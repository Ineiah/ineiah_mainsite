import { createGlobalState, useDark, useToggle } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vueuse+core@14.4.0_vue@3.5.40_typescript@6.0.3_/node_modules/@vueuse/core/dist/index.js?v=7e73afc2";
/**
* Composable to manage dark mode state
* @param enabled - Whether to enable dark mode support (default: false)
* @example
* const { darkMode, toggleDarkMode } = useDarkModeComposable(true)
* darkMode.value = true // Enable dark mode
* toggleDarkMode() // Toggle dark mode
*/
export const useDarkModeComposable = createGlobalState((enabled = false) => {
	const darkMode = useDark();
	if (true && enabled) {
		const toggleDarkMode = useToggle(darkMode);
		return {
			darkMode,
			toggleDarkMode
		};
	} else {
		return {
			darkMode,
			toggleDarkMode: () => {}
		};
	}
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBUUEsT0FBTyxNQUFNLHdCQUF3QixtQkFBbUIsVUFBVSxVQUFVO0NBQzFFLE1BQU0sV0FBVyxRQUFRO0NBRXpCLElBQUksWUFBWTtFQUNkLE1BQU0saUJBQWlCLFVBQVUsUUFBUTtFQUV6QyxPQUFPO0dBQ0w7R0FDQTtFQUNGO0NBQ0YsT0FBTztFQUNMLE9BQU87R0FDTDtHQUNBLHNCQUFzQixDQUFFO0VBQzFCO0NBQ0Y7QUFDRixDQUFDIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJkYXJrX21vZGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBDb21wb3NhYmxlIHRvIG1hbmFnZSBkYXJrIG1vZGUgc3RhdGVcbiAqIEBwYXJhbSBlbmFibGVkIC0gV2hldGhlciB0byBlbmFibGUgZGFyayBtb2RlIHN1cHBvcnQgKGRlZmF1bHQ6IGZhbHNlKVxuICogQGV4YW1wbGVcbiAqIGNvbnN0IHsgZGFya01vZGUsIHRvZ2dsZURhcmtNb2RlIH0gPSB1c2VEYXJrTW9kZUNvbXBvc2FibGUodHJ1ZSlcbiAqIGRhcmtNb2RlLnZhbHVlID0gdHJ1ZSAvLyBFbmFibGUgZGFyayBtb2RlXG4gKiB0b2dnbGVEYXJrTW9kZSgpIC8vIFRvZ2dsZSBkYXJrIG1vZGVcbiAqL1xuZXhwb3J0IGNvbnN0IHVzZURhcmtNb2RlQ29tcG9zYWJsZSA9IGNyZWF0ZUdsb2JhbFN0YXRlKChlbmFibGVkID0gZmFsc2UpID0+IHtcbiAgY29uc3QgZGFya01vZGUgPSB1c2VEYXJrKClcblxuICBpZiAoaW1wb3J0Lm1ldGEuY2xpZW50ICYmIGVuYWJsZWQpIHtcbiAgICBjb25zdCB0b2dnbGVEYXJrTW9kZSA9IHVzZVRvZ2dsZShkYXJrTW9kZSlcblxuICAgIHJldHVybiB7XG4gICAgICBkYXJrTW9kZSxcbiAgICAgIHRvZ2dsZURhcmtNb2RlXG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHJldHVybiB7XG4gICAgICBkYXJrTW9kZSxcbiAgICAgIHRvZ2dsZURhcmtNb2RlOiAoKSA9PiB7IH1cbiAgICB9XG4gIH1cbn0pXG4iXSwiZmlsZSI6Ii9Wb2x1bWVzL0NvZGluZy9Qcm9qZWN0cy9XZWJzaXRlcy9pbmVpYWgvZnJvbnRlbmQvYXBwL2NvbXBvc2FibGVzL2RhcmtfbW9kZS50cyJ9