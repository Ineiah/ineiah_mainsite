import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/components/hero/BottomCta.vue");import { default as __nuxt_component_0 } from "/_nuxt/components/hero/buttons/Glass.vue";
import { default as __nuxt_component_1 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxtjs+i18n@10.6.0_@vue+compiler-dom@3.5.40_db0@0.3.4_better-sqlite3@13.0.2_drizzle-or_ebcb91ac37e09cc979ede2167e22c07a/node_modules/@nuxtjs/i18n/dist/runtime/components/NuxtLinkLocale.js?v=7e73afc2";
import { useBusinessDetails as _$__useBusinessDetails } from "/_nuxt/composables/business/base.ts";;import { __nuxtTimelineWrap } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+devtools@3.4.1_db0@0.3.4_better-sqlite3@13.0.2_drizzle-orm@0.45.2_@opentelemetry+_0e55243a794e05cb19a29a0506aae086/node_modules/@nuxt/devtools/dist/runtime/function-metrics-helpers.js?v=7e73afc2";const useBusinessDetails = __nuxtTimelineWrap("useBusinessDetails", _$__useBusinessDetails);
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@8.2.0_@types+node@26.1.2_esbuild@0.28.1_jiti@2.7.0_sa_bcac4fa99282966dd94ca7ad2dfebde1/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=7e73afc2"
import { defineComponent as _defineComponent } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _sfc_main = /*@__PURE__*/ _defineComponent({
	__name: "HeroBottomCta",
	props: { image: {
		type: String,
		required: true
	} },
	setup(__props, { expose: __expose }) {
		__expose();
		/**
		* Business details
		*/
		const { businessDetails } = useBusinessDetails();
		const fallbackTelephone = businessDetails.contact.telephone;
		const __returned__ = {
			businessDetails,
			fallbackTelephone
		};
		Object.defineProperty(__returned__, "__isScriptSetup", {
			enumerable: false,
			value: true
		});
		return __returned__;
	}
});
import { toDisplayString as _toDisplayString, createElementVNode as _createElementVNode, resolveComponent as _resolveComponent, createVNode as _createVNode, withCtx as _withCtx, normalizeStyle as _normalizeStyle, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _hoisted_1 = {
	id: "lead",
	class: "md:max-w-7xl md:mx-auto text-center text-primary-50 dark:text-primary-200 p-5 md:p-10"
};
const _hoisted_2 = { class: "text-6xl md:text-7xl dark:text-primary-200 font-bold mb-2 animate animate-fade-up" };
const _hoisted_3 = { class: "text-2xl font-normal dark:text-primary-200 mb-10" };
const _hoisted_4 = { class: "flex flex-wrap space-y-2 w-full md:space-y-0 md:flex-nowrap justify-center md:items-center sm:space-x-2 md:space-x-5" };
const _hoisted_5 = ["href"];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
	const _component_hero_buttons_glass = __nuxt_component_0;
	const _component_nuxt_link_locale = __nuxt_component_1;
	return _openBlock(), _tracer(2,2,_createElementBlock(
		"div",
		{
			ref: "heroEl",
			class: "w-full h-[98vh] bg-center bg-no-repeat bg-cover flex items-end",
			style: _normalizeStyle({ backgroundImage: `url(${$props.image})` })
		},
		[_tracer(3,4,_createElementVNode("div", _hoisted_1, [
			_tracer(4,6,_createElementVNode(
				"h1",
				_hoisted_2,
				_toDisplayString(_ctx.$t("L'art de coiffer toutes les textures")),
				1
				/* TEXT */
			)),
			_tracer(8,6,_createElementVNode(
				"p",
				_hoisted_3,
				_toDisplayString(_ctx.$t("Cheveux crépus, bouclés, lisses ou texturés ? Chaque chevelure est célébrée")),
				1
				/* TEXT */
			)),
			_tracer(12,6,_createElementVNode("div", _hoisted_4, [_tracer(13,8,_createVNode(_component_nuxt_link_locale, {
				id: "link-offer-hero",
				"nuxt-link-locale": "",
				class: "block cursor-pointer",
				to: "/nos-prestations"
			}, {
				default: _withCtx(() => [_tracer(14,10,_createVNode(_component_hero_buttons_glass, {
					text: "Prestations",
					"icon-name": "lucide:arrow-up-right"
				}))]),
				_: 1
			})), _tracer(17,8,_createElementVNode("a", {
				id: "tel-call-us-hero",
				href: `tel:${$setup.fallbackTelephone}`,
				class: "block cursor-pointer"
			}, [_tracer(18,10,_createVNode(_component_hero_buttons_glass, {
				text: "Me contacter",
				"icon-name": "lucide:phone"
			}))], 8, _hoisted_5))]))
		]))],
		4
		/* STYLE */
	));
}
_sfc_main.__hmrId = "338ce5a1";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.on("file-changed", ({ file }) => {
	__VUE_HMR_RUNTIME__.CHANGED_FILE = file;
});
import.meta.hot.accept((mod) => {
	if (!mod) return;
	const { default: updated, _rerender_only } = mod;
	if (_rerender_only) {
		__VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
	} else {
		__VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
	}
});
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper";
export default /*#__PURE__*/ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "/Volumes/Coding/Projects/Websites/ineiah/frontend/app/components/hero/BottomCta.vue"]]);

function _tracer(line, column, vnode) { return _tracerRecordPosition("app/components/hero/BottomCta.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztFQThCQSxNQUFNLEVBQUUsb0JBQW9CLG1CQUFtQjtFQUUvQyxNQUFNLG9CQUFvQixnQkFBZ0IsUUFBUTs7Ozs7Ozs7Ozs7Ozs7Q0E5QnpDLElBQUc7Q0FBTyxPQUFNOztBQUNmLDRCQUFNLG9GQUFtRjtBQUkxRiw0QkFBTSxtREFBa0Q7QUFJdEQsNEJBQU0sdUhBQXNIOzs7OztDQVZySTtFQW9CTTtFQUFBO0dBcEJELEtBQUk7R0FBUyxPQUFNO0dBQWtFLE9BQUssMENBQTRCLGFBQUs7O2VBQzlILG9CQWtCTSxPQWxCTixZQWtCTTtlQWpCSjtJQUVLO0lBRkw7SUFFSyxpQkFEQSxRQUFFO0lBQUE7O0dBQUE7ZUFHUDtJQUVJO0lBRko7SUFFSSxpQkFEQyxRQUFFO0lBQUE7O0dBQUE7Z0JBR1Asb0JBUU0sT0FSTixZQVFNLGNBUEosYUFFbUI7SUFGRCxJQUFHO0lBQWtCO0lBQWlCLE9BQU07SUFBdUIsSUFBRzs7SUFDdEYsd0JBQTJFLGVBQTNFLGFBQTJFO0tBQXZELE1BQUs7S0FBYyxhQUFVOzs7cUJBR25ELG9CQUVJO0lBRkQsSUFBRztJQUFvQixNQUFJLE9BQVM7SUFBcUIsT0FBTTtxQkFDaEUsYUFBbUU7SUFBL0MsTUFBSztJQUFlLGFBQVUiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIkJvdHRvbUN0YS52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxuICA8ZGl2IHJlZj1cImhlcm9FbFwiIGNsYXNzPVwidy1mdWxsIGgtWzk4dmhdIGJnLWNlbnRlciBiZy1uby1yZXBlYXQgYmctY292ZXIgZmxleCBpdGVtcy1lbmRcIiA6c3R5bGU9XCJ7IGJhY2tncm91bmRJbWFnZTogYHVybCgke2ltYWdlfSlgIH1cIj5cbiAgICA8ZGl2IGlkPVwibGVhZFwiIGNsYXNzPVwibWQ6bWF4LXctN3hsIG1kOm14LWF1dG8gdGV4dC1jZW50ZXIgdGV4dC1wcmltYXJ5LTUwIGRhcms6dGV4dC1wcmltYXJ5LTIwMCBwLTUgbWQ6cC0xMFwiPlxuICAgICAgPGgxIGNsYXNzPVwidGV4dC02eGwgbWQ6dGV4dC03eGwgZGFyazp0ZXh0LXByaW1hcnktMjAwIGZvbnQtYm9sZCBtYi0yIGFuaW1hdGUgYW5pbWF0ZS1mYWRlLXVwXCI+XG4gICAgICAgIHt7ICR0KFwiTCdhcnQgZGUgY29pZmZlciB0b3V0ZXMgbGVzIHRleHR1cmVzXCIpIH19XG4gICAgICA8L2gxPlxuXG4gICAgICA8cCBjbGFzcz1cInRleHQtMnhsIGZvbnQtbm9ybWFsIGRhcms6dGV4dC1wcmltYXJ5LTIwMCBtYi0xMFwiPlxuICAgICAgICB7eyAkdChcIkNoZXZldXggY3LDqXB1cywgYm91Y2zDqXMsIGxpc3NlcyBvdSB0ZXh0dXLDqXMgPyBDaGFxdWUgY2hldmVsdXJlIGVzdCBjw6lsw6licsOpZVwiKSB9fVxuICAgICAgPC9wPlxuXG4gICAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LXdyYXAgc3BhY2UteS0yIHctZnVsbCBtZDpzcGFjZS15LTAgbWQ6ZmxleC1ub3dyYXAganVzdGlmeS1jZW50ZXIgbWQ6aXRlbXMtY2VudGVyIHNtOnNwYWNlLXgtMiBtZDpzcGFjZS14LTVcIj5cbiAgICAgICAgPG51eHQtbGluay1sb2NhbGUgaWQ9XCJsaW5rLW9mZmVyLWhlcm9cIiBudXh0LWxpbmstbG9jYWxlIGNsYXNzPVwiYmxvY2sgY3Vyc29yLXBvaW50ZXJcIiB0bz1cIi9ub3MtcHJlc3RhdGlvbnNcIj5cbiAgICAgICAgICA8aGVyby1idXR0b25zLWdsYXNzIHRleHQ9XCJQcmVzdGF0aW9uc1wiIGljb24tbmFtZT1cImx1Y2lkZTphcnJvdy11cC1yaWdodFwiIC8+XG4gICAgICAgIDwvbnV4dC1saW5rLWxvY2FsZT5cblxuICAgICAgICA8YSBpZD1cInRlbC1jYWxsLXVzLWhlcm9cIiA6aHJlZj1cImB0ZWw6JHtmYWxsYmFja1RlbGVwaG9uZX1gXCIgY2xhc3M9XCJibG9jayBjdXJzb3ItcG9pbnRlclwiPlxuICAgICAgICAgIDxoZXJvLWJ1dHRvbnMtZ2xhc3MgdGV4dD1cIk1lIGNvbnRhY3RlclwiIGljb24tbmFtZT1cImx1Y2lkZTpwaG9uZVwiIC8+XG4gICAgICAgIDwvYT5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG5cbjxzY3JpcHQgc2V0dXAgbGFuZz1cInRzXCI+XG5kZWZpbmVQcm9wczx7IGltYWdlOiBzdHJpbmcgfT4oKVxuXG4vKipcbiAqIEJ1c2luZXNzIGRldGFpbHNcbiAqL1xuY29uc3QgeyBidXNpbmVzc0RldGFpbHMgfSA9IHVzZUJ1c2luZXNzRGV0YWlscygpXG5cbmNvbnN0IGZhbGxiYWNrVGVsZXBob25lID0gYnVzaW5lc3NEZXRhaWxzLmNvbnRhY3QudGVsZXBob25lXG48L3NjcmlwdD5cbiJdLCJmaWxlIjoiL1ZvbHVtZXMvQ29kaW5nL1Byb2plY3RzL1dlYnNpdGVzL2luZWlhaC9mcm9udGVuZC9hcHAvY29tcG9uZW50cy9oZXJvL0JvdHRvbUN0YS52dWUifQ==