import { computed, customRef, effectScope, getCurrentInstance, getCurrentScope, hasInjectionContext, inject, isReactive, isRef, nextTick, onBeforeMount, onBeforeUnmount, onMounted, onScopeDispose, onUnmounted, provide, reactive, readonly, ref, shallowReadonly, shallowRef, toRef as toRef$1, toRefs as toRefs$1, toValue, unref, watch, watchEffect } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
//#region computedEager/index.ts
/**
*
* @deprecated This function will be removed in future version.
*
* Note: If you are using Vue 3.4+, you can straight use computed instead.
* Because in Vue 3.4+, if computed new value does not change,
* computed, effect, watch, watchEffect, render dependencies will not be triggered.
* refer: https://github.com/vuejs/core/pull/5912
*
* @param fn effect function
* @param options WatchOptionsBase
* @returns readonly shallowRef
*/
function computedEager(fn, options) {
	var _options$flush;
	const result = shallowRef();
	watchEffect(() => {
		result.value = fn();
	}, {
		...options,
		flush: (_options$flush = options === null || options === void 0 ? void 0 : options.flush) !== null && _options$flush !== void 0 ? _options$flush : "sync"
	});
	return readonly(result);
}
/** @deprecated use `computedEager` instead */
const eagerComputed = computedEager;
//#endregion
//#region computedWithControl/index.ts
/**
* Explicitly define the deps of computed.
*
* @param source
* @param fn
*/
function computedWithControl(source, fn, options = {}) {
	let v = void 0;
	let track;
	let trigger;
	let dirty = true;
	const update = () => {
		dirty = true;
		trigger();
	};
	watch(source, update, {
		flush: "sync",
		...options
	});
	const get = typeof fn === "function" ? fn : fn.get;
	const set = typeof fn === "function" ? void 0 : fn.set;
	const result = customRef((_track, _trigger) => {
		track = _track;
		trigger = _trigger;
		return {
			get() {
				if (dirty) {
					v = get(v);
					dirty = false;
				}
				track();
				return v;
			},
			set(v) {
				set === null || set === void 0 || set(v);
			}
		};
	});
	result.trigger = update;
	return result;
}
/** @deprecated use `computedWithControl` instead */
const controlledComputed = computedWithControl;
//#endregion
//#region createDisposableDirective/index.ts
/**
* Utility for authoring disposable directives. Reactive effects created within `mounted` directive hook will be tracked and automatically disposed when directive is unmounted.
*
* @see https://vueuse.org/createDisposableDirective
*
* @__NO_SIDE_EFFECTS__
*/
function createDisposableDirective(origin = {}) {
	function isFunc(fn) {
		return typeof fn === "function";
	}
	const normalisedOrigin = isFunc(origin) ? {
		mounted: origin,
		updated: origin
	} : origin;
	const { mounted, unmounted } = normalisedOrigin;
	if (!isFunc(mounted)) return origin;
	const scopeWeakMap = /* @__PURE__ */ new WeakMap();
	return {
		...normalisedOrigin,
		mounted(el, binding, vNode, prevNode) {
			var _scopeWeakMap$get;
			const scope = (_scopeWeakMap$get = scopeWeakMap.get(el)) !== null && _scopeWeakMap$get !== void 0 ? _scopeWeakMap$get : effectScope();
			scopeWeakMap.set(el, scope);
			scope.run(() => {
				mounted === null || mounted === void 0 || mounted(el, binding, vNode, prevNode);
			});
		},
		unmounted(el, binding, vNode, prevNode) {
			var _scopeWeakMap$get2;
			(_scopeWeakMap$get2 = scopeWeakMap.get(el)) === null || _scopeWeakMap$get2 === void 0 || _scopeWeakMap$get2.stop();
			scopeWeakMap.delete(el);
			if (isFunc(unmounted)) unmounted(el, binding, vNode, prevNode);
		}
	};
}
//#endregion
//#region tryOnScopeDispose/index.ts
/**
* Call onScopeDispose() if it's inside an effect scope lifecycle, if not, do nothing
*
* @param fn
*/
function tryOnScopeDispose(fn, failSilently) {
	if (getCurrentScope()) {
		onScopeDispose(fn, failSilently);
		return true;
	}
	return false;
}
//#endregion
//#region createEventHook/index.ts
/**
* Utility for creating event hooks
*
* @see https://vueuse.org/createEventHook
*
* @__NO_SIDE_EFFECTS__
*/
function createEventHook() {
	const fns = /* @__PURE__ */ new Set();
	const off = (fn) => {
		fns.delete(fn);
	};
	const clear = () => {
		fns.clear();
	};
	const on = (fn) => {
		fns.add(fn);
		const offFn = () => off(fn);
		tryOnScopeDispose(offFn);
		return { off: offFn };
	};
	const trigger = (...args) => {
		return Promise.all(Array.from(fns).map((fn) => fn(...args)));
	};
	return {
		on,
		off,
		trigger,
		clear
	};
}
//#endregion
//#region createGlobalState/index.ts
/**
* Keep states in the global scope to be reusable across Vue instances.
*
* @see https://vueuse.org/createGlobalState
* @param stateFactory A factory function to create the state
*
* @__NO_SIDE_EFFECTS__
*/
function createGlobalState(stateFactory) {
	let initialized = false;
	let state;
	const scope = effectScope(true);
	return ((...args) => {
		if (!initialized) {
			state = scope.run(() => stateFactory(...args));
			initialized = true;
		}
		return state;
	});
}
//#endregion
//#region provideLocal/map.ts
const localProvidedStateMap = /* @__PURE__ */ new WeakMap();
//#endregion
//#region injectLocal/index.ts
/**
* On the basis of `inject`, it is allowed to directly call inject to obtain the value after call provide in the same component.
*
* @example
* ```ts
* injectLocal('MyInjectionKey', 1)
* const injectedValue = injectLocal('MyInjectionKey') // injectedValue === 1
* ```
*
* @__NO_SIDE_EFFECTS__
*/
const injectLocal = (...args) => {
	var _getCurrentInstance;
	const key = args[0];
	const instance = (_getCurrentInstance = getCurrentInstance()) === null || _getCurrentInstance === void 0 ? void 0 : _getCurrentInstance.proxy;
	const owner = instance !== null && instance !== void 0 ? instance : getCurrentScope();
	if (owner == null && !hasInjectionContext()) throw new Error("injectLocal must be called in setup");
	if (owner && localProvidedStateMap.has(owner) && key in localProvidedStateMap.get(owner)) return localProvidedStateMap.get(owner)[key];
	return inject(...args);
};
//#endregion
//#region provideLocal/index.ts
/**
* On the basis of `provide`, it is allowed to directly call inject to obtain the value after call provide in the same component.
*
* @example
* ```ts
* provideLocal('MyInjectionKey', 1)
* const injectedValue = injectLocal('MyInjectionKey') // injectedValue === 1
* ```
*/
function provideLocal(key, value) {
	var _getCurrentInstance;
	const instance = (_getCurrentInstance = getCurrentInstance()) === null || _getCurrentInstance === void 0 ? void 0 : _getCurrentInstance.proxy;
	const owner = instance !== null && instance !== void 0 ? instance : getCurrentScope();
	if (owner == null) throw new Error("provideLocal must be called in setup");
	if (!localProvidedStateMap.has(owner)) localProvidedStateMap.set(owner, Object.create(null));
	const localProvidedState = localProvidedStateMap.get(owner);
	localProvidedState[key] = value;
	return provide(key, value);
}
//#endregion
//#region createInjectionState/index.ts
function createInjectionState(composable, options) {
	const key = (options === null || options === void 0 ? void 0 : options.injectionKey) || Symbol(composable.name || "InjectionState");
	const defaultValue = options === null || options === void 0 ? void 0 : options.defaultValue;
	const useProvidingState = (...args) => {
		const state = composable(...args);
		provideLocal(key, state);
		return state;
	};
	const useInjectedState = () => injectLocal(key, defaultValue);
	return [useProvidingState, useInjectedState];
}
//#endregion
//#region createRef/index.ts
/**
* Returns a `deepRef` or `shallowRef` depending on the `deep` param.
*
* @example createRef(1) // ShallowRef<number>
* @example createRef(1, false) // ShallowRef<number>
* @example createRef(1, true) // Ref<number>
* @example createRef("string") // ShallowRef<string>
* @example createRef<"A"|"B">("A", true) // Ref<"A"|"B">
*
* @param value
* @param deep
* @returns the `deepRef` or `shallowRef`
*
* @__NO_SIDE_EFFECTS__
*/
function createRef(value, deep) {
	if (deep === true) return ref(value);
	else return shallowRef(value);
}
//#endregion
//#region utils/is.ts
const isClient = typeof window !== "undefined" && typeof document !== "undefined";
const isWorker = typeof WorkerGlobalScope !== "undefined" && globalThis instanceof WorkerGlobalScope;
const isDef = (val) => typeof val !== "undefined";
const notNullish = (val) => val != null;
const assert = (condition, ...infos) => {
	if (!condition) console.warn(...infos);
};
const toString = Object.prototype.toString;
const isObject = (val) => toString.call(val) === "[object Object]";
const now = () => Date.now();
const timestamp = () => +Date.now();
const clamp = (n, min, max) => Math.min(max, Math.max(min, n));
const noop = () => {};
const rand = (min, max) => {
	min = Math.ceil(min);
	max = Math.floor(max);
	return Math.floor(Math.random() * (max - min + 1)) + min;
};
const hasOwn = (val, key) => Object.hasOwn(val, key);
const isIOS = /* #__PURE__ */ getIsIOS();
function getIsIOS() {
	var _window, _window2, _window3;
	return isClient && !!((_window = window) === null || _window === void 0 || (_window = _window.navigator) === null || _window === void 0 ? void 0 : _window.userAgent) && (/iP(?:ad|hone|od)/.test(window.navigator.userAgent) || ((_window2 = window) === null || _window2 === void 0 || (_window2 = _window2.navigator) === null || _window2 === void 0 ? void 0 : _window2.maxTouchPoints) > 2 && /iPad|Macintosh/.test((_window3 = window) === null || _window3 === void 0 ? void 0 : _window3.navigator.userAgent));
}
//#endregion
//#region toRef/index.ts
function toRef(...args) {
	if (args.length !== 1) return toRef$1(...args);
	const r = args[0];
	return typeof r === "function" ? readonly(customRef(() => ({
		get: r,
		set: noop
	}))) : ref(r);
}
//#endregion
//#region utils/filters.ts
function createFilterWrapper(filter, fn) {
	function wrapper(...args) {
		return new Promise((resolve, reject) => {
			Promise.resolve(filter(() => fn.apply(this, args), {
				fn,
				thisArg: this,
				args
			})).then(resolve).catch(reject);
		});
	}
	if ("cancel" in filter) Object.assign(wrapper, {
		cancel: filter.cancel,
		flush: filter.flush,
		isPending: filter.isPending
	});
	return wrapper;
}
const bypassFilter = (invoke) => {
	return invoke();
};
/**
* Create an EventFilter that debounce the events
*/
function debounceFilter(ms, options = {}) {
	let timer;
	let maxTimer;
	let lastRejector = noop;
	let lastResolve = noop;
	const _pending = shallowRef(false);
	const _clearTimeout = (timer) => {
		clearTimeout(timer);
		lastRejector();
		lastRejector = noop;
	};
	let lastInvoker;
	const handler = (invoke) => {
		const duration = toValue(ms);
		const maxDuration = toValue(options.maxWait);
		if (timer) _clearTimeout(timer);
		if (duration <= 0 || maxDuration !== void 0 && maxDuration <= 0) {
			if (maxTimer) {
				_clearTimeout(maxTimer);
				maxTimer = void 0;
			}
			_pending.value = false;
			return Promise.resolve(invoke());
		}
		_pending.value = true;
		return new Promise((resolve, reject) => {
			lastRejector = options.rejectOnCancel ? reject : resolve;
			lastResolve = resolve;
			lastInvoker = invoke;
			if (maxDuration && !maxTimer) maxTimer = setTimeout(() => {
				if (timer) _clearTimeout(timer);
				maxTimer = void 0;
				_pending.value = false;
				resolve(lastInvoker());
			}, maxDuration);
			timer = setTimeout(() => {
				if (maxTimer) _clearTimeout(maxTimer);
				maxTimer = void 0;
				_pending.value = false;
				resolve(invoke());
			}, duration);
		});
	};
	return Object.assign(handler, {
		cancel: () => {
			if (timer) {
				_clearTimeout(timer);
				timer = void 0;
			}
			if (maxTimer) {
				_clearTimeout(maxTimer);
				maxTimer = void 0;
			}
			_pending.value = false;
			lastResolve = noop;
		},
		flush: () => {
			if (_pending.value) {
				if (timer) {
					clearTimeout(timer);
					timer = void 0;
				}
				if (maxTimer) {
					clearTimeout(maxTimer);
					maxTimer = void 0;
				}
				_pending.value = false;
				const resolve = lastResolve;
				lastRejector = noop;
				lastResolve = noop;
				resolve(lastInvoker());
			}
		},
		isPending: shallowReadonly(_pending)
	});
}
function throttleFilter(...args) {
	let lastExec = 0;
	let timer;
	let isLeading = true;
	let lastRejector = noop;
	let lastValue;
	let ms;
	let trailing;
	let leading;
	let rejectOnCancel;
	if (!isRef(args[0]) && typeof args[0] === "object") ({delay: ms, trailing = true, leading = true, rejectOnCancel = false} = args[0]);
	else [ms, trailing = true, leading = true, rejectOnCancel = false] = args;
	const clear = () => {
		if (timer) {
			clearTimeout(timer);
			timer = void 0;
			lastRejector();
			lastRejector = noop;
		}
	};
	const filter = (_invoke) => {
		const duration = toValue(ms);
		const elapsed = Date.now() - lastExec;
		const invoke = () => {
			return lastValue = _invoke();
		};
		clear();
		if (duration <= 0) {
			lastExec = Date.now();
			return invoke();
		}
		if (elapsed > duration) {
			lastExec = Date.now();
			if (leading || !isLeading) invoke();
		} else if (trailing) lastValue = new Promise((resolve, reject) => {
			lastRejector = rejectOnCancel ? reject : resolve;
			timer = setTimeout(() => {
				lastExec = Date.now();
				isLeading = true;
				resolve(invoke());
				clear();
			}, Math.max(0, duration - elapsed));
		});
		if (!leading && !timer) timer = setTimeout(() => isLeading = true, duration);
		isLeading = false;
		return lastValue;
	};
	return filter;
}
/**
* EventFilter that gives extra controls to pause and resume the filter
*
* @param extendFilter  Extra filter to apply when the PausableFilter is active, default to none
* @param options Options to configure the filter
*/
function pausableFilter(extendFilter = bypassFilter, options = {}) {
	const { initialState = "active" } = options;
	const isActive = toRef(initialState === "active");
	function pause() {
		isActive.value = false;
	}
	function resume() {
		isActive.value = true;
	}
	const eventFilter = (...args) => {
		if (isActive.value) extendFilter(...args);
	};
	return {
		isActive: shallowReadonly(isActive),
		pause,
		resume,
		eventFilter
	};
}
//#endregion
//#region utils/general.ts
function promiseTimeout(ms, throwOnTimeout = false, reason = "Timeout") {
	return new Promise((resolve, reject) => {
		if (throwOnTimeout) setTimeout(reject, ms, reason);
		else setTimeout(resolve, ms);
	});
}
function identity(arg) {
	return arg;
}
/**
* Create singleton promise function
*
* @example
* ```
* const promise = createSingletonPromise(async () => { ... })
*
* await promise()
* await promise() // all of them will be bind to a single promise instance
* await promise() // and be resolved together
* ```
*/
function createSingletonPromise(fn) {
	let _promise;
	function wrapper() {
		if (!_promise) _promise = fn();
		return _promise;
	}
	wrapper.reset = async () => {
		const _prev = _promise;
		_promise = void 0;
		if (_prev) await _prev;
	};
	return wrapper;
}
function invoke(fn) {
	return fn();
}
function containsProp(obj, ...props) {
	return props.some((k) => k in obj);
}
function increaseWithUnit(target, delta) {
	var _target$match;
	if (typeof target === "number") return target + delta;
	const value = ((_target$match = target.match(/^-?\d+\.?\d*/)) === null || _target$match === void 0 ? void 0 : _target$match[0]) || "";
	const unit = target.slice(value.length);
	const result = Number.parseFloat(value) + delta;
	if (Number.isNaN(result)) return target;
	return result + unit;
}
/**
* Get a px value for SSR use, do not rely on this method outside of SSR as REM unit is assumed at 16px, which might not be the case on the client
*/
function pxValue(px) {
	return px.endsWith("rem") ? Number.parseFloat(px) * 16 : Number.parseFloat(px);
}
/**
* Create a new subset object by giving keys
*/
function objectPick(obj, keys, omitUndefined = false) {
	return keys.reduce((n, k) => {
		if (k in obj) {
			if (!omitUndefined || obj[k] !== void 0) n[k] = obj[k];
		}
		return n;
	}, {});
}
/**
* Create a new subset object by omit giving keys
*/
function objectOmit(obj, keys, omitUndefined = false) {
	return Object.fromEntries(Object.entries(obj).filter(([key, value]) => {
		return (!omitUndefined || value !== void 0) && !keys.includes(key);
	}));
}
function objectEntries(obj) {
	return Object.entries(obj);
}
function toArray(value) {
	return Array.isArray(value) ? value : [value];
}
//#endregion
//#region utils/port.ts
function cacheStringFunction(fn) {
	const cache = Object.create(null);
	return ((str) => {
		return cache[str] || (cache[str] = fn(str));
	});
}
const hyphenateRE = /\B([A-Z])/g;
const hyphenate = cacheStringFunction((str) => str.replace(hyphenateRE, "-$1").toLowerCase());
const camelizeRE = /-(\w)/g;
const camelize = cacheStringFunction((str) => {
	return str.replace(camelizeRE, (_, c) => c ? c.toUpperCase() : "");
});
//#endregion
//#region utils/vue.ts
function getLifeCycleTarget(target) {
	return target || getCurrentInstance();
}
//#endregion
//#region createSharedComposable/index.ts
/**
* Make a composable function usable with multiple Vue instances.
*
* @see https://vueuse.org/createSharedComposable
*
* @__NO_SIDE_EFFECTS__
*/
function createSharedComposable(composable) {
	if (!isClient) return composable;
	let subscribers = 0;
	let state;
	let scope;
	const dispose = () => {
		subscribers -= 1;
		if (scope && subscribers <= 0) {
			scope.stop();
			state = void 0;
			scope = void 0;
		}
	};
	return ((...args) => {
		subscribers += 1;
		if (!scope) {
			scope = effectScope(true);
			state = scope.run(() => composable(...args));
		}
		tryOnScopeDispose(dispose);
		return state;
	});
}
//#endregion
//#region extendRef/index.ts
function extendRef(ref, extend, { enumerable = false, unwrap = true } = {}) {
	for (const [key, value] of Object.entries(extend)) {
		if (key === "value") continue;
		if (isRef(value) && unwrap) Object.defineProperty(ref, key, {
			get() {
				return value.value;
			},
			set(v) {
				value.value = v;
			},
			enumerable
		});
		else Object.defineProperty(ref, key, {
			value,
			enumerable
		});
	}
	return ref;
}
//#endregion
//#region get/index.ts
function get(obj, key) {
	if (key == null) return unref(obj);
	return unref(obj)[key];
}
//#endregion
//#region isDefined/index.ts
function isDefined(v) {
	return unref(v) != null;
}
//#endregion
//#region makeDestructurable/index.ts
/* @__NO_SIDE_EFFECTS__ */
function makeDestructurable(obj, arr) {
	if (typeof Symbol !== "undefined") {
		const clone = { ...obj };
		Object.defineProperty(clone, Symbol.iterator, {
			enumerable: false,
			value() {
				let index = 0;
				return { next: () => ({
					value: arr[index++],
					done: index > arr.length
				}) };
			}
		});
		return clone;
	} else return Object.assign([...arr], obj);
}
//#endregion
//#region reactify/index.ts
/**
* Converts plain function into a reactive function.
* The converted function accepts refs as it's arguments
* and returns a ComputedRef, with proper typing.
*
* @param fn - Source function
* @param options - Options
*
* @__NO_SIDE_EFFECTS__
*/
function reactify(fn, options) {
	const unrefFn = (options === null || options === void 0 ? void 0 : options.computedGetter) === false ? unref : toValue;
	return function(...args) {
		return computed(() => fn.apply(this, args.map((i) => unrefFn(i))));
	};
}
/** @deprecated use `reactify` instead */
const createReactiveFn = reactify;
//#endregion
//#region reactifyObject/index.ts
/**
* Apply `reactify` to an object
*
* @__NO_SIDE_EFFECTS__
*/
function reactifyObject(obj, optionsOrKeys = {}) {
	let keys = [];
	let options;
	if (Array.isArray(optionsOrKeys)) keys = optionsOrKeys;
	else {
		options = optionsOrKeys;
		const { includeOwnProperties = true } = optionsOrKeys;
		keys.push(...Object.keys(obj));
		if (includeOwnProperties) keys.push(...Object.getOwnPropertyNames(obj));
	}
	return Object.fromEntries(keys.map((key) => {
		const value = obj[key];
		return [key, typeof value === "function" ? reactify(value.bind(obj), options) : value];
	}));
}
//#endregion
//#region toReactive/index.ts
/**
* Converts ref to reactive.
*
* @see https://vueuse.org/toReactive
* @param objectRef A ref of object
*/
function toReactive(objectRef) {
	if (!isRef(objectRef)) return reactive(objectRef);
	return reactive(new Proxy({}, {
		get(_, p, receiver) {
			return unref(Reflect.get(objectRef.value, p, receiver));
		},
		set(_, p, value) {
			if (isRef(objectRef.value[p]) && !isRef(value)) objectRef.value[p].value = value;
			else objectRef.value[p] = value;
			return true;
		},
		deleteProperty(_, p) {
			return Reflect.deleteProperty(objectRef.value, p);
		},
		has(_, p) {
			return Reflect.has(objectRef.value, p);
		},
		ownKeys() {
			return Object.keys(objectRef.value);
		},
		getOwnPropertyDescriptor() {
			return {
				enumerable: true,
				configurable: true
			};
		}
	}));
}
//#endregion
//#region reactiveComputed/index.ts
/**
* Computed reactive object.
*/
function reactiveComputed(fn) {
	return toReactive(computed(fn));
}
//#endregion
//#region reactiveOmit/index.ts
/**
* Reactively omit fields from a reactive object
*
* @see https://vueuse.org/reactiveOmit
*/
function reactiveOmit(obj, ...keys) {
	const flatKeys = keys.flat();
	const predicate = flatKeys[0];
	return reactiveComputed(() => typeof predicate === "function" ? Object.fromEntries(Object.entries(toRefs$1(obj)).filter(([k, v]) => !predicate(toValue(v), k))) : Object.fromEntries(Object.entries(toRefs$1(obj)).filter((e) => !flatKeys.includes(e[0]))));
}
//#endregion
//#region reactivePick/index.ts
/**
* Reactively pick fields from a reactive object
*
* @see https://vueuse.org/reactivePick
*/
function reactivePick(obj, ...keys) {
	const flatKeys = keys.flat();
	const predicate = flatKeys[0];
	return reactiveComputed(() => typeof predicate === "function" ? Object.fromEntries(Object.entries(toRefs$1(obj)).filter(([k, v]) => predicate(toValue(v), k))) : Object.fromEntries(flatKeys.map((k) => [k, toRef(obj, k)])));
}
//#endregion
//#region refAutoReset/index.ts
/**
* Create a ref which will be reset to the default value after some time.
*
* @see https://vueuse.org/refAutoReset
* @param defaultValue The value which will be set.
* @param afterMs      A zero-or-greater delay in milliseconds.
*/
function refAutoReset(defaultValue, afterMs = 1e4) {
	return customRef((track, trigger) => {
		let value = toValue(defaultValue);
		let timer;
		const resetAfter = () => setTimeout(() => {
			value = toValue(defaultValue);
			trigger();
		}, toValue(afterMs));
		tryOnScopeDispose(() => {
			clearTimeout(timer);
		});
		return {
			get() {
				track();
				return value;
			},
			set(newValue) {
				value = newValue;
				trigger();
				clearTimeout(timer);
				timer = resetAfter();
			}
		};
	});
}
/** @deprecated use `refAutoReset` instead */
const autoResetRef = refAutoReset;
//#endregion
//#region useDebounceFn/index.ts
/**
* Debounce execution of a function.
*
* @see https://vueuse.org/useDebounceFn
* @param  fn          A function to be executed after delay milliseconds debounced.
* @param  ms          A zero-or-greater delay in milliseconds. For event callbacks, values around 100 or 250 (or even higher) are most useful.
* @param  options     Options
*
* @return A new, debounced, function with isPending, cancel, and flush properties.
*/
function useDebounceFn(fn, ms = 200, options = {}) {
	return createFilterWrapper(debounceFilter(ms, options), fn);
}
//#endregion
//#region refDebounced/index.ts
/**
* Debounce updates of a ref.
*
* @return A new debounced ref.
*/
function refDebounced(value, ms = 200, options = {}) {
	const debounced = ref(toValue(value));
	const updater = useDebounceFn(() => {
		debounced.value = value.value;
	}, ms, options);
	watch(value, () => updater());
	return shallowReadonly(debounced);
}
/** @deprecated use `refDebounced` instead */
const debouncedRef = refDebounced;
/** @deprecated use `refDebounced` instead */
const useDebounce = refDebounced;
//#endregion
//#region refDefault/index.ts
/**
* Apply default value to a ref.
*
* @__NO_SIDE_EFFECTS__
*/
function refDefault(source, defaultValue) {
	return computed({
		get() {
			var _source$value;
			return (_source$value = source.value) !== null && _source$value !== void 0 ? _source$value : defaultValue;
		},
		set(value) {
			source.value = value;
		}
	});
}
//#endregion
//#region refManualReset/index.ts
/**
* Create a ref with manual reset functionality.
*
* @see https://vueuse.org/refManualReset
* @param defaultValue The value which will be set.
*/
function refManualReset(defaultValue) {
	let value = toValue(defaultValue);
	let trigger;
	const reset = () => {
		value = toValue(defaultValue);
		trigger();
	};
	const refValue = customRef((track, _trigger) => {
		trigger = _trigger;
		return {
			get() {
				track();
				return value;
			},
			set(newValue) {
				value = newValue;
				trigger();
			}
		};
	});
	refValue.reset = reset;
	return refValue;
}
//#endregion
//#region useThrottleFn/index.ts
/**
* Throttle execution of a function. Especially useful for rate limiting
* execution of handlers on events like resize and scroll.
*
* @param   fn             A function to be executed after delay milliseconds. The `this` context and all arguments are passed through, as-is,
*                                    to `callback` when the throttled-function is executed.
* @param   ms             A zero-or-greater delay in milliseconds. For event callbacks, values around 100 or 250 (or even higher) are most useful.
*                                    (default value: 200)
*
* @param [trailing] if true, call fn again after the time is up (default value: false)
*
* @param [leading] if true, call fn on the leading edge of the ms timeout (default value: true)
*
* @param [rejectOnCancel] if true, reject the last call if it's been cancel (default value: false)
*
* @return  A new, throttled, function.
*
* @__NO_SIDE_EFFECTS__
*/
function useThrottleFn(fn, ms = 200, trailing = false, leading = true, rejectOnCancel = false) {
	return createFilterWrapper(throttleFilter(ms, trailing, leading, rejectOnCancel), fn);
}
//#endregion
//#region refThrottled/index.ts
/**
* Throttle execution of a function. Especially useful for rate limiting
* execution of handlers on events like resize and scroll.
*
* @param value Ref value to be watched with throttle effect
* @param  delay  A zero-or-greater delay in milliseconds. For event callbacks, values around 100 or 250 (or even higher) are most useful.
* @param trailing if true, update the value again after the delay time is up
* @param leading if true, update the value on the leading edge of the ms timeout
*/
function refThrottled(value, delay = 200, trailing = true, leading = true) {
	if (delay <= 0) return value;
	const throttled = ref(toValue(value));
	const updater = useThrottleFn(() => {
		throttled.value = value.value;
	}, delay, trailing, leading);
	watch(value, () => updater());
	return throttled;
}
/** @deprecated use `refThrottled` instead */
const throttledRef = refThrottled;
/** @deprecated use `refThrottled` instead */
const useThrottle = refThrottled;
//#endregion
//#region refWithControl/index.ts
/**
* Fine-grained controls over ref and its reactivity.
*
* @__NO_SIDE_EFFECTS__
*/
function refWithControl(initial, options = {}) {
	let source = initial;
	let track;
	let trigger;
	const ref = customRef((_track, _trigger) => {
		track = _track;
		trigger = _trigger;
		return {
			get() {
				return get();
			},
			set(v) {
				set(v);
			}
		};
	});
	function get(tracking = true) {
		if (tracking) track();
		return source;
	}
	function set(value, triggering = true) {
		var _options$onBeforeChan, _options$onChanged;
		if (value === source) return;
		const old = source;
		if (((_options$onBeforeChan = options.onBeforeChange) === null || _options$onBeforeChan === void 0 ? void 0 : _options$onBeforeChan.call(options, value, old)) === false) return;
		source = value;
		(_options$onChanged = options.onChanged) === null || _options$onChanged === void 0 || _options$onChanged.call(options, value, old);
		if (triggering) trigger();
	}
	/**
	* Get the value without tracked in the reactivity system
	*/
	const untrackedGet = () => get(false);
	/**
	* Set the value without triggering the reactivity system
	*/
	const silentSet = (v) => set(v, false);
	/**
	* Get the value without tracked in the reactivity system.
	*
	* Alias for `untrackedGet()`
	*/
	const peek = () => get(false);
	/**
	* Set the value without triggering the reactivity system
	*
	* Alias for `silentSet(v)`
	*/
	const lay = (v) => set(v, false);
	return extendRef(ref, {
		get,
		set,
		untrackedGet,
		silentSet,
		peek,
		lay
	}, { enumerable: true });
}
/** @deprecated use `refWithControl` instead */
const controlledRef = refWithControl;
//#endregion
//#region set/index.ts
/**
*  Shorthand for `ref.value = x`
*/
function set(...args) {
	if (args.length === 2) {
		const [ref, value] = args;
		ref.value = value;
	}
	if (args.length === 3) {
		const [target, key, value] = args;
		target[key] = value;
	}
}
//#endregion
//#region watchWithFilter/index.ts
function watchWithFilter(source, cb, options = {}) {
	const { eventFilter = bypassFilter, ...watchOptions } = options;
	return watch(source, createFilterWrapper(eventFilter, cb), watchOptions);
}
//#endregion
//#region watchPausable/index.ts
/** @deprecated Use Vue's built-in `watch` instead. This function will be removed in future version. */
function watchPausable(source, cb, options = {}) {
	const { eventFilter: filter, initialState = "active", ...watchOptions } = options;
	const { eventFilter, pause, resume, isActive } = pausableFilter(filter, { initialState });
	return {
		stop: watchWithFilter(source, cb, {
			...watchOptions,
			eventFilter
		}),
		pause,
		resume,
		isActive
	};
}
/** @deprecated Use Vue's built-in `watch` instead. This function will be removed in future version. */
const pausableWatch = watchPausable;
//#endregion
//#region syncRef/index.ts
/**
* Two-way refs synchronization.
* From the set theory perspective to restrict the option's type
* Check in the following order:
* 1. L = R
* 2. L ∩ R ≠ ∅
* 3. L ⊆ R
* 4. L ∩ R = ∅
*/
function syncRef(left, right, ...[options]) {
	const { flush = "sync", deep = false, immediate = true, direction = "both", transform = {} } = options || {};
	const watchers = [];
	const transformLTR = "ltr" in transform && transform.ltr || ((v) => v);
	const transformRTL = "rtl" in transform && transform.rtl || ((v) => v);
	if (direction === "both" || direction === "ltr") watchers.push(watchPausable(left, (newValue) => {
		watchers.forEach((w) => w.pause());
		right.value = transformLTR(newValue);
		watchers.forEach((w) => w.resume());
	}, {
		flush,
		deep,
		immediate
	}));
	if (direction === "both" || direction === "rtl") watchers.push(watchPausable(right, (newValue) => {
		watchers.forEach((w) => w.pause());
		left.value = transformRTL(newValue);
		watchers.forEach((w) => w.resume());
	}, {
		flush,
		deep,
		immediate
	}));
	const stop = () => {
		watchers.forEach((w) => w.stop());
	};
	return stop;
}
//#endregion
//#region syncRefs/index.ts
/**
* Keep target ref(s) in sync with the source ref
*
* @param source source ref
* @param targets
*/
function syncRefs(source, targets, options = {}) {
	const { flush = "sync", deep = false, immediate = true } = options;
	const targetsArray = toArray(targets);
	return watch(source, (newValue) => targetsArray.forEach((target) => target.value = newValue), {
		flush,
		deep,
		immediate
	});
}
//#endregion
//#region toRefs/index.ts
/**
* Extended `toRefs` that also accepts refs of an object.
*
* @see https://vueuse.org/toRefs
* @param objectRef A ref or normal object or array.
* @param options Options
*/
function toRefs(objectRef, options = {}) {
	if (!isRef(objectRef)) return toRefs$1(objectRef);
	const result = Array.isArray(objectRef.value) ? Array.from({ length: objectRef.value.length }) : {};
	for (const key in objectRef.value) result[key] = customRef(() => ({
		get() {
			return objectRef.value[key];
		},
		set(v) {
			var _toValue;
			if ((_toValue = toValue(options.replaceRef)) !== null && _toValue !== void 0 ? _toValue : true) if (Array.isArray(objectRef.value)) {
				const copy = [...objectRef.value];
				copy[key] = v;
				objectRef.value = copy;
			} else {
				const newObject = {
					...objectRef.value,
					[key]: v
				};
				Object.setPrototypeOf(newObject, Object.getPrototypeOf(objectRef.value));
				objectRef.value = newObject;
			}
			else objectRef.value[key] = v;
		}
	}));
	return result;
}
//#endregion
//#region tryOnBeforeMount/index.ts
/**
* Call onBeforeMount() if it's inside a component lifecycle, if not, just call the function
*
* @param fn
* @param sync if set to false, it will run in the nextTick() of Vue
* @param target
*/
function tryOnBeforeMount(fn, sync = true, target) {
	if (getLifeCycleTarget(target)) onBeforeMount(fn, target);
	else if (sync) fn();
	else nextTick(fn);
}
//#endregion
//#region tryOnBeforeUnmount/index.ts
/**
* Call onBeforeUnmount() if it's inside a component lifecycle, if not, do nothing
*
* @param fn
* @param target
*/
function tryOnBeforeUnmount(fn, target) {
	if (getLifeCycleTarget(target)) onBeforeUnmount(fn, target);
}
//#endregion
//#region tryOnMounted/index.ts
/**
* Call onMounted() if it's inside a component lifecycle, if not, just call the function
*
* @param fn
* @param sync if set to false, it will run in the nextTick() of Vue
* @param target
*/
function tryOnMounted(fn, sync = true, target) {
	if (getLifeCycleTarget(target)) onMounted(fn, target);
	else if (sync) fn();
	else nextTick(fn);
}
//#endregion
//#region tryOnUnmounted/index.ts
/**
* Call onUnmounted() if it's inside a component lifecycle, if not, do nothing
*
* @param fn
* @param target
*/
function tryOnUnmounted(fn, target) {
	if (getLifeCycleTarget(target)) onUnmounted(fn, target);
}
//#endregion
//#region until/index.ts
function createUntil(r, isNot = false) {
	function toMatch(condition, { flush = "sync", deep = false, timeout, throwOnTimeout } = {}) {
		let stop = null;
		const promises = [new Promise((resolve) => {
			stop = watch(r, (v) => {
				if (condition(v) !== isNot) {
					if (stop) stop();
					else nextTick(() => stop === null || stop === void 0 ? void 0 : stop());
					resolve(v);
				}
			}, {
				flush,
				deep,
				immediate: true
			});
		})];
		if (timeout != null) promises.push(promiseTimeout(timeout, throwOnTimeout).then(() => toValue(r)).finally(() => stop === null || stop === void 0 ? void 0 : stop()));
		return Promise.race(promises);
	}
	function toBe(value, options) {
		if (!isRef(value)) return toMatch((v) => v === value, options);
		const { flush = "sync", deep = false, timeout, throwOnTimeout } = options !== null && options !== void 0 ? options : {};
		let stop = null;
		const promises = [new Promise((resolve) => {
			stop = watch([r, value], ([v1, v2]) => {
				if (isNot !== (v1 === v2)) {
					if (stop) stop();
					else nextTick(() => stop === null || stop === void 0 ? void 0 : stop());
					resolve(v1);
				}
			}, {
				flush,
				deep,
				immediate: true
			});
		})];
		if (timeout != null) promises.push(promiseTimeout(timeout, throwOnTimeout).then(() => toValue(r)).finally(() => {
			stop === null || stop === void 0 || stop();
			return toValue(r);
		}));
		return Promise.race(promises);
	}
	function toBeTruthy(options) {
		return toMatch((v) => Boolean(v), options);
	}
	function toBeNull(options) {
		return toBe(null, options);
	}
	function toBeUndefined(options) {
		return toBe(void 0, options);
	}
	function toBeNaN(options) {
		return toMatch(Number.isNaN, options);
	}
	function toContains(value, options) {
		return toMatch((v) => {
			const array = Array.from(v);
			return array.includes(value) || array.includes(toValue(value));
		}, options);
	}
	function changed(options) {
		return changedTimes(1, options);
	}
	function changedTimes(n = 1, options) {
		let count = -1;
		return toMatch(() => {
			count += 1;
			return count >= n;
		}, options);
	}
	if (Array.isArray(toValue(r))) return {
		toMatch,
		toContains,
		changed,
		changedTimes,
		get not() {
			return createUntil(r, !isNot);
		}
	};
	else return {
		toMatch,
		toBe,
		toBeTruthy,
		toBeNull,
		toBeNaN,
		toBeUndefined,
		changed,
		changedTimes,
		get not() {
			return createUntil(r, !isNot);
		}
	};
}
function until(r) {
	return createUntil(r);
}
//#endregion
//#region useArrayDifference/index.ts
function defaultComparator(value, othVal) {
	return value === othVal;
}
/**
* Reactive get array difference of two array
* @see https://vueuse.org/useArrayDifference
* @returns - the difference of two array
* @param args
*
* @__NO_SIDE_EFFECTS__
*/
function useArrayDifference(...args) {
	var _args$, _args$2;
	const list = args[0];
	const values = args[1];
	let compareFn = (_args$ = args[2]) !== null && _args$ !== void 0 ? _args$ : defaultComparator;
	const { symmetric = false } = (_args$2 = args[3]) !== null && _args$2 !== void 0 ? _args$2 : {};
	if (typeof compareFn === "string") {
		const key = compareFn;
		compareFn = (value, othVal) => value[key] === othVal[key];
	}
	const diff1 = computed(() => toValue(list).filter((x) => toValue(values).findIndex((y) => compareFn(x, y)) === -1));
	if (symmetric) {
		const diff2 = computed(() => toValue(values).filter((x) => toValue(list).findIndex((y) => compareFn(x, y)) === -1));
		return computed(() => symmetric ? [...toValue(diff1), ...toValue(diff2)] : toValue(diff1));
	} else return diff1;
}
//#endregion
//#region useArrayEvery/index.ts
/**
* Reactive `Array.every`
*
* @see https://vueuse.org/useArrayEvery
* @param list - the array was called upon.
* @param fn - a function to test each element.
*
* @returns **true** if the `fn` function returns a **truthy** value for every element from the array. Otherwise, **false**.
*
* @__NO_SIDE_EFFECTS__
*/
function useArrayEvery(list, fn) {
	return computed(() => toValue(list).every((element, index, array) => fn(toValue(element), index, array)));
}
//#endregion
//#region useArrayFilter/index.ts
/**
* Reactive `Array.filter`
*
* @see https://vueuse.org/useArrayFilter
* @param list - the array was called upon.
* @param fn - a function that is called for every element of the given `list`. Each time `fn` executes, the returned value is added to the new array.
*
* @returns a shallow copy of a portion of the given array, filtered down to just the elements from the given array that pass the test implemented by the provided function. If no elements pass the test, an empty array will be returned.
*
* @__NO_SIDE_EFFECTS__
*/
function useArrayFilter(list, fn) {
	return computed(() => toValue(list).map((i) => toValue(i)).filter(fn));
}
//#endregion
//#region useArrayFind/index.ts
/**
* Reactive `Array.find`
*
* @see https://vueuse.org/useArrayFind
* @param list - the array was called upon.
* @param fn - a function to test each element.
*
* @returns the first element in the array that satisfies the provided testing function. Otherwise, undefined is returned.
*
* @__NO_SIDE_EFFECTS__
*/
function useArrayFind(list, fn) {
	return computed(() => toValue(toValue(list).find((element, index, array) => fn(toValue(element), index, array))));
}
//#endregion
//#region useArrayFindIndex/index.ts
/**
* Reactive `Array.findIndex`
*
* @see https://vueuse.org/useArrayFindIndex
* @param list - the array was called upon.
* @param fn - a function to test each element.
*
* @returns the index of the first element in the array that passes the test. Otherwise, "-1".
*
* @__NO_SIDE_EFFECTS__
*/
function useArrayFindIndex(list, fn) {
	return computed(() => toValue(list).findIndex((element, index, array) => fn(toValue(element), index, array)));
}
//#endregion
//#region useArrayFindLast/index.ts
function findLast(arr, cb) {
	let index = arr.length;
	while (index-- > 0) if (cb(arr[index], index, arr)) return arr[index];
}
/**
* Reactive `Array.findLast`
*
* @see https://vueuse.org/useArrayFindLast
* @param list - the array was called upon.
* @param fn - a function to test each element.
*
* @returns the last element in the array that satisfies the provided testing function. Otherwise, undefined is returned.
*
* @__NO_SIDE_EFFECTS__
*/
function useArrayFindLast(list, fn) {
	return computed(() => toValue(!Array.prototype.findLast ? findLast(toValue(list), (element, index, array) => fn(toValue(element), index, array)) : toValue(list).findLast((element, index, array) => fn(toValue(element), index, array))));
}
//#endregion
//#region useArrayIncludes/index.ts
function isArrayIncludesOptions(obj) {
	return isObject(obj) && containsProp(obj, "formIndex", "comparator");
}
/**
* Reactive `Array.includes`
*
* @see https://vueuse.org/useArrayIncludes
*
* @returns true if the `value` is found in the array. Otherwise, false.
*
* @__NO_SIDE_EFFECTS__
*/
function useArrayIncludes(...args) {
	var _comparator;
	const list = args[0];
	const value = args[1];
	let comparator = args[2];
	let formIndex = 0;
	if (isArrayIncludesOptions(comparator)) {
		var _comparator$fromIndex;
		formIndex = (_comparator$fromIndex = comparator.fromIndex) !== null && _comparator$fromIndex !== void 0 ? _comparator$fromIndex : 0;
		comparator = comparator.comparator;
	}
	if (typeof comparator === "string") {
		const key = comparator;
		comparator = (element, value) => element[key] === toValue(value);
	}
	comparator = (_comparator = comparator) !== null && _comparator !== void 0 ? _comparator : ((element, value) => element === toValue(value));
	return computed(() => toValue(list).slice(formIndex).some((element, index, array) => comparator(toValue(element), toValue(value), index, toValue(array))));
}
//#endregion
//#region useArrayJoin/index.ts
/**
* Reactive `Array.join`
*
* @see https://vueuse.org/useArrayJoin
* @param list - the array was called upon.
* @param separator - a string to separate each pair of adjacent elements of the array. If omitted, the array elements are separated with a comma (",").
*
* @returns a string with all array elements joined. If arr.length is 0, the empty string is returned.
*
* @__NO_SIDE_EFFECTS__
*/
function useArrayJoin(list, separator) {
	return computed(() => toValue(list).map((i) => toValue(i)).join(toValue(separator)));
}
//#endregion
//#region useArrayMap/index.ts
/**
* Reactive `Array.map`
*
* @see https://vueuse.org/useArrayMap
* @param list - the array was called upon.
* @param fn - a function that is called for every element of the given `list`. Each time `fn` executes, the returned value is added to the new array.
*
* @returns a new array with each element being the result of the callback function.
*
* @__NO_SIDE_EFFECTS__
*/
function useArrayMap(list, fn) {
	return computed(() => toValue(list).map((i) => toValue(i)).map(fn));
}
//#endregion
//#region useArrayReduce/index.ts
/**
* Reactive `Array.reduce`
*
* @see https://vueuse.org/useArrayReduce
* @param list - the array was called upon.
* @param reducer - a "reducer" function.
* @param args
*
* @returns the value that results from running the "reducer" callback function to completion over the entire array.
*
* @__NO_SIDE_EFFECTS__
*/
function useArrayReduce(list, reducer, ...args) {
	const reduceCallback = (sum, value, index) => reducer(toValue(sum), toValue(value), index);
	return computed(() => {
		const resolved = toValue(list);
		return args.length ? resolved.reduce(reduceCallback, typeof args[0] === "function" ? toValue(args[0]()) : toValue(args[0])) : resolved.reduce(reduceCallback);
	});
}
//#endregion
//#region useArraySome/index.ts
/**
* Reactive `Array.some`
*
* @see https://vueuse.org/useArraySome
* @param list - the array was called upon.
* @param fn - a function to test each element.
*
* @returns **true** if the `fn` function returns a **truthy** value for any element from the array. Otherwise, **false**.
*
* @__NO_SIDE_EFFECTS__
*/
function useArraySome(list, fn) {
	return computed(() => toValue(list).some((element, index, array) => fn(toValue(element), index, array)));
}
//#endregion
//#region useArrayUnique/index.ts
function uniq(array) {
	return Array.from(new Set(array));
}
function uniqueElementsBy(array, fn) {
	return array.reduce((acc, v) => {
		if (!acc.some((x) => fn(v, x, array))) acc.push(v);
		return acc;
	}, []);
}
/**
* reactive unique array
* @see https://vueuse.org/useArrayUnique
* @param list - the array was called upon.
* @param compareFn
* @returns A computed ref that returns a unique array of items.
*
* @__NO_SIDE_EFFECTS__
*/
function useArrayUnique(list, compareFn) {
	return computed(() => {
		const resolvedList = toValue(list).map((element) => toValue(element));
		return compareFn ? uniqueElementsBy(resolvedList, compareFn) : uniq(resolvedList);
	});
}
//#endregion
//#region useCounter/index.ts
/**
* Basic counter with utility functions.
*
* @see https://vueuse.org/useCounter
* @param [initialValue]
* @param options
*/
function useCounter(initialValue = 0, options = {}) {
	let _initialValue = unref(initialValue);
	const count = shallowRef(initialValue);
	const { max = Number.POSITIVE_INFINITY, min = Number.NEGATIVE_INFINITY } = options;
	const inc = (delta = 1) => count.value = Math.max(Math.min(max, count.value + delta), min);
	const dec = (delta = 1) => count.value = Math.min(Math.max(min, count.value - delta), max);
	const get = () => count.value;
	const set = (val) => count.value = Math.max(min, Math.min(max, val));
	const reset = (val = _initialValue) => {
		_initialValue = val;
		return set(val);
	};
	return {
		count: shallowReadonly(count),
		inc,
		dec,
		get,
		set,
		reset
	};
}
//#endregion
//#region useDateFormat/index.ts
const REGEX_PARSE = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[T\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/i;
const REGEX_FORMAT = /[YMDHhms]o|\[([^\]]+)\]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a{1,2}|A{1,2}|m{1,2}|s{1,2}|Z{1,2}|z{1,4}|SSS/g;
function defaultMeridiem(hours, minutes, isLowercase, hasPeriod) {
	let m = hours < 12 ? "AM" : "PM";
	if (hasPeriod) m = m.split("").reduce((acc, curr) => acc += `${curr}.`, "");
	return isLowercase ? m.toLowerCase() : m;
}
function formatOrdinal(num) {
	const suffixes = [
		"th",
		"st",
		"nd",
		"rd"
	];
	const v = num % 100;
	return num + (suffixes[(v - 20) % 10] || suffixes[v] || suffixes[0]);
}
function formatDate(date, formatStr, options = {}) {
	var _options$customMeridi;
	const years = date.getFullYear();
	const month = date.getMonth();
	const days = date.getDate();
	const hours = date.getHours();
	const minutes = date.getMinutes();
	const seconds = date.getSeconds();
	const milliseconds = date.getMilliseconds();
	const day = date.getDay();
	const meridiem = (_options$customMeridi = options.customMeridiem) !== null && _options$customMeridi !== void 0 ? _options$customMeridi : defaultMeridiem;
	const stripTimeZone = (dateString) => {
		var _dateString$split$;
		return (_dateString$split$ = dateString.split(" ")[1]) !== null && _dateString$split$ !== void 0 ? _dateString$split$ : "";
	};
	const matches = {
		Yo: () => formatOrdinal(years),
		YY: () => String(years).slice(-2),
		YYYY: () => years,
		M: () => month + 1,
		Mo: () => formatOrdinal(month + 1),
		MM: () => `${month + 1}`.padStart(2, "0"),
		MMM: () => date.toLocaleDateString(toValue(options.locales), { month: "short" }),
		MMMM: () => date.toLocaleDateString(toValue(options.locales), { month: "long" }),
		D: () => String(days),
		Do: () => formatOrdinal(days),
		DD: () => `${days}`.padStart(2, "0"),
		H: () => String(hours),
		Ho: () => formatOrdinal(hours),
		HH: () => `${hours}`.padStart(2, "0"),
		h: () => `${hours % 12 || 12}`.padStart(1, "0"),
		ho: () => formatOrdinal(hours % 12 || 12),
		hh: () => `${hours % 12 || 12}`.padStart(2, "0"),
		m: () => String(minutes),
		mo: () => formatOrdinal(minutes),
		mm: () => `${minutes}`.padStart(2, "0"),
		s: () => String(seconds),
		so: () => formatOrdinal(seconds),
		ss: () => `${seconds}`.padStart(2, "0"),
		SSS: () => `${milliseconds}`.padStart(3, "0"),
		d: () => day,
		dd: () => date.toLocaleDateString(toValue(options.locales), { weekday: "narrow" }),
		ddd: () => date.toLocaleDateString(toValue(options.locales), { weekday: "short" }),
		dddd: () => date.toLocaleDateString(toValue(options.locales), { weekday: "long" }),
		A: () => meridiem(hours, minutes),
		AA: () => meridiem(hours, minutes, false, true),
		a: () => meridiem(hours, minutes, true),
		aa: () => meridiem(hours, minutes, true, true),
		z: () => stripTimeZone(date.toLocaleDateString(toValue(options.locales), { timeZoneName: "shortOffset" })),
		zz: () => stripTimeZone(date.toLocaleDateString(toValue(options.locales), { timeZoneName: "shortOffset" })),
		zzz: () => stripTimeZone(date.toLocaleDateString(toValue(options.locales), { timeZoneName: "shortOffset" })),
		zzzz: () => stripTimeZone(date.toLocaleDateString(toValue(options.locales), { timeZoneName: "longOffset" }))
	};
	return formatStr.replace(REGEX_FORMAT, (match, $1) => {
		var _ref, _matches$match;
		return (_ref = $1 !== null && $1 !== void 0 ? $1 : (_matches$match = matches[match]) === null || _matches$match === void 0 ? void 0 : _matches$match.call(matches)) !== null && _ref !== void 0 ? _ref : match;
	});
}
function normalizeDate(date) {
	if (date === null) return /* @__PURE__ */ new Date(NaN);
	if (date === void 0) return /* @__PURE__ */ new Date();
	if (date instanceof Date) return new Date(date);
	if (typeof date === "string" && !/Z$/i.test(date)) {
		const d = date.match(REGEX_PARSE);
		if (d) {
			const m = d[2] - 1 || 0;
			const ms = (d[7] || "0").substring(0, 3);
			return new Date(d[1], m, d[3] || 1, d[4] || 0, d[5] || 0, d[6] || 0, ms);
		}
	}
	return new Date(date);
}
/**
* Get the formatted date according to the string of tokens passed in.
*
* @see https://vueuse.org/useDateFormat
* @param date - The date to format, can either be a `Date` object, a timestamp, or a string
* @param formatStr - The combination of tokens to format the date
* @param options - UseDateFormatOptions
*
* @__NO_SIDE_EFFECTS__
*/
function useDateFormat(date, formatStr = "HH:mm:ss", options = {}) {
	return computed(() => formatDate(normalizeDate(toValue(date)), toValue(formatStr), options));
}
//#endregion
//#region useIntervalFn/index.ts
/**
* Wrapper for `setInterval` with controls
*
* @see https://vueuse.org/useIntervalFn
* @param cb
* @param interval
* @param options
*/
function useIntervalFn(cb, interval = 1e3, options = {}) {
	const { immediate = true, immediateCallback = false } = options;
	let timer = null;
	const isActive = shallowRef(false);
	function clean() {
		if (timer) {
			clearInterval(timer);
			timer = null;
		}
	}
	function pause() {
		isActive.value = false;
		clean();
	}
	function resume() {
		const intervalValue = toValue(interval);
		if (intervalValue <= 0) return;
		isActive.value = true;
		if (immediateCallback) cb();
		clean();
		if (isActive.value) timer = setInterval(cb, intervalValue);
	}
	if (immediate && isClient) resume();
	if (isRef(interval) || typeof interval === "function") tryOnScopeDispose(watch(interval, () => {
		if (isActive.value && isClient) resume();
	}));
	tryOnScopeDispose(pause);
	return {
		isActive: shallowReadonly(isActive),
		pause,
		resume
	};
}
//#endregion
//#region useInterval/index.ts
function useInterval(interval = 1e3, options = {}) {
	const { controls: exposeControls = false, immediate = true, callback } = options;
	const counter = shallowRef(0);
	const update = () => counter.value += 1;
	const reset = () => {
		counter.value = 0;
	};
	const controls = useIntervalFn(callback ? () => {
		update();
		callback(counter.value);
	} : update, interval, { immediate });
	if (exposeControls) return {
		counter: shallowReadonly(counter),
		reset,
		...controls
	};
	else return shallowReadonly(counter);
}
//#endregion
//#region useLastChanged/index.ts
function useLastChanged(source, options = {}) {
	var _options$initialValue;
	const ms = shallowRef((_options$initialValue = options.initialValue) !== null && _options$initialValue !== void 0 ? _options$initialValue : null);
	watch(source, () => ms.value = timestamp(), options);
	return shallowReadonly(ms);
}
//#endregion
//#region useTimeoutFn/index.ts
/**
* Wrapper for `setTimeout` with controls.
*
* @param cb
* @param interval
* @param options
*/
function useTimeoutFn(cb, interval, options = {}) {
	const { immediate = true, immediateCallback = false } = options;
	const isPending = shallowRef(false);
	let timer;
	function clear() {
		if (timer) {
			clearTimeout(timer);
			timer = void 0;
		}
	}
	function stop() {
		isPending.value = false;
		clear();
	}
	function start(...args) {
		if (immediateCallback) cb();
		clear();
		isPending.value = true;
		timer = setTimeout(() => {
			isPending.value = false;
			timer = void 0;
			cb(...args);
		}, toValue(interval));
	}
	if (immediate) {
		isPending.value = true;
		if (isClient) start();
	}
	tryOnScopeDispose(stop);
	return {
		isPending: shallowReadonly(isPending),
		start,
		stop
	};
}
//#endregion
//#region useTimeout/index.ts
function useTimeout(interval = 1e3, options = {}) {
	const { controls: exposeControls = false, callback } = options;
	const controls = useTimeoutFn(callback !== null && callback !== void 0 ? callback : noop, interval, options);
	const ready = computed(() => !controls.isPending.value);
	if (exposeControls) return {
		ready,
		...controls
	};
	else return ready;
}
//#endregion
//#region useToNumber/index.ts
/**
* Reactively convert a string ref to number.
*
* @__NO_SIDE_EFFECTS__
*/
function useToNumber(value, options = {}) {
	const { method = "parseFloat", radix, nanToZero } = options;
	return computed(() => {
		let resolved = toValue(value);
		if (typeof method === "function") resolved = method(resolved);
		else if (typeof resolved === "string") resolved = Number[method](resolved, radix);
		if (nanToZero && Number.isNaN(resolved)) resolved = 0;
		return resolved;
	});
}
//#endregion
//#region useToString/index.ts
/**
* Reactively convert a ref to string.
*
* @see https://vueuse.org/useToString
*
* @__NO_SIDE_EFFECTS__
*/
function useToString(value) {
	return computed(() => `${toValue(value)}`);
}
//#endregion
//#region useToggle/index.ts
/**
* A boolean ref with a toggler
*
* @see https://vueuse.org/useToggle
* @param [initialValue]
* @param options
*
* @__NO_SIDE_EFFECTS__
*/
function useToggle(initialValue = false, options = {}) {
	const { truthyValue = true, falsyValue = false } = options;
	const valueIsRef = isRef(initialValue);
	const _value = shallowRef(initialValue);
	function toggle(value) {
		if (arguments.length) {
			_value.value = value;
			return _value.value;
		} else {
			const truthy = toValue(truthyValue);
			_value.value = _value.value === truthy ? toValue(falsyValue) : truthy;
			return _value.value;
		}
	}
	if (valueIsRef) return toggle;
	else return [_value, toggle];
}
//#endregion
//#region watchArray/index.ts
/**
* Watch for an array with additions and removals.
*
* @see https://vueuse.org/watchArray
*/
function watchArray(source, cb, options) {
	let oldList = (options === null || options === void 0 ? void 0 : options.immediate) ? [] : [...typeof source === "function" ? source() : Array.isArray(source) ? source : toValue(source)];
	return watch(source, (newList, _, onCleanup) => {
		const oldListRemains = Array.from({ length: oldList.length });
		const added = [];
		for (const obj of newList) {
			let found = false;
			for (let i = 0; i < oldList.length; i++) if (!oldListRemains[i] && obj === oldList[i]) {
				oldListRemains[i] = true;
				found = true;
				break;
			}
			if (!found) added.push(obj);
		}
		const removed = oldList.filter((_, i) => !oldListRemains[i]);
		cb(newList, oldList, added, removed, onCleanup);
		oldList = [...newList];
	}, options);
}
//#endregion
//#region watchAtMost/index.ts
function watchAtMost(source, cb, options) {
	const { count, ...watchOptions } = options;
	const current = shallowRef(0);
	const { stop, resume, pause } = watchWithFilter(source, (...args) => {
		current.value += 1;
		if (current.value >= toValue(count)) nextTick(() => stop());
		cb(...args);
	}, watchOptions);
	return {
		count: current,
		stop,
		resume,
		pause
	};
}
//#endregion
//#region watchDebounced/index.ts
function watchDebounced(source, cb, options = {}) {
	const { debounce = 0, maxWait = void 0, ...watchOptions } = options;
	return watchWithFilter(source, cb, {
		...watchOptions,
		eventFilter: debounceFilter(debounce, { maxWait })
	});
}
/** @deprecated use `watchDebounced` instead */
const debouncedWatch = watchDebounced;
//#endregion
//#region watchDeep/index.ts
/**
* Shorthand for watching value with {deep: true}
*
* @see https://vueuse.org/watchDeep
*/
function watchDeep(source, cb, options) {
	return watch(source, cb, {
		...options,
		deep: true
	});
}
//#endregion
//#region watchIgnorable/index.ts
function watchIgnorable(source, cb, options = {}) {
	const { eventFilter = bypassFilter, ...watchOptions } = options;
	const filteredCb = createFilterWrapper(eventFilter, cb);
	let ignoreUpdates;
	let ignorePrevAsyncUpdates;
	let stop;
	if (watchOptions.flush === "sync") {
		let ignore = false;
		ignorePrevAsyncUpdates = () => {};
		ignoreUpdates = (updater) => {
			ignore = true;
			updater();
			ignore = false;
		};
		stop = watch(source, (...args) => {
			if (!ignore) filteredCb(...args);
		}, watchOptions);
	} else {
		const disposables = [];
		let ignoreCounter = 0;
		let syncCounter = 0;
		ignorePrevAsyncUpdates = () => {
			ignoreCounter = syncCounter;
		};
		disposables.push(watch(source, () => {
			syncCounter++;
		}, {
			...watchOptions,
			flush: "sync"
		}));
		ignoreUpdates = (updater) => {
			const syncCounterPrev = syncCounter;
			updater();
			ignoreCounter += syncCounter - syncCounterPrev;
		};
		disposables.push(watch(source, (...args) => {
			const ignore = ignoreCounter > 0 && ignoreCounter === syncCounter;
			ignoreCounter = 0;
			syncCounter = 0;
			if (ignore) return;
			filteredCb(...args);
		}, watchOptions));
		stop = () => {
			disposables.forEach((fn) => fn());
		};
	}
	return {
		stop,
		ignoreUpdates,
		ignorePrevAsyncUpdates
	};
}
/** @deprecated use `watchIgnorable` instead */
const ignorableWatch = watchIgnorable;
//#endregion
//#region watchImmediate/index.ts
/**
* Shorthand for watching value with {immediate: true}
*
* @see https://vueuse.org/watchImmediate
*/
function watchImmediate(source, cb, options) {
	return watch(source, cb, {
		...options,
		immediate: true
	});
}
//#endregion
//#region watchOnce/index.ts
/**
* Shorthand for watching value with { once: true }
*
* @see https://vueuse.org/watchOnce
*/
function watchOnce(source, cb, options) {
	return watch(source, cb, {
		...options,
		once: true
	});
}
//#endregion
//#region watchThrottled/index.ts
function watchThrottled(source, cb, options = {}) {
	const { throttle = 0, trailing = true, leading = true, ...watchOptions } = options;
	return watchWithFilter(source, cb, {
		...watchOptions,
		eventFilter: throttleFilter(throttle, trailing, leading)
	});
}
/** @deprecated use `watchThrottled` instead */
const throttledWatch = watchThrottled;
//#endregion
//#region watchTriggerable/index.ts
function watchTriggerable(source, cb, options = {}) {
	let cleanupFn;
	function onEffect() {
		if (!cleanupFn) return;
		const fn = cleanupFn;
		cleanupFn = void 0;
		fn();
	}
	/** Register the function `cleanupFn` */
	function onCleanup(callback) {
		cleanupFn = callback;
	}
	const _cb = (value, oldValue) => {
		onEffect();
		return cb(value, oldValue, onCleanup);
	};
	const res = watchIgnorable(source, _cb, options);
	const { ignoreUpdates } = res;
	const trigger = () => {
		let res;
		ignoreUpdates(() => {
			res = _cb(getWatchSources(source), getOldValue(source));
		});
		return res;
	};
	return {
		...res,
		trigger
	};
}
function getWatchSources(sources) {
	if (isReactive(sources)) return sources;
	if (Array.isArray(sources)) return sources.map((item) => toValue(item));
	return toValue(sources);
}
function getOldValue(source) {
	return Array.isArray(source) ? source.map(() => void 0) : void 0;
}
//#endregion
//#region whenever/index.ts
function whenever(source, cb, options) {
	const stop = watch(source, (v, ov, onInvalidate) => {
		if (v) {
			if (options === null || options === void 0 ? void 0 : options.once) nextTick(() => stop());
			cb(v, ov, onInvalidate);
		}
	}, {
		...options,
		once: false
	});
	return stop;
}
//#endregion
export { assert, autoResetRef, bypassFilter, camelize, clamp, computedEager, computedWithControl, containsProp, controlledComputed, controlledRef, createDisposableDirective, createEventHook, createFilterWrapper, createGlobalState, createInjectionState, createReactiveFn, createRef, createSharedComposable, createSingletonPromise, debounceFilter, debouncedRef, debouncedWatch, eagerComputed, extendRef, formatDate, get, getLifeCycleTarget, hasOwn, hyphenate, identity, ignorableWatch, increaseWithUnit, injectLocal, invoke, isClient, isDef, isDefined, isIOS, isObject, isWorker, makeDestructurable, noop, normalizeDate, notNullish, now, objectEntries, objectOmit, objectPick, pausableFilter, pausableWatch, promiseTimeout, provideLocal, pxValue, rand, reactify, reactifyObject, reactiveComputed, reactiveOmit, reactivePick, refAutoReset, refDebounced, refDefault, refManualReset, refThrottled, refWithControl, set, syncRef, syncRefs, throttleFilter, throttledRef, throttledWatch, timestamp, toArray, toReactive, toRef, toRefs, tryOnBeforeMount, tryOnBeforeUnmount, tryOnMounted, tryOnScopeDispose, tryOnUnmounted, until, useArrayDifference, useArrayEvery, useArrayFilter, useArrayFind, useArrayFindIndex, useArrayFindLast, useArrayIncludes, useArrayJoin, useArrayMap, useArrayReduce, useArraySome, useArrayUnique, useCounter, useDateFormat, useDebounce, useDebounceFn, useInterval, useIntervalFn, useLastChanged, useThrottle, useThrottleFn, useTimeout, useTimeoutFn, useToNumber, useToString, useToggle, watchArray, watchAtMost, watchDebounced, watchDeep, watchIgnorable, watchImmediate, watchOnce, watchPausable, watchThrottled, watchTriggerable, watchWithFilter, whenever };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzP3Y9N2U3M2FmYzIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY29tcHV0ZWQsIGN1c3RvbVJlZiwgZWZmZWN0U2NvcGUsIGdldEN1cnJlbnRJbnN0YW5jZSwgZ2V0Q3VycmVudFNjb3BlLCBoYXNJbmplY3Rpb25Db250ZXh0LCBpbmplY3QsIGlzUmVhY3RpdmUsIGlzUmVmLCBuZXh0VGljaywgb25CZWZvcmVNb3VudCwgb25CZWZvcmVVbm1vdW50LCBvbk1vdW50ZWQsIG9uU2NvcGVEaXNwb3NlLCBvblVubW91bnRlZCwgcHJvdmlkZSwgcmVhY3RpdmUsIHJlYWRvbmx5LCByZWYsIHNoYWxsb3dSZWFkb25seSwgc2hhbGxvd1JlZiwgdG9SZWYgYXMgdG9SZWYkMSwgdG9SZWZzIGFzIHRvUmVmcyQxLCB0b1ZhbHVlLCB1bnJlZiwgd2F0Y2gsIHdhdGNoRWZmZWN0IH0gZnJvbSBcIi9fbnV4dC9AZnMvVm9sdW1lcy9Db2RpbmcvUHJvamVjdHMvV2Vic2l0ZXMvaW5laWFoL2Zyb250ZW5kL25vZGVfbW9kdWxlcy8ucG5wbS92dWVAMy41LjQwX3R5cGVzY3JpcHRANi4wLjMvbm9kZV9tb2R1bGVzL3Z1ZS9kaXN0L3Z1ZS5ydW50aW1lLmVzbS1idW5kbGVyLmpzP3Y9N2U3M2FmYzJcIjtcbi8vI3JlZ2lvbiBjb21wdXRlZEVhZ2VyL2luZGV4LnRzXG4vKipcbipcbiogQGRlcHJlY2F0ZWQgVGhpcyBmdW5jdGlvbiB3aWxsIGJlIHJlbW92ZWQgaW4gZnV0dXJlIHZlcnNpb24uXG4qXG4qIE5vdGU6IElmIHlvdSBhcmUgdXNpbmcgVnVlIDMuNCssIHlvdSBjYW4gc3RyYWlnaHQgdXNlIGNvbXB1dGVkIGluc3RlYWQuXG4qIEJlY2F1c2UgaW4gVnVlIDMuNCssIGlmIGNvbXB1dGVkIG5ldyB2YWx1ZSBkb2VzIG5vdCBjaGFuZ2UsXG4qIGNvbXB1dGVkLCBlZmZlY3QsIHdhdGNoLCB3YXRjaEVmZmVjdCwgcmVuZGVyIGRlcGVuZGVuY2llcyB3aWxsIG5vdCBiZSB0cmlnZ2VyZWQuXG4qIHJlZmVyOiBodHRwczovL2dpdGh1Yi5jb20vdnVlanMvY29yZS9wdWxsLzU5MTJcbipcbiogQHBhcmFtIGZuIGVmZmVjdCBmdW5jdGlvblxuKiBAcGFyYW0gb3B0aW9ucyBXYXRjaE9wdGlvbnNCYXNlXG4qIEByZXR1cm5zIHJlYWRvbmx5IHNoYWxsb3dSZWZcbiovXG5mdW5jdGlvbiBjb21wdXRlZEVhZ2VyKGZuLCBvcHRpb25zKSB7XG5cdHZhciBfb3B0aW9ucyRmbHVzaDtcblx0Y29uc3QgcmVzdWx0ID0gc2hhbGxvd1JlZigpO1xuXHR3YXRjaEVmZmVjdCgoKSA9PiB7XG5cdFx0cmVzdWx0LnZhbHVlID0gZm4oKTtcblx0fSwge1xuXHRcdC4uLm9wdGlvbnMsXG5cdFx0Zmx1c2g6IChfb3B0aW9ucyRmbHVzaCA9IG9wdGlvbnMgPT09IG51bGwgfHwgb3B0aW9ucyA9PT0gdm9pZCAwID8gdm9pZCAwIDogb3B0aW9ucy5mbHVzaCkgIT09IG51bGwgJiYgX29wdGlvbnMkZmx1c2ggIT09IHZvaWQgMCA/IF9vcHRpb25zJGZsdXNoIDogXCJzeW5jXCJcblx0fSk7XG5cdHJldHVybiByZWFkb25seShyZXN1bHQpO1xufVxuLyoqIEBkZXByZWNhdGVkIHVzZSBgY29tcHV0ZWRFYWdlcmAgaW5zdGVhZCAqL1xuY29uc3QgZWFnZXJDb21wdXRlZCA9IGNvbXB1dGVkRWFnZXI7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBjb21wdXRlZFdpdGhDb250cm9sL2luZGV4LnRzXG4vKipcbiogRXhwbGljaXRseSBkZWZpbmUgdGhlIGRlcHMgb2YgY29tcHV0ZWQuXG4qXG4qIEBwYXJhbSBzb3VyY2VcbiogQHBhcmFtIGZuXG4qL1xuZnVuY3Rpb24gY29tcHV0ZWRXaXRoQ29udHJvbChzb3VyY2UsIGZuLCBvcHRpb25zID0ge30pIHtcblx0bGV0IHYgPSB2b2lkIDA7XG5cdGxldCB0cmFjaztcblx0bGV0IHRyaWdnZXI7XG5cdGxldCBkaXJ0eSA9IHRydWU7XG5cdGNvbnN0IHVwZGF0ZSA9ICgpID0+IHtcblx0XHRkaXJ0eSA9IHRydWU7XG5cdFx0dHJpZ2dlcigpO1xuXHR9O1xuXHR3YXRjaChzb3VyY2UsIHVwZGF0ZSwge1xuXHRcdGZsdXNoOiBcInN5bmNcIixcblx0XHQuLi5vcHRpb25zXG5cdH0pO1xuXHRjb25zdCBnZXQgPSB0eXBlb2YgZm4gPT09IFwiZnVuY3Rpb25cIiA/IGZuIDogZm4uZ2V0O1xuXHRjb25zdCBzZXQgPSB0eXBlb2YgZm4gPT09IFwiZnVuY3Rpb25cIiA/IHZvaWQgMCA6IGZuLnNldDtcblx0Y29uc3QgcmVzdWx0ID0gY3VzdG9tUmVmKChfdHJhY2ssIF90cmlnZ2VyKSA9PiB7XG5cdFx0dHJhY2sgPSBfdHJhY2s7XG5cdFx0dHJpZ2dlciA9IF90cmlnZ2VyO1xuXHRcdHJldHVybiB7XG5cdFx0XHRnZXQoKSB7XG5cdFx0XHRcdGlmIChkaXJ0eSkge1xuXHRcdFx0XHRcdHYgPSBnZXQodik7XG5cdFx0XHRcdFx0ZGlydHkgPSBmYWxzZTtcblx0XHRcdFx0fVxuXHRcdFx0XHR0cmFjaygpO1xuXHRcdFx0XHRyZXR1cm4gdjtcblx0XHRcdH0sXG5cdFx0XHRzZXQodikge1xuXHRcdFx0XHRzZXQgPT09IG51bGwgfHwgc2V0ID09PSB2b2lkIDAgfHwgc2V0KHYpO1xuXHRcdFx0fVxuXHRcdH07XG5cdH0pO1xuXHRyZXN1bHQudHJpZ2dlciA9IHVwZGF0ZTtcblx0cmV0dXJuIHJlc3VsdDtcbn1cbi8qKiBAZGVwcmVjYXRlZCB1c2UgYGNvbXB1dGVkV2l0aENvbnRyb2xgIGluc3RlYWQgKi9cbmNvbnN0IGNvbnRyb2xsZWRDb21wdXRlZCA9IGNvbXB1dGVkV2l0aENvbnRyb2w7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBjcmVhdGVEaXNwb3NhYmxlRGlyZWN0aXZlL2luZGV4LnRzXG4vKipcbiogVXRpbGl0eSBmb3IgYXV0aG9yaW5nIGRpc3Bvc2FibGUgZGlyZWN0aXZlcy4gUmVhY3RpdmUgZWZmZWN0cyBjcmVhdGVkIHdpdGhpbiBgbW91bnRlZGAgZGlyZWN0aXZlIGhvb2sgd2lsbCBiZSB0cmFja2VkIGFuZCBhdXRvbWF0aWNhbGx5IGRpc3Bvc2VkIHdoZW4gZGlyZWN0aXZlIGlzIHVubW91bnRlZC5cbipcbiogQHNlZSBodHRwczovL3Z1ZXVzZS5vcmcvY3JlYXRlRGlzcG9zYWJsZURpcmVjdGl2ZVxuKlxuKiBAX19OT19TSURFX0VGRkVDVFNfX1xuKi9cbmZ1bmN0aW9uIGNyZWF0ZURpc3Bvc2FibGVEaXJlY3RpdmUob3JpZ2luID0ge30pIHtcblx0ZnVuY3Rpb24gaXNGdW5jKGZuKSB7XG5cdFx0cmV0dXJuIHR5cGVvZiBmbiA9PT0gXCJmdW5jdGlvblwiO1xuXHR9XG5cdGNvbnN0IG5vcm1hbGlzZWRPcmlnaW4gPSBpc0Z1bmMob3JpZ2luKSA/IHtcblx0XHRtb3VudGVkOiBvcmlnaW4sXG5cdFx0dXBkYXRlZDogb3JpZ2luXG5cdH0gOiBvcmlnaW47XG5cdGNvbnN0IHsgbW91bnRlZCwgdW5tb3VudGVkIH0gPSBub3JtYWxpc2VkT3JpZ2luO1xuXHRpZiAoIWlzRnVuYyhtb3VudGVkKSkgcmV0dXJuIG9yaWdpbjtcblx0Y29uc3Qgc2NvcGVXZWFrTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5cdHJldHVybiB7XG5cdFx0Li4ubm9ybWFsaXNlZE9yaWdpbixcblx0XHRtb3VudGVkKGVsLCBiaW5kaW5nLCB2Tm9kZSwgcHJldk5vZGUpIHtcblx0XHRcdHZhciBfc2NvcGVXZWFrTWFwJGdldDtcblx0XHRcdGNvbnN0IHNjb3BlID0gKF9zY29wZVdlYWtNYXAkZ2V0ID0gc2NvcGVXZWFrTWFwLmdldChlbCkpICE9PSBudWxsICYmIF9zY29wZVdlYWtNYXAkZ2V0ICE9PSB2b2lkIDAgPyBfc2NvcGVXZWFrTWFwJGdldCA6IGVmZmVjdFNjb3BlKCk7XG5cdFx0XHRzY29wZVdlYWtNYXAuc2V0KGVsLCBzY29wZSk7XG5cdFx0XHRzY29wZS5ydW4oKCkgPT4ge1xuXHRcdFx0XHRtb3VudGVkID09PSBudWxsIHx8IG1vdW50ZWQgPT09IHZvaWQgMCB8fCBtb3VudGVkKGVsLCBiaW5kaW5nLCB2Tm9kZSwgcHJldk5vZGUpO1xuXHRcdFx0fSk7XG5cdFx0fSxcblx0XHR1bm1vdW50ZWQoZWwsIGJpbmRpbmcsIHZOb2RlLCBwcmV2Tm9kZSkge1xuXHRcdFx0dmFyIF9zY29wZVdlYWtNYXAkZ2V0Mjtcblx0XHRcdChfc2NvcGVXZWFrTWFwJGdldDIgPSBzY29wZVdlYWtNYXAuZ2V0KGVsKSkgPT09IG51bGwgfHwgX3Njb3BlV2Vha01hcCRnZXQyID09PSB2b2lkIDAgfHwgX3Njb3BlV2Vha01hcCRnZXQyLnN0b3AoKTtcblx0XHRcdHNjb3BlV2Vha01hcC5kZWxldGUoZWwpO1xuXHRcdFx0aWYgKGlzRnVuYyh1bm1vdW50ZWQpKSB1bm1vdW50ZWQoZWwsIGJpbmRpbmcsIHZOb2RlLCBwcmV2Tm9kZSk7XG5cdFx0fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gdHJ5T25TY29wZURpc3Bvc2UvaW5kZXgudHNcbi8qKlxuKiBDYWxsIG9uU2NvcGVEaXNwb3NlKCkgaWYgaXQncyBpbnNpZGUgYW4gZWZmZWN0IHNjb3BlIGxpZmVjeWNsZSwgaWYgbm90LCBkbyBub3RoaW5nXG4qXG4qIEBwYXJhbSBmblxuKi9cbmZ1bmN0aW9uIHRyeU9uU2NvcGVEaXNwb3NlKGZuLCBmYWlsU2lsZW50bHkpIHtcblx0aWYgKGdldEN1cnJlbnRTY29wZSgpKSB7XG5cdFx0b25TY29wZURpc3Bvc2UoZm4sIGZhaWxTaWxlbnRseSk7XG5cdFx0cmV0dXJuIHRydWU7XG5cdH1cblx0cmV0dXJuIGZhbHNlO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gY3JlYXRlRXZlbnRIb29rL2luZGV4LnRzXG4vKipcbiogVXRpbGl0eSBmb3IgY3JlYXRpbmcgZXZlbnQgaG9va3NcbipcbiogQHNlZSBodHRwczovL3Z1ZXVzZS5vcmcvY3JlYXRlRXZlbnRIb29rXG4qXG4qIEBfX05PX1NJREVfRUZGRUNUU19fXG4qL1xuZnVuY3Rpb24gY3JlYXRlRXZlbnRIb29rKCkge1xuXHRjb25zdCBmbnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRjb25zdCBvZmYgPSAoZm4pID0+IHtcblx0XHRmbnMuZGVsZXRlKGZuKTtcblx0fTtcblx0Y29uc3QgY2xlYXIgPSAoKSA9PiB7XG5cdFx0Zm5zLmNsZWFyKCk7XG5cdH07XG5cdGNvbnN0IG9uID0gKGZuKSA9PiB7XG5cdFx0Zm5zLmFkZChmbik7XG5cdFx0Y29uc3Qgb2ZmRm4gPSAoKSA9PiBvZmYoZm4pO1xuXHRcdHRyeU9uU2NvcGVEaXNwb3NlKG9mZkZuKTtcblx0XHRyZXR1cm4geyBvZmY6IG9mZkZuIH07XG5cdH07XG5cdGNvbnN0IHRyaWdnZXIgPSAoLi4uYXJncykgPT4ge1xuXHRcdHJldHVybiBQcm9taXNlLmFsbChBcnJheS5mcm9tKGZucykubWFwKChmbikgPT4gZm4oLi4uYXJncykpKTtcblx0fTtcblx0cmV0dXJuIHtcblx0XHRvbixcblx0XHRvZmYsXG5cdFx0dHJpZ2dlcixcblx0XHRjbGVhclxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gY3JlYXRlR2xvYmFsU3RhdGUvaW5kZXgudHNcbi8qKlxuKiBLZWVwIHN0YXRlcyBpbiB0aGUgZ2xvYmFsIHNjb3BlIHRvIGJlIHJldXNhYmxlIGFjcm9zcyBWdWUgaW5zdGFuY2VzLlxuKlxuKiBAc2VlIGh0dHBzOi8vdnVldXNlLm9yZy9jcmVhdGVHbG9iYWxTdGF0ZVxuKiBAcGFyYW0gc3RhdGVGYWN0b3J5IEEgZmFjdG9yeSBmdW5jdGlvbiB0byBjcmVhdGUgdGhlIHN0YXRlXG4qXG4qIEBfX05PX1NJREVfRUZGRUNUU19fXG4qL1xuZnVuY3Rpb24gY3JlYXRlR2xvYmFsU3RhdGUoc3RhdGVGYWN0b3J5KSB7XG5cdGxldCBpbml0aWFsaXplZCA9IGZhbHNlO1xuXHRsZXQgc3RhdGU7XG5cdGNvbnN0IHNjb3BlID0gZWZmZWN0U2NvcGUodHJ1ZSk7XG5cdHJldHVybiAoKC4uLmFyZ3MpID0+IHtcblx0XHRpZiAoIWluaXRpYWxpemVkKSB7XG5cdFx0XHRzdGF0ZSA9IHNjb3BlLnJ1bigoKSA9PiBzdGF0ZUZhY3RvcnkoLi4uYXJncykpO1xuXHRcdFx0aW5pdGlhbGl6ZWQgPSB0cnVlO1xuXHRcdH1cblx0XHRyZXR1cm4gc3RhdGU7XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gcHJvdmlkZUxvY2FsL21hcC50c1xuY29uc3QgbG9jYWxQcm92aWRlZFN0YXRlTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBpbmplY3RMb2NhbC9pbmRleC50c1xuLyoqXG4qIE9uIHRoZSBiYXNpcyBvZiBgaW5qZWN0YCwgaXQgaXMgYWxsb3dlZCB0byBkaXJlY3RseSBjYWxsIGluamVjdCB0byBvYnRhaW4gdGhlIHZhbHVlIGFmdGVyIGNhbGwgcHJvdmlkZSBpbiB0aGUgc2FtZSBjb21wb25lbnQuXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzXG4qIGluamVjdExvY2FsKCdNeUluamVjdGlvbktleScsIDEpXG4qIGNvbnN0IGluamVjdGVkVmFsdWUgPSBpbmplY3RMb2NhbCgnTXlJbmplY3Rpb25LZXknKSAvLyBpbmplY3RlZFZhbHVlID09PSAxXG4qIGBgYFxuKlxuKiBAX19OT19TSURFX0VGRkVDVFNfX1xuKi9cbmNvbnN0IGluamVjdExvY2FsID0gKC4uLmFyZ3MpID0+IHtcblx0dmFyIF9nZXRDdXJyZW50SW5zdGFuY2U7XG5cdGNvbnN0IGtleSA9IGFyZ3NbMF07XG5cdGNvbnN0IGluc3RhbmNlID0gKF9nZXRDdXJyZW50SW5zdGFuY2UgPSBnZXRDdXJyZW50SW5zdGFuY2UoKSkgPT09IG51bGwgfHwgX2dldEN1cnJlbnRJbnN0YW5jZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2dldEN1cnJlbnRJbnN0YW5jZS5wcm94eTtcblx0Y29uc3Qgb3duZXIgPSBpbnN0YW5jZSAhPT0gbnVsbCAmJiBpbnN0YW5jZSAhPT0gdm9pZCAwID8gaW5zdGFuY2UgOiBnZXRDdXJyZW50U2NvcGUoKTtcblx0aWYgKG93bmVyID09IG51bGwgJiYgIWhhc0luamVjdGlvbkNvbnRleHQoKSkgdGhyb3cgbmV3IEVycm9yKFwiaW5qZWN0TG9jYWwgbXVzdCBiZSBjYWxsZWQgaW4gc2V0dXBcIik7XG5cdGlmIChvd25lciAmJiBsb2NhbFByb3ZpZGVkU3RhdGVNYXAuaGFzKG93bmVyKSAmJiBrZXkgaW4gbG9jYWxQcm92aWRlZFN0YXRlTWFwLmdldChvd25lcikpIHJldHVybiBsb2NhbFByb3ZpZGVkU3RhdGVNYXAuZ2V0KG93bmVyKVtrZXldO1xuXHRyZXR1cm4gaW5qZWN0KC4uLmFyZ3MpO1xufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHByb3ZpZGVMb2NhbC9pbmRleC50c1xuLyoqXG4qIE9uIHRoZSBiYXNpcyBvZiBgcHJvdmlkZWAsIGl0IGlzIGFsbG93ZWQgdG8gZGlyZWN0bHkgY2FsbCBpbmplY3QgdG8gb2J0YWluIHRoZSB2YWx1ZSBhZnRlciBjYWxsIHByb3ZpZGUgaW4gdGhlIHNhbWUgY29tcG9uZW50LlxuKlxuKiBAZXhhbXBsZVxuKiBgYGB0c1xuKiBwcm92aWRlTG9jYWwoJ015SW5qZWN0aW9uS2V5JywgMSlcbiogY29uc3QgaW5qZWN0ZWRWYWx1ZSA9IGluamVjdExvY2FsKCdNeUluamVjdGlvbktleScpIC8vIGluamVjdGVkVmFsdWUgPT09IDFcbiogYGBgXG4qL1xuZnVuY3Rpb24gcHJvdmlkZUxvY2FsKGtleSwgdmFsdWUpIHtcblx0dmFyIF9nZXRDdXJyZW50SW5zdGFuY2U7XG5cdGNvbnN0IGluc3RhbmNlID0gKF9nZXRDdXJyZW50SW5zdGFuY2UgPSBnZXRDdXJyZW50SW5zdGFuY2UoKSkgPT09IG51bGwgfHwgX2dldEN1cnJlbnRJbnN0YW5jZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX2dldEN1cnJlbnRJbnN0YW5jZS5wcm94eTtcblx0Y29uc3Qgb3duZXIgPSBpbnN0YW5jZSAhPT0gbnVsbCAmJiBpbnN0YW5jZSAhPT0gdm9pZCAwID8gaW5zdGFuY2UgOiBnZXRDdXJyZW50U2NvcGUoKTtcblx0aWYgKG93bmVyID09IG51bGwpIHRocm93IG5ldyBFcnJvcihcInByb3ZpZGVMb2NhbCBtdXN0IGJlIGNhbGxlZCBpbiBzZXR1cFwiKTtcblx0aWYgKCFsb2NhbFByb3ZpZGVkU3RhdGVNYXAuaGFzKG93bmVyKSkgbG9jYWxQcm92aWRlZFN0YXRlTWFwLnNldChvd25lciwgT2JqZWN0LmNyZWF0ZShudWxsKSk7XG5cdGNvbnN0IGxvY2FsUHJvdmlkZWRTdGF0ZSA9IGxvY2FsUHJvdmlkZWRTdGF0ZU1hcC5nZXQob3duZXIpO1xuXHRsb2NhbFByb3ZpZGVkU3RhdGVba2V5XSA9IHZhbHVlO1xuXHRyZXR1cm4gcHJvdmlkZShrZXksIHZhbHVlKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIGNyZWF0ZUluamVjdGlvblN0YXRlL2luZGV4LnRzXG5mdW5jdGlvbiBjcmVhdGVJbmplY3Rpb25TdGF0ZShjb21wb3NhYmxlLCBvcHRpb25zKSB7XG5cdGNvbnN0IGtleSA9IChvcHRpb25zID09PSBudWxsIHx8IG9wdGlvbnMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9wdGlvbnMuaW5qZWN0aW9uS2V5KSB8fCBTeW1ib2woY29tcG9zYWJsZS5uYW1lIHx8IFwiSW5qZWN0aW9uU3RhdGVcIik7XG5cdGNvbnN0IGRlZmF1bHRWYWx1ZSA9IG9wdGlvbnMgPT09IG51bGwgfHwgb3B0aW9ucyA9PT0gdm9pZCAwID8gdm9pZCAwIDogb3B0aW9ucy5kZWZhdWx0VmFsdWU7XG5cdGNvbnN0IHVzZVByb3ZpZGluZ1N0YXRlID0gKC4uLmFyZ3MpID0+IHtcblx0XHRjb25zdCBzdGF0ZSA9IGNvbXBvc2FibGUoLi4uYXJncyk7XG5cdFx0cHJvdmlkZUxvY2FsKGtleSwgc3RhdGUpO1xuXHRcdHJldHVybiBzdGF0ZTtcblx0fTtcblx0Y29uc3QgdXNlSW5qZWN0ZWRTdGF0ZSA9ICgpID0+IGluamVjdExvY2FsKGtleSwgZGVmYXVsdFZhbHVlKTtcblx0cmV0dXJuIFt1c2VQcm92aWRpbmdTdGF0ZSwgdXNlSW5qZWN0ZWRTdGF0ZV07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBjcmVhdGVSZWYvaW5kZXgudHNcbi8qKlxuKiBSZXR1cm5zIGEgYGRlZXBSZWZgIG9yIGBzaGFsbG93UmVmYCBkZXBlbmRpbmcgb24gdGhlIGBkZWVwYCBwYXJhbS5cbipcbiogQGV4YW1wbGUgY3JlYXRlUmVmKDEpIC8vIFNoYWxsb3dSZWY8bnVtYmVyPlxuKiBAZXhhbXBsZSBjcmVhdGVSZWYoMSwgZmFsc2UpIC8vIFNoYWxsb3dSZWY8bnVtYmVyPlxuKiBAZXhhbXBsZSBjcmVhdGVSZWYoMSwgdHJ1ZSkgLy8gUmVmPG51bWJlcj5cbiogQGV4YW1wbGUgY3JlYXRlUmVmKFwic3RyaW5nXCIpIC8vIFNoYWxsb3dSZWY8c3RyaW5nPlxuKiBAZXhhbXBsZSBjcmVhdGVSZWY8XCJBXCJ8XCJCXCI+KFwiQVwiLCB0cnVlKSAvLyBSZWY8XCJBXCJ8XCJCXCI+XG4qXG4qIEBwYXJhbSB2YWx1ZVxuKiBAcGFyYW0gZGVlcFxuKiBAcmV0dXJucyB0aGUgYGRlZXBSZWZgIG9yIGBzaGFsbG93UmVmYFxuKlxuKiBAX19OT19TSURFX0VGRkVDVFNfX1xuKi9cbmZ1bmN0aW9uIGNyZWF0ZVJlZih2YWx1ZSwgZGVlcCkge1xuXHRpZiAoZGVlcCA9PT0gdHJ1ZSkgcmV0dXJuIHJlZih2YWx1ZSk7XG5cdGVsc2UgcmV0dXJuIHNoYWxsb3dSZWYodmFsdWUpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gdXRpbHMvaXMudHNcbmNvbnN0IGlzQ2xpZW50ID0gdHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiAmJiB0eXBlb2YgZG9jdW1lbnQgIT09IFwidW5kZWZpbmVkXCI7XG5jb25zdCBpc1dvcmtlciA9IHR5cGVvZiBXb3JrZXJHbG9iYWxTY29wZSAhPT0gXCJ1bmRlZmluZWRcIiAmJiBnbG9iYWxUaGlzIGluc3RhbmNlb2YgV29ya2VyR2xvYmFsU2NvcGU7XG5jb25zdCBpc0RlZiA9ICh2YWwpID0+IHR5cGVvZiB2YWwgIT09IFwidW5kZWZpbmVkXCI7XG5jb25zdCBub3ROdWxsaXNoID0gKHZhbCkgPT4gdmFsICE9IG51bGw7XG5jb25zdCBhc3NlcnQgPSAoY29uZGl0aW9uLCAuLi5pbmZvcykgPT4ge1xuXHRpZiAoIWNvbmRpdGlvbikgY29uc29sZS53YXJuKC4uLmluZm9zKTtcbn07XG5jb25zdCB0b1N0cmluZyA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmc7XG5jb25zdCBpc09iamVjdCA9ICh2YWwpID0+IHRvU3RyaW5nLmNhbGwodmFsKSA9PT0gXCJbb2JqZWN0IE9iamVjdF1cIjtcbmNvbnN0IG5vdyA9ICgpID0+IERhdGUubm93KCk7XG5jb25zdCB0aW1lc3RhbXAgPSAoKSA9PiArRGF0ZS5ub3coKTtcbmNvbnN0IGNsYW1wID0gKG4sIG1pbiwgbWF4KSA9PiBNYXRoLm1pbihtYXgsIE1hdGgubWF4KG1pbiwgbikpO1xuY29uc3Qgbm9vcCA9ICgpID0+IHt9O1xuY29uc3QgcmFuZCA9IChtaW4sIG1heCkgPT4ge1xuXHRtaW4gPSBNYXRoLmNlaWwobWluKTtcblx0bWF4ID0gTWF0aC5mbG9vcihtYXgpO1xuXHRyZXR1cm4gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogKG1heCAtIG1pbiArIDEpKSArIG1pbjtcbn07XG5jb25zdCBoYXNPd24gPSAodmFsLCBrZXkpID0+IE9iamVjdC5oYXNPd24odmFsLCBrZXkpO1xuY29uc3QgaXNJT1MgPSAvKiAjX19QVVJFX18gKi8gZ2V0SXNJT1MoKTtcbmZ1bmN0aW9uIGdldElzSU9TKCkge1xuXHR2YXIgX3dpbmRvdywgX3dpbmRvdzIsIF93aW5kb3czO1xuXHRyZXR1cm4gaXNDbGllbnQgJiYgISEoKF93aW5kb3cgPSB3aW5kb3cpID09PSBudWxsIHx8IF93aW5kb3cgPT09IHZvaWQgMCB8fCAoX3dpbmRvdyA9IF93aW5kb3cubmF2aWdhdG9yKSA9PT0gbnVsbCB8fCBfd2luZG93ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfd2luZG93LnVzZXJBZ2VudCkgJiYgKC9pUCg/OmFkfGhvbmV8b2QpLy50ZXN0KHdpbmRvdy5uYXZpZ2F0b3IudXNlckFnZW50KSB8fCAoKF93aW5kb3cyID0gd2luZG93KSA9PT0gbnVsbCB8fCBfd2luZG93MiA9PT0gdm9pZCAwIHx8IChfd2luZG93MiA9IF93aW5kb3cyLm5hdmlnYXRvcikgPT09IG51bGwgfHwgX3dpbmRvdzIgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF93aW5kb3cyLm1heFRvdWNoUG9pbnRzKSA+IDIgJiYgL2lQYWR8TWFjaW50b3NoLy50ZXN0KChfd2luZG93MyA9IHdpbmRvdykgPT09IG51bGwgfHwgX3dpbmRvdzMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF93aW5kb3czLm5hdmlnYXRvci51c2VyQWdlbnQpKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHRvUmVmL2luZGV4LnRzXG5mdW5jdGlvbiB0b1JlZiguLi5hcmdzKSB7XG5cdGlmIChhcmdzLmxlbmd0aCAhPT0gMSkgcmV0dXJuIHRvUmVmJDEoLi4uYXJncyk7XG5cdGNvbnN0IHIgPSBhcmdzWzBdO1xuXHRyZXR1cm4gdHlwZW9mIHIgPT09IFwiZnVuY3Rpb25cIiA/IHJlYWRvbmx5KGN1c3RvbVJlZigoKSA9PiAoe1xuXHRcdGdldDogcixcblx0XHRzZXQ6IG5vb3Bcblx0fSkpKSA6IHJlZihyKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHV0aWxzL2ZpbHRlcnMudHNcbmZ1bmN0aW9uIGNyZWF0ZUZpbHRlcldyYXBwZXIoZmlsdGVyLCBmbikge1xuXHRmdW5jdGlvbiB3cmFwcGVyKC4uLmFyZ3MpIHtcblx0XHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0UHJvbWlzZS5yZXNvbHZlKGZpbHRlcigoKSA9PiBmbi5hcHBseSh0aGlzLCBhcmdzKSwge1xuXHRcdFx0XHRmbixcblx0XHRcdFx0dGhpc0FyZzogdGhpcyxcblx0XHRcdFx0YXJnc1xuXHRcdFx0fSkpLnRoZW4ocmVzb2x2ZSkuY2F0Y2gocmVqZWN0KTtcblx0XHR9KTtcblx0fVxuXHRpZiAoXCJjYW5jZWxcIiBpbiBmaWx0ZXIpIE9iamVjdC5hc3NpZ24od3JhcHBlciwge1xuXHRcdGNhbmNlbDogZmlsdGVyLmNhbmNlbCxcblx0XHRmbHVzaDogZmlsdGVyLmZsdXNoLFxuXHRcdGlzUGVuZGluZzogZmlsdGVyLmlzUGVuZGluZ1xuXHR9KTtcblx0cmV0dXJuIHdyYXBwZXI7XG59XG5jb25zdCBieXBhc3NGaWx0ZXIgPSAoaW52b2tlKSA9PiB7XG5cdHJldHVybiBpbnZva2UoKTtcbn07XG4vKipcbiogQ3JlYXRlIGFuIEV2ZW50RmlsdGVyIHRoYXQgZGVib3VuY2UgdGhlIGV2ZW50c1xuKi9cbmZ1bmN0aW9uIGRlYm91bmNlRmlsdGVyKG1zLCBvcHRpb25zID0ge30pIHtcblx0bGV0IHRpbWVyO1xuXHRsZXQgbWF4VGltZXI7XG5cdGxldCBsYXN0UmVqZWN0b3IgPSBub29wO1xuXHRsZXQgbGFzdFJlc29sdmUgPSBub29wO1xuXHRjb25zdCBfcGVuZGluZyA9IHNoYWxsb3dSZWYoZmFsc2UpO1xuXHRjb25zdCBfY2xlYXJUaW1lb3V0ID0gKHRpbWVyKSA9PiB7XG5cdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKTtcblx0XHRsYXN0UmVqZWN0b3IoKTtcblx0XHRsYXN0UmVqZWN0b3IgPSBub29wO1xuXHR9O1xuXHRsZXQgbGFzdEludm9rZXI7XG5cdGNvbnN0IGhhbmRsZXIgPSAoaW52b2tlKSA9PiB7XG5cdFx0Y29uc3QgZHVyYXRpb24gPSB0b1ZhbHVlKG1zKTtcblx0XHRjb25zdCBtYXhEdXJhdGlvbiA9IHRvVmFsdWUob3B0aW9ucy5tYXhXYWl0KTtcblx0XHRpZiAodGltZXIpIF9jbGVhclRpbWVvdXQodGltZXIpO1xuXHRcdGlmIChkdXJhdGlvbiA8PSAwIHx8IG1heER1cmF0aW9uICE9PSB2b2lkIDAgJiYgbWF4RHVyYXRpb24gPD0gMCkge1xuXHRcdFx0aWYgKG1heFRpbWVyKSB7XG5cdFx0XHRcdF9jbGVhclRpbWVvdXQobWF4VGltZXIpO1xuXHRcdFx0XHRtYXhUaW1lciA9IHZvaWQgMDtcblx0XHRcdH1cblx0XHRcdF9wZW5kaW5nLnZhbHVlID0gZmFsc2U7XG5cdFx0XHRyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGludm9rZSgpKTtcblx0XHR9XG5cdFx0X3BlbmRpbmcudmFsdWUgPSB0cnVlO1xuXHRcdHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0XHRsYXN0UmVqZWN0b3IgPSBvcHRpb25zLnJlamVjdE9uQ2FuY2VsID8gcmVqZWN0IDogcmVzb2x2ZTtcblx0XHRcdGxhc3RSZXNvbHZlID0gcmVzb2x2ZTtcblx0XHRcdGxhc3RJbnZva2VyID0gaW52b2tlO1xuXHRcdFx0aWYgKG1heER1cmF0aW9uICYmICFtYXhUaW1lcikgbWF4VGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdFx0aWYgKHRpbWVyKSBfY2xlYXJUaW1lb3V0KHRpbWVyKTtcblx0XHRcdFx0bWF4VGltZXIgPSB2b2lkIDA7XG5cdFx0XHRcdF9wZW5kaW5nLnZhbHVlID0gZmFsc2U7XG5cdFx0XHRcdHJlc29sdmUobGFzdEludm9rZXIoKSk7XG5cdFx0XHR9LCBtYXhEdXJhdGlvbik7XG5cdFx0XHR0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0XHRpZiAobWF4VGltZXIpIF9jbGVhclRpbWVvdXQobWF4VGltZXIpO1xuXHRcdFx0XHRtYXhUaW1lciA9IHZvaWQgMDtcblx0XHRcdFx0X3BlbmRpbmcudmFsdWUgPSBmYWxzZTtcblx0XHRcdFx0cmVzb2x2ZShpbnZva2UoKSk7XG5cdFx0XHR9LCBkdXJhdGlvbik7XG5cdFx0fSk7XG5cdH07XG5cdHJldHVybiBPYmplY3QuYXNzaWduKGhhbmRsZXIsIHtcblx0XHRjYW5jZWw6ICgpID0+IHtcblx0XHRcdGlmICh0aW1lcikge1xuXHRcdFx0XHRfY2xlYXJUaW1lb3V0KHRpbWVyKTtcblx0XHRcdFx0dGltZXIgPSB2b2lkIDA7XG5cdFx0XHR9XG5cdFx0XHRpZiAobWF4VGltZXIpIHtcblx0XHRcdFx0X2NsZWFyVGltZW91dChtYXhUaW1lcik7XG5cdFx0XHRcdG1heFRpbWVyID0gdm9pZCAwO1xuXHRcdFx0fVxuXHRcdFx0X3BlbmRpbmcudmFsdWUgPSBmYWxzZTtcblx0XHRcdGxhc3RSZXNvbHZlID0gbm9vcDtcblx0XHR9LFxuXHRcdGZsdXNoOiAoKSA9PiB7XG5cdFx0XHRpZiAoX3BlbmRpbmcudmFsdWUpIHtcblx0XHRcdFx0aWYgKHRpbWVyKSB7XG5cdFx0XHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVyKTtcblx0XHRcdFx0XHR0aW1lciA9IHZvaWQgMDtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAobWF4VGltZXIpIHtcblx0XHRcdFx0XHRjbGVhclRpbWVvdXQobWF4VGltZXIpO1xuXHRcdFx0XHRcdG1heFRpbWVyID0gdm9pZCAwO1xuXHRcdFx0XHR9XG5cdFx0XHRcdF9wZW5kaW5nLnZhbHVlID0gZmFsc2U7XG5cdFx0XHRcdGNvbnN0IHJlc29sdmUgPSBsYXN0UmVzb2x2ZTtcblx0XHRcdFx0bGFzdFJlamVjdG9yID0gbm9vcDtcblx0XHRcdFx0bGFzdFJlc29sdmUgPSBub29wO1xuXHRcdFx0XHRyZXNvbHZlKGxhc3RJbnZva2VyKCkpO1xuXHRcdFx0fVxuXHRcdH0sXG5cdFx0aXNQZW5kaW5nOiBzaGFsbG93UmVhZG9ubHkoX3BlbmRpbmcpXG5cdH0pO1xufVxuZnVuY3Rpb24gdGhyb3R0bGVGaWx0ZXIoLi4uYXJncykge1xuXHRsZXQgbGFzdEV4ZWMgPSAwO1xuXHRsZXQgdGltZXI7XG5cdGxldCBpc0xlYWRpbmcgPSB0cnVlO1xuXHRsZXQgbGFzdFJlamVjdG9yID0gbm9vcDtcblx0bGV0IGxhc3RWYWx1ZTtcblx0bGV0IG1zO1xuXHRsZXQgdHJhaWxpbmc7XG5cdGxldCBsZWFkaW5nO1xuXHRsZXQgcmVqZWN0T25DYW5jZWw7XG5cdGlmICghaXNSZWYoYXJnc1swXSkgJiYgdHlwZW9mIGFyZ3NbMF0gPT09IFwib2JqZWN0XCIpICh7ZGVsYXk6IG1zLCB0cmFpbGluZyA9IHRydWUsIGxlYWRpbmcgPSB0cnVlLCByZWplY3RPbkNhbmNlbCA9IGZhbHNlfSA9IGFyZ3NbMF0pO1xuXHRlbHNlIFttcywgdHJhaWxpbmcgPSB0cnVlLCBsZWFkaW5nID0gdHJ1ZSwgcmVqZWN0T25DYW5jZWwgPSBmYWxzZV0gPSBhcmdzO1xuXHRjb25zdCBjbGVhciA9ICgpID0+IHtcblx0XHRpZiAodGltZXIpIHtcblx0XHRcdGNsZWFyVGltZW91dCh0aW1lcik7XG5cdFx0XHR0aW1lciA9IHZvaWQgMDtcblx0XHRcdGxhc3RSZWplY3RvcigpO1xuXHRcdFx0bGFzdFJlamVjdG9yID0gbm9vcDtcblx0XHR9XG5cdH07XG5cdGNvbnN0IGZpbHRlciA9IChfaW52b2tlKSA9PiB7XG5cdFx0Y29uc3QgZHVyYXRpb24gPSB0b1ZhbHVlKG1zKTtcblx0XHRjb25zdCBlbGFwc2VkID0gRGF0ZS5ub3coKSAtIGxhc3RFeGVjO1xuXHRcdGNvbnN0IGludm9rZSA9ICgpID0+IHtcblx0XHRcdHJldHVybiBsYXN0VmFsdWUgPSBfaW52b2tlKCk7XG5cdFx0fTtcblx0XHRjbGVhcigpO1xuXHRcdGlmIChkdXJhdGlvbiA8PSAwKSB7XG5cdFx0XHRsYXN0RXhlYyA9IERhdGUubm93KCk7XG5cdFx0XHRyZXR1cm4gaW52b2tlKCk7XG5cdFx0fVxuXHRcdGlmIChlbGFwc2VkID4gZHVyYXRpb24pIHtcblx0XHRcdGxhc3RFeGVjID0gRGF0ZS5ub3coKTtcblx0XHRcdGlmIChsZWFkaW5nIHx8ICFpc0xlYWRpbmcpIGludm9rZSgpO1xuXHRcdH0gZWxzZSBpZiAodHJhaWxpbmcpIGxhc3RWYWx1ZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdGxhc3RSZWplY3RvciA9IHJlamVjdE9uQ2FuY2VsID8gcmVqZWN0IDogcmVzb2x2ZTtcblx0XHRcdHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHRcdGxhc3RFeGVjID0gRGF0ZS5ub3coKTtcblx0XHRcdFx0aXNMZWFkaW5nID0gdHJ1ZTtcblx0XHRcdFx0cmVzb2x2ZShpbnZva2UoKSk7XG5cdFx0XHRcdGNsZWFyKCk7XG5cdFx0XHR9LCBNYXRoLm1heCgwLCBkdXJhdGlvbiAtIGVsYXBzZWQpKTtcblx0XHR9KTtcblx0XHRpZiAoIWxlYWRpbmcgJiYgIXRpbWVyKSB0aW1lciA9IHNldFRpbWVvdXQoKCkgPT4gaXNMZWFkaW5nID0gdHJ1ZSwgZHVyYXRpb24pO1xuXHRcdGlzTGVhZGluZyA9IGZhbHNlO1xuXHRcdHJldHVybiBsYXN0VmFsdWU7XG5cdH07XG5cdHJldHVybiBmaWx0ZXI7XG59XG4vKipcbiogRXZlbnRGaWx0ZXIgdGhhdCBnaXZlcyBleHRyYSBjb250cm9scyB0byBwYXVzZSBhbmQgcmVzdW1lIHRoZSBmaWx0ZXJcbipcbiogQHBhcmFtIGV4dGVuZEZpbHRlciAgRXh0cmEgZmlsdGVyIHRvIGFwcGx5IHdoZW4gdGhlIFBhdXNhYmxlRmlsdGVyIGlzIGFjdGl2ZSwgZGVmYXVsdCB0byBub25lXG4qIEBwYXJhbSBvcHRpb25zIE9wdGlvbnMgdG8gY29uZmlndXJlIHRoZSBmaWx0ZXJcbiovXG5mdW5jdGlvbiBwYXVzYWJsZUZpbHRlcihleHRlbmRGaWx0ZXIgPSBieXBhc3NGaWx0ZXIsIG9wdGlvbnMgPSB7fSkge1xuXHRjb25zdCB7IGluaXRpYWxTdGF0ZSA9IFwiYWN0aXZlXCIgfSA9IG9wdGlvbnM7XG5cdGNvbnN0IGlzQWN0aXZlID0gdG9SZWYoaW5pdGlhbFN0YXRlID09PSBcImFjdGl2ZVwiKTtcblx0ZnVuY3Rpb24gcGF1c2UoKSB7XG5cdFx0aXNBY3RpdmUudmFsdWUgPSBmYWxzZTtcblx0fVxuXHRmdW5jdGlvbiByZXN1bWUoKSB7XG5cdFx0aXNBY3RpdmUudmFsdWUgPSB0cnVlO1xuXHR9XG5cdGNvbnN0IGV2ZW50RmlsdGVyID0gKC4uLmFyZ3MpID0+IHtcblx0XHRpZiAoaXNBY3RpdmUudmFsdWUpIGV4dGVuZEZpbHRlciguLi5hcmdzKTtcblx0fTtcblx0cmV0dXJuIHtcblx0XHRpc0FjdGl2ZTogc2hhbGxvd1JlYWRvbmx5KGlzQWN0aXZlKSxcblx0XHRwYXVzZSxcblx0XHRyZXN1bWUsXG5cdFx0ZXZlbnRGaWx0ZXJcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHV0aWxzL2dlbmVyYWwudHNcbmZ1bmN0aW9uIHByb21pc2VUaW1lb3V0KG1zLCB0aHJvd09uVGltZW91dCA9IGZhbHNlLCByZWFzb24gPSBcIlRpbWVvdXRcIikge1xuXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGlmICh0aHJvd09uVGltZW91dCkgc2V0VGltZW91dChyZWplY3QsIG1zLCByZWFzb24pO1xuXHRcdGVsc2Ugc2V0VGltZW91dChyZXNvbHZlLCBtcyk7XG5cdH0pO1xufVxuZnVuY3Rpb24gaWRlbnRpdHkoYXJnKSB7XG5cdHJldHVybiBhcmc7XG59XG4vKipcbiogQ3JlYXRlIHNpbmdsZXRvbiBwcm9taXNlIGZ1bmN0aW9uXG4qXG4qIEBleGFtcGxlXG4qIGBgYFxuKiBjb25zdCBwcm9taXNlID0gY3JlYXRlU2luZ2xldG9uUHJvbWlzZShhc3luYyAoKSA9PiB7IC4uLiB9KVxuKlxuKiBhd2FpdCBwcm9taXNlKClcbiogYXdhaXQgcHJvbWlzZSgpIC8vIGFsbCBvZiB0aGVtIHdpbGwgYmUgYmluZCB0byBhIHNpbmdsZSBwcm9taXNlIGluc3RhbmNlXG4qIGF3YWl0IHByb21pc2UoKSAvLyBhbmQgYmUgcmVzb2x2ZWQgdG9nZXRoZXJcbiogYGBgXG4qL1xuZnVuY3Rpb24gY3JlYXRlU2luZ2xldG9uUHJvbWlzZShmbikge1xuXHRsZXQgX3Byb21pc2U7XG5cdGZ1bmN0aW9uIHdyYXBwZXIoKSB7XG5cdFx0aWYgKCFfcHJvbWlzZSkgX3Byb21pc2UgPSBmbigpO1xuXHRcdHJldHVybiBfcHJvbWlzZTtcblx0fVxuXHR3cmFwcGVyLnJlc2V0ID0gYXN5bmMgKCkgPT4ge1xuXHRcdGNvbnN0IF9wcmV2ID0gX3Byb21pc2U7XG5cdFx0X3Byb21pc2UgPSB2b2lkIDA7XG5cdFx0aWYgKF9wcmV2KSBhd2FpdCBfcHJldjtcblx0fTtcblx0cmV0dXJuIHdyYXBwZXI7XG59XG5mdW5jdGlvbiBpbnZva2UoZm4pIHtcblx0cmV0dXJuIGZuKCk7XG59XG5mdW5jdGlvbiBjb250YWluc1Byb3Aob2JqLCAuLi5wcm9wcykge1xuXHRyZXR1cm4gcHJvcHMuc29tZSgoaykgPT4gayBpbiBvYmopO1xufVxuZnVuY3Rpb24gaW5jcmVhc2VXaXRoVW5pdCh0YXJnZXQsIGRlbHRhKSB7XG5cdHZhciBfdGFyZ2V0JG1hdGNoO1xuXHRpZiAodHlwZW9mIHRhcmdldCA9PT0gXCJudW1iZXJcIikgcmV0dXJuIHRhcmdldCArIGRlbHRhO1xuXHRjb25zdCB2YWx1ZSA9ICgoX3RhcmdldCRtYXRjaCA9IHRhcmdldC5tYXRjaCgvXi0/XFxkK1xcLj9cXGQqLykpID09PSBudWxsIHx8IF90YXJnZXQkbWF0Y2ggPT09IHZvaWQgMCA/IHZvaWQgMCA6IF90YXJnZXQkbWF0Y2hbMF0pIHx8IFwiXCI7XG5cdGNvbnN0IHVuaXQgPSB0YXJnZXQuc2xpY2UodmFsdWUubGVuZ3RoKTtcblx0Y29uc3QgcmVzdWx0ID0gTnVtYmVyLnBhcnNlRmxvYXQodmFsdWUpICsgZGVsdGE7XG5cdGlmIChOdW1iZXIuaXNOYU4ocmVzdWx0KSkgcmV0dXJuIHRhcmdldDtcblx0cmV0dXJuIHJlc3VsdCArIHVuaXQ7XG59XG4vKipcbiogR2V0IGEgcHggdmFsdWUgZm9yIFNTUiB1c2UsIGRvIG5vdCByZWx5IG9uIHRoaXMgbWV0aG9kIG91dHNpZGUgb2YgU1NSIGFzIFJFTSB1bml0IGlzIGFzc3VtZWQgYXQgMTZweCwgd2hpY2ggbWlnaHQgbm90IGJlIHRoZSBjYXNlIG9uIHRoZSBjbGllbnRcbiovXG5mdW5jdGlvbiBweFZhbHVlKHB4KSB7XG5cdHJldHVybiBweC5lbmRzV2l0aChcInJlbVwiKSA/IE51bWJlci5wYXJzZUZsb2F0KHB4KSAqIDE2IDogTnVtYmVyLnBhcnNlRmxvYXQocHgpO1xufVxuLyoqXG4qIENyZWF0ZSBhIG5ldyBzdWJzZXQgb2JqZWN0IGJ5IGdpdmluZyBrZXlzXG4qL1xuZnVuY3Rpb24gb2JqZWN0UGljayhvYmosIGtleXMsIG9taXRVbmRlZmluZWQgPSBmYWxzZSkge1xuXHRyZXR1cm4ga2V5cy5yZWR1Y2UoKG4sIGspID0+IHtcblx0XHRpZiAoayBpbiBvYmopIHtcblx0XHRcdGlmICghb21pdFVuZGVmaW5lZCB8fCBvYmpba10gIT09IHZvaWQgMCkgbltrXSA9IG9ialtrXTtcblx0XHR9XG5cdFx0cmV0dXJuIG47XG5cdH0sIHt9KTtcbn1cbi8qKlxuKiBDcmVhdGUgYSBuZXcgc3Vic2V0IG9iamVjdCBieSBvbWl0IGdpdmluZyBrZXlzXG4qL1xuZnVuY3Rpb24gb2JqZWN0T21pdChvYmosIGtleXMsIG9taXRVbmRlZmluZWQgPSBmYWxzZSkge1xuXHRyZXR1cm4gT2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5lbnRyaWVzKG9iaikuZmlsdGVyKChba2V5LCB2YWx1ZV0pID0+IHtcblx0XHRyZXR1cm4gKCFvbWl0VW5kZWZpbmVkIHx8IHZhbHVlICE9PSB2b2lkIDApICYmICFrZXlzLmluY2x1ZGVzKGtleSk7XG5cdH0pKTtcbn1cbmZ1bmN0aW9uIG9iamVjdEVudHJpZXMob2JqKSB7XG5cdHJldHVybiBPYmplY3QuZW50cmllcyhvYmopO1xufVxuZnVuY3Rpb24gdG9BcnJheSh2YWx1ZSkge1xuXHRyZXR1cm4gQXJyYXkuaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZSA6IFt2YWx1ZV07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiB1dGlscy9wb3J0LnRzXG5mdW5jdGlvbiBjYWNoZVN0cmluZ0Z1bmN0aW9uKGZuKSB7XG5cdGNvbnN0IGNhY2hlID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblx0cmV0dXJuICgoc3RyKSA9PiB7XG5cdFx0cmV0dXJuIGNhY2hlW3N0cl0gfHwgKGNhY2hlW3N0cl0gPSBmbihzdHIpKTtcblx0fSk7XG59XG5jb25zdCBoeXBoZW5hdGVSRSA9IC9cXEIoW0EtWl0pL2c7XG5jb25zdCBoeXBoZW5hdGUgPSBjYWNoZVN0cmluZ0Z1bmN0aW9uKChzdHIpID0+IHN0ci5yZXBsYWNlKGh5cGhlbmF0ZVJFLCBcIi0kMVwiKS50b0xvd2VyQ2FzZSgpKTtcbmNvbnN0IGNhbWVsaXplUkUgPSAvLShcXHcpL2c7XG5jb25zdCBjYW1lbGl6ZSA9IGNhY2hlU3RyaW5nRnVuY3Rpb24oKHN0cikgPT4ge1xuXHRyZXR1cm4gc3RyLnJlcGxhY2UoY2FtZWxpemVSRSwgKF8sIGMpID0+IGMgPyBjLnRvVXBwZXJDYXNlKCkgOiBcIlwiKTtcbn0pO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gdXRpbHMvdnVlLnRzXG5mdW5jdGlvbiBnZXRMaWZlQ3ljbGVUYXJnZXQodGFyZ2V0KSB7XG5cdHJldHVybiB0YXJnZXQgfHwgZ2V0Q3VycmVudEluc3RhbmNlKCk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBjcmVhdGVTaGFyZWRDb21wb3NhYmxlL2luZGV4LnRzXG4vKipcbiogTWFrZSBhIGNvbXBvc2FibGUgZnVuY3Rpb24gdXNhYmxlIHdpdGggbXVsdGlwbGUgVnVlIGluc3RhbmNlcy5cbipcbiogQHNlZSBodHRwczovL3Z1ZXVzZS5vcmcvY3JlYXRlU2hhcmVkQ29tcG9zYWJsZVxuKlxuKiBAX19OT19TSURFX0VGRkVDVFNfX1xuKi9cbmZ1bmN0aW9uIGNyZWF0ZVNoYXJlZENvbXBvc2FibGUoY29tcG9zYWJsZSkge1xuXHRpZiAoIWlzQ2xpZW50KSByZXR1cm4gY29tcG9zYWJsZTtcblx0bGV0IHN1YnNjcmliZXJzID0gMDtcblx0bGV0IHN0YXRlO1xuXHRsZXQgc2NvcGU7XG5cdGNvbnN0IGRpc3Bvc2UgPSAoKSA9PiB7XG5cdFx0c3Vic2NyaWJlcnMgLT0gMTtcblx0XHRpZiAoc2NvcGUgJiYgc3Vic2NyaWJlcnMgPD0gMCkge1xuXHRcdFx0c2NvcGUuc3RvcCgpO1xuXHRcdFx0c3RhdGUgPSB2b2lkIDA7XG5cdFx0XHRzY29wZSA9IHZvaWQgMDtcblx0XHR9XG5cdH07XG5cdHJldHVybiAoKC4uLmFyZ3MpID0+IHtcblx0XHRzdWJzY3JpYmVycyArPSAxO1xuXHRcdGlmICghc2NvcGUpIHtcblx0XHRcdHNjb3BlID0gZWZmZWN0U2NvcGUodHJ1ZSk7XG5cdFx0XHRzdGF0ZSA9IHNjb3BlLnJ1bigoKSA9PiBjb21wb3NhYmxlKC4uLmFyZ3MpKTtcblx0XHR9XG5cdFx0dHJ5T25TY29wZURpc3Bvc2UoZGlzcG9zZSk7XG5cdFx0cmV0dXJuIHN0YXRlO1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIGV4dGVuZFJlZi9pbmRleC50c1xuZnVuY3Rpb24gZXh0ZW5kUmVmKHJlZiwgZXh0ZW5kLCB7IGVudW1lcmFibGUgPSBmYWxzZSwgdW53cmFwID0gdHJ1ZSB9ID0ge30pIHtcblx0Zm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMoZXh0ZW5kKSkge1xuXHRcdGlmIChrZXkgPT09IFwidmFsdWVcIikgY29udGludWU7XG5cdFx0aWYgKGlzUmVmKHZhbHVlKSAmJiB1bndyYXApIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShyZWYsIGtleSwge1xuXHRcdFx0Z2V0KCkge1xuXHRcdFx0XHRyZXR1cm4gdmFsdWUudmFsdWU7XG5cdFx0XHR9LFxuXHRcdFx0c2V0KHYpIHtcblx0XHRcdFx0dmFsdWUudmFsdWUgPSB2O1xuXHRcdFx0fSxcblx0XHRcdGVudW1lcmFibGVcblx0XHR9KTtcblx0XHRlbHNlIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShyZWYsIGtleSwge1xuXHRcdFx0dmFsdWUsXG5cdFx0XHRlbnVtZXJhYmxlXG5cdFx0fSk7XG5cdH1cblx0cmV0dXJuIHJlZjtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIGdldC9pbmRleC50c1xuZnVuY3Rpb24gZ2V0KG9iaiwga2V5KSB7XG5cdGlmIChrZXkgPT0gbnVsbCkgcmV0dXJuIHVucmVmKG9iaik7XG5cdHJldHVybiB1bnJlZihvYmopW2tleV07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBpc0RlZmluZWQvaW5kZXgudHNcbmZ1bmN0aW9uIGlzRGVmaW5lZCh2KSB7XG5cdHJldHVybiB1bnJlZih2KSAhPSBudWxsO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gbWFrZURlc3RydWN0dXJhYmxlL2luZGV4LnRzXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gbWFrZURlc3RydWN0dXJhYmxlKG9iaiwgYXJyKSB7XG5cdGlmICh0eXBlb2YgU3ltYm9sICE9PSBcInVuZGVmaW5lZFwiKSB7XG5cdFx0Y29uc3QgY2xvbmUgPSB7IC4uLm9iaiB9O1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjbG9uZSwgU3ltYm9sLml0ZXJhdG9yLCB7XG5cdFx0XHRlbnVtZXJhYmxlOiBmYWxzZSxcblx0XHRcdHZhbHVlKCkge1xuXHRcdFx0XHRsZXQgaW5kZXggPSAwO1xuXHRcdFx0XHRyZXR1cm4geyBuZXh0OiAoKSA9PiAoe1xuXHRcdFx0XHRcdHZhbHVlOiBhcnJbaW5kZXgrK10sXG5cdFx0XHRcdFx0ZG9uZTogaW5kZXggPiBhcnIubGVuZ3RoXG5cdFx0XHRcdH0pIH07XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0cmV0dXJuIGNsb25lO1xuXHR9IGVsc2UgcmV0dXJuIE9iamVjdC5hc3NpZ24oWy4uLmFycl0sIG9iaik7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiByZWFjdGlmeS9pbmRleC50c1xuLyoqXG4qIENvbnZlcnRzIHBsYWluIGZ1bmN0aW9uIGludG8gYSByZWFjdGl2ZSBmdW5jdGlvbi5cbiogVGhlIGNvbnZlcnRlZCBmdW5jdGlvbiBhY2NlcHRzIHJlZnMgYXMgaXQncyBhcmd1bWVudHNcbiogYW5kIHJldHVybnMgYSBDb21wdXRlZFJlZiwgd2l0aCBwcm9wZXIgdHlwaW5nLlxuKlxuKiBAcGFyYW0gZm4gLSBTb3VyY2UgZnVuY3Rpb25cbiogQHBhcmFtIG9wdGlvbnMgLSBPcHRpb25zXG4qXG4qIEBfX05PX1NJREVfRUZGRUNUU19fXG4qL1xuZnVuY3Rpb24gcmVhY3RpZnkoZm4sIG9wdGlvbnMpIHtcblx0Y29uc3QgdW5yZWZGbiA9IChvcHRpb25zID09PSBudWxsIHx8IG9wdGlvbnMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9wdGlvbnMuY29tcHV0ZWRHZXR0ZXIpID09PSBmYWxzZSA/IHVucmVmIDogdG9WYWx1ZTtcblx0cmV0dXJuIGZ1bmN0aW9uKC4uLmFyZ3MpIHtcblx0XHRyZXR1cm4gY29tcHV0ZWQoKCkgPT4gZm4uYXBwbHkodGhpcywgYXJncy5tYXAoKGkpID0+IHVucmVmRm4oaSkpKSk7XG5cdH07XG59XG4vKiogQGRlcHJlY2F0ZWQgdXNlIGByZWFjdGlmeWAgaW5zdGVhZCAqL1xuY29uc3QgY3JlYXRlUmVhY3RpdmVGbiA9IHJlYWN0aWZ5O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gcmVhY3RpZnlPYmplY3QvaW5kZXgudHNcbi8qKlxuKiBBcHBseSBgcmVhY3RpZnlgIHRvIGFuIG9iamVjdFxuKlxuKiBAX19OT19TSURFX0VGRkVDVFNfX1xuKi9cbmZ1bmN0aW9uIHJlYWN0aWZ5T2JqZWN0KG9iaiwgb3B0aW9uc09yS2V5cyA9IHt9KSB7XG5cdGxldCBrZXlzID0gW107XG5cdGxldCBvcHRpb25zO1xuXHRpZiAoQXJyYXkuaXNBcnJheShvcHRpb25zT3JLZXlzKSkga2V5cyA9IG9wdGlvbnNPcktleXM7XG5cdGVsc2Uge1xuXHRcdG9wdGlvbnMgPSBvcHRpb25zT3JLZXlzO1xuXHRcdGNvbnN0IHsgaW5jbHVkZU93blByb3BlcnRpZXMgPSB0cnVlIH0gPSBvcHRpb25zT3JLZXlzO1xuXHRcdGtleXMucHVzaCguLi5PYmplY3Qua2V5cyhvYmopKTtcblx0XHRpZiAoaW5jbHVkZU93blByb3BlcnRpZXMpIGtleXMucHVzaCguLi5PYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhvYmopKTtcblx0fVxuXHRyZXR1cm4gT2JqZWN0LmZyb21FbnRyaWVzKGtleXMubWFwKChrZXkpID0+IHtcblx0XHRjb25zdCB2YWx1ZSA9IG9ialtrZXldO1xuXHRcdHJldHVybiBba2V5LCB0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIiA/IHJlYWN0aWZ5KHZhbHVlLmJpbmQob2JqKSwgb3B0aW9ucykgOiB2YWx1ZV07XG5cdH0pKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHRvUmVhY3RpdmUvaW5kZXgudHNcbi8qKlxuKiBDb252ZXJ0cyByZWYgdG8gcmVhY3RpdmUuXG4qXG4qIEBzZWUgaHR0cHM6Ly92dWV1c2Uub3JnL3RvUmVhY3RpdmVcbiogQHBhcmFtIG9iamVjdFJlZiBBIHJlZiBvZiBvYmplY3RcbiovXG5mdW5jdGlvbiB0b1JlYWN0aXZlKG9iamVjdFJlZikge1xuXHRpZiAoIWlzUmVmKG9iamVjdFJlZikpIHJldHVybiByZWFjdGl2ZShvYmplY3RSZWYpO1xuXHRyZXR1cm4gcmVhY3RpdmUobmV3IFByb3h5KHt9LCB7XG5cdFx0Z2V0KF8sIHAsIHJlY2VpdmVyKSB7XG5cdFx0XHRyZXR1cm4gdW5yZWYoUmVmbGVjdC5nZXQob2JqZWN0UmVmLnZhbHVlLCBwLCByZWNlaXZlcikpO1xuXHRcdH0sXG5cdFx0c2V0KF8sIHAsIHZhbHVlKSB7XG5cdFx0XHRpZiAoaXNSZWYob2JqZWN0UmVmLnZhbHVlW3BdKSAmJiAhaXNSZWYodmFsdWUpKSBvYmplY3RSZWYudmFsdWVbcF0udmFsdWUgPSB2YWx1ZTtcblx0XHRcdGVsc2Ugb2JqZWN0UmVmLnZhbHVlW3BdID0gdmFsdWU7XG5cdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9LFxuXHRcdGRlbGV0ZVByb3BlcnR5KF8sIHApIHtcblx0XHRcdHJldHVybiBSZWZsZWN0LmRlbGV0ZVByb3BlcnR5KG9iamVjdFJlZi52YWx1ZSwgcCk7XG5cdFx0fSxcblx0XHRoYXMoXywgcCkge1xuXHRcdFx0cmV0dXJuIFJlZmxlY3QuaGFzKG9iamVjdFJlZi52YWx1ZSwgcCk7XG5cdFx0fSxcblx0XHRvd25LZXlzKCkge1xuXHRcdFx0cmV0dXJuIE9iamVjdC5rZXlzKG9iamVjdFJlZi52YWx1ZSk7XG5cdFx0fSxcblx0XHRnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuXHRcdFx0XHRjb25maWd1cmFibGU6IHRydWVcblx0XHRcdH07XG5cdFx0fVxuXHR9KSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiByZWFjdGl2ZUNvbXB1dGVkL2luZGV4LnRzXG4vKipcbiogQ29tcHV0ZWQgcmVhY3RpdmUgb2JqZWN0LlxuKi9cbmZ1bmN0aW9uIHJlYWN0aXZlQ29tcHV0ZWQoZm4pIHtcblx0cmV0dXJuIHRvUmVhY3RpdmUoY29tcHV0ZWQoZm4pKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHJlYWN0aXZlT21pdC9pbmRleC50c1xuLyoqXG4qIFJlYWN0aXZlbHkgb21pdCBmaWVsZHMgZnJvbSBhIHJlYWN0aXZlIG9iamVjdFxuKlxuKiBAc2VlIGh0dHBzOi8vdnVldXNlLm9yZy9yZWFjdGl2ZU9taXRcbiovXG5mdW5jdGlvbiByZWFjdGl2ZU9taXQob2JqLCAuLi5rZXlzKSB7XG5cdGNvbnN0IGZsYXRLZXlzID0ga2V5cy5mbGF0KCk7XG5cdGNvbnN0IHByZWRpY2F0ZSA9IGZsYXRLZXlzWzBdO1xuXHRyZXR1cm4gcmVhY3RpdmVDb21wdXRlZCgoKSA9PiB0eXBlb2YgcHJlZGljYXRlID09PSBcImZ1bmN0aW9uXCIgPyBPYmplY3QuZnJvbUVudHJpZXMoT2JqZWN0LmVudHJpZXModG9SZWZzJDEob2JqKSkuZmlsdGVyKChbaywgdl0pID0+ICFwcmVkaWNhdGUodG9WYWx1ZSh2KSwgaykpKSA6IE9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyh0b1JlZnMkMShvYmopKS5maWx0ZXIoKGUpID0+ICFmbGF0S2V5cy5pbmNsdWRlcyhlWzBdKSkpKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHJlYWN0aXZlUGljay9pbmRleC50c1xuLyoqXG4qIFJlYWN0aXZlbHkgcGljayBmaWVsZHMgZnJvbSBhIHJlYWN0aXZlIG9iamVjdFxuKlxuKiBAc2VlIGh0dHBzOi8vdnVldXNlLm9yZy9yZWFjdGl2ZVBpY2tcbiovXG5mdW5jdGlvbiByZWFjdGl2ZVBpY2sob2JqLCAuLi5rZXlzKSB7XG5cdGNvbnN0IGZsYXRLZXlzID0ga2V5cy5mbGF0KCk7XG5cdGNvbnN0IHByZWRpY2F0ZSA9IGZsYXRLZXlzWzBdO1xuXHRyZXR1cm4gcmVhY3RpdmVDb21wdXRlZCgoKSA9PiB0eXBlb2YgcHJlZGljYXRlID09PSBcImZ1bmN0aW9uXCIgPyBPYmplY3QuZnJvbUVudHJpZXMoT2JqZWN0LmVudHJpZXModG9SZWZzJDEob2JqKSkuZmlsdGVyKChbaywgdl0pID0+IHByZWRpY2F0ZSh0b1ZhbHVlKHYpLCBrKSkpIDogT2JqZWN0LmZyb21FbnRyaWVzKGZsYXRLZXlzLm1hcCgoaykgPT4gW2ssIHRvUmVmKG9iaiwgayldKSkpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gcmVmQXV0b1Jlc2V0L2luZGV4LnRzXG4vKipcbiogQ3JlYXRlIGEgcmVmIHdoaWNoIHdpbGwgYmUgcmVzZXQgdG8gdGhlIGRlZmF1bHQgdmFsdWUgYWZ0ZXIgc29tZSB0aW1lLlxuKlxuKiBAc2VlIGh0dHBzOi8vdnVldXNlLm9yZy9yZWZBdXRvUmVzZXRcbiogQHBhcmFtIGRlZmF1bHRWYWx1ZSBUaGUgdmFsdWUgd2hpY2ggd2lsbCBiZSBzZXQuXG4qIEBwYXJhbSBhZnRlck1zICAgICAgQSB6ZXJvLW9yLWdyZWF0ZXIgZGVsYXkgaW4gbWlsbGlzZWNvbmRzLlxuKi9cbmZ1bmN0aW9uIHJlZkF1dG9SZXNldChkZWZhdWx0VmFsdWUsIGFmdGVyTXMgPSAxZTQpIHtcblx0cmV0dXJuIGN1c3RvbVJlZigodHJhY2ssIHRyaWdnZXIpID0+IHtcblx0XHRsZXQgdmFsdWUgPSB0b1ZhbHVlKGRlZmF1bHRWYWx1ZSk7XG5cdFx0bGV0IHRpbWVyO1xuXHRcdGNvbnN0IHJlc2V0QWZ0ZXIgPSAoKSA9PiBzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdHZhbHVlID0gdG9WYWx1ZShkZWZhdWx0VmFsdWUpO1xuXHRcdFx0dHJpZ2dlcigpO1xuXHRcdH0sIHRvVmFsdWUoYWZ0ZXJNcykpO1xuXHRcdHRyeU9uU2NvcGVEaXNwb3NlKCgpID0+IHtcblx0XHRcdGNsZWFyVGltZW91dCh0aW1lcik7XG5cdFx0fSk7XG5cdFx0cmV0dXJuIHtcblx0XHRcdGdldCgpIHtcblx0XHRcdFx0dHJhY2soKTtcblx0XHRcdFx0cmV0dXJuIHZhbHVlO1xuXHRcdFx0fSxcblx0XHRcdHNldChuZXdWYWx1ZSkge1xuXHRcdFx0XHR2YWx1ZSA9IG5ld1ZhbHVlO1xuXHRcdFx0XHR0cmlnZ2VyKCk7XG5cdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lcik7XG5cdFx0XHRcdHRpbWVyID0gcmVzZXRBZnRlcigpO1xuXHRcdFx0fVxuXHRcdH07XG5cdH0pO1xufVxuLyoqIEBkZXByZWNhdGVkIHVzZSBgcmVmQXV0b1Jlc2V0YCBpbnN0ZWFkICovXG5jb25zdCBhdXRvUmVzZXRSZWYgPSByZWZBdXRvUmVzZXQ7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiB1c2VEZWJvdW5jZUZuL2luZGV4LnRzXG4vKipcbiogRGVib3VuY2UgZXhlY3V0aW9uIG9mIGEgZnVuY3Rpb24uXG4qXG4qIEBzZWUgaHR0cHM6Ly92dWV1c2Uub3JnL3VzZURlYm91bmNlRm5cbiogQHBhcmFtICBmbiAgICAgICAgICBBIGZ1bmN0aW9uIHRvIGJlIGV4ZWN1dGVkIGFmdGVyIGRlbGF5IG1pbGxpc2Vjb25kcyBkZWJvdW5jZWQuXG4qIEBwYXJhbSAgbXMgICAgICAgICAgQSB6ZXJvLW9yLWdyZWF0ZXIgZGVsYXkgaW4gbWlsbGlzZWNvbmRzLiBGb3IgZXZlbnQgY2FsbGJhY2tzLCB2YWx1ZXMgYXJvdW5kIDEwMCBvciAyNTAgKG9yIGV2ZW4gaGlnaGVyKSBhcmUgbW9zdCB1c2VmdWwuXG4qIEBwYXJhbSAgb3B0aW9ucyAgICAgT3B0aW9uc1xuKlxuKiBAcmV0dXJuIEEgbmV3LCBkZWJvdW5jZWQsIGZ1bmN0aW9uIHdpdGggaXNQZW5kaW5nLCBjYW5jZWwsIGFuZCBmbHVzaCBwcm9wZXJ0aWVzLlxuKi9cbmZ1bmN0aW9uIHVzZURlYm91bmNlRm4oZm4sIG1zID0gMjAwLCBvcHRpb25zID0ge30pIHtcblx0cmV0dXJuIGNyZWF0ZUZpbHRlcldyYXBwZXIoZGVib3VuY2VGaWx0ZXIobXMsIG9wdGlvbnMpLCBmbik7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiByZWZEZWJvdW5jZWQvaW5kZXgudHNcbi8qKlxuKiBEZWJvdW5jZSB1cGRhdGVzIG9mIGEgcmVmLlxuKlxuKiBAcmV0dXJuIEEgbmV3IGRlYm91bmNlZCByZWYuXG4qL1xuZnVuY3Rpb24gcmVmRGVib3VuY2VkKHZhbHVlLCBtcyA9IDIwMCwgb3B0aW9ucyA9IHt9KSB7XG5cdGNvbnN0IGRlYm91bmNlZCA9IHJlZih0b1ZhbHVlKHZhbHVlKSk7XG5cdGNvbnN0IHVwZGF0ZXIgPSB1c2VEZWJvdW5jZUZuKCgpID0+IHtcblx0XHRkZWJvdW5jZWQudmFsdWUgPSB2YWx1ZS52YWx1ZTtcblx0fSwgbXMsIG9wdGlvbnMpO1xuXHR3YXRjaCh2YWx1ZSwgKCkgPT4gdXBkYXRlcigpKTtcblx0cmV0dXJuIHNoYWxsb3dSZWFkb25seShkZWJvdW5jZWQpO1xufVxuLyoqIEBkZXByZWNhdGVkIHVzZSBgcmVmRGVib3VuY2VkYCBpbnN0ZWFkICovXG5jb25zdCBkZWJvdW5jZWRSZWYgPSByZWZEZWJvdW5jZWQ7XG4vKiogQGRlcHJlY2F0ZWQgdXNlIGByZWZEZWJvdW5jZWRgIGluc3RlYWQgKi9cbmNvbnN0IHVzZURlYm91bmNlID0gcmVmRGVib3VuY2VkO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gcmVmRGVmYXVsdC9pbmRleC50c1xuLyoqXG4qIEFwcGx5IGRlZmF1bHQgdmFsdWUgdG8gYSByZWYuXG4qXG4qIEBfX05PX1NJREVfRUZGRUNUU19fXG4qL1xuZnVuY3Rpb24gcmVmRGVmYXVsdChzb3VyY2UsIGRlZmF1bHRWYWx1ZSkge1xuXHRyZXR1cm4gY29tcHV0ZWQoe1xuXHRcdGdldCgpIHtcblx0XHRcdHZhciBfc291cmNlJHZhbHVlO1xuXHRcdFx0cmV0dXJuIChfc291cmNlJHZhbHVlID0gc291cmNlLnZhbHVlKSAhPT0gbnVsbCAmJiBfc291cmNlJHZhbHVlICE9PSB2b2lkIDAgPyBfc291cmNlJHZhbHVlIDogZGVmYXVsdFZhbHVlO1xuXHRcdH0sXG5cdFx0c2V0KHZhbHVlKSB7XG5cdFx0XHRzb3VyY2UudmFsdWUgPSB2YWx1ZTtcblx0XHR9XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gcmVmTWFudWFsUmVzZXQvaW5kZXgudHNcbi8qKlxuKiBDcmVhdGUgYSByZWYgd2l0aCBtYW51YWwgcmVzZXQgZnVuY3Rpb25hbGl0eS5cbipcbiogQHNlZSBodHRwczovL3Z1ZXVzZS5vcmcvcmVmTWFudWFsUmVzZXRcbiogQHBhcmFtIGRlZmF1bHRWYWx1ZSBUaGUgdmFsdWUgd2hpY2ggd2lsbCBiZSBzZXQuXG4qL1xuZnVuY3Rpb24gcmVmTWFudWFsUmVzZXQoZGVmYXVsdFZhbHVlKSB7XG5cdGxldCB2YWx1ZSA9IHRvVmFsdWUoZGVmYXVsdFZhbHVlKTtcblx0bGV0IHRyaWdnZXI7XG5cdGNvbnN0IHJlc2V0ID0gKCkgPT4ge1xuXHRcdHZhbHVlID0gdG9WYWx1ZShkZWZhdWx0VmFsdWUpO1xuXHRcdHRyaWdnZXIoKTtcblx0fTtcblx0Y29uc3QgcmVmVmFsdWUgPSBjdXN0b21SZWYoKHRyYWNrLCBfdHJpZ2dlcikgPT4ge1xuXHRcdHRyaWdnZXIgPSBfdHJpZ2dlcjtcblx0XHRyZXR1cm4ge1xuXHRcdFx0Z2V0KCkge1xuXHRcdFx0XHR0cmFjaygpO1xuXHRcdFx0XHRyZXR1cm4gdmFsdWU7XG5cdFx0XHR9LFxuXHRcdFx0c2V0KG5ld1ZhbHVlKSB7XG5cdFx0XHRcdHZhbHVlID0gbmV3VmFsdWU7XG5cdFx0XHRcdHRyaWdnZXIoKTtcblx0XHRcdH1cblx0XHR9O1xuXHR9KTtcblx0cmVmVmFsdWUucmVzZXQgPSByZXNldDtcblx0cmV0dXJuIHJlZlZhbHVlO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gdXNlVGhyb3R0bGVGbi9pbmRleC50c1xuLyoqXG4qIFRocm90dGxlIGV4ZWN1dGlvbiBvZiBhIGZ1bmN0aW9uLiBFc3BlY2lhbGx5IHVzZWZ1bCBmb3IgcmF0ZSBsaW1pdGluZ1xuKiBleGVjdXRpb24gb2YgaGFuZGxlcnMgb24gZXZlbnRzIGxpa2UgcmVzaXplIGFuZCBzY3JvbGwuXG4qXG4qIEBwYXJhbSAgIGZuICAgICAgICAgICAgIEEgZnVuY3Rpb24gdG8gYmUgZXhlY3V0ZWQgYWZ0ZXIgZGVsYXkgbWlsbGlzZWNvbmRzLiBUaGUgYHRoaXNgIGNvbnRleHQgYW5kIGFsbCBhcmd1bWVudHMgYXJlIHBhc3NlZCB0aHJvdWdoLCBhcy1pcyxcbiogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0byBgY2FsbGJhY2tgIHdoZW4gdGhlIHRocm90dGxlZC1mdW5jdGlvbiBpcyBleGVjdXRlZC5cbiogQHBhcmFtICAgbXMgICAgICAgICAgICAgQSB6ZXJvLW9yLWdyZWF0ZXIgZGVsYXkgaW4gbWlsbGlzZWNvbmRzLiBGb3IgZXZlbnQgY2FsbGJhY2tzLCB2YWx1ZXMgYXJvdW5kIDEwMCBvciAyNTAgKG9yIGV2ZW4gaGlnaGVyKSBhcmUgbW9zdCB1c2VmdWwuXG4qICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKGRlZmF1bHQgdmFsdWU6IDIwMClcbipcbiogQHBhcmFtIFt0cmFpbGluZ10gaWYgdHJ1ZSwgY2FsbCBmbiBhZ2FpbiBhZnRlciB0aGUgdGltZSBpcyB1cCAoZGVmYXVsdCB2YWx1ZTogZmFsc2UpXG4qXG4qIEBwYXJhbSBbbGVhZGluZ10gaWYgdHJ1ZSwgY2FsbCBmbiBvbiB0aGUgbGVhZGluZyBlZGdlIG9mIHRoZSBtcyB0aW1lb3V0IChkZWZhdWx0IHZhbHVlOiB0cnVlKVxuKlxuKiBAcGFyYW0gW3JlamVjdE9uQ2FuY2VsXSBpZiB0cnVlLCByZWplY3QgdGhlIGxhc3QgY2FsbCBpZiBpdCdzIGJlZW4gY2FuY2VsIChkZWZhdWx0IHZhbHVlOiBmYWxzZSlcbipcbiogQHJldHVybiAgQSBuZXcsIHRocm90dGxlZCwgZnVuY3Rpb24uXG4qXG4qIEBfX05PX1NJREVfRUZGRUNUU19fXG4qL1xuZnVuY3Rpb24gdXNlVGhyb3R0bGVGbihmbiwgbXMgPSAyMDAsIHRyYWlsaW5nID0gZmFsc2UsIGxlYWRpbmcgPSB0cnVlLCByZWplY3RPbkNhbmNlbCA9IGZhbHNlKSB7XG5cdHJldHVybiBjcmVhdGVGaWx0ZXJXcmFwcGVyKHRocm90dGxlRmlsdGVyKG1zLCB0cmFpbGluZywgbGVhZGluZywgcmVqZWN0T25DYW5jZWwpLCBmbik7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiByZWZUaHJvdHRsZWQvaW5kZXgudHNcbi8qKlxuKiBUaHJvdHRsZSBleGVjdXRpb24gb2YgYSBmdW5jdGlvbi4gRXNwZWNpYWxseSB1c2VmdWwgZm9yIHJhdGUgbGltaXRpbmdcbiogZXhlY3V0aW9uIG9mIGhhbmRsZXJzIG9uIGV2ZW50cyBsaWtlIHJlc2l6ZSBhbmQgc2Nyb2xsLlxuKlxuKiBAcGFyYW0gdmFsdWUgUmVmIHZhbHVlIHRvIGJlIHdhdGNoZWQgd2l0aCB0aHJvdHRsZSBlZmZlY3RcbiogQHBhcmFtICBkZWxheSAgQSB6ZXJvLW9yLWdyZWF0ZXIgZGVsYXkgaW4gbWlsbGlzZWNvbmRzLiBGb3IgZXZlbnQgY2FsbGJhY2tzLCB2YWx1ZXMgYXJvdW5kIDEwMCBvciAyNTAgKG9yIGV2ZW4gaGlnaGVyKSBhcmUgbW9zdCB1c2VmdWwuXG4qIEBwYXJhbSB0cmFpbGluZyBpZiB0cnVlLCB1cGRhdGUgdGhlIHZhbHVlIGFnYWluIGFmdGVyIHRoZSBkZWxheSB0aW1lIGlzIHVwXG4qIEBwYXJhbSBsZWFkaW5nIGlmIHRydWUsIHVwZGF0ZSB0aGUgdmFsdWUgb24gdGhlIGxlYWRpbmcgZWRnZSBvZiB0aGUgbXMgdGltZW91dFxuKi9cbmZ1bmN0aW9uIHJlZlRocm90dGxlZCh2YWx1ZSwgZGVsYXkgPSAyMDAsIHRyYWlsaW5nID0gdHJ1ZSwgbGVhZGluZyA9IHRydWUpIHtcblx0aWYgKGRlbGF5IDw9IDApIHJldHVybiB2YWx1ZTtcblx0Y29uc3QgdGhyb3R0bGVkID0gcmVmKHRvVmFsdWUodmFsdWUpKTtcblx0Y29uc3QgdXBkYXRlciA9IHVzZVRocm90dGxlRm4oKCkgPT4ge1xuXHRcdHRocm90dGxlZC52YWx1ZSA9IHZhbHVlLnZhbHVlO1xuXHR9LCBkZWxheSwgdHJhaWxpbmcsIGxlYWRpbmcpO1xuXHR3YXRjaCh2YWx1ZSwgKCkgPT4gdXBkYXRlcigpKTtcblx0cmV0dXJuIHRocm90dGxlZDtcbn1cbi8qKiBAZGVwcmVjYXRlZCB1c2UgYHJlZlRocm90dGxlZGAgaW5zdGVhZCAqL1xuY29uc3QgdGhyb3R0bGVkUmVmID0gcmVmVGhyb3R0bGVkO1xuLyoqIEBkZXByZWNhdGVkIHVzZSBgcmVmVGhyb3R0bGVkYCBpbnN0ZWFkICovXG5jb25zdCB1c2VUaHJvdHRsZSA9IHJlZlRocm90dGxlZDtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHJlZldpdGhDb250cm9sL2luZGV4LnRzXG4vKipcbiogRmluZS1ncmFpbmVkIGNvbnRyb2xzIG92ZXIgcmVmIGFuZCBpdHMgcmVhY3Rpdml0eS5cbipcbiogQF9fTk9fU0lERV9FRkZFQ1RTX19cbiovXG5mdW5jdGlvbiByZWZXaXRoQ29udHJvbChpbml0aWFsLCBvcHRpb25zID0ge30pIHtcblx0bGV0IHNvdXJjZSA9IGluaXRpYWw7XG5cdGxldCB0cmFjaztcblx0bGV0IHRyaWdnZXI7XG5cdGNvbnN0IHJlZiA9IGN1c3RvbVJlZigoX3RyYWNrLCBfdHJpZ2dlcikgPT4ge1xuXHRcdHRyYWNrID0gX3RyYWNrO1xuXHRcdHRyaWdnZXIgPSBfdHJpZ2dlcjtcblx0XHRyZXR1cm4ge1xuXHRcdFx0Z2V0KCkge1xuXHRcdFx0XHRyZXR1cm4gZ2V0KCk7XG5cdFx0XHR9LFxuXHRcdFx0c2V0KHYpIHtcblx0XHRcdFx0c2V0KHYpO1xuXHRcdFx0fVxuXHRcdH07XG5cdH0pO1xuXHRmdW5jdGlvbiBnZXQodHJhY2tpbmcgPSB0cnVlKSB7XG5cdFx0aWYgKHRyYWNraW5nKSB0cmFjaygpO1xuXHRcdHJldHVybiBzb3VyY2U7XG5cdH1cblx0ZnVuY3Rpb24gc2V0KHZhbHVlLCB0cmlnZ2VyaW5nID0gdHJ1ZSkge1xuXHRcdHZhciBfb3B0aW9ucyRvbkJlZm9yZUNoYW4sIF9vcHRpb25zJG9uQ2hhbmdlZDtcblx0XHRpZiAodmFsdWUgPT09IHNvdXJjZSkgcmV0dXJuO1xuXHRcdGNvbnN0IG9sZCA9IHNvdXJjZTtcblx0XHRpZiAoKChfb3B0aW9ucyRvbkJlZm9yZUNoYW4gPSBvcHRpb25zLm9uQmVmb3JlQ2hhbmdlKSA9PT0gbnVsbCB8fCBfb3B0aW9ucyRvbkJlZm9yZUNoYW4gPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9vcHRpb25zJG9uQmVmb3JlQ2hhbi5jYWxsKG9wdGlvbnMsIHZhbHVlLCBvbGQpKSA9PT0gZmFsc2UpIHJldHVybjtcblx0XHRzb3VyY2UgPSB2YWx1ZTtcblx0XHQoX29wdGlvbnMkb25DaGFuZ2VkID0gb3B0aW9ucy5vbkNoYW5nZWQpID09PSBudWxsIHx8IF9vcHRpb25zJG9uQ2hhbmdlZCA9PT0gdm9pZCAwIHx8IF9vcHRpb25zJG9uQ2hhbmdlZC5jYWxsKG9wdGlvbnMsIHZhbHVlLCBvbGQpO1xuXHRcdGlmICh0cmlnZ2VyaW5nKSB0cmlnZ2VyKCk7XG5cdH1cblx0LyoqXG5cdCogR2V0IHRoZSB2YWx1ZSB3aXRob3V0IHRyYWNrZWQgaW4gdGhlIHJlYWN0aXZpdHkgc3lzdGVtXG5cdCovXG5cdGNvbnN0IHVudHJhY2tlZEdldCA9ICgpID0+IGdldChmYWxzZSk7XG5cdC8qKlxuXHQqIFNldCB0aGUgdmFsdWUgd2l0aG91dCB0cmlnZ2VyaW5nIHRoZSByZWFjdGl2aXR5IHN5c3RlbVxuXHQqL1xuXHRjb25zdCBzaWxlbnRTZXQgPSAodikgPT4gc2V0KHYsIGZhbHNlKTtcblx0LyoqXG5cdCogR2V0IHRoZSB2YWx1ZSB3aXRob3V0IHRyYWNrZWQgaW4gdGhlIHJlYWN0aXZpdHkgc3lzdGVtLlxuXHQqXG5cdCogQWxpYXMgZm9yIGB1bnRyYWNrZWRHZXQoKWBcblx0Ki9cblx0Y29uc3QgcGVlayA9ICgpID0+IGdldChmYWxzZSk7XG5cdC8qKlxuXHQqIFNldCB0aGUgdmFsdWUgd2l0aG91dCB0cmlnZ2VyaW5nIHRoZSByZWFjdGl2aXR5IHN5c3RlbVxuXHQqXG5cdCogQWxpYXMgZm9yIGBzaWxlbnRTZXQodilgXG5cdCovXG5cdGNvbnN0IGxheSA9ICh2KSA9PiBzZXQodiwgZmFsc2UpO1xuXHRyZXR1cm4gZXh0ZW5kUmVmKHJlZiwge1xuXHRcdGdldCxcblx0XHRzZXQsXG5cdFx0dW50cmFja2VkR2V0LFxuXHRcdHNpbGVudFNldCxcblx0XHRwZWVrLFxuXHRcdGxheVxuXHR9LCB7IGVudW1lcmFibGU6IHRydWUgfSk7XG59XG4vKiogQGRlcHJlY2F0ZWQgdXNlIGByZWZXaXRoQ29udHJvbGAgaW5zdGVhZCAqL1xuY29uc3QgY29udHJvbGxlZFJlZiA9IHJlZldpdGhDb250cm9sO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc2V0L2luZGV4LnRzXG4vKipcbiogIFNob3J0aGFuZCBmb3IgYHJlZi52YWx1ZSA9IHhgXG4qL1xuZnVuY3Rpb24gc2V0KC4uLmFyZ3MpIHtcblx0aWYgKGFyZ3MubGVuZ3RoID09PSAyKSB7XG5cdFx0Y29uc3QgW3JlZiwgdmFsdWVdID0gYXJncztcblx0XHRyZWYudmFsdWUgPSB2YWx1ZTtcblx0fVxuXHRpZiAoYXJncy5sZW5ndGggPT09IDMpIHtcblx0XHRjb25zdCBbdGFyZ2V0LCBrZXksIHZhbHVlXSA9IGFyZ3M7XG5cdFx0dGFyZ2V0W2tleV0gPSB2YWx1ZTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gd2F0Y2hXaXRoRmlsdGVyL2luZGV4LnRzXG5mdW5jdGlvbiB3YXRjaFdpdGhGaWx0ZXIoc291cmNlLCBjYiwgb3B0aW9ucyA9IHt9KSB7XG5cdGNvbnN0IHsgZXZlbnRGaWx0ZXIgPSBieXBhc3NGaWx0ZXIsIC4uLndhdGNoT3B0aW9ucyB9ID0gb3B0aW9ucztcblx0cmV0dXJuIHdhdGNoKHNvdXJjZSwgY3JlYXRlRmlsdGVyV3JhcHBlcihldmVudEZpbHRlciwgY2IpLCB3YXRjaE9wdGlvbnMpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gd2F0Y2hQYXVzYWJsZS9pbmRleC50c1xuLyoqIEBkZXByZWNhdGVkIFVzZSBWdWUncyBidWlsdC1pbiBgd2F0Y2hgIGluc3RlYWQuIFRoaXMgZnVuY3Rpb24gd2lsbCBiZSByZW1vdmVkIGluIGZ1dHVyZSB2ZXJzaW9uLiAqL1xuZnVuY3Rpb24gd2F0Y2hQYXVzYWJsZShzb3VyY2UsIGNiLCBvcHRpb25zID0ge30pIHtcblx0Y29uc3QgeyBldmVudEZpbHRlcjogZmlsdGVyLCBpbml0aWFsU3RhdGUgPSBcImFjdGl2ZVwiLCAuLi53YXRjaE9wdGlvbnMgfSA9IG9wdGlvbnM7XG5cdGNvbnN0IHsgZXZlbnRGaWx0ZXIsIHBhdXNlLCByZXN1bWUsIGlzQWN0aXZlIH0gPSBwYXVzYWJsZUZpbHRlcihmaWx0ZXIsIHsgaW5pdGlhbFN0YXRlIH0pO1xuXHRyZXR1cm4ge1xuXHRcdHN0b3A6IHdhdGNoV2l0aEZpbHRlcihzb3VyY2UsIGNiLCB7XG5cdFx0XHQuLi53YXRjaE9wdGlvbnMsXG5cdFx0XHRldmVudEZpbHRlclxuXHRcdH0pLFxuXHRcdHBhdXNlLFxuXHRcdHJlc3VtZSxcblx0XHRpc0FjdGl2ZVxuXHR9O1xufVxuLyoqIEBkZXByZWNhdGVkIFVzZSBWdWUncyBidWlsdC1pbiBgd2F0Y2hgIGluc3RlYWQuIFRoaXMgZnVuY3Rpb24gd2lsbCBiZSByZW1vdmVkIGluIGZ1dHVyZSB2ZXJzaW9uLiAqL1xuY29uc3QgcGF1c2FibGVXYXRjaCA9IHdhdGNoUGF1c2FibGU7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzeW5jUmVmL2luZGV4LnRzXG4vKipcbiogVHdvLXdheSByZWZzIHN5bmNocm9uaXphdGlvbi5cbiogRnJvbSB0aGUgc2V0IHRoZW9yeSBwZXJzcGVjdGl2ZSB0byByZXN0cmljdCB0aGUgb3B0aW9uJ3MgdHlwZVxuKiBDaGVjayBpbiB0aGUgZm9sbG93aW5nIG9yZGVyOlxuKiAxLiBMID0gUlxuKiAyLiBMIOKIqSBSIOKJoCDiiIVcbiogMy4gTCDiioYgUlxuKiA0LiBMIOKIqSBSID0g4oiFXG4qL1xuZnVuY3Rpb24gc3luY1JlZihsZWZ0LCByaWdodCwgLi4uW29wdGlvbnNdKSB7XG5cdGNvbnN0IHsgZmx1c2ggPSBcInN5bmNcIiwgZGVlcCA9IGZhbHNlLCBpbW1lZGlhdGUgPSB0cnVlLCBkaXJlY3Rpb24gPSBcImJvdGhcIiwgdHJhbnNmb3JtID0ge30gfSA9IG9wdGlvbnMgfHwge307XG5cdGNvbnN0IHdhdGNoZXJzID0gW107XG5cdGNvbnN0IHRyYW5zZm9ybUxUUiA9IFwibHRyXCIgaW4gdHJhbnNmb3JtICYmIHRyYW5zZm9ybS5sdHIgfHwgKCh2KSA9PiB2KTtcblx0Y29uc3QgdHJhbnNmb3JtUlRMID0gXCJydGxcIiBpbiB0cmFuc2Zvcm0gJiYgdHJhbnNmb3JtLnJ0bCB8fCAoKHYpID0+IHYpO1xuXHRpZiAoZGlyZWN0aW9uID09PSBcImJvdGhcIiB8fCBkaXJlY3Rpb24gPT09IFwibHRyXCIpIHdhdGNoZXJzLnB1c2god2F0Y2hQYXVzYWJsZShsZWZ0LCAobmV3VmFsdWUpID0+IHtcblx0XHR3YXRjaGVycy5mb3JFYWNoKCh3KSA9PiB3LnBhdXNlKCkpO1xuXHRcdHJpZ2h0LnZhbHVlID0gdHJhbnNmb3JtTFRSKG5ld1ZhbHVlKTtcblx0XHR3YXRjaGVycy5mb3JFYWNoKCh3KSA9PiB3LnJlc3VtZSgpKTtcblx0fSwge1xuXHRcdGZsdXNoLFxuXHRcdGRlZXAsXG5cdFx0aW1tZWRpYXRlXG5cdH0pKTtcblx0aWYgKGRpcmVjdGlvbiA9PT0gXCJib3RoXCIgfHwgZGlyZWN0aW9uID09PSBcInJ0bFwiKSB3YXRjaGVycy5wdXNoKHdhdGNoUGF1c2FibGUocmlnaHQsIChuZXdWYWx1ZSkgPT4ge1xuXHRcdHdhdGNoZXJzLmZvckVhY2goKHcpID0+IHcucGF1c2UoKSk7XG5cdFx0bGVmdC52YWx1ZSA9IHRyYW5zZm9ybVJUTChuZXdWYWx1ZSk7XG5cdFx0d2F0Y2hlcnMuZm9yRWFjaCgodykgPT4gdy5yZXN1bWUoKSk7XG5cdH0sIHtcblx0XHRmbHVzaCxcblx0XHRkZWVwLFxuXHRcdGltbWVkaWF0ZVxuXHR9KSk7XG5cdGNvbnN0IHN0b3AgPSAoKSA9PiB7XG5cdFx0d2F0Y2hlcnMuZm9yRWFjaCgodykgPT4gdy5zdG9wKCkpO1xuXHR9O1xuXHRyZXR1cm4gc3RvcDtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHN5bmNSZWZzL2luZGV4LnRzXG4vKipcbiogS2VlcCB0YXJnZXQgcmVmKHMpIGluIHN5bmMgd2l0aCB0aGUgc291cmNlIHJlZlxuKlxuKiBAcGFyYW0gc291cmNlIHNvdXJjZSByZWZcbiogQHBhcmFtIHRhcmdldHNcbiovXG5mdW5jdGlvbiBzeW5jUmVmcyhzb3VyY2UsIHRhcmdldHMsIG9wdGlvbnMgPSB7fSkge1xuXHRjb25zdCB7IGZsdXNoID0gXCJzeW5jXCIsIGRlZXAgPSBmYWxzZSwgaW1tZWRpYXRlID0gdHJ1ZSB9ID0gb3B0aW9ucztcblx0Y29uc3QgdGFyZ2V0c0FycmF5ID0gdG9BcnJheSh0YXJnZXRzKTtcblx0cmV0dXJuIHdhdGNoKHNvdXJjZSwgKG5ld1ZhbHVlKSA9PiB0YXJnZXRzQXJyYXkuZm9yRWFjaCgodGFyZ2V0KSA9PiB0YXJnZXQudmFsdWUgPSBuZXdWYWx1ZSksIHtcblx0XHRmbHVzaCxcblx0XHRkZWVwLFxuXHRcdGltbWVkaWF0ZVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHRvUmVmcy9pbmRleC50c1xuLyoqXG4qIEV4dGVuZGVkIGB0b1JlZnNgIHRoYXQgYWxzbyBhY2NlcHRzIHJlZnMgb2YgYW4gb2JqZWN0LlxuKlxuKiBAc2VlIGh0dHBzOi8vdnVldXNlLm9yZy90b1JlZnNcbiogQHBhcmFtIG9iamVjdFJlZiBBIHJlZiBvciBub3JtYWwgb2JqZWN0IG9yIGFycmF5LlxuKiBAcGFyYW0gb3B0aW9ucyBPcHRpb25zXG4qL1xuZnVuY3Rpb24gdG9SZWZzKG9iamVjdFJlZiwgb3B0aW9ucyA9IHt9KSB7XG5cdGlmICghaXNSZWYob2JqZWN0UmVmKSkgcmV0dXJuIHRvUmVmcyQxKG9iamVjdFJlZik7XG5cdGNvbnN0IHJlc3VsdCA9IEFycmF5LmlzQXJyYXkob2JqZWN0UmVmLnZhbHVlKSA/IEFycmF5LmZyb20oeyBsZW5ndGg6IG9iamVjdFJlZi52YWx1ZS5sZW5ndGggfSkgOiB7fTtcblx0Zm9yIChjb25zdCBrZXkgaW4gb2JqZWN0UmVmLnZhbHVlKSByZXN1bHRba2V5XSA9IGN1c3RvbVJlZigoKSA9PiAoe1xuXHRcdGdldCgpIHtcblx0XHRcdHJldHVybiBvYmplY3RSZWYudmFsdWVba2V5XTtcblx0XHR9LFxuXHRcdHNldCh2KSB7XG5cdFx0XHR2YXIgX3RvVmFsdWU7XG5cdFx0XHRpZiAoKF90b1ZhbHVlID0gdG9WYWx1ZShvcHRpb25zLnJlcGxhY2VSZWYpKSAhPT0gbnVsbCAmJiBfdG9WYWx1ZSAhPT0gdm9pZCAwID8gX3RvVmFsdWUgOiB0cnVlKSBpZiAoQXJyYXkuaXNBcnJheShvYmplY3RSZWYudmFsdWUpKSB7XG5cdFx0XHRcdGNvbnN0IGNvcHkgPSBbLi4ub2JqZWN0UmVmLnZhbHVlXTtcblx0XHRcdFx0Y29weVtrZXldID0gdjtcblx0XHRcdFx0b2JqZWN0UmVmLnZhbHVlID0gY29weTtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGNvbnN0IG5ld09iamVjdCA9IHtcblx0XHRcdFx0XHQuLi5vYmplY3RSZWYudmFsdWUsXG5cdFx0XHRcdFx0W2tleV06IHZcblx0XHRcdFx0fTtcblx0XHRcdFx0T2JqZWN0LnNldFByb3RvdHlwZU9mKG5ld09iamVjdCwgT2JqZWN0LmdldFByb3RvdHlwZU9mKG9iamVjdFJlZi52YWx1ZSkpO1xuXHRcdFx0XHRvYmplY3RSZWYudmFsdWUgPSBuZXdPYmplY3Q7XG5cdFx0XHR9XG5cdFx0XHRlbHNlIG9iamVjdFJlZi52YWx1ZVtrZXldID0gdjtcblx0XHR9XG5cdH0pKTtcblx0cmV0dXJuIHJlc3VsdDtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHRyeU9uQmVmb3JlTW91bnQvaW5kZXgudHNcbi8qKlxuKiBDYWxsIG9uQmVmb3JlTW91bnQoKSBpZiBpdCdzIGluc2lkZSBhIGNvbXBvbmVudCBsaWZlY3ljbGUsIGlmIG5vdCwganVzdCBjYWxsIHRoZSBmdW5jdGlvblxuKlxuKiBAcGFyYW0gZm5cbiogQHBhcmFtIHN5bmMgaWYgc2V0IHRvIGZhbHNlLCBpdCB3aWxsIHJ1biBpbiB0aGUgbmV4dFRpY2soKSBvZiBWdWVcbiogQHBhcmFtIHRhcmdldFxuKi9cbmZ1bmN0aW9uIHRyeU9uQmVmb3JlTW91bnQoZm4sIHN5bmMgPSB0cnVlLCB0YXJnZXQpIHtcblx0aWYgKGdldExpZmVDeWNsZVRhcmdldCh0YXJnZXQpKSBvbkJlZm9yZU1vdW50KGZuLCB0YXJnZXQpO1xuXHRlbHNlIGlmIChzeW5jKSBmbigpO1xuXHRlbHNlIG5leHRUaWNrKGZuKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHRyeU9uQmVmb3JlVW5tb3VudC9pbmRleC50c1xuLyoqXG4qIENhbGwgb25CZWZvcmVVbm1vdW50KCkgaWYgaXQncyBpbnNpZGUgYSBjb21wb25lbnQgbGlmZWN5Y2xlLCBpZiBub3QsIGRvIG5vdGhpbmdcbipcbiogQHBhcmFtIGZuXG4qIEBwYXJhbSB0YXJnZXRcbiovXG5mdW5jdGlvbiB0cnlPbkJlZm9yZVVubW91bnQoZm4sIHRhcmdldCkge1xuXHRpZiAoZ2V0TGlmZUN5Y2xlVGFyZ2V0KHRhcmdldCkpIG9uQmVmb3JlVW5tb3VudChmbiwgdGFyZ2V0KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHRyeU9uTW91bnRlZC9pbmRleC50c1xuLyoqXG4qIENhbGwgb25Nb3VudGVkKCkgaWYgaXQncyBpbnNpZGUgYSBjb21wb25lbnQgbGlmZWN5Y2xlLCBpZiBub3QsIGp1c3QgY2FsbCB0aGUgZnVuY3Rpb25cbipcbiogQHBhcmFtIGZuXG4qIEBwYXJhbSBzeW5jIGlmIHNldCB0byBmYWxzZSwgaXQgd2lsbCBydW4gaW4gdGhlIG5leHRUaWNrKCkgb2YgVnVlXG4qIEBwYXJhbSB0YXJnZXRcbiovXG5mdW5jdGlvbiB0cnlPbk1vdW50ZWQoZm4sIHN5bmMgPSB0cnVlLCB0YXJnZXQpIHtcblx0aWYgKGdldExpZmVDeWNsZVRhcmdldCh0YXJnZXQpKSBvbk1vdW50ZWQoZm4sIHRhcmdldCk7XG5cdGVsc2UgaWYgKHN5bmMpIGZuKCk7XG5cdGVsc2UgbmV4dFRpY2soZm4pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gdHJ5T25Vbm1vdW50ZWQvaW5kZXgudHNcbi8qKlxuKiBDYWxsIG9uVW5tb3VudGVkKCkgaWYgaXQncyBpbnNpZGUgYSBjb21wb25lbnQgbGlmZWN5Y2xlLCBpZiBub3QsIGRvIG5vdGhpbmdcbipcbiogQHBhcmFtIGZuXG4qIEBwYXJhbSB0YXJnZXRcbiovXG5mdW5jdGlvbiB0cnlPblVubW91bnRlZChmbiwgdGFyZ2V0KSB7XG5cdGlmIChnZXRMaWZlQ3ljbGVUYXJnZXQodGFyZ2V0KSkgb25Vbm1vdW50ZWQoZm4sIHRhcmdldCk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiB1bnRpbC9pbmRleC50c1xuZnVuY3Rpb24gY3JlYXRlVW50aWwociwgaXNOb3QgPSBmYWxzZSkge1xuXHRmdW5jdGlvbiB0b01hdGNoKGNvbmRpdGlvbiwgeyBmbHVzaCA9IFwic3luY1wiLCBkZWVwID0gZmFsc2UsIHRpbWVvdXQsIHRocm93T25UaW1lb3V0IH0gPSB7fSkge1xuXHRcdGxldCBzdG9wID0gbnVsbDtcblx0XHRjb25zdCBwcm9taXNlcyA9IFtuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuXHRcdFx0c3RvcCA9IHdhdGNoKHIsICh2KSA9PiB7XG5cdFx0XHRcdGlmIChjb25kaXRpb24odikgIT09IGlzTm90KSB7XG5cdFx0XHRcdFx0aWYgKHN0b3ApIHN0b3AoKTtcblx0XHRcdFx0XHRlbHNlIG5leHRUaWNrKCgpID0+IHN0b3AgPT09IG51bGwgfHwgc3RvcCA9PT0gdm9pZCAwID8gdm9pZCAwIDogc3RvcCgpKTtcblx0XHRcdFx0XHRyZXNvbHZlKHYpO1xuXHRcdFx0XHR9XG5cdFx0XHR9LCB7XG5cdFx0XHRcdGZsdXNoLFxuXHRcdFx0XHRkZWVwLFxuXHRcdFx0XHRpbW1lZGlhdGU6IHRydWVcblx0XHRcdH0pO1xuXHRcdH0pXTtcblx0XHRpZiAodGltZW91dCAhPSBudWxsKSBwcm9taXNlcy5wdXNoKHByb21pc2VUaW1lb3V0KHRpbWVvdXQsIHRocm93T25UaW1lb3V0KS50aGVuKCgpID0+IHRvVmFsdWUocikpLmZpbmFsbHkoKCkgPT4gc3RvcCA9PT0gbnVsbCB8fCBzdG9wID09PSB2b2lkIDAgPyB2b2lkIDAgOiBzdG9wKCkpKTtcblx0XHRyZXR1cm4gUHJvbWlzZS5yYWNlKHByb21pc2VzKTtcblx0fVxuXHRmdW5jdGlvbiB0b0JlKHZhbHVlLCBvcHRpb25zKSB7XG5cdFx0aWYgKCFpc1JlZih2YWx1ZSkpIHJldHVybiB0b01hdGNoKCh2KSA9PiB2ID09PSB2YWx1ZSwgb3B0aW9ucyk7XG5cdFx0Y29uc3QgeyBmbHVzaCA9IFwic3luY1wiLCBkZWVwID0gZmFsc2UsIHRpbWVvdXQsIHRocm93T25UaW1lb3V0IH0gPSBvcHRpb25zICE9PSBudWxsICYmIG9wdGlvbnMgIT09IHZvaWQgMCA/IG9wdGlvbnMgOiB7fTtcblx0XHRsZXQgc3RvcCA9IG51bGw7XG5cdFx0Y29uc3QgcHJvbWlzZXMgPSBbbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRcdHN0b3AgPSB3YXRjaChbciwgdmFsdWVdLCAoW3YxLCB2Ml0pID0+IHtcblx0XHRcdFx0aWYgKGlzTm90ICE9PSAodjEgPT09IHYyKSkge1xuXHRcdFx0XHRcdGlmIChzdG9wKSBzdG9wKCk7XG5cdFx0XHRcdFx0ZWxzZSBuZXh0VGljaygoKSA9PiBzdG9wID09PSBudWxsIHx8IHN0b3AgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHN0b3AoKSk7XG5cdFx0XHRcdFx0cmVzb2x2ZSh2MSk7XG5cdFx0XHRcdH1cblx0XHRcdH0sIHtcblx0XHRcdFx0Zmx1c2gsXG5cdFx0XHRcdGRlZXAsXG5cdFx0XHRcdGltbWVkaWF0ZTogdHJ1ZVxuXHRcdFx0fSk7XG5cdFx0fSldO1xuXHRcdGlmICh0aW1lb3V0ICE9IG51bGwpIHByb21pc2VzLnB1c2gocHJvbWlzZVRpbWVvdXQodGltZW91dCwgdGhyb3dPblRpbWVvdXQpLnRoZW4oKCkgPT4gdG9WYWx1ZShyKSkuZmluYWxseSgoKSA9PiB7XG5cdFx0XHRzdG9wID09PSBudWxsIHx8IHN0b3AgPT09IHZvaWQgMCB8fCBzdG9wKCk7XG5cdFx0XHRyZXR1cm4gdG9WYWx1ZShyKTtcblx0XHR9KSk7XG5cdFx0cmV0dXJuIFByb21pc2UucmFjZShwcm9taXNlcyk7XG5cdH1cblx0ZnVuY3Rpb24gdG9CZVRydXRoeShvcHRpb25zKSB7XG5cdFx0cmV0dXJuIHRvTWF0Y2goKHYpID0+IEJvb2xlYW4odiksIG9wdGlvbnMpO1xuXHR9XG5cdGZ1bmN0aW9uIHRvQmVOdWxsKG9wdGlvbnMpIHtcblx0XHRyZXR1cm4gdG9CZShudWxsLCBvcHRpb25zKTtcblx0fVxuXHRmdW5jdGlvbiB0b0JlVW5kZWZpbmVkKG9wdGlvbnMpIHtcblx0XHRyZXR1cm4gdG9CZSh2b2lkIDAsIG9wdGlvbnMpO1xuXHR9XG5cdGZ1bmN0aW9uIHRvQmVOYU4ob3B0aW9ucykge1xuXHRcdHJldHVybiB0b01hdGNoKE51bWJlci5pc05hTiwgb3B0aW9ucyk7XG5cdH1cblx0ZnVuY3Rpb24gdG9Db250YWlucyh2YWx1ZSwgb3B0aW9ucykge1xuXHRcdHJldHVybiB0b01hdGNoKCh2KSA9PiB7XG5cdFx0XHRjb25zdCBhcnJheSA9IEFycmF5LmZyb20odik7XG5cdFx0XHRyZXR1cm4gYXJyYXkuaW5jbHVkZXModmFsdWUpIHx8IGFycmF5LmluY2x1ZGVzKHRvVmFsdWUodmFsdWUpKTtcblx0XHR9LCBvcHRpb25zKTtcblx0fVxuXHRmdW5jdGlvbiBjaGFuZ2VkKG9wdGlvbnMpIHtcblx0XHRyZXR1cm4gY2hhbmdlZFRpbWVzKDEsIG9wdGlvbnMpO1xuXHR9XG5cdGZ1bmN0aW9uIGNoYW5nZWRUaW1lcyhuID0gMSwgb3B0aW9ucykge1xuXHRcdGxldCBjb3VudCA9IC0xO1xuXHRcdHJldHVybiB0b01hdGNoKCgpID0+IHtcblx0XHRcdGNvdW50ICs9IDE7XG5cdFx0XHRyZXR1cm4gY291bnQgPj0gbjtcblx0XHR9LCBvcHRpb25zKTtcblx0fVxuXHRpZiAoQXJyYXkuaXNBcnJheSh0b1ZhbHVlKHIpKSkgcmV0dXJuIHtcblx0XHR0b01hdGNoLFxuXHRcdHRvQ29udGFpbnMsXG5cdFx0Y2hhbmdlZCxcblx0XHRjaGFuZ2VkVGltZXMsXG5cdFx0Z2V0IG5vdCgpIHtcblx0XHRcdHJldHVybiBjcmVhdGVVbnRpbChyLCAhaXNOb3QpO1xuXHRcdH1cblx0fTtcblx0ZWxzZSByZXR1cm4ge1xuXHRcdHRvTWF0Y2gsXG5cdFx0dG9CZSxcblx0XHR0b0JlVHJ1dGh5LFxuXHRcdHRvQmVOdWxsLFxuXHRcdHRvQmVOYU4sXG5cdFx0dG9CZVVuZGVmaW5lZCxcblx0XHRjaGFuZ2VkLFxuXHRcdGNoYW5nZWRUaW1lcyxcblx0XHRnZXQgbm90KCkge1xuXHRcdFx0cmV0dXJuIGNyZWF0ZVVudGlsKHIsICFpc05vdCk7XG5cdFx0fVxuXHR9O1xufVxuZnVuY3Rpb24gdW50aWwocikge1xuXHRyZXR1cm4gY3JlYXRlVW50aWwocik7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiB1c2VBcnJheURpZmZlcmVuY2UvaW5kZXgudHNcbmZ1bmN0aW9uIGRlZmF1bHRDb21wYXJhdG9yKHZhbHVlLCBvdGhWYWwpIHtcblx0cmV0dXJuIHZhbHVlID09PSBvdGhWYWw7XG59XG4vKipcbiogUmVhY3RpdmUgZ2V0IGFycmF5IGRpZmZlcmVuY2Ugb2YgdHdvIGFycmF5XG4qIEBzZWUgaHR0cHM6Ly92dWV1c2Uub3JnL3VzZUFycmF5RGlmZmVyZW5jZVxuKiBAcmV0dXJucyAtIHRoZSBkaWZmZXJlbmNlIG9mIHR3byBhcnJheVxuKiBAcGFyYW0gYXJnc1xuKlxuKiBAX19OT19TSURFX0VGRkVDVFNfX1xuKi9cbmZ1bmN0aW9uIHVzZUFycmF5RGlmZmVyZW5jZSguLi5hcmdzKSB7XG5cdHZhciBfYXJncyQsIF9hcmdzJDI7XG5cdGNvbnN0IGxpc3QgPSBhcmdzWzBdO1xuXHRjb25zdCB2YWx1ZXMgPSBhcmdzWzFdO1xuXHRsZXQgY29tcGFyZUZuID0gKF9hcmdzJCA9IGFyZ3NbMl0pICE9PSBudWxsICYmIF9hcmdzJCAhPT0gdm9pZCAwID8gX2FyZ3MkIDogZGVmYXVsdENvbXBhcmF0b3I7XG5cdGNvbnN0IHsgc3ltbWV0cmljID0gZmFsc2UgfSA9IChfYXJncyQyID0gYXJnc1szXSkgIT09IG51bGwgJiYgX2FyZ3MkMiAhPT0gdm9pZCAwID8gX2FyZ3MkMiA6IHt9O1xuXHRpZiAodHlwZW9mIGNvbXBhcmVGbiA9PT0gXCJzdHJpbmdcIikge1xuXHRcdGNvbnN0IGtleSA9IGNvbXBhcmVGbjtcblx0XHRjb21wYXJlRm4gPSAodmFsdWUsIG90aFZhbCkgPT4gdmFsdWVba2V5XSA9PT0gb3RoVmFsW2tleV07XG5cdH1cblx0Y29uc3QgZGlmZjEgPSBjb21wdXRlZCgoKSA9PiB0b1ZhbHVlKGxpc3QpLmZpbHRlcigoeCkgPT4gdG9WYWx1ZSh2YWx1ZXMpLmZpbmRJbmRleCgoeSkgPT4gY29tcGFyZUZuKHgsIHkpKSA9PT0gLTEpKTtcblx0aWYgKHN5bW1ldHJpYykge1xuXHRcdGNvbnN0IGRpZmYyID0gY29tcHV0ZWQoKCkgPT4gdG9WYWx1ZSh2YWx1ZXMpLmZpbHRlcigoeCkgPT4gdG9WYWx1ZShsaXN0KS5maW5kSW5kZXgoKHkpID0+IGNvbXBhcmVGbih4LCB5KSkgPT09IC0xKSk7XG5cdFx0cmV0dXJuIGNvbXB1dGVkKCgpID0+IHN5bW1ldHJpYyA/IFsuLi50b1ZhbHVlKGRpZmYxKSwgLi4udG9WYWx1ZShkaWZmMildIDogdG9WYWx1ZShkaWZmMSkpO1xuXHR9IGVsc2UgcmV0dXJuIGRpZmYxO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gdXNlQXJyYXlFdmVyeS9pbmRleC50c1xuLyoqXG4qIFJlYWN0aXZlIGBBcnJheS5ldmVyeWBcbipcbiogQHNlZSBodHRwczovL3Z1ZXVzZS5vcmcvdXNlQXJyYXlFdmVyeVxuKiBAcGFyYW0gbGlzdCAtIHRoZSBhcnJheSB3YXMgY2FsbGVkIHVwb24uXG4qIEBwYXJhbSBmbiAtIGEgZnVuY3Rpb24gdG8gdGVzdCBlYWNoIGVsZW1lbnQuXG4qXG4qIEByZXR1cm5zICoqdHJ1ZSoqIGlmIHRoZSBgZm5gIGZ1bmN0aW9uIHJldHVybnMgYSAqKnRydXRoeSoqIHZhbHVlIGZvciBldmVyeSBlbGVtZW50IGZyb20gdGhlIGFycmF5LiBPdGhlcndpc2UsICoqZmFsc2UqKi5cbipcbiogQF9fTk9fU0lERV9FRkZFQ1RTX19cbiovXG5mdW5jdGlvbiB1c2VBcnJheUV2ZXJ5KGxpc3QsIGZuKSB7XG5cdHJldHVybiBjb21wdXRlZCgoKSA9PiB0b1ZhbHVlKGxpc3QpLmV2ZXJ5KChlbGVtZW50LCBpbmRleCwgYXJyYXkpID0+IGZuKHRvVmFsdWUoZWxlbWVudCksIGluZGV4LCBhcnJheSkpKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHVzZUFycmF5RmlsdGVyL2luZGV4LnRzXG4vKipcbiogUmVhY3RpdmUgYEFycmF5LmZpbHRlcmBcbipcbiogQHNlZSBodHRwczovL3Z1ZXVzZS5vcmcvdXNlQXJyYXlGaWx0ZXJcbiogQHBhcmFtIGxpc3QgLSB0aGUgYXJyYXkgd2FzIGNhbGxlZCB1cG9uLlxuKiBAcGFyYW0gZm4gLSBhIGZ1bmN0aW9uIHRoYXQgaXMgY2FsbGVkIGZvciBldmVyeSBlbGVtZW50IG9mIHRoZSBnaXZlbiBgbGlzdGAuIEVhY2ggdGltZSBgZm5gIGV4ZWN1dGVzLCB0aGUgcmV0dXJuZWQgdmFsdWUgaXMgYWRkZWQgdG8gdGhlIG5ldyBhcnJheS5cbipcbiogQHJldHVybnMgYSBzaGFsbG93IGNvcHkgb2YgYSBwb3J0aW9uIG9mIHRoZSBnaXZlbiBhcnJheSwgZmlsdGVyZWQgZG93biB0byBqdXN0IHRoZSBlbGVtZW50cyBmcm9tIHRoZSBnaXZlbiBhcnJheSB0aGF0IHBhc3MgdGhlIHRlc3QgaW1wbGVtZW50ZWQgYnkgdGhlIHByb3ZpZGVkIGZ1bmN0aW9uLiBJZiBubyBlbGVtZW50cyBwYXNzIHRoZSB0ZXN0LCBhbiBlbXB0eSBhcnJheSB3aWxsIGJlIHJldHVybmVkLlxuKlxuKiBAX19OT19TSURFX0VGRkVDVFNfX1xuKi9cbmZ1bmN0aW9uIHVzZUFycmF5RmlsdGVyKGxpc3QsIGZuKSB7XG5cdHJldHVybiBjb21wdXRlZCgoKSA9PiB0b1ZhbHVlKGxpc3QpLm1hcCgoaSkgPT4gdG9WYWx1ZShpKSkuZmlsdGVyKGZuKSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiB1c2VBcnJheUZpbmQvaW5kZXgudHNcbi8qKlxuKiBSZWFjdGl2ZSBgQXJyYXkuZmluZGBcbipcbiogQHNlZSBodHRwczovL3Z1ZXVzZS5vcmcvdXNlQXJyYXlGaW5kXG4qIEBwYXJhbSBsaXN0IC0gdGhlIGFycmF5IHdhcyBjYWxsZWQgdXBvbi5cbiogQHBhcmFtIGZuIC0gYSBmdW5jdGlvbiB0byB0ZXN0IGVhY2ggZWxlbWVudC5cbipcbiogQHJldHVybnMgdGhlIGZpcnN0IGVsZW1lbnQgaW4gdGhlIGFycmF5IHRoYXQgc2F0aXNmaWVzIHRoZSBwcm92aWRlZCB0ZXN0aW5nIGZ1bmN0aW9uLiBPdGhlcndpc2UsIHVuZGVmaW5lZCBpcyByZXR1cm5lZC5cbipcbiogQF9fTk9fU0lERV9FRkZFQ1RTX19cbiovXG5mdW5jdGlvbiB1c2VBcnJheUZpbmQobGlzdCwgZm4pIHtcblx0cmV0dXJuIGNvbXB1dGVkKCgpID0+IHRvVmFsdWUodG9WYWx1ZShsaXN0KS5maW5kKChlbGVtZW50LCBpbmRleCwgYXJyYXkpID0+IGZuKHRvVmFsdWUoZWxlbWVudCksIGluZGV4LCBhcnJheSkpKSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiB1c2VBcnJheUZpbmRJbmRleC9pbmRleC50c1xuLyoqXG4qIFJlYWN0aXZlIGBBcnJheS5maW5kSW5kZXhgXG4qXG4qIEBzZWUgaHR0cHM6Ly92dWV1c2Uub3JnL3VzZUFycmF5RmluZEluZGV4XG4qIEBwYXJhbSBsaXN0IC0gdGhlIGFycmF5IHdhcyBjYWxsZWQgdXBvbi5cbiogQHBhcmFtIGZuIC0gYSBmdW5jdGlvbiB0byB0ZXN0IGVhY2ggZWxlbWVudC5cbipcbiogQHJldHVybnMgdGhlIGluZGV4IG9mIHRoZSBmaXJzdCBlbGVtZW50IGluIHRoZSBhcnJheSB0aGF0IHBhc3NlcyB0aGUgdGVzdC4gT3RoZXJ3aXNlLCBcIi0xXCIuXG4qXG4qIEBfX05PX1NJREVfRUZGRUNUU19fXG4qL1xuZnVuY3Rpb24gdXNlQXJyYXlGaW5kSW5kZXgobGlzdCwgZm4pIHtcblx0cmV0dXJuIGNvbXB1dGVkKCgpID0+IHRvVmFsdWUobGlzdCkuZmluZEluZGV4KChlbGVtZW50LCBpbmRleCwgYXJyYXkpID0+IGZuKHRvVmFsdWUoZWxlbWVudCksIGluZGV4LCBhcnJheSkpKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHVzZUFycmF5RmluZExhc3QvaW5kZXgudHNcbmZ1bmN0aW9uIGZpbmRMYXN0KGFyciwgY2IpIHtcblx0bGV0IGluZGV4ID0gYXJyLmxlbmd0aDtcblx0d2hpbGUgKGluZGV4LS0gPiAwKSBpZiAoY2IoYXJyW2luZGV4XSwgaW5kZXgsIGFycikpIHJldHVybiBhcnJbaW5kZXhdO1xufVxuLyoqXG4qIFJlYWN0aXZlIGBBcnJheS5maW5kTGFzdGBcbipcbiogQHNlZSBodHRwczovL3Z1ZXVzZS5vcmcvdXNlQXJyYXlGaW5kTGFzdFxuKiBAcGFyYW0gbGlzdCAtIHRoZSBhcnJheSB3YXMgY2FsbGVkIHVwb24uXG4qIEBwYXJhbSBmbiAtIGEgZnVuY3Rpb24gdG8gdGVzdCBlYWNoIGVsZW1lbnQuXG4qXG4qIEByZXR1cm5zIHRoZSBsYXN0IGVsZW1lbnQgaW4gdGhlIGFycmF5IHRoYXQgc2F0aXNmaWVzIHRoZSBwcm92aWRlZCB0ZXN0aW5nIGZ1bmN0aW9uLiBPdGhlcndpc2UsIHVuZGVmaW5lZCBpcyByZXR1cm5lZC5cbipcbiogQF9fTk9fU0lERV9FRkZFQ1RTX19cbiovXG5mdW5jdGlvbiB1c2VBcnJheUZpbmRMYXN0KGxpc3QsIGZuKSB7XG5cdHJldHVybiBjb21wdXRlZCgoKSA9PiB0b1ZhbHVlKCFBcnJheS5wcm90b3R5cGUuZmluZExhc3QgPyBmaW5kTGFzdCh0b1ZhbHVlKGxpc3QpLCAoZWxlbWVudCwgaW5kZXgsIGFycmF5KSA9PiBmbih0b1ZhbHVlKGVsZW1lbnQpLCBpbmRleCwgYXJyYXkpKSA6IHRvVmFsdWUobGlzdCkuZmluZExhc3QoKGVsZW1lbnQsIGluZGV4LCBhcnJheSkgPT4gZm4odG9WYWx1ZShlbGVtZW50KSwgaW5kZXgsIGFycmF5KSkpKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHVzZUFycmF5SW5jbHVkZXMvaW5kZXgudHNcbmZ1bmN0aW9uIGlzQXJyYXlJbmNsdWRlc09wdGlvbnMob2JqKSB7XG5cdHJldHVybiBpc09iamVjdChvYmopICYmIGNvbnRhaW5zUHJvcChvYmosIFwiZm9ybUluZGV4XCIsIFwiY29tcGFyYXRvclwiKTtcbn1cbi8qKlxuKiBSZWFjdGl2ZSBgQXJyYXkuaW5jbHVkZXNgXG4qXG4qIEBzZWUgaHR0cHM6Ly92dWV1c2Uub3JnL3VzZUFycmF5SW5jbHVkZXNcbipcbiogQHJldHVybnMgdHJ1ZSBpZiB0aGUgYHZhbHVlYCBpcyBmb3VuZCBpbiB0aGUgYXJyYXkuIE90aGVyd2lzZSwgZmFsc2UuXG4qXG4qIEBfX05PX1NJREVfRUZGRUNUU19fXG4qL1xuZnVuY3Rpb24gdXNlQXJyYXlJbmNsdWRlcyguLi5hcmdzKSB7XG5cdHZhciBfY29tcGFyYXRvcjtcblx0Y29uc3QgbGlzdCA9IGFyZ3NbMF07XG5cdGNvbnN0IHZhbHVlID0gYXJnc1sxXTtcblx0bGV0IGNvbXBhcmF0b3IgPSBhcmdzWzJdO1xuXHRsZXQgZm9ybUluZGV4ID0gMDtcblx0aWYgKGlzQXJyYXlJbmNsdWRlc09wdGlvbnMoY29tcGFyYXRvcikpIHtcblx0XHR2YXIgX2NvbXBhcmF0b3IkZnJvbUluZGV4O1xuXHRcdGZvcm1JbmRleCA9IChfY29tcGFyYXRvciRmcm9tSW5kZXggPSBjb21wYXJhdG9yLmZyb21JbmRleCkgIT09IG51bGwgJiYgX2NvbXBhcmF0b3IkZnJvbUluZGV4ICE9PSB2b2lkIDAgPyBfY29tcGFyYXRvciRmcm9tSW5kZXggOiAwO1xuXHRcdGNvbXBhcmF0b3IgPSBjb21wYXJhdG9yLmNvbXBhcmF0b3I7XG5cdH1cblx0aWYgKHR5cGVvZiBjb21wYXJhdG9yID09PSBcInN0cmluZ1wiKSB7XG5cdFx0Y29uc3Qga2V5ID0gY29tcGFyYXRvcjtcblx0XHRjb21wYXJhdG9yID0gKGVsZW1lbnQsIHZhbHVlKSA9PiBlbGVtZW50W2tleV0gPT09IHRvVmFsdWUodmFsdWUpO1xuXHR9XG5cdGNvbXBhcmF0b3IgPSAoX2NvbXBhcmF0b3IgPSBjb21wYXJhdG9yKSAhPT0gbnVsbCAmJiBfY29tcGFyYXRvciAhPT0gdm9pZCAwID8gX2NvbXBhcmF0b3IgOiAoKGVsZW1lbnQsIHZhbHVlKSA9PiBlbGVtZW50ID09PSB0b1ZhbHVlKHZhbHVlKSk7XG5cdHJldHVybiBjb21wdXRlZCgoKSA9PiB0b1ZhbHVlKGxpc3QpLnNsaWNlKGZvcm1JbmRleCkuc29tZSgoZWxlbWVudCwgaW5kZXgsIGFycmF5KSA9PiBjb21wYXJhdG9yKHRvVmFsdWUoZWxlbWVudCksIHRvVmFsdWUodmFsdWUpLCBpbmRleCwgdG9WYWx1ZShhcnJheSkpKSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiB1c2VBcnJheUpvaW4vaW5kZXgudHNcbi8qKlxuKiBSZWFjdGl2ZSBgQXJyYXkuam9pbmBcbipcbiogQHNlZSBodHRwczovL3Z1ZXVzZS5vcmcvdXNlQXJyYXlKb2luXG4qIEBwYXJhbSBsaXN0IC0gdGhlIGFycmF5IHdhcyBjYWxsZWQgdXBvbi5cbiogQHBhcmFtIHNlcGFyYXRvciAtIGEgc3RyaW5nIHRvIHNlcGFyYXRlIGVhY2ggcGFpciBvZiBhZGphY2VudCBlbGVtZW50cyBvZiB0aGUgYXJyYXkuIElmIG9taXR0ZWQsIHRoZSBhcnJheSBlbGVtZW50cyBhcmUgc2VwYXJhdGVkIHdpdGggYSBjb21tYSAoXCIsXCIpLlxuKlxuKiBAcmV0dXJucyBhIHN0cmluZyB3aXRoIGFsbCBhcnJheSBlbGVtZW50cyBqb2luZWQuIElmIGFyci5sZW5ndGggaXMgMCwgdGhlIGVtcHR5IHN0cmluZyBpcyByZXR1cm5lZC5cbipcbiogQF9fTk9fU0lERV9FRkZFQ1RTX19cbiovXG5mdW5jdGlvbiB1c2VBcnJheUpvaW4obGlzdCwgc2VwYXJhdG9yKSB7XG5cdHJldHVybiBjb21wdXRlZCgoKSA9PiB0b1ZhbHVlKGxpc3QpLm1hcCgoaSkgPT4gdG9WYWx1ZShpKSkuam9pbih0b1ZhbHVlKHNlcGFyYXRvcikpKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHVzZUFycmF5TWFwL2luZGV4LnRzXG4vKipcbiogUmVhY3RpdmUgYEFycmF5Lm1hcGBcbipcbiogQHNlZSBodHRwczovL3Z1ZXVzZS5vcmcvdXNlQXJyYXlNYXBcbiogQHBhcmFtIGxpc3QgLSB0aGUgYXJyYXkgd2FzIGNhbGxlZCB1cG9uLlxuKiBAcGFyYW0gZm4gLSBhIGZ1bmN0aW9uIHRoYXQgaXMgY2FsbGVkIGZvciBldmVyeSBlbGVtZW50IG9mIHRoZSBnaXZlbiBgbGlzdGAuIEVhY2ggdGltZSBgZm5gIGV4ZWN1dGVzLCB0aGUgcmV0dXJuZWQgdmFsdWUgaXMgYWRkZWQgdG8gdGhlIG5ldyBhcnJheS5cbipcbiogQHJldHVybnMgYSBuZXcgYXJyYXkgd2l0aCBlYWNoIGVsZW1lbnQgYmVpbmcgdGhlIHJlc3VsdCBvZiB0aGUgY2FsbGJhY2sgZnVuY3Rpb24uXG4qXG4qIEBfX05PX1NJREVfRUZGRUNUU19fXG4qL1xuZnVuY3Rpb24gdXNlQXJyYXlNYXAobGlzdCwgZm4pIHtcblx0cmV0dXJuIGNvbXB1dGVkKCgpID0+IHRvVmFsdWUobGlzdCkubWFwKChpKSA9PiB0b1ZhbHVlKGkpKS5tYXAoZm4pKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHVzZUFycmF5UmVkdWNlL2luZGV4LnRzXG4vKipcbiogUmVhY3RpdmUgYEFycmF5LnJlZHVjZWBcbipcbiogQHNlZSBodHRwczovL3Z1ZXVzZS5vcmcvdXNlQXJyYXlSZWR1Y2VcbiogQHBhcmFtIGxpc3QgLSB0aGUgYXJyYXkgd2FzIGNhbGxlZCB1cG9uLlxuKiBAcGFyYW0gcmVkdWNlciAtIGEgXCJyZWR1Y2VyXCIgZnVuY3Rpb24uXG4qIEBwYXJhbSBhcmdzXG4qXG4qIEByZXR1cm5zIHRoZSB2YWx1ZSB0aGF0IHJlc3VsdHMgZnJvbSBydW5uaW5nIHRoZSBcInJlZHVjZXJcIiBjYWxsYmFjayBmdW5jdGlvbiB0byBjb21wbGV0aW9uIG92ZXIgdGhlIGVudGlyZSBhcnJheS5cbipcbiogQF9fTk9fU0lERV9FRkZFQ1RTX19cbiovXG5mdW5jdGlvbiB1c2VBcnJheVJlZHVjZShsaXN0LCByZWR1Y2VyLCAuLi5hcmdzKSB7XG5cdGNvbnN0IHJlZHVjZUNhbGxiYWNrID0gKHN1bSwgdmFsdWUsIGluZGV4KSA9PiByZWR1Y2VyKHRvVmFsdWUoc3VtKSwgdG9WYWx1ZSh2YWx1ZSksIGluZGV4KTtcblx0cmV0dXJuIGNvbXB1dGVkKCgpID0+IHtcblx0XHRjb25zdCByZXNvbHZlZCA9IHRvVmFsdWUobGlzdCk7XG5cdFx0cmV0dXJuIGFyZ3MubGVuZ3RoID8gcmVzb2x2ZWQucmVkdWNlKHJlZHVjZUNhbGxiYWNrLCB0eXBlb2YgYXJnc1swXSA9PT0gXCJmdW5jdGlvblwiID8gdG9WYWx1ZShhcmdzWzBdKCkpIDogdG9WYWx1ZShhcmdzWzBdKSkgOiByZXNvbHZlZC5yZWR1Y2UocmVkdWNlQ2FsbGJhY2spO1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHVzZUFycmF5U29tZS9pbmRleC50c1xuLyoqXG4qIFJlYWN0aXZlIGBBcnJheS5zb21lYFxuKlxuKiBAc2VlIGh0dHBzOi8vdnVldXNlLm9yZy91c2VBcnJheVNvbWVcbiogQHBhcmFtIGxpc3QgLSB0aGUgYXJyYXkgd2FzIGNhbGxlZCB1cG9uLlxuKiBAcGFyYW0gZm4gLSBhIGZ1bmN0aW9uIHRvIHRlc3QgZWFjaCBlbGVtZW50LlxuKlxuKiBAcmV0dXJucyAqKnRydWUqKiBpZiB0aGUgYGZuYCBmdW5jdGlvbiByZXR1cm5zIGEgKip0cnV0aHkqKiB2YWx1ZSBmb3IgYW55IGVsZW1lbnQgZnJvbSB0aGUgYXJyYXkuIE90aGVyd2lzZSwgKipmYWxzZSoqLlxuKlxuKiBAX19OT19TSURFX0VGRkVDVFNfX1xuKi9cbmZ1bmN0aW9uIHVzZUFycmF5U29tZShsaXN0LCBmbikge1xuXHRyZXR1cm4gY29tcHV0ZWQoKCkgPT4gdG9WYWx1ZShsaXN0KS5zb21lKChlbGVtZW50LCBpbmRleCwgYXJyYXkpID0+IGZuKHRvVmFsdWUoZWxlbWVudCksIGluZGV4LCBhcnJheSkpKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHVzZUFycmF5VW5pcXVlL2luZGV4LnRzXG5mdW5jdGlvbiB1bmlxKGFycmF5KSB7XG5cdHJldHVybiBBcnJheS5mcm9tKG5ldyBTZXQoYXJyYXkpKTtcbn1cbmZ1bmN0aW9uIHVuaXF1ZUVsZW1lbnRzQnkoYXJyYXksIGZuKSB7XG5cdHJldHVybiBhcnJheS5yZWR1Y2UoKGFjYywgdikgPT4ge1xuXHRcdGlmICghYWNjLnNvbWUoKHgpID0+IGZuKHYsIHgsIGFycmF5KSkpIGFjYy5wdXNoKHYpO1xuXHRcdHJldHVybiBhY2M7XG5cdH0sIFtdKTtcbn1cbi8qKlxuKiByZWFjdGl2ZSB1bmlxdWUgYXJyYXlcbiogQHNlZSBodHRwczovL3Z1ZXVzZS5vcmcvdXNlQXJyYXlVbmlxdWVcbiogQHBhcmFtIGxpc3QgLSB0aGUgYXJyYXkgd2FzIGNhbGxlZCB1cG9uLlxuKiBAcGFyYW0gY29tcGFyZUZuXG4qIEByZXR1cm5zIEEgY29tcHV0ZWQgcmVmIHRoYXQgcmV0dXJucyBhIHVuaXF1ZSBhcnJheSBvZiBpdGVtcy5cbipcbiogQF9fTk9fU0lERV9FRkZFQ1RTX19cbiovXG5mdW5jdGlvbiB1c2VBcnJheVVuaXF1ZShsaXN0LCBjb21wYXJlRm4pIHtcblx0cmV0dXJuIGNvbXB1dGVkKCgpID0+IHtcblx0XHRjb25zdCByZXNvbHZlZExpc3QgPSB0b1ZhbHVlKGxpc3QpLm1hcCgoZWxlbWVudCkgPT4gdG9WYWx1ZShlbGVtZW50KSk7XG5cdFx0cmV0dXJuIGNvbXBhcmVGbiA/IHVuaXF1ZUVsZW1lbnRzQnkocmVzb2x2ZWRMaXN0LCBjb21wYXJlRm4pIDogdW5pcShyZXNvbHZlZExpc3QpO1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHVzZUNvdW50ZXIvaW5kZXgudHNcbi8qKlxuKiBCYXNpYyBjb3VudGVyIHdpdGggdXRpbGl0eSBmdW5jdGlvbnMuXG4qXG4qIEBzZWUgaHR0cHM6Ly92dWV1c2Uub3JnL3VzZUNvdW50ZXJcbiogQHBhcmFtIFtpbml0aWFsVmFsdWVdXG4qIEBwYXJhbSBvcHRpb25zXG4qL1xuZnVuY3Rpb24gdXNlQ291bnRlcihpbml0aWFsVmFsdWUgPSAwLCBvcHRpb25zID0ge30pIHtcblx0bGV0IF9pbml0aWFsVmFsdWUgPSB1bnJlZihpbml0aWFsVmFsdWUpO1xuXHRjb25zdCBjb3VudCA9IHNoYWxsb3dSZWYoaW5pdGlhbFZhbHVlKTtcblx0Y29uc3QgeyBtYXggPSBOdW1iZXIuUE9TSVRJVkVfSU5GSU5JVFksIG1pbiA9IE51bWJlci5ORUdBVElWRV9JTkZJTklUWSB9ID0gb3B0aW9ucztcblx0Y29uc3QgaW5jID0gKGRlbHRhID0gMSkgPT4gY291bnQudmFsdWUgPSBNYXRoLm1heChNYXRoLm1pbihtYXgsIGNvdW50LnZhbHVlICsgZGVsdGEpLCBtaW4pO1xuXHRjb25zdCBkZWMgPSAoZGVsdGEgPSAxKSA9PiBjb3VudC52YWx1ZSA9IE1hdGgubWluKE1hdGgubWF4KG1pbiwgY291bnQudmFsdWUgLSBkZWx0YSksIG1heCk7XG5cdGNvbnN0IGdldCA9ICgpID0+IGNvdW50LnZhbHVlO1xuXHRjb25zdCBzZXQgPSAodmFsKSA9PiBjb3VudC52YWx1ZSA9IE1hdGgubWF4KG1pbiwgTWF0aC5taW4obWF4LCB2YWwpKTtcblx0Y29uc3QgcmVzZXQgPSAodmFsID0gX2luaXRpYWxWYWx1ZSkgPT4ge1xuXHRcdF9pbml0aWFsVmFsdWUgPSB2YWw7XG5cdFx0cmV0dXJuIHNldCh2YWwpO1xuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdGNvdW50OiBzaGFsbG93UmVhZG9ubHkoY291bnQpLFxuXHRcdGluYyxcblx0XHRkZWMsXG5cdFx0Z2V0LFxuXHRcdHNldCxcblx0XHRyZXNldFxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gdXNlRGF0ZUZvcm1hdC9pbmRleC50c1xuY29uc3QgUkVHRVhfUEFSU0UgPSAvXihcXGR7NH0pWy0vXT8oXFxkezEsMn0pP1stL10/KFxcZHswLDJ9KVtUXFxzXSooXFxkezEsMn0pPzo/KFxcZHsxLDJ9KT86PyhcXGR7MSwyfSk/Wy46XT8oXFxkKyk/JC9pO1xuY29uc3QgUkVHRVhfRk9STUFUID0gL1tZTURIaG1zXW98XFxbKFteXFxdXSspXFxdfFl7MSw0fXxNezEsNH18RHsxLDJ9fGR7MSw0fXxIezEsMn18aHsxLDJ9fGF7MSwyfXxBezEsMn18bXsxLDJ9fHN7MSwyfXxaezEsMn18ensxLDR9fFNTUy9nO1xuZnVuY3Rpb24gZGVmYXVsdE1lcmlkaWVtKGhvdXJzLCBtaW51dGVzLCBpc0xvd2VyY2FzZSwgaGFzUGVyaW9kKSB7XG5cdGxldCBtID0gaG91cnMgPCAxMiA/IFwiQU1cIiA6IFwiUE1cIjtcblx0aWYgKGhhc1BlcmlvZCkgbSA9IG0uc3BsaXQoXCJcIikucmVkdWNlKChhY2MsIGN1cnIpID0+IGFjYyArPSBgJHtjdXJyfS5gLCBcIlwiKTtcblx0cmV0dXJuIGlzTG93ZXJjYXNlID8gbS50b0xvd2VyQ2FzZSgpIDogbTtcbn1cbmZ1bmN0aW9uIGZvcm1hdE9yZGluYWwobnVtKSB7XG5cdGNvbnN0IHN1ZmZpeGVzID0gW1xuXHRcdFwidGhcIixcblx0XHRcInN0XCIsXG5cdFx0XCJuZFwiLFxuXHRcdFwicmRcIlxuXHRdO1xuXHRjb25zdCB2ID0gbnVtICUgMTAwO1xuXHRyZXR1cm4gbnVtICsgKHN1ZmZpeGVzWyh2IC0gMjApICUgMTBdIHx8IHN1ZmZpeGVzW3ZdIHx8IHN1ZmZpeGVzWzBdKTtcbn1cbmZ1bmN0aW9uIGZvcm1hdERhdGUoZGF0ZSwgZm9ybWF0U3RyLCBvcHRpb25zID0ge30pIHtcblx0dmFyIF9vcHRpb25zJGN1c3RvbU1lcmlkaTtcblx0Y29uc3QgeWVhcnMgPSBkYXRlLmdldEZ1bGxZZWFyKCk7XG5cdGNvbnN0IG1vbnRoID0gZGF0ZS5nZXRNb250aCgpO1xuXHRjb25zdCBkYXlzID0gZGF0ZS5nZXREYXRlKCk7XG5cdGNvbnN0IGhvdXJzID0gZGF0ZS5nZXRIb3VycygpO1xuXHRjb25zdCBtaW51dGVzID0gZGF0ZS5nZXRNaW51dGVzKCk7XG5cdGNvbnN0IHNlY29uZHMgPSBkYXRlLmdldFNlY29uZHMoKTtcblx0Y29uc3QgbWlsbGlzZWNvbmRzID0gZGF0ZS5nZXRNaWxsaXNlY29uZHMoKTtcblx0Y29uc3QgZGF5ID0gZGF0ZS5nZXREYXkoKTtcblx0Y29uc3QgbWVyaWRpZW0gPSAoX29wdGlvbnMkY3VzdG9tTWVyaWRpID0gb3B0aW9ucy5jdXN0b21NZXJpZGllbSkgIT09IG51bGwgJiYgX29wdGlvbnMkY3VzdG9tTWVyaWRpICE9PSB2b2lkIDAgPyBfb3B0aW9ucyRjdXN0b21NZXJpZGkgOiBkZWZhdWx0TWVyaWRpZW07XG5cdGNvbnN0IHN0cmlwVGltZVpvbmUgPSAoZGF0ZVN0cmluZykgPT4ge1xuXHRcdHZhciBfZGF0ZVN0cmluZyRzcGxpdCQ7XG5cdFx0cmV0dXJuIChfZGF0ZVN0cmluZyRzcGxpdCQgPSBkYXRlU3RyaW5nLnNwbGl0KFwiIFwiKVsxXSkgIT09IG51bGwgJiYgX2RhdGVTdHJpbmckc3BsaXQkICE9PSB2b2lkIDAgPyBfZGF0ZVN0cmluZyRzcGxpdCQgOiBcIlwiO1xuXHR9O1xuXHRjb25zdCBtYXRjaGVzID0ge1xuXHRcdFlvOiAoKSA9PiBmb3JtYXRPcmRpbmFsKHllYXJzKSxcblx0XHRZWTogKCkgPT4gU3RyaW5nKHllYXJzKS5zbGljZSgtMiksXG5cdFx0WVlZWTogKCkgPT4geWVhcnMsXG5cdFx0TTogKCkgPT4gbW9udGggKyAxLFxuXHRcdE1vOiAoKSA9PiBmb3JtYXRPcmRpbmFsKG1vbnRoICsgMSksXG5cdFx0TU06ICgpID0+IGAke21vbnRoICsgMX1gLnBhZFN0YXJ0KDIsIFwiMFwiKSxcblx0XHRNTU06ICgpID0+IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKHRvVmFsdWUob3B0aW9ucy5sb2NhbGVzKSwgeyBtb250aDogXCJzaG9ydFwiIH0pLFxuXHRcdE1NTU06ICgpID0+IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKHRvVmFsdWUob3B0aW9ucy5sb2NhbGVzKSwgeyBtb250aDogXCJsb25nXCIgfSksXG5cdFx0RDogKCkgPT4gU3RyaW5nKGRheXMpLFxuXHRcdERvOiAoKSA9PiBmb3JtYXRPcmRpbmFsKGRheXMpLFxuXHRcdEREOiAoKSA9PiBgJHtkYXlzfWAucGFkU3RhcnQoMiwgXCIwXCIpLFxuXHRcdEg6ICgpID0+IFN0cmluZyhob3VycyksXG5cdFx0SG86ICgpID0+IGZvcm1hdE9yZGluYWwoaG91cnMpLFxuXHRcdEhIOiAoKSA9PiBgJHtob3Vyc31gLnBhZFN0YXJ0KDIsIFwiMFwiKSxcblx0XHRoOiAoKSA9PiBgJHtob3VycyAlIDEyIHx8IDEyfWAucGFkU3RhcnQoMSwgXCIwXCIpLFxuXHRcdGhvOiAoKSA9PiBmb3JtYXRPcmRpbmFsKGhvdXJzICUgMTIgfHwgMTIpLFxuXHRcdGhoOiAoKSA9PiBgJHtob3VycyAlIDEyIHx8IDEyfWAucGFkU3RhcnQoMiwgXCIwXCIpLFxuXHRcdG06ICgpID0+IFN0cmluZyhtaW51dGVzKSxcblx0XHRtbzogKCkgPT4gZm9ybWF0T3JkaW5hbChtaW51dGVzKSxcblx0XHRtbTogKCkgPT4gYCR7bWludXRlc31gLnBhZFN0YXJ0KDIsIFwiMFwiKSxcblx0XHRzOiAoKSA9PiBTdHJpbmcoc2Vjb25kcyksXG5cdFx0c286ICgpID0+IGZvcm1hdE9yZGluYWwoc2Vjb25kcyksXG5cdFx0c3M6ICgpID0+IGAke3NlY29uZHN9YC5wYWRTdGFydCgyLCBcIjBcIiksXG5cdFx0U1NTOiAoKSA9PiBgJHttaWxsaXNlY29uZHN9YC5wYWRTdGFydCgzLCBcIjBcIiksXG5cdFx0ZDogKCkgPT4gZGF5LFxuXHRcdGRkOiAoKSA9PiBkYXRlLnRvTG9jYWxlRGF0ZVN0cmluZyh0b1ZhbHVlKG9wdGlvbnMubG9jYWxlcyksIHsgd2Vla2RheTogXCJuYXJyb3dcIiB9KSxcblx0XHRkZGQ6ICgpID0+IGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKHRvVmFsdWUob3B0aW9ucy5sb2NhbGVzKSwgeyB3ZWVrZGF5OiBcInNob3J0XCIgfSksXG5cdFx0ZGRkZDogKCkgPT4gZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcodG9WYWx1ZShvcHRpb25zLmxvY2FsZXMpLCB7IHdlZWtkYXk6IFwibG9uZ1wiIH0pLFxuXHRcdEE6ICgpID0+IG1lcmlkaWVtKGhvdXJzLCBtaW51dGVzKSxcblx0XHRBQTogKCkgPT4gbWVyaWRpZW0oaG91cnMsIG1pbnV0ZXMsIGZhbHNlLCB0cnVlKSxcblx0XHRhOiAoKSA9PiBtZXJpZGllbShob3VycywgbWludXRlcywgdHJ1ZSksXG5cdFx0YWE6ICgpID0+IG1lcmlkaWVtKGhvdXJzLCBtaW51dGVzLCB0cnVlLCB0cnVlKSxcblx0XHR6OiAoKSA9PiBzdHJpcFRpbWVab25lKGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKHRvVmFsdWUob3B0aW9ucy5sb2NhbGVzKSwgeyB0aW1lWm9uZU5hbWU6IFwic2hvcnRPZmZzZXRcIiB9KSksXG5cdFx0eno6ICgpID0+IHN0cmlwVGltZVpvbmUoZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcodG9WYWx1ZShvcHRpb25zLmxvY2FsZXMpLCB7IHRpbWVab25lTmFtZTogXCJzaG9ydE9mZnNldFwiIH0pKSxcblx0XHR6eno6ICgpID0+IHN0cmlwVGltZVpvbmUoZGF0ZS50b0xvY2FsZURhdGVTdHJpbmcodG9WYWx1ZShvcHRpb25zLmxvY2FsZXMpLCB7IHRpbWVab25lTmFtZTogXCJzaG9ydE9mZnNldFwiIH0pKSxcblx0XHR6enp6OiAoKSA9PiBzdHJpcFRpbWVab25lKGRhdGUudG9Mb2NhbGVEYXRlU3RyaW5nKHRvVmFsdWUob3B0aW9ucy5sb2NhbGVzKSwgeyB0aW1lWm9uZU5hbWU6IFwibG9uZ09mZnNldFwiIH0pKVxuXHR9O1xuXHRyZXR1cm4gZm9ybWF0U3RyLnJlcGxhY2UoUkVHRVhfRk9STUFULCAobWF0Y2gsICQxKSA9PiB7XG5cdFx0dmFyIF9yZWYsIF9tYXRjaGVzJG1hdGNoO1xuXHRcdHJldHVybiAoX3JlZiA9ICQxICE9PSBudWxsICYmICQxICE9PSB2b2lkIDAgPyAkMSA6IChfbWF0Y2hlcyRtYXRjaCA9IG1hdGNoZXNbbWF0Y2hdKSA9PT0gbnVsbCB8fCBfbWF0Y2hlcyRtYXRjaCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX21hdGNoZXMkbWF0Y2guY2FsbChtYXRjaGVzKSkgIT09IG51bGwgJiYgX3JlZiAhPT0gdm9pZCAwID8gX3JlZiA6IG1hdGNoO1xuXHR9KTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZURhdGUoZGF0ZSkge1xuXHRpZiAoZGF0ZSA9PT0gbnVsbCkgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBuZXcgRGF0ZShOYU4pO1xuXHRpZiAoZGF0ZSA9PT0gdm9pZCAwKSByZXR1cm4gLyogQF9fUFVSRV9fICovIG5ldyBEYXRlKCk7XG5cdGlmIChkYXRlIGluc3RhbmNlb2YgRGF0ZSkgcmV0dXJuIG5ldyBEYXRlKGRhdGUpO1xuXHRpZiAodHlwZW9mIGRhdGUgPT09IFwic3RyaW5nXCIgJiYgIS9aJC9pLnRlc3QoZGF0ZSkpIHtcblx0XHRjb25zdCBkID0gZGF0ZS5tYXRjaChSRUdFWF9QQVJTRSk7XG5cdFx0aWYgKGQpIHtcblx0XHRcdGNvbnN0IG0gPSBkWzJdIC0gMSB8fCAwO1xuXHRcdFx0Y29uc3QgbXMgPSAoZFs3XSB8fCBcIjBcIikuc3Vic3RyaW5nKDAsIDMpO1xuXHRcdFx0cmV0dXJuIG5ldyBEYXRlKGRbMV0sIG0sIGRbM10gfHwgMSwgZFs0XSB8fCAwLCBkWzVdIHx8IDAsIGRbNl0gfHwgMCwgbXMpO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gbmV3IERhdGUoZGF0ZSk7XG59XG4vKipcbiogR2V0IHRoZSBmb3JtYXR0ZWQgZGF0ZSBhY2NvcmRpbmcgdG8gdGhlIHN0cmluZyBvZiB0b2tlbnMgcGFzc2VkIGluLlxuKlxuKiBAc2VlIGh0dHBzOi8vdnVldXNlLm9yZy91c2VEYXRlRm9ybWF0XG4qIEBwYXJhbSBkYXRlIC0gVGhlIGRhdGUgdG8gZm9ybWF0LCBjYW4gZWl0aGVyIGJlIGEgYERhdGVgIG9iamVjdCwgYSB0aW1lc3RhbXAsIG9yIGEgc3RyaW5nXG4qIEBwYXJhbSBmb3JtYXRTdHIgLSBUaGUgY29tYmluYXRpb24gb2YgdG9rZW5zIHRvIGZvcm1hdCB0aGUgZGF0ZVxuKiBAcGFyYW0gb3B0aW9ucyAtIFVzZURhdGVGb3JtYXRPcHRpb25zXG4qXG4qIEBfX05PX1NJREVfRUZGRUNUU19fXG4qL1xuZnVuY3Rpb24gdXNlRGF0ZUZvcm1hdChkYXRlLCBmb3JtYXRTdHIgPSBcIkhIOm1tOnNzXCIsIG9wdGlvbnMgPSB7fSkge1xuXHRyZXR1cm4gY29tcHV0ZWQoKCkgPT4gZm9ybWF0RGF0ZShub3JtYWxpemVEYXRlKHRvVmFsdWUoZGF0ZSkpLCB0b1ZhbHVlKGZvcm1hdFN0ciksIG9wdGlvbnMpKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHVzZUludGVydmFsRm4vaW5kZXgudHNcbi8qKlxuKiBXcmFwcGVyIGZvciBgc2V0SW50ZXJ2YWxgIHdpdGggY29udHJvbHNcbipcbiogQHNlZSBodHRwczovL3Z1ZXVzZS5vcmcvdXNlSW50ZXJ2YWxGblxuKiBAcGFyYW0gY2JcbiogQHBhcmFtIGludGVydmFsXG4qIEBwYXJhbSBvcHRpb25zXG4qL1xuZnVuY3Rpb24gdXNlSW50ZXJ2YWxGbihjYiwgaW50ZXJ2YWwgPSAxZTMsIG9wdGlvbnMgPSB7fSkge1xuXHRjb25zdCB7IGltbWVkaWF0ZSA9IHRydWUsIGltbWVkaWF0ZUNhbGxiYWNrID0gZmFsc2UgfSA9IG9wdGlvbnM7XG5cdGxldCB0aW1lciA9IG51bGw7XG5cdGNvbnN0IGlzQWN0aXZlID0gc2hhbGxvd1JlZihmYWxzZSk7XG5cdGZ1bmN0aW9uIGNsZWFuKCkge1xuXHRcdGlmICh0aW1lcikge1xuXHRcdFx0Y2xlYXJJbnRlcnZhbCh0aW1lcik7XG5cdFx0XHR0aW1lciA9IG51bGw7XG5cdFx0fVxuXHR9XG5cdGZ1bmN0aW9uIHBhdXNlKCkge1xuXHRcdGlzQWN0aXZlLnZhbHVlID0gZmFsc2U7XG5cdFx0Y2xlYW4oKTtcblx0fVxuXHRmdW5jdGlvbiByZXN1bWUoKSB7XG5cdFx0Y29uc3QgaW50ZXJ2YWxWYWx1ZSA9IHRvVmFsdWUoaW50ZXJ2YWwpO1xuXHRcdGlmIChpbnRlcnZhbFZhbHVlIDw9IDApIHJldHVybjtcblx0XHRpc0FjdGl2ZS52YWx1ZSA9IHRydWU7XG5cdFx0aWYgKGltbWVkaWF0ZUNhbGxiYWNrKSBjYigpO1xuXHRcdGNsZWFuKCk7XG5cdFx0aWYgKGlzQWN0aXZlLnZhbHVlKSB0aW1lciA9IHNldEludGVydmFsKGNiLCBpbnRlcnZhbFZhbHVlKTtcblx0fVxuXHRpZiAoaW1tZWRpYXRlICYmIGlzQ2xpZW50KSByZXN1bWUoKTtcblx0aWYgKGlzUmVmKGludGVydmFsKSB8fCB0eXBlb2YgaW50ZXJ2YWwgPT09IFwiZnVuY3Rpb25cIikgdHJ5T25TY29wZURpc3Bvc2Uod2F0Y2goaW50ZXJ2YWwsICgpID0+IHtcblx0XHRpZiAoaXNBY3RpdmUudmFsdWUgJiYgaXNDbGllbnQpIHJlc3VtZSgpO1xuXHR9KSk7XG5cdHRyeU9uU2NvcGVEaXNwb3NlKHBhdXNlKTtcblx0cmV0dXJuIHtcblx0XHRpc0FjdGl2ZTogc2hhbGxvd1JlYWRvbmx5KGlzQWN0aXZlKSxcblx0XHRwYXVzZSxcblx0XHRyZXN1bWVcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHVzZUludGVydmFsL2luZGV4LnRzXG5mdW5jdGlvbiB1c2VJbnRlcnZhbChpbnRlcnZhbCA9IDFlMywgb3B0aW9ucyA9IHt9KSB7XG5cdGNvbnN0IHsgY29udHJvbHM6IGV4cG9zZUNvbnRyb2xzID0gZmFsc2UsIGltbWVkaWF0ZSA9IHRydWUsIGNhbGxiYWNrIH0gPSBvcHRpb25zO1xuXHRjb25zdCBjb3VudGVyID0gc2hhbGxvd1JlZigwKTtcblx0Y29uc3QgdXBkYXRlID0gKCkgPT4gY291bnRlci52YWx1ZSArPSAxO1xuXHRjb25zdCByZXNldCA9ICgpID0+IHtcblx0XHRjb3VudGVyLnZhbHVlID0gMDtcblx0fTtcblx0Y29uc3QgY29udHJvbHMgPSB1c2VJbnRlcnZhbEZuKGNhbGxiYWNrID8gKCkgPT4ge1xuXHRcdHVwZGF0ZSgpO1xuXHRcdGNhbGxiYWNrKGNvdW50ZXIudmFsdWUpO1xuXHR9IDogdXBkYXRlLCBpbnRlcnZhbCwgeyBpbW1lZGlhdGUgfSk7XG5cdGlmIChleHBvc2VDb250cm9scykgcmV0dXJuIHtcblx0XHRjb3VudGVyOiBzaGFsbG93UmVhZG9ubHkoY291bnRlciksXG5cdFx0cmVzZXQsXG5cdFx0Li4uY29udHJvbHNcblx0fTtcblx0ZWxzZSByZXR1cm4gc2hhbGxvd1JlYWRvbmx5KGNvdW50ZXIpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gdXNlTGFzdENoYW5nZWQvaW5kZXgudHNcbmZ1bmN0aW9uIHVzZUxhc3RDaGFuZ2VkKHNvdXJjZSwgb3B0aW9ucyA9IHt9KSB7XG5cdHZhciBfb3B0aW9ucyRpbml0aWFsVmFsdWU7XG5cdGNvbnN0IG1zID0gc2hhbGxvd1JlZigoX29wdGlvbnMkaW5pdGlhbFZhbHVlID0gb3B0aW9ucy5pbml0aWFsVmFsdWUpICE9PSBudWxsICYmIF9vcHRpb25zJGluaXRpYWxWYWx1ZSAhPT0gdm9pZCAwID8gX29wdGlvbnMkaW5pdGlhbFZhbHVlIDogbnVsbCk7XG5cdHdhdGNoKHNvdXJjZSwgKCkgPT4gbXMudmFsdWUgPSB0aW1lc3RhbXAoKSwgb3B0aW9ucyk7XG5cdHJldHVybiBzaGFsbG93UmVhZG9ubHkobXMpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gdXNlVGltZW91dEZuL2luZGV4LnRzXG4vKipcbiogV3JhcHBlciBmb3IgYHNldFRpbWVvdXRgIHdpdGggY29udHJvbHMuXG4qXG4qIEBwYXJhbSBjYlxuKiBAcGFyYW0gaW50ZXJ2YWxcbiogQHBhcmFtIG9wdGlvbnNcbiovXG5mdW5jdGlvbiB1c2VUaW1lb3V0Rm4oY2IsIGludGVydmFsLCBvcHRpb25zID0ge30pIHtcblx0Y29uc3QgeyBpbW1lZGlhdGUgPSB0cnVlLCBpbW1lZGlhdGVDYWxsYmFjayA9IGZhbHNlIH0gPSBvcHRpb25zO1xuXHRjb25zdCBpc1BlbmRpbmcgPSBzaGFsbG93UmVmKGZhbHNlKTtcblx0bGV0IHRpbWVyO1xuXHRmdW5jdGlvbiBjbGVhcigpIHtcblx0XHRpZiAodGltZXIpIHtcblx0XHRcdGNsZWFyVGltZW91dCh0aW1lcik7XG5cdFx0XHR0aW1lciA9IHZvaWQgMDtcblx0XHR9XG5cdH1cblx0ZnVuY3Rpb24gc3RvcCgpIHtcblx0XHRpc1BlbmRpbmcudmFsdWUgPSBmYWxzZTtcblx0XHRjbGVhcigpO1xuXHR9XG5cdGZ1bmN0aW9uIHN0YXJ0KC4uLmFyZ3MpIHtcblx0XHRpZiAoaW1tZWRpYXRlQ2FsbGJhY2spIGNiKCk7XG5cdFx0Y2xlYXIoKTtcblx0XHRpc1BlbmRpbmcudmFsdWUgPSB0cnVlO1xuXHRcdHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHRpc1BlbmRpbmcudmFsdWUgPSBmYWxzZTtcblx0XHRcdHRpbWVyID0gdm9pZCAwO1xuXHRcdFx0Y2IoLi4uYXJncyk7XG5cdFx0fSwgdG9WYWx1ZShpbnRlcnZhbCkpO1xuXHR9XG5cdGlmIChpbW1lZGlhdGUpIHtcblx0XHRpc1BlbmRpbmcudmFsdWUgPSB0cnVlO1xuXHRcdGlmIChpc0NsaWVudCkgc3RhcnQoKTtcblx0fVxuXHR0cnlPblNjb3BlRGlzcG9zZShzdG9wKTtcblx0cmV0dXJuIHtcblx0XHRpc1BlbmRpbmc6IHNoYWxsb3dSZWFkb25seShpc1BlbmRpbmcpLFxuXHRcdHN0YXJ0LFxuXHRcdHN0b3Bcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHVzZVRpbWVvdXQvaW5kZXgudHNcbmZ1bmN0aW9uIHVzZVRpbWVvdXQoaW50ZXJ2YWwgPSAxZTMsIG9wdGlvbnMgPSB7fSkge1xuXHRjb25zdCB7IGNvbnRyb2xzOiBleHBvc2VDb250cm9scyA9IGZhbHNlLCBjYWxsYmFjayB9ID0gb3B0aW9ucztcblx0Y29uc3QgY29udHJvbHMgPSB1c2VUaW1lb3V0Rm4oY2FsbGJhY2sgIT09IG51bGwgJiYgY2FsbGJhY2sgIT09IHZvaWQgMCA/IGNhbGxiYWNrIDogbm9vcCwgaW50ZXJ2YWwsIG9wdGlvbnMpO1xuXHRjb25zdCByZWFkeSA9IGNvbXB1dGVkKCgpID0+ICFjb250cm9scy5pc1BlbmRpbmcudmFsdWUpO1xuXHRpZiAoZXhwb3NlQ29udHJvbHMpIHJldHVybiB7XG5cdFx0cmVhZHksXG5cdFx0Li4uY29udHJvbHNcblx0fTtcblx0ZWxzZSByZXR1cm4gcmVhZHk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiB1c2VUb051bWJlci9pbmRleC50c1xuLyoqXG4qIFJlYWN0aXZlbHkgY29udmVydCBhIHN0cmluZyByZWYgdG8gbnVtYmVyLlxuKlxuKiBAX19OT19TSURFX0VGRkVDVFNfX1xuKi9cbmZ1bmN0aW9uIHVzZVRvTnVtYmVyKHZhbHVlLCBvcHRpb25zID0ge30pIHtcblx0Y29uc3QgeyBtZXRob2QgPSBcInBhcnNlRmxvYXRcIiwgcmFkaXgsIG5hblRvWmVybyB9ID0gb3B0aW9ucztcblx0cmV0dXJuIGNvbXB1dGVkKCgpID0+IHtcblx0XHRsZXQgcmVzb2x2ZWQgPSB0b1ZhbHVlKHZhbHVlKTtcblx0XHRpZiAodHlwZW9mIG1ldGhvZCA9PT0gXCJmdW5jdGlvblwiKSByZXNvbHZlZCA9IG1ldGhvZChyZXNvbHZlZCk7XG5cdFx0ZWxzZSBpZiAodHlwZW9mIHJlc29sdmVkID09PSBcInN0cmluZ1wiKSByZXNvbHZlZCA9IE51bWJlclttZXRob2RdKHJlc29sdmVkLCByYWRpeCk7XG5cdFx0aWYgKG5hblRvWmVybyAmJiBOdW1iZXIuaXNOYU4ocmVzb2x2ZWQpKSByZXNvbHZlZCA9IDA7XG5cdFx0cmV0dXJuIHJlc29sdmVkO1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHVzZVRvU3RyaW5nL2luZGV4LnRzXG4vKipcbiogUmVhY3RpdmVseSBjb252ZXJ0IGEgcmVmIHRvIHN0cmluZy5cbipcbiogQHNlZSBodHRwczovL3Z1ZXVzZS5vcmcvdXNlVG9TdHJpbmdcbipcbiogQF9fTk9fU0lERV9FRkZFQ1RTX19cbiovXG5mdW5jdGlvbiB1c2VUb1N0cmluZyh2YWx1ZSkge1xuXHRyZXR1cm4gY29tcHV0ZWQoKCkgPT4gYCR7dG9WYWx1ZSh2YWx1ZSl9YCk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiB1c2VUb2dnbGUvaW5kZXgudHNcbi8qKlxuKiBBIGJvb2xlYW4gcmVmIHdpdGggYSB0b2dnbGVyXG4qXG4qIEBzZWUgaHR0cHM6Ly92dWV1c2Uub3JnL3VzZVRvZ2dsZVxuKiBAcGFyYW0gW2luaXRpYWxWYWx1ZV1cbiogQHBhcmFtIG9wdGlvbnNcbipcbiogQF9fTk9fU0lERV9FRkZFQ1RTX19cbiovXG5mdW5jdGlvbiB1c2VUb2dnbGUoaW5pdGlhbFZhbHVlID0gZmFsc2UsIG9wdGlvbnMgPSB7fSkge1xuXHRjb25zdCB7IHRydXRoeVZhbHVlID0gdHJ1ZSwgZmFsc3lWYWx1ZSA9IGZhbHNlIH0gPSBvcHRpb25zO1xuXHRjb25zdCB2YWx1ZUlzUmVmID0gaXNSZWYoaW5pdGlhbFZhbHVlKTtcblx0Y29uc3QgX3ZhbHVlID0gc2hhbGxvd1JlZihpbml0aWFsVmFsdWUpO1xuXHRmdW5jdGlvbiB0b2dnbGUodmFsdWUpIHtcblx0XHRpZiAoYXJndW1lbnRzLmxlbmd0aCkge1xuXHRcdFx0X3ZhbHVlLnZhbHVlID0gdmFsdWU7XG5cdFx0XHRyZXR1cm4gX3ZhbHVlLnZhbHVlO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRjb25zdCB0cnV0aHkgPSB0b1ZhbHVlKHRydXRoeVZhbHVlKTtcblx0XHRcdF92YWx1ZS52YWx1ZSA9IF92YWx1ZS52YWx1ZSA9PT0gdHJ1dGh5ID8gdG9WYWx1ZShmYWxzeVZhbHVlKSA6IHRydXRoeTtcblx0XHRcdHJldHVybiBfdmFsdWUudmFsdWU7XG5cdFx0fVxuXHR9XG5cdGlmICh2YWx1ZUlzUmVmKSByZXR1cm4gdG9nZ2xlO1xuXHRlbHNlIHJldHVybiBbX3ZhbHVlLCB0b2dnbGVdO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gd2F0Y2hBcnJheS9pbmRleC50c1xuLyoqXG4qIFdhdGNoIGZvciBhbiBhcnJheSB3aXRoIGFkZGl0aW9ucyBhbmQgcmVtb3ZhbHMuXG4qXG4qIEBzZWUgaHR0cHM6Ly92dWV1c2Uub3JnL3dhdGNoQXJyYXlcbiovXG5mdW5jdGlvbiB3YXRjaEFycmF5KHNvdXJjZSwgY2IsIG9wdGlvbnMpIHtcblx0bGV0IG9sZExpc3QgPSAob3B0aW9ucyA9PT0gbnVsbCB8fCBvcHRpb25zID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvcHRpb25zLmltbWVkaWF0ZSkgPyBbXSA6IFsuLi50eXBlb2Ygc291cmNlID09PSBcImZ1bmN0aW9uXCIgPyBzb3VyY2UoKSA6IEFycmF5LmlzQXJyYXkoc291cmNlKSA/IHNvdXJjZSA6IHRvVmFsdWUoc291cmNlKV07XG5cdHJldHVybiB3YXRjaChzb3VyY2UsIChuZXdMaXN0LCBfLCBvbkNsZWFudXApID0+IHtcblx0XHRjb25zdCBvbGRMaXN0UmVtYWlucyA9IEFycmF5LmZyb20oeyBsZW5ndGg6IG9sZExpc3QubGVuZ3RoIH0pO1xuXHRcdGNvbnN0IGFkZGVkID0gW107XG5cdFx0Zm9yIChjb25zdCBvYmogb2YgbmV3TGlzdCkge1xuXHRcdFx0bGV0IGZvdW5kID0gZmFsc2U7XG5cdFx0XHRmb3IgKGxldCBpID0gMDsgaSA8IG9sZExpc3QubGVuZ3RoOyBpKyspIGlmICghb2xkTGlzdFJlbWFpbnNbaV0gJiYgb2JqID09PSBvbGRMaXN0W2ldKSB7XG5cdFx0XHRcdG9sZExpc3RSZW1haW5zW2ldID0gdHJ1ZTtcblx0XHRcdFx0Zm91bmQgPSB0cnVlO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdH1cblx0XHRcdGlmICghZm91bmQpIGFkZGVkLnB1c2gob2JqKTtcblx0XHR9XG5cdFx0Y29uc3QgcmVtb3ZlZCA9IG9sZExpc3QuZmlsdGVyKChfLCBpKSA9PiAhb2xkTGlzdFJlbWFpbnNbaV0pO1xuXHRcdGNiKG5ld0xpc3QsIG9sZExpc3QsIGFkZGVkLCByZW1vdmVkLCBvbkNsZWFudXApO1xuXHRcdG9sZExpc3QgPSBbLi4ubmV3TGlzdF07XG5cdH0sIG9wdGlvbnMpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gd2F0Y2hBdE1vc3QvaW5kZXgudHNcbmZ1bmN0aW9uIHdhdGNoQXRNb3N0KHNvdXJjZSwgY2IsIG9wdGlvbnMpIHtcblx0Y29uc3QgeyBjb3VudCwgLi4ud2F0Y2hPcHRpb25zIH0gPSBvcHRpb25zO1xuXHRjb25zdCBjdXJyZW50ID0gc2hhbGxvd1JlZigwKTtcblx0Y29uc3QgeyBzdG9wLCByZXN1bWUsIHBhdXNlIH0gPSB3YXRjaFdpdGhGaWx0ZXIoc291cmNlLCAoLi4uYXJncykgPT4ge1xuXHRcdGN1cnJlbnQudmFsdWUgKz0gMTtcblx0XHRpZiAoY3VycmVudC52YWx1ZSA+PSB0b1ZhbHVlKGNvdW50KSkgbmV4dFRpY2soKCkgPT4gc3RvcCgpKTtcblx0XHRjYiguLi5hcmdzKTtcblx0fSwgd2F0Y2hPcHRpb25zKTtcblx0cmV0dXJuIHtcblx0XHRjb3VudDogY3VycmVudCxcblx0XHRzdG9wLFxuXHRcdHJlc3VtZSxcblx0XHRwYXVzZVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gd2F0Y2hEZWJvdW5jZWQvaW5kZXgudHNcbmZ1bmN0aW9uIHdhdGNoRGVib3VuY2VkKHNvdXJjZSwgY2IsIG9wdGlvbnMgPSB7fSkge1xuXHRjb25zdCB7IGRlYm91bmNlID0gMCwgbWF4V2FpdCA9IHZvaWQgMCwgLi4ud2F0Y2hPcHRpb25zIH0gPSBvcHRpb25zO1xuXHRyZXR1cm4gd2F0Y2hXaXRoRmlsdGVyKHNvdXJjZSwgY2IsIHtcblx0XHQuLi53YXRjaE9wdGlvbnMsXG5cdFx0ZXZlbnRGaWx0ZXI6IGRlYm91bmNlRmlsdGVyKGRlYm91bmNlLCB7IG1heFdhaXQgfSlcblx0fSk7XG59XG4vKiogQGRlcHJlY2F0ZWQgdXNlIGB3YXRjaERlYm91bmNlZGAgaW5zdGVhZCAqL1xuY29uc3QgZGVib3VuY2VkV2F0Y2ggPSB3YXRjaERlYm91bmNlZDtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHdhdGNoRGVlcC9pbmRleC50c1xuLyoqXG4qIFNob3J0aGFuZCBmb3Igd2F0Y2hpbmcgdmFsdWUgd2l0aCB7ZGVlcDogdHJ1ZX1cbipcbiogQHNlZSBodHRwczovL3Z1ZXVzZS5vcmcvd2F0Y2hEZWVwXG4qL1xuZnVuY3Rpb24gd2F0Y2hEZWVwKHNvdXJjZSwgY2IsIG9wdGlvbnMpIHtcblx0cmV0dXJuIHdhdGNoKHNvdXJjZSwgY2IsIHtcblx0XHQuLi5vcHRpb25zLFxuXHRcdGRlZXA6IHRydWVcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiB3YXRjaElnbm9yYWJsZS9pbmRleC50c1xuZnVuY3Rpb24gd2F0Y2hJZ25vcmFibGUoc291cmNlLCBjYiwgb3B0aW9ucyA9IHt9KSB7XG5cdGNvbnN0IHsgZXZlbnRGaWx0ZXIgPSBieXBhc3NGaWx0ZXIsIC4uLndhdGNoT3B0aW9ucyB9ID0gb3B0aW9ucztcblx0Y29uc3QgZmlsdGVyZWRDYiA9IGNyZWF0ZUZpbHRlcldyYXBwZXIoZXZlbnRGaWx0ZXIsIGNiKTtcblx0bGV0IGlnbm9yZVVwZGF0ZXM7XG5cdGxldCBpZ25vcmVQcmV2QXN5bmNVcGRhdGVzO1xuXHRsZXQgc3RvcDtcblx0aWYgKHdhdGNoT3B0aW9ucy5mbHVzaCA9PT0gXCJzeW5jXCIpIHtcblx0XHRsZXQgaWdub3JlID0gZmFsc2U7XG5cdFx0aWdub3JlUHJldkFzeW5jVXBkYXRlcyA9ICgpID0+IHt9O1xuXHRcdGlnbm9yZVVwZGF0ZXMgPSAodXBkYXRlcikgPT4ge1xuXHRcdFx0aWdub3JlID0gdHJ1ZTtcblx0XHRcdHVwZGF0ZXIoKTtcblx0XHRcdGlnbm9yZSA9IGZhbHNlO1xuXHRcdH07XG5cdFx0c3RvcCA9IHdhdGNoKHNvdXJjZSwgKC4uLmFyZ3MpID0+IHtcblx0XHRcdGlmICghaWdub3JlKSBmaWx0ZXJlZENiKC4uLmFyZ3MpO1xuXHRcdH0sIHdhdGNoT3B0aW9ucyk7XG5cdH0gZWxzZSB7XG5cdFx0Y29uc3QgZGlzcG9zYWJsZXMgPSBbXTtcblx0XHRsZXQgaWdub3JlQ291bnRlciA9IDA7XG5cdFx0bGV0IHN5bmNDb3VudGVyID0gMDtcblx0XHRpZ25vcmVQcmV2QXN5bmNVcGRhdGVzID0gKCkgPT4ge1xuXHRcdFx0aWdub3JlQ291bnRlciA9IHN5bmNDb3VudGVyO1xuXHRcdH07XG5cdFx0ZGlzcG9zYWJsZXMucHVzaCh3YXRjaChzb3VyY2UsICgpID0+IHtcblx0XHRcdHN5bmNDb3VudGVyKys7XG5cdFx0fSwge1xuXHRcdFx0Li4ud2F0Y2hPcHRpb25zLFxuXHRcdFx0Zmx1c2g6IFwic3luY1wiXG5cdFx0fSkpO1xuXHRcdGlnbm9yZVVwZGF0ZXMgPSAodXBkYXRlcikgPT4ge1xuXHRcdFx0Y29uc3Qgc3luY0NvdW50ZXJQcmV2ID0gc3luY0NvdW50ZXI7XG5cdFx0XHR1cGRhdGVyKCk7XG5cdFx0XHRpZ25vcmVDb3VudGVyICs9IHN5bmNDb3VudGVyIC0gc3luY0NvdW50ZXJQcmV2O1xuXHRcdH07XG5cdFx0ZGlzcG9zYWJsZXMucHVzaCh3YXRjaChzb3VyY2UsICguLi5hcmdzKSA9PiB7XG5cdFx0XHRjb25zdCBpZ25vcmUgPSBpZ25vcmVDb3VudGVyID4gMCAmJiBpZ25vcmVDb3VudGVyID09PSBzeW5jQ291bnRlcjtcblx0XHRcdGlnbm9yZUNvdW50ZXIgPSAwO1xuXHRcdFx0c3luY0NvdW50ZXIgPSAwO1xuXHRcdFx0aWYgKGlnbm9yZSkgcmV0dXJuO1xuXHRcdFx0ZmlsdGVyZWRDYiguLi5hcmdzKTtcblx0XHR9LCB3YXRjaE9wdGlvbnMpKTtcblx0XHRzdG9wID0gKCkgPT4ge1xuXHRcdFx0ZGlzcG9zYWJsZXMuZm9yRWFjaCgoZm4pID0+IGZuKCkpO1xuXHRcdH07XG5cdH1cblx0cmV0dXJuIHtcblx0XHRzdG9wLFxuXHRcdGlnbm9yZVVwZGF0ZXMsXG5cdFx0aWdub3JlUHJldkFzeW5jVXBkYXRlc1xuXHR9O1xufVxuLyoqIEBkZXByZWNhdGVkIHVzZSBgd2F0Y2hJZ25vcmFibGVgIGluc3RlYWQgKi9cbmNvbnN0IGlnbm9yYWJsZVdhdGNoID0gd2F0Y2hJZ25vcmFibGU7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiB3YXRjaEltbWVkaWF0ZS9pbmRleC50c1xuLyoqXG4qIFNob3J0aGFuZCBmb3Igd2F0Y2hpbmcgdmFsdWUgd2l0aCB7aW1tZWRpYXRlOiB0cnVlfVxuKlxuKiBAc2VlIGh0dHBzOi8vdnVldXNlLm9yZy93YXRjaEltbWVkaWF0ZVxuKi9cbmZ1bmN0aW9uIHdhdGNoSW1tZWRpYXRlKHNvdXJjZSwgY2IsIG9wdGlvbnMpIHtcblx0cmV0dXJuIHdhdGNoKHNvdXJjZSwgY2IsIHtcblx0XHQuLi5vcHRpb25zLFxuXHRcdGltbWVkaWF0ZTogdHJ1ZVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHdhdGNoT25jZS9pbmRleC50c1xuLyoqXG4qIFNob3J0aGFuZCBmb3Igd2F0Y2hpbmcgdmFsdWUgd2l0aCB7IG9uY2U6IHRydWUgfVxuKlxuKiBAc2VlIGh0dHBzOi8vdnVldXNlLm9yZy93YXRjaE9uY2VcbiovXG5mdW5jdGlvbiB3YXRjaE9uY2Uoc291cmNlLCBjYiwgb3B0aW9ucykge1xuXHRyZXR1cm4gd2F0Y2goc291cmNlLCBjYiwge1xuXHRcdC4uLm9wdGlvbnMsXG5cdFx0b25jZTogdHJ1ZVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHdhdGNoVGhyb3R0bGVkL2luZGV4LnRzXG5mdW5jdGlvbiB3YXRjaFRocm90dGxlZChzb3VyY2UsIGNiLCBvcHRpb25zID0ge30pIHtcblx0Y29uc3QgeyB0aHJvdHRsZSA9IDAsIHRyYWlsaW5nID0gdHJ1ZSwgbGVhZGluZyA9IHRydWUsIC4uLndhdGNoT3B0aW9ucyB9ID0gb3B0aW9ucztcblx0cmV0dXJuIHdhdGNoV2l0aEZpbHRlcihzb3VyY2UsIGNiLCB7XG5cdFx0Li4ud2F0Y2hPcHRpb25zLFxuXHRcdGV2ZW50RmlsdGVyOiB0aHJvdHRsZUZpbHRlcih0aHJvdHRsZSwgdHJhaWxpbmcsIGxlYWRpbmcpXG5cdH0pO1xufVxuLyoqIEBkZXByZWNhdGVkIHVzZSBgd2F0Y2hUaHJvdHRsZWRgIGluc3RlYWQgKi9cbmNvbnN0IHRocm90dGxlZFdhdGNoID0gd2F0Y2hUaHJvdHRsZWQ7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiB3YXRjaFRyaWdnZXJhYmxlL2luZGV4LnRzXG5mdW5jdGlvbiB3YXRjaFRyaWdnZXJhYmxlKHNvdXJjZSwgY2IsIG9wdGlvbnMgPSB7fSkge1xuXHRsZXQgY2xlYW51cEZuO1xuXHRmdW5jdGlvbiBvbkVmZmVjdCgpIHtcblx0XHRpZiAoIWNsZWFudXBGbikgcmV0dXJuO1xuXHRcdGNvbnN0IGZuID0gY2xlYW51cEZuO1xuXHRcdGNsZWFudXBGbiA9IHZvaWQgMDtcblx0XHRmbigpO1xuXHR9XG5cdC8qKiBSZWdpc3RlciB0aGUgZnVuY3Rpb24gYGNsZWFudXBGbmAgKi9cblx0ZnVuY3Rpb24gb25DbGVhbnVwKGNhbGxiYWNrKSB7XG5cdFx0Y2xlYW51cEZuID0gY2FsbGJhY2s7XG5cdH1cblx0Y29uc3QgX2NiID0gKHZhbHVlLCBvbGRWYWx1ZSkgPT4ge1xuXHRcdG9uRWZmZWN0KCk7XG5cdFx0cmV0dXJuIGNiKHZhbHVlLCBvbGRWYWx1ZSwgb25DbGVhbnVwKTtcblx0fTtcblx0Y29uc3QgcmVzID0gd2F0Y2hJZ25vcmFibGUoc291cmNlLCBfY2IsIG9wdGlvbnMpO1xuXHRjb25zdCB7IGlnbm9yZVVwZGF0ZXMgfSA9IHJlcztcblx0Y29uc3QgdHJpZ2dlciA9ICgpID0+IHtcblx0XHRsZXQgcmVzO1xuXHRcdGlnbm9yZVVwZGF0ZXMoKCkgPT4ge1xuXHRcdFx0cmVzID0gX2NiKGdldFdhdGNoU291cmNlcyhzb3VyY2UpLCBnZXRPbGRWYWx1ZShzb3VyY2UpKTtcblx0XHR9KTtcblx0XHRyZXR1cm4gcmVzO1xuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdC4uLnJlcyxcblx0XHR0cmlnZ2VyXG5cdH07XG59XG5mdW5jdGlvbiBnZXRXYXRjaFNvdXJjZXMoc291cmNlcykge1xuXHRpZiAoaXNSZWFjdGl2ZShzb3VyY2VzKSkgcmV0dXJuIHNvdXJjZXM7XG5cdGlmIChBcnJheS5pc0FycmF5KHNvdXJjZXMpKSByZXR1cm4gc291cmNlcy5tYXAoKGl0ZW0pID0+IHRvVmFsdWUoaXRlbSkpO1xuXHRyZXR1cm4gdG9WYWx1ZShzb3VyY2VzKTtcbn1cbmZ1bmN0aW9uIGdldE9sZFZhbHVlKHNvdXJjZSkge1xuXHRyZXR1cm4gQXJyYXkuaXNBcnJheShzb3VyY2UpID8gc291cmNlLm1hcCgoKSA9PiB2b2lkIDApIDogdm9pZCAwO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gd2hlbmV2ZXIvaW5kZXgudHNcbmZ1bmN0aW9uIHdoZW5ldmVyKHNvdXJjZSwgY2IsIG9wdGlvbnMpIHtcblx0Y29uc3Qgc3RvcCA9IHdhdGNoKHNvdXJjZSwgKHYsIG92LCBvbkludmFsaWRhdGUpID0+IHtcblx0XHRpZiAodikge1xuXHRcdFx0aWYgKG9wdGlvbnMgPT09IG51bGwgfHwgb3B0aW9ucyA9PT0gdm9pZCAwID8gdm9pZCAwIDogb3B0aW9ucy5vbmNlKSBuZXh0VGljaygoKSA9PiBzdG9wKCkpO1xuXHRcdFx0Y2Iodiwgb3YsIG9uSW52YWxpZGF0ZSk7XG5cdFx0fVxuXHR9LCB7XG5cdFx0Li4ub3B0aW9ucyxcblx0XHRvbmNlOiBmYWxzZVxuXHR9KTtcblx0cmV0dXJuIHN0b3A7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGFzc2VydCwgYXV0b1Jlc2V0UmVmLCBieXBhc3NGaWx0ZXIsIGNhbWVsaXplLCBjbGFtcCwgY29tcHV0ZWRFYWdlciwgY29tcHV0ZWRXaXRoQ29udHJvbCwgY29udGFpbnNQcm9wLCBjb250cm9sbGVkQ29tcHV0ZWQsIGNvbnRyb2xsZWRSZWYsIGNyZWF0ZURpc3Bvc2FibGVEaXJlY3RpdmUsIGNyZWF0ZUV2ZW50SG9vaywgY3JlYXRlRmlsdGVyV3JhcHBlciwgY3JlYXRlR2xvYmFsU3RhdGUsIGNyZWF0ZUluamVjdGlvblN0YXRlLCBjcmVhdGVSZWFjdGl2ZUZuLCBjcmVhdGVSZWYsIGNyZWF0ZVNoYXJlZENvbXBvc2FibGUsIGNyZWF0ZVNpbmdsZXRvblByb21pc2UsIGRlYm91bmNlRmlsdGVyLCBkZWJvdW5jZWRSZWYsIGRlYm91bmNlZFdhdGNoLCBlYWdlckNvbXB1dGVkLCBleHRlbmRSZWYsIGZvcm1hdERhdGUsIGdldCwgZ2V0TGlmZUN5Y2xlVGFyZ2V0LCBoYXNPd24sIGh5cGhlbmF0ZSwgaWRlbnRpdHksIGlnbm9yYWJsZVdhdGNoLCBpbmNyZWFzZVdpdGhVbml0LCBpbmplY3RMb2NhbCwgaW52b2tlLCBpc0NsaWVudCwgaXNEZWYsIGlzRGVmaW5lZCwgaXNJT1MsIGlzT2JqZWN0LCBpc1dvcmtlciwgbWFrZURlc3RydWN0dXJhYmxlLCBub29wLCBub3JtYWxpemVEYXRlLCBub3ROdWxsaXNoLCBub3csIG9iamVjdEVudHJpZXMsIG9iamVjdE9taXQsIG9iamVjdFBpY2ssIHBhdXNhYmxlRmlsdGVyLCBwYXVzYWJsZVdhdGNoLCBwcm9taXNlVGltZW91dCwgcHJvdmlkZUxvY2FsLCBweFZhbHVlLCByYW5kLCByZWFjdGlmeSwgcmVhY3RpZnlPYmplY3QsIHJlYWN0aXZlQ29tcHV0ZWQsIHJlYWN0aXZlT21pdCwgcmVhY3RpdmVQaWNrLCByZWZBdXRvUmVzZXQsIHJlZkRlYm91bmNlZCwgcmVmRGVmYXVsdCwgcmVmTWFudWFsUmVzZXQsIHJlZlRocm90dGxlZCwgcmVmV2l0aENvbnRyb2wsIHNldCwgc3luY1JlZiwgc3luY1JlZnMsIHRocm90dGxlRmlsdGVyLCB0aHJvdHRsZWRSZWYsIHRocm90dGxlZFdhdGNoLCB0aW1lc3RhbXAsIHRvQXJyYXksIHRvUmVhY3RpdmUsIHRvUmVmLCB0b1JlZnMsIHRyeU9uQmVmb3JlTW91bnQsIHRyeU9uQmVmb3JlVW5tb3VudCwgdHJ5T25Nb3VudGVkLCB0cnlPblNjb3BlRGlzcG9zZSwgdHJ5T25Vbm1vdW50ZWQsIHVudGlsLCB1c2VBcnJheURpZmZlcmVuY2UsIHVzZUFycmF5RXZlcnksIHVzZUFycmF5RmlsdGVyLCB1c2VBcnJheUZpbmQsIHVzZUFycmF5RmluZEluZGV4LCB1c2VBcnJheUZpbmRMYXN0LCB1c2VBcnJheUluY2x1ZGVzLCB1c2VBcnJheUpvaW4sIHVzZUFycmF5TWFwLCB1c2VBcnJheVJlZHVjZSwgdXNlQXJyYXlTb21lLCB1c2VBcnJheVVuaXF1ZSwgdXNlQ291bnRlciwgdXNlRGF0ZUZvcm1hdCwgdXNlRGVib3VuY2UsIHVzZURlYm91bmNlRm4sIHVzZUludGVydmFsLCB1c2VJbnRlcnZhbEZuLCB1c2VMYXN0Q2hhbmdlZCwgdXNlVGhyb3R0bGUsIHVzZVRocm90dGxlRm4sIHVzZVRpbWVvdXQsIHVzZVRpbWVvdXRGbiwgdXNlVG9OdW1iZXIsIHVzZVRvU3RyaW5nLCB1c2VUb2dnbGUsIHdhdGNoQXJyYXksIHdhdGNoQXRNb3N0LCB3YXRjaERlYm91bmNlZCwgd2F0Y2hEZWVwLCB3YXRjaElnbm9yYWJsZSwgd2F0Y2hJbW1lZGlhdGUsIHdhdGNoT25jZSwgd2F0Y2hQYXVzYWJsZSwgd2F0Y2hUaHJvdHRsZWQsIHdhdGNoVHJpZ2dlcmFibGUsIHdhdGNoV2l0aEZpbHRlciwgd2hlbmV2ZXIgfTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3pnQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztBQUM5QixDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsT0FBTztBQUM3RDtBQUNBLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsT0FBTztBQUN4RSxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTTtBQUM1RCxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxTQUFTO0FBQ2pGLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDNUM7QUFDQSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUM7QUFDcEIsQ0FBQztBQUNELFFBQVEsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUs7QUFDbkIsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUM1QixDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ1osQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQzFKLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztBQUN4QjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDN0MsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsYUFBYTtBQUNuQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUM7QUFDcEMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsUUFBUTtBQUN4QztBQUNBLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNULENBQUM7QUFDRCxRQUFRLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZELENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDZixDQUFDLEdBQUcsQ0FBQyxLQUFLO0FBQ1YsQ0FBQyxHQUFHLENBQUMsT0FBTztBQUNaLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNqQixDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDZCxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUM7QUFDRixDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUc7QUFDbkQsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUc7QUFDdkQsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ2hCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDcEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUM1QyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDeEIsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25ELEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsbUJBQW1CO0FBQzlDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLHlCQUF5QixDQUFDLEtBQUssQ0FBQztBQUMxQyxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsU0FBUztBQUM5SztBQUNBLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDMUI7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxRQUFRLENBQUMseUJBQXlCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hELENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNqQyxDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU07QUFDakIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDWCxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCO0FBQ2hELENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNwQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNuRCxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0I7QUFDckIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEdBQUc7QUFDeEIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3hJLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ25GLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLElBQUk7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNySCxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ2pFLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDO0FBQ2xDLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUM3RTtBQUNBLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNULENBQUM7QUFDRCxRQUFRLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDN0MsQ0FBQyxFQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUM7QUFDbEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQ2IsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDYjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUM7QUFDaEMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQztBQUM3QjtBQUNBLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDMUI7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxRQUFRLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQztBQUMzQixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN0QyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO0FBQ2hCLENBQUMsQ0FBQztBQUNGLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQztBQUNGLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztBQUM3QixDQUFDLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQztBQUNGLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUM5RCxDQUFDLENBQUM7QUFDRixDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxFQUFFO0FBQ0osQ0FBQyxDQUFDLEdBQUc7QUFDTCxDQUFDLENBQUMsT0FBTztBQUNULENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDO0FBQ2xDLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVM7QUFDckU7QUFDQSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDdkQ7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxRQUFRLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDekMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3hCLENBQUMsR0FBRyxDQUFDLEtBQUs7QUFDVixDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUM7QUFDaEMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3JCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNkLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDO0FBQzNCLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7QUFDNUIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTO0FBQzlIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNELEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxHQUFHLENBQUMsbUJBQW1CO0FBQ3hCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsS0FBSztBQUM5SSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDO0FBQ3RGLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNwRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUN2SSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3ZCLENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDO0FBQzdCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUztBQUMvSDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUNELFFBQVEsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxHQUFHLENBQUMsbUJBQW1CO0FBQ3hCLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLO0FBQzlJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDdEYsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzNFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM3RixDQUFDLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztBQUM1RCxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ2hDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDM0I7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUM7QUFDckMsUUFBUSxDQUFDLG9CQUFvQixDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25ELENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDcEksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVk7QUFDNUYsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDbkMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDMUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2QsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUM7QUFDOUQsQ0FBQyxNQUFNLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLGdCQUFnQixDQUFDO0FBQzdDO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQztBQUMxQixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSztBQUNuRTtBQUNBLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU07QUFDNUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTTtBQUNuRCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNO0FBQzNDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNO0FBQ25ELENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZEO0FBQ0EsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVU7QUFDdkM7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxRQUFRLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2hDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7QUFDckMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7QUFDOUI7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO0FBQ25CLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNqRixLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsaUJBQWlCO0FBQ3BHLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ2pELEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDdkMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDdkMsQ0FBQztBQUNELEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUTtBQUMxQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ2xFLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM1QixLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNuQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5RCxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDckIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ3RCLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDekQsQ0FBQztBQUNELEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDcEQsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDeEMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUTtBQUNoQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDeGY7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO0FBQ3RCLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDeEIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQy9DLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVELENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDZDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7QUFDeEIsUUFBUSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDdEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUN2QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDckIsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsTUFBTSxDQUFDLE9BQU87QUFDZjtBQUNBLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDaEIsQ0FBQztBQUNELENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQztBQUMxQyxDQUFDO0FBQ0QsUUFBUSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxHQUFHLENBQUMsS0FBSztBQUNWLENBQUMsR0FBRyxDQUFDLFFBQVE7QUFDYixDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDeEIsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3ZCLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztBQUNuQyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUM7QUFDckIsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDckIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxHQUFHLENBQUMsV0FBVztBQUNoQixDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7QUFDOUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25FLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDdkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDM0QsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUN2QixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3RCxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFDRixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSztBQUN6QixDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDckIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxlQUFlLENBQUMsUUFBUTtBQUNyQyxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsUUFBUSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNqQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxHQUFHLENBQUMsS0FBSztBQUNWLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNyQixDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDeEIsQ0FBQyxHQUFHLENBQUMsU0FBUztBQUNkLENBQUMsR0FBRyxDQUFDLEVBQUU7QUFDUCxDQUFDLEdBQUcsQ0FBQyxRQUFRO0FBQ2IsQ0FBQyxHQUFHLENBQUMsT0FBTztBQUNaLENBQUMsR0FBRyxDQUFDLGNBQWM7QUFDbkIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JJLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDMUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3RCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztBQUM5QixDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDdkMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDdEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNuRCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDOUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNuQixDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVM7QUFDbEIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUNoRTtBQUNBLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7QUFDM0YsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUM7QUFDMUMsQ0FBQztBQUNELFFBQVEsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDNUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNsRCxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3hCLENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3ZCLENBQUM7QUFDRCxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzNDLENBQUMsQ0FBQztBQUNGLENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUM7QUFDckMsQ0FBQyxDQUFDLEtBQUs7QUFDUCxDQUFDLENBQUMsTUFBTTtBQUNSLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUN4QixRQUFRLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDeEUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ3BELENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsUUFBUSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN2QixDQUFDLE1BQU0sQ0FBQyxHQUFHO0FBQ1g7QUFDQSxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUM7QUFDM0I7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUQ7QUFDQSxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUNoQixDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQ2xFLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQztBQUNyQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUNELFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNwQyxDQUFDLEdBQUcsQ0FBQyxRQUFRO0FBQ2IsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUTtBQUNqQixDQUFDO0FBQ0QsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDeEIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLO0FBQ3hCLENBQUMsQ0FBQztBQUNGLENBQUMsTUFBTSxDQUFDLE9BQU87QUFDZjtBQUNBLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDcEIsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDWjtBQUNBLFFBQVEsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDckMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDO0FBQ25DO0FBQ0EsUUFBUSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3pDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLO0FBQ2xCLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3RELENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO0FBQ3hDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNoRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUN4QyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDckI7QUFDQSxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQztBQUMzSSxDQUFDO0FBQ0QsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNyQixDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQztBQUMvRTtBQUNBLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7QUFDdkMsQ0FBQztBQUNELFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN0RCxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUN6RCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1A7QUFDQSxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUM1QyxDQUFDO0FBQ0QsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3RELENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDO0FBQ3BFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSjtBQUNBLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7QUFDM0I7QUFDQSxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3hCLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDOUM7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO0FBQ3JCLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNqQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO0FBQ2xDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQzdGLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQixLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRSxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ3BCLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNwQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQztBQUN0QztBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLHNCQUFzQixDQUFDLEtBQUssQ0FBQztBQUN2QyxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxTQUFTO0FBQy9EO0FBQ0EsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUMxQjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNELFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUM1QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVU7QUFDakMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsR0FBRyxDQUFDLEtBQUs7QUFDVixDQUFDLEdBQUcsQ0FBQyxLQUFLO0FBQ1YsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNkLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDO0FBQzFCLFFBQVEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVFLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNwRCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDL0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzlELENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNSLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxHQUFHO0FBQ1g7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO0FBQ3BCLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDbkMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUN2QjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7QUFDMUIsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUN4QjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDekIsUUFBUSxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDZCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUMzQztBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7QUFDekIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVE7QUFDbEQsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUMvQztBQUNBLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUNuQjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNELFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTztBQUN2SCxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRSxDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDeEMsS0FBSyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2pDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUM7QUFDL0IsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUM7QUFDekI7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxRQUFRLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRCxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsR0FBRyxDQUFDLE9BQU87QUFDWixDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGFBQWE7QUFDdkQsQ0FBQyxJQUFJLENBQUM7QUFDTixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxhQUFhO0FBQ3pCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhO0FBQ3ZELENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDekUsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3hGLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7QUFDM0IsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFFBQVE7QUFDMUI7QUFDQSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUM7QUFDNUIsQ0FBQztBQUNELFFBQVEsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDO0FBQ2xELENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzFELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDbkYsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDbEMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDZCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUk7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDO0FBQ2pDLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE1BQU07QUFDMUIsQ0FBQztBQUNELFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUM5QixDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2hDO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQztBQUM3QixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDekM7QUFDQSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQzFCLENBQUM7QUFDRCxRQUFRLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3BDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzdCLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN1A7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDO0FBQzdCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUN6QztBQUNBLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDMUIsQ0FBQztBQUNELFFBQVEsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDcEMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDN0IsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5TjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUM7QUFDN0IsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJO0FBQ3ZFO0FBQ0EsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsR0FBRztBQUNqRCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxZQUFZO0FBQzdELENBQUM7QUFDRCxRQUFRLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUM7QUFDbkMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLO0FBQ1gsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzVDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFlBQVk7QUFDakMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQztBQUM5QixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDbEM7QUFDQSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLFNBQVM7QUFDbEYsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNO0FBQzdJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCO0FBQ0EsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsVUFBVTtBQUNqRixDQUFDO0FBQ0QsUUFBUSxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDNUQ7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDO0FBQzdCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUMzQjtBQUNBLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFHO0FBQzdCLENBQUM7QUFDRCxRQUFRLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JELENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN0QyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUs7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDaEIsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDO0FBQ2xDO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM1QyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxZQUFZO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDNUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsWUFBWTtBQUNoQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO0FBQzNCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDOUI7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxRQUFRLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQzFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztBQUNqQixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSztBQUNwQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFlBQVk7QUFDNUcsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSztBQUN2QixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQztBQUMvQixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsYUFBYTtBQUM5QztBQUNBLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUc7QUFDakQsQ0FBQztBQUNELFFBQVEsQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDdEMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDO0FBQ2xDLENBQUMsR0FBRyxDQUFDLE9BQU87QUFDWixDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUM7QUFDL0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRCxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ3BCLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3ZCLENBQUMsTUFBTSxDQUFDLFFBQVE7QUFDaEI7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDO0FBQzlCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0FBQy9ELENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU07QUFDeEQ7QUFDQSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUU7QUFDNUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLFFBQVE7QUFDMUYsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU07QUFDakosQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHO0FBQ3hEO0FBQ0EsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSztBQUNyRjtBQUNBLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSTtBQUM5RjtBQUNBLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLO0FBQ2pHO0FBQ0EsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVE7QUFDckM7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxRQUFRLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDL0YsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ3RGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQztBQUM3QixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztBQUMvRCxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNO0FBQ3hEO0FBQ0EsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7QUFDckQsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU07QUFDeEksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7QUFDMUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO0FBQ3pFLENBQUM7QUFDRCxRQUFRLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzNFLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQzdCLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN0QyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUs7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDN0IsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLE1BQU0sQ0FBQyxTQUFTO0FBQ2pCO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM1QyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxZQUFZO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDNUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsWUFBWTtBQUNoQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDO0FBQy9CLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsVUFBVTtBQUNuRDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNELFFBQVEsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9DLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNyQixDQUFDLEdBQUcsQ0FBQyxLQUFLO0FBQ1YsQ0FBQyxHQUFHLENBQUMsT0FBTztBQUNaLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNoQixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ3BCLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDZixDQUFDO0FBQ0QsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVM7QUFDL0MsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU07QUFDOUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDcEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNO0FBQ2xMLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDaEIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNwSSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDM0IsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQztBQUNuRCxDQUFDLENBQUM7QUFDRixDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7QUFDdEMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7QUFDbkQsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLE1BQU07QUFDekQsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUM7QUFDRixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7QUFDbkQsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQztBQUNGLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2pDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsR0FBRztBQUNMLENBQUMsQ0FBQyxHQUFHO0FBQ0wsQ0FBQyxDQUFDLFlBQVk7QUFDZCxDQUFDLENBQUMsU0FBUztBQUNYLENBQUMsQ0FBQyxJQUFJO0FBQ04sQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUN6QjtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDOUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsY0FBYztBQUNwQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO0FBQ3BCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUM7QUFDRCxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3RCLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMzQixDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNuQixDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ25DLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDckIsQ0FBQztBQUNEO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztBQUNoQyxRQUFRLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ2hFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQztBQUN6RTtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDdEcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakQsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDbEYsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztBQUMxRixDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWTtBQUNsQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsS0FBSztBQUNQLENBQUMsQ0FBQyxNQUFNO0FBQ1IsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUN0RyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxhQUFhO0FBQ25DLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7QUFDeEIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGVBQWU7QUFDOUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUMzRCxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEtBQUs7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQztBQUNELFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQzVDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0csQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZFLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2RSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQztBQUN0QyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsS0FBSztBQUNQLENBQUMsQ0FBQyxJQUFJO0FBQ04sQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxLQUFLO0FBQ1AsQ0FBQyxDQUFDLElBQUk7QUFDTixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQztBQUNGLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDWjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7QUFDekIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7QUFDN0M7QUFDQSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDVCxDQUFDO0FBQ0QsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakQsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ25FLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztBQUN0QyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUMvRixDQUFDLENBQUMsS0FBSztBQUNQLENBQUMsQ0FBQyxJQUFJO0FBQ04sQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDdkIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLE1BQU07QUFDdkQ7QUFDQSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsS0FBSztBQUNsRCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO0FBQ2pCLENBQUM7QUFDRCxRQUFRLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ2xELENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUTtBQUNmLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ3ZJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUs7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM1RSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVM7QUFDL0IsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDO0FBQ2pDLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDbkY7QUFDQSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDaEUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1QsQ0FBQztBQUNELFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ25ELENBQUMsRUFBRSxDQUFDLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzFELENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUM7QUFDbEI7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUM7QUFDbkMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDMUU7QUFDQSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDVCxDQUFDO0FBQ0QsUUFBUSxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3hDLENBQUMsRUFBRSxDQUFDLENBQUMsa0JBQWtCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzVEO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQztBQUM3QixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQy9FO0FBQ0EsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNULENBQUM7QUFDRCxRQUFRLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDL0MsQ0FBQyxFQUFFLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDdEQsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDcEIsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQztBQUNsQjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUM7QUFDL0IsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDdEU7QUFDQSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDVCxDQUFDO0FBQ0QsUUFBUSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNwQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN4RDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7QUFDdEIsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdGLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2pCLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzVFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ1IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RLLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7QUFDL0IsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pILENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2pCLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzVFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEgsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztBQUMvQixDQUFDO0FBQ0QsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzVDLENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzVCLENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUM5QixDQUFDO0FBQ0QsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDdkMsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2pFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDYixDQUFDO0FBQ0QsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNqQyxDQUFDO0FBQ0QsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2IsQ0FBQztBQUNELENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN2QyxDQUFDLENBQUMsT0FBTztBQUNULENBQUMsQ0FBQyxVQUFVO0FBQ1osQ0FBQyxDQUFDLE9BQU87QUFDVCxDQUFDLENBQUMsWUFBWTtBQUNkLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLE9BQU87QUFDVCxDQUFDLENBQUMsSUFBSTtBQUNOLENBQUMsQ0FBQyxVQUFVO0FBQ1osQ0FBQyxDQUFDLFFBQVE7QUFDVixDQUFDLENBQUMsT0FBTztBQUNULENBQUMsQ0FBQyxhQUFhO0FBQ2YsQ0FBQyxDQUFDLE9BQU87QUFDVCxDQUFDLENBQUMsWUFBWTtBQUNkLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDdEI7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUM7QUFDbkMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDeEI7QUFDQSxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDVDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNELFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNyQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3BCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUI7QUFDOUYsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hHLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUztBQUN2QixDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDM0QsQ0FBQztBQUNELENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BILENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNySCxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM1RixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDcEI7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDO0FBQzlCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSztBQUN2QjtBQUNBLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDekMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPO0FBQzdDO0FBQ0EsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDMUg7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxRQUFRLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDMUc7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDO0FBQy9CLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTTtBQUN4QjtBQUNBLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDekMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsS0FBSztBQUNwSjtBQUNBLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsUUFBUTtBQUN6TztBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNELFFBQVEsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDbEMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDdkU7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDO0FBQzdCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSTtBQUN0QjtBQUNBLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDekMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPO0FBQzdDO0FBQ0EsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxRQUFRO0FBQ3hIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDO0FBQ0QsUUFBUSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNoQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDO0FBQ2xDLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUztBQUMzQjtBQUNBLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDekMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPO0FBQzdDO0FBQ0EsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUY7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxRQUFRLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDckMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUM5RztBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQztBQUNqQyxRQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQzNCLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU07QUFDdkIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztBQUN0RTtBQUNBLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUTtBQUMxQjtBQUNBLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDekMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPO0FBQzdDO0FBQ0EsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxRQUFRO0FBQ3ZIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDO0FBQ0QsUUFBUSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNPO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDO0FBQ2pDLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNyQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3JFO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRO0FBQzFCO0FBQ0EsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUMxQjtBQUNBLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFLO0FBQ3RFO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDO0FBQ0QsUUFBUSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ25DLENBQUMsR0FBRyxDQUFDLFdBQVc7QUFDaEIsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsRUFBRSxDQUFDLENBQUMsc0JBQXNCLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxTQUFTO0FBQzNCLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JJLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxVQUFVO0FBQ3BDLENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFVBQVU7QUFDeEIsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO0FBQ2xFLENBQUM7QUFDRCxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM1SSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzSjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUM7QUFDN0IsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJO0FBQ3RCO0FBQ0EsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUN6QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0SjtBQUNBLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFFBQVE7QUFDcEc7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxRQUFRLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQ3JGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQztBQUM1QixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUc7QUFDckI7QUFDQSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQ3pDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEtBQUs7QUFDcEo7QUFDQSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsUUFBUTtBQUNsRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNELFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDL0IsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDcEU7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDO0FBQy9CLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTTtBQUN4QjtBQUNBLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDekMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUTtBQUN2QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDVDtBQUNBLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNsSDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNELFFBQVEsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDaEQsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDM0YsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDO0FBQy9KLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDO0FBQzdCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSTtBQUN0QjtBQUNBLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDekMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPO0FBQzdDO0FBQ0EsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDeEg7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxRQUFRLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDekc7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDO0FBQy9CLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDckIsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2xDO0FBQ0EsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNwRCxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUc7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1A7QUFDQSxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQ3pDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLO0FBQzlEO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDO0FBQ0QsUUFBUSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUN6QyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDdkUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO0FBQ25GLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO0FBQzNCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUztBQUN0QztBQUNBLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsWUFBWTtBQUN0QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDVCxDQUFDO0FBQ0QsUUFBUSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRCxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUM7QUFDeEMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDO0FBQ3ZDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNuRixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDM0YsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQzNGLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUs7QUFDOUIsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNyRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ3JCLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUNqQixDQUFDLENBQUM7QUFDRixDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxHQUFHO0FBQ0wsQ0FBQyxDQUFDLEdBQUc7QUFDTCxDQUFDLENBQUMsR0FBRztBQUNMLENBQUMsQ0FBQyxHQUFHO0FBQ0wsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDO0FBQzlCLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoSCxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3ZJLFFBQVEsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDakUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDakMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QztBQUNBLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ0wsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDcEIsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckU7QUFDQSxRQUFRLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsWUFBWTtBQUMxQixDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNqQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM5QixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM1QixDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM5QixDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNsQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNsQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUM1QyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMxQixDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxlQUFlO0FBQ3pKLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7QUFDeEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1SCxDQUFDLENBQUM7QUFDRixDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7QUFDdkIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUM7QUFDL0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDeEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7QUFDaEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDM0MsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDMUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUM7QUFDbEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDMUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUM7QUFDbEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDZCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEYsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BGLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNuQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNqRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQztBQUN6QyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5RyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdHLENBQUMsQ0FBQztBQUNGLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUs7QUFDMUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDaE4sQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNBLFFBQVEsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDN0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDeEQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN2RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQ2hELENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNwRCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUM7QUFDbkMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQzNFLENBQUMsQ0FBQztBQUNGLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUN0QjtBQUNBLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUU7QUFDcEU7QUFDQSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3JGLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUM3RCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUNuQjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNELFFBQVEsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM3RjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7QUFDOUIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDakM7QUFDQSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNULENBQUM7QUFDRCxRQUFRLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pELENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ2hFLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNqQixDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7QUFDbkMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNmLENBQUMsQ0FBQztBQUNGLENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3hCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNULENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNoQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUN2QixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQztBQUM1RCxDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDcEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDO0FBQ3pCLENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUM7QUFDckMsQ0FBQyxDQUFDLEtBQUs7QUFDUCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7QUFDNUIsUUFBUSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDakYsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzVCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxLQUFLO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUM7QUFDckM7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDO0FBQy9CLFFBQVEsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxZQUFZO0FBQzFCLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDbEosQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNyRCxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDO0FBQzNCO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQztBQUM3QixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRO0FBQ3hDO0FBQ0EsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1QsQ0FBQztBQUNELFFBQVEsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xELENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ2hFLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztBQUNwQyxDQUFDLEdBQUcsQ0FBQyxLQUFLO0FBQ1YsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDekIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1QsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUN4QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSztBQUMxQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3ZCLENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3hCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN2QixDQUFDO0FBQ0QsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUM7QUFDeEIsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQztBQUN2QyxDQUFDLENBQUMsS0FBSztBQUNQLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztBQUMzQixRQUFRLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xELENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDL0QsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzdHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7QUFDeEQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDNUIsQ0FBQyxDQUFDLEtBQUs7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFDRixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNsQjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7QUFDNUIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLE1BQU07QUFDM0M7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxRQUFRLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUM1RCxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7QUFDL0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO0FBQy9ELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDbkYsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUTtBQUNqQixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQztBQUM1QixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxNQUFNO0FBQ3BDO0FBQ0EsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUMxQjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNELFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0M7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDO0FBQzFCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCO0FBQ0EsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNUO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDO0FBQ0QsUUFBUSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2RCxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDM0QsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDO0FBQ3ZDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQztBQUN4QyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7QUFDdEMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ3hFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSztBQUN0QixDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUM5QixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDN0I7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO0FBQzNCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUTtBQUNoRDtBQUNBLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDMUIsQ0FBQztBQUNELFFBQVEsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDekMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMzTCxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRCxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDL0QsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNwQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQzlCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDakQsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDWjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7QUFDNUIsUUFBUSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMxQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUMzQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDN0QsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQztBQUNqQixDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPO0FBQ2hCLENBQUMsQ0FBQyxJQUFJO0FBQ04sQ0FBQyxDQUFDLE1BQU07QUFDUixDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUM7QUFDL0IsUUFBUSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEQsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNwRSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVk7QUFDakIsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDOUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsY0FBYztBQUNyQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDO0FBQzFCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSTtBQUMvQztBQUNBLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDMUIsQ0FBQztBQUNELFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ1osQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUM7QUFDL0IsUUFBUSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEQsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNoRSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUN4RCxDQUFDLEdBQUcsQ0FBQyxhQUFhO0FBQ2xCLENBQUMsR0FBRyxDQUFDLHNCQUFzQjtBQUMzQixDQUFDLEdBQUcsQ0FBQyxJQUFJO0FBQ1QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3BCLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ2pCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsV0FBVztBQUM5QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsV0FBVztBQUN0QyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLGVBQWU7QUFDakQsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ3BFLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTTtBQUNyQixDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLElBQUk7QUFDTixDQUFDLENBQUMsYUFBYTtBQUNmLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM5QyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxjQUFjO0FBQ3JDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUM7QUFDL0IsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJO0FBQ3BEO0FBQ0EsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUMxQixDQUFDO0FBQ0QsUUFBUSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM3QyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDWixDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQztBQUMxQixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2pEO0FBQ0EsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUMxQixDQUFDO0FBQ0QsUUFBUSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN4QyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDWixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQztBQUMvQixRQUFRLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRCxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNuRixDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVk7QUFDakIsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPO0FBQ3pELENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzlDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLGNBQWM7QUFDckMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDO0FBQ2pDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEQsQ0FBQyxHQUFHLENBQUMsU0FBUztBQUNkLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTTtBQUN4QixDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUztBQUN0QixDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDTixDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUN0QixDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUN2QyxDQUFDLENBQUM7QUFDRixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDakQsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDOUIsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUc7QUFDVCxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMxRCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHO0FBQ1osQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUNSLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNsQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPO0FBQ3hDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3hFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7QUFDeEI7QUFDQSxRQUFRLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzdCLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNqRTtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7QUFDekIsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN2QyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDN0YsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQztBQUMxQixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDWixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsTUFBTSxDQUFDLElBQUk7QUFDWjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQzsifQ==