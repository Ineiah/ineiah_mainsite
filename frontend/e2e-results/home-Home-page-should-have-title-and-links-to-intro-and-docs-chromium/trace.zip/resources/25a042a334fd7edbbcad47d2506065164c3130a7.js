import { ref, watch, computed, toValue } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
import { useUrlSearchParams } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vueuse+core@14.4.0_vue@3.5.40_typescript@6.0.3_/node_modules/@vueuse/core/dist/index.js?v=7e73afc2";
export * from "/_nuxt/composables/google_search/utils.ts";
/**
* Composable for implementing a search on Goole's search page. It allows users to search through
* a list of items based on their title, description, and tags. The search query is synchronized with
* the URL's search parameters, allowing for easy sharing and bookmarking of search results.
* @param args Functions that return a list of SearchItems based on the search query.
*/
export function useGoogleSearch(...args) {
	const activeType = ref("all");
	const query = ref("");
	const searchParams = useUrlSearchParams("history");
	watch(query, (newValue) => {
		searchParams.q = newValue;
	});
	const allItems = computed(() => {
		return args.flatMap((func) => {
			return toValue(func(query.value));
		}).flatMap((x) => x);
	});
	const searchedItems = computed(() => {
		if (query.value === "") {
			return allItems.value;
		}
		const lowerQuery = query.value.toLowerCase();
		return allItems.value.filter((item) => item.title.toLowerCase().includes(lowerQuery) || item.description?.toLowerCase().includes(lowerQuery) || item.tags?.some((tag) => tag.toLowerCase().includes(lowerQuery)));
	});
	return {
		/**
		* The active type of items to display. It can be 'all', 'product',
		* 'page', or 'content'. This can be used to filter the search results
		* based on the type of items.
		*/
		activeType,
		/**
		* The search query entered by the user. This is synchronized with the URL's
		* search parameters, allowing for easy sharing and bookmarking of search results.
		*/
		query,
		/**
		* A computed property that returns all items from the provided functions based on the current search query.
		*/
		allItems,
		/**
		* A computed property that returns the list of items that
		* match the search query. It filters the items based on whether the
		* title, description, or tags include the search query (case-insensitive).
		* If the search query is empty, it returns all items.
		*/
		searchedItems
	};
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7QUFBQSxjQUFjOzs7Ozs7O0FBa0JkLE9BQU8sU0FBUyxnQkFBZ0IsR0FBRyxNQUFnRTtDQUNqRyxNQUFNLGFBQWEsSUFBNEMsS0FBSztDQUVwRSxNQUFNLFFBQVEsSUFBWSxFQUFFO0NBQzVCLE1BQU0sZUFBZSxtQkFBbUIsU0FBUztDQUVqRCxNQUFNLFFBQVEsYUFBYTtFQUN6QixhQUFhLElBQUk7Q0FDbkIsQ0FBQztDQUVELE1BQU0sV0FBVyxlQUFlO0VBQzlCLE9BQU8sS0FBSyxTQUFTLFNBQVM7R0FDNUIsT0FBTyxRQUFRLEtBQUssTUFBTSxLQUFLLENBQUM7RUFDbEMsQ0FBQyxDQUFDLENBQUMsU0FBUSxNQUFLLENBQUM7Q0FDbkIsQ0FBQztDQUVELE1BQU0sZ0JBQWdCLGVBQWU7RUFDbkMsSUFBSSxNQUFNLFVBQVUsSUFBSTtHQUN0QixPQUFPLFNBQVM7RUFDbEI7RUFFQSxNQUFNLGFBQWEsTUFBTSxNQUFNLFlBQVk7RUFDM0MsT0FBTyxTQUFTLE1BQU0sUUFBTyxTQUMzQixLQUFLLE1BQU0sWUFBWSxDQUFDLENBQUMsU0FBUyxVQUFVLEtBQ3pDLEtBQUssYUFBYSxZQUFZLENBQUMsQ0FBQyxTQUFTLFVBQVUsS0FDbkQsS0FBSyxNQUFNLE1BQUssUUFBTyxJQUFJLFlBQVksQ0FBQyxDQUFDLFNBQVMsVUFBVSxDQUFDLENBQ2xFO0NBQ0YsQ0FBQztDQUVELE9BQU87Ozs7OztFQU1MOzs7OztFQUtBOzs7O0VBSUE7Ozs7Ozs7RUFPQTtDQUNGO0FBQ0YiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCAqIGZyb20gJy4vdXRpbHMnXG5cbmV4cG9ydCBpbnRlcmZhY2UgU2VhcmNoSXRlbSB7XG4gIGlkOiBzdHJpbmdcbiAgdGl0bGU6IHN0cmluZ1xuICBkZXNjcmlwdGlvbj86IHN0cmluZ1xuICBzbHVnOiBzdHJpbmdcbiAgdHlwZTogJ3Byb2R1Y3QnIHwgJ3BhZ2UnIHwgJ2NvbnRlbnQnXG4gIHRvOiBzdHJpbmdcbiAgdGFncz86IHN0cmluZ1tdXG59XG5cbi8qKlxuICogQ29tcG9zYWJsZSBmb3IgaW1wbGVtZW50aW5nIGEgc2VhcmNoIG9uIEdvb2xlJ3Mgc2VhcmNoIHBhZ2UuIEl0IGFsbG93cyB1c2VycyB0byBzZWFyY2ggdGhyb3VnaFxuICogYSBsaXN0IG9mIGl0ZW1zIGJhc2VkIG9uIHRoZWlyIHRpdGxlLCBkZXNjcmlwdGlvbiwgYW5kIHRhZ3MuIFRoZSBzZWFyY2ggcXVlcnkgaXMgc3luY2hyb25pemVkIHdpdGhcbiAqIHRoZSBVUkwncyBzZWFyY2ggcGFyYW1ldGVycywgYWxsb3dpbmcgZm9yIGVhc3kgc2hhcmluZyBhbmQgYm9va21hcmtpbmcgb2Ygc2VhcmNoIHJlc3VsdHMuXG4gKiBAcGFyYW0gYXJncyBGdW5jdGlvbnMgdGhhdCByZXR1cm4gYSBsaXN0IG9mIFNlYXJjaEl0ZW1zIGJhc2VkIG9uIHRoZSBzZWFyY2ggcXVlcnkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VHb29nbGVTZWFyY2goLi4uYXJnczogKChzZWFyY2hJdGVtOiBzdHJpbmcpID0+IE1heWJlUmVmT3JHZXR0ZXI8U2VhcmNoSXRlbT4pW10pIHtcbiAgY29uc3QgYWN0aXZlVHlwZSA9IHJlZjwnYWxsJyB8ICdwcm9kdWN0JyB8ICdwYWdlJyB8ICdjb250ZW50Jz4oJ2FsbCcpXG5cbiAgY29uc3QgcXVlcnkgPSByZWY8c3RyaW5nPignJylcbiAgY29uc3Qgc2VhcmNoUGFyYW1zID0gdXNlVXJsU2VhcmNoUGFyYW1zKCdoaXN0b3J5JylcblxuICB3YXRjaChxdWVyeSwgKG5ld1ZhbHVlKSA9PiB7XG4gICAgc2VhcmNoUGFyYW1zLnEgPSBuZXdWYWx1ZVxuICB9KVxuXG4gIGNvbnN0IGFsbEl0ZW1zID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIHJldHVybiBhcmdzLmZsYXRNYXAoKGZ1bmMpID0+IHtcbiAgICAgIHJldHVybiB0b1ZhbHVlKGZ1bmMocXVlcnkudmFsdWUpKVxuICAgIH0pLmZsYXRNYXAoeCA9PiB4KVxuICB9KVxuXG4gIGNvbnN0IHNlYXJjaGVkSXRlbXMgPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgaWYgKHF1ZXJ5LnZhbHVlID09PSAnJykge1xuICAgICAgcmV0dXJuIGFsbEl0ZW1zLnZhbHVlXG4gICAgfVxuXG4gICAgY29uc3QgbG93ZXJRdWVyeSA9IHF1ZXJ5LnZhbHVlLnRvTG93ZXJDYXNlKClcbiAgICByZXR1cm4gYWxsSXRlbXMudmFsdWUuZmlsdGVyKGl0ZW0gPT5cbiAgICAgIGl0ZW0udGl0bGUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhsb3dlclF1ZXJ5KVxuICAgICAgfHwgaXRlbS5kZXNjcmlwdGlvbj8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhsb3dlclF1ZXJ5KVxuICAgICAgfHwgaXRlbS50YWdzPy5zb21lKHRhZyA9PiB0YWcudG9Mb3dlckNhc2UoKS5pbmNsdWRlcyhsb3dlclF1ZXJ5KSlcbiAgICApXG4gIH0pXG5cbiAgcmV0dXJuIHtcbiAgICAvKipcbiAgICAgKiBUaGUgYWN0aXZlIHR5cGUgb2YgaXRlbXMgdG8gZGlzcGxheS4gSXQgY2FuIGJlICdhbGwnLCAncHJvZHVjdCcsXG4gICAgICogJ3BhZ2UnLCBvciAnY29udGVudCcuIFRoaXMgY2FuIGJlIHVzZWQgdG8gZmlsdGVyIHRoZSBzZWFyY2ggcmVzdWx0c1xuICAgICAqIGJhc2VkIG9uIHRoZSB0eXBlIG9mIGl0ZW1zLlxuICAgICAqL1xuICAgIGFjdGl2ZVR5cGUsXG4gICAgLyoqXG4gICAgICogVGhlIHNlYXJjaCBxdWVyeSBlbnRlcmVkIGJ5IHRoZSB1c2VyLiBUaGlzIGlzIHN5bmNocm9uaXplZCB3aXRoIHRoZSBVUkwnc1xuICAgICAqIHNlYXJjaCBwYXJhbWV0ZXJzLCBhbGxvd2luZyBmb3IgZWFzeSBzaGFyaW5nIGFuZCBib29rbWFya2luZyBvZiBzZWFyY2ggcmVzdWx0cy5cbiAgICAgKi9cbiAgICBxdWVyeSxcbiAgICAvKipcbiAgICAgKiBBIGNvbXB1dGVkIHByb3BlcnR5IHRoYXQgcmV0dXJucyBhbGwgaXRlbXMgZnJvbSB0aGUgcHJvdmlkZWQgZnVuY3Rpb25zIGJhc2VkIG9uIHRoZSBjdXJyZW50IHNlYXJjaCBxdWVyeS5cbiAgICAgKi9cbiAgICBhbGxJdGVtcyxcbiAgICAvKipcbiAgICAgKiBBIGNvbXB1dGVkIHByb3BlcnR5IHRoYXQgcmV0dXJucyB0aGUgbGlzdCBvZiBpdGVtcyB0aGF0XG4gICAgICogbWF0Y2ggdGhlIHNlYXJjaCBxdWVyeS4gSXQgZmlsdGVycyB0aGUgaXRlbXMgYmFzZWQgb24gd2hldGhlciB0aGVcbiAgICAgKiB0aXRsZSwgZGVzY3JpcHRpb24sIG9yIHRhZ3MgaW5jbHVkZSB0aGUgc2VhcmNoIHF1ZXJ5IChjYXNlLWluc2Vuc2l0aXZlKS5cbiAgICAgKiBJZiB0aGUgc2VhcmNoIHF1ZXJ5IGlzIGVtcHR5LCBpdCByZXR1cm5zIGFsbCBpdGVtcy5cbiAgICAgKi9cbiAgICBzZWFyY2hlZEl0ZW1zXG4gIH1cbn1cbiJdLCJmaWxlIjoiL1ZvbHVtZXMvQ29kaW5nL1Byb2plY3RzL1dlYnNpdGVzL2luZWlhaC9mcm9udGVuZC9hcHAvY29tcG9zYWJsZXMvZ29vZ2xlX3NlYXJjaC9pbmRleC50cyJ9