import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/components/hero/SectionVideoCall.vue");import { useBusinessDetails as _$__useBusinessDetails } from "/_nuxt/composables/business/base.ts";;import { __nuxtTimelineWrap } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+devtools@3.4.1_db0@0.3.4_better-sqlite3@13.0.2_drizzle-orm@0.45.2_@opentelemetry+_0e55243a794e05cb19a29a0506aae086/node_modules/@nuxt/devtools/dist/runtime/function-metrics-helpers.js?v=7e73afc2";const useBusinessDetails = __nuxtTimelineWrap("useBusinessDetails", _$__useBusinessDetails);
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@8.2.0_@types+node@26.1.2_esbuild@0.28.1_jiti@2.7.0_sa_bcac4fa99282966dd94ca7ad2dfebde1/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=7e73afc2"
import { defineComponent as _defineComponent } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _sfc_main = /*@__PURE__*/ _defineComponent({
	__name: "HeroSectionVideoCall",
	setup(__props, { expose: __expose }) {
		__expose();
		/**
		* Business details
		*/
		const { getSocial } = useBusinessDetails();
		const __returned__ = { getSocial };
		Object.defineProperty(__returned__, "__isScriptSetup", {
			enumerable: false,
			value: true
		});
		return __returned__;
	}
});
import { createElementVNode as _createElementVNode, createCommentVNode as _createCommentVNode, createTextVNode as _createTextVNode, toDisplayString as _toDisplayString, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _hoisted_1 = {
	id: "video-call-hero",
	class: "max-w-8xl mx-auto pt-20 px-5 md:px-20"
};
const _hoisted_2 = { role: "contentinfo" };
const _hoisted_3 = { class: "p-20 text-center text-primary-500 dark:text-primary-200" };
const _hoisted_4 = { class: "text-md" };
const _hoisted_5 = ["href", "title"];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
	return _openBlock(), _tracer(2,2,_createElementBlock("div", _hoisted_1, [_cache[2] || (_cache[2] = _tracer(3,4,_createElementVNode(
		"div",
		{ class: "grid grid-cols-1 md:grid-cols-2 bg-primary-200 dark:bg-primary-700 dark:text-primary-200 rounded-lg md:rounded-none md:rounded-tl-lg md:rounded-bl-lg md:rounded-tr-lg md:rounded-br-lg overflow-hidden" },
		[
			_tracer(4,6,_createElementVNode("video", {
				class: "aspect-video object-fill h-full w-full lg:object-fill",
				autoplay: "",
				muted: "",
				loop: "",
				playsinline: ""
			}, [_tracer(5,8,_createElementVNode("source", {
				src: "https://freelance-data-storage.s3.us-east-1.amazonaws.com/hair.mp4",
				type: "video/mp4"
			}))])),
			_createCommentVNode(" Info "),
			_tracer(9,6,_createElementVNode("div", { class: "p-10 rounded-tr-md rounded-br-md flex-col justify-center content-center text-center max-w-3xl" }, [
				_tracer(10,8,_createElementVNode("h2", { class: "font-semibold uppercase text-primary-800 dark:text-primary-400 text-4xl" }, " Une sublime restructuration de la coupe ")),
				_tracer(14,8,_createElementVNode("p", { class: "text-2xl font-light mt-10 mb-3" }, " Des boucles souples et en bonne santé sans perdre de longueur, c'est tout ce qu'on aime 🤭 ")),
				_tracer(18,8,_createElementVNode("p", { class: "text-2xl font-light" }, " Alors ça vous plaît ? "))
			]))
		],
		-1
		/* CACHED */
	))), _tracer(24,4,_createElementVNode("div", _hoisted_2, [_tracer(25,6,_createElementVNode("div", _hoisted_3, [_cache[1] || (_cache[1] = _tracer(26,8,_createElementVNode(
		"p",
		{ class: "font-bold mb-3 text-4xl" },
		[_createTextVNode(" Rejoint le "), _tracer(27,21,_createElementVNode("span", { class: "text-primary-800 dark:text-primary-400" }, "#curlymouvement"))],
		-1
		/* CACHED */
	))), _tracer(29,8,_createElementVNode("p", _hoisted_4, [_cache[0] || (_cache[0] = _createTextVNode(
		" Retrouvez-nous sur instagram ",
		-1
		/* CACHED */
	)), _tracer(30,39,_createElementVNode("a", {
		href: $setup.getSocial("instagram")?.url,
		title: $setup.getSocial("instagram")?.url
	}, _toDisplayString($setup.getSocial("instagram")?.handle), 9, _hoisted_5))]))]))]))]));
}
_sfc_main.__hmrId = "93a0494f";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.on("file-changed", ({ file }) => {
	__VUE_HMR_RUNTIME__.CHANGED_FILE = file;
});
import.meta.hot.accept((mod) => {
	if (!mod) return;
	const { default: updated, _rerender_only } = mod;
	if (_rerender_only) {
		__VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
	} else {
		__VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
	}
});
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper";
export default /*#__PURE__*/ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "/Volumes/Coding/Projects/Websites/ineiah/frontend/app/components/hero/SectionVideoCall.vue"]]);

function _tracer(line, column, vnode) { return _tracerRecordPosition("app/components/hero/SectionVideoCall.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztFQXlDQSxNQUFNLEVBQUUsY0FBYyxtQkFBbUI7Ozs7Ozs7Ozs7O0NBeENsQyxJQUFHO0NBQWtCLE9BQU07O0FBc0J6QiwyQkFBSyxjQUFhO0FBQ2hCLDRCQUFNLDBEQUF5RDtBQUkvRCw0QkFBTSxVQUFTOzs7Q0EzQnhCLHFEQWdDTSxPQWhDTixZQWdDTSxDQS9CSjtFQW1CTTtFQUFBLEVBbkJELE9BQU0sME1BQXlNO0VBQUE7ZUFDbE4sb0JBRVE7SUFGRCxPQUFNO0lBQXdEO0lBQVM7SUFBTTtJQUFLO21CQUN2RixvQkFBa0c7SUFBMUYsS0FBSTtJQUFxRSxNQUFLOztHQUd4RjtlQUNBLG9CQVlNLFNBWkQsT0FBTSxnR0FBK0Y7aUJBQ3hHLG9CQUVLLFFBRkQsT0FBTSwwRUFBeUUsR0FBQywyQ0FFcEY7aUJBRUEsb0JBRUksT0FGRCxPQUFNLGlDQUFnQyxHQUFDLDhGQUUxQztpQkFFQSxvQkFFSSxPQUZELE9BQU0sc0JBQXFCLEdBQUMseUJBRS9COzs7OzttQkFJSixvQkFTTSxPQVROLFlBU00sY0FSSixvQkFPTSxPQVBOLFlBT00sQ0FOSjtFQUVJO0VBQUEsRUFGRCxPQUFNLDBCQUF5QjtFQUFBLENBQUMsK0JBQ3RCLHFDQUEyRSxVQUFyRSxPQUFNLHlDQUF3QyxHQUFDLGlCQUFlOzs7bUJBRWpGLG9CQUVJLEtBRkosWUFFSSxDQUZlO0VBQUE7RUFDWTs7Q0FBQSxzQ0FBb0g7RUFBaEgsTUFBTSxpQkFBUyxjQUFlO0VBQU0sT0FBTyxpQkFBUyxjQUFlO0NBQVEscUNBQVMsY0FBZSxNQUFNIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTZWN0aW9uVmlkZW9DYWxsLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XG4gIDxkaXYgaWQ9XCJ2aWRlby1jYWxsLWhlcm9cIiBjbGFzcz1cIm1heC13LTh4bCBteC1hdXRvIHB0LTIwIHB4LTUgbWQ6cHgtMjBcIj5cbiAgICA8ZGl2IGNsYXNzPVwiZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMiBiZy1wcmltYXJ5LTIwMCBkYXJrOmJnLXByaW1hcnktNzAwIGRhcms6dGV4dC1wcmltYXJ5LTIwMCByb3VuZGVkLWxnIG1kOnJvdW5kZWQtbm9uZSBtZDpyb3VuZGVkLXRsLWxnIG1kOnJvdW5kZWQtYmwtbGcgbWQ6cm91bmRlZC10ci1sZyBtZDpyb3VuZGVkLWJyLWxnIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgPHZpZGVvIGNsYXNzPVwiYXNwZWN0LXZpZGVvIG9iamVjdC1maWxsIGgtZnVsbCB3LWZ1bGwgbGc6b2JqZWN0LWZpbGxcIiBhdXRvcGxheSBtdXRlZCBsb29wIHBsYXlzaW5saW5lPlxuICAgICAgICA8c291cmNlIHNyYz1cImh0dHBzOi8vZnJlZWxhbmNlLWRhdGEtc3RvcmFnZS5zMy51cy1lYXN0LTEuYW1hem9uYXdzLmNvbS9oYWlyLm1wNFwiIHR5cGU9XCJ2aWRlby9tcDRcIj5cbiAgICAgIDwvdmlkZW8+XG5cbiAgICAgIDwhLS0gSW5mbyAtLT5cbiAgICAgIDxkaXYgY2xhc3M9XCJwLTEwIHJvdW5kZWQtdHItbWQgcm91bmRlZC1ici1tZCBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlciBjb250ZW50LWNlbnRlciB0ZXh0LWNlbnRlciBtYXgtdy0zeGxcIj5cbiAgICAgICAgPGgyIGNsYXNzPVwiZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdGV4dC1wcmltYXJ5LTgwMCBkYXJrOnRleHQtcHJpbWFyeS00MDAgdGV4dC00eGxcIj5cbiAgICAgICAgICBVbmUgc3VibGltZSByZXN0cnVjdHVyYXRpb24gZGUgbGEgY291cGVcbiAgICAgICAgPC9oMj5cblxuICAgICAgICA8cCBjbGFzcz1cInRleHQtMnhsIGZvbnQtbGlnaHQgbXQtMTAgbWItM1wiPlxuICAgICAgICAgIERlcyBib3VjbGVzIHNvdXBsZXMgZXQgZW4gYm9ubmUgc2FudMOpIHNhbnMgcGVyZHJlIGRlIGxvbmd1ZXVyLCBjJ2VzdCB0b3V0IGNlIHF1J29uIGFpbWUg8J+krVxuICAgICAgICA8L3A+XG5cbiAgICAgICAgPHAgY2xhc3M9XCJ0ZXh0LTJ4bCBmb250LWxpZ2h0XCI+XG4gICAgICAgICAgQWxvcnMgw6dhIHZvdXMgcGxhw650ID9cbiAgICAgICAgPC9wPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG5cbiAgICA8ZGl2IHJvbGU9XCJjb250ZW50aW5mb1wiPlxuICAgICAgPGRpdiBjbGFzcz1cInAtMjAgdGV4dC1jZW50ZXIgdGV4dC1wcmltYXJ5LTUwMCBkYXJrOnRleHQtcHJpbWFyeS0yMDBcIj5cbiAgICAgICAgPHAgY2xhc3M9XCJmb250LWJvbGQgbWItMyB0ZXh0LTR4bFwiPlxuICAgICAgICAgIFJlam9pbnQgbGUgPHNwYW4gY2xhc3M9XCJ0ZXh0LXByaW1hcnktODAwIGRhcms6dGV4dC1wcmltYXJ5LTQwMFwiPiNjdXJseW1vdXZlbWVudDwvc3Bhbj5cbiAgICAgICAgPC9wPlxuICAgICAgICA8cCBjbGFzcz1cInRleHQtbWRcIj5cbiAgICAgICAgICBSZXRyb3V2ZXotbm91cyBzdXIgaW5zdGFncmFtIDxhIDpocmVmPVwiZ2V0U29jaWFsKCdpbnN0YWdyYW0nKT8udXJsXCIgOnRpdGxlPVwiZ2V0U29jaWFsKCdpbnN0YWdyYW0nKT8udXJsXCI+e3sgZ2V0U29jaWFsKCdpbnN0YWdyYW0nKT8uaGFuZGxlIH19PC9hPlxuICAgICAgICA8L3A+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgPC9kaXY+XG48L3RlbXBsYXRlPlxuXG48c2NyaXB0IHNldHVwIGxhbmc9XCJ0c1wiPlxuLyoqXG4gKiBCdXNpbmVzcyBkZXRhaWxzXG4gKi9cblxuY29uc3QgeyBnZXRTb2NpYWwgfSA9IHVzZUJ1c2luZXNzRGV0YWlscygpXG48L3NjcmlwdD5cbiJdLCJmaWxlIjoiL1ZvbHVtZXMvQ29kaW5nL1Byb2plY3RzL1dlYnNpdGVzL2luZWlhaC9mcm9udGVuZC9hcHAvY29tcG9uZW50cy9oZXJvL1NlY3Rpb25WaWRlb0NhbGwudnVlIn0=