import { defineNuxtPlugin } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/nuxt.js?v=7e73afc2";
// import type { ResolvableLink } from '@unhead/vue'
export default defineNuxtPlugin({
	parallel: true,
	name: "canonical",
	setup() {
		// const locales = useNuxtApp().$i18n.locales
		// const route = useRoute()
		// const siteUrl = useRuntimeConfig().public.siteUrl
		// const localePath = useLocalePath()
		// useHead(() => {
		//   // Generate hreflang for each locale
		//   const hreflangLinks = (locales.value).map(locale => ({
		//     rel: 'alternate',
		//     hreflang: locale.language, // ex: 'fr-FR', 'en-US'
		//     href: siteUrl + localePath(route.name as string, locale.code)
		//   }))
		//   // Add x-default pointing to the FR version (default)
		//   const xDefault: ResolvableLink = {
		//     rel: 'alternate',
		//     hreflang: 'x-default',
		//     href: siteUrl + localePath(route.name as string, 'fr')
		//   }
		//   const canonicalHref = siteUrl + route.path
		//   return {
		//     link: [
		//       { rel: 'canonical', href: canonicalHref },
		//       ...hreflangLinks,
		//       xDefault
		//     ]
		//   }
		// })
	}
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7QUFFQSxlQUFlLGlCQUFpQjtDQUM5QixVQUFVO0NBQ1YsTUFBTTtDQUNOLFFBQVE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQStCUjtBQUNGLENBQUMiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImNhbm9uaWNhbC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBpbXBvcnQgdHlwZSB7IFJlc29sdmFibGVMaW5rIH0gZnJvbSAnQHVuaGVhZC92dWUnXG5cbmV4cG9ydCBkZWZhdWx0IGRlZmluZU51eHRQbHVnaW4oe1xuICBwYXJhbGxlbDogdHJ1ZSxcbiAgbmFtZTogJ2Nhbm9uaWNhbCcsXG4gIHNldHVwKCkge1xuICAgIC8vIGNvbnN0IGxvY2FsZXMgPSB1c2VOdXh0QXBwKCkuJGkxOG4ubG9jYWxlc1xuICAgIC8vIGNvbnN0IHJvdXRlID0gdXNlUm91dGUoKVxuICAgIC8vIGNvbnN0IHNpdGVVcmwgPSB1c2VSdW50aW1lQ29uZmlnKCkucHVibGljLnNpdGVVcmxcbiAgICAvLyBjb25zdCBsb2NhbGVQYXRoID0gdXNlTG9jYWxlUGF0aCgpXG5cbiAgICAvLyB1c2VIZWFkKCgpID0+IHtcbiAgICAvLyAgIC8vIEdlbmVyYXRlIGhyZWZsYW5nIGZvciBlYWNoIGxvY2FsZVxuICAgIC8vICAgY29uc3QgaHJlZmxhbmdMaW5rcyA9IChsb2NhbGVzLnZhbHVlKS5tYXAobG9jYWxlID0+ICh7XG4gICAgLy8gICAgIHJlbDogJ2FsdGVybmF0ZScsXG4gICAgLy8gICAgIGhyZWZsYW5nOiBsb2NhbGUubGFuZ3VhZ2UsIC8vIGV4OiAnZnItRlInLCAnZW4tVVMnXG4gICAgLy8gICAgIGhyZWY6IHNpdGVVcmwgKyBsb2NhbGVQYXRoKHJvdXRlLm5hbWUgYXMgc3RyaW5nLCBsb2NhbGUuY29kZSlcbiAgICAvLyAgIH0pKVxuXG4gICAgLy8gICAvLyBBZGQgeC1kZWZhdWx0IHBvaW50aW5nIHRvIHRoZSBGUiB2ZXJzaW9uIChkZWZhdWx0KVxuICAgIC8vICAgY29uc3QgeERlZmF1bHQ6IFJlc29sdmFibGVMaW5rID0ge1xuICAgIC8vICAgICByZWw6ICdhbHRlcm5hdGUnLFxuICAgIC8vICAgICBocmVmbGFuZzogJ3gtZGVmYXVsdCcsXG4gICAgLy8gICAgIGhyZWY6IHNpdGVVcmwgKyBsb2NhbGVQYXRoKHJvdXRlLm5hbWUgYXMgc3RyaW5nLCAnZnInKVxuICAgIC8vICAgfVxuXG4gICAgLy8gICBjb25zdCBjYW5vbmljYWxIcmVmID0gc2l0ZVVybCArIHJvdXRlLnBhdGhcblxuICAgIC8vICAgcmV0dXJuIHtcbiAgICAvLyAgICAgbGluazogW1xuICAgIC8vICAgICAgIHsgcmVsOiAnY2Fub25pY2FsJywgaHJlZjogY2Fub25pY2FsSHJlZiB9LFxuICAgIC8vICAgICAgIC4uLmhyZWZsYW5nTGlua3MsXG4gICAgLy8gICAgICAgeERlZmF1bHRcbiAgICAvLyAgICAgXVxuICAgIC8vICAgfVxuICAgIC8vIH0pXG4gIH1cbn0pXG4iXSwiZmlsZSI6Ii9Wb2x1bWVzL0NvZGluZy9Qcm9qZWN0cy9XZWJzaXRlcy9pbmVpYWgvZnJvbnRlbmQvYXBwL3BsdWdpbnMvY2Fub25pY2FsLnRzIn0=