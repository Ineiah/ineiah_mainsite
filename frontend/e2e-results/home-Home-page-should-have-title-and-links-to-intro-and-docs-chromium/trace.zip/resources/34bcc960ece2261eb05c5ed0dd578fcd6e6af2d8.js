import { t as __commonJSMin } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.cache/vite/client/deps/rolldown-runtime-BvCyGRYZ.js?v=7e73afc2";
//#region node_modules/.pnpm/dayjs@1.11.21/node_modules/dayjs/plugin/calendar.js
var require_calendar = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(e, t) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = t() : "function" == typeof define && define.amd ? define(t) : (e = "undefined" != typeof globalThis ? globalThis : e || self).dayjs_plugin_calendar = t();
	})(exports, (function() {
		"use strict";
		return function(e, t, a) {
			var n = "h:mm A", d = {
				lastDay: "[Yesterday at] " + n,
				sameDay: "[Today at] " + n,
				nextDay: "[Tomorrow at] " + n,
				nextWeek: "dddd [at] " + n,
				lastWeek: "[Last] dddd [at] " + n,
				sameElse: "MM/DD/YYYY"
			};
			t.prototype.calendar = function(e, t) {
				var n = t || this.$locale().calendar || d, o = a(e || void 0).startOf("d"), s = this.diff(o, "d", !0), i = "sameElse", f = s < -6 ? i : s < -1 ? "lastWeek" : s < 0 ? "lastDay" : s < 1 ? "sameDay" : s < 2 ? "nextDay" : s < 7 ? "nextWeek" : i, l = n[f] || d[f];
				return "function" == typeof l ? l.call(this, a()) : this.format(l);
			};
		};
	}));
}));
//#endregion
export default require_calendar();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF5anNfcGx1Z2luX2NhbGVuZGFyLmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy5wbnBtL2RheWpzQDEuMTEuMjEvbm9kZV9tb2R1bGVzL2RheWpzL3BsdWdpbi9jYWxlbmRhci5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIhZnVuY3Rpb24oZSx0KXtcIm9iamVjdFwiPT10eXBlb2YgZXhwb3J0cyYmXCJ1bmRlZmluZWRcIiE9dHlwZW9mIG1vZHVsZT9tb2R1bGUuZXhwb3J0cz10KCk6XCJmdW5jdGlvblwiPT10eXBlb2YgZGVmaW5lJiZkZWZpbmUuYW1kP2RlZmluZSh0KTooZT1cInVuZGVmaW5lZFwiIT10eXBlb2YgZ2xvYmFsVGhpcz9nbG9iYWxUaGlzOmV8fHNlbGYpLmRheWpzX3BsdWdpbl9jYWxlbmRhcj10KCl9KHRoaXMsKGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7cmV0dXJuIGZ1bmN0aW9uKGUsdCxhKXt2YXIgbj1cImg6bW0gQVwiLGQ9e2xhc3REYXk6XCJbWWVzdGVyZGF5IGF0XSBcIituLHNhbWVEYXk6XCJbVG9kYXkgYXRdIFwiK24sbmV4dERheTpcIltUb21vcnJvdyBhdF0gXCIrbixuZXh0V2VlazpcImRkZGQgW2F0XSBcIituLGxhc3RXZWVrOlwiW0xhc3RdIGRkZGQgW2F0XSBcIituLHNhbWVFbHNlOlwiTU0vREQvWVlZWVwifTt0LnByb3RvdHlwZS5jYWxlbmRhcj1mdW5jdGlvbihlLHQpe3ZhciBuPXR8fHRoaXMuJGxvY2FsZSgpLmNhbGVuZGFyfHxkLG89YShlfHx2b2lkIDApLnN0YXJ0T2YoXCJkXCIpLHM9dGhpcy5kaWZmKG8sXCJkXCIsITApLGk9XCJzYW1lRWxzZVwiLGY9czwtNj9pOnM8LTE/XCJsYXN0V2Vla1wiOnM8MD9cImxhc3REYXlcIjpzPDE/XCJzYW1lRGF5XCI6czwyP1wibmV4dERheVwiOnM8Nz9cIm5leHRXZWVrXCI6aSxsPW5bZl18fGRbZl07cmV0dXJuXCJmdW5jdGlvblwiPT10eXBlb2YgbD9sLmNhbGwodGhpcyxhKCkpOnRoaXMuZm9ybWF0KGwpfX19KSk7Il0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXSwibWFwcGluZ3MiOiI7OztDQUFBLENBQUMsU0FBUyxHQUFFLEdBQUU7RUFBQyxZQUFVLE9BQU8sV0FBUyxlQUFhLE9BQU8sU0FBTyxPQUFPLFVBQVEsRUFBRSxJQUFFLGNBQVksT0FBTyxVQUFRLE9BQU8sTUFBSSxPQUFPLENBQUMsSUFBRSxDQUFDLElBQUUsZUFBYSxPQUFPLGFBQVcsYUFBVyxLQUFHLEtBQUEsQ0FBTSx3QkFBc0IsRUFBRTtDQUFDLEVBQUEsQ0FBQyxVQUFPLFdBQVU7RUFBQztFQUFhLE9BQU8sU0FBUyxHQUFFLEdBQUUsR0FBRTtHQUFDLElBQUksSUFBRSxVQUFTLElBQUU7SUFBQyxTQUFRLG9CQUFrQjtJQUFFLFNBQVEsZ0JBQWM7SUFBRSxTQUFRLG1CQUFpQjtJQUFFLFVBQVMsZUFBYTtJQUFFLFVBQVMsc0JBQW9CO0lBQUUsVUFBUztHQUFZO0dBQUUsRUFBRSxVQUFVLFdBQVMsU0FBUyxHQUFFLEdBQUU7SUFBQyxJQUFJLElBQUUsS0FBRyxLQUFLLFFBQVEsQ0FBQyxDQUFDLFlBQVUsR0FBRSxJQUFFLEVBQUUsS0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxHQUFFLElBQUUsS0FBSyxLQUFLLEdBQUUsS0FBSSxDQUFDLENBQUMsR0FBRSxJQUFFLFlBQVcsSUFBRSxJQUFFLEtBQUcsSUFBRSxJQUFFLEtBQUcsYUFBVyxJQUFFLElBQUUsWUFBVSxJQUFFLElBQUUsWUFBVSxJQUFFLElBQUUsWUFBVSxJQUFFLElBQUUsYUFBVyxHQUFFLElBQUUsRUFBRSxNQUFJLEVBQUU7SUFBRyxPQUFNLGNBQVksT0FBTyxJQUFFLEVBQUUsS0FBSyxNQUFLLEVBQUUsQ0FBQyxJQUFFLEtBQUssT0FBTyxDQUFDO0dBQUM7RUFBQztDQUFDLEVBQUUifQ==