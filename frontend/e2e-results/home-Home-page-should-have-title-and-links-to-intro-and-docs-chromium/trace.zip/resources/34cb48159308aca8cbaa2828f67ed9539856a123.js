import { noop, makeDestructurable, camelize, isClient, toArray, watchImmediate, isObject, tryOnScopeDispose, isIOS, notNullish, tryOnMounted, objectOmit, promiseTimeout, until, injectLocal, provideLocal, pxValue, increaseWithUnit, objectEntries, createRef, createSingletonPromise, useTimeoutFn, pausableWatch, toRef, createEventHook, useIntervalFn, computedWithControl, timestamp, pausableFilter, watchIgnorable, debounceFilter, bypassFilter, createFilterWrapper, toRefs, watchOnce, containsProp, hasOwn, throttleFilter, useDebounceFn, useThrottleFn, tryOnUnmounted, clamp, syncRef, objectPick, watchWithFilter, identity, isDef, whenever, isWorker } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vueuse+shared@13.9.0_vue@3.5.40_typescript@6.0.3_/node_modules/@vueuse/shared/index.mjs?v=7e73afc2";
export * from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vueuse+shared@13.9.0_vue@3.5.40_typescript@6.0.3_/node_modules/@vueuse/shared/index.mjs?v=7e73afc2";
import { isRef, shallowRef, ref, watchEffect, computed, inject, defineComponent, h, TransitionGroup, Fragment, shallowReactive, toValue, unref, getCurrentInstance, onMounted, watch, customRef, onUpdated, readonly, reactive, hasInjectionContext, toRaw, shallowReadonly, nextTick, markRaw, getCurrentScope, isReadonly, onBeforeUpdate } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
function computedAsync(evaluationCallback, initialState, optionsOrRef) {
	var _a;
	let options;
	if (isRef(optionsOrRef)) {
		options = { evaluating: optionsOrRef };
	} else {
		options = optionsOrRef || {};
	}
	const { lazy = false, flush = "pre", evaluating = void 0, shallow = true, onError = (_a = globalThis.reportError) != null ? _a : noop } = options;
	const started = shallowRef(!lazy);
	const current = shallow ? shallowRef(initialState) : ref(initialState);
	let counter = 0;
	watchEffect(async (onInvalidate) => {
		if (!started.value) return;
		counter++;
		const counterAtBeginning = counter;
		let hasFinished = false;
		if (evaluating) {
			Promise.resolve().then(() => {
				evaluating.value = true;
			});
		}
		try {
			const result = await evaluationCallback((cancelCallback) => {
				onInvalidate(() => {
					if (evaluating) evaluating.value = false;
					if (!hasFinished) cancelCallback();
				});
			});
			if (counterAtBeginning === counter) current.value = result;
		} catch (e) {
			onError(e);
		} finally {
			if (evaluating && counterAtBeginning === counter) evaluating.value = false;
			hasFinished = true;
		}
	}, { flush });
	if (lazy) {
		return computed(() => {
			started.value = true;
			return current.value;
		});
	} else {
		return current;
	}
}
function computedInject(key, options, defaultSource, treatDefaultAsFactory) {
	let source = inject(key);
	if (defaultSource) source = inject(key, defaultSource);
	if (treatDefaultAsFactory) source = inject(key, defaultSource, treatDefaultAsFactory);
	if (typeof options === "function") {
		return computed((oldValue) => options(source, oldValue));
	} else {
		return computed({
			get: (oldValue) => options.get(source, oldValue),
			set: options.set
		});
	}
}
// @__NO_SIDE_EFFECTS__
function createReusableTemplate(options = {}) {
	const { inheritAttrs = true } = options;
	const render = shallowRef();
	const define = /*@__PURE__*/ defineComponent({ setup(_, { slots }) {
		return () => {
			render.value = slots.default;
		};
	} });
	const reuse = /*@__PURE__*/ defineComponent({
		inheritAttrs,
		props: options.props,
		setup(props, { attrs, slots }) {
			return () => {
				var _a;
				if (!render.value && "development" !== "production") throw new Error("[VueUse] Failed to find the definition of reusable template");
				const vnode = (_a = render.value) == null ? void 0 : _a.call(render, {
					...options.props == null ? keysToCamelKebabCase(attrs) : props,
					$slots: slots
				});
				return inheritAttrs && (vnode == null ? void 0 : vnode.length) === 1 ? vnode[0] : vnode;
			};
		}
	});
	return makeDestructurable({
		define,
		reuse
	}, [define, reuse]);
}
function keysToCamelKebabCase(obj) {
	const newObj = {};
	for (const key in obj) newObj[camelize(key)] = obj[key];
	return newObj;
}
// @__NO_SIDE_EFFECTS__
function createTemplatePromise(options = {}) {
	let index = 0;
	const instances = ref([]);
	function create(...args) {
		const props = shallowReactive({
			key: index++,
			args,
			promise: void 0,
			resolve: () => {},
			reject: () => {},
			isResolving: false,
			options
		});
		instances.value.push(props);
		props.promise = new Promise((_resolve, _reject) => {
			props.resolve = (v) => {
				props.isResolving = true;
				return _resolve(v);
			};
			props.reject = _reject;
		}).finally(() => {
			props.promise = void 0;
			const index2 = instances.value.indexOf(props);
			if (index2 !== -1) instances.value.splice(index2, 1);
		});
		return props.promise;
	}
	function start(...args) {
		if (options.singleton && instances.value.length > 0) return instances.value[0].promise;
		return create(...args);
	}
	const component = /*@__PURE__*/ defineComponent((_, { slots }) => {
		const renderList = () => instances.value.map((props) => {
			var _a;
			return h(Fragment, { key: props.key }, (_a = slots.default) == null ? void 0 : _a.call(slots, props));
		});
		if (options.transition) return () => h(TransitionGroup, options.transition, renderList);
		return renderList;
	});
	component.start = start;
	return component;
}
// @__NO_SIDE_EFFECTS__
function createUnrefFn(fn) {
	return function(...args) {
		return fn.apply(this, args.map((i) => toValue(i)));
	};
}
const defaultWindow = isClient ? window : void 0;
const defaultDocument = isClient ? window.document : void 0;
const defaultNavigator = isClient ? window.navigator : void 0;
const defaultLocation = isClient ? window.location : void 0;
function unrefElement(elRef) {
	var _a;
	const plain = toValue(elRef);
	return (_a = plain == null ? void 0 : plain.$el) != null ? _a : plain;
}
function useEventListener(...args) {
	const cleanups = [];
	const cleanup = () => {
		cleanups.forEach((fn) => fn());
		cleanups.length = 0;
	};
	const register = (el, event, listener, options) => {
		el.addEventListener(event, listener, options);
		return () => el.removeEventListener(event, listener, options);
	};
	const firstParamTargets = computed(() => {
		const test = toArray(toValue(args[0])).filter((e) => e != null);
		return test.every((e) => typeof e !== "string") ? test : void 0;
	});
	const stopWatch = watchImmediate(() => {
		var _a, _b;
		return [
			(_b = (_a = firstParamTargets.value) == null ? void 0 : _a.map((e) => unrefElement(e))) != null ? _b : [defaultWindow].filter((e) => e != null),
			toArray(toValue(firstParamTargets.value ? args[1] : args[0])),
			toArray(unref(firstParamTargets.value ? args[2] : args[1])),
			toValue(firstParamTargets.value ? args[3] : args[2])
		];
	}, ([raw_targets, raw_events, raw_listeners, raw_options]) => {
		cleanup();
		if (!(raw_targets == null ? void 0 : raw_targets.length) || !(raw_events == null ? void 0 : raw_events.length) || !(raw_listeners == null ? void 0 : raw_listeners.length)) return;
		const optionsClone = isObject(raw_options) ? { ...raw_options } : raw_options;
		cleanups.push(...raw_targets.flatMap((el) => raw_events.flatMap((event) => raw_listeners.map((listener) => register(el, event, listener, optionsClone)))));
	}, { flush: "post" });
	const stop = () => {
		stopWatch();
		cleanup();
	};
	tryOnScopeDispose(cleanup);
	return stop;
}
let _iOSWorkaround = false;
function onClickOutside(target, handler, options = {}) {
	const { window = defaultWindow, ignore = [], capture = true, detectIframe = false, controls = false } = options;
	if (!window) {
		return controls ? {
			stop: noop,
			cancel: noop,
			trigger: noop
		} : noop;
	}
	if (isIOS && !_iOSWorkaround) {
		_iOSWorkaround = true;
		const listenerOptions = { passive: true };
		Array.from(window.document.body.children).forEach((el) => el.addEventListener("click", noop, listenerOptions));
		window.document.documentElement.addEventListener("click", noop, listenerOptions);
	}
	let shouldListen = true;
	const shouldIgnore = (event) => {
		return toValue(ignore).some((target2) => {
			if (typeof target2 === "string") {
				return Array.from(window.document.querySelectorAll(target2)).some((el) => el === event.target || event.composedPath().includes(el));
			} else {
				const el = unrefElement(target2);
				return el && (event.target === el || event.composedPath().includes(el));
			}
		});
	};
	function hasMultipleRoots(target2) {
		const vm = toValue(target2);
		return vm && vm.$.subTree.shapeFlag === 16;
	}
	function checkMultipleRoots(target2, event) {
		const vm = toValue(target2);
		const children = vm.$.subTree && vm.$.subTree.children;
		if (children == null || !Array.isArray(children)) return false;
		return children.some((child) => child.el === event.target || event.composedPath().includes(child.el));
	}
	const listener = (event) => {
		const el = unrefElement(target);
		if (event.target == null) return;
		if (!(el instanceof Element) && hasMultipleRoots(target) && checkMultipleRoots(target, event)) return;
		if (!el || el === event.target || event.composedPath().includes(el)) return;
		if ("detail" in event && event.detail === 0) shouldListen = !shouldIgnore(event);
		if (!shouldListen) {
			shouldListen = true;
			return;
		}
		handler(event);
	};
	let isProcessingClick = false;
	const cleanup = [
		useEventListener(window, "click", (event) => {
			if (!isProcessingClick) {
				isProcessingClick = true;
				setTimeout(() => {
					isProcessingClick = false;
				}, 0);
				listener(event);
			}
		}, {
			passive: true,
			capture
		}),
		useEventListener(window, "pointerdown", (e) => {
			const el = unrefElement(target);
			shouldListen = !shouldIgnore(e) && !!(el && !e.composedPath().includes(el));
		}, { passive: true }),
		detectIframe && useEventListener(window, "blur", (event) => {
			setTimeout(() => {
				var _a;
				const el = unrefElement(target);
				if (((_a = window.document.activeElement) == null ? void 0 : _a.tagName) === "IFRAME" && !(el == null ? void 0 : el.contains(window.document.activeElement))) {
					handler(event);
				}
			}, 0);
		}, { passive: true })
	].filter(Boolean);
	const stop = () => cleanup.forEach((fn) => fn());
	if (controls) {
		return {
			stop,
			cancel: () => {
				shouldListen = false;
			},
			trigger: (event) => {
				shouldListen = true;
				listener(event);
				shouldListen = false;
			}
		};
	}
	return stop;
}
// @__NO_SIDE_EFFECTS__
function useMounted() {
	const isMounted = shallowRef(false);
	const instance = getCurrentInstance();
	if (instance) {
		onMounted(() => {
			isMounted.value = true;
		}, instance);
	}
	return isMounted;
}
// @__NO_SIDE_EFFECTS__
function useSupported(callback) {
	const isMounted = useMounted();
	return computed(() => {
		isMounted.value;
		return Boolean(callback());
	});
}
function useMutationObserver(target, callback, options = {}) {
	const { window = defaultWindow, ...mutationOptions } = options;
	let observer;
	const isSupported = useSupported(() => window && "MutationObserver" in window);
	const cleanup = () => {
		if (observer) {
			observer.disconnect();
			observer = void 0;
		}
	};
	const targets = computed(() => {
		const value = toValue(target);
		const items = toArray(value).map(unrefElement).filter(notNullish);
		return new Set(items);
	});
	const stopWatch = watch(targets, (newTargets) => {
		cleanup();
		if (isSupported.value && newTargets.size) {
			observer = new MutationObserver(callback);
			newTargets.forEach((el) => observer.observe(el, mutationOptions));
		}
	}, {
		immediate: true,
		flush: "post"
	});
	const takeRecords = () => {
		return observer == null ? void 0 : observer.takeRecords();
	};
	const stop = () => {
		stopWatch();
		cleanup();
	};
	tryOnScopeDispose(stop);
	return {
		isSupported,
		stop,
		takeRecords
	};
}
function onElementRemoval(target, callback, options = {}) {
	const { window = defaultWindow, document = window == null ? void 0 : window.document, flush = "sync" } = options;
	if (!window || !document) return noop;
	let stopFn;
	const cleanupAndUpdate = (fn) => {
		stopFn == null ? void 0 : stopFn();
		stopFn = fn;
	};
	const stopWatch = watchEffect(() => {
		const el = unrefElement(target);
		if (el) {
			const { stop } = useMutationObserver(document, (mutationsList) => {
				const targetRemoved = mutationsList.map((mutation) => [...mutation.removedNodes]).flat().some((node) => node === el || node.contains(el));
				if (targetRemoved) {
					callback(mutationsList);
				}
			}, {
				window,
				childList: true,
				subtree: true
			});
			cleanupAndUpdate(stop);
		}
	}, { flush });
	const stopHandle = () => {
		stopWatch();
		cleanupAndUpdate();
	};
	tryOnScopeDispose(stopHandle);
	return stopHandle;
}
function createKeyPredicate(keyFilter) {
	if (typeof keyFilter === "function") return keyFilter;
	else if (typeof keyFilter === "string") return (event) => event.key === keyFilter;
	else if (Array.isArray(keyFilter)) return (event) => keyFilter.includes(event.key);
	return () => true;
}
function onKeyStroke(...args) {
	let key;
	let handler;
	let options = {};
	if (args.length === 3) {
		key = args[0];
		handler = args[1];
		options = args[2];
	} else if (args.length === 2) {
		if (typeof args[1] === "object") {
			key = true;
			handler = args[0];
			options = args[1];
		} else {
			key = args[0];
			handler = args[1];
		}
	} else {
		key = true;
		handler = args[0];
	}
	const { target = defaultWindow, eventName = "keydown", passive = false, dedupe = false } = options;
	const predicate = createKeyPredicate(key);
	const listener = (e) => {
		if (e.repeat && toValue(dedupe)) return;
		if (predicate(e)) handler(e);
	};
	return useEventListener(target, eventName, listener, passive);
}
function onKeyDown(key, handler, options = {}) {
	return onKeyStroke(key, handler, {
		...options,
		eventName: "keydown"
	});
}
function onKeyPressed(key, handler, options = {}) {
	return onKeyStroke(key, handler, {
		...options,
		eventName: "keypress"
	});
}
function onKeyUp(key, handler, options = {}) {
	return onKeyStroke(key, handler, {
		...options,
		eventName: "keyup"
	});
}
const DEFAULT_DELAY = 500;
const DEFAULT_THRESHOLD = 10;
function onLongPress(target, handler, options) {
	var _a, _b;
	const elementRef = computed(() => unrefElement(target));
	let timeout;
	let posStart;
	let startTimestamp;
	let hasLongPressed = false;
	function clear() {
		if (timeout) {
			clearTimeout(timeout);
			timeout = void 0;
		}
		posStart = void 0;
		startTimestamp = void 0;
		hasLongPressed = false;
	}
	function getDelay(ev) {
		const delay = options == null ? void 0 : options.delay;
		if (typeof delay === "function") {
			return delay(ev);
		}
		return delay != null ? delay : DEFAULT_DELAY;
	}
	function onRelease(ev) {
		var _a2, _b2, _c;
		const [_startTimestamp, _posStart, _hasLongPressed] = [
			startTimestamp,
			posStart,
			hasLongPressed
		];
		clear();
		if (!(options == null ? void 0 : options.onMouseUp) || !_posStart || !_startTimestamp) return;
		if (((_a2 = options == null ? void 0 : options.modifiers) == null ? void 0 : _a2.self) && ev.target !== elementRef.value) return;
		if ((_b2 = options == null ? void 0 : options.modifiers) == null ? void 0 : _b2.prevent) ev.preventDefault();
		if ((_c = options == null ? void 0 : options.modifiers) == null ? void 0 : _c.stop) ev.stopPropagation();
		const dx = ev.x - _posStart.x;
		const dy = ev.y - _posStart.y;
		const distance = Math.sqrt(dx * dx + dy * dy);
		options.onMouseUp(ev.timeStamp - _startTimestamp, distance, _hasLongPressed);
	}
	function onDown(ev) {
		var _a2, _b2, _c;
		if (((_a2 = options == null ? void 0 : options.modifiers) == null ? void 0 : _a2.self) && ev.target !== elementRef.value) return;
		clear();
		if ((_b2 = options == null ? void 0 : options.modifiers) == null ? void 0 : _b2.prevent) ev.preventDefault();
		if ((_c = options == null ? void 0 : options.modifiers) == null ? void 0 : _c.stop) ev.stopPropagation();
		posStart = {
			x: ev.x,
			y: ev.y
		};
		startTimestamp = ev.timeStamp;
		timeout = setTimeout(() => {
			hasLongPressed = true;
			handler(ev);
		}, getDelay(ev));
	}
	function onMove(ev) {
		var _a2, _b2, _c, _d;
		if (((_a2 = options == null ? void 0 : options.modifiers) == null ? void 0 : _a2.self) && ev.target !== elementRef.value) return;
		if (!posStart || (options == null ? void 0 : options.distanceThreshold) === false) return;
		if ((_b2 = options == null ? void 0 : options.modifiers) == null ? void 0 : _b2.prevent) ev.preventDefault();
		if ((_c = options == null ? void 0 : options.modifiers) == null ? void 0 : _c.stop) ev.stopPropagation();
		const dx = ev.x - posStart.x;
		const dy = ev.y - posStart.y;
		const distance = Math.sqrt(dx * dx + dy * dy);
		if (distance >= ((_d = options == null ? void 0 : options.distanceThreshold) != null ? _d : DEFAULT_THRESHOLD)) clear();
	}
	const listenerOptions = {
		capture: (_a = options == null ? void 0 : options.modifiers) == null ? void 0 : _a.capture,
		once: (_b = options == null ? void 0 : options.modifiers) == null ? void 0 : _b.once
	};
	const cleanup = [
		useEventListener(elementRef, "pointerdown", onDown, listenerOptions),
		useEventListener(elementRef, "pointermove", onMove, listenerOptions),
		useEventListener(elementRef, ["pointerup", "pointerleave"], onRelease, listenerOptions)
	];
	const stop = () => cleanup.forEach((fn) => fn());
	return stop;
}
function isFocusedElementEditable() {
	const { activeElement, body } = document;
	if (!activeElement) return false;
	if (activeElement === body) return false;
	switch (activeElement.tagName) {
		case "INPUT":
		case "TEXTAREA": return true;
	}
	return activeElement.hasAttribute("contenteditable");
}
function isTypedCharValid({ keyCode, metaKey, ctrlKey, altKey }) {
	if (metaKey || ctrlKey || altKey) return false;
	if (keyCode >= 48 && keyCode <= 57 || keyCode >= 96 && keyCode <= 105) return true;
	if (keyCode >= 65 && keyCode <= 90) return true;
	return false;
}
function onStartTyping(callback, options = {}) {
	const { document: document2 = defaultDocument } = options;
	const keydown = (event) => {
		if (!isFocusedElementEditable() && isTypedCharValid(event)) {
			callback(event);
		}
	};
	if (document2) useEventListener(document2, "keydown", keydown, { passive: true });
}
// @__NO_SIDE_EFFECTS__
function templateRef(key, initialValue = null) {
	const instance = getCurrentInstance();
	let _trigger = () => {};
	const element = customRef((track, trigger) => {
		_trigger = trigger;
		return {
			get() {
				var _a, _b;
				track();
				return (_b = (_a = instance == null ? void 0 : instance.proxy) == null ? void 0 : _a.$refs[key]) != null ? _b : initialValue;
			},
			set() {}
		};
	});
	tryOnMounted(_trigger);
	onUpdated(_trigger);
	return element;
}
// @__NO_SIDE_EFFECTS__
function useActiveElement(options = {}) {
	var _a;
	const { window = defaultWindow, deep = true, triggerOnRemoval = false } = options;
	const document = (_a = options.document) != null ? _a : window == null ? void 0 : window.document;
	const getDeepActiveElement = () => {
		var _a2;
		let element = document == null ? void 0 : document.activeElement;
		if (deep) {
			while (element == null ? void 0 : element.shadowRoot) element = (_a2 = element == null ? void 0 : element.shadowRoot) == null ? void 0 : _a2.activeElement;
		}
		return element;
	};
	const activeElement = shallowRef();
	const trigger = () => {
		activeElement.value = getDeepActiveElement();
	};
	if (window) {
		const listenerOptions = {
			capture: true,
			passive: true
		};
		useEventListener(window, "blur", (event) => {
			if (event.relatedTarget !== null) return;
			trigger();
		}, listenerOptions);
		useEventListener(window, "focus", trigger, listenerOptions);
	}
	if (triggerOnRemoval) {
		onElementRemoval(activeElement, trigger, { document });
	}
	trigger();
	return activeElement;
}
function useRafFn(fn, options = {}) {
	const { immediate = true, fpsLimit = void 0, window = defaultWindow, once = false } = options;
	const isActive = shallowRef(false);
	const intervalLimit = computed(() => {
		return fpsLimit ? 1e3 / toValue(fpsLimit) : null;
	});
	let previousFrameTimestamp = 0;
	let rafId = null;
	function loop(timestamp) {
		if (!isActive.value || !window) return;
		if (!previousFrameTimestamp) previousFrameTimestamp = timestamp;
		const delta = timestamp - previousFrameTimestamp;
		if (intervalLimit.value && delta < intervalLimit.value) {
			rafId = window.requestAnimationFrame(loop);
			return;
		}
		previousFrameTimestamp = timestamp;
		fn({
			delta,
			timestamp
		});
		if (once) {
			isActive.value = false;
			rafId = null;
			return;
		}
		rafId = window.requestAnimationFrame(loop);
	}
	function resume() {
		if (!isActive.value && window) {
			isActive.value = true;
			previousFrameTimestamp = 0;
			rafId = window.requestAnimationFrame(loop);
		}
	}
	function pause() {
		isActive.value = false;
		if (rafId != null && window) {
			window.cancelAnimationFrame(rafId);
			rafId = null;
		}
	}
	if (immediate) resume();
	tryOnScopeDispose(pause);
	return {
		isActive: readonly(isActive),
		pause,
		resume
	};
}
function useAnimate(target, keyframes, options) {
	let config;
	let animateOptions;
	if (isObject(options)) {
		config = options;
		animateOptions = objectOmit(options, [
			"window",
			"immediate",
			"commitStyles",
			"persist",
			"onReady",
			"onError"
		]);
	} else {
		config = { duration: options };
		animateOptions = options;
	}
	const { window = defaultWindow, immediate = true, commitStyles, persist, playbackRate: _playbackRate = 1, onReady, onError = (e) => {
		console.error(e);
	} } = config;
	const isSupported = useSupported(() => window && HTMLElement && "animate" in HTMLElement.prototype);
	const animate = shallowRef(void 0);
	const store = shallowReactive({
		startTime: null,
		currentTime: null,
		timeline: null,
		playbackRate: _playbackRate,
		pending: false,
		playState: immediate ? "idle" : "paused",
		replaceState: "active"
	});
	const pending = computed(() => store.pending);
	const playState = computed(() => store.playState);
	const replaceState = computed(() => store.replaceState);
	const startTime = computed({
		get() {
			return store.startTime;
		},
		set(value) {
			store.startTime = value;
			if (animate.value) animate.value.startTime = value;
		}
	});
	const currentTime = computed({
		get() {
			return store.currentTime;
		},
		set(value) {
			store.currentTime = value;
			if (animate.value) {
				animate.value.currentTime = value;
				syncResume();
			}
		}
	});
	const timeline = computed({
		get() {
			return store.timeline;
		},
		set(value) {
			store.timeline = value;
			if (animate.value) animate.value.timeline = value;
		}
	});
	const playbackRate = computed({
		get() {
			return store.playbackRate;
		},
		set(value) {
			store.playbackRate = value;
			if (animate.value) animate.value.playbackRate = value;
		}
	});
	const play = () => {
		if (animate.value) {
			try {
				animate.value.play();
				syncResume();
			} catch (e) {
				syncPause();
				onError(e);
			}
		} else {
			update();
		}
	};
	const pause = () => {
		var _a;
		try {
			(_a = animate.value) == null ? void 0 : _a.pause();
			syncPause();
		} catch (e) {
			onError(e);
		}
	};
	const reverse = () => {
		var _a;
		if (!animate.value) update();
		try {
			(_a = animate.value) == null ? void 0 : _a.reverse();
			syncResume();
		} catch (e) {
			syncPause();
			onError(e);
		}
	};
	const finish = () => {
		var _a;
		try {
			(_a = animate.value) == null ? void 0 : _a.finish();
			syncPause();
		} catch (e) {
			onError(e);
		}
	};
	const cancel = () => {
		var _a;
		try {
			(_a = animate.value) == null ? void 0 : _a.cancel();
			syncPause();
		} catch (e) {
			onError(e);
		}
	};
	watch(() => unrefElement(target), (el) => {
		if (el) {
			update(true);
		} else {
			animate.value = void 0;
		}
	});
	watch(() => keyframes, (value) => {
		if (animate.value) {
			update();
			const targetEl = unrefElement(target);
			if (targetEl) {
				animate.value.effect = new KeyframeEffect(targetEl, toValue(value), animateOptions);
			}
		}
	}, { deep: true });
	tryOnMounted(() => update(true), false);
	tryOnScopeDispose(cancel);
	function update(init) {
		const el = unrefElement(target);
		if (!isSupported.value || !el) return;
		if (!animate.value) animate.value = el.animate(toValue(keyframes), animateOptions);
		if (persist) animate.value.persist();
		if (_playbackRate !== 1) animate.value.playbackRate = _playbackRate;
		if (init && !immediate) animate.value.pause();
		else syncResume();
		onReady == null ? void 0 : onReady(animate.value);
	}
	const listenerOptions = { passive: true };
	useEventListener(animate, [
		"cancel",
		"finish",
		"remove"
	], syncPause, listenerOptions);
	useEventListener(animate, "finish", () => {
		var _a;
		if (commitStyles) (_a = animate.value) == null ? void 0 : _a.commitStyles();
	}, listenerOptions);
	const { resume: resumeRef, pause: pauseRef } = useRafFn(() => {
		if (!animate.value) return;
		store.pending = animate.value.pending;
		store.playState = animate.value.playState;
		store.replaceState = animate.value.replaceState;
		store.startTime = animate.value.startTime;
		store.currentTime = animate.value.currentTime;
		store.timeline = animate.value.timeline;
		store.playbackRate = animate.value.playbackRate;
	}, { immediate: false });
	function syncResume() {
		if (isSupported.value) resumeRef();
	}
	function syncPause() {
		if (isSupported.value && window) window.requestAnimationFrame(pauseRef);
	}
	return {
		isSupported,
		animate,
		// actions
		play,
		pause,
		reverse,
		finish,
		cancel,
		// state
		pending,
		playState,
		replaceState,
		startTime,
		currentTime,
		timeline,
		playbackRate
	};
}
function useAsyncQueue(tasks, options) {
	const { interrupt = true, onError = noop, onFinished = noop, signal } = options || {};
	const promiseState = {
		aborted: "aborted",
		fulfilled: "fulfilled",
		pending: "pending",
		rejected: "rejected"
	};
	const initialResult = Array.from(Array.from({ length: tasks.length }), () => ({
		state: promiseState.pending,
		data: null
	}));
	const result = reactive(initialResult);
	const activeIndex = shallowRef(-1);
	if (!tasks || tasks.length === 0) {
		onFinished();
		return {
			activeIndex,
			result
		};
	}
	function updateResult(state, res) {
		activeIndex.value++;
		result[activeIndex.value].data = res;
		result[activeIndex.value].state = state;
	}
	tasks.reduce((prev, curr) => {
		return prev.then((prevRes) => {
			var _a;
			if (signal == null ? void 0 : signal.aborted) {
				updateResult(promiseState.aborted, new Error("aborted"));
				return;
			}
			if (((_a = result[activeIndex.value]) == null ? void 0 : _a.state) === promiseState.rejected && interrupt) {
				onFinished();
				return;
			}
			const done = curr(prevRes).then((currentRes) => {
				updateResult(promiseState.fulfilled, currentRes);
				if (activeIndex.value === tasks.length - 1) onFinished();
				return currentRes;
			});
			if (!signal) return done;
			return Promise.race([done, whenAborted(signal)]);
		}).catch((e) => {
			if (signal == null ? void 0 : signal.aborted) {
				updateResult(promiseState.aborted, e);
				return e;
			}
			updateResult(promiseState.rejected, e);
			onError();
			return e;
		});
	}, Promise.resolve());
	return {
		activeIndex,
		result
	};
}
function whenAborted(signal) {
	return new Promise((resolve, reject) => {
		const error = new Error("aborted");
		if (signal.aborted) reject(error);
		else signal.addEventListener("abort", () => reject(error), { once: true });
	});
}
function useAsyncState(promise, initialState, options) {
	var _a;
	const { immediate = true, delay = 0, onError = (_a = globalThis.reportError) != null ? _a : noop, onSuccess = noop, resetOnExecute = true, shallow = true, throwError } = options != null ? options : {};
	const state = shallow ? shallowRef(initialState) : ref(initialState);
	const isReady = shallowRef(false);
	const isLoading = shallowRef(false);
	const error = shallowRef(void 0);
	async function execute(delay2 = 0, ...args) {
		if (resetOnExecute) state.value = toValue(initialState);
		error.value = void 0;
		isReady.value = false;
		isLoading.value = true;
		if (delay2 > 0) await promiseTimeout(delay2);
		const _promise = typeof promise === "function" ? promise(...args) : promise;
		try {
			const data = await _promise;
			state.value = data;
			isReady.value = true;
			onSuccess(data);
		} catch (e) {
			error.value = e;
			onError(e);
			if (throwError) throw e;
		} finally {
			isLoading.value = false;
		}
		return state.value;
	}
	if (immediate) {
		execute(delay);
	}
	const shell = {
		state,
		isReady,
		isLoading,
		error,
		execute,
		executeImmediate: (...args) => execute(0, ...args)
	};
	function waitUntilIsLoaded() {
		return new Promise((resolve, reject) => {
			until(isLoading).toBe(false).then(() => resolve(shell)).catch(reject);
		});
	}
	return {
		...shell,
		then(onFulfilled, onRejected) {
			return waitUntilIsLoaded().then(onFulfilled, onRejected);
		}
	};
}
const defaults = {
	array: (v) => JSON.stringify(v),
	object: (v) => JSON.stringify(v),
	set: (v) => JSON.stringify(Array.from(v)),
	map: (v) => JSON.stringify(Object.fromEntries(v)),
	null: () => ""
};
function getDefaultSerialization(target) {
	if (!target) return defaults.null;
	if (target instanceof Map) return defaults.map;
	else if (target instanceof Set) return defaults.set;
	else if (Array.isArray(target)) return defaults.array;
	else return defaults.object;
}
function useBase64(target, options) {
	const base64 = shallowRef("");
	const promise = shallowRef();
	function execute() {
		if (!isClient) return;
		promise.value = new Promise((resolve, reject) => {
			try {
				const _target = toValue(target);
				if (_target == null) {
					resolve("");
				} else if (typeof _target === "string") {
					resolve(blobToBase64(new Blob([_target], { type: "text/plain" })));
				} else if (_target instanceof Blob) {
					resolve(blobToBase64(_target));
				} else if (_target instanceof ArrayBuffer) {
					resolve(window.btoa(String.fromCharCode(...new Uint8Array(_target))));
				} else if (_target instanceof HTMLCanvasElement) {
					resolve(_target.toDataURL(options == null ? void 0 : options.type, options == null ? void 0 : options.quality));
				} else if (_target instanceof HTMLImageElement) {
					const img = _target.cloneNode(false);
					img.crossOrigin = "Anonymous";
					imgLoaded(img).then(() => {
						const canvas = document.createElement("canvas");
						const ctx = canvas.getContext("2d");
						canvas.width = img.width;
						canvas.height = img.height;
						ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
						resolve(canvas.toDataURL(options == null ? void 0 : options.type, options == null ? void 0 : options.quality));
					}).catch(reject);
				} else if (typeof _target === "object") {
					const _serializeFn = (options == null ? void 0 : options.serializer) || getDefaultSerialization(_target);
					const serialized = _serializeFn(_target);
					return resolve(blobToBase64(new Blob([serialized], { type: "application/json" })));
				} else {
					reject(new Error("target is unsupported types"));
				}
			} catch (error) {
				reject(error);
			}
		});
		promise.value.then((res) => {
			base64.value = (options == null ? void 0 : options.dataUrl) === false ? res.replace(/^data:.*?;base64,/, "") : res;
		});
		return promise.value;
	}
	if (isRef(target) || typeof target === "function") watch(target, execute, { immediate: true });
	else execute();
	return {
		base64,
		promise,
		execute
	};
}
function imgLoaded(img) {
	return new Promise((resolve, reject) => {
		if (!img.complete) {
			img.onload = () => {
				resolve();
			};
			img.onerror = reject;
		} else {
			resolve();
		}
	});
}
function blobToBase64(blob) {
	return new Promise((resolve, reject) => {
		const fr = new FileReader();
		fr.onload = (e) => {
			resolve(e.target.result);
		};
		fr.onerror = reject;
		fr.readAsDataURL(blob);
	});
}
// @__NO_SIDE_EFFECTS__
function useBattery(options = {}) {
	const { navigator = defaultNavigator } = options;
	const events = [
		"chargingchange",
		"chargingtimechange",
		"dischargingtimechange",
		"levelchange"
	];
	const isSupported = useSupported(() => navigator && "getBattery" in navigator && typeof navigator.getBattery === "function");
	const charging = shallowRef(false);
	const chargingTime = shallowRef(0);
	const dischargingTime = shallowRef(0);
	const level = shallowRef(1);
	let battery;
	function updateBatteryInfo() {
		charging.value = this.charging;
		chargingTime.value = this.chargingTime || 0;
		dischargingTime.value = this.dischargingTime || 0;
		level.value = this.level;
	}
	if (isSupported.value) {
		navigator.getBattery().then((_battery) => {
			battery = _battery;
			updateBatteryInfo.call(battery);
			useEventListener(battery, events, updateBatteryInfo, { passive: true });
		});
	}
	return {
		isSupported,
		charging,
		chargingTime,
		dischargingTime,
		level
	};
}
// @__NO_SIDE_EFFECTS__
function useBluetooth(options) {
	let { acceptAllDevices = false } = options || {};
	const { filters = void 0, optionalServices = void 0, navigator = defaultNavigator } = options || {};
	const isSupported = useSupported(() => navigator && "bluetooth" in navigator);
	const device = shallowRef();
	const error = shallowRef(null);
	watch(device, () => {
		connectToBluetoothGATTServer();
	});
	async function requestDevice() {
		if (!isSupported.value) return;
		error.value = null;
		if (filters && filters.length > 0) acceptAllDevices = false;
		try {
			device.value = await (navigator == null ? void 0 : navigator.bluetooth.requestDevice({
				acceptAllDevices,
				filters,
				optionalServices
			}));
		} catch (err) {
			error.value = err;
		}
	}
	const server = shallowRef();
	const isConnected = shallowRef(false);
	function reset() {
		isConnected.value = false;
		device.value = void 0;
		server.value = void 0;
	}
	async function connectToBluetoothGATTServer() {
		error.value = null;
		if (device.value && device.value.gatt) {
			useEventListener(device, "gattserverdisconnected", reset, { passive: true });
			try {
				server.value = await device.value.gatt.connect();
				isConnected.value = server.value.connected;
			} catch (err) {
				error.value = err;
			}
		}
	}
	tryOnMounted(() => {
		var _a;
		if (device.value) (_a = device.value.gatt) == null ? void 0 : _a.connect();
	});
	tryOnScopeDispose(() => {
		var _a;
		if (device.value) (_a = device.value.gatt) == null ? void 0 : _a.disconnect();
	});
	return {
		isSupported,
		isConnected: readonly(isConnected),
		// Device:
		device,
		requestDevice,
		// Server:
		server,
		// Errors:
		error
	};
}
const ssrWidthSymbol = Symbol("vueuse-ssr-width");
// @__NO_SIDE_EFFECTS__
function useSSRWidth() {
	const ssrWidth = hasInjectionContext() ? injectLocal(ssrWidthSymbol, null) : null;
	return typeof ssrWidth === "number" ? ssrWidth : void 0;
}
function provideSSRWidth(width, app) {
	if (app !== void 0) {
		app.provide(ssrWidthSymbol, width);
	} else {
		provideLocal(ssrWidthSymbol, width);
	}
}
function useMediaQuery(query, options = {}) {
	const { window = defaultWindow, ssrWidth = useSSRWidth() } = options;
	const isSupported = useSupported(() => window && "matchMedia" in window && typeof window.matchMedia === "function");
	const ssrSupport = shallowRef(typeof ssrWidth === "number");
	const mediaQuery = shallowRef();
	const matches = shallowRef(false);
	const handler = (event) => {
		matches.value = event.matches;
	};
	watchEffect(() => {
		if (ssrSupport.value) {
			ssrSupport.value = !isSupported.value;
			const queryStrings = toValue(query).split(",");
			matches.value = queryStrings.some((queryString) => {
				const not = queryString.includes("not all");
				const minWidth = queryString.match(/\(\s*min-width:\s*(-?\d+(?:\.\d*)?[a-z]+\s*)\)/);
				const maxWidth = queryString.match(/\(\s*max-width:\s*(-?\d+(?:\.\d*)?[a-z]+\s*)\)/);
				let res = Boolean(minWidth || maxWidth);
				if (minWidth && res) {
					res = ssrWidth >= pxValue(minWidth[1]);
				}
				if (maxWidth && res) {
					res = ssrWidth <= pxValue(maxWidth[1]);
				}
				return not ? !res : res;
			});
			return;
		}
		if (!isSupported.value) return;
		mediaQuery.value = window.matchMedia(toValue(query));
		matches.value = mediaQuery.value.matches;
	});
	useEventListener(mediaQuery, "change", handler, { passive: true });
	return computed(() => matches.value);
}
const breakpointsTailwind = {
	"sm": 640,
	"md": 768,
	"lg": 1024,
	"xl": 1280,
	"2xl": 1536
};
const breakpointsBootstrapV5 = {
	xs: 0,
	sm: 576,
	md: 768,
	lg: 992,
	xl: 1200,
	xxl: 1400
};
const breakpointsVuetifyV2 = {
	xs: 0,
	sm: 600,
	md: 960,
	lg: 1264,
	xl: 1904
};
const breakpointsVuetifyV3 = {
	xs: 0,
	sm: 600,
	md: 960,
	lg: 1280,
	xl: 1920,
	xxl: 2560
};
const breakpointsVuetify = breakpointsVuetifyV2;
const breakpointsAntDesign = {
	xs: 480,
	sm: 576,
	md: 768,
	lg: 992,
	xl: 1200,
	xxl: 1600
};
const breakpointsQuasar = {
	xs: 0,
	sm: 600,
	md: 1024,
	lg: 1440,
	xl: 1920
};
const breakpointsSematic = {
	mobileS: 320,
	mobileM: 375,
	mobileL: 425,
	tablet: 768,
	laptop: 1024,
	laptopL: 1440,
	desktop4K: 2560
};
const breakpointsMasterCss = {
	"3xs": 360,
	"2xs": 480,
	"xs": 600,
	"sm": 768,
	"md": 1024,
	"lg": 1280,
	"xl": 1440,
	"2xl": 1600,
	"3xl": 1920,
	"4xl": 2560
};
const breakpointsPrimeFlex = {
	sm: 576,
	md: 768,
	lg: 992,
	xl: 1200
};
const breakpointsElement = {
	xs: 0,
	sm: 768,
	md: 992,
	lg: 1200,
	xl: 1920
};
// @__NO_SIDE_EFFECTS__
function useBreakpoints(breakpoints, options = {}) {
	function getValue(k, delta) {
		let v = toValue(breakpoints[toValue(k)]);
		if (delta != null) v = increaseWithUnit(v, delta);
		if (typeof v === "number") v = `${v}px`;
		return v;
	}
	const { window = defaultWindow, strategy = "min-width", ssrWidth = useSSRWidth() } = options;
	const ssrSupport = typeof ssrWidth === "number";
	const mounted = ssrSupport ? shallowRef(false) : { value: true };
	if (ssrSupport) {
		tryOnMounted(() => mounted.value = !!window);
	}
	function match(query, size) {
		if (!mounted.value && ssrSupport) {
			return query === "min" ? ssrWidth >= pxValue(size) : ssrWidth <= pxValue(size);
		}
		if (!window) return false;
		return window.matchMedia(`(${query}-width: ${size})`).matches;
	}
	const greaterOrEqual = (k) => {
		return useMediaQuery(() => `(min-width: ${getValue(k)})`, options);
	};
	const smallerOrEqual = (k) => {
		return useMediaQuery(() => `(max-width: ${getValue(k)})`, options);
	};
	const shortcutMethods = Object.keys(breakpoints).reduce((shortcuts, k) => {
		Object.defineProperty(shortcuts, k, {
			get: () => strategy === "min-width" ? greaterOrEqual(k) : smallerOrEqual(k),
			enumerable: true,
			configurable: true
		});
		return shortcuts;
	}, {});
	function current() {
		const points = Object.keys(breakpoints).map((k) => [
			k,
			shortcutMethods[k],
			pxValue(getValue(k))
		]).sort((a, b) => a[2] - b[2]);
		return computed(() => points.filter(([, v]) => v.value).map(([k]) => k));
	}
	return Object.assign(shortcutMethods, {
		greaterOrEqual,
		smallerOrEqual,
		greater(k) {
			return useMediaQuery(() => `(min-width: ${getValue(k, .1)})`, options);
		},
		smaller(k) {
			return useMediaQuery(() => `(max-width: ${getValue(k, -.1)})`, options);
		},
		between(a, b) {
			return useMediaQuery(() => `(min-width: ${getValue(a)}) and (max-width: ${getValue(b, -.1)})`, options);
		},
		isGreater(k) {
			return match("min", getValue(k, .1));
		},
		isGreaterOrEqual(k) {
			return match("min", getValue(k));
		},
		isSmaller(k) {
			return match("max", getValue(k, -.1));
		},
		isSmallerOrEqual(k) {
			return match("max", getValue(k));
		},
		isInBetween(a, b) {
			return match("min", getValue(a)) && match("max", getValue(b, -.1));
		},
		current,
		active() {
			const bps = current();
			return computed(() => bps.value.length === 0 ? "" : bps.value.at(strategy === "min-width" ? -1 : 0));
		}
	});
}
function useBroadcastChannel(options) {
	const { name, window = defaultWindow } = options;
	const isSupported = useSupported(() => window && "BroadcastChannel" in window);
	const isClosed = shallowRef(false);
	const channel = ref();
	const data = ref();
	const error = shallowRef(null);
	const post = (data2) => {
		if (channel.value) channel.value.postMessage(data2);
	};
	const close = () => {
		if (channel.value) channel.value.close();
		isClosed.value = true;
	};
	if (isSupported.value) {
		tryOnMounted(() => {
			error.value = null;
			channel.value = new BroadcastChannel(name);
			const listenerOptions = { passive: true };
			useEventListener(channel, "message", (e) => {
				data.value = e.data;
			}, listenerOptions);
			useEventListener(channel, "messageerror", (e) => {
				error.value = e;
			}, listenerOptions);
			useEventListener(channel, "close", () => {
				isClosed.value = true;
			}, listenerOptions);
		});
	}
	tryOnScopeDispose(() => {
		close();
	});
	return {
		isSupported,
		channel,
		data,
		post,
		close,
		error,
		isClosed
	};
}
const WRITABLE_PROPERTIES = [
	"hash",
	"host",
	"hostname",
	"href",
	"pathname",
	"port",
	"protocol",
	"search"
];
// @__NO_SIDE_EFFECTS__
function useBrowserLocation(options = {}) {
	const { window = defaultWindow } = options;
	const refs = Object.fromEntries(WRITABLE_PROPERTIES.map((key) => [key, ref()]));
	for (const [key, ref] of objectEntries(refs)) {
		watch(ref, (value) => {
			if (!(window == null ? void 0 : window.location) || window.location[key] === value) return;
			window.location[key] = value;
		});
	}
	const buildState = (trigger) => {
		var _a;
		const { state: state2, length } = (window == null ? void 0 : window.history) || {};
		const { origin } = (window == null ? void 0 : window.location) || {};
		for (const key of WRITABLE_PROPERTIES) refs[key].value = (_a = window == null ? void 0 : window.location) == null ? void 0 : _a[key];
		return reactive({
			trigger,
			state: state2,
			length,
			origin,
			...refs
		});
	};
	const state = ref(buildState("load"));
	if (window) {
		const listenerOptions = { passive: true };
		useEventListener(window, "popstate", () => state.value = buildState("popstate"), listenerOptions);
		useEventListener(window, "hashchange", () => state.value = buildState("hashchange"), listenerOptions);
	}
	return state;
}
function useCached(refValue, comparator = (a, b) => a === b, options) {
	const { deepRefs = true, ...watchOptions } = options || {};
	const cachedValue = createRef(refValue.value, deepRefs);
	watch(() => refValue.value, (value) => {
		if (!comparator(value, cachedValue.value)) cachedValue.value = value;
	}, watchOptions);
	return cachedValue;
}
// @__NO_SIDE_EFFECTS__
function usePermission(permissionDesc, options = {}) {
	const { controls = false, navigator = defaultNavigator } = options;
	const isSupported = useSupported(() => navigator && "permissions" in navigator);
	const permissionStatus = shallowRef();
	const desc = typeof permissionDesc === "string" ? { name: permissionDesc } : permissionDesc;
	const state = shallowRef();
	const update = () => {
		var _a, _b;
		state.value = (_b = (_a = permissionStatus.value) == null ? void 0 : _a.state) != null ? _b : "prompt";
	};
	useEventListener(permissionStatus, "change", update, { passive: true });
	const query = createSingletonPromise(async () => {
		if (!isSupported.value) return;
		if (!permissionStatus.value) {
			try {
				permissionStatus.value = await navigator.permissions.query(desc);
			} catch (e) {
				permissionStatus.value = void 0;
			} finally {
				update();
			}
		}
		if (controls) return toRaw(permissionStatus.value);
	});
	query();
	if (controls) {
		return {
			state,
			isSupported,
			query
		};
	} else {
		return state;
	}
}
function useClipboard(options = {}) {
	const { navigator = defaultNavigator, read = false, source, copiedDuring = 1500, legacy = false } = options;
	const isClipboardApiSupported = useSupported(() => navigator && "clipboard" in navigator);
	const permissionRead = usePermission("clipboard-read");
	const permissionWrite = usePermission("clipboard-write");
	const isSupported = computed(() => isClipboardApiSupported.value || legacy);
	const text = shallowRef("");
	const copied = shallowRef(false);
	const timeout = useTimeoutFn(() => copied.value = false, copiedDuring, { immediate: false });
	async function updateText() {
		let useLegacy = !(isClipboardApiSupported.value && isAllowed(permissionRead.value));
		if (!useLegacy) {
			try {
				text.value = await navigator.clipboard.readText();
			} catch (e) {
				useLegacy = true;
			}
		}
		if (useLegacy) {
			text.value = legacyRead();
		}
	}
	if (isSupported.value && read) useEventListener(["copy", "cut"], updateText, { passive: true });
	async function copy(value = toValue(source)) {
		if (isSupported.value && value != null) {
			let useLegacy = !(isClipboardApiSupported.value && isAllowed(permissionWrite.value));
			if (!useLegacy) {
				try {
					await navigator.clipboard.writeText(value);
				} catch (e) {
					useLegacy = true;
				}
			}
			if (useLegacy) legacyCopy(value);
			text.value = value;
			copied.value = true;
			timeout.start();
		}
	}
	function legacyCopy(value) {
		const ta = document.createElement("textarea");
		ta.value = value != null ? value : "";
		ta.style.position = "absolute";
		ta.style.opacity = "0";
		document.body.appendChild(ta);
		ta.select();
		document.execCommand("copy");
		ta.remove();
	}
	function legacyRead() {
		var _a, _b, _c;
		return (_c = (_b = (_a = document == null ? void 0 : document.getSelection) == null ? void 0 : _a.call(document)) == null ? void 0 : _b.toString()) != null ? _c : "";
	}
	function isAllowed(status) {
		return status === "granted" || status === "prompt";
	}
	return {
		isSupported,
		text,
		copied,
		copy
	};
}
function useClipboardItems(options = {}) {
	const { navigator = defaultNavigator, read = false, source, copiedDuring = 1500 } = options;
	const isSupported = useSupported(() => navigator && "clipboard" in navigator);
	const content = ref([]);
	const copied = shallowRef(false);
	const timeout = useTimeoutFn(() => copied.value = false, copiedDuring, { immediate: false });
	function updateContent() {
		if (isSupported.value) {
			navigator.clipboard.read().then((items) => {
				content.value = items;
			});
		}
	}
	if (isSupported.value && read) {
		useEventListener(["copy", "cut"], updateContent, { passive: true });
	}
	async function copy(value = toValue(source)) {
		if (isSupported.value && value != null) {
			await navigator.clipboard.write(value);
			content.value = value;
			copied.value = true;
			timeout.start();
		}
	}
	return {
		isSupported,
		content: shallowReadonly(content),
		copied: readonly(copied),
		copy,
		read: updateContent
	};
}
function cloneFnJSON(source) {
	return JSON.parse(JSON.stringify(source));
}
function useCloned(source, options = {}) {
	const cloned = ref({});
	const isModified = shallowRef(false);
	let _lastSync = false;
	const { manual, clone = cloneFnJSON, deep = true, immediate = true } = options;
	watch(cloned, () => {
		if (_lastSync) {
			_lastSync = false;
			return;
		}
		isModified.value = true;
	}, {
		deep: true,
		flush: "sync"
	});
	function sync() {
		_lastSync = true;
		isModified.value = false;
		cloned.value = clone(toValue(source));
	}
	if (!manual && (isRef(source) || typeof source === "function")) {
		watch(source, sync, {
			...options,
			deep,
			immediate
		});
	} else {
		sync();
	}
	return {
		cloned,
		isModified,
		sync
	};
}
const _global = typeof globalThis !== "undefined" ? globalThis : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : typeof self !== "undefined" ? self : {};
const globalKey = "__vueuse_ssr_handlers__";
const handlers = /* @__PURE__ */ getHandlers();
function getHandlers() {
	if (!(globalKey in _global)) _global[globalKey] = _global[globalKey] || {};
	return _global[globalKey];
}
function getSSRHandler(key, fallback) {
	return handlers[key] || fallback;
}
function setSSRHandler(key, fn) {
	handlers[key] = fn;
}
// @__NO_SIDE_EFFECTS__
function usePreferredDark(options) {
	return useMediaQuery("(prefers-color-scheme: dark)", options);
}
function guessSerializerType(rawInit) {
	return rawInit == null ? "any" : rawInit instanceof Set ? "set" : rawInit instanceof Map ? "map" : rawInit instanceof Date ? "date" : typeof rawInit === "boolean" ? "boolean" : typeof rawInit === "string" ? "string" : typeof rawInit === "object" ? "object" : !Number.isNaN(rawInit) ? "number" : "any";
}
const StorageSerializers = {
	boolean: {
		read: (v) => v === "true",
		write: (v) => String(v)
	},
	object: {
		read: (v) => JSON.parse(v),
		write: (v) => JSON.stringify(v)
	},
	number: {
		read: (v) => Number.parseFloat(v),
		write: (v) => String(v)
	},
	any: {
		read: (v) => v,
		write: (v) => String(v)
	},
	string: {
		read: (v) => v,
		write: (v) => String(v)
	},
	map: {
		read: (v) => new Map(JSON.parse(v)),
		write: (v) => JSON.stringify(Array.from(v.entries()))
	},
	set: {
		read: (v) => new Set(JSON.parse(v)),
		write: (v) => JSON.stringify(Array.from(v))
	},
	date: {
		read: (v) => new Date(v),
		write: (v) => v.toISOString()
	}
};
const customStorageEventName = "vueuse-storage";
function useStorage(key, defaults, storage, options = {}) {
	var _a;
	const { flush = "pre", deep = true, listenToStorageChanges = true, writeDefaults = true, mergeDefaults = false, shallow, window = defaultWindow, eventFilter, onError = (e) => {
		console.error(e);
	}, initOnMounted } = options;
	const data = (shallow ? shallowRef : ref)(typeof defaults === "function" ? defaults() : defaults);
	const keyComputed = computed(() => toValue(key));
	if (!storage) {
		try {
			storage = getSSRHandler("getDefaultStorage", () => {
				var _a2;
				return (_a2 = defaultWindow) == null ? void 0 : _a2.localStorage;
			})();
		} catch (e) {
			onError(e);
		}
	}
	if (!storage) return data;
	const rawInit = toValue(defaults);
	const type = guessSerializerType(rawInit);
	const serializer = (_a = options.serializer) != null ? _a : StorageSerializers[type];
	const { pause: pauseWatch, resume: resumeWatch } = pausableWatch(data, (newValue) => write(newValue), {
		flush,
		deep,
		eventFilter
	});
	watch(keyComputed, () => update(), { flush });
	let firstMounted = false;
	const onStorageEvent = (ev) => {
		if (initOnMounted && !firstMounted) {
			return;
		}
		update(ev);
	};
	const onStorageCustomEvent = (ev) => {
		if (initOnMounted && !firstMounted) {
			return;
		}
		updateFromCustomEvent(ev);
	};
	if (window && listenToStorageChanges) {
		if (storage instanceof Storage) useEventListener(window, "storage", onStorageEvent, { passive: true });
		else useEventListener(window, customStorageEventName, onStorageCustomEvent);
	}
	if (initOnMounted) {
		tryOnMounted(() => {
			firstMounted = true;
			update();
		});
	} else {
		update();
	}
	function dispatchWriteEvent(oldValue, newValue) {
		if (window) {
			const payload = {
				key: keyComputed.value,
				oldValue,
				newValue,
				storageArea: storage
			};
			window.dispatchEvent(storage instanceof Storage ? new StorageEvent("storage", payload) : new CustomEvent(customStorageEventName, { detail: payload }));
		}
	}
	function write(v) {
		try {
			const oldValue = storage.getItem(keyComputed.value);
			if (v == null) {
				dispatchWriteEvent(oldValue, null);
				storage.removeItem(keyComputed.value);
			} else {
				const serialized = serializer.write(v);
				if (oldValue !== serialized) {
					storage.setItem(keyComputed.value, serialized);
					dispatchWriteEvent(oldValue, serialized);
				}
			}
		} catch (e) {
			onError(e);
		}
	}
	function read(event) {
		const rawValue = event ? event.newValue : storage.getItem(keyComputed.value);
		if (rawValue == null) {
			if (writeDefaults && rawInit != null) storage.setItem(keyComputed.value, serializer.write(rawInit));
			return rawInit;
		} else if (!event && mergeDefaults) {
			const value = serializer.read(rawValue);
			if (typeof mergeDefaults === "function") return mergeDefaults(value, rawInit);
			else if (type === "object" && !Array.isArray(value)) return {
				...rawInit,
				...value
			};
			return value;
		} else if (typeof rawValue !== "string") {
			return rawValue;
		} else {
			return serializer.read(rawValue);
		}
	}
	function update(event) {
		if (event && event.storageArea !== storage) return;
		if (event && event.key == null) {
			data.value = rawInit;
			return;
		}
		if (event && event.key !== keyComputed.value) {
			return;
		}
		pauseWatch();
		try {
			const serializedData = serializer.write(data.value);
			if (event === void 0 || (event == null ? void 0 : event.newValue) !== serializedData) {
				data.value = read(event);
			}
		} catch (e) {
			onError(e);
		} finally {
			if (event) nextTick(resumeWatch);
			else resumeWatch();
		}
	}
	function updateFromCustomEvent(event) {
		update(event.detail);
	}
	return data;
}
const CSS_DISABLE_TRANS = "*,*::before,*::after{-webkit-transition:none!important;-moz-transition:none!important;-o-transition:none!important;-ms-transition:none!important;transition:none!important}";
function useColorMode(options = {}) {
	const { selector = "html", attribute = "class", initialValue = "auto", window = defaultWindow, storage, storageKey = "vueuse-color-scheme", listenToStorageChanges = true, storageRef, emitAuto, disableTransition = true } = options;
	const modes = {
		auto: "",
		light: "light",
		dark: "dark",
		...options.modes || {}
	};
	const preferredDark = usePreferredDark({ window });
	const system = computed(() => preferredDark.value ? "dark" : "light");
	const store = storageRef || (storageKey == null ? toRef(initialValue) : useStorage(storageKey, initialValue, storage, {
		window,
		listenToStorageChanges
	}));
	const state = computed(() => store.value === "auto" ? system.value : store.value);
	const updateHTMLAttrs = getSSRHandler("updateHTMLAttrs", (selector2, attribute2, value) => {
		const el = typeof selector2 === "string" ? window == null ? void 0 : window.document.querySelector(selector2) : unrefElement(selector2);
		if (!el) return;
		const classesToAdd = /* @__PURE__ */ new Set();
		const classesToRemove = /* @__PURE__ */ new Set();
		let attributeToChange = null;
		if (attribute2 === "class") {
			const current = value.split(/\s/g);
			Object.values(modes).flatMap((i) => (i || "").split(/\s/g)).filter(Boolean).forEach((v) => {
				if (current.includes(v)) classesToAdd.add(v);
				else classesToRemove.add(v);
			});
		} else {
			attributeToChange = {
				key: attribute2,
				value
			};
		}
		if (classesToAdd.size === 0 && classesToRemove.size === 0 && attributeToChange === null) return;
		let style;
		if (disableTransition) {
			style = window.document.createElement("style");
			style.appendChild(document.createTextNode(CSS_DISABLE_TRANS));
			window.document.head.appendChild(style);
		}
		for (const c of classesToAdd) {
			el.classList.add(c);
		}
		for (const c of classesToRemove) {
			el.classList.remove(c);
		}
		if (attributeToChange) {
			el.setAttribute(attributeToChange.key, attributeToChange.value);
		}
		if (disableTransition) {
			window.getComputedStyle(style).opacity;
			document.head.removeChild(style);
		}
	});
	function defaultOnChanged(mode) {
		var _a;
		updateHTMLAttrs(selector, attribute, (_a = modes[mode]) != null ? _a : mode);
	}
	function onChanged(mode) {
		if (options.onChanged) options.onChanged(mode, defaultOnChanged);
		else defaultOnChanged(mode);
	}
	watch(state, onChanged, {
		flush: "post",
		immediate: true
	});
	tryOnMounted(() => onChanged(state.value));
	const auto = computed({
		get() {
			return emitAuto ? store.value : state.value;
		},
		set(v) {
			store.value = v;
		}
	});
	return Object.assign(auto, {
		store,
		system,
		state
	});
}
// @__NO_SIDE_EFFECTS__
function useConfirmDialog(revealed = shallowRef(false)) {
	const confirmHook = createEventHook();
	const cancelHook = createEventHook();
	const revealHook = createEventHook();
	let _resolve = noop;
	const reveal = (data) => {
		revealHook.trigger(data);
		revealed.value = true;
		return new Promise((resolve) => {
			_resolve = resolve;
		});
	};
	const confirm = (data) => {
		revealed.value = false;
		confirmHook.trigger(data);
		_resolve({
			data,
			isCanceled: false
		});
	};
	const cancel = (data) => {
		revealed.value = false;
		cancelHook.trigger(data);
		_resolve({
			data,
			isCanceled: true
		});
	};
	return {
		isRevealed: computed(() => revealed.value),
		reveal,
		confirm,
		cancel,
		onReveal: revealHook.on,
		onConfirm: confirmHook.on,
		onCancel: cancelHook.on
	};
}
function useCountdown(initialCountdown, options) {
	var _a, _b;
	const remaining = shallowRef(toValue(initialCountdown));
	const intervalController = useIntervalFn(() => {
		var _a2, _b2;
		const value = remaining.value - 1;
		remaining.value = value < 0 ? 0 : value;
		(_a2 = options == null ? void 0 : options.onTick) == null ? void 0 : _a2.call(options);
		if (remaining.value <= 0) {
			intervalController.pause();
			(_b2 = options == null ? void 0 : options.onComplete) == null ? void 0 : _b2.call(options);
		}
	}, (_a = options == null ? void 0 : options.interval) != null ? _a : 1e3, { immediate: (_b = options == null ? void 0 : options.immediate) != null ? _b : false });
	const reset = (countdown) => {
		var _a2;
		remaining.value = (_a2 = toValue(countdown)) != null ? _a2 : toValue(initialCountdown);
	};
	const stop = () => {
		intervalController.pause();
		reset();
	};
	const resume = () => {
		if (!intervalController.isActive.value) {
			if (remaining.value > 0) {
				intervalController.resume();
			}
		}
	};
	const start = (countdown) => {
		reset(countdown);
		intervalController.resume();
	};
	return {
		remaining,
		reset,
		stop,
		start,
		pause: intervalController.pause,
		resume,
		isActive: intervalController.isActive
	};
}
function useCssVar(prop, target, options = {}) {
	const { window = defaultWindow, initialValue, observe = false } = options;
	const variable = shallowRef(initialValue);
	const elRef = computed(() => {
		var _a;
		return unrefElement(target) || ((_a = window == null ? void 0 : window.document) == null ? void 0 : _a.documentElement);
	});
	function updateCssVar() {
		var _a;
		const key = toValue(prop);
		const el = toValue(elRef);
		if (el && window && key) {
			const value = (_a = window.getComputedStyle(el).getPropertyValue(key)) == null ? void 0 : _a.trim();
			variable.value = value || variable.value || initialValue;
		}
	}
	if (observe) {
		useMutationObserver(elRef, updateCssVar, {
			attributeFilter: ["style", "class"],
			window
		});
	}
	watch([elRef, () => toValue(prop)], (_, old) => {
		if (old[0] && old[1]) old[0].style.removeProperty(old[1]);
		updateCssVar();
	}, { immediate: true });
	watch([variable, elRef], ([val, el]) => {
		const raw_prop = toValue(prop);
		if ((el == null ? void 0 : el.style) && raw_prop) {
			if (val == null) el.style.removeProperty(raw_prop);
			else el.style.setProperty(raw_prop, val);
		}
	}, { immediate: true });
	return variable;
}
function useCurrentElement(rootComponent) {
	const vm = getCurrentInstance();
	const currentElement = computedWithControl(() => null, () => rootComponent ? unrefElement(rootComponent) : vm.proxy.$el);
	onUpdated(currentElement.trigger);
	onMounted(currentElement.trigger);
	return currentElement;
}
function useCycleList(list, options) {
	const state = shallowRef(getInitialValue());
	const listRef = toRef(list);
	const index = computed({
		get() {
			var _a;
			const targetList = listRef.value;
			let index2 = (options == null ? void 0 : options.getIndexOf) ? options.getIndexOf(state.value, targetList) : targetList.indexOf(state.value);
			if (index2 < 0) index2 = (_a = options == null ? void 0 : options.fallbackIndex) != null ? _a : 0;
			return index2;
		},
		set(v) {
			set(v);
		}
	});
	function set(i) {
		const targetList = listRef.value;
		const length = targetList.length;
		const index2 = (i % length + length) % length;
		const value = targetList[index2];
		state.value = value;
		return value;
	}
	function shift(delta = 1) {
		return set(index.value + delta);
	}
	function next(n = 1) {
		return shift(n);
	}
	function prev(n = 1) {
		return shift(-n);
	}
	function getInitialValue() {
		var _a, _b;
		return (_b = toValue((_a = options == null ? void 0 : options.initialValue) != null ? _a : toValue(list)[0])) != null ? _b : void 0;
	}
	watch(listRef, () => set(index.value));
	return {
		state,
		index,
		next,
		prev,
		go: set
	};
}
function useDark(options = {}) {
	const { valueDark = "dark", valueLight = "" } = options;
	const mode = useColorMode({
		...options,
		onChanged: (mode2, defaultHandler) => {
			var _a;
			if (options.onChanged) (_a = options.onChanged) == null ? void 0 : _a.call(options, mode2 === "dark", defaultHandler, mode2);
			else defaultHandler(mode2);
		},
		modes: {
			dark: valueDark,
			light: valueLight
		}
	});
	const system = computed(() => mode.system.value);
	const isDark = computed({
		get() {
			return mode.value === "dark";
		},
		set(v) {
			const modeVal = v ? "dark" : "light";
			if (system.value === modeVal) mode.value = "auto";
			else mode.value = modeVal;
		}
	});
	return isDark;
}
function fnBypass(v) {
	return v;
}
function fnSetSource(source, value) {
	return source.value = value;
}
function defaultDump(clone) {
	return clone ? typeof clone === "function" ? clone : cloneFnJSON : fnBypass;
}
function defaultParse(clone) {
	return clone ? typeof clone === "function" ? clone : cloneFnJSON : fnBypass;
}
function useManualRefHistory(source, options = {}) {
	const { clone = false, dump = defaultDump(clone), parse = defaultParse(clone), setSource = fnSetSource } = options;
	function _createHistoryRecord() {
		return markRaw({
			snapshot: dump(source.value),
			timestamp: timestamp()
		});
	}
	const last = ref(_createHistoryRecord());
	const undoStack = ref([]);
	const redoStack = ref([]);
	const _setSource = (record) => {
		setSource(source, parse(record.snapshot));
		last.value = record;
	};
	const commit = () => {
		undoStack.value.unshift(last.value);
		last.value = _createHistoryRecord();
		if (options.capacity && undoStack.value.length > options.capacity) undoStack.value.splice(options.capacity, Number.POSITIVE_INFINITY);
		if (redoStack.value.length) redoStack.value.splice(0, redoStack.value.length);
	};
	const clear = () => {
		undoStack.value.splice(0, undoStack.value.length);
		redoStack.value.splice(0, redoStack.value.length);
	};
	const undo = () => {
		const state = undoStack.value.shift();
		if (state) {
			redoStack.value.unshift(last.value);
			_setSource(state);
		}
	};
	const redo = () => {
		const state = redoStack.value.shift();
		if (state) {
			undoStack.value.unshift(last.value);
			_setSource(state);
		}
	};
	const reset = () => {
		_setSource(last.value);
	};
	const history = computed(() => [last.value, ...undoStack.value]);
	const canUndo = computed(() => undoStack.value.length > 0);
	const canRedo = computed(() => redoStack.value.length > 0);
	return {
		source,
		undoStack,
		redoStack,
		last,
		history,
		canUndo,
		canRedo,
		clear,
		commit,
		reset,
		undo,
		redo
	};
}
function useRefHistory(source, options = {}) {
	const { deep = false, flush = "pre", eventFilter, shouldCommit = () => true } = options;
	const { eventFilter: composedFilter, pause, resume: resumeTracking, isActive: isTracking } = pausableFilter(eventFilter);
	let lastRawValue = source.value;
	const { ignoreUpdates, ignorePrevAsyncUpdates, stop } = watchIgnorable(source, commit, {
		deep,
		flush,
		eventFilter: composedFilter
	});
	function setSource(source2, value) {
		ignorePrevAsyncUpdates();
		ignoreUpdates(() => {
			source2.value = value;
			lastRawValue = value;
		});
	}
	const manualHistory = useManualRefHistory(source, {
		...options,
		clone: options.clone || deep,
		setSource
	});
	const { clear, commit: manualCommit } = manualHistory;
	function commit() {
		ignorePrevAsyncUpdates();
		if (!shouldCommit(lastRawValue, source.value)) return;
		lastRawValue = source.value;
		manualCommit();
	}
	function resume(commitNow) {
		resumeTracking();
		if (commitNow) commit();
	}
	function batch(fn) {
		let canceled = false;
		const cancel = () => canceled = true;
		ignoreUpdates(() => {
			fn(cancel);
		});
		if (!canceled) commit();
	}
	function dispose() {
		stop();
		clear();
	}
	return {
		...manualHistory,
		isTracking,
		pause,
		resume,
		commit,
		batch,
		dispose
	};
}
function useDebouncedRefHistory(source, options = {}) {
	const filter = options.debounce ? debounceFilter(options.debounce) : void 0;
	const history = useRefHistory(source, {
		...options,
		eventFilter: filter
	});
	return { ...history };
}
function useDeviceMotion(options = {}) {
	const { window = defaultWindow, requestPermissions = false, eventFilter = bypassFilter } = options;
	const isSupported = useSupported(() => typeof DeviceMotionEvent !== "undefined");
	const requirePermissions = useSupported(() => isSupported.value && "requestPermission" in DeviceMotionEvent && typeof DeviceMotionEvent.requestPermission === "function");
	const permissionGranted = shallowRef(false);
	const acceleration = ref({
		x: null,
		y: null,
		z: null
	});
	const rotationRate = ref({
		alpha: null,
		beta: null,
		gamma: null
	});
	const interval = shallowRef(0);
	const accelerationIncludingGravity = ref({
		x: null,
		y: null,
		z: null
	});
	function init() {
		if (window) {
			const onDeviceMotion = createFilterWrapper(eventFilter, (event) => {
				var _a, _b, _c, _d, _e, _f, _g, _h, _i;
				acceleration.value = {
					x: ((_a = event.acceleration) == null ? void 0 : _a.x) || null,
					y: ((_b = event.acceleration) == null ? void 0 : _b.y) || null,
					z: ((_c = event.acceleration) == null ? void 0 : _c.z) || null
				};
				accelerationIncludingGravity.value = {
					x: ((_d = event.accelerationIncludingGravity) == null ? void 0 : _d.x) || null,
					y: ((_e = event.accelerationIncludingGravity) == null ? void 0 : _e.y) || null,
					z: ((_f = event.accelerationIncludingGravity) == null ? void 0 : _f.z) || null
				};
				rotationRate.value = {
					alpha: ((_g = event.rotationRate) == null ? void 0 : _g.alpha) || null,
					beta: ((_h = event.rotationRate) == null ? void 0 : _h.beta) || null,
					gamma: ((_i = event.rotationRate) == null ? void 0 : _i.gamma) || null
				};
				interval.value = event.interval;
			});
			useEventListener(window, "devicemotion", onDeviceMotion, { passive: true });
		}
	}
	const ensurePermissions = async () => {
		if (!requirePermissions.value) permissionGranted.value = true;
		if (permissionGranted.value) return;
		if (requirePermissions.value) {
			const requestPermission = DeviceMotionEvent.requestPermission;
			try {
				const response = await requestPermission();
				if (response === "granted") {
					permissionGranted.value = true;
					init();
				}
			} catch (error) {
				console.error(error);
			}
		}
	};
	if (isSupported.value) {
		if (requestPermissions && requirePermissions.value) {
			ensurePermissions().then(() => init());
		} else {
			init();
		}
	}
	return {
		acceleration,
		accelerationIncludingGravity,
		rotationRate,
		interval,
		isSupported,
		requirePermissions,
		ensurePermissions,
		permissionGranted
	};
}
// @__NO_SIDE_EFFECTS__
function useDeviceOrientation(options = {}) {
	const { window = defaultWindow } = options;
	const isSupported = useSupported(() => window && "DeviceOrientationEvent" in window);
	const isAbsolute = shallowRef(false);
	const alpha = shallowRef(null);
	const beta = shallowRef(null);
	const gamma = shallowRef(null);
	if (window && isSupported.value) {
		useEventListener(window, "deviceorientation", (event) => {
			isAbsolute.value = event.absolute;
			alpha.value = event.alpha;
			beta.value = event.beta;
			gamma.value = event.gamma;
		}, { passive: true });
	}
	return {
		isSupported,
		isAbsolute,
		alpha,
		beta,
		gamma
	};
}
// @__NO_SIDE_EFFECTS__
function useDevicePixelRatio(options = {}) {
	const { window = defaultWindow } = options;
	const pixelRatio = shallowRef(1);
	const query = useMediaQuery(() => `(resolution: ${pixelRatio.value}dppx)`, options);
	let stop = noop;
	if (window) {
		stop = watchImmediate(query, () => pixelRatio.value = window.devicePixelRatio);
	}
	return {
		pixelRatio: readonly(pixelRatio),
		stop
	};
}
function useDevicesList(options = {}) {
	const { navigator = defaultNavigator, requestPermissions = false, constraints = {
		audio: true,
		video: true
	}, onUpdated } = options;
	const devices = ref([]);
	const videoInputs = computed(() => devices.value.filter((i) => i.kind === "videoinput"));
	const audioInputs = computed(() => devices.value.filter((i) => i.kind === "audioinput"));
	const audioOutputs = computed(() => devices.value.filter((i) => i.kind === "audiooutput"));
	const isSupported = useSupported(() => navigator && navigator.mediaDevices && navigator.mediaDevices.enumerateDevices);
	const permissionGranted = shallowRef(false);
	let stream;
	async function update() {
		if (!isSupported.value) return;
		devices.value = await navigator.mediaDevices.enumerateDevices();
		onUpdated == null ? void 0 : onUpdated(devices.value);
		if (stream) {
			stream.getTracks().forEach((t) => t.stop());
			stream = null;
		}
	}
	async function ensurePermissions() {
		const deviceName = constraints.video ? "camera" : "microphone";
		if (!isSupported.value) return false;
		if (permissionGranted.value) return true;
		const { state, query } = usePermission(deviceName, { controls: true });
		await query();
		if (state.value !== "granted") {
			let granted = true;
			try {
				const allDevices = await navigator.mediaDevices.enumerateDevices();
				const hasCamera = allDevices.some((device) => device.kind === "videoinput");
				const hasMicrophone = allDevices.some((device) => device.kind === "audioinput" || device.kind === "audiooutput");
				constraints.video = hasCamera ? constraints.video : false;
				constraints.audio = hasMicrophone ? constraints.audio : false;
				stream = await navigator.mediaDevices.getUserMedia(constraints);
			} catch (e) {
				stream = null;
				granted = false;
			}
			update();
			permissionGranted.value = granted;
		} else {
			permissionGranted.value = true;
		}
		return permissionGranted.value;
	}
	if (isSupported.value) {
		if (requestPermissions) ensurePermissions();
		useEventListener(navigator.mediaDevices, "devicechange", update, { passive: true });
		update();
	}
	return {
		devices,
		ensurePermissions,
		permissionGranted,
		videoInputs,
		audioInputs,
		audioOutputs,
		isSupported
	};
}
function useDisplayMedia(options = {}) {
	var _a;
	const enabled = shallowRef((_a = options.enabled) != null ? _a : false);
	const video = options.video;
	const audio = options.audio;
	const { navigator = defaultNavigator } = options;
	const isSupported = useSupported(() => {
		var _a2;
		return (_a2 = navigator == null ? void 0 : navigator.mediaDevices) == null ? void 0 : _a2.getDisplayMedia;
	});
	const constraint = {
		audio,
		video
	};
	const stream = shallowRef();
	async function _start() {
		var _a2;
		if (!isSupported.value || stream.value) return;
		stream.value = await navigator.mediaDevices.getDisplayMedia(constraint);
		(_a2 = stream.value) == null ? void 0 : _a2.getTracks().forEach((t) => useEventListener(t, "ended", stop, { passive: true }));
		return stream.value;
	}
	async function _stop() {
		var _a2;
		(_a2 = stream.value) == null ? void 0 : _a2.getTracks().forEach((t) => t.stop());
		stream.value = void 0;
	}
	function stop() {
		_stop();
		enabled.value = false;
	}
	async function start() {
		await _start();
		if (stream.value) enabled.value = true;
		return stream.value;
	}
	watch(enabled, (v) => {
		if (v) _start();
		else _stop();
	}, { immediate: true });
	return {
		isSupported,
		stream,
		start,
		stop,
		enabled
	};
}
// @__NO_SIDE_EFFECTS__
function useDocumentVisibility(options = {}) {
	const { document = defaultDocument } = options;
	if (!document) return shallowRef("visible");
	const visibility = shallowRef(document.visibilityState);
	useEventListener(document, "visibilitychange", () => {
		visibility.value = document.visibilityState;
	}, { passive: true });
	return visibility;
}
function useDraggable(target, options = {}) {
	var _a;
	const { pointerTypes, preventDefault, stopPropagation, exact, onMove, onEnd, onStart, initialValue, axis = "both", draggingElement = defaultWindow, containerElement, handle: draggingHandle = target, buttons = [0] } = options;
	const position = ref((_a = toValue(initialValue)) != null ? _a : {
		x: 0,
		y: 0
	});
	const pressedDelta = ref();
	const filterEvent = (e) => {
		if (pointerTypes) return pointerTypes.includes(e.pointerType);
		return true;
	};
	const handleEvent = (e) => {
		if (toValue(preventDefault)) e.preventDefault();
		if (toValue(stopPropagation)) e.stopPropagation();
	};
	const start = (e) => {
		var _a2;
		if (!toValue(buttons).includes(e.button)) return;
		if (toValue(options.disabled) || !filterEvent(e)) return;
		if (toValue(exact) && e.target !== toValue(target)) return;
		const container = toValue(containerElement);
		const containerRect = (_a2 = container == null ? void 0 : container.getBoundingClientRect) == null ? void 0 : _a2.call(container);
		const targetRect = toValue(target).getBoundingClientRect();
		const pos = {
			x: e.clientX - (container ? targetRect.left - containerRect.left + container.scrollLeft : targetRect.left),
			y: e.clientY - (container ? targetRect.top - containerRect.top + container.scrollTop : targetRect.top)
		};
		if ((onStart == null ? void 0 : onStart(pos, e)) === false) return;
		pressedDelta.value = pos;
		handleEvent(e);
	};
	const move = (e) => {
		if (toValue(options.disabled) || !filterEvent(e)) return;
		if (!pressedDelta.value) return;
		const container = toValue(containerElement);
		const targetRect = toValue(target).getBoundingClientRect();
		let { x, y } = position.value;
		if (axis === "x" || axis === "both") {
			x = e.clientX - pressedDelta.value.x;
			if (container) x = Math.min(Math.max(0, x), container.scrollWidth - targetRect.width);
		}
		if (axis === "y" || axis === "both") {
			y = e.clientY - pressedDelta.value.y;
			if (container) y = Math.min(Math.max(0, y), container.scrollHeight - targetRect.height);
		}
		position.value = {
			x,
			y
		};
		onMove == null ? void 0 : onMove(position.value, e);
		handleEvent(e);
	};
	const end = (e) => {
		if (toValue(options.disabled) || !filterEvent(e)) return;
		if (!pressedDelta.value) return;
		pressedDelta.value = void 0;
		onEnd == null ? void 0 : onEnd(position.value, e);
		handleEvent(e);
	};
	if (isClient) {
		const config = () => {
			var _a2;
			return {
				capture: (_a2 = options.capture) != null ? _a2 : true,
				passive: !toValue(preventDefault)
			};
		};
		useEventListener(draggingHandle, "pointerdown", start, config);
		useEventListener(draggingElement, "pointermove", move, config);
		useEventListener(draggingElement, "pointerup", end, config);
	}
	return {
		...toRefs(position),
		position,
		isDragging: computed(() => !!pressedDelta.value),
		style: computed(() => `left:${position.value.x}px;top:${position.value.y}px;`)
	};
}
function useDropZone(target, options = {}) {
	var _a, _b;
	const isOverDropZone = shallowRef(false);
	const files = shallowRef(null);
	let counter = 0;
	let isValid = true;
	if (isClient) {
		const _options = typeof options === "function" ? { onDrop: options } : options;
		const multiple = (_a = _options.multiple) != null ? _a : true;
		const preventDefaultForUnhandled = (_b = _options.preventDefaultForUnhandled) != null ? _b : false;
		const getFiles = (event) => {
			var _a2, _b2;
			const list = Array.from((_b2 = (_a2 = event.dataTransfer) == null ? void 0 : _a2.files) != null ? _b2 : []);
			return list.length === 0 ? null : multiple ? list : [list[0]];
		};
		const checkDataTypes = (types) => {
			const dataTypes = unref(_options.dataTypes);
			if (typeof dataTypes === "function") return dataTypes(types);
			if (!(dataTypes == null ? void 0 : dataTypes.length)) return true;
			if (types.length === 0) return false;
			return types.every((type) => dataTypes.some((allowedType) => type.includes(allowedType)));
		};
		const checkValidity = (items) => {
			const types = Array.from(items != null ? items : []).map((item) => item.type);
			const dataTypesValid = checkDataTypes(types);
			const multipleFilesValid = multiple || items.length <= 1;
			return dataTypesValid && multipleFilesValid;
		};
		const isSafari = () => /^(?:(?!chrome|android).)*safari/i.test(navigator.userAgent) && !("chrome" in window);
		const handleDragEvent = (event, eventType) => {
			var _a2, _b2, _c, _d, _e, _f;
			const dataTransferItemList = (_a2 = event.dataTransfer) == null ? void 0 : _a2.items;
			isValid = (_b2 = dataTransferItemList && checkValidity(dataTransferItemList)) != null ? _b2 : false;
			if (preventDefaultForUnhandled) {
				event.preventDefault();
			}
			if (!isSafari() && !isValid) {
				if (event.dataTransfer) {
					event.dataTransfer.dropEffect = "none";
				}
				return;
			}
			event.preventDefault();
			if (event.dataTransfer) {
				event.dataTransfer.dropEffect = "copy";
			}
			const currentFiles = getFiles(event);
			switch (eventType) {
				case "enter":
					counter += 1;
					isOverDropZone.value = true;
					(_c = _options.onEnter) == null ? void 0 : _c.call(_options, null, event);
					break;
				case "over":
					(_d = _options.onOver) == null ? void 0 : _d.call(_options, null, event);
					break;
				case "leave":
					counter -= 1;
					if (counter === 0) isOverDropZone.value = false;
					(_e = _options.onLeave) == null ? void 0 : _e.call(_options, null, event);
					break;
				case "drop":
					counter = 0;
					isOverDropZone.value = false;
					if (isValid) {
						files.value = currentFiles;
						(_f = _options.onDrop) == null ? void 0 : _f.call(_options, currentFiles, event);
					}
					break;
			}
		};
		useEventListener(target, "dragenter", (event) => handleDragEvent(event, "enter"));
		useEventListener(target, "dragover", (event) => handleDragEvent(event, "over"));
		useEventListener(target, "dragleave", (event) => handleDragEvent(event, "leave"));
		useEventListener(target, "drop", (event) => handleDragEvent(event, "drop"));
	}
	return {
		files,
		isOverDropZone
	};
}
function useResizeObserver(target, callback, options = {}) {
	const { window = defaultWindow, ...observerOptions } = options;
	let observer;
	const isSupported = useSupported(() => window && "ResizeObserver" in window);
	const cleanup = () => {
		if (observer) {
			observer.disconnect();
			observer = void 0;
		}
	};
	const targets = computed(() => {
		const _targets = toValue(target);
		return Array.isArray(_targets) ? _targets.map((el) => unrefElement(el)) : [unrefElement(_targets)];
	});
	const stopWatch = watch(targets, (els) => {
		cleanup();
		if (isSupported.value && window) {
			observer = new ResizeObserver(callback);
			for (const _el of els) {
				if (_el) observer.observe(_el, observerOptions);
			}
		}
	}, {
		immediate: true,
		flush: "post"
	});
	const stop = () => {
		cleanup();
		stopWatch();
	};
	tryOnScopeDispose(stop);
	return {
		isSupported,
		stop
	};
}
function useElementBounding(target, options = {}) {
	const { reset = true, windowResize = true, windowScroll = true, immediate = true, updateTiming = "sync" } = options;
	const height = shallowRef(0);
	const bottom = shallowRef(0);
	const left = shallowRef(0);
	const right = shallowRef(0);
	const top = shallowRef(0);
	const width = shallowRef(0);
	const x = shallowRef(0);
	const y = shallowRef(0);
	function recalculate() {
		const el = unrefElement(target);
		if (!el) {
			if (reset) {
				height.value = 0;
				bottom.value = 0;
				left.value = 0;
				right.value = 0;
				top.value = 0;
				width.value = 0;
				x.value = 0;
				y.value = 0;
			}
			return;
		}
		const rect = el.getBoundingClientRect();
		height.value = rect.height;
		bottom.value = rect.bottom;
		left.value = rect.left;
		right.value = rect.right;
		top.value = rect.top;
		width.value = rect.width;
		x.value = rect.x;
		y.value = rect.y;
	}
	function update() {
		if (updateTiming === "sync") recalculate();
		else if (updateTiming === "next-frame") requestAnimationFrame(() => recalculate());
	}
	useResizeObserver(target, update);
	watch(() => unrefElement(target), (ele) => !ele && update());
	useMutationObserver(target, update, { attributeFilter: ["style", "class"] });
	if (windowScroll) useEventListener("scroll", update, {
		capture: true,
		passive: true
	});
	if (windowResize) useEventListener("resize", update, { passive: true });
	tryOnMounted(() => {
		if (immediate) update();
	});
	return {
		height,
		bottom,
		left,
		right,
		top,
		width,
		x,
		y,
		update
	};
}
function useElementByPoint(options) {
	const { x, y, document = defaultDocument, multiple, interval = "requestAnimationFrame", immediate = true } = options;
	const isSupported = useSupported(() => {
		if (toValue(multiple)) return document && "elementsFromPoint" in document;
		return document && "elementFromPoint" in document;
	});
	const element = shallowRef(null);
	const cb = () => {
		var _a, _b;
		element.value = toValue(multiple) ? (_a = document == null ? void 0 : document.elementsFromPoint(toValue(x), toValue(y))) != null ? _a : [] : (_b = document == null ? void 0 : document.elementFromPoint(toValue(x), toValue(y))) != null ? _b : null;
	};
	const controls = interval === "requestAnimationFrame" ? useRafFn(cb, { immediate }) : useIntervalFn(cb, interval, { immediate });
	return {
		isSupported,
		element,
		...controls
	};
}
function useElementHover(el, options = {}) {
	const { delayEnter = 0, delayLeave = 0, triggerOnRemoval = false, window = defaultWindow } = options;
	const isHovered = shallowRef(false);
	let timer;
	const toggle = (entering) => {
		const delay = entering ? delayEnter : delayLeave;
		if (timer) {
			clearTimeout(timer);
			timer = void 0;
		}
		if (delay) timer = setTimeout(() => isHovered.value = entering, delay);
		else isHovered.value = entering;
	};
	if (!window) return isHovered;
	useEventListener(el, "mouseenter", () => toggle(true), { passive: true });
	useEventListener(el, "mouseleave", () => toggle(false), { passive: true });
	if (triggerOnRemoval) {
		onElementRemoval(computed(() => unrefElement(el)), () => toggle(false));
	}
	return isHovered;
}
function useElementSize(target, initialSize = {
	width: 0,
	height: 0
}, options = {}) {
	const { window = defaultWindow, box = "content-box" } = options;
	const isSVG = computed(() => {
		var _a, _b;
		return (_b = (_a = unrefElement(target)) == null ? void 0 : _a.namespaceURI) == null ? void 0 : _b.includes("svg");
	});
	const width = shallowRef(initialSize.width);
	const height = shallowRef(initialSize.height);
	const { stop: stop1 } = useResizeObserver(target, ([entry]) => {
		const boxSize = box === "border-box" ? entry.borderBoxSize : box === "content-box" ? entry.contentBoxSize : entry.devicePixelContentBoxSize;
		if (window && isSVG.value) {
			const $elem = unrefElement(target);
			if ($elem) {
				const rect = $elem.getBoundingClientRect();
				width.value = rect.width;
				height.value = rect.height;
			}
		} else {
			if (boxSize) {
				const formatBoxSize = toArray(boxSize);
				width.value = formatBoxSize.reduce((acc, { inlineSize }) => acc + inlineSize, 0);
				height.value = formatBoxSize.reduce((acc, { blockSize }) => acc + blockSize, 0);
			} else {
				width.value = entry.contentRect.width;
				height.value = entry.contentRect.height;
			}
		}
	}, options);
	tryOnMounted(() => {
		const ele = unrefElement(target);
		if (ele) {
			width.value = "offsetWidth" in ele ? ele.offsetWidth : initialSize.width;
			height.value = "offsetHeight" in ele ? ele.offsetHeight : initialSize.height;
		}
	});
	const stop2 = watch(() => unrefElement(target), (ele) => {
		width.value = ele ? initialSize.width : 0;
		height.value = ele ? initialSize.height : 0;
	});
	function stop() {
		stop1();
		stop2();
	}
	return {
		width,
		height,
		stop
	};
}
function useIntersectionObserver(target, callback, options = {}) {
	const { root, rootMargin = "0px", threshold = 0, window = defaultWindow, immediate = true } = options;
	const isSupported = useSupported(() => window && "IntersectionObserver" in window);
	const targets = computed(() => {
		const _target = toValue(target);
		return toArray(_target).map(unrefElement).filter(notNullish);
	});
	let cleanup = noop;
	const isActive = shallowRef(immediate);
	const stopWatch = isSupported.value ? watch(() => [
		targets.value,
		unrefElement(root),
		isActive.value
	], ([targets2, root2]) => {
		cleanup();
		if (!isActive.value) return;
		if (!targets2.length) return;
		const observer = new IntersectionObserver(callback, {
			root: unrefElement(root2),
			rootMargin,
			threshold
		});
		targets2.forEach((el) => el && observer.observe(el));
		cleanup = () => {
			observer.disconnect();
			cleanup = noop;
		};
	}, {
		immediate,
		flush: "post"
	}) : noop;
	const stop = () => {
		cleanup();
		stopWatch();
		isActive.value = false;
	};
	tryOnScopeDispose(stop);
	return {
		isSupported,
		isActive,
		pause() {
			cleanup();
			isActive.value = false;
		},
		resume() {
			isActive.value = true;
		},
		stop
	};
}
function useElementVisibility(element, options = {}) {
	const { window = defaultWindow, scrollTarget, threshold = 0, rootMargin, once = false } = options;
	const elementIsVisible = shallowRef(false);
	const { stop } = useIntersectionObserver(element, (intersectionObserverEntries) => {
		let isIntersecting = elementIsVisible.value;
		let latestTime = 0;
		for (const entry of intersectionObserverEntries) {
			if (entry.time >= latestTime) {
				latestTime = entry.time;
				isIntersecting = entry.isIntersecting;
			}
		}
		elementIsVisible.value = isIntersecting;
		if (once) {
			watchOnce(elementIsVisible, () => {
				stop();
			});
		}
	}, {
		root: scrollTarget,
		window,
		threshold,
		rootMargin: toValue(rootMargin)
	});
	return elementIsVisible;
}
const events = /* @__PURE__ */ new Map();
// @__NO_SIDE_EFFECTS__
function useEventBus(key) {
	const scope = getCurrentScope();
	function on(listener) {
		var _a;
		const listeners = events.get(key) || /* @__PURE__ */ new Set();
		listeners.add(listener);
		events.set(key, listeners);
		const _off = () => off(listener);
		(_a = scope == null ? void 0 : scope.cleanups) == null ? void 0 : _a.push(_off);
		return _off;
	}
	function once(listener) {
		function _listener(...args) {
			off(_listener);
			listener(...args);
		}
		return on(_listener);
	}
	function off(listener) {
		const listeners = events.get(key);
		if (!listeners) return;
		listeners.delete(listener);
		if (!listeners.size) reset();
	}
	function reset() {
		events.delete(key);
	}
	function emit(event, payload) {
		var _a;
		(_a = events.get(key)) == null ? void 0 : _a.forEach((v) => v(event, payload));
	}
	return {
		on,
		once,
		off,
		emit,
		reset
	};
}
function resolveNestedOptions$1(options) {
	if (options === true) return {};
	return options;
}
function useEventSource(url, events = [], options = {}) {
	const event = shallowRef(null);
	const data = shallowRef(null);
	const status = shallowRef("CONNECTING");
	const eventSource = ref(null);
	const error = shallowRef(null);
	const urlRef = toRef(url);
	const lastEventId = shallowRef(null);
	let explicitlyClosed = false;
	let retried = 0;
	const { withCredentials = false, immediate = true, autoConnect = true, autoReconnect, serializer = { read: (v) => v } } = options;
	const close = () => {
		if (isClient && eventSource.value) {
			eventSource.value.close();
			eventSource.value = null;
			status.value = "CLOSED";
			explicitlyClosed = true;
		}
	};
	const _init = () => {
		if (explicitlyClosed || typeof urlRef.value === "undefined") return;
		const es = new EventSource(urlRef.value, { withCredentials });
		status.value = "CONNECTING";
		eventSource.value = es;
		es.onopen = () => {
			status.value = "OPEN";
			error.value = null;
		};
		es.onerror = (e) => {
			status.value = "CLOSED";
			error.value = e;
			if (es.readyState === 2 && !explicitlyClosed && autoReconnect) {
				es.close();
				const { retries = -1, delay = 1e3, onFailed } = resolveNestedOptions$1(autoReconnect);
				retried += 1;
				if (typeof retries === "number" && (retries < 0 || retried < retries)) setTimeout(_init, delay);
				else if (typeof retries === "function" && retries()) setTimeout(_init, delay);
				else onFailed == null ? void 0 : onFailed();
			}
		};
		es.onmessage = (e) => {
			var _a;
			event.value = null;
			data.value = (_a = serializer.read(e.data)) != null ? _a : null;
			lastEventId.value = e.lastEventId;
		};
		for (const event_name of events) {
			useEventListener(es, event_name, (e) => {
				var _a, _b;
				event.value = event_name;
				data.value = (_a = serializer.read(e.data)) != null ? _a : null;
				lastEventId.value = (_b = e.lastEventId) != null ? _b : null;
			}, { passive: true });
		}
	};
	const open = () => {
		if (!isClient) return;
		close();
		explicitlyClosed = false;
		retried = 0;
		_init();
	};
	if (immediate) open();
	if (autoConnect) watch(urlRef, open);
	tryOnScopeDispose(close);
	return {
		eventSource,
		event,
		data,
		status,
		error,
		open,
		close,
		lastEventId
	};
}
// @__NO_SIDE_EFFECTS__
function useEyeDropper(options = {}) {
	const { initialValue = "" } = options;
	const isSupported = useSupported(() => typeof window !== "undefined" && "EyeDropper" in window);
	const sRGBHex = shallowRef(initialValue);
	async function open(openOptions) {
		if (!isSupported.value) return;
		const eyeDropper = new window.EyeDropper();
		const result = await eyeDropper.open(openOptions);
		sRGBHex.value = result.sRGBHex;
		return result;
	}
	return {
		isSupported,
		sRGBHex,
		open
	};
}
function useFavicon(newIcon = null, options = {}) {
	const { baseUrl = "", rel = "icon", document = defaultDocument } = options;
	const favicon = toRef(newIcon);
	const applyIcon = (icon) => {
		const elements = document == null ? void 0 : document.head.querySelectorAll(`link[rel*="${rel}"]`);
		if (!elements || elements.length === 0) {
			const link = document == null ? void 0 : document.createElement("link");
			if (link) {
				link.rel = rel;
				link.href = `${baseUrl}${icon}`;
				link.type = `image/${icon.split(".").pop()}`;
				document == null ? void 0 : document.head.append(link);
			}
			return;
		}
		elements == null ? void 0 : elements.forEach((el) => el.href = `${baseUrl}${icon}`);
	};
	watch(favicon, (i, o) => {
		if (typeof i === "string" && i !== o) applyIcon(i);
	}, { immediate: true });
	return favicon;
}
const payloadMapping = {
	json: "application/json",
	text: "text/plain"
};
function isFetchOptions(obj) {
	return obj && containsProp(obj, "immediate", "refetch", "initialData", "timeout", "beforeFetch", "afterFetch", "onFetchError", "fetch", "updateDataOnError");
}
const reAbsolute = /^(?:[a-z][a-z\d+\-.]*:)?\/\//i;
function isAbsoluteURL(url) {
	return reAbsolute.test(url);
}
function headersToObject(headers) {
	if (typeof Headers !== "undefined" && headers instanceof Headers) return Object.fromEntries(headers.entries());
	return headers;
}
function combineCallbacks(combination, ...callbacks) {
	if (combination === "overwrite") {
		return async (ctx) => {
			let callback;
			for (let i = callbacks.length - 1; i >= 0; i--) {
				if (callbacks[i] != null) {
					callback = callbacks[i];
					break;
				}
			}
			if (callback) return {
				...ctx,
				...await callback(ctx)
			};
			return ctx;
		};
	} else {
		return async (ctx) => {
			for (const callback of callbacks) {
				if (callback) ctx = {
					...ctx,
					...await callback(ctx)
				};
			}
			return ctx;
		};
	}
}
function createFetch(config = {}) {
	const _combination = config.combination || "chain";
	const _options = config.options || {};
	const _fetchOptions = config.fetchOptions || {};
	function useFactoryFetch(url, ...args) {
		const computedUrl = computed(() => {
			const baseUrl = toValue(config.baseUrl);
			const targetUrl = toValue(url);
			return baseUrl && !isAbsoluteURL(targetUrl) ? joinPaths(baseUrl, targetUrl) : targetUrl;
		});
		let options = _options;
		let fetchOptions = _fetchOptions;
		if (args.length > 0) {
			if (isFetchOptions(args[0])) {
				options = {
					...options,
					...args[0],
					beforeFetch: combineCallbacks(_combination, _options.beforeFetch, args[0].beforeFetch),
					afterFetch: combineCallbacks(_combination, _options.afterFetch, args[0].afterFetch),
					onFetchError: combineCallbacks(_combination, _options.onFetchError, args[0].onFetchError)
				};
			} else {
				fetchOptions = {
					...fetchOptions,
					...args[0],
					headers: {
						...headersToObject(fetchOptions.headers) || {},
						...headersToObject(args[0].headers) || {}
					}
				};
			}
		}
		if (args.length > 1 && isFetchOptions(args[1])) {
			options = {
				...options,
				...args[1],
				beforeFetch: combineCallbacks(_combination, _options.beforeFetch, args[1].beforeFetch),
				afterFetch: combineCallbacks(_combination, _options.afterFetch, args[1].afterFetch),
				onFetchError: combineCallbacks(_combination, _options.onFetchError, args[1].onFetchError)
			};
		}
		return useFetch(computedUrl, fetchOptions, options);
	}
	return useFactoryFetch;
}
function useFetch(url, ...args) {
	var _a, _b;
	const supportsAbort = typeof AbortController === "function";
	let fetchOptions = {};
	let options = {
		immediate: true,
		refetch: false,
		timeout: 0,
		updateDataOnError: false
	};
	const config = {
		method: "GET",
		type: "text",
		payload: void 0
	};
	if (args.length > 0) {
		if (isFetchOptions(args[0])) options = {
			...options,
			...args[0]
		};
		else fetchOptions = args[0];
	}
	if (args.length > 1) {
		if (isFetchOptions(args[1])) options = {
			...options,
			...args[1]
		};
	}
	const { fetch = (_b = (_a = defaultWindow) == null ? void 0 : _a.fetch) != null ? _b : globalThis == null ? void 0 : globalThis.fetch, initialData, timeout } = options;
	const responseEvent = createEventHook();
	const errorEvent = createEventHook();
	const finallyEvent = createEventHook();
	const isFinished = shallowRef(false);
	const isFetching = shallowRef(false);
	const aborted = shallowRef(false);
	const statusCode = shallowRef(null);
	const response = shallowRef(null);
	const error = shallowRef(null);
	const data = shallowRef(initialData || null);
	const canAbort = computed(() => supportsAbort && isFetching.value);
	let controller;
	let timer;
	const abort = (reason) => {
		if (supportsAbort) {
			controller == null ? void 0 : controller.abort(reason);
			controller = new AbortController();
			controller.signal.onabort = () => aborted.value = true;
			fetchOptions = {
				...fetchOptions,
				signal: controller.signal
			};
		}
	};
	const loading = (isLoading) => {
		isFetching.value = isLoading;
		isFinished.value = !isLoading;
	};
	if (timeout) timer = useTimeoutFn(abort, timeout, { immediate: false });
	let executeCounter = 0;
	const execute = async (throwOnFailed = false) => {
		var _a2, _b2;
		abort();
		loading(true);
		error.value = null;
		statusCode.value = null;
		aborted.value = false;
		executeCounter += 1;
		const currentExecuteCounter = executeCounter;
		const defaultFetchOptions = {
			method: config.method,
			headers: {}
		};
		const payload = toValue(config.payload);
		if (payload) {
			const headers = headersToObject(defaultFetchOptions.headers);
			const proto = Object.getPrototypeOf(payload);
			if (!config.payloadType && payload && (proto === Object.prototype || Array.isArray(proto)) && !(payload instanceof FormData)) config.payloadType = "json";
			if (config.payloadType) headers["Content-Type"] = (_a2 = payloadMapping[config.payloadType]) != null ? _a2 : config.payloadType;
			defaultFetchOptions.body = config.payloadType === "json" ? JSON.stringify(payload) : payload;
		}
		let isCanceled = false;
		const context = {
			url: toValue(url),
			options: {
				...defaultFetchOptions,
				...fetchOptions
			},
			cancel: () => {
				isCanceled = true;
			}
		};
		if (options.beforeFetch) Object.assign(context, await options.beforeFetch(context));
		if (isCanceled || !fetch) {
			loading(false);
			return Promise.resolve(null);
		}
		let responseData = null;
		if (timer) timer.start();
		return fetch(context.url, {
			...defaultFetchOptions,
			...context.options,
			headers: {
				...headersToObject(defaultFetchOptions.headers),
				...headersToObject((_b2 = context.options) == null ? void 0 : _b2.headers)
			}
		}).then(async (fetchResponse) => {
			response.value = fetchResponse;
			statusCode.value = fetchResponse.status;
			responseData = await fetchResponse.clone()[config.type]();
			if (!fetchResponse.ok) {
				data.value = initialData || null;
				throw new Error(fetchResponse.statusText);
			}
			if (options.afterFetch) {
				({data: responseData} = await options.afterFetch({
					data: responseData,
					response: fetchResponse,
					context,
					execute
				}));
			}
			data.value = responseData;
			responseEvent.trigger(fetchResponse);
			return fetchResponse;
		}).catch(async (fetchError) => {
			let errorData = fetchError.message || fetchError.name;
			if (options.onFetchError) {
				({error: errorData, data: responseData} = await options.onFetchError({
					data: responseData,
					error: fetchError,
					response: response.value,
					context,
					execute
				}));
			}
			error.value = errorData;
			if (options.updateDataOnError) data.value = responseData;
			errorEvent.trigger(fetchError);
			if (throwOnFailed) throw fetchError;
			return null;
		}).finally(() => {
			if (currentExecuteCounter === executeCounter) loading(false);
			if (timer) timer.stop();
			finallyEvent.trigger(null);
		});
	};
	const refetch = toRef(options.refetch);
	watch([refetch, toRef(url)], ([refetch2]) => refetch2 && execute(), { deep: true });
	const shell = {
		isFinished: readonly(isFinished),
		isFetching: readonly(isFetching),
		statusCode,
		response,
		error,
		data,
		canAbort,
		aborted,
		abort,
		execute,
		onFetchResponse: responseEvent.on,
		onFetchError: errorEvent.on,
		onFetchFinally: finallyEvent.on,
		// method
		get: setMethod("GET"),
		put: setMethod("PUT"),
		post: setMethod("POST"),
		delete: setMethod("DELETE"),
		patch: setMethod("PATCH"),
		head: setMethod("HEAD"),
		options: setMethod("OPTIONS"),
		// type
		json: setType("json"),
		text: setType("text"),
		blob: setType("blob"),
		arrayBuffer: setType("arrayBuffer"),
		formData: setType("formData")
	};
	function setMethod(method) {
		return (payload, payloadType) => {
			if (!isFetching.value) {
				config.method = method;
				config.payload = payload;
				config.payloadType = payloadType;
				if (isRef(config.payload)) {
					watch([refetch, toRef(config.payload)], ([refetch2]) => refetch2 && execute(), { deep: true });
				}
				return {
					...shell,
					then(onFulfilled, onRejected) {
						return waitUntilFinished().then(onFulfilled, onRejected);
					}
				};
			}
			return void 0;
		};
	}
	function waitUntilFinished() {
		return new Promise((resolve, reject) => {
			until(isFinished).toBe(true).then(() => resolve(shell)).catch(reject);
		});
	}
	function setType(type) {
		return () => {
			if (!isFetching.value) {
				config.type = type;
				return {
					...shell,
					then(onFulfilled, onRejected) {
						return waitUntilFinished().then(onFulfilled, onRejected);
					}
				};
			}
			return void 0;
		};
	}
	if (options.immediate) Promise.resolve().then(() => execute());
	return {
		...shell,
		then(onFulfilled, onRejected) {
			return waitUntilFinished().then(onFulfilled, onRejected);
		}
	};
}
function joinPaths(start, end) {
	if (!start.endsWith("/") && !end.startsWith("/")) {
		return `${start}/${end}`;
	}
	if (start.endsWith("/") && end.startsWith("/")) {
		return `${start.slice(0, -1)}${end}`;
	}
	return `${start}${end}`;
}
const DEFAULT_OPTIONS = {
	multiple: true,
	accept: "*",
	reset: false,
	directory: false
};
function prepareInitialFiles(files) {
	if (!files) return null;
	if (files instanceof FileList) return files;
	const dt = new DataTransfer();
	for (const file of files) {
		dt.items.add(file);
	}
	return dt.files;
}
function useFileDialog(options = {}) {
	const { document = defaultDocument } = options;
	const files = ref(prepareInitialFiles(options.initialFiles));
	const { on: onChange, trigger: changeTrigger } = createEventHook();
	const { on: onCancel, trigger: cancelTrigger } = createEventHook();
	const inputRef = computed(() => {
		var _a;
		const input = (_a = unrefElement(options.input)) != null ? _a : document ? document.createElement("input") : void 0;
		if (input) {
			input.type = "file";
			input.onchange = (event) => {
				const result = event.target;
				files.value = result.files;
				changeTrigger(files.value);
			};
			input.oncancel = () => {
				cancelTrigger();
			};
		}
		return input;
	});
	const reset = () => {
		files.value = null;
		if (inputRef.value && inputRef.value.value) {
			inputRef.value.value = "";
			changeTrigger(null);
		}
	};
	const applyOptions = (options2) => {
		const el = inputRef.value;
		if (!el) return;
		el.multiple = toValue(options2.multiple);
		el.accept = toValue(options2.accept);
		el.webkitdirectory = toValue(options2.directory);
		if (hasOwn(options2, "capture")) el.capture = toValue(options2.capture);
	};
	const open = (localOptions) => {
		const el = inputRef.value;
		if (!el) return;
		const mergedOptions = {
			...DEFAULT_OPTIONS,
			...options,
			...localOptions
		};
		applyOptions(mergedOptions);
		if (toValue(mergedOptions.reset)) reset();
		el.click();
	};
	watchEffect(() => {
		applyOptions(options);
	});
	return {
		files: readonly(files),
		open,
		reset,
		onCancel,
		onChange
	};
}
function useFileSystemAccess(options = {}) {
	const { window: _window = defaultWindow, dataType = "Text" } = options;
	const window = _window;
	const isSupported = useSupported(() => window && "showSaveFilePicker" in window && "showOpenFilePicker" in window);
	const fileHandle = shallowRef();
	const data = shallowRef();
	const file = shallowRef();
	const fileName = computed(() => {
		var _a, _b;
		return (_b = (_a = file.value) == null ? void 0 : _a.name) != null ? _b : "";
	});
	const fileMIME = computed(() => {
		var _a, _b;
		return (_b = (_a = file.value) == null ? void 0 : _a.type) != null ? _b : "";
	});
	const fileSize = computed(() => {
		var _a, _b;
		return (_b = (_a = file.value) == null ? void 0 : _a.size) != null ? _b : 0;
	});
	const fileLastModified = computed(() => {
		var _a, _b;
		return (_b = (_a = file.value) == null ? void 0 : _a.lastModified) != null ? _b : 0;
	});
	async function open(_options = {}) {
		if (!isSupported.value) return;
		const [handle] = await window.showOpenFilePicker({
			...toValue(options),
			..._options
		});
		fileHandle.value = handle;
		await updateData();
	}
	async function create(_options = {}) {
		if (!isSupported.value) return;
		fileHandle.value = await window.showSaveFilePicker({
			...options,
			..._options
		});
		data.value = void 0;
		await updateData();
	}
	async function save(_options = {}) {
		if (!isSupported.value) return;
		if (!fileHandle.value) return saveAs(_options);
		if (data.value) {
			const writableStream = await fileHandle.value.createWritable();
			await writableStream.write(data.value);
			await writableStream.close();
		}
		await updateFile();
	}
	async function saveAs(_options = {}) {
		if (!isSupported.value) return;
		fileHandle.value = await window.showSaveFilePicker({
			...options,
			..._options
		});
		if (data.value) {
			const writableStream = await fileHandle.value.createWritable();
			await writableStream.write(data.value);
			await writableStream.close();
		}
		await updateFile();
	}
	async function updateFile() {
		var _a;
		file.value = await ((_a = fileHandle.value) == null ? void 0 : _a.getFile());
	}
	async function updateData() {
		var _a, _b;
		await updateFile();
		const type = toValue(dataType);
		if (type === "Text") data.value = await ((_a = file.value) == null ? void 0 : _a.text());
		else if (type === "ArrayBuffer") data.value = await ((_b = file.value) == null ? void 0 : _b.arrayBuffer());
		else if (type === "Blob") data.value = file.value;
	}
	watch(() => toValue(dataType), updateData);
	return {
		isSupported,
		data,
		file,
		fileName,
		fileMIME,
		fileSize,
		fileLastModified,
		open,
		create,
		save,
		saveAs,
		updateData
	};
}
function useFocus(target, options = {}) {
	const { initialValue = false, focusVisible = false, preventScroll = false } = options;
	const innerFocused = shallowRef(false);
	const targetElement = computed(() => unrefElement(target));
	const listenerOptions = { passive: true };
	useEventListener(targetElement, "focus", (event) => {
		var _a, _b;
		if (!focusVisible || ((_b = (_a = event.target).matches) == null ? void 0 : _b.call(_a, ":focus-visible"))) innerFocused.value = true;
	}, listenerOptions);
	useEventListener(targetElement, "blur", () => innerFocused.value = false, listenerOptions);
	const focused = computed({
		get: () => innerFocused.value,
		set(value) {
			var _a, _b;
			if (!value && innerFocused.value) (_a = targetElement.value) == null ? void 0 : _a.blur();
			else if (value && !innerFocused.value) (_b = targetElement.value) == null ? void 0 : _b.focus({ preventScroll });
		}
	});
	watch(targetElement, () => {
		focused.value = initialValue;
	}, {
		immediate: true,
		flush: "post"
	});
	return { focused };
}
const EVENT_FOCUS_IN = "focusin";
const EVENT_FOCUS_OUT = "focusout";
const PSEUDO_CLASS_FOCUS_WITHIN = ":focus-within";
function useFocusWithin(target, options = {}) {
	const { window = defaultWindow } = options;
	const targetElement = computed(() => unrefElement(target));
	const _focused = shallowRef(false);
	const focused = computed(() => _focused.value);
	const activeElement = useActiveElement(options);
	if (!window || !activeElement.value) {
		return { focused };
	}
	const listenerOptions = { passive: true };
	useEventListener(targetElement, EVENT_FOCUS_IN, () => _focused.value = true, listenerOptions);
	useEventListener(targetElement, EVENT_FOCUS_OUT, () => {
		var _a, _b, _c;
		return _focused.value = (_c = (_b = (_a = targetElement.value) == null ? void 0 : _a.matches) == null ? void 0 : _b.call(_a, PSEUDO_CLASS_FOCUS_WITHIN)) != null ? _c : false;
	}, listenerOptions);
	return { focused };
}
// @__NO_SIDE_EFFECTS__
function useFps(options) {
	var _a;
	const fps = shallowRef(0);
	if (typeof performance === "undefined") return fps;
	const every = (_a = options == null ? void 0 : options.every) != null ? _a : 10;
	let last = performance.now();
	let ticks = 0;
	useRafFn(() => {
		ticks += 1;
		if (ticks >= every) {
			const now = performance.now();
			const diff = now - last;
			fps.value = Math.round(1e3 / (diff / ticks));
			last = now;
			ticks = 0;
		}
	});
	return fps;
}
const eventHandlers = [
	"fullscreenchange",
	"webkitfullscreenchange",
	"webkitendfullscreen",
	"mozfullscreenchange",
	"MSFullscreenChange"
];
function useFullscreen(target, options = {}) {
	const { document = defaultDocument, autoExit = false } = options;
	const targetRef = computed(() => {
		var _a;
		return (_a = unrefElement(target)) != null ? _a : document == null ? void 0 : document.documentElement;
	});
	const isFullscreen = shallowRef(false);
	const requestMethod = computed(() => {
		return [
			"requestFullscreen",
			"webkitRequestFullscreen",
			"webkitEnterFullscreen",
			"webkitEnterFullScreen",
			"webkitRequestFullScreen",
			"mozRequestFullScreen",
			"msRequestFullscreen"
		].find((m) => document && m in document || targetRef.value && m in targetRef.value);
	});
	const exitMethod = computed(() => {
		return [
			"exitFullscreen",
			"webkitExitFullscreen",
			"webkitExitFullScreen",
			"webkitCancelFullScreen",
			"mozCancelFullScreen",
			"msExitFullscreen"
		].find((m) => document && m in document || targetRef.value && m in targetRef.value);
	});
	const fullscreenEnabled = computed(() => {
		return [
			"fullScreen",
			"webkitIsFullScreen",
			"webkitDisplayingFullscreen",
			"mozFullScreen",
			"msFullscreenElement"
		].find((m) => document && m in document || targetRef.value && m in targetRef.value);
	});
	const fullscreenElementMethod = [
		"fullscreenElement",
		"webkitFullscreenElement",
		"mozFullScreenElement",
		"msFullscreenElement"
	].find((m) => document && m in document);
	const isSupported = useSupported(() => targetRef.value && document && requestMethod.value !== void 0 && exitMethod.value !== void 0 && fullscreenEnabled.value !== void 0);
	const isCurrentElementFullScreen = () => {
		if (fullscreenElementMethod) return (document == null ? void 0 : document[fullscreenElementMethod]) === targetRef.value;
		return false;
	};
	const isElementFullScreen = () => {
		if (fullscreenEnabled.value) {
			if (document && document[fullscreenEnabled.value] != null) {
				return document[fullscreenEnabled.value];
			} else {
				const target2 = targetRef.value;
				if ((target2 == null ? void 0 : target2[fullscreenEnabled.value]) != null) {
					return Boolean(target2[fullscreenEnabled.value]);
				}
			}
		}
		return false;
	};
	async function exit() {
		if (!isSupported.value || !isFullscreen.value) return;
		if (exitMethod.value) {
			if ((document == null ? void 0 : document[exitMethod.value]) != null) {
				await document[exitMethod.value]();
			} else {
				const target2 = targetRef.value;
				if ((target2 == null ? void 0 : target2[exitMethod.value]) != null) await target2[exitMethod.value]();
			}
		}
		isFullscreen.value = false;
	}
	async function enter() {
		if (!isSupported.value || isFullscreen.value) return;
		if (isElementFullScreen()) await exit();
		const target2 = targetRef.value;
		if (requestMethod.value && (target2 == null ? void 0 : target2[requestMethod.value]) != null) {
			await target2[requestMethod.value]();
			isFullscreen.value = true;
		}
	}
	async function toggle() {
		await (isFullscreen.value ? exit() : enter());
	}
	const handlerCallback = () => {
		const isElementFullScreenValue = isElementFullScreen();
		if (!isElementFullScreenValue || isElementFullScreenValue && isCurrentElementFullScreen()) isFullscreen.value = isElementFullScreenValue;
	};
	const listenerOptions = {
		capture: false,
		passive: true
	};
	useEventListener(document, eventHandlers, handlerCallback, listenerOptions);
	useEventListener(() => unrefElement(targetRef), eventHandlers, handlerCallback, listenerOptions);
	tryOnMounted(handlerCallback, false);
	if (autoExit) tryOnScopeDispose(exit);
	return {
		isSupported,
		isFullscreen,
		enter,
		exit,
		toggle
	};
}
function mapGamepadToXbox360Controller(gamepad) {
	return computed(() => {
		if (gamepad.value) {
			return {
				buttons: {
					a: gamepad.value.buttons[0],
					b: gamepad.value.buttons[1],
					x: gamepad.value.buttons[2],
					y: gamepad.value.buttons[3]
				},
				bumper: {
					left: gamepad.value.buttons[4],
					right: gamepad.value.buttons[5]
				},
				triggers: {
					left: gamepad.value.buttons[6],
					right: gamepad.value.buttons[7]
				},
				stick: {
					left: {
						horizontal: gamepad.value.axes[0],
						vertical: gamepad.value.axes[1],
						button: gamepad.value.buttons[10]
					},
					right: {
						horizontal: gamepad.value.axes[2],
						vertical: gamepad.value.axes[3],
						button: gamepad.value.buttons[11]
					}
				},
				dpad: {
					up: gamepad.value.buttons[12],
					down: gamepad.value.buttons[13],
					left: gamepad.value.buttons[14],
					right: gamepad.value.buttons[15]
				},
				back: gamepad.value.buttons[8],
				start: gamepad.value.buttons[9]
			};
		}
		return null;
	});
}
// @__NO_SIDE_EFFECTS__
function useGamepad(options = {}) {
	const { navigator = defaultNavigator } = options;
	const isSupported = useSupported(() => navigator && "getGamepads" in navigator);
	const gamepads = ref([]);
	const onConnectedHook = createEventHook();
	const onDisconnectedHook = createEventHook();
	const stateFromGamepad = (gamepad) => {
		const hapticActuators = [];
		const vibrationActuator = "vibrationActuator" in gamepad ? gamepad.vibrationActuator : null;
		if (vibrationActuator) hapticActuators.push(vibrationActuator);
		if (gamepad.hapticActuators) hapticActuators.push(...gamepad.hapticActuators);
		return {
			id: gamepad.id,
			index: gamepad.index,
			connected: gamepad.connected,
			mapping: gamepad.mapping,
			timestamp: gamepad.timestamp,
			vibrationActuator: gamepad.vibrationActuator,
			hapticActuators,
			axes: gamepad.axes.map((axes) => axes),
			buttons: gamepad.buttons.map((button) => ({
				pressed: button.pressed,
				touched: button.touched,
				value: button.value
			}))
		};
	};
	const updateGamepadState = () => {
		const _gamepads = (navigator == null ? void 0 : navigator.getGamepads()) || [];
		for (const gamepad of _gamepads) {
			if (gamepad && gamepads.value[gamepad.index]) gamepads.value[gamepad.index] = stateFromGamepad(gamepad);
		}
	};
	const { isActive, pause, resume } = useRafFn(updateGamepadState);
	const onGamepadConnected = (gamepad) => {
		if (!gamepads.value.some(({ index }) => index === gamepad.index)) {
			gamepads.value.push(stateFromGamepad(gamepad));
			onConnectedHook.trigger(gamepad.index);
		}
		resume();
	};
	const onGamepadDisconnected = (gamepad) => {
		gamepads.value = gamepads.value.filter((x) => x.index !== gamepad.index);
		onDisconnectedHook.trigger(gamepad.index);
	};
	const listenerOptions = { passive: true };
	useEventListener("gamepadconnected", (e) => onGamepadConnected(e.gamepad), listenerOptions);
	useEventListener("gamepaddisconnected", (e) => onGamepadDisconnected(e.gamepad), listenerOptions);
	tryOnMounted(() => {
		const _gamepads = (navigator == null ? void 0 : navigator.getGamepads()) || [];
		for (const gamepad of _gamepads) {
			if (gamepad && gamepads.value[gamepad.index]) onGamepadConnected(gamepad);
		}
	});
	pause();
	return {
		isSupported,
		onConnected: onConnectedHook.on,
		onDisconnected: onDisconnectedHook.on,
		gamepads,
		pause,
		resume,
		isActive
	};
}
function useGeolocation(options = {}) {
	const { enableHighAccuracy = true, maximumAge = 3e4, timeout = 27e3, navigator = defaultNavigator, immediate = true } = options;
	const isSupported = useSupported(() => navigator && "geolocation" in navigator);
	const locatedAt = shallowRef(null);
	const error = shallowRef(null);
	const coords = ref({
		accuracy: 0,
		latitude: Number.POSITIVE_INFINITY,
		longitude: Number.POSITIVE_INFINITY,
		altitude: null,
		altitudeAccuracy: null,
		heading: null,
		speed: null
	});
	function updatePosition(position) {
		locatedAt.value = position.timestamp;
		coords.value = position.coords;
		error.value = null;
	}
	let watcher;
	function resume() {
		if (isSupported.value) {
			watcher = navigator.geolocation.watchPosition(updatePosition, (err) => error.value = err, {
				enableHighAccuracy,
				maximumAge,
				timeout
			});
		}
	}
	if (immediate) resume();
	function pause() {
		if (watcher && navigator) navigator.geolocation.clearWatch(watcher);
	}
	tryOnScopeDispose(() => {
		pause();
	});
	return {
		isSupported,
		coords,
		locatedAt,
		error,
		resume,
		pause
	};
}
const defaultEvents$1 = [
	"mousemove",
	"mousedown",
	"resize",
	"keydown",
	"touchstart",
	"wheel"
];
const oneMinute = 6e4;
function useIdle(timeout = oneMinute, options = {}) {
	const { initialState = false, listenForVisibilityChange = true, events = defaultEvents$1, window = defaultWindow, eventFilter = throttleFilter(50) } = options;
	const idle = shallowRef(initialState);
	const lastActive = shallowRef(timestamp());
	let timer;
	const reset = () => {
		idle.value = false;
		clearTimeout(timer);
		timer = setTimeout(() => idle.value = true, timeout);
	};
	const onEvent = createFilterWrapper(eventFilter, () => {
		lastActive.value = timestamp();
		reset();
	});
	if (window) {
		const document = window.document;
		const listenerOptions = { passive: true };
		for (const event of events) useEventListener(window, event, onEvent, listenerOptions);
		if (listenForVisibilityChange) {
			useEventListener(document, "visibilitychange", () => {
				if (!document.hidden) onEvent();
			}, listenerOptions);
		}
		if (!initialState) reset();
	}
	return {
		idle,
		lastActive,
		reset
	};
}
async function loadImage(options) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		const { src, srcset, sizes, class: clazz, loading, crossorigin, referrerPolicy, width, height, decoding, fetchPriority, ismap, usemap } = options;
		img.src = src;
		if (srcset != null) img.srcset = srcset;
		if (sizes != null) img.sizes = sizes;
		if (clazz != null) img.className = clazz;
		if (loading != null) img.loading = loading;
		if (crossorigin != null) img.crossOrigin = crossorigin;
		if (referrerPolicy != null) img.referrerPolicy = referrerPolicy;
		if (width != null) img.width = width;
		if (height != null) img.height = height;
		if (decoding != null) img.decoding = decoding;
		if (fetchPriority != null) img.fetchPriority = fetchPriority;
		if (ismap != null) img.isMap = ismap;
		if (usemap != null) img.useMap = usemap;
		img.onload = () => resolve(img);
		img.onerror = reject;
	});
}
function useImage(options, asyncStateOptions = {}) {
	const state = useAsyncState(() => loadImage(toValue(options)), void 0, {
		resetOnExecute: true,
		...asyncStateOptions
	});
	watch(() => toValue(options), () => state.execute(asyncStateOptions.delay), { deep: true });
	return state;
}
function resolveElement(el) {
	if (typeof Window !== "undefined" && el instanceof Window) return el.document.documentElement;
	if (typeof Document !== "undefined" && el instanceof Document) return el.documentElement;
	return el;
}
const ARRIVED_STATE_THRESHOLD_PIXELS = 1;
function useScroll(element, options = {}) {
	const { throttle = 0, idle = 200, onStop = noop, onScroll = noop, offset = {
		left: 0,
		right: 0,
		top: 0,
		bottom: 0
	}, observe: _observe = { mutation: false }, eventListenerOptions = {
		capture: false,
		passive: true
	}, behavior = "auto", window = defaultWindow, onError = (e) => {
		console.error(e);
	} } = options;
	const observe = typeof _observe === "boolean" ? { mutation: _observe } : _observe;
	const internalX = shallowRef(0);
	const internalY = shallowRef(0);
	const x = computed({
		get() {
			return internalX.value;
		},
		set(x2) {
			scrollTo(x2, void 0);
		}
	});
	const y = computed({
		get() {
			return internalY.value;
		},
		set(y2) {
			scrollTo(void 0, y2);
		}
	});
	function scrollTo(_x, _y) {
		var _a, _b, _c, _d;
		if (!window) return;
		const _element = toValue(element);
		if (!_element) return;
		(_c = _element instanceof Document ? window.document.body : _element) == null ? void 0 : _c.scrollTo({
			top: (_a = toValue(_y)) != null ? _a : y.value,
			left: (_b = toValue(_x)) != null ? _b : x.value,
			behavior: toValue(behavior)
		});
		const scrollContainer = ((_d = _element == null ? void 0 : _element.document) == null ? void 0 : _d.documentElement) || (_element == null ? void 0 : _element.documentElement) || _element;
		if (x != null) internalX.value = scrollContainer.scrollLeft;
		if (y != null) internalY.value = scrollContainer.scrollTop;
	}
	const isScrolling = shallowRef(false);
	const arrivedState = reactive({
		left: true,
		right: false,
		top: true,
		bottom: false
	});
	const directions = reactive({
		left: false,
		right: false,
		top: false,
		bottom: false
	});
	const onScrollEnd = (e) => {
		if (!isScrolling.value) return;
		isScrolling.value = false;
		directions.left = false;
		directions.right = false;
		directions.top = false;
		directions.bottom = false;
		onStop(e);
	};
	const onScrollEndDebounced = useDebounceFn(onScrollEnd, throttle + idle);
	const setArrivedState = (target) => {
		var _a;
		if (!window) return;
		const el = ((_a = target == null ? void 0 : target.document) == null ? void 0 : _a.documentElement) || (target == null ? void 0 : target.documentElement) || unrefElement(target);
		const { display, flexDirection, direction } = getComputedStyle(el);
		const directionMultipler = direction === "rtl" ? -1 : 1;
		const scrollLeft = el.scrollLeft;
		directions.left = scrollLeft < internalX.value;
		directions.right = scrollLeft > internalX.value;
		const left = Math.abs(scrollLeft * directionMultipler) <= (offset.left || 0);
		const right = Math.abs(scrollLeft * directionMultipler) + el.clientWidth >= el.scrollWidth - (offset.right || 0) - ARRIVED_STATE_THRESHOLD_PIXELS;
		if (display === "flex" && flexDirection === "row-reverse") {
			arrivedState.left = right;
			arrivedState.right = left;
		} else {
			arrivedState.left = left;
			arrivedState.right = right;
		}
		internalX.value = scrollLeft;
		let scrollTop = el.scrollTop;
		if (target === window.document && !scrollTop) scrollTop = window.document.body.scrollTop;
		directions.top = scrollTop < internalY.value;
		directions.bottom = scrollTop > internalY.value;
		const top = Math.abs(scrollTop) <= (offset.top || 0);
		const bottom = Math.abs(scrollTop) + el.clientHeight >= el.scrollHeight - (offset.bottom || 0) - ARRIVED_STATE_THRESHOLD_PIXELS;
		if (display === "flex" && flexDirection === "column-reverse") {
			arrivedState.top = bottom;
			arrivedState.bottom = top;
		} else {
			arrivedState.top = top;
			arrivedState.bottom = bottom;
		}
		internalY.value = scrollTop;
	};
	const onScrollHandler = (e) => {
		var _a;
		if (!window) return;
		const eventTarget = (_a = e.target.documentElement) != null ? _a : e.target;
		setArrivedState(eventTarget);
		isScrolling.value = true;
		onScrollEndDebounced(e);
		onScroll(e);
	};
	useEventListener(element, "scroll", throttle ? useThrottleFn(onScrollHandler, throttle, true, false) : onScrollHandler, eventListenerOptions);
	tryOnMounted(() => {
		try {
			const _element = toValue(element);
			if (!_element) return;
			setArrivedState(_element);
		} catch (e) {
			onError(e);
		}
	});
	if ((observe == null ? void 0 : observe.mutation) && element != null && element !== window && element !== document) {
		useMutationObserver(element, () => {
			const _element = toValue(element);
			if (!_element) return;
			setArrivedState(_element);
		}, {
			attributes: true,
			childList: true,
			subtree: true
		});
	}
	useEventListener(element, "scrollend", onScrollEnd, eventListenerOptions);
	return {
		x,
		y,
		isScrolling,
		arrivedState,
		directions,
		measure() {
			const _element = toValue(element);
			if (window && _element) setArrivedState(_element);
		}
	};
}
function useInfiniteScroll(element, onLoadMore, options = {}) {
	var _a;
	const { direction = "bottom", interval = 100, canLoadMore = () => true } = options;
	const state = reactive(useScroll(element, {
		...options,
		offset: {
			[direction]: (_a = options.distance) != null ? _a : 0,
			...options.offset
		}
	}));
	const promise = ref();
	const isLoading = computed(() => !!promise.value);
	const observedElement = computed(() => {
		return resolveElement(toValue(element));
	});
	const isElementVisible = useElementVisibility(observedElement);
	function checkAndLoad() {
		state.measure();
		if (!observedElement.value || !isElementVisible.value || !canLoadMore(observedElement.value)) return;
		const { scrollHeight, clientHeight, scrollWidth, clientWidth } = observedElement.value;
		const isNarrower = direction === "bottom" || direction === "top" ? scrollHeight <= clientHeight : scrollWidth <= clientWidth;
		if (state.arrivedState[direction] || isNarrower) {
			if (!promise.value) {
				promise.value = Promise.all([onLoadMore(state), new Promise((resolve) => setTimeout(resolve, interval))]).finally(() => {
					promise.value = null;
					nextTick(() => checkAndLoad());
				});
			}
		}
	}
	const stop = watch(() => [state.arrivedState[direction], isElementVisible.value], checkAndLoad, { immediate: true });
	tryOnUnmounted(stop);
	return {
		isLoading,
		reset() {
			nextTick(() => checkAndLoad());
		}
	};
}
const defaultEvents = [
	"mousedown",
	"mouseup",
	"keydown",
	"keyup"
];
// @__NO_SIDE_EFFECTS__
function useKeyModifier(modifier, options = {}) {
	const { events = defaultEvents, document = defaultDocument, initial = null } = options;
	const state = shallowRef(initial);
	if (document) {
		events.forEach((listenerEvent) => {
			useEventListener(document, listenerEvent, (evt) => {
				if (typeof evt.getModifierState === "function") state.value = evt.getModifierState(modifier);
			}, { passive: true });
		});
	}
	return state;
}
function useLocalStorage(key, initialValue, options = {}) {
	const { window = defaultWindow } = options;
	return useStorage(key, initialValue, window == null ? void 0 : window.localStorage, options);
}
const DefaultMagicKeysAliasMap = {
	ctrl: "control",
	command: "meta",
	cmd: "meta",
	option: "alt",
	up: "arrowup",
	down: "arrowdown",
	left: "arrowleft",
	right: "arrowright"
};
function useMagicKeys(options = {}) {
	const { reactive: useReactive = false, target = defaultWindow, aliasMap = DefaultMagicKeysAliasMap, passive = true, onEventFired = noop } = options;
	const current = reactive(/* @__PURE__ */ new Set());
	const obj = {
		toJSON() {
			return {};
		},
		current
	};
	const refs = useReactive ? reactive(obj) : obj;
	const metaDeps = /* @__PURE__ */ new Set();
	const shiftDeps = /* @__PURE__ */ new Set();
	const usedKeys = /* @__PURE__ */ new Set();
	function setRefs(key, value) {
		if (key in refs) {
			if (useReactive) refs[key] = value;
			else refs[key].value = value;
		}
	}
	function reset() {
		current.clear();
		for (const key of usedKeys) setRefs(key, false);
	}
	function updateRefs(e, value) {
		var _a, _b;
		const key = (_a = e.key) == null ? void 0 : _a.toLowerCase();
		const code = (_b = e.code) == null ? void 0 : _b.toLowerCase();
		const values = [code, key].filter(Boolean);
		if (key) {
			if (value) current.add(key);
			else current.delete(key);
		}
		for (const key2 of values) {
			usedKeys.add(key2);
			setRefs(key2, value);
		}
		if (key === "shift" && !value) {
			const shiftDepsArray = Array.from(shiftDeps);
			const shiftIndex = shiftDepsArray.indexOf("shift");
			shiftDepsArray.forEach((key2, index) => {
				if (index >= shiftIndex) {
					current.delete(key2);
					setRefs(key2, false);
				}
			});
			shiftDeps.clear();
		} else if (typeof e.getModifierState === "function" && e.getModifierState("Shift") && value) {
			[...current, ...values].forEach((key2) => shiftDeps.add(key2));
		}
		if (key === "meta" && !value) {
			metaDeps.forEach((key2) => {
				current.delete(key2);
				setRefs(key2, false);
			});
			metaDeps.clear();
		} else if (typeof e.getModifierState === "function" && e.getModifierState("Meta") && value) {
			[...current, ...values].forEach((key2) => metaDeps.add(key2));
		}
	}
	useEventListener(target, "keydown", (e) => {
		updateRefs(e, true);
		return onEventFired(e);
	}, { passive });
	useEventListener(target, "keyup", (e) => {
		updateRefs(e, false);
		return onEventFired(e);
	}, { passive });
	useEventListener("blur", reset, { passive });
	useEventListener("focus", reset, { passive });
	const proxy = new Proxy(refs, { get(target2, prop, rec) {
		if (typeof prop !== "string") return Reflect.get(target2, prop, rec);
		prop = prop.toLowerCase();
		if (prop in aliasMap) prop = aliasMap[prop];
		if (!(prop in refs)) {
			if (/[+_-]/.test(prop)) {
				const keys = prop.split(/[+_-]/g).map((i) => i.trim());
				refs[prop] = computed(() => keys.map((key) => toValue(proxy[key])).every(Boolean));
			} else {
				refs[prop] = shallowRef(false);
			}
		}
		const r = Reflect.get(target2, prop, rec);
		return useReactive ? toValue(r) : r;
	} });
	return proxy;
}
function usingElRef(source, cb) {
	if (toValue(source)) cb(toValue(source));
}
function timeRangeToArray(timeRanges) {
	let ranges = [];
	for (let i = 0; i < timeRanges.length; ++i) ranges = [...ranges, [timeRanges.start(i), timeRanges.end(i)]];
	return ranges;
}
function tracksToArray(tracks) {
	return Array.from(tracks).map(({ label, kind, language, mode, activeCues, cues, inBandMetadataTrackDispatchType }, id) => ({
		id,
		label,
		kind,
		language,
		mode,
		activeCues,
		cues,
		inBandMetadataTrackDispatchType
	}));
}
const defaultOptions = {
	src: "",
	tracks: []
};
function useMediaControls(target, options = {}) {
	target = toRef(target);
	options = {
		...defaultOptions,
		...options
	};
	const { document = defaultDocument } = options;
	const listenerOptions = { passive: true };
	const currentTime = shallowRef(0);
	const duration = shallowRef(0);
	const seeking = shallowRef(false);
	const volume = shallowRef(1);
	const waiting = shallowRef(false);
	const ended = shallowRef(false);
	const playing = shallowRef(false);
	const rate = shallowRef(1);
	const stalled = shallowRef(false);
	const buffered = ref([]);
	const tracks = ref([]);
	const selectedTrack = shallowRef(-1);
	const isPictureInPicture = shallowRef(false);
	const muted = shallowRef(false);
	const supportsPictureInPicture = document && "pictureInPictureEnabled" in document;
	const sourceErrorEvent = createEventHook();
	const playbackErrorEvent = createEventHook();
	const disableTrack = (track) => {
		usingElRef(target, (el) => {
			if (track) {
				const id = typeof track === "number" ? track : track.id;
				el.textTracks[id].mode = "disabled";
			} else {
				for (let i = 0; i < el.textTracks.length; ++i) el.textTracks[i].mode = "disabled";
			}
			selectedTrack.value = -1;
		});
	};
	const enableTrack = (track, disableTracks = true) => {
		usingElRef(target, (el) => {
			const id = typeof track === "number" ? track : track.id;
			if (disableTracks) disableTrack();
			el.textTracks[id].mode = "showing";
			selectedTrack.value = id;
		});
	};
	const togglePictureInPicture = () => {
		return new Promise((resolve, reject) => {
			usingElRef(target, async (el) => {
				if (supportsPictureInPicture) {
					if (!isPictureInPicture.value) {
						el.requestPictureInPicture().then(resolve).catch(reject);
					} else {
						document.exitPictureInPicture().then(resolve).catch(reject);
					}
				}
			});
		});
	};
	watchEffect(() => {
		if (!document) return;
		const el = toValue(target);
		if (!el) return;
		const src = toValue(options.src);
		let sources = [];
		if (!src) return;
		if (typeof src === "string") sources = [{ src }];
		else if (Array.isArray(src)) sources = src;
		else if (isObject(src)) sources = [src];
		el.querySelectorAll("source").forEach((e) => {
			e.remove();
		});
		sources.forEach(({ src: src2, type, media }) => {
			const source = document.createElement("source");
			source.setAttribute("src", src2);
			source.setAttribute("type", type || "");
			source.setAttribute("media", media || "");
			useEventListener(source, "error", sourceErrorEvent.trigger, listenerOptions);
			el.appendChild(source);
		});
		el.load();
	});
	watch([target, volume], () => {
		const el = toValue(target);
		if (!el) return;
		el.volume = volume.value;
	});
	watch([target, muted], () => {
		const el = toValue(target);
		if (!el) return;
		el.muted = muted.value;
	});
	watch([target, rate], () => {
		const el = toValue(target);
		if (!el) return;
		el.playbackRate = rate.value;
	});
	watchEffect(() => {
		if (!document) return;
		const textTracks = toValue(options.tracks);
		const el = toValue(target);
		if (!textTracks || !textTracks.length || !el) return;
		el.querySelectorAll("track").forEach((e) => e.remove());
		textTracks.forEach(({ default: isDefault, kind, label, src, srcLang }, i) => {
			const track = document.createElement("track");
			track.default = isDefault || false;
			track.kind = kind;
			track.label = label;
			track.src = src;
			track.srclang = srcLang;
			if (track.default) selectedTrack.value = i;
			el.appendChild(track);
		});
	});
	const { ignoreUpdates: ignoreCurrentTimeUpdates } = watchIgnorable(currentTime, (time) => {
		const el = toValue(target);
		if (!el) return;
		el.currentTime = time;
	});
	const { ignoreUpdates: ignorePlayingUpdates } = watchIgnorable(playing, (isPlaying) => {
		const el = toValue(target);
		if (!el) return;
		if (isPlaying) {
			el.play().catch((e) => {
				playbackErrorEvent.trigger(e);
				throw e;
			});
		} else {
			el.pause();
		}
	});
	useEventListener(target, "timeupdate", () => ignoreCurrentTimeUpdates(() => currentTime.value = toValue(target).currentTime), listenerOptions);
	useEventListener(target, "durationchange", () => duration.value = toValue(target).duration, listenerOptions);
	useEventListener(target, "progress", () => buffered.value = timeRangeToArray(toValue(target).buffered), listenerOptions);
	useEventListener(target, "seeking", () => seeking.value = true, listenerOptions);
	useEventListener(target, "seeked", () => seeking.value = false, listenerOptions);
	useEventListener(target, ["waiting", "loadstart"], () => {
		waiting.value = true;
		ignorePlayingUpdates(() => playing.value = false);
	}, listenerOptions);
	useEventListener(target, "loadeddata", () => waiting.value = false, listenerOptions);
	useEventListener(target, "playing", () => {
		waiting.value = false;
		ended.value = false;
		ignorePlayingUpdates(() => playing.value = true);
	}, listenerOptions);
	useEventListener(target, "ratechange", () => rate.value = toValue(target).playbackRate, listenerOptions);
	useEventListener(target, "stalled", () => stalled.value = true, listenerOptions);
	useEventListener(target, "ended", () => ended.value = true, listenerOptions);
	useEventListener(target, "pause", () => ignorePlayingUpdates(() => playing.value = false), listenerOptions);
	useEventListener(target, "play", () => ignorePlayingUpdates(() => playing.value = true), listenerOptions);
	useEventListener(target, "enterpictureinpicture", () => isPictureInPicture.value = true, listenerOptions);
	useEventListener(target, "leavepictureinpicture", () => isPictureInPicture.value = false, listenerOptions);
	useEventListener(target, "volumechange", () => {
		const el = toValue(target);
		if (!el) return;
		volume.value = el.volume;
		muted.value = el.muted;
	}, listenerOptions);
	const listeners = [];
	const stop = watch([target], () => {
		const el = toValue(target);
		if (!el) return;
		stop();
		listeners[0] = useEventListener(el.textTracks, "addtrack", () => tracks.value = tracksToArray(el.textTracks), listenerOptions);
		listeners[1] = useEventListener(el.textTracks, "removetrack", () => tracks.value = tracksToArray(el.textTracks), listenerOptions);
		listeners[2] = useEventListener(el.textTracks, "change", () => tracks.value = tracksToArray(el.textTracks), listenerOptions);
	});
	tryOnScopeDispose(() => listeners.forEach((listener) => listener()));
	return {
		currentTime,
		duration,
		waiting,
		seeking,
		ended,
		stalled,
		buffered,
		playing,
		rate,
		// Volume
		volume,
		muted,
		// Tracks
		tracks,
		selectedTrack,
		enableTrack,
		disableTrack,
		// Picture in Picture
		supportsPictureInPicture,
		togglePictureInPicture,
		isPictureInPicture,
		// Events
		onSourceError: sourceErrorEvent.on,
		onPlaybackError: playbackErrorEvent.on
	};
}
// @__NO_SIDE_EFFECTS__
function useMemoize(resolver, options) {
	const initCache = () => {
		if (options == null ? void 0 : options.cache) return shallowReactive(options.cache);
		return shallowReactive(/* @__PURE__ */ new Map());
	};
	const cache = initCache();
	const generateKey = (...args) => (options == null ? void 0 : options.getKey) ? options.getKey(...args) : JSON.stringify(args);
	const _loadData = (key, ...args) => {
		cache.set(key, resolver(...args));
		return cache.get(key);
	};
	const loadData = (...args) => _loadData(generateKey(...args), ...args);
	const deleteData = (...args) => {
		cache.delete(generateKey(...args));
	};
	const clearData = () => {
		cache.clear();
	};
	const memoized = (...args) => {
		const key = generateKey(...args);
		if (cache.has(key)) return cache.get(key);
		return _loadData(key, ...args);
	};
	memoized.load = loadData;
	memoized.delete = deleteData;
	memoized.clear = clearData;
	memoized.generateKey = generateKey;
	memoized.cache = cache;
	return memoized;
}
// @__NO_SIDE_EFFECTS__
function useMemory(options = {}) {
	const memory = ref();
	const isSupported = useSupported(() => typeof performance !== "undefined" && "memory" in performance);
	if (isSupported.value) {
		const { interval = 1e3 } = options;
		useIntervalFn(() => {
			memory.value = performance.memory;
		}, interval, {
			immediate: options.immediate,
			immediateCallback: options.immediateCallback
		});
	}
	return {
		isSupported,
		memory
	};
}
const UseMouseBuiltinExtractors = {
	page: (event) => [event.pageX, event.pageY],
	client: (event) => [event.clientX, event.clientY],
	screen: (event) => [event.screenX, event.screenY],
	movement: (event) => event instanceof MouseEvent ? [event.movementX, event.movementY] : null
};
function useMouse(options = {}) {
	const { type = "page", touch = true, resetOnTouchEnds = false, initialValue = {
		x: 0,
		y: 0
	}, window = defaultWindow, target = window, scroll = true, eventFilter } = options;
	let _prevMouseEvent = null;
	let _prevScrollX = 0;
	let _prevScrollY = 0;
	const x = shallowRef(initialValue.x);
	const y = shallowRef(initialValue.y);
	const sourceType = shallowRef(null);
	const extractor = typeof type === "function" ? type : UseMouseBuiltinExtractors[type];
	const mouseHandler = (event) => {
		const result = extractor(event);
		_prevMouseEvent = event;
		if (result) {
			[x.value, y.value] = result;
			sourceType.value = "mouse";
		}
		if (window) {
			_prevScrollX = window.scrollX;
			_prevScrollY = window.scrollY;
		}
	};
	const touchHandler = (event) => {
		if (event.touches.length > 0) {
			const result = extractor(event.touches[0]);
			if (result) {
				[x.value, y.value] = result;
				sourceType.value = "touch";
			}
		}
	};
	const scrollHandler = () => {
		if (!_prevMouseEvent || !window) return;
		const pos = extractor(_prevMouseEvent);
		if (_prevMouseEvent instanceof MouseEvent && pos) {
			x.value = pos[0] + window.scrollX - _prevScrollX;
			y.value = pos[1] + window.scrollY - _prevScrollY;
		}
	};
	const reset = () => {
		x.value = initialValue.x;
		y.value = initialValue.y;
	};
	const mouseHandlerWrapper = eventFilter ? (event) => eventFilter(() => mouseHandler(event), {}) : (event) => mouseHandler(event);
	const touchHandlerWrapper = eventFilter ? (event) => eventFilter(() => touchHandler(event), {}) : (event) => touchHandler(event);
	const scrollHandlerWrapper = eventFilter ? () => eventFilter(() => scrollHandler(), {}) : () => scrollHandler();
	if (target) {
		const listenerOptions = { passive: true };
		useEventListener(target, ["mousemove", "dragover"], mouseHandlerWrapper, listenerOptions);
		if (touch && type !== "movement") {
			useEventListener(target, ["touchstart", "touchmove"], touchHandlerWrapper, listenerOptions);
			if (resetOnTouchEnds) useEventListener(target, "touchend", reset, listenerOptions);
		}
		if (scroll && type === "page") useEventListener(window, "scroll", scrollHandlerWrapper, listenerOptions);
	}
	return {
		x,
		y,
		sourceType
	};
}
function useMouseInElement(target, options = {}) {
	const { windowResize = true, windowScroll = true, handleOutside = true, window = defaultWindow } = options;
	const type = options.type || "page";
	const { x, y, sourceType } = useMouse(options);
	const targetRef = shallowRef(target != null ? target : window == null ? void 0 : window.document.body);
	const elementX = shallowRef(0);
	const elementY = shallowRef(0);
	const elementPositionX = shallowRef(0);
	const elementPositionY = shallowRef(0);
	const elementHeight = shallowRef(0);
	const elementWidth = shallowRef(0);
	const isOutside = shallowRef(true);
	function update() {
		if (!window) return;
		const el = unrefElement(targetRef);
		if (!el || !(el instanceof Element)) return;
		const { left, top, width, height } = el.getBoundingClientRect();
		elementPositionX.value = left + (type === "page" ? window.pageXOffset : 0);
		elementPositionY.value = top + (type === "page" ? window.pageYOffset : 0);
		elementHeight.value = height;
		elementWidth.value = width;
		const elX = x.value - elementPositionX.value;
		const elY = y.value - elementPositionY.value;
		isOutside.value = width === 0 || height === 0 || elX < 0 || elY < 0 || elX > width || elY > height;
		if (handleOutside || !isOutside.value) {
			elementX.value = elX;
			elementY.value = elY;
		}
	}
	const stopFnList = [];
	function stop() {
		stopFnList.forEach((fn) => fn());
		stopFnList.length = 0;
	}
	tryOnMounted(() => {
		update();
	});
	if (window) {
		const { stop: stopResizeObserver } = useResizeObserver(targetRef, update);
		const { stop: stopMutationObserver } = useMutationObserver(targetRef, update, { attributeFilter: ["style", "class"] });
		const stopWatch = watch([
			targetRef,
			x,
			y
		], update);
		stopFnList.push(stopResizeObserver, stopMutationObserver, stopWatch);
		useEventListener(document, "mouseleave", () => isOutside.value = true, { passive: true });
		if (windowScroll) {
			stopFnList.push(useEventListener("scroll", update, {
				capture: true,
				passive: true
			}));
		}
		if (windowResize) {
			stopFnList.push(useEventListener("resize", update, { passive: true }));
		}
	}
	return {
		x,
		y,
		sourceType,
		elementX,
		elementY,
		elementPositionX,
		elementPositionY,
		elementHeight,
		elementWidth,
		isOutside,
		stop
	};
}
function useMousePressed(options = {}) {
	const { touch = true, drag = true, capture = false, initialValue = false, window = defaultWindow } = options;
	const pressed = shallowRef(initialValue);
	const sourceType = shallowRef(null);
	if (!window) {
		return {
			pressed,
			sourceType
		};
	}
	const onPressed = (srcType) => (event) => {
		var _a;
		pressed.value = true;
		sourceType.value = srcType;
		(_a = options.onPressed) == null ? void 0 : _a.call(options, event);
	};
	const onReleased = (event) => {
		var _a;
		pressed.value = false;
		sourceType.value = null;
		(_a = options.onReleased) == null ? void 0 : _a.call(options, event);
	};
	const target = computed(() => unrefElement(options.target) || window);
	const listenerOptions = {
		passive: true,
		capture
	};
	useEventListener(target, "mousedown", onPressed("mouse"), listenerOptions);
	useEventListener(window, "mouseleave", onReleased, listenerOptions);
	useEventListener(window, "mouseup", onReleased, listenerOptions);
	if (drag) {
		useEventListener(target, "dragstart", onPressed("mouse"), listenerOptions);
		useEventListener(window, "drop", onReleased, listenerOptions);
		useEventListener(window, "dragend", onReleased, listenerOptions);
	}
	if (touch) {
		useEventListener(target, "touchstart", onPressed("touch"), listenerOptions);
		useEventListener(window, "touchend", onReleased, listenerOptions);
		useEventListener(window, "touchcancel", onReleased, listenerOptions);
	}
	return {
		pressed,
		sourceType
	};
}
// @__NO_SIDE_EFFECTS__
function useNavigatorLanguage(options = {}) {
	const { window = defaultWindow } = options;
	const navigator = window == null ? void 0 : window.navigator;
	const isSupported = useSupported(() => navigator && "language" in navigator);
	const language = shallowRef(navigator == null ? void 0 : navigator.language);
	useEventListener(window, "languagechange", () => {
		if (navigator) language.value = navigator.language;
	}, { passive: true });
	return {
		isSupported,
		language
	};
}
// @__NO_SIDE_EFFECTS__
function useNetwork(options = {}) {
	const { window = defaultWindow } = options;
	const navigator = window == null ? void 0 : window.navigator;
	const isSupported = useSupported(() => navigator && "connection" in navigator);
	const isOnline = shallowRef(true);
	const saveData = shallowRef(false);
	const offlineAt = shallowRef(void 0);
	const onlineAt = shallowRef(void 0);
	const downlink = shallowRef(void 0);
	const downlinkMax = shallowRef(void 0);
	const rtt = shallowRef(void 0);
	const effectiveType = shallowRef(void 0);
	const type = shallowRef("unknown");
	const connection = isSupported.value && navigator.connection;
	function updateNetworkInformation() {
		if (!navigator) return;
		isOnline.value = navigator.onLine;
		offlineAt.value = isOnline.value ? void 0 : Date.now();
		onlineAt.value = isOnline.value ? Date.now() : void 0;
		if (connection) {
			downlink.value = connection.downlink;
			downlinkMax.value = connection.downlinkMax;
			effectiveType.value = connection.effectiveType;
			rtt.value = connection.rtt;
			saveData.value = connection.saveData;
			type.value = connection.type;
		}
	}
	const listenerOptions = { passive: true };
	if (window) {
		useEventListener(window, "offline", () => {
			isOnline.value = false;
			offlineAt.value = Date.now();
		}, listenerOptions);
		useEventListener(window, "online", () => {
			isOnline.value = true;
			onlineAt.value = Date.now();
		}, listenerOptions);
	}
	if (connection) useEventListener(connection, "change", updateNetworkInformation, listenerOptions);
	updateNetworkInformation();
	return {
		isSupported,
		isOnline: readonly(isOnline),
		saveData: readonly(saveData),
		offlineAt: readonly(offlineAt),
		onlineAt: readonly(onlineAt),
		downlink: readonly(downlink),
		downlinkMax: readonly(downlinkMax),
		effectiveType: readonly(effectiveType),
		rtt: readonly(rtt),
		type: readonly(type)
	};
}
// @__NO_SIDE_EFFECTS__
function useNow(options = {}) {
	const { controls: exposeControls = false, interval = "requestAnimationFrame", immediate = true } = options;
	const now = ref(/* @__PURE__ */ new Date());
	const update = () => now.value = /* @__PURE__ */ new Date();
	const controls = interval === "requestAnimationFrame" ? useRafFn(update, { immediate }) : useIntervalFn(update, interval, { immediate });
	if (exposeControls) {
		return {
			now,
			...controls
		};
	} else {
		return now;
	}
}
function useObjectUrl(object) {
	const url = shallowRef();
	const release = () => {
		if (url.value) URL.revokeObjectURL(url.value);
		url.value = void 0;
	};
	watch(() => toValue(object), (newObject) => {
		release();
		if (newObject) url.value = URL.createObjectURL(newObject);
	}, { immediate: true });
	tryOnScopeDispose(release);
	return readonly(url);
}
// @__NO_SIDE_EFFECTS__
function useClamp(value, min, max) {
	if (typeof value === "function" || isReadonly(value)) return computed(() => clamp(toValue(value), toValue(min), toValue(max)));
	const _value = ref(value);
	return computed({
		get() {
			return _value.value = clamp(_value.value, toValue(min), toValue(max));
		},
		set(value2) {
			_value.value = clamp(value2, toValue(min), toValue(max));
		}
	});
}
function useOffsetPagination(options) {
	const { total = Number.POSITIVE_INFINITY, pageSize = 10, page = 1, onPageChange = noop, onPageSizeChange = noop, onPageCountChange = noop } = options;
	const currentPageSize = useClamp(pageSize, 1, Number.POSITIVE_INFINITY);
	const pageCount = computed(() => Math.max(1, Math.ceil(toValue(total) / toValue(currentPageSize))));
	const currentPage = useClamp(page, 1, pageCount);
	const isFirstPage = computed(() => currentPage.value === 1);
	const isLastPage = computed(() => currentPage.value === pageCount.value);
	if (isRef(page)) {
		syncRef(page, currentPage, { direction: isReadonly(page) ? "ltr" : "both" });
	}
	if (isRef(pageSize)) {
		syncRef(pageSize, currentPageSize, { direction: isReadonly(pageSize) ? "ltr" : "both" });
	}
	function prev() {
		currentPage.value--;
	}
	function next() {
		currentPage.value++;
	}
	const returnValue = {
		currentPage,
		currentPageSize,
		pageCount,
		isFirstPage,
		isLastPage,
		prev,
		next
	};
	watch(currentPage, () => {
		onPageChange(reactive(returnValue));
	});
	watch(currentPageSize, () => {
		onPageSizeChange(reactive(returnValue));
	});
	watch(pageCount, () => {
		onPageCountChange(reactive(returnValue));
	});
	return returnValue;
}
// @__NO_SIDE_EFFECTS__
function useOnline(options = {}) {
	const { isOnline } = useNetwork(options);
	return isOnline;
}
// @__NO_SIDE_EFFECTS__
function usePageLeave(options = {}) {
	const { window = defaultWindow } = options;
	const isLeft = shallowRef(false);
	const handler = (event) => {
		if (!window) return;
		event = event || window.event;
		const from = event.relatedTarget || event.toElement;
		isLeft.value = !from;
	};
	if (window) {
		const listenerOptions = { passive: true };
		useEventListener(window, "mouseout", handler, listenerOptions);
		useEventListener(window.document, "mouseleave", handler, listenerOptions);
		useEventListener(window.document, "mouseenter", handler, listenerOptions);
	}
	return isLeft;
}
// @__NO_SIDE_EFFECTS__
function useScreenOrientation(options = {}) {
	const { window = defaultWindow } = options;
	const isSupported = useSupported(() => window && "screen" in window && "orientation" in window.screen);
	const screenOrientation = isSupported.value ? window.screen.orientation : {};
	const orientation = ref(screenOrientation.type);
	const angle = shallowRef(screenOrientation.angle || 0);
	if (isSupported.value) {
		useEventListener(window, "orientationchange", () => {
			orientation.value = screenOrientation.type;
			angle.value = screenOrientation.angle;
		}, { passive: true });
	}
	const lockOrientation = (type) => {
		if (isSupported.value && typeof screenOrientation.lock === "function") return screenOrientation.lock(type);
		return Promise.reject(new Error("Not supported"));
	};
	const unlockOrientation = () => {
		if (isSupported.value && typeof screenOrientation.unlock === "function") screenOrientation.unlock();
	};
	return {
		isSupported,
		orientation,
		angle,
		lockOrientation,
		unlockOrientation
	};
}
function useParallax(target, options = {}) {
	const { deviceOrientationTiltAdjust = (i) => i, deviceOrientationRollAdjust = (i) => i, mouseTiltAdjust = (i) => i, mouseRollAdjust = (i) => i, window = defaultWindow } = options;
	const orientation = reactive(useDeviceOrientation({ window }));
	const screenOrientation = reactive(useScreenOrientation({ window }));
	const { elementX: x, elementY: y, elementWidth: width, elementHeight: height } = useMouseInElement(target, {
		handleOutside: false,
		window
	});
	const source = computed(() => {
		if (orientation.isSupported && (orientation.alpha != null && orientation.alpha !== 0 || orientation.gamma != null && orientation.gamma !== 0)) {
			return "deviceOrientation";
		}
		return "mouse";
	});
	const roll = computed(() => {
		if (source.value === "deviceOrientation") {
			let value;
			switch (screenOrientation.orientation) {
				case "landscape-primary":
					value = orientation.gamma / 90;
					break;
				case "landscape-secondary":
					value = -orientation.gamma / 90;
					break;
				case "portrait-primary":
					value = -orientation.beta / 90;
					break;
				case "portrait-secondary":
					value = orientation.beta / 90;
					break;
				default: value = -orientation.beta / 90;
			}
			return deviceOrientationRollAdjust(value);
		} else {
			const value = -(y.value - height.value / 2) / height.value;
			return mouseRollAdjust(value);
		}
	});
	const tilt = computed(() => {
		if (source.value === "deviceOrientation") {
			let value;
			switch (screenOrientation.orientation) {
				case "landscape-primary":
					value = orientation.beta / 90;
					break;
				case "landscape-secondary":
					value = -orientation.beta / 90;
					break;
				case "portrait-primary":
					value = orientation.gamma / 90;
					break;
				case "portrait-secondary":
					value = -orientation.gamma / 90;
					break;
				default: value = orientation.gamma / 90;
			}
			return deviceOrientationTiltAdjust(value);
		} else {
			const value = (x.value - width.value / 2) / width.value;
			return mouseTiltAdjust(value);
		}
	});
	return {
		roll,
		tilt,
		source
	};
}
function useParentElement(element = useCurrentElement()) {
	const parentElement = shallowRef();
	const update = () => {
		const el = unrefElement(element);
		if (el) parentElement.value = el.parentElement;
	};
	tryOnMounted(update);
	watch(() => toValue(element), update);
	return parentElement;
}
function usePerformanceObserver(options, callback) {
	const { window = defaultWindow, immediate = true, ...performanceOptions } = options;
	const isSupported = useSupported(() => window && "PerformanceObserver" in window);
	let observer;
	const stop = () => {
		observer == null ? void 0 : observer.disconnect();
	};
	const start = () => {
		if (isSupported.value) {
			stop();
			observer = new PerformanceObserver(callback);
			observer.observe(performanceOptions);
		}
	};
	tryOnScopeDispose(stop);
	if (immediate) start();
	return {
		isSupported,
		start,
		stop
	};
}
const defaultState = {
	x: 0,
	y: 0,
	pointerId: 0,
	pressure: 0,
	tiltX: 0,
	tiltY: 0,
	width: 0,
	height: 0,
	twist: 0,
	pointerType: null
};
const keys = /* @__PURE__ */ Object.keys(defaultState);
function usePointer(options = {}) {
	const { target = defaultWindow } = options;
	const isInside = shallowRef(false);
	const state = shallowRef(options.initialValue || {});
	Object.assign(state.value, defaultState, state.value);
	const handler = (event) => {
		isInside.value = true;
		if (options.pointerTypes && !options.pointerTypes.includes(event.pointerType)) return;
		state.value = objectPick(event, keys, false);
	};
	if (target) {
		const listenerOptions = { passive: true };
		useEventListener(target, [
			"pointerdown",
			"pointermove",
			"pointerup"
		], handler, listenerOptions);
		useEventListener(target, "pointerleave", () => isInside.value = false, listenerOptions);
	}
	return {
		...toRefs(state),
		isInside
	};
}
// @__NO_SIDE_EFFECTS__
function usePointerLock(target, options = {}) {
	const { document = defaultDocument } = options;
	const isSupported = useSupported(() => document && "pointerLockElement" in document);
	const element = shallowRef();
	const triggerElement = shallowRef();
	let targetElement;
	if (isSupported.value) {
		const listenerOptions = { passive: true };
		useEventListener(document, "pointerlockchange", () => {
			var _a;
			const currentElement = (_a = document.pointerLockElement) != null ? _a : element.value;
			if (targetElement && currentElement === targetElement) {
				element.value = document.pointerLockElement;
				if (!element.value) targetElement = triggerElement.value = null;
			}
		}, listenerOptions);
		useEventListener(document, "pointerlockerror", () => {
			var _a;
			const currentElement = (_a = document.pointerLockElement) != null ? _a : element.value;
			if (targetElement && currentElement === targetElement) {
				const action = document.pointerLockElement ? "release" : "acquire";
				throw new Error(`Failed to ${action} pointer lock.`);
			}
		}, listenerOptions);
	}
	async function lock(e) {
		var _a;
		if (!isSupported.value) throw new Error("Pointer Lock API is not supported by your browser.");
		triggerElement.value = e instanceof Event ? e.currentTarget : null;
		targetElement = e instanceof Event ? (_a = unrefElement(target)) != null ? _a : triggerElement.value : unrefElement(e);
		if (!targetElement) throw new Error("Target element undefined.");
		targetElement.requestPointerLock();
		return await until(element).toBe(targetElement);
	}
	async function unlock() {
		if (!element.value) return false;
		document.exitPointerLock();
		await until(element).toBeNull();
		return true;
	}
	return {
		isSupported,
		element,
		triggerElement,
		lock,
		unlock
	};
}
function usePointerSwipe(target, options = {}) {
	const targetRef = toRef(target);
	const { threshold = 50, onSwipe, onSwipeEnd, onSwipeStart, disableTextSelect = false } = options;
	const posStart = reactive({
		x: 0,
		y: 0
	});
	const updatePosStart = (x, y) => {
		posStart.x = x;
		posStart.y = y;
	};
	const posEnd = reactive({
		x: 0,
		y: 0
	});
	const updatePosEnd = (x, y) => {
		posEnd.x = x;
		posEnd.y = y;
	};
	const distanceX = computed(() => posStart.x - posEnd.x);
	const distanceY = computed(() => posStart.y - posEnd.y);
	const { max, abs } = Math;
	const isThresholdExceeded = computed(() => max(abs(distanceX.value), abs(distanceY.value)) >= threshold);
	const isSwiping = shallowRef(false);
	const isPointerDown = shallowRef(false);
	const direction = computed(() => {
		if (!isThresholdExceeded.value) return "none";
		if (abs(distanceX.value) > abs(distanceY.value)) {
			return distanceX.value > 0 ? "left" : "right";
		} else {
			return distanceY.value > 0 ? "up" : "down";
		}
	});
	const eventIsAllowed = (e) => {
		var _a, _b, _c;
		const isReleasingButton = e.buttons === 0;
		const isPrimaryButton = e.buttons === 1;
		return (_c = (_b = (_a = options.pointerTypes) == null ? void 0 : _a.includes(e.pointerType)) != null ? _b : isReleasingButton || isPrimaryButton) != null ? _c : true;
	};
	const listenerOptions = { passive: true };
	const stops = [
		useEventListener(target, "pointerdown", (e) => {
			if (!eventIsAllowed(e)) return;
			isPointerDown.value = true;
			const eventTarget = e.target;
			eventTarget == null ? void 0 : eventTarget.setPointerCapture(e.pointerId);
			const { clientX: x, clientY: y } = e;
			updatePosStart(x, y);
			updatePosEnd(x, y);
			onSwipeStart == null ? void 0 : onSwipeStart(e);
		}, listenerOptions),
		useEventListener(target, "pointermove", (e) => {
			if (!eventIsAllowed(e)) return;
			if (!isPointerDown.value) return;
			const { clientX: x, clientY: y } = e;
			updatePosEnd(x, y);
			if (!isSwiping.value && isThresholdExceeded.value) isSwiping.value = true;
			if (isSwiping.value) onSwipe == null ? void 0 : onSwipe(e);
		}, listenerOptions),
		useEventListener(target, "pointerup", (e) => {
			if (!eventIsAllowed(e)) return;
			if (isSwiping.value) onSwipeEnd == null ? void 0 : onSwipeEnd(e, direction.value);
			isPointerDown.value = false;
			isSwiping.value = false;
		}, listenerOptions)
	];
	tryOnMounted(() => {
		var _a, _b, _c, _d, _e, _f, _g, _h;
		(_b = (_a = targetRef.value) == null ? void 0 : _a.style) == null ? void 0 : _b.setProperty("touch-action", "pan-y");
		if (disableTextSelect) {
			(_d = (_c = targetRef.value) == null ? void 0 : _c.style) == null ? void 0 : _d.setProperty("-webkit-user-select", "none");
			(_f = (_e = targetRef.value) == null ? void 0 : _e.style) == null ? void 0 : _f.setProperty("-ms-user-select", "none");
			(_h = (_g = targetRef.value) == null ? void 0 : _g.style) == null ? void 0 : _h.setProperty("user-select", "none");
		}
	});
	const stop = () => stops.forEach((s) => s());
	return {
		isSwiping: readonly(isSwiping),
		direction: readonly(direction),
		posStart: readonly(posStart),
		posEnd: readonly(posEnd),
		distanceX,
		distanceY,
		stop
	};
}
// @__NO_SIDE_EFFECTS__
function usePreferredColorScheme(options) {
	const isLight = useMediaQuery("(prefers-color-scheme: light)", options);
	const isDark = useMediaQuery("(prefers-color-scheme: dark)", options);
	return computed(() => {
		if (isDark.value) return "dark";
		if (isLight.value) return "light";
		return "no-preference";
	});
}
// @__NO_SIDE_EFFECTS__
function usePreferredContrast(options) {
	const isMore = useMediaQuery("(prefers-contrast: more)", options);
	const isLess = useMediaQuery("(prefers-contrast: less)", options);
	const isCustom = useMediaQuery("(prefers-contrast: custom)", options);
	return computed(() => {
		if (isMore.value) return "more";
		if (isLess.value) return "less";
		if (isCustom.value) return "custom";
		return "no-preference";
	});
}
// @__NO_SIDE_EFFECTS__
function usePreferredLanguages(options = {}) {
	const { window = defaultWindow } = options;
	if (!window) return shallowRef(["en"]);
	const navigator = window.navigator;
	const value = shallowRef(navigator.languages);
	useEventListener(window, "languagechange", () => {
		value.value = navigator.languages;
	}, { passive: true });
	return value;
}
// @__NO_SIDE_EFFECTS__
function usePreferredReducedMotion(options) {
	const isReduced = useMediaQuery("(prefers-reduced-motion: reduce)", options);
	return computed(() => {
		if (isReduced.value) return "reduce";
		return "no-preference";
	});
}
// @__NO_SIDE_EFFECTS__
function usePreferredReducedTransparency(options) {
	const isReduced = useMediaQuery("(prefers-reduced-transparency: reduce)", options);
	return computed(() => {
		if (isReduced.value) return "reduce";
		return "no-preference";
	});
}
function usePrevious(value, initialValue) {
	const previous = shallowRef(initialValue);
	watch(toRef(value), (_, oldValue) => {
		previous.value = oldValue;
	}, { flush: "sync" });
	return readonly(previous);
}
const topVarName = "--vueuse-safe-area-top";
const rightVarName = "--vueuse-safe-area-right";
const bottomVarName = "--vueuse-safe-area-bottom";
const leftVarName = "--vueuse-safe-area-left";
function useScreenSafeArea() {
	const top = shallowRef("");
	const right = shallowRef("");
	const bottom = shallowRef("");
	const left = shallowRef("");
	if (isClient) {
		const topCssVar = useCssVar(topVarName);
		const rightCssVar = useCssVar(rightVarName);
		const bottomCssVar = useCssVar(bottomVarName);
		const leftCssVar = useCssVar(leftVarName);
		topCssVar.value = "env(safe-area-inset-top, 0px)";
		rightCssVar.value = "env(safe-area-inset-right, 0px)";
		bottomCssVar.value = "env(safe-area-inset-bottom, 0px)";
		leftCssVar.value = "env(safe-area-inset-left, 0px)";
		tryOnMounted(update);
		useEventListener("resize", useDebounceFn(update), { passive: true });
	}
	function update() {
		top.value = getValue(topVarName);
		right.value = getValue(rightVarName);
		bottom.value = getValue(bottomVarName);
		left.value = getValue(leftVarName);
	}
	return {
		top,
		right,
		bottom,
		left,
		update
	};
}
function getValue(position) {
	return getComputedStyle(document.documentElement).getPropertyValue(position);
}
function useScriptTag(src, onLoaded = noop, options = {}) {
	const { immediate = true, manual = false, type = "text/javascript", async = true, crossOrigin, referrerPolicy, noModule, defer, document = defaultDocument, attrs = {}, nonce = void 0 } = options;
	const scriptTag = shallowRef(null);
	let _promise = null;
	const loadScript = (waitForScriptLoad) => new Promise((resolve, reject) => {
		const resolveWithElement = (el2) => {
			scriptTag.value = el2;
			resolve(el2);
			return el2;
		};
		if (!document) {
			resolve(false);
			return;
		}
		let shouldAppend = false;
		let el = document.querySelector(`script[src="${toValue(src)}"]`);
		if (!el) {
			el = document.createElement("script");
			el.type = type;
			el.async = async;
			el.src = toValue(src);
			if (defer) el.defer = defer;
			if (crossOrigin) el.crossOrigin = crossOrigin;
			if (noModule) el.noModule = noModule;
			if (referrerPolicy) el.referrerPolicy = referrerPolicy;
			if (nonce) {
				el.nonce = nonce;
			}
			Object.entries(attrs).forEach(([name, value]) => el == null ? void 0 : el.setAttribute(name, value));
			shouldAppend = true;
		} else if (el.hasAttribute("data-loaded")) {
			resolveWithElement(el);
		}
		const listenerOptions = { passive: true };
		useEventListener(el, "error", (event) => reject(event), listenerOptions);
		useEventListener(el, "abort", (event) => reject(event), listenerOptions);
		useEventListener(el, "load", () => {
			el.setAttribute("data-loaded", "true");
			onLoaded(el);
			resolveWithElement(el);
		}, listenerOptions);
		if (shouldAppend) el = document.head.appendChild(el);
		if (!waitForScriptLoad) resolveWithElement(el);
	});
	const load = (waitForScriptLoad = true) => {
		if (!_promise) _promise = loadScript(waitForScriptLoad);
		return _promise;
	};
	const unload = () => {
		if (!document) return;
		_promise = null;
		if (scriptTag.value) scriptTag.value = null;
		const el = document.querySelector(`script[src="${toValue(src)}"]`);
		if (el) document.head.removeChild(el);
	};
	if (immediate && !manual) tryOnMounted(load);
	if (!manual) tryOnUnmounted(unload);
	return {
		scriptTag,
		load,
		unload
	};
}
function checkOverflowScroll(ele) {
	const style = window.getComputedStyle(ele);
	if (style.overflowX === "scroll" || style.overflowY === "scroll" || style.overflowX === "auto" && ele.clientWidth < ele.scrollWidth || style.overflowY === "auto" && ele.clientHeight < ele.scrollHeight) {
		return true;
	} else {
		const parent = ele.parentNode;
		if (!parent || parent.tagName === "BODY") return false;
		return checkOverflowScroll(parent);
	}
}
function preventDefault(rawEvent) {
	const e = rawEvent || window.event;
	const _target = e.target;
	if (checkOverflowScroll(_target)) return false;
	if (e.touches.length > 1) return true;
	if (e.preventDefault) e.preventDefault();
	return false;
}
const elInitialOverflow = /* @__PURE__ */ new WeakMap();
function useScrollLock(element, initialState = false) {
	const isLocked = shallowRef(initialState);
	let stopTouchMoveListener = null;
	let initialOverflow = "";
	watch(toRef(element), (el) => {
		const target = resolveElement(toValue(el));
		if (target) {
			const ele = target;
			if (!elInitialOverflow.get(ele)) elInitialOverflow.set(ele, ele.style.overflow);
			if (ele.style.overflow !== "hidden") initialOverflow = ele.style.overflow;
			if (ele.style.overflow === "hidden") return isLocked.value = true;
			if (isLocked.value) return ele.style.overflow = "hidden";
		}
	}, { immediate: true });
	const lock = () => {
		const el = resolveElement(toValue(element));
		if (!el || isLocked.value) return;
		if (isIOS) {
			stopTouchMoveListener = useEventListener(el, "touchmove", (e) => {
				preventDefault(e);
			}, { passive: false });
		}
		el.style.overflow = "hidden";
		isLocked.value = true;
	};
	const unlock = () => {
		const el = resolveElement(toValue(element));
		if (!el || !isLocked.value) return;
		if (isIOS) stopTouchMoveListener == null ? void 0 : stopTouchMoveListener();
		el.style.overflow = initialOverflow;
		elInitialOverflow.delete(el);
		isLocked.value = false;
	};
	tryOnScopeDispose(unlock);
	return computed({
		get() {
			return isLocked.value;
		},
		set(v) {
			if (v) lock();
			else unlock();
		}
	});
}
function useSessionStorage(key, initialValue, options = {}) {
	const { window = defaultWindow } = options;
	return useStorage(key, initialValue, window == null ? void 0 : window.sessionStorage, options);
}
// @__NO_SIDE_EFFECTS__
function useShare(shareOptions = {}, options = {}) {
	const { navigator = defaultNavigator } = options;
	const _navigator = navigator;
	const isSupported = useSupported(() => _navigator && "canShare" in _navigator);
	const share = async (overrideOptions = {}) => {
		if (isSupported.value) {
			const data = {
				...toValue(shareOptions),
				...toValue(overrideOptions)
			};
			let granted = true;
			if (data.files && _navigator.canShare) granted = _navigator.canShare({ files: data.files });
			if (granted) return _navigator.share(data);
		}
	};
	return {
		isSupported,
		share
	};
}
const defaultSortFn = (source, compareFn) => source.sort(compareFn);
const defaultCompare = (a, b) => a - b;
function useSorted(...args) {
	var _a, _b, _c, _d;
	const [source] = args;
	let compareFn = defaultCompare;
	let options = {};
	if (args.length === 2) {
		if (typeof args[1] === "object") {
			options = args[1];
			compareFn = (_a = options.compareFn) != null ? _a : defaultCompare;
		} else {
			compareFn = (_b = args[1]) != null ? _b : defaultCompare;
		}
	} else if (args.length > 2) {
		compareFn = (_c = args[1]) != null ? _c : defaultCompare;
		options = (_d = args[2]) != null ? _d : {};
	}
	const { dirty = false, sortFn = defaultSortFn } = options;
	if (!dirty) return computed(() => sortFn([...toValue(source)], compareFn));
	watchEffect(() => {
		const result = sortFn(toValue(source), compareFn);
		if (isRef(source)) source.value = result;
		else source.splice(0, source.length, ...result);
	});
	return source;
}
function useSpeechRecognition(options = {}) {
	const { interimResults = true, continuous = true, maxAlternatives = 1, window = defaultWindow } = options;
	const lang = toRef(options.lang || "en-US");
	const isListening = shallowRef(false);
	const isFinal = shallowRef(false);
	const result = shallowRef("");
	const error = shallowRef(void 0);
	let recognition;
	const start = () => {
		isListening.value = true;
	};
	const stop = () => {
		isListening.value = false;
	};
	const toggle = (value = !isListening.value) => {
		if (value) {
			start();
		} else {
			stop();
		}
	};
	const SpeechRecognition = window && (window.SpeechRecognition || window.webkitSpeechRecognition);
	const isSupported = useSupported(() => SpeechRecognition);
	if (isSupported.value) {
		recognition = new SpeechRecognition();
		recognition.continuous = continuous;
		recognition.interimResults = interimResults;
		recognition.lang = toValue(lang);
		recognition.maxAlternatives = maxAlternatives;
		recognition.onstart = () => {
			isListening.value = true;
			isFinal.value = false;
		};
		watch(lang, (lang2) => {
			if (recognition && !isListening.value) recognition.lang = lang2;
		});
		recognition.onresult = (event) => {
			const currentResult = event.results[event.resultIndex];
			const { transcript } = currentResult[0];
			isFinal.value = currentResult.isFinal;
			result.value = transcript;
			error.value = void 0;
		};
		recognition.onerror = (event) => {
			error.value = event;
		};
		recognition.onend = () => {
			isListening.value = false;
			recognition.lang = toValue(lang);
		};
		watch(isListening, (newValue, oldValue) => {
			if (newValue === oldValue) return;
			if (newValue) recognition.start();
			else recognition.stop();
		});
	}
	tryOnScopeDispose(() => {
		stop();
	});
	return {
		isSupported,
		isListening,
		isFinal,
		recognition,
		result,
		error,
		toggle,
		start,
		stop
	};
}
function useSpeechSynthesis(text, options = {}) {
	const { pitch = 1, rate = 1, volume = 1, window = defaultWindow, onBoundary } = options;
	const synth = window && window.speechSynthesis;
	const isSupported = useSupported(() => synth);
	const isPlaying = shallowRef(false);
	const status = shallowRef("init");
	const spokenText = toRef(text || "");
	const lang = toRef(options.lang || "en-US");
	const error = shallowRef(void 0);
	const toggle = (value = !isPlaying.value) => {
		isPlaying.value = value;
	};
	const bindEventsForUtterance = (utterance2) => {
		utterance2.lang = toValue(lang);
		utterance2.voice = toValue(options.voice) || null;
		utterance2.pitch = toValue(pitch);
		utterance2.rate = toValue(rate);
		utterance2.volume = toValue(volume);
		utterance2.onstart = () => {
			isPlaying.value = true;
			status.value = "play";
		};
		utterance2.onpause = () => {
			isPlaying.value = false;
			status.value = "pause";
		};
		utterance2.onresume = () => {
			isPlaying.value = true;
			status.value = "play";
		};
		utterance2.onend = () => {
			isPlaying.value = false;
			status.value = "end";
		};
		utterance2.onerror = (event) => {
			error.value = event;
		};
		utterance2.onboundary = (event) => {
			onBoundary == null ? void 0 : onBoundary(event);
		};
	};
	const utterance = computed(() => {
		isPlaying.value = false;
		status.value = "init";
		const newUtterance = new SpeechSynthesisUtterance(spokenText.value);
		bindEventsForUtterance(newUtterance);
		return newUtterance;
	});
	const speak = () => {
		synth.cancel();
		if (utterance) synth.speak(utterance.value);
	};
	const stop = () => {
		synth.cancel();
		isPlaying.value = false;
	};
	if (isSupported.value) {
		bindEventsForUtterance(utterance.value);
		watch(lang, (lang2) => {
			if (utterance.value && !isPlaying.value) utterance.value.lang = lang2;
		});
		if (options.voice) {
			watch(options.voice, () => {
				synth.cancel();
			});
		}
		watch(isPlaying, () => {
			if (isPlaying.value) synth.resume();
			else synth.pause();
		});
	}
	tryOnScopeDispose(() => {
		isPlaying.value = false;
	});
	return {
		isSupported,
		isPlaying,
		status,
		utterance,
		error,
		stop,
		toggle,
		speak
	};
}
// @__NO_SIDE_EFFECTS__
function useStepper(steps, initialStep) {
	const stepsRef = ref(steps);
	const stepNames = computed(() => Array.isArray(stepsRef.value) ? stepsRef.value : Object.keys(stepsRef.value));
	const index = ref(stepNames.value.indexOf(initialStep != null ? initialStep : stepNames.value[0]));
	const current = computed(() => at(index.value));
	const isFirst = computed(() => index.value === 0);
	const isLast = computed(() => index.value === stepNames.value.length - 1);
	const next = computed(() => stepNames.value[index.value + 1]);
	const previous = computed(() => stepNames.value[index.value - 1]);
	function at(index2) {
		if (Array.isArray(stepsRef.value)) return stepsRef.value[index2];
		return stepsRef.value[stepNames.value[index2]];
	}
	function get(step) {
		if (!stepNames.value.includes(step)) return;
		return at(stepNames.value.indexOf(step));
	}
	function goTo(step) {
		if (stepNames.value.includes(step)) index.value = stepNames.value.indexOf(step);
	}
	function goToNext() {
		if (isLast.value) return;
		index.value++;
	}
	function goToPrevious() {
		if (isFirst.value) return;
		index.value--;
	}
	function goBackTo(step) {
		if (isAfter(step)) goTo(step);
	}
	function isNext(step) {
		return stepNames.value.indexOf(step) === index.value + 1;
	}
	function isPrevious(step) {
		return stepNames.value.indexOf(step) === index.value - 1;
	}
	function isCurrent(step) {
		return stepNames.value.indexOf(step) === index.value;
	}
	function isBefore(step) {
		return index.value < stepNames.value.indexOf(step);
	}
	function isAfter(step) {
		return index.value > stepNames.value.indexOf(step);
	}
	return {
		steps: stepsRef,
		stepNames,
		index,
		current,
		next,
		previous,
		isFirst,
		isLast,
		at,
		get,
		goTo,
		goToNext,
		goToPrevious,
		goBackTo,
		isNext,
		isPrevious,
		isCurrent,
		isBefore,
		isAfter
	};
}
function useStorageAsync(key, initialValue, storage, options = {}) {
	var _a;
	const { flush = "pre", deep = true, listenToStorageChanges = true, writeDefaults = true, mergeDefaults = false, shallow, window = defaultWindow, eventFilter, onError = (e) => {
		console.error(e);
	}, onReady } = options;
	const rawInit = toValue(initialValue);
	const type = guessSerializerType(rawInit);
	const data = (shallow ? shallowRef : ref)(toValue(initialValue));
	const serializer = (_a = options.serializer) != null ? _a : StorageSerializers[type];
	if (!storage) {
		try {
			storage = getSSRHandler("getDefaultStorageAsync", () => {
				var _a2;
				return (_a2 = defaultWindow) == null ? void 0 : _a2.localStorage;
			})();
		} catch (e) {
			onError(e);
		}
	}
	async function read(event) {
		if (!storage || event && event.key !== key) return;
		try {
			const rawValue = event ? event.newValue : await storage.getItem(key);
			if (rawValue == null) {
				data.value = rawInit;
				if (writeDefaults && rawInit !== null) await storage.setItem(key, await serializer.write(rawInit));
			} else if (mergeDefaults) {
				const value = await serializer.read(rawValue);
				if (typeof mergeDefaults === "function") data.value = mergeDefaults(value, rawInit);
				else if (type === "object" && !Array.isArray(value)) data.value = {
					...rawInit,
					...value
				};
				else data.value = value;
			} else {
				data.value = await serializer.read(rawValue);
			}
		} catch (e) {
			onError(e);
		}
	}
	const promise = new Promise((resolve) => {
		read().then(() => {
			onReady == null ? void 0 : onReady(data.value);
			resolve(data);
		});
	});
	if (window && listenToStorageChanges) useEventListener(window, "storage", (e) => Promise.resolve().then(() => read(e)), { passive: true });
	if (storage) {
		watchWithFilter(data, async () => {
			try {
				if (data.value == null) await storage.removeItem(key);
				else await storage.setItem(key, await serializer.write(data.value));
			} catch (e) {
				onError(e);
			}
		}, {
			flush,
			deep,
			eventFilter
		});
	}
	Object.assign(data, {
		then: promise.then.bind(promise),
		catch: promise.catch.bind(promise)
	});
	return data;
}
let _id = 0;
function useStyleTag(css, options = {}) {
	const isLoaded = shallowRef(false);
	const { document = defaultDocument, immediate = true, manual = false, id = `vueuse_styletag_${++_id}` } = options;
	const cssRef = shallowRef(css);
	let stop = () => {};
	const load = () => {
		if (!document) return;
		const el = document.getElementById(id) || document.createElement("style");
		if (!el.isConnected) {
			el.id = id;
			if (options.nonce) el.nonce = options.nonce;
			if (options.media) el.media = options.media;
			document.head.appendChild(el);
		}
		if (isLoaded.value) return;
		stop = watch(cssRef, (value) => {
			el.textContent = value;
		}, { immediate: true });
		isLoaded.value = true;
	};
	const unload = () => {
		if (!document || !isLoaded.value) return;
		stop();
		document.head.removeChild(document.getElementById(id));
		isLoaded.value = false;
	};
	if (immediate && !manual) tryOnMounted(load);
	if (!manual) tryOnScopeDispose(unload);
	return {
		id,
		css: cssRef,
		unload,
		load,
		isLoaded: readonly(isLoaded)
	};
}
function useSwipe(target, options = {}) {
	const { threshold = 50, onSwipe, onSwipeEnd, onSwipeStart, passive = true } = options;
	const coordsStart = reactive({
		x: 0,
		y: 0
	});
	const coordsEnd = reactive({
		x: 0,
		y: 0
	});
	const diffX = computed(() => coordsStart.x - coordsEnd.x);
	const diffY = computed(() => coordsStart.y - coordsEnd.y);
	const { max, abs } = Math;
	const isThresholdExceeded = computed(() => max(abs(diffX.value), abs(diffY.value)) >= threshold);
	const isSwiping = shallowRef(false);
	const direction = computed(() => {
		if (!isThresholdExceeded.value) return "none";
		if (abs(diffX.value) > abs(diffY.value)) {
			return diffX.value > 0 ? "left" : "right";
		} else {
			return diffY.value > 0 ? "up" : "down";
		}
	});
	const getTouchEventCoords = (e) => [e.touches[0].clientX, e.touches[0].clientY];
	const updateCoordsStart = (x, y) => {
		coordsStart.x = x;
		coordsStart.y = y;
	};
	const updateCoordsEnd = (x, y) => {
		coordsEnd.x = x;
		coordsEnd.y = y;
	};
	const listenerOptions = {
		passive,
		capture: !passive
	};
	const onTouchEnd = (e) => {
		if (isSwiping.value) onSwipeEnd == null ? void 0 : onSwipeEnd(e, direction.value);
		isSwiping.value = false;
	};
	const stops = [
		useEventListener(target, "touchstart", (e) => {
			if (e.touches.length !== 1) return;
			const [x, y] = getTouchEventCoords(e);
			updateCoordsStart(x, y);
			updateCoordsEnd(x, y);
			onSwipeStart == null ? void 0 : onSwipeStart(e);
		}, listenerOptions),
		useEventListener(target, "touchmove", (e) => {
			if (e.touches.length !== 1) return;
			const [x, y] = getTouchEventCoords(e);
			updateCoordsEnd(x, y);
			if (listenerOptions.capture && !listenerOptions.passive && Math.abs(diffX.value) > Math.abs(diffY.value)) e.preventDefault();
			if (!isSwiping.value && isThresholdExceeded.value) isSwiping.value = true;
			if (isSwiping.value) onSwipe == null ? void 0 : onSwipe(e);
		}, listenerOptions),
		useEventListener(target, ["touchend", "touchcancel"], onTouchEnd, listenerOptions)
	];
	const stop = () => stops.forEach((s) => s());
	return {
		isSwiping,
		direction,
		coordsStart,
		coordsEnd,
		lengthX: diffX,
		lengthY: diffY,
		stop,
		// TODO: Remove in the next major version
		isPassiveEventSupported: true
	};
}
// @__NO_SIDE_EFFECTS__
function useTemplateRefsList() {
	const refs = ref([]);
	refs.value.set = (el) => {
		if (el) refs.value.push(el);
	};
	onBeforeUpdate(() => {
		refs.value.length = 0;
	});
	return refs;
}
// @__NO_SIDE_EFFECTS__
function useTextDirection(options = {}) {
	const { document = defaultDocument, selector = "html", observe = false, initialValue = "ltr" } = options;
	function getValue() {
		var _a, _b;
		return (_b = (_a = document == null ? void 0 : document.querySelector(selector)) == null ? void 0 : _a.getAttribute("dir")) != null ? _b : initialValue;
	}
	const dir = ref(getValue());
	tryOnMounted(() => dir.value = getValue());
	if (observe && document) {
		useMutationObserver(document.querySelector(selector), () => dir.value = getValue(), { attributes: true });
	}
	return computed({
		get() {
			return dir.value;
		},
		set(v) {
			var _a, _b;
			dir.value = v;
			if (!document) return;
			if (dir.value) (_a = document.querySelector(selector)) == null ? void 0 : _a.setAttribute("dir", dir.value);
			else (_b = document.querySelector(selector)) == null ? void 0 : _b.removeAttribute("dir");
		}
	});
}
function getRangesFromSelection(selection) {
	var _a;
	const rangeCount = (_a = selection.rangeCount) != null ? _a : 0;
	return Array.from({ length: rangeCount }, (_, i) => selection.getRangeAt(i));
}
// @__NO_SIDE_EFFECTS__
function useTextSelection(options = {}) {
	const { window = defaultWindow } = options;
	const selection = ref(null);
	const text = computed(() => {
		var _a, _b;
		return (_b = (_a = selection.value) == null ? void 0 : _a.toString()) != null ? _b : "";
	});
	const ranges = computed(() => selection.value ? getRangesFromSelection(selection.value) : []);
	const rects = computed(() => ranges.value.map((range) => range.getBoundingClientRect()));
	function onSelectionChange() {
		selection.value = null;
		if (window) selection.value = window.getSelection();
	}
	if (window) useEventListener(window.document, "selectionchange", onSelectionChange, { passive: true });
	return {
		text,
		rects,
		ranges,
		selection
	};
}
function tryRequestAnimationFrame(window = defaultWindow, fn) {
	if (window && typeof window.requestAnimationFrame === "function") {
		window.requestAnimationFrame(fn);
	} else {
		fn();
	}
}
function useTextareaAutosize(options = {}) {
	var _a, _b;
	const { window = defaultWindow } = options;
	const textarea = toRef(options == null ? void 0 : options.element);
	const input = toRef((_a = options == null ? void 0 : options.input) != null ? _a : "");
	const styleProp = (_b = options == null ? void 0 : options.styleProp) != null ? _b : "height";
	const textareaScrollHeight = shallowRef(1);
	const textareaOldWidth = shallowRef(0);
	function triggerResize() {
		var _a2;
		if (!textarea.value) return;
		let height = "";
		textarea.value.style[styleProp] = "1px";
		textareaScrollHeight.value = (_a2 = textarea.value) == null ? void 0 : _a2.scrollHeight;
		const _styleTarget = toValue(options == null ? void 0 : options.styleTarget);
		if (_styleTarget) _styleTarget.style[styleProp] = `${textareaScrollHeight.value}px`;
		else height = `${textareaScrollHeight.value}px`;
		textarea.value.style[styleProp] = height;
	}
	watch([input, textarea], () => nextTick(triggerResize), { immediate: true });
	watch(textareaScrollHeight, () => {
		var _a2;
		return (_a2 = options == null ? void 0 : options.onResize) == null ? void 0 : _a2.call(options);
	});
	useResizeObserver(textarea, ([{ contentRect }]) => {
		if (textareaOldWidth.value === contentRect.width) return;
		tryRequestAnimationFrame(window, () => {
			textareaOldWidth.value = contentRect.width;
			triggerResize();
		});
	});
	if (options == null ? void 0 : options.watch) watch(options.watch, triggerResize, {
		immediate: true,
		deep: true
	});
	return {
		textarea,
		input,
		triggerResize
	};
}
function useThrottledRefHistory(source, options = {}) {
	const { throttle = 200, trailing = true } = options;
	const filter = throttleFilter(throttle, trailing);
	const history = useRefHistory(source, {
		...options,
		eventFilter: filter
	});
	return { ...history };
}
const DEFAULT_UNITS = [
	{
		max: 6e4,
		value: 1e3,
		name: "second"
	},
	{
		max: 276e4,
		value: 6e4,
		name: "minute"
	},
	{
		max: 72e6,
		value: 36e5,
		name: "hour"
	},
	{
		max: 5184e5,
		value: 864e5,
		name: "day"
	},
	{
		max: 24192e5,
		value: 6048e5,
		name: "week"
	},
	{
		max: 28512e6,
		value: 2592e6,
		name: "month"
	},
	{
		max: Number.POSITIVE_INFINITY,
		value: 31536e6,
		name: "year"
	}
];
const DEFAULT_MESSAGES = {
	justNow: "just now",
	past: (n) => n.match(/\d/) ? `${n} ago` : n,
	future: (n) => n.match(/\d/) ? `in ${n}` : n,
	month: (n, past) => n === 1 ? past ? "last month" : "next month" : `${n} month${n > 1 ? "s" : ""}`,
	year: (n, past) => n === 1 ? past ? "last year" : "next year" : `${n} year${n > 1 ? "s" : ""}`,
	day: (n, past) => n === 1 ? past ? "yesterday" : "tomorrow" : `${n} day${n > 1 ? "s" : ""}`,
	week: (n, past) => n === 1 ? past ? "last week" : "next week" : `${n} week${n > 1 ? "s" : ""}`,
	hour: (n) => `${n} hour${n > 1 ? "s" : ""}`,
	minute: (n) => `${n} minute${n > 1 ? "s" : ""}`,
	second: (n) => `${n} second${n > 1 ? "s" : ""}`,
	invalid: ""
};
function DEFAULT_FORMATTER(date) {
	return date.toISOString().slice(0, 10);
}
// @__NO_SIDE_EFFECTS__
function useTimeAgo(time, options = {}) {
	const { controls: exposeControls = false, updateInterval = 3e4 } = options;
	const { now, ...controls } = useNow({
		interval: updateInterval,
		controls: true
	});
	const timeAgo = computed(() => formatTimeAgo(new Date(toValue(time)), options, toValue(now)));
	if (exposeControls) {
		return {
			timeAgo,
			...controls
		};
	} else {
		return timeAgo;
	}
}
function formatTimeAgo(from, options = {}, now = Date.now()) {
	var _a;
	const { max, messages = DEFAULT_MESSAGES, fullDateFormatter = DEFAULT_FORMATTER, units = DEFAULT_UNITS, showSecond = false, rounding = "round" } = options;
	const roundFn = typeof rounding === "number" ? (n) => +n.toFixed(rounding) : Math[rounding];
	const diff = +now - +from;
	const absDiff = Math.abs(diff);
	function getValue(diff2, unit) {
		return roundFn(Math.abs(diff2) / unit.value);
	}
	function format(diff2, unit) {
		const val = getValue(diff2, unit);
		const past = diff2 > 0;
		const str = applyFormat(unit.name, val, past);
		return applyFormat(past ? "past" : "future", str, past);
	}
	function applyFormat(name, val, isPast) {
		const formatter = messages[name];
		if (typeof formatter === "function") return formatter(val, isPast);
		return formatter.replace("{0}", val.toString());
	}
	if (absDiff < 6e4 && !showSecond) return messages.justNow;
	if (typeof max === "number" && absDiff > max) return fullDateFormatter(new Date(from));
	if (typeof max === "string") {
		const unitMax = (_a = units.find((i) => i.name === max)) == null ? void 0 : _a.max;
		if (unitMax && absDiff > unitMax) return fullDateFormatter(new Date(from));
	}
	for (const [idx, unit] of units.entries()) {
		const val = getValue(diff, unit);
		if (val <= 0 && units[idx - 1]) return format(diff, units[idx - 1]);
		if (absDiff < unit.max) return format(diff, unit);
	}
	return messages.invalid;
}
const UNITS = [
	{
		name: "year",
		ms: 31536e6
	},
	{
		name: "month",
		ms: 2592e6
	},
	{
		name: "week",
		ms: 6048e5
	},
	{
		name: "day",
		ms: 864e5
	},
	{
		name: "hour",
		ms: 36e5
	},
	{
		name: "minute",
		ms: 6e4
	},
	{
		name: "second",
		ms: 1e3
	}
];
function useTimeAgoIntl(time, options = {}) {
	const { controls: exposeControls = false, updateInterval = 3e4 } = options;
	const { now, ...controls } = useNow({
		interval: updateInterval,
		controls: true
	});
	const result = computed(() => getTimeAgoIntlResult(new Date(toValue(time)), options, toValue(now)));
	const parts = computed(() => result.value.parts);
	const timeAgoIntl = computed(() => formatTimeAgoIntlParts(parts.value, {
		...options,
		locale: result.value.resolvedLocale
	}));
	return exposeControls ? {
		timeAgoIntl,
		parts,
		...controls
	} : timeAgoIntl;
}
function formatTimeAgoIntl(from, options = {}, now = Date.now()) {
	const { parts, resolvedLocale } = getTimeAgoIntlResult(from, options, now);
	return formatTimeAgoIntlParts(parts, {
		...options,
		locale: resolvedLocale
	});
}
function getTimeAgoIntlResult(from, options = {}, now = Date.now()) {
	const { locale, relativeTimeFormatOptions = { numeric: "auto" } } = options;
	const rtf = new Intl.RelativeTimeFormat(locale, relativeTimeFormatOptions);
	const { locale: resolvedLocale } = rtf.resolvedOptions();
	const diff = +from - +now;
	const absDiff = Math.abs(diff);
	for (const { name, ms } of UNITS) {
		if (absDiff >= ms) {
			return {
				resolvedLocale,
				parts: rtf.formatToParts(Math.round(diff / ms), name)
			};
		}
	}
	return {
		resolvedLocale,
		parts: rtf.formatToParts(0, "second")
	};
}
function formatTimeAgoIntlParts(parts, options = {}) {
	const { insertSpace = true, joinParts, locale } = options;
	if (typeof joinParts === "function") return joinParts(parts, locale);
	if (!insertSpace) return parts.map((part) => part.value).join("");
	return parts.map((part) => part.value.trim()).join(" ");
}
function useTimeoutPoll(fn, interval, options = {}) {
	const { immediate = true, immediateCallback = false } = options;
	const { start } = useTimeoutFn(loop, interval, { immediate });
	const isActive = shallowRef(false);
	async function loop() {
		if (!isActive.value) return;
		await fn();
		start();
	}
	function resume() {
		if (!isActive.value) {
			isActive.value = true;
			if (immediateCallback) fn();
			start();
		}
	}
	function pause() {
		isActive.value = false;
	}
	if (immediate && isClient) resume();
	tryOnScopeDispose(pause);
	return {
		isActive,
		pause,
		resume
	};
}
function useTimestamp(options = {}) {
	const { controls: exposeControls = false, offset = 0, immediate = true, interval = "requestAnimationFrame", callback } = options;
	const ts = shallowRef(timestamp() + offset);
	const update = () => ts.value = timestamp() + offset;
	const cb = callback ? () => {
		update();
		callback(ts.value);
	} : update;
	const controls = interval === "requestAnimationFrame" ? useRafFn(cb, { immediate }) : useIntervalFn(cb, interval, { immediate });
	if (exposeControls) {
		return {
			timestamp: ts,
			...controls
		};
	} else {
		return ts;
	}
}
function useTitle(newTitle = null, options = {}) {
	var _a, _b, _c;
	const { document = defaultDocument, restoreOnUnmount = (t) => t } = options;
	const originalTitle = (_a = document == null ? void 0 : document.title) != null ? _a : "";
	const title = toRef((_b = newTitle != null ? newTitle : document == null ? void 0 : document.title) != null ? _b : null);
	const isReadonly = !!(newTitle && typeof newTitle === "function");
	function format(t) {
		if (!("titleTemplate" in options)) return t;
		const template = options.titleTemplate || "%s";
		return typeof template === "function" ? template(t) : toValue(template).replace(/%s/g, t);
	}
	watch(title, (newValue, oldValue) => {
		if (newValue !== oldValue && document) document.title = format(newValue != null ? newValue : "");
	}, { immediate: true });
	if (options.observe && !options.titleTemplate && document && !isReadonly) {
		useMutationObserver((_c = document.head) == null ? void 0 : _c.querySelector("title"), () => {
			if (document && document.title !== title.value) title.value = format(document.title);
		}, { childList: true });
	}
	tryOnScopeDispose(() => {
		if (restoreOnUnmount) {
			const restoredTitle = restoreOnUnmount(originalTitle, title.value || "");
			if (restoredTitle != null && document) document.title = restoredTitle;
		}
	});
	return title;
}
const _TransitionPresets = {
	easeInSine: [
		.12,
		0,
		.39,
		0
	],
	easeOutSine: [
		.61,
		1,
		.88,
		1
	],
	easeInOutSine: [
		.37,
		0,
		.63,
		1
	],
	easeInQuad: [
		.11,
		0,
		.5,
		0
	],
	easeOutQuad: [
		.5,
		1,
		.89,
		1
	],
	easeInOutQuad: [
		.45,
		0,
		.55,
		1
	],
	easeInCubic: [
		.32,
		0,
		.67,
		0
	],
	easeOutCubic: [
		.33,
		1,
		.68,
		1
	],
	easeInOutCubic: [
		.65,
		0,
		.35,
		1
	],
	easeInQuart: [
		.5,
		0,
		.75,
		0
	],
	easeOutQuart: [
		.25,
		1,
		.5,
		1
	],
	easeInOutQuart: [
		.76,
		0,
		.24,
		1
	],
	easeInQuint: [
		.64,
		0,
		.78,
		0
	],
	easeOutQuint: [
		.22,
		1,
		.36,
		1
	],
	easeInOutQuint: [
		.83,
		0,
		.17,
		1
	],
	easeInExpo: [
		.7,
		0,
		.84,
		0
	],
	easeOutExpo: [
		.16,
		1,
		.3,
		1
	],
	easeInOutExpo: [
		.87,
		0,
		.13,
		1
	],
	easeInCirc: [
		.55,
		0,
		1,
		.45
	],
	easeOutCirc: [
		0,
		.55,
		.45,
		1
	],
	easeInOutCirc: [
		.85,
		0,
		.15,
		1
	],
	easeInBack: [
		.36,
		0,
		.66,
		-.56
	],
	easeOutBack: [
		.34,
		1.56,
		.64,
		1
	],
	easeInOutBack: [
		.68,
		-.6,
		.32,
		1.6
	]
};
const TransitionPresets = /* @__PURE__ */ Object.assign({}, { linear: identity }, _TransitionPresets);
function createEasingFunction([p0, p1, p2, p3]) {
	const a = (a1, a2) => 1 - 3 * a2 + 3 * a1;
	const b = (a1, a2) => 3 * a2 - 6 * a1;
	const c = (a1) => 3 * a1;
	const calcBezier = (t, a1, a2) => ((a(a1, a2) * t + b(a1, a2)) * t + c(a1)) * t;
	const getSlope = (t, a1, a2) => 3 * a(a1, a2) * t * t + 2 * b(a1, a2) * t + c(a1);
	const getTforX = (x) => {
		let aGuessT = x;
		for (let i = 0; i < 4; ++i) {
			const currentSlope = getSlope(aGuessT, p0, p2);
			if (currentSlope === 0) return aGuessT;
			const currentX = calcBezier(aGuessT, p0, p2) - x;
			aGuessT -= currentX / currentSlope;
		}
		return aGuessT;
	};
	return (x) => p0 === p1 && p2 === p3 ? x : calcBezier(getTforX(x), p1, p3);
}
function lerp(a, b, alpha) {
	return a + alpha * (b - a);
}
function toVec(t) {
	return (typeof t === "number" ? [t] : t) || [];
}
function executeTransition(source, from, to, options = {}) {
	var _a, _b;
	const { window = defaultWindow } = options;
	const fromVal = toValue(from);
	const toVal = toValue(to);
	const v1 = toVec(fromVal);
	const v2 = toVec(toVal);
	const duration = (_a = toValue(options.duration)) != null ? _a : 1e3;
	const startedAt = Date.now();
	const endAt = Date.now() + duration;
	const trans = typeof options.transition === "function" ? options.transition : (_b = toValue(options.transition)) != null ? _b : identity;
	const ease = typeof trans === "function" ? trans : createEasingFunction(trans);
	return new Promise((resolve) => {
		source.value = fromVal;
		const tick = () => {
			var _a2;
			if ((_a2 = options.abort) == null ? void 0 : _a2.call(options)) {
				resolve();
				return;
			}
			const now = Date.now();
			const alpha = ease((now - startedAt) / duration);
			const arr = toVec(source.value).map((n, i) => lerp(v1[i], v2[i], alpha));
			if (Array.isArray(source.value)) source.value = arr.map((n, i) => {
				var _a3, _b2;
				return lerp((_a3 = v1[i]) != null ? _a3 : 0, (_b2 = v2[i]) != null ? _b2 : 0, alpha);
			});
			else if (typeof source.value === "number") source.value = arr[0];
			if (now < endAt) {
				window == null ? void 0 : window.requestAnimationFrame(tick);
			} else {
				source.value = toVal;
				resolve();
			}
		};
		tick();
	});
}
function useTransition(source, options = {}) {
	let currentId = 0;
	const sourceVal = () => {
		const v = toValue(source);
		return typeof v === "number" ? v : v.map(toValue);
	};
	const outputRef = ref(sourceVal());
	watch(sourceVal, async (to) => {
		var _a, _b;
		if (toValue(options.disabled)) return;
		const id = ++currentId;
		if (options.delay) await promiseTimeout(toValue(options.delay));
		if (id !== currentId) return;
		const toVal = Array.isArray(to) ? to.map(toValue) : toValue(to);
		(_a = options.onStarted) == null ? void 0 : _a.call(options);
		await executeTransition(outputRef, outputRef.value, toVal, {
			...options,
			abort: () => {
				var _a2;
				return id !== currentId || ((_a2 = options.abort) == null ? void 0 : _a2.call(options));
			}
		});
		(_b = options.onFinished) == null ? void 0 : _b.call(options);
	}, { deep: true });
	watch(() => toValue(options.disabled), (disabled) => {
		if (disabled) {
			currentId++;
			outputRef.value = sourceVal();
		}
	});
	tryOnScopeDispose(() => {
		currentId++;
	});
	return computed(() => toValue(options.disabled) ? sourceVal() : outputRef.value);
}
function useUrlSearchParams(mode = "history", options = {}) {
	const { initialValue = {}, removeNullishValues = true, removeFalsyValues = false, write: enableWrite = true, writeMode = "replace", window = defaultWindow, stringify = (params) => params.toString() } = options;
	if (!window) return reactive(initialValue);
	const state = reactive({});
	function getRawParams() {
		if (mode === "history") {
			return window.location.search || "";
		} else if (mode === "hash") {
			const hash = window.location.hash || "";
			const index = hash.indexOf("?");
			return index > 0 ? hash.slice(index) : "";
		} else {
			return (window.location.hash || "").replace(/^#/, "");
		}
	}
	function constructQuery(params) {
		const stringified = stringify(params);
		if (mode === "history") return `${stringified ? `?${stringified}` : ""}${window.location.hash || ""}`;
		if (mode === "hash-params") return `${window.location.search || ""}${stringified ? `#${stringified}` : ""}`;
		const hash = window.location.hash || "#";
		const index = hash.indexOf("?");
		if (index > 0) return `${window.location.search || ""}${hash.slice(0, index)}${stringified ? `?${stringified}` : ""}`;
		return `${window.location.search || ""}${hash}${stringified ? `?${stringified}` : ""}`;
	}
	function read() {
		return new URLSearchParams(getRawParams());
	}
	function updateState(params) {
		const unusedKeys = new Set(Object.keys(state));
		for (const key of params.keys()) {
			const paramsForKey = params.getAll(key);
			state[key] = paramsForKey.length > 1 ? paramsForKey : params.get(key) || "";
			unusedKeys.delete(key);
		}
		Array.from(unusedKeys).forEach((key) => delete state[key]);
	}
	const { pause, resume } = pausableWatch(state, () => {
		const params = new URLSearchParams("");
		Object.keys(state).forEach((key) => {
			const mapEntry = state[key];
			if (Array.isArray(mapEntry)) mapEntry.forEach((value) => params.append(key, value));
			else if (removeNullishValues && mapEntry == null) params.delete(key);
			else if (removeFalsyValues && !mapEntry) params.delete(key);
			else params.set(key, mapEntry);
		});
		write(params, false);
	}, { deep: true });
	function write(params, shouldUpdate, shouldWriteHistory = true) {
		pause();
		if (shouldUpdate) updateState(params);
		if (writeMode === "replace") {
			window.history.replaceState(window.history.state, window.document.title, window.location.pathname + constructQuery(params));
		} else {
			if (shouldWriteHistory) {
				window.history.pushState(window.history.state, window.document.title, window.location.pathname + constructQuery(params));
			}
		}
		nextTick(() => resume());
	}
	function onChanged() {
		if (!enableWrite) return;
		write(read(), true, false);
	}
	const listenerOptions = { passive: true };
	useEventListener(window, "popstate", onChanged, listenerOptions);
	if (mode !== "history") useEventListener(window, "hashchange", onChanged, listenerOptions);
	const initial = read();
	if (initial.keys().next().value) updateState(initial);
	else Object.assign(state, initialValue);
	return state;
}
function useUserMedia(options = {}) {
	var _a, _b;
	const enabled = shallowRef((_a = options.enabled) != null ? _a : false);
	const autoSwitch = shallowRef((_b = options.autoSwitch) != null ? _b : true);
	const constraints = ref(options.constraints);
	const { navigator = defaultNavigator } = options;
	const isSupported = useSupported(() => {
		var _a2;
		return (_a2 = navigator == null ? void 0 : navigator.mediaDevices) == null ? void 0 : _a2.getUserMedia;
	});
	const stream = shallowRef();
	function getDeviceOptions(type) {
		switch (type) {
			case "video": {
				if (constraints.value) return constraints.value.video || false;
				break;
			}
			case "audio": {
				if (constraints.value) return constraints.value.audio || false;
				break;
			}
		}
	}
	async function _start() {
		if (!isSupported.value || stream.value) return;
		stream.value = await navigator.mediaDevices.getUserMedia({
			video: getDeviceOptions("video"),
			audio: getDeviceOptions("audio")
		});
		return stream.value;
	}
	function _stop() {
		var _a2;
		(_a2 = stream.value) == null ? void 0 : _a2.getTracks().forEach((t) => t.stop());
		stream.value = void 0;
	}
	function stop() {
		_stop();
		enabled.value = false;
	}
	async function start() {
		await _start();
		if (stream.value) enabled.value = true;
		return stream.value;
	}
	async function restart() {
		_stop();
		return await start();
	}
	watch(enabled, (v) => {
		if (v) _start();
		else _stop();
	}, { immediate: true });
	watch(constraints, () => {
		if (autoSwitch.value && stream.value) restart();
	}, { immediate: true });
	tryOnScopeDispose(() => {
		stop();
	});
	return {
		isSupported,
		stream,
		start,
		stop,
		restart,
		constraints,
		enabled,
		autoSwitch
	};
}
// @__NO_SIDE_EFFECTS__
function useVModel(props, key, emit, options = {}) {
	var _a, _b, _c;
	const { clone = false, passive = false, eventName, deep = false, defaultValue, shouldEmit } = options;
	const vm = getCurrentInstance();
	const _emit = emit || (vm == null ? void 0 : vm.emit) || ((_a = vm == null ? void 0 : vm.$emit) == null ? void 0 : _a.bind(vm)) || ((_c = (_b = vm == null ? void 0 : vm.proxy) == null ? void 0 : _b.$emit) == null ? void 0 : _c.bind(vm == null ? void 0 : vm.proxy));
	let event = eventName;
	if (!key) {
		key = "modelValue";
	}
	event = event || `update:${key.toString()}`;
	const cloneFn = (val) => !clone ? val : typeof clone === "function" ? clone(val) : cloneFnJSON(val);
	const getValue = () => isDef(props[key]) ? cloneFn(props[key]) : defaultValue;
	const triggerEmit = (value) => {
		if (shouldEmit) {
			if (shouldEmit(value)) _emit(event, value);
		} else {
			_emit(event, value);
		}
	};
	if (passive) {
		const initialValue = getValue();
		const proxy = ref(initialValue);
		let isUpdating = false;
		watch(() => props[key], (v) => {
			if (!isUpdating) {
				isUpdating = true;
				proxy.value = cloneFn(v);
				nextTick(() => isUpdating = false);
			}
		});
		watch(proxy, (v) => {
			if (!isUpdating && (v !== props[key] || deep)) triggerEmit(v);
		}, { deep });
		return proxy;
	} else {
		return computed({
			get() {
				return getValue();
			},
			set(value) {
				triggerEmit(value);
			}
		});
	}
}
// @__NO_SIDE_EFFECTS__
function useVModels(props, emit, options = {}) {
	const ret = {};
	for (const key in props) {
		ret[key] = useVModel(props, key, emit, options);
	}
	return ret;
}
// @__NO_SIDE_EFFECTS__
function useVibrate(options) {
	const { pattern = [], interval = 0, navigator = defaultNavigator } = options || {};
	const isSupported = useSupported(() => typeof navigator !== "undefined" && "vibrate" in navigator);
	const patternRef = toRef(pattern);
	let intervalControls;
	const vibrate = (pattern2 = patternRef.value) => {
		if (isSupported.value) navigator.vibrate(pattern2);
	};
	const stop = () => {
		if (isSupported.value) navigator.vibrate(0);
		intervalControls == null ? void 0 : intervalControls.pause();
	};
	if (interval > 0) {
		intervalControls = useIntervalFn(vibrate, interval, {
			immediate: false,
			immediateCallback: false
		});
	}
	return {
		isSupported,
		pattern,
		intervalControls,
		vibrate,
		stop
	};
}
function useVirtualList(list, options) {
	const { containerStyle, wrapperProps, scrollTo, calculateRange, currentList, containerRef } = "itemHeight" in options ? useVerticalVirtualList(options, list) : useHorizontalVirtualList(options, list);
	return {
		list: currentList,
		scrollTo,
		containerProps: {
			ref: containerRef,
			onScroll: () => {
				calculateRange();
			},
			style: containerStyle
		},
		wrapperProps
	};
}
function useVirtualListResources(list) {
	const containerRef = shallowRef(null);
	const size = useElementSize(containerRef);
	const currentList = ref([]);
	const source = shallowRef(list);
	const state = ref({
		start: 0,
		end: 10
	});
	return {
		state,
		source,
		currentList,
		size,
		containerRef
	};
}
function createGetViewCapacity(state, source, itemSize) {
	return (containerSize) => {
		if (typeof itemSize === "number") return Math.ceil(containerSize / itemSize);
		const { start = 0 } = state.value;
		let sum = 0;
		let capacity = 0;
		for (let i = start; i < source.value.length; i++) {
			const size = itemSize(i);
			sum += size;
			capacity = i;
			if (sum > containerSize) break;
		}
		return capacity - start;
	};
}
function createGetOffset(source, itemSize) {
	return (scrollDirection) => {
		if (typeof itemSize === "number") return Math.floor(scrollDirection / itemSize) + 1;
		let sum = 0;
		let offset = 0;
		for (let i = 0; i < source.value.length; i++) {
			const size = itemSize(i);
			sum += size;
			if (sum >= scrollDirection) {
				offset = i;
				break;
			}
		}
		return offset + 1;
	};
}
function createCalculateRange(type, overscan, getOffset, getViewCapacity, { containerRef, state, currentList, source }) {
	return () => {
		const element = containerRef.value;
		if (element) {
			const offset = getOffset(type === "vertical" ? element.scrollTop : element.scrollLeft);
			const viewCapacity = getViewCapacity(type === "vertical" ? element.clientHeight : element.clientWidth);
			const from = offset - overscan;
			const to = offset + viewCapacity + overscan;
			state.value = {
				start: from < 0 ? 0 : from,
				end: to > source.value.length ? source.value.length : to
			};
			currentList.value = source.value.slice(state.value.start, state.value.end).map((ele, index) => ({
				data: ele,
				index: index + state.value.start
			}));
		}
	};
}
function createGetDistance(itemSize, source) {
	return (index) => {
		if (typeof itemSize === "number") {
			const size2 = index * itemSize;
			return size2;
		}
		const size = source.value.slice(0, index).reduce((sum, _, i) => sum + itemSize(i), 0);
		return size;
	};
}
function useWatchForSizes(size, list, containerRef, calculateRange) {
	watch([
		size.width,
		size.height,
		() => toValue(list),
		containerRef
	], () => {
		calculateRange();
	});
}
function createComputedTotalSize(itemSize, source) {
	return computed(() => {
		if (typeof itemSize === "number") return source.value.length * itemSize;
		return source.value.reduce((sum, _, index) => sum + itemSize(index), 0);
	});
}
const scrollToDictionaryForElementScrollKey = {
	horizontal: "scrollLeft",
	vertical: "scrollTop"
};
function createScrollTo(type, calculateRange, getDistance, containerRef) {
	return (index) => {
		if (containerRef.value) {
			containerRef.value[scrollToDictionaryForElementScrollKey[type]] = getDistance(index);
			calculateRange();
		}
	};
}
function useHorizontalVirtualList(options, list) {
	const resources = useVirtualListResources(list);
	const { state, source, currentList, size, containerRef } = resources;
	const containerStyle = { overflowX: "auto" };
	const { itemWidth, overscan = 5 } = options;
	const getViewCapacity = createGetViewCapacity(state, source, itemWidth);
	const getOffset = createGetOffset(source, itemWidth);
	const calculateRange = createCalculateRange("horizontal", overscan, getOffset, getViewCapacity, resources);
	const getDistanceLeft = createGetDistance(itemWidth, source);
	const offsetLeft = computed(() => getDistanceLeft(state.value.start));
	const totalWidth = createComputedTotalSize(itemWidth, source);
	useWatchForSizes(size, list, containerRef, calculateRange);
	const scrollTo = createScrollTo("horizontal", calculateRange, getDistanceLeft, containerRef);
	const wrapperProps = computed(() => {
		return { style: {
			height: "100%",
			width: `${totalWidth.value - offsetLeft.value}px`,
			marginLeft: `${offsetLeft.value}px`,
			display: "flex"
		} };
	});
	return {
		scrollTo,
		calculateRange,
		wrapperProps,
		containerStyle,
		currentList,
		containerRef
	};
}
function useVerticalVirtualList(options, list) {
	const resources = useVirtualListResources(list);
	const { state, source, currentList, size, containerRef } = resources;
	const containerStyle = { overflowY: "auto" };
	const { itemHeight, overscan = 5 } = options;
	const getViewCapacity = createGetViewCapacity(state, source, itemHeight);
	const getOffset = createGetOffset(source, itemHeight);
	const calculateRange = createCalculateRange("vertical", overscan, getOffset, getViewCapacity, resources);
	const getDistanceTop = createGetDistance(itemHeight, source);
	const offsetTop = computed(() => getDistanceTop(state.value.start));
	const totalHeight = createComputedTotalSize(itemHeight, source);
	useWatchForSizes(size, list, containerRef, calculateRange);
	const scrollTo = createScrollTo("vertical", calculateRange, getDistanceTop, containerRef);
	const wrapperProps = computed(() => {
		return { style: {
			width: "100%",
			height: `${totalHeight.value - offsetTop.value}px`,
			marginTop: `${offsetTop.value}px`
		} };
	});
	return {
		calculateRange,
		scrollTo,
		containerStyle,
		wrapperProps,
		currentList,
		containerRef
	};
}
// @__NO_SIDE_EFFECTS__
function useWakeLock(options = {}) {
	const { navigator = defaultNavigator, document = defaultDocument } = options;
	const requestedType = shallowRef(false);
	const sentinel = shallowRef(null);
	const documentVisibility = useDocumentVisibility({ document });
	const isSupported = useSupported(() => navigator && "wakeLock" in navigator);
	const isActive = computed(() => !!sentinel.value && documentVisibility.value === "visible");
	if (isSupported.value) {
		useEventListener(sentinel, "release", () => {
			var _a, _b;
			requestedType.value = (_b = (_a = sentinel.value) == null ? void 0 : _a.type) != null ? _b : false;
		}, { passive: true });
		whenever(() => documentVisibility.value === "visible" && (document == null ? void 0 : document.visibilityState) === "visible" && requestedType.value, (type) => {
			requestedType.value = false;
			forceRequest(type);
		});
	}
	async function forceRequest(type) {
		var _a;
		await ((_a = sentinel.value) == null ? void 0 : _a.release());
		sentinel.value = isSupported.value ? await navigator.wakeLock.request(type) : null;
	}
	async function request(type) {
		if (documentVisibility.value === "visible") await forceRequest(type);
		else requestedType.value = type;
	}
	async function release() {
		requestedType.value = false;
		const s = sentinel.value;
		sentinel.value = null;
		await (s == null ? void 0 : s.release());
	}
	return {
		sentinel,
		isSupported,
		isActive,
		request,
		forceRequest,
		release
	};
}
function useWebNotification(options = {}) {
	const { window = defaultWindow, requestPermissions: _requestForPermissions = true } = options;
	const defaultWebNotificationOptions = options;
	const isSupported = useSupported(() => {
		if (!window || !("Notification" in window)) return false;
		if (Notification.permission === "granted") return true;
		try {
			const notification2 = new Notification("");
			notification2.onshow = () => {
				notification2.close();
			};
		} catch (e) {
			if (e.name === "TypeError") return false;
		}
		return true;
	});
	const permissionGranted = shallowRef(isSupported.value && "permission" in Notification && Notification.permission === "granted");
	const notification = ref(null);
	const ensurePermissions = async () => {
		if (!isSupported.value) return;
		if (!permissionGranted.value && Notification.permission !== "denied") {
			const result = await Notification.requestPermission();
			if (result === "granted") permissionGranted.value = true;
		}
		return permissionGranted.value;
	};
	const { on: onClick, trigger: clickTrigger } = createEventHook();
	const { on: onShow, trigger: showTrigger } = createEventHook();
	const { on: onError, trigger: errorTrigger } = createEventHook();
	const { on: onClose, trigger: closeTrigger } = createEventHook();
	const show = async (overrides) => {
		if (!isSupported.value || !permissionGranted.value) return;
		const options2 = Object.assign({}, defaultWebNotificationOptions, overrides);
		notification.value = new Notification(options2.title || "", options2);
		notification.value.onclick = clickTrigger;
		notification.value.onshow = showTrigger;
		notification.value.onerror = errorTrigger;
		notification.value.onclose = closeTrigger;
		return notification.value;
	};
	const close = () => {
		if (notification.value) notification.value.close();
		notification.value = null;
	};
	if (_requestForPermissions) tryOnMounted(ensurePermissions);
	tryOnScopeDispose(close);
	if (isSupported.value && window) {
		const document = window.document;
		useEventListener(document, "visibilitychange", (e) => {
			e.preventDefault();
			if (document.visibilityState === "visible") {
				close();
			}
		});
	}
	return {
		isSupported,
		notification,
		ensurePermissions,
		permissionGranted,
		show,
		close,
		onClick,
		onShow,
		onError,
		onClose
	};
}
const DEFAULT_PING_MESSAGE = "ping";
function resolveNestedOptions(options) {
	if (options === true) return {};
	return options;
}
function useWebSocket(url, options = {}) {
	const { onConnected, onDisconnected, onError, onMessage, immediate = true, autoConnect = true, autoClose = true, protocols = [] } = options;
	const data = ref(null);
	const status = shallowRef("CLOSED");
	const wsRef = ref();
	const urlRef = toRef(url);
	let heartbeatPause;
	let heartbeatResume;
	let explicitlyClosed = false;
	let retried = 0;
	let bufferedData = [];
	let retryTimeout;
	let pongTimeoutWait;
	const _sendBuffer = () => {
		if (bufferedData.length && wsRef.value && status.value === "OPEN") {
			for (const buffer of bufferedData) wsRef.value.send(buffer);
			bufferedData = [];
		}
	};
	const resetRetry = () => {
		if (retryTimeout != null) {
			clearTimeout(retryTimeout);
			retryTimeout = void 0;
		}
	};
	const resetHeartbeat = () => {
		clearTimeout(pongTimeoutWait);
		pongTimeoutWait = void 0;
	};
	const close = (code = 1e3, reason) => {
		resetRetry();
		if (!isClient && !isWorker || !wsRef.value) return;
		explicitlyClosed = true;
		resetHeartbeat();
		heartbeatPause == null ? void 0 : heartbeatPause();
		wsRef.value.close(code, reason);
		wsRef.value = void 0;
	};
	const send = (data2, useBuffer = true) => {
		if (!wsRef.value || status.value !== "OPEN") {
			if (useBuffer) bufferedData.push(data2);
			return false;
		}
		_sendBuffer();
		wsRef.value.send(data2);
		return true;
	};
	const _init = () => {
		if (explicitlyClosed || typeof urlRef.value === "undefined") return;
		const ws = new WebSocket(urlRef.value, protocols);
		wsRef.value = ws;
		status.value = "CONNECTING";
		ws.onopen = () => {
			status.value = "OPEN";
			retried = 0;
			onConnected == null ? void 0 : onConnected(ws);
			heartbeatResume == null ? void 0 : heartbeatResume();
			_sendBuffer();
		};
		ws.onclose = (ev) => {
			status.value = "CLOSED";
			resetHeartbeat();
			heartbeatPause == null ? void 0 : heartbeatPause();
			onDisconnected == null ? void 0 : onDisconnected(ws, ev);
			if (!explicitlyClosed && options.autoReconnect && (wsRef.value == null || ws === wsRef.value)) {
				const { retries = -1, delay = 1e3, onFailed } = resolveNestedOptions(options.autoReconnect);
				const checkRetires = typeof retries === "function" ? retries : () => typeof retries === "number" && (retries < 0 || retried < retries);
				if (checkRetires(retried)) {
					retried += 1;
					retryTimeout = setTimeout(_init, delay);
				} else {
					onFailed == null ? void 0 : onFailed();
				}
			}
		};
		ws.onerror = (e) => {
			onError == null ? void 0 : onError(ws, e);
		};
		ws.onmessage = (e) => {
			if (options.heartbeat) {
				resetHeartbeat();
				const { message = DEFAULT_PING_MESSAGE, responseMessage = message } = resolveNestedOptions(options.heartbeat);
				if (e.data === toValue(responseMessage)) return;
			}
			data.value = e.data;
			onMessage == null ? void 0 : onMessage(ws, e);
		};
	};
	if (options.heartbeat) {
		const { message = DEFAULT_PING_MESSAGE, interval = 1e3, pongTimeout = 1e3 } = resolveNestedOptions(options.heartbeat);
		const { pause, resume } = useIntervalFn(() => {
			send(toValue(message), false);
			if (pongTimeoutWait != null) return;
			pongTimeoutWait = setTimeout(() => {
				close();
				explicitlyClosed = false;
			}, pongTimeout);
		}, interval, { immediate: false });
		heartbeatPause = pause;
		heartbeatResume = resume;
	}
	if (autoClose) {
		if (isClient) useEventListener("beforeunload", () => close(), { passive: true });
		tryOnScopeDispose(close);
	}
	const open = () => {
		if (!isClient && !isWorker) return;
		close();
		explicitlyClosed = false;
		retried = 0;
		_init();
	};
	if (immediate) open();
	if (autoConnect) watch(urlRef, open);
	return {
		data,
		status,
		close,
		send,
		open,
		ws: wsRef
	};
}
function useWebWorker(arg0, workerOptions, options) {
	const { window = defaultWindow } = options != null ? options : {};
	const data = ref(null);
	const worker = shallowRef();
	const post = (...args) => {
		if (!worker.value) return;
		worker.value.postMessage(...args);
	};
	const terminate = function terminate2() {
		if (!worker.value) return;
		worker.value.terminate();
	};
	if (window) {
		if (typeof arg0 === "string") worker.value = new Worker(arg0, workerOptions);
		else if (typeof arg0 === "function") worker.value = arg0();
		else worker.value = arg0;
		worker.value.onmessage = (e) => {
			data.value = e.data;
		};
		tryOnScopeDispose(() => {
			if (worker.value) worker.value.terminate();
		});
	}
	return {
		data,
		post,
		terminate,
		worker
	};
}
function depsParser(deps, localDeps) {
	if (deps.length === 0 && localDeps.length === 0) return "";
	const depsString = deps.map((dep) => `'${dep}'`).toString();
	const depsFunctionString = localDeps.filter((dep) => typeof dep === "function").map((fn) => {
		const str = fn.toString();
		if (str.trim().startsWith("function")) {
			return str;
		} else {
			const name = fn.name;
			return `const ${name} = ${str}`;
		}
	}).join(";");
	const importString = `importScripts(${depsString});`;
	return `${depsString.trim() === "" ? "" : importString} ${depsFunctionString}`;
}
function jobRunner(userFunc) {
	return (e) => {
		const userFuncArgs = e.data[0];
		return Promise.resolve(userFunc.apply(void 0, userFuncArgs)).then((result) => {
			postMessage(["SUCCESS", result]);
		}).catch((error) => {
			postMessage(["ERROR", error]);
		});
	};
}
function createWorkerBlobUrl(fn, deps, localDeps) {
	const blobCode = `${depsParser(deps, localDeps)}; onmessage=(${jobRunner})(${fn})`;
	const blob = new Blob([blobCode], { type: "text/javascript" });
	const url = URL.createObjectURL(blob);
	return url;
}
function useWebWorkerFn(fn, options = {}) {
	const { dependencies = [], localDependencies = [], timeout, window = defaultWindow } = options;
	const worker = ref();
	const workerStatus = shallowRef("PENDING");
	const promise = ref({});
	const timeoutId = shallowRef();
	const workerTerminate = (status = "PENDING") => {
		if (worker.value && worker.value._url && window) {
			worker.value.terminate();
			URL.revokeObjectURL(worker.value._url);
			promise.value = {};
			worker.value = void 0;
			window.clearTimeout(timeoutId.value);
			workerStatus.value = status;
		}
	};
	workerTerminate();
	tryOnScopeDispose(workerTerminate);
	const generateWorker = () => {
		const blobUrl = createWorkerBlobUrl(fn, dependencies, localDependencies);
		const newWorker = new Worker(blobUrl);
		newWorker._url = blobUrl;
		newWorker.onmessage = (e) => {
			const { resolve = () => {}, reject = () => {} } = promise.value;
			const [status, result] = e.data;
			switch (status) {
				case "SUCCESS":
					resolve(result);
					workerTerminate(status);
					break;
				default:
					reject(result);
					workerTerminate("ERROR");
					break;
			}
		};
		newWorker.onerror = (e) => {
			const { reject = () => {} } = promise.value;
			e.preventDefault();
			reject(e);
			workerTerminate("ERROR");
		};
		if (timeout) {
			timeoutId.value = setTimeout(() => workerTerminate("TIMEOUT_EXPIRED"), timeout);
		}
		return newWorker;
	};
	const callWorker = (...fnArgs) => new Promise((resolve, reject) => {
		var _a;
		promise.value = {
			resolve,
			reject
		};
		(_a = worker.value) == null ? void 0 : _a.postMessage([[...fnArgs]]);
		workerStatus.value = "RUNNING";
	});
	const workerFn = (...fnArgs) => {
		if (workerStatus.value === "RUNNING") {
			console.error("[useWebWorkerFn] You can only run one instance of the worker at a time.");
			return Promise.reject();
		}
		worker.value = generateWorker();
		return callWorker(...fnArgs);
	};
	return {
		workerFn,
		workerStatus,
		workerTerminate
	};
}
// @__NO_SIDE_EFFECTS__
function useWindowFocus(options = {}) {
	const { window = defaultWindow } = options;
	if (!window) return shallowRef(false);
	const focused = shallowRef(window.document.hasFocus());
	const listenerOptions = { passive: true };
	useEventListener(window, "blur", () => {
		focused.value = false;
	}, listenerOptions);
	useEventListener(window, "focus", () => {
		focused.value = true;
	}, listenerOptions);
	return focused;
}
function useWindowScroll(options = {}) {
	const { window = defaultWindow, ...rest } = options;
	return useScroll(window, rest);
}
// @__NO_SIDE_EFFECTS__
function useWindowSize(options = {}) {
	const { window = defaultWindow, initialWidth = Number.POSITIVE_INFINITY, initialHeight = Number.POSITIVE_INFINITY, listenOrientation = true, includeScrollbar = true, type = "inner" } = options;
	const width = shallowRef(initialWidth);
	const height = shallowRef(initialHeight);
	const update = () => {
		if (window) {
			if (type === "outer") {
				width.value = window.outerWidth;
				height.value = window.outerHeight;
			} else if (type === "visual" && window.visualViewport) {
				const { width: visualViewportWidth, height: visualViewportHeight, scale } = window.visualViewport;
				width.value = Math.round(visualViewportWidth * scale);
				height.value = Math.round(visualViewportHeight * scale);
			} else if (includeScrollbar) {
				width.value = window.innerWidth;
				height.value = window.innerHeight;
			} else {
				width.value = window.document.documentElement.clientWidth;
				height.value = window.document.documentElement.clientHeight;
			}
		}
	};
	update();
	tryOnMounted(update);
	const listenerOptions = { passive: true };
	useEventListener("resize", update, listenerOptions);
	if (window && type === "visual" && window.visualViewport) {
		useEventListener(window.visualViewport, "resize", update, listenerOptions);
	}
	if (listenOrientation) {
		const matches = useMediaQuery("(orientation: portrait)");
		watch(matches, () => update());
	}
	return {
		width,
		height
	};
}
export { DefaultMagicKeysAliasMap, StorageSerializers, TransitionPresets, computedAsync as asyncComputed, breakpointsAntDesign, breakpointsBootstrapV5, breakpointsElement, breakpointsMasterCss, breakpointsPrimeFlex, breakpointsQuasar, breakpointsSematic, breakpointsTailwind, breakpointsVuetify, breakpointsVuetifyV2, breakpointsVuetifyV3, cloneFnJSON, computedAsync, computedInject, createFetch, createReusableTemplate, createTemplatePromise, createUnrefFn, customStorageEventName, defaultDocument, defaultLocation, defaultNavigator, defaultWindow, executeTransition, formatTimeAgo, formatTimeAgoIntl, formatTimeAgoIntlParts, getSSRHandler, mapGamepadToXbox360Controller, onClickOutside, onElementRemoval, onKeyDown, onKeyPressed, onKeyStroke, onKeyUp, onLongPress, onStartTyping, provideSSRWidth, setSSRHandler, templateRef, unrefElement, useActiveElement, useAnimate, useAsyncQueue, useAsyncState, useBase64, useBattery, useBluetooth, useBreakpoints, useBroadcastChannel, useBrowserLocation, useCached, useClipboard, useClipboardItems, useCloned, useColorMode, useConfirmDialog, useCountdown, useCssVar, useCurrentElement, useCycleList, useDark, useDebouncedRefHistory, useDeviceMotion, useDeviceOrientation, useDevicePixelRatio, useDevicesList, useDisplayMedia, useDocumentVisibility, useDraggable, useDropZone, useElementBounding, useElementByPoint, useElementHover, useElementSize, useElementVisibility, useEventBus, useEventListener, useEventSource, useEyeDropper, useFavicon, useFetch, useFileDialog, useFileSystemAccess, useFocus, useFocusWithin, useFps, useFullscreen, useGamepad, useGeolocation, useIdle, useImage, useInfiniteScroll, useIntersectionObserver, useKeyModifier, useLocalStorage, useMagicKeys, useManualRefHistory, useMediaControls, useMediaQuery, useMemoize, useMemory, useMounted, useMouse, useMouseInElement, useMousePressed, useMutationObserver, useNavigatorLanguage, useNetwork, useNow, useObjectUrl, useOffsetPagination, useOnline, usePageLeave, useParallax, useParentElement, usePerformanceObserver, usePermission, usePointer, usePointerLock, usePointerSwipe, usePreferredColorScheme, usePreferredContrast, usePreferredDark, usePreferredLanguages, usePreferredReducedMotion, usePreferredReducedTransparency, usePrevious, useRafFn, useRefHistory, useResizeObserver, useSSRWidth, useScreenOrientation, useScreenSafeArea, useScriptTag, useScroll, useScrollLock, useSessionStorage, useShare, useSorted, useSpeechRecognition, useSpeechSynthesis, useStepper, useStorage, useStorageAsync, useStyleTag, useSupported, useSwipe, useTemplateRefsList, useTextDirection, useTextSelection, useTextareaAutosize, useThrottledRefHistory, useTimeAgo, useTimeAgoIntl, useTimeoutPoll, useTimestamp, useTitle, useTransition, useUrlSearchParams, useUserMedia, useVModel, useVModels, useVibrate, useVirtualList, useWakeLock, useWebNotification, useWebSocket, useWebWorker, useWebWorkerFn, useWindowFocus, useWindowScroll, useWindowSize };

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLG9CQUFvQixVQUFVLFVBQVUsU0FBUyxnQkFBZ0IsVUFBVSxtQkFBbUIsT0FBTyxZQUFZLGNBQWMsWUFBWSxnQkFBZ0IsT0FBTyxhQUFhLGNBQWMsU0FBUyxrQkFBa0IsZUFBZSxXQUFXLHdCQUF3QixjQUFjLGVBQWUsT0FBTyxpQkFBaUIsZUFBZSxxQkFBcUIsV0FBVyxnQkFBZ0IsZ0JBQWdCLGdCQUFnQixjQUFjLHFCQUFxQixRQUFRLFdBQVcsY0FBYyxRQUFRLGdCQUFnQixlQUFlLGVBQWUsZ0JBQWdCLE9BQU8sU0FBUyxZQUFZLGlCQUFpQixVQUFVLE9BQU8sVUFBVSxnQkFBZ0I7QUFDL29CLGNBQWM7QUFDZCxTQUFTLE9BQU8sWUFBWSxLQUFLLGFBQWEsVUFBVSxRQUFRLGlCQUFpQixHQUFHLGlCQUFpQixVQUFVLGlCQUFpQixTQUFTLE9BQU8sb0JBQW9CLFdBQVcsT0FBTyxXQUFXLFdBQVcsVUFBVSxVQUFVLHFCQUFxQixPQUFPLGlCQUFpQixVQUFVLFNBQVMsaUJBQWlCLFlBQVksc0JBQXNCO0FBRW5WLFNBQVMsY0FBYyxvQkFBb0IsY0FBYyxjQUFjO0NBQ3JFLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSSxNQUFNLFlBQVksR0FBRztFQUN2QixVQUFVLEVBQ1IsWUFBWSxhQUNkO0NBQ0YsT0FBTztFQUNMLFVBQVUsZ0JBQWdCLENBQUM7Q0FDN0I7Q0FDQSxNQUFNLEVBQ0osT0FBTyxPQUNQLFFBQVEsT0FDUixhQUFhLEtBQUssR0FDbEIsVUFBVSxNQUNWLFdBQVcsS0FBSyxXQUFXLGdCQUFnQixPQUFPLEtBQUssU0FDckQ7Q0FDSixNQUFNLFVBQVUsV0FBVyxDQUFDLElBQUk7Q0FDaEMsTUFBTSxVQUFVLFVBQVUsV0FBVyxZQUFZLElBQUksSUFBSSxZQUFZO0NBQ3JFLElBQUksVUFBVTtDQUNkLFlBQVksT0FBTyxpQkFBaUI7RUFDbEMsSUFBSSxDQUFDLFFBQVEsT0FDWDtFQUNGO0VBQ0EsTUFBTSxxQkFBcUI7RUFDM0IsSUFBSSxjQUFjO0VBQ2xCLElBQUksWUFBWTtHQUNkLFFBQVEsUUFBUSxDQUFDLENBQUMsV0FBVztJQUMzQixXQUFXLFFBQVE7R0FDckIsQ0FBQztFQUNIO0VBQ0EsSUFBSTtHQUNGLE1BQU0sU0FBUyxNQUFNLG9CQUFvQixtQkFBbUI7SUFDMUQsbUJBQW1CO0tBQ2pCLElBQUksWUFDRixXQUFXLFFBQVE7S0FDckIsSUFBSSxDQUFDLGFBQ0gsZUFBZTtJQUNuQixDQUFDO0dBQ0gsQ0FBQztHQUNELElBQUksdUJBQXVCLFNBQ3pCLFFBQVEsUUFBUTtFQUNwQixTQUFTLEdBQUc7R0FDVixRQUFRLENBQUM7RUFDWCxVQUFVO0dBQ1IsSUFBSSxjQUFjLHVCQUF1QixTQUN2QyxXQUFXLFFBQVE7R0FDckIsY0FBYztFQUNoQjtDQUNGLEdBQUcsRUFBRSxNQUFNLENBQUM7Q0FDWixJQUFJLE1BQU07RUFDUixPQUFPLGVBQWU7R0FDcEIsUUFBUSxRQUFRO0dBQ2hCLE9BQU8sUUFBUTtFQUNqQixDQUFDO0NBQ0gsT0FBTztFQUNMLE9BQU87Q0FDVDtBQUNGO0FBRUEsU0FBUyxlQUFlLEtBQUssU0FBUyxlQUFlLHVCQUF1QjtDQUMxRSxJQUFJLFNBQVMsT0FBTyxHQUFHO0NBQ3ZCLElBQUksZUFDRixTQUFTLE9BQU8sS0FBSyxhQUFhO0NBQ3BDLElBQUksdUJBQ0YsU0FBUyxPQUFPLEtBQUssZUFBZSxxQkFBcUI7Q0FDM0QsSUFBSSxPQUFPLFlBQVksWUFBWTtFQUNqQyxPQUFPLFVBQVUsYUFBYSxRQUFRLFFBQVEsUUFBUSxDQUFDO0NBQ3pELE9BQU87RUFDTCxPQUFPLFNBQVM7R0FDZCxNQUFNLGFBQWEsUUFBUSxJQUFJLFFBQVEsUUFBUTtHQUMvQyxLQUFLLFFBQVE7RUFDZixDQUFDO0NBQ0g7QUFDRjs7QUFHQSxTQUFTLHVCQUF1QixVQUFVLENBQUMsR0FBRztDQUM1QyxNQUFNLEVBQ0osZUFBZSxTQUNiO0NBQ0osTUFBTSxTQUFTLFdBQVc7Q0FDMUIsTUFBTSxTQUF1Qiw4QkFBZ0IsRUFDM0MsTUFBTSxHQUFHLEVBQUUsU0FBUztFQUNsQixhQUFhO0dBQ1gsT0FBTyxRQUFRLE1BQU07RUFDdkI7Q0FDRixFQUNGLENBQUM7Q0FDRCxNQUFNLFFBQXNCLDhCQUFnQjtFQUMxQztFQUNBLE9BQU8sUUFBUTtFQUNmLE1BQU0sT0FBTyxFQUFFLE9BQU8sU0FBUztHQUM3QixhQUFhO0lBQ1gsSUFBSTtJQUNKLElBQUksQ0FBQyxPQUFPLDJCQUFrQyxjQUM1QyxNQUFNLElBQUksTUFBTSw2REFBNkQ7SUFDL0UsTUFBTSxTQUFTLEtBQUssT0FBTyxVQUFVLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxRQUFRO0tBQ25FLEdBQUcsUUFBUSxTQUFTLE9BQU8scUJBQXFCLEtBQUssSUFBSTtLQUN6RCxRQUFRO0lBQ1YsQ0FBQztJQUNELE9BQU8saUJBQWlCLFNBQVMsT0FBTyxLQUFLLElBQUksTUFBTSxZQUFZLElBQUksTUFBTSxLQUFLO0dBQ3BGO0VBQ0Y7Q0FDRixDQUFDO0NBQ0QsT0FBTyxtQkFDTDtFQUFFO0VBQVE7Q0FBTSxHQUNoQixDQUFDLFFBQVEsS0FBSyxDQUNoQjtBQUNGO0FBQ0EsU0FBUyxxQkFBcUIsS0FBSztDQUNqQyxNQUFNLFNBQVMsQ0FBQztDQUNoQixLQUFLLE1BQU0sT0FBTyxLQUNoQixPQUFPLFNBQVMsR0FBRyxLQUFLLElBQUk7Q0FDOUIsT0FBTztBQUNUOztBQUdBLFNBQVMsc0JBQXNCLFVBQVUsQ0FBQyxHQUFHO0NBQzNDLElBQUksUUFBUTtDQUNaLE1BQU0sWUFBWSxJQUFJLENBQUMsQ0FBQztDQUN4QixTQUFTLE9BQU8sR0FBRyxNQUFNO0VBQ3ZCLE1BQU0sUUFBUSxnQkFBZ0I7R0FDNUIsS0FBSztHQUNMO0dBQ0EsU0FBUyxLQUFLO0dBQ2QsZUFBZSxDQUNmO0dBQ0EsY0FBYyxDQUNkO0dBQ0EsYUFBYTtHQUNiO0VBQ0YsQ0FBQztFQUNELFVBQVUsTUFBTSxLQUFLLEtBQUs7RUFDMUIsTUFBTSxVQUFVLElBQUksU0FBUyxVQUFVLFlBQVk7R0FDakQsTUFBTSxXQUFXLE1BQU07SUFDckIsTUFBTSxjQUFjO0lBQ3BCLE9BQU8sU0FBUyxDQUFDO0dBQ25CO0dBQ0EsTUFBTSxTQUFTO0VBQ2pCLENBQUMsQ0FBQyxDQUFDLGNBQWM7R0FDZixNQUFNLFVBQVUsS0FBSztHQUNyQixNQUFNLFNBQVMsVUFBVSxNQUFNLFFBQVEsS0FBSztHQUM1QyxJQUFJLFdBQVcsQ0FBQyxHQUNkLFVBQVUsTUFBTSxPQUFPLFFBQVEsQ0FBQztFQUNwQyxDQUFDO0VBQ0QsT0FBTyxNQUFNO0NBQ2Y7Q0FDQSxTQUFTLE1BQU0sR0FBRyxNQUFNO0VBQ3RCLElBQUksUUFBUSxhQUFhLFVBQVUsTUFBTSxTQUFTLEdBQ2hELE9BQU8sVUFBVSxNQUFNLEVBQUUsQ0FBQztFQUM1QixPQUFPLE9BQU8sR0FBRyxJQUFJO0NBQ3ZCO0NBQ0EsTUFBTSxZQUEwQiwrQkFBaUIsR0FBRyxFQUFFLFlBQVk7RUFDaEUsTUFBTSxtQkFBbUIsVUFBVSxNQUFNLEtBQUssVUFBVTtHQUN0RCxJQUFJO0dBQ0osT0FBTyxFQUFFLFVBQVUsRUFBRSxLQUFLLE1BQU0sSUFBSSxJQUFJLEtBQUssTUFBTSxZQUFZLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxPQUFPLEtBQUssQ0FBQztFQUN0RyxDQUFDO0VBQ0QsSUFBSSxRQUFRLFlBQ1YsYUFBYSxFQUFFLGlCQUFpQixRQUFRLFlBQVksVUFBVTtFQUNoRSxPQUFPO0NBQ1QsQ0FBQztDQUNELFVBQVUsUUFBUTtDQUNsQixPQUFPO0FBQ1Q7O0FBR0EsU0FBUyxjQUFjLElBQUk7Q0FDekIsT0FBTyxTQUFTLEdBQUcsTUFBTTtFQUN2QixPQUFPLEdBQUcsTUFBTSxNQUFNLEtBQUssS0FBSyxNQUFNLFFBQVEsQ0FBQyxDQUFDLENBQUM7Q0FDbkQ7QUFDRjtBQUVBLE1BQU0sZ0JBQWdCLFdBQVcsU0FBUyxLQUFLO0FBQy9DLE1BQU0sa0JBQWtCLFdBQVcsT0FBTyxXQUFXLEtBQUs7QUFDMUQsTUFBTSxtQkFBbUIsV0FBVyxPQUFPLFlBQVksS0FBSztBQUM1RCxNQUFNLGtCQUFrQixXQUFXLE9BQU8sV0FBVyxLQUFLO0FBRTFELFNBQVMsYUFBYSxPQUFPO0NBQzNCLElBQUk7Q0FDSixNQUFNLFFBQVEsUUFBUSxLQUFLO0NBQzNCLFFBQVEsS0FBSyxTQUFTLE9BQU8sS0FBSyxJQUFJLE1BQU0sUUFBUSxPQUFPLEtBQUs7QUFDbEU7QUFFQSxTQUFTLGlCQUFpQixHQUFHLE1BQU07Q0FDakMsTUFBTSxXQUFXLENBQUM7Q0FDbEIsTUFBTSxnQkFBZ0I7RUFDcEIsU0FBUyxTQUFTLE9BQU8sR0FBRyxDQUFDO0VBQzdCLFNBQVMsU0FBUztDQUNwQjtDQUNBLE1BQU0sWUFBWSxJQUFJLE9BQU8sVUFBVSxZQUFZO0VBQ2pELEdBQUcsaUJBQWlCLE9BQU8sVUFBVSxPQUFPO0VBQzVDLGFBQWEsR0FBRyxvQkFBb0IsT0FBTyxVQUFVLE9BQU87Q0FDOUQ7Q0FDQSxNQUFNLG9CQUFvQixlQUFlO0VBQ3ZDLE1BQU0sT0FBTyxRQUFRLFFBQVEsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsTUFBTSxLQUFLLElBQUk7RUFDOUQsT0FBTyxLQUFLLE9BQU8sTUFBTSxPQUFPLE1BQU0sUUFBUSxJQUFJLE9BQU8sS0FBSztDQUNoRSxDQUFDO0NBQ0QsTUFBTSxZQUFZLHFCQUNWO0VBQ0osSUFBSSxJQUFJO0VBQ1IsT0FBTztJQUNKLE1BQU0sS0FBSyxrQkFBa0IsVUFBVSxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssTUFBTSxhQUFhLENBQUMsQ0FBQyxNQUFNLE9BQU8sS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFFBQVEsTUFBTSxLQUFLLElBQUk7R0FDOUksUUFBUSxRQUFRLGtCQUFrQixRQUFRLEtBQUssS0FBSyxLQUFLLEVBQUUsQ0FBQztHQUM1RCxRQUFRLE1BQU0sa0JBQWtCLFFBQVEsS0FBSyxLQUFLLEtBQUssRUFBRSxDQUFDO0dBRTFELFFBQVEsa0JBQWtCLFFBQVEsS0FBSyxLQUFLLEtBQUssRUFBRTtFQUNyRDtDQUNGLElBQ0MsQ0FBQyxhQUFhLFlBQVksZUFBZSxpQkFBaUI7RUFDekQsUUFBUTtFQUNSLElBQUksRUFBRSxlQUFlLE9BQU8sS0FBSyxJQUFJLFlBQVksV0FBVyxFQUFFLGNBQWMsT0FBTyxLQUFLLElBQUksV0FBVyxXQUFXLEVBQUUsaUJBQWlCLE9BQU8sS0FBSyxJQUFJLGNBQWMsU0FDaks7RUFDRixNQUFNLGVBQWUsU0FBUyxXQUFXLElBQUksRUFBRSxHQUFHLFlBQVksSUFBSTtFQUNsRSxTQUFTLEtBQ1AsR0FBRyxZQUFZLFNBQ1osT0FBTyxXQUFXLFNBQ2hCLFVBQVUsY0FBYyxLQUFLLGFBQWEsU0FBUyxJQUFJLE9BQU8sVUFBVSxZQUFZLENBQUMsQ0FDeEYsQ0FDRixDQUNGO0NBQ0YsR0FDQSxFQUFFLE9BQU8sT0FBTyxDQUNsQjtDQUNBLE1BQU0sYUFBYTtFQUNqQixVQUFVO0VBQ1YsUUFBUTtDQUNWO0NBQ0Esa0JBQWtCLE9BQU87Q0FDekIsT0FBTztBQUNUO0FBRUEsSUFBSSxpQkFBaUI7QUFDckIsU0FBUyxlQUFlLFFBQVEsU0FBUyxVQUFVLENBQUMsR0FBRztDQUNyRCxNQUFNLEVBQUUsU0FBUyxlQUFlLFNBQVMsQ0FBQyxHQUFHLFVBQVUsTUFBTSxlQUFlLE9BQU8sV0FBVyxVQUFVO0NBQ3hHLElBQUksQ0FBQyxRQUFRO0VBQ1gsT0FBTyxXQUFXO0dBQUUsTUFBTTtHQUFNLFFBQVE7R0FBTSxTQUFTO0VBQUssSUFBSTtDQUNsRTtDQUNBLElBQUksU0FBUyxDQUFDLGdCQUFnQjtFQUM1QixpQkFBaUI7RUFDakIsTUFBTSxrQkFBa0IsRUFBRSxTQUFTLEtBQUs7RUFDeEMsTUFBTSxLQUFLLE9BQU8sU0FBUyxLQUFLLFFBQVEsQ0FBQyxDQUFDLFNBQVMsT0FBTyxHQUFHLGlCQUFpQixTQUFTLE1BQU0sZUFBZSxDQUFDO0VBQzdHLE9BQU8sU0FBUyxnQkFBZ0IsaUJBQWlCLFNBQVMsTUFBTSxlQUFlO0NBQ2pGO0NBQ0EsSUFBSSxlQUFlO0NBQ25CLE1BQU0sZ0JBQWdCLFVBQVU7RUFDOUIsT0FBTyxRQUFRLE1BQU0sQ0FBQyxDQUFDLE1BQU0sWUFBWTtHQUN2QyxJQUFJLE9BQU8sWUFBWSxVQUFVO0lBQy9CLE9BQU8sTUFBTSxLQUFLLE9BQU8sU0FBUyxpQkFBaUIsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLE9BQU8sT0FBTyxNQUFNLFVBQVUsTUFBTSxhQUFhLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQztHQUNwSSxPQUFPO0lBQ0wsTUFBTSxLQUFLLGFBQWEsT0FBTztJQUMvQixPQUFPLE9BQU8sTUFBTSxXQUFXLE1BQU0sTUFBTSxhQUFhLENBQUMsQ0FBQyxTQUFTLEVBQUU7R0FDdkU7RUFDRixDQUFDO0NBQ0g7Q0FDQSxTQUFTLGlCQUFpQixTQUFTO0VBQ2pDLE1BQU0sS0FBSyxRQUFRLE9BQU87RUFDMUIsT0FBTyxNQUFNLEdBQUcsRUFBRSxRQUFRLGNBQWM7Q0FDMUM7Q0FDQSxTQUFTLG1CQUFtQixTQUFTLE9BQU87RUFDMUMsTUFBTSxLQUFLLFFBQVEsT0FBTztFQUMxQixNQUFNLFdBQVcsR0FBRyxFQUFFLFdBQVcsR0FBRyxFQUFFLFFBQVE7RUFDOUMsSUFBSSxZQUFZLFFBQVEsQ0FBQyxNQUFNLFFBQVEsUUFBUSxHQUM3QyxPQUFPO0VBQ1QsT0FBTyxTQUFTLE1BQU0sVUFBVSxNQUFNLE9BQU8sTUFBTSxVQUFVLE1BQU0sYUFBYSxDQUFDLENBQUMsU0FBUyxNQUFNLEVBQUUsQ0FBQztDQUN0RztDQUNBLE1BQU0sWUFBWSxVQUFVO0VBQzFCLE1BQU0sS0FBSyxhQUFhLE1BQU07RUFDOUIsSUFBSSxNQUFNLFVBQVUsTUFDbEI7RUFDRixJQUFJLEVBQUUsY0FBYyxZQUFZLGlCQUFpQixNQUFNLEtBQUssbUJBQW1CLFFBQVEsS0FBSyxHQUMxRjtFQUNGLElBQUksQ0FBQyxNQUFNLE9BQU8sTUFBTSxVQUFVLE1BQU0sYUFBYSxDQUFDLENBQUMsU0FBUyxFQUFFLEdBQ2hFO0VBQ0YsSUFBSSxZQUFZLFNBQVMsTUFBTSxXQUFXLEdBQ3hDLGVBQWUsQ0FBQyxhQUFhLEtBQUs7RUFDcEMsSUFBSSxDQUFDLGNBQWM7R0FDakIsZUFBZTtHQUNmO0VBQ0Y7RUFDQSxRQUFRLEtBQUs7Q0FDZjtDQUNBLElBQUksb0JBQW9CO0NBQ3hCLE1BQU0sVUFBVTtFQUNkLGlCQUFpQixRQUFRLFVBQVUsVUFBVTtHQUMzQyxJQUFJLENBQUMsbUJBQW1CO0lBQ3RCLG9CQUFvQjtJQUNwQixpQkFBaUI7S0FDZixvQkFBb0I7SUFDdEIsR0FBRyxDQUFDO0lBQ0osU0FBUyxLQUFLO0dBQ2hCO0VBQ0YsR0FBRztHQUFFLFNBQVM7R0FBTTtFQUFRLENBQUM7RUFDN0IsaUJBQWlCLFFBQVEsZ0JBQWdCLE1BQU07R0FDN0MsTUFBTSxLQUFLLGFBQWEsTUFBTTtHQUM5QixlQUFlLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxFQUFFLE1BQU0sQ0FBQyxFQUFFLGFBQWEsQ0FBQyxDQUFDLFNBQVMsRUFBRTtFQUMzRSxHQUFHLEVBQUUsU0FBUyxLQUFLLENBQUM7RUFDcEIsZ0JBQWdCLGlCQUFpQixRQUFRLFNBQVMsVUFBVTtHQUMxRCxpQkFBaUI7SUFDZixJQUFJO0lBQ0osTUFBTSxLQUFLLGFBQWEsTUFBTTtJQUM5QixNQUFNLEtBQUssT0FBTyxTQUFTLGtCQUFrQixPQUFPLEtBQUssSUFBSSxHQUFHLGFBQWEsWUFBWSxFQUFFLE1BQU0sT0FBTyxLQUFLLElBQUksR0FBRyxTQUFTLE9BQU8sU0FBUyxhQUFhLElBQUk7S0FDNUosUUFBUSxLQUFLO0lBQ2Y7R0FDRixHQUFHLENBQUM7RUFDTixHQUFHLEVBQUUsU0FBUyxLQUFLLENBQUM7Q0FDdEIsQ0FBQyxDQUFDLE9BQU8sT0FBTztDQUNoQixNQUFNLGFBQWEsUUFBUSxTQUFTLE9BQU8sR0FBRyxDQUFDO0NBQy9DLElBQUksVUFBVTtFQUNaLE9BQU87R0FDTDtHQUNBLGNBQWM7SUFDWixlQUFlO0dBQ2pCO0dBQ0EsVUFBVSxVQUFVO0lBQ2xCLGVBQWU7SUFDZixTQUFTLEtBQUs7SUFDZCxlQUFlO0dBQ2pCO0VBQ0Y7Q0FDRjtDQUNBLE9BQU87QUFDVDs7QUFHQSxTQUFTLGFBQWE7Q0FDcEIsTUFBTSxZQUFZLFdBQVcsS0FBSztDQUNsQyxNQUFNLFdBQVcsbUJBQW1CO0NBQ3BDLElBQUksVUFBVTtFQUNaLGdCQUFnQjtHQUNkLFVBQVUsUUFBUTtFQUNwQixHQUFHLFFBQVE7Q0FDYjtDQUNBLE9BQU87QUFDVDs7QUFHQSxTQUFTLGFBQWEsVUFBVTtDQUM5QixNQUFNLFlBQVksV0FBVztDQUM3QixPQUFPLGVBQWU7RUFDcEIsVUFBVTtFQUNWLE9BQU8sUUFBUSxTQUFTLENBQUM7Q0FDM0IsQ0FBQztBQUNIO0FBRUEsU0FBUyxvQkFBb0IsUUFBUSxVQUFVLFVBQVUsQ0FBQyxHQUFHO0NBQzNELE1BQU0sRUFBRSxTQUFTLGVBQWUsR0FBRyxvQkFBb0I7Q0FDdkQsSUFBSTtDQUNKLE1BQU0sY0FBYyxtQkFBbUIsVUFBVSxzQkFBc0IsTUFBTTtDQUM3RSxNQUFNLGdCQUFnQjtFQUNwQixJQUFJLFVBQVU7R0FDWixTQUFTLFdBQVc7R0FDcEIsV0FBVyxLQUFLO0VBQ2xCO0NBQ0Y7Q0FDQSxNQUFNLFVBQVUsZUFBZTtFQUM3QixNQUFNLFFBQVEsUUFBUSxNQUFNO0VBQzVCLE1BQU0sUUFBUSxRQUFRLEtBQUssQ0FBQyxDQUFDLElBQUksWUFBWSxDQUFDLENBQUMsT0FBTyxVQUFVO0VBQ2hFLE9BQU8sSUFBSSxJQUFJLEtBQUs7Q0FDdEIsQ0FBQztDQUNELE1BQU0sWUFBWSxNQUNoQixVQUNDLGVBQWU7RUFDZCxRQUFRO0VBQ1IsSUFBSSxZQUFZLFNBQVMsV0FBVyxNQUFNO0dBQ3hDLFdBQVcsSUFBSSxpQkFBaUIsUUFBUTtHQUN4QyxXQUFXLFNBQVMsT0FBTyxTQUFTLFFBQVEsSUFBSSxlQUFlLENBQUM7RUFDbEU7Q0FDRixHQUNBO0VBQUUsV0FBVztFQUFNLE9BQU87Q0FBTyxDQUNuQztDQUNBLE1BQU0sb0JBQW9CO0VBQ3hCLE9BQU8sWUFBWSxPQUFPLEtBQUssSUFBSSxTQUFTLFlBQVk7Q0FDMUQ7Q0FDQSxNQUFNLGFBQWE7RUFDakIsVUFBVTtFQUNWLFFBQVE7Q0FDVjtDQUNBLGtCQUFrQixJQUFJO0NBQ3RCLE9BQU87RUFDTDtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsU0FBUyxpQkFBaUIsUUFBUSxVQUFVLFVBQVUsQ0FBQyxHQUFHO0NBQ3hELE1BQU0sRUFDSixTQUFTLGVBQ1QsV0FBVyxVQUFVLE9BQU8sS0FBSyxJQUFJLE9BQU8sVUFDNUMsUUFBUSxXQUNOO0NBQ0osSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUNkLE9BQU87Q0FDVCxJQUFJO0NBQ0osTUFBTSxvQkFBb0IsT0FBTztFQUMvQixVQUFVLE9BQU8sS0FBSyxJQUFJLE9BQU87RUFDakMsU0FBUztDQUNYO0NBQ0EsTUFBTSxZQUFZLGtCQUFrQjtFQUNsQyxNQUFNLEtBQUssYUFBYSxNQUFNO0VBQzlCLElBQUksSUFBSTtHQUNOLE1BQU0sRUFBRSxTQUFTLG9CQUNmLFdBQ0Msa0JBQWtCO0lBQ2pCLE1BQU0sZ0JBQWdCLGNBQWMsS0FBSyxhQUFhLENBQUMsR0FBRyxTQUFTLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxTQUFTLFNBQVMsTUFBTSxLQUFLLFNBQVMsRUFBRSxDQUFDO0lBQ3hJLElBQUksZUFBZTtLQUNqQixTQUFTLGFBQWE7SUFDeEI7R0FDRixHQUNBO0lBQ0U7SUFDQSxXQUFXO0lBQ1gsU0FBUztHQUNYLENBQ0Y7R0FDQSxpQkFBaUIsSUFBSTtFQUN2QjtDQUNGLEdBQUcsRUFBRSxNQUFNLENBQUM7Q0FDWixNQUFNLG1CQUFtQjtFQUN2QixVQUFVO0VBQ1YsaUJBQWlCO0NBQ25CO0NBQ0Esa0JBQWtCLFVBQVU7Q0FDNUIsT0FBTztBQUNUO0FBRUEsU0FBUyxtQkFBbUIsV0FBVztDQUNyQyxJQUFJLE9BQU8sY0FBYyxZQUN2QixPQUFPO01BQ0osSUFBSSxPQUFPLGNBQWMsVUFDNUIsUUFBUSxVQUFVLE1BQU0sUUFBUTtNQUM3QixJQUFJLE1BQU0sUUFBUSxTQUFTLEdBQzlCLFFBQVEsVUFBVSxVQUFVLFNBQVMsTUFBTSxHQUFHO0NBQ2hELGFBQWE7QUFDZjtBQUNBLFNBQVMsWUFBWSxHQUFHLE1BQU07Q0FDNUIsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJLFVBQVUsQ0FBQztDQUNmLElBQUksS0FBSyxXQUFXLEdBQUc7RUFDckIsTUFBTSxLQUFLO0VBQ1gsVUFBVSxLQUFLO0VBQ2YsVUFBVSxLQUFLO0NBQ2pCLE9BQU8sSUFBSSxLQUFLLFdBQVcsR0FBRztFQUM1QixJQUFJLE9BQU8sS0FBSyxPQUFPLFVBQVU7R0FDL0IsTUFBTTtHQUNOLFVBQVUsS0FBSztHQUNmLFVBQVUsS0FBSztFQUNqQixPQUFPO0dBQ0wsTUFBTSxLQUFLO0dBQ1gsVUFBVSxLQUFLO0VBQ2pCO0NBQ0YsT0FBTztFQUNMLE1BQU07RUFDTixVQUFVLEtBQUs7Q0FDakI7Q0FDQSxNQUFNLEVBQ0osU0FBUyxlQUNULFlBQVksV0FDWixVQUFVLE9BQ1YsU0FBUyxVQUNQO0NBQ0osTUFBTSxZQUFZLG1CQUFtQixHQUFHO0NBQ3hDLE1BQU0sWUFBWSxNQUFNO0VBQ3RCLElBQUksRUFBRSxVQUFVLFFBQVEsTUFBTSxHQUM1QjtFQUNGLElBQUksVUFBVSxDQUFDLEdBQ2IsUUFBUSxDQUFDO0NBQ2I7Q0FDQSxPQUFPLGlCQUFpQixRQUFRLFdBQVcsVUFBVSxPQUFPO0FBQzlEO0FBQ0EsU0FBUyxVQUFVLEtBQUssU0FBUyxVQUFVLENBQUMsR0FBRztDQUM3QyxPQUFPLFlBQVksS0FBSyxTQUFTO0VBQUUsR0FBRztFQUFTLFdBQVc7Q0FBVSxDQUFDO0FBQ3ZFO0FBQ0EsU0FBUyxhQUFhLEtBQUssU0FBUyxVQUFVLENBQUMsR0FBRztDQUNoRCxPQUFPLFlBQVksS0FBSyxTQUFTO0VBQUUsR0FBRztFQUFTLFdBQVc7Q0FBVyxDQUFDO0FBQ3hFO0FBQ0EsU0FBUyxRQUFRLEtBQUssU0FBUyxVQUFVLENBQUMsR0FBRztDQUMzQyxPQUFPLFlBQVksS0FBSyxTQUFTO0VBQUUsR0FBRztFQUFTLFdBQVc7Q0FBUSxDQUFDO0FBQ3JFO0FBRUEsTUFBTSxnQkFBZ0I7QUFDdEIsTUFBTSxvQkFBb0I7QUFDMUIsU0FBUyxZQUFZLFFBQVEsU0FBUyxTQUFTO0NBQzdDLElBQUksSUFBSTtDQUNSLE1BQU0sYUFBYSxlQUFlLGFBQWEsTUFBTSxDQUFDO0NBQ3RELElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUksaUJBQWlCO0NBQ3JCLFNBQVMsUUFBUTtFQUNmLElBQUksU0FBUztHQUNYLGFBQWEsT0FBTztHQUNwQixVQUFVLEtBQUs7RUFDakI7RUFDQSxXQUFXLEtBQUs7RUFDaEIsaUJBQWlCLEtBQUs7RUFDdEIsaUJBQWlCO0NBQ25CO0NBQ0EsU0FBUyxTQUFTLElBQUk7RUFDcEIsTUFBTSxRQUFRLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUTtFQUNqRCxJQUFJLE9BQU8sVUFBVSxZQUFZO0dBQy9CLE9BQU8sTUFBTSxFQUFFO0VBQ2pCO0VBQ0EsT0FBTyxTQUFTLE9BQU8sUUFBUTtDQUNqQztDQUNBLFNBQVMsVUFBVSxJQUFJO0VBQ3JCLElBQUksS0FBSyxLQUFLO0VBQ2QsTUFBTSxDQUFDLGlCQUFpQixXQUFXLG1CQUFtQjtHQUFDO0dBQWdCO0dBQVU7RUFBYztFQUMvRixNQUFNO0VBQ04sSUFBSSxFQUFFLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxjQUFjLENBQUMsYUFBYSxDQUFDLGlCQUNwRTtFQUNGLE1BQU0sTUFBTSxXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsY0FBYyxPQUFPLEtBQUssSUFBSSxJQUFJLFNBQVMsR0FBRyxXQUFXLFdBQVcsT0FDakg7RUFDRixLQUFLLE1BQU0sV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLGNBQWMsT0FBTyxLQUFLLElBQUksSUFBSSxTQUM5RSxHQUFHLGVBQWU7RUFDcEIsS0FBSyxLQUFLLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxjQUFjLE9BQU8sS0FBSyxJQUFJLEdBQUcsTUFDNUUsR0FBRyxnQkFBZ0I7RUFDckIsTUFBTSxLQUFLLEdBQUcsSUFBSSxVQUFVO0VBQzVCLE1BQU0sS0FBSyxHQUFHLElBQUksVUFBVTtFQUM1QixNQUFNLFdBQVcsS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEVBQUU7RUFDNUMsUUFBUSxVQUFVLEdBQUcsWUFBWSxpQkFBaUIsVUFBVSxlQUFlO0NBQzdFO0NBQ0EsU0FBUyxPQUFPLElBQUk7RUFDbEIsSUFBSSxLQUFLLEtBQUs7RUFDZCxNQUFNLE1BQU0sV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLGNBQWMsT0FBTyxLQUFLLElBQUksSUFBSSxTQUFTLEdBQUcsV0FBVyxXQUFXLE9BQ2pIO0VBQ0YsTUFBTTtFQUNOLEtBQUssTUFBTSxXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsY0FBYyxPQUFPLEtBQUssSUFBSSxJQUFJLFNBQzlFLEdBQUcsZUFBZTtFQUNwQixLQUFLLEtBQUssV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLGNBQWMsT0FBTyxLQUFLLElBQUksR0FBRyxNQUM1RSxHQUFHLGdCQUFnQjtFQUNyQixXQUFXO0dBQ1QsR0FBRyxHQUFHO0dBQ04sR0FBRyxHQUFHO0VBQ1I7RUFDQSxpQkFBaUIsR0FBRztFQUNwQixVQUFVLGlCQUNGO0dBQ0osaUJBQWlCO0dBQ2pCLFFBQVEsRUFBRTtFQUNaLEdBQ0EsU0FBUyxFQUFFLENBQ2I7Q0FDRjtDQUNBLFNBQVMsT0FBTyxJQUFJO0VBQ2xCLElBQUksS0FBSyxLQUFLLElBQUk7RUFDbEIsTUFBTSxNQUFNLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxjQUFjLE9BQU8sS0FBSyxJQUFJLElBQUksU0FBUyxHQUFHLFdBQVcsV0FBVyxPQUNqSDtFQUNGLElBQUksQ0FBQyxhQUFhLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSx1QkFBdUIsT0FDMUU7RUFDRixLQUFLLE1BQU0sV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLGNBQWMsT0FBTyxLQUFLLElBQUksSUFBSSxTQUM5RSxHQUFHLGVBQWU7RUFDcEIsS0FBSyxLQUFLLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxjQUFjLE9BQU8sS0FBSyxJQUFJLEdBQUcsTUFDNUUsR0FBRyxnQkFBZ0I7RUFDckIsTUFBTSxLQUFLLEdBQUcsSUFBSSxTQUFTO0VBQzNCLE1BQU0sS0FBSyxHQUFHLElBQUksU0FBUztFQUMzQixNQUFNLFdBQVcsS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEVBQUU7RUFDNUMsSUFBSSxjQUFjLEtBQUssV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLHNCQUFzQixPQUFPLEtBQUssb0JBQzFGLE1BQU07Q0FDVjtDQUNBLE1BQU0sa0JBQWtCO0VBQ3RCLFVBQVUsS0FBSyxXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsY0FBYyxPQUFPLEtBQUssSUFBSSxHQUFHO0VBQ25GLE9BQU8sS0FBSyxXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsY0FBYyxPQUFPLEtBQUssSUFBSSxHQUFHO0NBQ2xGO0NBQ0EsTUFBTSxVQUFVO0VBQ2QsaUJBQWlCLFlBQVksZUFBZSxRQUFRLGVBQWU7RUFDbkUsaUJBQWlCLFlBQVksZUFBZSxRQUFRLGVBQWU7RUFDbkUsaUJBQWlCLFlBQVksQ0FBQyxhQUFhLGNBQWMsR0FBRyxXQUFXLGVBQWU7Q0FDeEY7Q0FDQSxNQUFNLGFBQWEsUUFBUSxTQUFTLE9BQU8sR0FBRyxDQUFDO0NBQy9DLE9BQU87QUFDVDtBQUVBLFNBQVMsMkJBQTJCO0NBQ2xDLE1BQU0sRUFBRSxlQUFlLFNBQVM7Q0FDaEMsSUFBSSxDQUFDLGVBQ0gsT0FBTztDQUNULElBQUksa0JBQWtCLE1BQ3BCLE9BQU87Q0FDVCxRQUFRLGNBQWMsU0FBdEI7RUFDRSxLQUFLO0VBQ0wsS0FBSyxZQUNILE9BQU87Q0FDWDtDQUNBLE9BQU8sY0FBYyxhQUFhLGlCQUFpQjtBQUNyRDtBQUNBLFNBQVMsaUJBQWlCLEVBQ3hCLFNBQ0EsU0FDQSxTQUNBLFVBQ0M7Q0FDRCxJQUFJLFdBQVcsV0FBVyxRQUN4QixPQUFPO0NBQ1QsSUFBSSxXQUFXLE1BQU0sV0FBVyxNQUFNLFdBQVcsTUFBTSxXQUFXLEtBQ2hFLE9BQU87Q0FDVCxJQUFJLFdBQVcsTUFBTSxXQUFXLElBQzlCLE9BQU87Q0FDVCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGNBQWMsVUFBVSxVQUFVLENBQUMsR0FBRztDQUM3QyxNQUFNLEVBQUUsVUFBVSxZQUFZLG9CQUFvQjtDQUNsRCxNQUFNLFdBQVcsVUFBVTtFQUN6QixJQUFJLENBQUMseUJBQXlCLEtBQUssaUJBQWlCLEtBQUssR0FBRztHQUMxRCxTQUFTLEtBQUs7RUFDaEI7Q0FDRjtDQUNBLElBQUksV0FDRixpQkFBaUIsV0FBVyxXQUFXLFNBQVMsRUFBRSxTQUFTLEtBQUssQ0FBQztBQUNyRTs7QUFHQSxTQUFTLFlBQVksS0FBSyxlQUFlLE1BQU07Q0FDN0MsTUFBTSxXQUFXLG1CQUFtQjtDQUNwQyxJQUFJLGlCQUFpQixDQUNyQjtDQUNBLE1BQU0sVUFBVSxXQUFXLE9BQU8sWUFBWTtFQUM1QyxXQUFXO0VBQ1gsT0FBTztHQUNMLE1BQU07SUFDSixJQUFJLElBQUk7SUFDUixNQUFNO0lBQ04sUUFBUSxNQUFNLEtBQUssWUFBWSxPQUFPLEtBQUssSUFBSSxTQUFTLFVBQVUsT0FBTyxLQUFLLElBQUksR0FBRyxNQUFNLFNBQVMsT0FBTyxLQUFLO0dBQ2xIO0dBQ0EsTUFBTSxDQUNOO0VBQ0Y7Q0FDRixDQUFDO0NBQ0QsYUFBYSxRQUFRO0NBQ3JCLFVBQVUsUUFBUTtDQUNsQixPQUFPO0FBQ1Q7O0FBR0EsU0FBUyxpQkFBaUIsVUFBVSxDQUFDLEdBQUc7Q0FDdEMsSUFBSTtDQUNKLE1BQU0sRUFDSixTQUFTLGVBQ1QsT0FBTyxNQUNQLG1CQUFtQixVQUNqQjtDQUNKLE1BQU0sWUFBWSxLQUFLLFFBQVEsYUFBYSxPQUFPLEtBQUssVUFBVSxPQUFPLEtBQUssSUFBSSxPQUFPO0NBQ3pGLE1BQU0sNkJBQTZCO0VBQ2pDLElBQUk7RUFDSixJQUFJLFVBQVUsWUFBWSxPQUFPLEtBQUssSUFBSSxTQUFTO0VBQ25ELElBQUksTUFBTTtHQUNSLE9BQU8sV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLFlBQ3hDLFdBQVcsTUFBTSxXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsZUFBZSxPQUFPLEtBQUssSUFBSSxJQUFJO0VBQzNGO0VBQ0EsT0FBTztDQUNUO0NBQ0EsTUFBTSxnQkFBZ0IsV0FBVztDQUNqQyxNQUFNLGdCQUFnQjtFQUNwQixjQUFjLFFBQVEscUJBQXFCO0NBQzdDO0NBQ0EsSUFBSSxRQUFRO0VBQ1YsTUFBTSxrQkFBa0I7R0FDdEIsU0FBUztHQUNULFNBQVM7RUFDWDtFQUNBLGlCQUNFLFFBQ0EsU0FDQyxVQUFVO0dBQ1QsSUFBSSxNQUFNLGtCQUFrQixNQUMxQjtHQUNGLFFBQVE7RUFDVixHQUNBLGVBQ0Y7RUFDQSxpQkFDRSxRQUNBLFNBQ0EsU0FDQSxlQUNGO0NBQ0Y7Q0FDQSxJQUFJLGtCQUFrQjtFQUNwQixpQkFBaUIsZUFBZSxTQUFTLEVBQUUsU0FBUyxDQUFDO0NBQ3ZEO0NBQ0EsUUFBUTtDQUNSLE9BQU87QUFDVDtBQUVBLFNBQVMsU0FBUyxJQUFJLFVBQVUsQ0FBQyxHQUFHO0NBQ2xDLE1BQU0sRUFDSixZQUFZLE1BQ1osV0FBVyxLQUFLLEdBQ2hCLFNBQVMsZUFDVCxPQUFPLFVBQ0w7Q0FDSixNQUFNLFdBQVcsV0FBVyxLQUFLO0NBQ2pDLE1BQU0sZ0JBQWdCLGVBQWU7RUFDbkMsT0FBTyxXQUFXLE1BQU0sUUFBUSxRQUFRLElBQUk7Q0FDOUMsQ0FBQztDQUNELElBQUkseUJBQXlCO0NBQzdCLElBQUksUUFBUTtDQUNaLFNBQVMsS0FBSyxXQUFXO0VBQ3ZCLElBQUksQ0FBQyxTQUFTLFNBQVMsQ0FBQyxRQUN0QjtFQUNGLElBQUksQ0FBQyx3QkFDSCx5QkFBeUI7RUFDM0IsTUFBTSxRQUFRLFlBQVk7RUFDMUIsSUFBSSxjQUFjLFNBQVMsUUFBUSxjQUFjLE9BQU87R0FDdEQsUUFBUSxPQUFPLHNCQUFzQixJQUFJO0dBQ3pDO0VBQ0Y7RUFDQSx5QkFBeUI7RUFDekIsR0FBRztHQUFFO0dBQU87RUFBVSxDQUFDO0VBQ3ZCLElBQUksTUFBTTtHQUNSLFNBQVMsUUFBUTtHQUNqQixRQUFRO0dBQ1I7RUFDRjtFQUNBLFFBQVEsT0FBTyxzQkFBc0IsSUFBSTtDQUMzQztDQUNBLFNBQVMsU0FBUztFQUNoQixJQUFJLENBQUMsU0FBUyxTQUFTLFFBQVE7R0FDN0IsU0FBUyxRQUFRO0dBQ2pCLHlCQUF5QjtHQUN6QixRQUFRLE9BQU8sc0JBQXNCLElBQUk7RUFDM0M7Q0FDRjtDQUNBLFNBQVMsUUFBUTtFQUNmLFNBQVMsUUFBUTtFQUNqQixJQUFJLFNBQVMsUUFBUSxRQUFRO0dBQzNCLE9BQU8scUJBQXFCLEtBQUs7R0FDakMsUUFBUTtFQUNWO0NBQ0Y7Q0FDQSxJQUFJLFdBQ0YsT0FBTztDQUNULGtCQUFrQixLQUFLO0NBQ3ZCLE9BQU87RUFDTCxVQUFVLFNBQVMsUUFBUTtFQUMzQjtFQUNBO0NBQ0Y7QUFDRjtBQUVBLFNBQVMsV0FBVyxRQUFRLFdBQVcsU0FBUztDQUM5QyxJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUksU0FBUyxPQUFPLEdBQUc7RUFDckIsU0FBUztFQUNULGlCQUFpQixXQUFXLFNBQVM7R0FBQztHQUFVO0dBQWE7R0FBZ0I7R0FBVztHQUFXO0VBQVMsQ0FBQztDQUMvRyxPQUFPO0VBQ0wsU0FBUyxFQUFFLFVBQVUsUUFBUTtFQUM3QixpQkFBaUI7Q0FDbkI7Q0FDQSxNQUFNLEVBQ0osU0FBUyxlQUNULFlBQVksTUFDWixjQUNBLFNBQ0EsY0FBYyxnQkFBZ0IsR0FDOUIsU0FDQSxXQUFXLE1BQU07RUFDZixRQUFRLE1BQU0sQ0FBQztDQUNqQixNQUNFO0NBQ0osTUFBTSxjQUFjLG1CQUFtQixVQUFVLGVBQWUsYUFBYSxZQUFZLFNBQVM7Q0FDbEcsTUFBTSxVQUFVLFdBQVcsS0FBSyxDQUFDO0NBQ2pDLE1BQU0sUUFBUSxnQkFBZ0I7RUFDNUIsV0FBVztFQUNYLGFBQWE7RUFDYixVQUFVO0VBQ1YsY0FBYztFQUNkLFNBQVM7RUFDVCxXQUFXLFlBQVksU0FBUztFQUNoQyxjQUFjO0NBQ2hCLENBQUM7Q0FDRCxNQUFNLFVBQVUsZUFBZSxNQUFNLE9BQU87Q0FDNUMsTUFBTSxZQUFZLGVBQWUsTUFBTSxTQUFTO0NBQ2hELE1BQU0sZUFBZSxlQUFlLE1BQU0sWUFBWTtDQUN0RCxNQUFNLFlBQVksU0FBUztFQUN6QixNQUFNO0dBQ0osT0FBTyxNQUFNO0VBQ2Y7RUFDQSxJQUFJLE9BQU87R0FDVCxNQUFNLFlBQVk7R0FDbEIsSUFBSSxRQUFRLE9BQ1YsUUFBUSxNQUFNLFlBQVk7RUFDOUI7Q0FDRixDQUFDO0NBQ0QsTUFBTSxjQUFjLFNBQVM7RUFDM0IsTUFBTTtHQUNKLE9BQU8sTUFBTTtFQUNmO0VBQ0EsSUFBSSxPQUFPO0dBQ1QsTUFBTSxjQUFjO0dBQ3BCLElBQUksUUFBUSxPQUFPO0lBQ2pCLFFBQVEsTUFBTSxjQUFjO0lBQzVCLFdBQVc7R0FDYjtFQUNGO0NBQ0YsQ0FBQztDQUNELE1BQU0sV0FBVyxTQUFTO0VBQ3hCLE1BQU07R0FDSixPQUFPLE1BQU07RUFDZjtFQUNBLElBQUksT0FBTztHQUNULE1BQU0sV0FBVztHQUNqQixJQUFJLFFBQVEsT0FDVixRQUFRLE1BQU0sV0FBVztFQUM3QjtDQUNGLENBQUM7Q0FDRCxNQUFNLGVBQWUsU0FBUztFQUM1QixNQUFNO0dBQ0osT0FBTyxNQUFNO0VBQ2Y7RUFDQSxJQUFJLE9BQU87R0FDVCxNQUFNLGVBQWU7R0FDckIsSUFBSSxRQUFRLE9BQ1YsUUFBUSxNQUFNLGVBQWU7RUFDakM7Q0FDRixDQUFDO0NBQ0QsTUFBTSxhQUFhO0VBQ2pCLElBQUksUUFBUSxPQUFPO0dBQ2pCLElBQUk7SUFDRixRQUFRLE1BQU0sS0FBSztJQUNuQixXQUFXO0dBQ2IsU0FBUyxHQUFHO0lBQ1YsVUFBVTtJQUNWLFFBQVEsQ0FBQztHQUNYO0VBQ0YsT0FBTztHQUNMLE9BQU87RUFDVDtDQUNGO0NBQ0EsTUFBTSxjQUFjO0VBQ2xCLElBQUk7RUFDSixJQUFJO0dBQ0YsQ0FBQyxLQUFLLFFBQVEsVUFBVSxPQUFPLEtBQUssSUFBSSxHQUFHLE1BQU07R0FDakQsVUFBVTtFQUNaLFNBQVMsR0FBRztHQUNWLFFBQVEsQ0FBQztFQUNYO0NBQ0Y7Q0FDQSxNQUFNLGdCQUFnQjtFQUNwQixJQUFJO0VBQ0osSUFBSSxDQUFDLFFBQVEsT0FDWCxPQUFPO0VBQ1QsSUFBSTtHQUNGLENBQUMsS0FBSyxRQUFRLFVBQVUsT0FBTyxLQUFLLElBQUksR0FBRyxRQUFRO0dBQ25ELFdBQVc7RUFDYixTQUFTLEdBQUc7R0FDVixVQUFVO0dBQ1YsUUFBUSxDQUFDO0VBQ1g7Q0FDRjtDQUNBLE1BQU0sZUFBZTtFQUNuQixJQUFJO0VBQ0osSUFBSTtHQUNGLENBQUMsS0FBSyxRQUFRLFVBQVUsT0FBTyxLQUFLLElBQUksR0FBRyxPQUFPO0dBQ2xELFVBQVU7RUFDWixTQUFTLEdBQUc7R0FDVixRQUFRLENBQUM7RUFDWDtDQUNGO0NBQ0EsTUFBTSxlQUFlO0VBQ25CLElBQUk7RUFDSixJQUFJO0dBQ0YsQ0FBQyxLQUFLLFFBQVEsVUFBVSxPQUFPLEtBQUssSUFBSSxHQUFHLE9BQU87R0FDbEQsVUFBVTtFQUNaLFNBQVMsR0FBRztHQUNWLFFBQVEsQ0FBQztFQUNYO0NBQ0Y7Q0FDQSxZQUFZLGFBQWEsTUFBTSxJQUFJLE9BQU87RUFDeEMsSUFBSSxJQUFJO0dBQ04sT0FBTyxJQUFJO0VBQ2IsT0FBTztHQUNMLFFBQVEsUUFBUSxLQUFLO0VBQ3ZCO0NBQ0YsQ0FBQztDQUNELFlBQVksWUFBWSxVQUFVO0VBQ2hDLElBQUksUUFBUSxPQUFPO0dBQ2pCLE9BQU87R0FDUCxNQUFNLFdBQVcsYUFBYSxNQUFNO0dBQ3BDLElBQUksVUFBVTtJQUNaLFFBQVEsTUFBTSxTQUFTLElBQUksZUFDekIsVUFDQSxRQUFRLEtBQUssR0FDYixjQUNGO0dBQ0Y7RUFDRjtDQUNGLEdBQUcsRUFBRSxNQUFNLEtBQUssQ0FBQztDQUNqQixtQkFBbUIsT0FBTyxJQUFJLEdBQUcsS0FBSztDQUN0QyxrQkFBa0IsTUFBTTtDQUN4QixTQUFTLE9BQU8sTUFBTTtFQUNwQixNQUFNLEtBQUssYUFBYSxNQUFNO0VBQzlCLElBQUksQ0FBQyxZQUFZLFNBQVMsQ0FBQyxJQUN6QjtFQUNGLElBQUksQ0FBQyxRQUFRLE9BQ1gsUUFBUSxRQUFRLEdBQUcsUUFBUSxRQUFRLFNBQVMsR0FBRyxjQUFjO0VBQy9ELElBQUksU0FDRixRQUFRLE1BQU0sUUFBUTtFQUN4QixJQUFJLGtCQUFrQixHQUNwQixRQUFRLE1BQU0sZUFBZTtFQUMvQixJQUFJLFFBQVEsQ0FBQyxXQUNYLFFBQVEsTUFBTSxNQUFNO09BRXBCLFdBQVc7RUFDYixXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsUUFBUSxLQUFLO0NBQ2xEO0NBQ0EsTUFBTSxrQkFBa0IsRUFBRSxTQUFTLEtBQUs7Q0FDeEMsaUJBQWlCLFNBQVM7RUFBQztFQUFVO0VBQVU7Q0FBUSxHQUFHLFdBQVcsZUFBZTtDQUNwRixpQkFBaUIsU0FBUyxnQkFBZ0I7RUFDeEMsSUFBSTtFQUNKLElBQUksY0FDRixDQUFDLEtBQUssUUFBUSxVQUFVLE9BQU8sS0FBSyxJQUFJLEdBQUcsYUFBYTtDQUM1RCxHQUFHLGVBQWU7Q0FDbEIsTUFBTSxFQUFFLFFBQVEsV0FBVyxPQUFPLGFBQWEsZUFBZTtFQUM1RCxJQUFJLENBQUMsUUFBUSxPQUNYO0VBQ0YsTUFBTSxVQUFVLFFBQVEsTUFBTTtFQUM5QixNQUFNLFlBQVksUUFBUSxNQUFNO0VBQ2hDLE1BQU0sZUFBZSxRQUFRLE1BQU07RUFDbkMsTUFBTSxZQUFZLFFBQVEsTUFBTTtFQUNoQyxNQUFNLGNBQWMsUUFBUSxNQUFNO0VBQ2xDLE1BQU0sV0FBVyxRQUFRLE1BQU07RUFDL0IsTUFBTSxlQUFlLFFBQVEsTUFBTTtDQUNyQyxHQUFHLEVBQUUsV0FBVyxNQUFNLENBQUM7Q0FDdkIsU0FBUyxhQUFhO0VBQ3BCLElBQUksWUFBWSxPQUNkLFVBQVU7Q0FDZDtDQUNBLFNBQVMsWUFBWTtFQUNuQixJQUFJLFlBQVksU0FBUyxRQUN2QixPQUFPLHNCQUFzQixRQUFRO0NBQ3pDO0NBQ0EsT0FBTztFQUNMO0VBQ0E7O0VBRUE7RUFDQTtFQUNBO0VBQ0E7RUFDQTs7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7QUFFQSxTQUFTLGNBQWMsT0FBTyxTQUFTO0NBQ3JDLE1BQU0sRUFDSixZQUFZLE1BQ1osVUFBVSxNQUNWLGFBQWEsTUFDYixXQUNFLFdBQVcsQ0FBQztDQUNoQixNQUFNLGVBQWU7RUFDbkIsU0FBUztFQUNULFdBQVc7RUFDWCxTQUFTO0VBQ1QsVUFBVTtDQUNaO0NBQ0EsTUFBTSxnQkFBZ0IsTUFBTSxLQUFLLE1BQU0sS0FBSyxFQUFFLFFBQVEsTUFBTSxPQUFPLENBQUMsVUFBVTtFQUFFLE9BQU8sYUFBYTtFQUFTLE1BQU07Q0FBSyxFQUFFO0NBQzFILE1BQU0sU0FBUyxTQUFTLGFBQWE7Q0FDckMsTUFBTSxjQUFjLFdBQVcsQ0FBQyxDQUFDO0NBQ2pDLElBQUksQ0FBQyxTQUFTLE1BQU0sV0FBVyxHQUFHO0VBQ2hDLFdBQVc7RUFDWCxPQUFPO0dBQ0w7R0FDQTtFQUNGO0NBQ0Y7Q0FDQSxTQUFTLGFBQWEsT0FBTyxLQUFLO0VBQ2hDLFlBQVk7RUFDWixPQUFPLFlBQVksTUFBTSxDQUFDLE9BQU87RUFDakMsT0FBTyxZQUFZLE1BQU0sQ0FBQyxRQUFRO0NBQ3BDO0NBQ0EsTUFBTSxRQUFRLE1BQU0sU0FBUztFQUMzQixPQUFPLEtBQUssTUFBTSxZQUFZO0dBQzVCLElBQUk7R0FDSixJQUFJLFVBQVUsT0FBTyxLQUFLLElBQUksT0FBTyxTQUFTO0lBQzVDLGFBQWEsYUFBYSxTQUFTLElBQUksTUFBTSxTQUFTLENBQUM7SUFDdkQ7R0FDRjtHQUNBLE1BQU0sS0FBSyxPQUFPLFlBQVksV0FBVyxPQUFPLEtBQUssSUFBSSxHQUFHLFdBQVcsYUFBYSxZQUFZLFdBQVc7SUFDekcsV0FBVztJQUNYO0dBQ0Y7R0FDQSxNQUFNLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxNQUFNLGVBQWU7SUFDOUMsYUFBYSxhQUFhLFdBQVcsVUFBVTtJQUMvQyxJQUFJLFlBQVksVUFBVSxNQUFNLFNBQVMsR0FDdkMsV0FBVztJQUNiLE9BQU87R0FDVCxDQUFDO0dBQ0QsSUFBSSxDQUFDLFFBQ0gsT0FBTztHQUNULE9BQU8sUUFBUSxLQUFLLENBQUMsTUFBTSxZQUFZLE1BQU0sQ0FBQyxDQUFDO0VBQ2pELENBQUMsQ0FBQyxDQUFDLE9BQU8sTUFBTTtHQUNkLElBQUksVUFBVSxPQUFPLEtBQUssSUFBSSxPQUFPLFNBQVM7SUFDNUMsYUFBYSxhQUFhLFNBQVMsQ0FBQztJQUNwQyxPQUFPO0dBQ1Q7R0FDQSxhQUFhLGFBQWEsVUFBVSxDQUFDO0dBQ3JDLFFBQVE7R0FDUixPQUFPO0VBQ1QsQ0FBQztDQUNILEdBQUcsUUFBUSxRQUFRLENBQUM7Q0FDcEIsT0FBTztFQUNMO0VBQ0E7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxZQUFZLFFBQVE7Q0FDM0IsT0FBTyxJQUFJLFNBQVMsU0FBUyxXQUFXO0VBQ3RDLE1BQU0sUUFBUSxJQUFJLE1BQU0sU0FBUztFQUNqQyxJQUFJLE9BQU8sU0FDVCxPQUFPLEtBQUs7T0FFWixPQUFPLGlCQUFpQixlQUFlLE9BQU8sS0FBSyxHQUFHLEVBQUUsTUFBTSxLQUFLLENBQUM7Q0FDeEUsQ0FBQztBQUNIO0FBRUEsU0FBUyxjQUFjLFNBQVMsY0FBYyxTQUFTO0NBQ3JELElBQUk7Q0FDSixNQUFNLEVBQ0osWUFBWSxNQUNaLFFBQVEsR0FDUixXQUFXLEtBQUssV0FBVyxnQkFBZ0IsT0FBTyxLQUFLLE1BQ3ZELFlBQVksTUFDWixpQkFBaUIsTUFDakIsVUFBVSxNQUNWLGVBQ0UsV0FBVyxPQUFPLFVBQVUsQ0FBQztDQUNqQyxNQUFNLFFBQVEsVUFBVSxXQUFXLFlBQVksSUFBSSxJQUFJLFlBQVk7Q0FDbkUsTUFBTSxVQUFVLFdBQVcsS0FBSztDQUNoQyxNQUFNLFlBQVksV0FBVyxLQUFLO0NBQ2xDLE1BQU0sUUFBUSxXQUFXLEtBQUssQ0FBQztDQUMvQixlQUFlLFFBQVEsU0FBUyxHQUFHLEdBQUcsTUFBTTtFQUMxQyxJQUFJLGdCQUNGLE1BQU0sUUFBUSxRQUFRLFlBQVk7RUFDcEMsTUFBTSxRQUFRLEtBQUs7RUFDbkIsUUFBUSxRQUFRO0VBQ2hCLFVBQVUsUUFBUTtFQUNsQixJQUFJLFNBQVMsR0FDWCxNQUFNLGVBQWUsTUFBTTtFQUM3QixNQUFNLFdBQVcsT0FBTyxZQUFZLGFBQWEsUUFBUSxHQUFHLElBQUksSUFBSTtFQUNwRSxJQUFJO0dBQ0YsTUFBTSxPQUFPLE1BQU07R0FDbkIsTUFBTSxRQUFRO0dBQ2QsUUFBUSxRQUFRO0dBQ2hCLFVBQVUsSUFBSTtFQUNoQixTQUFTLEdBQUc7R0FDVixNQUFNLFFBQVE7R0FDZCxRQUFRLENBQUM7R0FDVCxJQUFJLFlBQ0YsTUFBTTtFQUNWLFVBQVU7R0FDUixVQUFVLFFBQVE7RUFDcEI7RUFDQSxPQUFPLE1BQU07Q0FDZjtDQUNBLElBQUksV0FBVztFQUNiLFFBQVEsS0FBSztDQUNmO0NBQ0EsTUFBTSxRQUFRO0VBQ1o7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLG1CQUFtQixHQUFHLFNBQVMsUUFBUSxHQUFHLEdBQUcsSUFBSTtDQUNuRDtDQUNBLFNBQVMsb0JBQW9CO0VBQzNCLE9BQU8sSUFBSSxTQUFTLFNBQVMsV0FBVztHQUN0QyxNQUFNLFNBQVMsQ0FBQyxDQUFDLEtBQUssS0FBSyxDQUFDLENBQUMsV0FBVyxRQUFRLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxNQUFNO0VBQ3RFLENBQUM7Q0FDSDtDQUNBLE9BQU87RUFDTCxHQUFHO0VBQ0gsS0FBSyxhQUFhLFlBQVk7R0FDNUIsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLEtBQUssYUFBYSxVQUFVO0VBQ3pEO0NBQ0Y7QUFDRjtBQUVBLE1BQU0sV0FBVztDQUNmLFFBQVEsTUFBTSxLQUFLLFVBQVUsQ0FBQztDQUM5QixTQUFTLE1BQU0sS0FBSyxVQUFVLENBQUM7Q0FDL0IsTUFBTSxNQUFNLEtBQUssVUFBVSxNQUFNLEtBQUssQ0FBQyxDQUFDO0NBQ3hDLE1BQU0sTUFBTSxLQUFLLFVBQVUsT0FBTyxZQUFZLENBQUMsQ0FBQztDQUNoRCxZQUFZO0FBQ2Q7QUFDQSxTQUFTLHdCQUF3QixRQUFRO0NBQ3ZDLElBQUksQ0FBQyxRQUNILE9BQU8sU0FBUztDQUNsQixJQUFJLGtCQUFrQixLQUNwQixPQUFPLFNBQVM7TUFDYixJQUFJLGtCQUFrQixLQUN6QixPQUFPLFNBQVM7TUFDYixJQUFJLE1BQU0sUUFBUSxNQUFNLEdBQzNCLE9BQU8sU0FBUztNQUVoQixPQUFPLFNBQVM7QUFDcEI7QUFFQSxTQUFTLFVBQVUsUUFBUSxTQUFTO0NBQ2xDLE1BQU0sU0FBUyxXQUFXLEVBQUU7Q0FDNUIsTUFBTSxVQUFVLFdBQVc7Q0FDM0IsU0FBUyxVQUFVO0VBQ2pCLElBQUksQ0FBQyxVQUNIO0VBQ0YsUUFBUSxRQUFRLElBQUksU0FBUyxTQUFTLFdBQVc7R0FDL0MsSUFBSTtJQUNGLE1BQU0sVUFBVSxRQUFRLE1BQU07SUFDOUIsSUFBSSxXQUFXLE1BQU07S0FDbkIsUUFBUSxFQUFFO0lBQ1osT0FBTyxJQUFJLE9BQU8sWUFBWSxVQUFVO0tBQ3RDLFFBQVEsYUFBYSxJQUFJLEtBQUssQ0FBQyxPQUFPLEdBQUcsRUFBRSxNQUFNLGFBQWEsQ0FBQyxDQUFDLENBQUM7SUFDbkUsT0FBTyxJQUFJLG1CQUFtQixNQUFNO0tBQ2xDLFFBQVEsYUFBYSxPQUFPLENBQUM7SUFDL0IsT0FBTyxJQUFJLG1CQUFtQixhQUFhO0tBQ3pDLFFBQVEsT0FBTyxLQUFLLE9BQU8sYUFBYSxHQUFHLElBQUksV0FBVyxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQ3RFLE9BQU8sSUFBSSxtQkFBbUIsbUJBQW1CO0tBQy9DLFFBQVEsUUFBUSxVQUFVLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxNQUFNLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxPQUFPLENBQUM7SUFDaEgsT0FBTyxJQUFJLG1CQUFtQixrQkFBa0I7S0FDOUMsTUFBTSxNQUFNLFFBQVEsVUFBVSxLQUFLO0tBQ25DLElBQUksY0FBYztLQUNsQixVQUFVLEdBQUcsQ0FBQyxDQUFDLFdBQVc7TUFDeEIsTUFBTSxTQUFTLFNBQVMsY0FBYyxRQUFRO01BQzlDLE1BQU0sTUFBTSxPQUFPLFdBQVcsSUFBSTtNQUNsQyxPQUFPLFFBQVEsSUFBSTtNQUNuQixPQUFPLFNBQVMsSUFBSTtNQUNwQixJQUFJLFVBQVUsS0FBSyxHQUFHLEdBQUcsT0FBTyxPQUFPLE9BQU8sTUFBTTtNQUNwRCxRQUFRLE9BQU8sVUFBVSxXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsTUFBTSxXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsT0FBTyxDQUFDO0tBQy9HLENBQUMsQ0FBQyxDQUFDLE1BQU0sTUFBTTtJQUNqQixPQUFPLElBQUksT0FBTyxZQUFZLFVBQVU7S0FDdEMsTUFBTSxnQkFBZ0IsV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLGVBQWUsd0JBQXdCLE9BQU87S0FDdkcsTUFBTSxhQUFhLGFBQWEsT0FBTztLQUN2QyxPQUFPLFFBQVEsYUFBYSxJQUFJLEtBQUssQ0FBQyxVQUFVLEdBQUcsRUFBRSxNQUFNLG1CQUFtQixDQUFDLENBQUMsQ0FBQztJQUNuRixPQUFPO0tBQ0wsT0FBTyxJQUFJLE1BQU0sNkJBQTZCLENBQUM7SUFDakQ7R0FDRixTQUFTLE9BQU87SUFDZCxPQUFPLEtBQUs7R0FDZDtFQUNGLENBQUM7RUFDRCxRQUFRLE1BQU0sTUFBTSxRQUFRO0dBQzFCLE9BQU8sU0FBUyxXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsYUFBYSxRQUFRLElBQUksUUFBUSxxQkFBcUIsRUFBRSxJQUFJO0VBQ2pILENBQUM7RUFDRCxPQUFPLFFBQVE7Q0FDakI7Q0FDQSxJQUFJLE1BQU0sTUFBTSxLQUFLLE9BQU8sV0FBVyxZQUNyQyxNQUFNLFFBQVEsU0FBUyxFQUFFLFdBQVcsS0FBSyxDQUFDO01BRTFDLFFBQVE7Q0FDVixPQUFPO0VBQ0w7RUFDQTtFQUNBO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsVUFBVSxLQUFLO0NBQ3RCLE9BQU8sSUFBSSxTQUFTLFNBQVMsV0FBVztFQUN0QyxJQUFJLENBQUMsSUFBSSxVQUFVO0dBQ2pCLElBQUksZUFBZTtJQUNqQixRQUFRO0dBQ1Y7R0FDQSxJQUFJLFVBQVU7RUFDaEIsT0FBTztHQUNMLFFBQVE7RUFDVjtDQUNGLENBQUM7QUFDSDtBQUNBLFNBQVMsYUFBYSxNQUFNO0NBQzFCLE9BQU8sSUFBSSxTQUFTLFNBQVMsV0FBVztFQUN0QyxNQUFNLEtBQUssSUFBSSxXQUFXO0VBQzFCLEdBQUcsVUFBVSxNQUFNO0dBQ2pCLFFBQVEsRUFBRSxPQUFPLE1BQU07RUFDekI7RUFDQSxHQUFHLFVBQVU7RUFDYixHQUFHLGNBQWMsSUFBSTtDQUN2QixDQUFDO0FBQ0g7O0FBR0EsU0FBUyxXQUFXLFVBQVUsQ0FBQyxHQUFHO0NBQ2hDLE1BQU0sRUFBRSxZQUFZLHFCQUFxQjtDQUN6QyxNQUFNLFNBQVM7RUFBQztFQUFrQjtFQUFzQjtFQUF5QjtDQUFhO0NBQzlGLE1BQU0sY0FBYyxtQkFBbUIsYUFBYSxnQkFBZ0IsYUFBYSxPQUFPLFVBQVUsZUFBZSxVQUFVO0NBQzNILE1BQU0sV0FBVyxXQUFXLEtBQUs7Q0FDakMsTUFBTSxlQUFlLFdBQVcsQ0FBQztDQUNqQyxNQUFNLGtCQUFrQixXQUFXLENBQUM7Q0FDcEMsTUFBTSxRQUFRLFdBQVcsQ0FBQztDQUMxQixJQUFJO0NBQ0osU0FBUyxvQkFBb0I7RUFDM0IsU0FBUyxRQUFRLEtBQUs7RUFDdEIsYUFBYSxRQUFRLEtBQUssZ0JBQWdCO0VBQzFDLGdCQUFnQixRQUFRLEtBQUssbUJBQW1CO0VBQ2hELE1BQU0sUUFBUSxLQUFLO0NBQ3JCO0NBQ0EsSUFBSSxZQUFZLE9BQU87RUFDckIsVUFBVSxXQUFXLENBQUMsQ0FBQyxNQUFNLGFBQWE7R0FDeEMsVUFBVTtHQUNWLGtCQUFrQixLQUFLLE9BQU87R0FDOUIsaUJBQWlCLFNBQVMsUUFBUSxtQkFBbUIsRUFBRSxTQUFTLEtBQUssQ0FBQztFQUN4RSxDQUFDO0NBQ0g7Q0FDQSxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7O0FBR0EsU0FBUyxhQUFhLFNBQVM7Q0FDN0IsSUFBSSxFQUNGLG1CQUFtQixVQUNqQixXQUFXLENBQUM7Q0FDaEIsTUFBTSxFQUNKLFVBQVUsS0FBSyxHQUNmLG1CQUFtQixLQUFLLEdBQ3hCLFlBQVkscUJBQ1YsV0FBVyxDQUFDO0NBQ2hCLE1BQU0sY0FBYyxtQkFBbUIsYUFBYSxlQUFlLFNBQVM7Q0FDNUUsTUFBTSxTQUFTLFdBQVc7Q0FDMUIsTUFBTSxRQUFRLFdBQVcsSUFBSTtDQUM3QixNQUFNLGNBQWM7RUFDbEIsNkJBQTZCO0NBQy9CLENBQUM7Q0FDRCxlQUFlLGdCQUFnQjtFQUM3QixJQUFJLENBQUMsWUFBWSxPQUNmO0VBQ0YsTUFBTSxRQUFRO0VBQ2QsSUFBSSxXQUFXLFFBQVEsU0FBUyxHQUM5QixtQkFBbUI7RUFDckIsSUFBSTtHQUNGLE9BQU8sUUFBUSxPQUFPLGFBQWEsT0FBTyxLQUFLLElBQUksVUFBVSxVQUFVLGNBQWM7SUFDbkY7SUFDQTtJQUNBO0dBQ0YsQ0FBQztFQUNILFNBQVMsS0FBSztHQUNaLE1BQU0sUUFBUTtFQUNoQjtDQUNGO0NBQ0EsTUFBTSxTQUFTLFdBQVc7Q0FDMUIsTUFBTSxjQUFjLFdBQVcsS0FBSztDQUNwQyxTQUFTLFFBQVE7RUFDZixZQUFZLFFBQVE7RUFDcEIsT0FBTyxRQUFRLEtBQUs7RUFDcEIsT0FBTyxRQUFRLEtBQUs7Q0FDdEI7Q0FDQSxlQUFlLCtCQUErQjtFQUM1QyxNQUFNLFFBQVE7RUFDZCxJQUFJLE9BQU8sU0FBUyxPQUFPLE1BQU0sTUFBTTtHQUNyQyxpQkFBaUIsUUFBUSwwQkFBMEIsT0FBTyxFQUFFLFNBQVMsS0FBSyxDQUFDO0dBQzNFLElBQUk7SUFDRixPQUFPLFFBQVEsTUFBTSxPQUFPLE1BQU0sS0FBSyxRQUFRO0lBQy9DLFlBQVksUUFBUSxPQUFPLE1BQU07R0FDbkMsU0FBUyxLQUFLO0lBQ1osTUFBTSxRQUFRO0dBQ2hCO0VBQ0Y7Q0FDRjtDQUNBLG1CQUFtQjtFQUNqQixJQUFJO0VBQ0osSUFBSSxPQUFPLE9BQ1QsQ0FBQyxLQUFLLE9BQU8sTUFBTSxTQUFTLE9BQU8sS0FBSyxJQUFJLEdBQUcsUUFBUTtDQUMzRCxDQUFDO0NBQ0Qsd0JBQXdCO0VBQ3RCLElBQUk7RUFDSixJQUFJLE9BQU8sT0FDVCxDQUFDLEtBQUssT0FBTyxNQUFNLFNBQVMsT0FBTyxLQUFLLElBQUksR0FBRyxXQUFXO0NBQzlELENBQUM7Q0FDRCxPQUFPO0VBQ0w7RUFDQSxhQUFhLFNBQVMsV0FBVzs7RUFFakM7RUFDQTs7RUFFQTs7RUFFQTtDQUNGO0FBQ0Y7QUFFQSxNQUFNLGlCQUFpQixPQUFPLGtCQUFrQjs7QUFFaEQsU0FBUyxjQUFjO0NBQ3JCLE1BQU0sV0FBVyxvQkFBb0IsSUFBSSxZQUFZLGdCQUFnQixJQUFJLElBQUk7Q0FDN0UsT0FBTyxPQUFPLGFBQWEsV0FBVyxXQUFXLEtBQUs7QUFDeEQ7QUFDQSxTQUFTLGdCQUFnQixPQUFPLEtBQUs7Q0FDbkMsSUFBSSxRQUFRLEtBQUssR0FBRztFQUNsQixJQUFJLFFBQVEsZ0JBQWdCLEtBQUs7Q0FDbkMsT0FBTztFQUNMLGFBQWEsZ0JBQWdCLEtBQUs7Q0FDcEM7QUFDRjtBQUVBLFNBQVMsY0FBYyxPQUFPLFVBQVUsQ0FBQyxHQUFHO0NBQzFDLE1BQU0sRUFBRSxTQUFTLGVBQWUsV0FBVyxZQUFZLE1BQU07Q0FDN0QsTUFBTSxjQUFjLG1CQUFtQixVQUFVLGdCQUFnQixVQUFVLE9BQU8sT0FBTyxlQUFlLFVBQVU7Q0FDbEgsTUFBTSxhQUFhLFdBQVcsT0FBTyxhQUFhLFFBQVE7Q0FDMUQsTUFBTSxhQUFhLFdBQVc7Q0FDOUIsTUFBTSxVQUFVLFdBQVcsS0FBSztDQUNoQyxNQUFNLFdBQVcsVUFBVTtFQUN6QixRQUFRLFFBQVEsTUFBTTtDQUN4QjtDQUNBLGtCQUFrQjtFQUNoQixJQUFJLFdBQVcsT0FBTztHQUNwQixXQUFXLFFBQVEsQ0FBQyxZQUFZO0dBQ2hDLE1BQU0sZUFBZSxRQUFRLEtBQUssQ0FBQyxDQUFDLE1BQU0sR0FBRztHQUM3QyxRQUFRLFFBQVEsYUFBYSxNQUFNLGdCQUFnQjtJQUNqRCxNQUFNLE1BQU0sWUFBWSxTQUFTLFNBQVM7SUFDMUMsTUFBTSxXQUFXLFlBQVksTUFBTSxnREFBZ0Q7SUFDbkYsTUFBTSxXQUFXLFlBQVksTUFBTSxnREFBZ0Q7SUFDbkYsSUFBSSxNQUFNLFFBQVEsWUFBWSxRQUFRO0lBQ3RDLElBQUksWUFBWSxLQUFLO0tBQ25CLE1BQU0sWUFBWSxRQUFRLFNBQVMsRUFBRTtJQUN2QztJQUNBLElBQUksWUFBWSxLQUFLO0tBQ25CLE1BQU0sWUFBWSxRQUFRLFNBQVMsRUFBRTtJQUN2QztJQUNBLE9BQU8sTUFBTSxDQUFDLE1BQU07R0FDdEIsQ0FBQztHQUNEO0VBQ0Y7RUFDQSxJQUFJLENBQUMsWUFBWSxPQUNmO0VBQ0YsV0FBVyxRQUFRLE9BQU8sV0FBVyxRQUFRLEtBQUssQ0FBQztFQUNuRCxRQUFRLFFBQVEsV0FBVyxNQUFNO0NBQ25DLENBQUM7Q0FDRCxpQkFBaUIsWUFBWSxVQUFVLFNBQVMsRUFBRSxTQUFTLEtBQUssQ0FBQztDQUNqRSxPQUFPLGVBQWUsUUFBUSxLQUFLO0FBQ3JDO0FBRUEsTUFBTSxzQkFBc0I7Q0FDMUIsTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE9BQU87QUFDVDtBQUNBLE1BQU0seUJBQXlCO0NBQzdCLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osS0FBSztBQUNQO0FBQ0EsTUFBTSx1QkFBdUI7Q0FDM0IsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7QUFDTjtBQUNBLE1BQU0sdUJBQXVCO0NBQzNCLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osS0FBSztBQUNQO0FBQ0EsTUFBTSxxQkFBcUI7QUFDM0IsTUFBTSx1QkFBdUI7Q0FDM0IsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixLQUFLO0FBQ1A7QUFDQSxNQUFNLG9CQUFvQjtDQUN4QixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtBQUNOO0FBQ0EsTUFBTSxxQkFBcUI7Q0FDekIsU0FBUztDQUNULFNBQVM7Q0FDVCxTQUFTO0NBQ1QsUUFBUTtDQUNSLFFBQVE7Q0FDUixTQUFTO0NBQ1QsV0FBVztBQUNiO0FBQ0EsTUFBTSx1QkFBdUI7Q0FDM0IsT0FBTztDQUNQLE9BQU87Q0FDUCxNQUFNO0NBQ04sTUFBTTtDQUNOLE1BQU07Q0FDTixNQUFNO0NBQ04sTUFBTTtDQUNOLE9BQU87Q0FDUCxPQUFPO0NBQ1AsT0FBTztBQUNUO0FBQ0EsTUFBTSx1QkFBdUI7Q0FDM0IsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtBQUNOO0FBQ0EsTUFBTSxxQkFBcUI7Q0FDekIsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7QUFDTjs7QUFHQSxTQUFTLGVBQWUsYUFBYSxVQUFVLENBQUMsR0FBRztDQUNqRCxTQUFTLFNBQVMsR0FBRyxPQUFPO0VBQzFCLElBQUksSUFBSSxRQUFRLFlBQVksUUFBUSxDQUFDLEVBQUU7RUFDdkMsSUFBSSxTQUFTLE1BQ1gsSUFBSSxpQkFBaUIsR0FBRyxLQUFLO0VBQy9CLElBQUksT0FBTyxNQUFNLFVBQ2YsSUFBSSxHQUFHLEVBQUU7RUFDWCxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLEVBQUUsU0FBUyxlQUFlLFdBQVcsYUFBYSxXQUFXLFlBQVksTUFBTTtDQUNyRixNQUFNLGFBQWEsT0FBTyxhQUFhO0NBQ3ZDLE1BQU0sVUFBVSxhQUFhLFdBQVcsS0FBSyxJQUFJLEVBQUUsT0FBTyxLQUFLO0NBQy9ELElBQUksWUFBWTtFQUNkLG1CQUFtQixRQUFRLFFBQVEsQ0FBQyxDQUFDLE1BQU07Q0FDN0M7Q0FDQSxTQUFTLE1BQU0sT0FBTyxNQUFNO0VBQzFCLElBQUksQ0FBQyxRQUFRLFNBQVMsWUFBWTtHQUNoQyxPQUFPLFVBQVUsUUFBUSxZQUFZLFFBQVEsSUFBSSxJQUFJLFlBQVksUUFBUSxJQUFJO0VBQy9FO0VBQ0EsSUFBSSxDQUFDLFFBQ0gsT0FBTztFQUNULE9BQU8sT0FBTyxXQUFXLElBQUksTUFBTSxVQUFVLEtBQUssRUFBRSxDQUFDLENBQUM7Q0FDeEQ7Q0FDQSxNQUFNLGtCQUFrQixNQUFNO0VBQzVCLE9BQU8sb0JBQW9CLGVBQWUsU0FBUyxDQUFDLEVBQUUsSUFBSSxPQUFPO0NBQ25FO0NBQ0EsTUFBTSxrQkFBa0IsTUFBTTtFQUM1QixPQUFPLG9CQUFvQixlQUFlLFNBQVMsQ0FBQyxFQUFFLElBQUksT0FBTztDQUNuRTtDQUNBLE1BQU0sa0JBQWtCLE9BQU8sS0FBSyxXQUFXLENBQUMsQ0FBQyxRQUFRLFdBQVcsTUFBTTtFQUN4RSxPQUFPLGVBQWUsV0FBVyxHQUFHO0dBQ2xDLFdBQVcsYUFBYSxjQUFjLGVBQWUsQ0FBQyxJQUFJLGVBQWUsQ0FBQztHQUMxRSxZQUFZO0dBQ1osY0FBYztFQUNoQixDQUFDO0VBQ0QsT0FBTztDQUNULEdBQUcsQ0FBQyxDQUFDO0NBQ0wsU0FBUyxVQUFVO0VBQ2pCLE1BQU0sU0FBUyxPQUFPLEtBQUssV0FBVyxDQUFDLENBQUMsS0FBSyxNQUFNO0dBQUM7R0FBRyxnQkFBZ0I7R0FBSSxRQUFRLFNBQVMsQ0FBQyxDQUFDO0VBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sRUFBRSxLQUFLLEVBQUUsRUFBRTtFQUM1SCxPQUFPLGVBQWUsT0FBTyxRQUFRLEdBQUcsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztDQUN6RTtDQUNBLE9BQU8sT0FBTyxPQUFPLGlCQUFpQjtFQUNwQztFQUNBO0VBQ0EsUUFBUSxHQUFHO0dBQ1QsT0FBTyxvQkFBb0IsZUFBZSxTQUFTLEdBQUcsRUFBRyxFQUFFLElBQUksT0FBTztFQUN4RTtFQUNBLFFBQVEsR0FBRztHQUNULE9BQU8sb0JBQW9CLGVBQWUsU0FBUyxHQUFHLENBQUMsRUFBRyxFQUFFLElBQUksT0FBTztFQUN6RTtFQUNBLFFBQVEsR0FBRyxHQUFHO0dBQ1osT0FBTyxvQkFBb0IsZUFBZSxTQUFTLENBQUMsRUFBRSxvQkFBb0IsU0FBUyxHQUFHLENBQUMsRUFBRyxFQUFFLElBQUksT0FBTztFQUN6RztFQUNBLFVBQVUsR0FBRztHQUNYLE9BQU8sTUFBTSxPQUFPLFNBQVMsR0FBRyxFQUFHLENBQUM7RUFDdEM7RUFDQSxpQkFBaUIsR0FBRztHQUNsQixPQUFPLE1BQU0sT0FBTyxTQUFTLENBQUMsQ0FBQztFQUNqQztFQUNBLFVBQVUsR0FBRztHQUNYLE9BQU8sTUFBTSxPQUFPLFNBQVMsR0FBRyxDQUFDLEVBQUcsQ0FBQztFQUN2QztFQUNBLGlCQUFpQixHQUFHO0dBQ2xCLE9BQU8sTUFBTSxPQUFPLFNBQVMsQ0FBQyxDQUFDO0VBQ2pDO0VBQ0EsWUFBWSxHQUFHLEdBQUc7R0FDaEIsT0FBTyxNQUFNLE9BQU8sU0FBUyxDQUFDLENBQUMsS0FBSyxNQUFNLE9BQU8sU0FBUyxHQUFHLENBQUMsRUFBRyxDQUFDO0VBQ3BFO0VBQ0E7RUFDQSxTQUFTO0dBQ1AsTUFBTSxNQUFNLFFBQVE7R0FDcEIsT0FBTyxlQUFlLElBQUksTUFBTSxXQUFXLElBQUksS0FBSyxJQUFJLE1BQU0sR0FBRyxhQUFhLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztFQUNyRztDQUNGLENBQUM7QUFDSDtBQUVBLFNBQVMsb0JBQW9CLFNBQVM7Q0FDcEMsTUFBTSxFQUNKLE1BQ0EsU0FBUyxrQkFDUDtDQUNKLE1BQU0sY0FBYyxtQkFBbUIsVUFBVSxzQkFBc0IsTUFBTTtDQUM3RSxNQUFNLFdBQVcsV0FBVyxLQUFLO0NBQ2pDLE1BQU0sVUFBVSxJQUFJO0NBQ3BCLE1BQU0sT0FBTyxJQUFJO0NBQ2pCLE1BQU0sUUFBUSxXQUFXLElBQUk7Q0FDN0IsTUFBTSxRQUFRLFVBQVU7RUFDdEIsSUFBSSxRQUFRLE9BQ1YsUUFBUSxNQUFNLFlBQVksS0FBSztDQUNuQztDQUNBLE1BQU0sY0FBYztFQUNsQixJQUFJLFFBQVEsT0FDVixRQUFRLE1BQU0sTUFBTTtFQUN0QixTQUFTLFFBQVE7Q0FDbkI7Q0FDQSxJQUFJLFlBQVksT0FBTztFQUNyQixtQkFBbUI7R0FDakIsTUFBTSxRQUFRO0dBQ2QsUUFBUSxRQUFRLElBQUksaUJBQWlCLElBQUk7R0FDekMsTUFBTSxrQkFBa0IsRUFDdEIsU0FBUyxLQUNYO0dBQ0EsaUJBQWlCLFNBQVMsWUFBWSxNQUFNO0lBQzFDLEtBQUssUUFBUSxFQUFFO0dBQ2pCLEdBQUcsZUFBZTtHQUNsQixpQkFBaUIsU0FBUyxpQkFBaUIsTUFBTTtJQUMvQyxNQUFNLFFBQVE7R0FDaEIsR0FBRyxlQUFlO0dBQ2xCLGlCQUFpQixTQUFTLGVBQWU7SUFDdkMsU0FBUyxRQUFRO0dBQ25CLEdBQUcsZUFBZTtFQUNwQixDQUFDO0NBQ0g7Q0FDQSx3QkFBd0I7RUFDdEIsTUFBTTtDQUNSLENBQUM7Q0FDRCxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsTUFBTSxzQkFBc0I7Q0FDMUI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGOztBQUVBLFNBQVMsbUJBQW1CLFVBQVUsQ0FBQyxHQUFHO0NBQ3hDLE1BQU0sRUFBRSxTQUFTLGtCQUFrQjtDQUNuQyxNQUFNLE9BQU8sT0FBTyxZQUNsQixvQkFBb0IsS0FBSyxRQUFRLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUMvQztDQUNBLEtBQUssTUFBTSxDQUFDLEtBQUssUUFBUSxjQUFjLElBQUksR0FBRztFQUM1QyxNQUFNLE1BQU0sVUFBVTtHQUNwQixJQUFJLEVBQUUsVUFBVSxPQUFPLEtBQUssSUFBSSxPQUFPLGFBQWEsT0FBTyxTQUFTLFNBQVMsT0FDM0U7R0FDRixPQUFPLFNBQVMsT0FBTztFQUN6QixDQUFDO0NBQ0g7Q0FDQSxNQUFNLGNBQWMsWUFBWTtFQUM5QixJQUFJO0VBQ0osTUFBTSxFQUFFLE9BQU8sUUFBUSxZQUFZLFVBQVUsT0FBTyxLQUFLLElBQUksT0FBTyxZQUFZLENBQUM7RUFDakYsTUFBTSxFQUFFLFlBQVksVUFBVSxPQUFPLEtBQUssSUFBSSxPQUFPLGFBQWEsQ0FBQztFQUNuRSxLQUFLLE1BQU0sT0FBTyxxQkFDaEIsS0FBSyxJQUFJLENBQUMsU0FBUyxLQUFLLFVBQVUsT0FBTyxLQUFLLElBQUksT0FBTyxhQUFhLE9BQU8sS0FBSyxJQUFJLEdBQUc7RUFDM0YsT0FBTyxTQUFTO0dBQ2Q7R0FDQSxPQUFPO0dBQ1A7R0FDQTtHQUNBLEdBQUc7RUFDTCxDQUFDO0NBQ0g7Q0FDQSxNQUFNLFFBQVEsSUFBSSxXQUFXLE1BQU0sQ0FBQztDQUNwQyxJQUFJLFFBQVE7RUFDVixNQUFNLGtCQUFrQixFQUFFLFNBQVMsS0FBSztFQUN4QyxpQkFBaUIsUUFBUSxrQkFBa0IsTUFBTSxRQUFRLFdBQVcsVUFBVSxHQUFHLGVBQWU7RUFDaEcsaUJBQWlCLFFBQVEsb0JBQW9CLE1BQU0sUUFBUSxXQUFXLFlBQVksR0FBRyxlQUFlO0NBQ3RHO0NBQ0EsT0FBTztBQUNUO0FBRUEsU0FBUyxVQUFVLFVBQVUsY0FBYyxHQUFHLE1BQU0sTUFBTSxHQUFHLFNBQVM7Q0FDcEUsTUFBTSxFQUFFLFdBQVcsTUFBTSxHQUFHLGlCQUFpQixXQUFXLENBQUM7Q0FDekQsTUFBTSxjQUFjLFVBQVUsU0FBUyxPQUFPLFFBQVE7Q0FDdEQsWUFBWSxTQUFTLFFBQVEsVUFBVTtFQUNyQyxJQUFJLENBQUMsV0FBVyxPQUFPLFlBQVksS0FBSyxHQUN0QyxZQUFZLFFBQVE7Q0FDeEIsR0FBRyxZQUFZO0NBQ2YsT0FBTztBQUNUOztBQUdBLFNBQVMsY0FBYyxnQkFBZ0IsVUFBVSxDQUFDLEdBQUc7Q0FDbkQsTUFBTSxFQUNKLFdBQVcsT0FDWCxZQUFZLHFCQUNWO0NBQ0osTUFBTSxjQUFjLG1CQUFtQixhQUFhLGlCQUFpQixTQUFTO0NBQzlFLE1BQU0sbUJBQW1CLFdBQVc7Q0FDcEMsTUFBTSxPQUFPLE9BQU8sbUJBQW1CLFdBQVcsRUFBRSxNQUFNLGVBQWUsSUFBSTtDQUM3RSxNQUFNLFFBQVEsV0FBVztDQUN6QixNQUFNLGVBQWU7RUFDbkIsSUFBSSxJQUFJO0VBQ1IsTUFBTSxTQUFTLE1BQU0sS0FBSyxpQkFBaUIsVUFBVSxPQUFPLEtBQUssSUFBSSxHQUFHLFVBQVUsT0FBTyxLQUFLO0NBQ2hHO0NBQ0EsaUJBQWlCLGtCQUFrQixVQUFVLFFBQVEsRUFBRSxTQUFTLEtBQUssQ0FBQztDQUN0RSxNQUFNLFFBQVEsdUJBQXVCLFlBQVk7RUFDL0MsSUFBSSxDQUFDLFlBQVksT0FDZjtFQUNGLElBQUksQ0FBQyxpQkFBaUIsT0FBTztHQUMzQixJQUFJO0lBQ0YsaUJBQWlCLFFBQVEsTUFBTSxVQUFVLFlBQVksTUFBTSxJQUFJO0dBQ2pFLFNBQVMsR0FBRztJQUNWLGlCQUFpQixRQUFRLEtBQUs7R0FDaEMsVUFBVTtJQUNSLE9BQU87R0FDVDtFQUNGO0VBQ0EsSUFBSSxVQUNGLE9BQU8sTUFBTSxpQkFBaUIsS0FBSztDQUN2QyxDQUFDO0NBQ0QsTUFBTTtDQUNOLElBQUksVUFBVTtFQUNaLE9BQU87R0FDTDtHQUNBO0dBQ0E7RUFDRjtDQUNGLE9BQU87RUFDTCxPQUFPO0NBQ1Q7QUFDRjtBQUVBLFNBQVMsYUFBYSxVQUFVLENBQUMsR0FBRztDQUNsQyxNQUFNLEVBQ0osWUFBWSxrQkFDWixPQUFPLE9BQ1AsUUFDQSxlQUFlLE1BQ2YsU0FBUyxVQUNQO0NBQ0osTUFBTSwwQkFBMEIsbUJBQW1CLGFBQWEsZUFBZSxTQUFTO0NBQ3hGLE1BQU0saUJBQWlCLGNBQWMsZ0JBQWdCO0NBQ3JELE1BQU0sa0JBQWtCLGNBQWMsaUJBQWlCO0NBQ3ZELE1BQU0sY0FBYyxlQUFlLHdCQUF3QixTQUFTLE1BQU07Q0FDMUUsTUFBTSxPQUFPLFdBQVcsRUFBRTtDQUMxQixNQUFNLFNBQVMsV0FBVyxLQUFLO0NBQy9CLE1BQU0sVUFBVSxtQkFBbUIsT0FBTyxRQUFRLE9BQU8sY0FBYyxFQUFFLFdBQVcsTUFBTSxDQUFDO0NBQzNGLGVBQWUsYUFBYTtFQUMxQixJQUFJLFlBQVksRUFBRSx3QkFBd0IsU0FBUyxVQUFVLGVBQWUsS0FBSztFQUNqRixJQUFJLENBQUMsV0FBVztHQUNkLElBQUk7SUFDRixLQUFLLFFBQVEsTUFBTSxVQUFVLFVBQVUsU0FBUztHQUNsRCxTQUFTLEdBQUc7SUFDVixZQUFZO0dBQ2Q7RUFDRjtFQUNBLElBQUksV0FBVztHQUNiLEtBQUssUUFBUSxXQUFXO0VBQzFCO0NBQ0Y7Q0FDQSxJQUFJLFlBQVksU0FBUyxNQUN2QixpQkFBaUIsQ0FBQyxRQUFRLEtBQUssR0FBRyxZQUFZLEVBQUUsU0FBUyxLQUFLLENBQUM7Q0FDakUsZUFBZSxLQUFLLFFBQVEsUUFBUSxNQUFNLEdBQUc7RUFDM0MsSUFBSSxZQUFZLFNBQVMsU0FBUyxNQUFNO0dBQ3RDLElBQUksWUFBWSxFQUFFLHdCQUF3QixTQUFTLFVBQVUsZ0JBQWdCLEtBQUs7R0FDbEYsSUFBSSxDQUFDLFdBQVc7SUFDZCxJQUFJO0tBQ0YsTUFBTSxVQUFVLFVBQVUsVUFBVSxLQUFLO0lBQzNDLFNBQVMsR0FBRztLQUNWLFlBQVk7SUFDZDtHQUNGO0dBQ0EsSUFBSSxXQUNGLFdBQVcsS0FBSztHQUNsQixLQUFLLFFBQVE7R0FDYixPQUFPLFFBQVE7R0FDZixRQUFRLE1BQU07RUFDaEI7Q0FDRjtDQUNBLFNBQVMsV0FBVyxPQUFPO0VBQ3pCLE1BQU0sS0FBSyxTQUFTLGNBQWMsVUFBVTtFQUM1QyxHQUFHLFFBQVEsU0FBUyxPQUFPLFFBQVE7RUFDbkMsR0FBRyxNQUFNLFdBQVc7RUFDcEIsR0FBRyxNQUFNLFVBQVU7RUFDbkIsU0FBUyxLQUFLLFlBQVksRUFBRTtFQUM1QixHQUFHLE9BQU87RUFDVixTQUFTLFlBQVksTUFBTTtFQUMzQixHQUFHLE9BQU87Q0FDWjtDQUNBLFNBQVMsYUFBYTtFQUNwQixJQUFJLElBQUksSUFBSTtFQUNaLFFBQVEsTUFBTSxNQUFNLEtBQUssWUFBWSxPQUFPLEtBQUssSUFBSSxTQUFTLGlCQUFpQixPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssUUFBUSxNQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsU0FBUyxNQUFNLE9BQU8sS0FBSztDQUNySztDQUNBLFNBQVMsVUFBVSxRQUFRO0VBQ3pCLE9BQU8sV0FBVyxhQUFhLFdBQVc7Q0FDNUM7Q0FDQSxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsU0FBUyxrQkFBa0IsVUFBVSxDQUFDLEdBQUc7Q0FDdkMsTUFBTSxFQUNKLFlBQVksa0JBQ1osT0FBTyxPQUNQLFFBQ0EsZUFBZSxTQUNiO0NBQ0osTUFBTSxjQUFjLG1CQUFtQixhQUFhLGVBQWUsU0FBUztDQUM1RSxNQUFNLFVBQVUsSUFBSSxDQUFDLENBQUM7Q0FDdEIsTUFBTSxTQUFTLFdBQVcsS0FBSztDQUMvQixNQUFNLFVBQVUsbUJBQW1CLE9BQU8sUUFBUSxPQUFPLGNBQWMsRUFBRSxXQUFXLE1BQU0sQ0FBQztDQUMzRixTQUFTLGdCQUFnQjtFQUN2QixJQUFJLFlBQVksT0FBTztHQUNyQixVQUFVLFVBQVUsS0FBSyxDQUFDLENBQUMsTUFBTSxVQUFVO0lBQ3pDLFFBQVEsUUFBUTtHQUNsQixDQUFDO0VBQ0g7Q0FDRjtDQUNBLElBQUksWUFBWSxTQUFTLE1BQU07RUFDN0IsaUJBQWlCLENBQUMsUUFBUSxLQUFLLEdBQUcsZUFBZSxFQUFFLFNBQVMsS0FBSyxDQUFDO0NBQ3BFO0NBQ0EsZUFBZSxLQUFLLFFBQVEsUUFBUSxNQUFNLEdBQUc7RUFDM0MsSUFBSSxZQUFZLFNBQVMsU0FBUyxNQUFNO0dBQ3RDLE1BQU0sVUFBVSxVQUFVLE1BQU0sS0FBSztHQUNyQyxRQUFRLFFBQVE7R0FDaEIsT0FBTyxRQUFRO0dBQ2YsUUFBUSxNQUFNO0VBQ2hCO0NBQ0Y7Q0FDQSxPQUFPO0VBQ0w7RUFDQSxTQUFTLGdCQUFnQixPQUFPO0VBQ2hDLFFBQVEsU0FBUyxNQUFNO0VBQ3ZCO0VBQ0EsTUFBTTtDQUNSO0FBQ0Y7QUFFQSxTQUFTLFlBQVksUUFBUTtDQUMzQixPQUFPLEtBQUssTUFBTSxLQUFLLFVBQVUsTUFBTSxDQUFDO0FBQzFDO0FBQ0EsU0FBUyxVQUFVLFFBQVEsVUFBVSxDQUFDLEdBQUc7Q0FDdkMsTUFBTSxTQUFTLElBQUksQ0FBQyxDQUFDO0NBQ3JCLE1BQU0sYUFBYSxXQUFXLEtBQUs7Q0FDbkMsSUFBSSxZQUFZO0NBQ2hCLE1BQU0sRUFDSixRQUNBLFFBQVEsYUFFUixPQUFPLE1BQ1AsWUFBWSxTQUNWO0NBQ0osTUFBTSxjQUFjO0VBQ2xCLElBQUksV0FBVztHQUNiLFlBQVk7R0FDWjtFQUNGO0VBQ0EsV0FBVyxRQUFRO0NBQ3JCLEdBQUc7RUFDRCxNQUFNO0VBQ04sT0FBTztDQUNULENBQUM7Q0FDRCxTQUFTLE9BQU87RUFDZCxZQUFZO0VBQ1osV0FBVyxRQUFRO0VBQ25CLE9BQU8sUUFBUSxNQUFNLFFBQVEsTUFBTSxDQUFDO0NBQ3RDO0NBQ0EsSUFBSSxDQUFDLFdBQVcsTUFBTSxNQUFNLEtBQUssT0FBTyxXQUFXLGFBQWE7RUFDOUQsTUFBTSxRQUFRLE1BQU07R0FDbEIsR0FBRztHQUNIO0dBQ0E7RUFDRixDQUFDO0NBQ0gsT0FBTztFQUNMLEtBQUs7Q0FDUDtDQUNBLE9BQU87RUFBRTtFQUFRO0VBQVk7Q0FBSztBQUNwQztBQUVBLE1BQU0sVUFBVSxPQUFPLGVBQWUsY0FBYyxhQUFhLE9BQU8sV0FBVyxjQUFjLFNBQVMsT0FBTyxXQUFXLGNBQWMsU0FBUyxPQUFPLFNBQVMsY0FBYyxPQUFPLENBQUM7QUFDekwsTUFBTSxZQUFZO0FBQ2xCLE1BQU0sV0FBMkIsNEJBQVk7QUFDN0MsU0FBUyxjQUFjO0NBQ3JCLElBQUksRUFBRSxhQUFhLFVBQ2pCLFFBQVEsYUFBYSxRQUFRLGNBQWMsQ0FBQztDQUM5QyxPQUFPLFFBQVE7QUFDakI7QUFDQSxTQUFTLGNBQWMsS0FBSyxVQUFVO0NBQ3BDLE9BQU8sU0FBUyxRQUFRO0FBQzFCO0FBQ0EsU0FBUyxjQUFjLEtBQUssSUFBSTtDQUM5QixTQUFTLE9BQU87QUFDbEI7O0FBR0EsU0FBUyxpQkFBaUIsU0FBUztDQUNqQyxPQUFPLGNBQWMsZ0NBQWdDLE9BQU87QUFDOUQ7QUFFQSxTQUFTLG9CQUFvQixTQUFTO0NBQ3BDLE9BQU8sV0FBVyxPQUFPLFFBQVEsbUJBQW1CLE1BQU0sUUFBUSxtQkFBbUIsTUFBTSxRQUFRLG1CQUFtQixPQUFPLFNBQVMsT0FBTyxZQUFZLFlBQVksWUFBWSxPQUFPLFlBQVksV0FBVyxXQUFXLE9BQU8sWUFBWSxXQUFXLFdBQVcsQ0FBQyxPQUFPLE1BQU0sT0FBTyxJQUFJLFdBQVc7QUFDelM7QUFFQSxNQUFNLHFCQUFxQjtDQUN6QixTQUFTO0VBQ1AsT0FBTyxNQUFNLE1BQU07RUFDbkIsUUFBUSxNQUFNLE9BQU8sQ0FBQztDQUN4QjtDQUNBLFFBQVE7RUFDTixPQUFPLE1BQU0sS0FBSyxNQUFNLENBQUM7RUFDekIsUUFBUSxNQUFNLEtBQUssVUFBVSxDQUFDO0NBQ2hDO0NBQ0EsUUFBUTtFQUNOLE9BQU8sTUFBTSxPQUFPLFdBQVcsQ0FBQztFQUNoQyxRQUFRLE1BQU0sT0FBTyxDQUFDO0NBQ3hCO0NBQ0EsS0FBSztFQUNILE9BQU8sTUFBTTtFQUNiLFFBQVEsTUFBTSxPQUFPLENBQUM7Q0FDeEI7Q0FDQSxRQUFRO0VBQ04sT0FBTyxNQUFNO0VBQ2IsUUFBUSxNQUFNLE9BQU8sQ0FBQztDQUN4QjtDQUNBLEtBQUs7RUFDSCxPQUFPLE1BQU0sSUFBSSxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUM7RUFDbEMsUUFBUSxNQUFNLEtBQUssVUFBVSxNQUFNLEtBQUssRUFBRSxRQUFRLENBQUMsQ0FBQztDQUN0RDtDQUNBLEtBQUs7RUFDSCxPQUFPLE1BQU0sSUFBSSxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUM7RUFDbEMsUUFBUSxNQUFNLEtBQUssVUFBVSxNQUFNLEtBQUssQ0FBQyxDQUFDO0NBQzVDO0NBQ0EsTUFBTTtFQUNKLE9BQU8sTUFBTSxJQUFJLEtBQUssQ0FBQztFQUN2QixRQUFRLE1BQU0sRUFBRSxZQUFZO0NBQzlCO0FBQ0Y7QUFDQSxNQUFNLHlCQUF5QjtBQUMvQixTQUFTLFdBQVcsS0FBSyxVQUFVLFNBQVMsVUFBVSxDQUFDLEdBQUc7Q0FDeEQsSUFBSTtDQUNKLE1BQU0sRUFDSixRQUFRLE9BQ1IsT0FBTyxNQUNQLHlCQUF5QixNQUN6QixnQkFBZ0IsTUFDaEIsZ0JBQWdCLE9BQ2hCLFNBQ0EsU0FBUyxlQUNULGFBQ0EsV0FBVyxNQUFNO0VBQ2YsUUFBUSxNQUFNLENBQUM7Q0FDakIsR0FDQSxrQkFDRTtDQUNKLE1BQU0sUUFBUSxVQUFVLGFBQWEsSUFBRyxDQUFFLE9BQU8sYUFBYSxhQUFhLFNBQVMsSUFBSSxRQUFRO0NBQ2hHLE1BQU0sY0FBYyxlQUFlLFFBQVEsR0FBRyxDQUFDO0NBQy9DLElBQUksQ0FBQyxTQUFTO0VBQ1osSUFBSTtHQUNGLFVBQVUsY0FBYywyQkFBMkI7SUFDakQsSUFBSTtJQUNKLFFBQVEsTUFBTSxrQkFBa0IsT0FBTyxLQUFLLElBQUksSUFBSTtHQUN0RCxDQUFDLENBQUMsQ0FBQztFQUNMLFNBQVMsR0FBRztHQUNWLFFBQVEsQ0FBQztFQUNYO0NBQ0Y7Q0FDQSxJQUFJLENBQUMsU0FDSCxPQUFPO0NBQ1QsTUFBTSxVQUFVLFFBQVEsUUFBUTtDQUNoQyxNQUFNLE9BQU8sb0JBQW9CLE9BQU87Q0FDeEMsTUFBTSxjQUFjLEtBQUssUUFBUSxlQUFlLE9BQU8sS0FBSyxtQkFBbUI7Q0FDL0UsTUFBTSxFQUFFLE9BQU8sWUFBWSxRQUFRLGdCQUFnQixjQUNqRCxPQUNDLGFBQWEsTUFBTSxRQUFRLEdBQzVCO0VBQUU7RUFBTztFQUFNO0NBQVksQ0FDN0I7Q0FDQSxNQUFNLG1CQUFtQixPQUFPLEdBQUcsRUFBRSxNQUFNLENBQUM7Q0FDNUMsSUFBSSxlQUFlO0NBQ25CLE1BQU0sa0JBQWtCLE9BQU87RUFDN0IsSUFBSSxpQkFBaUIsQ0FBQyxjQUFjO0dBQ2xDO0VBQ0Y7RUFDQSxPQUFPLEVBQUU7Q0FDWDtDQUNBLE1BQU0sd0JBQXdCLE9BQU87RUFDbkMsSUFBSSxpQkFBaUIsQ0FBQyxjQUFjO0dBQ2xDO0VBQ0Y7RUFDQSxzQkFBc0IsRUFBRTtDQUMxQjtDQUNBLElBQUksVUFBVSx3QkFBd0I7RUFDcEMsSUFBSSxtQkFBbUIsU0FDckIsaUJBQWlCLFFBQVEsV0FBVyxnQkFBZ0IsRUFBRSxTQUFTLEtBQUssQ0FBQztPQUVyRSxpQkFBaUIsUUFBUSx3QkFBd0Isb0JBQW9CO0NBQ3pFO0NBQ0EsSUFBSSxlQUFlO0VBQ2pCLG1CQUFtQjtHQUNqQixlQUFlO0dBQ2YsT0FBTztFQUNULENBQUM7Q0FDSCxPQUFPO0VBQ0wsT0FBTztDQUNUO0NBQ0EsU0FBUyxtQkFBbUIsVUFBVSxVQUFVO0VBQzlDLElBQUksUUFBUTtHQUNWLE1BQU0sVUFBVTtJQUNkLEtBQUssWUFBWTtJQUNqQjtJQUNBO0lBQ0EsYUFBYTtHQUNmO0dBQ0EsT0FBTyxjQUFjLG1CQUFtQixVQUFVLElBQUksYUFBYSxXQUFXLE9BQU8sSUFBSSxJQUFJLFlBQVksd0JBQXdCLEVBQy9ILFFBQVEsUUFDVixDQUFDLENBQUM7RUFDSjtDQUNGO0NBQ0EsU0FBUyxNQUFNLEdBQUc7RUFDaEIsSUFBSTtHQUNGLE1BQU0sV0FBVyxRQUFRLFFBQVEsWUFBWSxLQUFLO0dBQ2xELElBQUksS0FBSyxNQUFNO0lBQ2IsbUJBQW1CLFVBQVUsSUFBSTtJQUNqQyxRQUFRLFdBQVcsWUFBWSxLQUFLO0dBQ3RDLE9BQU87SUFDTCxNQUFNLGFBQWEsV0FBVyxNQUFNLENBQUM7SUFDckMsSUFBSSxhQUFhLFlBQVk7S0FDM0IsUUFBUSxRQUFRLFlBQVksT0FBTyxVQUFVO0tBQzdDLG1CQUFtQixVQUFVLFVBQVU7SUFDekM7R0FDRjtFQUNGLFNBQVMsR0FBRztHQUNWLFFBQVEsQ0FBQztFQUNYO0NBQ0Y7Q0FDQSxTQUFTLEtBQUssT0FBTztFQUNuQixNQUFNLFdBQVcsUUFBUSxNQUFNLFdBQVcsUUFBUSxRQUFRLFlBQVksS0FBSztFQUMzRSxJQUFJLFlBQVksTUFBTTtHQUNwQixJQUFJLGlCQUFpQixXQUFXLE1BQzlCLFFBQVEsUUFBUSxZQUFZLE9BQU8sV0FBVyxNQUFNLE9BQU8sQ0FBQztHQUM5RCxPQUFPO0VBQ1QsT0FBTyxJQUFJLENBQUMsU0FBUyxlQUFlO0dBQ2xDLE1BQU0sUUFBUSxXQUFXLEtBQUssUUFBUTtHQUN0QyxJQUFJLE9BQU8sa0JBQWtCLFlBQzNCLE9BQU8sY0FBYyxPQUFPLE9BQU87UUFDaEMsSUFBSSxTQUFTLFlBQVksQ0FBQyxNQUFNLFFBQVEsS0FBSyxHQUNoRCxPQUFPO0lBQUUsR0FBRztJQUFTLEdBQUc7R0FBTTtHQUNoQyxPQUFPO0VBQ1QsT0FBTyxJQUFJLE9BQU8sYUFBYSxVQUFVO0dBQ3ZDLE9BQU87RUFDVCxPQUFPO0dBQ0wsT0FBTyxXQUFXLEtBQUssUUFBUTtFQUNqQztDQUNGO0NBQ0EsU0FBUyxPQUFPLE9BQU87RUFDckIsSUFBSSxTQUFTLE1BQU0sZ0JBQWdCLFNBQ2pDO0VBQ0YsSUFBSSxTQUFTLE1BQU0sT0FBTyxNQUFNO0dBQzlCLEtBQUssUUFBUTtHQUNiO0VBQ0Y7RUFDQSxJQUFJLFNBQVMsTUFBTSxRQUFRLFlBQVksT0FBTztHQUM1QztFQUNGO0VBQ0EsV0FBVztFQUNYLElBQUk7R0FDRixNQUFNLGlCQUFpQixXQUFXLE1BQU0sS0FBSyxLQUFLO0dBQ2xELElBQUksVUFBVSxLQUFLLE1BQU0sU0FBUyxPQUFPLEtBQUssSUFBSSxNQUFNLGNBQWMsZ0JBQWdCO0lBQ3BGLEtBQUssUUFBUSxLQUFLLEtBQUs7R0FDekI7RUFDRixTQUFTLEdBQUc7R0FDVixRQUFRLENBQUM7RUFDWCxVQUFVO0dBQ1IsSUFBSSxPQUNGLFNBQVMsV0FBVztRQUVwQixZQUFZO0VBQ2hCO0NBQ0Y7Q0FDQSxTQUFTLHNCQUFzQixPQUFPO0VBQ3BDLE9BQU8sTUFBTSxNQUFNO0NBQ3JCO0NBQ0EsT0FBTztBQUNUO0FBRUEsTUFBTSxvQkFBb0I7QUFDMUIsU0FBUyxhQUFhLFVBQVUsQ0FBQyxHQUFHO0NBQ2xDLE1BQU0sRUFDSixXQUFXLFFBQ1gsWUFBWSxTQUNaLGVBQWUsUUFDZixTQUFTLGVBQ1QsU0FDQSxhQUFhLHVCQUNiLHlCQUF5QixNQUN6QixZQUNBLFVBQ0Esb0JBQW9CLFNBQ2xCO0NBQ0osTUFBTSxRQUFRO0VBQ1osTUFBTTtFQUNOLE9BQU87RUFDUCxNQUFNO0VBQ04sR0FBRyxRQUFRLFNBQVMsQ0FBQztDQUN2QjtDQUNBLE1BQU0sZ0JBQWdCLGlCQUFpQixFQUFFLE9BQU8sQ0FBQztDQUNqRCxNQUFNLFNBQVMsZUFBZSxjQUFjLFFBQVEsU0FBUyxPQUFPO0NBQ3BFLE1BQU0sUUFBUSxlQUFlLGNBQWMsT0FBTyxNQUFNLFlBQVksSUFBSSxXQUFXLFlBQVksY0FBYyxTQUFTO0VBQUU7RUFBUTtDQUF1QixDQUFDO0NBQ3hKLE1BQU0sUUFBUSxlQUFlLE1BQU0sVUFBVSxTQUFTLE9BQU8sUUFBUSxNQUFNLEtBQUs7Q0FDaEYsTUFBTSxrQkFBa0IsY0FDdEIsb0JBQ0MsV0FBVyxZQUFZLFVBQVU7RUFDaEMsTUFBTSxLQUFLLE9BQU8sY0FBYyxXQUFXLFVBQVUsT0FBTyxLQUFLLElBQUksT0FBTyxTQUFTLGNBQWMsU0FBUyxJQUFJLGFBQWEsU0FBUztFQUN0SSxJQUFJLENBQUMsSUFDSDtFQUNGLE1BQU0sK0JBQStCLElBQUksSUFBSTtFQUM3QyxNQUFNLGtDQUFrQyxJQUFJLElBQUk7RUFDaEQsSUFBSSxvQkFBb0I7RUFDeEIsSUFBSSxlQUFlLFNBQVM7R0FDMUIsTUFBTSxVQUFVLE1BQU0sTUFBTSxLQUFLO0dBQ2pDLE9BQU8sT0FBTyxLQUFLLENBQUMsQ0FBQyxTQUFTLE9BQU8sS0FBSyxHQUFFLENBQUUsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsU0FBUyxNQUFNO0lBQ3pGLElBQUksUUFBUSxTQUFTLENBQUMsR0FDcEIsYUFBYSxJQUFJLENBQUM7U0FFbEIsZ0JBQWdCLElBQUksQ0FBQztHQUN6QixDQUFDO0VBQ0gsT0FBTztHQUNMLG9CQUFvQjtJQUFFLEtBQUs7SUFBWTtHQUFNO0VBQy9DO0VBQ0EsSUFBSSxhQUFhLFNBQVMsS0FBSyxnQkFBZ0IsU0FBUyxLQUFLLHNCQUFzQixNQUNqRjtFQUNGLElBQUk7RUFDSixJQUFJLG1CQUFtQjtHQUNyQixRQUFRLE9BQU8sU0FBUyxjQUFjLE9BQU87R0FDN0MsTUFBTSxZQUFZLFNBQVMsZUFBZSxpQkFBaUIsQ0FBQztHQUM1RCxPQUFPLFNBQVMsS0FBSyxZQUFZLEtBQUs7RUFDeEM7RUFDQSxLQUFLLE1BQU0sS0FBSyxjQUFjO0dBQzVCLEdBQUcsVUFBVSxJQUFJLENBQUM7RUFDcEI7RUFDQSxLQUFLLE1BQU0sS0FBSyxpQkFBaUI7R0FDL0IsR0FBRyxVQUFVLE9BQU8sQ0FBQztFQUN2QjtFQUNBLElBQUksbUJBQW1CO0dBQ3JCLEdBQUcsYUFBYSxrQkFBa0IsS0FBSyxrQkFBa0IsS0FBSztFQUNoRTtFQUNBLElBQUksbUJBQW1CO0dBQ3JCLE9BQU8saUJBQWlCLEtBQUssQ0FBQyxDQUFDO0dBQy9CLFNBQVMsS0FBSyxZQUFZLEtBQUs7RUFDakM7Q0FDRixDQUNGO0NBQ0EsU0FBUyxpQkFBaUIsTUFBTTtFQUM5QixJQUFJO0VBQ0osZ0JBQWdCLFVBQVUsWUFBWSxLQUFLLE1BQU0sVUFBVSxPQUFPLEtBQUssSUFBSTtDQUM3RTtDQUNBLFNBQVMsVUFBVSxNQUFNO0VBQ3ZCLElBQUksUUFBUSxXQUNWLFFBQVEsVUFBVSxNQUFNLGdCQUFnQjtPQUV4QyxpQkFBaUIsSUFBSTtDQUN6QjtDQUNBLE1BQU0sT0FBTyxXQUFXO0VBQUUsT0FBTztFQUFRLFdBQVc7Q0FBSyxDQUFDO0NBQzFELG1CQUFtQixVQUFVLE1BQU0sS0FBSyxDQUFDO0NBQ3pDLE1BQU0sT0FBTyxTQUFTO0VBQ3BCLE1BQU07R0FDSixPQUFPLFdBQVcsTUFBTSxRQUFRLE1BQU07RUFDeEM7RUFDQSxJQUFJLEdBQUc7R0FDTCxNQUFNLFFBQVE7RUFDaEI7Q0FDRixDQUFDO0NBQ0QsT0FBTyxPQUFPLE9BQU8sTUFBTTtFQUFFO0VBQU87RUFBUTtDQUFNLENBQUM7QUFDckQ7O0FBR0EsU0FBUyxpQkFBaUIsV0FBVyxXQUFXLEtBQUssR0FBRztDQUN0RCxNQUFNLGNBQWMsZ0JBQWdCO0NBQ3BDLE1BQU0sYUFBYSxnQkFBZ0I7Q0FDbkMsTUFBTSxhQUFhLGdCQUFnQjtDQUNuQyxJQUFJLFdBQVc7Q0FDZixNQUFNLFVBQVUsU0FBUztFQUN2QixXQUFXLFFBQVEsSUFBSTtFQUN2QixTQUFTLFFBQVE7RUFDakIsT0FBTyxJQUFJLFNBQVMsWUFBWTtHQUM5QixXQUFXO0VBQ2IsQ0FBQztDQUNIO0NBQ0EsTUFBTSxXQUFXLFNBQVM7RUFDeEIsU0FBUyxRQUFRO0VBQ2pCLFlBQVksUUFBUSxJQUFJO0VBQ3hCLFNBQVM7R0FBRTtHQUFNLFlBQVk7RUFBTSxDQUFDO0NBQ3RDO0NBQ0EsTUFBTSxVQUFVLFNBQVM7RUFDdkIsU0FBUyxRQUFRO0VBQ2pCLFdBQVcsUUFBUSxJQUFJO0VBQ3ZCLFNBQVM7R0FBRTtHQUFNLFlBQVk7RUFBSyxDQUFDO0NBQ3JDO0NBQ0EsT0FBTztFQUNMLFlBQVksZUFBZSxTQUFTLEtBQUs7RUFDekM7RUFDQTtFQUNBO0VBQ0EsVUFBVSxXQUFXO0VBQ3JCLFdBQVcsWUFBWTtFQUN2QixVQUFVLFdBQVc7Q0FDdkI7QUFDRjtBQUVBLFNBQVMsYUFBYSxrQkFBa0IsU0FBUztDQUMvQyxJQUFJLElBQUk7Q0FDUixNQUFNLFlBQVksV0FBVyxRQUFRLGdCQUFnQixDQUFDO0NBQ3RELE1BQU0scUJBQXFCLG9CQUFvQjtFQUM3QyxJQUFJLEtBQUs7RUFDVCxNQUFNLFFBQVEsVUFBVSxRQUFRO0VBQ2hDLFVBQVUsUUFBUSxRQUFRLElBQUksSUFBSTtFQUNsQyxDQUFDLE1BQU0sV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLFdBQVcsT0FBTyxLQUFLLElBQUksSUFBSSxLQUFLLE9BQU87RUFDckYsSUFBSSxVQUFVLFNBQVMsR0FBRztHQUN4QixtQkFBbUIsTUFBTTtHQUN6QixDQUFDLE1BQU0sV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLGVBQWUsT0FBTyxLQUFLLElBQUksSUFBSSxLQUFLLE9BQU87RUFDM0Y7Q0FDRixJQUFJLEtBQUssV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLGFBQWEsT0FBTyxLQUFLLEtBQUssRUFBRSxZQUFZLEtBQUssV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLGNBQWMsT0FBTyxLQUFLLE1BQU0sQ0FBQztDQUNqSyxNQUFNLFNBQVMsY0FBYztFQUMzQixJQUFJO0VBQ0osVUFBVSxTQUFTLE1BQU0sUUFBUSxTQUFTLE1BQU0sT0FBTyxNQUFNLFFBQVEsZ0JBQWdCO0NBQ3ZGO0NBQ0EsTUFBTSxhQUFhO0VBQ2pCLG1CQUFtQixNQUFNO0VBQ3pCLE1BQU07Q0FDUjtDQUNBLE1BQU0sZUFBZTtFQUNuQixJQUFJLENBQUMsbUJBQW1CLFNBQVMsT0FBTztHQUN0QyxJQUFJLFVBQVUsUUFBUSxHQUFHO0lBQ3ZCLG1CQUFtQixPQUFPO0dBQzVCO0VBQ0Y7Q0FDRjtDQUNBLE1BQU0sU0FBUyxjQUFjO0VBQzNCLE1BQU0sU0FBUztFQUNmLG1CQUFtQixPQUFPO0NBQzVCO0NBQ0EsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsT0FBTyxtQkFBbUI7RUFDMUI7RUFDQSxVQUFVLG1CQUFtQjtDQUMvQjtBQUNGO0FBRUEsU0FBUyxVQUFVLE1BQU0sUUFBUSxVQUFVLENBQUMsR0FBRztDQUM3QyxNQUFNLEVBQUUsU0FBUyxlQUFlLGNBQWMsVUFBVSxVQUFVO0NBQ2xFLE1BQU0sV0FBVyxXQUFXLFlBQVk7Q0FDeEMsTUFBTSxRQUFRLGVBQWU7RUFDM0IsSUFBSTtFQUNKLE9BQU8sYUFBYSxNQUFNLE9BQU8sS0FBSyxVQUFVLE9BQU8sS0FBSyxJQUFJLE9BQU8sYUFBYSxPQUFPLEtBQUssSUFBSSxHQUFHO0NBQ3pHLENBQUM7Q0FDRCxTQUFTLGVBQWU7RUFDdEIsSUFBSTtFQUNKLE1BQU0sTUFBTSxRQUFRLElBQUk7RUFDeEIsTUFBTSxLQUFLLFFBQVEsS0FBSztFQUN4QixJQUFJLE1BQU0sVUFBVSxLQUFLO0dBQ3ZCLE1BQU0sU0FBUyxLQUFLLE9BQU8saUJBQWlCLEVBQUUsQ0FBQyxDQUFDLGlCQUFpQixHQUFHLE1BQU0sT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLO0dBQ2xHLFNBQVMsUUFBUSxTQUFTLFNBQVMsU0FBUztFQUM5QztDQUNGO0NBQ0EsSUFBSSxTQUFTO0VBQ1gsb0JBQW9CLE9BQU8sY0FBYztHQUN2QyxpQkFBaUIsQ0FBQyxTQUFTLE9BQU87R0FDbEM7RUFDRixDQUFDO0NBQ0g7Q0FDQSxNQUNFLENBQUMsYUFBYSxRQUFRLElBQUksQ0FBQyxJQUMxQixHQUFHLFFBQVE7RUFDVixJQUFJLElBQUksTUFBTSxJQUFJLElBQ2hCLElBQUksRUFBRSxDQUFDLE1BQU0sZUFBZSxJQUFJLEVBQUU7RUFDcEMsYUFBYTtDQUNmLEdBQ0EsRUFBRSxXQUFXLEtBQUssQ0FDcEI7Q0FDQSxNQUNFLENBQUMsVUFBVSxLQUFLLElBQ2YsQ0FBQyxLQUFLLFFBQVE7RUFDYixNQUFNLFdBQVcsUUFBUSxJQUFJO0VBQzdCLEtBQUssTUFBTSxPQUFPLEtBQUssSUFBSSxHQUFHLFVBQVUsVUFBVTtHQUNoRCxJQUFJLE9BQU8sTUFDVCxHQUFHLE1BQU0sZUFBZSxRQUFRO1FBRWhDLEdBQUcsTUFBTSxZQUFZLFVBQVUsR0FBRztFQUN0QztDQUNGLEdBQ0EsRUFBRSxXQUFXLEtBQUssQ0FDcEI7Q0FDQSxPQUFPO0FBQ1Q7QUFFQSxTQUFTLGtCQUFrQixlQUFlO0NBQ3hDLE1BQU0sS0FBSyxtQkFBbUI7Q0FDOUIsTUFBTSxpQkFBaUIsMEJBQ2YsWUFDQSxnQkFBZ0IsYUFBYSxhQUFhLElBQUksR0FBRyxNQUFNLEdBQy9EO0NBQ0EsVUFBVSxlQUFlLE9BQU87Q0FDaEMsVUFBVSxlQUFlLE9BQU87Q0FDaEMsT0FBTztBQUNUO0FBRUEsU0FBUyxhQUFhLE1BQU0sU0FBUztDQUNuQyxNQUFNLFFBQVEsV0FBVyxnQkFBZ0IsQ0FBQztDQUMxQyxNQUFNLFVBQVUsTUFBTSxJQUFJO0NBQzFCLE1BQU0sUUFBUSxTQUFTO0VBQ3JCLE1BQU07R0FDSixJQUFJO0dBQ0osTUFBTSxhQUFhLFFBQVE7R0FDM0IsSUFBSSxVQUFVLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxjQUFjLFFBQVEsV0FBVyxNQUFNLE9BQU8sVUFBVSxJQUFJLFdBQVcsUUFBUSxNQUFNLEtBQUs7R0FDM0ksSUFBSSxTQUFTLEdBQ1gsVUFBVSxLQUFLLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxrQkFBa0IsT0FBTyxLQUFLO0dBQ2xGLE9BQU87RUFDVDtFQUNBLElBQUksR0FBRztHQUNMLElBQUksQ0FBQztFQUNQO0NBQ0YsQ0FBQztDQUNELFNBQVMsSUFBSSxHQUFHO0VBQ2QsTUFBTSxhQUFhLFFBQVE7RUFDM0IsTUFBTSxTQUFTLFdBQVc7RUFDMUIsTUFBTSxVQUFVLElBQUksU0FBUyxVQUFVO0VBQ3ZDLE1BQU0sUUFBUSxXQUFXO0VBQ3pCLE1BQU0sUUFBUTtFQUNkLE9BQU87Q0FDVDtDQUNBLFNBQVMsTUFBTSxRQUFRLEdBQUc7RUFDeEIsT0FBTyxJQUFJLE1BQU0sUUFBUSxLQUFLO0NBQ2hDO0NBQ0EsU0FBUyxLQUFLLElBQUksR0FBRztFQUNuQixPQUFPLE1BQU0sQ0FBQztDQUNoQjtDQUNBLFNBQVMsS0FBSyxJQUFJLEdBQUc7RUFDbkIsT0FBTyxNQUFNLENBQUMsQ0FBQztDQUNqQjtDQUNBLFNBQVMsa0JBQWtCO0VBQ3pCLElBQUksSUFBSTtFQUNSLFFBQVEsS0FBSyxTQUFTLEtBQUssV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLGlCQUFpQixPQUFPLEtBQUssUUFBUSxJQUFJLENBQUMsQ0FBQyxFQUFFLE1BQU0sT0FBTyxLQUFLLEtBQUs7Q0FDcEk7Q0FDQSxNQUFNLGVBQWUsSUFBSSxNQUFNLEtBQUssQ0FBQztDQUNyQyxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFJO0NBQ047QUFDRjtBQUVBLFNBQVMsUUFBUSxVQUFVLENBQUMsR0FBRztDQUM3QixNQUFNLEVBQ0osWUFBWSxRQUNaLGFBQWEsT0FDWDtDQUNKLE1BQU0sT0FBTyxhQUFhO0VBQ3hCLEdBQUc7RUFDSCxZQUFZLE9BQU8sbUJBQW1CO0dBQ3BDLElBQUk7R0FDSixJQUFJLFFBQVEsV0FDVixDQUFDLEtBQUssUUFBUSxjQUFjLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxTQUFTLFVBQVUsUUFBUSxnQkFBZ0IsS0FBSztRQUVwRyxlQUFlLEtBQUs7RUFDeEI7RUFDQSxPQUFPO0dBQ0wsTUFBTTtHQUNOLE9BQU87RUFDVDtDQUNGLENBQUM7Q0FDRCxNQUFNLFNBQVMsZUFBZSxLQUFLLE9BQU8sS0FBSztDQUMvQyxNQUFNLFNBQVMsU0FBUztFQUN0QixNQUFNO0dBQ0osT0FBTyxLQUFLLFVBQVU7RUFDeEI7RUFDQSxJQUFJLEdBQUc7R0FDTCxNQUFNLFVBQVUsSUFBSSxTQUFTO0dBQzdCLElBQUksT0FBTyxVQUFVLFNBQ25CLEtBQUssUUFBUTtRQUViLEtBQUssUUFBUTtFQUNqQjtDQUNGLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7QUFFQSxTQUFTLFNBQVMsR0FBRztDQUNuQixPQUFPO0FBQ1Q7QUFDQSxTQUFTLFlBQVksUUFBUSxPQUFPO0NBQ2xDLE9BQU8sT0FBTyxRQUFRO0FBQ3hCO0FBQ0EsU0FBUyxZQUFZLE9BQU87Q0FDMUIsT0FBTyxRQUFRLE9BQU8sVUFBVSxhQUFhLFFBQVEsY0FBYztBQUNyRTtBQUNBLFNBQVMsYUFBYSxPQUFPO0NBQzNCLE9BQU8sUUFBUSxPQUFPLFVBQVUsYUFBYSxRQUFRLGNBQWM7QUFDckU7QUFDQSxTQUFTLG9CQUFvQixRQUFRLFVBQVUsQ0FBQyxHQUFHO0NBQ2pELE1BQU0sRUFDSixRQUFRLE9BQ1IsT0FBTyxZQUFZLEtBQUssR0FDeEIsUUFBUSxhQUFhLEtBQUssR0FDMUIsWUFBWSxnQkFDVjtDQUNKLFNBQVMsdUJBQXVCO0VBQzlCLE9BQU8sUUFBUTtHQUNiLFVBQVUsS0FBSyxPQUFPLEtBQUs7R0FDM0IsV0FBVyxVQUFVO0VBQ3ZCLENBQUM7Q0FDSDtDQUNBLE1BQU0sT0FBTyxJQUFJLHFCQUFxQixDQUFDO0NBQ3ZDLE1BQU0sWUFBWSxJQUFJLENBQUMsQ0FBQztDQUN4QixNQUFNLFlBQVksSUFBSSxDQUFDLENBQUM7Q0FDeEIsTUFBTSxjQUFjLFdBQVc7RUFDN0IsVUFBVSxRQUFRLE1BQU0sT0FBTyxRQUFRLENBQUM7RUFDeEMsS0FBSyxRQUFRO0NBQ2Y7Q0FDQSxNQUFNLGVBQWU7RUFDbkIsVUFBVSxNQUFNLFFBQVEsS0FBSyxLQUFLO0VBQ2xDLEtBQUssUUFBUSxxQkFBcUI7RUFDbEMsSUFBSSxRQUFRLFlBQVksVUFBVSxNQUFNLFNBQVMsUUFBUSxVQUN2RCxVQUFVLE1BQU0sT0FBTyxRQUFRLFVBQVUsT0FBTyxpQkFBaUI7RUFDbkUsSUFBSSxVQUFVLE1BQU0sUUFDbEIsVUFBVSxNQUFNLE9BQU8sR0FBRyxVQUFVLE1BQU0sTUFBTTtDQUNwRDtDQUNBLE1BQU0sY0FBYztFQUNsQixVQUFVLE1BQU0sT0FBTyxHQUFHLFVBQVUsTUFBTSxNQUFNO0VBQ2hELFVBQVUsTUFBTSxPQUFPLEdBQUcsVUFBVSxNQUFNLE1BQU07Q0FDbEQ7Q0FDQSxNQUFNLGFBQWE7RUFDakIsTUFBTSxRQUFRLFVBQVUsTUFBTSxNQUFNO0VBQ3BDLElBQUksT0FBTztHQUNULFVBQVUsTUFBTSxRQUFRLEtBQUssS0FBSztHQUNsQyxXQUFXLEtBQUs7RUFDbEI7Q0FDRjtDQUNBLE1BQU0sYUFBYTtFQUNqQixNQUFNLFFBQVEsVUFBVSxNQUFNLE1BQU07RUFDcEMsSUFBSSxPQUFPO0dBQ1QsVUFBVSxNQUFNLFFBQVEsS0FBSyxLQUFLO0dBQ2xDLFdBQVcsS0FBSztFQUNsQjtDQUNGO0NBQ0EsTUFBTSxjQUFjO0VBQ2xCLFdBQVcsS0FBSyxLQUFLO0NBQ3ZCO0NBQ0EsTUFBTSxVQUFVLGVBQWUsQ0FBQyxLQUFLLE9BQU8sR0FBRyxVQUFVLEtBQUssQ0FBQztDQUMvRCxNQUFNLFVBQVUsZUFBZSxVQUFVLE1BQU0sU0FBUyxDQUFDO0NBQ3pELE1BQU0sVUFBVSxlQUFlLFVBQVUsTUFBTSxTQUFTLENBQUM7Q0FDekQsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7QUFFQSxTQUFTLGNBQWMsUUFBUSxVQUFVLENBQUMsR0FBRztDQUMzQyxNQUFNLEVBQ0osT0FBTyxPQUNQLFFBQVEsT0FDUixhQUNBLHFCQUFxQixTQUNuQjtDQUNKLE1BQU0sRUFDSixhQUFhLGdCQUNiLE9BQ0EsUUFBUSxnQkFDUixVQUFVLGVBQ1IsZUFBZSxXQUFXO0NBQzlCLElBQUksZUFBZSxPQUFPO0NBQzFCLE1BQU0sRUFDSixlQUNBLHdCQUNBLFNBQ0UsZUFDRixRQUNBLFFBQ0E7RUFBRTtFQUFNO0VBQU8sYUFBYTtDQUFlLENBQzdDO0NBQ0EsU0FBUyxVQUFVLFNBQVMsT0FBTztFQUNqQyx1QkFBdUI7RUFDdkIsb0JBQW9CO0dBQ2xCLFFBQVEsUUFBUTtHQUNoQixlQUFlO0VBQ2pCLENBQUM7Q0FDSDtDQUNBLE1BQU0sZ0JBQWdCLG9CQUFvQixRQUFRO0VBQUUsR0FBRztFQUFTLE9BQU8sUUFBUSxTQUFTO0VBQU07Q0FBVSxDQUFDO0NBQ3pHLE1BQU0sRUFBRSxPQUFPLFFBQVEsaUJBQWlCO0NBQ3hDLFNBQVMsU0FBUztFQUNoQix1QkFBdUI7RUFDdkIsSUFBSSxDQUFDLGFBQWEsY0FBYyxPQUFPLEtBQUssR0FDMUM7RUFDRixlQUFlLE9BQU87RUFDdEIsYUFBYTtDQUNmO0NBQ0EsU0FBUyxPQUFPLFdBQVc7RUFDekIsZUFBZTtFQUNmLElBQUksV0FDRixPQUFPO0NBQ1g7Q0FDQSxTQUFTLE1BQU0sSUFBSTtFQUNqQixJQUFJLFdBQVc7RUFDZixNQUFNLGVBQWUsV0FBVztFQUNoQyxvQkFBb0I7R0FDbEIsR0FBRyxNQUFNO0VBQ1gsQ0FBQztFQUNELElBQUksQ0FBQyxVQUNILE9BQU87Q0FDWDtDQUNBLFNBQVMsVUFBVTtFQUNqQixLQUFLO0VBQ0wsTUFBTTtDQUNSO0NBQ0EsT0FBTztFQUNMLEdBQUc7RUFDSDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsU0FBUyx1QkFBdUIsUUFBUSxVQUFVLENBQUMsR0FBRztDQUNwRCxNQUFNLFNBQVMsUUFBUSxXQUFXLGVBQWUsUUFBUSxRQUFRLElBQUksS0FBSztDQUMxRSxNQUFNLFVBQVUsY0FBYyxRQUFRO0VBQUUsR0FBRztFQUFTLGFBQWE7Q0FBTyxDQUFDO0NBQ3pFLE9BQU8sRUFDTCxHQUFHLFFBQ0w7QUFDRjtBQUVBLFNBQVMsZ0JBQWdCLFVBQVUsQ0FBQyxHQUFHO0NBQ3JDLE1BQU0sRUFDSixTQUFTLGVBQ1QscUJBQXFCLE9BQ3JCLGNBQWMsaUJBQ1o7Q0FDSixNQUFNLGNBQWMsbUJBQW1CLE9BQU8sc0JBQXNCLFdBQVc7Q0FDL0UsTUFBTSxxQkFBcUIsbUJBQW1CLFlBQVksU0FBUyx1QkFBdUIscUJBQXFCLE9BQU8sa0JBQWtCLHNCQUFzQixVQUFVO0NBQ3hLLE1BQU0sb0JBQW9CLFdBQVcsS0FBSztDQUMxQyxNQUFNLGVBQWUsSUFBSTtFQUFFLEdBQUc7RUFBTSxHQUFHO0VBQU0sR0FBRztDQUFLLENBQUM7Q0FDdEQsTUFBTSxlQUFlLElBQUk7RUFBRSxPQUFPO0VBQU0sTUFBTTtFQUFNLE9BQU87Q0FBSyxDQUFDO0NBQ2pFLE1BQU0sV0FBVyxXQUFXLENBQUM7Q0FDN0IsTUFBTSwrQkFBK0IsSUFBSTtFQUN2QyxHQUFHO0VBQ0gsR0FBRztFQUNILEdBQUc7Q0FDTCxDQUFDO0NBQ0QsU0FBUyxPQUFPO0VBQ2QsSUFBSSxRQUFRO0dBQ1YsTUFBTSxpQkFBaUIsb0JBQ3JCLGNBQ0MsVUFBVTtJQUNULElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJO0lBQ3BDLGFBQWEsUUFBUTtLQUNuQixLQUFLLEtBQUssTUFBTSxpQkFBaUIsT0FBTyxLQUFLLElBQUksR0FBRyxNQUFNO0tBQzFELEtBQUssS0FBSyxNQUFNLGlCQUFpQixPQUFPLEtBQUssSUFBSSxHQUFHLE1BQU07S0FDMUQsS0FBSyxLQUFLLE1BQU0saUJBQWlCLE9BQU8sS0FBSyxJQUFJLEdBQUcsTUFBTTtJQUM1RDtJQUNBLDZCQUE2QixRQUFRO0tBQ25DLEtBQUssS0FBSyxNQUFNLGlDQUFpQyxPQUFPLEtBQUssSUFBSSxHQUFHLE1BQU07S0FDMUUsS0FBSyxLQUFLLE1BQU0saUNBQWlDLE9BQU8sS0FBSyxJQUFJLEdBQUcsTUFBTTtLQUMxRSxLQUFLLEtBQUssTUFBTSxpQ0FBaUMsT0FBTyxLQUFLLElBQUksR0FBRyxNQUFNO0lBQzVFO0lBQ0EsYUFBYSxRQUFRO0tBQ25CLFNBQVMsS0FBSyxNQUFNLGlCQUFpQixPQUFPLEtBQUssSUFBSSxHQUFHLFVBQVU7S0FDbEUsUUFBUSxLQUFLLE1BQU0saUJBQWlCLE9BQU8sS0FBSyxJQUFJLEdBQUcsU0FBUztLQUNoRSxTQUFTLEtBQUssTUFBTSxpQkFBaUIsT0FBTyxLQUFLLElBQUksR0FBRyxVQUFVO0lBQ3BFO0lBQ0EsU0FBUyxRQUFRLE1BQU07R0FDekIsQ0FDRjtHQUNBLGlCQUFpQixRQUFRLGdCQUFnQixnQkFBZ0IsRUFBRSxTQUFTLEtBQUssQ0FBQztFQUM1RTtDQUNGO0NBQ0EsTUFBTSxvQkFBb0IsWUFBWTtFQUNwQyxJQUFJLENBQUMsbUJBQW1CLE9BQ3RCLGtCQUFrQixRQUFRO0VBQzVCLElBQUksa0JBQWtCLE9BQ3BCO0VBQ0YsSUFBSSxtQkFBbUIsT0FBTztHQUM1QixNQUFNLG9CQUFvQixrQkFBa0I7R0FDNUMsSUFBSTtJQUNGLE1BQU0sV0FBVyxNQUFNLGtCQUFrQjtJQUN6QyxJQUFJLGFBQWEsV0FBVztLQUMxQixrQkFBa0IsUUFBUTtLQUMxQixLQUFLO0lBQ1A7R0FDRixTQUFTLE9BQU87SUFDZCxRQUFRLE1BQU0sS0FBSztHQUNyQjtFQUNGO0NBQ0Y7Q0FDQSxJQUFJLFlBQVksT0FBTztFQUNyQixJQUFJLHNCQUFzQixtQkFBbUIsT0FBTztHQUNsRCxrQkFBa0IsQ0FBQyxDQUFDLFdBQVcsS0FBSyxDQUFDO0VBQ3ZDLE9BQU87R0FDTCxLQUFLO0VBQ1A7Q0FDRjtDQUNBLE9BQU87RUFDTDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7QUFDRjs7QUFHQSxTQUFTLHFCQUFxQixVQUFVLENBQUMsR0FBRztDQUMxQyxNQUFNLEVBQUUsU0FBUyxrQkFBa0I7Q0FDbkMsTUFBTSxjQUFjLG1CQUFtQixVQUFVLDRCQUE0QixNQUFNO0NBQ25GLE1BQU0sYUFBYSxXQUFXLEtBQUs7Q0FDbkMsTUFBTSxRQUFRLFdBQVcsSUFBSTtDQUM3QixNQUFNLE9BQU8sV0FBVyxJQUFJO0NBQzVCLE1BQU0sUUFBUSxXQUFXLElBQUk7Q0FDN0IsSUFBSSxVQUFVLFlBQVksT0FBTztFQUMvQixpQkFBaUIsUUFBUSxzQkFBc0IsVUFBVTtHQUN2RCxXQUFXLFFBQVEsTUFBTTtHQUN6QixNQUFNLFFBQVEsTUFBTTtHQUNwQixLQUFLLFFBQVEsTUFBTTtHQUNuQixNQUFNLFFBQVEsTUFBTTtFQUN0QixHQUFHLEVBQUUsU0FBUyxLQUFLLENBQUM7Q0FDdEI7Q0FDQSxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7O0FBR0EsU0FBUyxvQkFBb0IsVUFBVSxDQUFDLEdBQUc7Q0FDekMsTUFBTSxFQUNKLFNBQVMsa0JBQ1A7Q0FDSixNQUFNLGFBQWEsV0FBVyxDQUFDO0NBQy9CLE1BQU0sUUFBUSxvQkFBb0IsZ0JBQWdCLFdBQVcsTUFBTSxRQUFRLE9BQU87Q0FDbEYsSUFBSSxPQUFPO0NBQ1gsSUFBSSxRQUFRO0VBQ1YsT0FBTyxlQUFlLGFBQWEsV0FBVyxRQUFRLE9BQU8sZ0JBQWdCO0NBQy9FO0NBQ0EsT0FBTztFQUNMLFlBQVksU0FBUyxVQUFVO0VBQy9CO0NBQ0Y7QUFDRjtBQUVBLFNBQVMsZUFBZSxVQUFVLENBQUMsR0FBRztDQUNwQyxNQUFNLEVBQ0osWUFBWSxrQkFDWixxQkFBcUIsT0FDckIsY0FBYztFQUFFLE9BQU87RUFBTSxPQUFPO0NBQUssR0FDekMsY0FDRTtDQUNKLE1BQU0sVUFBVSxJQUFJLENBQUMsQ0FBQztDQUN0QixNQUFNLGNBQWMsZUFBZSxRQUFRLE1BQU0sUUFBUSxNQUFNLEVBQUUsU0FBUyxZQUFZLENBQUM7Q0FDdkYsTUFBTSxjQUFjLGVBQWUsUUFBUSxNQUFNLFFBQVEsTUFBTSxFQUFFLFNBQVMsWUFBWSxDQUFDO0NBQ3ZGLE1BQU0sZUFBZSxlQUFlLFFBQVEsTUFBTSxRQUFRLE1BQU0sRUFBRSxTQUFTLGFBQWEsQ0FBQztDQUN6RixNQUFNLGNBQWMsbUJBQW1CLGFBQWEsVUFBVSxnQkFBZ0IsVUFBVSxhQUFhLGdCQUFnQjtDQUNySCxNQUFNLG9CQUFvQixXQUFXLEtBQUs7Q0FDMUMsSUFBSTtDQUNKLGVBQWUsU0FBUztFQUN0QixJQUFJLENBQUMsWUFBWSxPQUNmO0VBQ0YsUUFBUSxRQUFRLE1BQU0sVUFBVSxhQUFhLGlCQUFpQjtFQUM5RCxhQUFhLE9BQU8sS0FBSyxJQUFJLFVBQVUsUUFBUSxLQUFLO0VBQ3BELElBQUksUUFBUTtHQUNWLE9BQU8sVUFBVSxDQUFDLENBQUMsU0FBUyxNQUFNLEVBQUUsS0FBSyxDQUFDO0dBQzFDLFNBQVM7RUFDWDtDQUNGO0NBQ0EsZUFBZSxvQkFBb0I7RUFDakMsTUFBTSxhQUFhLFlBQVksUUFBUSxXQUFXO0VBQ2xELElBQUksQ0FBQyxZQUFZLE9BQ2YsT0FBTztFQUNULElBQUksa0JBQWtCLE9BQ3BCLE9BQU87RUFDVCxNQUFNLEVBQUUsT0FBTyxVQUFVLGNBQWMsWUFBWSxFQUFFLFVBQVUsS0FBSyxDQUFDO0VBQ3JFLE1BQU0sTUFBTTtFQUNaLElBQUksTUFBTSxVQUFVLFdBQVc7R0FDN0IsSUFBSSxVQUFVO0dBQ2QsSUFBSTtJQUNGLE1BQU0sYUFBYSxNQUFNLFVBQVUsYUFBYSxpQkFBaUI7SUFDakUsTUFBTSxZQUFZLFdBQVcsTUFBTSxXQUFXLE9BQU8sU0FBUyxZQUFZO0lBQzFFLE1BQU0sZ0JBQWdCLFdBQVcsTUFBTSxXQUFXLE9BQU8sU0FBUyxnQkFBZ0IsT0FBTyxTQUFTLGFBQWE7SUFDL0csWUFBWSxRQUFRLFlBQVksWUFBWSxRQUFRO0lBQ3BELFlBQVksUUFBUSxnQkFBZ0IsWUFBWSxRQUFRO0lBQ3hELFNBQVMsTUFBTSxVQUFVLGFBQWEsYUFBYSxXQUFXO0dBQ2hFLFNBQVMsR0FBRztJQUNWLFNBQVM7SUFDVCxVQUFVO0dBQ1o7R0FDQSxPQUFPO0dBQ1Asa0JBQWtCLFFBQVE7RUFDNUIsT0FBTztHQUNMLGtCQUFrQixRQUFRO0VBQzVCO0VBQ0EsT0FBTyxrQkFBa0I7Q0FDM0I7Q0FDQSxJQUFJLFlBQVksT0FBTztFQUNyQixJQUFJLG9CQUNGLGtCQUFrQjtFQUNwQixpQkFBaUIsVUFBVSxjQUFjLGdCQUFnQixRQUFRLEVBQUUsU0FBUyxLQUFLLENBQUM7RUFDbEYsT0FBTztDQUNUO0NBQ0EsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7QUFDRjtBQUVBLFNBQVMsZ0JBQWdCLFVBQVUsQ0FBQyxHQUFHO0NBQ3JDLElBQUk7Q0FDSixNQUFNLFVBQVUsWUFBWSxLQUFLLFFBQVEsWUFBWSxPQUFPLEtBQUssS0FBSztDQUN0RSxNQUFNLFFBQVEsUUFBUTtDQUN0QixNQUFNLFFBQVEsUUFBUTtDQUN0QixNQUFNLEVBQUUsWUFBWSxxQkFBcUI7Q0FDekMsTUFBTSxjQUFjLG1CQUFtQjtFQUNyQyxJQUFJO0VBQ0osUUFBUSxNQUFNLGFBQWEsT0FBTyxLQUFLLElBQUksVUFBVSxpQkFBaUIsT0FBTyxLQUFLLElBQUksSUFBSTtDQUM1RixDQUFDO0NBQ0QsTUFBTSxhQUFhO0VBQUU7RUFBTztDQUFNO0NBQ2xDLE1BQU0sU0FBUyxXQUFXO0NBQzFCLGVBQWUsU0FBUztFQUN0QixJQUFJO0VBQ0osSUFBSSxDQUFDLFlBQVksU0FBUyxPQUFPLE9BQy9CO0VBQ0YsT0FBTyxRQUFRLE1BQU0sVUFBVSxhQUFhLGdCQUFnQixVQUFVO0VBQ3RFLENBQUMsTUFBTSxPQUFPLFVBQVUsT0FBTyxLQUFLLElBQUksSUFBSSxVQUFVLENBQUMsQ0FBQyxTQUFTLE1BQU0saUJBQWlCLEdBQUcsU0FBUyxNQUFNLEVBQUUsU0FBUyxLQUFLLENBQUMsQ0FBQztFQUM1SCxPQUFPLE9BQU87Q0FDaEI7Q0FDQSxlQUFlLFFBQVE7RUFDckIsSUFBSTtFQUNKLENBQUMsTUFBTSxPQUFPLFVBQVUsT0FBTyxLQUFLLElBQUksSUFBSSxVQUFVLENBQUMsQ0FBQyxTQUFTLE1BQU0sRUFBRSxLQUFLLENBQUM7RUFDL0UsT0FBTyxRQUFRLEtBQUs7Q0FDdEI7Q0FDQSxTQUFTLE9BQU87RUFDZCxNQUFNO0VBQ04sUUFBUSxRQUFRO0NBQ2xCO0NBQ0EsZUFBZSxRQUFRO0VBQ3JCLE1BQU0sT0FBTztFQUNiLElBQUksT0FBTyxPQUNULFFBQVEsUUFBUTtFQUNsQixPQUFPLE9BQU87Q0FDaEI7Q0FDQSxNQUNFLFVBQ0MsTUFBTTtFQUNMLElBQUksR0FDRixPQUFPO09BRVAsTUFBTTtDQUNWLEdBQ0EsRUFBRSxXQUFXLEtBQUssQ0FDcEI7Q0FDQSxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7O0FBR0EsU0FBUyxzQkFBc0IsVUFBVSxDQUFDLEdBQUc7Q0FDM0MsTUFBTSxFQUFFLFdBQVcsb0JBQW9CO0NBQ3ZDLElBQUksQ0FBQyxVQUNILE9BQU8sV0FBVyxTQUFTO0NBQzdCLE1BQU0sYUFBYSxXQUFXLFNBQVMsZUFBZTtDQUN0RCxpQkFBaUIsVUFBVSwwQkFBMEI7RUFDbkQsV0FBVyxRQUFRLFNBQVM7Q0FDOUIsR0FBRyxFQUFFLFNBQVMsS0FBSyxDQUFDO0NBQ3BCLE9BQU87QUFDVDtBQUVBLFNBQVMsYUFBYSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0NBQzFDLElBQUk7Q0FDSixNQUFNLEVBQ0osY0FDQSxnQkFDQSxpQkFDQSxPQUNBLFFBQ0EsT0FDQSxTQUNBLGNBQ0EsT0FBTyxRQUNQLGtCQUFrQixlQUNsQixrQkFDQSxRQUFRLGlCQUFpQixRQUN6QixVQUFVLENBQUMsQ0FBQyxNQUNWO0NBQ0osTUFBTSxXQUFXLEtBQ2QsS0FBSyxRQUFRLFlBQVksTUFBTSxPQUFPLEtBQUs7RUFBRSxHQUFHO0VBQUcsR0FBRztDQUFFLENBQzNEO0NBQ0EsTUFBTSxlQUFlLElBQUk7Q0FDekIsTUFBTSxlQUFlLE1BQU07RUFDekIsSUFBSSxjQUNGLE9BQU8sYUFBYSxTQUFTLEVBQUUsV0FBVztFQUM1QyxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLGVBQWUsTUFBTTtFQUN6QixJQUFJLFFBQVEsY0FBYyxHQUN4QixFQUFFLGVBQWU7RUFDbkIsSUFBSSxRQUFRLGVBQWUsR0FDekIsRUFBRSxnQkFBZ0I7Q0FDdEI7Q0FDQSxNQUFNLFNBQVMsTUFBTTtFQUNuQixJQUFJO0VBQ0osSUFBSSxDQUFDLFFBQVEsT0FBTyxDQUFDLENBQUMsU0FBUyxFQUFFLE1BQU0sR0FDckM7RUFDRixJQUFJLFFBQVEsUUFBUSxRQUFRLEtBQUssQ0FBQyxZQUFZLENBQUMsR0FDN0M7RUFDRixJQUFJLFFBQVEsS0FBSyxLQUFLLEVBQUUsV0FBVyxRQUFRLE1BQU0sR0FDL0M7RUFDRixNQUFNLFlBQVksUUFBUSxnQkFBZ0I7RUFDMUMsTUFBTSxpQkFBaUIsTUFBTSxhQUFhLE9BQU8sS0FBSyxJQUFJLFVBQVUsMEJBQTBCLE9BQU8sS0FBSyxJQUFJLElBQUksS0FBSyxTQUFTO0VBQ2hJLE1BQU0sYUFBYSxRQUFRLE1BQU0sQ0FBQyxDQUFDLHNCQUFzQjtFQUN6RCxNQUFNLE1BQU07R0FDVixHQUFHLEVBQUUsV0FBVyxZQUFZLFdBQVcsT0FBTyxjQUFjLE9BQU8sVUFBVSxhQUFhLFdBQVc7R0FDckcsR0FBRyxFQUFFLFdBQVcsWUFBWSxXQUFXLE1BQU0sY0FBYyxNQUFNLFVBQVUsWUFBWSxXQUFXO0VBQ3BHO0VBQ0EsS0FBSyxXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsS0FBSyxDQUFDLE9BQU8sT0FDbkQ7RUFDRixhQUFhLFFBQVE7RUFDckIsWUFBWSxDQUFDO0NBQ2Y7Q0FDQSxNQUFNLFFBQVEsTUFBTTtFQUNsQixJQUFJLFFBQVEsUUFBUSxRQUFRLEtBQUssQ0FBQyxZQUFZLENBQUMsR0FDN0M7RUFDRixJQUFJLENBQUMsYUFBYSxPQUNoQjtFQUNGLE1BQU0sWUFBWSxRQUFRLGdCQUFnQjtFQUMxQyxNQUFNLGFBQWEsUUFBUSxNQUFNLENBQUMsQ0FBQyxzQkFBc0I7RUFDekQsSUFBSSxFQUFFLEdBQUcsTUFBTSxTQUFTO0VBQ3hCLElBQUksU0FBUyxPQUFPLFNBQVMsUUFBUTtHQUNuQyxJQUFJLEVBQUUsVUFBVSxhQUFhLE1BQU07R0FDbkMsSUFBSSxXQUNGLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHLENBQUMsR0FBRyxVQUFVLGNBQWMsV0FBVyxLQUFLO0VBQ3pFO0VBQ0EsSUFBSSxTQUFTLE9BQU8sU0FBUyxRQUFRO0dBQ25DLElBQUksRUFBRSxVQUFVLGFBQWEsTUFBTTtHQUNuQyxJQUFJLFdBQ0YsSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsQ0FBQyxHQUFHLFVBQVUsZUFBZSxXQUFXLE1BQU07RUFDM0U7RUFDQSxTQUFTLFFBQVE7R0FDZjtHQUNBO0VBQ0Y7RUFDQSxVQUFVLE9BQU8sS0FBSyxJQUFJLE9BQU8sU0FBUyxPQUFPLENBQUM7RUFDbEQsWUFBWSxDQUFDO0NBQ2Y7Q0FDQSxNQUFNLE9BQU8sTUFBTTtFQUNqQixJQUFJLFFBQVEsUUFBUSxRQUFRLEtBQUssQ0FBQyxZQUFZLENBQUMsR0FDN0M7RUFDRixJQUFJLENBQUMsYUFBYSxPQUNoQjtFQUNGLGFBQWEsUUFBUSxLQUFLO0VBQzFCLFNBQVMsT0FBTyxLQUFLLElBQUksTUFBTSxTQUFTLE9BQU8sQ0FBQztFQUNoRCxZQUFZLENBQUM7Q0FDZjtDQUNBLElBQUksVUFBVTtFQUNaLE1BQU0sZUFBZTtHQUNuQixJQUFJO0dBQ0osT0FBTztJQUNMLFVBQVUsTUFBTSxRQUFRLFlBQVksT0FBTyxNQUFNO0lBQ2pELFNBQVMsQ0FBQyxRQUFRLGNBQWM7R0FDbEM7RUFDRjtFQUNBLGlCQUFpQixnQkFBZ0IsZUFBZSxPQUFPLE1BQU07RUFDN0QsaUJBQWlCLGlCQUFpQixlQUFlLE1BQU0sTUFBTTtFQUM3RCxpQkFBaUIsaUJBQWlCLGFBQWEsS0FBSyxNQUFNO0NBQzVEO0NBQ0EsT0FBTztFQUNMLEdBQUcsT0FBTyxRQUFRO0VBQ2xCO0VBQ0EsWUFBWSxlQUFlLENBQUMsQ0FBQyxhQUFhLEtBQUs7RUFDL0MsT0FBTyxlQUNDLFFBQVEsU0FBUyxNQUFNLEVBQUUsU0FBUyxTQUFTLE1BQU0sRUFBRSxJQUMzRDtDQUNGO0FBQ0Y7QUFFQSxTQUFTLFlBQVksUUFBUSxVQUFVLENBQUMsR0FBRztDQUN6QyxJQUFJLElBQUk7Q0FDUixNQUFNLGlCQUFpQixXQUFXLEtBQUs7Q0FDdkMsTUFBTSxRQUFRLFdBQVcsSUFBSTtDQUM3QixJQUFJLFVBQVU7Q0FDZCxJQUFJLFVBQVU7Q0FDZCxJQUFJLFVBQVU7RUFDWixNQUFNLFdBQVcsT0FBTyxZQUFZLGFBQWEsRUFBRSxRQUFRLFFBQVEsSUFBSTtFQUN2RSxNQUFNLFlBQVksS0FBSyxTQUFTLGFBQWEsT0FBTyxLQUFLO0VBQ3pELE1BQU0sOEJBQThCLEtBQUssU0FBUywrQkFBK0IsT0FBTyxLQUFLO0VBQzdGLE1BQU0sWUFBWSxVQUFVO0dBQzFCLElBQUksS0FBSztHQUNULE1BQU0sT0FBTyxNQUFNLE1BQU0sT0FBTyxNQUFNLE1BQU0saUJBQWlCLE9BQU8sS0FBSyxJQUFJLElBQUksVUFBVSxPQUFPLE1BQU0sQ0FBQyxDQUFDO0dBQzFHLE9BQU8sS0FBSyxXQUFXLElBQUksT0FBTyxXQUFXLE9BQU8sQ0FBQyxLQUFLLEVBQUU7RUFDOUQ7RUFDQSxNQUFNLGtCQUFrQixVQUFVO0dBQ2hDLE1BQU0sWUFBWSxNQUFNLFNBQVMsU0FBUztHQUMxQyxJQUFJLE9BQU8sY0FBYyxZQUN2QixPQUFPLFVBQVUsS0FBSztHQUN4QixJQUFJLEVBQUUsYUFBYSxPQUFPLEtBQUssSUFBSSxVQUFVLFNBQzNDLE9BQU87R0FDVCxJQUFJLE1BQU0sV0FBVyxHQUNuQixPQUFPO0dBQ1QsT0FBTyxNQUFNLE9BQ1YsU0FBUyxVQUFVLE1BQU0sZ0JBQWdCLEtBQUssU0FBUyxXQUFXLENBQUMsQ0FDdEU7RUFDRjtFQUNBLE1BQU0saUJBQWlCLFVBQVU7R0FDL0IsTUFBTSxRQUFRLE1BQU0sS0FBSyxTQUFTLE9BQU8sUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxLQUFLLElBQUk7R0FDNUUsTUFBTSxpQkFBaUIsZUFBZSxLQUFLO0dBQzNDLE1BQU0scUJBQXFCLFlBQVksTUFBTSxVQUFVO0dBQ3ZELE9BQU8sa0JBQWtCO0VBQzNCO0VBQ0EsTUFBTSxpQkFBaUIsbUNBQW1DLEtBQUssVUFBVSxTQUFTLEtBQUssRUFBRSxZQUFZO0VBQ3JHLE1BQU0sbUJBQW1CLE9BQU8sY0FBYztHQUM1QyxJQUFJLEtBQUssS0FBSyxJQUFJLElBQUksSUFBSTtHQUMxQixNQUFNLHdCQUF3QixNQUFNLE1BQU0saUJBQWlCLE9BQU8sS0FBSyxJQUFJLElBQUk7R0FDL0UsV0FBVyxNQUFNLHdCQUF3QixjQUFjLG9CQUFvQixNQUFNLE9BQU8sTUFBTTtHQUM5RixJQUFJLDRCQUE0QjtJQUM5QixNQUFNLGVBQWU7R0FDdkI7R0FDQSxJQUFJLENBQUMsU0FBUyxLQUFLLENBQUMsU0FBUztJQUMzQixJQUFJLE1BQU0sY0FBYztLQUN0QixNQUFNLGFBQWEsYUFBYTtJQUNsQztJQUNBO0dBQ0Y7R0FDQSxNQUFNLGVBQWU7R0FDckIsSUFBSSxNQUFNLGNBQWM7SUFDdEIsTUFBTSxhQUFhLGFBQWE7R0FDbEM7R0FDQSxNQUFNLGVBQWUsU0FBUyxLQUFLO0dBQ25DLFFBQVEsV0FBUjtJQUNFLEtBQUs7S0FDSCxXQUFXO0tBQ1gsZUFBZSxRQUFRO0tBQ3ZCLENBQUMsS0FBSyxTQUFTLFlBQVksT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLFVBQVUsTUFBTSxLQUFLO0tBQ3hFO0lBQ0YsS0FBSztLQUNILENBQUMsS0FBSyxTQUFTLFdBQVcsT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLFVBQVUsTUFBTSxLQUFLO0tBQ3ZFO0lBQ0YsS0FBSztLQUNILFdBQVc7S0FDWCxJQUFJLFlBQVksR0FDZCxlQUFlLFFBQVE7S0FDekIsQ0FBQyxLQUFLLFNBQVMsWUFBWSxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssVUFBVSxNQUFNLEtBQUs7S0FDeEU7SUFDRixLQUFLO0tBQ0gsVUFBVTtLQUNWLGVBQWUsUUFBUTtLQUN2QixJQUFJLFNBQVM7TUFDWCxNQUFNLFFBQVE7TUFDZCxDQUFDLEtBQUssU0FBUyxXQUFXLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxVQUFVLGNBQWMsS0FBSztLQUNqRjtLQUNBO0dBQ0o7RUFDRjtFQUNBLGlCQUFpQixRQUFRLGNBQWMsVUFBVSxnQkFBZ0IsT0FBTyxPQUFPLENBQUM7RUFDaEYsaUJBQWlCLFFBQVEsYUFBYSxVQUFVLGdCQUFnQixPQUFPLE1BQU0sQ0FBQztFQUM5RSxpQkFBaUIsUUFBUSxjQUFjLFVBQVUsZ0JBQWdCLE9BQU8sT0FBTyxDQUFDO0VBQ2hGLGlCQUFpQixRQUFRLFNBQVMsVUFBVSxnQkFBZ0IsT0FBTyxNQUFNLENBQUM7Q0FDNUU7Q0FDQSxPQUFPO0VBQ0w7RUFDQTtDQUNGO0FBQ0Y7QUFFQSxTQUFTLGtCQUFrQixRQUFRLFVBQVUsVUFBVSxDQUFDLEdBQUc7Q0FDekQsTUFBTSxFQUFFLFNBQVMsZUFBZSxHQUFHLG9CQUFvQjtDQUN2RCxJQUFJO0NBQ0osTUFBTSxjQUFjLG1CQUFtQixVQUFVLG9CQUFvQixNQUFNO0NBQzNFLE1BQU0sZ0JBQWdCO0VBQ3BCLElBQUksVUFBVTtHQUNaLFNBQVMsV0FBVztHQUNwQixXQUFXLEtBQUs7RUFDbEI7Q0FDRjtDQUNBLE1BQU0sVUFBVSxlQUFlO0VBQzdCLE1BQU0sV0FBVyxRQUFRLE1BQU07RUFDL0IsT0FBTyxNQUFNLFFBQVEsUUFBUSxJQUFJLFNBQVMsS0FBSyxPQUFPLGFBQWEsRUFBRSxDQUFDLElBQUksQ0FBQyxhQUFhLFFBQVEsQ0FBQztDQUNuRyxDQUFDO0NBQ0QsTUFBTSxZQUFZLE1BQ2hCLFVBQ0MsUUFBUTtFQUNQLFFBQVE7RUFDUixJQUFJLFlBQVksU0FBUyxRQUFRO0dBQy9CLFdBQVcsSUFBSSxlQUFlLFFBQVE7R0FDdEMsS0FBSyxNQUFNLE9BQU8sS0FBSztJQUNyQixJQUFJLEtBQ0YsU0FBUyxRQUFRLEtBQUssZUFBZTtHQUN6QztFQUNGO0NBQ0YsR0FDQTtFQUFFLFdBQVc7RUFBTSxPQUFPO0NBQU8sQ0FDbkM7Q0FDQSxNQUFNLGFBQWE7RUFDakIsUUFBUTtFQUNSLFVBQVU7Q0FDWjtDQUNBLGtCQUFrQixJQUFJO0NBQ3RCLE9BQU87RUFDTDtFQUNBO0NBQ0Y7QUFDRjtBQUVBLFNBQVMsbUJBQW1CLFFBQVEsVUFBVSxDQUFDLEdBQUc7Q0FDaEQsTUFBTSxFQUNKLFFBQVEsTUFDUixlQUFlLE1BQ2YsZUFBZSxNQUNmLFlBQVksTUFDWixlQUFlLFdBQ2I7Q0FDSixNQUFNLFNBQVMsV0FBVyxDQUFDO0NBQzNCLE1BQU0sU0FBUyxXQUFXLENBQUM7Q0FDM0IsTUFBTSxPQUFPLFdBQVcsQ0FBQztDQUN6QixNQUFNLFFBQVEsV0FBVyxDQUFDO0NBQzFCLE1BQU0sTUFBTSxXQUFXLENBQUM7Q0FDeEIsTUFBTSxRQUFRLFdBQVcsQ0FBQztDQUMxQixNQUFNLElBQUksV0FBVyxDQUFDO0NBQ3RCLE1BQU0sSUFBSSxXQUFXLENBQUM7Q0FDdEIsU0FBUyxjQUFjO0VBQ3JCLE1BQU0sS0FBSyxhQUFhLE1BQU07RUFDOUIsSUFBSSxDQUFDLElBQUk7R0FDUCxJQUFJLE9BQU87SUFDVCxPQUFPLFFBQVE7SUFDZixPQUFPLFFBQVE7SUFDZixLQUFLLFFBQVE7SUFDYixNQUFNLFFBQVE7SUFDZCxJQUFJLFFBQVE7SUFDWixNQUFNLFFBQVE7SUFDZCxFQUFFLFFBQVE7SUFDVixFQUFFLFFBQVE7R0FDWjtHQUNBO0VBQ0Y7RUFDQSxNQUFNLE9BQU8sR0FBRyxzQkFBc0I7RUFDdEMsT0FBTyxRQUFRLEtBQUs7RUFDcEIsT0FBTyxRQUFRLEtBQUs7RUFDcEIsS0FBSyxRQUFRLEtBQUs7RUFDbEIsTUFBTSxRQUFRLEtBQUs7RUFDbkIsSUFBSSxRQUFRLEtBQUs7RUFDakIsTUFBTSxRQUFRLEtBQUs7RUFDbkIsRUFBRSxRQUFRLEtBQUs7RUFDZixFQUFFLFFBQVEsS0FBSztDQUNqQjtDQUNBLFNBQVMsU0FBUztFQUNoQixJQUFJLGlCQUFpQixRQUNuQixZQUFZO09BQ1QsSUFBSSxpQkFBaUIsY0FDeEIsNEJBQTRCLFlBQVksQ0FBQztDQUM3QztDQUNBLGtCQUFrQixRQUFRLE1BQU07Q0FDaEMsWUFBWSxhQUFhLE1BQU0sSUFBSSxRQUFRLENBQUMsT0FBTyxPQUFPLENBQUM7Q0FDM0Qsb0JBQW9CLFFBQVEsUUFBUSxFQUNsQyxpQkFBaUIsQ0FBQyxTQUFTLE9BQU8sRUFDcEMsQ0FBQztDQUNELElBQUksY0FDRixpQkFBaUIsVUFBVSxRQUFRO0VBQUUsU0FBUztFQUFNLFNBQVM7Q0FBSyxDQUFDO0NBQ3JFLElBQUksY0FDRixpQkFBaUIsVUFBVSxRQUFRLEVBQUUsU0FBUyxLQUFLLENBQUM7Q0FDdEQsbUJBQW1CO0VBQ2pCLElBQUksV0FDRixPQUFPO0NBQ1gsQ0FBQztDQUNELE9BQU87RUFDTDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsU0FBUyxrQkFBa0IsU0FBUztDQUNsQyxNQUFNLEVBQ0osR0FDQSxHQUNBLFdBQVcsaUJBQ1gsVUFDQSxXQUFXLHlCQUNYLFlBQVksU0FDVjtDQUNKLE1BQU0sY0FBYyxtQkFBbUI7RUFDckMsSUFBSSxRQUFRLFFBQVEsR0FDbEIsT0FBTyxZQUFZLHVCQUF1QjtFQUM1QyxPQUFPLFlBQVksc0JBQXNCO0NBQzNDLENBQUM7Q0FDRCxNQUFNLFVBQVUsV0FBVyxJQUFJO0NBQy9CLE1BQU0sV0FBVztFQUNmLElBQUksSUFBSTtFQUNSLFFBQVEsUUFBUSxRQUFRLFFBQVEsS0FBSyxLQUFLLFlBQVksT0FBTyxLQUFLLElBQUksU0FBUyxrQkFBa0IsUUFBUSxDQUFDLEdBQUcsUUFBUSxDQUFDLENBQUMsTUFBTSxPQUFPLEtBQUssQ0FBQyxLQUFLLEtBQUssWUFBWSxPQUFPLEtBQUssSUFBSSxTQUFTLGlCQUFpQixRQUFRLENBQUMsR0FBRyxRQUFRLENBQUMsQ0FBQyxNQUFNLE9BQU8sS0FBSztDQUNwUDtDQUNBLE1BQU0sV0FBVyxhQUFhLDBCQUEwQixTQUFTLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSSxjQUFjLElBQUksVUFBVSxFQUFFLFVBQVUsQ0FBQztDQUMvSCxPQUFPO0VBQ0w7RUFDQTtFQUNBLEdBQUc7Q0FDTDtBQUNGO0FBRUEsU0FBUyxnQkFBZ0IsSUFBSSxVQUFVLENBQUMsR0FBRztDQUN6QyxNQUFNLEVBQ0osYUFBYSxHQUNiLGFBQWEsR0FDYixtQkFBbUIsT0FDbkIsU0FBUyxrQkFDUDtDQUNKLE1BQU0sWUFBWSxXQUFXLEtBQUs7Q0FDbEMsSUFBSTtDQUNKLE1BQU0sVUFBVSxhQUFhO0VBQzNCLE1BQU0sUUFBUSxXQUFXLGFBQWE7RUFDdEMsSUFBSSxPQUFPO0dBQ1QsYUFBYSxLQUFLO0dBQ2xCLFFBQVEsS0FBSztFQUNmO0VBQ0EsSUFBSSxPQUNGLFFBQVEsaUJBQWlCLFVBQVUsUUFBUSxVQUFVLEtBQUs7T0FFMUQsVUFBVSxRQUFRO0NBQ3RCO0NBQ0EsSUFBSSxDQUFDLFFBQ0gsT0FBTztDQUNULGlCQUFpQixJQUFJLG9CQUFvQixPQUFPLElBQUksR0FBRyxFQUFFLFNBQVMsS0FBSyxDQUFDO0NBQ3hFLGlCQUFpQixJQUFJLG9CQUFvQixPQUFPLEtBQUssR0FBRyxFQUFFLFNBQVMsS0FBSyxDQUFDO0NBQ3pFLElBQUksa0JBQWtCO0VBQ3BCLGlCQUNFLGVBQWUsYUFBYSxFQUFFLENBQUMsU0FDekIsT0FBTyxLQUFLLENBQ3BCO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFFQSxTQUFTLGVBQWUsUUFBUSxjQUFjO0NBQUUsT0FBTztDQUFHLFFBQVE7QUFBRSxHQUFHLFVBQVUsQ0FBQyxHQUFHO0NBQ25GLE1BQU0sRUFBRSxTQUFTLGVBQWUsTUFBTSxrQkFBa0I7Q0FDeEQsTUFBTSxRQUFRLGVBQWU7RUFDM0IsSUFBSSxJQUFJO0VBQ1IsUUFBUSxNQUFNLEtBQUssYUFBYSxNQUFNLE1BQU0sT0FBTyxLQUFLLElBQUksR0FBRyxpQkFBaUIsT0FBTyxLQUFLLElBQUksR0FBRyxTQUFTLEtBQUs7Q0FDbkgsQ0FBQztDQUNELE1BQU0sUUFBUSxXQUFXLFlBQVksS0FBSztDQUMxQyxNQUFNLFNBQVMsV0FBVyxZQUFZLE1BQU07Q0FDNUMsTUFBTSxFQUFFLE1BQU0sVUFBVSxrQkFDdEIsU0FDQyxDQUFDLFdBQVc7RUFDWCxNQUFNLFVBQVUsUUFBUSxlQUFlLE1BQU0sZ0JBQWdCLFFBQVEsZ0JBQWdCLE1BQU0saUJBQWlCLE1BQU07RUFDbEgsSUFBSSxVQUFVLE1BQU0sT0FBTztHQUN6QixNQUFNLFFBQVEsYUFBYSxNQUFNO0dBQ2pDLElBQUksT0FBTztJQUNULE1BQU0sT0FBTyxNQUFNLHNCQUFzQjtJQUN6QyxNQUFNLFFBQVEsS0FBSztJQUNuQixPQUFPLFFBQVEsS0FBSztHQUN0QjtFQUNGLE9BQU87R0FDTCxJQUFJLFNBQVM7SUFDWCxNQUFNLGdCQUFnQixRQUFRLE9BQU87SUFDckMsTUFBTSxRQUFRLGNBQWMsUUFBUSxLQUFLLEVBQUUsaUJBQWlCLE1BQU0sWUFBWSxDQUFDO0lBQy9FLE9BQU8sUUFBUSxjQUFjLFFBQVEsS0FBSyxFQUFFLGdCQUFnQixNQUFNLFdBQVcsQ0FBQztHQUNoRixPQUFPO0lBQ0wsTUFBTSxRQUFRLE1BQU0sWUFBWTtJQUNoQyxPQUFPLFFBQVEsTUFBTSxZQUFZO0dBQ25DO0VBQ0Y7Q0FDRixHQUNBLE9BQ0Y7Q0FDQSxtQkFBbUI7RUFDakIsTUFBTSxNQUFNLGFBQWEsTUFBTTtFQUMvQixJQUFJLEtBQUs7R0FDUCxNQUFNLFFBQVEsaUJBQWlCLE1BQU0sSUFBSSxjQUFjLFlBQVk7R0FDbkUsT0FBTyxRQUFRLGtCQUFrQixNQUFNLElBQUksZUFBZSxZQUFZO0VBQ3hFO0NBQ0YsQ0FBQztDQUNELE1BQU0sUUFBUSxZQUNOLGFBQWEsTUFBTSxJQUN4QixRQUFRO0VBQ1AsTUFBTSxRQUFRLE1BQU0sWUFBWSxRQUFRO0VBQ3hDLE9BQU8sUUFBUSxNQUFNLFlBQVksU0FBUztDQUM1QyxDQUNGO0NBQ0EsU0FBUyxPQUFPO0VBQ2QsTUFBTTtFQUNOLE1BQU07Q0FDUjtDQUNBLE9BQU87RUFDTDtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsU0FBUyx3QkFBd0IsUUFBUSxVQUFVLFVBQVUsQ0FBQyxHQUFHO0NBQy9ELE1BQU0sRUFDSixNQUNBLGFBQWEsT0FDYixZQUFZLEdBQ1osU0FBUyxlQUNULFlBQVksU0FDVjtDQUNKLE1BQU0sY0FBYyxtQkFBbUIsVUFBVSwwQkFBMEIsTUFBTTtDQUNqRixNQUFNLFVBQVUsZUFBZTtFQUM3QixNQUFNLFVBQVUsUUFBUSxNQUFNO0VBQzlCLE9BQU8sUUFBUSxPQUFPLENBQUMsQ0FBQyxJQUFJLFlBQVksQ0FBQyxDQUFDLE9BQU8sVUFBVTtDQUM3RCxDQUFDO0NBQ0QsSUFBSSxVQUFVO0NBQ2QsTUFBTSxXQUFXLFdBQVcsU0FBUztDQUNyQyxNQUFNLFlBQVksWUFBWSxRQUFRLFlBQzlCO0VBQUMsUUFBUTtFQUFPLGFBQWEsSUFBSTtFQUFHLFNBQVM7Q0FBSyxJQUN2RCxDQUFDLFVBQVUsV0FBVztFQUNyQixRQUFRO0VBQ1IsSUFBSSxDQUFDLFNBQVMsT0FDWjtFQUNGLElBQUksQ0FBQyxTQUFTLFFBQ1o7RUFDRixNQUFNLFdBQVcsSUFBSSxxQkFDbkIsVUFDQTtHQUNFLE1BQU0sYUFBYSxLQUFLO0dBQ3hCO0dBQ0E7RUFDRixDQUNGO0VBQ0EsU0FBUyxTQUFTLE9BQU8sTUFBTSxTQUFTLFFBQVEsRUFBRSxDQUFDO0VBQ25ELGdCQUFnQjtHQUNkLFNBQVMsV0FBVztHQUNwQixVQUFVO0VBQ1o7Q0FDRixHQUNBO0VBQUU7RUFBVyxPQUFPO0NBQU8sQ0FDN0IsSUFBSTtDQUNKLE1BQU0sYUFBYTtFQUNqQixRQUFRO0VBQ1IsVUFBVTtFQUNWLFNBQVMsUUFBUTtDQUNuQjtDQUNBLGtCQUFrQixJQUFJO0NBQ3RCLE9BQU87RUFDTDtFQUNBO0VBQ0EsUUFBUTtHQUNOLFFBQVE7R0FDUixTQUFTLFFBQVE7RUFDbkI7RUFDQSxTQUFTO0dBQ1AsU0FBUyxRQUFRO0VBQ25CO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsU0FBUyxxQkFBcUIsU0FBUyxVQUFVLENBQUMsR0FBRztDQUNuRCxNQUFNLEVBQ0osU0FBUyxlQUNULGNBQ0EsWUFBWSxHQUNaLFlBQ0EsT0FBTyxVQUNMO0NBQ0osTUFBTSxtQkFBbUIsV0FBVyxLQUFLO0NBQ3pDLE1BQU0sRUFBRSxTQUFTLHdCQUNmLFVBQ0MsZ0NBQWdDO0VBQy9CLElBQUksaUJBQWlCLGlCQUFpQjtFQUN0QyxJQUFJLGFBQWE7RUFDakIsS0FBSyxNQUFNLFNBQVMsNkJBQTZCO0dBQy9DLElBQUksTUFBTSxRQUFRLFlBQVk7SUFDNUIsYUFBYSxNQUFNO0lBQ25CLGlCQUFpQixNQUFNO0dBQ3pCO0VBQ0Y7RUFDQSxpQkFBaUIsUUFBUTtFQUN6QixJQUFJLE1BQU07R0FDUixVQUFVLHdCQUF3QjtJQUNoQyxLQUFLO0dBQ1AsQ0FBQztFQUNIO0NBQ0YsR0FDQTtFQUNFLE1BQU07RUFDTjtFQUNBO0VBQ0EsWUFBWSxRQUFRLFVBQVU7Q0FDaEMsQ0FDRjtDQUNBLE9BQU87QUFDVDtBQUVBLE1BQU0seUJBQXlCLElBQUksSUFBSTs7QUFHdkMsU0FBUyxZQUFZLEtBQUs7Q0FDeEIsTUFBTSxRQUFRLGdCQUFnQjtDQUM5QixTQUFTLEdBQUcsVUFBVTtFQUNwQixJQUFJO0VBQ0osTUFBTSxZQUFZLE9BQU8sSUFBSSxHQUFHLHFCQUFxQixJQUFJLElBQUk7RUFDN0QsVUFBVSxJQUFJLFFBQVE7RUFDdEIsT0FBTyxJQUFJLEtBQUssU0FBUztFQUN6QixNQUFNLGFBQWEsSUFBSSxRQUFRO0VBQy9CLENBQUMsS0FBSyxTQUFTLE9BQU8sS0FBSyxJQUFJLE1BQU0sYUFBYSxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSTtFQUM5RSxPQUFPO0NBQ1Q7Q0FDQSxTQUFTLEtBQUssVUFBVTtFQUN0QixTQUFTLFVBQVUsR0FBRyxNQUFNO0dBQzFCLElBQUksU0FBUztHQUNiLFNBQVMsR0FBRyxJQUFJO0VBQ2xCO0VBQ0EsT0FBTyxHQUFHLFNBQVM7Q0FDckI7Q0FDQSxTQUFTLElBQUksVUFBVTtFQUNyQixNQUFNLFlBQVksT0FBTyxJQUFJLEdBQUc7RUFDaEMsSUFBSSxDQUFDLFdBQ0g7RUFDRixVQUFVLE9BQU8sUUFBUTtFQUN6QixJQUFJLENBQUMsVUFBVSxNQUNiLE1BQU07Q0FDVjtDQUNBLFNBQVMsUUFBUTtFQUNmLE9BQU8sT0FBTyxHQUFHO0NBQ25CO0NBQ0EsU0FBUyxLQUFLLE9BQU8sU0FBUztFQUM1QixJQUFJO0VBQ0osQ0FBQyxLQUFLLE9BQU8sSUFBSSxHQUFHLE1BQU0sT0FBTyxLQUFLLElBQUksR0FBRyxTQUFTLE1BQU0sRUFBRSxPQUFPLE9BQU8sQ0FBQztDQUMvRTtDQUNBLE9BQU87RUFBRTtFQUFJO0VBQU07RUFBSztFQUFNO0NBQU07QUFDdEM7QUFFQSxTQUFTLHVCQUF1QixTQUFTO0NBQ3ZDLElBQUksWUFBWSxNQUNkLE9BQU8sQ0FBQztDQUNWLE9BQU87QUFDVDtBQUNBLFNBQVMsZUFBZSxLQUFLLFNBQVMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxHQUFHO0NBQ3RELE1BQU0sUUFBUSxXQUFXLElBQUk7Q0FDN0IsTUFBTSxPQUFPLFdBQVcsSUFBSTtDQUM1QixNQUFNLFNBQVMsV0FBVyxZQUFZO0NBQ3RDLE1BQU0sY0FBYyxJQUFJLElBQUk7Q0FDNUIsTUFBTSxRQUFRLFdBQVcsSUFBSTtDQUM3QixNQUFNLFNBQVMsTUFBTSxHQUFHO0NBQ3hCLE1BQU0sY0FBYyxXQUFXLElBQUk7Q0FDbkMsSUFBSSxtQkFBbUI7Q0FDdkIsSUFBSSxVQUFVO0NBQ2QsTUFBTSxFQUNKLGtCQUFrQixPQUNsQixZQUFZLE1BQ1osY0FBYyxNQUNkLGVBQ0EsYUFBYSxFQUNYLE9BQU8sTUFBTSxFQUNmLE1BQ0U7Q0FDSixNQUFNLGNBQWM7RUFDbEIsSUFBSSxZQUFZLFlBQVksT0FBTztHQUNqQyxZQUFZLE1BQU0sTUFBTTtHQUN4QixZQUFZLFFBQVE7R0FDcEIsT0FBTyxRQUFRO0dBQ2YsbUJBQW1CO0VBQ3JCO0NBQ0Y7Q0FDQSxNQUFNLGNBQWM7RUFDbEIsSUFBSSxvQkFBb0IsT0FBTyxPQUFPLFVBQVUsYUFDOUM7RUFDRixNQUFNLEtBQUssSUFBSSxZQUFZLE9BQU8sT0FBTyxFQUFFLGdCQUFnQixDQUFDO0VBQzVELE9BQU8sUUFBUTtFQUNmLFlBQVksUUFBUTtFQUNwQixHQUFHLGVBQWU7R0FDaEIsT0FBTyxRQUFRO0dBQ2YsTUFBTSxRQUFRO0VBQ2hCO0VBQ0EsR0FBRyxXQUFXLE1BQU07R0FDbEIsT0FBTyxRQUFRO0dBQ2YsTUFBTSxRQUFRO0dBQ2QsSUFBSSxHQUFHLGVBQWUsS0FBSyxDQUFDLG9CQUFvQixlQUFlO0lBQzdELEdBQUcsTUFBTTtJQUNULE1BQU0sRUFDSixVQUFVLENBQUMsR0FDWCxRQUFRLEtBQ1IsYUFDRSx1QkFBdUIsYUFBYTtJQUN4QyxXQUFXO0lBQ1gsSUFBSSxPQUFPLFlBQVksYUFBYSxVQUFVLEtBQUssVUFBVSxVQUMzRCxXQUFXLE9BQU8sS0FBSztTQUNwQixJQUFJLE9BQU8sWUFBWSxjQUFjLFFBQVEsR0FDaEQsV0FBVyxPQUFPLEtBQUs7U0FFdkIsWUFBWSxPQUFPLEtBQUssSUFBSSxTQUFTO0dBQ3pDO0VBQ0Y7RUFDQSxHQUFHLGFBQWEsTUFBTTtHQUNwQixJQUFJO0dBQ0osTUFBTSxRQUFRO0dBQ2QsS0FBSyxTQUFTLEtBQUssV0FBVyxLQUFLLEVBQUUsSUFBSSxNQUFNLE9BQU8sS0FBSztHQUMzRCxZQUFZLFFBQVEsRUFBRTtFQUN4QjtFQUNBLEtBQUssTUFBTSxjQUFjLFFBQVE7R0FDL0IsaUJBQWlCLElBQUksYUFBYSxNQUFNO0lBQ3RDLElBQUksSUFBSTtJQUNSLE1BQU0sUUFBUTtJQUNkLEtBQUssU0FBUyxLQUFLLFdBQVcsS0FBSyxFQUFFLElBQUksTUFBTSxPQUFPLEtBQUs7SUFDM0QsWUFBWSxTQUFTLEtBQUssRUFBRSxnQkFBZ0IsT0FBTyxLQUFLO0dBQzFELEdBQUcsRUFBRSxTQUFTLEtBQUssQ0FBQztFQUN0QjtDQUNGO0NBQ0EsTUFBTSxhQUFhO0VBQ2pCLElBQUksQ0FBQyxVQUNIO0VBQ0YsTUFBTTtFQUNOLG1CQUFtQjtFQUNuQixVQUFVO0VBQ1YsTUFBTTtDQUNSO0NBQ0EsSUFBSSxXQUNGLEtBQUs7Q0FDUCxJQUFJLGFBQ0YsTUFBTSxRQUFRLElBQUk7Q0FDcEIsa0JBQWtCLEtBQUs7Q0FDdkIsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGOztBQUdBLFNBQVMsY0FBYyxVQUFVLENBQUMsR0FBRztDQUNuQyxNQUFNLEVBQUUsZUFBZSxPQUFPO0NBQzlCLE1BQU0sY0FBYyxtQkFBbUIsT0FBTyxXQUFXLGVBQWUsZ0JBQWdCLE1BQU07Q0FDOUYsTUFBTSxVQUFVLFdBQVcsWUFBWTtDQUN2QyxlQUFlLEtBQUssYUFBYTtFQUMvQixJQUFJLENBQUMsWUFBWSxPQUNmO0VBQ0YsTUFBTSxhQUFhLElBQUksT0FBTyxXQUFXO0VBQ3pDLE1BQU0sU0FBUyxNQUFNLFdBQVcsS0FBSyxXQUFXO0VBQ2hELFFBQVEsUUFBUSxPQUFPO0VBQ3ZCLE9BQU87Q0FDVDtDQUNBLE9BQU87RUFBRTtFQUFhO0VBQVM7Q0FBSztBQUN0QztBQUVBLFNBQVMsV0FBVyxVQUFVLE1BQU0sVUFBVSxDQUFDLEdBQUc7Q0FDaEQsTUFBTSxFQUNKLFVBQVUsSUFDVixNQUFNLFFBQ04sV0FBVyxvQkFDVDtDQUNKLE1BQU0sVUFBVSxNQUFNLE9BQU87Q0FDN0IsTUFBTSxhQUFhLFNBQVM7RUFDMUIsTUFBTSxXQUFXLFlBQVksT0FBTyxLQUFLLElBQUksU0FBUyxLQUFLLGlCQUFpQixjQUFjLElBQUksR0FBRztFQUNqRyxJQUFJLENBQUMsWUFBWSxTQUFTLFdBQVcsR0FBRztHQUN0QyxNQUFNLE9BQU8sWUFBWSxPQUFPLEtBQUssSUFBSSxTQUFTLGNBQWMsTUFBTTtHQUN0RSxJQUFJLE1BQU07SUFDUixLQUFLLE1BQU07SUFDWCxLQUFLLE9BQU8sR0FBRyxVQUFVO0lBQ3pCLEtBQUssT0FBTyxTQUFTLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxJQUFJO0lBQ3pDLFlBQVksT0FBTyxLQUFLLElBQUksU0FBUyxLQUFLLE9BQU8sSUFBSTtHQUN2RDtHQUNBO0VBQ0Y7RUFDQSxZQUFZLE9BQU8sS0FBSyxJQUFJLFNBQVMsU0FBUyxPQUFPLEdBQUcsT0FBTyxHQUFHLFVBQVUsTUFBTTtDQUNwRjtDQUNBLE1BQ0UsVUFDQyxHQUFHLE1BQU07RUFDUixJQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sR0FDakMsVUFBVSxDQUFDO0NBQ2YsR0FDQSxFQUFFLFdBQVcsS0FBSyxDQUNwQjtDQUNBLE9BQU87QUFDVDtBQUVBLE1BQU0saUJBQWlCO0NBQ3JCLE1BQU07Q0FDTixNQUFNO0FBQ1I7QUFDQSxTQUFTLGVBQWUsS0FBSztDQUMzQixPQUFPLE9BQU8sYUFBYSxLQUFLLGFBQWEsV0FBVyxlQUFlLFdBQVcsZUFBZSxjQUFjLGdCQUFnQixTQUFTLG1CQUFtQjtBQUM3SjtBQUNBLE1BQU0sYUFBYTtBQUNuQixTQUFTLGNBQWMsS0FBSztDQUMxQixPQUFPLFdBQVcsS0FBSyxHQUFHO0FBQzVCO0FBQ0EsU0FBUyxnQkFBZ0IsU0FBUztDQUNoQyxJQUFJLE9BQU8sWUFBWSxlQUFlLG1CQUFtQixTQUN2RCxPQUFPLE9BQU8sWUFBWSxRQUFRLFFBQVEsQ0FBQztDQUM3QyxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGlCQUFpQixhQUFhLEdBQUcsV0FBVztDQUNuRCxJQUFJLGdCQUFnQixhQUFhO0VBQy9CLE9BQU8sT0FBTyxRQUFRO0dBQ3BCLElBQUk7R0FDSixLQUFLLElBQUksSUFBSSxVQUFVLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztJQUM5QyxJQUFJLFVBQVUsTUFBTSxNQUFNO0tBQ3hCLFdBQVcsVUFBVTtLQUNyQjtJQUNGO0dBQ0Y7R0FDQSxJQUFJLFVBQ0YsT0FBTztJQUFFLEdBQUc7SUFBSyxHQUFHLE1BQU0sU0FBUyxHQUFHO0dBQUU7R0FDMUMsT0FBTztFQUNUO0NBQ0YsT0FBTztFQUNMLE9BQU8sT0FBTyxRQUFRO0dBQ3BCLEtBQUssTUFBTSxZQUFZLFdBQVc7SUFDaEMsSUFBSSxVQUNGLE1BQU07S0FBRSxHQUFHO0tBQUssR0FBRyxNQUFNLFNBQVMsR0FBRztJQUFFO0dBQzNDO0dBQ0EsT0FBTztFQUNUO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsWUFBWSxTQUFTLENBQUMsR0FBRztDQUNoQyxNQUFNLGVBQWUsT0FBTyxlQUFlO0NBQzNDLE1BQU0sV0FBVyxPQUFPLFdBQVcsQ0FBQztDQUNwQyxNQUFNLGdCQUFnQixPQUFPLGdCQUFnQixDQUFDO0NBQzlDLFNBQVMsZ0JBQWdCLEtBQUssR0FBRyxNQUFNO0VBQ3JDLE1BQU0sY0FBYyxlQUFlO0dBQ2pDLE1BQU0sVUFBVSxRQUFRLE9BQU8sT0FBTztHQUN0QyxNQUFNLFlBQVksUUFBUSxHQUFHO0dBQzdCLE9BQU8sV0FBVyxDQUFDLGNBQWMsU0FBUyxJQUFJLFVBQVUsU0FBUyxTQUFTLElBQUk7RUFDaEYsQ0FBQztFQUNELElBQUksVUFBVTtFQUNkLElBQUksZUFBZTtFQUNuQixJQUFJLEtBQUssU0FBUyxHQUFHO0dBQ25CLElBQUksZUFBZSxLQUFLLEVBQUUsR0FBRztJQUMzQixVQUFVO0tBQ1IsR0FBRztLQUNILEdBQUcsS0FBSztLQUNSLGFBQWEsaUJBQWlCLGNBQWMsU0FBUyxhQUFhLEtBQUssRUFBRSxDQUFDLFdBQVc7S0FDckYsWUFBWSxpQkFBaUIsY0FBYyxTQUFTLFlBQVksS0FBSyxFQUFFLENBQUMsVUFBVTtLQUNsRixjQUFjLGlCQUFpQixjQUFjLFNBQVMsY0FBYyxLQUFLLEVBQUUsQ0FBQyxZQUFZO0lBQzFGO0dBQ0YsT0FBTztJQUNMLGVBQWU7S0FDYixHQUFHO0tBQ0gsR0FBRyxLQUFLO0tBQ1IsU0FBUztNQUNQLEdBQUcsZ0JBQWdCLGFBQWEsT0FBTyxLQUFLLENBQUM7TUFDN0MsR0FBRyxnQkFBZ0IsS0FBSyxFQUFFLENBQUMsT0FBTyxLQUFLLENBQUM7S0FDMUM7SUFDRjtHQUNGO0VBQ0Y7RUFDQSxJQUFJLEtBQUssU0FBUyxLQUFLLGVBQWUsS0FBSyxFQUFFLEdBQUc7R0FDOUMsVUFBVTtJQUNSLEdBQUc7SUFDSCxHQUFHLEtBQUs7SUFDUixhQUFhLGlCQUFpQixjQUFjLFNBQVMsYUFBYSxLQUFLLEVBQUUsQ0FBQyxXQUFXO0lBQ3JGLFlBQVksaUJBQWlCLGNBQWMsU0FBUyxZQUFZLEtBQUssRUFBRSxDQUFDLFVBQVU7SUFDbEYsY0FBYyxpQkFBaUIsY0FBYyxTQUFTLGNBQWMsS0FBSyxFQUFFLENBQUMsWUFBWTtHQUMxRjtFQUNGO0VBQ0EsT0FBTyxTQUFTLGFBQWEsY0FBYyxPQUFPO0NBQ3BEO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxTQUFTLEtBQUssR0FBRyxNQUFNO0NBQzlCLElBQUksSUFBSTtDQUNSLE1BQU0sZ0JBQWdCLE9BQU8sb0JBQW9CO0NBQ2pELElBQUksZUFBZSxDQUFDO0NBQ3BCLElBQUksVUFBVTtFQUNaLFdBQVc7RUFDWCxTQUFTO0VBQ1QsU0FBUztFQUNULG1CQUFtQjtDQUNyQjtDQUNBLE1BQU0sU0FBUztFQUNiLFFBQVE7RUFDUixNQUFNO0VBQ04sU0FBUyxLQUFLO0NBQ2hCO0NBQ0EsSUFBSSxLQUFLLFNBQVMsR0FBRztFQUNuQixJQUFJLGVBQWUsS0FBSyxFQUFFLEdBQ3hCLFVBQVU7R0FBRSxHQUFHO0dBQVMsR0FBRyxLQUFLO0VBQUc7T0FFbkMsZUFBZSxLQUFLO0NBQ3hCO0NBQ0EsSUFBSSxLQUFLLFNBQVMsR0FBRztFQUNuQixJQUFJLGVBQWUsS0FBSyxFQUFFLEdBQ3hCLFVBQVU7R0FBRSxHQUFHO0dBQVMsR0FBRyxLQUFLO0VBQUc7Q0FDdkM7Q0FDQSxNQUFNLEVBQ0osU0FBUyxNQUFNLEtBQUssa0JBQWtCLE9BQU8sS0FBSyxJQUFJLEdBQUcsVUFBVSxPQUFPLEtBQUssY0FBYyxPQUFPLEtBQUssSUFBSSxXQUFXLE9BQ3hILGFBQ0EsWUFDRTtDQUNKLE1BQU0sZ0JBQWdCLGdCQUFnQjtDQUN0QyxNQUFNLGFBQWEsZ0JBQWdCO0NBQ25DLE1BQU0sZUFBZSxnQkFBZ0I7Q0FDckMsTUFBTSxhQUFhLFdBQVcsS0FBSztDQUNuQyxNQUFNLGFBQWEsV0FBVyxLQUFLO0NBQ25DLE1BQU0sVUFBVSxXQUFXLEtBQUs7Q0FDaEMsTUFBTSxhQUFhLFdBQVcsSUFBSTtDQUNsQyxNQUFNLFdBQVcsV0FBVyxJQUFJO0NBQ2hDLE1BQU0sUUFBUSxXQUFXLElBQUk7Q0FDN0IsTUFBTSxPQUFPLFdBQVcsZUFBZSxJQUFJO0NBQzNDLE1BQU0sV0FBVyxlQUFlLGlCQUFpQixXQUFXLEtBQUs7Q0FDakUsSUFBSTtDQUNKLElBQUk7Q0FDSixNQUFNLFNBQVMsV0FBVztFQUN4QixJQUFJLGVBQWU7R0FDakIsY0FBYyxPQUFPLEtBQUssSUFBSSxXQUFXLE1BQU0sTUFBTTtHQUNyRCxhQUFhLElBQUksZ0JBQWdCO0dBQ2pDLFdBQVcsT0FBTyxnQkFBZ0IsUUFBUSxRQUFRO0dBQ2xELGVBQWU7SUFDYixHQUFHO0lBQ0gsUUFBUSxXQUFXO0dBQ3JCO0VBQ0Y7Q0FDRjtDQUNBLE1BQU0sV0FBVyxjQUFjO0VBQzdCLFdBQVcsUUFBUTtFQUNuQixXQUFXLFFBQVEsQ0FBQztDQUN0QjtDQUNBLElBQUksU0FDRixRQUFRLGFBQWEsT0FBTyxTQUFTLEVBQUUsV0FBVyxNQUFNLENBQUM7Q0FDM0QsSUFBSSxpQkFBaUI7Q0FDckIsTUFBTSxVQUFVLE9BQU8sZ0JBQWdCLFVBQVU7RUFDL0MsSUFBSSxLQUFLO0VBQ1QsTUFBTTtFQUNOLFFBQVEsSUFBSTtFQUNaLE1BQU0sUUFBUTtFQUNkLFdBQVcsUUFBUTtFQUNuQixRQUFRLFFBQVE7RUFDaEIsa0JBQWtCO0VBQ2xCLE1BQU0sd0JBQXdCO0VBQzlCLE1BQU0sc0JBQXNCO0dBQzFCLFFBQVEsT0FBTztHQUNmLFNBQVMsQ0FBQztFQUNaO0VBQ0EsTUFBTSxVQUFVLFFBQVEsT0FBTyxPQUFPO0VBQ3RDLElBQUksU0FBUztHQUNYLE1BQU0sVUFBVSxnQkFBZ0Isb0JBQW9CLE9BQU87R0FDM0QsTUFBTSxRQUFRLE9BQU8sZUFBZSxPQUFPO0dBQzNDLElBQUksQ0FBQyxPQUFPLGVBQWUsWUFBWSxVQUFVLE9BQU8sYUFBYSxNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUUsbUJBQW1CLFdBQ2pILE9BQU8sY0FBYztHQUN2QixJQUFJLE9BQU8sYUFDVCxRQUFRLG1CQUFtQixNQUFNLGVBQWUsT0FBTyxpQkFBaUIsT0FBTyxNQUFNLE9BQU87R0FDOUYsb0JBQW9CLE9BQU8sT0FBTyxnQkFBZ0IsU0FBUyxLQUFLLFVBQVUsT0FBTyxJQUFJO0VBQ3ZGO0VBQ0EsSUFBSSxhQUFhO0VBQ2pCLE1BQU0sVUFBVTtHQUNkLEtBQUssUUFBUSxHQUFHO0dBQ2hCLFNBQVM7SUFDUCxHQUFHO0lBQ0gsR0FBRztHQUNMO0dBQ0EsY0FBYztJQUNaLGFBQWE7R0FDZjtFQUNGO0VBQ0EsSUFBSSxRQUFRLGFBQ1YsT0FBTyxPQUFPLFNBQVMsTUFBTSxRQUFRLFlBQVksT0FBTyxDQUFDO0VBQzNELElBQUksY0FBYyxDQUFDLE9BQU87R0FDeEIsUUFBUSxLQUFLO0dBQ2IsT0FBTyxRQUFRLFFBQVEsSUFBSTtFQUM3QjtFQUNBLElBQUksZUFBZTtFQUNuQixJQUFJLE9BQ0YsTUFBTSxNQUFNO0VBQ2QsT0FBTyxNQUNMLFFBQVEsS0FDUjtHQUNFLEdBQUc7R0FDSCxHQUFHLFFBQVE7R0FDWCxTQUFTO0lBQ1AsR0FBRyxnQkFBZ0Isb0JBQW9CLE9BQU87SUFDOUMsR0FBRyxpQkFBaUIsTUFBTSxRQUFRLFlBQVksT0FBTyxLQUFLLElBQUksSUFBSSxPQUFPO0dBQzNFO0VBQ0YsQ0FDRixDQUFDLENBQUMsS0FBSyxPQUFPLGtCQUFrQjtHQUM5QixTQUFTLFFBQVE7R0FDakIsV0FBVyxRQUFRLGNBQWM7R0FDakMsZUFBZSxNQUFNLGNBQWMsTUFBTSxDQUFDLENBQUMsT0FBTyxLQUFLLENBQUM7R0FDeEQsSUFBSSxDQUFDLGNBQWMsSUFBSTtJQUNyQixLQUFLLFFBQVEsZUFBZTtJQUM1QixNQUFNLElBQUksTUFBTSxjQUFjLFVBQVU7R0FDMUM7R0FDQSxJQUFJLFFBQVEsWUFBWTtJQUN0QixDQUFDLENBQUUsTUFBTSxnQkFBaUIsTUFBTSxRQUFRLFdBQVc7S0FDakQsTUFBTTtLQUNOLFVBQVU7S0FDVjtLQUNBO0lBQ0YsQ0FBQztHQUNIO0dBQ0EsS0FBSyxRQUFRO0dBQ2IsY0FBYyxRQUFRLGFBQWE7R0FDbkMsT0FBTztFQUNULENBQUMsQ0FBQyxDQUFDLE1BQU0sT0FBTyxlQUFlO0dBQzdCLElBQUksWUFBWSxXQUFXLFdBQVcsV0FBVztHQUNqRCxJQUFJLFFBQVEsY0FBYztJQUN4QixDQUFDLENBQUUsT0FBTyxXQUFXLE1BQU0sZ0JBQWlCLE1BQU0sUUFBUSxhQUFhO0tBQ3JFLE1BQU07S0FDTixPQUFPO0tBQ1AsVUFBVSxTQUFTO0tBQ25CO0tBQ0E7SUFDRixDQUFDO0dBQ0g7R0FDQSxNQUFNLFFBQVE7R0FDZCxJQUFJLFFBQVEsbUJBQ1YsS0FBSyxRQUFRO0dBQ2YsV0FBVyxRQUFRLFVBQVU7R0FDN0IsSUFBSSxlQUNGLE1BQU07R0FDUixPQUFPO0VBQ1QsQ0FBQyxDQUFDLENBQUMsY0FBYztHQUNmLElBQUksMEJBQTBCLGdCQUM1QixRQUFRLEtBQUs7R0FDZixJQUFJLE9BQ0YsTUFBTSxLQUFLO0dBQ2IsYUFBYSxRQUFRLElBQUk7RUFDM0IsQ0FBQztDQUNIO0NBQ0EsTUFBTSxVQUFVLE1BQU0sUUFBUSxPQUFPO0NBQ3JDLE1BQ0UsQ0FDRSxTQUNBLE1BQU0sR0FBRyxDQUNYLElBQ0MsQ0FBQyxjQUFjLFlBQVksUUFBUSxHQUNwQyxFQUFFLE1BQU0sS0FBSyxDQUNmO0NBQ0EsTUFBTSxRQUFRO0VBQ1osWUFBWSxTQUFTLFVBQVU7RUFDL0IsWUFBWSxTQUFTLFVBQVU7RUFDL0I7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLGlCQUFpQixjQUFjO0VBQy9CLGNBQWMsV0FBVztFQUN6QixnQkFBZ0IsYUFBYTs7RUFFN0IsS0FBSyxVQUFVLEtBQUs7RUFDcEIsS0FBSyxVQUFVLEtBQUs7RUFDcEIsTUFBTSxVQUFVLE1BQU07RUFDdEIsUUFBUSxVQUFVLFFBQVE7RUFDMUIsT0FBTyxVQUFVLE9BQU87RUFDeEIsTUFBTSxVQUFVLE1BQU07RUFDdEIsU0FBUyxVQUFVLFNBQVM7O0VBRTVCLE1BQU0sUUFBUSxNQUFNO0VBQ3BCLE1BQU0sUUFBUSxNQUFNO0VBQ3BCLE1BQU0sUUFBUSxNQUFNO0VBQ3BCLGFBQWEsUUFBUSxhQUFhO0VBQ2xDLFVBQVUsUUFBUSxVQUFVO0NBQzlCO0NBQ0EsU0FBUyxVQUFVLFFBQVE7RUFDekIsUUFBUSxTQUFTLGdCQUFnQjtHQUMvQixJQUFJLENBQUMsV0FBVyxPQUFPO0lBQ3JCLE9BQU8sU0FBUztJQUNoQixPQUFPLFVBQVU7SUFDakIsT0FBTyxjQUFjO0lBQ3JCLElBQUksTUFBTSxPQUFPLE9BQU8sR0FBRztLQUN6QixNQUNFLENBQ0UsU0FDQSxNQUFNLE9BQU8sT0FBTyxDQUN0QixJQUNDLENBQUMsY0FBYyxZQUFZLFFBQVEsR0FDcEMsRUFBRSxNQUFNLEtBQUssQ0FDZjtJQUNGO0lBQ0EsT0FBTztLQUNMLEdBQUc7S0FDSCxLQUFLLGFBQWEsWUFBWTtNQUM1QixPQUFPLGtCQUFrQixDQUFDLENBQUMsS0FBSyxhQUFhLFVBQVU7S0FDekQ7SUFDRjtHQUNGO0dBQ0EsT0FBTyxLQUFLO0VBQ2Q7Q0FDRjtDQUNBLFNBQVMsb0JBQW9CO0VBQzNCLE9BQU8sSUFBSSxTQUFTLFNBQVMsV0FBVztHQUN0QyxNQUFNLFVBQVUsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsV0FBVyxRQUFRLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxNQUFNO0VBQ3RFLENBQUM7Q0FDSDtDQUNBLFNBQVMsUUFBUSxNQUFNO0VBQ3JCLGFBQWE7R0FDWCxJQUFJLENBQUMsV0FBVyxPQUFPO0lBQ3JCLE9BQU8sT0FBTztJQUNkLE9BQU87S0FDTCxHQUFHO0tBQ0gsS0FBSyxhQUFhLFlBQVk7TUFDNUIsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLEtBQUssYUFBYSxVQUFVO0tBQ3pEO0lBQ0Y7R0FDRjtHQUNBLE9BQU8sS0FBSztFQUNkO0NBQ0Y7Q0FDQSxJQUFJLFFBQVEsV0FDVixRQUFRLFFBQVEsQ0FBQyxDQUFDLFdBQVcsUUFBUSxDQUFDO0NBQ3hDLE9BQU87RUFDTCxHQUFHO0VBQ0gsS0FBSyxhQUFhLFlBQVk7R0FDNUIsT0FBTyxrQkFBa0IsQ0FBQyxDQUFDLEtBQUssYUFBYSxVQUFVO0VBQ3pEO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsVUFBVSxPQUFPLEtBQUs7Q0FDN0IsSUFBSSxDQUFDLE1BQU0sU0FBUyxHQUFHLEtBQUssQ0FBQyxJQUFJLFdBQVcsR0FBRyxHQUFHO0VBQ2hELE9BQU8sR0FBRyxNQUFNLEdBQUc7Q0FDckI7Q0FDQSxJQUFJLE1BQU0sU0FBUyxHQUFHLEtBQUssSUFBSSxXQUFXLEdBQUcsR0FBRztFQUM5QyxPQUFPLEdBQUcsTUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLElBQUk7Q0FDakM7Q0FDQSxPQUFPLEdBQUcsUUFBUTtBQUNwQjtBQUVBLE1BQU0sa0JBQWtCO0NBQ3RCLFVBQVU7Q0FDVixRQUFRO0NBQ1IsT0FBTztDQUNQLFdBQVc7QUFDYjtBQUNBLFNBQVMsb0JBQW9CLE9BQU87Q0FDbEMsSUFBSSxDQUFDLE9BQ0gsT0FBTztDQUNULElBQUksaUJBQWlCLFVBQ25CLE9BQU87Q0FDVCxNQUFNLEtBQUssSUFBSSxhQUFhO0NBQzVCLEtBQUssTUFBTSxRQUFRLE9BQU87RUFDeEIsR0FBRyxNQUFNLElBQUksSUFBSTtDQUNuQjtDQUNBLE9BQU8sR0FBRztBQUNaO0FBQ0EsU0FBUyxjQUFjLFVBQVUsQ0FBQyxHQUFHO0NBQ25DLE1BQU0sRUFDSixXQUFXLG9CQUNUO0NBQ0osTUFBTSxRQUFRLElBQUksb0JBQW9CLFFBQVEsWUFBWSxDQUFDO0NBQzNELE1BQU0sRUFBRSxJQUFJLFVBQVUsU0FBUyxrQkFBa0IsZ0JBQWdCO0NBQ2pFLE1BQU0sRUFBRSxJQUFJLFVBQVUsU0FBUyxrQkFBa0IsZ0JBQWdCO0NBQ2pFLE1BQU0sV0FBVyxlQUFlO0VBQzlCLElBQUk7RUFDSixNQUFNLFNBQVMsS0FBSyxhQUFhLFFBQVEsS0FBSyxNQUFNLE9BQU8sS0FBSyxXQUFXLFNBQVMsY0FBYyxPQUFPLElBQUksS0FBSztFQUNsSCxJQUFJLE9BQU87R0FDVCxNQUFNLE9BQU87R0FDYixNQUFNLFlBQVksVUFBVTtJQUMxQixNQUFNLFNBQVMsTUFBTTtJQUNyQixNQUFNLFFBQVEsT0FBTztJQUNyQixjQUFjLE1BQU0sS0FBSztHQUMzQjtHQUNBLE1BQU0saUJBQWlCO0lBQ3JCLGNBQWM7R0FDaEI7RUFDRjtFQUNBLE9BQU87Q0FDVCxDQUFDO0NBQ0QsTUFBTSxjQUFjO0VBQ2xCLE1BQU0sUUFBUTtFQUNkLElBQUksU0FBUyxTQUFTLFNBQVMsTUFBTSxPQUFPO0dBQzFDLFNBQVMsTUFBTSxRQUFRO0dBQ3ZCLGNBQWMsSUFBSTtFQUNwQjtDQUNGO0NBQ0EsTUFBTSxnQkFBZ0IsYUFBYTtFQUNqQyxNQUFNLEtBQUssU0FBUztFQUNwQixJQUFJLENBQUMsSUFDSDtFQUNGLEdBQUcsV0FBVyxRQUFRLFNBQVMsUUFBUTtFQUN2QyxHQUFHLFNBQVMsUUFBUSxTQUFTLE1BQU07RUFDbkMsR0FBRyxrQkFBa0IsUUFBUSxTQUFTLFNBQVM7RUFDL0MsSUFBSSxPQUFPLFVBQVUsU0FBUyxHQUM1QixHQUFHLFVBQVUsUUFBUSxTQUFTLE9BQU87Q0FDekM7Q0FDQSxNQUFNLFFBQVEsaUJBQWlCO0VBQzdCLE1BQU0sS0FBSyxTQUFTO0VBQ3BCLElBQUksQ0FBQyxJQUNIO0VBQ0YsTUFBTSxnQkFBZ0I7R0FDcEIsR0FBRztHQUNILEdBQUc7R0FDSCxHQUFHO0VBQ0w7RUFDQSxhQUFhLGFBQWE7RUFDMUIsSUFBSSxRQUFRLGNBQWMsS0FBSyxHQUM3QixNQUFNO0VBQ1IsR0FBRyxNQUFNO0NBQ1g7Q0FDQSxrQkFBa0I7RUFDaEIsYUFBYSxPQUFPO0NBQ3RCLENBQUM7Q0FDRCxPQUFPO0VBQ0wsT0FBTyxTQUFTLEtBQUs7RUFDckI7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsU0FBUyxvQkFBb0IsVUFBVSxDQUFDLEdBQUc7Q0FDekMsTUFBTSxFQUNKLFFBQVEsVUFBVSxlQUNsQixXQUFXLFdBQ1Q7Q0FDSixNQUFNLFNBQVM7Q0FDZixNQUFNLGNBQWMsbUJBQW1CLFVBQVUsd0JBQXdCLFVBQVUsd0JBQXdCLE1BQU07Q0FDakgsTUFBTSxhQUFhLFdBQVc7Q0FDOUIsTUFBTSxPQUFPLFdBQVc7Q0FDeEIsTUFBTSxPQUFPLFdBQVc7Q0FDeEIsTUFBTSxXQUFXLGVBQWU7RUFDOUIsSUFBSSxJQUFJO0VBQ1IsUUFBUSxNQUFNLEtBQUssS0FBSyxVQUFVLE9BQU8sS0FBSyxJQUFJLEdBQUcsU0FBUyxPQUFPLEtBQUs7Q0FDNUUsQ0FBQztDQUNELE1BQU0sV0FBVyxlQUFlO0VBQzlCLElBQUksSUFBSTtFQUNSLFFBQVEsTUFBTSxLQUFLLEtBQUssVUFBVSxPQUFPLEtBQUssSUFBSSxHQUFHLFNBQVMsT0FBTyxLQUFLO0NBQzVFLENBQUM7Q0FDRCxNQUFNLFdBQVcsZUFBZTtFQUM5QixJQUFJLElBQUk7RUFDUixRQUFRLE1BQU0sS0FBSyxLQUFLLFVBQVUsT0FBTyxLQUFLLElBQUksR0FBRyxTQUFTLE9BQU8sS0FBSztDQUM1RSxDQUFDO0NBQ0QsTUFBTSxtQkFBbUIsZUFBZTtFQUN0QyxJQUFJLElBQUk7RUFDUixRQUFRLE1BQU0sS0FBSyxLQUFLLFVBQVUsT0FBTyxLQUFLLElBQUksR0FBRyxpQkFBaUIsT0FBTyxLQUFLO0NBQ3BGLENBQUM7Q0FDRCxlQUFlLEtBQUssV0FBVyxDQUFDLEdBQUc7RUFDakMsSUFBSSxDQUFDLFlBQVksT0FDZjtFQUNGLE1BQU0sQ0FBQyxVQUFVLE1BQU0sT0FBTyxtQkFBbUI7R0FBRSxHQUFHLFFBQVEsT0FBTztHQUFHLEdBQUc7RUFBUyxDQUFDO0VBQ3JGLFdBQVcsUUFBUTtFQUNuQixNQUFNLFdBQVc7Q0FDbkI7Q0FDQSxlQUFlLE9BQU8sV0FBVyxDQUFDLEdBQUc7RUFDbkMsSUFBSSxDQUFDLFlBQVksT0FDZjtFQUNGLFdBQVcsUUFBUSxNQUFNLE9BQU8sbUJBQW1CO0dBQUUsR0FBRztHQUFTLEdBQUc7RUFBUyxDQUFDO0VBQzlFLEtBQUssUUFBUSxLQUFLO0VBQ2xCLE1BQU0sV0FBVztDQUNuQjtDQUNBLGVBQWUsS0FBSyxXQUFXLENBQUMsR0FBRztFQUNqQyxJQUFJLENBQUMsWUFBWSxPQUNmO0VBQ0YsSUFBSSxDQUFDLFdBQVcsT0FDZCxPQUFPLE9BQU8sUUFBUTtFQUN4QixJQUFJLEtBQUssT0FBTztHQUNkLE1BQU0saUJBQWlCLE1BQU0sV0FBVyxNQUFNLGVBQWU7R0FDN0QsTUFBTSxlQUFlLE1BQU0sS0FBSyxLQUFLO0dBQ3JDLE1BQU0sZUFBZSxNQUFNO0VBQzdCO0VBQ0EsTUFBTSxXQUFXO0NBQ25CO0NBQ0EsZUFBZSxPQUFPLFdBQVcsQ0FBQyxHQUFHO0VBQ25DLElBQUksQ0FBQyxZQUFZLE9BQ2Y7RUFDRixXQUFXLFFBQVEsTUFBTSxPQUFPLG1CQUFtQjtHQUFFLEdBQUc7R0FBUyxHQUFHO0VBQVMsQ0FBQztFQUM5RSxJQUFJLEtBQUssT0FBTztHQUNkLE1BQU0saUJBQWlCLE1BQU0sV0FBVyxNQUFNLGVBQWU7R0FDN0QsTUFBTSxlQUFlLE1BQU0sS0FBSyxLQUFLO0dBQ3JDLE1BQU0sZUFBZSxNQUFNO0VBQzdCO0VBQ0EsTUFBTSxXQUFXO0NBQ25CO0NBQ0EsZUFBZSxhQUFhO0VBQzFCLElBQUk7RUFDSixLQUFLLFFBQVEsUUFBUSxLQUFLLFdBQVcsVUFBVSxPQUFPLEtBQUssSUFBSSxHQUFHLFFBQVE7Q0FDNUU7Q0FDQSxlQUFlLGFBQWE7RUFDMUIsSUFBSSxJQUFJO0VBQ1IsTUFBTSxXQUFXO0VBQ2pCLE1BQU0sT0FBTyxRQUFRLFFBQVE7RUFDN0IsSUFBSSxTQUFTLFFBQ1gsS0FBSyxRQUFRLFFBQVEsS0FBSyxLQUFLLFVBQVUsT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLO09BQzlELElBQUksU0FBUyxlQUNoQixLQUFLLFFBQVEsUUFBUSxLQUFLLEtBQUssVUFBVSxPQUFPLEtBQUssSUFBSSxHQUFHLFlBQVk7T0FDckUsSUFBSSxTQUFTLFFBQ2hCLEtBQUssUUFBUSxLQUFLO0NBQ3RCO0NBQ0EsWUFBWSxRQUFRLFFBQVEsR0FBRyxVQUFVO0NBQ3pDLE9BQU87RUFDTDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsU0FBUyxTQUFTLFFBQVEsVUFBVSxDQUFDLEdBQUc7Q0FDdEMsTUFBTSxFQUFFLGVBQWUsT0FBTyxlQUFlLE9BQU8sZ0JBQWdCLFVBQVU7Q0FDOUUsTUFBTSxlQUFlLFdBQVcsS0FBSztDQUNyQyxNQUFNLGdCQUFnQixlQUFlLGFBQWEsTUFBTSxDQUFDO0NBQ3pELE1BQU0sa0JBQWtCLEVBQUUsU0FBUyxLQUFLO0NBQ3hDLGlCQUFpQixlQUFlLFVBQVUsVUFBVTtFQUNsRCxJQUFJLElBQUk7RUFDUixJQUFJLENBQUMsa0JBQWtCLE1BQU0sS0FBSyxNQUFNLE9BQU0sQ0FBRSxZQUFZLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLGdCQUFnQixJQUN0RyxhQUFhLFFBQVE7Q0FDekIsR0FBRyxlQUFlO0NBQ2xCLGlCQUFpQixlQUFlLGNBQWMsYUFBYSxRQUFRLE9BQU8sZUFBZTtDQUN6RixNQUFNLFVBQVUsU0FBUztFQUN2QixXQUFXLGFBQWE7RUFDeEIsSUFBSSxPQUFPO0dBQ1QsSUFBSSxJQUFJO0dBQ1IsSUFBSSxDQUFDLFNBQVMsYUFBYSxPQUN6QixDQUFDLEtBQUssY0FBYyxVQUFVLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSztRQUNuRCxJQUFJLFNBQVMsQ0FBQyxhQUFhLE9BQzlCLENBQUMsS0FBSyxjQUFjLFVBQVUsT0FBTyxLQUFLLElBQUksR0FBRyxNQUFNLEVBQUUsY0FBYyxDQUFDO0VBQzVFO0NBQ0YsQ0FBQztDQUNELE1BQ0UscUJBQ007RUFDSixRQUFRLFFBQVE7Q0FDbEIsR0FDQTtFQUFFLFdBQVc7RUFBTSxPQUFPO0NBQU8sQ0FDbkM7Q0FDQSxPQUFPLEVBQUUsUUFBUTtBQUNuQjtBQUVBLE1BQU0saUJBQWlCO0FBQ3ZCLE1BQU0sa0JBQWtCO0FBQ3hCLE1BQU0sNEJBQTRCO0FBQ2xDLFNBQVMsZUFBZSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0NBQzVDLE1BQU0sRUFBRSxTQUFTLGtCQUFrQjtDQUNuQyxNQUFNLGdCQUFnQixlQUFlLGFBQWEsTUFBTSxDQUFDO0NBQ3pELE1BQU0sV0FBVyxXQUFXLEtBQUs7Q0FDakMsTUFBTSxVQUFVLGVBQWUsU0FBUyxLQUFLO0NBQzdDLE1BQU0sZ0JBQWdCLGlCQUFpQixPQUFPO0NBQzlDLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxPQUFPO0VBQ25DLE9BQU8sRUFBRSxRQUFRO0NBQ25CO0NBQ0EsTUFBTSxrQkFBa0IsRUFBRSxTQUFTLEtBQUs7Q0FDeEMsaUJBQWlCLGVBQWUsc0JBQXNCLFNBQVMsUUFBUSxNQUFNLGVBQWU7Q0FDNUYsaUJBQWlCLGVBQWUsdUJBQXVCO0VBQ3JELElBQUksSUFBSSxJQUFJO0VBQ1osT0FBTyxTQUFTLFNBQVMsTUFBTSxNQUFNLEtBQUssY0FBYyxVQUFVLE9BQU8sS0FBSyxJQUFJLEdBQUcsWUFBWSxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSx5QkFBeUIsTUFBTSxPQUFPLEtBQUs7Q0FDMUssR0FBRyxlQUFlO0NBQ2xCLE9BQU8sRUFBRSxRQUFRO0FBQ25COztBQUdBLFNBQVMsT0FBTyxTQUFTO0NBQ3ZCLElBQUk7Q0FDSixNQUFNLE1BQU0sV0FBVyxDQUFDO0NBQ3hCLElBQUksT0FBTyxnQkFBZ0IsYUFDekIsT0FBTztDQUNULE1BQU0sU0FBUyxLQUFLLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxVQUFVLE9BQU8sS0FBSztDQUM3RSxJQUFJLE9BQU8sWUFBWSxJQUFJO0NBQzNCLElBQUksUUFBUTtDQUNaLGVBQWU7RUFDYixTQUFTO0VBQ1QsSUFBSSxTQUFTLE9BQU87R0FDbEIsTUFBTSxNQUFNLFlBQVksSUFBSTtHQUM1QixNQUFNLE9BQU8sTUFBTTtHQUNuQixJQUFJLFFBQVEsS0FBSyxNQUFNLE9BQU8sT0FBTyxNQUFNO0dBQzNDLE9BQU87R0FDUCxRQUFRO0VBQ1Y7Q0FDRixDQUFDO0NBQ0QsT0FBTztBQUNUO0FBRUEsTUFBTSxnQkFBZ0I7Q0FDcEI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGO0FBQ0EsU0FBUyxjQUFjLFFBQVEsVUFBVSxDQUFDLEdBQUc7Q0FDM0MsTUFBTSxFQUNKLFdBQVcsaUJBQ1gsV0FBVyxVQUNUO0NBQ0osTUFBTSxZQUFZLGVBQWU7RUFDL0IsSUFBSTtFQUNKLFFBQVEsS0FBSyxhQUFhLE1BQU0sTUFBTSxPQUFPLEtBQUssWUFBWSxPQUFPLEtBQUssSUFBSSxTQUFTO0NBQ3pGLENBQUM7Q0FDRCxNQUFNLGVBQWUsV0FBVyxLQUFLO0NBQ3JDLE1BQU0sZ0JBQWdCLGVBQWU7RUFDbkMsT0FBTztHQUNMO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0YsQ0FBQyxDQUFDLE1BQU0sTUFBTSxZQUFZLEtBQUssWUFBWSxVQUFVLFNBQVMsS0FBSyxVQUFVLEtBQUs7Q0FDcEYsQ0FBQztDQUNELE1BQU0sYUFBYSxlQUFlO0VBQ2hDLE9BQU87R0FDTDtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRixDQUFDLENBQUMsTUFBTSxNQUFNLFlBQVksS0FBSyxZQUFZLFVBQVUsU0FBUyxLQUFLLFVBQVUsS0FBSztDQUNwRixDQUFDO0NBQ0QsTUFBTSxvQkFBb0IsZUFBZTtFQUN2QyxPQUFPO0dBQ0w7R0FDQTtHQUNBO0dBQ0E7R0FDQTtFQUNGLENBQUMsQ0FBQyxNQUFNLE1BQU0sWUFBWSxLQUFLLFlBQVksVUFBVSxTQUFTLEtBQUssVUFBVSxLQUFLO0NBQ3BGLENBQUM7Q0FDRCxNQUFNLDBCQUEwQjtFQUM5QjtFQUNBO0VBQ0E7RUFDQTtDQUNGLENBQUMsQ0FBQyxNQUFNLE1BQU0sWUFBWSxLQUFLLFFBQVE7Q0FDdkMsTUFBTSxjQUFjLG1CQUFtQixVQUFVLFNBQVMsWUFBWSxjQUFjLFVBQVUsS0FBSyxLQUFLLFdBQVcsVUFBVSxLQUFLLEtBQUssa0JBQWtCLFVBQVUsS0FBSyxDQUFDO0NBQ3pLLE1BQU0sbUNBQW1DO0VBQ3ZDLElBQUkseUJBQ0YsUUFBUSxZQUFZLE9BQU8sS0FBSyxJQUFJLFNBQVMsOEJBQThCLFVBQVU7RUFDdkYsT0FBTztDQUNUO0NBQ0EsTUFBTSw0QkFBNEI7RUFDaEMsSUFBSSxrQkFBa0IsT0FBTztHQUMzQixJQUFJLFlBQVksU0FBUyxrQkFBa0IsVUFBVSxNQUFNO0lBQ3pELE9BQU8sU0FBUyxrQkFBa0I7R0FDcEMsT0FBTztJQUNMLE1BQU0sVUFBVSxVQUFVO0lBQzFCLEtBQUssV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLGtCQUFrQixXQUFXLE1BQU07S0FDekUsT0FBTyxRQUFRLFFBQVEsa0JBQWtCLE1BQU07SUFDakQ7R0FDRjtFQUNGO0VBQ0EsT0FBTztDQUNUO0NBQ0EsZUFBZSxPQUFPO0VBQ3BCLElBQUksQ0FBQyxZQUFZLFNBQVMsQ0FBQyxhQUFhLE9BQ3RDO0VBQ0YsSUFBSSxXQUFXLE9BQU87R0FDcEIsS0FBSyxZQUFZLE9BQU8sS0FBSyxJQUFJLFNBQVMsV0FBVyxXQUFXLE1BQU07SUFDcEUsTUFBTSxTQUFTLFdBQVcsTUFBTSxDQUFDO0dBQ25DLE9BQU87SUFDTCxNQUFNLFVBQVUsVUFBVTtJQUMxQixLQUFLLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxXQUFXLFdBQVcsTUFDNUQsTUFBTSxRQUFRLFdBQVcsTUFBTSxDQUFDO0dBQ3BDO0VBQ0Y7RUFDQSxhQUFhLFFBQVE7Q0FDdkI7Q0FDQSxlQUFlLFFBQVE7RUFDckIsSUFBSSxDQUFDLFlBQVksU0FBUyxhQUFhLE9BQ3JDO0VBQ0YsSUFBSSxvQkFBb0IsR0FDdEIsTUFBTSxLQUFLO0VBQ2IsTUFBTSxVQUFVLFVBQVU7RUFDMUIsSUFBSSxjQUFjLFVBQVUsV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLGNBQWMsV0FBVyxNQUFNO0dBQzVGLE1BQU0sUUFBUSxjQUFjLE1BQU0sQ0FBQztHQUNuQyxhQUFhLFFBQVE7RUFDdkI7Q0FDRjtDQUNBLGVBQWUsU0FBUztFQUN0QixPQUFPLGFBQWEsUUFBUSxLQUFLLElBQUksTUFBTTtDQUM3QztDQUNBLE1BQU0sd0JBQXdCO0VBQzVCLE1BQU0sMkJBQTJCLG9CQUFvQjtFQUNyRCxJQUFJLENBQUMsNEJBQTRCLDRCQUE0QiwyQkFBMkIsR0FDdEYsYUFBYSxRQUFRO0NBQ3pCO0NBQ0EsTUFBTSxrQkFBa0I7RUFBRSxTQUFTO0VBQU8sU0FBUztDQUFLO0NBQ3hELGlCQUFpQixVQUFVLGVBQWUsaUJBQWlCLGVBQWU7Q0FDMUUsdUJBQXVCLGFBQWEsU0FBUyxHQUFHLGVBQWUsaUJBQWlCLGVBQWU7Q0FDL0YsYUFBYSxpQkFBaUIsS0FBSztDQUNuQyxJQUFJLFVBQ0Ysa0JBQWtCLElBQUk7Q0FDeEIsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsU0FBUyw4QkFBOEIsU0FBUztDQUM5QyxPQUFPLGVBQWU7RUFDcEIsSUFBSSxRQUFRLE9BQU87R0FDakIsT0FBTztJQUNMLFNBQVM7S0FDUCxHQUFHLFFBQVEsTUFBTSxRQUFRO0tBQ3pCLEdBQUcsUUFBUSxNQUFNLFFBQVE7S0FDekIsR0FBRyxRQUFRLE1BQU0sUUFBUTtLQUN6QixHQUFHLFFBQVEsTUFBTSxRQUFRO0lBQzNCO0lBQ0EsUUFBUTtLQUNOLE1BQU0sUUFBUSxNQUFNLFFBQVE7S0FDNUIsT0FBTyxRQUFRLE1BQU0sUUFBUTtJQUMvQjtJQUNBLFVBQVU7S0FDUixNQUFNLFFBQVEsTUFBTSxRQUFRO0tBQzVCLE9BQU8sUUFBUSxNQUFNLFFBQVE7SUFDL0I7SUFDQSxPQUFPO0tBQ0wsTUFBTTtNQUNKLFlBQVksUUFBUSxNQUFNLEtBQUs7TUFDL0IsVUFBVSxRQUFRLE1BQU0sS0FBSztNQUM3QixRQUFRLFFBQVEsTUFBTSxRQUFRO0tBQ2hDO0tBQ0EsT0FBTztNQUNMLFlBQVksUUFBUSxNQUFNLEtBQUs7TUFDL0IsVUFBVSxRQUFRLE1BQU0sS0FBSztNQUM3QixRQUFRLFFBQVEsTUFBTSxRQUFRO0tBQ2hDO0lBQ0Y7SUFDQSxNQUFNO0tBQ0osSUFBSSxRQUFRLE1BQU0sUUFBUTtLQUMxQixNQUFNLFFBQVEsTUFBTSxRQUFRO0tBQzVCLE1BQU0sUUFBUSxNQUFNLFFBQVE7S0FDNUIsT0FBTyxRQUFRLE1BQU0sUUFBUTtJQUMvQjtJQUNBLE1BQU0sUUFBUSxNQUFNLFFBQVE7SUFDNUIsT0FBTyxRQUFRLE1BQU0sUUFBUTtHQUMvQjtFQUNGO0VBQ0EsT0FBTztDQUNULENBQUM7QUFDSDs7QUFFQSxTQUFTLFdBQVcsVUFBVSxDQUFDLEdBQUc7Q0FDaEMsTUFBTSxFQUNKLFlBQVkscUJBQ1Y7Q0FDSixNQUFNLGNBQWMsbUJBQW1CLGFBQWEsaUJBQWlCLFNBQVM7Q0FDOUUsTUFBTSxXQUFXLElBQUksQ0FBQyxDQUFDO0NBQ3ZCLE1BQU0sa0JBQWtCLGdCQUFnQjtDQUN4QyxNQUFNLHFCQUFxQixnQkFBZ0I7Q0FDM0MsTUFBTSxvQkFBb0IsWUFBWTtFQUNwQyxNQUFNLGtCQUFrQixDQUFDO0VBQ3pCLE1BQU0sb0JBQW9CLHVCQUF1QixVQUFVLFFBQVEsb0JBQW9CO0VBQ3ZGLElBQUksbUJBQ0YsZ0JBQWdCLEtBQUssaUJBQWlCO0VBQ3hDLElBQUksUUFBUSxpQkFDVixnQkFBZ0IsS0FBSyxHQUFHLFFBQVEsZUFBZTtFQUNqRCxPQUFPO0dBQ0wsSUFBSSxRQUFRO0dBQ1osT0FBTyxRQUFRO0dBQ2YsV0FBVyxRQUFRO0dBQ25CLFNBQVMsUUFBUTtHQUNqQixXQUFXLFFBQVE7R0FDbkIsbUJBQW1CLFFBQVE7R0FDM0I7R0FDQSxNQUFNLFFBQVEsS0FBSyxLQUFLLFNBQVMsSUFBSTtHQUNyQyxTQUFTLFFBQVEsUUFBUSxLQUFLLFlBQVk7SUFBRSxTQUFTLE9BQU87SUFBUyxTQUFTLE9BQU87SUFBUyxPQUFPLE9BQU87R0FBTSxFQUFFO0VBQ3RIO0NBQ0Y7Q0FDQSxNQUFNLDJCQUEyQjtFQUMvQixNQUFNLGFBQWEsYUFBYSxPQUFPLEtBQUssSUFBSSxVQUFVLFlBQVksTUFBTSxDQUFDO0VBQzdFLEtBQUssTUFBTSxXQUFXLFdBQVc7R0FDL0IsSUFBSSxXQUFXLFNBQVMsTUFBTSxRQUFRLFFBQ3BDLFNBQVMsTUFBTSxRQUFRLFNBQVMsaUJBQWlCLE9BQU87RUFDNUQ7Q0FDRjtDQUNBLE1BQU0sRUFBRSxVQUFVLE9BQU8sV0FBVyxTQUFTLGtCQUFrQjtDQUMvRCxNQUFNLHNCQUFzQixZQUFZO0VBQ3RDLElBQUksQ0FBQyxTQUFTLE1BQU0sTUFBTSxFQUFFLFlBQVksVUFBVSxRQUFRLEtBQUssR0FBRztHQUNoRSxTQUFTLE1BQU0sS0FBSyxpQkFBaUIsT0FBTyxDQUFDO0dBQzdDLGdCQUFnQixRQUFRLFFBQVEsS0FBSztFQUN2QztFQUNBLE9BQU87Q0FDVDtDQUNBLE1BQU0seUJBQXlCLFlBQVk7RUFDekMsU0FBUyxRQUFRLFNBQVMsTUFBTSxRQUFRLE1BQU0sRUFBRSxVQUFVLFFBQVEsS0FBSztFQUN2RSxtQkFBbUIsUUFBUSxRQUFRLEtBQUs7Q0FDMUM7Q0FDQSxNQUFNLGtCQUFrQixFQUFFLFNBQVMsS0FBSztDQUN4QyxpQkFBaUIscUJBQXFCLE1BQU0sbUJBQW1CLEVBQUUsT0FBTyxHQUFHLGVBQWU7Q0FDMUYsaUJBQWlCLHdCQUF3QixNQUFNLHNCQUFzQixFQUFFLE9BQU8sR0FBRyxlQUFlO0NBQ2hHLG1CQUFtQjtFQUNqQixNQUFNLGFBQWEsYUFBYSxPQUFPLEtBQUssSUFBSSxVQUFVLFlBQVksTUFBTSxDQUFDO0VBQzdFLEtBQUssTUFBTSxXQUFXLFdBQVc7R0FDL0IsSUFBSSxXQUFXLFNBQVMsTUFBTSxRQUFRLFFBQ3BDLG1CQUFtQixPQUFPO0VBQzlCO0NBQ0YsQ0FBQztDQUNELE1BQU07Q0FDTixPQUFPO0VBQ0w7RUFDQSxhQUFhLGdCQUFnQjtFQUM3QixnQkFBZ0IsbUJBQW1CO0VBQ25DO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7QUFDRjtBQUVBLFNBQVMsZUFBZSxVQUFVLENBQUMsR0FBRztDQUNwQyxNQUFNLEVBQ0oscUJBQXFCLE1BQ3JCLGFBQWEsS0FDYixVQUFVLE1BQ1YsWUFBWSxrQkFDWixZQUFZLFNBQ1Y7Q0FDSixNQUFNLGNBQWMsbUJBQW1CLGFBQWEsaUJBQWlCLFNBQVM7Q0FDOUUsTUFBTSxZQUFZLFdBQVcsSUFBSTtDQUNqQyxNQUFNLFFBQVEsV0FBVyxJQUFJO0NBQzdCLE1BQU0sU0FBUyxJQUFJO0VBQ2pCLFVBQVU7RUFDVixVQUFVLE9BQU87RUFDakIsV0FBVyxPQUFPO0VBQ2xCLFVBQVU7RUFDVixrQkFBa0I7RUFDbEIsU0FBUztFQUNULE9BQU87Q0FDVCxDQUFDO0NBQ0QsU0FBUyxlQUFlLFVBQVU7RUFDaEMsVUFBVSxRQUFRLFNBQVM7RUFDM0IsT0FBTyxRQUFRLFNBQVM7RUFDeEIsTUFBTSxRQUFRO0NBQ2hCO0NBQ0EsSUFBSTtDQUNKLFNBQVMsU0FBUztFQUNoQixJQUFJLFlBQVksT0FBTztHQUNyQixVQUFVLFVBQVUsWUFBWSxjQUM5QixpQkFDQyxRQUFRLE1BQU0sUUFBUSxLQUN2QjtJQUNFO0lBQ0E7SUFDQTtHQUNGLENBQ0Y7RUFDRjtDQUNGO0NBQ0EsSUFBSSxXQUNGLE9BQU87Q0FDVCxTQUFTLFFBQVE7RUFDZixJQUFJLFdBQVcsV0FDYixVQUFVLFlBQVksV0FBVyxPQUFPO0NBQzVDO0NBQ0Esd0JBQXdCO0VBQ3RCLE1BQU07Q0FDUixDQUFDO0NBQ0QsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7QUFFQSxNQUFNLGtCQUFrQjtDQUFDO0NBQWE7Q0FBYTtDQUFVO0NBQVc7Q0FBYztBQUFPO0FBQzdGLE1BQU0sWUFBWTtBQUNsQixTQUFTLFFBQVEsVUFBVSxXQUFXLFVBQVUsQ0FBQyxHQUFHO0NBQ2xELE1BQU0sRUFDSixlQUFlLE9BQ2YsNEJBQTRCLE1BQzVCLFNBQVMsaUJBQ1QsU0FBUyxlQUNULGNBQWMsZUFBZSxFQUFFLE1BQzdCO0NBQ0osTUFBTSxPQUFPLFdBQVcsWUFBWTtDQUNwQyxNQUFNLGFBQWEsV0FBVyxVQUFVLENBQUM7Q0FDekMsSUFBSTtDQUNKLE1BQU0sY0FBYztFQUNsQixLQUFLLFFBQVE7RUFDYixhQUFhLEtBQUs7RUFDbEIsUUFBUSxpQkFBaUIsS0FBSyxRQUFRLE1BQU0sT0FBTztDQUNyRDtDQUNBLE1BQU0sVUFBVSxvQkFDZCxtQkFDTTtFQUNKLFdBQVcsUUFBUSxVQUFVO0VBQzdCLE1BQU07Q0FDUixDQUNGO0NBQ0EsSUFBSSxRQUFRO0VBQ1YsTUFBTSxXQUFXLE9BQU87RUFDeEIsTUFBTSxrQkFBa0IsRUFBRSxTQUFTLEtBQUs7RUFDeEMsS0FBSyxNQUFNLFNBQVMsUUFDbEIsaUJBQWlCLFFBQVEsT0FBTyxTQUFTLGVBQWU7RUFDMUQsSUFBSSwyQkFBMkI7R0FDN0IsaUJBQWlCLFVBQVUsMEJBQTBCO0lBQ25ELElBQUksQ0FBQyxTQUFTLFFBQ1osUUFBUTtHQUNaLEdBQUcsZUFBZTtFQUNwQjtFQUNBLElBQUksQ0FBQyxjQUNILE1BQU07Q0FDVjtDQUNBLE9BQU87RUFDTDtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsZUFBZSxVQUFVLFNBQVM7Q0FDaEMsT0FBTyxJQUFJLFNBQVMsU0FBUyxXQUFXO0VBQ3RDLE1BQU0sTUFBTSxJQUFJLE1BQU07RUFDdEIsTUFBTSxFQUFFLEtBQUssUUFBUSxPQUFPLE9BQU8sT0FBTyxTQUFTLGFBQWEsZ0JBQWdCLE9BQU8sUUFBUSxVQUFVLGVBQWUsT0FBTyxXQUFXO0VBQzFJLElBQUksTUFBTTtFQUNWLElBQUksVUFBVSxNQUNaLElBQUksU0FBUztFQUNmLElBQUksU0FBUyxNQUNYLElBQUksUUFBUTtFQUNkLElBQUksU0FBUyxNQUNYLElBQUksWUFBWTtFQUNsQixJQUFJLFdBQVcsTUFDYixJQUFJLFVBQVU7RUFDaEIsSUFBSSxlQUFlLE1BQ2pCLElBQUksY0FBYztFQUNwQixJQUFJLGtCQUFrQixNQUNwQixJQUFJLGlCQUFpQjtFQUN2QixJQUFJLFNBQVMsTUFDWCxJQUFJLFFBQVE7RUFDZCxJQUFJLFVBQVUsTUFDWixJQUFJLFNBQVM7RUFDZixJQUFJLFlBQVksTUFDZCxJQUFJLFdBQVc7RUFDakIsSUFBSSxpQkFBaUIsTUFDbkIsSUFBSSxnQkFBZ0I7RUFDdEIsSUFBSSxTQUFTLE1BQ1gsSUFBSSxRQUFRO0VBQ2QsSUFBSSxVQUFVLE1BQ1osSUFBSSxTQUFTO0VBQ2YsSUFBSSxlQUFlLFFBQVEsR0FBRztFQUM5QixJQUFJLFVBQVU7Q0FDaEIsQ0FBQztBQUNIO0FBQ0EsU0FBUyxTQUFTLFNBQVMsb0JBQW9CLENBQUMsR0FBRztDQUNqRCxNQUFNLFFBQVEsb0JBQ04sVUFBVSxRQUFRLE9BQU8sQ0FBQyxHQUNoQyxLQUFLLEdBQ0w7RUFDRSxnQkFBZ0I7RUFDaEIsR0FBRztDQUNMLENBQ0Y7Q0FDQSxZQUNRLFFBQVEsT0FBTyxTQUNmLE1BQU0sUUFBUSxrQkFBa0IsS0FBSyxHQUMzQyxFQUFFLE1BQU0sS0FBSyxDQUNmO0NBQ0EsT0FBTztBQUNUO0FBRUEsU0FBUyxlQUFlLElBQUk7Q0FDMUIsSUFBSSxPQUFPLFdBQVcsZUFBZSxjQUFjLFFBQ2pELE9BQU8sR0FBRyxTQUFTO0NBQ3JCLElBQUksT0FBTyxhQUFhLGVBQWUsY0FBYyxVQUNuRCxPQUFPLEdBQUc7Q0FDWixPQUFPO0FBQ1Q7QUFFQSxNQUFNLGlDQUFpQztBQUN2QyxTQUFTLFVBQVUsU0FBUyxVQUFVLENBQUMsR0FBRztDQUN4QyxNQUFNLEVBQ0osV0FBVyxHQUNYLE9BQU8sS0FDUCxTQUFTLE1BQ1QsV0FBVyxNQUNYLFNBQVM7RUFDUCxNQUFNO0VBQ04sT0FBTztFQUNQLEtBQUs7RUFDTCxRQUFRO0NBQ1YsR0FDQSxTQUFTLFdBQVcsRUFDbEIsVUFBVSxNQUNaLEdBQ0EsdUJBQXVCO0VBQ3JCLFNBQVM7RUFDVCxTQUFTO0NBQ1gsR0FDQSxXQUFXLFFBQ1gsU0FBUyxlQUNULFdBQVcsTUFBTTtFQUNmLFFBQVEsTUFBTSxDQUFDO0NBQ2pCLE1BQ0U7Q0FDSixNQUFNLFVBQVUsT0FBTyxhQUFhLFlBQVksRUFDOUMsVUFBVSxTQUNaLElBQUk7Q0FDSixNQUFNLFlBQVksV0FBVyxDQUFDO0NBQzlCLE1BQU0sWUFBWSxXQUFXLENBQUM7Q0FDOUIsTUFBTSxJQUFJLFNBQVM7RUFDakIsTUFBTTtHQUNKLE9BQU8sVUFBVTtFQUNuQjtFQUNBLElBQUksSUFBSTtHQUNOLFNBQVMsSUFBSSxLQUFLLENBQUM7RUFDckI7Q0FDRixDQUFDO0NBQ0QsTUFBTSxJQUFJLFNBQVM7RUFDakIsTUFBTTtHQUNKLE9BQU8sVUFBVTtFQUNuQjtFQUNBLElBQUksSUFBSTtHQUNOLFNBQVMsS0FBSyxHQUFHLEVBQUU7RUFDckI7Q0FDRixDQUFDO0NBQ0QsU0FBUyxTQUFTLElBQUksSUFBSTtFQUN4QixJQUFJLElBQUksSUFBSSxJQUFJO0VBQ2hCLElBQUksQ0FBQyxRQUNIO0VBQ0YsTUFBTSxXQUFXLFFBQVEsT0FBTztFQUNoQyxJQUFJLENBQUMsVUFDSDtFQUNGLENBQUMsS0FBSyxvQkFBb0IsV0FBVyxPQUFPLFNBQVMsT0FBTyxhQUFhLE9BQU8sS0FBSyxJQUFJLEdBQUcsU0FBUztHQUNuRyxNQUFNLEtBQUssUUFBUSxFQUFFLE1BQU0sT0FBTyxLQUFLLEVBQUU7R0FDekMsT0FBTyxLQUFLLFFBQVEsRUFBRSxNQUFNLE9BQU8sS0FBSyxFQUFFO0dBQzFDLFVBQVUsUUFBUSxRQUFRO0VBQzVCLENBQUM7RUFDRCxNQUFNLG9CQUFvQixLQUFLLFlBQVksT0FBTyxLQUFLLElBQUksU0FBUyxhQUFhLE9BQU8sS0FBSyxJQUFJLEdBQUcscUJBQXFCLFlBQVksT0FBTyxLQUFLLElBQUksU0FBUyxvQkFBb0I7RUFDbEwsSUFBSSxLQUFLLE1BQ1AsVUFBVSxRQUFRLGdCQUFnQjtFQUNwQyxJQUFJLEtBQUssTUFDUCxVQUFVLFFBQVEsZ0JBQWdCO0NBQ3RDO0NBQ0EsTUFBTSxjQUFjLFdBQVcsS0FBSztDQUNwQyxNQUFNLGVBQWUsU0FBUztFQUM1QixNQUFNO0VBQ04sT0FBTztFQUNQLEtBQUs7RUFDTCxRQUFRO0NBQ1YsQ0FBQztDQUNELE1BQU0sYUFBYSxTQUFTO0VBQzFCLE1BQU07RUFDTixPQUFPO0VBQ1AsS0FBSztFQUNMLFFBQVE7Q0FDVixDQUFDO0NBQ0QsTUFBTSxlQUFlLE1BQU07RUFDekIsSUFBSSxDQUFDLFlBQVksT0FDZjtFQUNGLFlBQVksUUFBUTtFQUNwQixXQUFXLE9BQU87RUFDbEIsV0FBVyxRQUFRO0VBQ25CLFdBQVcsTUFBTTtFQUNqQixXQUFXLFNBQVM7RUFDcEIsT0FBTyxDQUFDO0NBQ1Y7Q0FDQSxNQUFNLHVCQUF1QixjQUFjLGFBQWEsV0FBVyxJQUFJO0NBQ3ZFLE1BQU0sbUJBQW1CLFdBQVc7RUFDbEMsSUFBSTtFQUNKLElBQUksQ0FBQyxRQUNIO0VBQ0YsTUFBTSxPQUFPLEtBQUssVUFBVSxPQUFPLEtBQUssSUFBSSxPQUFPLGFBQWEsT0FBTyxLQUFLLElBQUksR0FBRyxxQkFBcUIsVUFBVSxPQUFPLEtBQUssSUFBSSxPQUFPLG9CQUFvQixhQUFhLE1BQU07RUFDaEwsTUFBTSxFQUFFLFNBQVMsZUFBZSxjQUFjLGlCQUFpQixFQUFFO0VBQ2pFLE1BQU0scUJBQXFCLGNBQWMsUUFBUSxDQUFDLElBQUk7RUFDdEQsTUFBTSxhQUFhLEdBQUc7RUFDdEIsV0FBVyxPQUFPLGFBQWEsVUFBVTtFQUN6QyxXQUFXLFFBQVEsYUFBYSxVQUFVO0VBQzFDLE1BQU0sT0FBTyxLQUFLLElBQUksYUFBYSxrQkFBa0IsTUFBTSxPQUFPLFFBQVE7RUFDMUUsTUFBTSxRQUFRLEtBQUssSUFBSSxhQUFhLGtCQUFrQixJQUFJLEdBQUcsZUFBZSxHQUFHLGVBQWUsT0FBTyxTQUFTLEtBQUs7RUFDbkgsSUFBSSxZQUFZLFVBQVUsa0JBQWtCLGVBQWU7R0FDekQsYUFBYSxPQUFPO0dBQ3BCLGFBQWEsUUFBUTtFQUN2QixPQUFPO0dBQ0wsYUFBYSxPQUFPO0dBQ3BCLGFBQWEsUUFBUTtFQUN2QjtFQUNBLFVBQVUsUUFBUTtFQUNsQixJQUFJLFlBQVksR0FBRztFQUNuQixJQUFJLFdBQVcsT0FBTyxZQUFZLENBQUMsV0FDakMsWUFBWSxPQUFPLFNBQVMsS0FBSztFQUNuQyxXQUFXLE1BQU0sWUFBWSxVQUFVO0VBQ3ZDLFdBQVcsU0FBUyxZQUFZLFVBQVU7RUFDMUMsTUFBTSxNQUFNLEtBQUssSUFBSSxTQUFTLE1BQU0sT0FBTyxPQUFPO0VBQ2xELE1BQU0sU0FBUyxLQUFLLElBQUksU0FBUyxJQUFJLEdBQUcsZ0JBQWdCLEdBQUcsZ0JBQWdCLE9BQU8sVUFBVSxLQUFLO0VBQ2pHLElBQUksWUFBWSxVQUFVLGtCQUFrQixrQkFBa0I7R0FDNUQsYUFBYSxNQUFNO0dBQ25CLGFBQWEsU0FBUztFQUN4QixPQUFPO0dBQ0wsYUFBYSxNQUFNO0dBQ25CLGFBQWEsU0FBUztFQUN4QjtFQUNBLFVBQVUsUUFBUTtDQUNwQjtDQUNBLE1BQU0sbUJBQW1CLE1BQU07RUFDN0IsSUFBSTtFQUNKLElBQUksQ0FBQyxRQUNIO0VBQ0YsTUFBTSxlQUFlLEtBQUssRUFBRSxPQUFPLG9CQUFvQixPQUFPLEtBQUssRUFBRTtFQUNyRSxnQkFBZ0IsV0FBVztFQUMzQixZQUFZLFFBQVE7RUFDcEIscUJBQXFCLENBQUM7RUFDdEIsU0FBUyxDQUFDO0NBQ1o7Q0FDQSxpQkFDRSxTQUNBLFVBQ0EsV0FBVyxjQUFjLGlCQUFpQixVQUFVLE1BQU0sS0FBSyxJQUFJLGlCQUNuRSxvQkFDRjtDQUNBLG1CQUFtQjtFQUNqQixJQUFJO0dBQ0YsTUFBTSxXQUFXLFFBQVEsT0FBTztHQUNoQyxJQUFJLENBQUMsVUFDSDtHQUNGLGdCQUFnQixRQUFRO0VBQzFCLFNBQVMsR0FBRztHQUNWLFFBQVEsQ0FBQztFQUNYO0NBQ0YsQ0FBQztDQUNELEtBQUssV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLGFBQWEsV0FBVyxRQUFRLFlBQVksVUFBVSxZQUFZLFVBQVU7RUFDbEgsb0JBQ0UsZUFDTTtHQUNKLE1BQU0sV0FBVyxRQUFRLE9BQU87R0FDaEMsSUFBSSxDQUFDLFVBQ0g7R0FDRixnQkFBZ0IsUUFBUTtFQUMxQixHQUNBO0dBQ0UsWUFBWTtHQUNaLFdBQVc7R0FDWCxTQUFTO0VBQ1gsQ0FDRjtDQUNGO0NBQ0EsaUJBQ0UsU0FDQSxhQUNBLGFBQ0Esb0JBQ0Y7Q0FDQSxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLFVBQVU7R0FDUixNQUFNLFdBQVcsUUFBUSxPQUFPO0dBQ2hDLElBQUksVUFBVSxVQUNaLGdCQUFnQixRQUFRO0VBQzVCO0NBQ0Y7QUFDRjtBQUVBLFNBQVMsa0JBQWtCLFNBQVMsWUFBWSxVQUFVLENBQUMsR0FBRztDQUM1RCxJQUFJO0NBQ0osTUFBTSxFQUNKLFlBQVksVUFDWixXQUFXLEtBQ1gsb0JBQW9CLFNBQ2xCO0NBQ0osTUFBTSxRQUFRLFNBQVMsVUFDckIsU0FDQTtFQUNFLEdBQUc7RUFDSCxRQUFRO0lBQ0wsYUFBYSxLQUFLLFFBQVEsYUFBYSxPQUFPLEtBQUs7R0FDcEQsR0FBRyxRQUFRO0VBQ2I7Q0FDRixDQUNGLENBQUM7Q0FDRCxNQUFNLFVBQVUsSUFBSTtDQUNwQixNQUFNLFlBQVksZUFBZSxDQUFDLENBQUMsUUFBUSxLQUFLO0NBQ2hELE1BQU0sa0JBQWtCLGVBQWU7RUFDckMsT0FBTyxlQUFlLFFBQVEsT0FBTyxDQUFDO0NBQ3hDLENBQUM7Q0FDRCxNQUFNLG1CQUFtQixxQkFBcUIsZUFBZTtDQUM3RCxTQUFTLGVBQWU7RUFDdEIsTUFBTSxRQUFRO0VBQ2QsSUFBSSxDQUFDLGdCQUFnQixTQUFTLENBQUMsaUJBQWlCLFNBQVMsQ0FBQyxZQUFZLGdCQUFnQixLQUFLLEdBQ3pGO0VBQ0YsTUFBTSxFQUFFLGNBQWMsY0FBYyxhQUFhLGdCQUFnQixnQkFBZ0I7RUFDakYsTUFBTSxhQUFhLGNBQWMsWUFBWSxjQUFjLFFBQVEsZ0JBQWdCLGVBQWUsZUFBZTtFQUNqSCxJQUFJLE1BQU0sYUFBYSxjQUFjLFlBQVk7R0FDL0MsSUFBSSxDQUFDLFFBQVEsT0FBTztJQUNsQixRQUFRLFFBQVEsUUFBUSxJQUFJLENBQzFCLFdBQVcsS0FBSyxHQUNoQixJQUFJLFNBQVMsWUFBWSxXQUFXLFNBQVMsUUFBUSxDQUFDLENBQ3hELENBQUMsQ0FBQyxDQUFDLGNBQWM7S0FDZixRQUFRLFFBQVE7S0FDaEIsZUFBZSxhQUFhLENBQUM7SUFDL0IsQ0FBQztHQUNIO0VBQ0Y7Q0FDRjtDQUNBLE1BQU0sT0FBTyxZQUNMLENBQUMsTUFBTSxhQUFhLFlBQVksaUJBQWlCLEtBQUssR0FDNUQsY0FDQSxFQUFFLFdBQVcsS0FBSyxDQUNwQjtDQUNBLGVBQWUsSUFBSTtDQUNuQixPQUFPO0VBQ0w7RUFDQSxRQUFRO0dBQ04sZUFBZSxhQUFhLENBQUM7RUFDL0I7Q0FDRjtBQUNGO0FBRUEsTUFBTSxnQkFBZ0I7Q0FBQztDQUFhO0NBQVc7Q0FBVztBQUFPOztBQUVqRSxTQUFTLGVBQWUsVUFBVSxVQUFVLENBQUMsR0FBRztDQUM5QyxNQUFNLEVBQ0osU0FBUyxlQUNULFdBQVcsaUJBQ1gsVUFBVSxTQUNSO0NBQ0osTUFBTSxRQUFRLFdBQVcsT0FBTztDQUNoQyxJQUFJLFVBQVU7RUFDWixPQUFPLFNBQVMsa0JBQWtCO0dBQ2hDLGlCQUFpQixVQUFVLGdCQUFnQixRQUFRO0lBQ2pELElBQUksT0FBTyxJQUFJLHFCQUFxQixZQUNsQyxNQUFNLFFBQVEsSUFBSSxpQkFBaUIsUUFBUTtHQUMvQyxHQUFHLEVBQUUsU0FBUyxLQUFLLENBQUM7RUFDdEIsQ0FBQztDQUNIO0NBQ0EsT0FBTztBQUNUO0FBRUEsU0FBUyxnQkFBZ0IsS0FBSyxjQUFjLFVBQVUsQ0FBQyxHQUFHO0NBQ3hELE1BQU0sRUFBRSxTQUFTLGtCQUFrQjtDQUNuQyxPQUFPLFdBQVcsS0FBSyxjQUFjLFVBQVUsT0FBTyxLQUFLLElBQUksT0FBTyxjQUFjLE9BQU87QUFDN0Y7QUFFQSxNQUFNLDJCQUEyQjtDQUMvQixNQUFNO0NBQ04sU0FBUztDQUNULEtBQUs7Q0FDTCxRQUFRO0NBQ1IsSUFBSTtDQUNKLE1BQU07Q0FDTixNQUFNO0NBQ04sT0FBTztBQUNUO0FBRUEsU0FBUyxhQUFhLFVBQVUsQ0FBQyxHQUFHO0NBQ2xDLE1BQU0sRUFDSixVQUFVLGNBQWMsT0FDeEIsU0FBUyxlQUNULFdBQVcsMEJBQ1gsVUFBVSxNQUNWLGVBQWUsU0FDYjtDQUNKLE1BQU0sVUFBVSx5QkFBeUIsSUFBSSxJQUFJLENBQUM7Q0FDbEQsTUFBTSxNQUFNO0VBQ1YsU0FBUztHQUNQLE9BQU8sQ0FBQztFQUNWO0VBQ0E7Q0FDRjtDQUNBLE1BQU0sT0FBTyxjQUFjLFNBQVMsR0FBRyxJQUFJO0NBQzNDLE1BQU0sMkJBQTJCLElBQUksSUFBSTtDQUN6QyxNQUFNLDRCQUE0QixJQUFJLElBQUk7Q0FDMUMsTUFBTSwyQkFBMkIsSUFBSSxJQUFJO0NBQ3pDLFNBQVMsUUFBUSxLQUFLLE9BQU87RUFDM0IsSUFBSSxPQUFPLE1BQU07R0FDZixJQUFJLGFBQ0YsS0FBSyxPQUFPO1FBRVosS0FBSyxJQUFJLENBQUMsUUFBUTtFQUN0QjtDQUNGO0NBQ0EsU0FBUyxRQUFRO0VBQ2YsUUFBUSxNQUFNO0VBQ2QsS0FBSyxNQUFNLE9BQU8sVUFDaEIsUUFBUSxLQUFLLEtBQUs7Q0FDdEI7Q0FDQSxTQUFTLFdBQVcsR0FBRyxPQUFPO0VBQzVCLElBQUksSUFBSTtFQUNSLE1BQU0sT0FBTyxLQUFLLEVBQUUsUUFBUSxPQUFPLEtBQUssSUFBSSxHQUFHLFlBQVk7RUFDM0QsTUFBTSxRQUFRLEtBQUssRUFBRSxTQUFTLE9BQU8sS0FBSyxJQUFJLEdBQUcsWUFBWTtFQUM3RCxNQUFNLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE9BQU8sT0FBTztFQUN6QyxJQUFJLEtBQUs7R0FDUCxJQUFJLE9BQ0YsUUFBUSxJQUFJLEdBQUc7UUFFZixRQUFRLE9BQU8sR0FBRztFQUN0QjtFQUNBLEtBQUssTUFBTSxRQUFRLFFBQVE7R0FDekIsU0FBUyxJQUFJLElBQUk7R0FDakIsUUFBUSxNQUFNLEtBQUs7RUFDckI7RUFDQSxJQUFJLFFBQVEsV0FBVyxDQUFDLE9BQU87R0FDN0IsTUFBTSxpQkFBaUIsTUFBTSxLQUFLLFNBQVM7R0FDM0MsTUFBTSxhQUFhLGVBQWUsUUFBUSxPQUFPO0dBQ2pELGVBQWUsU0FBUyxNQUFNLFVBQVU7SUFDdEMsSUFBSSxTQUFTLFlBQVk7S0FDdkIsUUFBUSxPQUFPLElBQUk7S0FDbkIsUUFBUSxNQUFNLEtBQUs7SUFDckI7R0FDRixDQUFDO0dBQ0QsVUFBVSxNQUFNO0VBQ2xCLE9BQU8sSUFBSSxPQUFPLEVBQUUscUJBQXFCLGNBQWMsRUFBRSxpQkFBaUIsT0FBTyxLQUFLLE9BQU87R0FDM0YsQ0FBQyxHQUFHLFNBQVMsR0FBRyxNQUFNLENBQUMsQ0FBQyxTQUFTLFNBQVMsVUFBVSxJQUFJLElBQUksQ0FBQztFQUMvRDtFQUNBLElBQUksUUFBUSxVQUFVLENBQUMsT0FBTztHQUM1QixTQUFTLFNBQVMsU0FBUztJQUN6QixRQUFRLE9BQU8sSUFBSTtJQUNuQixRQUFRLE1BQU0sS0FBSztHQUNyQixDQUFDO0dBQ0QsU0FBUyxNQUFNO0VBQ2pCLE9BQU8sSUFBSSxPQUFPLEVBQUUscUJBQXFCLGNBQWMsRUFBRSxpQkFBaUIsTUFBTSxLQUFLLE9BQU87R0FDMUYsQ0FBQyxHQUFHLFNBQVMsR0FBRyxNQUFNLENBQUMsQ0FBQyxTQUFTLFNBQVMsU0FBUyxJQUFJLElBQUksQ0FBQztFQUM5RDtDQUNGO0NBQ0EsaUJBQWlCLFFBQVEsWUFBWSxNQUFNO0VBQ3pDLFdBQVcsR0FBRyxJQUFJO0VBQ2xCLE9BQU8sYUFBYSxDQUFDO0NBQ3ZCLEdBQUcsRUFBRSxRQUFRLENBQUM7Q0FDZCxpQkFBaUIsUUFBUSxVQUFVLE1BQU07RUFDdkMsV0FBVyxHQUFHLEtBQUs7RUFDbkIsT0FBTyxhQUFhLENBQUM7Q0FDdkIsR0FBRyxFQUFFLFFBQVEsQ0FBQztDQUNkLGlCQUFpQixRQUFRLE9BQU8sRUFBRSxRQUFRLENBQUM7Q0FDM0MsaUJBQWlCLFNBQVMsT0FBTyxFQUFFLFFBQVEsQ0FBQztDQUM1QyxNQUFNLFFBQVEsSUFBSSxNQUNoQixNQUNBLEVBQ0UsSUFBSSxTQUFTLE1BQU0sS0FBSztFQUN0QixJQUFJLE9BQU8sU0FBUyxVQUNsQixPQUFPLFFBQVEsSUFBSSxTQUFTLE1BQU0sR0FBRztFQUN2QyxPQUFPLEtBQUssWUFBWTtFQUN4QixJQUFJLFFBQVEsVUFDVixPQUFPLFNBQVM7RUFDbEIsSUFBSSxFQUFFLFFBQVEsT0FBTztHQUNuQixJQUFJLFFBQVEsS0FBSyxJQUFJLEdBQUc7SUFDdEIsTUFBTSxPQUFPLEtBQUssTUFBTSxRQUFRLENBQUMsQ0FBQyxLQUFLLE1BQU0sRUFBRSxLQUFLLENBQUM7SUFDckQsS0FBSyxRQUFRLGVBQWUsS0FBSyxLQUFLLFFBQVEsUUFBUSxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxPQUFPLENBQUM7R0FDbkYsT0FBTztJQUNMLEtBQUssUUFBUSxXQUFXLEtBQUs7R0FDL0I7RUFDRjtFQUNBLE1BQU0sSUFBSSxRQUFRLElBQUksU0FBUyxNQUFNLEdBQUc7RUFDeEMsT0FBTyxjQUFjLFFBQVEsQ0FBQyxJQUFJO0NBQ3BDLEVBQ0YsQ0FDRjtDQUNBLE9BQU87QUFDVDtBQUVBLFNBQVMsV0FBVyxRQUFRLElBQUk7Q0FDOUIsSUFBSSxRQUFRLE1BQU0sR0FDaEIsR0FBRyxRQUFRLE1BQU0sQ0FBQztBQUN0QjtBQUNBLFNBQVMsaUJBQWlCLFlBQVk7Q0FDcEMsSUFBSSxTQUFTLENBQUM7Q0FDZCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksV0FBVyxRQUFRLEVBQUUsR0FDdkMsU0FBUyxDQUFDLEdBQUcsUUFBUSxDQUFDLFdBQVcsTUFBTSxDQUFDLEdBQUcsV0FBVyxJQUFJLENBQUMsQ0FBQyxDQUFDO0NBQy9ELE9BQU87QUFDVDtBQUNBLFNBQVMsY0FBYyxRQUFRO0NBQzdCLE9BQU8sTUFBTSxLQUFLLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxPQUFPLE1BQU0sVUFBVSxNQUFNLFlBQVksTUFBTSxtQ0FBbUMsUUFBUTtFQUFFO0VBQUk7RUFBTztFQUFNO0VBQVU7RUFBTTtFQUFZO0VBQU07Q0FBZ0MsRUFBRTtBQUNwTjtBQUNBLE1BQU0saUJBQWlCO0NBQ3JCLEtBQUs7Q0FDTCxRQUFRLENBQUM7QUFDWDtBQUNBLFNBQVMsaUJBQWlCLFFBQVEsVUFBVSxDQUFDLEdBQUc7Q0FDOUMsU0FBUyxNQUFNLE1BQU07Q0FDckIsVUFBVTtFQUNSLEdBQUc7RUFDSCxHQUFHO0NBQ0w7Q0FDQSxNQUFNLEVBQ0osV0FBVyxvQkFDVDtDQUNKLE1BQU0sa0JBQWtCLEVBQUUsU0FBUyxLQUFLO0NBQ3hDLE1BQU0sY0FBYyxXQUFXLENBQUM7Q0FDaEMsTUFBTSxXQUFXLFdBQVcsQ0FBQztDQUM3QixNQUFNLFVBQVUsV0FBVyxLQUFLO0NBQ2hDLE1BQU0sU0FBUyxXQUFXLENBQUM7Q0FDM0IsTUFBTSxVQUFVLFdBQVcsS0FBSztDQUNoQyxNQUFNLFFBQVEsV0FBVyxLQUFLO0NBQzlCLE1BQU0sVUFBVSxXQUFXLEtBQUs7Q0FDaEMsTUFBTSxPQUFPLFdBQVcsQ0FBQztDQUN6QixNQUFNLFVBQVUsV0FBVyxLQUFLO0NBQ2hDLE1BQU0sV0FBVyxJQUFJLENBQUMsQ0FBQztDQUN2QixNQUFNLFNBQVMsSUFBSSxDQUFDLENBQUM7Q0FDckIsTUFBTSxnQkFBZ0IsV0FBVyxDQUFDLENBQUM7Q0FDbkMsTUFBTSxxQkFBcUIsV0FBVyxLQUFLO0NBQzNDLE1BQU0sUUFBUSxXQUFXLEtBQUs7Q0FDOUIsTUFBTSwyQkFBMkIsWUFBWSw2QkFBNkI7Q0FDMUUsTUFBTSxtQkFBbUIsZ0JBQWdCO0NBQ3pDLE1BQU0scUJBQXFCLGdCQUFnQjtDQUMzQyxNQUFNLGdCQUFnQixVQUFVO0VBQzlCLFdBQVcsU0FBUyxPQUFPO0dBQ3pCLElBQUksT0FBTztJQUNULE1BQU0sS0FBSyxPQUFPLFVBQVUsV0FBVyxRQUFRLE1BQU07SUFDckQsR0FBRyxXQUFXLEdBQUcsQ0FBQyxPQUFPO0dBQzNCLE9BQU87SUFDTCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxXQUFXLFFBQVEsRUFBRSxHQUMxQyxHQUFHLFdBQVcsRUFBRSxDQUFDLE9BQU87R0FDNUI7R0FDQSxjQUFjLFFBQVEsQ0FBQztFQUN6QixDQUFDO0NBQ0g7Q0FDQSxNQUFNLGVBQWUsT0FBTyxnQkFBZ0IsU0FBUztFQUNuRCxXQUFXLFNBQVMsT0FBTztHQUN6QixNQUFNLEtBQUssT0FBTyxVQUFVLFdBQVcsUUFBUSxNQUFNO0dBQ3JELElBQUksZUFDRixhQUFhO0dBQ2YsR0FBRyxXQUFXLEdBQUcsQ0FBQyxPQUFPO0dBQ3pCLGNBQWMsUUFBUTtFQUN4QixDQUFDO0NBQ0g7Q0FDQSxNQUFNLCtCQUErQjtFQUNuQyxPQUFPLElBQUksU0FBUyxTQUFTLFdBQVc7R0FDdEMsV0FBVyxRQUFRLE9BQU8sT0FBTztJQUMvQixJQUFJLDBCQUEwQjtLQUM1QixJQUFJLENBQUMsbUJBQW1CLE9BQU87TUFDN0IsR0FBRyx3QkFBd0IsQ0FBQyxDQUFDLEtBQUssT0FBTyxDQUFDLENBQUMsTUFBTSxNQUFNO0tBQ3pELE9BQU87TUFDTCxTQUFTLHFCQUFxQixDQUFDLENBQUMsS0FBSyxPQUFPLENBQUMsQ0FBQyxNQUFNLE1BQU07S0FDNUQ7SUFDRjtHQUNGLENBQUM7RUFDSCxDQUFDO0NBQ0g7Q0FDQSxrQkFBa0I7RUFDaEIsSUFBSSxDQUFDLFVBQ0g7RUFDRixNQUFNLEtBQUssUUFBUSxNQUFNO0VBQ3pCLElBQUksQ0FBQyxJQUNIO0VBQ0YsTUFBTSxNQUFNLFFBQVEsUUFBUSxHQUFHO0VBQy9CLElBQUksVUFBVSxDQUFDO0VBQ2YsSUFBSSxDQUFDLEtBQ0g7RUFDRixJQUFJLE9BQU8sUUFBUSxVQUNqQixVQUFVLENBQUMsRUFBRSxJQUFJLENBQUM7T0FDZixJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQ3hCLFVBQVU7T0FDUCxJQUFJLFNBQVMsR0FBRyxHQUNuQixVQUFVLENBQUMsR0FBRztFQUNoQixHQUFHLGlCQUFpQixRQUFRLENBQUMsQ0FBQyxTQUFTLE1BQU07R0FDM0MsRUFBRSxPQUFPO0VBQ1gsQ0FBQztFQUNELFFBQVEsU0FBUyxFQUFFLEtBQUssTUFBTSxNQUFNLFlBQVk7R0FDOUMsTUFBTSxTQUFTLFNBQVMsY0FBYyxRQUFRO0dBQzlDLE9BQU8sYUFBYSxPQUFPLElBQUk7R0FDL0IsT0FBTyxhQUFhLFFBQVEsUUFBUSxFQUFFO0dBQ3RDLE9BQU8sYUFBYSxTQUFTLFNBQVMsRUFBRTtHQUN4QyxpQkFBaUIsUUFBUSxTQUFTLGlCQUFpQixTQUFTLGVBQWU7R0FDM0UsR0FBRyxZQUFZLE1BQU07RUFDdkIsQ0FBQztFQUNELEdBQUcsS0FBSztDQUNWLENBQUM7Q0FDRCxNQUFNLENBQUMsUUFBUSxNQUFNLFNBQVM7RUFDNUIsTUFBTSxLQUFLLFFBQVEsTUFBTTtFQUN6QixJQUFJLENBQUMsSUFDSDtFQUNGLEdBQUcsU0FBUyxPQUFPO0NBQ3JCLENBQUM7Q0FDRCxNQUFNLENBQUMsUUFBUSxLQUFLLFNBQVM7RUFDM0IsTUFBTSxLQUFLLFFBQVEsTUFBTTtFQUN6QixJQUFJLENBQUMsSUFDSDtFQUNGLEdBQUcsUUFBUSxNQUFNO0NBQ25CLENBQUM7Q0FDRCxNQUFNLENBQUMsUUFBUSxJQUFJLFNBQVM7RUFDMUIsTUFBTSxLQUFLLFFBQVEsTUFBTTtFQUN6QixJQUFJLENBQUMsSUFDSDtFQUNGLEdBQUcsZUFBZSxLQUFLO0NBQ3pCLENBQUM7Q0FDRCxrQkFBa0I7RUFDaEIsSUFBSSxDQUFDLFVBQ0g7RUFDRixNQUFNLGFBQWEsUUFBUSxRQUFRLE1BQU07RUFDekMsTUFBTSxLQUFLLFFBQVEsTUFBTTtFQUN6QixJQUFJLENBQUMsY0FBYyxDQUFDLFdBQVcsVUFBVSxDQUFDLElBQ3hDO0VBQ0YsR0FBRyxpQkFBaUIsT0FBTyxDQUFDLENBQUMsU0FBUyxNQUFNLEVBQUUsT0FBTyxDQUFDO0VBQ3RELFdBQVcsU0FBUyxFQUFFLFNBQVMsV0FBVyxNQUFNLE9BQU8sS0FBSyxXQUFXLE1BQU07R0FDM0UsTUFBTSxRQUFRLFNBQVMsY0FBYyxPQUFPO0dBQzVDLE1BQU0sVUFBVSxhQUFhO0dBQzdCLE1BQU0sT0FBTztHQUNiLE1BQU0sUUFBUTtHQUNkLE1BQU0sTUFBTTtHQUNaLE1BQU0sVUFBVTtHQUNoQixJQUFJLE1BQU0sU0FDUixjQUFjLFFBQVE7R0FDeEIsR0FBRyxZQUFZLEtBQUs7RUFDdEIsQ0FBQztDQUNILENBQUM7Q0FDRCxNQUFNLEVBQUUsZUFBZSw2QkFBNkIsZUFBZSxjQUFjLFNBQVM7RUFDeEYsTUFBTSxLQUFLLFFBQVEsTUFBTTtFQUN6QixJQUFJLENBQUMsSUFDSDtFQUNGLEdBQUcsY0FBYztDQUNuQixDQUFDO0NBQ0QsTUFBTSxFQUFFLGVBQWUseUJBQXlCLGVBQWUsVUFBVSxjQUFjO0VBQ3JGLE1BQU0sS0FBSyxRQUFRLE1BQU07RUFDekIsSUFBSSxDQUFDLElBQ0g7RUFDRixJQUFJLFdBQVc7R0FDYixHQUFHLEtBQUssQ0FBQyxDQUFDLE9BQU8sTUFBTTtJQUNyQixtQkFBbUIsUUFBUSxDQUFDO0lBQzVCLE1BQU07R0FDUixDQUFDO0VBQ0gsT0FBTztHQUNMLEdBQUcsTUFBTTtFQUNYO0NBQ0YsQ0FBQztDQUNELGlCQUNFLFFBQ0Esb0JBQ00sK0JBQStCLFlBQVksUUFBUSxRQUFRLE1BQU0sQ0FBQyxDQUFDLFdBQVcsR0FDcEYsZUFDRjtDQUNBLGlCQUNFLFFBQ0Esd0JBQ00sU0FBUyxRQUFRLFFBQVEsTUFBTSxDQUFDLENBQUMsVUFDdkMsZUFDRjtDQUNBLGlCQUNFLFFBQ0Esa0JBQ00sU0FBUyxRQUFRLGlCQUFpQixRQUFRLE1BQU0sQ0FBQyxDQUFDLFFBQVEsR0FDaEUsZUFDRjtDQUNBLGlCQUNFLFFBQ0EsaUJBQ00sUUFBUSxRQUFRLE1BQ3RCLGVBQ0Y7Q0FDQSxpQkFDRSxRQUNBLGdCQUNNLFFBQVEsUUFBUSxPQUN0QixlQUNGO0NBQ0EsaUJBQ0UsUUFDQSxDQUFDLFdBQVcsV0FBVyxTQUNqQjtFQUNKLFFBQVEsUUFBUTtFQUNoQiwyQkFBMkIsUUFBUSxRQUFRLEtBQUs7Q0FDbEQsR0FDQSxlQUNGO0NBQ0EsaUJBQ0UsUUFDQSxvQkFDTSxRQUFRLFFBQVEsT0FDdEIsZUFDRjtDQUNBLGlCQUNFLFFBQ0EsaUJBQ007RUFDSixRQUFRLFFBQVE7RUFDaEIsTUFBTSxRQUFRO0VBQ2QsMkJBQTJCLFFBQVEsUUFBUSxJQUFJO0NBQ2pELEdBQ0EsZUFDRjtDQUNBLGlCQUNFLFFBQ0Esb0JBQ00sS0FBSyxRQUFRLFFBQVEsTUFBTSxDQUFDLENBQUMsY0FDbkMsZUFDRjtDQUNBLGlCQUNFLFFBQ0EsaUJBQ00sUUFBUSxRQUFRLE1BQ3RCLGVBQ0Y7Q0FDQSxpQkFDRSxRQUNBLGVBQ00sTUFBTSxRQUFRLE1BQ3BCLGVBQ0Y7Q0FDQSxpQkFDRSxRQUNBLGVBQ00sMkJBQTJCLFFBQVEsUUFBUSxLQUFLLEdBQ3RELGVBQ0Y7Q0FDQSxpQkFDRSxRQUNBLGNBQ00sMkJBQTJCLFFBQVEsUUFBUSxJQUFJLEdBQ3JELGVBQ0Y7Q0FDQSxpQkFDRSxRQUNBLCtCQUNNLG1CQUFtQixRQUFRLE1BQ2pDLGVBQ0Y7Q0FDQSxpQkFDRSxRQUNBLCtCQUNNLG1CQUFtQixRQUFRLE9BQ2pDLGVBQ0Y7Q0FDQSxpQkFDRSxRQUNBLHNCQUNNO0VBQ0osTUFBTSxLQUFLLFFBQVEsTUFBTTtFQUN6QixJQUFJLENBQUMsSUFDSDtFQUNGLE9BQU8sUUFBUSxHQUFHO0VBQ2xCLE1BQU0sUUFBUSxHQUFHO0NBQ25CLEdBQ0EsZUFDRjtDQUNBLE1BQU0sWUFBWSxDQUFDO0NBQ25CLE1BQU0sT0FBTyxNQUFNLENBQUMsTUFBTSxTQUFTO0VBQ2pDLE1BQU0sS0FBSyxRQUFRLE1BQU07RUFDekIsSUFBSSxDQUFDLElBQ0g7RUFDRixLQUFLO0VBQ0wsVUFBVSxLQUFLLGlCQUFpQixHQUFHLFlBQVksa0JBQWtCLE9BQU8sUUFBUSxjQUFjLEdBQUcsVUFBVSxHQUFHLGVBQWU7RUFDN0gsVUFBVSxLQUFLLGlCQUFpQixHQUFHLFlBQVkscUJBQXFCLE9BQU8sUUFBUSxjQUFjLEdBQUcsVUFBVSxHQUFHLGVBQWU7RUFDaEksVUFBVSxLQUFLLGlCQUFpQixHQUFHLFlBQVksZ0JBQWdCLE9BQU8sUUFBUSxjQUFjLEdBQUcsVUFBVSxHQUFHLGVBQWU7Q0FDN0gsQ0FBQztDQUNELHdCQUF3QixVQUFVLFNBQVMsYUFBYSxTQUFTLENBQUMsQ0FBQztDQUNuRSxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBOztFQUVBO0VBQ0E7O0VBRUE7RUFDQTtFQUNBO0VBQ0E7O0VBRUE7RUFDQTtFQUNBOztFQUVBLGVBQWUsaUJBQWlCO0VBQ2hDLGlCQUFpQixtQkFBbUI7Q0FDdEM7QUFDRjs7QUFHQSxTQUFTLFdBQVcsVUFBVSxTQUFTO0NBQ3JDLE1BQU0sa0JBQWtCO0VBQ3RCLElBQUksV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLE9BQ3JDLE9BQU8sZ0JBQWdCLFFBQVEsS0FBSztFQUN0QyxPQUFPLGdDQUFnQyxJQUFJLElBQUksQ0FBQztDQUNsRDtDQUNBLE1BQU0sUUFBUSxVQUFVO0NBQ3hCLE1BQU0sZUFBZSxHQUFHLFVBQVUsV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLFVBQVUsUUFBUSxPQUFPLEdBQUcsSUFBSSxJQUFJLEtBQUssVUFBVSxJQUFJO0NBQzVILE1BQU0sYUFBYSxLQUFLLEdBQUcsU0FBUztFQUNsQyxNQUFNLElBQUksS0FBSyxTQUFTLEdBQUcsSUFBSSxDQUFDO0VBQ2hDLE9BQU8sTUFBTSxJQUFJLEdBQUc7Q0FDdEI7Q0FDQSxNQUFNLFlBQVksR0FBRyxTQUFTLFVBQVUsWUFBWSxHQUFHLElBQUksR0FBRyxHQUFHLElBQUk7Q0FDckUsTUFBTSxjQUFjLEdBQUcsU0FBUztFQUM5QixNQUFNLE9BQU8sWUFBWSxHQUFHLElBQUksQ0FBQztDQUNuQztDQUNBLE1BQU0sa0JBQWtCO0VBQ3RCLE1BQU0sTUFBTTtDQUNkO0NBQ0EsTUFBTSxZQUFZLEdBQUcsU0FBUztFQUM1QixNQUFNLE1BQU0sWUFBWSxHQUFHLElBQUk7RUFDL0IsSUFBSSxNQUFNLElBQUksR0FBRyxHQUNmLE9BQU8sTUFBTSxJQUFJLEdBQUc7RUFDdEIsT0FBTyxVQUFVLEtBQUssR0FBRyxJQUFJO0NBQy9CO0NBQ0EsU0FBUyxPQUFPO0NBQ2hCLFNBQVMsU0FBUztDQUNsQixTQUFTLFFBQVE7Q0FDakIsU0FBUyxjQUFjO0NBQ3ZCLFNBQVMsUUFBUTtDQUNqQixPQUFPO0FBQ1Q7O0FBR0EsU0FBUyxVQUFVLFVBQVUsQ0FBQyxHQUFHO0NBQy9CLE1BQU0sU0FBUyxJQUFJO0NBQ25CLE1BQU0sY0FBYyxtQkFBbUIsT0FBTyxnQkFBZ0IsZUFBZSxZQUFZLFdBQVc7Q0FDcEcsSUFBSSxZQUFZLE9BQU87RUFDckIsTUFBTSxFQUFFLFdBQVcsUUFBUTtFQUMzQixvQkFBb0I7R0FDbEIsT0FBTyxRQUFRLFlBQVk7RUFDN0IsR0FBRyxVQUFVO0dBQUUsV0FBVyxRQUFRO0dBQVcsbUJBQW1CLFFBQVE7RUFBa0IsQ0FBQztDQUM3RjtDQUNBLE9BQU87RUFBRTtFQUFhO0NBQU87QUFDL0I7QUFFQSxNQUFNLDRCQUE0QjtDQUNoQyxPQUFPLFVBQVUsQ0FBQyxNQUFNLE9BQU8sTUFBTSxLQUFLO0NBQzFDLFNBQVMsVUFBVSxDQUFDLE1BQU0sU0FBUyxNQUFNLE9BQU87Q0FDaEQsU0FBUyxVQUFVLENBQUMsTUFBTSxTQUFTLE1BQU0sT0FBTztDQUNoRCxXQUFXLFVBQVUsaUJBQWlCLGFBQWEsQ0FBQyxNQUFNLFdBQVcsTUFBTSxTQUFTLElBQUk7QUFDMUY7QUFDQSxTQUFTLFNBQVMsVUFBVSxDQUFDLEdBQUc7Q0FDOUIsTUFBTSxFQUNKLE9BQU8sUUFDUCxRQUFRLE1BQ1IsbUJBQW1CLE9BQ25CLGVBQWU7RUFBRSxHQUFHO0VBQUcsR0FBRztDQUFFLEdBQzVCLFNBQVMsZUFDVCxTQUFTLFFBQ1QsU0FBUyxNQUNULGdCQUNFO0NBQ0osSUFBSSxrQkFBa0I7Q0FDdEIsSUFBSSxlQUFlO0NBQ25CLElBQUksZUFBZTtDQUNuQixNQUFNLElBQUksV0FBVyxhQUFhLENBQUM7Q0FDbkMsTUFBTSxJQUFJLFdBQVcsYUFBYSxDQUFDO0NBQ25DLE1BQU0sYUFBYSxXQUFXLElBQUk7Q0FDbEMsTUFBTSxZQUFZLE9BQU8sU0FBUyxhQUFhLE9BQU8sMEJBQTBCO0NBQ2hGLE1BQU0sZ0JBQWdCLFVBQVU7RUFDOUIsTUFBTSxTQUFTLFVBQVUsS0FBSztFQUM5QixrQkFBa0I7RUFDbEIsSUFBSSxRQUFRO0dBQ1YsQ0FBQyxFQUFFLE9BQU8sRUFBRSxTQUFTO0dBQ3JCLFdBQVcsUUFBUTtFQUNyQjtFQUNBLElBQUksUUFBUTtHQUNWLGVBQWUsT0FBTztHQUN0QixlQUFlLE9BQU87RUFDeEI7Q0FDRjtDQUNBLE1BQU0sZ0JBQWdCLFVBQVU7RUFDOUIsSUFBSSxNQUFNLFFBQVEsU0FBUyxHQUFHO0dBQzVCLE1BQU0sU0FBUyxVQUFVLE1BQU0sUUFBUSxFQUFFO0dBQ3pDLElBQUksUUFBUTtJQUNWLENBQUMsRUFBRSxPQUFPLEVBQUUsU0FBUztJQUNyQixXQUFXLFFBQVE7R0FDckI7RUFDRjtDQUNGO0NBQ0EsTUFBTSxzQkFBc0I7RUFDMUIsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQ3ZCO0VBQ0YsTUFBTSxNQUFNLFVBQVUsZUFBZTtFQUNyQyxJQUFJLDJCQUEyQixjQUFjLEtBQUs7R0FDaEQsRUFBRSxRQUFRLElBQUksS0FBSyxPQUFPLFVBQVU7R0FDcEMsRUFBRSxRQUFRLElBQUksS0FBSyxPQUFPLFVBQVU7RUFDdEM7Q0FDRjtDQUNBLE1BQU0sY0FBYztFQUNsQixFQUFFLFFBQVEsYUFBYTtFQUN2QixFQUFFLFFBQVEsYUFBYTtDQUN6QjtDQUNBLE1BQU0sc0JBQXNCLGVBQWUsVUFBVSxrQkFBa0IsYUFBYSxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUssVUFBVSxhQUFhLEtBQUs7Q0FDL0gsTUFBTSxzQkFBc0IsZUFBZSxVQUFVLGtCQUFrQixhQUFhLEtBQUssR0FBRyxDQUFDLENBQUMsS0FBSyxVQUFVLGFBQWEsS0FBSztDQUMvSCxNQUFNLHVCQUF1QixvQkFBb0Isa0JBQWtCLGNBQWMsR0FBRyxDQUFDLENBQUMsVUFBVSxjQUFjO0NBQzlHLElBQUksUUFBUTtFQUNWLE1BQU0sa0JBQWtCLEVBQUUsU0FBUyxLQUFLO0VBQ3hDLGlCQUFpQixRQUFRLENBQUMsYUFBYSxVQUFVLEdBQUcscUJBQXFCLGVBQWU7RUFDeEYsSUFBSSxTQUFTLFNBQVMsWUFBWTtHQUNoQyxpQkFBaUIsUUFBUSxDQUFDLGNBQWMsV0FBVyxHQUFHLHFCQUFxQixlQUFlO0dBQzFGLElBQUksa0JBQ0YsaUJBQWlCLFFBQVEsWUFBWSxPQUFPLGVBQWU7RUFDL0Q7RUFDQSxJQUFJLFVBQVUsU0FBUyxRQUNyQixpQkFBaUIsUUFBUSxVQUFVLHNCQUFzQixlQUFlO0NBQzVFO0NBQ0EsT0FBTztFQUNMO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7QUFFQSxTQUFTLGtCQUFrQixRQUFRLFVBQVUsQ0FBQyxHQUFHO0NBQy9DLE1BQU0sRUFDSixlQUFlLE1BQ2YsZUFBZSxNQUNmLGdCQUFnQixNQUNoQixTQUFTLGtCQUNQO0NBQ0osTUFBTSxPQUFPLFFBQVEsUUFBUTtDQUM3QixNQUFNLEVBQUUsR0FBRyxHQUFHLGVBQWUsU0FBUyxPQUFPO0NBQzdDLE1BQU0sWUFBWSxXQUFXLFVBQVUsT0FBTyxTQUFTLFVBQVUsT0FBTyxLQUFLLElBQUksT0FBTyxTQUFTLElBQUk7Q0FDckcsTUFBTSxXQUFXLFdBQVcsQ0FBQztDQUM3QixNQUFNLFdBQVcsV0FBVyxDQUFDO0NBQzdCLE1BQU0sbUJBQW1CLFdBQVcsQ0FBQztDQUNyQyxNQUFNLG1CQUFtQixXQUFXLENBQUM7Q0FDckMsTUFBTSxnQkFBZ0IsV0FBVyxDQUFDO0NBQ2xDLE1BQU0sZUFBZSxXQUFXLENBQUM7Q0FDakMsTUFBTSxZQUFZLFdBQVcsSUFBSTtDQUNqQyxTQUFTLFNBQVM7RUFDaEIsSUFBSSxDQUFDLFFBQ0g7RUFDRixNQUFNLEtBQUssYUFBYSxTQUFTO0VBQ2pDLElBQUksQ0FBQyxNQUFNLEVBQUUsY0FBYyxVQUN6QjtFQUNGLE1BQU0sRUFDSixNQUNBLEtBQ0EsT0FDQSxXQUNFLEdBQUcsc0JBQXNCO0VBQzdCLGlCQUFpQixRQUFRLFFBQVEsU0FBUyxTQUFTLE9BQU8sY0FBYztFQUN4RSxpQkFBaUIsUUFBUSxPQUFPLFNBQVMsU0FBUyxPQUFPLGNBQWM7RUFDdkUsY0FBYyxRQUFRO0VBQ3RCLGFBQWEsUUFBUTtFQUNyQixNQUFNLE1BQU0sRUFBRSxRQUFRLGlCQUFpQjtFQUN2QyxNQUFNLE1BQU0sRUFBRSxRQUFRLGlCQUFpQjtFQUN2QyxVQUFVLFFBQVEsVUFBVSxLQUFLLFdBQVcsS0FBSyxNQUFNLEtBQUssTUFBTSxLQUFLLE1BQU0sU0FBUyxNQUFNO0VBQzVGLElBQUksaUJBQWlCLENBQUMsVUFBVSxPQUFPO0dBQ3JDLFNBQVMsUUFBUTtHQUNqQixTQUFTLFFBQVE7RUFDbkI7Q0FDRjtDQUNBLE1BQU0sYUFBYSxDQUFDO0NBQ3BCLFNBQVMsT0FBTztFQUNkLFdBQVcsU0FBUyxPQUFPLEdBQUcsQ0FBQztFQUMvQixXQUFXLFNBQVM7Q0FDdEI7Q0FDQSxtQkFBbUI7RUFDakIsT0FBTztDQUNULENBQUM7Q0FDRCxJQUFJLFFBQVE7RUFDVixNQUFNLEVBQ0osTUFBTSx1QkFDSixrQkFBa0IsV0FBVyxNQUFNO0VBQ3ZDLE1BQU0sRUFDSixNQUFNLHlCQUNKLG9CQUFvQixXQUFXLFFBQVEsRUFDekMsaUJBQWlCLENBQUMsU0FBUyxPQUFPLEVBQ3BDLENBQUM7RUFDRCxNQUFNLFlBQVksTUFDaEI7R0FBQztHQUFXO0dBQUc7RUFBQyxHQUNoQixNQUNGO0VBQ0EsV0FBVyxLQUNULG9CQUNBLHNCQUNBLFNBQ0Y7RUFDQSxpQkFDRSxVQUNBLG9CQUNNLFVBQVUsUUFBUSxNQUN4QixFQUFFLFNBQVMsS0FBSyxDQUNsQjtFQUNBLElBQUksY0FBYztHQUNoQixXQUFXLEtBQ1QsaUJBQWlCLFVBQVUsUUFBUTtJQUFFLFNBQVM7SUFBTSxTQUFTO0dBQUssQ0FBQyxDQUNyRTtFQUNGO0VBQ0EsSUFBSSxjQUFjO0dBQ2hCLFdBQVcsS0FDVCxpQkFBaUIsVUFBVSxRQUFRLEVBQUUsU0FBUyxLQUFLLENBQUMsQ0FDdEQ7RUFDRjtDQUNGO0NBQ0EsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsU0FBUyxnQkFBZ0IsVUFBVSxDQUFDLEdBQUc7Q0FDckMsTUFBTSxFQUNKLFFBQVEsTUFDUixPQUFPLE1BQ1AsVUFBVSxPQUNWLGVBQWUsT0FDZixTQUFTLGtCQUNQO0NBQ0osTUFBTSxVQUFVLFdBQVcsWUFBWTtDQUN2QyxNQUFNLGFBQWEsV0FBVyxJQUFJO0NBQ2xDLElBQUksQ0FBQyxRQUFRO0VBQ1gsT0FBTztHQUNMO0dBQ0E7RUFDRjtDQUNGO0NBQ0EsTUFBTSxhQUFhLGFBQWEsVUFBVTtFQUN4QyxJQUFJO0VBQ0osUUFBUSxRQUFRO0VBQ2hCLFdBQVcsUUFBUTtFQUNuQixDQUFDLEtBQUssUUFBUSxjQUFjLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxTQUFTLEtBQUs7Q0FDcEU7Q0FDQSxNQUFNLGNBQWMsVUFBVTtFQUM1QixJQUFJO0VBQ0osUUFBUSxRQUFRO0VBQ2hCLFdBQVcsUUFBUTtFQUNuQixDQUFDLEtBQUssUUFBUSxlQUFlLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxTQUFTLEtBQUs7Q0FDckU7Q0FDQSxNQUFNLFNBQVMsZUFBZSxhQUFhLFFBQVEsTUFBTSxLQUFLLE1BQU07Q0FDcEUsTUFBTSxrQkFBa0I7RUFBRSxTQUFTO0VBQU07Q0FBUTtDQUNqRCxpQkFBaUIsUUFBUSxhQUFhLFVBQVUsT0FBTyxHQUFHLGVBQWU7Q0FDekUsaUJBQWlCLFFBQVEsY0FBYyxZQUFZLGVBQWU7Q0FDbEUsaUJBQWlCLFFBQVEsV0FBVyxZQUFZLGVBQWU7Q0FDL0QsSUFBSSxNQUFNO0VBQ1IsaUJBQWlCLFFBQVEsYUFBYSxVQUFVLE9BQU8sR0FBRyxlQUFlO0VBQ3pFLGlCQUFpQixRQUFRLFFBQVEsWUFBWSxlQUFlO0VBQzVELGlCQUFpQixRQUFRLFdBQVcsWUFBWSxlQUFlO0NBQ2pFO0NBQ0EsSUFBSSxPQUFPO0VBQ1QsaUJBQWlCLFFBQVEsY0FBYyxVQUFVLE9BQU8sR0FBRyxlQUFlO0VBQzFFLGlCQUFpQixRQUFRLFlBQVksWUFBWSxlQUFlO0VBQ2hFLGlCQUFpQixRQUFRLGVBQWUsWUFBWSxlQUFlO0NBQ3JFO0NBQ0EsT0FBTztFQUNMO0VBQ0E7Q0FDRjtBQUNGOztBQUdBLFNBQVMscUJBQXFCLFVBQVUsQ0FBQyxHQUFHO0NBQzFDLE1BQU0sRUFBRSxTQUFTLGtCQUFrQjtDQUNuQyxNQUFNLFlBQVksVUFBVSxPQUFPLEtBQUssSUFBSSxPQUFPO0NBQ25ELE1BQU0sY0FBYyxtQkFBbUIsYUFBYSxjQUFjLFNBQVM7Q0FDM0UsTUFBTSxXQUFXLFdBQVcsYUFBYSxPQUFPLEtBQUssSUFBSSxVQUFVLFFBQVE7Q0FDM0UsaUJBQWlCLFFBQVEsd0JBQXdCO0VBQy9DLElBQUksV0FDRixTQUFTLFFBQVEsVUFBVTtDQUMvQixHQUFHLEVBQUUsU0FBUyxLQUFLLENBQUM7Q0FDcEIsT0FBTztFQUNMO0VBQ0E7Q0FDRjtBQUNGOztBQUdBLFNBQVMsV0FBVyxVQUFVLENBQUMsR0FBRztDQUNoQyxNQUFNLEVBQUUsU0FBUyxrQkFBa0I7Q0FDbkMsTUFBTSxZQUFZLFVBQVUsT0FBTyxLQUFLLElBQUksT0FBTztDQUNuRCxNQUFNLGNBQWMsbUJBQW1CLGFBQWEsZ0JBQWdCLFNBQVM7Q0FDN0UsTUFBTSxXQUFXLFdBQVcsSUFBSTtDQUNoQyxNQUFNLFdBQVcsV0FBVyxLQUFLO0NBQ2pDLE1BQU0sWUFBWSxXQUFXLEtBQUssQ0FBQztDQUNuQyxNQUFNLFdBQVcsV0FBVyxLQUFLLENBQUM7Q0FDbEMsTUFBTSxXQUFXLFdBQVcsS0FBSyxDQUFDO0NBQ2xDLE1BQU0sY0FBYyxXQUFXLEtBQUssQ0FBQztDQUNyQyxNQUFNLE1BQU0sV0FBVyxLQUFLLENBQUM7Q0FDN0IsTUFBTSxnQkFBZ0IsV0FBVyxLQUFLLENBQUM7Q0FDdkMsTUFBTSxPQUFPLFdBQVcsU0FBUztDQUNqQyxNQUFNLGFBQWEsWUFBWSxTQUFTLFVBQVU7Q0FDbEQsU0FBUywyQkFBMkI7RUFDbEMsSUFBSSxDQUFDLFdBQ0g7RUFDRixTQUFTLFFBQVEsVUFBVTtFQUMzQixVQUFVLFFBQVEsU0FBUyxRQUFRLEtBQUssSUFBSSxLQUFLLElBQUk7RUFDckQsU0FBUyxRQUFRLFNBQVMsUUFBUSxLQUFLLElBQUksSUFBSSxLQUFLO0VBQ3BELElBQUksWUFBWTtHQUNkLFNBQVMsUUFBUSxXQUFXO0dBQzVCLFlBQVksUUFBUSxXQUFXO0dBQy9CLGNBQWMsUUFBUSxXQUFXO0dBQ2pDLElBQUksUUFBUSxXQUFXO0dBQ3ZCLFNBQVMsUUFBUSxXQUFXO0dBQzVCLEtBQUssUUFBUSxXQUFXO0VBQzFCO0NBQ0Y7Q0FDQSxNQUFNLGtCQUFrQixFQUFFLFNBQVMsS0FBSztDQUN4QyxJQUFJLFFBQVE7RUFDVixpQkFBaUIsUUFBUSxpQkFBaUI7R0FDeEMsU0FBUyxRQUFRO0dBQ2pCLFVBQVUsUUFBUSxLQUFLLElBQUk7RUFDN0IsR0FBRyxlQUFlO0VBQ2xCLGlCQUFpQixRQUFRLGdCQUFnQjtHQUN2QyxTQUFTLFFBQVE7R0FDakIsU0FBUyxRQUFRLEtBQUssSUFBSTtFQUM1QixHQUFHLGVBQWU7Q0FDcEI7Q0FDQSxJQUFJLFlBQ0YsaUJBQWlCLFlBQVksVUFBVSwwQkFBMEIsZUFBZTtDQUNsRix5QkFBeUI7Q0FDekIsT0FBTztFQUNMO0VBQ0EsVUFBVSxTQUFTLFFBQVE7RUFDM0IsVUFBVSxTQUFTLFFBQVE7RUFDM0IsV0FBVyxTQUFTLFNBQVM7RUFDN0IsVUFBVSxTQUFTLFFBQVE7RUFDM0IsVUFBVSxTQUFTLFFBQVE7RUFDM0IsYUFBYSxTQUFTLFdBQVc7RUFDakMsZUFBZSxTQUFTLGFBQWE7RUFDckMsS0FBSyxTQUFTLEdBQUc7RUFDakIsTUFBTSxTQUFTLElBQUk7Q0FDckI7QUFDRjs7QUFHQSxTQUFTLE9BQU8sVUFBVSxDQUFDLEdBQUc7Q0FDNUIsTUFBTSxFQUNKLFVBQVUsaUJBQWlCLE9BQzNCLFdBQVcseUJBQ1gsWUFBWSxTQUNWO0NBQ0osTUFBTSxNQUFNLG9CQUFvQixJQUFJLEtBQUssQ0FBQztDQUMxQyxNQUFNLGVBQWUsSUFBSSx3QkFBd0IsSUFBSSxLQUFLO0NBQzFELE1BQU0sV0FBVyxhQUFhLDBCQUEwQixTQUFTLFFBQVEsRUFBRSxVQUFVLENBQUMsSUFBSSxjQUFjLFFBQVEsVUFBVSxFQUFFLFVBQVUsQ0FBQztDQUN2SSxJQUFJLGdCQUFnQjtFQUNsQixPQUFPO0dBQ0w7R0FDQSxHQUFHO0VBQ0w7Q0FDRixPQUFPO0VBQ0wsT0FBTztDQUNUO0FBQ0Y7QUFFQSxTQUFTLGFBQWEsUUFBUTtDQUM1QixNQUFNLE1BQU0sV0FBVztDQUN2QixNQUFNLGdCQUFnQjtFQUNwQixJQUFJLElBQUksT0FDTixJQUFJLGdCQUFnQixJQUFJLEtBQUs7RUFDL0IsSUFBSSxRQUFRLEtBQUs7Q0FDbkI7Q0FDQSxZQUNRLFFBQVEsTUFBTSxJQUNuQixjQUFjO0VBQ2IsUUFBUTtFQUNSLElBQUksV0FDRixJQUFJLFFBQVEsSUFBSSxnQkFBZ0IsU0FBUztDQUM3QyxHQUNBLEVBQUUsV0FBVyxLQUFLLENBQ3BCO0NBQ0Esa0JBQWtCLE9BQU87Q0FDekIsT0FBTyxTQUFTLEdBQUc7QUFDckI7O0FBR0EsU0FBUyxTQUFTLE9BQU8sS0FBSyxLQUFLO0NBQ2pDLElBQUksT0FBTyxVQUFVLGNBQWMsV0FBVyxLQUFLLEdBQ2pELE9BQU8sZUFBZSxNQUFNLFFBQVEsS0FBSyxHQUFHLFFBQVEsR0FBRyxHQUFHLFFBQVEsR0FBRyxDQUFDLENBQUM7Q0FDekUsTUFBTSxTQUFTLElBQUksS0FBSztDQUN4QixPQUFPLFNBQVM7RUFDZCxNQUFNO0dBQ0osT0FBTyxPQUFPLFFBQVEsTUFBTSxPQUFPLE9BQU8sUUFBUSxHQUFHLEdBQUcsUUFBUSxHQUFHLENBQUM7RUFDdEU7RUFDQSxJQUFJLFFBQVE7R0FDVixPQUFPLFFBQVEsTUFBTSxRQUFRLFFBQVEsR0FBRyxHQUFHLFFBQVEsR0FBRyxDQUFDO0VBQ3pEO0NBQ0YsQ0FBQztBQUNIO0FBRUEsU0FBUyxvQkFBb0IsU0FBUztDQUNwQyxNQUFNLEVBQ0osUUFBUSxPQUFPLG1CQUNmLFdBQVcsSUFDWCxPQUFPLEdBQ1AsZUFBZSxNQUNmLG1CQUFtQixNQUNuQixvQkFBb0IsU0FDbEI7Q0FDSixNQUFNLGtCQUFrQixTQUFTLFVBQVUsR0FBRyxPQUFPLGlCQUFpQjtDQUN0RSxNQUFNLFlBQVksZUFBZSxLQUFLLElBQ3BDLEdBQ0EsS0FBSyxLQUFLLFFBQVEsS0FBSyxJQUFJLFFBQVEsZUFBZSxDQUFDLENBQ3JELENBQUM7Q0FDRCxNQUFNLGNBQWMsU0FBUyxNQUFNLEdBQUcsU0FBUztDQUMvQyxNQUFNLGNBQWMsZUFBZSxZQUFZLFVBQVUsQ0FBQztDQUMxRCxNQUFNLGFBQWEsZUFBZSxZQUFZLFVBQVUsVUFBVSxLQUFLO0NBQ3ZFLElBQUksTUFBTSxJQUFJLEdBQUc7RUFDZixRQUFRLE1BQU0sYUFBYSxFQUN6QixXQUFXLFdBQVcsSUFBSSxJQUFJLFFBQVEsT0FDeEMsQ0FBQztDQUNIO0NBQ0EsSUFBSSxNQUFNLFFBQVEsR0FBRztFQUNuQixRQUFRLFVBQVUsaUJBQWlCLEVBQ2pDLFdBQVcsV0FBVyxRQUFRLElBQUksUUFBUSxPQUM1QyxDQUFDO0NBQ0g7Q0FDQSxTQUFTLE9BQU87RUFDZCxZQUFZO0NBQ2Q7Q0FDQSxTQUFTLE9BQU87RUFDZCxZQUFZO0NBQ2Q7Q0FDQSxNQUFNLGNBQWM7RUFDbEI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtDQUNBLE1BQU0sbUJBQW1CO0VBQ3ZCLGFBQWEsU0FBUyxXQUFXLENBQUM7Q0FDcEMsQ0FBQztDQUNELE1BQU0sdUJBQXVCO0VBQzNCLGlCQUFpQixTQUFTLFdBQVcsQ0FBQztDQUN4QyxDQUFDO0NBQ0QsTUFBTSxpQkFBaUI7RUFDckIsa0JBQWtCLFNBQVMsV0FBVyxDQUFDO0NBQ3pDLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7O0FBR0EsU0FBUyxVQUFVLFVBQVUsQ0FBQyxHQUFHO0NBQy9CLE1BQU0sRUFBRSxhQUFhLFdBQVcsT0FBTztDQUN2QyxPQUFPO0FBQ1Q7O0FBR0EsU0FBUyxhQUFhLFVBQVUsQ0FBQyxHQUFHO0NBQ2xDLE1BQU0sRUFBRSxTQUFTLGtCQUFrQjtDQUNuQyxNQUFNLFNBQVMsV0FBVyxLQUFLO0NBQy9CLE1BQU0sV0FBVyxVQUFVO0VBQ3pCLElBQUksQ0FBQyxRQUNIO0VBQ0YsUUFBUSxTQUFTLE9BQU87RUFDeEIsTUFBTSxPQUFPLE1BQU0saUJBQWlCLE1BQU07RUFDMUMsT0FBTyxRQUFRLENBQUM7Q0FDbEI7Q0FDQSxJQUFJLFFBQVE7RUFDVixNQUFNLGtCQUFrQixFQUFFLFNBQVMsS0FBSztFQUN4QyxpQkFBaUIsUUFBUSxZQUFZLFNBQVMsZUFBZTtFQUM3RCxpQkFBaUIsT0FBTyxVQUFVLGNBQWMsU0FBUyxlQUFlO0VBQ3hFLGlCQUFpQixPQUFPLFVBQVUsY0FBYyxTQUFTLGVBQWU7Q0FDMUU7Q0FDQSxPQUFPO0FBQ1Q7O0FBR0EsU0FBUyxxQkFBcUIsVUFBVSxDQUFDLEdBQUc7Q0FDMUMsTUFBTSxFQUNKLFNBQVMsa0JBQ1A7Q0FDSixNQUFNLGNBQWMsbUJBQW1CLFVBQVUsWUFBWSxVQUFVLGlCQUFpQixPQUFPLE1BQU07Q0FDckcsTUFBTSxvQkFBb0IsWUFBWSxRQUFRLE9BQU8sT0FBTyxjQUFjLENBQUM7Q0FDM0UsTUFBTSxjQUFjLElBQUksa0JBQWtCLElBQUk7Q0FDOUMsTUFBTSxRQUFRLFdBQVcsa0JBQWtCLFNBQVMsQ0FBQztDQUNyRCxJQUFJLFlBQVksT0FBTztFQUNyQixpQkFBaUIsUUFBUSwyQkFBMkI7R0FDbEQsWUFBWSxRQUFRLGtCQUFrQjtHQUN0QyxNQUFNLFFBQVEsa0JBQWtCO0VBQ2xDLEdBQUcsRUFBRSxTQUFTLEtBQUssQ0FBQztDQUN0QjtDQUNBLE1BQU0sbUJBQW1CLFNBQVM7RUFDaEMsSUFBSSxZQUFZLFNBQVMsT0FBTyxrQkFBa0IsU0FBUyxZQUN6RCxPQUFPLGtCQUFrQixLQUFLLElBQUk7RUFDcEMsT0FBTyxRQUFRLE9BQU8sSUFBSSxNQUFNLGVBQWUsQ0FBQztDQUNsRDtDQUNBLE1BQU0sMEJBQTBCO0VBQzlCLElBQUksWUFBWSxTQUFTLE9BQU8sa0JBQWtCLFdBQVcsWUFDM0Qsa0JBQWtCLE9BQU87Q0FDN0I7Q0FDQSxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7QUFFQSxTQUFTLFlBQVksUUFBUSxVQUFVLENBQUMsR0FBRztDQUN6QyxNQUFNLEVBQ0osK0JBQStCLE1BQU0sR0FDckMsK0JBQStCLE1BQU0sR0FDckMsbUJBQW1CLE1BQU0sR0FDekIsbUJBQW1CLE1BQU0sR0FDekIsU0FBUyxrQkFDUDtDQUNKLE1BQU0sY0FBYyxTQUFTLHFCQUFxQixFQUFFLE9BQU8sQ0FBQyxDQUFDO0NBQzdELE1BQU0sb0JBQW9CLFNBQVMscUJBQXFCLEVBQUUsT0FBTyxDQUFDLENBQUM7Q0FDbkUsTUFBTSxFQUNKLFVBQVUsR0FDVixVQUFVLEdBQ1YsY0FBYyxPQUNkLGVBQWUsV0FDYixrQkFBa0IsUUFBUTtFQUFFLGVBQWU7RUFBTztDQUFPLENBQUM7Q0FDOUQsTUFBTSxTQUFTLGVBQWU7RUFDNUIsSUFBSSxZQUFZLGdCQUFnQixZQUFZLFNBQVMsUUFBUSxZQUFZLFVBQVUsS0FBSyxZQUFZLFNBQVMsUUFBUSxZQUFZLFVBQVUsSUFBSTtHQUM3SSxPQUFPO0VBQ1Q7RUFDQSxPQUFPO0NBQ1QsQ0FBQztDQUNELE1BQU0sT0FBTyxlQUFlO0VBQzFCLElBQUksT0FBTyxVQUFVLHFCQUFxQjtHQUN4QyxJQUFJO0dBQ0osUUFBUSxrQkFBa0IsYUFBMUI7SUFDRSxLQUFLO0tBQ0gsUUFBUSxZQUFZLFFBQVE7S0FDNUI7SUFDRixLQUFLO0tBQ0gsUUFBUSxDQUFDLFlBQVksUUFBUTtLQUM3QjtJQUNGLEtBQUs7S0FDSCxRQUFRLENBQUMsWUFBWSxPQUFPO0tBQzVCO0lBQ0YsS0FBSztLQUNILFFBQVEsWUFBWSxPQUFPO0tBQzNCO0lBQ0YsU0FDRSxRQUFRLENBQUMsWUFBWSxPQUFPO0dBQ2hDO0dBQ0EsT0FBTyw0QkFBNEIsS0FBSztFQUMxQyxPQUFPO0dBQ0wsTUFBTSxRQUFRLEVBQUUsRUFBRSxRQUFRLE9BQU8sUUFBUSxLQUFLLE9BQU87R0FDckQsT0FBTyxnQkFBZ0IsS0FBSztFQUM5QjtDQUNGLENBQUM7Q0FDRCxNQUFNLE9BQU8sZUFBZTtFQUMxQixJQUFJLE9BQU8sVUFBVSxxQkFBcUI7R0FDeEMsSUFBSTtHQUNKLFFBQVEsa0JBQWtCLGFBQTFCO0lBQ0UsS0FBSztLQUNILFFBQVEsWUFBWSxPQUFPO0tBQzNCO0lBQ0YsS0FBSztLQUNILFFBQVEsQ0FBQyxZQUFZLE9BQU87S0FDNUI7SUFDRixLQUFLO0tBQ0gsUUFBUSxZQUFZLFFBQVE7S0FDNUI7SUFDRixLQUFLO0tBQ0gsUUFBUSxDQUFDLFlBQVksUUFBUTtLQUM3QjtJQUNGLFNBQ0UsUUFBUSxZQUFZLFFBQVE7R0FDaEM7R0FDQSxPQUFPLDRCQUE0QixLQUFLO0VBQzFDLE9BQU87R0FDTCxNQUFNLFNBQVMsRUFBRSxRQUFRLE1BQU0sUUFBUSxLQUFLLE1BQU07R0FDbEQsT0FBTyxnQkFBZ0IsS0FBSztFQUM5QjtDQUNGLENBQUM7Q0FDRCxPQUFPO0VBQUU7RUFBTTtFQUFNO0NBQU87QUFDOUI7QUFFQSxTQUFTLGlCQUFpQixVQUFVLGtCQUFrQixHQUFHO0NBQ3ZELE1BQU0sZ0JBQWdCLFdBQVc7Q0FDakMsTUFBTSxlQUFlO0VBQ25CLE1BQU0sS0FBSyxhQUFhLE9BQU87RUFDL0IsSUFBSSxJQUNGLGNBQWMsUUFBUSxHQUFHO0NBQzdCO0NBQ0EsYUFBYSxNQUFNO0NBQ25CLFlBQVksUUFBUSxPQUFPLEdBQUcsTUFBTTtDQUNwQyxPQUFPO0FBQ1Q7QUFFQSxTQUFTLHVCQUF1QixTQUFTLFVBQVU7Q0FDakQsTUFBTSxFQUNKLFNBQVMsZUFDVCxZQUFZLE1BQ1osR0FBRyx1QkFDRDtDQUNKLE1BQU0sY0FBYyxtQkFBbUIsVUFBVSx5QkFBeUIsTUFBTTtDQUNoRixJQUFJO0NBQ0osTUFBTSxhQUFhO0VBQ2pCLFlBQVksT0FBTyxLQUFLLElBQUksU0FBUyxXQUFXO0NBQ2xEO0NBQ0EsTUFBTSxjQUFjO0VBQ2xCLElBQUksWUFBWSxPQUFPO0dBQ3JCLEtBQUs7R0FDTCxXQUFXLElBQUksb0JBQW9CLFFBQVE7R0FDM0MsU0FBUyxRQUFRLGtCQUFrQjtFQUNyQztDQUNGO0NBQ0Esa0JBQWtCLElBQUk7Q0FDdEIsSUFBSSxXQUNGLE1BQU07Q0FDUixPQUFPO0VBQ0w7RUFDQTtFQUNBO0NBQ0Y7QUFDRjtBQUVBLE1BQU0sZUFBZTtDQUNuQixHQUFHO0NBQ0gsR0FBRztDQUNILFdBQVc7Q0FDWCxVQUFVO0NBQ1YsT0FBTztDQUNQLE9BQU87Q0FDUCxPQUFPO0NBQ1AsUUFBUTtDQUNSLE9BQU87Q0FDUCxhQUFhO0FBQ2Y7QUFDQSxNQUFNLE9BQXVCLHVCQUFPLEtBQUssWUFBWTtBQUNyRCxTQUFTLFdBQVcsVUFBVSxDQUFDLEdBQUc7Q0FDaEMsTUFBTSxFQUNKLFNBQVMsa0JBQ1A7Q0FDSixNQUFNLFdBQVcsV0FBVyxLQUFLO0NBQ2pDLE1BQU0sUUFBUSxXQUFXLFFBQVEsZ0JBQWdCLENBQUMsQ0FBQztDQUNuRCxPQUFPLE9BQU8sTUFBTSxPQUFPLGNBQWMsTUFBTSxLQUFLO0NBQ3BELE1BQU0sV0FBVyxVQUFVO0VBQ3pCLFNBQVMsUUFBUTtFQUNqQixJQUFJLFFBQVEsZ0JBQWdCLENBQUMsUUFBUSxhQUFhLFNBQVMsTUFBTSxXQUFXLEdBQzFFO0VBQ0YsTUFBTSxRQUFRLFdBQVcsT0FBTyxNQUFNLEtBQUs7Q0FDN0M7Q0FDQSxJQUFJLFFBQVE7RUFDVixNQUFNLGtCQUFrQixFQUFFLFNBQVMsS0FBSztFQUN4QyxpQkFBaUIsUUFBUTtHQUFDO0dBQWU7R0FBZTtFQUFXLEdBQUcsU0FBUyxlQUFlO0VBQzlGLGlCQUFpQixRQUFRLHNCQUFzQixTQUFTLFFBQVEsT0FBTyxlQUFlO0NBQ3hGO0NBQ0EsT0FBTztFQUNMLEdBQUcsT0FBTyxLQUFLO0VBQ2Y7Q0FDRjtBQUNGOztBQUdBLFNBQVMsZUFBZSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0NBQzVDLE1BQU0sRUFBRSxXQUFXLG9CQUFvQjtDQUN2QyxNQUFNLGNBQWMsbUJBQW1CLFlBQVksd0JBQXdCLFFBQVE7Q0FDbkYsTUFBTSxVQUFVLFdBQVc7Q0FDM0IsTUFBTSxpQkFBaUIsV0FBVztDQUNsQyxJQUFJO0NBQ0osSUFBSSxZQUFZLE9BQU87RUFDckIsTUFBTSxrQkFBa0IsRUFBRSxTQUFTLEtBQUs7RUFDeEMsaUJBQWlCLFVBQVUsMkJBQTJCO0dBQ3BELElBQUk7R0FDSixNQUFNLGtCQUFrQixLQUFLLFNBQVMsdUJBQXVCLE9BQU8sS0FBSyxRQUFRO0dBQ2pGLElBQUksaUJBQWlCLG1CQUFtQixlQUFlO0lBQ3JELFFBQVEsUUFBUSxTQUFTO0lBQ3pCLElBQUksQ0FBQyxRQUFRLE9BQ1gsZ0JBQWdCLGVBQWUsUUFBUTtHQUMzQztFQUNGLEdBQUcsZUFBZTtFQUNsQixpQkFBaUIsVUFBVSwwQkFBMEI7R0FDbkQsSUFBSTtHQUNKLE1BQU0sa0JBQWtCLEtBQUssU0FBUyx1QkFBdUIsT0FBTyxLQUFLLFFBQVE7R0FDakYsSUFBSSxpQkFBaUIsbUJBQW1CLGVBQWU7SUFDckQsTUFBTSxTQUFTLFNBQVMscUJBQXFCLFlBQVk7SUFDekQsTUFBTSxJQUFJLE1BQU0sYUFBYSxPQUFPLGVBQWU7R0FDckQ7RUFDRixHQUFHLGVBQWU7Q0FDcEI7Q0FDQSxlQUFlLEtBQUssR0FBRztFQUNyQixJQUFJO0VBQ0osSUFBSSxDQUFDLFlBQVksT0FDZixNQUFNLElBQUksTUFBTSxvREFBb0Q7RUFDdEUsZUFBZSxRQUFRLGFBQWEsUUFBUSxFQUFFLGdCQUFnQjtFQUM5RCxnQkFBZ0IsYUFBYSxTQUFTLEtBQUssYUFBYSxNQUFNLE1BQU0sT0FBTyxLQUFLLGVBQWUsUUFBUSxhQUFhLENBQUM7RUFDckgsSUFBSSxDQUFDLGVBQ0gsTUFBTSxJQUFJLE1BQU0sMkJBQTJCO0VBQzdDLGNBQWMsbUJBQW1CO0VBQ2pDLE9BQU8sTUFBTSxNQUFNLE9BQU8sQ0FBQyxDQUFDLEtBQUssYUFBYTtDQUNoRDtDQUNBLGVBQWUsU0FBUztFQUN0QixJQUFJLENBQUMsUUFBUSxPQUNYLE9BQU87RUFDVCxTQUFTLGdCQUFnQjtFQUN6QixNQUFNLE1BQU0sT0FBTyxDQUFDLENBQUMsU0FBUztFQUM5QixPQUFPO0NBQ1Q7Q0FDQSxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7QUFFQSxTQUFTLGdCQUFnQixRQUFRLFVBQVUsQ0FBQyxHQUFHO0NBQzdDLE1BQU0sWUFBWSxNQUFNLE1BQU07Q0FDOUIsTUFBTSxFQUNKLFlBQVksSUFDWixTQUNBLFlBQ0EsY0FDQSxvQkFBb0IsVUFDbEI7Q0FDSixNQUFNLFdBQVcsU0FBUztFQUFFLEdBQUc7RUFBRyxHQUFHO0NBQUUsQ0FBQztDQUN4QyxNQUFNLGtCQUFrQixHQUFHLE1BQU07RUFDL0IsU0FBUyxJQUFJO0VBQ2IsU0FBUyxJQUFJO0NBQ2Y7Q0FDQSxNQUFNLFNBQVMsU0FBUztFQUFFLEdBQUc7RUFBRyxHQUFHO0NBQUUsQ0FBQztDQUN0QyxNQUFNLGdCQUFnQixHQUFHLE1BQU07RUFDN0IsT0FBTyxJQUFJO0VBQ1gsT0FBTyxJQUFJO0NBQ2I7Q0FDQSxNQUFNLFlBQVksZUFBZSxTQUFTLElBQUksT0FBTyxDQUFDO0NBQ3RELE1BQU0sWUFBWSxlQUFlLFNBQVMsSUFBSSxPQUFPLENBQUM7Q0FDdEQsTUFBTSxFQUFFLEtBQUssUUFBUTtDQUNyQixNQUFNLHNCQUFzQixlQUFlLElBQUksSUFBSSxVQUFVLEtBQUssR0FBRyxJQUFJLFVBQVUsS0FBSyxDQUFDLEtBQUssU0FBUztDQUN2RyxNQUFNLFlBQVksV0FBVyxLQUFLO0NBQ2xDLE1BQU0sZ0JBQWdCLFdBQVcsS0FBSztDQUN0QyxNQUFNLFlBQVksZUFBZTtFQUMvQixJQUFJLENBQUMsb0JBQW9CLE9BQ3ZCLE9BQU87RUFDVCxJQUFJLElBQUksVUFBVSxLQUFLLElBQUksSUFBSSxVQUFVLEtBQUssR0FBRztHQUMvQyxPQUFPLFVBQVUsUUFBUSxJQUFJLFNBQVM7RUFDeEMsT0FBTztHQUNMLE9BQU8sVUFBVSxRQUFRLElBQUksT0FBTztFQUN0QztDQUNGLENBQUM7Q0FDRCxNQUFNLGtCQUFrQixNQUFNO0VBQzVCLElBQUksSUFBSSxJQUFJO0VBQ1osTUFBTSxvQkFBb0IsRUFBRSxZQUFZO0VBQ3hDLE1BQU0sa0JBQWtCLEVBQUUsWUFBWTtFQUN0QyxRQUFRLE1BQU0sTUFBTSxLQUFLLFFBQVEsaUJBQWlCLE9BQU8sS0FBSyxJQUFJLEdBQUcsU0FBUyxFQUFFLFdBQVcsTUFBTSxPQUFPLEtBQUsscUJBQXFCLG9CQUFvQixPQUFPLEtBQUs7Q0FDcEs7Q0FDQSxNQUFNLGtCQUFrQixFQUFFLFNBQVMsS0FBSztDQUN4QyxNQUFNLFFBQVE7RUFDWixpQkFBaUIsUUFBUSxnQkFBZ0IsTUFBTTtHQUM3QyxJQUFJLENBQUMsZUFBZSxDQUFDLEdBQ25CO0dBQ0YsY0FBYyxRQUFRO0dBQ3RCLE1BQU0sY0FBYyxFQUFFO0dBQ3RCLGVBQWUsT0FBTyxLQUFLLElBQUksWUFBWSxrQkFBa0IsRUFBRSxTQUFTO0dBQ3hFLE1BQU0sRUFBRSxTQUFTLEdBQUcsU0FBUyxNQUFNO0dBQ25DLGVBQWUsR0FBRyxDQUFDO0dBQ25CLGFBQWEsR0FBRyxDQUFDO0dBQ2pCLGdCQUFnQixPQUFPLEtBQUssSUFBSSxhQUFhLENBQUM7RUFDaEQsR0FBRyxlQUFlO0VBQ2xCLGlCQUFpQixRQUFRLGdCQUFnQixNQUFNO0dBQzdDLElBQUksQ0FBQyxlQUFlLENBQUMsR0FDbkI7R0FDRixJQUFJLENBQUMsY0FBYyxPQUNqQjtHQUNGLE1BQU0sRUFBRSxTQUFTLEdBQUcsU0FBUyxNQUFNO0dBQ25DLGFBQWEsR0FBRyxDQUFDO0dBQ2pCLElBQUksQ0FBQyxVQUFVLFNBQVMsb0JBQW9CLE9BQzFDLFVBQVUsUUFBUTtHQUNwQixJQUFJLFVBQVUsT0FDWixXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsQ0FBQztFQUN4QyxHQUFHLGVBQWU7RUFDbEIsaUJBQWlCLFFBQVEsY0FBYyxNQUFNO0dBQzNDLElBQUksQ0FBQyxlQUFlLENBQUMsR0FDbkI7R0FDRixJQUFJLFVBQVUsT0FDWixjQUFjLE9BQU8sS0FBSyxJQUFJLFdBQVcsR0FBRyxVQUFVLEtBQUs7R0FDN0QsY0FBYyxRQUFRO0dBQ3RCLFVBQVUsUUFBUTtFQUNwQixHQUFHLGVBQWU7Q0FDcEI7Q0FDQSxtQkFBbUI7RUFDakIsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJO0VBQ2hDLENBQUMsTUFBTSxLQUFLLFVBQVUsVUFBVSxPQUFPLEtBQUssSUFBSSxHQUFHLFVBQVUsT0FBTyxLQUFLLElBQUksR0FBRyxZQUFZLGdCQUFnQixPQUFPO0VBQ25ILElBQUksbUJBQW1CO0dBQ3JCLENBQUMsTUFBTSxLQUFLLFVBQVUsVUFBVSxPQUFPLEtBQUssSUFBSSxHQUFHLFVBQVUsT0FBTyxLQUFLLElBQUksR0FBRyxZQUFZLHVCQUF1QixNQUFNO0dBQ3pILENBQUMsTUFBTSxLQUFLLFVBQVUsVUFBVSxPQUFPLEtBQUssSUFBSSxHQUFHLFVBQVUsT0FBTyxLQUFLLElBQUksR0FBRyxZQUFZLG1CQUFtQixNQUFNO0dBQ3JILENBQUMsTUFBTSxLQUFLLFVBQVUsVUFBVSxPQUFPLEtBQUssSUFBSSxHQUFHLFVBQVUsT0FBTyxLQUFLLElBQUksR0FBRyxZQUFZLGVBQWUsTUFBTTtFQUNuSDtDQUNGLENBQUM7Q0FDRCxNQUFNLGFBQWEsTUFBTSxTQUFTLE1BQU0sRUFBRSxDQUFDO0NBQzNDLE9BQU87RUFDTCxXQUFXLFNBQVMsU0FBUztFQUM3QixXQUFXLFNBQVMsU0FBUztFQUM3QixVQUFVLFNBQVMsUUFBUTtFQUMzQixRQUFRLFNBQVMsTUFBTTtFQUN2QjtFQUNBO0VBQ0E7Q0FDRjtBQUNGOztBQUdBLFNBQVMsd0JBQXdCLFNBQVM7Q0FDeEMsTUFBTSxVQUFVLGNBQWMsaUNBQWlDLE9BQU87Q0FDdEUsTUFBTSxTQUFTLGNBQWMsZ0NBQWdDLE9BQU87Q0FDcEUsT0FBTyxlQUFlO0VBQ3BCLElBQUksT0FBTyxPQUNULE9BQU87RUFDVCxJQUFJLFFBQVEsT0FDVixPQUFPO0VBQ1QsT0FBTztDQUNULENBQUM7QUFDSDs7QUFHQSxTQUFTLHFCQUFxQixTQUFTO0NBQ3JDLE1BQU0sU0FBUyxjQUFjLDRCQUE0QixPQUFPO0NBQ2hFLE1BQU0sU0FBUyxjQUFjLDRCQUE0QixPQUFPO0NBQ2hFLE1BQU0sV0FBVyxjQUFjLDhCQUE4QixPQUFPO0NBQ3BFLE9BQU8sZUFBZTtFQUNwQixJQUFJLE9BQU8sT0FDVCxPQUFPO0VBQ1QsSUFBSSxPQUFPLE9BQ1QsT0FBTztFQUNULElBQUksU0FBUyxPQUNYLE9BQU87RUFDVCxPQUFPO0NBQ1QsQ0FBQztBQUNIOztBQUdBLFNBQVMsc0JBQXNCLFVBQVUsQ0FBQyxHQUFHO0NBQzNDLE1BQU0sRUFBRSxTQUFTLGtCQUFrQjtDQUNuQyxJQUFJLENBQUMsUUFDSCxPQUFPLFdBQVcsQ0FBQyxJQUFJLENBQUM7Q0FDMUIsTUFBTSxZQUFZLE9BQU87Q0FDekIsTUFBTSxRQUFRLFdBQVcsVUFBVSxTQUFTO0NBQzVDLGlCQUFpQixRQUFRLHdCQUF3QjtFQUMvQyxNQUFNLFFBQVEsVUFBVTtDQUMxQixHQUFHLEVBQUUsU0FBUyxLQUFLLENBQUM7Q0FDcEIsT0FBTztBQUNUOztBQUdBLFNBQVMsMEJBQTBCLFNBQVM7Q0FDMUMsTUFBTSxZQUFZLGNBQWMsb0NBQW9DLE9BQU87Q0FDM0UsT0FBTyxlQUFlO0VBQ3BCLElBQUksVUFBVSxPQUNaLE9BQU87RUFDVCxPQUFPO0NBQ1QsQ0FBQztBQUNIOztBQUdBLFNBQVMsZ0NBQWdDLFNBQVM7Q0FDaEQsTUFBTSxZQUFZLGNBQWMsMENBQTBDLE9BQU87Q0FDakYsT0FBTyxlQUFlO0VBQ3BCLElBQUksVUFBVSxPQUNaLE9BQU87RUFDVCxPQUFPO0NBQ1QsQ0FBQztBQUNIO0FBRUEsU0FBUyxZQUFZLE9BQU8sY0FBYztDQUN4QyxNQUFNLFdBQVcsV0FBVyxZQUFZO0NBQ3hDLE1BQ0UsTUFBTSxLQUFLLElBQ1YsR0FBRyxhQUFhO0VBQ2YsU0FBUyxRQUFRO0NBQ25CLEdBQ0EsRUFBRSxPQUFPLE9BQU8sQ0FDbEI7Q0FDQSxPQUFPLFNBQVMsUUFBUTtBQUMxQjtBQUVBLE1BQU0sYUFBYTtBQUNuQixNQUFNLGVBQWU7QUFDckIsTUFBTSxnQkFBZ0I7QUFDdEIsTUFBTSxjQUFjO0FBQ3BCLFNBQVMsb0JBQW9CO0NBQzNCLE1BQU0sTUFBTSxXQUFXLEVBQUU7Q0FDekIsTUFBTSxRQUFRLFdBQVcsRUFBRTtDQUMzQixNQUFNLFNBQVMsV0FBVyxFQUFFO0NBQzVCLE1BQU0sT0FBTyxXQUFXLEVBQUU7Q0FDMUIsSUFBSSxVQUFVO0VBQ1osTUFBTSxZQUFZLFVBQVUsVUFBVTtFQUN0QyxNQUFNLGNBQWMsVUFBVSxZQUFZO0VBQzFDLE1BQU0sZUFBZSxVQUFVLGFBQWE7RUFDNUMsTUFBTSxhQUFhLFVBQVUsV0FBVztFQUN4QyxVQUFVLFFBQVE7RUFDbEIsWUFBWSxRQUFRO0VBQ3BCLGFBQWEsUUFBUTtFQUNyQixXQUFXLFFBQVE7RUFDbkIsYUFBYSxNQUFNO0VBQ25CLGlCQUFpQixVQUFVLGNBQWMsTUFBTSxHQUFHLEVBQUUsU0FBUyxLQUFLLENBQUM7Q0FDckU7Q0FDQSxTQUFTLFNBQVM7RUFDaEIsSUFBSSxRQUFRLFNBQVMsVUFBVTtFQUMvQixNQUFNLFFBQVEsU0FBUyxZQUFZO0VBQ25DLE9BQU8sUUFBUSxTQUFTLGFBQWE7RUFDckMsS0FBSyxRQUFRLFNBQVMsV0FBVztDQUNuQztDQUNBLE9BQU87RUFDTDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsU0FBUyxVQUFVO0NBQzFCLE9BQU8saUJBQWlCLFNBQVMsZUFBZSxDQUFDLENBQUMsaUJBQWlCLFFBQVE7QUFDN0U7QUFFQSxTQUFTLGFBQWEsS0FBSyxXQUFXLE1BQU0sVUFBVSxDQUFDLEdBQUc7Q0FDeEQsTUFBTSxFQUNKLFlBQVksTUFDWixTQUFTLE9BQ1QsT0FBTyxtQkFDUCxRQUFRLE1BQ1IsYUFDQSxnQkFDQSxVQUNBLE9BQ0EsV0FBVyxpQkFDWCxRQUFRLENBQUMsR0FDVCxRQUFRLEtBQUssTUFDWDtDQUNKLE1BQU0sWUFBWSxXQUFXLElBQUk7Q0FDakMsSUFBSSxXQUFXO0NBQ2YsTUFBTSxjQUFjLHNCQUFzQixJQUFJLFNBQVMsU0FBUyxXQUFXO0VBQ3pFLE1BQU0sc0JBQXNCLFFBQVE7R0FDbEMsVUFBVSxRQUFRO0dBQ2xCLFFBQVEsR0FBRztHQUNYLE9BQU87RUFDVDtFQUNBLElBQUksQ0FBQyxVQUFVO0dBQ2IsUUFBUSxLQUFLO0dBQ2I7RUFDRjtFQUNBLElBQUksZUFBZTtFQUNuQixJQUFJLEtBQUssU0FBUyxjQUFjLGVBQWUsUUFBUSxHQUFHLEVBQUUsR0FBRztFQUMvRCxJQUFJLENBQUMsSUFBSTtHQUNQLEtBQUssU0FBUyxjQUFjLFFBQVE7R0FDcEMsR0FBRyxPQUFPO0dBQ1YsR0FBRyxRQUFRO0dBQ1gsR0FBRyxNQUFNLFFBQVEsR0FBRztHQUNwQixJQUFJLE9BQ0YsR0FBRyxRQUFRO0dBQ2IsSUFBSSxhQUNGLEdBQUcsY0FBYztHQUNuQixJQUFJLFVBQ0YsR0FBRyxXQUFXO0dBQ2hCLElBQUksZ0JBQ0YsR0FBRyxpQkFBaUI7R0FDdEIsSUFBSSxPQUFPO0lBQ1QsR0FBRyxRQUFRO0dBQ2I7R0FDQSxPQUFPLFFBQVEsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sV0FBVyxNQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsYUFBYSxNQUFNLEtBQUssQ0FBQztHQUNuRyxlQUFlO0VBQ2pCLE9BQU8sSUFBSSxHQUFHLGFBQWEsYUFBYSxHQUFHO0dBQ3pDLG1CQUFtQixFQUFFO0VBQ3ZCO0VBQ0EsTUFBTSxrQkFBa0IsRUFDdEIsU0FBUyxLQUNYO0VBQ0EsaUJBQWlCLElBQUksVUFBVSxVQUFVLE9BQU8sS0FBSyxHQUFHLGVBQWU7RUFDdkUsaUJBQWlCLElBQUksVUFBVSxVQUFVLE9BQU8sS0FBSyxHQUFHLGVBQWU7RUFDdkUsaUJBQWlCLElBQUksY0FBYztHQUNqQyxHQUFHLGFBQWEsZUFBZSxNQUFNO0dBQ3JDLFNBQVMsRUFBRTtHQUNYLG1CQUFtQixFQUFFO0VBQ3ZCLEdBQUcsZUFBZTtFQUNsQixJQUFJLGNBQ0YsS0FBSyxTQUFTLEtBQUssWUFBWSxFQUFFO0VBQ25DLElBQUksQ0FBQyxtQkFDSCxtQkFBbUIsRUFBRTtDQUN6QixDQUFDO0NBQ0QsTUFBTSxRQUFRLG9CQUFvQixTQUFTO0VBQ3pDLElBQUksQ0FBQyxVQUNILFdBQVcsV0FBVyxpQkFBaUI7RUFDekMsT0FBTztDQUNUO0NBQ0EsTUFBTSxlQUFlO0VBQ25CLElBQUksQ0FBQyxVQUNIO0VBQ0YsV0FBVztFQUNYLElBQUksVUFBVSxPQUNaLFVBQVUsUUFBUTtFQUNwQixNQUFNLEtBQUssU0FBUyxjQUFjLGVBQWUsUUFBUSxHQUFHLEVBQUUsR0FBRztFQUNqRSxJQUFJLElBQ0YsU0FBUyxLQUFLLFlBQVksRUFBRTtDQUNoQztDQUNBLElBQUksYUFBYSxDQUFDLFFBQ2hCLGFBQWEsSUFBSTtDQUNuQixJQUFJLENBQUMsUUFDSCxlQUFlLE1BQU07Q0FDdkIsT0FBTztFQUFFO0VBQVc7RUFBTTtDQUFPO0FBQ25DO0FBRUEsU0FBUyxvQkFBb0IsS0FBSztDQUNoQyxNQUFNLFFBQVEsT0FBTyxpQkFBaUIsR0FBRztDQUN6QyxJQUFJLE1BQU0sY0FBYyxZQUFZLE1BQU0sY0FBYyxZQUFZLE1BQU0sY0FBYyxVQUFVLElBQUksY0FBYyxJQUFJLGVBQWUsTUFBTSxjQUFjLFVBQVUsSUFBSSxlQUFlLElBQUksY0FBYztFQUN4TSxPQUFPO0NBQ1QsT0FBTztFQUNMLE1BQU0sU0FBUyxJQUFJO0VBQ25CLElBQUksQ0FBQyxVQUFVLE9BQU8sWUFBWSxRQUNoQyxPQUFPO0VBQ1QsT0FBTyxvQkFBb0IsTUFBTTtDQUNuQztBQUNGO0FBQ0EsU0FBUyxlQUFlLFVBQVU7Q0FDaEMsTUFBTSxJQUFJLFlBQVksT0FBTztDQUM3QixNQUFNLFVBQVUsRUFBRTtDQUNsQixJQUFJLG9CQUFvQixPQUFPLEdBQzdCLE9BQU87Q0FDVCxJQUFJLEVBQUUsUUFBUSxTQUFTLEdBQ3JCLE9BQU87Q0FDVCxJQUFJLEVBQUUsZ0JBQ0osRUFBRSxlQUFlO0NBQ25CLE9BQU87QUFDVDtBQUNBLE1BQU0sb0NBQW9DLElBQUksUUFBUTtBQUN0RCxTQUFTLGNBQWMsU0FBUyxlQUFlLE9BQU87Q0FDcEQsTUFBTSxXQUFXLFdBQVcsWUFBWTtDQUN4QyxJQUFJLHdCQUF3QjtDQUM1QixJQUFJLGtCQUFrQjtDQUN0QixNQUFNLE1BQU0sT0FBTyxJQUFJLE9BQU87RUFDNUIsTUFBTSxTQUFTLGVBQWUsUUFBUSxFQUFFLENBQUM7RUFDekMsSUFBSSxRQUFRO0dBQ1YsTUFBTSxNQUFNO0dBQ1osSUFBSSxDQUFDLGtCQUFrQixJQUFJLEdBQUcsR0FDNUIsa0JBQWtCLElBQUksS0FBSyxJQUFJLE1BQU0sUUFBUTtHQUMvQyxJQUFJLElBQUksTUFBTSxhQUFhLFVBQ3pCLGtCQUFrQixJQUFJLE1BQU07R0FDOUIsSUFBSSxJQUFJLE1BQU0sYUFBYSxVQUN6QixPQUFPLFNBQVMsUUFBUTtHQUMxQixJQUFJLFNBQVMsT0FDWCxPQUFPLElBQUksTUFBTSxXQUFXO0VBQ2hDO0NBQ0YsR0FBRyxFQUNELFdBQVcsS0FDYixDQUFDO0NBQ0QsTUFBTSxhQUFhO0VBQ2pCLE1BQU0sS0FBSyxlQUFlLFFBQVEsT0FBTyxDQUFDO0VBQzFDLElBQUksQ0FBQyxNQUFNLFNBQVMsT0FDbEI7RUFDRixJQUFJLE9BQU87R0FDVCx3QkFBd0IsaUJBQ3RCLElBQ0EsY0FDQyxNQUFNO0lBQ0wsZUFBZSxDQUFDO0dBQ2xCLEdBQ0EsRUFBRSxTQUFTLE1BQU0sQ0FDbkI7RUFDRjtFQUNBLEdBQUcsTUFBTSxXQUFXO0VBQ3BCLFNBQVMsUUFBUTtDQUNuQjtDQUNBLE1BQU0sZUFBZTtFQUNuQixNQUFNLEtBQUssZUFBZSxRQUFRLE9BQU8sQ0FBQztFQUMxQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsT0FDbkI7RUFDRixJQUFJLE9BQ0YseUJBQXlCLE9BQU8sS0FBSyxJQUFJLHNCQUFzQjtFQUNqRSxHQUFHLE1BQU0sV0FBVztFQUNwQixrQkFBa0IsT0FBTyxFQUFFO0VBQzNCLFNBQVMsUUFBUTtDQUNuQjtDQUNBLGtCQUFrQixNQUFNO0NBQ3hCLE9BQU8sU0FBUztFQUNkLE1BQU07R0FDSixPQUFPLFNBQVM7RUFDbEI7RUFDQSxJQUFJLEdBQUc7R0FDTCxJQUFJLEdBQ0YsS0FBSztRQUNGLE9BQU87RUFDZDtDQUNGLENBQUM7QUFDSDtBQUVBLFNBQVMsa0JBQWtCLEtBQUssY0FBYyxVQUFVLENBQUMsR0FBRztDQUMxRCxNQUFNLEVBQUUsU0FBUyxrQkFBa0I7Q0FDbkMsT0FBTyxXQUFXLEtBQUssY0FBYyxVQUFVLE9BQU8sS0FBSyxJQUFJLE9BQU8sZ0JBQWdCLE9BQU87QUFDL0Y7O0FBR0EsU0FBUyxTQUFTLGVBQWUsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxHQUFHO0NBQ2pELE1BQU0sRUFBRSxZQUFZLHFCQUFxQjtDQUN6QyxNQUFNLGFBQWE7Q0FDbkIsTUFBTSxjQUFjLG1CQUFtQixjQUFjLGNBQWMsVUFBVTtDQUM3RSxNQUFNLFFBQVEsT0FBTyxrQkFBa0IsQ0FBQyxNQUFNO0VBQzVDLElBQUksWUFBWSxPQUFPO0dBQ3JCLE1BQU0sT0FBTztJQUNYLEdBQUcsUUFBUSxZQUFZO0lBQ3ZCLEdBQUcsUUFBUSxlQUFlO0dBQzVCO0dBQ0EsSUFBSSxVQUFVO0dBQ2QsSUFBSSxLQUFLLFNBQVMsV0FBVyxVQUMzQixVQUFVLFdBQVcsU0FBUyxFQUFFLE9BQU8sS0FBSyxNQUFNLENBQUM7R0FDckQsSUFBSSxTQUNGLE9BQU8sV0FBVyxNQUFNLElBQUk7RUFDaEM7Q0FDRjtDQUNBLE9BQU87RUFDTDtFQUNBO0NBQ0Y7QUFDRjtBQUVBLE1BQU0saUJBQWlCLFFBQVEsY0FBYyxPQUFPLEtBQUssU0FBUztBQUNsRSxNQUFNLGtCQUFrQixHQUFHLE1BQU0sSUFBSTtBQUNyQyxTQUFTLFVBQVUsR0FBRyxNQUFNO0NBQzFCLElBQUksSUFBSSxJQUFJLElBQUk7Q0FDaEIsTUFBTSxDQUFDLFVBQVU7Q0FDakIsSUFBSSxZQUFZO0NBQ2hCLElBQUksVUFBVSxDQUFDO0NBQ2YsSUFBSSxLQUFLLFdBQVcsR0FBRztFQUNyQixJQUFJLE9BQU8sS0FBSyxPQUFPLFVBQVU7R0FDL0IsVUFBVSxLQUFLO0dBQ2YsYUFBYSxLQUFLLFFBQVEsY0FBYyxPQUFPLEtBQUs7RUFDdEQsT0FBTztHQUNMLGFBQWEsS0FBSyxLQUFLLE9BQU8sT0FBTyxLQUFLO0VBQzVDO0NBQ0YsT0FBTyxJQUFJLEtBQUssU0FBUyxHQUFHO0VBQzFCLGFBQWEsS0FBSyxLQUFLLE9BQU8sT0FBTyxLQUFLO0VBQzFDLFdBQVcsS0FBSyxLQUFLLE9BQU8sT0FBTyxLQUFLLENBQUM7Q0FDM0M7Q0FDQSxNQUFNLEVBQ0osUUFBUSxPQUNSLFNBQVMsa0JBQ1A7Q0FDSixJQUFJLENBQUMsT0FDSCxPQUFPLGVBQWUsT0FBTyxDQUFDLEdBQUcsUUFBUSxNQUFNLENBQUMsR0FBRyxTQUFTLENBQUM7Q0FDL0Qsa0JBQWtCO0VBQ2hCLE1BQU0sU0FBUyxPQUFPLFFBQVEsTUFBTSxHQUFHLFNBQVM7RUFDaEQsSUFBSSxNQUFNLE1BQU0sR0FDZCxPQUFPLFFBQVE7T0FFZixPQUFPLE9BQU8sR0FBRyxPQUFPLFFBQVEsR0FBRyxNQUFNO0NBQzdDLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7QUFFQSxTQUFTLHFCQUFxQixVQUFVLENBQUMsR0FBRztDQUMxQyxNQUFNLEVBQ0osaUJBQWlCLE1BQ2pCLGFBQWEsTUFDYixrQkFBa0IsR0FDbEIsU0FBUyxrQkFDUDtDQUNKLE1BQU0sT0FBTyxNQUFNLFFBQVEsUUFBUSxPQUFPO0NBQzFDLE1BQU0sY0FBYyxXQUFXLEtBQUs7Q0FDcEMsTUFBTSxVQUFVLFdBQVcsS0FBSztDQUNoQyxNQUFNLFNBQVMsV0FBVyxFQUFFO0NBQzVCLE1BQU0sUUFBUSxXQUFXLEtBQUssQ0FBQztDQUMvQixJQUFJO0NBQ0osTUFBTSxjQUFjO0VBQ2xCLFlBQVksUUFBUTtDQUN0QjtDQUNBLE1BQU0sYUFBYTtFQUNqQixZQUFZLFFBQVE7Q0FDdEI7Q0FDQSxNQUFNLFVBQVUsUUFBUSxDQUFDLFlBQVksVUFBVTtFQUM3QyxJQUFJLE9BQU87R0FDVCxNQUFNO0VBQ1IsT0FBTztHQUNMLEtBQUs7RUFDUDtDQUNGO0NBQ0EsTUFBTSxvQkFBb0IsV0FBVyxPQUFPLHFCQUFxQixPQUFPO0NBQ3hFLE1BQU0sY0FBYyxtQkFBbUIsaUJBQWlCO0NBQ3hELElBQUksWUFBWSxPQUFPO0VBQ3JCLGNBQWMsSUFBSSxrQkFBa0I7RUFDcEMsWUFBWSxhQUFhO0VBQ3pCLFlBQVksaUJBQWlCO0VBQzdCLFlBQVksT0FBTyxRQUFRLElBQUk7RUFDL0IsWUFBWSxrQkFBa0I7RUFDOUIsWUFBWSxnQkFBZ0I7R0FDMUIsWUFBWSxRQUFRO0dBQ3BCLFFBQVEsUUFBUTtFQUNsQjtFQUNBLE1BQU0sT0FBTyxVQUFVO0dBQ3JCLElBQUksZUFBZSxDQUFDLFlBQVksT0FDOUIsWUFBWSxPQUFPO0VBQ3ZCLENBQUM7RUFDRCxZQUFZLFlBQVksVUFBVTtHQUNoQyxNQUFNLGdCQUFnQixNQUFNLFFBQVEsTUFBTTtHQUMxQyxNQUFNLEVBQUUsZUFBZSxjQUFjO0dBQ3JDLFFBQVEsUUFBUSxjQUFjO0dBQzlCLE9BQU8sUUFBUTtHQUNmLE1BQU0sUUFBUSxLQUFLO0VBQ3JCO0VBQ0EsWUFBWSxXQUFXLFVBQVU7R0FDL0IsTUFBTSxRQUFRO0VBQ2hCO0VBQ0EsWUFBWSxjQUFjO0dBQ3hCLFlBQVksUUFBUTtHQUNwQixZQUFZLE9BQU8sUUFBUSxJQUFJO0VBQ2pDO0VBQ0EsTUFBTSxjQUFjLFVBQVUsYUFBYTtHQUN6QyxJQUFJLGFBQWEsVUFDZjtHQUNGLElBQUksVUFDRixZQUFZLE1BQU07UUFFbEIsWUFBWSxLQUFLO0VBQ3JCLENBQUM7Q0FDSDtDQUNBLHdCQUF3QjtFQUN0QixLQUFLO0NBQ1AsQ0FBQztDQUNELE9BQU87RUFDTDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsU0FBUyxtQkFBbUIsTUFBTSxVQUFVLENBQUMsR0FBRztDQUM5QyxNQUFNLEVBQ0osUUFBUSxHQUNSLE9BQU8sR0FDUCxTQUFTLEdBQ1QsU0FBUyxlQUNULGVBQ0U7Q0FDSixNQUFNLFFBQVEsVUFBVSxPQUFPO0NBQy9CLE1BQU0sY0FBYyxtQkFBbUIsS0FBSztDQUM1QyxNQUFNLFlBQVksV0FBVyxLQUFLO0NBQ2xDLE1BQU0sU0FBUyxXQUFXLE1BQU07Q0FDaEMsTUFBTSxhQUFhLE1BQU0sUUFBUSxFQUFFO0NBQ25DLE1BQU0sT0FBTyxNQUFNLFFBQVEsUUFBUSxPQUFPO0NBQzFDLE1BQU0sUUFBUSxXQUFXLEtBQUssQ0FBQztDQUMvQixNQUFNLFVBQVUsUUFBUSxDQUFDLFVBQVUsVUFBVTtFQUMzQyxVQUFVLFFBQVE7Q0FDcEI7Q0FDQSxNQUFNLDBCQUEwQixlQUFlO0VBQzdDLFdBQVcsT0FBTyxRQUFRLElBQUk7RUFDOUIsV0FBVyxRQUFRLFFBQVEsUUFBUSxLQUFLLEtBQUs7RUFDN0MsV0FBVyxRQUFRLFFBQVEsS0FBSztFQUNoQyxXQUFXLE9BQU8sUUFBUSxJQUFJO0VBQzlCLFdBQVcsU0FBUyxRQUFRLE1BQU07RUFDbEMsV0FBVyxnQkFBZ0I7R0FDekIsVUFBVSxRQUFRO0dBQ2xCLE9BQU8sUUFBUTtFQUNqQjtFQUNBLFdBQVcsZ0JBQWdCO0dBQ3pCLFVBQVUsUUFBUTtHQUNsQixPQUFPLFFBQVE7RUFDakI7RUFDQSxXQUFXLGlCQUFpQjtHQUMxQixVQUFVLFFBQVE7R0FDbEIsT0FBTyxRQUFRO0VBQ2pCO0VBQ0EsV0FBVyxjQUFjO0dBQ3ZCLFVBQVUsUUFBUTtHQUNsQixPQUFPLFFBQVE7RUFDakI7RUFDQSxXQUFXLFdBQVcsVUFBVTtHQUM5QixNQUFNLFFBQVE7RUFDaEI7RUFDQSxXQUFXLGNBQWMsVUFBVTtHQUNqQyxjQUFjLE9BQU8sS0FBSyxJQUFJLFdBQVcsS0FBSztFQUNoRDtDQUNGO0NBQ0EsTUFBTSxZQUFZLGVBQWU7RUFDL0IsVUFBVSxRQUFRO0VBQ2xCLE9BQU8sUUFBUTtFQUNmLE1BQU0sZUFBZSxJQUFJLHlCQUF5QixXQUFXLEtBQUs7RUFDbEUsdUJBQXVCLFlBQVk7RUFDbkMsT0FBTztDQUNULENBQUM7Q0FDRCxNQUFNLGNBQWM7RUFDbEIsTUFBTSxPQUFPO0VBQ2IsSUFBSSxXQUNGLE1BQU0sTUFBTSxVQUFVLEtBQUs7Q0FDL0I7Q0FDQSxNQUFNLGFBQWE7RUFDakIsTUFBTSxPQUFPO0VBQ2IsVUFBVSxRQUFRO0NBQ3BCO0NBQ0EsSUFBSSxZQUFZLE9BQU87RUFDckIsdUJBQXVCLFVBQVUsS0FBSztFQUN0QyxNQUFNLE9BQU8sVUFBVTtHQUNyQixJQUFJLFVBQVUsU0FBUyxDQUFDLFVBQVUsT0FDaEMsVUFBVSxNQUFNLE9BQU87RUFDM0IsQ0FBQztFQUNELElBQUksUUFBUSxPQUFPO0dBQ2pCLE1BQU0sUUFBUSxhQUFhO0lBQ3pCLE1BQU0sT0FBTztHQUNmLENBQUM7RUFDSDtFQUNBLE1BQU0saUJBQWlCO0dBQ3JCLElBQUksVUFBVSxPQUNaLE1BQU0sT0FBTztRQUViLE1BQU0sTUFBTTtFQUNoQixDQUFDO0NBQ0g7Q0FDQSx3QkFBd0I7RUFDdEIsVUFBVSxRQUFRO0NBQ3BCLENBQUM7Q0FDRCxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7O0FBR0EsU0FBUyxXQUFXLE9BQU8sYUFBYTtDQUN0QyxNQUFNLFdBQVcsSUFBSSxLQUFLO0NBQzFCLE1BQU0sWUFBWSxlQUFlLE1BQU0sUUFBUSxTQUFTLEtBQUssSUFBSSxTQUFTLFFBQVEsT0FBTyxLQUFLLFNBQVMsS0FBSyxDQUFDO0NBQzdHLE1BQU0sUUFBUSxJQUFJLFVBQVUsTUFBTSxRQUFRLGVBQWUsT0FBTyxjQUFjLFVBQVUsTUFBTSxFQUFFLENBQUM7Q0FDakcsTUFBTSxVQUFVLGVBQWUsR0FBRyxNQUFNLEtBQUssQ0FBQztDQUM5QyxNQUFNLFVBQVUsZUFBZSxNQUFNLFVBQVUsQ0FBQztDQUNoRCxNQUFNLFNBQVMsZUFBZSxNQUFNLFVBQVUsVUFBVSxNQUFNLFNBQVMsQ0FBQztDQUN4RSxNQUFNLE9BQU8sZUFBZSxVQUFVLE1BQU0sTUFBTSxRQUFRLEVBQUU7Q0FDNUQsTUFBTSxXQUFXLGVBQWUsVUFBVSxNQUFNLE1BQU0sUUFBUSxFQUFFO0NBQ2hFLFNBQVMsR0FBRyxRQUFRO0VBQ2xCLElBQUksTUFBTSxRQUFRLFNBQVMsS0FBSyxHQUM5QixPQUFPLFNBQVMsTUFBTTtFQUN4QixPQUFPLFNBQVMsTUFBTSxVQUFVLE1BQU07Q0FDeEM7Q0FDQSxTQUFTLElBQUksTUFBTTtFQUNqQixJQUFJLENBQUMsVUFBVSxNQUFNLFNBQVMsSUFBSSxHQUNoQztFQUNGLE9BQU8sR0FBRyxVQUFVLE1BQU0sUUFBUSxJQUFJLENBQUM7Q0FDekM7Q0FDQSxTQUFTLEtBQUssTUFBTTtFQUNsQixJQUFJLFVBQVUsTUFBTSxTQUFTLElBQUksR0FDL0IsTUFBTSxRQUFRLFVBQVUsTUFBTSxRQUFRLElBQUk7Q0FDOUM7Q0FDQSxTQUFTLFdBQVc7RUFDbEIsSUFBSSxPQUFPLE9BQ1Q7RUFDRixNQUFNO0NBQ1I7Q0FDQSxTQUFTLGVBQWU7RUFDdEIsSUFBSSxRQUFRLE9BQ1Y7RUFDRixNQUFNO0NBQ1I7Q0FDQSxTQUFTLFNBQVMsTUFBTTtFQUN0QixJQUFJLFFBQVEsSUFBSSxHQUNkLEtBQUssSUFBSTtDQUNiO0NBQ0EsU0FBUyxPQUFPLE1BQU07RUFDcEIsT0FBTyxVQUFVLE1BQU0sUUFBUSxJQUFJLE1BQU0sTUFBTSxRQUFRO0NBQ3pEO0NBQ0EsU0FBUyxXQUFXLE1BQU07RUFDeEIsT0FBTyxVQUFVLE1BQU0sUUFBUSxJQUFJLE1BQU0sTUFBTSxRQUFRO0NBQ3pEO0NBQ0EsU0FBUyxVQUFVLE1BQU07RUFDdkIsT0FBTyxVQUFVLE1BQU0sUUFBUSxJQUFJLE1BQU0sTUFBTTtDQUNqRDtDQUNBLFNBQVMsU0FBUyxNQUFNO0VBQ3RCLE9BQU8sTUFBTSxRQUFRLFVBQVUsTUFBTSxRQUFRLElBQUk7Q0FDbkQ7Q0FDQSxTQUFTLFFBQVEsTUFBTTtFQUNyQixPQUFPLE1BQU0sUUFBUSxVQUFVLE1BQU0sUUFBUSxJQUFJO0NBQ25EO0NBQ0EsT0FBTztFQUNMLE9BQU87RUFDUDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsU0FBUyxnQkFBZ0IsS0FBSyxjQUFjLFNBQVMsVUFBVSxDQUFDLEdBQUc7Q0FDakUsSUFBSTtDQUNKLE1BQU0sRUFDSixRQUFRLE9BQ1IsT0FBTyxNQUNQLHlCQUF5QixNQUN6QixnQkFBZ0IsTUFDaEIsZ0JBQWdCLE9BQ2hCLFNBQ0EsU0FBUyxlQUNULGFBQ0EsV0FBVyxNQUFNO0VBQ2YsUUFBUSxNQUFNLENBQUM7Q0FDakIsR0FDQSxZQUNFO0NBQ0osTUFBTSxVQUFVLFFBQVEsWUFBWTtDQUNwQyxNQUFNLE9BQU8sb0JBQW9CLE9BQU87Q0FDeEMsTUFBTSxRQUFRLFVBQVUsYUFBYSxJQUFHLENBQUUsUUFBUSxZQUFZLENBQUM7Q0FDL0QsTUFBTSxjQUFjLEtBQUssUUFBUSxlQUFlLE9BQU8sS0FBSyxtQkFBbUI7Q0FDL0UsSUFBSSxDQUFDLFNBQVM7RUFDWixJQUFJO0dBQ0YsVUFBVSxjQUFjLGdDQUFnQztJQUN0RCxJQUFJO0lBQ0osUUFBUSxNQUFNLGtCQUFrQixPQUFPLEtBQUssSUFBSSxJQUFJO0dBQ3RELENBQUMsQ0FBQyxDQUFDO0VBQ0wsU0FBUyxHQUFHO0dBQ1YsUUFBUSxDQUFDO0VBQ1g7Q0FDRjtDQUNBLGVBQWUsS0FBSyxPQUFPO0VBQ3pCLElBQUksQ0FBQyxXQUFXLFNBQVMsTUFBTSxRQUFRLEtBQ3JDO0VBQ0YsSUFBSTtHQUNGLE1BQU0sV0FBVyxRQUFRLE1BQU0sV0FBVyxNQUFNLFFBQVEsUUFBUSxHQUFHO0dBQ25FLElBQUksWUFBWSxNQUFNO0lBQ3BCLEtBQUssUUFBUTtJQUNiLElBQUksaUJBQWlCLFlBQVksTUFDL0IsTUFBTSxRQUFRLFFBQVEsS0FBSyxNQUFNLFdBQVcsTUFBTSxPQUFPLENBQUM7R0FDOUQsT0FBTyxJQUFJLGVBQWU7SUFDeEIsTUFBTSxRQUFRLE1BQU0sV0FBVyxLQUFLLFFBQVE7SUFDNUMsSUFBSSxPQUFPLGtCQUFrQixZQUMzQixLQUFLLFFBQVEsY0FBYyxPQUFPLE9BQU87U0FDdEMsSUFBSSxTQUFTLFlBQVksQ0FBQyxNQUFNLFFBQVEsS0FBSyxHQUNoRCxLQUFLLFFBQVE7S0FBRSxHQUFHO0tBQVMsR0FBRztJQUFNO1NBQ2pDLEtBQUssUUFBUTtHQUNwQixPQUFPO0lBQ0wsS0FBSyxRQUFRLE1BQU0sV0FBVyxLQUFLLFFBQVE7R0FDN0M7RUFDRixTQUFTLEdBQUc7R0FDVixRQUFRLENBQUM7RUFDWDtDQUNGO0NBQ0EsTUFBTSxVQUFVLElBQUksU0FBUyxZQUFZO0VBQ3ZDLEtBQUssQ0FBQyxDQUFDLFdBQVc7R0FDaEIsV0FBVyxPQUFPLEtBQUssSUFBSSxRQUFRLEtBQUssS0FBSztHQUM3QyxRQUFRLElBQUk7RUFDZCxDQUFDO0NBQ0gsQ0FBQztDQUNELElBQUksVUFBVSx3QkFDWixpQkFBaUIsUUFBUSxZQUFZLE1BQU0sUUFBUSxRQUFRLENBQUMsQ0FBQyxXQUFXLEtBQUssQ0FBQyxDQUFDLEdBQUcsRUFBRSxTQUFTLEtBQUssQ0FBQztDQUNyRyxJQUFJLFNBQVM7RUFDWCxnQkFDRSxNQUNBLFlBQVk7R0FDVixJQUFJO0lBQ0YsSUFBSSxLQUFLLFNBQVMsTUFDaEIsTUFBTSxRQUFRLFdBQVcsR0FBRztTQUU1QixNQUFNLFFBQVEsUUFBUSxLQUFLLE1BQU0sV0FBVyxNQUFNLEtBQUssS0FBSyxDQUFDO0dBQ2pFLFNBQVMsR0FBRztJQUNWLFFBQVEsQ0FBQztHQUNYO0VBQ0YsR0FDQTtHQUNFO0dBQ0E7R0FDQTtFQUNGLENBQ0Y7Q0FDRjtDQUNBLE9BQU8sT0FBTyxNQUFNO0VBQ2xCLE1BQU0sUUFBUSxLQUFLLEtBQUssT0FBTztFQUMvQixPQUFPLFFBQVEsTUFBTSxLQUFLLE9BQU87Q0FDbkMsQ0FBQztDQUNELE9BQU87QUFDVDtBQUVBLElBQUksTUFBTTtBQUNWLFNBQVMsWUFBWSxLQUFLLFVBQVUsQ0FBQyxHQUFHO0NBQ3RDLE1BQU0sV0FBVyxXQUFXLEtBQUs7Q0FDakMsTUFBTSxFQUNKLFdBQVcsaUJBQ1gsWUFBWSxNQUNaLFNBQVMsT0FDVCxLQUFLLG1CQUFtQixFQUFFLFVBQ3hCO0NBQ0osTUFBTSxTQUFTLFdBQVcsR0FBRztDQUM3QixJQUFJLGFBQWEsQ0FDakI7Q0FDQSxNQUFNLGFBQWE7RUFDakIsSUFBSSxDQUFDLFVBQ0g7RUFDRixNQUFNLEtBQUssU0FBUyxlQUFlLEVBQUUsS0FBSyxTQUFTLGNBQWMsT0FBTztFQUN4RSxJQUFJLENBQUMsR0FBRyxhQUFhO0dBQ25CLEdBQUcsS0FBSztHQUNSLElBQUksUUFBUSxPQUNWLEdBQUcsUUFBUSxRQUFRO0dBQ3JCLElBQUksUUFBUSxPQUNWLEdBQUcsUUFBUSxRQUFRO0dBQ3JCLFNBQVMsS0FBSyxZQUFZLEVBQUU7RUFDOUI7RUFDQSxJQUFJLFNBQVMsT0FDWDtFQUNGLE9BQU8sTUFDTCxTQUNDLFVBQVU7R0FDVCxHQUFHLGNBQWM7RUFDbkIsR0FDQSxFQUFFLFdBQVcsS0FBSyxDQUNwQjtFQUNBLFNBQVMsUUFBUTtDQUNuQjtDQUNBLE1BQU0sZUFBZTtFQUNuQixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsT0FDekI7RUFDRixLQUFLO0VBQ0wsU0FBUyxLQUFLLFlBQVksU0FBUyxlQUFlLEVBQUUsQ0FBQztFQUNyRCxTQUFTLFFBQVE7Q0FDbkI7Q0FDQSxJQUFJLGFBQWEsQ0FBQyxRQUNoQixhQUFhLElBQUk7Q0FDbkIsSUFBSSxDQUFDLFFBQ0gsa0JBQWtCLE1BQU07Q0FDMUIsT0FBTztFQUNMO0VBQ0EsS0FBSztFQUNMO0VBQ0E7RUFDQSxVQUFVLFNBQVMsUUFBUTtDQUM3QjtBQUNGO0FBRUEsU0FBUyxTQUFTLFFBQVEsVUFBVSxDQUFDLEdBQUc7Q0FDdEMsTUFBTSxFQUNKLFlBQVksSUFDWixTQUNBLFlBQ0EsY0FDQSxVQUFVLFNBQ1I7Q0FDSixNQUFNLGNBQWMsU0FBUztFQUFFLEdBQUc7RUFBRyxHQUFHO0NBQUUsQ0FBQztDQUMzQyxNQUFNLFlBQVksU0FBUztFQUFFLEdBQUc7RUFBRyxHQUFHO0NBQUUsQ0FBQztDQUN6QyxNQUFNLFFBQVEsZUFBZSxZQUFZLElBQUksVUFBVSxDQUFDO0NBQ3hELE1BQU0sUUFBUSxlQUFlLFlBQVksSUFBSSxVQUFVLENBQUM7Q0FDeEQsTUFBTSxFQUFFLEtBQUssUUFBUTtDQUNyQixNQUFNLHNCQUFzQixlQUFlLElBQUksSUFBSSxNQUFNLEtBQUssR0FBRyxJQUFJLE1BQU0sS0FBSyxDQUFDLEtBQUssU0FBUztDQUMvRixNQUFNLFlBQVksV0FBVyxLQUFLO0NBQ2xDLE1BQU0sWUFBWSxlQUFlO0VBQy9CLElBQUksQ0FBQyxvQkFBb0IsT0FDdkIsT0FBTztFQUNULElBQUksSUFBSSxNQUFNLEtBQUssSUFBSSxJQUFJLE1BQU0sS0FBSyxHQUFHO0dBQ3ZDLE9BQU8sTUFBTSxRQUFRLElBQUksU0FBUztFQUNwQyxPQUFPO0dBQ0wsT0FBTyxNQUFNLFFBQVEsSUFBSSxPQUFPO0VBQ2xDO0NBQ0YsQ0FBQztDQUNELE1BQU0sdUJBQXVCLE1BQU0sQ0FBQyxFQUFFLFFBQVEsRUFBRSxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxPQUFPO0NBQzlFLE1BQU0scUJBQXFCLEdBQUcsTUFBTTtFQUNsQyxZQUFZLElBQUk7RUFDaEIsWUFBWSxJQUFJO0NBQ2xCO0NBQ0EsTUFBTSxtQkFBbUIsR0FBRyxNQUFNO0VBQ2hDLFVBQVUsSUFBSTtFQUNkLFVBQVUsSUFBSTtDQUNoQjtDQUNBLE1BQU0sa0JBQWtCO0VBQUU7RUFBUyxTQUFTLENBQUM7Q0FBUTtDQUNyRCxNQUFNLGNBQWMsTUFBTTtFQUN4QixJQUFJLFVBQVUsT0FDWixjQUFjLE9BQU8sS0FBSyxJQUFJLFdBQVcsR0FBRyxVQUFVLEtBQUs7RUFDN0QsVUFBVSxRQUFRO0NBQ3BCO0NBQ0EsTUFBTSxRQUFRO0VBQ1osaUJBQWlCLFFBQVEsZUFBZSxNQUFNO0dBQzVDLElBQUksRUFBRSxRQUFRLFdBQVcsR0FDdkI7R0FDRixNQUFNLENBQUMsR0FBRyxLQUFLLG9CQUFvQixDQUFDO0dBQ3BDLGtCQUFrQixHQUFHLENBQUM7R0FDdEIsZ0JBQWdCLEdBQUcsQ0FBQztHQUNwQixnQkFBZ0IsT0FBTyxLQUFLLElBQUksYUFBYSxDQUFDO0VBQ2hELEdBQUcsZUFBZTtFQUNsQixpQkFBaUIsUUFBUSxjQUFjLE1BQU07R0FDM0MsSUFBSSxFQUFFLFFBQVEsV0FBVyxHQUN2QjtHQUNGLE1BQU0sQ0FBQyxHQUFHLEtBQUssb0JBQW9CLENBQUM7R0FDcEMsZ0JBQWdCLEdBQUcsQ0FBQztHQUNwQixJQUFJLGdCQUFnQixXQUFXLENBQUMsZ0JBQWdCLFdBQVcsS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJLEtBQUssSUFBSSxNQUFNLEtBQUssR0FDckcsRUFBRSxlQUFlO0dBQ25CLElBQUksQ0FBQyxVQUFVLFNBQVMsb0JBQW9CLE9BQzFDLFVBQVUsUUFBUTtHQUNwQixJQUFJLFVBQVUsT0FDWixXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsQ0FBQztFQUN4QyxHQUFHLGVBQWU7RUFDbEIsaUJBQWlCLFFBQVEsQ0FBQyxZQUFZLGFBQWEsR0FBRyxZQUFZLGVBQWU7Q0FDbkY7Q0FDQSxNQUFNLGFBQWEsTUFBTSxTQUFTLE1BQU0sRUFBRSxDQUFDO0NBQzNDLE9BQU87RUFDTDtFQUNBO0VBQ0E7RUFDQTtFQUNBLFNBQVM7RUFDVCxTQUFTO0VBQ1Q7O0VBRUEseUJBQXlCO0NBQzNCO0FBQ0Y7O0FBR0EsU0FBUyxzQkFBc0I7Q0FDN0IsTUFBTSxPQUFPLElBQUksQ0FBQyxDQUFDO0NBQ25CLEtBQUssTUFBTSxPQUFPLE9BQU87RUFDdkIsSUFBSSxJQUNGLEtBQUssTUFBTSxLQUFLLEVBQUU7Q0FDdEI7Q0FDQSxxQkFBcUI7RUFDbkIsS0FBSyxNQUFNLFNBQVM7Q0FDdEIsQ0FBQztDQUNELE9BQU87QUFDVDs7QUFHQSxTQUFTLGlCQUFpQixVQUFVLENBQUMsR0FBRztDQUN0QyxNQUFNLEVBQ0osV0FBVyxpQkFDWCxXQUFXLFFBQ1gsVUFBVSxPQUNWLGVBQWUsVUFDYjtDQUNKLFNBQVMsV0FBVztFQUNsQixJQUFJLElBQUk7RUFDUixRQUFRLE1BQU0sS0FBSyxZQUFZLE9BQU8sS0FBSyxJQUFJLFNBQVMsY0FBYyxRQUFRLE1BQU0sT0FBTyxLQUFLLElBQUksR0FBRyxhQUFhLEtBQUssTUFBTSxPQUFPLEtBQUs7Q0FDN0k7Q0FDQSxNQUFNLE1BQU0sSUFBSSxTQUFTLENBQUM7Q0FDMUIsbUJBQW1CLElBQUksUUFBUSxTQUFTLENBQUM7Q0FDekMsSUFBSSxXQUFXLFVBQVU7RUFDdkIsb0JBQ0UsU0FBUyxjQUFjLFFBQVEsU0FDekIsSUFBSSxRQUFRLFNBQVMsR0FDM0IsRUFBRSxZQUFZLEtBQUssQ0FDckI7Q0FDRjtDQUNBLE9BQU8sU0FBUztFQUNkLE1BQU07R0FDSixPQUFPLElBQUk7RUFDYjtFQUNBLElBQUksR0FBRztHQUNMLElBQUksSUFBSTtHQUNSLElBQUksUUFBUTtHQUNaLElBQUksQ0FBQyxVQUNIO0dBQ0YsSUFBSSxJQUFJLE9BQ04sQ0FBQyxLQUFLLFNBQVMsY0FBYyxRQUFRLE1BQU0sT0FBTyxLQUFLLElBQUksR0FBRyxhQUFhLE9BQU8sSUFBSSxLQUFLO1FBRTNGLENBQUMsS0FBSyxTQUFTLGNBQWMsUUFBUSxNQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsZ0JBQWdCLEtBQUs7RUFDdkY7Q0FDRixDQUFDO0FBQ0g7QUFFQSxTQUFTLHVCQUF1QixXQUFXO0NBQ3pDLElBQUk7Q0FDSixNQUFNLGNBQWMsS0FBSyxVQUFVLGVBQWUsT0FBTyxLQUFLO0NBQzlELE9BQU8sTUFBTSxLQUFLLEVBQUUsUUFBUSxXQUFXLElBQUksR0FBRyxNQUFNLFVBQVUsV0FBVyxDQUFDLENBQUM7QUFDN0U7O0FBRUEsU0FBUyxpQkFBaUIsVUFBVSxDQUFDLEdBQUc7Q0FDdEMsTUFBTSxFQUNKLFNBQVMsa0JBQ1A7Q0FDSixNQUFNLFlBQVksSUFBSSxJQUFJO0NBQzFCLE1BQU0sT0FBTyxlQUFlO0VBQzFCLElBQUksSUFBSTtFQUNSLFFBQVEsTUFBTSxLQUFLLFVBQVUsVUFBVSxPQUFPLEtBQUssSUFBSSxHQUFHLFNBQVMsTUFBTSxPQUFPLEtBQUs7Q0FDdkYsQ0FBQztDQUNELE1BQU0sU0FBUyxlQUFlLFVBQVUsUUFBUSx1QkFBdUIsVUFBVSxLQUFLLElBQUksQ0FBQyxDQUFDO0NBQzVGLE1BQU0sUUFBUSxlQUFlLE9BQU8sTUFBTSxLQUFLLFVBQVUsTUFBTSxzQkFBc0IsQ0FBQyxDQUFDO0NBQ3ZGLFNBQVMsb0JBQW9CO0VBQzNCLFVBQVUsUUFBUTtFQUNsQixJQUFJLFFBQ0YsVUFBVSxRQUFRLE9BQU8sYUFBYTtDQUMxQztDQUNBLElBQUksUUFDRixpQkFBaUIsT0FBTyxVQUFVLG1CQUFtQixtQkFBbUIsRUFBRSxTQUFTLEtBQUssQ0FBQztDQUMzRixPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsU0FBUyx5QkFBeUIsU0FBUyxlQUFlLElBQUk7Q0FDNUQsSUFBSSxVQUFVLE9BQU8sT0FBTywwQkFBMEIsWUFBWTtFQUNoRSxPQUFPLHNCQUFzQixFQUFFO0NBQ2pDLE9BQU87RUFDTCxHQUFHO0NBQ0w7QUFDRjtBQUNBLFNBQVMsb0JBQW9CLFVBQVUsQ0FBQyxHQUFHO0NBQ3pDLElBQUksSUFBSTtDQUNSLE1BQU0sRUFBRSxTQUFTLGtCQUFrQjtDQUNuQyxNQUFNLFdBQVcsTUFBTSxXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsT0FBTztDQUNqRSxNQUFNLFFBQVEsT0FBTyxLQUFLLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxVQUFVLE9BQU8sS0FBSyxFQUFFO0NBQ3JGLE1BQU0sYUFBYSxLQUFLLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxjQUFjLE9BQU8sS0FBSztDQUNyRixNQUFNLHVCQUF1QixXQUFXLENBQUM7Q0FDekMsTUFBTSxtQkFBbUIsV0FBVyxDQUFDO0NBQ3JDLFNBQVMsZ0JBQWdCO0VBQ3ZCLElBQUk7RUFDSixJQUFJLENBQUMsU0FBUyxPQUNaO0VBQ0YsSUFBSSxTQUFTO0VBQ2IsU0FBUyxNQUFNLE1BQU0sYUFBYTtFQUNsQyxxQkFBcUIsU0FBUyxNQUFNLFNBQVMsVUFBVSxPQUFPLEtBQUssSUFBSSxJQUFJO0VBQzNFLE1BQU0sZUFBZSxRQUFRLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxXQUFXO0VBQzNFLElBQUksY0FDRixhQUFhLE1BQU0sYUFBYSxHQUFHLHFCQUFxQixNQUFNO09BRTlELFNBQVMsR0FBRyxxQkFBcUIsTUFBTTtFQUN6QyxTQUFTLE1BQU0sTUFBTSxhQUFhO0NBQ3BDO0NBQ0EsTUFBTSxDQUFDLE9BQU8sUUFBUSxTQUFTLFNBQVMsYUFBYSxHQUFHLEVBQUUsV0FBVyxLQUFLLENBQUM7Q0FDM0UsTUFBTSw0QkFBNEI7RUFDaEMsSUFBSTtFQUNKLFFBQVEsTUFBTSxXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsYUFBYSxPQUFPLEtBQUssSUFBSSxJQUFJLEtBQUssT0FBTztDQUNoRyxDQUFDO0NBQ0Qsa0JBQWtCLFdBQVcsQ0FBQyxFQUFFLG1CQUFtQjtFQUNqRCxJQUFJLGlCQUFpQixVQUFVLFlBQVksT0FDekM7RUFDRix5QkFBeUIsY0FBYztHQUNyQyxpQkFBaUIsUUFBUSxZQUFZO0dBQ3JDLGNBQWM7RUFDaEIsQ0FBQztDQUNILENBQUM7Q0FDRCxJQUFJLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxPQUNyQyxNQUFNLFFBQVEsT0FBTyxlQUFlO0VBQUUsV0FBVztFQUFNLE1BQU07Q0FBSyxDQUFDO0NBQ3JFLE9BQU87RUFDTDtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsU0FBUyx1QkFBdUIsUUFBUSxVQUFVLENBQUMsR0FBRztDQUNwRCxNQUFNLEVBQUUsV0FBVyxLQUFLLFdBQVcsU0FBUztDQUM1QyxNQUFNLFNBQVMsZUFBZSxVQUFVLFFBQVE7Q0FDaEQsTUFBTSxVQUFVLGNBQWMsUUFBUTtFQUFFLEdBQUc7RUFBUyxhQUFhO0NBQU8sQ0FBQztDQUN6RSxPQUFPLEVBQ0wsR0FBRyxRQUNMO0FBQ0Y7QUFFQSxNQUFNLGdCQUFnQjtDQUNwQjtFQUFFLEtBQUs7RUFBSyxPQUFPO0VBQUssTUFBTTtDQUFTO0NBQ3ZDO0VBQUUsS0FBSztFQUFPLE9BQU87RUFBSyxNQUFNO0NBQVM7Q0FDekM7RUFBRSxLQUFLO0VBQU0sT0FBTztFQUFNLE1BQU07Q0FBTztDQUN2QztFQUFFLEtBQUs7RUFBUSxPQUFPO0VBQU8sTUFBTTtDQUFNO0NBQ3pDO0VBQUUsS0FBSztFQUFTLE9BQU87RUFBUSxNQUFNO0NBQU87Q0FDNUM7RUFBRSxLQUFLO0VBQVMsT0FBTztFQUFRLE1BQU07Q0FBUTtDQUM3QztFQUFFLEtBQUssT0FBTztFQUFtQixPQUFPO0VBQVMsTUFBTTtDQUFPO0FBQ2hFO0FBQ0EsTUFBTSxtQkFBbUI7Q0FDdkIsU0FBUztDQUNULE9BQU8sTUFBTSxFQUFFLE1BQU0sSUFBSSxJQUFJLEdBQUcsRUFBRSxRQUFRO0NBQzFDLFNBQVMsTUFBTSxFQUFFLE1BQU0sSUFBSSxJQUFJLE1BQU0sTUFBTTtDQUMzQyxRQUFRLEdBQUcsU0FBUyxNQUFNLElBQUksT0FBTyxlQUFlLGVBQWUsR0FBRyxFQUFFLFFBQVEsSUFBSSxJQUFJLE1BQU07Q0FDOUYsT0FBTyxHQUFHLFNBQVMsTUFBTSxJQUFJLE9BQU8sY0FBYyxjQUFjLEdBQUcsRUFBRSxPQUFPLElBQUksSUFBSSxNQUFNO0NBQzFGLE1BQU0sR0FBRyxTQUFTLE1BQU0sSUFBSSxPQUFPLGNBQWMsYUFBYSxHQUFHLEVBQUUsTUFBTSxJQUFJLElBQUksTUFBTTtDQUN2RixPQUFPLEdBQUcsU0FBUyxNQUFNLElBQUksT0FBTyxjQUFjLGNBQWMsR0FBRyxFQUFFLE9BQU8sSUFBSSxJQUFJLE1BQU07Q0FDMUYsT0FBTyxNQUFNLEdBQUcsRUFBRSxPQUFPLElBQUksSUFBSSxNQUFNO0NBQ3ZDLFNBQVMsTUFBTSxHQUFHLEVBQUUsU0FBUyxJQUFJLElBQUksTUFBTTtDQUMzQyxTQUFTLE1BQU0sR0FBRyxFQUFFLFNBQVMsSUFBSSxJQUFJLE1BQU07Q0FDM0MsU0FBUztBQUNYO0FBQ0EsU0FBUyxrQkFBa0IsTUFBTTtDQUMvQixPQUFPLEtBQUssWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUU7QUFDdkM7O0FBRUEsU0FBUyxXQUFXLE1BQU0sVUFBVSxDQUFDLEdBQUc7Q0FDdEMsTUFBTSxFQUNKLFVBQVUsaUJBQWlCLE9BQzNCLGlCQUFpQixRQUNmO0NBQ0osTUFBTSxFQUFFLEtBQUssR0FBRyxhQUFhLE9BQU87RUFBRSxVQUFVO0VBQWdCLFVBQVU7Q0FBSyxDQUFDO0NBQ2hGLE1BQU0sVUFBVSxlQUFlLGNBQWMsSUFBSSxLQUFLLFFBQVEsSUFBSSxDQUFDLEdBQUcsU0FBUyxRQUFRLEdBQUcsQ0FBQyxDQUFDO0NBQzVGLElBQUksZ0JBQWdCO0VBQ2xCLE9BQU87R0FDTDtHQUNBLEdBQUc7RUFDTDtDQUNGLE9BQU87RUFDTCxPQUFPO0NBQ1Q7QUFDRjtBQUNBLFNBQVMsY0FBYyxNQUFNLFVBQVUsQ0FBQyxHQUFHLE1BQU0sS0FBSyxJQUFJLEdBQUc7Q0FDM0QsSUFBSTtDQUNKLE1BQU0sRUFDSixLQUNBLFdBQVcsa0JBQ1gsb0JBQW9CLG1CQUNwQixRQUFRLGVBQ1IsYUFBYSxPQUNiLFdBQVcsWUFDVDtDQUNKLE1BQU0sVUFBVSxPQUFPLGFBQWEsWUFBWSxNQUFNLENBQUMsRUFBRSxRQUFRLFFBQVEsSUFBSSxLQUFLO0NBQ2xGLE1BQU0sT0FBTyxDQUFDLE1BQU0sQ0FBQztDQUNyQixNQUFNLFVBQVUsS0FBSyxJQUFJLElBQUk7Q0FDN0IsU0FBUyxTQUFTLE9BQU8sTUFBTTtFQUM3QixPQUFPLFFBQVEsS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUs7Q0FDN0M7Q0FDQSxTQUFTLE9BQU8sT0FBTyxNQUFNO0VBQzNCLE1BQU0sTUFBTSxTQUFTLE9BQU8sSUFBSTtFQUNoQyxNQUFNLE9BQU8sUUFBUTtFQUNyQixNQUFNLE1BQU0sWUFBWSxLQUFLLE1BQU0sS0FBSyxJQUFJO0VBQzVDLE9BQU8sWUFBWSxPQUFPLFNBQVMsVUFBVSxLQUFLLElBQUk7Q0FDeEQ7Q0FDQSxTQUFTLFlBQVksTUFBTSxLQUFLLFFBQVE7RUFDdEMsTUFBTSxZQUFZLFNBQVM7RUFDM0IsSUFBSSxPQUFPLGNBQWMsWUFDdkIsT0FBTyxVQUFVLEtBQUssTUFBTTtFQUM5QixPQUFPLFVBQVUsUUFBUSxPQUFPLElBQUksU0FBUyxDQUFDO0NBQ2hEO0NBQ0EsSUFBSSxVQUFVLE9BQU8sQ0FBQyxZQUNwQixPQUFPLFNBQVM7Q0FDbEIsSUFBSSxPQUFPLFFBQVEsWUFBWSxVQUFVLEtBQ3ZDLE9BQU8sa0JBQWtCLElBQUksS0FBSyxJQUFJLENBQUM7Q0FDekMsSUFBSSxPQUFPLFFBQVEsVUFBVTtFQUMzQixNQUFNLFdBQVcsS0FBSyxNQUFNLE1BQU0sTUFBTSxFQUFFLFNBQVMsR0FBRyxNQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUc7RUFDL0UsSUFBSSxXQUFXLFVBQVUsU0FDdkIsT0FBTyxrQkFBa0IsSUFBSSxLQUFLLElBQUksQ0FBQztDQUMzQztDQUNBLEtBQUssTUFBTSxDQUFDLEtBQUssU0FBUyxNQUFNLFFBQVEsR0FBRztFQUN6QyxNQUFNLE1BQU0sU0FBUyxNQUFNLElBQUk7RUFDL0IsSUFBSSxPQUFPLEtBQUssTUFBTSxNQUFNLElBQzFCLE9BQU8sT0FBTyxNQUFNLE1BQU0sTUFBTSxFQUFFO0VBQ3BDLElBQUksVUFBVSxLQUFLLEtBQ2pCLE9BQU8sT0FBTyxNQUFNLElBQUk7Q0FDNUI7Q0FDQSxPQUFPLFNBQVM7QUFDbEI7QUFFQSxNQUFNLFFBQVE7Q0FDWjtFQUFFLE1BQU07RUFBUSxJQUFJO0NBQVE7Q0FDNUI7RUFBRSxNQUFNO0VBQVMsSUFBSTtDQUFPO0NBQzVCO0VBQUUsTUFBTTtFQUFRLElBQUk7Q0FBTztDQUMzQjtFQUFFLE1BQU07RUFBTyxJQUFJO0NBQU07Q0FDekI7RUFBRSxNQUFNO0VBQVEsSUFBSTtDQUFLO0NBQ3pCO0VBQUUsTUFBTTtFQUFVLElBQUk7Q0FBSTtDQUMxQjtFQUFFLE1BQU07RUFBVSxJQUFJO0NBQUk7QUFDNUI7QUFDQSxTQUFTLGVBQWUsTUFBTSxVQUFVLENBQUMsR0FBRztDQUMxQyxNQUFNLEVBQ0osVUFBVSxpQkFBaUIsT0FDM0IsaUJBQWlCLFFBQ2Y7Q0FDSixNQUFNLEVBQUUsS0FBSyxHQUFHLGFBQWEsT0FBTztFQUFFLFVBQVU7RUFBZ0IsVUFBVTtDQUFLLENBQUM7Q0FDaEYsTUFBTSxTQUFTLGVBQ1AscUJBQXFCLElBQUksS0FBSyxRQUFRLElBQUksQ0FBQyxHQUFHLFNBQVMsUUFBUSxHQUFHLENBQUMsQ0FDM0U7Q0FDQSxNQUFNLFFBQVEsZUFBZSxPQUFPLE1BQU0sS0FBSztDQUMvQyxNQUFNLGNBQWMsZUFDWix1QkFBdUIsTUFBTSxPQUFPO0VBQ3hDLEdBQUc7RUFDSCxRQUFRLE9BQU8sTUFBTTtDQUN2QixDQUFDLENBQ0g7Q0FDQSxPQUFPLGlCQUFpQjtFQUFFO0VBQWE7RUFBTyxHQUFHO0NBQVMsSUFBSTtBQUNoRTtBQUNBLFNBQVMsa0JBQWtCLE1BQU0sVUFBVSxDQUFDLEdBQUcsTUFBTSxLQUFLLElBQUksR0FBRztDQUMvRCxNQUFNLEVBQUUsT0FBTyxtQkFBbUIscUJBQXFCLE1BQU0sU0FBUyxHQUFHO0NBQ3pFLE9BQU8sdUJBQXVCLE9BQU87RUFDbkMsR0FBRztFQUNILFFBQVE7Q0FDVixDQUFDO0FBQ0g7QUFDQSxTQUFTLHFCQUFxQixNQUFNLFVBQVUsQ0FBQyxHQUFHLE1BQU0sS0FBSyxJQUFJLEdBQUc7Q0FDbEUsTUFBTSxFQUNKLFFBQ0EsNEJBQTRCLEVBQUUsU0FBUyxPQUFPLE1BQzVDO0NBQ0osTUFBTSxNQUFNLElBQUksS0FBSyxtQkFBbUIsUUFBUSx5QkFBeUI7Q0FDekUsTUFBTSxFQUFFLFFBQVEsbUJBQW1CLElBQUksZ0JBQWdCO0NBQ3ZELE1BQU0sT0FBTyxDQUFDLE9BQU8sQ0FBQztDQUN0QixNQUFNLFVBQVUsS0FBSyxJQUFJLElBQUk7Q0FDN0IsS0FBSyxNQUFNLEVBQUUsTUFBTSxRQUFRLE9BQU87RUFDaEMsSUFBSSxXQUFXLElBQUk7R0FDakIsT0FBTztJQUNMO0lBQ0EsT0FBTyxJQUFJLGNBQWMsS0FBSyxNQUFNLE9BQU8sRUFBRSxHQUFHLElBQUk7R0FDdEQ7RUFDRjtDQUNGO0NBQ0EsT0FBTztFQUNMO0VBQ0EsT0FBTyxJQUFJLGNBQWMsR0FBRyxRQUFRO0NBQ3RDO0FBQ0Y7QUFDQSxTQUFTLHVCQUF1QixPQUFPLFVBQVUsQ0FBQyxHQUFHO0NBQ25ELE1BQU0sRUFDSixjQUFjLE1BQ2QsV0FDQSxXQUNFO0NBQ0osSUFBSSxPQUFPLGNBQWMsWUFDdkIsT0FBTyxVQUFVLE9BQU8sTUFBTTtDQUNoQyxJQUFJLENBQUMsYUFDSCxPQUFPLE1BQU0sS0FBSyxTQUFTLEtBQUssS0FBSyxDQUFDLENBQUMsS0FBSyxFQUFFO0NBQ2hELE9BQU8sTUFBTSxLQUFLLFNBQVMsS0FBSyxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHO0FBQ3hEO0FBRUEsU0FBUyxlQUFlLElBQUksVUFBVSxVQUFVLENBQUMsR0FBRztDQUNsRCxNQUFNLEVBQ0osWUFBWSxNQUNaLG9CQUFvQixVQUNsQjtDQUNKLE1BQU0sRUFBRSxVQUFVLGFBQWEsTUFBTSxVQUFVLEVBQUUsVUFBVSxDQUFDO0NBQzVELE1BQU0sV0FBVyxXQUFXLEtBQUs7Q0FDakMsZUFBZSxPQUFPO0VBQ3BCLElBQUksQ0FBQyxTQUFTLE9BQ1o7RUFDRixNQUFNLEdBQUc7RUFDVCxNQUFNO0NBQ1I7Q0FDQSxTQUFTLFNBQVM7RUFDaEIsSUFBSSxDQUFDLFNBQVMsT0FBTztHQUNuQixTQUFTLFFBQVE7R0FDakIsSUFBSSxtQkFDRixHQUFHO0dBQ0wsTUFBTTtFQUNSO0NBQ0Y7Q0FDQSxTQUFTLFFBQVE7RUFDZixTQUFTLFFBQVE7Q0FDbkI7Q0FDQSxJQUFJLGFBQWEsVUFDZixPQUFPO0NBQ1Qsa0JBQWtCLEtBQUs7Q0FDdkIsT0FBTztFQUNMO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7QUFFQSxTQUFTLGFBQWEsVUFBVSxDQUFDLEdBQUc7Q0FDbEMsTUFBTSxFQUNKLFVBQVUsaUJBQWlCLE9BQzNCLFNBQVMsR0FDVCxZQUFZLE1BQ1osV0FBVyx5QkFDWCxhQUNFO0NBQ0osTUFBTSxLQUFLLFdBQVcsVUFBVSxJQUFJLE1BQU07Q0FDMUMsTUFBTSxlQUFlLEdBQUcsUUFBUSxVQUFVLElBQUk7Q0FDOUMsTUFBTSxLQUFLLGlCQUFpQjtFQUMxQixPQUFPO0VBQ1AsU0FBUyxHQUFHLEtBQUs7Q0FDbkIsSUFBSTtDQUNKLE1BQU0sV0FBVyxhQUFhLDBCQUEwQixTQUFTLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSSxjQUFjLElBQUksVUFBVSxFQUFFLFVBQVUsQ0FBQztDQUMvSCxJQUFJLGdCQUFnQjtFQUNsQixPQUFPO0dBQ0wsV0FBVztHQUNYLEdBQUc7RUFDTDtDQUNGLE9BQU87RUFDTCxPQUFPO0NBQ1Q7QUFDRjtBQUVBLFNBQVMsU0FBUyxXQUFXLE1BQU0sVUFBVSxDQUFDLEdBQUc7Q0FDL0MsSUFBSSxJQUFJLElBQUk7Q0FDWixNQUFNLEVBQ0osV0FBVyxpQkFDWCxvQkFBb0IsTUFBTSxNQUN4QjtDQUNKLE1BQU0saUJBQWlCLEtBQUssWUFBWSxPQUFPLEtBQUssSUFBSSxTQUFTLFVBQVUsT0FBTyxLQUFLO0NBQ3ZGLE1BQU0sUUFBUSxPQUFPLEtBQUssWUFBWSxPQUFPLFdBQVcsWUFBWSxPQUFPLEtBQUssSUFBSSxTQUFTLFVBQVUsT0FBTyxLQUFLLElBQUk7Q0FDdkgsTUFBTSxhQUFhLENBQUMsRUFBRSxZQUFZLE9BQU8sYUFBYTtDQUN0RCxTQUFTLE9BQU8sR0FBRztFQUNqQixJQUFJLEVBQUUsbUJBQW1CLFVBQ3ZCLE9BQU87RUFDVCxNQUFNLFdBQVcsUUFBUSxpQkFBaUI7RUFDMUMsT0FBTyxPQUFPLGFBQWEsYUFBYSxTQUFTLENBQUMsSUFBSSxRQUFRLFFBQVEsQ0FBQyxDQUFDLFFBQVEsT0FBTyxDQUFDO0NBQzFGO0NBQ0EsTUFDRSxRQUNDLFVBQVUsYUFBYTtFQUN0QixJQUFJLGFBQWEsWUFBWSxVQUMzQixTQUFTLFFBQVEsT0FBTyxZQUFZLE9BQU8sV0FBVyxFQUFFO0NBQzVELEdBQ0EsRUFBRSxXQUFXLEtBQUssQ0FDcEI7Q0FDQSxJQUFJLFFBQVEsV0FBVyxDQUFDLFFBQVEsaUJBQWlCLFlBQVksQ0FBQyxZQUFZO0VBQ3hFLHFCQUNHLEtBQUssU0FBUyxTQUFTLE9BQU8sS0FBSyxJQUFJLEdBQUcsY0FBYyxPQUFPLFNBQzFEO0dBQ0osSUFBSSxZQUFZLFNBQVMsVUFBVSxNQUFNLE9BQ3ZDLE1BQU0sUUFBUSxPQUFPLFNBQVMsS0FBSztFQUN2QyxHQUNBLEVBQUUsV0FBVyxLQUFLLENBQ3BCO0NBQ0Y7Q0FDQSx3QkFBd0I7RUFDdEIsSUFBSSxrQkFBa0I7R0FDcEIsTUFBTSxnQkFBZ0IsaUJBQWlCLGVBQWUsTUFBTSxTQUFTLEVBQUU7R0FDdkUsSUFBSSxpQkFBaUIsUUFBUSxVQUMzQixTQUFTLFFBQVE7RUFDckI7Q0FDRixDQUFDO0NBQ0QsT0FBTztBQUNUO0FBRUEsTUFBTSxxQkFBcUI7Q0FDekIsWUFBWTtFQUFDO0VBQU07RUFBRztFQUFNO0NBQUM7Q0FDN0IsYUFBYTtFQUFDO0VBQU07RUFBRztFQUFNO0NBQUM7Q0FDOUIsZUFBZTtFQUFDO0VBQU07RUFBRztFQUFNO0NBQUM7Q0FDaEMsWUFBWTtFQUFDO0VBQU07RUFBRztFQUFLO0NBQUM7Q0FDNUIsYUFBYTtFQUFDO0VBQUs7RUFBRztFQUFNO0NBQUM7Q0FDN0IsZUFBZTtFQUFDO0VBQU07RUFBRztFQUFNO0NBQUM7Q0FDaEMsYUFBYTtFQUFDO0VBQU07RUFBRztFQUFNO0NBQUM7Q0FDOUIsY0FBYztFQUFDO0VBQU07RUFBRztFQUFNO0NBQUM7Q0FDL0IsZ0JBQWdCO0VBQUM7RUFBTTtFQUFHO0VBQU07Q0FBQztDQUNqQyxhQUFhO0VBQUM7RUFBSztFQUFHO0VBQU07Q0FBQztDQUM3QixjQUFjO0VBQUM7RUFBTTtFQUFHO0VBQUs7Q0FBQztDQUM5QixnQkFBZ0I7RUFBQztFQUFNO0VBQUc7RUFBTTtDQUFDO0NBQ2pDLGFBQWE7RUFBQztFQUFNO0VBQUc7RUFBTTtDQUFDO0NBQzlCLGNBQWM7RUFBQztFQUFNO0VBQUc7RUFBTTtDQUFDO0NBQy9CLGdCQUFnQjtFQUFDO0VBQU07RUFBRztFQUFNO0NBQUM7Q0FDakMsWUFBWTtFQUFDO0VBQUs7RUFBRztFQUFNO0NBQUM7Q0FDNUIsYUFBYTtFQUFDO0VBQU07RUFBRztFQUFLO0NBQUM7Q0FDN0IsZUFBZTtFQUFDO0VBQU07RUFBRztFQUFNO0NBQUM7Q0FDaEMsWUFBWTtFQUFDO0VBQU07RUFBRztFQUFHO0NBQUk7Q0FDN0IsYUFBYTtFQUFDO0VBQUc7RUFBTTtFQUFNO0NBQUM7Q0FDOUIsZUFBZTtFQUFDO0VBQU07RUFBRztFQUFNO0NBQUM7Q0FDaEMsWUFBWTtFQUFDO0VBQU07RUFBRztFQUFNLENBQUM7Q0FBSTtDQUNqQyxhQUFhO0VBQUM7RUFBTTtFQUFNO0VBQU07Q0FBQztDQUNqQyxlQUFlO0VBQUM7RUFBTSxDQUFDO0VBQUs7RUFBTTtDQUFHO0FBQ3ZDO0FBQ0EsTUFBTSxvQkFBb0MsdUJBQU8sT0FBTyxDQUFDLEdBQUcsRUFBRSxRQUFRLFNBQVMsR0FBRyxrQkFBa0I7QUFDcEcsU0FBUyxxQkFBcUIsQ0FBQyxJQUFJLElBQUksSUFBSSxLQUFLO0NBQzlDLE1BQU0sS0FBSyxJQUFJLE9BQU8sSUFBSSxJQUFJLEtBQUssSUFBSTtDQUN2QyxNQUFNLEtBQUssSUFBSSxPQUFPLElBQUksS0FBSyxJQUFJO0NBQ25DLE1BQU0sS0FBSyxPQUFPLElBQUk7Q0FDdEIsTUFBTSxjQUFjLEdBQUcsSUFBSSxTQUFTLEVBQUUsSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFLElBQUksRUFBRSxLQUFLLElBQUksRUFBRSxFQUFFLEtBQUs7Q0FDOUUsTUFBTSxZQUFZLEdBQUcsSUFBSSxPQUFPLElBQUksRUFBRSxJQUFJLEVBQUUsSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFLElBQUksRUFBRSxJQUFJLElBQUksRUFBRSxFQUFFO0NBQ2hGLE1BQU0sWUFBWSxNQUFNO0VBQ3RCLElBQUksVUFBVTtFQUNkLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEVBQUUsR0FBRztHQUMxQixNQUFNLGVBQWUsU0FBUyxTQUFTLElBQUksRUFBRTtHQUM3QyxJQUFJLGlCQUFpQixHQUNuQixPQUFPO0dBQ1QsTUFBTSxXQUFXLFdBQVcsU0FBUyxJQUFJLEVBQUUsSUFBSTtHQUMvQyxXQUFXLFdBQVc7RUFDeEI7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxRQUFRLE1BQU0sT0FBTyxNQUFNLE9BQU8sS0FBSyxJQUFJLFdBQVcsU0FBUyxDQUFDLEdBQUcsSUFBSSxFQUFFO0FBQzNFO0FBQ0EsU0FBUyxLQUFLLEdBQUcsR0FBRyxPQUFPO0NBQ3pCLE9BQU8sSUFBSSxTQUFTLElBQUk7QUFDMUI7QUFDQSxTQUFTLE1BQU0sR0FBRztDQUNoQixRQUFRLE9BQU8sTUFBTSxXQUFXLENBQUMsQ0FBQyxJQUFJLE1BQU0sQ0FBQztBQUMvQztBQUNBLFNBQVMsa0JBQWtCLFFBQVEsTUFBTSxJQUFJLFVBQVUsQ0FBQyxHQUFHO0NBQ3pELElBQUksSUFBSTtDQUNSLE1BQU0sRUFDSixTQUFTLGtCQUNQO0NBQ0osTUFBTSxVQUFVLFFBQVEsSUFBSTtDQUM1QixNQUFNLFFBQVEsUUFBUSxFQUFFO0NBQ3hCLE1BQU0sS0FBSyxNQUFNLE9BQU87Q0FDeEIsTUFBTSxLQUFLLE1BQU0sS0FBSztDQUN0QixNQUFNLFlBQVksS0FBSyxRQUFRLFFBQVEsUUFBUSxNQUFNLE9BQU8sS0FBSztDQUNqRSxNQUFNLFlBQVksS0FBSyxJQUFJO0NBQzNCLE1BQU0sUUFBUSxLQUFLLElBQUksSUFBSTtDQUMzQixNQUFNLFFBQVEsT0FBTyxRQUFRLGVBQWUsYUFBYSxRQUFRLGNBQWMsS0FBSyxRQUFRLFFBQVEsVUFBVSxNQUFNLE9BQU8sS0FBSztDQUNoSSxNQUFNLE9BQU8sT0FBTyxVQUFVLGFBQWEsUUFBUSxxQkFBcUIsS0FBSztDQUM3RSxPQUFPLElBQUksU0FBUyxZQUFZO0VBQzlCLE9BQU8sUUFBUTtFQUNmLE1BQU0sYUFBYTtHQUNqQixJQUFJO0dBQ0osS0FBSyxNQUFNLFFBQVEsVUFBVSxPQUFPLEtBQUssSUFBSSxJQUFJLEtBQUssT0FBTyxHQUFHO0lBQzlELFFBQVE7SUFDUjtHQUNGO0dBQ0EsTUFBTSxNQUFNLEtBQUssSUFBSTtHQUNyQixNQUFNLFFBQVEsTUFBTSxNQUFNLGFBQWEsUUFBUTtHQUMvQyxNQUFNLE1BQU0sTUFBTSxPQUFPLEtBQUssQ0FBQyxDQUFDLEtBQUssR0FBRyxNQUFNLEtBQUssR0FBRyxJQUFJLEdBQUcsSUFBSSxLQUFLLENBQUM7R0FDdkUsSUFBSSxNQUFNLFFBQVEsT0FBTyxLQUFLLEdBQzVCLE9BQU8sUUFBUSxJQUFJLEtBQUssR0FBRyxNQUFNO0lBQy9CLElBQUksS0FBSztJQUNULE9BQU8sTUFBTSxNQUFNLEdBQUcsT0FBTyxPQUFPLE1BQU0sSUFBSSxNQUFNLEdBQUcsT0FBTyxPQUFPLE1BQU0sR0FBRyxLQUFLO0dBQ3JGLENBQUM7UUFDRSxJQUFJLE9BQU8sT0FBTyxVQUFVLFVBQy9CLE9BQU8sUUFBUSxJQUFJO0dBQ3JCLElBQUksTUFBTSxPQUFPO0lBQ2YsVUFBVSxPQUFPLEtBQUssSUFBSSxPQUFPLHNCQUFzQixJQUFJO0dBQzdELE9BQU87SUFDTCxPQUFPLFFBQVE7SUFDZixRQUFRO0dBQ1Y7RUFDRjtFQUNBLEtBQUs7Q0FDUCxDQUFDO0FBQ0g7QUFDQSxTQUFTLGNBQWMsUUFBUSxVQUFVLENBQUMsR0FBRztDQUMzQyxJQUFJLFlBQVk7Q0FDaEIsTUFBTSxrQkFBa0I7RUFDdEIsTUFBTSxJQUFJLFFBQVEsTUFBTTtFQUN4QixPQUFPLE9BQU8sTUFBTSxXQUFXLElBQUksRUFBRSxJQUFJLE9BQU87Q0FDbEQ7Q0FDQSxNQUFNLFlBQVksSUFBSSxVQUFVLENBQUM7Q0FDakMsTUFBTSxXQUFXLE9BQU8sT0FBTztFQUM3QixJQUFJLElBQUk7RUFDUixJQUFJLFFBQVEsUUFBUSxRQUFRLEdBQzFCO0VBQ0YsTUFBTSxLQUFLLEVBQUU7RUFDYixJQUFJLFFBQVEsT0FDVixNQUFNLGVBQWUsUUFBUSxRQUFRLEtBQUssQ0FBQztFQUM3QyxJQUFJLE9BQU8sV0FDVDtFQUNGLE1BQU0sUUFBUSxNQUFNLFFBQVEsRUFBRSxJQUFJLEdBQUcsSUFBSSxPQUFPLElBQUksUUFBUSxFQUFFO0VBQzlELENBQUMsS0FBSyxRQUFRLGNBQWMsT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLE9BQU87RUFDM0QsTUFBTSxrQkFBa0IsV0FBVyxVQUFVLE9BQU8sT0FBTztHQUN6RCxHQUFHO0dBQ0gsYUFBYTtJQUNYLElBQUk7SUFDSixPQUFPLE9BQU8sZUFBZSxNQUFNLFFBQVEsVUFBVSxPQUFPLEtBQUssSUFBSSxJQUFJLEtBQUssT0FBTztHQUN2RjtFQUNGLENBQUM7RUFDRCxDQUFDLEtBQUssUUFBUSxlQUFlLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxPQUFPO0NBQzlELEdBQUcsRUFBRSxNQUFNLEtBQUssQ0FBQztDQUNqQixZQUFZLFFBQVEsUUFBUSxRQUFRLElBQUksYUFBYTtFQUNuRCxJQUFJLFVBQVU7R0FDWjtHQUNBLFVBQVUsUUFBUSxVQUFVO0VBQzlCO0NBQ0YsQ0FBQztDQUNELHdCQUF3QjtFQUN0QjtDQUNGLENBQUM7Q0FDRCxPQUFPLGVBQWUsUUFBUSxRQUFRLFFBQVEsSUFBSSxVQUFVLElBQUksVUFBVSxLQUFLO0FBQ2pGO0FBRUEsU0FBUyxtQkFBbUIsT0FBTyxXQUFXLFVBQVUsQ0FBQyxHQUFHO0NBQzFELE1BQU0sRUFDSixlQUFlLENBQUMsR0FDaEIsc0JBQXNCLE1BQ3RCLG9CQUFvQixPQUNwQixPQUFPLGNBQWMsTUFDckIsWUFBWSxXQUNaLFNBQVMsZUFDVCxhQUFhLFdBQVcsT0FBTyxTQUFTLE1BQ3RDO0NBQ0osSUFBSSxDQUFDLFFBQ0gsT0FBTyxTQUFTLFlBQVk7Q0FDOUIsTUFBTSxRQUFRLFNBQVMsQ0FBQyxDQUFDO0NBQ3pCLFNBQVMsZUFBZTtFQUN0QixJQUFJLFNBQVMsV0FBVztHQUN0QixPQUFPLE9BQU8sU0FBUyxVQUFVO0VBQ25DLE9BQU8sSUFBSSxTQUFTLFFBQVE7R0FDMUIsTUFBTSxPQUFPLE9BQU8sU0FBUyxRQUFRO0dBQ3JDLE1BQU0sUUFBUSxLQUFLLFFBQVEsR0FBRztHQUM5QixPQUFPLFFBQVEsSUFBSSxLQUFLLE1BQU0sS0FBSyxJQUFJO0VBQ3pDLE9BQU87R0FDTCxRQUFRLE9BQU8sU0FBUyxRQUFRLEdBQUUsQ0FBRSxRQUFRLE1BQU0sRUFBRTtFQUN0RDtDQUNGO0NBQ0EsU0FBUyxlQUFlLFFBQVE7RUFDOUIsTUFBTSxjQUFjLFVBQVUsTUFBTTtFQUNwQyxJQUFJLFNBQVMsV0FDWCxPQUFPLEdBQUcsY0FBYyxJQUFJLGdCQUFnQixLQUFLLE9BQU8sU0FBUyxRQUFRO0VBQzNFLElBQUksU0FBUyxlQUNYLE9BQU8sR0FBRyxPQUFPLFNBQVMsVUFBVSxLQUFLLGNBQWMsSUFBSSxnQkFBZ0I7RUFDN0UsTUFBTSxPQUFPLE9BQU8sU0FBUyxRQUFRO0VBQ3JDLE1BQU0sUUFBUSxLQUFLLFFBQVEsR0FBRztFQUM5QixJQUFJLFFBQVEsR0FDVixPQUFPLEdBQUcsT0FBTyxTQUFTLFVBQVUsS0FBSyxLQUFLLE1BQU0sR0FBRyxLQUFLLElBQUksY0FBYyxJQUFJLGdCQUFnQjtFQUNwRyxPQUFPLEdBQUcsT0FBTyxTQUFTLFVBQVUsS0FBSyxPQUFPLGNBQWMsSUFBSSxnQkFBZ0I7Q0FDcEY7Q0FDQSxTQUFTLE9BQU87RUFDZCxPQUFPLElBQUksZ0JBQWdCLGFBQWEsQ0FBQztDQUMzQztDQUNBLFNBQVMsWUFBWSxRQUFRO0VBQzNCLE1BQU0sYUFBYSxJQUFJLElBQUksT0FBTyxLQUFLLEtBQUssQ0FBQztFQUM3QyxLQUFLLE1BQU0sT0FBTyxPQUFPLEtBQUssR0FBRztHQUMvQixNQUFNLGVBQWUsT0FBTyxPQUFPLEdBQUc7R0FDdEMsTUFBTSxPQUFPLGFBQWEsU0FBUyxJQUFJLGVBQWUsT0FBTyxJQUFJLEdBQUcsS0FBSztHQUN6RSxXQUFXLE9BQU8sR0FBRztFQUN2QjtFQUNBLE1BQU0sS0FBSyxVQUFVLENBQUMsQ0FBQyxTQUFTLFFBQVEsT0FBTyxNQUFNLElBQUk7Q0FDM0Q7Q0FDQSxNQUFNLEVBQUUsT0FBTyxXQUFXLGNBQ3hCLGFBQ007RUFDSixNQUFNLFNBQVMsSUFBSSxnQkFBZ0IsRUFBRTtFQUNyQyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsU0FBUyxRQUFRO0dBQ2xDLE1BQU0sV0FBVyxNQUFNO0dBQ3ZCLElBQUksTUFBTSxRQUFRLFFBQVEsR0FDeEIsU0FBUyxTQUFTLFVBQVUsT0FBTyxPQUFPLEtBQUssS0FBSyxDQUFDO1FBQ2xELElBQUksdUJBQXVCLFlBQVksTUFDMUMsT0FBTyxPQUFPLEdBQUc7UUFDZCxJQUFJLHFCQUFxQixDQUFDLFVBQzdCLE9BQU8sT0FBTyxHQUFHO1FBRWpCLE9BQU8sSUFBSSxLQUFLLFFBQVE7RUFDNUIsQ0FBQztFQUNELE1BQU0sUUFBUSxLQUFLO0NBQ3JCLEdBQ0EsRUFBRSxNQUFNLEtBQUssQ0FDZjtDQUNBLFNBQVMsTUFBTSxRQUFRLGNBQWMscUJBQXFCLE1BQU07RUFDOUQsTUFBTTtFQUNOLElBQUksY0FDRixZQUFZLE1BQU07RUFDcEIsSUFBSSxjQUFjLFdBQVc7R0FDM0IsT0FBTyxRQUFRLGFBQ2IsT0FBTyxRQUFRLE9BQ2YsT0FBTyxTQUFTLE9BQ2hCLE9BQU8sU0FBUyxXQUFXLGVBQWUsTUFBTSxDQUNsRDtFQUNGLE9BQU87R0FDTCxJQUFJLG9CQUFvQjtJQUN0QixPQUFPLFFBQVEsVUFDYixPQUFPLFFBQVEsT0FDZixPQUFPLFNBQVMsT0FDaEIsT0FBTyxTQUFTLFdBQVcsZUFBZSxNQUFNLENBQ2xEO0dBQ0Y7RUFDRjtFQUNBLGVBQWUsT0FBTyxDQUFDO0NBQ3pCO0NBQ0EsU0FBUyxZQUFZO0VBQ25CLElBQUksQ0FBQyxhQUNIO0VBQ0YsTUFBTSxLQUFLLEdBQUcsTUFBTSxLQUFLO0NBQzNCO0NBQ0EsTUFBTSxrQkFBa0IsRUFBRSxTQUFTLEtBQUs7Q0FDeEMsaUJBQWlCLFFBQVEsWUFBWSxXQUFXLGVBQWU7Q0FDL0QsSUFBSSxTQUFTLFdBQ1gsaUJBQWlCLFFBQVEsY0FBYyxXQUFXLGVBQWU7Q0FDbkUsTUFBTSxVQUFVLEtBQUs7Q0FDckIsSUFBSSxRQUFRLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQ3hCLFlBQVksT0FBTztNQUVuQixPQUFPLE9BQU8sT0FBTyxZQUFZO0NBQ25DLE9BQU87QUFDVDtBQUVBLFNBQVMsYUFBYSxVQUFVLENBQUMsR0FBRztDQUNsQyxJQUFJLElBQUk7Q0FDUixNQUFNLFVBQVUsWUFBWSxLQUFLLFFBQVEsWUFBWSxPQUFPLEtBQUssS0FBSztDQUN0RSxNQUFNLGFBQWEsWUFBWSxLQUFLLFFBQVEsZUFBZSxPQUFPLEtBQUssSUFBSTtDQUMzRSxNQUFNLGNBQWMsSUFBSSxRQUFRLFdBQVc7Q0FDM0MsTUFBTSxFQUFFLFlBQVkscUJBQXFCO0NBQ3pDLE1BQU0sY0FBYyxtQkFBbUI7RUFDckMsSUFBSTtFQUNKLFFBQVEsTUFBTSxhQUFhLE9BQU8sS0FBSyxJQUFJLFVBQVUsaUJBQWlCLE9BQU8sS0FBSyxJQUFJLElBQUk7Q0FDNUYsQ0FBQztDQUNELE1BQU0sU0FBUyxXQUFXO0NBQzFCLFNBQVMsaUJBQWlCLE1BQU07RUFDOUIsUUFBUSxNQUFSO0dBQ0UsS0FBSyxTQUFTO0lBQ1osSUFBSSxZQUFZLE9BQ2QsT0FBTyxZQUFZLE1BQU0sU0FBUztJQUNwQztHQUNGO0dBQ0EsS0FBSyxTQUFTO0lBQ1osSUFBSSxZQUFZLE9BQ2QsT0FBTyxZQUFZLE1BQU0sU0FBUztJQUNwQztHQUNGO0VBQ0Y7Q0FDRjtDQUNBLGVBQWUsU0FBUztFQUN0QixJQUFJLENBQUMsWUFBWSxTQUFTLE9BQU8sT0FDL0I7RUFDRixPQUFPLFFBQVEsTUFBTSxVQUFVLGFBQWEsYUFBYTtHQUN2RCxPQUFPLGlCQUFpQixPQUFPO0dBQy9CLE9BQU8saUJBQWlCLE9BQU87RUFDakMsQ0FBQztFQUNELE9BQU8sT0FBTztDQUNoQjtDQUNBLFNBQVMsUUFBUTtFQUNmLElBQUk7RUFDSixDQUFDLE1BQU0sT0FBTyxVQUFVLE9BQU8sS0FBSyxJQUFJLElBQUksVUFBVSxDQUFDLENBQUMsU0FBUyxNQUFNLEVBQUUsS0FBSyxDQUFDO0VBQy9FLE9BQU8sUUFBUSxLQUFLO0NBQ3RCO0NBQ0EsU0FBUyxPQUFPO0VBQ2QsTUFBTTtFQUNOLFFBQVEsUUFBUTtDQUNsQjtDQUNBLGVBQWUsUUFBUTtFQUNyQixNQUFNLE9BQU87RUFDYixJQUFJLE9BQU8sT0FDVCxRQUFRLFFBQVE7RUFDbEIsT0FBTyxPQUFPO0NBQ2hCO0NBQ0EsZUFBZSxVQUFVO0VBQ3ZCLE1BQU07RUFDTixPQUFPLE1BQU0sTUFBTTtDQUNyQjtDQUNBLE1BQ0UsVUFDQyxNQUFNO0VBQ0wsSUFBSSxHQUNGLE9BQU87T0FDSixNQUFNO0NBQ2IsR0FDQSxFQUFFLFdBQVcsS0FBSyxDQUNwQjtDQUNBLE1BQ0UsbUJBQ007RUFDSixJQUFJLFdBQVcsU0FBUyxPQUFPLE9BQzdCLFFBQVE7Q0FDWixHQUNBLEVBQUUsV0FBVyxLQUFLLENBQ3BCO0NBQ0Esd0JBQXdCO0VBQ3RCLEtBQUs7Q0FDUCxDQUFDO0NBQ0QsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGOztBQUdBLFNBQVMsVUFBVSxPQUFPLEtBQUssTUFBTSxVQUFVLENBQUMsR0FBRztDQUNqRCxJQUFJLElBQUksSUFBSTtDQUNaLE1BQU0sRUFDSixRQUFRLE9BQ1IsVUFBVSxPQUNWLFdBQ0EsT0FBTyxPQUNQLGNBQ0EsZUFDRTtDQUNKLE1BQU0sS0FBSyxtQkFBbUI7Q0FDOUIsTUFBTSxRQUFRLFNBQVMsTUFBTSxPQUFPLEtBQUssSUFBSSxHQUFHLFdBQVcsS0FBSyxNQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsVUFBVSxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssRUFBRSxRQUFRLE1BQU0sS0FBSyxNQUFNLE9BQU8sS0FBSyxJQUFJLEdBQUcsVUFBVSxPQUFPLEtBQUssSUFBSSxHQUFHLFVBQVUsT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLLE1BQU0sT0FBTyxLQUFLLElBQUksR0FBRyxLQUFLO0NBQ3RRLElBQUksUUFBUTtDQUNaLElBQUksQ0FBQyxLQUFLO0VBQ1IsTUFBTTtDQUNSO0NBQ0EsUUFBUSxTQUFTLFVBQVUsSUFBSSxTQUFTO0NBQ3hDLE1BQU0sV0FBVyxRQUFRLENBQUMsUUFBUSxNQUFNLE9BQU8sVUFBVSxhQUFhLE1BQU0sR0FBRyxJQUFJLFlBQVksR0FBRztDQUNsRyxNQUFNLGlCQUFpQixNQUFNLE1BQU0sSUFBSSxJQUFJLFFBQVEsTUFBTSxJQUFJLElBQUk7Q0FDakUsTUFBTSxlQUFlLFVBQVU7RUFDN0IsSUFBSSxZQUFZO0dBQ2QsSUFBSSxXQUFXLEtBQUssR0FDbEIsTUFBTSxPQUFPLEtBQUs7RUFDdEIsT0FBTztHQUNMLE1BQU0sT0FBTyxLQUFLO0VBQ3BCO0NBQ0Y7Q0FDQSxJQUFJLFNBQVM7RUFDWCxNQUFNLGVBQWUsU0FBUztFQUM5QixNQUFNLFFBQVEsSUFBSSxZQUFZO0VBQzlCLElBQUksYUFBYTtFQUNqQixZQUNRLE1BQU0sT0FDWCxNQUFNO0dBQ0wsSUFBSSxDQUFDLFlBQVk7SUFDZixhQUFhO0lBQ2IsTUFBTSxRQUFRLFFBQVEsQ0FBQztJQUN2QixlQUFlLGFBQWEsS0FBSztHQUNuQztFQUNGLENBQ0Y7RUFDQSxNQUNFLFFBQ0MsTUFBTTtHQUNMLElBQUksQ0FBQyxlQUFlLE1BQU0sTUFBTSxRQUFRLE9BQ3RDLFlBQVksQ0FBQztFQUNqQixHQUNBLEVBQUUsS0FBSyxDQUNUO0VBQ0EsT0FBTztDQUNULE9BQU87RUFDTCxPQUFPLFNBQVM7R0FDZCxNQUFNO0lBQ0osT0FBTyxTQUFTO0dBQ2xCO0dBQ0EsSUFBSSxPQUFPO0lBQ1QsWUFBWSxLQUFLO0dBQ25CO0VBQ0YsQ0FBQztDQUNIO0FBQ0Y7O0FBR0EsU0FBUyxXQUFXLE9BQU8sTUFBTSxVQUFVLENBQUMsR0FBRztDQUM3QyxNQUFNLE1BQU0sQ0FBQztDQUNiLEtBQUssTUFBTSxPQUFPLE9BQU87RUFDdkIsSUFBSSxPQUFPLFVBQ1QsT0FDQSxLQUNBLE1BQ0EsT0FDRjtDQUNGO0NBQ0EsT0FBTztBQUNUOztBQUdBLFNBQVMsV0FBVyxTQUFTO0NBQzNCLE1BQU0sRUFDSixVQUFVLENBQUMsR0FDWCxXQUFXLEdBQ1gsWUFBWSxxQkFDVixXQUFXLENBQUM7Q0FDaEIsTUFBTSxjQUFjLG1CQUFtQixPQUFPLGNBQWMsZUFBZSxhQUFhLFNBQVM7Q0FDakcsTUFBTSxhQUFhLE1BQU0sT0FBTztDQUNoQyxJQUFJO0NBQ0osTUFBTSxXQUFXLFdBQVcsV0FBVyxVQUFVO0VBQy9DLElBQUksWUFBWSxPQUNkLFVBQVUsUUFBUSxRQUFRO0NBQzlCO0NBQ0EsTUFBTSxhQUFhO0VBQ2pCLElBQUksWUFBWSxPQUNkLFVBQVUsUUFBUSxDQUFDO0VBQ3JCLG9CQUFvQixPQUFPLEtBQUssSUFBSSxpQkFBaUIsTUFBTTtDQUM3RDtDQUNBLElBQUksV0FBVyxHQUFHO0VBQ2hCLG1CQUFtQixjQUNqQixTQUNBLFVBQ0E7R0FDRSxXQUFXO0dBQ1gsbUJBQW1CO0VBQ3JCLENBQ0Y7Q0FDRjtDQUNBLE9BQU87RUFDTDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7QUFDRjtBQUVBLFNBQVMsZUFBZSxNQUFNLFNBQVM7Q0FDckMsTUFBTSxFQUFFLGdCQUFnQixjQUFjLFVBQVUsZ0JBQWdCLGFBQWEsaUJBQWlCLGdCQUFnQixVQUFVLHVCQUF1QixTQUFTLElBQUksSUFBSSx5QkFBeUIsU0FBUyxJQUFJO0NBQ3RNLE9BQU87RUFDTCxNQUFNO0VBQ047RUFDQSxnQkFBZ0I7R0FDZCxLQUFLO0dBQ0wsZ0JBQWdCO0lBQ2QsZUFBZTtHQUNqQjtHQUNBLE9BQU87RUFDVDtFQUNBO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsd0JBQXdCLE1BQU07Q0FDckMsTUFBTSxlQUFlLFdBQVcsSUFBSTtDQUNwQyxNQUFNLE9BQU8sZUFBZSxZQUFZO0NBQ3hDLE1BQU0sY0FBYyxJQUFJLENBQUMsQ0FBQztDQUMxQixNQUFNLFNBQVMsV0FBVyxJQUFJO0NBQzlCLE1BQU0sUUFBUSxJQUFJO0VBQUUsT0FBTztFQUFHLEtBQUs7Q0FBRyxDQUFDO0NBQ3ZDLE9BQU87RUFBRTtFQUFPO0VBQVE7RUFBYTtFQUFNO0NBQWE7QUFDMUQ7QUFDQSxTQUFTLHNCQUFzQixPQUFPLFFBQVEsVUFBVTtDQUN0RCxRQUFRLGtCQUFrQjtFQUN4QixJQUFJLE9BQU8sYUFBYSxVQUN0QixPQUFPLEtBQUssS0FBSyxnQkFBZ0IsUUFBUTtFQUMzQyxNQUFNLEVBQUUsUUFBUSxNQUFNLE1BQU07RUFDNUIsSUFBSSxNQUFNO0VBQ1YsSUFBSSxXQUFXO0VBQ2YsS0FBSyxJQUFJLElBQUksT0FBTyxJQUFJLE9BQU8sTUFBTSxRQUFRLEtBQUs7R0FDaEQsTUFBTSxPQUFPLFNBQVMsQ0FBQztHQUN2QixPQUFPO0dBQ1AsV0FBVztHQUNYLElBQUksTUFBTSxlQUNSO0VBQ0o7RUFDQSxPQUFPLFdBQVc7Q0FDcEI7QUFDRjtBQUNBLFNBQVMsZ0JBQWdCLFFBQVEsVUFBVTtDQUN6QyxRQUFRLG9CQUFvQjtFQUMxQixJQUFJLE9BQU8sYUFBYSxVQUN0QixPQUFPLEtBQUssTUFBTSxrQkFBa0IsUUFBUSxJQUFJO0VBQ2xELElBQUksTUFBTTtFQUNWLElBQUksU0FBUztFQUNiLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLE1BQU0sUUFBUSxLQUFLO0dBQzVDLE1BQU0sT0FBTyxTQUFTLENBQUM7R0FDdkIsT0FBTztHQUNQLElBQUksT0FBTyxpQkFBaUI7SUFDMUIsU0FBUztJQUNUO0dBQ0Y7RUFDRjtFQUNBLE9BQU8sU0FBUztDQUNsQjtBQUNGO0FBQ0EsU0FBUyxxQkFBcUIsTUFBTSxVQUFVLFdBQVcsaUJBQWlCLEVBQUUsY0FBYyxPQUFPLGFBQWEsVUFBVTtDQUN0SCxhQUFhO0VBQ1gsTUFBTSxVQUFVLGFBQWE7RUFDN0IsSUFBSSxTQUFTO0dBQ1gsTUFBTSxTQUFTLFVBQVUsU0FBUyxhQUFhLFFBQVEsWUFBWSxRQUFRLFVBQVU7R0FDckYsTUFBTSxlQUFlLGdCQUFnQixTQUFTLGFBQWEsUUFBUSxlQUFlLFFBQVEsV0FBVztHQUNyRyxNQUFNLE9BQU8sU0FBUztHQUN0QixNQUFNLEtBQUssU0FBUyxlQUFlO0dBQ25DLE1BQU0sUUFBUTtJQUNaLE9BQU8sT0FBTyxJQUFJLElBQUk7SUFDdEIsS0FBSyxLQUFLLE9BQU8sTUFBTSxTQUFTLE9BQU8sTUFBTSxTQUFTO0dBQ3hEO0dBQ0EsWUFBWSxRQUFRLE9BQU8sTUFBTSxNQUFNLE1BQU0sTUFBTSxPQUFPLE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLEtBQUssV0FBVztJQUM5RixNQUFNO0lBQ04sT0FBTyxRQUFRLE1BQU0sTUFBTTtHQUM3QixFQUFFO0VBQ0o7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxrQkFBa0IsVUFBVSxRQUFRO0NBQzNDLFFBQVEsVUFBVTtFQUNoQixJQUFJLE9BQU8sYUFBYSxVQUFVO0dBQ2hDLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLE9BQU87RUFDVDtFQUNBLE1BQU0sT0FBTyxPQUFPLE1BQU0sTUFBTSxHQUFHLEtBQUssQ0FBQyxDQUFDLFFBQVEsS0FBSyxHQUFHLE1BQU0sTUFBTSxTQUFTLENBQUMsR0FBRyxDQUFDO0VBQ3BGLE9BQU87Q0FDVDtBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsTUFBTSxNQUFNLGNBQWMsZ0JBQWdCO0NBQ2xFLE1BQU07RUFBQyxLQUFLO0VBQU8sS0FBSztRQUFjLFFBQVEsSUFBSTtFQUFHO0NBQVksU0FBUztFQUN4RSxlQUFlO0NBQ2pCLENBQUM7QUFDSDtBQUNBLFNBQVMsd0JBQXdCLFVBQVUsUUFBUTtDQUNqRCxPQUFPLGVBQWU7RUFDcEIsSUFBSSxPQUFPLGFBQWEsVUFDdEIsT0FBTyxPQUFPLE1BQU0sU0FBUztFQUMvQixPQUFPLE9BQU8sTUFBTSxRQUFRLEtBQUssR0FBRyxVQUFVLE1BQU0sU0FBUyxLQUFLLEdBQUcsQ0FBQztDQUN4RSxDQUFDO0FBQ0g7QUFDQSxNQUFNLHdDQUF3QztDQUM1QyxZQUFZO0NBQ1osVUFBVTtBQUNaO0FBQ0EsU0FBUyxlQUFlLE1BQU0sZ0JBQWdCLGFBQWEsY0FBYztDQUN2RSxRQUFRLFVBQVU7RUFDaEIsSUFBSSxhQUFhLE9BQU87R0FDdEIsYUFBYSxNQUFNLHNDQUFzQyxTQUFTLFlBQVksS0FBSztHQUNuRixlQUFlO0VBQ2pCO0NBQ0Y7QUFDRjtBQUNBLFNBQVMseUJBQXlCLFNBQVMsTUFBTTtDQUMvQyxNQUFNLFlBQVksd0JBQXdCLElBQUk7Q0FDOUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxhQUFhLE1BQU0saUJBQWlCO0NBQzNELE1BQU0saUJBQWlCLEVBQUUsV0FBVyxPQUFPO0NBQzNDLE1BQU0sRUFBRSxXQUFXLFdBQVcsTUFBTTtDQUNwQyxNQUFNLGtCQUFrQixzQkFBc0IsT0FBTyxRQUFRLFNBQVM7Q0FDdEUsTUFBTSxZQUFZLGdCQUFnQixRQUFRLFNBQVM7Q0FDbkQsTUFBTSxpQkFBaUIscUJBQXFCLGNBQWMsVUFBVSxXQUFXLGlCQUFpQixTQUFTO0NBQ3pHLE1BQU0sa0JBQWtCLGtCQUFrQixXQUFXLE1BQU07Q0FDM0QsTUFBTSxhQUFhLGVBQWUsZ0JBQWdCLE1BQU0sTUFBTSxLQUFLLENBQUM7Q0FDcEUsTUFBTSxhQUFhLHdCQUF3QixXQUFXLE1BQU07Q0FDNUQsaUJBQWlCLE1BQU0sTUFBTSxjQUFjLGNBQWM7Q0FDekQsTUFBTSxXQUFXLGVBQWUsY0FBYyxnQkFBZ0IsaUJBQWlCLFlBQVk7Q0FDM0YsTUFBTSxlQUFlLGVBQWU7RUFDbEMsT0FBTyxFQUNMLE9BQU87R0FDTCxRQUFRO0dBQ1IsT0FBTyxHQUFHLFdBQVcsUUFBUSxXQUFXLE1BQU07R0FDOUMsWUFBWSxHQUFHLFdBQVcsTUFBTTtHQUNoQyxTQUFTO0VBQ1gsRUFDRjtDQUNGLENBQUM7Q0FDRCxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsdUJBQXVCLFNBQVMsTUFBTTtDQUM3QyxNQUFNLFlBQVksd0JBQXdCLElBQUk7Q0FDOUMsTUFBTSxFQUFFLE9BQU8sUUFBUSxhQUFhLE1BQU0saUJBQWlCO0NBQzNELE1BQU0saUJBQWlCLEVBQUUsV0FBVyxPQUFPO0NBQzNDLE1BQU0sRUFBRSxZQUFZLFdBQVcsTUFBTTtDQUNyQyxNQUFNLGtCQUFrQixzQkFBc0IsT0FBTyxRQUFRLFVBQVU7Q0FDdkUsTUFBTSxZQUFZLGdCQUFnQixRQUFRLFVBQVU7Q0FDcEQsTUFBTSxpQkFBaUIscUJBQXFCLFlBQVksVUFBVSxXQUFXLGlCQUFpQixTQUFTO0NBQ3ZHLE1BQU0saUJBQWlCLGtCQUFrQixZQUFZLE1BQU07Q0FDM0QsTUFBTSxZQUFZLGVBQWUsZUFBZSxNQUFNLE1BQU0sS0FBSyxDQUFDO0NBQ2xFLE1BQU0sY0FBYyx3QkFBd0IsWUFBWSxNQUFNO0NBQzlELGlCQUFpQixNQUFNLE1BQU0sY0FBYyxjQUFjO0NBQ3pELE1BQU0sV0FBVyxlQUFlLFlBQVksZ0JBQWdCLGdCQUFnQixZQUFZO0NBQ3hGLE1BQU0sZUFBZSxlQUFlO0VBQ2xDLE9BQU8sRUFDTCxPQUFPO0dBQ0wsT0FBTztHQUNQLFFBQVEsR0FBRyxZQUFZLFFBQVEsVUFBVSxNQUFNO0dBQy9DLFdBQVcsR0FBRyxVQUFVLE1BQU07RUFDaEMsRUFDRjtDQUNGLENBQUM7Q0FDRCxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7QUFDRjs7QUFHQSxTQUFTLFlBQVksVUFBVSxDQUFDLEdBQUc7Q0FDakMsTUFBTSxFQUNKLFlBQVksa0JBQ1osV0FBVyxvQkFDVDtDQUNKLE1BQU0sZ0JBQWdCLFdBQVcsS0FBSztDQUN0QyxNQUFNLFdBQVcsV0FBVyxJQUFJO0NBQ2hDLE1BQU0scUJBQXFCLHNCQUFzQixFQUFFLFNBQVMsQ0FBQztDQUM3RCxNQUFNLGNBQWMsbUJBQW1CLGFBQWEsY0FBYyxTQUFTO0NBQzNFLE1BQU0sV0FBVyxlQUFlLENBQUMsQ0FBQyxTQUFTLFNBQVMsbUJBQW1CLFVBQVUsU0FBUztDQUMxRixJQUFJLFlBQVksT0FBTztFQUNyQixpQkFBaUIsVUFBVSxpQkFBaUI7R0FDMUMsSUFBSSxJQUFJO0dBQ1IsY0FBYyxTQUFTLE1BQU0sS0FBSyxTQUFTLFVBQVUsT0FBTyxLQUFLLElBQUksR0FBRyxTQUFTLE9BQU8sS0FBSztFQUMvRixHQUFHLEVBQUUsU0FBUyxLQUFLLENBQUM7RUFDcEIsZUFDUSxtQkFBbUIsVUFBVSxjQUFjLFlBQVksT0FBTyxLQUFLLElBQUksU0FBUyxxQkFBcUIsYUFBYSxjQUFjLFFBQ3JJLFNBQVM7R0FDUixjQUFjLFFBQVE7R0FDdEIsYUFBYSxJQUFJO0VBQ25CLENBQ0Y7Q0FDRjtDQUNBLGVBQWUsYUFBYSxNQUFNO0VBQ2hDLElBQUk7RUFDSixRQUFRLEtBQUssU0FBUyxVQUFVLE9BQU8sS0FBSyxJQUFJLEdBQUcsUUFBUTtFQUMzRCxTQUFTLFFBQVEsWUFBWSxRQUFRLE1BQU0sVUFBVSxTQUFTLFFBQVEsSUFBSSxJQUFJO0NBQ2hGO0NBQ0EsZUFBZSxRQUFRLE1BQU07RUFDM0IsSUFBSSxtQkFBbUIsVUFBVSxXQUMvQixNQUFNLGFBQWEsSUFBSTtPQUV2QixjQUFjLFFBQVE7Q0FDMUI7Q0FDQSxlQUFlLFVBQVU7RUFDdkIsY0FBYyxRQUFRO0VBQ3RCLE1BQU0sSUFBSSxTQUFTO0VBQ25CLFNBQVMsUUFBUTtFQUNqQixPQUFPLEtBQUssT0FBTyxLQUFLLElBQUksRUFBRSxRQUFRO0NBQ3hDO0NBQ0EsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGO0FBQ0Y7QUFFQSxTQUFTLG1CQUFtQixVQUFVLENBQUMsR0FBRztDQUN4QyxNQUFNLEVBQ0osU0FBUyxlQUNULG9CQUFvQix5QkFBeUIsU0FDM0M7Q0FDSixNQUFNLGdDQUFnQztDQUN0QyxNQUFNLGNBQWMsbUJBQW1CO0VBQ3JDLElBQUksQ0FBQyxVQUFVLEVBQUUsa0JBQWtCLFNBQ2pDLE9BQU87RUFDVCxJQUFJLGFBQWEsZUFBZSxXQUM5QixPQUFPO0VBQ1QsSUFBSTtHQUNGLE1BQU0sZ0JBQWdCLElBQUksYUFBYSxFQUFFO0dBQ3pDLGNBQWMsZUFBZTtJQUMzQixjQUFjLE1BQU07R0FDdEI7RUFDRixTQUFTLEdBQUc7R0FDVixJQUFJLEVBQUUsU0FBUyxhQUNiLE9BQU87RUFDWDtFQUNBLE9BQU87Q0FDVCxDQUFDO0NBQ0QsTUFBTSxvQkFBb0IsV0FBVyxZQUFZLFNBQVMsZ0JBQWdCLGdCQUFnQixhQUFhLGVBQWUsU0FBUztDQUMvSCxNQUFNLGVBQWUsSUFBSSxJQUFJO0NBQzdCLE1BQU0sb0JBQW9CLFlBQVk7RUFDcEMsSUFBSSxDQUFDLFlBQVksT0FDZjtFQUNGLElBQUksQ0FBQyxrQkFBa0IsU0FBUyxhQUFhLGVBQWUsVUFBVTtHQUNwRSxNQUFNLFNBQVMsTUFBTSxhQUFhLGtCQUFrQjtHQUNwRCxJQUFJLFdBQVcsV0FDYixrQkFBa0IsUUFBUTtFQUM5QjtFQUNBLE9BQU8sa0JBQWtCO0NBQzNCO0NBQ0EsTUFBTSxFQUFFLElBQUksU0FBUyxTQUFTLGlCQUFpQixnQkFBZ0I7Q0FDL0QsTUFBTSxFQUFFLElBQUksUUFBUSxTQUFTLGdCQUFnQixnQkFBZ0I7Q0FDN0QsTUFBTSxFQUFFLElBQUksU0FBUyxTQUFTLGlCQUFpQixnQkFBZ0I7Q0FDL0QsTUFBTSxFQUFFLElBQUksU0FBUyxTQUFTLGlCQUFpQixnQkFBZ0I7Q0FDL0QsTUFBTSxPQUFPLE9BQU8sY0FBYztFQUNoQyxJQUFJLENBQUMsWUFBWSxTQUFTLENBQUMsa0JBQWtCLE9BQzNDO0VBQ0YsTUFBTSxXQUFXLE9BQU8sT0FBTyxDQUFDLEdBQUcsK0JBQStCLFNBQVM7RUFDM0UsYUFBYSxRQUFRLElBQUksYUFBYSxTQUFTLFNBQVMsSUFBSSxRQUFRO0VBQ3BFLGFBQWEsTUFBTSxVQUFVO0VBQzdCLGFBQWEsTUFBTSxTQUFTO0VBQzVCLGFBQWEsTUFBTSxVQUFVO0VBQzdCLGFBQWEsTUFBTSxVQUFVO0VBQzdCLE9BQU8sYUFBYTtDQUN0QjtDQUNBLE1BQU0sY0FBYztFQUNsQixJQUFJLGFBQWEsT0FDZixhQUFhLE1BQU0sTUFBTTtFQUMzQixhQUFhLFFBQVE7Q0FDdkI7Q0FDQSxJQUFJLHdCQUNGLGFBQWEsaUJBQWlCO0NBQ2hDLGtCQUFrQixLQUFLO0NBQ3ZCLElBQUksWUFBWSxTQUFTLFFBQVE7RUFDL0IsTUFBTSxXQUFXLE9BQU87RUFDeEIsaUJBQWlCLFVBQVUscUJBQXFCLE1BQU07R0FDcEQsRUFBRSxlQUFlO0dBQ2pCLElBQUksU0FBUyxvQkFBb0IsV0FBVztJQUMxQyxNQUFNO0dBQ1I7RUFDRixDQUFDO0NBQ0g7Q0FDQSxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsTUFBTSx1QkFBdUI7QUFDN0IsU0FBUyxxQkFBcUIsU0FBUztDQUNyQyxJQUFJLFlBQVksTUFDZCxPQUFPLENBQUM7Q0FDVixPQUFPO0FBQ1Q7QUFDQSxTQUFTLGFBQWEsS0FBSyxVQUFVLENBQUMsR0FBRztDQUN2QyxNQUFNLEVBQ0osYUFDQSxnQkFDQSxTQUNBLFdBQ0EsWUFBWSxNQUNaLGNBQWMsTUFDZCxZQUFZLE1BQ1osWUFBWSxDQUFDLE1BQ1g7Q0FDSixNQUFNLE9BQU8sSUFBSSxJQUFJO0NBQ3JCLE1BQU0sU0FBUyxXQUFXLFFBQVE7Q0FDbEMsTUFBTSxRQUFRLElBQUk7Q0FDbEIsTUFBTSxTQUFTLE1BQU0sR0FBRztDQUN4QixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUksbUJBQW1CO0NBQ3ZCLElBQUksVUFBVTtDQUNkLElBQUksZUFBZSxDQUFDO0NBQ3BCLElBQUk7Q0FDSixJQUFJO0NBQ0osTUFBTSxvQkFBb0I7RUFDeEIsSUFBSSxhQUFhLFVBQVUsTUFBTSxTQUFTLE9BQU8sVUFBVSxRQUFRO0dBQ2pFLEtBQUssTUFBTSxVQUFVLGNBQ25CLE1BQU0sTUFBTSxLQUFLLE1BQU07R0FDekIsZUFBZSxDQUFDO0VBQ2xCO0NBQ0Y7Q0FDQSxNQUFNLG1CQUFtQjtFQUN2QixJQUFJLGdCQUFnQixNQUFNO0dBQ3hCLGFBQWEsWUFBWTtHQUN6QixlQUFlLEtBQUs7RUFDdEI7Q0FDRjtDQUNBLE1BQU0sdUJBQXVCO0VBQzNCLGFBQWEsZUFBZTtFQUM1QixrQkFBa0IsS0FBSztDQUN6QjtDQUNBLE1BQU0sU0FBUyxPQUFPLEtBQUssV0FBVztFQUNwQyxXQUFXO0VBQ1gsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsTUFBTSxPQUNuQztFQUNGLG1CQUFtQjtFQUNuQixlQUFlO0VBQ2Ysa0JBQWtCLE9BQU8sS0FBSyxJQUFJLGVBQWU7RUFDakQsTUFBTSxNQUFNLE1BQU0sTUFBTSxNQUFNO0VBQzlCLE1BQU0sUUFBUSxLQUFLO0NBQ3JCO0NBQ0EsTUFBTSxRQUFRLE9BQU8sWUFBWSxTQUFTO0VBQ3hDLElBQUksQ0FBQyxNQUFNLFNBQVMsT0FBTyxVQUFVLFFBQVE7R0FDM0MsSUFBSSxXQUNGLGFBQWEsS0FBSyxLQUFLO0dBQ3pCLE9BQU87RUFDVDtFQUNBLFlBQVk7RUFDWixNQUFNLE1BQU0sS0FBSyxLQUFLO0VBQ3RCLE9BQU87Q0FDVDtDQUNBLE1BQU0sY0FBYztFQUNsQixJQUFJLG9CQUFvQixPQUFPLE9BQU8sVUFBVSxhQUM5QztFQUNGLE1BQU0sS0FBSyxJQUFJLFVBQVUsT0FBTyxPQUFPLFNBQVM7RUFDaEQsTUFBTSxRQUFRO0VBQ2QsT0FBTyxRQUFRO0VBQ2YsR0FBRyxlQUFlO0dBQ2hCLE9BQU8sUUFBUTtHQUNmLFVBQVU7R0FDVixlQUFlLE9BQU8sS0FBSyxJQUFJLFlBQVksRUFBRTtHQUM3QyxtQkFBbUIsT0FBTyxLQUFLLElBQUksZ0JBQWdCO0dBQ25ELFlBQVk7RUFDZDtFQUNBLEdBQUcsV0FBVyxPQUFPO0dBQ25CLE9BQU8sUUFBUTtHQUNmLGVBQWU7R0FDZixrQkFBa0IsT0FBTyxLQUFLLElBQUksZUFBZTtHQUNqRCxrQkFBa0IsT0FBTyxLQUFLLElBQUksZUFBZSxJQUFJLEVBQUU7R0FDdkQsSUFBSSxDQUFDLG9CQUFvQixRQUFRLGtCQUFrQixNQUFNLFNBQVMsUUFBUSxPQUFPLE1BQU0sUUFBUTtJQUM3RixNQUFNLEVBQ0osVUFBVSxDQUFDLEdBQ1gsUUFBUSxLQUNSLGFBQ0UscUJBQXFCLFFBQVEsYUFBYTtJQUM5QyxNQUFNLGVBQWUsT0FBTyxZQUFZLGFBQWEsZ0JBQWdCLE9BQU8sWUFBWSxhQUFhLFVBQVUsS0FBSyxVQUFVO0lBQzlILElBQUksYUFBYSxPQUFPLEdBQUc7S0FDekIsV0FBVztLQUNYLGVBQWUsV0FBVyxPQUFPLEtBQUs7SUFDeEMsT0FBTztLQUNMLFlBQVksT0FBTyxLQUFLLElBQUksU0FBUztJQUN2QztHQUNGO0VBQ0Y7RUFDQSxHQUFHLFdBQVcsTUFBTTtHQUNsQixXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsSUFBSSxDQUFDO0VBQzFDO0VBQ0EsR0FBRyxhQUFhLE1BQU07R0FDcEIsSUFBSSxRQUFRLFdBQVc7SUFDckIsZUFBZTtJQUNmLE1BQU0sRUFDSixVQUFVLHNCQUNWLGtCQUFrQixZQUNoQixxQkFBcUIsUUFBUSxTQUFTO0lBQzFDLElBQUksRUFBRSxTQUFTLFFBQVEsZUFBZSxHQUNwQztHQUNKO0dBQ0EsS0FBSyxRQUFRLEVBQUU7R0FDZixhQUFhLE9BQU8sS0FBSyxJQUFJLFVBQVUsSUFBSSxDQUFDO0VBQzlDO0NBQ0Y7Q0FDQSxJQUFJLFFBQVEsV0FBVztFQUNyQixNQUFNLEVBQ0osVUFBVSxzQkFDVixXQUFXLEtBQ1gsY0FBYyxRQUNaLHFCQUFxQixRQUFRLFNBQVM7RUFDMUMsTUFBTSxFQUFFLE9BQU8sV0FBVyxvQkFDbEI7R0FDSixLQUFLLFFBQVEsT0FBTyxHQUFHLEtBQUs7R0FDNUIsSUFBSSxtQkFBbUIsTUFDckI7R0FDRixrQkFBa0IsaUJBQWlCO0lBQ2pDLE1BQU07SUFDTixtQkFBbUI7R0FDckIsR0FBRyxXQUFXO0VBQ2hCLEdBQ0EsVUFDQSxFQUFFLFdBQVcsTUFBTSxDQUNyQjtFQUNBLGlCQUFpQjtFQUNqQixrQkFBa0I7Q0FDcEI7Q0FDQSxJQUFJLFdBQVc7RUFDYixJQUFJLFVBQ0YsaUJBQWlCLHNCQUFzQixNQUFNLEdBQUcsRUFBRSxTQUFTLEtBQUssQ0FBQztFQUNuRSxrQkFBa0IsS0FBSztDQUN6QjtDQUNBLE1BQU0sYUFBYTtFQUNqQixJQUFJLENBQUMsWUFBWSxDQUFDLFVBQ2hCO0VBQ0YsTUFBTTtFQUNOLG1CQUFtQjtFQUNuQixVQUFVO0VBQ1YsTUFBTTtDQUNSO0NBQ0EsSUFBSSxXQUNGLEtBQUs7Q0FDUCxJQUFJLGFBQ0YsTUFBTSxRQUFRLElBQUk7Q0FDcEIsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFJO0NBQ047QUFDRjtBQUVBLFNBQVMsYUFBYSxNQUFNLGVBQWUsU0FBUztDQUNsRCxNQUFNLEVBQ0osU0FBUyxrQkFDUCxXQUFXLE9BQU8sVUFBVSxDQUFDO0NBQ2pDLE1BQU0sT0FBTyxJQUFJLElBQUk7Q0FDckIsTUFBTSxTQUFTLFdBQVc7Q0FDMUIsTUFBTSxRQUFRLEdBQUcsU0FBUztFQUN4QixJQUFJLENBQUMsT0FBTyxPQUNWO0VBQ0YsT0FBTyxNQUFNLFlBQVksR0FBRyxJQUFJO0NBQ2xDO0NBQ0EsTUFBTSxZQUFZLFNBQVMsYUFBYTtFQUN0QyxJQUFJLENBQUMsT0FBTyxPQUNWO0VBQ0YsT0FBTyxNQUFNLFVBQVU7Q0FDekI7Q0FDQSxJQUFJLFFBQVE7RUFDVixJQUFJLE9BQU8sU0FBUyxVQUNsQixPQUFPLFFBQVEsSUFBSSxPQUFPLE1BQU0sYUFBYTtPQUMxQyxJQUFJLE9BQU8sU0FBUyxZQUN2QixPQUFPLFFBQVEsS0FBSztPQUVwQixPQUFPLFFBQVE7RUFDakIsT0FBTyxNQUFNLGFBQWEsTUFBTTtHQUM5QixLQUFLLFFBQVEsRUFBRTtFQUNqQjtFQUNBLHdCQUF3QjtHQUN0QixJQUFJLE9BQU8sT0FDVCxPQUFPLE1BQU0sVUFBVTtFQUMzQixDQUFDO0NBQ0g7Q0FDQSxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBRUEsU0FBUyxXQUFXLE1BQU0sV0FBVztDQUNuQyxJQUFJLEtBQUssV0FBVyxLQUFLLFVBQVUsV0FBVyxHQUM1QyxPQUFPO0NBQ1QsTUFBTSxhQUFhLEtBQUssS0FBSyxRQUFRLElBQUksSUFBSSxFQUFFLENBQUMsQ0FBQyxTQUFTO0NBQzFELE1BQU0scUJBQXFCLFVBQVUsUUFBUSxRQUFRLE9BQU8sUUFBUSxVQUFVLENBQUMsQ0FBQyxLQUFLLE9BQU87RUFDMUYsTUFBTSxNQUFNLEdBQUcsU0FBUztFQUN4QixJQUFJLElBQUksS0FBSyxDQUFDLENBQUMsV0FBVyxVQUFVLEdBQUc7R0FDckMsT0FBTztFQUNULE9BQU87R0FDTCxNQUFNLE9BQU8sR0FBRztHQUNoQixPQUFPLFNBQVMsS0FBSyxLQUFLO0VBQzVCO0NBQ0YsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHO0NBQ1gsTUFBTSxlQUFlLGlCQUFpQixXQUFXO0NBQ2pELE9BQU8sR0FBRyxXQUFXLEtBQUssTUFBTSxLQUFLLEtBQUssYUFBYSxHQUFHO0FBQzVEO0FBRUEsU0FBUyxVQUFVLFVBQVU7Q0FDM0IsUUFBUSxNQUFNO0VBQ1osTUFBTSxlQUFlLEVBQUUsS0FBSztFQUM1QixPQUFPLFFBQVEsUUFBUSxTQUFTLE1BQU0sS0FBSyxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUMsTUFBTSxXQUFXO0dBQzVFLFlBQVksQ0FBQyxXQUFXLE1BQU0sQ0FBQztFQUNqQyxDQUFDLENBQUMsQ0FBQyxPQUFPLFVBQVU7R0FDbEIsWUFBWSxDQUFDLFNBQVMsS0FBSyxDQUFDO0VBQzlCLENBQUM7Q0FDSDtBQUNGO0FBRUEsU0FBUyxvQkFBb0IsSUFBSSxNQUFNLFdBQVc7Q0FDaEQsTUFBTSxXQUFXLEdBQUcsV0FBVyxNQUFNLFNBQVMsRUFBRSxlQUFlLFVBQVUsSUFBSSxHQUFHO0NBQ2hGLE1BQU0sT0FBTyxJQUFJLEtBQUssQ0FBQyxRQUFRLEdBQUcsRUFBRSxNQUFNLGtCQUFrQixDQUFDO0NBQzdELE1BQU0sTUFBTSxJQUFJLGdCQUFnQixJQUFJO0NBQ3BDLE9BQU87QUFDVDtBQUVBLFNBQVMsZUFBZSxJQUFJLFVBQVUsQ0FBQyxHQUFHO0NBQ3hDLE1BQU0sRUFDSixlQUFlLENBQUMsR0FDaEIsb0JBQW9CLENBQUMsR0FDckIsU0FDQSxTQUFTLGtCQUNQO0NBQ0osTUFBTSxTQUFTLElBQUk7Q0FDbkIsTUFBTSxlQUFlLFdBQVcsU0FBUztDQUN6QyxNQUFNLFVBQVUsSUFBSSxDQUFDLENBQUM7Q0FDdEIsTUFBTSxZQUFZLFdBQVc7Q0FDN0IsTUFBTSxtQkFBbUIsU0FBUyxjQUFjO0VBQzlDLElBQUksT0FBTyxTQUFTLE9BQU8sTUFBTSxRQUFRLFFBQVE7R0FDL0MsT0FBTyxNQUFNLFVBQVU7R0FDdkIsSUFBSSxnQkFBZ0IsT0FBTyxNQUFNLElBQUk7R0FDckMsUUFBUSxRQUFRLENBQUM7R0FDakIsT0FBTyxRQUFRLEtBQUs7R0FDcEIsT0FBTyxhQUFhLFVBQVUsS0FBSztHQUNuQyxhQUFhLFFBQVE7RUFDdkI7Q0FDRjtDQUNBLGdCQUFnQjtDQUNoQixrQkFBa0IsZUFBZTtDQUNqQyxNQUFNLHVCQUF1QjtFQUMzQixNQUFNLFVBQVUsb0JBQW9CLElBQUksY0FBYyxpQkFBaUI7RUFDdkUsTUFBTSxZQUFZLElBQUksT0FBTyxPQUFPO0VBQ3BDLFVBQVUsT0FBTztFQUNqQixVQUFVLGFBQWEsTUFBTTtHQUMzQixNQUFNLEVBQUUsZ0JBQWdCLENBQ3hCLEdBQUcsZUFBZSxDQUNsQixNQUFNLFFBQVE7R0FDZCxNQUFNLENBQUMsUUFBUSxVQUFVLEVBQUU7R0FDM0IsUUFBUSxRQUFSO0lBQ0UsS0FBSztLQUNILFFBQVEsTUFBTTtLQUNkLGdCQUFnQixNQUFNO0tBQ3RCO0lBQ0Y7S0FDRSxPQUFPLE1BQU07S0FDYixnQkFBZ0IsT0FBTztLQUN2QjtHQUNKO0VBQ0Y7RUFDQSxVQUFVLFdBQVcsTUFBTTtHQUN6QixNQUFNLEVBQUUsZUFBZSxDQUN2QixNQUFNLFFBQVE7R0FDZCxFQUFFLGVBQWU7R0FDakIsT0FBTyxDQUFDO0dBQ1IsZ0JBQWdCLE9BQU87RUFDekI7RUFDQSxJQUFJLFNBQVM7R0FDWCxVQUFVLFFBQVEsaUJBQ1YsZ0JBQWdCLGlCQUFpQixHQUN2QyxPQUNGO0VBQ0Y7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLGNBQWMsR0FBRyxXQUFXLElBQUksU0FBUyxTQUFTLFdBQVc7RUFDakUsSUFBSTtFQUNKLFFBQVEsUUFBUTtHQUNkO0dBQ0E7RUFDRjtFQUNBLENBQUMsS0FBSyxPQUFPLFVBQVUsT0FBTyxLQUFLLElBQUksR0FBRyxZQUFZLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDO0VBQ25FLGFBQWEsUUFBUTtDQUN2QixDQUFDO0NBQ0QsTUFBTSxZQUFZLEdBQUcsV0FBVztFQUM5QixJQUFJLGFBQWEsVUFBVSxXQUFXO0dBQ3BDLFFBQVEsTUFDTix5RUFDRjtHQUNBLE9BQU8sUUFBUSxPQUFPO0VBQ3hCO0VBQ0EsT0FBTyxRQUFRLGVBQWU7RUFDOUIsT0FBTyxXQUFXLEdBQUcsTUFBTTtDQUM3QjtDQUNBLE9BQU87RUFDTDtFQUNBO0VBQ0E7Q0FDRjtBQUNGOztBQUdBLFNBQVMsZUFBZSxVQUFVLENBQUMsR0FBRztDQUNwQyxNQUFNLEVBQUUsU0FBUyxrQkFBa0I7Q0FDbkMsSUFBSSxDQUFDLFFBQ0gsT0FBTyxXQUFXLEtBQUs7Q0FDekIsTUFBTSxVQUFVLFdBQVcsT0FBTyxTQUFTLFNBQVMsQ0FBQztDQUNyRCxNQUFNLGtCQUFrQixFQUFFLFNBQVMsS0FBSztDQUN4QyxpQkFBaUIsUUFBUSxjQUFjO0VBQ3JDLFFBQVEsUUFBUTtDQUNsQixHQUFHLGVBQWU7Q0FDbEIsaUJBQWlCLFFBQVEsZUFBZTtFQUN0QyxRQUFRLFFBQVE7Q0FDbEIsR0FBRyxlQUFlO0NBQ2xCLE9BQU87QUFDVDtBQUVBLFNBQVMsZ0JBQWdCLFVBQVUsQ0FBQyxHQUFHO0NBQ3JDLE1BQU0sRUFBRSxTQUFTLGVBQWUsR0FBRyxTQUFTO0NBQzVDLE9BQU8sVUFBVSxRQUFRLElBQUk7QUFDL0I7O0FBR0EsU0FBUyxjQUFjLFVBQVUsQ0FBQyxHQUFHO0NBQ25DLE1BQU0sRUFDSixTQUFTLGVBQ1QsZUFBZSxPQUFPLG1CQUN0QixnQkFBZ0IsT0FBTyxtQkFDdkIsb0JBQW9CLE1BQ3BCLG1CQUFtQixNQUNuQixPQUFPLFlBQ0w7Q0FDSixNQUFNLFFBQVEsV0FBVyxZQUFZO0NBQ3JDLE1BQU0sU0FBUyxXQUFXLGFBQWE7Q0FDdkMsTUFBTSxlQUFlO0VBQ25CLElBQUksUUFBUTtHQUNWLElBQUksU0FBUyxTQUFTO0lBQ3BCLE1BQU0sUUFBUSxPQUFPO0lBQ3JCLE9BQU8sUUFBUSxPQUFPO0dBQ3hCLE9BQU8sSUFBSSxTQUFTLFlBQVksT0FBTyxnQkFBZ0I7SUFDckQsTUFBTSxFQUFFLE9BQU8scUJBQXFCLFFBQVEsc0JBQXNCLFVBQVUsT0FBTztJQUNuRixNQUFNLFFBQVEsS0FBSyxNQUFNLHNCQUFzQixLQUFLO0lBQ3BELE9BQU8sUUFBUSxLQUFLLE1BQU0sdUJBQXVCLEtBQUs7R0FDeEQsT0FBTyxJQUFJLGtCQUFrQjtJQUMzQixNQUFNLFFBQVEsT0FBTztJQUNyQixPQUFPLFFBQVEsT0FBTztHQUN4QixPQUFPO0lBQ0wsTUFBTSxRQUFRLE9BQU8sU0FBUyxnQkFBZ0I7SUFDOUMsT0FBTyxRQUFRLE9BQU8sU0FBUyxnQkFBZ0I7R0FDakQ7RUFDRjtDQUNGO0NBQ0EsT0FBTztDQUNQLGFBQWEsTUFBTTtDQUNuQixNQUFNLGtCQUFrQixFQUFFLFNBQVMsS0FBSztDQUN4QyxpQkFBaUIsVUFBVSxRQUFRLGVBQWU7Q0FDbEQsSUFBSSxVQUFVLFNBQVMsWUFBWSxPQUFPLGdCQUFnQjtFQUN4RCxpQkFBaUIsT0FBTyxnQkFBZ0IsVUFBVSxRQUFRLGVBQWU7Q0FDM0U7Q0FDQSxJQUFJLG1CQUFtQjtFQUNyQixNQUFNLFVBQVUsY0FBYyx5QkFBeUI7RUFDdkQsTUFBTSxlQUFlLE9BQU8sQ0FBQztDQUMvQjtDQUNBLE9BQU87RUFBRTtFQUFPO0NBQU87QUFDekI7QUFFQSxTQUFTLDBCQUEwQixvQkFBb0IsbUJBQW1CLGlCQUFpQixlQUFlLHNCQUFzQix3QkFBd0Isb0JBQW9CLHNCQUFzQixzQkFBc0IsbUJBQW1CLG9CQUFvQixxQkFBcUIsb0JBQW9CLHNCQUFzQixzQkFBc0IsYUFBYSxlQUFlLGdCQUFnQixhQUFhLHdCQUF3Qix1QkFBdUIsZUFBZSx3QkFBd0IsaUJBQWlCLGlCQUFpQixrQkFBa0IsZUFBZSxtQkFBbUIsZUFBZSxtQkFBbUIsd0JBQXdCLGVBQWUsK0JBQStCLGdCQUFnQixrQkFBa0IsV0FBVyxjQUFjLGFBQWEsU0FBUyxhQUFhLGVBQWUsaUJBQWlCLGVBQWUsYUFBYSxjQUFjLGtCQUFrQixZQUFZLGVBQWUsZUFBZSxXQUFXLFlBQVksY0FBYyxnQkFBZ0IscUJBQXFCLG9CQUFvQixXQUFXLGNBQWMsbUJBQW1CLFdBQVcsY0FBYyxrQkFBa0IsY0FBYyxXQUFXLG1CQUFtQixjQUFjLFNBQVMsd0JBQXdCLGlCQUFpQixzQkFBc0IscUJBQXFCLGdCQUFnQixpQkFBaUIsdUJBQXVCLGNBQWMsYUFBYSxvQkFBb0IsbUJBQW1CLGlCQUFpQixnQkFBZ0Isc0JBQXNCLGFBQWEsa0JBQWtCLGdCQUFnQixlQUFlLFlBQVksVUFBVSxlQUFlLHFCQUFxQixVQUFVLGdCQUFnQixRQUFRLGVBQWUsWUFBWSxnQkFBZ0IsU0FBUyxVQUFVLG1CQUFtQix5QkFBeUIsZ0JBQWdCLGlCQUFpQixjQUFjLHFCQUFxQixrQkFBa0IsZUFBZSxZQUFZLFdBQVcsWUFBWSxVQUFVLG1CQUFtQixpQkFBaUIscUJBQXFCLHNCQUFzQixZQUFZLFFBQVEsY0FBYyxxQkFBcUIsV0FBVyxjQUFjLGFBQWEsa0JBQWtCLHdCQUF3QixlQUFlLFlBQVksZ0JBQWdCLGlCQUFpQix5QkFBeUIsc0JBQXNCLGtCQUFrQix1QkFBdUIsMkJBQTJCLGlDQUFpQyxhQUFhLFVBQVUsZUFBZSxtQkFBbUIsYUFBYSxzQkFBc0IsbUJBQW1CLGNBQWMsV0FBVyxlQUFlLG1CQUFtQixVQUFVLFdBQVcsc0JBQXNCLG9CQUFvQixZQUFZLFlBQVksaUJBQWlCLGFBQWEsY0FBYyxVQUFVLHFCQUFxQixrQkFBa0Isa0JBQWtCLHFCQUFxQix3QkFBd0IsWUFBWSxnQkFBZ0IsZ0JBQWdCLGNBQWMsVUFBVSxlQUFlLG9CQUFvQixjQUFjLFdBQVcsWUFBWSxZQUFZLGdCQUFnQixhQUFhLG9CQUFvQixjQUFjLGNBQWMsZ0JBQWdCLGdCQUFnQixpQkFBaUIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgubWpzP3Y9N2U3M2FmYzIiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbm9vcCwgbWFrZURlc3RydWN0dXJhYmxlLCBjYW1lbGl6ZSwgaXNDbGllbnQsIHRvQXJyYXksIHdhdGNoSW1tZWRpYXRlLCBpc09iamVjdCwgdHJ5T25TY29wZURpc3Bvc2UsIGlzSU9TLCBub3ROdWxsaXNoLCB0cnlPbk1vdW50ZWQsIG9iamVjdE9taXQsIHByb21pc2VUaW1lb3V0LCB1bnRpbCwgaW5qZWN0TG9jYWwsIHByb3ZpZGVMb2NhbCwgcHhWYWx1ZSwgaW5jcmVhc2VXaXRoVW5pdCwgb2JqZWN0RW50cmllcywgY3JlYXRlUmVmLCBjcmVhdGVTaW5nbGV0b25Qcm9taXNlLCB1c2VUaW1lb3V0Rm4sIHBhdXNhYmxlV2F0Y2gsIHRvUmVmLCBjcmVhdGVFdmVudEhvb2ssIHVzZUludGVydmFsRm4sIGNvbXB1dGVkV2l0aENvbnRyb2wsIHRpbWVzdGFtcCwgcGF1c2FibGVGaWx0ZXIsIHdhdGNoSWdub3JhYmxlLCBkZWJvdW5jZUZpbHRlciwgYnlwYXNzRmlsdGVyLCBjcmVhdGVGaWx0ZXJXcmFwcGVyLCB0b1JlZnMsIHdhdGNoT25jZSwgY29udGFpbnNQcm9wLCBoYXNPd24sIHRocm90dGxlRmlsdGVyLCB1c2VEZWJvdW5jZUZuLCB1c2VUaHJvdHRsZUZuLCB0cnlPblVubW91bnRlZCwgY2xhbXAsIHN5bmNSZWYsIG9iamVjdFBpY2ssIHdhdGNoV2l0aEZpbHRlciwgaWRlbnRpdHksIGlzRGVmLCB3aGVuZXZlciwgaXNXb3JrZXIgfSBmcm9tICdAdnVldXNlL3NoYXJlZCc7XG5leHBvcnQgKiBmcm9tICdAdnVldXNlL3NoYXJlZCc7XG5pbXBvcnQgeyBpc1JlZiwgc2hhbGxvd1JlZiwgcmVmLCB3YXRjaEVmZmVjdCwgY29tcHV0ZWQsIGluamVjdCwgZGVmaW5lQ29tcG9uZW50LCBoLCBUcmFuc2l0aW9uR3JvdXAsIEZyYWdtZW50LCBzaGFsbG93UmVhY3RpdmUsIHRvVmFsdWUsIHVucmVmLCBnZXRDdXJyZW50SW5zdGFuY2UsIG9uTW91bnRlZCwgd2F0Y2gsIGN1c3RvbVJlZiwgb25VcGRhdGVkLCByZWFkb25seSwgcmVhY3RpdmUsIGhhc0luamVjdGlvbkNvbnRleHQsIHRvUmF3LCBzaGFsbG93UmVhZG9ubHksIG5leHRUaWNrLCBtYXJrUmF3LCBnZXRDdXJyZW50U2NvcGUsIGlzUmVhZG9ubHksIG9uQmVmb3JlVXBkYXRlIH0gZnJvbSAndnVlJztcblxuZnVuY3Rpb24gY29tcHV0ZWRBc3luYyhldmFsdWF0aW9uQ2FsbGJhY2ssIGluaXRpYWxTdGF0ZSwgb3B0aW9uc09yUmVmKSB7XG4gIHZhciBfYTtcbiAgbGV0IG9wdGlvbnM7XG4gIGlmIChpc1JlZihvcHRpb25zT3JSZWYpKSB7XG4gICAgb3B0aW9ucyA9IHtcbiAgICAgIGV2YWx1YXRpbmc6IG9wdGlvbnNPclJlZlxuICAgIH07XG4gIH0gZWxzZSB7XG4gICAgb3B0aW9ucyA9IG9wdGlvbnNPclJlZiB8fCB7fTtcbiAgfVxuICBjb25zdCB7XG4gICAgbGF6eSA9IGZhbHNlLFxuICAgIGZsdXNoID0gXCJwcmVcIixcbiAgICBldmFsdWF0aW5nID0gdm9pZCAwLFxuICAgIHNoYWxsb3cgPSB0cnVlLFxuICAgIG9uRXJyb3IgPSAoX2EgPSBnbG9iYWxUaGlzLnJlcG9ydEVycm9yKSAhPSBudWxsID8gX2EgOiBub29wXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBzdGFydGVkID0gc2hhbGxvd1JlZighbGF6eSk7XG4gIGNvbnN0IGN1cnJlbnQgPSBzaGFsbG93ID8gc2hhbGxvd1JlZihpbml0aWFsU3RhdGUpIDogcmVmKGluaXRpYWxTdGF0ZSk7XG4gIGxldCBjb3VudGVyID0gMDtcbiAgd2F0Y2hFZmZlY3QoYXN5bmMgKG9uSW52YWxpZGF0ZSkgPT4ge1xuICAgIGlmICghc3RhcnRlZC52YWx1ZSlcbiAgICAgIHJldHVybjtcbiAgICBjb3VudGVyKys7XG4gICAgY29uc3QgY291bnRlckF0QmVnaW5uaW5nID0gY291bnRlcjtcbiAgICBsZXQgaGFzRmluaXNoZWQgPSBmYWxzZTtcbiAgICBpZiAoZXZhbHVhdGluZykge1xuICAgICAgUHJvbWlzZS5yZXNvbHZlKCkudGhlbigoKSA9PiB7XG4gICAgICAgIGV2YWx1YXRpbmcudmFsdWUgPSB0cnVlO1xuICAgICAgfSk7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBldmFsdWF0aW9uQ2FsbGJhY2soKGNhbmNlbENhbGxiYWNrKSA9PiB7XG4gICAgICAgIG9uSW52YWxpZGF0ZSgoKSA9PiB7XG4gICAgICAgICAgaWYgKGV2YWx1YXRpbmcpXG4gICAgICAgICAgICBldmFsdWF0aW5nLnZhbHVlID0gZmFsc2U7XG4gICAgICAgICAgaWYgKCFoYXNGaW5pc2hlZClcbiAgICAgICAgICAgIGNhbmNlbENhbGxiYWNrKCk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgICBpZiAoY291bnRlckF0QmVnaW5uaW5nID09PSBjb3VudGVyKVxuICAgICAgICBjdXJyZW50LnZhbHVlID0gcmVzdWx0O1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIG9uRXJyb3IoZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIGlmIChldmFsdWF0aW5nICYmIGNvdW50ZXJBdEJlZ2lubmluZyA9PT0gY291bnRlcilcbiAgICAgICAgZXZhbHVhdGluZy52YWx1ZSA9IGZhbHNlO1xuICAgICAgaGFzRmluaXNoZWQgPSB0cnVlO1xuICAgIH1cbiAgfSwgeyBmbHVzaCB9KTtcbiAgaWYgKGxhenkpIHtcbiAgICByZXR1cm4gY29tcHV0ZWQoKCkgPT4ge1xuICAgICAgc3RhcnRlZC52YWx1ZSA9IHRydWU7XG4gICAgICByZXR1cm4gY3VycmVudC52YWx1ZTtcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gY3VycmVudDtcbiAgfVxufVxuXG5mdW5jdGlvbiBjb21wdXRlZEluamVjdChrZXksIG9wdGlvbnMsIGRlZmF1bHRTb3VyY2UsIHRyZWF0RGVmYXVsdEFzRmFjdG9yeSkge1xuICBsZXQgc291cmNlID0gaW5qZWN0KGtleSk7XG4gIGlmIChkZWZhdWx0U291cmNlKVxuICAgIHNvdXJjZSA9IGluamVjdChrZXksIGRlZmF1bHRTb3VyY2UpO1xuICBpZiAodHJlYXREZWZhdWx0QXNGYWN0b3J5KVxuICAgIHNvdXJjZSA9IGluamVjdChrZXksIGRlZmF1bHRTb3VyY2UsIHRyZWF0RGVmYXVsdEFzRmFjdG9yeSk7XG4gIGlmICh0eXBlb2Ygb3B0aW9ucyA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgcmV0dXJuIGNvbXB1dGVkKChvbGRWYWx1ZSkgPT4gb3B0aW9ucyhzb3VyY2UsIG9sZFZhbHVlKSk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIGNvbXB1dGVkKHtcbiAgICAgIGdldDogKG9sZFZhbHVlKSA9PiBvcHRpb25zLmdldChzb3VyY2UsIG9sZFZhbHVlKSxcbiAgICAgIHNldDogb3B0aW9ucy5zZXRcbiAgICB9KTtcbiAgfVxufVxuXG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gY3JlYXRlUmV1c2FibGVUZW1wbGF0ZShvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGluaGVyaXRBdHRycyA9IHRydWVcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IHJlbmRlciA9IHNoYWxsb3dSZWYoKTtcbiAgY29uc3QgZGVmaW5lID0gLypAX19QVVJFX18qLyBkZWZpbmVDb21wb25lbnQoe1xuICAgIHNldHVwKF8sIHsgc2xvdHMgfSkge1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgcmVuZGVyLnZhbHVlID0gc2xvdHMuZGVmYXVsdDtcbiAgICAgIH07XG4gICAgfVxuICB9KTtcbiAgY29uc3QgcmV1c2UgPSAvKkBfX1BVUkVfXyovIGRlZmluZUNvbXBvbmVudCh7XG4gICAgaW5oZXJpdEF0dHJzLFxuICAgIHByb3BzOiBvcHRpb25zLnByb3BzLFxuICAgIHNldHVwKHByb3BzLCB7IGF0dHJzLCBzbG90cyB9KSB7XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIGlmICghcmVuZGVyLnZhbHVlICYmIHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIilcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJbVnVlVXNlXSBGYWlsZWQgdG8gZmluZCB0aGUgZGVmaW5pdGlvbiBvZiByZXVzYWJsZSB0ZW1wbGF0ZVwiKTtcbiAgICAgICAgY29uc3Qgdm5vZGUgPSAoX2EgPSByZW5kZXIudmFsdWUpID09IG51bGwgPyB2b2lkIDAgOiBfYS5jYWxsKHJlbmRlciwge1xuICAgICAgICAgIC4uLm9wdGlvbnMucHJvcHMgPT0gbnVsbCA/IGtleXNUb0NhbWVsS2ViYWJDYXNlKGF0dHJzKSA6IHByb3BzLFxuICAgICAgICAgICRzbG90czogc2xvdHNcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBpbmhlcml0QXR0cnMgJiYgKHZub2RlID09IG51bGwgPyB2b2lkIDAgOiB2bm9kZS5sZW5ndGgpID09PSAxID8gdm5vZGVbMF0gOiB2bm9kZTtcbiAgICAgIH07XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIG1ha2VEZXN0cnVjdHVyYWJsZShcbiAgICB7IGRlZmluZSwgcmV1c2UgfSxcbiAgICBbZGVmaW5lLCByZXVzZV1cbiAgKTtcbn1cbmZ1bmN0aW9uIGtleXNUb0NhbWVsS2ViYWJDYXNlKG9iaikge1xuICBjb25zdCBuZXdPYmogPSB7fTtcbiAgZm9yIChjb25zdCBrZXkgaW4gb2JqKVxuICAgIG5ld09ialtjYW1lbGl6ZShrZXkpXSA9IG9ialtrZXldO1xuICByZXR1cm4gbmV3T2JqO1xufVxuXG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gY3JlYXRlVGVtcGxhdGVQcm9taXNlKG9wdGlvbnMgPSB7fSkge1xuICBsZXQgaW5kZXggPSAwO1xuICBjb25zdCBpbnN0YW5jZXMgPSByZWYoW10pO1xuICBmdW5jdGlvbiBjcmVhdGUoLi4uYXJncykge1xuICAgIGNvbnN0IHByb3BzID0gc2hhbGxvd1JlYWN0aXZlKHtcbiAgICAgIGtleTogaW5kZXgrKyxcbiAgICAgIGFyZ3MsXG4gICAgICBwcm9taXNlOiB2b2lkIDAsXG4gICAgICByZXNvbHZlOiAoKSA9PiB7XG4gICAgICB9LFxuICAgICAgcmVqZWN0OiAoKSA9PiB7XG4gICAgICB9LFxuICAgICAgaXNSZXNvbHZpbmc6IGZhbHNlLFxuICAgICAgb3B0aW9uc1xuICAgIH0pO1xuICAgIGluc3RhbmNlcy52YWx1ZS5wdXNoKHByb3BzKTtcbiAgICBwcm9wcy5wcm9taXNlID0gbmV3IFByb21pc2UoKF9yZXNvbHZlLCBfcmVqZWN0KSA9PiB7XG4gICAgICBwcm9wcy5yZXNvbHZlID0gKHYpID0+IHtcbiAgICAgICAgcHJvcHMuaXNSZXNvbHZpbmcgPSB0cnVlO1xuICAgICAgICByZXR1cm4gX3Jlc29sdmUodik7XG4gICAgICB9O1xuICAgICAgcHJvcHMucmVqZWN0ID0gX3JlamVjdDtcbiAgICB9KS5maW5hbGx5KCgpID0+IHtcbiAgICAgIHByb3BzLnByb21pc2UgPSB2b2lkIDA7XG4gICAgICBjb25zdCBpbmRleDIgPSBpbnN0YW5jZXMudmFsdWUuaW5kZXhPZihwcm9wcyk7XG4gICAgICBpZiAoaW5kZXgyICE9PSAtMSlcbiAgICAgICAgaW5zdGFuY2VzLnZhbHVlLnNwbGljZShpbmRleDIsIDEpO1xuICAgIH0pO1xuICAgIHJldHVybiBwcm9wcy5wcm9taXNlO1xuICB9XG4gIGZ1bmN0aW9uIHN0YXJ0KC4uLmFyZ3MpIHtcbiAgICBpZiAob3B0aW9ucy5zaW5nbGV0b24gJiYgaW5zdGFuY2VzLnZhbHVlLmxlbmd0aCA+IDApXG4gICAgICByZXR1cm4gaW5zdGFuY2VzLnZhbHVlWzBdLnByb21pc2U7XG4gICAgcmV0dXJuIGNyZWF0ZSguLi5hcmdzKTtcbiAgfVxuICBjb25zdCBjb21wb25lbnQgPSAvKkBfX1BVUkVfXyovIGRlZmluZUNvbXBvbmVudCgoXywgeyBzbG90cyB9KSA9PiB7XG4gICAgY29uc3QgcmVuZGVyTGlzdCA9ICgpID0+IGluc3RhbmNlcy52YWx1ZS5tYXAoKHByb3BzKSA9PiB7XG4gICAgICB2YXIgX2E7XG4gICAgICByZXR1cm4gaChGcmFnbWVudCwgeyBrZXk6IHByb3BzLmtleSB9LCAoX2EgPSBzbG90cy5kZWZhdWx0KSA9PSBudWxsID8gdm9pZCAwIDogX2EuY2FsbChzbG90cywgcHJvcHMpKTtcbiAgICB9KTtcbiAgICBpZiAob3B0aW9ucy50cmFuc2l0aW9uKVxuICAgICAgcmV0dXJuICgpID0+IGgoVHJhbnNpdGlvbkdyb3VwLCBvcHRpb25zLnRyYW5zaXRpb24sIHJlbmRlckxpc3QpO1xuICAgIHJldHVybiByZW5kZXJMaXN0O1xuICB9KTtcbiAgY29tcG9uZW50LnN0YXJ0ID0gc3RhcnQ7XG4gIHJldHVybiBjb21wb25lbnQ7XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiBjcmVhdGVVbnJlZkZuKGZuKSB7XG4gIHJldHVybiBmdW5jdGlvbiguLi5hcmdzKSB7XG4gICAgcmV0dXJuIGZuLmFwcGx5KHRoaXMsIGFyZ3MubWFwKChpKSA9PiB0b1ZhbHVlKGkpKSk7XG4gIH07XG59XG5cbmNvbnN0IGRlZmF1bHRXaW5kb3cgPSBpc0NsaWVudCA/IHdpbmRvdyA6IHZvaWQgMDtcbmNvbnN0IGRlZmF1bHREb2N1bWVudCA9IGlzQ2xpZW50ID8gd2luZG93LmRvY3VtZW50IDogdm9pZCAwO1xuY29uc3QgZGVmYXVsdE5hdmlnYXRvciA9IGlzQ2xpZW50ID8gd2luZG93Lm5hdmlnYXRvciA6IHZvaWQgMDtcbmNvbnN0IGRlZmF1bHRMb2NhdGlvbiA9IGlzQ2xpZW50ID8gd2luZG93LmxvY2F0aW9uIDogdm9pZCAwO1xuXG5mdW5jdGlvbiB1bnJlZkVsZW1lbnQoZWxSZWYpIHtcbiAgdmFyIF9hO1xuICBjb25zdCBwbGFpbiA9IHRvVmFsdWUoZWxSZWYpO1xuICByZXR1cm4gKF9hID0gcGxhaW4gPT0gbnVsbCA/IHZvaWQgMCA6IHBsYWluLiRlbCkgIT0gbnVsbCA/IF9hIDogcGxhaW47XG59XG5cbmZ1bmN0aW9uIHVzZUV2ZW50TGlzdGVuZXIoLi4uYXJncykge1xuICBjb25zdCBjbGVhbnVwcyA9IFtdO1xuICBjb25zdCBjbGVhbnVwID0gKCkgPT4ge1xuICAgIGNsZWFudXBzLmZvckVhY2goKGZuKSA9PiBmbigpKTtcbiAgICBjbGVhbnVwcy5sZW5ndGggPSAwO1xuICB9O1xuICBjb25zdCByZWdpc3RlciA9IChlbCwgZXZlbnQsIGxpc3RlbmVyLCBvcHRpb25zKSA9PiB7XG4gICAgZWwuYWRkRXZlbnRMaXN0ZW5lcihldmVudCwgbGlzdGVuZXIsIG9wdGlvbnMpO1xuICAgIHJldHVybiAoKSA9PiBlbC5yZW1vdmVFdmVudExpc3RlbmVyKGV2ZW50LCBsaXN0ZW5lciwgb3B0aW9ucyk7XG4gIH07XG4gIGNvbnN0IGZpcnN0UGFyYW1UYXJnZXRzID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIGNvbnN0IHRlc3QgPSB0b0FycmF5KHRvVmFsdWUoYXJnc1swXSkpLmZpbHRlcigoZSkgPT4gZSAhPSBudWxsKTtcbiAgICByZXR1cm4gdGVzdC5ldmVyeSgoZSkgPT4gdHlwZW9mIGUgIT09IFwic3RyaW5nXCIpID8gdGVzdCA6IHZvaWQgMDtcbiAgfSk7XG4gIGNvbnN0IHN0b3BXYXRjaCA9IHdhdGNoSW1tZWRpYXRlKFxuICAgICgpID0+IHtcbiAgICAgIHZhciBfYSwgX2I7XG4gICAgICByZXR1cm4gW1xuICAgICAgICAoX2IgPSAoX2EgPSBmaXJzdFBhcmFtVGFyZ2V0cy52YWx1ZSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLm1hcCgoZSkgPT4gdW5yZWZFbGVtZW50KGUpKSkgIT0gbnVsbCA/IF9iIDogW2RlZmF1bHRXaW5kb3ddLmZpbHRlcigoZSkgPT4gZSAhPSBudWxsKSxcbiAgICAgICAgdG9BcnJheSh0b1ZhbHVlKGZpcnN0UGFyYW1UYXJnZXRzLnZhbHVlID8gYXJnc1sxXSA6IGFyZ3NbMF0pKSxcbiAgICAgICAgdG9BcnJheSh1bnJlZihmaXJzdFBhcmFtVGFyZ2V0cy52YWx1ZSA/IGFyZ3NbMl0gOiBhcmdzWzFdKSksXG4gICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgLSBUeXBlU2NyaXB0IGdldHMgdGhlIGNvcnJlY3QgdHlwZXMsIGJ1dCBzb21laG93IHN0aWxsIGNvbXBsYWluc1xuICAgICAgICB0b1ZhbHVlKGZpcnN0UGFyYW1UYXJnZXRzLnZhbHVlID8gYXJnc1szXSA6IGFyZ3NbMl0pXG4gICAgICBdO1xuICAgIH0sXG4gICAgKFtyYXdfdGFyZ2V0cywgcmF3X2V2ZW50cywgcmF3X2xpc3RlbmVycywgcmF3X29wdGlvbnNdKSA9PiB7XG4gICAgICBjbGVhbnVwKCk7XG4gICAgICBpZiAoIShyYXdfdGFyZ2V0cyA9PSBudWxsID8gdm9pZCAwIDogcmF3X3RhcmdldHMubGVuZ3RoKSB8fCAhKHJhd19ldmVudHMgPT0gbnVsbCA/IHZvaWQgMCA6IHJhd19ldmVudHMubGVuZ3RoKSB8fCAhKHJhd19saXN0ZW5lcnMgPT0gbnVsbCA/IHZvaWQgMCA6IHJhd19saXN0ZW5lcnMubGVuZ3RoKSlcbiAgICAgICAgcmV0dXJuO1xuICAgICAgY29uc3Qgb3B0aW9uc0Nsb25lID0gaXNPYmplY3QocmF3X29wdGlvbnMpID8geyAuLi5yYXdfb3B0aW9ucyB9IDogcmF3X29wdGlvbnM7XG4gICAgICBjbGVhbnVwcy5wdXNoKFxuICAgICAgICAuLi5yYXdfdGFyZ2V0cy5mbGF0TWFwKFxuICAgICAgICAgIChlbCkgPT4gcmF3X2V2ZW50cy5mbGF0TWFwKFxuICAgICAgICAgICAgKGV2ZW50KSA9PiByYXdfbGlzdGVuZXJzLm1hcCgobGlzdGVuZXIpID0+IHJlZ2lzdGVyKGVsLCBldmVudCwgbGlzdGVuZXIsIG9wdGlvbnNDbG9uZSkpXG4gICAgICAgICAgKVxuICAgICAgICApXG4gICAgICApO1xuICAgIH0sXG4gICAgeyBmbHVzaDogXCJwb3N0XCIgfVxuICApO1xuICBjb25zdCBzdG9wID0gKCkgPT4ge1xuICAgIHN0b3BXYXRjaCgpO1xuICAgIGNsZWFudXAoKTtcbiAgfTtcbiAgdHJ5T25TY29wZURpc3Bvc2UoY2xlYW51cCk7XG4gIHJldHVybiBzdG9wO1xufVxuXG5sZXQgX2lPU1dvcmthcm91bmQgPSBmYWxzZTtcbmZ1bmN0aW9uIG9uQ2xpY2tPdXRzaWRlKHRhcmdldCwgaGFuZGxlciwgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHsgd2luZG93ID0gZGVmYXVsdFdpbmRvdywgaWdub3JlID0gW10sIGNhcHR1cmUgPSB0cnVlLCBkZXRlY3RJZnJhbWUgPSBmYWxzZSwgY29udHJvbHMgPSBmYWxzZSB9ID0gb3B0aW9ucztcbiAgaWYgKCF3aW5kb3cpIHtcbiAgICByZXR1cm4gY29udHJvbHMgPyB7IHN0b3A6IG5vb3AsIGNhbmNlbDogbm9vcCwgdHJpZ2dlcjogbm9vcCB9IDogbm9vcDtcbiAgfVxuICBpZiAoaXNJT1MgJiYgIV9pT1NXb3JrYXJvdW5kKSB7XG4gICAgX2lPU1dvcmthcm91bmQgPSB0cnVlO1xuICAgIGNvbnN0IGxpc3RlbmVyT3B0aW9ucyA9IHsgcGFzc2l2ZTogdHJ1ZSB9O1xuICAgIEFycmF5LmZyb20od2luZG93LmRvY3VtZW50LmJvZHkuY2hpbGRyZW4pLmZvckVhY2goKGVsKSA9PiBlbC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgbm9vcCwgbGlzdGVuZXJPcHRpb25zKSk7XG4gICAgd2luZG93LmRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgbm9vcCwgbGlzdGVuZXJPcHRpb25zKTtcbiAgfVxuICBsZXQgc2hvdWxkTGlzdGVuID0gdHJ1ZTtcbiAgY29uc3Qgc2hvdWxkSWdub3JlID0gKGV2ZW50KSA9PiB7XG4gICAgcmV0dXJuIHRvVmFsdWUoaWdub3JlKS5zb21lKCh0YXJnZXQyKSA9PiB7XG4gICAgICBpZiAodHlwZW9mIHRhcmdldDIgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgcmV0dXJuIEFycmF5LmZyb20od2luZG93LmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwodGFyZ2V0MikpLnNvbWUoKGVsKSA9PiBlbCA9PT0gZXZlbnQudGFyZ2V0IHx8IGV2ZW50LmNvbXBvc2VkUGF0aCgpLmluY2x1ZGVzKGVsKSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCBlbCA9IHVucmVmRWxlbWVudCh0YXJnZXQyKTtcbiAgICAgICAgcmV0dXJuIGVsICYmIChldmVudC50YXJnZXQgPT09IGVsIHx8IGV2ZW50LmNvbXBvc2VkUGF0aCgpLmluY2x1ZGVzKGVsKSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH07XG4gIGZ1bmN0aW9uIGhhc011bHRpcGxlUm9vdHModGFyZ2V0Mikge1xuICAgIGNvbnN0IHZtID0gdG9WYWx1ZSh0YXJnZXQyKTtcbiAgICByZXR1cm4gdm0gJiYgdm0uJC5zdWJUcmVlLnNoYXBlRmxhZyA9PT0gMTY7XG4gIH1cbiAgZnVuY3Rpb24gY2hlY2tNdWx0aXBsZVJvb3RzKHRhcmdldDIsIGV2ZW50KSB7XG4gICAgY29uc3Qgdm0gPSB0b1ZhbHVlKHRhcmdldDIpO1xuICAgIGNvbnN0IGNoaWxkcmVuID0gdm0uJC5zdWJUcmVlICYmIHZtLiQuc3ViVHJlZS5jaGlsZHJlbjtcbiAgICBpZiAoY2hpbGRyZW4gPT0gbnVsbCB8fCAhQXJyYXkuaXNBcnJheShjaGlsZHJlbikpXG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgcmV0dXJuIGNoaWxkcmVuLnNvbWUoKGNoaWxkKSA9PiBjaGlsZC5lbCA9PT0gZXZlbnQudGFyZ2V0IHx8IGV2ZW50LmNvbXBvc2VkUGF0aCgpLmluY2x1ZGVzKGNoaWxkLmVsKSk7XG4gIH1cbiAgY29uc3QgbGlzdGVuZXIgPSAoZXZlbnQpID0+IHtcbiAgICBjb25zdCBlbCA9IHVucmVmRWxlbWVudCh0YXJnZXQpO1xuICAgIGlmIChldmVudC50YXJnZXQgPT0gbnVsbClcbiAgICAgIHJldHVybjtcbiAgICBpZiAoIShlbCBpbnN0YW5jZW9mIEVsZW1lbnQpICYmIGhhc011bHRpcGxlUm9vdHModGFyZ2V0KSAmJiBjaGVja011bHRpcGxlUm9vdHModGFyZ2V0LCBldmVudCkpXG4gICAgICByZXR1cm47XG4gICAgaWYgKCFlbCB8fCBlbCA9PT0gZXZlbnQudGFyZ2V0IHx8IGV2ZW50LmNvbXBvc2VkUGF0aCgpLmluY2x1ZGVzKGVsKSlcbiAgICAgIHJldHVybjtcbiAgICBpZiAoXCJkZXRhaWxcIiBpbiBldmVudCAmJiBldmVudC5kZXRhaWwgPT09IDApXG4gICAgICBzaG91bGRMaXN0ZW4gPSAhc2hvdWxkSWdub3JlKGV2ZW50KTtcbiAgICBpZiAoIXNob3VsZExpc3Rlbikge1xuICAgICAgc2hvdWxkTGlzdGVuID0gdHJ1ZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaGFuZGxlcihldmVudCk7XG4gIH07XG4gIGxldCBpc1Byb2Nlc3NpbmdDbGljayA9IGZhbHNlO1xuICBjb25zdCBjbGVhbnVwID0gW1xuICAgIHVzZUV2ZW50TGlzdGVuZXIod2luZG93LCBcImNsaWNrXCIsIChldmVudCkgPT4ge1xuICAgICAgaWYgKCFpc1Byb2Nlc3NpbmdDbGljaykge1xuICAgICAgICBpc1Byb2Nlc3NpbmdDbGljayA9IHRydWU7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIGlzUHJvY2Vzc2luZ0NsaWNrID0gZmFsc2U7XG4gICAgICAgIH0sIDApO1xuICAgICAgICBsaXN0ZW5lcihldmVudCk7XG4gICAgICB9XG4gICAgfSwgeyBwYXNzaXZlOiB0cnVlLCBjYXB0dXJlIH0pLFxuICAgIHVzZUV2ZW50TGlzdGVuZXIod2luZG93LCBcInBvaW50ZXJkb3duXCIsIChlKSA9PiB7XG4gICAgICBjb25zdCBlbCA9IHVucmVmRWxlbWVudCh0YXJnZXQpO1xuICAgICAgc2hvdWxkTGlzdGVuID0gIXNob3VsZElnbm9yZShlKSAmJiAhIShlbCAmJiAhZS5jb21wb3NlZFBhdGgoKS5pbmNsdWRlcyhlbCkpO1xuICAgIH0sIHsgcGFzc2l2ZTogdHJ1ZSB9KSxcbiAgICBkZXRlY3RJZnJhbWUgJiYgdXNlRXZlbnRMaXN0ZW5lcih3aW5kb3csIFwiYmx1clwiLCAoZXZlbnQpID0+IHtcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB2YXIgX2E7XG4gICAgICAgIGNvbnN0IGVsID0gdW5yZWZFbGVtZW50KHRhcmdldCk7XG4gICAgICAgIGlmICgoKF9hID0gd2luZG93LmRvY3VtZW50LmFjdGl2ZUVsZW1lbnQpID09IG51bGwgPyB2b2lkIDAgOiBfYS50YWdOYW1lKSA9PT0gXCJJRlJBTUVcIiAmJiAhKGVsID09IG51bGwgPyB2b2lkIDAgOiBlbC5jb250YWlucyh3aW5kb3cuZG9jdW1lbnQuYWN0aXZlRWxlbWVudCkpKSB7XG4gICAgICAgICAgaGFuZGxlcihldmVudCk7XG4gICAgICAgIH1cbiAgICAgIH0sIDApO1xuICAgIH0sIHsgcGFzc2l2ZTogdHJ1ZSB9KVxuICBdLmZpbHRlcihCb29sZWFuKTtcbiAgY29uc3Qgc3RvcCA9ICgpID0+IGNsZWFudXAuZm9yRWFjaCgoZm4pID0+IGZuKCkpO1xuICBpZiAoY29udHJvbHMpIHtcbiAgICByZXR1cm4ge1xuICAgICAgc3RvcCxcbiAgICAgIGNhbmNlbDogKCkgPT4ge1xuICAgICAgICBzaG91bGRMaXN0ZW4gPSBmYWxzZTtcbiAgICAgIH0sXG4gICAgICB0cmlnZ2VyOiAoZXZlbnQpID0+IHtcbiAgICAgICAgc2hvdWxkTGlzdGVuID0gdHJ1ZTtcbiAgICAgICAgbGlzdGVuZXIoZXZlbnQpO1xuICAgICAgICBzaG91bGRMaXN0ZW4gPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9O1xuICB9XG4gIHJldHVybiBzdG9wO1xufVxuXG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gdXNlTW91bnRlZCgpIHtcbiAgY29uc3QgaXNNb3VudGVkID0gc2hhbGxvd1JlZihmYWxzZSk7XG4gIGNvbnN0IGluc3RhbmNlID0gZ2V0Q3VycmVudEluc3RhbmNlKCk7XG4gIGlmIChpbnN0YW5jZSkge1xuICAgIG9uTW91bnRlZCgoKSA9PiB7XG4gICAgICBpc01vdW50ZWQudmFsdWUgPSB0cnVlO1xuICAgIH0sIGluc3RhbmNlKTtcbiAgfVxuICByZXR1cm4gaXNNb3VudGVkO1xufVxuXG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gdXNlU3VwcG9ydGVkKGNhbGxiYWNrKSB7XG4gIGNvbnN0IGlzTW91bnRlZCA9IHVzZU1vdW50ZWQoKTtcbiAgcmV0dXJuIGNvbXB1dGVkKCgpID0+IHtcbiAgICBpc01vdW50ZWQudmFsdWU7XG4gICAgcmV0dXJuIEJvb2xlYW4oY2FsbGJhY2soKSk7XG4gIH0pO1xufVxuXG5mdW5jdGlvbiB1c2VNdXRhdGlvbk9ic2VydmVyKHRhcmdldCwgY2FsbGJhY2ssIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7IHdpbmRvdyA9IGRlZmF1bHRXaW5kb3csIC4uLm11dGF0aW9uT3B0aW9ucyB9ID0gb3B0aW9ucztcbiAgbGV0IG9ic2VydmVyO1xuICBjb25zdCBpc1N1cHBvcnRlZCA9IHVzZVN1cHBvcnRlZCgoKSA9PiB3aW5kb3cgJiYgXCJNdXRhdGlvbk9ic2VydmVyXCIgaW4gd2luZG93KTtcbiAgY29uc3QgY2xlYW51cCA9ICgpID0+IHtcbiAgICBpZiAob2JzZXJ2ZXIpIHtcbiAgICAgIG9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICAgIG9ic2VydmVyID0gdm9pZCAwO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgdGFyZ2V0cyA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICBjb25zdCB2YWx1ZSA9IHRvVmFsdWUodGFyZ2V0KTtcbiAgICBjb25zdCBpdGVtcyA9IHRvQXJyYXkodmFsdWUpLm1hcCh1bnJlZkVsZW1lbnQpLmZpbHRlcihub3ROdWxsaXNoKTtcbiAgICByZXR1cm4gbmV3IFNldChpdGVtcyk7XG4gIH0pO1xuICBjb25zdCBzdG9wV2F0Y2ggPSB3YXRjaChcbiAgICB0YXJnZXRzLFxuICAgIChuZXdUYXJnZXRzKSA9PiB7XG4gICAgICBjbGVhbnVwKCk7XG4gICAgICBpZiAoaXNTdXBwb3J0ZWQudmFsdWUgJiYgbmV3VGFyZ2V0cy5zaXplKSB7XG4gICAgICAgIG9ic2VydmVyID0gbmV3IE11dGF0aW9uT2JzZXJ2ZXIoY2FsbGJhY2spO1xuICAgICAgICBuZXdUYXJnZXRzLmZvckVhY2goKGVsKSA9PiBvYnNlcnZlci5vYnNlcnZlKGVsLCBtdXRhdGlvbk9wdGlvbnMpKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIHsgaW1tZWRpYXRlOiB0cnVlLCBmbHVzaDogXCJwb3N0XCIgfVxuICApO1xuICBjb25zdCB0YWtlUmVjb3JkcyA9ICgpID0+IHtcbiAgICByZXR1cm4gb2JzZXJ2ZXIgPT0gbnVsbCA/IHZvaWQgMCA6IG9ic2VydmVyLnRha2VSZWNvcmRzKCk7XG4gIH07XG4gIGNvbnN0IHN0b3AgPSAoKSA9PiB7XG4gICAgc3RvcFdhdGNoKCk7XG4gICAgY2xlYW51cCgpO1xuICB9O1xuICB0cnlPblNjb3BlRGlzcG9zZShzdG9wKTtcbiAgcmV0dXJuIHtcbiAgICBpc1N1cHBvcnRlZCxcbiAgICBzdG9wLFxuICAgIHRha2VSZWNvcmRzXG4gIH07XG59XG5cbmZ1bmN0aW9uIG9uRWxlbWVudFJlbW92YWwodGFyZ2V0LCBjYWxsYmFjaywgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICB3aW5kb3cgPSBkZWZhdWx0V2luZG93LFxuICAgIGRvY3VtZW50ID0gd2luZG93ID09IG51bGwgPyB2b2lkIDAgOiB3aW5kb3cuZG9jdW1lbnQsXG4gICAgZmx1c2ggPSBcInN5bmNcIlxuICB9ID0gb3B0aW9ucztcbiAgaWYgKCF3aW5kb3cgfHwgIWRvY3VtZW50KVxuICAgIHJldHVybiBub29wO1xuICBsZXQgc3RvcEZuO1xuICBjb25zdCBjbGVhbnVwQW5kVXBkYXRlID0gKGZuKSA9PiB7XG4gICAgc3RvcEZuID09IG51bGwgPyB2b2lkIDAgOiBzdG9wRm4oKTtcbiAgICBzdG9wRm4gPSBmbjtcbiAgfTtcbiAgY29uc3Qgc3RvcFdhdGNoID0gd2F0Y2hFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGVsID0gdW5yZWZFbGVtZW50KHRhcmdldCk7XG4gICAgaWYgKGVsKSB7XG4gICAgICBjb25zdCB7IHN0b3AgfSA9IHVzZU11dGF0aW9uT2JzZXJ2ZXIoXG4gICAgICAgIGRvY3VtZW50LFxuICAgICAgICAobXV0YXRpb25zTGlzdCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHRhcmdldFJlbW92ZWQgPSBtdXRhdGlvbnNMaXN0Lm1hcCgobXV0YXRpb24pID0+IFsuLi5tdXRhdGlvbi5yZW1vdmVkTm9kZXNdKS5mbGF0KCkuc29tZSgobm9kZSkgPT4gbm9kZSA9PT0gZWwgfHwgbm9kZS5jb250YWlucyhlbCkpO1xuICAgICAgICAgIGlmICh0YXJnZXRSZW1vdmVkKSB7XG4gICAgICAgICAgICBjYWxsYmFjayhtdXRhdGlvbnNMaXN0KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICB3aW5kb3csXG4gICAgICAgICAgY2hpbGRMaXN0OiB0cnVlLFxuICAgICAgICAgIHN1YnRyZWU6IHRydWVcbiAgICAgICAgfVxuICAgICAgKTtcbiAgICAgIGNsZWFudXBBbmRVcGRhdGUoc3RvcCk7XG4gICAgfVxuICB9LCB7IGZsdXNoIH0pO1xuICBjb25zdCBzdG9wSGFuZGxlID0gKCkgPT4ge1xuICAgIHN0b3BXYXRjaCgpO1xuICAgIGNsZWFudXBBbmRVcGRhdGUoKTtcbiAgfTtcbiAgdHJ5T25TY29wZURpc3Bvc2Uoc3RvcEhhbmRsZSk7XG4gIHJldHVybiBzdG9wSGFuZGxlO1xufVxuXG5mdW5jdGlvbiBjcmVhdGVLZXlQcmVkaWNhdGUoa2V5RmlsdGVyKSB7XG4gIGlmICh0eXBlb2Yga2V5RmlsdGVyID09PSBcImZ1bmN0aW9uXCIpXG4gICAgcmV0dXJuIGtleUZpbHRlcjtcbiAgZWxzZSBpZiAodHlwZW9mIGtleUZpbHRlciA9PT0gXCJzdHJpbmdcIilcbiAgICByZXR1cm4gKGV2ZW50KSA9PiBldmVudC5rZXkgPT09IGtleUZpbHRlcjtcbiAgZWxzZSBpZiAoQXJyYXkuaXNBcnJheShrZXlGaWx0ZXIpKVxuICAgIHJldHVybiAoZXZlbnQpID0+IGtleUZpbHRlci5pbmNsdWRlcyhldmVudC5rZXkpO1xuICByZXR1cm4gKCkgPT4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIG9uS2V5U3Ryb2tlKC4uLmFyZ3MpIHtcbiAgbGV0IGtleTtcbiAgbGV0IGhhbmRsZXI7XG4gIGxldCBvcHRpb25zID0ge307XG4gIGlmIChhcmdzLmxlbmd0aCA9PT0gMykge1xuICAgIGtleSA9IGFyZ3NbMF07XG4gICAgaGFuZGxlciA9IGFyZ3NbMV07XG4gICAgb3B0aW9ucyA9IGFyZ3NbMl07XG4gIH0gZWxzZSBpZiAoYXJncy5sZW5ndGggPT09IDIpIHtcbiAgICBpZiAodHlwZW9mIGFyZ3NbMV0gPT09IFwib2JqZWN0XCIpIHtcbiAgICAgIGtleSA9IHRydWU7XG4gICAgICBoYW5kbGVyID0gYXJnc1swXTtcbiAgICAgIG9wdGlvbnMgPSBhcmdzWzFdO1xuICAgIH0gZWxzZSB7XG4gICAgICBrZXkgPSBhcmdzWzBdO1xuICAgICAgaGFuZGxlciA9IGFyZ3NbMV07XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGtleSA9IHRydWU7XG4gICAgaGFuZGxlciA9IGFyZ3NbMF07XG4gIH1cbiAgY29uc3Qge1xuICAgIHRhcmdldCA9IGRlZmF1bHRXaW5kb3csXG4gICAgZXZlbnROYW1lID0gXCJrZXlkb3duXCIsXG4gICAgcGFzc2l2ZSA9IGZhbHNlLFxuICAgIGRlZHVwZSA9IGZhbHNlXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBwcmVkaWNhdGUgPSBjcmVhdGVLZXlQcmVkaWNhdGUoa2V5KTtcbiAgY29uc3QgbGlzdGVuZXIgPSAoZSkgPT4ge1xuICAgIGlmIChlLnJlcGVhdCAmJiB0b1ZhbHVlKGRlZHVwZSkpXG4gICAgICByZXR1cm47XG4gICAgaWYgKHByZWRpY2F0ZShlKSlcbiAgICAgIGhhbmRsZXIoZSk7XG4gIH07XG4gIHJldHVybiB1c2VFdmVudExpc3RlbmVyKHRhcmdldCwgZXZlbnROYW1lLCBsaXN0ZW5lciwgcGFzc2l2ZSk7XG59XG5mdW5jdGlvbiBvbktleURvd24oa2V5LCBoYW5kbGVyLCBvcHRpb25zID0ge30pIHtcbiAgcmV0dXJuIG9uS2V5U3Ryb2tlKGtleSwgaGFuZGxlciwgeyAuLi5vcHRpb25zLCBldmVudE5hbWU6IFwia2V5ZG93blwiIH0pO1xufVxuZnVuY3Rpb24gb25LZXlQcmVzc2VkKGtleSwgaGFuZGxlciwgb3B0aW9ucyA9IHt9KSB7XG4gIHJldHVybiBvbktleVN0cm9rZShrZXksIGhhbmRsZXIsIHsgLi4ub3B0aW9ucywgZXZlbnROYW1lOiBcImtleXByZXNzXCIgfSk7XG59XG5mdW5jdGlvbiBvbktleVVwKGtleSwgaGFuZGxlciwgb3B0aW9ucyA9IHt9KSB7XG4gIHJldHVybiBvbktleVN0cm9rZShrZXksIGhhbmRsZXIsIHsgLi4ub3B0aW9ucywgZXZlbnROYW1lOiBcImtleXVwXCIgfSk7XG59XG5cbmNvbnN0IERFRkFVTFRfREVMQVkgPSA1MDA7XG5jb25zdCBERUZBVUxUX1RIUkVTSE9MRCA9IDEwO1xuZnVuY3Rpb24gb25Mb25nUHJlc3ModGFyZ2V0LCBoYW5kbGVyLCBvcHRpb25zKSB7XG4gIHZhciBfYSwgX2I7XG4gIGNvbnN0IGVsZW1lbnRSZWYgPSBjb21wdXRlZCgoKSA9PiB1bnJlZkVsZW1lbnQodGFyZ2V0KSk7XG4gIGxldCB0aW1lb3V0O1xuICBsZXQgcG9zU3RhcnQ7XG4gIGxldCBzdGFydFRpbWVzdGFtcDtcbiAgbGV0IGhhc0xvbmdQcmVzc2VkID0gZmFsc2U7XG4gIGZ1bmN0aW9uIGNsZWFyKCkge1xuICAgIGlmICh0aW1lb3V0KSB7XG4gICAgICBjbGVhclRpbWVvdXQodGltZW91dCk7XG4gICAgICB0aW1lb3V0ID0gdm9pZCAwO1xuICAgIH1cbiAgICBwb3NTdGFydCA9IHZvaWQgMDtcbiAgICBzdGFydFRpbWVzdGFtcCA9IHZvaWQgMDtcbiAgICBoYXNMb25nUHJlc3NlZCA9IGZhbHNlO1xuICB9XG4gIGZ1bmN0aW9uIGdldERlbGF5KGV2KSB7XG4gICAgY29uc3QgZGVsYXkgPSBvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLmRlbGF5O1xuICAgIGlmICh0eXBlb2YgZGVsYXkgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgcmV0dXJuIGRlbGF5KGV2KTtcbiAgICB9XG4gICAgcmV0dXJuIGRlbGF5ICE9IG51bGwgPyBkZWxheSA6IERFRkFVTFRfREVMQVk7XG4gIH1cbiAgZnVuY3Rpb24gb25SZWxlYXNlKGV2KSB7XG4gICAgdmFyIF9hMiwgX2IyLCBfYztcbiAgICBjb25zdCBbX3N0YXJ0VGltZXN0YW1wLCBfcG9zU3RhcnQsIF9oYXNMb25nUHJlc3NlZF0gPSBbc3RhcnRUaW1lc3RhbXAsIHBvc1N0YXJ0LCBoYXNMb25nUHJlc3NlZF07XG4gICAgY2xlYXIoKTtcbiAgICBpZiAoIShvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLm9uTW91c2VVcCkgfHwgIV9wb3NTdGFydCB8fCAhX3N0YXJ0VGltZXN0YW1wKVxuICAgICAgcmV0dXJuO1xuICAgIGlmICgoKF9hMiA9IG9wdGlvbnMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdGlvbnMubW9kaWZpZXJzKSA9PSBudWxsID8gdm9pZCAwIDogX2EyLnNlbGYpICYmIGV2LnRhcmdldCAhPT0gZWxlbWVudFJlZi52YWx1ZSlcbiAgICAgIHJldHVybjtcbiAgICBpZiAoKF9iMiA9IG9wdGlvbnMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdGlvbnMubW9kaWZpZXJzKSA9PSBudWxsID8gdm9pZCAwIDogX2IyLnByZXZlbnQpXG4gICAgICBldi5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmICgoX2MgPSBvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLm1vZGlmaWVycykgPT0gbnVsbCA/IHZvaWQgMCA6IF9jLnN0b3ApXG4gICAgICBldi5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICBjb25zdCBkeCA9IGV2LnggLSBfcG9zU3RhcnQueDtcbiAgICBjb25zdCBkeSA9IGV2LnkgLSBfcG9zU3RhcnQueTtcbiAgICBjb25zdCBkaXN0YW5jZSA9IE1hdGguc3FydChkeCAqIGR4ICsgZHkgKiBkeSk7XG4gICAgb3B0aW9ucy5vbk1vdXNlVXAoZXYudGltZVN0YW1wIC0gX3N0YXJ0VGltZXN0YW1wLCBkaXN0YW5jZSwgX2hhc0xvbmdQcmVzc2VkKTtcbiAgfVxuICBmdW5jdGlvbiBvbkRvd24oZXYpIHtcbiAgICB2YXIgX2EyLCBfYjIsIF9jO1xuICAgIGlmICgoKF9hMiA9IG9wdGlvbnMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdGlvbnMubW9kaWZpZXJzKSA9PSBudWxsID8gdm9pZCAwIDogX2EyLnNlbGYpICYmIGV2LnRhcmdldCAhPT0gZWxlbWVudFJlZi52YWx1ZSlcbiAgICAgIHJldHVybjtcbiAgICBjbGVhcigpO1xuICAgIGlmICgoX2IyID0gb3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy5tb2RpZmllcnMpID09IG51bGwgPyB2b2lkIDAgOiBfYjIucHJldmVudClcbiAgICAgIGV2LnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKChfYyA9IG9wdGlvbnMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdGlvbnMubW9kaWZpZXJzKSA9PSBudWxsID8gdm9pZCAwIDogX2Muc3RvcClcbiAgICAgIGV2LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgIHBvc1N0YXJ0ID0ge1xuICAgICAgeDogZXYueCxcbiAgICAgIHk6IGV2LnlcbiAgICB9O1xuICAgIHN0YXJ0VGltZXN0YW1wID0gZXYudGltZVN0YW1wO1xuICAgIHRpbWVvdXQgPSBzZXRUaW1lb3V0KFxuICAgICAgKCkgPT4ge1xuICAgICAgICBoYXNMb25nUHJlc3NlZCA9IHRydWU7XG4gICAgICAgIGhhbmRsZXIoZXYpO1xuICAgICAgfSxcbiAgICAgIGdldERlbGF5KGV2KVxuICAgICk7XG4gIH1cbiAgZnVuY3Rpb24gb25Nb3ZlKGV2KSB7XG4gICAgdmFyIF9hMiwgX2IyLCBfYywgX2Q7XG4gICAgaWYgKCgoX2EyID0gb3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy5tb2RpZmllcnMpID09IG51bGwgPyB2b2lkIDAgOiBfYTIuc2VsZikgJiYgZXYudGFyZ2V0ICE9PSBlbGVtZW50UmVmLnZhbHVlKVxuICAgICAgcmV0dXJuO1xuICAgIGlmICghcG9zU3RhcnQgfHwgKG9wdGlvbnMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdGlvbnMuZGlzdGFuY2VUaHJlc2hvbGQpID09PSBmYWxzZSlcbiAgICAgIHJldHVybjtcbiAgICBpZiAoKF9iMiA9IG9wdGlvbnMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdGlvbnMubW9kaWZpZXJzKSA9PSBudWxsID8gdm9pZCAwIDogX2IyLnByZXZlbnQpXG4gICAgICBldi5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmICgoX2MgPSBvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLm1vZGlmaWVycykgPT0gbnVsbCA/IHZvaWQgMCA6IF9jLnN0b3ApXG4gICAgICBldi5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICBjb25zdCBkeCA9IGV2LnggLSBwb3NTdGFydC54O1xuICAgIGNvbnN0IGR5ID0gZXYueSAtIHBvc1N0YXJ0Lnk7XG4gICAgY29uc3QgZGlzdGFuY2UgPSBNYXRoLnNxcnQoZHggKiBkeCArIGR5ICogZHkpO1xuICAgIGlmIChkaXN0YW5jZSA+PSAoKF9kID0gb3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy5kaXN0YW5jZVRocmVzaG9sZCkgIT0gbnVsbCA/IF9kIDogREVGQVVMVF9USFJFU0hPTEQpKVxuICAgICAgY2xlYXIoKTtcbiAgfVxuICBjb25zdCBsaXN0ZW5lck9wdGlvbnMgPSB7XG4gICAgY2FwdHVyZTogKF9hID0gb3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy5tb2RpZmllcnMpID09IG51bGwgPyB2b2lkIDAgOiBfYS5jYXB0dXJlLFxuICAgIG9uY2U6IChfYiA9IG9wdGlvbnMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdGlvbnMubW9kaWZpZXJzKSA9PSBudWxsID8gdm9pZCAwIDogX2Iub25jZVxuICB9O1xuICBjb25zdCBjbGVhbnVwID0gW1xuICAgIHVzZUV2ZW50TGlzdGVuZXIoZWxlbWVudFJlZiwgXCJwb2ludGVyZG93blwiLCBvbkRvd24sIGxpc3RlbmVyT3B0aW9ucyksXG4gICAgdXNlRXZlbnRMaXN0ZW5lcihlbGVtZW50UmVmLCBcInBvaW50ZXJtb3ZlXCIsIG9uTW92ZSwgbGlzdGVuZXJPcHRpb25zKSxcbiAgICB1c2VFdmVudExpc3RlbmVyKGVsZW1lbnRSZWYsIFtcInBvaW50ZXJ1cFwiLCBcInBvaW50ZXJsZWF2ZVwiXSwgb25SZWxlYXNlLCBsaXN0ZW5lck9wdGlvbnMpXG4gIF07XG4gIGNvbnN0IHN0b3AgPSAoKSA9PiBjbGVhbnVwLmZvckVhY2goKGZuKSA9PiBmbigpKTtcbiAgcmV0dXJuIHN0b3A7XG59XG5cbmZ1bmN0aW9uIGlzRm9jdXNlZEVsZW1lbnRFZGl0YWJsZSgpIHtcbiAgY29uc3QgeyBhY3RpdmVFbGVtZW50LCBib2R5IH0gPSBkb2N1bWVudDtcbiAgaWYgKCFhY3RpdmVFbGVtZW50KVxuICAgIHJldHVybiBmYWxzZTtcbiAgaWYgKGFjdGl2ZUVsZW1lbnQgPT09IGJvZHkpXG4gICAgcmV0dXJuIGZhbHNlO1xuICBzd2l0Y2ggKGFjdGl2ZUVsZW1lbnQudGFnTmFtZSkge1xuICAgIGNhc2UgXCJJTlBVVFwiOlxuICAgIGNhc2UgXCJURVhUQVJFQVwiOlxuICAgICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGFjdGl2ZUVsZW1lbnQuaGFzQXR0cmlidXRlKFwiY29udGVudGVkaXRhYmxlXCIpO1xufVxuZnVuY3Rpb24gaXNUeXBlZENoYXJWYWxpZCh7XG4gIGtleUNvZGUsXG4gIG1ldGFLZXksXG4gIGN0cmxLZXksXG4gIGFsdEtleVxufSkge1xuICBpZiAobWV0YUtleSB8fCBjdHJsS2V5IHx8IGFsdEtleSlcbiAgICByZXR1cm4gZmFsc2U7XG4gIGlmIChrZXlDb2RlID49IDQ4ICYmIGtleUNvZGUgPD0gNTcgfHwga2V5Q29kZSA+PSA5NiAmJiBrZXlDb2RlIDw9IDEwNSlcbiAgICByZXR1cm4gdHJ1ZTtcbiAgaWYgKGtleUNvZGUgPj0gNjUgJiYga2V5Q29kZSA8PSA5MClcbiAgICByZXR1cm4gdHJ1ZTtcbiAgcmV0dXJuIGZhbHNlO1xufVxuZnVuY3Rpb24gb25TdGFydFR5cGluZyhjYWxsYmFjaywgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHsgZG9jdW1lbnQ6IGRvY3VtZW50MiA9IGRlZmF1bHREb2N1bWVudCB9ID0gb3B0aW9ucztcbiAgY29uc3Qga2V5ZG93biA9IChldmVudCkgPT4ge1xuICAgIGlmICghaXNGb2N1c2VkRWxlbWVudEVkaXRhYmxlKCkgJiYgaXNUeXBlZENoYXJWYWxpZChldmVudCkpIHtcbiAgICAgIGNhbGxiYWNrKGV2ZW50KTtcbiAgICB9XG4gIH07XG4gIGlmIChkb2N1bWVudDIpXG4gICAgdXNlRXZlbnRMaXN0ZW5lcihkb2N1bWVudDIsIFwia2V5ZG93blwiLCBrZXlkb3duLCB7IHBhc3NpdmU6IHRydWUgfSk7XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB0ZW1wbGF0ZVJlZihrZXksIGluaXRpYWxWYWx1ZSA9IG51bGwpIHtcbiAgY29uc3QgaW5zdGFuY2UgPSBnZXRDdXJyZW50SW5zdGFuY2UoKTtcbiAgbGV0IF90cmlnZ2VyID0gKCkgPT4ge1xuICB9O1xuICBjb25zdCBlbGVtZW50ID0gY3VzdG9tUmVmKCh0cmFjaywgdHJpZ2dlcikgPT4ge1xuICAgIF90cmlnZ2VyID0gdHJpZ2dlcjtcbiAgICByZXR1cm4ge1xuICAgICAgZ2V0KCkge1xuICAgICAgICB2YXIgX2EsIF9iO1xuICAgICAgICB0cmFjaygpO1xuICAgICAgICByZXR1cm4gKF9iID0gKF9hID0gaW5zdGFuY2UgPT0gbnVsbCA/IHZvaWQgMCA6IGluc3RhbmNlLnByb3h5KSA9PSBudWxsID8gdm9pZCAwIDogX2EuJHJlZnNba2V5XSkgIT0gbnVsbCA/IF9iIDogaW5pdGlhbFZhbHVlO1xuICAgICAgfSxcbiAgICAgIHNldCgpIHtcbiAgICAgIH1cbiAgICB9O1xuICB9KTtcbiAgdHJ5T25Nb3VudGVkKF90cmlnZ2VyKTtcbiAgb25VcGRhdGVkKF90cmlnZ2VyKTtcbiAgcmV0dXJuIGVsZW1lbnQ7XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VBY3RpdmVFbGVtZW50KG9wdGlvbnMgPSB7fSkge1xuICB2YXIgX2E7XG4gIGNvbnN0IHtcbiAgICB3aW5kb3cgPSBkZWZhdWx0V2luZG93LFxuICAgIGRlZXAgPSB0cnVlLFxuICAgIHRyaWdnZXJPblJlbW92YWwgPSBmYWxzZVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgZG9jdW1lbnQgPSAoX2EgPSBvcHRpb25zLmRvY3VtZW50KSAhPSBudWxsID8gX2EgOiB3aW5kb3cgPT0gbnVsbCA/IHZvaWQgMCA6IHdpbmRvdy5kb2N1bWVudDtcbiAgY29uc3QgZ2V0RGVlcEFjdGl2ZUVsZW1lbnQgPSAoKSA9PiB7XG4gICAgdmFyIF9hMjtcbiAgICBsZXQgZWxlbWVudCA9IGRvY3VtZW50ID09IG51bGwgPyB2b2lkIDAgOiBkb2N1bWVudC5hY3RpdmVFbGVtZW50O1xuICAgIGlmIChkZWVwKSB7XG4gICAgICB3aGlsZSAoZWxlbWVudCA9PSBudWxsID8gdm9pZCAwIDogZWxlbWVudC5zaGFkb3dSb290KVxuICAgICAgICBlbGVtZW50ID0gKF9hMiA9IGVsZW1lbnQgPT0gbnVsbCA/IHZvaWQgMCA6IGVsZW1lbnQuc2hhZG93Um9vdCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hMi5hY3RpdmVFbGVtZW50O1xuICAgIH1cbiAgICByZXR1cm4gZWxlbWVudDtcbiAgfTtcbiAgY29uc3QgYWN0aXZlRWxlbWVudCA9IHNoYWxsb3dSZWYoKTtcbiAgY29uc3QgdHJpZ2dlciA9ICgpID0+IHtcbiAgICBhY3RpdmVFbGVtZW50LnZhbHVlID0gZ2V0RGVlcEFjdGl2ZUVsZW1lbnQoKTtcbiAgfTtcbiAgaWYgKHdpbmRvdykge1xuICAgIGNvbnN0IGxpc3RlbmVyT3B0aW9ucyA9IHtcbiAgICAgIGNhcHR1cmU6IHRydWUsXG4gICAgICBwYXNzaXZlOiB0cnVlXG4gICAgfTtcbiAgICB1c2VFdmVudExpc3RlbmVyKFxuICAgICAgd2luZG93LFxuICAgICAgXCJibHVyXCIsXG4gICAgICAoZXZlbnQpID0+IHtcbiAgICAgICAgaWYgKGV2ZW50LnJlbGF0ZWRUYXJnZXQgIT09IG51bGwpXG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB0cmlnZ2VyKCk7XG4gICAgICB9LFxuICAgICAgbGlzdGVuZXJPcHRpb25zXG4gICAgKTtcbiAgICB1c2VFdmVudExpc3RlbmVyKFxuICAgICAgd2luZG93LFxuICAgICAgXCJmb2N1c1wiLFxuICAgICAgdHJpZ2dlcixcbiAgICAgIGxpc3RlbmVyT3B0aW9uc1xuICAgICk7XG4gIH1cbiAgaWYgKHRyaWdnZXJPblJlbW92YWwpIHtcbiAgICBvbkVsZW1lbnRSZW1vdmFsKGFjdGl2ZUVsZW1lbnQsIHRyaWdnZXIsIHsgZG9jdW1lbnQgfSk7XG4gIH1cbiAgdHJpZ2dlcigpO1xuICByZXR1cm4gYWN0aXZlRWxlbWVudDtcbn1cblxuZnVuY3Rpb24gdXNlUmFmRm4oZm4sIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgaW1tZWRpYXRlID0gdHJ1ZSxcbiAgICBmcHNMaW1pdCA9IHZvaWQgMCxcbiAgICB3aW5kb3cgPSBkZWZhdWx0V2luZG93LFxuICAgIG9uY2UgPSBmYWxzZVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgaXNBY3RpdmUgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgY29uc3QgaW50ZXJ2YWxMaW1pdCA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICByZXR1cm4gZnBzTGltaXQgPyAxZTMgLyB0b1ZhbHVlKGZwc0xpbWl0KSA6IG51bGw7XG4gIH0pO1xuICBsZXQgcHJldmlvdXNGcmFtZVRpbWVzdGFtcCA9IDA7XG4gIGxldCByYWZJZCA9IG51bGw7XG4gIGZ1bmN0aW9uIGxvb3AodGltZXN0YW1wKSB7XG4gICAgaWYgKCFpc0FjdGl2ZS52YWx1ZSB8fCAhd2luZG93KVxuICAgICAgcmV0dXJuO1xuICAgIGlmICghcHJldmlvdXNGcmFtZVRpbWVzdGFtcClcbiAgICAgIHByZXZpb3VzRnJhbWVUaW1lc3RhbXAgPSB0aW1lc3RhbXA7XG4gICAgY29uc3QgZGVsdGEgPSB0aW1lc3RhbXAgLSBwcmV2aW91c0ZyYW1lVGltZXN0YW1wO1xuICAgIGlmIChpbnRlcnZhbExpbWl0LnZhbHVlICYmIGRlbHRhIDwgaW50ZXJ2YWxMaW1pdC52YWx1ZSkge1xuICAgICAgcmFmSWQgPSB3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lKGxvb3ApO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBwcmV2aW91c0ZyYW1lVGltZXN0YW1wID0gdGltZXN0YW1wO1xuICAgIGZuKHsgZGVsdGEsIHRpbWVzdGFtcCB9KTtcbiAgICBpZiAob25jZSkge1xuICAgICAgaXNBY3RpdmUudmFsdWUgPSBmYWxzZTtcbiAgICAgIHJhZklkID0gbnVsbDtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcmFmSWQgPSB3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lKGxvb3ApO1xuICB9XG4gIGZ1bmN0aW9uIHJlc3VtZSgpIHtcbiAgICBpZiAoIWlzQWN0aXZlLnZhbHVlICYmIHdpbmRvdykge1xuICAgICAgaXNBY3RpdmUudmFsdWUgPSB0cnVlO1xuICAgICAgcHJldmlvdXNGcmFtZVRpbWVzdGFtcCA9IDA7XG4gICAgICByYWZJZCA9IHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUobG9vcCk7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIHBhdXNlKCkge1xuICAgIGlzQWN0aXZlLnZhbHVlID0gZmFsc2U7XG4gICAgaWYgKHJhZklkICE9IG51bGwgJiYgd2luZG93KSB7XG4gICAgICB3aW5kb3cuY2FuY2VsQW5pbWF0aW9uRnJhbWUocmFmSWQpO1xuICAgICAgcmFmSWQgPSBudWxsO1xuICAgIH1cbiAgfVxuICBpZiAoaW1tZWRpYXRlKVxuICAgIHJlc3VtZSgpO1xuICB0cnlPblNjb3BlRGlzcG9zZShwYXVzZSk7XG4gIHJldHVybiB7XG4gICAgaXNBY3RpdmU6IHJlYWRvbmx5KGlzQWN0aXZlKSxcbiAgICBwYXVzZSxcbiAgICByZXN1bWVcbiAgfTtcbn1cblxuZnVuY3Rpb24gdXNlQW5pbWF0ZSh0YXJnZXQsIGtleWZyYW1lcywgb3B0aW9ucykge1xuICBsZXQgY29uZmlnO1xuICBsZXQgYW5pbWF0ZU9wdGlvbnM7XG4gIGlmIChpc09iamVjdChvcHRpb25zKSkge1xuICAgIGNvbmZpZyA9IG9wdGlvbnM7XG4gICAgYW5pbWF0ZU9wdGlvbnMgPSBvYmplY3RPbWl0KG9wdGlvbnMsIFtcIndpbmRvd1wiLCBcImltbWVkaWF0ZVwiLCBcImNvbW1pdFN0eWxlc1wiLCBcInBlcnNpc3RcIiwgXCJvblJlYWR5XCIsIFwib25FcnJvclwiXSk7XG4gIH0gZWxzZSB7XG4gICAgY29uZmlnID0geyBkdXJhdGlvbjogb3B0aW9ucyB9O1xuICAgIGFuaW1hdGVPcHRpb25zID0gb3B0aW9ucztcbiAgfVxuICBjb25zdCB7XG4gICAgd2luZG93ID0gZGVmYXVsdFdpbmRvdyxcbiAgICBpbW1lZGlhdGUgPSB0cnVlLFxuICAgIGNvbW1pdFN0eWxlcyxcbiAgICBwZXJzaXN0LFxuICAgIHBsYXliYWNrUmF0ZTogX3BsYXliYWNrUmF0ZSA9IDEsXG4gICAgb25SZWFkeSxcbiAgICBvbkVycm9yID0gKGUpID0+IHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgfVxuICB9ID0gY29uZmlnO1xuICBjb25zdCBpc1N1cHBvcnRlZCA9IHVzZVN1cHBvcnRlZCgoKSA9PiB3aW5kb3cgJiYgSFRNTEVsZW1lbnQgJiYgXCJhbmltYXRlXCIgaW4gSFRNTEVsZW1lbnQucHJvdG90eXBlKTtcbiAgY29uc3QgYW5pbWF0ZSA9IHNoYWxsb3dSZWYodm9pZCAwKTtcbiAgY29uc3Qgc3RvcmUgPSBzaGFsbG93UmVhY3RpdmUoe1xuICAgIHN0YXJ0VGltZTogbnVsbCxcbiAgICBjdXJyZW50VGltZTogbnVsbCxcbiAgICB0aW1lbGluZTogbnVsbCxcbiAgICBwbGF5YmFja1JhdGU6IF9wbGF5YmFja1JhdGUsXG4gICAgcGVuZGluZzogZmFsc2UsXG4gICAgcGxheVN0YXRlOiBpbW1lZGlhdGUgPyBcImlkbGVcIiA6IFwicGF1c2VkXCIsXG4gICAgcmVwbGFjZVN0YXRlOiBcImFjdGl2ZVwiXG4gIH0pO1xuICBjb25zdCBwZW5kaW5nID0gY29tcHV0ZWQoKCkgPT4gc3RvcmUucGVuZGluZyk7XG4gIGNvbnN0IHBsYXlTdGF0ZSA9IGNvbXB1dGVkKCgpID0+IHN0b3JlLnBsYXlTdGF0ZSk7XG4gIGNvbnN0IHJlcGxhY2VTdGF0ZSA9IGNvbXB1dGVkKCgpID0+IHN0b3JlLnJlcGxhY2VTdGF0ZSk7XG4gIGNvbnN0IHN0YXJ0VGltZSA9IGNvbXB1dGVkKHtcbiAgICBnZXQoKSB7XG4gICAgICByZXR1cm4gc3RvcmUuc3RhcnRUaW1lO1xuICAgIH0sXG4gICAgc2V0KHZhbHVlKSB7XG4gICAgICBzdG9yZS5zdGFydFRpbWUgPSB2YWx1ZTtcbiAgICAgIGlmIChhbmltYXRlLnZhbHVlKVxuICAgICAgICBhbmltYXRlLnZhbHVlLnN0YXJ0VGltZSA9IHZhbHVlO1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IGN1cnJlbnRUaW1lID0gY29tcHV0ZWQoe1xuICAgIGdldCgpIHtcbiAgICAgIHJldHVybiBzdG9yZS5jdXJyZW50VGltZTtcbiAgICB9LFxuICAgIHNldCh2YWx1ZSkge1xuICAgICAgc3RvcmUuY3VycmVudFRpbWUgPSB2YWx1ZTtcbiAgICAgIGlmIChhbmltYXRlLnZhbHVlKSB7XG4gICAgICAgIGFuaW1hdGUudmFsdWUuY3VycmVudFRpbWUgPSB2YWx1ZTtcbiAgICAgICAgc3luY1Jlc3VtZSgpO1xuICAgICAgfVxuICAgIH1cbiAgfSk7XG4gIGNvbnN0IHRpbWVsaW5lID0gY29tcHV0ZWQoe1xuICAgIGdldCgpIHtcbiAgICAgIHJldHVybiBzdG9yZS50aW1lbGluZTtcbiAgICB9LFxuICAgIHNldCh2YWx1ZSkge1xuICAgICAgc3RvcmUudGltZWxpbmUgPSB2YWx1ZTtcbiAgICAgIGlmIChhbmltYXRlLnZhbHVlKVxuICAgICAgICBhbmltYXRlLnZhbHVlLnRpbWVsaW5lID0gdmFsdWU7XG4gICAgfVxuICB9KTtcbiAgY29uc3QgcGxheWJhY2tSYXRlID0gY29tcHV0ZWQoe1xuICAgIGdldCgpIHtcbiAgICAgIHJldHVybiBzdG9yZS5wbGF5YmFja1JhdGU7XG4gICAgfSxcbiAgICBzZXQodmFsdWUpIHtcbiAgICAgIHN0b3JlLnBsYXliYWNrUmF0ZSA9IHZhbHVlO1xuICAgICAgaWYgKGFuaW1hdGUudmFsdWUpXG4gICAgICAgIGFuaW1hdGUudmFsdWUucGxheWJhY2tSYXRlID0gdmFsdWU7XG4gICAgfVxuICB9KTtcbiAgY29uc3QgcGxheSA9ICgpID0+IHtcbiAgICBpZiAoYW5pbWF0ZS52YWx1ZSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgYW5pbWF0ZS52YWx1ZS5wbGF5KCk7XG4gICAgICAgIHN5bmNSZXN1bWUoKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgc3luY1BhdXNlKCk7XG4gICAgICAgIG9uRXJyb3IoZSk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHVwZGF0ZSgpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgcGF1c2UgPSAoKSA9PiB7XG4gICAgdmFyIF9hO1xuICAgIHRyeSB7XG4gICAgICAoX2EgPSBhbmltYXRlLnZhbHVlKSA9PSBudWxsID8gdm9pZCAwIDogX2EucGF1c2UoKTtcbiAgICAgIHN5bmNQYXVzZSgpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIG9uRXJyb3IoZSk7XG4gICAgfVxuICB9O1xuICBjb25zdCByZXZlcnNlID0gKCkgPT4ge1xuICAgIHZhciBfYTtcbiAgICBpZiAoIWFuaW1hdGUudmFsdWUpXG4gICAgICB1cGRhdGUoKTtcbiAgICB0cnkge1xuICAgICAgKF9hID0gYW5pbWF0ZS52YWx1ZSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLnJldmVyc2UoKTtcbiAgICAgIHN5bmNSZXN1bWUoKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBzeW5jUGF1c2UoKTtcbiAgICAgIG9uRXJyb3IoZSk7XG4gICAgfVxuICB9O1xuICBjb25zdCBmaW5pc2ggPSAoKSA9PiB7XG4gICAgdmFyIF9hO1xuICAgIHRyeSB7XG4gICAgICAoX2EgPSBhbmltYXRlLnZhbHVlKSA9PSBudWxsID8gdm9pZCAwIDogX2EuZmluaXNoKCk7XG4gICAgICBzeW5jUGF1c2UoKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBvbkVycm9yKGUpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgY2FuY2VsID0gKCkgPT4ge1xuICAgIHZhciBfYTtcbiAgICB0cnkge1xuICAgICAgKF9hID0gYW5pbWF0ZS52YWx1ZSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLmNhbmNlbCgpO1xuICAgICAgc3luY1BhdXNlKCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgb25FcnJvcihlKTtcbiAgICB9XG4gIH07XG4gIHdhdGNoKCgpID0+IHVucmVmRWxlbWVudCh0YXJnZXQpLCAoZWwpID0+IHtcbiAgICBpZiAoZWwpIHtcbiAgICAgIHVwZGF0ZSh0cnVlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgYW5pbWF0ZS52YWx1ZSA9IHZvaWQgMDtcbiAgICB9XG4gIH0pO1xuICB3YXRjaCgoKSA9PiBrZXlmcmFtZXMsICh2YWx1ZSkgPT4ge1xuICAgIGlmIChhbmltYXRlLnZhbHVlKSB7XG4gICAgICB1cGRhdGUoKTtcbiAgICAgIGNvbnN0IHRhcmdldEVsID0gdW5yZWZFbGVtZW50KHRhcmdldCk7XG4gICAgICBpZiAodGFyZ2V0RWwpIHtcbiAgICAgICAgYW5pbWF0ZS52YWx1ZS5lZmZlY3QgPSBuZXcgS2V5ZnJhbWVFZmZlY3QoXG4gICAgICAgICAgdGFyZ2V0RWwsXG4gICAgICAgICAgdG9WYWx1ZSh2YWx1ZSksXG4gICAgICAgICAgYW5pbWF0ZU9wdGlvbnNcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gIH0sIHsgZGVlcDogdHJ1ZSB9KTtcbiAgdHJ5T25Nb3VudGVkKCgpID0+IHVwZGF0ZSh0cnVlKSwgZmFsc2UpO1xuICB0cnlPblNjb3BlRGlzcG9zZShjYW5jZWwpO1xuICBmdW5jdGlvbiB1cGRhdGUoaW5pdCkge1xuICAgIGNvbnN0IGVsID0gdW5yZWZFbGVtZW50KHRhcmdldCk7XG4gICAgaWYgKCFpc1N1cHBvcnRlZC52YWx1ZSB8fCAhZWwpXG4gICAgICByZXR1cm47XG4gICAgaWYgKCFhbmltYXRlLnZhbHVlKVxuICAgICAgYW5pbWF0ZS52YWx1ZSA9IGVsLmFuaW1hdGUodG9WYWx1ZShrZXlmcmFtZXMpLCBhbmltYXRlT3B0aW9ucyk7XG4gICAgaWYgKHBlcnNpc3QpXG4gICAgICBhbmltYXRlLnZhbHVlLnBlcnNpc3QoKTtcbiAgICBpZiAoX3BsYXliYWNrUmF0ZSAhPT0gMSlcbiAgICAgIGFuaW1hdGUudmFsdWUucGxheWJhY2tSYXRlID0gX3BsYXliYWNrUmF0ZTtcbiAgICBpZiAoaW5pdCAmJiAhaW1tZWRpYXRlKVxuICAgICAgYW5pbWF0ZS52YWx1ZS5wYXVzZSgpO1xuICAgIGVsc2VcbiAgICAgIHN5bmNSZXN1bWUoKTtcbiAgICBvblJlYWR5ID09IG51bGwgPyB2b2lkIDAgOiBvblJlYWR5KGFuaW1hdGUudmFsdWUpO1xuICB9XG4gIGNvbnN0IGxpc3RlbmVyT3B0aW9ucyA9IHsgcGFzc2l2ZTogdHJ1ZSB9O1xuICB1c2VFdmVudExpc3RlbmVyKGFuaW1hdGUsIFtcImNhbmNlbFwiLCBcImZpbmlzaFwiLCBcInJlbW92ZVwiXSwgc3luY1BhdXNlLCBsaXN0ZW5lck9wdGlvbnMpO1xuICB1c2VFdmVudExpc3RlbmVyKGFuaW1hdGUsIFwiZmluaXNoXCIsICgpID0+IHtcbiAgICB2YXIgX2E7XG4gICAgaWYgKGNvbW1pdFN0eWxlcylcbiAgICAgIChfYSA9IGFuaW1hdGUudmFsdWUpID09IG51bGwgPyB2b2lkIDAgOiBfYS5jb21taXRTdHlsZXMoKTtcbiAgfSwgbGlzdGVuZXJPcHRpb25zKTtcbiAgY29uc3QgeyByZXN1bWU6IHJlc3VtZVJlZiwgcGF1c2U6IHBhdXNlUmVmIH0gPSB1c2VSYWZGbigoKSA9PiB7XG4gICAgaWYgKCFhbmltYXRlLnZhbHVlKVxuICAgICAgcmV0dXJuO1xuICAgIHN0b3JlLnBlbmRpbmcgPSBhbmltYXRlLnZhbHVlLnBlbmRpbmc7XG4gICAgc3RvcmUucGxheVN0YXRlID0gYW5pbWF0ZS52YWx1ZS5wbGF5U3RhdGU7XG4gICAgc3RvcmUucmVwbGFjZVN0YXRlID0gYW5pbWF0ZS52YWx1ZS5yZXBsYWNlU3RhdGU7XG4gICAgc3RvcmUuc3RhcnRUaW1lID0gYW5pbWF0ZS52YWx1ZS5zdGFydFRpbWU7XG4gICAgc3RvcmUuY3VycmVudFRpbWUgPSBhbmltYXRlLnZhbHVlLmN1cnJlbnRUaW1lO1xuICAgIHN0b3JlLnRpbWVsaW5lID0gYW5pbWF0ZS52YWx1ZS50aW1lbGluZTtcbiAgICBzdG9yZS5wbGF5YmFja1JhdGUgPSBhbmltYXRlLnZhbHVlLnBsYXliYWNrUmF0ZTtcbiAgfSwgeyBpbW1lZGlhdGU6IGZhbHNlIH0pO1xuICBmdW5jdGlvbiBzeW5jUmVzdW1lKCkge1xuICAgIGlmIChpc1N1cHBvcnRlZC52YWx1ZSlcbiAgICAgIHJlc3VtZVJlZigpO1xuICB9XG4gIGZ1bmN0aW9uIHN5bmNQYXVzZSgpIHtcbiAgICBpZiAoaXNTdXBwb3J0ZWQudmFsdWUgJiYgd2luZG93KVxuICAgICAgd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZShwYXVzZVJlZik7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBpc1N1cHBvcnRlZCxcbiAgICBhbmltYXRlLFxuICAgIC8vIGFjdGlvbnNcbiAgICBwbGF5LFxuICAgIHBhdXNlLFxuICAgIHJldmVyc2UsXG4gICAgZmluaXNoLFxuICAgIGNhbmNlbCxcbiAgICAvLyBzdGF0ZVxuICAgIHBlbmRpbmcsXG4gICAgcGxheVN0YXRlLFxuICAgIHJlcGxhY2VTdGF0ZSxcbiAgICBzdGFydFRpbWUsXG4gICAgY3VycmVudFRpbWUsXG4gICAgdGltZWxpbmUsXG4gICAgcGxheWJhY2tSYXRlXG4gIH07XG59XG5cbmZ1bmN0aW9uIHVzZUFzeW5jUXVldWUodGFza3MsIG9wdGlvbnMpIHtcbiAgY29uc3Qge1xuICAgIGludGVycnVwdCA9IHRydWUsXG4gICAgb25FcnJvciA9IG5vb3AsXG4gICAgb25GaW5pc2hlZCA9IG5vb3AsXG4gICAgc2lnbmFsXG4gIH0gPSBvcHRpb25zIHx8IHt9O1xuICBjb25zdCBwcm9taXNlU3RhdGUgPSB7XG4gICAgYWJvcnRlZDogXCJhYm9ydGVkXCIsXG4gICAgZnVsZmlsbGVkOiBcImZ1bGZpbGxlZFwiLFxuICAgIHBlbmRpbmc6IFwicGVuZGluZ1wiLFxuICAgIHJlamVjdGVkOiBcInJlamVjdGVkXCJcbiAgfTtcbiAgY29uc3QgaW5pdGlhbFJlc3VsdCA9IEFycmF5LmZyb20oQXJyYXkuZnJvbSh7IGxlbmd0aDogdGFza3MubGVuZ3RoIH0pLCAoKSA9PiAoeyBzdGF0ZTogcHJvbWlzZVN0YXRlLnBlbmRpbmcsIGRhdGE6IG51bGwgfSkpO1xuICBjb25zdCByZXN1bHQgPSByZWFjdGl2ZShpbml0aWFsUmVzdWx0KTtcbiAgY29uc3QgYWN0aXZlSW5kZXggPSBzaGFsbG93UmVmKC0xKTtcbiAgaWYgKCF0YXNrcyB8fCB0YXNrcy5sZW5ndGggPT09IDApIHtcbiAgICBvbkZpbmlzaGVkKCk7XG4gICAgcmV0dXJuIHtcbiAgICAgIGFjdGl2ZUluZGV4LFxuICAgICAgcmVzdWx0XG4gICAgfTtcbiAgfVxuICBmdW5jdGlvbiB1cGRhdGVSZXN1bHQoc3RhdGUsIHJlcykge1xuICAgIGFjdGl2ZUluZGV4LnZhbHVlKys7XG4gICAgcmVzdWx0W2FjdGl2ZUluZGV4LnZhbHVlXS5kYXRhID0gcmVzO1xuICAgIHJlc3VsdFthY3RpdmVJbmRleC52YWx1ZV0uc3RhdGUgPSBzdGF0ZTtcbiAgfVxuICB0YXNrcy5yZWR1Y2UoKHByZXYsIGN1cnIpID0+IHtcbiAgICByZXR1cm4gcHJldi50aGVuKChwcmV2UmVzKSA9PiB7XG4gICAgICB2YXIgX2E7XG4gICAgICBpZiAoc2lnbmFsID09IG51bGwgPyB2b2lkIDAgOiBzaWduYWwuYWJvcnRlZCkge1xuICAgICAgICB1cGRhdGVSZXN1bHQocHJvbWlzZVN0YXRlLmFib3J0ZWQsIG5ldyBFcnJvcihcImFib3J0ZWRcIikpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoKChfYSA9IHJlc3VsdFthY3RpdmVJbmRleC52YWx1ZV0pID09IG51bGwgPyB2b2lkIDAgOiBfYS5zdGF0ZSkgPT09IHByb21pc2VTdGF0ZS5yZWplY3RlZCAmJiBpbnRlcnJ1cHQpIHtcbiAgICAgICAgb25GaW5pc2hlZCgpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBkb25lID0gY3VycihwcmV2UmVzKS50aGVuKChjdXJyZW50UmVzKSA9PiB7XG4gICAgICAgIHVwZGF0ZVJlc3VsdChwcm9taXNlU3RhdGUuZnVsZmlsbGVkLCBjdXJyZW50UmVzKTtcbiAgICAgICAgaWYgKGFjdGl2ZUluZGV4LnZhbHVlID09PSB0YXNrcy5sZW5ndGggLSAxKVxuICAgICAgICAgIG9uRmluaXNoZWQoKTtcbiAgICAgICAgcmV0dXJuIGN1cnJlbnRSZXM7XG4gICAgICB9KTtcbiAgICAgIGlmICghc2lnbmFsKVxuICAgICAgICByZXR1cm4gZG9uZTtcbiAgICAgIHJldHVybiBQcm9taXNlLnJhY2UoW2RvbmUsIHdoZW5BYm9ydGVkKHNpZ25hbCldKTtcbiAgICB9KS5jYXRjaCgoZSkgPT4ge1xuICAgICAgaWYgKHNpZ25hbCA9PSBudWxsID8gdm9pZCAwIDogc2lnbmFsLmFib3J0ZWQpIHtcbiAgICAgICAgdXBkYXRlUmVzdWx0KHByb21pc2VTdGF0ZS5hYm9ydGVkLCBlKTtcbiAgICAgICAgcmV0dXJuIGU7XG4gICAgICB9XG4gICAgICB1cGRhdGVSZXN1bHQocHJvbWlzZVN0YXRlLnJlamVjdGVkLCBlKTtcbiAgICAgIG9uRXJyb3IoKTtcbiAgICAgIHJldHVybiBlO1xuICAgIH0pO1xuICB9LCBQcm9taXNlLnJlc29sdmUoKSk7XG4gIHJldHVybiB7XG4gICAgYWN0aXZlSW5kZXgsXG4gICAgcmVzdWx0XG4gIH07XG59XG5mdW5jdGlvbiB3aGVuQWJvcnRlZChzaWduYWwpIHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBjb25zdCBlcnJvciA9IG5ldyBFcnJvcihcImFib3J0ZWRcIik7XG4gICAgaWYgKHNpZ25hbC5hYm9ydGVkKVxuICAgICAgcmVqZWN0KGVycm9yKTtcbiAgICBlbHNlXG4gICAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsICgpID0+IHJlamVjdChlcnJvciksIHsgb25jZTogdHJ1ZSB9KTtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHVzZUFzeW5jU3RhdGUocHJvbWlzZSwgaW5pdGlhbFN0YXRlLCBvcHRpb25zKSB7XG4gIHZhciBfYTtcbiAgY29uc3Qge1xuICAgIGltbWVkaWF0ZSA9IHRydWUsXG4gICAgZGVsYXkgPSAwLFxuICAgIG9uRXJyb3IgPSAoX2EgPSBnbG9iYWxUaGlzLnJlcG9ydEVycm9yKSAhPSBudWxsID8gX2EgOiBub29wLFxuICAgIG9uU3VjY2VzcyA9IG5vb3AsXG4gICAgcmVzZXRPbkV4ZWN1dGUgPSB0cnVlLFxuICAgIHNoYWxsb3cgPSB0cnVlLFxuICAgIHRocm93RXJyb3JcbiAgfSA9IG9wdGlvbnMgIT0gbnVsbCA/IG9wdGlvbnMgOiB7fTtcbiAgY29uc3Qgc3RhdGUgPSBzaGFsbG93ID8gc2hhbGxvd1JlZihpbml0aWFsU3RhdGUpIDogcmVmKGluaXRpYWxTdGF0ZSk7XG4gIGNvbnN0IGlzUmVhZHkgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgY29uc3QgaXNMb2FkaW5nID0gc2hhbGxvd1JlZihmYWxzZSk7XG4gIGNvbnN0IGVycm9yID0gc2hhbGxvd1JlZih2b2lkIDApO1xuICBhc3luYyBmdW5jdGlvbiBleGVjdXRlKGRlbGF5MiA9IDAsIC4uLmFyZ3MpIHtcbiAgICBpZiAocmVzZXRPbkV4ZWN1dGUpXG4gICAgICBzdGF0ZS52YWx1ZSA9IHRvVmFsdWUoaW5pdGlhbFN0YXRlKTtcbiAgICBlcnJvci52YWx1ZSA9IHZvaWQgMDtcbiAgICBpc1JlYWR5LnZhbHVlID0gZmFsc2U7XG4gICAgaXNMb2FkaW5nLnZhbHVlID0gdHJ1ZTtcbiAgICBpZiAoZGVsYXkyID4gMClcbiAgICAgIGF3YWl0IHByb21pc2VUaW1lb3V0KGRlbGF5Mik7XG4gICAgY29uc3QgX3Byb21pc2UgPSB0eXBlb2YgcHJvbWlzZSA9PT0gXCJmdW5jdGlvblwiID8gcHJvbWlzZSguLi5hcmdzKSA6IHByb21pc2U7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBfcHJvbWlzZTtcbiAgICAgIHN0YXRlLnZhbHVlID0gZGF0YTtcbiAgICAgIGlzUmVhZHkudmFsdWUgPSB0cnVlO1xuICAgICAgb25TdWNjZXNzKGRhdGEpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGVycm9yLnZhbHVlID0gZTtcbiAgICAgIG9uRXJyb3IoZSk7XG4gICAgICBpZiAodGhyb3dFcnJvcilcbiAgICAgICAgdGhyb3cgZTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgaXNMb2FkaW5nLnZhbHVlID0gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiBzdGF0ZS52YWx1ZTtcbiAgfVxuICBpZiAoaW1tZWRpYXRlKSB7XG4gICAgZXhlY3V0ZShkZWxheSk7XG4gIH1cbiAgY29uc3Qgc2hlbGwgPSB7XG4gICAgc3RhdGUsXG4gICAgaXNSZWFkeSxcbiAgICBpc0xvYWRpbmcsXG4gICAgZXJyb3IsXG4gICAgZXhlY3V0ZSxcbiAgICBleGVjdXRlSW1tZWRpYXRlOiAoLi4uYXJncykgPT4gZXhlY3V0ZSgwLCAuLi5hcmdzKVxuICB9O1xuICBmdW5jdGlvbiB3YWl0VW50aWxJc0xvYWRlZCgpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdW50aWwoaXNMb2FkaW5nKS50b0JlKGZhbHNlKS50aGVuKCgpID0+IHJlc29sdmUoc2hlbGwpKS5jYXRjaChyZWplY3QpO1xuICAgIH0pO1xuICB9XG4gIHJldHVybiB7XG4gICAgLi4uc2hlbGwsXG4gICAgdGhlbihvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCkge1xuICAgICAgcmV0dXJuIHdhaXRVbnRpbElzTG9hZGVkKCkudGhlbihvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCk7XG4gICAgfVxuICB9O1xufVxuXG5jb25zdCBkZWZhdWx0cyA9IHtcbiAgYXJyYXk6ICh2KSA9PiBKU09OLnN0cmluZ2lmeSh2KSxcbiAgb2JqZWN0OiAodikgPT4gSlNPTi5zdHJpbmdpZnkodiksXG4gIHNldDogKHYpID0+IEpTT04uc3RyaW5naWZ5KEFycmF5LmZyb20odikpLFxuICBtYXA6ICh2KSA9PiBKU09OLnN0cmluZ2lmeShPYmplY3QuZnJvbUVudHJpZXModikpLFxuICBudWxsOiAoKSA9PiBcIlwiXG59O1xuZnVuY3Rpb24gZ2V0RGVmYXVsdFNlcmlhbGl6YXRpb24odGFyZ2V0KSB7XG4gIGlmICghdGFyZ2V0KVxuICAgIHJldHVybiBkZWZhdWx0cy5udWxsO1xuICBpZiAodGFyZ2V0IGluc3RhbmNlb2YgTWFwKVxuICAgIHJldHVybiBkZWZhdWx0cy5tYXA7XG4gIGVsc2UgaWYgKHRhcmdldCBpbnN0YW5jZW9mIFNldClcbiAgICByZXR1cm4gZGVmYXVsdHMuc2V0O1xuICBlbHNlIGlmIChBcnJheS5pc0FycmF5KHRhcmdldCkpXG4gICAgcmV0dXJuIGRlZmF1bHRzLmFycmF5O1xuICBlbHNlXG4gICAgcmV0dXJuIGRlZmF1bHRzLm9iamVjdDtcbn1cblxuZnVuY3Rpb24gdXNlQmFzZTY0KHRhcmdldCwgb3B0aW9ucykge1xuICBjb25zdCBiYXNlNjQgPSBzaGFsbG93UmVmKFwiXCIpO1xuICBjb25zdCBwcm9taXNlID0gc2hhbGxvd1JlZigpO1xuICBmdW5jdGlvbiBleGVjdXRlKCkge1xuICAgIGlmICghaXNDbGllbnQpXG4gICAgICByZXR1cm47XG4gICAgcHJvbWlzZS52YWx1ZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IF90YXJnZXQgPSB0b1ZhbHVlKHRhcmdldCk7XG4gICAgICAgIGlmIChfdGFyZ2V0ID09IG51bGwpIHtcbiAgICAgICAgICByZXNvbHZlKFwiXCIpO1xuICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiBfdGFyZ2V0ID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgcmVzb2x2ZShibG9iVG9CYXNlNjQobmV3IEJsb2IoW190YXJnZXRdLCB7IHR5cGU6IFwidGV4dC9wbGFpblwiIH0pKSk7XG4gICAgICAgIH0gZWxzZSBpZiAoX3RhcmdldCBpbnN0YW5jZW9mIEJsb2IpIHtcbiAgICAgICAgICByZXNvbHZlKGJsb2JUb0Jhc2U2NChfdGFyZ2V0KSk7XG4gICAgICAgIH0gZWxzZSBpZiAoX3RhcmdldCBpbnN0YW5jZW9mIEFycmF5QnVmZmVyKSB7XG4gICAgICAgICAgcmVzb2x2ZSh3aW5kb3cuYnRvYShTdHJpbmcuZnJvbUNoYXJDb2RlKC4uLm5ldyBVaW50OEFycmF5KF90YXJnZXQpKSkpO1xuICAgICAgICB9IGVsc2UgaWYgKF90YXJnZXQgaW5zdGFuY2VvZiBIVE1MQ2FudmFzRWxlbWVudCkge1xuICAgICAgICAgIHJlc29sdmUoX3RhcmdldC50b0RhdGFVUkwob3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy50eXBlLCBvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLnF1YWxpdHkpKTtcbiAgICAgICAgfSBlbHNlIGlmIChfdGFyZ2V0IGluc3RhbmNlb2YgSFRNTEltYWdlRWxlbWVudCkge1xuICAgICAgICAgIGNvbnN0IGltZyA9IF90YXJnZXQuY2xvbmVOb2RlKGZhbHNlKTtcbiAgICAgICAgICBpbWcuY3Jvc3NPcmlnaW4gPSBcIkFub255bW91c1wiO1xuICAgICAgICAgIGltZ0xvYWRlZChpbWcpLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgY2FudmFzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImNhbnZhc1wiKTtcbiAgICAgICAgICAgIGNvbnN0IGN0eCA9IGNhbnZhcy5nZXRDb250ZXh0KFwiMmRcIik7XG4gICAgICAgICAgICBjYW52YXMud2lkdGggPSBpbWcud2lkdGg7XG4gICAgICAgICAgICBjYW52YXMuaGVpZ2h0ID0gaW1nLmhlaWdodDtcbiAgICAgICAgICAgIGN0eC5kcmF3SW1hZ2UoaW1nLCAwLCAwLCBjYW52YXMud2lkdGgsIGNhbnZhcy5oZWlnaHQpO1xuICAgICAgICAgICAgcmVzb2x2ZShjYW52YXMudG9EYXRhVVJMKG9wdGlvbnMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdGlvbnMudHlwZSwgb3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy5xdWFsaXR5KSk7XG4gICAgICAgICAgfSkuY2F0Y2gocmVqZWN0KTtcbiAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgX3RhcmdldCA9PT0gXCJvYmplY3RcIikge1xuICAgICAgICAgIGNvbnN0IF9zZXJpYWxpemVGbiA9IChvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLnNlcmlhbGl6ZXIpIHx8IGdldERlZmF1bHRTZXJpYWxpemF0aW9uKF90YXJnZXQpO1xuICAgICAgICAgIGNvbnN0IHNlcmlhbGl6ZWQgPSBfc2VyaWFsaXplRm4oX3RhcmdldCk7XG4gICAgICAgICAgcmV0dXJuIHJlc29sdmUoYmxvYlRvQmFzZTY0KG5ldyBCbG9iKFtzZXJpYWxpemVkXSwgeyB0eXBlOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9KSkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoXCJ0YXJnZXQgaXMgdW5zdXBwb3J0ZWQgdHlwZXNcIikpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZWplY3QoZXJyb3IpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHByb21pc2UudmFsdWUudGhlbigocmVzKSA9PiB7XG4gICAgICBiYXNlNjQudmFsdWUgPSAob3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy5kYXRhVXJsKSA9PT0gZmFsc2UgPyByZXMucmVwbGFjZSgvXmRhdGE6Lio/O2Jhc2U2NCwvLCBcIlwiKSA6IHJlcztcbiAgICB9KTtcbiAgICByZXR1cm4gcHJvbWlzZS52YWx1ZTtcbiAgfVxuICBpZiAoaXNSZWYodGFyZ2V0KSB8fCB0eXBlb2YgdGFyZ2V0ID09PSBcImZ1bmN0aW9uXCIpXG4gICAgd2F0Y2godGFyZ2V0LCBleGVjdXRlLCB7IGltbWVkaWF0ZTogdHJ1ZSB9KTtcbiAgZWxzZVxuICAgIGV4ZWN1dGUoKTtcbiAgcmV0dXJuIHtcbiAgICBiYXNlNjQsXG4gICAgcHJvbWlzZSxcbiAgICBleGVjdXRlXG4gIH07XG59XG5mdW5jdGlvbiBpbWdMb2FkZWQoaW1nKSB7XG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgaWYgKCFpbWcuY29tcGxldGUpIHtcbiAgICAgIGltZy5vbmxvYWQgPSAoKSA9PiB7XG4gICAgICAgIHJlc29sdmUoKTtcbiAgICAgIH07XG4gICAgICBpbWcub25lcnJvciA9IHJlamVjdDtcbiAgICB9IGVsc2Uge1xuICAgICAgcmVzb2x2ZSgpO1xuICAgIH1cbiAgfSk7XG59XG5mdW5jdGlvbiBibG9iVG9CYXNlNjQoYmxvYikge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIGNvbnN0IGZyID0gbmV3IEZpbGVSZWFkZXIoKTtcbiAgICBmci5vbmxvYWQgPSAoZSkgPT4ge1xuICAgICAgcmVzb2x2ZShlLnRhcmdldC5yZXN1bHQpO1xuICAgIH07XG4gICAgZnIub25lcnJvciA9IHJlamVjdDtcbiAgICBmci5yZWFkQXNEYXRhVVJMKGJsb2IpO1xuICB9KTtcbn1cblxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHVzZUJhdHRlcnkob3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHsgbmF2aWdhdG9yID0gZGVmYXVsdE5hdmlnYXRvciB9ID0gb3B0aW9ucztcbiAgY29uc3QgZXZlbnRzID0gW1wiY2hhcmdpbmdjaGFuZ2VcIiwgXCJjaGFyZ2luZ3RpbWVjaGFuZ2VcIiwgXCJkaXNjaGFyZ2luZ3RpbWVjaGFuZ2VcIiwgXCJsZXZlbGNoYW5nZVwiXTtcbiAgY29uc3QgaXNTdXBwb3J0ZWQgPSB1c2VTdXBwb3J0ZWQoKCkgPT4gbmF2aWdhdG9yICYmIFwiZ2V0QmF0dGVyeVwiIGluIG5hdmlnYXRvciAmJiB0eXBlb2YgbmF2aWdhdG9yLmdldEJhdHRlcnkgPT09IFwiZnVuY3Rpb25cIik7XG4gIGNvbnN0IGNoYXJnaW5nID0gc2hhbGxvd1JlZihmYWxzZSk7XG4gIGNvbnN0IGNoYXJnaW5nVGltZSA9IHNoYWxsb3dSZWYoMCk7XG4gIGNvbnN0IGRpc2NoYXJnaW5nVGltZSA9IHNoYWxsb3dSZWYoMCk7XG4gIGNvbnN0IGxldmVsID0gc2hhbGxvd1JlZigxKTtcbiAgbGV0IGJhdHRlcnk7XG4gIGZ1bmN0aW9uIHVwZGF0ZUJhdHRlcnlJbmZvKCkge1xuICAgIGNoYXJnaW5nLnZhbHVlID0gdGhpcy5jaGFyZ2luZztcbiAgICBjaGFyZ2luZ1RpbWUudmFsdWUgPSB0aGlzLmNoYXJnaW5nVGltZSB8fCAwO1xuICAgIGRpc2NoYXJnaW5nVGltZS52YWx1ZSA9IHRoaXMuZGlzY2hhcmdpbmdUaW1lIHx8IDA7XG4gICAgbGV2ZWwudmFsdWUgPSB0aGlzLmxldmVsO1xuICB9XG4gIGlmIChpc1N1cHBvcnRlZC52YWx1ZSkge1xuICAgIG5hdmlnYXRvci5nZXRCYXR0ZXJ5KCkudGhlbigoX2JhdHRlcnkpID0+IHtcbiAgICAgIGJhdHRlcnkgPSBfYmF0dGVyeTtcbiAgICAgIHVwZGF0ZUJhdHRlcnlJbmZvLmNhbGwoYmF0dGVyeSk7XG4gICAgICB1c2VFdmVudExpc3RlbmVyKGJhdHRlcnksIGV2ZW50cywgdXBkYXRlQmF0dGVyeUluZm8sIHsgcGFzc2l2ZTogdHJ1ZSB9KTtcbiAgICB9KTtcbiAgfVxuICByZXR1cm4ge1xuICAgIGlzU3VwcG9ydGVkLFxuICAgIGNoYXJnaW5nLFxuICAgIGNoYXJnaW5nVGltZSxcbiAgICBkaXNjaGFyZ2luZ1RpbWUsXG4gICAgbGV2ZWxcbiAgfTtcbn1cblxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHVzZUJsdWV0b290aChvcHRpb25zKSB7XG4gIGxldCB7XG4gICAgYWNjZXB0QWxsRGV2aWNlcyA9IGZhbHNlXG4gIH0gPSBvcHRpb25zIHx8IHt9O1xuICBjb25zdCB7XG4gICAgZmlsdGVycyA9IHZvaWQgMCxcbiAgICBvcHRpb25hbFNlcnZpY2VzID0gdm9pZCAwLFxuICAgIG5hdmlnYXRvciA9IGRlZmF1bHROYXZpZ2F0b3JcbiAgfSA9IG9wdGlvbnMgfHwge307XG4gIGNvbnN0IGlzU3VwcG9ydGVkID0gdXNlU3VwcG9ydGVkKCgpID0+IG5hdmlnYXRvciAmJiBcImJsdWV0b290aFwiIGluIG5hdmlnYXRvcik7XG4gIGNvbnN0IGRldmljZSA9IHNoYWxsb3dSZWYoKTtcbiAgY29uc3QgZXJyb3IgPSBzaGFsbG93UmVmKG51bGwpO1xuICB3YXRjaChkZXZpY2UsICgpID0+IHtcbiAgICBjb25uZWN0VG9CbHVldG9vdGhHQVRUU2VydmVyKCk7XG4gIH0pO1xuICBhc3luYyBmdW5jdGlvbiByZXF1ZXN0RGV2aWNlKCkge1xuICAgIGlmICghaXNTdXBwb3J0ZWQudmFsdWUpXG4gICAgICByZXR1cm47XG4gICAgZXJyb3IudmFsdWUgPSBudWxsO1xuICAgIGlmIChmaWx0ZXJzICYmIGZpbHRlcnMubGVuZ3RoID4gMClcbiAgICAgIGFjY2VwdEFsbERldmljZXMgPSBmYWxzZTtcbiAgICB0cnkge1xuICAgICAgZGV2aWNlLnZhbHVlID0gYXdhaXQgKG5hdmlnYXRvciA9PSBudWxsID8gdm9pZCAwIDogbmF2aWdhdG9yLmJsdWV0b290aC5yZXF1ZXN0RGV2aWNlKHtcbiAgICAgICAgYWNjZXB0QWxsRGV2aWNlcyxcbiAgICAgICAgZmlsdGVycyxcbiAgICAgICAgb3B0aW9uYWxTZXJ2aWNlc1xuICAgICAgfSkpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgZXJyb3IudmFsdWUgPSBlcnI7XG4gICAgfVxuICB9XG4gIGNvbnN0IHNlcnZlciA9IHNoYWxsb3dSZWYoKTtcbiAgY29uc3QgaXNDb25uZWN0ZWQgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgZnVuY3Rpb24gcmVzZXQoKSB7XG4gICAgaXNDb25uZWN0ZWQudmFsdWUgPSBmYWxzZTtcbiAgICBkZXZpY2UudmFsdWUgPSB2b2lkIDA7XG4gICAgc2VydmVyLnZhbHVlID0gdm9pZCAwO1xuICB9XG4gIGFzeW5jIGZ1bmN0aW9uIGNvbm5lY3RUb0JsdWV0b290aEdBVFRTZXJ2ZXIoKSB7XG4gICAgZXJyb3IudmFsdWUgPSBudWxsO1xuICAgIGlmIChkZXZpY2UudmFsdWUgJiYgZGV2aWNlLnZhbHVlLmdhdHQpIHtcbiAgICAgIHVzZUV2ZW50TGlzdGVuZXIoZGV2aWNlLCBcImdhdHRzZXJ2ZXJkaXNjb25uZWN0ZWRcIiwgcmVzZXQsIHsgcGFzc2l2ZTogdHJ1ZSB9KTtcbiAgICAgIHRyeSB7XG4gICAgICAgIHNlcnZlci52YWx1ZSA9IGF3YWl0IGRldmljZS52YWx1ZS5nYXR0LmNvbm5lY3QoKTtcbiAgICAgICAgaXNDb25uZWN0ZWQudmFsdWUgPSBzZXJ2ZXIudmFsdWUuY29ubmVjdGVkO1xuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGVycm9yLnZhbHVlID0gZXJyO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICB0cnlPbk1vdW50ZWQoKCkgPT4ge1xuICAgIHZhciBfYTtcbiAgICBpZiAoZGV2aWNlLnZhbHVlKVxuICAgICAgKF9hID0gZGV2aWNlLnZhbHVlLmdhdHQpID09IG51bGwgPyB2b2lkIDAgOiBfYS5jb25uZWN0KCk7XG4gIH0pO1xuICB0cnlPblNjb3BlRGlzcG9zZSgoKSA9PiB7XG4gICAgdmFyIF9hO1xuICAgIGlmIChkZXZpY2UudmFsdWUpXG4gICAgICAoX2EgPSBkZXZpY2UudmFsdWUuZ2F0dCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLmRpc2Nvbm5lY3QoKTtcbiAgfSk7XG4gIHJldHVybiB7XG4gICAgaXNTdXBwb3J0ZWQsXG4gICAgaXNDb25uZWN0ZWQ6IHJlYWRvbmx5KGlzQ29ubmVjdGVkKSxcbiAgICAvLyBEZXZpY2U6XG4gICAgZGV2aWNlLFxuICAgIHJlcXVlc3REZXZpY2UsXG4gICAgLy8gU2VydmVyOlxuICAgIHNlcnZlcixcbiAgICAvLyBFcnJvcnM6XG4gICAgZXJyb3JcbiAgfTtcbn1cblxuY29uc3Qgc3NyV2lkdGhTeW1ib2wgPSBTeW1ib2woXCJ2dWV1c2Utc3NyLXdpZHRoXCIpO1xuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHVzZVNTUldpZHRoKCkge1xuICBjb25zdCBzc3JXaWR0aCA9IGhhc0luamVjdGlvbkNvbnRleHQoKSA/IGluamVjdExvY2FsKHNzcldpZHRoU3ltYm9sLCBudWxsKSA6IG51bGw7XG4gIHJldHVybiB0eXBlb2Ygc3NyV2lkdGggPT09IFwibnVtYmVyXCIgPyBzc3JXaWR0aCA6IHZvaWQgMDtcbn1cbmZ1bmN0aW9uIHByb3ZpZGVTU1JXaWR0aCh3aWR0aCwgYXBwKSB7XG4gIGlmIChhcHAgIT09IHZvaWQgMCkge1xuICAgIGFwcC5wcm92aWRlKHNzcldpZHRoU3ltYm9sLCB3aWR0aCk7XG4gIH0gZWxzZSB7XG4gICAgcHJvdmlkZUxvY2FsKHNzcldpZHRoU3ltYm9sLCB3aWR0aCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gdXNlTWVkaWFRdWVyeShxdWVyeSwgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHsgd2luZG93ID0gZGVmYXVsdFdpbmRvdywgc3NyV2lkdGggPSB1c2VTU1JXaWR0aCgpIH0gPSBvcHRpb25zO1xuICBjb25zdCBpc1N1cHBvcnRlZCA9IHVzZVN1cHBvcnRlZCgoKSA9PiB3aW5kb3cgJiYgXCJtYXRjaE1lZGlhXCIgaW4gd2luZG93ICYmIHR5cGVvZiB3aW5kb3cubWF0Y2hNZWRpYSA9PT0gXCJmdW5jdGlvblwiKTtcbiAgY29uc3Qgc3NyU3VwcG9ydCA9IHNoYWxsb3dSZWYodHlwZW9mIHNzcldpZHRoID09PSBcIm51bWJlclwiKTtcbiAgY29uc3QgbWVkaWFRdWVyeSA9IHNoYWxsb3dSZWYoKTtcbiAgY29uc3QgbWF0Y2hlcyA9IHNoYWxsb3dSZWYoZmFsc2UpO1xuICBjb25zdCBoYW5kbGVyID0gKGV2ZW50KSA9PiB7XG4gICAgbWF0Y2hlcy52YWx1ZSA9IGV2ZW50Lm1hdGNoZXM7XG4gIH07XG4gIHdhdGNoRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoc3NyU3VwcG9ydC52YWx1ZSkge1xuICAgICAgc3NyU3VwcG9ydC52YWx1ZSA9ICFpc1N1cHBvcnRlZC52YWx1ZTtcbiAgICAgIGNvbnN0IHF1ZXJ5U3RyaW5ncyA9IHRvVmFsdWUocXVlcnkpLnNwbGl0KFwiLFwiKTtcbiAgICAgIG1hdGNoZXMudmFsdWUgPSBxdWVyeVN0cmluZ3Muc29tZSgocXVlcnlTdHJpbmcpID0+IHtcbiAgICAgICAgY29uc3Qgbm90ID0gcXVlcnlTdHJpbmcuaW5jbHVkZXMoXCJub3QgYWxsXCIpO1xuICAgICAgICBjb25zdCBtaW5XaWR0aCA9IHF1ZXJ5U3RyaW5nLm1hdGNoKC9cXChcXHMqbWluLXdpZHRoOlxccyooLT9cXGQrKD86XFwuXFxkKik/W2Etel0rXFxzKilcXCkvKTtcbiAgICAgICAgY29uc3QgbWF4V2lkdGggPSBxdWVyeVN0cmluZy5tYXRjaCgvXFwoXFxzKm1heC13aWR0aDpcXHMqKC0/XFxkKyg/OlxcLlxcZCopP1thLXpdK1xccyopXFwpLyk7XG4gICAgICAgIGxldCByZXMgPSBCb29sZWFuKG1pbldpZHRoIHx8IG1heFdpZHRoKTtcbiAgICAgICAgaWYgKG1pbldpZHRoICYmIHJlcykge1xuICAgICAgICAgIHJlcyA9IHNzcldpZHRoID49IHB4VmFsdWUobWluV2lkdGhbMV0pO1xuICAgICAgICB9XG4gICAgICAgIGlmIChtYXhXaWR0aCAmJiByZXMpIHtcbiAgICAgICAgICByZXMgPSBzc3JXaWR0aCA8PSBweFZhbHVlKG1heFdpZHRoWzFdKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbm90ID8gIXJlcyA6IHJlcztcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoIWlzU3VwcG9ydGVkLnZhbHVlKVxuICAgICAgcmV0dXJuO1xuICAgIG1lZGlhUXVlcnkudmFsdWUgPSB3aW5kb3cubWF0Y2hNZWRpYSh0b1ZhbHVlKHF1ZXJ5KSk7XG4gICAgbWF0Y2hlcy52YWx1ZSA9IG1lZGlhUXVlcnkudmFsdWUubWF0Y2hlcztcbiAgfSk7XG4gIHVzZUV2ZW50TGlzdGVuZXIobWVkaWFRdWVyeSwgXCJjaGFuZ2VcIiwgaGFuZGxlciwgeyBwYXNzaXZlOiB0cnVlIH0pO1xuICByZXR1cm4gY29tcHV0ZWQoKCkgPT4gbWF0Y2hlcy52YWx1ZSk7XG59XG5cbmNvbnN0IGJyZWFrcG9pbnRzVGFpbHdpbmQgPSB7XG4gIFwic21cIjogNjQwLFxuICBcIm1kXCI6IDc2OCxcbiAgXCJsZ1wiOiAxMDI0LFxuICBcInhsXCI6IDEyODAsXG4gIFwiMnhsXCI6IDE1MzZcbn07XG5jb25zdCBicmVha3BvaW50c0Jvb3RzdHJhcFY1ID0ge1xuICB4czogMCxcbiAgc206IDU3NixcbiAgbWQ6IDc2OCxcbiAgbGc6IDk5MixcbiAgeGw6IDEyMDAsXG4gIHh4bDogMTQwMFxufTtcbmNvbnN0IGJyZWFrcG9pbnRzVnVldGlmeVYyID0ge1xuICB4czogMCxcbiAgc206IDYwMCxcbiAgbWQ6IDk2MCxcbiAgbGc6IDEyNjQsXG4gIHhsOiAxOTA0XG59O1xuY29uc3QgYnJlYWtwb2ludHNWdWV0aWZ5VjMgPSB7XG4gIHhzOiAwLFxuICBzbTogNjAwLFxuICBtZDogOTYwLFxuICBsZzogMTI4MCxcbiAgeGw6IDE5MjAsXG4gIHh4bDogMjU2MFxufTtcbmNvbnN0IGJyZWFrcG9pbnRzVnVldGlmeSA9IGJyZWFrcG9pbnRzVnVldGlmeVYyO1xuY29uc3QgYnJlYWtwb2ludHNBbnREZXNpZ24gPSB7XG4gIHhzOiA0ODAsXG4gIHNtOiA1NzYsXG4gIG1kOiA3NjgsXG4gIGxnOiA5OTIsXG4gIHhsOiAxMjAwLFxuICB4eGw6IDE2MDBcbn07XG5jb25zdCBicmVha3BvaW50c1F1YXNhciA9IHtcbiAgeHM6IDAsXG4gIHNtOiA2MDAsXG4gIG1kOiAxMDI0LFxuICBsZzogMTQ0MCxcbiAgeGw6IDE5MjBcbn07XG5jb25zdCBicmVha3BvaW50c1NlbWF0aWMgPSB7XG4gIG1vYmlsZVM6IDMyMCxcbiAgbW9iaWxlTTogMzc1LFxuICBtb2JpbGVMOiA0MjUsXG4gIHRhYmxldDogNzY4LFxuICBsYXB0b3A6IDEwMjQsXG4gIGxhcHRvcEw6IDE0NDAsXG4gIGRlc2t0b3A0SzogMjU2MFxufTtcbmNvbnN0IGJyZWFrcG9pbnRzTWFzdGVyQ3NzID0ge1xuICBcIjN4c1wiOiAzNjAsXG4gIFwiMnhzXCI6IDQ4MCxcbiAgXCJ4c1wiOiA2MDAsXG4gIFwic21cIjogNzY4LFxuICBcIm1kXCI6IDEwMjQsXG4gIFwibGdcIjogMTI4MCxcbiAgXCJ4bFwiOiAxNDQwLFxuICBcIjJ4bFwiOiAxNjAwLFxuICBcIjN4bFwiOiAxOTIwLFxuICBcIjR4bFwiOiAyNTYwXG59O1xuY29uc3QgYnJlYWtwb2ludHNQcmltZUZsZXggPSB7XG4gIHNtOiA1NzYsXG4gIG1kOiA3NjgsXG4gIGxnOiA5OTIsXG4gIHhsOiAxMjAwXG59O1xuY29uc3QgYnJlYWtwb2ludHNFbGVtZW50ID0ge1xuICB4czogMCxcbiAgc206IDc2OCxcbiAgbWQ6IDk5MixcbiAgbGc6IDEyMDAsXG4gIHhsOiAxOTIwXG59O1xuXG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gdXNlQnJlYWtwb2ludHMoYnJlYWtwb2ludHMsIG9wdGlvbnMgPSB7fSkge1xuICBmdW5jdGlvbiBnZXRWYWx1ZShrLCBkZWx0YSkge1xuICAgIGxldCB2ID0gdG9WYWx1ZShicmVha3BvaW50c1t0b1ZhbHVlKGspXSk7XG4gICAgaWYgKGRlbHRhICE9IG51bGwpXG4gICAgICB2ID0gaW5jcmVhc2VXaXRoVW5pdCh2LCBkZWx0YSk7XG4gICAgaWYgKHR5cGVvZiB2ID09PSBcIm51bWJlclwiKVxuICAgICAgdiA9IGAke3Z9cHhgO1xuICAgIHJldHVybiB2O1xuICB9XG4gIGNvbnN0IHsgd2luZG93ID0gZGVmYXVsdFdpbmRvdywgc3RyYXRlZ3kgPSBcIm1pbi13aWR0aFwiLCBzc3JXaWR0aCA9IHVzZVNTUldpZHRoKCkgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IHNzclN1cHBvcnQgPSB0eXBlb2Ygc3NyV2lkdGggPT09IFwibnVtYmVyXCI7XG4gIGNvbnN0IG1vdW50ZWQgPSBzc3JTdXBwb3J0ID8gc2hhbGxvd1JlZihmYWxzZSkgOiB7IHZhbHVlOiB0cnVlIH07XG4gIGlmIChzc3JTdXBwb3J0KSB7XG4gICAgdHJ5T25Nb3VudGVkKCgpID0+IG1vdW50ZWQudmFsdWUgPSAhIXdpbmRvdyk7XG4gIH1cbiAgZnVuY3Rpb24gbWF0Y2gocXVlcnksIHNpemUpIHtcbiAgICBpZiAoIW1vdW50ZWQudmFsdWUgJiYgc3NyU3VwcG9ydCkge1xuICAgICAgcmV0dXJuIHF1ZXJ5ID09PSBcIm1pblwiID8gc3NyV2lkdGggPj0gcHhWYWx1ZShzaXplKSA6IHNzcldpZHRoIDw9IHB4VmFsdWUoc2l6ZSk7XG4gICAgfVxuICAgIGlmICghd2luZG93KVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIHJldHVybiB3aW5kb3cubWF0Y2hNZWRpYShgKCR7cXVlcnl9LXdpZHRoOiAke3NpemV9KWApLm1hdGNoZXM7XG4gIH1cbiAgY29uc3QgZ3JlYXRlck9yRXF1YWwgPSAoaykgPT4ge1xuICAgIHJldHVybiB1c2VNZWRpYVF1ZXJ5KCgpID0+IGAobWluLXdpZHRoOiAke2dldFZhbHVlKGspfSlgLCBvcHRpb25zKTtcbiAgfTtcbiAgY29uc3Qgc21hbGxlck9yRXF1YWwgPSAoaykgPT4ge1xuICAgIHJldHVybiB1c2VNZWRpYVF1ZXJ5KCgpID0+IGAobWF4LXdpZHRoOiAke2dldFZhbHVlKGspfSlgLCBvcHRpb25zKTtcbiAgfTtcbiAgY29uc3Qgc2hvcnRjdXRNZXRob2RzID0gT2JqZWN0LmtleXMoYnJlYWtwb2ludHMpLnJlZHVjZSgoc2hvcnRjdXRzLCBrKSA9PiB7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHNob3J0Y3V0cywgaywge1xuICAgICAgZ2V0OiAoKSA9PiBzdHJhdGVneSA9PT0gXCJtaW4td2lkdGhcIiA/IGdyZWF0ZXJPckVxdWFsKGspIDogc21hbGxlck9yRXF1YWwoayksXG4gICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgY29uZmlndXJhYmxlOiB0cnVlXG4gICAgfSk7XG4gICAgcmV0dXJuIHNob3J0Y3V0cztcbiAgfSwge30pO1xuICBmdW5jdGlvbiBjdXJyZW50KCkge1xuICAgIGNvbnN0IHBvaW50cyA9IE9iamVjdC5rZXlzKGJyZWFrcG9pbnRzKS5tYXAoKGspID0+IFtrLCBzaG9ydGN1dE1ldGhvZHNba10sIHB4VmFsdWUoZ2V0VmFsdWUoaykpXSkuc29ydCgoYSwgYikgPT4gYVsyXSAtIGJbMl0pO1xuICAgIHJldHVybiBjb21wdXRlZCgoKSA9PiBwb2ludHMuZmlsdGVyKChbLCB2XSkgPT4gdi52YWx1ZSkubWFwKChba10pID0+IGspKTtcbiAgfVxuICByZXR1cm4gT2JqZWN0LmFzc2lnbihzaG9ydGN1dE1ldGhvZHMsIHtcbiAgICBncmVhdGVyT3JFcXVhbCxcbiAgICBzbWFsbGVyT3JFcXVhbCxcbiAgICBncmVhdGVyKGspIHtcbiAgICAgIHJldHVybiB1c2VNZWRpYVF1ZXJ5KCgpID0+IGAobWluLXdpZHRoOiAke2dldFZhbHVlKGssIDAuMSl9KWAsIG9wdGlvbnMpO1xuICAgIH0sXG4gICAgc21hbGxlcihrKSB7XG4gICAgICByZXR1cm4gdXNlTWVkaWFRdWVyeSgoKSA9PiBgKG1heC13aWR0aDogJHtnZXRWYWx1ZShrLCAtMC4xKX0pYCwgb3B0aW9ucyk7XG4gICAgfSxcbiAgICBiZXR3ZWVuKGEsIGIpIHtcbiAgICAgIHJldHVybiB1c2VNZWRpYVF1ZXJ5KCgpID0+IGAobWluLXdpZHRoOiAke2dldFZhbHVlKGEpfSkgYW5kIChtYXgtd2lkdGg6ICR7Z2V0VmFsdWUoYiwgLTAuMSl9KWAsIG9wdGlvbnMpO1xuICAgIH0sXG4gICAgaXNHcmVhdGVyKGspIHtcbiAgICAgIHJldHVybiBtYXRjaChcIm1pblwiLCBnZXRWYWx1ZShrLCAwLjEpKTtcbiAgICB9LFxuICAgIGlzR3JlYXRlck9yRXF1YWwoaykge1xuICAgICAgcmV0dXJuIG1hdGNoKFwibWluXCIsIGdldFZhbHVlKGspKTtcbiAgICB9LFxuICAgIGlzU21hbGxlcihrKSB7XG4gICAgICByZXR1cm4gbWF0Y2goXCJtYXhcIiwgZ2V0VmFsdWUoaywgLTAuMSkpO1xuICAgIH0sXG4gICAgaXNTbWFsbGVyT3JFcXVhbChrKSB7XG4gICAgICByZXR1cm4gbWF0Y2goXCJtYXhcIiwgZ2V0VmFsdWUoaykpO1xuICAgIH0sXG4gICAgaXNJbkJldHdlZW4oYSwgYikge1xuICAgICAgcmV0dXJuIG1hdGNoKFwibWluXCIsIGdldFZhbHVlKGEpKSAmJiBtYXRjaChcIm1heFwiLCBnZXRWYWx1ZShiLCAtMC4xKSk7XG4gICAgfSxcbiAgICBjdXJyZW50LFxuICAgIGFjdGl2ZSgpIHtcbiAgICAgIGNvbnN0IGJwcyA9IGN1cnJlbnQoKTtcbiAgICAgIHJldHVybiBjb21wdXRlZCgoKSA9PiBicHMudmFsdWUubGVuZ3RoID09PSAwID8gXCJcIiA6IGJwcy52YWx1ZS5hdChzdHJhdGVneSA9PT0gXCJtaW4td2lkdGhcIiA/IC0xIDogMCkpO1xuICAgIH1cbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHVzZUJyb2FkY2FzdENoYW5uZWwob3B0aW9ucykge1xuICBjb25zdCB7XG4gICAgbmFtZSxcbiAgICB3aW5kb3cgPSBkZWZhdWx0V2luZG93XG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBpc1N1cHBvcnRlZCA9IHVzZVN1cHBvcnRlZCgoKSA9PiB3aW5kb3cgJiYgXCJCcm9hZGNhc3RDaGFubmVsXCIgaW4gd2luZG93KTtcbiAgY29uc3QgaXNDbG9zZWQgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgY29uc3QgY2hhbm5lbCA9IHJlZigpO1xuICBjb25zdCBkYXRhID0gcmVmKCk7XG4gIGNvbnN0IGVycm9yID0gc2hhbGxvd1JlZihudWxsKTtcbiAgY29uc3QgcG9zdCA9IChkYXRhMikgPT4ge1xuICAgIGlmIChjaGFubmVsLnZhbHVlKVxuICAgICAgY2hhbm5lbC52YWx1ZS5wb3N0TWVzc2FnZShkYXRhMik7XG4gIH07XG4gIGNvbnN0IGNsb3NlID0gKCkgPT4ge1xuICAgIGlmIChjaGFubmVsLnZhbHVlKVxuICAgICAgY2hhbm5lbC52YWx1ZS5jbG9zZSgpO1xuICAgIGlzQ2xvc2VkLnZhbHVlID0gdHJ1ZTtcbiAgfTtcbiAgaWYgKGlzU3VwcG9ydGVkLnZhbHVlKSB7XG4gICAgdHJ5T25Nb3VudGVkKCgpID0+IHtcbiAgICAgIGVycm9yLnZhbHVlID0gbnVsbDtcbiAgICAgIGNoYW5uZWwudmFsdWUgPSBuZXcgQnJvYWRjYXN0Q2hhbm5lbChuYW1lKTtcbiAgICAgIGNvbnN0IGxpc3RlbmVyT3B0aW9ucyA9IHtcbiAgICAgICAgcGFzc2l2ZTogdHJ1ZVxuICAgICAgfTtcbiAgICAgIHVzZUV2ZW50TGlzdGVuZXIoY2hhbm5lbCwgXCJtZXNzYWdlXCIsIChlKSA9PiB7XG4gICAgICAgIGRhdGEudmFsdWUgPSBlLmRhdGE7XG4gICAgICB9LCBsaXN0ZW5lck9wdGlvbnMpO1xuICAgICAgdXNlRXZlbnRMaXN0ZW5lcihjaGFubmVsLCBcIm1lc3NhZ2VlcnJvclwiLCAoZSkgPT4ge1xuICAgICAgICBlcnJvci52YWx1ZSA9IGU7XG4gICAgICB9LCBsaXN0ZW5lck9wdGlvbnMpO1xuICAgICAgdXNlRXZlbnRMaXN0ZW5lcihjaGFubmVsLCBcImNsb3NlXCIsICgpID0+IHtcbiAgICAgICAgaXNDbG9zZWQudmFsdWUgPSB0cnVlO1xuICAgICAgfSwgbGlzdGVuZXJPcHRpb25zKTtcbiAgICB9KTtcbiAgfVxuICB0cnlPblNjb3BlRGlzcG9zZSgoKSA9PiB7XG4gICAgY2xvc2UoKTtcbiAgfSk7XG4gIHJldHVybiB7XG4gICAgaXNTdXBwb3J0ZWQsXG4gICAgY2hhbm5lbCxcbiAgICBkYXRhLFxuICAgIHBvc3QsXG4gICAgY2xvc2UsXG4gICAgZXJyb3IsXG4gICAgaXNDbG9zZWRcbiAgfTtcbn1cblxuY29uc3QgV1JJVEFCTEVfUFJPUEVSVElFUyA9IFtcbiAgXCJoYXNoXCIsXG4gIFwiaG9zdFwiLFxuICBcImhvc3RuYW1lXCIsXG4gIFwiaHJlZlwiLFxuICBcInBhdGhuYW1lXCIsXG4gIFwicG9ydFwiLFxuICBcInByb3RvY29sXCIsXG4gIFwic2VhcmNoXCJcbl07XG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gdXNlQnJvd3NlckxvY2F0aW9uKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7IHdpbmRvdyA9IGRlZmF1bHRXaW5kb3cgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IHJlZnMgPSBPYmplY3QuZnJvbUVudHJpZXMoXG4gICAgV1JJVEFCTEVfUFJPUEVSVElFUy5tYXAoKGtleSkgPT4gW2tleSwgcmVmKCldKVxuICApO1xuICBmb3IgKGNvbnN0IFtrZXksIHJlZl0gb2Ygb2JqZWN0RW50cmllcyhyZWZzKSkge1xuICAgIHdhdGNoKHJlZiwgKHZhbHVlKSA9PiB7XG4gICAgICBpZiAoISh3aW5kb3cgPT0gbnVsbCA/IHZvaWQgMCA6IHdpbmRvdy5sb2NhdGlvbikgfHwgd2luZG93LmxvY2F0aW9uW2tleV0gPT09IHZhbHVlKVxuICAgICAgICByZXR1cm47XG4gICAgICB3aW5kb3cubG9jYXRpb25ba2V5XSA9IHZhbHVlO1xuICAgIH0pO1xuICB9XG4gIGNvbnN0IGJ1aWxkU3RhdGUgPSAodHJpZ2dlcikgPT4ge1xuICAgIHZhciBfYTtcbiAgICBjb25zdCB7IHN0YXRlOiBzdGF0ZTIsIGxlbmd0aCB9ID0gKHdpbmRvdyA9PSBudWxsID8gdm9pZCAwIDogd2luZG93Lmhpc3RvcnkpIHx8IHt9O1xuICAgIGNvbnN0IHsgb3JpZ2luIH0gPSAod2luZG93ID09IG51bGwgPyB2b2lkIDAgOiB3aW5kb3cubG9jYXRpb24pIHx8IHt9O1xuICAgIGZvciAoY29uc3Qga2V5IG9mIFdSSVRBQkxFX1BST1BFUlRJRVMpXG4gICAgICByZWZzW2tleV0udmFsdWUgPSAoX2EgPSB3aW5kb3cgPT0gbnVsbCA/IHZvaWQgMCA6IHdpbmRvdy5sb2NhdGlvbikgPT0gbnVsbCA/IHZvaWQgMCA6IF9hW2tleV07XG4gICAgcmV0dXJuIHJlYWN0aXZlKHtcbiAgICAgIHRyaWdnZXIsXG4gICAgICBzdGF0ZTogc3RhdGUyLFxuICAgICAgbGVuZ3RoLFxuICAgICAgb3JpZ2luLFxuICAgICAgLi4ucmVmc1xuICAgIH0pO1xuICB9O1xuICBjb25zdCBzdGF0ZSA9IHJlZihidWlsZFN0YXRlKFwibG9hZFwiKSk7XG4gIGlmICh3aW5kb3cpIHtcbiAgICBjb25zdCBsaXN0ZW5lck9wdGlvbnMgPSB7IHBhc3NpdmU6IHRydWUgfTtcbiAgICB1c2VFdmVudExpc3RlbmVyKHdpbmRvdywgXCJwb3BzdGF0ZVwiLCAoKSA9PiBzdGF0ZS52YWx1ZSA9IGJ1aWxkU3RhdGUoXCJwb3BzdGF0ZVwiKSwgbGlzdGVuZXJPcHRpb25zKTtcbiAgICB1c2VFdmVudExpc3RlbmVyKHdpbmRvdywgXCJoYXNoY2hhbmdlXCIsICgpID0+IHN0YXRlLnZhbHVlID0gYnVpbGRTdGF0ZShcImhhc2hjaGFuZ2VcIiksIGxpc3RlbmVyT3B0aW9ucyk7XG4gIH1cbiAgcmV0dXJuIHN0YXRlO1xufVxuXG5mdW5jdGlvbiB1c2VDYWNoZWQocmVmVmFsdWUsIGNvbXBhcmF0b3IgPSAoYSwgYikgPT4gYSA9PT0gYiwgb3B0aW9ucykge1xuICBjb25zdCB7IGRlZXBSZWZzID0gdHJ1ZSwgLi4ud2F0Y2hPcHRpb25zIH0gPSBvcHRpb25zIHx8IHt9O1xuICBjb25zdCBjYWNoZWRWYWx1ZSA9IGNyZWF0ZVJlZihyZWZWYWx1ZS52YWx1ZSwgZGVlcFJlZnMpO1xuICB3YXRjaCgoKSA9PiByZWZWYWx1ZS52YWx1ZSwgKHZhbHVlKSA9PiB7XG4gICAgaWYgKCFjb21wYXJhdG9yKHZhbHVlLCBjYWNoZWRWYWx1ZS52YWx1ZSkpXG4gICAgICBjYWNoZWRWYWx1ZS52YWx1ZSA9IHZhbHVlO1xuICB9LCB3YXRjaE9wdGlvbnMpO1xuICByZXR1cm4gY2FjaGVkVmFsdWU7XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VQZXJtaXNzaW9uKHBlcm1pc3Npb25EZXNjLCBvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGNvbnRyb2xzID0gZmFsc2UsXG4gICAgbmF2aWdhdG9yID0gZGVmYXVsdE5hdmlnYXRvclxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgaXNTdXBwb3J0ZWQgPSB1c2VTdXBwb3J0ZWQoKCkgPT4gbmF2aWdhdG9yICYmIFwicGVybWlzc2lvbnNcIiBpbiBuYXZpZ2F0b3IpO1xuICBjb25zdCBwZXJtaXNzaW9uU3RhdHVzID0gc2hhbGxvd1JlZigpO1xuICBjb25zdCBkZXNjID0gdHlwZW9mIHBlcm1pc3Npb25EZXNjID09PSBcInN0cmluZ1wiID8geyBuYW1lOiBwZXJtaXNzaW9uRGVzYyB9IDogcGVybWlzc2lvbkRlc2M7XG4gIGNvbnN0IHN0YXRlID0gc2hhbGxvd1JlZigpO1xuICBjb25zdCB1cGRhdGUgPSAoKSA9PiB7XG4gICAgdmFyIF9hLCBfYjtcbiAgICBzdGF0ZS52YWx1ZSA9IChfYiA9IChfYSA9IHBlcm1pc3Npb25TdGF0dXMudmFsdWUpID09IG51bGwgPyB2b2lkIDAgOiBfYS5zdGF0ZSkgIT0gbnVsbCA/IF9iIDogXCJwcm9tcHRcIjtcbiAgfTtcbiAgdXNlRXZlbnRMaXN0ZW5lcihwZXJtaXNzaW9uU3RhdHVzLCBcImNoYW5nZVwiLCB1cGRhdGUsIHsgcGFzc2l2ZTogdHJ1ZSB9KTtcbiAgY29uc3QgcXVlcnkgPSBjcmVhdGVTaW5nbGV0b25Qcm9taXNlKGFzeW5jICgpID0+IHtcbiAgICBpZiAoIWlzU3VwcG9ydGVkLnZhbHVlKVxuICAgICAgcmV0dXJuO1xuICAgIGlmICghcGVybWlzc2lvblN0YXR1cy52YWx1ZSkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgcGVybWlzc2lvblN0YXR1cy52YWx1ZSA9IGF3YWl0IG5hdmlnYXRvci5wZXJtaXNzaW9ucy5xdWVyeShkZXNjKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgcGVybWlzc2lvblN0YXR1cy52YWx1ZSA9IHZvaWQgMDtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHVwZGF0ZSgpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoY29udHJvbHMpXG4gICAgICByZXR1cm4gdG9SYXcocGVybWlzc2lvblN0YXR1cy52YWx1ZSk7XG4gIH0pO1xuICBxdWVyeSgpO1xuICBpZiAoY29udHJvbHMpIHtcbiAgICByZXR1cm4ge1xuICAgICAgc3RhdGUsXG4gICAgICBpc1N1cHBvcnRlZCxcbiAgICAgIHF1ZXJ5XG4gICAgfTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gc3RhdGU7XG4gIH1cbn1cblxuZnVuY3Rpb24gdXNlQ2xpcGJvYXJkKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgbmF2aWdhdG9yID0gZGVmYXVsdE5hdmlnYXRvcixcbiAgICByZWFkID0gZmFsc2UsXG4gICAgc291cmNlLFxuICAgIGNvcGllZER1cmluZyA9IDE1MDAsXG4gICAgbGVnYWN5ID0gZmFsc2VcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGlzQ2xpcGJvYXJkQXBpU3VwcG9ydGVkID0gdXNlU3VwcG9ydGVkKCgpID0+IG5hdmlnYXRvciAmJiBcImNsaXBib2FyZFwiIGluIG5hdmlnYXRvcik7XG4gIGNvbnN0IHBlcm1pc3Npb25SZWFkID0gdXNlUGVybWlzc2lvbihcImNsaXBib2FyZC1yZWFkXCIpO1xuICBjb25zdCBwZXJtaXNzaW9uV3JpdGUgPSB1c2VQZXJtaXNzaW9uKFwiY2xpcGJvYXJkLXdyaXRlXCIpO1xuICBjb25zdCBpc1N1cHBvcnRlZCA9IGNvbXB1dGVkKCgpID0+IGlzQ2xpcGJvYXJkQXBpU3VwcG9ydGVkLnZhbHVlIHx8IGxlZ2FjeSk7XG4gIGNvbnN0IHRleHQgPSBzaGFsbG93UmVmKFwiXCIpO1xuICBjb25zdCBjb3BpZWQgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgY29uc3QgdGltZW91dCA9IHVzZVRpbWVvdXRGbigoKSA9PiBjb3BpZWQudmFsdWUgPSBmYWxzZSwgY29waWVkRHVyaW5nLCB7IGltbWVkaWF0ZTogZmFsc2UgfSk7XG4gIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVRleHQoKSB7XG4gICAgbGV0IHVzZUxlZ2FjeSA9ICEoaXNDbGlwYm9hcmRBcGlTdXBwb3J0ZWQudmFsdWUgJiYgaXNBbGxvd2VkKHBlcm1pc3Npb25SZWFkLnZhbHVlKSk7XG4gICAgaWYgKCF1c2VMZWdhY3kpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHRleHQudmFsdWUgPSBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLnJlYWRUZXh0KCk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHVzZUxlZ2FjeSA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICh1c2VMZWdhY3kpIHtcbiAgICAgIHRleHQudmFsdWUgPSBsZWdhY3lSZWFkKCk7XG4gICAgfVxuICB9XG4gIGlmIChpc1N1cHBvcnRlZC52YWx1ZSAmJiByZWFkKVxuICAgIHVzZUV2ZW50TGlzdGVuZXIoW1wiY29weVwiLCBcImN1dFwiXSwgdXBkYXRlVGV4dCwgeyBwYXNzaXZlOiB0cnVlIH0pO1xuICBhc3luYyBmdW5jdGlvbiBjb3B5KHZhbHVlID0gdG9WYWx1ZShzb3VyY2UpKSB7XG4gICAgaWYgKGlzU3VwcG9ydGVkLnZhbHVlICYmIHZhbHVlICE9IG51bGwpIHtcbiAgICAgIGxldCB1c2VMZWdhY3kgPSAhKGlzQ2xpcGJvYXJkQXBpU3VwcG9ydGVkLnZhbHVlICYmIGlzQWxsb3dlZChwZXJtaXNzaW9uV3JpdGUudmFsdWUpKTtcbiAgICAgIGlmICghdXNlTGVnYWN5KSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQodmFsdWUpO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgdXNlTGVnYWN5ID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKHVzZUxlZ2FjeSlcbiAgICAgICAgbGVnYWN5Q29weSh2YWx1ZSk7XG4gICAgICB0ZXh0LnZhbHVlID0gdmFsdWU7XG4gICAgICBjb3BpZWQudmFsdWUgPSB0cnVlO1xuICAgICAgdGltZW91dC5zdGFydCgpO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBsZWdhY3lDb3B5KHZhbHVlKSB7XG4gICAgY29uc3QgdGEgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwidGV4dGFyZWFcIik7XG4gICAgdGEudmFsdWUgPSB2YWx1ZSAhPSBudWxsID8gdmFsdWUgOiBcIlwiO1xuICAgIHRhLnN0eWxlLnBvc2l0aW9uID0gXCJhYnNvbHV0ZVwiO1xuICAgIHRhLnN0eWxlLm9wYWNpdHkgPSBcIjBcIjtcbiAgICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHRhKTtcbiAgICB0YS5zZWxlY3QoKTtcbiAgICBkb2N1bWVudC5leGVjQ29tbWFuZChcImNvcHlcIik7XG4gICAgdGEucmVtb3ZlKCk7XG4gIH1cbiAgZnVuY3Rpb24gbGVnYWN5UmVhZCgpIHtcbiAgICB2YXIgX2EsIF9iLCBfYztcbiAgICByZXR1cm4gKF9jID0gKF9iID0gKF9hID0gZG9jdW1lbnQgPT0gbnVsbCA/IHZvaWQgMCA6IGRvY3VtZW50LmdldFNlbGVjdGlvbikgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLmNhbGwoZG9jdW1lbnQpKSA9PSBudWxsID8gdm9pZCAwIDogX2IudG9TdHJpbmcoKSkgIT0gbnVsbCA/IF9jIDogXCJcIjtcbiAgfVxuICBmdW5jdGlvbiBpc0FsbG93ZWQoc3RhdHVzKSB7XG4gICAgcmV0dXJuIHN0YXR1cyA9PT0gXCJncmFudGVkXCIgfHwgc3RhdHVzID09PSBcInByb21wdFwiO1xuICB9XG4gIHJldHVybiB7XG4gICAgaXNTdXBwb3J0ZWQsXG4gICAgdGV4dCxcbiAgICBjb3BpZWQsXG4gICAgY29weVxuICB9O1xufVxuXG5mdW5jdGlvbiB1c2VDbGlwYm9hcmRJdGVtcyhvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIG5hdmlnYXRvciA9IGRlZmF1bHROYXZpZ2F0b3IsXG4gICAgcmVhZCA9IGZhbHNlLFxuICAgIHNvdXJjZSxcbiAgICBjb3BpZWREdXJpbmcgPSAxNTAwXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBpc1N1cHBvcnRlZCA9IHVzZVN1cHBvcnRlZCgoKSA9PiBuYXZpZ2F0b3IgJiYgXCJjbGlwYm9hcmRcIiBpbiBuYXZpZ2F0b3IpO1xuICBjb25zdCBjb250ZW50ID0gcmVmKFtdKTtcbiAgY29uc3QgY29waWVkID0gc2hhbGxvd1JlZihmYWxzZSk7XG4gIGNvbnN0IHRpbWVvdXQgPSB1c2VUaW1lb3V0Rm4oKCkgPT4gY29waWVkLnZhbHVlID0gZmFsc2UsIGNvcGllZER1cmluZywgeyBpbW1lZGlhdGU6IGZhbHNlIH0pO1xuICBmdW5jdGlvbiB1cGRhdGVDb250ZW50KCkge1xuICAgIGlmIChpc1N1cHBvcnRlZC52YWx1ZSkge1xuICAgICAgbmF2aWdhdG9yLmNsaXBib2FyZC5yZWFkKCkudGhlbigoaXRlbXMpID0+IHtcbiAgICAgICAgY29udGVudC52YWx1ZSA9IGl0ZW1zO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIGlmIChpc1N1cHBvcnRlZC52YWx1ZSAmJiByZWFkKSB7XG4gICAgdXNlRXZlbnRMaXN0ZW5lcihbXCJjb3B5XCIsIFwiY3V0XCJdLCB1cGRhdGVDb250ZW50LCB7IHBhc3NpdmU6IHRydWUgfSk7XG4gIH1cbiAgYXN5bmMgZnVuY3Rpb24gY29weSh2YWx1ZSA9IHRvVmFsdWUoc291cmNlKSkge1xuICAgIGlmIChpc1N1cHBvcnRlZC52YWx1ZSAmJiB2YWx1ZSAhPSBudWxsKSB7XG4gICAgICBhd2FpdCBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlKHZhbHVlKTtcbiAgICAgIGNvbnRlbnQudmFsdWUgPSB2YWx1ZTtcbiAgICAgIGNvcGllZC52YWx1ZSA9IHRydWU7XG4gICAgICB0aW1lb3V0LnN0YXJ0KCk7XG4gICAgfVxuICB9XG4gIHJldHVybiB7XG4gICAgaXNTdXBwb3J0ZWQsXG4gICAgY29udGVudDogc2hhbGxvd1JlYWRvbmx5KGNvbnRlbnQpLFxuICAgIGNvcGllZDogcmVhZG9ubHkoY29waWVkKSxcbiAgICBjb3B5LFxuICAgIHJlYWQ6IHVwZGF0ZUNvbnRlbnRcbiAgfTtcbn1cblxuZnVuY3Rpb24gY2xvbmVGbkpTT04oc291cmNlKSB7XG4gIHJldHVybiBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHNvdXJjZSkpO1xufVxuZnVuY3Rpb24gdXNlQ2xvbmVkKHNvdXJjZSwgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IGNsb25lZCA9IHJlZih7fSk7XG4gIGNvbnN0IGlzTW9kaWZpZWQgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgbGV0IF9sYXN0U3luYyA9IGZhbHNlO1xuICBjb25zdCB7XG4gICAgbWFudWFsLFxuICAgIGNsb25lID0gY2xvbmVGbkpTT04sXG4gICAgLy8gd2F0Y2ggb3B0aW9uc1xuICAgIGRlZXAgPSB0cnVlLFxuICAgIGltbWVkaWF0ZSA9IHRydWVcbiAgfSA9IG9wdGlvbnM7XG4gIHdhdGNoKGNsb25lZCwgKCkgPT4ge1xuICAgIGlmIChfbGFzdFN5bmMpIHtcbiAgICAgIF9sYXN0U3luYyA9IGZhbHNlO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpc01vZGlmaWVkLnZhbHVlID0gdHJ1ZTtcbiAgfSwge1xuICAgIGRlZXA6IHRydWUsXG4gICAgZmx1c2g6IFwic3luY1wiXG4gIH0pO1xuICBmdW5jdGlvbiBzeW5jKCkge1xuICAgIF9sYXN0U3luYyA9IHRydWU7XG4gICAgaXNNb2RpZmllZC52YWx1ZSA9IGZhbHNlO1xuICAgIGNsb25lZC52YWx1ZSA9IGNsb25lKHRvVmFsdWUoc291cmNlKSk7XG4gIH1cbiAgaWYgKCFtYW51YWwgJiYgKGlzUmVmKHNvdXJjZSkgfHwgdHlwZW9mIHNvdXJjZSA9PT0gXCJmdW5jdGlvblwiKSkge1xuICAgIHdhdGNoKHNvdXJjZSwgc3luYywge1xuICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIGRlZXAsXG4gICAgICBpbW1lZGlhdGVcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICBzeW5jKCk7XG4gIH1cbiAgcmV0dXJuIHsgY2xvbmVkLCBpc01vZGlmaWVkLCBzeW5jIH07XG59XG5cbmNvbnN0IF9nbG9iYWwgPSB0eXBlb2YgZ2xvYmFsVGhpcyAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbFRoaXMgOiB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiID8gd2luZG93IDogdHlwZW9mIGdsb2JhbCAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbCA6IHR5cGVvZiBzZWxmICE9PSBcInVuZGVmaW5lZFwiID8gc2VsZiA6IHt9O1xuY29uc3QgZ2xvYmFsS2V5ID0gXCJfX3Z1ZXVzZV9zc3JfaGFuZGxlcnNfX1wiO1xuY29uc3QgaGFuZGxlcnMgPSAvKiBAX19QVVJFX18gKi8gZ2V0SGFuZGxlcnMoKTtcbmZ1bmN0aW9uIGdldEhhbmRsZXJzKCkge1xuICBpZiAoIShnbG9iYWxLZXkgaW4gX2dsb2JhbCkpXG4gICAgX2dsb2JhbFtnbG9iYWxLZXldID0gX2dsb2JhbFtnbG9iYWxLZXldIHx8IHt9O1xuICByZXR1cm4gX2dsb2JhbFtnbG9iYWxLZXldO1xufVxuZnVuY3Rpb24gZ2V0U1NSSGFuZGxlcihrZXksIGZhbGxiYWNrKSB7XG4gIHJldHVybiBoYW5kbGVyc1trZXldIHx8IGZhbGxiYWNrO1xufVxuZnVuY3Rpb24gc2V0U1NSSGFuZGxlcihrZXksIGZuKSB7XG4gIGhhbmRsZXJzW2tleV0gPSBmbjtcbn1cblxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHVzZVByZWZlcnJlZERhcmsob3B0aW9ucykge1xuICByZXR1cm4gdXNlTWVkaWFRdWVyeShcIihwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaylcIiwgb3B0aW9ucyk7XG59XG5cbmZ1bmN0aW9uIGd1ZXNzU2VyaWFsaXplclR5cGUocmF3SW5pdCkge1xuICByZXR1cm4gcmF3SW5pdCA9PSBudWxsID8gXCJhbnlcIiA6IHJhd0luaXQgaW5zdGFuY2VvZiBTZXQgPyBcInNldFwiIDogcmF3SW5pdCBpbnN0YW5jZW9mIE1hcCA/IFwibWFwXCIgOiByYXdJbml0IGluc3RhbmNlb2YgRGF0ZSA/IFwiZGF0ZVwiIDogdHlwZW9mIHJhd0luaXQgPT09IFwiYm9vbGVhblwiID8gXCJib29sZWFuXCIgOiB0eXBlb2YgcmF3SW5pdCA9PT0gXCJzdHJpbmdcIiA/IFwic3RyaW5nXCIgOiB0eXBlb2YgcmF3SW5pdCA9PT0gXCJvYmplY3RcIiA/IFwib2JqZWN0XCIgOiAhTnVtYmVyLmlzTmFOKHJhd0luaXQpID8gXCJudW1iZXJcIiA6IFwiYW55XCI7XG59XG5cbmNvbnN0IFN0b3JhZ2VTZXJpYWxpemVycyA9IHtcbiAgYm9vbGVhbjoge1xuICAgIHJlYWQ6ICh2KSA9PiB2ID09PSBcInRydWVcIixcbiAgICB3cml0ZTogKHYpID0+IFN0cmluZyh2KVxuICB9LFxuICBvYmplY3Q6IHtcbiAgICByZWFkOiAodikgPT4gSlNPTi5wYXJzZSh2KSxcbiAgICB3cml0ZTogKHYpID0+IEpTT04uc3RyaW5naWZ5KHYpXG4gIH0sXG4gIG51bWJlcjoge1xuICAgIHJlYWQ6ICh2KSA9PiBOdW1iZXIucGFyc2VGbG9hdCh2KSxcbiAgICB3cml0ZTogKHYpID0+IFN0cmluZyh2KVxuICB9LFxuICBhbnk6IHtcbiAgICByZWFkOiAodikgPT4gdixcbiAgICB3cml0ZTogKHYpID0+IFN0cmluZyh2KVxuICB9LFxuICBzdHJpbmc6IHtcbiAgICByZWFkOiAodikgPT4gdixcbiAgICB3cml0ZTogKHYpID0+IFN0cmluZyh2KVxuICB9LFxuICBtYXA6IHtcbiAgICByZWFkOiAodikgPT4gbmV3IE1hcChKU09OLnBhcnNlKHYpKSxcbiAgICB3cml0ZTogKHYpID0+IEpTT04uc3RyaW5naWZ5KEFycmF5LmZyb20odi5lbnRyaWVzKCkpKVxuICB9LFxuICBzZXQ6IHtcbiAgICByZWFkOiAodikgPT4gbmV3IFNldChKU09OLnBhcnNlKHYpKSxcbiAgICB3cml0ZTogKHYpID0+IEpTT04uc3RyaW5naWZ5KEFycmF5LmZyb20odikpXG4gIH0sXG4gIGRhdGU6IHtcbiAgICByZWFkOiAodikgPT4gbmV3IERhdGUodiksXG4gICAgd3JpdGU6ICh2KSA9PiB2LnRvSVNPU3RyaW5nKClcbiAgfVxufTtcbmNvbnN0IGN1c3RvbVN0b3JhZ2VFdmVudE5hbWUgPSBcInZ1ZXVzZS1zdG9yYWdlXCI7XG5mdW5jdGlvbiB1c2VTdG9yYWdlKGtleSwgZGVmYXVsdHMsIHN0b3JhZ2UsIG9wdGlvbnMgPSB7fSkge1xuICB2YXIgX2E7XG4gIGNvbnN0IHtcbiAgICBmbHVzaCA9IFwicHJlXCIsXG4gICAgZGVlcCA9IHRydWUsXG4gICAgbGlzdGVuVG9TdG9yYWdlQ2hhbmdlcyA9IHRydWUsXG4gICAgd3JpdGVEZWZhdWx0cyA9IHRydWUsXG4gICAgbWVyZ2VEZWZhdWx0cyA9IGZhbHNlLFxuICAgIHNoYWxsb3csXG4gICAgd2luZG93ID0gZGVmYXVsdFdpbmRvdyxcbiAgICBldmVudEZpbHRlcixcbiAgICBvbkVycm9yID0gKGUpID0+IHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgfSxcbiAgICBpbml0T25Nb3VudGVkXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBkYXRhID0gKHNoYWxsb3cgPyBzaGFsbG93UmVmIDogcmVmKSh0eXBlb2YgZGVmYXVsdHMgPT09IFwiZnVuY3Rpb25cIiA/IGRlZmF1bHRzKCkgOiBkZWZhdWx0cyk7XG4gIGNvbnN0IGtleUNvbXB1dGVkID0gY29tcHV0ZWQoKCkgPT4gdG9WYWx1ZShrZXkpKTtcbiAgaWYgKCFzdG9yYWdlKSB7XG4gICAgdHJ5IHtcbiAgICAgIHN0b3JhZ2UgPSBnZXRTU1JIYW5kbGVyKFwiZ2V0RGVmYXVsdFN0b3JhZ2VcIiwgKCkgPT4ge1xuICAgICAgICB2YXIgX2EyO1xuICAgICAgICByZXR1cm4gKF9hMiA9IGRlZmF1bHRXaW5kb3cpID09IG51bGwgPyB2b2lkIDAgOiBfYTIubG9jYWxTdG9yYWdlO1xuICAgICAgfSkoKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBvbkVycm9yKGUpO1xuICAgIH1cbiAgfVxuICBpZiAoIXN0b3JhZ2UpXG4gICAgcmV0dXJuIGRhdGE7XG4gIGNvbnN0IHJhd0luaXQgPSB0b1ZhbHVlKGRlZmF1bHRzKTtcbiAgY29uc3QgdHlwZSA9IGd1ZXNzU2VyaWFsaXplclR5cGUocmF3SW5pdCk7XG4gIGNvbnN0IHNlcmlhbGl6ZXIgPSAoX2EgPSBvcHRpb25zLnNlcmlhbGl6ZXIpICE9IG51bGwgPyBfYSA6IFN0b3JhZ2VTZXJpYWxpemVyc1t0eXBlXTtcbiAgY29uc3QgeyBwYXVzZTogcGF1c2VXYXRjaCwgcmVzdW1lOiByZXN1bWVXYXRjaCB9ID0gcGF1c2FibGVXYXRjaChcbiAgICBkYXRhLFxuICAgIChuZXdWYWx1ZSkgPT4gd3JpdGUobmV3VmFsdWUpLFxuICAgIHsgZmx1c2gsIGRlZXAsIGV2ZW50RmlsdGVyIH1cbiAgKTtcbiAgd2F0Y2goa2V5Q29tcHV0ZWQsICgpID0+IHVwZGF0ZSgpLCB7IGZsdXNoIH0pO1xuICBsZXQgZmlyc3RNb3VudGVkID0gZmFsc2U7XG4gIGNvbnN0IG9uU3RvcmFnZUV2ZW50ID0gKGV2KSA9PiB7XG4gICAgaWYgKGluaXRPbk1vdW50ZWQgJiYgIWZpcnN0TW91bnRlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB1cGRhdGUoZXYpO1xuICB9O1xuICBjb25zdCBvblN0b3JhZ2VDdXN0b21FdmVudCA9IChldikgPT4ge1xuICAgIGlmIChpbml0T25Nb3VudGVkICYmICFmaXJzdE1vdW50ZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdXBkYXRlRnJvbUN1c3RvbUV2ZW50KGV2KTtcbiAgfTtcbiAgaWYgKHdpbmRvdyAmJiBsaXN0ZW5Ub1N0b3JhZ2VDaGFuZ2VzKSB7XG4gICAgaWYgKHN0b3JhZ2UgaW5zdGFuY2VvZiBTdG9yYWdlKVxuICAgICAgdXNlRXZlbnRMaXN0ZW5lcih3aW5kb3csIFwic3RvcmFnZVwiLCBvblN0b3JhZ2VFdmVudCwgeyBwYXNzaXZlOiB0cnVlIH0pO1xuICAgIGVsc2VcbiAgICAgIHVzZUV2ZW50TGlzdGVuZXIod2luZG93LCBjdXN0b21TdG9yYWdlRXZlbnROYW1lLCBvblN0b3JhZ2VDdXN0b21FdmVudCk7XG4gIH1cbiAgaWYgKGluaXRPbk1vdW50ZWQpIHtcbiAgICB0cnlPbk1vdW50ZWQoKCkgPT4ge1xuICAgICAgZmlyc3RNb3VudGVkID0gdHJ1ZTtcbiAgICAgIHVwZGF0ZSgpO1xuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIHVwZGF0ZSgpO1xuICB9XG4gIGZ1bmN0aW9uIGRpc3BhdGNoV3JpdGVFdmVudChvbGRWYWx1ZSwgbmV3VmFsdWUpIHtcbiAgICBpZiAod2luZG93KSB7XG4gICAgICBjb25zdCBwYXlsb2FkID0ge1xuICAgICAgICBrZXk6IGtleUNvbXB1dGVkLnZhbHVlLFxuICAgICAgICBvbGRWYWx1ZSxcbiAgICAgICAgbmV3VmFsdWUsXG4gICAgICAgIHN0b3JhZ2VBcmVhOiBzdG9yYWdlXG4gICAgICB9O1xuICAgICAgd2luZG93LmRpc3BhdGNoRXZlbnQoc3RvcmFnZSBpbnN0YW5jZW9mIFN0b3JhZ2UgPyBuZXcgU3RvcmFnZUV2ZW50KFwic3RvcmFnZVwiLCBwYXlsb2FkKSA6IG5ldyBDdXN0b21FdmVudChjdXN0b21TdG9yYWdlRXZlbnROYW1lLCB7XG4gICAgICAgIGRldGFpbDogcGF5bG9hZFxuICAgICAgfSkpO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiB3cml0ZSh2KSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IG9sZFZhbHVlID0gc3RvcmFnZS5nZXRJdGVtKGtleUNvbXB1dGVkLnZhbHVlKTtcbiAgICAgIGlmICh2ID09IG51bGwpIHtcbiAgICAgICAgZGlzcGF0Y2hXcml0ZUV2ZW50KG9sZFZhbHVlLCBudWxsKTtcbiAgICAgICAgc3RvcmFnZS5yZW1vdmVJdGVtKGtleUNvbXB1dGVkLnZhbHVlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHNlcmlhbGl6ZWQgPSBzZXJpYWxpemVyLndyaXRlKHYpO1xuICAgICAgICBpZiAob2xkVmFsdWUgIT09IHNlcmlhbGl6ZWQpIHtcbiAgICAgICAgICBzdG9yYWdlLnNldEl0ZW0oa2V5Q29tcHV0ZWQudmFsdWUsIHNlcmlhbGl6ZWQpO1xuICAgICAgICAgIGRpc3BhdGNoV3JpdGVFdmVudChvbGRWYWx1ZSwgc2VyaWFsaXplZCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBvbkVycm9yKGUpO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiByZWFkKGV2ZW50KSB7XG4gICAgY29uc3QgcmF3VmFsdWUgPSBldmVudCA/IGV2ZW50Lm5ld1ZhbHVlIDogc3RvcmFnZS5nZXRJdGVtKGtleUNvbXB1dGVkLnZhbHVlKTtcbiAgICBpZiAocmF3VmFsdWUgPT0gbnVsbCkge1xuICAgICAgaWYgKHdyaXRlRGVmYXVsdHMgJiYgcmF3SW5pdCAhPSBudWxsKVxuICAgICAgICBzdG9yYWdlLnNldEl0ZW0oa2V5Q29tcHV0ZWQudmFsdWUsIHNlcmlhbGl6ZXIud3JpdGUocmF3SW5pdCkpO1xuICAgICAgcmV0dXJuIHJhd0luaXQ7XG4gICAgfSBlbHNlIGlmICghZXZlbnQgJiYgbWVyZ2VEZWZhdWx0cykge1xuICAgICAgY29uc3QgdmFsdWUgPSBzZXJpYWxpemVyLnJlYWQocmF3VmFsdWUpO1xuICAgICAgaWYgKHR5cGVvZiBtZXJnZURlZmF1bHRzID09PSBcImZ1bmN0aW9uXCIpXG4gICAgICAgIHJldHVybiBtZXJnZURlZmF1bHRzKHZhbHVlLCByYXdJbml0KTtcbiAgICAgIGVsc2UgaWYgKHR5cGUgPT09IFwib2JqZWN0XCIgJiYgIUFycmF5LmlzQXJyYXkodmFsdWUpKVxuICAgICAgICByZXR1cm4geyAuLi5yYXdJbml0LCAuLi52YWx1ZSB9O1xuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHJhd1ZhbHVlICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICByZXR1cm4gcmF3VmFsdWU7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBzZXJpYWxpemVyLnJlYWQocmF3VmFsdWUpO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiB1cGRhdGUoZXZlbnQpIHtcbiAgICBpZiAoZXZlbnQgJiYgZXZlbnQuc3RvcmFnZUFyZWEgIT09IHN0b3JhZ2UpXG4gICAgICByZXR1cm47XG4gICAgaWYgKGV2ZW50ICYmIGV2ZW50LmtleSA9PSBudWxsKSB7XG4gICAgICBkYXRhLnZhbHVlID0gcmF3SW5pdDtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGV2ZW50ICYmIGV2ZW50LmtleSAhPT0ga2V5Q29tcHV0ZWQudmFsdWUpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcGF1c2VXYXRjaCgpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBzZXJpYWxpemVkRGF0YSA9IHNlcmlhbGl6ZXIud3JpdGUoZGF0YS52YWx1ZSk7XG4gICAgICBpZiAoZXZlbnQgPT09IHZvaWQgMCB8fCAoZXZlbnQgPT0gbnVsbCA/IHZvaWQgMCA6IGV2ZW50Lm5ld1ZhbHVlKSAhPT0gc2VyaWFsaXplZERhdGEpIHtcbiAgICAgICAgZGF0YS52YWx1ZSA9IHJlYWQoZXZlbnQpO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIG9uRXJyb3IoZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIGlmIChldmVudClcbiAgICAgICAgbmV4dFRpY2socmVzdW1lV2F0Y2gpO1xuICAgICAgZWxzZVxuICAgICAgICByZXN1bWVXYXRjaCgpO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiB1cGRhdGVGcm9tQ3VzdG9tRXZlbnQoZXZlbnQpIHtcbiAgICB1cGRhdGUoZXZlbnQuZGV0YWlsKTtcbiAgfVxuICByZXR1cm4gZGF0YTtcbn1cblxuY29uc3QgQ1NTX0RJU0FCTEVfVFJBTlMgPSBcIiosKjo6YmVmb3JlLCo6OmFmdGVyey13ZWJraXQtdHJhbnNpdGlvbjpub25lIWltcG9ydGFudDstbW96LXRyYW5zaXRpb246bm9uZSFpbXBvcnRhbnQ7LW8tdHJhbnNpdGlvbjpub25lIWltcG9ydGFudDstbXMtdHJhbnNpdGlvbjpub25lIWltcG9ydGFudDt0cmFuc2l0aW9uOm5vbmUhaW1wb3J0YW50fVwiO1xuZnVuY3Rpb24gdXNlQ29sb3JNb2RlKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgc2VsZWN0b3IgPSBcImh0bWxcIixcbiAgICBhdHRyaWJ1dGUgPSBcImNsYXNzXCIsXG4gICAgaW5pdGlhbFZhbHVlID0gXCJhdXRvXCIsXG4gICAgd2luZG93ID0gZGVmYXVsdFdpbmRvdyxcbiAgICBzdG9yYWdlLFxuICAgIHN0b3JhZ2VLZXkgPSBcInZ1ZXVzZS1jb2xvci1zY2hlbWVcIixcbiAgICBsaXN0ZW5Ub1N0b3JhZ2VDaGFuZ2VzID0gdHJ1ZSxcbiAgICBzdG9yYWdlUmVmLFxuICAgIGVtaXRBdXRvLFxuICAgIGRpc2FibGVUcmFuc2l0aW9uID0gdHJ1ZVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgbW9kZXMgPSB7XG4gICAgYXV0bzogXCJcIixcbiAgICBsaWdodDogXCJsaWdodFwiLFxuICAgIGRhcms6IFwiZGFya1wiLFxuICAgIC4uLm9wdGlvbnMubW9kZXMgfHwge31cbiAgfTtcbiAgY29uc3QgcHJlZmVycmVkRGFyayA9IHVzZVByZWZlcnJlZERhcmsoeyB3aW5kb3cgfSk7XG4gIGNvbnN0IHN5c3RlbSA9IGNvbXB1dGVkKCgpID0+IHByZWZlcnJlZERhcmsudmFsdWUgPyBcImRhcmtcIiA6IFwibGlnaHRcIik7XG4gIGNvbnN0IHN0b3JlID0gc3RvcmFnZVJlZiB8fCAoc3RvcmFnZUtleSA9PSBudWxsID8gdG9SZWYoaW5pdGlhbFZhbHVlKSA6IHVzZVN0b3JhZ2Uoc3RvcmFnZUtleSwgaW5pdGlhbFZhbHVlLCBzdG9yYWdlLCB7IHdpbmRvdywgbGlzdGVuVG9TdG9yYWdlQ2hhbmdlcyB9KSk7XG4gIGNvbnN0IHN0YXRlID0gY29tcHV0ZWQoKCkgPT4gc3RvcmUudmFsdWUgPT09IFwiYXV0b1wiID8gc3lzdGVtLnZhbHVlIDogc3RvcmUudmFsdWUpO1xuICBjb25zdCB1cGRhdGVIVE1MQXR0cnMgPSBnZXRTU1JIYW5kbGVyKFxuICAgIFwidXBkYXRlSFRNTEF0dHJzXCIsXG4gICAgKHNlbGVjdG9yMiwgYXR0cmlidXRlMiwgdmFsdWUpID0+IHtcbiAgICAgIGNvbnN0IGVsID0gdHlwZW9mIHNlbGVjdG9yMiA9PT0gXCJzdHJpbmdcIiA/IHdpbmRvdyA9PSBudWxsID8gdm9pZCAwIDogd2luZG93LmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3Ioc2VsZWN0b3IyKSA6IHVucmVmRWxlbWVudChzZWxlY3RvcjIpO1xuICAgICAgaWYgKCFlbClcbiAgICAgICAgcmV0dXJuO1xuICAgICAgY29uc3QgY2xhc3Nlc1RvQWRkID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgICAgIGNvbnN0IGNsYXNzZXNUb1JlbW92ZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gICAgICBsZXQgYXR0cmlidXRlVG9DaGFuZ2UgPSBudWxsO1xuICAgICAgaWYgKGF0dHJpYnV0ZTIgPT09IFwiY2xhc3NcIikge1xuICAgICAgICBjb25zdCBjdXJyZW50ID0gdmFsdWUuc3BsaXQoL1xccy9nKTtcbiAgICAgICAgT2JqZWN0LnZhbHVlcyhtb2RlcykuZmxhdE1hcCgoaSkgPT4gKGkgfHwgXCJcIikuc3BsaXQoL1xccy9nKSkuZmlsdGVyKEJvb2xlYW4pLmZvckVhY2goKHYpID0+IHtcbiAgICAgICAgICBpZiAoY3VycmVudC5pbmNsdWRlcyh2KSlcbiAgICAgICAgICAgIGNsYXNzZXNUb0FkZC5hZGQodik7XG4gICAgICAgICAgZWxzZVxuICAgICAgICAgICAgY2xhc3Nlc1RvUmVtb3ZlLmFkZCh2KTtcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhdHRyaWJ1dGVUb0NoYW5nZSA9IHsga2V5OiBhdHRyaWJ1dGUyLCB2YWx1ZSB9O1xuICAgICAgfVxuICAgICAgaWYgKGNsYXNzZXNUb0FkZC5zaXplID09PSAwICYmIGNsYXNzZXNUb1JlbW92ZS5zaXplID09PSAwICYmIGF0dHJpYnV0ZVRvQ2hhbmdlID09PSBudWxsKVxuICAgICAgICByZXR1cm47XG4gICAgICBsZXQgc3R5bGU7XG4gICAgICBpZiAoZGlzYWJsZVRyYW5zaXRpb24pIHtcbiAgICAgICAgc3R5bGUgPSB3aW5kb3cuZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInN0eWxlXCIpO1xuICAgICAgICBzdHlsZS5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShDU1NfRElTQUJMRV9UUkFOUykpO1xuICAgICAgICB3aW5kb3cuZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZChzdHlsZSk7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IGMgb2YgY2xhc3Nlc1RvQWRkKSB7XG4gICAgICAgIGVsLmNsYXNzTGlzdC5hZGQoYyk7XG4gICAgICB9XG4gICAgICBmb3IgKGNvbnN0IGMgb2YgY2xhc3Nlc1RvUmVtb3ZlKSB7XG4gICAgICAgIGVsLmNsYXNzTGlzdC5yZW1vdmUoYyk7XG4gICAgICB9XG4gICAgICBpZiAoYXR0cmlidXRlVG9DaGFuZ2UpIHtcbiAgICAgICAgZWwuc2V0QXR0cmlidXRlKGF0dHJpYnV0ZVRvQ2hhbmdlLmtleSwgYXR0cmlidXRlVG9DaGFuZ2UudmFsdWUpO1xuICAgICAgfVxuICAgICAgaWYgKGRpc2FibGVUcmFuc2l0aW9uKSB7XG4gICAgICAgIHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKHN0eWxlKS5vcGFjaXR5O1xuICAgICAgICBkb2N1bWVudC5oZWFkLnJlbW92ZUNoaWxkKHN0eWxlKTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG4gIGZ1bmN0aW9uIGRlZmF1bHRPbkNoYW5nZWQobW9kZSkge1xuICAgIHZhciBfYTtcbiAgICB1cGRhdGVIVE1MQXR0cnMoc2VsZWN0b3IsIGF0dHJpYnV0ZSwgKF9hID0gbW9kZXNbbW9kZV0pICE9IG51bGwgPyBfYSA6IG1vZGUpO1xuICB9XG4gIGZ1bmN0aW9uIG9uQ2hhbmdlZChtb2RlKSB7XG4gICAgaWYgKG9wdGlvbnMub25DaGFuZ2VkKVxuICAgICAgb3B0aW9ucy5vbkNoYW5nZWQobW9kZSwgZGVmYXVsdE9uQ2hhbmdlZCk7XG4gICAgZWxzZVxuICAgICAgZGVmYXVsdE9uQ2hhbmdlZChtb2RlKTtcbiAgfVxuICB3YXRjaChzdGF0ZSwgb25DaGFuZ2VkLCB7IGZsdXNoOiBcInBvc3RcIiwgaW1tZWRpYXRlOiB0cnVlIH0pO1xuICB0cnlPbk1vdW50ZWQoKCkgPT4gb25DaGFuZ2VkKHN0YXRlLnZhbHVlKSk7XG4gIGNvbnN0IGF1dG8gPSBjb21wdXRlZCh7XG4gICAgZ2V0KCkge1xuICAgICAgcmV0dXJuIGVtaXRBdXRvID8gc3RvcmUudmFsdWUgOiBzdGF0ZS52YWx1ZTtcbiAgICB9LFxuICAgIHNldCh2KSB7XG4gICAgICBzdG9yZS52YWx1ZSA9IHY7XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIE9iamVjdC5hc3NpZ24oYXV0bywgeyBzdG9yZSwgc3lzdGVtLCBzdGF0ZSB9KTtcbn1cblxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHVzZUNvbmZpcm1EaWFsb2cocmV2ZWFsZWQgPSBzaGFsbG93UmVmKGZhbHNlKSkge1xuICBjb25zdCBjb25maXJtSG9vayA9IGNyZWF0ZUV2ZW50SG9vaygpO1xuICBjb25zdCBjYW5jZWxIb29rID0gY3JlYXRlRXZlbnRIb29rKCk7XG4gIGNvbnN0IHJldmVhbEhvb2sgPSBjcmVhdGVFdmVudEhvb2soKTtcbiAgbGV0IF9yZXNvbHZlID0gbm9vcDtcbiAgY29uc3QgcmV2ZWFsID0gKGRhdGEpID0+IHtcbiAgICByZXZlYWxIb29rLnRyaWdnZXIoZGF0YSk7XG4gICAgcmV2ZWFsZWQudmFsdWUgPSB0cnVlO1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgX3Jlc29sdmUgPSByZXNvbHZlO1xuICAgIH0pO1xuICB9O1xuICBjb25zdCBjb25maXJtID0gKGRhdGEpID0+IHtcbiAgICByZXZlYWxlZC52YWx1ZSA9IGZhbHNlO1xuICAgIGNvbmZpcm1Ib29rLnRyaWdnZXIoZGF0YSk7XG4gICAgX3Jlc29sdmUoeyBkYXRhLCBpc0NhbmNlbGVkOiBmYWxzZSB9KTtcbiAgfTtcbiAgY29uc3QgY2FuY2VsID0gKGRhdGEpID0+IHtcbiAgICByZXZlYWxlZC52YWx1ZSA9IGZhbHNlO1xuICAgIGNhbmNlbEhvb2sudHJpZ2dlcihkYXRhKTtcbiAgICBfcmVzb2x2ZSh7IGRhdGEsIGlzQ2FuY2VsZWQ6IHRydWUgfSk7XG4gIH07XG4gIHJldHVybiB7XG4gICAgaXNSZXZlYWxlZDogY29tcHV0ZWQoKCkgPT4gcmV2ZWFsZWQudmFsdWUpLFxuICAgIHJldmVhbCxcbiAgICBjb25maXJtLFxuICAgIGNhbmNlbCxcbiAgICBvblJldmVhbDogcmV2ZWFsSG9vay5vbixcbiAgICBvbkNvbmZpcm06IGNvbmZpcm1Ib29rLm9uLFxuICAgIG9uQ2FuY2VsOiBjYW5jZWxIb29rLm9uXG4gIH07XG59XG5cbmZ1bmN0aW9uIHVzZUNvdW50ZG93bihpbml0aWFsQ291bnRkb3duLCBvcHRpb25zKSB7XG4gIHZhciBfYSwgX2I7XG4gIGNvbnN0IHJlbWFpbmluZyA9IHNoYWxsb3dSZWYodG9WYWx1ZShpbml0aWFsQ291bnRkb3duKSk7XG4gIGNvbnN0IGludGVydmFsQ29udHJvbGxlciA9IHVzZUludGVydmFsRm4oKCkgPT4ge1xuICAgIHZhciBfYTIsIF9iMjtcbiAgICBjb25zdCB2YWx1ZSA9IHJlbWFpbmluZy52YWx1ZSAtIDE7XG4gICAgcmVtYWluaW5nLnZhbHVlID0gdmFsdWUgPCAwID8gMCA6IHZhbHVlO1xuICAgIChfYTIgPSBvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLm9uVGljaykgPT0gbnVsbCA/IHZvaWQgMCA6IF9hMi5jYWxsKG9wdGlvbnMpO1xuICAgIGlmIChyZW1haW5pbmcudmFsdWUgPD0gMCkge1xuICAgICAgaW50ZXJ2YWxDb250cm9sbGVyLnBhdXNlKCk7XG4gICAgICAoX2IyID0gb3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy5vbkNvbXBsZXRlKSA9PSBudWxsID8gdm9pZCAwIDogX2IyLmNhbGwob3B0aW9ucyk7XG4gICAgfVxuICB9LCAoX2EgPSBvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLmludGVydmFsKSAhPSBudWxsID8gX2EgOiAxZTMsIHsgaW1tZWRpYXRlOiAoX2IgPSBvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLmltbWVkaWF0ZSkgIT0gbnVsbCA/IF9iIDogZmFsc2UgfSk7XG4gIGNvbnN0IHJlc2V0ID0gKGNvdW50ZG93bikgPT4ge1xuICAgIHZhciBfYTI7XG4gICAgcmVtYWluaW5nLnZhbHVlID0gKF9hMiA9IHRvVmFsdWUoY291bnRkb3duKSkgIT0gbnVsbCA/IF9hMiA6IHRvVmFsdWUoaW5pdGlhbENvdW50ZG93bik7XG4gIH07XG4gIGNvbnN0IHN0b3AgPSAoKSA9PiB7XG4gICAgaW50ZXJ2YWxDb250cm9sbGVyLnBhdXNlKCk7XG4gICAgcmVzZXQoKTtcbiAgfTtcbiAgY29uc3QgcmVzdW1lID0gKCkgPT4ge1xuICAgIGlmICghaW50ZXJ2YWxDb250cm9sbGVyLmlzQWN0aXZlLnZhbHVlKSB7XG4gICAgICBpZiAocmVtYWluaW5nLnZhbHVlID4gMCkge1xuICAgICAgICBpbnRlcnZhbENvbnRyb2xsZXIucmVzdW1lKCk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuICBjb25zdCBzdGFydCA9IChjb3VudGRvd24pID0+IHtcbiAgICByZXNldChjb3VudGRvd24pO1xuICAgIGludGVydmFsQ29udHJvbGxlci5yZXN1bWUoKTtcbiAgfTtcbiAgcmV0dXJuIHtcbiAgICByZW1haW5pbmcsXG4gICAgcmVzZXQsXG4gICAgc3RvcCxcbiAgICBzdGFydCxcbiAgICBwYXVzZTogaW50ZXJ2YWxDb250cm9sbGVyLnBhdXNlLFxuICAgIHJlc3VtZSxcbiAgICBpc0FjdGl2ZTogaW50ZXJ2YWxDb250cm9sbGVyLmlzQWN0aXZlXG4gIH07XG59XG5cbmZ1bmN0aW9uIHVzZUNzc1Zhcihwcm9wLCB0YXJnZXQsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7IHdpbmRvdyA9IGRlZmF1bHRXaW5kb3csIGluaXRpYWxWYWx1ZSwgb2JzZXJ2ZSA9IGZhbHNlIH0gPSBvcHRpb25zO1xuICBjb25zdCB2YXJpYWJsZSA9IHNoYWxsb3dSZWYoaW5pdGlhbFZhbHVlKTtcbiAgY29uc3QgZWxSZWYgPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgdmFyIF9hO1xuICAgIHJldHVybiB1bnJlZkVsZW1lbnQodGFyZ2V0KSB8fCAoKF9hID0gd2luZG93ID09IG51bGwgPyB2b2lkIDAgOiB3aW5kb3cuZG9jdW1lbnQpID09IG51bGwgPyB2b2lkIDAgOiBfYS5kb2N1bWVudEVsZW1lbnQpO1xuICB9KTtcbiAgZnVuY3Rpb24gdXBkYXRlQ3NzVmFyKCkge1xuICAgIHZhciBfYTtcbiAgICBjb25zdCBrZXkgPSB0b1ZhbHVlKHByb3ApO1xuICAgIGNvbnN0IGVsID0gdG9WYWx1ZShlbFJlZik7XG4gICAgaWYgKGVsICYmIHdpbmRvdyAmJiBrZXkpIHtcbiAgICAgIGNvbnN0IHZhbHVlID0gKF9hID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoZWwpLmdldFByb3BlcnR5VmFsdWUoa2V5KSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLnRyaW0oKTtcbiAgICAgIHZhcmlhYmxlLnZhbHVlID0gdmFsdWUgfHwgdmFyaWFibGUudmFsdWUgfHwgaW5pdGlhbFZhbHVlO1xuICAgIH1cbiAgfVxuICBpZiAob2JzZXJ2ZSkge1xuICAgIHVzZU11dGF0aW9uT2JzZXJ2ZXIoZWxSZWYsIHVwZGF0ZUNzc1Zhciwge1xuICAgICAgYXR0cmlidXRlRmlsdGVyOiBbXCJzdHlsZVwiLCBcImNsYXNzXCJdLFxuICAgICAgd2luZG93XG4gICAgfSk7XG4gIH1cbiAgd2F0Y2goXG4gICAgW2VsUmVmLCAoKSA9PiB0b1ZhbHVlKHByb3ApXSxcbiAgICAoXywgb2xkKSA9PiB7XG4gICAgICBpZiAob2xkWzBdICYmIG9sZFsxXSlcbiAgICAgICAgb2xkWzBdLnN0eWxlLnJlbW92ZVByb3BlcnR5KG9sZFsxXSk7XG4gICAgICB1cGRhdGVDc3NWYXIoKTtcbiAgICB9LFxuICAgIHsgaW1tZWRpYXRlOiB0cnVlIH1cbiAgKTtcbiAgd2F0Y2goXG4gICAgW3ZhcmlhYmxlLCBlbFJlZl0sXG4gICAgKFt2YWwsIGVsXSkgPT4ge1xuICAgICAgY29uc3QgcmF3X3Byb3AgPSB0b1ZhbHVlKHByb3ApO1xuICAgICAgaWYgKChlbCA9PSBudWxsID8gdm9pZCAwIDogZWwuc3R5bGUpICYmIHJhd19wcm9wKSB7XG4gICAgICAgIGlmICh2YWwgPT0gbnVsbClcbiAgICAgICAgICBlbC5zdHlsZS5yZW1vdmVQcm9wZXJ0eShyYXdfcHJvcCk7XG4gICAgICAgIGVsc2VcbiAgICAgICAgICBlbC5zdHlsZS5zZXRQcm9wZXJ0eShyYXdfcHJvcCwgdmFsKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIHsgaW1tZWRpYXRlOiB0cnVlIH1cbiAgKTtcbiAgcmV0dXJuIHZhcmlhYmxlO1xufVxuXG5mdW5jdGlvbiB1c2VDdXJyZW50RWxlbWVudChyb290Q29tcG9uZW50KSB7XG4gIGNvbnN0IHZtID0gZ2V0Q3VycmVudEluc3RhbmNlKCk7XG4gIGNvbnN0IGN1cnJlbnRFbGVtZW50ID0gY29tcHV0ZWRXaXRoQ29udHJvbChcbiAgICAoKSA9PiBudWxsLFxuICAgICgpID0+IHJvb3RDb21wb25lbnQgPyB1bnJlZkVsZW1lbnQocm9vdENvbXBvbmVudCkgOiB2bS5wcm94eS4kZWxcbiAgKTtcbiAgb25VcGRhdGVkKGN1cnJlbnRFbGVtZW50LnRyaWdnZXIpO1xuICBvbk1vdW50ZWQoY3VycmVudEVsZW1lbnQudHJpZ2dlcik7XG4gIHJldHVybiBjdXJyZW50RWxlbWVudDtcbn1cblxuZnVuY3Rpb24gdXNlQ3ljbGVMaXN0KGxpc3QsIG9wdGlvbnMpIHtcbiAgY29uc3Qgc3RhdGUgPSBzaGFsbG93UmVmKGdldEluaXRpYWxWYWx1ZSgpKTtcbiAgY29uc3QgbGlzdFJlZiA9IHRvUmVmKGxpc3QpO1xuICBjb25zdCBpbmRleCA9IGNvbXB1dGVkKHtcbiAgICBnZXQoKSB7XG4gICAgICB2YXIgX2E7XG4gICAgICBjb25zdCB0YXJnZXRMaXN0ID0gbGlzdFJlZi52YWx1ZTtcbiAgICAgIGxldCBpbmRleDIgPSAob3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy5nZXRJbmRleE9mKSA/IG9wdGlvbnMuZ2V0SW5kZXhPZihzdGF0ZS52YWx1ZSwgdGFyZ2V0TGlzdCkgOiB0YXJnZXRMaXN0LmluZGV4T2Yoc3RhdGUudmFsdWUpO1xuICAgICAgaWYgKGluZGV4MiA8IDApXG4gICAgICAgIGluZGV4MiA9IChfYSA9IG9wdGlvbnMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdGlvbnMuZmFsbGJhY2tJbmRleCkgIT0gbnVsbCA/IF9hIDogMDtcbiAgICAgIHJldHVybiBpbmRleDI7XG4gICAgfSxcbiAgICBzZXQodikge1xuICAgICAgc2V0KHYpO1xuICAgIH1cbiAgfSk7XG4gIGZ1bmN0aW9uIHNldChpKSB7XG4gICAgY29uc3QgdGFyZ2V0TGlzdCA9IGxpc3RSZWYudmFsdWU7XG4gICAgY29uc3QgbGVuZ3RoID0gdGFyZ2V0TGlzdC5sZW5ndGg7XG4gICAgY29uc3QgaW5kZXgyID0gKGkgJSBsZW5ndGggKyBsZW5ndGgpICUgbGVuZ3RoO1xuICAgIGNvbnN0IHZhbHVlID0gdGFyZ2V0TGlzdFtpbmRleDJdO1xuICAgIHN0YXRlLnZhbHVlID0gdmFsdWU7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG4gIGZ1bmN0aW9uIHNoaWZ0KGRlbHRhID0gMSkge1xuICAgIHJldHVybiBzZXQoaW5kZXgudmFsdWUgKyBkZWx0YSk7XG4gIH1cbiAgZnVuY3Rpb24gbmV4dChuID0gMSkge1xuICAgIHJldHVybiBzaGlmdChuKTtcbiAgfVxuICBmdW5jdGlvbiBwcmV2KG4gPSAxKSB7XG4gICAgcmV0dXJuIHNoaWZ0KC1uKTtcbiAgfVxuICBmdW5jdGlvbiBnZXRJbml0aWFsVmFsdWUoKSB7XG4gICAgdmFyIF9hLCBfYjtcbiAgICByZXR1cm4gKF9iID0gdG9WYWx1ZSgoX2EgPSBvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLmluaXRpYWxWYWx1ZSkgIT0gbnVsbCA/IF9hIDogdG9WYWx1ZShsaXN0KVswXSkpICE9IG51bGwgPyBfYiA6IHZvaWQgMDtcbiAgfVxuICB3YXRjaChsaXN0UmVmLCAoKSA9PiBzZXQoaW5kZXgudmFsdWUpKTtcbiAgcmV0dXJuIHtcbiAgICBzdGF0ZSxcbiAgICBpbmRleCxcbiAgICBuZXh0LFxuICAgIHByZXYsXG4gICAgZ286IHNldFxuICB9O1xufVxuXG5mdW5jdGlvbiB1c2VEYXJrKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgdmFsdWVEYXJrID0gXCJkYXJrXCIsXG4gICAgdmFsdWVMaWdodCA9IFwiXCJcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IG1vZGUgPSB1c2VDb2xvck1vZGUoe1xuICAgIC4uLm9wdGlvbnMsXG4gICAgb25DaGFuZ2VkOiAobW9kZTIsIGRlZmF1bHRIYW5kbGVyKSA9PiB7XG4gICAgICB2YXIgX2E7XG4gICAgICBpZiAob3B0aW9ucy5vbkNoYW5nZWQpXG4gICAgICAgIChfYSA9IG9wdGlvbnMub25DaGFuZ2VkKSA9PSBudWxsID8gdm9pZCAwIDogX2EuY2FsbChvcHRpb25zLCBtb2RlMiA9PT0gXCJkYXJrXCIsIGRlZmF1bHRIYW5kbGVyLCBtb2RlMik7XG4gICAgICBlbHNlXG4gICAgICAgIGRlZmF1bHRIYW5kbGVyKG1vZGUyKTtcbiAgICB9LFxuICAgIG1vZGVzOiB7XG4gICAgICBkYXJrOiB2YWx1ZURhcmssXG4gICAgICBsaWdodDogdmFsdWVMaWdodFxuICAgIH1cbiAgfSk7XG4gIGNvbnN0IHN5c3RlbSA9IGNvbXB1dGVkKCgpID0+IG1vZGUuc3lzdGVtLnZhbHVlKTtcbiAgY29uc3QgaXNEYXJrID0gY29tcHV0ZWQoe1xuICAgIGdldCgpIHtcbiAgICAgIHJldHVybiBtb2RlLnZhbHVlID09PSBcImRhcmtcIjtcbiAgICB9LFxuICAgIHNldCh2KSB7XG4gICAgICBjb25zdCBtb2RlVmFsID0gdiA/IFwiZGFya1wiIDogXCJsaWdodFwiO1xuICAgICAgaWYgKHN5c3RlbS52YWx1ZSA9PT0gbW9kZVZhbClcbiAgICAgICAgbW9kZS52YWx1ZSA9IFwiYXV0b1wiO1xuICAgICAgZWxzZVxuICAgICAgICBtb2RlLnZhbHVlID0gbW9kZVZhbDtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gaXNEYXJrO1xufVxuXG5mdW5jdGlvbiBmbkJ5cGFzcyh2KSB7XG4gIHJldHVybiB2O1xufVxuZnVuY3Rpb24gZm5TZXRTb3VyY2Uoc291cmNlLCB2YWx1ZSkge1xuICByZXR1cm4gc291cmNlLnZhbHVlID0gdmFsdWU7XG59XG5mdW5jdGlvbiBkZWZhdWx0RHVtcChjbG9uZSkge1xuICByZXR1cm4gY2xvbmUgPyB0eXBlb2YgY2xvbmUgPT09IFwiZnVuY3Rpb25cIiA/IGNsb25lIDogY2xvbmVGbkpTT04gOiBmbkJ5cGFzcztcbn1cbmZ1bmN0aW9uIGRlZmF1bHRQYXJzZShjbG9uZSkge1xuICByZXR1cm4gY2xvbmUgPyB0eXBlb2YgY2xvbmUgPT09IFwiZnVuY3Rpb25cIiA/IGNsb25lIDogY2xvbmVGbkpTT04gOiBmbkJ5cGFzcztcbn1cbmZ1bmN0aW9uIHVzZU1hbnVhbFJlZkhpc3Rvcnkoc291cmNlLCBvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGNsb25lID0gZmFsc2UsXG4gICAgZHVtcCA9IGRlZmF1bHREdW1wKGNsb25lKSxcbiAgICBwYXJzZSA9IGRlZmF1bHRQYXJzZShjbG9uZSksXG4gICAgc2V0U291cmNlID0gZm5TZXRTb3VyY2VcbiAgfSA9IG9wdGlvbnM7XG4gIGZ1bmN0aW9uIF9jcmVhdGVIaXN0b3J5UmVjb3JkKCkge1xuICAgIHJldHVybiBtYXJrUmF3KHtcbiAgICAgIHNuYXBzaG90OiBkdW1wKHNvdXJjZS52YWx1ZSksXG4gICAgICB0aW1lc3RhbXA6IHRpbWVzdGFtcCgpXG4gICAgfSk7XG4gIH1cbiAgY29uc3QgbGFzdCA9IHJlZihfY3JlYXRlSGlzdG9yeVJlY29yZCgpKTtcbiAgY29uc3QgdW5kb1N0YWNrID0gcmVmKFtdKTtcbiAgY29uc3QgcmVkb1N0YWNrID0gcmVmKFtdKTtcbiAgY29uc3QgX3NldFNvdXJjZSA9IChyZWNvcmQpID0+IHtcbiAgICBzZXRTb3VyY2Uoc291cmNlLCBwYXJzZShyZWNvcmQuc25hcHNob3QpKTtcbiAgICBsYXN0LnZhbHVlID0gcmVjb3JkO1xuICB9O1xuICBjb25zdCBjb21taXQgPSAoKSA9PiB7XG4gICAgdW5kb1N0YWNrLnZhbHVlLnVuc2hpZnQobGFzdC52YWx1ZSk7XG4gICAgbGFzdC52YWx1ZSA9IF9jcmVhdGVIaXN0b3J5UmVjb3JkKCk7XG4gICAgaWYgKG9wdGlvbnMuY2FwYWNpdHkgJiYgdW5kb1N0YWNrLnZhbHVlLmxlbmd0aCA+IG9wdGlvbnMuY2FwYWNpdHkpXG4gICAgICB1bmRvU3RhY2sudmFsdWUuc3BsaWNlKG9wdGlvbnMuY2FwYWNpdHksIE51bWJlci5QT1NJVElWRV9JTkZJTklUWSk7XG4gICAgaWYgKHJlZG9TdGFjay52YWx1ZS5sZW5ndGgpXG4gICAgICByZWRvU3RhY2sudmFsdWUuc3BsaWNlKDAsIHJlZG9TdGFjay52YWx1ZS5sZW5ndGgpO1xuICB9O1xuICBjb25zdCBjbGVhciA9ICgpID0+IHtcbiAgICB1bmRvU3RhY2sudmFsdWUuc3BsaWNlKDAsIHVuZG9TdGFjay52YWx1ZS5sZW5ndGgpO1xuICAgIHJlZG9TdGFjay52YWx1ZS5zcGxpY2UoMCwgcmVkb1N0YWNrLnZhbHVlLmxlbmd0aCk7XG4gIH07XG4gIGNvbnN0IHVuZG8gPSAoKSA9PiB7XG4gICAgY29uc3Qgc3RhdGUgPSB1bmRvU3RhY2sudmFsdWUuc2hpZnQoKTtcbiAgICBpZiAoc3RhdGUpIHtcbiAgICAgIHJlZG9TdGFjay52YWx1ZS51bnNoaWZ0KGxhc3QudmFsdWUpO1xuICAgICAgX3NldFNvdXJjZShzdGF0ZSk7XG4gICAgfVxuICB9O1xuICBjb25zdCByZWRvID0gKCkgPT4ge1xuICAgIGNvbnN0IHN0YXRlID0gcmVkb1N0YWNrLnZhbHVlLnNoaWZ0KCk7XG4gICAgaWYgKHN0YXRlKSB7XG4gICAgICB1bmRvU3RhY2sudmFsdWUudW5zaGlmdChsYXN0LnZhbHVlKTtcbiAgICAgIF9zZXRTb3VyY2Uoc3RhdGUpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgcmVzZXQgPSAoKSA9PiB7XG4gICAgX3NldFNvdXJjZShsYXN0LnZhbHVlKTtcbiAgfTtcbiAgY29uc3QgaGlzdG9yeSA9IGNvbXB1dGVkKCgpID0+IFtsYXN0LnZhbHVlLCAuLi51bmRvU3RhY2sudmFsdWVdKTtcbiAgY29uc3QgY2FuVW5kbyA9IGNvbXB1dGVkKCgpID0+IHVuZG9TdGFjay52YWx1ZS5sZW5ndGggPiAwKTtcbiAgY29uc3QgY2FuUmVkbyA9IGNvbXB1dGVkKCgpID0+IHJlZG9TdGFjay52YWx1ZS5sZW5ndGggPiAwKTtcbiAgcmV0dXJuIHtcbiAgICBzb3VyY2UsXG4gICAgdW5kb1N0YWNrLFxuICAgIHJlZG9TdGFjayxcbiAgICBsYXN0LFxuICAgIGhpc3RvcnksXG4gICAgY2FuVW5kbyxcbiAgICBjYW5SZWRvLFxuICAgIGNsZWFyLFxuICAgIGNvbW1pdCxcbiAgICByZXNldCxcbiAgICB1bmRvLFxuICAgIHJlZG9cbiAgfTtcbn1cblxuZnVuY3Rpb24gdXNlUmVmSGlzdG9yeShzb3VyY2UsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgZGVlcCA9IGZhbHNlLFxuICAgIGZsdXNoID0gXCJwcmVcIixcbiAgICBldmVudEZpbHRlcixcbiAgICBzaG91bGRDb21taXQgPSAoKSA9PiB0cnVlXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCB7XG4gICAgZXZlbnRGaWx0ZXI6IGNvbXBvc2VkRmlsdGVyLFxuICAgIHBhdXNlLFxuICAgIHJlc3VtZTogcmVzdW1lVHJhY2tpbmcsXG4gICAgaXNBY3RpdmU6IGlzVHJhY2tpbmdcbiAgfSA9IHBhdXNhYmxlRmlsdGVyKGV2ZW50RmlsdGVyKTtcbiAgbGV0IGxhc3RSYXdWYWx1ZSA9IHNvdXJjZS52YWx1ZTtcbiAgY29uc3Qge1xuICAgIGlnbm9yZVVwZGF0ZXMsXG4gICAgaWdub3JlUHJldkFzeW5jVXBkYXRlcyxcbiAgICBzdG9wXG4gIH0gPSB3YXRjaElnbm9yYWJsZShcbiAgICBzb3VyY2UsXG4gICAgY29tbWl0LFxuICAgIHsgZGVlcCwgZmx1c2gsIGV2ZW50RmlsdGVyOiBjb21wb3NlZEZpbHRlciB9XG4gICk7XG4gIGZ1bmN0aW9uIHNldFNvdXJjZShzb3VyY2UyLCB2YWx1ZSkge1xuICAgIGlnbm9yZVByZXZBc3luY1VwZGF0ZXMoKTtcbiAgICBpZ25vcmVVcGRhdGVzKCgpID0+IHtcbiAgICAgIHNvdXJjZTIudmFsdWUgPSB2YWx1ZTtcbiAgICAgIGxhc3RSYXdWYWx1ZSA9IHZhbHVlO1xuICAgIH0pO1xuICB9XG4gIGNvbnN0IG1hbnVhbEhpc3RvcnkgPSB1c2VNYW51YWxSZWZIaXN0b3J5KHNvdXJjZSwgeyAuLi5vcHRpb25zLCBjbG9uZTogb3B0aW9ucy5jbG9uZSB8fCBkZWVwLCBzZXRTb3VyY2UgfSk7XG4gIGNvbnN0IHsgY2xlYXIsIGNvbW1pdDogbWFudWFsQ29tbWl0IH0gPSBtYW51YWxIaXN0b3J5O1xuICBmdW5jdGlvbiBjb21taXQoKSB7XG4gICAgaWdub3JlUHJldkFzeW5jVXBkYXRlcygpO1xuICAgIGlmICghc2hvdWxkQ29tbWl0KGxhc3RSYXdWYWx1ZSwgc291cmNlLnZhbHVlKSlcbiAgICAgIHJldHVybjtcbiAgICBsYXN0UmF3VmFsdWUgPSBzb3VyY2UudmFsdWU7XG4gICAgbWFudWFsQ29tbWl0KCk7XG4gIH1cbiAgZnVuY3Rpb24gcmVzdW1lKGNvbW1pdE5vdykge1xuICAgIHJlc3VtZVRyYWNraW5nKCk7XG4gICAgaWYgKGNvbW1pdE5vdylcbiAgICAgIGNvbW1pdCgpO1xuICB9XG4gIGZ1bmN0aW9uIGJhdGNoKGZuKSB7XG4gICAgbGV0IGNhbmNlbGVkID0gZmFsc2U7XG4gICAgY29uc3QgY2FuY2VsID0gKCkgPT4gY2FuY2VsZWQgPSB0cnVlO1xuICAgIGlnbm9yZVVwZGF0ZXMoKCkgPT4ge1xuICAgICAgZm4oY2FuY2VsKTtcbiAgICB9KTtcbiAgICBpZiAoIWNhbmNlbGVkKVxuICAgICAgY29tbWl0KCk7XG4gIH1cbiAgZnVuY3Rpb24gZGlzcG9zZSgpIHtcbiAgICBzdG9wKCk7XG4gICAgY2xlYXIoKTtcbiAgfVxuICByZXR1cm4ge1xuICAgIC4uLm1hbnVhbEhpc3RvcnksXG4gICAgaXNUcmFja2luZyxcbiAgICBwYXVzZSxcbiAgICByZXN1bWUsXG4gICAgY29tbWl0LFxuICAgIGJhdGNoLFxuICAgIGRpc3Bvc2VcbiAgfTtcbn1cblxuZnVuY3Rpb24gdXNlRGVib3VuY2VkUmVmSGlzdG9yeShzb3VyY2UsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCBmaWx0ZXIgPSBvcHRpb25zLmRlYm91bmNlID8gZGVib3VuY2VGaWx0ZXIob3B0aW9ucy5kZWJvdW5jZSkgOiB2b2lkIDA7XG4gIGNvbnN0IGhpc3RvcnkgPSB1c2VSZWZIaXN0b3J5KHNvdXJjZSwgeyAuLi5vcHRpb25zLCBldmVudEZpbHRlcjogZmlsdGVyIH0pO1xuICByZXR1cm4ge1xuICAgIC4uLmhpc3RvcnlcbiAgfTtcbn1cblxuZnVuY3Rpb24gdXNlRGV2aWNlTW90aW9uKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgd2luZG93ID0gZGVmYXVsdFdpbmRvdyxcbiAgICByZXF1ZXN0UGVybWlzc2lvbnMgPSBmYWxzZSxcbiAgICBldmVudEZpbHRlciA9IGJ5cGFzc0ZpbHRlclxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgaXNTdXBwb3J0ZWQgPSB1c2VTdXBwb3J0ZWQoKCkgPT4gdHlwZW9mIERldmljZU1vdGlvbkV2ZW50ICE9PSBcInVuZGVmaW5lZFwiKTtcbiAgY29uc3QgcmVxdWlyZVBlcm1pc3Npb25zID0gdXNlU3VwcG9ydGVkKCgpID0+IGlzU3VwcG9ydGVkLnZhbHVlICYmIFwicmVxdWVzdFBlcm1pc3Npb25cIiBpbiBEZXZpY2VNb3Rpb25FdmVudCAmJiB0eXBlb2YgRGV2aWNlTW90aW9uRXZlbnQucmVxdWVzdFBlcm1pc3Npb24gPT09IFwiZnVuY3Rpb25cIik7XG4gIGNvbnN0IHBlcm1pc3Npb25HcmFudGVkID0gc2hhbGxvd1JlZihmYWxzZSk7XG4gIGNvbnN0IGFjY2VsZXJhdGlvbiA9IHJlZih7IHg6IG51bGwsIHk6IG51bGwsIHo6IG51bGwgfSk7XG4gIGNvbnN0IHJvdGF0aW9uUmF0ZSA9IHJlZih7IGFscGhhOiBudWxsLCBiZXRhOiBudWxsLCBnYW1tYTogbnVsbCB9KTtcbiAgY29uc3QgaW50ZXJ2YWwgPSBzaGFsbG93UmVmKDApO1xuICBjb25zdCBhY2NlbGVyYXRpb25JbmNsdWRpbmdHcmF2aXR5ID0gcmVmKHtcbiAgICB4OiBudWxsLFxuICAgIHk6IG51bGwsXG4gICAgejogbnVsbFxuICB9KTtcbiAgZnVuY3Rpb24gaW5pdCgpIHtcbiAgICBpZiAod2luZG93KSB7XG4gICAgICBjb25zdCBvbkRldmljZU1vdGlvbiA9IGNyZWF0ZUZpbHRlcldyYXBwZXIoXG4gICAgICAgIGV2ZW50RmlsdGVyLFxuICAgICAgICAoZXZlbnQpID0+IHtcbiAgICAgICAgICB2YXIgX2EsIF9iLCBfYywgX2QsIF9lLCBfZiwgX2csIF9oLCBfaTtcbiAgICAgICAgICBhY2NlbGVyYXRpb24udmFsdWUgPSB7XG4gICAgICAgICAgICB4OiAoKF9hID0gZXZlbnQuYWNjZWxlcmF0aW9uKSA9PSBudWxsID8gdm9pZCAwIDogX2EueCkgfHwgbnVsbCxcbiAgICAgICAgICAgIHk6ICgoX2IgPSBldmVudC5hY2NlbGVyYXRpb24pID09IG51bGwgPyB2b2lkIDAgOiBfYi55KSB8fCBudWxsLFxuICAgICAgICAgICAgejogKChfYyA9IGV2ZW50LmFjY2VsZXJhdGlvbikgPT0gbnVsbCA/IHZvaWQgMCA6IF9jLnopIHx8IG51bGxcbiAgICAgICAgICB9O1xuICAgICAgICAgIGFjY2VsZXJhdGlvbkluY2x1ZGluZ0dyYXZpdHkudmFsdWUgPSB7XG4gICAgICAgICAgICB4OiAoKF9kID0gZXZlbnQuYWNjZWxlcmF0aW9uSW5jbHVkaW5nR3Jhdml0eSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9kLngpIHx8IG51bGwsXG4gICAgICAgICAgICB5OiAoKF9lID0gZXZlbnQuYWNjZWxlcmF0aW9uSW5jbHVkaW5nR3Jhdml0eSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9lLnkpIHx8IG51bGwsXG4gICAgICAgICAgICB6OiAoKF9mID0gZXZlbnQuYWNjZWxlcmF0aW9uSW5jbHVkaW5nR3Jhdml0eSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9mLnopIHx8IG51bGxcbiAgICAgICAgICB9O1xuICAgICAgICAgIHJvdGF0aW9uUmF0ZS52YWx1ZSA9IHtcbiAgICAgICAgICAgIGFscGhhOiAoKF9nID0gZXZlbnQucm90YXRpb25SYXRlKSA9PSBudWxsID8gdm9pZCAwIDogX2cuYWxwaGEpIHx8IG51bGwsXG4gICAgICAgICAgICBiZXRhOiAoKF9oID0gZXZlbnQucm90YXRpb25SYXRlKSA9PSBudWxsID8gdm9pZCAwIDogX2guYmV0YSkgfHwgbnVsbCxcbiAgICAgICAgICAgIGdhbW1hOiAoKF9pID0gZXZlbnQucm90YXRpb25SYXRlKSA9PSBudWxsID8gdm9pZCAwIDogX2kuZ2FtbWEpIHx8IG51bGxcbiAgICAgICAgICB9O1xuICAgICAgICAgIGludGVydmFsLnZhbHVlID0gZXZlbnQuaW50ZXJ2YWw7XG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgICB1c2VFdmVudExpc3RlbmVyKHdpbmRvdywgXCJkZXZpY2Vtb3Rpb25cIiwgb25EZXZpY2VNb3Rpb24sIHsgcGFzc2l2ZTogdHJ1ZSB9KTtcbiAgICB9XG4gIH1cbiAgY29uc3QgZW5zdXJlUGVybWlzc2lvbnMgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFyZXF1aXJlUGVybWlzc2lvbnMudmFsdWUpXG4gICAgICBwZXJtaXNzaW9uR3JhbnRlZC52YWx1ZSA9IHRydWU7XG4gICAgaWYgKHBlcm1pc3Npb25HcmFudGVkLnZhbHVlKVxuICAgICAgcmV0dXJuO1xuICAgIGlmIChyZXF1aXJlUGVybWlzc2lvbnMudmFsdWUpIHtcbiAgICAgIGNvbnN0IHJlcXVlc3RQZXJtaXNzaW9uID0gRGV2aWNlTW90aW9uRXZlbnQucmVxdWVzdFBlcm1pc3Npb247XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHJlcXVlc3RQZXJtaXNzaW9uKCk7XG4gICAgICAgIGlmIChyZXNwb25zZSA9PT0gXCJncmFudGVkXCIpIHtcbiAgICAgICAgICBwZXJtaXNzaW9uR3JhbnRlZC52YWx1ZSA9IHRydWU7XG4gICAgICAgICAgaW5pdCgpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIGlmIChpc1N1cHBvcnRlZC52YWx1ZSkge1xuICAgIGlmIChyZXF1ZXN0UGVybWlzc2lvbnMgJiYgcmVxdWlyZVBlcm1pc3Npb25zLnZhbHVlKSB7XG4gICAgICBlbnN1cmVQZXJtaXNzaW9ucygpLnRoZW4oKCkgPT4gaW5pdCgpKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaW5pdCgpO1xuICAgIH1cbiAgfVxuICByZXR1cm4ge1xuICAgIGFjY2VsZXJhdGlvbixcbiAgICBhY2NlbGVyYXRpb25JbmNsdWRpbmdHcmF2aXR5LFxuICAgIHJvdGF0aW9uUmF0ZSxcbiAgICBpbnRlcnZhbCxcbiAgICBpc1N1cHBvcnRlZCxcbiAgICByZXF1aXJlUGVybWlzc2lvbnMsXG4gICAgZW5zdXJlUGVybWlzc2lvbnMsXG4gICAgcGVybWlzc2lvbkdyYW50ZWRcbiAgfTtcbn1cblxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHVzZURldmljZU9yaWVudGF0aW9uKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7IHdpbmRvdyA9IGRlZmF1bHRXaW5kb3cgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGlzU3VwcG9ydGVkID0gdXNlU3VwcG9ydGVkKCgpID0+IHdpbmRvdyAmJiBcIkRldmljZU9yaWVudGF0aW9uRXZlbnRcIiBpbiB3aW5kb3cpO1xuICBjb25zdCBpc0Fic29sdXRlID0gc2hhbGxvd1JlZihmYWxzZSk7XG4gIGNvbnN0IGFscGhhID0gc2hhbGxvd1JlZihudWxsKTtcbiAgY29uc3QgYmV0YSA9IHNoYWxsb3dSZWYobnVsbCk7XG4gIGNvbnN0IGdhbW1hID0gc2hhbGxvd1JlZihudWxsKTtcbiAgaWYgKHdpbmRvdyAmJiBpc1N1cHBvcnRlZC52YWx1ZSkge1xuICAgIHVzZUV2ZW50TGlzdGVuZXIod2luZG93LCBcImRldmljZW9yaWVudGF0aW9uXCIsIChldmVudCkgPT4ge1xuICAgICAgaXNBYnNvbHV0ZS52YWx1ZSA9IGV2ZW50LmFic29sdXRlO1xuICAgICAgYWxwaGEudmFsdWUgPSBldmVudC5hbHBoYTtcbiAgICAgIGJldGEudmFsdWUgPSBldmVudC5iZXRhO1xuICAgICAgZ2FtbWEudmFsdWUgPSBldmVudC5nYW1tYTtcbiAgICB9LCB7IHBhc3NpdmU6IHRydWUgfSk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBpc1N1cHBvcnRlZCxcbiAgICBpc0Fic29sdXRlLFxuICAgIGFscGhhLFxuICAgIGJldGEsXG4gICAgZ2FtbWFcbiAgfTtcbn1cblxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHVzZURldmljZVBpeGVsUmF0aW8ob3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICB3aW5kb3cgPSBkZWZhdWx0V2luZG93XG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBwaXhlbFJhdGlvID0gc2hhbGxvd1JlZigxKTtcbiAgY29uc3QgcXVlcnkgPSB1c2VNZWRpYVF1ZXJ5KCgpID0+IGAocmVzb2x1dGlvbjogJHtwaXhlbFJhdGlvLnZhbHVlfWRwcHgpYCwgb3B0aW9ucyk7XG4gIGxldCBzdG9wID0gbm9vcDtcbiAgaWYgKHdpbmRvdykge1xuICAgIHN0b3AgPSB3YXRjaEltbWVkaWF0ZShxdWVyeSwgKCkgPT4gcGl4ZWxSYXRpby52YWx1ZSA9IHdpbmRvdy5kZXZpY2VQaXhlbFJhdGlvKTtcbiAgfVxuICByZXR1cm4ge1xuICAgIHBpeGVsUmF0aW86IHJlYWRvbmx5KHBpeGVsUmF0aW8pLFxuICAgIHN0b3BcbiAgfTtcbn1cblxuZnVuY3Rpb24gdXNlRGV2aWNlc0xpc3Qob3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBuYXZpZ2F0b3IgPSBkZWZhdWx0TmF2aWdhdG9yLFxuICAgIHJlcXVlc3RQZXJtaXNzaW9ucyA9IGZhbHNlLFxuICAgIGNvbnN0cmFpbnRzID0geyBhdWRpbzogdHJ1ZSwgdmlkZW86IHRydWUgfSxcbiAgICBvblVwZGF0ZWRcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGRldmljZXMgPSByZWYoW10pO1xuICBjb25zdCB2aWRlb0lucHV0cyA9IGNvbXB1dGVkKCgpID0+IGRldmljZXMudmFsdWUuZmlsdGVyKChpKSA9PiBpLmtpbmQgPT09IFwidmlkZW9pbnB1dFwiKSk7XG4gIGNvbnN0IGF1ZGlvSW5wdXRzID0gY29tcHV0ZWQoKCkgPT4gZGV2aWNlcy52YWx1ZS5maWx0ZXIoKGkpID0+IGkua2luZCA9PT0gXCJhdWRpb2lucHV0XCIpKTtcbiAgY29uc3QgYXVkaW9PdXRwdXRzID0gY29tcHV0ZWQoKCkgPT4gZGV2aWNlcy52YWx1ZS5maWx0ZXIoKGkpID0+IGkua2luZCA9PT0gXCJhdWRpb291dHB1dFwiKSk7XG4gIGNvbnN0IGlzU3VwcG9ydGVkID0gdXNlU3VwcG9ydGVkKCgpID0+IG5hdmlnYXRvciAmJiBuYXZpZ2F0b3IubWVkaWFEZXZpY2VzICYmIG5hdmlnYXRvci5tZWRpYURldmljZXMuZW51bWVyYXRlRGV2aWNlcyk7XG4gIGNvbnN0IHBlcm1pc3Npb25HcmFudGVkID0gc2hhbGxvd1JlZihmYWxzZSk7XG4gIGxldCBzdHJlYW07XG4gIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZSgpIHtcbiAgICBpZiAoIWlzU3VwcG9ydGVkLnZhbHVlKVxuICAgICAgcmV0dXJuO1xuICAgIGRldmljZXMudmFsdWUgPSBhd2FpdCBuYXZpZ2F0b3IubWVkaWFEZXZpY2VzLmVudW1lcmF0ZURldmljZXMoKTtcbiAgICBvblVwZGF0ZWQgPT0gbnVsbCA/IHZvaWQgMCA6IG9uVXBkYXRlZChkZXZpY2VzLnZhbHVlKTtcbiAgICBpZiAoc3RyZWFtKSB7XG4gICAgICBzdHJlYW0uZ2V0VHJhY2tzKCkuZm9yRWFjaCgodCkgPT4gdC5zdG9wKCkpO1xuICAgICAgc3RyZWFtID0gbnVsbDtcbiAgICB9XG4gIH1cbiAgYXN5bmMgZnVuY3Rpb24gZW5zdXJlUGVybWlzc2lvbnMoKSB7XG4gICAgY29uc3QgZGV2aWNlTmFtZSA9IGNvbnN0cmFpbnRzLnZpZGVvID8gXCJjYW1lcmFcIiA6IFwibWljcm9waG9uZVwiO1xuICAgIGlmICghaXNTdXBwb3J0ZWQudmFsdWUpXG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgaWYgKHBlcm1pc3Npb25HcmFudGVkLnZhbHVlKVxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgY29uc3QgeyBzdGF0ZSwgcXVlcnkgfSA9IHVzZVBlcm1pc3Npb24oZGV2aWNlTmFtZSwgeyBjb250cm9sczogdHJ1ZSB9KTtcbiAgICBhd2FpdCBxdWVyeSgpO1xuICAgIGlmIChzdGF0ZS52YWx1ZSAhPT0gXCJncmFudGVkXCIpIHtcbiAgICAgIGxldCBncmFudGVkID0gdHJ1ZTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGFsbERldmljZXMgPSBhd2FpdCBuYXZpZ2F0b3IubWVkaWFEZXZpY2VzLmVudW1lcmF0ZURldmljZXMoKTtcbiAgICAgICAgY29uc3QgaGFzQ2FtZXJhID0gYWxsRGV2aWNlcy5zb21lKChkZXZpY2UpID0+IGRldmljZS5raW5kID09PSBcInZpZGVvaW5wdXRcIik7XG4gICAgICAgIGNvbnN0IGhhc01pY3JvcGhvbmUgPSBhbGxEZXZpY2VzLnNvbWUoKGRldmljZSkgPT4gZGV2aWNlLmtpbmQgPT09IFwiYXVkaW9pbnB1dFwiIHx8IGRldmljZS5raW5kID09PSBcImF1ZGlvb3V0cHV0XCIpO1xuICAgICAgICBjb25zdHJhaW50cy52aWRlbyA9IGhhc0NhbWVyYSA/IGNvbnN0cmFpbnRzLnZpZGVvIDogZmFsc2U7XG4gICAgICAgIGNvbnN0cmFpbnRzLmF1ZGlvID0gaGFzTWljcm9waG9uZSA/IGNvbnN0cmFpbnRzLmF1ZGlvIDogZmFsc2U7XG4gICAgICAgIHN0cmVhbSA9IGF3YWl0IG5hdmlnYXRvci5tZWRpYURldmljZXMuZ2V0VXNlck1lZGlhKGNvbnN0cmFpbnRzKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgc3RyZWFtID0gbnVsbDtcbiAgICAgICAgZ3JhbnRlZCA9IGZhbHNlO1xuICAgICAgfVxuICAgICAgdXBkYXRlKCk7XG4gICAgICBwZXJtaXNzaW9uR3JhbnRlZC52YWx1ZSA9IGdyYW50ZWQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIHBlcm1pc3Npb25HcmFudGVkLnZhbHVlID0gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIHBlcm1pc3Npb25HcmFudGVkLnZhbHVlO1xuICB9XG4gIGlmIChpc1N1cHBvcnRlZC52YWx1ZSkge1xuICAgIGlmIChyZXF1ZXN0UGVybWlzc2lvbnMpXG4gICAgICBlbnN1cmVQZXJtaXNzaW9ucygpO1xuICAgIHVzZUV2ZW50TGlzdGVuZXIobmF2aWdhdG9yLm1lZGlhRGV2aWNlcywgXCJkZXZpY2VjaGFuZ2VcIiwgdXBkYXRlLCB7IHBhc3NpdmU6IHRydWUgfSk7XG4gICAgdXBkYXRlKCk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBkZXZpY2VzLFxuICAgIGVuc3VyZVBlcm1pc3Npb25zLFxuICAgIHBlcm1pc3Npb25HcmFudGVkLFxuICAgIHZpZGVvSW5wdXRzLFxuICAgIGF1ZGlvSW5wdXRzLFxuICAgIGF1ZGlvT3V0cHV0cyxcbiAgICBpc1N1cHBvcnRlZFxuICB9O1xufVxuXG5mdW5jdGlvbiB1c2VEaXNwbGF5TWVkaWEob3B0aW9ucyA9IHt9KSB7XG4gIHZhciBfYTtcbiAgY29uc3QgZW5hYmxlZCA9IHNoYWxsb3dSZWYoKF9hID0gb3B0aW9ucy5lbmFibGVkKSAhPSBudWxsID8gX2EgOiBmYWxzZSk7XG4gIGNvbnN0IHZpZGVvID0gb3B0aW9ucy52aWRlbztcbiAgY29uc3QgYXVkaW8gPSBvcHRpb25zLmF1ZGlvO1xuICBjb25zdCB7IG5hdmlnYXRvciA9IGRlZmF1bHROYXZpZ2F0b3IgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGlzU3VwcG9ydGVkID0gdXNlU3VwcG9ydGVkKCgpID0+IHtcbiAgICB2YXIgX2EyO1xuICAgIHJldHVybiAoX2EyID0gbmF2aWdhdG9yID09IG51bGwgPyB2b2lkIDAgOiBuYXZpZ2F0b3IubWVkaWFEZXZpY2VzKSA9PSBudWxsID8gdm9pZCAwIDogX2EyLmdldERpc3BsYXlNZWRpYTtcbiAgfSk7XG4gIGNvbnN0IGNvbnN0cmFpbnQgPSB7IGF1ZGlvLCB2aWRlbyB9O1xuICBjb25zdCBzdHJlYW0gPSBzaGFsbG93UmVmKCk7XG4gIGFzeW5jIGZ1bmN0aW9uIF9zdGFydCgpIHtcbiAgICB2YXIgX2EyO1xuICAgIGlmICghaXNTdXBwb3J0ZWQudmFsdWUgfHwgc3RyZWFtLnZhbHVlKVxuICAgICAgcmV0dXJuO1xuICAgIHN0cmVhbS52YWx1ZSA9IGF3YWl0IG5hdmlnYXRvci5tZWRpYURldmljZXMuZ2V0RGlzcGxheU1lZGlhKGNvbnN0cmFpbnQpO1xuICAgIChfYTIgPSBzdHJlYW0udmFsdWUpID09IG51bGwgPyB2b2lkIDAgOiBfYTIuZ2V0VHJhY2tzKCkuZm9yRWFjaCgodCkgPT4gdXNlRXZlbnRMaXN0ZW5lcih0LCBcImVuZGVkXCIsIHN0b3AsIHsgcGFzc2l2ZTogdHJ1ZSB9KSk7XG4gICAgcmV0dXJuIHN0cmVhbS52YWx1ZTtcbiAgfVxuICBhc3luYyBmdW5jdGlvbiBfc3RvcCgpIHtcbiAgICB2YXIgX2EyO1xuICAgIChfYTIgPSBzdHJlYW0udmFsdWUpID09IG51bGwgPyB2b2lkIDAgOiBfYTIuZ2V0VHJhY2tzKCkuZm9yRWFjaCgodCkgPT4gdC5zdG9wKCkpO1xuICAgIHN0cmVhbS52YWx1ZSA9IHZvaWQgMDtcbiAgfVxuICBmdW5jdGlvbiBzdG9wKCkge1xuICAgIF9zdG9wKCk7XG4gICAgZW5hYmxlZC52YWx1ZSA9IGZhbHNlO1xuICB9XG4gIGFzeW5jIGZ1bmN0aW9uIHN0YXJ0KCkge1xuICAgIGF3YWl0IF9zdGFydCgpO1xuICAgIGlmIChzdHJlYW0udmFsdWUpXG4gICAgICBlbmFibGVkLnZhbHVlID0gdHJ1ZTtcbiAgICByZXR1cm4gc3RyZWFtLnZhbHVlO1xuICB9XG4gIHdhdGNoKFxuICAgIGVuYWJsZWQsXG4gICAgKHYpID0+IHtcbiAgICAgIGlmICh2KVxuICAgICAgICBfc3RhcnQoKTtcbiAgICAgIGVsc2VcbiAgICAgICAgX3N0b3AoKTtcbiAgICB9LFxuICAgIHsgaW1tZWRpYXRlOiB0cnVlIH1cbiAgKTtcbiAgcmV0dXJuIHtcbiAgICBpc1N1cHBvcnRlZCxcbiAgICBzdHJlYW0sXG4gICAgc3RhcnQsXG4gICAgc3RvcCxcbiAgICBlbmFibGVkXG4gIH07XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VEb2N1bWVudFZpc2liaWxpdHkob3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHsgZG9jdW1lbnQgPSBkZWZhdWx0RG9jdW1lbnQgfSA9IG9wdGlvbnM7XG4gIGlmICghZG9jdW1lbnQpXG4gICAgcmV0dXJuIHNoYWxsb3dSZWYoXCJ2aXNpYmxlXCIpO1xuICBjb25zdCB2aXNpYmlsaXR5ID0gc2hhbGxvd1JlZihkb2N1bWVudC52aXNpYmlsaXR5U3RhdGUpO1xuICB1c2VFdmVudExpc3RlbmVyKGRvY3VtZW50LCBcInZpc2liaWxpdHljaGFuZ2VcIiwgKCkgPT4ge1xuICAgIHZpc2liaWxpdHkudmFsdWUgPSBkb2N1bWVudC52aXNpYmlsaXR5U3RhdGU7XG4gIH0sIHsgcGFzc2l2ZTogdHJ1ZSB9KTtcbiAgcmV0dXJuIHZpc2liaWxpdHk7XG59XG5cbmZ1bmN0aW9uIHVzZURyYWdnYWJsZSh0YXJnZXQsIG9wdGlvbnMgPSB7fSkge1xuICB2YXIgX2E7XG4gIGNvbnN0IHtcbiAgICBwb2ludGVyVHlwZXMsXG4gICAgcHJldmVudERlZmF1bHQsXG4gICAgc3RvcFByb3BhZ2F0aW9uLFxuICAgIGV4YWN0LFxuICAgIG9uTW92ZSxcbiAgICBvbkVuZCxcbiAgICBvblN0YXJ0LFxuICAgIGluaXRpYWxWYWx1ZSxcbiAgICBheGlzID0gXCJib3RoXCIsXG4gICAgZHJhZ2dpbmdFbGVtZW50ID0gZGVmYXVsdFdpbmRvdyxcbiAgICBjb250YWluZXJFbGVtZW50LFxuICAgIGhhbmRsZTogZHJhZ2dpbmdIYW5kbGUgPSB0YXJnZXQsXG4gICAgYnV0dG9ucyA9IFswXVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgcG9zaXRpb24gPSByZWYoXG4gICAgKF9hID0gdG9WYWx1ZShpbml0aWFsVmFsdWUpKSAhPSBudWxsID8gX2EgOiB7IHg6IDAsIHk6IDAgfVxuICApO1xuICBjb25zdCBwcmVzc2VkRGVsdGEgPSByZWYoKTtcbiAgY29uc3QgZmlsdGVyRXZlbnQgPSAoZSkgPT4ge1xuICAgIGlmIChwb2ludGVyVHlwZXMpXG4gICAgICByZXR1cm4gcG9pbnRlclR5cGVzLmluY2x1ZGVzKGUucG9pbnRlclR5cGUpO1xuICAgIHJldHVybiB0cnVlO1xuICB9O1xuICBjb25zdCBoYW5kbGVFdmVudCA9IChlKSA9PiB7XG4gICAgaWYgKHRvVmFsdWUocHJldmVudERlZmF1bHQpKVxuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmICh0b1ZhbHVlKHN0b3BQcm9wYWdhdGlvbikpXG4gICAgICBlLnN0b3BQcm9wYWdhdGlvbigpO1xuICB9O1xuICBjb25zdCBzdGFydCA9IChlKSA9PiB7XG4gICAgdmFyIF9hMjtcbiAgICBpZiAoIXRvVmFsdWUoYnV0dG9ucykuaW5jbHVkZXMoZS5idXR0b24pKVxuICAgICAgcmV0dXJuO1xuICAgIGlmICh0b1ZhbHVlKG9wdGlvbnMuZGlzYWJsZWQpIHx8ICFmaWx0ZXJFdmVudChlKSlcbiAgICAgIHJldHVybjtcbiAgICBpZiAodG9WYWx1ZShleGFjdCkgJiYgZS50YXJnZXQgIT09IHRvVmFsdWUodGFyZ2V0KSlcbiAgICAgIHJldHVybjtcbiAgICBjb25zdCBjb250YWluZXIgPSB0b1ZhbHVlKGNvbnRhaW5lckVsZW1lbnQpO1xuICAgIGNvbnN0IGNvbnRhaW5lclJlY3QgPSAoX2EyID0gY29udGFpbmVyID09IG51bGwgPyB2b2lkIDAgOiBjb250YWluZXIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KSA9PSBudWxsID8gdm9pZCAwIDogX2EyLmNhbGwoY29udGFpbmVyKTtcbiAgICBjb25zdCB0YXJnZXRSZWN0ID0gdG9WYWx1ZSh0YXJnZXQpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGNvbnN0IHBvcyA9IHtcbiAgICAgIHg6IGUuY2xpZW50WCAtIChjb250YWluZXIgPyB0YXJnZXRSZWN0LmxlZnQgLSBjb250YWluZXJSZWN0LmxlZnQgKyBjb250YWluZXIuc2Nyb2xsTGVmdCA6IHRhcmdldFJlY3QubGVmdCksXG4gICAgICB5OiBlLmNsaWVudFkgLSAoY29udGFpbmVyID8gdGFyZ2V0UmVjdC50b3AgLSBjb250YWluZXJSZWN0LnRvcCArIGNvbnRhaW5lci5zY3JvbGxUb3AgOiB0YXJnZXRSZWN0LnRvcClcbiAgICB9O1xuICAgIGlmICgob25TdGFydCA9PSBudWxsID8gdm9pZCAwIDogb25TdGFydChwb3MsIGUpKSA9PT0gZmFsc2UpXG4gICAgICByZXR1cm47XG4gICAgcHJlc3NlZERlbHRhLnZhbHVlID0gcG9zO1xuICAgIGhhbmRsZUV2ZW50KGUpO1xuICB9O1xuICBjb25zdCBtb3ZlID0gKGUpID0+IHtcbiAgICBpZiAodG9WYWx1ZShvcHRpb25zLmRpc2FibGVkKSB8fCAhZmlsdGVyRXZlbnQoZSkpXG4gICAgICByZXR1cm47XG4gICAgaWYgKCFwcmVzc2VkRGVsdGEudmFsdWUpXG4gICAgICByZXR1cm47XG4gICAgY29uc3QgY29udGFpbmVyID0gdG9WYWx1ZShjb250YWluZXJFbGVtZW50KTtcbiAgICBjb25zdCB0YXJnZXRSZWN0ID0gdG9WYWx1ZSh0YXJnZXQpLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGxldCB7IHgsIHkgfSA9IHBvc2l0aW9uLnZhbHVlO1xuICAgIGlmIChheGlzID09PSBcInhcIiB8fCBheGlzID09PSBcImJvdGhcIikge1xuICAgICAgeCA9IGUuY2xpZW50WCAtIHByZXNzZWREZWx0YS52YWx1ZS54O1xuICAgICAgaWYgKGNvbnRhaW5lcilcbiAgICAgICAgeCA9IE1hdGgubWluKE1hdGgubWF4KDAsIHgpLCBjb250YWluZXIuc2Nyb2xsV2lkdGggLSB0YXJnZXRSZWN0LndpZHRoKTtcbiAgICB9XG4gICAgaWYgKGF4aXMgPT09IFwieVwiIHx8IGF4aXMgPT09IFwiYm90aFwiKSB7XG4gICAgICB5ID0gZS5jbGllbnRZIC0gcHJlc3NlZERlbHRhLnZhbHVlLnk7XG4gICAgICBpZiAoY29udGFpbmVyKVxuICAgICAgICB5ID0gTWF0aC5taW4oTWF0aC5tYXgoMCwgeSksIGNvbnRhaW5lci5zY3JvbGxIZWlnaHQgLSB0YXJnZXRSZWN0LmhlaWdodCk7XG4gICAgfVxuICAgIHBvc2l0aW9uLnZhbHVlID0ge1xuICAgICAgeCxcbiAgICAgIHlcbiAgICB9O1xuICAgIG9uTW92ZSA9PSBudWxsID8gdm9pZCAwIDogb25Nb3ZlKHBvc2l0aW9uLnZhbHVlLCBlKTtcbiAgICBoYW5kbGVFdmVudChlKTtcbiAgfTtcbiAgY29uc3QgZW5kID0gKGUpID0+IHtcbiAgICBpZiAodG9WYWx1ZShvcHRpb25zLmRpc2FibGVkKSB8fCAhZmlsdGVyRXZlbnQoZSkpXG4gICAgICByZXR1cm47XG4gICAgaWYgKCFwcmVzc2VkRGVsdGEudmFsdWUpXG4gICAgICByZXR1cm47XG4gICAgcHJlc3NlZERlbHRhLnZhbHVlID0gdm9pZCAwO1xuICAgIG9uRW5kID09IG51bGwgPyB2b2lkIDAgOiBvbkVuZChwb3NpdGlvbi52YWx1ZSwgZSk7XG4gICAgaGFuZGxlRXZlbnQoZSk7XG4gIH07XG4gIGlmIChpc0NsaWVudCkge1xuICAgIGNvbnN0IGNvbmZpZyA9ICgpID0+IHtcbiAgICAgIHZhciBfYTI7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBjYXB0dXJlOiAoX2EyID0gb3B0aW9ucy5jYXB0dXJlKSAhPSBudWxsID8gX2EyIDogdHJ1ZSxcbiAgICAgICAgcGFzc2l2ZTogIXRvVmFsdWUocHJldmVudERlZmF1bHQpXG4gICAgICB9O1xuICAgIH07XG4gICAgdXNlRXZlbnRMaXN0ZW5lcihkcmFnZ2luZ0hhbmRsZSwgXCJwb2ludGVyZG93blwiLCBzdGFydCwgY29uZmlnKTtcbiAgICB1c2VFdmVudExpc3RlbmVyKGRyYWdnaW5nRWxlbWVudCwgXCJwb2ludGVybW92ZVwiLCBtb3ZlLCBjb25maWcpO1xuICAgIHVzZUV2ZW50TGlzdGVuZXIoZHJhZ2dpbmdFbGVtZW50LCBcInBvaW50ZXJ1cFwiLCBlbmQsIGNvbmZpZyk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICAuLi50b1JlZnMocG9zaXRpb24pLFxuICAgIHBvc2l0aW9uLFxuICAgIGlzRHJhZ2dpbmc6IGNvbXB1dGVkKCgpID0+ICEhcHJlc3NlZERlbHRhLnZhbHVlKSxcbiAgICBzdHlsZTogY29tcHV0ZWQoXG4gICAgICAoKSA9PiBgbGVmdDoke3Bvc2l0aW9uLnZhbHVlLnh9cHg7dG9wOiR7cG9zaXRpb24udmFsdWUueX1weDtgXG4gICAgKVxuICB9O1xufVxuXG5mdW5jdGlvbiB1c2VEcm9wWm9uZSh0YXJnZXQsIG9wdGlvbnMgPSB7fSkge1xuICB2YXIgX2EsIF9iO1xuICBjb25zdCBpc092ZXJEcm9wWm9uZSA9IHNoYWxsb3dSZWYoZmFsc2UpO1xuICBjb25zdCBmaWxlcyA9IHNoYWxsb3dSZWYobnVsbCk7XG4gIGxldCBjb3VudGVyID0gMDtcbiAgbGV0IGlzVmFsaWQgPSB0cnVlO1xuICBpZiAoaXNDbGllbnQpIHtcbiAgICBjb25zdCBfb3B0aW9ucyA9IHR5cGVvZiBvcHRpb25zID09PSBcImZ1bmN0aW9uXCIgPyB7IG9uRHJvcDogb3B0aW9ucyB9IDogb3B0aW9ucztcbiAgICBjb25zdCBtdWx0aXBsZSA9IChfYSA9IF9vcHRpb25zLm11bHRpcGxlKSAhPSBudWxsID8gX2EgOiB0cnVlO1xuICAgIGNvbnN0IHByZXZlbnREZWZhdWx0Rm9yVW5oYW5kbGVkID0gKF9iID0gX29wdGlvbnMucHJldmVudERlZmF1bHRGb3JVbmhhbmRsZWQpICE9IG51bGwgPyBfYiA6IGZhbHNlO1xuICAgIGNvbnN0IGdldEZpbGVzID0gKGV2ZW50KSA9PiB7XG4gICAgICB2YXIgX2EyLCBfYjI7XG4gICAgICBjb25zdCBsaXN0ID0gQXJyYXkuZnJvbSgoX2IyID0gKF9hMiA9IGV2ZW50LmRhdGFUcmFuc2ZlcikgPT0gbnVsbCA/IHZvaWQgMCA6IF9hMi5maWxlcykgIT0gbnVsbCA/IF9iMiA6IFtdKTtcbiAgICAgIHJldHVybiBsaXN0Lmxlbmd0aCA9PT0gMCA/IG51bGwgOiBtdWx0aXBsZSA/IGxpc3QgOiBbbGlzdFswXV07XG4gICAgfTtcbiAgICBjb25zdCBjaGVja0RhdGFUeXBlcyA9ICh0eXBlcykgPT4ge1xuICAgICAgY29uc3QgZGF0YVR5cGVzID0gdW5yZWYoX29wdGlvbnMuZGF0YVR5cGVzKTtcbiAgICAgIGlmICh0eXBlb2YgZGF0YVR5cGVzID09PSBcImZ1bmN0aW9uXCIpXG4gICAgICAgIHJldHVybiBkYXRhVHlwZXModHlwZXMpO1xuICAgICAgaWYgKCEoZGF0YVR5cGVzID09IG51bGwgPyB2b2lkIDAgOiBkYXRhVHlwZXMubGVuZ3RoKSlcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICBpZiAodHlwZXMubGVuZ3RoID09PSAwKVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICByZXR1cm4gdHlwZXMuZXZlcnkoXG4gICAgICAgICh0eXBlKSA9PiBkYXRhVHlwZXMuc29tZSgoYWxsb3dlZFR5cGUpID0+IHR5cGUuaW5jbHVkZXMoYWxsb3dlZFR5cGUpKVxuICAgICAgKTtcbiAgICB9O1xuICAgIGNvbnN0IGNoZWNrVmFsaWRpdHkgPSAoaXRlbXMpID0+IHtcbiAgICAgIGNvbnN0IHR5cGVzID0gQXJyYXkuZnJvbShpdGVtcyAhPSBudWxsID8gaXRlbXMgOiBbXSkubWFwKChpdGVtKSA9PiBpdGVtLnR5cGUpO1xuICAgICAgY29uc3QgZGF0YVR5cGVzVmFsaWQgPSBjaGVja0RhdGFUeXBlcyh0eXBlcyk7XG4gICAgICBjb25zdCBtdWx0aXBsZUZpbGVzVmFsaWQgPSBtdWx0aXBsZSB8fCBpdGVtcy5sZW5ndGggPD0gMTtcbiAgICAgIHJldHVybiBkYXRhVHlwZXNWYWxpZCAmJiBtdWx0aXBsZUZpbGVzVmFsaWQ7XG4gICAgfTtcbiAgICBjb25zdCBpc1NhZmFyaSA9ICgpID0+IC9eKD86KD8hY2hyb21lfGFuZHJvaWQpLikqc2FmYXJpL2kudGVzdChuYXZpZ2F0b3IudXNlckFnZW50KSAmJiAhKFwiY2hyb21lXCIgaW4gd2luZG93KTtcbiAgICBjb25zdCBoYW5kbGVEcmFnRXZlbnQgPSAoZXZlbnQsIGV2ZW50VHlwZSkgPT4ge1xuICAgICAgdmFyIF9hMiwgX2IyLCBfYywgX2QsIF9lLCBfZjtcbiAgICAgIGNvbnN0IGRhdGFUcmFuc2Zlckl0ZW1MaXN0ID0gKF9hMiA9IGV2ZW50LmRhdGFUcmFuc2ZlcikgPT0gbnVsbCA/IHZvaWQgMCA6IF9hMi5pdGVtcztcbiAgICAgIGlzVmFsaWQgPSAoX2IyID0gZGF0YVRyYW5zZmVySXRlbUxpc3QgJiYgY2hlY2tWYWxpZGl0eShkYXRhVHJhbnNmZXJJdGVtTGlzdCkpICE9IG51bGwgPyBfYjIgOiBmYWxzZTtcbiAgICAgIGlmIChwcmV2ZW50RGVmYXVsdEZvclVuaGFuZGxlZCkge1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgfVxuICAgICAgaWYgKCFpc1NhZmFyaSgpICYmICFpc1ZhbGlkKSB7XG4gICAgICAgIGlmIChldmVudC5kYXRhVHJhbnNmZXIpIHtcbiAgICAgICAgICBldmVudC5kYXRhVHJhbnNmZXIuZHJvcEVmZmVjdCA9IFwibm9uZVwiO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICBpZiAoZXZlbnQuZGF0YVRyYW5zZmVyKSB7XG4gICAgICAgIGV2ZW50LmRhdGFUcmFuc2Zlci5kcm9wRWZmZWN0ID0gXCJjb3B5XCI7XG4gICAgICB9XG4gICAgICBjb25zdCBjdXJyZW50RmlsZXMgPSBnZXRGaWxlcyhldmVudCk7XG4gICAgICBzd2l0Y2ggKGV2ZW50VHlwZSkge1xuICAgICAgICBjYXNlIFwiZW50ZXJcIjpcbiAgICAgICAgICBjb3VudGVyICs9IDE7XG4gICAgICAgICAgaXNPdmVyRHJvcFpvbmUudmFsdWUgPSB0cnVlO1xuICAgICAgICAgIChfYyA9IF9vcHRpb25zLm9uRW50ZXIpID09IG51bGwgPyB2b2lkIDAgOiBfYy5jYWxsKF9vcHRpb25zLCBudWxsLCBldmVudCk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJvdmVyXCI6XG4gICAgICAgICAgKF9kID0gX29wdGlvbnMub25PdmVyKSA9PSBudWxsID8gdm9pZCAwIDogX2QuY2FsbChfb3B0aW9ucywgbnVsbCwgZXZlbnQpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwibGVhdmVcIjpcbiAgICAgICAgICBjb3VudGVyIC09IDE7XG4gICAgICAgICAgaWYgKGNvdW50ZXIgPT09IDApXG4gICAgICAgICAgICBpc092ZXJEcm9wWm9uZS52YWx1ZSA9IGZhbHNlO1xuICAgICAgICAgIChfZSA9IF9vcHRpb25zLm9uTGVhdmUpID09IG51bGwgPyB2b2lkIDAgOiBfZS5jYWxsKF9vcHRpb25zLCBudWxsLCBldmVudCk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJkcm9wXCI6XG4gICAgICAgICAgY291bnRlciA9IDA7XG4gICAgICAgICAgaXNPdmVyRHJvcFpvbmUudmFsdWUgPSBmYWxzZTtcbiAgICAgICAgICBpZiAoaXNWYWxpZCkge1xuICAgICAgICAgICAgZmlsZXMudmFsdWUgPSBjdXJyZW50RmlsZXM7XG4gICAgICAgICAgICAoX2YgPSBfb3B0aW9ucy5vbkRyb3ApID09IG51bGwgPyB2b2lkIDAgOiBfZi5jYWxsKF9vcHRpb25zLCBjdXJyZW50RmlsZXMsIGV2ZW50KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfTtcbiAgICB1c2VFdmVudExpc3RlbmVyKHRhcmdldCwgXCJkcmFnZW50ZXJcIiwgKGV2ZW50KSA9PiBoYW5kbGVEcmFnRXZlbnQoZXZlbnQsIFwiZW50ZXJcIikpO1xuICAgIHVzZUV2ZW50TGlzdGVuZXIodGFyZ2V0LCBcImRyYWdvdmVyXCIsIChldmVudCkgPT4gaGFuZGxlRHJhZ0V2ZW50KGV2ZW50LCBcIm92ZXJcIikpO1xuICAgIHVzZUV2ZW50TGlzdGVuZXIodGFyZ2V0LCBcImRyYWdsZWF2ZVwiLCAoZXZlbnQpID0+IGhhbmRsZURyYWdFdmVudChldmVudCwgXCJsZWF2ZVwiKSk7XG4gICAgdXNlRXZlbnRMaXN0ZW5lcih0YXJnZXQsIFwiZHJvcFwiLCAoZXZlbnQpID0+IGhhbmRsZURyYWdFdmVudChldmVudCwgXCJkcm9wXCIpKTtcbiAgfVxuICByZXR1cm4ge1xuICAgIGZpbGVzLFxuICAgIGlzT3ZlckRyb3Bab25lXG4gIH07XG59XG5cbmZ1bmN0aW9uIHVzZVJlc2l6ZU9ic2VydmVyKHRhcmdldCwgY2FsbGJhY2ssIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7IHdpbmRvdyA9IGRlZmF1bHRXaW5kb3csIC4uLm9ic2VydmVyT3B0aW9ucyB9ID0gb3B0aW9ucztcbiAgbGV0IG9ic2VydmVyO1xuICBjb25zdCBpc1N1cHBvcnRlZCA9IHVzZVN1cHBvcnRlZCgoKSA9PiB3aW5kb3cgJiYgXCJSZXNpemVPYnNlcnZlclwiIGluIHdpbmRvdyk7XG4gIGNvbnN0IGNsZWFudXAgPSAoKSA9PiB7XG4gICAgaWYgKG9ic2VydmVyKSB7XG4gICAgICBvYnNlcnZlci5kaXNjb25uZWN0KCk7XG4gICAgICBvYnNlcnZlciA9IHZvaWQgMDtcbiAgICB9XG4gIH07XG4gIGNvbnN0IHRhcmdldHMgPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgY29uc3QgX3RhcmdldHMgPSB0b1ZhbHVlKHRhcmdldCk7XG4gICAgcmV0dXJuIEFycmF5LmlzQXJyYXkoX3RhcmdldHMpID8gX3RhcmdldHMubWFwKChlbCkgPT4gdW5yZWZFbGVtZW50KGVsKSkgOiBbdW5yZWZFbGVtZW50KF90YXJnZXRzKV07XG4gIH0pO1xuICBjb25zdCBzdG9wV2F0Y2ggPSB3YXRjaChcbiAgICB0YXJnZXRzLFxuICAgIChlbHMpID0+IHtcbiAgICAgIGNsZWFudXAoKTtcbiAgICAgIGlmIChpc1N1cHBvcnRlZC52YWx1ZSAmJiB3aW5kb3cpIHtcbiAgICAgICAgb2JzZXJ2ZXIgPSBuZXcgUmVzaXplT2JzZXJ2ZXIoY2FsbGJhY2spO1xuICAgICAgICBmb3IgKGNvbnN0IF9lbCBvZiBlbHMpIHtcbiAgICAgICAgICBpZiAoX2VsKVxuICAgICAgICAgICAgb2JzZXJ2ZXIub2JzZXJ2ZShfZWwsIG9ic2VydmVyT3B0aW9ucyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIHsgaW1tZWRpYXRlOiB0cnVlLCBmbHVzaDogXCJwb3N0XCIgfVxuICApO1xuICBjb25zdCBzdG9wID0gKCkgPT4ge1xuICAgIGNsZWFudXAoKTtcbiAgICBzdG9wV2F0Y2goKTtcbiAgfTtcbiAgdHJ5T25TY29wZURpc3Bvc2Uoc3RvcCk7XG4gIHJldHVybiB7XG4gICAgaXNTdXBwb3J0ZWQsXG4gICAgc3RvcFxuICB9O1xufVxuXG5mdW5jdGlvbiB1c2VFbGVtZW50Qm91bmRpbmcodGFyZ2V0LCBvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIHJlc2V0ID0gdHJ1ZSxcbiAgICB3aW5kb3dSZXNpemUgPSB0cnVlLFxuICAgIHdpbmRvd1Njcm9sbCA9IHRydWUsXG4gICAgaW1tZWRpYXRlID0gdHJ1ZSxcbiAgICB1cGRhdGVUaW1pbmcgPSBcInN5bmNcIlxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgaGVpZ2h0ID0gc2hhbGxvd1JlZigwKTtcbiAgY29uc3QgYm90dG9tID0gc2hhbGxvd1JlZigwKTtcbiAgY29uc3QgbGVmdCA9IHNoYWxsb3dSZWYoMCk7XG4gIGNvbnN0IHJpZ2h0ID0gc2hhbGxvd1JlZigwKTtcbiAgY29uc3QgdG9wID0gc2hhbGxvd1JlZigwKTtcbiAgY29uc3Qgd2lkdGggPSBzaGFsbG93UmVmKDApO1xuICBjb25zdCB4ID0gc2hhbGxvd1JlZigwKTtcbiAgY29uc3QgeSA9IHNoYWxsb3dSZWYoMCk7XG4gIGZ1bmN0aW9uIHJlY2FsY3VsYXRlKCkge1xuICAgIGNvbnN0IGVsID0gdW5yZWZFbGVtZW50KHRhcmdldCk7XG4gICAgaWYgKCFlbCkge1xuICAgICAgaWYgKHJlc2V0KSB7XG4gICAgICAgIGhlaWdodC52YWx1ZSA9IDA7XG4gICAgICAgIGJvdHRvbS52YWx1ZSA9IDA7XG4gICAgICAgIGxlZnQudmFsdWUgPSAwO1xuICAgICAgICByaWdodC52YWx1ZSA9IDA7XG4gICAgICAgIHRvcC52YWx1ZSA9IDA7XG4gICAgICAgIHdpZHRoLnZhbHVlID0gMDtcbiAgICAgICAgeC52YWx1ZSA9IDA7XG4gICAgICAgIHkudmFsdWUgPSAwO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCByZWN0ID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgaGVpZ2h0LnZhbHVlID0gcmVjdC5oZWlnaHQ7XG4gICAgYm90dG9tLnZhbHVlID0gcmVjdC5ib3R0b207XG4gICAgbGVmdC52YWx1ZSA9IHJlY3QubGVmdDtcbiAgICByaWdodC52YWx1ZSA9IHJlY3QucmlnaHQ7XG4gICAgdG9wLnZhbHVlID0gcmVjdC50b3A7XG4gICAgd2lkdGgudmFsdWUgPSByZWN0LndpZHRoO1xuICAgIHgudmFsdWUgPSByZWN0Lng7XG4gICAgeS52YWx1ZSA9IHJlY3QueTtcbiAgfVxuICBmdW5jdGlvbiB1cGRhdGUoKSB7XG4gICAgaWYgKHVwZGF0ZVRpbWluZyA9PT0gXCJzeW5jXCIpXG4gICAgICByZWNhbGN1bGF0ZSgpO1xuICAgIGVsc2UgaWYgKHVwZGF0ZVRpbWluZyA9PT0gXCJuZXh0LWZyYW1lXCIpXG4gICAgICByZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCkgPT4gcmVjYWxjdWxhdGUoKSk7XG4gIH1cbiAgdXNlUmVzaXplT2JzZXJ2ZXIodGFyZ2V0LCB1cGRhdGUpO1xuICB3YXRjaCgoKSA9PiB1bnJlZkVsZW1lbnQodGFyZ2V0KSwgKGVsZSkgPT4gIWVsZSAmJiB1cGRhdGUoKSk7XG4gIHVzZU11dGF0aW9uT2JzZXJ2ZXIodGFyZ2V0LCB1cGRhdGUsIHtcbiAgICBhdHRyaWJ1dGVGaWx0ZXI6IFtcInN0eWxlXCIsIFwiY2xhc3NcIl1cbiAgfSk7XG4gIGlmICh3aW5kb3dTY3JvbGwpXG4gICAgdXNlRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLCB1cGRhdGUsIHsgY2FwdHVyZTogdHJ1ZSwgcGFzc2l2ZTogdHJ1ZSB9KTtcbiAgaWYgKHdpbmRvd1Jlc2l6ZSlcbiAgICB1c2VFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIHVwZGF0ZSwgeyBwYXNzaXZlOiB0cnVlIH0pO1xuICB0cnlPbk1vdW50ZWQoKCkgPT4ge1xuICAgIGlmIChpbW1lZGlhdGUpXG4gICAgICB1cGRhdGUoKTtcbiAgfSk7XG4gIHJldHVybiB7XG4gICAgaGVpZ2h0LFxuICAgIGJvdHRvbSxcbiAgICBsZWZ0LFxuICAgIHJpZ2h0LFxuICAgIHRvcCxcbiAgICB3aWR0aCxcbiAgICB4LFxuICAgIHksXG4gICAgdXBkYXRlXG4gIH07XG59XG5cbmZ1bmN0aW9uIHVzZUVsZW1lbnRCeVBvaW50KG9wdGlvbnMpIHtcbiAgY29uc3Qge1xuICAgIHgsXG4gICAgeSxcbiAgICBkb2N1bWVudCA9IGRlZmF1bHREb2N1bWVudCxcbiAgICBtdWx0aXBsZSxcbiAgICBpbnRlcnZhbCA9IFwicmVxdWVzdEFuaW1hdGlvbkZyYW1lXCIsXG4gICAgaW1tZWRpYXRlID0gdHJ1ZVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgaXNTdXBwb3J0ZWQgPSB1c2VTdXBwb3J0ZWQoKCkgPT4ge1xuICAgIGlmICh0b1ZhbHVlKG11bHRpcGxlKSlcbiAgICAgIHJldHVybiBkb2N1bWVudCAmJiBcImVsZW1lbnRzRnJvbVBvaW50XCIgaW4gZG9jdW1lbnQ7XG4gICAgcmV0dXJuIGRvY3VtZW50ICYmIFwiZWxlbWVudEZyb21Qb2ludFwiIGluIGRvY3VtZW50O1xuICB9KTtcbiAgY29uc3QgZWxlbWVudCA9IHNoYWxsb3dSZWYobnVsbCk7XG4gIGNvbnN0IGNiID0gKCkgPT4ge1xuICAgIHZhciBfYSwgX2I7XG4gICAgZWxlbWVudC52YWx1ZSA9IHRvVmFsdWUobXVsdGlwbGUpID8gKF9hID0gZG9jdW1lbnQgPT0gbnVsbCA/IHZvaWQgMCA6IGRvY3VtZW50LmVsZW1lbnRzRnJvbVBvaW50KHRvVmFsdWUoeCksIHRvVmFsdWUoeSkpKSAhPSBudWxsID8gX2EgOiBbXSA6IChfYiA9IGRvY3VtZW50ID09IG51bGwgPyB2b2lkIDAgOiBkb2N1bWVudC5lbGVtZW50RnJvbVBvaW50KHRvVmFsdWUoeCksIHRvVmFsdWUoeSkpKSAhPSBudWxsID8gX2IgOiBudWxsO1xuICB9O1xuICBjb25zdCBjb250cm9scyA9IGludGVydmFsID09PSBcInJlcXVlc3RBbmltYXRpb25GcmFtZVwiID8gdXNlUmFmRm4oY2IsIHsgaW1tZWRpYXRlIH0pIDogdXNlSW50ZXJ2YWxGbihjYiwgaW50ZXJ2YWwsIHsgaW1tZWRpYXRlIH0pO1xuICByZXR1cm4ge1xuICAgIGlzU3VwcG9ydGVkLFxuICAgIGVsZW1lbnQsXG4gICAgLi4uY29udHJvbHNcbiAgfTtcbn1cblxuZnVuY3Rpb24gdXNlRWxlbWVudEhvdmVyKGVsLCBvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGRlbGF5RW50ZXIgPSAwLFxuICAgIGRlbGF5TGVhdmUgPSAwLFxuICAgIHRyaWdnZXJPblJlbW92YWwgPSBmYWxzZSxcbiAgICB3aW5kb3cgPSBkZWZhdWx0V2luZG93XG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBpc0hvdmVyZWQgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgbGV0IHRpbWVyO1xuICBjb25zdCB0b2dnbGUgPSAoZW50ZXJpbmcpID0+IHtcbiAgICBjb25zdCBkZWxheSA9IGVudGVyaW5nID8gZGVsYXlFbnRlciA6IGRlbGF5TGVhdmU7XG4gICAgaWYgKHRpbWVyKSB7XG4gICAgICBjbGVhclRpbWVvdXQodGltZXIpO1xuICAgICAgdGltZXIgPSB2b2lkIDA7XG4gICAgfVxuICAgIGlmIChkZWxheSlcbiAgICAgIHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiBpc0hvdmVyZWQudmFsdWUgPSBlbnRlcmluZywgZGVsYXkpO1xuICAgIGVsc2VcbiAgICAgIGlzSG92ZXJlZC52YWx1ZSA9IGVudGVyaW5nO1xuICB9O1xuICBpZiAoIXdpbmRvdylcbiAgICByZXR1cm4gaXNIb3ZlcmVkO1xuICB1c2VFdmVudExpc3RlbmVyKGVsLCBcIm1vdXNlZW50ZXJcIiwgKCkgPT4gdG9nZ2xlKHRydWUpLCB7IHBhc3NpdmU6IHRydWUgfSk7XG4gIHVzZUV2ZW50TGlzdGVuZXIoZWwsIFwibW91c2VsZWF2ZVwiLCAoKSA9PiB0b2dnbGUoZmFsc2UpLCB7IHBhc3NpdmU6IHRydWUgfSk7XG4gIGlmICh0cmlnZ2VyT25SZW1vdmFsKSB7XG4gICAgb25FbGVtZW50UmVtb3ZhbChcbiAgICAgIGNvbXB1dGVkKCgpID0+IHVucmVmRWxlbWVudChlbCkpLFxuICAgICAgKCkgPT4gdG9nZ2xlKGZhbHNlKVxuICAgICk7XG4gIH1cbiAgcmV0dXJuIGlzSG92ZXJlZDtcbn1cblxuZnVuY3Rpb24gdXNlRWxlbWVudFNpemUodGFyZ2V0LCBpbml0aWFsU2l6ZSA9IHsgd2lkdGg6IDAsIGhlaWdodDogMCB9LCBvcHRpb25zID0ge30pIHtcbiAgY29uc3QgeyB3aW5kb3cgPSBkZWZhdWx0V2luZG93LCBib3ggPSBcImNvbnRlbnQtYm94XCIgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGlzU1ZHID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIHZhciBfYSwgX2I7XG4gICAgcmV0dXJuIChfYiA9IChfYSA9IHVucmVmRWxlbWVudCh0YXJnZXQpKSA9PSBudWxsID8gdm9pZCAwIDogX2EubmFtZXNwYWNlVVJJKSA9PSBudWxsID8gdm9pZCAwIDogX2IuaW5jbHVkZXMoXCJzdmdcIik7XG4gIH0pO1xuICBjb25zdCB3aWR0aCA9IHNoYWxsb3dSZWYoaW5pdGlhbFNpemUud2lkdGgpO1xuICBjb25zdCBoZWlnaHQgPSBzaGFsbG93UmVmKGluaXRpYWxTaXplLmhlaWdodCk7XG4gIGNvbnN0IHsgc3RvcDogc3RvcDEgfSA9IHVzZVJlc2l6ZU9ic2VydmVyKFxuICAgIHRhcmdldCxcbiAgICAoW2VudHJ5XSkgPT4ge1xuICAgICAgY29uc3QgYm94U2l6ZSA9IGJveCA9PT0gXCJib3JkZXItYm94XCIgPyBlbnRyeS5ib3JkZXJCb3hTaXplIDogYm94ID09PSBcImNvbnRlbnQtYm94XCIgPyBlbnRyeS5jb250ZW50Qm94U2l6ZSA6IGVudHJ5LmRldmljZVBpeGVsQ29udGVudEJveFNpemU7XG4gICAgICBpZiAod2luZG93ICYmIGlzU1ZHLnZhbHVlKSB7XG4gICAgICAgIGNvbnN0ICRlbGVtID0gdW5yZWZFbGVtZW50KHRhcmdldCk7XG4gICAgICAgIGlmICgkZWxlbSkge1xuICAgICAgICAgIGNvbnN0IHJlY3QgPSAkZWxlbS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgICB3aWR0aC52YWx1ZSA9IHJlY3Qud2lkdGg7XG4gICAgICAgICAgaGVpZ2h0LnZhbHVlID0gcmVjdC5oZWlnaHQ7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChib3hTaXplKSB7XG4gICAgICAgICAgY29uc3QgZm9ybWF0Qm94U2l6ZSA9IHRvQXJyYXkoYm94U2l6ZSk7XG4gICAgICAgICAgd2lkdGgudmFsdWUgPSBmb3JtYXRCb3hTaXplLnJlZHVjZSgoYWNjLCB7IGlubGluZVNpemUgfSkgPT4gYWNjICsgaW5saW5lU2l6ZSwgMCk7XG4gICAgICAgICAgaGVpZ2h0LnZhbHVlID0gZm9ybWF0Qm94U2l6ZS5yZWR1Y2UoKGFjYywgeyBibG9ja1NpemUgfSkgPT4gYWNjICsgYmxvY2tTaXplLCAwKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB3aWR0aC52YWx1ZSA9IGVudHJ5LmNvbnRlbnRSZWN0LndpZHRoO1xuICAgICAgICAgIGhlaWdodC52YWx1ZSA9IGVudHJ5LmNvbnRlbnRSZWN0LmhlaWdodDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gICAgb3B0aW9uc1xuICApO1xuICB0cnlPbk1vdW50ZWQoKCkgPT4ge1xuICAgIGNvbnN0IGVsZSA9IHVucmVmRWxlbWVudCh0YXJnZXQpO1xuICAgIGlmIChlbGUpIHtcbiAgICAgIHdpZHRoLnZhbHVlID0gXCJvZmZzZXRXaWR0aFwiIGluIGVsZSA/IGVsZS5vZmZzZXRXaWR0aCA6IGluaXRpYWxTaXplLndpZHRoO1xuICAgICAgaGVpZ2h0LnZhbHVlID0gXCJvZmZzZXRIZWlnaHRcIiBpbiBlbGUgPyBlbGUub2Zmc2V0SGVpZ2h0IDogaW5pdGlhbFNpemUuaGVpZ2h0O1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IHN0b3AyID0gd2F0Y2goXG4gICAgKCkgPT4gdW5yZWZFbGVtZW50KHRhcmdldCksXG4gICAgKGVsZSkgPT4ge1xuICAgICAgd2lkdGgudmFsdWUgPSBlbGUgPyBpbml0aWFsU2l6ZS53aWR0aCA6IDA7XG4gICAgICBoZWlnaHQudmFsdWUgPSBlbGUgPyBpbml0aWFsU2l6ZS5oZWlnaHQgOiAwO1xuICAgIH1cbiAgKTtcbiAgZnVuY3Rpb24gc3RvcCgpIHtcbiAgICBzdG9wMSgpO1xuICAgIHN0b3AyKCk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB3aWR0aCxcbiAgICBoZWlnaHQsXG4gICAgc3RvcFxuICB9O1xufVxuXG5mdW5jdGlvbiB1c2VJbnRlcnNlY3Rpb25PYnNlcnZlcih0YXJnZXQsIGNhbGxiYWNrLCBvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIHJvb3QsXG4gICAgcm9vdE1hcmdpbiA9IFwiMHB4XCIsXG4gICAgdGhyZXNob2xkID0gMCxcbiAgICB3aW5kb3cgPSBkZWZhdWx0V2luZG93LFxuICAgIGltbWVkaWF0ZSA9IHRydWVcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGlzU3VwcG9ydGVkID0gdXNlU3VwcG9ydGVkKCgpID0+IHdpbmRvdyAmJiBcIkludGVyc2VjdGlvbk9ic2VydmVyXCIgaW4gd2luZG93KTtcbiAgY29uc3QgdGFyZ2V0cyA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICBjb25zdCBfdGFyZ2V0ID0gdG9WYWx1ZSh0YXJnZXQpO1xuICAgIHJldHVybiB0b0FycmF5KF90YXJnZXQpLm1hcCh1bnJlZkVsZW1lbnQpLmZpbHRlcihub3ROdWxsaXNoKTtcbiAgfSk7XG4gIGxldCBjbGVhbnVwID0gbm9vcDtcbiAgY29uc3QgaXNBY3RpdmUgPSBzaGFsbG93UmVmKGltbWVkaWF0ZSk7XG4gIGNvbnN0IHN0b3BXYXRjaCA9IGlzU3VwcG9ydGVkLnZhbHVlID8gd2F0Y2goXG4gICAgKCkgPT4gW3RhcmdldHMudmFsdWUsIHVucmVmRWxlbWVudChyb290KSwgaXNBY3RpdmUudmFsdWVdLFxuICAgIChbdGFyZ2V0czIsIHJvb3QyXSkgPT4ge1xuICAgICAgY2xlYW51cCgpO1xuICAgICAgaWYgKCFpc0FjdGl2ZS52YWx1ZSlcbiAgICAgICAgcmV0dXJuO1xuICAgICAgaWYgKCF0YXJnZXRzMi5sZW5ndGgpXG4gICAgICAgIHJldHVybjtcbiAgICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IEludGVyc2VjdGlvbk9ic2VydmVyKFxuICAgICAgICBjYWxsYmFjayxcbiAgICAgICAge1xuICAgICAgICAgIHJvb3Q6IHVucmVmRWxlbWVudChyb290MiksXG4gICAgICAgICAgcm9vdE1hcmdpbixcbiAgICAgICAgICB0aHJlc2hvbGRcbiAgICAgICAgfVxuICAgICAgKTtcbiAgICAgIHRhcmdldHMyLmZvckVhY2goKGVsKSA9PiBlbCAmJiBvYnNlcnZlci5vYnNlcnZlKGVsKSk7XG4gICAgICBjbGVhbnVwID0gKCkgPT4ge1xuICAgICAgICBvYnNlcnZlci5kaXNjb25uZWN0KCk7XG4gICAgICAgIGNsZWFudXAgPSBub29wO1xuICAgICAgfTtcbiAgICB9LFxuICAgIHsgaW1tZWRpYXRlLCBmbHVzaDogXCJwb3N0XCIgfVxuICApIDogbm9vcDtcbiAgY29uc3Qgc3RvcCA9ICgpID0+IHtcbiAgICBjbGVhbnVwKCk7XG4gICAgc3RvcFdhdGNoKCk7XG4gICAgaXNBY3RpdmUudmFsdWUgPSBmYWxzZTtcbiAgfTtcbiAgdHJ5T25TY29wZURpc3Bvc2Uoc3RvcCk7XG4gIHJldHVybiB7XG4gICAgaXNTdXBwb3J0ZWQsXG4gICAgaXNBY3RpdmUsXG4gICAgcGF1c2UoKSB7XG4gICAgICBjbGVhbnVwKCk7XG4gICAgICBpc0FjdGl2ZS52YWx1ZSA9IGZhbHNlO1xuICAgIH0sXG4gICAgcmVzdW1lKCkge1xuICAgICAgaXNBY3RpdmUudmFsdWUgPSB0cnVlO1xuICAgIH0sXG4gICAgc3RvcFxuICB9O1xufVxuXG5mdW5jdGlvbiB1c2VFbGVtZW50VmlzaWJpbGl0eShlbGVtZW50LCBvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIHdpbmRvdyA9IGRlZmF1bHRXaW5kb3csXG4gICAgc2Nyb2xsVGFyZ2V0LFxuICAgIHRocmVzaG9sZCA9IDAsXG4gICAgcm9vdE1hcmdpbixcbiAgICBvbmNlID0gZmFsc2VcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGVsZW1lbnRJc1Zpc2libGUgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgY29uc3QgeyBzdG9wIH0gPSB1c2VJbnRlcnNlY3Rpb25PYnNlcnZlcihcbiAgICBlbGVtZW50LFxuICAgIChpbnRlcnNlY3Rpb25PYnNlcnZlckVudHJpZXMpID0+IHtcbiAgICAgIGxldCBpc0ludGVyc2VjdGluZyA9IGVsZW1lbnRJc1Zpc2libGUudmFsdWU7XG4gICAgICBsZXQgbGF0ZXN0VGltZSA9IDA7XG4gICAgICBmb3IgKGNvbnN0IGVudHJ5IG9mIGludGVyc2VjdGlvbk9ic2VydmVyRW50cmllcykge1xuICAgICAgICBpZiAoZW50cnkudGltZSA+PSBsYXRlc3RUaW1lKSB7XG4gICAgICAgICAgbGF0ZXN0VGltZSA9IGVudHJ5LnRpbWU7XG4gICAgICAgICAgaXNJbnRlcnNlY3RpbmcgPSBlbnRyeS5pc0ludGVyc2VjdGluZztcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgZWxlbWVudElzVmlzaWJsZS52YWx1ZSA9IGlzSW50ZXJzZWN0aW5nO1xuICAgICAgaWYgKG9uY2UpIHtcbiAgICAgICAgd2F0Y2hPbmNlKGVsZW1lbnRJc1Zpc2libGUsICgpID0+IHtcbiAgICAgICAgICBzdG9wKCk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICAge1xuICAgICAgcm9vdDogc2Nyb2xsVGFyZ2V0LFxuICAgICAgd2luZG93LFxuICAgICAgdGhyZXNob2xkLFxuICAgICAgcm9vdE1hcmdpbjogdG9WYWx1ZShyb290TWFyZ2luKVxuICAgIH1cbiAgKTtcbiAgcmV0dXJuIGVsZW1lbnRJc1Zpc2libGU7XG59XG5cbmNvbnN0IGV2ZW50cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VFdmVudEJ1cyhrZXkpIHtcbiAgY29uc3Qgc2NvcGUgPSBnZXRDdXJyZW50U2NvcGUoKTtcbiAgZnVuY3Rpb24gb24obGlzdGVuZXIpIHtcbiAgICB2YXIgX2E7XG4gICAgY29uc3QgbGlzdGVuZXJzID0gZXZlbnRzLmdldChrZXkpIHx8IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gICAgbGlzdGVuZXJzLmFkZChsaXN0ZW5lcik7XG4gICAgZXZlbnRzLnNldChrZXksIGxpc3RlbmVycyk7XG4gICAgY29uc3QgX29mZiA9ICgpID0+IG9mZihsaXN0ZW5lcik7XG4gICAgKF9hID0gc2NvcGUgPT0gbnVsbCA/IHZvaWQgMCA6IHNjb3BlLmNsZWFudXBzKSA9PSBudWxsID8gdm9pZCAwIDogX2EucHVzaChfb2ZmKTtcbiAgICByZXR1cm4gX29mZjtcbiAgfVxuICBmdW5jdGlvbiBvbmNlKGxpc3RlbmVyKSB7XG4gICAgZnVuY3Rpb24gX2xpc3RlbmVyKC4uLmFyZ3MpIHtcbiAgICAgIG9mZihfbGlzdGVuZXIpO1xuICAgICAgbGlzdGVuZXIoLi4uYXJncyk7XG4gICAgfVxuICAgIHJldHVybiBvbihfbGlzdGVuZXIpO1xuICB9XG4gIGZ1bmN0aW9uIG9mZihsaXN0ZW5lcikge1xuICAgIGNvbnN0IGxpc3RlbmVycyA9IGV2ZW50cy5nZXQoa2V5KTtcbiAgICBpZiAoIWxpc3RlbmVycylcbiAgICAgIHJldHVybjtcbiAgICBsaXN0ZW5lcnMuZGVsZXRlKGxpc3RlbmVyKTtcbiAgICBpZiAoIWxpc3RlbmVycy5zaXplKVxuICAgICAgcmVzZXQoKTtcbiAgfVxuICBmdW5jdGlvbiByZXNldCgpIHtcbiAgICBldmVudHMuZGVsZXRlKGtleSk7XG4gIH1cbiAgZnVuY3Rpb24gZW1pdChldmVudCwgcGF5bG9hZCkge1xuICAgIHZhciBfYTtcbiAgICAoX2EgPSBldmVudHMuZ2V0KGtleSkpID09IG51bGwgPyB2b2lkIDAgOiBfYS5mb3JFYWNoKCh2KSA9PiB2KGV2ZW50LCBwYXlsb2FkKSk7XG4gIH1cbiAgcmV0dXJuIHsgb24sIG9uY2UsIG9mZiwgZW1pdCwgcmVzZXQgfTtcbn1cblxuZnVuY3Rpb24gcmVzb2x2ZU5lc3RlZE9wdGlvbnMkMShvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB0cnVlKVxuICAgIHJldHVybiB7fTtcbiAgcmV0dXJuIG9wdGlvbnM7XG59XG5mdW5jdGlvbiB1c2VFdmVudFNvdXJjZSh1cmwsIGV2ZW50cyA9IFtdLCBvcHRpb25zID0ge30pIHtcbiAgY29uc3QgZXZlbnQgPSBzaGFsbG93UmVmKG51bGwpO1xuICBjb25zdCBkYXRhID0gc2hhbGxvd1JlZihudWxsKTtcbiAgY29uc3Qgc3RhdHVzID0gc2hhbGxvd1JlZihcIkNPTk5FQ1RJTkdcIik7XG4gIGNvbnN0IGV2ZW50U291cmNlID0gcmVmKG51bGwpO1xuICBjb25zdCBlcnJvciA9IHNoYWxsb3dSZWYobnVsbCk7XG4gIGNvbnN0IHVybFJlZiA9IHRvUmVmKHVybCk7XG4gIGNvbnN0IGxhc3RFdmVudElkID0gc2hhbGxvd1JlZihudWxsKTtcbiAgbGV0IGV4cGxpY2l0bHlDbG9zZWQgPSBmYWxzZTtcbiAgbGV0IHJldHJpZWQgPSAwO1xuICBjb25zdCB7XG4gICAgd2l0aENyZWRlbnRpYWxzID0gZmFsc2UsXG4gICAgaW1tZWRpYXRlID0gdHJ1ZSxcbiAgICBhdXRvQ29ubmVjdCA9IHRydWUsXG4gICAgYXV0b1JlY29ubmVjdCxcbiAgICBzZXJpYWxpemVyID0ge1xuICAgICAgcmVhZDogKHYpID0+IHZcbiAgICB9XG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBjbG9zZSA9ICgpID0+IHtcbiAgICBpZiAoaXNDbGllbnQgJiYgZXZlbnRTb3VyY2UudmFsdWUpIHtcbiAgICAgIGV2ZW50U291cmNlLnZhbHVlLmNsb3NlKCk7XG4gICAgICBldmVudFNvdXJjZS52YWx1ZSA9IG51bGw7XG4gICAgICBzdGF0dXMudmFsdWUgPSBcIkNMT1NFRFwiO1xuICAgICAgZXhwbGljaXRseUNsb3NlZCA9IHRydWU7XG4gICAgfVxuICB9O1xuICBjb25zdCBfaW5pdCA9ICgpID0+IHtcbiAgICBpZiAoZXhwbGljaXRseUNsb3NlZCB8fCB0eXBlb2YgdXJsUmVmLnZhbHVlID09PSBcInVuZGVmaW5lZFwiKVxuICAgICAgcmV0dXJuO1xuICAgIGNvbnN0IGVzID0gbmV3IEV2ZW50U291cmNlKHVybFJlZi52YWx1ZSwgeyB3aXRoQ3JlZGVudGlhbHMgfSk7XG4gICAgc3RhdHVzLnZhbHVlID0gXCJDT05ORUNUSU5HXCI7XG4gICAgZXZlbnRTb3VyY2UudmFsdWUgPSBlcztcbiAgICBlcy5vbm9wZW4gPSAoKSA9PiB7XG4gICAgICBzdGF0dXMudmFsdWUgPSBcIk9QRU5cIjtcbiAgICAgIGVycm9yLnZhbHVlID0gbnVsbDtcbiAgICB9O1xuICAgIGVzLm9uZXJyb3IgPSAoZSkgPT4ge1xuICAgICAgc3RhdHVzLnZhbHVlID0gXCJDTE9TRURcIjtcbiAgICAgIGVycm9yLnZhbHVlID0gZTtcbiAgICAgIGlmIChlcy5yZWFkeVN0YXRlID09PSAyICYmICFleHBsaWNpdGx5Q2xvc2VkICYmIGF1dG9SZWNvbm5lY3QpIHtcbiAgICAgICAgZXMuY2xvc2UoKTtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIHJldHJpZXMgPSAtMSxcbiAgICAgICAgICBkZWxheSA9IDFlMyxcbiAgICAgICAgICBvbkZhaWxlZFxuICAgICAgICB9ID0gcmVzb2x2ZU5lc3RlZE9wdGlvbnMkMShhdXRvUmVjb25uZWN0KTtcbiAgICAgICAgcmV0cmllZCArPSAxO1xuICAgICAgICBpZiAodHlwZW9mIHJldHJpZXMgPT09IFwibnVtYmVyXCIgJiYgKHJldHJpZXMgPCAwIHx8IHJldHJpZWQgPCByZXRyaWVzKSlcbiAgICAgICAgICBzZXRUaW1lb3V0KF9pbml0LCBkZWxheSk7XG4gICAgICAgIGVsc2UgaWYgKHR5cGVvZiByZXRyaWVzID09PSBcImZ1bmN0aW9uXCIgJiYgcmV0cmllcygpKVxuICAgICAgICAgIHNldFRpbWVvdXQoX2luaXQsIGRlbGF5KTtcbiAgICAgICAgZWxzZVxuICAgICAgICAgIG9uRmFpbGVkID09IG51bGwgPyB2b2lkIDAgOiBvbkZhaWxlZCgpO1xuICAgICAgfVxuICAgIH07XG4gICAgZXMub25tZXNzYWdlID0gKGUpID0+IHtcbiAgICAgIHZhciBfYTtcbiAgICAgIGV2ZW50LnZhbHVlID0gbnVsbDtcbiAgICAgIGRhdGEudmFsdWUgPSAoX2EgPSBzZXJpYWxpemVyLnJlYWQoZS5kYXRhKSkgIT0gbnVsbCA/IF9hIDogbnVsbDtcbiAgICAgIGxhc3RFdmVudElkLnZhbHVlID0gZS5sYXN0RXZlbnRJZDtcbiAgICB9O1xuICAgIGZvciAoY29uc3QgZXZlbnRfbmFtZSBvZiBldmVudHMpIHtcbiAgICAgIHVzZUV2ZW50TGlzdGVuZXIoZXMsIGV2ZW50X25hbWUsIChlKSA9PiB7XG4gICAgICAgIHZhciBfYSwgX2I7XG4gICAgICAgIGV2ZW50LnZhbHVlID0gZXZlbnRfbmFtZTtcbiAgICAgICAgZGF0YS52YWx1ZSA9IChfYSA9IHNlcmlhbGl6ZXIucmVhZChlLmRhdGEpKSAhPSBudWxsID8gX2EgOiBudWxsO1xuICAgICAgICBsYXN0RXZlbnRJZC52YWx1ZSA9IChfYiA9IGUubGFzdEV2ZW50SWQpICE9IG51bGwgPyBfYiA6IG51bGw7XG4gICAgICB9LCB7IHBhc3NpdmU6IHRydWUgfSk7XG4gICAgfVxuICB9O1xuICBjb25zdCBvcGVuID0gKCkgPT4ge1xuICAgIGlmICghaXNDbGllbnQpXG4gICAgICByZXR1cm47XG4gICAgY2xvc2UoKTtcbiAgICBleHBsaWNpdGx5Q2xvc2VkID0gZmFsc2U7XG4gICAgcmV0cmllZCA9IDA7XG4gICAgX2luaXQoKTtcbiAgfTtcbiAgaWYgKGltbWVkaWF0ZSlcbiAgICBvcGVuKCk7XG4gIGlmIChhdXRvQ29ubmVjdClcbiAgICB3YXRjaCh1cmxSZWYsIG9wZW4pO1xuICB0cnlPblNjb3BlRGlzcG9zZShjbG9zZSk7XG4gIHJldHVybiB7XG4gICAgZXZlbnRTb3VyY2UsXG4gICAgZXZlbnQsXG4gICAgZGF0YSxcbiAgICBzdGF0dXMsXG4gICAgZXJyb3IsXG4gICAgb3BlbixcbiAgICBjbG9zZSxcbiAgICBsYXN0RXZlbnRJZFxuICB9O1xufVxuXG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gdXNlRXllRHJvcHBlcihvcHRpb25zID0ge30pIHtcbiAgY29uc3QgeyBpbml0aWFsVmFsdWUgPSBcIlwiIH0gPSBvcHRpb25zO1xuICBjb25zdCBpc1N1cHBvcnRlZCA9IHVzZVN1cHBvcnRlZCgoKSA9PiB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIFwiRXllRHJvcHBlclwiIGluIHdpbmRvdyk7XG4gIGNvbnN0IHNSR0JIZXggPSBzaGFsbG93UmVmKGluaXRpYWxWYWx1ZSk7XG4gIGFzeW5jIGZ1bmN0aW9uIG9wZW4ob3Blbk9wdGlvbnMpIHtcbiAgICBpZiAoIWlzU3VwcG9ydGVkLnZhbHVlKVxuICAgICAgcmV0dXJuO1xuICAgIGNvbnN0IGV5ZURyb3BwZXIgPSBuZXcgd2luZG93LkV5ZURyb3BwZXIoKTtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBleWVEcm9wcGVyLm9wZW4ob3Blbk9wdGlvbnMpO1xuICAgIHNSR0JIZXgudmFsdWUgPSByZXN1bHQuc1JHQkhleDtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG4gIHJldHVybiB7IGlzU3VwcG9ydGVkLCBzUkdCSGV4LCBvcGVuIH07XG59XG5cbmZ1bmN0aW9uIHVzZUZhdmljb24obmV3SWNvbiA9IG51bGwsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgYmFzZVVybCA9IFwiXCIsXG4gICAgcmVsID0gXCJpY29uXCIsXG4gICAgZG9jdW1lbnQgPSBkZWZhdWx0RG9jdW1lbnRcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGZhdmljb24gPSB0b1JlZihuZXdJY29uKTtcbiAgY29uc3QgYXBwbHlJY29uID0gKGljb24pID0+IHtcbiAgICBjb25zdCBlbGVtZW50cyA9IGRvY3VtZW50ID09IG51bGwgPyB2b2lkIDAgOiBkb2N1bWVudC5oZWFkLnF1ZXJ5U2VsZWN0b3JBbGwoYGxpbmtbcmVsKj1cIiR7cmVsfVwiXWApO1xuICAgIGlmICghZWxlbWVudHMgfHwgZWxlbWVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgICBjb25zdCBsaW5rID0gZG9jdW1lbnQgPT0gbnVsbCA/IHZvaWQgMCA6IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJsaW5rXCIpO1xuICAgICAgaWYgKGxpbmspIHtcbiAgICAgICAgbGluay5yZWwgPSByZWw7XG4gICAgICAgIGxpbmsuaHJlZiA9IGAke2Jhc2VVcmx9JHtpY29ufWA7XG4gICAgICAgIGxpbmsudHlwZSA9IGBpbWFnZS8ke2ljb24uc3BsaXQoXCIuXCIpLnBvcCgpfWA7XG4gICAgICAgIGRvY3VtZW50ID09IG51bGwgPyB2b2lkIDAgOiBkb2N1bWVudC5oZWFkLmFwcGVuZChsaW5rKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgZWxlbWVudHMgPT0gbnVsbCA/IHZvaWQgMCA6IGVsZW1lbnRzLmZvckVhY2goKGVsKSA9PiBlbC5ocmVmID0gYCR7YmFzZVVybH0ke2ljb259YCk7XG4gIH07XG4gIHdhdGNoKFxuICAgIGZhdmljb24sXG4gICAgKGksIG8pID0+IHtcbiAgICAgIGlmICh0eXBlb2YgaSA9PT0gXCJzdHJpbmdcIiAmJiBpICE9PSBvKVxuICAgICAgICBhcHBseUljb24oaSk7XG4gICAgfSxcbiAgICB7IGltbWVkaWF0ZTogdHJ1ZSB9XG4gICk7XG4gIHJldHVybiBmYXZpY29uO1xufVxuXG5jb25zdCBwYXlsb2FkTWFwcGluZyA9IHtcbiAganNvbjogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gIHRleHQ6IFwidGV4dC9wbGFpblwiXG59O1xuZnVuY3Rpb24gaXNGZXRjaE9wdGlvbnMob2JqKSB7XG4gIHJldHVybiBvYmogJiYgY29udGFpbnNQcm9wKG9iaiwgXCJpbW1lZGlhdGVcIiwgXCJyZWZldGNoXCIsIFwiaW5pdGlhbERhdGFcIiwgXCJ0aW1lb3V0XCIsIFwiYmVmb3JlRmV0Y2hcIiwgXCJhZnRlckZldGNoXCIsIFwib25GZXRjaEVycm9yXCIsIFwiZmV0Y2hcIiwgXCJ1cGRhdGVEYXRhT25FcnJvclwiKTtcbn1cbmNvbnN0IHJlQWJzb2x1dGUgPSAvXig/OlthLXpdW2EtelxcZCtcXC0uXSo6KT9cXC9cXC8vaTtcbmZ1bmN0aW9uIGlzQWJzb2x1dGVVUkwodXJsKSB7XG4gIHJldHVybiByZUFic29sdXRlLnRlc3QodXJsKTtcbn1cbmZ1bmN0aW9uIGhlYWRlcnNUb09iamVjdChoZWFkZXJzKSB7XG4gIGlmICh0eXBlb2YgSGVhZGVycyAhPT0gXCJ1bmRlZmluZWRcIiAmJiBoZWFkZXJzIGluc3RhbmNlb2YgSGVhZGVycylcbiAgICByZXR1cm4gT2JqZWN0LmZyb21FbnRyaWVzKGhlYWRlcnMuZW50cmllcygpKTtcbiAgcmV0dXJuIGhlYWRlcnM7XG59XG5mdW5jdGlvbiBjb21iaW5lQ2FsbGJhY2tzKGNvbWJpbmF0aW9uLCAuLi5jYWxsYmFja3MpIHtcbiAgaWYgKGNvbWJpbmF0aW9uID09PSBcIm92ZXJ3cml0ZVwiKSB7XG4gICAgcmV0dXJuIGFzeW5jIChjdHgpID0+IHtcbiAgICAgIGxldCBjYWxsYmFjaztcbiAgICAgIGZvciAobGV0IGkgPSBjYWxsYmFja3MubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgICAgaWYgKGNhbGxiYWNrc1tpXSAhPSBudWxsKSB7XG4gICAgICAgICAgY2FsbGJhY2sgPSBjYWxsYmFja3NbaV07XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChjYWxsYmFjaylcbiAgICAgICAgcmV0dXJuIHsgLi4uY3R4LCAuLi5hd2FpdCBjYWxsYmFjayhjdHgpIH07XG4gICAgICByZXR1cm4gY3R4O1xuICAgIH07XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIGFzeW5jIChjdHgpID0+IHtcbiAgICAgIGZvciAoY29uc3QgY2FsbGJhY2sgb2YgY2FsbGJhY2tzKSB7XG4gICAgICAgIGlmIChjYWxsYmFjaylcbiAgICAgICAgICBjdHggPSB7IC4uLmN0eCwgLi4uYXdhaXQgY2FsbGJhY2soY3R4KSB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIGN0eDtcbiAgICB9O1xuICB9XG59XG5mdW5jdGlvbiBjcmVhdGVGZXRjaChjb25maWcgPSB7fSkge1xuICBjb25zdCBfY29tYmluYXRpb24gPSBjb25maWcuY29tYmluYXRpb24gfHwgXCJjaGFpblwiO1xuICBjb25zdCBfb3B0aW9ucyA9IGNvbmZpZy5vcHRpb25zIHx8IHt9O1xuICBjb25zdCBfZmV0Y2hPcHRpb25zID0gY29uZmlnLmZldGNoT3B0aW9ucyB8fCB7fTtcbiAgZnVuY3Rpb24gdXNlRmFjdG9yeUZldGNoKHVybCwgLi4uYXJncykge1xuICAgIGNvbnN0IGNvbXB1dGVkVXJsID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgICAgY29uc3QgYmFzZVVybCA9IHRvVmFsdWUoY29uZmlnLmJhc2VVcmwpO1xuICAgICAgY29uc3QgdGFyZ2V0VXJsID0gdG9WYWx1ZSh1cmwpO1xuICAgICAgcmV0dXJuIGJhc2VVcmwgJiYgIWlzQWJzb2x1dGVVUkwodGFyZ2V0VXJsKSA/IGpvaW5QYXRocyhiYXNlVXJsLCB0YXJnZXRVcmwpIDogdGFyZ2V0VXJsO1xuICAgIH0pO1xuICAgIGxldCBvcHRpb25zID0gX29wdGlvbnM7XG4gICAgbGV0IGZldGNoT3B0aW9ucyA9IF9mZXRjaE9wdGlvbnM7XG4gICAgaWYgKGFyZ3MubGVuZ3RoID4gMCkge1xuICAgICAgaWYgKGlzRmV0Y2hPcHRpb25zKGFyZ3NbMF0pKSB7XG4gICAgICAgIG9wdGlvbnMgPSB7XG4gICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAuLi5hcmdzWzBdLFxuICAgICAgICAgIGJlZm9yZUZldGNoOiBjb21iaW5lQ2FsbGJhY2tzKF9jb21iaW5hdGlvbiwgX29wdGlvbnMuYmVmb3JlRmV0Y2gsIGFyZ3NbMF0uYmVmb3JlRmV0Y2gpLFxuICAgICAgICAgIGFmdGVyRmV0Y2g6IGNvbWJpbmVDYWxsYmFja3MoX2NvbWJpbmF0aW9uLCBfb3B0aW9ucy5hZnRlckZldGNoLCBhcmdzWzBdLmFmdGVyRmV0Y2gpLFxuICAgICAgICAgIG9uRmV0Y2hFcnJvcjogY29tYmluZUNhbGxiYWNrcyhfY29tYmluYXRpb24sIF9vcHRpb25zLm9uRmV0Y2hFcnJvciwgYXJnc1swXS5vbkZldGNoRXJyb3IpXG4gICAgICAgIH07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBmZXRjaE9wdGlvbnMgPSB7XG4gICAgICAgICAgLi4uZmV0Y2hPcHRpb25zLFxuICAgICAgICAgIC4uLmFyZ3NbMF0sXG4gICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgLi4uaGVhZGVyc1RvT2JqZWN0KGZldGNoT3B0aW9ucy5oZWFkZXJzKSB8fCB7fSxcbiAgICAgICAgICAgIC4uLmhlYWRlcnNUb09iamVjdChhcmdzWzBdLmhlYWRlcnMpIHx8IHt9XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoYXJncy5sZW5ndGggPiAxICYmIGlzRmV0Y2hPcHRpb25zKGFyZ3NbMV0pKSB7XG4gICAgICBvcHRpb25zID0ge1xuICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAuLi5hcmdzWzFdLFxuICAgICAgICBiZWZvcmVGZXRjaDogY29tYmluZUNhbGxiYWNrcyhfY29tYmluYXRpb24sIF9vcHRpb25zLmJlZm9yZUZldGNoLCBhcmdzWzFdLmJlZm9yZUZldGNoKSxcbiAgICAgICAgYWZ0ZXJGZXRjaDogY29tYmluZUNhbGxiYWNrcyhfY29tYmluYXRpb24sIF9vcHRpb25zLmFmdGVyRmV0Y2gsIGFyZ3NbMV0uYWZ0ZXJGZXRjaCksXG4gICAgICAgIG9uRmV0Y2hFcnJvcjogY29tYmluZUNhbGxiYWNrcyhfY29tYmluYXRpb24sIF9vcHRpb25zLm9uRmV0Y2hFcnJvciwgYXJnc1sxXS5vbkZldGNoRXJyb3IpXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gdXNlRmV0Y2goY29tcHV0ZWRVcmwsIGZldGNoT3B0aW9ucywgb3B0aW9ucyk7XG4gIH1cbiAgcmV0dXJuIHVzZUZhY3RvcnlGZXRjaDtcbn1cbmZ1bmN0aW9uIHVzZUZldGNoKHVybCwgLi4uYXJncykge1xuICB2YXIgX2EsIF9iO1xuICBjb25zdCBzdXBwb3J0c0Fib3J0ID0gdHlwZW9mIEFib3J0Q29udHJvbGxlciA9PT0gXCJmdW5jdGlvblwiO1xuICBsZXQgZmV0Y2hPcHRpb25zID0ge307XG4gIGxldCBvcHRpb25zID0ge1xuICAgIGltbWVkaWF0ZTogdHJ1ZSxcbiAgICByZWZldGNoOiBmYWxzZSxcbiAgICB0aW1lb3V0OiAwLFxuICAgIHVwZGF0ZURhdGFPbkVycm9yOiBmYWxzZVxuICB9O1xuICBjb25zdCBjb25maWcgPSB7XG4gICAgbWV0aG9kOiBcIkdFVFwiLFxuICAgIHR5cGU6IFwidGV4dFwiLFxuICAgIHBheWxvYWQ6IHZvaWQgMFxuICB9O1xuICBpZiAoYXJncy5sZW5ndGggPiAwKSB7XG4gICAgaWYgKGlzRmV0Y2hPcHRpb25zKGFyZ3NbMF0pKVxuICAgICAgb3B0aW9ucyA9IHsgLi4ub3B0aW9ucywgLi4uYXJnc1swXSB9O1xuICAgIGVsc2VcbiAgICAgIGZldGNoT3B0aW9ucyA9IGFyZ3NbMF07XG4gIH1cbiAgaWYgKGFyZ3MubGVuZ3RoID4gMSkge1xuICAgIGlmIChpc0ZldGNoT3B0aW9ucyhhcmdzWzFdKSlcbiAgICAgIG9wdGlvbnMgPSB7IC4uLm9wdGlvbnMsIC4uLmFyZ3NbMV0gfTtcbiAgfVxuICBjb25zdCB7XG4gICAgZmV0Y2ggPSAoX2IgPSAoX2EgPSBkZWZhdWx0V2luZG93KSA9PSBudWxsID8gdm9pZCAwIDogX2EuZmV0Y2gpICE9IG51bGwgPyBfYiA6IGdsb2JhbFRoaXMgPT0gbnVsbCA/IHZvaWQgMCA6IGdsb2JhbFRoaXMuZmV0Y2gsXG4gICAgaW5pdGlhbERhdGEsXG4gICAgdGltZW91dFxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgcmVzcG9uc2VFdmVudCA9IGNyZWF0ZUV2ZW50SG9vaygpO1xuICBjb25zdCBlcnJvckV2ZW50ID0gY3JlYXRlRXZlbnRIb29rKCk7XG4gIGNvbnN0IGZpbmFsbHlFdmVudCA9IGNyZWF0ZUV2ZW50SG9vaygpO1xuICBjb25zdCBpc0ZpbmlzaGVkID0gc2hhbGxvd1JlZihmYWxzZSk7XG4gIGNvbnN0IGlzRmV0Y2hpbmcgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgY29uc3QgYWJvcnRlZCA9IHNoYWxsb3dSZWYoZmFsc2UpO1xuICBjb25zdCBzdGF0dXNDb2RlID0gc2hhbGxvd1JlZihudWxsKTtcbiAgY29uc3QgcmVzcG9uc2UgPSBzaGFsbG93UmVmKG51bGwpO1xuICBjb25zdCBlcnJvciA9IHNoYWxsb3dSZWYobnVsbCk7XG4gIGNvbnN0IGRhdGEgPSBzaGFsbG93UmVmKGluaXRpYWxEYXRhIHx8IG51bGwpO1xuICBjb25zdCBjYW5BYm9ydCA9IGNvbXB1dGVkKCgpID0+IHN1cHBvcnRzQWJvcnQgJiYgaXNGZXRjaGluZy52YWx1ZSk7XG4gIGxldCBjb250cm9sbGVyO1xuICBsZXQgdGltZXI7XG4gIGNvbnN0IGFib3J0ID0gKHJlYXNvbikgPT4ge1xuICAgIGlmIChzdXBwb3J0c0Fib3J0KSB7XG4gICAgICBjb250cm9sbGVyID09IG51bGwgPyB2b2lkIDAgOiBjb250cm9sbGVyLmFib3J0KHJlYXNvbik7XG4gICAgICBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgICAgY29udHJvbGxlci5zaWduYWwub25hYm9ydCA9ICgpID0+IGFib3J0ZWQudmFsdWUgPSB0cnVlO1xuICAgICAgZmV0Y2hPcHRpb25zID0ge1xuICAgICAgICAuLi5mZXRjaE9wdGlvbnMsXG4gICAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWxcbiAgICAgIH07XG4gICAgfVxuICB9O1xuICBjb25zdCBsb2FkaW5nID0gKGlzTG9hZGluZykgPT4ge1xuICAgIGlzRmV0Y2hpbmcudmFsdWUgPSBpc0xvYWRpbmc7XG4gICAgaXNGaW5pc2hlZC52YWx1ZSA9ICFpc0xvYWRpbmc7XG4gIH07XG4gIGlmICh0aW1lb3V0KVxuICAgIHRpbWVyID0gdXNlVGltZW91dEZuKGFib3J0LCB0aW1lb3V0LCB7IGltbWVkaWF0ZTogZmFsc2UgfSk7XG4gIGxldCBleGVjdXRlQ291bnRlciA9IDA7XG4gIGNvbnN0IGV4ZWN1dGUgPSBhc3luYyAodGhyb3dPbkZhaWxlZCA9IGZhbHNlKSA9PiB7XG4gICAgdmFyIF9hMiwgX2IyO1xuICAgIGFib3J0KCk7XG4gICAgbG9hZGluZyh0cnVlKTtcbiAgICBlcnJvci52YWx1ZSA9IG51bGw7XG4gICAgc3RhdHVzQ29kZS52YWx1ZSA9IG51bGw7XG4gICAgYWJvcnRlZC52YWx1ZSA9IGZhbHNlO1xuICAgIGV4ZWN1dGVDb3VudGVyICs9IDE7XG4gICAgY29uc3QgY3VycmVudEV4ZWN1dGVDb3VudGVyID0gZXhlY3V0ZUNvdW50ZXI7XG4gICAgY29uc3QgZGVmYXVsdEZldGNoT3B0aW9ucyA9IHtcbiAgICAgIG1ldGhvZDogY29uZmlnLm1ldGhvZCxcbiAgICAgIGhlYWRlcnM6IHt9XG4gICAgfTtcbiAgICBjb25zdCBwYXlsb2FkID0gdG9WYWx1ZShjb25maWcucGF5bG9hZCk7XG4gICAgaWYgKHBheWxvYWQpIHtcbiAgICAgIGNvbnN0IGhlYWRlcnMgPSBoZWFkZXJzVG9PYmplY3QoZGVmYXVsdEZldGNoT3B0aW9ucy5oZWFkZXJzKTtcbiAgICAgIGNvbnN0IHByb3RvID0gT2JqZWN0LmdldFByb3RvdHlwZU9mKHBheWxvYWQpO1xuICAgICAgaWYgKCFjb25maWcucGF5bG9hZFR5cGUgJiYgcGF5bG9hZCAmJiAocHJvdG8gPT09IE9iamVjdC5wcm90b3R5cGUgfHwgQXJyYXkuaXNBcnJheShwcm90bykpICYmICEocGF5bG9hZCBpbnN0YW5jZW9mIEZvcm1EYXRhKSlcbiAgICAgICAgY29uZmlnLnBheWxvYWRUeXBlID0gXCJqc29uXCI7XG4gICAgICBpZiAoY29uZmlnLnBheWxvYWRUeXBlKVxuICAgICAgICBoZWFkZXJzW1wiQ29udGVudC1UeXBlXCJdID0gKF9hMiA9IHBheWxvYWRNYXBwaW5nW2NvbmZpZy5wYXlsb2FkVHlwZV0pICE9IG51bGwgPyBfYTIgOiBjb25maWcucGF5bG9hZFR5cGU7XG4gICAgICBkZWZhdWx0RmV0Y2hPcHRpb25zLmJvZHkgPSBjb25maWcucGF5bG9hZFR5cGUgPT09IFwianNvblwiID8gSlNPTi5zdHJpbmdpZnkocGF5bG9hZCkgOiBwYXlsb2FkO1xuICAgIH1cbiAgICBsZXQgaXNDYW5jZWxlZCA9IGZhbHNlO1xuICAgIGNvbnN0IGNvbnRleHQgPSB7XG4gICAgICB1cmw6IHRvVmFsdWUodXJsKSxcbiAgICAgIG9wdGlvbnM6IHtcbiAgICAgICAgLi4uZGVmYXVsdEZldGNoT3B0aW9ucyxcbiAgICAgICAgLi4uZmV0Y2hPcHRpb25zXG4gICAgICB9LFxuICAgICAgY2FuY2VsOiAoKSA9PiB7XG4gICAgICAgIGlzQ2FuY2VsZWQgPSB0cnVlO1xuICAgICAgfVxuICAgIH07XG4gICAgaWYgKG9wdGlvbnMuYmVmb3JlRmV0Y2gpXG4gICAgICBPYmplY3QuYXNzaWduKGNvbnRleHQsIGF3YWl0IG9wdGlvbnMuYmVmb3JlRmV0Y2goY29udGV4dCkpO1xuICAgIGlmIChpc0NhbmNlbGVkIHx8ICFmZXRjaCkge1xuICAgICAgbG9hZGluZyhmYWxzZSk7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKG51bGwpO1xuICAgIH1cbiAgICBsZXQgcmVzcG9uc2VEYXRhID0gbnVsbDtcbiAgICBpZiAodGltZXIpXG4gICAgICB0aW1lci5zdGFydCgpO1xuICAgIHJldHVybiBmZXRjaChcbiAgICAgIGNvbnRleHQudXJsLFxuICAgICAge1xuICAgICAgICAuLi5kZWZhdWx0RmV0Y2hPcHRpb25zLFxuICAgICAgICAuLi5jb250ZXh0Lm9wdGlvbnMsXG4gICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAuLi5oZWFkZXJzVG9PYmplY3QoZGVmYXVsdEZldGNoT3B0aW9ucy5oZWFkZXJzKSxcbiAgICAgICAgICAuLi5oZWFkZXJzVG9PYmplY3QoKF9iMiA9IGNvbnRleHQub3B0aW9ucykgPT0gbnVsbCA/IHZvaWQgMCA6IF9iMi5oZWFkZXJzKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgKS50aGVuKGFzeW5jIChmZXRjaFJlc3BvbnNlKSA9PiB7XG4gICAgICByZXNwb25zZS52YWx1ZSA9IGZldGNoUmVzcG9uc2U7XG4gICAgICBzdGF0dXNDb2RlLnZhbHVlID0gZmV0Y2hSZXNwb25zZS5zdGF0dXM7XG4gICAgICByZXNwb25zZURhdGEgPSBhd2FpdCBmZXRjaFJlc3BvbnNlLmNsb25lKClbY29uZmlnLnR5cGVdKCk7XG4gICAgICBpZiAoIWZldGNoUmVzcG9uc2Uub2spIHtcbiAgICAgICAgZGF0YS52YWx1ZSA9IGluaXRpYWxEYXRhIHx8IG51bGw7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihmZXRjaFJlc3BvbnNlLnN0YXR1c1RleHQpO1xuICAgICAgfVxuICAgICAgaWYgKG9wdGlvbnMuYWZ0ZXJGZXRjaCkge1xuICAgICAgICAoeyBkYXRhOiByZXNwb25zZURhdGEgfSA9IGF3YWl0IG9wdGlvbnMuYWZ0ZXJGZXRjaCh7XG4gICAgICAgICAgZGF0YTogcmVzcG9uc2VEYXRhLFxuICAgICAgICAgIHJlc3BvbnNlOiBmZXRjaFJlc3BvbnNlLFxuICAgICAgICAgIGNvbnRleHQsXG4gICAgICAgICAgZXhlY3V0ZVxuICAgICAgICB9KSk7XG4gICAgICB9XG4gICAgICBkYXRhLnZhbHVlID0gcmVzcG9uc2VEYXRhO1xuICAgICAgcmVzcG9uc2VFdmVudC50cmlnZ2VyKGZldGNoUmVzcG9uc2UpO1xuICAgICAgcmV0dXJuIGZldGNoUmVzcG9uc2U7XG4gICAgfSkuY2F0Y2goYXN5bmMgKGZldGNoRXJyb3IpID0+IHtcbiAgICAgIGxldCBlcnJvckRhdGEgPSBmZXRjaEVycm9yLm1lc3NhZ2UgfHwgZmV0Y2hFcnJvci5uYW1lO1xuICAgICAgaWYgKG9wdGlvbnMub25GZXRjaEVycm9yKSB7XG4gICAgICAgICh7IGVycm9yOiBlcnJvckRhdGEsIGRhdGE6IHJlc3BvbnNlRGF0YSB9ID0gYXdhaXQgb3B0aW9ucy5vbkZldGNoRXJyb3Ioe1xuICAgICAgICAgIGRhdGE6IHJlc3BvbnNlRGF0YSxcbiAgICAgICAgICBlcnJvcjogZmV0Y2hFcnJvcixcbiAgICAgICAgICByZXNwb25zZTogcmVzcG9uc2UudmFsdWUsXG4gICAgICAgICAgY29udGV4dCxcbiAgICAgICAgICBleGVjdXRlXG4gICAgICAgIH0pKTtcbiAgICAgIH1cbiAgICAgIGVycm9yLnZhbHVlID0gZXJyb3JEYXRhO1xuICAgICAgaWYgKG9wdGlvbnMudXBkYXRlRGF0YU9uRXJyb3IpXG4gICAgICAgIGRhdGEudmFsdWUgPSByZXNwb25zZURhdGE7XG4gICAgICBlcnJvckV2ZW50LnRyaWdnZXIoZmV0Y2hFcnJvcik7XG4gICAgICBpZiAodGhyb3dPbkZhaWxlZClcbiAgICAgICAgdGhyb3cgZmV0Y2hFcnJvcjtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgICAgaWYgKGN1cnJlbnRFeGVjdXRlQ291bnRlciA9PT0gZXhlY3V0ZUNvdW50ZXIpXG4gICAgICAgIGxvYWRpbmcoZmFsc2UpO1xuICAgICAgaWYgKHRpbWVyKVxuICAgICAgICB0aW1lci5zdG9wKCk7XG4gICAgICBmaW5hbGx5RXZlbnQudHJpZ2dlcihudWxsKTtcbiAgICB9KTtcbiAgfTtcbiAgY29uc3QgcmVmZXRjaCA9IHRvUmVmKG9wdGlvbnMucmVmZXRjaCk7XG4gIHdhdGNoKFxuICAgIFtcbiAgICAgIHJlZmV0Y2gsXG4gICAgICB0b1JlZih1cmwpXG4gICAgXSxcbiAgICAoW3JlZmV0Y2gyXSkgPT4gcmVmZXRjaDIgJiYgZXhlY3V0ZSgpLFxuICAgIHsgZGVlcDogdHJ1ZSB9XG4gICk7XG4gIGNvbnN0IHNoZWxsID0ge1xuICAgIGlzRmluaXNoZWQ6IHJlYWRvbmx5KGlzRmluaXNoZWQpLFxuICAgIGlzRmV0Y2hpbmc6IHJlYWRvbmx5KGlzRmV0Y2hpbmcpLFxuICAgIHN0YXR1c0NvZGUsXG4gICAgcmVzcG9uc2UsXG4gICAgZXJyb3IsXG4gICAgZGF0YSxcbiAgICBjYW5BYm9ydCxcbiAgICBhYm9ydGVkLFxuICAgIGFib3J0LFxuICAgIGV4ZWN1dGUsXG4gICAgb25GZXRjaFJlc3BvbnNlOiByZXNwb25zZUV2ZW50Lm9uLFxuICAgIG9uRmV0Y2hFcnJvcjogZXJyb3JFdmVudC5vbixcbiAgICBvbkZldGNoRmluYWxseTogZmluYWxseUV2ZW50Lm9uLFxuICAgIC8vIG1ldGhvZFxuICAgIGdldDogc2V0TWV0aG9kKFwiR0VUXCIpLFxuICAgIHB1dDogc2V0TWV0aG9kKFwiUFVUXCIpLFxuICAgIHBvc3Q6IHNldE1ldGhvZChcIlBPU1RcIiksXG4gICAgZGVsZXRlOiBzZXRNZXRob2QoXCJERUxFVEVcIiksXG4gICAgcGF0Y2g6IHNldE1ldGhvZChcIlBBVENIXCIpLFxuICAgIGhlYWQ6IHNldE1ldGhvZChcIkhFQURcIiksXG4gICAgb3B0aW9uczogc2V0TWV0aG9kKFwiT1BUSU9OU1wiKSxcbiAgICAvLyB0eXBlXG4gICAganNvbjogc2V0VHlwZShcImpzb25cIiksXG4gICAgdGV4dDogc2V0VHlwZShcInRleHRcIiksXG4gICAgYmxvYjogc2V0VHlwZShcImJsb2JcIiksXG4gICAgYXJyYXlCdWZmZXI6IHNldFR5cGUoXCJhcnJheUJ1ZmZlclwiKSxcbiAgICBmb3JtRGF0YTogc2V0VHlwZShcImZvcm1EYXRhXCIpXG4gIH07XG4gIGZ1bmN0aW9uIHNldE1ldGhvZChtZXRob2QpIHtcbiAgICByZXR1cm4gKHBheWxvYWQsIHBheWxvYWRUeXBlKSA9PiB7XG4gICAgICBpZiAoIWlzRmV0Y2hpbmcudmFsdWUpIHtcbiAgICAgICAgY29uZmlnLm1ldGhvZCA9IG1ldGhvZDtcbiAgICAgICAgY29uZmlnLnBheWxvYWQgPSBwYXlsb2FkO1xuICAgICAgICBjb25maWcucGF5bG9hZFR5cGUgPSBwYXlsb2FkVHlwZTtcbiAgICAgICAgaWYgKGlzUmVmKGNvbmZpZy5wYXlsb2FkKSkge1xuICAgICAgICAgIHdhdGNoKFxuICAgICAgICAgICAgW1xuICAgICAgICAgICAgICByZWZldGNoLFxuICAgICAgICAgICAgICB0b1JlZihjb25maWcucGF5bG9hZClcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAoW3JlZmV0Y2gyXSkgPT4gcmVmZXRjaDIgJiYgZXhlY3V0ZSgpLFxuICAgICAgICAgICAgeyBkZWVwOiB0cnVlIH1cbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgLi4uc2hlbGwsXG4gICAgICAgICAgdGhlbihvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCkge1xuICAgICAgICAgICAgcmV0dXJuIHdhaXRVbnRpbEZpbmlzaGVkKCkudGhlbihvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCk7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHZvaWQgMDtcbiAgICB9O1xuICB9XG4gIGZ1bmN0aW9uIHdhaXRVbnRpbEZpbmlzaGVkKCkge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICB1bnRpbChpc0ZpbmlzaGVkKS50b0JlKHRydWUpLnRoZW4oKCkgPT4gcmVzb2x2ZShzaGVsbCkpLmNhdGNoKHJlamVjdCk7XG4gICAgfSk7XG4gIH1cbiAgZnVuY3Rpb24gc2V0VHlwZSh0eXBlKSB7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlmICghaXNGZXRjaGluZy52YWx1ZSkge1xuICAgICAgICBjb25maWcudHlwZSA9IHR5cGU7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgLi4uc2hlbGwsXG4gICAgICAgICAgdGhlbihvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCkge1xuICAgICAgICAgICAgcmV0dXJuIHdhaXRVbnRpbEZpbmlzaGVkKCkudGhlbihvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCk7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHZvaWQgMDtcbiAgICB9O1xuICB9XG4gIGlmIChvcHRpb25zLmltbWVkaWF0ZSlcbiAgICBQcm9taXNlLnJlc29sdmUoKS50aGVuKCgpID0+IGV4ZWN1dGUoKSk7XG4gIHJldHVybiB7XG4gICAgLi4uc2hlbGwsXG4gICAgdGhlbihvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCkge1xuICAgICAgcmV0dXJuIHdhaXRVbnRpbEZpbmlzaGVkKCkudGhlbihvbkZ1bGZpbGxlZCwgb25SZWplY3RlZCk7XG4gICAgfVxuICB9O1xufVxuZnVuY3Rpb24gam9pblBhdGhzKHN0YXJ0LCBlbmQpIHtcbiAgaWYgKCFzdGFydC5lbmRzV2l0aChcIi9cIikgJiYgIWVuZC5zdGFydHNXaXRoKFwiL1wiKSkge1xuICAgIHJldHVybiBgJHtzdGFydH0vJHtlbmR9YDtcbiAgfVxuICBpZiAoc3RhcnQuZW5kc1dpdGgoXCIvXCIpICYmIGVuZC5zdGFydHNXaXRoKFwiL1wiKSkge1xuICAgIHJldHVybiBgJHtzdGFydC5zbGljZSgwLCAtMSl9JHtlbmR9YDtcbiAgfVxuICByZXR1cm4gYCR7c3RhcnR9JHtlbmR9YDtcbn1cblxuY29uc3QgREVGQVVMVF9PUFRJT05TID0ge1xuICBtdWx0aXBsZTogdHJ1ZSxcbiAgYWNjZXB0OiBcIipcIixcbiAgcmVzZXQ6IGZhbHNlLFxuICBkaXJlY3Rvcnk6IGZhbHNlXG59O1xuZnVuY3Rpb24gcHJlcGFyZUluaXRpYWxGaWxlcyhmaWxlcykge1xuICBpZiAoIWZpbGVzKVxuICAgIHJldHVybiBudWxsO1xuICBpZiAoZmlsZXMgaW5zdGFuY2VvZiBGaWxlTGlzdClcbiAgICByZXR1cm4gZmlsZXM7XG4gIGNvbnN0IGR0ID0gbmV3IERhdGFUcmFuc2ZlcigpO1xuICBmb3IgKGNvbnN0IGZpbGUgb2YgZmlsZXMpIHtcbiAgICBkdC5pdGVtcy5hZGQoZmlsZSk7XG4gIH1cbiAgcmV0dXJuIGR0LmZpbGVzO1xufVxuZnVuY3Rpb24gdXNlRmlsZURpYWxvZyhvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGRvY3VtZW50ID0gZGVmYXVsdERvY3VtZW50XG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBmaWxlcyA9IHJlZihwcmVwYXJlSW5pdGlhbEZpbGVzKG9wdGlvbnMuaW5pdGlhbEZpbGVzKSk7XG4gIGNvbnN0IHsgb246IG9uQ2hhbmdlLCB0cmlnZ2VyOiBjaGFuZ2VUcmlnZ2VyIH0gPSBjcmVhdGVFdmVudEhvb2soKTtcbiAgY29uc3QgeyBvbjogb25DYW5jZWwsIHRyaWdnZXI6IGNhbmNlbFRyaWdnZXIgfSA9IGNyZWF0ZUV2ZW50SG9vaygpO1xuICBjb25zdCBpbnB1dFJlZiA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICB2YXIgX2E7XG4gICAgY29uc3QgaW5wdXQgPSAoX2EgPSB1bnJlZkVsZW1lbnQob3B0aW9ucy5pbnB1dCkpICE9IG51bGwgPyBfYSA6IGRvY3VtZW50ID8gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImlucHV0XCIpIDogdm9pZCAwO1xuICAgIGlmIChpbnB1dCkge1xuICAgICAgaW5wdXQudHlwZSA9IFwiZmlsZVwiO1xuICAgICAgaW5wdXQub25jaGFuZ2UgPSAoZXZlbnQpID0+IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gZXZlbnQudGFyZ2V0O1xuICAgICAgICBmaWxlcy52YWx1ZSA9IHJlc3VsdC5maWxlcztcbiAgICAgICAgY2hhbmdlVHJpZ2dlcihmaWxlcy52YWx1ZSk7XG4gICAgICB9O1xuICAgICAgaW5wdXQub25jYW5jZWwgPSAoKSA9PiB7XG4gICAgICAgIGNhbmNlbFRyaWdnZXIoKTtcbiAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBpbnB1dDtcbiAgfSk7XG4gIGNvbnN0IHJlc2V0ID0gKCkgPT4ge1xuICAgIGZpbGVzLnZhbHVlID0gbnVsbDtcbiAgICBpZiAoaW5wdXRSZWYudmFsdWUgJiYgaW5wdXRSZWYudmFsdWUudmFsdWUpIHtcbiAgICAgIGlucHV0UmVmLnZhbHVlLnZhbHVlID0gXCJcIjtcbiAgICAgIGNoYW5nZVRyaWdnZXIobnVsbCk7XG4gICAgfVxuICB9O1xuICBjb25zdCBhcHBseU9wdGlvbnMgPSAob3B0aW9uczIpID0+IHtcbiAgICBjb25zdCBlbCA9IGlucHV0UmVmLnZhbHVlO1xuICAgIGlmICghZWwpXG4gICAgICByZXR1cm47XG4gICAgZWwubXVsdGlwbGUgPSB0b1ZhbHVlKG9wdGlvbnMyLm11bHRpcGxlKTtcbiAgICBlbC5hY2NlcHQgPSB0b1ZhbHVlKG9wdGlvbnMyLmFjY2VwdCk7XG4gICAgZWwud2Via2l0ZGlyZWN0b3J5ID0gdG9WYWx1ZShvcHRpb25zMi5kaXJlY3RvcnkpO1xuICAgIGlmIChoYXNPd24ob3B0aW9uczIsIFwiY2FwdHVyZVwiKSlcbiAgICAgIGVsLmNhcHR1cmUgPSB0b1ZhbHVlKG9wdGlvbnMyLmNhcHR1cmUpO1xuICB9O1xuICBjb25zdCBvcGVuID0gKGxvY2FsT3B0aW9ucykgPT4ge1xuICAgIGNvbnN0IGVsID0gaW5wdXRSZWYudmFsdWU7XG4gICAgaWYgKCFlbClcbiAgICAgIHJldHVybjtcbiAgICBjb25zdCBtZXJnZWRPcHRpb25zID0ge1xuICAgICAgLi4uREVGQVVMVF9PUFRJT05TLFxuICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIC4uLmxvY2FsT3B0aW9uc1xuICAgIH07XG4gICAgYXBwbHlPcHRpb25zKG1lcmdlZE9wdGlvbnMpO1xuICAgIGlmICh0b1ZhbHVlKG1lcmdlZE9wdGlvbnMucmVzZXQpKVxuICAgICAgcmVzZXQoKTtcbiAgICBlbC5jbGljaygpO1xuICB9O1xuICB3YXRjaEVmZmVjdCgoKSA9PiB7XG4gICAgYXBwbHlPcHRpb25zKG9wdGlvbnMpO1xuICB9KTtcbiAgcmV0dXJuIHtcbiAgICBmaWxlczogcmVhZG9ubHkoZmlsZXMpLFxuICAgIG9wZW4sXG4gICAgcmVzZXQsXG4gICAgb25DYW5jZWwsXG4gICAgb25DaGFuZ2VcbiAgfTtcbn1cblxuZnVuY3Rpb24gdXNlRmlsZVN5c3RlbUFjY2VzcyhvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIHdpbmRvdzogX3dpbmRvdyA9IGRlZmF1bHRXaW5kb3csXG4gICAgZGF0YVR5cGUgPSBcIlRleHRcIlxuICB9ID0gb3B0aW9ucztcbiAgY29uc3Qgd2luZG93ID0gX3dpbmRvdztcbiAgY29uc3QgaXNTdXBwb3J0ZWQgPSB1c2VTdXBwb3J0ZWQoKCkgPT4gd2luZG93ICYmIFwic2hvd1NhdmVGaWxlUGlja2VyXCIgaW4gd2luZG93ICYmIFwic2hvd09wZW5GaWxlUGlja2VyXCIgaW4gd2luZG93KTtcbiAgY29uc3QgZmlsZUhhbmRsZSA9IHNoYWxsb3dSZWYoKTtcbiAgY29uc3QgZGF0YSA9IHNoYWxsb3dSZWYoKTtcbiAgY29uc3QgZmlsZSA9IHNoYWxsb3dSZWYoKTtcbiAgY29uc3QgZmlsZU5hbWUgPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgdmFyIF9hLCBfYjtcbiAgICByZXR1cm4gKF9iID0gKF9hID0gZmlsZS52YWx1ZSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLm5hbWUpICE9IG51bGwgPyBfYiA6IFwiXCI7XG4gIH0pO1xuICBjb25zdCBmaWxlTUlNRSA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICB2YXIgX2EsIF9iO1xuICAgIHJldHVybiAoX2IgPSAoX2EgPSBmaWxlLnZhbHVlKSA9PSBudWxsID8gdm9pZCAwIDogX2EudHlwZSkgIT0gbnVsbCA/IF9iIDogXCJcIjtcbiAgfSk7XG4gIGNvbnN0IGZpbGVTaXplID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIHZhciBfYSwgX2I7XG4gICAgcmV0dXJuIChfYiA9IChfYSA9IGZpbGUudmFsdWUpID09IG51bGwgPyB2b2lkIDAgOiBfYS5zaXplKSAhPSBudWxsID8gX2IgOiAwO1xuICB9KTtcbiAgY29uc3QgZmlsZUxhc3RNb2RpZmllZCA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICB2YXIgX2EsIF9iO1xuICAgIHJldHVybiAoX2IgPSAoX2EgPSBmaWxlLnZhbHVlKSA9PSBudWxsID8gdm9pZCAwIDogX2EubGFzdE1vZGlmaWVkKSAhPSBudWxsID8gX2IgOiAwO1xuICB9KTtcbiAgYXN5bmMgZnVuY3Rpb24gb3Blbihfb3B0aW9ucyA9IHt9KSB7XG4gICAgaWYgKCFpc1N1cHBvcnRlZC52YWx1ZSlcbiAgICAgIHJldHVybjtcbiAgICBjb25zdCBbaGFuZGxlXSA9IGF3YWl0IHdpbmRvdy5zaG93T3BlbkZpbGVQaWNrZXIoeyAuLi50b1ZhbHVlKG9wdGlvbnMpLCAuLi5fb3B0aW9ucyB9KTtcbiAgICBmaWxlSGFuZGxlLnZhbHVlID0gaGFuZGxlO1xuICAgIGF3YWl0IHVwZGF0ZURhdGEoKTtcbiAgfVxuICBhc3luYyBmdW5jdGlvbiBjcmVhdGUoX29wdGlvbnMgPSB7fSkge1xuICAgIGlmICghaXNTdXBwb3J0ZWQudmFsdWUpXG4gICAgICByZXR1cm47XG4gICAgZmlsZUhhbmRsZS52YWx1ZSA9IGF3YWl0IHdpbmRvdy5zaG93U2F2ZUZpbGVQaWNrZXIoeyAuLi5vcHRpb25zLCAuLi5fb3B0aW9ucyB9KTtcbiAgICBkYXRhLnZhbHVlID0gdm9pZCAwO1xuICAgIGF3YWl0IHVwZGF0ZURhdGEoKTtcbiAgfVxuICBhc3luYyBmdW5jdGlvbiBzYXZlKF9vcHRpb25zID0ge30pIHtcbiAgICBpZiAoIWlzU3VwcG9ydGVkLnZhbHVlKVxuICAgICAgcmV0dXJuO1xuICAgIGlmICghZmlsZUhhbmRsZS52YWx1ZSlcbiAgICAgIHJldHVybiBzYXZlQXMoX29wdGlvbnMpO1xuICAgIGlmIChkYXRhLnZhbHVlKSB7XG4gICAgICBjb25zdCB3cml0YWJsZVN0cmVhbSA9IGF3YWl0IGZpbGVIYW5kbGUudmFsdWUuY3JlYXRlV3JpdGFibGUoKTtcbiAgICAgIGF3YWl0IHdyaXRhYmxlU3RyZWFtLndyaXRlKGRhdGEudmFsdWUpO1xuICAgICAgYXdhaXQgd3JpdGFibGVTdHJlYW0uY2xvc2UoKTtcbiAgICB9XG4gICAgYXdhaXQgdXBkYXRlRmlsZSgpO1xuICB9XG4gIGFzeW5jIGZ1bmN0aW9uIHNhdmVBcyhfb3B0aW9ucyA9IHt9KSB7XG4gICAgaWYgKCFpc1N1cHBvcnRlZC52YWx1ZSlcbiAgICAgIHJldHVybjtcbiAgICBmaWxlSGFuZGxlLnZhbHVlID0gYXdhaXQgd2luZG93LnNob3dTYXZlRmlsZVBpY2tlcih7IC4uLm9wdGlvbnMsIC4uLl9vcHRpb25zIH0pO1xuICAgIGlmIChkYXRhLnZhbHVlKSB7XG4gICAgICBjb25zdCB3cml0YWJsZVN0cmVhbSA9IGF3YWl0IGZpbGVIYW5kbGUudmFsdWUuY3JlYXRlV3JpdGFibGUoKTtcbiAgICAgIGF3YWl0IHdyaXRhYmxlU3RyZWFtLndyaXRlKGRhdGEudmFsdWUpO1xuICAgICAgYXdhaXQgd3JpdGFibGVTdHJlYW0uY2xvc2UoKTtcbiAgICB9XG4gICAgYXdhaXQgdXBkYXRlRmlsZSgpO1xuICB9XG4gIGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUZpbGUoKSB7XG4gICAgdmFyIF9hO1xuICAgIGZpbGUudmFsdWUgPSBhd2FpdCAoKF9hID0gZmlsZUhhbmRsZS52YWx1ZSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLmdldEZpbGUoKSk7XG4gIH1cbiAgYXN5bmMgZnVuY3Rpb24gdXBkYXRlRGF0YSgpIHtcbiAgICB2YXIgX2EsIF9iO1xuICAgIGF3YWl0IHVwZGF0ZUZpbGUoKTtcbiAgICBjb25zdCB0eXBlID0gdG9WYWx1ZShkYXRhVHlwZSk7XG4gICAgaWYgKHR5cGUgPT09IFwiVGV4dFwiKVxuICAgICAgZGF0YS52YWx1ZSA9IGF3YWl0ICgoX2EgPSBmaWxlLnZhbHVlKSA9PSBudWxsID8gdm9pZCAwIDogX2EudGV4dCgpKTtcbiAgICBlbHNlIGlmICh0eXBlID09PSBcIkFycmF5QnVmZmVyXCIpXG4gICAgICBkYXRhLnZhbHVlID0gYXdhaXQgKChfYiA9IGZpbGUudmFsdWUpID09IG51bGwgPyB2b2lkIDAgOiBfYi5hcnJheUJ1ZmZlcigpKTtcbiAgICBlbHNlIGlmICh0eXBlID09PSBcIkJsb2JcIilcbiAgICAgIGRhdGEudmFsdWUgPSBmaWxlLnZhbHVlO1xuICB9XG4gIHdhdGNoKCgpID0+IHRvVmFsdWUoZGF0YVR5cGUpLCB1cGRhdGVEYXRhKTtcbiAgcmV0dXJuIHtcbiAgICBpc1N1cHBvcnRlZCxcbiAgICBkYXRhLFxuICAgIGZpbGUsXG4gICAgZmlsZU5hbWUsXG4gICAgZmlsZU1JTUUsXG4gICAgZmlsZVNpemUsXG4gICAgZmlsZUxhc3RNb2RpZmllZCxcbiAgICBvcGVuLFxuICAgIGNyZWF0ZSxcbiAgICBzYXZlLFxuICAgIHNhdmVBcyxcbiAgICB1cGRhdGVEYXRhXG4gIH07XG59XG5cbmZ1bmN0aW9uIHVzZUZvY3VzKHRhcmdldCwgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHsgaW5pdGlhbFZhbHVlID0gZmFsc2UsIGZvY3VzVmlzaWJsZSA9IGZhbHNlLCBwcmV2ZW50U2Nyb2xsID0gZmFsc2UgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGlubmVyRm9jdXNlZCA9IHNoYWxsb3dSZWYoZmFsc2UpO1xuICBjb25zdCB0YXJnZXRFbGVtZW50ID0gY29tcHV0ZWQoKCkgPT4gdW5yZWZFbGVtZW50KHRhcmdldCkpO1xuICBjb25zdCBsaXN0ZW5lck9wdGlvbnMgPSB7IHBhc3NpdmU6IHRydWUgfTtcbiAgdXNlRXZlbnRMaXN0ZW5lcih0YXJnZXRFbGVtZW50LCBcImZvY3VzXCIsIChldmVudCkgPT4ge1xuICAgIHZhciBfYSwgX2I7XG4gICAgaWYgKCFmb2N1c1Zpc2libGUgfHwgKChfYiA9IChfYSA9IGV2ZW50LnRhcmdldCkubWF0Y2hlcykgPT0gbnVsbCA/IHZvaWQgMCA6IF9iLmNhbGwoX2EsIFwiOmZvY3VzLXZpc2libGVcIikpKVxuICAgICAgaW5uZXJGb2N1c2VkLnZhbHVlID0gdHJ1ZTtcbiAgfSwgbGlzdGVuZXJPcHRpb25zKTtcbiAgdXNlRXZlbnRMaXN0ZW5lcih0YXJnZXRFbGVtZW50LCBcImJsdXJcIiwgKCkgPT4gaW5uZXJGb2N1c2VkLnZhbHVlID0gZmFsc2UsIGxpc3RlbmVyT3B0aW9ucyk7XG4gIGNvbnN0IGZvY3VzZWQgPSBjb21wdXRlZCh7XG4gICAgZ2V0OiAoKSA9PiBpbm5lckZvY3VzZWQudmFsdWUsXG4gICAgc2V0KHZhbHVlKSB7XG4gICAgICB2YXIgX2EsIF9iO1xuICAgICAgaWYgKCF2YWx1ZSAmJiBpbm5lckZvY3VzZWQudmFsdWUpXG4gICAgICAgIChfYSA9IHRhcmdldEVsZW1lbnQudmFsdWUpID09IG51bGwgPyB2b2lkIDAgOiBfYS5ibHVyKCk7XG4gICAgICBlbHNlIGlmICh2YWx1ZSAmJiAhaW5uZXJGb2N1c2VkLnZhbHVlKVxuICAgICAgICAoX2IgPSB0YXJnZXRFbGVtZW50LnZhbHVlKSA9PSBudWxsID8gdm9pZCAwIDogX2IuZm9jdXMoeyBwcmV2ZW50U2Nyb2xsIH0pO1xuICAgIH1cbiAgfSk7XG4gIHdhdGNoKFxuICAgIHRhcmdldEVsZW1lbnQsXG4gICAgKCkgPT4ge1xuICAgICAgZm9jdXNlZC52YWx1ZSA9IGluaXRpYWxWYWx1ZTtcbiAgICB9LFxuICAgIHsgaW1tZWRpYXRlOiB0cnVlLCBmbHVzaDogXCJwb3N0XCIgfVxuICApO1xuICByZXR1cm4geyBmb2N1c2VkIH07XG59XG5cbmNvbnN0IEVWRU5UX0ZPQ1VTX0lOID0gXCJmb2N1c2luXCI7XG5jb25zdCBFVkVOVF9GT0NVU19PVVQgPSBcImZvY3Vzb3V0XCI7XG5jb25zdCBQU0VVRE9fQ0xBU1NfRk9DVVNfV0lUSElOID0gXCI6Zm9jdXMtd2l0aGluXCI7XG5mdW5jdGlvbiB1c2VGb2N1c1dpdGhpbih0YXJnZXQsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7IHdpbmRvdyA9IGRlZmF1bHRXaW5kb3cgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IHRhcmdldEVsZW1lbnQgPSBjb21wdXRlZCgoKSA9PiB1bnJlZkVsZW1lbnQodGFyZ2V0KSk7XG4gIGNvbnN0IF9mb2N1c2VkID0gc2hhbGxvd1JlZihmYWxzZSk7XG4gIGNvbnN0IGZvY3VzZWQgPSBjb21wdXRlZCgoKSA9PiBfZm9jdXNlZC52YWx1ZSk7XG4gIGNvbnN0IGFjdGl2ZUVsZW1lbnQgPSB1c2VBY3RpdmVFbGVtZW50KG9wdGlvbnMpO1xuICBpZiAoIXdpbmRvdyB8fCAhYWN0aXZlRWxlbWVudC52YWx1ZSkge1xuICAgIHJldHVybiB7IGZvY3VzZWQgfTtcbiAgfVxuICBjb25zdCBsaXN0ZW5lck9wdGlvbnMgPSB7IHBhc3NpdmU6IHRydWUgfTtcbiAgdXNlRXZlbnRMaXN0ZW5lcih0YXJnZXRFbGVtZW50LCBFVkVOVF9GT0NVU19JTiwgKCkgPT4gX2ZvY3VzZWQudmFsdWUgPSB0cnVlLCBsaXN0ZW5lck9wdGlvbnMpO1xuICB1c2VFdmVudExpc3RlbmVyKHRhcmdldEVsZW1lbnQsIEVWRU5UX0ZPQ1VTX09VVCwgKCkgPT4ge1xuICAgIHZhciBfYSwgX2IsIF9jO1xuICAgIHJldHVybiBfZm9jdXNlZC52YWx1ZSA9IChfYyA9IChfYiA9IChfYSA9IHRhcmdldEVsZW1lbnQudmFsdWUpID09IG51bGwgPyB2b2lkIDAgOiBfYS5tYXRjaGVzKSA9PSBudWxsID8gdm9pZCAwIDogX2IuY2FsbChfYSwgUFNFVURPX0NMQVNTX0ZPQ1VTX1dJVEhJTikpICE9IG51bGwgPyBfYyA6IGZhbHNlO1xuICB9LCBsaXN0ZW5lck9wdGlvbnMpO1xuICByZXR1cm4geyBmb2N1c2VkIH07XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VGcHMob3B0aW9ucykge1xuICB2YXIgX2E7XG4gIGNvbnN0IGZwcyA9IHNoYWxsb3dSZWYoMCk7XG4gIGlmICh0eXBlb2YgcGVyZm9ybWFuY2UgPT09IFwidW5kZWZpbmVkXCIpXG4gICAgcmV0dXJuIGZwcztcbiAgY29uc3QgZXZlcnkgPSAoX2EgPSBvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLmV2ZXJ5KSAhPSBudWxsID8gX2EgOiAxMDtcbiAgbGV0IGxhc3QgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgbGV0IHRpY2tzID0gMDtcbiAgdXNlUmFmRm4oKCkgPT4ge1xuICAgIHRpY2tzICs9IDE7XG4gICAgaWYgKHRpY2tzID49IGV2ZXJ5KSB7XG4gICAgICBjb25zdCBub3cgPSBwZXJmb3JtYW5jZS5ub3coKTtcbiAgICAgIGNvbnN0IGRpZmYgPSBub3cgLSBsYXN0O1xuICAgICAgZnBzLnZhbHVlID0gTWF0aC5yb3VuZCgxZTMgLyAoZGlmZiAvIHRpY2tzKSk7XG4gICAgICBsYXN0ID0gbm93O1xuICAgICAgdGlja3MgPSAwO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiBmcHM7XG59XG5cbmNvbnN0IGV2ZW50SGFuZGxlcnMgPSBbXG4gIFwiZnVsbHNjcmVlbmNoYW5nZVwiLFxuICBcIndlYmtpdGZ1bGxzY3JlZW5jaGFuZ2VcIixcbiAgXCJ3ZWJraXRlbmRmdWxsc2NyZWVuXCIsXG4gIFwibW96ZnVsbHNjcmVlbmNoYW5nZVwiLFxuICBcIk1TRnVsbHNjcmVlbkNoYW5nZVwiXG5dO1xuZnVuY3Rpb24gdXNlRnVsbHNjcmVlbih0YXJnZXQsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgZG9jdW1lbnQgPSBkZWZhdWx0RG9jdW1lbnQsXG4gICAgYXV0b0V4aXQgPSBmYWxzZVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgdGFyZ2V0UmVmID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIHZhciBfYTtcbiAgICByZXR1cm4gKF9hID0gdW5yZWZFbGVtZW50KHRhcmdldCkpICE9IG51bGwgPyBfYSA6IGRvY3VtZW50ID09IG51bGwgPyB2b2lkIDAgOiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQ7XG4gIH0pO1xuICBjb25zdCBpc0Z1bGxzY3JlZW4gPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgY29uc3QgcmVxdWVzdE1ldGhvZCA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICByZXR1cm4gW1xuICAgICAgXCJyZXF1ZXN0RnVsbHNjcmVlblwiLFxuICAgICAgXCJ3ZWJraXRSZXF1ZXN0RnVsbHNjcmVlblwiLFxuICAgICAgXCJ3ZWJraXRFbnRlckZ1bGxzY3JlZW5cIixcbiAgICAgIFwid2Via2l0RW50ZXJGdWxsU2NyZWVuXCIsXG4gICAgICBcIndlYmtpdFJlcXVlc3RGdWxsU2NyZWVuXCIsXG4gICAgICBcIm1velJlcXVlc3RGdWxsU2NyZWVuXCIsXG4gICAgICBcIm1zUmVxdWVzdEZ1bGxzY3JlZW5cIlxuICAgIF0uZmluZCgobSkgPT4gZG9jdW1lbnQgJiYgbSBpbiBkb2N1bWVudCB8fCB0YXJnZXRSZWYudmFsdWUgJiYgbSBpbiB0YXJnZXRSZWYudmFsdWUpO1xuICB9KTtcbiAgY29uc3QgZXhpdE1ldGhvZCA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICByZXR1cm4gW1xuICAgICAgXCJleGl0RnVsbHNjcmVlblwiLFxuICAgICAgXCJ3ZWJraXRFeGl0RnVsbHNjcmVlblwiLFxuICAgICAgXCJ3ZWJraXRFeGl0RnVsbFNjcmVlblwiLFxuICAgICAgXCJ3ZWJraXRDYW5jZWxGdWxsU2NyZWVuXCIsXG4gICAgICBcIm1vekNhbmNlbEZ1bGxTY3JlZW5cIixcbiAgICAgIFwibXNFeGl0RnVsbHNjcmVlblwiXG4gICAgXS5maW5kKChtKSA9PiBkb2N1bWVudCAmJiBtIGluIGRvY3VtZW50IHx8IHRhcmdldFJlZi52YWx1ZSAmJiBtIGluIHRhcmdldFJlZi52YWx1ZSk7XG4gIH0pO1xuICBjb25zdCBmdWxsc2NyZWVuRW5hYmxlZCA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICByZXR1cm4gW1xuICAgICAgXCJmdWxsU2NyZWVuXCIsXG4gICAgICBcIndlYmtpdElzRnVsbFNjcmVlblwiLFxuICAgICAgXCJ3ZWJraXREaXNwbGF5aW5nRnVsbHNjcmVlblwiLFxuICAgICAgXCJtb3pGdWxsU2NyZWVuXCIsXG4gICAgICBcIm1zRnVsbHNjcmVlbkVsZW1lbnRcIlxuICAgIF0uZmluZCgobSkgPT4gZG9jdW1lbnQgJiYgbSBpbiBkb2N1bWVudCB8fCB0YXJnZXRSZWYudmFsdWUgJiYgbSBpbiB0YXJnZXRSZWYudmFsdWUpO1xuICB9KTtcbiAgY29uc3QgZnVsbHNjcmVlbkVsZW1lbnRNZXRob2QgPSBbXG4gICAgXCJmdWxsc2NyZWVuRWxlbWVudFwiLFxuICAgIFwid2Via2l0RnVsbHNjcmVlbkVsZW1lbnRcIixcbiAgICBcIm1vekZ1bGxTY3JlZW5FbGVtZW50XCIsXG4gICAgXCJtc0Z1bGxzY3JlZW5FbGVtZW50XCJcbiAgXS5maW5kKChtKSA9PiBkb2N1bWVudCAmJiBtIGluIGRvY3VtZW50KTtcbiAgY29uc3QgaXNTdXBwb3J0ZWQgPSB1c2VTdXBwb3J0ZWQoKCkgPT4gdGFyZ2V0UmVmLnZhbHVlICYmIGRvY3VtZW50ICYmIHJlcXVlc3RNZXRob2QudmFsdWUgIT09IHZvaWQgMCAmJiBleGl0TWV0aG9kLnZhbHVlICE9PSB2b2lkIDAgJiYgZnVsbHNjcmVlbkVuYWJsZWQudmFsdWUgIT09IHZvaWQgMCk7XG4gIGNvbnN0IGlzQ3VycmVudEVsZW1lbnRGdWxsU2NyZWVuID0gKCkgPT4ge1xuICAgIGlmIChmdWxsc2NyZWVuRWxlbWVudE1ldGhvZClcbiAgICAgIHJldHVybiAoZG9jdW1lbnQgPT0gbnVsbCA/IHZvaWQgMCA6IGRvY3VtZW50W2Z1bGxzY3JlZW5FbGVtZW50TWV0aG9kXSkgPT09IHRhcmdldFJlZi52YWx1ZTtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH07XG4gIGNvbnN0IGlzRWxlbWVudEZ1bGxTY3JlZW4gPSAoKSA9PiB7XG4gICAgaWYgKGZ1bGxzY3JlZW5FbmFibGVkLnZhbHVlKSB7XG4gICAgICBpZiAoZG9jdW1lbnQgJiYgZG9jdW1lbnRbZnVsbHNjcmVlbkVuYWJsZWQudmFsdWVdICE9IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIGRvY3VtZW50W2Z1bGxzY3JlZW5FbmFibGVkLnZhbHVlXTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHRhcmdldDIgPSB0YXJnZXRSZWYudmFsdWU7XG4gICAgICAgIGlmICgodGFyZ2V0MiA9PSBudWxsID8gdm9pZCAwIDogdGFyZ2V0MltmdWxsc2NyZWVuRW5hYmxlZC52YWx1ZV0pICE9IG51bGwpIHtcbiAgICAgICAgICByZXR1cm4gQm9vbGVhbih0YXJnZXQyW2Z1bGxzY3JlZW5FbmFibGVkLnZhbHVlXSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9O1xuICBhc3luYyBmdW5jdGlvbiBleGl0KCkge1xuICAgIGlmICghaXNTdXBwb3J0ZWQudmFsdWUgfHwgIWlzRnVsbHNjcmVlbi52YWx1ZSlcbiAgICAgIHJldHVybjtcbiAgICBpZiAoZXhpdE1ldGhvZC52YWx1ZSkge1xuICAgICAgaWYgKChkb2N1bWVudCA9PSBudWxsID8gdm9pZCAwIDogZG9jdW1lbnRbZXhpdE1ldGhvZC52YWx1ZV0pICE9IG51bGwpIHtcbiAgICAgICAgYXdhaXQgZG9jdW1lbnRbZXhpdE1ldGhvZC52YWx1ZV0oKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHRhcmdldDIgPSB0YXJnZXRSZWYudmFsdWU7XG4gICAgICAgIGlmICgodGFyZ2V0MiA9PSBudWxsID8gdm9pZCAwIDogdGFyZ2V0MltleGl0TWV0aG9kLnZhbHVlXSkgIT0gbnVsbClcbiAgICAgICAgICBhd2FpdCB0YXJnZXQyW2V4aXRNZXRob2QudmFsdWVdKCk7XG4gICAgICB9XG4gICAgfVxuICAgIGlzRnVsbHNjcmVlbi52YWx1ZSA9IGZhbHNlO1xuICB9XG4gIGFzeW5jIGZ1bmN0aW9uIGVudGVyKCkge1xuICAgIGlmICghaXNTdXBwb3J0ZWQudmFsdWUgfHwgaXNGdWxsc2NyZWVuLnZhbHVlKVxuICAgICAgcmV0dXJuO1xuICAgIGlmIChpc0VsZW1lbnRGdWxsU2NyZWVuKCkpXG4gICAgICBhd2FpdCBleGl0KCk7XG4gICAgY29uc3QgdGFyZ2V0MiA9IHRhcmdldFJlZi52YWx1ZTtcbiAgICBpZiAocmVxdWVzdE1ldGhvZC52YWx1ZSAmJiAodGFyZ2V0MiA9PSBudWxsID8gdm9pZCAwIDogdGFyZ2V0MltyZXF1ZXN0TWV0aG9kLnZhbHVlXSkgIT0gbnVsbCkge1xuICAgICAgYXdhaXQgdGFyZ2V0MltyZXF1ZXN0TWV0aG9kLnZhbHVlXSgpO1xuICAgICAgaXNGdWxsc2NyZWVuLnZhbHVlID0gdHJ1ZTtcbiAgICB9XG4gIH1cbiAgYXN5bmMgZnVuY3Rpb24gdG9nZ2xlKCkge1xuICAgIGF3YWl0IChpc0Z1bGxzY3JlZW4udmFsdWUgPyBleGl0KCkgOiBlbnRlcigpKTtcbiAgfVxuICBjb25zdCBoYW5kbGVyQ2FsbGJhY2sgPSAoKSA9PiB7XG4gICAgY29uc3QgaXNFbGVtZW50RnVsbFNjcmVlblZhbHVlID0gaXNFbGVtZW50RnVsbFNjcmVlbigpO1xuICAgIGlmICghaXNFbGVtZW50RnVsbFNjcmVlblZhbHVlIHx8IGlzRWxlbWVudEZ1bGxTY3JlZW5WYWx1ZSAmJiBpc0N1cnJlbnRFbGVtZW50RnVsbFNjcmVlbigpKVxuICAgICAgaXNGdWxsc2NyZWVuLnZhbHVlID0gaXNFbGVtZW50RnVsbFNjcmVlblZhbHVlO1xuICB9O1xuICBjb25zdCBsaXN0ZW5lck9wdGlvbnMgPSB7IGNhcHR1cmU6IGZhbHNlLCBwYXNzaXZlOiB0cnVlIH07XG4gIHVzZUV2ZW50TGlzdGVuZXIoZG9jdW1lbnQsIGV2ZW50SGFuZGxlcnMsIGhhbmRsZXJDYWxsYmFjaywgbGlzdGVuZXJPcHRpb25zKTtcbiAgdXNlRXZlbnRMaXN0ZW5lcigoKSA9PiB1bnJlZkVsZW1lbnQodGFyZ2V0UmVmKSwgZXZlbnRIYW5kbGVycywgaGFuZGxlckNhbGxiYWNrLCBsaXN0ZW5lck9wdGlvbnMpO1xuICB0cnlPbk1vdW50ZWQoaGFuZGxlckNhbGxiYWNrLCBmYWxzZSk7XG4gIGlmIChhdXRvRXhpdClcbiAgICB0cnlPblNjb3BlRGlzcG9zZShleGl0KTtcbiAgcmV0dXJuIHtcbiAgICBpc1N1cHBvcnRlZCxcbiAgICBpc0Z1bGxzY3JlZW4sXG4gICAgZW50ZXIsXG4gICAgZXhpdCxcbiAgICB0b2dnbGVcbiAgfTtcbn1cblxuZnVuY3Rpb24gbWFwR2FtZXBhZFRvWGJveDM2MENvbnRyb2xsZXIoZ2FtZXBhZCkge1xuICByZXR1cm4gY29tcHV0ZWQoKCkgPT4ge1xuICAgIGlmIChnYW1lcGFkLnZhbHVlKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBidXR0b25zOiB7XG4gICAgICAgICAgYTogZ2FtZXBhZC52YWx1ZS5idXR0b25zWzBdLFxuICAgICAgICAgIGI6IGdhbWVwYWQudmFsdWUuYnV0dG9uc1sxXSxcbiAgICAgICAgICB4OiBnYW1lcGFkLnZhbHVlLmJ1dHRvbnNbMl0sXG4gICAgICAgICAgeTogZ2FtZXBhZC52YWx1ZS5idXR0b25zWzNdXG4gICAgICAgIH0sXG4gICAgICAgIGJ1bXBlcjoge1xuICAgICAgICAgIGxlZnQ6IGdhbWVwYWQudmFsdWUuYnV0dG9uc1s0XSxcbiAgICAgICAgICByaWdodDogZ2FtZXBhZC52YWx1ZS5idXR0b25zWzVdXG4gICAgICAgIH0sXG4gICAgICAgIHRyaWdnZXJzOiB7XG4gICAgICAgICAgbGVmdDogZ2FtZXBhZC52YWx1ZS5idXR0b25zWzZdLFxuICAgICAgICAgIHJpZ2h0OiBnYW1lcGFkLnZhbHVlLmJ1dHRvbnNbN11cbiAgICAgICAgfSxcbiAgICAgICAgc3RpY2s6IHtcbiAgICAgICAgICBsZWZ0OiB7XG4gICAgICAgICAgICBob3Jpem9udGFsOiBnYW1lcGFkLnZhbHVlLmF4ZXNbMF0sXG4gICAgICAgICAgICB2ZXJ0aWNhbDogZ2FtZXBhZC52YWx1ZS5heGVzWzFdLFxuICAgICAgICAgICAgYnV0dG9uOiBnYW1lcGFkLnZhbHVlLmJ1dHRvbnNbMTBdXG4gICAgICAgICAgfSxcbiAgICAgICAgICByaWdodDoge1xuICAgICAgICAgICAgaG9yaXpvbnRhbDogZ2FtZXBhZC52YWx1ZS5heGVzWzJdLFxuICAgICAgICAgICAgdmVydGljYWw6IGdhbWVwYWQudmFsdWUuYXhlc1szXSxcbiAgICAgICAgICAgIGJ1dHRvbjogZ2FtZXBhZC52YWx1ZS5idXR0b25zWzExXVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgZHBhZDoge1xuICAgICAgICAgIHVwOiBnYW1lcGFkLnZhbHVlLmJ1dHRvbnNbMTJdLFxuICAgICAgICAgIGRvd246IGdhbWVwYWQudmFsdWUuYnV0dG9uc1sxM10sXG4gICAgICAgICAgbGVmdDogZ2FtZXBhZC52YWx1ZS5idXR0b25zWzE0XSxcbiAgICAgICAgICByaWdodDogZ2FtZXBhZC52YWx1ZS5idXR0b25zWzE1XVxuICAgICAgICB9LFxuICAgICAgICBiYWNrOiBnYW1lcGFkLnZhbHVlLmJ1dHRvbnNbOF0sXG4gICAgICAgIHN0YXJ0OiBnYW1lcGFkLnZhbHVlLmJ1dHRvbnNbOV1cbiAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9KTtcbn1cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VHYW1lcGFkKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgbmF2aWdhdG9yID0gZGVmYXVsdE5hdmlnYXRvclxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgaXNTdXBwb3J0ZWQgPSB1c2VTdXBwb3J0ZWQoKCkgPT4gbmF2aWdhdG9yICYmIFwiZ2V0R2FtZXBhZHNcIiBpbiBuYXZpZ2F0b3IpO1xuICBjb25zdCBnYW1lcGFkcyA9IHJlZihbXSk7XG4gIGNvbnN0IG9uQ29ubmVjdGVkSG9vayA9IGNyZWF0ZUV2ZW50SG9vaygpO1xuICBjb25zdCBvbkRpc2Nvbm5lY3RlZEhvb2sgPSBjcmVhdGVFdmVudEhvb2soKTtcbiAgY29uc3Qgc3RhdGVGcm9tR2FtZXBhZCA9IChnYW1lcGFkKSA9PiB7XG4gICAgY29uc3QgaGFwdGljQWN0dWF0b3JzID0gW107XG4gICAgY29uc3QgdmlicmF0aW9uQWN0dWF0b3IgPSBcInZpYnJhdGlvbkFjdHVhdG9yXCIgaW4gZ2FtZXBhZCA/IGdhbWVwYWQudmlicmF0aW9uQWN0dWF0b3IgOiBudWxsO1xuICAgIGlmICh2aWJyYXRpb25BY3R1YXRvcilcbiAgICAgIGhhcHRpY0FjdHVhdG9ycy5wdXNoKHZpYnJhdGlvbkFjdHVhdG9yKTtcbiAgICBpZiAoZ2FtZXBhZC5oYXB0aWNBY3R1YXRvcnMpXG4gICAgICBoYXB0aWNBY3R1YXRvcnMucHVzaCguLi5nYW1lcGFkLmhhcHRpY0FjdHVhdG9ycyk7XG4gICAgcmV0dXJuIHtcbiAgICAgIGlkOiBnYW1lcGFkLmlkLFxuICAgICAgaW5kZXg6IGdhbWVwYWQuaW5kZXgsXG4gICAgICBjb25uZWN0ZWQ6IGdhbWVwYWQuY29ubmVjdGVkLFxuICAgICAgbWFwcGluZzogZ2FtZXBhZC5tYXBwaW5nLFxuICAgICAgdGltZXN0YW1wOiBnYW1lcGFkLnRpbWVzdGFtcCxcbiAgICAgIHZpYnJhdGlvbkFjdHVhdG9yOiBnYW1lcGFkLnZpYnJhdGlvbkFjdHVhdG9yLFxuICAgICAgaGFwdGljQWN0dWF0b3JzLFxuICAgICAgYXhlczogZ2FtZXBhZC5heGVzLm1hcCgoYXhlcykgPT4gYXhlcyksXG4gICAgICBidXR0b25zOiBnYW1lcGFkLmJ1dHRvbnMubWFwKChidXR0b24pID0+ICh7IHByZXNzZWQ6IGJ1dHRvbi5wcmVzc2VkLCB0b3VjaGVkOiBidXR0b24udG91Y2hlZCwgdmFsdWU6IGJ1dHRvbi52YWx1ZSB9KSlcbiAgICB9O1xuICB9O1xuICBjb25zdCB1cGRhdGVHYW1lcGFkU3RhdGUgPSAoKSA9PiB7XG4gICAgY29uc3QgX2dhbWVwYWRzID0gKG5hdmlnYXRvciA9PSBudWxsID8gdm9pZCAwIDogbmF2aWdhdG9yLmdldEdhbWVwYWRzKCkpIHx8IFtdO1xuICAgIGZvciAoY29uc3QgZ2FtZXBhZCBvZiBfZ2FtZXBhZHMpIHtcbiAgICAgIGlmIChnYW1lcGFkICYmIGdhbWVwYWRzLnZhbHVlW2dhbWVwYWQuaW5kZXhdKVxuICAgICAgICBnYW1lcGFkcy52YWx1ZVtnYW1lcGFkLmluZGV4XSA9IHN0YXRlRnJvbUdhbWVwYWQoZ2FtZXBhZCk7XG4gICAgfVxuICB9O1xuICBjb25zdCB7IGlzQWN0aXZlLCBwYXVzZSwgcmVzdW1lIH0gPSB1c2VSYWZGbih1cGRhdGVHYW1lcGFkU3RhdGUpO1xuICBjb25zdCBvbkdhbWVwYWRDb25uZWN0ZWQgPSAoZ2FtZXBhZCkgPT4ge1xuICAgIGlmICghZ2FtZXBhZHMudmFsdWUuc29tZSgoeyBpbmRleCB9KSA9PiBpbmRleCA9PT0gZ2FtZXBhZC5pbmRleCkpIHtcbiAgICAgIGdhbWVwYWRzLnZhbHVlLnB1c2goc3RhdGVGcm9tR2FtZXBhZChnYW1lcGFkKSk7XG4gICAgICBvbkNvbm5lY3RlZEhvb2sudHJpZ2dlcihnYW1lcGFkLmluZGV4KTtcbiAgICB9XG4gICAgcmVzdW1lKCk7XG4gIH07XG4gIGNvbnN0IG9uR2FtZXBhZERpc2Nvbm5lY3RlZCA9IChnYW1lcGFkKSA9PiB7XG4gICAgZ2FtZXBhZHMudmFsdWUgPSBnYW1lcGFkcy52YWx1ZS5maWx0ZXIoKHgpID0+IHguaW5kZXggIT09IGdhbWVwYWQuaW5kZXgpO1xuICAgIG9uRGlzY29ubmVjdGVkSG9vay50cmlnZ2VyKGdhbWVwYWQuaW5kZXgpO1xuICB9O1xuICBjb25zdCBsaXN0ZW5lck9wdGlvbnMgPSB7IHBhc3NpdmU6IHRydWUgfTtcbiAgdXNlRXZlbnRMaXN0ZW5lcihcImdhbWVwYWRjb25uZWN0ZWRcIiwgKGUpID0+IG9uR2FtZXBhZENvbm5lY3RlZChlLmdhbWVwYWQpLCBsaXN0ZW5lck9wdGlvbnMpO1xuICB1c2VFdmVudExpc3RlbmVyKFwiZ2FtZXBhZGRpc2Nvbm5lY3RlZFwiLCAoZSkgPT4gb25HYW1lcGFkRGlzY29ubmVjdGVkKGUuZ2FtZXBhZCksIGxpc3RlbmVyT3B0aW9ucyk7XG4gIHRyeU9uTW91bnRlZCgoKSA9PiB7XG4gICAgY29uc3QgX2dhbWVwYWRzID0gKG5hdmlnYXRvciA9PSBudWxsID8gdm9pZCAwIDogbmF2aWdhdG9yLmdldEdhbWVwYWRzKCkpIHx8IFtdO1xuICAgIGZvciAoY29uc3QgZ2FtZXBhZCBvZiBfZ2FtZXBhZHMpIHtcbiAgICAgIGlmIChnYW1lcGFkICYmIGdhbWVwYWRzLnZhbHVlW2dhbWVwYWQuaW5kZXhdKVxuICAgICAgICBvbkdhbWVwYWRDb25uZWN0ZWQoZ2FtZXBhZCk7XG4gICAgfVxuICB9KTtcbiAgcGF1c2UoKTtcbiAgcmV0dXJuIHtcbiAgICBpc1N1cHBvcnRlZCxcbiAgICBvbkNvbm5lY3RlZDogb25Db25uZWN0ZWRIb29rLm9uLFxuICAgIG9uRGlzY29ubmVjdGVkOiBvbkRpc2Nvbm5lY3RlZEhvb2sub24sXG4gICAgZ2FtZXBhZHMsXG4gICAgcGF1c2UsXG4gICAgcmVzdW1lLFxuICAgIGlzQWN0aXZlXG4gIH07XG59XG5cbmZ1bmN0aW9uIHVzZUdlb2xvY2F0aW9uKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgZW5hYmxlSGlnaEFjY3VyYWN5ID0gdHJ1ZSxcbiAgICBtYXhpbXVtQWdlID0gM2U0LFxuICAgIHRpbWVvdXQgPSAyN2UzLFxuICAgIG5hdmlnYXRvciA9IGRlZmF1bHROYXZpZ2F0b3IsXG4gICAgaW1tZWRpYXRlID0gdHJ1ZVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgaXNTdXBwb3J0ZWQgPSB1c2VTdXBwb3J0ZWQoKCkgPT4gbmF2aWdhdG9yICYmIFwiZ2VvbG9jYXRpb25cIiBpbiBuYXZpZ2F0b3IpO1xuICBjb25zdCBsb2NhdGVkQXQgPSBzaGFsbG93UmVmKG51bGwpO1xuICBjb25zdCBlcnJvciA9IHNoYWxsb3dSZWYobnVsbCk7XG4gIGNvbnN0IGNvb3JkcyA9IHJlZih7XG4gICAgYWNjdXJhY3k6IDAsXG4gICAgbGF0aXR1ZGU6IE51bWJlci5QT1NJVElWRV9JTkZJTklUWSxcbiAgICBsb25naXR1ZGU6IE51bWJlci5QT1NJVElWRV9JTkZJTklUWSxcbiAgICBhbHRpdHVkZTogbnVsbCxcbiAgICBhbHRpdHVkZUFjY3VyYWN5OiBudWxsLFxuICAgIGhlYWRpbmc6IG51bGwsXG4gICAgc3BlZWQ6IG51bGxcbiAgfSk7XG4gIGZ1bmN0aW9uIHVwZGF0ZVBvc2l0aW9uKHBvc2l0aW9uKSB7XG4gICAgbG9jYXRlZEF0LnZhbHVlID0gcG9zaXRpb24udGltZXN0YW1wO1xuICAgIGNvb3Jkcy52YWx1ZSA9IHBvc2l0aW9uLmNvb3JkcztcbiAgICBlcnJvci52YWx1ZSA9IG51bGw7XG4gIH1cbiAgbGV0IHdhdGNoZXI7XG4gIGZ1bmN0aW9uIHJlc3VtZSgpIHtcbiAgICBpZiAoaXNTdXBwb3J0ZWQudmFsdWUpIHtcbiAgICAgIHdhdGNoZXIgPSBuYXZpZ2F0b3IuZ2VvbG9jYXRpb24ud2F0Y2hQb3NpdGlvbihcbiAgICAgICAgdXBkYXRlUG9zaXRpb24sXG4gICAgICAgIChlcnIpID0+IGVycm9yLnZhbHVlID0gZXJyLFxuICAgICAgICB7XG4gICAgICAgICAgZW5hYmxlSGlnaEFjY3VyYWN5LFxuICAgICAgICAgIG1heGltdW1BZ2UsXG4gICAgICAgICAgdGltZW91dFxuICAgICAgICB9XG4gICAgICApO1xuICAgIH1cbiAgfVxuICBpZiAoaW1tZWRpYXRlKVxuICAgIHJlc3VtZSgpO1xuICBmdW5jdGlvbiBwYXVzZSgpIHtcbiAgICBpZiAod2F0Y2hlciAmJiBuYXZpZ2F0b3IpXG4gICAgICBuYXZpZ2F0b3IuZ2VvbG9jYXRpb24uY2xlYXJXYXRjaCh3YXRjaGVyKTtcbiAgfVxuICB0cnlPblNjb3BlRGlzcG9zZSgoKSA9PiB7XG4gICAgcGF1c2UoKTtcbiAgfSk7XG4gIHJldHVybiB7XG4gICAgaXNTdXBwb3J0ZWQsXG4gICAgY29vcmRzLFxuICAgIGxvY2F0ZWRBdCxcbiAgICBlcnJvcixcbiAgICByZXN1bWUsXG4gICAgcGF1c2VcbiAgfTtcbn1cblxuY29uc3QgZGVmYXVsdEV2ZW50cyQxID0gW1wibW91c2Vtb3ZlXCIsIFwibW91c2Vkb3duXCIsIFwicmVzaXplXCIsIFwia2V5ZG93blwiLCBcInRvdWNoc3RhcnRcIiwgXCJ3aGVlbFwiXTtcbmNvbnN0IG9uZU1pbnV0ZSA9IDZlNDtcbmZ1bmN0aW9uIHVzZUlkbGUodGltZW91dCA9IG9uZU1pbnV0ZSwgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBpbml0aWFsU3RhdGUgPSBmYWxzZSxcbiAgICBsaXN0ZW5Gb3JWaXNpYmlsaXR5Q2hhbmdlID0gdHJ1ZSxcbiAgICBldmVudHMgPSBkZWZhdWx0RXZlbnRzJDEsXG4gICAgd2luZG93ID0gZGVmYXVsdFdpbmRvdyxcbiAgICBldmVudEZpbHRlciA9IHRocm90dGxlRmlsdGVyKDUwKVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgaWRsZSA9IHNoYWxsb3dSZWYoaW5pdGlhbFN0YXRlKTtcbiAgY29uc3QgbGFzdEFjdGl2ZSA9IHNoYWxsb3dSZWYodGltZXN0YW1wKCkpO1xuICBsZXQgdGltZXI7XG4gIGNvbnN0IHJlc2V0ID0gKCkgPT4ge1xuICAgIGlkbGUudmFsdWUgPSBmYWxzZTtcbiAgICBjbGVhclRpbWVvdXQodGltZXIpO1xuICAgIHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiBpZGxlLnZhbHVlID0gdHJ1ZSwgdGltZW91dCk7XG4gIH07XG4gIGNvbnN0IG9uRXZlbnQgPSBjcmVhdGVGaWx0ZXJXcmFwcGVyKFxuICAgIGV2ZW50RmlsdGVyLFxuICAgICgpID0+IHtcbiAgICAgIGxhc3RBY3RpdmUudmFsdWUgPSB0aW1lc3RhbXAoKTtcbiAgICAgIHJlc2V0KCk7XG4gICAgfVxuICApO1xuICBpZiAod2luZG93KSB7XG4gICAgY29uc3QgZG9jdW1lbnQgPSB3aW5kb3cuZG9jdW1lbnQ7XG4gICAgY29uc3QgbGlzdGVuZXJPcHRpb25zID0geyBwYXNzaXZlOiB0cnVlIH07XG4gICAgZm9yIChjb25zdCBldmVudCBvZiBldmVudHMpXG4gICAgICB1c2VFdmVudExpc3RlbmVyKHdpbmRvdywgZXZlbnQsIG9uRXZlbnQsIGxpc3RlbmVyT3B0aW9ucyk7XG4gICAgaWYgKGxpc3RlbkZvclZpc2liaWxpdHlDaGFuZ2UpIHtcbiAgICAgIHVzZUV2ZW50TGlzdGVuZXIoZG9jdW1lbnQsIFwidmlzaWJpbGl0eWNoYW5nZVwiLCAoKSA9PiB7XG4gICAgICAgIGlmICghZG9jdW1lbnQuaGlkZGVuKVxuICAgICAgICAgIG9uRXZlbnQoKTtcbiAgICAgIH0sIGxpc3RlbmVyT3B0aW9ucyk7XG4gICAgfVxuICAgIGlmICghaW5pdGlhbFN0YXRlKVxuICAgICAgcmVzZXQoKTtcbiAgfVxuICByZXR1cm4ge1xuICAgIGlkbGUsXG4gICAgbGFzdEFjdGl2ZSxcbiAgICByZXNldFxuICB9O1xufVxuXG5hc3luYyBmdW5jdGlvbiBsb2FkSW1hZ2Uob3B0aW9ucykge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIGNvbnN0IGltZyA9IG5ldyBJbWFnZSgpO1xuICAgIGNvbnN0IHsgc3JjLCBzcmNzZXQsIHNpemVzLCBjbGFzczogY2xhenosIGxvYWRpbmcsIGNyb3Nzb3JpZ2luLCByZWZlcnJlclBvbGljeSwgd2lkdGgsIGhlaWdodCwgZGVjb2RpbmcsIGZldGNoUHJpb3JpdHksIGlzbWFwLCB1c2VtYXAgfSA9IG9wdGlvbnM7XG4gICAgaW1nLnNyYyA9IHNyYztcbiAgICBpZiAoc3Jjc2V0ICE9IG51bGwpXG4gICAgICBpbWcuc3Jjc2V0ID0gc3Jjc2V0O1xuICAgIGlmIChzaXplcyAhPSBudWxsKVxuICAgICAgaW1nLnNpemVzID0gc2l6ZXM7XG4gICAgaWYgKGNsYXp6ICE9IG51bGwpXG4gICAgICBpbWcuY2xhc3NOYW1lID0gY2xheno7XG4gICAgaWYgKGxvYWRpbmcgIT0gbnVsbClcbiAgICAgIGltZy5sb2FkaW5nID0gbG9hZGluZztcbiAgICBpZiAoY3Jvc3NvcmlnaW4gIT0gbnVsbClcbiAgICAgIGltZy5jcm9zc09yaWdpbiA9IGNyb3Nzb3JpZ2luO1xuICAgIGlmIChyZWZlcnJlclBvbGljeSAhPSBudWxsKVxuICAgICAgaW1nLnJlZmVycmVyUG9saWN5ID0gcmVmZXJyZXJQb2xpY3k7XG4gICAgaWYgKHdpZHRoICE9IG51bGwpXG4gICAgICBpbWcud2lkdGggPSB3aWR0aDtcbiAgICBpZiAoaGVpZ2h0ICE9IG51bGwpXG4gICAgICBpbWcuaGVpZ2h0ID0gaGVpZ2h0O1xuICAgIGlmIChkZWNvZGluZyAhPSBudWxsKVxuICAgICAgaW1nLmRlY29kaW5nID0gZGVjb2Rpbmc7XG4gICAgaWYgKGZldGNoUHJpb3JpdHkgIT0gbnVsbClcbiAgICAgIGltZy5mZXRjaFByaW9yaXR5ID0gZmV0Y2hQcmlvcml0eTtcbiAgICBpZiAoaXNtYXAgIT0gbnVsbClcbiAgICAgIGltZy5pc01hcCA9IGlzbWFwO1xuICAgIGlmICh1c2VtYXAgIT0gbnVsbClcbiAgICAgIGltZy51c2VNYXAgPSB1c2VtYXA7XG4gICAgaW1nLm9ubG9hZCA9ICgpID0+IHJlc29sdmUoaW1nKTtcbiAgICBpbWcub25lcnJvciA9IHJlamVjdDtcbiAgfSk7XG59XG5mdW5jdGlvbiB1c2VJbWFnZShvcHRpb25zLCBhc3luY1N0YXRlT3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHN0YXRlID0gdXNlQXN5bmNTdGF0ZShcbiAgICAoKSA9PiBsb2FkSW1hZ2UodG9WYWx1ZShvcHRpb25zKSksXG4gICAgdm9pZCAwLFxuICAgIHtcbiAgICAgIHJlc2V0T25FeGVjdXRlOiB0cnVlLFxuICAgICAgLi4uYXN5bmNTdGF0ZU9wdGlvbnNcbiAgICB9XG4gICk7XG4gIHdhdGNoKFxuICAgICgpID0+IHRvVmFsdWUob3B0aW9ucyksXG4gICAgKCkgPT4gc3RhdGUuZXhlY3V0ZShhc3luY1N0YXRlT3B0aW9ucy5kZWxheSksXG4gICAgeyBkZWVwOiB0cnVlIH1cbiAgKTtcbiAgcmV0dXJuIHN0YXRlO1xufVxuXG5mdW5jdGlvbiByZXNvbHZlRWxlbWVudChlbCkge1xuICBpZiAodHlwZW9mIFdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiAmJiBlbCBpbnN0YW5jZW9mIFdpbmRvdylcbiAgICByZXR1cm4gZWwuZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50O1xuICBpZiAodHlwZW9mIERvY3VtZW50ICE9PSBcInVuZGVmaW5lZFwiICYmIGVsIGluc3RhbmNlb2YgRG9jdW1lbnQpXG4gICAgcmV0dXJuIGVsLmRvY3VtZW50RWxlbWVudDtcbiAgcmV0dXJuIGVsO1xufVxuXG5jb25zdCBBUlJJVkVEX1NUQVRFX1RIUkVTSE9MRF9QSVhFTFMgPSAxO1xuZnVuY3Rpb24gdXNlU2Nyb2xsKGVsZW1lbnQsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgdGhyb3R0bGUgPSAwLFxuICAgIGlkbGUgPSAyMDAsXG4gICAgb25TdG9wID0gbm9vcCxcbiAgICBvblNjcm9sbCA9IG5vb3AsXG4gICAgb2Zmc2V0ID0ge1xuICAgICAgbGVmdDogMCxcbiAgICAgIHJpZ2h0OiAwLFxuICAgICAgdG9wOiAwLFxuICAgICAgYm90dG9tOiAwXG4gICAgfSxcbiAgICBvYnNlcnZlOiBfb2JzZXJ2ZSA9IHtcbiAgICAgIG11dGF0aW9uOiBmYWxzZVxuICAgIH0sXG4gICAgZXZlbnRMaXN0ZW5lck9wdGlvbnMgPSB7XG4gICAgICBjYXB0dXJlOiBmYWxzZSxcbiAgICAgIHBhc3NpdmU6IHRydWVcbiAgICB9LFxuICAgIGJlaGF2aW9yID0gXCJhdXRvXCIsXG4gICAgd2luZG93ID0gZGVmYXVsdFdpbmRvdyxcbiAgICBvbkVycm9yID0gKGUpID0+IHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgfVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3Qgb2JzZXJ2ZSA9IHR5cGVvZiBfb2JzZXJ2ZSA9PT0gXCJib29sZWFuXCIgPyB7XG4gICAgbXV0YXRpb246IF9vYnNlcnZlXG4gIH0gOiBfb2JzZXJ2ZTtcbiAgY29uc3QgaW50ZXJuYWxYID0gc2hhbGxvd1JlZigwKTtcbiAgY29uc3QgaW50ZXJuYWxZID0gc2hhbGxvd1JlZigwKTtcbiAgY29uc3QgeCA9IGNvbXB1dGVkKHtcbiAgICBnZXQoKSB7XG4gICAgICByZXR1cm4gaW50ZXJuYWxYLnZhbHVlO1xuICAgIH0sXG4gICAgc2V0KHgyKSB7XG4gICAgICBzY3JvbGxUbyh4Miwgdm9pZCAwKTtcbiAgICB9XG4gIH0pO1xuICBjb25zdCB5ID0gY29tcHV0ZWQoe1xuICAgIGdldCgpIHtcbiAgICAgIHJldHVybiBpbnRlcm5hbFkudmFsdWU7XG4gICAgfSxcbiAgICBzZXQoeTIpIHtcbiAgICAgIHNjcm9sbFRvKHZvaWQgMCwgeTIpO1xuICAgIH1cbiAgfSk7XG4gIGZ1bmN0aW9uIHNjcm9sbFRvKF94LCBfeSkge1xuICAgIHZhciBfYSwgX2IsIF9jLCBfZDtcbiAgICBpZiAoIXdpbmRvdylcbiAgICAgIHJldHVybjtcbiAgICBjb25zdCBfZWxlbWVudCA9IHRvVmFsdWUoZWxlbWVudCk7XG4gICAgaWYgKCFfZWxlbWVudClcbiAgICAgIHJldHVybjtcbiAgICAoX2MgPSBfZWxlbWVudCBpbnN0YW5jZW9mIERvY3VtZW50ID8gd2luZG93LmRvY3VtZW50LmJvZHkgOiBfZWxlbWVudCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9jLnNjcm9sbFRvKHtcbiAgICAgIHRvcDogKF9hID0gdG9WYWx1ZShfeSkpICE9IG51bGwgPyBfYSA6IHkudmFsdWUsXG4gICAgICBsZWZ0OiAoX2IgPSB0b1ZhbHVlKF94KSkgIT0gbnVsbCA/IF9iIDogeC52YWx1ZSxcbiAgICAgIGJlaGF2aW9yOiB0b1ZhbHVlKGJlaGF2aW9yKVxuICAgIH0pO1xuICAgIGNvbnN0IHNjcm9sbENvbnRhaW5lciA9ICgoX2QgPSBfZWxlbWVudCA9PSBudWxsID8gdm9pZCAwIDogX2VsZW1lbnQuZG9jdW1lbnQpID09IG51bGwgPyB2b2lkIDAgOiBfZC5kb2N1bWVudEVsZW1lbnQpIHx8IChfZWxlbWVudCA9PSBudWxsID8gdm9pZCAwIDogX2VsZW1lbnQuZG9jdW1lbnRFbGVtZW50KSB8fCBfZWxlbWVudDtcbiAgICBpZiAoeCAhPSBudWxsKVxuICAgICAgaW50ZXJuYWxYLnZhbHVlID0gc2Nyb2xsQ29udGFpbmVyLnNjcm9sbExlZnQ7XG4gICAgaWYgKHkgIT0gbnVsbClcbiAgICAgIGludGVybmFsWS52YWx1ZSA9IHNjcm9sbENvbnRhaW5lci5zY3JvbGxUb3A7XG4gIH1cbiAgY29uc3QgaXNTY3JvbGxpbmcgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgY29uc3QgYXJyaXZlZFN0YXRlID0gcmVhY3RpdmUoe1xuICAgIGxlZnQ6IHRydWUsXG4gICAgcmlnaHQ6IGZhbHNlLFxuICAgIHRvcDogdHJ1ZSxcbiAgICBib3R0b206IGZhbHNlXG4gIH0pO1xuICBjb25zdCBkaXJlY3Rpb25zID0gcmVhY3RpdmUoe1xuICAgIGxlZnQ6IGZhbHNlLFxuICAgIHJpZ2h0OiBmYWxzZSxcbiAgICB0b3A6IGZhbHNlLFxuICAgIGJvdHRvbTogZmFsc2VcbiAgfSk7XG4gIGNvbnN0IG9uU2Nyb2xsRW5kID0gKGUpID0+IHtcbiAgICBpZiAoIWlzU2Nyb2xsaW5nLnZhbHVlKVxuICAgICAgcmV0dXJuO1xuICAgIGlzU2Nyb2xsaW5nLnZhbHVlID0gZmFsc2U7XG4gICAgZGlyZWN0aW9ucy5sZWZ0ID0gZmFsc2U7XG4gICAgZGlyZWN0aW9ucy5yaWdodCA9IGZhbHNlO1xuICAgIGRpcmVjdGlvbnMudG9wID0gZmFsc2U7XG4gICAgZGlyZWN0aW9ucy5ib3R0b20gPSBmYWxzZTtcbiAgICBvblN0b3AoZSk7XG4gIH07XG4gIGNvbnN0IG9uU2Nyb2xsRW5kRGVib3VuY2VkID0gdXNlRGVib3VuY2VGbihvblNjcm9sbEVuZCwgdGhyb3R0bGUgKyBpZGxlKTtcbiAgY29uc3Qgc2V0QXJyaXZlZFN0YXRlID0gKHRhcmdldCkgPT4ge1xuICAgIHZhciBfYTtcbiAgICBpZiAoIXdpbmRvdylcbiAgICAgIHJldHVybjtcbiAgICBjb25zdCBlbCA9ICgoX2EgPSB0YXJnZXQgPT0gbnVsbCA/IHZvaWQgMCA6IHRhcmdldC5kb2N1bWVudCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLmRvY3VtZW50RWxlbWVudCkgfHwgKHRhcmdldCA9PSBudWxsID8gdm9pZCAwIDogdGFyZ2V0LmRvY3VtZW50RWxlbWVudCkgfHwgdW5yZWZFbGVtZW50KHRhcmdldCk7XG4gICAgY29uc3QgeyBkaXNwbGF5LCBmbGV4RGlyZWN0aW9uLCBkaXJlY3Rpb24gfSA9IGdldENvbXB1dGVkU3R5bGUoZWwpO1xuICAgIGNvbnN0IGRpcmVjdGlvbk11bHRpcGxlciA9IGRpcmVjdGlvbiA9PT0gXCJydGxcIiA/IC0xIDogMTtcbiAgICBjb25zdCBzY3JvbGxMZWZ0ID0gZWwuc2Nyb2xsTGVmdDtcbiAgICBkaXJlY3Rpb25zLmxlZnQgPSBzY3JvbGxMZWZ0IDwgaW50ZXJuYWxYLnZhbHVlO1xuICAgIGRpcmVjdGlvbnMucmlnaHQgPSBzY3JvbGxMZWZ0ID4gaW50ZXJuYWxYLnZhbHVlO1xuICAgIGNvbnN0IGxlZnQgPSBNYXRoLmFicyhzY3JvbGxMZWZ0ICogZGlyZWN0aW9uTXVsdGlwbGVyKSA8PSAob2Zmc2V0LmxlZnQgfHwgMCk7XG4gICAgY29uc3QgcmlnaHQgPSBNYXRoLmFicyhzY3JvbGxMZWZ0ICogZGlyZWN0aW9uTXVsdGlwbGVyKSArIGVsLmNsaWVudFdpZHRoID49IGVsLnNjcm9sbFdpZHRoIC0gKG9mZnNldC5yaWdodCB8fCAwKSAtIEFSUklWRURfU1RBVEVfVEhSRVNIT0xEX1BJWEVMUztcbiAgICBpZiAoZGlzcGxheSA9PT0gXCJmbGV4XCIgJiYgZmxleERpcmVjdGlvbiA9PT0gXCJyb3ctcmV2ZXJzZVwiKSB7XG4gICAgICBhcnJpdmVkU3RhdGUubGVmdCA9IHJpZ2h0O1xuICAgICAgYXJyaXZlZFN0YXRlLnJpZ2h0ID0gbGVmdDtcbiAgICB9IGVsc2Uge1xuICAgICAgYXJyaXZlZFN0YXRlLmxlZnQgPSBsZWZ0O1xuICAgICAgYXJyaXZlZFN0YXRlLnJpZ2h0ID0gcmlnaHQ7XG4gICAgfVxuICAgIGludGVybmFsWC52YWx1ZSA9IHNjcm9sbExlZnQ7XG4gICAgbGV0IHNjcm9sbFRvcCA9IGVsLnNjcm9sbFRvcDtcbiAgICBpZiAodGFyZ2V0ID09PSB3aW5kb3cuZG9jdW1lbnQgJiYgIXNjcm9sbFRvcClcbiAgICAgIHNjcm9sbFRvcCA9IHdpbmRvdy5kb2N1bWVudC5ib2R5LnNjcm9sbFRvcDtcbiAgICBkaXJlY3Rpb25zLnRvcCA9IHNjcm9sbFRvcCA8IGludGVybmFsWS52YWx1ZTtcbiAgICBkaXJlY3Rpb25zLmJvdHRvbSA9IHNjcm9sbFRvcCA+IGludGVybmFsWS52YWx1ZTtcbiAgICBjb25zdCB0b3AgPSBNYXRoLmFicyhzY3JvbGxUb3ApIDw9IChvZmZzZXQudG9wIHx8IDApO1xuICAgIGNvbnN0IGJvdHRvbSA9IE1hdGguYWJzKHNjcm9sbFRvcCkgKyBlbC5jbGllbnRIZWlnaHQgPj0gZWwuc2Nyb2xsSGVpZ2h0IC0gKG9mZnNldC5ib3R0b20gfHwgMCkgLSBBUlJJVkVEX1NUQVRFX1RIUkVTSE9MRF9QSVhFTFM7XG4gICAgaWYgKGRpc3BsYXkgPT09IFwiZmxleFwiICYmIGZsZXhEaXJlY3Rpb24gPT09IFwiY29sdW1uLXJldmVyc2VcIikge1xuICAgICAgYXJyaXZlZFN0YXRlLnRvcCA9IGJvdHRvbTtcbiAgICAgIGFycml2ZWRTdGF0ZS5ib3R0b20gPSB0b3A7XG4gICAgfSBlbHNlIHtcbiAgICAgIGFycml2ZWRTdGF0ZS50b3AgPSB0b3A7XG4gICAgICBhcnJpdmVkU3RhdGUuYm90dG9tID0gYm90dG9tO1xuICAgIH1cbiAgICBpbnRlcm5hbFkudmFsdWUgPSBzY3JvbGxUb3A7XG4gIH07XG4gIGNvbnN0IG9uU2Nyb2xsSGFuZGxlciA9IChlKSA9PiB7XG4gICAgdmFyIF9hO1xuICAgIGlmICghd2luZG93KVxuICAgICAgcmV0dXJuO1xuICAgIGNvbnN0IGV2ZW50VGFyZ2V0ID0gKF9hID0gZS50YXJnZXQuZG9jdW1lbnRFbGVtZW50KSAhPSBudWxsID8gX2EgOiBlLnRhcmdldDtcbiAgICBzZXRBcnJpdmVkU3RhdGUoZXZlbnRUYXJnZXQpO1xuICAgIGlzU2Nyb2xsaW5nLnZhbHVlID0gdHJ1ZTtcbiAgICBvblNjcm9sbEVuZERlYm91bmNlZChlKTtcbiAgICBvblNjcm9sbChlKTtcbiAgfTtcbiAgdXNlRXZlbnRMaXN0ZW5lcihcbiAgICBlbGVtZW50LFxuICAgIFwic2Nyb2xsXCIsXG4gICAgdGhyb3R0bGUgPyB1c2VUaHJvdHRsZUZuKG9uU2Nyb2xsSGFuZGxlciwgdGhyb3R0bGUsIHRydWUsIGZhbHNlKSA6IG9uU2Nyb2xsSGFuZGxlcixcbiAgICBldmVudExpc3RlbmVyT3B0aW9uc1xuICApO1xuICB0cnlPbk1vdW50ZWQoKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBfZWxlbWVudCA9IHRvVmFsdWUoZWxlbWVudCk7XG4gICAgICBpZiAoIV9lbGVtZW50KVxuICAgICAgICByZXR1cm47XG4gICAgICBzZXRBcnJpdmVkU3RhdGUoX2VsZW1lbnQpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIG9uRXJyb3IoZSk7XG4gICAgfVxuICB9KTtcbiAgaWYgKChvYnNlcnZlID09IG51bGwgPyB2b2lkIDAgOiBvYnNlcnZlLm11dGF0aW9uKSAmJiBlbGVtZW50ICE9IG51bGwgJiYgZWxlbWVudCAhPT0gd2luZG93ICYmIGVsZW1lbnQgIT09IGRvY3VtZW50KSB7XG4gICAgdXNlTXV0YXRpb25PYnNlcnZlcihcbiAgICAgIGVsZW1lbnQsXG4gICAgICAoKSA9PiB7XG4gICAgICAgIGNvbnN0IF9lbGVtZW50ID0gdG9WYWx1ZShlbGVtZW50KTtcbiAgICAgICAgaWYgKCFfZWxlbWVudClcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIHNldEFycml2ZWRTdGF0ZShfZWxlbWVudCk7XG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBhdHRyaWJ1dGVzOiB0cnVlLFxuICAgICAgICBjaGlsZExpc3Q6IHRydWUsXG4gICAgICAgIHN1YnRyZWU6IHRydWVcbiAgICAgIH1cbiAgICApO1xuICB9XG4gIHVzZUV2ZW50TGlzdGVuZXIoXG4gICAgZWxlbWVudCxcbiAgICBcInNjcm9sbGVuZFwiLFxuICAgIG9uU2Nyb2xsRW5kLFxuICAgIGV2ZW50TGlzdGVuZXJPcHRpb25zXG4gICk7XG4gIHJldHVybiB7XG4gICAgeCxcbiAgICB5LFxuICAgIGlzU2Nyb2xsaW5nLFxuICAgIGFycml2ZWRTdGF0ZSxcbiAgICBkaXJlY3Rpb25zLFxuICAgIG1lYXN1cmUoKSB7XG4gICAgICBjb25zdCBfZWxlbWVudCA9IHRvVmFsdWUoZWxlbWVudCk7XG4gICAgICBpZiAod2luZG93ICYmIF9lbGVtZW50KVxuICAgICAgICBzZXRBcnJpdmVkU3RhdGUoX2VsZW1lbnQpO1xuICAgIH1cbiAgfTtcbn1cblxuZnVuY3Rpb24gdXNlSW5maW5pdGVTY3JvbGwoZWxlbWVudCwgb25Mb2FkTW9yZSwgb3B0aW9ucyA9IHt9KSB7XG4gIHZhciBfYTtcbiAgY29uc3Qge1xuICAgIGRpcmVjdGlvbiA9IFwiYm90dG9tXCIsXG4gICAgaW50ZXJ2YWwgPSAxMDAsXG4gICAgY2FuTG9hZE1vcmUgPSAoKSA9PiB0cnVlXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBzdGF0ZSA9IHJlYWN0aXZlKHVzZVNjcm9sbChcbiAgICBlbGVtZW50LFxuICAgIHtcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICBvZmZzZXQ6IHtcbiAgICAgICAgW2RpcmVjdGlvbl06IChfYSA9IG9wdGlvbnMuZGlzdGFuY2UpICE9IG51bGwgPyBfYSA6IDAsXG4gICAgICAgIC4uLm9wdGlvbnMub2Zmc2V0XG4gICAgICB9XG4gICAgfVxuICApKTtcbiAgY29uc3QgcHJvbWlzZSA9IHJlZigpO1xuICBjb25zdCBpc0xvYWRpbmcgPSBjb21wdXRlZCgoKSA9PiAhIXByb21pc2UudmFsdWUpO1xuICBjb25zdCBvYnNlcnZlZEVsZW1lbnQgPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgcmV0dXJuIHJlc29sdmVFbGVtZW50KHRvVmFsdWUoZWxlbWVudCkpO1xuICB9KTtcbiAgY29uc3QgaXNFbGVtZW50VmlzaWJsZSA9IHVzZUVsZW1lbnRWaXNpYmlsaXR5KG9ic2VydmVkRWxlbWVudCk7XG4gIGZ1bmN0aW9uIGNoZWNrQW5kTG9hZCgpIHtcbiAgICBzdGF0ZS5tZWFzdXJlKCk7XG4gICAgaWYgKCFvYnNlcnZlZEVsZW1lbnQudmFsdWUgfHwgIWlzRWxlbWVudFZpc2libGUudmFsdWUgfHwgIWNhbkxvYWRNb3JlKG9ic2VydmVkRWxlbWVudC52YWx1ZSkpXG4gICAgICByZXR1cm47XG4gICAgY29uc3QgeyBzY3JvbGxIZWlnaHQsIGNsaWVudEhlaWdodCwgc2Nyb2xsV2lkdGgsIGNsaWVudFdpZHRoIH0gPSBvYnNlcnZlZEVsZW1lbnQudmFsdWU7XG4gICAgY29uc3QgaXNOYXJyb3dlciA9IGRpcmVjdGlvbiA9PT0gXCJib3R0b21cIiB8fCBkaXJlY3Rpb24gPT09IFwidG9wXCIgPyBzY3JvbGxIZWlnaHQgPD0gY2xpZW50SGVpZ2h0IDogc2Nyb2xsV2lkdGggPD0gY2xpZW50V2lkdGg7XG4gICAgaWYgKHN0YXRlLmFycml2ZWRTdGF0ZVtkaXJlY3Rpb25dIHx8IGlzTmFycm93ZXIpIHtcbiAgICAgIGlmICghcHJvbWlzZS52YWx1ZSkge1xuICAgICAgICBwcm9taXNlLnZhbHVlID0gUHJvbWlzZS5hbGwoW1xuICAgICAgICAgIG9uTG9hZE1vcmUoc3RhdGUpLFxuICAgICAgICAgIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIGludGVydmFsKSlcbiAgICAgICAgXSkuZmluYWxseSgoKSA9PiB7XG4gICAgICAgICAgcHJvbWlzZS52YWx1ZSA9IG51bGw7XG4gICAgICAgICAgbmV4dFRpY2soKCkgPT4gY2hlY2tBbmRMb2FkKCkpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgY29uc3Qgc3RvcCA9IHdhdGNoKFxuICAgICgpID0+IFtzdGF0ZS5hcnJpdmVkU3RhdGVbZGlyZWN0aW9uXSwgaXNFbGVtZW50VmlzaWJsZS52YWx1ZV0sXG4gICAgY2hlY2tBbmRMb2FkLFxuICAgIHsgaW1tZWRpYXRlOiB0cnVlIH1cbiAgKTtcbiAgdHJ5T25Vbm1vdW50ZWQoc3RvcCk7XG4gIHJldHVybiB7XG4gICAgaXNMb2FkaW5nLFxuICAgIHJlc2V0KCkge1xuICAgICAgbmV4dFRpY2soKCkgPT4gY2hlY2tBbmRMb2FkKCkpO1xuICAgIH1cbiAgfTtcbn1cblxuY29uc3QgZGVmYXVsdEV2ZW50cyA9IFtcIm1vdXNlZG93blwiLCBcIm1vdXNldXBcIiwgXCJrZXlkb3duXCIsIFwia2V5dXBcIl07XG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gdXNlS2V5TW9kaWZpZXIobW9kaWZpZXIsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgZXZlbnRzID0gZGVmYXVsdEV2ZW50cyxcbiAgICBkb2N1bWVudCA9IGRlZmF1bHREb2N1bWVudCxcbiAgICBpbml0aWFsID0gbnVsbFxuICB9ID0gb3B0aW9ucztcbiAgY29uc3Qgc3RhdGUgPSBzaGFsbG93UmVmKGluaXRpYWwpO1xuICBpZiAoZG9jdW1lbnQpIHtcbiAgICBldmVudHMuZm9yRWFjaCgobGlzdGVuZXJFdmVudCkgPT4ge1xuICAgICAgdXNlRXZlbnRMaXN0ZW5lcihkb2N1bWVudCwgbGlzdGVuZXJFdmVudCwgKGV2dCkgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIGV2dC5nZXRNb2RpZmllclN0YXRlID09PSBcImZ1bmN0aW9uXCIpXG4gICAgICAgICAgc3RhdGUudmFsdWUgPSBldnQuZ2V0TW9kaWZpZXJTdGF0ZShtb2RpZmllcik7XG4gICAgICB9LCB7IHBhc3NpdmU6IHRydWUgfSk7XG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIHN0YXRlO1xufVxuXG5mdW5jdGlvbiB1c2VMb2NhbFN0b3JhZ2Uoa2V5LCBpbml0aWFsVmFsdWUsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7IHdpbmRvdyA9IGRlZmF1bHRXaW5kb3cgfSA9IG9wdGlvbnM7XG4gIHJldHVybiB1c2VTdG9yYWdlKGtleSwgaW5pdGlhbFZhbHVlLCB3aW5kb3cgPT0gbnVsbCA/IHZvaWQgMCA6IHdpbmRvdy5sb2NhbFN0b3JhZ2UsIG9wdGlvbnMpO1xufVxuXG5jb25zdCBEZWZhdWx0TWFnaWNLZXlzQWxpYXNNYXAgPSB7XG4gIGN0cmw6IFwiY29udHJvbFwiLFxuICBjb21tYW5kOiBcIm1ldGFcIixcbiAgY21kOiBcIm1ldGFcIixcbiAgb3B0aW9uOiBcImFsdFwiLFxuICB1cDogXCJhcnJvd3VwXCIsXG4gIGRvd246IFwiYXJyb3dkb3duXCIsXG4gIGxlZnQ6IFwiYXJyb3dsZWZ0XCIsXG4gIHJpZ2h0OiBcImFycm93cmlnaHRcIlxufTtcblxuZnVuY3Rpb24gdXNlTWFnaWNLZXlzKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgcmVhY3RpdmU6IHVzZVJlYWN0aXZlID0gZmFsc2UsXG4gICAgdGFyZ2V0ID0gZGVmYXVsdFdpbmRvdyxcbiAgICBhbGlhc01hcCA9IERlZmF1bHRNYWdpY0tleXNBbGlhc01hcCxcbiAgICBwYXNzaXZlID0gdHJ1ZSxcbiAgICBvbkV2ZW50RmlyZWQgPSBub29wXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBjdXJyZW50ID0gcmVhY3RpdmUoLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSk7XG4gIGNvbnN0IG9iaiA9IHtcbiAgICB0b0pTT04oKSB7XG4gICAgICByZXR1cm4ge307XG4gICAgfSxcbiAgICBjdXJyZW50XG4gIH07XG4gIGNvbnN0IHJlZnMgPSB1c2VSZWFjdGl2ZSA/IHJlYWN0aXZlKG9iaikgOiBvYmo7XG4gIGNvbnN0IG1ldGFEZXBzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgY29uc3Qgc2hpZnREZXBzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgY29uc3QgdXNlZEtleXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuICBmdW5jdGlvbiBzZXRSZWZzKGtleSwgdmFsdWUpIHtcbiAgICBpZiAoa2V5IGluIHJlZnMpIHtcbiAgICAgIGlmICh1c2VSZWFjdGl2ZSlcbiAgICAgICAgcmVmc1trZXldID0gdmFsdWU7XG4gICAgICBlbHNlXG4gICAgICAgIHJlZnNba2V5XS52YWx1ZSA9IHZhbHVlO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiByZXNldCgpIHtcbiAgICBjdXJyZW50LmNsZWFyKCk7XG4gICAgZm9yIChjb25zdCBrZXkgb2YgdXNlZEtleXMpXG4gICAgICBzZXRSZWZzKGtleSwgZmFsc2UpO1xuICB9XG4gIGZ1bmN0aW9uIHVwZGF0ZVJlZnMoZSwgdmFsdWUpIHtcbiAgICB2YXIgX2EsIF9iO1xuICAgIGNvbnN0IGtleSA9IChfYSA9IGUua2V5KSA9PSBudWxsID8gdm9pZCAwIDogX2EudG9Mb3dlckNhc2UoKTtcbiAgICBjb25zdCBjb2RlID0gKF9iID0gZS5jb2RlKSA9PSBudWxsID8gdm9pZCAwIDogX2IudG9Mb3dlckNhc2UoKTtcbiAgICBjb25zdCB2YWx1ZXMgPSBbY29kZSwga2V5XS5maWx0ZXIoQm9vbGVhbik7XG4gICAgaWYgKGtleSkge1xuICAgICAgaWYgKHZhbHVlKVxuICAgICAgICBjdXJyZW50LmFkZChrZXkpO1xuICAgICAgZWxzZVxuICAgICAgICBjdXJyZW50LmRlbGV0ZShrZXkpO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IGtleTIgb2YgdmFsdWVzKSB7XG4gICAgICB1c2VkS2V5cy5hZGQoa2V5Mik7XG4gICAgICBzZXRSZWZzKGtleTIsIHZhbHVlKTtcbiAgICB9XG4gICAgaWYgKGtleSA9PT0gXCJzaGlmdFwiICYmICF2YWx1ZSkge1xuICAgICAgY29uc3Qgc2hpZnREZXBzQXJyYXkgPSBBcnJheS5mcm9tKHNoaWZ0RGVwcyk7XG4gICAgICBjb25zdCBzaGlmdEluZGV4ID0gc2hpZnREZXBzQXJyYXkuaW5kZXhPZihcInNoaWZ0XCIpO1xuICAgICAgc2hpZnREZXBzQXJyYXkuZm9yRWFjaCgoa2V5MiwgaW5kZXgpID0+IHtcbiAgICAgICAgaWYgKGluZGV4ID49IHNoaWZ0SW5kZXgpIHtcbiAgICAgICAgICBjdXJyZW50LmRlbGV0ZShrZXkyKTtcbiAgICAgICAgICBzZXRSZWZzKGtleTIsIGZhbHNlKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBzaGlmdERlcHMuY2xlYXIoKTtcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiBlLmdldE1vZGlmaWVyU3RhdGUgPT09IFwiZnVuY3Rpb25cIiAmJiBlLmdldE1vZGlmaWVyU3RhdGUoXCJTaGlmdFwiKSAmJiB2YWx1ZSkge1xuICAgICAgWy4uLmN1cnJlbnQsIC4uLnZhbHVlc10uZm9yRWFjaCgoa2V5MikgPT4gc2hpZnREZXBzLmFkZChrZXkyKSk7XG4gICAgfVxuICAgIGlmIChrZXkgPT09IFwibWV0YVwiICYmICF2YWx1ZSkge1xuICAgICAgbWV0YURlcHMuZm9yRWFjaCgoa2V5MikgPT4ge1xuICAgICAgICBjdXJyZW50LmRlbGV0ZShrZXkyKTtcbiAgICAgICAgc2V0UmVmcyhrZXkyLCBmYWxzZSk7XG4gICAgICB9KTtcbiAgICAgIG1ldGFEZXBzLmNsZWFyKCk7XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgZS5nZXRNb2RpZmllclN0YXRlID09PSBcImZ1bmN0aW9uXCIgJiYgZS5nZXRNb2RpZmllclN0YXRlKFwiTWV0YVwiKSAmJiB2YWx1ZSkge1xuICAgICAgWy4uLmN1cnJlbnQsIC4uLnZhbHVlc10uZm9yRWFjaCgoa2V5MikgPT4gbWV0YURlcHMuYWRkKGtleTIpKTtcbiAgICB9XG4gIH1cbiAgdXNlRXZlbnRMaXN0ZW5lcih0YXJnZXQsIFwia2V5ZG93blwiLCAoZSkgPT4ge1xuICAgIHVwZGF0ZVJlZnMoZSwgdHJ1ZSk7XG4gICAgcmV0dXJuIG9uRXZlbnRGaXJlZChlKTtcbiAgfSwgeyBwYXNzaXZlIH0pO1xuICB1c2VFdmVudExpc3RlbmVyKHRhcmdldCwgXCJrZXl1cFwiLCAoZSkgPT4ge1xuICAgIHVwZGF0ZVJlZnMoZSwgZmFsc2UpO1xuICAgIHJldHVybiBvbkV2ZW50RmlyZWQoZSk7XG4gIH0sIHsgcGFzc2l2ZSB9KTtcbiAgdXNlRXZlbnRMaXN0ZW5lcihcImJsdXJcIiwgcmVzZXQsIHsgcGFzc2l2ZSB9KTtcbiAgdXNlRXZlbnRMaXN0ZW5lcihcImZvY3VzXCIsIHJlc2V0LCB7IHBhc3NpdmUgfSk7XG4gIGNvbnN0IHByb3h5ID0gbmV3IFByb3h5KFxuICAgIHJlZnMsXG4gICAge1xuICAgICAgZ2V0KHRhcmdldDIsIHByb3AsIHJlYykge1xuICAgICAgICBpZiAodHlwZW9mIHByb3AgIT09IFwic3RyaW5nXCIpXG4gICAgICAgICAgcmV0dXJuIFJlZmxlY3QuZ2V0KHRhcmdldDIsIHByb3AsIHJlYyk7XG4gICAgICAgIHByb3AgPSBwcm9wLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgIGlmIChwcm9wIGluIGFsaWFzTWFwKVxuICAgICAgICAgIHByb3AgPSBhbGlhc01hcFtwcm9wXTtcbiAgICAgICAgaWYgKCEocHJvcCBpbiByZWZzKSkge1xuICAgICAgICAgIGlmICgvWytfLV0vLnRlc3QocHJvcCkpIHtcbiAgICAgICAgICAgIGNvbnN0IGtleXMgPSBwcm9wLnNwbGl0KC9bK18tXS9nKS5tYXAoKGkpID0+IGkudHJpbSgpKTtcbiAgICAgICAgICAgIHJlZnNbcHJvcF0gPSBjb21wdXRlZCgoKSA9PiBrZXlzLm1hcCgoa2V5KSA9PiB0b1ZhbHVlKHByb3h5W2tleV0pKS5ldmVyeShCb29sZWFuKSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlZnNbcHJvcF0gPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgciA9IFJlZmxlY3QuZ2V0KHRhcmdldDIsIHByb3AsIHJlYyk7XG4gICAgICAgIHJldHVybiB1c2VSZWFjdGl2ZSA/IHRvVmFsdWUocikgOiByO1xuICAgICAgfVxuICAgIH1cbiAgKTtcbiAgcmV0dXJuIHByb3h5O1xufVxuXG5mdW5jdGlvbiB1c2luZ0VsUmVmKHNvdXJjZSwgY2IpIHtcbiAgaWYgKHRvVmFsdWUoc291cmNlKSlcbiAgICBjYih0b1ZhbHVlKHNvdXJjZSkpO1xufVxuZnVuY3Rpb24gdGltZVJhbmdlVG9BcnJheSh0aW1lUmFuZ2VzKSB7XG4gIGxldCByYW5nZXMgPSBbXTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aW1lUmFuZ2VzLmxlbmd0aDsgKytpKVxuICAgIHJhbmdlcyA9IFsuLi5yYW5nZXMsIFt0aW1lUmFuZ2VzLnN0YXJ0KGkpLCB0aW1lUmFuZ2VzLmVuZChpKV1dO1xuICByZXR1cm4gcmFuZ2VzO1xufVxuZnVuY3Rpb24gdHJhY2tzVG9BcnJheSh0cmFja3MpIHtcbiAgcmV0dXJuIEFycmF5LmZyb20odHJhY2tzKS5tYXAoKHsgbGFiZWwsIGtpbmQsIGxhbmd1YWdlLCBtb2RlLCBhY3RpdmVDdWVzLCBjdWVzLCBpbkJhbmRNZXRhZGF0YVRyYWNrRGlzcGF0Y2hUeXBlIH0sIGlkKSA9PiAoeyBpZCwgbGFiZWwsIGtpbmQsIGxhbmd1YWdlLCBtb2RlLCBhY3RpdmVDdWVzLCBjdWVzLCBpbkJhbmRNZXRhZGF0YVRyYWNrRGlzcGF0Y2hUeXBlIH0pKTtcbn1cbmNvbnN0IGRlZmF1bHRPcHRpb25zID0ge1xuICBzcmM6IFwiXCIsXG4gIHRyYWNrczogW11cbn07XG5mdW5jdGlvbiB1c2VNZWRpYUNvbnRyb2xzKHRhcmdldCwgb3B0aW9ucyA9IHt9KSB7XG4gIHRhcmdldCA9IHRvUmVmKHRhcmdldCk7XG4gIG9wdGlvbnMgPSB7XG4gICAgLi4uZGVmYXVsdE9wdGlvbnMsXG4gICAgLi4ub3B0aW9uc1xuICB9O1xuICBjb25zdCB7XG4gICAgZG9jdW1lbnQgPSBkZWZhdWx0RG9jdW1lbnRcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGxpc3RlbmVyT3B0aW9ucyA9IHsgcGFzc2l2ZTogdHJ1ZSB9O1xuICBjb25zdCBjdXJyZW50VGltZSA9IHNoYWxsb3dSZWYoMCk7XG4gIGNvbnN0IGR1cmF0aW9uID0gc2hhbGxvd1JlZigwKTtcbiAgY29uc3Qgc2Vla2luZyA9IHNoYWxsb3dSZWYoZmFsc2UpO1xuICBjb25zdCB2b2x1bWUgPSBzaGFsbG93UmVmKDEpO1xuICBjb25zdCB3YWl0aW5nID0gc2hhbGxvd1JlZihmYWxzZSk7XG4gIGNvbnN0IGVuZGVkID0gc2hhbGxvd1JlZihmYWxzZSk7XG4gIGNvbnN0IHBsYXlpbmcgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgY29uc3QgcmF0ZSA9IHNoYWxsb3dSZWYoMSk7XG4gIGNvbnN0IHN0YWxsZWQgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgY29uc3QgYnVmZmVyZWQgPSByZWYoW10pO1xuICBjb25zdCB0cmFja3MgPSByZWYoW10pO1xuICBjb25zdCBzZWxlY3RlZFRyYWNrID0gc2hhbGxvd1JlZigtMSk7XG4gIGNvbnN0IGlzUGljdHVyZUluUGljdHVyZSA9IHNoYWxsb3dSZWYoZmFsc2UpO1xuICBjb25zdCBtdXRlZCA9IHNoYWxsb3dSZWYoZmFsc2UpO1xuICBjb25zdCBzdXBwb3J0c1BpY3R1cmVJblBpY3R1cmUgPSBkb2N1bWVudCAmJiBcInBpY3R1cmVJblBpY3R1cmVFbmFibGVkXCIgaW4gZG9jdW1lbnQ7XG4gIGNvbnN0IHNvdXJjZUVycm9yRXZlbnQgPSBjcmVhdGVFdmVudEhvb2soKTtcbiAgY29uc3QgcGxheWJhY2tFcnJvckV2ZW50ID0gY3JlYXRlRXZlbnRIb29rKCk7XG4gIGNvbnN0IGRpc2FibGVUcmFjayA9ICh0cmFjaykgPT4ge1xuICAgIHVzaW5nRWxSZWYodGFyZ2V0LCAoZWwpID0+IHtcbiAgICAgIGlmICh0cmFjaykge1xuICAgICAgICBjb25zdCBpZCA9IHR5cGVvZiB0cmFjayA9PT0gXCJudW1iZXJcIiA/IHRyYWNrIDogdHJhY2suaWQ7XG4gICAgICAgIGVsLnRleHRUcmFja3NbaWRdLm1vZGUgPSBcImRpc2FibGVkXCI7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGVsLnRleHRUcmFja3MubGVuZ3RoOyArK2kpXG4gICAgICAgICAgZWwudGV4dFRyYWNrc1tpXS5tb2RlID0gXCJkaXNhYmxlZFwiO1xuICAgICAgfVxuICAgICAgc2VsZWN0ZWRUcmFjay52YWx1ZSA9IC0xO1xuICAgIH0pO1xuICB9O1xuICBjb25zdCBlbmFibGVUcmFjayA9ICh0cmFjaywgZGlzYWJsZVRyYWNrcyA9IHRydWUpID0+IHtcbiAgICB1c2luZ0VsUmVmKHRhcmdldCwgKGVsKSA9PiB7XG4gICAgICBjb25zdCBpZCA9IHR5cGVvZiB0cmFjayA9PT0gXCJudW1iZXJcIiA/IHRyYWNrIDogdHJhY2suaWQ7XG4gICAgICBpZiAoZGlzYWJsZVRyYWNrcylcbiAgICAgICAgZGlzYWJsZVRyYWNrKCk7XG4gICAgICBlbC50ZXh0VHJhY2tzW2lkXS5tb2RlID0gXCJzaG93aW5nXCI7XG4gICAgICBzZWxlY3RlZFRyYWNrLnZhbHVlID0gaWQ7XG4gICAgfSk7XG4gIH07XG4gIGNvbnN0IHRvZ2dsZVBpY3R1cmVJblBpY3R1cmUgPSAoKSA9PiB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHVzaW5nRWxSZWYodGFyZ2V0LCBhc3luYyAoZWwpID0+IHtcbiAgICAgICAgaWYgKHN1cHBvcnRzUGljdHVyZUluUGljdHVyZSkge1xuICAgICAgICAgIGlmICghaXNQaWN0dXJlSW5QaWN0dXJlLnZhbHVlKSB7XG4gICAgICAgICAgICBlbC5yZXF1ZXN0UGljdHVyZUluUGljdHVyZSgpLnRoZW4ocmVzb2x2ZSkuY2F0Y2gocmVqZWN0KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZG9jdW1lbnQuZXhpdFBpY3R1cmVJblBpY3R1cmUoKS50aGVuKHJlc29sdmUpLmNhdGNoKHJlamVjdCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfTtcbiAgd2F0Y2hFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZG9jdW1lbnQpXG4gICAgICByZXR1cm47XG4gICAgY29uc3QgZWwgPSB0b1ZhbHVlKHRhcmdldCk7XG4gICAgaWYgKCFlbClcbiAgICAgIHJldHVybjtcbiAgICBjb25zdCBzcmMgPSB0b1ZhbHVlKG9wdGlvbnMuc3JjKTtcbiAgICBsZXQgc291cmNlcyA9IFtdO1xuICAgIGlmICghc3JjKVxuICAgICAgcmV0dXJuO1xuICAgIGlmICh0eXBlb2Ygc3JjID09PSBcInN0cmluZ1wiKVxuICAgICAgc291cmNlcyA9IFt7IHNyYyB9XTtcbiAgICBlbHNlIGlmIChBcnJheS5pc0FycmF5KHNyYykpXG4gICAgICBzb3VyY2VzID0gc3JjO1xuICAgIGVsc2UgaWYgKGlzT2JqZWN0KHNyYykpXG4gICAgICBzb3VyY2VzID0gW3NyY107XG4gICAgZWwucXVlcnlTZWxlY3RvckFsbChcInNvdXJjZVwiKS5mb3JFYWNoKChlKSA9PiB7XG4gICAgICBlLnJlbW92ZSgpO1xuICAgIH0pO1xuICAgIHNvdXJjZXMuZm9yRWFjaCgoeyBzcmM6IHNyYzIsIHR5cGUsIG1lZGlhIH0pID0+IHtcbiAgICAgIGNvbnN0IHNvdXJjZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzb3VyY2VcIik7XG4gICAgICBzb3VyY2Uuc2V0QXR0cmlidXRlKFwic3JjXCIsIHNyYzIpO1xuICAgICAgc291cmNlLnNldEF0dHJpYnV0ZShcInR5cGVcIiwgdHlwZSB8fCBcIlwiKTtcbiAgICAgIHNvdXJjZS5zZXRBdHRyaWJ1dGUoXCJtZWRpYVwiLCBtZWRpYSB8fCBcIlwiKTtcbiAgICAgIHVzZUV2ZW50TGlzdGVuZXIoc291cmNlLCBcImVycm9yXCIsIHNvdXJjZUVycm9yRXZlbnQudHJpZ2dlciwgbGlzdGVuZXJPcHRpb25zKTtcbiAgICAgIGVsLmFwcGVuZENoaWxkKHNvdXJjZSk7XG4gICAgfSk7XG4gICAgZWwubG9hZCgpO1xuICB9KTtcbiAgd2F0Y2goW3RhcmdldCwgdm9sdW1lXSwgKCkgPT4ge1xuICAgIGNvbnN0IGVsID0gdG9WYWx1ZSh0YXJnZXQpO1xuICAgIGlmICghZWwpXG4gICAgICByZXR1cm47XG4gICAgZWwudm9sdW1lID0gdm9sdW1lLnZhbHVlO1xuICB9KTtcbiAgd2F0Y2goW3RhcmdldCwgbXV0ZWRdLCAoKSA9PiB7XG4gICAgY29uc3QgZWwgPSB0b1ZhbHVlKHRhcmdldCk7XG4gICAgaWYgKCFlbClcbiAgICAgIHJldHVybjtcbiAgICBlbC5tdXRlZCA9IG11dGVkLnZhbHVlO1xuICB9KTtcbiAgd2F0Y2goW3RhcmdldCwgcmF0ZV0sICgpID0+IHtcbiAgICBjb25zdCBlbCA9IHRvVmFsdWUodGFyZ2V0KTtcbiAgICBpZiAoIWVsKVxuICAgICAgcmV0dXJuO1xuICAgIGVsLnBsYXliYWNrUmF0ZSA9IHJhdGUudmFsdWU7XG4gIH0pO1xuICB3YXRjaEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFkb2N1bWVudClcbiAgICAgIHJldHVybjtcbiAgICBjb25zdCB0ZXh0VHJhY2tzID0gdG9WYWx1ZShvcHRpb25zLnRyYWNrcyk7XG4gICAgY29uc3QgZWwgPSB0b1ZhbHVlKHRhcmdldCk7XG4gICAgaWYgKCF0ZXh0VHJhY2tzIHx8ICF0ZXh0VHJhY2tzLmxlbmd0aCB8fCAhZWwpXG4gICAgICByZXR1cm47XG4gICAgZWwucXVlcnlTZWxlY3RvckFsbChcInRyYWNrXCIpLmZvckVhY2goKGUpID0+IGUucmVtb3ZlKCkpO1xuICAgIHRleHRUcmFja3MuZm9yRWFjaCgoeyBkZWZhdWx0OiBpc0RlZmF1bHQsIGtpbmQsIGxhYmVsLCBzcmMsIHNyY0xhbmcgfSwgaSkgPT4ge1xuICAgICAgY29uc3QgdHJhY2sgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwidHJhY2tcIik7XG4gICAgICB0cmFjay5kZWZhdWx0ID0gaXNEZWZhdWx0IHx8IGZhbHNlO1xuICAgICAgdHJhY2sua2luZCA9IGtpbmQ7XG4gICAgICB0cmFjay5sYWJlbCA9IGxhYmVsO1xuICAgICAgdHJhY2suc3JjID0gc3JjO1xuICAgICAgdHJhY2suc3JjbGFuZyA9IHNyY0xhbmc7XG4gICAgICBpZiAodHJhY2suZGVmYXVsdClcbiAgICAgICAgc2VsZWN0ZWRUcmFjay52YWx1ZSA9IGk7XG4gICAgICBlbC5hcHBlbmRDaGlsZCh0cmFjayk7XG4gICAgfSk7XG4gIH0pO1xuICBjb25zdCB7IGlnbm9yZVVwZGF0ZXM6IGlnbm9yZUN1cnJlbnRUaW1lVXBkYXRlcyB9ID0gd2F0Y2hJZ25vcmFibGUoY3VycmVudFRpbWUsICh0aW1lKSA9PiB7XG4gICAgY29uc3QgZWwgPSB0b1ZhbHVlKHRhcmdldCk7XG4gICAgaWYgKCFlbClcbiAgICAgIHJldHVybjtcbiAgICBlbC5jdXJyZW50VGltZSA9IHRpbWU7XG4gIH0pO1xuICBjb25zdCB7IGlnbm9yZVVwZGF0ZXM6IGlnbm9yZVBsYXlpbmdVcGRhdGVzIH0gPSB3YXRjaElnbm9yYWJsZShwbGF5aW5nLCAoaXNQbGF5aW5nKSA9PiB7XG4gICAgY29uc3QgZWwgPSB0b1ZhbHVlKHRhcmdldCk7XG4gICAgaWYgKCFlbClcbiAgICAgIHJldHVybjtcbiAgICBpZiAoaXNQbGF5aW5nKSB7XG4gICAgICBlbC5wbGF5KCkuY2F0Y2goKGUpID0+IHtcbiAgICAgICAgcGxheWJhY2tFcnJvckV2ZW50LnRyaWdnZXIoZSk7XG4gICAgICAgIHRocm93IGU7XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgZWwucGF1c2UoKTtcbiAgICB9XG4gIH0pO1xuICB1c2VFdmVudExpc3RlbmVyKFxuICAgIHRhcmdldCxcbiAgICBcInRpbWV1cGRhdGVcIixcbiAgICAoKSA9PiBpZ25vcmVDdXJyZW50VGltZVVwZGF0ZXMoKCkgPT4gY3VycmVudFRpbWUudmFsdWUgPSB0b1ZhbHVlKHRhcmdldCkuY3VycmVudFRpbWUpLFxuICAgIGxpc3RlbmVyT3B0aW9uc1xuICApO1xuICB1c2VFdmVudExpc3RlbmVyKFxuICAgIHRhcmdldCxcbiAgICBcImR1cmF0aW9uY2hhbmdlXCIsXG4gICAgKCkgPT4gZHVyYXRpb24udmFsdWUgPSB0b1ZhbHVlKHRhcmdldCkuZHVyYXRpb24sXG4gICAgbGlzdGVuZXJPcHRpb25zXG4gICk7XG4gIHVzZUV2ZW50TGlzdGVuZXIoXG4gICAgdGFyZ2V0LFxuICAgIFwicHJvZ3Jlc3NcIixcbiAgICAoKSA9PiBidWZmZXJlZC52YWx1ZSA9IHRpbWVSYW5nZVRvQXJyYXkodG9WYWx1ZSh0YXJnZXQpLmJ1ZmZlcmVkKSxcbiAgICBsaXN0ZW5lck9wdGlvbnNcbiAgKTtcbiAgdXNlRXZlbnRMaXN0ZW5lcihcbiAgICB0YXJnZXQsXG4gICAgXCJzZWVraW5nXCIsXG4gICAgKCkgPT4gc2Vla2luZy52YWx1ZSA9IHRydWUsXG4gICAgbGlzdGVuZXJPcHRpb25zXG4gICk7XG4gIHVzZUV2ZW50TGlzdGVuZXIoXG4gICAgdGFyZ2V0LFxuICAgIFwic2Vla2VkXCIsXG4gICAgKCkgPT4gc2Vla2luZy52YWx1ZSA9IGZhbHNlLFxuICAgIGxpc3RlbmVyT3B0aW9uc1xuICApO1xuICB1c2VFdmVudExpc3RlbmVyKFxuICAgIHRhcmdldCxcbiAgICBbXCJ3YWl0aW5nXCIsIFwibG9hZHN0YXJ0XCJdLFxuICAgICgpID0+IHtcbiAgICAgIHdhaXRpbmcudmFsdWUgPSB0cnVlO1xuICAgICAgaWdub3JlUGxheWluZ1VwZGF0ZXMoKCkgPT4gcGxheWluZy52YWx1ZSA9IGZhbHNlKTtcbiAgICB9LFxuICAgIGxpc3RlbmVyT3B0aW9uc1xuICApO1xuICB1c2VFdmVudExpc3RlbmVyKFxuICAgIHRhcmdldCxcbiAgICBcImxvYWRlZGRhdGFcIixcbiAgICAoKSA9PiB3YWl0aW5nLnZhbHVlID0gZmFsc2UsXG4gICAgbGlzdGVuZXJPcHRpb25zXG4gICk7XG4gIHVzZUV2ZW50TGlzdGVuZXIoXG4gICAgdGFyZ2V0LFxuICAgIFwicGxheWluZ1wiLFxuICAgICgpID0+IHtcbiAgICAgIHdhaXRpbmcudmFsdWUgPSBmYWxzZTtcbiAgICAgIGVuZGVkLnZhbHVlID0gZmFsc2U7XG4gICAgICBpZ25vcmVQbGF5aW5nVXBkYXRlcygoKSA9PiBwbGF5aW5nLnZhbHVlID0gdHJ1ZSk7XG4gICAgfSxcbiAgICBsaXN0ZW5lck9wdGlvbnNcbiAgKTtcbiAgdXNlRXZlbnRMaXN0ZW5lcihcbiAgICB0YXJnZXQsXG4gICAgXCJyYXRlY2hhbmdlXCIsXG4gICAgKCkgPT4gcmF0ZS52YWx1ZSA9IHRvVmFsdWUodGFyZ2V0KS5wbGF5YmFja1JhdGUsXG4gICAgbGlzdGVuZXJPcHRpb25zXG4gICk7XG4gIHVzZUV2ZW50TGlzdGVuZXIoXG4gICAgdGFyZ2V0LFxuICAgIFwic3RhbGxlZFwiLFxuICAgICgpID0+IHN0YWxsZWQudmFsdWUgPSB0cnVlLFxuICAgIGxpc3RlbmVyT3B0aW9uc1xuICApO1xuICB1c2VFdmVudExpc3RlbmVyKFxuICAgIHRhcmdldCxcbiAgICBcImVuZGVkXCIsXG4gICAgKCkgPT4gZW5kZWQudmFsdWUgPSB0cnVlLFxuICAgIGxpc3RlbmVyT3B0aW9uc1xuICApO1xuICB1c2VFdmVudExpc3RlbmVyKFxuICAgIHRhcmdldCxcbiAgICBcInBhdXNlXCIsXG4gICAgKCkgPT4gaWdub3JlUGxheWluZ1VwZGF0ZXMoKCkgPT4gcGxheWluZy52YWx1ZSA9IGZhbHNlKSxcbiAgICBsaXN0ZW5lck9wdGlvbnNcbiAgKTtcbiAgdXNlRXZlbnRMaXN0ZW5lcihcbiAgICB0YXJnZXQsXG4gICAgXCJwbGF5XCIsXG4gICAgKCkgPT4gaWdub3JlUGxheWluZ1VwZGF0ZXMoKCkgPT4gcGxheWluZy52YWx1ZSA9IHRydWUpLFxuICAgIGxpc3RlbmVyT3B0aW9uc1xuICApO1xuICB1c2VFdmVudExpc3RlbmVyKFxuICAgIHRhcmdldCxcbiAgICBcImVudGVycGljdHVyZWlucGljdHVyZVwiLFxuICAgICgpID0+IGlzUGljdHVyZUluUGljdHVyZS52YWx1ZSA9IHRydWUsXG4gICAgbGlzdGVuZXJPcHRpb25zXG4gICk7XG4gIHVzZUV2ZW50TGlzdGVuZXIoXG4gICAgdGFyZ2V0LFxuICAgIFwibGVhdmVwaWN0dXJlaW5waWN0dXJlXCIsXG4gICAgKCkgPT4gaXNQaWN0dXJlSW5QaWN0dXJlLnZhbHVlID0gZmFsc2UsXG4gICAgbGlzdGVuZXJPcHRpb25zXG4gICk7XG4gIHVzZUV2ZW50TGlzdGVuZXIoXG4gICAgdGFyZ2V0LFxuICAgIFwidm9sdW1lY2hhbmdlXCIsXG4gICAgKCkgPT4ge1xuICAgICAgY29uc3QgZWwgPSB0b1ZhbHVlKHRhcmdldCk7XG4gICAgICBpZiAoIWVsKVxuICAgICAgICByZXR1cm47XG4gICAgICB2b2x1bWUudmFsdWUgPSBlbC52b2x1bWU7XG4gICAgICBtdXRlZC52YWx1ZSA9IGVsLm11dGVkO1xuICAgIH0sXG4gICAgbGlzdGVuZXJPcHRpb25zXG4gICk7XG4gIGNvbnN0IGxpc3RlbmVycyA9IFtdO1xuICBjb25zdCBzdG9wID0gd2F0Y2goW3RhcmdldF0sICgpID0+IHtcbiAgICBjb25zdCBlbCA9IHRvVmFsdWUodGFyZ2V0KTtcbiAgICBpZiAoIWVsKVxuICAgICAgcmV0dXJuO1xuICAgIHN0b3AoKTtcbiAgICBsaXN0ZW5lcnNbMF0gPSB1c2VFdmVudExpc3RlbmVyKGVsLnRleHRUcmFja3MsIFwiYWRkdHJhY2tcIiwgKCkgPT4gdHJhY2tzLnZhbHVlID0gdHJhY2tzVG9BcnJheShlbC50ZXh0VHJhY2tzKSwgbGlzdGVuZXJPcHRpb25zKTtcbiAgICBsaXN0ZW5lcnNbMV0gPSB1c2VFdmVudExpc3RlbmVyKGVsLnRleHRUcmFja3MsIFwicmVtb3ZldHJhY2tcIiwgKCkgPT4gdHJhY2tzLnZhbHVlID0gdHJhY2tzVG9BcnJheShlbC50ZXh0VHJhY2tzKSwgbGlzdGVuZXJPcHRpb25zKTtcbiAgICBsaXN0ZW5lcnNbMl0gPSB1c2VFdmVudExpc3RlbmVyKGVsLnRleHRUcmFja3MsIFwiY2hhbmdlXCIsICgpID0+IHRyYWNrcy52YWx1ZSA9IHRyYWNrc1RvQXJyYXkoZWwudGV4dFRyYWNrcyksIGxpc3RlbmVyT3B0aW9ucyk7XG4gIH0pO1xuICB0cnlPblNjb3BlRGlzcG9zZSgoKSA9PiBsaXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IGxpc3RlbmVyKCkpKTtcbiAgcmV0dXJuIHtcbiAgICBjdXJyZW50VGltZSxcbiAgICBkdXJhdGlvbixcbiAgICB3YWl0aW5nLFxuICAgIHNlZWtpbmcsXG4gICAgZW5kZWQsXG4gICAgc3RhbGxlZCxcbiAgICBidWZmZXJlZCxcbiAgICBwbGF5aW5nLFxuICAgIHJhdGUsXG4gICAgLy8gVm9sdW1lXG4gICAgdm9sdW1lLFxuICAgIG11dGVkLFxuICAgIC8vIFRyYWNrc1xuICAgIHRyYWNrcyxcbiAgICBzZWxlY3RlZFRyYWNrLFxuICAgIGVuYWJsZVRyYWNrLFxuICAgIGRpc2FibGVUcmFjayxcbiAgICAvLyBQaWN0dXJlIGluIFBpY3R1cmVcbiAgICBzdXBwb3J0c1BpY3R1cmVJblBpY3R1cmUsXG4gICAgdG9nZ2xlUGljdHVyZUluUGljdHVyZSxcbiAgICBpc1BpY3R1cmVJblBpY3R1cmUsXG4gICAgLy8gRXZlbnRzXG4gICAgb25Tb3VyY2VFcnJvcjogc291cmNlRXJyb3JFdmVudC5vbixcbiAgICBvblBsYXliYWNrRXJyb3I6IHBsYXliYWNrRXJyb3JFdmVudC5vblxuICB9O1xufVxuXG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gdXNlTWVtb2l6ZShyZXNvbHZlciwgb3B0aW9ucykge1xuICBjb25zdCBpbml0Q2FjaGUgPSAoKSA9PiB7XG4gICAgaWYgKG9wdGlvbnMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdGlvbnMuY2FjaGUpXG4gICAgICByZXR1cm4gc2hhbGxvd1JlYWN0aXZlKG9wdGlvbnMuY2FjaGUpO1xuICAgIHJldHVybiBzaGFsbG93UmVhY3RpdmUoLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSk7XG4gIH07XG4gIGNvbnN0IGNhY2hlID0gaW5pdENhY2hlKCk7XG4gIGNvbnN0IGdlbmVyYXRlS2V5ID0gKC4uLmFyZ3MpID0+IChvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLmdldEtleSkgPyBvcHRpb25zLmdldEtleSguLi5hcmdzKSA6IEpTT04uc3RyaW5naWZ5KGFyZ3MpO1xuICBjb25zdCBfbG9hZERhdGEgPSAoa2V5LCAuLi5hcmdzKSA9PiB7XG4gICAgY2FjaGUuc2V0KGtleSwgcmVzb2x2ZXIoLi4uYXJncykpO1xuICAgIHJldHVybiBjYWNoZS5nZXQoa2V5KTtcbiAgfTtcbiAgY29uc3QgbG9hZERhdGEgPSAoLi4uYXJncykgPT4gX2xvYWREYXRhKGdlbmVyYXRlS2V5KC4uLmFyZ3MpLCAuLi5hcmdzKTtcbiAgY29uc3QgZGVsZXRlRGF0YSA9ICguLi5hcmdzKSA9PiB7XG4gICAgY2FjaGUuZGVsZXRlKGdlbmVyYXRlS2V5KC4uLmFyZ3MpKTtcbiAgfTtcbiAgY29uc3QgY2xlYXJEYXRhID0gKCkgPT4ge1xuICAgIGNhY2hlLmNsZWFyKCk7XG4gIH07XG4gIGNvbnN0IG1lbW9pemVkID0gKC4uLmFyZ3MpID0+IHtcbiAgICBjb25zdCBrZXkgPSBnZW5lcmF0ZUtleSguLi5hcmdzKTtcbiAgICBpZiAoY2FjaGUuaGFzKGtleSkpXG4gICAgICByZXR1cm4gY2FjaGUuZ2V0KGtleSk7XG4gICAgcmV0dXJuIF9sb2FkRGF0YShrZXksIC4uLmFyZ3MpO1xuICB9O1xuICBtZW1vaXplZC5sb2FkID0gbG9hZERhdGE7XG4gIG1lbW9pemVkLmRlbGV0ZSA9IGRlbGV0ZURhdGE7XG4gIG1lbW9pemVkLmNsZWFyID0gY2xlYXJEYXRhO1xuICBtZW1vaXplZC5nZW5lcmF0ZUtleSA9IGdlbmVyYXRlS2V5O1xuICBtZW1vaXplZC5jYWNoZSA9IGNhY2hlO1xuICByZXR1cm4gbWVtb2l6ZWQ7XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VNZW1vcnkob3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IG1lbW9yeSA9IHJlZigpO1xuICBjb25zdCBpc1N1cHBvcnRlZCA9IHVzZVN1cHBvcnRlZCgoKSA9PiB0eXBlb2YgcGVyZm9ybWFuY2UgIT09IFwidW5kZWZpbmVkXCIgJiYgXCJtZW1vcnlcIiBpbiBwZXJmb3JtYW5jZSk7XG4gIGlmIChpc1N1cHBvcnRlZC52YWx1ZSkge1xuICAgIGNvbnN0IHsgaW50ZXJ2YWwgPSAxZTMgfSA9IG9wdGlvbnM7XG4gICAgdXNlSW50ZXJ2YWxGbigoKSA9PiB7XG4gICAgICBtZW1vcnkudmFsdWUgPSBwZXJmb3JtYW5jZS5tZW1vcnk7XG4gICAgfSwgaW50ZXJ2YWwsIHsgaW1tZWRpYXRlOiBvcHRpb25zLmltbWVkaWF0ZSwgaW1tZWRpYXRlQ2FsbGJhY2s6IG9wdGlvbnMuaW1tZWRpYXRlQ2FsbGJhY2sgfSk7XG4gIH1cbiAgcmV0dXJuIHsgaXNTdXBwb3J0ZWQsIG1lbW9yeSB9O1xufVxuXG5jb25zdCBVc2VNb3VzZUJ1aWx0aW5FeHRyYWN0b3JzID0ge1xuICBwYWdlOiAoZXZlbnQpID0+IFtldmVudC5wYWdlWCwgZXZlbnQucGFnZVldLFxuICBjbGllbnQ6IChldmVudCkgPT4gW2V2ZW50LmNsaWVudFgsIGV2ZW50LmNsaWVudFldLFxuICBzY3JlZW46IChldmVudCkgPT4gW2V2ZW50LnNjcmVlblgsIGV2ZW50LnNjcmVlblldLFxuICBtb3ZlbWVudDogKGV2ZW50KSA9PiBldmVudCBpbnN0YW5jZW9mIE1vdXNlRXZlbnQgPyBbZXZlbnQubW92ZW1lbnRYLCBldmVudC5tb3ZlbWVudFldIDogbnVsbFxufTtcbmZ1bmN0aW9uIHVzZU1vdXNlKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgdHlwZSA9IFwicGFnZVwiLFxuICAgIHRvdWNoID0gdHJ1ZSxcbiAgICByZXNldE9uVG91Y2hFbmRzID0gZmFsc2UsXG4gICAgaW5pdGlhbFZhbHVlID0geyB4OiAwLCB5OiAwIH0sXG4gICAgd2luZG93ID0gZGVmYXVsdFdpbmRvdyxcbiAgICB0YXJnZXQgPSB3aW5kb3csXG4gICAgc2Nyb2xsID0gdHJ1ZSxcbiAgICBldmVudEZpbHRlclxuICB9ID0gb3B0aW9ucztcbiAgbGV0IF9wcmV2TW91c2VFdmVudCA9IG51bGw7XG4gIGxldCBfcHJldlNjcm9sbFggPSAwO1xuICBsZXQgX3ByZXZTY3JvbGxZID0gMDtcbiAgY29uc3QgeCA9IHNoYWxsb3dSZWYoaW5pdGlhbFZhbHVlLngpO1xuICBjb25zdCB5ID0gc2hhbGxvd1JlZihpbml0aWFsVmFsdWUueSk7XG4gIGNvbnN0IHNvdXJjZVR5cGUgPSBzaGFsbG93UmVmKG51bGwpO1xuICBjb25zdCBleHRyYWN0b3IgPSB0eXBlb2YgdHlwZSA9PT0gXCJmdW5jdGlvblwiID8gdHlwZSA6IFVzZU1vdXNlQnVpbHRpbkV4dHJhY3RvcnNbdHlwZV07XG4gIGNvbnN0IG1vdXNlSGFuZGxlciA9IChldmVudCkgPT4ge1xuICAgIGNvbnN0IHJlc3VsdCA9IGV4dHJhY3RvcihldmVudCk7XG4gICAgX3ByZXZNb3VzZUV2ZW50ID0gZXZlbnQ7XG4gICAgaWYgKHJlc3VsdCkge1xuICAgICAgW3gudmFsdWUsIHkudmFsdWVdID0gcmVzdWx0O1xuICAgICAgc291cmNlVHlwZS52YWx1ZSA9IFwibW91c2VcIjtcbiAgICB9XG4gICAgaWYgKHdpbmRvdykge1xuICAgICAgX3ByZXZTY3JvbGxYID0gd2luZG93LnNjcm9sbFg7XG4gICAgICBfcHJldlNjcm9sbFkgPSB3aW5kb3cuc2Nyb2xsWTtcbiAgICB9XG4gIH07XG4gIGNvbnN0IHRvdWNoSGFuZGxlciA9IChldmVudCkgPT4ge1xuICAgIGlmIChldmVudC50b3VjaGVzLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGV4dHJhY3RvcihldmVudC50b3VjaGVzWzBdKTtcbiAgICAgIGlmIChyZXN1bHQpIHtcbiAgICAgICAgW3gudmFsdWUsIHkudmFsdWVdID0gcmVzdWx0O1xuICAgICAgICBzb3VyY2VUeXBlLnZhbHVlID0gXCJ0b3VjaFwiO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbiAgY29uc3Qgc2Nyb2xsSGFuZGxlciA9ICgpID0+IHtcbiAgICBpZiAoIV9wcmV2TW91c2VFdmVudCB8fCAhd2luZG93KVxuICAgICAgcmV0dXJuO1xuICAgIGNvbnN0IHBvcyA9IGV4dHJhY3RvcihfcHJldk1vdXNlRXZlbnQpO1xuICAgIGlmIChfcHJldk1vdXNlRXZlbnQgaW5zdGFuY2VvZiBNb3VzZUV2ZW50ICYmIHBvcykge1xuICAgICAgeC52YWx1ZSA9IHBvc1swXSArIHdpbmRvdy5zY3JvbGxYIC0gX3ByZXZTY3JvbGxYO1xuICAgICAgeS52YWx1ZSA9IHBvc1sxXSArIHdpbmRvdy5zY3JvbGxZIC0gX3ByZXZTY3JvbGxZO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgcmVzZXQgPSAoKSA9PiB7XG4gICAgeC52YWx1ZSA9IGluaXRpYWxWYWx1ZS54O1xuICAgIHkudmFsdWUgPSBpbml0aWFsVmFsdWUueTtcbiAgfTtcbiAgY29uc3QgbW91c2VIYW5kbGVyV3JhcHBlciA9IGV2ZW50RmlsdGVyID8gKGV2ZW50KSA9PiBldmVudEZpbHRlcigoKSA9PiBtb3VzZUhhbmRsZXIoZXZlbnQpLCB7fSkgOiAoZXZlbnQpID0+IG1vdXNlSGFuZGxlcihldmVudCk7XG4gIGNvbnN0IHRvdWNoSGFuZGxlcldyYXBwZXIgPSBldmVudEZpbHRlciA/IChldmVudCkgPT4gZXZlbnRGaWx0ZXIoKCkgPT4gdG91Y2hIYW5kbGVyKGV2ZW50KSwge30pIDogKGV2ZW50KSA9PiB0b3VjaEhhbmRsZXIoZXZlbnQpO1xuICBjb25zdCBzY3JvbGxIYW5kbGVyV3JhcHBlciA9IGV2ZW50RmlsdGVyID8gKCkgPT4gZXZlbnRGaWx0ZXIoKCkgPT4gc2Nyb2xsSGFuZGxlcigpLCB7fSkgOiAoKSA9PiBzY3JvbGxIYW5kbGVyKCk7XG4gIGlmICh0YXJnZXQpIHtcbiAgICBjb25zdCBsaXN0ZW5lck9wdGlvbnMgPSB7IHBhc3NpdmU6IHRydWUgfTtcbiAgICB1c2VFdmVudExpc3RlbmVyKHRhcmdldCwgW1wibW91c2Vtb3ZlXCIsIFwiZHJhZ292ZXJcIl0sIG1vdXNlSGFuZGxlcldyYXBwZXIsIGxpc3RlbmVyT3B0aW9ucyk7XG4gICAgaWYgKHRvdWNoICYmIHR5cGUgIT09IFwibW92ZW1lbnRcIikge1xuICAgICAgdXNlRXZlbnRMaXN0ZW5lcih0YXJnZXQsIFtcInRvdWNoc3RhcnRcIiwgXCJ0b3VjaG1vdmVcIl0sIHRvdWNoSGFuZGxlcldyYXBwZXIsIGxpc3RlbmVyT3B0aW9ucyk7XG4gICAgICBpZiAocmVzZXRPblRvdWNoRW5kcylcbiAgICAgICAgdXNlRXZlbnRMaXN0ZW5lcih0YXJnZXQsIFwidG91Y2hlbmRcIiwgcmVzZXQsIGxpc3RlbmVyT3B0aW9ucyk7XG4gICAgfVxuICAgIGlmIChzY3JvbGwgJiYgdHlwZSA9PT0gXCJwYWdlXCIpXG4gICAgICB1c2VFdmVudExpc3RlbmVyKHdpbmRvdywgXCJzY3JvbGxcIiwgc2Nyb2xsSGFuZGxlcldyYXBwZXIsIGxpc3RlbmVyT3B0aW9ucyk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB4LFxuICAgIHksXG4gICAgc291cmNlVHlwZVxuICB9O1xufVxuXG5mdW5jdGlvbiB1c2VNb3VzZUluRWxlbWVudCh0YXJnZXQsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgd2luZG93UmVzaXplID0gdHJ1ZSxcbiAgICB3aW5kb3dTY3JvbGwgPSB0cnVlLFxuICAgIGhhbmRsZU91dHNpZGUgPSB0cnVlLFxuICAgIHdpbmRvdyA9IGRlZmF1bHRXaW5kb3dcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IHR5cGUgPSBvcHRpb25zLnR5cGUgfHwgXCJwYWdlXCI7XG4gIGNvbnN0IHsgeCwgeSwgc291cmNlVHlwZSB9ID0gdXNlTW91c2Uob3B0aW9ucyk7XG4gIGNvbnN0IHRhcmdldFJlZiA9IHNoYWxsb3dSZWYodGFyZ2V0ICE9IG51bGwgPyB0YXJnZXQgOiB3aW5kb3cgPT0gbnVsbCA/IHZvaWQgMCA6IHdpbmRvdy5kb2N1bWVudC5ib2R5KTtcbiAgY29uc3QgZWxlbWVudFggPSBzaGFsbG93UmVmKDApO1xuICBjb25zdCBlbGVtZW50WSA9IHNoYWxsb3dSZWYoMCk7XG4gIGNvbnN0IGVsZW1lbnRQb3NpdGlvblggPSBzaGFsbG93UmVmKDApO1xuICBjb25zdCBlbGVtZW50UG9zaXRpb25ZID0gc2hhbGxvd1JlZigwKTtcbiAgY29uc3QgZWxlbWVudEhlaWdodCA9IHNoYWxsb3dSZWYoMCk7XG4gIGNvbnN0IGVsZW1lbnRXaWR0aCA9IHNoYWxsb3dSZWYoMCk7XG4gIGNvbnN0IGlzT3V0c2lkZSA9IHNoYWxsb3dSZWYodHJ1ZSk7XG4gIGZ1bmN0aW9uIHVwZGF0ZSgpIHtcbiAgICBpZiAoIXdpbmRvdylcbiAgICAgIHJldHVybjtcbiAgICBjb25zdCBlbCA9IHVucmVmRWxlbWVudCh0YXJnZXRSZWYpO1xuICAgIGlmICghZWwgfHwgIShlbCBpbnN0YW5jZW9mIEVsZW1lbnQpKVxuICAgICAgcmV0dXJuO1xuICAgIGNvbnN0IHtcbiAgICAgIGxlZnQsXG4gICAgICB0b3AsXG4gICAgICB3aWR0aCxcbiAgICAgIGhlaWdodFxuICAgIH0gPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBlbGVtZW50UG9zaXRpb25YLnZhbHVlID0gbGVmdCArICh0eXBlID09PSBcInBhZ2VcIiA/IHdpbmRvdy5wYWdlWE9mZnNldCA6IDApO1xuICAgIGVsZW1lbnRQb3NpdGlvblkudmFsdWUgPSB0b3AgKyAodHlwZSA9PT0gXCJwYWdlXCIgPyB3aW5kb3cucGFnZVlPZmZzZXQgOiAwKTtcbiAgICBlbGVtZW50SGVpZ2h0LnZhbHVlID0gaGVpZ2h0O1xuICAgIGVsZW1lbnRXaWR0aC52YWx1ZSA9IHdpZHRoO1xuICAgIGNvbnN0IGVsWCA9IHgudmFsdWUgLSBlbGVtZW50UG9zaXRpb25YLnZhbHVlO1xuICAgIGNvbnN0IGVsWSA9IHkudmFsdWUgLSBlbGVtZW50UG9zaXRpb25ZLnZhbHVlO1xuICAgIGlzT3V0c2lkZS52YWx1ZSA9IHdpZHRoID09PSAwIHx8IGhlaWdodCA9PT0gMCB8fCBlbFggPCAwIHx8IGVsWSA8IDAgfHwgZWxYID4gd2lkdGggfHwgZWxZID4gaGVpZ2h0O1xuICAgIGlmIChoYW5kbGVPdXRzaWRlIHx8ICFpc091dHNpZGUudmFsdWUpIHtcbiAgICAgIGVsZW1lbnRYLnZhbHVlID0gZWxYO1xuICAgICAgZWxlbWVudFkudmFsdWUgPSBlbFk7XG4gICAgfVxuICB9XG4gIGNvbnN0IHN0b3BGbkxpc3QgPSBbXTtcbiAgZnVuY3Rpb24gc3RvcCgpIHtcbiAgICBzdG9wRm5MaXN0LmZvckVhY2goKGZuKSA9PiBmbigpKTtcbiAgICBzdG9wRm5MaXN0Lmxlbmd0aCA9IDA7XG4gIH1cbiAgdHJ5T25Nb3VudGVkKCgpID0+IHtcbiAgICB1cGRhdGUoKTtcbiAgfSk7XG4gIGlmICh3aW5kb3cpIHtcbiAgICBjb25zdCB7XG4gICAgICBzdG9wOiBzdG9wUmVzaXplT2JzZXJ2ZXJcbiAgICB9ID0gdXNlUmVzaXplT2JzZXJ2ZXIodGFyZ2V0UmVmLCB1cGRhdGUpO1xuICAgIGNvbnN0IHtcbiAgICAgIHN0b3A6IHN0b3BNdXRhdGlvbk9ic2VydmVyXG4gICAgfSA9IHVzZU11dGF0aW9uT2JzZXJ2ZXIodGFyZ2V0UmVmLCB1cGRhdGUsIHtcbiAgICAgIGF0dHJpYnV0ZUZpbHRlcjogW1wic3R5bGVcIiwgXCJjbGFzc1wiXVxuICAgIH0pO1xuICAgIGNvbnN0IHN0b3BXYXRjaCA9IHdhdGNoKFxuICAgICAgW3RhcmdldFJlZiwgeCwgeV0sXG4gICAgICB1cGRhdGVcbiAgICApO1xuICAgIHN0b3BGbkxpc3QucHVzaChcbiAgICAgIHN0b3BSZXNpemVPYnNlcnZlcixcbiAgICAgIHN0b3BNdXRhdGlvbk9ic2VydmVyLFxuICAgICAgc3RvcFdhdGNoXG4gICAgKTtcbiAgICB1c2VFdmVudExpc3RlbmVyKFxuICAgICAgZG9jdW1lbnQsXG4gICAgICBcIm1vdXNlbGVhdmVcIixcbiAgICAgICgpID0+IGlzT3V0c2lkZS52YWx1ZSA9IHRydWUsXG4gICAgICB7IHBhc3NpdmU6IHRydWUgfVxuICAgICk7XG4gICAgaWYgKHdpbmRvd1Njcm9sbCkge1xuICAgICAgc3RvcEZuTGlzdC5wdXNoKFxuICAgICAgICB1c2VFdmVudExpc3RlbmVyKFwic2Nyb2xsXCIsIHVwZGF0ZSwgeyBjYXB0dXJlOiB0cnVlLCBwYXNzaXZlOiB0cnVlIH0pXG4gICAgICApO1xuICAgIH1cbiAgICBpZiAod2luZG93UmVzaXplKSB7XG4gICAgICBzdG9wRm5MaXN0LnB1c2goXG4gICAgICAgIHVzZUV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIiwgdXBkYXRlLCB7IHBhc3NpdmU6IHRydWUgfSlcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIHJldHVybiB7XG4gICAgeCxcbiAgICB5LFxuICAgIHNvdXJjZVR5cGUsXG4gICAgZWxlbWVudFgsXG4gICAgZWxlbWVudFksXG4gICAgZWxlbWVudFBvc2l0aW9uWCxcbiAgICBlbGVtZW50UG9zaXRpb25ZLFxuICAgIGVsZW1lbnRIZWlnaHQsXG4gICAgZWxlbWVudFdpZHRoLFxuICAgIGlzT3V0c2lkZSxcbiAgICBzdG9wXG4gIH07XG59XG5cbmZ1bmN0aW9uIHVzZU1vdXNlUHJlc3NlZChvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIHRvdWNoID0gdHJ1ZSxcbiAgICBkcmFnID0gdHJ1ZSxcbiAgICBjYXB0dXJlID0gZmFsc2UsXG4gICAgaW5pdGlhbFZhbHVlID0gZmFsc2UsXG4gICAgd2luZG93ID0gZGVmYXVsdFdpbmRvd1xuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgcHJlc3NlZCA9IHNoYWxsb3dSZWYoaW5pdGlhbFZhbHVlKTtcbiAgY29uc3Qgc291cmNlVHlwZSA9IHNoYWxsb3dSZWYobnVsbCk7XG4gIGlmICghd2luZG93KSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHByZXNzZWQsXG4gICAgICBzb3VyY2VUeXBlXG4gICAgfTtcbiAgfVxuICBjb25zdCBvblByZXNzZWQgPSAoc3JjVHlwZSkgPT4gKGV2ZW50KSA9PiB7XG4gICAgdmFyIF9hO1xuICAgIHByZXNzZWQudmFsdWUgPSB0cnVlO1xuICAgIHNvdXJjZVR5cGUudmFsdWUgPSBzcmNUeXBlO1xuICAgIChfYSA9IG9wdGlvbnMub25QcmVzc2VkKSA9PSBudWxsID8gdm9pZCAwIDogX2EuY2FsbChvcHRpb25zLCBldmVudCk7XG4gIH07XG4gIGNvbnN0IG9uUmVsZWFzZWQgPSAoZXZlbnQpID0+IHtcbiAgICB2YXIgX2E7XG4gICAgcHJlc3NlZC52YWx1ZSA9IGZhbHNlO1xuICAgIHNvdXJjZVR5cGUudmFsdWUgPSBudWxsO1xuICAgIChfYSA9IG9wdGlvbnMub25SZWxlYXNlZCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLmNhbGwob3B0aW9ucywgZXZlbnQpO1xuICB9O1xuICBjb25zdCB0YXJnZXQgPSBjb21wdXRlZCgoKSA9PiB1bnJlZkVsZW1lbnQob3B0aW9ucy50YXJnZXQpIHx8IHdpbmRvdyk7XG4gIGNvbnN0IGxpc3RlbmVyT3B0aW9ucyA9IHsgcGFzc2l2ZTogdHJ1ZSwgY2FwdHVyZSB9O1xuICB1c2VFdmVudExpc3RlbmVyKHRhcmdldCwgXCJtb3VzZWRvd25cIiwgb25QcmVzc2VkKFwibW91c2VcIiksIGxpc3RlbmVyT3B0aW9ucyk7XG4gIHVzZUV2ZW50TGlzdGVuZXIod2luZG93LCBcIm1vdXNlbGVhdmVcIiwgb25SZWxlYXNlZCwgbGlzdGVuZXJPcHRpb25zKTtcbiAgdXNlRXZlbnRMaXN0ZW5lcih3aW5kb3csIFwibW91c2V1cFwiLCBvblJlbGVhc2VkLCBsaXN0ZW5lck9wdGlvbnMpO1xuICBpZiAoZHJhZykge1xuICAgIHVzZUV2ZW50TGlzdGVuZXIodGFyZ2V0LCBcImRyYWdzdGFydFwiLCBvblByZXNzZWQoXCJtb3VzZVwiKSwgbGlzdGVuZXJPcHRpb25zKTtcbiAgICB1c2VFdmVudExpc3RlbmVyKHdpbmRvdywgXCJkcm9wXCIsIG9uUmVsZWFzZWQsIGxpc3RlbmVyT3B0aW9ucyk7XG4gICAgdXNlRXZlbnRMaXN0ZW5lcih3aW5kb3csIFwiZHJhZ2VuZFwiLCBvblJlbGVhc2VkLCBsaXN0ZW5lck9wdGlvbnMpO1xuICB9XG4gIGlmICh0b3VjaCkge1xuICAgIHVzZUV2ZW50TGlzdGVuZXIodGFyZ2V0LCBcInRvdWNoc3RhcnRcIiwgb25QcmVzc2VkKFwidG91Y2hcIiksIGxpc3RlbmVyT3B0aW9ucyk7XG4gICAgdXNlRXZlbnRMaXN0ZW5lcih3aW5kb3csIFwidG91Y2hlbmRcIiwgb25SZWxlYXNlZCwgbGlzdGVuZXJPcHRpb25zKTtcbiAgICB1c2VFdmVudExpc3RlbmVyKHdpbmRvdywgXCJ0b3VjaGNhbmNlbFwiLCBvblJlbGVhc2VkLCBsaXN0ZW5lck9wdGlvbnMpO1xuICB9XG4gIHJldHVybiB7XG4gICAgcHJlc3NlZCxcbiAgICBzb3VyY2VUeXBlXG4gIH07XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VOYXZpZ2F0b3JMYW5ndWFnZShvcHRpb25zID0ge30pIHtcbiAgY29uc3QgeyB3aW5kb3cgPSBkZWZhdWx0V2luZG93IH0gPSBvcHRpb25zO1xuICBjb25zdCBuYXZpZ2F0b3IgPSB3aW5kb3cgPT0gbnVsbCA/IHZvaWQgMCA6IHdpbmRvdy5uYXZpZ2F0b3I7XG4gIGNvbnN0IGlzU3VwcG9ydGVkID0gdXNlU3VwcG9ydGVkKCgpID0+IG5hdmlnYXRvciAmJiBcImxhbmd1YWdlXCIgaW4gbmF2aWdhdG9yKTtcbiAgY29uc3QgbGFuZ3VhZ2UgPSBzaGFsbG93UmVmKG5hdmlnYXRvciA9PSBudWxsID8gdm9pZCAwIDogbmF2aWdhdG9yLmxhbmd1YWdlKTtcbiAgdXNlRXZlbnRMaXN0ZW5lcih3aW5kb3csIFwibGFuZ3VhZ2VjaGFuZ2VcIiwgKCkgPT4ge1xuICAgIGlmIChuYXZpZ2F0b3IpXG4gICAgICBsYW5ndWFnZS52YWx1ZSA9IG5hdmlnYXRvci5sYW5ndWFnZTtcbiAgfSwgeyBwYXNzaXZlOiB0cnVlIH0pO1xuICByZXR1cm4ge1xuICAgIGlzU3VwcG9ydGVkLFxuICAgIGxhbmd1YWdlXG4gIH07XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VOZXR3b3JrKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7IHdpbmRvdyA9IGRlZmF1bHRXaW5kb3cgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IG5hdmlnYXRvciA9IHdpbmRvdyA9PSBudWxsID8gdm9pZCAwIDogd2luZG93Lm5hdmlnYXRvcjtcbiAgY29uc3QgaXNTdXBwb3J0ZWQgPSB1c2VTdXBwb3J0ZWQoKCkgPT4gbmF2aWdhdG9yICYmIFwiY29ubmVjdGlvblwiIGluIG5hdmlnYXRvcik7XG4gIGNvbnN0IGlzT25saW5lID0gc2hhbGxvd1JlZih0cnVlKTtcbiAgY29uc3Qgc2F2ZURhdGEgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgY29uc3Qgb2ZmbGluZUF0ID0gc2hhbGxvd1JlZih2b2lkIDApO1xuICBjb25zdCBvbmxpbmVBdCA9IHNoYWxsb3dSZWYodm9pZCAwKTtcbiAgY29uc3QgZG93bmxpbmsgPSBzaGFsbG93UmVmKHZvaWQgMCk7XG4gIGNvbnN0IGRvd25saW5rTWF4ID0gc2hhbGxvd1JlZih2b2lkIDApO1xuICBjb25zdCBydHQgPSBzaGFsbG93UmVmKHZvaWQgMCk7XG4gIGNvbnN0IGVmZmVjdGl2ZVR5cGUgPSBzaGFsbG93UmVmKHZvaWQgMCk7XG4gIGNvbnN0IHR5cGUgPSBzaGFsbG93UmVmKFwidW5rbm93blwiKTtcbiAgY29uc3QgY29ubmVjdGlvbiA9IGlzU3VwcG9ydGVkLnZhbHVlICYmIG5hdmlnYXRvci5jb25uZWN0aW9uO1xuICBmdW5jdGlvbiB1cGRhdGVOZXR3b3JrSW5mb3JtYXRpb24oKSB7XG4gICAgaWYgKCFuYXZpZ2F0b3IpXG4gICAgICByZXR1cm47XG4gICAgaXNPbmxpbmUudmFsdWUgPSBuYXZpZ2F0b3Iub25MaW5lO1xuICAgIG9mZmxpbmVBdC52YWx1ZSA9IGlzT25saW5lLnZhbHVlID8gdm9pZCAwIDogRGF0ZS5ub3coKTtcbiAgICBvbmxpbmVBdC52YWx1ZSA9IGlzT25saW5lLnZhbHVlID8gRGF0ZS5ub3coKSA6IHZvaWQgMDtcbiAgICBpZiAoY29ubmVjdGlvbikge1xuICAgICAgZG93bmxpbmsudmFsdWUgPSBjb25uZWN0aW9uLmRvd25saW5rO1xuICAgICAgZG93bmxpbmtNYXgudmFsdWUgPSBjb25uZWN0aW9uLmRvd25saW5rTWF4O1xuICAgICAgZWZmZWN0aXZlVHlwZS52YWx1ZSA9IGNvbm5lY3Rpb24uZWZmZWN0aXZlVHlwZTtcbiAgICAgIHJ0dC52YWx1ZSA9IGNvbm5lY3Rpb24ucnR0O1xuICAgICAgc2F2ZURhdGEudmFsdWUgPSBjb25uZWN0aW9uLnNhdmVEYXRhO1xuICAgICAgdHlwZS52YWx1ZSA9IGNvbm5lY3Rpb24udHlwZTtcbiAgICB9XG4gIH1cbiAgY29uc3QgbGlzdGVuZXJPcHRpb25zID0geyBwYXNzaXZlOiB0cnVlIH07XG4gIGlmICh3aW5kb3cpIHtcbiAgICB1c2VFdmVudExpc3RlbmVyKHdpbmRvdywgXCJvZmZsaW5lXCIsICgpID0+IHtcbiAgICAgIGlzT25saW5lLnZhbHVlID0gZmFsc2U7XG4gICAgICBvZmZsaW5lQXQudmFsdWUgPSBEYXRlLm5vdygpO1xuICAgIH0sIGxpc3RlbmVyT3B0aW9ucyk7XG4gICAgdXNlRXZlbnRMaXN0ZW5lcih3aW5kb3csIFwib25saW5lXCIsICgpID0+IHtcbiAgICAgIGlzT25saW5lLnZhbHVlID0gdHJ1ZTtcbiAgICAgIG9ubGluZUF0LnZhbHVlID0gRGF0ZS5ub3coKTtcbiAgICB9LCBsaXN0ZW5lck9wdGlvbnMpO1xuICB9XG4gIGlmIChjb25uZWN0aW9uKVxuICAgIHVzZUV2ZW50TGlzdGVuZXIoY29ubmVjdGlvbiwgXCJjaGFuZ2VcIiwgdXBkYXRlTmV0d29ya0luZm9ybWF0aW9uLCBsaXN0ZW5lck9wdGlvbnMpO1xuICB1cGRhdGVOZXR3b3JrSW5mb3JtYXRpb24oKTtcbiAgcmV0dXJuIHtcbiAgICBpc1N1cHBvcnRlZCxcbiAgICBpc09ubGluZTogcmVhZG9ubHkoaXNPbmxpbmUpLFxuICAgIHNhdmVEYXRhOiByZWFkb25seShzYXZlRGF0YSksXG4gICAgb2ZmbGluZUF0OiByZWFkb25seShvZmZsaW5lQXQpLFxuICAgIG9ubGluZUF0OiByZWFkb25seShvbmxpbmVBdCksXG4gICAgZG93bmxpbms6IHJlYWRvbmx5KGRvd25saW5rKSxcbiAgICBkb3dubGlua01heDogcmVhZG9ubHkoZG93bmxpbmtNYXgpLFxuICAgIGVmZmVjdGl2ZVR5cGU6IHJlYWRvbmx5KGVmZmVjdGl2ZVR5cGUpLFxuICAgIHJ0dDogcmVhZG9ubHkocnR0KSxcbiAgICB0eXBlOiByZWFkb25seSh0eXBlKVxuICB9O1xufVxuXG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gdXNlTm93KG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgY29udHJvbHM6IGV4cG9zZUNvbnRyb2xzID0gZmFsc2UsXG4gICAgaW50ZXJ2YWwgPSBcInJlcXVlc3RBbmltYXRpb25GcmFtZVwiLFxuICAgIGltbWVkaWF0ZSA9IHRydWVcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IG5vdyA9IHJlZigvKiBAX19QVVJFX18gKi8gbmV3IERhdGUoKSk7XG4gIGNvbnN0IHVwZGF0ZSA9ICgpID0+IG5vdy52YWx1ZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgRGF0ZSgpO1xuICBjb25zdCBjb250cm9scyA9IGludGVydmFsID09PSBcInJlcXVlc3RBbmltYXRpb25GcmFtZVwiID8gdXNlUmFmRm4odXBkYXRlLCB7IGltbWVkaWF0ZSB9KSA6IHVzZUludGVydmFsRm4odXBkYXRlLCBpbnRlcnZhbCwgeyBpbW1lZGlhdGUgfSk7XG4gIGlmIChleHBvc2VDb250cm9scykge1xuICAgIHJldHVybiB7XG4gICAgICBub3csXG4gICAgICAuLi5jb250cm9sc1xuICAgIH07XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIG5vdztcbiAgfVxufVxuXG5mdW5jdGlvbiB1c2VPYmplY3RVcmwob2JqZWN0KSB7XG4gIGNvbnN0IHVybCA9IHNoYWxsb3dSZWYoKTtcbiAgY29uc3QgcmVsZWFzZSA9ICgpID0+IHtcbiAgICBpZiAodXJsLnZhbHVlKVxuICAgICAgVVJMLnJldm9rZU9iamVjdFVSTCh1cmwudmFsdWUpO1xuICAgIHVybC52YWx1ZSA9IHZvaWQgMDtcbiAgfTtcbiAgd2F0Y2goXG4gICAgKCkgPT4gdG9WYWx1ZShvYmplY3QpLFxuICAgIChuZXdPYmplY3QpID0+IHtcbiAgICAgIHJlbGVhc2UoKTtcbiAgICAgIGlmIChuZXdPYmplY3QpXG4gICAgICAgIHVybC52YWx1ZSA9IFVSTC5jcmVhdGVPYmplY3RVUkwobmV3T2JqZWN0KTtcbiAgICB9LFxuICAgIHsgaW1tZWRpYXRlOiB0cnVlIH1cbiAgKTtcbiAgdHJ5T25TY29wZURpc3Bvc2UocmVsZWFzZSk7XG4gIHJldHVybiByZWFkb25seSh1cmwpO1xufVxuXG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gdXNlQ2xhbXAodmFsdWUsIG1pbiwgbWF4KSB7XG4gIGlmICh0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIiB8fCBpc1JlYWRvbmx5KHZhbHVlKSlcbiAgICByZXR1cm4gY29tcHV0ZWQoKCkgPT4gY2xhbXAodG9WYWx1ZSh2YWx1ZSksIHRvVmFsdWUobWluKSwgdG9WYWx1ZShtYXgpKSk7XG4gIGNvbnN0IF92YWx1ZSA9IHJlZih2YWx1ZSk7XG4gIHJldHVybiBjb21wdXRlZCh7XG4gICAgZ2V0KCkge1xuICAgICAgcmV0dXJuIF92YWx1ZS52YWx1ZSA9IGNsYW1wKF92YWx1ZS52YWx1ZSwgdG9WYWx1ZShtaW4pLCB0b1ZhbHVlKG1heCkpO1xuICAgIH0sXG4gICAgc2V0KHZhbHVlMikge1xuICAgICAgX3ZhbHVlLnZhbHVlID0gY2xhbXAodmFsdWUyLCB0b1ZhbHVlKG1pbiksIHRvVmFsdWUobWF4KSk7XG4gICAgfVxuICB9KTtcbn1cblxuZnVuY3Rpb24gdXNlT2Zmc2V0UGFnaW5hdGlvbihvcHRpb25zKSB7XG4gIGNvbnN0IHtcbiAgICB0b3RhbCA9IE51bWJlci5QT1NJVElWRV9JTkZJTklUWSxcbiAgICBwYWdlU2l6ZSA9IDEwLFxuICAgIHBhZ2UgPSAxLFxuICAgIG9uUGFnZUNoYW5nZSA9IG5vb3AsXG4gICAgb25QYWdlU2l6ZUNoYW5nZSA9IG5vb3AsXG4gICAgb25QYWdlQ291bnRDaGFuZ2UgPSBub29wXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBjdXJyZW50UGFnZVNpemUgPSB1c2VDbGFtcChwYWdlU2l6ZSwgMSwgTnVtYmVyLlBPU0lUSVZFX0lORklOSVRZKTtcbiAgY29uc3QgcGFnZUNvdW50ID0gY29tcHV0ZWQoKCkgPT4gTWF0aC5tYXgoXG4gICAgMSxcbiAgICBNYXRoLmNlaWwodG9WYWx1ZSh0b3RhbCkgLyB0b1ZhbHVlKGN1cnJlbnRQYWdlU2l6ZSkpXG4gICkpO1xuICBjb25zdCBjdXJyZW50UGFnZSA9IHVzZUNsYW1wKHBhZ2UsIDEsIHBhZ2VDb3VudCk7XG4gIGNvbnN0IGlzRmlyc3RQYWdlID0gY29tcHV0ZWQoKCkgPT4gY3VycmVudFBhZ2UudmFsdWUgPT09IDEpO1xuICBjb25zdCBpc0xhc3RQYWdlID0gY29tcHV0ZWQoKCkgPT4gY3VycmVudFBhZ2UudmFsdWUgPT09IHBhZ2VDb3VudC52YWx1ZSk7XG4gIGlmIChpc1JlZihwYWdlKSkge1xuICAgIHN5bmNSZWYocGFnZSwgY3VycmVudFBhZ2UsIHtcbiAgICAgIGRpcmVjdGlvbjogaXNSZWFkb25seShwYWdlKSA/IFwibHRyXCIgOiBcImJvdGhcIlxuICAgIH0pO1xuICB9XG4gIGlmIChpc1JlZihwYWdlU2l6ZSkpIHtcbiAgICBzeW5jUmVmKHBhZ2VTaXplLCBjdXJyZW50UGFnZVNpemUsIHtcbiAgICAgIGRpcmVjdGlvbjogaXNSZWFkb25seShwYWdlU2l6ZSkgPyBcImx0clwiIDogXCJib3RoXCJcbiAgICB9KTtcbiAgfVxuICBmdW5jdGlvbiBwcmV2KCkge1xuICAgIGN1cnJlbnRQYWdlLnZhbHVlLS07XG4gIH1cbiAgZnVuY3Rpb24gbmV4dCgpIHtcbiAgICBjdXJyZW50UGFnZS52YWx1ZSsrO1xuICB9XG4gIGNvbnN0IHJldHVyblZhbHVlID0ge1xuICAgIGN1cnJlbnRQYWdlLFxuICAgIGN1cnJlbnRQYWdlU2l6ZSxcbiAgICBwYWdlQ291bnQsXG4gICAgaXNGaXJzdFBhZ2UsXG4gICAgaXNMYXN0UGFnZSxcbiAgICBwcmV2LFxuICAgIG5leHRcbiAgfTtcbiAgd2F0Y2goY3VycmVudFBhZ2UsICgpID0+IHtcbiAgICBvblBhZ2VDaGFuZ2UocmVhY3RpdmUocmV0dXJuVmFsdWUpKTtcbiAgfSk7XG4gIHdhdGNoKGN1cnJlbnRQYWdlU2l6ZSwgKCkgPT4ge1xuICAgIG9uUGFnZVNpemVDaGFuZ2UocmVhY3RpdmUocmV0dXJuVmFsdWUpKTtcbiAgfSk7XG4gIHdhdGNoKHBhZ2VDb3VudCwgKCkgPT4ge1xuICAgIG9uUGFnZUNvdW50Q2hhbmdlKHJlYWN0aXZlKHJldHVyblZhbHVlKSk7XG4gIH0pO1xuICByZXR1cm4gcmV0dXJuVmFsdWU7XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VPbmxpbmUob3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHsgaXNPbmxpbmUgfSA9IHVzZU5ldHdvcmsob3B0aW9ucyk7XG4gIHJldHVybiBpc09ubGluZTtcbn1cblxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHVzZVBhZ2VMZWF2ZShvcHRpb25zID0ge30pIHtcbiAgY29uc3QgeyB3aW5kb3cgPSBkZWZhdWx0V2luZG93IH0gPSBvcHRpb25zO1xuICBjb25zdCBpc0xlZnQgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgY29uc3QgaGFuZGxlciA9IChldmVudCkgPT4ge1xuICAgIGlmICghd2luZG93KVxuICAgICAgcmV0dXJuO1xuICAgIGV2ZW50ID0gZXZlbnQgfHwgd2luZG93LmV2ZW50O1xuICAgIGNvbnN0IGZyb20gPSBldmVudC5yZWxhdGVkVGFyZ2V0IHx8IGV2ZW50LnRvRWxlbWVudDtcbiAgICBpc0xlZnQudmFsdWUgPSAhZnJvbTtcbiAgfTtcbiAgaWYgKHdpbmRvdykge1xuICAgIGNvbnN0IGxpc3RlbmVyT3B0aW9ucyA9IHsgcGFzc2l2ZTogdHJ1ZSB9O1xuICAgIHVzZUV2ZW50TGlzdGVuZXIod2luZG93LCBcIm1vdXNlb3V0XCIsIGhhbmRsZXIsIGxpc3RlbmVyT3B0aW9ucyk7XG4gICAgdXNlRXZlbnRMaXN0ZW5lcih3aW5kb3cuZG9jdW1lbnQsIFwibW91c2VsZWF2ZVwiLCBoYW5kbGVyLCBsaXN0ZW5lck9wdGlvbnMpO1xuICAgIHVzZUV2ZW50TGlzdGVuZXIod2luZG93LmRvY3VtZW50LCBcIm1vdXNlZW50ZXJcIiwgaGFuZGxlciwgbGlzdGVuZXJPcHRpb25zKTtcbiAgfVxuICByZXR1cm4gaXNMZWZ0O1xufVxuXG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gdXNlU2NyZWVuT3JpZW50YXRpb24ob3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICB3aW5kb3cgPSBkZWZhdWx0V2luZG93XG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBpc1N1cHBvcnRlZCA9IHVzZVN1cHBvcnRlZCgoKSA9PiB3aW5kb3cgJiYgXCJzY3JlZW5cIiBpbiB3aW5kb3cgJiYgXCJvcmllbnRhdGlvblwiIGluIHdpbmRvdy5zY3JlZW4pO1xuICBjb25zdCBzY3JlZW5PcmllbnRhdGlvbiA9IGlzU3VwcG9ydGVkLnZhbHVlID8gd2luZG93LnNjcmVlbi5vcmllbnRhdGlvbiA6IHt9O1xuICBjb25zdCBvcmllbnRhdGlvbiA9IHJlZihzY3JlZW5PcmllbnRhdGlvbi50eXBlKTtcbiAgY29uc3QgYW5nbGUgPSBzaGFsbG93UmVmKHNjcmVlbk9yaWVudGF0aW9uLmFuZ2xlIHx8IDApO1xuICBpZiAoaXNTdXBwb3J0ZWQudmFsdWUpIHtcbiAgICB1c2VFdmVudExpc3RlbmVyKHdpbmRvdywgXCJvcmllbnRhdGlvbmNoYW5nZVwiLCAoKSA9PiB7XG4gICAgICBvcmllbnRhdGlvbi52YWx1ZSA9IHNjcmVlbk9yaWVudGF0aW9uLnR5cGU7XG4gICAgICBhbmdsZS52YWx1ZSA9IHNjcmVlbk9yaWVudGF0aW9uLmFuZ2xlO1xuICAgIH0sIHsgcGFzc2l2ZTogdHJ1ZSB9KTtcbiAgfVxuICBjb25zdCBsb2NrT3JpZW50YXRpb24gPSAodHlwZSkgPT4ge1xuICAgIGlmIChpc1N1cHBvcnRlZC52YWx1ZSAmJiB0eXBlb2Ygc2NyZWVuT3JpZW50YXRpb24ubG9jayA9PT0gXCJmdW5jdGlvblwiKVxuICAgICAgcmV0dXJuIHNjcmVlbk9yaWVudGF0aW9uLmxvY2sodHlwZSk7XG4gICAgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBFcnJvcihcIk5vdCBzdXBwb3J0ZWRcIikpO1xuICB9O1xuICBjb25zdCB1bmxvY2tPcmllbnRhdGlvbiA9ICgpID0+IHtcbiAgICBpZiAoaXNTdXBwb3J0ZWQudmFsdWUgJiYgdHlwZW9mIHNjcmVlbk9yaWVudGF0aW9uLnVubG9jayA9PT0gXCJmdW5jdGlvblwiKVxuICAgICAgc2NyZWVuT3JpZW50YXRpb24udW5sb2NrKCk7XG4gIH07XG4gIHJldHVybiB7XG4gICAgaXNTdXBwb3J0ZWQsXG4gICAgb3JpZW50YXRpb24sXG4gICAgYW5nbGUsXG4gICAgbG9ja09yaWVudGF0aW9uLFxuICAgIHVubG9ja09yaWVudGF0aW9uXG4gIH07XG59XG5cbmZ1bmN0aW9uIHVzZVBhcmFsbGF4KHRhcmdldCwgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBkZXZpY2VPcmllbnRhdGlvblRpbHRBZGp1c3QgPSAoaSkgPT4gaSxcbiAgICBkZXZpY2VPcmllbnRhdGlvblJvbGxBZGp1c3QgPSAoaSkgPT4gaSxcbiAgICBtb3VzZVRpbHRBZGp1c3QgPSAoaSkgPT4gaSxcbiAgICBtb3VzZVJvbGxBZGp1c3QgPSAoaSkgPT4gaSxcbiAgICB3aW5kb3cgPSBkZWZhdWx0V2luZG93XG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBvcmllbnRhdGlvbiA9IHJlYWN0aXZlKHVzZURldmljZU9yaWVudGF0aW9uKHsgd2luZG93IH0pKTtcbiAgY29uc3Qgc2NyZWVuT3JpZW50YXRpb24gPSByZWFjdGl2ZSh1c2VTY3JlZW5PcmllbnRhdGlvbih7IHdpbmRvdyB9KSk7XG4gIGNvbnN0IHtcbiAgICBlbGVtZW50WDogeCxcbiAgICBlbGVtZW50WTogeSxcbiAgICBlbGVtZW50V2lkdGg6IHdpZHRoLFxuICAgIGVsZW1lbnRIZWlnaHQ6IGhlaWdodFxuICB9ID0gdXNlTW91c2VJbkVsZW1lbnQodGFyZ2V0LCB7IGhhbmRsZU91dHNpZGU6IGZhbHNlLCB3aW5kb3cgfSk7XG4gIGNvbnN0IHNvdXJjZSA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICBpZiAob3JpZW50YXRpb24uaXNTdXBwb3J0ZWQgJiYgKG9yaWVudGF0aW9uLmFscGhhICE9IG51bGwgJiYgb3JpZW50YXRpb24uYWxwaGEgIT09IDAgfHwgb3JpZW50YXRpb24uZ2FtbWEgIT0gbnVsbCAmJiBvcmllbnRhdGlvbi5nYW1tYSAhPT0gMCkpIHtcbiAgICAgIHJldHVybiBcImRldmljZU9yaWVudGF0aW9uXCI7XG4gICAgfVxuICAgIHJldHVybiBcIm1vdXNlXCI7XG4gIH0pO1xuICBjb25zdCByb2xsID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIGlmIChzb3VyY2UudmFsdWUgPT09IFwiZGV2aWNlT3JpZW50YXRpb25cIikge1xuICAgICAgbGV0IHZhbHVlO1xuICAgICAgc3dpdGNoIChzY3JlZW5PcmllbnRhdGlvbi5vcmllbnRhdGlvbikge1xuICAgICAgICBjYXNlIFwibGFuZHNjYXBlLXByaW1hcnlcIjpcbiAgICAgICAgICB2YWx1ZSA9IG9yaWVudGF0aW9uLmdhbW1hIC8gOTA7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJsYW5kc2NhcGUtc2Vjb25kYXJ5XCI6XG4gICAgICAgICAgdmFsdWUgPSAtb3JpZW50YXRpb24uZ2FtbWEgLyA5MDtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcInBvcnRyYWl0LXByaW1hcnlcIjpcbiAgICAgICAgICB2YWx1ZSA9IC1vcmllbnRhdGlvbi5iZXRhIC8gOTA7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJwb3J0cmFpdC1zZWNvbmRhcnlcIjpcbiAgICAgICAgICB2YWx1ZSA9IG9yaWVudGF0aW9uLmJldGEgLyA5MDtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICB2YWx1ZSA9IC1vcmllbnRhdGlvbi5iZXRhIC8gOTA7XG4gICAgICB9XG4gICAgICByZXR1cm4gZGV2aWNlT3JpZW50YXRpb25Sb2xsQWRqdXN0KHZhbHVlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgdmFsdWUgPSAtKHkudmFsdWUgLSBoZWlnaHQudmFsdWUgLyAyKSAvIGhlaWdodC52YWx1ZTtcbiAgICAgIHJldHVybiBtb3VzZVJvbGxBZGp1c3QodmFsdWUpO1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IHRpbHQgPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgaWYgKHNvdXJjZS52YWx1ZSA9PT0gXCJkZXZpY2VPcmllbnRhdGlvblwiKSB7XG4gICAgICBsZXQgdmFsdWU7XG4gICAgICBzd2l0Y2ggKHNjcmVlbk9yaWVudGF0aW9uLm9yaWVudGF0aW9uKSB7XG4gICAgICAgIGNhc2UgXCJsYW5kc2NhcGUtcHJpbWFyeVwiOlxuICAgICAgICAgIHZhbHVlID0gb3JpZW50YXRpb24uYmV0YSAvIDkwO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwibGFuZHNjYXBlLXNlY29uZGFyeVwiOlxuICAgICAgICAgIHZhbHVlID0gLW9yaWVudGF0aW9uLmJldGEgLyA5MDtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcInBvcnRyYWl0LXByaW1hcnlcIjpcbiAgICAgICAgICB2YWx1ZSA9IG9yaWVudGF0aW9uLmdhbW1hIC8gOTA7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJwb3J0cmFpdC1zZWNvbmRhcnlcIjpcbiAgICAgICAgICB2YWx1ZSA9IC1vcmllbnRhdGlvbi5nYW1tYSAvIDkwO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgIHZhbHVlID0gb3JpZW50YXRpb24uZ2FtbWEgLyA5MDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBkZXZpY2VPcmllbnRhdGlvblRpbHRBZGp1c3QodmFsdWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCB2YWx1ZSA9ICh4LnZhbHVlIC0gd2lkdGgudmFsdWUgLyAyKSAvIHdpZHRoLnZhbHVlO1xuICAgICAgcmV0dXJuIG1vdXNlVGlsdEFkanVzdCh2YWx1ZSk7XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIHsgcm9sbCwgdGlsdCwgc291cmNlIH07XG59XG5cbmZ1bmN0aW9uIHVzZVBhcmVudEVsZW1lbnQoZWxlbWVudCA9IHVzZUN1cnJlbnRFbGVtZW50KCkpIHtcbiAgY29uc3QgcGFyZW50RWxlbWVudCA9IHNoYWxsb3dSZWYoKTtcbiAgY29uc3QgdXBkYXRlID0gKCkgPT4ge1xuICAgIGNvbnN0IGVsID0gdW5yZWZFbGVtZW50KGVsZW1lbnQpO1xuICAgIGlmIChlbClcbiAgICAgIHBhcmVudEVsZW1lbnQudmFsdWUgPSBlbC5wYXJlbnRFbGVtZW50O1xuICB9O1xuICB0cnlPbk1vdW50ZWQodXBkYXRlKTtcbiAgd2F0Y2goKCkgPT4gdG9WYWx1ZShlbGVtZW50KSwgdXBkYXRlKTtcbiAgcmV0dXJuIHBhcmVudEVsZW1lbnQ7XG59XG5cbmZ1bmN0aW9uIHVzZVBlcmZvcm1hbmNlT2JzZXJ2ZXIob3B0aW9ucywgY2FsbGJhY2spIHtcbiAgY29uc3Qge1xuICAgIHdpbmRvdyA9IGRlZmF1bHRXaW5kb3csXG4gICAgaW1tZWRpYXRlID0gdHJ1ZSxcbiAgICAuLi5wZXJmb3JtYW5jZU9wdGlvbnNcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGlzU3VwcG9ydGVkID0gdXNlU3VwcG9ydGVkKCgpID0+IHdpbmRvdyAmJiBcIlBlcmZvcm1hbmNlT2JzZXJ2ZXJcIiBpbiB3aW5kb3cpO1xuICBsZXQgb2JzZXJ2ZXI7XG4gIGNvbnN0IHN0b3AgPSAoKSA9PiB7XG4gICAgb2JzZXJ2ZXIgPT0gbnVsbCA/IHZvaWQgMCA6IG9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgfTtcbiAgY29uc3Qgc3RhcnQgPSAoKSA9PiB7XG4gICAgaWYgKGlzU3VwcG9ydGVkLnZhbHVlKSB7XG4gICAgICBzdG9wKCk7XG4gICAgICBvYnNlcnZlciA9IG5ldyBQZXJmb3JtYW5jZU9ic2VydmVyKGNhbGxiYWNrKTtcbiAgICAgIG9ic2VydmVyLm9ic2VydmUocGVyZm9ybWFuY2VPcHRpb25zKTtcbiAgICB9XG4gIH07XG4gIHRyeU9uU2NvcGVEaXNwb3NlKHN0b3ApO1xuICBpZiAoaW1tZWRpYXRlKVxuICAgIHN0YXJ0KCk7XG4gIHJldHVybiB7XG4gICAgaXNTdXBwb3J0ZWQsXG4gICAgc3RhcnQsXG4gICAgc3RvcFxuICB9O1xufVxuXG5jb25zdCBkZWZhdWx0U3RhdGUgPSB7XG4gIHg6IDAsXG4gIHk6IDAsXG4gIHBvaW50ZXJJZDogMCxcbiAgcHJlc3N1cmU6IDAsXG4gIHRpbHRYOiAwLFxuICB0aWx0WTogMCxcbiAgd2lkdGg6IDAsXG4gIGhlaWdodDogMCxcbiAgdHdpc3Q6IDAsXG4gIHBvaW50ZXJUeXBlOiBudWxsXG59O1xuY29uc3Qga2V5cyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3Qua2V5cyhkZWZhdWx0U3RhdGUpO1xuZnVuY3Rpb24gdXNlUG9pbnRlcihvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIHRhcmdldCA9IGRlZmF1bHRXaW5kb3dcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGlzSW5zaWRlID0gc2hhbGxvd1JlZihmYWxzZSk7XG4gIGNvbnN0IHN0YXRlID0gc2hhbGxvd1JlZihvcHRpb25zLmluaXRpYWxWYWx1ZSB8fCB7fSk7XG4gIE9iamVjdC5hc3NpZ24oc3RhdGUudmFsdWUsIGRlZmF1bHRTdGF0ZSwgc3RhdGUudmFsdWUpO1xuICBjb25zdCBoYW5kbGVyID0gKGV2ZW50KSA9PiB7XG4gICAgaXNJbnNpZGUudmFsdWUgPSB0cnVlO1xuICAgIGlmIChvcHRpb25zLnBvaW50ZXJUeXBlcyAmJiAhb3B0aW9ucy5wb2ludGVyVHlwZXMuaW5jbHVkZXMoZXZlbnQucG9pbnRlclR5cGUpKVxuICAgICAgcmV0dXJuO1xuICAgIHN0YXRlLnZhbHVlID0gb2JqZWN0UGljayhldmVudCwga2V5cywgZmFsc2UpO1xuICB9O1xuICBpZiAodGFyZ2V0KSB7XG4gICAgY29uc3QgbGlzdGVuZXJPcHRpb25zID0geyBwYXNzaXZlOiB0cnVlIH07XG4gICAgdXNlRXZlbnRMaXN0ZW5lcih0YXJnZXQsIFtcInBvaW50ZXJkb3duXCIsIFwicG9pbnRlcm1vdmVcIiwgXCJwb2ludGVydXBcIl0sIGhhbmRsZXIsIGxpc3RlbmVyT3B0aW9ucyk7XG4gICAgdXNlRXZlbnRMaXN0ZW5lcih0YXJnZXQsIFwicG9pbnRlcmxlYXZlXCIsICgpID0+IGlzSW5zaWRlLnZhbHVlID0gZmFsc2UsIGxpc3RlbmVyT3B0aW9ucyk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICAuLi50b1JlZnMoc3RhdGUpLFxuICAgIGlzSW5zaWRlXG4gIH07XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VQb2ludGVyTG9jayh0YXJnZXQsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7IGRvY3VtZW50ID0gZGVmYXVsdERvY3VtZW50IH0gPSBvcHRpb25zO1xuICBjb25zdCBpc1N1cHBvcnRlZCA9IHVzZVN1cHBvcnRlZCgoKSA9PiBkb2N1bWVudCAmJiBcInBvaW50ZXJMb2NrRWxlbWVudFwiIGluIGRvY3VtZW50KTtcbiAgY29uc3QgZWxlbWVudCA9IHNoYWxsb3dSZWYoKTtcbiAgY29uc3QgdHJpZ2dlckVsZW1lbnQgPSBzaGFsbG93UmVmKCk7XG4gIGxldCB0YXJnZXRFbGVtZW50O1xuICBpZiAoaXNTdXBwb3J0ZWQudmFsdWUpIHtcbiAgICBjb25zdCBsaXN0ZW5lck9wdGlvbnMgPSB7IHBhc3NpdmU6IHRydWUgfTtcbiAgICB1c2VFdmVudExpc3RlbmVyKGRvY3VtZW50LCBcInBvaW50ZXJsb2NrY2hhbmdlXCIsICgpID0+IHtcbiAgICAgIHZhciBfYTtcbiAgICAgIGNvbnN0IGN1cnJlbnRFbGVtZW50ID0gKF9hID0gZG9jdW1lbnQucG9pbnRlckxvY2tFbGVtZW50KSAhPSBudWxsID8gX2EgOiBlbGVtZW50LnZhbHVlO1xuICAgICAgaWYgKHRhcmdldEVsZW1lbnQgJiYgY3VycmVudEVsZW1lbnQgPT09IHRhcmdldEVsZW1lbnQpIHtcbiAgICAgICAgZWxlbWVudC52YWx1ZSA9IGRvY3VtZW50LnBvaW50ZXJMb2NrRWxlbWVudDtcbiAgICAgICAgaWYgKCFlbGVtZW50LnZhbHVlKVxuICAgICAgICAgIHRhcmdldEVsZW1lbnQgPSB0cmlnZ2VyRWxlbWVudC52YWx1ZSA9IG51bGw7XG4gICAgICB9XG4gICAgfSwgbGlzdGVuZXJPcHRpb25zKTtcbiAgICB1c2VFdmVudExpc3RlbmVyKGRvY3VtZW50LCBcInBvaW50ZXJsb2NrZXJyb3JcIiwgKCkgPT4ge1xuICAgICAgdmFyIF9hO1xuICAgICAgY29uc3QgY3VycmVudEVsZW1lbnQgPSAoX2EgPSBkb2N1bWVudC5wb2ludGVyTG9ja0VsZW1lbnQpICE9IG51bGwgPyBfYSA6IGVsZW1lbnQudmFsdWU7XG4gICAgICBpZiAodGFyZ2V0RWxlbWVudCAmJiBjdXJyZW50RWxlbWVudCA9PT0gdGFyZ2V0RWxlbWVudCkge1xuICAgICAgICBjb25zdCBhY3Rpb24gPSBkb2N1bWVudC5wb2ludGVyTG9ja0VsZW1lbnQgPyBcInJlbGVhc2VcIiA6IFwiYWNxdWlyZVwiO1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byAke2FjdGlvbn0gcG9pbnRlciBsb2NrLmApO1xuICAgICAgfVxuICAgIH0sIGxpc3RlbmVyT3B0aW9ucyk7XG4gIH1cbiAgYXN5bmMgZnVuY3Rpb24gbG9jayhlKSB7XG4gICAgdmFyIF9hO1xuICAgIGlmICghaXNTdXBwb3J0ZWQudmFsdWUpXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJQb2ludGVyIExvY2sgQVBJIGlzIG5vdCBzdXBwb3J0ZWQgYnkgeW91ciBicm93c2VyLlwiKTtcbiAgICB0cmlnZ2VyRWxlbWVudC52YWx1ZSA9IGUgaW5zdGFuY2VvZiBFdmVudCA/IGUuY3VycmVudFRhcmdldCA6IG51bGw7XG4gICAgdGFyZ2V0RWxlbWVudCA9IGUgaW5zdGFuY2VvZiBFdmVudCA/IChfYSA9IHVucmVmRWxlbWVudCh0YXJnZXQpKSAhPSBudWxsID8gX2EgOiB0cmlnZ2VyRWxlbWVudC52YWx1ZSA6IHVucmVmRWxlbWVudChlKTtcbiAgICBpZiAoIXRhcmdldEVsZW1lbnQpXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUYXJnZXQgZWxlbWVudCB1bmRlZmluZWQuXCIpO1xuICAgIHRhcmdldEVsZW1lbnQucmVxdWVzdFBvaW50ZXJMb2NrKCk7XG4gICAgcmV0dXJuIGF3YWl0IHVudGlsKGVsZW1lbnQpLnRvQmUodGFyZ2V0RWxlbWVudCk7XG4gIH1cbiAgYXN5bmMgZnVuY3Rpb24gdW5sb2NrKCkge1xuICAgIGlmICghZWxlbWVudC52YWx1ZSlcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICBkb2N1bWVudC5leGl0UG9pbnRlckxvY2soKTtcbiAgICBhd2FpdCB1bnRpbChlbGVtZW50KS50b0JlTnVsbCgpO1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIHJldHVybiB7XG4gICAgaXNTdXBwb3J0ZWQsXG4gICAgZWxlbWVudCxcbiAgICB0cmlnZ2VyRWxlbWVudCxcbiAgICBsb2NrLFxuICAgIHVubG9ja1xuICB9O1xufVxuXG5mdW5jdGlvbiB1c2VQb2ludGVyU3dpcGUodGFyZ2V0LCBvcHRpb25zID0ge30pIHtcbiAgY29uc3QgdGFyZ2V0UmVmID0gdG9SZWYodGFyZ2V0KTtcbiAgY29uc3Qge1xuICAgIHRocmVzaG9sZCA9IDUwLFxuICAgIG9uU3dpcGUsXG4gICAgb25Td2lwZUVuZCxcbiAgICBvblN3aXBlU3RhcnQsXG4gICAgZGlzYWJsZVRleHRTZWxlY3QgPSBmYWxzZVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgcG9zU3RhcnQgPSByZWFjdGl2ZSh7IHg6IDAsIHk6IDAgfSk7XG4gIGNvbnN0IHVwZGF0ZVBvc1N0YXJ0ID0gKHgsIHkpID0+IHtcbiAgICBwb3NTdGFydC54ID0geDtcbiAgICBwb3NTdGFydC55ID0geTtcbiAgfTtcbiAgY29uc3QgcG9zRW5kID0gcmVhY3RpdmUoeyB4OiAwLCB5OiAwIH0pO1xuICBjb25zdCB1cGRhdGVQb3NFbmQgPSAoeCwgeSkgPT4ge1xuICAgIHBvc0VuZC54ID0geDtcbiAgICBwb3NFbmQueSA9IHk7XG4gIH07XG4gIGNvbnN0IGRpc3RhbmNlWCA9IGNvbXB1dGVkKCgpID0+IHBvc1N0YXJ0LnggLSBwb3NFbmQueCk7XG4gIGNvbnN0IGRpc3RhbmNlWSA9IGNvbXB1dGVkKCgpID0+IHBvc1N0YXJ0LnkgLSBwb3NFbmQueSk7XG4gIGNvbnN0IHsgbWF4LCBhYnMgfSA9IE1hdGg7XG4gIGNvbnN0IGlzVGhyZXNob2xkRXhjZWVkZWQgPSBjb21wdXRlZCgoKSA9PiBtYXgoYWJzKGRpc3RhbmNlWC52YWx1ZSksIGFicyhkaXN0YW5jZVkudmFsdWUpKSA+PSB0aHJlc2hvbGQpO1xuICBjb25zdCBpc1N3aXBpbmcgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgY29uc3QgaXNQb2ludGVyRG93biA9IHNoYWxsb3dSZWYoZmFsc2UpO1xuICBjb25zdCBkaXJlY3Rpb24gPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgaWYgKCFpc1RocmVzaG9sZEV4Y2VlZGVkLnZhbHVlKVxuICAgICAgcmV0dXJuIFwibm9uZVwiO1xuICAgIGlmIChhYnMoZGlzdGFuY2VYLnZhbHVlKSA+IGFicyhkaXN0YW5jZVkudmFsdWUpKSB7XG4gICAgICByZXR1cm4gZGlzdGFuY2VYLnZhbHVlID4gMCA/IFwibGVmdFwiIDogXCJyaWdodFwiO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gZGlzdGFuY2VZLnZhbHVlID4gMCA/IFwidXBcIiA6IFwiZG93blwiO1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IGV2ZW50SXNBbGxvd2VkID0gKGUpID0+IHtcbiAgICB2YXIgX2EsIF9iLCBfYztcbiAgICBjb25zdCBpc1JlbGVhc2luZ0J1dHRvbiA9IGUuYnV0dG9ucyA9PT0gMDtcbiAgICBjb25zdCBpc1ByaW1hcnlCdXR0b24gPSBlLmJ1dHRvbnMgPT09IDE7XG4gICAgcmV0dXJuIChfYyA9IChfYiA9IChfYSA9IG9wdGlvbnMucG9pbnRlclR5cGVzKSA9PSBudWxsID8gdm9pZCAwIDogX2EuaW5jbHVkZXMoZS5wb2ludGVyVHlwZSkpICE9IG51bGwgPyBfYiA6IGlzUmVsZWFzaW5nQnV0dG9uIHx8IGlzUHJpbWFyeUJ1dHRvbikgIT0gbnVsbCA/IF9jIDogdHJ1ZTtcbiAgfTtcbiAgY29uc3QgbGlzdGVuZXJPcHRpb25zID0geyBwYXNzaXZlOiB0cnVlIH07XG4gIGNvbnN0IHN0b3BzID0gW1xuICAgIHVzZUV2ZW50TGlzdGVuZXIodGFyZ2V0LCBcInBvaW50ZXJkb3duXCIsIChlKSA9PiB7XG4gICAgICBpZiAoIWV2ZW50SXNBbGxvd2VkKGUpKVxuICAgICAgICByZXR1cm47XG4gICAgICBpc1BvaW50ZXJEb3duLnZhbHVlID0gdHJ1ZTtcbiAgICAgIGNvbnN0IGV2ZW50VGFyZ2V0ID0gZS50YXJnZXQ7XG4gICAgICBldmVudFRhcmdldCA9PSBudWxsID8gdm9pZCAwIDogZXZlbnRUYXJnZXQuc2V0UG9pbnRlckNhcHR1cmUoZS5wb2ludGVySWQpO1xuICAgICAgY29uc3QgeyBjbGllbnRYOiB4LCBjbGllbnRZOiB5IH0gPSBlO1xuICAgICAgdXBkYXRlUG9zU3RhcnQoeCwgeSk7XG4gICAgICB1cGRhdGVQb3NFbmQoeCwgeSk7XG4gICAgICBvblN3aXBlU3RhcnQgPT0gbnVsbCA/IHZvaWQgMCA6IG9uU3dpcGVTdGFydChlKTtcbiAgICB9LCBsaXN0ZW5lck9wdGlvbnMpLFxuICAgIHVzZUV2ZW50TGlzdGVuZXIodGFyZ2V0LCBcInBvaW50ZXJtb3ZlXCIsIChlKSA9PiB7XG4gICAgICBpZiAoIWV2ZW50SXNBbGxvd2VkKGUpKVxuICAgICAgICByZXR1cm47XG4gICAgICBpZiAoIWlzUG9pbnRlckRvd24udmFsdWUpXG4gICAgICAgIHJldHVybjtcbiAgICAgIGNvbnN0IHsgY2xpZW50WDogeCwgY2xpZW50WTogeSB9ID0gZTtcbiAgICAgIHVwZGF0ZVBvc0VuZCh4LCB5KTtcbiAgICAgIGlmICghaXNTd2lwaW5nLnZhbHVlICYmIGlzVGhyZXNob2xkRXhjZWVkZWQudmFsdWUpXG4gICAgICAgIGlzU3dpcGluZy52YWx1ZSA9IHRydWU7XG4gICAgICBpZiAoaXNTd2lwaW5nLnZhbHVlKVxuICAgICAgICBvblN3aXBlID09IG51bGwgPyB2b2lkIDAgOiBvblN3aXBlKGUpO1xuICAgIH0sIGxpc3RlbmVyT3B0aW9ucyksXG4gICAgdXNlRXZlbnRMaXN0ZW5lcih0YXJnZXQsIFwicG9pbnRlcnVwXCIsIChlKSA9PiB7XG4gICAgICBpZiAoIWV2ZW50SXNBbGxvd2VkKGUpKVxuICAgICAgICByZXR1cm47XG4gICAgICBpZiAoaXNTd2lwaW5nLnZhbHVlKVxuICAgICAgICBvblN3aXBlRW5kID09IG51bGwgPyB2b2lkIDAgOiBvblN3aXBlRW5kKGUsIGRpcmVjdGlvbi52YWx1ZSk7XG4gICAgICBpc1BvaW50ZXJEb3duLnZhbHVlID0gZmFsc2U7XG4gICAgICBpc1N3aXBpbmcudmFsdWUgPSBmYWxzZTtcbiAgICB9LCBsaXN0ZW5lck9wdGlvbnMpXG4gIF07XG4gIHRyeU9uTW91bnRlZCgoKSA9PiB7XG4gICAgdmFyIF9hLCBfYiwgX2MsIF9kLCBfZSwgX2YsIF9nLCBfaDtcbiAgICAoX2IgPSAoX2EgPSB0YXJnZXRSZWYudmFsdWUpID09IG51bGwgPyB2b2lkIDAgOiBfYS5zdHlsZSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9iLnNldFByb3BlcnR5KFwidG91Y2gtYWN0aW9uXCIsIFwicGFuLXlcIik7XG4gICAgaWYgKGRpc2FibGVUZXh0U2VsZWN0KSB7XG4gICAgICAoX2QgPSAoX2MgPSB0YXJnZXRSZWYudmFsdWUpID09IG51bGwgPyB2b2lkIDAgOiBfYy5zdHlsZSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9kLnNldFByb3BlcnR5KFwiLXdlYmtpdC11c2VyLXNlbGVjdFwiLCBcIm5vbmVcIik7XG4gICAgICAoX2YgPSAoX2UgPSB0YXJnZXRSZWYudmFsdWUpID09IG51bGwgPyB2b2lkIDAgOiBfZS5zdHlsZSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9mLnNldFByb3BlcnR5KFwiLW1zLXVzZXItc2VsZWN0XCIsIFwibm9uZVwiKTtcbiAgICAgIChfaCA9IChfZyA9IHRhcmdldFJlZi52YWx1ZSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9nLnN0eWxlKSA9PSBudWxsID8gdm9pZCAwIDogX2guc2V0UHJvcGVydHkoXCJ1c2VyLXNlbGVjdFwiLCBcIm5vbmVcIik7XG4gICAgfVxuICB9KTtcbiAgY29uc3Qgc3RvcCA9ICgpID0+IHN0b3BzLmZvckVhY2goKHMpID0+IHMoKSk7XG4gIHJldHVybiB7XG4gICAgaXNTd2lwaW5nOiByZWFkb25seShpc1N3aXBpbmcpLFxuICAgIGRpcmVjdGlvbjogcmVhZG9ubHkoZGlyZWN0aW9uKSxcbiAgICBwb3NTdGFydDogcmVhZG9ubHkocG9zU3RhcnQpLFxuICAgIHBvc0VuZDogcmVhZG9ubHkocG9zRW5kKSxcbiAgICBkaXN0YW5jZVgsXG4gICAgZGlzdGFuY2VZLFxuICAgIHN0b3BcbiAgfTtcbn1cblxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHVzZVByZWZlcnJlZENvbG9yU2NoZW1lKG9wdGlvbnMpIHtcbiAgY29uc3QgaXNMaWdodCA9IHVzZU1lZGlhUXVlcnkoXCIocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KVwiLCBvcHRpb25zKTtcbiAgY29uc3QgaXNEYXJrID0gdXNlTWVkaWFRdWVyeShcIihwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaylcIiwgb3B0aW9ucyk7XG4gIHJldHVybiBjb21wdXRlZCgoKSA9PiB7XG4gICAgaWYgKGlzRGFyay52YWx1ZSlcbiAgICAgIHJldHVybiBcImRhcmtcIjtcbiAgICBpZiAoaXNMaWdodC52YWx1ZSlcbiAgICAgIHJldHVybiBcImxpZ2h0XCI7XG4gICAgcmV0dXJuIFwibm8tcHJlZmVyZW5jZVwiO1xuICB9KTtcbn1cblxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHVzZVByZWZlcnJlZENvbnRyYXN0KG9wdGlvbnMpIHtcbiAgY29uc3QgaXNNb3JlID0gdXNlTWVkaWFRdWVyeShcIihwcmVmZXJzLWNvbnRyYXN0OiBtb3JlKVwiLCBvcHRpb25zKTtcbiAgY29uc3QgaXNMZXNzID0gdXNlTWVkaWFRdWVyeShcIihwcmVmZXJzLWNvbnRyYXN0OiBsZXNzKVwiLCBvcHRpb25zKTtcbiAgY29uc3QgaXNDdXN0b20gPSB1c2VNZWRpYVF1ZXJ5KFwiKHByZWZlcnMtY29udHJhc3Q6IGN1c3RvbSlcIiwgb3B0aW9ucyk7XG4gIHJldHVybiBjb21wdXRlZCgoKSA9PiB7XG4gICAgaWYgKGlzTW9yZS52YWx1ZSlcbiAgICAgIHJldHVybiBcIm1vcmVcIjtcbiAgICBpZiAoaXNMZXNzLnZhbHVlKVxuICAgICAgcmV0dXJuIFwibGVzc1wiO1xuICAgIGlmIChpc0N1c3RvbS52YWx1ZSlcbiAgICAgIHJldHVybiBcImN1c3RvbVwiO1xuICAgIHJldHVybiBcIm5vLXByZWZlcmVuY2VcIjtcbiAgfSk7XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VQcmVmZXJyZWRMYW5ndWFnZXMob3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHsgd2luZG93ID0gZGVmYXVsdFdpbmRvdyB9ID0gb3B0aW9ucztcbiAgaWYgKCF3aW5kb3cpXG4gICAgcmV0dXJuIHNoYWxsb3dSZWYoW1wiZW5cIl0pO1xuICBjb25zdCBuYXZpZ2F0b3IgPSB3aW5kb3cubmF2aWdhdG9yO1xuICBjb25zdCB2YWx1ZSA9IHNoYWxsb3dSZWYobmF2aWdhdG9yLmxhbmd1YWdlcyk7XG4gIHVzZUV2ZW50TGlzdGVuZXIod2luZG93LCBcImxhbmd1YWdlY2hhbmdlXCIsICgpID0+IHtcbiAgICB2YWx1ZS52YWx1ZSA9IG5hdmlnYXRvci5sYW5ndWFnZXM7XG4gIH0sIHsgcGFzc2l2ZTogdHJ1ZSB9KTtcbiAgcmV0dXJuIHZhbHVlO1xufVxuXG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gdXNlUHJlZmVycmVkUmVkdWNlZE1vdGlvbihvcHRpb25zKSB7XG4gIGNvbnN0IGlzUmVkdWNlZCA9IHVzZU1lZGlhUXVlcnkoXCIocHJlZmVycy1yZWR1Y2VkLW1vdGlvbjogcmVkdWNlKVwiLCBvcHRpb25zKTtcbiAgcmV0dXJuIGNvbXB1dGVkKCgpID0+IHtcbiAgICBpZiAoaXNSZWR1Y2VkLnZhbHVlKVxuICAgICAgcmV0dXJuIFwicmVkdWNlXCI7XG4gICAgcmV0dXJuIFwibm8tcHJlZmVyZW5jZVwiO1xuICB9KTtcbn1cblxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHVzZVByZWZlcnJlZFJlZHVjZWRUcmFuc3BhcmVuY3kob3B0aW9ucykge1xuICBjb25zdCBpc1JlZHVjZWQgPSB1c2VNZWRpYVF1ZXJ5KFwiKHByZWZlcnMtcmVkdWNlZC10cmFuc3BhcmVuY3k6IHJlZHVjZSlcIiwgb3B0aW9ucyk7XG4gIHJldHVybiBjb21wdXRlZCgoKSA9PiB7XG4gICAgaWYgKGlzUmVkdWNlZC52YWx1ZSlcbiAgICAgIHJldHVybiBcInJlZHVjZVwiO1xuICAgIHJldHVybiBcIm5vLXByZWZlcmVuY2VcIjtcbiAgfSk7XG59XG5cbmZ1bmN0aW9uIHVzZVByZXZpb3VzKHZhbHVlLCBpbml0aWFsVmFsdWUpIHtcbiAgY29uc3QgcHJldmlvdXMgPSBzaGFsbG93UmVmKGluaXRpYWxWYWx1ZSk7XG4gIHdhdGNoKFxuICAgIHRvUmVmKHZhbHVlKSxcbiAgICAoXywgb2xkVmFsdWUpID0+IHtcbiAgICAgIHByZXZpb3VzLnZhbHVlID0gb2xkVmFsdWU7XG4gICAgfSxcbiAgICB7IGZsdXNoOiBcInN5bmNcIiB9XG4gICk7XG4gIHJldHVybiByZWFkb25seShwcmV2aW91cyk7XG59XG5cbmNvbnN0IHRvcFZhck5hbWUgPSBcIi0tdnVldXNlLXNhZmUtYXJlYS10b3BcIjtcbmNvbnN0IHJpZ2h0VmFyTmFtZSA9IFwiLS12dWV1c2Utc2FmZS1hcmVhLXJpZ2h0XCI7XG5jb25zdCBib3R0b21WYXJOYW1lID0gXCItLXZ1ZXVzZS1zYWZlLWFyZWEtYm90dG9tXCI7XG5jb25zdCBsZWZ0VmFyTmFtZSA9IFwiLS12dWV1c2Utc2FmZS1hcmVhLWxlZnRcIjtcbmZ1bmN0aW9uIHVzZVNjcmVlblNhZmVBcmVhKCkge1xuICBjb25zdCB0b3AgPSBzaGFsbG93UmVmKFwiXCIpO1xuICBjb25zdCByaWdodCA9IHNoYWxsb3dSZWYoXCJcIik7XG4gIGNvbnN0IGJvdHRvbSA9IHNoYWxsb3dSZWYoXCJcIik7XG4gIGNvbnN0IGxlZnQgPSBzaGFsbG93UmVmKFwiXCIpO1xuICBpZiAoaXNDbGllbnQpIHtcbiAgICBjb25zdCB0b3BDc3NWYXIgPSB1c2VDc3NWYXIodG9wVmFyTmFtZSk7XG4gICAgY29uc3QgcmlnaHRDc3NWYXIgPSB1c2VDc3NWYXIocmlnaHRWYXJOYW1lKTtcbiAgICBjb25zdCBib3R0b21Dc3NWYXIgPSB1c2VDc3NWYXIoYm90dG9tVmFyTmFtZSk7XG4gICAgY29uc3QgbGVmdENzc1ZhciA9IHVzZUNzc1ZhcihsZWZ0VmFyTmFtZSk7XG4gICAgdG9wQ3NzVmFyLnZhbHVlID0gXCJlbnYoc2FmZS1hcmVhLWluc2V0LXRvcCwgMHB4KVwiO1xuICAgIHJpZ2h0Q3NzVmFyLnZhbHVlID0gXCJlbnYoc2FmZS1hcmVhLWluc2V0LXJpZ2h0LCAwcHgpXCI7XG4gICAgYm90dG9tQ3NzVmFyLnZhbHVlID0gXCJlbnYoc2FmZS1hcmVhLWluc2V0LWJvdHRvbSwgMHB4KVwiO1xuICAgIGxlZnRDc3NWYXIudmFsdWUgPSBcImVudihzYWZlLWFyZWEtaW5zZXQtbGVmdCwgMHB4KVwiO1xuICAgIHRyeU9uTW91bnRlZCh1cGRhdGUpO1xuICAgIHVzZUV2ZW50TGlzdGVuZXIoXCJyZXNpemVcIiwgdXNlRGVib3VuY2VGbih1cGRhdGUpLCB7IHBhc3NpdmU6IHRydWUgfSk7XG4gIH1cbiAgZnVuY3Rpb24gdXBkYXRlKCkge1xuICAgIHRvcC52YWx1ZSA9IGdldFZhbHVlKHRvcFZhck5hbWUpO1xuICAgIHJpZ2h0LnZhbHVlID0gZ2V0VmFsdWUocmlnaHRWYXJOYW1lKTtcbiAgICBib3R0b20udmFsdWUgPSBnZXRWYWx1ZShib3R0b21WYXJOYW1lKTtcbiAgICBsZWZ0LnZhbHVlID0gZ2V0VmFsdWUobGVmdFZhck5hbWUpO1xuICB9XG4gIHJldHVybiB7XG4gICAgdG9wLFxuICAgIHJpZ2h0LFxuICAgIGJvdHRvbSxcbiAgICBsZWZ0LFxuICAgIHVwZGF0ZVxuICB9O1xufVxuZnVuY3Rpb24gZ2V0VmFsdWUocG9zaXRpb24pIHtcbiAgcmV0dXJuIGdldENvbXB1dGVkU3R5bGUoZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50KS5nZXRQcm9wZXJ0eVZhbHVlKHBvc2l0aW9uKTtcbn1cblxuZnVuY3Rpb24gdXNlU2NyaXB0VGFnKHNyYywgb25Mb2FkZWQgPSBub29wLCBvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGltbWVkaWF0ZSA9IHRydWUsXG4gICAgbWFudWFsID0gZmFsc2UsXG4gICAgdHlwZSA9IFwidGV4dC9qYXZhc2NyaXB0XCIsXG4gICAgYXN5bmMgPSB0cnVlLFxuICAgIGNyb3NzT3JpZ2luLFxuICAgIHJlZmVycmVyUG9saWN5LFxuICAgIG5vTW9kdWxlLFxuICAgIGRlZmVyLFxuICAgIGRvY3VtZW50ID0gZGVmYXVsdERvY3VtZW50LFxuICAgIGF0dHJzID0ge30sXG4gICAgbm9uY2UgPSB2b2lkIDBcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IHNjcmlwdFRhZyA9IHNoYWxsb3dSZWYobnVsbCk7XG4gIGxldCBfcHJvbWlzZSA9IG51bGw7XG4gIGNvbnN0IGxvYWRTY3JpcHQgPSAod2FpdEZvclNjcmlwdExvYWQpID0+IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBjb25zdCByZXNvbHZlV2l0aEVsZW1lbnQgPSAoZWwyKSA9PiB7XG4gICAgICBzY3JpcHRUYWcudmFsdWUgPSBlbDI7XG4gICAgICByZXNvbHZlKGVsMik7XG4gICAgICByZXR1cm4gZWwyO1xuICAgIH07XG4gICAgaWYgKCFkb2N1bWVudCkge1xuICAgICAgcmVzb2x2ZShmYWxzZSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGxldCBzaG91bGRBcHBlbmQgPSBmYWxzZTtcbiAgICBsZXQgZWwgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGBzY3JpcHRbc3JjPVwiJHt0b1ZhbHVlKHNyYyl9XCJdYCk7XG4gICAgaWYgKCFlbCkge1xuICAgICAgZWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic2NyaXB0XCIpO1xuICAgICAgZWwudHlwZSA9IHR5cGU7XG4gICAgICBlbC5hc3luYyA9IGFzeW5jO1xuICAgICAgZWwuc3JjID0gdG9WYWx1ZShzcmMpO1xuICAgICAgaWYgKGRlZmVyKVxuICAgICAgICBlbC5kZWZlciA9IGRlZmVyO1xuICAgICAgaWYgKGNyb3NzT3JpZ2luKVxuICAgICAgICBlbC5jcm9zc09yaWdpbiA9IGNyb3NzT3JpZ2luO1xuICAgICAgaWYgKG5vTW9kdWxlKVxuICAgICAgICBlbC5ub01vZHVsZSA9IG5vTW9kdWxlO1xuICAgICAgaWYgKHJlZmVycmVyUG9saWN5KVxuICAgICAgICBlbC5yZWZlcnJlclBvbGljeSA9IHJlZmVycmVyUG9saWN5O1xuICAgICAgaWYgKG5vbmNlKSB7XG4gICAgICAgIGVsLm5vbmNlID0gbm9uY2U7XG4gICAgICB9XG4gICAgICBPYmplY3QuZW50cmllcyhhdHRycykuZm9yRWFjaCgoW25hbWUsIHZhbHVlXSkgPT4gZWwgPT0gbnVsbCA/IHZvaWQgMCA6IGVsLnNldEF0dHJpYnV0ZShuYW1lLCB2YWx1ZSkpO1xuICAgICAgc2hvdWxkQXBwZW5kID0gdHJ1ZTtcbiAgICB9IGVsc2UgaWYgKGVsLmhhc0F0dHJpYnV0ZShcImRhdGEtbG9hZGVkXCIpKSB7XG4gICAgICByZXNvbHZlV2l0aEVsZW1lbnQoZWwpO1xuICAgIH1cbiAgICBjb25zdCBsaXN0ZW5lck9wdGlvbnMgPSB7XG4gICAgICBwYXNzaXZlOiB0cnVlXG4gICAgfTtcbiAgICB1c2VFdmVudExpc3RlbmVyKGVsLCBcImVycm9yXCIsIChldmVudCkgPT4gcmVqZWN0KGV2ZW50KSwgbGlzdGVuZXJPcHRpb25zKTtcbiAgICB1c2VFdmVudExpc3RlbmVyKGVsLCBcImFib3J0XCIsIChldmVudCkgPT4gcmVqZWN0KGV2ZW50KSwgbGlzdGVuZXJPcHRpb25zKTtcbiAgICB1c2VFdmVudExpc3RlbmVyKGVsLCBcImxvYWRcIiwgKCkgPT4ge1xuICAgICAgZWwuc2V0QXR0cmlidXRlKFwiZGF0YS1sb2FkZWRcIiwgXCJ0cnVlXCIpO1xuICAgICAgb25Mb2FkZWQoZWwpO1xuICAgICAgcmVzb2x2ZVdpdGhFbGVtZW50KGVsKTtcbiAgICB9LCBsaXN0ZW5lck9wdGlvbnMpO1xuICAgIGlmIChzaG91bGRBcHBlbmQpXG4gICAgICBlbCA9IGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoZWwpO1xuICAgIGlmICghd2FpdEZvclNjcmlwdExvYWQpXG4gICAgICByZXNvbHZlV2l0aEVsZW1lbnQoZWwpO1xuICB9KTtcbiAgY29uc3QgbG9hZCA9ICh3YWl0Rm9yU2NyaXB0TG9hZCA9IHRydWUpID0+IHtcbiAgICBpZiAoIV9wcm9taXNlKVxuICAgICAgX3Byb21pc2UgPSBsb2FkU2NyaXB0KHdhaXRGb3JTY3JpcHRMb2FkKTtcbiAgICByZXR1cm4gX3Byb21pc2U7XG4gIH07XG4gIGNvbnN0IHVubG9hZCA9ICgpID0+IHtcbiAgICBpZiAoIWRvY3VtZW50KVxuICAgICAgcmV0dXJuO1xuICAgIF9wcm9taXNlID0gbnVsbDtcbiAgICBpZiAoc2NyaXB0VGFnLnZhbHVlKVxuICAgICAgc2NyaXB0VGFnLnZhbHVlID0gbnVsbDtcbiAgICBjb25zdCBlbCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoYHNjcmlwdFtzcmM9XCIke3RvVmFsdWUoc3JjKX1cIl1gKTtcbiAgICBpZiAoZWwpXG4gICAgICBkb2N1bWVudC5oZWFkLnJlbW92ZUNoaWxkKGVsKTtcbiAgfTtcbiAgaWYgKGltbWVkaWF0ZSAmJiAhbWFudWFsKVxuICAgIHRyeU9uTW91bnRlZChsb2FkKTtcbiAgaWYgKCFtYW51YWwpXG4gICAgdHJ5T25Vbm1vdW50ZWQodW5sb2FkKTtcbiAgcmV0dXJuIHsgc2NyaXB0VGFnLCBsb2FkLCB1bmxvYWQgfTtcbn1cblxuZnVuY3Rpb24gY2hlY2tPdmVyZmxvd1Njcm9sbChlbGUpIHtcbiAgY29uc3Qgc3R5bGUgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShlbGUpO1xuICBpZiAoc3R5bGUub3ZlcmZsb3dYID09PSBcInNjcm9sbFwiIHx8IHN0eWxlLm92ZXJmbG93WSA9PT0gXCJzY3JvbGxcIiB8fCBzdHlsZS5vdmVyZmxvd1ggPT09IFwiYXV0b1wiICYmIGVsZS5jbGllbnRXaWR0aCA8IGVsZS5zY3JvbGxXaWR0aCB8fCBzdHlsZS5vdmVyZmxvd1kgPT09IFwiYXV0b1wiICYmIGVsZS5jbGllbnRIZWlnaHQgPCBlbGUuc2Nyb2xsSGVpZ2h0KSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgcGFyZW50ID0gZWxlLnBhcmVudE5vZGU7XG4gICAgaWYgKCFwYXJlbnQgfHwgcGFyZW50LnRhZ05hbWUgPT09IFwiQk9EWVwiKVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIHJldHVybiBjaGVja092ZXJmbG93U2Nyb2xsKHBhcmVudCk7XG4gIH1cbn1cbmZ1bmN0aW9uIHByZXZlbnREZWZhdWx0KHJhd0V2ZW50KSB7XG4gIGNvbnN0IGUgPSByYXdFdmVudCB8fCB3aW5kb3cuZXZlbnQ7XG4gIGNvbnN0IF90YXJnZXQgPSBlLnRhcmdldDtcbiAgaWYgKGNoZWNrT3ZlcmZsb3dTY3JvbGwoX3RhcmdldCkpXG4gICAgcmV0dXJuIGZhbHNlO1xuICBpZiAoZS50b3VjaGVzLmxlbmd0aCA+IDEpXG4gICAgcmV0dXJuIHRydWU7XG4gIGlmIChlLnByZXZlbnREZWZhdWx0KVxuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgcmV0dXJuIGZhbHNlO1xufVxuY29uc3QgZWxJbml0aWFsT3ZlcmZsb3cgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbmZ1bmN0aW9uIHVzZVNjcm9sbExvY2soZWxlbWVudCwgaW5pdGlhbFN0YXRlID0gZmFsc2UpIHtcbiAgY29uc3QgaXNMb2NrZWQgPSBzaGFsbG93UmVmKGluaXRpYWxTdGF0ZSk7XG4gIGxldCBzdG9wVG91Y2hNb3ZlTGlzdGVuZXIgPSBudWxsO1xuICBsZXQgaW5pdGlhbE92ZXJmbG93ID0gXCJcIjtcbiAgd2F0Y2godG9SZWYoZWxlbWVudCksIChlbCkgPT4ge1xuICAgIGNvbnN0IHRhcmdldCA9IHJlc29sdmVFbGVtZW50KHRvVmFsdWUoZWwpKTtcbiAgICBpZiAodGFyZ2V0KSB7XG4gICAgICBjb25zdCBlbGUgPSB0YXJnZXQ7XG4gICAgICBpZiAoIWVsSW5pdGlhbE92ZXJmbG93LmdldChlbGUpKVxuICAgICAgICBlbEluaXRpYWxPdmVyZmxvdy5zZXQoZWxlLCBlbGUuc3R5bGUub3ZlcmZsb3cpO1xuICAgICAgaWYgKGVsZS5zdHlsZS5vdmVyZmxvdyAhPT0gXCJoaWRkZW5cIilcbiAgICAgICAgaW5pdGlhbE92ZXJmbG93ID0gZWxlLnN0eWxlLm92ZXJmbG93O1xuICAgICAgaWYgKGVsZS5zdHlsZS5vdmVyZmxvdyA9PT0gXCJoaWRkZW5cIilcbiAgICAgICAgcmV0dXJuIGlzTG9ja2VkLnZhbHVlID0gdHJ1ZTtcbiAgICAgIGlmIChpc0xvY2tlZC52YWx1ZSlcbiAgICAgICAgcmV0dXJuIGVsZS5zdHlsZS5vdmVyZmxvdyA9IFwiaGlkZGVuXCI7XG4gICAgfVxuICB9LCB7XG4gICAgaW1tZWRpYXRlOiB0cnVlXG4gIH0pO1xuICBjb25zdCBsb2NrID0gKCkgPT4ge1xuICAgIGNvbnN0IGVsID0gcmVzb2x2ZUVsZW1lbnQodG9WYWx1ZShlbGVtZW50KSk7XG4gICAgaWYgKCFlbCB8fCBpc0xvY2tlZC52YWx1ZSlcbiAgICAgIHJldHVybjtcbiAgICBpZiAoaXNJT1MpIHtcbiAgICAgIHN0b3BUb3VjaE1vdmVMaXN0ZW5lciA9IHVzZUV2ZW50TGlzdGVuZXIoXG4gICAgICAgIGVsLFxuICAgICAgICBcInRvdWNobW92ZVwiLFxuICAgICAgICAoZSkgPT4ge1xuICAgICAgICAgIHByZXZlbnREZWZhdWx0KGUpO1xuICAgICAgICB9LFxuICAgICAgICB7IHBhc3NpdmU6IGZhbHNlIH1cbiAgICAgICk7XG4gICAgfVxuICAgIGVsLnN0eWxlLm92ZXJmbG93ID0gXCJoaWRkZW5cIjtcbiAgICBpc0xvY2tlZC52YWx1ZSA9IHRydWU7XG4gIH07XG4gIGNvbnN0IHVubG9jayA9ICgpID0+IHtcbiAgICBjb25zdCBlbCA9IHJlc29sdmVFbGVtZW50KHRvVmFsdWUoZWxlbWVudCkpO1xuICAgIGlmICghZWwgfHwgIWlzTG9ja2VkLnZhbHVlKVxuICAgICAgcmV0dXJuO1xuICAgIGlmIChpc0lPUylcbiAgICAgIHN0b3BUb3VjaE1vdmVMaXN0ZW5lciA9PSBudWxsID8gdm9pZCAwIDogc3RvcFRvdWNoTW92ZUxpc3RlbmVyKCk7XG4gICAgZWwuc3R5bGUub3ZlcmZsb3cgPSBpbml0aWFsT3ZlcmZsb3c7XG4gICAgZWxJbml0aWFsT3ZlcmZsb3cuZGVsZXRlKGVsKTtcbiAgICBpc0xvY2tlZC52YWx1ZSA9IGZhbHNlO1xuICB9O1xuICB0cnlPblNjb3BlRGlzcG9zZSh1bmxvY2spO1xuICByZXR1cm4gY29tcHV0ZWQoe1xuICAgIGdldCgpIHtcbiAgICAgIHJldHVybiBpc0xvY2tlZC52YWx1ZTtcbiAgICB9LFxuICAgIHNldCh2KSB7XG4gICAgICBpZiAodilcbiAgICAgICAgbG9jaygpO1xuICAgICAgZWxzZSB1bmxvY2soKTtcbiAgICB9XG4gIH0pO1xufVxuXG5mdW5jdGlvbiB1c2VTZXNzaW9uU3RvcmFnZShrZXksIGluaXRpYWxWYWx1ZSwgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHsgd2luZG93ID0gZGVmYXVsdFdpbmRvdyB9ID0gb3B0aW9ucztcbiAgcmV0dXJuIHVzZVN0b3JhZ2Uoa2V5LCBpbml0aWFsVmFsdWUsIHdpbmRvdyA9PSBudWxsID8gdm9pZCAwIDogd2luZG93LnNlc3Npb25TdG9yYWdlLCBvcHRpb25zKTtcbn1cblxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHVzZVNoYXJlKHNoYXJlT3B0aW9ucyA9IHt9LCBvcHRpb25zID0ge30pIHtcbiAgY29uc3QgeyBuYXZpZ2F0b3IgPSBkZWZhdWx0TmF2aWdhdG9yIH0gPSBvcHRpb25zO1xuICBjb25zdCBfbmF2aWdhdG9yID0gbmF2aWdhdG9yO1xuICBjb25zdCBpc1N1cHBvcnRlZCA9IHVzZVN1cHBvcnRlZCgoKSA9PiBfbmF2aWdhdG9yICYmIFwiY2FuU2hhcmVcIiBpbiBfbmF2aWdhdG9yKTtcbiAgY29uc3Qgc2hhcmUgPSBhc3luYyAob3ZlcnJpZGVPcHRpb25zID0ge30pID0+IHtcbiAgICBpZiAoaXNTdXBwb3J0ZWQudmFsdWUpIHtcbiAgICAgIGNvbnN0IGRhdGEgPSB7XG4gICAgICAgIC4uLnRvVmFsdWUoc2hhcmVPcHRpb25zKSxcbiAgICAgICAgLi4udG9WYWx1ZShvdmVycmlkZU9wdGlvbnMpXG4gICAgICB9O1xuICAgICAgbGV0IGdyYW50ZWQgPSB0cnVlO1xuICAgICAgaWYgKGRhdGEuZmlsZXMgJiYgX25hdmlnYXRvci5jYW5TaGFyZSlcbiAgICAgICAgZ3JhbnRlZCA9IF9uYXZpZ2F0b3IuY2FuU2hhcmUoeyBmaWxlczogZGF0YS5maWxlcyB9KTtcbiAgICAgIGlmIChncmFudGVkKVxuICAgICAgICByZXR1cm4gX25hdmlnYXRvci5zaGFyZShkYXRhKTtcbiAgICB9XG4gIH07XG4gIHJldHVybiB7XG4gICAgaXNTdXBwb3J0ZWQsXG4gICAgc2hhcmVcbiAgfTtcbn1cblxuY29uc3QgZGVmYXVsdFNvcnRGbiA9IChzb3VyY2UsIGNvbXBhcmVGbikgPT4gc291cmNlLnNvcnQoY29tcGFyZUZuKTtcbmNvbnN0IGRlZmF1bHRDb21wYXJlID0gKGEsIGIpID0+IGEgLSBiO1xuZnVuY3Rpb24gdXNlU29ydGVkKC4uLmFyZ3MpIHtcbiAgdmFyIF9hLCBfYiwgX2MsIF9kO1xuICBjb25zdCBbc291cmNlXSA9IGFyZ3M7XG4gIGxldCBjb21wYXJlRm4gPSBkZWZhdWx0Q29tcGFyZTtcbiAgbGV0IG9wdGlvbnMgPSB7fTtcbiAgaWYgKGFyZ3MubGVuZ3RoID09PSAyKSB7XG4gICAgaWYgKHR5cGVvZiBhcmdzWzFdID09PSBcIm9iamVjdFwiKSB7XG4gICAgICBvcHRpb25zID0gYXJnc1sxXTtcbiAgICAgIGNvbXBhcmVGbiA9IChfYSA9IG9wdGlvbnMuY29tcGFyZUZuKSAhPSBudWxsID8gX2EgOiBkZWZhdWx0Q29tcGFyZTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29tcGFyZUZuID0gKF9iID0gYXJnc1sxXSkgIT0gbnVsbCA/IF9iIDogZGVmYXVsdENvbXBhcmU7XG4gICAgfVxuICB9IGVsc2UgaWYgKGFyZ3MubGVuZ3RoID4gMikge1xuICAgIGNvbXBhcmVGbiA9IChfYyA9IGFyZ3NbMV0pICE9IG51bGwgPyBfYyA6IGRlZmF1bHRDb21wYXJlO1xuICAgIG9wdGlvbnMgPSAoX2QgPSBhcmdzWzJdKSAhPSBudWxsID8gX2QgOiB7fTtcbiAgfVxuICBjb25zdCB7XG4gICAgZGlydHkgPSBmYWxzZSxcbiAgICBzb3J0Rm4gPSBkZWZhdWx0U29ydEZuXG4gIH0gPSBvcHRpb25zO1xuICBpZiAoIWRpcnR5KVxuICAgIHJldHVybiBjb21wdXRlZCgoKSA9PiBzb3J0Rm4oWy4uLnRvVmFsdWUoc291cmNlKV0sIGNvbXBhcmVGbikpO1xuICB3YXRjaEVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgcmVzdWx0ID0gc29ydEZuKHRvVmFsdWUoc291cmNlKSwgY29tcGFyZUZuKTtcbiAgICBpZiAoaXNSZWYoc291cmNlKSlcbiAgICAgIHNvdXJjZS52YWx1ZSA9IHJlc3VsdDtcbiAgICBlbHNlXG4gICAgICBzb3VyY2Uuc3BsaWNlKDAsIHNvdXJjZS5sZW5ndGgsIC4uLnJlc3VsdCk7XG4gIH0pO1xuICByZXR1cm4gc291cmNlO1xufVxuXG5mdW5jdGlvbiB1c2VTcGVlY2hSZWNvZ25pdGlvbihvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGludGVyaW1SZXN1bHRzID0gdHJ1ZSxcbiAgICBjb250aW51b3VzID0gdHJ1ZSxcbiAgICBtYXhBbHRlcm5hdGl2ZXMgPSAxLFxuICAgIHdpbmRvdyA9IGRlZmF1bHRXaW5kb3dcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGxhbmcgPSB0b1JlZihvcHRpb25zLmxhbmcgfHwgXCJlbi1VU1wiKTtcbiAgY29uc3QgaXNMaXN0ZW5pbmcgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgY29uc3QgaXNGaW5hbCA9IHNoYWxsb3dSZWYoZmFsc2UpO1xuICBjb25zdCByZXN1bHQgPSBzaGFsbG93UmVmKFwiXCIpO1xuICBjb25zdCBlcnJvciA9IHNoYWxsb3dSZWYodm9pZCAwKTtcbiAgbGV0IHJlY29nbml0aW9uO1xuICBjb25zdCBzdGFydCA9ICgpID0+IHtcbiAgICBpc0xpc3RlbmluZy52YWx1ZSA9IHRydWU7XG4gIH07XG4gIGNvbnN0IHN0b3AgPSAoKSA9PiB7XG4gICAgaXNMaXN0ZW5pbmcudmFsdWUgPSBmYWxzZTtcbiAgfTtcbiAgY29uc3QgdG9nZ2xlID0gKHZhbHVlID0gIWlzTGlzdGVuaW5nLnZhbHVlKSA9PiB7XG4gICAgaWYgKHZhbHVlKSB7XG4gICAgICBzdGFydCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdG9wKCk7XG4gICAgfVxuICB9O1xuICBjb25zdCBTcGVlY2hSZWNvZ25pdGlvbiA9IHdpbmRvdyAmJiAod2luZG93LlNwZWVjaFJlY29nbml0aW9uIHx8IHdpbmRvdy53ZWJraXRTcGVlY2hSZWNvZ25pdGlvbik7XG4gIGNvbnN0IGlzU3VwcG9ydGVkID0gdXNlU3VwcG9ydGVkKCgpID0+IFNwZWVjaFJlY29nbml0aW9uKTtcbiAgaWYgKGlzU3VwcG9ydGVkLnZhbHVlKSB7XG4gICAgcmVjb2duaXRpb24gPSBuZXcgU3BlZWNoUmVjb2duaXRpb24oKTtcbiAgICByZWNvZ25pdGlvbi5jb250aW51b3VzID0gY29udGludW91cztcbiAgICByZWNvZ25pdGlvbi5pbnRlcmltUmVzdWx0cyA9IGludGVyaW1SZXN1bHRzO1xuICAgIHJlY29nbml0aW9uLmxhbmcgPSB0b1ZhbHVlKGxhbmcpO1xuICAgIHJlY29nbml0aW9uLm1heEFsdGVybmF0aXZlcyA9IG1heEFsdGVybmF0aXZlcztcbiAgICByZWNvZ25pdGlvbi5vbnN0YXJ0ID0gKCkgPT4ge1xuICAgICAgaXNMaXN0ZW5pbmcudmFsdWUgPSB0cnVlO1xuICAgICAgaXNGaW5hbC52YWx1ZSA9IGZhbHNlO1xuICAgIH07XG4gICAgd2F0Y2gobGFuZywgKGxhbmcyKSA9PiB7XG4gICAgICBpZiAocmVjb2duaXRpb24gJiYgIWlzTGlzdGVuaW5nLnZhbHVlKVxuICAgICAgICByZWNvZ25pdGlvbi5sYW5nID0gbGFuZzI7XG4gICAgfSk7XG4gICAgcmVjb2duaXRpb24ub25yZXN1bHQgPSAoZXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IGN1cnJlbnRSZXN1bHQgPSBldmVudC5yZXN1bHRzW2V2ZW50LnJlc3VsdEluZGV4XTtcbiAgICAgIGNvbnN0IHsgdHJhbnNjcmlwdCB9ID0gY3VycmVudFJlc3VsdFswXTtcbiAgICAgIGlzRmluYWwudmFsdWUgPSBjdXJyZW50UmVzdWx0LmlzRmluYWw7XG4gICAgICByZXN1bHQudmFsdWUgPSB0cmFuc2NyaXB0O1xuICAgICAgZXJyb3IudmFsdWUgPSB2b2lkIDA7XG4gICAgfTtcbiAgICByZWNvZ25pdGlvbi5vbmVycm9yID0gKGV2ZW50KSA9PiB7XG4gICAgICBlcnJvci52YWx1ZSA9IGV2ZW50O1xuICAgIH07XG4gICAgcmVjb2duaXRpb24ub25lbmQgPSAoKSA9PiB7XG4gICAgICBpc0xpc3RlbmluZy52YWx1ZSA9IGZhbHNlO1xuICAgICAgcmVjb2duaXRpb24ubGFuZyA9IHRvVmFsdWUobGFuZyk7XG4gICAgfTtcbiAgICB3YXRjaChpc0xpc3RlbmluZywgKG5ld1ZhbHVlLCBvbGRWYWx1ZSkgPT4ge1xuICAgICAgaWYgKG5ld1ZhbHVlID09PSBvbGRWYWx1ZSlcbiAgICAgICAgcmV0dXJuO1xuICAgICAgaWYgKG5ld1ZhbHVlKVxuICAgICAgICByZWNvZ25pdGlvbi5zdGFydCgpO1xuICAgICAgZWxzZVxuICAgICAgICByZWNvZ25pdGlvbi5zdG9wKCk7XG4gICAgfSk7XG4gIH1cbiAgdHJ5T25TY29wZURpc3Bvc2UoKCkgPT4ge1xuICAgIHN0b3AoKTtcbiAgfSk7XG4gIHJldHVybiB7XG4gICAgaXNTdXBwb3J0ZWQsXG4gICAgaXNMaXN0ZW5pbmcsXG4gICAgaXNGaW5hbCxcbiAgICByZWNvZ25pdGlvbixcbiAgICByZXN1bHQsXG4gICAgZXJyb3IsXG4gICAgdG9nZ2xlLFxuICAgIHN0YXJ0LFxuICAgIHN0b3BcbiAgfTtcbn1cblxuZnVuY3Rpb24gdXNlU3BlZWNoU3ludGhlc2lzKHRleHQsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgcGl0Y2ggPSAxLFxuICAgIHJhdGUgPSAxLFxuICAgIHZvbHVtZSA9IDEsXG4gICAgd2luZG93ID0gZGVmYXVsdFdpbmRvdyxcbiAgICBvbkJvdW5kYXJ5XG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBzeW50aCA9IHdpbmRvdyAmJiB3aW5kb3cuc3BlZWNoU3ludGhlc2lzO1xuICBjb25zdCBpc1N1cHBvcnRlZCA9IHVzZVN1cHBvcnRlZCgoKSA9PiBzeW50aCk7XG4gIGNvbnN0IGlzUGxheWluZyA9IHNoYWxsb3dSZWYoZmFsc2UpO1xuICBjb25zdCBzdGF0dXMgPSBzaGFsbG93UmVmKFwiaW5pdFwiKTtcbiAgY29uc3Qgc3Bva2VuVGV4dCA9IHRvUmVmKHRleHQgfHwgXCJcIik7XG4gIGNvbnN0IGxhbmcgPSB0b1JlZihvcHRpb25zLmxhbmcgfHwgXCJlbi1VU1wiKTtcbiAgY29uc3QgZXJyb3IgPSBzaGFsbG93UmVmKHZvaWQgMCk7XG4gIGNvbnN0IHRvZ2dsZSA9ICh2YWx1ZSA9ICFpc1BsYXlpbmcudmFsdWUpID0+IHtcbiAgICBpc1BsYXlpbmcudmFsdWUgPSB2YWx1ZTtcbiAgfTtcbiAgY29uc3QgYmluZEV2ZW50c0ZvclV0dGVyYW5jZSA9ICh1dHRlcmFuY2UyKSA9PiB7XG4gICAgdXR0ZXJhbmNlMi5sYW5nID0gdG9WYWx1ZShsYW5nKTtcbiAgICB1dHRlcmFuY2UyLnZvaWNlID0gdG9WYWx1ZShvcHRpb25zLnZvaWNlKSB8fCBudWxsO1xuICAgIHV0dGVyYW5jZTIucGl0Y2ggPSB0b1ZhbHVlKHBpdGNoKTtcbiAgICB1dHRlcmFuY2UyLnJhdGUgPSB0b1ZhbHVlKHJhdGUpO1xuICAgIHV0dGVyYW5jZTIudm9sdW1lID0gdG9WYWx1ZSh2b2x1bWUpO1xuICAgIHV0dGVyYW5jZTIub25zdGFydCA9ICgpID0+IHtcbiAgICAgIGlzUGxheWluZy52YWx1ZSA9IHRydWU7XG4gICAgICBzdGF0dXMudmFsdWUgPSBcInBsYXlcIjtcbiAgICB9O1xuICAgIHV0dGVyYW5jZTIub25wYXVzZSA9ICgpID0+IHtcbiAgICAgIGlzUGxheWluZy52YWx1ZSA9IGZhbHNlO1xuICAgICAgc3RhdHVzLnZhbHVlID0gXCJwYXVzZVwiO1xuICAgIH07XG4gICAgdXR0ZXJhbmNlMi5vbnJlc3VtZSA9ICgpID0+IHtcbiAgICAgIGlzUGxheWluZy52YWx1ZSA9IHRydWU7XG4gICAgICBzdGF0dXMudmFsdWUgPSBcInBsYXlcIjtcbiAgICB9O1xuICAgIHV0dGVyYW5jZTIub25lbmQgPSAoKSA9PiB7XG4gICAgICBpc1BsYXlpbmcudmFsdWUgPSBmYWxzZTtcbiAgICAgIHN0YXR1cy52YWx1ZSA9IFwiZW5kXCI7XG4gICAgfTtcbiAgICB1dHRlcmFuY2UyLm9uZXJyb3IgPSAoZXZlbnQpID0+IHtcbiAgICAgIGVycm9yLnZhbHVlID0gZXZlbnQ7XG4gICAgfTtcbiAgICB1dHRlcmFuY2UyLm9uYm91bmRhcnkgPSAoZXZlbnQpID0+IHtcbiAgICAgIG9uQm91bmRhcnkgPT0gbnVsbCA/IHZvaWQgMCA6IG9uQm91bmRhcnkoZXZlbnQpO1xuICAgIH07XG4gIH07XG4gIGNvbnN0IHV0dGVyYW5jZSA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICBpc1BsYXlpbmcudmFsdWUgPSBmYWxzZTtcbiAgICBzdGF0dXMudmFsdWUgPSBcImluaXRcIjtcbiAgICBjb25zdCBuZXdVdHRlcmFuY2UgPSBuZXcgU3BlZWNoU3ludGhlc2lzVXR0ZXJhbmNlKHNwb2tlblRleHQudmFsdWUpO1xuICAgIGJpbmRFdmVudHNGb3JVdHRlcmFuY2UobmV3VXR0ZXJhbmNlKTtcbiAgICByZXR1cm4gbmV3VXR0ZXJhbmNlO1xuICB9KTtcbiAgY29uc3Qgc3BlYWsgPSAoKSA9PiB7XG4gICAgc3ludGguY2FuY2VsKCk7XG4gICAgaWYgKHV0dGVyYW5jZSlcbiAgICAgIHN5bnRoLnNwZWFrKHV0dGVyYW5jZS52YWx1ZSk7XG4gIH07XG4gIGNvbnN0IHN0b3AgPSAoKSA9PiB7XG4gICAgc3ludGguY2FuY2VsKCk7XG4gICAgaXNQbGF5aW5nLnZhbHVlID0gZmFsc2U7XG4gIH07XG4gIGlmIChpc1N1cHBvcnRlZC52YWx1ZSkge1xuICAgIGJpbmRFdmVudHNGb3JVdHRlcmFuY2UodXR0ZXJhbmNlLnZhbHVlKTtcbiAgICB3YXRjaChsYW5nLCAobGFuZzIpID0+IHtcbiAgICAgIGlmICh1dHRlcmFuY2UudmFsdWUgJiYgIWlzUGxheWluZy52YWx1ZSlcbiAgICAgICAgdXR0ZXJhbmNlLnZhbHVlLmxhbmcgPSBsYW5nMjtcbiAgICB9KTtcbiAgICBpZiAob3B0aW9ucy52b2ljZSkge1xuICAgICAgd2F0Y2gob3B0aW9ucy52b2ljZSwgKCkgPT4ge1xuICAgICAgICBzeW50aC5jYW5jZWwoKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICB3YXRjaChpc1BsYXlpbmcsICgpID0+IHtcbiAgICAgIGlmIChpc1BsYXlpbmcudmFsdWUpXG4gICAgICAgIHN5bnRoLnJlc3VtZSgpO1xuICAgICAgZWxzZVxuICAgICAgICBzeW50aC5wYXVzZSgpO1xuICAgIH0pO1xuICB9XG4gIHRyeU9uU2NvcGVEaXNwb3NlKCgpID0+IHtcbiAgICBpc1BsYXlpbmcudmFsdWUgPSBmYWxzZTtcbiAgfSk7XG4gIHJldHVybiB7XG4gICAgaXNTdXBwb3J0ZWQsXG4gICAgaXNQbGF5aW5nLFxuICAgIHN0YXR1cyxcbiAgICB1dHRlcmFuY2UsXG4gICAgZXJyb3IsXG4gICAgc3RvcCxcbiAgICB0b2dnbGUsXG4gICAgc3BlYWtcbiAgfTtcbn1cblxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHVzZVN0ZXBwZXIoc3RlcHMsIGluaXRpYWxTdGVwKSB7XG4gIGNvbnN0IHN0ZXBzUmVmID0gcmVmKHN0ZXBzKTtcbiAgY29uc3Qgc3RlcE5hbWVzID0gY29tcHV0ZWQoKCkgPT4gQXJyYXkuaXNBcnJheShzdGVwc1JlZi52YWx1ZSkgPyBzdGVwc1JlZi52YWx1ZSA6IE9iamVjdC5rZXlzKHN0ZXBzUmVmLnZhbHVlKSk7XG4gIGNvbnN0IGluZGV4ID0gcmVmKHN0ZXBOYW1lcy52YWx1ZS5pbmRleE9mKGluaXRpYWxTdGVwICE9IG51bGwgPyBpbml0aWFsU3RlcCA6IHN0ZXBOYW1lcy52YWx1ZVswXSkpO1xuICBjb25zdCBjdXJyZW50ID0gY29tcHV0ZWQoKCkgPT4gYXQoaW5kZXgudmFsdWUpKTtcbiAgY29uc3QgaXNGaXJzdCA9IGNvbXB1dGVkKCgpID0+IGluZGV4LnZhbHVlID09PSAwKTtcbiAgY29uc3QgaXNMYXN0ID0gY29tcHV0ZWQoKCkgPT4gaW5kZXgudmFsdWUgPT09IHN0ZXBOYW1lcy52YWx1ZS5sZW5ndGggLSAxKTtcbiAgY29uc3QgbmV4dCA9IGNvbXB1dGVkKCgpID0+IHN0ZXBOYW1lcy52YWx1ZVtpbmRleC52YWx1ZSArIDFdKTtcbiAgY29uc3QgcHJldmlvdXMgPSBjb21wdXRlZCgoKSA9PiBzdGVwTmFtZXMudmFsdWVbaW5kZXgudmFsdWUgLSAxXSk7XG4gIGZ1bmN0aW9uIGF0KGluZGV4Mikge1xuICAgIGlmIChBcnJheS5pc0FycmF5KHN0ZXBzUmVmLnZhbHVlKSlcbiAgICAgIHJldHVybiBzdGVwc1JlZi52YWx1ZVtpbmRleDJdO1xuICAgIHJldHVybiBzdGVwc1JlZi52YWx1ZVtzdGVwTmFtZXMudmFsdWVbaW5kZXgyXV07XG4gIH1cbiAgZnVuY3Rpb24gZ2V0KHN0ZXApIHtcbiAgICBpZiAoIXN0ZXBOYW1lcy52YWx1ZS5pbmNsdWRlcyhzdGVwKSlcbiAgICAgIHJldHVybjtcbiAgICByZXR1cm4gYXQoc3RlcE5hbWVzLnZhbHVlLmluZGV4T2Yoc3RlcCkpO1xuICB9XG4gIGZ1bmN0aW9uIGdvVG8oc3RlcCkge1xuICAgIGlmIChzdGVwTmFtZXMudmFsdWUuaW5jbHVkZXMoc3RlcCkpXG4gICAgICBpbmRleC52YWx1ZSA9IHN0ZXBOYW1lcy52YWx1ZS5pbmRleE9mKHN0ZXApO1xuICB9XG4gIGZ1bmN0aW9uIGdvVG9OZXh0KCkge1xuICAgIGlmIChpc0xhc3QudmFsdWUpXG4gICAgICByZXR1cm47XG4gICAgaW5kZXgudmFsdWUrKztcbiAgfVxuICBmdW5jdGlvbiBnb1RvUHJldmlvdXMoKSB7XG4gICAgaWYgKGlzRmlyc3QudmFsdWUpXG4gICAgICByZXR1cm47XG4gICAgaW5kZXgudmFsdWUtLTtcbiAgfVxuICBmdW5jdGlvbiBnb0JhY2tUbyhzdGVwKSB7XG4gICAgaWYgKGlzQWZ0ZXIoc3RlcCkpXG4gICAgICBnb1RvKHN0ZXApO1xuICB9XG4gIGZ1bmN0aW9uIGlzTmV4dChzdGVwKSB7XG4gICAgcmV0dXJuIHN0ZXBOYW1lcy52YWx1ZS5pbmRleE9mKHN0ZXApID09PSBpbmRleC52YWx1ZSArIDE7XG4gIH1cbiAgZnVuY3Rpb24gaXNQcmV2aW91cyhzdGVwKSB7XG4gICAgcmV0dXJuIHN0ZXBOYW1lcy52YWx1ZS5pbmRleE9mKHN0ZXApID09PSBpbmRleC52YWx1ZSAtIDE7XG4gIH1cbiAgZnVuY3Rpb24gaXNDdXJyZW50KHN0ZXApIHtcbiAgICByZXR1cm4gc3RlcE5hbWVzLnZhbHVlLmluZGV4T2Yoc3RlcCkgPT09IGluZGV4LnZhbHVlO1xuICB9XG4gIGZ1bmN0aW9uIGlzQmVmb3JlKHN0ZXApIHtcbiAgICByZXR1cm4gaW5kZXgudmFsdWUgPCBzdGVwTmFtZXMudmFsdWUuaW5kZXhPZihzdGVwKTtcbiAgfVxuICBmdW5jdGlvbiBpc0FmdGVyKHN0ZXApIHtcbiAgICByZXR1cm4gaW5kZXgudmFsdWUgPiBzdGVwTmFtZXMudmFsdWUuaW5kZXhPZihzdGVwKTtcbiAgfVxuICByZXR1cm4ge1xuICAgIHN0ZXBzOiBzdGVwc1JlZixcbiAgICBzdGVwTmFtZXMsXG4gICAgaW5kZXgsXG4gICAgY3VycmVudCxcbiAgICBuZXh0LFxuICAgIHByZXZpb3VzLFxuICAgIGlzRmlyc3QsXG4gICAgaXNMYXN0LFxuICAgIGF0LFxuICAgIGdldCxcbiAgICBnb1RvLFxuICAgIGdvVG9OZXh0LFxuICAgIGdvVG9QcmV2aW91cyxcbiAgICBnb0JhY2tUbyxcbiAgICBpc05leHQsXG4gICAgaXNQcmV2aW91cyxcbiAgICBpc0N1cnJlbnQsXG4gICAgaXNCZWZvcmUsXG4gICAgaXNBZnRlclxuICB9O1xufVxuXG5mdW5jdGlvbiB1c2VTdG9yYWdlQXN5bmMoa2V5LCBpbml0aWFsVmFsdWUsIHN0b3JhZ2UsIG9wdGlvbnMgPSB7fSkge1xuICB2YXIgX2E7XG4gIGNvbnN0IHtcbiAgICBmbHVzaCA9IFwicHJlXCIsXG4gICAgZGVlcCA9IHRydWUsXG4gICAgbGlzdGVuVG9TdG9yYWdlQ2hhbmdlcyA9IHRydWUsXG4gICAgd3JpdGVEZWZhdWx0cyA9IHRydWUsXG4gICAgbWVyZ2VEZWZhdWx0cyA9IGZhbHNlLFxuICAgIHNoYWxsb3csXG4gICAgd2luZG93ID0gZGVmYXVsdFdpbmRvdyxcbiAgICBldmVudEZpbHRlcixcbiAgICBvbkVycm9yID0gKGUpID0+IHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoZSk7XG4gICAgfSxcbiAgICBvblJlYWR5XG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCByYXdJbml0ID0gdG9WYWx1ZShpbml0aWFsVmFsdWUpO1xuICBjb25zdCB0eXBlID0gZ3Vlc3NTZXJpYWxpemVyVHlwZShyYXdJbml0KTtcbiAgY29uc3QgZGF0YSA9IChzaGFsbG93ID8gc2hhbGxvd1JlZiA6IHJlZikodG9WYWx1ZShpbml0aWFsVmFsdWUpKTtcbiAgY29uc3Qgc2VyaWFsaXplciA9IChfYSA9IG9wdGlvbnMuc2VyaWFsaXplcikgIT0gbnVsbCA/IF9hIDogU3RvcmFnZVNlcmlhbGl6ZXJzW3R5cGVdO1xuICBpZiAoIXN0b3JhZ2UpIHtcbiAgICB0cnkge1xuICAgICAgc3RvcmFnZSA9IGdldFNTUkhhbmRsZXIoXCJnZXREZWZhdWx0U3RvcmFnZUFzeW5jXCIsICgpID0+IHtcbiAgICAgICAgdmFyIF9hMjtcbiAgICAgICAgcmV0dXJuIChfYTIgPSBkZWZhdWx0V2luZG93KSA9PSBudWxsID8gdm9pZCAwIDogX2EyLmxvY2FsU3RvcmFnZTtcbiAgICAgIH0pKCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgb25FcnJvcihlKTtcbiAgICB9XG4gIH1cbiAgYXN5bmMgZnVuY3Rpb24gcmVhZChldmVudCkge1xuICAgIGlmICghc3RvcmFnZSB8fCBldmVudCAmJiBldmVudC5rZXkgIT09IGtleSlcbiAgICAgIHJldHVybjtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmF3VmFsdWUgPSBldmVudCA/IGV2ZW50Lm5ld1ZhbHVlIDogYXdhaXQgc3RvcmFnZS5nZXRJdGVtKGtleSk7XG4gICAgICBpZiAocmF3VmFsdWUgPT0gbnVsbCkge1xuICAgICAgICBkYXRhLnZhbHVlID0gcmF3SW5pdDtcbiAgICAgICAgaWYgKHdyaXRlRGVmYXVsdHMgJiYgcmF3SW5pdCAhPT0gbnVsbClcbiAgICAgICAgICBhd2FpdCBzdG9yYWdlLnNldEl0ZW0oa2V5LCBhd2FpdCBzZXJpYWxpemVyLndyaXRlKHJhd0luaXQpKTtcbiAgICAgIH0gZWxzZSBpZiAobWVyZ2VEZWZhdWx0cykge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IGF3YWl0IHNlcmlhbGl6ZXIucmVhZChyYXdWYWx1ZSk7XG4gICAgICAgIGlmICh0eXBlb2YgbWVyZ2VEZWZhdWx0cyA9PT0gXCJmdW5jdGlvblwiKVxuICAgICAgICAgIGRhdGEudmFsdWUgPSBtZXJnZURlZmF1bHRzKHZhbHVlLCByYXdJbml0KTtcbiAgICAgICAgZWxzZSBpZiAodHlwZSA9PT0gXCJvYmplY3RcIiAmJiAhQXJyYXkuaXNBcnJheSh2YWx1ZSkpXG4gICAgICAgICAgZGF0YS52YWx1ZSA9IHsgLi4ucmF3SW5pdCwgLi4udmFsdWUgfTtcbiAgICAgICAgZWxzZSBkYXRhLnZhbHVlID0gdmFsdWU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBkYXRhLnZhbHVlID0gYXdhaXQgc2VyaWFsaXplci5yZWFkKHJhd1ZhbHVlKTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBvbkVycm9yKGUpO1xuICAgIH1cbiAgfVxuICBjb25zdCBwcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICByZWFkKCkudGhlbigoKSA9PiB7XG4gICAgICBvblJlYWR5ID09IG51bGwgPyB2b2lkIDAgOiBvblJlYWR5KGRhdGEudmFsdWUpO1xuICAgICAgcmVzb2x2ZShkYXRhKTtcbiAgICB9KTtcbiAgfSk7XG4gIGlmICh3aW5kb3cgJiYgbGlzdGVuVG9TdG9yYWdlQ2hhbmdlcylcbiAgICB1c2VFdmVudExpc3RlbmVyKHdpbmRvdywgXCJzdG9yYWdlXCIsIChlKSA9PiBQcm9taXNlLnJlc29sdmUoKS50aGVuKCgpID0+IHJlYWQoZSkpLCB7IHBhc3NpdmU6IHRydWUgfSk7XG4gIGlmIChzdG9yYWdlKSB7XG4gICAgd2F0Y2hXaXRoRmlsdGVyKFxuICAgICAgZGF0YSxcbiAgICAgIGFzeW5jICgpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBpZiAoZGF0YS52YWx1ZSA9PSBudWxsKVxuICAgICAgICAgICAgYXdhaXQgc3RvcmFnZS5yZW1vdmVJdGVtKGtleSk7XG4gICAgICAgICAgZWxzZVxuICAgICAgICAgICAgYXdhaXQgc3RvcmFnZS5zZXRJdGVtKGtleSwgYXdhaXQgc2VyaWFsaXplci53cml0ZShkYXRhLnZhbHVlKSk7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICBvbkVycm9yKGUpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBmbHVzaCxcbiAgICAgICAgZGVlcCxcbiAgICAgICAgZXZlbnRGaWx0ZXJcbiAgICAgIH1cbiAgICApO1xuICB9XG4gIE9iamVjdC5hc3NpZ24oZGF0YSwge1xuICAgIHRoZW46IHByb21pc2UudGhlbi5iaW5kKHByb21pc2UpLFxuICAgIGNhdGNoOiBwcm9taXNlLmNhdGNoLmJpbmQocHJvbWlzZSlcbiAgfSk7XG4gIHJldHVybiBkYXRhO1xufVxuXG5sZXQgX2lkID0gMDtcbmZ1bmN0aW9uIHVzZVN0eWxlVGFnKGNzcywgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IGlzTG9hZGVkID0gc2hhbGxvd1JlZihmYWxzZSk7XG4gIGNvbnN0IHtcbiAgICBkb2N1bWVudCA9IGRlZmF1bHREb2N1bWVudCxcbiAgICBpbW1lZGlhdGUgPSB0cnVlLFxuICAgIG1hbnVhbCA9IGZhbHNlLFxuICAgIGlkID0gYHZ1ZXVzZV9zdHlsZXRhZ18keysrX2lkfWBcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGNzc1JlZiA9IHNoYWxsb3dSZWYoY3NzKTtcbiAgbGV0IHN0b3AgPSAoKSA9PiB7XG4gIH07XG4gIGNvbnN0IGxvYWQgPSAoKSA9PiB7XG4gICAgaWYgKCFkb2N1bWVudClcbiAgICAgIHJldHVybjtcbiAgICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKSB8fCBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3R5bGVcIik7XG4gICAgaWYgKCFlbC5pc0Nvbm5lY3RlZCkge1xuICAgICAgZWwuaWQgPSBpZDtcbiAgICAgIGlmIChvcHRpb25zLm5vbmNlKVxuICAgICAgICBlbC5ub25jZSA9IG9wdGlvbnMubm9uY2U7XG4gICAgICBpZiAob3B0aW9ucy5tZWRpYSlcbiAgICAgICAgZWwubWVkaWEgPSBvcHRpb25zLm1lZGlhO1xuICAgICAgZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZChlbCk7XG4gICAgfVxuICAgIGlmIChpc0xvYWRlZC52YWx1ZSlcbiAgICAgIHJldHVybjtcbiAgICBzdG9wID0gd2F0Y2goXG4gICAgICBjc3NSZWYsXG4gICAgICAodmFsdWUpID0+IHtcbiAgICAgICAgZWwudGV4dENvbnRlbnQgPSB2YWx1ZTtcbiAgICAgIH0sXG4gICAgICB7IGltbWVkaWF0ZTogdHJ1ZSB9XG4gICAgKTtcbiAgICBpc0xvYWRlZC52YWx1ZSA9IHRydWU7XG4gIH07XG4gIGNvbnN0IHVubG9hZCA9ICgpID0+IHtcbiAgICBpZiAoIWRvY3VtZW50IHx8ICFpc0xvYWRlZC52YWx1ZSlcbiAgICAgIHJldHVybjtcbiAgICBzdG9wKCk7XG4gICAgZG9jdW1lbnQuaGVhZC5yZW1vdmVDaGlsZChkb2N1bWVudC5nZXRFbGVtZW50QnlJZChpZCkpO1xuICAgIGlzTG9hZGVkLnZhbHVlID0gZmFsc2U7XG4gIH07XG4gIGlmIChpbW1lZGlhdGUgJiYgIW1hbnVhbClcbiAgICB0cnlPbk1vdW50ZWQobG9hZCk7XG4gIGlmICghbWFudWFsKVxuICAgIHRyeU9uU2NvcGVEaXNwb3NlKHVubG9hZCk7XG4gIHJldHVybiB7XG4gICAgaWQsXG4gICAgY3NzOiBjc3NSZWYsXG4gICAgdW5sb2FkLFxuICAgIGxvYWQsXG4gICAgaXNMb2FkZWQ6IHJlYWRvbmx5KGlzTG9hZGVkKVxuICB9O1xufVxuXG5mdW5jdGlvbiB1c2VTd2lwZSh0YXJnZXQsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgdGhyZXNob2xkID0gNTAsXG4gICAgb25Td2lwZSxcbiAgICBvblN3aXBlRW5kLFxuICAgIG9uU3dpcGVTdGFydCxcbiAgICBwYXNzaXZlID0gdHJ1ZVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgY29vcmRzU3RhcnQgPSByZWFjdGl2ZSh7IHg6IDAsIHk6IDAgfSk7XG4gIGNvbnN0IGNvb3Jkc0VuZCA9IHJlYWN0aXZlKHsgeDogMCwgeTogMCB9KTtcbiAgY29uc3QgZGlmZlggPSBjb21wdXRlZCgoKSA9PiBjb29yZHNTdGFydC54IC0gY29vcmRzRW5kLngpO1xuICBjb25zdCBkaWZmWSA9IGNvbXB1dGVkKCgpID0+IGNvb3Jkc1N0YXJ0LnkgLSBjb29yZHNFbmQueSk7XG4gIGNvbnN0IHsgbWF4LCBhYnMgfSA9IE1hdGg7XG4gIGNvbnN0IGlzVGhyZXNob2xkRXhjZWVkZWQgPSBjb21wdXRlZCgoKSA9PiBtYXgoYWJzKGRpZmZYLnZhbHVlKSwgYWJzKGRpZmZZLnZhbHVlKSkgPj0gdGhyZXNob2xkKTtcbiAgY29uc3QgaXNTd2lwaW5nID0gc2hhbGxvd1JlZihmYWxzZSk7XG4gIGNvbnN0IGRpcmVjdGlvbiA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICBpZiAoIWlzVGhyZXNob2xkRXhjZWVkZWQudmFsdWUpXG4gICAgICByZXR1cm4gXCJub25lXCI7XG4gICAgaWYgKGFicyhkaWZmWC52YWx1ZSkgPiBhYnMoZGlmZlkudmFsdWUpKSB7XG4gICAgICByZXR1cm4gZGlmZlgudmFsdWUgPiAwID8gXCJsZWZ0XCIgOiBcInJpZ2h0XCI7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBkaWZmWS52YWx1ZSA+IDAgPyBcInVwXCIgOiBcImRvd25cIjtcbiAgICB9XG4gIH0pO1xuICBjb25zdCBnZXRUb3VjaEV2ZW50Q29vcmRzID0gKGUpID0+IFtlLnRvdWNoZXNbMF0uY2xpZW50WCwgZS50b3VjaGVzWzBdLmNsaWVudFldO1xuICBjb25zdCB1cGRhdGVDb29yZHNTdGFydCA9ICh4LCB5KSA9PiB7XG4gICAgY29vcmRzU3RhcnQueCA9IHg7XG4gICAgY29vcmRzU3RhcnQueSA9IHk7XG4gIH07XG4gIGNvbnN0IHVwZGF0ZUNvb3Jkc0VuZCA9ICh4LCB5KSA9PiB7XG4gICAgY29vcmRzRW5kLnggPSB4O1xuICAgIGNvb3Jkc0VuZC55ID0geTtcbiAgfTtcbiAgY29uc3QgbGlzdGVuZXJPcHRpb25zID0geyBwYXNzaXZlLCBjYXB0dXJlOiAhcGFzc2l2ZSB9O1xuICBjb25zdCBvblRvdWNoRW5kID0gKGUpID0+IHtcbiAgICBpZiAoaXNTd2lwaW5nLnZhbHVlKVxuICAgICAgb25Td2lwZUVuZCA9PSBudWxsID8gdm9pZCAwIDogb25Td2lwZUVuZChlLCBkaXJlY3Rpb24udmFsdWUpO1xuICAgIGlzU3dpcGluZy52YWx1ZSA9IGZhbHNlO1xuICB9O1xuICBjb25zdCBzdG9wcyA9IFtcbiAgICB1c2VFdmVudExpc3RlbmVyKHRhcmdldCwgXCJ0b3VjaHN0YXJ0XCIsIChlKSA9PiB7XG4gICAgICBpZiAoZS50b3VjaGVzLmxlbmd0aCAhPT0gMSlcbiAgICAgICAgcmV0dXJuO1xuICAgICAgY29uc3QgW3gsIHldID0gZ2V0VG91Y2hFdmVudENvb3JkcyhlKTtcbiAgICAgIHVwZGF0ZUNvb3Jkc1N0YXJ0KHgsIHkpO1xuICAgICAgdXBkYXRlQ29vcmRzRW5kKHgsIHkpO1xuICAgICAgb25Td2lwZVN0YXJ0ID09IG51bGwgPyB2b2lkIDAgOiBvblN3aXBlU3RhcnQoZSk7XG4gICAgfSwgbGlzdGVuZXJPcHRpb25zKSxcbiAgICB1c2VFdmVudExpc3RlbmVyKHRhcmdldCwgXCJ0b3VjaG1vdmVcIiwgKGUpID0+IHtcbiAgICAgIGlmIChlLnRvdWNoZXMubGVuZ3RoICE9PSAxKVxuICAgICAgICByZXR1cm47XG4gICAgICBjb25zdCBbeCwgeV0gPSBnZXRUb3VjaEV2ZW50Q29vcmRzKGUpO1xuICAgICAgdXBkYXRlQ29vcmRzRW5kKHgsIHkpO1xuICAgICAgaWYgKGxpc3RlbmVyT3B0aW9ucy5jYXB0dXJlICYmICFsaXN0ZW5lck9wdGlvbnMucGFzc2l2ZSAmJiBNYXRoLmFicyhkaWZmWC52YWx1ZSkgPiBNYXRoLmFicyhkaWZmWS52YWx1ZSkpXG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIGlmICghaXNTd2lwaW5nLnZhbHVlICYmIGlzVGhyZXNob2xkRXhjZWVkZWQudmFsdWUpXG4gICAgICAgIGlzU3dpcGluZy52YWx1ZSA9IHRydWU7XG4gICAgICBpZiAoaXNTd2lwaW5nLnZhbHVlKVxuICAgICAgICBvblN3aXBlID09IG51bGwgPyB2b2lkIDAgOiBvblN3aXBlKGUpO1xuICAgIH0sIGxpc3RlbmVyT3B0aW9ucyksXG4gICAgdXNlRXZlbnRMaXN0ZW5lcih0YXJnZXQsIFtcInRvdWNoZW5kXCIsIFwidG91Y2hjYW5jZWxcIl0sIG9uVG91Y2hFbmQsIGxpc3RlbmVyT3B0aW9ucylcbiAgXTtcbiAgY29uc3Qgc3RvcCA9ICgpID0+IHN0b3BzLmZvckVhY2goKHMpID0+IHMoKSk7XG4gIHJldHVybiB7XG4gICAgaXNTd2lwaW5nLFxuICAgIGRpcmVjdGlvbixcbiAgICBjb29yZHNTdGFydCxcbiAgICBjb29yZHNFbmQsXG4gICAgbGVuZ3RoWDogZGlmZlgsXG4gICAgbGVuZ3RoWTogZGlmZlksXG4gICAgc3RvcCxcbiAgICAvLyBUT0RPOiBSZW1vdmUgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvblxuICAgIGlzUGFzc2l2ZUV2ZW50U3VwcG9ydGVkOiB0cnVlXG4gIH07XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VUZW1wbGF0ZVJlZnNMaXN0KCkge1xuICBjb25zdCByZWZzID0gcmVmKFtdKTtcbiAgcmVmcy52YWx1ZS5zZXQgPSAoZWwpID0+IHtcbiAgICBpZiAoZWwpXG4gICAgICByZWZzLnZhbHVlLnB1c2goZWwpO1xuICB9O1xuICBvbkJlZm9yZVVwZGF0ZSgoKSA9PiB7XG4gICAgcmVmcy52YWx1ZS5sZW5ndGggPSAwO1xuICB9KTtcbiAgcmV0dXJuIHJlZnM7XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VUZXh0RGlyZWN0aW9uKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgZG9jdW1lbnQgPSBkZWZhdWx0RG9jdW1lbnQsXG4gICAgc2VsZWN0b3IgPSBcImh0bWxcIixcbiAgICBvYnNlcnZlID0gZmFsc2UsXG4gICAgaW5pdGlhbFZhbHVlID0gXCJsdHJcIlxuICB9ID0gb3B0aW9ucztcbiAgZnVuY3Rpb24gZ2V0VmFsdWUoKSB7XG4gICAgdmFyIF9hLCBfYjtcbiAgICByZXR1cm4gKF9iID0gKF9hID0gZG9jdW1lbnQgPT0gbnVsbCA/IHZvaWQgMCA6IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3Ioc2VsZWN0b3IpKSA9PSBudWxsID8gdm9pZCAwIDogX2EuZ2V0QXR0cmlidXRlKFwiZGlyXCIpKSAhPSBudWxsID8gX2IgOiBpbml0aWFsVmFsdWU7XG4gIH1cbiAgY29uc3QgZGlyID0gcmVmKGdldFZhbHVlKCkpO1xuICB0cnlPbk1vdW50ZWQoKCkgPT4gZGlyLnZhbHVlID0gZ2V0VmFsdWUoKSk7XG4gIGlmIChvYnNlcnZlICYmIGRvY3VtZW50KSB7XG4gICAgdXNlTXV0YXRpb25PYnNlcnZlcihcbiAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3Ioc2VsZWN0b3IpLFxuICAgICAgKCkgPT4gZGlyLnZhbHVlID0gZ2V0VmFsdWUoKSxcbiAgICAgIHsgYXR0cmlidXRlczogdHJ1ZSB9XG4gICAgKTtcbiAgfVxuICByZXR1cm4gY29tcHV0ZWQoe1xuICAgIGdldCgpIHtcbiAgICAgIHJldHVybiBkaXIudmFsdWU7XG4gICAgfSxcbiAgICBzZXQodikge1xuICAgICAgdmFyIF9hLCBfYjtcbiAgICAgIGRpci52YWx1ZSA9IHY7XG4gICAgICBpZiAoIWRvY3VtZW50KVxuICAgICAgICByZXR1cm47XG4gICAgICBpZiAoZGlyLnZhbHVlKVxuICAgICAgICAoX2EgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHNlbGVjdG9yKSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLnNldEF0dHJpYnV0ZShcImRpclwiLCBkaXIudmFsdWUpO1xuICAgICAgZWxzZVxuICAgICAgICAoX2IgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHNlbGVjdG9yKSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9iLnJlbW92ZUF0dHJpYnV0ZShcImRpclwiKTtcbiAgICB9XG4gIH0pO1xufVxuXG5mdW5jdGlvbiBnZXRSYW5nZXNGcm9tU2VsZWN0aW9uKHNlbGVjdGlvbikge1xuICB2YXIgX2E7XG4gIGNvbnN0IHJhbmdlQ291bnQgPSAoX2EgPSBzZWxlY3Rpb24ucmFuZ2VDb3VudCkgIT0gbnVsbCA/IF9hIDogMDtcbiAgcmV0dXJuIEFycmF5LmZyb20oeyBsZW5ndGg6IHJhbmdlQ291bnQgfSwgKF8sIGkpID0+IHNlbGVjdGlvbi5nZXRSYW5nZUF0KGkpKTtcbn1cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VUZXh0U2VsZWN0aW9uKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgd2luZG93ID0gZGVmYXVsdFdpbmRvd1xuICB9ID0gb3B0aW9ucztcbiAgY29uc3Qgc2VsZWN0aW9uID0gcmVmKG51bGwpO1xuICBjb25zdCB0ZXh0ID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIHZhciBfYSwgX2I7XG4gICAgcmV0dXJuIChfYiA9IChfYSA9IHNlbGVjdGlvbi52YWx1ZSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLnRvU3RyaW5nKCkpICE9IG51bGwgPyBfYiA6IFwiXCI7XG4gIH0pO1xuICBjb25zdCByYW5nZXMgPSBjb21wdXRlZCgoKSA9PiBzZWxlY3Rpb24udmFsdWUgPyBnZXRSYW5nZXNGcm9tU2VsZWN0aW9uKHNlbGVjdGlvbi52YWx1ZSkgOiBbXSk7XG4gIGNvbnN0IHJlY3RzID0gY29tcHV0ZWQoKCkgPT4gcmFuZ2VzLnZhbHVlLm1hcCgocmFuZ2UpID0+IHJhbmdlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpKSk7XG4gIGZ1bmN0aW9uIG9uU2VsZWN0aW9uQ2hhbmdlKCkge1xuICAgIHNlbGVjdGlvbi52YWx1ZSA9IG51bGw7XG4gICAgaWYgKHdpbmRvdylcbiAgICAgIHNlbGVjdGlvbi52YWx1ZSA9IHdpbmRvdy5nZXRTZWxlY3Rpb24oKTtcbiAgfVxuICBpZiAod2luZG93KVxuICAgIHVzZUV2ZW50TGlzdGVuZXIod2luZG93LmRvY3VtZW50LCBcInNlbGVjdGlvbmNoYW5nZVwiLCBvblNlbGVjdGlvbkNoYW5nZSwgeyBwYXNzaXZlOiB0cnVlIH0pO1xuICByZXR1cm4ge1xuICAgIHRleHQsXG4gICAgcmVjdHMsXG4gICAgcmFuZ2VzLFxuICAgIHNlbGVjdGlvblxuICB9O1xufVxuXG5mdW5jdGlvbiB0cnlSZXF1ZXN0QW5pbWF0aW9uRnJhbWUod2luZG93ID0gZGVmYXVsdFdpbmRvdywgZm4pIHtcbiAgaWYgKHdpbmRvdyAmJiB0eXBlb2Ygd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZShmbik7XG4gIH0gZWxzZSB7XG4gICAgZm4oKTtcbiAgfVxufVxuZnVuY3Rpb24gdXNlVGV4dGFyZWFBdXRvc2l6ZShvcHRpb25zID0ge30pIHtcbiAgdmFyIF9hLCBfYjtcbiAgY29uc3QgeyB3aW5kb3cgPSBkZWZhdWx0V2luZG93IH0gPSBvcHRpb25zO1xuICBjb25zdCB0ZXh0YXJlYSA9IHRvUmVmKG9wdGlvbnMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdGlvbnMuZWxlbWVudCk7XG4gIGNvbnN0IGlucHV0ID0gdG9SZWYoKF9hID0gb3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy5pbnB1dCkgIT0gbnVsbCA/IF9hIDogXCJcIik7XG4gIGNvbnN0IHN0eWxlUHJvcCA9IChfYiA9IG9wdGlvbnMgPT0gbnVsbCA/IHZvaWQgMCA6IG9wdGlvbnMuc3R5bGVQcm9wKSAhPSBudWxsID8gX2IgOiBcImhlaWdodFwiO1xuICBjb25zdCB0ZXh0YXJlYVNjcm9sbEhlaWdodCA9IHNoYWxsb3dSZWYoMSk7XG4gIGNvbnN0IHRleHRhcmVhT2xkV2lkdGggPSBzaGFsbG93UmVmKDApO1xuICBmdW5jdGlvbiB0cmlnZ2VyUmVzaXplKCkge1xuICAgIHZhciBfYTI7XG4gICAgaWYgKCF0ZXh0YXJlYS52YWx1ZSlcbiAgICAgIHJldHVybjtcbiAgICBsZXQgaGVpZ2h0ID0gXCJcIjtcbiAgICB0ZXh0YXJlYS52YWx1ZS5zdHlsZVtzdHlsZVByb3BdID0gXCIxcHhcIjtcbiAgICB0ZXh0YXJlYVNjcm9sbEhlaWdodC52YWx1ZSA9IChfYTIgPSB0ZXh0YXJlYS52YWx1ZSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hMi5zY3JvbGxIZWlnaHQ7XG4gICAgY29uc3QgX3N0eWxlVGFyZ2V0ID0gdG9WYWx1ZShvcHRpb25zID09IG51bGwgPyB2b2lkIDAgOiBvcHRpb25zLnN0eWxlVGFyZ2V0KTtcbiAgICBpZiAoX3N0eWxlVGFyZ2V0KVxuICAgICAgX3N0eWxlVGFyZ2V0LnN0eWxlW3N0eWxlUHJvcF0gPSBgJHt0ZXh0YXJlYVNjcm9sbEhlaWdodC52YWx1ZX1weGA7XG4gICAgZWxzZVxuICAgICAgaGVpZ2h0ID0gYCR7dGV4dGFyZWFTY3JvbGxIZWlnaHQudmFsdWV9cHhgO1xuICAgIHRleHRhcmVhLnZhbHVlLnN0eWxlW3N0eWxlUHJvcF0gPSBoZWlnaHQ7XG4gIH1cbiAgd2F0Y2goW2lucHV0LCB0ZXh0YXJlYV0sICgpID0+IG5leHRUaWNrKHRyaWdnZXJSZXNpemUpLCB7IGltbWVkaWF0ZTogdHJ1ZSB9KTtcbiAgd2F0Y2godGV4dGFyZWFTY3JvbGxIZWlnaHQsICgpID0+IHtcbiAgICB2YXIgX2EyO1xuICAgIHJldHVybiAoX2EyID0gb3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy5vblJlc2l6ZSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hMi5jYWxsKG9wdGlvbnMpO1xuICB9KTtcbiAgdXNlUmVzaXplT2JzZXJ2ZXIodGV4dGFyZWEsIChbeyBjb250ZW50UmVjdCB9XSkgPT4ge1xuICAgIGlmICh0ZXh0YXJlYU9sZFdpZHRoLnZhbHVlID09PSBjb250ZW50UmVjdC53aWR0aClcbiAgICAgIHJldHVybjtcbiAgICB0cnlSZXF1ZXN0QW5pbWF0aW9uRnJhbWUod2luZG93LCAoKSA9PiB7XG4gICAgICB0ZXh0YXJlYU9sZFdpZHRoLnZhbHVlID0gY29udGVudFJlY3Qud2lkdGg7XG4gICAgICB0cmlnZ2VyUmVzaXplKCk7XG4gICAgfSk7XG4gIH0pO1xuICBpZiAob3B0aW9ucyA9PSBudWxsID8gdm9pZCAwIDogb3B0aW9ucy53YXRjaClcbiAgICB3YXRjaChvcHRpb25zLndhdGNoLCB0cmlnZ2VyUmVzaXplLCB7IGltbWVkaWF0ZTogdHJ1ZSwgZGVlcDogdHJ1ZSB9KTtcbiAgcmV0dXJuIHtcbiAgICB0ZXh0YXJlYSxcbiAgICBpbnB1dCxcbiAgICB0cmlnZ2VyUmVzaXplXG4gIH07XG59XG5cbmZ1bmN0aW9uIHVzZVRocm90dGxlZFJlZkhpc3Rvcnkoc291cmNlLCBvcHRpb25zID0ge30pIHtcbiAgY29uc3QgeyB0aHJvdHRsZSA9IDIwMCwgdHJhaWxpbmcgPSB0cnVlIH0gPSBvcHRpb25zO1xuICBjb25zdCBmaWx0ZXIgPSB0aHJvdHRsZUZpbHRlcih0aHJvdHRsZSwgdHJhaWxpbmcpO1xuICBjb25zdCBoaXN0b3J5ID0gdXNlUmVmSGlzdG9yeShzb3VyY2UsIHsgLi4ub3B0aW9ucywgZXZlbnRGaWx0ZXI6IGZpbHRlciB9KTtcbiAgcmV0dXJuIHtcbiAgICAuLi5oaXN0b3J5XG4gIH07XG59XG5cbmNvbnN0IERFRkFVTFRfVU5JVFMgPSBbXG4gIHsgbWF4OiA2ZTQsIHZhbHVlOiAxZTMsIG5hbWU6IFwic2Vjb25kXCIgfSxcbiAgeyBtYXg6IDI3NmU0LCB2YWx1ZTogNmU0LCBuYW1lOiBcIm1pbnV0ZVwiIH0sXG4gIHsgbWF4OiA3MmU2LCB2YWx1ZTogMzZlNSwgbmFtZTogXCJob3VyXCIgfSxcbiAgeyBtYXg6IDUxODRlNSwgdmFsdWU6IDg2NGU1LCBuYW1lOiBcImRheVwiIH0sXG4gIHsgbWF4OiAyNDE5MmU1LCB2YWx1ZTogNjA0OGU1LCBuYW1lOiBcIndlZWtcIiB9LFxuICB7IG1heDogMjg1MTJlNiwgdmFsdWU6IDI1OTJlNiwgbmFtZTogXCJtb250aFwiIH0sXG4gIHsgbWF4OiBOdW1iZXIuUE9TSVRJVkVfSU5GSU5JVFksIHZhbHVlOiAzMTUzNmU2LCBuYW1lOiBcInllYXJcIiB9XG5dO1xuY29uc3QgREVGQVVMVF9NRVNTQUdFUyA9IHtcbiAganVzdE5vdzogXCJqdXN0IG5vd1wiLFxuICBwYXN0OiAobikgPT4gbi5tYXRjaCgvXFxkLykgPyBgJHtufSBhZ29gIDogbixcbiAgZnV0dXJlOiAobikgPT4gbi5tYXRjaCgvXFxkLykgPyBgaW4gJHtufWAgOiBuLFxuICBtb250aDogKG4sIHBhc3QpID0+IG4gPT09IDEgPyBwYXN0ID8gXCJsYXN0IG1vbnRoXCIgOiBcIm5leHQgbW9udGhcIiA6IGAke259IG1vbnRoJHtuID4gMSA/IFwic1wiIDogXCJcIn1gLFxuICB5ZWFyOiAobiwgcGFzdCkgPT4gbiA9PT0gMSA/IHBhc3QgPyBcImxhc3QgeWVhclwiIDogXCJuZXh0IHllYXJcIiA6IGAke259IHllYXIke24gPiAxID8gXCJzXCIgOiBcIlwifWAsXG4gIGRheTogKG4sIHBhc3QpID0+IG4gPT09IDEgPyBwYXN0ID8gXCJ5ZXN0ZXJkYXlcIiA6IFwidG9tb3Jyb3dcIiA6IGAke259IGRheSR7biA+IDEgPyBcInNcIiA6IFwiXCJ9YCxcbiAgd2VlazogKG4sIHBhc3QpID0+IG4gPT09IDEgPyBwYXN0ID8gXCJsYXN0IHdlZWtcIiA6IFwibmV4dCB3ZWVrXCIgOiBgJHtufSB3ZWVrJHtuID4gMSA/IFwic1wiIDogXCJcIn1gLFxuICBob3VyOiAobikgPT4gYCR7bn0gaG91ciR7biA+IDEgPyBcInNcIiA6IFwiXCJ9YCxcbiAgbWludXRlOiAobikgPT4gYCR7bn0gbWludXRlJHtuID4gMSA/IFwic1wiIDogXCJcIn1gLFxuICBzZWNvbmQ6IChuKSA9PiBgJHtufSBzZWNvbmQke24gPiAxID8gXCJzXCIgOiBcIlwifWAsXG4gIGludmFsaWQ6IFwiXCJcbn07XG5mdW5jdGlvbiBERUZBVUxUX0ZPUk1BVFRFUihkYXRlKSB7XG4gIHJldHVybiBkYXRlLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgMTApO1xufVxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHVzZVRpbWVBZ28odGltZSwgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBjb250cm9sczogZXhwb3NlQ29udHJvbHMgPSBmYWxzZSxcbiAgICB1cGRhdGVJbnRlcnZhbCA9IDNlNFxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgeyBub3csIC4uLmNvbnRyb2xzIH0gPSB1c2VOb3coeyBpbnRlcnZhbDogdXBkYXRlSW50ZXJ2YWwsIGNvbnRyb2xzOiB0cnVlIH0pO1xuICBjb25zdCB0aW1lQWdvID0gY29tcHV0ZWQoKCkgPT4gZm9ybWF0VGltZUFnbyhuZXcgRGF0ZSh0b1ZhbHVlKHRpbWUpKSwgb3B0aW9ucywgdG9WYWx1ZShub3cpKSk7XG4gIGlmIChleHBvc2VDb250cm9scykge1xuICAgIHJldHVybiB7XG4gICAgICB0aW1lQWdvLFxuICAgICAgLi4uY29udHJvbHNcbiAgICB9O1xuICB9IGVsc2Uge1xuICAgIHJldHVybiB0aW1lQWdvO1xuICB9XG59XG5mdW5jdGlvbiBmb3JtYXRUaW1lQWdvKGZyb20sIG9wdGlvbnMgPSB7fSwgbm93ID0gRGF0ZS5ub3coKSkge1xuICB2YXIgX2E7XG4gIGNvbnN0IHtcbiAgICBtYXgsXG4gICAgbWVzc2FnZXMgPSBERUZBVUxUX01FU1NBR0VTLFxuICAgIGZ1bGxEYXRlRm9ybWF0dGVyID0gREVGQVVMVF9GT1JNQVRURVIsXG4gICAgdW5pdHMgPSBERUZBVUxUX1VOSVRTLFxuICAgIHNob3dTZWNvbmQgPSBmYWxzZSxcbiAgICByb3VuZGluZyA9IFwicm91bmRcIlxuICB9ID0gb3B0aW9ucztcbiAgY29uc3Qgcm91bmRGbiA9IHR5cGVvZiByb3VuZGluZyA9PT0gXCJudW1iZXJcIiA/IChuKSA9PiArbi50b0ZpeGVkKHJvdW5kaW5nKSA6IE1hdGhbcm91bmRpbmddO1xuICBjb25zdCBkaWZmID0gK25vdyAtICtmcm9tO1xuICBjb25zdCBhYnNEaWZmID0gTWF0aC5hYnMoZGlmZik7XG4gIGZ1bmN0aW9uIGdldFZhbHVlKGRpZmYyLCB1bml0KSB7XG4gICAgcmV0dXJuIHJvdW5kRm4oTWF0aC5hYnMoZGlmZjIpIC8gdW5pdC52YWx1ZSk7XG4gIH1cbiAgZnVuY3Rpb24gZm9ybWF0KGRpZmYyLCB1bml0KSB7XG4gICAgY29uc3QgdmFsID0gZ2V0VmFsdWUoZGlmZjIsIHVuaXQpO1xuICAgIGNvbnN0IHBhc3QgPSBkaWZmMiA+IDA7XG4gICAgY29uc3Qgc3RyID0gYXBwbHlGb3JtYXQodW5pdC5uYW1lLCB2YWwsIHBhc3QpO1xuICAgIHJldHVybiBhcHBseUZvcm1hdChwYXN0ID8gXCJwYXN0XCIgOiBcImZ1dHVyZVwiLCBzdHIsIHBhc3QpO1xuICB9XG4gIGZ1bmN0aW9uIGFwcGx5Rm9ybWF0KG5hbWUsIHZhbCwgaXNQYXN0KSB7XG4gICAgY29uc3QgZm9ybWF0dGVyID0gbWVzc2FnZXNbbmFtZV07XG4gICAgaWYgKHR5cGVvZiBmb3JtYXR0ZXIgPT09IFwiZnVuY3Rpb25cIilcbiAgICAgIHJldHVybiBmb3JtYXR0ZXIodmFsLCBpc1Bhc3QpO1xuICAgIHJldHVybiBmb3JtYXR0ZXIucmVwbGFjZShcInswfVwiLCB2YWwudG9TdHJpbmcoKSk7XG4gIH1cbiAgaWYgKGFic0RpZmYgPCA2ZTQgJiYgIXNob3dTZWNvbmQpXG4gICAgcmV0dXJuIG1lc3NhZ2VzLmp1c3ROb3c7XG4gIGlmICh0eXBlb2YgbWF4ID09PSBcIm51bWJlclwiICYmIGFic0RpZmYgPiBtYXgpXG4gICAgcmV0dXJuIGZ1bGxEYXRlRm9ybWF0dGVyKG5ldyBEYXRlKGZyb20pKTtcbiAgaWYgKHR5cGVvZiBtYXggPT09IFwic3RyaW5nXCIpIHtcbiAgICBjb25zdCB1bml0TWF4ID0gKF9hID0gdW5pdHMuZmluZCgoaSkgPT4gaS5uYW1lID09PSBtYXgpKSA9PSBudWxsID8gdm9pZCAwIDogX2EubWF4O1xuICAgIGlmICh1bml0TWF4ICYmIGFic0RpZmYgPiB1bml0TWF4KVxuICAgICAgcmV0dXJuIGZ1bGxEYXRlRm9ybWF0dGVyKG5ldyBEYXRlKGZyb20pKTtcbiAgfVxuICBmb3IgKGNvbnN0IFtpZHgsIHVuaXRdIG9mIHVuaXRzLmVudHJpZXMoKSkge1xuICAgIGNvbnN0IHZhbCA9IGdldFZhbHVlKGRpZmYsIHVuaXQpO1xuICAgIGlmICh2YWwgPD0gMCAmJiB1bml0c1tpZHggLSAxXSlcbiAgICAgIHJldHVybiBmb3JtYXQoZGlmZiwgdW5pdHNbaWR4IC0gMV0pO1xuICAgIGlmIChhYnNEaWZmIDwgdW5pdC5tYXgpXG4gICAgICByZXR1cm4gZm9ybWF0KGRpZmYsIHVuaXQpO1xuICB9XG4gIHJldHVybiBtZXNzYWdlcy5pbnZhbGlkO1xufVxuXG5jb25zdCBVTklUUyA9IFtcbiAgeyBuYW1lOiBcInllYXJcIiwgbXM6IDMxNTM2ZTYgfSxcbiAgeyBuYW1lOiBcIm1vbnRoXCIsIG1zOiAyNTkyZTYgfSxcbiAgeyBuYW1lOiBcIndlZWtcIiwgbXM6IDYwNDhlNSB9LFxuICB7IG5hbWU6IFwiZGF5XCIsIG1zOiA4NjRlNSB9LFxuICB7IG5hbWU6IFwiaG91clwiLCBtczogMzZlNSB9LFxuICB7IG5hbWU6IFwibWludXRlXCIsIG1zOiA2ZTQgfSxcbiAgeyBuYW1lOiBcInNlY29uZFwiLCBtczogMWUzIH1cbl07XG5mdW5jdGlvbiB1c2VUaW1lQWdvSW50bCh0aW1lLCBvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGNvbnRyb2xzOiBleHBvc2VDb250cm9scyA9IGZhbHNlLFxuICAgIHVwZGF0ZUludGVydmFsID0gM2U0XG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCB7IG5vdywgLi4uY29udHJvbHMgfSA9IHVzZU5vdyh7IGludGVydmFsOiB1cGRhdGVJbnRlcnZhbCwgY29udHJvbHM6IHRydWUgfSk7XG4gIGNvbnN0IHJlc3VsdCA9IGNvbXB1dGVkKFxuICAgICgpID0+IGdldFRpbWVBZ29JbnRsUmVzdWx0KG5ldyBEYXRlKHRvVmFsdWUodGltZSkpLCBvcHRpb25zLCB0b1ZhbHVlKG5vdykpXG4gICk7XG4gIGNvbnN0IHBhcnRzID0gY29tcHV0ZWQoKCkgPT4gcmVzdWx0LnZhbHVlLnBhcnRzKTtcbiAgY29uc3QgdGltZUFnb0ludGwgPSBjb21wdXRlZChcbiAgICAoKSA9PiBmb3JtYXRUaW1lQWdvSW50bFBhcnRzKHBhcnRzLnZhbHVlLCB7XG4gICAgICAuLi5vcHRpb25zLFxuICAgICAgbG9jYWxlOiByZXN1bHQudmFsdWUucmVzb2x2ZWRMb2NhbGVcbiAgICB9KVxuICApO1xuICByZXR1cm4gZXhwb3NlQ29udHJvbHMgPyB7IHRpbWVBZ29JbnRsLCBwYXJ0cywgLi4uY29udHJvbHMgfSA6IHRpbWVBZ29JbnRsO1xufVxuZnVuY3Rpb24gZm9ybWF0VGltZUFnb0ludGwoZnJvbSwgb3B0aW9ucyA9IHt9LCBub3cgPSBEYXRlLm5vdygpKSB7XG4gIGNvbnN0IHsgcGFydHMsIHJlc29sdmVkTG9jYWxlIH0gPSBnZXRUaW1lQWdvSW50bFJlc3VsdChmcm9tLCBvcHRpb25zLCBub3cpO1xuICByZXR1cm4gZm9ybWF0VGltZUFnb0ludGxQYXJ0cyhwYXJ0cywge1xuICAgIC4uLm9wdGlvbnMsXG4gICAgbG9jYWxlOiByZXNvbHZlZExvY2FsZVxuICB9KTtcbn1cbmZ1bmN0aW9uIGdldFRpbWVBZ29JbnRsUmVzdWx0KGZyb20sIG9wdGlvbnMgPSB7fSwgbm93ID0gRGF0ZS5ub3coKSkge1xuICBjb25zdCB7XG4gICAgbG9jYWxlLFxuICAgIHJlbGF0aXZlVGltZUZvcm1hdE9wdGlvbnMgPSB7IG51bWVyaWM6IFwiYXV0b1wiIH1cbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IHJ0ZiA9IG5ldyBJbnRsLlJlbGF0aXZlVGltZUZvcm1hdChsb2NhbGUsIHJlbGF0aXZlVGltZUZvcm1hdE9wdGlvbnMpO1xuICBjb25zdCB7IGxvY2FsZTogcmVzb2x2ZWRMb2NhbGUgfSA9IHJ0Zi5yZXNvbHZlZE9wdGlvbnMoKTtcbiAgY29uc3QgZGlmZiA9ICtmcm9tIC0gK25vdztcbiAgY29uc3QgYWJzRGlmZiA9IE1hdGguYWJzKGRpZmYpO1xuICBmb3IgKGNvbnN0IHsgbmFtZSwgbXMgfSBvZiBVTklUUykge1xuICAgIGlmIChhYnNEaWZmID49IG1zKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICByZXNvbHZlZExvY2FsZSxcbiAgICAgICAgcGFydHM6IHJ0Zi5mb3JtYXRUb1BhcnRzKE1hdGgucm91bmQoZGlmZiAvIG1zKSwgbmFtZSlcbiAgICAgIH07XG4gICAgfVxuICB9XG4gIHJldHVybiB7XG4gICAgcmVzb2x2ZWRMb2NhbGUsXG4gICAgcGFydHM6IHJ0Zi5mb3JtYXRUb1BhcnRzKDAsIFwic2Vjb25kXCIpXG4gIH07XG59XG5mdW5jdGlvbiBmb3JtYXRUaW1lQWdvSW50bFBhcnRzKHBhcnRzLCBvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGluc2VydFNwYWNlID0gdHJ1ZSxcbiAgICBqb2luUGFydHMsXG4gICAgbG9jYWxlXG4gIH0gPSBvcHRpb25zO1xuICBpZiAodHlwZW9mIGpvaW5QYXJ0cyA9PT0gXCJmdW5jdGlvblwiKVxuICAgIHJldHVybiBqb2luUGFydHMocGFydHMsIGxvY2FsZSk7XG4gIGlmICghaW5zZXJ0U3BhY2UpXG4gICAgcmV0dXJuIHBhcnRzLm1hcCgocGFydCkgPT4gcGFydC52YWx1ZSkuam9pbihcIlwiKTtcbiAgcmV0dXJuIHBhcnRzLm1hcCgocGFydCkgPT4gcGFydC52YWx1ZS50cmltKCkpLmpvaW4oXCIgXCIpO1xufVxuXG5mdW5jdGlvbiB1c2VUaW1lb3V0UG9sbChmbiwgaW50ZXJ2YWwsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgaW1tZWRpYXRlID0gdHJ1ZSxcbiAgICBpbW1lZGlhdGVDYWxsYmFjayA9IGZhbHNlXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCB7IHN0YXJ0IH0gPSB1c2VUaW1lb3V0Rm4obG9vcCwgaW50ZXJ2YWwsIHsgaW1tZWRpYXRlIH0pO1xuICBjb25zdCBpc0FjdGl2ZSA9IHNoYWxsb3dSZWYoZmFsc2UpO1xuICBhc3luYyBmdW5jdGlvbiBsb29wKCkge1xuICAgIGlmICghaXNBY3RpdmUudmFsdWUpXG4gICAgICByZXR1cm47XG4gICAgYXdhaXQgZm4oKTtcbiAgICBzdGFydCgpO1xuICB9XG4gIGZ1bmN0aW9uIHJlc3VtZSgpIHtcbiAgICBpZiAoIWlzQWN0aXZlLnZhbHVlKSB7XG4gICAgICBpc0FjdGl2ZS52YWx1ZSA9IHRydWU7XG4gICAgICBpZiAoaW1tZWRpYXRlQ2FsbGJhY2spXG4gICAgICAgIGZuKCk7XG4gICAgICBzdGFydCgpO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBwYXVzZSgpIHtcbiAgICBpc0FjdGl2ZS52YWx1ZSA9IGZhbHNlO1xuICB9XG4gIGlmIChpbW1lZGlhdGUgJiYgaXNDbGllbnQpXG4gICAgcmVzdW1lKCk7XG4gIHRyeU9uU2NvcGVEaXNwb3NlKHBhdXNlKTtcbiAgcmV0dXJuIHtcbiAgICBpc0FjdGl2ZSxcbiAgICBwYXVzZSxcbiAgICByZXN1bWVcbiAgfTtcbn1cblxuZnVuY3Rpb24gdXNlVGltZXN0YW1wKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgY29udHJvbHM6IGV4cG9zZUNvbnRyb2xzID0gZmFsc2UsXG4gICAgb2Zmc2V0ID0gMCxcbiAgICBpbW1lZGlhdGUgPSB0cnVlLFxuICAgIGludGVydmFsID0gXCJyZXF1ZXN0QW5pbWF0aW9uRnJhbWVcIixcbiAgICBjYWxsYmFja1xuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgdHMgPSBzaGFsbG93UmVmKHRpbWVzdGFtcCgpICsgb2Zmc2V0KTtcbiAgY29uc3QgdXBkYXRlID0gKCkgPT4gdHMudmFsdWUgPSB0aW1lc3RhbXAoKSArIG9mZnNldDtcbiAgY29uc3QgY2IgPSBjYWxsYmFjayA/ICgpID0+IHtcbiAgICB1cGRhdGUoKTtcbiAgICBjYWxsYmFjayh0cy52YWx1ZSk7XG4gIH0gOiB1cGRhdGU7XG4gIGNvbnN0IGNvbnRyb2xzID0gaW50ZXJ2YWwgPT09IFwicmVxdWVzdEFuaW1hdGlvbkZyYW1lXCIgPyB1c2VSYWZGbihjYiwgeyBpbW1lZGlhdGUgfSkgOiB1c2VJbnRlcnZhbEZuKGNiLCBpbnRlcnZhbCwgeyBpbW1lZGlhdGUgfSk7XG4gIGlmIChleHBvc2VDb250cm9scykge1xuICAgIHJldHVybiB7XG4gICAgICB0aW1lc3RhbXA6IHRzLFxuICAgICAgLi4uY29udHJvbHNcbiAgICB9O1xuICB9IGVsc2Uge1xuICAgIHJldHVybiB0cztcbiAgfVxufVxuXG5mdW5jdGlvbiB1c2VUaXRsZShuZXdUaXRsZSA9IG51bGwsIG9wdGlvbnMgPSB7fSkge1xuICB2YXIgX2EsIF9iLCBfYztcbiAgY29uc3Qge1xuICAgIGRvY3VtZW50ID0gZGVmYXVsdERvY3VtZW50LFxuICAgIHJlc3RvcmVPblVubW91bnQgPSAodCkgPT4gdFxuICB9ID0gb3B0aW9ucztcbiAgY29uc3Qgb3JpZ2luYWxUaXRsZSA9IChfYSA9IGRvY3VtZW50ID09IG51bGwgPyB2b2lkIDAgOiBkb2N1bWVudC50aXRsZSkgIT0gbnVsbCA/IF9hIDogXCJcIjtcbiAgY29uc3QgdGl0bGUgPSB0b1JlZigoX2IgPSBuZXdUaXRsZSAhPSBudWxsID8gbmV3VGl0bGUgOiBkb2N1bWVudCA9PSBudWxsID8gdm9pZCAwIDogZG9jdW1lbnQudGl0bGUpICE9IG51bGwgPyBfYiA6IG51bGwpO1xuICBjb25zdCBpc1JlYWRvbmx5ID0gISEobmV3VGl0bGUgJiYgdHlwZW9mIG5ld1RpdGxlID09PSBcImZ1bmN0aW9uXCIpO1xuICBmdW5jdGlvbiBmb3JtYXQodCkge1xuICAgIGlmICghKFwidGl0bGVUZW1wbGF0ZVwiIGluIG9wdGlvbnMpKVxuICAgICAgcmV0dXJuIHQ7XG4gICAgY29uc3QgdGVtcGxhdGUgPSBvcHRpb25zLnRpdGxlVGVtcGxhdGUgfHwgXCIlc1wiO1xuICAgIHJldHVybiB0eXBlb2YgdGVtcGxhdGUgPT09IFwiZnVuY3Rpb25cIiA/IHRlbXBsYXRlKHQpIDogdG9WYWx1ZSh0ZW1wbGF0ZSkucmVwbGFjZSgvJXMvZywgdCk7XG4gIH1cbiAgd2F0Y2goXG4gICAgdGl0bGUsXG4gICAgKG5ld1ZhbHVlLCBvbGRWYWx1ZSkgPT4ge1xuICAgICAgaWYgKG5ld1ZhbHVlICE9PSBvbGRWYWx1ZSAmJiBkb2N1bWVudClcbiAgICAgICAgZG9jdW1lbnQudGl0bGUgPSBmb3JtYXQobmV3VmFsdWUgIT0gbnVsbCA/IG5ld1ZhbHVlIDogXCJcIik7XG4gICAgfSxcbiAgICB7IGltbWVkaWF0ZTogdHJ1ZSB9XG4gICk7XG4gIGlmIChvcHRpb25zLm9ic2VydmUgJiYgIW9wdGlvbnMudGl0bGVUZW1wbGF0ZSAmJiBkb2N1bWVudCAmJiAhaXNSZWFkb25seSkge1xuICAgIHVzZU11dGF0aW9uT2JzZXJ2ZXIoXG4gICAgICAoX2MgPSBkb2N1bWVudC5oZWFkKSA9PSBudWxsID8gdm9pZCAwIDogX2MucXVlcnlTZWxlY3RvcihcInRpdGxlXCIpLFxuICAgICAgKCkgPT4ge1xuICAgICAgICBpZiAoZG9jdW1lbnQgJiYgZG9jdW1lbnQudGl0bGUgIT09IHRpdGxlLnZhbHVlKVxuICAgICAgICAgIHRpdGxlLnZhbHVlID0gZm9ybWF0KGRvY3VtZW50LnRpdGxlKTtcbiAgICAgIH0sXG4gICAgICB7IGNoaWxkTGlzdDogdHJ1ZSB9XG4gICAgKTtcbiAgfVxuICB0cnlPblNjb3BlRGlzcG9zZSgoKSA9PiB7XG4gICAgaWYgKHJlc3RvcmVPblVubW91bnQpIHtcbiAgICAgIGNvbnN0IHJlc3RvcmVkVGl0bGUgPSByZXN0b3JlT25Vbm1vdW50KG9yaWdpbmFsVGl0bGUsIHRpdGxlLnZhbHVlIHx8IFwiXCIpO1xuICAgICAgaWYgKHJlc3RvcmVkVGl0bGUgIT0gbnVsbCAmJiBkb2N1bWVudClcbiAgICAgICAgZG9jdW1lbnQudGl0bGUgPSByZXN0b3JlZFRpdGxlO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiB0aXRsZTtcbn1cblxuY29uc3QgX1RyYW5zaXRpb25QcmVzZXRzID0ge1xuICBlYXNlSW5TaW5lOiBbMC4xMiwgMCwgMC4zOSwgMF0sXG4gIGVhc2VPdXRTaW5lOiBbMC42MSwgMSwgMC44OCwgMV0sXG4gIGVhc2VJbk91dFNpbmU6IFswLjM3LCAwLCAwLjYzLCAxXSxcbiAgZWFzZUluUXVhZDogWzAuMTEsIDAsIDAuNSwgMF0sXG4gIGVhc2VPdXRRdWFkOiBbMC41LCAxLCAwLjg5LCAxXSxcbiAgZWFzZUluT3V0UXVhZDogWzAuNDUsIDAsIDAuNTUsIDFdLFxuICBlYXNlSW5DdWJpYzogWzAuMzIsIDAsIDAuNjcsIDBdLFxuICBlYXNlT3V0Q3ViaWM6IFswLjMzLCAxLCAwLjY4LCAxXSxcbiAgZWFzZUluT3V0Q3ViaWM6IFswLjY1LCAwLCAwLjM1LCAxXSxcbiAgZWFzZUluUXVhcnQ6IFswLjUsIDAsIDAuNzUsIDBdLFxuICBlYXNlT3V0UXVhcnQ6IFswLjI1LCAxLCAwLjUsIDFdLFxuICBlYXNlSW5PdXRRdWFydDogWzAuNzYsIDAsIDAuMjQsIDFdLFxuICBlYXNlSW5RdWludDogWzAuNjQsIDAsIDAuNzgsIDBdLFxuICBlYXNlT3V0UXVpbnQ6IFswLjIyLCAxLCAwLjM2LCAxXSxcbiAgZWFzZUluT3V0UXVpbnQ6IFswLjgzLCAwLCAwLjE3LCAxXSxcbiAgZWFzZUluRXhwbzogWzAuNywgMCwgMC44NCwgMF0sXG4gIGVhc2VPdXRFeHBvOiBbMC4xNiwgMSwgMC4zLCAxXSxcbiAgZWFzZUluT3V0RXhwbzogWzAuODcsIDAsIDAuMTMsIDFdLFxuICBlYXNlSW5DaXJjOiBbMC41NSwgMCwgMSwgMC40NV0sXG4gIGVhc2VPdXRDaXJjOiBbMCwgMC41NSwgMC40NSwgMV0sXG4gIGVhc2VJbk91dENpcmM6IFswLjg1LCAwLCAwLjE1LCAxXSxcbiAgZWFzZUluQmFjazogWzAuMzYsIDAsIDAuNjYsIC0wLjU2XSxcbiAgZWFzZU91dEJhY2s6IFswLjM0LCAxLjU2LCAwLjY0LCAxXSxcbiAgZWFzZUluT3V0QmFjazogWzAuNjgsIC0wLjYsIDAuMzIsIDEuNl1cbn07XG5jb25zdCBUcmFuc2l0aW9uUHJlc2V0cyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuYXNzaWduKHt9LCB7IGxpbmVhcjogaWRlbnRpdHkgfSwgX1RyYW5zaXRpb25QcmVzZXRzKTtcbmZ1bmN0aW9uIGNyZWF0ZUVhc2luZ0Z1bmN0aW9uKFtwMCwgcDEsIHAyLCBwM10pIHtcbiAgY29uc3QgYSA9IChhMSwgYTIpID0+IDEgLSAzICogYTIgKyAzICogYTE7XG4gIGNvbnN0IGIgPSAoYTEsIGEyKSA9PiAzICogYTIgLSA2ICogYTE7XG4gIGNvbnN0IGMgPSAoYTEpID0+IDMgKiBhMTtcbiAgY29uc3QgY2FsY0JlemllciA9ICh0LCBhMSwgYTIpID0+ICgoYShhMSwgYTIpICogdCArIGIoYTEsIGEyKSkgKiB0ICsgYyhhMSkpICogdDtcbiAgY29uc3QgZ2V0U2xvcGUgPSAodCwgYTEsIGEyKSA9PiAzICogYShhMSwgYTIpICogdCAqIHQgKyAyICogYihhMSwgYTIpICogdCArIGMoYTEpO1xuICBjb25zdCBnZXRUZm9yWCA9ICh4KSA9PiB7XG4gICAgbGV0IGFHdWVzc1QgPSB4O1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgNDsgKytpKSB7XG4gICAgICBjb25zdCBjdXJyZW50U2xvcGUgPSBnZXRTbG9wZShhR3Vlc3NULCBwMCwgcDIpO1xuICAgICAgaWYgKGN1cnJlbnRTbG9wZSA9PT0gMClcbiAgICAgICAgcmV0dXJuIGFHdWVzc1Q7XG4gICAgICBjb25zdCBjdXJyZW50WCA9IGNhbGNCZXppZXIoYUd1ZXNzVCwgcDAsIHAyKSAtIHg7XG4gICAgICBhR3Vlc3NUIC09IGN1cnJlbnRYIC8gY3VycmVudFNsb3BlO1xuICAgIH1cbiAgICByZXR1cm4gYUd1ZXNzVDtcbiAgfTtcbiAgcmV0dXJuICh4KSA9PiBwMCA9PT0gcDEgJiYgcDIgPT09IHAzID8geCA6IGNhbGNCZXppZXIoZ2V0VGZvclgoeCksIHAxLCBwMyk7XG59XG5mdW5jdGlvbiBsZXJwKGEsIGIsIGFscGhhKSB7XG4gIHJldHVybiBhICsgYWxwaGEgKiAoYiAtIGEpO1xufVxuZnVuY3Rpb24gdG9WZWModCkge1xuICByZXR1cm4gKHR5cGVvZiB0ID09PSBcIm51bWJlclwiID8gW3RdIDogdCkgfHwgW107XG59XG5mdW5jdGlvbiBleGVjdXRlVHJhbnNpdGlvbihzb3VyY2UsIGZyb20sIHRvLCBvcHRpb25zID0ge30pIHtcbiAgdmFyIF9hLCBfYjtcbiAgY29uc3Qge1xuICAgIHdpbmRvdyA9IGRlZmF1bHRXaW5kb3dcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGZyb21WYWwgPSB0b1ZhbHVlKGZyb20pO1xuICBjb25zdCB0b1ZhbCA9IHRvVmFsdWUodG8pO1xuICBjb25zdCB2MSA9IHRvVmVjKGZyb21WYWwpO1xuICBjb25zdCB2MiA9IHRvVmVjKHRvVmFsKTtcbiAgY29uc3QgZHVyYXRpb24gPSAoX2EgPSB0b1ZhbHVlKG9wdGlvbnMuZHVyYXRpb24pKSAhPSBudWxsID8gX2EgOiAxZTM7XG4gIGNvbnN0IHN0YXJ0ZWRBdCA9IERhdGUubm93KCk7XG4gIGNvbnN0IGVuZEF0ID0gRGF0ZS5ub3coKSArIGR1cmF0aW9uO1xuICBjb25zdCB0cmFucyA9IHR5cGVvZiBvcHRpb25zLnRyYW5zaXRpb24gPT09IFwiZnVuY3Rpb25cIiA/IG9wdGlvbnMudHJhbnNpdGlvbiA6IChfYiA9IHRvVmFsdWUob3B0aW9ucy50cmFuc2l0aW9uKSkgIT0gbnVsbCA/IF9iIDogaWRlbnRpdHk7XG4gIGNvbnN0IGVhc2UgPSB0eXBlb2YgdHJhbnMgPT09IFwiZnVuY3Rpb25cIiA/IHRyYW5zIDogY3JlYXRlRWFzaW5nRnVuY3Rpb24odHJhbnMpO1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICBzb3VyY2UudmFsdWUgPSBmcm9tVmFsO1xuICAgIGNvbnN0IHRpY2sgPSAoKSA9PiB7XG4gICAgICB2YXIgX2EyO1xuICAgICAgaWYgKChfYTIgPSBvcHRpb25zLmFib3J0KSA9PSBudWxsID8gdm9pZCAwIDogX2EyLmNhbGwob3B0aW9ucykpIHtcbiAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICAgICAgY29uc3QgYWxwaGEgPSBlYXNlKChub3cgLSBzdGFydGVkQXQpIC8gZHVyYXRpb24pO1xuICAgICAgY29uc3QgYXJyID0gdG9WZWMoc291cmNlLnZhbHVlKS5tYXAoKG4sIGkpID0+IGxlcnAodjFbaV0sIHYyW2ldLCBhbHBoYSkpO1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoc291cmNlLnZhbHVlKSlcbiAgICAgICAgc291cmNlLnZhbHVlID0gYXJyLm1hcCgobiwgaSkgPT4ge1xuICAgICAgICAgIHZhciBfYTMsIF9iMjtcbiAgICAgICAgICByZXR1cm4gbGVycCgoX2EzID0gdjFbaV0pICE9IG51bGwgPyBfYTMgOiAwLCAoX2IyID0gdjJbaV0pICE9IG51bGwgPyBfYjIgOiAwLCBhbHBoYSk7XG4gICAgICAgIH0pO1xuICAgICAgZWxzZSBpZiAodHlwZW9mIHNvdXJjZS52YWx1ZSA9PT0gXCJudW1iZXJcIilcbiAgICAgICAgc291cmNlLnZhbHVlID0gYXJyWzBdO1xuICAgICAgaWYgKG5vdyA8IGVuZEF0KSB7XG4gICAgICAgIHdpbmRvdyA9PSBudWxsID8gdm9pZCAwIDogd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSh0aWNrKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNvdXJjZS52YWx1ZSA9IHRvVmFsO1xuICAgICAgICByZXNvbHZlKCk7XG4gICAgICB9XG4gICAgfTtcbiAgICB0aWNrKCk7XG4gIH0pO1xufVxuZnVuY3Rpb24gdXNlVHJhbnNpdGlvbihzb3VyY2UsIG9wdGlvbnMgPSB7fSkge1xuICBsZXQgY3VycmVudElkID0gMDtcbiAgY29uc3Qgc291cmNlVmFsID0gKCkgPT4ge1xuICAgIGNvbnN0IHYgPSB0b1ZhbHVlKHNvdXJjZSk7XG4gICAgcmV0dXJuIHR5cGVvZiB2ID09PSBcIm51bWJlclwiID8gdiA6IHYubWFwKHRvVmFsdWUpO1xuICB9O1xuICBjb25zdCBvdXRwdXRSZWYgPSByZWYoc291cmNlVmFsKCkpO1xuICB3YXRjaChzb3VyY2VWYWwsIGFzeW5jICh0bykgPT4ge1xuICAgIHZhciBfYSwgX2I7XG4gICAgaWYgKHRvVmFsdWUob3B0aW9ucy5kaXNhYmxlZCkpXG4gICAgICByZXR1cm47XG4gICAgY29uc3QgaWQgPSArK2N1cnJlbnRJZDtcbiAgICBpZiAob3B0aW9ucy5kZWxheSlcbiAgICAgIGF3YWl0IHByb21pc2VUaW1lb3V0KHRvVmFsdWUob3B0aW9ucy5kZWxheSkpO1xuICAgIGlmIChpZCAhPT0gY3VycmVudElkKVxuICAgICAgcmV0dXJuO1xuICAgIGNvbnN0IHRvVmFsID0gQXJyYXkuaXNBcnJheSh0bykgPyB0by5tYXAodG9WYWx1ZSkgOiB0b1ZhbHVlKHRvKTtcbiAgICAoX2EgPSBvcHRpb25zLm9uU3RhcnRlZCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLmNhbGwob3B0aW9ucyk7XG4gICAgYXdhaXQgZXhlY3V0ZVRyYW5zaXRpb24ob3V0cHV0UmVmLCBvdXRwdXRSZWYudmFsdWUsIHRvVmFsLCB7XG4gICAgICAuLi5vcHRpb25zLFxuICAgICAgYWJvcnQ6ICgpID0+IHtcbiAgICAgICAgdmFyIF9hMjtcbiAgICAgICAgcmV0dXJuIGlkICE9PSBjdXJyZW50SWQgfHwgKChfYTIgPSBvcHRpb25zLmFib3J0KSA9PSBudWxsID8gdm9pZCAwIDogX2EyLmNhbGwob3B0aW9ucykpO1xuICAgICAgfVxuICAgIH0pO1xuICAgIChfYiA9IG9wdGlvbnMub25GaW5pc2hlZCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9iLmNhbGwob3B0aW9ucyk7XG4gIH0sIHsgZGVlcDogdHJ1ZSB9KTtcbiAgd2F0Y2goKCkgPT4gdG9WYWx1ZShvcHRpb25zLmRpc2FibGVkKSwgKGRpc2FibGVkKSA9PiB7XG4gICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICBjdXJyZW50SWQrKztcbiAgICAgIG91dHB1dFJlZi52YWx1ZSA9IHNvdXJjZVZhbCgpO1xuICAgIH1cbiAgfSk7XG4gIHRyeU9uU2NvcGVEaXNwb3NlKCgpID0+IHtcbiAgICBjdXJyZW50SWQrKztcbiAgfSk7XG4gIHJldHVybiBjb21wdXRlZCgoKSA9PiB0b1ZhbHVlKG9wdGlvbnMuZGlzYWJsZWQpID8gc291cmNlVmFsKCkgOiBvdXRwdXRSZWYudmFsdWUpO1xufVxuXG5mdW5jdGlvbiB1c2VVcmxTZWFyY2hQYXJhbXMobW9kZSA9IFwiaGlzdG9yeVwiLCBvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGluaXRpYWxWYWx1ZSA9IHt9LFxuICAgIHJlbW92ZU51bGxpc2hWYWx1ZXMgPSB0cnVlLFxuICAgIHJlbW92ZUZhbHN5VmFsdWVzID0gZmFsc2UsXG4gICAgd3JpdGU6IGVuYWJsZVdyaXRlID0gdHJ1ZSxcbiAgICB3cml0ZU1vZGUgPSBcInJlcGxhY2VcIixcbiAgICB3aW5kb3cgPSBkZWZhdWx0V2luZG93LFxuICAgIHN0cmluZ2lmeSA9IChwYXJhbXMpID0+IHBhcmFtcy50b1N0cmluZygpXG4gIH0gPSBvcHRpb25zO1xuICBpZiAoIXdpbmRvdylcbiAgICByZXR1cm4gcmVhY3RpdmUoaW5pdGlhbFZhbHVlKTtcbiAgY29uc3Qgc3RhdGUgPSByZWFjdGl2ZSh7fSk7XG4gIGZ1bmN0aW9uIGdldFJhd1BhcmFtcygpIHtcbiAgICBpZiAobW9kZSA9PT0gXCJoaXN0b3J5XCIpIHtcbiAgICAgIHJldHVybiB3aW5kb3cubG9jYXRpb24uc2VhcmNoIHx8IFwiXCI7XG4gICAgfSBlbHNlIGlmIChtb2RlID09PSBcImhhc2hcIikge1xuICAgICAgY29uc3QgaGFzaCA9IHdpbmRvdy5sb2NhdGlvbi5oYXNoIHx8IFwiXCI7XG4gICAgICBjb25zdCBpbmRleCA9IGhhc2guaW5kZXhPZihcIj9cIik7XG4gICAgICByZXR1cm4gaW5kZXggPiAwID8gaGFzaC5zbGljZShpbmRleCkgOiBcIlwiO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gKHdpbmRvdy5sb2NhdGlvbi5oYXNoIHx8IFwiXCIpLnJlcGxhY2UoL14jLywgXCJcIik7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIGNvbnN0cnVjdFF1ZXJ5KHBhcmFtcykge1xuICAgIGNvbnN0IHN0cmluZ2lmaWVkID0gc3RyaW5naWZ5KHBhcmFtcyk7XG4gICAgaWYgKG1vZGUgPT09IFwiaGlzdG9yeVwiKVxuICAgICAgcmV0dXJuIGAke3N0cmluZ2lmaWVkID8gYD8ke3N0cmluZ2lmaWVkfWAgOiBcIlwifSR7d2luZG93LmxvY2F0aW9uLmhhc2ggfHwgXCJcIn1gO1xuICAgIGlmIChtb2RlID09PSBcImhhc2gtcGFyYW1zXCIpXG4gICAgICByZXR1cm4gYCR7d2luZG93LmxvY2F0aW9uLnNlYXJjaCB8fCBcIlwifSR7c3RyaW5naWZpZWQgPyBgIyR7c3RyaW5naWZpZWR9YCA6IFwiXCJ9YDtcbiAgICBjb25zdCBoYXNoID0gd2luZG93LmxvY2F0aW9uLmhhc2ggfHwgXCIjXCI7XG4gICAgY29uc3QgaW5kZXggPSBoYXNoLmluZGV4T2YoXCI/XCIpO1xuICAgIGlmIChpbmRleCA+IDApXG4gICAgICByZXR1cm4gYCR7d2luZG93LmxvY2F0aW9uLnNlYXJjaCB8fCBcIlwifSR7aGFzaC5zbGljZSgwLCBpbmRleCl9JHtzdHJpbmdpZmllZCA/IGA/JHtzdHJpbmdpZmllZH1gIDogXCJcIn1gO1xuICAgIHJldHVybiBgJHt3aW5kb3cubG9jYXRpb24uc2VhcmNoIHx8IFwiXCJ9JHtoYXNofSR7c3RyaW5naWZpZWQgPyBgPyR7c3RyaW5naWZpZWR9YCA6IFwiXCJ9YDtcbiAgfVxuICBmdW5jdGlvbiByZWFkKCkge1xuICAgIHJldHVybiBuZXcgVVJMU2VhcmNoUGFyYW1zKGdldFJhd1BhcmFtcygpKTtcbiAgfVxuICBmdW5jdGlvbiB1cGRhdGVTdGF0ZShwYXJhbXMpIHtcbiAgICBjb25zdCB1bnVzZWRLZXlzID0gbmV3IFNldChPYmplY3Qua2V5cyhzdGF0ZSkpO1xuICAgIGZvciAoY29uc3Qga2V5IG9mIHBhcmFtcy5rZXlzKCkpIHtcbiAgICAgIGNvbnN0IHBhcmFtc0ZvcktleSA9IHBhcmFtcy5nZXRBbGwoa2V5KTtcbiAgICAgIHN0YXRlW2tleV0gPSBwYXJhbXNGb3JLZXkubGVuZ3RoID4gMSA/IHBhcmFtc0ZvcktleSA6IHBhcmFtcy5nZXQoa2V5KSB8fCBcIlwiO1xuICAgICAgdW51c2VkS2V5cy5kZWxldGUoa2V5KTtcbiAgICB9XG4gICAgQXJyYXkuZnJvbSh1bnVzZWRLZXlzKS5mb3JFYWNoKChrZXkpID0+IGRlbGV0ZSBzdGF0ZVtrZXldKTtcbiAgfVxuICBjb25zdCB7IHBhdXNlLCByZXN1bWUgfSA9IHBhdXNhYmxlV2F0Y2goXG4gICAgc3RhdGUsXG4gICAgKCkgPT4ge1xuICAgICAgY29uc3QgcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhcIlwiKTtcbiAgICAgIE9iamVjdC5rZXlzKHN0YXRlKS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgICAgY29uc3QgbWFwRW50cnkgPSBzdGF0ZVtrZXldO1xuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShtYXBFbnRyeSkpXG4gICAgICAgICAgbWFwRW50cnkuZm9yRWFjaCgodmFsdWUpID0+IHBhcmFtcy5hcHBlbmQoa2V5LCB2YWx1ZSkpO1xuICAgICAgICBlbHNlIGlmIChyZW1vdmVOdWxsaXNoVmFsdWVzICYmIG1hcEVudHJ5ID09IG51bGwpXG4gICAgICAgICAgcGFyYW1zLmRlbGV0ZShrZXkpO1xuICAgICAgICBlbHNlIGlmIChyZW1vdmVGYWxzeVZhbHVlcyAmJiAhbWFwRW50cnkpXG4gICAgICAgICAgcGFyYW1zLmRlbGV0ZShrZXkpO1xuICAgICAgICBlbHNlXG4gICAgICAgICAgcGFyYW1zLnNldChrZXksIG1hcEVudHJ5KTtcbiAgICAgIH0pO1xuICAgICAgd3JpdGUocGFyYW1zLCBmYWxzZSk7XG4gICAgfSxcbiAgICB7IGRlZXA6IHRydWUgfVxuICApO1xuICBmdW5jdGlvbiB3cml0ZShwYXJhbXMsIHNob3VsZFVwZGF0ZSwgc2hvdWxkV3JpdGVIaXN0b3J5ID0gdHJ1ZSkge1xuICAgIHBhdXNlKCk7XG4gICAgaWYgKHNob3VsZFVwZGF0ZSlcbiAgICAgIHVwZGF0ZVN0YXRlKHBhcmFtcyk7XG4gICAgaWYgKHdyaXRlTW9kZSA9PT0gXCJyZXBsYWNlXCIpIHtcbiAgICAgIHdpbmRvdy5oaXN0b3J5LnJlcGxhY2VTdGF0ZShcbiAgICAgICAgd2luZG93Lmhpc3Rvcnkuc3RhdGUsXG4gICAgICAgIHdpbmRvdy5kb2N1bWVudC50aXRsZSxcbiAgICAgICAgd2luZG93LmxvY2F0aW9uLnBhdGhuYW1lICsgY29uc3RydWN0UXVlcnkocGFyYW1zKVxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKHNob3VsZFdyaXRlSGlzdG9yeSkge1xuICAgICAgICB3aW5kb3cuaGlzdG9yeS5wdXNoU3RhdGUoXG4gICAgICAgICAgd2luZG93Lmhpc3Rvcnkuc3RhdGUsXG4gICAgICAgICAgd2luZG93LmRvY3VtZW50LnRpdGxlLFxuICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5wYXRobmFtZSArIGNvbnN0cnVjdFF1ZXJ5KHBhcmFtcylcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gICAgbmV4dFRpY2soKCkgPT4gcmVzdW1lKCkpO1xuICB9XG4gIGZ1bmN0aW9uIG9uQ2hhbmdlZCgpIHtcbiAgICBpZiAoIWVuYWJsZVdyaXRlKVxuICAgICAgcmV0dXJuO1xuICAgIHdyaXRlKHJlYWQoKSwgdHJ1ZSwgZmFsc2UpO1xuICB9XG4gIGNvbnN0IGxpc3RlbmVyT3B0aW9ucyA9IHsgcGFzc2l2ZTogdHJ1ZSB9O1xuICB1c2VFdmVudExpc3RlbmVyKHdpbmRvdywgXCJwb3BzdGF0ZVwiLCBvbkNoYW5nZWQsIGxpc3RlbmVyT3B0aW9ucyk7XG4gIGlmIChtb2RlICE9PSBcImhpc3RvcnlcIilcbiAgICB1c2VFdmVudExpc3RlbmVyKHdpbmRvdywgXCJoYXNoY2hhbmdlXCIsIG9uQ2hhbmdlZCwgbGlzdGVuZXJPcHRpb25zKTtcbiAgY29uc3QgaW5pdGlhbCA9IHJlYWQoKTtcbiAgaWYgKGluaXRpYWwua2V5cygpLm5leHQoKS52YWx1ZSlcbiAgICB1cGRhdGVTdGF0ZShpbml0aWFsKTtcbiAgZWxzZVxuICAgIE9iamVjdC5hc3NpZ24oc3RhdGUsIGluaXRpYWxWYWx1ZSk7XG4gIHJldHVybiBzdGF0ZTtcbn1cblxuZnVuY3Rpb24gdXNlVXNlck1lZGlhKG9wdGlvbnMgPSB7fSkge1xuICB2YXIgX2EsIF9iO1xuICBjb25zdCBlbmFibGVkID0gc2hhbGxvd1JlZigoX2EgPSBvcHRpb25zLmVuYWJsZWQpICE9IG51bGwgPyBfYSA6IGZhbHNlKTtcbiAgY29uc3QgYXV0b1N3aXRjaCA9IHNoYWxsb3dSZWYoKF9iID0gb3B0aW9ucy5hdXRvU3dpdGNoKSAhPSBudWxsID8gX2IgOiB0cnVlKTtcbiAgY29uc3QgY29uc3RyYWludHMgPSByZWYob3B0aW9ucy5jb25zdHJhaW50cyk7XG4gIGNvbnN0IHsgbmF2aWdhdG9yID0gZGVmYXVsdE5hdmlnYXRvciB9ID0gb3B0aW9ucztcbiAgY29uc3QgaXNTdXBwb3J0ZWQgPSB1c2VTdXBwb3J0ZWQoKCkgPT4ge1xuICAgIHZhciBfYTI7XG4gICAgcmV0dXJuIChfYTIgPSBuYXZpZ2F0b3IgPT0gbnVsbCA/IHZvaWQgMCA6IG5hdmlnYXRvci5tZWRpYURldmljZXMpID09IG51bGwgPyB2b2lkIDAgOiBfYTIuZ2V0VXNlck1lZGlhO1xuICB9KTtcbiAgY29uc3Qgc3RyZWFtID0gc2hhbGxvd1JlZigpO1xuICBmdW5jdGlvbiBnZXREZXZpY2VPcHRpb25zKHR5cGUpIHtcbiAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgIGNhc2UgXCJ2aWRlb1wiOiB7XG4gICAgICAgIGlmIChjb25zdHJhaW50cy52YWx1ZSlcbiAgICAgICAgICByZXR1cm4gY29uc3RyYWludHMudmFsdWUudmlkZW8gfHwgZmFsc2U7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSBcImF1ZGlvXCI6IHtcbiAgICAgICAgaWYgKGNvbnN0cmFpbnRzLnZhbHVlKVxuICAgICAgICAgIHJldHVybiBjb25zdHJhaW50cy52YWx1ZS5hdWRpbyB8fCBmYWxzZTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGFzeW5jIGZ1bmN0aW9uIF9zdGFydCgpIHtcbiAgICBpZiAoIWlzU3VwcG9ydGVkLnZhbHVlIHx8IHN0cmVhbS52YWx1ZSlcbiAgICAgIHJldHVybjtcbiAgICBzdHJlYW0udmFsdWUgPSBhd2FpdCBuYXZpZ2F0b3IubWVkaWFEZXZpY2VzLmdldFVzZXJNZWRpYSh7XG4gICAgICB2aWRlbzogZ2V0RGV2aWNlT3B0aW9ucyhcInZpZGVvXCIpLFxuICAgICAgYXVkaW86IGdldERldmljZU9wdGlvbnMoXCJhdWRpb1wiKVxuICAgIH0pO1xuICAgIHJldHVybiBzdHJlYW0udmFsdWU7XG4gIH1cbiAgZnVuY3Rpb24gX3N0b3AoKSB7XG4gICAgdmFyIF9hMjtcbiAgICAoX2EyID0gc3RyZWFtLnZhbHVlKSA9PSBudWxsID8gdm9pZCAwIDogX2EyLmdldFRyYWNrcygpLmZvckVhY2goKHQpID0+IHQuc3RvcCgpKTtcbiAgICBzdHJlYW0udmFsdWUgPSB2b2lkIDA7XG4gIH1cbiAgZnVuY3Rpb24gc3RvcCgpIHtcbiAgICBfc3RvcCgpO1xuICAgIGVuYWJsZWQudmFsdWUgPSBmYWxzZTtcbiAgfVxuICBhc3luYyBmdW5jdGlvbiBzdGFydCgpIHtcbiAgICBhd2FpdCBfc3RhcnQoKTtcbiAgICBpZiAoc3RyZWFtLnZhbHVlKVxuICAgICAgZW5hYmxlZC52YWx1ZSA9IHRydWU7XG4gICAgcmV0dXJuIHN0cmVhbS52YWx1ZTtcbiAgfVxuICBhc3luYyBmdW5jdGlvbiByZXN0YXJ0KCkge1xuICAgIF9zdG9wKCk7XG4gICAgcmV0dXJuIGF3YWl0IHN0YXJ0KCk7XG4gIH1cbiAgd2F0Y2goXG4gICAgZW5hYmxlZCxcbiAgICAodikgPT4ge1xuICAgICAgaWYgKHYpXG4gICAgICAgIF9zdGFydCgpO1xuICAgICAgZWxzZSBfc3RvcCgpO1xuICAgIH0sXG4gICAgeyBpbW1lZGlhdGU6IHRydWUgfVxuICApO1xuICB3YXRjaChcbiAgICBjb25zdHJhaW50cyxcbiAgICAoKSA9PiB7XG4gICAgICBpZiAoYXV0b1N3aXRjaC52YWx1ZSAmJiBzdHJlYW0udmFsdWUpXG4gICAgICAgIHJlc3RhcnQoKTtcbiAgICB9LFxuICAgIHsgaW1tZWRpYXRlOiB0cnVlIH1cbiAgKTtcbiAgdHJ5T25TY29wZURpc3Bvc2UoKCkgPT4ge1xuICAgIHN0b3AoKTtcbiAgfSk7XG4gIHJldHVybiB7XG4gICAgaXNTdXBwb3J0ZWQsXG4gICAgc3RyZWFtLFxuICAgIHN0YXJ0LFxuICAgIHN0b3AsXG4gICAgcmVzdGFydCxcbiAgICBjb25zdHJhaW50cyxcbiAgICBlbmFibGVkLFxuICAgIGF1dG9Td2l0Y2hcbiAgfTtcbn1cblxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHVzZVZNb2RlbChwcm9wcywga2V5LCBlbWl0LCBvcHRpb25zID0ge30pIHtcbiAgdmFyIF9hLCBfYiwgX2M7XG4gIGNvbnN0IHtcbiAgICBjbG9uZSA9IGZhbHNlLFxuICAgIHBhc3NpdmUgPSBmYWxzZSxcbiAgICBldmVudE5hbWUsXG4gICAgZGVlcCA9IGZhbHNlLFxuICAgIGRlZmF1bHRWYWx1ZSxcbiAgICBzaG91bGRFbWl0XG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCB2bSA9IGdldEN1cnJlbnRJbnN0YW5jZSgpO1xuICBjb25zdCBfZW1pdCA9IGVtaXQgfHwgKHZtID09IG51bGwgPyB2b2lkIDAgOiB2bS5lbWl0KSB8fCAoKF9hID0gdm0gPT0gbnVsbCA/IHZvaWQgMCA6IHZtLiRlbWl0KSA9PSBudWxsID8gdm9pZCAwIDogX2EuYmluZCh2bSkpIHx8ICgoX2MgPSAoX2IgPSB2bSA9PSBudWxsID8gdm9pZCAwIDogdm0ucHJveHkpID09IG51bGwgPyB2b2lkIDAgOiBfYi4kZW1pdCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9jLmJpbmQodm0gPT0gbnVsbCA/IHZvaWQgMCA6IHZtLnByb3h5KSk7XG4gIGxldCBldmVudCA9IGV2ZW50TmFtZTtcbiAgaWYgKCFrZXkpIHtcbiAgICBrZXkgPSBcIm1vZGVsVmFsdWVcIjtcbiAgfVxuICBldmVudCA9IGV2ZW50IHx8IGB1cGRhdGU6JHtrZXkudG9TdHJpbmcoKX1gO1xuICBjb25zdCBjbG9uZUZuID0gKHZhbCkgPT4gIWNsb25lID8gdmFsIDogdHlwZW9mIGNsb25lID09PSBcImZ1bmN0aW9uXCIgPyBjbG9uZSh2YWwpIDogY2xvbmVGbkpTT04odmFsKTtcbiAgY29uc3QgZ2V0VmFsdWUgPSAoKSA9PiBpc0RlZihwcm9wc1trZXldKSA/IGNsb25lRm4ocHJvcHNba2V5XSkgOiBkZWZhdWx0VmFsdWU7XG4gIGNvbnN0IHRyaWdnZXJFbWl0ID0gKHZhbHVlKSA9PiB7XG4gICAgaWYgKHNob3VsZEVtaXQpIHtcbiAgICAgIGlmIChzaG91bGRFbWl0KHZhbHVlKSlcbiAgICAgICAgX2VtaXQoZXZlbnQsIHZhbHVlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgX2VtaXQoZXZlbnQsIHZhbHVlKTtcbiAgICB9XG4gIH07XG4gIGlmIChwYXNzaXZlKSB7XG4gICAgY29uc3QgaW5pdGlhbFZhbHVlID0gZ2V0VmFsdWUoKTtcbiAgICBjb25zdCBwcm94eSA9IHJlZihpbml0aWFsVmFsdWUpO1xuICAgIGxldCBpc1VwZGF0aW5nID0gZmFsc2U7XG4gICAgd2F0Y2goXG4gICAgICAoKSA9PiBwcm9wc1trZXldLFxuICAgICAgKHYpID0+IHtcbiAgICAgICAgaWYgKCFpc1VwZGF0aW5nKSB7XG4gICAgICAgICAgaXNVcGRhdGluZyA9IHRydWU7XG4gICAgICAgICAgcHJveHkudmFsdWUgPSBjbG9uZUZuKHYpO1xuICAgICAgICAgIG5leHRUaWNrKCgpID0+IGlzVXBkYXRpbmcgPSBmYWxzZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICApO1xuICAgIHdhdGNoKFxuICAgICAgcHJveHksXG4gICAgICAodikgPT4ge1xuICAgICAgICBpZiAoIWlzVXBkYXRpbmcgJiYgKHYgIT09IHByb3BzW2tleV0gfHwgZGVlcCkpXG4gICAgICAgICAgdHJpZ2dlckVtaXQodik7XG4gICAgICB9LFxuICAgICAgeyBkZWVwIH1cbiAgICApO1xuICAgIHJldHVybiBwcm94eTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gY29tcHV0ZWQoe1xuICAgICAgZ2V0KCkge1xuICAgICAgICByZXR1cm4gZ2V0VmFsdWUoKTtcbiAgICAgIH0sXG4gICAgICBzZXQodmFsdWUpIHtcbiAgICAgICAgdHJpZ2dlckVtaXQodmFsdWUpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VWTW9kZWxzKHByb3BzLCBlbWl0LCBvcHRpb25zID0ge30pIHtcbiAgY29uc3QgcmV0ID0ge307XG4gIGZvciAoY29uc3Qga2V5IGluIHByb3BzKSB7XG4gICAgcmV0W2tleV0gPSB1c2VWTW9kZWwoXG4gICAgICBwcm9wcyxcbiAgICAgIGtleSxcbiAgICAgIGVtaXQsXG4gICAgICBvcHRpb25zXG4gICAgKTtcbiAgfVxuICByZXR1cm4gcmV0O1xufVxuXG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gdXNlVmlicmF0ZShvcHRpb25zKSB7XG4gIGNvbnN0IHtcbiAgICBwYXR0ZXJuID0gW10sXG4gICAgaW50ZXJ2YWwgPSAwLFxuICAgIG5hdmlnYXRvciA9IGRlZmF1bHROYXZpZ2F0b3JcbiAgfSA9IG9wdGlvbnMgfHwge307XG4gIGNvbnN0IGlzU3VwcG9ydGVkID0gdXNlU3VwcG9ydGVkKCgpID0+IHR5cGVvZiBuYXZpZ2F0b3IgIT09IFwidW5kZWZpbmVkXCIgJiYgXCJ2aWJyYXRlXCIgaW4gbmF2aWdhdG9yKTtcbiAgY29uc3QgcGF0dGVyblJlZiA9IHRvUmVmKHBhdHRlcm4pO1xuICBsZXQgaW50ZXJ2YWxDb250cm9scztcbiAgY29uc3QgdmlicmF0ZSA9IChwYXR0ZXJuMiA9IHBhdHRlcm5SZWYudmFsdWUpID0+IHtcbiAgICBpZiAoaXNTdXBwb3J0ZWQudmFsdWUpXG4gICAgICBuYXZpZ2F0b3IudmlicmF0ZShwYXR0ZXJuMik7XG4gIH07XG4gIGNvbnN0IHN0b3AgPSAoKSA9PiB7XG4gICAgaWYgKGlzU3VwcG9ydGVkLnZhbHVlKVxuICAgICAgbmF2aWdhdG9yLnZpYnJhdGUoMCk7XG4gICAgaW50ZXJ2YWxDb250cm9scyA9PSBudWxsID8gdm9pZCAwIDogaW50ZXJ2YWxDb250cm9scy5wYXVzZSgpO1xuICB9O1xuICBpZiAoaW50ZXJ2YWwgPiAwKSB7XG4gICAgaW50ZXJ2YWxDb250cm9scyA9IHVzZUludGVydmFsRm4oXG4gICAgICB2aWJyYXRlLFxuICAgICAgaW50ZXJ2YWwsXG4gICAgICB7XG4gICAgICAgIGltbWVkaWF0ZTogZmFsc2UsXG4gICAgICAgIGltbWVkaWF0ZUNhbGxiYWNrOiBmYWxzZVxuICAgICAgfVxuICAgICk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBpc1N1cHBvcnRlZCxcbiAgICBwYXR0ZXJuLFxuICAgIGludGVydmFsQ29udHJvbHMsXG4gICAgdmlicmF0ZSxcbiAgICBzdG9wXG4gIH07XG59XG5cbmZ1bmN0aW9uIHVzZVZpcnR1YWxMaXN0KGxpc3QsIG9wdGlvbnMpIHtcbiAgY29uc3QgeyBjb250YWluZXJTdHlsZSwgd3JhcHBlclByb3BzLCBzY3JvbGxUbywgY2FsY3VsYXRlUmFuZ2UsIGN1cnJlbnRMaXN0LCBjb250YWluZXJSZWYgfSA9IFwiaXRlbUhlaWdodFwiIGluIG9wdGlvbnMgPyB1c2VWZXJ0aWNhbFZpcnR1YWxMaXN0KG9wdGlvbnMsIGxpc3QpIDogdXNlSG9yaXpvbnRhbFZpcnR1YWxMaXN0KG9wdGlvbnMsIGxpc3QpO1xuICByZXR1cm4ge1xuICAgIGxpc3Q6IGN1cnJlbnRMaXN0LFxuICAgIHNjcm9sbFRvLFxuICAgIGNvbnRhaW5lclByb3BzOiB7XG4gICAgICByZWY6IGNvbnRhaW5lclJlZixcbiAgICAgIG9uU2Nyb2xsOiAoKSA9PiB7XG4gICAgICAgIGNhbGN1bGF0ZVJhbmdlKCk7XG4gICAgICB9LFxuICAgICAgc3R5bGU6IGNvbnRhaW5lclN0eWxlXG4gICAgfSxcbiAgICB3cmFwcGVyUHJvcHNcbiAgfTtcbn1cbmZ1bmN0aW9uIHVzZVZpcnR1YWxMaXN0UmVzb3VyY2VzKGxpc3QpIHtcbiAgY29uc3QgY29udGFpbmVyUmVmID0gc2hhbGxvd1JlZihudWxsKTtcbiAgY29uc3Qgc2l6ZSA9IHVzZUVsZW1lbnRTaXplKGNvbnRhaW5lclJlZik7XG4gIGNvbnN0IGN1cnJlbnRMaXN0ID0gcmVmKFtdKTtcbiAgY29uc3Qgc291cmNlID0gc2hhbGxvd1JlZihsaXN0KTtcbiAgY29uc3Qgc3RhdGUgPSByZWYoeyBzdGFydDogMCwgZW5kOiAxMCB9KTtcbiAgcmV0dXJuIHsgc3RhdGUsIHNvdXJjZSwgY3VycmVudExpc3QsIHNpemUsIGNvbnRhaW5lclJlZiB9O1xufVxuZnVuY3Rpb24gY3JlYXRlR2V0Vmlld0NhcGFjaXR5KHN0YXRlLCBzb3VyY2UsIGl0ZW1TaXplKSB7XG4gIHJldHVybiAoY29udGFpbmVyU2l6ZSkgPT4ge1xuICAgIGlmICh0eXBlb2YgaXRlbVNpemUgPT09IFwibnVtYmVyXCIpXG4gICAgICByZXR1cm4gTWF0aC5jZWlsKGNvbnRhaW5lclNpemUgLyBpdGVtU2l6ZSk7XG4gICAgY29uc3QgeyBzdGFydCA9IDAgfSA9IHN0YXRlLnZhbHVlO1xuICAgIGxldCBzdW0gPSAwO1xuICAgIGxldCBjYXBhY2l0eSA9IDA7XG4gICAgZm9yIChsZXQgaSA9IHN0YXJ0OyBpIDwgc291cmNlLnZhbHVlLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBzaXplID0gaXRlbVNpemUoaSk7XG4gICAgICBzdW0gKz0gc2l6ZTtcbiAgICAgIGNhcGFjaXR5ID0gaTtcbiAgICAgIGlmIChzdW0gPiBjb250YWluZXJTaXplKVxuICAgICAgICBicmVhaztcbiAgICB9XG4gICAgcmV0dXJuIGNhcGFjaXR5IC0gc3RhcnQ7XG4gIH07XG59XG5mdW5jdGlvbiBjcmVhdGVHZXRPZmZzZXQoc291cmNlLCBpdGVtU2l6ZSkge1xuICByZXR1cm4gKHNjcm9sbERpcmVjdGlvbikgPT4ge1xuICAgIGlmICh0eXBlb2YgaXRlbVNpemUgPT09IFwibnVtYmVyXCIpXG4gICAgICByZXR1cm4gTWF0aC5mbG9vcihzY3JvbGxEaXJlY3Rpb24gLyBpdGVtU2l6ZSkgKyAxO1xuICAgIGxldCBzdW0gPSAwO1xuICAgIGxldCBvZmZzZXQgPSAwO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc291cmNlLnZhbHVlLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBzaXplID0gaXRlbVNpemUoaSk7XG4gICAgICBzdW0gKz0gc2l6ZTtcbiAgICAgIGlmIChzdW0gPj0gc2Nyb2xsRGlyZWN0aW9uKSB7XG4gICAgICAgIG9mZnNldCA9IGk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gb2Zmc2V0ICsgMTtcbiAgfTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUNhbGN1bGF0ZVJhbmdlKHR5cGUsIG92ZXJzY2FuLCBnZXRPZmZzZXQsIGdldFZpZXdDYXBhY2l0eSwgeyBjb250YWluZXJSZWYsIHN0YXRlLCBjdXJyZW50TGlzdCwgc291cmNlIH0pIHtcbiAgcmV0dXJuICgpID0+IHtcbiAgICBjb25zdCBlbGVtZW50ID0gY29udGFpbmVyUmVmLnZhbHVlO1xuICAgIGlmIChlbGVtZW50KSB7XG4gICAgICBjb25zdCBvZmZzZXQgPSBnZXRPZmZzZXQodHlwZSA9PT0gXCJ2ZXJ0aWNhbFwiID8gZWxlbWVudC5zY3JvbGxUb3AgOiBlbGVtZW50LnNjcm9sbExlZnQpO1xuICAgICAgY29uc3Qgdmlld0NhcGFjaXR5ID0gZ2V0Vmlld0NhcGFjaXR5KHR5cGUgPT09IFwidmVydGljYWxcIiA/IGVsZW1lbnQuY2xpZW50SGVpZ2h0IDogZWxlbWVudC5jbGllbnRXaWR0aCk7XG4gICAgICBjb25zdCBmcm9tID0gb2Zmc2V0IC0gb3ZlcnNjYW47XG4gICAgICBjb25zdCB0byA9IG9mZnNldCArIHZpZXdDYXBhY2l0eSArIG92ZXJzY2FuO1xuICAgICAgc3RhdGUudmFsdWUgPSB7XG4gICAgICAgIHN0YXJ0OiBmcm9tIDwgMCA/IDAgOiBmcm9tLFxuICAgICAgICBlbmQ6IHRvID4gc291cmNlLnZhbHVlLmxlbmd0aCA/IHNvdXJjZS52YWx1ZS5sZW5ndGggOiB0b1xuICAgICAgfTtcbiAgICAgIGN1cnJlbnRMaXN0LnZhbHVlID0gc291cmNlLnZhbHVlLnNsaWNlKHN0YXRlLnZhbHVlLnN0YXJ0LCBzdGF0ZS52YWx1ZS5lbmQpLm1hcCgoZWxlLCBpbmRleCkgPT4gKHtcbiAgICAgICAgZGF0YTogZWxlLFxuICAgICAgICBpbmRleDogaW5kZXggKyBzdGF0ZS52YWx1ZS5zdGFydFxuICAgICAgfSkpO1xuICAgIH1cbiAgfTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUdldERpc3RhbmNlKGl0ZW1TaXplLCBzb3VyY2UpIHtcbiAgcmV0dXJuIChpbmRleCkgPT4ge1xuICAgIGlmICh0eXBlb2YgaXRlbVNpemUgPT09IFwibnVtYmVyXCIpIHtcbiAgICAgIGNvbnN0IHNpemUyID0gaW5kZXggKiBpdGVtU2l6ZTtcbiAgICAgIHJldHVybiBzaXplMjtcbiAgICB9XG4gICAgY29uc3Qgc2l6ZSA9IHNvdXJjZS52YWx1ZS5zbGljZSgwLCBpbmRleCkucmVkdWNlKChzdW0sIF8sIGkpID0+IHN1bSArIGl0ZW1TaXplKGkpLCAwKTtcbiAgICByZXR1cm4gc2l6ZTtcbiAgfTtcbn1cbmZ1bmN0aW9uIHVzZVdhdGNoRm9yU2l6ZXMoc2l6ZSwgbGlzdCwgY29udGFpbmVyUmVmLCBjYWxjdWxhdGVSYW5nZSkge1xuICB3YXRjaChbc2l6ZS53aWR0aCwgc2l6ZS5oZWlnaHQsICgpID0+IHRvVmFsdWUobGlzdCksIGNvbnRhaW5lclJlZl0sICgpID0+IHtcbiAgICBjYWxjdWxhdGVSYW5nZSgpO1xuICB9KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUNvbXB1dGVkVG90YWxTaXplKGl0ZW1TaXplLCBzb3VyY2UpIHtcbiAgcmV0dXJuIGNvbXB1dGVkKCgpID0+IHtcbiAgICBpZiAodHlwZW9mIGl0ZW1TaXplID09PSBcIm51bWJlclwiKVxuICAgICAgcmV0dXJuIHNvdXJjZS52YWx1ZS5sZW5ndGggKiBpdGVtU2l6ZTtcbiAgICByZXR1cm4gc291cmNlLnZhbHVlLnJlZHVjZSgoc3VtLCBfLCBpbmRleCkgPT4gc3VtICsgaXRlbVNpemUoaW5kZXgpLCAwKTtcbiAgfSk7XG59XG5jb25zdCBzY3JvbGxUb0RpY3Rpb25hcnlGb3JFbGVtZW50U2Nyb2xsS2V5ID0ge1xuICBob3Jpem9udGFsOiBcInNjcm9sbExlZnRcIixcbiAgdmVydGljYWw6IFwic2Nyb2xsVG9wXCJcbn07XG5mdW5jdGlvbiBjcmVhdGVTY3JvbGxUbyh0eXBlLCBjYWxjdWxhdGVSYW5nZSwgZ2V0RGlzdGFuY2UsIGNvbnRhaW5lclJlZikge1xuICByZXR1cm4gKGluZGV4KSA9PiB7XG4gICAgaWYgKGNvbnRhaW5lclJlZi52YWx1ZSkge1xuICAgICAgY29udGFpbmVyUmVmLnZhbHVlW3Njcm9sbFRvRGljdGlvbmFyeUZvckVsZW1lbnRTY3JvbGxLZXlbdHlwZV1dID0gZ2V0RGlzdGFuY2UoaW5kZXgpO1xuICAgICAgY2FsY3VsYXRlUmFuZ2UoKTtcbiAgICB9XG4gIH07XG59XG5mdW5jdGlvbiB1c2VIb3Jpem9udGFsVmlydHVhbExpc3Qob3B0aW9ucywgbGlzdCkge1xuICBjb25zdCByZXNvdXJjZXMgPSB1c2VWaXJ0dWFsTGlzdFJlc291cmNlcyhsaXN0KTtcbiAgY29uc3QgeyBzdGF0ZSwgc291cmNlLCBjdXJyZW50TGlzdCwgc2l6ZSwgY29udGFpbmVyUmVmIH0gPSByZXNvdXJjZXM7XG4gIGNvbnN0IGNvbnRhaW5lclN0eWxlID0geyBvdmVyZmxvd1g6IFwiYXV0b1wiIH07XG4gIGNvbnN0IHsgaXRlbVdpZHRoLCBvdmVyc2NhbiA9IDUgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGdldFZpZXdDYXBhY2l0eSA9IGNyZWF0ZUdldFZpZXdDYXBhY2l0eShzdGF0ZSwgc291cmNlLCBpdGVtV2lkdGgpO1xuICBjb25zdCBnZXRPZmZzZXQgPSBjcmVhdGVHZXRPZmZzZXQoc291cmNlLCBpdGVtV2lkdGgpO1xuICBjb25zdCBjYWxjdWxhdGVSYW5nZSA9IGNyZWF0ZUNhbGN1bGF0ZVJhbmdlKFwiaG9yaXpvbnRhbFwiLCBvdmVyc2NhbiwgZ2V0T2Zmc2V0LCBnZXRWaWV3Q2FwYWNpdHksIHJlc291cmNlcyk7XG4gIGNvbnN0IGdldERpc3RhbmNlTGVmdCA9IGNyZWF0ZUdldERpc3RhbmNlKGl0ZW1XaWR0aCwgc291cmNlKTtcbiAgY29uc3Qgb2Zmc2V0TGVmdCA9IGNvbXB1dGVkKCgpID0+IGdldERpc3RhbmNlTGVmdChzdGF0ZS52YWx1ZS5zdGFydCkpO1xuICBjb25zdCB0b3RhbFdpZHRoID0gY3JlYXRlQ29tcHV0ZWRUb3RhbFNpemUoaXRlbVdpZHRoLCBzb3VyY2UpO1xuICB1c2VXYXRjaEZvclNpemVzKHNpemUsIGxpc3QsIGNvbnRhaW5lclJlZiwgY2FsY3VsYXRlUmFuZ2UpO1xuICBjb25zdCBzY3JvbGxUbyA9IGNyZWF0ZVNjcm9sbFRvKFwiaG9yaXpvbnRhbFwiLCBjYWxjdWxhdGVSYW5nZSwgZ2V0RGlzdGFuY2VMZWZ0LCBjb250YWluZXJSZWYpO1xuICBjb25zdCB3cmFwcGVyUHJvcHMgPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHN0eWxlOiB7XG4gICAgICAgIGhlaWdodDogXCIxMDAlXCIsXG4gICAgICAgIHdpZHRoOiBgJHt0b3RhbFdpZHRoLnZhbHVlIC0gb2Zmc2V0TGVmdC52YWx1ZX1weGAsXG4gICAgICAgIG1hcmdpbkxlZnQ6IGAke29mZnNldExlZnQudmFsdWV9cHhgLFxuICAgICAgICBkaXNwbGF5OiBcImZsZXhcIlxuICAgICAgfVxuICAgIH07XG4gIH0pO1xuICByZXR1cm4ge1xuICAgIHNjcm9sbFRvLFxuICAgIGNhbGN1bGF0ZVJhbmdlLFxuICAgIHdyYXBwZXJQcm9wcyxcbiAgICBjb250YWluZXJTdHlsZSxcbiAgICBjdXJyZW50TGlzdCxcbiAgICBjb250YWluZXJSZWZcbiAgfTtcbn1cbmZ1bmN0aW9uIHVzZVZlcnRpY2FsVmlydHVhbExpc3Qob3B0aW9ucywgbGlzdCkge1xuICBjb25zdCByZXNvdXJjZXMgPSB1c2VWaXJ0dWFsTGlzdFJlc291cmNlcyhsaXN0KTtcbiAgY29uc3QgeyBzdGF0ZSwgc291cmNlLCBjdXJyZW50TGlzdCwgc2l6ZSwgY29udGFpbmVyUmVmIH0gPSByZXNvdXJjZXM7XG4gIGNvbnN0IGNvbnRhaW5lclN0eWxlID0geyBvdmVyZmxvd1k6IFwiYXV0b1wiIH07XG4gIGNvbnN0IHsgaXRlbUhlaWdodCwgb3ZlcnNjYW4gPSA1IH0gPSBvcHRpb25zO1xuICBjb25zdCBnZXRWaWV3Q2FwYWNpdHkgPSBjcmVhdGVHZXRWaWV3Q2FwYWNpdHkoc3RhdGUsIHNvdXJjZSwgaXRlbUhlaWdodCk7XG4gIGNvbnN0IGdldE9mZnNldCA9IGNyZWF0ZUdldE9mZnNldChzb3VyY2UsIGl0ZW1IZWlnaHQpO1xuICBjb25zdCBjYWxjdWxhdGVSYW5nZSA9IGNyZWF0ZUNhbGN1bGF0ZVJhbmdlKFwidmVydGljYWxcIiwgb3ZlcnNjYW4sIGdldE9mZnNldCwgZ2V0Vmlld0NhcGFjaXR5LCByZXNvdXJjZXMpO1xuICBjb25zdCBnZXREaXN0YW5jZVRvcCA9IGNyZWF0ZUdldERpc3RhbmNlKGl0ZW1IZWlnaHQsIHNvdXJjZSk7XG4gIGNvbnN0IG9mZnNldFRvcCA9IGNvbXB1dGVkKCgpID0+IGdldERpc3RhbmNlVG9wKHN0YXRlLnZhbHVlLnN0YXJ0KSk7XG4gIGNvbnN0IHRvdGFsSGVpZ2h0ID0gY3JlYXRlQ29tcHV0ZWRUb3RhbFNpemUoaXRlbUhlaWdodCwgc291cmNlKTtcbiAgdXNlV2F0Y2hGb3JTaXplcyhzaXplLCBsaXN0LCBjb250YWluZXJSZWYsIGNhbGN1bGF0ZVJhbmdlKTtcbiAgY29uc3Qgc2Nyb2xsVG8gPSBjcmVhdGVTY3JvbGxUbyhcInZlcnRpY2FsXCIsIGNhbGN1bGF0ZVJhbmdlLCBnZXREaXN0YW5jZVRvcCwgY29udGFpbmVyUmVmKTtcbiAgY29uc3Qgd3JhcHBlclByb3BzID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIHJldHVybiB7XG4gICAgICBzdHlsZToge1xuICAgICAgICB3aWR0aDogXCIxMDAlXCIsXG4gICAgICAgIGhlaWdodDogYCR7dG90YWxIZWlnaHQudmFsdWUgLSBvZmZzZXRUb3AudmFsdWV9cHhgLFxuICAgICAgICBtYXJnaW5Ub3A6IGAke29mZnNldFRvcC52YWx1ZX1weGBcbiAgICAgIH1cbiAgICB9O1xuICB9KTtcbiAgcmV0dXJuIHtcbiAgICBjYWxjdWxhdGVSYW5nZSxcbiAgICBzY3JvbGxUbyxcbiAgICBjb250YWluZXJTdHlsZSxcbiAgICB3cmFwcGVyUHJvcHMsXG4gICAgY3VycmVudExpc3QsXG4gICAgY29udGFpbmVyUmVmXG4gIH07XG59XG5cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiB1c2VXYWtlTG9jayhvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIG5hdmlnYXRvciA9IGRlZmF1bHROYXZpZ2F0b3IsXG4gICAgZG9jdW1lbnQgPSBkZWZhdWx0RG9jdW1lbnRcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IHJlcXVlc3RlZFR5cGUgPSBzaGFsbG93UmVmKGZhbHNlKTtcbiAgY29uc3Qgc2VudGluZWwgPSBzaGFsbG93UmVmKG51bGwpO1xuICBjb25zdCBkb2N1bWVudFZpc2liaWxpdHkgPSB1c2VEb2N1bWVudFZpc2liaWxpdHkoeyBkb2N1bWVudCB9KTtcbiAgY29uc3QgaXNTdXBwb3J0ZWQgPSB1c2VTdXBwb3J0ZWQoKCkgPT4gbmF2aWdhdG9yICYmIFwid2FrZUxvY2tcIiBpbiBuYXZpZ2F0b3IpO1xuICBjb25zdCBpc0FjdGl2ZSA9IGNvbXB1dGVkKCgpID0+ICEhc2VudGluZWwudmFsdWUgJiYgZG9jdW1lbnRWaXNpYmlsaXR5LnZhbHVlID09PSBcInZpc2libGVcIik7XG4gIGlmIChpc1N1cHBvcnRlZC52YWx1ZSkge1xuICAgIHVzZUV2ZW50TGlzdGVuZXIoc2VudGluZWwsIFwicmVsZWFzZVwiLCAoKSA9PiB7XG4gICAgICB2YXIgX2EsIF9iO1xuICAgICAgcmVxdWVzdGVkVHlwZS52YWx1ZSA9IChfYiA9IChfYSA9IHNlbnRpbmVsLnZhbHVlKSA9PSBudWxsID8gdm9pZCAwIDogX2EudHlwZSkgIT0gbnVsbCA/IF9iIDogZmFsc2U7XG4gICAgfSwgeyBwYXNzaXZlOiB0cnVlIH0pO1xuICAgIHdoZW5ldmVyKFxuICAgICAgKCkgPT4gZG9jdW1lbnRWaXNpYmlsaXR5LnZhbHVlID09PSBcInZpc2libGVcIiAmJiAoZG9jdW1lbnQgPT0gbnVsbCA/IHZvaWQgMCA6IGRvY3VtZW50LnZpc2liaWxpdHlTdGF0ZSkgPT09IFwidmlzaWJsZVwiICYmIHJlcXVlc3RlZFR5cGUudmFsdWUsXG4gICAgICAodHlwZSkgPT4ge1xuICAgICAgICByZXF1ZXN0ZWRUeXBlLnZhbHVlID0gZmFsc2U7XG4gICAgICAgIGZvcmNlUmVxdWVzdCh0eXBlKTtcbiAgICAgIH1cbiAgICApO1xuICB9XG4gIGFzeW5jIGZ1bmN0aW9uIGZvcmNlUmVxdWVzdCh0eXBlKSB7XG4gICAgdmFyIF9hO1xuICAgIGF3YWl0ICgoX2EgPSBzZW50aW5lbC52YWx1ZSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9hLnJlbGVhc2UoKSk7XG4gICAgc2VudGluZWwudmFsdWUgPSBpc1N1cHBvcnRlZC52YWx1ZSA/IGF3YWl0IG5hdmlnYXRvci53YWtlTG9jay5yZXF1ZXN0KHR5cGUpIDogbnVsbDtcbiAgfVxuICBhc3luYyBmdW5jdGlvbiByZXF1ZXN0KHR5cGUpIHtcbiAgICBpZiAoZG9jdW1lbnRWaXNpYmlsaXR5LnZhbHVlID09PSBcInZpc2libGVcIilcbiAgICAgIGF3YWl0IGZvcmNlUmVxdWVzdCh0eXBlKTtcbiAgICBlbHNlXG4gICAgICByZXF1ZXN0ZWRUeXBlLnZhbHVlID0gdHlwZTtcbiAgfVxuICBhc3luYyBmdW5jdGlvbiByZWxlYXNlKCkge1xuICAgIHJlcXVlc3RlZFR5cGUudmFsdWUgPSBmYWxzZTtcbiAgICBjb25zdCBzID0gc2VudGluZWwudmFsdWU7XG4gICAgc2VudGluZWwudmFsdWUgPSBudWxsO1xuICAgIGF3YWl0IChzID09IG51bGwgPyB2b2lkIDAgOiBzLnJlbGVhc2UoKSk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBzZW50aW5lbCxcbiAgICBpc1N1cHBvcnRlZCxcbiAgICBpc0FjdGl2ZSxcbiAgICByZXF1ZXN0LFxuICAgIGZvcmNlUmVxdWVzdCxcbiAgICByZWxlYXNlXG4gIH07XG59XG5cbmZ1bmN0aW9uIHVzZVdlYk5vdGlmaWNhdGlvbihvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIHdpbmRvdyA9IGRlZmF1bHRXaW5kb3csXG4gICAgcmVxdWVzdFBlcm1pc3Npb25zOiBfcmVxdWVzdEZvclBlcm1pc3Npb25zID0gdHJ1ZVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgZGVmYXVsdFdlYk5vdGlmaWNhdGlvbk9wdGlvbnMgPSBvcHRpb25zO1xuICBjb25zdCBpc1N1cHBvcnRlZCA9IHVzZVN1cHBvcnRlZCgoKSA9PiB7XG4gICAgaWYgKCF3aW5kb3cgfHwgIShcIk5vdGlmaWNhdGlvblwiIGluIHdpbmRvdykpXG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgaWYgKE5vdGlmaWNhdGlvbi5wZXJtaXNzaW9uID09PSBcImdyYW50ZWRcIilcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBub3RpZmljYXRpb24yID0gbmV3IE5vdGlmaWNhdGlvbihcIlwiKTtcbiAgICAgIG5vdGlmaWNhdGlvbjIub25zaG93ID0gKCkgPT4ge1xuICAgICAgICBub3RpZmljYXRpb24yLmNsb3NlKCk7XG4gICAgICB9O1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGlmIChlLm5hbWUgPT09IFwiVHlwZUVycm9yXCIpXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH0pO1xuICBjb25zdCBwZXJtaXNzaW9uR3JhbnRlZCA9IHNoYWxsb3dSZWYoaXNTdXBwb3J0ZWQudmFsdWUgJiYgXCJwZXJtaXNzaW9uXCIgaW4gTm90aWZpY2F0aW9uICYmIE5vdGlmaWNhdGlvbi5wZXJtaXNzaW9uID09PSBcImdyYW50ZWRcIik7XG4gIGNvbnN0IG5vdGlmaWNhdGlvbiA9IHJlZihudWxsKTtcbiAgY29uc3QgZW5zdXJlUGVybWlzc2lvbnMgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKCFpc1N1cHBvcnRlZC52YWx1ZSlcbiAgICAgIHJldHVybjtcbiAgICBpZiAoIXBlcm1pc3Npb25HcmFudGVkLnZhbHVlICYmIE5vdGlmaWNhdGlvbi5wZXJtaXNzaW9uICE9PSBcImRlbmllZFwiKSB7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBOb3RpZmljYXRpb24ucmVxdWVzdFBlcm1pc3Npb24oKTtcbiAgICAgIGlmIChyZXN1bHQgPT09IFwiZ3JhbnRlZFwiKVxuICAgICAgICBwZXJtaXNzaW9uR3JhbnRlZC52YWx1ZSA9IHRydWU7XG4gICAgfVxuICAgIHJldHVybiBwZXJtaXNzaW9uR3JhbnRlZC52YWx1ZTtcbiAgfTtcbiAgY29uc3QgeyBvbjogb25DbGljaywgdHJpZ2dlcjogY2xpY2tUcmlnZ2VyIH0gPSBjcmVhdGVFdmVudEhvb2soKTtcbiAgY29uc3QgeyBvbjogb25TaG93LCB0cmlnZ2VyOiBzaG93VHJpZ2dlciB9ID0gY3JlYXRlRXZlbnRIb29rKCk7XG4gIGNvbnN0IHsgb246IG9uRXJyb3IsIHRyaWdnZXI6IGVycm9yVHJpZ2dlciB9ID0gY3JlYXRlRXZlbnRIb29rKCk7XG4gIGNvbnN0IHsgb246IG9uQ2xvc2UsIHRyaWdnZXI6IGNsb3NlVHJpZ2dlciB9ID0gY3JlYXRlRXZlbnRIb29rKCk7XG4gIGNvbnN0IHNob3cgPSBhc3luYyAob3ZlcnJpZGVzKSA9PiB7XG4gICAgaWYgKCFpc1N1cHBvcnRlZC52YWx1ZSB8fCAhcGVybWlzc2lvbkdyYW50ZWQudmFsdWUpXG4gICAgICByZXR1cm47XG4gICAgY29uc3Qgb3B0aW9uczIgPSBPYmplY3QuYXNzaWduKHt9LCBkZWZhdWx0V2ViTm90aWZpY2F0aW9uT3B0aW9ucywgb3ZlcnJpZGVzKTtcbiAgICBub3RpZmljYXRpb24udmFsdWUgPSBuZXcgTm90aWZpY2F0aW9uKG9wdGlvbnMyLnRpdGxlIHx8IFwiXCIsIG9wdGlvbnMyKTtcbiAgICBub3RpZmljYXRpb24udmFsdWUub25jbGljayA9IGNsaWNrVHJpZ2dlcjtcbiAgICBub3RpZmljYXRpb24udmFsdWUub25zaG93ID0gc2hvd1RyaWdnZXI7XG4gICAgbm90aWZpY2F0aW9uLnZhbHVlLm9uZXJyb3IgPSBlcnJvclRyaWdnZXI7XG4gICAgbm90aWZpY2F0aW9uLnZhbHVlLm9uY2xvc2UgPSBjbG9zZVRyaWdnZXI7XG4gICAgcmV0dXJuIG5vdGlmaWNhdGlvbi52YWx1ZTtcbiAgfTtcbiAgY29uc3QgY2xvc2UgPSAoKSA9PiB7XG4gICAgaWYgKG5vdGlmaWNhdGlvbi52YWx1ZSlcbiAgICAgIG5vdGlmaWNhdGlvbi52YWx1ZS5jbG9zZSgpO1xuICAgIG5vdGlmaWNhdGlvbi52YWx1ZSA9IG51bGw7XG4gIH07XG4gIGlmIChfcmVxdWVzdEZvclBlcm1pc3Npb25zKVxuICAgIHRyeU9uTW91bnRlZChlbnN1cmVQZXJtaXNzaW9ucyk7XG4gIHRyeU9uU2NvcGVEaXNwb3NlKGNsb3NlKTtcbiAgaWYgKGlzU3VwcG9ydGVkLnZhbHVlICYmIHdpbmRvdykge1xuICAgIGNvbnN0IGRvY3VtZW50ID0gd2luZG93LmRvY3VtZW50O1xuICAgIHVzZUV2ZW50TGlzdGVuZXIoZG9jdW1lbnQsIFwidmlzaWJpbGl0eWNoYW5nZVwiLCAoZSkgPT4ge1xuICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgaWYgKGRvY3VtZW50LnZpc2liaWxpdHlTdGF0ZSA9PT0gXCJ2aXNpYmxlXCIpIHtcbiAgICAgICAgY2xvc2UoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICByZXR1cm4ge1xuICAgIGlzU3VwcG9ydGVkLFxuICAgIG5vdGlmaWNhdGlvbixcbiAgICBlbnN1cmVQZXJtaXNzaW9ucyxcbiAgICBwZXJtaXNzaW9uR3JhbnRlZCxcbiAgICBzaG93LFxuICAgIGNsb3NlLFxuICAgIG9uQ2xpY2ssXG4gICAgb25TaG93LFxuICAgIG9uRXJyb3IsXG4gICAgb25DbG9zZVxuICB9O1xufVxuXG5jb25zdCBERUZBVUxUX1BJTkdfTUVTU0FHRSA9IFwicGluZ1wiO1xuZnVuY3Rpb24gcmVzb2x2ZU5lc3RlZE9wdGlvbnMob3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdHJ1ZSlcbiAgICByZXR1cm4ge307XG4gIHJldHVybiBvcHRpb25zO1xufVxuZnVuY3Rpb24gdXNlV2ViU29ja2V0KHVybCwgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBvbkNvbm5lY3RlZCxcbiAgICBvbkRpc2Nvbm5lY3RlZCxcbiAgICBvbkVycm9yLFxuICAgIG9uTWVzc2FnZSxcbiAgICBpbW1lZGlhdGUgPSB0cnVlLFxuICAgIGF1dG9Db25uZWN0ID0gdHJ1ZSxcbiAgICBhdXRvQ2xvc2UgPSB0cnVlLFxuICAgIHByb3RvY29scyA9IFtdXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBkYXRhID0gcmVmKG51bGwpO1xuICBjb25zdCBzdGF0dXMgPSBzaGFsbG93UmVmKFwiQ0xPU0VEXCIpO1xuICBjb25zdCB3c1JlZiA9IHJlZigpO1xuICBjb25zdCB1cmxSZWYgPSB0b1JlZih1cmwpO1xuICBsZXQgaGVhcnRiZWF0UGF1c2U7XG4gIGxldCBoZWFydGJlYXRSZXN1bWU7XG4gIGxldCBleHBsaWNpdGx5Q2xvc2VkID0gZmFsc2U7XG4gIGxldCByZXRyaWVkID0gMDtcbiAgbGV0IGJ1ZmZlcmVkRGF0YSA9IFtdO1xuICBsZXQgcmV0cnlUaW1lb3V0O1xuICBsZXQgcG9uZ1RpbWVvdXRXYWl0O1xuICBjb25zdCBfc2VuZEJ1ZmZlciA9ICgpID0+IHtcbiAgICBpZiAoYnVmZmVyZWREYXRhLmxlbmd0aCAmJiB3c1JlZi52YWx1ZSAmJiBzdGF0dXMudmFsdWUgPT09IFwiT1BFTlwiKSB7XG4gICAgICBmb3IgKGNvbnN0IGJ1ZmZlciBvZiBidWZmZXJlZERhdGEpXG4gICAgICAgIHdzUmVmLnZhbHVlLnNlbmQoYnVmZmVyKTtcbiAgICAgIGJ1ZmZlcmVkRGF0YSA9IFtdO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgcmVzZXRSZXRyeSA9ICgpID0+IHtcbiAgICBpZiAocmV0cnlUaW1lb3V0ICE9IG51bGwpIHtcbiAgICAgIGNsZWFyVGltZW91dChyZXRyeVRpbWVvdXQpO1xuICAgICAgcmV0cnlUaW1lb3V0ID0gdm9pZCAwO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgcmVzZXRIZWFydGJlYXQgPSAoKSA9PiB7XG4gICAgY2xlYXJUaW1lb3V0KHBvbmdUaW1lb3V0V2FpdCk7XG4gICAgcG9uZ1RpbWVvdXRXYWl0ID0gdm9pZCAwO1xuICB9O1xuICBjb25zdCBjbG9zZSA9IChjb2RlID0gMWUzLCByZWFzb24pID0+IHtcbiAgICByZXNldFJldHJ5KCk7XG4gICAgaWYgKCFpc0NsaWVudCAmJiAhaXNXb3JrZXIgfHwgIXdzUmVmLnZhbHVlKVxuICAgICAgcmV0dXJuO1xuICAgIGV4cGxpY2l0bHlDbG9zZWQgPSB0cnVlO1xuICAgIHJlc2V0SGVhcnRiZWF0KCk7XG4gICAgaGVhcnRiZWF0UGF1c2UgPT0gbnVsbCA/IHZvaWQgMCA6IGhlYXJ0YmVhdFBhdXNlKCk7XG4gICAgd3NSZWYudmFsdWUuY2xvc2UoY29kZSwgcmVhc29uKTtcbiAgICB3c1JlZi52YWx1ZSA9IHZvaWQgMDtcbiAgfTtcbiAgY29uc3Qgc2VuZCA9IChkYXRhMiwgdXNlQnVmZmVyID0gdHJ1ZSkgPT4ge1xuICAgIGlmICghd3NSZWYudmFsdWUgfHwgc3RhdHVzLnZhbHVlICE9PSBcIk9QRU5cIikge1xuICAgICAgaWYgKHVzZUJ1ZmZlcilcbiAgICAgICAgYnVmZmVyZWREYXRhLnB1c2goZGF0YTIpO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBfc2VuZEJ1ZmZlcigpO1xuICAgIHdzUmVmLnZhbHVlLnNlbmQoZGF0YTIpO1xuICAgIHJldHVybiB0cnVlO1xuICB9O1xuICBjb25zdCBfaW5pdCA9ICgpID0+IHtcbiAgICBpZiAoZXhwbGljaXRseUNsb3NlZCB8fCB0eXBlb2YgdXJsUmVmLnZhbHVlID09PSBcInVuZGVmaW5lZFwiKVxuICAgICAgcmV0dXJuO1xuICAgIGNvbnN0IHdzID0gbmV3IFdlYlNvY2tldCh1cmxSZWYudmFsdWUsIHByb3RvY29scyk7XG4gICAgd3NSZWYudmFsdWUgPSB3cztcbiAgICBzdGF0dXMudmFsdWUgPSBcIkNPTk5FQ1RJTkdcIjtcbiAgICB3cy5vbm9wZW4gPSAoKSA9PiB7XG4gICAgICBzdGF0dXMudmFsdWUgPSBcIk9QRU5cIjtcbiAgICAgIHJldHJpZWQgPSAwO1xuICAgICAgb25Db25uZWN0ZWQgPT0gbnVsbCA/IHZvaWQgMCA6IG9uQ29ubmVjdGVkKHdzKTtcbiAgICAgIGhlYXJ0YmVhdFJlc3VtZSA9PSBudWxsID8gdm9pZCAwIDogaGVhcnRiZWF0UmVzdW1lKCk7XG4gICAgICBfc2VuZEJ1ZmZlcigpO1xuICAgIH07XG4gICAgd3Mub25jbG9zZSA9IChldikgPT4ge1xuICAgICAgc3RhdHVzLnZhbHVlID0gXCJDTE9TRURcIjtcbiAgICAgIHJlc2V0SGVhcnRiZWF0KCk7XG4gICAgICBoZWFydGJlYXRQYXVzZSA9PSBudWxsID8gdm9pZCAwIDogaGVhcnRiZWF0UGF1c2UoKTtcbiAgICAgIG9uRGlzY29ubmVjdGVkID09IG51bGwgPyB2b2lkIDAgOiBvbkRpc2Nvbm5lY3RlZCh3cywgZXYpO1xuICAgICAgaWYgKCFleHBsaWNpdGx5Q2xvc2VkICYmIG9wdGlvbnMuYXV0b1JlY29ubmVjdCAmJiAod3NSZWYudmFsdWUgPT0gbnVsbCB8fCB3cyA9PT0gd3NSZWYudmFsdWUpKSB7XG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICByZXRyaWVzID0gLTEsXG4gICAgICAgICAgZGVsYXkgPSAxZTMsXG4gICAgICAgICAgb25GYWlsZWRcbiAgICAgICAgfSA9IHJlc29sdmVOZXN0ZWRPcHRpb25zKG9wdGlvbnMuYXV0b1JlY29ubmVjdCk7XG4gICAgICAgIGNvbnN0IGNoZWNrUmV0aXJlcyA9IHR5cGVvZiByZXRyaWVzID09PSBcImZ1bmN0aW9uXCIgPyByZXRyaWVzIDogKCkgPT4gdHlwZW9mIHJldHJpZXMgPT09IFwibnVtYmVyXCIgJiYgKHJldHJpZXMgPCAwIHx8IHJldHJpZWQgPCByZXRyaWVzKTtcbiAgICAgICAgaWYgKGNoZWNrUmV0aXJlcyhyZXRyaWVkKSkge1xuICAgICAgICAgIHJldHJpZWQgKz0gMTtcbiAgICAgICAgICByZXRyeVRpbWVvdXQgPSBzZXRUaW1lb3V0KF9pbml0LCBkZWxheSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgb25GYWlsZWQgPT0gbnVsbCA/IHZvaWQgMCA6IG9uRmFpbGVkKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuICAgIHdzLm9uZXJyb3IgPSAoZSkgPT4ge1xuICAgICAgb25FcnJvciA9PSBudWxsID8gdm9pZCAwIDogb25FcnJvcih3cywgZSk7XG4gICAgfTtcbiAgICB3cy5vbm1lc3NhZ2UgPSAoZSkgPT4ge1xuICAgICAgaWYgKG9wdGlvbnMuaGVhcnRiZWF0KSB7XG4gICAgICAgIHJlc2V0SGVhcnRiZWF0KCk7XG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICBtZXNzYWdlID0gREVGQVVMVF9QSU5HX01FU1NBR0UsXG4gICAgICAgICAgcmVzcG9uc2VNZXNzYWdlID0gbWVzc2FnZVxuICAgICAgICB9ID0gcmVzb2x2ZU5lc3RlZE9wdGlvbnMob3B0aW9ucy5oZWFydGJlYXQpO1xuICAgICAgICBpZiAoZS5kYXRhID09PSB0b1ZhbHVlKHJlc3BvbnNlTWVzc2FnZSkpXG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgZGF0YS52YWx1ZSA9IGUuZGF0YTtcbiAgICAgIG9uTWVzc2FnZSA9PSBudWxsID8gdm9pZCAwIDogb25NZXNzYWdlKHdzLCBlKTtcbiAgICB9O1xuICB9O1xuICBpZiAob3B0aW9ucy5oZWFydGJlYXQpIHtcbiAgICBjb25zdCB7XG4gICAgICBtZXNzYWdlID0gREVGQVVMVF9QSU5HX01FU1NBR0UsXG4gICAgICBpbnRlcnZhbCA9IDFlMyxcbiAgICAgIHBvbmdUaW1lb3V0ID0gMWUzXG4gICAgfSA9IHJlc29sdmVOZXN0ZWRPcHRpb25zKG9wdGlvbnMuaGVhcnRiZWF0KTtcbiAgICBjb25zdCB7IHBhdXNlLCByZXN1bWUgfSA9IHVzZUludGVydmFsRm4oXG4gICAgICAoKSA9PiB7XG4gICAgICAgIHNlbmQodG9WYWx1ZShtZXNzYWdlKSwgZmFsc2UpO1xuICAgICAgICBpZiAocG9uZ1RpbWVvdXRXYWl0ICE9IG51bGwpXG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICBwb25nVGltZW91dFdhaXQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICBjbG9zZSgpO1xuICAgICAgICAgIGV4cGxpY2l0bHlDbG9zZWQgPSBmYWxzZTtcbiAgICAgICAgfSwgcG9uZ1RpbWVvdXQpO1xuICAgICAgfSxcbiAgICAgIGludGVydmFsLFxuICAgICAgeyBpbW1lZGlhdGU6IGZhbHNlIH1cbiAgICApO1xuICAgIGhlYXJ0YmVhdFBhdXNlID0gcGF1c2U7XG4gICAgaGVhcnRiZWF0UmVzdW1lID0gcmVzdW1lO1xuICB9XG4gIGlmIChhdXRvQ2xvc2UpIHtcbiAgICBpZiAoaXNDbGllbnQpXG4gICAgICB1c2VFdmVudExpc3RlbmVyKFwiYmVmb3JldW5sb2FkXCIsICgpID0+IGNsb3NlKCksIHsgcGFzc2l2ZTogdHJ1ZSB9KTtcbiAgICB0cnlPblNjb3BlRGlzcG9zZShjbG9zZSk7XG4gIH1cbiAgY29uc3Qgb3BlbiA9ICgpID0+IHtcbiAgICBpZiAoIWlzQ2xpZW50ICYmICFpc1dvcmtlcilcbiAgICAgIHJldHVybjtcbiAgICBjbG9zZSgpO1xuICAgIGV4cGxpY2l0bHlDbG9zZWQgPSBmYWxzZTtcbiAgICByZXRyaWVkID0gMDtcbiAgICBfaW5pdCgpO1xuICB9O1xuICBpZiAoaW1tZWRpYXRlKVxuICAgIG9wZW4oKTtcbiAgaWYgKGF1dG9Db25uZWN0KVxuICAgIHdhdGNoKHVybFJlZiwgb3Blbik7XG4gIHJldHVybiB7XG4gICAgZGF0YSxcbiAgICBzdGF0dXMsXG4gICAgY2xvc2UsXG4gICAgc2VuZCxcbiAgICBvcGVuLFxuICAgIHdzOiB3c1JlZlxuICB9O1xufVxuXG5mdW5jdGlvbiB1c2VXZWJXb3JrZXIoYXJnMCwgd29ya2VyT3B0aW9ucywgb3B0aW9ucykge1xuICBjb25zdCB7XG4gICAgd2luZG93ID0gZGVmYXVsdFdpbmRvd1xuICB9ID0gb3B0aW9ucyAhPSBudWxsID8gb3B0aW9ucyA6IHt9O1xuICBjb25zdCBkYXRhID0gcmVmKG51bGwpO1xuICBjb25zdCB3b3JrZXIgPSBzaGFsbG93UmVmKCk7XG4gIGNvbnN0IHBvc3QgPSAoLi4uYXJncykgPT4ge1xuICAgIGlmICghd29ya2VyLnZhbHVlKVxuICAgICAgcmV0dXJuO1xuICAgIHdvcmtlci52YWx1ZS5wb3N0TWVzc2FnZSguLi5hcmdzKTtcbiAgfTtcbiAgY29uc3QgdGVybWluYXRlID0gZnVuY3Rpb24gdGVybWluYXRlMigpIHtcbiAgICBpZiAoIXdvcmtlci52YWx1ZSlcbiAgICAgIHJldHVybjtcbiAgICB3b3JrZXIudmFsdWUudGVybWluYXRlKCk7XG4gIH07XG4gIGlmICh3aW5kb3cpIHtcbiAgICBpZiAodHlwZW9mIGFyZzAgPT09IFwic3RyaW5nXCIpXG4gICAgICB3b3JrZXIudmFsdWUgPSBuZXcgV29ya2VyKGFyZzAsIHdvcmtlck9wdGlvbnMpO1xuICAgIGVsc2UgaWYgKHR5cGVvZiBhcmcwID09PSBcImZ1bmN0aW9uXCIpXG4gICAgICB3b3JrZXIudmFsdWUgPSBhcmcwKCk7XG4gICAgZWxzZVxuICAgICAgd29ya2VyLnZhbHVlID0gYXJnMDtcbiAgICB3b3JrZXIudmFsdWUub25tZXNzYWdlID0gKGUpID0+IHtcbiAgICAgIGRhdGEudmFsdWUgPSBlLmRhdGE7XG4gICAgfTtcbiAgICB0cnlPblNjb3BlRGlzcG9zZSgoKSA9PiB7XG4gICAgICBpZiAod29ya2VyLnZhbHVlKVxuICAgICAgICB3b3JrZXIudmFsdWUudGVybWluYXRlKCk7XG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBkYXRhLFxuICAgIHBvc3QsXG4gICAgdGVybWluYXRlLFxuICAgIHdvcmtlclxuICB9O1xufVxuXG5mdW5jdGlvbiBkZXBzUGFyc2VyKGRlcHMsIGxvY2FsRGVwcykge1xuICBpZiAoZGVwcy5sZW5ndGggPT09IDAgJiYgbG9jYWxEZXBzLmxlbmd0aCA9PT0gMClcbiAgICByZXR1cm4gXCJcIjtcbiAgY29uc3QgZGVwc1N0cmluZyA9IGRlcHMubWFwKChkZXApID0+IGAnJHtkZXB9J2ApLnRvU3RyaW5nKCk7XG4gIGNvbnN0IGRlcHNGdW5jdGlvblN0cmluZyA9IGxvY2FsRGVwcy5maWx0ZXIoKGRlcCkgPT4gdHlwZW9mIGRlcCA9PT0gXCJmdW5jdGlvblwiKS5tYXAoKGZuKSA9PiB7XG4gICAgY29uc3Qgc3RyID0gZm4udG9TdHJpbmcoKTtcbiAgICBpZiAoc3RyLnRyaW0oKS5zdGFydHNXaXRoKFwiZnVuY3Rpb25cIikpIHtcbiAgICAgIHJldHVybiBzdHI7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IG5hbWUgPSBmbi5uYW1lO1xuICAgICAgcmV0dXJuIGBjb25zdCAke25hbWV9ID0gJHtzdHJ9YDtcbiAgICB9XG4gIH0pLmpvaW4oXCI7XCIpO1xuICBjb25zdCBpbXBvcnRTdHJpbmcgPSBgaW1wb3J0U2NyaXB0cygke2RlcHNTdHJpbmd9KTtgO1xuICByZXR1cm4gYCR7ZGVwc1N0cmluZy50cmltKCkgPT09IFwiXCIgPyBcIlwiIDogaW1wb3J0U3RyaW5nfSAke2RlcHNGdW5jdGlvblN0cmluZ31gO1xufVxuXG5mdW5jdGlvbiBqb2JSdW5uZXIodXNlckZ1bmMpIHtcbiAgcmV0dXJuIChlKSA9PiB7XG4gICAgY29uc3QgdXNlckZ1bmNBcmdzID0gZS5kYXRhWzBdO1xuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUodXNlckZ1bmMuYXBwbHkodm9pZCAwLCB1c2VyRnVuY0FyZ3MpKS50aGVuKChyZXN1bHQpID0+IHtcbiAgICAgIHBvc3RNZXNzYWdlKFtcIlNVQ0NFU1NcIiwgcmVzdWx0XSk7XG4gICAgfSkuY2F0Y2goKGVycm9yKSA9PiB7XG4gICAgICBwb3N0TWVzc2FnZShbXCJFUlJPUlwiLCBlcnJvcl0pO1xuICAgIH0pO1xuICB9O1xufVxuXG5mdW5jdGlvbiBjcmVhdGVXb3JrZXJCbG9iVXJsKGZuLCBkZXBzLCBsb2NhbERlcHMpIHtcbiAgY29uc3QgYmxvYkNvZGUgPSBgJHtkZXBzUGFyc2VyKGRlcHMsIGxvY2FsRGVwcyl9OyBvbm1lc3NhZ2U9KCR7am9iUnVubmVyfSkoJHtmbn0pYDtcbiAgY29uc3QgYmxvYiA9IG5ldyBCbG9iKFtibG9iQ29kZV0sIHsgdHlwZTogXCJ0ZXh0L2phdmFzY3JpcHRcIiB9KTtcbiAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcbiAgcmV0dXJuIHVybDtcbn1cblxuZnVuY3Rpb24gdXNlV2ViV29ya2VyRm4oZm4sIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgZGVwZW5kZW5jaWVzID0gW10sXG4gICAgbG9jYWxEZXBlbmRlbmNpZXMgPSBbXSxcbiAgICB0aW1lb3V0LFxuICAgIHdpbmRvdyA9IGRlZmF1bHRXaW5kb3dcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IHdvcmtlciA9IHJlZigpO1xuICBjb25zdCB3b3JrZXJTdGF0dXMgPSBzaGFsbG93UmVmKFwiUEVORElOR1wiKTtcbiAgY29uc3QgcHJvbWlzZSA9IHJlZih7fSk7XG4gIGNvbnN0IHRpbWVvdXRJZCA9IHNoYWxsb3dSZWYoKTtcbiAgY29uc3Qgd29ya2VyVGVybWluYXRlID0gKHN0YXR1cyA9IFwiUEVORElOR1wiKSA9PiB7XG4gICAgaWYgKHdvcmtlci52YWx1ZSAmJiB3b3JrZXIudmFsdWUuX3VybCAmJiB3aW5kb3cpIHtcbiAgICAgIHdvcmtlci52YWx1ZS50ZXJtaW5hdGUoKTtcbiAgICAgIFVSTC5yZXZva2VPYmplY3RVUkwod29ya2VyLnZhbHVlLl91cmwpO1xuICAgICAgcHJvbWlzZS52YWx1ZSA9IHt9O1xuICAgICAgd29ya2VyLnZhbHVlID0gdm9pZCAwO1xuICAgICAgd2luZG93LmNsZWFyVGltZW91dCh0aW1lb3V0SWQudmFsdWUpO1xuICAgICAgd29ya2VyU3RhdHVzLnZhbHVlID0gc3RhdHVzO1xuICAgIH1cbiAgfTtcbiAgd29ya2VyVGVybWluYXRlKCk7XG4gIHRyeU9uU2NvcGVEaXNwb3NlKHdvcmtlclRlcm1pbmF0ZSk7XG4gIGNvbnN0IGdlbmVyYXRlV29ya2VyID0gKCkgPT4ge1xuICAgIGNvbnN0IGJsb2JVcmwgPSBjcmVhdGVXb3JrZXJCbG9iVXJsKGZuLCBkZXBlbmRlbmNpZXMsIGxvY2FsRGVwZW5kZW5jaWVzKTtcbiAgICBjb25zdCBuZXdXb3JrZXIgPSBuZXcgV29ya2VyKGJsb2JVcmwpO1xuICAgIG5ld1dvcmtlci5fdXJsID0gYmxvYlVybDtcbiAgICBuZXdXb3JrZXIub25tZXNzYWdlID0gKGUpID0+IHtcbiAgICAgIGNvbnN0IHsgcmVzb2x2ZSA9ICgpID0+IHtcbiAgICAgIH0sIHJlamVjdCA9ICgpID0+IHtcbiAgICAgIH0gfSA9IHByb21pc2UudmFsdWU7XG4gICAgICBjb25zdCBbc3RhdHVzLCByZXN1bHRdID0gZS5kYXRhO1xuICAgICAgc3dpdGNoIChzdGF0dXMpIHtcbiAgICAgICAgY2FzZSBcIlNVQ0NFU1NcIjpcbiAgICAgICAgICByZXNvbHZlKHJlc3VsdCk7XG4gICAgICAgICAgd29ya2VyVGVybWluYXRlKHN0YXR1cyk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgcmVqZWN0KHJlc3VsdCk7XG4gICAgICAgICAgd29ya2VyVGVybWluYXRlKFwiRVJST1JcIik7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfTtcbiAgICBuZXdXb3JrZXIub25lcnJvciA9IChlKSA9PiB7XG4gICAgICBjb25zdCB7IHJlamVjdCA9ICgpID0+IHtcbiAgICAgIH0gfSA9IHByb21pc2UudmFsdWU7XG4gICAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgICByZWplY3QoZSk7XG4gICAgICB3b3JrZXJUZXJtaW5hdGUoXCJFUlJPUlwiKTtcbiAgICB9O1xuICAgIGlmICh0aW1lb3V0KSB7XG4gICAgICB0aW1lb3V0SWQudmFsdWUgPSBzZXRUaW1lb3V0KFxuICAgICAgICAoKSA9PiB3b3JrZXJUZXJtaW5hdGUoXCJUSU1FT1VUX0VYUElSRURcIiksXG4gICAgICAgIHRpbWVvdXRcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBuZXdXb3JrZXI7XG4gIH07XG4gIGNvbnN0IGNhbGxXb3JrZXIgPSAoLi4uZm5BcmdzKSA9PiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgdmFyIF9hO1xuICAgIHByb21pc2UudmFsdWUgPSB7XG4gICAgICByZXNvbHZlLFxuICAgICAgcmVqZWN0XG4gICAgfTtcbiAgICAoX2EgPSB3b3JrZXIudmFsdWUpID09IG51bGwgPyB2b2lkIDAgOiBfYS5wb3N0TWVzc2FnZShbWy4uLmZuQXJnc11dKTtcbiAgICB3b3JrZXJTdGF0dXMudmFsdWUgPSBcIlJVTk5JTkdcIjtcbiAgfSk7XG4gIGNvbnN0IHdvcmtlckZuID0gKC4uLmZuQXJncykgPT4ge1xuICAgIGlmICh3b3JrZXJTdGF0dXMudmFsdWUgPT09IFwiUlVOTklOR1wiKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBcIlt1c2VXZWJXb3JrZXJGbl0gWW91IGNhbiBvbmx5IHJ1biBvbmUgaW5zdGFuY2Ugb2YgdGhlIHdvcmtlciBhdCBhIHRpbWUuXCJcbiAgICAgICk7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QoKTtcbiAgICB9XG4gICAgd29ya2VyLnZhbHVlID0gZ2VuZXJhdGVXb3JrZXIoKTtcbiAgICByZXR1cm4gY2FsbFdvcmtlciguLi5mbkFyZ3MpO1xuICB9O1xuICByZXR1cm4ge1xuICAgIHdvcmtlckZuLFxuICAgIHdvcmtlclN0YXR1cyxcbiAgICB3b3JrZXJUZXJtaW5hdGVcbiAgfTtcbn1cblxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHVzZVdpbmRvd0ZvY3VzKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7IHdpbmRvdyA9IGRlZmF1bHRXaW5kb3cgfSA9IG9wdGlvbnM7XG4gIGlmICghd2luZG93KVxuICAgIHJldHVybiBzaGFsbG93UmVmKGZhbHNlKTtcbiAgY29uc3QgZm9jdXNlZCA9IHNoYWxsb3dSZWYod2luZG93LmRvY3VtZW50Lmhhc0ZvY3VzKCkpO1xuICBjb25zdCBsaXN0ZW5lck9wdGlvbnMgPSB7IHBhc3NpdmU6IHRydWUgfTtcbiAgdXNlRXZlbnRMaXN0ZW5lcih3aW5kb3csIFwiYmx1clwiLCAoKSA9PiB7XG4gICAgZm9jdXNlZC52YWx1ZSA9IGZhbHNlO1xuICB9LCBsaXN0ZW5lck9wdGlvbnMpO1xuICB1c2VFdmVudExpc3RlbmVyKHdpbmRvdywgXCJmb2N1c1wiLCAoKSA9PiB7XG4gICAgZm9jdXNlZC52YWx1ZSA9IHRydWU7XG4gIH0sIGxpc3RlbmVyT3B0aW9ucyk7XG4gIHJldHVybiBmb2N1c2VkO1xufVxuXG5mdW5jdGlvbiB1c2VXaW5kb3dTY3JvbGwob3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHsgd2luZG93ID0gZGVmYXVsdFdpbmRvdywgLi4ucmVzdCB9ID0gb3B0aW9ucztcbiAgcmV0dXJuIHVzZVNjcm9sbCh3aW5kb3csIHJlc3QpO1xufVxuXG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gdXNlV2luZG93U2l6ZShvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIHdpbmRvdyA9IGRlZmF1bHRXaW5kb3csXG4gICAgaW5pdGlhbFdpZHRoID0gTnVtYmVyLlBPU0lUSVZFX0lORklOSVRZLFxuICAgIGluaXRpYWxIZWlnaHQgPSBOdW1iZXIuUE9TSVRJVkVfSU5GSU5JVFksXG4gICAgbGlzdGVuT3JpZW50YXRpb24gPSB0cnVlLFxuICAgIGluY2x1ZGVTY3JvbGxiYXIgPSB0cnVlLFxuICAgIHR5cGUgPSBcImlubmVyXCJcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IHdpZHRoID0gc2hhbGxvd1JlZihpbml0aWFsV2lkdGgpO1xuICBjb25zdCBoZWlnaHQgPSBzaGFsbG93UmVmKGluaXRpYWxIZWlnaHQpO1xuICBjb25zdCB1cGRhdGUgPSAoKSA9PiB7XG4gICAgaWYgKHdpbmRvdykge1xuICAgICAgaWYgKHR5cGUgPT09IFwib3V0ZXJcIikge1xuICAgICAgICB3aWR0aC52YWx1ZSA9IHdpbmRvdy5vdXRlcldpZHRoO1xuICAgICAgICBoZWlnaHQudmFsdWUgPSB3aW5kb3cub3V0ZXJIZWlnaHQ7XG4gICAgICB9IGVsc2UgaWYgKHR5cGUgPT09IFwidmlzdWFsXCIgJiYgd2luZG93LnZpc3VhbFZpZXdwb3J0KSB7XG4gICAgICAgIGNvbnN0IHsgd2lkdGg6IHZpc3VhbFZpZXdwb3J0V2lkdGgsIGhlaWdodDogdmlzdWFsVmlld3BvcnRIZWlnaHQsIHNjYWxlIH0gPSB3aW5kb3cudmlzdWFsVmlld3BvcnQ7XG4gICAgICAgIHdpZHRoLnZhbHVlID0gTWF0aC5yb3VuZCh2aXN1YWxWaWV3cG9ydFdpZHRoICogc2NhbGUpO1xuICAgICAgICBoZWlnaHQudmFsdWUgPSBNYXRoLnJvdW5kKHZpc3VhbFZpZXdwb3J0SGVpZ2h0ICogc2NhbGUpO1xuICAgICAgfSBlbHNlIGlmIChpbmNsdWRlU2Nyb2xsYmFyKSB7XG4gICAgICAgIHdpZHRoLnZhbHVlID0gd2luZG93LmlubmVyV2lkdGg7XG4gICAgICAgIGhlaWdodC52YWx1ZSA9IHdpbmRvdy5pbm5lckhlaWdodDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHdpZHRoLnZhbHVlID0gd2luZG93LmRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGllbnRXaWR0aDtcbiAgICAgICAgaGVpZ2h0LnZhbHVlID0gd2luZG93LmRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5jbGllbnRIZWlnaHQ7XG4gICAgICB9XG4gICAgfVxuICB9O1xuICB1cGRhdGUoKTtcbiAgdHJ5T25Nb3VudGVkKHVwZGF0ZSk7XG4gIGNvbnN0IGxpc3RlbmVyT3B0aW9ucyA9IHsgcGFzc2l2ZTogdHJ1ZSB9O1xuICB1c2VFdmVudExpc3RlbmVyKFwicmVzaXplXCIsIHVwZGF0ZSwgbGlzdGVuZXJPcHRpb25zKTtcbiAgaWYgKHdpbmRvdyAmJiB0eXBlID09PSBcInZpc3VhbFwiICYmIHdpbmRvdy52aXN1YWxWaWV3cG9ydCkge1xuICAgIHVzZUV2ZW50TGlzdGVuZXIod2luZG93LnZpc3VhbFZpZXdwb3J0LCBcInJlc2l6ZVwiLCB1cGRhdGUsIGxpc3RlbmVyT3B0aW9ucyk7XG4gIH1cbiAgaWYgKGxpc3Rlbk9yaWVudGF0aW9uKSB7XG4gICAgY29uc3QgbWF0Y2hlcyA9IHVzZU1lZGlhUXVlcnkoXCIob3JpZW50YXRpb246IHBvcnRyYWl0KVwiKTtcbiAgICB3YXRjaChtYXRjaGVzLCAoKSA9PiB1cGRhdGUoKSk7XG4gIH1cbiAgcmV0dXJuIHsgd2lkdGgsIGhlaWdodCB9O1xufVxuXG5leHBvcnQgeyBEZWZhdWx0TWFnaWNLZXlzQWxpYXNNYXAsIFN0b3JhZ2VTZXJpYWxpemVycywgVHJhbnNpdGlvblByZXNldHMsIGNvbXB1dGVkQXN5bmMgYXMgYXN5bmNDb21wdXRlZCwgYnJlYWtwb2ludHNBbnREZXNpZ24sIGJyZWFrcG9pbnRzQm9vdHN0cmFwVjUsIGJyZWFrcG9pbnRzRWxlbWVudCwgYnJlYWtwb2ludHNNYXN0ZXJDc3MsIGJyZWFrcG9pbnRzUHJpbWVGbGV4LCBicmVha3BvaW50c1F1YXNhciwgYnJlYWtwb2ludHNTZW1hdGljLCBicmVha3BvaW50c1RhaWx3aW5kLCBicmVha3BvaW50c1Z1ZXRpZnksIGJyZWFrcG9pbnRzVnVldGlmeVYyLCBicmVha3BvaW50c1Z1ZXRpZnlWMywgY2xvbmVGbkpTT04sIGNvbXB1dGVkQXN5bmMsIGNvbXB1dGVkSW5qZWN0LCBjcmVhdGVGZXRjaCwgY3JlYXRlUmV1c2FibGVUZW1wbGF0ZSwgY3JlYXRlVGVtcGxhdGVQcm9taXNlLCBjcmVhdGVVbnJlZkZuLCBjdXN0b21TdG9yYWdlRXZlbnROYW1lLCBkZWZhdWx0RG9jdW1lbnQsIGRlZmF1bHRMb2NhdGlvbiwgZGVmYXVsdE5hdmlnYXRvciwgZGVmYXVsdFdpbmRvdywgZXhlY3V0ZVRyYW5zaXRpb24sIGZvcm1hdFRpbWVBZ28sIGZvcm1hdFRpbWVBZ29JbnRsLCBmb3JtYXRUaW1lQWdvSW50bFBhcnRzLCBnZXRTU1JIYW5kbGVyLCBtYXBHYW1lcGFkVG9YYm94MzYwQ29udHJvbGxlciwgb25DbGlja091dHNpZGUsIG9uRWxlbWVudFJlbW92YWwsIG9uS2V5RG93biwgb25LZXlQcmVzc2VkLCBvbktleVN0cm9rZSwgb25LZXlVcCwgb25Mb25nUHJlc3MsIG9uU3RhcnRUeXBpbmcsIHByb3ZpZGVTU1JXaWR0aCwgc2V0U1NSSGFuZGxlciwgdGVtcGxhdGVSZWYsIHVucmVmRWxlbWVudCwgdXNlQWN0aXZlRWxlbWVudCwgdXNlQW5pbWF0ZSwgdXNlQXN5bmNRdWV1ZSwgdXNlQXN5bmNTdGF0ZSwgdXNlQmFzZTY0LCB1c2VCYXR0ZXJ5LCB1c2VCbHVldG9vdGgsIHVzZUJyZWFrcG9pbnRzLCB1c2VCcm9hZGNhc3RDaGFubmVsLCB1c2VCcm93c2VyTG9jYXRpb24sIHVzZUNhY2hlZCwgdXNlQ2xpcGJvYXJkLCB1c2VDbGlwYm9hcmRJdGVtcywgdXNlQ2xvbmVkLCB1c2VDb2xvck1vZGUsIHVzZUNvbmZpcm1EaWFsb2csIHVzZUNvdW50ZG93biwgdXNlQ3NzVmFyLCB1c2VDdXJyZW50RWxlbWVudCwgdXNlQ3ljbGVMaXN0LCB1c2VEYXJrLCB1c2VEZWJvdW5jZWRSZWZIaXN0b3J5LCB1c2VEZXZpY2VNb3Rpb24sIHVzZURldmljZU9yaWVudGF0aW9uLCB1c2VEZXZpY2VQaXhlbFJhdGlvLCB1c2VEZXZpY2VzTGlzdCwgdXNlRGlzcGxheU1lZGlhLCB1c2VEb2N1bWVudFZpc2liaWxpdHksIHVzZURyYWdnYWJsZSwgdXNlRHJvcFpvbmUsIHVzZUVsZW1lbnRCb3VuZGluZywgdXNlRWxlbWVudEJ5UG9pbnQsIHVzZUVsZW1lbnRIb3ZlciwgdXNlRWxlbWVudFNpemUsIHVzZUVsZW1lbnRWaXNpYmlsaXR5LCB1c2VFdmVudEJ1cywgdXNlRXZlbnRMaXN0ZW5lciwgdXNlRXZlbnRTb3VyY2UsIHVzZUV5ZURyb3BwZXIsIHVzZUZhdmljb24sIHVzZUZldGNoLCB1c2VGaWxlRGlhbG9nLCB1c2VGaWxlU3lzdGVtQWNjZXNzLCB1c2VGb2N1cywgdXNlRm9jdXNXaXRoaW4sIHVzZUZwcywgdXNlRnVsbHNjcmVlbiwgdXNlR2FtZXBhZCwgdXNlR2VvbG9jYXRpb24sIHVzZUlkbGUsIHVzZUltYWdlLCB1c2VJbmZpbml0ZVNjcm9sbCwgdXNlSW50ZXJzZWN0aW9uT2JzZXJ2ZXIsIHVzZUtleU1vZGlmaWVyLCB1c2VMb2NhbFN0b3JhZ2UsIHVzZU1hZ2ljS2V5cywgdXNlTWFudWFsUmVmSGlzdG9yeSwgdXNlTWVkaWFDb250cm9scywgdXNlTWVkaWFRdWVyeSwgdXNlTWVtb2l6ZSwgdXNlTWVtb3J5LCB1c2VNb3VudGVkLCB1c2VNb3VzZSwgdXNlTW91c2VJbkVsZW1lbnQsIHVzZU1vdXNlUHJlc3NlZCwgdXNlTXV0YXRpb25PYnNlcnZlciwgdXNlTmF2aWdhdG9yTGFuZ3VhZ2UsIHVzZU5ldHdvcmssIHVzZU5vdywgdXNlT2JqZWN0VXJsLCB1c2VPZmZzZXRQYWdpbmF0aW9uLCB1c2VPbmxpbmUsIHVzZVBhZ2VMZWF2ZSwgdXNlUGFyYWxsYXgsIHVzZVBhcmVudEVsZW1lbnQsIHVzZVBlcmZvcm1hbmNlT2JzZXJ2ZXIsIHVzZVBlcm1pc3Npb24sIHVzZVBvaW50ZXIsIHVzZVBvaW50ZXJMb2NrLCB1c2VQb2ludGVyU3dpcGUsIHVzZVByZWZlcnJlZENvbG9yU2NoZW1lLCB1c2VQcmVmZXJyZWRDb250cmFzdCwgdXNlUHJlZmVycmVkRGFyaywgdXNlUHJlZmVycmVkTGFuZ3VhZ2VzLCB1c2VQcmVmZXJyZWRSZWR1Y2VkTW90aW9uLCB1c2VQcmVmZXJyZWRSZWR1Y2VkVHJhbnNwYXJlbmN5LCB1c2VQcmV2aW91cywgdXNlUmFmRm4sIHVzZVJlZkhpc3RvcnksIHVzZVJlc2l6ZU9ic2VydmVyLCB1c2VTU1JXaWR0aCwgdXNlU2NyZWVuT3JpZW50YXRpb24sIHVzZVNjcmVlblNhZmVBcmVhLCB1c2VTY3JpcHRUYWcsIHVzZVNjcm9sbCwgdXNlU2Nyb2xsTG9jaywgdXNlU2Vzc2lvblN0b3JhZ2UsIHVzZVNoYXJlLCB1c2VTb3J0ZWQsIHVzZVNwZWVjaFJlY29nbml0aW9uLCB1c2VTcGVlY2hTeW50aGVzaXMsIHVzZVN0ZXBwZXIsIHVzZVN0b3JhZ2UsIHVzZVN0b3JhZ2VBc3luYywgdXNlU3R5bGVUYWcsIHVzZVN1cHBvcnRlZCwgdXNlU3dpcGUsIHVzZVRlbXBsYXRlUmVmc0xpc3QsIHVzZVRleHREaXJlY3Rpb24sIHVzZVRleHRTZWxlY3Rpb24sIHVzZVRleHRhcmVhQXV0b3NpemUsIHVzZVRocm90dGxlZFJlZkhpc3RvcnksIHVzZVRpbWVBZ28sIHVzZVRpbWVBZ29JbnRsLCB1c2VUaW1lb3V0UG9sbCwgdXNlVGltZXN0YW1wLCB1c2VUaXRsZSwgdXNlVHJhbnNpdGlvbiwgdXNlVXJsU2VhcmNoUGFyYW1zLCB1c2VVc2VyTWVkaWEsIHVzZVZNb2RlbCwgdXNlVk1vZGVscywgdXNlVmlicmF0ZSwgdXNlVmlydHVhbExpc3QsIHVzZVdha2VMb2NrLCB1c2VXZWJOb3RpZmljYXRpb24sIHVzZVdlYlNvY2tldCwgdXNlV2ViV29ya2VyLCB1c2VXZWJXb3JrZXJGbiwgdXNlV2luZG93Rm9jdXMsIHVzZVdpbmRvd1Njcm9sbCwgdXNlV2luZG93U2l6ZSB9O1xuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=