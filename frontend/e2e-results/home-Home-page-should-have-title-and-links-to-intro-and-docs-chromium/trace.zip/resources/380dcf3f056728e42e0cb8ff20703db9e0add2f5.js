import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.cache/vite/client/deps/nostics_reporters_dev.js?v=7e73afc2");//#region node_modules/.pnpm/nostics@1.2.0/node_modules/nostics/dist/reporters/dev.mjs
/**
* Creates a reporter for browser code under Vite dev: it forwards each
* diagnostic over `import.meta.hot.send('nostics:report', ...)` so the
* dev-server collector can file it. Outside Vite (`import.meta.hot` absent) it
* warns once and does nothing.
*/
/* @__NO_SIDE_EFFECTS__ */
function createDevReporter() {
	return (diagnostic) => {
		if (import.meta.hot && typeof import.meta.hot.send === "function") import.meta.hot.send("nostics:report", diagnostic.toJSON());
		else console.warn("[nostics]: import.meta.hot.send() is not available. This must be running on Vite.");
	};
}
//#endregion
export { createDevReporter };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibm9zdGljc19yZXBvcnRlcnNfZGV2LmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy5wbnBtL25vc3RpY3NAMS4yLjAvbm9kZV9tb2R1bGVzL25vc3RpY3MvZGlzdC9yZXBvcnRlcnMvZGV2Lm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyNyZWdpb24gc3JjL3JlcG9ydGVycy9kZXYudHNcbi8qKlxuKiBDcmVhdGVzIGEgcmVwb3J0ZXIgZm9yIGJyb3dzZXIgY29kZSB1bmRlciBWaXRlIGRldjogaXQgZm9yd2FyZHMgZWFjaFxuKiBkaWFnbm9zdGljIG92ZXIgYGltcG9ydC5tZXRhLmhvdC5zZW5kKCdub3N0aWNzOnJlcG9ydCcsIC4uLilgIHNvIHRoZVxuKiBkZXYtc2VydmVyIGNvbGxlY3RvciBjYW4gZmlsZSBpdC4gT3V0c2lkZSBWaXRlIChgaW1wb3J0Lm1ldGEuaG90YCBhYnNlbnQpIGl0XG4qIHdhcm5zIG9uY2UgYW5kIGRvZXMgbm90aGluZy5cbiovXG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gY3JlYXRlRGV2UmVwb3J0ZXIoKSB7XG5cdHJldHVybiAoZGlhZ25vc3RpYykgPT4ge1xuXHRcdGlmIChpbXBvcnQubWV0YS5ob3QgJiYgdHlwZW9mIGltcG9ydC5tZXRhLmhvdC5zZW5kID09PSBcImZ1bmN0aW9uXCIpIGltcG9ydC5tZXRhLmhvdC5zZW5kKFwibm9zdGljczpyZXBvcnRcIiwgZGlhZ25vc3RpYy50b0pTT04oKSk7XG5cdFx0ZWxzZSBjb25zb2xlLndhcm4oXCJbbm9zdGljc106IGltcG9ydC5tZXRhLmhvdC5zZW5kKCkgaXMgbm90IGF2YWlsYWJsZS4gVGhpcyBtdXN0IGJlIHJ1bm5pbmcgb24gVml0ZS5cIik7XG5cdH07XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGNyZWF0ZURldlJlcG9ydGVyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWRldi5tanMubWFwIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBUUEsU0FBUyxvQkFBb0I7Q0FDNUIsUUFBUSxlQUFlO0VBQ3RCLElBQUksWUFBWSxPQUFPLE9BQU8sWUFBWSxJQUFJLFNBQVMsWUFBWSxZQUFZLElBQUksS0FBSyxrQkFBa0IsV0FBVyxPQUFPLENBQUM7T0FDeEgsUUFBUSxLQUFLLG1GQUFtRjtDQUN0RztBQUNEIn0=