/**
* vue v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
import { initCustomFormatter, warn } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vue+runtime-dom@3.5.40/node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js?v=7e73afc2";
export * from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vue+runtime-dom@3.5.40/node_modules/@vue/runtime-dom/dist/runtime-dom.esm-bundler.js?v=7e73afc2";
function initDev() {
	{
		initCustomFormatter();
	}
}
if (!!("development" !== "production")) {
	initDev();
}
const compile = () => {
	if (!!("development" !== "production")) {
		warn(`Runtime compilation is not supported in this build of Vue.` + ` Configure your bundler to alias "vue" to "vue/dist/vue.esm-bundler.js".`);
	}
};
export { compile };

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFLQSxTQUFTLHFCQUFxQixZQUFZO0FBQzFDLGNBQWM7QUFFZCxTQUFTLFVBQVU7Q0FDakI7RUFDRSxvQkFBb0I7Q0FDdEI7QUFDRjtBQUVBLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtDQUM3QyxRQUFRO0FBQ1Y7QUFDQSxNQUFNLGdCQUFnQjtDQUNwQixJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDN0MsS0FDRSwrREFBZ0UsMEVBQ2xFO0NBQ0Y7QUFDRjtBQUVBLFNBQVMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsidnVlLnJ1bnRpbWUuZXNtLWJ1bmRsZXIuanM/dj03ZTczYWZjMiJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiogdnVlIHYzLjUuNDBcbiogKGMpIDIwMTgtcHJlc2VudCBZdXhpIChFdmFuKSBZb3UgYW5kIFZ1ZSBjb250cmlidXRvcnNcbiogQGxpY2Vuc2UgTUlUXG4qKi9cbmltcG9ydCB7IGluaXRDdXN0b21Gb3JtYXR0ZXIsIHdhcm4gfSBmcm9tICdAdnVlL3J1bnRpbWUtZG9tJztcbmV4cG9ydCAqIGZyb20gJ0B2dWUvcnVudGltZS1kb20nO1xuXG5mdW5jdGlvbiBpbml0RGV2KCkge1xuICB7XG4gICAgaW5pdEN1c3RvbUZvcm1hdHRlcigpO1xuICB9XG59XG5cbmlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gIGluaXREZXYoKTtcbn1cbmNvbnN0IGNvbXBpbGUgPSAoKSA9PiB7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgd2FybihcbiAgICAgIGBSdW50aW1lIGNvbXBpbGF0aW9uIGlzIG5vdCBzdXBwb3J0ZWQgaW4gdGhpcyBidWlsZCBvZiBWdWUuYCArIChgIENvbmZpZ3VyZSB5b3VyIGJ1bmRsZXIgdG8gYWxpYXMgXCJ2dWVcIiB0byBcInZ1ZS9kaXN0L3Z1ZS5lc20tYnVuZGxlci5qc1wiLmAgKVxuICAgICk7XG4gIH1cbn07XG5cbmV4cG9ydCB7IGNvbXBpbGUgfTtcbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19