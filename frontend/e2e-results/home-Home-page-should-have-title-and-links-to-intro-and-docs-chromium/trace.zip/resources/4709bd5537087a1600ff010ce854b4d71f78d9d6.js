import { _isFirebaseServerApp, _getProvider, getApp, _registerComponent, registerVersion, SDK_VERSION } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@firebase+app@0.16.0/node_modules/@firebase/app/dist/esm/index.esm.js?v=7e73afc2";
import { FirebaseError, isCloudWorkstation, pingServer, createMockUserToken, getModularInstance, getDefaultEmulatorHostnameAndPort } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@firebase+util@1.15.2/node_modules/@firebase/util/dist/index.esm.js?v=7e73afc2";
import { Component } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@firebase+component@0.7.4/node_modules/@firebase/component/dist/esm/index.esm.js?v=7e73afc2";

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @fileoverview Constants used in the Firebase Storage library.
 */
/**
 * Domain name for firebase storage.
 */
const DEFAULT_HOST = 'firebasestorage.googleapis.com';
/**
 * The key in Firebase config json for the storage bucket.
 */
const CONFIG_STORAGE_BUCKET_KEY = 'storageBucket';
/**
 * 2 minutes
 *
 * The timeout for all operations except upload.
 */
const DEFAULT_MAX_OPERATION_RETRY_TIME = 2 * 60 * 1000;
/**
 * 10 minutes
 *
 * The timeout for upload.
 */
const DEFAULT_MAX_UPLOAD_RETRY_TIME = 10 * 60 * 1000;
/**
 * 1 second
 */
const DEFAULT_MIN_SLEEP_TIME_MILLIS = 1000;

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * An error returned by the Firebase Storage SDK.
 * @public
 */
class StorageError extends FirebaseError {
    /**
     * @param code - A `StorageErrorCode` string to be prefixed with 'storage/' and
     *  added to the end of the message.
     * @param message  - Error message.
     * @param status_ - Corresponding HTTP Status Code
     */
    constructor(code, message, status_ = 0) {
        super(prependCode(code), `Firebase Storage: ${message} (${prependCode(code)})`);
        this.status_ = status_;
        /**
         * Stores custom error data unique to the `StorageError`.
         */
        this.customData = { serverResponse: null };
        this._baseMessage = this.message;
        // Without this, `instanceof StorageError`, in tests for example,
        // returns false.
        Object.setPrototypeOf(this, StorageError.prototype);
    }
    get status() {
        return this.status_;
    }
    set status(status) {
        this.status_ = status;
    }
    /**
     * Compares a `StorageErrorCode` against this error's code, filtering out the prefix.
     */
    _codeEquals(code) {
        return prependCode(code) === this.code;
    }
    /**
     * Optional response message that was added by the server.
     */
    get serverResponse() {
        return this.customData.serverResponse;
    }
    set serverResponse(serverResponse) {
        this.customData.serverResponse = serverResponse;
        if (this.customData.serverResponse) {
            this.message = `${this._baseMessage}\n${this.customData.serverResponse}`;
        }
        else {
            this.message = this._baseMessage;
        }
    }
}
/**
 * @public
 * Error codes that can be attached to `StorageError` objects.
 */
var StorageErrorCode;
(function (StorageErrorCode) {
    // Shared between all platforms
    StorageErrorCode["UNKNOWN"] = "unknown";
    StorageErrorCode["OBJECT_NOT_FOUND"] = "object-not-found";
    StorageErrorCode["BUCKET_NOT_FOUND"] = "bucket-not-found";
    StorageErrorCode["PROJECT_NOT_FOUND"] = "project-not-found";
    StorageErrorCode["QUOTA_EXCEEDED"] = "quota-exceeded";
    StorageErrorCode["UNAUTHENTICATED"] = "unauthenticated";
    StorageErrorCode["UNAUTHORIZED"] = "unauthorized";
    StorageErrorCode["UNAUTHORIZED_APP"] = "unauthorized-app";
    StorageErrorCode["RETRY_LIMIT_EXCEEDED"] = "retry-limit-exceeded";
    StorageErrorCode["INVALID_CHECKSUM"] = "invalid-checksum";
    StorageErrorCode["CANCELED"] = "canceled";
    // JS specific
    StorageErrorCode["INVALID_EVENT_NAME"] = "invalid-event-name";
    StorageErrorCode["INVALID_URL"] = "invalid-url";
    StorageErrorCode["INVALID_DEFAULT_BUCKET"] = "invalid-default-bucket";
    StorageErrorCode["NO_DEFAULT_BUCKET"] = "no-default-bucket";
    StorageErrorCode["CANNOT_SLICE_BLOB"] = "cannot-slice-blob";
    StorageErrorCode["SERVER_FILE_WRONG_SIZE"] = "server-file-wrong-size";
    StorageErrorCode["NO_DOWNLOAD_URL"] = "no-download-url";
    StorageErrorCode["INVALID_ARGUMENT"] = "invalid-argument";
    StorageErrorCode["INVALID_ARGUMENT_COUNT"] = "invalid-argument-count";
    StorageErrorCode["APP_DELETED"] = "app-deleted";
    StorageErrorCode["INVALID_ROOT_OPERATION"] = "invalid-root-operation";
    StorageErrorCode["INVALID_FORMAT"] = "invalid-format";
    StorageErrorCode["INTERNAL_ERROR"] = "internal-error";
    StorageErrorCode["UNSUPPORTED_ENVIRONMENT"] = "unsupported-environment";
})(StorageErrorCode || (StorageErrorCode = {}));
function prependCode(code) {
    return 'storage/' + code;
}
function unknown() {
    const message = 'An unknown error occurred, please check the error payload for ' +
        'server response.';
    return new StorageError(StorageErrorCode.UNKNOWN, message);
}
function objectNotFound(path) {
    return new StorageError(StorageErrorCode.OBJECT_NOT_FOUND, "Object '" + path + "' does not exist.");
}
function quotaExceeded(bucket) {
    return new StorageError(StorageErrorCode.QUOTA_EXCEEDED, "Quota for bucket '" +
        bucket +
        "' exceeded, please view quota on " +
        'https://firebase.google.com/pricing/.');
}
function unauthenticated() {
    const message = 'User is not authenticated, please authenticate using Firebase ' +
        'Authentication and try again.';
    return new StorageError(StorageErrorCode.UNAUTHENTICATED, message);
}
function unauthorizedApp() {
    return new StorageError(StorageErrorCode.UNAUTHORIZED_APP, 'This app does not have permission to access Firebase Storage on this project.');
}
function unauthorized(path) {
    return new StorageError(StorageErrorCode.UNAUTHORIZED, "User does not have permission to access '" + path + "'.");
}
function retryLimitExceeded() {
    return new StorageError(StorageErrorCode.RETRY_LIMIT_EXCEEDED, 'Max retry time for operation exceeded, please try again.');
}
function canceled() {
    return new StorageError(StorageErrorCode.CANCELED, 'User canceled the upload/download.');
}
function invalidUrl(url) {
    return new StorageError(StorageErrorCode.INVALID_URL, "Invalid URL '" + url + "'.");
}
function invalidDefaultBucket(bucket) {
    return new StorageError(StorageErrorCode.INVALID_DEFAULT_BUCKET, "Invalid default bucket '" + bucket + "'.");
}
function noDefaultBucket() {
    return new StorageError(StorageErrorCode.NO_DEFAULT_BUCKET, 'No default bucket ' +
        "found. Did you set the '" +
        CONFIG_STORAGE_BUCKET_KEY +
        "' property when initializing the app?");
}
function cannotSliceBlob() {
    return new StorageError(StorageErrorCode.CANNOT_SLICE_BLOB, 'Cannot slice blob for upload. Please retry the upload.');
}
function serverFileWrongSize() {
    return new StorageError(StorageErrorCode.SERVER_FILE_WRONG_SIZE, 'Server recorded incorrect upload file size, please retry the upload.');
}
function noDownloadURL() {
    return new StorageError(StorageErrorCode.NO_DOWNLOAD_URL, 'The given file does not have any download URLs.');
}
function missingPolyFill(polyFill) {
    return new StorageError(StorageErrorCode.UNSUPPORTED_ENVIRONMENT, `${polyFill} is missing. Make sure to install the required polyfills. See https://firebase.google.com/docs/web/environments-js-sdk#polyfills for more information.`);
}
/**
 * @internal
 */
function invalidArgument(message) {
    return new StorageError(StorageErrorCode.INVALID_ARGUMENT, message);
}
function appDeleted() {
    return new StorageError(StorageErrorCode.APP_DELETED, 'The Firebase app was deleted.');
}
/**
 * @param name - The name of the operation that was invalid.
 *
 * @internal
 */
function invalidRootOperation(name) {
    return new StorageError(StorageErrorCode.INVALID_ROOT_OPERATION, "The operation '" +
        name +
        "' cannot be performed on a root reference, create a non-root " +
        "reference using child, such as .child('file.png').");
}
/**
 * @param format - The format that was not valid.
 * @param message - A message describing the format violation.
 */
function invalidFormat(format, message) {
    return new StorageError(StorageErrorCode.INVALID_FORMAT, "String does not match format '" + format + "': " + message);
}
/**
 * @param message - A message describing the internal error.
 */
function internalError(message) {
    throw new StorageError(StorageErrorCode.INTERNAL_ERROR, 'Internal error: ' + message);
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @fileoverview Functionality related to the parsing/composition of bucket/
 * object location.
 */
/**
 * Firebase Storage location data.
 *
 * @internal
 */
class Location {
    constructor(bucket, path) {
        this.bucket = bucket;
        this.path_ = path;
    }
    get path() {
        return this.path_;
    }
    get isRoot() {
        return this.path.length === 0;
    }
    fullServerUrl() {
        const encode = encodeURIComponent;
        return '/b/' + encode(this.bucket) + '/o/' + encode(this.path);
    }
    bucketOnlyServerUrl() {
        const encode = encodeURIComponent;
        return '/b/' + encode(this.bucket) + '/o';
    }
    static makeFromBucketSpec(bucketString, host) {
        let bucketLocation;
        try {
            bucketLocation = Location.makeFromUrl(bucketString, host);
        }
        catch (e) {
            // Not valid URL, use as-is. This lets you put bare bucket names in
            // config.
            return new Location(bucketString, '');
        }
        if (bucketLocation.path === '') {
            return bucketLocation;
        }
        else {
            throw invalidDefaultBucket(bucketString);
        }
    }
    static makeFromUrl(url, host) {
        let location = null;
        const bucketDomain = '([A-Za-z0-9.\\-_]+)';
        function gsModify(loc) {
            if (loc.path.charAt(loc.path.length - 1) === '/') {
                loc.path_ = loc.path_.slice(0, -1);
            }
        }
        const gsPath = '(/(.*))?$';
        const gsRegex = new RegExp('^gs://' + bucketDomain + gsPath, 'i');
        const gsIndices = { bucket: 1, path: 3 };
        function httpModify(loc) {
            loc.path_ = decodeURIComponent(loc.path);
        }
        const version = 'v[A-Za-z0-9_]+';
        const firebaseStorageHost = host.replace(/[.]/g, '\\.');
        const firebaseStoragePath = '(/([^?#]*).*)?$';
        const firebaseStorageRegExp = new RegExp(`^https?://${firebaseStorageHost}/${version}/b/${bucketDomain}/o${firebaseStoragePath}`, 'i');
        const firebaseStorageIndices = { bucket: 1, path: 3 };
        const cloudStorageHost = host === DEFAULT_HOST
            ? '(?:storage.googleapis.com|storage.cloud.google.com)'
            : host;
        const cloudStoragePath = '([^?#]*)';
        const cloudStorageRegExp = new RegExp(`^https?://${cloudStorageHost}/${bucketDomain}/${cloudStoragePath}`, 'i');
        const cloudStorageIndices = { bucket: 1, path: 2 };
        const groups = [
            { regex: gsRegex, indices: gsIndices, postModify: gsModify },
            {
                regex: firebaseStorageRegExp,
                indices: firebaseStorageIndices,
                postModify: httpModify
            },
            {
                regex: cloudStorageRegExp,
                indices: cloudStorageIndices,
                postModify: httpModify
            }
        ];
        for (let i = 0; i < groups.length; i++) {
            const group = groups[i];
            const captures = group.regex.exec(url);
            if (captures) {
                const bucketValue = captures[group.indices.bucket];
                let pathValue = captures[group.indices.path];
                if (!pathValue) {
                    pathValue = '';
                }
                location = new Location(bucketValue, pathValue);
                group.postModify(location);
                break;
            }
        }
        if (location == null) {
            throw invalidUrl(url);
        }
        return location;
    }
}

/**
 * A request whose promise always fails.
 */
class FailRequest {
    constructor(error) {
        this.promise_ = Promise.reject(error);
    }
    /** @inheritDoc */
    getPromise() {
        return this.promise_;
    }
    /** @inheritDoc */
    cancel(_appDelete = false) { }
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Accepts a callback for an action to perform (`doRequest`),
 * and then a callback for when the backoff has completed (`backoffCompleteCb`).
 * The callback sent to start requires an argument to call (`onRequestComplete`).
 * When `start` calls `doRequest`, it passes a callback for when the request has
 * completed, `onRequestComplete`. Based on this, the backoff continues, with
 * another call to `doRequest` and the above loop continues until the timeout
 * is hit, or a successful response occurs.
 * @description
 * @param doRequest Callback to perform request
 * @param backoffCompleteCb Callback to call when backoff has been completed
 */
function start(doRequest, 
// eslint-disable-next-line @typescript-eslint/no-explicit-any
backoffCompleteCb, timeout) {
    // TODO(andysoto): make this code cleaner (probably refactor into an actual
    // type instead of a bunch of functions with state shared in the closure)
    let waitSeconds = 1;
    // Would type this as "number" but that doesn't work for Node so ¯\_(ツ)_/¯
    // TODO: find a way to exclude Node type definition for storage because storage only works in browser
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let retryTimeoutId = null;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let globalTimeoutId = null;
    let hitTimeout = false;
    let cancelState = 0;
    function canceled() {
        return cancelState === 2;
    }
    let triggeredCallback = false;
    function triggerCallback(...args) {
        if (!triggeredCallback) {
            triggeredCallback = true;
            backoffCompleteCb.apply(null, args);
        }
    }
    function callWithDelay(millis) {
        retryTimeoutId = setTimeout(() => {
            retryTimeoutId = null;
            doRequest(responseHandler, canceled());
        }, millis);
    }
    function clearGlobalTimeout() {
        if (globalTimeoutId) {
            clearTimeout(globalTimeoutId);
        }
    }
    function responseHandler(success, ...args) {
        if (triggeredCallback) {
            clearGlobalTimeout();
            return;
        }
        if (success) {
            clearGlobalTimeout();
            triggerCallback.call(null, success, ...args);
            return;
        }
        const mustStop = canceled() || hitTimeout;
        if (mustStop) {
            clearGlobalTimeout();
            triggerCallback.call(null, success, ...args);
            return;
        }
        if (waitSeconds < 64) {
            /* TODO(andysoto): don't back off so quickly if we know we're offline. */
            waitSeconds *= 2;
        }
        let waitMillis;
        if (cancelState === 1) {
            cancelState = 2;
            waitMillis = 0;
        }
        else {
            waitMillis = (waitSeconds + Math.random()) * 1000;
        }
        callWithDelay(waitMillis);
    }
    let stopped = false;
    function stop(wasTimeout) {
        if (stopped) {
            return;
        }
        stopped = true;
        clearGlobalTimeout();
        if (triggeredCallback) {
            return;
        }
        if (retryTimeoutId !== null) {
            if (!wasTimeout) {
                cancelState = 2;
            }
            clearTimeout(retryTimeoutId);
            callWithDelay(0);
        }
        else {
            if (!wasTimeout) {
                cancelState = 1;
            }
        }
    }
    callWithDelay(0);
    globalTimeoutId = setTimeout(() => {
        hitTimeout = true;
        stop(true);
    }, timeout);
    return stop;
}
/**
 * Stops the retry loop from repeating.
 * If the function is currently "in between" retries, it is invoked immediately
 * with the second parameter as "true". Otherwise, it will be invoked once more
 * after the current invocation finishes iff the current invocation would have
 * triggered another retry.
 */
function stop(id) {
    id(false);
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function isJustDef(p) {
    return p !== void 0;
}
// eslint-disable-next-line @typescript-eslint/ban-types
function isFunction(p) {
    return typeof p === 'function';
}
function isNonArrayObject(p) {
    return typeof p === 'object' && !Array.isArray(p);
}
function isString(p) {
    return typeof p === 'string' || p instanceof String;
}
function isNativeBlob(p) {
    return isNativeBlobDefined() && p instanceof Blob;
}
function isNativeBlobDefined() {
    return typeof Blob !== 'undefined';
}
function validateNumber(argument, minValue, maxValue, value) {
    if (value < minValue) {
        throw invalidArgument(`Invalid value for '${argument}'. Expected ${minValue} or greater.`);
    }
    if (value > maxValue) {
        throw invalidArgument(`Invalid value for '${argument}'. Expected ${maxValue} or less.`);
    }
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function makeUrl(urlPart, host, protocol) {
    let origin = host;
    if (protocol == null) {
        origin = `https://${host}`;
    }
    return `${protocol}://${origin}/v0${urlPart}`;
}
function makeQueryString(params) {
    const encode = encodeURIComponent;
    let queryPart = '?';
    for (const key in params) {
        if (params.hasOwnProperty(key)) {
            const nextPart = encode(key) + '=' + encode(params[key]);
            queryPart = queryPart + nextPart + '&';
        }
    }
    // Chop off the extra '&' or '?' on the end
    queryPart = queryPart.slice(0, -1);
    return queryPart;
}

/**
 * Error codes for requests made by the XhrIo wrapper.
 */
var ErrorCode;
(function (ErrorCode) {
    ErrorCode[ErrorCode["NO_ERROR"] = 0] = "NO_ERROR";
    ErrorCode[ErrorCode["NETWORK_ERROR"] = 1] = "NETWORK_ERROR";
    ErrorCode[ErrorCode["ABORT"] = 2] = "ABORT";
})(ErrorCode || (ErrorCode = {}));

/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Checks the status code to see if the action should be retried.
 *
 * @param status Current HTTP status code returned by server.
 * @param additionalRetryCodes additional retry codes to check against
 */
function isRetryStatusCode(status, additionalRetryCodes) {
    // The codes for which to retry came from this page:
    // https://cloud.google.com/storage/docs/exponential-backoff
    const isFiveHundredCode = status >= 500 && status < 600;
    const extraRetryCodes = [
        // Request Timeout: web server didn't receive full request in time.
        408,
        // Too Many Requests: you're getting rate-limited, basically.
        429
    ];
    const isExtraRetryCode = extraRetryCodes.indexOf(status) !== -1;
    const isAdditionalRetryCode = additionalRetryCodes.indexOf(status) !== -1;
    return isFiveHundredCode || isExtraRetryCode || isAdditionalRetryCode;
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @fileoverview Defines methods used to actually send HTTP requests from
 * abstract representations.
 */
/**
 * Handles network logic for all Storage Requests, including error reporting and
 * retries with backoff.
 *
 * @param I - the type of the backend's network response.
 * @param - O the output type used by the rest of the SDK. The conversion
 * happens in the specified `callback_`.
 */
class NetworkRequest {
    constructor(url_, method_, headers_, body_, successCodes_, additionalRetryCodes_, callback_, errorCallback_, timeout_, progressCallback_, connectionFactory_, retry = true, isUsingEmulator = false) {
        this.url_ = url_;
        this.method_ = method_;
        this.headers_ = headers_;
        this.body_ = body_;
        this.successCodes_ = successCodes_;
        this.additionalRetryCodes_ = additionalRetryCodes_;
        this.callback_ = callback_;
        this.errorCallback_ = errorCallback_;
        this.timeout_ = timeout_;
        this.progressCallback_ = progressCallback_;
        this.connectionFactory_ = connectionFactory_;
        this.retry = retry;
        this.isUsingEmulator = isUsingEmulator;
        this.pendingConnection_ = null;
        this.backoffId_ = null;
        this.canceled_ = false;
        this.appDelete_ = false;
        this.promise_ = new Promise((resolve, reject) => {
            this.resolve_ = resolve;
            this.reject_ = reject;
            this.start_();
        });
    }
    /**
     * Actually starts the retry loop.
     */
    start_() {
        const doTheRequest = (backoffCallback, canceled) => {
            if (canceled) {
                backoffCallback(false, new RequestEndStatus(false, null, true));
                return;
            }
            const connection = this.connectionFactory_();
            this.pendingConnection_ = connection;
            const progressListener = progressEvent => {
                const loaded = progressEvent.loaded;
                const total = progressEvent.lengthComputable ? progressEvent.total : -1;
                if (this.progressCallback_ !== null) {
                    this.progressCallback_(loaded, total);
                }
            };
            if (this.progressCallback_ !== null) {
                connection.addUploadProgressListener(progressListener);
            }
            // connection.send() never rejects, so we don't need to have a error handler or use catch on the returned promise.
            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            connection
                .send(this.url_, this.method_, this.isUsingEmulator, this.body_, this.headers_)
                .then(() => {
                if (this.progressCallback_ !== null) {
                    connection.removeUploadProgressListener(progressListener);
                }
                this.pendingConnection_ = null;
                const hitServer = connection.getErrorCode() === ErrorCode.NO_ERROR;
                const status = connection.getStatus();
                if (!hitServer ||
                    (isRetryStatusCode(status, this.additionalRetryCodes_) &&
                        this.retry)) {
                    const wasCanceled = connection.getErrorCode() === ErrorCode.ABORT;
                    backoffCallback(false, new RequestEndStatus(false, null, wasCanceled));
                    return;
                }
                const successCode = this.successCodes_.indexOf(status) !== -1;
                backoffCallback(true, new RequestEndStatus(successCode, connection));
            });
        };
        /**
         * @param requestWentThrough - True if the request eventually went
         *     through, false if it hit the retry limit or was canceled.
         */
        const backoffDone = (requestWentThrough, status) => {
            const resolve = this.resolve_;
            const reject = this.reject_;
            const connection = status.connection;
            if (status.wasSuccessCode) {
                try {
                    const result = this.callback_(connection, connection.getResponse());
                    if (isJustDef(result)) {
                        resolve(result);
                    }
                    else {
                        resolve();
                    }
                }
                catch (e) {
                    reject(e);
                }
            }
            else {
                if (connection !== null) {
                    const err = unknown();
                    err.serverResponse = connection.getErrorText();
                    if (this.errorCallback_) {
                        reject(this.errorCallback_(connection, err));
                    }
                    else {
                        reject(err);
                    }
                }
                else {
                    if (status.canceled) {
                        const err = this.appDelete_ ? appDeleted() : canceled();
                        reject(err);
                    }
                    else {
                        const err = retryLimitExceeded();
                        reject(err);
                    }
                }
            }
        };
        if (this.canceled_) {
            backoffDone(false, new RequestEndStatus(false, null, true));
        }
        else {
            this.backoffId_ = start(doTheRequest, backoffDone, this.timeout_);
        }
    }
    /** @inheritDoc */
    getPromise() {
        return this.promise_;
    }
    /** @inheritDoc */
    cancel(appDelete) {
        this.canceled_ = true;
        this.appDelete_ = appDelete || false;
        if (this.backoffId_ !== null) {
            stop(this.backoffId_);
        }
        if (this.pendingConnection_ !== null) {
            this.pendingConnection_.abort();
        }
    }
}
/**
 * A collection of information about the result of a network request.
 * @param opt_canceled - Defaults to false.
 */
class RequestEndStatus {
    constructor(wasSuccessCode, connection, canceled) {
        this.wasSuccessCode = wasSuccessCode;
        this.connection = connection;
        this.canceled = !!canceled;
    }
}
function addAuthHeader_(headers, authToken) {
    if (authToken !== null && authToken.length > 0) {
        headers['Authorization'] = 'Firebase ' + authToken;
    }
}
function addVersionHeader_(headers, firebaseVersion) {
    headers['X-Firebase-Storage-Version'] =
        'webjs/' + (firebaseVersion ?? 'AppManager');
}
function addGmpidHeader_(headers, appId) {
    if (appId) {
        headers['X-Firebase-GMPID'] = appId;
    }
}
function addAppCheckHeader_(headers, appCheckToken) {
    if (appCheckToken !== null) {
        headers['X-Firebase-AppCheck'] = appCheckToken;
    }
}
function makeRequest(requestInfo, appId, authToken, appCheckToken, requestFactory, firebaseVersion, retry = true, isUsingEmulator = false) {
    const queryPart = makeQueryString(requestInfo.urlParams);
    const url = requestInfo.url + queryPart;
    const headers = Object.assign({}, requestInfo.headers);
    addGmpidHeader_(headers, appId);
    addAuthHeader_(headers, authToken);
    addVersionHeader_(headers, firebaseVersion);
    addAppCheckHeader_(headers, appCheckToken);
    return new NetworkRequest(url, requestInfo.method, headers, requestInfo.body, requestInfo.successCodes, requestInfo.additionalRetryCodes, requestInfo.handler, requestInfo.errorHandler, requestInfo.timeout, requestInfo.progressCallback, requestFactory, retry, isUsingEmulator);
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @fileoverview Some methods copied from goog.fs.
 * We don't include goog.fs because it pulls in a bunch of Deferred code that
 * bloats the size of the released binary.
 */
function getBlobBuilder() {
    if (typeof BlobBuilder !== 'undefined') {
        return BlobBuilder;
    }
    else if (typeof WebKitBlobBuilder !== 'undefined') {
        return WebKitBlobBuilder;
    }
    else {
        return undefined;
    }
}
/**
 * Concatenates one or more values together and converts them to a Blob.
 *
 * @param args The values that will make up the resulting blob.
 * @return The blob.
 */
function getBlob$1(...args) {
    const BlobBuilder = getBlobBuilder();
    if (BlobBuilder !== undefined) {
        const bb = new BlobBuilder();
        for (let i = 0; i < args.length; i++) {
            bb.append(args[i]);
        }
        return bb.getBlob();
    }
    else {
        if (isNativeBlobDefined()) {
            return new Blob(args);
        }
        else {
            throw new StorageError(StorageErrorCode.UNSUPPORTED_ENVIRONMENT, "This browser doesn't seem to support creating Blobs");
        }
    }
}
/**
 * Slices the blob. The returned blob contains data from the start byte
 * (inclusive) till the end byte (exclusive). Negative indices cannot be used.
 *
 * @param blob The blob to be sliced.
 * @param start Index of the starting byte.
 * @param end Index of the ending byte.
 * @return The blob slice or null if not supported.
 */
function sliceBlob(blob, start, end) {
    if (blob.webkitSlice) {
        return blob.webkitSlice(start, end);
    }
    else if (blob.mozSlice) {
        return blob.mozSlice(start, end);
    }
    else if (blob.slice) {
        return blob.slice(start, end);
    }
    return null;
}

/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/** Converts a Base64 encoded string to a binary string. */
function decodeBase64(encoded) {
    if (typeof atob === 'undefined') {
        throw missingPolyFill('base-64');
    }
    return atob(encoded);
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * An enumeration of the possible string formats for upload.
 * @public
 */
const StringFormat = {
    /**
     * Indicates the string should be interpreted "raw", that is, as normal text.
     * The string will be interpreted as UTF-16, then uploaded as a UTF-8 byte
     * sequence.
     * Example: The string 'Hello! \\ud83d\\ude0a' becomes the byte sequence
     * 48 65 6c 6c 6f 21 20 f0 9f 98 8a
     */
    RAW: 'raw',
    /**
     * Indicates the string should be interpreted as base64-encoded data.
     * Padding characters (trailing '='s) are optional.
     * Example: The string 'rWmO++E6t7/rlw==' becomes the byte sequence
     * ad 69 8e fb e1 3a b7 bf eb 97
     */
    BASE64: 'base64',
    /**
     * Indicates the string should be interpreted as base64url-encoded data.
     * Padding characters (trailing '='s) are optional.
     * Example: The string 'rWmO--E6t7_rlw==' becomes the byte sequence
     * ad 69 8e fb e1 3a b7 bf eb 97
     */
    BASE64URL: 'base64url',
    /**
     * Indicates the string is a data URL, such as one obtained from
     * canvas.toDataURL().
     * Example: the string 'data:application/octet-stream;base64,aaaa'
     * becomes the byte sequence
     * 69 a6 9a
     * (the content-type "application/octet-stream" is also applied, but can
     * be overridden in the metadata object).
     */
    DATA_URL: 'data_url'
};
class StringData {
    constructor(data, contentType) {
        this.data = data;
        this.contentType = contentType || null;
    }
}
/**
 * @internal
 */
function dataFromString(format, stringData) {
    switch (format) {
        case StringFormat.RAW:
            return new StringData(utf8Bytes_(stringData));
        case StringFormat.BASE64:
        case StringFormat.BASE64URL:
            return new StringData(base64Bytes_(format, stringData));
        case StringFormat.DATA_URL:
            return new StringData(dataURLBytes_(stringData), dataURLContentType_(stringData));
        // do nothing
    }
    // assert(false);
    throw unknown();
}
function utf8Bytes_(value) {
    const b = [];
    for (let i = 0; i < value.length; i++) {
        let c = value.charCodeAt(i);
        if (c <= 127) {
            b.push(c);
        }
        else {
            if (c <= 2047) {
                b.push(192 | (c >> 6), 128 | (c & 63));
            }
            else {
                if ((c & 64512) === 55296) {
                    // The start of a surrogate pair.
                    const valid = i < value.length - 1 && (value.charCodeAt(i + 1) & 64512) === 56320;
                    if (!valid) {
                        // The second surrogate wasn't there.
                        b.push(239, 191, 189);
                    }
                    else {
                        const hi = c;
                        const lo = value.charCodeAt(++i);
                        c = 65536 | ((hi & 1023) << 10) | (lo & 1023);
                        b.push(240 | (c >> 18), 128 | ((c >> 12) & 63), 128 | ((c >> 6) & 63), 128 | (c & 63));
                    }
                }
                else {
                    if ((c & 64512) === 56320) {
                        // Invalid low surrogate.
                        b.push(239, 191, 189);
                    }
                    else {
                        b.push(224 | (c >> 12), 128 | ((c >> 6) & 63), 128 | (c & 63));
                    }
                }
            }
        }
    }
    return new Uint8Array(b);
}
function percentEncodedBytes_(value) {
    let decoded;
    try {
        decoded = decodeURIComponent(value);
    }
    catch (e) {
        throw invalidFormat(StringFormat.DATA_URL, 'Malformed data URL.');
    }
    return utf8Bytes_(decoded);
}
function base64Bytes_(format, value) {
    switch (format) {
        case StringFormat.BASE64: {
            const hasMinus = value.indexOf('-') !== -1;
            const hasUnder = value.indexOf('_') !== -1;
            if (hasMinus || hasUnder) {
                const invalidChar = hasMinus ? '-' : '_';
                throw invalidFormat(format, "Invalid character '" +
                    invalidChar +
                    "' found: is it base64url encoded?");
            }
            break;
        }
        case StringFormat.BASE64URL: {
            const hasPlus = value.indexOf('+') !== -1;
            const hasSlash = value.indexOf('/') !== -1;
            if (hasPlus || hasSlash) {
                const invalidChar = hasPlus ? '+' : '/';
                throw invalidFormat(format, "Invalid character '" + invalidChar + "' found: is it base64 encoded?");
            }
            value = value.replace(/-/g, '+').replace(/_/g, '/');
            break;
        }
        // do nothing
    }
    let bytes;
    try {
        bytes = decodeBase64(value);
    }
    catch (e) {
        if (e.message.includes('polyfill')) {
            throw e;
        }
        throw invalidFormat(format, 'Invalid character found');
    }
    const array = new Uint8Array(bytes.length);
    for (let i = 0; i < bytes.length; i++) {
        array[i] = bytes.charCodeAt(i);
    }
    return array;
}
class DataURLParts {
    constructor(dataURL) {
        this.base64 = false;
        this.contentType = null;
        const matches = dataURL.match(/^data:([^,]+)?,/);
        if (matches === null) {
            throw invalidFormat(StringFormat.DATA_URL, "Must be formatted 'data:[<mediatype>][;base64],<data>");
        }
        const middle = matches[1] || null;
        if (middle != null) {
            this.base64 = endsWith(middle, ';base64');
            this.contentType = this.base64
                ? middle.substring(0, middle.length - ';base64'.length)
                : middle;
        }
        this.rest = dataURL.substring(dataURL.indexOf(',') + 1);
    }
}
function dataURLBytes_(dataUrl) {
    const parts = new DataURLParts(dataUrl);
    if (parts.base64) {
        return base64Bytes_(StringFormat.BASE64, parts.rest);
    }
    else {
        return percentEncodedBytes_(parts.rest);
    }
}
function dataURLContentType_(dataUrl) {
    const parts = new DataURLParts(dataUrl);
    return parts.contentType;
}
function endsWith(s, end) {
    const longEnough = s.length >= end.length;
    if (!longEnough) {
        return false;
    }
    return s.substring(s.length - end.length) === end;
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @file Provides a Blob-like wrapper for various binary types (including the
 * native Blob type). This makes it possible to upload types like ArrayBuffers,
 * making uploads possible in environments without the native Blob type.
 */
/**
 * @param opt_elideCopy - If true, doesn't copy mutable input data
 *     (e.g. Uint8Arrays). Pass true only if you know the objects will not be
 *     modified after this blob's construction.
 *
 * @internal
 */
class FbsBlob {
    constructor(data, elideCopy) {
        let size = 0;
        let blobType = '';
        if (isNativeBlob(data)) {
            this.data_ = data;
            size = data.size;
            blobType = data.type;
        }
        else if (data instanceof ArrayBuffer) {
            if (elideCopy) {
                this.data_ = new Uint8Array(data);
            }
            else {
                this.data_ = new Uint8Array(data.byteLength);
                this.data_.set(new Uint8Array(data));
            }
            size = this.data_.length;
        }
        else if (data instanceof Uint8Array) {
            if (elideCopy) {
                this.data_ = data;
            }
            else {
                this.data_ = new Uint8Array(data.length);
                this.data_.set(data);
            }
            size = data.length;
        }
        this.size_ = size;
        this.type_ = blobType;
    }
    size() {
        return this.size_;
    }
    type() {
        return this.type_;
    }
    slice(startByte, endByte) {
        if (isNativeBlob(this.data_)) {
            const realBlob = this.data_;
            const sliced = sliceBlob(realBlob, startByte, endByte);
            if (sliced === null) {
                return null;
            }
            return new FbsBlob(sliced);
        }
        else {
            const slice = new Uint8Array(this.data_.buffer, startByte, endByte - startByte);
            return new FbsBlob(slice, true);
        }
    }
    static getBlob(...args) {
        if (isNativeBlobDefined()) {
            const blobby = args.map((val) => {
                if (val instanceof FbsBlob) {
                    return val.data_;
                }
                else {
                    return val;
                }
            });
            return new FbsBlob(getBlob$1.apply(null, blobby));
        }
        else {
            const uint8Arrays = args.map((val) => {
                if (isString(val)) {
                    return dataFromString(StringFormat.RAW, val).data;
                }
                else {
                    // Blobs don't exist, so this has to be a Uint8Array.
                    return val.data_;
                }
            });
            let finalLength = 0;
            uint8Arrays.forEach((array) => {
                finalLength += array.byteLength;
            });
            const merged = new Uint8Array(finalLength);
            let index = 0;
            uint8Arrays.forEach((array) => {
                for (let i = 0; i < array.length; i++) {
                    merged[index++] = array[i];
                }
            });
            return new FbsBlob(merged, true);
        }
    }
    uploadData() {
        return this.data_;
    }
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Returns the Object resulting from parsing the given JSON, or null if the
 * given string does not represent a JSON object.
 */
function jsonObjectOrNull(s) {
    let obj;
    try {
        obj = JSON.parse(s);
    }
    catch (e) {
        return null;
    }
    if (isNonArrayObject(obj)) {
        return obj;
    }
    else {
        return null;
    }
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @fileoverview Contains helper methods for manipulating paths.
 */
/**
 * @return Null if the path is already at the root.
 */
function parent(path) {
    if (path.length === 0) {
        return null;
    }
    const index = path.lastIndexOf('/');
    if (index === -1) {
        return '';
    }
    const newPath = path.slice(0, index);
    return newPath;
}
function child(path, childPath) {
    const canonicalChildPath = childPath
        .split('/')
        .filter(component => component.length > 0)
        .join('/');
    if (path.length === 0) {
        return canonicalChildPath;
    }
    else {
        return path + '/' + canonicalChildPath;
    }
}
/**
 * Returns the last component of a path.
 * '/foo/bar' -> 'bar'
 * '/foo/bar/baz/' -> 'baz/'
 * '/a' -> 'a'
 */
function lastComponent(path) {
    const index = path.lastIndexOf('/', path.length - 2);
    if (index === -1) {
        return path;
    }
    else {
        return path.slice(index + 1);
    }
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function noXform_(metadata, value) {
    return value;
}
class Mapping {
    constructor(server, local, writable, xform) {
        this.server = server;
        this.local = local || server;
        this.writable = !!writable;
        this.xform = xform || noXform_;
    }
}
let mappings_ = null;
function xformPath(fullPath) {
    if (!isString(fullPath) || fullPath.length < 2) {
        return fullPath;
    }
    else {
        return lastComponent(fullPath);
    }
}
function getMappings() {
    if (mappings_) {
        return mappings_;
    }
    const mappings = [];
    mappings.push(new Mapping('bucket'));
    mappings.push(new Mapping('generation'));
    mappings.push(new Mapping('metageneration'));
    mappings.push(new Mapping('name', 'fullPath', true));
    function mappingsXformPath(_metadata, fullPath) {
        return xformPath(fullPath);
    }
    const nameMapping = new Mapping('name');
    nameMapping.xform = mappingsXformPath;
    mappings.push(nameMapping);
    /**
     * Coerces the second param to a number, if it is defined.
     */
    function xformSize(_metadata, size) {
        if (size !== undefined) {
            return Number(size);
        }
        else {
            return size;
        }
    }
    const sizeMapping = new Mapping('size');
    sizeMapping.xform = xformSize;
    mappings.push(sizeMapping);
    mappings.push(new Mapping('timeCreated'));
    mappings.push(new Mapping('updated'));
    mappings.push(new Mapping('md5Hash', null, true));
    mappings.push(new Mapping('cacheControl', null, true));
    mappings.push(new Mapping('contentDisposition', null, true));
    mappings.push(new Mapping('contentEncoding', null, true));
    mappings.push(new Mapping('contentLanguage', null, true));
    mappings.push(new Mapping('contentType', null, true));
    mappings.push(new Mapping('metadata', 'customMetadata', true));
    mappings_ = mappings;
    return mappings_;
}
function addRef(metadata, service) {
    function generateRef() {
        const bucket = metadata['bucket'];
        const path = metadata['fullPath'];
        const loc = new Location(bucket, path);
        return service._makeStorageReference(loc);
    }
    Object.defineProperty(metadata, 'ref', { get: generateRef });
}
function fromResource(service, resource, mappings) {
    const metadata = {};
    metadata['type'] = 'file';
    const len = mappings.length;
    for (let i = 0; i < len; i++) {
        const mapping = mappings[i];
        metadata[mapping.local] = mapping.xform(metadata, resource[mapping.server]);
    }
    addRef(metadata, service);
    return metadata;
}
function fromResourceString(service, resourceString, mappings) {
    const obj = jsonObjectOrNull(resourceString);
    if (obj === null) {
        return null;
    }
    const resource = obj;
    return fromResource(service, resource, mappings);
}
function downloadUrlFromResourceString(metadata, resourceString, host, protocol) {
    const obj = jsonObjectOrNull(resourceString);
    if (obj === null) {
        return null;
    }
    if (!isString(obj['downloadTokens'])) {
        // This can happen if objects are uploaded through GCS and retrieved
        // through list, so we don't want to throw an Error.
        return null;
    }
    const tokens = obj['downloadTokens'];
    if (tokens.length === 0) {
        return null;
    }
    const encode = encodeURIComponent;
    const tokensList = tokens.split(',');
    const urls = tokensList.map((token) => {
        const bucket = metadata['bucket'];
        const path = metadata['fullPath'];
        const urlPart = '/b/' + encode(bucket) + '/o/' + encode(path);
        const base = makeUrl(urlPart, host, protocol);
        const queryString = makeQueryString({
            alt: 'media',
            token
        });
        return base + queryString;
    });
    return urls[0];
}
function toResourceString(metadata, mappings) {
    const resource = {};
    const len = mappings.length;
    for (let i = 0; i < len; i++) {
        const mapping = mappings[i];
        if (mapping.writable) {
            resource[mapping.server] = metadata[mapping.local];
        }
    }
    return JSON.stringify(resource);
}

/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @fileoverview Documentation for the listOptions and listResult format
 */
const PREFIXES_KEY = 'prefixes';
const ITEMS_KEY = 'items';
function fromBackendResponse(service, bucket, resource) {
    const listResult = {
        prefixes: [],
        items: [],
        nextPageToken: resource['nextPageToken']
    };
    if (resource[PREFIXES_KEY]) {
        for (const path of resource[PREFIXES_KEY]) {
            const pathWithoutTrailingSlash = path.replace(/\/$/, '');
            const reference = service._makeStorageReference(new Location(bucket, pathWithoutTrailingSlash));
            listResult.prefixes.push(reference);
        }
    }
    if (resource[ITEMS_KEY]) {
        for (const item of resource[ITEMS_KEY]) {
            const reference = service._makeStorageReference(new Location(bucket, item['name']));
            listResult.items.push(reference);
        }
    }
    return listResult;
}
function fromResponseString(service, bucket, resourceString) {
    const obj = jsonObjectOrNull(resourceString);
    if (obj === null) {
        return null;
    }
    const resource = obj;
    return fromBackendResponse(service, bucket, resource);
}

/**
 * Contains a fully specified request.
 *
 * @param I - the type of the backend's network response.
 * @param O - the output response type used by the rest of the SDK.
 */
class RequestInfo {
    constructor(url, method, 
    /**
     * Returns the value with which to resolve the request's promise. Only called
     * if the request is successful. Throw from this function to reject the
     * returned Request's promise with the thrown error.
     * Note: The XhrIo passed to this function may be reused after this callback
     * returns. Do not keep a reference to it in any way.
     */
    handler, timeout) {
        this.url = url;
        this.method = method;
        this.handler = handler;
        this.timeout = timeout;
        this.urlParams = {};
        this.headers = {};
        this.body = null;
        this.errorHandler = null;
        /**
         * Called with the current number of bytes uploaded and total size (-1 if not
         * computable) of the request body (i.e. used to report upload progress).
         */
        this.progressCallback = null;
        this.successCodes = [200];
        this.additionalRetryCodes = [];
    }
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Throws the UNKNOWN StorageError if cndn is false.
 */
function handlerCheck(cndn) {
    if (!cndn) {
        throw unknown();
    }
}
function metadataHandler(service, mappings) {
    function handler(xhr, text) {
        const metadata = fromResourceString(service, text, mappings);
        handlerCheck(metadata !== null);
        return metadata;
    }
    return handler;
}
function listHandler(service, bucket) {
    function handler(xhr, text) {
        const listResult = fromResponseString(service, bucket, text);
        handlerCheck(listResult !== null);
        return listResult;
    }
    return handler;
}
function downloadUrlHandler(service, mappings) {
    function handler(xhr, text) {
        const metadata = fromResourceString(service, text, mappings);
        handlerCheck(metadata !== null);
        return downloadUrlFromResourceString(metadata, text, service.host, service._protocol);
    }
    return handler;
}
function sharedErrorHandler(location) {
    function errorHandler(xhr, err) {
        let newErr;
        if (xhr.getStatus() === 401) {
            if (
            // This exact message string is the only consistent part of the
            // server's error response that identifies it as an App Check error.
            xhr.getErrorText().includes('Firebase App Check token is invalid')) {
                newErr = unauthorizedApp();
            }
            else {
                newErr = unauthenticated();
            }
        }
        else {
            if (xhr.getStatus() === 402) {
                newErr = quotaExceeded(location.bucket);
            }
            else {
                if (xhr.getStatus() === 403) {
                    newErr = unauthorized(location.path);
                }
                else {
                    newErr = err;
                }
            }
        }
        newErr.status = xhr.getStatus();
        newErr.serverResponse = err.serverResponse;
        return newErr;
    }
    return errorHandler;
}
function objectErrorHandler(location) {
    const shared = sharedErrorHandler(location);
    function errorHandler(xhr, err) {
        let newErr = shared(xhr, err);
        if (xhr.getStatus() === 404) {
            newErr = objectNotFound(location.path);
        }
        newErr.serverResponse = err.serverResponse;
        return newErr;
    }
    return errorHandler;
}
function getMetadata$2(service, location, mappings) {
    const urlPart = location.fullServerUrl();
    const url = makeUrl(urlPart, service.host, service._protocol);
    const method = 'GET';
    const timeout = service.maxOperationRetryTime;
    const requestInfo = new RequestInfo(url, method, metadataHandler(service, mappings), timeout);
    requestInfo.errorHandler = objectErrorHandler(location);
    return requestInfo;
}
function list$2(service, location, delimiter, pageToken, maxResults) {
    const urlParams = {};
    if (location.isRoot) {
        urlParams['prefix'] = '';
    }
    else {
        urlParams['prefix'] = location.path + '/';
    }
    if (delimiter.length > 0) {
        urlParams['delimiter'] = delimiter;
    }
    if (pageToken) {
        urlParams['pageToken'] = pageToken;
    }
    if (maxResults) {
        urlParams['maxResults'] = maxResults;
    }
    const urlPart = location.bucketOnlyServerUrl();
    const url = makeUrl(urlPart, service.host, service._protocol);
    const method = 'GET';
    const timeout = service.maxOperationRetryTime;
    const requestInfo = new RequestInfo(url, method, listHandler(service, location.bucket), timeout);
    requestInfo.urlParams = urlParams;
    requestInfo.errorHandler = sharedErrorHandler(location);
    return requestInfo;
}
function getBytes$1(service, location, maxDownloadSizeBytes) {
    const urlPart = location.fullServerUrl();
    const url = makeUrl(urlPart, service.host, service._protocol) + '?alt=media';
    const method = 'GET';
    const timeout = service.maxOperationRetryTime;
    const requestInfo = new RequestInfo(url, method, (_, data) => data, timeout);
    requestInfo.errorHandler = objectErrorHandler(location);
    if (maxDownloadSizeBytes !== undefined) {
        requestInfo.headers['Range'] = `bytes=0-${maxDownloadSizeBytes}`;
        requestInfo.successCodes = [200 /* OK */, 206 /* Partial Content */];
    }
    return requestInfo;
}
function getDownloadUrl(service, location, mappings) {
    const urlPart = location.fullServerUrl();
    const url = makeUrl(urlPart, service.host, service._protocol);
    const method = 'GET';
    const timeout = service.maxOperationRetryTime;
    const requestInfo = new RequestInfo(url, method, downloadUrlHandler(service, mappings), timeout);
    requestInfo.errorHandler = objectErrorHandler(location);
    return requestInfo;
}
function updateMetadata$2(service, location, metadata, mappings) {
    const urlPart = location.fullServerUrl();
    const url = makeUrl(urlPart, service.host, service._protocol);
    const method = 'PATCH';
    const body = toResourceString(metadata, mappings);
    const headers = { 'Content-Type': 'application/json; charset=utf-8' };
    const timeout = service.maxOperationRetryTime;
    const requestInfo = new RequestInfo(url, method, metadataHandler(service, mappings), timeout);
    requestInfo.headers = headers;
    requestInfo.body = body;
    requestInfo.errorHandler = objectErrorHandler(location);
    return requestInfo;
}
function deleteObject$2(service, location) {
    const urlPart = location.fullServerUrl();
    const url = makeUrl(urlPart, service.host, service._protocol);
    const method = 'DELETE';
    const timeout = service.maxOperationRetryTime;
    function handler(_xhr, _text) { }
    const requestInfo = new RequestInfo(url, method, handler, timeout);
    requestInfo.successCodes = [200, 204];
    requestInfo.errorHandler = objectErrorHandler(location);
    return requestInfo;
}
function determineContentType_(metadata, blob) {
    return ((metadata && metadata['contentType']) ||
        (blob && blob.type()) ||
        'application/octet-stream');
}
function metadataForUpload_(location, blob, metadata) {
    const metadataClone = Object.assign({}, metadata);
    metadataClone['fullPath'] = location.path;
    metadataClone['size'] = blob.size();
    if (!metadataClone['contentType']) {
        metadataClone['contentType'] = determineContentType_(null, blob);
    }
    return metadataClone;
}
/**
 * Prepare RequestInfo for uploads as Content-Type: multipart.
 */
function multipartUpload(service, location, mappings, blob, metadata) {
    const urlPart = location.bucketOnlyServerUrl();
    const headers = {
        'X-Goog-Upload-Protocol': 'multipart'
    };
    function genBoundary() {
        let str = '';
        for (let i = 0; i < 2; i++) {
            str = str + Math.random().toString().slice(2);
        }
        return str;
    }
    const boundary = genBoundary();
    headers['Content-Type'] = 'multipart/related; boundary=' + boundary;
    const metadata_ = metadataForUpload_(location, blob, metadata);
    const metadataString = toResourceString(metadata_, mappings);
    const preBlobPart = '--' +
        boundary +
        '\r\n' +
        'Content-Type: application/json; charset=utf-8\r\n\r\n' +
        metadataString +
        '\r\n--' +
        boundary +
        '\r\n' +
        'Content-Type: ' +
        metadata_['contentType'] +
        '\r\n\r\n';
    const postBlobPart = '\r\n--' + boundary + '--';
    const body = FbsBlob.getBlob(preBlobPart, blob, postBlobPart);
    if (body === null) {
        throw cannotSliceBlob();
    }
    const urlParams = { name: metadata_['fullPath'] };
    const url = makeUrl(urlPart, service.host, service._protocol);
    const method = 'POST';
    const timeout = service.maxUploadRetryTime;
    const requestInfo = new RequestInfo(url, method, metadataHandler(service, mappings), timeout);
    requestInfo.urlParams = urlParams;
    requestInfo.headers = headers;
    requestInfo.body = body.uploadData();
    requestInfo.errorHandler = sharedErrorHandler(location);
    return requestInfo;
}
/**
 * @param current The number of bytes that have been uploaded so far.
 * @param total The total number of bytes in the upload.
 * @param opt_finalized True if the server has finished the upload.
 * @param opt_metadata The upload metadata, should
 *     only be passed if opt_finalized is true.
 */
class ResumableUploadStatus {
    constructor(current, total, finalized, metadata) {
        this.current = current;
        this.total = total;
        this.finalized = !!finalized;
        this.metadata = metadata || null;
    }
}
function checkResumeHeader_(xhr, allowed) {
    let status = null;
    try {
        status = xhr.getResponseHeader('X-Goog-Upload-Status');
    }
    catch (e) {
        handlerCheck(false);
    }
    const allowedStatus = allowed || ['active'];
    handlerCheck(!!status && allowedStatus.indexOf(status) !== -1);
    return status;
}
function createResumableUpload(service, location, mappings, blob, metadata) {
    const urlPart = location.bucketOnlyServerUrl();
    const metadataForUpload = metadataForUpload_(location, blob, metadata);
    const urlParams = { name: metadataForUpload['fullPath'] };
    const url = makeUrl(urlPart, service.host, service._protocol);
    const method = 'POST';
    const headers = {
        'X-Goog-Upload-Protocol': 'resumable',
        'X-Goog-Upload-Command': 'start',
        'X-Goog-Upload-Header-Content-Length': `${blob.size()}`,
        'X-Goog-Upload-Header-Content-Type': metadataForUpload['contentType'],
        'Content-Type': 'application/json; charset=utf-8'
    };
    const body = toResourceString(metadataForUpload, mappings);
    const timeout = service.maxUploadRetryTime;
    function handler(xhr) {
        checkResumeHeader_(xhr);
        let url;
        try {
            url = xhr.getResponseHeader('X-Goog-Upload-URL');
        }
        catch (e) {
            handlerCheck(false);
        }
        handlerCheck(isString(url));
        return url;
    }
    const requestInfo = new RequestInfo(url, method, handler, timeout);
    requestInfo.urlParams = urlParams;
    requestInfo.headers = headers;
    requestInfo.body = body;
    requestInfo.errorHandler = sharedErrorHandler(location);
    return requestInfo;
}
/**
 * @param url From a call to fbs.requests.createResumableUpload.
 */
function getResumableUploadStatus(service, location, url, blob) {
    const headers = { 'X-Goog-Upload-Command': 'query' };
    function handler(xhr) {
        const status = checkResumeHeader_(xhr, ['active', 'final']);
        let sizeString = null;
        try {
            sizeString = xhr.getResponseHeader('X-Goog-Upload-Size-Received');
        }
        catch (e) {
            handlerCheck(false);
        }
        if (!sizeString) {
            // null or empty string
            handlerCheck(false);
        }
        const size = Number(sizeString);
        handlerCheck(!isNaN(size));
        return new ResumableUploadStatus(size, blob.size(), status === 'final');
    }
    const method = 'POST';
    const timeout = service.maxUploadRetryTime;
    const requestInfo = new RequestInfo(url, method, handler, timeout);
    requestInfo.headers = headers;
    requestInfo.errorHandler = sharedErrorHandler(location);
    return requestInfo;
}
/**
 * Any uploads via the resumable upload API must transfer a number of bytes
 * that is a multiple of this number.
 */
const RESUMABLE_UPLOAD_CHUNK_SIZE = 256 * 1024;
/**
 * @param url From a call to fbs.requests.createResumableUpload.
 * @param chunkSize Number of bytes to upload.
 * @param status The previous status.
 *     If not passed or null, we start from the beginning.
 * @throws fbs.Error If the upload is already complete, the passed in status
 *     has a final size inconsistent with the blob, or the blob cannot be sliced
 *     for upload.
 */
function continueResumableUpload(location, service, url, blob, chunkSize, mappings, status, progressCallback) {
    // TODO(andysoto): standardize on internal asserts
    // assert(!(opt_status && opt_status.finalized));
    const status_ = new ResumableUploadStatus(0, 0);
    if (status) {
        status_.current = status.current;
        status_.total = status.total;
    }
    else {
        status_.current = 0;
        status_.total = blob.size();
    }
    if (blob.size() !== status_.total) {
        throw serverFileWrongSize();
    }
    const bytesLeft = status_.total - status_.current;
    let bytesToUpload = bytesLeft;
    if (chunkSize > 0) {
        bytesToUpload = Math.min(bytesToUpload, chunkSize);
    }
    const startByte = status_.current;
    const endByte = startByte + bytesToUpload;
    let uploadCommand = '';
    if (bytesToUpload === 0) {
        uploadCommand = 'finalize';
    }
    else if (bytesLeft === bytesToUpload) {
        uploadCommand = 'upload, finalize';
    }
    else {
        uploadCommand = 'upload';
    }
    const headers = {
        'X-Goog-Upload-Command': uploadCommand,
        'X-Goog-Upload-Offset': `${status_.current}`
    };
    const body = blob.slice(startByte, endByte);
    if (body === null) {
        throw cannotSliceBlob();
    }
    function handler(xhr, text) {
        // TODO(andysoto): Verify the MD5 of each uploaded range:
        // the 'x-range-md5' header comes back with status code 308 responses.
        // We'll only be able to bail out though, because you can't re-upload a
        // range that you previously uploaded.
        const uploadStatus = checkResumeHeader_(xhr, ['active', 'final']);
        const newCurrent = status_.current + bytesToUpload;
        const size = blob.size();
        let metadata;
        if (uploadStatus === 'final') {
            metadata = metadataHandler(service, mappings)(xhr, text);
        }
        else {
            metadata = null;
        }
        return new ResumableUploadStatus(newCurrent, size, uploadStatus === 'final', metadata);
    }
    const method = 'POST';
    const timeout = service.maxUploadRetryTime;
    const requestInfo = new RequestInfo(url, method, handler, timeout);
    requestInfo.headers = headers;
    requestInfo.body = body.uploadData();
    requestInfo.progressCallback = progressCallback || null;
    requestInfo.errorHandler = sharedErrorHandler(location);
    return requestInfo;
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * An event that is triggered on a task.
 * @internal
 */
const TaskEvent = {
    /**
     * For this event,
     * <ul>
     *   <li>The `next` function is triggered on progress updates and when the
     *       task is paused/resumed with an `UploadTaskSnapshot` as the first
     *       argument.</li>
     *   <li>The `error` function is triggered if the upload is canceled or fails
     *       for another reason.</li>
     *   <li>The `complete` function is triggered if the upload completes
     *       successfully.</li>
     * </ul>
     */
    STATE_CHANGED: 'state_changed'
};
// type keys = keyof TaskState
/**
 * Represents the current state of a running upload.
 * @internal
 */
const TaskState = {
    /** The task is currently transferring data. */
    RUNNING: 'running',
    /** The task was paused by the user. */
    PAUSED: 'paused',
    /** The task completed successfully. */
    SUCCESS: 'success',
    /** The task was canceled. */
    CANCELED: 'canceled',
    /** The task failed with an error. */
    ERROR: 'error'
};
function taskStateFromInternalTaskState(state) {
    switch (state) {
        case "running" /* InternalTaskState.RUNNING */:
        case "pausing" /* InternalTaskState.PAUSING */:
        case "canceling" /* InternalTaskState.CANCELING */:
            return TaskState.RUNNING;
        case "paused" /* InternalTaskState.PAUSED */:
            return TaskState.PAUSED;
        case "success" /* InternalTaskState.SUCCESS */:
            return TaskState.SUCCESS;
        case "canceled" /* InternalTaskState.CANCELED */:
            return TaskState.CANCELED;
        case "error" /* InternalTaskState.ERROR */:
            return TaskState.ERROR;
        default:
            // TODO(andysoto): assert(false);
            return TaskState.ERROR;
    }
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Observer {
    constructor(nextOrObserver, error, complete) {
        const asFunctions = isFunction(nextOrObserver) || error != null || complete != null;
        if (asFunctions) {
            this.next = nextOrObserver;
            this.error = error ?? undefined;
            this.complete = complete ?? undefined;
        }
        else {
            const observer = nextOrObserver;
            this.next = observer.next;
            this.error = observer.error;
            this.complete = observer.complete;
        }
    }
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Returns a function that invokes f with its arguments asynchronously as a
 * microtask, i.e. as soon as possible after the current script returns back
 * into browser code.
 */
// eslint-disable-next-line @typescript-eslint/ban-types
function async(f) {
    return (...argsToForward) => {
        // eslint-disable-next-line @typescript-eslint/no-floating-promises
        Promise.resolve().then(() => f(...argsToForward));
    };
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Network layer for browsers. We use this instead of goog.net.XhrIo because
 * goog.net.XhrIo is hyuuuuge and doesn't work in React Native on Android.
 */
class XhrConnection {
    constructor() {
        this.sent_ = false;
        this.xhr_ = new XMLHttpRequest();
        this.initXhr();
        this.errorCode_ = ErrorCode.NO_ERROR;
        this.sendPromise_ = new Promise(resolve => {
            this.xhr_.addEventListener('abort', () => {
                this.errorCode_ = ErrorCode.ABORT;
                resolve();
            });
            this.xhr_.addEventListener('error', () => {
                this.errorCode_ = ErrorCode.NETWORK_ERROR;
                resolve();
            });
            this.xhr_.addEventListener('load', () => {
                resolve();
            });
        });
    }
    send(url, method, isUsingEmulator, body, headers) {
        if (this.sent_) {
            throw internalError('cannot .send() more than once');
        }
        if (isCloudWorkstation(url) && isUsingEmulator) {
            this.xhr_.withCredentials = true;
        }
        this.sent_ = true;
        this.xhr_.open(method, url, true);
        if (headers !== undefined) {
            for (const key in headers) {
                if (headers.hasOwnProperty(key)) {
                    this.xhr_.setRequestHeader(key, headers[key].toString());
                }
            }
        }
        if (body !== undefined) {
            this.xhr_.send(body);
        }
        else {
            this.xhr_.send();
        }
        return this.sendPromise_;
    }
    getErrorCode() {
        if (!this.sent_) {
            throw internalError('cannot .getErrorCode() before sending');
        }
        return this.errorCode_;
    }
    getStatus() {
        if (!this.sent_) {
            throw internalError('cannot .getStatus() before sending');
        }
        try {
            return this.xhr_.status;
        }
        catch (e) {
            return -1;
        }
    }
    getResponse() {
        if (!this.sent_) {
            throw internalError('cannot .getResponse() before sending');
        }
        return this.xhr_.response;
    }
    getErrorText() {
        if (!this.sent_) {
            throw internalError('cannot .getErrorText() before sending');
        }
        return this.xhr_.statusText;
    }
    /** Aborts the request. */
    abort() {
        this.xhr_.abort();
    }
    getResponseHeader(header) {
        return this.xhr_.getResponseHeader(header);
    }
    addUploadProgressListener(listener) {
        if (this.xhr_.upload != null) {
            this.xhr_.upload.addEventListener('progress', listener);
        }
    }
    removeUploadProgressListener(listener) {
        if (this.xhr_.upload != null) {
            this.xhr_.upload.removeEventListener('progress', listener);
        }
    }
}
class XhrTextConnection extends XhrConnection {
    initXhr() {
        this.xhr_.responseType = 'text';
    }
}
function newTextConnection() {
    return new XhrTextConnection();
}
class XhrBytesConnection extends XhrConnection {
    initXhr() {
        this.xhr_.responseType = 'arraybuffer';
    }
}
function newBytesConnection() {
    return new XhrBytesConnection();
}
class XhrBlobConnection extends XhrConnection {
    initXhr() {
        this.xhr_.responseType = 'blob';
    }
}
function newBlobConnection() {
    return new XhrBlobConnection();
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @fileoverview Defines types for interacting with blob transfer tasks.
 */
/**
 * Represents a blob being uploaded. Can be used to pause/resume/cancel the
 * upload and manage callbacks for various events.
 * @internal
 */
class UploadTask {
    isExponentialBackoffExpired() {
        return this.sleepTime > this.maxSleepTime;
    }
    /**
     * @param ref - The firebaseStorage.Reference object this task came
     *     from, untyped to avoid cyclic dependencies.
     * @param blob - The blob to upload.
     */
    constructor(ref, blob, metadata = null) {
        /**
         * Number of bytes transferred so far.
         */
        this._transferred = 0;
        this._needToFetchStatus = false;
        this._needToFetchMetadata = false;
        this._observers = [];
        this._error = undefined;
        this._uploadUrl = undefined;
        this._request = undefined;
        this._chunkMultiplier = 1;
        this._resolve = undefined;
        this._reject = undefined;
        this._ref = ref;
        this._blob = blob;
        this._metadata = metadata;
        this._mappings = getMappings();
        this._resumable = this._shouldDoResumable(this._blob);
        this._state = "running" /* InternalTaskState.RUNNING */;
        this._errorHandler = error => {
            this._request = undefined;
            this._chunkMultiplier = 1;
            if (error._codeEquals(StorageErrorCode.CANCELED)) {
                this._needToFetchStatus = true;
                this.completeTransitions_();
            }
            else {
                const backoffExpired = this.isExponentialBackoffExpired();
                if (isRetryStatusCode(error.status, [])) {
                    if (backoffExpired) {
                        error = retryLimitExceeded();
                    }
                    else {
                        this.sleepTime = Math.max(this.sleepTime * 2, DEFAULT_MIN_SLEEP_TIME_MILLIS);
                        this._needToFetchStatus = true;
                        this.completeTransitions_();
                        return;
                    }
                }
                this._error = error;
                this._transition("error" /* InternalTaskState.ERROR */);
            }
        };
        this._metadataErrorHandler = error => {
            this._request = undefined;
            if (error._codeEquals(StorageErrorCode.CANCELED)) {
                this.completeTransitions_();
            }
            else {
                this._error = error;
                this._transition("error" /* InternalTaskState.ERROR */);
            }
        };
        this.sleepTime = 0;
        this.maxSleepTime = this._ref.storage.maxUploadRetryTime;
        this._promise = new Promise((resolve, reject) => {
            this._resolve = resolve;
            this._reject = reject;
            this._start();
        });
        // Prevent uncaught rejections on the internal promise from bubbling out
        // to the top level with a dummy handler.
        this._promise.then(null, () => { });
    }
    _makeProgressCallback() {
        const sizeBefore = this._transferred;
        return loaded => this._updateProgress(sizeBefore + loaded);
    }
    _shouldDoResumable(blob) {
        return blob.size() > 256 * 1024;
    }
    _start() {
        if (this._state !== "running" /* InternalTaskState.RUNNING */) {
            // This can happen if someone pauses us in a resume callback, for example.
            return;
        }
        if (this._request !== undefined) {
            return;
        }
        if (this._resumable) {
            if (this._uploadUrl === undefined) {
                this._createResumable();
            }
            else {
                if (this._needToFetchStatus) {
                    this._fetchStatus();
                }
                else {
                    if (this._needToFetchMetadata) {
                        // Happens if we miss the metadata on upload completion.
                        this._fetchMetadata();
                    }
                    else {
                        this.pendingTimeout = setTimeout(() => {
                            this.pendingTimeout = undefined;
                            this._continueUpload();
                        }, this.sleepTime);
                    }
                }
            }
        }
        else {
            this._oneShotUpload();
        }
    }
    _resolveToken(callback) {
        // eslint-disable-next-line @typescript-eslint/no-floating-promises
        Promise.all([
            this._ref.storage._getAuthToken(),
            this._ref.storage._getAppCheckToken()
        ]).then(([authToken, appCheckToken]) => {
            switch (this._state) {
                case "running" /* InternalTaskState.RUNNING */:
                    callback(authToken, appCheckToken);
                    break;
                case "canceling" /* InternalTaskState.CANCELING */:
                    this._transition("canceled" /* InternalTaskState.CANCELED */);
                    break;
                case "pausing" /* InternalTaskState.PAUSING */:
                    this._transition("paused" /* InternalTaskState.PAUSED */);
                    break;
            }
        });
    }
    // TODO(andysoto): assert false
    _createResumable() {
        this._resolveToken((authToken, appCheckToken) => {
            const requestInfo = createResumableUpload(this._ref.storage, this._ref._location, this._mappings, this._blob, this._metadata);
            const createRequest = this._ref.storage._makeRequest(requestInfo, newTextConnection, authToken, appCheckToken);
            this._request = createRequest;
            createRequest.getPromise().then((url) => {
                this._request = undefined;
                this._uploadUrl = url;
                this._needToFetchStatus = false;
                this.completeTransitions_();
            }, this._errorHandler);
        });
    }
    _fetchStatus() {
        // TODO(andysoto): assert(this.uploadUrl_ !== null);
        const url = this._uploadUrl;
        this._resolveToken((authToken, appCheckToken) => {
            const requestInfo = getResumableUploadStatus(this._ref.storage, this._ref._location, url, this._blob);
            const statusRequest = this._ref.storage._makeRequest(requestInfo, newTextConnection, authToken, appCheckToken);
            this._request = statusRequest;
            statusRequest.getPromise().then(status => {
                status = status;
                this._request = undefined;
                this._updateProgress(status.current);
                this._needToFetchStatus = false;
                if (status.finalized) {
                    this._needToFetchMetadata = true;
                }
                this.completeTransitions_();
            }, this._errorHandler);
        });
    }
    _continueUpload() {
        const chunkSize = RESUMABLE_UPLOAD_CHUNK_SIZE * this._chunkMultiplier;
        const status = new ResumableUploadStatus(this._transferred, this._blob.size());
        // TODO(andysoto): assert(this.uploadUrl_ !== null);
        const url = this._uploadUrl;
        this._resolveToken((authToken, appCheckToken) => {
            let requestInfo;
            try {
                requestInfo = continueResumableUpload(this._ref._location, this._ref.storage, url, this._blob, chunkSize, this._mappings, status, this._makeProgressCallback());
            }
            catch (e) {
                this._error = e;
                this._transition("error" /* InternalTaskState.ERROR */);
                return;
            }
            const uploadRequest = this._ref.storage._makeRequest(requestInfo, newTextConnection, authToken, appCheckToken, 
            /*retry=*/ false // Upload requests should not be retried as each retry should be preceded by another query request. Which is handled in this file.
            );
            this._request = uploadRequest;
            uploadRequest.getPromise().then((newStatus) => {
                this._increaseMultiplier();
                this._request = undefined;
                this._updateProgress(newStatus.current);
                if (newStatus.finalized) {
                    this._metadata = newStatus.metadata;
                    this._transition("success" /* InternalTaskState.SUCCESS */);
                }
                else {
                    this.completeTransitions_();
                }
            }, this._errorHandler);
        });
    }
    _increaseMultiplier() {
        const currentSize = RESUMABLE_UPLOAD_CHUNK_SIZE * this._chunkMultiplier;
        // Max chunk size is 32M.
        if (currentSize * 2 < 32 * 1024 * 1024) {
            this._chunkMultiplier *= 2;
        }
    }
    _fetchMetadata() {
        this._resolveToken((authToken, appCheckToken) => {
            const requestInfo = getMetadata$2(this._ref.storage, this._ref._location, this._mappings);
            const metadataRequest = this._ref.storage._makeRequest(requestInfo, newTextConnection, authToken, appCheckToken);
            this._request = metadataRequest;
            metadataRequest.getPromise().then(metadata => {
                this._request = undefined;
                this._metadata = metadata;
                this._transition("success" /* InternalTaskState.SUCCESS */);
            }, this._metadataErrorHandler);
        });
    }
    _oneShotUpload() {
        this._resolveToken((authToken, appCheckToken) => {
            const requestInfo = multipartUpload(this._ref.storage, this._ref._location, this._mappings, this._blob, this._metadata);
            const multipartRequest = this._ref.storage._makeRequest(requestInfo, newTextConnection, authToken, appCheckToken);
            this._request = multipartRequest;
            multipartRequest.getPromise().then(metadata => {
                this._request = undefined;
                this._metadata = metadata;
                this._updateProgress(this._blob.size());
                this._transition("success" /* InternalTaskState.SUCCESS */);
            }, this._errorHandler);
        });
    }
    _updateProgress(transferred) {
        const old = this._transferred;
        this._transferred = transferred;
        // A progress update can make the "transferred" value smaller (e.g. a
        // partial upload not completed by server, after which the "transferred"
        // value may reset to the value at the beginning of the request).
        if (this._transferred !== old) {
            this._notifyObservers();
        }
    }
    _transition(state) {
        if (this._state === state) {
            return;
        }
        switch (state) {
            case "canceling" /* InternalTaskState.CANCELING */:
            case "pausing" /* InternalTaskState.PAUSING */:
                // TODO(andysoto):
                // assert(this.state_ === InternalTaskState.RUNNING ||
                //        this.state_ === InternalTaskState.PAUSING);
                this._state = state;
                if (this._request !== undefined) {
                    this._request.cancel();
                }
                else if (this.pendingTimeout) {
                    clearTimeout(this.pendingTimeout);
                    this.pendingTimeout = undefined;
                    this.completeTransitions_();
                }
                break;
            case "running" /* InternalTaskState.RUNNING */:
                // TODO(andysoto):
                // assert(this.state_ === InternalTaskState.PAUSED ||
                //        this.state_ === InternalTaskState.PAUSING);
                const wasPaused = this._state === "paused" /* InternalTaskState.PAUSED */;
                this._state = state;
                if (wasPaused) {
                    this._notifyObservers();
                    this._start();
                }
                break;
            case "paused" /* InternalTaskState.PAUSED */:
                // TODO(andysoto):
                // assert(this.state_ === InternalTaskState.PAUSING);
                this._state = state;
                this._notifyObservers();
                break;
            case "canceled" /* InternalTaskState.CANCELED */:
                // TODO(andysoto):
                // assert(this.state_ === InternalTaskState.PAUSED ||
                //        this.state_ === InternalTaskState.CANCELING);
                this._error = canceled();
                this._state = state;
                this._notifyObservers();
                break;
            case "error" /* InternalTaskState.ERROR */:
                // TODO(andysoto):
                // assert(this.state_ === InternalTaskState.RUNNING ||
                //        this.state_ === InternalTaskState.PAUSING ||
                //        this.state_ === InternalTaskState.CANCELING);
                this._state = state;
                this._notifyObservers();
                break;
            case "success" /* InternalTaskState.SUCCESS */:
                // TODO(andysoto):
                // assert(this.state_ === InternalTaskState.RUNNING ||
                //        this.state_ === InternalTaskState.PAUSING ||
                //        this.state_ === InternalTaskState.CANCELING);
                this._state = state;
                this._notifyObservers();
                break;
        }
    }
    completeTransitions_() {
        switch (this._state) {
            case "pausing" /* InternalTaskState.PAUSING */:
                this._transition("paused" /* InternalTaskState.PAUSED */);
                break;
            case "canceling" /* InternalTaskState.CANCELING */:
                this._transition("canceled" /* InternalTaskState.CANCELED */);
                break;
            case "running" /* InternalTaskState.RUNNING */:
                this._start();
                break;
        }
    }
    /**
     * A snapshot of the current task state.
     */
    get snapshot() {
        const externalState = taskStateFromInternalTaskState(this._state);
        return {
            bytesTransferred: this._transferred,
            totalBytes: this._blob.size(),
            state: externalState,
            metadata: this._metadata,
            task: this,
            ref: this._ref
        };
    }
    /**
     * Adds a callback for an event.
     * @param type - The type of event to listen for.
     * @param nextOrObserver -
     *     The `next` function, which gets called for each item in
     *     the event stream, or an observer object with some or all of these three
     *     properties (`next`, `error`, `complete`).
     * @param error - A function that gets called with a `StorageError`
     *     if the event stream ends due to an error.
     * @param completed - A function that gets called if the
     *     event stream ends normally.
     * @returns
     *     If only the event argument is passed, returns a function you can use to
     *     add callbacks (see the examples above). If more than just the event
     *     argument is passed, returns a function you can call to unregister the
     *     callbacks.
     */
    on(type, nextOrObserver, error, completed) {
        // Note: `type` isn't being used. Its type is also incorrect. TaskEvent should not be a string.
        const observer = new Observer(nextOrObserver || undefined, error || undefined, completed || undefined);
        this._addObserver(observer);
        return () => {
            this._removeObserver(observer);
        };
    }
    /**
     * This object behaves like a Promise, and resolves with its snapshot data
     * when the upload completes.
     * @param onFulfilled - The fulfillment callback. Promise chaining works as normal.
     * @param onRejected - The rejection callback.
     */
    then(onFulfilled, onRejected) {
        // These casts are needed so that TypeScript can infer the types of the
        // resulting Promise.
        return this._promise.then(onFulfilled, onRejected);
    }
    /**
     * Equivalent to calling `then(null, onRejected)`.
     */
    catch(onRejected) {
        return this.then(null, onRejected);
    }
    /**
     * Adds the given observer.
     */
    _addObserver(observer) {
        this._observers.push(observer);
        this._notifyObserver(observer);
    }
    /**
     * Removes the given observer.
     */
    _removeObserver(observer) {
        const i = this._observers.indexOf(observer);
        if (i !== -1) {
            this._observers.splice(i, 1);
        }
    }
    _notifyObservers() {
        this._finishPromise();
        const observers = this._observers.slice();
        observers.forEach(observer => {
            this._notifyObserver(observer);
        });
    }
    _finishPromise() {
        if (this._resolve !== undefined) {
            let triggered = true;
            switch (taskStateFromInternalTaskState(this._state)) {
                case TaskState.SUCCESS:
                    async(this._resolve.bind(null, this.snapshot))();
                    break;
                case TaskState.CANCELED:
                case TaskState.ERROR:
                    const toCall = this._reject;
                    async(toCall.bind(null, this._error))();
                    break;
                default:
                    triggered = false;
                    break;
            }
            if (triggered) {
                this._resolve = undefined;
                this._reject = undefined;
            }
        }
    }
    _notifyObserver(observer) {
        const externalState = taskStateFromInternalTaskState(this._state);
        switch (externalState) {
            case TaskState.RUNNING:
            case TaskState.PAUSED:
                if (observer.next) {
                    async(observer.next.bind(observer, this.snapshot))();
                }
                break;
            case TaskState.SUCCESS:
                if (observer.complete) {
                    async(observer.complete.bind(observer))();
                }
                break;
            case TaskState.CANCELED:
            case TaskState.ERROR:
                if (observer.error) {
                    async(observer.error.bind(observer, this._error))();
                }
                break;
            default:
                // TODO(andysoto): assert(false);
                if (observer.error) {
                    async(observer.error.bind(observer, this._error))();
                }
        }
    }
    /**
     * Resumes a paused task. Has no effect on a currently running or failed task.
     * @returns True if the operation took effect, false if ignored.
     */
    resume() {
        const valid = this._state === "paused" /* InternalTaskState.PAUSED */ ||
            this._state === "pausing" /* InternalTaskState.PAUSING */;
        if (valid) {
            this._transition("running" /* InternalTaskState.RUNNING */);
        }
        return valid;
    }
    /**
     * Pauses a currently running task. Has no effect on a paused or failed task.
     * @returns True if the operation took effect, false if ignored.
     */
    pause() {
        const valid = this._state === "running" /* InternalTaskState.RUNNING */;
        if (valid) {
            this._transition("pausing" /* InternalTaskState.PAUSING */);
        }
        return valid;
    }
    /**
     * Cancels a currently running or paused task. Has no effect on a complete or
     * failed task.
     * @returns True if the operation took effect, false if ignored.
     */
    cancel() {
        const valid = this._state === "running" /* InternalTaskState.RUNNING */ ||
            this._state === "pausing" /* InternalTaskState.PAUSING */;
        if (valid) {
            this._transition("canceling" /* InternalTaskState.CANCELING */);
        }
        return valid;
    }
}

/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @fileoverview Defines the Firebase StorageReference class.
 */
/**
 * Provides methods to interact with a bucket in the Firebase Storage service.
 * @internal
 * @param _location - An fbs.location, or the URL at
 *     which to base this object, in one of the following forms:
 *         gs://<bucket>/<object-path>
 *         http[s]://firebasestorage.googleapis.com/
 *                     <api-version>/b/<bucket>/o/<object-path>
 *     Any query or fragment strings will be ignored in the http[s]
 *     format. If no value is passed, the storage object will use a URL based on
 *     the project ID of the base firebase.App instance.
 */
class Reference {
    constructor(_service, location) {
        this._service = _service;
        if (location instanceof Location) {
            this._location = location;
        }
        else {
            this._location = Location.makeFromUrl(location, _service.host);
        }
    }
    /**
     * Returns the URL for the bucket and path this object references,
     *     in the form gs://<bucket>/<object-path>
     * @override
     */
    toString() {
        return 'gs://' + this._location.bucket + '/' + this._location.path;
    }
    _newRef(service, location) {
        return new Reference(service, location);
    }
    /**
     * A reference to the root of this object's bucket.
     */
    get root() {
        const location = new Location(this._location.bucket, '');
        return this._newRef(this._service, location);
    }
    /**
     * The name of the bucket containing this reference's object.
     */
    get bucket() {
        return this._location.bucket;
    }
    /**
     * The full path of this object.
     */
    get fullPath() {
        return this._location.path;
    }
    /**
     * The short name of this object, which is the last component of the full path.
     * For example, if fullPath is 'full/path/image.png', name is 'image.png'.
     */
    get name() {
        return lastComponent(this._location.path);
    }
    /**
     * The `StorageService` instance this `StorageReference` is associated with.
     */
    get storage() {
        return this._service;
    }
    /**
     * A `StorageReference` pointing to the parent location of this `StorageReference`, or null if
     * this reference is the root.
     */
    get parent() {
        const newPath = parent(this._location.path);
        if (newPath === null) {
            return null;
        }
        const location = new Location(this._location.bucket, newPath);
        return new Reference(this._service, location);
    }
    /**
     * Utility function to throw an error in methods that do not accept a root reference.
     */
    _throwIfRoot(name) {
        if (this._location.path === '') {
            throw invalidRootOperation(name);
        }
    }
}
/**
 * Download the bytes at the object's location.
 * @returns A Promise containing the downloaded bytes.
 */
function getBytesInternal(ref, maxDownloadSizeBytes) {
    ref._throwIfRoot('getBytes');
    const requestInfo = getBytes$1(ref.storage, ref._location, maxDownloadSizeBytes);
    return ref.storage
        .makeRequestWithTokens(requestInfo, newBytesConnection)
        .then(bytes => maxDownloadSizeBytes !== undefined
        ? // GCS may not honor the Range header for small files
            bytes.slice(0, maxDownloadSizeBytes)
        : bytes);
}
/**
 * Download the bytes at the object's location.
 * @returns A Promise containing the downloaded blob.
 */
function getBlobInternal(ref, maxDownloadSizeBytes) {
    ref._throwIfRoot('getBlob');
    const requestInfo = getBytes$1(ref.storage, ref._location, maxDownloadSizeBytes);
    return ref.storage
        .makeRequestWithTokens(requestInfo, newBlobConnection)
        .then(blob => maxDownloadSizeBytes !== undefined
        ? // GCS may not honor the Range header for small files
            blob.slice(0, maxDownloadSizeBytes)
        : blob);
}
/**
 * Uploads data to this object's location.
 * The upload is not resumable.
 *
 * @param ref - StorageReference where data should be uploaded.
 * @param data - The data to upload.
 * @param metadata - Metadata for the newly uploaded data.
 * @returns A Promise containing an UploadResult
 */
function uploadBytes$1(ref, data, metadata) {
    ref._throwIfRoot('uploadBytes');
    const requestInfo = multipartUpload(ref.storage, ref._location, getMappings(), new FbsBlob(data, true), metadata);
    return ref.storage
        .makeRequestWithTokens(requestInfo, newTextConnection)
        .then(finalMetadata => {
        return {
            metadata: finalMetadata,
            ref
        };
    });
}
/**
 * Uploads data to this object's location.
 * The upload can be paused and resumed, and exposes progress updates.
 * @public
 * @param ref - StorageReference where data should be uploaded.
 * @param data - The data to upload.
 * @param metadata - Metadata for the newly uploaded data.
 * @returns An UploadTask
 */
function uploadBytesResumable$1(ref, data, metadata) {
    ref._throwIfRoot('uploadBytesResumable');
    return new UploadTask(ref, new FbsBlob(data), metadata);
}
/**
 * Uploads a string to this object's location.
 * The upload is not resumable.
 * @public
 * @param ref - StorageReference where string should be uploaded.
 * @param value - The string to upload.
 * @param format - The format of the string to upload.
 * @param metadata - Metadata for the newly uploaded string.
 * @returns A Promise containing an UploadResult
 */
function uploadString$1(ref, value, format = StringFormat.RAW, metadata) {
    ref._throwIfRoot('uploadString');
    const data = dataFromString(format, value);
    const metadataClone = { ...metadata };
    if (metadataClone['contentType'] == null && data.contentType != null) {
        metadataClone['contentType'] = data.contentType;
    }
    return uploadBytes$1(ref, data.data, metadataClone);
}
/**
 * List all items (files) and prefixes (folders) under this storage reference.
 *
 * This is a helper method for calling list() repeatedly until there are
 * no more results. The default pagination size is 1000.
 *
 * Note: The results may not be consistent if objects are changed while this
 * operation is running.
 *
 * Warning: listAll may potentially consume too many resources if there are
 * too many results.
 * @public
 * @param ref - StorageReference to get list from.
 *
 * @returns A Promise that resolves with all the items and prefixes under
 *      the current storage reference. `prefixes` contains references to
 *      sub-directories and `items` contains references to objects in this
 *      folder. `nextPageToken` is never returned.
 */
function listAll$1(ref) {
    const accumulator = {
        prefixes: [],
        items: []
    };
    return listAllHelper(ref, accumulator).then(() => accumulator);
}
/**
 * Separated from listAll because async functions can't use "arguments".
 * @param ref
 * @param accumulator
 * @param pageToken
 */
async function listAllHelper(ref, accumulator, pageToken) {
    const opt = {
        // maxResults is 1000 by default.
        pageToken
    };
    const nextPage = await list$1(ref, opt);
    accumulator.prefixes.push(...nextPage.prefixes);
    accumulator.items.push(...nextPage.items);
    if (nextPage.nextPageToken != null) {
        await listAllHelper(ref, accumulator, nextPage.nextPageToken);
    }
}
/**
 * List items (files) and prefixes (folders) under this storage reference.
 *
 * List API is only available for Firebase Rules Version 2.
 *
 * GCS is a key-blob store. Firebase Storage imposes the semantic of '/'
 * delimited folder structure.
 * Refer to GCS's List API if you want to learn more.
 *
 * To adhere to Firebase Rules's Semantics, Firebase Storage does not
 * support objects whose paths end with "/" or contain two consecutive
 * "/"s. Firebase Storage List API will filter these unsupported objects.
 * list() may fail if there are too many unsupported objects in the bucket.
 * @public
 *
 * @param ref - StorageReference to get list from.
 * @param options - See ListOptions for details.
 * @returns A Promise that resolves with the items and prefixes.
 *      `prefixes` contains references to sub-folders and `items`
 *      contains references to objects in this folder. `nextPageToken`
 *      can be used to get the rest of the results.
 */
function list$1(ref, options) {
    if (options != null) {
        if (typeof options.maxResults === 'number') {
            validateNumber('options.maxResults', 
            /* minValue= */ 1, 
            /* maxValue= */ 1000, options.maxResults);
        }
    }
    const op = options || {};
    const requestInfo = list$2(ref.storage, ref._location, 
    /*delimiter= */ '/', op.pageToken, op.maxResults);
    return ref.storage.makeRequestWithTokens(requestInfo, newTextConnection);
}
/**
 * A `Promise` that resolves with the metadata for this object. If this
 * object doesn't exist or metadata cannot be retrieved, the promise is
 * rejected.
 * @public
 * @param ref - StorageReference to get metadata from.
 */
function getMetadata$1(ref) {
    ref._throwIfRoot('getMetadata');
    const requestInfo = getMetadata$2(ref.storage, ref._location, getMappings());
    return ref.storage.makeRequestWithTokens(requestInfo, newTextConnection);
}
/**
 * Updates the metadata for this object.
 * @public
 * @param ref - StorageReference to update metadata for.
 * @param metadata - The new metadata for the object.
 *     Only values that have been explicitly set will be changed. Explicitly
 *     setting a value to null will remove the metadata.
 * @returns A `Promise` that resolves
 *     with the new metadata for this object.
 *     See `firebaseStorage.Reference.prototype.getMetadata`
 */
function updateMetadata$1(ref, metadata) {
    ref._throwIfRoot('updateMetadata');
    const requestInfo = updateMetadata$2(ref.storage, ref._location, metadata, getMappings());
    return ref.storage.makeRequestWithTokens(requestInfo, newTextConnection);
}
/**
 * Returns the download URL for the given Reference.
 * @public
 * @returns A `Promise` that resolves with the download
 *     URL for this object.
 */
function getDownloadURL$1(ref) {
    ref._throwIfRoot('getDownloadURL');
    const requestInfo = getDownloadUrl(ref.storage, ref._location, getMappings());
    return ref.storage
        .makeRequestWithTokens(requestInfo, newTextConnection)
        .then(url => {
        if (url === null) {
            throw noDownloadURL();
        }
        return url;
    });
}
/**
 * Deletes the object at this location.
 * @public
 * @param ref - StorageReference for object to delete.
 * @returns A `Promise` that resolves if the deletion succeeds.
 */
function deleteObject$1(ref) {
    ref._throwIfRoot('deleteObject');
    const requestInfo = deleteObject$2(ref.storage, ref._location);
    return ref.storage.makeRequestWithTokens(requestInfo, newTextConnection);
}
/**
 * Returns reference for object obtained by appending `childPath` to `ref`.
 *
 * @param ref - StorageReference to get child of.
 * @param childPath - Child path from provided ref.
 * @returns A reference to the object obtained by
 * appending childPath, removing any duplicate, beginning, or trailing
 * slashes.
 *
 */
function _getChild$1(ref, childPath) {
    const newPath = child(ref._location.path, childPath);
    const location = new Location(ref._location.bucket, newPath);
    return new Reference(ref.storage, location);
}

/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function isUrl(path) {
    return /^[A-Za-z]+:\/\//.test(path);
}
/**
 * Returns a firebaseStorage.Reference for the given url.
 */
function refFromURL(service, url) {
    return new Reference(service, url);
}
/**
 * Returns a firebaseStorage.Reference for the given path in the default
 * bucket.
 */
function refFromPath(ref, path) {
    if (ref instanceof FirebaseStorageImpl) {
        const service = ref;
        if (service._bucket == null) {
            throw noDefaultBucket();
        }
        const reference = new Reference(service, service._bucket);
        if (path != null) {
            return refFromPath(reference, path);
        }
        else {
            return reference;
        }
    }
    else {
        // ref is a Reference
        if (path !== undefined) {
            return _getChild$1(ref, path);
        }
        else {
            return ref;
        }
    }
}
function ref$1(serviceOrRef, pathOrUrl) {
    if (pathOrUrl && isUrl(pathOrUrl)) {
        if (serviceOrRef instanceof FirebaseStorageImpl) {
            return refFromURL(serviceOrRef, pathOrUrl);
        }
        else {
            throw invalidArgument('To use ref(service, url), the first argument must be a Storage instance.');
        }
    }
    else {
        return refFromPath(serviceOrRef, pathOrUrl);
    }
}
function extractBucket(host, config) {
    const bucketString = config?.[CONFIG_STORAGE_BUCKET_KEY];
    if (bucketString == null) {
        return null;
    }
    return Location.makeFromBucketSpec(bucketString, host);
}
function connectStorageEmulator$1(storage, host, port, options = {}) {
    storage.host = `${host}:${port}`;
    const useSsl = isCloudWorkstation(host);
    // Workaround to get cookies in Firebase Studio
    if (useSsl) {
        void pingServer(`https://${storage.host}/b`);
    }
    storage._isUsingEmulator = true;
    storage._protocol = useSsl ? 'https' : 'http';
    const { mockUserToken } = options;
    if (mockUserToken) {
        storage._overrideAuthToken =
            typeof mockUserToken === 'string'
                ? mockUserToken
                : createMockUserToken(mockUserToken, storage.app.options.projectId);
    }
}
/**
 * A service that provides Firebase Storage Reference instances.
 * @param opt_url - gs:// url to a custom Storage Bucket
 *
 * @internal
 */
class FirebaseStorageImpl {
    constructor(
    /**
     * FirebaseApp associated with this StorageService instance.
     */
    app, _authProvider, 
    /**
     * @internal
     */
    _appCheckProvider, 
    /**
     * @internal
     */
    _url, _firebaseVersion, _isUsingEmulator = false) {
        this.app = app;
        this._authProvider = _authProvider;
        this._appCheckProvider = _appCheckProvider;
        this._url = _url;
        this._firebaseVersion = _firebaseVersion;
        this._isUsingEmulator = _isUsingEmulator;
        this._bucket = null;
        /**
         * This string can be in the formats:
         * - host
         * - host:port
         */
        this._host = DEFAULT_HOST;
        this._protocol = 'https';
        this._appId = null;
        this._deleted = false;
        this._maxOperationRetryTime = DEFAULT_MAX_OPERATION_RETRY_TIME;
        this._maxUploadRetryTime = DEFAULT_MAX_UPLOAD_RETRY_TIME;
        this._requests = new Set();
        if (_url != null) {
            this._bucket = Location.makeFromBucketSpec(_url, this._host);
        }
        else {
            this._bucket = extractBucket(this._host, this.app.options);
        }
    }
    /**
     * The host string for this service, in the form of `host` or
     * `host:port`.
     */
    get host() {
        return this._host;
    }
    set host(host) {
        this._host = host;
        if (this._url != null) {
            this._bucket = Location.makeFromBucketSpec(this._url, host);
        }
        else {
            this._bucket = extractBucket(host, this.app.options);
        }
    }
    /**
     * The maximum time to retry uploads in milliseconds.
     */
    get maxUploadRetryTime() {
        return this._maxUploadRetryTime;
    }
    set maxUploadRetryTime(time) {
        validateNumber('time', 
        /* minValue=*/ 0, 
        /* maxValue= */ Number.POSITIVE_INFINITY, time);
        this._maxUploadRetryTime = time;
    }
    /**
     * The maximum time to retry operations other than uploads or downloads in
     * milliseconds.
     */
    get maxOperationRetryTime() {
        return this._maxOperationRetryTime;
    }
    set maxOperationRetryTime(time) {
        validateNumber('time', 
        /* minValue=*/ 0, 
        /* maxValue= */ Number.POSITIVE_INFINITY, time);
        this._maxOperationRetryTime = time;
    }
    async _getAuthToken() {
        if (this._overrideAuthToken) {
            return this._overrideAuthToken;
        }
        const auth = this._authProvider.getImmediate({ optional: true });
        if (auth) {
            const tokenData = await auth.getToken();
            if (tokenData !== null) {
                return tokenData.accessToken;
            }
        }
        return null;
    }
    async _getAppCheckToken() {
        if (_isFirebaseServerApp(this.app) && this.app.settings.appCheckToken) {
            return this.app.settings.appCheckToken;
        }
        const appCheck = this._appCheckProvider.getImmediate({ optional: true });
        if (appCheck) {
            const result = await appCheck.getToken();
            // TODO: What do we want to do if there is an error getting the token?
            // Context: appCheck.getToken() will never throw even if an error happened. In the error case, a dummy token will be
            // returned along with an error field describing the error. In general, we shouldn't care about the error condition and just use
            // the token (actual or dummy) to send requests.
            return result.token;
        }
        return null;
    }
    /**
     * Stop running requests and prevent more from being created.
     */
    _delete() {
        if (!this._deleted) {
            this._deleted = true;
            this._requests.forEach(request => request.cancel());
            this._requests.clear();
        }
        return Promise.resolve();
    }
    /**
     * Returns a new firebaseStorage.Reference object referencing this StorageService
     * at the given Location.
     */
    _makeStorageReference(loc) {
        return new Reference(this, loc);
    }
    /**
     * @param requestInfo - HTTP RequestInfo object
     * @param authToken - Firebase auth token
     */
    _makeRequest(requestInfo, requestFactory, authToken, appCheckToken, retry = true) {
        if (!this._deleted) {
            const request = makeRequest(requestInfo, this._appId, authToken, appCheckToken, requestFactory, this._firebaseVersion, retry, this._isUsingEmulator);
            this._requests.add(request);
            // Request removes itself from set when complete.
            request.getPromise().then(() => this._requests.delete(request), () => this._requests.delete(request));
            return request;
        }
        else {
            return new FailRequest(appDeleted());
        }
    }
    async makeRequestWithTokens(requestInfo, requestFactory) {
        const [authToken, appCheckToken] = await Promise.all([
            this._getAuthToken(),
            this._getAppCheckToken()
        ]);
        return this._makeRequest(requestInfo, requestFactory, authToken, appCheckToken).getPromise();
    }
}

const name = "@firebase/storage";
const version = "0.14.4";

/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Type constant for Firebase Storage.
 */
const STORAGE_TYPE = 'storage';

/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Downloads the data at the object's location. Returns an error if the object
 * is not found.
 *
 * To use this functionality, you have to whitelist your app's origin in your
 * Cloud Storage bucket. See also
 * https://cloud.google.com/storage/docs/configuring-cors
 *
 * @public
 * @param ref - StorageReference where data should be downloaded.
 * @param maxDownloadSizeBytes - If set, the maximum allowed size in bytes to
 * retrieve.
 * @returns A Promise containing the object's bytes
 */
function getBytes(ref, maxDownloadSizeBytes) {
    ref = getModularInstance(ref);
    return getBytesInternal(ref, maxDownloadSizeBytes);
}
/**
 * Uploads data to this object's location.
 * The upload is not resumable.
 * @public
 * @param ref - {@link StorageReference} where data should be uploaded.
 * @param data - The data to upload.
 * @param metadata - Metadata for the data to upload.
 * @returns A Promise containing an UploadResult
 */
function uploadBytes(ref, data, metadata) {
    ref = getModularInstance(ref);
    return uploadBytes$1(ref, data, metadata);
}
/**
 * Uploads a string to this object's location.
 * The upload is not resumable.
 * @public
 * @param ref - {@link StorageReference} where string should be uploaded.
 * @param value - The string to upload.
 * @param format - The format of the string to upload.
 * @param metadata - Metadata for the string to upload.
 * @returns A Promise containing an UploadResult
 */
function uploadString(ref, value, format, metadata) {
    ref = getModularInstance(ref);
    return uploadString$1(ref, value, format, metadata);
}
/**
 * Uploads data to this object's location.
 * The upload can be paused and resumed, and exposes progress updates.
 * @public
 * @param ref - {@link StorageReference} where data should be uploaded.
 * @param data - The data to upload.
 * @param metadata - Metadata for the data to upload.
 * @returns An UploadTask
 */
function uploadBytesResumable(ref, data, metadata) {
    ref = getModularInstance(ref);
    return uploadBytesResumable$1(ref, data, metadata);
}
/**
 * A `Promise` that resolves with the metadata for this object. If this
 * object doesn't exist or metadata cannot be retrieved, the promise is
 * rejected.
 * @public
 * @param ref - {@link StorageReference} to get metadata from.
 */
function getMetadata(ref) {
    ref = getModularInstance(ref);
    return getMetadata$1(ref);
}
/**
 * Updates the metadata for this object.
 * @public
 * @param ref - {@link StorageReference} to update metadata for.
 * @param metadata - The new metadata for the object.
 *     Only values that have been explicitly set will be changed. Explicitly
 *     setting a value to null will remove the metadata.
 * @returns A `Promise` that resolves with the new metadata for this object.
 */
function updateMetadata(ref, metadata) {
    ref = getModularInstance(ref);
    return updateMetadata$1(ref, metadata);
}
/**
 * List items (files) and prefixes (folders) under this storage reference.
 *
 * List API is only available for Firebase Rules Version 2.
 *
 * GCS is a key-blob store. Firebase Storage imposes the semantic of '/'
 * delimited folder structure.
 * Refer to GCS's List API if you want to learn more.
 *
 * To adhere to Firebase Rules's Semantics, Firebase Storage does not
 * support objects whose paths end with "/" or contain two consecutive
 * "/"s. Firebase Storage List API will filter these unsupported objects.
 * list() may fail if there are too many unsupported objects in the bucket.
 * @public
 *
 * @param ref - {@link StorageReference} to get list from.
 * @param options - See {@link ListOptions} for details.
 * @returns A `Promise` that resolves with the items and prefixes.
 *      `prefixes` contains references to sub-folders and `items`
 *      contains references to objects in this folder. `nextPageToken`
 *      can be used to get the rest of the results.
 */
function list(ref, options) {
    ref = getModularInstance(ref);
    return list$1(ref, options);
}
/**
 * List all items (files) and prefixes (folders) under this storage reference.
 *
 * This is a helper method for calling list() repeatedly until there are
 * no more results. The default pagination size is 1000.
 *
 * Note: The results may not be consistent if objects are changed while this
 * operation is running.
 *
 * Warning: `listAll` may potentially consume too many resources if there are
 * too many results.
 * @public
 * @param ref - {@link StorageReference} to get list from.
 *
 * @returns A `Promise` that resolves with all the items and prefixes under
 *      the current storage reference. `prefixes` contains references to
 *      sub-directories and `items` contains references to objects in this
 *      folder. `nextPageToken` is never returned.
 */
function listAll(ref) {
    ref = getModularInstance(ref);
    return listAll$1(ref);
}
/**
 * Returns the download URL for the given {@link StorageReference}.
 * @public
 * @param ref - {@link StorageReference} to get the download URL for.
 * @returns A `Promise` that resolves with the download
 *     URL for this object.
 */
function getDownloadURL(ref) {
    ref = getModularInstance(ref);
    return getDownloadURL$1(ref);
}
/**
 * Deletes the object at this location.
 * @public
 * @param ref - {@link StorageReference} for object to delete.
 * @returns A `Promise` that resolves if the deletion succeeds.
 */
function deleteObject(ref) {
    ref = getModularInstance(ref);
    return deleteObject$1(ref);
}
function ref(serviceOrRef, pathOrUrl) {
    serviceOrRef = getModularInstance(serviceOrRef);
    return ref$1(serviceOrRef, pathOrUrl);
}
/**
 * @internal
 */
function _getChild(ref, childPath) {
    return _getChild$1(ref, childPath);
}
/**
 * Gets a {@link FirebaseStorage} instance for the given Firebase app.
 * @public
 * @param app - Firebase app to get {@link FirebaseStorage} instance for.
 * @param bucketUrl - The gs:// url to your Firebase Storage Bucket.
 * If not passed, uses the app's default Storage Bucket.
 * @returns A {@link FirebaseStorage} instance.
 */
function getStorage(app = getApp(), bucketUrl) {
    app = getModularInstance(app);
    const storageProvider = _getProvider(app, STORAGE_TYPE);
    const storageInstance = storageProvider.getImmediate({
        identifier: bucketUrl
    });
    const emulator = getDefaultEmulatorHostnameAndPort('storage');
    if (emulator) {
        connectStorageEmulator(storageInstance, ...emulator);
    }
    return storageInstance;
}
/**
 * Modify this {@link FirebaseStorage} instance to communicate with the Cloud Storage emulator.
 *
 * @param storage - The {@link FirebaseStorage} instance
 * @param host - The emulator host (ex: localhost)
 * @param port - The emulator port (ex: 5001)
 * @param options - Emulator options. `options.mockUserToken` is the mock auth
 * token to use for unit testing Security Rules.
 * @public
 */
function connectStorageEmulator(storage, host, port, options = {}) {
    connectStorageEmulator$1(storage, host, port, options);
}

/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Downloads the data at the object's location. Returns an error if the object
 * is not found.
 *
 * To use this functionality, you have to whitelist your app's origin in your
 * Cloud Storage bucket. See also
 * https://cloud.google.com/storage/docs/configuring-cors
 *
 * This API is not available in Node.
 *
 * @public
 * @param ref - StorageReference where data should be downloaded.
 * @param maxDownloadSizeBytes - If set, the maximum allowed size in bytes to
 * retrieve.
 * @returns A Promise that resolves with a Blob containing the object's bytes
 */
function getBlob(ref, maxDownloadSizeBytes) {
    ref = getModularInstance(ref);
    return getBlobInternal(ref, maxDownloadSizeBytes);
}
/**
 * Downloads the data at the object's location. Raises an error event if the
 * object is not found.
 *
 * This API is only available in Node.
 *
 * @public
 * @param ref - StorageReference where data should be downloaded.
 * @param maxDownloadSizeBytes - If set, the maximum allowed size in bytes to
 * retrieve.
 * @returns A stream with the object's data as bytes
 */
function getStream(ref, maxDownloadSizeBytes) {
    throw new Error('getStream() is only supported by NodeJS builds');
}

/**
 * Cloud Storage for Firebase
 *
 * @packageDocumentation
 */
/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// eslint-disable-next-line import/no-extraneous-dependencies
function factory(container, { instanceIdentifier: url }) {
    const app = container.getProvider('app').getImmediate();
    const authProvider = container.getProvider('auth-internal');
    const appCheckProvider = container.getProvider('app-check-internal');
    return new FirebaseStorageImpl(app, authProvider, appCheckProvider, url, SDK_VERSION);
}
function registerStorage() {
    _registerComponent(new Component(STORAGE_TYPE, factory, "PUBLIC" /* ComponentType.PUBLIC */).setMultipleInstances(true));
    //RUNTIME_ENV will be replaced during the compilation to "node" for nodejs and an empty string for browser
    registerVersion(name, version, '');
    // BUILD_TARGET will be replaced by values like esm, cjs, etc during the compilation
    registerVersion(name, version, 'esm2020');
}
registerStorage();

export { StorageError, StorageErrorCode, StringFormat, FbsBlob as _FbsBlob, Location as _Location, TaskEvent as _TaskEvent, TaskState as _TaskState, UploadTask as _UploadTask, dataFromString as _dataFromString, _getChild, invalidArgument as _invalidArgument, invalidRootOperation as _invalidRootOperation, connectStorageEmulator, deleteObject, getBlob, getBytes, getDownloadURL, getMetadata, getStorage, getStream, list, listAll, ref, updateMetadata, uploadBytes, uploadBytesResumable, uploadString };
                                     

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguZXNtLmpzIiwic291cmNlcyI6WyIuLi9zcmMvaW1wbGVtZW50YXRpb24vY29uc3RhbnRzLnRzIiwiLi4vc3JjL2ltcGxlbWVudGF0aW9uL2Vycm9yLnRzIiwiLi4vc3JjL2ltcGxlbWVudGF0aW9uL2xvY2F0aW9uLnRzIiwiLi4vc3JjL2ltcGxlbWVudGF0aW9uL2ZhaWxyZXF1ZXN0LnRzIiwiLi4vc3JjL2ltcGxlbWVudGF0aW9uL2JhY2tvZmYudHMiLCIuLi9zcmMvaW1wbGVtZW50YXRpb24vdHlwZS50cyIsIi4uL3NyYy9pbXBsZW1lbnRhdGlvbi91cmwudHMiLCIuLi9zcmMvaW1wbGVtZW50YXRpb24vY29ubmVjdGlvbi50cyIsIi4uL3NyYy9pbXBsZW1lbnRhdGlvbi91dGlscy50cyIsIi4uL3NyYy9pbXBsZW1lbnRhdGlvbi9yZXF1ZXN0LnRzIiwiLi4vc3JjL2ltcGxlbWVudGF0aW9uL2ZzLnRzIiwiLi4vc3JjL3BsYXRmb3JtL2Jyb3dzZXIvYmFzZTY0LnRzIiwiLi4vc3JjL2ltcGxlbWVudGF0aW9uL3N0cmluZy50cyIsIi4uL3NyYy9pbXBsZW1lbnRhdGlvbi9ibG9iLnRzIiwiLi4vc3JjL2ltcGxlbWVudGF0aW9uL2pzb24udHMiLCIuLi9zcmMvaW1wbGVtZW50YXRpb24vcGF0aC50cyIsIi4uL3NyYy9pbXBsZW1lbnRhdGlvbi9tZXRhZGF0YS50cyIsIi4uL3NyYy9pbXBsZW1lbnRhdGlvbi9saXN0LnRzIiwiLi4vc3JjL2ltcGxlbWVudGF0aW9uL3JlcXVlc3RpbmZvLnRzIiwiLi4vc3JjL2ltcGxlbWVudGF0aW9uL3JlcXVlc3RzLnRzIiwiLi4vc3JjL2ltcGxlbWVudGF0aW9uL3Rhc2tlbnVtcy50cyIsIi4uL3NyYy9pbXBsZW1lbnRhdGlvbi9vYnNlcnZlci50cyIsIi4uL3NyYy9pbXBsZW1lbnRhdGlvbi9hc3luYy50cyIsIi4uL3NyYy9wbGF0Zm9ybS9icm93c2VyL2Nvbm5lY3Rpb24udHMiLCIuLi9zcmMvdGFzay50cyIsIi4uL3NyYy9yZWZlcmVuY2UudHMiLCIuLi9zcmMvc2VydmljZS50cyIsIi4uL3NyYy9jb25zdGFudHMudHMiLCIuLi9zcmMvYXBpLnRzIiwiLi4vc3JjL2FwaS5icm93c2VyLnRzIiwiLi4vc3JjL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDE3IEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG4vKipcbiAqIEBmaWxlb3ZlcnZpZXcgQ29uc3RhbnRzIHVzZWQgaW4gdGhlIEZpcmViYXNlIFN0b3JhZ2UgbGlicmFyeS5cbiAqL1xuXG4vKipcbiAqIERvbWFpbiBuYW1lIGZvciBmaXJlYmFzZSBzdG9yYWdlLlxuICovXG5leHBvcnQgY29uc3QgREVGQVVMVF9IT1NUID0gJ2ZpcmViYXNlc3RvcmFnZS5nb29nbGVhcGlzLmNvbSc7XG5cbi8qKlxuICogVGhlIGtleSBpbiBGaXJlYmFzZSBjb25maWcganNvbiBmb3IgdGhlIHN0b3JhZ2UgYnVja2V0LlxuICovXG5leHBvcnQgY29uc3QgQ09ORklHX1NUT1JBR0VfQlVDS0VUX0tFWSA9ICdzdG9yYWdlQnVja2V0JztcblxuLyoqXG4gKiAyIG1pbnV0ZXNcbiAqXG4gKiBUaGUgdGltZW91dCBmb3IgYWxsIG9wZXJhdGlvbnMgZXhjZXB0IHVwbG9hZC5cbiAqL1xuZXhwb3J0IGNvbnN0IERFRkFVTFRfTUFYX09QRVJBVElPTl9SRVRSWV9USU1FID0gMiAqIDYwICogMTAwMDtcblxuLyoqXG4gKiAxMCBtaW51dGVzXG4gKlxuICogVGhlIHRpbWVvdXQgZm9yIHVwbG9hZC5cbiAqL1xuZXhwb3J0IGNvbnN0IERFRkFVTFRfTUFYX1VQTE9BRF9SRVRSWV9USU1FID0gMTAgKiA2MCAqIDEwMDA7XG5cbi8qKlxuICogMSBzZWNvbmRcbiAqL1xuZXhwb3J0IGNvbnN0IERFRkFVTFRfTUlOX1NMRUVQX1RJTUVfTUlMTElTID0gMTAwMDtcblxuLyoqXG4gKiBUaGlzIGlzIHRoZSB2YWx1ZSBvZiBOdW1iZXIuTUlOX1NBRkVfSU5URUdFUiwgd2hpY2ggaXMgbm90IHdlbGwgc3VwcG9ydGVkXG4gKiBlbm91Z2ggZm9yIHVzIHRvIHVzZSBpdCBkaXJlY3RseS5cbiAqL1xuZXhwb3J0IGNvbnN0IE1JTl9TQUZFX0lOVEVHRVIgPSAtOTAwNzE5OTI1NDc0MDk5MTtcbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDE3IEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmltcG9ydCB7IEZpcmViYXNlRXJyb3IgfSBmcm9tICdAZmlyZWJhc2UvdXRpbCc7XG5cbmltcG9ydCB7IENPTkZJR19TVE9SQUdFX0JVQ0tFVF9LRVkgfSBmcm9tICcuL2NvbnN0YW50cyc7XG5cbi8qKlxuICogQW4gZXJyb3IgcmV0dXJuZWQgYnkgdGhlIEZpcmViYXNlIFN0b3JhZ2UgU0RLLlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgY2xhc3MgU3RvcmFnZUVycm9yIGV4dGVuZHMgRmlyZWJhc2VFcnJvciB7XG4gIHByaXZhdGUgcmVhZG9ubHkgX2Jhc2VNZXNzYWdlOiBzdHJpbmc7XG4gIC8qKlxuICAgKiBTdG9yZXMgY3VzdG9tIGVycm9yIGRhdGEgdW5pcXVlIHRvIHRoZSBgU3RvcmFnZUVycm9yYC5cbiAgICovXG4gIGN1c3RvbURhdGE6IHsgc2VydmVyUmVzcG9uc2U6IHN0cmluZyB8IG51bGwgfSA9IHsgc2VydmVyUmVzcG9uc2U6IG51bGwgfTtcblxuICAvKipcbiAgICogQHBhcmFtIGNvZGUgLSBBIGBTdG9yYWdlRXJyb3JDb2RlYCBzdHJpbmcgdG8gYmUgcHJlZml4ZWQgd2l0aCAnc3RvcmFnZS8nIGFuZFxuICAgKiAgYWRkZWQgdG8gdGhlIGVuZCBvZiB0aGUgbWVzc2FnZS5cbiAgICogQHBhcmFtIG1lc3NhZ2UgIC0gRXJyb3IgbWVzc2FnZS5cbiAgICogQHBhcmFtIHN0YXR1c18gLSBDb3JyZXNwb25kaW5nIEhUVFAgU3RhdHVzIENvZGVcbiAgICovXG4gIGNvbnN0cnVjdG9yKGNvZGU6IFN0b3JhZ2VFcnJvckNvZGUsIG1lc3NhZ2U6IHN0cmluZywgcHJpdmF0ZSBzdGF0dXNfID0gMCkge1xuICAgIHN1cGVyKFxuICAgICAgcHJlcGVuZENvZGUoY29kZSksXG4gICAgICBgRmlyZWJhc2UgU3RvcmFnZTogJHttZXNzYWdlfSAoJHtwcmVwZW5kQ29kZShjb2RlKX0pYFxuICAgICk7XG4gICAgdGhpcy5fYmFzZU1lc3NhZ2UgPSB0aGlzLm1lc3NhZ2U7XG4gICAgLy8gV2l0aG91dCB0aGlzLCBgaW5zdGFuY2VvZiBTdG9yYWdlRXJyb3JgLCBpbiB0ZXN0cyBmb3IgZXhhbXBsZSxcbiAgICAvLyByZXR1cm5zIGZhbHNlLlxuICAgIE9iamVjdC5zZXRQcm90b3R5cGVPZih0aGlzLCBTdG9yYWdlRXJyb3IucHJvdG90eXBlKTtcbiAgfVxuXG4gIGdldCBzdGF0dXMoKTogbnVtYmVyIHtcbiAgICByZXR1cm4gdGhpcy5zdGF0dXNfO1xuICB9XG5cbiAgc2V0IHN0YXR1cyhzdGF0dXM6IG51bWJlcikge1xuICAgIHRoaXMuc3RhdHVzXyA9IHN0YXR1cztcbiAgfVxuXG4gIC8qKlxuICAgKiBDb21wYXJlcyBhIGBTdG9yYWdlRXJyb3JDb2RlYCBhZ2FpbnN0IHRoaXMgZXJyb3IncyBjb2RlLCBmaWx0ZXJpbmcgb3V0IHRoZSBwcmVmaXguXG4gICAqL1xuICBfY29kZUVxdWFscyhjb2RlOiBTdG9yYWdlRXJyb3JDb2RlKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHByZXBlbmRDb2RlKGNvZGUpID09PSB0aGlzLmNvZGU7XG4gIH1cblxuICAvKipcbiAgICogT3B0aW9uYWwgcmVzcG9uc2UgbWVzc2FnZSB0aGF0IHdhcyBhZGRlZCBieSB0aGUgc2VydmVyLlxuICAgKi9cbiAgZ2V0IHNlcnZlclJlc3BvbnNlKCk6IG51bGwgfCBzdHJpbmcge1xuICAgIHJldHVybiB0aGlzLmN1c3RvbURhdGEuc2VydmVyUmVzcG9uc2U7XG4gIH1cblxuICBzZXQgc2VydmVyUmVzcG9uc2Uoc2VydmVyUmVzcG9uc2U6IHN0cmluZyB8IG51bGwpIHtcbiAgICB0aGlzLmN1c3RvbURhdGEuc2VydmVyUmVzcG9uc2UgPSBzZXJ2ZXJSZXNwb25zZTtcbiAgICBpZiAodGhpcy5jdXN0b21EYXRhLnNlcnZlclJlc3BvbnNlKSB7XG4gICAgICB0aGlzLm1lc3NhZ2UgPSBgJHt0aGlzLl9iYXNlTWVzc2FnZX1cXG4ke3RoaXMuY3VzdG9tRGF0YS5zZXJ2ZXJSZXNwb25zZX1gO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLm1lc3NhZ2UgPSB0aGlzLl9iYXNlTWVzc2FnZTtcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IGNvbnN0IGVycm9ycyA9IHt9O1xuXG4vKipcbiAqIEBwdWJsaWNcbiAqIEVycm9yIGNvZGVzIHRoYXQgY2FuIGJlIGF0dGFjaGVkIHRvIGBTdG9yYWdlRXJyb3JgIG9iamVjdHMuXG4gKi9cbmV4cG9ydCBlbnVtIFN0b3JhZ2VFcnJvckNvZGUge1xuICAvLyBTaGFyZWQgYmV0d2VlbiBhbGwgcGxhdGZvcm1zXG4gIFVOS05PV04gPSAndW5rbm93bicsXG4gIE9CSkVDVF9OT1RfRk9VTkQgPSAnb2JqZWN0LW5vdC1mb3VuZCcsXG4gIEJVQ0tFVF9OT1RfRk9VTkQgPSAnYnVja2V0LW5vdC1mb3VuZCcsXG4gIFBST0pFQ1RfTk9UX0ZPVU5EID0gJ3Byb2plY3Qtbm90LWZvdW5kJyxcbiAgUVVPVEFfRVhDRUVERUQgPSAncXVvdGEtZXhjZWVkZWQnLFxuICBVTkFVVEhFTlRJQ0FURUQgPSAndW5hdXRoZW50aWNhdGVkJyxcbiAgVU5BVVRIT1JJWkVEID0gJ3VuYXV0aG9yaXplZCcsXG4gIFVOQVVUSE9SSVpFRF9BUFAgPSAndW5hdXRob3JpemVkLWFwcCcsXG4gIFJFVFJZX0xJTUlUX0VYQ0VFREVEID0gJ3JldHJ5LWxpbWl0LWV4Y2VlZGVkJyxcbiAgSU5WQUxJRF9DSEVDS1NVTSA9ICdpbnZhbGlkLWNoZWNrc3VtJyxcbiAgQ0FOQ0VMRUQgPSAnY2FuY2VsZWQnLFxuICAvLyBKUyBzcGVjaWZpY1xuICBJTlZBTElEX0VWRU5UX05BTUUgPSAnaW52YWxpZC1ldmVudC1uYW1lJyxcbiAgSU5WQUxJRF9VUkwgPSAnaW52YWxpZC11cmwnLFxuICBJTlZBTElEX0RFRkFVTFRfQlVDS0VUID0gJ2ludmFsaWQtZGVmYXVsdC1idWNrZXQnLFxuICBOT19ERUZBVUxUX0JVQ0tFVCA9ICduby1kZWZhdWx0LWJ1Y2tldCcsXG4gIENBTk5PVF9TTElDRV9CTE9CID0gJ2Nhbm5vdC1zbGljZS1ibG9iJyxcbiAgU0VSVkVSX0ZJTEVfV1JPTkdfU0laRSA9ICdzZXJ2ZXItZmlsZS13cm9uZy1zaXplJyxcbiAgTk9fRE9XTkxPQURfVVJMID0gJ25vLWRvd25sb2FkLXVybCcsXG4gIElOVkFMSURfQVJHVU1FTlQgPSAnaW52YWxpZC1hcmd1bWVudCcsXG4gIElOVkFMSURfQVJHVU1FTlRfQ09VTlQgPSAnaW52YWxpZC1hcmd1bWVudC1jb3VudCcsXG4gIEFQUF9ERUxFVEVEID0gJ2FwcC1kZWxldGVkJyxcbiAgSU5WQUxJRF9ST09UX09QRVJBVElPTiA9ICdpbnZhbGlkLXJvb3Qtb3BlcmF0aW9uJyxcbiAgSU5WQUxJRF9GT1JNQVQgPSAnaW52YWxpZC1mb3JtYXQnLFxuICBJTlRFUk5BTF9FUlJPUiA9ICdpbnRlcm5hbC1lcnJvcicsXG4gIFVOU1VQUE9SVEVEX0VOVklST05NRU5UID0gJ3Vuc3VwcG9ydGVkLWVudmlyb25tZW50J1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcHJlcGVuZENvZGUoY29kZTogU3RvcmFnZUVycm9yQ29kZSk6IHN0cmluZyB7XG4gIHJldHVybiAnc3RvcmFnZS8nICsgY29kZTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHVua25vd24oKTogU3RvcmFnZUVycm9yIHtcbiAgY29uc3QgbWVzc2FnZSA9XG4gICAgJ0FuIHVua25vd24gZXJyb3Igb2NjdXJyZWQsIHBsZWFzZSBjaGVjayB0aGUgZXJyb3IgcGF5bG9hZCBmb3IgJyArXG4gICAgJ3NlcnZlciByZXNwb25zZS4nO1xuICByZXR1cm4gbmV3IFN0b3JhZ2VFcnJvcihTdG9yYWdlRXJyb3JDb2RlLlVOS05PV04sIG1lc3NhZ2UpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gb2JqZWN0Tm90Rm91bmQocGF0aDogc3RyaW5nKTogU3RvcmFnZUVycm9yIHtcbiAgcmV0dXJuIG5ldyBTdG9yYWdlRXJyb3IoXG4gICAgU3RvcmFnZUVycm9yQ29kZS5PQkpFQ1RfTk9UX0ZPVU5ELFxuICAgIFwiT2JqZWN0ICdcIiArIHBhdGggKyBcIicgZG9lcyBub3QgZXhpc3QuXCJcbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGJ1Y2tldE5vdEZvdW5kKGJ1Y2tldDogc3RyaW5nKTogU3RvcmFnZUVycm9yIHtcbiAgcmV0dXJuIG5ldyBTdG9yYWdlRXJyb3IoXG4gICAgU3RvcmFnZUVycm9yQ29kZS5CVUNLRVRfTk9UX0ZPVU5ELFxuICAgIFwiQnVja2V0ICdcIiArIGJ1Y2tldCArIFwiJyBkb2VzIG5vdCBleGlzdC5cIlxuICApO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcHJvamVjdE5vdEZvdW5kKHByb2plY3Q6IHN0cmluZyk6IFN0b3JhZ2VFcnJvciB7XG4gIHJldHVybiBuZXcgU3RvcmFnZUVycm9yKFxuICAgIFN0b3JhZ2VFcnJvckNvZGUuUFJPSkVDVF9OT1RfRk9VTkQsXG4gICAgXCJQcm9qZWN0ICdcIiArIHByb2plY3QgKyBcIicgZG9lcyBub3QgZXhpc3QuXCJcbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHF1b3RhRXhjZWVkZWQoYnVja2V0OiBzdHJpbmcpOiBTdG9yYWdlRXJyb3Ige1xuICByZXR1cm4gbmV3IFN0b3JhZ2VFcnJvcihcbiAgICBTdG9yYWdlRXJyb3JDb2RlLlFVT1RBX0VYQ0VFREVELFxuICAgIFwiUXVvdGEgZm9yIGJ1Y2tldCAnXCIgK1xuICAgICAgYnVja2V0ICtcbiAgICAgIFwiJyBleGNlZWRlZCwgcGxlYXNlIHZpZXcgcXVvdGEgb24gXCIgK1xuICAgICAgJ2h0dHBzOi8vZmlyZWJhc2UuZ29vZ2xlLmNvbS9wcmljaW5nLy4nXG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1bmF1dGhlbnRpY2F0ZWQoKTogU3RvcmFnZUVycm9yIHtcbiAgY29uc3QgbWVzc2FnZSA9XG4gICAgJ1VzZXIgaXMgbm90IGF1dGhlbnRpY2F0ZWQsIHBsZWFzZSBhdXRoZW50aWNhdGUgdXNpbmcgRmlyZWJhc2UgJyArXG4gICAgJ0F1dGhlbnRpY2F0aW9uIGFuZCB0cnkgYWdhaW4uJztcbiAgcmV0dXJuIG5ldyBTdG9yYWdlRXJyb3IoU3RvcmFnZUVycm9yQ29kZS5VTkFVVEhFTlRJQ0FURUQsIG1lc3NhZ2UpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdW5hdXRob3JpemVkQXBwKCk6IFN0b3JhZ2VFcnJvciB7XG4gIHJldHVybiBuZXcgU3RvcmFnZUVycm9yKFxuICAgIFN0b3JhZ2VFcnJvckNvZGUuVU5BVVRIT1JJWkVEX0FQUCxcbiAgICAnVGhpcyBhcHAgZG9lcyBub3QgaGF2ZSBwZXJtaXNzaW9uIHRvIGFjY2VzcyBGaXJlYmFzZSBTdG9yYWdlIG9uIHRoaXMgcHJvamVjdC4nXG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1bmF1dGhvcml6ZWQocGF0aDogc3RyaW5nKTogU3RvcmFnZUVycm9yIHtcbiAgcmV0dXJuIG5ldyBTdG9yYWdlRXJyb3IoXG4gICAgU3RvcmFnZUVycm9yQ29kZS5VTkFVVEhPUklaRUQsXG4gICAgXCJVc2VyIGRvZXMgbm90IGhhdmUgcGVybWlzc2lvbiB0byBhY2Nlc3MgJ1wiICsgcGF0aCArIFwiJy5cIlxuICApO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcmV0cnlMaW1pdEV4Y2VlZGVkKCk6IFN0b3JhZ2VFcnJvciB7XG4gIHJldHVybiBuZXcgU3RvcmFnZUVycm9yKFxuICAgIFN0b3JhZ2VFcnJvckNvZGUuUkVUUllfTElNSVRfRVhDRUVERUQsXG4gICAgJ01heCByZXRyeSB0aW1lIGZvciBvcGVyYXRpb24gZXhjZWVkZWQsIHBsZWFzZSB0cnkgYWdhaW4uJ1xuICApO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaW52YWxpZENoZWNrc3VtKFxuICBwYXRoOiBzdHJpbmcsXG4gIGNoZWNrc3VtOiBzdHJpbmcsXG4gIGNhbGN1bGF0ZWQ6IHN0cmluZ1xuKTogU3RvcmFnZUVycm9yIHtcbiAgcmV0dXJuIG5ldyBTdG9yYWdlRXJyb3IoXG4gICAgU3RvcmFnZUVycm9yQ29kZS5JTlZBTElEX0NIRUNLU1VNLFxuICAgIFwiVXBsb2FkZWQvZG93bmxvYWRlZCBvYmplY3QgJ1wiICtcbiAgICAgIHBhdGggK1xuICAgICAgXCInIGhhcyBjaGVja3N1bSAnXCIgK1xuICAgICAgY2hlY2tzdW0gK1xuICAgICAgXCInIHdoaWNoIGRvZXMgbm90IG1hdGNoICdcIiArXG4gICAgICBjYWxjdWxhdGVkICtcbiAgICAgIFwiJy4gUGxlYXNlIHJldHJ5IHRoZSB1cGxvYWQvZG93bmxvYWQuXCJcbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNhbmNlbGVkKCk6IFN0b3JhZ2VFcnJvciB7XG4gIHJldHVybiBuZXcgU3RvcmFnZUVycm9yKFxuICAgIFN0b3JhZ2VFcnJvckNvZGUuQ0FOQ0VMRUQsXG4gICAgJ1VzZXIgY2FuY2VsZWQgdGhlIHVwbG9hZC9kb3dubG9hZC4nXG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpbnZhbGlkRXZlbnROYW1lKG5hbWU6IHN0cmluZyk6IFN0b3JhZ2VFcnJvciB7XG4gIHJldHVybiBuZXcgU3RvcmFnZUVycm9yKFxuICAgIFN0b3JhZ2VFcnJvckNvZGUuSU5WQUxJRF9FVkVOVF9OQU1FLFxuICAgIFwiSW52YWxpZCBldmVudCBuYW1lICdcIiArIG5hbWUgKyBcIicuXCJcbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGludmFsaWRVcmwodXJsOiBzdHJpbmcpOiBTdG9yYWdlRXJyb3Ige1xuICByZXR1cm4gbmV3IFN0b3JhZ2VFcnJvcihcbiAgICBTdG9yYWdlRXJyb3JDb2RlLklOVkFMSURfVVJMLFxuICAgIFwiSW52YWxpZCBVUkwgJ1wiICsgdXJsICsgXCInLlwiXG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpbnZhbGlkRGVmYXVsdEJ1Y2tldChidWNrZXQ6IHN0cmluZyk6IFN0b3JhZ2VFcnJvciB7XG4gIHJldHVybiBuZXcgU3RvcmFnZUVycm9yKFxuICAgIFN0b3JhZ2VFcnJvckNvZGUuSU5WQUxJRF9ERUZBVUxUX0JVQ0tFVCxcbiAgICBcIkludmFsaWQgZGVmYXVsdCBidWNrZXQgJ1wiICsgYnVja2V0ICsgXCInLlwiXG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBub0RlZmF1bHRCdWNrZXQoKTogU3RvcmFnZUVycm9yIHtcbiAgcmV0dXJuIG5ldyBTdG9yYWdlRXJyb3IoXG4gICAgU3RvcmFnZUVycm9yQ29kZS5OT19ERUZBVUxUX0JVQ0tFVCxcbiAgICAnTm8gZGVmYXVsdCBidWNrZXQgJyArXG4gICAgICBcImZvdW5kLiBEaWQgeW91IHNldCB0aGUgJ1wiICtcbiAgICAgIENPTkZJR19TVE9SQUdFX0JVQ0tFVF9LRVkgK1xuICAgICAgXCInIHByb3BlcnR5IHdoZW4gaW5pdGlhbGl6aW5nIHRoZSBhcHA/XCJcbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGNhbm5vdFNsaWNlQmxvYigpOiBTdG9yYWdlRXJyb3Ige1xuICByZXR1cm4gbmV3IFN0b3JhZ2VFcnJvcihcbiAgICBTdG9yYWdlRXJyb3JDb2RlLkNBTk5PVF9TTElDRV9CTE9CLFxuICAgICdDYW5ub3Qgc2xpY2UgYmxvYiBmb3IgdXBsb2FkLiBQbGVhc2UgcmV0cnkgdGhlIHVwbG9hZC4nXG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzZXJ2ZXJGaWxlV3JvbmdTaXplKCk6IFN0b3JhZ2VFcnJvciB7XG4gIHJldHVybiBuZXcgU3RvcmFnZUVycm9yKFxuICAgIFN0b3JhZ2VFcnJvckNvZGUuU0VSVkVSX0ZJTEVfV1JPTkdfU0laRSxcbiAgICAnU2VydmVyIHJlY29yZGVkIGluY29ycmVjdCB1cGxvYWQgZmlsZSBzaXplLCBwbGVhc2UgcmV0cnkgdGhlIHVwbG9hZC4nXG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBub0Rvd25sb2FkVVJMKCk6IFN0b3JhZ2VFcnJvciB7XG4gIHJldHVybiBuZXcgU3RvcmFnZUVycm9yKFxuICAgIFN0b3JhZ2VFcnJvckNvZGUuTk9fRE9XTkxPQURfVVJMLFxuICAgICdUaGUgZ2l2ZW4gZmlsZSBkb2VzIG5vdCBoYXZlIGFueSBkb3dubG9hZCBVUkxzLidcbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG1pc3NpbmdQb2x5RmlsbChwb2x5RmlsbDogc3RyaW5nKTogU3RvcmFnZUVycm9yIHtcbiAgcmV0dXJuIG5ldyBTdG9yYWdlRXJyb3IoXG4gICAgU3RvcmFnZUVycm9yQ29kZS5VTlNVUFBPUlRFRF9FTlZJUk9OTUVOVCxcbiAgICBgJHtwb2x5RmlsbH0gaXMgbWlzc2luZy4gTWFrZSBzdXJlIHRvIGluc3RhbGwgdGhlIHJlcXVpcmVkIHBvbHlmaWxscy4gU2VlIGh0dHBzOi8vZmlyZWJhc2UuZ29vZ2xlLmNvbS9kb2NzL3dlYi9lbnZpcm9ubWVudHMtanMtc2RrI3BvbHlmaWxscyBmb3IgbW9yZSBpbmZvcm1hdGlvbi5gXG4gICk7XG59XG5cbi8qKlxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpbnZhbGlkQXJndW1lbnQobWVzc2FnZTogc3RyaW5nKTogU3RvcmFnZUVycm9yIHtcbiAgcmV0dXJuIG5ldyBTdG9yYWdlRXJyb3IoU3RvcmFnZUVycm9yQ29kZS5JTlZBTElEX0FSR1VNRU5ULCBtZXNzYWdlKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGludmFsaWRBcmd1bWVudENvdW50KFxuICBhcmdNaW46IG51bWJlcixcbiAgYXJnTWF4OiBudW1iZXIsXG4gIGZuTmFtZTogc3RyaW5nLFxuICByZWFsOiBudW1iZXJcbik6IFN0b3JhZ2VFcnJvciB7XG4gIGxldCBjb3VudFBhcnQ7XG4gIGxldCBwbHVyYWw7XG4gIGlmIChhcmdNaW4gPT09IGFyZ01heCkge1xuICAgIGNvdW50UGFydCA9IGFyZ01pbjtcbiAgICBwbHVyYWwgPSBhcmdNaW4gPT09IDEgPyAnYXJndW1lbnQnIDogJ2FyZ3VtZW50cyc7XG4gIH0gZWxzZSB7XG4gICAgY291bnRQYXJ0ID0gJ2JldHdlZW4gJyArIGFyZ01pbiArICcgYW5kICcgKyBhcmdNYXg7XG4gICAgcGx1cmFsID0gJ2FyZ3VtZW50cyc7XG4gIH1cbiAgcmV0dXJuIG5ldyBTdG9yYWdlRXJyb3IoXG4gICAgU3RvcmFnZUVycm9yQ29kZS5JTlZBTElEX0FSR1VNRU5UX0NPVU5ULFxuICAgICdJbnZhbGlkIGFyZ3VtZW50IGNvdW50IGluIGAnICtcbiAgICAgIGZuTmFtZSArXG4gICAgICAnYDogRXhwZWN0ZWQgJyArXG4gICAgICBjb3VudFBhcnQgK1xuICAgICAgJyAnICtcbiAgICAgIHBsdXJhbCArXG4gICAgICAnLCByZWNlaXZlZCAnICtcbiAgICAgIHJlYWwgK1xuICAgICAgJy4nXG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhcHBEZWxldGVkKCk6IFN0b3JhZ2VFcnJvciB7XG4gIHJldHVybiBuZXcgU3RvcmFnZUVycm9yKFxuICAgIFN0b3JhZ2VFcnJvckNvZGUuQVBQX0RFTEVURUQsXG4gICAgJ1RoZSBGaXJlYmFzZSBhcHAgd2FzIGRlbGV0ZWQuJ1xuICApO1xufVxuXG4vKipcbiAqIEBwYXJhbSBuYW1lIC0gVGhlIG5hbWUgb2YgdGhlIG9wZXJhdGlvbiB0aGF0IHdhcyBpbnZhbGlkLlxuICpcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgZnVuY3Rpb24gaW52YWxpZFJvb3RPcGVyYXRpb24obmFtZTogc3RyaW5nKTogU3RvcmFnZUVycm9yIHtcbiAgcmV0dXJuIG5ldyBTdG9yYWdlRXJyb3IoXG4gICAgU3RvcmFnZUVycm9yQ29kZS5JTlZBTElEX1JPT1RfT1BFUkFUSU9OLFxuICAgIFwiVGhlIG9wZXJhdGlvbiAnXCIgK1xuICAgICAgbmFtZSArXG4gICAgICBcIicgY2Fubm90IGJlIHBlcmZvcm1lZCBvbiBhIHJvb3QgcmVmZXJlbmNlLCBjcmVhdGUgYSBub24tcm9vdCBcIiArXG4gICAgICBcInJlZmVyZW5jZSB1c2luZyBjaGlsZCwgc3VjaCBhcyAuY2hpbGQoJ2ZpbGUucG5nJykuXCJcbiAgKTtcbn1cblxuLyoqXG4gKiBAcGFyYW0gZm9ybWF0IC0gVGhlIGZvcm1hdCB0aGF0IHdhcyBub3QgdmFsaWQuXG4gKiBAcGFyYW0gbWVzc2FnZSAtIEEgbWVzc2FnZSBkZXNjcmliaW5nIHRoZSBmb3JtYXQgdmlvbGF0aW9uLlxuICovXG5leHBvcnQgZnVuY3Rpb24gaW52YWxpZEZvcm1hdChmb3JtYXQ6IHN0cmluZywgbWVzc2FnZTogc3RyaW5nKTogU3RvcmFnZUVycm9yIHtcbiAgcmV0dXJuIG5ldyBTdG9yYWdlRXJyb3IoXG4gICAgU3RvcmFnZUVycm9yQ29kZS5JTlZBTElEX0ZPUk1BVCxcbiAgICBcIlN0cmluZyBkb2VzIG5vdCBtYXRjaCBmb3JtYXQgJ1wiICsgZm9ybWF0ICsgXCInOiBcIiArIG1lc3NhZ2VcbiAgKTtcbn1cblxuLyoqXG4gKiBAcGFyYW0gbWVzc2FnZSAtIEEgbWVzc2FnZSBkZXNjcmliaW5nIHRoZSBpbnRlcm5hbCBlcnJvci5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVuc3VwcG9ydGVkRW52aXJvbm1lbnQobWVzc2FnZTogc3RyaW5nKTogU3RvcmFnZUVycm9yIHtcbiAgdGhyb3cgbmV3IFN0b3JhZ2VFcnJvcihTdG9yYWdlRXJyb3JDb2RlLlVOU1VQUE9SVEVEX0VOVklST05NRU5ULCBtZXNzYWdlKTtcbn1cblxuLyoqXG4gKiBAcGFyYW0gbWVzc2FnZSAtIEEgbWVzc2FnZSBkZXNjcmliaW5nIHRoZSBpbnRlcm5hbCBlcnJvci5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGludGVybmFsRXJyb3IobWVzc2FnZTogc3RyaW5nKTogU3RvcmFnZUVycm9yIHtcbiAgdGhyb3cgbmV3IFN0b3JhZ2VFcnJvcihcbiAgICBTdG9yYWdlRXJyb3JDb2RlLklOVEVSTkFMX0VSUk9SLFxuICAgICdJbnRlcm5hbCBlcnJvcjogJyArIG1lc3NhZ2VcbiAgKTtcbn1cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDE3IEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbi8qKlxuICogQGZpbGVvdmVydmlldyBGdW5jdGlvbmFsaXR5IHJlbGF0ZWQgdG8gdGhlIHBhcnNpbmcvY29tcG9zaXRpb24gb2YgYnVja2V0L1xuICogb2JqZWN0IGxvY2F0aW9uLlxuICovXG5cbmltcG9ydCB7IGludmFsaWREZWZhdWx0QnVja2V0LCBpbnZhbGlkVXJsIH0gZnJvbSAnLi9lcnJvcic7XG5pbXBvcnQgeyBERUZBVUxUX0hPU1QgfSBmcm9tICcuL2NvbnN0YW50cyc7XG5cbi8qKlxuICogRmlyZWJhc2UgU3RvcmFnZSBsb2NhdGlvbiBkYXRhLlxuICpcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgY2xhc3MgTG9jYXRpb24ge1xuICBwcml2YXRlIHBhdGhfOiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IocHVibGljIHJlYWRvbmx5IGJ1Y2tldDogc3RyaW5nLCBwYXRoOiBzdHJpbmcpIHtcbiAgICB0aGlzLnBhdGhfID0gcGF0aDtcbiAgfVxuXG4gIGdldCBwYXRoKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHRoaXMucGF0aF87XG4gIH1cblxuICBnZXQgaXNSb290KCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLnBhdGgubGVuZ3RoID09PSAwO1xuICB9XG5cbiAgZnVsbFNlcnZlclVybCgpOiBzdHJpbmcge1xuICAgIGNvbnN0IGVuY29kZSA9IGVuY29kZVVSSUNvbXBvbmVudDtcbiAgICByZXR1cm4gJy9iLycgKyBlbmNvZGUodGhpcy5idWNrZXQpICsgJy9vLycgKyBlbmNvZGUodGhpcy5wYXRoKTtcbiAgfVxuXG4gIGJ1Y2tldE9ubHlTZXJ2ZXJVcmwoKTogc3RyaW5nIHtcbiAgICBjb25zdCBlbmNvZGUgPSBlbmNvZGVVUklDb21wb25lbnQ7XG4gICAgcmV0dXJuICcvYi8nICsgZW5jb2RlKHRoaXMuYnVja2V0KSArICcvbyc7XG4gIH1cblxuICBzdGF0aWMgbWFrZUZyb21CdWNrZXRTcGVjKGJ1Y2tldFN0cmluZzogc3RyaW5nLCBob3N0OiBzdHJpbmcpOiBMb2NhdGlvbiB7XG4gICAgbGV0IGJ1Y2tldExvY2F0aW9uO1xuICAgIHRyeSB7XG4gICAgICBidWNrZXRMb2NhdGlvbiA9IExvY2F0aW9uLm1ha2VGcm9tVXJsKGJ1Y2tldFN0cmluZywgaG9zdCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgLy8gTm90IHZhbGlkIFVSTCwgdXNlIGFzLWlzLiBUaGlzIGxldHMgeW91IHB1dCBiYXJlIGJ1Y2tldCBuYW1lcyBpblxuICAgICAgLy8gY29uZmlnLlxuICAgICAgcmV0dXJuIG5ldyBMb2NhdGlvbihidWNrZXRTdHJpbmcsICcnKTtcbiAgICB9XG4gICAgaWYgKGJ1Y2tldExvY2F0aW9uLnBhdGggPT09ICcnKSB7XG4gICAgICByZXR1cm4gYnVja2V0TG9jYXRpb247XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IGludmFsaWREZWZhdWx0QnVja2V0KGJ1Y2tldFN0cmluZyk7XG4gICAgfVxuICB9XG5cbiAgc3RhdGljIG1ha2VGcm9tVXJsKHVybDogc3RyaW5nLCBob3N0OiBzdHJpbmcpOiBMb2NhdGlvbiB7XG4gICAgbGV0IGxvY2F0aW9uOiBMb2NhdGlvbiB8IG51bGwgPSBudWxsO1xuICAgIGNvbnN0IGJ1Y2tldERvbWFpbiA9ICcoW0EtWmEtejAtOS5cXFxcLV9dKyknO1xuXG4gICAgZnVuY3Rpb24gZ3NNb2RpZnkobG9jOiBMb2NhdGlvbik6IHZvaWQge1xuICAgICAgaWYgKGxvYy5wYXRoLmNoYXJBdChsb2MucGF0aC5sZW5ndGggLSAxKSA9PT0gJy8nKSB7XG4gICAgICAgIGxvYy5wYXRoXyA9IGxvYy5wYXRoXy5zbGljZSgwLCAtMSk7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGdzUGF0aCA9ICcoLyguKikpPyQnO1xuICAgIGNvbnN0IGdzUmVnZXggPSBuZXcgUmVnRXhwKCdeZ3M6Ly8nICsgYnVja2V0RG9tYWluICsgZ3NQYXRoLCAnaScpO1xuICAgIGNvbnN0IGdzSW5kaWNlcyA9IHsgYnVja2V0OiAxLCBwYXRoOiAzIH07XG5cbiAgICBmdW5jdGlvbiBodHRwTW9kaWZ5KGxvYzogTG9jYXRpb24pOiB2b2lkIHtcbiAgICAgIGxvYy5wYXRoXyA9IGRlY29kZVVSSUNvbXBvbmVudChsb2MucGF0aCk7XG4gICAgfVxuICAgIGNvbnN0IHZlcnNpb24gPSAndltBLVphLXowLTlfXSsnO1xuICAgIGNvbnN0IGZpcmViYXNlU3RvcmFnZUhvc3QgPSBob3N0LnJlcGxhY2UoL1suXS9nLCAnXFxcXC4nKTtcbiAgICBjb25zdCBmaXJlYmFzZVN0b3JhZ2VQYXRoID0gJygvKFtePyNdKikuKik/JCc7XG4gICAgY29uc3QgZmlyZWJhc2VTdG9yYWdlUmVnRXhwID0gbmV3IFJlZ0V4cChcbiAgICAgIGBeaHR0cHM/Oi8vJHtmaXJlYmFzZVN0b3JhZ2VIb3N0fS8ke3ZlcnNpb259L2IvJHtidWNrZXREb21haW59L28ke2ZpcmViYXNlU3RvcmFnZVBhdGh9YCxcbiAgICAgICdpJ1xuICAgICk7XG4gICAgY29uc3QgZmlyZWJhc2VTdG9yYWdlSW5kaWNlcyA9IHsgYnVja2V0OiAxLCBwYXRoOiAzIH07XG5cbiAgICBjb25zdCBjbG91ZFN0b3JhZ2VIb3N0ID1cbiAgICAgIGhvc3QgPT09IERFRkFVTFRfSE9TVFxuICAgICAgICA/ICcoPzpzdG9yYWdlLmdvb2dsZWFwaXMuY29tfHN0b3JhZ2UuY2xvdWQuZ29vZ2xlLmNvbSknXG4gICAgICAgIDogaG9zdDtcbiAgICBjb25zdCBjbG91ZFN0b3JhZ2VQYXRoID0gJyhbXj8jXSopJztcbiAgICBjb25zdCBjbG91ZFN0b3JhZ2VSZWdFeHAgPSBuZXcgUmVnRXhwKFxuICAgICAgYF5odHRwcz86Ly8ke2Nsb3VkU3RvcmFnZUhvc3R9LyR7YnVja2V0RG9tYWlufS8ke2Nsb3VkU3RvcmFnZVBhdGh9YCxcbiAgICAgICdpJ1xuICAgICk7XG4gICAgY29uc3QgY2xvdWRTdG9yYWdlSW5kaWNlcyA9IHsgYnVja2V0OiAxLCBwYXRoOiAyIH07XG5cbiAgICBjb25zdCBncm91cHMgPSBbXG4gICAgICB7IHJlZ2V4OiBnc1JlZ2V4LCBpbmRpY2VzOiBnc0luZGljZXMsIHBvc3RNb2RpZnk6IGdzTW9kaWZ5IH0sXG4gICAgICB7XG4gICAgICAgIHJlZ2V4OiBmaXJlYmFzZVN0b3JhZ2VSZWdFeHAsXG4gICAgICAgIGluZGljZXM6IGZpcmViYXNlU3RvcmFnZUluZGljZXMsXG4gICAgICAgIHBvc3RNb2RpZnk6IGh0dHBNb2RpZnlcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHJlZ2V4OiBjbG91ZFN0b3JhZ2VSZWdFeHAsXG4gICAgICAgIGluZGljZXM6IGNsb3VkU3RvcmFnZUluZGljZXMsXG4gICAgICAgIHBvc3RNb2RpZnk6IGh0dHBNb2RpZnlcbiAgICAgIH1cbiAgICBdO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZ3JvdXBzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBncm91cCA9IGdyb3Vwc1tpXTtcbiAgICAgIGNvbnN0IGNhcHR1cmVzID0gZ3JvdXAucmVnZXguZXhlYyh1cmwpO1xuICAgICAgaWYgKGNhcHR1cmVzKSB7XG4gICAgICAgIGNvbnN0IGJ1Y2tldFZhbHVlID0gY2FwdHVyZXNbZ3JvdXAuaW5kaWNlcy5idWNrZXRdO1xuICAgICAgICBsZXQgcGF0aFZhbHVlID0gY2FwdHVyZXNbZ3JvdXAuaW5kaWNlcy5wYXRoXTtcbiAgICAgICAgaWYgKCFwYXRoVmFsdWUpIHtcbiAgICAgICAgICBwYXRoVmFsdWUgPSAnJztcbiAgICAgICAgfVxuICAgICAgICBsb2NhdGlvbiA9IG5ldyBMb2NhdGlvbihidWNrZXRWYWx1ZSwgcGF0aFZhbHVlKTtcbiAgICAgICAgZ3JvdXAucG9zdE1vZGlmeShsb2NhdGlvbik7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAobG9jYXRpb24gPT0gbnVsbCkge1xuICAgICAgdGhyb3cgaW52YWxpZFVybCh1cmwpO1xuICAgIH1cbiAgICByZXR1cm4gbG9jYXRpb247XG4gIH1cbn1cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDE3IEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5pbXBvcnQgeyBTdG9yYWdlRXJyb3IgfSBmcm9tICcuL2Vycm9yJztcbmltcG9ydCB7IFJlcXVlc3QgfSBmcm9tICcuL3JlcXVlc3QnO1xuXG4vKipcbiAqIEEgcmVxdWVzdCB3aG9zZSBwcm9taXNlIGFsd2F5cyBmYWlscy5cbiAqL1xuZXhwb3J0IGNsYXNzIEZhaWxSZXF1ZXN0PFQ+IGltcGxlbWVudHMgUmVxdWVzdDxUPiB7XG4gIHByb21pc2VfOiBQcm9taXNlPFQ+O1xuXG4gIGNvbnN0cnVjdG9yKGVycm9yOiBTdG9yYWdlRXJyb3IpIHtcbiAgICB0aGlzLnByb21pc2VfID0gUHJvbWlzZS5yZWplY3Q8VD4oZXJyb3IpO1xuICB9XG5cbiAgLyoqIEBpbmhlcml0RG9jICovXG4gIGdldFByb21pc2UoKTogUHJvbWlzZTxUPiB7XG4gICAgcmV0dXJuIHRoaXMucHJvbWlzZV87XG4gIH1cblxuICAvKiogQGluaGVyaXREb2MgKi9cbiAgY2FuY2VsKF9hcHBEZWxldGUgPSBmYWxzZSk6IHZvaWQge31cbn1cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDE3IEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbi8qKlxuICogQGZpbGVvdmVydmlldyBQcm92aWRlcyBhIG1ldGhvZCBmb3IgcnVubmluZyBhIGZ1bmN0aW9uIHdpdGggZXhwb25lbnRpYWxcbiAqIGJhY2tvZmYuXG4gKi9cbnR5cGUgaWQgPSAocDE6IGJvb2xlYW4pID0+IHZvaWQ7XG5cbmV4cG9ydCB7IGlkIH07XG5cbi8qKlxuICogQWNjZXB0cyBhIGNhbGxiYWNrIGZvciBhbiBhY3Rpb24gdG8gcGVyZm9ybSAoYGRvUmVxdWVzdGApLFxuICogYW5kIHRoZW4gYSBjYWxsYmFjayBmb3Igd2hlbiB0aGUgYmFja29mZiBoYXMgY29tcGxldGVkIChgYmFja29mZkNvbXBsZXRlQ2JgKS5cbiAqIFRoZSBjYWxsYmFjayBzZW50IHRvIHN0YXJ0IHJlcXVpcmVzIGFuIGFyZ3VtZW50IHRvIGNhbGwgKGBvblJlcXVlc3RDb21wbGV0ZWApLlxuICogV2hlbiBgc3RhcnRgIGNhbGxzIGBkb1JlcXVlc3RgLCBpdCBwYXNzZXMgYSBjYWxsYmFjayBmb3Igd2hlbiB0aGUgcmVxdWVzdCBoYXNcbiAqIGNvbXBsZXRlZCwgYG9uUmVxdWVzdENvbXBsZXRlYC4gQmFzZWQgb24gdGhpcywgdGhlIGJhY2tvZmYgY29udGludWVzLCB3aXRoXG4gKiBhbm90aGVyIGNhbGwgdG8gYGRvUmVxdWVzdGAgYW5kIHRoZSBhYm92ZSBsb29wIGNvbnRpbnVlcyB1bnRpbCB0aGUgdGltZW91dFxuICogaXMgaGl0LCBvciBhIHN1Y2Nlc3NmdWwgcmVzcG9uc2Ugb2NjdXJzLlxuICogQGRlc2NyaXB0aW9uXG4gKiBAcGFyYW0gZG9SZXF1ZXN0IENhbGxiYWNrIHRvIHBlcmZvcm0gcmVxdWVzdFxuICogQHBhcmFtIGJhY2tvZmZDb21wbGV0ZUNiIENhbGxiYWNrIHRvIGNhbGwgd2hlbiBiYWNrb2ZmIGhhcyBiZWVuIGNvbXBsZXRlZFxuICovXG5leHBvcnQgZnVuY3Rpb24gc3RhcnQoXG4gIGRvUmVxdWVzdDogKFxuICAgIG9uUmVxdWVzdENvbXBsZXRlOiAoc3VjY2VzczogYm9vbGVhbikgPT4gdm9pZCxcbiAgICBjYW5jZWxlZDogYm9vbGVhblxuICApID0+IHZvaWQsXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gIGJhY2tvZmZDb21wbGV0ZUNiOiAoLi4uYXJnczogYW55W10pID0+IHVua25vd24sXG4gIHRpbWVvdXQ6IG51bWJlclxuKTogaWQge1xuICAvLyBUT0RPKGFuZHlzb3RvKTogbWFrZSB0aGlzIGNvZGUgY2xlYW5lciAocHJvYmFibHkgcmVmYWN0b3IgaW50byBhbiBhY3R1YWxcbiAgLy8gdHlwZSBpbnN0ZWFkIG9mIGEgYnVuY2ggb2YgZnVuY3Rpb25zIHdpdGggc3RhdGUgc2hhcmVkIGluIHRoZSBjbG9zdXJlKVxuICBsZXQgd2FpdFNlY29uZHMgPSAxO1xuICAvLyBXb3VsZCB0eXBlIHRoaXMgYXMgXCJudW1iZXJcIiBidXQgdGhhdCBkb2Vzbid0IHdvcmsgZm9yIE5vZGUgc28gwq9cXF8o44OEKV8vwq9cbiAgLy8gVE9ETzogZmluZCBhIHdheSB0byBleGNsdWRlIE5vZGUgdHlwZSBkZWZpbml0aW9uIGZvciBzdG9yYWdlIGJlY2F1c2Ugc3RvcmFnZSBvbmx5IHdvcmtzIGluIGJyb3dzZXJcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbiAgbGV0IHJldHJ5VGltZW91dElkOiBhbnkgPSBudWxsO1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICBsZXQgZ2xvYmFsVGltZW91dElkOiBhbnkgPSBudWxsO1xuICBsZXQgaGl0VGltZW91dCA9IGZhbHNlO1xuICBsZXQgY2FuY2VsU3RhdGUgPSAwO1xuXG4gIGZ1bmN0aW9uIGNhbmNlbGVkKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiBjYW5jZWxTdGF0ZSA9PT0gMjtcbiAgfVxuICBsZXQgdHJpZ2dlcmVkQ2FsbGJhY2sgPSBmYWxzZTtcblxuICBmdW5jdGlvbiB0cmlnZ2VyQ2FsbGJhY2soLi4uYXJnczogYW55W10pOiB2b2lkIHtcbiAgICBpZiAoIXRyaWdnZXJlZENhbGxiYWNrKSB7XG4gICAgICB0cmlnZ2VyZWRDYWxsYmFjayA9IHRydWU7XG4gICAgICBiYWNrb2ZmQ29tcGxldGVDYi5hcHBseShudWxsLCBhcmdzKTtcbiAgICB9XG4gIH1cblxuICBmdW5jdGlvbiBjYWxsV2l0aERlbGF5KG1pbGxpczogbnVtYmVyKTogdm9pZCB7XG4gICAgcmV0cnlUaW1lb3V0SWQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHJldHJ5VGltZW91dElkID0gbnVsbDtcbiAgICAgIGRvUmVxdWVzdChyZXNwb25zZUhhbmRsZXIsIGNhbmNlbGVkKCkpO1xuICAgIH0sIG1pbGxpcyk7XG4gIH1cblxuICBmdW5jdGlvbiBjbGVhckdsb2JhbFRpbWVvdXQoKTogdm9pZCB7XG4gICAgaWYgKGdsb2JhbFRpbWVvdXRJZCkge1xuICAgICAgY2xlYXJUaW1lb3V0KGdsb2JhbFRpbWVvdXRJZCk7XG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gcmVzcG9uc2VIYW5kbGVyKHN1Y2Nlc3M6IGJvb2xlYW4sIC4uLmFyZ3M6IGFueVtdKTogdm9pZCB7XG4gICAgaWYgKHRyaWdnZXJlZENhbGxiYWNrKSB7XG4gICAgICBjbGVhckdsb2JhbFRpbWVvdXQoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHN1Y2Nlc3MpIHtcbiAgICAgIGNsZWFyR2xvYmFsVGltZW91dCgpO1xuICAgICAgdHJpZ2dlckNhbGxiYWNrLmNhbGwobnVsbCwgc3VjY2VzcywgLi4uYXJncyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IG11c3RTdG9wID0gY2FuY2VsZWQoKSB8fCBoaXRUaW1lb3V0O1xuICAgIGlmIChtdXN0U3RvcCkge1xuICAgICAgY2xlYXJHbG9iYWxUaW1lb3V0KCk7XG4gICAgICB0cmlnZ2VyQ2FsbGJhY2suY2FsbChudWxsLCBzdWNjZXNzLCAuLi5hcmdzKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHdhaXRTZWNvbmRzIDwgNjQpIHtcbiAgICAgIC8qIFRPRE8oYW5keXNvdG8pOiBkb24ndCBiYWNrIG9mZiBzbyBxdWlja2x5IGlmIHdlIGtub3cgd2UncmUgb2ZmbGluZS4gKi9cbiAgICAgIHdhaXRTZWNvbmRzICo9IDI7XG4gICAgfVxuICAgIGxldCB3YWl0TWlsbGlzO1xuICAgIGlmIChjYW5jZWxTdGF0ZSA9PT0gMSkge1xuICAgICAgY2FuY2VsU3RhdGUgPSAyO1xuICAgICAgd2FpdE1pbGxpcyA9IDA7XG4gICAgfSBlbHNlIHtcbiAgICAgIHdhaXRNaWxsaXMgPSAod2FpdFNlY29uZHMgKyBNYXRoLnJhbmRvbSgpKSAqIDEwMDA7XG4gICAgfVxuICAgIGNhbGxXaXRoRGVsYXkod2FpdE1pbGxpcyk7XG4gIH1cbiAgbGV0IHN0b3BwZWQgPSBmYWxzZTtcblxuICBmdW5jdGlvbiBzdG9wKHdhc1RpbWVvdXQ6IGJvb2xlYW4pOiB2b2lkIHtcbiAgICBpZiAoc3RvcHBlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzdG9wcGVkID0gdHJ1ZTtcbiAgICBjbGVhckdsb2JhbFRpbWVvdXQoKTtcbiAgICBpZiAodHJpZ2dlcmVkQ2FsbGJhY2spIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHJldHJ5VGltZW91dElkICE9PSBudWxsKSB7XG4gICAgICBpZiAoIXdhc1RpbWVvdXQpIHtcbiAgICAgICAgY2FuY2VsU3RhdGUgPSAyO1xuICAgICAgfVxuICAgICAgY2xlYXJUaW1lb3V0KHJldHJ5VGltZW91dElkKTtcbiAgICAgIGNhbGxXaXRoRGVsYXkoMCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmICghd2FzVGltZW91dCkge1xuICAgICAgICBjYW5jZWxTdGF0ZSA9IDE7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGNhbGxXaXRoRGVsYXkoMCk7XG4gIGdsb2JhbFRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgIGhpdFRpbWVvdXQgPSB0cnVlO1xuICAgIHN0b3AodHJ1ZSk7XG4gIH0sIHRpbWVvdXQpO1xuICByZXR1cm4gc3RvcDtcbn1cblxuLyoqXG4gKiBTdG9wcyB0aGUgcmV0cnkgbG9vcCBmcm9tIHJlcGVhdGluZy5cbiAqIElmIHRoZSBmdW5jdGlvbiBpcyBjdXJyZW50bHkgXCJpbiBiZXR3ZWVuXCIgcmV0cmllcywgaXQgaXMgaW52b2tlZCBpbW1lZGlhdGVseVxuICogd2l0aCB0aGUgc2Vjb25kIHBhcmFtZXRlciBhcyBcInRydWVcIi4gT3RoZXJ3aXNlLCBpdCB3aWxsIGJlIGludm9rZWQgb25jZSBtb3JlXG4gKiBhZnRlciB0aGUgY3VycmVudCBpbnZvY2F0aW9uIGZpbmlzaGVzIGlmZiB0aGUgY3VycmVudCBpbnZvY2F0aW9uIHdvdWxkIGhhdmVcbiAqIHRyaWdnZXJlZCBhbm90aGVyIHJldHJ5LlxuICovXG5leHBvcnQgZnVuY3Rpb24gc3RvcChpZDogaWQpOiB2b2lkIHtcbiAgaWQoZmFsc2UpO1xufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMTcgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgaW52YWxpZEFyZ3VtZW50IH0gZnJvbSAnLi9lcnJvcic7XG5cbmV4cG9ydCBmdW5jdGlvbiBpc0p1c3REZWY8VD4ocDogVCB8IG51bGwgfCB1bmRlZmluZWQpOiBwIGlzIFQgfCBudWxsIHtcbiAgcmV0dXJuIHAgIT09IHZvaWQgMDtcbn1cblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHlwZXNcbmV4cG9ydCBmdW5jdGlvbiBpc0Z1bmN0aW9uKHA6IHVua25vd24pOiBwIGlzIEZ1bmN0aW9uIHtcbiAgcmV0dXJuIHR5cGVvZiBwID09PSAnZnVuY3Rpb24nO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNOb25BcnJheU9iamVjdChwOiB1bmtub3duKTogYm9vbGVhbiB7XG4gIHJldHVybiB0eXBlb2YgcCA9PT0gJ29iamVjdCcgJiYgIUFycmF5LmlzQXJyYXkocCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc1N0cmluZyhwOiB1bmtub3duKTogcCBpcyBzdHJpbmcge1xuICByZXR1cm4gdHlwZW9mIHAgPT09ICdzdHJpbmcnIHx8IHAgaW5zdGFuY2VvZiBTdHJpbmc7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc05hdGl2ZUJsb2IocDogdW5rbm93bik6IHAgaXMgQmxvYiB7XG4gIHJldHVybiBpc05hdGl2ZUJsb2JEZWZpbmVkKCkgJiYgcCBpbnN0YW5jZW9mIEJsb2I7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpc05hdGl2ZUJsb2JEZWZpbmVkKCk6IGJvb2xlYW4ge1xuICByZXR1cm4gdHlwZW9mIEJsb2IgIT09ICd1bmRlZmluZWQnO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGVOdW1iZXIoXG4gIGFyZ3VtZW50OiBzdHJpbmcsXG4gIG1pblZhbHVlOiBudW1iZXIsXG4gIG1heFZhbHVlOiBudW1iZXIsXG4gIHZhbHVlOiBudW1iZXJcbik6IHZvaWQge1xuICBpZiAodmFsdWUgPCBtaW5WYWx1ZSkge1xuICAgIHRocm93IGludmFsaWRBcmd1bWVudChcbiAgICAgIGBJbnZhbGlkIHZhbHVlIGZvciAnJHthcmd1bWVudH0nLiBFeHBlY3RlZCAke21pblZhbHVlfSBvciBncmVhdGVyLmBcbiAgICApO1xuICB9XG4gIGlmICh2YWx1ZSA+IG1heFZhbHVlKSB7XG4gICAgdGhyb3cgaW52YWxpZEFyZ3VtZW50KFxuICAgICAgYEludmFsaWQgdmFsdWUgZm9yICcke2FyZ3VtZW50fScuIEV4cGVjdGVkICR7bWF4VmFsdWV9IG9yIGxlc3MuYFxuICAgICk7XG4gIH1cbn1cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDE3IEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbi8qKlxuICogQGZpbGVvdmVydmlldyBGdW5jdGlvbnMgdG8gY3JlYXRlIGFuZCBtYW5pcHVsYXRlIFVSTHMgZm9yIHRoZSBzZXJ2ZXIgQVBJLlxuICovXG5pbXBvcnQgeyBVcmxQYXJhbXMgfSBmcm9tICcuL3JlcXVlc3RpbmZvJztcblxuZXhwb3J0IGZ1bmN0aW9uIG1ha2VVcmwoXG4gIHVybFBhcnQ6IHN0cmluZyxcbiAgaG9zdDogc3RyaW5nLFxuICBwcm90b2NvbDogc3RyaW5nXG4pOiBzdHJpbmcge1xuICBsZXQgb3JpZ2luID0gaG9zdDtcbiAgaWYgKHByb3RvY29sID09IG51bGwpIHtcbiAgICBvcmlnaW4gPSBgaHR0cHM6Ly8ke2hvc3R9YDtcbiAgfVxuICByZXR1cm4gYCR7cHJvdG9jb2x9Oi8vJHtvcmlnaW59L3YwJHt1cmxQYXJ0fWA7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBtYWtlUXVlcnlTdHJpbmcocGFyYW1zOiBVcmxQYXJhbXMpOiBzdHJpbmcge1xuICBjb25zdCBlbmNvZGUgPSBlbmNvZGVVUklDb21wb25lbnQ7XG4gIGxldCBxdWVyeVBhcnQgPSAnPyc7XG4gIGZvciAoY29uc3Qga2V5IGluIHBhcmFtcykge1xuICAgIGlmIChwYXJhbXMuaGFzT3duUHJvcGVydHkoa2V5KSkge1xuICAgICAgY29uc3QgbmV4dFBhcnQgPSBlbmNvZGUoa2V5KSArICc9JyArIGVuY29kZShwYXJhbXNba2V5XSk7XG4gICAgICBxdWVyeVBhcnQgPSBxdWVyeVBhcnQgKyBuZXh0UGFydCArICcmJztcbiAgICB9XG4gIH1cblxuICAvLyBDaG9wIG9mZiB0aGUgZXh0cmEgJyYnIG9yICc/JyBvbiB0aGUgZW5kXG4gIHF1ZXJ5UGFydCA9IHF1ZXJ5UGFydC5zbGljZSgwLCAtMSk7XG4gIHJldHVybiBxdWVyeVBhcnQ7XG59XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAxNyBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuLyoqIE5ldHdvcmsgaGVhZGVycyAqL1xuZXhwb3J0IHR5cGUgSGVhZGVycyA9IFJlY29yZDxzdHJpbmcsIHN0cmluZz47XG5cbi8qKiBSZXNwb25zZSB0eXBlIGV4cG9zZWQgYnkgdGhlIG5ldHdvcmtpbmcgQVBJcy4gKi9cbmV4cG9ydCB0eXBlIENvbm5lY3Rpb25UeXBlID1cbiAgfCBzdHJpbmdcbiAgfCBBcnJheUJ1ZmZlclxuICB8IEJsb2JcbiAgfCBSZWFkYWJsZVN0cmVhbTxVaW50OEFycmF5PjtcblxuLyoqXG4gKiBBIGxpZ2h0d2VpZ2h0IHdyYXBwZXIgYXJvdW5kIFhNTEh0dHBSZXF1ZXN0IHdpdGggYVxuICogZ29vZy5uZXQuWGhySW8tbGlrZSBpbnRlcmZhY2UuXG4gKlxuICogWW91IGNhbiBjcmVhdGUgYSBuZXcgY29ubmVjdGlvbiBieSBpbnZva2luZyBgbmV3VGV4dENvbm5lY3Rpb24oKWAsXG4gKiBgbmV3Qnl0ZXNDb25uZWN0aW9uKClgIG9yIGBuZXdTdHJlYW1Db25uZWN0aW9uKClgLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIENvbm5lY3Rpb248VCBleHRlbmRzIENvbm5lY3Rpb25UeXBlPiB7XG4gIC8qKlxuICAgKiBTZW5kcyBhIHJlcXVlc3QgdG8gdGhlIHByb3ZpZGVkIFVSTC5cbiAgICpcbiAgICogVGhpcyBtZXRob2QgbmV2ZXIgcmVqZWN0cyBpdHMgcHJvbWlzZS4gSW4gY2FzZSBvZiBlbmNvdW50ZXJpbmcgYW4gZXJyb3IsXG4gICAqIGl0IHNldHMgYW4gZXJyb3IgY29kZSBpbnRlcm5hbGx5IHdoaWNoIGNhbiBiZSBhY2Nlc3NlZCBieSBjYWxsaW5nXG4gICAqIGdldEVycm9yQ29kZSgpIGJ5IGNhbGxlcnMuXG4gICAqL1xuICBzZW5kKFxuICAgIHVybDogc3RyaW5nLFxuICAgIG1ldGhvZDogc3RyaW5nLFxuICAgIGlzVXNpbmdFbXVsYXRvcjogYm9vbGVhbixcbiAgICBib2R5PzogQXJyYXlCdWZmZXJWaWV3IHwgQmxvYiB8IHN0cmluZyB8IG51bGwsXG4gICAgaGVhZGVycz86IEhlYWRlcnNcbiAgKTogUHJvbWlzZTx2b2lkPjtcblxuICBnZXRFcnJvckNvZGUoKTogRXJyb3JDb2RlO1xuXG4gIGdldFN0YXR1cygpOiBudW1iZXI7XG5cbiAgZ2V0UmVzcG9uc2UoKTogVDtcblxuICBnZXRFcnJvclRleHQoKTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBBYm9ydCB0aGUgcmVxdWVzdC5cbiAgICovXG4gIGFib3J0KCk6IHZvaWQ7XG5cbiAgZ2V0UmVzcG9uc2VIZWFkZXIoaGVhZGVyOiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsO1xuXG4gIGFkZFVwbG9hZFByb2dyZXNzTGlzdGVuZXIobGlzdGVuZXI6IChwMTogUHJvZ3Jlc3NFdmVudCkgPT4gdm9pZCk6IHZvaWQ7XG5cbiAgcmVtb3ZlVXBsb2FkUHJvZ3Jlc3NMaXN0ZW5lcihsaXN0ZW5lcjogKHAxOiBQcm9ncmVzc0V2ZW50KSA9PiB2b2lkKTogdm9pZDtcbn1cblxuLyoqXG4gKiBFcnJvciBjb2RlcyBmb3IgcmVxdWVzdHMgbWFkZSBieSB0aGUgWGhySW8gd3JhcHBlci5cbiAqL1xuZXhwb3J0IGVudW0gRXJyb3JDb2RlIHtcbiAgTk9fRVJST1IgPSAwLFxuICBORVRXT1JLX0VSUk9SID0gMSxcbiAgQUJPUlQgPSAyXG59XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAyMiBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG4vKipcbiAqIENoZWNrcyB0aGUgc3RhdHVzIGNvZGUgdG8gc2VlIGlmIHRoZSBhY3Rpb24gc2hvdWxkIGJlIHJldHJpZWQuXG4gKlxuICogQHBhcmFtIHN0YXR1cyBDdXJyZW50IEhUVFAgc3RhdHVzIGNvZGUgcmV0dXJuZWQgYnkgc2VydmVyLlxuICogQHBhcmFtIGFkZGl0aW9uYWxSZXRyeUNvZGVzIGFkZGl0aW9uYWwgcmV0cnkgY29kZXMgdG8gY2hlY2sgYWdhaW5zdFxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNSZXRyeVN0YXR1c0NvZGUoXG4gIHN0YXR1czogbnVtYmVyLFxuICBhZGRpdGlvbmFsUmV0cnlDb2RlczogbnVtYmVyW11cbik6IGJvb2xlYW4ge1xuICAvLyBUaGUgY29kZXMgZm9yIHdoaWNoIHRvIHJldHJ5IGNhbWUgZnJvbSB0aGlzIHBhZ2U6XG4gIC8vIGh0dHBzOi8vY2xvdWQuZ29vZ2xlLmNvbS9zdG9yYWdlL2RvY3MvZXhwb25lbnRpYWwtYmFja29mZlxuICBjb25zdCBpc0ZpdmVIdW5kcmVkQ29kZSA9IHN0YXR1cyA+PSA1MDAgJiYgc3RhdHVzIDwgNjAwO1xuICBjb25zdCBleHRyYVJldHJ5Q29kZXMgPSBbXG4gICAgLy8gUmVxdWVzdCBUaW1lb3V0OiB3ZWIgc2VydmVyIGRpZG4ndCByZWNlaXZlIGZ1bGwgcmVxdWVzdCBpbiB0aW1lLlxuICAgIDQwOCxcbiAgICAvLyBUb28gTWFueSBSZXF1ZXN0czogeW91J3JlIGdldHRpbmcgcmF0ZS1saW1pdGVkLCBiYXNpY2FsbHkuXG4gICAgNDI5XG4gIF07XG4gIGNvbnN0IGlzRXh0cmFSZXRyeUNvZGUgPSBleHRyYVJldHJ5Q29kZXMuaW5kZXhPZihzdGF0dXMpICE9PSAtMTtcbiAgY29uc3QgaXNBZGRpdGlvbmFsUmV0cnlDb2RlID0gYWRkaXRpb25hbFJldHJ5Q29kZXMuaW5kZXhPZihzdGF0dXMpICE9PSAtMTtcbiAgcmV0dXJuIGlzRml2ZUh1bmRyZWRDb2RlIHx8IGlzRXh0cmFSZXRyeUNvZGUgfHwgaXNBZGRpdGlvbmFsUmV0cnlDb2RlO1xufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMTcgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuLyoqXG4gKiBAZmlsZW92ZXJ2aWV3IERlZmluZXMgbWV0aG9kcyB1c2VkIHRvIGFjdHVhbGx5IHNlbmQgSFRUUCByZXF1ZXN0cyBmcm9tXG4gKiBhYnN0cmFjdCByZXByZXNlbnRhdGlvbnMuXG4gKi9cblxuaW1wb3J0IHsgaWQgYXMgYmFja29mZklkLCBzdGFydCwgc3RvcCB9IGZyb20gJy4vYmFja29mZic7XG5pbXBvcnQgeyBhcHBEZWxldGVkLCBjYW5jZWxlZCwgcmV0cnlMaW1pdEV4Y2VlZGVkLCB1bmtub3duIH0gZnJvbSAnLi9lcnJvcic7XG5pbXBvcnQgeyBFcnJvckhhbmRsZXIsIFJlcXVlc3RIYW5kbGVyLCBSZXF1ZXN0SW5mbyB9IGZyb20gJy4vcmVxdWVzdGluZm8nO1xuaW1wb3J0IHsgaXNKdXN0RGVmIH0gZnJvbSAnLi90eXBlJztcbmltcG9ydCB7IG1ha2VRdWVyeVN0cmluZyB9IGZyb20gJy4vdXJsJztcbmltcG9ydCB7IENvbm5lY3Rpb24sIEVycm9yQ29kZSwgSGVhZGVycywgQ29ubmVjdGlvblR5cGUgfSBmcm9tICcuL2Nvbm5lY3Rpb24nO1xuaW1wb3J0IHsgaXNSZXRyeVN0YXR1c0NvZGUgfSBmcm9tICcuL3V0aWxzJztcblxuZXhwb3J0IGludGVyZmFjZSBSZXF1ZXN0PFQ+IHtcbiAgZ2V0UHJvbWlzZSgpOiBQcm9taXNlPFQ+O1xuXG4gIC8qKlxuICAgKiBDYW5jZWxzIHRoZSByZXF1ZXN0LiBJTVBPUlRBTlQ6IHRoZSBwcm9taXNlIG1heSBzdGlsbCBiZSByZXNvbHZlZCB3aXRoIGFuXG4gICAqIGFwcHJvcHJpYXRlIHZhbHVlIChpZiB0aGUgcmVxdWVzdCBpcyBmaW5pc2hlZCBiZWZvcmUgeW91IGNhbGwgdGhpcyBtZXRob2QsXG4gICAqIGJ1dCB0aGUgcHJvbWlzZSBoYXMgbm90IHlldCBiZWVuIHJlc29sdmVkKSwgc28gZG9uJ3QganVzdCBhc3N1bWUgaXQgd2lsbCBiZVxuICAgKiByZWplY3RlZCBpZiB5b3UgY2FsbCB0aGlzIGZ1bmN0aW9uLlxuICAgKiBAcGFyYW0gYXBwRGVsZXRlIC0gVHJ1ZSBpZiB0aGUgY2FuY2VsYXRpb24gY2FtZSBmcm9tIHRoZSBhcHAgYmVpbmcgZGVsZXRlZC5cbiAgICovXG4gIGNhbmNlbChhcHBEZWxldGU/OiBib29sZWFuKTogdm9pZDtcbn1cblxuLyoqXG4gKiBIYW5kbGVzIG5ldHdvcmsgbG9naWMgZm9yIGFsbCBTdG9yYWdlIFJlcXVlc3RzLCBpbmNsdWRpbmcgZXJyb3IgcmVwb3J0aW5nIGFuZFxuICogcmV0cmllcyB3aXRoIGJhY2tvZmYuXG4gKlxuICogQHBhcmFtIEkgLSB0aGUgdHlwZSBvZiB0aGUgYmFja2VuZCdzIG5ldHdvcmsgcmVzcG9uc2UuXG4gKiBAcGFyYW0gLSBPIHRoZSBvdXRwdXQgdHlwZSB1c2VkIGJ5IHRoZSByZXN0IG9mIHRoZSBTREsuIFRoZSBjb252ZXJzaW9uXG4gKiBoYXBwZW5zIGluIHRoZSBzcGVjaWZpZWQgYGNhbGxiYWNrX2AuXG4gKi9cbmNsYXNzIE5ldHdvcmtSZXF1ZXN0PEkgZXh0ZW5kcyBDb25uZWN0aW9uVHlwZSwgTz4gaW1wbGVtZW50cyBSZXF1ZXN0PE8+IHtcbiAgcHJpdmF0ZSBwZW5kaW5nQ29ubmVjdGlvbl86IENvbm5lY3Rpb248ST4gfCBudWxsID0gbnVsbDtcbiAgcHJpdmF0ZSBiYWNrb2ZmSWRfOiBiYWNrb2ZmSWQgfCBudWxsID0gbnVsbDtcbiAgcHJpdmF0ZSByZXNvbHZlXyE6ICh2YWx1ZT86IE8gfCBQcm9taXNlTGlrZTxPPikgPT4gdm9pZDtcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbiAgcHJpdmF0ZSByZWplY3RfITogKHJlYXNvbj86IGFueSkgPT4gdm9pZDtcbiAgcHJpdmF0ZSBjYW5jZWxlZF86IGJvb2xlYW4gPSBmYWxzZTtcbiAgcHJpdmF0ZSBhcHBEZWxldGVfOiBib29sZWFuID0gZmFsc2U7XG4gIHByaXZhdGUgcHJvbWlzZV86IFByb21pc2U8Tz47XG5cbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSB1cmxfOiBzdHJpbmcsXG4gICAgcHJpdmF0ZSBtZXRob2RfOiBzdHJpbmcsXG4gICAgcHJpdmF0ZSBoZWFkZXJzXzogSGVhZGVycyxcbiAgICBwcml2YXRlIGJvZHlfOiBzdHJpbmcgfCBCbG9iIHwgVWludDhBcnJheSB8IG51bGwsXG4gICAgcHJpdmF0ZSBzdWNjZXNzQ29kZXNfOiBudW1iZXJbXSxcbiAgICBwcml2YXRlIGFkZGl0aW9uYWxSZXRyeUNvZGVzXzogbnVtYmVyW10sXG4gICAgcHJpdmF0ZSBjYWxsYmFja186IFJlcXVlc3RIYW5kbGVyPEksIE8+LFxuICAgIHByaXZhdGUgZXJyb3JDYWxsYmFja186IEVycm9ySGFuZGxlciB8IG51bGwsXG4gICAgcHJpdmF0ZSB0aW1lb3V0XzogbnVtYmVyLFxuICAgIHByaXZhdGUgcHJvZ3Jlc3NDYWxsYmFja186ICgocDE6IG51bWJlciwgcDI6IG51bWJlcikgPT4gdm9pZCkgfCBudWxsLFxuICAgIHByaXZhdGUgY29ubmVjdGlvbkZhY3RvcnlfOiAoKSA9PiBDb25uZWN0aW9uPEk+LFxuICAgIHByaXZhdGUgcmV0cnkgPSB0cnVlLFxuICAgIHByaXZhdGUgaXNVc2luZ0VtdWxhdG9yID0gZmFsc2VcbiAgKSB7XG4gICAgdGhpcy5wcm9taXNlXyA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHRoaXMucmVzb2x2ZV8gPSByZXNvbHZlIGFzICh2YWx1ZT86IE8gfCBQcm9taXNlTGlrZTxPPikgPT4gdm9pZDtcbiAgICAgIHRoaXMucmVqZWN0XyA9IHJlamVjdDtcbiAgICAgIHRoaXMuc3RhcnRfKCk7XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogQWN0dWFsbHkgc3RhcnRzIHRoZSByZXRyeSBsb29wLlxuICAgKi9cbiAgcHJpdmF0ZSBzdGFydF8oKTogdm9pZCB7XG4gICAgY29uc3QgZG9UaGVSZXF1ZXN0OiAoXG4gICAgICBiYWNrb2ZmQ2FsbGJhY2s6IChzdWNjZXNzOiBib29sZWFuLCAuLi5wMjogdW5rbm93bltdKSA9PiB2b2lkLFxuICAgICAgY2FuY2VsZWQ6IGJvb2xlYW5cbiAgICApID0+IHZvaWQgPSAoYmFja29mZkNhbGxiYWNrLCBjYW5jZWxlZCkgPT4ge1xuICAgICAgaWYgKGNhbmNlbGVkKSB7XG4gICAgICAgIGJhY2tvZmZDYWxsYmFjayhmYWxzZSwgbmV3IFJlcXVlc3RFbmRTdGF0dXMoZmFsc2UsIG51bGwsIHRydWUpKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgY29ubmVjdGlvbiA9IHRoaXMuY29ubmVjdGlvbkZhY3RvcnlfKCk7XG4gICAgICB0aGlzLnBlbmRpbmdDb25uZWN0aW9uXyA9IGNvbm5lY3Rpb247XG5cbiAgICAgIGNvbnN0IHByb2dyZXNzTGlzdGVuZXI6IChcbiAgICAgICAgcHJvZ3Jlc3NFdmVudDogUHJvZ3Jlc3NFdmVudFxuICAgICAgKSA9PiB2b2lkID0gcHJvZ3Jlc3NFdmVudCA9PiB7XG4gICAgICAgIGNvbnN0IGxvYWRlZCA9IHByb2dyZXNzRXZlbnQubG9hZGVkO1xuICAgICAgICBjb25zdCB0b3RhbCA9IHByb2dyZXNzRXZlbnQubGVuZ3RoQ29tcHV0YWJsZSA/IHByb2dyZXNzRXZlbnQudG90YWwgOiAtMTtcbiAgICAgICAgaWYgKHRoaXMucHJvZ3Jlc3NDYWxsYmFja18gIT09IG51bGwpIHtcbiAgICAgICAgICB0aGlzLnByb2dyZXNzQ2FsbGJhY2tfKGxvYWRlZCwgdG90YWwpO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgaWYgKHRoaXMucHJvZ3Jlc3NDYWxsYmFja18gIT09IG51bGwpIHtcbiAgICAgICAgY29ubmVjdGlvbi5hZGRVcGxvYWRQcm9ncmVzc0xpc3RlbmVyKHByb2dyZXNzTGlzdGVuZXIpO1xuICAgICAgfVxuXG4gICAgICAvLyBjb25uZWN0aW9uLnNlbmQoKSBuZXZlciByZWplY3RzLCBzbyB3ZSBkb24ndCBuZWVkIHRvIGhhdmUgYSBlcnJvciBoYW5kbGVyIG9yIHVzZSBjYXRjaCBvbiB0aGUgcmV0dXJuZWQgcHJvbWlzZS5cbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZmxvYXRpbmctcHJvbWlzZXNcbiAgICAgIGNvbm5lY3Rpb25cbiAgICAgICAgLnNlbmQoXG4gICAgICAgICAgdGhpcy51cmxfLFxuICAgICAgICAgIHRoaXMubWV0aG9kXyxcbiAgICAgICAgICB0aGlzLmlzVXNpbmdFbXVsYXRvcixcbiAgICAgICAgICB0aGlzLmJvZHlfLFxuICAgICAgICAgIHRoaXMuaGVhZGVyc19cbiAgICAgICAgKVxuICAgICAgICAudGhlbigoKSA9PiB7XG4gICAgICAgICAgaWYgKHRoaXMucHJvZ3Jlc3NDYWxsYmFja18gIT09IG51bGwpIHtcbiAgICAgICAgICAgIGNvbm5lY3Rpb24ucmVtb3ZlVXBsb2FkUHJvZ3Jlc3NMaXN0ZW5lcihwcm9ncmVzc0xpc3RlbmVyKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhpcy5wZW5kaW5nQ29ubmVjdGlvbl8gPSBudWxsO1xuICAgICAgICAgIGNvbnN0IGhpdFNlcnZlciA9IGNvbm5lY3Rpb24uZ2V0RXJyb3JDb2RlKCkgPT09IEVycm9yQ29kZS5OT19FUlJPUjtcbiAgICAgICAgICBjb25zdCBzdGF0dXMgPSBjb25uZWN0aW9uLmdldFN0YXR1cygpO1xuICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICFoaXRTZXJ2ZXIgfHxcbiAgICAgICAgICAgIChpc1JldHJ5U3RhdHVzQ29kZShzdGF0dXMsIHRoaXMuYWRkaXRpb25hbFJldHJ5Q29kZXNfKSAmJlxuICAgICAgICAgICAgICB0aGlzLnJldHJ5KVxuICAgICAgICAgICkge1xuICAgICAgICAgICAgY29uc3Qgd2FzQ2FuY2VsZWQgPSBjb25uZWN0aW9uLmdldEVycm9yQ29kZSgpID09PSBFcnJvckNvZGUuQUJPUlQ7XG4gICAgICAgICAgICBiYWNrb2ZmQ2FsbGJhY2soXG4gICAgICAgICAgICAgIGZhbHNlLFxuICAgICAgICAgICAgICBuZXcgUmVxdWVzdEVuZFN0YXR1cyhmYWxzZSwgbnVsbCwgd2FzQ2FuY2VsZWQpXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBzdWNjZXNzQ29kZSA9IHRoaXMuc3VjY2Vzc0NvZGVzXy5pbmRleE9mKHN0YXR1cykgIT09IC0xO1xuICAgICAgICAgIGJhY2tvZmZDYWxsYmFjayh0cnVlLCBuZXcgUmVxdWVzdEVuZFN0YXR1cyhzdWNjZXNzQ29kZSwgY29ubmVjdGlvbikpO1xuICAgICAgICB9KTtcbiAgICB9O1xuXG4gICAgLyoqXG4gICAgICogQHBhcmFtIHJlcXVlc3RXZW50VGhyb3VnaCAtIFRydWUgaWYgdGhlIHJlcXVlc3QgZXZlbnR1YWxseSB3ZW50XG4gICAgICogICAgIHRocm91Z2gsIGZhbHNlIGlmIGl0IGhpdCB0aGUgcmV0cnkgbGltaXQgb3Igd2FzIGNhbmNlbGVkLlxuICAgICAqL1xuICAgIGNvbnN0IGJhY2tvZmZEb25lOiAoXG4gICAgICByZXF1ZXN0V2VudFRocm91Z2g6IGJvb2xlYW4sXG4gICAgICBzdGF0dXM6IFJlcXVlc3RFbmRTdGF0dXM8ST5cbiAgICApID0+IHZvaWQgPSAocmVxdWVzdFdlbnRUaHJvdWdoLCBzdGF0dXMpID0+IHtcbiAgICAgIGNvbnN0IHJlc29sdmUgPSB0aGlzLnJlc29sdmVfO1xuICAgICAgY29uc3QgcmVqZWN0ID0gdGhpcy5yZWplY3RfO1xuICAgICAgY29uc3QgY29ubmVjdGlvbiA9IHN0YXR1cy5jb25uZWN0aW9uIGFzIENvbm5lY3Rpb248ST47XG4gICAgICBpZiAoc3RhdHVzLndhc1N1Y2Nlc3NDb2RlKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgcmVzdWx0ID0gdGhpcy5jYWxsYmFja18oY29ubmVjdGlvbiwgY29ubmVjdGlvbi5nZXRSZXNwb25zZSgpKTtcbiAgICAgICAgICBpZiAoaXNKdXN0RGVmKHJlc3VsdCkpIHtcbiAgICAgICAgICAgIHJlc29sdmUocmVzdWx0KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIHJlamVjdChlKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKGNvbm5lY3Rpb24gIT09IG51bGwpIHtcbiAgICAgICAgICBjb25zdCBlcnIgPSB1bmtub3duKCk7XG4gICAgICAgICAgZXJyLnNlcnZlclJlc3BvbnNlID0gY29ubmVjdGlvbi5nZXRFcnJvclRleHQoKTtcbiAgICAgICAgICBpZiAodGhpcy5lcnJvckNhbGxiYWNrXykge1xuICAgICAgICAgICAgcmVqZWN0KHRoaXMuZXJyb3JDYWxsYmFja18oY29ubmVjdGlvbiwgZXJyKSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlamVjdChlcnIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAoc3RhdHVzLmNhbmNlbGVkKSB7XG4gICAgICAgICAgICBjb25zdCBlcnIgPSB0aGlzLmFwcERlbGV0ZV8gPyBhcHBEZWxldGVkKCkgOiBjYW5jZWxlZCgpO1xuICAgICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGVyciA9IHJldHJ5TGltaXRFeGNlZWRlZCgpO1xuICAgICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcbiAgICBpZiAodGhpcy5jYW5jZWxlZF8pIHtcbiAgICAgIGJhY2tvZmZEb25lKGZhbHNlLCBuZXcgUmVxdWVzdEVuZFN0YXR1cyhmYWxzZSwgbnVsbCwgdHJ1ZSkpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmJhY2tvZmZJZF8gPSBzdGFydChkb1RoZVJlcXVlc3QsIGJhY2tvZmZEb25lLCB0aGlzLnRpbWVvdXRfKTtcbiAgICB9XG4gIH1cblxuICAvKiogQGluaGVyaXREb2MgKi9cbiAgZ2V0UHJvbWlzZSgpOiBQcm9taXNlPE8+IHtcbiAgICByZXR1cm4gdGhpcy5wcm9taXNlXztcbiAgfVxuXG4gIC8qKiBAaW5oZXJpdERvYyAqL1xuICBjYW5jZWwoYXBwRGVsZXRlPzogYm9vbGVhbik6IHZvaWQge1xuICAgIHRoaXMuY2FuY2VsZWRfID0gdHJ1ZTtcbiAgICB0aGlzLmFwcERlbGV0ZV8gPSBhcHBEZWxldGUgfHwgZmFsc2U7XG4gICAgaWYgKHRoaXMuYmFja29mZklkXyAhPT0gbnVsbCkge1xuICAgICAgc3RvcCh0aGlzLmJhY2tvZmZJZF8pO1xuICAgIH1cbiAgICBpZiAodGhpcy5wZW5kaW5nQ29ubmVjdGlvbl8gIT09IG51bGwpIHtcbiAgICAgIHRoaXMucGVuZGluZ0Nvbm5lY3Rpb25fLmFib3J0KCk7XG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogQSBjb2xsZWN0aW9uIG9mIGluZm9ybWF0aW9uIGFib3V0IHRoZSByZXN1bHQgb2YgYSBuZXR3b3JrIHJlcXVlc3QuXG4gKiBAcGFyYW0gb3B0X2NhbmNlbGVkIC0gRGVmYXVsdHMgdG8gZmFsc2UuXG4gKi9cbmV4cG9ydCBjbGFzcyBSZXF1ZXN0RW5kU3RhdHVzPEkgZXh0ZW5kcyBDb25uZWN0aW9uVHlwZT4ge1xuICAvKipcbiAgICogVHJ1ZSBpZiB0aGUgcmVxdWVzdCB3YXMgY2FuY2VsZWQuXG4gICAqL1xuICBjYW5jZWxlZDogYm9vbGVhbjtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwdWJsaWMgd2FzU3VjY2Vzc0NvZGU6IGJvb2xlYW4sXG4gICAgcHVibGljIGNvbm5lY3Rpb246IENvbm5lY3Rpb248ST4gfCBudWxsLFxuICAgIGNhbmNlbGVkPzogYm9vbGVhblxuICApIHtcbiAgICB0aGlzLmNhbmNlbGVkID0gISFjYW5jZWxlZDtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gYWRkQXV0aEhlYWRlcl8oXG4gIGhlYWRlcnM6IEhlYWRlcnMsXG4gIGF1dGhUb2tlbjogc3RyaW5nIHwgbnVsbFxuKTogdm9pZCB7XG4gIGlmIChhdXRoVG9rZW4gIT09IG51bGwgJiYgYXV0aFRva2VuLmxlbmd0aCA+IDApIHtcbiAgICBoZWFkZXJzWydBdXRob3JpemF0aW9uJ10gPSAnRmlyZWJhc2UgJyArIGF1dGhUb2tlbjtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gYWRkVmVyc2lvbkhlYWRlcl8oXG4gIGhlYWRlcnM6IEhlYWRlcnMsXG4gIGZpcmViYXNlVmVyc2lvbj86IHN0cmluZ1xuKTogdm9pZCB7XG4gIGhlYWRlcnNbJ1gtRmlyZWJhc2UtU3RvcmFnZS1WZXJzaW9uJ10gPVxuICAgICd3ZWJqcy8nICsgKGZpcmViYXNlVmVyc2lvbiA/PyAnQXBwTWFuYWdlcicpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gYWRkR21waWRIZWFkZXJfKGhlYWRlcnM6IEhlYWRlcnMsIGFwcElkOiBzdHJpbmcgfCBudWxsKTogdm9pZCB7XG4gIGlmIChhcHBJZCkge1xuICAgIGhlYWRlcnNbJ1gtRmlyZWJhc2UtR01QSUQnXSA9IGFwcElkO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhZGRBcHBDaGVja0hlYWRlcl8oXG4gIGhlYWRlcnM6IEhlYWRlcnMsXG4gIGFwcENoZWNrVG9rZW46IHN0cmluZyB8IG51bGxcbik6IHZvaWQge1xuICBpZiAoYXBwQ2hlY2tUb2tlbiAhPT0gbnVsbCkge1xuICAgIGhlYWRlcnNbJ1gtRmlyZWJhc2UtQXBwQ2hlY2snXSA9IGFwcENoZWNrVG9rZW47XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG1ha2VSZXF1ZXN0PEkgZXh0ZW5kcyBDb25uZWN0aW9uVHlwZSwgTz4oXG4gIHJlcXVlc3RJbmZvOiBSZXF1ZXN0SW5mbzxJLCBPPixcbiAgYXBwSWQ6IHN0cmluZyB8IG51bGwsXG4gIGF1dGhUb2tlbjogc3RyaW5nIHwgbnVsbCxcbiAgYXBwQ2hlY2tUb2tlbjogc3RyaW5nIHwgbnVsbCxcbiAgcmVxdWVzdEZhY3Rvcnk6ICgpID0+IENvbm5lY3Rpb248ST4sXG4gIGZpcmViYXNlVmVyc2lvbj86IHN0cmluZyxcbiAgcmV0cnkgPSB0cnVlLFxuICBpc1VzaW5nRW11bGF0b3IgPSBmYWxzZVxuKTogUmVxdWVzdDxPPiB7XG4gIGNvbnN0IHF1ZXJ5UGFydCA9IG1ha2VRdWVyeVN0cmluZyhyZXF1ZXN0SW5mby51cmxQYXJhbXMpO1xuICBjb25zdCB1cmwgPSByZXF1ZXN0SW5mby51cmwgKyBxdWVyeVBhcnQ7XG4gIGNvbnN0IGhlYWRlcnMgPSBPYmplY3QuYXNzaWduKHt9LCByZXF1ZXN0SW5mby5oZWFkZXJzKTtcbiAgYWRkR21waWRIZWFkZXJfKGhlYWRlcnMsIGFwcElkKTtcbiAgYWRkQXV0aEhlYWRlcl8oaGVhZGVycywgYXV0aFRva2VuKTtcbiAgYWRkVmVyc2lvbkhlYWRlcl8oaGVhZGVycywgZmlyZWJhc2VWZXJzaW9uKTtcbiAgYWRkQXBwQ2hlY2tIZWFkZXJfKGhlYWRlcnMsIGFwcENoZWNrVG9rZW4pO1xuICByZXR1cm4gbmV3IE5ldHdvcmtSZXF1ZXN0PEksIE8+KFxuICAgIHVybCxcbiAgICByZXF1ZXN0SW5mby5tZXRob2QsXG4gICAgaGVhZGVycyxcbiAgICByZXF1ZXN0SW5mby5ib2R5LFxuICAgIHJlcXVlc3RJbmZvLnN1Y2Nlc3NDb2RlcyxcbiAgICByZXF1ZXN0SW5mby5hZGRpdGlvbmFsUmV0cnlDb2RlcyxcbiAgICByZXF1ZXN0SW5mby5oYW5kbGVyLFxuICAgIHJlcXVlc3RJbmZvLmVycm9ySGFuZGxlcixcbiAgICByZXF1ZXN0SW5mby50aW1lb3V0LFxuICAgIHJlcXVlc3RJbmZvLnByb2dyZXNzQ2FsbGJhY2ssXG4gICAgcmVxdWVzdEZhY3RvcnksXG4gICAgcmV0cnksXG4gICAgaXNVc2luZ0VtdWxhdG9yXG4gICk7XG59XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAxNyBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuLyoqXG4gKiBAZmlsZW92ZXJ2aWV3IFNvbWUgbWV0aG9kcyBjb3BpZWQgZnJvbSBnb29nLmZzLlxuICogV2UgZG9uJ3QgaW5jbHVkZSBnb29nLmZzIGJlY2F1c2UgaXQgcHVsbHMgaW4gYSBidW5jaCBvZiBEZWZlcnJlZCBjb2RlIHRoYXRcbiAqIGJsb2F0cyB0aGUgc2l6ZSBvZiB0aGUgcmVsZWFzZWQgYmluYXJ5LlxuICovXG5pbXBvcnQgeyBpc05hdGl2ZUJsb2JEZWZpbmVkIH0gZnJvbSAnLi90eXBlJztcbmltcG9ydCB7IFN0b3JhZ2VFcnJvckNvZGUsIFN0b3JhZ2VFcnJvciB9IGZyb20gJy4vZXJyb3InO1xuXG5mdW5jdGlvbiBnZXRCbG9iQnVpbGRlcigpOiB0eXBlb2YgSUJsb2JCdWlsZGVyIHwgdW5kZWZpbmVkIHtcbiAgaWYgKHR5cGVvZiBCbG9iQnVpbGRlciAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4gQmxvYkJ1aWxkZXI7XG4gIH0gZWxzZSBpZiAodHlwZW9mIFdlYktpdEJsb2JCdWlsZGVyICE9PSAndW5kZWZpbmVkJykge1xuICAgIHJldHVybiBXZWJLaXRCbG9iQnVpbGRlcjtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG59XG5cbi8qKlxuICogQ29uY2F0ZW5hdGVzIG9uZSBvciBtb3JlIHZhbHVlcyB0b2dldGhlciBhbmQgY29udmVydHMgdGhlbSB0byBhIEJsb2IuXG4gKlxuICogQHBhcmFtIGFyZ3MgVGhlIHZhbHVlcyB0aGF0IHdpbGwgbWFrZSB1cCB0aGUgcmVzdWx0aW5nIGJsb2IuXG4gKiBAcmV0dXJuIFRoZSBibG9iLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0QmxvYiguLi5hcmdzOiBBcnJheTxzdHJpbmcgfCBCbG9iIHwgQXJyYXlCdWZmZXI+KTogQmxvYiB7XG4gIGNvbnN0IEJsb2JCdWlsZGVyID0gZ2V0QmxvYkJ1aWxkZXIoKTtcbiAgaWYgKEJsb2JCdWlsZGVyICE9PSB1bmRlZmluZWQpIHtcbiAgICBjb25zdCBiYiA9IG5ldyBCbG9iQnVpbGRlcigpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYXJncy5sZW5ndGg7IGkrKykge1xuICAgICAgYmIuYXBwZW5kKGFyZ3NbaV0pO1xuICAgIH1cbiAgICByZXR1cm4gYmIuZ2V0QmxvYigpO1xuICB9IGVsc2Uge1xuICAgIGlmIChpc05hdGl2ZUJsb2JEZWZpbmVkKCkpIHtcbiAgICAgIHJldHVybiBuZXcgQmxvYihhcmdzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IFN0b3JhZ2VFcnJvcihcbiAgICAgICAgU3RvcmFnZUVycm9yQ29kZS5VTlNVUFBPUlRFRF9FTlZJUk9OTUVOVCxcbiAgICAgICAgXCJUaGlzIGJyb3dzZXIgZG9lc24ndCBzZWVtIHRvIHN1cHBvcnQgY3JlYXRpbmcgQmxvYnNcIlxuICAgICAgKTtcbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBTbGljZXMgdGhlIGJsb2IuIFRoZSByZXR1cm5lZCBibG9iIGNvbnRhaW5zIGRhdGEgZnJvbSB0aGUgc3RhcnQgYnl0ZVxuICogKGluY2x1c2l2ZSkgdGlsbCB0aGUgZW5kIGJ5dGUgKGV4Y2x1c2l2ZSkuIE5lZ2F0aXZlIGluZGljZXMgY2Fubm90IGJlIHVzZWQuXG4gKlxuICogQHBhcmFtIGJsb2IgVGhlIGJsb2IgdG8gYmUgc2xpY2VkLlxuICogQHBhcmFtIHN0YXJ0IEluZGV4IG9mIHRoZSBzdGFydGluZyBieXRlLlxuICogQHBhcmFtIGVuZCBJbmRleCBvZiB0aGUgZW5kaW5nIGJ5dGUuXG4gKiBAcmV0dXJuIFRoZSBibG9iIHNsaWNlIG9yIG51bGwgaWYgbm90IHN1cHBvcnRlZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNsaWNlQmxvYihibG9iOiBCbG9iLCBzdGFydDogbnVtYmVyLCBlbmQ6IG51bWJlcik6IEJsb2IgfCBudWxsIHtcbiAgaWYgKGJsb2Iud2Via2l0U2xpY2UpIHtcbiAgICByZXR1cm4gYmxvYi53ZWJraXRTbGljZShzdGFydCwgZW5kKTtcbiAgfSBlbHNlIGlmIChibG9iLm1velNsaWNlKSB7XG4gICAgcmV0dXJuIGJsb2IubW96U2xpY2Uoc3RhcnQsIGVuZCk7XG4gIH0gZWxzZSBpZiAoYmxvYi5zbGljZSkge1xuICAgIHJldHVybiBibG9iLnNsaWNlKHN0YXJ0LCBlbmQpO1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMjEgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgbWlzc2luZ1BvbHlGaWxsIH0gZnJvbSAnLi4vLi4vaW1wbGVtZW50YXRpb24vZXJyb3InO1xuXG4vKiogQ29udmVydHMgYSBCYXNlNjQgZW5jb2RlZCBzdHJpbmcgdG8gYSBiaW5hcnkgc3RyaW5nLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRlY29kZUJhc2U2NChlbmNvZGVkOiBzdHJpbmcpOiBzdHJpbmcge1xuICBpZiAodHlwZW9mIGF0b2IgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgdGhyb3cgbWlzc2luZ1BvbHlGaWxsKCdiYXNlLTY0Jyk7XG4gIH1cbiAgcmV0dXJuIGF0b2IoZW5jb2RlZCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZWNvZGVVaW50OEFycmF5KGRhdGE6IFVpbnQ4QXJyYXkpOiBzdHJpbmcge1xuICByZXR1cm4gbmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKGRhdGEpO1xufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMTcgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgdW5rbm93biwgaW52YWxpZEZvcm1hdCB9IGZyb20gJy4vZXJyb3InO1xuaW1wb3J0IHsgZGVjb2RlQmFzZTY0IH0gZnJvbSAnLi4vcGxhdGZvcm0vYmFzZTY0JztcblxuLyoqXG4gKiBBbiBlbnVtZXJhdGlvbiBvZiB0aGUgcG9zc2libGUgc3RyaW5nIGZvcm1hdHMgZm9yIHVwbG9hZC5cbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IHR5cGUgU3RyaW5nRm9ybWF0ID0gKHR5cGVvZiBTdHJpbmdGb3JtYXQpW2tleW9mIHR5cGVvZiBTdHJpbmdGb3JtYXRdO1xuLyoqXG4gKiBBbiBlbnVtZXJhdGlvbiBvZiB0aGUgcG9zc2libGUgc3RyaW5nIGZvcm1hdHMgZm9yIHVwbG9hZC5cbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IGNvbnN0IFN0cmluZ0Zvcm1hdCA9IHtcbiAgLyoqXG4gICAqIEluZGljYXRlcyB0aGUgc3RyaW5nIHNob3VsZCBiZSBpbnRlcnByZXRlZCBcInJhd1wiLCB0aGF0IGlzLCBhcyBub3JtYWwgdGV4dC5cbiAgICogVGhlIHN0cmluZyB3aWxsIGJlIGludGVycHJldGVkIGFzIFVURi0xNiwgdGhlbiB1cGxvYWRlZCBhcyBhIFVURi04IGJ5dGVcbiAgICogc2VxdWVuY2UuXG4gICAqIEV4YW1wbGU6IFRoZSBzdHJpbmcgJ0hlbGxvISBcXFxcdWQ4M2RcXFxcdWRlMGEnIGJlY29tZXMgdGhlIGJ5dGUgc2VxdWVuY2VcbiAgICogNDggNjUgNmMgNmMgNmYgMjEgMjAgZjAgOWYgOTggOGFcbiAgICovXG4gIFJBVzogJ3JhdycsXG4gIC8qKlxuICAgKiBJbmRpY2F0ZXMgdGhlIHN0cmluZyBzaG91bGQgYmUgaW50ZXJwcmV0ZWQgYXMgYmFzZTY0LWVuY29kZWQgZGF0YS5cbiAgICogUGFkZGluZyBjaGFyYWN0ZXJzICh0cmFpbGluZyAnPSdzKSBhcmUgb3B0aW9uYWwuXG4gICAqIEV4YW1wbGU6IFRoZSBzdHJpbmcgJ3JXbU8rK0U2dDcvcmx3PT0nIGJlY29tZXMgdGhlIGJ5dGUgc2VxdWVuY2VcbiAgICogYWQgNjkgOGUgZmIgZTEgM2EgYjcgYmYgZWIgOTdcbiAgICovXG4gIEJBU0U2NDogJ2Jhc2U2NCcsXG4gIC8qKlxuICAgKiBJbmRpY2F0ZXMgdGhlIHN0cmluZyBzaG91bGQgYmUgaW50ZXJwcmV0ZWQgYXMgYmFzZTY0dXJsLWVuY29kZWQgZGF0YS5cbiAgICogUGFkZGluZyBjaGFyYWN0ZXJzICh0cmFpbGluZyAnPSdzKSBhcmUgb3B0aW9uYWwuXG4gICAqIEV4YW1wbGU6IFRoZSBzdHJpbmcgJ3JXbU8tLUU2dDdfcmx3PT0nIGJlY29tZXMgdGhlIGJ5dGUgc2VxdWVuY2VcbiAgICogYWQgNjkgOGUgZmIgZTEgM2EgYjcgYmYgZWIgOTdcbiAgICovXG4gIEJBU0U2NFVSTDogJ2Jhc2U2NHVybCcsXG4gIC8qKlxuICAgKiBJbmRpY2F0ZXMgdGhlIHN0cmluZyBpcyBhIGRhdGEgVVJMLCBzdWNoIGFzIG9uZSBvYnRhaW5lZCBmcm9tXG4gICAqIGNhbnZhcy50b0RhdGFVUkwoKS5cbiAgICogRXhhbXBsZTogdGhlIHN0cmluZyAnZGF0YTphcHBsaWNhdGlvbi9vY3RldC1zdHJlYW07YmFzZTY0LGFhYWEnXG4gICAqIGJlY29tZXMgdGhlIGJ5dGUgc2VxdWVuY2VcbiAgICogNjkgYTYgOWFcbiAgICogKHRoZSBjb250ZW50LXR5cGUgXCJhcHBsaWNhdGlvbi9vY3RldC1zdHJlYW1cIiBpcyBhbHNvIGFwcGxpZWQsIGJ1dCBjYW5cbiAgICogYmUgb3ZlcnJpZGRlbiBpbiB0aGUgbWV0YWRhdGEgb2JqZWN0KS5cbiAgICovXG4gIERBVEFfVVJMOiAnZGF0YV91cmwnXG59IGFzIGNvbnN0O1xuXG5leHBvcnQgY2xhc3MgU3RyaW5nRGF0YSB7XG4gIGNvbnRlbnRUeXBlOiBzdHJpbmcgfCBudWxsO1xuXG4gIGNvbnN0cnVjdG9yKHB1YmxpYyBkYXRhOiBVaW50OEFycmF5LCBjb250ZW50VHlwZT86IHN0cmluZyB8IG51bGwpIHtcbiAgICB0aGlzLmNvbnRlbnRUeXBlID0gY29udGVudFR5cGUgfHwgbnVsbDtcbiAgfVxufVxuXG4vKipcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgZnVuY3Rpb24gZGF0YUZyb21TdHJpbmcoXG4gIGZvcm1hdDogU3RyaW5nRm9ybWF0LFxuICBzdHJpbmdEYXRhOiBzdHJpbmdcbik6IFN0cmluZ0RhdGEge1xuICBzd2l0Y2ggKGZvcm1hdCkge1xuICAgIGNhc2UgU3RyaW5nRm9ybWF0LlJBVzpcbiAgICAgIHJldHVybiBuZXcgU3RyaW5nRGF0YSh1dGY4Qnl0ZXNfKHN0cmluZ0RhdGEpKTtcbiAgICBjYXNlIFN0cmluZ0Zvcm1hdC5CQVNFNjQ6XG4gICAgY2FzZSBTdHJpbmdGb3JtYXQuQkFTRTY0VVJMOlxuICAgICAgcmV0dXJuIG5ldyBTdHJpbmdEYXRhKGJhc2U2NEJ5dGVzXyhmb3JtYXQsIHN0cmluZ0RhdGEpKTtcbiAgICBjYXNlIFN0cmluZ0Zvcm1hdC5EQVRBX1VSTDpcbiAgICAgIHJldHVybiBuZXcgU3RyaW5nRGF0YShcbiAgICAgICAgZGF0YVVSTEJ5dGVzXyhzdHJpbmdEYXRhKSxcbiAgICAgICAgZGF0YVVSTENvbnRlbnRUeXBlXyhzdHJpbmdEYXRhKVxuICAgICAgKTtcbiAgICBkZWZhdWx0OlxuICAgIC8vIGRvIG5vdGhpbmdcbiAgfVxuXG4gIC8vIGFzc2VydChmYWxzZSk7XG4gIHRocm93IHVua25vd24oKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHV0ZjhCeXRlc18odmFsdWU6IHN0cmluZyk6IFVpbnQ4QXJyYXkge1xuICBjb25zdCBiOiBudW1iZXJbXSA9IFtdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IHZhbHVlLmxlbmd0aDsgaSsrKSB7XG4gICAgbGV0IGMgPSB2YWx1ZS5jaGFyQ29kZUF0KGkpO1xuICAgIGlmIChjIDw9IDEyNykge1xuICAgICAgYi5wdXNoKGMpO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoYyA8PSAyMDQ3KSB7XG4gICAgICAgIGIucHVzaCgxOTIgfCAoYyA+PiA2KSwgMTI4IHwgKGMgJiA2MykpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKChjICYgNjQ1MTIpID09PSA1NTI5Nikge1xuICAgICAgICAgIC8vIFRoZSBzdGFydCBvZiBhIHN1cnJvZ2F0ZSBwYWlyLlxuICAgICAgICAgIGNvbnN0IHZhbGlkID1cbiAgICAgICAgICAgIGkgPCB2YWx1ZS5sZW5ndGggLSAxICYmICh2YWx1ZS5jaGFyQ29kZUF0KGkgKyAxKSAmIDY0NTEyKSA9PT0gNTYzMjA7XG4gICAgICAgICAgaWYgKCF2YWxpZCkge1xuICAgICAgICAgICAgLy8gVGhlIHNlY29uZCBzdXJyb2dhdGUgd2Fzbid0IHRoZXJlLlxuICAgICAgICAgICAgYi5wdXNoKDIzOSwgMTkxLCAxODkpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb25zdCBoaSA9IGM7XG4gICAgICAgICAgICBjb25zdCBsbyA9IHZhbHVlLmNoYXJDb2RlQXQoKytpKTtcbiAgICAgICAgICAgIGMgPSA2NTUzNiB8ICgoaGkgJiAxMDIzKSA8PCAxMCkgfCAobG8gJiAxMDIzKTtcbiAgICAgICAgICAgIGIucHVzaChcbiAgICAgICAgICAgICAgMjQwIHwgKGMgPj4gMTgpLFxuICAgICAgICAgICAgICAxMjggfCAoKGMgPj4gMTIpICYgNjMpLFxuICAgICAgICAgICAgICAxMjggfCAoKGMgPj4gNikgJiA2MyksXG4gICAgICAgICAgICAgIDEyOCB8IChjICYgNjMpXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAoKGMgJiA2NDUxMikgPT09IDU2MzIwKSB7XG4gICAgICAgICAgICAvLyBJbnZhbGlkIGxvdyBzdXJyb2dhdGUuXG4gICAgICAgICAgICBiLnB1c2goMjM5LCAxOTEsIDE4OSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGIucHVzaCgyMjQgfCAoYyA+PiAxMiksIDEyOCB8ICgoYyA+PiA2KSAmIDYzKSwgMTI4IHwgKGMgJiA2MykpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gbmV3IFVpbnQ4QXJyYXkoYik7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwZXJjZW50RW5jb2RlZEJ5dGVzXyh2YWx1ZTogc3RyaW5nKTogVWludDhBcnJheSB7XG4gIGxldCBkZWNvZGVkO1xuICB0cnkge1xuICAgIGRlY29kZWQgPSBkZWNvZGVVUklDb21wb25lbnQodmFsdWUpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgdGhyb3cgaW52YWxpZEZvcm1hdChTdHJpbmdGb3JtYXQuREFUQV9VUkwsICdNYWxmb3JtZWQgZGF0YSBVUkwuJyk7XG4gIH1cbiAgcmV0dXJuIHV0ZjhCeXRlc18oZGVjb2RlZCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBiYXNlNjRCeXRlc18oZm9ybWF0OiBTdHJpbmdGb3JtYXQsIHZhbHVlOiBzdHJpbmcpOiBVaW50OEFycmF5IHtcbiAgc3dpdGNoIChmb3JtYXQpIHtcbiAgICBjYXNlIFN0cmluZ0Zvcm1hdC5CQVNFNjQ6IHtcbiAgICAgIGNvbnN0IGhhc01pbnVzID0gdmFsdWUuaW5kZXhPZignLScpICE9PSAtMTtcbiAgICAgIGNvbnN0IGhhc1VuZGVyID0gdmFsdWUuaW5kZXhPZignXycpICE9PSAtMTtcbiAgICAgIGlmIChoYXNNaW51cyB8fCBoYXNVbmRlcikge1xuICAgICAgICBjb25zdCBpbnZhbGlkQ2hhciA9IGhhc01pbnVzID8gJy0nIDogJ18nO1xuICAgICAgICB0aHJvdyBpbnZhbGlkRm9ybWF0KFxuICAgICAgICAgIGZvcm1hdCxcbiAgICAgICAgICBcIkludmFsaWQgY2hhcmFjdGVyICdcIiArXG4gICAgICAgICAgICBpbnZhbGlkQ2hhciArXG4gICAgICAgICAgICBcIicgZm91bmQ6IGlzIGl0IGJhc2U2NHVybCBlbmNvZGVkP1wiXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgY2FzZSBTdHJpbmdGb3JtYXQuQkFTRTY0VVJMOiB7XG4gICAgICBjb25zdCBoYXNQbHVzID0gdmFsdWUuaW5kZXhPZignKycpICE9PSAtMTtcbiAgICAgIGNvbnN0IGhhc1NsYXNoID0gdmFsdWUuaW5kZXhPZignLycpICE9PSAtMTtcbiAgICAgIGlmIChoYXNQbHVzIHx8IGhhc1NsYXNoKSB7XG4gICAgICAgIGNvbnN0IGludmFsaWRDaGFyID0gaGFzUGx1cyA/ICcrJyA6ICcvJztcbiAgICAgICAgdGhyb3cgaW52YWxpZEZvcm1hdChcbiAgICAgICAgICBmb3JtYXQsXG4gICAgICAgICAgXCJJbnZhbGlkIGNoYXJhY3RlciAnXCIgKyBpbnZhbGlkQ2hhciArIFwiJyBmb3VuZDogaXMgaXQgYmFzZTY0IGVuY29kZWQ/XCJcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIHZhbHVlID0gdmFsdWUucmVwbGFjZSgvLS9nLCAnKycpLnJlcGxhY2UoL18vZywgJy8nKTtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBkZWZhdWx0OlxuICAgIC8vIGRvIG5vdGhpbmdcbiAgfVxuICBsZXQgYnl0ZXM7XG4gIHRyeSB7XG4gICAgYnl0ZXMgPSBkZWNvZGVCYXNlNjQodmFsdWUpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgaWYgKChlIGFzIEVycm9yKS5tZXNzYWdlLmluY2x1ZGVzKCdwb2x5ZmlsbCcpKSB7XG4gICAgICB0aHJvdyBlO1xuICAgIH1cbiAgICB0aHJvdyBpbnZhbGlkRm9ybWF0KGZvcm1hdCwgJ0ludmFsaWQgY2hhcmFjdGVyIGZvdW5kJyk7XG4gIH1cbiAgY29uc3QgYXJyYXkgPSBuZXcgVWludDhBcnJheShieXRlcy5sZW5ndGgpO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGJ5dGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgYXJyYXlbaV0gPSBieXRlcy5jaGFyQ29kZUF0KGkpO1xuICB9XG4gIHJldHVybiBhcnJheTtcbn1cblxuY2xhc3MgRGF0YVVSTFBhcnRzIHtcbiAgYmFzZTY0OiBib29sZWFuID0gZmFsc2U7XG4gIGNvbnRlbnRUeXBlOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgcmVzdDogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKGRhdGFVUkw6IHN0cmluZykge1xuICAgIGNvbnN0IG1hdGNoZXMgPSBkYXRhVVJMLm1hdGNoKC9eZGF0YTooW14sXSspPywvKTtcbiAgICBpZiAobWF0Y2hlcyA9PT0gbnVsbCkge1xuICAgICAgdGhyb3cgaW52YWxpZEZvcm1hdChcbiAgICAgICAgU3RyaW5nRm9ybWF0LkRBVEFfVVJMLFxuICAgICAgICBcIk11c3QgYmUgZm9ybWF0dGVkICdkYXRhOls8bWVkaWF0eXBlPl1bO2Jhc2U2NF0sPGRhdGE+XCJcbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IG1pZGRsZSA9IG1hdGNoZXNbMV0gfHwgbnVsbDtcbiAgICBpZiAobWlkZGxlICE9IG51bGwpIHtcbiAgICAgIHRoaXMuYmFzZTY0ID0gZW5kc1dpdGgobWlkZGxlLCAnO2Jhc2U2NCcpO1xuICAgICAgdGhpcy5jb250ZW50VHlwZSA9IHRoaXMuYmFzZTY0XG4gICAgICAgID8gbWlkZGxlLnN1YnN0cmluZygwLCBtaWRkbGUubGVuZ3RoIC0gJztiYXNlNjQnLmxlbmd0aClcbiAgICAgICAgOiBtaWRkbGU7XG4gICAgfVxuICAgIHRoaXMucmVzdCA9IGRhdGFVUkwuc3Vic3RyaW5nKGRhdGFVUkwuaW5kZXhPZignLCcpICsgMSk7XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRhdGFVUkxCeXRlc18oZGF0YVVybDogc3RyaW5nKTogVWludDhBcnJheSB7XG4gIGNvbnN0IHBhcnRzID0gbmV3IERhdGFVUkxQYXJ0cyhkYXRhVXJsKTtcbiAgaWYgKHBhcnRzLmJhc2U2NCkge1xuICAgIHJldHVybiBiYXNlNjRCeXRlc18oU3RyaW5nRm9ybWF0LkJBU0U2NCwgcGFydHMucmVzdCk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIHBlcmNlbnRFbmNvZGVkQnl0ZXNfKHBhcnRzLnJlc3QpO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkYXRhVVJMQ29udGVudFR5cGVfKGRhdGFVcmw6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICBjb25zdCBwYXJ0cyA9IG5ldyBEYXRhVVJMUGFydHMoZGF0YVVybCk7XG4gIHJldHVybiBwYXJ0cy5jb250ZW50VHlwZTtcbn1cblxuZnVuY3Rpb24gZW5kc1dpdGgoczogc3RyaW5nLCBlbmQ6IHN0cmluZyk6IGJvb2xlYW4ge1xuICBjb25zdCBsb25nRW5vdWdoID0gcy5sZW5ndGggPj0gZW5kLmxlbmd0aDtcbiAgaWYgKCFsb25nRW5vdWdoKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgcmV0dXJuIHMuc3Vic3RyaW5nKHMubGVuZ3RoIC0gZW5kLmxlbmd0aCkgPT09IGVuZDtcbn1cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDE3IEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbi8qKlxuICogQGZpbGUgUHJvdmlkZXMgYSBCbG9iLWxpa2Ugd3JhcHBlciBmb3IgdmFyaW91cyBiaW5hcnkgdHlwZXMgKGluY2x1ZGluZyB0aGVcbiAqIG5hdGl2ZSBCbG9iIHR5cGUpLiBUaGlzIG1ha2VzIGl0IHBvc3NpYmxlIHRvIHVwbG9hZCB0eXBlcyBsaWtlIEFycmF5QnVmZmVycyxcbiAqIG1ha2luZyB1cGxvYWRzIHBvc3NpYmxlIGluIGVudmlyb25tZW50cyB3aXRob3V0IHRoZSBuYXRpdmUgQmxvYiB0eXBlLlxuICovXG5pbXBvcnQgeyBzbGljZUJsb2IsIGdldEJsb2IgfSBmcm9tICcuL2ZzJztcbmltcG9ydCB7IFN0cmluZ0Zvcm1hdCwgZGF0YUZyb21TdHJpbmcgfSBmcm9tICcuL3N0cmluZyc7XG5pbXBvcnQgeyBpc05hdGl2ZUJsb2IsIGlzTmF0aXZlQmxvYkRlZmluZWQsIGlzU3RyaW5nIH0gZnJvbSAnLi90eXBlJztcblxuLyoqXG4gKiBAcGFyYW0gb3B0X2VsaWRlQ29weSAtIElmIHRydWUsIGRvZXNuJ3QgY29weSBtdXRhYmxlIGlucHV0IGRhdGFcbiAqICAgICAoZS5nLiBVaW50OEFycmF5cykuIFBhc3MgdHJ1ZSBvbmx5IGlmIHlvdSBrbm93IHRoZSBvYmplY3RzIHdpbGwgbm90IGJlXG4gKiAgICAgbW9kaWZpZWQgYWZ0ZXIgdGhpcyBibG9iJ3MgY29uc3RydWN0aW9uLlxuICpcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgY2xhc3MgRmJzQmxvYiB7XG4gIHByaXZhdGUgZGF0YV8hOiBCbG9iIHwgVWludDhBcnJheTtcbiAgcHJpdmF0ZSBzaXplXzogbnVtYmVyO1xuICBwcml2YXRlIHR5cGVfOiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IoZGF0YTogQmxvYiB8IFVpbnQ4QXJyYXkgfCBBcnJheUJ1ZmZlciwgZWxpZGVDb3B5PzogYm9vbGVhbikge1xuICAgIGxldCBzaXplOiBudW1iZXIgPSAwO1xuICAgIGxldCBibG9iVHlwZTogc3RyaW5nID0gJyc7XG4gICAgaWYgKGlzTmF0aXZlQmxvYihkYXRhKSkge1xuICAgICAgdGhpcy5kYXRhXyA9IGRhdGEgYXMgQmxvYjtcbiAgICAgIHNpemUgPSAoZGF0YSBhcyBCbG9iKS5zaXplO1xuICAgICAgYmxvYlR5cGUgPSAoZGF0YSBhcyBCbG9iKS50eXBlO1xuICAgIH0gZWxzZSBpZiAoZGF0YSBpbnN0YW5jZW9mIEFycmF5QnVmZmVyKSB7XG4gICAgICBpZiAoZWxpZGVDb3B5KSB7XG4gICAgICAgIHRoaXMuZGF0YV8gPSBuZXcgVWludDhBcnJheShkYXRhKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuZGF0YV8gPSBuZXcgVWludDhBcnJheShkYXRhLmJ5dGVMZW5ndGgpO1xuICAgICAgICB0aGlzLmRhdGFfLnNldChuZXcgVWludDhBcnJheShkYXRhKSk7XG4gICAgICB9XG4gICAgICBzaXplID0gdGhpcy5kYXRhXy5sZW5ndGg7XG4gICAgfSBlbHNlIGlmIChkYXRhIGluc3RhbmNlb2YgVWludDhBcnJheSkge1xuICAgICAgaWYgKGVsaWRlQ29weSkge1xuICAgICAgICB0aGlzLmRhdGFfID0gZGF0YSBhcyBVaW50OEFycmF5O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5kYXRhXyA9IG5ldyBVaW50OEFycmF5KGRhdGEubGVuZ3RoKTtcbiAgICAgICAgdGhpcy5kYXRhXy5zZXQoZGF0YSBhcyBVaW50OEFycmF5KTtcbiAgICAgIH1cbiAgICAgIHNpemUgPSBkYXRhLmxlbmd0aDtcbiAgICB9XG4gICAgdGhpcy5zaXplXyA9IHNpemU7XG4gICAgdGhpcy50eXBlXyA9IGJsb2JUeXBlO1xuICB9XG5cbiAgc2l6ZSgpOiBudW1iZXIge1xuICAgIHJldHVybiB0aGlzLnNpemVfO1xuICB9XG5cbiAgdHlwZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiB0aGlzLnR5cGVfO1xuICB9XG5cbiAgc2xpY2Uoc3RhcnRCeXRlOiBudW1iZXIsIGVuZEJ5dGU6IG51bWJlcik6IEZic0Jsb2IgfCBudWxsIHtcbiAgICBpZiAoaXNOYXRpdmVCbG9iKHRoaXMuZGF0YV8pKSB7XG4gICAgICBjb25zdCByZWFsQmxvYiA9IHRoaXMuZGF0YV8gYXMgQmxvYjtcbiAgICAgIGNvbnN0IHNsaWNlZCA9IHNsaWNlQmxvYihyZWFsQmxvYiwgc3RhcnRCeXRlLCBlbmRCeXRlKTtcbiAgICAgIGlmIChzbGljZWQgPT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgICByZXR1cm4gbmV3IEZic0Jsb2Ioc2xpY2VkKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3Qgc2xpY2UgPSBuZXcgVWludDhBcnJheShcbiAgICAgICAgKHRoaXMuZGF0YV8gYXMgVWludDhBcnJheSkuYnVmZmVyLFxuICAgICAgICBzdGFydEJ5dGUsXG4gICAgICAgIGVuZEJ5dGUgLSBzdGFydEJ5dGVcbiAgICAgICk7XG4gICAgICByZXR1cm4gbmV3IEZic0Jsb2Ioc2xpY2UsIHRydWUpO1xuICAgIH1cbiAgfVxuXG4gIHN0YXRpYyBnZXRCbG9iKC4uLmFyZ3M6IEFycmF5PHN0cmluZyB8IEZic0Jsb2I+KTogRmJzQmxvYiB8IG51bGwge1xuICAgIGlmIChpc05hdGl2ZUJsb2JEZWZpbmVkKCkpIHtcbiAgICAgIGNvbnN0IGJsb2JieTogQXJyYXk8QmxvYiB8IFVpbnQ4QXJyYXkgfCBzdHJpbmc+ID0gYXJncy5tYXAoXG4gICAgICAgICh2YWw6IHN0cmluZyB8IEZic0Jsb2IpOiBCbG9iIHwgVWludDhBcnJheSB8IHN0cmluZyA9PiB7XG4gICAgICAgICAgaWYgKHZhbCBpbnN0YW5jZW9mIEZic0Jsb2IpIHtcbiAgICAgICAgICAgIHJldHVybiB2YWwuZGF0YV87XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiB2YWw7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICApO1xuICAgICAgcmV0dXJuIG5ldyBGYnNCbG9iKGdldEJsb2IuYXBwbHkobnVsbCwgYmxvYmJ5KSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHVpbnQ4QXJyYXlzOiBVaW50OEFycmF5W10gPSBhcmdzLm1hcChcbiAgICAgICAgKHZhbDogc3RyaW5nIHwgRmJzQmxvYik6IFVpbnQ4QXJyYXkgPT4ge1xuICAgICAgICAgIGlmIChpc1N0cmluZyh2YWwpKSB7XG4gICAgICAgICAgICByZXR1cm4gZGF0YUZyb21TdHJpbmcoU3RyaW5nRm9ybWF0LlJBVywgdmFsIGFzIHN0cmluZykuZGF0YTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gQmxvYnMgZG9uJ3QgZXhpc3QsIHNvIHRoaXMgaGFzIHRvIGJlIGEgVWludDhBcnJheS5cbiAgICAgICAgICAgIHJldHVybiAodmFsIGFzIEZic0Jsb2IpLmRhdGFfIGFzIFVpbnQ4QXJyYXk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICApO1xuICAgICAgbGV0IGZpbmFsTGVuZ3RoID0gMDtcbiAgICAgIHVpbnQ4QXJyYXlzLmZvckVhY2goKGFycmF5OiBVaW50OEFycmF5KTogdm9pZCA9PiB7XG4gICAgICAgIGZpbmFsTGVuZ3RoICs9IGFycmF5LmJ5dGVMZW5ndGg7XG4gICAgICB9KTtcbiAgICAgIGNvbnN0IG1lcmdlZCA9IG5ldyBVaW50OEFycmF5KGZpbmFsTGVuZ3RoKTtcbiAgICAgIGxldCBpbmRleCA9IDA7XG4gICAgICB1aW50OEFycmF5cy5mb3JFYWNoKChhcnJheTogVWludDhBcnJheSkgPT4ge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGFycmF5Lmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgbWVyZ2VkW2luZGV4KytdID0gYXJyYXlbaV07XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIG5ldyBGYnNCbG9iKG1lcmdlZCwgdHJ1ZSk7XG4gICAgfVxuICB9XG5cbiAgdXBsb2FkRGF0YSgpOiBCbG9iIHwgVWludDhBcnJheSB7XG4gICAgcmV0dXJuIHRoaXMuZGF0YV87XG4gIH1cbn1cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDE3IEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5pbXBvcnQgeyBpc05vbkFycmF5T2JqZWN0IH0gZnJvbSAnLi90eXBlJztcblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBPYmplY3QgcmVzdWx0aW5nIGZyb20gcGFyc2luZyB0aGUgZ2l2ZW4gSlNPTiwgb3IgbnVsbCBpZiB0aGVcbiAqIGdpdmVuIHN0cmluZyBkb2VzIG5vdCByZXByZXNlbnQgYSBKU09OIG9iamVjdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGpzb25PYmplY3RPck51bGwoXG4gIHM6IHN0cmluZ1xuKTogeyBbbmFtZTogc3RyaW5nXTogdW5rbm93biB9IHwgbnVsbCB7XG4gIGxldCBvYmo7XG4gIHRyeSB7XG4gICAgb2JqID0gSlNPTi5wYXJzZShzKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGlmIChpc05vbkFycmF5T2JqZWN0KG9iaikpIHtcbiAgICByZXR1cm4gb2JqO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAxNyBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG4vKipcbiAqIEBmaWxlb3ZlcnZpZXcgQ29udGFpbnMgaGVscGVyIG1ldGhvZHMgZm9yIG1hbmlwdWxhdGluZyBwYXRocy5cbiAqL1xuXG4vKipcbiAqIEByZXR1cm4gTnVsbCBpZiB0aGUgcGF0aCBpcyBhbHJlYWR5IGF0IHRoZSByb290LlxuICovXG5leHBvcnQgZnVuY3Rpb24gcGFyZW50KHBhdGg6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICBpZiAocGF0aC5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBjb25zdCBpbmRleCA9IHBhdGgubGFzdEluZGV4T2YoJy8nKTtcbiAgaWYgKGluZGV4ID09PSAtMSkge1xuICAgIHJldHVybiAnJztcbiAgfVxuICBjb25zdCBuZXdQYXRoID0gcGF0aC5zbGljZSgwLCBpbmRleCk7XG4gIHJldHVybiBuZXdQYXRoO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY2hpbGQocGF0aDogc3RyaW5nLCBjaGlsZFBhdGg6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IGNhbm9uaWNhbENoaWxkUGF0aCA9IGNoaWxkUGF0aFxuICAgIC5zcGxpdCgnLycpXG4gICAgLmZpbHRlcihjb21wb25lbnQgPT4gY29tcG9uZW50Lmxlbmd0aCA+IDApXG4gICAgLmpvaW4oJy8nKTtcbiAgaWYgKHBhdGgubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIGNhbm9uaWNhbENoaWxkUGF0aDtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gcGF0aCArICcvJyArIGNhbm9uaWNhbENoaWxkUGF0aDtcbiAgfVxufVxuXG4vKipcbiAqIFJldHVybnMgdGhlIGxhc3QgY29tcG9uZW50IG9mIGEgcGF0aC5cbiAqICcvZm9vL2JhcicgLT4gJ2JhcidcbiAqICcvZm9vL2Jhci9iYXovJyAtPiAnYmF6LydcbiAqICcvYScgLT4gJ2EnXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBsYXN0Q29tcG9uZW50KHBhdGg6IHN0cmluZyk6IHN0cmluZyB7XG4gIGNvbnN0IGluZGV4ID0gcGF0aC5sYXN0SW5kZXhPZignLycsIHBhdGgubGVuZ3RoIC0gMik7XG4gIGlmIChpbmRleCA9PT0gLTEpIHtcbiAgICByZXR1cm4gcGF0aDtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gcGF0aC5zbGljZShpbmRleCArIDEpO1xuICB9XG59XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAxNyBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG4vKipcbiAqIEBmaWxlb3ZlcnZpZXcgRG9jdW1lbnRhdGlvbiBmb3IgdGhlIG1ldGFkYXRhIGZvcm1hdFxuICovXG5pbXBvcnQgeyBNZXRhZGF0YSB9IGZyb20gJy4uL21ldGFkYXRhJztcblxuaW1wb3J0IHsganNvbk9iamVjdE9yTnVsbCB9IGZyb20gJy4vanNvbic7XG5pbXBvcnQgeyBMb2NhdGlvbiB9IGZyb20gJy4vbG9jYXRpb24nO1xuaW1wb3J0IHsgbGFzdENvbXBvbmVudCB9IGZyb20gJy4vcGF0aCc7XG5pbXBvcnQgeyBpc1N0cmluZyB9IGZyb20gJy4vdHlwZSc7XG5pbXBvcnQgeyBtYWtlVXJsLCBtYWtlUXVlcnlTdHJpbmcgfSBmcm9tICcuL3VybCc7XG5pbXBvcnQgeyBSZWZlcmVuY2UgfSBmcm9tICcuLi9yZWZlcmVuY2UnO1xuaW1wb3J0IHsgRmlyZWJhc2VTdG9yYWdlSW1wbCB9IGZyb20gJy4uL3NlcnZpY2UnO1xuXG5leHBvcnQgZnVuY3Rpb24gbm9YZm9ybV88VD4obWV0YWRhdGE6IE1ldGFkYXRhLCB2YWx1ZTogVCk6IFQge1xuICByZXR1cm4gdmFsdWU7XG59XG5cbmNsYXNzIE1hcHBpbmc8VD4ge1xuICBsb2NhbDogc3RyaW5nO1xuICB3cml0YWJsZTogYm9vbGVhbjtcbiAgeGZvcm06IChwMTogTWV0YWRhdGEsIHAyPzogVCkgPT4gVCB8IHVuZGVmaW5lZDtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwdWJsaWMgc2VydmVyOiBzdHJpbmcsXG4gICAgbG9jYWw/OiBzdHJpbmcgfCBudWxsLFxuICAgIHdyaXRhYmxlPzogYm9vbGVhbixcbiAgICB4Zm9ybT86ICgocDE6IE1ldGFkYXRhLCBwMj86IFQpID0+IFQgfCB1bmRlZmluZWQpIHwgbnVsbFxuICApIHtcbiAgICB0aGlzLmxvY2FsID0gbG9jYWwgfHwgc2VydmVyO1xuICAgIHRoaXMud3JpdGFibGUgPSAhIXdyaXRhYmxlO1xuICAgIHRoaXMueGZvcm0gPSB4Zm9ybSB8fCBub1hmb3JtXztcbiAgfVxufVxudHlwZSBNYXBwaW5ncyA9IEFycmF5PE1hcHBpbmc8c3RyaW5nPiB8IE1hcHBpbmc8bnVtYmVyPj47XG5cbmV4cG9ydCB7IE1hcHBpbmdzIH07XG5cbmxldCBtYXBwaW5nc186IE1hcHBpbmdzIHwgbnVsbCA9IG51bGw7XG5cbmV4cG9ydCBmdW5jdGlvbiB4Zm9ybVBhdGgoZnVsbFBhdGg6IHN0cmluZyB8IHVuZGVmaW5lZCk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gIGlmICghaXNTdHJpbmcoZnVsbFBhdGgpIHx8IGZ1bGxQYXRoLmxlbmd0aCA8IDIpIHtcbiAgICByZXR1cm4gZnVsbFBhdGg7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIGxhc3RDb21wb25lbnQoZnVsbFBhdGgpO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRNYXBwaW5ncygpOiBNYXBwaW5ncyB7XG4gIGlmIChtYXBwaW5nc18pIHtcbiAgICByZXR1cm4gbWFwcGluZ3NfO1xuICB9XG4gIGNvbnN0IG1hcHBpbmdzOiBNYXBwaW5ncyA9IFtdO1xuICBtYXBwaW5ncy5wdXNoKG5ldyBNYXBwaW5nPHN0cmluZz4oJ2J1Y2tldCcpKTtcbiAgbWFwcGluZ3MucHVzaChuZXcgTWFwcGluZzxzdHJpbmc+KCdnZW5lcmF0aW9uJykpO1xuICBtYXBwaW5ncy5wdXNoKG5ldyBNYXBwaW5nPHN0cmluZz4oJ21ldGFnZW5lcmF0aW9uJykpO1xuICBtYXBwaW5ncy5wdXNoKG5ldyBNYXBwaW5nPHN0cmluZz4oJ25hbWUnLCAnZnVsbFBhdGgnLCB0cnVlKSk7XG5cbiAgZnVuY3Rpb24gbWFwcGluZ3NYZm9ybVBhdGgoXG4gICAgX21ldGFkYXRhOiBNZXRhZGF0YSxcbiAgICBmdWxsUGF0aDogc3RyaW5nIHwgdW5kZWZpbmVkXG4gICk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgcmV0dXJuIHhmb3JtUGF0aChmdWxsUGF0aCk7XG4gIH1cbiAgY29uc3QgbmFtZU1hcHBpbmcgPSBuZXcgTWFwcGluZzxzdHJpbmc+KCduYW1lJyk7XG4gIG5hbWVNYXBwaW5nLnhmb3JtID0gbWFwcGluZ3NYZm9ybVBhdGg7XG4gIG1hcHBpbmdzLnB1c2gobmFtZU1hcHBpbmcpO1xuXG4gIC8qKlxuICAgKiBDb2VyY2VzIHRoZSBzZWNvbmQgcGFyYW0gdG8gYSBudW1iZXIsIGlmIGl0IGlzIGRlZmluZWQuXG4gICAqL1xuICBmdW5jdGlvbiB4Zm9ybVNpemUoXG4gICAgX21ldGFkYXRhOiBNZXRhZGF0YSxcbiAgICBzaXplPzogbnVtYmVyIHwgc3RyaW5nXG4gICk6IG51bWJlciB8IHVuZGVmaW5lZCB7XG4gICAgaWYgKHNpemUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuIE51bWJlcihzaXplKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHNpemU7XG4gICAgfVxuICB9XG4gIGNvbnN0IHNpemVNYXBwaW5nID0gbmV3IE1hcHBpbmc8bnVtYmVyPignc2l6ZScpO1xuICBzaXplTWFwcGluZy54Zm9ybSA9IHhmb3JtU2l6ZTtcbiAgbWFwcGluZ3MucHVzaChzaXplTWFwcGluZyk7XG4gIG1hcHBpbmdzLnB1c2gobmV3IE1hcHBpbmc8bnVtYmVyPigndGltZUNyZWF0ZWQnKSk7XG4gIG1hcHBpbmdzLnB1c2gobmV3IE1hcHBpbmc8c3RyaW5nPigndXBkYXRlZCcpKTtcbiAgbWFwcGluZ3MucHVzaChuZXcgTWFwcGluZzxzdHJpbmc+KCdtZDVIYXNoJywgbnVsbCwgdHJ1ZSkpO1xuICBtYXBwaW5ncy5wdXNoKG5ldyBNYXBwaW5nPHN0cmluZz4oJ2NhY2hlQ29udHJvbCcsIG51bGwsIHRydWUpKTtcbiAgbWFwcGluZ3MucHVzaChuZXcgTWFwcGluZzxzdHJpbmc+KCdjb250ZW50RGlzcG9zaXRpb24nLCBudWxsLCB0cnVlKSk7XG4gIG1hcHBpbmdzLnB1c2gobmV3IE1hcHBpbmc8c3RyaW5nPignY29udGVudEVuY29kaW5nJywgbnVsbCwgdHJ1ZSkpO1xuICBtYXBwaW5ncy5wdXNoKG5ldyBNYXBwaW5nPHN0cmluZz4oJ2NvbnRlbnRMYW5ndWFnZScsIG51bGwsIHRydWUpKTtcbiAgbWFwcGluZ3MucHVzaChuZXcgTWFwcGluZzxzdHJpbmc+KCdjb250ZW50VHlwZScsIG51bGwsIHRydWUpKTtcbiAgbWFwcGluZ3MucHVzaChuZXcgTWFwcGluZzxzdHJpbmc+KCdtZXRhZGF0YScsICdjdXN0b21NZXRhZGF0YScsIHRydWUpKTtcbiAgbWFwcGluZ3NfID0gbWFwcGluZ3M7XG4gIHJldHVybiBtYXBwaW5nc187XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhZGRSZWYobWV0YWRhdGE6IE1ldGFkYXRhLCBzZXJ2aWNlOiBGaXJlYmFzZVN0b3JhZ2VJbXBsKTogdm9pZCB7XG4gIGZ1bmN0aW9uIGdlbmVyYXRlUmVmKCk6IFJlZmVyZW5jZSB7XG4gICAgY29uc3QgYnVja2V0OiBzdHJpbmcgPSBtZXRhZGF0YVsnYnVja2V0J10gYXMgc3RyaW5nO1xuICAgIGNvbnN0IHBhdGg6IHN0cmluZyA9IG1ldGFkYXRhWydmdWxsUGF0aCddIGFzIHN0cmluZztcbiAgICBjb25zdCBsb2MgPSBuZXcgTG9jYXRpb24oYnVja2V0LCBwYXRoKTtcbiAgICByZXR1cm4gc2VydmljZS5fbWFrZVN0b3JhZ2VSZWZlcmVuY2UobG9jKTtcbiAgfVxuICBPYmplY3QuZGVmaW5lUHJvcGVydHkobWV0YWRhdGEsICdyZWYnLCB7IGdldDogZ2VuZXJhdGVSZWYgfSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBmcm9tUmVzb3VyY2UoXG4gIHNlcnZpY2U6IEZpcmViYXNlU3RvcmFnZUltcGwsXG4gIHJlc291cmNlOiB7IFtuYW1lOiBzdHJpbmddOiB1bmtub3duIH0sXG4gIG1hcHBpbmdzOiBNYXBwaW5nc1xuKTogTWV0YWRhdGEge1xuICBjb25zdCBtZXRhZGF0YTogTWV0YWRhdGEgPSB7fSBhcyBNZXRhZGF0YTtcbiAgbWV0YWRhdGFbJ3R5cGUnXSA9ICdmaWxlJztcbiAgY29uc3QgbGVuID0gbWFwcGluZ3MubGVuZ3RoO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgY29uc3QgbWFwcGluZyA9IG1hcHBpbmdzW2ldO1xuICAgIG1ldGFkYXRhW21hcHBpbmcubG9jYWxdID0gKG1hcHBpbmcgYXMgTWFwcGluZzx1bmtub3duPikueGZvcm0oXG4gICAgICBtZXRhZGF0YSxcbiAgICAgIHJlc291cmNlW21hcHBpbmcuc2VydmVyXVxuICAgICk7XG4gIH1cbiAgYWRkUmVmKG1ldGFkYXRhLCBzZXJ2aWNlKTtcbiAgcmV0dXJuIG1ldGFkYXRhO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZnJvbVJlc291cmNlU3RyaW5nKFxuICBzZXJ2aWNlOiBGaXJlYmFzZVN0b3JhZ2VJbXBsLFxuICByZXNvdXJjZVN0cmluZzogc3RyaW5nLFxuICBtYXBwaW5nczogTWFwcGluZ3Ncbik6IE1ldGFkYXRhIHwgbnVsbCB7XG4gIGNvbnN0IG9iaiA9IGpzb25PYmplY3RPck51bGwocmVzb3VyY2VTdHJpbmcpO1xuICBpZiAob2JqID09PSBudWxsKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgcmVzb3VyY2UgPSBvYmogYXMgTWV0YWRhdGE7XG4gIHJldHVybiBmcm9tUmVzb3VyY2Uoc2VydmljZSwgcmVzb3VyY2UsIG1hcHBpbmdzKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRvd25sb2FkVXJsRnJvbVJlc291cmNlU3RyaW5nKFxuICBtZXRhZGF0YTogTWV0YWRhdGEsXG4gIHJlc291cmNlU3RyaW5nOiBzdHJpbmcsXG4gIGhvc3Q6IHN0cmluZyxcbiAgcHJvdG9jb2w6IHN0cmluZ1xuKTogc3RyaW5nIHwgbnVsbCB7XG4gIGNvbnN0IG9iaiA9IGpzb25PYmplY3RPck51bGwocmVzb3VyY2VTdHJpbmcpO1xuICBpZiAob2JqID09PSBudWxsKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgaWYgKCFpc1N0cmluZyhvYmpbJ2Rvd25sb2FkVG9rZW5zJ10pKSB7XG4gICAgLy8gVGhpcyBjYW4gaGFwcGVuIGlmIG9iamVjdHMgYXJlIHVwbG9hZGVkIHRocm91Z2ggR0NTIGFuZCByZXRyaWV2ZWRcbiAgICAvLyB0aHJvdWdoIGxpc3QsIHNvIHdlIGRvbid0IHdhbnQgdG8gdGhyb3cgYW4gRXJyb3IuXG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgdG9rZW5zOiBzdHJpbmcgPSBvYmpbJ2Rvd25sb2FkVG9rZW5zJ10gYXMgc3RyaW5nO1xuICBpZiAodG9rZW5zLmxlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGNvbnN0IGVuY29kZSA9IGVuY29kZVVSSUNvbXBvbmVudDtcbiAgY29uc3QgdG9rZW5zTGlzdCA9IHRva2Vucy5zcGxpdCgnLCcpO1xuICBjb25zdCB1cmxzID0gdG9rZW5zTGlzdC5tYXAoKHRva2VuOiBzdHJpbmcpOiBzdHJpbmcgPT4ge1xuICAgIGNvbnN0IGJ1Y2tldDogc3RyaW5nID0gbWV0YWRhdGFbJ2J1Y2tldCddIGFzIHN0cmluZztcbiAgICBjb25zdCBwYXRoOiBzdHJpbmcgPSBtZXRhZGF0YVsnZnVsbFBhdGgnXSBhcyBzdHJpbmc7XG4gICAgY29uc3QgdXJsUGFydCA9ICcvYi8nICsgZW5jb2RlKGJ1Y2tldCkgKyAnL28vJyArIGVuY29kZShwYXRoKTtcbiAgICBjb25zdCBiYXNlID0gbWFrZVVybCh1cmxQYXJ0LCBob3N0LCBwcm90b2NvbCk7XG4gICAgY29uc3QgcXVlcnlTdHJpbmcgPSBtYWtlUXVlcnlTdHJpbmcoe1xuICAgICAgYWx0OiAnbWVkaWEnLFxuICAgICAgdG9rZW5cbiAgICB9KTtcbiAgICByZXR1cm4gYmFzZSArIHF1ZXJ5U3RyaW5nO1xuICB9KTtcbiAgcmV0dXJuIHVybHNbMF07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB0b1Jlc291cmNlU3RyaW5nKFxuICBtZXRhZGF0YTogUGFydGlhbDxNZXRhZGF0YT4sXG4gIG1hcHBpbmdzOiBNYXBwaW5nc1xuKTogc3RyaW5nIHtcbiAgY29uc3QgcmVzb3VyY2U6IHtcbiAgICBbcHJvcDogc3RyaW5nXTogdW5rbm93bjtcbiAgfSA9IHt9O1xuICBjb25zdCBsZW4gPSBtYXBwaW5ncy5sZW5ndGg7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICBjb25zdCBtYXBwaW5nID0gbWFwcGluZ3NbaV07XG4gICAgaWYgKG1hcHBpbmcud3JpdGFibGUpIHtcbiAgICAgIHJlc291cmNlW21hcHBpbmcuc2VydmVyXSA9IG1ldGFkYXRhW21hcHBpbmcubG9jYWxdO1xuICAgIH1cbiAgfVxuICByZXR1cm4gSlNPTi5zdHJpbmdpZnkocmVzb3VyY2UpO1xufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuLyoqXG4gKiBAZmlsZW92ZXJ2aWV3IERvY3VtZW50YXRpb24gZm9yIHRoZSBsaXN0T3B0aW9ucyBhbmQgbGlzdFJlc3VsdCBmb3JtYXRcbiAqL1xuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tICcuL2xvY2F0aW9uJztcbmltcG9ydCB7IGpzb25PYmplY3RPck51bGwgfSBmcm9tICcuL2pzb24nO1xuaW1wb3J0IHsgTGlzdFJlc3VsdCB9IGZyb20gJy4uL2xpc3QnO1xuaW1wb3J0IHsgRmlyZWJhc2VTdG9yYWdlSW1wbCB9IGZyb20gJy4uL3NlcnZpY2UnO1xuXG4vKipcbiAqIFJlcHJlc2VudHMgdGhlIHNpbXBsaWZpZWQgb2JqZWN0IG1ldGFkYXRhIHJldHVybmVkIGJ5IExpc3QgQVBJLlxuICogT3RoZXIgZmllbGRzIGFyZSBmaWx0ZXJlZCBiZWNhdXNlIGxpc3QgaW4gRmlyZWJhc2UgUnVsZXMgZG9lcyBub3QgZ3JhbnRcbiAqIHRoZSBwZXJtaXNzaW9uIHRvIHJlYWQgdGhlIG1ldGFkYXRhLlxuICovXG5pbnRlcmZhY2UgTGlzdE1ldGFkYXRhUmVzcG9uc2Uge1xuICBuYW1lOiBzdHJpbmc7XG4gIGJ1Y2tldDogc3RyaW5nO1xufVxuXG4vKipcbiAqIFJlcHJlc2VudHMgdGhlIEpTT04gcmVzcG9uc2Ugb2YgTGlzdCBBUEkuXG4gKi9cbmludGVyZmFjZSBMaXN0UmVzdWx0UmVzcG9uc2Uge1xuICBwcmVmaXhlczogc3RyaW5nW107XG4gIGl0ZW1zOiBMaXN0TWV0YWRhdGFSZXNwb25zZVtdO1xuICBuZXh0UGFnZVRva2VuPzogc3RyaW5nO1xufVxuXG5jb25zdCBQUkVGSVhFU19LRVkgPSAncHJlZml4ZXMnO1xuY29uc3QgSVRFTVNfS0VZID0gJ2l0ZW1zJztcblxuZnVuY3Rpb24gZnJvbUJhY2tlbmRSZXNwb25zZShcbiAgc2VydmljZTogRmlyZWJhc2VTdG9yYWdlSW1wbCxcbiAgYnVja2V0OiBzdHJpbmcsXG4gIHJlc291cmNlOiBMaXN0UmVzdWx0UmVzcG9uc2Vcbik6IExpc3RSZXN1bHQge1xuICBjb25zdCBsaXN0UmVzdWx0OiBMaXN0UmVzdWx0ID0ge1xuICAgIHByZWZpeGVzOiBbXSxcbiAgICBpdGVtczogW10sXG4gICAgbmV4dFBhZ2VUb2tlbjogcmVzb3VyY2VbJ25leHRQYWdlVG9rZW4nXVxuICB9O1xuICBpZiAocmVzb3VyY2VbUFJFRklYRVNfS0VZXSkge1xuICAgIGZvciAoY29uc3QgcGF0aCBvZiByZXNvdXJjZVtQUkVGSVhFU19LRVldKSB7XG4gICAgICBjb25zdCBwYXRoV2l0aG91dFRyYWlsaW5nU2xhc2ggPSBwYXRoLnJlcGxhY2UoL1xcLyQvLCAnJyk7XG4gICAgICBjb25zdCByZWZlcmVuY2UgPSBzZXJ2aWNlLl9tYWtlU3RvcmFnZVJlZmVyZW5jZShcbiAgICAgICAgbmV3IExvY2F0aW9uKGJ1Y2tldCwgcGF0aFdpdGhvdXRUcmFpbGluZ1NsYXNoKVxuICAgICAgKTtcbiAgICAgIGxpc3RSZXN1bHQucHJlZml4ZXMucHVzaChyZWZlcmVuY2UpO1xuICAgIH1cbiAgfVxuXG4gIGlmIChyZXNvdXJjZVtJVEVNU19LRVldKSB7XG4gICAgZm9yIChjb25zdCBpdGVtIG9mIHJlc291cmNlW0lURU1TX0tFWV0pIHtcbiAgICAgIGNvbnN0IHJlZmVyZW5jZSA9IHNlcnZpY2UuX21ha2VTdG9yYWdlUmVmZXJlbmNlKFxuICAgICAgICBuZXcgTG9jYXRpb24oYnVja2V0LCBpdGVtWyduYW1lJ10pXG4gICAgICApO1xuICAgICAgbGlzdFJlc3VsdC5pdGVtcy5wdXNoKHJlZmVyZW5jZSk7XG4gICAgfVxuICB9XG4gIHJldHVybiBsaXN0UmVzdWx0O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZnJvbVJlc3BvbnNlU3RyaW5nKFxuICBzZXJ2aWNlOiBGaXJlYmFzZVN0b3JhZ2VJbXBsLFxuICBidWNrZXQ6IHN0cmluZyxcbiAgcmVzb3VyY2VTdHJpbmc6IHN0cmluZ1xuKTogTGlzdFJlc3VsdCB8IG51bGwge1xuICBjb25zdCBvYmogPSBqc29uT2JqZWN0T3JOdWxsKHJlc291cmNlU3RyaW5nKTtcbiAgaWYgKG9iaiA9PT0gbnVsbCkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGNvbnN0IHJlc291cmNlID0gb2JqIGFzIHVua25vd24gYXMgTGlzdFJlc3VsdFJlc3BvbnNlO1xuICByZXR1cm4gZnJvbUJhY2tlbmRSZXNwb25zZShzZXJ2aWNlLCBidWNrZXQsIHJlc291cmNlKTtcbn1cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDE3IEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5pbXBvcnQgeyBTdG9yYWdlRXJyb3IgfSBmcm9tICcuL2Vycm9yJztcbmltcG9ydCB7IEhlYWRlcnMsIENvbm5lY3Rpb24sIENvbm5lY3Rpb25UeXBlIH0gZnJvbSAnLi9jb25uZWN0aW9uJztcblxuLyoqXG4gKiBUeXBlIGZvciB1cmwgcGFyYW1zIHN0b3JlZCBpbiBSZXF1ZXN0SW5mby5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBVcmxQYXJhbXMge1xuICBbbmFtZTogc3RyaW5nXTogc3RyaW5nIHwgbnVtYmVyO1xufVxuXG4vKipcbiAqIEEgZnVuY3Rpb24gdGhhdCBjb252ZXJ0cyBhIHNlcnZlciByZXNwb25zZSB0byB0aGUgQVBJIHR5cGUgZXhwZWN0ZWQgYnkgdGhlXG4gKiBTREsuXG4gKlxuICogQHBhcmFtIEkgLSB0aGUgdHlwZSBvZiB0aGUgYmFja2VuZCdzIG5ldHdvcmsgcmVzcG9uc2VcbiAqIEBwYXJhbSBPIC0gdGhlIG91dHB1dCByZXNwb25zZSB0eXBlIHVzZWQgYnkgdGhlIHJlc3Qgb2YgdGhlIFNESy5cbiAqL1xuZXhwb3J0IHR5cGUgUmVxdWVzdEhhbmRsZXI8SSBleHRlbmRzIENvbm5lY3Rpb25UeXBlLCBPPiA9IChcbiAgY29ubmVjdGlvbjogQ29ubmVjdGlvbjxJPixcbiAgcmVzcG9uc2U6IElcbikgPT4gTztcblxuLyoqIEEgZnVuY3Rpb24gdG8gaGFuZGxlIGFuIGVycm9yLiAqL1xuZXhwb3J0IHR5cGUgRXJyb3JIYW5kbGVyID0gKFxuICBjb25uZWN0aW9uOiBDb25uZWN0aW9uPENvbm5lY3Rpb25UeXBlPixcbiAgcmVzcG9uc2U6IFN0b3JhZ2VFcnJvclxuKSA9PiBTdG9yYWdlRXJyb3I7XG5cbi8qKlxuICogQ29udGFpbnMgYSBmdWxseSBzcGVjaWZpZWQgcmVxdWVzdC5cbiAqXG4gKiBAcGFyYW0gSSAtIHRoZSB0eXBlIG9mIHRoZSBiYWNrZW5kJ3MgbmV0d29yayByZXNwb25zZS5cbiAqIEBwYXJhbSBPIC0gdGhlIG91dHB1dCByZXNwb25zZSB0eXBlIHVzZWQgYnkgdGhlIHJlc3Qgb2YgdGhlIFNESy5cbiAqL1xuZXhwb3J0IGNsYXNzIFJlcXVlc3RJbmZvPEkgZXh0ZW5kcyBDb25uZWN0aW9uVHlwZSwgTz4ge1xuICB1cmxQYXJhbXM6IFVybFBhcmFtcyA9IHt9O1xuICBoZWFkZXJzOiBIZWFkZXJzID0ge307XG4gIGJvZHk6IEJsb2IgfCBzdHJpbmcgfCBVaW50OEFycmF5IHwgbnVsbCA9IG51bGw7XG4gIGVycm9ySGFuZGxlcjogRXJyb3JIYW5kbGVyIHwgbnVsbCA9IG51bGw7XG5cbiAgLyoqXG4gICAqIENhbGxlZCB3aXRoIHRoZSBjdXJyZW50IG51bWJlciBvZiBieXRlcyB1cGxvYWRlZCBhbmQgdG90YWwgc2l6ZSAoLTEgaWYgbm90XG4gICAqIGNvbXB1dGFibGUpIG9mIHRoZSByZXF1ZXN0IGJvZHkgKGkuZS4gdXNlZCB0byByZXBvcnQgdXBsb2FkIHByb2dyZXNzKS5cbiAgICovXG4gIHByb2dyZXNzQ2FsbGJhY2s6ICgocDE6IG51bWJlciwgcDI6IG51bWJlcikgPT4gdm9pZCkgfCBudWxsID0gbnVsbDtcbiAgc3VjY2Vzc0NvZGVzOiBudW1iZXJbXSA9IFsyMDBdO1xuICBhZGRpdGlvbmFsUmV0cnlDb2RlczogbnVtYmVyW10gPSBbXTtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwdWJsaWMgdXJsOiBzdHJpbmcsXG4gICAgcHVibGljIG1ldGhvZDogc3RyaW5nLFxuICAgIC8qKlxuICAgICAqIFJldHVybnMgdGhlIHZhbHVlIHdpdGggd2hpY2ggdG8gcmVzb2x2ZSB0aGUgcmVxdWVzdCdzIHByb21pc2UuIE9ubHkgY2FsbGVkXG4gICAgICogaWYgdGhlIHJlcXVlc3QgaXMgc3VjY2Vzc2Z1bC4gVGhyb3cgZnJvbSB0aGlzIGZ1bmN0aW9uIHRvIHJlamVjdCB0aGVcbiAgICAgKiByZXR1cm5lZCBSZXF1ZXN0J3MgcHJvbWlzZSB3aXRoIHRoZSB0aHJvd24gZXJyb3IuXG4gICAgICogTm90ZTogVGhlIFhocklvIHBhc3NlZCB0byB0aGlzIGZ1bmN0aW9uIG1heSBiZSByZXVzZWQgYWZ0ZXIgdGhpcyBjYWxsYmFja1xuICAgICAqIHJldHVybnMuIERvIG5vdCBrZWVwIGEgcmVmZXJlbmNlIHRvIGl0IGluIGFueSB3YXkuXG4gICAgICovXG4gICAgcHVibGljIGhhbmRsZXI6IFJlcXVlc3RIYW5kbGVyPEksIE8+LFxuICAgIHB1YmxpYyB0aW1lb3V0OiBudW1iZXJcbiAgKSB7fVxufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMTcgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuLyoqXG4gKiBAZmlsZW92ZXJ2aWV3IERlZmluZXMgbWV0aG9kcyBmb3IgaW50ZXJhY3Rpbmcgd2l0aCB0aGUgbmV0d29yay5cbiAqL1xuXG5pbXBvcnQgeyBNZXRhZGF0YSB9IGZyb20gJy4uL21ldGFkYXRhJztcbmltcG9ydCB7IExpc3RSZXN1bHQgfSBmcm9tICcuLi9saXN0JztcbmltcG9ydCB7IEZic0Jsb2IgfSBmcm9tICcuL2Jsb2InO1xuaW1wb3J0IHtcbiAgU3RvcmFnZUVycm9yLFxuICBjYW5ub3RTbGljZUJsb2IsXG4gIHVuYXV0aGVudGljYXRlZCxcbiAgcXVvdGFFeGNlZWRlZCxcbiAgdW5hdXRob3JpemVkLFxuICBvYmplY3ROb3RGb3VuZCxcbiAgc2VydmVyRmlsZVdyb25nU2l6ZSxcbiAgdW5rbm93bixcbiAgdW5hdXRob3JpemVkQXBwXG59IGZyb20gJy4vZXJyb3InO1xuaW1wb3J0IHsgTG9jYXRpb24gfSBmcm9tICcuL2xvY2F0aW9uJztcbmltcG9ydCB7XG4gIE1hcHBpbmdzLFxuICBmcm9tUmVzb3VyY2VTdHJpbmcsXG4gIGRvd25sb2FkVXJsRnJvbVJlc291cmNlU3RyaW5nLFxuICB0b1Jlc291cmNlU3RyaW5nXG59IGZyb20gJy4vbWV0YWRhdGEnO1xuaW1wb3J0IHsgZnJvbVJlc3BvbnNlU3RyaW5nIH0gZnJvbSAnLi9saXN0JztcbmltcG9ydCB7IFJlcXVlc3RJbmZvLCBVcmxQYXJhbXMgfSBmcm9tICcuL3JlcXVlc3RpbmZvJztcbmltcG9ydCB7IGlzU3RyaW5nIH0gZnJvbSAnLi90eXBlJztcbmltcG9ydCB7IG1ha2VVcmwgfSBmcm9tICcuL3VybCc7XG5pbXBvcnQgeyBDb25uZWN0aW9uLCBDb25uZWN0aW9uVHlwZSB9IGZyb20gJy4vY29ubmVjdGlvbic7XG5pbXBvcnQgeyBGaXJlYmFzZVN0b3JhZ2VJbXBsIH0gZnJvbSAnLi4vc2VydmljZSc7XG5cbi8qKlxuICogVGhyb3dzIHRoZSBVTktOT1dOIFN0b3JhZ2VFcnJvciBpZiBjbmRuIGlzIGZhbHNlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gaGFuZGxlckNoZWNrKGNuZG46IGJvb2xlYW4pOiB2b2lkIHtcbiAgaWYgKCFjbmRuKSB7XG4gICAgdGhyb3cgdW5rbm93bigpO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBtZXRhZGF0YUhhbmRsZXIoXG4gIHNlcnZpY2U6IEZpcmViYXNlU3RvcmFnZUltcGwsXG4gIG1hcHBpbmdzOiBNYXBwaW5nc1xuKTogKHAxOiBDb25uZWN0aW9uPHN0cmluZz4sIHAyOiBzdHJpbmcpID0+IE1ldGFkYXRhIHtcbiAgZnVuY3Rpb24gaGFuZGxlcih4aHI6IENvbm5lY3Rpb248c3RyaW5nPiwgdGV4dDogc3RyaW5nKTogTWV0YWRhdGEge1xuICAgIGNvbnN0IG1ldGFkYXRhID0gZnJvbVJlc291cmNlU3RyaW5nKHNlcnZpY2UsIHRleHQsIG1hcHBpbmdzKTtcbiAgICBoYW5kbGVyQ2hlY2sobWV0YWRhdGEgIT09IG51bGwpO1xuICAgIHJldHVybiBtZXRhZGF0YSBhcyBNZXRhZGF0YTtcbiAgfVxuICByZXR1cm4gaGFuZGxlcjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGxpc3RIYW5kbGVyKFxuICBzZXJ2aWNlOiBGaXJlYmFzZVN0b3JhZ2VJbXBsLFxuICBidWNrZXQ6IHN0cmluZ1xuKTogKHAxOiBDb25uZWN0aW9uPHN0cmluZz4sIHAyOiBzdHJpbmcpID0+IExpc3RSZXN1bHQge1xuICBmdW5jdGlvbiBoYW5kbGVyKHhocjogQ29ubmVjdGlvbjxzdHJpbmc+LCB0ZXh0OiBzdHJpbmcpOiBMaXN0UmVzdWx0IHtcbiAgICBjb25zdCBsaXN0UmVzdWx0ID0gZnJvbVJlc3BvbnNlU3RyaW5nKHNlcnZpY2UsIGJ1Y2tldCwgdGV4dCk7XG4gICAgaGFuZGxlckNoZWNrKGxpc3RSZXN1bHQgIT09IG51bGwpO1xuICAgIHJldHVybiBsaXN0UmVzdWx0IGFzIExpc3RSZXN1bHQ7XG4gIH1cbiAgcmV0dXJuIGhhbmRsZXI7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkb3dubG9hZFVybEhhbmRsZXIoXG4gIHNlcnZpY2U6IEZpcmViYXNlU3RvcmFnZUltcGwsXG4gIG1hcHBpbmdzOiBNYXBwaW5nc1xuKTogKHAxOiBDb25uZWN0aW9uPHN0cmluZz4sIHAyOiBzdHJpbmcpID0+IHN0cmluZyB8IG51bGwge1xuICBmdW5jdGlvbiBoYW5kbGVyKHhocjogQ29ubmVjdGlvbjxzdHJpbmc+LCB0ZXh0OiBzdHJpbmcpOiBzdHJpbmcgfCBudWxsIHtcbiAgICBjb25zdCBtZXRhZGF0YSA9IGZyb21SZXNvdXJjZVN0cmluZyhzZXJ2aWNlLCB0ZXh0LCBtYXBwaW5ncyk7XG4gICAgaGFuZGxlckNoZWNrKG1ldGFkYXRhICE9PSBudWxsKTtcbiAgICByZXR1cm4gZG93bmxvYWRVcmxGcm9tUmVzb3VyY2VTdHJpbmcoXG4gICAgICBtZXRhZGF0YSBhcyBNZXRhZGF0YSxcbiAgICAgIHRleHQsXG4gICAgICBzZXJ2aWNlLmhvc3QsXG4gICAgICBzZXJ2aWNlLl9wcm90b2NvbFxuICAgICk7XG4gIH1cbiAgcmV0dXJuIGhhbmRsZXI7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzaGFyZWRFcnJvckhhbmRsZXIoXG4gIGxvY2F0aW9uOiBMb2NhdGlvblxuKTogKHAxOiBDb25uZWN0aW9uPENvbm5lY3Rpb25UeXBlPiwgcDI6IFN0b3JhZ2VFcnJvcikgPT4gU3RvcmFnZUVycm9yIHtcbiAgZnVuY3Rpb24gZXJyb3JIYW5kbGVyKFxuICAgIHhocjogQ29ubmVjdGlvbjxDb25uZWN0aW9uVHlwZT4sXG4gICAgZXJyOiBTdG9yYWdlRXJyb3JcbiAgKTogU3RvcmFnZUVycm9yIHtcbiAgICBsZXQgbmV3RXJyOiBTdG9yYWdlRXJyb3I7XG4gICAgaWYgKHhoci5nZXRTdGF0dXMoKSA9PT0gNDAxKSB7XG4gICAgICBpZiAoXG4gICAgICAgIC8vIFRoaXMgZXhhY3QgbWVzc2FnZSBzdHJpbmcgaXMgdGhlIG9ubHkgY29uc2lzdGVudCBwYXJ0IG9mIHRoZVxuICAgICAgICAvLyBzZXJ2ZXIncyBlcnJvciByZXNwb25zZSB0aGF0IGlkZW50aWZpZXMgaXQgYXMgYW4gQXBwIENoZWNrIGVycm9yLlxuICAgICAgICB4aHIuZ2V0RXJyb3JUZXh0KCkuaW5jbHVkZXMoJ0ZpcmViYXNlIEFwcCBDaGVjayB0b2tlbiBpcyBpbnZhbGlkJylcbiAgICAgICkge1xuICAgICAgICBuZXdFcnIgPSB1bmF1dGhvcml6ZWRBcHAoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG5ld0VyciA9IHVuYXV0aGVudGljYXRlZCgpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoeGhyLmdldFN0YXR1cygpID09PSA0MDIpIHtcbiAgICAgICAgbmV3RXJyID0gcXVvdGFFeGNlZWRlZChsb2NhdGlvbi5idWNrZXQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKHhoci5nZXRTdGF0dXMoKSA9PT0gNDAzKSB7XG4gICAgICAgICAgbmV3RXJyID0gdW5hdXRob3JpemVkKGxvY2F0aW9uLnBhdGgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG5ld0VyciA9IGVycjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBuZXdFcnIuc3RhdHVzID0geGhyLmdldFN0YXR1cygpO1xuICAgIG5ld0Vyci5zZXJ2ZXJSZXNwb25zZSA9IGVyci5zZXJ2ZXJSZXNwb25zZTtcbiAgICByZXR1cm4gbmV3RXJyO1xuICB9XG4gIHJldHVybiBlcnJvckhhbmRsZXI7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBvYmplY3RFcnJvckhhbmRsZXIoXG4gIGxvY2F0aW9uOiBMb2NhdGlvblxuKTogKHAxOiBDb25uZWN0aW9uPENvbm5lY3Rpb25UeXBlPiwgcDI6IFN0b3JhZ2VFcnJvcikgPT4gU3RvcmFnZUVycm9yIHtcbiAgY29uc3Qgc2hhcmVkID0gc2hhcmVkRXJyb3JIYW5kbGVyKGxvY2F0aW9uKTtcblxuICBmdW5jdGlvbiBlcnJvckhhbmRsZXIoXG4gICAgeGhyOiBDb25uZWN0aW9uPENvbm5lY3Rpb25UeXBlPixcbiAgICBlcnI6IFN0b3JhZ2VFcnJvclxuICApOiBTdG9yYWdlRXJyb3Ige1xuICAgIGxldCBuZXdFcnIgPSBzaGFyZWQoeGhyLCBlcnIpO1xuICAgIGlmICh4aHIuZ2V0U3RhdHVzKCkgPT09IDQwNCkge1xuICAgICAgbmV3RXJyID0gb2JqZWN0Tm90Rm91bmQobG9jYXRpb24ucGF0aCk7XG4gICAgfVxuICAgIG5ld0Vyci5zZXJ2ZXJSZXNwb25zZSA9IGVyci5zZXJ2ZXJSZXNwb25zZTtcbiAgICByZXR1cm4gbmV3RXJyO1xuICB9XG4gIHJldHVybiBlcnJvckhhbmRsZXI7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRNZXRhZGF0YShcbiAgc2VydmljZTogRmlyZWJhc2VTdG9yYWdlSW1wbCxcbiAgbG9jYXRpb246IExvY2F0aW9uLFxuICBtYXBwaW5nczogTWFwcGluZ3Ncbik6IFJlcXVlc3RJbmZvPHN0cmluZywgTWV0YWRhdGE+IHtcbiAgY29uc3QgdXJsUGFydCA9IGxvY2F0aW9uLmZ1bGxTZXJ2ZXJVcmwoKTtcbiAgY29uc3QgdXJsID0gbWFrZVVybCh1cmxQYXJ0LCBzZXJ2aWNlLmhvc3QsIHNlcnZpY2UuX3Byb3RvY29sKTtcbiAgY29uc3QgbWV0aG9kID0gJ0dFVCc7XG4gIGNvbnN0IHRpbWVvdXQgPSBzZXJ2aWNlLm1heE9wZXJhdGlvblJldHJ5VGltZTtcbiAgY29uc3QgcmVxdWVzdEluZm8gPSBuZXcgUmVxdWVzdEluZm8oXG4gICAgdXJsLFxuICAgIG1ldGhvZCxcbiAgICBtZXRhZGF0YUhhbmRsZXIoc2VydmljZSwgbWFwcGluZ3MpLFxuICAgIHRpbWVvdXRcbiAgKTtcbiAgcmVxdWVzdEluZm8uZXJyb3JIYW5kbGVyID0gb2JqZWN0RXJyb3JIYW5kbGVyKGxvY2F0aW9uKTtcbiAgcmV0dXJuIHJlcXVlc3RJbmZvO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gbGlzdChcbiAgc2VydmljZTogRmlyZWJhc2VTdG9yYWdlSW1wbCxcbiAgbG9jYXRpb246IExvY2F0aW9uLFxuICBkZWxpbWl0ZXI/OiBzdHJpbmcsXG4gIHBhZ2VUb2tlbj86IHN0cmluZyB8IG51bGwsXG4gIG1heFJlc3VsdHM/OiBudW1iZXIgfCBudWxsXG4pOiBSZXF1ZXN0SW5mbzxzdHJpbmcsIExpc3RSZXN1bHQ+IHtcbiAgY29uc3QgdXJsUGFyYW1zOiBVcmxQYXJhbXMgPSB7fTtcbiAgaWYgKGxvY2F0aW9uLmlzUm9vdCkge1xuICAgIHVybFBhcmFtc1sncHJlZml4J10gPSAnJztcbiAgfSBlbHNlIHtcbiAgICB1cmxQYXJhbXNbJ3ByZWZpeCddID0gbG9jYXRpb24ucGF0aCArICcvJztcbiAgfVxuICBpZiAoZGVsaW1pdGVyICYmIGRlbGltaXRlci5sZW5ndGggPiAwKSB7XG4gICAgdXJsUGFyYW1zWydkZWxpbWl0ZXInXSA9IGRlbGltaXRlcjtcbiAgfVxuICBpZiAocGFnZVRva2VuKSB7XG4gICAgdXJsUGFyYW1zWydwYWdlVG9rZW4nXSA9IHBhZ2VUb2tlbjtcbiAgfVxuICBpZiAobWF4UmVzdWx0cykge1xuICAgIHVybFBhcmFtc1snbWF4UmVzdWx0cyddID0gbWF4UmVzdWx0cztcbiAgfVxuICBjb25zdCB1cmxQYXJ0ID0gbG9jYXRpb24uYnVja2V0T25seVNlcnZlclVybCgpO1xuICBjb25zdCB1cmwgPSBtYWtlVXJsKHVybFBhcnQsIHNlcnZpY2UuaG9zdCwgc2VydmljZS5fcHJvdG9jb2wpO1xuICBjb25zdCBtZXRob2QgPSAnR0VUJztcbiAgY29uc3QgdGltZW91dCA9IHNlcnZpY2UubWF4T3BlcmF0aW9uUmV0cnlUaW1lO1xuICBjb25zdCByZXF1ZXN0SW5mbyA9IG5ldyBSZXF1ZXN0SW5mbyhcbiAgICB1cmwsXG4gICAgbWV0aG9kLFxuICAgIGxpc3RIYW5kbGVyKHNlcnZpY2UsIGxvY2F0aW9uLmJ1Y2tldCksXG4gICAgdGltZW91dFxuICApO1xuICByZXF1ZXN0SW5mby51cmxQYXJhbXMgPSB1cmxQYXJhbXM7XG4gIHJlcXVlc3RJbmZvLmVycm9ySGFuZGxlciA9IHNoYXJlZEVycm9ySGFuZGxlcihsb2NhdGlvbik7XG4gIHJldHVybiByZXF1ZXN0SW5mbztcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldEJ5dGVzPEkgZXh0ZW5kcyBDb25uZWN0aW9uVHlwZT4oXG4gIHNlcnZpY2U6IEZpcmViYXNlU3RvcmFnZUltcGwsXG4gIGxvY2F0aW9uOiBMb2NhdGlvbixcbiAgbWF4RG93bmxvYWRTaXplQnl0ZXM/OiBudW1iZXJcbik6IFJlcXVlc3RJbmZvPEksIEk+IHtcbiAgY29uc3QgdXJsUGFydCA9IGxvY2F0aW9uLmZ1bGxTZXJ2ZXJVcmwoKTtcbiAgY29uc3QgdXJsID0gbWFrZVVybCh1cmxQYXJ0LCBzZXJ2aWNlLmhvc3QsIHNlcnZpY2UuX3Byb3RvY29sKSArICc/YWx0PW1lZGlhJztcbiAgY29uc3QgbWV0aG9kID0gJ0dFVCc7XG4gIGNvbnN0IHRpbWVvdXQgPSBzZXJ2aWNlLm1heE9wZXJhdGlvblJldHJ5VGltZTtcbiAgY29uc3QgcmVxdWVzdEluZm8gPSBuZXcgUmVxdWVzdEluZm8oXG4gICAgdXJsLFxuICAgIG1ldGhvZCxcbiAgICAoXzogQ29ubmVjdGlvbjxJPiwgZGF0YTogSSkgPT4gZGF0YSxcbiAgICB0aW1lb3V0XG4gICk7XG4gIHJlcXVlc3RJbmZvLmVycm9ySGFuZGxlciA9IG9iamVjdEVycm9ySGFuZGxlcihsb2NhdGlvbik7XG4gIGlmIChtYXhEb3dubG9hZFNpemVCeXRlcyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgcmVxdWVzdEluZm8uaGVhZGVyc1snUmFuZ2UnXSA9IGBieXRlcz0wLSR7bWF4RG93bmxvYWRTaXplQnl0ZXN9YDtcbiAgICByZXF1ZXN0SW5mby5zdWNjZXNzQ29kZXMgPSBbMjAwIC8qIE9LICovLCAyMDYgLyogUGFydGlhbCBDb250ZW50ICovXTtcbiAgfVxuICByZXR1cm4gcmVxdWVzdEluZm87XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXREb3dubG9hZFVybChcbiAgc2VydmljZTogRmlyZWJhc2VTdG9yYWdlSW1wbCxcbiAgbG9jYXRpb246IExvY2F0aW9uLFxuICBtYXBwaW5nczogTWFwcGluZ3Ncbik6IFJlcXVlc3RJbmZvPHN0cmluZywgc3RyaW5nIHwgbnVsbD4ge1xuICBjb25zdCB1cmxQYXJ0ID0gbG9jYXRpb24uZnVsbFNlcnZlclVybCgpO1xuICBjb25zdCB1cmwgPSBtYWtlVXJsKHVybFBhcnQsIHNlcnZpY2UuaG9zdCwgc2VydmljZS5fcHJvdG9jb2wpO1xuICBjb25zdCBtZXRob2QgPSAnR0VUJztcbiAgY29uc3QgdGltZW91dCA9IHNlcnZpY2UubWF4T3BlcmF0aW9uUmV0cnlUaW1lO1xuICBjb25zdCByZXF1ZXN0SW5mbyA9IG5ldyBSZXF1ZXN0SW5mbyhcbiAgICB1cmwsXG4gICAgbWV0aG9kLFxuICAgIGRvd25sb2FkVXJsSGFuZGxlcihzZXJ2aWNlLCBtYXBwaW5ncyksXG4gICAgdGltZW91dFxuICApO1xuICByZXF1ZXN0SW5mby5lcnJvckhhbmRsZXIgPSBvYmplY3RFcnJvckhhbmRsZXIobG9jYXRpb24pO1xuICByZXR1cm4gcmVxdWVzdEluZm87XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1cGRhdGVNZXRhZGF0YShcbiAgc2VydmljZTogRmlyZWJhc2VTdG9yYWdlSW1wbCxcbiAgbG9jYXRpb246IExvY2F0aW9uLFxuICBtZXRhZGF0YTogUGFydGlhbDxNZXRhZGF0YT4sXG4gIG1hcHBpbmdzOiBNYXBwaW5nc1xuKTogUmVxdWVzdEluZm88c3RyaW5nLCBNZXRhZGF0YT4ge1xuICBjb25zdCB1cmxQYXJ0ID0gbG9jYXRpb24uZnVsbFNlcnZlclVybCgpO1xuICBjb25zdCB1cmwgPSBtYWtlVXJsKHVybFBhcnQsIHNlcnZpY2UuaG9zdCwgc2VydmljZS5fcHJvdG9jb2wpO1xuICBjb25zdCBtZXRob2QgPSAnUEFUQ0gnO1xuICBjb25zdCBib2R5ID0gdG9SZXNvdXJjZVN0cmluZyhtZXRhZGF0YSwgbWFwcGluZ3MpO1xuICBjb25zdCBoZWFkZXJzID0geyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb247IGNoYXJzZXQ9dXRmLTgnIH07XG4gIGNvbnN0IHRpbWVvdXQgPSBzZXJ2aWNlLm1heE9wZXJhdGlvblJldHJ5VGltZTtcbiAgY29uc3QgcmVxdWVzdEluZm8gPSBuZXcgUmVxdWVzdEluZm8oXG4gICAgdXJsLFxuICAgIG1ldGhvZCxcbiAgICBtZXRhZGF0YUhhbmRsZXIoc2VydmljZSwgbWFwcGluZ3MpLFxuICAgIHRpbWVvdXRcbiAgKTtcbiAgcmVxdWVzdEluZm8uaGVhZGVycyA9IGhlYWRlcnM7XG4gIHJlcXVlc3RJbmZvLmJvZHkgPSBib2R5O1xuICByZXF1ZXN0SW5mby5lcnJvckhhbmRsZXIgPSBvYmplY3RFcnJvckhhbmRsZXIobG9jYXRpb24pO1xuICByZXR1cm4gcmVxdWVzdEluZm87XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZWxldGVPYmplY3QoXG4gIHNlcnZpY2U6IEZpcmViYXNlU3RvcmFnZUltcGwsXG4gIGxvY2F0aW9uOiBMb2NhdGlvblxuKTogUmVxdWVzdEluZm88c3RyaW5nLCB2b2lkPiB7XG4gIGNvbnN0IHVybFBhcnQgPSBsb2NhdGlvbi5mdWxsU2VydmVyVXJsKCk7XG4gIGNvbnN0IHVybCA9IG1ha2VVcmwodXJsUGFydCwgc2VydmljZS5ob3N0LCBzZXJ2aWNlLl9wcm90b2NvbCk7XG4gIGNvbnN0IG1ldGhvZCA9ICdERUxFVEUnO1xuICBjb25zdCB0aW1lb3V0ID0gc2VydmljZS5tYXhPcGVyYXRpb25SZXRyeVRpbWU7XG5cbiAgZnVuY3Rpb24gaGFuZGxlcihfeGhyOiBDb25uZWN0aW9uPHN0cmluZz4sIF90ZXh0OiBzdHJpbmcpOiB2b2lkIHt9XG4gIGNvbnN0IHJlcXVlc3RJbmZvID0gbmV3IFJlcXVlc3RJbmZvKHVybCwgbWV0aG9kLCBoYW5kbGVyLCB0aW1lb3V0KTtcbiAgcmVxdWVzdEluZm8uc3VjY2Vzc0NvZGVzID0gWzIwMCwgMjA0XTtcbiAgcmVxdWVzdEluZm8uZXJyb3JIYW5kbGVyID0gb2JqZWN0RXJyb3JIYW5kbGVyKGxvY2F0aW9uKTtcbiAgcmV0dXJuIHJlcXVlc3RJbmZvO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZGV0ZXJtaW5lQ29udGVudFR5cGVfKFxuICBtZXRhZGF0YTogTWV0YWRhdGEgfCBudWxsLFxuICBibG9iOiBGYnNCbG9iIHwgbnVsbFxuKTogc3RyaW5nIHtcbiAgcmV0dXJuIChcbiAgICAobWV0YWRhdGEgJiYgbWV0YWRhdGFbJ2NvbnRlbnRUeXBlJ10pIHx8XG4gICAgKGJsb2IgJiYgYmxvYi50eXBlKCkpIHx8XG4gICAgJ2FwcGxpY2F0aW9uL29jdGV0LXN0cmVhbSdcbiAgKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG1ldGFkYXRhRm9yVXBsb2FkXyhcbiAgbG9jYXRpb246IExvY2F0aW9uLFxuICBibG9iOiBGYnNCbG9iLFxuICBtZXRhZGF0YT86IE1ldGFkYXRhIHwgbnVsbFxuKTogTWV0YWRhdGEge1xuICBjb25zdCBtZXRhZGF0YUNsb25lID0gT2JqZWN0LmFzc2lnbih7fSwgbWV0YWRhdGEpO1xuICBtZXRhZGF0YUNsb25lWydmdWxsUGF0aCddID0gbG9jYXRpb24ucGF0aDtcbiAgbWV0YWRhdGFDbG9uZVsnc2l6ZSddID0gYmxvYi5zaXplKCk7XG4gIGlmICghbWV0YWRhdGFDbG9uZVsnY29udGVudFR5cGUnXSkge1xuICAgIG1ldGFkYXRhQ2xvbmVbJ2NvbnRlbnRUeXBlJ10gPSBkZXRlcm1pbmVDb250ZW50VHlwZV8obnVsbCwgYmxvYik7XG4gIH1cbiAgcmV0dXJuIG1ldGFkYXRhQ2xvbmU7XG59XG5cbi8qKlxuICogUHJlcGFyZSBSZXF1ZXN0SW5mbyBmb3IgdXBsb2FkcyBhcyBDb250ZW50LVR5cGU6IG11bHRpcGFydC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG11bHRpcGFydFVwbG9hZChcbiAgc2VydmljZTogRmlyZWJhc2VTdG9yYWdlSW1wbCxcbiAgbG9jYXRpb246IExvY2F0aW9uLFxuICBtYXBwaW5nczogTWFwcGluZ3MsXG4gIGJsb2I6IEZic0Jsb2IsXG4gIG1ldGFkYXRhPzogTWV0YWRhdGEgfCBudWxsXG4pOiBSZXF1ZXN0SW5mbzxzdHJpbmcsIE1ldGFkYXRhPiB7XG4gIGNvbnN0IHVybFBhcnQgPSBsb2NhdGlvbi5idWNrZXRPbmx5U2VydmVyVXJsKCk7XG4gIGNvbnN0IGhlYWRlcnM6IHsgW3Byb3A6IHN0cmluZ106IHN0cmluZyB9ID0ge1xuICAgICdYLUdvb2ctVXBsb2FkLVByb3RvY29sJzogJ211bHRpcGFydCdcbiAgfTtcblxuICBmdW5jdGlvbiBnZW5Cb3VuZGFyeSgpOiBzdHJpbmcge1xuICAgIGxldCBzdHIgPSAnJztcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IDI7IGkrKykge1xuICAgICAgc3RyID0gc3RyICsgTWF0aC5yYW5kb20oKS50b1N0cmluZygpLnNsaWNlKDIpO1xuICAgIH1cbiAgICByZXR1cm4gc3RyO1xuICB9XG4gIGNvbnN0IGJvdW5kYXJ5ID0gZ2VuQm91bmRhcnkoKTtcbiAgaGVhZGVyc1snQ29udGVudC1UeXBlJ10gPSAnbXVsdGlwYXJ0L3JlbGF0ZWQ7IGJvdW5kYXJ5PScgKyBib3VuZGFyeTtcbiAgY29uc3QgbWV0YWRhdGFfID0gbWV0YWRhdGFGb3JVcGxvYWRfKGxvY2F0aW9uLCBibG9iLCBtZXRhZGF0YSk7XG4gIGNvbnN0IG1ldGFkYXRhU3RyaW5nID0gdG9SZXNvdXJjZVN0cmluZyhtZXRhZGF0YV8sIG1hcHBpbmdzKTtcbiAgY29uc3QgcHJlQmxvYlBhcnQgPVxuICAgICctLScgK1xuICAgIGJvdW5kYXJ5ICtcbiAgICAnXFxyXFxuJyArXG4gICAgJ0NvbnRlbnQtVHlwZTogYXBwbGljYXRpb24vanNvbjsgY2hhcnNldD11dGYtOFxcclxcblxcclxcbicgK1xuICAgIG1ldGFkYXRhU3RyaW5nICtcbiAgICAnXFxyXFxuLS0nICtcbiAgICBib3VuZGFyeSArXG4gICAgJ1xcclxcbicgK1xuICAgICdDb250ZW50LVR5cGU6ICcgK1xuICAgIG1ldGFkYXRhX1snY29udGVudFR5cGUnXSArXG4gICAgJ1xcclxcblxcclxcbic7XG4gIGNvbnN0IHBvc3RCbG9iUGFydCA9ICdcXHJcXG4tLScgKyBib3VuZGFyeSArICctLSc7XG4gIGNvbnN0IGJvZHkgPSBGYnNCbG9iLmdldEJsb2IocHJlQmxvYlBhcnQsIGJsb2IsIHBvc3RCbG9iUGFydCk7XG4gIGlmIChib2R5ID09PSBudWxsKSB7XG4gICAgdGhyb3cgY2Fubm90U2xpY2VCbG9iKCk7XG4gIH1cbiAgY29uc3QgdXJsUGFyYW1zOiBVcmxQYXJhbXMgPSB7IG5hbWU6IG1ldGFkYXRhX1snZnVsbFBhdGgnXSEgfTtcbiAgY29uc3QgdXJsID0gbWFrZVVybCh1cmxQYXJ0LCBzZXJ2aWNlLmhvc3QsIHNlcnZpY2UuX3Byb3RvY29sKTtcbiAgY29uc3QgbWV0aG9kID0gJ1BPU1QnO1xuICBjb25zdCB0aW1lb3V0ID0gc2VydmljZS5tYXhVcGxvYWRSZXRyeVRpbWU7XG4gIGNvbnN0IHJlcXVlc3RJbmZvID0gbmV3IFJlcXVlc3RJbmZvKFxuICAgIHVybCxcbiAgICBtZXRob2QsXG4gICAgbWV0YWRhdGFIYW5kbGVyKHNlcnZpY2UsIG1hcHBpbmdzKSxcbiAgICB0aW1lb3V0XG4gICk7XG4gIHJlcXVlc3RJbmZvLnVybFBhcmFtcyA9IHVybFBhcmFtcztcbiAgcmVxdWVzdEluZm8uaGVhZGVycyA9IGhlYWRlcnM7XG4gIHJlcXVlc3RJbmZvLmJvZHkgPSBib2R5LnVwbG9hZERhdGEoKTtcbiAgcmVxdWVzdEluZm8uZXJyb3JIYW5kbGVyID0gc2hhcmVkRXJyb3JIYW5kbGVyKGxvY2F0aW9uKTtcbiAgcmV0dXJuIHJlcXVlc3RJbmZvO1xufVxuXG4vKipcbiAqIEBwYXJhbSBjdXJyZW50IFRoZSBudW1iZXIgb2YgYnl0ZXMgdGhhdCBoYXZlIGJlZW4gdXBsb2FkZWQgc28gZmFyLlxuICogQHBhcmFtIHRvdGFsIFRoZSB0b3RhbCBudW1iZXIgb2YgYnl0ZXMgaW4gdGhlIHVwbG9hZC5cbiAqIEBwYXJhbSBvcHRfZmluYWxpemVkIFRydWUgaWYgdGhlIHNlcnZlciBoYXMgZmluaXNoZWQgdGhlIHVwbG9hZC5cbiAqIEBwYXJhbSBvcHRfbWV0YWRhdGEgVGhlIHVwbG9hZCBtZXRhZGF0YSwgc2hvdWxkXG4gKiAgICAgb25seSBiZSBwYXNzZWQgaWYgb3B0X2ZpbmFsaXplZCBpcyB0cnVlLlxuICovXG5leHBvcnQgY2xhc3MgUmVzdW1hYmxlVXBsb2FkU3RhdHVzIHtcbiAgZmluYWxpemVkOiBib29sZWFuO1xuICBtZXRhZGF0YTogTWV0YWRhdGEgfCBudWxsO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHB1YmxpYyBjdXJyZW50OiBudW1iZXIsXG4gICAgcHVibGljIHRvdGFsOiBudW1iZXIsXG4gICAgZmluYWxpemVkPzogYm9vbGVhbixcbiAgICBtZXRhZGF0YT86IE1ldGFkYXRhIHwgbnVsbFxuICApIHtcbiAgICB0aGlzLmZpbmFsaXplZCA9ICEhZmluYWxpemVkO1xuICAgIHRoaXMubWV0YWRhdGEgPSBtZXRhZGF0YSB8fCBudWxsO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjaGVja1Jlc3VtZUhlYWRlcl8oXG4gIHhocjogQ29ubmVjdGlvbjxzdHJpbmc+LFxuICBhbGxvd2VkPzogc3RyaW5nW11cbik6IHN0cmluZyB7XG4gIGxldCBzdGF0dXM6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICB0cnkge1xuICAgIHN0YXR1cyA9IHhoci5nZXRSZXNwb25zZUhlYWRlcignWC1Hb29nLVVwbG9hZC1TdGF0dXMnKTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIGhhbmRsZXJDaGVjayhmYWxzZSk7XG4gIH1cbiAgY29uc3QgYWxsb3dlZFN0YXR1cyA9IGFsbG93ZWQgfHwgWydhY3RpdmUnXTtcbiAgaGFuZGxlckNoZWNrKCEhc3RhdHVzICYmIGFsbG93ZWRTdGF0dXMuaW5kZXhPZihzdGF0dXMpICE9PSAtMSk7XG4gIHJldHVybiBzdGF0dXMgYXMgc3RyaW5nO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlUmVzdW1hYmxlVXBsb2FkKFxuICBzZXJ2aWNlOiBGaXJlYmFzZVN0b3JhZ2VJbXBsLFxuICBsb2NhdGlvbjogTG9jYXRpb24sXG4gIG1hcHBpbmdzOiBNYXBwaW5ncyxcbiAgYmxvYjogRmJzQmxvYixcbiAgbWV0YWRhdGE/OiBNZXRhZGF0YSB8IG51bGxcbik6IFJlcXVlc3RJbmZvPHN0cmluZywgc3RyaW5nPiB7XG4gIGNvbnN0IHVybFBhcnQgPSBsb2NhdGlvbi5idWNrZXRPbmx5U2VydmVyVXJsKCk7XG4gIGNvbnN0IG1ldGFkYXRhRm9yVXBsb2FkID0gbWV0YWRhdGFGb3JVcGxvYWRfKGxvY2F0aW9uLCBibG9iLCBtZXRhZGF0YSk7XG4gIGNvbnN0IHVybFBhcmFtczogVXJsUGFyYW1zID0geyBuYW1lOiBtZXRhZGF0YUZvclVwbG9hZFsnZnVsbFBhdGgnXSEgfTtcbiAgY29uc3QgdXJsID0gbWFrZVVybCh1cmxQYXJ0LCBzZXJ2aWNlLmhvc3QsIHNlcnZpY2UuX3Byb3RvY29sKTtcbiAgY29uc3QgbWV0aG9kID0gJ1BPU1QnO1xuICBjb25zdCBoZWFkZXJzID0ge1xuICAgICdYLUdvb2ctVXBsb2FkLVByb3RvY29sJzogJ3Jlc3VtYWJsZScsXG4gICAgJ1gtR29vZy1VcGxvYWQtQ29tbWFuZCc6ICdzdGFydCcsXG4gICAgJ1gtR29vZy1VcGxvYWQtSGVhZGVyLUNvbnRlbnQtTGVuZ3RoJzogYCR7YmxvYi5zaXplKCl9YCxcbiAgICAnWC1Hb29nLVVwbG9hZC1IZWFkZXItQ29udGVudC1UeXBlJzogbWV0YWRhdGFGb3JVcGxvYWRbJ2NvbnRlbnRUeXBlJ10hLFxuICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbjsgY2hhcnNldD11dGYtOCdcbiAgfTtcbiAgY29uc3QgYm9keSA9IHRvUmVzb3VyY2VTdHJpbmcobWV0YWRhdGFGb3JVcGxvYWQsIG1hcHBpbmdzKTtcbiAgY29uc3QgdGltZW91dCA9IHNlcnZpY2UubWF4VXBsb2FkUmV0cnlUaW1lO1xuXG4gIGZ1bmN0aW9uIGhhbmRsZXIoeGhyOiBDb25uZWN0aW9uPHN0cmluZz4pOiBzdHJpbmcge1xuICAgIGNoZWNrUmVzdW1lSGVhZGVyXyh4aHIpO1xuICAgIGxldCB1cmw7XG4gICAgdHJ5IHtcbiAgICAgIHVybCA9IHhoci5nZXRSZXNwb25zZUhlYWRlcignWC1Hb29nLVVwbG9hZC1VUkwnKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBoYW5kbGVyQ2hlY2soZmFsc2UpO1xuICAgIH1cbiAgICBoYW5kbGVyQ2hlY2soaXNTdHJpbmcodXJsKSk7XG4gICAgcmV0dXJuIHVybCBhcyBzdHJpbmc7XG4gIH1cbiAgY29uc3QgcmVxdWVzdEluZm8gPSBuZXcgUmVxdWVzdEluZm8odXJsLCBtZXRob2QsIGhhbmRsZXIsIHRpbWVvdXQpO1xuICByZXF1ZXN0SW5mby51cmxQYXJhbXMgPSB1cmxQYXJhbXM7XG4gIHJlcXVlc3RJbmZvLmhlYWRlcnMgPSBoZWFkZXJzO1xuICByZXF1ZXN0SW5mby5ib2R5ID0gYm9keTtcbiAgcmVxdWVzdEluZm8uZXJyb3JIYW5kbGVyID0gc2hhcmVkRXJyb3JIYW5kbGVyKGxvY2F0aW9uKTtcbiAgcmV0dXJuIHJlcXVlc3RJbmZvO1xufVxuXG4vKipcbiAqIEBwYXJhbSB1cmwgRnJvbSBhIGNhbGwgdG8gZmJzLnJlcXVlc3RzLmNyZWF0ZVJlc3VtYWJsZVVwbG9hZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFJlc3VtYWJsZVVwbG9hZFN0YXR1cyhcbiAgc2VydmljZTogRmlyZWJhc2VTdG9yYWdlSW1wbCxcbiAgbG9jYXRpb246IExvY2F0aW9uLFxuICB1cmw6IHN0cmluZyxcbiAgYmxvYjogRmJzQmxvYlxuKTogUmVxdWVzdEluZm88c3RyaW5nLCBSZXN1bWFibGVVcGxvYWRTdGF0dXM+IHtcbiAgY29uc3QgaGVhZGVycyA9IHsgJ1gtR29vZy1VcGxvYWQtQ29tbWFuZCc6ICdxdWVyeScgfTtcblxuICBmdW5jdGlvbiBoYW5kbGVyKHhocjogQ29ubmVjdGlvbjxzdHJpbmc+KTogUmVzdW1hYmxlVXBsb2FkU3RhdHVzIHtcbiAgICBjb25zdCBzdGF0dXMgPSBjaGVja1Jlc3VtZUhlYWRlcl8oeGhyLCBbJ2FjdGl2ZScsICdmaW5hbCddKTtcbiAgICBsZXQgc2l6ZVN0cmluZzogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gICAgdHJ5IHtcbiAgICAgIHNpemVTdHJpbmcgPSB4aHIuZ2V0UmVzcG9uc2VIZWFkZXIoJ1gtR29vZy1VcGxvYWQtU2l6ZS1SZWNlaXZlZCcpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGhhbmRsZXJDaGVjayhmYWxzZSk7XG4gICAgfVxuXG4gICAgaWYgKCFzaXplU3RyaW5nKSB7XG4gICAgICAvLyBudWxsIG9yIGVtcHR5IHN0cmluZ1xuICAgICAgaGFuZGxlckNoZWNrKGZhbHNlKTtcbiAgICB9XG5cbiAgICBjb25zdCBzaXplID0gTnVtYmVyKHNpemVTdHJpbmcpO1xuICAgIGhhbmRsZXJDaGVjayghaXNOYU4oc2l6ZSkpO1xuICAgIHJldHVybiBuZXcgUmVzdW1hYmxlVXBsb2FkU3RhdHVzKHNpemUsIGJsb2Iuc2l6ZSgpLCBzdGF0dXMgPT09ICdmaW5hbCcpO1xuICB9XG4gIGNvbnN0IG1ldGhvZCA9ICdQT1NUJztcbiAgY29uc3QgdGltZW91dCA9IHNlcnZpY2UubWF4VXBsb2FkUmV0cnlUaW1lO1xuICBjb25zdCByZXF1ZXN0SW5mbyA9IG5ldyBSZXF1ZXN0SW5mbyh1cmwsIG1ldGhvZCwgaGFuZGxlciwgdGltZW91dCk7XG4gIHJlcXVlc3RJbmZvLmhlYWRlcnMgPSBoZWFkZXJzO1xuICByZXF1ZXN0SW5mby5lcnJvckhhbmRsZXIgPSBzaGFyZWRFcnJvckhhbmRsZXIobG9jYXRpb24pO1xuICByZXR1cm4gcmVxdWVzdEluZm87XG59XG5cbi8qKlxuICogQW55IHVwbG9hZHMgdmlhIHRoZSByZXN1bWFibGUgdXBsb2FkIEFQSSBtdXN0IHRyYW5zZmVyIGEgbnVtYmVyIG9mIGJ5dGVzXG4gKiB0aGF0IGlzIGEgbXVsdGlwbGUgb2YgdGhpcyBudW1iZXIuXG4gKi9cbmV4cG9ydCBjb25zdCBSRVNVTUFCTEVfVVBMT0FEX0NIVU5LX1NJWkU6IG51bWJlciA9IDI1NiAqIDEwMjQ7XG5cbi8qKlxuICogQHBhcmFtIHVybCBGcm9tIGEgY2FsbCB0byBmYnMucmVxdWVzdHMuY3JlYXRlUmVzdW1hYmxlVXBsb2FkLlxuICogQHBhcmFtIGNodW5rU2l6ZSBOdW1iZXIgb2YgYnl0ZXMgdG8gdXBsb2FkLlxuICogQHBhcmFtIHN0YXR1cyBUaGUgcHJldmlvdXMgc3RhdHVzLlxuICogICAgIElmIG5vdCBwYXNzZWQgb3IgbnVsbCwgd2Ugc3RhcnQgZnJvbSB0aGUgYmVnaW5uaW5nLlxuICogQHRocm93cyBmYnMuRXJyb3IgSWYgdGhlIHVwbG9hZCBpcyBhbHJlYWR5IGNvbXBsZXRlLCB0aGUgcGFzc2VkIGluIHN0YXR1c1xuICogICAgIGhhcyBhIGZpbmFsIHNpemUgaW5jb25zaXN0ZW50IHdpdGggdGhlIGJsb2IsIG9yIHRoZSBibG9iIGNhbm5vdCBiZSBzbGljZWRcbiAqICAgICBmb3IgdXBsb2FkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gY29udGludWVSZXN1bWFibGVVcGxvYWQoXG4gIGxvY2F0aW9uOiBMb2NhdGlvbixcbiAgc2VydmljZTogRmlyZWJhc2VTdG9yYWdlSW1wbCxcbiAgdXJsOiBzdHJpbmcsXG4gIGJsb2I6IEZic0Jsb2IsXG4gIGNodW5rU2l6ZTogbnVtYmVyLFxuICBtYXBwaW5nczogTWFwcGluZ3MsXG4gIHN0YXR1cz86IFJlc3VtYWJsZVVwbG9hZFN0YXR1cyB8IG51bGwsXG4gIHByb2dyZXNzQ2FsbGJhY2s/OiAoKHAxOiBudW1iZXIsIHAyOiBudW1iZXIpID0+IHZvaWQpIHwgbnVsbFxuKTogUmVxdWVzdEluZm88c3RyaW5nLCBSZXN1bWFibGVVcGxvYWRTdGF0dXM+IHtcbiAgLy8gVE9ETyhhbmR5c290byk6IHN0YW5kYXJkaXplIG9uIGludGVybmFsIGFzc2VydHNcbiAgLy8gYXNzZXJ0KCEob3B0X3N0YXR1cyAmJiBvcHRfc3RhdHVzLmZpbmFsaXplZCkpO1xuICBjb25zdCBzdGF0dXNfID0gbmV3IFJlc3VtYWJsZVVwbG9hZFN0YXR1cygwLCAwKTtcbiAgaWYgKHN0YXR1cykge1xuICAgIHN0YXR1c18uY3VycmVudCA9IHN0YXR1cy5jdXJyZW50O1xuICAgIHN0YXR1c18udG90YWwgPSBzdGF0dXMudG90YWw7XG4gIH0gZWxzZSB7XG4gICAgc3RhdHVzXy5jdXJyZW50ID0gMDtcbiAgICBzdGF0dXNfLnRvdGFsID0gYmxvYi5zaXplKCk7XG4gIH1cbiAgaWYgKGJsb2Iuc2l6ZSgpICE9PSBzdGF0dXNfLnRvdGFsKSB7XG4gICAgdGhyb3cgc2VydmVyRmlsZVdyb25nU2l6ZSgpO1xuICB9XG4gIGNvbnN0IGJ5dGVzTGVmdCA9IHN0YXR1c18udG90YWwgLSBzdGF0dXNfLmN1cnJlbnQ7XG4gIGxldCBieXRlc1RvVXBsb2FkID0gYnl0ZXNMZWZ0O1xuICBpZiAoY2h1bmtTaXplID4gMCkge1xuICAgIGJ5dGVzVG9VcGxvYWQgPSBNYXRoLm1pbihieXRlc1RvVXBsb2FkLCBjaHVua1NpemUpO1xuICB9XG4gIGNvbnN0IHN0YXJ0Qnl0ZSA9IHN0YXR1c18uY3VycmVudDtcbiAgY29uc3QgZW5kQnl0ZSA9IHN0YXJ0Qnl0ZSArIGJ5dGVzVG9VcGxvYWQ7XG4gIGxldCB1cGxvYWRDb21tYW5kID0gJyc7XG4gIGlmIChieXRlc1RvVXBsb2FkID09PSAwKSB7XG4gICAgdXBsb2FkQ29tbWFuZCA9ICdmaW5hbGl6ZSc7XG4gIH0gZWxzZSBpZiAoYnl0ZXNMZWZ0ID09PSBieXRlc1RvVXBsb2FkKSB7XG4gICAgdXBsb2FkQ29tbWFuZCA9ICd1cGxvYWQsIGZpbmFsaXplJztcbiAgfSBlbHNlIHtcbiAgICB1cGxvYWRDb21tYW5kID0gJ3VwbG9hZCc7XG4gIH1cbiAgY29uc3QgaGVhZGVycyA9IHtcbiAgICAnWC1Hb29nLVVwbG9hZC1Db21tYW5kJzogdXBsb2FkQ29tbWFuZCxcbiAgICAnWC1Hb29nLVVwbG9hZC1PZmZzZXQnOiBgJHtzdGF0dXNfLmN1cnJlbnR9YFxuICB9O1xuICBjb25zdCBib2R5ID0gYmxvYi5zbGljZShzdGFydEJ5dGUsIGVuZEJ5dGUpO1xuICBpZiAoYm9keSA9PT0gbnVsbCkge1xuICAgIHRocm93IGNhbm5vdFNsaWNlQmxvYigpO1xuICB9XG5cbiAgZnVuY3Rpb24gaGFuZGxlcihcbiAgICB4aHI6IENvbm5lY3Rpb248c3RyaW5nPixcbiAgICB0ZXh0OiBzdHJpbmdcbiAgKTogUmVzdW1hYmxlVXBsb2FkU3RhdHVzIHtcbiAgICAvLyBUT0RPKGFuZHlzb3RvKTogVmVyaWZ5IHRoZSBNRDUgb2YgZWFjaCB1cGxvYWRlZCByYW5nZTpcbiAgICAvLyB0aGUgJ3gtcmFuZ2UtbWQ1JyBoZWFkZXIgY29tZXMgYmFjayB3aXRoIHN0YXR1cyBjb2RlIDMwOCByZXNwb25zZXMuXG4gICAgLy8gV2UnbGwgb25seSBiZSBhYmxlIHRvIGJhaWwgb3V0IHRob3VnaCwgYmVjYXVzZSB5b3UgY2FuJ3QgcmUtdXBsb2FkIGFcbiAgICAvLyByYW5nZSB0aGF0IHlvdSBwcmV2aW91c2x5IHVwbG9hZGVkLlxuICAgIGNvbnN0IHVwbG9hZFN0YXR1cyA9IGNoZWNrUmVzdW1lSGVhZGVyXyh4aHIsIFsnYWN0aXZlJywgJ2ZpbmFsJ10pO1xuICAgIGNvbnN0IG5ld0N1cnJlbnQgPSBzdGF0dXNfLmN1cnJlbnQgKyBieXRlc1RvVXBsb2FkO1xuICAgIGNvbnN0IHNpemUgPSBibG9iLnNpemUoKTtcbiAgICBsZXQgbWV0YWRhdGE7XG4gICAgaWYgKHVwbG9hZFN0YXR1cyA9PT0gJ2ZpbmFsJykge1xuICAgICAgbWV0YWRhdGEgPSBtZXRhZGF0YUhhbmRsZXIoc2VydmljZSwgbWFwcGluZ3MpKHhociwgdGV4dCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG1ldGFkYXRhID0gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBSZXN1bWFibGVVcGxvYWRTdGF0dXMoXG4gICAgICBuZXdDdXJyZW50LFxuICAgICAgc2l6ZSxcbiAgICAgIHVwbG9hZFN0YXR1cyA9PT0gJ2ZpbmFsJyxcbiAgICAgIG1ldGFkYXRhXG4gICAgKTtcbiAgfVxuICBjb25zdCBtZXRob2QgPSAnUE9TVCc7XG4gIGNvbnN0IHRpbWVvdXQgPSBzZXJ2aWNlLm1heFVwbG9hZFJldHJ5VGltZTtcbiAgY29uc3QgcmVxdWVzdEluZm8gPSBuZXcgUmVxdWVzdEluZm8odXJsLCBtZXRob2QsIGhhbmRsZXIsIHRpbWVvdXQpO1xuICByZXF1ZXN0SW5mby5oZWFkZXJzID0gaGVhZGVycztcbiAgcmVxdWVzdEluZm8uYm9keSA9IGJvZHkudXBsb2FkRGF0YSgpO1xuICByZXF1ZXN0SW5mby5wcm9ncmVzc0NhbGxiYWNrID0gcHJvZ3Jlc3NDYWxsYmFjayB8fCBudWxsO1xuICByZXF1ZXN0SW5mby5lcnJvckhhbmRsZXIgPSBzaGFyZWRFcnJvckhhbmRsZXIobG9jYXRpb24pO1xuICByZXR1cm4gcmVxdWVzdEluZm87XG59XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAxNyBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG4vKipcbiAqIEBmaWxlb3ZlcnZpZXcgRW51bWVyYXRpb25zIHVzZWQgZm9yIHVwbG9hZCB0YXNrcy5cbiAqL1xuXG4vKipcbiAqIEFuIGV2ZW50IHRoYXQgaXMgdHJpZ2dlcmVkIG9uIGEgdGFzay5cbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgdHlwZSBUYXNrRXZlbnQgPSBzdHJpbmc7XG5cbi8qKlxuICogQW4gZXZlbnQgdGhhdCBpcyB0cmlnZ2VyZWQgb24gYSB0YXNrLlxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCBjb25zdCBUYXNrRXZlbnQgPSB7XG4gIC8qKlxuICAgKiBGb3IgdGhpcyBldmVudCxcbiAgICogPHVsPlxuICAgKiAgIDxsaT5UaGUgYG5leHRgIGZ1bmN0aW9uIGlzIHRyaWdnZXJlZCBvbiBwcm9ncmVzcyB1cGRhdGVzIGFuZCB3aGVuIHRoZVxuICAgKiAgICAgICB0YXNrIGlzIHBhdXNlZC9yZXN1bWVkIHdpdGggYW4gYFVwbG9hZFRhc2tTbmFwc2hvdGAgYXMgdGhlIGZpcnN0XG4gICAqICAgICAgIGFyZ3VtZW50LjwvbGk+XG4gICAqICAgPGxpPlRoZSBgZXJyb3JgIGZ1bmN0aW9uIGlzIHRyaWdnZXJlZCBpZiB0aGUgdXBsb2FkIGlzIGNhbmNlbGVkIG9yIGZhaWxzXG4gICAqICAgICAgIGZvciBhbm90aGVyIHJlYXNvbi48L2xpPlxuICAgKiAgIDxsaT5UaGUgYGNvbXBsZXRlYCBmdW5jdGlvbiBpcyB0cmlnZ2VyZWQgaWYgdGhlIHVwbG9hZCBjb21wbGV0ZXNcbiAgICogICAgICAgc3VjY2Vzc2Z1bGx5LjwvbGk+XG4gICAqIDwvdWw+XG4gICAqL1xuICBTVEFURV9DSEFOR0VEOiAnc3RhdGVfY2hhbmdlZCdcbn07XG5cbi8qKlxuICogSW50ZXJuYWwgZW51bSBmb3IgdGFzayBzdGF0ZS5cbiAqL1xuZXhwb3J0IGNvbnN0IGVudW0gSW50ZXJuYWxUYXNrU3RhdGUge1xuICBSVU5OSU5HID0gJ3J1bm5pbmcnLFxuICBQQVVTSU5HID0gJ3BhdXNpbmcnLFxuICBQQVVTRUQgPSAncGF1c2VkJyxcbiAgU1VDQ0VTUyA9ICdzdWNjZXNzJyxcbiAgQ0FOQ0VMSU5HID0gJ2NhbmNlbGluZycsXG4gIENBTkNFTEVEID0gJ2NhbmNlbGVkJyxcbiAgRVJST1IgPSAnZXJyb3InXG59XG5cbi8qKlxuICogUmVwcmVzZW50cyB0aGUgY3VycmVudCBzdGF0ZSBvZiBhIHJ1bm5pbmcgdXBsb2FkLlxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCB0eXBlIFRhc2tTdGF0ZSA9ICh0eXBlb2YgVGFza1N0YXRlKVtrZXlvZiB0eXBlb2YgVGFza1N0YXRlXTtcblxuLy8gdHlwZSBrZXlzID0ga2V5b2YgVGFza1N0YXRlXG4vKipcbiAqIFJlcHJlc2VudHMgdGhlIGN1cnJlbnQgc3RhdGUgb2YgYSBydW5uaW5nIHVwbG9hZC5cbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgY29uc3QgVGFza1N0YXRlID0ge1xuICAvKiogVGhlIHRhc2sgaXMgY3VycmVudGx5IHRyYW5zZmVycmluZyBkYXRhLiAqL1xuICBSVU5OSU5HOiAncnVubmluZycsXG5cbiAgLyoqIFRoZSB0YXNrIHdhcyBwYXVzZWQgYnkgdGhlIHVzZXIuICovXG4gIFBBVVNFRDogJ3BhdXNlZCcsXG5cbiAgLyoqIFRoZSB0YXNrIGNvbXBsZXRlZCBzdWNjZXNzZnVsbHkuICovXG4gIFNVQ0NFU1M6ICdzdWNjZXNzJyxcblxuICAvKiogVGhlIHRhc2sgd2FzIGNhbmNlbGVkLiAqL1xuICBDQU5DRUxFRDogJ2NhbmNlbGVkJyxcblxuICAvKiogVGhlIHRhc2sgZmFpbGVkIHdpdGggYW4gZXJyb3IuICovXG4gIEVSUk9SOiAnZXJyb3InXG59IGFzIGNvbnN0O1xuXG5leHBvcnQgZnVuY3Rpb24gdGFza1N0YXRlRnJvbUludGVybmFsVGFza1N0YXRlKFxuICBzdGF0ZTogSW50ZXJuYWxUYXNrU3RhdGVcbik6IFRhc2tTdGF0ZSB7XG4gIHN3aXRjaCAoc3RhdGUpIHtcbiAgICBjYXNlIEludGVybmFsVGFza1N0YXRlLlJVTk5JTkc6XG4gICAgY2FzZSBJbnRlcm5hbFRhc2tTdGF0ZS5QQVVTSU5HOlxuICAgIGNhc2UgSW50ZXJuYWxUYXNrU3RhdGUuQ0FOQ0VMSU5HOlxuICAgICAgcmV0dXJuIFRhc2tTdGF0ZS5SVU5OSU5HO1xuICAgIGNhc2UgSW50ZXJuYWxUYXNrU3RhdGUuUEFVU0VEOlxuICAgICAgcmV0dXJuIFRhc2tTdGF0ZS5QQVVTRUQ7XG4gICAgY2FzZSBJbnRlcm5hbFRhc2tTdGF0ZS5TVUNDRVNTOlxuICAgICAgcmV0dXJuIFRhc2tTdGF0ZS5TVUNDRVNTO1xuICAgIGNhc2UgSW50ZXJuYWxUYXNrU3RhdGUuQ0FOQ0VMRUQ6XG4gICAgICByZXR1cm4gVGFza1N0YXRlLkNBTkNFTEVEO1xuICAgIGNhc2UgSW50ZXJuYWxUYXNrU3RhdGUuRVJST1I6XG4gICAgICByZXR1cm4gVGFza1N0YXRlLkVSUk9SO1xuICAgIGRlZmF1bHQ6XG4gICAgICAvLyBUT0RPKGFuZHlzb3RvKTogYXNzZXJ0KGZhbHNlKTtcbiAgICAgIHJldHVybiBUYXNrU3RhdGUuRVJST1I7XG4gIH1cbn1cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDE3IEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5pbXBvcnQgeyBpc0Z1bmN0aW9uIH0gZnJvbSAnLi90eXBlJztcbmltcG9ydCB7IFN0b3JhZ2VFcnJvciB9IGZyb20gJy4vZXJyb3InO1xuXG4vKipcbiAqIEZ1bmN0aW9uIHRoYXQgaXMgY2FsbGVkIG9uY2UgZm9yIGVhY2ggdmFsdWUgaW4gYSBzdHJlYW0gb2YgdmFsdWVzLlxuICovXG5leHBvcnQgdHlwZSBOZXh0Rm48VD4gPSAodmFsdWU6IFQpID0+IHZvaWQ7XG5cbi8qKlxuICogQSBmdW5jdGlvbiB0aGF0IGlzIGNhbGxlZCB3aXRoIGEgYFN0b3JhZ2VFcnJvcmBcbiAqIGlmIHRoZSBldmVudCBzdHJlYW0gZW5kcyBkdWUgdG8gYW4gZXJyb3IuXG4gKi9cbmV4cG9ydCB0eXBlIEVycm9yRm4gPSAoZXJyb3I6IFN0b3JhZ2VFcnJvcikgPT4gdm9pZDtcblxuLyoqXG4gKiBBIGZ1bmN0aW9uIHRoYXQgaXMgY2FsbGVkIGlmIHRoZSBldmVudCBzdHJlYW0gZW5kcyBub3JtYWxseS5cbiAqL1xuZXhwb3J0IHR5cGUgQ29tcGxldGVGbiA9ICgpID0+IHZvaWQ7XG5cbi8qKlxuICogVW5zdWJzY3JpYmVzIGZyb20gYSBzdHJlYW0uXG4gKi9cbmV4cG9ydCB0eXBlIFVuc3Vic2NyaWJlID0gKCkgPT4gdm9pZDtcblxuLyoqXG4gKiBBbiBvYnNlcnZlciBpZGVudGljYWwgdG8gdGhlIGBPYnNlcnZlcmAgZGVmaW5lZCBpbiBwYWNrYWdlcy91dGlsIGV4Y2VwdCB0aGVcbiAqIGVycm9yIHBhc3NlZCBpbnRvIHRoZSBFcnJvckZuIGlzIHNwZWNpZmljYWxseSBhIGBTdG9yYWdlRXJyb3JgLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFN0b3JhZ2VPYnNlcnZlcjxUPiB7XG4gIC8qKlxuICAgKiBGdW5jdGlvbiB0aGF0IGlzIGNhbGxlZCBvbmNlIGZvciBlYWNoIHZhbHVlIGluIHRoZSBldmVudCBzdHJlYW0uXG4gICAqL1xuICBuZXh0PzogTmV4dEZuPFQ+O1xuICAvKipcbiAgICogQSBmdW5jdGlvbiB0aGF0IGlzIGNhbGxlZCB3aXRoIGEgYFN0b3JhZ2VFcnJvcmBcbiAgICogaWYgdGhlIGV2ZW50IHN0cmVhbSBlbmRzIGR1ZSB0byBhbiBlcnJvci5cbiAgICovXG4gIGVycm9yPzogRXJyb3JGbjtcbiAgLyoqXG4gICAqIEEgZnVuY3Rpb24gdGhhdCBpcyBjYWxsZWQgaWYgdGhlIGV2ZW50IHN0cmVhbSBlbmRzIG5vcm1hbGx5LlxuICAgKi9cbiAgY29tcGxldGU/OiBDb21wbGV0ZUZuO1xufVxuXG4vKipcbiAqIFN1YnNjcmliZXMgdG8gYW4gZXZlbnQgc3RyZWFtLlxuICovXG5leHBvcnQgdHlwZSBTdWJzY3JpYmU8VD4gPSAoXG4gIG5leHQ/OiBOZXh0Rm48VD4gfCBTdG9yYWdlT2JzZXJ2ZXI8VD4sXG4gIGVycm9yPzogRXJyb3JGbixcbiAgY29tcGxldGU/OiBDb21wbGV0ZUZuXG4pID0+IFVuc3Vic2NyaWJlO1xuXG5leHBvcnQgY2xhc3MgT2JzZXJ2ZXI8VD4gaW1wbGVtZW50cyBTdG9yYWdlT2JzZXJ2ZXI8VD4ge1xuICBuZXh0PzogTmV4dEZuPFQ+O1xuICBlcnJvcj86IEVycm9yRm47XG4gIGNvbXBsZXRlPzogQ29tcGxldGVGbjtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBuZXh0T3JPYnNlcnZlcj86IE5leHRGbjxUPiB8IFN0b3JhZ2VPYnNlcnZlcjxUPixcbiAgICBlcnJvcj86IEVycm9yRm4sXG4gICAgY29tcGxldGU/OiBDb21wbGV0ZUZuXG4gICkge1xuICAgIGNvbnN0IGFzRnVuY3Rpb25zID1cbiAgICAgIGlzRnVuY3Rpb24obmV4dE9yT2JzZXJ2ZXIpIHx8IGVycm9yICE9IG51bGwgfHwgY29tcGxldGUgIT0gbnVsbDtcbiAgICBpZiAoYXNGdW5jdGlvbnMpIHtcbiAgICAgIHRoaXMubmV4dCA9IG5leHRPck9ic2VydmVyIGFzIE5leHRGbjxUPjtcbiAgICAgIHRoaXMuZXJyb3IgPSBlcnJvciA/PyB1bmRlZmluZWQ7XG4gICAgICB0aGlzLmNvbXBsZXRlID0gY29tcGxldGUgPz8gdW5kZWZpbmVkO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBvYnNlcnZlciA9IG5leHRPck9ic2VydmVyIGFzIHtcbiAgICAgICAgbmV4dD86IE5leHRGbjxUPjtcbiAgICAgICAgZXJyb3I/OiBFcnJvckZuO1xuICAgICAgICBjb21wbGV0ZT86IENvbXBsZXRlRm47XG4gICAgICB9O1xuICAgICAgdGhpcy5uZXh0ID0gb2JzZXJ2ZXIubmV4dDtcbiAgICAgIHRoaXMuZXJyb3IgPSBvYnNlcnZlci5lcnJvcjtcbiAgICAgIHRoaXMuY29tcGxldGUgPSBvYnNlcnZlci5jb21wbGV0ZTtcbiAgICB9XG4gIH1cbn1cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDE3IEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbi8qKlxuICogUmV0dXJucyBhIGZ1bmN0aW9uIHRoYXQgaW52b2tlcyBmIHdpdGggaXRzIGFyZ3VtZW50cyBhc3luY2hyb25vdXNseSBhcyBhXG4gKiBtaWNyb3Rhc2ssIGkuZS4gYXMgc29vbiBhcyBwb3NzaWJsZSBhZnRlciB0aGUgY3VycmVudCBzY3JpcHQgcmV0dXJucyBiYWNrXG4gKiBpbnRvIGJyb3dzZXIgY29kZS5cbiAqL1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHlwZXNcbmV4cG9ydCBmdW5jdGlvbiBhc3luYyhmOiBGdW5jdGlvbik6IEZ1bmN0aW9uIHtcbiAgcmV0dXJuICguLi5hcmdzVG9Gb3J3YXJkOiB1bmtub3duW10pID0+IHtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWZsb2F0aW5nLXByb21pc2VzXG4gICAgUHJvbWlzZS5yZXNvbHZlKCkudGhlbigoKSA9PiBmKC4uLmFyZ3NUb0ZvcndhcmQpKTtcbiAgfTtcbn1cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDE3IEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmltcG9ydCB7IGlzQ2xvdWRXb3Jrc3RhdGlvbiB9IGZyb20gJ0BmaXJlYmFzZS91dGlsJztcbmltcG9ydCB7XG4gIENvbm5lY3Rpb24sXG4gIENvbm5lY3Rpb25UeXBlLFxuICBFcnJvckNvZGUsXG4gIEhlYWRlcnNcbn0gZnJvbSAnLi4vLi4vaW1wbGVtZW50YXRpb24vY29ubmVjdGlvbic7XG5pbXBvcnQgeyBpbnRlcm5hbEVycm9yIH0gZnJvbSAnLi4vLi4vaW1wbGVtZW50YXRpb24vZXJyb3InO1xuXG4vKiogQW4gb3ZlcnJpZGUgZm9yIHRoZSB0ZXh0LWJhc2VkIENvbm5lY3Rpb24uIFVzZWQgaW4gdGVzdHMuICovXG5sZXQgdGV4dEZhY3RvcnlPdmVycmlkZTogKCgpID0+IENvbm5lY3Rpb248c3RyaW5nPikgfCBudWxsID0gbnVsbDtcblxuLyoqXG4gKiBOZXR3b3JrIGxheWVyIGZvciBicm93c2Vycy4gV2UgdXNlIHRoaXMgaW5zdGVhZCBvZiBnb29nLm5ldC5YaHJJbyBiZWNhdXNlXG4gKiBnb29nLm5ldC5YaHJJbyBpcyBoeXV1dXVnZSBhbmQgZG9lc24ndCB3b3JrIGluIFJlYWN0IE5hdGl2ZSBvbiBBbmRyb2lkLlxuICovXG5hYnN0cmFjdCBjbGFzcyBYaHJDb25uZWN0aW9uPFQgZXh0ZW5kcyBDb25uZWN0aW9uVHlwZT5cbiAgaW1wbGVtZW50cyBDb25uZWN0aW9uPFQ+XG57XG4gIHByb3RlY3RlZCB4aHJfOiBYTUxIdHRwUmVxdWVzdDtcbiAgcHJpdmF0ZSBlcnJvckNvZGVfOiBFcnJvckNvZGU7XG4gIHByaXZhdGUgc2VuZFByb21pc2VfOiBQcm9taXNlPHZvaWQ+O1xuICBwcm90ZWN0ZWQgc2VudF86IGJvb2xlYW4gPSBmYWxzZTtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLnhocl8gPSBuZXcgWE1MSHR0cFJlcXVlc3QoKTtcbiAgICB0aGlzLmluaXRYaHIoKTtcbiAgICB0aGlzLmVycm9yQ29kZV8gPSBFcnJvckNvZGUuTk9fRVJST1I7XG4gICAgdGhpcy5zZW5kUHJvbWlzZV8gPSBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHtcbiAgICAgIHRoaXMueGhyXy5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsICgpID0+IHtcbiAgICAgICAgdGhpcy5lcnJvckNvZGVfID0gRXJyb3JDb2RlLkFCT1JUO1xuICAgICAgICByZXNvbHZlKCk7XG4gICAgICB9KTtcbiAgICAgIHRoaXMueGhyXy5hZGRFdmVudExpc3RlbmVyKCdlcnJvcicsICgpID0+IHtcbiAgICAgICAgdGhpcy5lcnJvckNvZGVfID0gRXJyb3JDb2RlLk5FVFdPUktfRVJST1I7XG4gICAgICAgIHJlc29sdmUoKTtcbiAgICAgIH0pO1xuICAgICAgdGhpcy54aHJfLmFkZEV2ZW50TGlzdGVuZXIoJ2xvYWQnLCAoKSA9PiB7XG4gICAgICAgIHJlc29sdmUoKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG5cbiAgYWJzdHJhY3QgaW5pdFhocigpOiB2b2lkO1xuXG4gIHNlbmQoXG4gICAgdXJsOiBzdHJpbmcsXG4gICAgbWV0aG9kOiBzdHJpbmcsXG4gICAgaXNVc2luZ0VtdWxhdG9yOiBib29sZWFuLFxuICAgIGJvZHk/OiBBcnJheUJ1ZmZlclZpZXcgfCBCbG9iIHwgc3RyaW5nLFxuICAgIGhlYWRlcnM/OiBIZWFkZXJzXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIGlmICh0aGlzLnNlbnRfKSB7XG4gICAgICB0aHJvdyBpbnRlcm5hbEVycm9yKCdjYW5ub3QgLnNlbmQoKSBtb3JlIHRoYW4gb25jZScpO1xuICAgIH1cbiAgICBpZiAoaXNDbG91ZFdvcmtzdGF0aW9uKHVybCkgJiYgaXNVc2luZ0VtdWxhdG9yKSB7XG4gICAgICB0aGlzLnhocl8ud2l0aENyZWRlbnRpYWxzID0gdHJ1ZTtcbiAgICB9XG4gICAgdGhpcy5zZW50XyA9IHRydWU7XG4gICAgdGhpcy54aHJfLm9wZW4obWV0aG9kLCB1cmwsIHRydWUpO1xuICAgIGlmIChoZWFkZXJzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGZvciAoY29uc3Qga2V5IGluIGhlYWRlcnMpIHtcbiAgICAgICAgaWYgKGhlYWRlcnMuaGFzT3duUHJvcGVydHkoa2V5KSkge1xuICAgICAgICAgIHRoaXMueGhyXy5zZXRSZXF1ZXN0SGVhZGVyKGtleSwgaGVhZGVyc1trZXldLnRvU3RyaW5nKCkpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChib2R5ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMueGhyXy5zZW5kKGJvZHkpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnhocl8uc2VuZCgpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5zZW5kUHJvbWlzZV87XG4gIH1cblxuICBnZXRFcnJvckNvZGUoKTogRXJyb3JDb2RlIHtcbiAgICBpZiAoIXRoaXMuc2VudF8pIHtcbiAgICAgIHRocm93IGludGVybmFsRXJyb3IoJ2Nhbm5vdCAuZ2V0RXJyb3JDb2RlKCkgYmVmb3JlIHNlbmRpbmcnKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuZXJyb3JDb2RlXztcbiAgfVxuXG4gIGdldFN0YXR1cygpOiBudW1iZXIge1xuICAgIGlmICghdGhpcy5zZW50Xykge1xuICAgICAgdGhyb3cgaW50ZXJuYWxFcnJvcignY2Fubm90IC5nZXRTdGF0dXMoKSBiZWZvcmUgc2VuZGluZycpO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgcmV0dXJuIHRoaXMueGhyXy5zdGF0dXM7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgcmV0dXJuIC0xO1xuICAgIH1cbiAgfVxuXG4gIGdldFJlc3BvbnNlKCk6IFQge1xuICAgIGlmICghdGhpcy5zZW50Xykge1xuICAgICAgdGhyb3cgaW50ZXJuYWxFcnJvcignY2Fubm90IC5nZXRSZXNwb25zZSgpIGJlZm9yZSBzZW5kaW5nJyk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnhocl8ucmVzcG9uc2U7XG4gIH1cblxuICBnZXRFcnJvclRleHQoKTogc3RyaW5nIHtcbiAgICBpZiAoIXRoaXMuc2VudF8pIHtcbiAgICAgIHRocm93IGludGVybmFsRXJyb3IoJ2Nhbm5vdCAuZ2V0RXJyb3JUZXh0KCkgYmVmb3JlIHNlbmRpbmcnKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMueGhyXy5zdGF0dXNUZXh0O1xuICB9XG5cbiAgLyoqIEFib3J0cyB0aGUgcmVxdWVzdC4gKi9cbiAgYWJvcnQoKTogdm9pZCB7XG4gICAgdGhpcy54aHJfLmFib3J0KCk7XG4gIH1cblxuICBnZXRSZXNwb25zZUhlYWRlcihoZWFkZXI6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuICAgIHJldHVybiB0aGlzLnhocl8uZ2V0UmVzcG9uc2VIZWFkZXIoaGVhZGVyKTtcbiAgfVxuXG4gIGFkZFVwbG9hZFByb2dyZXNzTGlzdGVuZXIobGlzdGVuZXI6IChwMTogUHJvZ3Jlc3NFdmVudCkgPT4gdm9pZCk6IHZvaWQge1xuICAgIGlmICh0aGlzLnhocl8udXBsb2FkICE9IG51bGwpIHtcbiAgICAgIHRoaXMueGhyXy51cGxvYWQuYWRkRXZlbnRMaXN0ZW5lcigncHJvZ3Jlc3MnLCBsaXN0ZW5lcik7XG4gICAgfVxuICB9XG5cbiAgcmVtb3ZlVXBsb2FkUHJvZ3Jlc3NMaXN0ZW5lcihsaXN0ZW5lcjogKHAxOiBQcm9ncmVzc0V2ZW50KSA9PiB2b2lkKTogdm9pZCB7XG4gICAgaWYgKHRoaXMueGhyXy51cGxvYWQgIT0gbnVsbCkge1xuICAgICAgdGhpcy54aHJfLnVwbG9hZC5yZW1vdmVFdmVudExpc3RlbmVyKCdwcm9ncmVzcycsIGxpc3RlbmVyKTtcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIFhoclRleHRDb25uZWN0aW9uIGV4dGVuZHMgWGhyQ29ubmVjdGlvbjxzdHJpbmc+IHtcbiAgaW5pdFhocigpOiB2b2lkIHtcbiAgICB0aGlzLnhocl8ucmVzcG9uc2VUeXBlID0gJ3RleHQnO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBuZXdUZXh0Q29ubmVjdGlvbigpOiBDb25uZWN0aW9uPHN0cmluZz4ge1xuICByZXR1cm4gdGV4dEZhY3RvcnlPdmVycmlkZSA/IHRleHRGYWN0b3J5T3ZlcnJpZGUoKSA6IG5ldyBYaHJUZXh0Q29ubmVjdGlvbigpO1xufVxuXG5leHBvcnQgY2xhc3MgWGhyQnl0ZXNDb25uZWN0aW9uIGV4dGVuZHMgWGhyQ29ubmVjdGlvbjxBcnJheUJ1ZmZlcj4ge1xuICBwcml2YXRlIGRhdGFfPzogQXJyYXlCdWZmZXI7XG5cbiAgaW5pdFhocigpOiB2b2lkIHtcbiAgICB0aGlzLnhocl8ucmVzcG9uc2VUeXBlID0gJ2FycmF5YnVmZmVyJztcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gbmV3Qnl0ZXNDb25uZWN0aW9uKCk6IENvbm5lY3Rpb248QXJyYXlCdWZmZXI+IHtcbiAgcmV0dXJuIG5ldyBYaHJCeXRlc0Nvbm5lY3Rpb24oKTtcbn1cblxuZXhwb3J0IGNsYXNzIFhockJsb2JDb25uZWN0aW9uIGV4dGVuZHMgWGhyQ29ubmVjdGlvbjxCbG9iPiB7XG4gIGluaXRYaHIoKTogdm9pZCB7XG4gICAgdGhpcy54aHJfLnJlc3BvbnNlVHlwZSA9ICdibG9iJztcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gbmV3QmxvYkNvbm5lY3Rpb24oKTogQ29ubmVjdGlvbjxCbG9iPiB7XG4gIHJldHVybiBuZXcgWGhyQmxvYkNvbm5lY3Rpb24oKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIG5ld1N0cmVhbUNvbm5lY3Rpb24oKTogQ29ubmVjdGlvbjxSZWFkYWJsZVN0cmVhbT4ge1xuICB0aHJvdyBuZXcgRXJyb3IoJ1N0cmVhbXMgYXJlIG9ubHkgc3VwcG9ydGVkIG9uIE5vZGUnKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGluamVjdFRlc3RDb25uZWN0aW9uKFxuICBmYWN0b3J5OiAoKCkgPT4gQ29ubmVjdGlvbjxzdHJpbmc+KSB8IG51bGxcbik6IHZvaWQge1xuICB0ZXh0RmFjdG9yeU92ZXJyaWRlID0gZmFjdG9yeTtcbn1cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDE3IEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG4vKipcbiAqIEBmaWxlb3ZlcnZpZXcgRGVmaW5lcyB0eXBlcyBmb3IgaW50ZXJhY3Rpbmcgd2l0aCBibG9iIHRyYW5zZmVyIHRhc2tzLlxuICovXG5cbmltcG9ydCB7IEZic0Jsb2IgfSBmcm9tICcuL2ltcGxlbWVudGF0aW9uL2Jsb2InO1xuaW1wb3J0IHtcbiAgY2FuY2VsZWQsXG4gIFN0b3JhZ2VFcnJvckNvZGUsXG4gIFN0b3JhZ2VFcnJvcixcbiAgcmV0cnlMaW1pdEV4Y2VlZGVkXG59IGZyb20gJy4vaW1wbGVtZW50YXRpb24vZXJyb3InO1xuaW1wb3J0IHtcbiAgSW50ZXJuYWxUYXNrU3RhdGUsXG4gIFRhc2tFdmVudCxcbiAgVGFza1N0YXRlLFxuICB0YXNrU3RhdGVGcm9tSW50ZXJuYWxUYXNrU3RhdGVcbn0gZnJvbSAnLi9pbXBsZW1lbnRhdGlvbi90YXNrZW51bXMnO1xuaW1wb3J0IHsgTWV0YWRhdGEgfSBmcm9tICcuL21ldGFkYXRhJztcbmltcG9ydCB7XG4gIE9ic2VydmVyLFxuICBTdWJzY3JpYmUsXG4gIFVuc3Vic2NyaWJlLFxuICBTdG9yYWdlT2JzZXJ2ZXIgYXMgU3RvcmFnZU9ic2VydmVySW50ZXJuYWwsXG4gIE5leHRGblxufSBmcm9tICcuL2ltcGxlbWVudGF0aW9uL29ic2VydmVyJztcbmltcG9ydCB7IFJlcXVlc3QgfSBmcm9tICcuL2ltcGxlbWVudGF0aW9uL3JlcXVlc3QnO1xuaW1wb3J0IHsgVXBsb2FkVGFza1NuYXBzaG90LCBTdG9yYWdlT2JzZXJ2ZXIgfSBmcm9tICcuL3B1YmxpYy10eXBlcyc7XG5pbXBvcnQgeyBhc3luYyBhcyBmYnNBc3luYyB9IGZyb20gJy4vaW1wbGVtZW50YXRpb24vYXN5bmMnO1xuaW1wb3J0IHsgTWFwcGluZ3MsIGdldE1hcHBpbmdzIH0gZnJvbSAnLi9pbXBsZW1lbnRhdGlvbi9tZXRhZGF0YSc7XG5pbXBvcnQge1xuICBjcmVhdGVSZXN1bWFibGVVcGxvYWQsXG4gIGdldFJlc3VtYWJsZVVwbG9hZFN0YXR1cyxcbiAgUkVTVU1BQkxFX1VQTE9BRF9DSFVOS19TSVpFLFxuICBSZXN1bWFibGVVcGxvYWRTdGF0dXMsXG4gIGNvbnRpbnVlUmVzdW1hYmxlVXBsb2FkLFxuICBnZXRNZXRhZGF0YSxcbiAgbXVsdGlwYXJ0VXBsb2FkXG59IGZyb20gJy4vaW1wbGVtZW50YXRpb24vcmVxdWVzdHMnO1xuaW1wb3J0IHsgUmVmZXJlbmNlIH0gZnJvbSAnLi9yZWZlcmVuY2UnO1xuaW1wb3J0IHsgbmV3VGV4dENvbm5lY3Rpb24gfSBmcm9tICcuL3BsYXRmb3JtL2Nvbm5lY3Rpb24nO1xuaW1wb3J0IHsgaXNSZXRyeVN0YXR1c0NvZGUgfSBmcm9tICcuL2ltcGxlbWVudGF0aW9uL3V0aWxzJztcbmltcG9ydCB7IENvbXBsZXRlRm4gfSBmcm9tICdAZmlyZWJhc2UvdXRpbCc7XG5pbXBvcnQgeyBERUZBVUxUX01JTl9TTEVFUF9USU1FX01JTExJUyB9IGZyb20gJy4vaW1wbGVtZW50YXRpb24vY29uc3RhbnRzJztcblxuLyoqXG4gKiBSZXByZXNlbnRzIGEgYmxvYiBiZWluZyB1cGxvYWRlZC4gQ2FuIGJlIHVzZWQgdG8gcGF1c2UvcmVzdW1lL2NhbmNlbCB0aGVcbiAqIHVwbG9hZCBhbmQgbWFuYWdlIGNhbGxiYWNrcyBmb3IgdmFyaW91cyBldmVudHMuXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGNsYXNzIFVwbG9hZFRhc2sge1xuICBwcml2YXRlIF9yZWY6IFJlZmVyZW5jZTtcbiAgLyoqXG4gICAqIFRoZSBkYXRhIHRvIGJlIHVwbG9hZGVkLlxuICAgKi9cbiAgX2Jsb2I6IEZic0Jsb2I7XG4gIC8qKlxuICAgKiBNZXRhZGF0YSByZWxhdGVkIHRvIHRoZSB1cGxvYWQuXG4gICAqL1xuICBfbWV0YWRhdGE6IE1ldGFkYXRhIHwgbnVsbDtcbiAgcHJpdmF0ZSBfbWFwcGluZ3M6IE1hcHBpbmdzO1xuICAvKipcbiAgICogTnVtYmVyIG9mIGJ5dGVzIHRyYW5zZmVycmVkIHNvIGZhci5cbiAgICovXG4gIF90cmFuc2ZlcnJlZDogbnVtYmVyID0gMDtcbiAgcHJpdmF0ZSBfbmVlZFRvRmV0Y2hTdGF0dXM6IGJvb2xlYW4gPSBmYWxzZTtcbiAgcHJpdmF0ZSBfbmVlZFRvRmV0Y2hNZXRhZGF0YTogYm9vbGVhbiA9IGZhbHNlO1xuICBwcml2YXRlIF9vYnNlcnZlcnM6IEFycmF5PFN0b3JhZ2VPYnNlcnZlckludGVybmFsPFVwbG9hZFRhc2tTbmFwc2hvdD4+ID0gW107XG4gIHByaXZhdGUgX3Jlc3VtYWJsZTogYm9vbGVhbjtcbiAgLyoqXG4gICAqIFVwbG9hZCBzdGF0ZS5cbiAgICovXG4gIF9zdGF0ZTogSW50ZXJuYWxUYXNrU3RhdGU7XG4gIHByaXZhdGUgX2Vycm9yPzogU3RvcmFnZUVycm9yID0gdW5kZWZpbmVkO1xuICBwcml2YXRlIF91cGxvYWRVcmw/OiBzdHJpbmcgPSB1bmRlZmluZWQ7XG4gIHByaXZhdGUgX3JlcXVlc3Q/OiBSZXF1ZXN0PHVua25vd24+ID0gdW5kZWZpbmVkO1xuICBwcml2YXRlIF9jaHVua011bHRpcGxpZXI6IG51bWJlciA9IDE7XG4gIHByaXZhdGUgX2Vycm9ySGFuZGxlcjogKHAxOiBTdG9yYWdlRXJyb3IpID0+IHZvaWQ7XG4gIHByaXZhdGUgX21ldGFkYXRhRXJyb3JIYW5kbGVyOiAocDE6IFN0b3JhZ2VFcnJvcikgPT4gdm9pZDtcbiAgcHJpdmF0ZSBfcmVzb2x2ZT86IChwMTogVXBsb2FkVGFza1NuYXBzaG90KSA9PiB2b2lkID0gdW5kZWZpbmVkO1xuICBwcml2YXRlIF9yZWplY3Q/OiAocDE6IFN0b3JhZ2VFcnJvcikgPT4gdm9pZCA9IHVuZGVmaW5lZDtcbiAgcHJpdmF0ZSBwZW5kaW5nVGltZW91dD86IFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+O1xuICBwcml2YXRlIF9wcm9taXNlOiBQcm9taXNlPFVwbG9hZFRhc2tTbmFwc2hvdD47XG5cbiAgcHJpdmF0ZSBzbGVlcFRpbWU6IG51bWJlcjtcblxuICBwcml2YXRlIG1heFNsZWVwVGltZTogbnVtYmVyO1xuXG4gIGlzRXhwb25lbnRpYWxCYWNrb2ZmRXhwaXJlZCgpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy5zbGVlcFRpbWUgPiB0aGlzLm1heFNsZWVwVGltZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAcGFyYW0gcmVmIC0gVGhlIGZpcmViYXNlU3RvcmFnZS5SZWZlcmVuY2Ugb2JqZWN0IHRoaXMgdGFzayBjYW1lXG4gICAqICAgICBmcm9tLCB1bnR5cGVkIHRvIGF2b2lkIGN5Y2xpYyBkZXBlbmRlbmNpZXMuXG4gICAqIEBwYXJhbSBibG9iIC0gVGhlIGJsb2IgdG8gdXBsb2FkLlxuICAgKi9cbiAgY29uc3RydWN0b3IocmVmOiBSZWZlcmVuY2UsIGJsb2I6IEZic0Jsb2IsIG1ldGFkYXRhOiBNZXRhZGF0YSB8IG51bGwgPSBudWxsKSB7XG4gICAgdGhpcy5fcmVmID0gcmVmO1xuICAgIHRoaXMuX2Jsb2IgPSBibG9iO1xuICAgIHRoaXMuX21ldGFkYXRhID0gbWV0YWRhdGE7XG4gICAgdGhpcy5fbWFwcGluZ3MgPSBnZXRNYXBwaW5ncygpO1xuICAgIHRoaXMuX3Jlc3VtYWJsZSA9IHRoaXMuX3Nob3VsZERvUmVzdW1hYmxlKHRoaXMuX2Jsb2IpO1xuICAgIHRoaXMuX3N0YXRlID0gSW50ZXJuYWxUYXNrU3RhdGUuUlVOTklORztcbiAgICB0aGlzLl9lcnJvckhhbmRsZXIgPSBlcnJvciA9PiB7XG4gICAgICB0aGlzLl9yZXF1ZXN0ID0gdW5kZWZpbmVkO1xuICAgICAgdGhpcy5fY2h1bmtNdWx0aXBsaWVyID0gMTtcbiAgICAgIGlmIChlcnJvci5fY29kZUVxdWFscyhTdG9yYWdlRXJyb3JDb2RlLkNBTkNFTEVEKSkge1xuICAgICAgICB0aGlzLl9uZWVkVG9GZXRjaFN0YXR1cyA9IHRydWU7XG4gICAgICAgIHRoaXMuY29tcGxldGVUcmFuc2l0aW9uc18oKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IGJhY2tvZmZFeHBpcmVkID0gdGhpcy5pc0V4cG9uZW50aWFsQmFja29mZkV4cGlyZWQoKTtcbiAgICAgICAgaWYgKGlzUmV0cnlTdGF0dXNDb2RlKGVycm9yLnN0YXR1cywgW10pKSB7XG4gICAgICAgICAgaWYgKGJhY2tvZmZFeHBpcmVkKSB7XG4gICAgICAgICAgICBlcnJvciA9IHJldHJ5TGltaXRFeGNlZWRlZCgpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnNsZWVwVGltZSA9IE1hdGgubWF4KFxuICAgICAgICAgICAgICB0aGlzLnNsZWVwVGltZSAqIDIsXG4gICAgICAgICAgICAgIERFRkFVTFRfTUlOX1NMRUVQX1RJTUVfTUlMTElTXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgdGhpcy5fbmVlZFRvRmV0Y2hTdGF0dXMgPSB0cnVlO1xuICAgICAgICAgICAgdGhpcy5jb21wbGV0ZVRyYW5zaXRpb25zXygpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0aGlzLl9lcnJvciA9IGVycm9yO1xuICAgICAgICB0aGlzLl90cmFuc2l0aW9uKEludGVybmFsVGFza1N0YXRlLkVSUk9SKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHRoaXMuX21ldGFkYXRhRXJyb3JIYW5kbGVyID0gZXJyb3IgPT4ge1xuICAgICAgdGhpcy5fcmVxdWVzdCA9IHVuZGVmaW5lZDtcbiAgICAgIGlmIChlcnJvci5fY29kZUVxdWFscyhTdG9yYWdlRXJyb3JDb2RlLkNBTkNFTEVEKSkge1xuICAgICAgICB0aGlzLmNvbXBsZXRlVHJhbnNpdGlvbnNfKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLl9lcnJvciA9IGVycm9yO1xuICAgICAgICB0aGlzLl90cmFuc2l0aW9uKEludGVybmFsVGFza1N0YXRlLkVSUk9SKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHRoaXMuc2xlZXBUaW1lID0gMDtcbiAgICB0aGlzLm1heFNsZWVwVGltZSA9IHRoaXMuX3JlZi5zdG9yYWdlLm1heFVwbG9hZFJldHJ5VGltZTtcbiAgICB0aGlzLl9wcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdGhpcy5fcmVzb2x2ZSA9IHJlc29sdmU7XG4gICAgICB0aGlzLl9yZWplY3QgPSByZWplY3Q7XG4gICAgICB0aGlzLl9zdGFydCgpO1xuICAgIH0pO1xuXG4gICAgLy8gUHJldmVudCB1bmNhdWdodCByZWplY3Rpb25zIG9uIHRoZSBpbnRlcm5hbCBwcm9taXNlIGZyb20gYnViYmxpbmcgb3V0XG4gICAgLy8gdG8gdGhlIHRvcCBsZXZlbCB3aXRoIGEgZHVtbXkgaGFuZGxlci5cbiAgICB0aGlzLl9wcm9taXNlLnRoZW4obnVsbCwgKCkgPT4ge30pO1xuICB9XG5cbiAgcHJpdmF0ZSBfbWFrZVByb2dyZXNzQ2FsbGJhY2soKTogKHAxOiBudW1iZXIsIHAyOiBudW1iZXIpID0+IHZvaWQge1xuICAgIGNvbnN0IHNpemVCZWZvcmUgPSB0aGlzLl90cmFuc2ZlcnJlZDtcbiAgICByZXR1cm4gbG9hZGVkID0+IHRoaXMuX3VwZGF0ZVByb2dyZXNzKHNpemVCZWZvcmUgKyBsb2FkZWQpO1xuICB9XG5cbiAgcHJpdmF0ZSBfc2hvdWxkRG9SZXN1bWFibGUoYmxvYjogRmJzQmxvYik6IGJvb2xlYW4ge1xuICAgIHJldHVybiBibG9iLnNpemUoKSA+IDI1NiAqIDEwMjQ7XG4gIH1cblxuICBwcml2YXRlIF9zdGFydCgpOiB2b2lkIHtcbiAgICBpZiAodGhpcy5fc3RhdGUgIT09IEludGVybmFsVGFza1N0YXRlLlJVTk5JTkcpIHtcbiAgICAgIC8vIFRoaXMgY2FuIGhhcHBlbiBpZiBzb21lb25lIHBhdXNlcyB1cyBpbiBhIHJlc3VtZSBjYWxsYmFjaywgZm9yIGV4YW1wbGUuXG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICh0aGlzLl9yZXF1ZXN0ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHRoaXMuX3Jlc3VtYWJsZSkge1xuICAgICAgaWYgKHRoaXMuX3VwbG9hZFVybCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuX2NyZWF0ZVJlc3VtYWJsZSgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKHRoaXMuX25lZWRUb0ZldGNoU3RhdHVzKSB7XG4gICAgICAgICAgdGhpcy5fZmV0Y2hTdGF0dXMoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBpZiAodGhpcy5fbmVlZFRvRmV0Y2hNZXRhZGF0YSkge1xuICAgICAgICAgICAgLy8gSGFwcGVucyBpZiB3ZSBtaXNzIHRoZSBtZXRhZGF0YSBvbiB1cGxvYWQgY29tcGxldGlvbi5cbiAgICAgICAgICAgIHRoaXMuX2ZldGNoTWV0YWRhdGEoKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5wZW5kaW5nVGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICB0aGlzLnBlbmRpbmdUaW1lb3V0ID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgICB0aGlzLl9jb250aW51ZVVwbG9hZCgpO1xuICAgICAgICAgICAgfSwgdGhpcy5zbGVlcFRpbWUpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9vbmVTaG90VXBsb2FkKCk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBfcmVzb2x2ZVRva2VuKFxuICAgIGNhbGxiYWNrOiAoYXV0aFRva2VuOiBzdHJpbmcgfCBudWxsLCBhcHBDaGVja1Rva2VuOiBzdHJpbmcgfCBudWxsKSA9PiB2b2lkXG4gICk6IHZvaWQge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZmxvYXRpbmctcHJvbWlzZXNcbiAgICBQcm9taXNlLmFsbChbXG4gICAgICB0aGlzLl9yZWYuc3RvcmFnZS5fZ2V0QXV0aFRva2VuKCksXG4gICAgICB0aGlzLl9yZWYuc3RvcmFnZS5fZ2V0QXBwQ2hlY2tUb2tlbigpXG4gICAgXSkudGhlbigoW2F1dGhUb2tlbiwgYXBwQ2hlY2tUb2tlbl0pID0+IHtcbiAgICAgIHN3aXRjaCAodGhpcy5fc3RhdGUpIHtcbiAgICAgICAgY2FzZSBJbnRlcm5hbFRhc2tTdGF0ZS5SVU5OSU5HOlxuICAgICAgICAgIGNhbGxiYWNrKGF1dGhUb2tlbiwgYXBwQ2hlY2tUb2tlbik7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgSW50ZXJuYWxUYXNrU3RhdGUuQ0FOQ0VMSU5HOlxuICAgICAgICAgIHRoaXMuX3RyYW5zaXRpb24oSW50ZXJuYWxUYXNrU3RhdGUuQ0FOQ0VMRUQpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIEludGVybmFsVGFza1N0YXRlLlBBVVNJTkc6XG4gICAgICAgICAgdGhpcy5fdHJhbnNpdGlvbihJbnRlcm5hbFRhc2tTdGF0ZS5QQVVTRUQpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgLy8gVE9ETyhhbmR5c290byk6IGFzc2VydCBmYWxzZVxuXG4gIHByaXZhdGUgX2NyZWF0ZVJlc3VtYWJsZSgpOiB2b2lkIHtcbiAgICB0aGlzLl9yZXNvbHZlVG9rZW4oKGF1dGhUb2tlbiwgYXBwQ2hlY2tUb2tlbikgPT4ge1xuICAgICAgY29uc3QgcmVxdWVzdEluZm8gPSBjcmVhdGVSZXN1bWFibGVVcGxvYWQoXG4gICAgICAgIHRoaXMuX3JlZi5zdG9yYWdlLFxuICAgICAgICB0aGlzLl9yZWYuX2xvY2F0aW9uLFxuICAgICAgICB0aGlzLl9tYXBwaW5ncyxcbiAgICAgICAgdGhpcy5fYmxvYixcbiAgICAgICAgdGhpcy5fbWV0YWRhdGFcbiAgICAgICk7XG4gICAgICBjb25zdCBjcmVhdGVSZXF1ZXN0ID0gdGhpcy5fcmVmLnN0b3JhZ2UuX21ha2VSZXF1ZXN0KFxuICAgICAgICByZXF1ZXN0SW5mbyxcbiAgICAgICAgbmV3VGV4dENvbm5lY3Rpb24sXG4gICAgICAgIGF1dGhUb2tlbixcbiAgICAgICAgYXBwQ2hlY2tUb2tlblxuICAgICAgKTtcbiAgICAgIHRoaXMuX3JlcXVlc3QgPSBjcmVhdGVSZXF1ZXN0O1xuICAgICAgY3JlYXRlUmVxdWVzdC5nZXRQcm9taXNlKCkudGhlbigodXJsOiBzdHJpbmcpID0+IHtcbiAgICAgICAgdGhpcy5fcmVxdWVzdCA9IHVuZGVmaW5lZDtcbiAgICAgICAgdGhpcy5fdXBsb2FkVXJsID0gdXJsO1xuICAgICAgICB0aGlzLl9uZWVkVG9GZXRjaFN0YXR1cyA9IGZhbHNlO1xuICAgICAgICB0aGlzLmNvbXBsZXRlVHJhbnNpdGlvbnNfKCk7XG4gICAgICB9LCB0aGlzLl9lcnJvckhhbmRsZXIpO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBfZmV0Y2hTdGF0dXMoKTogdm9pZCB7XG4gICAgLy8gVE9ETyhhbmR5c290byk6IGFzc2VydCh0aGlzLnVwbG9hZFVybF8gIT09IG51bGwpO1xuICAgIGNvbnN0IHVybCA9IHRoaXMuX3VwbG9hZFVybCBhcyBzdHJpbmc7XG4gICAgdGhpcy5fcmVzb2x2ZVRva2VuKChhdXRoVG9rZW4sIGFwcENoZWNrVG9rZW4pID0+IHtcbiAgICAgIGNvbnN0IHJlcXVlc3RJbmZvID0gZ2V0UmVzdW1hYmxlVXBsb2FkU3RhdHVzKFxuICAgICAgICB0aGlzLl9yZWYuc3RvcmFnZSxcbiAgICAgICAgdGhpcy5fcmVmLl9sb2NhdGlvbixcbiAgICAgICAgdXJsLFxuICAgICAgICB0aGlzLl9ibG9iXG4gICAgICApO1xuICAgICAgY29uc3Qgc3RhdHVzUmVxdWVzdCA9IHRoaXMuX3JlZi5zdG9yYWdlLl9tYWtlUmVxdWVzdChcbiAgICAgICAgcmVxdWVzdEluZm8sXG4gICAgICAgIG5ld1RleHRDb25uZWN0aW9uLFxuICAgICAgICBhdXRoVG9rZW4sXG4gICAgICAgIGFwcENoZWNrVG9rZW5cbiAgICAgICk7XG4gICAgICB0aGlzLl9yZXF1ZXN0ID0gc3RhdHVzUmVxdWVzdDtcbiAgICAgIHN0YXR1c1JlcXVlc3QuZ2V0UHJvbWlzZSgpLnRoZW4oc3RhdHVzID0+IHtcbiAgICAgICAgc3RhdHVzID0gc3RhdHVzIGFzIFJlc3VtYWJsZVVwbG9hZFN0YXR1cztcbiAgICAgICAgdGhpcy5fcmVxdWVzdCA9IHVuZGVmaW5lZDtcbiAgICAgICAgdGhpcy5fdXBkYXRlUHJvZ3Jlc3Moc3RhdHVzLmN1cnJlbnQpO1xuICAgICAgICB0aGlzLl9uZWVkVG9GZXRjaFN0YXR1cyA9IGZhbHNlO1xuICAgICAgICBpZiAoc3RhdHVzLmZpbmFsaXplZCkge1xuICAgICAgICAgIHRoaXMuX25lZWRUb0ZldGNoTWV0YWRhdGEgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuY29tcGxldGVUcmFuc2l0aW9uc18oKTtcbiAgICAgIH0sIHRoaXMuX2Vycm9ySGFuZGxlcik7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIF9jb250aW51ZVVwbG9hZCgpOiB2b2lkIHtcbiAgICBjb25zdCBjaHVua1NpemUgPSBSRVNVTUFCTEVfVVBMT0FEX0NIVU5LX1NJWkUgKiB0aGlzLl9jaHVua011bHRpcGxpZXI7XG4gICAgY29uc3Qgc3RhdHVzID0gbmV3IFJlc3VtYWJsZVVwbG9hZFN0YXR1cyhcbiAgICAgIHRoaXMuX3RyYW5zZmVycmVkLFxuICAgICAgdGhpcy5fYmxvYi5zaXplKClcbiAgICApO1xuXG4gICAgLy8gVE9ETyhhbmR5c290byk6IGFzc2VydCh0aGlzLnVwbG9hZFVybF8gIT09IG51bGwpO1xuICAgIGNvbnN0IHVybCA9IHRoaXMuX3VwbG9hZFVybCBhcyBzdHJpbmc7XG4gICAgdGhpcy5fcmVzb2x2ZVRva2VuKChhdXRoVG9rZW4sIGFwcENoZWNrVG9rZW4pID0+IHtcbiAgICAgIGxldCByZXF1ZXN0SW5mbztcbiAgICAgIHRyeSB7XG4gICAgICAgIHJlcXVlc3RJbmZvID0gY29udGludWVSZXN1bWFibGVVcGxvYWQoXG4gICAgICAgICAgdGhpcy5fcmVmLl9sb2NhdGlvbixcbiAgICAgICAgICB0aGlzLl9yZWYuc3RvcmFnZSxcbiAgICAgICAgICB1cmwsXG4gICAgICAgICAgdGhpcy5fYmxvYixcbiAgICAgICAgICBjaHVua1NpemUsXG4gICAgICAgICAgdGhpcy5fbWFwcGluZ3MsXG4gICAgICAgICAgc3RhdHVzLFxuICAgICAgICAgIHRoaXMuX21ha2VQcm9ncmVzc0NhbGxiYWNrKClcbiAgICAgICAgKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgdGhpcy5fZXJyb3IgPSBlIGFzIFN0b3JhZ2VFcnJvcjtcbiAgICAgICAgdGhpcy5fdHJhbnNpdGlvbihJbnRlcm5hbFRhc2tTdGF0ZS5FUlJPUik7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHVwbG9hZFJlcXVlc3QgPSB0aGlzLl9yZWYuc3RvcmFnZS5fbWFrZVJlcXVlc3QoXG4gICAgICAgIHJlcXVlc3RJbmZvLFxuICAgICAgICBuZXdUZXh0Q29ubmVjdGlvbixcbiAgICAgICAgYXV0aFRva2VuLFxuICAgICAgICBhcHBDaGVja1Rva2VuLFxuICAgICAgICAvKnJldHJ5PSovIGZhbHNlIC8vIFVwbG9hZCByZXF1ZXN0cyBzaG91bGQgbm90IGJlIHJldHJpZWQgYXMgZWFjaCByZXRyeSBzaG91bGQgYmUgcHJlY2VkZWQgYnkgYW5vdGhlciBxdWVyeSByZXF1ZXN0LiBXaGljaCBpcyBoYW5kbGVkIGluIHRoaXMgZmlsZS5cbiAgICAgICk7XG4gICAgICB0aGlzLl9yZXF1ZXN0ID0gdXBsb2FkUmVxdWVzdDtcbiAgICAgIHVwbG9hZFJlcXVlc3QuZ2V0UHJvbWlzZSgpLnRoZW4oKG5ld1N0YXR1czogUmVzdW1hYmxlVXBsb2FkU3RhdHVzKSA9PiB7XG4gICAgICAgIHRoaXMuX2luY3JlYXNlTXVsdGlwbGllcigpO1xuICAgICAgICB0aGlzLl9yZXF1ZXN0ID0gdW5kZWZpbmVkO1xuICAgICAgICB0aGlzLl91cGRhdGVQcm9ncmVzcyhuZXdTdGF0dXMuY3VycmVudCk7XG4gICAgICAgIGlmIChuZXdTdGF0dXMuZmluYWxpemVkKSB7XG4gICAgICAgICAgdGhpcy5fbWV0YWRhdGEgPSBuZXdTdGF0dXMubWV0YWRhdGE7XG4gICAgICAgICAgdGhpcy5fdHJhbnNpdGlvbihJbnRlcm5hbFRhc2tTdGF0ZS5TVUNDRVNTKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aGlzLmNvbXBsZXRlVHJhbnNpdGlvbnNfKCk7XG4gICAgICAgIH1cbiAgICAgIH0sIHRoaXMuX2Vycm9ySGFuZGxlcik7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIF9pbmNyZWFzZU11bHRpcGxpZXIoKTogdm9pZCB7XG4gICAgY29uc3QgY3VycmVudFNpemUgPSBSRVNVTUFCTEVfVVBMT0FEX0NIVU5LX1NJWkUgKiB0aGlzLl9jaHVua011bHRpcGxpZXI7XG5cbiAgICAvLyBNYXggY2h1bmsgc2l6ZSBpcyAzMk0uXG4gICAgaWYgKGN1cnJlbnRTaXplICogMiA8IDMyICogMTAyNCAqIDEwMjQpIHtcbiAgICAgIHRoaXMuX2NodW5rTXVsdGlwbGllciAqPSAyO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgX2ZldGNoTWV0YWRhdGEoKTogdm9pZCB7XG4gICAgdGhpcy5fcmVzb2x2ZVRva2VuKChhdXRoVG9rZW4sIGFwcENoZWNrVG9rZW4pID0+IHtcbiAgICAgIGNvbnN0IHJlcXVlc3RJbmZvID0gZ2V0TWV0YWRhdGEoXG4gICAgICAgIHRoaXMuX3JlZi5zdG9yYWdlLFxuICAgICAgICB0aGlzLl9yZWYuX2xvY2F0aW9uLFxuICAgICAgICB0aGlzLl9tYXBwaW5nc1xuICAgICAgKTtcbiAgICAgIGNvbnN0IG1ldGFkYXRhUmVxdWVzdCA9IHRoaXMuX3JlZi5zdG9yYWdlLl9tYWtlUmVxdWVzdChcbiAgICAgICAgcmVxdWVzdEluZm8sXG4gICAgICAgIG5ld1RleHRDb25uZWN0aW9uLFxuICAgICAgICBhdXRoVG9rZW4sXG4gICAgICAgIGFwcENoZWNrVG9rZW5cbiAgICAgICk7XG4gICAgICB0aGlzLl9yZXF1ZXN0ID0gbWV0YWRhdGFSZXF1ZXN0O1xuICAgICAgbWV0YWRhdGFSZXF1ZXN0LmdldFByb21pc2UoKS50aGVuKG1ldGFkYXRhID0+IHtcbiAgICAgICAgdGhpcy5fcmVxdWVzdCA9IHVuZGVmaW5lZDtcbiAgICAgICAgdGhpcy5fbWV0YWRhdGEgPSBtZXRhZGF0YTtcbiAgICAgICAgdGhpcy5fdHJhbnNpdGlvbihJbnRlcm5hbFRhc2tTdGF0ZS5TVUNDRVNTKTtcbiAgICAgIH0sIHRoaXMuX21ldGFkYXRhRXJyb3JIYW5kbGVyKTtcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgX29uZVNob3RVcGxvYWQoKTogdm9pZCB7XG4gICAgdGhpcy5fcmVzb2x2ZVRva2VuKChhdXRoVG9rZW4sIGFwcENoZWNrVG9rZW4pID0+IHtcbiAgICAgIGNvbnN0IHJlcXVlc3RJbmZvID0gbXVsdGlwYXJ0VXBsb2FkKFxuICAgICAgICB0aGlzLl9yZWYuc3RvcmFnZSxcbiAgICAgICAgdGhpcy5fcmVmLl9sb2NhdGlvbixcbiAgICAgICAgdGhpcy5fbWFwcGluZ3MsXG4gICAgICAgIHRoaXMuX2Jsb2IsXG4gICAgICAgIHRoaXMuX21ldGFkYXRhXG4gICAgICApO1xuICAgICAgY29uc3QgbXVsdGlwYXJ0UmVxdWVzdCA9IHRoaXMuX3JlZi5zdG9yYWdlLl9tYWtlUmVxdWVzdChcbiAgICAgICAgcmVxdWVzdEluZm8sXG4gICAgICAgIG5ld1RleHRDb25uZWN0aW9uLFxuICAgICAgICBhdXRoVG9rZW4sXG4gICAgICAgIGFwcENoZWNrVG9rZW5cbiAgICAgICk7XG4gICAgICB0aGlzLl9yZXF1ZXN0ID0gbXVsdGlwYXJ0UmVxdWVzdDtcbiAgICAgIG11bHRpcGFydFJlcXVlc3QuZ2V0UHJvbWlzZSgpLnRoZW4obWV0YWRhdGEgPT4ge1xuICAgICAgICB0aGlzLl9yZXF1ZXN0ID0gdW5kZWZpbmVkO1xuICAgICAgICB0aGlzLl9tZXRhZGF0YSA9IG1ldGFkYXRhO1xuICAgICAgICB0aGlzLl91cGRhdGVQcm9ncmVzcyh0aGlzLl9ibG9iLnNpemUoKSk7XG4gICAgICAgIHRoaXMuX3RyYW5zaXRpb24oSW50ZXJuYWxUYXNrU3RhdGUuU1VDQ0VTUyk7XG4gICAgICB9LCB0aGlzLl9lcnJvckhhbmRsZXIpO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBfdXBkYXRlUHJvZ3Jlc3ModHJhbnNmZXJyZWQ6IG51bWJlcik6IHZvaWQge1xuICAgIGNvbnN0IG9sZCA9IHRoaXMuX3RyYW5zZmVycmVkO1xuICAgIHRoaXMuX3RyYW5zZmVycmVkID0gdHJhbnNmZXJyZWQ7XG5cbiAgICAvLyBBIHByb2dyZXNzIHVwZGF0ZSBjYW4gbWFrZSB0aGUgXCJ0cmFuc2ZlcnJlZFwiIHZhbHVlIHNtYWxsZXIgKGUuZy4gYVxuICAgIC8vIHBhcnRpYWwgdXBsb2FkIG5vdCBjb21wbGV0ZWQgYnkgc2VydmVyLCBhZnRlciB3aGljaCB0aGUgXCJ0cmFuc2ZlcnJlZFwiXG4gICAgLy8gdmFsdWUgbWF5IHJlc2V0IHRvIHRoZSB2YWx1ZSBhdCB0aGUgYmVnaW5uaW5nIG9mIHRoZSByZXF1ZXN0KS5cbiAgICBpZiAodGhpcy5fdHJhbnNmZXJyZWQgIT09IG9sZCkge1xuICAgICAgdGhpcy5fbm90aWZ5T2JzZXJ2ZXJzKCk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBfdHJhbnNpdGlvbihzdGF0ZTogSW50ZXJuYWxUYXNrU3RhdGUpOiB2b2lkIHtcbiAgICBpZiAodGhpcy5fc3RhdGUgPT09IHN0YXRlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHN3aXRjaCAoc3RhdGUpIHtcbiAgICAgIGNhc2UgSW50ZXJuYWxUYXNrU3RhdGUuQ0FOQ0VMSU5HOlxuICAgICAgY2FzZSBJbnRlcm5hbFRhc2tTdGF0ZS5QQVVTSU5HOlxuICAgICAgICAvLyBUT0RPKGFuZHlzb3RvKTpcbiAgICAgICAgLy8gYXNzZXJ0KHRoaXMuc3RhdGVfID09PSBJbnRlcm5hbFRhc2tTdGF0ZS5SVU5OSU5HIHx8XG4gICAgICAgIC8vICAgICAgICB0aGlzLnN0YXRlXyA9PT0gSW50ZXJuYWxUYXNrU3RhdGUuUEFVU0lORyk7XG4gICAgICAgIHRoaXMuX3N0YXRlID0gc3RhdGU7XG4gICAgICAgIGlmICh0aGlzLl9yZXF1ZXN0ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICB0aGlzLl9yZXF1ZXN0LmNhbmNlbCgpO1xuICAgICAgICB9IGVsc2UgaWYgKHRoaXMucGVuZGluZ1RpbWVvdXQpIHtcbiAgICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5wZW5kaW5nVGltZW91dCk7XG4gICAgICAgICAgdGhpcy5wZW5kaW5nVGltZW91dCA9IHVuZGVmaW5lZDtcbiAgICAgICAgICB0aGlzLmNvbXBsZXRlVHJhbnNpdGlvbnNfKCk7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIEludGVybmFsVGFza1N0YXRlLlJVTk5JTkc6XG4gICAgICAgIC8vIFRPRE8oYW5keXNvdG8pOlxuICAgICAgICAvLyBhc3NlcnQodGhpcy5zdGF0ZV8gPT09IEludGVybmFsVGFza1N0YXRlLlBBVVNFRCB8fFxuICAgICAgICAvLyAgICAgICAgdGhpcy5zdGF0ZV8gPT09IEludGVybmFsVGFza1N0YXRlLlBBVVNJTkcpO1xuICAgICAgICBjb25zdCB3YXNQYXVzZWQgPSB0aGlzLl9zdGF0ZSA9PT0gSW50ZXJuYWxUYXNrU3RhdGUuUEFVU0VEO1xuICAgICAgICB0aGlzLl9zdGF0ZSA9IHN0YXRlO1xuICAgICAgICBpZiAod2FzUGF1c2VkKSB7XG4gICAgICAgICAgdGhpcy5fbm90aWZ5T2JzZXJ2ZXJzKCk7XG4gICAgICAgICAgdGhpcy5fc3RhcnQoKTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgSW50ZXJuYWxUYXNrU3RhdGUuUEFVU0VEOlxuICAgICAgICAvLyBUT0RPKGFuZHlzb3RvKTpcbiAgICAgICAgLy8gYXNzZXJ0KHRoaXMuc3RhdGVfID09PSBJbnRlcm5hbFRhc2tTdGF0ZS5QQVVTSU5HKTtcbiAgICAgICAgdGhpcy5fc3RhdGUgPSBzdGF0ZTtcbiAgICAgICAgdGhpcy5fbm90aWZ5T2JzZXJ2ZXJzKCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBJbnRlcm5hbFRhc2tTdGF0ZS5DQU5DRUxFRDpcbiAgICAgICAgLy8gVE9ETyhhbmR5c290byk6XG4gICAgICAgIC8vIGFzc2VydCh0aGlzLnN0YXRlXyA9PT0gSW50ZXJuYWxUYXNrU3RhdGUuUEFVU0VEIHx8XG4gICAgICAgIC8vICAgICAgICB0aGlzLnN0YXRlXyA9PT0gSW50ZXJuYWxUYXNrU3RhdGUuQ0FOQ0VMSU5HKTtcbiAgICAgICAgdGhpcy5fZXJyb3IgPSBjYW5jZWxlZCgpO1xuICAgICAgICB0aGlzLl9zdGF0ZSA9IHN0YXRlO1xuICAgICAgICB0aGlzLl9ub3RpZnlPYnNlcnZlcnMoKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIEludGVybmFsVGFza1N0YXRlLkVSUk9SOlxuICAgICAgICAvLyBUT0RPKGFuZHlzb3RvKTpcbiAgICAgICAgLy8gYXNzZXJ0KHRoaXMuc3RhdGVfID09PSBJbnRlcm5hbFRhc2tTdGF0ZS5SVU5OSU5HIHx8XG4gICAgICAgIC8vICAgICAgICB0aGlzLnN0YXRlXyA9PT0gSW50ZXJuYWxUYXNrU3RhdGUuUEFVU0lORyB8fFxuICAgICAgICAvLyAgICAgICAgdGhpcy5zdGF0ZV8gPT09IEludGVybmFsVGFza1N0YXRlLkNBTkNFTElORyk7XG4gICAgICAgIHRoaXMuX3N0YXRlID0gc3RhdGU7XG4gICAgICAgIHRoaXMuX25vdGlmeU9ic2VydmVycygpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgSW50ZXJuYWxUYXNrU3RhdGUuU1VDQ0VTUzpcbiAgICAgICAgLy8gVE9ETyhhbmR5c290byk6XG4gICAgICAgIC8vIGFzc2VydCh0aGlzLnN0YXRlXyA9PT0gSW50ZXJuYWxUYXNrU3RhdGUuUlVOTklORyB8fFxuICAgICAgICAvLyAgICAgICAgdGhpcy5zdGF0ZV8gPT09IEludGVybmFsVGFza1N0YXRlLlBBVVNJTkcgfHxcbiAgICAgICAgLy8gICAgICAgIHRoaXMuc3RhdGVfID09PSBJbnRlcm5hbFRhc2tTdGF0ZS5DQU5DRUxJTkcpO1xuICAgICAgICB0aGlzLl9zdGF0ZSA9IHN0YXRlO1xuICAgICAgICB0aGlzLl9ub3RpZnlPYnNlcnZlcnMoKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OiAvLyBJZ25vcmVcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGNvbXBsZXRlVHJhbnNpdGlvbnNfKCk6IHZvaWQge1xuICAgIHN3aXRjaCAodGhpcy5fc3RhdGUpIHtcbiAgICAgIGNhc2UgSW50ZXJuYWxUYXNrU3RhdGUuUEFVU0lORzpcbiAgICAgICAgdGhpcy5fdHJhbnNpdGlvbihJbnRlcm5hbFRhc2tTdGF0ZS5QQVVTRUQpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgSW50ZXJuYWxUYXNrU3RhdGUuQ0FOQ0VMSU5HOlxuICAgICAgICB0aGlzLl90cmFuc2l0aW9uKEludGVybmFsVGFza1N0YXRlLkNBTkNFTEVEKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIEludGVybmFsVGFza1N0YXRlLlJVTk5JTkc6XG4gICAgICAgIHRoaXMuX3N0YXJ0KCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgLy8gVE9ETyhhbmR5c290byk6IGFzc2VydChmYWxzZSk7XG4gICAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBBIHNuYXBzaG90IG9mIHRoZSBjdXJyZW50IHRhc2sgc3RhdGUuXG4gICAqL1xuICBnZXQgc25hcHNob3QoKTogVXBsb2FkVGFza1NuYXBzaG90IHtcbiAgICBjb25zdCBleHRlcm5hbFN0YXRlID0gdGFza1N0YXRlRnJvbUludGVybmFsVGFza1N0YXRlKHRoaXMuX3N0YXRlKTtcbiAgICByZXR1cm4ge1xuICAgICAgYnl0ZXNUcmFuc2ZlcnJlZDogdGhpcy5fdHJhbnNmZXJyZWQsXG4gICAgICB0b3RhbEJ5dGVzOiB0aGlzLl9ibG9iLnNpemUoKSxcbiAgICAgIHN0YXRlOiBleHRlcm5hbFN0YXRlLFxuICAgICAgbWV0YWRhdGE6IHRoaXMuX21ldGFkYXRhISxcbiAgICAgIHRhc2s6IHRoaXMsXG4gICAgICByZWY6IHRoaXMuX3JlZlxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogQWRkcyBhIGNhbGxiYWNrIGZvciBhbiBldmVudC5cbiAgICogQHBhcmFtIHR5cGUgLSBUaGUgdHlwZSBvZiBldmVudCB0byBsaXN0ZW4gZm9yLlxuICAgKiBAcGFyYW0gbmV4dE9yT2JzZXJ2ZXIgLVxuICAgKiAgICAgVGhlIGBuZXh0YCBmdW5jdGlvbiwgd2hpY2ggZ2V0cyBjYWxsZWQgZm9yIGVhY2ggaXRlbSBpblxuICAgKiAgICAgdGhlIGV2ZW50IHN0cmVhbSwgb3IgYW4gb2JzZXJ2ZXIgb2JqZWN0IHdpdGggc29tZSBvciBhbGwgb2YgdGhlc2UgdGhyZWVcbiAgICogICAgIHByb3BlcnRpZXMgKGBuZXh0YCwgYGVycm9yYCwgYGNvbXBsZXRlYCkuXG4gICAqIEBwYXJhbSBlcnJvciAtIEEgZnVuY3Rpb24gdGhhdCBnZXRzIGNhbGxlZCB3aXRoIGEgYFN0b3JhZ2VFcnJvcmBcbiAgICogICAgIGlmIHRoZSBldmVudCBzdHJlYW0gZW5kcyBkdWUgdG8gYW4gZXJyb3IuXG4gICAqIEBwYXJhbSBjb21wbGV0ZWQgLSBBIGZ1bmN0aW9uIHRoYXQgZ2V0cyBjYWxsZWQgaWYgdGhlXG4gICAqICAgICBldmVudCBzdHJlYW0gZW5kcyBub3JtYWxseS5cbiAgICogQHJldHVybnNcbiAgICogICAgIElmIG9ubHkgdGhlIGV2ZW50IGFyZ3VtZW50IGlzIHBhc3NlZCwgcmV0dXJucyBhIGZ1bmN0aW9uIHlvdSBjYW4gdXNlIHRvXG4gICAqICAgICBhZGQgY2FsbGJhY2tzIChzZWUgdGhlIGV4YW1wbGVzIGFib3ZlKS4gSWYgbW9yZSB0aGFuIGp1c3QgdGhlIGV2ZW50XG4gICAqICAgICBhcmd1bWVudCBpcyBwYXNzZWQsIHJldHVybnMgYSBmdW5jdGlvbiB5b3UgY2FuIGNhbGwgdG8gdW5yZWdpc3RlciB0aGVcbiAgICogICAgIGNhbGxiYWNrcy5cbiAgICovXG4gIG9uKFxuICAgIHR5cGU6IFRhc2tFdmVudCxcbiAgICBuZXh0T3JPYnNlcnZlcj86XG4gICAgICB8IFN0b3JhZ2VPYnNlcnZlcjxVcGxvYWRUYXNrU25hcHNob3Q+XG4gICAgICB8IG51bGxcbiAgICAgIHwgKChzbmFwc2hvdDogVXBsb2FkVGFza1NuYXBzaG90KSA9PiB1bmtub3duKSxcbiAgICBlcnJvcj86ICgoYTogU3RvcmFnZUVycm9yKSA9PiB1bmtub3duKSB8IG51bGwsXG4gICAgY29tcGxldGVkPzogQ29tcGxldGVGbiB8IG51bGxcbiAgKTogVW5zdWJzY3JpYmUgfCBTdWJzY3JpYmU8VXBsb2FkVGFza1NuYXBzaG90PiB7XG4gICAgLy8gTm90ZTogYHR5cGVgIGlzbid0IGJlaW5nIHVzZWQuIEl0cyB0eXBlIGlzIGFsc28gaW5jb3JyZWN0LiBUYXNrRXZlbnQgc2hvdWxkIG5vdCBiZSBhIHN0cmluZy5cbiAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBPYnNlcnZlcihcbiAgICAgIChuZXh0T3JPYnNlcnZlciBhc1xuICAgICAgICB8IFN0b3JhZ2VPYnNlcnZlckludGVybmFsPFVwbG9hZFRhc2tTbmFwc2hvdD5cbiAgICAgICAgfCBOZXh0Rm48VXBsb2FkVGFza1NuYXBzaG90PikgfHwgdW5kZWZpbmVkLFxuICAgICAgZXJyb3IgfHwgdW5kZWZpbmVkLFxuICAgICAgY29tcGxldGVkIHx8IHVuZGVmaW5lZFxuICAgICk7XG4gICAgdGhpcy5fYWRkT2JzZXJ2ZXIob2JzZXJ2ZXIpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB0aGlzLl9yZW1vdmVPYnNlcnZlcihvYnNlcnZlcik7XG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIG9iamVjdCBiZWhhdmVzIGxpa2UgYSBQcm9taXNlLCBhbmQgcmVzb2x2ZXMgd2l0aCBpdHMgc25hcHNob3QgZGF0YVxuICAgKiB3aGVuIHRoZSB1cGxvYWQgY29tcGxldGVzLlxuICAgKiBAcGFyYW0gb25GdWxmaWxsZWQgLSBUaGUgZnVsZmlsbG1lbnQgY2FsbGJhY2suIFByb21pc2UgY2hhaW5pbmcgd29ya3MgYXMgbm9ybWFsLlxuICAgKiBAcGFyYW0gb25SZWplY3RlZCAtIFRoZSByZWplY3Rpb24gY2FsbGJhY2suXG4gICAqL1xuICB0aGVuPFU+KFxuICAgIG9uRnVsZmlsbGVkPzogKCh2YWx1ZTogVXBsb2FkVGFza1NuYXBzaG90KSA9PiBVIHwgUHJvbWlzZTxVPikgfCBudWxsLFxuICAgIG9uUmVqZWN0ZWQ/OiAoKGVycm9yOiBTdG9yYWdlRXJyb3IpID0+IFUgfCBQcm9taXNlPFU+KSB8IG51bGxcbiAgKTogUHJvbWlzZTxVPiB7XG4gICAgLy8gVGhlc2UgY2FzdHMgYXJlIG5lZWRlZCBzbyB0aGF0IFR5cGVTY3JpcHQgY2FuIGluZmVyIHRoZSB0eXBlcyBvZiB0aGVcbiAgICAvLyByZXN1bHRpbmcgUHJvbWlzZS5cbiAgICByZXR1cm4gdGhpcy5fcHJvbWlzZS50aGVuPFU+KFxuICAgICAgb25GdWxmaWxsZWQgYXMgKHZhbHVlOiBVcGxvYWRUYXNrU25hcHNob3QpID0+IFUgfCBQcm9taXNlPFU+LFxuICAgICAgb25SZWplY3RlZCBhcyAoKGVycm9yOiB1bmtub3duKSA9PiBQcm9taXNlPG5ldmVyPikgfCBudWxsXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBFcXVpdmFsZW50IHRvIGNhbGxpbmcgYHRoZW4obnVsbCwgb25SZWplY3RlZClgLlxuICAgKi9cbiAgY2F0Y2g8VD4ob25SZWplY3RlZDogKHAxOiBTdG9yYWdlRXJyb3IpID0+IFQgfCBQcm9taXNlPFQ+KTogUHJvbWlzZTxUPiB7XG4gICAgcmV0dXJuIHRoaXMudGhlbihudWxsLCBvblJlamVjdGVkKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIHRoZSBnaXZlbiBvYnNlcnZlci5cbiAgICovXG4gIHByaXZhdGUgX2FkZE9ic2VydmVyKG9ic2VydmVyOiBPYnNlcnZlcjxVcGxvYWRUYXNrU25hcHNob3Q+KTogdm9pZCB7XG4gICAgdGhpcy5fb2JzZXJ2ZXJzLnB1c2gob2JzZXJ2ZXIpO1xuICAgIHRoaXMuX25vdGlmeU9ic2VydmVyKG9ic2VydmVyKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW1vdmVzIHRoZSBnaXZlbiBvYnNlcnZlci5cbiAgICovXG4gIHByaXZhdGUgX3JlbW92ZU9ic2VydmVyKG9ic2VydmVyOiBPYnNlcnZlcjxVcGxvYWRUYXNrU25hcHNob3Q+KTogdm9pZCB7XG4gICAgY29uc3QgaSA9IHRoaXMuX29ic2VydmVycy5pbmRleE9mKG9ic2VydmVyKTtcbiAgICBpZiAoaSAhPT0gLTEpIHtcbiAgICAgIHRoaXMuX29ic2VydmVycy5zcGxpY2UoaSwgMSk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBfbm90aWZ5T2JzZXJ2ZXJzKCk6IHZvaWQge1xuICAgIHRoaXMuX2ZpbmlzaFByb21pc2UoKTtcbiAgICBjb25zdCBvYnNlcnZlcnMgPSB0aGlzLl9vYnNlcnZlcnMuc2xpY2UoKTtcbiAgICBvYnNlcnZlcnMuZm9yRWFjaChvYnNlcnZlciA9PiB7XG4gICAgICB0aGlzLl9ub3RpZnlPYnNlcnZlcihvYnNlcnZlcik7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIF9maW5pc2hQcm9taXNlKCk6IHZvaWQge1xuICAgIGlmICh0aGlzLl9yZXNvbHZlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIGxldCB0cmlnZ2VyZWQgPSB0cnVlO1xuICAgICAgc3dpdGNoICh0YXNrU3RhdGVGcm9tSW50ZXJuYWxUYXNrU3RhdGUodGhpcy5fc3RhdGUpKSB7XG4gICAgICAgIGNhc2UgVGFza1N0YXRlLlNVQ0NFU1M6XG4gICAgICAgICAgZmJzQXN5bmModGhpcy5fcmVzb2x2ZS5iaW5kKG51bGwsIHRoaXMuc25hcHNob3QpKSgpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFRhc2tTdGF0ZS5DQU5DRUxFRDpcbiAgICAgICAgY2FzZSBUYXNrU3RhdGUuRVJST1I6XG4gICAgICAgICAgY29uc3QgdG9DYWxsID0gdGhpcy5fcmVqZWN0IGFzIChwMTogU3RvcmFnZUVycm9yKSA9PiB2b2lkO1xuICAgICAgICAgIGZic0FzeW5jKHRvQ2FsbC5iaW5kKG51bGwsIHRoaXMuX2Vycm9yIGFzIFN0b3JhZ2VFcnJvcikpKCk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgdHJpZ2dlcmVkID0gZmFsc2U7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBpZiAodHJpZ2dlcmVkKSB7XG4gICAgICAgIHRoaXMuX3Jlc29sdmUgPSB1bmRlZmluZWQ7XG4gICAgICAgIHRoaXMuX3JlamVjdCA9IHVuZGVmaW5lZDtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBwcml2YXRlIF9ub3RpZnlPYnNlcnZlcihvYnNlcnZlcjogT2JzZXJ2ZXI8VXBsb2FkVGFza1NuYXBzaG90Pik6IHZvaWQge1xuICAgIGNvbnN0IGV4dGVybmFsU3RhdGUgPSB0YXNrU3RhdGVGcm9tSW50ZXJuYWxUYXNrU3RhdGUodGhpcy5fc3RhdGUpO1xuICAgIHN3aXRjaCAoZXh0ZXJuYWxTdGF0ZSkge1xuICAgICAgY2FzZSBUYXNrU3RhdGUuUlVOTklORzpcbiAgICAgIGNhc2UgVGFza1N0YXRlLlBBVVNFRDpcbiAgICAgICAgaWYgKG9ic2VydmVyLm5leHQpIHtcbiAgICAgICAgICBmYnNBc3luYyhvYnNlcnZlci5uZXh0LmJpbmQob2JzZXJ2ZXIsIHRoaXMuc25hcHNob3QpKSgpO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBUYXNrU3RhdGUuU1VDQ0VTUzpcbiAgICAgICAgaWYgKG9ic2VydmVyLmNvbXBsZXRlKSB7XG4gICAgICAgICAgZmJzQXN5bmMob2JzZXJ2ZXIuY29tcGxldGUuYmluZChvYnNlcnZlcikpKCk7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFRhc2tTdGF0ZS5DQU5DRUxFRDpcbiAgICAgIGNhc2UgVGFza1N0YXRlLkVSUk9SOlxuICAgICAgICBpZiAob2JzZXJ2ZXIuZXJyb3IpIHtcbiAgICAgICAgICBmYnNBc3luYyhcbiAgICAgICAgICAgIG9ic2VydmVyLmVycm9yLmJpbmQob2JzZXJ2ZXIsIHRoaXMuX2Vycm9yIGFzIFN0b3JhZ2VFcnJvcilcbiAgICAgICAgICApKCk7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICAvLyBUT0RPKGFuZHlzb3RvKTogYXNzZXJ0KGZhbHNlKTtcbiAgICAgICAgaWYgKG9ic2VydmVyLmVycm9yKSB7XG4gICAgICAgICAgZmJzQXN5bmMoXG4gICAgICAgICAgICBvYnNlcnZlci5lcnJvci5iaW5kKG9ic2VydmVyLCB0aGlzLl9lcnJvciBhcyBTdG9yYWdlRXJyb3IpXG4gICAgICAgICAgKSgpO1xuICAgICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFJlc3VtZXMgYSBwYXVzZWQgdGFzay4gSGFzIG5vIGVmZmVjdCBvbiBhIGN1cnJlbnRseSBydW5uaW5nIG9yIGZhaWxlZCB0YXNrLlxuICAgKiBAcmV0dXJucyBUcnVlIGlmIHRoZSBvcGVyYXRpb24gdG9vayBlZmZlY3QsIGZhbHNlIGlmIGlnbm9yZWQuXG4gICAqL1xuICByZXN1bWUoKTogYm9vbGVhbiB7XG4gICAgY29uc3QgdmFsaWQgPVxuICAgICAgdGhpcy5fc3RhdGUgPT09IEludGVybmFsVGFza1N0YXRlLlBBVVNFRCB8fFxuICAgICAgdGhpcy5fc3RhdGUgPT09IEludGVybmFsVGFza1N0YXRlLlBBVVNJTkc7XG4gICAgaWYgKHZhbGlkKSB7XG4gICAgICB0aGlzLl90cmFuc2l0aW9uKEludGVybmFsVGFza1N0YXRlLlJVTk5JTkcpO1xuICAgIH1cbiAgICByZXR1cm4gdmFsaWQ7XG4gIH1cblxuICAvKipcbiAgICogUGF1c2VzIGEgY3VycmVudGx5IHJ1bm5pbmcgdGFzay4gSGFzIG5vIGVmZmVjdCBvbiBhIHBhdXNlZCBvciBmYWlsZWQgdGFzay5cbiAgICogQHJldHVybnMgVHJ1ZSBpZiB0aGUgb3BlcmF0aW9uIHRvb2sgZWZmZWN0LCBmYWxzZSBpZiBpZ25vcmVkLlxuICAgKi9cbiAgcGF1c2UoKTogYm9vbGVhbiB7XG4gICAgY29uc3QgdmFsaWQgPSB0aGlzLl9zdGF0ZSA9PT0gSW50ZXJuYWxUYXNrU3RhdGUuUlVOTklORztcbiAgICBpZiAodmFsaWQpIHtcbiAgICAgIHRoaXMuX3RyYW5zaXRpb24oSW50ZXJuYWxUYXNrU3RhdGUuUEFVU0lORyk7XG4gICAgfVxuICAgIHJldHVybiB2YWxpZDtcbiAgfVxuXG4gIC8qKlxuICAgKiBDYW5jZWxzIGEgY3VycmVudGx5IHJ1bm5pbmcgb3IgcGF1c2VkIHRhc2suIEhhcyBubyBlZmZlY3Qgb24gYSBjb21wbGV0ZSBvclxuICAgKiBmYWlsZWQgdGFzay5cbiAgICogQHJldHVybnMgVHJ1ZSBpZiB0aGUgb3BlcmF0aW9uIHRvb2sgZWZmZWN0LCBmYWxzZSBpZiBpZ25vcmVkLlxuICAgKi9cbiAgY2FuY2VsKCk6IGJvb2xlYW4ge1xuICAgIGNvbnN0IHZhbGlkID1cbiAgICAgIHRoaXMuX3N0YXRlID09PSBJbnRlcm5hbFRhc2tTdGF0ZS5SVU5OSU5HIHx8XG4gICAgICB0aGlzLl9zdGF0ZSA9PT0gSW50ZXJuYWxUYXNrU3RhdGUuUEFVU0lORztcbiAgICBpZiAodmFsaWQpIHtcbiAgICAgIHRoaXMuX3RyYW5zaXRpb24oSW50ZXJuYWxUYXNrU3RhdGUuQ0FOQ0VMSU5HKTtcbiAgICB9XG4gICAgcmV0dXJuIHZhbGlkO1xuICB9XG59XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG4vKipcbiAqIEBmaWxlb3ZlcnZpZXcgRGVmaW5lcyB0aGUgRmlyZWJhc2UgU3RvcmFnZVJlZmVyZW5jZSBjbGFzcy5cbiAqL1xuXG5pbXBvcnQgeyBGYnNCbG9iIH0gZnJvbSAnLi9pbXBsZW1lbnRhdGlvbi9ibG9iJztcbmltcG9ydCB7IExvY2F0aW9uIH0gZnJvbSAnLi9pbXBsZW1lbnRhdGlvbi9sb2NhdGlvbic7XG5pbXBvcnQgeyBnZXRNYXBwaW5ncyB9IGZyb20gJy4vaW1wbGVtZW50YXRpb24vbWV0YWRhdGEnO1xuaW1wb3J0IHsgY2hpbGQsIGxhc3RDb21wb25lbnQsIHBhcmVudCB9IGZyb20gJy4vaW1wbGVtZW50YXRpb24vcGF0aCc7XG5pbXBvcnQge1xuICBkZWxldGVPYmplY3QgYXMgcmVxdWVzdHNEZWxldGVPYmplY3QsXG4gIGdldEJ5dGVzLFxuICBnZXREb3dubG9hZFVybCBhcyByZXF1ZXN0c0dldERvd25sb2FkVXJsLFxuICBnZXRNZXRhZGF0YSBhcyByZXF1ZXN0c0dldE1ldGFkYXRhLFxuICBsaXN0IGFzIHJlcXVlc3RzTGlzdCxcbiAgbXVsdGlwYXJ0VXBsb2FkLFxuICB1cGRhdGVNZXRhZGF0YSBhcyByZXF1ZXN0c1VwZGF0ZU1ldGFkYXRhXG59IGZyb20gJy4vaW1wbGVtZW50YXRpb24vcmVxdWVzdHMnO1xuaW1wb3J0IHsgTGlzdE9wdGlvbnMsIFVwbG9hZFJlc3VsdCB9IGZyb20gJy4vcHVibGljLXR5cGVzJztcbmltcG9ydCB7IGRhdGFGcm9tU3RyaW5nLCBTdHJpbmdGb3JtYXQgfSBmcm9tICcuL2ltcGxlbWVudGF0aW9uL3N0cmluZyc7XG5pbXBvcnQgeyBNZXRhZGF0YSB9IGZyb20gJy4vbWV0YWRhdGEnO1xuaW1wb3J0IHsgRmlyZWJhc2VTdG9yYWdlSW1wbCB9IGZyb20gJy4vc2VydmljZSc7XG5pbXBvcnQgeyBMaXN0UmVzdWx0IH0gZnJvbSAnLi9saXN0JztcbmltcG9ydCB7IFVwbG9hZFRhc2sgfSBmcm9tICcuL3Rhc2snO1xuaW1wb3J0IHsgaW52YWxpZFJvb3RPcGVyYXRpb24sIG5vRG93bmxvYWRVUkwgfSBmcm9tICcuL2ltcGxlbWVudGF0aW9uL2Vycm9yJztcbmltcG9ydCB7IHZhbGlkYXRlTnVtYmVyIH0gZnJvbSAnLi9pbXBsZW1lbnRhdGlvbi90eXBlJztcbmltcG9ydCB7XG4gIG5ld0Jsb2JDb25uZWN0aW9uLFxuICBuZXdCeXRlc0Nvbm5lY3Rpb24sXG4gIG5ld1N0cmVhbUNvbm5lY3Rpb24sXG4gIG5ld1RleHRDb25uZWN0aW9uXG59IGZyb20gJy4vcGxhdGZvcm0vY29ubmVjdGlvbic7XG5pbXBvcnQgeyBSZXF1ZXN0SW5mbyB9IGZyb20gJy4vaW1wbGVtZW50YXRpb24vcmVxdWVzdGluZm8nO1xuXG4vKipcbiAqIFByb3ZpZGVzIG1ldGhvZHMgdG8gaW50ZXJhY3Qgd2l0aCBhIGJ1Y2tldCBpbiB0aGUgRmlyZWJhc2UgU3RvcmFnZSBzZXJ2aWNlLlxuICogQGludGVybmFsXG4gKiBAcGFyYW0gX2xvY2F0aW9uIC0gQW4gZmJzLmxvY2F0aW9uLCBvciB0aGUgVVJMIGF0XG4gKiAgICAgd2hpY2ggdG8gYmFzZSB0aGlzIG9iamVjdCwgaW4gb25lIG9mIHRoZSBmb2xsb3dpbmcgZm9ybXM6XG4gKiAgICAgICAgIGdzOi8vPGJ1Y2tldD4vPG9iamVjdC1wYXRoPlxuICogICAgICAgICBodHRwW3NdOi8vZmlyZWJhc2VzdG9yYWdlLmdvb2dsZWFwaXMuY29tL1xuICogICAgICAgICAgICAgICAgICAgICA8YXBpLXZlcnNpb24+L2IvPGJ1Y2tldD4vby88b2JqZWN0LXBhdGg+XG4gKiAgICAgQW55IHF1ZXJ5IG9yIGZyYWdtZW50IHN0cmluZ3Mgd2lsbCBiZSBpZ25vcmVkIGluIHRoZSBodHRwW3NdXG4gKiAgICAgZm9ybWF0LiBJZiBubyB2YWx1ZSBpcyBwYXNzZWQsIHRoZSBzdG9yYWdlIG9iamVjdCB3aWxsIHVzZSBhIFVSTCBiYXNlZCBvblxuICogICAgIHRoZSBwcm9qZWN0IElEIG9mIHRoZSBiYXNlIGZpcmViYXNlLkFwcCBpbnN0YW5jZS5cbiAqL1xuZXhwb3J0IGNsYXNzIFJlZmVyZW5jZSB7XG4gIF9sb2NhdGlvbjogTG9jYXRpb247XG5cbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSBfc2VydmljZTogRmlyZWJhc2VTdG9yYWdlSW1wbCxcbiAgICBsb2NhdGlvbjogc3RyaW5nIHwgTG9jYXRpb25cbiAgKSB7XG4gICAgaWYgKGxvY2F0aW9uIGluc3RhbmNlb2YgTG9jYXRpb24pIHtcbiAgICAgIHRoaXMuX2xvY2F0aW9uID0gbG9jYXRpb247XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuX2xvY2F0aW9uID0gTG9jYXRpb24ubWFrZUZyb21VcmwobG9jYXRpb24sIF9zZXJ2aWNlLmhvc3QpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIHRoZSBVUkwgZm9yIHRoZSBidWNrZXQgYW5kIHBhdGggdGhpcyBvYmplY3QgcmVmZXJlbmNlcyxcbiAgICogICAgIGluIHRoZSBmb3JtIGdzOi8vPGJ1Y2tldD4vPG9iamVjdC1wYXRoPlxuICAgKiBAb3ZlcnJpZGVcbiAgICovXG4gIHRvU3RyaW5nKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuICdnczovLycgKyB0aGlzLl9sb2NhdGlvbi5idWNrZXQgKyAnLycgKyB0aGlzLl9sb2NhdGlvbi5wYXRoO1xuICB9XG5cbiAgcHJvdGVjdGVkIF9uZXdSZWYoXG4gICAgc2VydmljZTogRmlyZWJhc2VTdG9yYWdlSW1wbCxcbiAgICBsb2NhdGlvbjogTG9jYXRpb25cbiAgKTogUmVmZXJlbmNlIHtcbiAgICByZXR1cm4gbmV3IFJlZmVyZW5jZShzZXJ2aWNlLCBsb2NhdGlvbik7XG4gIH1cblxuICAvKipcbiAgICogQSByZWZlcmVuY2UgdG8gdGhlIHJvb3Qgb2YgdGhpcyBvYmplY3QncyBidWNrZXQuXG4gICAqL1xuICBnZXQgcm9vdCgpOiBSZWZlcmVuY2Uge1xuICAgIGNvbnN0IGxvY2F0aW9uID0gbmV3IExvY2F0aW9uKHRoaXMuX2xvY2F0aW9uLmJ1Y2tldCwgJycpO1xuICAgIHJldHVybiB0aGlzLl9uZXdSZWYodGhpcy5fc2VydmljZSwgbG9jYXRpb24pO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSBuYW1lIG9mIHRoZSBidWNrZXQgY29udGFpbmluZyB0aGlzIHJlZmVyZW5jZSdzIG9iamVjdC5cbiAgICovXG4gIGdldCBidWNrZXQoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gdGhpcy5fbG9jYXRpb24uYnVja2V0O1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSBmdWxsIHBhdGggb2YgdGhpcyBvYmplY3QuXG4gICAqL1xuICBnZXQgZnVsbFBhdGgoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gdGhpcy5fbG9jYXRpb24ucGF0aDtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGUgc2hvcnQgbmFtZSBvZiB0aGlzIG9iamVjdCwgd2hpY2ggaXMgdGhlIGxhc3QgY29tcG9uZW50IG9mIHRoZSBmdWxsIHBhdGguXG4gICAqIEZvciBleGFtcGxlLCBpZiBmdWxsUGF0aCBpcyAnZnVsbC9wYXRoL2ltYWdlLnBuZycsIG5hbWUgaXMgJ2ltYWdlLnBuZycuXG4gICAqL1xuICBnZXQgbmFtZSgpOiBzdHJpbmcge1xuICAgIHJldHVybiBsYXN0Q29tcG9uZW50KHRoaXMuX2xvY2F0aW9uLnBhdGgpO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSBgU3RvcmFnZVNlcnZpY2VgIGluc3RhbmNlIHRoaXMgYFN0b3JhZ2VSZWZlcmVuY2VgIGlzIGFzc29jaWF0ZWQgd2l0aC5cbiAgICovXG4gIGdldCBzdG9yYWdlKCk6IEZpcmViYXNlU3RvcmFnZUltcGwge1xuICAgIHJldHVybiB0aGlzLl9zZXJ2aWNlO1xuICB9XG5cbiAgLyoqXG4gICAqIEEgYFN0b3JhZ2VSZWZlcmVuY2VgIHBvaW50aW5nIHRvIHRoZSBwYXJlbnQgbG9jYXRpb24gb2YgdGhpcyBgU3RvcmFnZVJlZmVyZW5jZWAsIG9yIG51bGwgaWZcbiAgICogdGhpcyByZWZlcmVuY2UgaXMgdGhlIHJvb3QuXG4gICAqL1xuICBnZXQgcGFyZW50KCk6IFJlZmVyZW5jZSB8IG51bGwge1xuICAgIGNvbnN0IG5ld1BhdGggPSBwYXJlbnQodGhpcy5fbG9jYXRpb24ucGF0aCk7XG4gICAgaWYgKG5ld1BhdGggPT09IG51bGwpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBjb25zdCBsb2NhdGlvbiA9IG5ldyBMb2NhdGlvbih0aGlzLl9sb2NhdGlvbi5idWNrZXQsIG5ld1BhdGgpO1xuICAgIHJldHVybiBuZXcgUmVmZXJlbmNlKHRoaXMuX3NlcnZpY2UsIGxvY2F0aW9uKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBVdGlsaXR5IGZ1bmN0aW9uIHRvIHRocm93IGFuIGVycm9yIGluIG1ldGhvZHMgdGhhdCBkbyBub3QgYWNjZXB0IGEgcm9vdCByZWZlcmVuY2UuXG4gICAqL1xuICBfdGhyb3dJZlJvb3QobmFtZTogc3RyaW5nKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuX2xvY2F0aW9uLnBhdGggPT09ICcnKSB7XG4gICAgICB0aHJvdyBpbnZhbGlkUm9vdE9wZXJhdGlvbihuYW1lKTtcbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBEb3dubG9hZCB0aGUgYnl0ZXMgYXQgdGhlIG9iamVjdCdzIGxvY2F0aW9uLlxuICogQHJldHVybnMgQSBQcm9taXNlIGNvbnRhaW5pbmcgdGhlIGRvd25sb2FkZWQgYnl0ZXMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRCeXRlc0ludGVybmFsKFxuICByZWY6IFJlZmVyZW5jZSxcbiAgbWF4RG93bmxvYWRTaXplQnl0ZXM/OiBudW1iZXJcbik6IFByb21pc2U8QXJyYXlCdWZmZXI+IHtcbiAgcmVmLl90aHJvd0lmUm9vdCgnZ2V0Qnl0ZXMnKTtcbiAgY29uc3QgcmVxdWVzdEluZm8gPSBnZXRCeXRlcyhcbiAgICByZWYuc3RvcmFnZSxcbiAgICByZWYuX2xvY2F0aW9uLFxuICAgIG1heERvd25sb2FkU2l6ZUJ5dGVzXG4gICk7XG4gIHJldHVybiByZWYuc3RvcmFnZVxuICAgIC5tYWtlUmVxdWVzdFdpdGhUb2tlbnMocmVxdWVzdEluZm8sIG5ld0J5dGVzQ29ubmVjdGlvbilcbiAgICAudGhlbihieXRlcyA9PlxuICAgICAgbWF4RG93bmxvYWRTaXplQnl0ZXMgIT09IHVuZGVmaW5lZFxuICAgICAgICA/IC8vIEdDUyBtYXkgbm90IGhvbm9yIHRoZSBSYW5nZSBoZWFkZXIgZm9yIHNtYWxsIGZpbGVzXG4gICAgICAgICAgKGJ5dGVzIGFzIEFycmF5QnVmZmVyKS5zbGljZSgwLCBtYXhEb3dubG9hZFNpemVCeXRlcylcbiAgICAgICAgOiAoYnl0ZXMgYXMgQXJyYXlCdWZmZXIpXG4gICAgKTtcbn1cblxuLyoqXG4gKiBEb3dubG9hZCB0aGUgYnl0ZXMgYXQgdGhlIG9iamVjdCdzIGxvY2F0aW9uLlxuICogQHJldHVybnMgQSBQcm9taXNlIGNvbnRhaW5pbmcgdGhlIGRvd25sb2FkZWQgYmxvYi5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldEJsb2JJbnRlcm5hbChcbiAgcmVmOiBSZWZlcmVuY2UsXG4gIG1heERvd25sb2FkU2l6ZUJ5dGVzPzogbnVtYmVyXG4pOiBQcm9taXNlPEJsb2I+IHtcbiAgcmVmLl90aHJvd0lmUm9vdCgnZ2V0QmxvYicpO1xuICBjb25zdCByZXF1ZXN0SW5mbyA9IGdldEJ5dGVzKFxuICAgIHJlZi5zdG9yYWdlLFxuICAgIHJlZi5fbG9jYXRpb24sXG4gICAgbWF4RG93bmxvYWRTaXplQnl0ZXNcbiAgKTtcbiAgcmV0dXJuIHJlZi5zdG9yYWdlXG4gICAgLm1ha2VSZXF1ZXN0V2l0aFRva2VucyhyZXF1ZXN0SW5mbywgbmV3QmxvYkNvbm5lY3Rpb24pXG4gICAgLnRoZW4oYmxvYiA9PlxuICAgICAgbWF4RG93bmxvYWRTaXplQnl0ZXMgIT09IHVuZGVmaW5lZFxuICAgICAgICA/IC8vIEdDUyBtYXkgbm90IGhvbm9yIHRoZSBSYW5nZSBoZWFkZXIgZm9yIHNtYWxsIGZpbGVzXG4gICAgICAgICAgKGJsb2IgYXMgQmxvYikuc2xpY2UoMCwgbWF4RG93bmxvYWRTaXplQnl0ZXMpXG4gICAgICAgIDogKGJsb2IgYXMgQmxvYilcbiAgICApO1xufVxuXG4vKiogU3RyZWFtIHRoZSBieXRlcyBhdCB0aGUgb2JqZWN0J3MgbG9jYXRpb24uICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0U3RyZWFtSW50ZXJuYWwoXG4gIHJlZjogUmVmZXJlbmNlLFxuICBtYXhEb3dubG9hZFNpemVCeXRlcz86IG51bWJlclxuKTogUmVhZGFibGVTdHJlYW0ge1xuICByZWYuX3Rocm93SWZSb290KCdnZXRTdHJlYW0nKTtcbiAgY29uc3QgcmVxdWVzdEluZm86IFJlcXVlc3RJbmZvPFJlYWRhYmxlU3RyZWFtLCBSZWFkYWJsZVN0cmVhbT4gPSBnZXRCeXRlcyhcbiAgICByZWYuc3RvcmFnZSxcbiAgICByZWYuX2xvY2F0aW9uLFxuICAgIG1heERvd25sb2FkU2l6ZUJ5dGVzXG4gICk7XG5cbiAgLy8gVHJhbnNmb3JtcyB0aGUgc3RyZWFtIHNvIHRoYXQgb25seSBgbWF4RG93bmxvYWRTaXplQnl0ZXNgIGJ5dGVzIGFyZSBwaXBlZCB0byB0aGUgcmVzdWx0XG4gIGNvbnN0IG5ld01heFNpemVUcmFuc2Zvcm0gPSAobjogbnVtYmVyKTogVHJhbnNmb3JtZXIgPT4ge1xuICAgIGxldCBtaXNzaW5nQnl0ZXMgPSBuO1xuICAgIHJldHVybiB7XG4gICAgICB0cmFuc2Zvcm0oY2h1bmssIGNvbnRyb2xsZXI6IFRyYW5zZm9ybVN0cmVhbURlZmF1bHRDb250cm9sbGVyKSB7XG4gICAgICAgIC8vIEdDUyBtYXkgbm90IGhvbm9yIHRoZSBSYW5nZSBoZWFkZXIgZm9yIHNtYWxsIGZpbGVzXG4gICAgICAgIGlmIChjaHVuay5sZW5ndGggPCBtaXNzaW5nQnl0ZXMpIHtcbiAgICAgICAgICBjb250cm9sbGVyLmVucXVldWUoY2h1bmspO1xuICAgICAgICAgIG1pc3NpbmdCeXRlcyAtPSBjaHVuay5sZW5ndGg7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29udHJvbGxlci5lbnF1ZXVlKGNodW5rLnNsaWNlKDAsIG1pc3NpbmdCeXRlcykpO1xuICAgICAgICAgIGNvbnRyb2xsZXIudGVybWluYXRlKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuICB9O1xuXG4gIGNvbnN0IHJlc3VsdCA9XG4gICAgbWF4RG93bmxvYWRTaXplQnl0ZXMgIT09IHVuZGVmaW5lZFxuICAgICAgPyBuZXcgVHJhbnNmb3JtU3RyZWFtKG5ld01heFNpemVUcmFuc2Zvcm0obWF4RG93bmxvYWRTaXplQnl0ZXMpKVxuICAgICAgOiBuZXcgVHJhbnNmb3JtU3RyZWFtKCk7IC8vIFRoZSBkZWZhdWx0IHRyYW5zZm9ybWVyIGZvcndhcmRzIGFsbCBjaHVua3MgdG8gaXRzIHJlYWRhYmxlIHNpZGVcblxuICByZWYuc3RvcmFnZVxuICAgIC5tYWtlUmVxdWVzdFdpdGhUb2tlbnMocmVxdWVzdEluZm8sIG5ld1N0cmVhbUNvbm5lY3Rpb24pXG4gICAgLnRoZW4ocmVhZGFibGVTdHJlYW0gPT4gcmVhZGFibGVTdHJlYW0ucGlwZVRocm91Z2gocmVzdWx0KSlcbiAgICAuY2F0Y2goZXJyID0+IHJlc3VsdC53cml0YWJsZS5hYm9ydChlcnIpKTtcblxuICByZXR1cm4gcmVzdWx0LnJlYWRhYmxlO1xufVxuXG4vKipcbiAqIFVwbG9hZHMgZGF0YSB0byB0aGlzIG9iamVjdCdzIGxvY2F0aW9uLlxuICogVGhlIHVwbG9hZCBpcyBub3QgcmVzdW1hYmxlLlxuICpcbiAqIEBwYXJhbSByZWYgLSBTdG9yYWdlUmVmZXJlbmNlIHdoZXJlIGRhdGEgc2hvdWxkIGJlIHVwbG9hZGVkLlxuICogQHBhcmFtIGRhdGEgLSBUaGUgZGF0YSB0byB1cGxvYWQuXG4gKiBAcGFyYW0gbWV0YWRhdGEgLSBNZXRhZGF0YSBmb3IgdGhlIG5ld2x5IHVwbG9hZGVkIGRhdGEuXG4gKiBAcmV0dXJucyBBIFByb21pc2UgY29udGFpbmluZyBhbiBVcGxvYWRSZXN1bHRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVwbG9hZEJ5dGVzKFxuICByZWY6IFJlZmVyZW5jZSxcbiAgZGF0YTogQmxvYiB8IFVpbnQ4QXJyYXkgfCBBcnJheUJ1ZmZlcixcbiAgbWV0YWRhdGE/OiBNZXRhZGF0YVxuKTogUHJvbWlzZTxVcGxvYWRSZXN1bHQ+IHtcbiAgcmVmLl90aHJvd0lmUm9vdCgndXBsb2FkQnl0ZXMnKTtcbiAgY29uc3QgcmVxdWVzdEluZm8gPSBtdWx0aXBhcnRVcGxvYWQoXG4gICAgcmVmLnN0b3JhZ2UsXG4gICAgcmVmLl9sb2NhdGlvbixcbiAgICBnZXRNYXBwaW5ncygpLFxuICAgIG5ldyBGYnNCbG9iKGRhdGEsIHRydWUpLFxuICAgIG1ldGFkYXRhXG4gICk7XG4gIHJldHVybiByZWYuc3RvcmFnZVxuICAgIC5tYWtlUmVxdWVzdFdpdGhUb2tlbnMocmVxdWVzdEluZm8sIG5ld1RleHRDb25uZWN0aW9uKVxuICAgIC50aGVuKGZpbmFsTWV0YWRhdGEgPT4ge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbWV0YWRhdGE6IGZpbmFsTWV0YWRhdGEsXG4gICAgICAgIHJlZlxuICAgICAgfTtcbiAgICB9KTtcbn1cblxuLyoqXG4gKiBVcGxvYWRzIGRhdGEgdG8gdGhpcyBvYmplY3QncyBsb2NhdGlvbi5cbiAqIFRoZSB1cGxvYWQgY2FuIGJlIHBhdXNlZCBhbmQgcmVzdW1lZCwgYW5kIGV4cG9zZXMgcHJvZ3Jlc3MgdXBkYXRlcy5cbiAqIEBwdWJsaWNcbiAqIEBwYXJhbSByZWYgLSBTdG9yYWdlUmVmZXJlbmNlIHdoZXJlIGRhdGEgc2hvdWxkIGJlIHVwbG9hZGVkLlxuICogQHBhcmFtIGRhdGEgLSBUaGUgZGF0YSB0byB1cGxvYWQuXG4gKiBAcGFyYW0gbWV0YWRhdGEgLSBNZXRhZGF0YSBmb3IgdGhlIG5ld2x5IHVwbG9hZGVkIGRhdGEuXG4gKiBAcmV0dXJucyBBbiBVcGxvYWRUYXNrXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1cGxvYWRCeXRlc1Jlc3VtYWJsZShcbiAgcmVmOiBSZWZlcmVuY2UsXG4gIGRhdGE6IEJsb2IgfCBVaW50OEFycmF5IHwgQXJyYXlCdWZmZXIsXG4gIG1ldGFkYXRhPzogTWV0YWRhdGFcbik6IFVwbG9hZFRhc2sge1xuICByZWYuX3Rocm93SWZSb290KCd1cGxvYWRCeXRlc1Jlc3VtYWJsZScpO1xuICByZXR1cm4gbmV3IFVwbG9hZFRhc2socmVmLCBuZXcgRmJzQmxvYihkYXRhKSwgbWV0YWRhdGEpO1xufVxuXG4vKipcbiAqIFVwbG9hZHMgYSBzdHJpbmcgdG8gdGhpcyBvYmplY3QncyBsb2NhdGlvbi5cbiAqIFRoZSB1cGxvYWQgaXMgbm90IHJlc3VtYWJsZS5cbiAqIEBwdWJsaWNcbiAqIEBwYXJhbSByZWYgLSBTdG9yYWdlUmVmZXJlbmNlIHdoZXJlIHN0cmluZyBzaG91bGQgYmUgdXBsb2FkZWQuXG4gKiBAcGFyYW0gdmFsdWUgLSBUaGUgc3RyaW5nIHRvIHVwbG9hZC5cbiAqIEBwYXJhbSBmb3JtYXQgLSBUaGUgZm9ybWF0IG9mIHRoZSBzdHJpbmcgdG8gdXBsb2FkLlxuICogQHBhcmFtIG1ldGFkYXRhIC0gTWV0YWRhdGEgZm9yIHRoZSBuZXdseSB1cGxvYWRlZCBzdHJpbmcuXG4gKiBAcmV0dXJucyBBIFByb21pc2UgY29udGFpbmluZyBhbiBVcGxvYWRSZXN1bHRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVwbG9hZFN0cmluZyhcbiAgcmVmOiBSZWZlcmVuY2UsXG4gIHZhbHVlOiBzdHJpbmcsXG4gIGZvcm1hdDogU3RyaW5nRm9ybWF0ID0gU3RyaW5nRm9ybWF0LlJBVyxcbiAgbWV0YWRhdGE/OiBNZXRhZGF0YVxuKTogUHJvbWlzZTxVcGxvYWRSZXN1bHQ+IHtcbiAgcmVmLl90aHJvd0lmUm9vdCgndXBsb2FkU3RyaW5nJyk7XG4gIGNvbnN0IGRhdGEgPSBkYXRhRnJvbVN0cmluZyhmb3JtYXQsIHZhbHVlKTtcbiAgY29uc3QgbWV0YWRhdGFDbG9uZSA9IHsgLi4ubWV0YWRhdGEgfSBhcyBNZXRhZGF0YTtcbiAgaWYgKG1ldGFkYXRhQ2xvbmVbJ2NvbnRlbnRUeXBlJ10gPT0gbnVsbCAmJiBkYXRhLmNvbnRlbnRUeXBlICE9IG51bGwpIHtcbiAgICBtZXRhZGF0YUNsb25lWydjb250ZW50VHlwZSddID0gZGF0YS5jb250ZW50VHlwZSE7XG4gIH1cbiAgcmV0dXJuIHVwbG9hZEJ5dGVzKHJlZiwgZGF0YS5kYXRhLCBtZXRhZGF0YUNsb25lKTtcbn1cblxuLyoqXG4gKiBMaXN0IGFsbCBpdGVtcyAoZmlsZXMpIGFuZCBwcmVmaXhlcyAoZm9sZGVycykgdW5kZXIgdGhpcyBzdG9yYWdlIHJlZmVyZW5jZS5cbiAqXG4gKiBUaGlzIGlzIGEgaGVscGVyIG1ldGhvZCBmb3IgY2FsbGluZyBsaXN0KCkgcmVwZWF0ZWRseSB1bnRpbCB0aGVyZSBhcmVcbiAqIG5vIG1vcmUgcmVzdWx0cy4gVGhlIGRlZmF1bHQgcGFnaW5hdGlvbiBzaXplIGlzIDEwMDAuXG4gKlxuICogTm90ZTogVGhlIHJlc3VsdHMgbWF5IG5vdCBiZSBjb25zaXN0ZW50IGlmIG9iamVjdHMgYXJlIGNoYW5nZWQgd2hpbGUgdGhpc1xuICogb3BlcmF0aW9uIGlzIHJ1bm5pbmcuXG4gKlxuICogV2FybmluZzogbGlzdEFsbCBtYXkgcG90ZW50aWFsbHkgY29uc3VtZSB0b28gbWFueSByZXNvdXJjZXMgaWYgdGhlcmUgYXJlXG4gKiB0b28gbWFueSByZXN1bHRzLlxuICogQHB1YmxpY1xuICogQHBhcmFtIHJlZiAtIFN0b3JhZ2VSZWZlcmVuY2UgdG8gZ2V0IGxpc3QgZnJvbS5cbiAqXG4gKiBAcmV0dXJucyBBIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIGFsbCB0aGUgaXRlbXMgYW5kIHByZWZpeGVzIHVuZGVyXG4gKiAgICAgIHRoZSBjdXJyZW50IHN0b3JhZ2UgcmVmZXJlbmNlLiBgcHJlZml4ZXNgIGNvbnRhaW5zIHJlZmVyZW5jZXMgdG9cbiAqICAgICAgc3ViLWRpcmVjdG9yaWVzIGFuZCBgaXRlbXNgIGNvbnRhaW5zIHJlZmVyZW5jZXMgdG8gb2JqZWN0cyBpbiB0aGlzXG4gKiAgICAgIGZvbGRlci4gYG5leHRQYWdlVG9rZW5gIGlzIG5ldmVyIHJldHVybmVkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbGlzdEFsbChyZWY6IFJlZmVyZW5jZSk6IFByb21pc2U8TGlzdFJlc3VsdD4ge1xuICBjb25zdCBhY2N1bXVsYXRvcjogTGlzdFJlc3VsdCA9IHtcbiAgICBwcmVmaXhlczogW10sXG4gICAgaXRlbXM6IFtdXG4gIH07XG4gIHJldHVybiBsaXN0QWxsSGVscGVyKHJlZiwgYWNjdW11bGF0b3IpLnRoZW4oKCkgPT4gYWNjdW11bGF0b3IpO1xufVxuXG4vKipcbiAqIFNlcGFyYXRlZCBmcm9tIGxpc3RBbGwgYmVjYXVzZSBhc3luYyBmdW5jdGlvbnMgY2FuJ3QgdXNlIFwiYXJndW1lbnRzXCIuXG4gKiBAcGFyYW0gcmVmXG4gKiBAcGFyYW0gYWNjdW11bGF0b3JcbiAqIEBwYXJhbSBwYWdlVG9rZW5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gbGlzdEFsbEhlbHBlcihcbiAgcmVmOiBSZWZlcmVuY2UsXG4gIGFjY3VtdWxhdG9yOiBMaXN0UmVzdWx0LFxuICBwYWdlVG9rZW4/OiBzdHJpbmdcbik6IFByb21pc2U8dm9pZD4ge1xuICBjb25zdCBvcHQ6IExpc3RPcHRpb25zID0ge1xuICAgIC8vIG1heFJlc3VsdHMgaXMgMTAwMCBieSBkZWZhdWx0LlxuICAgIHBhZ2VUb2tlblxuICB9O1xuICBjb25zdCBuZXh0UGFnZSA9IGF3YWl0IGxpc3QocmVmLCBvcHQpO1xuICBhY2N1bXVsYXRvci5wcmVmaXhlcy5wdXNoKC4uLm5leHRQYWdlLnByZWZpeGVzKTtcbiAgYWNjdW11bGF0b3IuaXRlbXMucHVzaCguLi5uZXh0UGFnZS5pdGVtcyk7XG4gIGlmIChuZXh0UGFnZS5uZXh0UGFnZVRva2VuICE9IG51bGwpIHtcbiAgICBhd2FpdCBsaXN0QWxsSGVscGVyKHJlZiwgYWNjdW11bGF0b3IsIG5leHRQYWdlLm5leHRQYWdlVG9rZW4pO1xuICB9XG59XG5cbi8qKlxuICogTGlzdCBpdGVtcyAoZmlsZXMpIGFuZCBwcmVmaXhlcyAoZm9sZGVycykgdW5kZXIgdGhpcyBzdG9yYWdlIHJlZmVyZW5jZS5cbiAqXG4gKiBMaXN0IEFQSSBpcyBvbmx5IGF2YWlsYWJsZSBmb3IgRmlyZWJhc2UgUnVsZXMgVmVyc2lvbiAyLlxuICpcbiAqIEdDUyBpcyBhIGtleS1ibG9iIHN0b3JlLiBGaXJlYmFzZSBTdG9yYWdlIGltcG9zZXMgdGhlIHNlbWFudGljIG9mICcvJ1xuICogZGVsaW1pdGVkIGZvbGRlciBzdHJ1Y3R1cmUuXG4gKiBSZWZlciB0byBHQ1MncyBMaXN0IEFQSSBpZiB5b3Ugd2FudCB0byBsZWFybiBtb3JlLlxuICpcbiAqIFRvIGFkaGVyZSB0byBGaXJlYmFzZSBSdWxlcydzIFNlbWFudGljcywgRmlyZWJhc2UgU3RvcmFnZSBkb2VzIG5vdFxuICogc3VwcG9ydCBvYmplY3RzIHdob3NlIHBhdGhzIGVuZCB3aXRoIFwiL1wiIG9yIGNvbnRhaW4gdHdvIGNvbnNlY3V0aXZlXG4gKiBcIi9cInMuIEZpcmViYXNlIFN0b3JhZ2UgTGlzdCBBUEkgd2lsbCBmaWx0ZXIgdGhlc2UgdW5zdXBwb3J0ZWQgb2JqZWN0cy5cbiAqIGxpc3QoKSBtYXkgZmFpbCBpZiB0aGVyZSBhcmUgdG9vIG1hbnkgdW5zdXBwb3J0ZWQgb2JqZWN0cyBpbiB0aGUgYnVja2V0LlxuICogQHB1YmxpY1xuICpcbiAqIEBwYXJhbSByZWYgLSBTdG9yYWdlUmVmZXJlbmNlIHRvIGdldCBsaXN0IGZyb20uXG4gKiBAcGFyYW0gb3B0aW9ucyAtIFNlZSBMaXN0T3B0aW9ucyBmb3IgZGV0YWlscy5cbiAqIEByZXR1cm5zIEEgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIGl0ZW1zIGFuZCBwcmVmaXhlcy5cbiAqICAgICAgYHByZWZpeGVzYCBjb250YWlucyByZWZlcmVuY2VzIHRvIHN1Yi1mb2xkZXJzIGFuZCBgaXRlbXNgXG4gKiAgICAgIGNvbnRhaW5zIHJlZmVyZW5jZXMgdG8gb2JqZWN0cyBpbiB0aGlzIGZvbGRlci4gYG5leHRQYWdlVG9rZW5gXG4gKiAgICAgIGNhbiBiZSB1c2VkIHRvIGdldCB0aGUgcmVzdCBvZiB0aGUgcmVzdWx0cy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxpc3QoXG4gIHJlZjogUmVmZXJlbmNlLFxuICBvcHRpb25zPzogTGlzdE9wdGlvbnMgfCBudWxsXG4pOiBQcm9taXNlPExpc3RSZXN1bHQ+IHtcbiAgaWYgKG9wdGlvbnMgIT0gbnVsbCkge1xuICAgIGlmICh0eXBlb2Ygb3B0aW9ucy5tYXhSZXN1bHRzID09PSAnbnVtYmVyJykge1xuICAgICAgdmFsaWRhdGVOdW1iZXIoXG4gICAgICAgICdvcHRpb25zLm1heFJlc3VsdHMnLFxuICAgICAgICAvKiBtaW5WYWx1ZT0gKi8gMSxcbiAgICAgICAgLyogbWF4VmFsdWU9ICovIDEwMDAsXG4gICAgICAgIG9wdGlvbnMubWF4UmVzdWx0c1xuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgY29uc3Qgb3AgPSBvcHRpb25zIHx8IHt9O1xuICBjb25zdCByZXF1ZXN0SW5mbyA9IHJlcXVlc3RzTGlzdChcbiAgICByZWYuc3RvcmFnZSxcbiAgICByZWYuX2xvY2F0aW9uLFxuICAgIC8qZGVsaW1pdGVyPSAqLyAnLycsXG4gICAgb3AucGFnZVRva2VuLFxuICAgIG9wLm1heFJlc3VsdHNcbiAgKTtcbiAgcmV0dXJuIHJlZi5zdG9yYWdlLm1ha2VSZXF1ZXN0V2l0aFRva2VucyhyZXF1ZXN0SW5mbywgbmV3VGV4dENvbm5lY3Rpb24pO1xufVxuXG4vKipcbiAqIEEgYFByb21pc2VgIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgbWV0YWRhdGEgZm9yIHRoaXMgb2JqZWN0LiBJZiB0aGlzXG4gKiBvYmplY3QgZG9lc24ndCBleGlzdCBvciBtZXRhZGF0YSBjYW5ub3QgYmUgcmV0cmlldmVkLCB0aGUgcHJvbWlzZSBpc1xuICogcmVqZWN0ZWQuXG4gKiBAcHVibGljXG4gKiBAcGFyYW0gcmVmIC0gU3RvcmFnZVJlZmVyZW5jZSB0byBnZXQgbWV0YWRhdGEgZnJvbS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldE1ldGFkYXRhKHJlZjogUmVmZXJlbmNlKTogUHJvbWlzZTxNZXRhZGF0YT4ge1xuICByZWYuX3Rocm93SWZSb290KCdnZXRNZXRhZGF0YScpO1xuICBjb25zdCByZXF1ZXN0SW5mbyA9IHJlcXVlc3RzR2V0TWV0YWRhdGEoXG4gICAgcmVmLnN0b3JhZ2UsXG4gICAgcmVmLl9sb2NhdGlvbixcbiAgICBnZXRNYXBwaW5ncygpXG4gICk7XG4gIHJldHVybiByZWYuc3RvcmFnZS5tYWtlUmVxdWVzdFdpdGhUb2tlbnMocmVxdWVzdEluZm8sIG5ld1RleHRDb25uZWN0aW9uKTtcbn1cblxuLyoqXG4gKiBVcGRhdGVzIHRoZSBtZXRhZGF0YSBmb3IgdGhpcyBvYmplY3QuXG4gKiBAcHVibGljXG4gKiBAcGFyYW0gcmVmIC0gU3RvcmFnZVJlZmVyZW5jZSB0byB1cGRhdGUgbWV0YWRhdGEgZm9yLlxuICogQHBhcmFtIG1ldGFkYXRhIC0gVGhlIG5ldyBtZXRhZGF0YSBmb3IgdGhlIG9iamVjdC5cbiAqICAgICBPbmx5IHZhbHVlcyB0aGF0IGhhdmUgYmVlbiBleHBsaWNpdGx5IHNldCB3aWxsIGJlIGNoYW5nZWQuIEV4cGxpY2l0bHlcbiAqICAgICBzZXR0aW5nIGEgdmFsdWUgdG8gbnVsbCB3aWxsIHJlbW92ZSB0aGUgbWV0YWRhdGEuXG4gKiBAcmV0dXJucyBBIGBQcm9taXNlYCB0aGF0IHJlc29sdmVzXG4gKiAgICAgd2l0aCB0aGUgbmV3IG1ldGFkYXRhIGZvciB0aGlzIG9iamVjdC5cbiAqICAgICBTZWUgYGZpcmViYXNlU3RvcmFnZS5SZWZlcmVuY2UucHJvdG90eXBlLmdldE1ldGFkYXRhYFxuICovXG5leHBvcnQgZnVuY3Rpb24gdXBkYXRlTWV0YWRhdGEoXG4gIHJlZjogUmVmZXJlbmNlLFxuICBtZXRhZGF0YTogUGFydGlhbDxNZXRhZGF0YT5cbik6IFByb21pc2U8TWV0YWRhdGE+IHtcbiAgcmVmLl90aHJvd0lmUm9vdCgndXBkYXRlTWV0YWRhdGEnKTtcbiAgY29uc3QgcmVxdWVzdEluZm8gPSByZXF1ZXN0c1VwZGF0ZU1ldGFkYXRhKFxuICAgIHJlZi5zdG9yYWdlLFxuICAgIHJlZi5fbG9jYXRpb24sXG4gICAgbWV0YWRhdGEsXG4gICAgZ2V0TWFwcGluZ3MoKVxuICApO1xuICByZXR1cm4gcmVmLnN0b3JhZ2UubWFrZVJlcXVlc3RXaXRoVG9rZW5zKHJlcXVlc3RJbmZvLCBuZXdUZXh0Q29ubmVjdGlvbik7XG59XG5cbi8qKlxuICogUmV0dXJucyB0aGUgZG93bmxvYWQgVVJMIGZvciB0aGUgZ2l2ZW4gUmVmZXJlbmNlLlxuICogQHB1YmxpY1xuICogQHJldHVybnMgQSBgUHJvbWlzZWAgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSBkb3dubG9hZFxuICogICAgIFVSTCBmb3IgdGhpcyBvYmplY3QuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREb3dubG9hZFVSTChyZWY6IFJlZmVyZW5jZSk6IFByb21pc2U8c3RyaW5nPiB7XG4gIHJlZi5fdGhyb3dJZlJvb3QoJ2dldERvd25sb2FkVVJMJyk7XG4gIGNvbnN0IHJlcXVlc3RJbmZvID0gcmVxdWVzdHNHZXREb3dubG9hZFVybChcbiAgICByZWYuc3RvcmFnZSxcbiAgICByZWYuX2xvY2F0aW9uLFxuICAgIGdldE1hcHBpbmdzKClcbiAgKTtcbiAgcmV0dXJuIHJlZi5zdG9yYWdlXG4gICAgLm1ha2VSZXF1ZXN0V2l0aFRva2VucyhyZXF1ZXN0SW5mbywgbmV3VGV4dENvbm5lY3Rpb24pXG4gICAgLnRoZW4odXJsID0+IHtcbiAgICAgIGlmICh1cmwgPT09IG51bGwpIHtcbiAgICAgICAgdGhyb3cgbm9Eb3dubG9hZFVSTCgpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHVybDtcbiAgICB9KTtcbn1cblxuLyoqXG4gKiBEZWxldGVzIHRoZSBvYmplY3QgYXQgdGhpcyBsb2NhdGlvbi5cbiAqIEBwdWJsaWNcbiAqIEBwYXJhbSByZWYgLSBTdG9yYWdlUmVmZXJlbmNlIGZvciBvYmplY3QgdG8gZGVsZXRlLlxuICogQHJldHVybnMgQSBgUHJvbWlzZWAgdGhhdCByZXNvbHZlcyBpZiB0aGUgZGVsZXRpb24gc3VjY2VlZHMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZWxldGVPYmplY3QocmVmOiBSZWZlcmVuY2UpOiBQcm9taXNlPHZvaWQ+IHtcbiAgcmVmLl90aHJvd0lmUm9vdCgnZGVsZXRlT2JqZWN0Jyk7XG4gIGNvbnN0IHJlcXVlc3RJbmZvID0gcmVxdWVzdHNEZWxldGVPYmplY3QocmVmLnN0b3JhZ2UsIHJlZi5fbG9jYXRpb24pO1xuICByZXR1cm4gcmVmLnN0b3JhZ2UubWFrZVJlcXVlc3RXaXRoVG9rZW5zKHJlcXVlc3RJbmZvLCBuZXdUZXh0Q29ubmVjdGlvbik7XG59XG5cbi8qKlxuICogUmV0dXJucyByZWZlcmVuY2UgZm9yIG9iamVjdCBvYnRhaW5lZCBieSBhcHBlbmRpbmcgYGNoaWxkUGF0aGAgdG8gYHJlZmAuXG4gKlxuICogQHBhcmFtIHJlZiAtIFN0b3JhZ2VSZWZlcmVuY2UgdG8gZ2V0IGNoaWxkIG9mLlxuICogQHBhcmFtIGNoaWxkUGF0aCAtIENoaWxkIHBhdGggZnJvbSBwcm92aWRlZCByZWYuXG4gKiBAcmV0dXJucyBBIHJlZmVyZW5jZSB0byB0aGUgb2JqZWN0IG9idGFpbmVkIGJ5XG4gKiBhcHBlbmRpbmcgY2hpbGRQYXRoLCByZW1vdmluZyBhbnkgZHVwbGljYXRlLCBiZWdpbm5pbmcsIG9yIHRyYWlsaW5nXG4gKiBzbGFzaGVzLlxuICpcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIF9nZXRDaGlsZChyZWY6IFJlZmVyZW5jZSwgY2hpbGRQYXRoOiBzdHJpbmcpOiBSZWZlcmVuY2Uge1xuICBjb25zdCBuZXdQYXRoID0gY2hpbGQocmVmLl9sb2NhdGlvbi5wYXRoLCBjaGlsZFBhdGgpO1xuICBjb25zdCBsb2NhdGlvbiA9IG5ldyBMb2NhdGlvbihyZWYuX2xvY2F0aW9uLmJ1Y2tldCwgbmV3UGF0aCk7XG4gIHJldHVybiBuZXcgUmVmZXJlbmNlKHJlZi5zdG9yYWdlLCBsb2NhdGlvbik7XG59XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAxNyBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG5pbXBvcnQgeyBMb2NhdGlvbiB9IGZyb20gJy4vaW1wbGVtZW50YXRpb24vbG9jYXRpb24nO1xuaW1wb3J0IHsgRmFpbFJlcXVlc3QgfSBmcm9tICcuL2ltcGxlbWVudGF0aW9uL2ZhaWxyZXF1ZXN0JztcbmltcG9ydCB7IFJlcXVlc3QsIG1ha2VSZXF1ZXN0IH0gZnJvbSAnLi9pbXBsZW1lbnRhdGlvbi9yZXF1ZXN0JztcbmltcG9ydCB7IFJlcXVlc3RJbmZvIH0gZnJvbSAnLi9pbXBsZW1lbnRhdGlvbi9yZXF1ZXN0aW5mbyc7XG5pbXBvcnQgeyBSZWZlcmVuY2UsIF9nZXRDaGlsZCB9IGZyb20gJy4vcmVmZXJlbmNlJztcbmltcG9ydCB7IFByb3ZpZGVyIH0gZnJvbSAnQGZpcmViYXNlL2NvbXBvbmVudCc7XG5pbXBvcnQgeyBGaXJlYmFzZUF1dGhJbnRlcm5hbE5hbWUgfSBmcm9tICdAZmlyZWJhc2UvYXV0aC1pbnRlcm9wLXR5cGVzJztcbmltcG9ydCB7IEFwcENoZWNrSW50ZXJuYWxDb21wb25lbnROYW1lIH0gZnJvbSAnQGZpcmViYXNlL2FwcC1jaGVjay1pbnRlcm9wLXR5cGVzJztcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBpbXBvcnQvbm8tZXh0cmFuZW91cy1kZXBlbmRlbmNpZXNcbmltcG9ydCB7XG4gIEZpcmViYXNlQXBwLFxuICBGaXJlYmFzZU9wdGlvbnMsXG4gIF9pc0ZpcmViYXNlU2VydmVyQXBwXG59IGZyb20gJ0BmaXJlYmFzZS9hcHAnO1xuaW1wb3J0IHtcbiAgQ09ORklHX1NUT1JBR0VfQlVDS0VUX0tFWSxcbiAgREVGQVVMVF9IT1NULFxuICBERUZBVUxUX01BWF9PUEVSQVRJT05fUkVUUllfVElNRSxcbiAgREVGQVVMVF9NQVhfVVBMT0FEX1JFVFJZX1RJTUVcbn0gZnJvbSAnLi9pbXBsZW1lbnRhdGlvbi9jb25zdGFudHMnO1xuaW1wb3J0IHtcbiAgaW52YWxpZEFyZ3VtZW50LFxuICBhcHBEZWxldGVkLFxuICBub0RlZmF1bHRCdWNrZXRcbn0gZnJvbSAnLi9pbXBsZW1lbnRhdGlvbi9lcnJvcic7XG5pbXBvcnQgeyB2YWxpZGF0ZU51bWJlciB9IGZyb20gJy4vaW1wbGVtZW50YXRpb24vdHlwZSc7XG5pbXBvcnQgeyBGaXJlYmFzZVN0b3JhZ2UgfSBmcm9tICcuL3B1YmxpYy10eXBlcyc7XG5pbXBvcnQge1xuICBjcmVhdGVNb2NrVXNlclRva2VuLFxuICBFbXVsYXRvck1vY2tUb2tlbk9wdGlvbnMsXG4gIGlzQ2xvdWRXb3Jrc3RhdGlvbixcbiAgcGluZ1NlcnZlclxufSBmcm9tICdAZmlyZWJhc2UvdXRpbCc7XG5pbXBvcnQgeyBDb25uZWN0aW9uLCBDb25uZWN0aW9uVHlwZSB9IGZyb20gJy4vaW1wbGVtZW50YXRpb24vY29ubmVjdGlvbic7XG5cbmV4cG9ydCBmdW5jdGlvbiBpc1VybChwYXRoPzogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHJldHVybiAvXltBLVphLXpdKzpcXC9cXC8vLnRlc3QocGF0aCBhcyBzdHJpbmcpO1xufVxuXG4vKipcbiAqIFJldHVybnMgYSBmaXJlYmFzZVN0b3JhZ2UuUmVmZXJlbmNlIGZvciB0aGUgZ2l2ZW4gdXJsLlxuICovXG5mdW5jdGlvbiByZWZGcm9tVVJMKHNlcnZpY2U6IEZpcmViYXNlU3RvcmFnZUltcGwsIHVybDogc3RyaW5nKTogUmVmZXJlbmNlIHtcbiAgcmV0dXJuIG5ldyBSZWZlcmVuY2Uoc2VydmljZSwgdXJsKTtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgZmlyZWJhc2VTdG9yYWdlLlJlZmVyZW5jZSBmb3IgdGhlIGdpdmVuIHBhdGggaW4gdGhlIGRlZmF1bHRcbiAqIGJ1Y2tldC5cbiAqL1xuZnVuY3Rpb24gcmVmRnJvbVBhdGgoXG4gIHJlZjogRmlyZWJhc2VTdG9yYWdlSW1wbCB8IFJlZmVyZW5jZSxcbiAgcGF0aD86IHN0cmluZ1xuKTogUmVmZXJlbmNlIHtcbiAgaWYgKHJlZiBpbnN0YW5jZW9mIEZpcmViYXNlU3RvcmFnZUltcGwpIHtcbiAgICBjb25zdCBzZXJ2aWNlID0gcmVmO1xuICAgIGlmIChzZXJ2aWNlLl9idWNrZXQgPT0gbnVsbCkge1xuICAgICAgdGhyb3cgbm9EZWZhdWx0QnVja2V0KCk7XG4gICAgfVxuICAgIGNvbnN0IHJlZmVyZW5jZSA9IG5ldyBSZWZlcmVuY2Uoc2VydmljZSwgc2VydmljZS5fYnVja2V0ISk7XG4gICAgaWYgKHBhdGggIT0gbnVsbCkge1xuICAgICAgcmV0dXJuIHJlZkZyb21QYXRoKHJlZmVyZW5jZSwgcGF0aCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiByZWZlcmVuY2U7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIC8vIHJlZiBpcyBhIFJlZmVyZW5jZVxuICAgIGlmIChwYXRoICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybiBfZ2V0Q2hpbGQocmVmLCBwYXRoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHJlZjtcbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgc3RvcmFnZSBSZWZlcmVuY2UgZm9yIHRoZSBnaXZlbiB1cmwuXG4gKiBAcGFyYW0gc3RvcmFnZSAtIGBTdG9yYWdlYCBpbnN0YW5jZS5cbiAqIEBwYXJhbSB1cmwgLSBVUkwuIElmIGVtcHR5LCByZXR1cm5zIHJvb3QgcmVmZXJlbmNlLlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgZnVuY3Rpb24gcmVmKHN0b3JhZ2U6IEZpcmViYXNlU3RvcmFnZUltcGwsIHVybD86IHN0cmluZyk6IFJlZmVyZW5jZTtcbi8qKlxuICogUmV0dXJucyBhIHN0b3JhZ2UgUmVmZXJlbmNlIGZvciB0aGUgZ2l2ZW4gcGF0aCBpbiB0aGVcbiAqIGRlZmF1bHQgYnVja2V0LlxuICogQHBhcmFtIHN0b3JhZ2VPclJlZiAtIGBTdG9yYWdlYCBzZXJ2aWNlIG9yIHN0b3JhZ2UgYFJlZmVyZW5jZWAuXG4gKiBAcGFyYW0gcGF0aE9yVXJsU3RvcmFnZSAtIHBhdGguIElmIGVtcHR5LCByZXR1cm5zIHJvb3QgcmVmZXJlbmNlIChpZiBTdG9yYWdlXG4gKiBpbnN0YW5jZSBwcm92aWRlZCkgb3IgcmV0dXJucyBzYW1lIHJlZmVyZW5jZSAoaWYgUmVmZXJlbmNlIHByb3ZpZGVkKS5cbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlZihcbiAgc3RvcmFnZU9yUmVmOiBGaXJlYmFzZVN0b3JhZ2VJbXBsIHwgUmVmZXJlbmNlLFxuICBwYXRoPzogc3RyaW5nXG4pOiBSZWZlcmVuY2U7XG5leHBvcnQgZnVuY3Rpb24gcmVmKFxuICBzZXJ2aWNlT3JSZWY6IEZpcmViYXNlU3RvcmFnZUltcGwgfCBSZWZlcmVuY2UsXG4gIHBhdGhPclVybD86IHN0cmluZ1xuKTogUmVmZXJlbmNlIHwgbnVsbCB7XG4gIGlmIChwYXRoT3JVcmwgJiYgaXNVcmwocGF0aE9yVXJsKSkge1xuICAgIGlmIChzZXJ2aWNlT3JSZWYgaW5zdGFuY2VvZiBGaXJlYmFzZVN0b3JhZ2VJbXBsKSB7XG4gICAgICByZXR1cm4gcmVmRnJvbVVSTChzZXJ2aWNlT3JSZWYsIHBhdGhPclVybCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IGludmFsaWRBcmd1bWVudChcbiAgICAgICAgJ1RvIHVzZSByZWYoc2VydmljZSwgdXJsKSwgdGhlIGZpcnN0IGFyZ3VtZW50IG11c3QgYmUgYSBTdG9yYWdlIGluc3RhbmNlLidcbiAgICAgICk7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHJldHVybiByZWZGcm9tUGF0aChzZXJ2aWNlT3JSZWYsIHBhdGhPclVybCk7XG4gIH1cbn1cblxuZnVuY3Rpb24gZXh0cmFjdEJ1Y2tldChcbiAgaG9zdDogc3RyaW5nLFxuICBjb25maWc/OiBGaXJlYmFzZU9wdGlvbnNcbik6IExvY2F0aW9uIHwgbnVsbCB7XG4gIGNvbnN0IGJ1Y2tldFN0cmluZyA9IGNvbmZpZz8uW0NPTkZJR19TVE9SQUdFX0JVQ0tFVF9LRVldO1xuICBpZiAoYnVja2V0U3RyaW5nID09IG51bGwpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICByZXR1cm4gTG9jYXRpb24ubWFrZUZyb21CdWNrZXRTcGVjKGJ1Y2tldFN0cmluZywgaG9zdCk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBjb25uZWN0U3RvcmFnZUVtdWxhdG9yKFxuICBzdG9yYWdlOiBGaXJlYmFzZVN0b3JhZ2VJbXBsLFxuICBob3N0OiBzdHJpbmcsXG4gIHBvcnQ6IG51bWJlcixcbiAgb3B0aW9uczoge1xuICAgIG1vY2tVc2VyVG9rZW4/OiBFbXVsYXRvck1vY2tUb2tlbk9wdGlvbnMgfCBzdHJpbmc7XG4gIH0gPSB7fVxuKTogdm9pZCB7XG4gIHN0b3JhZ2UuaG9zdCA9IGAke2hvc3R9OiR7cG9ydH1gO1xuICBjb25zdCB1c2VTc2wgPSBpc0Nsb3VkV29ya3N0YXRpb24oaG9zdCk7XG4gIC8vIFdvcmthcm91bmQgdG8gZ2V0IGNvb2tpZXMgaW4gRmlyZWJhc2UgU3R1ZGlvXG4gIGlmICh1c2VTc2wpIHtcbiAgICB2b2lkIHBpbmdTZXJ2ZXIoYGh0dHBzOi8vJHtzdG9yYWdlLmhvc3R9L2JgKTtcbiAgfVxuICBzdG9yYWdlLl9pc1VzaW5nRW11bGF0b3IgPSB0cnVlO1xuICBzdG9yYWdlLl9wcm90b2NvbCA9IHVzZVNzbCA/ICdodHRwcycgOiAnaHR0cCc7XG4gIGNvbnN0IHsgbW9ja1VzZXJUb2tlbiB9ID0gb3B0aW9ucztcbiAgaWYgKG1vY2tVc2VyVG9rZW4pIHtcbiAgICBzdG9yYWdlLl9vdmVycmlkZUF1dGhUb2tlbiA9XG4gICAgICB0eXBlb2YgbW9ja1VzZXJUb2tlbiA9PT0gJ3N0cmluZydcbiAgICAgICAgPyBtb2NrVXNlclRva2VuXG4gICAgICAgIDogY3JlYXRlTW9ja1VzZXJUb2tlbihtb2NrVXNlclRva2VuLCBzdG9yYWdlLmFwcC5vcHRpb25zLnByb2plY3RJZCk7XG4gIH1cbn1cblxuLyoqXG4gKiBBIHNlcnZpY2UgdGhhdCBwcm92aWRlcyBGaXJlYmFzZSBTdG9yYWdlIFJlZmVyZW5jZSBpbnN0YW5jZXMuXG4gKiBAcGFyYW0gb3B0X3VybCAtIGdzOi8vIHVybCB0byBhIGN1c3RvbSBTdG9yYWdlIEJ1Y2tldFxuICpcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgY2xhc3MgRmlyZWJhc2VTdG9yYWdlSW1wbCBpbXBsZW1lbnRzIEZpcmViYXNlU3RvcmFnZSB7XG4gIF9idWNrZXQ6IExvY2F0aW9uIHwgbnVsbCA9IG51bGw7XG4gIC8qKlxuICAgKiBUaGlzIHN0cmluZyBjYW4gYmUgaW4gdGhlIGZvcm1hdHM6XG4gICAqIC0gaG9zdFxuICAgKiAtIGhvc3Q6cG9ydFxuICAgKi9cbiAgcHJpdmF0ZSBfaG9zdDogc3RyaW5nID0gREVGQVVMVF9IT1NUO1xuICBfcHJvdG9jb2w6IHN0cmluZyA9ICdodHRwcyc7XG4gIHByb3RlY3RlZCByZWFkb25seSBfYXBwSWQ6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICBwcml2YXRlIHJlYWRvbmx5IF9yZXF1ZXN0czogU2V0PFJlcXVlc3Q8dW5rbm93bj4+O1xuICBwcml2YXRlIF9kZWxldGVkOiBib29sZWFuID0gZmFsc2U7XG4gIHByaXZhdGUgX21heE9wZXJhdGlvblJldHJ5VGltZTogbnVtYmVyO1xuICBwcml2YXRlIF9tYXhVcGxvYWRSZXRyeVRpbWU6IG51bWJlcjtcbiAgX292ZXJyaWRlQXV0aFRva2VuPzogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIC8qKlxuICAgICAqIEZpcmViYXNlQXBwIGFzc29jaWF0ZWQgd2l0aCB0aGlzIFN0b3JhZ2VTZXJ2aWNlIGluc3RhbmNlLlxuICAgICAqL1xuICAgIHJlYWRvbmx5IGFwcDogRmlyZWJhc2VBcHAsXG4gICAgcmVhZG9ubHkgX2F1dGhQcm92aWRlcjogUHJvdmlkZXI8RmlyZWJhc2VBdXRoSW50ZXJuYWxOYW1lPixcbiAgICAvKipcbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICByZWFkb25seSBfYXBwQ2hlY2tQcm92aWRlcjogUHJvdmlkZXI8QXBwQ2hlY2tJbnRlcm5hbENvbXBvbmVudE5hbWU+LFxuICAgIC8qKlxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHJlYWRvbmx5IF91cmw/OiBzdHJpbmcsXG4gICAgcmVhZG9ubHkgX2ZpcmViYXNlVmVyc2lvbj86IHN0cmluZyxcbiAgICBwdWJsaWMgX2lzVXNpbmdFbXVsYXRvciA9IGZhbHNlXG4gICkge1xuICAgIHRoaXMuX21heE9wZXJhdGlvblJldHJ5VGltZSA9IERFRkFVTFRfTUFYX09QRVJBVElPTl9SRVRSWV9USU1FO1xuICAgIHRoaXMuX21heFVwbG9hZFJldHJ5VGltZSA9IERFRkFVTFRfTUFYX1VQTE9BRF9SRVRSWV9USU1FO1xuICAgIHRoaXMuX3JlcXVlc3RzID0gbmV3IFNldCgpO1xuICAgIGlmIChfdXJsICE9IG51bGwpIHtcbiAgICAgIHRoaXMuX2J1Y2tldCA9IExvY2F0aW9uLm1ha2VGcm9tQnVja2V0U3BlYyhfdXJsLCB0aGlzLl9ob3N0KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5fYnVja2V0ID0gZXh0cmFjdEJ1Y2tldCh0aGlzLl9ob3N0LCB0aGlzLmFwcC5vcHRpb25zKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVGhlIGhvc3Qgc3RyaW5nIGZvciB0aGlzIHNlcnZpY2UsIGluIHRoZSBmb3JtIG9mIGBob3N0YCBvclxuICAgKiBgaG9zdDpwb3J0YC5cbiAgICovXG4gIGdldCBob3N0KCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHRoaXMuX2hvc3Q7XG4gIH1cblxuICBzZXQgaG9zdChob3N0OiBzdHJpbmcpIHtcbiAgICB0aGlzLl9ob3N0ID0gaG9zdDtcbiAgICBpZiAodGhpcy5fdXJsICE9IG51bGwpIHtcbiAgICAgIHRoaXMuX2J1Y2tldCA9IExvY2F0aW9uLm1ha2VGcm9tQnVja2V0U3BlYyh0aGlzLl91cmwsIGhvc3QpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9idWNrZXQgPSBleHRyYWN0QnVja2V0KGhvc3QsIHRoaXMuYXBwLm9wdGlvbnMpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBUaGUgbWF4aW11bSB0aW1lIHRvIHJldHJ5IHVwbG9hZHMgaW4gbWlsbGlzZWNvbmRzLlxuICAgKi9cbiAgZ2V0IG1heFVwbG9hZFJldHJ5VGltZSgpOiBudW1iZXIge1xuICAgIHJldHVybiB0aGlzLl9tYXhVcGxvYWRSZXRyeVRpbWU7XG4gIH1cblxuICBzZXQgbWF4VXBsb2FkUmV0cnlUaW1lKHRpbWU6IG51bWJlcikge1xuICAgIHZhbGlkYXRlTnVtYmVyKFxuICAgICAgJ3RpbWUnLFxuICAgICAgLyogbWluVmFsdWU9Ki8gMCxcbiAgICAgIC8qIG1heFZhbHVlPSAqLyBOdW1iZXIuUE9TSVRJVkVfSU5GSU5JVFksXG4gICAgICB0aW1lXG4gICAgKTtcbiAgICB0aGlzLl9tYXhVcGxvYWRSZXRyeVRpbWUgPSB0aW1lO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSBtYXhpbXVtIHRpbWUgdG8gcmV0cnkgb3BlcmF0aW9ucyBvdGhlciB0aGFuIHVwbG9hZHMgb3IgZG93bmxvYWRzIGluXG4gICAqIG1pbGxpc2Vjb25kcy5cbiAgICovXG4gIGdldCBtYXhPcGVyYXRpb25SZXRyeVRpbWUoKTogbnVtYmVyIHtcbiAgICByZXR1cm4gdGhpcy5fbWF4T3BlcmF0aW9uUmV0cnlUaW1lO1xuICB9XG5cbiAgc2V0IG1heE9wZXJhdGlvblJldHJ5VGltZSh0aW1lOiBudW1iZXIpIHtcbiAgICB2YWxpZGF0ZU51bWJlcihcbiAgICAgICd0aW1lJyxcbiAgICAgIC8qIG1pblZhbHVlPSovIDAsXG4gICAgICAvKiBtYXhWYWx1ZT0gKi8gTnVtYmVyLlBPU0lUSVZFX0lORklOSVRZLFxuICAgICAgdGltZVxuICAgICk7XG4gICAgdGhpcy5fbWF4T3BlcmF0aW9uUmV0cnlUaW1lID0gdGltZTtcbiAgfVxuXG4gIGFzeW5jIF9nZXRBdXRoVG9rZW4oKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG4gICAgaWYgKHRoaXMuX292ZXJyaWRlQXV0aFRva2VuKSB7XG4gICAgICByZXR1cm4gdGhpcy5fb3ZlcnJpZGVBdXRoVG9rZW47XG4gICAgfVxuICAgIGNvbnN0IGF1dGggPSB0aGlzLl9hdXRoUHJvdmlkZXIuZ2V0SW1tZWRpYXRlKHsgb3B0aW9uYWw6IHRydWUgfSk7XG4gICAgaWYgKGF1dGgpIHtcbiAgICAgIGNvbnN0IHRva2VuRGF0YSA9IGF3YWl0IGF1dGguZ2V0VG9rZW4oKTtcbiAgICAgIGlmICh0b2tlbkRhdGEgIT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIHRva2VuRGF0YS5hY2Nlc3NUb2tlbjtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICBhc3luYyBfZ2V0QXBwQ2hlY2tUb2tlbigpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgICBpZiAoX2lzRmlyZWJhc2VTZXJ2ZXJBcHAodGhpcy5hcHApICYmIHRoaXMuYXBwLnNldHRpbmdzLmFwcENoZWNrVG9rZW4pIHtcbiAgICAgIHJldHVybiB0aGlzLmFwcC5zZXR0aW5ncy5hcHBDaGVja1Rva2VuO1xuICAgIH1cbiAgICBjb25zdCBhcHBDaGVjayA9IHRoaXMuX2FwcENoZWNrUHJvdmlkZXIuZ2V0SW1tZWRpYXRlKHsgb3B0aW9uYWw6IHRydWUgfSk7XG4gICAgaWYgKGFwcENoZWNrKSB7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBhcHBDaGVjay5nZXRUb2tlbigpO1xuICAgICAgLy8gVE9ETzogV2hhdCBkbyB3ZSB3YW50IHRvIGRvIGlmIHRoZXJlIGlzIGFuIGVycm9yIGdldHRpbmcgdGhlIHRva2VuP1xuICAgICAgLy8gQ29udGV4dDogYXBwQ2hlY2suZ2V0VG9rZW4oKSB3aWxsIG5ldmVyIHRocm93IGV2ZW4gaWYgYW4gZXJyb3IgaGFwcGVuZWQuIEluIHRoZSBlcnJvciBjYXNlLCBhIGR1bW15IHRva2VuIHdpbGwgYmVcbiAgICAgIC8vIHJldHVybmVkIGFsb25nIHdpdGggYW4gZXJyb3IgZmllbGQgZGVzY3JpYmluZyB0aGUgZXJyb3IuIEluIGdlbmVyYWwsIHdlIHNob3VsZG4ndCBjYXJlIGFib3V0IHRoZSBlcnJvciBjb25kaXRpb24gYW5kIGp1c3QgdXNlXG4gICAgICAvLyB0aGUgdG9rZW4gKGFjdHVhbCBvciBkdW1teSkgdG8gc2VuZCByZXF1ZXN0cy5cbiAgICAgIHJldHVybiByZXN1bHQudG9rZW47XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgLyoqXG4gICAqIFN0b3AgcnVubmluZyByZXF1ZXN0cyBhbmQgcHJldmVudCBtb3JlIGZyb20gYmVpbmcgY3JlYXRlZC5cbiAgICovXG4gIF9kZWxldGUoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgaWYgKCF0aGlzLl9kZWxldGVkKSB7XG4gICAgICB0aGlzLl9kZWxldGVkID0gdHJ1ZTtcbiAgICAgIHRoaXMuX3JlcXVlc3RzLmZvckVhY2gocmVxdWVzdCA9PiByZXF1ZXN0LmNhbmNlbCgpKTtcbiAgICAgIHRoaXMuX3JlcXVlc3RzLmNsZWFyKCk7XG4gICAgfVxuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGEgbmV3IGZpcmViYXNlU3RvcmFnZS5SZWZlcmVuY2Ugb2JqZWN0IHJlZmVyZW5jaW5nIHRoaXMgU3RvcmFnZVNlcnZpY2VcbiAgICogYXQgdGhlIGdpdmVuIExvY2F0aW9uLlxuICAgKi9cbiAgX21ha2VTdG9yYWdlUmVmZXJlbmNlKGxvYzogTG9jYXRpb24pOiBSZWZlcmVuY2Uge1xuICAgIHJldHVybiBuZXcgUmVmZXJlbmNlKHRoaXMsIGxvYyk7XG4gIH1cblxuICAvKipcbiAgICogQHBhcmFtIHJlcXVlc3RJbmZvIC0gSFRUUCBSZXF1ZXN0SW5mbyBvYmplY3RcbiAgICogQHBhcmFtIGF1dGhUb2tlbiAtIEZpcmViYXNlIGF1dGggdG9rZW5cbiAgICovXG4gIF9tYWtlUmVxdWVzdDxJIGV4dGVuZHMgQ29ubmVjdGlvblR5cGUsIE8+KFxuICAgIHJlcXVlc3RJbmZvOiBSZXF1ZXN0SW5mbzxJLCBPPixcbiAgICByZXF1ZXN0RmFjdG9yeTogKCkgPT4gQ29ubmVjdGlvbjxJPixcbiAgICBhdXRoVG9rZW46IHN0cmluZyB8IG51bGwsXG4gICAgYXBwQ2hlY2tUb2tlbjogc3RyaW5nIHwgbnVsbCxcbiAgICByZXRyeSA9IHRydWVcbiAgKTogUmVxdWVzdDxPPiB7XG4gICAgaWYgKCF0aGlzLl9kZWxldGVkKSB7XG4gICAgICBjb25zdCByZXF1ZXN0ID0gbWFrZVJlcXVlc3QoXG4gICAgICAgIHJlcXVlc3RJbmZvLFxuICAgICAgICB0aGlzLl9hcHBJZCxcbiAgICAgICAgYXV0aFRva2VuLFxuICAgICAgICBhcHBDaGVja1Rva2VuLFxuICAgICAgICByZXF1ZXN0RmFjdG9yeSxcbiAgICAgICAgdGhpcy5fZmlyZWJhc2VWZXJzaW9uLFxuICAgICAgICByZXRyeSxcbiAgICAgICAgdGhpcy5faXNVc2luZ0VtdWxhdG9yXG4gICAgICApO1xuICAgICAgdGhpcy5fcmVxdWVzdHMuYWRkKHJlcXVlc3QpO1xuICAgICAgLy8gUmVxdWVzdCByZW1vdmVzIGl0c2VsZiBmcm9tIHNldCB3aGVuIGNvbXBsZXRlLlxuICAgICAgcmVxdWVzdC5nZXRQcm9taXNlKCkudGhlbihcbiAgICAgICAgKCkgPT4gdGhpcy5fcmVxdWVzdHMuZGVsZXRlKHJlcXVlc3QpLFxuICAgICAgICAoKSA9PiB0aGlzLl9yZXF1ZXN0cy5kZWxldGUocmVxdWVzdClcbiAgICAgICk7XG4gICAgICByZXR1cm4gcmVxdWVzdDtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIG5ldyBGYWlsUmVxdWVzdChhcHBEZWxldGVkKCkpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIG1ha2VSZXF1ZXN0V2l0aFRva2VuczxJIGV4dGVuZHMgQ29ubmVjdGlvblR5cGUsIE8+KFxuICAgIHJlcXVlc3RJbmZvOiBSZXF1ZXN0SW5mbzxJLCBPPixcbiAgICByZXF1ZXN0RmFjdG9yeTogKCkgPT4gQ29ubmVjdGlvbjxJPlxuICApOiBQcm9taXNlPE8+IHtcbiAgICBjb25zdCBbYXV0aFRva2VuLCBhcHBDaGVja1Rva2VuXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgIHRoaXMuX2dldEF1dGhUb2tlbigpLFxuICAgICAgdGhpcy5fZ2V0QXBwQ2hlY2tUb2tlbigpXG4gICAgXSk7XG5cbiAgICByZXR1cm4gdGhpcy5fbWFrZVJlcXVlc3QoXG4gICAgICByZXF1ZXN0SW5mbyxcbiAgICAgIHJlcXVlc3RGYWN0b3J5LFxuICAgICAgYXV0aFRva2VuLFxuICAgICAgYXBwQ2hlY2tUb2tlblxuICAgICkuZ2V0UHJvbWlzZSgpO1xuICB9XG59XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAyMCBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG4vKipcbiAqIFR5cGUgY29uc3RhbnQgZm9yIEZpcmViYXNlIFN0b3JhZ2UuXG4gKi9cbmV4cG9ydCBjb25zdCBTVE9SQUdFX1RZUEUgPSAnc3RvcmFnZSc7XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAyMCBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuaW1wb3J0IHsgX2dldFByb3ZpZGVyLCBGaXJlYmFzZUFwcCwgZ2V0QXBwIH0gZnJvbSAnQGZpcmViYXNlL2FwcCc7XG5cbmltcG9ydCB7XG4gIHJlZiBhcyByZWZJbnRlcm5hbCxcbiAgRmlyZWJhc2VTdG9yYWdlSW1wbCxcbiAgY29ubmVjdFN0b3JhZ2VFbXVsYXRvciBhcyBjb25uZWN0RW11bGF0b3JJbnRlcm5hbFxufSBmcm9tICcuL3NlcnZpY2UnO1xuaW1wb3J0IHsgUHJvdmlkZXIgfSBmcm9tICdAZmlyZWJhc2UvY29tcG9uZW50JztcblxuaW1wb3J0IHtcbiAgU3RvcmFnZVJlZmVyZW5jZSxcbiAgRmlyZWJhc2VTdG9yYWdlLFxuICBVcGxvYWRSZXN1bHQsXG4gIExpc3RPcHRpb25zLFxuICBMaXN0UmVzdWx0LFxuICBVcGxvYWRUYXNrLFxuICBTZXR0YWJsZU1ldGFkYXRhLFxuICBVcGxvYWRNZXRhZGF0YSxcbiAgRnVsbE1ldGFkYXRhXG59IGZyb20gJy4vcHVibGljLXR5cGVzJztcbmltcG9ydCB7IE1ldGFkYXRhIGFzIE1ldGFkYXRhSW50ZXJuYWwgfSBmcm9tICcuL21ldGFkYXRhJztcbmltcG9ydCB7XG4gIHVwbG9hZEJ5dGVzIGFzIHVwbG9hZEJ5dGVzSW50ZXJuYWwsXG4gIHVwbG9hZEJ5dGVzUmVzdW1hYmxlIGFzIHVwbG9hZEJ5dGVzUmVzdW1hYmxlSW50ZXJuYWwsXG4gIHVwbG9hZFN0cmluZyBhcyB1cGxvYWRTdHJpbmdJbnRlcm5hbCxcbiAgZ2V0TWV0YWRhdGEgYXMgZ2V0TWV0YWRhdGFJbnRlcm5hbCxcbiAgdXBkYXRlTWV0YWRhdGEgYXMgdXBkYXRlTWV0YWRhdGFJbnRlcm5hbCxcbiAgbGlzdCBhcyBsaXN0SW50ZXJuYWwsXG4gIGxpc3RBbGwgYXMgbGlzdEFsbEludGVybmFsLFxuICBnZXREb3dubG9hZFVSTCBhcyBnZXREb3dubG9hZFVSTEludGVybmFsLFxuICBkZWxldGVPYmplY3QgYXMgZGVsZXRlT2JqZWN0SW50ZXJuYWwsXG4gIFJlZmVyZW5jZSxcbiAgX2dldENoaWxkIGFzIF9nZXRDaGlsZEludGVybmFsLFxuICBnZXRCeXRlc0ludGVybmFsXG59IGZyb20gJy4vcmVmZXJlbmNlJztcbmltcG9ydCB7IFNUT1JBR0VfVFlQRSB9IGZyb20gJy4vY29uc3RhbnRzJztcbmltcG9ydCB7XG4gIEVtdWxhdG9yTW9ja1Rva2VuT3B0aW9ucyxcbiAgZ2V0TW9kdWxhckluc3RhbmNlLFxuICBnZXREZWZhdWx0RW11bGF0b3JIb3N0bmFtZUFuZFBvcnRcbn0gZnJvbSAnQGZpcmViYXNlL3V0aWwnO1xuaW1wb3J0IHsgU3RyaW5nRm9ybWF0IH0gZnJvbSAnLi9pbXBsZW1lbnRhdGlvbi9zdHJpbmcnO1xuXG5leHBvcnQgeyBFbXVsYXRvck1vY2tUb2tlbk9wdGlvbnMgfSBmcm9tICdAZmlyZWJhc2UvdXRpbCc7XG5cbmV4cG9ydCB7IFN0b3JhZ2VFcnJvciwgU3RvcmFnZUVycm9yQ29kZSB9IGZyb20gJy4vaW1wbGVtZW50YXRpb24vZXJyb3InO1xuXG4vKipcbiAqIFB1YmxpYyB0eXBlcy5cbiAqL1xuZXhwb3J0ICogZnJvbSAnLi9wdWJsaWMtdHlwZXMnO1xuXG5leHBvcnQgeyBMb2NhdGlvbiBhcyBfTG9jYXRpb24gfSBmcm9tICcuL2ltcGxlbWVudGF0aW9uL2xvY2F0aW9uJztcbmV4cG9ydCB7IFVwbG9hZFRhc2sgYXMgX1VwbG9hZFRhc2sgfSBmcm9tICcuL3Rhc2snO1xuZXhwb3J0IHR5cGUgeyBSZWZlcmVuY2UgYXMgX1JlZmVyZW5jZSB9IGZyb20gJy4vcmVmZXJlbmNlJztcbmV4cG9ydCB0eXBlIHsgRmlyZWJhc2VTdG9yYWdlSW1wbCBhcyBfRmlyZWJhc2VTdG9yYWdlSW1wbCB9IGZyb20gJy4vc2VydmljZSc7XG5leHBvcnQgeyBGYnNCbG9iIGFzIF9GYnNCbG9iIH0gZnJvbSAnLi9pbXBsZW1lbnRhdGlvbi9ibG9iJztcbmV4cG9ydCB7IGRhdGFGcm9tU3RyaW5nIGFzIF9kYXRhRnJvbVN0cmluZyB9IGZyb20gJy4vaW1wbGVtZW50YXRpb24vc3RyaW5nJztcbmV4cG9ydCB7XG4gIGludmFsaWRSb290T3BlcmF0aW9uIGFzIF9pbnZhbGlkUm9vdE9wZXJhdGlvbixcbiAgaW52YWxpZEFyZ3VtZW50IGFzIF9pbnZhbGlkQXJndW1lbnRcbn0gZnJvbSAnLi9pbXBsZW1lbnRhdGlvbi9lcnJvcic7XG5leHBvcnQge1xuICBUYXNrRXZlbnQgYXMgX1Rhc2tFdmVudCxcbiAgVGFza1N0YXRlIGFzIF9UYXNrU3RhdGVcbn0gZnJvbSAnLi9pbXBsZW1lbnRhdGlvbi90YXNrZW51bXMnO1xuZXhwb3J0IHsgU3RyaW5nRm9ybWF0IH07XG5cbi8qKlxuICogRG93bmxvYWRzIHRoZSBkYXRhIGF0IHRoZSBvYmplY3QncyBsb2NhdGlvbi4gUmV0dXJucyBhbiBlcnJvciBpZiB0aGUgb2JqZWN0XG4gKiBpcyBub3QgZm91bmQuXG4gKlxuICogVG8gdXNlIHRoaXMgZnVuY3Rpb25hbGl0eSwgeW91IGhhdmUgdG8gd2hpdGVsaXN0IHlvdXIgYXBwJ3Mgb3JpZ2luIGluIHlvdXJcbiAqIENsb3VkIFN0b3JhZ2UgYnVja2V0LiBTZWUgYWxzb1xuICogaHR0cHM6Ly9jbG91ZC5nb29nbGUuY29tL3N0b3JhZ2UvZG9jcy9jb25maWd1cmluZy1jb3JzXG4gKlxuICogQHB1YmxpY1xuICogQHBhcmFtIHJlZiAtIFN0b3JhZ2VSZWZlcmVuY2Ugd2hlcmUgZGF0YSBzaG91bGQgYmUgZG93bmxvYWRlZC5cbiAqIEBwYXJhbSBtYXhEb3dubG9hZFNpemVCeXRlcyAtIElmIHNldCwgdGhlIG1heGltdW0gYWxsb3dlZCBzaXplIGluIGJ5dGVzIHRvXG4gKiByZXRyaWV2ZS5cbiAqIEByZXR1cm5zIEEgUHJvbWlzZSBjb250YWluaW5nIHRoZSBvYmplY3QncyBieXRlc1xuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0Qnl0ZXMoXG4gIHJlZjogU3RvcmFnZVJlZmVyZW5jZSxcbiAgbWF4RG93bmxvYWRTaXplQnl0ZXM/OiBudW1iZXJcbik6IFByb21pc2U8QXJyYXlCdWZmZXI+IHtcbiAgcmVmID0gZ2V0TW9kdWxhckluc3RhbmNlKHJlZik7XG4gIHJldHVybiBnZXRCeXRlc0ludGVybmFsKHJlZiBhcyBSZWZlcmVuY2UsIG1heERvd25sb2FkU2l6ZUJ5dGVzKTtcbn1cblxuLyoqXG4gKiBVcGxvYWRzIGRhdGEgdG8gdGhpcyBvYmplY3QncyBsb2NhdGlvbi5cbiAqIFRoZSB1cGxvYWQgaXMgbm90IHJlc3VtYWJsZS5cbiAqIEBwdWJsaWNcbiAqIEBwYXJhbSByZWYgLSB7QGxpbmsgU3RvcmFnZVJlZmVyZW5jZX0gd2hlcmUgZGF0YSBzaG91bGQgYmUgdXBsb2FkZWQuXG4gKiBAcGFyYW0gZGF0YSAtIFRoZSBkYXRhIHRvIHVwbG9hZC5cbiAqIEBwYXJhbSBtZXRhZGF0YSAtIE1ldGFkYXRhIGZvciB0aGUgZGF0YSB0byB1cGxvYWQuXG4gKiBAcmV0dXJucyBBIFByb21pc2UgY29udGFpbmluZyBhbiBVcGxvYWRSZXN1bHRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVwbG9hZEJ5dGVzKFxuICByZWY6IFN0b3JhZ2VSZWZlcmVuY2UsXG4gIGRhdGE6IEJsb2IgfCBVaW50OEFycmF5IHwgQXJyYXlCdWZmZXIsXG4gIG1ldGFkYXRhPzogVXBsb2FkTWV0YWRhdGFcbik6IFByb21pc2U8VXBsb2FkUmVzdWx0PiB7XG4gIHJlZiA9IGdldE1vZHVsYXJJbnN0YW5jZShyZWYpO1xuICByZXR1cm4gdXBsb2FkQnl0ZXNJbnRlcm5hbChcbiAgICByZWYgYXMgUmVmZXJlbmNlLFxuICAgIGRhdGEsXG4gICAgbWV0YWRhdGEgYXMgTWV0YWRhdGFJbnRlcm5hbFxuICApO1xufVxuXG4vKipcbiAqIFVwbG9hZHMgYSBzdHJpbmcgdG8gdGhpcyBvYmplY3QncyBsb2NhdGlvbi5cbiAqIFRoZSB1cGxvYWQgaXMgbm90IHJlc3VtYWJsZS5cbiAqIEBwdWJsaWNcbiAqIEBwYXJhbSByZWYgLSB7QGxpbmsgU3RvcmFnZVJlZmVyZW5jZX0gd2hlcmUgc3RyaW5nIHNob3VsZCBiZSB1cGxvYWRlZC5cbiAqIEBwYXJhbSB2YWx1ZSAtIFRoZSBzdHJpbmcgdG8gdXBsb2FkLlxuICogQHBhcmFtIGZvcm1hdCAtIFRoZSBmb3JtYXQgb2YgdGhlIHN0cmluZyB0byB1cGxvYWQuXG4gKiBAcGFyYW0gbWV0YWRhdGEgLSBNZXRhZGF0YSBmb3IgdGhlIHN0cmluZyB0byB1cGxvYWQuXG4gKiBAcmV0dXJucyBBIFByb21pc2UgY29udGFpbmluZyBhbiBVcGxvYWRSZXN1bHRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVwbG9hZFN0cmluZyhcbiAgcmVmOiBTdG9yYWdlUmVmZXJlbmNlLFxuICB2YWx1ZTogc3RyaW5nLFxuICBmb3JtYXQ/OiBTdHJpbmdGb3JtYXQsXG4gIG1ldGFkYXRhPzogVXBsb2FkTWV0YWRhdGFcbik6IFByb21pc2U8VXBsb2FkUmVzdWx0PiB7XG4gIHJlZiA9IGdldE1vZHVsYXJJbnN0YW5jZShyZWYpO1xuICByZXR1cm4gdXBsb2FkU3RyaW5nSW50ZXJuYWwoXG4gICAgcmVmIGFzIFJlZmVyZW5jZSxcbiAgICB2YWx1ZSxcbiAgICBmb3JtYXQsXG4gICAgbWV0YWRhdGEgYXMgTWV0YWRhdGFJbnRlcm5hbFxuICApO1xufVxuXG4vKipcbiAqIFVwbG9hZHMgZGF0YSB0byB0aGlzIG9iamVjdCdzIGxvY2F0aW9uLlxuICogVGhlIHVwbG9hZCBjYW4gYmUgcGF1c2VkIGFuZCByZXN1bWVkLCBhbmQgZXhwb3NlcyBwcm9ncmVzcyB1cGRhdGVzLlxuICogQHB1YmxpY1xuICogQHBhcmFtIHJlZiAtIHtAbGluayBTdG9yYWdlUmVmZXJlbmNlfSB3aGVyZSBkYXRhIHNob3VsZCBiZSB1cGxvYWRlZC5cbiAqIEBwYXJhbSBkYXRhIC0gVGhlIGRhdGEgdG8gdXBsb2FkLlxuICogQHBhcmFtIG1ldGFkYXRhIC0gTWV0YWRhdGEgZm9yIHRoZSBkYXRhIHRvIHVwbG9hZC5cbiAqIEByZXR1cm5zIEFuIFVwbG9hZFRhc2tcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVwbG9hZEJ5dGVzUmVzdW1hYmxlKFxuICByZWY6IFN0b3JhZ2VSZWZlcmVuY2UsXG4gIGRhdGE6IEJsb2IgfCBVaW50OEFycmF5IHwgQXJyYXlCdWZmZXIsXG4gIG1ldGFkYXRhPzogVXBsb2FkTWV0YWRhdGFcbik6IFVwbG9hZFRhc2sge1xuICByZWYgPSBnZXRNb2R1bGFySW5zdGFuY2UocmVmKTtcbiAgcmV0dXJuIHVwbG9hZEJ5dGVzUmVzdW1hYmxlSW50ZXJuYWwoXG4gICAgcmVmIGFzIFJlZmVyZW5jZSxcbiAgICBkYXRhLFxuICAgIG1ldGFkYXRhIGFzIE1ldGFkYXRhSW50ZXJuYWxcbiAgKSBhcyBVcGxvYWRUYXNrO1xufVxuXG4vKipcbiAqIEEgYFByb21pc2VgIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgbWV0YWRhdGEgZm9yIHRoaXMgb2JqZWN0LiBJZiB0aGlzXG4gKiBvYmplY3QgZG9lc24ndCBleGlzdCBvciBtZXRhZGF0YSBjYW5ub3QgYmUgcmV0cmlldmVkLCB0aGUgcHJvbWlzZSBpc1xuICogcmVqZWN0ZWQuXG4gKiBAcHVibGljXG4gKiBAcGFyYW0gcmVmIC0ge0BsaW5rIFN0b3JhZ2VSZWZlcmVuY2V9IHRvIGdldCBtZXRhZGF0YSBmcm9tLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0TWV0YWRhdGEocmVmOiBTdG9yYWdlUmVmZXJlbmNlKTogUHJvbWlzZTxGdWxsTWV0YWRhdGE+IHtcbiAgcmVmID0gZ2V0TW9kdWxhckluc3RhbmNlKHJlZik7XG4gIHJldHVybiBnZXRNZXRhZGF0YUludGVybmFsKHJlZiBhcyBSZWZlcmVuY2UpIGFzIFByb21pc2U8RnVsbE1ldGFkYXRhPjtcbn1cblxuLyoqXG4gKiBVcGRhdGVzIHRoZSBtZXRhZGF0YSBmb3IgdGhpcyBvYmplY3QuXG4gKiBAcHVibGljXG4gKiBAcGFyYW0gcmVmIC0ge0BsaW5rIFN0b3JhZ2VSZWZlcmVuY2V9IHRvIHVwZGF0ZSBtZXRhZGF0YSBmb3IuXG4gKiBAcGFyYW0gbWV0YWRhdGEgLSBUaGUgbmV3IG1ldGFkYXRhIGZvciB0aGUgb2JqZWN0LlxuICogICAgIE9ubHkgdmFsdWVzIHRoYXQgaGF2ZSBiZWVuIGV4cGxpY2l0bHkgc2V0IHdpbGwgYmUgY2hhbmdlZC4gRXhwbGljaXRseVxuICogICAgIHNldHRpbmcgYSB2YWx1ZSB0byBudWxsIHdpbGwgcmVtb3ZlIHRoZSBtZXRhZGF0YS5cbiAqIEByZXR1cm5zIEEgYFByb21pc2VgIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgbmV3IG1ldGFkYXRhIGZvciB0aGlzIG9iamVjdC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVwZGF0ZU1ldGFkYXRhKFxuICByZWY6IFN0b3JhZ2VSZWZlcmVuY2UsXG4gIG1ldGFkYXRhOiBTZXR0YWJsZU1ldGFkYXRhXG4pOiBQcm9taXNlPEZ1bGxNZXRhZGF0YT4ge1xuICByZWYgPSBnZXRNb2R1bGFySW5zdGFuY2UocmVmKTtcbiAgcmV0dXJuIHVwZGF0ZU1ldGFkYXRhSW50ZXJuYWwoXG4gICAgcmVmIGFzIFJlZmVyZW5jZSxcbiAgICBtZXRhZGF0YSBhcyBQYXJ0aWFsPE1ldGFkYXRhSW50ZXJuYWw+XG4gICkgYXMgUHJvbWlzZTxGdWxsTWV0YWRhdGE+O1xufVxuXG4vKipcbiAqIExpc3QgaXRlbXMgKGZpbGVzKSBhbmQgcHJlZml4ZXMgKGZvbGRlcnMpIHVuZGVyIHRoaXMgc3RvcmFnZSByZWZlcmVuY2UuXG4gKlxuICogTGlzdCBBUEkgaXMgb25seSBhdmFpbGFibGUgZm9yIEZpcmViYXNlIFJ1bGVzIFZlcnNpb24gMi5cbiAqXG4gKiBHQ1MgaXMgYSBrZXktYmxvYiBzdG9yZS4gRmlyZWJhc2UgU3RvcmFnZSBpbXBvc2VzIHRoZSBzZW1hbnRpYyBvZiAnLydcbiAqIGRlbGltaXRlZCBmb2xkZXIgc3RydWN0dXJlLlxuICogUmVmZXIgdG8gR0NTJ3MgTGlzdCBBUEkgaWYgeW91IHdhbnQgdG8gbGVhcm4gbW9yZS5cbiAqXG4gKiBUbyBhZGhlcmUgdG8gRmlyZWJhc2UgUnVsZXMncyBTZW1hbnRpY3MsIEZpcmViYXNlIFN0b3JhZ2UgZG9lcyBub3RcbiAqIHN1cHBvcnQgb2JqZWN0cyB3aG9zZSBwYXRocyBlbmQgd2l0aCBcIi9cIiBvciBjb250YWluIHR3byBjb25zZWN1dGl2ZVxuICogXCIvXCJzLiBGaXJlYmFzZSBTdG9yYWdlIExpc3QgQVBJIHdpbGwgZmlsdGVyIHRoZXNlIHVuc3VwcG9ydGVkIG9iamVjdHMuXG4gKiBsaXN0KCkgbWF5IGZhaWwgaWYgdGhlcmUgYXJlIHRvbyBtYW55IHVuc3VwcG9ydGVkIG9iamVjdHMgaW4gdGhlIGJ1Y2tldC5cbiAqIEBwdWJsaWNcbiAqXG4gKiBAcGFyYW0gcmVmIC0ge0BsaW5rIFN0b3JhZ2VSZWZlcmVuY2V9IHRvIGdldCBsaXN0IGZyb20uXG4gKiBAcGFyYW0gb3B0aW9ucyAtIFNlZSB7QGxpbmsgTGlzdE9wdGlvbnN9IGZvciBkZXRhaWxzLlxuICogQHJldHVybnMgQSBgUHJvbWlzZWAgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSBpdGVtcyBhbmQgcHJlZml4ZXMuXG4gKiAgICAgIGBwcmVmaXhlc2AgY29udGFpbnMgcmVmZXJlbmNlcyB0byBzdWItZm9sZGVycyBhbmQgYGl0ZW1zYFxuICogICAgICBjb250YWlucyByZWZlcmVuY2VzIHRvIG9iamVjdHMgaW4gdGhpcyBmb2xkZXIuIGBuZXh0UGFnZVRva2VuYFxuICogICAgICBjYW4gYmUgdXNlZCB0byBnZXQgdGhlIHJlc3Qgb2YgdGhlIHJlc3VsdHMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBsaXN0KFxuICByZWY6IFN0b3JhZ2VSZWZlcmVuY2UsXG4gIG9wdGlvbnM/OiBMaXN0T3B0aW9uc1xuKTogUHJvbWlzZTxMaXN0UmVzdWx0PiB7XG4gIHJlZiA9IGdldE1vZHVsYXJJbnN0YW5jZShyZWYpO1xuICByZXR1cm4gbGlzdEludGVybmFsKHJlZiBhcyBSZWZlcmVuY2UsIG9wdGlvbnMpO1xufVxuXG4vKipcbiAqIExpc3QgYWxsIGl0ZW1zIChmaWxlcykgYW5kIHByZWZpeGVzIChmb2xkZXJzKSB1bmRlciB0aGlzIHN0b3JhZ2UgcmVmZXJlbmNlLlxuICpcbiAqIFRoaXMgaXMgYSBoZWxwZXIgbWV0aG9kIGZvciBjYWxsaW5nIGxpc3QoKSByZXBlYXRlZGx5IHVudGlsIHRoZXJlIGFyZVxuICogbm8gbW9yZSByZXN1bHRzLiBUaGUgZGVmYXVsdCBwYWdpbmF0aW9uIHNpemUgaXMgMTAwMC5cbiAqXG4gKiBOb3RlOiBUaGUgcmVzdWx0cyBtYXkgbm90IGJlIGNvbnNpc3RlbnQgaWYgb2JqZWN0cyBhcmUgY2hhbmdlZCB3aGlsZSB0aGlzXG4gKiBvcGVyYXRpb24gaXMgcnVubmluZy5cbiAqXG4gKiBXYXJuaW5nOiBgbGlzdEFsbGAgbWF5IHBvdGVudGlhbGx5IGNvbnN1bWUgdG9vIG1hbnkgcmVzb3VyY2VzIGlmIHRoZXJlIGFyZVxuICogdG9vIG1hbnkgcmVzdWx0cy5cbiAqIEBwdWJsaWNcbiAqIEBwYXJhbSByZWYgLSB7QGxpbmsgU3RvcmFnZVJlZmVyZW5jZX0gdG8gZ2V0IGxpc3QgZnJvbS5cbiAqXG4gKiBAcmV0dXJucyBBIGBQcm9taXNlYCB0aGF0IHJlc29sdmVzIHdpdGggYWxsIHRoZSBpdGVtcyBhbmQgcHJlZml4ZXMgdW5kZXJcbiAqICAgICAgdGhlIGN1cnJlbnQgc3RvcmFnZSByZWZlcmVuY2UuIGBwcmVmaXhlc2AgY29udGFpbnMgcmVmZXJlbmNlcyB0b1xuICogICAgICBzdWItZGlyZWN0b3JpZXMgYW5kIGBpdGVtc2AgY29udGFpbnMgcmVmZXJlbmNlcyB0byBvYmplY3RzIGluIHRoaXNcbiAqICAgICAgZm9sZGVyLiBgbmV4dFBhZ2VUb2tlbmAgaXMgbmV2ZXIgcmV0dXJuZWQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBsaXN0QWxsKHJlZjogU3RvcmFnZVJlZmVyZW5jZSk6IFByb21pc2U8TGlzdFJlc3VsdD4ge1xuICByZWYgPSBnZXRNb2R1bGFySW5zdGFuY2UocmVmKTtcbiAgcmV0dXJuIGxpc3RBbGxJbnRlcm5hbChyZWYgYXMgUmVmZXJlbmNlKTtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBkb3dubG9hZCBVUkwgZm9yIHRoZSBnaXZlbiB7QGxpbmsgU3RvcmFnZVJlZmVyZW5jZX0uXG4gKiBAcHVibGljXG4gKiBAcGFyYW0gcmVmIC0ge0BsaW5rIFN0b3JhZ2VSZWZlcmVuY2V9IHRvIGdldCB0aGUgZG93bmxvYWQgVVJMIGZvci5cbiAqIEByZXR1cm5zIEEgYFByb21pc2VgIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgZG93bmxvYWRcbiAqICAgICBVUkwgZm9yIHRoaXMgb2JqZWN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RG93bmxvYWRVUkwocmVmOiBTdG9yYWdlUmVmZXJlbmNlKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgcmVmID0gZ2V0TW9kdWxhckluc3RhbmNlKHJlZik7XG4gIHJldHVybiBnZXREb3dubG9hZFVSTEludGVybmFsKHJlZiBhcyBSZWZlcmVuY2UpO1xufVxuXG4vKipcbiAqIERlbGV0ZXMgdGhlIG9iamVjdCBhdCB0aGlzIGxvY2F0aW9uLlxuICogQHB1YmxpY1xuICogQHBhcmFtIHJlZiAtIHtAbGluayBTdG9yYWdlUmVmZXJlbmNlfSBmb3Igb2JqZWN0IHRvIGRlbGV0ZS5cbiAqIEByZXR1cm5zIEEgYFByb21pc2VgIHRoYXQgcmVzb2x2ZXMgaWYgdGhlIGRlbGV0aW9uIHN1Y2NlZWRzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZGVsZXRlT2JqZWN0KHJlZjogU3RvcmFnZVJlZmVyZW5jZSk6IFByb21pc2U8dm9pZD4ge1xuICByZWYgPSBnZXRNb2R1bGFySW5zdGFuY2UocmVmKTtcbiAgcmV0dXJuIGRlbGV0ZU9iamVjdEludGVybmFsKHJlZiBhcyBSZWZlcmVuY2UpO1xufVxuXG4vKipcbiAqIFJldHVybnMgYSB7QGxpbmsgU3RvcmFnZVJlZmVyZW5jZX0gZm9yIHRoZSBnaXZlbiB1cmwuXG4gKiBAcGFyYW0gc3RvcmFnZSAtIHtAbGluayBGaXJlYmFzZVN0b3JhZ2V9IGluc3RhbmNlLlxuICogQHBhcmFtIHVybCAtIFVSTC4gSWYgZW1wdHksIHJldHVybnMgcm9vdCByZWZlcmVuY2UuXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZWYoc3RvcmFnZTogRmlyZWJhc2VTdG9yYWdlLCB1cmw/OiBzdHJpbmcpOiBTdG9yYWdlUmVmZXJlbmNlO1xuLyoqXG4gKiBSZXR1cm5zIGEge0BsaW5rIFN0b3JhZ2VSZWZlcmVuY2V9IGZvciB0aGUgZ2l2ZW4gcGF0aCBpbiB0aGVcbiAqIGRlZmF1bHQgYnVja2V0LlxuICogQHBhcmFtIHN0b3JhZ2VPclJlZiAtIHtAbGluayBGaXJlYmFzZVN0b3JhZ2V9IG9yIHtAbGluayBTdG9yYWdlUmVmZXJlbmNlfS5cbiAqIEBwYXJhbSBwYXRoT3JVcmxTdG9yYWdlIC0gcGF0aC4gSWYgZW1wdHksIHJldHVybnMgcm9vdCByZWZlcmVuY2UgKGlmIHtAbGluayBGaXJlYmFzZVN0b3JhZ2V9XG4gKiBpbnN0YW5jZSBwcm92aWRlZCkgb3IgcmV0dXJucyBzYW1lIHJlZmVyZW5jZSAoaWYge0BsaW5rIFN0b3JhZ2VSZWZlcmVuY2V9IHByb3ZpZGVkKS5cbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlZihcbiAgc3RvcmFnZU9yUmVmOiBGaXJlYmFzZVN0b3JhZ2UgfCBTdG9yYWdlUmVmZXJlbmNlLFxuICBwYXRoPzogc3RyaW5nXG4pOiBTdG9yYWdlUmVmZXJlbmNlO1xuZXhwb3J0IGZ1bmN0aW9uIHJlZihcbiAgc2VydmljZU9yUmVmOiBGaXJlYmFzZVN0b3JhZ2UgfCBTdG9yYWdlUmVmZXJlbmNlLFxuICBwYXRoT3JVcmw/OiBzdHJpbmdcbik6IFN0b3JhZ2VSZWZlcmVuY2UgfCBudWxsIHtcbiAgc2VydmljZU9yUmVmID0gZ2V0TW9kdWxhckluc3RhbmNlKHNlcnZpY2VPclJlZik7XG4gIHJldHVybiByZWZJbnRlcm5hbChcbiAgICBzZXJ2aWNlT3JSZWYgYXMgRmlyZWJhc2VTdG9yYWdlSW1wbCB8IFJlZmVyZW5jZSxcbiAgICBwYXRoT3JVcmxcbiAgKTtcbn1cblxuLyoqXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIF9nZXRDaGlsZChyZWY6IFN0b3JhZ2VSZWZlcmVuY2UsIGNoaWxkUGF0aDogc3RyaW5nKTogUmVmZXJlbmNlIHtcbiAgcmV0dXJuIF9nZXRDaGlsZEludGVybmFsKHJlZiBhcyBSZWZlcmVuY2UsIGNoaWxkUGF0aCk7XG59XG5cbi8qKlxuICogR2V0cyBhIHtAbGluayBGaXJlYmFzZVN0b3JhZ2V9IGluc3RhbmNlIGZvciB0aGUgZ2l2ZW4gRmlyZWJhc2UgYXBwLlxuICogQHB1YmxpY1xuICogQHBhcmFtIGFwcCAtIEZpcmViYXNlIGFwcCB0byBnZXQge0BsaW5rIEZpcmViYXNlU3RvcmFnZX0gaW5zdGFuY2UgZm9yLlxuICogQHBhcmFtIGJ1Y2tldFVybCAtIFRoZSBnczovLyB1cmwgdG8geW91ciBGaXJlYmFzZSBTdG9yYWdlIEJ1Y2tldC5cbiAqIElmIG5vdCBwYXNzZWQsIHVzZXMgdGhlIGFwcCdzIGRlZmF1bHQgU3RvcmFnZSBCdWNrZXQuXG4gKiBAcmV0dXJucyBBIHtAbGluayBGaXJlYmFzZVN0b3JhZ2V9IGluc3RhbmNlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0U3RvcmFnZShcbiAgYXBwOiBGaXJlYmFzZUFwcCA9IGdldEFwcCgpLFxuICBidWNrZXRVcmw/OiBzdHJpbmdcbik6IEZpcmViYXNlU3RvcmFnZSB7XG4gIGFwcCA9IGdldE1vZHVsYXJJbnN0YW5jZShhcHApO1xuICBjb25zdCBzdG9yYWdlUHJvdmlkZXI6IFByb3ZpZGVyPCdzdG9yYWdlJz4gPSBfZ2V0UHJvdmlkZXIoYXBwLCBTVE9SQUdFX1RZUEUpO1xuICBjb25zdCBzdG9yYWdlSW5zdGFuY2UgPSBzdG9yYWdlUHJvdmlkZXIuZ2V0SW1tZWRpYXRlKHtcbiAgICBpZGVudGlmaWVyOiBidWNrZXRVcmxcbiAgfSk7XG4gIGNvbnN0IGVtdWxhdG9yID0gZ2V0RGVmYXVsdEVtdWxhdG9ySG9zdG5hbWVBbmRQb3J0KCdzdG9yYWdlJyk7XG4gIGlmIChlbXVsYXRvcikge1xuICAgIGNvbm5lY3RTdG9yYWdlRW11bGF0b3Ioc3RvcmFnZUluc3RhbmNlLCAuLi5lbXVsYXRvcik7XG4gIH1cbiAgcmV0dXJuIHN0b3JhZ2VJbnN0YW5jZTtcbn1cblxuLyoqXG4gKiBNb2RpZnkgdGhpcyB7QGxpbmsgRmlyZWJhc2VTdG9yYWdlfSBpbnN0YW5jZSB0byBjb21tdW5pY2F0ZSB3aXRoIHRoZSBDbG91ZCBTdG9yYWdlIGVtdWxhdG9yLlxuICpcbiAqIEBwYXJhbSBzdG9yYWdlIC0gVGhlIHtAbGluayBGaXJlYmFzZVN0b3JhZ2V9IGluc3RhbmNlXG4gKiBAcGFyYW0gaG9zdCAtIFRoZSBlbXVsYXRvciBob3N0IChleDogbG9jYWxob3N0KVxuICogQHBhcmFtIHBvcnQgLSBUaGUgZW11bGF0b3IgcG9ydCAoZXg6IDUwMDEpXG4gKiBAcGFyYW0gb3B0aW9ucyAtIEVtdWxhdG9yIG9wdGlvbnMuIGBvcHRpb25zLm1vY2tVc2VyVG9rZW5gIGlzIHRoZSBtb2NrIGF1dGhcbiAqIHRva2VuIHRvIHVzZSBmb3IgdW5pdCB0ZXN0aW5nIFNlY3VyaXR5IFJ1bGVzLlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgZnVuY3Rpb24gY29ubmVjdFN0b3JhZ2VFbXVsYXRvcihcbiAgc3RvcmFnZTogRmlyZWJhc2VTdG9yYWdlLFxuICBob3N0OiBzdHJpbmcsXG4gIHBvcnQ6IG51bWJlcixcbiAgb3B0aW9uczoge1xuICAgIG1vY2tVc2VyVG9rZW4/OiBFbXVsYXRvck1vY2tUb2tlbk9wdGlvbnMgfCBzdHJpbmc7XG4gIH0gPSB7fVxuKTogdm9pZCB7XG4gIGNvbm5lY3RFbXVsYXRvckludGVybmFsKHN0b3JhZ2UgYXMgRmlyZWJhc2VTdG9yYWdlSW1wbCwgaG9zdCwgcG9ydCwgb3B0aW9ucyk7XG59XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAyMSBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG5pbXBvcnQgeyBTdG9yYWdlUmVmZXJlbmNlIH0gZnJvbSAnLi9wdWJsaWMtdHlwZXMnO1xuaW1wb3J0IHsgUmVmZXJlbmNlLCBnZXRCbG9iSW50ZXJuYWwgfSBmcm9tICcuL3JlZmVyZW5jZSc7XG5pbXBvcnQgeyBnZXRNb2R1bGFySW5zdGFuY2UgfSBmcm9tICdAZmlyZWJhc2UvdXRpbCc7XG5cbi8qKlxuICogRG93bmxvYWRzIHRoZSBkYXRhIGF0IHRoZSBvYmplY3QncyBsb2NhdGlvbi4gUmV0dXJucyBhbiBlcnJvciBpZiB0aGUgb2JqZWN0XG4gKiBpcyBub3QgZm91bmQuXG4gKlxuICogVG8gdXNlIHRoaXMgZnVuY3Rpb25hbGl0eSwgeW91IGhhdmUgdG8gd2hpdGVsaXN0IHlvdXIgYXBwJ3Mgb3JpZ2luIGluIHlvdXJcbiAqIENsb3VkIFN0b3JhZ2UgYnVja2V0LiBTZWUgYWxzb1xuICogaHR0cHM6Ly9jbG91ZC5nb29nbGUuY29tL3N0b3JhZ2UvZG9jcy9jb25maWd1cmluZy1jb3JzXG4gKlxuICogVGhpcyBBUEkgaXMgbm90IGF2YWlsYWJsZSBpbiBOb2RlLlxuICpcbiAqIEBwdWJsaWNcbiAqIEBwYXJhbSByZWYgLSBTdG9yYWdlUmVmZXJlbmNlIHdoZXJlIGRhdGEgc2hvdWxkIGJlIGRvd25sb2FkZWQuXG4gKiBAcGFyYW0gbWF4RG93bmxvYWRTaXplQnl0ZXMgLSBJZiBzZXQsIHRoZSBtYXhpbXVtIGFsbG93ZWQgc2l6ZSBpbiBieXRlcyB0b1xuICogcmV0cmlldmUuXG4gKiBAcmV0dXJucyBBIFByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIGEgQmxvYiBjb250YWluaW5nIHRoZSBvYmplY3QncyBieXRlc1xuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0QmxvYihcbiAgcmVmOiBTdG9yYWdlUmVmZXJlbmNlLFxuICBtYXhEb3dubG9hZFNpemVCeXRlcz86IG51bWJlclxuKTogUHJvbWlzZTxCbG9iPiB7XG4gIHJlZiA9IGdldE1vZHVsYXJJbnN0YW5jZShyZWYpO1xuICByZXR1cm4gZ2V0QmxvYkludGVybmFsKHJlZiBhcyBSZWZlcmVuY2UsIG1heERvd25sb2FkU2l6ZUJ5dGVzKTtcbn1cblxuLyoqXG4gKiBEb3dubG9hZHMgdGhlIGRhdGEgYXQgdGhlIG9iamVjdCdzIGxvY2F0aW9uLiBSYWlzZXMgYW4gZXJyb3IgZXZlbnQgaWYgdGhlXG4gKiBvYmplY3QgaXMgbm90IGZvdW5kLlxuICpcbiAqIFRoaXMgQVBJIGlzIG9ubHkgYXZhaWxhYmxlIGluIE5vZGUuXG4gKlxuICogQHB1YmxpY1xuICogQHBhcmFtIHJlZiAtIFN0b3JhZ2VSZWZlcmVuY2Ugd2hlcmUgZGF0YSBzaG91bGQgYmUgZG93bmxvYWRlZC5cbiAqIEBwYXJhbSBtYXhEb3dubG9hZFNpemVCeXRlcyAtIElmIHNldCwgdGhlIG1heGltdW0gYWxsb3dlZCBzaXplIGluIGJ5dGVzIHRvXG4gKiByZXRyaWV2ZS5cbiAqIEByZXR1cm5zIEEgc3RyZWFtIHdpdGggdGhlIG9iamVjdCdzIGRhdGEgYXMgYnl0ZXNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFN0cmVhbShcbiAgcmVmOiBTdG9yYWdlUmVmZXJlbmNlLFxuICBtYXhEb3dubG9hZFNpemVCeXRlcz86IG51bWJlclxuKTogUmVhZGFibGVTdHJlYW0ge1xuICB0aHJvdyBuZXcgRXJyb3IoJ2dldFN0cmVhbSgpIGlzIG9ubHkgc3VwcG9ydGVkIGJ5IE5vZGVKUyBidWlsZHMnKTtcbn1cbiIsIi8qKlxuICogQ2xvdWQgU3RvcmFnZSBmb3IgRmlyZWJhc2VcbiAqXG4gKiBAcGFja2FnZURvY3VtZW50YXRpb25cbiAqL1xuXG4vKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAyMCBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGltcG9ydC9uby1leHRyYW5lb3VzLWRlcGVuZGVuY2llc1xuaW1wb3J0IHtcbiAgX3JlZ2lzdGVyQ29tcG9uZW50LFxuICByZWdpc3RlclZlcnNpb24sXG4gIFNES19WRVJTSU9OXG59IGZyb20gJ0BmaXJlYmFzZS9hcHAnO1xuXG5pbXBvcnQgeyBGaXJlYmFzZVN0b3JhZ2VJbXBsIH0gZnJvbSAnLi4vc3JjL3NlcnZpY2UnO1xuaW1wb3J0IHtcbiAgQ29tcG9uZW50LFxuICBDb21wb25lbnRUeXBlLFxuICBDb21wb25lbnRDb250YWluZXIsXG4gIEluc3RhbmNlRmFjdG9yeU9wdGlvbnNcbn0gZnJvbSAnQGZpcmViYXNlL2NvbXBvbmVudCc7XG5cbmltcG9ydCB7IG5hbWUsIHZlcnNpb24gfSBmcm9tICcuLi9wYWNrYWdlLmpzb24nO1xuXG5pbXBvcnQgeyBGaXJlYmFzZVN0b3JhZ2UgfSBmcm9tICcuL3B1YmxpYy10eXBlcyc7XG5pbXBvcnQgeyBTVE9SQUdFX1RZUEUgfSBmcm9tICcuL2NvbnN0YW50cyc7XG5cbmV4cG9ydCAqIGZyb20gJy4vYXBpJztcbmV4cG9ydCAqIGZyb20gJy4vYXBpLmJyb3dzZXInO1xuXG5mdW5jdGlvbiBmYWN0b3J5KFxuICBjb250YWluZXI6IENvbXBvbmVudENvbnRhaW5lcixcbiAgeyBpbnN0YW5jZUlkZW50aWZpZXI6IHVybCB9OiBJbnN0YW5jZUZhY3RvcnlPcHRpb25zXG4pOiBGaXJlYmFzZVN0b3JhZ2Uge1xuICBjb25zdCBhcHAgPSBjb250YWluZXIuZ2V0UHJvdmlkZXIoJ2FwcCcpLmdldEltbWVkaWF0ZSgpO1xuICBjb25zdCBhdXRoUHJvdmlkZXIgPSBjb250YWluZXIuZ2V0UHJvdmlkZXIoJ2F1dGgtaW50ZXJuYWwnKTtcbiAgY29uc3QgYXBwQ2hlY2tQcm92aWRlciA9IGNvbnRhaW5lci5nZXRQcm92aWRlcignYXBwLWNoZWNrLWludGVybmFsJyk7XG5cbiAgcmV0dXJuIG5ldyBGaXJlYmFzZVN0b3JhZ2VJbXBsKFxuICAgIGFwcCxcbiAgICBhdXRoUHJvdmlkZXIsXG4gICAgYXBwQ2hlY2tQcm92aWRlcixcbiAgICB1cmwsXG4gICAgU0RLX1ZFUlNJT05cbiAgKTtcbn1cblxuZnVuY3Rpb24gcmVnaXN0ZXJTdG9yYWdlKCk6IHZvaWQge1xuICBfcmVnaXN0ZXJDb21wb25lbnQoXG4gICAgbmV3IENvbXBvbmVudChcbiAgICAgIFNUT1JBR0VfVFlQRSxcbiAgICAgIGZhY3RvcnksXG4gICAgICBDb21wb25lbnRUeXBlLlBVQkxJQ1xuICAgICkuc2V0TXVsdGlwbGVJbnN0YW5jZXModHJ1ZSlcbiAgKTtcbiAgLy9SVU5USU1FX0VOViB3aWxsIGJlIHJlcGxhY2VkIGR1cmluZyB0aGUgY29tcGlsYXRpb24gdG8gXCJub2RlXCIgZm9yIG5vZGVqcyBhbmQgYW4gZW1wdHkgc3RyaW5nIGZvciBicm93c2VyXG4gIHJlZ2lzdGVyVmVyc2lvbihuYW1lLCB2ZXJzaW9uLCAnX19SVU5USU1FX0VOVl9fJyk7XG4gIC8vIEJVSUxEX1RBUkdFVCB3aWxsIGJlIHJlcGxhY2VkIGJ5IHZhbHVlcyBsaWtlIGVzbSwgY2pzLCBldGMgZHVyaW5nIHRoZSBjb21waWxhdGlvblxuICByZWdpc3RlclZlcnNpb24obmFtZSwgdmVyc2lvbiwgJ19fQlVJTERfVEFSR0VUX18nKTtcbn1cblxucmVnaXN0ZXJTdG9yYWdlKCk7XG4iXSwibmFtZXMiOlsiZ2V0QmxvYiIsImdldE1ldGFkYXRhIiwibGlzdCIsImdldEJ5dGVzIiwidXBkYXRlTWV0YWRhdGEiLCJkZWxldGVPYmplY3QiLCJmYnNBc3luYyIsInVwbG9hZEJ5dGVzIiwidXBsb2FkQnl0ZXNSZXN1bWFibGUiLCJ1cGxvYWRTdHJpbmciLCJsaXN0QWxsIiwicmVxdWVzdHNMaXN0IiwicmVxdWVzdHNHZXRNZXRhZGF0YSIsInJlcXVlc3RzVXBkYXRlTWV0YWRhdGEiLCJnZXREb3dubG9hZFVSTCIsInJlcXVlc3RzR2V0RG93bmxvYWRVcmwiLCJyZXF1ZXN0c0RlbGV0ZU9iamVjdCIsIl9nZXRDaGlsZCIsInJlZiIsImNvbm5lY3RTdG9yYWdlRW11bGF0b3IiLCJ1cGxvYWRCeXRlc0ludGVybmFsIiwidXBsb2FkU3RyaW5nSW50ZXJuYWwiLCJ1cGxvYWRCeXRlc1Jlc3VtYWJsZUludGVybmFsIiwiZ2V0TWV0YWRhdGFJbnRlcm5hbCIsInVwZGF0ZU1ldGFkYXRhSW50ZXJuYWwiLCJsaXN0SW50ZXJuYWwiLCJsaXN0QWxsSW50ZXJuYWwiLCJnZXREb3dubG9hZFVSTEludGVybmFsIiwiZGVsZXRlT2JqZWN0SW50ZXJuYWwiLCJyZWZJbnRlcm5hbCIsIl9nZXRDaGlsZEludGVybmFsIiwiY29ubmVjdEVtdWxhdG9ySW50ZXJuYWwiXSwibWFwcGluZ3MiOiI7Ozs7QUFBQTs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUFDSDs7QUFFRztBQUVIOztBQUVHO0FBQ0ksTUFBTSxZQUFZLEdBQUcsZ0NBQWdDO0FBRTVEOztBQUVHO0FBQ0ksTUFBTSx5QkFBeUIsR0FBRyxlQUFlO0FBRXhEOzs7O0FBSUc7QUFDSSxNQUFNLGdDQUFnQyxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSTtBQUU3RDs7OztBQUlHO0FBQ0ksTUFBTSw2QkFBNkIsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLElBQUk7QUFFM0Q7O0FBRUc7QUFDSSxNQUFNLDZCQUE2QixHQUFHLElBQUk7O0FDL0NqRDs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUFNSDs7O0FBR0c7QUFDRyxNQUFPLFlBQWEsU0FBUSxhQUFhLENBQUE7QUFPN0M7Ozs7O0FBS0c7QUFDSCxJQUFBLFdBQUEsQ0FBWSxJQUFzQixFQUFFLE9BQWUsRUFBVSxVQUFVLENBQUMsRUFBQTtBQUN0RSxRQUFBLEtBQUssQ0FDSCxXQUFXLENBQUMsSUFBSSxDQUFDLEVBQ2pCLENBQUEsa0JBQUEsRUFBcUIsT0FBTyxDQUFBLEVBQUEsRUFBSyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUEsQ0FBQSxDQUFHLENBQ3REO1FBSjBELElBQUEsQ0FBQSxPQUFPLEdBQVAsT0FBTztBQVhwRTs7QUFFRztBQUNILFFBQUEsSUFBQSxDQUFBLFVBQVUsR0FBc0MsRUFBRSxjQUFjLEVBQUUsSUFBSSxFQUFFO0FBYXRFLFFBQUEsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsT0FBTzs7O1FBR2hDLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLFlBQVksQ0FBQyxTQUFTLENBQUM7SUFDckQ7QUFFQSxJQUFBLElBQUksTUFBTSxHQUFBO1FBQ1IsT0FBTyxJQUFJLENBQUMsT0FBTztJQUNyQjtJQUVBLElBQUksTUFBTSxDQUFDLE1BQWMsRUFBQTtBQUN2QixRQUFBLElBQUksQ0FBQyxPQUFPLEdBQUcsTUFBTTtJQUN2QjtBQUVBOztBQUVHO0FBQ0gsSUFBQSxXQUFXLENBQUMsSUFBc0IsRUFBQTtRQUNoQyxPQUFPLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsSUFBSTtJQUN4QztBQUVBOztBQUVHO0FBQ0gsSUFBQSxJQUFJLGNBQWMsR0FBQTtBQUNoQixRQUFBLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjO0lBQ3ZDO0lBRUEsSUFBSSxjQUFjLENBQUMsY0FBNkIsRUFBQTtBQUM5QyxRQUFBLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxHQUFHLGNBQWM7QUFDL0MsUUFBQSxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsY0FBYyxFQUFFO0FBQ2xDLFlBQUEsSUFBSSxDQUFDLE9BQU8sR0FBRyxDQUFBLEVBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQSxFQUFBLEVBQUssSUFBSSxDQUFDLFVBQVUsQ0FBQyxjQUFjLEVBQUU7UUFDMUU7YUFBTztBQUNMLFlBQUEsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsWUFBWTtRQUNsQztJQUNGO0FBQ0Q7QUFJRDs7O0FBR0c7SUFDUztBQUFaLENBQUEsVUFBWSxnQkFBZ0IsRUFBQTs7QUFFMUIsSUFBQSxnQkFBQSxDQUFBLFNBQUEsQ0FBQSxHQUFBLFNBQW1CO0FBQ25CLElBQUEsZ0JBQUEsQ0FBQSxrQkFBQSxDQUFBLEdBQUEsa0JBQXFDO0FBQ3JDLElBQUEsZ0JBQUEsQ0FBQSxrQkFBQSxDQUFBLEdBQUEsa0JBQXFDO0FBQ3JDLElBQUEsZ0JBQUEsQ0FBQSxtQkFBQSxDQUFBLEdBQUEsbUJBQXVDO0FBQ3ZDLElBQUEsZ0JBQUEsQ0FBQSxnQkFBQSxDQUFBLEdBQUEsZ0JBQWlDO0FBQ2pDLElBQUEsZ0JBQUEsQ0FBQSxpQkFBQSxDQUFBLEdBQUEsaUJBQW1DO0FBQ25DLElBQUEsZ0JBQUEsQ0FBQSxjQUFBLENBQUEsR0FBQSxjQUE2QjtBQUM3QixJQUFBLGdCQUFBLENBQUEsa0JBQUEsQ0FBQSxHQUFBLGtCQUFxQztBQUNyQyxJQUFBLGdCQUFBLENBQUEsc0JBQUEsQ0FBQSxHQUFBLHNCQUE2QztBQUM3QyxJQUFBLGdCQUFBLENBQUEsa0JBQUEsQ0FBQSxHQUFBLGtCQUFxQztBQUNyQyxJQUFBLGdCQUFBLENBQUEsVUFBQSxDQUFBLEdBQUEsVUFBcUI7O0FBRXJCLElBQUEsZ0JBQUEsQ0FBQSxvQkFBQSxDQUFBLEdBQUEsb0JBQXlDO0FBQ3pDLElBQUEsZ0JBQUEsQ0FBQSxhQUFBLENBQUEsR0FBQSxhQUEyQjtBQUMzQixJQUFBLGdCQUFBLENBQUEsd0JBQUEsQ0FBQSxHQUFBLHdCQUFpRDtBQUNqRCxJQUFBLGdCQUFBLENBQUEsbUJBQUEsQ0FBQSxHQUFBLG1CQUF1QztBQUN2QyxJQUFBLGdCQUFBLENBQUEsbUJBQUEsQ0FBQSxHQUFBLG1CQUF1QztBQUN2QyxJQUFBLGdCQUFBLENBQUEsd0JBQUEsQ0FBQSxHQUFBLHdCQUFpRDtBQUNqRCxJQUFBLGdCQUFBLENBQUEsaUJBQUEsQ0FBQSxHQUFBLGlCQUFtQztBQUNuQyxJQUFBLGdCQUFBLENBQUEsa0JBQUEsQ0FBQSxHQUFBLGtCQUFxQztBQUNyQyxJQUFBLGdCQUFBLENBQUEsd0JBQUEsQ0FBQSxHQUFBLHdCQUFpRDtBQUNqRCxJQUFBLGdCQUFBLENBQUEsYUFBQSxDQUFBLEdBQUEsYUFBMkI7QUFDM0IsSUFBQSxnQkFBQSxDQUFBLHdCQUFBLENBQUEsR0FBQSx3QkFBaUQ7QUFDakQsSUFBQSxnQkFBQSxDQUFBLGdCQUFBLENBQUEsR0FBQSxnQkFBaUM7QUFDakMsSUFBQSxnQkFBQSxDQUFBLGdCQUFBLENBQUEsR0FBQSxnQkFBaUM7QUFDakMsSUFBQSxnQkFBQSxDQUFBLHlCQUFBLENBQUEsR0FBQSx5QkFBbUQ7QUFDckQsQ0FBQyxFQTVCVyxnQkFBZ0IsS0FBaEIsZ0JBQWdCLEdBQUEsRUFBQSxDQUFBLENBQUE7QUE4QnRCLFNBQVUsV0FBVyxDQUFDLElBQXNCLEVBQUE7SUFDaEQsT0FBTyxVQUFVLEdBQUcsSUFBSTtBQUMxQjtTQUVnQixPQUFPLEdBQUE7SUFDckIsTUFBTSxPQUFPLEdBQ1gsZ0VBQWdFO0FBQ2hFLFFBQUEsa0JBQWtCO0lBQ3BCLE9BQU8sSUFBSSxZQUFZLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQztBQUM1RDtBQUVNLFNBQVUsY0FBYyxDQUFDLElBQVksRUFBQTtBQUN6QyxJQUFBLE9BQU8sSUFBSSxZQUFZLENBQ3JCLGdCQUFnQixDQUFDLGdCQUFnQixFQUNqQyxVQUFVLEdBQUcsSUFBSSxHQUFHLG1CQUFtQixDQUN4QztBQUNIO0FBZ0JNLFNBQVUsYUFBYSxDQUFDLE1BQWMsRUFBQTtBQUMxQyxJQUFBLE9BQU8sSUFBSSxZQUFZLENBQ3JCLGdCQUFnQixDQUFDLGNBQWMsRUFDL0Isb0JBQW9CO1FBQ2xCLE1BQU07UUFDTixtQ0FBbUM7QUFDbkMsUUFBQSx1Q0FBdUMsQ0FDMUM7QUFDSDtTQUVnQixlQUFlLEdBQUE7SUFDN0IsTUFBTSxPQUFPLEdBQ1gsZ0VBQWdFO0FBQ2hFLFFBQUEsK0JBQStCO0lBQ2pDLE9BQU8sSUFBSSxZQUFZLENBQUMsZ0JBQWdCLENBQUMsZUFBZSxFQUFFLE9BQU8sQ0FBQztBQUNwRTtTQUVnQixlQUFlLEdBQUE7SUFDN0IsT0FBTyxJQUFJLFlBQVksQ0FDckIsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQ2pDLCtFQUErRSxDQUNoRjtBQUNIO0FBRU0sU0FBVSxZQUFZLENBQUMsSUFBWSxFQUFBO0FBQ3ZDLElBQUEsT0FBTyxJQUFJLFlBQVksQ0FDckIsZ0JBQWdCLENBQUMsWUFBWSxFQUM3QiwyQ0FBMkMsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUMxRDtBQUNIO1NBRWdCLGtCQUFrQixHQUFBO0lBQ2hDLE9BQU8sSUFBSSxZQUFZLENBQ3JCLGdCQUFnQixDQUFDLG9CQUFvQixFQUNyQywwREFBMEQsQ0FDM0Q7QUFDSDtTQW1CZ0IsUUFBUSxHQUFBO0lBQ3RCLE9BQU8sSUFBSSxZQUFZLENBQ3JCLGdCQUFnQixDQUFDLFFBQVEsRUFDekIsb0NBQW9DLENBQ3JDO0FBQ0g7QUFTTSxTQUFVLFVBQVUsQ0FBQyxHQUFXLEVBQUE7QUFDcEMsSUFBQSxPQUFPLElBQUksWUFBWSxDQUNyQixnQkFBZ0IsQ0FBQyxXQUFXLEVBQzVCLGVBQWUsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUM3QjtBQUNIO0FBRU0sU0FBVSxvQkFBb0IsQ0FBQyxNQUFjLEVBQUE7QUFDakQsSUFBQSxPQUFPLElBQUksWUFBWSxDQUNyQixnQkFBZ0IsQ0FBQyxzQkFBc0IsRUFDdkMsMEJBQTBCLEdBQUcsTUFBTSxHQUFHLElBQUksQ0FDM0M7QUFDSDtTQUVnQixlQUFlLEdBQUE7QUFDN0IsSUFBQSxPQUFPLElBQUksWUFBWSxDQUNyQixnQkFBZ0IsQ0FBQyxpQkFBaUIsRUFDbEMsb0JBQW9CO1FBQ2xCLDBCQUEwQjtRQUMxQix5QkFBeUI7QUFDekIsUUFBQSx1Q0FBdUMsQ0FDMUM7QUFDSDtTQUVnQixlQUFlLEdBQUE7SUFDN0IsT0FBTyxJQUFJLFlBQVksQ0FDckIsZ0JBQWdCLENBQUMsaUJBQWlCLEVBQ2xDLHdEQUF3RCxDQUN6RDtBQUNIO1NBRWdCLG1CQUFtQixHQUFBO0lBQ2pDLE9BQU8sSUFBSSxZQUFZLENBQ3JCLGdCQUFnQixDQUFDLHNCQUFzQixFQUN2QyxzRUFBc0UsQ0FDdkU7QUFDSDtTQUVnQixhQUFhLEdBQUE7SUFDM0IsT0FBTyxJQUFJLFlBQVksQ0FDckIsZ0JBQWdCLENBQUMsZUFBZSxFQUNoQyxpREFBaUQsQ0FDbEQ7QUFDSDtBQUVNLFNBQVUsZUFBZSxDQUFDLFFBQWdCLEVBQUE7SUFDOUMsT0FBTyxJQUFJLFlBQVksQ0FDckIsZ0JBQWdCLENBQUMsdUJBQXVCLEVBQ3hDLENBQUEsRUFBRyxRQUFRLENBQUEsc0pBQUEsQ0FBd0osQ0FDcEs7QUFDSDtBQUVBOztBQUVHO0FBQ0csU0FBVSxlQUFlLENBQUMsT0FBZSxFQUFBO0lBQzdDLE9BQU8sSUFBSSxZQUFZLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDO0FBQ3JFO1NBK0JnQixVQUFVLEdBQUE7SUFDeEIsT0FBTyxJQUFJLFlBQVksQ0FDckIsZ0JBQWdCLENBQUMsV0FBVyxFQUM1QiwrQkFBK0IsQ0FDaEM7QUFDSDtBQUVBOzs7O0FBSUc7QUFDRyxTQUFVLG9CQUFvQixDQUFDLElBQVksRUFBQTtBQUMvQyxJQUFBLE9BQU8sSUFBSSxZQUFZLENBQ3JCLGdCQUFnQixDQUFDLHNCQUFzQixFQUN2QyxpQkFBaUI7UUFDZixJQUFJO1FBQ0osK0RBQStEO0FBQy9ELFFBQUEsb0RBQW9ELENBQ3ZEO0FBQ0g7QUFFQTs7O0FBR0c7QUFDRyxTQUFVLGFBQWEsQ0FBQyxNQUFjLEVBQUUsT0FBZSxFQUFBO0FBQzNELElBQUEsT0FBTyxJQUFJLFlBQVksQ0FDckIsZ0JBQWdCLENBQUMsY0FBYyxFQUMvQixnQ0FBZ0MsR0FBRyxNQUFNLEdBQUcsS0FBSyxHQUFHLE9BQU8sQ0FDNUQ7QUFDSDtBQVNBOztBQUVHO0FBQ0csU0FBVSxhQUFhLENBQUMsT0FBZSxFQUFBO0lBQzNDLE1BQU0sSUFBSSxZQUFZLENBQ3BCLGdCQUFnQixDQUFDLGNBQWMsRUFDL0Isa0JBQWtCLEdBQUcsT0FBTyxDQUM3QjtBQUNIOztBQ2xXQTs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUFFSDs7O0FBR0c7QUFLSDs7OztBQUlHO01BQ1UsUUFBUSxDQUFBO0lBR25CLFdBQUEsQ0FBNEIsTUFBYyxFQUFFLElBQVksRUFBQTtRQUE1QixJQUFBLENBQUEsTUFBTSxHQUFOLE1BQU07QUFDaEMsUUFBQSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUk7SUFDbkI7QUFFQSxJQUFBLElBQUksSUFBSSxHQUFBO1FBQ04sT0FBTyxJQUFJLENBQUMsS0FBSztJQUNuQjtBQUVBLElBQUEsSUFBSSxNQUFNLEdBQUE7QUFDUixRQUFBLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEtBQUssQ0FBQztJQUMvQjtJQUVBLGFBQWEsR0FBQTtRQUNYLE1BQU0sTUFBTSxHQUFHLGtCQUFrQjtBQUNqQyxRQUFBLE9BQU8sS0FBSyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsS0FBSyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQ2hFO0lBRUEsbUJBQW1CLEdBQUE7UUFDakIsTUFBTSxNQUFNLEdBQUcsa0JBQWtCO1FBQ2pDLE9BQU8sS0FBSyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSTtJQUMzQztBQUVBLElBQUEsT0FBTyxrQkFBa0IsQ0FBQyxZQUFvQixFQUFFLElBQVksRUFBQTtBQUMxRCxRQUFBLElBQUksY0FBYztBQUNsQixRQUFBLElBQUk7WUFDRixjQUFjLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDO1FBQzNEO1FBQUUsT0FBTyxDQUFDLEVBQUU7OztBQUdWLFlBQUEsT0FBTyxJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDO1FBQ3ZDO0FBQ0EsUUFBQSxJQUFJLGNBQWMsQ0FBQyxJQUFJLEtBQUssRUFBRSxFQUFFO0FBQzlCLFlBQUEsT0FBTyxjQUFjO1FBQ3ZCO2FBQU87QUFDTCxZQUFBLE1BQU0sb0JBQW9CLENBQUMsWUFBWSxDQUFDO1FBQzFDO0lBQ0Y7QUFFQSxJQUFBLE9BQU8sV0FBVyxDQUFDLEdBQVcsRUFBRSxJQUFZLEVBQUE7UUFDMUMsSUFBSSxRQUFRLEdBQW9CLElBQUk7UUFDcEMsTUFBTSxZQUFZLEdBQUcscUJBQXFCO1FBRTFDLFNBQVMsUUFBUSxDQUFDLEdBQWEsRUFBQTtBQUM3QixZQUFBLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO0FBQ2hELGdCQUFBLEdBQUcsQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUNwQztRQUNGO1FBQ0EsTUFBTSxNQUFNLEdBQUcsV0FBVztBQUMxQixRQUFBLE1BQU0sT0FBTyxHQUFHLElBQUksTUFBTSxDQUFDLFFBQVEsR0FBRyxZQUFZLEdBQUcsTUFBTSxFQUFFLEdBQUcsQ0FBQztRQUNqRSxNQUFNLFNBQVMsR0FBRyxFQUFFLE1BQU0sRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRTtRQUV4QyxTQUFTLFVBQVUsQ0FBQyxHQUFhLEVBQUE7WUFDL0IsR0FBRyxDQUFDLEtBQUssR0FBRyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQzFDO1FBQ0EsTUFBTSxPQUFPLEdBQUcsZ0JBQWdCO1FBQ2hDLE1BQU0sbUJBQW1CLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDO1FBQ3ZELE1BQU0sbUJBQW1CLEdBQUcsaUJBQWlCO0FBQzdDLFFBQUEsTUFBTSxxQkFBcUIsR0FBRyxJQUFJLE1BQU0sQ0FDdEMsYUFBYSxtQkFBbUIsQ0FBQSxDQUFBLEVBQUksT0FBTyxDQUFBLEdBQUEsRUFBTSxZQUFZLENBQUEsRUFBQSxFQUFLLG1CQUFtQixFQUFFLEVBQ3ZGLEdBQUcsQ0FDSjtRQUNELE1BQU0sc0JBQXNCLEdBQUcsRUFBRSxNQUFNLEVBQUUsQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUU7QUFFckQsUUFBQSxNQUFNLGdCQUFnQixHQUNwQixJQUFJLEtBQUs7QUFDUCxjQUFFO2NBQ0EsSUFBSTtRQUNWLE1BQU0sZ0JBQWdCLEdBQUcsVUFBVTtBQUNuQyxRQUFBLE1BQU0sa0JBQWtCLEdBQUcsSUFBSSxNQUFNLENBQ25DLENBQUEsVUFBQSxFQUFhLGdCQUFnQixDQUFBLENBQUEsRUFBSSxZQUFZLElBQUksZ0JBQWdCLENBQUEsQ0FBRSxFQUNuRSxHQUFHLENBQ0o7UUFDRCxNQUFNLG1CQUFtQixHQUFHLEVBQUUsTUFBTSxFQUFFLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFO0FBRWxELFFBQUEsTUFBTSxNQUFNLEdBQUc7WUFDYixFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxVQUFVLEVBQUUsUUFBUSxFQUFFO0FBQzVELFlBQUE7QUFDRSxnQkFBQSxLQUFLLEVBQUUscUJBQXFCO0FBQzVCLGdCQUFBLE9BQU8sRUFBRSxzQkFBc0I7QUFDL0IsZ0JBQUEsVUFBVSxFQUFFO0FBQ2IsYUFBQTtBQUNELFlBQUE7QUFDRSxnQkFBQSxLQUFLLEVBQUUsa0JBQWtCO0FBQ3pCLGdCQUFBLE9BQU8sRUFBRSxtQkFBbUI7QUFDNUIsZ0JBQUEsVUFBVSxFQUFFO0FBQ2I7U0FDRjtBQUNELFFBQUEsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDdEMsWUFBQSxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ3ZCLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztZQUN0QyxJQUFJLFFBQVEsRUFBRTtnQkFDWixNQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7Z0JBQ2xELElBQUksU0FBUyxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztnQkFDNUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtvQkFDZCxTQUFTLEdBQUcsRUFBRTtnQkFDaEI7Z0JBQ0EsUUFBUSxHQUFHLElBQUksUUFBUSxDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUM7QUFDL0MsZ0JBQUEsS0FBSyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUM7Z0JBQzFCO1lBQ0Y7UUFDRjtBQUNBLFFBQUEsSUFBSSxRQUFRLElBQUksSUFBSSxFQUFFO0FBQ3BCLFlBQUEsTUFBTSxVQUFVLENBQUMsR0FBRyxDQUFDO1FBQ3ZCO0FBQ0EsUUFBQSxPQUFPLFFBQVE7SUFDakI7QUFDRDs7QUN4SEQ7O0FBRUc7TUFDVSxXQUFXLENBQUE7QUFHdEIsSUFBQSxXQUFBLENBQVksS0FBbUIsRUFBQTtRQUM3QixJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUksS0FBSyxDQUFDO0lBQzFDOztJQUdBLFVBQVUsR0FBQTtRQUNSLE9BQU8sSUFBSSxDQUFDLFFBQVE7SUFDdEI7O0FBR0EsSUFBQSxNQUFNLENBQUMsVUFBVSxHQUFHLEtBQUssSUFBUztBQUNuQzs7QUNwQ0Q7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBVUg7Ozs7Ozs7Ozs7O0FBV0c7QUFDRyxTQUFVLEtBQUssQ0FDbkIsU0FHUztBQUNUO0FBQ0EsaUJBQThDLEVBQzlDLE9BQWUsRUFBQTs7O0lBSWYsSUFBSSxXQUFXLEdBQUcsQ0FBQzs7OztJQUluQixJQUFJLGNBQWMsR0FBUSxJQUFJOztJQUU5QixJQUFJLGVBQWUsR0FBUSxJQUFJO0lBQy9CLElBQUksVUFBVSxHQUFHLEtBQUs7SUFDdEIsSUFBSSxXQUFXLEdBQUcsQ0FBQztBQUVuQixJQUFBLFNBQVMsUUFBUSxHQUFBO1FBQ2YsT0FBTyxXQUFXLEtBQUssQ0FBQztJQUMxQjtJQUNBLElBQUksaUJBQWlCLEdBQUcsS0FBSztJQUU3QixTQUFTLGVBQWUsQ0FBQyxHQUFHLElBQVcsRUFBQTtRQUNyQyxJQUFJLENBQUMsaUJBQWlCLEVBQUU7WUFDdEIsaUJBQWlCLEdBQUcsSUFBSTtBQUN4QixZQUFBLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDO1FBQ3JDO0lBQ0Y7SUFFQSxTQUFTLGFBQWEsQ0FBQyxNQUFjLEVBQUE7QUFDbkMsUUFBQSxjQUFjLEdBQUcsVUFBVSxDQUFDLE1BQUs7WUFDL0IsY0FBYyxHQUFHLElBQUk7QUFDckIsWUFBQSxTQUFTLENBQUMsZUFBZSxFQUFFLFFBQVEsRUFBRSxDQUFDO1FBQ3hDLENBQUMsRUFBRSxNQUFNLENBQUM7SUFDWjtBQUVBLElBQUEsU0FBUyxrQkFBa0IsR0FBQTtRQUN6QixJQUFJLGVBQWUsRUFBRTtZQUNuQixZQUFZLENBQUMsZUFBZSxDQUFDO1FBQy9CO0lBQ0Y7QUFFQSxJQUFBLFNBQVMsZUFBZSxDQUFDLE9BQWdCLEVBQUUsR0FBRyxJQUFXLEVBQUE7UUFDdkQsSUFBSSxpQkFBaUIsRUFBRTtBQUNyQixZQUFBLGtCQUFrQixFQUFFO1lBQ3BCO1FBQ0Y7UUFDQSxJQUFJLE9BQU8sRUFBRTtBQUNYLFlBQUEsa0JBQWtCLEVBQUU7WUFDcEIsZUFBZSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDO1lBQzVDO1FBQ0Y7QUFDQSxRQUFBLE1BQU0sUUFBUSxHQUFHLFFBQVEsRUFBRSxJQUFJLFVBQVU7UUFDekMsSUFBSSxRQUFRLEVBQUU7QUFDWixZQUFBLGtCQUFrQixFQUFFO1lBQ3BCLGVBQWUsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxHQUFHLElBQUksQ0FBQztZQUM1QztRQUNGO0FBQ0EsUUFBQSxJQUFJLFdBQVcsR0FBRyxFQUFFLEVBQUU7O1lBRXBCLFdBQVcsSUFBSSxDQUFDO1FBQ2xCO0FBQ0EsUUFBQSxJQUFJLFVBQVU7QUFDZCxRQUFBLElBQUksV0FBVyxLQUFLLENBQUMsRUFBRTtZQUNyQixXQUFXLEdBQUcsQ0FBQztZQUNmLFVBQVUsR0FBRyxDQUFDO1FBQ2hCO2FBQU87WUFDTCxVQUFVLEdBQUcsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLElBQUk7UUFDbkQ7UUFDQSxhQUFhLENBQUMsVUFBVSxDQUFDO0lBQzNCO0lBQ0EsSUFBSSxPQUFPLEdBQUcsS0FBSztJQUVuQixTQUFTLElBQUksQ0FBQyxVQUFtQixFQUFBO1FBQy9CLElBQUksT0FBTyxFQUFFO1lBQ1g7UUFDRjtRQUNBLE9BQU8sR0FBRyxJQUFJO0FBQ2QsUUFBQSxrQkFBa0IsRUFBRTtRQUNwQixJQUFJLGlCQUFpQixFQUFFO1lBQ3JCO1FBQ0Y7QUFDQSxRQUFBLElBQUksY0FBYyxLQUFLLElBQUksRUFBRTtZQUMzQixJQUFJLENBQUMsVUFBVSxFQUFFO2dCQUNmLFdBQVcsR0FBRyxDQUFDO1lBQ2pCO1lBQ0EsWUFBWSxDQUFDLGNBQWMsQ0FBQztZQUM1QixhQUFhLENBQUMsQ0FBQyxDQUFDO1FBQ2xCO2FBQU87WUFDTCxJQUFJLENBQUMsVUFBVSxFQUFFO2dCQUNmLFdBQVcsR0FBRyxDQUFDO1lBQ2pCO1FBQ0Y7SUFDRjtJQUNBLGFBQWEsQ0FBQyxDQUFDLENBQUM7QUFDaEIsSUFBQSxlQUFlLEdBQUcsVUFBVSxDQUFDLE1BQUs7UUFDaEMsVUFBVSxHQUFHLElBQUk7UUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQztJQUNaLENBQUMsRUFBRSxPQUFPLENBQUM7QUFDWCxJQUFBLE9BQU8sSUFBSTtBQUNiO0FBRUE7Ozs7OztBQU1HO0FBQ0csU0FBVSxJQUFJLENBQUMsRUFBTSxFQUFBO0lBQ3pCLEVBQUUsQ0FBQyxLQUFLLENBQUM7QUFDWDs7QUN4SkE7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBSUcsU0FBVSxTQUFTLENBQUksQ0FBdUIsRUFBQTtBQUNsRCxJQUFBLE9BQU8sQ0FBQyxLQUFLLE1BQU07QUFDckI7QUFFQTtBQUNNLFNBQVUsVUFBVSxDQUFDLENBQVUsRUFBQTtBQUNuQyxJQUFBLE9BQU8sT0FBTyxDQUFDLEtBQUssVUFBVTtBQUNoQztBQUVNLFNBQVUsZ0JBQWdCLENBQUMsQ0FBVSxFQUFBO0FBQ3pDLElBQUEsT0FBTyxPQUFPLENBQUMsS0FBSyxRQUFRLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUNuRDtBQUVNLFNBQVUsUUFBUSxDQUFDLENBQVUsRUFBQTtJQUNqQyxPQUFPLE9BQU8sQ0FBQyxLQUFLLFFBQVEsSUFBSSxDQUFDLFlBQVksTUFBTTtBQUNyRDtBQUVNLFNBQVUsWUFBWSxDQUFDLENBQVUsRUFBQTtBQUNyQyxJQUFBLE9BQU8sbUJBQW1CLEVBQUUsSUFBSSxDQUFDLFlBQVksSUFBSTtBQUNuRDtTQUVnQixtQkFBbUIsR0FBQTtBQUNqQyxJQUFBLE9BQU8sT0FBTyxJQUFJLEtBQUssV0FBVztBQUNwQztBQUVNLFNBQVUsY0FBYyxDQUM1QixRQUFnQixFQUNoQixRQUFnQixFQUNoQixRQUFnQixFQUNoQixLQUFhLEVBQUE7QUFFYixJQUFBLElBQUksS0FBSyxHQUFHLFFBQVEsRUFBRTtRQUNwQixNQUFNLGVBQWUsQ0FDbkIsQ0FBQSxtQkFBQSxFQUFzQixRQUFRLGVBQWUsUUFBUSxDQUFBLFlBQUEsQ0FBYyxDQUNwRTtJQUNIO0FBQ0EsSUFBQSxJQUFJLEtBQUssR0FBRyxRQUFRLEVBQUU7UUFDcEIsTUFBTSxlQUFlLENBQ25CLENBQUEsbUJBQUEsRUFBc0IsUUFBUSxlQUFlLFFBQVEsQ0FBQSxTQUFBLENBQVcsQ0FDakU7SUFDSDtBQUNGOztBQzVEQTs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7U0FPYSxPQUFPLENBQ3JCLE9BQWUsRUFDZixJQUFZLEVBQ1osUUFBZ0IsRUFBQTtJQUVoQixJQUFJLE1BQU0sR0FBRyxJQUFJO0FBQ2pCLElBQUEsSUFBSSxRQUFRLElBQUksSUFBSSxFQUFFO0FBQ3BCLFFBQUEsTUFBTSxHQUFHLENBQUEsUUFBQSxFQUFXLElBQUksQ0FBQSxDQUFFO0lBQzVCO0FBQ0EsSUFBQSxPQUFPLEdBQUcsUUFBUSxDQUFBLEdBQUEsRUFBTSxNQUFNLENBQUEsR0FBQSxFQUFNLE9BQU8sRUFBRTtBQUMvQztBQUVNLFNBQVUsZUFBZSxDQUFDLE1BQWlCLEVBQUE7SUFDL0MsTUFBTSxNQUFNLEdBQUcsa0JBQWtCO0lBQ2pDLElBQUksU0FBUyxHQUFHLEdBQUc7QUFDbkIsSUFBQSxLQUFLLE1BQU0sR0FBRyxJQUFJLE1BQU0sRUFBRTtBQUN4QixRQUFBLElBQUksTUFBTSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBRTtBQUM5QixZQUFBLE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN4RCxZQUFBLFNBQVMsR0FBRyxTQUFTLEdBQUcsUUFBUSxHQUFHLEdBQUc7UUFDeEM7SUFDRjs7SUFHQSxTQUFTLEdBQUcsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDO0FBQ2xDLElBQUEsT0FBTyxTQUFTO0FBQ2xCOztBQ3NCQTs7QUFFRztBQUNILElBQVksU0FJWDtBQUpELENBQUEsVUFBWSxTQUFTLEVBQUE7QUFDbkIsSUFBQSxTQUFBLENBQUEsU0FBQSxDQUFBLFVBQUEsQ0FBQSxHQUFBLENBQUEsQ0FBQSxHQUFBLFVBQVk7QUFDWixJQUFBLFNBQUEsQ0FBQSxTQUFBLENBQUEsZUFBQSxDQUFBLEdBQUEsQ0FBQSxDQUFBLEdBQUEsZUFBaUI7QUFDakIsSUFBQSxTQUFBLENBQUEsU0FBQSxDQUFBLE9BQUEsQ0FBQSxHQUFBLENBQUEsQ0FBQSxHQUFBLE9BQVM7QUFDWCxDQUFDLEVBSlcsU0FBUyxLQUFULFNBQVMsR0FBQSxFQUFBLENBQUEsQ0FBQTs7QUN4RXJCOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztBQUVIOzs7OztBQUtHO0FBQ0csU0FBVSxpQkFBaUIsQ0FDL0IsTUFBYyxFQUNkLG9CQUE4QixFQUFBOzs7SUFJOUIsTUFBTSxpQkFBaUIsR0FBRyxNQUFNLElBQUksR0FBRyxJQUFJLE1BQU0sR0FBRyxHQUFHO0FBQ3ZELElBQUEsTUFBTSxlQUFlLEdBQUc7O1FBRXRCLEdBQUc7O1FBRUg7S0FDRDtJQUNELE1BQU0sZ0JBQWdCLEdBQUcsZUFBZSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO0lBQy9ELE1BQU0scUJBQXFCLEdBQUcsb0JBQW9CLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7QUFDekUsSUFBQSxPQUFPLGlCQUFpQixJQUFJLGdCQUFnQixJQUFJLHFCQUFxQjtBQUN2RTs7QUN2Q0E7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBRUg7OztBQUdHO0FBdUJIOzs7Ozs7O0FBT0c7QUFDSCxNQUFNLGNBQWMsQ0FBQTtJQVVsQixXQUFBLENBQ1UsSUFBWSxFQUNaLE9BQWUsRUFDZixRQUFpQixFQUNqQixLQUF3QyxFQUN4QyxhQUF1QixFQUN2QixxQkFBK0IsRUFDL0IsU0FBK0IsRUFDL0IsY0FBbUMsRUFDbkMsUUFBZ0IsRUFDaEIsaUJBQTRELEVBQzVELGtCQUF1QyxFQUN2QyxLQUFBLEdBQVEsSUFBSSxFQUNaLGVBQUEsR0FBa0IsS0FBSyxFQUFBO1FBWnZCLElBQUEsQ0FBQSxJQUFJLEdBQUosSUFBSTtRQUNKLElBQUEsQ0FBQSxPQUFPLEdBQVAsT0FBTztRQUNQLElBQUEsQ0FBQSxRQUFRLEdBQVIsUUFBUTtRQUNSLElBQUEsQ0FBQSxLQUFLLEdBQUwsS0FBSztRQUNMLElBQUEsQ0FBQSxhQUFhLEdBQWIsYUFBYTtRQUNiLElBQUEsQ0FBQSxxQkFBcUIsR0FBckIscUJBQXFCO1FBQ3JCLElBQUEsQ0FBQSxTQUFTLEdBQVQsU0FBUztRQUNULElBQUEsQ0FBQSxjQUFjLEdBQWQsY0FBYztRQUNkLElBQUEsQ0FBQSxRQUFRLEdBQVIsUUFBUTtRQUNSLElBQUEsQ0FBQSxpQkFBaUIsR0FBakIsaUJBQWlCO1FBQ2pCLElBQUEsQ0FBQSxrQkFBa0IsR0FBbEIsa0JBQWtCO1FBQ2xCLElBQUEsQ0FBQSxLQUFLLEdBQUwsS0FBSztRQUNMLElBQUEsQ0FBQSxlQUFlLEdBQWYsZUFBZTtRQXRCakIsSUFBQSxDQUFBLGtCQUFrQixHQUF5QixJQUFJO1FBQy9DLElBQUEsQ0FBQSxVQUFVLEdBQXFCLElBQUk7UUFJbkMsSUFBQSxDQUFBLFNBQVMsR0FBWSxLQUFLO1FBQzFCLElBQUEsQ0FBQSxVQUFVLEdBQVksS0FBSztRQWtCakMsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEtBQUk7QUFDOUMsWUFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLE9BQStDO0FBQy9ELFlBQUEsSUFBSSxDQUFDLE9BQU8sR0FBRyxNQUFNO1lBQ3JCLElBQUksQ0FBQyxNQUFNLEVBQUU7QUFDZixRQUFBLENBQUMsQ0FBQztJQUNKO0FBRUE7O0FBRUc7SUFDSyxNQUFNLEdBQUE7QUFDWixRQUFBLE1BQU0sWUFBWSxHQUdOLENBQUMsZUFBZSxFQUFFLFFBQVEsS0FBSTtZQUN4QyxJQUFJLFFBQVEsRUFBRTtBQUNaLGdCQUFBLGVBQWUsQ0FBQyxLQUFLLEVBQUUsSUFBSSxnQkFBZ0IsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO2dCQUMvRDtZQUNGO0FBQ0EsWUFBQSxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsa0JBQWtCLEVBQUU7QUFDNUMsWUFBQSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsVUFBVTtBQUVwQyxZQUFBLE1BQU0sZ0JBQWdCLEdBRVYsYUFBYSxJQUFHO0FBQzFCLGdCQUFBLE1BQU0sTUFBTSxHQUFHLGFBQWEsQ0FBQyxNQUFNO0FBQ25DLGdCQUFBLE1BQU0sS0FBSyxHQUFHLGFBQWEsQ0FBQyxnQkFBZ0IsR0FBRyxhQUFhLENBQUMsS0FBSyxHQUFHLEVBQUU7QUFDdkUsZ0JBQUEsSUFBSSxJQUFJLENBQUMsaUJBQWlCLEtBQUssSUFBSSxFQUFFO0FBQ25DLG9CQUFBLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDO2dCQUN2QztBQUNGLFlBQUEsQ0FBQztBQUNELFlBQUEsSUFBSSxJQUFJLENBQUMsaUJBQWlCLEtBQUssSUFBSSxFQUFFO0FBQ25DLGdCQUFBLFVBQVUsQ0FBQyx5QkFBeUIsQ0FBQyxnQkFBZ0IsQ0FBQztZQUN4RDs7O1lBSUE7aUJBQ0csSUFBSSxDQUNILElBQUksQ0FBQyxJQUFJLEVBQ1QsSUFBSSxDQUFDLE9BQU8sRUFDWixJQUFJLENBQUMsZUFBZSxFQUNwQixJQUFJLENBQUMsS0FBSyxFQUNWLElBQUksQ0FBQyxRQUFRO2lCQUVkLElBQUksQ0FBQyxNQUFLO0FBQ1QsZ0JBQUEsSUFBSSxJQUFJLENBQUMsaUJBQWlCLEtBQUssSUFBSSxFQUFFO0FBQ25DLG9CQUFBLFVBQVUsQ0FBQyw0QkFBNEIsQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDM0Q7QUFDQSxnQkFBQSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSTtnQkFDOUIsTUFBTSxTQUFTLEdBQUcsVUFBVSxDQUFDLFlBQVksRUFBRSxLQUFLLFNBQVMsQ0FBQyxRQUFRO0FBQ2xFLGdCQUFBLE1BQU0sTUFBTSxHQUFHLFVBQVUsQ0FBQyxTQUFTLEVBQUU7QUFDckMsZ0JBQUEsSUFDRSxDQUFDLFNBQVM7QUFDVixxQkFBQyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLHFCQUFxQixDQUFDO0FBQ3BELHdCQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsRUFDYjtvQkFDQSxNQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsWUFBWSxFQUFFLEtBQUssU0FBUyxDQUFDLEtBQUs7QUFDakUsb0JBQUEsZUFBZSxDQUNiLEtBQUssRUFDTCxJQUFJLGdCQUFnQixDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQy9DO29CQUNEO2dCQUNGO0FBQ0EsZ0JBQUEsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtnQkFDN0QsZUFBZSxDQUFDLElBQUksRUFBRSxJQUFJLGdCQUFnQixDQUFDLFdBQVcsRUFBRSxVQUFVLENBQUMsQ0FBQztBQUN0RSxZQUFBLENBQUMsQ0FBQztBQUNOLFFBQUEsQ0FBQztBQUVEOzs7QUFHRztBQUNILFFBQUEsTUFBTSxXQUFXLEdBR0wsQ0FBQyxrQkFBa0IsRUFBRSxNQUFNLEtBQUk7QUFDekMsWUFBQSxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsUUFBUTtBQUM3QixZQUFBLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPO0FBQzNCLFlBQUEsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLFVBQTJCO0FBQ3JELFlBQUEsSUFBSSxNQUFNLENBQUMsY0FBYyxFQUFFO0FBQ3pCLGdCQUFBLElBQUk7QUFDRixvQkFBQSxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxVQUFVLENBQUMsV0FBVyxFQUFFLENBQUM7QUFDbkUsb0JBQUEsSUFBSSxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUU7d0JBQ3JCLE9BQU8sQ0FBQyxNQUFNLENBQUM7b0JBQ2pCO3lCQUFPO0FBQ0wsd0JBQUEsT0FBTyxFQUFFO29CQUNYO2dCQUNGO2dCQUFFLE9BQU8sQ0FBQyxFQUFFO29CQUNWLE1BQU0sQ0FBQyxDQUFDLENBQUM7Z0JBQ1g7WUFDRjtpQkFBTztBQUNMLGdCQUFBLElBQUksVUFBVSxLQUFLLElBQUksRUFBRTtBQUN2QixvQkFBQSxNQUFNLEdBQUcsR0FBRyxPQUFPLEVBQUU7QUFDckIsb0JBQUEsR0FBRyxDQUFDLGNBQWMsR0FBRyxVQUFVLENBQUMsWUFBWSxFQUFFO0FBQzlDLG9CQUFBLElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRTt3QkFDdkIsTUFBTSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxDQUFDO29CQUM5Qzt5QkFBTzt3QkFDTCxNQUFNLENBQUMsR0FBRyxDQUFDO29CQUNiO2dCQUNGO3FCQUFPO0FBQ0wsb0JBQUEsSUFBSSxNQUFNLENBQUMsUUFBUSxFQUFFO0FBQ25CLHdCQUFBLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxFQUFFLEdBQUcsUUFBUSxFQUFFO3dCQUN2RCxNQUFNLENBQUMsR0FBRyxDQUFDO29CQUNiO3lCQUFPO0FBQ0wsd0JBQUEsTUFBTSxHQUFHLEdBQUcsa0JBQWtCLEVBQUU7d0JBQ2hDLE1BQU0sQ0FBQyxHQUFHLENBQUM7b0JBQ2I7Z0JBQ0Y7WUFDRjtBQUNGLFFBQUEsQ0FBQztBQUNELFFBQUEsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFO0FBQ2xCLFlBQUEsV0FBVyxDQUFDLEtBQUssRUFBRSxJQUFJLGdCQUFnQixDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDN0Q7YUFBTztBQUNMLFlBQUEsSUFBSSxDQUFDLFVBQVUsR0FBRyxLQUFLLENBQUMsWUFBWSxFQUFFLFdBQVcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDO1FBQ25FO0lBQ0Y7O0lBR0EsVUFBVSxHQUFBO1FBQ1IsT0FBTyxJQUFJLENBQUMsUUFBUTtJQUN0Qjs7QUFHQSxJQUFBLE1BQU0sQ0FBQyxTQUFtQixFQUFBO0FBQ3hCLFFBQUEsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJO0FBQ3JCLFFBQUEsSUFBSSxDQUFDLFVBQVUsR0FBRyxTQUFTLElBQUksS0FBSztBQUNwQyxRQUFBLElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxJQUFJLEVBQUU7QUFDNUIsWUFBQSxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUN2QjtBQUNBLFFBQUEsSUFBSSxJQUFJLENBQUMsa0JBQWtCLEtBQUssSUFBSSxFQUFFO0FBQ3BDLFlBQUEsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssRUFBRTtRQUNqQztJQUNGO0FBQ0Q7QUFFRDs7O0FBR0c7TUFDVSxnQkFBZ0IsQ0FBQTtBQU0zQixJQUFBLFdBQUEsQ0FDUyxjQUF1QixFQUN2QixVQUFnQyxFQUN2QyxRQUFrQixFQUFBO1FBRlgsSUFBQSxDQUFBLGNBQWMsR0FBZCxjQUFjO1FBQ2QsSUFBQSxDQUFBLFVBQVUsR0FBVixVQUFVO0FBR2pCLFFBQUEsSUFBSSxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUMsUUFBUTtJQUM1QjtBQUNEO0FBRUssU0FBVSxjQUFjLENBQzVCLE9BQWdCLEVBQ2hCLFNBQXdCLEVBQUE7SUFFeEIsSUFBSSxTQUFTLEtBQUssSUFBSSxJQUFJLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO0FBQzlDLFFBQUEsT0FBTyxDQUFDLGVBQWUsQ0FBQyxHQUFHLFdBQVcsR0FBRyxTQUFTO0lBQ3BEO0FBQ0Y7QUFFTSxTQUFVLGlCQUFpQixDQUMvQixPQUFnQixFQUNoQixlQUF3QixFQUFBO0lBRXhCLE9BQU8sQ0FBQyw0QkFBNEIsQ0FBQztBQUNuQyxRQUFBLFFBQVEsSUFBSSxlQUFlLElBQUksWUFBWSxDQUFDO0FBQ2hEO0FBRU0sU0FBVSxlQUFlLENBQUMsT0FBZ0IsRUFBRSxLQUFvQixFQUFBO0lBQ3BFLElBQUksS0FBSyxFQUFFO0FBQ1QsUUFBQSxPQUFPLENBQUMsa0JBQWtCLENBQUMsR0FBRyxLQUFLO0lBQ3JDO0FBQ0Y7QUFFTSxTQUFVLGtCQUFrQixDQUNoQyxPQUFnQixFQUNoQixhQUE0QixFQUFBO0FBRTVCLElBQUEsSUFBSSxhQUFhLEtBQUssSUFBSSxFQUFFO0FBQzFCLFFBQUEsT0FBTyxDQUFDLHFCQUFxQixDQUFDLEdBQUcsYUFBYTtJQUNoRDtBQUNGO0FBRU0sU0FBVSxXQUFXLENBQ3pCLFdBQThCLEVBQzlCLEtBQW9CLEVBQ3BCLFNBQXdCLEVBQ3hCLGFBQTRCLEVBQzVCLGNBQW1DLEVBQ25DLGVBQXdCLEVBQ3hCLEtBQUssR0FBRyxJQUFJLEVBQ1osZUFBZSxHQUFHLEtBQUssRUFBQTtJQUV2QixNQUFNLFNBQVMsR0FBRyxlQUFlLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQztBQUN4RCxJQUFBLE1BQU0sR0FBRyxHQUFHLFdBQVcsQ0FBQyxHQUFHLEdBQUcsU0FBUztBQUN2QyxJQUFBLE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxFQUFFLFdBQVcsQ0FBQyxPQUFPLENBQUM7QUFDdEQsSUFBQSxlQUFlLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQztBQUMvQixJQUFBLGNBQWMsQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDO0FBQ2xDLElBQUEsaUJBQWlCLENBQUMsT0FBTyxFQUFFLGVBQWUsQ0FBQztBQUMzQyxJQUFBLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7SUFDMUMsT0FBTyxJQUFJLGNBQWMsQ0FDdkIsR0FBRyxFQUNILFdBQVcsQ0FBQyxNQUFNLEVBQ2xCLE9BQU8sRUFDUCxXQUFXLENBQUMsSUFBSSxFQUNoQixXQUFXLENBQUMsWUFBWSxFQUN4QixXQUFXLENBQUMsb0JBQW9CLEVBQ2hDLFdBQVcsQ0FBQyxPQUFPLEVBQ25CLFdBQVcsQ0FBQyxZQUFZLEVBQ3hCLFdBQVcsQ0FBQyxPQUFPLEVBQ25CLFdBQVcsQ0FBQyxnQkFBZ0IsRUFDNUIsY0FBYyxFQUNkLEtBQUssRUFDTCxlQUFlLENBQ2hCO0FBQ0g7O0FDdlNBOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztBQUNIOzs7O0FBSUc7QUFJSCxTQUFTLGNBQWMsR0FBQTtBQUNyQixJQUFBLElBQUksT0FBTyxXQUFXLEtBQUssV0FBVyxFQUFFO0FBQ3RDLFFBQUEsT0FBTyxXQUFXO0lBQ3BCO0FBQU8sU0FBQSxJQUFJLE9BQU8saUJBQWlCLEtBQUssV0FBVyxFQUFFO0FBQ25ELFFBQUEsT0FBTyxpQkFBaUI7SUFDMUI7U0FBTztBQUNMLFFBQUEsT0FBTyxTQUFTO0lBQ2xCO0FBQ0Y7QUFFQTs7Ozs7QUFLRztBQUNHLFNBQVVBLFNBQU8sQ0FBQyxHQUFHLElBQXdDLEVBQUE7QUFDakUsSUFBQSxNQUFNLFdBQVcsR0FBRyxjQUFjLEVBQUU7QUFDcEMsSUFBQSxJQUFJLFdBQVcsS0FBSyxTQUFTLEVBQUU7QUFDN0IsUUFBQSxNQUFNLEVBQUUsR0FBRyxJQUFJLFdBQVcsRUFBRTtBQUM1QixRQUFBLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1lBQ3BDLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3BCO0FBQ0EsUUFBQSxPQUFPLEVBQUUsQ0FBQyxPQUFPLEVBQUU7SUFDckI7U0FBTztRQUNMLElBQUksbUJBQW1CLEVBQUUsRUFBRTtBQUN6QixZQUFBLE9BQU8sSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQ3ZCO2FBQU87WUFDTCxNQUFNLElBQUksWUFBWSxDQUNwQixnQkFBZ0IsQ0FBQyx1QkFBdUIsRUFDeEMscURBQXFELENBQ3REO1FBQ0g7SUFDRjtBQUNGO0FBRUE7Ozs7Ozs7O0FBUUc7U0FDYSxTQUFTLENBQUMsSUFBVSxFQUFFLEtBQWEsRUFBRSxHQUFXLEVBQUE7QUFDOUQsSUFBQSxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7UUFDcEIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUM7SUFDckM7QUFBTyxTQUFBLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtRQUN4QixPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQztJQUNsQztBQUFPLFNBQUEsSUFBSSxJQUFJLENBQUMsS0FBSyxFQUFFO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDO0lBQy9CO0FBQ0EsSUFBQSxPQUFPLElBQUk7QUFDYjs7QUM5RUE7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBSUg7QUFDTSxTQUFVLFlBQVksQ0FBQyxPQUFlLEVBQUE7QUFDMUMsSUFBQSxJQUFJLE9BQU8sSUFBSSxLQUFLLFdBQVcsRUFBRTtBQUMvQixRQUFBLE1BQU0sZUFBZSxDQUFDLFNBQVMsQ0FBQztJQUNsQztBQUNBLElBQUEsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDO0FBQ3RCOztBQ3pCQTs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUFVSDs7O0FBR0c7QUFDSSxNQUFNLFlBQVksR0FBRztBQUMxQjs7Ozs7O0FBTUc7QUFDSCxJQUFBLEdBQUcsRUFBRSxLQUFLO0FBQ1Y7Ozs7O0FBS0c7QUFDSCxJQUFBLE1BQU0sRUFBRSxRQUFRO0FBQ2hCOzs7OztBQUtHO0FBQ0gsSUFBQSxTQUFTLEVBQUUsV0FBVztBQUN0Qjs7Ozs7Ozs7QUFRRztBQUNILElBQUEsUUFBUSxFQUFFOztNQUdDLFVBQVUsQ0FBQTtJQUdyQixXQUFBLENBQW1CLElBQWdCLEVBQUUsV0FBMkIsRUFBQTtRQUE3QyxJQUFBLENBQUEsSUFBSSxHQUFKLElBQUk7QUFDckIsUUFBQSxJQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsSUFBSSxJQUFJO0lBQ3hDO0FBQ0Q7QUFFRDs7QUFFRztBQUNHLFNBQVUsY0FBYyxDQUM1QixNQUFvQixFQUNwQixVQUFrQixFQUFBO0lBRWxCLFFBQVEsTUFBTTtRQUNaLEtBQUssWUFBWSxDQUFDLEdBQUc7WUFDbkIsT0FBTyxJQUFJLFVBQVUsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDL0MsS0FBSyxZQUFZLENBQUMsTUFBTTtRQUN4QixLQUFLLFlBQVksQ0FBQyxTQUFTO1lBQ3pCLE9BQU8sSUFBSSxVQUFVLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQztRQUN6RCxLQUFLLFlBQVksQ0FBQyxRQUFRO0FBQ3hCLFlBQUEsT0FBTyxJQUFJLFVBQVUsQ0FDbkIsYUFBYSxDQUFDLFVBQVUsQ0FBQyxFQUN6QixtQkFBbUIsQ0FBQyxVQUFVLENBQUMsQ0FDaEM7Ozs7SUFNTCxNQUFNLE9BQU8sRUFBRTtBQUNqQjtBQUVNLFNBQVUsVUFBVSxDQUFDLEtBQWEsRUFBQTtJQUN0QyxNQUFNLENBQUMsR0FBYSxFQUFFO0FBQ3RCLElBQUEsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7UUFDckMsSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7QUFDM0IsUUFBQSxJQUFJLENBQUMsSUFBSSxHQUFHLEVBQUU7QUFDWixZQUFBLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ1g7YUFBTztBQUNMLFlBQUEsSUFBSSxDQUFDLElBQUksSUFBSSxFQUFFO0FBQ2IsZ0JBQUEsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7WUFDeEM7aUJBQU87Z0JBQ0wsSUFBSSxDQUFDLENBQUMsR0FBRyxLQUFLLE1BQU0sS0FBSyxFQUFFOztvQkFFekIsTUFBTSxLQUFLLEdBQ1QsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsS0FBSyxNQUFNLEtBQUs7b0JBQ3JFLElBQUksQ0FBQyxLQUFLLEVBQUU7O3dCQUVWLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7b0JBQ3ZCO3lCQUFPO3dCQUNMLE1BQU0sRUFBRSxHQUFHLENBQUM7d0JBQ1osTUFBTSxFQUFFLEdBQUcsS0FBSyxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNoQyx3QkFBQSxDQUFDLEdBQUcsS0FBSyxJQUFJLENBQUMsRUFBRSxHQUFHLElBQUksS0FBSyxFQUFFLENBQUMsSUFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDO0FBQzdDLHdCQUFBLENBQUMsQ0FBQyxJQUFJLENBQ0osR0FBRyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsRUFDZixHQUFHLElBQUksQ0FBQyxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUN0QixHQUFHLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUNyQixHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUNmO29CQUNIO2dCQUNGO3FCQUFPO29CQUNMLElBQUksQ0FBQyxDQUFDLEdBQUcsS0FBSyxNQUFNLEtBQUssRUFBRTs7d0JBRXpCLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7b0JBQ3ZCO3lCQUFPO0FBQ0wsd0JBQUEsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztvQkFDaEU7Z0JBQ0Y7WUFDRjtRQUNGO0lBQ0Y7QUFDQSxJQUFBLE9BQU8sSUFBSSxVQUFVLENBQUMsQ0FBQyxDQUFDO0FBQzFCO0FBRU0sU0FBVSxvQkFBb0IsQ0FBQyxLQUFhLEVBQUE7QUFDaEQsSUFBQSxJQUFJLE9BQU87QUFDWCxJQUFBLElBQUk7QUFDRixRQUFBLE9BQU8sR0FBRyxrQkFBa0IsQ0FBQyxLQUFLLENBQUM7SUFDckM7SUFBRSxPQUFPLENBQUMsRUFBRTtRQUNWLE1BQU0sYUFBYSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUscUJBQXFCLENBQUM7SUFDbkU7QUFDQSxJQUFBLE9BQU8sVUFBVSxDQUFDLE9BQU8sQ0FBQztBQUM1QjtBQUVNLFNBQVUsWUFBWSxDQUFDLE1BQW9CLEVBQUUsS0FBYSxFQUFBO0lBQzlELFFBQVEsTUFBTTtBQUNaLFFBQUEsS0FBSyxZQUFZLENBQUMsTUFBTSxFQUFFO1lBQ3hCLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRTtZQUMxQyxNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUU7QUFDMUMsWUFBQSxJQUFJLFFBQVEsSUFBSSxRQUFRLEVBQUU7Z0JBQ3hCLE1BQU0sV0FBVyxHQUFHLFFBQVEsR0FBRyxHQUFHLEdBQUcsR0FBRztBQUN4QyxnQkFBQSxNQUFNLGFBQWEsQ0FDakIsTUFBTSxFQUNOLHFCQUFxQjtvQkFDbkIsV0FBVztBQUNYLG9CQUFBLG1DQUFtQyxDQUN0QztZQUNIO1lBQ0E7UUFDRjtBQUNBLFFBQUEsS0FBSyxZQUFZLENBQUMsU0FBUyxFQUFFO1lBQzNCLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRTtZQUN6QyxNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUU7QUFDMUMsWUFBQSxJQUFJLE9BQU8sSUFBSSxRQUFRLEVBQUU7Z0JBQ3ZCLE1BQU0sV0FBVyxHQUFHLE9BQU8sR0FBRyxHQUFHLEdBQUcsR0FBRztnQkFDdkMsTUFBTSxhQUFhLENBQ2pCLE1BQU0sRUFDTixxQkFBcUIsR0FBRyxXQUFXLEdBQUcsZ0NBQWdDLENBQ3ZFO1lBQ0g7QUFDQSxZQUFBLEtBQUssR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQztZQUNuRDtRQUNGOzs7QUFJRixJQUFBLElBQUksS0FBSztBQUNULElBQUEsSUFBSTtBQUNGLFFBQUEsS0FBSyxHQUFHLFlBQVksQ0FBQyxLQUFLLENBQUM7SUFDN0I7SUFBRSxPQUFPLENBQUMsRUFBRTtRQUNWLElBQUssQ0FBVyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEVBQUU7QUFDN0MsWUFBQSxNQUFNLENBQUM7UUFDVDtBQUNBLFFBQUEsTUFBTSxhQUFhLENBQUMsTUFBTSxFQUFFLHlCQUF5QixDQUFDO0lBQ3hEO0lBQ0EsTUFBTSxLQUFLLEdBQUcsSUFBSSxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztBQUMxQyxJQUFBLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1FBQ3JDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztJQUNoQztBQUNBLElBQUEsT0FBTyxLQUFLO0FBQ2Q7QUFFQSxNQUFNLFlBQVksQ0FBQTtBQUtoQixJQUFBLFdBQUEsQ0FBWSxPQUFlLEVBQUE7UUFKM0IsSUFBQSxDQUFBLE1BQU0sR0FBWSxLQUFLO1FBQ3ZCLElBQUEsQ0FBQSxXQUFXLEdBQWtCLElBQUk7UUFJL0IsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQztBQUNoRCxRQUFBLElBQUksT0FBTyxLQUFLLElBQUksRUFBRTtZQUNwQixNQUFNLGFBQWEsQ0FDakIsWUFBWSxDQUFDLFFBQVEsRUFDckIsdURBQXVELENBQ3hEO1FBQ0g7UUFDQSxNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSTtBQUNqQyxRQUFBLElBQUksTUFBTSxJQUFJLElBQUksRUFBRTtZQUNsQixJQUFJLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDO0FBQ3pDLFlBQUEsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7QUFDdEIsa0JBQUUsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUMsTUFBTTtrQkFDcEQsTUFBTTtRQUNaO0FBQ0EsUUFBQSxJQUFJLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDekQ7QUFDRDtBQUVLLFNBQVUsYUFBYSxDQUFDLE9BQWUsRUFBQTtBQUMzQyxJQUFBLE1BQU0sS0FBSyxHQUFHLElBQUksWUFBWSxDQUFDLE9BQU8sQ0FBQztBQUN2QyxJQUFBLElBQUksS0FBSyxDQUFDLE1BQU0sRUFBRTtRQUNoQixPQUFPLFlBQVksQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUM7SUFDdEQ7U0FBTztBQUNMLFFBQUEsT0FBTyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO0lBQ3pDO0FBQ0Y7QUFFTSxTQUFVLG1CQUFtQixDQUFDLE9BQWUsRUFBQTtBQUNqRCxJQUFBLE1BQU0sS0FBSyxHQUFHLElBQUksWUFBWSxDQUFDLE9BQU8sQ0FBQztJQUN2QyxPQUFPLEtBQUssQ0FBQyxXQUFXO0FBQzFCO0FBRUEsU0FBUyxRQUFRLENBQUMsQ0FBUyxFQUFFLEdBQVcsRUFBQTtJQUN0QyxNQUFNLFVBQVUsR0FBRyxDQUFDLENBQUMsTUFBTSxJQUFJLEdBQUcsQ0FBQyxNQUFNO0lBQ3pDLElBQUksQ0FBQyxVQUFVLEVBQUU7QUFDZixRQUFBLE9BQU8sS0FBSztJQUNkO0FBRUEsSUFBQSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRztBQUNuRDs7QUNuUEE7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBRUg7Ozs7QUFJRztBQUtIOzs7Ozs7QUFNRztNQUNVLE9BQU8sQ0FBQTtJQUtsQixXQUFBLENBQVksSUFBcUMsRUFBRSxTQUFtQixFQUFBO1FBQ3BFLElBQUksSUFBSSxHQUFXLENBQUM7UUFDcEIsSUFBSSxRQUFRLEdBQVcsRUFBRTtBQUN6QixRQUFBLElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ3RCLFlBQUEsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFZO0FBQ3pCLFlBQUEsSUFBSSxHQUFJLElBQWEsQ0FBQyxJQUFJO0FBQzFCLFlBQUEsUUFBUSxHQUFJLElBQWEsQ0FBQyxJQUFJO1FBQ2hDO0FBQU8sYUFBQSxJQUFJLElBQUksWUFBWSxXQUFXLEVBQUU7WUFDdEMsSUFBSSxTQUFTLEVBQUU7Z0JBQ2IsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUM7WUFDbkM7aUJBQU87Z0JBQ0wsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO2dCQUM1QyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUN0QztBQUNBLFlBQUEsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTTtRQUMxQjtBQUFPLGFBQUEsSUFBSSxJQUFJLFlBQVksVUFBVSxFQUFFO1lBQ3JDLElBQUksU0FBUyxFQUFFO0FBQ2IsZ0JBQUEsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFrQjtZQUNqQztpQkFBTztnQkFDTCxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDeEMsZ0JBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBa0IsQ0FBQztZQUNwQztBQUNBLFlBQUEsSUFBSSxHQUFHLElBQUksQ0FBQyxNQUFNO1FBQ3BCO0FBQ0EsUUFBQSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUk7QUFDakIsUUFBQSxJQUFJLENBQUMsS0FBSyxHQUFHLFFBQVE7SUFDdkI7SUFFQSxJQUFJLEdBQUE7UUFDRixPQUFPLElBQUksQ0FBQyxLQUFLO0lBQ25CO0lBRUEsSUFBSSxHQUFBO1FBQ0YsT0FBTyxJQUFJLENBQUMsS0FBSztJQUNuQjtJQUVBLEtBQUssQ0FBQyxTQUFpQixFQUFFLE9BQWUsRUFBQTtBQUN0QyxRQUFBLElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRTtBQUM1QixZQUFBLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFhO1lBQ25DLE1BQU0sTUFBTSxHQUFHLFNBQVMsQ0FBQyxRQUFRLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQztBQUN0RCxZQUFBLElBQUksTUFBTSxLQUFLLElBQUksRUFBRTtBQUNuQixnQkFBQSxPQUFPLElBQUk7WUFDYjtBQUNBLFlBQUEsT0FBTyxJQUFJLE9BQU8sQ0FBQyxNQUFNLENBQUM7UUFDNUI7YUFBTztBQUNMLFlBQUEsTUFBTSxLQUFLLEdBQUcsSUFBSSxVQUFVLENBQ3pCLElBQUksQ0FBQyxLQUFvQixDQUFDLE1BQU0sRUFDakMsU0FBUyxFQUNULE9BQU8sR0FBRyxTQUFTLENBQ3BCO0FBQ0QsWUFBQSxPQUFPLElBQUksT0FBTyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUM7UUFDakM7SUFDRjtBQUVBLElBQUEsT0FBTyxPQUFPLENBQUMsR0FBRyxJQUE2QixFQUFBO1FBQzdDLElBQUksbUJBQW1CLEVBQUUsRUFBRTtZQUN6QixNQUFNLE1BQU0sR0FBc0MsSUFBSSxDQUFDLEdBQUcsQ0FDeEQsQ0FBQyxHQUFxQixLQUFnQztBQUNwRCxnQkFBQSxJQUFJLEdBQUcsWUFBWSxPQUFPLEVBQUU7b0JBQzFCLE9BQU8sR0FBRyxDQUFDLEtBQUs7Z0JBQ2xCO3FCQUFPO0FBQ0wsb0JBQUEsT0FBTyxHQUFHO2dCQUNaO0FBQ0YsWUFBQSxDQUFDLENBQ0Y7QUFDRCxZQUFBLE9BQU8sSUFBSSxPQUFPLENBQUNBLFNBQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ2pEO2FBQU87WUFDTCxNQUFNLFdBQVcsR0FBaUIsSUFBSSxDQUFDLEdBQUcsQ0FDeEMsQ0FBQyxHQUFxQixLQUFnQjtBQUNwQyxnQkFBQSxJQUFJLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRTtvQkFDakIsT0FBTyxjQUFjLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxHQUFhLENBQUMsQ0FBQyxJQUFJO2dCQUM3RDtxQkFBTzs7b0JBRUwsT0FBUSxHQUFlLENBQUMsS0FBbUI7Z0JBQzdDO0FBQ0YsWUFBQSxDQUFDLENBQ0Y7WUFDRCxJQUFJLFdBQVcsR0FBRyxDQUFDO0FBQ25CLFlBQUEsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQWlCLEtBQVU7QUFDOUMsZ0JBQUEsV0FBVyxJQUFJLEtBQUssQ0FBQyxVQUFVO0FBQ2pDLFlBQUEsQ0FBQyxDQUFDO0FBQ0YsWUFBQSxNQUFNLE1BQU0sR0FBRyxJQUFJLFVBQVUsQ0FBQyxXQUFXLENBQUM7WUFDMUMsSUFBSSxLQUFLLEdBQUcsQ0FBQztBQUNiLFlBQUEsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQWlCLEtBQUk7QUFDeEMsZ0JBQUEsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7b0JBQ3JDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUM7Z0JBQzVCO0FBQ0YsWUFBQSxDQUFDLENBQUM7QUFDRixZQUFBLE9BQU8sSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQztRQUNsQztJQUNGO0lBRUEsVUFBVSxHQUFBO1FBQ1IsT0FBTyxJQUFJLENBQUMsS0FBSztJQUNuQjtBQUNEOztBQ3JJRDs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUFHSDs7O0FBR0c7QUFDRyxTQUFVLGdCQUFnQixDQUM5QixDQUFTLEVBQUE7QUFFVCxJQUFBLElBQUksR0FBRztBQUNQLElBQUEsSUFBSTtBQUNGLFFBQUEsR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0lBQ3JCO0lBQUUsT0FBTyxDQUFDLEVBQUU7QUFDVixRQUFBLE9BQU8sSUFBSTtJQUNiO0FBQ0EsSUFBQSxJQUFJLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxFQUFFO0FBQ3pCLFFBQUEsT0FBTyxHQUFHO0lBQ1o7U0FBTztBQUNMLFFBQUEsT0FBTyxJQUFJO0lBQ2I7QUFDRjs7QUNwQ0E7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBRUg7O0FBRUc7QUFFSDs7QUFFRztBQUNHLFNBQVUsTUFBTSxDQUFDLElBQVksRUFBQTtBQUNqQyxJQUFBLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUU7QUFDckIsUUFBQSxPQUFPLElBQUk7SUFDYjtJQUNBLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDO0FBQ25DLElBQUEsSUFBSSxLQUFLLEtBQUssRUFBRSxFQUFFO0FBQ2hCLFFBQUEsT0FBTyxFQUFFO0lBQ1g7SUFDQSxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUM7QUFDcEMsSUFBQSxPQUFPLE9BQU87QUFDaEI7QUFFTSxTQUFVLEtBQUssQ0FBQyxJQUFZLEVBQUUsU0FBaUIsRUFBQTtJQUNuRCxNQUFNLGtCQUFrQixHQUFHO1NBQ3hCLEtBQUssQ0FBQyxHQUFHO1NBQ1QsTUFBTSxDQUFDLFNBQVMsSUFBSSxTQUFTLENBQUMsTUFBTSxHQUFHLENBQUM7U0FDeEMsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUNaLElBQUEsSUFBSSxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtBQUNyQixRQUFBLE9BQU8sa0JBQWtCO0lBQzNCO1NBQU87QUFDTCxRQUFBLE9BQU8sSUFBSSxHQUFHLEdBQUcsR0FBRyxrQkFBa0I7SUFDeEM7QUFDRjtBQUVBOzs7OztBQUtHO0FBQ0csU0FBVSxhQUFhLENBQUMsSUFBWSxFQUFBO0FBQ3hDLElBQUEsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7QUFDcEQsSUFBQSxJQUFJLEtBQUssS0FBSyxFQUFFLEVBQUU7QUFDaEIsUUFBQSxPQUFPLElBQUk7SUFDYjtTQUFPO1FBQ0wsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUM7SUFDOUI7QUFDRjs7QUM3REE7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBZUcsU0FBVSxRQUFRLENBQUksUUFBa0IsRUFBRSxLQUFRLEVBQUE7QUFDdEQsSUFBQSxPQUFPLEtBQUs7QUFDZDtBQUVBLE1BQU0sT0FBTyxDQUFBO0FBS1gsSUFBQSxXQUFBLENBQ1MsTUFBYyxFQUNyQixLQUFxQixFQUNyQixRQUFrQixFQUNsQixLQUF3RCxFQUFBO1FBSGpELElBQUEsQ0FBQSxNQUFNLEdBQU4sTUFBTTtBQUtiLFFBQUEsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLElBQUksTUFBTTtBQUM1QixRQUFBLElBQUksQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLFFBQVE7QUFDMUIsUUFBQSxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssSUFBSSxRQUFRO0lBQ2hDO0FBQ0Q7QUFLRCxJQUFJLFNBQVMsR0FBb0IsSUFBSTtBQUUvQixTQUFVLFNBQVMsQ0FBQyxRQUE0QixFQUFBO0FBQ3BELElBQUEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxRQUFRLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtBQUM5QyxRQUFBLE9BQU8sUUFBUTtJQUNqQjtTQUFPO0FBQ0wsUUFBQSxPQUFPLGFBQWEsQ0FBQyxRQUFRLENBQUM7SUFDaEM7QUFDRjtTQUVnQixXQUFXLEdBQUE7SUFDekIsSUFBSSxTQUFTLEVBQUU7QUFDYixRQUFBLE9BQU8sU0FBUztJQUNsQjtJQUNBLE1BQU0sUUFBUSxHQUFhLEVBQUU7SUFDN0IsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLE9BQU8sQ0FBUyxRQUFRLENBQUMsQ0FBQztJQUM1QyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksT0FBTyxDQUFTLFlBQVksQ0FBQyxDQUFDO0lBQ2hELFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxPQUFPLENBQVMsZ0JBQWdCLENBQUMsQ0FBQztBQUNwRCxJQUFBLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxPQUFPLENBQVMsTUFBTSxFQUFFLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQztBQUU1RCxJQUFBLFNBQVMsaUJBQWlCLENBQ3hCLFNBQW1CLEVBQ25CLFFBQTRCLEVBQUE7QUFFNUIsUUFBQSxPQUFPLFNBQVMsQ0FBQyxRQUFRLENBQUM7SUFDNUI7QUFDQSxJQUFBLE1BQU0sV0FBVyxHQUFHLElBQUksT0FBTyxDQUFTLE1BQU0sQ0FBQztBQUMvQyxJQUFBLFdBQVcsQ0FBQyxLQUFLLEdBQUcsaUJBQWlCO0FBQ3JDLElBQUEsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7QUFFMUI7O0FBRUc7QUFDSCxJQUFBLFNBQVMsU0FBUyxDQUNoQixTQUFtQixFQUNuQixJQUFzQixFQUFBO0FBRXRCLFFBQUEsSUFBSSxJQUFJLEtBQUssU0FBUyxFQUFFO0FBQ3RCLFlBQUEsT0FBTyxNQUFNLENBQUMsSUFBSSxDQUFDO1FBQ3JCO2FBQU87QUFDTCxZQUFBLE9BQU8sSUFBSTtRQUNiO0lBQ0Y7QUFDQSxJQUFBLE1BQU0sV0FBVyxHQUFHLElBQUksT0FBTyxDQUFTLE1BQU0sQ0FBQztBQUMvQyxJQUFBLFdBQVcsQ0FBQyxLQUFLLEdBQUcsU0FBUztBQUM3QixJQUFBLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQzFCLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxPQUFPLENBQVMsYUFBYSxDQUFDLENBQUM7SUFDakQsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLE9BQU8sQ0FBUyxTQUFTLENBQUMsQ0FBQztBQUM3QyxJQUFBLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxPQUFPLENBQVMsU0FBUyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztBQUN6RCxJQUFBLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxPQUFPLENBQVMsY0FBYyxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztBQUM5RCxJQUFBLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxPQUFPLENBQVMsb0JBQW9CLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO0FBQ3BFLElBQUEsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLE9BQU8sQ0FBUyxpQkFBaUIsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7QUFDakUsSUFBQSxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksT0FBTyxDQUFTLGlCQUFpQixFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztBQUNqRSxJQUFBLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxPQUFPLENBQVMsYUFBYSxFQUFFLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztBQUM3RCxJQUFBLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxPQUFPLENBQVMsVUFBVSxFQUFFLGdCQUFnQixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3RFLFNBQVMsR0FBRyxRQUFRO0FBQ3BCLElBQUEsT0FBTyxTQUFTO0FBQ2xCO0FBRU0sU0FBVSxNQUFNLENBQUMsUUFBa0IsRUFBRSxPQUE0QixFQUFBO0FBQ3JFLElBQUEsU0FBUyxXQUFXLEdBQUE7QUFDbEIsUUFBQSxNQUFNLE1BQU0sR0FBVyxRQUFRLENBQUMsUUFBUSxDQUFXO0FBQ25ELFFBQUEsTUFBTSxJQUFJLEdBQVcsUUFBUSxDQUFDLFVBQVUsQ0FBVztRQUNuRCxNQUFNLEdBQUcsR0FBRyxJQUFJLFFBQVEsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDO0FBQ3RDLFFBQUEsT0FBTyxPQUFPLENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDO0lBQzNDO0FBQ0EsSUFBQSxNQUFNLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsRUFBRSxHQUFHLEVBQUUsV0FBVyxFQUFFLENBQUM7QUFDOUQ7U0FFZ0IsWUFBWSxDQUMxQixPQUE0QixFQUM1QixRQUFxQyxFQUNyQyxRQUFrQixFQUFBO0lBRWxCLE1BQU0sUUFBUSxHQUFhLEVBQWM7QUFDekMsSUFBQSxRQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsTUFBTTtBQUN6QixJQUFBLE1BQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQyxNQUFNO0FBQzNCLElBQUEsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRTtBQUM1QixRQUFBLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDM0IsUUFBQSxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFJLE9BQTRCLENBQUMsS0FBSyxDQUMzRCxRQUFRLEVBQ1IsUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FDekI7SUFDSDtBQUNBLElBQUEsTUFBTSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUM7QUFDekIsSUFBQSxPQUFPLFFBQVE7QUFDakI7U0FFZ0Isa0JBQWtCLENBQ2hDLE9BQTRCLEVBQzVCLGNBQXNCLEVBQ3RCLFFBQWtCLEVBQUE7QUFFbEIsSUFBQSxNQUFNLEdBQUcsR0FBRyxnQkFBZ0IsQ0FBQyxjQUFjLENBQUM7QUFDNUMsSUFBQSxJQUFJLEdBQUcsS0FBSyxJQUFJLEVBQUU7QUFDaEIsUUFBQSxPQUFPLElBQUk7SUFDYjtJQUNBLE1BQU0sUUFBUSxHQUFHLEdBQWU7SUFDaEMsT0FBTyxZQUFZLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxRQUFRLENBQUM7QUFDbEQ7QUFFTSxTQUFVLDZCQUE2QixDQUMzQyxRQUFrQixFQUNsQixjQUFzQixFQUN0QixJQUFZLEVBQ1osUUFBZ0IsRUFBQTtBQUVoQixJQUFBLE1BQU0sR0FBRyxHQUFHLGdCQUFnQixDQUFDLGNBQWMsQ0FBQztBQUM1QyxJQUFBLElBQUksR0FBRyxLQUFLLElBQUksRUFBRTtBQUNoQixRQUFBLE9BQU8sSUFBSTtJQUNiO0lBQ0EsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxFQUFFOzs7QUFHcEMsUUFBQSxPQUFPLElBQUk7SUFDYjtBQUNBLElBQUEsTUFBTSxNQUFNLEdBQVcsR0FBRyxDQUFDLGdCQUFnQixDQUFXO0FBQ3RELElBQUEsSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRTtBQUN2QixRQUFBLE9BQU8sSUFBSTtJQUNiO0lBQ0EsTUFBTSxNQUFNLEdBQUcsa0JBQWtCO0lBQ2pDLE1BQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0lBQ3BDLE1BQU0sSUFBSSxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFhLEtBQVk7QUFDcEQsUUFBQSxNQUFNLE1BQU0sR0FBVyxRQUFRLENBQUMsUUFBUSxDQUFXO0FBQ25ELFFBQUEsTUFBTSxJQUFJLEdBQVcsUUFBUSxDQUFDLFVBQVUsQ0FBVztBQUNuRCxRQUFBLE1BQU0sT0FBTyxHQUFHLEtBQUssR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsS0FBSyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUM7UUFDN0QsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDO1FBQzdDLE1BQU0sV0FBVyxHQUFHLGVBQWUsQ0FBQztBQUNsQyxZQUFBLEdBQUcsRUFBRSxPQUFPO1lBQ1o7QUFDRCxTQUFBLENBQUM7UUFDRixPQUFPLElBQUksR0FBRyxXQUFXO0FBQzNCLElBQUEsQ0FBQyxDQUFDO0FBQ0YsSUFBQSxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDaEI7QUFFTSxTQUFVLGdCQUFnQixDQUM5QixRQUEyQixFQUMzQixRQUFrQixFQUFBO0lBRWxCLE1BQU0sUUFBUSxHQUVWLEVBQUU7QUFDTixJQUFBLE1BQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQyxNQUFNO0FBQzNCLElBQUEsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRTtBQUM1QixRQUFBLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDM0IsUUFBQSxJQUFJLE9BQU8sQ0FBQyxRQUFRLEVBQUU7QUFDcEIsWUFBQSxRQUFRLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO1FBQ3BEO0lBQ0Y7QUFDQSxJQUFBLE9BQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7QUFDakM7O0FDN01BOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztBQUVIOztBQUVHO0FBeUJILE1BQU0sWUFBWSxHQUFHLFVBQVU7QUFDL0IsTUFBTSxTQUFTLEdBQUcsT0FBTztBQUV6QixTQUFTLG1CQUFtQixDQUMxQixPQUE0QixFQUM1QixNQUFjLEVBQ2QsUUFBNEIsRUFBQTtBQUU1QixJQUFBLE1BQU0sVUFBVSxHQUFlO0FBQzdCLFFBQUEsUUFBUSxFQUFFLEVBQUU7QUFDWixRQUFBLEtBQUssRUFBRSxFQUFFO0FBQ1QsUUFBQSxhQUFhLEVBQUUsUUFBUSxDQUFDLGVBQWU7S0FDeEM7QUFDRCxJQUFBLElBQUksUUFBUSxDQUFDLFlBQVksQ0FBQyxFQUFFO1FBQzFCLEtBQUssTUFBTSxJQUFJLElBQUksUUFBUSxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQ3pDLE1BQU0sd0JBQXdCLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDO0FBQ3hELFlBQUEsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLHFCQUFxQixDQUM3QyxJQUFJLFFBQVEsQ0FBQyxNQUFNLEVBQUUsd0JBQXdCLENBQUMsQ0FDL0M7QUFDRCxZQUFBLFVBQVUsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUNyQztJQUNGO0FBRUEsSUFBQSxJQUFJLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRTtRQUN2QixLQUFLLE1BQU0sSUFBSSxJQUFJLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRTtBQUN0QyxZQUFBLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxxQkFBcUIsQ0FDN0MsSUFBSSxRQUFRLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUNuQztBQUNELFlBQUEsVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQ2xDO0lBQ0Y7QUFDQSxJQUFBLE9BQU8sVUFBVTtBQUNuQjtTQUVnQixrQkFBa0IsQ0FDaEMsT0FBNEIsRUFDNUIsTUFBYyxFQUNkLGNBQXNCLEVBQUE7QUFFdEIsSUFBQSxNQUFNLEdBQUcsR0FBRyxnQkFBZ0IsQ0FBQyxjQUFjLENBQUM7QUFDNUMsSUFBQSxJQUFJLEdBQUcsS0FBSyxJQUFJLEVBQUU7QUFDaEIsUUFBQSxPQUFPLElBQUk7SUFDYjtJQUNBLE1BQU0sUUFBUSxHQUFHLEdBQW9DO0lBQ3JELE9BQU8sbUJBQW1CLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxRQUFRLENBQUM7QUFDdkQ7O0FDN0NBOzs7OztBQUtHO01BQ1UsV0FBVyxDQUFBO0lBY3RCLFdBQUEsQ0FDUyxHQUFXLEVBQ1gsTUFBYztBQUNyQjs7Ozs7O0FBTUc7QUFDSSxJQUFBLE9BQTZCLEVBQzdCLE9BQWUsRUFBQTtRQVZmLElBQUEsQ0FBQSxHQUFHLEdBQUgsR0FBRztRQUNILElBQUEsQ0FBQSxNQUFNLEdBQU4sTUFBTTtRQVFOLElBQUEsQ0FBQSxPQUFPLEdBQVAsT0FBTztRQUNQLElBQUEsQ0FBQSxPQUFPLEdBQVAsT0FBTztRQXhCaEIsSUFBQSxDQUFBLFNBQVMsR0FBYyxFQUFFO1FBQ3pCLElBQUEsQ0FBQSxPQUFPLEdBQVksRUFBRTtRQUNyQixJQUFBLENBQUEsSUFBSSxHQUFzQyxJQUFJO1FBQzlDLElBQUEsQ0FBQSxZQUFZLEdBQXdCLElBQUk7QUFFeEM7OztBQUdHO1FBQ0gsSUFBQSxDQUFBLGdCQUFnQixHQUE4QyxJQUFJO0FBQ2xFLFFBQUEsSUFBQSxDQUFBLFlBQVksR0FBYSxDQUFDLEdBQUcsQ0FBQztRQUM5QixJQUFBLENBQUEsb0JBQW9CLEdBQWEsRUFBRTtJQWNoQztBQUNKOztBQzdFRDs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUFrQ0g7O0FBRUc7QUFDRyxTQUFVLFlBQVksQ0FBQyxJQUFhLEVBQUE7SUFDeEMsSUFBSSxDQUFDLElBQUksRUFBRTtRQUNULE1BQU0sT0FBTyxFQUFFO0lBQ2pCO0FBQ0Y7QUFFTSxTQUFVLGVBQWUsQ0FDN0IsT0FBNEIsRUFDNUIsUUFBa0IsRUFBQTtBQUVsQixJQUFBLFNBQVMsT0FBTyxDQUFDLEdBQXVCLEVBQUUsSUFBWSxFQUFBO1FBQ3BELE1BQU0sUUFBUSxHQUFHLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDO0FBQzVELFFBQUEsWUFBWSxDQUFDLFFBQVEsS0FBSyxJQUFJLENBQUM7QUFDL0IsUUFBQSxPQUFPLFFBQW9CO0lBQzdCO0FBQ0EsSUFBQSxPQUFPLE9BQU87QUFDaEI7QUFFTSxTQUFVLFdBQVcsQ0FDekIsT0FBNEIsRUFDNUIsTUFBYyxFQUFBO0FBRWQsSUFBQSxTQUFTLE9BQU8sQ0FBQyxHQUF1QixFQUFFLElBQVksRUFBQTtRQUNwRCxNQUFNLFVBQVUsR0FBRyxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQztBQUM1RCxRQUFBLFlBQVksQ0FBQyxVQUFVLEtBQUssSUFBSSxDQUFDO0FBQ2pDLFFBQUEsT0FBTyxVQUF3QjtJQUNqQztBQUNBLElBQUEsT0FBTyxPQUFPO0FBQ2hCO0FBRU0sU0FBVSxrQkFBa0IsQ0FDaEMsT0FBNEIsRUFDNUIsUUFBa0IsRUFBQTtBQUVsQixJQUFBLFNBQVMsT0FBTyxDQUFDLEdBQXVCLEVBQUUsSUFBWSxFQUFBO1FBQ3BELE1BQU0sUUFBUSxHQUFHLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDO0FBQzVELFFBQUEsWUFBWSxDQUFDLFFBQVEsS0FBSyxJQUFJLENBQUM7QUFDL0IsUUFBQSxPQUFPLDZCQUE2QixDQUNsQyxRQUFvQixFQUNwQixJQUFJLEVBQ0osT0FBTyxDQUFDLElBQUksRUFDWixPQUFPLENBQUMsU0FBUyxDQUNsQjtJQUNIO0FBQ0EsSUFBQSxPQUFPLE9BQU87QUFDaEI7QUFFTSxTQUFVLGtCQUFrQixDQUNoQyxRQUFrQixFQUFBO0FBRWxCLElBQUEsU0FBUyxZQUFZLENBQ25CLEdBQStCLEVBQy9CLEdBQWlCLEVBQUE7QUFFakIsUUFBQSxJQUFJLE1BQW9CO0FBQ3hCLFFBQUEsSUFBSSxHQUFHLENBQUMsU0FBUyxFQUFFLEtBQUssR0FBRyxFQUFFO0FBQzNCLFlBQUE7OztZQUdFLEdBQUcsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxRQUFRLENBQUMscUNBQXFDLENBQUMsRUFDbEU7Z0JBQ0EsTUFBTSxHQUFHLGVBQWUsRUFBRTtZQUM1QjtpQkFBTztnQkFDTCxNQUFNLEdBQUcsZUFBZSxFQUFFO1lBQzVCO1FBQ0Y7YUFBTztBQUNMLFlBQUEsSUFBSSxHQUFHLENBQUMsU0FBUyxFQUFFLEtBQUssR0FBRyxFQUFFO0FBQzNCLGdCQUFBLE1BQU0sR0FBRyxhQUFhLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQztZQUN6QztpQkFBTztBQUNMLGdCQUFBLElBQUksR0FBRyxDQUFDLFNBQVMsRUFBRSxLQUFLLEdBQUcsRUFBRTtBQUMzQixvQkFBQSxNQUFNLEdBQUcsWUFBWSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7Z0JBQ3RDO3FCQUFPO29CQUNMLE1BQU0sR0FBRyxHQUFHO2dCQUNkO1lBQ0Y7UUFDRjtBQUNBLFFBQUEsTUFBTSxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUMsU0FBUyxFQUFFO0FBQy9CLFFBQUEsTUFBTSxDQUFDLGNBQWMsR0FBRyxHQUFHLENBQUMsY0FBYztBQUMxQyxRQUFBLE9BQU8sTUFBTTtJQUNmO0FBQ0EsSUFBQSxPQUFPLFlBQVk7QUFDckI7QUFFTSxTQUFVLGtCQUFrQixDQUNoQyxRQUFrQixFQUFBO0FBRWxCLElBQUEsTUFBTSxNQUFNLEdBQUcsa0JBQWtCLENBQUMsUUFBUSxDQUFDO0FBRTNDLElBQUEsU0FBUyxZQUFZLENBQ25CLEdBQStCLEVBQy9CLEdBQWlCLEVBQUE7UUFFakIsSUFBSSxNQUFNLEdBQUcsTUFBTSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7QUFDN0IsUUFBQSxJQUFJLEdBQUcsQ0FBQyxTQUFTLEVBQUUsS0FBSyxHQUFHLEVBQUU7QUFDM0IsWUFBQSxNQUFNLEdBQUcsY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7UUFDeEM7QUFDQSxRQUFBLE1BQU0sQ0FBQyxjQUFjLEdBQUcsR0FBRyxDQUFDLGNBQWM7QUFDMUMsUUFBQSxPQUFPLE1BQU07SUFDZjtBQUNBLElBQUEsT0FBTyxZQUFZO0FBQ3JCO1NBRWdCQyxhQUFXLENBQ3pCLE9BQTRCLEVBQzVCLFFBQWtCLEVBQ2xCLFFBQWtCLEVBQUE7QUFFbEIsSUFBQSxNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsYUFBYSxFQUFFO0FBQ3hDLElBQUEsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUM7SUFDN0QsTUFBTSxNQUFNLEdBQUcsS0FBSztBQUNwQixJQUFBLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxxQkFBcUI7QUFDN0MsSUFBQSxNQUFNLFdBQVcsR0FBRyxJQUFJLFdBQVcsQ0FDakMsR0FBRyxFQUNILE1BQU0sRUFDTixlQUFlLENBQUMsT0FBTyxFQUFFLFFBQVEsQ0FBQyxFQUNsQyxPQUFPLENBQ1I7QUFDRCxJQUFBLFdBQVcsQ0FBQyxZQUFZLEdBQUcsa0JBQWtCLENBQUMsUUFBUSxDQUFDO0FBQ3ZELElBQUEsT0FBTyxXQUFXO0FBQ3BCO0FBRU0sU0FBVUMsTUFBSSxDQUNsQixPQUE0QixFQUM1QixRQUFrQixFQUNsQixTQUFrQixFQUNsQixTQUF5QixFQUN6QixVQUEwQixFQUFBO0lBRTFCLE1BQU0sU0FBUyxHQUFjLEVBQUU7QUFDL0IsSUFBQSxJQUFJLFFBQVEsQ0FBQyxNQUFNLEVBQUU7QUFDbkIsUUFBQSxTQUFTLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRTtJQUMxQjtTQUFPO1FBQ0wsU0FBUyxDQUFDLFFBQVEsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxJQUFJLEdBQUcsR0FBRztJQUMzQztJQUNBLElBQWlCLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO0FBQ3JDLFFBQUEsU0FBUyxDQUFDLFdBQVcsQ0FBQyxHQUFHLFNBQVM7SUFDcEM7SUFDQSxJQUFJLFNBQVMsRUFBRTtBQUNiLFFBQUEsU0FBUyxDQUFDLFdBQVcsQ0FBQyxHQUFHLFNBQVM7SUFDcEM7SUFDQSxJQUFJLFVBQVUsRUFBRTtBQUNkLFFBQUEsU0FBUyxDQUFDLFlBQVksQ0FBQyxHQUFHLFVBQVU7SUFDdEM7QUFDQSxJQUFBLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxtQkFBbUIsRUFBRTtBQUM5QyxJQUFBLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsU0FBUyxDQUFDO0lBQzdELE1BQU0sTUFBTSxHQUFHLEtBQUs7QUFDcEIsSUFBQSxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMscUJBQXFCO0lBQzdDLE1BQU0sV0FBVyxHQUFHLElBQUksV0FBVyxDQUNqQyxHQUFHLEVBQ0gsTUFBTSxFQUNOLFdBQVcsQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLE1BQU0sQ0FBQyxFQUNyQyxPQUFPLENBQ1I7QUFDRCxJQUFBLFdBQVcsQ0FBQyxTQUFTLEdBQUcsU0FBUztBQUNqQyxJQUFBLFdBQVcsQ0FBQyxZQUFZLEdBQUcsa0JBQWtCLENBQUMsUUFBUSxDQUFDO0FBQ3ZELElBQUEsT0FBTyxXQUFXO0FBQ3BCO1NBRWdCQyxVQUFRLENBQ3RCLE9BQTRCLEVBQzVCLFFBQWtCLEVBQ2xCLG9CQUE2QixFQUFBO0FBRTdCLElBQUEsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLGFBQWEsRUFBRTtBQUN4QyxJQUFBLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsWUFBWTtJQUM1RSxNQUFNLE1BQU0sR0FBRyxLQUFLO0FBQ3BCLElBQUEsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLHFCQUFxQjtJQUM3QyxNQUFNLFdBQVcsR0FBRyxJQUFJLFdBQVcsQ0FDakMsR0FBRyxFQUNILE1BQU0sRUFDTixDQUFDLENBQWdCLEVBQUUsSUFBTyxLQUFLLElBQUksRUFDbkMsT0FBTyxDQUNSO0FBQ0QsSUFBQSxXQUFXLENBQUMsWUFBWSxHQUFHLGtCQUFrQixDQUFDLFFBQVEsQ0FBQztBQUN2RCxJQUFBLElBQUksb0JBQW9CLEtBQUssU0FBUyxFQUFFO1FBQ3RDLFdBQVcsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQSxRQUFBLEVBQVcsb0JBQW9CLENBQUEsQ0FBRTtBQUNoRSxRQUFBLFdBQVcsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxHQUFHLFdBQVcsR0FBRyx1QkFBdUI7SUFDdEU7QUFDQSxJQUFBLE9BQU8sV0FBVztBQUNwQjtTQUVnQixjQUFjLENBQzVCLE9BQTRCLEVBQzVCLFFBQWtCLEVBQ2xCLFFBQWtCLEVBQUE7QUFFbEIsSUFBQSxNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsYUFBYSxFQUFFO0FBQ3hDLElBQUEsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUM7SUFDN0QsTUFBTSxNQUFNLEdBQUcsS0FBSztBQUNwQixJQUFBLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxxQkFBcUI7QUFDN0MsSUFBQSxNQUFNLFdBQVcsR0FBRyxJQUFJLFdBQVcsQ0FDakMsR0FBRyxFQUNILE1BQU0sRUFDTixrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLEVBQ3JDLE9BQU8sQ0FDUjtBQUNELElBQUEsV0FBVyxDQUFDLFlBQVksR0FBRyxrQkFBa0IsQ0FBQyxRQUFRLENBQUM7QUFDdkQsSUFBQSxPQUFPLFdBQVc7QUFDcEI7QUFFTSxTQUFVQyxnQkFBYyxDQUM1QixPQUE0QixFQUM1QixRQUFrQixFQUNsQixRQUEyQixFQUMzQixRQUFrQixFQUFBO0FBRWxCLElBQUEsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLGFBQWEsRUFBRTtBQUN4QyxJQUFBLE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsU0FBUyxDQUFDO0lBQzdELE1BQU0sTUFBTSxHQUFHLE9BQU87SUFDdEIsTUFBTSxJQUFJLEdBQUcsZ0JBQWdCLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQztBQUNqRCxJQUFBLE1BQU0sT0FBTyxHQUFHLEVBQUUsY0FBYyxFQUFFLGlDQUFpQyxFQUFFO0FBQ3JFLElBQUEsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLHFCQUFxQjtBQUM3QyxJQUFBLE1BQU0sV0FBVyxHQUFHLElBQUksV0FBVyxDQUNqQyxHQUFHLEVBQ0gsTUFBTSxFQUNOLGVBQWUsQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLEVBQ2xDLE9BQU8sQ0FDUjtBQUNELElBQUEsV0FBVyxDQUFDLE9BQU8sR0FBRyxPQUFPO0FBQzdCLElBQUEsV0FBVyxDQUFDLElBQUksR0FBRyxJQUFJO0FBQ3ZCLElBQUEsV0FBVyxDQUFDLFlBQVksR0FBRyxrQkFBa0IsQ0FBQyxRQUFRLENBQUM7QUFDdkQsSUFBQSxPQUFPLFdBQVc7QUFDcEI7QUFFTSxTQUFVQyxjQUFZLENBQzFCLE9BQTRCLEVBQzVCLFFBQWtCLEVBQUE7QUFFbEIsSUFBQSxNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsYUFBYSxFQUFFO0FBQ3hDLElBQUEsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUM7SUFDN0QsTUFBTSxNQUFNLEdBQUcsUUFBUTtBQUN2QixJQUFBLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxxQkFBcUI7QUFFN0MsSUFBQSxTQUFTLE9BQU8sQ0FBQyxJQUF3QixFQUFFLEtBQWEsSUFBUztBQUNqRSxJQUFBLE1BQU0sV0FBVyxHQUFHLElBQUksV0FBVyxDQUFDLEdBQUcsRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQztJQUNsRSxXQUFXLENBQUMsWUFBWSxHQUFHLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztBQUNyQyxJQUFBLFdBQVcsQ0FBQyxZQUFZLEdBQUcsa0JBQWtCLENBQUMsUUFBUSxDQUFDO0FBQ3ZELElBQUEsT0FBTyxXQUFXO0FBQ3BCO0FBRU0sU0FBVSxxQkFBcUIsQ0FDbkMsUUFBeUIsRUFDekIsSUFBb0IsRUFBQTtJQUVwQixRQUNFLENBQUMsUUFBUSxJQUFJLFFBQVEsQ0FBQyxhQUFhLENBQUM7QUFDcEMsU0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO0FBQ3JCLFFBQUEsMEJBQTBCO0FBRTlCO1NBRWdCLGtCQUFrQixDQUNoQyxRQUFrQixFQUNsQixJQUFhLEVBQ2IsUUFBMEIsRUFBQTtJQUUxQixNQUFNLGFBQWEsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxRQUFRLENBQUM7QUFDakQsSUFBQSxhQUFhLENBQUMsVUFBVSxDQUFDLEdBQUcsUUFBUSxDQUFDLElBQUk7SUFDekMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLEVBQUU7QUFDbkMsSUFBQSxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxFQUFFO1FBQ2pDLGFBQWEsQ0FBQyxhQUFhLENBQUMsR0FBRyxxQkFBcUIsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDO0lBQ2xFO0FBQ0EsSUFBQSxPQUFPLGFBQWE7QUFDdEI7QUFFQTs7QUFFRztBQUNHLFNBQVUsZUFBZSxDQUM3QixPQUE0QixFQUM1QixRQUFrQixFQUNsQixRQUFrQixFQUNsQixJQUFhLEVBQ2IsUUFBMEIsRUFBQTtBQUUxQixJQUFBLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxtQkFBbUIsRUFBRTtBQUM5QyxJQUFBLE1BQU0sT0FBTyxHQUErQjtBQUMxQyxRQUFBLHdCQUF3QixFQUFFO0tBQzNCO0FBRUQsSUFBQSxTQUFTLFdBQVcsR0FBQTtRQUNsQixJQUFJLEdBQUcsR0FBRyxFQUFFO0FBQ1osUUFBQSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQzFCLFlBQUEsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUMvQztBQUNBLFFBQUEsT0FBTyxHQUFHO0lBQ1o7QUFDQSxJQUFBLE1BQU0sUUFBUSxHQUFHLFdBQVcsRUFBRTtBQUM5QixJQUFBLE9BQU8sQ0FBQyxjQUFjLENBQUMsR0FBRyw4QkFBOEIsR0FBRyxRQUFRO0lBQ25FLE1BQU0sU0FBUyxHQUFHLGtCQUFrQixDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDO0lBQzlELE1BQU0sY0FBYyxHQUFHLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxRQUFRLENBQUM7SUFDNUQsTUFBTSxXQUFXLEdBQ2YsSUFBSTtRQUNKLFFBQVE7UUFDUixNQUFNO1FBQ04sdURBQXVEO1FBQ3ZELGNBQWM7UUFDZCxRQUFRO1FBQ1IsUUFBUTtRQUNSLE1BQU07UUFDTixnQkFBZ0I7UUFDaEIsU0FBUyxDQUFDLGFBQWEsQ0FBQztBQUN4QixRQUFBLFVBQVU7QUFDWixJQUFBLE1BQU0sWUFBWSxHQUFHLFFBQVEsR0FBRyxRQUFRLEdBQUcsSUFBSTtBQUMvQyxJQUFBLE1BQU0sSUFBSSxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLElBQUksRUFBRSxZQUFZLENBQUM7QUFDN0QsSUFBQSxJQUFJLElBQUksS0FBSyxJQUFJLEVBQUU7UUFDakIsTUFBTSxlQUFlLEVBQUU7SUFDekI7SUFDQSxNQUFNLFNBQVMsR0FBYyxFQUFFLElBQUksRUFBRSxTQUFTLENBQUMsVUFBVSxDQUFFLEVBQUU7QUFDN0QsSUFBQSxNQUFNLEdBQUcsR0FBRyxPQUFPLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLFNBQVMsQ0FBQztJQUM3RCxNQUFNLE1BQU0sR0FBRyxNQUFNO0FBQ3JCLElBQUEsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLGtCQUFrQjtBQUMxQyxJQUFBLE1BQU0sV0FBVyxHQUFHLElBQUksV0FBVyxDQUNqQyxHQUFHLEVBQ0gsTUFBTSxFQUNOLGVBQWUsQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLEVBQ2xDLE9BQU8sQ0FDUjtBQUNELElBQUEsV0FBVyxDQUFDLFNBQVMsR0FBRyxTQUFTO0FBQ2pDLElBQUEsV0FBVyxDQUFDLE9BQU8sR0FBRyxPQUFPO0FBQzdCLElBQUEsV0FBVyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFFO0FBQ3BDLElBQUEsV0FBVyxDQUFDLFlBQVksR0FBRyxrQkFBa0IsQ0FBQyxRQUFRLENBQUM7QUFDdkQsSUFBQSxPQUFPLFdBQVc7QUFDcEI7QUFFQTs7Ozs7O0FBTUc7TUFDVSxxQkFBcUIsQ0FBQTtBQUloQyxJQUFBLFdBQUEsQ0FDUyxPQUFlLEVBQ2YsS0FBYSxFQUNwQixTQUFtQixFQUNuQixRQUEwQixFQUFBO1FBSG5CLElBQUEsQ0FBQSxPQUFPLEdBQVAsT0FBTztRQUNQLElBQUEsQ0FBQSxLQUFLLEdBQUwsS0FBSztBQUlaLFFBQUEsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsU0FBUztBQUM1QixRQUFBLElBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxJQUFJLElBQUk7SUFDbEM7QUFDRDtBQUVLLFNBQVUsa0JBQWtCLENBQ2hDLEdBQXVCLEVBQ3ZCLE9BQWtCLEVBQUE7SUFFbEIsSUFBSSxNQUFNLEdBQWtCLElBQUk7QUFDaEMsSUFBQSxJQUFJO0FBQ0YsUUFBQSxNQUFNLEdBQUcsR0FBRyxDQUFDLGlCQUFpQixDQUFDLHNCQUFzQixDQUFDO0lBQ3hEO0lBQUUsT0FBTyxDQUFDLEVBQUU7UUFDVixZQUFZLENBQUMsS0FBSyxDQUFDO0lBQ3JCO0FBQ0EsSUFBQSxNQUFNLGFBQWEsR0FBRyxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUM7QUFDM0MsSUFBQSxZQUFZLENBQUMsQ0FBQyxDQUFDLE1BQU0sSUFBSSxhQUFhLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQztBQUM5RCxJQUFBLE9BQU8sTUFBZ0I7QUFDekI7QUFFTSxTQUFVLHFCQUFxQixDQUNuQyxPQUE0QixFQUM1QixRQUFrQixFQUNsQixRQUFrQixFQUNsQixJQUFhLEVBQ2IsUUFBMEIsRUFBQTtBQUUxQixJQUFBLE1BQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyxtQkFBbUIsRUFBRTtJQUM5QyxNQUFNLGlCQUFpQixHQUFHLGtCQUFrQixDQUFDLFFBQVEsRUFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDO0lBQ3RFLE1BQU0sU0FBUyxHQUFjLEVBQUUsSUFBSSxFQUFFLGlCQUFpQixDQUFDLFVBQVUsQ0FBRSxFQUFFO0FBQ3JFLElBQUEsTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLENBQUM7SUFDN0QsTUFBTSxNQUFNLEdBQUcsTUFBTTtBQUNyQixJQUFBLE1BQU0sT0FBTyxHQUFHO0FBQ2QsUUFBQSx3QkFBd0IsRUFBRSxXQUFXO0FBQ3JDLFFBQUEsdUJBQXVCLEVBQUUsT0FBTztBQUNoQyxRQUFBLHFDQUFxQyxFQUFFLENBQUEsRUFBRyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUEsQ0FBRTtBQUN2RCxRQUFBLG1DQUFtQyxFQUFFLGlCQUFpQixDQUFDLGFBQWEsQ0FBRTtBQUN0RSxRQUFBLGNBQWMsRUFBRTtLQUNqQjtJQUNELE1BQU0sSUFBSSxHQUFHLGdCQUFnQixDQUFDLGlCQUFpQixFQUFFLFFBQVEsQ0FBQztBQUMxRCxJQUFBLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxrQkFBa0I7SUFFMUMsU0FBUyxPQUFPLENBQUMsR0FBdUIsRUFBQTtRQUN0QyxrQkFBa0IsQ0FBQyxHQUFHLENBQUM7QUFDdkIsUUFBQSxJQUFJLEdBQUc7QUFDUCxRQUFBLElBQUk7QUFDRixZQUFBLEdBQUcsR0FBRyxHQUFHLENBQUMsaUJBQWlCLENBQUMsbUJBQW1CLENBQUM7UUFDbEQ7UUFBRSxPQUFPLENBQUMsRUFBRTtZQUNWLFlBQVksQ0FBQyxLQUFLLENBQUM7UUFDckI7QUFDQSxRQUFBLFlBQVksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDM0IsUUFBQSxPQUFPLEdBQWE7SUFDdEI7QUFDQSxJQUFBLE1BQU0sV0FBVyxHQUFHLElBQUksV0FBVyxDQUFDLEdBQUcsRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQztBQUNsRSxJQUFBLFdBQVcsQ0FBQyxTQUFTLEdBQUcsU0FBUztBQUNqQyxJQUFBLFdBQVcsQ0FBQyxPQUFPLEdBQUcsT0FBTztBQUM3QixJQUFBLFdBQVcsQ0FBQyxJQUFJLEdBQUcsSUFBSTtBQUN2QixJQUFBLFdBQVcsQ0FBQyxZQUFZLEdBQUcsa0JBQWtCLENBQUMsUUFBUSxDQUFDO0FBQ3ZELElBQUEsT0FBTyxXQUFXO0FBQ3BCO0FBRUE7O0FBRUc7QUFDRyxTQUFVLHdCQUF3QixDQUN0QyxPQUE0QixFQUM1QixRQUFrQixFQUNsQixHQUFXLEVBQ1gsSUFBYSxFQUFBO0FBRWIsSUFBQSxNQUFNLE9BQU8sR0FBRyxFQUFFLHVCQUF1QixFQUFFLE9BQU8sRUFBRTtJQUVwRCxTQUFTLE9BQU8sQ0FBQyxHQUF1QixFQUFBO0FBQ3RDLFFBQUEsTUFBTSxNQUFNLEdBQUcsa0JBQWtCLENBQUMsR0FBRyxFQUFFLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQzNELElBQUksVUFBVSxHQUFrQixJQUFJO0FBQ3BDLFFBQUEsSUFBSTtBQUNGLFlBQUEsVUFBVSxHQUFHLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyw2QkFBNkIsQ0FBQztRQUNuRTtRQUFFLE9BQU8sQ0FBQyxFQUFFO1lBQ1YsWUFBWSxDQUFDLEtBQUssQ0FBQztRQUNyQjtRQUVBLElBQUksQ0FBQyxVQUFVLEVBQUU7O1lBRWYsWUFBWSxDQUFDLEtBQUssQ0FBQztRQUNyQjtBQUVBLFFBQUEsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLFVBQVUsQ0FBQztBQUMvQixRQUFBLFlBQVksQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMxQixRQUFBLE9BQU8sSUFBSSxxQkFBcUIsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxFQUFFLE1BQU0sS0FBSyxPQUFPLENBQUM7SUFDekU7SUFDQSxNQUFNLE1BQU0sR0FBRyxNQUFNO0FBQ3JCLElBQUEsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLGtCQUFrQjtBQUMxQyxJQUFBLE1BQU0sV0FBVyxHQUFHLElBQUksV0FBVyxDQUFDLEdBQUcsRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQztBQUNsRSxJQUFBLFdBQVcsQ0FBQyxPQUFPLEdBQUcsT0FBTztBQUM3QixJQUFBLFdBQVcsQ0FBQyxZQUFZLEdBQUcsa0JBQWtCLENBQUMsUUFBUSxDQUFDO0FBQ3ZELElBQUEsT0FBTyxXQUFXO0FBQ3BCO0FBRUE7OztBQUdHO0FBQ0ksTUFBTSwyQkFBMkIsR0FBVyxHQUFHLEdBQUcsSUFBSTtBQUU3RDs7Ozs7Ozs7QUFRRztTQUNhLHVCQUF1QixDQUNyQyxRQUFrQixFQUNsQixPQUE0QixFQUM1QixHQUFXLEVBQ1gsSUFBYSxFQUNiLFNBQWlCLEVBQ2pCLFFBQWtCLEVBQ2xCLE1BQXFDLEVBQ3JDLGdCQUE0RCxFQUFBOzs7SUFJNUQsTUFBTSxPQUFPLEdBQUcsSUFBSSxxQkFBcUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQy9DLElBQUksTUFBTSxFQUFFO0FBQ1YsUUFBQSxPQUFPLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPO0FBQ2hDLFFBQUEsT0FBTyxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUMsS0FBSztJQUM5QjtTQUFPO0FBQ0wsUUFBQSxPQUFPLENBQUMsT0FBTyxHQUFHLENBQUM7QUFDbkIsUUFBQSxPQUFPLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLEVBQUU7SUFDN0I7SUFDQSxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxPQUFPLENBQUMsS0FBSyxFQUFFO1FBQ2pDLE1BQU0sbUJBQW1CLEVBQUU7SUFDN0I7SUFDQSxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxPQUFPO0lBQ2pELElBQUksYUFBYSxHQUFHLFNBQVM7QUFDN0IsSUFBQSxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUU7UUFDakIsYUFBYSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLFNBQVMsQ0FBQztJQUNwRDtBQUNBLElBQUEsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLE9BQU87QUFDakMsSUFBQSxNQUFNLE9BQU8sR0FBRyxTQUFTLEdBQUcsYUFBYTtJQUN6QyxJQUFJLGFBQWEsR0FBRyxFQUFFO0FBQ3RCLElBQUEsSUFBSSxhQUFhLEtBQUssQ0FBQyxFQUFFO1FBQ3ZCLGFBQWEsR0FBRyxVQUFVO0lBQzVCO0FBQU8sU0FBQSxJQUFJLFNBQVMsS0FBSyxhQUFhLEVBQUU7UUFDdEMsYUFBYSxHQUFHLGtCQUFrQjtJQUNwQztTQUFPO1FBQ0wsYUFBYSxHQUFHLFFBQVE7SUFDMUI7QUFDQSxJQUFBLE1BQU0sT0FBTyxHQUFHO0FBQ2QsUUFBQSx1QkFBdUIsRUFBRSxhQUFhO0FBQ3RDLFFBQUEsc0JBQXNCLEVBQUUsQ0FBQSxFQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUE7S0FDM0M7SUFDRCxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUM7QUFDM0MsSUFBQSxJQUFJLElBQUksS0FBSyxJQUFJLEVBQUU7UUFDakIsTUFBTSxlQUFlLEVBQUU7SUFDekI7QUFFQSxJQUFBLFNBQVMsT0FBTyxDQUNkLEdBQXVCLEVBQ3ZCLElBQVksRUFBQTs7Ozs7QUFNWixRQUFBLE1BQU0sWUFBWSxHQUFHLGtCQUFrQixDQUFDLEdBQUcsRUFBRSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQztBQUNqRSxRQUFBLE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxPQUFPLEdBQUcsYUFBYTtBQUNsRCxRQUFBLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLEVBQUU7QUFDeEIsUUFBQSxJQUFJLFFBQVE7QUFDWixRQUFBLElBQUksWUFBWSxLQUFLLE9BQU8sRUFBRTtBQUM1QixZQUFBLFFBQVEsR0FBRyxlQUFlLENBQUMsT0FBTyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUM7UUFDMUQ7YUFBTztZQUNMLFFBQVEsR0FBRyxJQUFJO1FBQ2pCO0FBQ0EsUUFBQSxPQUFPLElBQUkscUJBQXFCLENBQzlCLFVBQVUsRUFDVixJQUFJLEVBQ0osWUFBWSxLQUFLLE9BQU8sRUFDeEIsUUFBUSxDQUNUO0lBQ0g7SUFDQSxNQUFNLE1BQU0sR0FBRyxNQUFNO0FBQ3JCLElBQUEsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLGtCQUFrQjtBQUMxQyxJQUFBLE1BQU0sV0FBVyxHQUFHLElBQUksV0FBVyxDQUFDLEdBQUcsRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLE9BQU8sQ0FBQztBQUNsRSxJQUFBLFdBQVcsQ0FBQyxPQUFPLEdBQUcsT0FBTztBQUM3QixJQUFBLFdBQVcsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsRUFBRTtBQUNwQyxJQUFBLFdBQVcsQ0FBQyxnQkFBZ0IsR0FBRyxnQkFBZ0IsSUFBSSxJQUFJO0FBQ3ZELElBQUEsV0FBVyxDQUFDLFlBQVksR0FBRyxrQkFBa0IsQ0FBQyxRQUFRLENBQUM7QUFDdkQsSUFBQSxPQUFPLFdBQVc7QUFDcEI7O0FDMWtCQTs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUFZSDs7O0FBR0c7QUFDSSxNQUFNLFNBQVMsR0FBRztBQUN2Qjs7Ozs7Ozs7Ozs7QUFXRztBQUNILElBQUEsYUFBYSxFQUFFOztBQXNCakI7QUFDQTs7O0FBR0c7QUFDSSxNQUFNLFNBQVMsR0FBRzs7QUFFdkIsSUFBQSxPQUFPLEVBQUUsU0FBUzs7QUFHbEIsSUFBQSxNQUFNLEVBQUUsUUFBUTs7QUFHaEIsSUFBQSxPQUFPLEVBQUUsU0FBUzs7QUFHbEIsSUFBQSxRQUFRLEVBQUUsVUFBVTs7QUFHcEIsSUFBQSxLQUFLLEVBQUU7O0FBR0gsU0FBVSw4QkFBOEIsQ0FDNUMsS0FBd0IsRUFBQTtJQUV4QixRQUFRLEtBQUs7UUFDWCxLQUFBLFNBQUE7UUFDQSxLQUFBLFNBQUE7QUFDQSxRQUFBLEtBQUEsV0FBQTtZQUNFLE9BQU8sU0FBUyxDQUFDLE9BQU87QUFDMUIsUUFBQSxLQUFBLFFBQUE7WUFDRSxPQUFPLFNBQVMsQ0FBQyxNQUFNO0FBQ3pCLFFBQUEsS0FBQSxTQUFBO1lBQ0UsT0FBTyxTQUFTLENBQUMsT0FBTztBQUMxQixRQUFBLEtBQUEsVUFBQTtZQUNFLE9BQU8sU0FBUyxDQUFDLFFBQVE7QUFDM0IsUUFBQSxLQUFBLE9BQUE7WUFDRSxPQUFPLFNBQVMsQ0FBQyxLQUFLO0FBQ3hCLFFBQUE7O1lBRUUsT0FBTyxTQUFTLENBQUMsS0FBSzs7QUFFNUI7O0FDNUdBOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztNQXNEVSxRQUFRLENBQUE7QUFLbkIsSUFBQSxXQUFBLENBQ0UsY0FBK0MsRUFDL0MsS0FBZSxFQUNmLFFBQXFCLEVBQUE7QUFFckIsUUFBQSxNQUFNLFdBQVcsR0FDZixVQUFVLENBQUMsY0FBYyxDQUFDLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxRQUFRLElBQUksSUFBSTtRQUNqRSxJQUFJLFdBQVcsRUFBRTtBQUNmLFlBQUEsSUFBSSxDQUFDLElBQUksR0FBRyxjQUEyQjtBQUN2QyxZQUFBLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxJQUFJLFNBQVM7QUFDL0IsWUFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsSUFBSSxTQUFTO1FBQ3ZDO2FBQU87WUFDTCxNQUFNLFFBQVEsR0FBRyxjQUloQjtBQUNELFlBQUEsSUFBSSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsSUFBSTtBQUN6QixZQUFBLElBQUksQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUs7QUFDM0IsWUFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxRQUFRO1FBQ25DO0lBQ0Y7QUFDRDs7QUNoR0Q7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBRUg7Ozs7QUFJRztBQUNIO0FBQ00sU0FBVSxLQUFLLENBQUMsQ0FBVyxFQUFBO0FBQy9CLElBQUEsT0FBTyxDQUFDLEdBQUcsYUFBd0IsS0FBSTs7QUFFckMsUUFBQSxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsYUFBYSxDQUFDLENBQUM7QUFDbkQsSUFBQSxDQUFDO0FBQ0g7O0FDNUJBOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztBQWNIOzs7QUFHRztBQUNILE1BQWUsYUFBYSxDQUFBO0FBUTFCLElBQUEsV0FBQSxHQUFBO1FBRlUsSUFBQSxDQUFBLEtBQUssR0FBWSxLQUFLO0FBRzlCLFFBQUEsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLGNBQWMsRUFBRTtRQUNoQyxJQUFJLENBQUMsT0FBTyxFQUFFO0FBQ2QsUUFBQSxJQUFJLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQyxRQUFRO1FBQ3BDLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxPQUFPLENBQUMsT0FBTyxJQUFHO1lBQ3hDLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLE1BQUs7QUFDdkMsZ0JBQUEsSUFBSSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUMsS0FBSztBQUNqQyxnQkFBQSxPQUFPLEVBQUU7QUFDWCxZQUFBLENBQUMsQ0FBQztZQUNGLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLE1BQUs7QUFDdkMsZ0JBQUEsSUFBSSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUMsYUFBYTtBQUN6QyxnQkFBQSxPQUFPLEVBQUU7QUFDWCxZQUFBLENBQUMsQ0FBQztZQUNGLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLE1BQUs7QUFDdEMsZ0JBQUEsT0FBTyxFQUFFO0FBQ1gsWUFBQSxDQUFDLENBQUM7QUFDSixRQUFBLENBQUMsQ0FBQztJQUNKO0lBSUEsSUFBSSxDQUNGLEdBQVcsRUFDWCxNQUFjLEVBQ2QsZUFBd0IsRUFDeEIsSUFBc0MsRUFDdEMsT0FBaUIsRUFBQTtBQUVqQixRQUFBLElBQUksSUFBSSxDQUFDLEtBQUssRUFBRTtBQUNkLFlBQUEsTUFBTSxhQUFhLENBQUMsK0JBQStCLENBQUM7UUFDdEQ7QUFDQSxRQUFBLElBQUksa0JBQWtCLENBQUMsR0FBRyxDQUFDLElBQUksZUFBZSxFQUFFO0FBQzlDLFlBQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEdBQUcsSUFBSTtRQUNsQztBQUNBLFFBQUEsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJO1FBQ2pCLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsSUFBSSxDQUFDO0FBQ2pDLFFBQUEsSUFBSSxPQUFPLEtBQUssU0FBUyxFQUFFO0FBQ3pCLFlBQUEsS0FBSyxNQUFNLEdBQUcsSUFBSSxPQUFPLEVBQUU7QUFDekIsZ0JBQUEsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFO0FBQy9CLG9CQUFBLElBQUksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDMUQ7WUFDRjtRQUNGO0FBQ0EsUUFBQSxJQUFJLElBQUksS0FBSyxTQUFTLEVBQUU7QUFDdEIsWUFBQSxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDdEI7YUFBTztBQUNMLFlBQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7UUFDbEI7UUFDQSxPQUFPLElBQUksQ0FBQyxZQUFZO0lBQzFCO0lBRUEsWUFBWSxHQUFBO0FBQ1YsUUFBQSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRTtBQUNmLFlBQUEsTUFBTSxhQUFhLENBQUMsdUNBQXVDLENBQUM7UUFDOUQ7UUFDQSxPQUFPLElBQUksQ0FBQyxVQUFVO0lBQ3hCO0lBRUEsU0FBUyxHQUFBO0FBQ1AsUUFBQSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRTtBQUNmLFlBQUEsTUFBTSxhQUFhLENBQUMsb0NBQW9DLENBQUM7UUFDM0Q7QUFDQSxRQUFBLElBQUk7QUFDRixZQUFBLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNO1FBQ3pCO1FBQUUsT0FBTyxDQUFDLEVBQUU7WUFDVixPQUFPLEVBQUU7UUFDWDtJQUNGO0lBRUEsV0FBVyxHQUFBO0FBQ1QsUUFBQSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRTtBQUNmLFlBQUEsTUFBTSxhQUFhLENBQUMsc0NBQXNDLENBQUM7UUFDN0Q7QUFDQSxRQUFBLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRO0lBQzNCO0lBRUEsWUFBWSxHQUFBO0FBQ1YsUUFBQSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRTtBQUNmLFlBQUEsTUFBTSxhQUFhLENBQUMsdUNBQXVDLENBQUM7UUFDOUQ7QUFDQSxRQUFBLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVO0lBQzdCOztJQUdBLEtBQUssR0FBQTtBQUNILFFBQUEsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUU7SUFDbkI7QUFFQSxJQUFBLGlCQUFpQixDQUFDLE1BQWMsRUFBQTtRQUM5QixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDO0lBQzVDO0FBRUEsSUFBQSx5QkFBeUIsQ0FBQyxRQUFxQyxFQUFBO1FBQzdELElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxFQUFFO1lBQzVCLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUM7UUFDekQ7SUFDRjtBQUVBLElBQUEsNEJBQTRCLENBQUMsUUFBcUMsRUFBQTtRQUNoRSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksRUFBRTtZQUM1QixJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxVQUFVLEVBQUUsUUFBUSxDQUFDO1FBQzVEO0lBQ0Y7QUFDRDtBQUVLLE1BQU8saUJBQWtCLFNBQVEsYUFBcUIsQ0FBQTtJQUMxRCxPQUFPLEdBQUE7QUFDTCxRQUFBLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxHQUFHLE1BQU07SUFDakM7QUFDRDtTQUVlLGlCQUFpQixHQUFBO0FBQy9CLElBQUEsT0FBcUQsSUFBSSxpQkFBaUIsRUFBRTtBQUM5RTtBQUVNLE1BQU8sa0JBQW1CLFNBQVEsYUFBMEIsQ0FBQTtJQUdoRSxPQUFPLEdBQUE7QUFDTCxRQUFBLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxHQUFHLGFBQWE7SUFDeEM7QUFDRDtTQUVlLGtCQUFrQixHQUFBO0lBQ2hDLE9BQU8sSUFBSSxrQkFBa0IsRUFBRTtBQUNqQztBQUVNLE1BQU8saUJBQWtCLFNBQVEsYUFBbUIsQ0FBQTtJQUN4RCxPQUFPLEdBQUE7QUFDTCxRQUFBLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxHQUFHLE1BQU07SUFDakM7QUFDRDtTQUVlLGlCQUFpQixHQUFBO0lBQy9CLE9BQU8sSUFBSSxpQkFBaUIsRUFBRTtBQUNoQzs7QUNoTEE7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBQ0g7O0FBRUc7QUEwQ0g7Ozs7QUFJRztNQUNVLFVBQVUsQ0FBQTtJQXNDckIsMkJBQTJCLEdBQUE7QUFDekIsUUFBQSxPQUFPLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFlBQVk7SUFDM0M7QUFFQTs7OztBQUlHO0FBQ0gsSUFBQSxXQUFBLENBQVksR0FBYyxFQUFFLElBQWEsRUFBRSxXQUE0QixJQUFJLEVBQUE7QUFwQzNFOztBQUVHO1FBQ0gsSUFBQSxDQUFBLFlBQVksR0FBVyxDQUFDO1FBQ2hCLElBQUEsQ0FBQSxrQkFBa0IsR0FBWSxLQUFLO1FBQ25DLElBQUEsQ0FBQSxvQkFBb0IsR0FBWSxLQUFLO1FBQ3JDLElBQUEsQ0FBQSxVQUFVLEdBQXVELEVBQUU7UUFNbkUsSUFBQSxDQUFBLE1BQU0sR0FBa0IsU0FBUztRQUNqQyxJQUFBLENBQUEsVUFBVSxHQUFZLFNBQVM7UUFDL0IsSUFBQSxDQUFBLFFBQVEsR0FBc0IsU0FBUztRQUN2QyxJQUFBLENBQUEsZ0JBQWdCLEdBQVcsQ0FBQztRQUc1QixJQUFBLENBQUEsUUFBUSxHQUFzQyxTQUFTO1FBQ3ZELElBQUEsQ0FBQSxPQUFPLEdBQWdDLFNBQVM7QUFrQnRELFFBQUEsSUFBSSxDQUFDLElBQUksR0FBRyxHQUFHO0FBQ2YsUUFBQSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUk7QUFDakIsUUFBQSxJQUFJLENBQUMsU0FBUyxHQUFHLFFBQVE7QUFDekIsUUFBQSxJQUFJLENBQUMsU0FBUyxHQUFHLFdBQVcsRUFBRTtRQUM5QixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3JELElBQUksQ0FBQyxNQUFNLEdBQUEsU0FBQTtBQUNYLFFBQUEsSUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLElBQUc7QUFDM0IsWUFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLFNBQVM7QUFDekIsWUFBQSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQztZQUN6QixJQUFJLEtBQUssQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLEVBQUU7QUFDaEQsZ0JBQUEsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUk7Z0JBQzlCLElBQUksQ0FBQyxvQkFBb0IsRUFBRTtZQUM3QjtpQkFBTztBQUNMLGdCQUFBLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQywyQkFBMkIsRUFBRTtnQkFDekQsSUFBSSxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLEVBQUUsQ0FBQyxFQUFFO29CQUN2QyxJQUFJLGNBQWMsRUFBRTt3QkFDbEIsS0FBSyxHQUFHLGtCQUFrQixFQUFFO29CQUM5Qjt5QkFBTztBQUNMLHdCQUFBLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FDdkIsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLEVBQ2xCLDZCQUE2QixDQUM5QjtBQUNELHdCQUFBLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJO3dCQUM5QixJQUFJLENBQUMsb0JBQW9CLEVBQUU7d0JBQzNCO29CQUNGO2dCQUNGO0FBQ0EsZ0JBQUEsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLO2dCQUNuQixJQUFJLENBQUMsV0FBVyxDQUFBLE9BQUEsK0JBQXlCO1lBQzNDO0FBQ0YsUUFBQSxDQUFDO0FBQ0QsUUFBQSxJQUFJLENBQUMscUJBQXFCLEdBQUcsS0FBSyxJQUFHO0FBQ25DLFlBQUEsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTO1lBQ3pCLElBQUksS0FBSyxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsRUFBRTtnQkFDaEQsSUFBSSxDQUFDLG9CQUFvQixFQUFFO1lBQzdCO2lCQUFPO0FBQ0wsZ0JBQUEsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLO2dCQUNuQixJQUFJLENBQUMsV0FBVyxDQUFBLE9BQUEsK0JBQXlCO1lBQzNDO0FBQ0YsUUFBQSxDQUFDO0FBQ0QsUUFBQSxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUM7UUFDbEIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0I7UUFDeEQsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEtBQUk7QUFDOUMsWUFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU87QUFDdkIsWUFBQSxJQUFJLENBQUMsT0FBTyxHQUFHLE1BQU07WUFDckIsSUFBSSxDQUFDLE1BQU0sRUFBRTtBQUNmLFFBQUEsQ0FBQyxDQUFDOzs7QUFJRixRQUFBLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxNQUFLLEVBQUUsQ0FBQyxDQUFDO0lBQ3BDO0lBRVEscUJBQXFCLEdBQUE7QUFDM0IsUUFBQSxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsWUFBWTtBQUNwQyxRQUFBLE9BQU8sTUFBTSxJQUFJLElBQUksQ0FBQyxlQUFlLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQztJQUM1RDtBQUVRLElBQUEsa0JBQWtCLENBQUMsSUFBYSxFQUFBO1FBQ3RDLE9BQU8sSUFBSSxDQUFDLElBQUksRUFBRSxHQUFHLEdBQUcsR0FBRyxJQUFJO0lBQ2pDO0lBRVEsTUFBTSxHQUFBO0FBQ1osUUFBQSxJQUFJLElBQUksQ0FBQyxNQUFNLEtBQUEsU0FBQSxrQ0FBZ0M7O1lBRTdDO1FBQ0Y7QUFDQSxRQUFBLElBQUksSUFBSSxDQUFDLFFBQVEsS0FBSyxTQUFTLEVBQUU7WUFDL0I7UUFDRjtBQUNBLFFBQUEsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFO0FBQ25CLFlBQUEsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLFNBQVMsRUFBRTtnQkFDakMsSUFBSSxDQUFDLGdCQUFnQixFQUFFO1lBQ3pCO2lCQUFPO0FBQ0wsZ0JBQUEsSUFBSSxJQUFJLENBQUMsa0JBQWtCLEVBQUU7b0JBQzNCLElBQUksQ0FBQyxZQUFZLEVBQUU7Z0JBQ3JCO3FCQUFPO0FBQ0wsb0JBQUEsSUFBSSxJQUFJLENBQUMsb0JBQW9CLEVBQUU7O3dCQUU3QixJQUFJLENBQUMsY0FBYyxFQUFFO29CQUN2Qjt5QkFBTztBQUNMLHdCQUFBLElBQUksQ0FBQyxjQUFjLEdBQUcsVUFBVSxDQUFDLE1BQUs7QUFDcEMsNEJBQUEsSUFBSSxDQUFDLGNBQWMsR0FBRyxTQUFTOzRCQUMvQixJQUFJLENBQUMsZUFBZSxFQUFFO0FBQ3hCLHdCQUFBLENBQUMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDO29CQUNwQjtnQkFDRjtZQUNGO1FBQ0Y7YUFBTztZQUNMLElBQUksQ0FBQyxjQUFjLEVBQUU7UUFDdkI7SUFDRjtBQUVRLElBQUEsYUFBYSxDQUNuQixRQUEwRSxFQUFBOztRQUcxRSxPQUFPLENBQUMsR0FBRyxDQUFDO0FBQ1YsWUFBQSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUU7QUFDakMsWUFBQSxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUI7U0FDcEMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsU0FBUyxFQUFFLGFBQWEsQ0FBQyxLQUFJO0FBQ3JDLFlBQUEsUUFBUSxJQUFJLENBQUMsTUFBTTtBQUNqQixnQkFBQSxLQUFBLFNBQUE7QUFDRSxvQkFBQSxRQUFRLENBQUMsU0FBUyxFQUFFLGFBQWEsQ0FBQztvQkFDbEM7QUFDRixnQkFBQSxLQUFBLFdBQUE7b0JBQ0UsSUFBSSxDQUFDLFdBQVcsQ0FBQSxVQUFBLGtDQUE0QjtvQkFDNUM7QUFDRixnQkFBQSxLQUFBLFNBQUE7b0JBQ0UsSUFBSSxDQUFDLFdBQVcsQ0FBQSxRQUFBLGdDQUEwQjtvQkFDMUM7O0FBR04sUUFBQSxDQUFDLENBQUM7SUFDSjs7SUFJUSxnQkFBZ0IsR0FBQTtRQUN0QixJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxFQUFFLGFBQWEsS0FBSTtBQUM5QyxZQUFBLE1BQU0sV0FBVyxHQUFHLHFCQUFxQixDQUN2QyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQ25CLElBQUksQ0FBQyxTQUFTLEVBQ2QsSUFBSSxDQUFDLEtBQUssRUFDVixJQUFJLENBQUMsU0FBUyxDQUNmO0FBQ0QsWUFBQSxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQ2xELFdBQVcsRUFDWCxpQkFBaUIsRUFDakIsU0FBUyxFQUNULGFBQWEsQ0FDZDtBQUNELFlBQUEsSUFBSSxDQUFDLFFBQVEsR0FBRyxhQUFhO1lBQzdCLGFBQWEsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFXLEtBQUk7QUFDOUMsZ0JBQUEsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTO0FBQ3pCLGdCQUFBLElBQUksQ0FBQyxVQUFVLEdBQUcsR0FBRztBQUNyQixnQkFBQSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSztnQkFDL0IsSUFBSSxDQUFDLG9CQUFvQixFQUFFO0FBQzdCLFlBQUEsQ0FBQyxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUM7QUFDeEIsUUFBQSxDQUFDLENBQUM7SUFDSjtJQUVRLFlBQVksR0FBQTs7QUFFbEIsUUFBQSxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBb0I7UUFDckMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxDQUFDLFNBQVMsRUFBRSxhQUFhLEtBQUk7WUFDOUMsTUFBTSxXQUFXLEdBQUcsd0JBQXdCLENBQzFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUNqQixJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFDbkIsR0FBRyxFQUNILElBQUksQ0FBQyxLQUFLLENBQ1g7QUFDRCxZQUFBLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FDbEQsV0FBVyxFQUNYLGlCQUFpQixFQUNqQixTQUFTLEVBQ1QsYUFBYSxDQUNkO0FBQ0QsWUFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLGFBQWE7WUFDN0IsYUFBYSxDQUFDLFVBQVUsRUFBRSxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUc7Z0JBQ3ZDLE1BQU0sR0FBRyxNQUErQjtBQUN4QyxnQkFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLFNBQVM7QUFDekIsZ0JBQUEsSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQ3BDLGdCQUFBLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLO0FBQy9CLGdCQUFBLElBQUksTUFBTSxDQUFDLFNBQVMsRUFBRTtBQUNwQixvQkFBQSxJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSTtnQkFDbEM7Z0JBQ0EsSUFBSSxDQUFDLG9CQUFvQixFQUFFO0FBQzdCLFlBQUEsQ0FBQyxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUM7QUFDeEIsUUFBQSxDQUFDLENBQUM7SUFDSjtJQUVRLGVBQWUsR0FBQTtBQUNyQixRQUFBLE1BQU0sU0FBUyxHQUFHLDJCQUEyQixHQUFHLElBQUksQ0FBQyxnQkFBZ0I7QUFDckUsUUFBQSxNQUFNLE1BQU0sR0FBRyxJQUFJLHFCQUFxQixDQUN0QyxJQUFJLENBQUMsWUFBWSxFQUNqQixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUNsQjs7QUFHRCxRQUFBLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxVQUFvQjtRQUNyQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxFQUFFLGFBQWEsS0FBSTtBQUM5QyxZQUFBLElBQUksV0FBVztBQUNmLFlBQUEsSUFBSTtBQUNGLGdCQUFBLFdBQVcsR0FBRyx1QkFBdUIsQ0FDbkMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQ25CLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUNqQixHQUFHLEVBQ0gsSUFBSSxDQUFDLEtBQUssRUFDVixTQUFTLEVBQ1QsSUFBSSxDQUFDLFNBQVMsRUFDZCxNQUFNLEVBQ04sSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQzdCO1lBQ0g7WUFBRSxPQUFPLENBQUMsRUFBRTtBQUNWLGdCQUFBLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBaUI7Z0JBQy9CLElBQUksQ0FBQyxXQUFXLENBQUEsT0FBQSwrQkFBeUI7Z0JBQ3pDO1lBQ0Y7QUFDQSxZQUFBLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FDbEQsV0FBVyxFQUNYLGlCQUFpQixFQUNqQixTQUFTLEVBQ1QsYUFBYTt1QkFDRixLQUFLO2FBQ2pCO0FBQ0QsWUFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLGFBQWE7WUFDN0IsYUFBYSxDQUFDLFVBQVUsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQWdDLEtBQUk7Z0JBQ25FLElBQUksQ0FBQyxtQkFBbUIsRUFBRTtBQUMxQixnQkFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLFNBQVM7QUFDekIsZ0JBQUEsSUFBSSxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDO0FBQ3ZDLGdCQUFBLElBQUksU0FBUyxDQUFDLFNBQVMsRUFBRTtBQUN2QixvQkFBQSxJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQyxRQUFRO29CQUNuQyxJQUFJLENBQUMsV0FBVyxDQUFBLFNBQUEsaUNBQTJCO2dCQUM3QztxQkFBTztvQkFDTCxJQUFJLENBQUMsb0JBQW9CLEVBQUU7Z0JBQzdCO0FBQ0YsWUFBQSxDQUFDLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQztBQUN4QixRQUFBLENBQUMsQ0FBQztJQUNKO0lBRVEsbUJBQW1CLEdBQUE7QUFDekIsUUFBQSxNQUFNLFdBQVcsR0FBRywyQkFBMkIsR0FBRyxJQUFJLENBQUMsZ0JBQWdCOztRQUd2RSxJQUFJLFdBQVcsR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLElBQUksR0FBRyxJQUFJLEVBQUU7QUFDdEMsWUFBQSxJQUFJLENBQUMsZ0JBQWdCLElBQUksQ0FBQztRQUM1QjtJQUNGO0lBRVEsY0FBYyxHQUFBO1FBQ3BCLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxTQUFTLEVBQUUsYUFBYSxLQUFJO1lBQzlDLE1BQU0sV0FBVyxHQUFHSixhQUFXLENBQzdCLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUNqQixJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFDbkIsSUFBSSxDQUFDLFNBQVMsQ0FDZjtBQUNELFlBQUEsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUNwRCxXQUFXLEVBQ1gsaUJBQWlCLEVBQ2pCLFNBQVMsRUFDVCxhQUFhLENBQ2Q7QUFDRCxZQUFBLElBQUksQ0FBQyxRQUFRLEdBQUcsZUFBZTtZQUMvQixlQUFlLENBQUMsVUFBVSxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsSUFBRztBQUMzQyxnQkFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLFNBQVM7QUFDekIsZ0JBQUEsSUFBSSxDQUFDLFNBQVMsR0FBRyxRQUFRO2dCQUN6QixJQUFJLENBQUMsV0FBVyxDQUFBLFNBQUEsaUNBQTJCO0FBQzdDLFlBQUEsQ0FBQyxFQUFFLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztBQUNoQyxRQUFBLENBQUMsQ0FBQztJQUNKO0lBRVEsY0FBYyxHQUFBO1FBQ3BCLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxTQUFTLEVBQUUsYUFBYSxLQUFJO0FBQzlDLFlBQUEsTUFBTSxXQUFXLEdBQUcsZUFBZSxDQUNqQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQ25CLElBQUksQ0FBQyxTQUFTLEVBQ2QsSUFBSSxDQUFDLEtBQUssRUFDVixJQUFJLENBQUMsU0FBUyxDQUNmO0FBQ0QsWUFBQSxNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FDckQsV0FBVyxFQUNYLGlCQUFpQixFQUNqQixTQUFTLEVBQ1QsYUFBYSxDQUNkO0FBQ0QsWUFBQSxJQUFJLENBQUMsUUFBUSxHQUFHLGdCQUFnQjtZQUNoQyxnQkFBZ0IsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxJQUFHO0FBQzVDLGdCQUFBLElBQUksQ0FBQyxRQUFRLEdBQUcsU0FBUztBQUN6QixnQkFBQSxJQUFJLENBQUMsU0FBUyxHQUFHLFFBQVE7Z0JBQ3pCLElBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDdkMsSUFBSSxDQUFDLFdBQVcsQ0FBQSxTQUFBLGlDQUEyQjtBQUM3QyxZQUFBLENBQUMsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDO0FBQ3hCLFFBQUEsQ0FBQyxDQUFDO0lBQ0o7QUFFUSxJQUFBLGVBQWUsQ0FBQyxXQUFtQixFQUFBO0FBQ3pDLFFBQUEsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLFlBQVk7QUFDN0IsUUFBQSxJQUFJLENBQUMsWUFBWSxHQUFHLFdBQVc7Ozs7QUFLL0IsUUFBQSxJQUFJLElBQUksQ0FBQyxZQUFZLEtBQUssR0FBRyxFQUFFO1lBQzdCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtRQUN6QjtJQUNGO0FBRVEsSUFBQSxXQUFXLENBQUMsS0FBd0IsRUFBQTtBQUMxQyxRQUFBLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxLQUFLLEVBQUU7WUFDekI7UUFDRjtRQUNBLFFBQVEsS0FBSztZQUNYLEtBQUEsV0FBQTtBQUNBLFlBQUEsS0FBQSxTQUFBOzs7O0FBSUUsZ0JBQUEsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLO0FBQ25CLGdCQUFBLElBQUksSUFBSSxDQUFDLFFBQVEsS0FBSyxTQUFTLEVBQUU7QUFDL0Isb0JBQUEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUU7Z0JBQ3hCO0FBQU8scUJBQUEsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFO0FBQzlCLG9CQUFBLFlBQVksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDO0FBQ2pDLG9CQUFBLElBQUksQ0FBQyxjQUFjLEdBQUcsU0FBUztvQkFDL0IsSUFBSSxDQUFDLG9CQUFvQixFQUFFO2dCQUM3QjtnQkFDQTtBQUNGLFlBQUEsS0FBQSxTQUFBOzs7O0FBSUUsZ0JBQUEsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLE1BQU07QUFDN0IsZ0JBQUEsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLO2dCQUNuQixJQUFJLFNBQVMsRUFBRTtvQkFDYixJQUFJLENBQUMsZ0JBQWdCLEVBQUU7b0JBQ3ZCLElBQUksQ0FBQyxNQUFNLEVBQUU7Z0JBQ2Y7Z0JBQ0E7QUFDRixZQUFBLEtBQUEsUUFBQTs7O0FBR0UsZ0JBQUEsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLO2dCQUNuQixJQUFJLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQ3ZCO0FBQ0YsWUFBQSxLQUFBLFVBQUE7Ozs7QUFJRSxnQkFBQSxJQUFJLENBQUMsTUFBTSxHQUFHLFFBQVEsRUFBRTtBQUN4QixnQkFBQSxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUs7Z0JBQ25CLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtnQkFDdkI7QUFDRixZQUFBLEtBQUEsT0FBQTs7Ozs7QUFLRSxnQkFBQSxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUs7Z0JBQ25CLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtnQkFDdkI7QUFDRixZQUFBLEtBQUEsU0FBQTs7Ozs7QUFLRSxnQkFBQSxJQUFJLENBQUMsTUFBTSxHQUFHLEtBQUs7Z0JBQ25CLElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtnQkFDdkI7O0lBR047SUFFUSxvQkFBb0IsR0FBQTtBQUMxQixRQUFBLFFBQVEsSUFBSSxDQUFDLE1BQU07QUFDakIsWUFBQSxLQUFBLFNBQUE7Z0JBQ0UsSUFBSSxDQUFDLFdBQVcsQ0FBQSxRQUFBLGdDQUEwQjtnQkFDMUM7QUFDRixZQUFBLEtBQUEsV0FBQTtnQkFDRSxJQUFJLENBQUMsV0FBVyxDQUFBLFVBQUEsa0NBQTRCO2dCQUM1QztBQUNGLFlBQUEsS0FBQSxTQUFBO2dCQUNFLElBQUksQ0FBQyxNQUFNLEVBQUU7Z0JBQ2I7O0lBS047QUFFQTs7QUFFRztBQUNILElBQUEsSUFBSSxRQUFRLEdBQUE7UUFDVixNQUFNLGFBQWEsR0FBRyw4QkFBOEIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ2pFLE9BQU87WUFDTCxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsWUFBWTtBQUNuQyxZQUFBLFVBQVUsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRTtBQUM3QixZQUFBLEtBQUssRUFBRSxhQUFhO1lBQ3BCLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBVTtBQUN6QixZQUFBLElBQUksRUFBRSxJQUFJO1lBQ1YsR0FBRyxFQUFFLElBQUksQ0FBQztTQUNYO0lBQ0g7QUFFQTs7Ozs7Ozs7Ozs7Ozs7OztBQWdCRztBQUNILElBQUEsRUFBRSxDQUNBLElBQWUsRUFDZixjQUcrQyxFQUMvQyxLQUE2QyxFQUM3QyxTQUE2QixFQUFBOztBQUc3QixRQUFBLE1BQU0sUUFBUSxHQUFHLElBQUksUUFBUSxDQUMxQixjQUU4QixJQUFJLFNBQVMsRUFDNUMsS0FBSyxJQUFJLFNBQVMsRUFDbEIsU0FBUyxJQUFJLFNBQVMsQ0FDdkI7QUFDRCxRQUFBLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDO0FBQzNCLFFBQUEsT0FBTyxNQUFLO0FBQ1YsWUFBQSxJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQztBQUNoQyxRQUFBLENBQUM7SUFDSDtBQUVBOzs7OztBQUtHO0lBQ0gsSUFBSSxDQUNGLFdBQW9FLEVBQ3BFLFVBQTZELEVBQUE7OztRQUk3RCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUN2QixXQUE0RCxFQUM1RCxVQUF5RCxDQUMxRDtJQUNIO0FBRUE7O0FBRUc7QUFDSCxJQUFBLEtBQUssQ0FBSSxVQUFnRCxFQUFBO1FBQ3ZELE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDO0lBQ3BDO0FBRUE7O0FBRUc7QUFDSyxJQUFBLFlBQVksQ0FBQyxRQUFzQyxFQUFBO0FBQ3pELFFBQUEsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO0FBQzlCLFFBQUEsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUM7SUFDaEM7QUFFQTs7QUFFRztBQUNLLElBQUEsZUFBZSxDQUFDLFFBQXNDLEVBQUE7UUFDNUQsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDO0FBQzNDLFFBQUEsSUFBSSxDQUFDLEtBQUssRUFBRSxFQUFFO1lBQ1osSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUM5QjtJQUNGO0lBRVEsZ0JBQWdCLEdBQUE7UUFDdEIsSUFBSSxDQUFDLGNBQWMsRUFBRTtRQUNyQixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRTtBQUN6QyxRQUFBLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxJQUFHO0FBQzNCLFlBQUEsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUM7QUFDaEMsUUFBQSxDQUFDLENBQUM7SUFDSjtJQUVRLGNBQWMsR0FBQTtBQUNwQixRQUFBLElBQUksSUFBSSxDQUFDLFFBQVEsS0FBSyxTQUFTLEVBQUU7WUFDL0IsSUFBSSxTQUFTLEdBQUcsSUFBSTtBQUNwQixZQUFBLFFBQVEsOEJBQThCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztnQkFDakQsS0FBSyxTQUFTLENBQUMsT0FBTztBQUNwQixvQkFBQUssS0FBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRTtvQkFDbkQ7Z0JBQ0YsS0FBSyxTQUFTLENBQUMsUUFBUTtnQkFDdkIsS0FBSyxTQUFTLENBQUMsS0FBSztBQUNsQixvQkFBQSxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBcUM7QUFDekQsb0JBQUFBLEtBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsTUFBc0IsQ0FBQyxDQUFDLEVBQUU7b0JBQzFEO0FBQ0YsZ0JBQUE7b0JBQ0UsU0FBUyxHQUFHLEtBQUs7b0JBQ2pCOztZQUVKLElBQUksU0FBUyxFQUFFO0FBQ2IsZ0JBQUEsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTO0FBQ3pCLGdCQUFBLElBQUksQ0FBQyxPQUFPLEdBQUcsU0FBUztZQUMxQjtRQUNGO0lBQ0Y7QUFFUSxJQUFBLGVBQWUsQ0FBQyxRQUFzQyxFQUFBO1FBQzVELE1BQU0sYUFBYSxHQUFHLDhCQUE4QixDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDakUsUUFBUSxhQUFhO1lBQ25CLEtBQUssU0FBUyxDQUFDLE9BQU87WUFDdEIsS0FBSyxTQUFTLENBQUMsTUFBTTtBQUNuQixnQkFBQSxJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUU7QUFDakIsb0JBQUFBLEtBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3pEO2dCQUNBO1lBQ0YsS0FBSyxTQUFTLENBQUMsT0FBTztBQUNwQixnQkFBQSxJQUFJLFFBQVEsQ0FBQyxRQUFRLEVBQUU7b0JBQ3JCQSxLQUFRLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRTtnQkFDOUM7Z0JBQ0E7WUFDRixLQUFLLFNBQVMsQ0FBQyxRQUFRO1lBQ3ZCLEtBQUssU0FBUyxDQUFDLEtBQUs7QUFDbEIsZ0JBQUEsSUFBSSxRQUFRLENBQUMsS0FBSyxFQUFFO0FBQ2xCLG9CQUFBQSxLQUFRLENBQ04sUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFzQixDQUFDLENBQzNELEVBQUU7Z0JBQ0w7Z0JBQ0E7QUFDRixZQUFBOztBQUVFLGdCQUFBLElBQUksUUFBUSxDQUFDLEtBQUssRUFBRTtBQUNsQixvQkFBQUEsS0FBUSxDQUNOLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBc0IsQ0FBQyxDQUMzRCxFQUFFO2dCQUNMOztJQUVOO0FBRUE7OztBQUdHO0lBQ0gsTUFBTSxHQUFBO0FBQ0osUUFBQSxNQUFNLEtBQUssR0FDVCxJQUFJLENBQUMsTUFBTSxLQUFBLFFBQUE7WUFDWCxJQUFJLENBQUMsTUFBTSxLQUFBLFNBQUE7UUFDYixJQUFJLEtBQUssRUFBRTtZQUNULElBQUksQ0FBQyxXQUFXLENBQUEsU0FBQSxpQ0FBMkI7UUFDN0M7QUFDQSxRQUFBLE9BQU8sS0FBSztJQUNkO0FBRUE7OztBQUdHO0lBQ0gsS0FBSyxHQUFBO0FBQ0gsUUFBQSxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTTtRQUN6QixJQUFJLEtBQUssRUFBRTtZQUNULElBQUksQ0FBQyxXQUFXLENBQUEsU0FBQSxpQ0FBMkI7UUFDN0M7QUFDQSxRQUFBLE9BQU8sS0FBSztJQUNkO0FBRUE7Ozs7QUFJRztJQUNILE1BQU0sR0FBQTtBQUNKLFFBQUEsTUFBTSxLQUFLLEdBQ1QsSUFBSSxDQUFDLE1BQU0sS0FBQSxTQUFBO1lBQ1gsSUFBSSxDQUFDLE1BQU0sS0FBQSxTQUFBO1FBQ2IsSUFBSSxLQUFLLEVBQUU7WUFDVCxJQUFJLENBQUMsV0FBVyxDQUFBLFdBQUEsbUNBQTZCO1FBQy9DO0FBQ0EsUUFBQSxPQUFPLEtBQUs7SUFDZDtBQUNEOztBQzdxQkQ7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBRUg7O0FBRUc7QUErQkg7Ozs7Ozs7Ozs7O0FBV0c7TUFDVSxTQUFTLENBQUE7SUFHcEIsV0FBQSxDQUNVLFFBQTZCLEVBQ3JDLFFBQTJCLEVBQUE7UUFEbkIsSUFBQSxDQUFBLFFBQVEsR0FBUixRQUFRO0FBR2hCLFFBQUEsSUFBSSxRQUFRLFlBQVksUUFBUSxFQUFFO0FBQ2hDLFlBQUEsSUFBSSxDQUFDLFNBQVMsR0FBRyxRQUFRO1FBQzNCO2FBQU87QUFDTCxZQUFBLElBQUksQ0FBQyxTQUFTLEdBQUcsUUFBUSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQztRQUNoRTtJQUNGO0FBRUE7Ozs7QUFJRztJQUNILFFBQVEsR0FBQTtBQUNOLFFBQUEsT0FBTyxPQUFPLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSTtJQUNwRTtJQUVVLE9BQU8sQ0FDZixPQUE0QixFQUM1QixRQUFrQixFQUFBO0FBRWxCLFFBQUEsT0FBTyxJQUFJLFNBQVMsQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDO0lBQ3pDO0FBRUE7O0FBRUc7QUFDSCxJQUFBLElBQUksSUFBSSxHQUFBO0FBQ04sUUFBQSxNQUFNLFFBQVEsR0FBRyxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUM7UUFDeEQsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDO0lBQzlDO0FBRUE7O0FBRUc7QUFDSCxJQUFBLElBQUksTUFBTSxHQUFBO0FBQ1IsUUFBQSxPQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTTtJQUM5QjtBQUVBOztBQUVHO0FBQ0gsSUFBQSxJQUFJLFFBQVEsR0FBQTtBQUNWLFFBQUEsT0FBTyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUk7SUFDNUI7QUFFQTs7O0FBR0c7QUFDSCxJQUFBLElBQUksSUFBSSxHQUFBO1FBQ04sT0FBTyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7SUFDM0M7QUFFQTs7QUFFRztBQUNILElBQUEsSUFBSSxPQUFPLEdBQUE7UUFDVCxPQUFPLElBQUksQ0FBQyxRQUFRO0lBQ3RCO0FBRUE7OztBQUdHO0FBQ0gsSUFBQSxJQUFJLE1BQU0sR0FBQTtRQUNSLE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztBQUMzQyxRQUFBLElBQUksT0FBTyxLQUFLLElBQUksRUFBRTtBQUNwQixZQUFBLE9BQU8sSUFBSTtRQUNiO0FBQ0EsUUFBQSxNQUFNLFFBQVEsR0FBRyxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUM7UUFDN0QsT0FBTyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQztJQUMvQztBQUVBOztBQUVHO0FBQ0gsSUFBQSxZQUFZLENBQUMsSUFBWSxFQUFBO1FBQ3ZCLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEtBQUssRUFBRSxFQUFFO0FBQzlCLFlBQUEsTUFBTSxvQkFBb0IsQ0FBQyxJQUFJLENBQUM7UUFDbEM7SUFDRjtBQUNEO0FBRUQ7OztBQUdHO0FBQ0csU0FBVSxnQkFBZ0IsQ0FDOUIsR0FBYyxFQUNkLG9CQUE2QixFQUFBO0FBRTdCLElBQUEsR0FBRyxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUM7QUFDNUIsSUFBQSxNQUFNLFdBQVcsR0FBR0gsVUFBUSxDQUMxQixHQUFHLENBQUMsT0FBTyxFQUNYLEdBQUcsQ0FBQyxTQUFTLEVBQ2Isb0JBQW9CLENBQ3JCO0lBQ0QsT0FBTyxHQUFHLENBQUM7QUFDUixTQUFBLHFCQUFxQixDQUFDLFdBQVcsRUFBRSxrQkFBa0I7QUFDckQsU0FBQSxJQUFJLENBQUMsS0FBSyxJQUNULG9CQUFvQixLQUFLO0FBQ3ZCO0FBQ0csWUFBQSxLQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsb0JBQW9CO1VBQ25ELEtBQXFCLENBQzNCO0FBQ0w7QUFFQTs7O0FBR0c7QUFDRyxTQUFVLGVBQWUsQ0FDN0IsR0FBYyxFQUNkLG9CQUE2QixFQUFBO0FBRTdCLElBQUEsR0FBRyxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUM7QUFDM0IsSUFBQSxNQUFNLFdBQVcsR0FBR0EsVUFBUSxDQUMxQixHQUFHLENBQUMsT0FBTyxFQUNYLEdBQUcsQ0FBQyxTQUFTLEVBQ2Isb0JBQW9CLENBQ3JCO0lBQ0QsT0FBTyxHQUFHLENBQUM7QUFDUixTQUFBLHFCQUFxQixDQUFDLFdBQVcsRUFBRSxpQkFBaUI7QUFDcEQsU0FBQSxJQUFJLENBQUMsSUFBSSxJQUNSLG9CQUFvQixLQUFLO0FBQ3ZCO0FBQ0csWUFBQSxJQUFhLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxvQkFBb0I7VUFDM0MsSUFBYSxDQUNuQjtBQUNMO0FBNENBOzs7Ozs7OztBQVFHO1NBQ2FJLGFBQVcsQ0FDekIsR0FBYyxFQUNkLElBQXFDLEVBQ3JDLFFBQW1CLEVBQUE7QUFFbkIsSUFBQSxHQUFHLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQztJQUMvQixNQUFNLFdBQVcsR0FBRyxlQUFlLENBQ2pDLEdBQUcsQ0FBQyxPQUFPLEVBQ1gsR0FBRyxDQUFDLFNBQVMsRUFDYixXQUFXLEVBQUUsRUFDYixJQUFJLE9BQU8sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEVBQ3ZCLFFBQVEsQ0FDVDtJQUNELE9BQU8sR0FBRyxDQUFDO0FBQ1IsU0FBQSxxQkFBcUIsQ0FBQyxXQUFXLEVBQUUsaUJBQWlCO1NBQ3BELElBQUksQ0FBQyxhQUFhLElBQUc7UUFDcEIsT0FBTztBQUNMLFlBQUEsUUFBUSxFQUFFLGFBQWE7WUFDdkI7U0FDRDtBQUNILElBQUEsQ0FBQyxDQUFDO0FBQ047QUFFQTs7Ozs7Ozs7QUFRRztTQUNhQyxzQkFBb0IsQ0FDbEMsR0FBYyxFQUNkLElBQXFDLEVBQ3JDLFFBQW1CLEVBQUE7QUFFbkIsSUFBQSxHQUFHLENBQUMsWUFBWSxDQUFDLHNCQUFzQixDQUFDO0FBQ3hDLElBQUEsT0FBTyxJQUFJLFVBQVUsQ0FBQyxHQUFHLEVBQUUsSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsUUFBUSxDQUFDO0FBQ3pEO0FBRUE7Ozs7Ozs7OztBQVNHO0FBQ0csU0FBVUMsY0FBWSxDQUMxQixHQUFjLEVBQ2QsS0FBYSxFQUNiLE1BQUEsR0FBdUIsWUFBWSxDQUFDLEdBQUcsRUFDdkMsUUFBbUIsRUFBQTtBQUVuQixJQUFBLEdBQUcsQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDO0lBQ2hDLE1BQU0sSUFBSSxHQUFHLGNBQWMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDO0FBQzFDLElBQUEsTUFBTSxhQUFhLEdBQUcsRUFBRSxHQUFHLFFBQVEsRUFBYztBQUNqRCxJQUFBLElBQUksYUFBYSxDQUFDLGFBQWEsQ0FBQyxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsV0FBVyxJQUFJLElBQUksRUFBRTtBQUNwRSxRQUFBLGFBQWEsQ0FBQyxhQUFhLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBWTtJQUNsRDtJQUNBLE9BQU9GLGFBQVcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxhQUFhLENBQUM7QUFDbkQ7QUFFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBa0JHO0FBQ0csU0FBVUcsU0FBTyxDQUFDLEdBQWMsRUFBQTtBQUNwQyxJQUFBLE1BQU0sV0FBVyxHQUFlO0FBQzlCLFFBQUEsUUFBUSxFQUFFLEVBQUU7QUFDWixRQUFBLEtBQUssRUFBRTtLQUNSO0FBQ0QsSUFBQSxPQUFPLGFBQWEsQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sV0FBVyxDQUFDO0FBQ2hFO0FBRUE7Ozs7O0FBS0c7QUFDSCxlQUFlLGFBQWEsQ0FDMUIsR0FBYyxFQUNkLFdBQXVCLEVBQ3ZCLFNBQWtCLEVBQUE7QUFFbEIsSUFBQSxNQUFNLEdBQUcsR0FBZ0I7O1FBRXZCO0tBQ0Q7SUFDRCxNQUFNLFFBQVEsR0FBRyxNQUFNUixNQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztJQUNyQyxXQUFXLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUM7SUFDL0MsV0FBVyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDO0FBQ3pDLElBQUEsSUFBSSxRQUFRLENBQUMsYUFBYSxJQUFJLElBQUksRUFBRTtRQUNsQyxNQUFNLGFBQWEsQ0FBQyxHQUFHLEVBQUUsV0FBVyxFQUFFLFFBQVEsQ0FBQyxhQUFhLENBQUM7SUFDL0Q7QUFDRjtBQUVBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFxQkc7QUFDRyxTQUFVQSxNQUFJLENBQ2xCLEdBQWMsRUFDZCxPQUE0QixFQUFBO0FBRTVCLElBQUEsSUFBSSxPQUFPLElBQUksSUFBSSxFQUFFO0FBQ25CLFFBQUEsSUFBSSxPQUFPLE9BQU8sQ0FBQyxVQUFVLEtBQUssUUFBUSxFQUFFO0FBQzFDLFlBQUEsY0FBYyxDQUNaLG9CQUFvQjtBQUNwQiw0QkFBZ0IsQ0FBQztBQUNqQiw0QkFBZ0IsSUFBSSxFQUNwQixPQUFPLENBQUMsVUFBVSxDQUNuQjtRQUNIO0lBQ0Y7QUFDQSxJQUFBLE1BQU0sRUFBRSxHQUFHLE9BQU8sSUFBSSxFQUFFO0lBQ3hCLE1BQU0sV0FBVyxHQUFHUyxNQUFZLENBQzlCLEdBQUcsQ0FBQyxPQUFPLEVBQ1gsR0FBRyxDQUFDLFNBQVM7b0JBQ0csR0FBRyxFQUNuQixFQUFFLENBQUMsU0FBUyxFQUNaLEVBQUUsQ0FBQyxVQUFVLENBQ2Q7SUFDRCxPQUFPLEdBQUcsQ0FBQyxPQUFPLENBQUMscUJBQXFCLENBQUMsV0FBVyxFQUFFLGlCQUFpQixDQUFDO0FBQzFFO0FBRUE7Ozs7OztBQU1HO0FBQ0csU0FBVVYsYUFBVyxDQUFDLEdBQWMsRUFBQTtBQUN4QyxJQUFBLEdBQUcsQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDO0FBQy9CLElBQUEsTUFBTSxXQUFXLEdBQUdXLGFBQW1CLENBQ3JDLEdBQUcsQ0FBQyxPQUFPLEVBQ1gsR0FBRyxDQUFDLFNBQVMsRUFDYixXQUFXLEVBQUUsQ0FDZDtJQUNELE9BQU8sR0FBRyxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxXQUFXLEVBQUUsaUJBQWlCLENBQUM7QUFDMUU7QUFFQTs7Ozs7Ozs7OztBQVVHO0FBQ0csU0FBVVIsZ0JBQWMsQ0FDNUIsR0FBYyxFQUNkLFFBQTJCLEVBQUE7QUFFM0IsSUFBQSxHQUFHLENBQUMsWUFBWSxDQUFDLGdCQUFnQixDQUFDO0FBQ2xDLElBQUEsTUFBTSxXQUFXLEdBQUdTLGdCQUFzQixDQUN4QyxHQUFHLENBQUMsT0FBTyxFQUNYLEdBQUcsQ0FBQyxTQUFTLEVBQ2IsUUFBUSxFQUNSLFdBQVcsRUFBRSxDQUNkO0lBQ0QsT0FBTyxHQUFHLENBQUMsT0FBTyxDQUFDLHFCQUFxQixDQUFDLFdBQVcsRUFBRSxpQkFBaUIsQ0FBQztBQUMxRTtBQUVBOzs7OztBQUtHO0FBQ0csU0FBVUMsZ0JBQWMsQ0FBQyxHQUFjLEVBQUE7QUFDM0MsSUFBQSxHQUFHLENBQUMsWUFBWSxDQUFDLGdCQUFnQixDQUFDO0FBQ2xDLElBQUEsTUFBTSxXQUFXLEdBQUdDLGNBQXNCLENBQ3hDLEdBQUcsQ0FBQyxPQUFPLEVBQ1gsR0FBRyxDQUFDLFNBQVMsRUFDYixXQUFXLEVBQUUsQ0FDZDtJQUNELE9BQU8sR0FBRyxDQUFDO0FBQ1IsU0FBQSxxQkFBcUIsQ0FBQyxXQUFXLEVBQUUsaUJBQWlCO1NBQ3BELElBQUksQ0FBQyxHQUFHLElBQUc7QUFDVixRQUFBLElBQUksR0FBRyxLQUFLLElBQUksRUFBRTtZQUNoQixNQUFNLGFBQWEsRUFBRTtRQUN2QjtBQUNBLFFBQUEsT0FBTyxHQUFHO0FBQ1osSUFBQSxDQUFDLENBQUM7QUFDTjtBQUVBOzs7OztBQUtHO0FBQ0csU0FBVVYsY0FBWSxDQUFDLEdBQWMsRUFBQTtBQUN6QyxJQUFBLEdBQUcsQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDO0FBQ2hDLElBQUEsTUFBTSxXQUFXLEdBQUdXLGNBQW9CLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsU0FBUyxDQUFDO0lBQ3BFLE9BQU8sR0FBRyxDQUFDLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQyxXQUFXLEVBQUUsaUJBQWlCLENBQUM7QUFDMUU7QUFFQTs7Ozs7Ozs7O0FBU0c7QUFDRyxTQUFVQyxXQUFTLENBQUMsR0FBYyxFQUFFLFNBQWlCLEVBQUE7QUFDekQsSUFBQSxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDO0FBQ3BELElBQUEsTUFBTSxRQUFRLEdBQUcsSUFBSSxRQUFRLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDO0lBQzVELE9BQU8sSUFBSSxTQUFTLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUM7QUFDN0M7O0FDemZBOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztBQXFDRyxTQUFVLEtBQUssQ0FBQyxJQUFhLEVBQUE7QUFDakMsSUFBQSxPQUFPLGlCQUFpQixDQUFDLElBQUksQ0FBQyxJQUFjLENBQUM7QUFDL0M7QUFFQTs7QUFFRztBQUNILFNBQVMsVUFBVSxDQUFDLE9BQTRCLEVBQUUsR0FBVyxFQUFBO0FBQzNELElBQUEsT0FBTyxJQUFJLFNBQVMsQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDO0FBQ3BDO0FBRUE7OztBQUdHO0FBQ0gsU0FBUyxXQUFXLENBQ2xCLEdBQW9DLEVBQ3BDLElBQWEsRUFBQTtBQUViLElBQUEsSUFBSSxHQUFHLFlBQVksbUJBQW1CLEVBQUU7UUFDdEMsTUFBTSxPQUFPLEdBQUcsR0FBRztBQUNuQixRQUFBLElBQUksT0FBTyxDQUFDLE9BQU8sSUFBSSxJQUFJLEVBQUU7WUFDM0IsTUFBTSxlQUFlLEVBQUU7UUFDekI7UUFDQSxNQUFNLFNBQVMsR0FBRyxJQUFJLFNBQVMsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQVEsQ0FBQztBQUMxRCxRQUFBLElBQUksSUFBSSxJQUFJLElBQUksRUFBRTtBQUNoQixZQUFBLE9BQU8sV0FBVyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUM7UUFDckM7YUFBTztBQUNMLFlBQUEsT0FBTyxTQUFTO1FBQ2xCO0lBQ0Y7U0FBTzs7QUFFTCxRQUFBLElBQUksSUFBSSxLQUFLLFNBQVMsRUFBRTtBQUN0QixZQUFBLE9BQU9BLFdBQVMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDO1FBQzdCO2FBQU87QUFDTCxZQUFBLE9BQU8sR0FBRztRQUNaO0lBQ0Y7QUFDRjtBQXFCTSxTQUFVQyxLQUFHLENBQ2pCLFlBQTZDLEVBQzdDLFNBQWtCLEVBQUE7QUFFbEIsSUFBQSxJQUFJLFNBQVMsSUFBSSxLQUFLLENBQUMsU0FBUyxDQUFDLEVBQUU7QUFDakMsUUFBQSxJQUFJLFlBQVksWUFBWSxtQkFBbUIsRUFBRTtBQUMvQyxZQUFBLE9BQU8sVUFBVSxDQUFDLFlBQVksRUFBRSxTQUFTLENBQUM7UUFDNUM7YUFBTztBQUNMLFlBQUEsTUFBTSxlQUFlLENBQ25CLDBFQUEwRSxDQUMzRTtRQUNIO0lBQ0Y7U0FBTztBQUNMLFFBQUEsT0FBTyxXQUFXLENBQUMsWUFBWSxFQUFFLFNBQVMsQ0FBQztJQUM3QztBQUNGO0FBRUEsU0FBUyxhQUFhLENBQ3BCLElBQVksRUFDWixNQUF3QixFQUFBO0FBRXhCLElBQUEsTUFBTSxZQUFZLEdBQUcsTUFBTSxHQUFHLHlCQUF5QixDQUFDO0FBQ3hELElBQUEsSUFBSSxZQUFZLElBQUksSUFBSSxFQUFFO0FBQ3hCLFFBQUEsT0FBTyxJQUFJO0lBQ2I7SUFDQSxPQUFPLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDO0FBQ3hEO0FBRU0sU0FBVUMsd0JBQXNCLENBQ3BDLE9BQTRCLEVBQzVCLElBQVksRUFDWixJQUFZLEVBQ1osT0FBQSxHQUVJLEVBQUUsRUFBQTtJQUVOLE9BQU8sQ0FBQyxJQUFJLEdBQUcsQ0FBQSxFQUFHLElBQUksQ0FBQSxDQUFBLEVBQUksSUFBSSxFQUFFO0FBQ2hDLElBQUEsTUFBTSxNQUFNLEdBQUcsa0JBQWtCLENBQUMsSUFBSSxDQUFDOztJQUV2QyxJQUFJLE1BQU0sRUFBRTtRQUNWLEtBQUssVUFBVSxDQUFDLENBQUEsUUFBQSxFQUFXLE9BQU8sQ0FBQyxJQUFJLENBQUEsRUFBQSxDQUFJLENBQUM7SUFDOUM7QUFDQSxJQUFBLE9BQU8sQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJO0FBQy9CLElBQUEsT0FBTyxDQUFDLFNBQVMsR0FBRyxNQUFNLEdBQUcsT0FBTyxHQUFHLE1BQU07QUFDN0MsSUFBQSxNQUFNLEVBQUUsYUFBYSxFQUFFLEdBQUcsT0FBTztJQUNqQyxJQUFJLGFBQWEsRUFBRTtBQUNqQixRQUFBLE9BQU8sQ0FBQyxrQkFBa0I7WUFDeEIsT0FBTyxhQUFhLEtBQUs7QUFDdkIsa0JBQUU7QUFDRixrQkFBRSxtQkFBbUIsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDO0lBQ3pFO0FBQ0Y7QUFFQTs7Ozs7QUFLRztNQUNVLG1CQUFtQixDQUFBO0FBZ0I5QixJQUFBLFdBQUE7QUFDRTs7QUFFRztBQUNNLElBQUEsR0FBZ0IsRUFDaEIsYUFBaUQ7QUFDMUQ7O0FBRUc7SUFDTSxpQkFBMEQ7QUFDbkU7O0FBRUc7QUFDTSxJQUFBLElBQWEsRUFDYixnQkFBeUIsRUFDM0IsZ0JBQUEsR0FBbUIsS0FBSyxFQUFBO1FBWHRCLElBQUEsQ0FBQSxHQUFHLEdBQUgsR0FBRztRQUNILElBQUEsQ0FBQSxhQUFhLEdBQWIsYUFBYTtRQUliLElBQUEsQ0FBQSxpQkFBaUIsR0FBakIsaUJBQWlCO1FBSWpCLElBQUEsQ0FBQSxJQUFJLEdBQUosSUFBSTtRQUNKLElBQUEsQ0FBQSxnQkFBZ0IsR0FBaEIsZ0JBQWdCO1FBQ2xCLElBQUEsQ0FBQSxnQkFBZ0IsR0FBaEIsZ0JBQWdCO1FBOUJ6QixJQUFBLENBQUEsT0FBTyxHQUFvQixJQUFJO0FBQy9COzs7O0FBSUc7UUFDSyxJQUFBLENBQUEsS0FBSyxHQUFXLFlBQVk7UUFDcEMsSUFBQSxDQUFBLFNBQVMsR0FBVyxPQUFPO1FBQ1IsSUFBQSxDQUFBLE1BQU0sR0FBa0IsSUFBSTtRQUV2QyxJQUFBLENBQUEsUUFBUSxHQUFZLEtBQUs7QUFzQi9CLFFBQUEsSUFBSSxDQUFDLHNCQUFzQixHQUFHLGdDQUFnQztBQUM5RCxRQUFBLElBQUksQ0FBQyxtQkFBbUIsR0FBRyw2QkFBNkI7QUFDeEQsUUFBQSxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksR0FBRyxFQUFFO0FBQzFCLFFBQUEsSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFO0FBQ2hCLFlBQUEsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUMsa0JBQWtCLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDOUQ7YUFBTztBQUNMLFlBQUEsSUFBSSxDQUFDLE9BQU8sR0FBRyxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQztRQUM1RDtJQUNGO0FBRUE7OztBQUdHO0FBQ0gsSUFBQSxJQUFJLElBQUksR0FBQTtRQUNOLE9BQU8sSUFBSSxDQUFDLEtBQUs7SUFDbkI7SUFFQSxJQUFJLElBQUksQ0FBQyxJQUFZLEVBQUE7QUFDbkIsUUFBQSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUk7QUFDakIsUUFBQSxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxFQUFFO0FBQ3JCLFlBQUEsSUFBSSxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUM7UUFDN0Q7YUFBTztBQUNMLFlBQUEsSUFBSSxDQUFDLE9BQU8sR0FBRyxhQUFhLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDO1FBQ3REO0lBQ0Y7QUFFQTs7QUFFRztBQUNILElBQUEsSUFBSSxrQkFBa0IsR0FBQTtRQUNwQixPQUFPLElBQUksQ0FBQyxtQkFBbUI7SUFDakM7SUFFQSxJQUFJLGtCQUFrQixDQUFDLElBQVksRUFBQTtBQUNqQyxRQUFBLGNBQWMsQ0FDWixNQUFNO0FBQ04sdUJBQWUsQ0FBQztBQUNoQix3QkFBZ0IsTUFBTSxDQUFDLGlCQUFpQixFQUN4QyxJQUFJLENBQ0w7QUFDRCxRQUFBLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJO0lBQ2pDO0FBRUE7OztBQUdHO0FBQ0gsSUFBQSxJQUFJLHFCQUFxQixHQUFBO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLHNCQUFzQjtJQUNwQztJQUVBLElBQUkscUJBQXFCLENBQUMsSUFBWSxFQUFBO0FBQ3BDLFFBQUEsY0FBYyxDQUNaLE1BQU07QUFDTix1QkFBZSxDQUFDO0FBQ2hCLHdCQUFnQixNQUFNLENBQUMsaUJBQWlCLEVBQ3hDLElBQUksQ0FDTDtBQUNELFFBQUEsSUFBSSxDQUFDLHNCQUFzQixHQUFHLElBQUk7SUFDcEM7QUFFQSxJQUFBLE1BQU0sYUFBYSxHQUFBO0FBQ2pCLFFBQUEsSUFBSSxJQUFJLENBQUMsa0JBQWtCLEVBQUU7WUFDM0IsT0FBTyxJQUFJLENBQUMsa0JBQWtCO1FBQ2hDO0FBQ0EsUUFBQSxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUNoRSxJQUFJLElBQUksRUFBRTtBQUNSLFlBQUEsTUFBTSxTQUFTLEdBQUcsTUFBTSxJQUFJLENBQUMsUUFBUSxFQUFFO0FBQ3ZDLFlBQUEsSUFBSSxTQUFTLEtBQUssSUFBSSxFQUFFO2dCQUN0QixPQUFPLFNBQVMsQ0FBQyxXQUFXO1lBQzlCO1FBQ0Y7QUFDQSxRQUFBLE9BQU8sSUFBSTtJQUNiO0FBRUEsSUFBQSxNQUFNLGlCQUFpQixHQUFBO0FBQ3JCLFFBQUEsSUFBSSxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFO0FBQ3JFLFlBQUEsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxhQUFhO1FBQ3hDO0FBQ0EsUUFBQSxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxDQUFDO1FBQ3hFLElBQUksUUFBUSxFQUFFO0FBQ1osWUFBQSxNQUFNLE1BQU0sR0FBRyxNQUFNLFFBQVEsQ0FBQyxRQUFRLEVBQUU7Ozs7O1lBS3hDLE9BQU8sTUFBTSxDQUFDLEtBQUs7UUFDckI7QUFDQSxRQUFBLE9BQU8sSUFBSTtJQUNiO0FBRUE7O0FBRUc7SUFDSCxPQUFPLEdBQUE7QUFDTCxRQUFBLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO0FBQ2xCLFlBQUEsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJO0FBQ3BCLFlBQUEsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQztBQUNuRCxZQUFBLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFO1FBQ3hCO0FBQ0EsUUFBQSxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUU7SUFDMUI7QUFFQTs7O0FBR0c7QUFDSCxJQUFBLHFCQUFxQixDQUFDLEdBQWEsRUFBQTtBQUNqQyxRQUFBLE9BQU8sSUFBSSxTQUFTLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQztJQUNqQztBQUVBOzs7QUFHRztJQUNILFlBQVksQ0FDVixXQUE4QixFQUM5QixjQUFtQyxFQUNuQyxTQUF3QixFQUN4QixhQUE0QixFQUM1QixLQUFLLEdBQUcsSUFBSSxFQUFBO0FBRVosUUFBQSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNsQixNQUFNLE9BQU8sR0FBRyxXQUFXLENBQ3pCLFdBQVcsRUFDWCxJQUFJLENBQUMsTUFBTSxFQUNYLFNBQVMsRUFDVCxhQUFhLEVBQ2IsY0FBYyxFQUNkLElBQUksQ0FBQyxnQkFBZ0IsRUFDckIsS0FBSyxFQUNMLElBQUksQ0FBQyxnQkFBZ0IsQ0FDdEI7QUFDRCxZQUFBLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQzs7QUFFM0IsWUFBQSxPQUFPLENBQUMsVUFBVSxFQUFFLENBQUMsSUFBSSxDQUN2QixNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUNwQyxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUNyQztBQUNELFlBQUEsT0FBTyxPQUFPO1FBQ2hCO2FBQU87QUFDTCxZQUFBLE9BQU8sSUFBSSxXQUFXLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDdEM7SUFDRjtBQUVBLElBQUEsTUFBTSxxQkFBcUIsQ0FDekIsV0FBOEIsRUFDOUIsY0FBbUMsRUFBQTtRQUVuQyxNQUFNLENBQUMsU0FBUyxFQUFFLGFBQWEsQ0FBQyxHQUFHLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztZQUNuRCxJQUFJLENBQUMsYUFBYSxFQUFFO1lBQ3BCLElBQUksQ0FBQyxpQkFBaUI7QUFDdkIsU0FBQSxDQUFDO0FBRUYsUUFBQSxPQUFPLElBQUksQ0FBQyxZQUFZLENBQ3RCLFdBQVcsRUFDWCxjQUFjLEVBQ2QsU0FBUyxFQUNULGFBQWEsQ0FDZCxDQUFDLFVBQVUsRUFBRTtJQUNoQjtBQUNEOzs7OztBQzdXRDs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUFFSDs7QUFFRztBQUNJLE1BQU0sWUFBWSxHQUFHLFNBQVM7O0FDcEJyQzs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUFxRUg7Ozs7Ozs7Ozs7Ozs7QUFhRztBQUNHLFNBQVUsUUFBUSxDQUN0QixHQUFxQixFQUNyQixvQkFBNkIsRUFBQTtBQUU3QixJQUFBLEdBQUcsR0FBRyxrQkFBa0IsQ0FBQyxHQUFHLENBQUM7QUFDN0IsSUFBQSxPQUFPLGdCQUFnQixDQUFDLEdBQWdCLEVBQUUsb0JBQW9CLENBQUM7QUFDakU7QUFFQTs7Ozs7Ozs7QUFRRztTQUNhLFdBQVcsQ0FDekIsR0FBcUIsRUFDckIsSUFBcUMsRUFDckMsUUFBeUIsRUFBQTtBQUV6QixJQUFBLEdBQUcsR0FBRyxrQkFBa0IsQ0FBQyxHQUFHLENBQUM7SUFDN0IsT0FBT0MsYUFBbUIsQ0FDeEIsR0FBZ0IsRUFDaEIsSUFBSSxFQUNKLFFBQTRCLENBQzdCO0FBQ0g7QUFFQTs7Ozs7Ozs7O0FBU0c7QUFDRyxTQUFVLFlBQVksQ0FDMUIsR0FBcUIsRUFDckIsS0FBYSxFQUNiLE1BQXFCLEVBQ3JCLFFBQXlCLEVBQUE7QUFFekIsSUFBQSxHQUFHLEdBQUcsa0JBQWtCLENBQUMsR0FBRyxDQUFDO0lBQzdCLE9BQU9DLGNBQW9CLENBQ3pCLEdBQWdCLEVBQ2hCLEtBQUssRUFDTCxNQUFNLEVBQ04sUUFBNEIsQ0FDN0I7QUFDSDtBQUVBOzs7Ozs7OztBQVFHO1NBQ2Esb0JBQW9CLENBQ2xDLEdBQXFCLEVBQ3JCLElBQXFDLEVBQ3JDLFFBQXlCLEVBQUE7QUFFekIsSUFBQSxHQUFHLEdBQUcsa0JBQWtCLENBQUMsR0FBRyxDQUFDO0lBQzdCLE9BQU9DLHNCQUE0QixDQUNqQyxHQUFnQixFQUNoQixJQUFJLEVBQ0osUUFBNEIsQ0FDZjtBQUNqQjtBQUVBOzs7Ozs7QUFNRztBQUNHLFNBQVUsV0FBVyxDQUFDLEdBQXFCLEVBQUE7QUFDL0MsSUFBQSxHQUFHLEdBQUcsa0JBQWtCLENBQUMsR0FBRyxDQUFDO0FBQzdCLElBQUEsT0FBT0MsYUFBbUIsQ0FBQyxHQUFnQixDQUEwQjtBQUN2RTtBQUVBOzs7Ozs7OztBQVFHO0FBQ0csU0FBVSxjQUFjLENBQzVCLEdBQXFCLEVBQ3JCLFFBQTBCLEVBQUE7QUFFMUIsSUFBQSxHQUFHLEdBQUcsa0JBQWtCLENBQUMsR0FBRyxDQUFDO0FBQzdCLElBQUEsT0FBT0MsZ0JBQXNCLENBQzNCLEdBQWdCLEVBQ2hCLFFBQXFDLENBQ2I7QUFDNUI7QUFFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBcUJHO0FBQ0csU0FBVSxJQUFJLENBQ2xCLEdBQXFCLEVBQ3JCLE9BQXFCLEVBQUE7QUFFckIsSUFBQSxHQUFHLEdBQUcsa0JBQWtCLENBQUMsR0FBRyxDQUFDO0FBQzdCLElBQUEsT0FBT0MsTUFBWSxDQUFDLEdBQWdCLEVBQUUsT0FBTyxDQUFDO0FBQ2hEO0FBRUE7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWtCRztBQUNHLFNBQVUsT0FBTyxDQUFDLEdBQXFCLEVBQUE7QUFDM0MsSUFBQSxHQUFHLEdBQUcsa0JBQWtCLENBQUMsR0FBRyxDQUFDO0FBQzdCLElBQUEsT0FBT0MsU0FBZSxDQUFDLEdBQWdCLENBQUM7QUFDMUM7QUFFQTs7Ozs7O0FBTUc7QUFDRyxTQUFVLGNBQWMsQ0FBQyxHQUFxQixFQUFBO0FBQ2xELElBQUEsR0FBRyxHQUFHLGtCQUFrQixDQUFDLEdBQUcsQ0FBQztBQUM3QixJQUFBLE9BQU9DLGdCQUFzQixDQUFDLEdBQWdCLENBQUM7QUFDakQ7QUFFQTs7Ozs7QUFLRztBQUNHLFNBQVUsWUFBWSxDQUFDLEdBQXFCLEVBQUE7QUFDaEQsSUFBQSxHQUFHLEdBQUcsa0JBQWtCLENBQUMsR0FBRyxDQUFDO0FBQzdCLElBQUEsT0FBT0MsY0FBb0IsQ0FBQyxHQUFnQixDQUFDO0FBQy9DO0FBcUJNLFNBQVUsR0FBRyxDQUNqQixZQUFnRCxFQUNoRCxTQUFrQixFQUFBO0FBRWxCLElBQUEsWUFBWSxHQUFHLGtCQUFrQixDQUFDLFlBQVksQ0FBQztBQUMvQyxJQUFBLE9BQU9DLEtBQVcsQ0FDaEIsWUFBK0MsRUFDL0MsU0FBUyxDQUNWO0FBQ0g7QUFFQTs7QUFFRztBQUNHLFNBQVUsU0FBUyxDQUFDLEdBQXFCLEVBQUUsU0FBaUIsRUFBQTtBQUNoRSxJQUFBLE9BQU9DLFdBQWlCLENBQUMsR0FBZ0IsRUFBRSxTQUFTLENBQUM7QUFDdkQ7QUFFQTs7Ozs7OztBQU9HO1NBQ2EsVUFBVSxDQUN4QixNQUFtQixNQUFNLEVBQUUsRUFDM0IsU0FBa0IsRUFBQTtBQUVsQixJQUFBLEdBQUcsR0FBRyxrQkFBa0IsQ0FBQyxHQUFHLENBQUM7SUFDN0IsTUFBTSxlQUFlLEdBQXdCLFlBQVksQ0FBQyxHQUFHLEVBQUUsWUFBWSxDQUFDO0FBQzVFLElBQUEsTUFBTSxlQUFlLEdBQUcsZUFBZSxDQUFDLFlBQVksQ0FBQztBQUNuRCxRQUFBLFVBQVUsRUFBRTtBQUNiLEtBQUEsQ0FBQztBQUNGLElBQUEsTUFBTSxRQUFRLEdBQUcsaUNBQWlDLENBQUMsU0FBUyxDQUFDO0lBQzdELElBQUksUUFBUSxFQUFFO0FBQ1osUUFBQSxzQkFBc0IsQ0FBQyxlQUFlLEVBQUUsR0FBRyxRQUFRLENBQUM7SUFDdEQ7QUFDQSxJQUFBLE9BQU8sZUFBZTtBQUN4QjtBQUVBOzs7Ozs7Ozs7QUFTRztBQUNHLFNBQVUsc0JBQXNCLENBQ3BDLE9BQXdCLEVBQ3hCLElBQVksRUFDWixJQUFZLEVBQ1osT0FBQSxHQUVJLEVBQUUsRUFBQTtJQUVOQyx3QkFBdUIsQ0FBQyxPQUE4QixFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsT0FBTyxDQUFDO0FBQzlFOztBQzVXQTs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUFNSDs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUFDRyxTQUFVLE9BQU8sQ0FDckIsR0FBcUIsRUFDckIsb0JBQTZCLEVBQUE7QUFFN0IsSUFBQSxHQUFHLEdBQUcsa0JBQWtCLENBQUMsR0FBRyxDQUFDO0FBQzdCLElBQUEsT0FBTyxlQUFlLENBQUMsR0FBZ0IsRUFBRSxvQkFBb0IsQ0FBQztBQUNoRTtBQUVBOzs7Ozs7Ozs7OztBQVdHO0FBQ0csU0FBVSxTQUFTLENBQ3ZCLEdBQXFCLEVBQ3JCLG9CQUE2QixFQUFBO0FBRTdCLElBQUEsTUFBTSxJQUFJLEtBQUssQ0FBQyxnREFBZ0QsQ0FBQztBQUNuRTs7QUM5REE7Ozs7QUFJRztBQUVIOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztBQUNIO0FBdUJBLFNBQVMsT0FBTyxDQUNkLFNBQTZCLEVBQzdCLEVBQUUsa0JBQWtCLEVBQUUsR0FBRyxFQUEwQixFQUFBO0lBRW5ELE1BQU0sR0FBRyxHQUFHLFNBQVMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsWUFBWSxFQUFFO0lBQ3ZELE1BQU0sWUFBWSxHQUFHLFNBQVMsQ0FBQyxXQUFXLENBQUMsZUFBZSxDQUFDO0lBQzNELE1BQU0sZ0JBQWdCLEdBQUcsU0FBUyxDQUFDLFdBQVcsQ0FBQyxvQkFBb0IsQ0FBQztBQUVwRSxJQUFBLE9BQU8sSUFBSSxtQkFBbUIsQ0FDNUIsR0FBRyxFQUNILFlBQVksRUFDWixnQkFBZ0IsRUFDaEIsR0FBRyxFQUNILFdBQVcsQ0FDWjtBQUNIO0FBRUEsU0FBUyxlQUFlLEdBQUE7QUFDdEIsSUFBQSxrQkFBa0IsQ0FDaEIsSUFBSSxTQUFTLENBQ1gsWUFBWSxFQUNaLE9BQU8sRUFBQSxRQUFBLDRCQUVSLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQzdCOztBQUVELElBQUEsZUFBZSxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsRUFBaUIsQ0FBQzs7QUFFakQsSUFBQSxlQUFlLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxTQUFrQixDQUFDO0FBQ3BEO0FBRUEsZUFBZSxFQUFFOzs7OyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDE5LDIwLDIxLDIyLDIzLDI0LDI1LDI2LDI3LDI4LDI5LDMwXX0=