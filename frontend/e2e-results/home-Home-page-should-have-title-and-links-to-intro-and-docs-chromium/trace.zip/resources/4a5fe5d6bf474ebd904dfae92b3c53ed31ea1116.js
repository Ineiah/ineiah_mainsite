//#region node_modules/.pnpm/@primeuix+utils@0.8.0/node_modules/@primeuix/utils/dist/classnames/index.mjs
function c(...e) {
	let t = [];
	for (let s = 0; s < e.length; s++) {
		let n = e[s];
		if (!n) continue;
		let r = typeof n;
		if (r === "string" || r === "number") t.push(n);
		else if (r === "object") {
			let o = Array.isArray(n) ? [c(...n)] : Object.entries(n).map(([i, u]) => u ? i : void 0);
			t = o.length ? t.concat(o.filter((i) => !!i)) : t;
		}
	}
	return t.join(" ").trim();
}
//#endregion
export { c as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2xhc3NuYW1lcy1CVE81UTZ3MS5qcyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8ucG5wbS9AcHJpbWV1aXgrdXRpbHNAMC44LjAvbm9kZV9tb2R1bGVzL0BwcmltZXVpeC91dGlscy9kaXN0L2NsYXNzbmFtZXMvaW5kZXgubWpzIl0sInNvdXJjZXNDb250ZW50IjpbImZ1bmN0aW9uIGMoLi4uZSl7bGV0IHQ9W107Zm9yKGxldCBzPTA7czxlLmxlbmd0aDtzKyspe2xldCBuPWVbc107aWYoIW4pY29udGludWU7bGV0IHI9dHlwZW9mIG47aWYocj09PVwic3RyaW5nXCJ8fHI9PT1cIm51bWJlclwiKXQucHVzaChuKTtlbHNlIGlmKHI9PT1cIm9iamVjdFwiKXtsZXQgbz1BcnJheS5pc0FycmF5KG4pP1tjKC4uLm4pXTpPYmplY3QuZW50cmllcyhuKS5tYXAoKFtpLHVdKT0+dT9pOnZvaWQgMCk7dD1vLmxlbmd0aD90LmNvbmNhdChvLmZpbHRlcihpPT4hIWkpKTp0fX1yZXR1cm4gdC5qb2luKFwiIFwiKS50cmltKCl9ZnVuY3Rpb24gYSguLi5lKXtyZXR1cm4gYyguLi5lKX1leHBvcnR7YSBhcyBjbGFzc05hbWVzLGMgYXMgY259O1xuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXSwibWFwcGluZ3MiOiI7QUFBQSxTQUFTLEVBQUUsR0FBRyxHQUFFO0NBQUMsSUFBSSxJQUFFLENBQUM7Q0FBRSxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsRUFBRSxRQUFPLEtBQUk7RUFBQyxJQUFJLElBQUUsRUFBRTtFQUFHLElBQUcsQ0FBQyxHQUFFO0VBQVMsSUFBSSxJQUFFLE9BQU87RUFBRSxJQUFHLE1BQUksWUFBVSxNQUFJLFVBQVMsRUFBRSxLQUFLLENBQUM7T0FBTyxJQUFHLE1BQUksVUFBUztHQUFDLElBQUksSUFBRSxNQUFNLFFBQVEsQ0FBQyxJQUFFLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxJQUFFLE9BQU8sUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRSxPQUFLLElBQUUsSUFBRSxLQUFLLENBQUM7R0FBRSxJQUFFLEVBQUUsU0FBTyxFQUFFLE9BQU8sRUFBRSxRQUFPLE1BQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFFO0VBQUM7Q0FBQztDQUFDLE9BQU8sRUFBRSxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUs7QUFBQyJ9