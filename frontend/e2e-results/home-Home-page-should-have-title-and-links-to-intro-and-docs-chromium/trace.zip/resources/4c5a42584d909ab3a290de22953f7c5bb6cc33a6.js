import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+image@2.1.0_@types+node@26.1.2_magic-string@1.1.0_magicast@0.5.4_oxc-parser@0.142_8c2f52bee20945aa2ec4d2e10b1999d3/node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue");import { useHead as _$__useHead } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/composables/head.js?v=7e73afc2";
import { useNuxtApp } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/nuxt.js?v=7e73afc2";
import { useRequestEvent as _$__useRequestEvent } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/composables/ssr.js?v=7e73afc2";;import { __nuxtTimelineWrap } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+devtools@3.4.1_db0@0.3.4_better-sqlite3@13.0.2_drizzle-orm@0.45.2_@opentelemetry+_0e55243a794e05cb19a29a0506aae086/node_modules/@nuxt/devtools/dist/runtime/function-metrics-helpers.js?v=7e73afc2";const useHead = __nuxtTimelineWrap("useHead", _$__useHead);const useRequestEvent = __nuxtTimelineWrap("useRequestEvent", _$__useRequestEvent);
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@8.2.0_@types+node@26.1.2_esbuild@0.28.1_jiti@2.7.0_sa_bcac4fa99282966dd94ca7ad2dfebde1/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=7e73afc2"
import { computed, onMounted, ref, useAttrs, useTemplateRef } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
import { useImage } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+image@2.1.0_@types+node@26.1.2_magic-string@1.1.0_magicast@0.5.4_oxc-parser@0.142_8c2f52bee20945aa2ec4d2e10b1999d3/node_modules/@nuxt/image/dist/runtime/composables.js?v=7e73afc2";
import { prerenderStaticImages } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+image@2.1.0_@types+node@26.1.2_magic-string@1.1.0_magicast@0.5.4_oxc-parser@0.142_8c2f52bee20945aa2ec4d2e10b1999d3/node_modules/@nuxt/image/dist/runtime/utils/prerender.js?v=7e73afc2";
import { markFeatureUsage } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+image@2.1.0_@types+node@26.1.2_magic-string@1.1.0_magicast@0.5.4_oxc-parser@0.142_8c2f52bee20945aa2ec4d2e10b1999d3/node_modules/@nuxt/image/dist/runtime/utils/performance.js?v=7e73afc2";
import { useImageProps } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+image@2.1.0_@types+node@26.1.2_magic-string@1.1.0_magicast@0.5.4_oxc-parser@0.142_8c2f52bee20945aa2ec4d2e10b1999d3/node_modules/@nuxt/image/dist/runtime/utils/props.js?v=7e73afc2";


const _sfc_main = {
  __name: "NuxtImg",
  props: {
  custom: { type: Boolean, required: false },
  placeholder: { type: [Boolean, String, Number, Array], required: false },
  placeholderClass: { type: String, required: false },
  src: { type: String, required: false },
  format: { type: String, required: false },
  quality: { type: [String, Number], required: false },
  background: { type: String, required: false },
  fit: { type: String, required: false },
  modifiers: { type: Object, required: false },
  preset: { type: String, required: false },
  provider: { type: null, required: false },
  sizes: { type: [String, Object], required: false },
  densities: { type: String, required: false },
  preload: { type: [Boolean, Object], required: false },
  width: { type: [String, Number], required: false },
  height: { type: [String, Number], required: false },
  crossorigin: { type: [String, Boolean], required: false },
  nonce: { type: String, required: false }
},
  emits: ["load", "error"],
  setup(__props, { expose: __expose, emit: __emit }) {

const props = __props;
const emit = __emit;

const $img = useImage();
const { providerOptions, normalizedAttrs, imageModifiers } = useImageProps(props);
const sizes = computed(() => $img.getSizes(props.src, {
  ...providerOptions.value,
  sizes: props.sizes,
  densities: props.densities,
  modifiers: imageModifiers.value
}));
const placeholderLoaded = ref(false);
const attrs = useAttrs();
const imgAttrs = computed(() => ({
  ...normalizedAttrs.value,
  "data-nuxt-img": "",
  ...!props.placeholder || placeholderLoaded.value ? { sizes: sizes.value.sizes, srcset: sizes.value.srcset } : {},
  ...false ? { onerror: "this.setAttribute('data-error', 1)" } : {},
  ...attrs
}));
const placeholder = computed(() => {
  if (placeholderLoaded.value) {
    return false;
  }
  const placeholder2 = props.placeholder === "" ? [10, 10] : props.placeholder;
  if (!placeholder2) {
    return false;
  }
  if (typeof placeholder2 === "string") {
    return placeholder2;
  }
  const [width = 10, height = width, quality = 50, blur = 3] = Array.isArray(placeholder2) ? placeholder2 : typeof placeholder2 === "number" ? [placeholder2] : [];
  return $img(props.src, {
    ...imageModifiers.value,
    width,
    height,
    quality,
    blur
  }, providerOptions.value);
});
const mainSrc = computed(
  () => props.sizes ? sizes.value.src : $img(props.src, imageModifiers.value, providerOptions.value)
);
const src = computed(() => placeholder.value || mainSrc.value);
if (false && props.preload) {
  const hasMultipleDensities = sizes.value.srcset.includes("x, ");
  const isResponsive = hasMultipleDensities || !!sizes.value.sizes;
  useHead({
    link: [{
      rel: "preload",
      as: "image",
      nonce: props.nonce,
      crossorigin: normalizedAttrs.value.crossorigin,
      href: isResponsive ? sizes.value.src : src.value,
      ...sizes.value.sizes && { imagesizes: sizes.value.sizes },
      ...isResponsive && { imagesrcset: sizes.value.srcset },
      ...typeof props.preload !== "boolean" && props.preload.fetchPriority ? { fetchpriority: props.preload.fetchPriority } : {}
    }]
  });
}
if (false && false) {
  prerenderStaticImages(src.value, sizes.value.srcset, useRequestEvent());
}
const initialLoad = useNuxtApp().isHydrating;
const imgEl = useTemplateRef("imgEl");
__expose({ imgEl });
onMounted(() => {
  if (placeholder.value || props.custom) {
    const img = new Image();
    if (mainSrc.value) {
      img.src = mainSrc.value;
    }
    if (props.sizes) {
      img.sizes = sizes.value.sizes || "";
      img.srcset = sizes.value.srcset;
    }
    if (img.decode) {
      img.decode().then(() => {
        placeholderLoaded.value = true;
        emit("load", new Event("load"));
      }).catch((error) => {
        emit("error", error);
      });
    } else {
      img.onload = (event) => {
        placeholderLoaded.value = true;
        emit("load", event);
      };
      img.onerror = (event) => {
        emit("error", event);
      };
    }
    markFeatureUsage("nuxt-image");
    return;
  }
  if (!imgEl.value) {
    return;
  }
  if (imgEl.value.complete && initialLoad) {
    if (imgEl.value.getAttribute("data-error")) {
      emit("error", new Event("error"));
    } else {
      emit("load", new Event("load"));
    }
  }
  imgEl.value.onload = (event) => {
    emit("load", event);
  };
  imgEl.value.onerror = (event) => {
    emit("error", event);
  };
});

const __returned__ = { props, emit, $img, providerOptions, normalizedAttrs, imageModifiers, sizes, placeholderLoaded, attrs, imgAttrs, placeholder, mainSrc, src, initialLoad, imgEl, computed, onMounted, ref, useAttrs, useTemplateRef, get useImage() { return useImage }, get prerenderStaticImages() { return prerenderStaticImages }, get markFeatureUsage() { return markFeatureUsage }, get useImageProps() { return useImageProps }, get useHead() { return useHead }, get useNuxtApp() { return useNuxtApp }, get useRequestEvent() { return useRequestEvent } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { mergeProps as _mergeProps, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode, normalizeProps as _normalizeProps, guardReactiveProps as _guardReactiveProps, renderSlot as _renderSlot } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2"

const _hoisted_1 = ["src"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (!$props.custom)
    ? (_openBlock(), _tracer(2,2,_createElementBlock("img", _mergeProps({
        key: 0,
        ref: "imgEl",
        class: $setup.placeholder ? $props.placeholderClass : void 0
      }, $setup.imgAttrs, { src: $setup.src }), null, 16 /* FULL_PROPS */, _hoisted_1)))
    : _renderSlot(_ctx.$slots, "default", _normalizeProps(_guardReactiveProps({
  imgAttrs: $setup.imgAttrs,
  isLoaded: $setup.placeholderLoaded,
  src: $setup.src
})), undefined, undefined, 1)
}



_sfc_main.__hmrId = "1e3ec01a"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+image@2.1.0_@types+node@26.1.2_magic-string@1.1.0_magicast@0.5.4_oxc-parser@0.142_8c2f52bee20945aa2ec4d2e10b1999d3/node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue"]])
function _tracer(line, column, vnode) { return _tracerRecordPosition("node_modules/.pnpm/@nuxt+image@2.1.0_@types+node@26.1.2_magic-string@1.1.0_magicast@0.5.4_oxc-parser@0.142_8c2f52bee20945aa2ec4d2e10b1999d3/node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7OztBQW1CQSxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ3hFLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7QUFDekMsTUFBTSxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztBQUMxRCxNQUFNLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDO0FBQ3ZELE1BQU0sQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRTlDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BbUJaO0FBQ0YsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBOEI7O0FBRTNDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDdkIsS0FBSyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDO0FBQ2pGLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSztBQUMxQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUs7QUFDcEIsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTO0FBQzVCLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxjQUFjLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUM7QUFDSCxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7QUFDcEMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDeEIsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxLQUFLO0FBQzFCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xILENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25FLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0gsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2hCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXO0FBQzlFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDaEIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWTtBQUN2QixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLEtBQUs7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDO0FBQzNCLENBQUMsQ0FBQztBQUNGLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLGVBQWUsQ0FBQyxLQUFLO0FBQ25HLENBQUM7QUFDRCxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO0FBQzlELEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pFLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLO0FBQ2xFLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLFdBQVc7QUFDcEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUs7QUFDdEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDL0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzVELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvSCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0o7QUFDQSxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM7QUFDekU7QUFDQSxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFdBQVc7QUFDNUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDckMsUUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUs7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU07QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDdEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ1YsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNWLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUMzQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7V0F6SlMsYUFBTTtpQ0FEZixvQkFNQyxPQU5ELFlBTUM7O1FBSkMsR0FBRyxFQUFDLE9BQU87UUFDVixLQUFLLEVBQUUsa0JBQVcsR0FBRyx1QkFBZ0I7U0FDOUIsZUFBUSxJQUNmLEdBQUcsRUFBRSxVQUFHO01BRVgsWUFPRTtZQUxZLGVBQVE7WUFBYyx3QkFBaUI7T0FBSSIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiTnV4dEltZy52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxuICA8aW1nXG4gICAgdi1pZj1cIiFjdXN0b21cIlxuICAgIHJlZj1cImltZ0VsXCJcbiAgICA6Y2xhc3M9XCJwbGFjZWhvbGRlciA/IHBsYWNlaG9sZGVyQ2xhc3MgOiB2b2lkIDBcIlxuICAgIHYtYmluZD1cImltZ0F0dHJzXCJcbiAgICA6c3JjPVwic3JjXCJcbiAgPlxuICA8c2xvdFxuICAgIHYtZWxzZVxuICAgIHYtYmluZD1cIntcbiAgaW1nQXR0cnMsXG4gIGlzTG9hZGVkOiBwbGFjZWhvbGRlckxvYWRlZCxcbiAgc3JjXG59XCJcbiAgLz5cbjwvdGVtcGxhdGU+XG5cbjxzY3JpcHQgc2V0dXA+XG5pbXBvcnQgeyBjb21wdXRlZCwgb25Nb3VudGVkLCByZWYsIHVzZUF0dHJzLCB1c2VUZW1wbGF0ZVJlZiB9IGZyb20gXCJ2dWVcIjtcbmltcG9ydCB7IHVzZUltYWdlIH0gZnJvbSBcIi4uL2NvbXBvc2FibGVzXCI7XG5pbXBvcnQgeyBwcmVyZW5kZXJTdGF0aWNJbWFnZXMgfSBmcm9tIFwiLi4vdXRpbHMvcHJlcmVuZGVyXCI7XG5pbXBvcnQgeyBtYXJrRmVhdHVyZVVzYWdlIH0gZnJvbSBcIi4uL3V0aWxzL3BlcmZvcm1hbmNlXCI7XG5pbXBvcnQgeyB1c2VJbWFnZVByb3BzIH0gZnJvbSBcIi4uL3V0aWxzL3Byb3BzXCI7XG5pbXBvcnQgeyB1c2VIZWFkLCB1c2VOdXh0QXBwLCB1c2VSZXF1ZXN0RXZlbnQgfSBmcm9tIFwiI2ltcG9ydHNcIjtcbmNvbnN0IHByb3BzID0gZGVmaW5lUHJvcHMoe1xuICBjdXN0b206IHsgdHlwZTogQm9vbGVhbiwgcmVxdWlyZWQ6IGZhbHNlIH0sXG4gIHBsYWNlaG9sZGVyOiB7IHR5cGU6IFtCb29sZWFuLCBTdHJpbmcsIE51bWJlciwgQXJyYXldLCByZXF1aXJlZDogZmFsc2UgfSxcbiAgcGxhY2Vob2xkZXJDbGFzczogeyB0eXBlOiBTdHJpbmcsIHJlcXVpcmVkOiBmYWxzZSB9LFxuICBzcmM6IHsgdHlwZTogU3RyaW5nLCByZXF1aXJlZDogZmFsc2UgfSxcbiAgZm9ybWF0OiB7IHR5cGU6IFN0cmluZywgcmVxdWlyZWQ6IGZhbHNlIH0sXG4gIHF1YWxpdHk6IHsgdHlwZTogW1N0cmluZywgTnVtYmVyXSwgcmVxdWlyZWQ6IGZhbHNlIH0sXG4gIGJhY2tncm91bmQ6IHsgdHlwZTogU3RyaW5nLCByZXF1aXJlZDogZmFsc2UgfSxcbiAgZml0OiB7IHR5cGU6IFN0cmluZywgcmVxdWlyZWQ6IGZhbHNlIH0sXG4gIG1vZGlmaWVyczogeyB0eXBlOiBPYmplY3QsIHJlcXVpcmVkOiBmYWxzZSB9LFxuICBwcmVzZXQ6IHsgdHlwZTogU3RyaW5nLCByZXF1aXJlZDogZmFsc2UgfSxcbiAgcHJvdmlkZXI6IHsgdHlwZTogbnVsbCwgcmVxdWlyZWQ6IGZhbHNlIH0sXG4gIHNpemVzOiB7IHR5cGU6IFtTdHJpbmcsIE9iamVjdF0sIHJlcXVpcmVkOiBmYWxzZSB9LFxuICBkZW5zaXRpZXM6IHsgdHlwZTogU3RyaW5nLCByZXF1aXJlZDogZmFsc2UgfSxcbiAgcHJlbG9hZDogeyB0eXBlOiBbQm9vbGVhbiwgT2JqZWN0XSwgcmVxdWlyZWQ6IGZhbHNlIH0sXG4gIHdpZHRoOiB7IHR5cGU6IFtTdHJpbmcsIE51bWJlcl0sIHJlcXVpcmVkOiBmYWxzZSB9LFxuICBoZWlnaHQ6IHsgdHlwZTogW1N0cmluZywgTnVtYmVyXSwgcmVxdWlyZWQ6IGZhbHNlIH0sXG4gIGNyb3Nzb3JpZ2luOiB7IHR5cGU6IFtTdHJpbmcsIEJvb2xlYW5dLCByZXF1aXJlZDogZmFsc2UgfSxcbiAgbm9uY2U6IHsgdHlwZTogU3RyaW5nLCByZXF1aXJlZDogZmFsc2UgfVxufSk7XG5jb25zdCBlbWl0ID0gZGVmaW5lRW1pdHMoW1wibG9hZFwiLCBcImVycm9yXCJdKTtcbmRlZmluZVNsb3RzKCk7XG5jb25zdCAkaW1nID0gdXNlSW1hZ2UoKTtcbmNvbnN0IHsgcHJvdmlkZXJPcHRpb25zLCBub3JtYWxpemVkQXR0cnMsIGltYWdlTW9kaWZpZXJzIH0gPSB1c2VJbWFnZVByb3BzKHByb3BzKTtcbmNvbnN0IHNpemVzID0gY29tcHV0ZWQoKCkgPT4gJGltZy5nZXRTaXplcyhwcm9wcy5zcmMsIHtcbiAgLi4ucHJvdmlkZXJPcHRpb25zLnZhbHVlLFxuICBzaXplczogcHJvcHMuc2l6ZXMsXG4gIGRlbnNpdGllczogcHJvcHMuZGVuc2l0aWVzLFxuICBtb2RpZmllcnM6IGltYWdlTW9kaWZpZXJzLnZhbHVlXG59KSk7XG5jb25zdCBwbGFjZWhvbGRlckxvYWRlZCA9IHJlZihmYWxzZSk7XG5jb25zdCBhdHRycyA9IHVzZUF0dHJzKCk7XG5jb25zdCBpbWdBdHRycyA9IGNvbXB1dGVkKCgpID0+ICh7XG4gIC4uLm5vcm1hbGl6ZWRBdHRycy52YWx1ZSxcbiAgXCJkYXRhLW51eHQtaW1nXCI6IFwiXCIsXG4gIC4uLiFwcm9wcy5wbGFjZWhvbGRlciB8fCBwbGFjZWhvbGRlckxvYWRlZC52YWx1ZSA/IHsgc2l6ZXM6IHNpemVzLnZhbHVlLnNpemVzLCBzcmNzZXQ6IHNpemVzLnZhbHVlLnNyY3NldCB9IDoge30sXG4gIC4uLmltcG9ydC5tZXRhLnNlcnZlciA/IHsgb25lcnJvcjogXCJ0aGlzLnNldEF0dHJpYnV0ZSgnZGF0YS1lcnJvcicsIDEpXCIgfSA6IHt9LFxuICAuLi5hdHRyc1xufSkpO1xuY29uc3QgcGxhY2Vob2xkZXIgPSBjb21wdXRlZCgoKSA9PiB7XG4gIGlmIChwbGFjZWhvbGRlckxvYWRlZC52YWx1ZSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBjb25zdCBwbGFjZWhvbGRlcjIgPSBwcm9wcy5wbGFjZWhvbGRlciA9PT0gXCJcIiA/IFsxMCwgMTBdIDogcHJvcHMucGxhY2Vob2xkZXI7XG4gIGlmICghcGxhY2Vob2xkZXIyKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmICh0eXBlb2YgcGxhY2Vob2xkZXIyID09PSBcInN0cmluZ1wiKSB7XG4gICAgcmV0dXJuIHBsYWNlaG9sZGVyMjtcbiAgfVxuICBjb25zdCBbd2lkdGggPSAxMCwgaGVpZ2h0ID0gd2lkdGgsIHF1YWxpdHkgPSA1MCwgYmx1ciA9IDNdID0gQXJyYXkuaXNBcnJheShwbGFjZWhvbGRlcjIpID8gcGxhY2Vob2xkZXIyIDogdHlwZW9mIHBsYWNlaG9sZGVyMiA9PT0gXCJudW1iZXJcIiA/IFtwbGFjZWhvbGRlcjJdIDogW107XG4gIHJldHVybiAkaW1nKHByb3BzLnNyYywge1xuICAgIC4uLmltYWdlTW9kaWZpZXJzLnZhbHVlLFxuICAgIHdpZHRoLFxuICAgIGhlaWdodCxcbiAgICBxdWFsaXR5LFxuICAgIGJsdXJcbiAgfSwgcHJvdmlkZXJPcHRpb25zLnZhbHVlKTtcbn0pO1xuY29uc3QgbWFpblNyYyA9IGNvbXB1dGVkKFxuICAoKSA9PiBwcm9wcy5zaXplcyA/IHNpemVzLnZhbHVlLnNyYyA6ICRpbWcocHJvcHMuc3JjLCBpbWFnZU1vZGlmaWVycy52YWx1ZSwgcHJvdmlkZXJPcHRpb25zLnZhbHVlKVxuKTtcbmNvbnN0IHNyYyA9IGNvbXB1dGVkKCgpID0+IHBsYWNlaG9sZGVyLnZhbHVlIHx8IG1haW5TcmMudmFsdWUpO1xuaWYgKGltcG9ydC5tZXRhLnNlcnZlciAmJiBwcm9wcy5wcmVsb2FkKSB7XG4gIGNvbnN0IGhhc011bHRpcGxlRGVuc2l0aWVzID0gc2l6ZXMudmFsdWUuc3Jjc2V0LmluY2x1ZGVzKFwieCwgXCIpO1xuICBjb25zdCBpc1Jlc3BvbnNpdmUgPSBoYXNNdWx0aXBsZURlbnNpdGllcyB8fCAhIXNpemVzLnZhbHVlLnNpemVzO1xuICB1c2VIZWFkKHtcbiAgICBsaW5rOiBbe1xuICAgICAgcmVsOiBcInByZWxvYWRcIixcbiAgICAgIGFzOiBcImltYWdlXCIsXG4gICAgICBub25jZTogcHJvcHMubm9uY2UsXG4gICAgICBjcm9zc29yaWdpbjogbm9ybWFsaXplZEF0dHJzLnZhbHVlLmNyb3Nzb3JpZ2luLFxuICAgICAgaHJlZjogaXNSZXNwb25zaXZlID8gc2l6ZXMudmFsdWUuc3JjIDogc3JjLnZhbHVlLFxuICAgICAgLi4uc2l6ZXMudmFsdWUuc2l6ZXMgJiYgeyBpbWFnZXNpemVzOiBzaXplcy52YWx1ZS5zaXplcyB9LFxuICAgICAgLi4uaXNSZXNwb25zaXZlICYmIHsgaW1hZ2VzcmNzZXQ6IHNpemVzLnZhbHVlLnNyY3NldCB9LFxuICAgICAgLi4udHlwZW9mIHByb3BzLnByZWxvYWQgIT09IFwiYm9vbGVhblwiICYmIHByb3BzLnByZWxvYWQuZmV0Y2hQcmlvcml0eSA/IHsgZmV0Y2hwcmlvcml0eTogcHJvcHMucHJlbG9hZC5mZXRjaFByaW9yaXR5IH0gOiB7fVxuICAgIH1dXG4gIH0pO1xufVxuaWYgKGltcG9ydC5tZXRhLnNlcnZlciAmJiBpbXBvcnQubWV0YS5wcmVyZW5kZXIpIHtcbiAgcHJlcmVuZGVyU3RhdGljSW1hZ2VzKHNyYy52YWx1ZSwgc2l6ZXMudmFsdWUuc3Jjc2V0LCB1c2VSZXF1ZXN0RXZlbnQoKSk7XG59XG5jb25zdCBpbml0aWFsTG9hZCA9IHVzZU51eHRBcHAoKS5pc0h5ZHJhdGluZztcbmNvbnN0IGltZ0VsID0gdXNlVGVtcGxhdGVSZWYoXCJpbWdFbFwiKTtcbmRlZmluZUV4cG9zZSh7IGltZ0VsIH0pO1xub25Nb3VudGVkKCgpID0+IHtcbiAgaWYgKHBsYWNlaG9sZGVyLnZhbHVlIHx8IHByb3BzLmN1c3RvbSkge1xuICAgIGNvbnN0IGltZyA9IG5ldyBJbWFnZSgpO1xuICAgIGlmIChtYWluU3JjLnZhbHVlKSB7XG4gICAgICBpbWcuc3JjID0gbWFpblNyYy52YWx1ZTtcbiAgICB9XG4gICAgaWYgKHByb3BzLnNpemVzKSB7XG4gICAgICBpbWcuc2l6ZXMgPSBzaXplcy52YWx1ZS5zaXplcyB8fCBcIlwiO1xuICAgICAgaW1nLnNyY3NldCA9IHNpemVzLnZhbHVlLnNyY3NldDtcbiAgICB9XG4gICAgaWYgKGltZy5kZWNvZGUpIHtcbiAgICAgIGltZy5kZWNvZGUoKS50aGVuKCgpID0+IHtcbiAgICAgICAgcGxhY2Vob2xkZXJMb2FkZWQudmFsdWUgPSB0cnVlO1xuICAgICAgICBlbWl0KFwibG9hZFwiLCBuZXcgRXZlbnQoXCJsb2FkXCIpKTtcbiAgICAgIH0pLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgICBlbWl0KFwiZXJyb3JcIiwgZXJyb3IpO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGltZy5vbmxvYWQgPSAoZXZlbnQpID0+IHtcbiAgICAgICAgcGxhY2Vob2xkZXJMb2FkZWQudmFsdWUgPSB0cnVlO1xuICAgICAgICBlbWl0KFwibG9hZFwiLCBldmVudCk7XG4gICAgICB9O1xuICAgICAgaW1nLm9uZXJyb3IgPSAoZXZlbnQpID0+IHtcbiAgICAgICAgZW1pdChcImVycm9yXCIsIGV2ZW50KTtcbiAgICAgIH07XG4gICAgfVxuICAgIG1hcmtGZWF0dXJlVXNhZ2UoXCJudXh0LWltYWdlXCIpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoIWltZ0VsLnZhbHVlKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChpbWdFbC52YWx1ZS5jb21wbGV0ZSAmJiBpbml0aWFsTG9hZCkge1xuICAgIGlmIChpbWdFbC52YWx1ZS5nZXRBdHRyaWJ1dGUoXCJkYXRhLWVycm9yXCIpKSB7XG4gICAgICBlbWl0KFwiZXJyb3JcIiwgbmV3IEV2ZW50KFwiZXJyb3JcIikpO1xuICAgIH0gZWxzZSB7XG4gICAgICBlbWl0KFwibG9hZFwiLCBuZXcgRXZlbnQoXCJsb2FkXCIpKTtcbiAgICB9XG4gIH1cbiAgaW1nRWwudmFsdWUub25sb2FkID0gKGV2ZW50KSA9PiB7XG4gICAgZW1pdChcImxvYWRcIiwgZXZlbnQpO1xuICB9O1xuICBpbWdFbC52YWx1ZS5vbmVycm9yID0gKGV2ZW50KSA9PiB7XG4gICAgZW1pdChcImVycm9yXCIsIGV2ZW50KTtcbiAgfTtcbn0pO1xuPC9zY3JpcHQ+XG5cbjxzY3JpcHQ+XG5cbjwvc2NyaXB0PlxuIl0sImZpbGUiOiIvVm9sdW1lcy9Db2RpbmcvUHJvamVjdHMvV2Vic2l0ZXMvaW5laWFoL2Zyb250ZW5kL25vZGVfbW9kdWxlcy8ucG5wbS9AbnV4dCtpbWFnZUAyLjEuMF9AdHlwZXMrbm9kZUAyNi4xLjJfbWFnaWMtc3RyaW5nQDEuMS4wX21hZ2ljYXN0QDAuNS40X294Yy1wYXJzZXJAMC4xNDJfOGMyZjUyYmVlMjA5NDVhYTJlYzRkMmUxMGIxOTk5ZDMvbm9kZV9tb2R1bGVzL0BudXh0L2ltYWdlL2Rpc3QvcnVudGltZS9jb21wb25lbnRzL051eHRJbWcudnVlIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==