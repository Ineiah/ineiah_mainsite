import { browserLocalPersistence, browserPopupRedirectResolver, browserSessionPersistence, indexedDBLocalPersistence, initializeAuth, onIdTokenChanged, updateProfile } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/firebase@12.17.0/node_modules/firebase/auth/dist/esm/index.esm.js?v=7e73afc2";
import { computed, effectScope, getCurrentInstance, getCurrentScope, inject, isRef, isVue2, isVue3, onScopeDispose, onServerPrefetch, ref, shallowRef, toRef, toValue, watch } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/compat/vue-demi.js?v=7e73afc2";
import { initializeAppCheck, onTokenChanged } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/firebase@12.17.0/node_modules/firebase/app-check/dist/esm/index.esm.js?v=7e73afc2";
import { getApp } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/firebase@12.17.0/node_modules/firebase/app/dist/esm/index.esm.js?v=7e73afc2";
import { get, getDatabase, onChildAdded, onChildChanged, onChildMoved, onChildRemoved, onValue } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/firebase@12.17.0/node_modules/firebase/database/dist/esm/index.esm.js?v=7e73afc2";
import { GeoPoint, Timestamp, getDoc, getDocs, getFirestore, onSnapshot } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/firebase@12.17.0/node_modules/firebase/firestore/dist/esm/index.esm.js?v=7e73afc2";
import { getDownloadURL, getMetadata, getStorage, updateMetadata, uploadBytesResumable } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/firebase@12.17.0/node_modules/firebase/storage/dist/esm/index.esm.js?v=7e73afc2";
//#region node_modules/.pnpm/vuefire@3.2.3_consola@3.4.2_firebase@12.17.0_vue@3.5.40_typescript@6.0.3_/node_modules/vuefire/dist/shared/vuefire.0feb90cc.mjs
var _FirebaseAppInjectionKey = Symbol("firebaseApp");
function useFirebaseApp(name) {
	return getCurrentInstance() && inject(_FirebaseAppInjectionKey, null) || getApp(name);
}
var noop = () => {};
var isClient = typeof window !== "undefined";
function walkGet(obj, path) {
	return path.split(".").reduce((target, key) => target && target[key], obj);
}
function walkSet(obj, path, value) {
	const keys = ("" + path).split(".");
	const key = keys.pop();
	const target = keys.reduce((target2, key2) => target2 && target2[key2], obj);
	if (target == null) return;
	return Array.isArray(target) ? target.splice(Number(key), 1, value) : target[key] = value;
}
function isObject(o) {
	return !!o && typeof o === "object";
}
var ObjectPrototype = Object.prototype;
function isPOJO(obj) {
	return isObject(obj) && Object.getPrototypeOf(obj) === ObjectPrototype;
}
function isDocumentRef(o) {
	return isObject(o) && o.type === "document";
}
function isCollectionRef(o) {
	return isObject(o) && o.type === "collection";
}
function isFirestoreDataReference(source) {
	return isDocumentRef(source) || isCollectionRef(source);
}
function isFirestoreQuery(source) {
	return isObject(source) && source.type === "query";
}
function isDatabaseReference(source) {
	return isObject(source) && "ref" in source;
}
function isStorageReference(source) {
	return isObject(source) && typeof source.bucket === "string";
}
function callOnceWithArg(fn, argFn) {
	let called;
	return () => {
		if (!called) {
			called = true;
			return fn(argFn());
		}
	};
}
var ssrContextKey = Symbol.for("v-scx");
function useIsSSR() {
	const instance = getCurrentInstance();
	return !!(isVue2 ? instance && instance.proxy.$isServer : inject(ssrContextKey, 0));
}
function checkWrittenTarget(data, fnName) {
	if (Object.getOwnPropertyDescriptor(data, "data")?.get?.() === data) {
		console.warn(`[VueFire] the passed "options.target" is already the returned value of "${fnName}". If you want to subscribe to a different data source, pass a reactive variable to "${fnName}" instead:
https://vuefire.vuejs.org/guide/realtime-data.html#declarative-realtime-data
This will FAIL in production.`);
		return true;
	}
	return false;
}
var scopeMap = /* @__PURE__ */ new WeakMap();
function getGlobalScope(firebaseApp, app) {
	if (!scopeMap.has(firebaseApp)) {
		const scope = effectScope(true);
		scopeMap.set(firebaseApp, scope);
		const { unmount } = app;
		app.unmount = () => {
			unmount.call(app);
			scope.stop();
			scopeMap.delete(firebaseApp);
		};
	}
	return scopeMap.get(firebaseApp);
}
var authUserMap = /* @__PURE__ */ new WeakMap();
function useCurrentUser(name) {
	if (!authUserMap.has(useFirebaseApp(name))) throw new Error(`[VueFire] useCurrentUser() called before the VueFireAuth module was added to the VueFire plugin. This will fail in production.`);
	return authUserMap.get(useFirebaseApp(name));
}
function useIsCurrentUserLoaded(name) {
	const currentUser = useCurrentUser(name);
	return computed(() => currentUser.value !== void 0);
}
function updateCurrentUserProfile(profile) {
	return getCurrentUser().then((user) => {
		if (user) return updateProfile(user, profile).then(() => user.reload());
	});
}
var initialUserMap = /* @__PURE__ */ new WeakMap();
function _getCurrentUserState(name) {
	const firebaseApp = useFirebaseApp(name);
	if (!initialUserMap.has(firebaseApp)) {
		let resolve;
		const userState = [new Promise((_resolve) => {
			resolve = _resolve;
		}), (user) => {
			initialUserMap.set(firebaseApp, user);
			resolve(user.value);
		}];
		initialUserMap.set(firebaseApp, userState);
	}
	return initialUserMap.get(firebaseApp);
}
function getCurrentUser(name) {
	const userOrPromise = _getCurrentUserState(name);
	return Array.isArray(userOrPromise) ? userOrPromise[0] : Promise.resolve(userOrPromise.value);
}
function setupOnAuthStateChanged(user, auth) {
	onIdTokenChanged(auth, (userData) => {
		const userOrPromise = _getCurrentUserState();
		user.value = userData;
		if (Array.isArray(userOrPromise)) userOrPromise[1](user);
	});
}
var AppCheckTokenInjectSymbol = Symbol("app-check-token");
function useAppCheckToken() {
	return inject(AppCheckTokenInjectSymbol);
}
function VueFireAppCheck(options) {
	return (firebaseApp, app) => {
		if (!isClient) return;
		const token = getGlobalScope(firebaseApp, app).run(() => ref());
		app.provide(AppCheckTokenInjectSymbol, token);
		if (options.debug) self.FIREBASE_APPCHECK_DEBUG_TOKEN = options.debug;
		const appCheck = initializeAppCheck(firebaseApp, options);
		onTokenChanged(appCheck, (newToken) => {
			token.value = newToken.token;
		});
		AppCheckMap.set(firebaseApp, appCheck);
	};
}
var AppCheckMap = /* @__PURE__ */ new WeakMap();
function useAppCheck(name) {
	return AppCheckMap.get(useFirebaseApp(name));
}
//#endregion
//#region node_modules/.pnpm/vuefire@3.2.3_consola@3.4.2_firebase@12.17.0_vue@3.5.40_typescript@6.0.3_/node_modules/vuefire/dist/index.mjs
var _initialStatesMap = /* @__PURE__ */ new WeakMap();
function useSSRInitialState(initialState, firebaseApp) {
	if (!_initialStatesMap.has(firebaseApp)) _initialStatesMap.set(firebaseApp, initialState || {
		f: {},
		r: {},
		s: {},
		u: {}
	});
	return _initialStatesMap.get(firebaseApp);
}
function getInitialValue(dataSource, ssrKey, fallbackValue, firebaseApp) {
	if (!dataSource) return fallbackValue;
	const [sourceType, path] = getDataSourceInfo(dataSource);
	if (!sourceType) return fallbackValue;
	const initialState = useSSRInitialState(void 0, firebaseApp)[sourceType] || {};
	const key = ssrKey || path;
	return key && key in initialState ? initialState[key] : fallbackValue;
}
function deferInitialValueSetup(dataSource, ssrKey, promise, firebaseApp) {
	if (!dataSource) return;
	const [sourceType, path] = getDataSourceInfo(dataSource);
	if (!sourceType) return;
	const initialState = useSSRInitialState(void 0, firebaseApp)[sourceType];
	const key = ssrKey || path;
	if (key) {
		promise.then((value) => {
			initialState[key] = value;
		}).catch(noop);
		return key;
	}
}
function getDataSourceInfo(dataSource) {
	return isFirestoreDataReference(dataSource) || isFirestoreQuery(dataSource) ? ["f", dataSource.path] : isDatabaseReference(dataSource) ? ["r", dataSource.toString()] : isStorageReference(dataSource) ? ["s", dataSource.toString()] : [];
}
var appPendingPromises = /* @__PURE__ */ new WeakMap();
function addPendingPromise(promise, dataSource, ssrKey) {
	const app = useFirebaseApp();
	if (!appPendingPromises.has(app)) appPendingPromises.set(app, /* @__PURE__ */ new Map());
	const pendingPromises = appPendingPromises.get(app);
	const key = deferInitialValueSetup(dataSource, ssrKey, promise, app);
	if (key) pendingPromises.set(key, promise);
	else console.warn("[VueFire SSR]: Could not get the path of the data source");
	return key ? () => pendingPromises.delete(key) : noop;
}
function usePendingPromises(app) {
	app = app || useFirebaseApp();
	const pendingPromises = appPendingPromises.get(app);
	const p = pendingPromises ? Promise.all(Array.from(pendingPromises).map(([key, promise]) => promise.then((data) => [key, data]))) : Promise.resolve([]);
	appPendingPromises.delete(app);
	return p;
}
function createRecordFromDatabaseSnapshot(snapshot) {
	if (!snapshot.exists()) return null;
	const value = snapshot.val();
	return isObject(value) ? Object.defineProperty(value, "id", { value: snapshot.key }) : {
		$value: value,
		id: snapshot.key
	};
}
function indexForKey(array, key) {
	for (let i = 0; i < array.length; i++) if (array[i].id === key) return i;
	return -1;
}
var DEFAULT_OPTIONS$1 = {
	reset: false,
	serialize: createRecordFromDatabaseSnapshot,
	wait: true
};
function bindAsObject(target, document, resolve, reject, extraOptions) {
	const options = Object.assign({}, DEFAULT_OPTIONS$1, extraOptions);
	let unsubscribe = noop;
	function onValueCallback(snapshot) {
		const value = options.serialize(snapshot);
		target.value = value;
		resolve(value);
	}
	if (options.once) get(document).then(onValueCallback).catch(reject);
	else unsubscribe = onValue(document, onValueCallback, reject);
	return (reset) => {
		unsubscribe();
		if (reset) target.value = typeof reset === "function" ? reset() : null;
	};
}
function bindAsArray(target, collection, resolve, reject, extraOptions) {
	const options = Object.assign({}, DEFAULT_OPTIONS$1, extraOptions);
	let arrayRef = options.wait ? [] : target;
	if (!options.wait) target.value = [];
	let removeChildAddedListener = noop;
	let removeChildChangedListener = noop;
	let removeChildRemovedListener = noop;
	let removeChildMovedListener = noop;
	let removeValueListener = noop;
	if (options.once) get(collection).then((data) => {
		const array = [];
		data.forEach((snapshot) => {
			array.push(options.serialize(snapshot));
		});
		resolve(target.value = array);
	}).catch(reject);
	else {
		removeChildAddedListener = onChildAdded(collection, (snapshot, prevKey) => {
			const array = toValue(arrayRef);
			const index = prevKey ? indexForKey(array, prevKey) + 1 : 0;
			array.splice(index, 0, options.serialize(snapshot));
		}, reject);
		removeChildRemovedListener = onChildRemoved(collection, (snapshot) => {
			const array = toValue(arrayRef);
			array.splice(indexForKey(array, snapshot.key), 1);
		}, reject);
		removeChildChangedListener = onChildChanged(collection, (snapshot) => {
			const array = toValue(arrayRef);
			array.splice(indexForKey(array, snapshot.key), 1, options.serialize(snapshot));
		}, reject);
		removeChildMovedListener = onChildMoved(collection, (snapshot, prevKey) => {
			const array = toValue(arrayRef);
			const index = indexForKey(array, snapshot.key);
			const oldRecord = array.splice(index, 1)[0];
			const newIndex = prevKey ? indexForKey(array, prevKey) + 1 : 0;
			array.splice(newIndex, 0, oldRecord);
		}, reject);
		removeValueListener = onValue(collection, () => {
			const array = toValue(arrayRef);
			if (options.wait) {
				target.value = array;
				arrayRef = target;
			}
			resolve(array);
			removeValueListener();
		}, reject);
	}
	return (reset) => {
		removeValueListener();
		removeChildAddedListener();
		removeChildRemovedListener();
		removeChildChangedListener();
		removeChildMovedListener();
		if (reset) target.value = typeof reset === "function" ? reset() : [];
	};
}
function _useDatabaseRef(reference, localOptions = {}, isList = false) {
	let unbind = noop;
	const options = Object.assign({}, DEFAULT_OPTIONS$1, localOptions);
	const initialSourceValue = toValue(reference);
	const data = options.target || ref();
	if (options.target && checkWrittenTarget(data, "useDatabaseObject()/useDatabaseList()")) return data;
	if (useIsSSR()) options.once = true;
	const initialValue = getInitialValue(initialSourceValue, options.ssrKey, data.value, useFirebaseApp());
	data.value = initialValue;
	let shouldStartAsPending = !(isList ? (initialValue || []).length > 0 : initialValue !== void 0);
	const error = ref();
	const pending = ref(false);
	const promise = shallowRef();
	const hasCurrentScope = getCurrentScope();
	let removePendingPromise = noop;
	function bindDatabaseRef() {
		const referenceValue = toValue(reference);
		const newPromise = new Promise((resolve, reject) => {
			unbind(options.reset);
			if (!referenceValue) {
				unbind = noop;
				return resolve(null);
			}
			pending.value = shouldStartAsPending;
			shouldStartAsPending = true;
			if (Array.isArray(data.value)) unbind = bindAsArray(data, referenceValue, resolve, reject, options);
			else unbind = bindAsObject(data, referenceValue, resolve, reject, options);
		}).catch((reason) => {
			if (promise.value === newPromise) error.value = reason;
			throw reason;
		}).finally(() => {
			if (promise.value === newPromise) pending.value = false;
		});
		promise.value = newPromise;
	}
	let stopWatcher = noop;
	if (isRef(reference) || typeof reference === "function") stopWatcher = watch(reference, bindDatabaseRef);
	bindDatabaseRef();
	if (initialSourceValue) removePendingPromise = addPendingPromise(promise.value, initialSourceValue, options.ssrKey);
	if (hasCurrentScope) {
		onScopeDispose(stop);
		if (getCurrentInstance()) onServerPrefetch(() => promise.value);
	}
	function stop(reset = options.reset) {
		stopWatcher();
		removePendingPromise();
		unbind(reset);
	}
	return Object.defineProperties(data, {
		data: { get: () => data },
		error: { get: () => error },
		pending: { get: () => pending },
		promise: { get: () => promise },
		stop: { get: () => stop }
	});
}
function useDatabaseList(reference, options) {
	return _useDatabaseRef(reference, {
		target: ref([]),
		...options
	}, true);
}
var useList = useDatabaseList;
function useDatabaseObject(reference, options) {
	return _useDatabaseRef(reference, {
		target: ref(),
		...options
	});
}
var useObject = useDatabaseObject;
function useDatabase(name) {
	return getDatabase(useFirebaseApp(name));
}
var firestoreDefaultConverter = {
	toFirestore(data) {
		return data;
	},
	fromFirestore(snapshot, options) {
		return snapshot.exists() ? Object.defineProperties(snapshot.data(options), { id: { value: snapshot.id } }) : null;
	}
};
function extractRefs(doc, oldDoc, subs, options) {
	if (!isPOJO(doc)) return [doc, {}];
	const dataAndRefs = [{}, {}];
	const subsByPath = Object.keys(subs).reduce((resultSubs, subKey) => {
		const sub = subs[subKey];
		resultSubs[sub.path] = sub.data();
		return resultSubs;
	}, {});
	function recursiveExtract(doc2, oldDoc2, path, result) {
		oldDoc2 = oldDoc2 || {};
		const [data, refs] = result;
		Object.getOwnPropertyNames(doc2).forEach((propertyName) => {
			const descriptor = Object.getOwnPropertyDescriptor(doc2, propertyName);
			if (descriptor && !descriptor.enumerable) Object.defineProperty(data, propertyName, descriptor);
		});
		for (const key in doc2) {
			const ref = doc2[key];
			if (ref == null || ref instanceof Date || ref instanceof Timestamp || ref instanceof GeoPoint) data[key] = ref;
			else if (isDocumentRef(ref)) {
				const refSubKey = path + key;
				data[key] = refSubKey in subs ? oldDoc2[key] : ref.path;
				refs[refSubKey] = ref.converter ? ref : ref.withConverter(options.converter);
			} else if (Array.isArray(ref)) {
				data[key] = Array(ref.length);
				for (let i = 0; i < ref.length; i++) {
					const newRef = ref[i];
					if (newRef && newRef.path in subsByPath) data[key][i] = subsByPath[newRef.path];
				}
				recursiveExtract(ref, oldDoc2[key] || data[key], path + key + ".", [data[key], refs]);
			} else if (isObject(ref)) {
				data[key] = {};
				recursiveExtract(ref, oldDoc2[key], path + key + ".", [data[key], refs]);
			} else data[key] = ref;
		}
	}
	recursiveExtract(doc, oldDoc, "", dataAndRefs);
	return dataAndRefs;
}
var devalueCustomStringifiers = {
	TimeStamp: (data) => data instanceof Timestamp && data.toJSON(),
	GeoPoint: (data) => data instanceof GeoPoint && data.toJSON()
};
var devalueCustomParsers = {
	TimeStamp: (data) => new Timestamp(data.seconds, data.nanoseconds),
	GeoPoint: (data) => new GeoPoint(data.latitude, data.longitude)
};
var DEFAULT_OPTIONS = {
	reset: false,
	wait: true,
	maxRefDepth: 2,
	converter: firestoreDefaultConverter,
	snapshotOptions: { serverTimestamps: "estimate" }
};
function unsubscribeAll(subs) {
	for (const sub in subs) subs[sub].unsub();
}
function updateDataFromDocumentSnapshot(options, target, path, snapshot, subs, ops, depth, resolve, reject) {
	const [data, refs] = extractRefs(snapshot.data(options.snapshotOptions), walkGet(target, path), subs, options);
	ops.set(target, path, data);
	subscribeToRefs(options, target, path, subs, refs, ops, depth, resolve, reject);
}
function subscribeToDocument({ ref: ref2, target, path, depth, resolve, reject, ops }, options) {
	const subs = /* @__PURE__ */ Object.create(null);
	let unbind = noop;
	if (options.once) getDoc(ref2).then((snapshot) => {
		if (snapshot.exists()) updateDataFromDocumentSnapshot(options, target, path, snapshot, subs, ops, depth, resolve, reject);
		else {
			ops.set(target, path, null);
			resolve();
		}
	}).catch(reject);
	else unbind = onSnapshot(ref2, (snapshot) => {
		if (snapshot.exists()) updateDataFromDocumentSnapshot(options, target, path, snapshot, subs, ops, depth, resolve, reject);
		else {
			ops.set(target, path, null);
			resolve();
		}
	}, reject);
	return () => {
		unbind();
		unsubscribeAll(subs);
	};
}
function subscribeToRefs(options, target, path, subs, refs, ops, depth, resolve, reject) {
	const refKeys = Object.keys(refs);
	Object.keys(subs).filter((refKey) => refKeys.indexOf(refKey) < 0).forEach((refKey) => {
		subs[refKey].unsub();
		delete subs[refKey];
	});
	if (!refKeys.length || ++depth > options.maxRefDepth) return resolve(path);
	let resolvedCount = 0;
	const totalToResolve = refKeys.length;
	const validResolves = /* @__PURE__ */ Object.create(null);
	function deepResolve(key) {
		if (key in validResolves) {
			if (++resolvedCount >= totalToResolve) resolve(path);
		}
	}
	refKeys.forEach((refKey) => {
		const sub = subs[refKey];
		const ref2 = refs[refKey];
		const docPath = `${path}.${refKey}`;
		validResolves[docPath] = true;
		if (sub) if (sub.path !== ref2.path) sub.unsub();
		else return;
		subs[refKey] = {
			data: () => walkGet(target, docPath),
			unsub: subscribeToDocument({
				ref: ref2,
				target,
				path: docPath,
				depth,
				ops,
				resolve: deepResolve.bind(null, docPath),
				reject
			}, options),
			path: ref2.path
		};
	});
}
function bindCollection(target, collection, ops, resolve, reject, extraOptions) {
	const options = Object.assign({}, DEFAULT_OPTIONS, extraOptions);
	const { snapshotListenOptions, snapshotOptions, wait, once } = options;
	const key = "value";
	let arrayRef = ref(wait ? [] : target.value);
	if (!wait) ops.set(target, key, []);
	const originalResolve = resolve;
	let isResolved;
	let stopOnSnapshot = noop;
	const arraySubs = [];
	const change = {
		added: ({ newIndex, doc }) => {
			arraySubs.splice(newIndex, 0, /* @__PURE__ */ Object.create(null));
			const subs = arraySubs[newIndex];
			const [data, refs] = extractRefs(doc.data(snapshotOptions), void 0, subs, options);
			ops.add(toValue(arrayRef), newIndex, data);
			subscribeToRefs(options, arrayRef, `${key}.${newIndex}`, subs, refs, ops, 0, resolve.bind(null, doc), reject);
		},
		modified: ({ oldIndex, newIndex, doc }) => {
			const array = toValue(arrayRef);
			const subs = arraySubs[oldIndex];
			const oldData = array[oldIndex];
			const [data, refs] = extractRefs(doc.data(snapshotOptions), oldData, subs, options);
			arraySubs.splice(newIndex, 0, subs);
			ops.remove(array, oldIndex);
			ops.add(array, newIndex, data);
			subscribeToRefs(options, arrayRef, `${key}.${newIndex}`, subs, refs, ops, 0, resolve, reject);
		},
		removed: ({ oldIndex }) => {
			const array = toValue(arrayRef);
			ops.remove(array, oldIndex);
			unsubscribeAll(arraySubs.splice(oldIndex, 1)[0]);
		}
	};
	function onSnapshotCallback(snapshot) {
		const docChanges = snapshot.docChanges(snapshotListenOptions);
		if (!isResolved && docChanges.length) {
			isResolved = true;
			let count = 0;
			const expectedItems = docChanges.length;
			const validDocs = /* @__PURE__ */ Object.create(null);
			for (let i = 0; i < expectedItems; i++) validDocs[docChanges[i].doc.id] = true;
			resolve = (data) => {
				if (data && data.id in validDocs) {
					if (++count >= expectedItems) {
						if (wait) {
							ops.set(target, key, toValue(arrayRef));
							arrayRef = target;
						}
						originalResolve(toValue(arrayRef));
						resolve = noop;
					}
				}
			};
		}
		docChanges.forEach((c) => {
			change[c.type](c);
		});
		if (!docChanges.length) {
			if (wait) {
				ops.set(target, key, toValue(arrayRef));
				arrayRef = target;
			}
			resolve(toValue(arrayRef));
		}
	}
	if (once) getDocs(collection).then(onSnapshotCallback).catch(reject);
	else stopOnSnapshot = onSnapshot(collection, onSnapshotCallback, reject);
	return (reset) => {
		stopOnSnapshot();
		if (reset) {
			const value = typeof reset === "function" ? reset() : [];
			ops.set(target, key, value);
		}
		arraySubs.forEach(unsubscribeAll);
	};
}
function bindDocument(target, document, ops, resolve, reject, extraOptions) {
	const options = Object.assign({}, DEFAULT_OPTIONS, extraOptions);
	const key = "value";
	const subs = /* @__PURE__ */ Object.create(null);
	resolve = callOnceWithArg(resolve, () => walkGet(target, key));
	let stopOnSnapshot = noop;
	function onSnapshotCallback(snapshot) {
		if (snapshot.exists()) updateDataFromDocumentSnapshot(options, target, key, snapshot, subs, ops, 0, resolve, reject);
		else {
			ops.set(target, key, null);
			resolve(null);
		}
	}
	if (options.once) getDoc(document).then(onSnapshotCallback).catch(reject);
	else stopOnSnapshot = onSnapshot(document, onSnapshotCallback, reject);
	return (reset) => {
		stopOnSnapshot();
		if (reset) {
			const value = typeof reset === "function" ? reset() : null;
			ops.set(target, key, value);
		}
		unsubscribeAll(subs);
	};
}
var NO_INITIAL_VALUE = Symbol();
function _useFirestoreRef(docOrCollectionRef, localOptions) {
	let unbind = noop;
	const options = Object.assign({}, DEFAULT_OPTIONS, localOptions);
	const initialSourceValue = toValue(docOrCollectionRef);
	const data = options.target || ref();
	if (options.target && checkWrittenTarget(data, "useDocument()/useCollection()")) return data;
	if (useIsSSR()) options.once = true;
	const initialValue = getInitialValue(initialSourceValue, options.ssrKey, NO_INITIAL_VALUE, useFirebaseApp());
	const hasInitialValue = initialValue !== NO_INITIAL_VALUE;
	if (hasInitialValue) data.value = initialValue;
	let shouldStartAsPending = !hasInitialValue;
	const pending = ref(false);
	const error = ref();
	const promise = shallowRef();
	const hasCurrentScope = getCurrentScope();
	let removePendingPromise = noop;
	function bindFirestoreRef() {
		let docRefValue = toValue(docOrCollectionRef);
		const newPromise = new Promise((resolve, reject) => {
			unbind(options.reset);
			if (!docRefValue) {
				unbind = noop;
				return resolve(null);
			}
			pending.value = shouldStartAsPending;
			shouldStartAsPending = true;
			if (!docRefValue.converter) docRefValue = docRefValue.withConverter(options.converter);
			unbind = (isDocumentRef(docRefValue) ? bindDocument : bindCollection)(data, docRefValue, ops, resolve, reject, options);
		}).catch((reason) => {
			if (promise.value === newPromise) error.value = reason;
			return Promise.reject(reason);
		}).finally(() => {
			if (promise.value === newPromise) pending.value = false;
		});
		promise.value = newPromise;
	}
	let stopWatcher = noop;
	if (isRef(docOrCollectionRef) || typeof docOrCollectionRef === "function") stopWatcher = watch(docOrCollectionRef, bindFirestoreRef);
	bindFirestoreRef();
	if (initialSourceValue) removePendingPromise = addPendingPromise(promise.value, initialSourceValue, options.ssrKey);
	if (getCurrentInstance()) onServerPrefetch(() => promise.value);
	if (hasCurrentScope) onScopeDispose(stop);
	function stop(reset = options.reset) {
		stopWatcher();
		removePendingPromise();
		unbind(reset);
	}
	return Object.defineProperties(data, {
		error: { get: () => error },
		data: { get: () => data },
		pending: { get: () => pending },
		promise: { get: () => promise },
		stop: { get: () => stop }
	});
}
var ops = {
	set: (target, key, value) => walkSet(target, key, value),
	add: (array, index, data) => array.splice(index, 0, data),
	remove: (array, index) => array.splice(index, 1)
};
function useCollection(collectionRef, options) {
	return _useFirestoreRef(collectionRef, {
		target: ref([]),
		...options
	});
}
function useDocument(documentRef, options) {
	return _useFirestoreRef(documentRef, options);
}
function useFirestore(name) {
	return getFirestore(useFirebaseApp(name));
}
var databaseUnbinds = /* @__PURE__ */ new WeakMap();
function internalUnbind$1(key, unbinds, reset) {
	if (unbinds && unbinds[key]) {
		unbinds[key](reset);
		delete unbinds[key];
	}
}
var databasePluginDefaults = {
	bindName: "$databaseBind",
	unbindName: "$databaseUnbind"
};
function databasePlugin(app, pluginOptions, firebaseApp) {
	const globalOptions = Object.assign({}, databasePluginDefaults, pluginOptions);
	const { bindName, unbindName } = globalOptions;
	const GlobalTarget = isVue3 ? app.config.globalProperties : app.prototype;
	GlobalTarget[unbindName] = function databaseUnbind(key, reset) {
		internalUnbind$1(key, databaseUnbinds.get(this), reset);
		delete this.$firebaseRefs[key];
	};
	GlobalTarget[bindName] = function databaseBind(key, source, userOptions) {
		const options = Object.assign({}, globalOptions, userOptions);
		const target = toRef(this.$data, key);
		if (!databaseUnbinds.has(this)) databaseUnbinds.set(this, {});
		const unbinds = databaseUnbinds.get(this);
		if (unbinds[key]) unbinds[key](options.reset);
		if (pluginOptions) {
			if (!pluginOptions.bindName) GlobalTarget["$rtdbBind"] = GlobalTarget[bindName];
			if (!pluginOptions.unbindName) GlobalTarget["$rtdbUnbind"] = GlobalTarget[unbindName];
		}
		const scope = getGlobalScope(firebaseApp || useFirebaseApp(), app).run(() => effectScope());
		const { promise, stop: _unbind } = app.runWithContext(() => scope.run(() => _useDatabaseRef(source, {
			target,
			...options
		})));
		const unbind = (reset) => {
			_unbind(reset);
			scope.stop();
		};
		unbinds[key] = unbind;
		this.$firebaseRefs[key] = source.ref;
		return promise.value;
	};
	app.mixin({
		beforeCreate() {
			this.$firebaseRefs = /* @__PURE__ */ Object.create(null);
		},
		created() {
			let bindings = this.$options.firebase;
			if (typeof bindings === "function") bindings = bindings.call(this);
			if (!bindings) return;
			for (const key in bindings) this[bindName](key, bindings[key], globalOptions);
		},
		beforeUnmount() {
			const unbinds = databaseUnbinds.get(this);
			if (unbinds) for (const key in unbinds) unbinds[key]();
			this.$firebaseRefs = null;
		}
	});
}
function VueFireDatabaseOptionsAPI(pluginOptions) {
	return (firebaseApp, app) => {
		return databasePlugin(app, pluginOptions, firebaseApp);
	};
}
var firestoreUnbinds = /* @__PURE__ */ new WeakMap();
function internalUnbind(key, unbinds, reset) {
	if (unbinds && unbinds[key]) {
		unbinds[key](reset);
		delete unbinds[key];
	}
}
var firestorePluginDefaults = {
	bindName: "$firestoreBind",
	unbindName: "$firestoreUnbind"
};
var firestorePlugin = function firestorePlugin2(app, pluginOptions, firebaseApp) {
	const globalOptions = Object.assign({}, firestorePluginDefaults, pluginOptions);
	const { bindName, unbindName } = globalOptions;
	const GlobalTarget = isVue3 ? app.config.globalProperties : app.prototype;
	GlobalTarget[unbindName] = function firestoreUnbind(key, reset) {
		internalUnbind(key, firestoreUnbinds.get(this), reset);
		delete this.$firestoreRefs[key];
	};
	GlobalTarget[bindName] = function firestoreBind(key, docOrCollectionRef, userOptions) {
		const options = Object.assign({}, globalOptions, userOptions);
		const target = toRef(this.$data, key);
		if (!firestoreUnbinds.has(this)) firestoreUnbinds.set(this, {});
		const unbinds = firestoreUnbinds.get(this);
		if (unbinds[key]) unbinds[key](options.reset);
		const scope = getGlobalScope(firebaseApp || useFirebaseApp(), app).run(() => effectScope());
		const { promise, stop: _unbind } = app.runWithContext(() => scope.run(() => _useFirestoreRef(docOrCollectionRef, {
			target,
			...options
		})));
		const unbind = (reset) => {
			_unbind(reset);
			scope.stop();
		};
		unbinds[key] = unbind;
		this.$firestoreRefs[key] = docOrCollectionRef;
		return promise.value;
	};
	app.mixin({
		beforeCreate() {
			this.$firestoreRefs = /* @__PURE__ */ Object.create(null);
		},
		created() {
			const { firestore } = this.$options;
			const refs = typeof firestore === "function" ? firestore.call(this) : firestore;
			if (!refs) return;
			for (const key in refs) this[bindName](key, refs[key], globalOptions);
		},
		beforeUnmount() {
			const unbinds = firestoreUnbinds.get(this);
			if (unbinds) for (const subKey in unbinds) unbinds[subKey]();
			this.$firestoreRefs = null;
		}
	});
};
function VueFireFirestoreOptionsAPI(pluginOptions) {
	return (firebaseApp, app) => {
		return firestorePlugin(app, pluginOptions, firebaseApp);
	};
}
function VueFireAuth(initialUser) {
	return VueFireAuthWithDependencies({
		initialUser,
		dependencies: {
			popupRedirectResolver: browserPopupRedirectResolver,
			persistence: [
				indexedDBLocalPersistence,
				browserLocalPersistence,
				browserSessionPersistence
			]
		}
	});
}
var _VueFireAuthKey = Symbol("VueFireAuth");
function VueFireAuthOptionsFromAuth({ auth, initialUser }) {
	return (firebaseApp, app) => {
		const [user, _auth] = _VueFireAuthInit(firebaseApp, app, initialUser, void 0, auth);
		setupOnAuthStateChanged(user, _auth);
	};
}
function VueFireAuthWithDependencies({ dependencies, initialUser }) {
	return (firebaseApp, app) => {
		const [user, auth] = _VueFireAuthInit(firebaseApp, app, initialUser, dependencies);
		setupOnAuthStateChanged(user, auth);
	};
}
function _VueFireAuthInit(firebaseApp, app, initialUser, dependencies, auth = initializeAuth(firebaseApp, dependencies)) {
	const user = getGlobalScope(firebaseApp, app).run(() => ref(initialUser));
	authUserMap.set(firebaseApp, user);
	app.provide(_VueFireAuthKey, auth);
	return [user, auth];
}
function useFirebaseAuth(name) {
	if (name != null) console.warn(`[VueFire] useFirebaseAuth() no longer accepts a name parameter to enable tree shaking. If you have multiple applications, you must use "getAuth(firebaseApp)" or "getAuth(useFirebaseApp(name))" instead.`);
	return isClient ? inject(_VueFireAuthKey) : null;
}
function useFirebaseStorage(name) {
	return getStorage(useFirebaseApp(name));
}
function useStorageFileUrl(storageRef) {
	const initialSourceValue = toValue(storageRef);
	const url = ref();
	url.value = getInitialValue(initialSourceValue, void 0, url.value, useFirebaseApp());
	const promise = shallowRef(Promise.resolve(null));
	let removePendingPromise = noop;
	function refresh() {
		const storageSource = toValue(storageRef);
		if (storageSource) promise.value = getDownloadURL(storageSource).then((downloadUrl) => url.value = downloadUrl).catch(() => null);
		else promise.value = Promise.resolve(url.value = null);
		return promise.value;
	}
	refresh();
	if (isRef(storageRef) || typeof storageRef === "function") watch(storageRef, refresh);
	if (initialSourceValue) removePendingPromise = addPendingPromise(promise.value, initialSourceValue);
	if (getCurrentScope()) onScopeDispose(removePendingPromise);
	if (getCurrentInstance()) onServerPrefetch(() => promise.value);
	return {
		url,
		refresh,
		promise
	};
}
function useStorageFileMetadata(storageRef) {
	const initialSourceValue = toValue(storageRef);
	const metadata = shallowRef();
	if (initialSourceValue) metadata.value = getInitialValue(initialSourceValue, "m " + initialSourceValue.toString(), metadata.value, useFirebaseApp());
	const promise = shallowRef(Promise.resolve(null));
	let removePendingPromise = noop;
	function refresh() {
		const storageSource = toValue(storageRef);
		if (storageSource) promise.value = getMetadata(storageSource).then((data) => metadata.value = data).catch(() => null);
		else promise.value = Promise.resolve(metadata.value = null);
		return promise.value;
	}
	function update(newMetadata) {
		const storageSource = toValue(storageRef);
		if (storageSource) promise.value = updateMetadata(storageSource, newMetadata).then((newData) => {
			return metadata.value = newData;
		});
		else console.warn("[VueFire]: \"update()\" called with no storage source.");
		return promise.value;
	}
	refresh();
	if (isRef(storageRef)) watch(storageRef, refresh);
	if (initialSourceValue) removePendingPromise = addPendingPromise(promise.value, initialSourceValue);
	if (getCurrentScope()) onScopeDispose(removePendingPromise);
	if (getCurrentInstance()) onServerPrefetch(() => promise.value);
	return {
		metadata,
		update,
		refresh,
		promise
	};
}
function useStorageFile(storageRef) {
	const { url, refresh: refreshUrl } = useStorageFileUrl(storageRef);
	const { metadata, update: updateMetadata2, refresh: refreshMetadata } = useStorageFileMetadata(storageRef);
	const uploadTask = shallowRef();
	const snapshot = shallowRef();
	const uploadError = shallowRef();
	const uploadProgress = computed(() => {
		const snap = toValue(snapshot);
		return snap ? snap.bytesTransferred / snap.totalBytes : null;
	});
	let unsub = noop;
	function upload(newData, newMetadata) {
		const storageSource = toValue(storageRef);
		const currentTask = toValue(uploadTask);
		if (currentTask) currentTask.cancel();
		uploadError.value = null;
		snapshot.value = null;
		uploadTask.value = null;
		url.value = null;
		metadata.value = null;
		unsub();
		if (storageSource) {
			const newTask = uploadBytesResumable(storageSource, newData, newMetadata);
			uploadTask.value = newTask;
			snapshot.value = newTask.snapshot;
			unsub = newTask.on("state_changed", (newSnapshot) => {
				snapshot.value = newSnapshot;
			});
			return newTask.then((finalSnapshot) => {
				metadata.value = finalSnapshot.metadata;
				refreshUrl();
			}).catch((err) => {
				uploadError.value = err;
				return Promise.reject(err);
			}).finally(() => {
				unsub();
				uploadTask.value = null;
			});
		}
	}
	function refresh() {
		return Promise.all([refreshUrl(), refreshMetadata()]);
	}
	if (isRef(storageRef) || typeof storageRef === "function") watch(storageRef, (storageSource) => {
		if (!storageSource) {
			if (uploadTask.value) {
				unsub();
				uploadTask.value.cancel();
			}
			uploadTask.value = null;
			snapshot.value = null;
		}
		refresh();
	});
	if (getCurrentScope()) onScopeDispose(unsub);
	return {
		url,
		metadata,
		snapshot,
		uploadTask,
		uploadError,
		uploadProgress,
		upload,
		updateMetadata: updateMetadata2,
		refresh
	};
}
var useStorage = useFirebaseStorage;
var useStorageUrl = useStorageFileUrl;
var useStorageMetadata = useStorageFileMetadata;
var useStorageObject = useStorageFile;
function VueFire(app, { firebaseApp, modules = [] }) {
	app.provide(_FirebaseAppInjectionKey, firebaseApp);
	for (const firebaseModule of modules) firebaseModule(firebaseApp, app);
}
//#endregion
export { VueFire, VueFireAppCheck, VueFireAuth, VueFireAuthOptionsFromAuth, VueFireAuthWithDependencies, VueFireDatabaseOptionsAPI, VueFireFirestoreOptionsAPI, _VueFireAuthInit, _VueFireAuthKey, createRecordFromDatabaseSnapshot as databaseDefaultSerializer, databasePlugin, databasePlugin as rtdbPlugin, devalueCustomParsers, devalueCustomStringifiers, firestoreDefaultConverter, firestorePlugin, getCurrentUser, DEFAULT_OPTIONS$1 as globalDatabaseOptions, DEFAULT_OPTIONS as globalFirestoreOptions, updateCurrentUserProfile, useAppCheck, useAppCheckToken, useCollection, useCurrentUser, useDatabase, useDatabaseList, useDatabaseObject, useDocument, useFirebaseApp, useFirebaseAuth, useFirebaseStorage, useFirestore, useIsCurrentUserLoaded, useList, useObject, usePendingPromises, useSSRInitialState, useStorage, useStorageFile, useStorageFileMetadata, useStorageFileUrl, useStorageMetadata, useStorageObject, useStorageUrl };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidnVlZmlyZS5qcyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8ucG5wbS92dWVmaXJlQDMuMi4zX2NvbnNvbGFAMy40LjJfZmlyZWJhc2VAMTIuMTcuMF92dWVAMy41LjQwX3R5cGVzY3JpcHRANi4wLjNfL25vZGVfbW9kdWxlcy92dWVmaXJlL2Rpc3Qvc2hhcmVkL3Z1ZWZpcmUuMGZlYjkwY2MubWpzIiwiLi4vLi4vLi4vLi4vLnBucG0vdnVlZmlyZUAzLjIuM19jb25zb2xhQDMuNC4yX2ZpcmViYXNlQDEyLjE3LjBfdnVlQDMuNS40MF90eXBlc2NyaXB0QDYuMC4zXy9ub2RlX21vZHVsZXMvdnVlZmlyZS9kaXN0L2luZGV4Lm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1cGRhdGVQcm9maWxlLCBvbklkVG9rZW5DaGFuZ2VkIH0gZnJvbSAnZmlyZWJhc2UvYXV0aCc7XG5pbXBvcnQgeyBnZXRDdXJyZW50SW5zdGFuY2UsIGluamVjdCwgaXNWdWUyLCBlZmZlY3RTY29wZSwgY29tcHV0ZWQsIHJlZiB9IGZyb20gJ3Z1ZS1kZW1pJztcbmltcG9ydCB7IGluaXRpYWxpemVBcHBDaGVjaywgb25Ub2tlbkNoYW5nZWQgfSBmcm9tICdmaXJlYmFzZS9hcHAtY2hlY2snO1xuaW1wb3J0IHsgZ2V0QXBwIH0gZnJvbSAnZmlyZWJhc2UvYXBwJztcblxuY29uc3QgX0ZpcmViYXNlQXBwSW5qZWN0aW9uS2V5ID0gU3ltYm9sKFwiZmlyZWJhc2VBcHBcIik7XG5mdW5jdGlvbiB1c2VGaXJlYmFzZUFwcChuYW1lKSB7XG4gIHJldHVybiBnZXRDdXJyZW50SW5zdGFuY2UoKSAmJiBpbmplY3QoXG4gICAgX0ZpcmViYXNlQXBwSW5qZWN0aW9uS2V5LFxuICAgIC8vIGF2b2lkIHRoZSBpbmplY3Qgbm90IGZvdW5kIHdhcm5pbmdcbiAgICBudWxsXG4gICkgfHwgZ2V0QXBwKG5hbWUpO1xufVxuXG5jb25zdCBub29wID0gKCkgPT4ge1xufTtcbmNvbnN0IGlzQ2xpZW50ID0gdHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIjtcbmZ1bmN0aW9uIHdhbGtHZXQob2JqLCBwYXRoKSB7XG4gIHJldHVybiBwYXRoLnNwbGl0KFwiLlwiKS5yZWR1Y2UoKHRhcmdldCwga2V5KSA9PiB0YXJnZXQgJiYgdGFyZ2V0W2tleV0sIG9iaik7XG59XG5mdW5jdGlvbiB3YWxrU2V0KG9iaiwgcGF0aCwgdmFsdWUpIHtcbiAgY29uc3Qga2V5cyA9IChcIlwiICsgcGF0aCkuc3BsaXQoXCIuXCIpO1xuICBjb25zdCBrZXkgPSBrZXlzLnBvcCgpO1xuICBjb25zdCB0YXJnZXQgPSBrZXlzLnJlZHVjZShcbiAgICAodGFyZ2V0Miwga2V5MikgPT4gKFxuICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvcjogRklYTUU6IG1heWJlXG4gICAgICB0YXJnZXQyICYmIHRhcmdldDJba2V5Ml1cbiAgICApLFxuICAgIG9ialxuICApO1xuICBpZiAodGFyZ2V0ID09IG51bGwpXG4gICAgcmV0dXJuO1xuICByZXR1cm4gQXJyYXkuaXNBcnJheSh0YXJnZXQpID8gdGFyZ2V0LnNwbGljZShOdW1iZXIoa2V5KSwgMSwgdmFsdWUpIDogKFxuICAgIC8vIEB0cy1leHBlY3QtZXJyb3I6IEZJWE1FOiBtYXliZVxuICAgIHRhcmdldFtrZXldID0gLy9cbiAgICB2YWx1ZVxuICApO1xufVxuZnVuY3Rpb24gaXNPYmplY3Qobykge1xuICByZXR1cm4gISFvICYmIHR5cGVvZiBvID09PSBcIm9iamVjdFwiO1xufVxuY29uc3QgT2JqZWN0UHJvdG90eXBlID0gT2JqZWN0LnByb3RvdHlwZTtcbmZ1bmN0aW9uIGlzUE9KTyhvYmopIHtcbiAgcmV0dXJuIGlzT2JqZWN0KG9iaikgJiYgT2JqZWN0LmdldFByb3RvdHlwZU9mKG9iaikgPT09IE9iamVjdFByb3RvdHlwZTtcbn1cbmZ1bmN0aW9uIGlzRG9jdW1lbnRSZWYobykge1xuICByZXR1cm4gaXNPYmplY3QobykgJiYgby50eXBlID09PSBcImRvY3VtZW50XCI7XG59XG5mdW5jdGlvbiBpc0NvbGxlY3Rpb25SZWYobykge1xuICByZXR1cm4gaXNPYmplY3QobykgJiYgby50eXBlID09PSBcImNvbGxlY3Rpb25cIjtcbn1cbmZ1bmN0aW9uIGlzRmlyZXN0b3JlRGF0YVJlZmVyZW5jZShzb3VyY2UpIHtcbiAgcmV0dXJuIGlzRG9jdW1lbnRSZWYoc291cmNlKSB8fCBpc0NvbGxlY3Rpb25SZWYoc291cmNlKTtcbn1cbmZ1bmN0aW9uIGlzRmlyZXN0b3JlUXVlcnkoc291cmNlKSB7XG4gIHJldHVybiBpc09iamVjdChzb3VyY2UpICYmIHNvdXJjZS50eXBlID09PSBcInF1ZXJ5XCI7XG59XG5mdW5jdGlvbiBpc0RhdGFiYXNlUmVmZXJlbmNlKHNvdXJjZSkge1xuICByZXR1cm4gaXNPYmplY3Qoc291cmNlKSAmJiBcInJlZlwiIGluIHNvdXJjZTtcbn1cbmZ1bmN0aW9uIGlzU3RvcmFnZVJlZmVyZW5jZShzb3VyY2UpIHtcbiAgcmV0dXJuIGlzT2JqZWN0KHNvdXJjZSkgJiYgdHlwZW9mIHNvdXJjZS5idWNrZXQgPT09IFwic3RyaW5nXCI7XG59XG5mdW5jdGlvbiBjYWxsT25jZVdpdGhBcmcoZm4sIGFyZ0ZuKSB7XG4gIGxldCBjYWxsZWQ7XG4gIHJldHVybiAoKSA9PiB7XG4gICAgaWYgKCFjYWxsZWQpIHtcbiAgICAgIGNhbGxlZCA9IHRydWU7XG4gICAgICByZXR1cm4gZm4oYXJnRm4oKSk7XG4gICAgfVxuICB9O1xufVxuY29uc3Qgc3NyQ29udGV4dEtleSA9IFN5bWJvbC5mb3IoXCJ2LXNjeFwiKTtcbmZ1bmN0aW9uIHVzZUlzU1NSKCkge1xuICBjb25zdCBpbnN0YW5jZSA9IGdldEN1cnJlbnRJbnN0YW5jZSgpO1xuICByZXR1cm4gISEoaXNWdWUyID8gaW5zdGFuY2UgJiYgLy8gQHRzLWV4cGVjdC1lcnJvcjogVnVlIDIgb25seSBBUElcbiAgaW5zdGFuY2UucHJveHkuJGlzU2VydmVyIDogaW5qZWN0KHNzckNvbnRleHRLZXksIDApKTtcbn1cbmZ1bmN0aW9uIGNoZWNrV3JpdHRlblRhcmdldChkYXRhLCBmbk5hbWUpIHtcbiAgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoZGF0YSwgXCJkYXRhXCIpPy5nZXQ/LigpID09PSBkYXRhKSB7XG4gICAgY29uc29sZS53YXJuKGBbVnVlRmlyZV0gdGhlIHBhc3NlZCBcIm9wdGlvbnMudGFyZ2V0XCIgaXMgYWxyZWFkeSB0aGUgcmV0dXJuZWQgdmFsdWUgb2YgXCIke2ZuTmFtZX1cIi4gSWYgeW91IHdhbnQgdG8gc3Vic2NyaWJlIHRvIGEgZGlmZmVyZW50IGRhdGEgc291cmNlLCBwYXNzIGEgcmVhY3RpdmUgdmFyaWFibGUgdG8gXCIke2ZuTmFtZX1cIiBpbnN0ZWFkOlxuaHR0cHM6Ly92dWVmaXJlLnZ1ZWpzLm9yZy9ndWlkZS9yZWFsdGltZS1kYXRhLmh0bWwjZGVjbGFyYXRpdmUtcmVhbHRpbWUtZGF0YVxuVGhpcyB3aWxsIEZBSUwgaW4gcHJvZHVjdGlvbi5gKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5cbmNvbnN0IHNjb3BlTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5mdW5jdGlvbiBnZXRHbG9iYWxTY29wZShmaXJlYmFzZUFwcCwgYXBwKSB7XG4gIGlmICghc2NvcGVNYXAuaGFzKGZpcmViYXNlQXBwKSkge1xuICAgIGNvbnN0IHNjb3BlID0gZWZmZWN0U2NvcGUodHJ1ZSk7XG4gICAgc2NvcGVNYXAuc2V0KGZpcmViYXNlQXBwLCBzY29wZSk7XG4gICAgY29uc3QgeyB1bm1vdW50IH0gPSBhcHA7XG4gICAgYXBwLnVubW91bnQgPSAoKSA9PiB7XG4gICAgICB1bm1vdW50LmNhbGwoYXBwKTtcbiAgICAgIHNjb3BlLnN0b3AoKTtcbiAgICAgIHNjb3BlTWFwLmRlbGV0ZShmaXJlYmFzZUFwcCk7XG4gICAgfTtcbiAgfVxuICByZXR1cm4gc2NvcGVNYXAuZ2V0KGZpcmViYXNlQXBwKTtcbn1cblxuY29uc3QgYXV0aFVzZXJNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbmZ1bmN0aW9uIHVzZUN1cnJlbnRVc2VyKG5hbWUpIHtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhYXV0aFVzZXJNYXAuaGFzKHVzZUZpcmViYXNlQXBwKG5hbWUpKSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgIGBbVnVlRmlyZV0gdXNlQ3VycmVudFVzZXIoKSBjYWxsZWQgYmVmb3JlIHRoZSBWdWVGaXJlQXV0aCBtb2R1bGUgd2FzIGFkZGVkIHRvIHRoZSBWdWVGaXJlIHBsdWdpbi4gVGhpcyB3aWxsIGZhaWwgaW4gcHJvZHVjdGlvbi5gXG4gICAgKTtcbiAgfVxuICByZXR1cm4gYXV0aFVzZXJNYXAuZ2V0KHVzZUZpcmViYXNlQXBwKG5hbWUpKTtcbn1cbmZ1bmN0aW9uIHVzZUlzQ3VycmVudFVzZXJMb2FkZWQobmFtZSkge1xuICBjb25zdCBjdXJyZW50VXNlciA9IHVzZUN1cnJlbnRVc2VyKG5hbWUpO1xuICByZXR1cm4gY29tcHV0ZWQoKCkgPT4gY3VycmVudFVzZXIudmFsdWUgIT09IHZvaWQgMCk7XG59XG5mdW5jdGlvbiB1cGRhdGVDdXJyZW50VXNlclByb2ZpbGUocHJvZmlsZSkge1xuICByZXR1cm4gZ2V0Q3VycmVudFVzZXIoKS50aGVuKCh1c2VyKSA9PiB7XG4gICAgaWYgKHVzZXIpIHtcbiAgICAgIHJldHVybiB1cGRhdGVQcm9maWxlKHVzZXIsIHByb2ZpbGUpLnRoZW4oKCkgPT4gdXNlci5yZWxvYWQoKSk7XG4gICAgfVxuICB9KTtcbn1cbmNvbnN0IGluaXRpYWxVc2VyTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5mdW5jdGlvbiBfc2V0SW5pdGlhbFVzZXIoZmlyZWJhc2VBcHAsIHVzZXIpIHtcbiAgaW5pdGlhbFVzZXJNYXAuc2V0KGZpcmViYXNlQXBwLCB1c2VyKTtcbn1cbmZ1bmN0aW9uIF9nZXRDdXJyZW50VXNlclN0YXRlKG5hbWUpIHtcbiAgY29uc3QgZmlyZWJhc2VBcHAgPSB1c2VGaXJlYmFzZUFwcChuYW1lKTtcbiAgaWYgKCFpbml0aWFsVXNlck1hcC5oYXMoZmlyZWJhc2VBcHApKSB7XG4gICAgbGV0IHJlc29sdmU7XG4gICAgY29uc3QgcHJvbWlzZSA9IG5ldyBQcm9taXNlKChfcmVzb2x2ZSkgPT4ge1xuICAgICAgcmVzb2x2ZSA9IF9yZXNvbHZlO1xuICAgIH0pO1xuICAgIGNvbnN0IHVzZXJTdGF0ZSA9IFtcbiAgICAgIHByb21pc2UsXG4gICAgICAodXNlcikgPT4ge1xuICAgICAgICBpbml0aWFsVXNlck1hcC5zZXQoZmlyZWJhc2VBcHAsIHVzZXIpO1xuICAgICAgICByZXNvbHZlKHVzZXIudmFsdWUpO1xuICAgICAgfVxuICAgIF07XG4gICAgaW5pdGlhbFVzZXJNYXAuc2V0KGZpcmViYXNlQXBwLCB1c2VyU3RhdGUpO1xuICB9XG4gIHJldHVybiBpbml0aWFsVXNlck1hcC5nZXQoZmlyZWJhc2VBcHApO1xufVxuZnVuY3Rpb24gZ2V0Q3VycmVudFVzZXIobmFtZSkge1xuICBjb25zdCB1c2VyT3JQcm9taXNlID0gX2dldEN1cnJlbnRVc2VyU3RhdGUobmFtZSk7XG4gIHJldHVybiBBcnJheS5pc0FycmF5KHVzZXJPclByb21pc2UpID8gdXNlck9yUHJvbWlzZVswXSA6IFByb21pc2UucmVzb2x2ZSh1c2VyT3JQcm9taXNlLnZhbHVlKTtcbn1cbmZ1bmN0aW9uIHNldHVwT25BdXRoU3RhdGVDaGFuZ2VkKHVzZXIsIGF1dGgpIHtcbiAgb25JZFRva2VuQ2hhbmdlZChhdXRoLCAodXNlckRhdGEpID0+IHtcbiAgICBjb25zdCB1c2VyT3JQcm9taXNlID0gX2dldEN1cnJlbnRVc2VyU3RhdGUoKTtcbiAgICB1c2VyLnZhbHVlID0gdXNlckRhdGE7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkodXNlck9yUHJvbWlzZSkpIHtcbiAgICAgIHVzZXJPclByb21pc2VbMV0odXNlcik7XG4gICAgfVxuICB9KTtcbn1cblxuY29uc3QgQXBwQ2hlY2tUb2tlbkluamVjdFN5bWJvbCA9IFN5bWJvbChcImFwcC1jaGVjay10b2tlblwiKTtcbmZ1bmN0aW9uIHVzZUFwcENoZWNrVG9rZW4oKSB7XG4gIHJldHVybiBpbmplY3QoQXBwQ2hlY2tUb2tlbkluamVjdFN5bWJvbCk7XG59XG5mdW5jdGlvbiBWdWVGaXJlQXBwQ2hlY2sob3B0aW9ucykge1xuICByZXR1cm4gKGZpcmViYXNlQXBwLCBhcHApID0+IHtcbiAgICBpZiAoIWlzQ2xpZW50KVxuICAgICAgcmV0dXJuO1xuICAgIGNvbnN0IHRva2VuID0gZ2V0R2xvYmFsU2NvcGUoZmlyZWJhc2VBcHAsIGFwcCkucnVuKCgpID0+IHJlZigpKTtcbiAgICBhcHAucHJvdmlkZShBcHBDaGVja1Rva2VuSW5qZWN0U3ltYm9sLCB0b2tlbik7XG4gICAgaWYgKG9wdGlvbnMuZGVidWcpIHtcbiAgICAgIHNlbGYuRklSRUJBU0VfQVBQQ0hFQ0tfREVCVUdfVE9LRU4gPSBvcHRpb25zLmRlYnVnO1xuICAgIH1cbiAgICBjb25zdCBhcHBDaGVjayA9IGluaXRpYWxpemVBcHBDaGVjayhmaXJlYmFzZUFwcCwgb3B0aW9ucyk7XG4gICAgb25Ub2tlbkNoYW5nZWQoYXBwQ2hlY2ssIChuZXdUb2tlbikgPT4ge1xuICAgICAgdG9rZW4udmFsdWUgPSBuZXdUb2tlbi50b2tlbjtcbiAgICB9KTtcbiAgICBBcHBDaGVja01hcC5zZXQoZmlyZWJhc2VBcHAsIGFwcENoZWNrKTtcbiAgfTtcbn1cbmNvbnN0IEFwcENoZWNrTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5mdW5jdGlvbiB1c2VBcHBDaGVjayhuYW1lKSB7XG4gIHJldHVybiBBcHBDaGVja01hcC5nZXQodXNlRmlyZWJhc2VBcHAobmFtZSkpO1xufVxuXG5leHBvcnQgeyBBcHBDaGVja1Rva2VuSW5qZWN0U3ltYm9sIGFzIEEsIFZ1ZUZpcmVBcHBDaGVjayBhcyBWLCBfRmlyZWJhc2VBcHBJbmplY3Rpb25LZXkgYXMgXywgaXNGaXJlc3RvcmVRdWVyeSBhcyBhLCBpc0RhdGFiYXNlUmVmZXJlbmNlIGFzIGIsIGlzU3RvcmFnZVJlZmVyZW5jZSBhcyBjLCBpc09iamVjdCBhcyBkLCBjaGVja1dyaXR0ZW5UYXJnZXQgYXMgZSwgdXNlSXNTU1IgYXMgZiwgaXNQT0pPIGFzIGcsIGlzRG9jdW1lbnRSZWYgYXMgaCwgaXNGaXJlc3RvcmVEYXRhUmVmZXJlbmNlIGFzIGksIGNhbGxPbmNlV2l0aEFyZyBhcyBqLCB3YWxrU2V0IGFzIGssIGdldEdsb2JhbFNjb3BlIGFzIGwsIGF1dGhVc2VyTWFwIGFzIG0sIG5vb3AgYXMgbiwgaXNDbGllbnQgYXMgbywgdXNlQ3VycmVudFVzZXIgYXMgcCwgdXNlSXNDdXJyZW50VXNlckxvYWRlZCBhcyBxLCBnZXRDdXJyZW50VXNlciBhcyByLCBzZXR1cE9uQXV0aFN0YXRlQ2hhbmdlZCBhcyBzLCB1cGRhdGVDdXJyZW50VXNlclByb2ZpbGUgYXMgdCwgdXNlRmlyZWJhc2VBcHAgYXMgdSwgdXNlQXBwQ2hlY2tUb2tlbiBhcyB2LCB3YWxrR2V0IGFzIHcsIHVzZUFwcENoZWNrIGFzIHgsIEFwcENoZWNrTWFwIGFzIHksIF9zZXRJbml0aWFsVXNlciBhcyB6IH07XG4iLCJpbXBvcnQgeyBpIGFzIGlzRmlyZXN0b3JlRGF0YVJlZmVyZW5jZSwgYSBhcyBpc0ZpcmVzdG9yZVF1ZXJ5LCBiIGFzIGlzRGF0YWJhc2VSZWZlcmVuY2UsIGMgYXMgaXNTdG9yYWdlUmVmZXJlbmNlLCBuIGFzIG5vb3AsIHUgYXMgdXNlRmlyZWJhc2VBcHAsIGQgYXMgaXNPYmplY3QsIGUgYXMgY2hlY2tXcml0dGVuVGFyZ2V0LCBmIGFzIHVzZUlzU1NSLCBnIGFzIGlzUE9KTywgaCBhcyBpc0RvY3VtZW50UmVmLCB3IGFzIHdhbGtHZXQsIGogYXMgY2FsbE9uY2VXaXRoQXJnLCBrIGFzIHdhbGtTZXQsIGwgYXMgZ2V0R2xvYmFsU2NvcGUsIHMgYXMgc2V0dXBPbkF1dGhTdGF0ZUNoYW5nZWQsIG0gYXMgYXV0aFVzZXJNYXAsIG8gYXMgaXNDbGllbnQsIF8gYXMgX0ZpcmViYXNlQXBwSW5qZWN0aW9uS2V5IH0gZnJvbSAnLi9zaGFyZWQvdnVlZmlyZS4wZmViOTBjYy5tanMnO1xuZXhwb3J0IHsgViBhcyBWdWVGaXJlQXBwQ2hlY2ssIHIgYXMgZ2V0Q3VycmVudFVzZXIsIHQgYXMgdXBkYXRlQ3VycmVudFVzZXJQcm9maWxlLCB4IGFzIHVzZUFwcENoZWNrLCB2IGFzIHVzZUFwcENoZWNrVG9rZW4sIHAgYXMgdXNlQ3VycmVudFVzZXIsIHEgYXMgdXNlSXNDdXJyZW50VXNlckxvYWRlZCB9IGZyb20gJy4vc2hhcmVkL3Z1ZWZpcmUuMGZlYjkwY2MubWpzJztcbmltcG9ydCB7IHRvVmFsdWUsIHJlZiwgc2hhbGxvd1JlZiwgZ2V0Q3VycmVudFNjb3BlLCBpc1JlZiwgd2F0Y2gsIG9uU2NvcGVEaXNwb3NlLCBnZXRDdXJyZW50SW5zdGFuY2UsIG9uU2VydmVyUHJlZmV0Y2gsIGlzVnVlMywgdG9SZWYsIGVmZmVjdFNjb3BlLCBpbmplY3QsIGNvbXB1dGVkIH0gZnJvbSAndnVlLWRlbWknO1xuaW1wb3J0IHsgZ2V0LCBvblZhbHVlLCBvbkNoaWxkQWRkZWQsIG9uQ2hpbGRSZW1vdmVkLCBvbkNoaWxkQ2hhbmdlZCwgb25DaGlsZE1vdmVkLCBnZXREYXRhYmFzZSB9IGZyb20gJ2ZpcmViYXNlL2RhdGFiYXNlJztcbmltcG9ydCB7IFRpbWVzdGFtcCwgR2VvUG9pbnQsIGdldERvY3MsIG9uU25hcHNob3QsIGdldERvYywgZ2V0RmlyZXN0b3JlIH0gZnJvbSAnZmlyZWJhc2UvZmlyZXN0b3JlJztcbmltcG9ydCB7IGluaXRpYWxpemVBdXRoLCBicm93c2VyUG9wdXBSZWRpcmVjdFJlc29sdmVyLCBpbmRleGVkREJMb2NhbFBlcnNpc3RlbmNlLCBicm93c2VyTG9jYWxQZXJzaXN0ZW5jZSwgYnJvd3NlclNlc3Npb25QZXJzaXN0ZW5jZSB9IGZyb20gJ2ZpcmViYXNlL2F1dGgnO1xuaW1wb3J0IHsgZ2V0U3RvcmFnZSwgZ2V0RG93bmxvYWRVUkwsIGdldE1ldGFkYXRhLCB1cGRhdGVNZXRhZGF0YSwgdXBsb2FkQnl0ZXNSZXN1bWFibGUgfSBmcm9tICdmaXJlYmFzZS9zdG9yYWdlJztcbmltcG9ydCAnZmlyZWJhc2UvYXBwLWNoZWNrJztcbmltcG9ydCAnZmlyZWJhc2UvYXBwJztcblxuY29uc3QgX2luaXRpYWxTdGF0ZXNNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbmZ1bmN0aW9uIHVzZVNTUkluaXRpYWxTdGF0ZShpbml0aWFsU3RhdGUsIGZpcmViYXNlQXBwKSB7XG4gIGlmICghX2luaXRpYWxTdGF0ZXNNYXAuaGFzKGZpcmViYXNlQXBwKSkge1xuICAgIF9pbml0aWFsU3RhdGVzTWFwLnNldChcbiAgICAgIGZpcmViYXNlQXBwLFxuICAgICAgaW5pdGlhbFN0YXRlIHx8IHsgZjoge30sIHI6IHt9LCBzOiB7fSwgdToge30gfVxuICAgICk7XG4gIH1cbiAgcmV0dXJuIF9pbml0aWFsU3RhdGVzTWFwLmdldChmaXJlYmFzZUFwcCk7XG59XG5mdW5jdGlvbiBnZXRJbml0aWFsVmFsdWUoZGF0YVNvdXJjZSwgc3NyS2V5LCBmYWxsYmFja1ZhbHVlLCBmaXJlYmFzZUFwcCkge1xuICBpZiAoIWRhdGFTb3VyY2UpXG4gICAgcmV0dXJuIGZhbGxiYWNrVmFsdWU7XG4gIGNvbnN0IFtzb3VyY2VUeXBlLCBwYXRoXSA9IGdldERhdGFTb3VyY2VJbmZvKGRhdGFTb3VyY2UpO1xuICBpZiAoIXNvdXJjZVR5cGUpXG4gICAgcmV0dXJuIGZhbGxiYWNrVmFsdWU7XG4gIGNvbnN0IGluaXRpYWxTdGF0ZSA9IHVzZVNTUkluaXRpYWxTdGF0ZSh2b2lkIDAsIGZpcmViYXNlQXBwKVtzb3VyY2VUeXBlXSB8fCB7fTtcbiAgY29uc3Qga2V5ID0gc3NyS2V5IHx8IHBhdGg7XG4gIHJldHVybiBrZXkgJiYga2V5IGluIGluaXRpYWxTdGF0ZSA/IGluaXRpYWxTdGF0ZVtrZXldIDogZmFsbGJhY2tWYWx1ZTtcbn1cbmZ1bmN0aW9uIGRlZmVySW5pdGlhbFZhbHVlU2V0dXAoZGF0YVNvdXJjZSwgc3NyS2V5LCBwcm9taXNlLCBmaXJlYmFzZUFwcCkge1xuICBpZiAoIWRhdGFTb3VyY2UpXG4gICAgcmV0dXJuO1xuICBjb25zdCBbc291cmNlVHlwZSwgcGF0aF0gPSBnZXREYXRhU291cmNlSW5mbyhkYXRhU291cmNlKTtcbiAgaWYgKCFzb3VyY2VUeXBlKVxuICAgIHJldHVybjtcbiAgY29uc3QgaW5pdGlhbFN0YXRlID0gdXNlU1NSSW5pdGlhbFN0YXRlKFxuICAgIHZvaWQgMCxcbiAgICBmaXJlYmFzZUFwcFxuICApW3NvdXJjZVR5cGVdO1xuICBjb25zdCBrZXkgPSBzc3JLZXkgfHwgcGF0aDtcbiAgaWYgKGtleSkge1xuICAgIHByb21pc2UudGhlbigodmFsdWUpID0+IHtcbiAgICAgIGluaXRpYWxTdGF0ZVtrZXldID0gdmFsdWU7XG4gICAgfSkuY2F0Y2gobm9vcCk7XG4gICAgcmV0dXJuIGtleTtcbiAgfVxufVxuZnVuY3Rpb24gZ2V0RGF0YVNvdXJjZUluZm8oZGF0YVNvdXJjZSkge1xuICByZXR1cm4gaXNGaXJlc3RvcmVEYXRhUmVmZXJlbmNlKGRhdGFTb3VyY2UpIHx8IGlzRmlyZXN0b3JlUXVlcnkoZGF0YVNvdXJjZSkgPyBbXCJmXCIsIGRhdGFTb3VyY2UucGF0aF0gOiBpc0RhdGFiYXNlUmVmZXJlbmNlKGRhdGFTb3VyY2UpID8gW1wiclwiLCBkYXRhU291cmNlLnRvU3RyaW5nKCldIDogaXNTdG9yYWdlUmVmZXJlbmNlKGRhdGFTb3VyY2UpID8gW1wic1wiLCBkYXRhU291cmNlLnRvU3RyaW5nKCldIDogW107XG59XG5cbmNvbnN0IGFwcFBlbmRpbmdQcm9taXNlcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuZnVuY3Rpb24gYWRkUGVuZGluZ1Byb21pc2UocHJvbWlzZSwgZGF0YVNvdXJjZSwgc3NyS2V5KSB7XG4gIGNvbnN0IGFwcCA9IHVzZUZpcmViYXNlQXBwKCk7XG4gIGlmICghYXBwUGVuZGluZ1Byb21pc2VzLmhhcyhhcHApKSB7XG4gICAgYXBwUGVuZGluZ1Byb21pc2VzLnNldChhcHAsIC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCkpO1xuICB9XG4gIGNvbnN0IHBlbmRpbmdQcm9taXNlcyA9IGFwcFBlbmRpbmdQcm9taXNlcy5nZXQoYXBwKTtcbiAgY29uc3Qga2V5ID0gZGVmZXJJbml0aWFsVmFsdWVTZXR1cChkYXRhU291cmNlLCBzc3JLZXksIHByb21pc2UsIGFwcCk7XG4gIGlmIChrZXkpIHtcbiAgICBwZW5kaW5nUHJvbWlzZXMuc2V0KGtleSwgcHJvbWlzZSk7XG4gIH0gZWxzZSB7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgY29uc29sZS53YXJuKFwiW1Z1ZUZpcmUgU1NSXTogQ291bGQgbm90IGdldCB0aGUgcGF0aCBvZiB0aGUgZGF0YSBzb3VyY2VcIik7XG4gICAgfVxuICB9XG4gIHJldHVybiBrZXkgPyAoKSA9PiBwZW5kaW5nUHJvbWlzZXMuZGVsZXRlKGtleSkgOiBub29wO1xufVxuZnVuY3Rpb24gdXNlUGVuZGluZ1Byb21pc2VzKGFwcCkge1xuICBhcHAgPSBhcHAgfHwgdXNlRmlyZWJhc2VBcHAoKTtcbiAgY29uc3QgcGVuZGluZ1Byb21pc2VzID0gYXBwUGVuZGluZ1Byb21pc2VzLmdldChhcHApO1xuICBjb25zdCBwID0gcGVuZGluZ1Byb21pc2VzID8gUHJvbWlzZS5hbGwoXG4gICAgQXJyYXkuZnJvbShwZW5kaW5nUHJvbWlzZXMpLm1hcChcbiAgICAgIChba2V5LCBwcm9taXNlXSkgPT4gcHJvbWlzZS50aGVuKChkYXRhKSA9PiBba2V5LCBkYXRhXSlcbiAgICApXG4gICkgOiBQcm9taXNlLnJlc29sdmUoW10pO1xuICBhcHBQZW5kaW5nUHJvbWlzZXMuZGVsZXRlKGFwcCk7XG4gIHJldHVybiBwO1xufVxuXG5mdW5jdGlvbiBjcmVhdGVSZWNvcmRGcm9tRGF0YWJhc2VTbmFwc2hvdChzbmFwc2hvdCkge1xuICBpZiAoIXNuYXBzaG90LmV4aXN0cygpKVxuICAgIHJldHVybiBudWxsO1xuICBjb25zdCB2YWx1ZSA9IHNuYXBzaG90LnZhbCgpO1xuICByZXR1cm4gaXNPYmplY3QodmFsdWUpID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KHZhbHVlLCBcImlkXCIsIHtcbiAgICAvLyBhbGxvdyBkZXN0cnVjdHVyaW5nIHdpdGhvdXQgaW50ZXJmZXJpbmcgd2l0aG91dCB1c2luZyB0aGUgYGlkYCBwcm9wZXJ0eVxuICAgIHZhbHVlOiBzbmFwc2hvdC5rZXlcbiAgfSkgOiB7XG4gICAgLy8gaWYgdGhlIHZhbHVlIGlzIGEgcHJpbWl0aXZlIHdlIGNhbiBqdXN0IHJldHVybiBhIHJlZ3VsYXIgb2JqZWN0LCBpdCdzIGVhc2llciB0byBkZWJ1Z1xuICAgIC8vIEB0cy1leHBlY3QtZXJyb3I6ICR2YWx1ZSBkb2Vzbid0IGV4aXN0XG4gICAgJHZhbHVlOiB2YWx1ZSxcbiAgICBpZDogc25hcHNob3Qua2V5XG4gIH07XG59XG5mdW5jdGlvbiBpbmRleEZvcktleShhcnJheSwga2V5KSB7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYXJyYXkubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAoYXJyYXlbaV0uaWQgPT09IGtleSlcbiAgICAgIHJldHVybiBpO1xuICB9XG4gIHJldHVybiAtMTtcbn1cblxuY29uc3QgREVGQVVMVF9PUFRJT05TJDEgPSB7XG4gIHJlc2V0OiBmYWxzZSxcbiAgc2VyaWFsaXplOiBjcmVhdGVSZWNvcmRGcm9tRGF0YWJhc2VTbmFwc2hvdCxcbiAgd2FpdDogdHJ1ZVxufTtcbmZ1bmN0aW9uIGJpbmRBc09iamVjdCh0YXJnZXQsIGRvY3VtZW50LCByZXNvbHZlLCByZWplY3QsIGV4dHJhT3B0aW9ucykge1xuICBjb25zdCBvcHRpb25zID0gT2JqZWN0LmFzc2lnbih7fSwgREVGQVVMVF9PUFRJT05TJDEsIGV4dHJhT3B0aW9ucyk7XG4gIGxldCB1bnN1YnNjcmliZSA9IG5vb3A7XG4gIGZ1bmN0aW9uIG9uVmFsdWVDYWxsYmFjayhzbmFwc2hvdCkge1xuICAgIGNvbnN0IHZhbHVlID0gb3B0aW9ucy5zZXJpYWxpemUoc25hcHNob3QpO1xuICAgIHRhcmdldC52YWx1ZSA9IHZhbHVlO1xuICAgIHJlc29sdmUodmFsdWUpO1xuICB9XG4gIGlmIChvcHRpb25zLm9uY2UpIHtcbiAgICBnZXQoZG9jdW1lbnQpLnRoZW4ob25WYWx1ZUNhbGxiYWNrKS5jYXRjaChyZWplY3QpO1xuICB9IGVsc2Uge1xuICAgIHVuc3Vic2NyaWJlID0gb25WYWx1ZShkb2N1bWVudCwgb25WYWx1ZUNhbGxiYWNrLCByZWplY3QpO1xuICB9XG4gIHJldHVybiAocmVzZXQpID0+IHtcbiAgICB1bnN1YnNjcmliZSgpO1xuICAgIGlmIChyZXNldCkge1xuICAgICAgY29uc3QgdmFsdWUgPSB0eXBlb2YgcmVzZXQgPT09IFwiZnVuY3Rpb25cIiA/IHJlc2V0KCkgOiBudWxsO1xuICAgICAgdGFyZ2V0LnZhbHVlID0gdmFsdWU7XG4gICAgfVxuICB9O1xufVxuZnVuY3Rpb24gYmluZEFzQXJyYXkodGFyZ2V0LCBjb2xsZWN0aW9uLCByZXNvbHZlLCByZWplY3QsIGV4dHJhT3B0aW9ucykge1xuICBjb25zdCBvcHRpb25zID0gT2JqZWN0LmFzc2lnbih7fSwgREVGQVVMVF9PUFRJT05TJDEsIGV4dHJhT3B0aW9ucyk7XG4gIGxldCBhcnJheVJlZiA9IG9wdGlvbnMud2FpdCA/IFtdIDogdGFyZ2V0O1xuICBpZiAoIW9wdGlvbnMud2FpdCkge1xuICAgIHRhcmdldC52YWx1ZSA9IFtdO1xuICB9XG4gIGxldCByZW1vdmVDaGlsZEFkZGVkTGlzdGVuZXIgPSBub29wO1xuICBsZXQgcmVtb3ZlQ2hpbGRDaGFuZ2VkTGlzdGVuZXIgPSBub29wO1xuICBsZXQgcmVtb3ZlQ2hpbGRSZW1vdmVkTGlzdGVuZXIgPSBub29wO1xuICBsZXQgcmVtb3ZlQ2hpbGRNb3ZlZExpc3RlbmVyID0gbm9vcDtcbiAgbGV0IHJlbW92ZVZhbHVlTGlzdGVuZXIgPSBub29wO1xuICBpZiAob3B0aW9ucy5vbmNlKSB7XG4gICAgZ2V0KGNvbGxlY3Rpb24pLnRoZW4oKGRhdGEpID0+IHtcbiAgICAgIGNvbnN0IGFycmF5ID0gW107XG4gICAgICBkYXRhLmZvckVhY2goKHNuYXBzaG90KSA9PiB7XG4gICAgICAgIGFycmF5LnB1c2gob3B0aW9ucy5zZXJpYWxpemUoc25hcHNob3QpKTtcbiAgICAgIH0pO1xuICAgICAgcmVzb2x2ZSh0YXJnZXQudmFsdWUgPSBhcnJheSk7XG4gICAgfSkuY2F0Y2gocmVqZWN0KTtcbiAgfSBlbHNlIHtcbiAgICByZW1vdmVDaGlsZEFkZGVkTGlzdGVuZXIgPSBvbkNoaWxkQWRkZWQoXG4gICAgICBjb2xsZWN0aW9uLFxuICAgICAgKHNuYXBzaG90LCBwcmV2S2V5KSA9PiB7XG4gICAgICAgIGNvbnN0IGFycmF5ID0gdG9WYWx1ZShhcnJheVJlZik7XG4gICAgICAgIGNvbnN0IGluZGV4ID0gcHJldktleSA/IGluZGV4Rm9yS2V5KGFycmF5LCBwcmV2S2V5KSArIDEgOiAwO1xuICAgICAgICBhcnJheS5zcGxpY2UoaW5kZXgsIDAsIG9wdGlvbnMuc2VyaWFsaXplKHNuYXBzaG90KSk7XG4gICAgICB9LFxuICAgICAgcmVqZWN0XG4gICAgKTtcbiAgICByZW1vdmVDaGlsZFJlbW92ZWRMaXN0ZW5lciA9IG9uQ2hpbGRSZW1vdmVkKFxuICAgICAgY29sbGVjdGlvbixcbiAgICAgIChzbmFwc2hvdCkgPT4ge1xuICAgICAgICBjb25zdCBhcnJheSA9IHRvVmFsdWUoYXJyYXlSZWYpO1xuICAgICAgICBhcnJheS5zcGxpY2UoaW5kZXhGb3JLZXkoYXJyYXksIHNuYXBzaG90LmtleSksIDEpO1xuICAgICAgfSxcbiAgICAgIHJlamVjdFxuICAgICk7XG4gICAgcmVtb3ZlQ2hpbGRDaGFuZ2VkTGlzdGVuZXIgPSBvbkNoaWxkQ2hhbmdlZChcbiAgICAgIGNvbGxlY3Rpb24sXG4gICAgICAoc25hcHNob3QpID0+IHtcbiAgICAgICAgY29uc3QgYXJyYXkgPSB0b1ZhbHVlKGFycmF5UmVmKTtcbiAgICAgICAgYXJyYXkuc3BsaWNlKFxuICAgICAgICAgIGluZGV4Rm9yS2V5KGFycmF5LCBzbmFwc2hvdC5rZXkpLFxuICAgICAgICAgIDEsXG4gICAgICAgICAgLy8gY2Fubm90IGJlIG51bGwgYmVjYXVzZSBpdCBleGlzdHNcbiAgICAgICAgICBvcHRpb25zLnNlcmlhbGl6ZShzbmFwc2hvdClcbiAgICAgICAgKTtcbiAgICAgIH0sXG4gICAgICByZWplY3RcbiAgICApO1xuICAgIHJlbW92ZUNoaWxkTW92ZWRMaXN0ZW5lciA9IG9uQ2hpbGRNb3ZlZChcbiAgICAgIGNvbGxlY3Rpb24sXG4gICAgICAoc25hcHNob3QsIHByZXZLZXkpID0+IHtcbiAgICAgICAgY29uc3QgYXJyYXkgPSB0b1ZhbHVlKGFycmF5UmVmKTtcbiAgICAgICAgY29uc3QgaW5kZXggPSBpbmRleEZvcktleShhcnJheSwgc25hcHNob3Qua2V5KTtcbiAgICAgICAgY29uc3Qgb2xkUmVjb3JkID0gYXJyYXkuc3BsaWNlKGluZGV4LCAxKVswXTtcbiAgICAgICAgY29uc3QgbmV3SW5kZXggPSBwcmV2S2V5ID8gaW5kZXhGb3JLZXkoYXJyYXksIHByZXZLZXkpICsgMSA6IDA7XG4gICAgICAgIGFycmF5LnNwbGljZShuZXdJbmRleCwgMCwgb2xkUmVjb3JkKTtcbiAgICAgIH0sXG4gICAgICByZWplY3RcbiAgICApO1xuICAgIHJlbW92ZVZhbHVlTGlzdGVuZXIgPSBvblZhbHVlKFxuICAgICAgY29sbGVjdGlvbixcbiAgICAgICgpID0+IHtcbiAgICAgICAgY29uc3QgYXJyYXkgPSB0b1ZhbHVlKGFycmF5UmVmKTtcbiAgICAgICAgaWYgKG9wdGlvbnMud2FpdCkge1xuICAgICAgICAgIHRhcmdldC52YWx1ZSA9IGFycmF5O1xuICAgICAgICAgIGFycmF5UmVmID0gdGFyZ2V0O1xuICAgICAgICB9XG4gICAgICAgIHJlc29sdmUoYXJyYXkpO1xuICAgICAgICByZW1vdmVWYWx1ZUxpc3RlbmVyKCk7XG4gICAgICB9LFxuICAgICAgcmVqZWN0XG4gICAgKTtcbiAgfVxuICByZXR1cm4gKHJlc2V0KSA9PiB7XG4gICAgcmVtb3ZlVmFsdWVMaXN0ZW5lcigpO1xuICAgIHJlbW92ZUNoaWxkQWRkZWRMaXN0ZW5lcigpO1xuICAgIHJlbW92ZUNoaWxkUmVtb3ZlZExpc3RlbmVyKCk7XG4gICAgcmVtb3ZlQ2hpbGRDaGFuZ2VkTGlzdGVuZXIoKTtcbiAgICByZW1vdmVDaGlsZE1vdmVkTGlzdGVuZXIoKTtcbiAgICBpZiAocmVzZXQpIHtcbiAgICAgIGNvbnN0IHZhbHVlID0gdHlwZW9mIHJlc2V0ID09PSBcImZ1bmN0aW9uXCIgPyByZXNldCgpIDogW107XG4gICAgICB0YXJnZXQudmFsdWUgPSB2YWx1ZTtcbiAgICB9XG4gIH07XG59XG5cbmZ1bmN0aW9uIF91c2VEYXRhYmFzZVJlZihyZWZlcmVuY2UsIGxvY2FsT3B0aW9ucyA9IHt9LCBpc0xpc3QgPSBmYWxzZSkge1xuICBsZXQgdW5iaW5kID0gbm9vcDtcbiAgY29uc3Qgb3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oe30sIERFRkFVTFRfT1BUSU9OUyQxLCBsb2NhbE9wdGlvbnMpO1xuICBjb25zdCBpbml0aWFsU291cmNlVmFsdWUgPSB0b1ZhbHVlKHJlZmVyZW5jZSk7XG4gIGNvbnN0IGRhdGEgPSBvcHRpb25zLnRhcmdldCB8fCByZWYoKTtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgIGlmIChvcHRpb25zLnRhcmdldCAmJiBjaGVja1dyaXR0ZW5UYXJnZXQoZGF0YSwgXCJ1c2VEYXRhYmFzZU9iamVjdCgpL3VzZURhdGFiYXNlTGlzdCgpXCIpKSB7XG4gICAgICByZXR1cm4gZGF0YTtcbiAgICB9XG4gIH1cbiAgY29uc3QgaXNTU1IgPSB1c2VJc1NTUigpO1xuICBpZiAoaXNTU1IpIHtcbiAgICBvcHRpb25zLm9uY2UgPSB0cnVlO1xuICB9XG4gIGNvbnN0IGluaXRpYWxWYWx1ZSA9IGdldEluaXRpYWxWYWx1ZShcbiAgICBpbml0aWFsU291cmNlVmFsdWUsXG4gICAgb3B0aW9ucy5zc3JLZXksXG4gICAgZGF0YS52YWx1ZSxcbiAgICB1c2VGaXJlYmFzZUFwcCgpXG4gICk7XG4gIGRhdGEudmFsdWUgPSBpbml0aWFsVmFsdWU7XG4gIGNvbnN0IGhhc0luaXRpYWxWYWx1ZSA9IGlzTGlzdCA/IChpbml0aWFsVmFsdWUgfHwgW10pLmxlbmd0aCA+IDAgOiBpbml0aWFsVmFsdWUgIT09IHZvaWQgMDtcbiAgbGV0IHNob3VsZFN0YXJ0QXNQZW5kaW5nID0gIWhhc0luaXRpYWxWYWx1ZTtcbiAgY29uc3QgZXJyb3IgPSByZWYoKTtcbiAgY29uc3QgcGVuZGluZyA9IHJlZihmYWxzZSk7XG4gIGNvbnN0IHByb21pc2UgPSBzaGFsbG93UmVmKCk7XG4gIGNvbnN0IGhhc0N1cnJlbnRTY29wZSA9IGdldEN1cnJlbnRTY29wZSgpO1xuICBsZXQgcmVtb3ZlUGVuZGluZ1Byb21pc2UgPSBub29wO1xuICBmdW5jdGlvbiBiaW5kRGF0YWJhc2VSZWYoKSB7XG4gICAgY29uc3QgcmVmZXJlbmNlVmFsdWUgPSB0b1ZhbHVlKHJlZmVyZW5jZSk7XG4gICAgY29uc3QgbmV3UHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHVuYmluZChvcHRpb25zLnJlc2V0KTtcbiAgICAgIGlmICghcmVmZXJlbmNlVmFsdWUpIHtcbiAgICAgICAgdW5iaW5kID0gbm9vcDtcbiAgICAgICAgcmV0dXJuIHJlc29sdmUobnVsbCk7XG4gICAgICB9XG4gICAgICBwZW5kaW5nLnZhbHVlID0gc2hvdWxkU3RhcnRBc1BlbmRpbmc7XG4gICAgICBzaG91bGRTdGFydEFzUGVuZGluZyA9IHRydWU7XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShkYXRhLnZhbHVlKSkge1xuICAgICAgICB1bmJpbmQgPSBiaW5kQXNBcnJheShcbiAgICAgICAgICBkYXRhLFxuICAgICAgICAgIHJlZmVyZW5jZVZhbHVlLFxuICAgICAgICAgIHJlc29sdmUsXG4gICAgICAgICAgcmVqZWN0LFxuICAgICAgICAgIG9wdGlvbnNcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHVuYmluZCA9IGJpbmRBc09iamVjdChkYXRhLCByZWZlcmVuY2VWYWx1ZSwgcmVzb2x2ZSwgcmVqZWN0LCBvcHRpb25zKTtcbiAgICAgIH1cbiAgICB9KS5jYXRjaCgocmVhc29uKSA9PiB7XG4gICAgICBpZiAocHJvbWlzZS52YWx1ZSA9PT0gbmV3UHJvbWlzZSkge1xuICAgICAgICBlcnJvci52YWx1ZSA9IHJlYXNvbjtcbiAgICAgIH1cbiAgICAgIHRocm93IHJlYXNvbjtcbiAgICB9KS5maW5hbGx5KCgpID0+IHtcbiAgICAgIGlmIChwcm9taXNlLnZhbHVlID09PSBuZXdQcm9taXNlKSB7XG4gICAgICAgIHBlbmRpbmcudmFsdWUgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBwcm9taXNlLnZhbHVlID0gbmV3UHJvbWlzZTtcbiAgfVxuICBsZXQgc3RvcFdhdGNoZXIgPSBub29wO1xuICBpZiAoaXNSZWYocmVmZXJlbmNlKSB8fCB0eXBlb2YgcmVmZXJlbmNlID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICBzdG9wV2F0Y2hlciA9IHdhdGNoKHJlZmVyZW5jZSwgYmluZERhdGFiYXNlUmVmKTtcbiAgfVxuICBiaW5kRGF0YWJhc2VSZWYoKTtcbiAgaWYgKGluaXRpYWxTb3VyY2VWYWx1ZSkge1xuICAgIHJlbW92ZVBlbmRpbmdQcm9taXNlID0gYWRkUGVuZGluZ1Byb21pc2UoXG4gICAgICBwcm9taXNlLnZhbHVlLFxuICAgICAgaW5pdGlhbFNvdXJjZVZhbHVlLFxuICAgICAgb3B0aW9ucy5zc3JLZXlcbiAgICApO1xuICB9XG4gIGlmIChoYXNDdXJyZW50U2NvcGUpIHtcbiAgICBvblNjb3BlRGlzcG9zZShzdG9wKTtcbiAgICBpZiAoZ2V0Q3VycmVudEluc3RhbmNlKCkpIHtcbiAgICAgIG9uU2VydmVyUHJlZmV0Y2goKCkgPT4gcHJvbWlzZS52YWx1ZSk7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIHN0b3AocmVzZXQgPSBvcHRpb25zLnJlc2V0KSB7XG4gICAgc3RvcFdhdGNoZXIoKTtcbiAgICByZW1vdmVQZW5kaW5nUHJvbWlzZSgpO1xuICAgIHVuYmluZChyZXNldCk7XG4gIH1cbiAgcmV0dXJuIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGRhdGEsIHtcbiAgICAvLyBhbGxvdyBkZXN0cnVjdHVyaW5nIHdpdGhvdXQgaW50ZXJmZXJpbmcgd2l0aCB0aGUgcmVmIGl0c2VsZlxuICAgIGRhdGE6IHsgZ2V0OiAoKSA9PiBkYXRhIH0sXG4gICAgZXJyb3I6IHsgZ2V0OiAoKSA9PiBlcnJvciB9LFxuICAgIHBlbmRpbmc6IHsgZ2V0OiAoKSA9PiBwZW5kaW5nIH0sXG4gICAgcHJvbWlzZTogeyBnZXQ6ICgpID0+IHByb21pc2UgfSxcbiAgICBzdG9wOiB7IGdldDogKCkgPT4gc3RvcCB9XG4gIH0pO1xufVxuXG5mdW5jdGlvbiB1c2VEYXRhYmFzZUxpc3QocmVmZXJlbmNlLCBvcHRpb25zKSB7XG4gIGNvbnN0IGRhdGEgPSByZWYoW10pO1xuICByZXR1cm4gX3VzZURhdGFiYXNlUmVmKFxuICAgIHJlZmVyZW5jZSxcbiAgICB7XG4gICAgICB0YXJnZXQ6IGRhdGEsXG4gICAgICAuLi5vcHRpb25zXG4gICAgfSxcbiAgICB0cnVlXG4gICk7XG59XG5jb25zdCB1c2VMaXN0ID0gdXNlRGF0YWJhc2VMaXN0O1xuZnVuY3Rpb24gdXNlRGF0YWJhc2VPYmplY3QocmVmZXJlbmNlLCBvcHRpb25zKSB7XG4gIGNvbnN0IGRhdGEgPSByZWYoKTtcbiAgcmV0dXJuIF91c2VEYXRhYmFzZVJlZihyZWZlcmVuY2UsIHtcbiAgICB0YXJnZXQ6IGRhdGEsXG4gICAgLi4ub3B0aW9uc1xuICB9KTtcbn1cbmNvbnN0IHVzZU9iamVjdCA9IHVzZURhdGFiYXNlT2JqZWN0O1xuZnVuY3Rpb24gdXNlRGF0YWJhc2UobmFtZSkge1xuICByZXR1cm4gZ2V0RGF0YWJhc2UodXNlRmlyZWJhc2VBcHAobmFtZSkpO1xufVxuXG5jb25zdCBmaXJlc3RvcmVEZWZhdWx0Q29udmVydGVyID0ge1xuICB0b0ZpcmVzdG9yZShkYXRhKSB7XG4gICAgcmV0dXJuIGRhdGE7XG4gIH0sXG4gIGZyb21GaXJlc3RvcmUoc25hcHNob3QsIG9wdGlvbnMpIHtcbiAgICByZXR1cm4gc25hcHNob3QuZXhpc3RzKCkgPyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhzbmFwc2hvdC5kYXRhKG9wdGlvbnMpLCB7XG4gICAgICBpZDogeyB2YWx1ZTogc25hcHNob3QuaWQgfVxuICAgICAgLy8gVE9ETzogY2hlY2sgaWYgd29ydGggYWRkaW5nIG9yIHNob3VsZCBiZSB0aHJvdWdoIGFuIG9wdGlvblxuICAgICAgLy8gSXQgY291bGQgYWxzbyBiZSBhbiBleGFtcGxlIGluIHRoZSBkb2NzIGFib3V0IGNvbnZlcnRlcnNcbiAgICAgIC8vICRtZXRhOiB7XG4gICAgICAvLyAgIHZhbHVlOiBzbmFwc2hvdC5tZXRhZGF0YSxcbiAgICAgIC8vIH0sXG4gICAgICAvLyAkcmVmOiB7IGdldDogKCkgPT4gc25hcHNob3QucmVmIH0sXG4gICAgfSkgOiBudWxsO1xuICB9XG59O1xuZnVuY3Rpb24gZXh0cmFjdFJlZnMoZG9jLCBvbGREb2MsIHN1YnMsIG9wdGlvbnMpIHtcbiAgaWYgKCFpc1BPSk8oZG9jKSlcbiAgICByZXR1cm4gW2RvYywge31dO1xuICBjb25zdCBkYXRhQW5kUmVmcyA9IFtcbiAgICB7fSxcbiAgICB7fVxuICBdO1xuICBjb25zdCBzdWJzQnlQYXRoID0gT2JqZWN0LmtleXMoc3VicykucmVkdWNlKFxuICAgIChyZXN1bHRTdWJzLCBzdWJLZXkpID0+IHtcbiAgICAgIGNvbnN0IHN1YiA9IHN1YnNbc3ViS2V5XTtcbiAgICAgIHJlc3VsdFN1YnNbc3ViLnBhdGhdID0gc3ViLmRhdGEoKTtcbiAgICAgIHJldHVybiByZXN1bHRTdWJzO1xuICAgIH0sXG4gICAge31cbiAgKTtcbiAgZnVuY3Rpb24gcmVjdXJzaXZlRXh0cmFjdChkb2MyLCBvbGREb2MyLCBwYXRoLCByZXN1bHQpIHtcbiAgICBvbGREb2MyID0gb2xkRG9jMiB8fCB7fTtcbiAgICBjb25zdCBbZGF0YSwgcmVmc10gPSByZXN1bHQ7XG4gICAgT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMoZG9jMikuZm9yRWFjaCgocHJvcGVydHlOYW1lKSA9PiB7XG4gICAgICBjb25zdCBkZXNjcmlwdG9yID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihkb2MyLCBwcm9wZXJ0eU5hbWUpO1xuICAgICAgaWYgKGRlc2NyaXB0b3IgJiYgIWRlc2NyaXB0b3IuZW51bWVyYWJsZSkge1xuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoZGF0YSwgcHJvcGVydHlOYW1lLCBkZXNjcmlwdG9yKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBkb2MyKSB7XG4gICAgICBjb25zdCByZWYgPSBkb2MyW2tleV07XG4gICAgICBpZiAoXG4gICAgICAgIC8vIHByaW1pdGl2ZXNcbiAgICAgICAgcmVmID09IG51bGwgfHwgLy8gVE9ETzogY2hlY2sgYW5kIHJlbW92ZVxuICAgICAgICAvLyBGaXJlc3RvcmUgPCA0LjEzXG4gICAgICAgIHJlZiBpbnN0YW5jZW9mIERhdGUgfHwgcmVmIGluc3RhbmNlb2YgVGltZXN0YW1wIHx8IHJlZiBpbnN0YW5jZW9mIEdlb1BvaW50XG4gICAgICApIHtcbiAgICAgICAgZGF0YVtrZXldID0gcmVmO1xuICAgICAgfSBlbHNlIGlmIChpc0RvY3VtZW50UmVmKHJlZikpIHtcbiAgICAgICAgY29uc3QgcmVmU3ViS2V5ID0gcGF0aCArIGtleTtcbiAgICAgICAgZGF0YVtrZXldID0gLy8gaWYgdGhlIHJlZiB3YXMgYWxyZWFkeSBib3VuZCwga2VlcCB0aGUgc2FtZSBvYmplY3RcbiAgICAgICAgLy8gb3RoZXJ3aXNlIHNldCB0aGUgcGF0aCBhcyBhIHN0cmluZyBzbyBpdCBjYW4gYmUgYm91bmQgbGF0ZXJcbiAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL3Z1ZWpzL3Z1ZWZpcmUvaXNzdWVzLzgzMVxuICAgICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vdnVlanMvdnVlZmlyZS9wdWxsLzEyMjNcbiAgICAgICAgcmVmU3ViS2V5IGluIHN1YnMgPyBvbGREb2MyW2tleV0gOiByZWYucGF0aDtcbiAgICAgICAgcmVmc1tyZWZTdWJLZXldID0gcmVmLmNvbnZlcnRlciA/IHJlZiA6IHJlZi53aXRoQ29udmVydGVyKFxuICAgICAgICAgIG9wdGlvbnMuY29udmVydGVyXG4gICAgICAgICk7XG4gICAgICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkocmVmKSkge1xuICAgICAgICBkYXRhW2tleV0gPSBBcnJheShyZWYubGVuZ3RoKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZWYubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBjb25zdCBuZXdSZWYgPSByZWZbaV07XG4gICAgICAgICAgaWYgKG5ld1JlZiAmJiBuZXdSZWYucGF0aCBpbiBzdWJzQnlQYXRoKVxuICAgICAgICAgICAgZGF0YVtrZXldW2ldID0gc3Vic0J5UGF0aFtuZXdSZWYucGF0aF07XG4gICAgICAgIH1cbiAgICAgICAgcmVjdXJzaXZlRXh0cmFjdChyZWYsIG9sZERvYzJba2V5XSB8fCBkYXRhW2tleV0sIHBhdGggKyBrZXkgKyBcIi5cIiwgW1xuICAgICAgICAgIGRhdGFba2V5XSxcbiAgICAgICAgICByZWZzXG4gICAgICAgIF0pO1xuICAgICAgfSBlbHNlIGlmIChpc09iamVjdChyZWYpKSB7XG4gICAgICAgIGRhdGFba2V5XSA9IHt9O1xuICAgICAgICByZWN1cnNpdmVFeHRyYWN0KHJlZiwgb2xkRG9jMltrZXldLCBwYXRoICsga2V5ICsgXCIuXCIsIFtkYXRhW2tleV0sIHJlZnNdKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGRhdGFba2V5XSA9IHJlZjtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmVjdXJzaXZlRXh0cmFjdChkb2MsIG9sZERvYywgXCJcIiwgZGF0YUFuZFJlZnMpO1xuICByZXR1cm4gZGF0YUFuZFJlZnM7XG59XG5jb25zdCBkZXZhbHVlQ3VzdG9tU3RyaW5naWZpZXJzID0ge1xuICBUaW1lU3RhbXA6IChkYXRhKSA9PiBkYXRhIGluc3RhbmNlb2YgVGltZXN0YW1wICYmIGRhdGEudG9KU09OKCksXG4gIEdlb1BvaW50OiAoZGF0YSkgPT4gZGF0YSBpbnN0YW5jZW9mIEdlb1BvaW50ICYmIGRhdGEudG9KU09OKClcbn07XG5jb25zdCBkZXZhbHVlQ3VzdG9tUGFyc2VycyA9IHtcbiAgVGltZVN0YW1wOiAoZGF0YSkgPT4gbmV3IFRpbWVzdGFtcChkYXRhLnNlY29uZHMsIGRhdGEubmFub3NlY29uZHMpLFxuICBHZW9Qb2ludDogKGRhdGEpID0+IG5ldyBHZW9Qb2ludChkYXRhLmxhdGl0dWRlLCBkYXRhLmxvbmdpdHVkZSlcbn07XG5cbmNvbnN0IERFRkFVTFRfT1BUSU9OUyA9IHtcbiAgcmVzZXQ6IGZhbHNlLFxuICB3YWl0OiB0cnVlLFxuICBtYXhSZWZEZXB0aDogMixcbiAgY29udmVydGVyOiBmaXJlc3RvcmVEZWZhdWx0Q29udmVydGVyLFxuICBzbmFwc2hvdE9wdGlvbnM6IHsgc2VydmVyVGltZXN0YW1wczogXCJlc3RpbWF0ZVwiIH1cbn07XG5mdW5jdGlvbiB1bnN1YnNjcmliZUFsbChzdWJzKSB7XG4gIGZvciAoY29uc3Qgc3ViIGluIHN1YnMpIHtcbiAgICBzdWJzW3N1Yl0udW5zdWIoKTtcbiAgfVxufVxuZnVuY3Rpb24gdXBkYXRlRGF0YUZyb21Eb2N1bWVudFNuYXBzaG90KG9wdGlvbnMsIHRhcmdldCwgcGF0aCwgc25hcHNob3QsIHN1YnMsIG9wcywgZGVwdGgsIHJlc29sdmUsIHJlamVjdCkge1xuICBjb25zdCBbZGF0YSwgcmVmc10gPSBleHRyYWN0UmVmcyhcbiAgICAvLyBQYXNzIHNuYXBzaG90IG9wdGlvbnNcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yOiBGSVhNRTogdXNlIGJldHRlciB0eXBlc1xuICAgIHNuYXBzaG90LmRhdGEob3B0aW9ucy5zbmFwc2hvdE9wdGlvbnMpLFxuICAgIHdhbGtHZXQodGFyZ2V0LCBwYXRoKSxcbiAgICBzdWJzLFxuICAgIG9wdGlvbnNcbiAgKTtcbiAgb3BzLnNldCh0YXJnZXQsIHBhdGgsIGRhdGEpO1xuICBzdWJzY3JpYmVUb1JlZnMoXG4gICAgb3B0aW9ucyxcbiAgICB0YXJnZXQsXG4gICAgcGF0aCxcbiAgICBzdWJzLFxuICAgIHJlZnMsXG4gICAgb3BzLFxuICAgIGRlcHRoLFxuICAgIHJlc29sdmUsXG4gICAgcmVqZWN0XG4gICk7XG59XG5mdW5jdGlvbiBzdWJzY3JpYmVUb0RvY3VtZW50KHtcbiAgcmVmOiByZWYyLFxuICB0YXJnZXQsXG4gIHBhdGgsXG4gIGRlcHRoLFxuICByZXNvbHZlLFxuICByZWplY3QsXG4gIG9wc1xufSwgb3B0aW9ucykge1xuICBjb25zdCBzdWJzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGxldCB1bmJpbmQgPSBub29wO1xuICBpZiAob3B0aW9ucy5vbmNlKSB7XG4gICAgZ2V0RG9jKHJlZjIpLnRoZW4oKHNuYXBzaG90KSA9PiB7XG4gICAgICBpZiAoc25hcHNob3QuZXhpc3RzKCkpIHtcbiAgICAgICAgdXBkYXRlRGF0YUZyb21Eb2N1bWVudFNuYXBzaG90KFxuICAgICAgICAgIG9wdGlvbnMsXG4gICAgICAgICAgdGFyZ2V0LFxuICAgICAgICAgIHBhdGgsXG4gICAgICAgICAgc25hcHNob3QsXG4gICAgICAgICAgc3VicyxcbiAgICAgICAgICBvcHMsXG4gICAgICAgICAgZGVwdGgsXG4gICAgICAgICAgcmVzb2x2ZSxcbiAgICAgICAgICByZWplY3RcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG9wcy5zZXQodGFyZ2V0LCBwYXRoLCBudWxsKTtcbiAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgfVxuICAgIH0pLmNhdGNoKHJlamVjdCk7XG4gIH0gZWxzZSB7XG4gICAgdW5iaW5kID0gb25TbmFwc2hvdChcbiAgICAgIHJlZjIsXG4gICAgICAoc25hcHNob3QpID0+IHtcbiAgICAgICAgaWYgKHNuYXBzaG90LmV4aXN0cygpKSB7XG4gICAgICAgICAgdXBkYXRlRGF0YUZyb21Eb2N1bWVudFNuYXBzaG90KFxuICAgICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgICAgIHRhcmdldCxcbiAgICAgICAgICAgIHBhdGgsXG4gICAgICAgICAgICBzbmFwc2hvdCxcbiAgICAgICAgICAgIHN1YnMsXG4gICAgICAgICAgICBvcHMsXG4gICAgICAgICAgICBkZXB0aCxcbiAgICAgICAgICAgIHJlc29sdmUsXG4gICAgICAgICAgICByZWplY3RcbiAgICAgICAgICApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG9wcy5zZXQodGFyZ2V0LCBwYXRoLCBudWxsKTtcbiAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICByZWplY3RcbiAgICApO1xuICB9XG4gIHJldHVybiAoKSA9PiB7XG4gICAgdW5iaW5kKCk7XG4gICAgdW5zdWJzY3JpYmVBbGwoc3Vicyk7XG4gIH07XG59XG5mdW5jdGlvbiBzdWJzY3JpYmVUb1JlZnMob3B0aW9ucywgdGFyZ2V0LCBwYXRoLCBzdWJzLCByZWZzLCBvcHMsIGRlcHRoLCByZXNvbHZlLCByZWplY3QpIHtcbiAgY29uc3QgcmVmS2V5cyA9IE9iamVjdC5rZXlzKHJlZnMpO1xuICBjb25zdCBtaXNzaW5nS2V5cyA9IE9iamVjdC5rZXlzKHN1YnMpLmZpbHRlcihcbiAgICAocmVmS2V5KSA9PiByZWZLZXlzLmluZGV4T2YocmVmS2V5KSA8IDBcbiAgKTtcbiAgbWlzc2luZ0tleXMuZm9yRWFjaCgocmVmS2V5KSA9PiB7XG4gICAgc3Vic1tyZWZLZXldLnVuc3ViKCk7XG4gICAgZGVsZXRlIHN1YnNbcmVmS2V5XTtcbiAgfSk7XG4gIGlmICghcmVmS2V5cy5sZW5ndGggfHwgKytkZXB0aCA+IG9wdGlvbnMubWF4UmVmRGVwdGgpXG4gICAgcmV0dXJuIHJlc29sdmUocGF0aCk7XG4gIGxldCByZXNvbHZlZENvdW50ID0gMDtcbiAgY29uc3QgdG90YWxUb1Jlc29sdmUgPSByZWZLZXlzLmxlbmd0aDtcbiAgY29uc3QgdmFsaWRSZXNvbHZlcyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBmdW5jdGlvbiBkZWVwUmVzb2x2ZShrZXkpIHtcbiAgICBpZiAoa2V5IGluIHZhbGlkUmVzb2x2ZXMpIHtcbiAgICAgIGlmICgrK3Jlc29sdmVkQ291bnQgPj0gdG90YWxUb1Jlc29sdmUpXG4gICAgICAgIHJlc29sdmUocGF0aCk7XG4gICAgfVxuICB9XG4gIHJlZktleXMuZm9yRWFjaCgocmVmS2V5KSA9PiB7XG4gICAgY29uc3Qgc3ViID0gc3Vic1tyZWZLZXldO1xuICAgIGNvbnN0IHJlZjIgPSByZWZzW3JlZktleV07XG4gICAgY29uc3QgZG9jUGF0aCA9IGAke3BhdGh9LiR7cmVmS2V5fWA7XG4gICAgdmFsaWRSZXNvbHZlc1tkb2NQYXRoXSA9IHRydWU7XG4gICAgaWYgKHN1Yikge1xuICAgICAgaWYgKHN1Yi5wYXRoICE9PSByZWYyLnBhdGgpXG4gICAgICAgIHN1Yi51bnN1YigpO1xuICAgICAgZWxzZVxuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIHN1YnNbcmVmS2V5XSA9IHtcbiAgICAgIGRhdGE6ICgpID0+IHdhbGtHZXQodGFyZ2V0LCBkb2NQYXRoKSxcbiAgICAgIHVuc3ViOiBzdWJzY3JpYmVUb0RvY3VtZW50KFxuICAgICAgICB7XG4gICAgICAgICAgcmVmOiByZWYyLFxuICAgICAgICAgIHRhcmdldCxcbiAgICAgICAgICBwYXRoOiBkb2NQYXRoLFxuICAgICAgICAgIGRlcHRoLFxuICAgICAgICAgIG9wcyxcbiAgICAgICAgICByZXNvbHZlOiBkZWVwUmVzb2x2ZS5iaW5kKG51bGwsIGRvY1BhdGgpLFxuICAgICAgICAgIHJlamVjdFxuICAgICAgICB9LFxuICAgICAgICBvcHRpb25zXG4gICAgICApLFxuICAgICAgcGF0aDogcmVmMi5wYXRoXG4gICAgfTtcbiAgfSk7XG59XG5mdW5jdGlvbiBiaW5kQ29sbGVjdGlvbih0YXJnZXQsIGNvbGxlY3Rpb24sIG9wcywgcmVzb2x2ZSwgcmVqZWN0LCBleHRyYU9wdGlvbnMpIHtcbiAgY29uc3Qgb3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oe30sIERFRkFVTFRfT1BUSU9OUywgZXh0cmFPcHRpb25zKTtcbiAgY29uc3QgeyBzbmFwc2hvdExpc3Rlbk9wdGlvbnMsIHNuYXBzaG90T3B0aW9ucywgd2FpdCwgb25jZSB9ID0gb3B0aW9ucztcbiAgY29uc3Qga2V5ID0gXCJ2YWx1ZVwiO1xuICBsZXQgYXJyYXlSZWYgPSByZWYod2FpdCA/IFtdIDogdGFyZ2V0LnZhbHVlKTtcbiAgaWYgKCF3YWl0KVxuICAgIG9wcy5zZXQodGFyZ2V0LCBrZXksIFtdKTtcbiAgY29uc3Qgb3JpZ2luYWxSZXNvbHZlID0gcmVzb2x2ZTtcbiAgbGV0IGlzUmVzb2x2ZWQ7XG4gIGxldCBzdG9wT25TbmFwc2hvdCA9IG5vb3A7XG4gIGNvbnN0IGFycmF5U3VicyA9IFtdO1xuICBjb25zdCBjaGFuZ2UgPSB7XG4gICAgYWRkZWQ6ICh7IG5ld0luZGV4LCBkb2MgfSkgPT4ge1xuICAgICAgYXJyYXlTdWJzLnNwbGljZShuZXdJbmRleCwgMCwgLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCkpO1xuICAgICAgY29uc3Qgc3VicyA9IGFycmF5U3Vic1tuZXdJbmRleF07XG4gICAgICBjb25zdCBbZGF0YSwgcmVmc10gPSBleHRyYWN0UmVmcyhcbiAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvcjogRklYTUU6IHdyb25nIGNhc3QsIG5lZWRzIGJldHRlciB0eXBlc1xuICAgICAgICBkb2MuZGF0YShzbmFwc2hvdE9wdGlvbnMpLFxuICAgICAgICB2b2lkIDAsXG4gICAgICAgIHN1YnMsXG4gICAgICAgIG9wdGlvbnNcbiAgICAgICk7XG4gICAgICBvcHMuYWRkKHRvVmFsdWUoYXJyYXlSZWYpLCBuZXdJbmRleCwgZGF0YSk7XG4gICAgICBzdWJzY3JpYmVUb1JlZnMoXG4gICAgICAgIG9wdGlvbnMsXG4gICAgICAgIGFycmF5UmVmLFxuICAgICAgICBgJHtrZXl9LiR7bmV3SW5kZXh9YCxcbiAgICAgICAgc3VicyxcbiAgICAgICAgcmVmcyxcbiAgICAgICAgb3BzLFxuICAgICAgICAwLFxuICAgICAgICByZXNvbHZlLmJpbmQobnVsbCwgZG9jKSxcbiAgICAgICAgcmVqZWN0XG4gICAgICApO1xuICAgIH0sXG4gICAgbW9kaWZpZWQ6ICh7IG9sZEluZGV4LCBuZXdJbmRleCwgZG9jIH0pID0+IHtcbiAgICAgIGNvbnN0IGFycmF5ID0gdG9WYWx1ZShhcnJheVJlZik7XG4gICAgICBjb25zdCBzdWJzID0gYXJyYXlTdWJzW29sZEluZGV4XTtcbiAgICAgIGNvbnN0IG9sZERhdGEgPSBhcnJheVtvbGRJbmRleF07XG4gICAgICBjb25zdCBbZGF0YSwgcmVmc10gPSBleHRyYWN0UmVmcyhcbiAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvcjogRklYTUU6IEJldHRlciB0eXBlc1xuICAgICAgICBkb2MuZGF0YShzbmFwc2hvdE9wdGlvbnMpLFxuICAgICAgICBvbGREYXRhLFxuICAgICAgICBzdWJzLFxuICAgICAgICBvcHRpb25zXG4gICAgICApO1xuICAgICAgYXJyYXlTdWJzLnNwbGljZShuZXdJbmRleCwgMCwgc3Vicyk7XG4gICAgICBvcHMucmVtb3ZlKGFycmF5LCBvbGRJbmRleCk7XG4gICAgICBvcHMuYWRkKGFycmF5LCBuZXdJbmRleCwgZGF0YSk7XG4gICAgICBzdWJzY3JpYmVUb1JlZnMoXG4gICAgICAgIG9wdGlvbnMsXG4gICAgICAgIGFycmF5UmVmLFxuICAgICAgICBgJHtrZXl9LiR7bmV3SW5kZXh9YCxcbiAgICAgICAgc3VicyxcbiAgICAgICAgcmVmcyxcbiAgICAgICAgb3BzLFxuICAgICAgICAwLFxuICAgICAgICByZXNvbHZlLFxuICAgICAgICByZWplY3RcbiAgICAgICk7XG4gICAgfSxcbiAgICByZW1vdmVkOiAoeyBvbGRJbmRleCB9KSA9PiB7XG4gICAgICBjb25zdCBhcnJheSA9IHRvVmFsdWUoYXJyYXlSZWYpO1xuICAgICAgb3BzLnJlbW92ZShhcnJheSwgb2xkSW5kZXgpO1xuICAgICAgdW5zdWJzY3JpYmVBbGwoYXJyYXlTdWJzLnNwbGljZShvbGRJbmRleCwgMSlbMF0pO1xuICAgIH1cbiAgfTtcbiAgZnVuY3Rpb24gb25TbmFwc2hvdENhbGxiYWNrKHNuYXBzaG90KSB7XG4gICAgY29uc3QgZG9jQ2hhbmdlcyA9IHNuYXBzaG90LmRvY0NoYW5nZXMoc25hcHNob3RMaXN0ZW5PcHRpb25zKTtcbiAgICBpZiAoIWlzUmVzb2x2ZWQgJiYgZG9jQ2hhbmdlcy5sZW5ndGgpIHtcbiAgICAgIGlzUmVzb2x2ZWQgPSB0cnVlO1xuICAgICAgbGV0IGNvdW50ID0gMDtcbiAgICAgIGNvbnN0IGV4cGVjdGVkSXRlbXMgPSBkb2NDaGFuZ2VzLmxlbmd0aDtcbiAgICAgIGNvbnN0IHZhbGlkRG9jcyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBleHBlY3RlZEl0ZW1zOyBpKyspIHtcbiAgICAgICAgdmFsaWREb2NzW2RvY0NoYW5nZXNbaV0uZG9jLmlkXSA9IHRydWU7XG4gICAgICB9XG4gICAgICByZXNvbHZlID0gKGRhdGEpID0+IHtcbiAgICAgICAgaWYgKGRhdGEgJiYgZGF0YS5pZCBpbiB2YWxpZERvY3MpIHtcbiAgICAgICAgICBpZiAoKytjb3VudCA+PSBleHBlY3RlZEl0ZW1zKSB7XG4gICAgICAgICAgICBpZiAod2FpdCkge1xuICAgICAgICAgICAgICBvcHMuc2V0KHRhcmdldCwga2V5LCB0b1ZhbHVlKGFycmF5UmVmKSk7XG4gICAgICAgICAgICAgIGFycmF5UmVmID0gdGFyZ2V0O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgb3JpZ2luYWxSZXNvbHZlKHRvVmFsdWUoYXJyYXlSZWYpKTtcbiAgICAgICAgICAgIHJlc29sdmUgPSBub29wO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9XG4gICAgZG9jQ2hhbmdlcy5mb3JFYWNoKChjKSA9PiB7XG4gICAgICBjaGFuZ2VbYy50eXBlXShjKTtcbiAgICB9KTtcbiAgICBpZiAoIWRvY0NoYW5nZXMubGVuZ3RoKSB7XG4gICAgICBpZiAod2FpdCkge1xuICAgICAgICBvcHMuc2V0KHRhcmdldCwga2V5LCB0b1ZhbHVlKGFycmF5UmVmKSk7XG4gICAgICAgIGFycmF5UmVmID0gdGFyZ2V0O1xuICAgICAgfVxuICAgICAgcmVzb2x2ZSh0b1ZhbHVlKGFycmF5UmVmKSk7XG4gICAgfVxuICB9XG4gIGlmIChvbmNlKSB7XG4gICAgZ2V0RG9jcyhjb2xsZWN0aW9uKS50aGVuKG9uU25hcHNob3RDYWxsYmFjaykuY2F0Y2gocmVqZWN0KTtcbiAgfSBlbHNlIHtcbiAgICBzdG9wT25TbmFwc2hvdCA9IG9uU25hcHNob3QoY29sbGVjdGlvbiwgb25TbmFwc2hvdENhbGxiYWNrLCByZWplY3QpO1xuICB9XG4gIHJldHVybiAocmVzZXQpID0+IHtcbiAgICBzdG9wT25TbmFwc2hvdCgpO1xuICAgIGlmIChyZXNldCkge1xuICAgICAgY29uc3QgdmFsdWUgPSB0eXBlb2YgcmVzZXQgPT09IFwiZnVuY3Rpb25cIiA/IHJlc2V0KCkgOiBbXTtcbiAgICAgIG9wcy5zZXQodGFyZ2V0LCBrZXksIHZhbHVlKTtcbiAgICB9XG4gICAgYXJyYXlTdWJzLmZvckVhY2godW5zdWJzY3JpYmVBbGwpO1xuICB9O1xufVxuZnVuY3Rpb24gYmluZERvY3VtZW50KHRhcmdldCwgZG9jdW1lbnQsIG9wcywgcmVzb2x2ZSwgcmVqZWN0LCBleHRyYU9wdGlvbnMpIHtcbiAgY29uc3Qgb3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oe30sIERFRkFVTFRfT1BUSU9OUywgZXh0cmFPcHRpb25zKTtcbiAgY29uc3Qga2V5ID0gXCJ2YWx1ZVwiO1xuICBjb25zdCBzdWJzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIHJlc29sdmUgPSBjYWxsT25jZVdpdGhBcmcocmVzb2x2ZSwgKCkgPT4gd2Fsa0dldCh0YXJnZXQsIGtleSkpO1xuICBsZXQgc3RvcE9uU25hcHNob3QgPSBub29wO1xuICBmdW5jdGlvbiBvblNuYXBzaG90Q2FsbGJhY2soc25hcHNob3QpIHtcbiAgICBpZiAoc25hcHNob3QuZXhpc3RzKCkpIHtcbiAgICAgIHVwZGF0ZURhdGFGcm9tRG9jdW1lbnRTbmFwc2hvdChcbiAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgdGFyZ2V0LFxuICAgICAgICBrZXksXG4gICAgICAgIHNuYXBzaG90LFxuICAgICAgICBzdWJzLFxuICAgICAgICBvcHMsXG4gICAgICAgIDAsXG4gICAgICAgIHJlc29sdmUsXG4gICAgICAgIHJlamVjdFxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgb3BzLnNldCh0YXJnZXQsIGtleSwgbnVsbCk7XG4gICAgICByZXNvbHZlKG51bGwpO1xuICAgIH1cbiAgfVxuICBpZiAob3B0aW9ucy5vbmNlKSB7XG4gICAgZ2V0RG9jKGRvY3VtZW50KS50aGVuKG9uU25hcHNob3RDYWxsYmFjaykuY2F0Y2gocmVqZWN0KTtcbiAgfSBlbHNlIHtcbiAgICBzdG9wT25TbmFwc2hvdCA9IG9uU25hcHNob3QoZG9jdW1lbnQsIG9uU25hcHNob3RDYWxsYmFjaywgcmVqZWN0KTtcbiAgfVxuICByZXR1cm4gKHJlc2V0KSA9PiB7XG4gICAgc3RvcE9uU25hcHNob3QoKTtcbiAgICBpZiAocmVzZXQpIHtcbiAgICAgIGNvbnN0IHZhbHVlID0gdHlwZW9mIHJlc2V0ID09PSBcImZ1bmN0aW9uXCIgPyByZXNldCgpIDogbnVsbDtcbiAgICAgIG9wcy5zZXQodGFyZ2V0LCBrZXksIHZhbHVlKTtcbiAgICB9XG4gICAgdW5zdWJzY3JpYmVBbGwoc3Vicyk7XG4gIH07XG59XG5cbmNvbnN0IE5PX0lOSVRJQUxfVkFMVUUgPSBTeW1ib2woKTtcbmZ1bmN0aW9uIF91c2VGaXJlc3RvcmVSZWYoZG9jT3JDb2xsZWN0aW9uUmVmLCBsb2NhbE9wdGlvbnMpIHtcbiAgbGV0IHVuYmluZCA9IG5vb3A7XG4gIGNvbnN0IG9wdGlvbnMgPSBPYmplY3QuYXNzaWduKHt9LCBERUZBVUxUX09QVElPTlMsIGxvY2FsT3B0aW9ucyk7XG4gIGNvbnN0IGluaXRpYWxTb3VyY2VWYWx1ZSA9IHRvVmFsdWUoZG9jT3JDb2xsZWN0aW9uUmVmKTtcbiAgY29uc3QgZGF0YSA9IG9wdGlvbnMudGFyZ2V0IHx8IHJlZigpO1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgaWYgKG9wdGlvbnMudGFyZ2V0ICYmIGNoZWNrV3JpdHRlblRhcmdldChkYXRhLCBcInVzZURvY3VtZW50KCkvdXNlQ29sbGVjdGlvbigpXCIpKSB7XG4gICAgICByZXR1cm4gZGF0YTtcbiAgICB9XG4gIH1cbiAgaWYgKHVzZUlzU1NSKCkpIHtcbiAgICBvcHRpb25zLm9uY2UgPSB0cnVlO1xuICB9XG4gIGNvbnN0IGluaXRpYWxWYWx1ZSA9IGdldEluaXRpYWxWYWx1ZShcbiAgICBpbml0aWFsU291cmNlVmFsdWUsXG4gICAgb3B0aW9ucy5zc3JLZXksXG4gICAgTk9fSU5JVElBTF9WQUxVRSxcbiAgICB1c2VGaXJlYmFzZUFwcCgpXG4gICk7XG4gIGNvbnN0IGhhc0luaXRpYWxWYWx1ZSA9IGluaXRpYWxWYWx1ZSAhPT0gTk9fSU5JVElBTF9WQUxVRTtcbiAgaWYgKGhhc0luaXRpYWxWYWx1ZSkge1xuICAgIGRhdGEudmFsdWUgPSBpbml0aWFsVmFsdWU7XG4gIH1cbiAgbGV0IHNob3VsZFN0YXJ0QXNQZW5kaW5nID0gIWhhc0luaXRpYWxWYWx1ZTtcbiAgY29uc3QgcGVuZGluZyA9IHJlZihmYWxzZSk7XG4gIGNvbnN0IGVycm9yID0gcmVmKCk7XG4gIGNvbnN0IHByb21pc2UgPSBzaGFsbG93UmVmKCk7XG4gIGNvbnN0IGhhc0N1cnJlbnRTY29wZSA9IGdldEN1cnJlbnRTY29wZSgpO1xuICBsZXQgcmVtb3ZlUGVuZGluZ1Byb21pc2UgPSBub29wO1xuICBmdW5jdGlvbiBiaW5kRmlyZXN0b3JlUmVmKCkge1xuICAgIGxldCBkb2NSZWZWYWx1ZSA9IHRvVmFsdWUoZG9jT3JDb2xsZWN0aW9uUmVmKTtcbiAgICBjb25zdCBuZXdQcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdW5iaW5kKG9wdGlvbnMucmVzZXQpO1xuICAgICAgaWYgKCFkb2NSZWZWYWx1ZSkge1xuICAgICAgICB1bmJpbmQgPSBub29wO1xuICAgICAgICByZXR1cm4gcmVzb2x2ZShudWxsKTtcbiAgICAgIH1cbiAgICAgIHBlbmRpbmcudmFsdWUgPSBzaG91bGRTdGFydEFzUGVuZGluZztcbiAgICAgIHNob3VsZFN0YXJ0QXNQZW5kaW5nID0gdHJ1ZTtcbiAgICAgIGlmICghZG9jUmVmVmFsdWUuY29udmVydGVyKSB7XG4gICAgICAgIGRvY1JlZlZhbHVlID0gZG9jUmVmVmFsdWUud2l0aENvbnZlcnRlcihcbiAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yOiBzZWVtcyBsaWtlIGEgdHMgZXJyb3JcbiAgICAgICAgICBvcHRpb25zLmNvbnZlcnRlclxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgdW5iaW5kID0gKGlzRG9jdW1lbnRSZWYoZG9jUmVmVmFsdWUpID8gYmluZERvY3VtZW50IDogYmluZENvbGxlY3Rpb24pKFxuICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yOiBjYW5ub3QgdHlwZSB3aXRoIHRoZSB0ZXJuYXJ5XG4gICAgICAgIGRhdGEsXG4gICAgICAgIGRvY1JlZlZhbHVlLFxuICAgICAgICBvcHMsXG4gICAgICAgIHJlc29sdmUsXG4gICAgICAgIHJlamVjdCxcbiAgICAgICAgb3B0aW9uc1xuICAgICAgKTtcbiAgICB9KS5jYXRjaCgocmVhc29uKSA9PiB7XG4gICAgICBpZiAocHJvbWlzZS52YWx1ZSA9PT0gbmV3UHJvbWlzZSkge1xuICAgICAgICBlcnJvci52YWx1ZSA9IHJlYXNvbjtcbiAgICAgIH1cbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChyZWFzb24pO1xuICAgIH0pLmZpbmFsbHkoKCkgPT4ge1xuICAgICAgaWYgKHByb21pc2UudmFsdWUgPT09IG5ld1Byb21pc2UpIHtcbiAgICAgICAgcGVuZGluZy52YWx1ZSA9IGZhbHNlO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHByb21pc2UudmFsdWUgPSBuZXdQcm9taXNlO1xuICB9XG4gIGxldCBzdG9wV2F0Y2hlciA9IG5vb3A7XG4gIGlmIChpc1JlZihkb2NPckNvbGxlY3Rpb25SZWYpIHx8IHR5cGVvZiBkb2NPckNvbGxlY3Rpb25SZWYgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIHN0b3BXYXRjaGVyID0gd2F0Y2goZG9jT3JDb2xsZWN0aW9uUmVmLCBiaW5kRmlyZXN0b3JlUmVmKTtcbiAgfVxuICBiaW5kRmlyZXN0b3JlUmVmKCk7XG4gIGlmIChpbml0aWFsU291cmNlVmFsdWUpIHtcbiAgICByZW1vdmVQZW5kaW5nUHJvbWlzZSA9IGFkZFBlbmRpbmdQcm9taXNlKFxuICAgICAgcHJvbWlzZS52YWx1ZSxcbiAgICAgIGluaXRpYWxTb3VyY2VWYWx1ZSxcbiAgICAgIG9wdGlvbnMuc3NyS2V5XG4gICAgKTtcbiAgfVxuICBpZiAoZ2V0Q3VycmVudEluc3RhbmNlKCkpIHtcbiAgICBvblNlcnZlclByZWZldGNoKCgpID0+IHByb21pc2UudmFsdWUpO1xuICB9XG4gIGlmIChoYXNDdXJyZW50U2NvcGUpIHtcbiAgICBvblNjb3BlRGlzcG9zZShzdG9wKTtcbiAgfVxuICBmdW5jdGlvbiBzdG9wKHJlc2V0ID0gb3B0aW9ucy5yZXNldCkge1xuICAgIHN0b3BXYXRjaGVyKCk7XG4gICAgcmVtb3ZlUGVuZGluZ1Byb21pc2UoKTtcbiAgICB1bmJpbmQocmVzZXQpO1xuICB9XG4gIHJldHVybiBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhkYXRhLCB7XG4gICAgZXJyb3I6IHsgZ2V0OiAoKSA9PiBlcnJvciB9LFxuICAgIGRhdGE6IHsgZ2V0OiAoKSA9PiBkYXRhIH0sXG4gICAgcGVuZGluZzogeyBnZXQ6ICgpID0+IHBlbmRpbmcgfSxcbiAgICBwcm9taXNlOiB7IGdldDogKCkgPT4gcHJvbWlzZSB9LFxuICAgIHN0b3A6IHsgZ2V0OiAoKSA9PiBzdG9wIH1cbiAgfSk7XG59XG5jb25zdCBvcHMgPSB7XG4gIHNldDogKHRhcmdldCwga2V5LCB2YWx1ZSkgPT4gd2Fsa1NldCh0YXJnZXQsIGtleSwgdmFsdWUpLFxuICBhZGQ6IChhcnJheSwgaW5kZXgsIGRhdGEpID0+IGFycmF5LnNwbGljZShpbmRleCwgMCwgZGF0YSksXG4gIHJlbW92ZTogKGFycmF5LCBpbmRleCkgPT4gYXJyYXkuc3BsaWNlKGluZGV4LCAxKVxufTtcblxuZnVuY3Rpb24gdXNlQ29sbGVjdGlvbihjb2xsZWN0aW9uUmVmLCBvcHRpb25zKSB7XG4gIHJldHVybiBfdXNlRmlyZXN0b3JlUmVmKGNvbGxlY3Rpb25SZWYsIHtcbiAgICB0YXJnZXQ6IHJlZihbXSksXG4gICAgLi4ub3B0aW9uc1xuICB9KTtcbn1cbmZ1bmN0aW9uIHVzZURvY3VtZW50KGRvY3VtZW50UmVmLCBvcHRpb25zKSB7XG4gIHJldHVybiBfdXNlRmlyZXN0b3JlUmVmKGRvY3VtZW50UmVmLCBvcHRpb25zKTtcbn1cbmZ1bmN0aW9uIHVzZUZpcmVzdG9yZShuYW1lKSB7XG4gIHJldHVybiBnZXRGaXJlc3RvcmUodXNlRmlyZWJhc2VBcHAobmFtZSkpO1xufVxuXG5jb25zdCBkYXRhYmFzZVVuYmluZHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbmZ1bmN0aW9uIGludGVybmFsVW5iaW5kJDEoa2V5LCB1bmJpbmRzLCByZXNldCkge1xuICBpZiAodW5iaW5kcyAmJiB1bmJpbmRzW2tleV0pIHtcbiAgICB1bmJpbmRzW2tleV0ocmVzZXQpO1xuICAgIGRlbGV0ZSB1bmJpbmRzW2tleV07XG4gIH1cbn1cblxuY29uc3QgZGF0YWJhc2VQbHVnaW5EZWZhdWx0cyA9IHtcbiAgYmluZE5hbWU6IFwiJGRhdGFiYXNlQmluZFwiLFxuICB1bmJpbmROYW1lOiBcIiRkYXRhYmFzZVVuYmluZFwiXG59O1xuZnVuY3Rpb24gZGF0YWJhc2VQbHVnaW4oYXBwLCBwbHVnaW5PcHRpb25zLCBmaXJlYmFzZUFwcCkge1xuICBjb25zdCBnbG9iYWxPcHRpb25zID0gT2JqZWN0LmFzc2lnbih7fSwgZGF0YWJhc2VQbHVnaW5EZWZhdWx0cywgcGx1Z2luT3B0aW9ucyk7XG4gIGNvbnN0IHsgYmluZE5hbWUsIHVuYmluZE5hbWUgfSA9IGdsb2JhbE9wdGlvbnM7XG4gIGNvbnN0IEdsb2JhbFRhcmdldCA9IGlzVnVlMyA/IGFwcC5jb25maWcuZ2xvYmFsUHJvcGVydGllcyA6IGFwcC5wcm90b3R5cGU7XG4gIEdsb2JhbFRhcmdldFt1bmJpbmROYW1lXSA9IGZ1bmN0aW9uIGRhdGFiYXNlVW5iaW5kKGtleSwgcmVzZXQpIHtcbiAgICBpbnRlcm5hbFVuYmluZCQxKGtleSwgZGF0YWJhc2VVbmJpbmRzLmdldCh0aGlzKSwgcmVzZXQpO1xuICAgIGRlbGV0ZSB0aGlzLiRmaXJlYmFzZVJlZnNba2V5XTtcbiAgfTtcbiAgR2xvYmFsVGFyZ2V0W2JpbmROYW1lXSA9IGZ1bmN0aW9uIGRhdGFiYXNlQmluZChrZXksIHNvdXJjZSwgdXNlck9wdGlvbnMpIHtcbiAgICBjb25zdCBvcHRpb25zID0gT2JqZWN0LmFzc2lnbih7fSwgZ2xvYmFsT3B0aW9ucywgdXNlck9wdGlvbnMpO1xuICAgIGNvbnN0IHRhcmdldCA9IHRvUmVmKHRoaXMuJGRhdGEsIGtleSk7XG4gICAgaWYgKCFkYXRhYmFzZVVuYmluZHMuaGFzKHRoaXMpKSB7XG4gICAgICBkYXRhYmFzZVVuYmluZHMuc2V0KHRoaXMsIHt9KTtcbiAgICB9XG4gICAgY29uc3QgdW5iaW5kcyA9IGRhdGFiYXNlVW5iaW5kcy5nZXQodGhpcyk7XG4gICAgaWYgKHVuYmluZHNba2V5XSkge1xuICAgICAgdW5iaW5kc1trZXldKG9wdGlvbnMucmVzZXQpO1xuICAgIH1cbiAgICBpZiAocGx1Z2luT3B0aW9ucykge1xuICAgICAgaWYgKCFwbHVnaW5PcHRpb25zLmJpbmROYW1lKSB7XG4gICAgICAgIEdsb2JhbFRhcmdldFtcIiRydGRiQmluZFwiXSA9IEdsb2JhbFRhcmdldFtiaW5kTmFtZV07XG4gICAgICB9XG4gICAgICBpZiAoIXBsdWdpbk9wdGlvbnMudW5iaW5kTmFtZSkge1xuICAgICAgICBHbG9iYWxUYXJnZXRbXCIkcnRkYlVuYmluZFwiXSA9IEdsb2JhbFRhcmdldFt1bmJpbmROYW1lXTtcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3Qgc2NvcGUgPSBnZXRHbG9iYWxTY29wZShmaXJlYmFzZUFwcCB8fCB1c2VGaXJlYmFzZUFwcCgpLCBhcHApLnJ1bihcbiAgICAgICgpID0+IGVmZmVjdFNjb3BlKClcbiAgICApO1xuICAgIGNvbnN0IHsgcHJvbWlzZSwgc3RvcDogX3VuYmluZCB9ID0gYXBwLnJ1bldpdGhDb250ZXh0KFxuICAgICAgKCkgPT4gc2NvcGUucnVuKCgpID0+IF91c2VEYXRhYmFzZVJlZihzb3VyY2UsIHsgdGFyZ2V0LCAuLi5vcHRpb25zIH0pKVxuICAgICk7XG4gICAgY29uc3QgdW5iaW5kID0gKHJlc2V0KSA9PiB7XG4gICAgICBfdW5iaW5kKHJlc2V0KTtcbiAgICAgIHNjb3BlLnN0b3AoKTtcbiAgICB9O1xuICAgIHVuYmluZHNba2V5XSA9IHVuYmluZDtcbiAgICB0aGlzLiRmaXJlYmFzZVJlZnNba2V5XSA9IHNvdXJjZS5yZWY7XG4gICAgcmV0dXJuIHByb21pc2UudmFsdWU7XG4gIH07XG4gIGFwcC5taXhpbih7XG4gICAgYmVmb3JlQ3JlYXRlKCkge1xuICAgICAgdGhpcy4kZmlyZWJhc2VSZWZzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgfSxcbiAgICBjcmVhdGVkKCkge1xuICAgICAgbGV0IGJpbmRpbmdzID0gdGhpcy4kb3B0aW9ucy5maXJlYmFzZTtcbiAgICAgIGlmICh0eXBlb2YgYmluZGluZ3MgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICBiaW5kaW5ncyA9IGJpbmRpbmdzLmNhbGwodGhpcyk7XG4gICAgICB9XG4gICAgICBpZiAoIWJpbmRpbmdzKVxuICAgICAgICByZXR1cm47XG4gICAgICBmb3IgKGNvbnN0IGtleSBpbiBiaW5kaW5ncykge1xuICAgICAgICB0aGlzW2JpbmROYW1lXShcbiAgICAgICAgICAvLyB0c1xuICAgICAgICAgIGtleSxcbiAgICAgICAgICBiaW5kaW5nc1trZXldLFxuICAgICAgICAgIGdsb2JhbE9wdGlvbnNcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGJlZm9yZVVubW91bnQoKSB7XG4gICAgICBjb25zdCB1bmJpbmRzID0gZGF0YWJhc2VVbmJpbmRzLmdldCh0aGlzKTtcbiAgICAgIGlmICh1bmJpbmRzKSB7XG4gICAgICAgIGZvciAoY29uc3Qga2V5IGluIHVuYmluZHMpIHtcbiAgICAgICAgICB1bmJpbmRzW2tleV0oKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhpcy4kZmlyZWJhc2VSZWZzID0gbnVsbDtcbiAgICB9XG4gIH0pO1xufVxuZnVuY3Rpb24gVnVlRmlyZURhdGFiYXNlT3B0aW9uc0FQSShwbHVnaW5PcHRpb25zKSB7XG4gIHJldHVybiAoZmlyZWJhc2VBcHAsIGFwcCkgPT4ge1xuICAgIHJldHVybiBkYXRhYmFzZVBsdWdpbihhcHAsIHBsdWdpbk9wdGlvbnMsIGZpcmViYXNlQXBwKTtcbiAgfTtcbn1cblxuY29uc3QgZmlyZXN0b3JlVW5iaW5kcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuZnVuY3Rpb24gaW50ZXJuYWxVbmJpbmQoa2V5LCB1bmJpbmRzLCByZXNldCkge1xuICBpZiAodW5iaW5kcyAmJiB1bmJpbmRzW2tleV0pIHtcbiAgICB1bmJpbmRzW2tleV0ocmVzZXQpO1xuICAgIGRlbGV0ZSB1bmJpbmRzW2tleV07XG4gIH1cbn1cblxuY29uc3QgZmlyZXN0b3JlUGx1Z2luRGVmYXVsdHMgPSB7XG4gIGJpbmROYW1lOiBcIiRmaXJlc3RvcmVCaW5kXCIsXG4gIHVuYmluZE5hbWU6IFwiJGZpcmVzdG9yZVVuYmluZFwiXG59O1xuY29uc3QgZmlyZXN0b3JlUGx1Z2luID0gZnVuY3Rpb24gZmlyZXN0b3JlUGx1Z2luMihhcHAsIHBsdWdpbk9wdGlvbnMsIGZpcmViYXNlQXBwKSB7XG4gIGNvbnN0IGdsb2JhbE9wdGlvbnMgPSBPYmplY3QuYXNzaWduKFxuICAgIHt9LFxuICAgIGZpcmVzdG9yZVBsdWdpbkRlZmF1bHRzLFxuICAgIHBsdWdpbk9wdGlvbnNcbiAgKTtcbiAgY29uc3QgeyBiaW5kTmFtZSwgdW5iaW5kTmFtZSB9ID0gZ2xvYmFsT3B0aW9ucztcbiAgY29uc3QgR2xvYmFsVGFyZ2V0ID0gaXNWdWUzID8gYXBwLmNvbmZpZy5nbG9iYWxQcm9wZXJ0aWVzIDogYXBwLnByb3RvdHlwZTtcbiAgR2xvYmFsVGFyZ2V0W3VuYmluZE5hbWVdID0gZnVuY3Rpb24gZmlyZXN0b3JlVW5iaW5kKGtleSwgcmVzZXQpIHtcbiAgICBpbnRlcm5hbFVuYmluZChrZXksIGZpcmVzdG9yZVVuYmluZHMuZ2V0KHRoaXMpLCByZXNldCk7XG4gICAgZGVsZXRlIHRoaXMuJGZpcmVzdG9yZVJlZnNba2V5XTtcbiAgfTtcbiAgR2xvYmFsVGFyZ2V0W2JpbmROYW1lXSA9IGZ1bmN0aW9uIGZpcmVzdG9yZUJpbmQoa2V5LCBkb2NPckNvbGxlY3Rpb25SZWYsIHVzZXJPcHRpb25zKSB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oe30sIGdsb2JhbE9wdGlvbnMsIHVzZXJPcHRpb25zKTtcbiAgICBjb25zdCB0YXJnZXQgPSB0b1JlZih0aGlzLiRkYXRhLCBrZXkpO1xuICAgIGlmICghZmlyZXN0b3JlVW5iaW5kcy5oYXModGhpcykpIHtcbiAgICAgIGZpcmVzdG9yZVVuYmluZHMuc2V0KHRoaXMsIHt9KTtcbiAgICB9XG4gICAgY29uc3QgdW5iaW5kcyA9IGZpcmVzdG9yZVVuYmluZHMuZ2V0KHRoaXMpO1xuICAgIGlmICh1bmJpbmRzW2tleV0pIHtcbiAgICAgIHVuYmluZHNba2V5XShvcHRpb25zLnJlc2V0KTtcbiAgICB9XG4gICAgY29uc3Qgc2NvcGUgPSBnZXRHbG9iYWxTY29wZShmaXJlYmFzZUFwcCB8fCB1c2VGaXJlYmFzZUFwcCgpLCBhcHApLnJ1bihcbiAgICAgICgpID0+IGVmZmVjdFNjb3BlKClcbiAgICApO1xuICAgIGNvbnN0IHsgcHJvbWlzZSwgc3RvcDogX3VuYmluZCB9ID0gYXBwLnJ1bldpdGhDb250ZXh0KFxuICAgICAgKCkgPT4gc2NvcGUucnVuKFxuICAgICAgICAoKSA9PiBfdXNlRmlyZXN0b3JlUmVmKGRvY09yQ29sbGVjdGlvblJlZiwge1xuICAgICAgICAgIHRhcmdldCxcbiAgICAgICAgICAuLi5vcHRpb25zXG4gICAgICAgIH0pXG4gICAgICApXG4gICAgKTtcbiAgICBjb25zdCB1bmJpbmQgPSAocmVzZXQpID0+IHtcbiAgICAgIF91bmJpbmQocmVzZXQpO1xuICAgICAgc2NvcGUuc3RvcCgpO1xuICAgIH07XG4gICAgdW5iaW5kc1trZXldID0gdW5iaW5kO1xuICAgIHRoaXMuJGZpcmVzdG9yZVJlZnNba2V5XSA9IC8vIHRzXG4gICAgZG9jT3JDb2xsZWN0aW9uUmVmO1xuICAgIHJldHVybiBwcm9taXNlLnZhbHVlO1xuICB9O1xuICBhcHAubWl4aW4oe1xuICAgIGJlZm9yZUNyZWF0ZSgpIHtcbiAgICAgIHRoaXMuJGZpcmVzdG9yZVJlZnMgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICB9LFxuICAgIGNyZWF0ZWQoKSB7XG4gICAgICBjb25zdCB7IGZpcmVzdG9yZSB9ID0gdGhpcy4kb3B0aW9ucztcbiAgICAgIGNvbnN0IHJlZnMgPSB0eXBlb2YgZmlyZXN0b3JlID09PSBcImZ1bmN0aW9uXCIgPyBmaXJlc3RvcmUuY2FsbCh0aGlzKSA6IGZpcmVzdG9yZTtcbiAgICAgIGlmICghcmVmcylcbiAgICAgICAgcmV0dXJuO1xuICAgICAgZm9yIChjb25zdCBrZXkgaW4gcmVmcykge1xuICAgICAgICB0aGlzW2JpbmROYW1lXShcbiAgICAgICAgICBrZXksXG4gICAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvcjogRklYTUU6IHRoZXJlIGlzIHByb2JhYmx5IGEgd3JvbmcgdHlwZSBpbiBnbG9iYWwgcHJvcGVydGllc1xuICAgICAgICAgIHJlZnNba2V5XSxcbiAgICAgICAgICBnbG9iYWxPcHRpb25zXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfSxcbiAgICBiZWZvcmVVbm1vdW50KCkge1xuICAgICAgY29uc3QgdW5iaW5kcyA9IGZpcmVzdG9yZVVuYmluZHMuZ2V0KHRoaXMpO1xuICAgICAgaWYgKHVuYmluZHMpIHtcbiAgICAgICAgZm9yIChjb25zdCBzdWJLZXkgaW4gdW5iaW5kcykge1xuICAgICAgICAgIHVuYmluZHNbc3ViS2V5XSgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLiRmaXJlc3RvcmVSZWZzID0gbnVsbDtcbiAgICB9XG4gIH0pO1xufTtcbmZ1bmN0aW9uIFZ1ZUZpcmVGaXJlc3RvcmVPcHRpb25zQVBJKHBsdWdpbk9wdGlvbnMpIHtcbiAgcmV0dXJuIChmaXJlYmFzZUFwcCwgYXBwKSA9PiB7XG4gICAgcmV0dXJuIGZpcmVzdG9yZVBsdWdpbihhcHAsIHBsdWdpbk9wdGlvbnMsIGZpcmViYXNlQXBwKTtcbiAgfTtcbn1cblxuZnVuY3Rpb24gVnVlRmlyZUF1dGgoaW5pdGlhbFVzZXIpIHtcbiAgcmV0dXJuIFZ1ZUZpcmVBdXRoV2l0aERlcGVuZGVuY2llcyh7XG4gICAgaW5pdGlhbFVzZXIsXG4gICAgZGVwZW5kZW5jaWVzOiB7XG4gICAgICBwb3B1cFJlZGlyZWN0UmVzb2x2ZXI6IGJyb3dzZXJQb3B1cFJlZGlyZWN0UmVzb2x2ZXIsXG4gICAgICBwZXJzaXN0ZW5jZTogW1xuICAgICAgICBpbmRleGVkREJMb2NhbFBlcnNpc3RlbmNlLFxuICAgICAgICBicm93c2VyTG9jYWxQZXJzaXN0ZW5jZSxcbiAgICAgICAgYnJvd3NlclNlc3Npb25QZXJzaXN0ZW5jZVxuICAgICAgXVxuICAgIH1cbiAgfSk7XG59XG5jb25zdCBfVnVlRmlyZUF1dGhLZXkgPSBTeW1ib2woXCJWdWVGaXJlQXV0aFwiKTtcbmZ1bmN0aW9uIFZ1ZUZpcmVBdXRoT3B0aW9uc0Zyb21BdXRoKHtcbiAgYXV0aCxcbiAgaW5pdGlhbFVzZXJcbn0pIHtcbiAgcmV0dXJuIChmaXJlYmFzZUFwcCwgYXBwKSA9PiB7XG4gICAgY29uc3QgW3VzZXIsIF9hdXRoXSA9IF9WdWVGaXJlQXV0aEluaXQoXG4gICAgICBmaXJlYmFzZUFwcCxcbiAgICAgIGFwcCxcbiAgICAgIGluaXRpYWxVc2VyLFxuICAgICAgdm9pZCAwLFxuICAgICAgYXV0aFxuICAgICk7XG4gICAgc2V0dXBPbkF1dGhTdGF0ZUNoYW5nZWQodXNlciwgX2F1dGgpO1xuICB9O1xufVxuZnVuY3Rpb24gVnVlRmlyZUF1dGhXaXRoRGVwZW5kZW5jaWVzKHtcbiAgZGVwZW5kZW5jaWVzLFxuICBpbml0aWFsVXNlclxufSkge1xuICByZXR1cm4gKGZpcmViYXNlQXBwLCBhcHApID0+IHtcbiAgICBjb25zdCBbdXNlciwgYXV0aF0gPSBfVnVlRmlyZUF1dGhJbml0KFxuICAgICAgZmlyZWJhc2VBcHAsXG4gICAgICBhcHAsXG4gICAgICBpbml0aWFsVXNlcixcbiAgICAgIGRlcGVuZGVuY2llc1xuICAgICk7XG4gICAgc2V0dXBPbkF1dGhTdGF0ZUNoYW5nZWQodXNlciwgYXV0aCk7XG4gIH07XG59XG5mdW5jdGlvbiBfVnVlRmlyZUF1dGhJbml0KGZpcmViYXNlQXBwLCBhcHAsIGluaXRpYWxVc2VyLCBkZXBlbmRlbmNpZXMsIGF1dGggPSBpbml0aWFsaXplQXV0aChmaXJlYmFzZUFwcCwgZGVwZW5kZW5jaWVzKSkge1xuICBjb25zdCB1c2VyID0gZ2V0R2xvYmFsU2NvcGUoZmlyZWJhc2VBcHAsIGFwcCkucnVuKFxuICAgICgpID0+IHJlZihpbml0aWFsVXNlcilcbiAgKTtcbiAgYXV0aFVzZXJNYXAuc2V0KGZpcmViYXNlQXBwLCB1c2VyKTtcbiAgYXBwLnByb3ZpZGUoX1Z1ZUZpcmVBdXRoS2V5LCBhdXRoKTtcbiAgcmV0dXJuIFt1c2VyLCBhdXRoXTtcbn1cbmZ1bmN0aW9uIHVzZUZpcmViYXNlQXV0aChuYW1lKSB7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgbmFtZSAhPSBudWxsKSB7XG4gICAgY29uc29sZS53YXJuKFxuICAgICAgYFtWdWVGaXJlXSB1c2VGaXJlYmFzZUF1dGgoKSBubyBsb25nZXIgYWNjZXB0cyBhIG5hbWUgcGFyYW1ldGVyIHRvIGVuYWJsZSB0cmVlIHNoYWtpbmcuIElmIHlvdSBoYXZlIG11bHRpcGxlIGFwcGxpY2F0aW9ucywgeW91IG11c3QgdXNlIFwiZ2V0QXV0aChmaXJlYmFzZUFwcClcIiBvciBcImdldEF1dGgodXNlRmlyZWJhc2VBcHAobmFtZSkpXCIgaW5zdGVhZC5gXG4gICAgKTtcbiAgfVxuICByZXR1cm4gaXNDbGllbnQgPyBpbmplY3QoX1Z1ZUZpcmVBdXRoS2V5KSA6IG51bGw7XG59XG5cbmZ1bmN0aW9uIHVzZUZpcmViYXNlU3RvcmFnZShuYW1lKSB7XG4gIHJldHVybiBnZXRTdG9yYWdlKHVzZUZpcmViYXNlQXBwKG5hbWUpKTtcbn1cbmZ1bmN0aW9uIHVzZVN0b3JhZ2VGaWxlVXJsKHN0b3JhZ2VSZWYpIHtcbiAgY29uc3QgaW5pdGlhbFNvdXJjZVZhbHVlID0gdG9WYWx1ZShzdG9yYWdlUmVmKTtcbiAgY29uc3QgdXJsID0gcmVmKCk7XG4gIHVybC52YWx1ZSA9IGdldEluaXRpYWxWYWx1ZShcbiAgICBpbml0aWFsU291cmNlVmFsdWUsXG4gICAgdm9pZCAwLFxuICAgIHVybC52YWx1ZSxcbiAgICB1c2VGaXJlYmFzZUFwcCgpXG4gICk7XG4gIGNvbnN0IHByb21pc2UgPSBzaGFsbG93UmVmKFByb21pc2UucmVzb2x2ZShudWxsKSk7XG4gIGxldCByZW1vdmVQZW5kaW5nUHJvbWlzZSA9IG5vb3A7XG4gIGZ1bmN0aW9uIHJlZnJlc2goKSB7XG4gICAgY29uc3Qgc3RvcmFnZVNvdXJjZSA9IHRvVmFsdWUoc3RvcmFnZVJlZik7XG4gICAgaWYgKHN0b3JhZ2VTb3VyY2UpIHtcbiAgICAgIHByb21pc2UudmFsdWUgPSBnZXREb3dubG9hZFVSTChzdG9yYWdlU291cmNlKS50aGVuKChkb3dubG9hZFVybCkgPT4gdXJsLnZhbHVlID0gZG93bmxvYWRVcmwpLmNhdGNoKCgpID0+IG51bGwpO1xuICAgIH0gZWxzZSB7XG4gICAgICBwcm9taXNlLnZhbHVlID0gUHJvbWlzZS5yZXNvbHZlKHVybC52YWx1ZSA9IG51bGwpO1xuICAgIH1cbiAgICByZXR1cm4gcHJvbWlzZS52YWx1ZTtcbiAgfVxuICByZWZyZXNoKCk7XG4gIGlmIChpc1JlZihzdG9yYWdlUmVmKSB8fCB0eXBlb2Ygc3RvcmFnZVJlZiA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgd2F0Y2goc3RvcmFnZVJlZiwgcmVmcmVzaCk7XG4gIH1cbiAgaWYgKGluaXRpYWxTb3VyY2VWYWx1ZSkge1xuICAgIHJlbW92ZVBlbmRpbmdQcm9taXNlID0gYWRkUGVuZGluZ1Byb21pc2UocHJvbWlzZS52YWx1ZSwgaW5pdGlhbFNvdXJjZVZhbHVlKTtcbiAgfVxuICBpZiAoZ2V0Q3VycmVudFNjb3BlKCkpIHtcbiAgICBvblNjb3BlRGlzcG9zZShyZW1vdmVQZW5kaW5nUHJvbWlzZSk7XG4gIH1cbiAgaWYgKGdldEN1cnJlbnRJbnN0YW5jZSgpKSB7XG4gICAgb25TZXJ2ZXJQcmVmZXRjaCgoKSA9PiBwcm9taXNlLnZhbHVlKTtcbiAgfVxuICByZXR1cm4geyB1cmwsIHJlZnJlc2gsIHByb21pc2UgfTtcbn1cbmZ1bmN0aW9uIHVzZVN0b3JhZ2VGaWxlTWV0YWRhdGEoc3RvcmFnZVJlZikge1xuICBjb25zdCBpbml0aWFsU291cmNlVmFsdWUgPSB0b1ZhbHVlKHN0b3JhZ2VSZWYpO1xuICBjb25zdCBtZXRhZGF0YSA9IHNoYWxsb3dSZWYoKTtcbiAgaWYgKGluaXRpYWxTb3VyY2VWYWx1ZSkge1xuICAgIG1ldGFkYXRhLnZhbHVlID0gZ2V0SW5pdGlhbFZhbHVlKFxuICAgICAgaW5pdGlhbFNvdXJjZVZhbHVlLFxuICAgICAgLy8gJ20gJyBpcyBhIHByZWZpeCB0byBkaWZmZXJlbnRpYXRlIGZyb20gdXJscyBzaW5jZSBib3RoIGFyZSBzdG9yZWQgaW4gdGhlIHNhbWUgb2JqZWN0XG4gICAgICBcIm0gXCIgKyBpbml0aWFsU291cmNlVmFsdWUudG9TdHJpbmcoKSxcbiAgICAgIG1ldGFkYXRhLnZhbHVlLFxuICAgICAgdXNlRmlyZWJhc2VBcHAoKVxuICAgICk7XG4gIH1cbiAgY29uc3QgcHJvbWlzZSA9IHNoYWxsb3dSZWYoXG4gICAgUHJvbWlzZS5yZXNvbHZlKG51bGwpXG4gICk7XG4gIGxldCByZW1vdmVQZW5kaW5nUHJvbWlzZSA9IG5vb3A7XG4gIGZ1bmN0aW9uIHJlZnJlc2goKSB7XG4gICAgY29uc3Qgc3RvcmFnZVNvdXJjZSA9IHRvVmFsdWUoc3RvcmFnZVJlZik7XG4gICAgaWYgKHN0b3JhZ2VTb3VyY2UpIHtcbiAgICAgIHByb21pc2UudmFsdWUgPSBnZXRNZXRhZGF0YShzdG9yYWdlU291cmNlKS50aGVuKChkYXRhKSA9PiBtZXRhZGF0YS52YWx1ZSA9IGRhdGEpLmNhdGNoKCgpID0+IG51bGwpO1xuICAgIH0gZWxzZSB7XG4gICAgICBwcm9taXNlLnZhbHVlID0gUHJvbWlzZS5yZXNvbHZlKG1ldGFkYXRhLnZhbHVlID0gbnVsbCk7XG4gICAgfVxuICAgIHJldHVybiBwcm9taXNlLnZhbHVlO1xuICB9XG4gIGZ1bmN0aW9uIHVwZGF0ZShuZXdNZXRhZGF0YSkge1xuICAgIGNvbnN0IHN0b3JhZ2VTb3VyY2UgPSB0b1ZhbHVlKHN0b3JhZ2VSZWYpO1xuICAgIGlmIChzdG9yYWdlU291cmNlKSB7XG4gICAgICBwcm9taXNlLnZhbHVlID0gdXBkYXRlTWV0YWRhdGEoc3RvcmFnZVNvdXJjZSwgbmV3TWV0YWRhdGEpLnRoZW4oXG4gICAgICAgIChuZXdEYXRhKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIG1ldGFkYXRhLnZhbHVlID0gbmV3RGF0YTtcbiAgICAgICAgfVxuICAgICAgKTtcbiAgICB9IGVsc2UgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgY29uc29sZS53YXJuKCdbVnVlRmlyZV06IFwidXBkYXRlKClcIiBjYWxsZWQgd2l0aCBubyBzdG9yYWdlIHNvdXJjZS4nKTtcbiAgICB9XG4gICAgcmV0dXJuIHByb21pc2UudmFsdWU7XG4gIH1cbiAgcmVmcmVzaCgpO1xuICBpZiAoaXNSZWYoc3RvcmFnZVJlZikpIHtcbiAgICB3YXRjaChzdG9yYWdlUmVmLCByZWZyZXNoKTtcbiAgfVxuICBpZiAoaW5pdGlhbFNvdXJjZVZhbHVlKSB7XG4gICAgcmVtb3ZlUGVuZGluZ1Byb21pc2UgPSBhZGRQZW5kaW5nUHJvbWlzZShwcm9taXNlLnZhbHVlLCBpbml0aWFsU291cmNlVmFsdWUpO1xuICB9XG4gIGlmIChnZXRDdXJyZW50U2NvcGUoKSkge1xuICAgIG9uU2NvcGVEaXNwb3NlKHJlbW92ZVBlbmRpbmdQcm9taXNlKTtcbiAgfVxuICBpZiAoZ2V0Q3VycmVudEluc3RhbmNlKCkpIHtcbiAgICBvblNlcnZlclByZWZldGNoKCgpID0+IHByb21pc2UudmFsdWUpO1xuICB9XG4gIHJldHVybiB7IG1ldGFkYXRhLCB1cGRhdGUsIHJlZnJlc2gsIHByb21pc2UgfTtcbn1cbmZ1bmN0aW9uIHVzZVN0b3JhZ2VGaWxlKHN0b3JhZ2VSZWYpIHtcbiAgY29uc3QgeyB1cmwsIHJlZnJlc2g6IHJlZnJlc2hVcmwgfSA9IHVzZVN0b3JhZ2VGaWxlVXJsKHN0b3JhZ2VSZWYpO1xuICBjb25zdCB7XG4gICAgbWV0YWRhdGEsXG4gICAgdXBkYXRlOiB1cGRhdGVNZXRhZGF0YTIsXG4gICAgcmVmcmVzaDogcmVmcmVzaE1ldGFkYXRhXG4gIH0gPSB1c2VTdG9yYWdlRmlsZU1ldGFkYXRhKHN0b3JhZ2VSZWYpO1xuICBjb25zdCB1cGxvYWRUYXNrID0gc2hhbGxvd1JlZigpO1xuICBjb25zdCBzbmFwc2hvdCA9IHNoYWxsb3dSZWYoKTtcbiAgY29uc3QgdXBsb2FkRXJyb3IgPSBzaGFsbG93UmVmKCk7XG4gIGNvbnN0IHVwbG9hZFByb2dyZXNzID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIGNvbnN0IHNuYXAgPSB0b1ZhbHVlKHNuYXBzaG90KTtcbiAgICByZXR1cm4gc25hcCA/IHNuYXAuYnl0ZXNUcmFuc2ZlcnJlZCAvIHNuYXAudG90YWxCeXRlcyA6IG51bGw7XG4gIH0pO1xuICBsZXQgdW5zdWIgPSBub29wO1xuICBmdW5jdGlvbiB1cGxvYWQobmV3RGF0YSwgbmV3TWV0YWRhdGEpIHtcbiAgICBjb25zdCBzdG9yYWdlU291cmNlID0gdG9WYWx1ZShzdG9yYWdlUmVmKTtcbiAgICBjb25zdCBjdXJyZW50VGFzayA9IHRvVmFsdWUodXBsb2FkVGFzayk7XG4gICAgaWYgKGN1cnJlbnRUYXNrKSB7XG4gICAgICBjdXJyZW50VGFzay5jYW5jZWwoKTtcbiAgICB9XG4gICAgdXBsb2FkRXJyb3IudmFsdWUgPSBudWxsO1xuICAgIHNuYXBzaG90LnZhbHVlID0gbnVsbDtcbiAgICB1cGxvYWRUYXNrLnZhbHVlID0gbnVsbDtcbiAgICB1cmwudmFsdWUgPSBudWxsO1xuICAgIG1ldGFkYXRhLnZhbHVlID0gbnVsbDtcbiAgICB1bnN1YigpO1xuICAgIGlmIChzdG9yYWdlU291cmNlKSB7XG4gICAgICBjb25zdCBuZXdUYXNrID0gdXBsb2FkQnl0ZXNSZXN1bWFibGUoc3RvcmFnZVNvdXJjZSwgbmV3RGF0YSwgbmV3TWV0YWRhdGEpO1xuICAgICAgdXBsb2FkVGFzay52YWx1ZSA9IG5ld1Rhc2s7XG4gICAgICBzbmFwc2hvdC52YWx1ZSA9IG5ld1Rhc2suc25hcHNob3Q7XG4gICAgICB1bnN1YiA9IG5ld1Rhc2sub24oXCJzdGF0ZV9jaGFuZ2VkXCIsIChuZXdTbmFwc2hvdCkgPT4ge1xuICAgICAgICBzbmFwc2hvdC52YWx1ZSA9IG5ld1NuYXBzaG90O1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gbmV3VGFzay50aGVuKChmaW5hbFNuYXBzaG90KSA9PiB7XG4gICAgICAgIG1ldGFkYXRhLnZhbHVlID0gZmluYWxTbmFwc2hvdC5tZXRhZGF0YTtcbiAgICAgICAgcmVmcmVzaFVybCgpO1xuICAgICAgfSkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICB1cGxvYWRFcnJvci52YWx1ZSA9IGVycjtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycik7XG4gICAgICB9KS5maW5hbGx5KCgpID0+IHtcbiAgICAgICAgdW5zdWIoKTtcbiAgICAgICAgdXBsb2FkVGFzay52YWx1ZSA9IG51bGw7XG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gcmVmcmVzaCgpIHtcbiAgICByZXR1cm4gUHJvbWlzZS5hbGwoW3JlZnJlc2hVcmwoKSwgcmVmcmVzaE1ldGFkYXRhKCldKTtcbiAgfVxuICBpZiAoaXNSZWYoc3RvcmFnZVJlZikgfHwgdHlwZW9mIHN0b3JhZ2VSZWYgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIHdhdGNoKHN0b3JhZ2VSZWYsIChzdG9yYWdlU291cmNlKSA9PiB7XG4gICAgICBpZiAoIXN0b3JhZ2VTb3VyY2UpIHtcbiAgICAgICAgaWYgKHVwbG9hZFRhc2sudmFsdWUpIHtcbiAgICAgICAgICB1bnN1YigpO1xuICAgICAgICAgIHVwbG9hZFRhc2sudmFsdWUuY2FuY2VsKCk7XG4gICAgICAgIH1cbiAgICAgICAgdXBsb2FkVGFzay52YWx1ZSA9IG51bGw7XG4gICAgICAgIHNuYXBzaG90LnZhbHVlID0gbnVsbDtcbiAgICAgIH1cbiAgICAgIHJlZnJlc2goKTtcbiAgICB9KTtcbiAgfVxuICBpZiAoZ2V0Q3VycmVudFNjb3BlKCkpIHtcbiAgICBvblNjb3BlRGlzcG9zZSh1bnN1Yik7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB1cmwsXG4gICAgbWV0YWRhdGEsXG4gICAgc25hcHNob3QsXG4gICAgdXBsb2FkVGFzayxcbiAgICB1cGxvYWRFcnJvcixcbiAgICB1cGxvYWRQcm9ncmVzcyxcbiAgICB1cGxvYWQsXG4gICAgdXBkYXRlTWV0YWRhdGE6IHVwZGF0ZU1ldGFkYXRhMixcbiAgICByZWZyZXNoXG4gICAgLy8gcHJvbWlzZSxcbiAgfTtcbn1cbmNvbnN0IHVzZVN0b3JhZ2UgPSB1c2VGaXJlYmFzZVN0b3JhZ2U7XG5jb25zdCB1c2VTdG9yYWdlVXJsID0gdXNlU3RvcmFnZUZpbGVVcmw7XG5jb25zdCB1c2VTdG9yYWdlTWV0YWRhdGEgPSB1c2VTdG9yYWdlRmlsZU1ldGFkYXRhO1xuY29uc3QgdXNlU3RvcmFnZU9iamVjdCA9IHVzZVN0b3JhZ2VGaWxlO1xuXG5mdW5jdGlvbiBWdWVGaXJlKGFwcCwgeyBmaXJlYmFzZUFwcCwgbW9kdWxlcyA9IFtdIH0pIHtcbiAgYXBwLnByb3ZpZGUoX0ZpcmViYXNlQXBwSW5qZWN0aW9uS2V5LCBmaXJlYmFzZUFwcCk7XG4gIGZvciAoY29uc3QgZmlyZWJhc2VNb2R1bGUgb2YgbW9kdWxlcykge1xuICAgIGZpcmViYXNlTW9kdWxlKGZpcmViYXNlQXBwLCBhcHApO1xuICB9XG59XG5cbmV4cG9ydCB7IFZ1ZUZpcmUsIFZ1ZUZpcmVBdXRoLCBWdWVGaXJlQXV0aE9wdGlvbnNGcm9tQXV0aCwgVnVlRmlyZUF1dGhXaXRoRGVwZW5kZW5jaWVzLCBWdWVGaXJlRGF0YWJhc2VPcHRpb25zQVBJLCBWdWVGaXJlRmlyZXN0b3JlT3B0aW9uc0FQSSwgX1Z1ZUZpcmVBdXRoSW5pdCwgX1Z1ZUZpcmVBdXRoS2V5LCBjcmVhdGVSZWNvcmRGcm9tRGF0YWJhc2VTbmFwc2hvdCBhcyBkYXRhYmFzZURlZmF1bHRTZXJpYWxpemVyLCBkYXRhYmFzZVBsdWdpbiwgZGV2YWx1ZUN1c3RvbVBhcnNlcnMsIGRldmFsdWVDdXN0b21TdHJpbmdpZmllcnMsIGZpcmVzdG9yZURlZmF1bHRDb252ZXJ0ZXIsIGZpcmVzdG9yZVBsdWdpbiwgREVGQVVMVF9PUFRJT05TJDEgYXMgZ2xvYmFsRGF0YWJhc2VPcHRpb25zLCBERUZBVUxUX09QVElPTlMgYXMgZ2xvYmFsRmlyZXN0b3JlT3B0aW9ucywgZGF0YWJhc2VQbHVnaW4gYXMgcnRkYlBsdWdpbiwgdXNlQ29sbGVjdGlvbiwgdXNlRGF0YWJhc2UsIHVzZURhdGFiYXNlTGlzdCwgdXNlRGF0YWJhc2VPYmplY3QsIHVzZURvY3VtZW50LCB1c2VGaXJlYmFzZUFwcCwgdXNlRmlyZWJhc2VBdXRoLCB1c2VGaXJlYmFzZVN0b3JhZ2UsIHVzZUZpcmVzdG9yZSwgdXNlTGlzdCwgdXNlT2JqZWN0LCB1c2VQZW5kaW5nUHJvbWlzZXMsIHVzZVNTUkluaXRpYWxTdGF0ZSwgdXNlU3RvcmFnZSwgdXNlU3RvcmFnZUZpbGUsIHVzZVN0b3JhZ2VGaWxlTWV0YWRhdGEsIHVzZVN0b3JhZ2VGaWxlVXJsLCB1c2VTdG9yYWdlTWV0YWRhdGEsIHVzZVN0b3JhZ2VPYmplY3QsIHVzZVN0b3JhZ2VVcmwgfTtcbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBS0EsSUFBTSwyQkFBMkIsT0FBTyxhQUFhO0FBQ3JELFNBQVMsZUFBZSxNQUFNO0NBQzVCLE9BQU8sbUJBQW1CLEtBQUssT0FDN0IsMEJBRUEsSUFDRixLQUFLLE9BQU8sSUFBSTtBQUNsQjtBQUVBLElBQU0sYUFBYSxDQUNuQjtBQUNBLElBQU0sV0FBVyxPQUFPLFdBQVc7QUFDbkMsU0FBUyxRQUFRLEtBQUssTUFBTTtDQUMxQixPQUFPLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxRQUFRLFFBQVEsUUFBUSxVQUFVLE9BQU8sTUFBTSxHQUFHO0FBQzNFO0FBQ0EsU0FBUyxRQUFRLEtBQUssTUFBTSxPQUFPO0NBQ2pDLE1BQU0sUUFBUSxLQUFLLEtBQUEsQ0FBTSxNQUFNLEdBQUc7Q0FDbEMsTUFBTSxNQUFNLEtBQUssSUFBSTtDQUNyQixNQUFNLFNBQVMsS0FBSyxRQUNqQixTQUFTLFNBRVIsV0FBVyxRQUFRLE9BRXJCLEdBQ0Y7Q0FDQSxJQUFJLFVBQVUsTUFDWjtDQUNGLE9BQU8sTUFBTSxRQUFRLE1BQU0sSUFBSSxPQUFPLE9BQU8sT0FBTyxHQUFHLEdBQUcsR0FBRyxLQUFLLElBRWhFLE9BQU8sT0FDUDtBQUVKO0FBQ0EsU0FBUyxTQUFTLEdBQUc7Q0FDbkIsT0FBTyxDQUFDLENBQUMsS0FBSyxPQUFPLE1BQU07QUFDN0I7QUFDQSxJQUFNLGtCQUFrQixPQUFPO0FBQy9CLFNBQVMsT0FBTyxLQUFLO0NBQ25CLE9BQU8sU0FBUyxHQUFHLEtBQUssT0FBTyxlQUFlLEdBQUcsTUFBTTtBQUN6RDtBQUNBLFNBQVMsY0FBYyxHQUFHO0NBQ3hCLE9BQU8sU0FBUyxDQUFDLEtBQUssRUFBRSxTQUFTO0FBQ25DO0FBQ0EsU0FBUyxnQkFBZ0IsR0FBRztDQUMxQixPQUFPLFNBQVMsQ0FBQyxLQUFLLEVBQUUsU0FBUztBQUNuQztBQUNBLFNBQVMseUJBQXlCLFFBQVE7Q0FDeEMsT0FBTyxjQUFjLE1BQU0sS0FBSyxnQkFBZ0IsTUFBTTtBQUN4RDtBQUNBLFNBQVMsaUJBQWlCLFFBQVE7Q0FDaEMsT0FBTyxTQUFTLE1BQU0sS0FBSyxPQUFPLFNBQVM7QUFDN0M7QUFDQSxTQUFTLG9CQUFvQixRQUFRO0NBQ25DLE9BQU8sU0FBUyxNQUFNLEtBQUssU0FBUztBQUN0QztBQUNBLFNBQVMsbUJBQW1CLFFBQVE7Q0FDbEMsT0FBTyxTQUFTLE1BQU0sS0FBSyxPQUFPLE9BQU8sV0FBVztBQUN0RDtBQUNBLFNBQVMsZ0JBQWdCLElBQUksT0FBTztDQUNsQyxJQUFJO0NBQ0osYUFBYTtFQUNYLElBQUksQ0FBQyxRQUFRO0dBQ1gsU0FBUztHQUNULE9BQU8sR0FBRyxNQUFNLENBQUM7RUFDbkI7Q0FDRjtBQUNGO0FBQ0EsSUFBTSxnQkFBZ0IsT0FBTyxJQUFJLE9BQU87QUFDeEMsU0FBUyxXQUFXO0NBQ2xCLE1BQU0sV0FBVyxtQkFBbUI7Q0FDcEMsT0FBTyxDQUFDLEVBQUUsU0FBUyxZQUNuQixTQUFTLE1BQU0sWUFBWSxPQUFPLGVBQWUsQ0FBQztBQUNwRDtBQUNBLFNBQVMsbUJBQW1CLE1BQU0sUUFBUTtDQUN4QyxJQUFJLE9BQU8seUJBQXlCLE1BQU0sTUFBTSxDQUFDLEVBQUUsTUFBTSxNQUFNLE1BQU07RUFDbkUsUUFBUSxLQUFLLDJFQUEyRSxPQUFPLHVGQUF1RixPQUFPOzs4QkFFbks7RUFDMUIsT0FBTztDQUNUO0NBQ0EsT0FBTztBQUNUO0FBRUEsSUFBTSwyQkFBMkIsSUFBSSxRQUFRO0FBQzdDLFNBQVMsZUFBZSxhQUFhLEtBQUs7Q0FDeEMsSUFBSSxDQUFDLFNBQVMsSUFBSSxXQUFXLEdBQUc7RUFDOUIsTUFBTSxRQUFRLFlBQVksSUFBSTtFQUM5QixTQUFTLElBQUksYUFBYSxLQUFLO0VBQy9CLE1BQU0sRUFBRSxZQUFZO0VBQ3BCLElBQUksZ0JBQWdCO0dBQ2xCLFFBQVEsS0FBSyxHQUFHO0dBQ2hCLE1BQU0sS0FBSztHQUNYLFNBQVMsT0FBTyxXQUFXO0VBQzdCO0NBQ0Y7Q0FDQSxPQUFPLFNBQVMsSUFBSSxXQUFXO0FBQ2pDO0FBRUEsSUFBTSw4QkFBOEIsSUFBSSxRQUFRO0FBQ2hELFNBQVMsZUFBZSxNQUFNO0NBQzVCLElBQTZDLENBQUMsWUFBWSxJQUFJLGVBQWUsSUFBSSxDQUFDLEdBQ2hGLE1BQU0sSUFBSSxNQUNSLGdJQUNGO0NBRUYsT0FBTyxZQUFZLElBQUksZUFBZSxJQUFJLENBQUM7QUFDN0M7QUFDQSxTQUFTLHVCQUF1QixNQUFNO0NBQ3BDLE1BQU0sY0FBYyxlQUFlLElBQUk7Q0FDdkMsT0FBTyxlQUFlLFlBQVksVUFBVSxLQUFLLENBQUM7QUFDcEQ7QUFDQSxTQUFTLHlCQUF5QixTQUFTO0NBQ3pDLE9BQU8sZUFBZSxDQUFDLENBQUMsTUFBTSxTQUFTO0VBQ3JDLElBQUksTUFDRixPQUFPLGNBQWMsTUFBTSxPQUFPLENBQUMsQ0FBQyxXQUFXLEtBQUssT0FBTyxDQUFDO0NBRWhFLENBQUM7QUFDSDtBQUNBLElBQU0saUNBQWlDLElBQUksUUFBUTtBQUluRCxTQUFTLHFCQUFxQixNQUFNO0NBQ2xDLE1BQU0sY0FBYyxlQUFlLElBQUk7Q0FDdkMsSUFBSSxDQUFDLGVBQWUsSUFBSSxXQUFXLEdBQUc7RUFDcEMsSUFBSTtFQUlKLE1BQU0sWUFBWSxDQUNoQixJQUprQixTQUFTLGFBQWE7R0FDeEMsVUFBVTtFQUNaLENBRVEsSUFDTCxTQUFTO0dBQ1IsZUFBZSxJQUFJLGFBQWEsSUFBSTtHQUNwQyxRQUFRLEtBQUssS0FBSztFQUNwQixDQUNGO0VBQ0EsZUFBZSxJQUFJLGFBQWEsU0FBUztDQUMzQztDQUNBLE9BQU8sZUFBZSxJQUFJLFdBQVc7QUFDdkM7QUFDQSxTQUFTLGVBQWUsTUFBTTtDQUM1QixNQUFNLGdCQUFnQixxQkFBcUIsSUFBSTtDQUMvQyxPQUFPLE1BQU0sUUFBUSxhQUFhLElBQUksY0FBYyxLQUFLLFFBQVEsUUFBUSxjQUFjLEtBQUs7QUFDOUY7QUFDQSxTQUFTLHdCQUF3QixNQUFNLE1BQU07Q0FDM0MsaUJBQWlCLE9BQU8sYUFBYTtFQUNuQyxNQUFNLGdCQUFnQixxQkFBcUI7RUFDM0MsS0FBSyxRQUFRO0VBQ2IsSUFBSSxNQUFNLFFBQVEsYUFBYSxHQUM3QixjQUFjLEVBQUUsQ0FBQyxJQUFJO0NBRXpCLENBQUM7QUFDSDtBQUVBLElBQU0sNEJBQTRCLE9BQU8saUJBQWlCO0FBQzFELFNBQVMsbUJBQW1CO0NBQzFCLE9BQU8sT0FBTyx5QkFBeUI7QUFDekM7QUFDQSxTQUFTLGdCQUFnQixTQUFTO0NBQ2hDLFFBQVEsYUFBYSxRQUFRO0VBQzNCLElBQUksQ0FBQyxVQUNIO0VBQ0YsTUFBTSxRQUFRLGVBQWUsYUFBYSxHQUFHLENBQUMsQ0FBQyxVQUFVLElBQUksQ0FBQztFQUM5RCxJQUFJLFFBQVEsMkJBQTJCLEtBQUs7RUFDNUMsSUFBSSxRQUFRLE9BQ1YsS0FBSyxnQ0FBZ0MsUUFBUTtFQUUvQyxNQUFNLFdBQVcsbUJBQW1CLGFBQWEsT0FBTztFQUN4RCxlQUFlLFdBQVcsYUFBYTtHQUNyQyxNQUFNLFFBQVEsU0FBUztFQUN6QixDQUFDO0VBQ0QsWUFBWSxJQUFJLGFBQWEsUUFBUTtDQUN2QztBQUNGO0FBQ0EsSUFBTSw4QkFBOEIsSUFBSSxRQUFRO0FBQ2hELFNBQVMsWUFBWSxNQUFNO0NBQ3pCLE9BQU8sWUFBWSxJQUFJLGVBQWUsSUFBSSxDQUFDO0FBQzdDOzs7QUM1S0EsSUFBTSxvQ0FBb0MsSUFBSSxRQUFRO0FBQ3RELFNBQVMsbUJBQW1CLGNBQWMsYUFBYTtDQUNyRCxJQUFJLENBQUMsa0JBQWtCLElBQUksV0FBVyxHQUNwQyxrQkFBa0IsSUFDaEIsYUFDQSxnQkFBZ0I7RUFBRSxHQUFHLENBQUM7RUFBRyxHQUFHLENBQUM7RUFBRyxHQUFHLENBQUM7RUFBRyxHQUFHLENBQUM7Q0FBRSxDQUMvQztDQUVGLE9BQU8sa0JBQWtCLElBQUksV0FBVztBQUMxQztBQUNBLFNBQVMsZ0JBQWdCLFlBQVksUUFBUSxlQUFlLGFBQWE7Q0FDdkUsSUFBSSxDQUFDLFlBQ0gsT0FBTztDQUNULE1BQU0sQ0FBQyxZQUFZLFFBQVEsa0JBQWtCLFVBQVU7Q0FDdkQsSUFBSSxDQUFDLFlBQ0gsT0FBTztDQUNULE1BQU0sZUFBZSxtQkFBbUIsS0FBSyxHQUFHLFdBQVcsQ0FBQyxDQUFDLGVBQWUsQ0FBQztDQUM3RSxNQUFNLE1BQU0sVUFBVTtDQUN0QixPQUFPLE9BQU8sT0FBTyxlQUFlLGFBQWEsT0FBTztBQUMxRDtBQUNBLFNBQVMsdUJBQXVCLFlBQVksUUFBUSxTQUFTLGFBQWE7Q0FDeEUsSUFBSSxDQUFDLFlBQ0g7Q0FDRixNQUFNLENBQUMsWUFBWSxRQUFRLGtCQUFrQixVQUFVO0NBQ3ZELElBQUksQ0FBQyxZQUNIO0NBQ0YsTUFBTSxlQUFlLG1CQUNuQixLQUFLLEdBQ0wsV0FDRixDQUFDLENBQUM7Q0FDRixNQUFNLE1BQU0sVUFBVTtDQUN0QixJQUFJLEtBQUs7RUFDUCxRQUFRLE1BQU0sVUFBVTtHQUN0QixhQUFhLE9BQU87RUFDdEIsQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFJO0VBQ2IsT0FBTztDQUNUO0FBQ0Y7QUFDQSxTQUFTLGtCQUFrQixZQUFZO0NBQ3JDLE9BQU8seUJBQXlCLFVBQVUsS0FBSyxpQkFBaUIsVUFBVSxJQUFJLENBQUMsS0FBSyxXQUFXLElBQUksSUFBSSxvQkFBb0IsVUFBVSxJQUFJLENBQUMsS0FBSyxXQUFXLFNBQVMsQ0FBQyxJQUFJLG1CQUFtQixVQUFVLElBQUksQ0FBQyxLQUFLLFdBQVcsU0FBUyxDQUFDLElBQUksQ0FBQztBQUMzTztBQUVBLElBQU0scUNBQXFDLElBQUksUUFBUTtBQUN2RCxTQUFTLGtCQUFrQixTQUFTLFlBQVksUUFBUTtDQUN0RCxNQUFNLE1BQU0sZUFBZTtDQUMzQixJQUFJLENBQUMsbUJBQW1CLElBQUksR0FBRyxHQUM3QixtQkFBbUIsSUFBSSxxQkFBcUIsSUFBSSxJQUFJLENBQUM7Q0FFdkQsTUFBTSxrQkFBa0IsbUJBQW1CLElBQUksR0FBRztDQUNsRCxNQUFNLE1BQU0sdUJBQXVCLFlBQVksUUFBUSxTQUFTLEdBQUc7Q0FDbkUsSUFBSSxLQUNGLGdCQUFnQixJQUFJLEtBQUssT0FBTztNQUc5QixRQUFRLEtBQUssMERBQTBEO0NBRzNFLE9BQU8sWUFBWSxnQkFBZ0IsT0FBTyxHQUFHLElBQUk7QUFDbkQ7QUFDQSxTQUFTLG1CQUFtQixLQUFLO0NBQy9CLE1BQU0sT0FBTyxlQUFlO0NBQzVCLE1BQU0sa0JBQWtCLG1CQUFtQixJQUFJLEdBQUc7Q0FDbEQsTUFBTSxJQUFJLGtCQUFrQixRQUFRLElBQ2xDLE1BQU0sS0FBSyxlQUFlLENBQUMsQ0FBQyxLQUN6QixDQUFDLEtBQUssYUFBYSxRQUFRLE1BQU0sU0FBUyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQ3hELENBQ0YsSUFBSSxRQUFRLFFBQVEsQ0FBQyxDQUFDO0NBQ3RCLG1CQUFtQixPQUFPLEdBQUc7Q0FDN0IsT0FBTztBQUNUO0FBRUEsU0FBUyxpQ0FBaUMsVUFBVTtDQUNsRCxJQUFJLENBQUMsU0FBUyxPQUFPLEdBQ25CLE9BQU87Q0FDVCxNQUFNLFFBQVEsU0FBUyxJQUFJO0NBQzNCLE9BQU8sU0FBUyxLQUFLLElBQUksT0FBTyxlQUFlLE9BQU8sTUFBTSxFQUUxRCxPQUFPLFNBQVMsSUFDbEIsQ0FBQyxJQUFJO0VBR0gsUUFBUTtFQUNSLElBQUksU0FBUztDQUNmO0FBQ0Y7QUFDQSxTQUFTLFlBQVksT0FBTyxLQUFLO0NBQy9CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FDaEMsSUFBSSxNQUFNLEVBQUUsQ0FBQyxPQUFPLEtBQ2xCLE9BQU87Q0FFWCxPQUFPO0FBQ1Q7QUFFQSxJQUFNLG9CQUFvQjtDQUN4QixPQUFPO0NBQ1AsV0FBVztDQUNYLE1BQU07QUFDUjtBQUNBLFNBQVMsYUFBYSxRQUFRLFVBQVUsU0FBUyxRQUFRLGNBQWM7Q0FDckUsTUFBTSxVQUFVLE9BQU8sT0FBTyxDQUFDLEdBQUcsbUJBQW1CLFlBQVk7Q0FDakUsSUFBSSxjQUFjO0NBQ2xCLFNBQVMsZ0JBQWdCLFVBQVU7RUFDakMsTUFBTSxRQUFRLFFBQVEsVUFBVSxRQUFRO0VBQ3hDLE9BQU8sUUFBUTtFQUNmLFFBQVEsS0FBSztDQUNmO0NBQ0EsSUFBSSxRQUFRLE1BQ1YsSUFBSSxRQUFRLENBQUMsQ0FBQyxLQUFLLGVBQWUsQ0FBQyxDQUFDLE1BQU0sTUFBTTtNQUVoRCxjQUFjLFFBQVEsVUFBVSxpQkFBaUIsTUFBTTtDQUV6RCxRQUFRLFVBQVU7RUFDaEIsWUFBWTtFQUNaLElBQUksT0FFRixPQUFPLFFBRE8sT0FBTyxVQUFVLGFBQWEsTUFBTSxJQUFJO0NBRzFEO0FBQ0Y7QUFDQSxTQUFTLFlBQVksUUFBUSxZQUFZLFNBQVMsUUFBUSxjQUFjO0NBQ3RFLE1BQU0sVUFBVSxPQUFPLE9BQU8sQ0FBQyxHQUFHLG1CQUFtQixZQUFZO0NBQ2pFLElBQUksV0FBVyxRQUFRLE9BQU8sQ0FBQyxJQUFJO0NBQ25DLElBQUksQ0FBQyxRQUFRLE1BQ1gsT0FBTyxRQUFRLENBQUM7Q0FFbEIsSUFBSSwyQkFBMkI7Q0FDL0IsSUFBSSw2QkFBNkI7Q0FDakMsSUFBSSw2QkFBNkI7Q0FDakMsSUFBSSwyQkFBMkI7Q0FDL0IsSUFBSSxzQkFBc0I7Q0FDMUIsSUFBSSxRQUFRLE1BQ1YsSUFBSSxVQUFVLENBQUMsQ0FBQyxNQUFNLFNBQVM7RUFDN0IsTUFBTSxRQUFRLENBQUM7RUFDZixLQUFLLFNBQVMsYUFBYTtHQUN6QixNQUFNLEtBQUssUUFBUSxVQUFVLFFBQVEsQ0FBQztFQUN4QyxDQUFDO0VBQ0QsUUFBUSxPQUFPLFFBQVEsS0FBSztDQUM5QixDQUFDLENBQUMsQ0FBQyxNQUFNLE1BQU07TUFDVjtFQUNMLDJCQUEyQixhQUN6QixhQUNDLFVBQVUsWUFBWTtHQUNyQixNQUFNLFFBQVEsUUFBUSxRQUFRO0dBQzlCLE1BQU0sUUFBUSxVQUFVLFlBQVksT0FBTyxPQUFPLElBQUksSUFBSTtHQUMxRCxNQUFNLE9BQU8sT0FBTyxHQUFHLFFBQVEsVUFBVSxRQUFRLENBQUM7RUFDcEQsR0FDQSxNQUNGO0VBQ0EsNkJBQTZCLGVBQzNCLGFBQ0MsYUFBYTtHQUNaLE1BQU0sUUFBUSxRQUFRLFFBQVE7R0FDOUIsTUFBTSxPQUFPLFlBQVksT0FBTyxTQUFTLEdBQUcsR0FBRyxDQUFDO0VBQ2xELEdBQ0EsTUFDRjtFQUNBLDZCQUE2QixlQUMzQixhQUNDLGFBQWE7R0FDWixNQUFNLFFBQVEsUUFBUSxRQUFRO0dBQzlCLE1BQU0sT0FDSixZQUFZLE9BQU8sU0FBUyxHQUFHLEdBQy9CLEdBRUEsUUFBUSxVQUFVLFFBQVEsQ0FDNUI7RUFDRixHQUNBLE1BQ0Y7RUFDQSwyQkFBMkIsYUFDekIsYUFDQyxVQUFVLFlBQVk7R0FDckIsTUFBTSxRQUFRLFFBQVEsUUFBUTtHQUM5QixNQUFNLFFBQVEsWUFBWSxPQUFPLFNBQVMsR0FBRztHQUM3QyxNQUFNLFlBQVksTUFBTSxPQUFPLE9BQU8sQ0FBQyxDQUFDLENBQUM7R0FDekMsTUFBTSxXQUFXLFVBQVUsWUFBWSxPQUFPLE9BQU8sSUFBSSxJQUFJO0dBQzdELE1BQU0sT0FBTyxVQUFVLEdBQUcsU0FBUztFQUNyQyxHQUNBLE1BQ0Y7RUFDQSxzQkFBc0IsUUFDcEIsa0JBQ007R0FDSixNQUFNLFFBQVEsUUFBUSxRQUFRO0dBQzlCLElBQUksUUFBUSxNQUFNO0lBQ2hCLE9BQU8sUUFBUTtJQUNmLFdBQVc7R0FDYjtHQUNBLFFBQVEsS0FBSztHQUNiLG9CQUFvQjtFQUN0QixHQUNBLE1BQ0Y7Q0FDRjtDQUNBLFFBQVEsVUFBVTtFQUNoQixvQkFBb0I7RUFDcEIseUJBQXlCO0VBQ3pCLDJCQUEyQjtFQUMzQiwyQkFBMkI7RUFDM0IseUJBQXlCO0VBQ3pCLElBQUksT0FFRixPQUFPLFFBRE8sT0FBTyxVQUFVLGFBQWEsTUFBTSxJQUFJLENBQUM7Q0FHM0Q7QUFDRjtBQUVBLFNBQVMsZ0JBQWdCLFdBQVcsZUFBZSxDQUFDLEdBQUcsU0FBUyxPQUFPO0NBQ3JFLElBQUksU0FBUztDQUNiLE1BQU0sVUFBVSxPQUFPLE9BQU8sQ0FBQyxHQUFHLG1CQUFtQixZQUFZO0NBQ2pFLE1BQU0scUJBQXFCLFFBQVEsU0FBUztDQUM1QyxNQUFNLE9BQU8sUUFBUSxVQUFVLElBQUk7Q0FFakMsSUFBSSxRQUFRLFVBQVUsbUJBQW1CLE1BQU0sdUNBQXVDLEdBQ3BGLE9BQU87Q0FJWCxJQURjLFNBQ04sR0FDTixRQUFRLE9BQU87Q0FFakIsTUFBTSxlQUFlLGdCQUNuQixvQkFDQSxRQUFRLFFBQ1IsS0FBSyxPQUNMLGVBQWUsQ0FDakI7Q0FDQSxLQUFLLFFBQVE7Q0FFYixJQUFJLHVCQUF1QixFQURILFVBQVUsZ0JBQWdCLENBQUMsRUFBQSxDQUFHLFNBQVMsSUFBSSxpQkFBaUIsS0FBSztDQUV6RixNQUFNLFFBQVEsSUFBSTtDQUNsQixNQUFNLFVBQVUsSUFBSSxLQUFLO0NBQ3pCLE1BQU0sVUFBVSxXQUFXO0NBQzNCLE1BQU0sa0JBQWtCLGdCQUFnQjtDQUN4QyxJQUFJLHVCQUF1QjtDQUMzQixTQUFTLGtCQUFrQjtFQUN6QixNQUFNLGlCQUFpQixRQUFRLFNBQVM7RUFDeEMsTUFBTSxhQUFhLElBQUksU0FBUyxTQUFTLFdBQVc7R0FDbEQsT0FBTyxRQUFRLEtBQUs7R0FDcEIsSUFBSSxDQUFDLGdCQUFnQjtJQUNuQixTQUFTO0lBQ1QsT0FBTyxRQUFRLElBQUk7R0FDckI7R0FDQSxRQUFRLFFBQVE7R0FDaEIsdUJBQXVCO0dBQ3ZCLElBQUksTUFBTSxRQUFRLEtBQUssS0FBSyxHQUMxQixTQUFTLFlBQ1AsTUFDQSxnQkFDQSxTQUNBLFFBQ0EsT0FDRjtRQUVBLFNBQVMsYUFBYSxNQUFNLGdCQUFnQixTQUFTLFFBQVEsT0FBTztFQUV4RSxDQUFDLENBQUMsQ0FBQyxPQUFPLFdBQVc7R0FDbkIsSUFBSSxRQUFRLFVBQVUsWUFDcEIsTUFBTSxRQUFRO0dBRWhCLE1BQU07RUFDUixDQUFDLENBQUMsQ0FBQyxjQUFjO0dBQ2YsSUFBSSxRQUFRLFVBQVUsWUFDcEIsUUFBUSxRQUFRO0VBRXBCLENBQUM7RUFDRCxRQUFRLFFBQVE7Q0FDbEI7Q0FDQSxJQUFJLGNBQWM7Q0FDbEIsSUFBSSxNQUFNLFNBQVMsS0FBSyxPQUFPLGNBQWMsWUFDM0MsY0FBYyxNQUFNLFdBQVcsZUFBZTtDQUVoRCxnQkFBZ0I7Q0FDaEIsSUFBSSxvQkFDRix1QkFBdUIsa0JBQ3JCLFFBQVEsT0FDUixvQkFDQSxRQUFRLE1BQ1Y7Q0FFRixJQUFJLGlCQUFpQjtFQUNuQixlQUFlLElBQUk7RUFDbkIsSUFBSSxtQkFBbUIsR0FDckIsdUJBQXVCLFFBQVEsS0FBSztDQUV4QztDQUNBLFNBQVMsS0FBSyxRQUFRLFFBQVEsT0FBTztFQUNuQyxZQUFZO0VBQ1oscUJBQXFCO0VBQ3JCLE9BQU8sS0FBSztDQUNkO0NBQ0EsT0FBTyxPQUFPLGlCQUFpQixNQUFNO0VBRW5DLE1BQU0sRUFBRSxXQUFXLEtBQUs7RUFDeEIsT0FBTyxFQUFFLFdBQVcsTUFBTTtFQUMxQixTQUFTLEVBQUUsV0FBVyxRQUFRO0VBQzlCLFNBQVMsRUFBRSxXQUFXLFFBQVE7RUFDOUIsTUFBTSxFQUFFLFdBQVcsS0FBSztDQUMxQixDQUFDO0FBQ0g7QUFFQSxTQUFTLGdCQUFnQixXQUFXLFNBQVM7Q0FFM0MsT0FBTyxnQkFDTCxXQUNBO0VBQ0UsUUFKUyxJQUFJLENBQUMsQ0FJSDtFQUNYLEdBQUc7Q0FDTCxHQUNBLElBQ0Y7QUFDRjtBQUNBLElBQU0sVUFBVTtBQUNoQixTQUFTLGtCQUFrQixXQUFXLFNBQVM7Q0FFN0MsT0FBTyxnQkFBZ0IsV0FBVztFQUNoQyxRQUZXLElBRUE7RUFDWCxHQUFHO0NBQ0wsQ0FBQztBQUNIO0FBQ0EsSUFBTSxZQUFZO0FBQ2xCLFNBQVMsWUFBWSxNQUFNO0NBQ3pCLE9BQU8sWUFBWSxlQUFlLElBQUksQ0FBQztBQUN6QztBQUVBLElBQU0sNEJBQTRCO0NBQ2hDLFlBQVksTUFBTTtFQUNoQixPQUFPO0NBQ1Q7Q0FDQSxjQUFjLFVBQVUsU0FBUztFQUMvQixPQUFPLFNBQVMsT0FBTyxJQUFJLE9BQU8saUJBQWlCLFNBQVMsS0FBSyxPQUFPLEdBQUcsRUFDekUsSUFBSSxFQUFFLE9BQU8sU0FBUyxHQUFHLEVBTzNCLENBQUMsSUFBSTtDQUNQO0FBQ0Y7QUFDQSxTQUFTLFlBQVksS0FBSyxRQUFRLE1BQU0sU0FBUztDQUMvQyxJQUFJLENBQUMsT0FBTyxHQUFHLEdBQ2IsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO0NBQ2pCLE1BQU0sY0FBYyxDQUNsQixDQUFDLEdBQ0QsQ0FBQyxDQUNIO0NBQ0EsTUFBTSxhQUFhLE9BQU8sS0FBSyxJQUFJLENBQUMsQ0FBQyxRQUNsQyxZQUFZLFdBQVc7RUFDdEIsTUFBTSxNQUFNLEtBQUs7RUFDakIsV0FBVyxJQUFJLFFBQVEsSUFBSSxLQUFLO0VBQ2hDLE9BQU87Q0FDVCxHQUNBLENBQUMsQ0FDSDtDQUNBLFNBQVMsaUJBQWlCLE1BQU0sU0FBUyxNQUFNLFFBQVE7RUFDckQsVUFBVSxXQUFXLENBQUM7RUFDdEIsTUFBTSxDQUFDLE1BQU0sUUFBUTtFQUNyQixPQUFPLG9CQUFvQixJQUFJLENBQUMsQ0FBQyxTQUFTLGlCQUFpQjtHQUN6RCxNQUFNLGFBQWEsT0FBTyx5QkFBeUIsTUFBTSxZQUFZO0dBQ3JFLElBQUksY0FBYyxDQUFDLFdBQVcsWUFDNUIsT0FBTyxlQUFlLE1BQU0sY0FBYyxVQUFVO0VBRXhELENBQUM7RUFDRCxLQUFLLE1BQU0sT0FBTyxNQUFNO0dBQ3RCLE1BQU0sTUFBTSxLQUFLO0dBQ2pCLElBRUUsT0FBTyxRQUVQLGVBQWUsUUFBUSxlQUFlLGFBQWEsZUFBZSxVQUVsRSxLQUFLLE9BQU87UUFDUCxJQUFJLGNBQWMsR0FBRyxHQUFHO0lBQzdCLE1BQU0sWUFBWSxPQUFPO0lBQ3pCLEtBQUssT0FJTCxhQUFhLE9BQU8sUUFBUSxPQUFPLElBQUk7SUFDdkMsS0FBSyxhQUFhLElBQUksWUFBWSxNQUFNLElBQUksY0FDMUMsUUFBUSxTQUNWO0dBQ0YsT0FBTyxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUc7SUFDN0IsS0FBSyxPQUFPLE1BQU0sSUFBSSxNQUFNO0lBQzVCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsS0FBSztLQUNuQyxNQUFNLFNBQVMsSUFBSTtLQUNuQixJQUFJLFVBQVUsT0FBTyxRQUFRLFlBQzNCLEtBQUssSUFBSSxDQUFDLEtBQUssV0FBVyxPQUFPO0lBQ3JDO0lBQ0EsaUJBQWlCLEtBQUssUUFBUSxRQUFRLEtBQUssTUFBTSxPQUFPLE1BQU0sS0FBSyxDQUNqRSxLQUFLLE1BQ0wsSUFDRixDQUFDO0dBQ0gsT0FBTyxJQUFJLFNBQVMsR0FBRyxHQUFHO0lBQ3hCLEtBQUssT0FBTyxDQUFDO0lBQ2IsaUJBQWlCLEtBQUssUUFBUSxNQUFNLE9BQU8sTUFBTSxLQUFLLENBQUMsS0FBSyxNQUFNLElBQUksQ0FBQztHQUN6RSxPQUNFLEtBQUssT0FBTztFQUVoQjtDQUNGO0NBQ0EsaUJBQWlCLEtBQUssUUFBUSxJQUFJLFdBQVc7Q0FDN0MsT0FBTztBQUNUO0FBQ0EsSUFBTSw0QkFBNEI7Q0FDaEMsWUFBWSxTQUFTLGdCQUFnQixhQUFhLEtBQUssT0FBTztDQUM5RCxXQUFXLFNBQVMsZ0JBQWdCLFlBQVksS0FBSyxPQUFPO0FBQzlEO0FBQ0EsSUFBTSx1QkFBdUI7Q0FDM0IsWUFBWSxTQUFTLElBQUksVUFBVSxLQUFLLFNBQVMsS0FBSyxXQUFXO0NBQ2pFLFdBQVcsU0FBUyxJQUFJLFNBQVMsS0FBSyxVQUFVLEtBQUssU0FBUztBQUNoRTtBQUVBLElBQU0sa0JBQWtCO0NBQ3RCLE9BQU87Q0FDUCxNQUFNO0NBQ04sYUFBYTtDQUNiLFdBQVc7Q0FDWCxpQkFBaUIsRUFBRSxrQkFBa0IsV0FBVztBQUNsRDtBQUNBLFNBQVMsZUFBZSxNQUFNO0NBQzVCLEtBQUssTUFBTSxPQUFPLE1BQ2hCLEtBQUssSUFBSSxDQUFDLE1BQU07QUFFcEI7QUFDQSxTQUFTLCtCQUErQixTQUFTLFFBQVEsTUFBTSxVQUFVLE1BQU0sS0FBSyxPQUFPLFNBQVMsUUFBUTtDQUMxRyxNQUFNLENBQUMsTUFBTSxRQUFRLFlBR25CLFNBQVMsS0FBSyxRQUFRLGVBQWUsR0FDckMsUUFBUSxRQUFRLElBQUksR0FDcEIsTUFDQSxPQUNGO0NBQ0EsSUFBSSxJQUFJLFFBQVEsTUFBTSxJQUFJO0NBQzFCLGdCQUNFLFNBQ0EsUUFDQSxNQUNBLE1BQ0EsTUFDQSxLQUNBLE9BQ0EsU0FDQSxNQUNGO0FBQ0Y7QUFDQSxTQUFTLG9CQUFvQixFQUMzQixLQUFLLE1BQ0wsUUFDQSxNQUNBLE9BQ0EsU0FDQSxRQUNBLE9BQ0MsU0FBUztDQUNWLE1BQU0sT0FBdUIsdUJBQU8sT0FBTyxJQUFJO0NBQy9DLElBQUksU0FBUztDQUNiLElBQUksUUFBUSxNQUNWLE9BQU8sSUFBSSxDQUFDLENBQUMsTUFBTSxhQUFhO0VBQzlCLElBQUksU0FBUyxPQUFPLEdBQ2xCLCtCQUNFLFNBQ0EsUUFDQSxNQUNBLFVBQ0EsTUFDQSxLQUNBLE9BQ0EsU0FDQSxNQUNGO09BQ0s7R0FDTCxJQUFJLElBQUksUUFBUSxNQUFNLElBQUk7R0FDMUIsUUFBUTtFQUNWO0NBQ0YsQ0FBQyxDQUFDLENBQUMsTUFBTSxNQUFNO01BRWYsU0FBUyxXQUNQLE9BQ0MsYUFBYTtFQUNaLElBQUksU0FBUyxPQUFPLEdBQ2xCLCtCQUNFLFNBQ0EsUUFDQSxNQUNBLFVBQ0EsTUFDQSxLQUNBLE9BQ0EsU0FDQSxNQUNGO09BQ0s7R0FDTCxJQUFJLElBQUksUUFBUSxNQUFNLElBQUk7R0FDMUIsUUFBUTtFQUNWO0NBQ0YsR0FDQSxNQUNGO0NBRUYsYUFBYTtFQUNYLE9BQU87RUFDUCxlQUFlLElBQUk7Q0FDckI7QUFDRjtBQUNBLFNBQVMsZ0JBQWdCLFNBQVMsUUFBUSxNQUFNLE1BQU0sTUFBTSxLQUFLLE9BQU8sU0FBUyxRQUFRO0NBQ3ZGLE1BQU0sVUFBVSxPQUFPLEtBQUssSUFBSTtDQUloQyxPQUgyQixLQUFLLElBQUksQ0FBQyxDQUFDLFFBQ25DLFdBQVcsUUFBUSxRQUFRLE1BQU0sSUFBSSxDQUU5QixDQUFDLENBQUMsU0FBUyxXQUFXO0VBQzlCLEtBQUssT0FBTyxDQUFDLE1BQU07RUFDbkIsT0FBTyxLQUFLO0NBQ2QsQ0FBQztDQUNELElBQUksQ0FBQyxRQUFRLFVBQVUsRUFBRSxRQUFRLFFBQVEsYUFDdkMsT0FBTyxRQUFRLElBQUk7Q0FDckIsSUFBSSxnQkFBZ0I7Q0FDcEIsTUFBTSxpQkFBaUIsUUFBUTtDQUMvQixNQUFNLGdCQUFnQyx1QkFBTyxPQUFPLElBQUk7Q0FDeEQsU0FBUyxZQUFZLEtBQUs7RUFDeEIsSUFBSSxPQUFPLGVBQ0w7T0FBQSxFQUFFLGlCQUFpQixnQkFDckIsUUFBUSxJQUFJO0VBQUE7Q0FFbEI7Q0FDQSxRQUFRLFNBQVMsV0FBVztFQUMxQixNQUFNLE1BQU0sS0FBSztFQUNqQixNQUFNLE9BQU8sS0FBSztFQUNsQixNQUFNLFVBQVUsR0FBRyxLQUFLLEdBQUc7RUFDM0IsY0FBYyxXQUFXO0VBQ3pCLElBQUksS0FDRixJQUFJLElBQUksU0FBUyxLQUFLLE1BQ3BCLElBQUksTUFBTTtPQUVWO0VBRUosS0FBSyxVQUFVO0dBQ2IsWUFBWSxRQUFRLFFBQVEsT0FBTztHQUNuQyxPQUFPLG9CQUNMO0lBQ0UsS0FBSztJQUNMO0lBQ0EsTUFBTTtJQUNOO0lBQ0E7SUFDQSxTQUFTLFlBQVksS0FBSyxNQUFNLE9BQU87SUFDdkM7R0FDRixHQUNBLE9BQ0Y7R0FDQSxNQUFNLEtBQUs7RUFDYjtDQUNGLENBQUM7QUFDSDtBQUNBLFNBQVMsZUFBZSxRQUFRLFlBQVksS0FBSyxTQUFTLFFBQVEsY0FBYztDQUM5RSxNQUFNLFVBQVUsT0FBTyxPQUFPLENBQUMsR0FBRyxpQkFBaUIsWUFBWTtDQUMvRCxNQUFNLEVBQUUsdUJBQXVCLGlCQUFpQixNQUFNLFNBQVM7Q0FDL0QsTUFBTSxNQUFNO0NBQ1osSUFBSSxXQUFXLElBQUksT0FBTyxDQUFDLElBQUksT0FBTyxLQUFLO0NBQzNDLElBQUksQ0FBQyxNQUNILElBQUksSUFBSSxRQUFRLEtBQUssQ0FBQyxDQUFDO0NBQ3pCLE1BQU0sa0JBQWtCO0NBQ3hCLElBQUk7Q0FDSixJQUFJLGlCQUFpQjtDQUNyQixNQUFNLFlBQVksQ0FBQztDQUNuQixNQUFNLFNBQVM7RUFDYixRQUFRLEVBQUUsVUFBVSxVQUFVO0dBQzVCLFVBQVUsT0FBTyxVQUFVLEdBQW1CLHVCQUFPLE9BQU8sSUFBSSxDQUFDO0dBQ2pFLE1BQU0sT0FBTyxVQUFVO0dBQ3ZCLE1BQU0sQ0FBQyxNQUFNLFFBQVEsWUFFbkIsSUFBSSxLQUFLLGVBQWUsR0FDeEIsS0FBSyxHQUNMLE1BQ0EsT0FDRjtHQUNBLElBQUksSUFBSSxRQUFRLFFBQVEsR0FBRyxVQUFVLElBQUk7R0FDekMsZ0JBQ0UsU0FDQSxVQUNBLEdBQUcsSUFBSSxHQUFHLFlBQ1YsTUFDQSxNQUNBLEtBQ0EsR0FDQSxRQUFRLEtBQUssTUFBTSxHQUFHLEdBQ3RCLE1BQ0Y7RUFDRjtFQUNBLFdBQVcsRUFBRSxVQUFVLFVBQVUsVUFBVTtHQUN6QyxNQUFNLFFBQVEsUUFBUSxRQUFRO0dBQzlCLE1BQU0sT0FBTyxVQUFVO0dBQ3ZCLE1BQU0sVUFBVSxNQUFNO0dBQ3RCLE1BQU0sQ0FBQyxNQUFNLFFBQVEsWUFFbkIsSUFBSSxLQUFLLGVBQWUsR0FDeEIsU0FDQSxNQUNBLE9BQ0Y7R0FDQSxVQUFVLE9BQU8sVUFBVSxHQUFHLElBQUk7R0FDbEMsSUFBSSxPQUFPLE9BQU8sUUFBUTtHQUMxQixJQUFJLElBQUksT0FBTyxVQUFVLElBQUk7R0FDN0IsZ0JBQ0UsU0FDQSxVQUNBLEdBQUcsSUFBSSxHQUFHLFlBQ1YsTUFDQSxNQUNBLEtBQ0EsR0FDQSxTQUNBLE1BQ0Y7RUFDRjtFQUNBLFVBQVUsRUFBRSxlQUFlO0dBQ3pCLE1BQU0sUUFBUSxRQUFRLFFBQVE7R0FDOUIsSUFBSSxPQUFPLE9BQU8sUUFBUTtHQUMxQixlQUFlLFVBQVUsT0FBTyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUU7RUFDakQ7Q0FDRjtDQUNBLFNBQVMsbUJBQW1CLFVBQVU7RUFDcEMsTUFBTSxhQUFhLFNBQVMsV0FBVyxxQkFBcUI7RUFDNUQsSUFBSSxDQUFDLGNBQWMsV0FBVyxRQUFRO0dBQ3BDLGFBQWE7R0FDYixJQUFJLFFBQVE7R0FDWixNQUFNLGdCQUFnQixXQUFXO0dBQ2pDLE1BQU0sWUFBNEIsdUJBQU8sT0FBTyxJQUFJO0dBQ3BELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxlQUFlLEtBQ2pDLFVBQVUsV0FBVyxFQUFFLENBQUMsSUFBSSxNQUFNO0dBRXBDLFdBQVcsU0FBUztJQUNsQixJQUFJLFFBQVEsS0FBSyxNQUFNLFdBQ2pCO1NBQUEsRUFBRSxTQUFTLGVBQWU7TUFDNUIsSUFBSSxNQUFNO09BQ1IsSUFBSSxJQUFJLFFBQVEsS0FBSyxRQUFRLFFBQVEsQ0FBQztPQUN0QyxXQUFXO01BQ2I7TUFDQSxnQkFBZ0IsUUFBUSxRQUFRLENBQUM7TUFDakMsVUFBVTtLQUNaOztHQUVKO0VBQ0Y7RUFDQSxXQUFXLFNBQVMsTUFBTTtHQUN4QixPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7RUFDbEIsQ0FBQztFQUNELElBQUksQ0FBQyxXQUFXLFFBQVE7R0FDdEIsSUFBSSxNQUFNO0lBQ1IsSUFBSSxJQUFJLFFBQVEsS0FBSyxRQUFRLFFBQVEsQ0FBQztJQUN0QyxXQUFXO0dBQ2I7R0FDQSxRQUFRLFFBQVEsUUFBUSxDQUFDO0VBQzNCO0NBQ0Y7Q0FDQSxJQUFJLE1BQ0YsUUFBUSxVQUFVLENBQUMsQ0FBQyxLQUFLLGtCQUFrQixDQUFDLENBQUMsTUFBTSxNQUFNO01BRXpELGlCQUFpQixXQUFXLFlBQVksb0JBQW9CLE1BQU07Q0FFcEUsUUFBUSxVQUFVO0VBQ2hCLGVBQWU7RUFDZixJQUFJLE9BQU87R0FDVCxNQUFNLFFBQVEsT0FBTyxVQUFVLGFBQWEsTUFBTSxJQUFJLENBQUM7R0FDdkQsSUFBSSxJQUFJLFFBQVEsS0FBSyxLQUFLO0VBQzVCO0VBQ0EsVUFBVSxRQUFRLGNBQWM7Q0FDbEM7QUFDRjtBQUNBLFNBQVMsYUFBYSxRQUFRLFVBQVUsS0FBSyxTQUFTLFFBQVEsY0FBYztDQUMxRSxNQUFNLFVBQVUsT0FBTyxPQUFPLENBQUMsR0FBRyxpQkFBaUIsWUFBWTtDQUMvRCxNQUFNLE1BQU07Q0FDWixNQUFNLE9BQXVCLHVCQUFPLE9BQU8sSUFBSTtDQUMvQyxVQUFVLGdCQUFnQixlQUFlLFFBQVEsUUFBUSxHQUFHLENBQUM7Q0FDN0QsSUFBSSxpQkFBaUI7Q0FDckIsU0FBUyxtQkFBbUIsVUFBVTtFQUNwQyxJQUFJLFNBQVMsT0FBTyxHQUNsQiwrQkFDRSxTQUNBLFFBQ0EsS0FDQSxVQUNBLE1BQ0EsS0FDQSxHQUNBLFNBQ0EsTUFDRjtPQUNLO0dBQ0wsSUFBSSxJQUFJLFFBQVEsS0FBSyxJQUFJO0dBQ3pCLFFBQVEsSUFBSTtFQUNkO0NBQ0Y7Q0FDQSxJQUFJLFFBQVEsTUFDVixPQUFPLFFBQVEsQ0FBQyxDQUFDLEtBQUssa0JBQWtCLENBQUMsQ0FBQyxNQUFNLE1BQU07TUFFdEQsaUJBQWlCLFdBQVcsVUFBVSxvQkFBb0IsTUFBTTtDQUVsRSxRQUFRLFVBQVU7RUFDaEIsZUFBZTtFQUNmLElBQUksT0FBTztHQUNULE1BQU0sUUFBUSxPQUFPLFVBQVUsYUFBYSxNQUFNLElBQUk7R0FDdEQsSUFBSSxJQUFJLFFBQVEsS0FBSyxLQUFLO0VBQzVCO0VBQ0EsZUFBZSxJQUFJO0NBQ3JCO0FBQ0Y7QUFFQSxJQUFNLG1CQUFtQixPQUFPO0FBQ2hDLFNBQVMsaUJBQWlCLG9CQUFvQixjQUFjO0NBQzFELElBQUksU0FBUztDQUNiLE1BQU0sVUFBVSxPQUFPLE9BQU8sQ0FBQyxHQUFHLGlCQUFpQixZQUFZO0NBQy9ELE1BQU0scUJBQXFCLFFBQVEsa0JBQWtCO0NBQ3JELE1BQU0sT0FBTyxRQUFRLFVBQVUsSUFBSTtDQUVqQyxJQUFJLFFBQVEsVUFBVSxtQkFBbUIsTUFBTSwrQkFBK0IsR0FDNUUsT0FBTztDQUdYLElBQUksU0FBUyxHQUNYLFFBQVEsT0FBTztDQUVqQixNQUFNLGVBQWUsZ0JBQ25CLG9CQUNBLFFBQVEsUUFDUixrQkFDQSxlQUFlLENBQ2pCO0NBQ0EsTUFBTSxrQkFBa0IsaUJBQWlCO0NBQ3pDLElBQUksaUJBQ0YsS0FBSyxRQUFRO0NBRWYsSUFBSSx1QkFBdUIsQ0FBQztDQUM1QixNQUFNLFVBQVUsSUFBSSxLQUFLO0NBQ3pCLE1BQU0sUUFBUSxJQUFJO0NBQ2xCLE1BQU0sVUFBVSxXQUFXO0NBQzNCLE1BQU0sa0JBQWtCLGdCQUFnQjtDQUN4QyxJQUFJLHVCQUF1QjtDQUMzQixTQUFTLG1CQUFtQjtFQUMxQixJQUFJLGNBQWMsUUFBUSxrQkFBa0I7RUFDNUMsTUFBTSxhQUFhLElBQUksU0FBUyxTQUFTLFdBQVc7R0FDbEQsT0FBTyxRQUFRLEtBQUs7R0FDcEIsSUFBSSxDQUFDLGFBQWE7SUFDaEIsU0FBUztJQUNULE9BQU8sUUFBUSxJQUFJO0dBQ3JCO0dBQ0EsUUFBUSxRQUFRO0dBQ2hCLHVCQUF1QjtHQUN2QixJQUFJLENBQUMsWUFBWSxXQUNmLGNBQWMsWUFBWSxjQUV4QixRQUFRLFNBQ1Y7R0FFRixVQUFVLGNBQWMsV0FBVyxJQUFJLGVBQWUsZUFBQSxDQUVwRCxNQUNBLGFBQ0EsS0FDQSxTQUNBLFFBQ0EsT0FDRjtFQUNGLENBQUMsQ0FBQyxDQUFDLE9BQU8sV0FBVztHQUNuQixJQUFJLFFBQVEsVUFBVSxZQUNwQixNQUFNLFFBQVE7R0FFaEIsT0FBTyxRQUFRLE9BQU8sTUFBTTtFQUM5QixDQUFDLENBQUMsQ0FBQyxjQUFjO0dBQ2YsSUFBSSxRQUFRLFVBQVUsWUFDcEIsUUFBUSxRQUFRO0VBRXBCLENBQUM7RUFDRCxRQUFRLFFBQVE7Q0FDbEI7Q0FDQSxJQUFJLGNBQWM7Q0FDbEIsSUFBSSxNQUFNLGtCQUFrQixLQUFLLE9BQU8sdUJBQXVCLFlBQzdELGNBQWMsTUFBTSxvQkFBb0IsZ0JBQWdCO0NBRTFELGlCQUFpQjtDQUNqQixJQUFJLG9CQUNGLHVCQUF1QixrQkFDckIsUUFBUSxPQUNSLG9CQUNBLFFBQVEsTUFDVjtDQUVGLElBQUksbUJBQW1CLEdBQ3JCLHVCQUF1QixRQUFRLEtBQUs7Q0FFdEMsSUFBSSxpQkFDRixlQUFlLElBQUk7Q0FFckIsU0FBUyxLQUFLLFFBQVEsUUFBUSxPQUFPO0VBQ25DLFlBQVk7RUFDWixxQkFBcUI7RUFDckIsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxPQUFPLE9BQU8saUJBQWlCLE1BQU07RUFDbkMsT0FBTyxFQUFFLFdBQVcsTUFBTTtFQUMxQixNQUFNLEVBQUUsV0FBVyxLQUFLO0VBQ3hCLFNBQVMsRUFBRSxXQUFXLFFBQVE7RUFDOUIsU0FBUyxFQUFFLFdBQVcsUUFBUTtFQUM5QixNQUFNLEVBQUUsV0FBVyxLQUFLO0NBQzFCLENBQUM7QUFDSDtBQUNBLElBQU0sTUFBTTtDQUNWLE1BQU0sUUFBUSxLQUFLLFVBQVUsUUFBUSxRQUFRLEtBQUssS0FBSztDQUN2RCxNQUFNLE9BQU8sT0FBTyxTQUFTLE1BQU0sT0FBTyxPQUFPLEdBQUcsSUFBSTtDQUN4RCxTQUFTLE9BQU8sVUFBVSxNQUFNLE9BQU8sT0FBTyxDQUFDO0FBQ2pEO0FBRUEsU0FBUyxjQUFjLGVBQWUsU0FBUztDQUM3QyxPQUFPLGlCQUFpQixlQUFlO0VBQ3JDLFFBQVEsSUFBSSxDQUFDLENBQUM7RUFDZCxHQUFHO0NBQ0wsQ0FBQztBQUNIO0FBQ0EsU0FBUyxZQUFZLGFBQWEsU0FBUztDQUN6QyxPQUFPLGlCQUFpQixhQUFhLE9BQU87QUFDOUM7QUFDQSxTQUFTLGFBQWEsTUFBTTtDQUMxQixPQUFPLGFBQWEsZUFBZSxJQUFJLENBQUM7QUFDMUM7QUFFQSxJQUFNLGtDQUFrQyxJQUFJLFFBQVE7QUFDcEQsU0FBUyxpQkFBaUIsS0FBSyxTQUFTLE9BQU87Q0FDN0MsSUFBSSxXQUFXLFFBQVEsTUFBTTtFQUMzQixRQUFRLElBQUksQ0FBQyxLQUFLO0VBQ2xCLE9BQU8sUUFBUTtDQUNqQjtBQUNGO0FBRUEsSUFBTSx5QkFBeUI7Q0FDN0IsVUFBVTtDQUNWLFlBQVk7QUFDZDtBQUNBLFNBQVMsZUFBZSxLQUFLLGVBQWUsYUFBYTtDQUN2RCxNQUFNLGdCQUFnQixPQUFPLE9BQU8sQ0FBQyxHQUFHLHdCQUF3QixhQUFhO0NBQzdFLE1BQU0sRUFBRSxVQUFVLGVBQWU7Q0FDakMsTUFBTSxlQUFlLFNBQVMsSUFBSSxPQUFPLG1CQUFtQixJQUFJO0NBQ2hFLGFBQWEsY0FBYyxTQUFTLGVBQWUsS0FBSyxPQUFPO0VBQzdELGlCQUFpQixLQUFLLGdCQUFnQixJQUFJLElBQUksR0FBRyxLQUFLO0VBQ3RELE9BQU8sS0FBSyxjQUFjO0NBQzVCO0NBQ0EsYUFBYSxZQUFZLFNBQVMsYUFBYSxLQUFLLFFBQVEsYUFBYTtFQUN2RSxNQUFNLFVBQVUsT0FBTyxPQUFPLENBQUMsR0FBRyxlQUFlLFdBQVc7RUFDNUQsTUFBTSxTQUFTLE1BQU0sS0FBSyxPQUFPLEdBQUc7RUFDcEMsSUFBSSxDQUFDLGdCQUFnQixJQUFJLElBQUksR0FDM0IsZ0JBQWdCLElBQUksTUFBTSxDQUFDLENBQUM7RUFFOUIsTUFBTSxVQUFVLGdCQUFnQixJQUFJLElBQUk7RUFDeEMsSUFBSSxRQUFRLE1BQ1YsUUFBUSxJQUFJLENBQUMsUUFBUSxLQUFLO0VBRTVCLElBQUksZUFBZTtHQUNqQixJQUFJLENBQUMsY0FBYyxVQUNqQixhQUFhLGVBQWUsYUFBYTtHQUUzQyxJQUFJLENBQUMsY0FBYyxZQUNqQixhQUFhLGlCQUFpQixhQUFhO0VBRS9DO0VBQ0EsTUFBTSxRQUFRLGVBQWUsZUFBZSxlQUFlLEdBQUcsR0FBRyxDQUFDLENBQUMsVUFDM0QsWUFBWSxDQUNwQjtFQUNBLE1BQU0sRUFBRSxTQUFTLE1BQU0sWUFBWSxJQUFJLHFCQUMvQixNQUFNLFVBQVUsZ0JBQWdCLFFBQVE7R0FBRTtHQUFRLEdBQUc7RUFBUSxDQUFDLENBQUMsQ0FDdkU7RUFDQSxNQUFNLFVBQVUsVUFBVTtHQUN4QixRQUFRLEtBQUs7R0FDYixNQUFNLEtBQUs7RUFDYjtFQUNBLFFBQVEsT0FBTztFQUNmLEtBQUssY0FBYyxPQUFPLE9BQU87RUFDakMsT0FBTyxRQUFRO0NBQ2pCO0NBQ0EsSUFBSSxNQUFNO0VBQ1IsZUFBZTtHQUNiLEtBQUssZ0JBQWdDLHVCQUFPLE9BQU8sSUFBSTtFQUN6RDtFQUNBLFVBQVU7R0FDUixJQUFJLFdBQVcsS0FBSyxTQUFTO0dBQzdCLElBQUksT0FBTyxhQUFhLFlBQ3RCLFdBQVcsU0FBUyxLQUFLLElBQUk7R0FFL0IsSUFBSSxDQUFDLFVBQ0g7R0FDRixLQUFLLE1BQU0sT0FBTyxVQUNoQixLQUFLLFNBQVMsQ0FFWixLQUNBLFNBQVMsTUFDVCxhQUNGO0VBRUo7RUFDQSxnQkFBZ0I7R0FDZCxNQUFNLFVBQVUsZ0JBQWdCLElBQUksSUFBSTtHQUN4QyxJQUFJLFNBQ0YsS0FBSyxNQUFNLE9BQU8sU0FDaEIsUUFBUSxJQUFJLENBQUM7R0FHakIsS0FBSyxnQkFBZ0I7RUFDdkI7Q0FDRixDQUFDO0FBQ0g7QUFDQSxTQUFTLDBCQUEwQixlQUFlO0NBQ2hELFFBQVEsYUFBYSxRQUFRO0VBQzNCLE9BQU8sZUFBZSxLQUFLLGVBQWUsV0FBVztDQUN2RDtBQUNGO0FBRUEsSUFBTSxtQ0FBbUMsSUFBSSxRQUFRO0FBQ3JELFNBQVMsZUFBZSxLQUFLLFNBQVMsT0FBTztDQUMzQyxJQUFJLFdBQVcsUUFBUSxNQUFNO0VBQzNCLFFBQVEsSUFBSSxDQUFDLEtBQUs7RUFDbEIsT0FBTyxRQUFRO0NBQ2pCO0FBQ0Y7QUFFQSxJQUFNLDBCQUEwQjtDQUM5QixVQUFVO0NBQ1YsWUFBWTtBQUNkO0FBQ0EsSUFBTSxrQkFBa0IsU0FBUyxpQkFBaUIsS0FBSyxlQUFlLGFBQWE7Q0FDakYsTUFBTSxnQkFBZ0IsT0FBTyxPQUMzQixDQUFDLEdBQ0QseUJBQ0EsYUFDRjtDQUNBLE1BQU0sRUFBRSxVQUFVLGVBQWU7Q0FDakMsTUFBTSxlQUFlLFNBQVMsSUFBSSxPQUFPLG1CQUFtQixJQUFJO0NBQ2hFLGFBQWEsY0FBYyxTQUFTLGdCQUFnQixLQUFLLE9BQU87RUFDOUQsZUFBZSxLQUFLLGlCQUFpQixJQUFJLElBQUksR0FBRyxLQUFLO0VBQ3JELE9BQU8sS0FBSyxlQUFlO0NBQzdCO0NBQ0EsYUFBYSxZQUFZLFNBQVMsY0FBYyxLQUFLLG9CQUFvQixhQUFhO0VBQ3BGLE1BQU0sVUFBVSxPQUFPLE9BQU8sQ0FBQyxHQUFHLGVBQWUsV0FBVztFQUM1RCxNQUFNLFNBQVMsTUFBTSxLQUFLLE9BQU8sR0FBRztFQUNwQyxJQUFJLENBQUMsaUJBQWlCLElBQUksSUFBSSxHQUM1QixpQkFBaUIsSUFBSSxNQUFNLENBQUMsQ0FBQztFQUUvQixNQUFNLFVBQVUsaUJBQWlCLElBQUksSUFBSTtFQUN6QyxJQUFJLFFBQVEsTUFDVixRQUFRLElBQUksQ0FBQyxRQUFRLEtBQUs7RUFFNUIsTUFBTSxRQUFRLGVBQWUsZUFBZSxlQUFlLEdBQUcsR0FBRyxDQUFDLENBQUMsVUFDM0QsWUFBWSxDQUNwQjtFQUNBLE1BQU0sRUFBRSxTQUFTLE1BQU0sWUFBWSxJQUFJLHFCQUMvQixNQUFNLFVBQ0osaUJBQWlCLG9CQUFvQjtHQUN6QztHQUNBLEdBQUc7RUFDTCxDQUFDLENBQ0gsQ0FDRjtFQUNBLE1BQU0sVUFBVSxVQUFVO0dBQ3hCLFFBQVEsS0FBSztHQUNiLE1BQU0sS0FBSztFQUNiO0VBQ0EsUUFBUSxPQUFPO0VBQ2YsS0FBSyxlQUFlLE9BQ3BCO0VBQ0EsT0FBTyxRQUFRO0NBQ2pCO0NBQ0EsSUFBSSxNQUFNO0VBQ1IsZUFBZTtHQUNiLEtBQUssaUJBQWlDLHVCQUFPLE9BQU8sSUFBSTtFQUMxRDtFQUNBLFVBQVU7R0FDUixNQUFNLEVBQUUsY0FBYyxLQUFLO0dBQzNCLE1BQU0sT0FBTyxPQUFPLGNBQWMsYUFBYSxVQUFVLEtBQUssSUFBSSxJQUFJO0dBQ3RFLElBQUksQ0FBQyxNQUNIO0dBQ0YsS0FBSyxNQUFNLE9BQU8sTUFDaEIsS0FBSyxTQUFTLENBQ1osS0FFQSxLQUFLLE1BQ0wsYUFDRjtFQUVKO0VBQ0EsZ0JBQWdCO0dBQ2QsTUFBTSxVQUFVLGlCQUFpQixJQUFJLElBQUk7R0FDekMsSUFBSSxTQUNGLEtBQUssTUFBTSxVQUFVLFNBQ25CLFFBQVEsT0FBTyxDQUFDO0dBR3BCLEtBQUssaUJBQWlCO0VBQ3hCO0NBQ0YsQ0FBQztBQUNIO0FBQ0EsU0FBUywyQkFBMkIsZUFBZTtDQUNqRCxRQUFRLGFBQWEsUUFBUTtFQUMzQixPQUFPLGdCQUFnQixLQUFLLGVBQWUsV0FBVztDQUN4RDtBQUNGO0FBRUEsU0FBUyxZQUFZLGFBQWE7Q0FDaEMsT0FBTyw0QkFBNEI7RUFDakM7RUFDQSxjQUFjO0dBQ1osdUJBQXVCO0dBQ3ZCLGFBQWE7SUFDWDtJQUNBO0lBQ0E7R0FDRjtFQUNGO0NBQ0YsQ0FBQztBQUNIO0FBQ0EsSUFBTSxrQkFBa0IsT0FBTyxhQUFhO0FBQzVDLFNBQVMsMkJBQTJCLEVBQ2xDLE1BQ0EsZUFDQztDQUNELFFBQVEsYUFBYSxRQUFRO0VBQzNCLE1BQU0sQ0FBQyxNQUFNLFNBQVMsaUJBQ3BCLGFBQ0EsS0FDQSxhQUNBLEtBQUssR0FDTCxJQUNGO0VBQ0Esd0JBQXdCLE1BQU0sS0FBSztDQUNyQztBQUNGO0FBQ0EsU0FBUyw0QkFBNEIsRUFDbkMsY0FDQSxlQUNDO0NBQ0QsUUFBUSxhQUFhLFFBQVE7RUFDM0IsTUFBTSxDQUFDLE1BQU0sUUFBUSxpQkFDbkIsYUFDQSxLQUNBLGFBQ0EsWUFDRjtFQUNBLHdCQUF3QixNQUFNLElBQUk7Q0FDcEM7QUFDRjtBQUNBLFNBQVMsaUJBQWlCLGFBQWEsS0FBSyxhQUFhLGNBQWMsT0FBTyxlQUFlLGFBQWEsWUFBWSxHQUFHO0NBQ3ZILE1BQU0sT0FBTyxlQUFlLGFBQWEsR0FBRyxDQUFDLENBQUMsVUFDdEMsSUFBSSxXQUFXLENBQ3ZCO0NBQ0EsWUFBWSxJQUFJLGFBQWEsSUFBSTtDQUNqQyxJQUFJLFFBQVEsaUJBQWlCLElBQUk7Q0FDakMsT0FBTyxDQUFDLE1BQU0sSUFBSTtBQUNwQjtBQUNBLFNBQVMsZ0JBQWdCLE1BQU07Q0FDN0IsSUFBNkMsUUFBUSxNQUNuRCxRQUFRLEtBQ04sMk1BQ0Y7Q0FFRixPQUFPLFdBQVcsT0FBTyxlQUFlLElBQUk7QUFDOUM7QUFFQSxTQUFTLG1CQUFtQixNQUFNO0NBQ2hDLE9BQU8sV0FBVyxlQUFlLElBQUksQ0FBQztBQUN4QztBQUNBLFNBQVMsa0JBQWtCLFlBQVk7Q0FDckMsTUFBTSxxQkFBcUIsUUFBUSxVQUFVO0NBQzdDLE1BQU0sTUFBTSxJQUFJO0NBQ2hCLElBQUksUUFBUSxnQkFDVixvQkFDQSxLQUFLLEdBQ0wsSUFBSSxPQUNKLGVBQWUsQ0FDakI7Q0FDQSxNQUFNLFVBQVUsV0FBVyxRQUFRLFFBQVEsSUFBSSxDQUFDO0NBQ2hELElBQUksdUJBQXVCO0NBQzNCLFNBQVMsVUFBVTtFQUNqQixNQUFNLGdCQUFnQixRQUFRLFVBQVU7RUFDeEMsSUFBSSxlQUNGLFFBQVEsUUFBUSxlQUFlLGFBQWEsQ0FBQyxDQUFDLE1BQU0sZ0JBQWdCLElBQUksUUFBUSxXQUFXLENBQUMsQ0FBQyxZQUFZLElBQUk7T0FFN0csUUFBUSxRQUFRLFFBQVEsUUFBUSxJQUFJLFFBQVEsSUFBSTtFQUVsRCxPQUFPLFFBQVE7Q0FDakI7Q0FDQSxRQUFRO0NBQ1IsSUFBSSxNQUFNLFVBQVUsS0FBSyxPQUFPLGVBQWUsWUFDN0MsTUFBTSxZQUFZLE9BQU87Q0FFM0IsSUFBSSxvQkFDRix1QkFBdUIsa0JBQWtCLFFBQVEsT0FBTyxrQkFBa0I7Q0FFNUUsSUFBSSxnQkFBZ0IsR0FDbEIsZUFBZSxvQkFBb0I7Q0FFckMsSUFBSSxtQkFBbUIsR0FDckIsdUJBQXVCLFFBQVEsS0FBSztDQUV0QyxPQUFPO0VBQUU7RUFBSztFQUFTO0NBQVE7QUFDakM7QUFDQSxTQUFTLHVCQUF1QixZQUFZO0NBQzFDLE1BQU0scUJBQXFCLFFBQVEsVUFBVTtDQUM3QyxNQUFNLFdBQVcsV0FBVztDQUM1QixJQUFJLG9CQUNGLFNBQVMsUUFBUSxnQkFDZixvQkFFQSxPQUFPLG1CQUFtQixTQUFTLEdBQ25DLFNBQVMsT0FDVCxlQUFlLENBQ2pCO0NBRUYsTUFBTSxVQUFVLFdBQ2QsUUFBUSxRQUFRLElBQUksQ0FDdEI7Q0FDQSxJQUFJLHVCQUF1QjtDQUMzQixTQUFTLFVBQVU7RUFDakIsTUFBTSxnQkFBZ0IsUUFBUSxVQUFVO0VBQ3hDLElBQUksZUFDRixRQUFRLFFBQVEsWUFBWSxhQUFhLENBQUMsQ0FBQyxNQUFNLFNBQVMsU0FBUyxRQUFRLElBQUksQ0FBQyxDQUFDLFlBQVksSUFBSTtPQUVqRyxRQUFRLFFBQVEsUUFBUSxRQUFRLFNBQVMsUUFBUSxJQUFJO0VBRXZELE9BQU8sUUFBUTtDQUNqQjtDQUNBLFNBQVMsT0FBTyxhQUFhO0VBQzNCLE1BQU0sZ0JBQWdCLFFBQVEsVUFBVTtFQUN4QyxJQUFJLGVBQ0YsUUFBUSxRQUFRLGVBQWUsZUFBZSxXQUFXLENBQUMsQ0FBQyxNQUN4RCxZQUFZO0dBQ1gsT0FBTyxTQUFTLFFBQVE7RUFDMUIsQ0FDRjtPQUVBLFFBQVEsS0FBSyx3REFBc0Q7RUFFckUsT0FBTyxRQUFRO0NBQ2pCO0NBQ0EsUUFBUTtDQUNSLElBQUksTUFBTSxVQUFVLEdBQ2xCLE1BQU0sWUFBWSxPQUFPO0NBRTNCLElBQUksb0JBQ0YsdUJBQXVCLGtCQUFrQixRQUFRLE9BQU8sa0JBQWtCO0NBRTVFLElBQUksZ0JBQWdCLEdBQ2xCLGVBQWUsb0JBQW9CO0NBRXJDLElBQUksbUJBQW1CLEdBQ3JCLHVCQUF1QixRQUFRLEtBQUs7Q0FFdEMsT0FBTztFQUFFO0VBQVU7RUFBUTtFQUFTO0NBQVE7QUFDOUM7QUFDQSxTQUFTLGVBQWUsWUFBWTtDQUNsQyxNQUFNLEVBQUUsS0FBSyxTQUFTLGVBQWUsa0JBQWtCLFVBQVU7Q0FDakUsTUFBTSxFQUNKLFVBQ0EsUUFBUSxpQkFDUixTQUFTLG9CQUNQLHVCQUF1QixVQUFVO0NBQ3JDLE1BQU0sYUFBYSxXQUFXO0NBQzlCLE1BQU0sV0FBVyxXQUFXO0NBQzVCLE1BQU0sY0FBYyxXQUFXO0NBQy9CLE1BQU0saUJBQWlCLGVBQWU7RUFDcEMsTUFBTSxPQUFPLFFBQVEsUUFBUTtFQUM3QixPQUFPLE9BQU8sS0FBSyxtQkFBbUIsS0FBSyxhQUFhO0NBQzFELENBQUM7Q0FDRCxJQUFJLFFBQVE7Q0FDWixTQUFTLE9BQU8sU0FBUyxhQUFhO0VBQ3BDLE1BQU0sZ0JBQWdCLFFBQVEsVUFBVTtFQUN4QyxNQUFNLGNBQWMsUUFBUSxVQUFVO0VBQ3RDLElBQUksYUFDRixZQUFZLE9BQU87RUFFckIsWUFBWSxRQUFRO0VBQ3BCLFNBQVMsUUFBUTtFQUNqQixXQUFXLFFBQVE7RUFDbkIsSUFBSSxRQUFRO0VBQ1osU0FBUyxRQUFRO0VBQ2pCLE1BQU07RUFDTixJQUFJLGVBQWU7R0FDakIsTUFBTSxVQUFVLHFCQUFxQixlQUFlLFNBQVMsV0FBVztHQUN4RSxXQUFXLFFBQVE7R0FDbkIsU0FBUyxRQUFRLFFBQVE7R0FDekIsUUFBUSxRQUFRLEdBQUcsa0JBQWtCLGdCQUFnQjtJQUNuRCxTQUFTLFFBQVE7R0FDbkIsQ0FBQztHQUNELE9BQU8sUUFBUSxNQUFNLGtCQUFrQjtJQUNyQyxTQUFTLFFBQVEsY0FBYztJQUMvQixXQUFXO0dBQ2IsQ0FBQyxDQUFDLENBQUMsT0FBTyxRQUFRO0lBQ2hCLFlBQVksUUFBUTtJQUNwQixPQUFPLFFBQVEsT0FBTyxHQUFHO0dBQzNCLENBQUMsQ0FBQyxDQUFDLGNBQWM7SUFDZixNQUFNO0lBQ04sV0FBVyxRQUFRO0dBQ3JCLENBQUM7RUFDSDtDQUNGO0NBQ0EsU0FBUyxVQUFVO0VBQ2pCLE9BQU8sUUFBUSxJQUFJLENBQUMsV0FBVyxHQUFHLGdCQUFnQixDQUFDLENBQUM7Q0FDdEQ7Q0FDQSxJQUFJLE1BQU0sVUFBVSxLQUFLLE9BQU8sZUFBZSxZQUM3QyxNQUFNLGFBQWEsa0JBQWtCO0VBQ25DLElBQUksQ0FBQyxlQUFlO0dBQ2xCLElBQUksV0FBVyxPQUFPO0lBQ3BCLE1BQU07SUFDTixXQUFXLE1BQU0sT0FBTztHQUMxQjtHQUNBLFdBQVcsUUFBUTtHQUNuQixTQUFTLFFBQVE7RUFDbkI7RUFDQSxRQUFRO0NBQ1YsQ0FBQztDQUVILElBQUksZ0JBQWdCLEdBQ2xCLGVBQWUsS0FBSztDQUV0QixPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxnQkFBZ0I7RUFDaEI7Q0FFRjtBQUNGO0FBQ0EsSUFBTSxhQUFhO0FBQ25CLElBQU0sZ0JBQWdCO0FBQ3RCLElBQU0scUJBQXFCO0FBQzNCLElBQU0sbUJBQW1CO0FBRXpCLFNBQVMsUUFBUSxLQUFLLEVBQUUsYUFBYSxVQUFVLENBQUMsS0FBSztDQUNuRCxJQUFJLFFBQVEsMEJBQTBCLFdBQVc7Q0FDakQsS0FBSyxNQUFNLGtCQUFrQixTQUMzQixlQUFlLGFBQWEsR0FBRztBQUVuQyJ9