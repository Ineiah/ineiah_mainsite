import { _getProvider, getApp, _registerComponent, registerVersion } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@firebase+app@0.16.0/node_modules/@firebase/app/dist/esm/index.esm.js?v=7e73afc2";
import { Component } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@firebase+component@0.7.4/node_modules/@firebase/component/dist/esm/index.esm.js?v=7e73afc2";
import { Deferred, ErrorFactory, isIndexedDBAvailable, getGlobal, base64, issuedAtTime, calculateBackoffMillis, getModularInstance } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@firebase+util@1.15.2/node_modules/@firebase/util/dist/index.esm.js?v=7e73afc2";
import { Logger } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@firebase+logger@0.5.1/node_modules/@firebase/logger/dist/esm/index.esm.js?v=7e73afc2";

/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const APP_CHECK_STATES = new Map();
const DEFAULT_STATE = {
    activated: false,
    tokenObservers: []
};
const DEBUG_STATE = {
    initialized: false,
    enabled: false
};
/**
 * Gets a reference to the state object.
 */
function getStateReference(app) {
    return APP_CHECK_STATES.get(app) || { ...DEFAULT_STATE };
}
/**
 * Set once on initialization. The map should hold the same reference to the
 * same object until this entry is deleted.
 */
function setInitialState(app, state) {
    APP_CHECK_STATES.set(app, state);
    return APP_CHECK_STATES.get(app);
}
function getDebugState() {
    return DEBUG_STATE;
}

/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const BASE_ENDPOINT = 'https://content-firebaseappcheck.googleapis.com/v1';
const EXCHANGE_RECAPTCHA_TOKEN_METHOD = 'exchangeRecaptchaV3Token';
const EXCHANGE_RECAPTCHA_ENTERPRISE_TOKEN_METHOD = 'exchangeRecaptchaEnterpriseToken';
const EXCHANGE_DEBUG_TOKEN_METHOD = 'exchangeDebugToken';
const TOKEN_REFRESH_TIME = {
    /**
     * This is the first retrial wait after an error. This is currently
     * 30 seconds.
     */
    RETRIAL_MIN_WAIT: 30 * 1000,
    /**
     * This is the maximum retrial wait, currently 16 minutes.
     */
    RETRIAL_MAX_WAIT: 16 * 60 * 1000
};
/**
 * One day in millis, for certain error code backoffs.
 */
const ONE_DAY = 24 * 60 * 60 * 1000;

/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Port from auth proactiverefresh.js
 *
 */
// TODO: move it to @firebase/util?
// TODO: allow to config whether refresh should happen in the background
class Refresher {
    constructor(operation, retryPolicy, getWaitDuration, lowerBound, upperBound) {
        this.operation = operation;
        this.retryPolicy = retryPolicy;
        this.getWaitDuration = getWaitDuration;
        this.lowerBound = lowerBound;
        this.upperBound = upperBound;
        this.pending = null;
        this.nextErrorWaitInterval = lowerBound;
        if (lowerBound > upperBound) {
            throw new Error('Proactive refresh lower bound greater than upper bound!');
        }
    }
    start() {
        this.nextErrorWaitInterval = this.lowerBound;
        this.process(true).catch(() => {
            /* we don't care about the result */
        });
    }
    stop() {
        if (this.pending) {
            this.pending.reject('cancelled');
            this.pending = null;
        }
    }
    isRunning() {
        return !!this.pending;
    }
    async process(hasSucceeded) {
        this.stop();
        try {
            this.pending = new Deferred();
            this.pending.promise.catch(_e => {
                /* ignore */
            });
            await sleep(this.getNextRun(hasSucceeded));
            // Why do we resolve a promise, then immediate wait for it?
            // We do it to make the promise chain cancellable.
            // We can call stop() which rejects the promise before the following line execute, which makes
            // the code jump to the catch block.
            // TODO: unit test this
            this.pending.resolve();
            await this.pending.promise;
            this.pending = new Deferred();
            this.pending.promise.catch(_e => {
                /* ignore */
            });
            await this.operation();
            this.pending.resolve();
            await this.pending.promise;
            this.process(true).catch(() => {
                /* we don't care about the result */
            });
        }
        catch (error) {
            if (this.retryPolicy(error)) {
                this.process(false).catch(() => {
                    /* we don't care about the result */
                });
            }
            else {
                this.stop();
            }
        }
    }
    getNextRun(hasSucceeded) {
        if (hasSucceeded) {
            // If last operation succeeded, reset next error wait interval and return
            // the default wait duration.
            this.nextErrorWaitInterval = this.lowerBound;
            // Return typical wait duration interval after a successful operation.
            return this.getWaitDuration();
        }
        else {
            // Get next error wait interval.
            const currentErrorWaitInterval = this.nextErrorWaitInterval;
            // Double interval for next consecutive error.
            this.nextErrorWaitInterval *= 2;
            // Make sure next wait interval does not exceed the maximum upper bound.
            if (this.nextErrorWaitInterval > this.upperBound) {
                this.nextErrorWaitInterval = this.upperBound;
            }
            return currentErrorWaitInterval;
        }
    }
}
function sleep(ms) {
    return new Promise(resolve => {
        setTimeout(resolve, ms);
    });
}

/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ERRORS = {
    ["already-initialized" /* AppCheckError.ALREADY_INITIALIZED */]: 'You have already called initializeAppCheck() for FirebaseApp {$appName} with ' +
        'different options. To avoid this error, call initializeAppCheck() with the ' +
        'same options as when it was originally called. This will return the ' +
        'already initialized instance.',
    ["use-before-activation" /* AppCheckError.USE_BEFORE_ACTIVATION */]: 'App Check is being used before initializeAppCheck() is called for FirebaseApp {$appName}. ' +
        'Call initializeAppCheck() before instantiating other Firebase services.',
    ["fetch-network-error" /* AppCheckError.FETCH_NETWORK_ERROR */]: 'Fetch failed to connect to a network. Check Internet connection. ' +
        'Original error: {$originalErrorMessage}.',
    ["fetch-parse-error" /* AppCheckError.FETCH_PARSE_ERROR */]: 'Fetch client could not parse response.' +
        ' Original error: {$originalErrorMessage}.',
    ["fetch-status-error" /* AppCheckError.FETCH_STATUS_ERROR */]: 'Fetch server returned an HTTP error status. HTTP status: {$httpStatus}.',
    ["storage-open" /* AppCheckError.STORAGE_OPEN */]: 'Error thrown when opening storage. Original error: {$originalErrorMessage}.',
    ["storage-get" /* AppCheckError.STORAGE_GET */]: 'Error thrown when reading from storage. Original error: {$originalErrorMessage}.',
    ["storage-set" /* AppCheckError.STORAGE_WRITE */]: 'Error thrown when writing to storage. Original error: {$originalErrorMessage}.',
    ["recaptcha-error" /* AppCheckError.RECAPTCHA_ERROR */]: 'ReCAPTCHA error.',
    ["initial-throttle" /* AppCheckError.INITIAL_THROTTLE */]: `{$httpStatus} error. Attempts allowed again after {$time}`,
    ["throttled" /* AppCheckError.THROTTLED */]: `Requests throttled due to previous {$httpStatus} error. Attempts allowed again after {$time}`
};
const ERROR_FACTORY = new ErrorFactory('appCheck', 'AppCheck', ERRORS);

/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function getRecaptcha(isEnterprise = false) {
    if (isEnterprise) {
        return self.grecaptcha?.enterprise;
    }
    return self.grecaptcha;
}
function ensureActivated(app) {
    if (!getStateReference(app).activated) {
        throw ERROR_FACTORY.create("use-before-activation" /* AppCheckError.USE_BEFORE_ACTIVATION */, {
            appName: app.name
        });
    }
}
function getDurationString(durationInMillis) {
    const totalSeconds = Math.round(durationInMillis / 1000);
    const days = Math.floor(totalSeconds / (3600 * 24));
    const hours = Math.floor((totalSeconds - days * 3600 * 24) / 3600);
    const minutes = Math.floor((totalSeconds - days * 3600 * 24 - hours * 3600) / 60);
    const seconds = totalSeconds - days * 3600 * 24 - hours * 3600 - minutes * 60;
    let result = '';
    if (days) {
        result += pad(days) + 'd:';
    }
    if (hours) {
        result += pad(hours) + 'h:';
    }
    result += pad(minutes) + 'm:' + pad(seconds) + 's';
    return result;
}
function pad(value) {
    if (value === 0) {
        return '00';
    }
    return value >= 10 ? value.toString() : '0' + value;
}

/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function exchangeToken({ url, body }, heartbeatServiceProvider) {
    const headers = {
        'Content-Type': 'application/json'
    };
    // If heartbeat service exists, add heartbeat header string to the header.
    const heartbeatService = heartbeatServiceProvider.getImmediate({
        optional: true
    });
    if (heartbeatService) {
        const heartbeatsHeader = await heartbeatService.getHeartbeatsHeader();
        if (heartbeatsHeader) {
            headers['X-Firebase-Client'] = heartbeatsHeader;
        }
    }
    const options = {
        method: 'POST',
        body: JSON.stringify(body),
        headers
    };
    let response;
    try {
        response = await fetch(url, options);
    }
    catch (originalError) {
        throw ERROR_FACTORY.create("fetch-network-error" /* AppCheckError.FETCH_NETWORK_ERROR */, {
            originalErrorMessage: originalError?.message
        });
    }
    if (response.status !== 200) {
        throw ERROR_FACTORY.create("fetch-status-error" /* AppCheckError.FETCH_STATUS_ERROR */, {
            httpStatus: response.status
        });
    }
    let responseBody;
    try {
        // JSON parsing throws SyntaxError if the response body isn't a JSON string.
        responseBody = await response.json();
    }
    catch (originalError) {
        throw ERROR_FACTORY.create("fetch-parse-error" /* AppCheckError.FETCH_PARSE_ERROR */, {
            originalErrorMessage: originalError?.message
        });
    }
    // Protobuf duration format.
    // https://developers.google.com/protocol-buffers/docs/reference/java/com/google/protobuf/Duration
    const match = responseBody.ttl.match(/^([\d.]+)(s)$/);
    if (!match || !match[2] || isNaN(Number(match[1]))) {
        throw ERROR_FACTORY.create("fetch-parse-error" /* AppCheckError.FETCH_PARSE_ERROR */, {
            originalErrorMessage: `ttl field (timeToLive) is not in standard Protobuf Duration ` +
                `format: ${responseBody.ttl}`
        });
    }
    const timeToLiveAsNumber = Number(match[1]) * 1000;
    const now = Date.now();
    return {
        token: responseBody.token,
        expireTimeMillis: now + timeToLiveAsNumber,
        issuedAtTimeMillis: now
    };
}
function getExchangeRecaptchaV3TokenRequest(app, reCAPTCHAToken) {
    const { projectId, appId, apiKey } = app.options;
    return {
        url: `${BASE_ENDPOINT}/projects/${projectId}/apps/${appId}:${EXCHANGE_RECAPTCHA_TOKEN_METHOD}?key=${apiKey}`,
        body: {
            'recaptcha_v3_token': reCAPTCHAToken
        }
    };
}
function getExchangeRecaptchaEnterpriseTokenRequest(app, reCAPTCHAToken) {
    const { projectId, appId, apiKey } = app.options;
    return {
        url: `${BASE_ENDPOINT}/projects/${projectId}/apps/${appId}:${EXCHANGE_RECAPTCHA_ENTERPRISE_TOKEN_METHOD}?key=${apiKey}`,
        body: {
            'recaptcha_enterprise_token': reCAPTCHAToken
        }
    };
}
function getExchangeDebugTokenRequest(app, debugToken) {
    const { projectId, appId, apiKey } = app.options;
    return {
        url: `${BASE_ENDPOINT}/projects/${projectId}/apps/${appId}:${EXCHANGE_DEBUG_TOKEN_METHOD}?key=${apiKey}`,
        body: {
            // eslint-disable-next-line
            debug_token: debugToken
        }
    };
}

/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const DB_NAME = 'firebase-app-check-database';
const DB_VERSION = 1;
const STORE_NAME = 'firebase-app-check-store';
const DEBUG_TOKEN_KEY = 'debug-token';
let dbPromise = null;
function getDBPromise() {
    if (dbPromise) {
        return dbPromise;
    }
    dbPromise = new Promise((resolve, reject) => {
        try {
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            request.onsuccess = event => {
                resolve(event.target.result);
            };
            request.onerror = event => {
                reject(ERROR_FACTORY.create("storage-open" /* AppCheckError.STORAGE_OPEN */, {
                    originalErrorMessage: event.target.error?.message
                }));
            };
            request.onupgradeneeded = event => {
                const db = event.target.result;
                // We don't use 'break' in this switch statement, the fall-through
                // behavior is what we want, because if there are multiple versions between
                // the old version and the current version, we want ALL the migrations
                // that correspond to those versions to run, not only the last one.
                // eslint-disable-next-line default-case
                switch (event.oldVersion) {
                    case 0:
                        db.createObjectStore(STORE_NAME, {
                            keyPath: 'compositeKey'
                        });
                }
            };
        }
        catch (e) {
            reject(ERROR_FACTORY.create("storage-open" /* AppCheckError.STORAGE_OPEN */, {
                originalErrorMessage: e?.message
            }));
        }
    });
    return dbPromise;
}
function readTokenFromIndexedDB(app) {
    return read(computeKey(app));
}
function writeTokenToIndexedDB(app, token) {
    return write(computeKey(app), token);
}
function writeDebugTokenToIndexedDB(token) {
    return write(DEBUG_TOKEN_KEY, token);
}
function readDebugTokenFromIndexedDB() {
    return read(DEBUG_TOKEN_KEY);
}
async function write(key, value) {
    const db = await getDBPromise();
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.put({
        compositeKey: key,
        value
    });
    return new Promise((resolve, reject) => {
        request.onsuccess = _event => {
            resolve();
        };
        transaction.onerror = event => {
            reject(ERROR_FACTORY.create("storage-set" /* AppCheckError.STORAGE_WRITE */, {
                originalErrorMessage: event.target.error?.message
            }));
        };
    });
}
async function read(key) {
    const db = await getDBPromise();
    const transaction = db.transaction(STORE_NAME, 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.get(key);
    return new Promise((resolve, reject) => {
        request.onsuccess = event => {
            const result = event.target.result;
            if (result) {
                resolve(result.value);
            }
            else {
                resolve(undefined);
            }
        };
        transaction.onerror = event => {
            reject(ERROR_FACTORY.create("storage-get" /* AppCheckError.STORAGE_GET */, {
                originalErrorMessage: event.target.error?.message
            }));
        };
    });
}
function computeKey(app) {
    return `${app.options.appId}-${app.name}`;
}

/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const logger = new Logger('@firebase/app-check');

/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Always resolves. In case of an error reading from indexeddb, resolve with undefined
 */
async function readTokenFromStorage(app) {
    if (isIndexedDBAvailable()) {
        let token = undefined;
        try {
            token = await readTokenFromIndexedDB(app);
        }
        catch (e) {
            // swallow the error and return undefined
            logger.warn(`Failed to read token from IndexedDB. Error: ${e}`);
        }
        return token;
    }
    return undefined;
}
/**
 * Always resolves. In case of an error writing to indexeddb, print a warning and resolve the promise
 */
function writeTokenToStorage(app, token) {
    if (isIndexedDBAvailable()) {
        return writeTokenToIndexedDB(app, token).catch(e => {
            // swallow the error and resolve the promise
            logger.warn(`Failed to write token to IndexedDB. Error: ${e}`);
        });
    }
    return Promise.resolve();
}
async function readOrCreateDebugTokenFromStorage() {
    /**
     * Theoretically race condition can happen if we read, then write in 2 separate transactions.
     * But it won't happen here, because this function will be called exactly once.
     */
    let existingDebugToken = undefined;
    try {
        existingDebugToken = await readDebugTokenFromIndexedDB();
    }
    catch (_e) {
        // failed to read from indexeddb. We assume there is no existing debug token, and generate a new one.
    }
    if (!existingDebugToken) {
        // create a new debug token
        // This function is only available in secure contexts. See https://developer.mozilla.org/en-US/docs/Web/Security/Secure_Contexts
        const newToken = crypto.randomUUID();
        // We don't need to block on writing to indexeddb
        // In case persistence failed, a new debug token will be generated every time the page is refreshed.
        // It renders the debug token useless because you have to manually register(whitelist) the new token in the firebase console again and again.
        // If you see this error trying to use debug token, it probably means you are using a browser that doesn't support indexeddb.
        // You should switch to a different browser that supports indexeddb
        writeDebugTokenToIndexedDB(newToken).catch(e => logger.warn(`Failed to persist debug token to IndexedDB. Error: ${e}`));
        return newToken;
    }
    else {
        return existingDebugToken;
    }
}

/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function isDebugMode() {
    const debugState = getDebugState();
    return debugState.enabled;
}
async function getDebugToken() {
    const state = getDebugState();
    if (state.enabled && state.token) {
        return state.token.promise;
    }
    else {
        // should not happen!
        throw Error(`
            Can't get debug token in production mode.
        `);
    }
}
function initializeDebugMode() {
    const globals = getGlobal();
    const debugState = getDebugState();
    // Set to true if this function has been called, whether or not
    // it enabled debug mode.
    debugState.initialized = true;
    if (typeof globals.FIREBASE_APPCHECK_DEBUG_TOKEN !== 'string' &&
        globals.FIREBASE_APPCHECK_DEBUG_TOKEN !== true) {
        return;
    }
    debugState.enabled = true;
    const deferredToken = new Deferred();
    debugState.token = deferredToken;
    if (typeof globals.FIREBASE_APPCHECK_DEBUG_TOKEN === 'string') {
        deferredToken.resolve(globals.FIREBASE_APPCHECK_DEBUG_TOKEN);
    }
    else {
        deferredToken.resolve(readOrCreateDebugTokenFromStorage());
    }
}

/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// Initial hardcoded value agreed upon across platforms for initial launch.
// Format left open for possible dynamic error values and other fields in the future.
const defaultTokenErrorData = { error: 'UNKNOWN_ERROR' };
/**
 * Stringify and base64 encode token error data.
 *
 * @param tokenError Error data, currently hardcoded.
 */
function formatDummyToken(tokenErrorData) {
    return base64.encodeString(JSON.stringify(tokenErrorData), 
    /* webSafe= */ false);
}
/**
 * This function always resolves.
 * The result will contain an error field if there is any error.
 * In case there is an error, the token field in the result will be populated with a dummy value
 */
async function getToken$2(appCheck, forceRefresh = false, shouldLogErrors = false) {
    const app = appCheck.app;
    ensureActivated(app);
    const state = getStateReference(app);
    /**
     * First check if there is a token in memory from a previous `getToken()` call.
     */
    let token = state.token;
    let error = undefined;
    /**
     * If an invalid token was found in memory, clear token from
     * memory and unset the local variable `token`.
     */
    if (token && !isValid(token)) {
        state.token = undefined;
        token = undefined;
    }
    /**
     * If there is no valid token in memory, try to load token from indexedDB.
     */
    if (!token) {
        // cachedTokenPromise contains the token found in IndexedDB or undefined if not found.
        const cachedToken = await state.cachedTokenPromise;
        if (cachedToken) {
            if (isValid(cachedToken)) {
                token = cachedToken;
            }
            else {
                // If there was an invalid token in the indexedDB cache, clear it.
                await writeTokenToStorage(app, undefined);
            }
        }
    }
    // Return the cached token (from either memory or indexedDB) if it's valid
    if (!forceRefresh && token && isValid(token)) {
        return {
            token: token.token
        };
    }
    // Only set to true if this `getToken()` call is making the actual
    // REST call to the exchange endpoint, versus waiting for an already
    // in-flight call (see debug and regular exchange endpoint paths below)
    let shouldCallListeners = false;
    /**
     * DEBUG MODE
     * If debug mode is set, and there is no cached token, fetch a new App
     * Check token using the debug token, and return it directly.
     */
    if (isDebugMode()) {
        try {
            const debugToken = await getDebugToken();
            // Avoid making another call to the exchange endpoint if one is in flight.
            if (!state.exchangeTokenPromise) {
                state.exchangeTokenPromise = exchangeToken(getExchangeDebugTokenRequest(app, debugToken), appCheck.heartbeatServiceProvider).finally(() => {
                    // Clear promise when settled - either resolved or rejected.
                    state.exchangeTokenPromise = undefined;
                });
                shouldCallListeners = true;
            }
            const tokenFromDebugExchange = await state.exchangeTokenPromise;
            // Write debug token to indexedDB.
            await writeTokenToStorage(app, tokenFromDebugExchange);
            // Write debug token to state.
            state.token = tokenFromDebugExchange;
            return { token: tokenFromDebugExchange.token };
        }
        catch (e) {
            if (e.code === `appCheck/${"throttled" /* AppCheckError.THROTTLED */}` ||
                e.code ===
                    `appCheck/${"initial-throttle" /* AppCheckError.INITIAL_THROTTLE */}`) {
                // Warn if throttled, but do not treat it as an error.
                logger.warn(e.message);
            }
            else if (shouldLogErrors) {
                logger.error(e);
            }
            // Return dummy token and error
            return makeDummyTokenResult(e);
        }
    }
    /**
     * There are no valid tokens in memory or indexedDB and we are not in
     * debug mode.
     * Request a new token from the exchange endpoint.
     */
    try {
        // Avoid making another call to the exchange endpoint if one is in flight.
        if (!state.exchangeTokenPromise) {
            // state.provider is populated in initializeAppCheck()
            // ensureActivated() at the top of this function checks that
            // initializeAppCheck() has been called.
            state.exchangeTokenPromise = state.provider.getToken().finally(() => {
                // Clear promise when settled - either resolved or rejected.
                state.exchangeTokenPromise = undefined;
            });
            shouldCallListeners = true;
        }
        token = await getStateReference(app).exchangeTokenPromise;
    }
    catch (e) {
        if (e.code === `appCheck/${"throttled" /* AppCheckError.THROTTLED */}` ||
            e.code === `appCheck/${"initial-throttle" /* AppCheckError.INITIAL_THROTTLE */}`) {
            // Warn if throttled, but do not treat it as an error.
            logger.warn(e.message);
        }
        else if (shouldLogErrors) {
            logger.error(e);
        }
        // Always save error to be added to dummy token.
        error = e;
    }
    let interopTokenResult;
    if (!token) {
        // If token is undefined, there must be an error.
        // Return a dummy token along with the error.
        interopTokenResult = makeDummyTokenResult(error);
    }
    else if (error) {
        if (isValid(token)) {
            // It's also possible a valid token exists, but there's also an error.
            // (Such as if the token is almost expired, tries to refresh, and
            // the exchange request fails.)
            // We add a special error property here so that the refresher will
            // count this as a failed attempt and use the backoff instead of
            // retrying repeatedly with no delay, but any 3P listeners will not
            // be hindered in getting the still-valid token.
            interopTokenResult = {
                token: token.token,
                internalError: error
            };
        }
        else {
            // No invalid tokens should make it to this step. Memory and cached tokens
            // are checked. Other tokens are from fresh exchanges. But just in case.
            interopTokenResult = makeDummyTokenResult(error);
        }
    }
    else {
        interopTokenResult = {
            token: token.token
        };
        // write the new token to the memory state as well as the persistent storage.
        // Only do it if we got a valid new token
        state.token = token;
        await writeTokenToStorage(app, token);
    }
    if (shouldCallListeners) {
        notifyTokenListeners(app, interopTokenResult);
    }
    return interopTokenResult;
}
/**
 * Internal API for limited use tokens. Skips all FAC state and simply calls
 * the underlying provider.
 */
async function getLimitedUseToken$1(appCheck) {
    const app = appCheck.app;
    ensureActivated(app);
    const { provider } = getStateReference(app);
    if (isDebugMode()) {
        const debugToken = await getDebugToken();
        const request = getExchangeDebugTokenRequest(app, debugToken);
        request.body['limited_use'] = true;
        const { token } = await exchangeToken(request, appCheck.heartbeatServiceProvider);
        return { token };
    }
    else {
        // provider is definitely valid since we ensure AppCheck was activated
        const { token } = await provider.getToken(true /* isLimitedUse */);
        return { token };
    }
}
function addTokenListener(appCheck, type, listener, onError) {
    const { app } = appCheck;
    const state = getStateReference(app);
    const tokenObserver = {
        next: listener,
        error: onError,
        type
    };
    state.tokenObservers = [...state.tokenObservers, tokenObserver];
    // Invoke the listener async immediately if there is a valid token
    // in memory.
    if (state.token && isValid(state.token)) {
        const validToken = state.token;
        Promise.resolve()
            .then(() => {
            listener({ token: validToken.token });
            initTokenRefresher(appCheck);
        })
            .catch(() => {
            /* we don't care about exceptions thrown in listeners */
        });
    }
    /**
     * Wait for any cached token promise to resolve before starting the token
     * refresher. The refresher checks to see if there is an existing token
     * in state and calls the exchange endpoint if not. We should first let the
     * IndexedDB check have a chance to populate state if it can.
     *
     * Listener call isn't needed here because cachedTokenPromise will call any
     * listeners that exist when it resolves.
     */
    // state.cachedTokenPromise is always populated in `activate()`.
    void state.cachedTokenPromise.then(() => initTokenRefresher(appCheck));
}
function removeTokenListener(app, listener) {
    const state = getStateReference(app);
    const newObservers = state.tokenObservers.filter(tokenObserver => tokenObserver.next !== listener);
    if (newObservers.length === 0 &&
        state.tokenRefresher &&
        state.tokenRefresher.isRunning()) {
        state.tokenRefresher.stop();
    }
    state.tokenObservers = newObservers;
}
/**
 * Logic to create and start refresher as needed.
 */
function initTokenRefresher(appCheck) {
    const { app } = appCheck;
    const state = getStateReference(app);
    // Create the refresher but don't start it if `isTokenAutoRefreshEnabled`
    // is not true.
    let refresher = state.tokenRefresher;
    if (!refresher) {
        refresher = createTokenRefresher(appCheck);
        state.tokenRefresher = refresher;
    }
    if (!refresher.isRunning() && state.isTokenAutoRefreshEnabled) {
        refresher.start();
    }
}
function createTokenRefresher(appCheck) {
    const { app } = appCheck;
    return new Refresher(
    // Keep in mind when this fails for any reason other than the ones
    // for which we should retry, it will effectively stop the proactive refresh.
    async () => {
        const state = getStateReference(app);
        // If there is no token, we will try to load it from storage and use it
        // If there is a token, we force refresh it because we know it's going to expire soon
        let result;
        if (!state.token) {
            result = await getToken$2(appCheck);
        }
        else {
            result = await getToken$2(appCheck, true);
        }
        /**
         * getToken() always resolves. In case the result has an error field defined, it means
         * the operation failed, and we should retry.
         */
        if (result.error) {
            throw result.error;
        }
        /**
         * A special `internalError` field reflects that there was an error
         * getting a new token from the exchange endpoint, but there's still a
         * previous token that's valid for now and this should be passed to 2P/3P
         * requests for a token. But we want this callback (`this.operation` in
         * `Refresher`) to throw in order to kick off the Refresher's retry
         * backoff. (Setting `hasSucceeded` to false.)
         */
        if (result.internalError) {
            throw result.internalError;
        }
    }, () => {
        return true;
    }, () => {
        const state = getStateReference(app);
        if (state.token) {
            // issuedAtTime + (50% * total TTL) + 5 minutes
            let nextRefreshTimeMillis = state.token.issuedAtTimeMillis +
                (state.token.expireTimeMillis - state.token.issuedAtTimeMillis) *
                    0.5 +
                5 * 60 * 1000;
            // Do not allow refresh time to be past (expireTime - 5 minutes)
            const latestAllowableRefresh = state.token.expireTimeMillis - 5 * 60 * 1000;
            nextRefreshTimeMillis = Math.min(nextRefreshTimeMillis, latestAllowableRefresh);
            return Math.max(0, nextRefreshTimeMillis - Date.now());
        }
        else {
            return 0;
        }
    }, TOKEN_REFRESH_TIME.RETRIAL_MIN_WAIT, TOKEN_REFRESH_TIME.RETRIAL_MAX_WAIT);
}
function notifyTokenListeners(app, token) {
    const observers = getStateReference(app).tokenObservers;
    for (const observer of observers) {
        try {
            if (observer.type === "EXTERNAL" /* ListenerType.EXTERNAL */ && token.error != null) {
                // If this listener was added by a 3P call, send any token error to
                // the supplied error handler. A 3P observer always has an error
                // handler.
                observer.error(token.error);
            }
            else {
                // If the token has no error field, always return the token.
                // If this is a 2P listener, return the token, whether or not it
                // has an error field.
                observer.next(token);
            }
        }
        catch (e) {
            // Errors in the listener function itself are always ignored.
        }
    }
}
function isValid(token) {
    return token.expireTimeMillis - Date.now() > 0;
}
function makeDummyTokenResult(error) {
    return {
        token: formatDummyToken(defaultTokenErrorData),
        error
    };
}

/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * AppCheck Service class.
 */
class AppCheckService {
    constructor(app, heartbeatServiceProvider) {
        this.app = app;
        this.heartbeatServiceProvider = heartbeatServiceProvider;
    }
    _delete() {
        const { tokenObservers } = getStateReference(this.app);
        for (const tokenObserver of tokenObservers) {
            removeTokenListener(this.app, tokenObserver.next);
        }
        return Promise.resolve();
    }
}
function factory(app, heartbeatServiceProvider) {
    return new AppCheckService(app, heartbeatServiceProvider);
}
function internalFactory(appCheck) {
    return {
        getToken: forceRefresh => getToken$2(appCheck, forceRefresh),
        getLimitedUseToken: () => getLimitedUseToken$1(appCheck),
        addTokenListener: listener => addTokenListener(appCheck, "INTERNAL" /* ListenerType.INTERNAL */, listener),
        removeTokenListener: listener => removeTokenListener(appCheck.app, listener)
    };
}

const name = "@firebase/app-check";
const version = "0.13.0";

/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const RECAPTCHA_URL = 'https://www.google.com/recaptcha/api.js';
const RECAPTCHA_ENTERPRISE_URL = 'https://www.google.com/recaptcha/enterprise.js';
function initializeV3(app, siteKey) {
    const initialized = new Deferred();
    const state = getStateReference(app);
    state.reCAPTCHAState = { initialized };
    const divId = makeDiv(app);
    const grecaptcha = getRecaptcha(false);
    if (!grecaptcha) {
        loadReCAPTCHAV3Script(() => {
            const grecaptcha = getRecaptcha(false);
            if (!grecaptcha) {
                // it shouldn't happen.
                throw new Error('no recaptcha');
            }
            queueWidgetRender(app, siteKey, grecaptcha, divId, initialized);
        });
    }
    else {
        queueWidgetRender(app, siteKey, grecaptcha, divId, initialized);
    }
    return initialized.promise;
}
function initializeEnterprise(app, siteKey) {
    const initialized = new Deferred();
    const state = getStateReference(app);
    state.reCAPTCHAState = { initialized };
    const divId = makeDiv(app);
    const grecaptcha = getRecaptcha(true);
    if (!grecaptcha) {
        loadReCAPTCHAEnterpriseScript(() => {
            const grecaptcha = getRecaptcha(true);
            if (!grecaptcha) {
                // it shouldn't happen.
                throw new Error('no recaptcha');
            }
            queueWidgetRender(app, siteKey, grecaptcha, divId, initialized);
        });
    }
    else {
        queueWidgetRender(app, siteKey, grecaptcha, divId, initialized);
    }
    return initialized.promise;
}
/**
 * Add listener to render the widget and resolve the promise when
 * the grecaptcha.ready() event fires.
 */
function queueWidgetRender(app, siteKey, grecaptcha, container, initialized) {
    grecaptcha.ready(() => {
        // Invisible widgets allow us to set a different siteKey for each widget,
        // so we use them to support multiple apps
        renderInvisibleWidget(app, siteKey, grecaptcha, container);
        initialized.resolve(grecaptcha);
    });
}
/**
 * Add invisible div to page.
 */
function makeDiv(app) {
    const divId = `fire_app_check_${app.name}`;
    const invisibleDiv = document.createElement('div');
    invisibleDiv.id = divId;
    invisibleDiv.style.display = 'none';
    document.body.appendChild(invisibleDiv);
    return divId;
}
async function getToken$1(app) {
    ensureActivated(app);
    // ensureActivated() guarantees that reCAPTCHAState is set
    const reCAPTCHAState = getStateReference(app).reCAPTCHAState;
    const recaptcha = await reCAPTCHAState.initialized.promise;
    return new Promise((resolve, _reject) => {
        // Updated after initialization is complete.
        const reCAPTCHAState = getStateReference(app).reCAPTCHAState;
        recaptcha.ready(() => {
            resolve(
            // widgetId is guaranteed to be available if reCAPTCHAState.initialized.promise resolved.
            recaptcha.execute(reCAPTCHAState.widgetId, {
                action: 'fire_app_check'
            }));
        });
    });
}
/**
 *
 * @param app
 * @param container - Id of a HTML element.
 */
function renderInvisibleWidget(app, siteKey, grecaptcha, container) {
    const widgetId = grecaptcha.render(container, {
        sitekey: siteKey,
        size: 'invisible',
        // Success callback - set state
        callback: () => {
            getStateReference(app).reCAPTCHAState.succeeded = true;
        },
        // Failure callback - set state
        'error-callback': () => {
            getStateReference(app).reCAPTCHAState.succeeded = false;
        }
    });
    const state = getStateReference(app);
    state.reCAPTCHAState = {
        ...state.reCAPTCHAState, // state.reCAPTCHAState is set in the initialize()
        widgetId
    };
}
function loadReCAPTCHAV3Script(onload) {
    const script = document.createElement('script');
    script.src = RECAPTCHA_URL;
    script.onload = onload;
    document.head.appendChild(script);
}
function loadReCAPTCHAEnterpriseScript(onload) {
    const script = document.createElement('script');
    // This param is required when we plan to render a widget explicitly.
    script.src = RECAPTCHA_ENTERPRISE_URL + '?render=explicit';
    script.onload = onload;
    document.head.appendChild(script);
}

/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * App Check provider that can obtain a reCAPTCHA V3 token and exchange it
 * for an App Check token.
 *
 * @public
 */
class ReCaptchaV3Provider {
    /**
     * Create a ReCaptchaV3Provider instance.
     * @param siteKey - ReCAPTCHA V3 siteKey.
     */
    constructor(_siteKey) {
        this._siteKey = _siteKey;
        /**
         * Throttle requests on certain error codes to prevent too many retries
         * in a short time.
         */
        this._throttleData = null;
    }
    /**
     * Returns an App Check token.
     * @internal
     */
    async getToken(isLimitedUse = false) {
        throwIfThrottled(this._throttleData);
        // Top-level `getToken()` has already checked that App Check is initialized
        // and therefore this._app and this._heartbeatServiceProvider are available.
        const attestedClaimsToken = await getToken$1(this._app).catch(_e => {
            // reCaptcha.execute() throws null which is not very descriptive.
            throw ERROR_FACTORY.create("recaptcha-error" /* AppCheckError.RECAPTCHA_ERROR */);
        });
        // Check if a failure state was set by the recaptcha "error-callback".
        if (!getStateReference(this._app).reCAPTCHAState?.succeeded) {
            throw ERROR_FACTORY.create("recaptcha-error" /* AppCheckError.RECAPTCHA_ERROR */);
        }
        let result;
        try {
            const request = getExchangeRecaptchaV3TokenRequest(this._app, attestedClaimsToken);
            if (isLimitedUse) {
                request.body['limited_use'] = true;
            }
            result = await exchangeToken(request, this._heartbeatServiceProvider);
        }
        catch (e) {
            if (e.code?.includes("fetch-status-error" /* AppCheckError.FETCH_STATUS_ERROR */)) {
                this._throttleData = setBackoff(Number(e.customData?.httpStatus), this._throttleData);
                throw ERROR_FACTORY.create("initial-throttle" /* AppCheckError.INITIAL_THROTTLE */, {
                    time: getDurationString(this._throttleData.allowRequestsAfter - Date.now()),
                    httpStatus: this._throttleData.httpStatus
                });
            }
            else {
                throw e;
            }
        }
        // If successful, clear throttle data.
        this._throttleData = null;
        return result;
    }
    /**
     * @internal
     */
    initialize(app) {
        this._app = app;
        this._heartbeatServiceProvider = _getProvider(app, 'heartbeat');
        initializeV3(app, this._siteKey).catch(() => {
            /* we don't care about the initialization result */
        });
    }
    /**
     * @internal
     */
    isEqual(otherProvider) {
        if (otherProvider instanceof ReCaptchaV3Provider) {
            return this._siteKey === otherProvider._siteKey;
        }
        else {
            return false;
        }
    }
}
/**
 * App Check provider that can obtain a reCAPTCHA Enterprise token and exchange it
 * for an App Check token.
 *
 * @public
 */
class ReCaptchaEnterpriseProvider {
    /**
     * Create a ReCaptchaEnterpriseProvider instance.
     * @param siteKey - reCAPTCHA Enterprise score-based site key.
     */
    constructor(_siteKey) {
        this._siteKey = _siteKey;
        /**
         * Throttle requests on certain error codes to prevent too many retries
         * in a short time.
         */
        this._throttleData = null;
    }
    /**
     * Returns an App Check token.
     * @internal
     */
    async getToken(isLimitedUse = false) {
        throwIfThrottled(this._throttleData);
        // Top-level `getToken()` has already checked that App Check is initialized
        // and therefore this._app and this._heartbeatServiceProvider are available.
        const attestedClaimsToken = await getToken$1(this._app).catch(_e => {
            // reCaptcha.execute() throws null which is not very descriptive.
            throw ERROR_FACTORY.create("recaptcha-error" /* AppCheckError.RECAPTCHA_ERROR */);
        });
        // Check if a failure state was set by the recaptcha "error-callback".
        if (!getStateReference(this._app).reCAPTCHAState?.succeeded) {
            throw ERROR_FACTORY.create("recaptcha-error" /* AppCheckError.RECAPTCHA_ERROR */);
        }
        let result;
        try {
            const request = getExchangeRecaptchaEnterpriseTokenRequest(this._app, attestedClaimsToken);
            if (isLimitedUse) {
                request.body['limited_use'] = true;
            }
            result = await exchangeToken(request, this._heartbeatServiceProvider);
        }
        catch (e) {
            if (e.code?.includes("fetch-status-error" /* AppCheckError.FETCH_STATUS_ERROR */)) {
                this._throttleData = setBackoff(Number(e.customData?.httpStatus), this._throttleData);
                throw ERROR_FACTORY.create("initial-throttle" /* AppCheckError.INITIAL_THROTTLE */, {
                    time: getDurationString(this._throttleData.allowRequestsAfter - Date.now()),
                    httpStatus: this._throttleData.httpStatus
                });
            }
            else {
                throw e;
            }
        }
        // If successful, clear throttle data.
        this._throttleData = null;
        return result;
    }
    /**
     * @internal
     */
    initialize(app) {
        this._app = app;
        this._heartbeatServiceProvider = _getProvider(app, 'heartbeat');
        initializeEnterprise(app, this._siteKey).catch(() => {
            /* we don't care about the initialization result */
        });
    }
    /**
     * @internal
     */
    isEqual(otherProvider) {
        if (otherProvider instanceof ReCaptchaEnterpriseProvider) {
            return this._siteKey === otherProvider._siteKey;
        }
        else {
            return false;
        }
    }
}
/**
 * Custom provider class.
 * @public
 */
class CustomProvider {
    constructor(_customProviderOptions) {
        this._customProviderOptions = _customProviderOptions;
    }
    /**
     * @internal
     */
    async getToken() {
        // custom provider
        const customToken = await this._customProviderOptions.getToken();
        // Try to extract IAT from custom token, in case this token is not
        // being newly issued. JWT timestamps are in seconds since epoch.
        const issuedAtTimeSeconds = issuedAtTime(customToken.token);
        // Very basic validation, use current timestamp as IAT if JWT
        // has no `iat` field or value is out of bounds.
        const issuedAtTimeMillis = issuedAtTimeSeconds !== null &&
            issuedAtTimeSeconds < Date.now() &&
            issuedAtTimeSeconds > 0
            ? issuedAtTimeSeconds * 1000
            : Date.now();
        return { ...customToken, issuedAtTimeMillis };
    }
    /**
     * @internal
     */
    initialize(app) {
        this._app = app;
    }
    /**
     * @internal
     */
    isEqual(otherProvider) {
        if (otherProvider instanceof CustomProvider) {
            return (this._customProviderOptions.getToken.toString() ===
                otherProvider._customProviderOptions.getToken.toString());
        }
        else {
            return false;
        }
    }
}
/**
 * Set throttle data to block requests until after a certain time
 * depending on the failed request's status code.
 * @param httpStatus - Status code of failed request.
 * @param throttleData - `ThrottleData` object containing previous throttle
 * data state.
 * @returns Data about current throttle state and expiration time.
 */
function setBackoff(httpStatus, throttleData) {
    /**
     * Block retries for 1 day for the following error codes:
     *
     * 404: Likely malformed URL.
     *
     * 403:
     * - Attestation failed
     * - Wrong API key
     * - Project deleted
     */
    if (httpStatus === 404 || httpStatus === 403) {
        return {
            backoffCount: 1,
            allowRequestsAfter: Date.now() + ONE_DAY,
            httpStatus
        };
    }
    else {
        /**
         * For all other error codes, the time when it is ok to retry again
         * is based on exponential backoff.
         */
        const backoffCount = throttleData ? throttleData.backoffCount : 0;
        const backoffMillis = calculateBackoffMillis(backoffCount, 1000, 2);
        return {
            backoffCount: backoffCount + 1,
            allowRequestsAfter: Date.now() + backoffMillis,
            httpStatus
        };
    }
}
function throwIfThrottled(throttleData) {
    if (throttleData) {
        if (Date.now() - throttleData.allowRequestsAfter <= 0) {
            // If before, throw.
            throw ERROR_FACTORY.create("throttled" /* AppCheckError.THROTTLED */, {
                time: getDurationString(throttleData.allowRequestsAfter - Date.now()),
                httpStatus: throttleData.httpStatus
            });
        }
    }
}

/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * Activate App Check for the given app. Can be called only once per app.
 * @param app - the {@link @firebase/app#FirebaseApp} to activate App Check for
 * @param options - App Check initialization options
 * @public
 */
function initializeAppCheck(app = getApp(), options) {
    app = getModularInstance(app);
    const provider = _getProvider(app, 'app-check');
    // Ensure initializeDebugMode() is only called once.
    if (!getDebugState().initialized) {
        initializeDebugMode();
    }
    // Log a message containing the debug token when `initializeAppCheck()`
    // is called in debug mode.
    if (isDebugMode()) {
        // Do not block initialization to get the token for the message.
        void getDebugToken().then(token => 
        // Not using logger because I don't think we ever want this accidentally hidden.
        console.log(`App Check debug token: ${token}. You will need to add it to your app's App Check settings in the Firebase console for it to work.`));
    }
    if (provider.isInitialized()) {
        const existingInstance = provider.getImmediate();
        const initialOptions = provider.getOptions();
        if (initialOptions &&
            !!initialOptions.isTokenAutoRefreshEnabled ===
                !!options.isTokenAutoRefreshEnabled &&
            initialOptions.provider?.isEqual(options.provider)) {
            return existingInstance;
        }
        else {
            throw ERROR_FACTORY.create("already-initialized" /* AppCheckError.ALREADY_INITIALIZED */, {
                appName: app.name
            });
        }
    }
    const appCheck = provider.initialize({ options });
    _activate(app, options.provider, options.isTokenAutoRefreshEnabled);
    // If isTokenAutoRefreshEnabled is false, do not send any requests to the
    // exchange endpoint without an explicit call from the user either directly
    // or through another Firebase library (storage, functions, etc.)
    if (getStateReference(app).isTokenAutoRefreshEnabled) {
        // Adding a listener will start the refresher and fetch a token if needed.
        // This gets a token ready and prevents a delay when an internal library
        // requests the token.
        // Listener function does not need to do anything, its base functionality
        // of calling getToken() already fetches token and writes it to memory/storage.
        addTokenListener(appCheck, "INTERNAL" /* ListenerType.INTERNAL */, () => { });
    }
    return appCheck;
}
/**
 * Activate App Check
 * @param app - Firebase app to activate App Check for.
 * @param provider - reCAPTCHA v3 provider or
 * custom token provider.
 * @param isTokenAutoRefreshEnabled - If true, the SDK automatically
 * refreshes App Check tokens as needed. If undefined, defaults to the
 * value of `app.automaticDataCollectionEnabled`, which defaults to
 * false and can be set in the app config.
 */
function _activate(app, provider, isTokenAutoRefreshEnabled = false) {
    // Create an entry in the APP_CHECK_STATES map. Further changes should
    // directly mutate this object.
    const state = setInitialState(app, { ...DEFAULT_STATE });
    state.activated = true;
    state.provider = provider; // Read cached token from storage if it exists and store it in memory.
    state.cachedTokenPromise = readTokenFromStorage(app).then(cachedToken => {
        if (cachedToken && isValid(cachedToken)) {
            state.token = cachedToken;
            // notify all listeners with the cached token
            notifyTokenListeners(app, { token: cachedToken.token });
        }
        return cachedToken;
    });
    // Global `automaticDataCollectionEnabled` (defaults to true) and
    // `isTokenAutoRefreshEnabled` must both be true.
    state.isTokenAutoRefreshEnabled =
        isTokenAutoRefreshEnabled && app.automaticDataCollectionEnabled;
    if (!app.automaticDataCollectionEnabled && isTokenAutoRefreshEnabled) {
        logger.warn('`isTokenAutoRefreshEnabled` is true but ' +
            '`automaticDataCollectionEnabled` was set to false during' +
            ' `initializeApp()`. This blocks automatic token refresh.');
    }
    state.provider.initialize(app);
}
/**
 * Set whether App Check will automatically refresh tokens as needed.
 *
 * @param appCheckInstance - The App Check service instance.
 * @param isTokenAutoRefreshEnabled - If true, the SDK automatically
 * refreshes App Check tokens as needed. This overrides any value set
 * during `initializeAppCheck()`.
 * @public
 */
function setTokenAutoRefreshEnabled(appCheckInstance, isTokenAutoRefreshEnabled) {
    const app = appCheckInstance.app;
    const state = getStateReference(app);
    // This will exist if any product libraries have called
    // `addTokenListener()`
    if (state.tokenRefresher) {
        if (isTokenAutoRefreshEnabled === true) {
            state.tokenRefresher.start();
        }
        else {
            state.tokenRefresher.stop();
        }
    }
    state.isTokenAutoRefreshEnabled = isTokenAutoRefreshEnabled;
}
/**
 * Get the current App Check token. If `forceRefresh` is false, this function first
 * checks for a valid token in memory, then local persistence (IndexedDB).
 * If not found, or if `forceRefresh` is true, it makes a request to the
 * App Check endpoint for a fresh token. That request attaches
 * to the most recent in-flight request if one is present.
 *
 * @param appCheckInstance - The App Check service instance.
 * @param forceRefresh - If true, will always try to fetch a fresh token.
 * If false, will use a cached token if found in storage.
 * @public
 */
async function getToken(appCheckInstance, forceRefresh) {
    const result = await getToken$2(appCheckInstance, forceRefresh);
    if (result.error) {
        throw result.error;
    }
    if (result.internalError) {
        throw result.internalError;
    }
    return { token: result.token };
}
/**
 * Requests a Firebase App Check token. This method should be used
 * only if you need to authorize requests to a non-Firebase backend.
 *
 * Returns limited-use tokens that are intended for use with your
 * non-Firebase backend endpoints that are protected with
 * <a href="https://firebase.google.com/docs/app-check/custom-resource-backend#replay-protection">
 * Replay Protection</a>. This method
 * does not affect the token generation behavior of the
 * #getAppCheckToken() method.
 *
 * @param appCheckInstance - The App Check service instance.
 * @returns The limited use token.
 * @public
 */
function getLimitedUseToken(appCheckInstance) {
    return getLimitedUseToken$1(appCheckInstance);
}
/**
 * Wraps `addTokenListener`/`removeTokenListener` methods in an `Observer`
 * pattern for public use.
 */
function onTokenChanged(appCheckInstance, onNextOrObserver, onError, 
/**
 * NOTE: Although an `onCompletion` callback can be provided, it will
 * never be called because the token stream is never-ending.
 * It is added only for API consistency with the observer pattern, which
 * we follow in JS APIs.
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
onCompletion) {
    let nextFn = () => { };
    let errorFn = () => { };
    if (onNextOrObserver.next != null) {
        nextFn = onNextOrObserver.next.bind(onNextOrObserver);
    }
    else {
        nextFn = onNextOrObserver;
    }
    if (onNextOrObserver.error != null) {
        errorFn = onNextOrObserver.error.bind(onNextOrObserver);
    }
    else if (onError) {
        errorFn = onError;
    }
    addTokenListener(appCheckInstance, "EXTERNAL" /* ListenerType.EXTERNAL */, nextFn, errorFn);
    return () => removeTokenListener(appCheckInstance.app, nextFn);
}

/**
 * The Firebase App Check Web SDK.
 *
 * @remarks
 * Firebase App Check does not work in a Node.js environment using `ReCaptchaV3Provider` or
 * `ReCaptchaEnterpriseProvider`, but can be used in Node.js if you use
 * `CustomProvider` and write your own attestation method.
 *
 * @packageDocumentation
 */
/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const APP_CHECK_NAME = 'app-check';
const APP_CHECK_NAME_INTERNAL = 'app-check-internal';
function registerAppCheck() {
    // The public interface
    _registerComponent(new Component(APP_CHECK_NAME, container => {
        // getImmediate for FirebaseApp will always succeed
        const app = container.getProvider('app').getImmediate();
        const heartbeatServiceProvider = container.getProvider('heartbeat');
        return factory(app, heartbeatServiceProvider);
    }, "PUBLIC" /* ComponentType.PUBLIC */)
        .setInstantiationMode("EXPLICIT" /* InstantiationMode.EXPLICIT */)
        /**
         * Initialize app-check-internal after app-check is initialized to make AppCheck available to
         * other Firebase SDKs
         */
        .setInstanceCreatedCallback((container, _identifier, _appcheckService) => {
        container.getProvider(APP_CHECK_NAME_INTERNAL).initialize();
    }));
    // The internal interface used by other Firebase products
    _registerComponent(new Component(APP_CHECK_NAME_INTERNAL, container => {
        const appCheck = container.getProvider('app-check').getImmediate();
        return internalFactory(appCheck);
    }, "PUBLIC" /* ComponentType.PUBLIC */).setInstantiationMode("EXPLICIT" /* InstantiationMode.EXPLICIT */));
    registerVersion(name, version);
}
registerAppCheck();

export { CustomProvider, ReCaptchaEnterpriseProvider, ReCaptchaV3Provider, getLimitedUseToken, getToken, initializeAppCheck, onTokenChanged, setTokenAutoRefreshEnabled };
                                     

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguZXNtLmpzIiwic291cmNlcyI6WyIuLi8uLi9zcmMvc3RhdGUudHMiLCIuLi8uLi9zcmMvY29uc3RhbnRzLnRzIiwiLi4vLi4vc3JjL3Byb2FjdGl2ZS1yZWZyZXNoLnRzIiwiLi4vLi4vc3JjL2Vycm9ycy50cyIsIi4uLy4uL3NyYy91dGlsLnRzIiwiLi4vLi4vc3JjL2NsaWVudC50cyIsIi4uLy4uL3NyYy9pbmRleGVkZGIudHMiLCIuLi8uLi9zcmMvbG9nZ2VyLnRzIiwiLi4vLi4vc3JjL3N0b3JhZ2UudHMiLCIuLi8uLi9zcmMvZGVidWcudHMiLCIuLi8uLi9zcmMvaW50ZXJuYWwtYXBpLnRzIiwiLi4vLi4vc3JjL2ZhY3RvcnkudHMiLCIuLi8uLi9zcmMvcmVjYXB0Y2hhLnRzIiwiLi4vLi4vc3JjL3Byb3ZpZGVycy50cyIsIi4uLy4uL3NyYy9hcGkudHMiLCIuLi8uLi9zcmMvaW5kZXgudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgRmlyZWJhc2VBcHAgfSBmcm9tICdAZmlyZWJhc2UvYXBwJztcbmltcG9ydCB7XG4gIEFwcENoZWNrUHJvdmlkZXIsXG4gIEFwcENoZWNrVG9rZW5JbnRlcm5hbCxcbiAgQXBwQ2hlY2tUb2tlbk9ic2VydmVyXG59IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHsgUmVmcmVzaGVyIH0gZnJvbSAnLi9wcm9hY3RpdmUtcmVmcmVzaCc7XG5pbXBvcnQgeyBEZWZlcnJlZCB9IGZyb20gJ0BmaXJlYmFzZS91dGlsJztcbmltcG9ydCB7IEdyZUNBUFRDSEEgfSBmcm9tICcuL3JlY2FwdGNoYSc7XG5leHBvcnQgaW50ZXJmYWNlIEFwcENoZWNrU3RhdGUge1xuICBhY3RpdmF0ZWQ6IGJvb2xlYW47XG4gIHRva2VuT2JzZXJ2ZXJzOiBBcHBDaGVja1Rva2VuT2JzZXJ2ZXJbXTtcbiAgcHJvdmlkZXI/OiBBcHBDaGVja1Byb3ZpZGVyO1xuICB0b2tlbj86IEFwcENoZWNrVG9rZW5JbnRlcm5hbDtcbiAgY2FjaGVkVG9rZW5Qcm9taXNlPzogUHJvbWlzZTxBcHBDaGVja1Rva2VuSW50ZXJuYWwgfCB1bmRlZmluZWQ+O1xuICBleGNoYW5nZVRva2VuUHJvbWlzZT86IFByb21pc2U8QXBwQ2hlY2tUb2tlbkludGVybmFsPjtcbiAgdG9rZW5SZWZyZXNoZXI/OiBSZWZyZXNoZXI7XG4gIHJlQ0FQVENIQVN0YXRlPzogUmVDQVBUQ0hBU3RhdGU7XG4gIGlzVG9rZW5BdXRvUmVmcmVzaEVuYWJsZWQ/OiBib29sZWFuO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFJlQ0FQVENIQVN0YXRlIHtcbiAgaW5pdGlhbGl6ZWQ6IERlZmVycmVkPEdyZUNBUFRDSEE+O1xuICB3aWRnZXRJZD86IHN0cmluZztcbiAgLy8gVHJ1ZSBpZiB0aGUgbW9zdCByZWNlbnQgcmVjYXB0Y2hhIGNoZWNrIHN1Y2NlZWRlZC5cbiAgc3VjY2VlZGVkPzogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBEZWJ1Z1N0YXRlIHtcbiAgaW5pdGlhbGl6ZWQ6IGJvb2xlYW47XG4gIGVuYWJsZWQ6IGJvb2xlYW47XG4gIHRva2VuPzogRGVmZXJyZWQ8c3RyaW5nPjtcbn1cblxuY29uc3QgQVBQX0NIRUNLX1NUQVRFUyA9IG5ldyBNYXA8RmlyZWJhc2VBcHAsIEFwcENoZWNrU3RhdGU+KCk7XG5leHBvcnQgY29uc3QgREVGQVVMVF9TVEFURTogQXBwQ2hlY2tTdGF0ZSA9IHtcbiAgYWN0aXZhdGVkOiBmYWxzZSxcbiAgdG9rZW5PYnNlcnZlcnM6IFtdXG59O1xuXG5jb25zdCBERUJVR19TVEFURTogRGVidWdTdGF0ZSA9IHtcbiAgaW5pdGlhbGl6ZWQ6IGZhbHNlLFxuICBlbmFibGVkOiBmYWxzZVxufTtcblxuLyoqXG4gKiBHZXRzIGEgcmVmZXJlbmNlIHRvIHRoZSBzdGF0ZSBvYmplY3QuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRTdGF0ZVJlZmVyZW5jZShhcHA6IEZpcmViYXNlQXBwKTogQXBwQ2hlY2tTdGF0ZSB7XG4gIHJldHVybiBBUFBfQ0hFQ0tfU1RBVEVTLmdldChhcHApIHx8IHsgLi4uREVGQVVMVF9TVEFURSB9O1xufVxuXG4vKipcbiAqIFNldCBvbmNlIG9uIGluaXRpYWxpemF0aW9uLiBUaGUgbWFwIHNob3VsZCBob2xkIHRoZSBzYW1lIHJlZmVyZW5jZSB0byB0aGVcbiAqIHNhbWUgb2JqZWN0IHVudGlsIHRoaXMgZW50cnkgaXMgZGVsZXRlZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNldEluaXRpYWxTdGF0ZShcbiAgYXBwOiBGaXJlYmFzZUFwcCxcbiAgc3RhdGU6IEFwcENoZWNrU3RhdGVcbik6IEFwcENoZWNrU3RhdGUge1xuICBBUFBfQ0hFQ0tfU1RBVEVTLnNldChhcHAsIHN0YXRlKTtcbiAgcmV0dXJuIEFQUF9DSEVDS19TVEFURVMuZ2V0KGFwcCkgYXMgQXBwQ2hlY2tTdGF0ZTtcbn1cblxuLy8gZm9yIHRlc3Rpbmcgb25seVxuZXhwb3J0IGZ1bmN0aW9uIGNsZWFyU3RhdGUoKTogdm9pZCB7XG4gIEFQUF9DSEVDS19TVEFURVMuY2xlYXIoKTtcbiAgREVCVUdfU1RBVEUuZW5hYmxlZCA9IGZhbHNlO1xuICBERUJVR19TVEFURS50b2tlbiA9IHVuZGVmaW5lZDtcbiAgREVCVUdfU1RBVEUuaW5pdGlhbGl6ZWQgPSBmYWxzZTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldERlYnVnU3RhdGUoKTogRGVidWdTdGF0ZSB7XG4gIHJldHVybiBERUJVR19TVEFURTtcbn1cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDIwIEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5leHBvcnQgY29uc3QgQkFTRV9FTkRQT0lOVCA9XG4gICdodHRwczovL2NvbnRlbnQtZmlyZWJhc2VhcHBjaGVjay5nb29nbGVhcGlzLmNvbS92MSc7XG5cbmV4cG9ydCBjb25zdCBFWENIQU5HRV9SRUNBUFRDSEFfVE9LRU5fTUVUSE9EID0gJ2V4Y2hhbmdlUmVjYXB0Y2hhVjNUb2tlbic7XG5leHBvcnQgY29uc3QgRVhDSEFOR0VfUkVDQVBUQ0hBX0VOVEVSUFJJU0VfVE9LRU5fTUVUSE9EID1cbiAgJ2V4Y2hhbmdlUmVjYXB0Y2hhRW50ZXJwcmlzZVRva2VuJztcbmV4cG9ydCBjb25zdCBFWENIQU5HRV9ERUJVR19UT0tFTl9NRVRIT0QgPSAnZXhjaGFuZ2VEZWJ1Z1Rva2VuJztcblxuZXhwb3J0IGNvbnN0IFRPS0VOX1JFRlJFU0hfVElNRSA9IHtcbiAgLyoqXG4gICAqIFRoZSBvZmZzZXQgdGltZSBiZWZvcmUgdG9rZW4gbmF0dXJhbCBleHBpcmF0aW9uIHRvIHJ1biB0aGUgcmVmcmVzaC5cbiAgICogVGhpcyBpcyBjdXJyZW50bHkgNSBtaW51dGVzLlxuICAgKi9cbiAgT0ZGU0VUX0RVUkFUSU9OOiA1ICogNjAgKiAxMDAwLFxuICAvKipcbiAgICogVGhpcyBpcyB0aGUgZmlyc3QgcmV0cmlhbCB3YWl0IGFmdGVyIGFuIGVycm9yLiBUaGlzIGlzIGN1cnJlbnRseVxuICAgKiAzMCBzZWNvbmRzLlxuICAgKi9cbiAgUkVUUklBTF9NSU5fV0FJVDogMzAgKiAxMDAwLFxuICAvKipcbiAgICogVGhpcyBpcyB0aGUgbWF4aW11bSByZXRyaWFsIHdhaXQsIGN1cnJlbnRseSAxNiBtaW51dGVzLlxuICAgKi9cbiAgUkVUUklBTF9NQVhfV0FJVDogMTYgKiA2MCAqIDEwMDBcbn07XG5cbi8qKlxuICogT25lIGRheSBpbiBtaWxsaXMsIGZvciBjZXJ0YWluIGVycm9yIGNvZGUgYmFja29mZnMuXG4gKi9cbmV4cG9ydCBjb25zdCBPTkVfREFZID0gMjQgKiA2MCAqIDYwICogMTAwMDtcbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDIwIEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmltcG9ydCB7IERlZmVycmVkIH0gZnJvbSAnQGZpcmViYXNlL3V0aWwnO1xuXG4vKipcbiAqIFBvcnQgZnJvbSBhdXRoIHByb2FjdGl2ZXJlZnJlc2guanNcbiAqXG4gKi9cbi8vIFRPRE86IG1vdmUgaXQgdG8gQGZpcmViYXNlL3V0aWw/XG4vLyBUT0RPOiBhbGxvdyB0byBjb25maWcgd2hldGhlciByZWZyZXNoIHNob3VsZCBoYXBwZW4gaW4gdGhlIGJhY2tncm91bmRcbmV4cG9ydCBjbGFzcyBSZWZyZXNoZXIge1xuICBwcml2YXRlIHBlbmRpbmc6IERlZmVycmVkPHVua25vd24+IHwgbnVsbCA9IG51bGw7XG4gIHByaXZhdGUgbmV4dEVycm9yV2FpdEludGVydmFsOiBudW1iZXI7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgcmVhZG9ubHkgb3BlcmF0aW9uOiAoKSA9PiBQcm9taXNlPHVua25vd24+LFxuICAgIHByaXZhdGUgcmVhZG9ubHkgcmV0cnlQb2xpY3k6IChlcnJvcjogdW5rbm93bikgPT4gYm9vbGVhbixcbiAgICBwcml2YXRlIHJlYWRvbmx5IGdldFdhaXREdXJhdGlvbjogKCkgPT4gbnVtYmVyLFxuICAgIHByaXZhdGUgcmVhZG9ubHkgbG93ZXJCb3VuZDogbnVtYmVyLFxuICAgIHByaXZhdGUgcmVhZG9ubHkgdXBwZXJCb3VuZDogbnVtYmVyXG4gICkge1xuICAgIHRoaXMubmV4dEVycm9yV2FpdEludGVydmFsID0gbG93ZXJCb3VuZDtcblxuICAgIGlmIChsb3dlckJvdW5kID4gdXBwZXJCb3VuZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAnUHJvYWN0aXZlIHJlZnJlc2ggbG93ZXIgYm91bmQgZ3JlYXRlciB0aGFuIHVwcGVyIGJvdW5kISdcbiAgICAgICk7XG4gICAgfVxuICB9XG5cbiAgc3RhcnQoKTogdm9pZCB7XG4gICAgdGhpcy5uZXh0RXJyb3JXYWl0SW50ZXJ2YWwgPSB0aGlzLmxvd2VyQm91bmQ7XG4gICAgdGhpcy5wcm9jZXNzKHRydWUpLmNhdGNoKCgpID0+IHtcbiAgICAgIC8qIHdlIGRvbid0IGNhcmUgYWJvdXQgdGhlIHJlc3VsdCAqL1xuICAgIH0pO1xuICB9XG5cbiAgc3RvcCgpOiB2b2lkIHtcbiAgICBpZiAodGhpcy5wZW5kaW5nKSB7XG4gICAgICB0aGlzLnBlbmRpbmcucmVqZWN0KCdjYW5jZWxsZWQnKTtcbiAgICAgIHRoaXMucGVuZGluZyA9IG51bGw7XG4gICAgfVxuICB9XG5cbiAgaXNSdW5uaW5nKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiAhIXRoaXMucGVuZGluZztcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgcHJvY2VzcyhoYXNTdWNjZWVkZWQ6IGJvb2xlYW4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0aGlzLnN0b3AoKTtcbiAgICB0cnkge1xuICAgICAgdGhpcy5wZW5kaW5nID0gbmV3IERlZmVycmVkKCk7XG4gICAgICB0aGlzLnBlbmRpbmcucHJvbWlzZS5jYXRjaChfZSA9PiB7XG4gICAgICAgIC8qIGlnbm9yZSAqL1xuICAgICAgfSk7XG4gICAgICBhd2FpdCBzbGVlcCh0aGlzLmdldE5leHRSdW4oaGFzU3VjY2VlZGVkKSk7XG5cbiAgICAgIC8vIFdoeSBkbyB3ZSByZXNvbHZlIGEgcHJvbWlzZSwgdGhlbiBpbW1lZGlhdGUgd2FpdCBmb3IgaXQ/XG4gICAgICAvLyBXZSBkbyBpdCB0byBtYWtlIHRoZSBwcm9taXNlIGNoYWluIGNhbmNlbGxhYmxlLlxuICAgICAgLy8gV2UgY2FuIGNhbGwgc3RvcCgpIHdoaWNoIHJlamVjdHMgdGhlIHByb21pc2UgYmVmb3JlIHRoZSBmb2xsb3dpbmcgbGluZSBleGVjdXRlLCB3aGljaCBtYWtlc1xuICAgICAgLy8gdGhlIGNvZGUganVtcCB0byB0aGUgY2F0Y2ggYmxvY2suXG4gICAgICAvLyBUT0RPOiB1bml0IHRlc3QgdGhpc1xuICAgICAgdGhpcy5wZW5kaW5nLnJlc29sdmUoKTtcbiAgICAgIGF3YWl0IHRoaXMucGVuZGluZy5wcm9taXNlO1xuICAgICAgdGhpcy5wZW5kaW5nID0gbmV3IERlZmVycmVkKCk7XG4gICAgICB0aGlzLnBlbmRpbmcucHJvbWlzZS5jYXRjaChfZSA9PiB7XG4gICAgICAgIC8qIGlnbm9yZSAqL1xuICAgICAgfSk7XG4gICAgICBhd2FpdCB0aGlzLm9wZXJhdGlvbigpO1xuXG4gICAgICB0aGlzLnBlbmRpbmcucmVzb2x2ZSgpO1xuICAgICAgYXdhaXQgdGhpcy5wZW5kaW5nLnByb21pc2U7XG5cbiAgICAgIHRoaXMucHJvY2Vzcyh0cnVlKS5jYXRjaCgoKSA9PiB7XG4gICAgICAgIC8qIHdlIGRvbid0IGNhcmUgYWJvdXQgdGhlIHJlc3VsdCAqL1xuICAgICAgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmICh0aGlzLnJldHJ5UG9saWN5KGVycm9yKSkge1xuICAgICAgICB0aGlzLnByb2Nlc3MoZmFsc2UpLmNhdGNoKCgpID0+IHtcbiAgICAgICAgICAvKiB3ZSBkb24ndCBjYXJlIGFib3V0IHRoZSByZXN1bHQgKi9cbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLnN0b3AoKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGdldE5leHRSdW4oaGFzU3VjY2VlZGVkOiBib29sZWFuKTogbnVtYmVyIHtcbiAgICBpZiAoaGFzU3VjY2VlZGVkKSB7XG4gICAgICAvLyBJZiBsYXN0IG9wZXJhdGlvbiBzdWNjZWVkZWQsIHJlc2V0IG5leHQgZXJyb3Igd2FpdCBpbnRlcnZhbCBhbmQgcmV0dXJuXG4gICAgICAvLyB0aGUgZGVmYXVsdCB3YWl0IGR1cmF0aW9uLlxuICAgICAgdGhpcy5uZXh0RXJyb3JXYWl0SW50ZXJ2YWwgPSB0aGlzLmxvd2VyQm91bmQ7XG4gICAgICAvLyBSZXR1cm4gdHlwaWNhbCB3YWl0IGR1cmF0aW9uIGludGVydmFsIGFmdGVyIGEgc3VjY2Vzc2Z1bCBvcGVyYXRpb24uXG4gICAgICByZXR1cm4gdGhpcy5nZXRXYWl0RHVyYXRpb24oKTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gR2V0IG5leHQgZXJyb3Igd2FpdCBpbnRlcnZhbC5cbiAgICAgIGNvbnN0IGN1cnJlbnRFcnJvcldhaXRJbnRlcnZhbCA9IHRoaXMubmV4dEVycm9yV2FpdEludGVydmFsO1xuICAgICAgLy8gRG91YmxlIGludGVydmFsIGZvciBuZXh0IGNvbnNlY3V0aXZlIGVycm9yLlxuICAgICAgdGhpcy5uZXh0RXJyb3JXYWl0SW50ZXJ2YWwgKj0gMjtcbiAgICAgIC8vIE1ha2Ugc3VyZSBuZXh0IHdhaXQgaW50ZXJ2YWwgZG9lcyBub3QgZXhjZWVkIHRoZSBtYXhpbXVtIHVwcGVyIGJvdW5kLlxuICAgICAgaWYgKHRoaXMubmV4dEVycm9yV2FpdEludGVydmFsID4gdGhpcy51cHBlckJvdW5kKSB7XG4gICAgICAgIHRoaXMubmV4dEVycm9yV2FpdEludGVydmFsID0gdGhpcy51cHBlckJvdW5kO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGN1cnJlbnRFcnJvcldhaXRJbnRlcnZhbDtcbiAgICB9XG4gIH1cbn1cblxuZnVuY3Rpb24gc2xlZXAobXM6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuICByZXR1cm4gbmV3IFByb21pc2U8dm9pZD4ocmVzb2x2ZSA9PiB7XG4gICAgc2V0VGltZW91dChyZXNvbHZlLCBtcyk7XG4gIH0pO1xufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgRXJyb3JGYWN0b3J5LCBFcnJvck1hcCB9IGZyb20gJ0BmaXJlYmFzZS91dGlsJztcblxuZXhwb3J0IGNvbnN0IGVudW0gQXBwQ2hlY2tFcnJvciB7XG4gIEFMUkVBRFlfSU5JVElBTElaRUQgPSAnYWxyZWFkeS1pbml0aWFsaXplZCcsXG4gIFVTRV9CRUZPUkVfQUNUSVZBVElPTiA9ICd1c2UtYmVmb3JlLWFjdGl2YXRpb24nLFxuICBGRVRDSF9ORVRXT1JLX0VSUk9SID0gJ2ZldGNoLW5ldHdvcmstZXJyb3InLFxuICBGRVRDSF9QQVJTRV9FUlJPUiA9ICdmZXRjaC1wYXJzZS1lcnJvcicsXG4gIEZFVENIX1NUQVRVU19FUlJPUiA9ICdmZXRjaC1zdGF0dXMtZXJyb3InLFxuICBTVE9SQUdFX09QRU4gPSAnc3RvcmFnZS1vcGVuJyxcbiAgU1RPUkFHRV9HRVQgPSAnc3RvcmFnZS1nZXQnLFxuICBTVE9SQUdFX1dSSVRFID0gJ3N0b3JhZ2Utc2V0JyxcbiAgUkVDQVBUQ0hBX0VSUk9SID0gJ3JlY2FwdGNoYS1lcnJvcicsXG4gIElOSVRJQUxfVEhST1RUTEUgPSAnaW5pdGlhbC10aHJvdHRsZScsXG4gIFRIUk9UVExFRCA9ICd0aHJvdHRsZWQnXG59XG5cbmNvbnN0IEVSUk9SUzogRXJyb3JNYXA8QXBwQ2hlY2tFcnJvcj4gPSB7XG4gIFtBcHBDaGVja0Vycm9yLkFMUkVBRFlfSU5JVElBTElaRURdOlxuICAgICdZb3UgaGF2ZSBhbHJlYWR5IGNhbGxlZCBpbml0aWFsaXplQXBwQ2hlY2soKSBmb3IgRmlyZWJhc2VBcHAgeyRhcHBOYW1lfSB3aXRoICcgK1xuICAgICdkaWZmZXJlbnQgb3B0aW9ucy4gVG8gYXZvaWQgdGhpcyBlcnJvciwgY2FsbCBpbml0aWFsaXplQXBwQ2hlY2soKSB3aXRoIHRoZSAnICtcbiAgICAnc2FtZSBvcHRpb25zIGFzIHdoZW4gaXQgd2FzIG9yaWdpbmFsbHkgY2FsbGVkLiBUaGlzIHdpbGwgcmV0dXJuIHRoZSAnICtcbiAgICAnYWxyZWFkeSBpbml0aWFsaXplZCBpbnN0YW5jZS4nLFxuICBbQXBwQ2hlY2tFcnJvci5VU0VfQkVGT1JFX0FDVElWQVRJT05dOlxuICAgICdBcHAgQ2hlY2sgaXMgYmVpbmcgdXNlZCBiZWZvcmUgaW5pdGlhbGl6ZUFwcENoZWNrKCkgaXMgY2FsbGVkIGZvciBGaXJlYmFzZUFwcCB7JGFwcE5hbWV9LiAnICtcbiAgICAnQ2FsbCBpbml0aWFsaXplQXBwQ2hlY2soKSBiZWZvcmUgaW5zdGFudGlhdGluZyBvdGhlciBGaXJlYmFzZSBzZXJ2aWNlcy4nLFxuICBbQXBwQ2hlY2tFcnJvci5GRVRDSF9ORVRXT1JLX0VSUk9SXTpcbiAgICAnRmV0Y2ggZmFpbGVkIHRvIGNvbm5lY3QgdG8gYSBuZXR3b3JrLiBDaGVjayBJbnRlcm5ldCBjb25uZWN0aW9uLiAnICtcbiAgICAnT3JpZ2luYWwgZXJyb3I6IHskb3JpZ2luYWxFcnJvck1lc3NhZ2V9LicsXG4gIFtBcHBDaGVja0Vycm9yLkZFVENIX1BBUlNFX0VSUk9SXTpcbiAgICAnRmV0Y2ggY2xpZW50IGNvdWxkIG5vdCBwYXJzZSByZXNwb25zZS4nICtcbiAgICAnIE9yaWdpbmFsIGVycm9yOiB7JG9yaWdpbmFsRXJyb3JNZXNzYWdlfS4nLFxuICBbQXBwQ2hlY2tFcnJvci5GRVRDSF9TVEFUVVNfRVJST1JdOlxuICAgICdGZXRjaCBzZXJ2ZXIgcmV0dXJuZWQgYW4gSFRUUCBlcnJvciBzdGF0dXMuIEhUVFAgc3RhdHVzOiB7JGh0dHBTdGF0dXN9LicsXG4gIFtBcHBDaGVja0Vycm9yLlNUT1JBR0VfT1BFTl06XG4gICAgJ0Vycm9yIHRocm93biB3aGVuIG9wZW5pbmcgc3RvcmFnZS4gT3JpZ2luYWwgZXJyb3I6IHskb3JpZ2luYWxFcnJvck1lc3NhZ2V9LicsXG4gIFtBcHBDaGVja0Vycm9yLlNUT1JBR0VfR0VUXTpcbiAgICAnRXJyb3IgdGhyb3duIHdoZW4gcmVhZGluZyBmcm9tIHN0b3JhZ2UuIE9yaWdpbmFsIGVycm9yOiB7JG9yaWdpbmFsRXJyb3JNZXNzYWdlfS4nLFxuICBbQXBwQ2hlY2tFcnJvci5TVE9SQUdFX1dSSVRFXTpcbiAgICAnRXJyb3IgdGhyb3duIHdoZW4gd3JpdGluZyB0byBzdG9yYWdlLiBPcmlnaW5hbCBlcnJvcjogeyRvcmlnaW5hbEVycm9yTWVzc2FnZX0uJyxcbiAgW0FwcENoZWNrRXJyb3IuUkVDQVBUQ0hBX0VSUk9SXTogJ1JlQ0FQVENIQSBlcnJvci4nLFxuICBbQXBwQ2hlY2tFcnJvci5JTklUSUFMX1RIUk9UVExFXTogYHskaHR0cFN0YXR1c30gZXJyb3IuIEF0dGVtcHRzIGFsbG93ZWQgYWdhaW4gYWZ0ZXIgeyR0aW1lfWAsXG4gIFtBcHBDaGVja0Vycm9yLlRIUk9UVExFRF06IGBSZXF1ZXN0cyB0aHJvdHRsZWQgZHVlIHRvIHByZXZpb3VzIHskaHR0cFN0YXR1c30gZXJyb3IuIEF0dGVtcHRzIGFsbG93ZWQgYWdhaW4gYWZ0ZXIgeyR0aW1lfWBcbn07XG5cbmludGVyZmFjZSBFcnJvclBhcmFtcyB7XG4gIFtBcHBDaGVja0Vycm9yLkFMUkVBRFlfSU5JVElBTElaRURdOiB7IGFwcE5hbWU6IHN0cmluZyB9O1xuICBbQXBwQ2hlY2tFcnJvci5VU0VfQkVGT1JFX0FDVElWQVRJT05dOiB7IGFwcE5hbWU6IHN0cmluZyB9O1xuICBbQXBwQ2hlY2tFcnJvci5GRVRDSF9ORVRXT1JLX0VSUk9SXTogeyBvcmlnaW5hbEVycm9yTWVzc2FnZTogc3RyaW5nIH07XG4gIFtBcHBDaGVja0Vycm9yLkZFVENIX1BBUlNFX0VSUk9SXTogeyBvcmlnaW5hbEVycm9yTWVzc2FnZTogc3RyaW5nIH07XG4gIFtBcHBDaGVja0Vycm9yLkZFVENIX1NUQVRVU19FUlJPUl06IHsgaHR0cFN0YXR1czogbnVtYmVyIH07XG4gIFtBcHBDaGVja0Vycm9yLlNUT1JBR0VfT1BFTl06IHsgb3JpZ2luYWxFcnJvck1lc3NhZ2U/OiBzdHJpbmcgfTtcbiAgW0FwcENoZWNrRXJyb3IuU1RPUkFHRV9HRVRdOiB7IG9yaWdpbmFsRXJyb3JNZXNzYWdlPzogc3RyaW5nIH07XG4gIFtBcHBDaGVja0Vycm9yLlNUT1JBR0VfV1JJVEVdOiB7IG9yaWdpbmFsRXJyb3JNZXNzYWdlPzogc3RyaW5nIH07XG4gIFtBcHBDaGVja0Vycm9yLklOSVRJQUxfVEhST1RUTEVdOiB7IHRpbWU6IHN0cmluZzsgaHR0cFN0YXR1czogbnVtYmVyIH07XG4gIFtBcHBDaGVja0Vycm9yLlRIUk9UVExFRF06IHsgdGltZTogc3RyaW5nOyBodHRwU3RhdHVzOiBudW1iZXIgfTtcbn1cblxuZXhwb3J0IGNvbnN0IEVSUk9SX0ZBQ1RPUlkgPSBuZXcgRXJyb3JGYWN0b3J5PEFwcENoZWNrRXJyb3IsIEVycm9yUGFyYW1zPihcbiAgJ2FwcENoZWNrJyxcbiAgJ0FwcENoZWNrJyxcbiAgRVJST1JTXG4pO1xuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgR3JlQ0FQVENIQSB9IGZyb20gJy4vcmVjYXB0Y2hhJztcbmltcG9ydCB7IGdldFN0YXRlUmVmZXJlbmNlIH0gZnJvbSAnLi9zdGF0ZSc7XG5pbXBvcnQgeyBFUlJPUl9GQUNUT1JZLCBBcHBDaGVja0Vycm9yIH0gZnJvbSAnLi9lcnJvcnMnO1xuaW1wb3J0IHsgRmlyZWJhc2VBcHAgfSBmcm9tICdAZmlyZWJhc2UvYXBwJztcblxuZXhwb3J0IGZ1bmN0aW9uIGdldFJlY2FwdGNoYShcbiAgaXNFbnRlcnByaXNlOiBib29sZWFuID0gZmFsc2Vcbik6IEdyZUNBUFRDSEEgfCB1bmRlZmluZWQge1xuICBpZiAoaXNFbnRlcnByaXNlKSB7XG4gICAgcmV0dXJuIHNlbGYuZ3JlY2FwdGNoYT8uZW50ZXJwcmlzZTtcbiAgfVxuICByZXR1cm4gc2VsZi5ncmVjYXB0Y2hhO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZW5zdXJlQWN0aXZhdGVkKGFwcDogRmlyZWJhc2VBcHApOiB2b2lkIHtcbiAgaWYgKCFnZXRTdGF0ZVJlZmVyZW5jZShhcHApLmFjdGl2YXRlZCkge1xuICAgIHRocm93IEVSUk9SX0ZBQ1RPUlkuY3JlYXRlKEFwcENoZWNrRXJyb3IuVVNFX0JFRk9SRV9BQ1RJVkFUSU9OLCB7XG4gICAgICBhcHBOYW1lOiBhcHAubmFtZVxuICAgIH0pO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXREdXJhdGlvblN0cmluZyhkdXJhdGlvbkluTWlsbGlzOiBudW1iZXIpOiBzdHJpbmcge1xuICBjb25zdCB0b3RhbFNlY29uZHMgPSBNYXRoLnJvdW5kKGR1cmF0aW9uSW5NaWxsaXMgLyAxMDAwKTtcbiAgY29uc3QgZGF5cyA9IE1hdGguZmxvb3IodG90YWxTZWNvbmRzIC8gKDM2MDAgKiAyNCkpO1xuICBjb25zdCBob3VycyA9IE1hdGguZmxvb3IoKHRvdGFsU2Vjb25kcyAtIGRheXMgKiAzNjAwICogMjQpIC8gMzYwMCk7XG4gIGNvbnN0IG1pbnV0ZXMgPSBNYXRoLmZsb29yKFxuICAgICh0b3RhbFNlY29uZHMgLSBkYXlzICogMzYwMCAqIDI0IC0gaG91cnMgKiAzNjAwKSAvIDYwXG4gICk7XG4gIGNvbnN0IHNlY29uZHMgPSB0b3RhbFNlY29uZHMgLSBkYXlzICogMzYwMCAqIDI0IC0gaG91cnMgKiAzNjAwIC0gbWludXRlcyAqIDYwO1xuXG4gIGxldCByZXN1bHQgPSAnJztcbiAgaWYgKGRheXMpIHtcbiAgICByZXN1bHQgKz0gcGFkKGRheXMpICsgJ2Q6JztcbiAgfVxuICBpZiAoaG91cnMpIHtcbiAgICByZXN1bHQgKz0gcGFkKGhvdXJzKSArICdoOic7XG4gIH1cbiAgcmVzdWx0ICs9IHBhZChtaW51dGVzKSArICdtOicgKyBwYWQoc2Vjb25kcykgKyAncyc7XG4gIHJldHVybiByZXN1bHQ7XG59XG5cbmZ1bmN0aW9uIHBhZCh2YWx1ZTogbnVtYmVyKTogc3RyaW5nIHtcbiAgaWYgKHZhbHVlID09PSAwKSB7XG4gICAgcmV0dXJuICcwMCc7XG4gIH1cbiAgcmV0dXJuIHZhbHVlID49IDEwID8gdmFsdWUudG9TdHJpbmcoKSA6ICcwJyArIHZhbHVlO1xufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHtcbiAgQkFTRV9FTkRQT0lOVCxcbiAgRVhDSEFOR0VfREVCVUdfVE9LRU5fTUVUSE9ELFxuICBFWENIQU5HRV9SRUNBUFRDSEFfRU5URVJQUklTRV9UT0tFTl9NRVRIT0QsXG4gIEVYQ0hBTkdFX1JFQ0FQVENIQV9UT0tFTl9NRVRIT0Rcbn0gZnJvbSAnLi9jb25zdGFudHMnO1xuaW1wb3J0IHsgRmlyZWJhc2VBcHAgfSBmcm9tICdAZmlyZWJhc2UvYXBwJztcbmltcG9ydCB7IEVSUk9SX0ZBQ1RPUlksIEFwcENoZWNrRXJyb3IgfSBmcm9tICcuL2Vycm9ycyc7XG5pbXBvcnQgeyBQcm92aWRlciB9IGZyb20gJ0BmaXJlYmFzZS9jb21wb25lbnQnO1xuaW1wb3J0IHsgQXBwQ2hlY2tUb2tlbkludGVybmFsIH0gZnJvbSAnLi90eXBlcyc7XG5cbi8qKlxuICogUmVzcG9uc2UgSlNPTiByZXR1cm5lZCBmcm9tIEFwcENoZWNrIHNlcnZlciBlbmRwb2ludC5cbiAqL1xuaW50ZXJmYWNlIEFwcENoZWNrUmVzcG9uc2Uge1xuICB0b2tlbjogc3RyaW5nO1xuICAvLyB0aW1lVG9MaXZlXG4gIHR0bDogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgQXBwQ2hlY2tSZXF1ZXN0IHtcbiAgdXJsOiBzdHJpbmc7XG4gIGJvZHk6IHsgW2tleTogc3RyaW5nXTogc3RyaW5nIHwgYm9vbGVhbiB9O1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZXhjaGFuZ2VUb2tlbihcbiAgeyB1cmwsIGJvZHkgfTogQXBwQ2hlY2tSZXF1ZXN0LFxuICBoZWFydGJlYXRTZXJ2aWNlUHJvdmlkZXI6IFByb3ZpZGVyPCdoZWFydGJlYXQnPlxuKTogUHJvbWlzZTxBcHBDaGVja1Rva2VuSW50ZXJuYWw+IHtcbiAgY29uc3QgaGVhZGVyczogSGVhZGVyc0luaXQgPSB7XG4gICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJ1xuICB9O1xuICAvLyBJZiBoZWFydGJlYXQgc2VydmljZSBleGlzdHMsIGFkZCBoZWFydGJlYXQgaGVhZGVyIHN0cmluZyB0byB0aGUgaGVhZGVyLlxuICBjb25zdCBoZWFydGJlYXRTZXJ2aWNlID0gaGVhcnRiZWF0U2VydmljZVByb3ZpZGVyLmdldEltbWVkaWF0ZSh7XG4gICAgb3B0aW9uYWw6IHRydWVcbiAgfSk7XG4gIGlmIChoZWFydGJlYXRTZXJ2aWNlKSB7XG4gICAgY29uc3QgaGVhcnRiZWF0c0hlYWRlciA9IGF3YWl0IGhlYXJ0YmVhdFNlcnZpY2UuZ2V0SGVhcnRiZWF0c0hlYWRlcigpO1xuICAgIGlmIChoZWFydGJlYXRzSGVhZGVyKSB7XG4gICAgICBoZWFkZXJzWydYLUZpcmViYXNlLUNsaWVudCddID0gaGVhcnRiZWF0c0hlYWRlcjtcbiAgICB9XG4gIH1cbiAgY29uc3Qgb3B0aW9uczogUmVxdWVzdEluaXQgPSB7XG4gICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgYm9keTogSlNPTi5zdHJpbmdpZnkoYm9keSksXG4gICAgaGVhZGVyc1xuICB9O1xuICBsZXQgcmVzcG9uc2U7XG4gIHRyeSB7XG4gICAgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwsIG9wdGlvbnMpO1xuICB9IGNhdGNoIChvcmlnaW5hbEVycm9yKSB7XG4gICAgdGhyb3cgRVJST1JfRkFDVE9SWS5jcmVhdGUoQXBwQ2hlY2tFcnJvci5GRVRDSF9ORVRXT1JLX0VSUk9SLCB7XG4gICAgICBvcmlnaW5hbEVycm9yTWVzc2FnZTogKG9yaWdpbmFsRXJyb3IgYXMgRXJyb3IpPy5tZXNzYWdlXG4gICAgfSk7XG4gIH1cblxuICBpZiAocmVzcG9uc2Uuc3RhdHVzICE9PSAyMDApIHtcbiAgICB0aHJvdyBFUlJPUl9GQUNUT1JZLmNyZWF0ZShBcHBDaGVja0Vycm9yLkZFVENIX1NUQVRVU19FUlJPUiwge1xuICAgICAgaHR0cFN0YXR1czogcmVzcG9uc2Uuc3RhdHVzXG4gICAgfSk7XG4gIH1cblxuICBsZXQgcmVzcG9uc2VCb2R5OiBBcHBDaGVja1Jlc3BvbnNlO1xuICB0cnkge1xuICAgIC8vIEpTT04gcGFyc2luZyB0aHJvd3MgU3ludGF4RXJyb3IgaWYgdGhlIHJlc3BvbnNlIGJvZHkgaXNuJ3QgYSBKU09OIHN0cmluZy5cbiAgICByZXNwb25zZUJvZHkgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gIH0gY2F0Y2ggKG9yaWdpbmFsRXJyb3IpIHtcbiAgICB0aHJvdyBFUlJPUl9GQUNUT1JZLmNyZWF0ZShBcHBDaGVja0Vycm9yLkZFVENIX1BBUlNFX0VSUk9SLCB7XG4gICAgICBvcmlnaW5hbEVycm9yTWVzc2FnZTogKG9yaWdpbmFsRXJyb3IgYXMgRXJyb3IpPy5tZXNzYWdlXG4gICAgfSk7XG4gIH1cblxuICAvLyBQcm90b2J1ZiBkdXJhdGlvbiBmb3JtYXQuXG4gIC8vIGh0dHBzOi8vZGV2ZWxvcGVycy5nb29nbGUuY29tL3Byb3RvY29sLWJ1ZmZlcnMvZG9jcy9yZWZlcmVuY2UvamF2YS9jb20vZ29vZ2xlL3Byb3RvYnVmL0R1cmF0aW9uXG4gIGNvbnN0IG1hdGNoID0gcmVzcG9uc2VCb2R5LnR0bC5tYXRjaCgvXihbXFxkLl0rKShzKSQvKTtcbiAgaWYgKCFtYXRjaCB8fCAhbWF0Y2hbMl0gfHwgaXNOYU4oTnVtYmVyKG1hdGNoWzFdKSkpIHtcbiAgICB0aHJvdyBFUlJPUl9GQUNUT1JZLmNyZWF0ZShBcHBDaGVja0Vycm9yLkZFVENIX1BBUlNFX0VSUk9SLCB7XG4gICAgICBvcmlnaW5hbEVycm9yTWVzc2FnZTpcbiAgICAgICAgYHR0bCBmaWVsZCAodGltZVRvTGl2ZSkgaXMgbm90IGluIHN0YW5kYXJkIFByb3RvYnVmIER1cmF0aW9uIGAgK1xuICAgICAgICBgZm9ybWF0OiAke3Jlc3BvbnNlQm9keS50dGx9YFxuICAgIH0pO1xuICB9XG4gIGNvbnN0IHRpbWVUb0xpdmVBc051bWJlciA9IE51bWJlcihtYXRjaFsxXSkgKiAxMDAwO1xuXG4gIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gIHJldHVybiB7XG4gICAgdG9rZW46IHJlc3BvbnNlQm9keS50b2tlbixcbiAgICBleHBpcmVUaW1lTWlsbGlzOiBub3cgKyB0aW1lVG9MaXZlQXNOdW1iZXIsXG4gICAgaXNzdWVkQXRUaW1lTWlsbGlzOiBub3dcbiAgfTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGdldEV4Y2hhbmdlUmVjYXB0Y2hhVjNUb2tlblJlcXVlc3QoXG4gIGFwcDogRmlyZWJhc2VBcHAsXG4gIHJlQ0FQVENIQVRva2VuOiBzdHJpbmdcbik6IEFwcENoZWNrUmVxdWVzdCB7XG4gIGNvbnN0IHsgcHJvamVjdElkLCBhcHBJZCwgYXBpS2V5IH0gPSBhcHAub3B0aW9ucztcblxuICByZXR1cm4ge1xuICAgIHVybDogYCR7QkFTRV9FTkRQT0lOVH0vcHJvamVjdHMvJHtwcm9qZWN0SWR9L2FwcHMvJHthcHBJZH06JHtFWENIQU5HRV9SRUNBUFRDSEFfVE9LRU5fTUVUSE9EfT9rZXk9JHthcGlLZXl9YCxcbiAgICBib2R5OiB7XG4gICAgICAncmVjYXB0Y2hhX3YzX3Rva2VuJzogcmVDQVBUQ0hBVG9rZW5cbiAgICB9XG4gIH07XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBnZXRFeGNoYW5nZVJlY2FwdGNoYUVudGVycHJpc2VUb2tlblJlcXVlc3QoXG4gIGFwcDogRmlyZWJhc2VBcHAsXG4gIHJlQ0FQVENIQVRva2VuOiBzdHJpbmdcbik6IEFwcENoZWNrUmVxdWVzdCB7XG4gIGNvbnN0IHsgcHJvamVjdElkLCBhcHBJZCwgYXBpS2V5IH0gPSBhcHAub3B0aW9ucztcblxuICByZXR1cm4ge1xuICAgIHVybDogYCR7QkFTRV9FTkRQT0lOVH0vcHJvamVjdHMvJHtwcm9qZWN0SWR9L2FwcHMvJHthcHBJZH06JHtFWENIQU5HRV9SRUNBUFRDSEFfRU5URVJQUklTRV9UT0tFTl9NRVRIT0R9P2tleT0ke2FwaUtleX1gLFxuICAgIGJvZHk6IHtcbiAgICAgICdyZWNhcHRjaGFfZW50ZXJwcmlzZV90b2tlbic6IHJlQ0FQVENIQVRva2VuXG4gICAgfVxuICB9O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZ2V0RXhjaGFuZ2VEZWJ1Z1Rva2VuUmVxdWVzdChcbiAgYXBwOiBGaXJlYmFzZUFwcCxcbiAgZGVidWdUb2tlbjogc3RyaW5nXG4pOiBBcHBDaGVja1JlcXVlc3Qge1xuICBjb25zdCB7IHByb2plY3RJZCwgYXBwSWQsIGFwaUtleSB9ID0gYXBwLm9wdGlvbnM7XG5cbiAgcmV0dXJuIHtcbiAgICB1cmw6IGAke0JBU0VfRU5EUE9JTlR9L3Byb2plY3RzLyR7cHJvamVjdElkfS9hcHBzLyR7YXBwSWR9OiR7RVhDSEFOR0VfREVCVUdfVE9LRU5fTUVUSE9EfT9rZXk9JHthcGlLZXl9YCxcbiAgICBib2R5OiB7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmVcbiAgICAgIGRlYnVnX3Rva2VuOiBkZWJ1Z1Rva2VuXG4gICAgfVxuICB9O1xufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgRmlyZWJhc2VBcHAgfSBmcm9tICdAZmlyZWJhc2UvYXBwJztcbmltcG9ydCB7IEVSUk9SX0ZBQ1RPUlksIEFwcENoZWNrRXJyb3IgfSBmcm9tICcuL2Vycm9ycyc7XG5pbXBvcnQgeyBBcHBDaGVja1Rva2VuSW50ZXJuYWwgfSBmcm9tICcuL3R5cGVzJztcbmNvbnN0IERCX05BTUUgPSAnZmlyZWJhc2UtYXBwLWNoZWNrLWRhdGFiYXNlJztcbmNvbnN0IERCX1ZFUlNJT04gPSAxO1xuY29uc3QgU1RPUkVfTkFNRSA9ICdmaXJlYmFzZS1hcHAtY2hlY2stc3RvcmUnO1xuY29uc3QgREVCVUdfVE9LRU5fS0VZID0gJ2RlYnVnLXRva2VuJztcblxubGV0IGRiUHJvbWlzZTogUHJvbWlzZTxJREJEYXRhYmFzZT4gfCBudWxsID0gbnVsbDtcbmZ1bmN0aW9uIGdldERCUHJvbWlzZSgpOiBQcm9taXNlPElEQkRhdGFiYXNlPiB7XG4gIGlmIChkYlByb21pc2UpIHtcbiAgICByZXR1cm4gZGJQcm9taXNlO1xuICB9XG5cbiAgZGJQcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXF1ZXN0ID0gaW5kZXhlZERCLm9wZW4oREJfTkFNRSwgREJfVkVSU0lPTik7XG5cbiAgICAgIHJlcXVlc3Qub25zdWNjZXNzID0gZXZlbnQgPT4ge1xuICAgICAgICByZXNvbHZlKChldmVudC50YXJnZXQgYXMgSURCT3BlbkRCUmVxdWVzdCkucmVzdWx0KTtcbiAgICAgIH07XG5cbiAgICAgIHJlcXVlc3Qub25lcnJvciA9IGV2ZW50ID0+IHtcbiAgICAgICAgcmVqZWN0KFxuICAgICAgICAgIEVSUk9SX0ZBQ1RPUlkuY3JlYXRlKEFwcENoZWNrRXJyb3IuU1RPUkFHRV9PUEVOLCB7XG4gICAgICAgICAgICBvcmlnaW5hbEVycm9yTWVzc2FnZTogKGV2ZW50LnRhcmdldCBhcyBJREJSZXF1ZXN0KS5lcnJvcj8ubWVzc2FnZVxuICAgICAgICAgIH0pXG4gICAgICAgICk7XG4gICAgICB9O1xuXG4gICAgICByZXF1ZXN0Lm9udXBncmFkZW5lZWRlZCA9IGV2ZW50ID0+IHtcbiAgICAgICAgY29uc3QgZGIgPSAoZXZlbnQudGFyZ2V0IGFzIElEQk9wZW5EQlJlcXVlc3QpLnJlc3VsdDtcblxuICAgICAgICAvLyBXZSBkb24ndCB1c2UgJ2JyZWFrJyBpbiB0aGlzIHN3aXRjaCBzdGF0ZW1lbnQsIHRoZSBmYWxsLXRocm91Z2hcbiAgICAgICAgLy8gYmVoYXZpb3IgaXMgd2hhdCB3ZSB3YW50LCBiZWNhdXNlIGlmIHRoZXJlIGFyZSBtdWx0aXBsZSB2ZXJzaW9ucyBiZXR3ZWVuXG4gICAgICAgIC8vIHRoZSBvbGQgdmVyc2lvbiBhbmQgdGhlIGN1cnJlbnQgdmVyc2lvbiwgd2Ugd2FudCBBTEwgdGhlIG1pZ3JhdGlvbnNcbiAgICAgICAgLy8gdGhhdCBjb3JyZXNwb25kIHRvIHRob3NlIHZlcnNpb25zIHRvIHJ1biwgbm90IG9ubHkgdGhlIGxhc3Qgb25lLlxuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgZGVmYXVsdC1jYXNlXG4gICAgICAgIHN3aXRjaCAoZXZlbnQub2xkVmVyc2lvbikge1xuICAgICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgIGRiLmNyZWF0ZU9iamVjdFN0b3JlKFNUT1JFX05BTUUsIHtcbiAgICAgICAgICAgICAga2V5UGF0aDogJ2NvbXBvc2l0ZUtleSdcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9O1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHJlamVjdChcbiAgICAgICAgRVJST1JfRkFDVE9SWS5jcmVhdGUoQXBwQ2hlY2tFcnJvci5TVE9SQUdFX09QRU4sIHtcbiAgICAgICAgICBvcmlnaW5hbEVycm9yTWVzc2FnZTogKGUgYXMgRXJyb3IpPy5tZXNzYWdlXG4gICAgICAgIH0pXG4gICAgICApO1xuICAgIH1cbiAgfSk7XG5cbiAgcmV0dXJuIGRiUHJvbWlzZTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHJlYWRUb2tlbkZyb21JbmRleGVkREIoXG4gIGFwcDogRmlyZWJhc2VBcHBcbik6IFByb21pc2U8QXBwQ2hlY2tUb2tlbkludGVybmFsIHwgdW5kZWZpbmVkPiB7XG4gIHJldHVybiByZWFkKGNvbXB1dGVLZXkoYXBwKSkgYXMgUHJvbWlzZTxBcHBDaGVja1Rva2VuSW50ZXJuYWwgfCB1bmRlZmluZWQ+O1xufVxuXG5leHBvcnQgZnVuY3Rpb24gd3JpdGVUb2tlblRvSW5kZXhlZERCKFxuICBhcHA6IEZpcmViYXNlQXBwLFxuICB0b2tlbj86IEFwcENoZWNrVG9rZW5JbnRlcm5hbFxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIHJldHVybiB3cml0ZShjb21wdXRlS2V5KGFwcCksIHRva2VuKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHdyaXRlRGVidWdUb2tlblRvSW5kZXhlZERCKHRva2VuOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgcmV0dXJuIHdyaXRlKERFQlVHX1RPS0VOX0tFWSwgdG9rZW4pO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVhZERlYnVnVG9rZW5Gcm9tSW5kZXhlZERCKCk6IFByb21pc2U8c3RyaW5nIHwgdW5kZWZpbmVkPiB7XG4gIHJldHVybiByZWFkKERFQlVHX1RPS0VOX0tFWSkgYXMgUHJvbWlzZTxzdHJpbmcgfCB1bmRlZmluZWQ+O1xufVxuXG5hc3luYyBmdW5jdGlvbiB3cml0ZShrZXk6IHN0cmluZywgdmFsdWU6IHVua25vd24pOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgZGIgPSBhd2FpdCBnZXREQlByb21pc2UoKTtcblxuICBjb25zdCB0cmFuc2FjdGlvbiA9IGRiLnRyYW5zYWN0aW9uKFNUT1JFX05BTUUsICdyZWFkd3JpdGUnKTtcbiAgY29uc3Qgc3RvcmUgPSB0cmFuc2FjdGlvbi5vYmplY3RTdG9yZShTVE9SRV9OQU1FKTtcbiAgY29uc3QgcmVxdWVzdCA9IHN0b3JlLnB1dCh7XG4gICAgY29tcG9zaXRlS2V5OiBrZXksXG4gICAgdmFsdWVcbiAgfSk7XG5cbiAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICByZXF1ZXN0Lm9uc3VjY2VzcyA9IF9ldmVudCA9PiB7XG4gICAgICByZXNvbHZlKCk7XG4gICAgfTtcblxuICAgIHRyYW5zYWN0aW9uLm9uZXJyb3IgPSBldmVudCA9PiB7XG4gICAgICByZWplY3QoXG4gICAgICAgIEVSUk9SX0ZBQ1RPUlkuY3JlYXRlKEFwcENoZWNrRXJyb3IuU1RPUkFHRV9XUklURSwge1xuICAgICAgICAgIG9yaWdpbmFsRXJyb3JNZXNzYWdlOiAoZXZlbnQudGFyZ2V0IGFzIElEQlJlcXVlc3QpLmVycm9yPy5tZXNzYWdlXG4gICAgICAgIH0pXG4gICAgICApO1xuICAgIH07XG4gIH0pO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWFkKGtleTogc3RyaW5nKTogUHJvbWlzZTx1bmtub3duPiB7XG4gIGNvbnN0IGRiID0gYXdhaXQgZ2V0REJQcm9taXNlKCk7XG5cbiAgY29uc3QgdHJhbnNhY3Rpb24gPSBkYi50cmFuc2FjdGlvbihTVE9SRV9OQU1FLCAncmVhZG9ubHknKTtcbiAgY29uc3Qgc3RvcmUgPSB0cmFuc2FjdGlvbi5vYmplY3RTdG9yZShTVE9SRV9OQU1FKTtcbiAgY29uc3QgcmVxdWVzdCA9IHN0b3JlLmdldChrZXkpO1xuXG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgcmVxdWVzdC5vbnN1Y2Nlc3MgPSBldmVudCA9PiB7XG4gICAgICBjb25zdCByZXN1bHQgPSAoZXZlbnQudGFyZ2V0IGFzIElEQlJlcXVlc3QpLnJlc3VsdDtcblxuICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICByZXNvbHZlKHJlc3VsdC52YWx1ZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXNvbHZlKHVuZGVmaW5lZCk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIHRyYW5zYWN0aW9uLm9uZXJyb3IgPSBldmVudCA9PiB7XG4gICAgICByZWplY3QoXG4gICAgICAgIEVSUk9SX0ZBQ1RPUlkuY3JlYXRlKEFwcENoZWNrRXJyb3IuU1RPUkFHRV9HRVQsIHtcbiAgICAgICAgICBvcmlnaW5hbEVycm9yTWVzc2FnZTogKGV2ZW50LnRhcmdldCBhcyBJREJSZXF1ZXN0KS5lcnJvcj8ubWVzc2FnZVxuICAgICAgICB9KVxuICAgICAgKTtcbiAgICB9O1xuICB9KTtcbn1cblxuZnVuY3Rpb24gY29tcHV0ZUtleShhcHA6IEZpcmViYXNlQXBwKTogc3RyaW5nIHtcbiAgcmV0dXJuIGAke2FwcC5vcHRpb25zLmFwcElkfS0ke2FwcC5uYW1lfWA7XG59XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAyMCBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG5pbXBvcnQgeyBMb2dnZXIgfSBmcm9tICdAZmlyZWJhc2UvbG9nZ2VyJztcblxuZXhwb3J0IGNvbnN0IGxvZ2dlciA9IG5ldyBMb2dnZXIoJ0BmaXJlYmFzZS9hcHAtY2hlY2snKTtcbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDIwIEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmltcG9ydCB7IEZpcmViYXNlQXBwIH0gZnJvbSAnQGZpcmViYXNlL2FwcCc7XG5pbXBvcnQgeyBpc0luZGV4ZWREQkF2YWlsYWJsZSB9IGZyb20gJ0BmaXJlYmFzZS91dGlsJztcbmltcG9ydCB7XG4gIHJlYWREZWJ1Z1Rva2VuRnJvbUluZGV4ZWREQixcbiAgcmVhZFRva2VuRnJvbUluZGV4ZWREQixcbiAgd3JpdGVEZWJ1Z1Rva2VuVG9JbmRleGVkREIsXG4gIHdyaXRlVG9rZW5Ub0luZGV4ZWREQlxufSBmcm9tICcuL2luZGV4ZWRkYic7XG5pbXBvcnQgeyBsb2dnZXIgfSBmcm9tICcuL2xvZ2dlcic7XG5pbXBvcnQgeyBBcHBDaGVja1Rva2VuSW50ZXJuYWwgfSBmcm9tICcuL3R5cGVzJztcblxuLyoqXG4gKiBBbHdheXMgcmVzb2x2ZXMuIEluIGNhc2Ugb2YgYW4gZXJyb3IgcmVhZGluZyBmcm9tIGluZGV4ZWRkYiwgcmVzb2x2ZSB3aXRoIHVuZGVmaW5lZFxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVhZFRva2VuRnJvbVN0b3JhZ2UoXG4gIGFwcDogRmlyZWJhc2VBcHBcbik6IFByb21pc2U8QXBwQ2hlY2tUb2tlbkludGVybmFsIHwgdW5kZWZpbmVkPiB7XG4gIGlmIChpc0luZGV4ZWREQkF2YWlsYWJsZSgpKSB7XG4gICAgbGV0IHRva2VuID0gdW5kZWZpbmVkO1xuICAgIHRyeSB7XG4gICAgICB0b2tlbiA9IGF3YWl0IHJlYWRUb2tlbkZyb21JbmRleGVkREIoYXBwKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAvLyBzd2FsbG93IHRoZSBlcnJvciBhbmQgcmV0dXJuIHVuZGVmaW5lZFxuICAgICAgbG9nZ2VyLndhcm4oYEZhaWxlZCB0byByZWFkIHRva2VuIGZyb20gSW5kZXhlZERCLiBFcnJvcjogJHtlfWApO1xuICAgIH1cbiAgICByZXR1cm4gdG9rZW47XG4gIH1cblxuICByZXR1cm4gdW5kZWZpbmVkO1xufVxuXG4vKipcbiAqIEFsd2F5cyByZXNvbHZlcy4gSW4gY2FzZSBvZiBhbiBlcnJvciB3cml0aW5nIHRvIGluZGV4ZWRkYiwgcHJpbnQgYSB3YXJuaW5nIGFuZCByZXNvbHZlIHRoZSBwcm9taXNlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB3cml0ZVRva2VuVG9TdG9yYWdlKFxuICBhcHA6IEZpcmViYXNlQXBwLFxuICB0b2tlbj86IEFwcENoZWNrVG9rZW5JbnRlcm5hbFxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGlmIChpc0luZGV4ZWREQkF2YWlsYWJsZSgpKSB7XG4gICAgcmV0dXJuIHdyaXRlVG9rZW5Ub0luZGV4ZWREQihhcHAsIHRva2VuKS5jYXRjaChlID0+IHtcbiAgICAgIC8vIHN3YWxsb3cgdGhlIGVycm9yIGFuZCByZXNvbHZlIHRoZSBwcm9taXNlXG4gICAgICBsb2dnZXIud2FybihgRmFpbGVkIHRvIHdyaXRlIHRva2VuIHRvIEluZGV4ZWREQi4gRXJyb3I6ICR7ZX1gKTtcbiAgICB9KTtcbiAgfVxuXG4gIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlYWRPckNyZWF0ZURlYnVnVG9rZW5Gcm9tU3RvcmFnZSgpOiBQcm9taXNlPHN0cmluZz4ge1xuICAvKipcbiAgICogVGhlb3JldGljYWxseSByYWNlIGNvbmRpdGlvbiBjYW4gaGFwcGVuIGlmIHdlIHJlYWQsIHRoZW4gd3JpdGUgaW4gMiBzZXBhcmF0ZSB0cmFuc2FjdGlvbnMuXG4gICAqIEJ1dCBpdCB3b24ndCBoYXBwZW4gaGVyZSwgYmVjYXVzZSB0aGlzIGZ1bmN0aW9uIHdpbGwgYmUgY2FsbGVkIGV4YWN0bHkgb25jZS5cbiAgICovXG4gIGxldCBleGlzdGluZ0RlYnVnVG9rZW46IHN0cmluZyB8IHVuZGVmaW5lZCA9IHVuZGVmaW5lZDtcbiAgdHJ5IHtcbiAgICBleGlzdGluZ0RlYnVnVG9rZW4gPSBhd2FpdCByZWFkRGVidWdUb2tlbkZyb21JbmRleGVkREIoKTtcbiAgfSBjYXRjaCAoX2UpIHtcbiAgICAvLyBmYWlsZWQgdG8gcmVhZCBmcm9tIGluZGV4ZWRkYi4gV2UgYXNzdW1lIHRoZXJlIGlzIG5vIGV4aXN0aW5nIGRlYnVnIHRva2VuLCBhbmQgZ2VuZXJhdGUgYSBuZXcgb25lLlxuICB9XG5cbiAgaWYgKCFleGlzdGluZ0RlYnVnVG9rZW4pIHtcbiAgICAvLyBjcmVhdGUgYSBuZXcgZGVidWcgdG9rZW5cbiAgICAvLyBUaGlzIGZ1bmN0aW9uIGlzIG9ubHkgYXZhaWxhYmxlIGluIHNlY3VyZSBjb250ZXh0cy4gU2VlIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL1NlY3VyaXR5L1NlY3VyZV9Db250ZXh0c1xuICAgIGNvbnN0IG5ld1Rva2VuID0gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbiAgICAvLyBXZSBkb24ndCBuZWVkIHRvIGJsb2NrIG9uIHdyaXRpbmcgdG8gaW5kZXhlZGRiXG4gICAgLy8gSW4gY2FzZSBwZXJzaXN0ZW5jZSBmYWlsZWQsIGEgbmV3IGRlYnVnIHRva2VuIHdpbGwgYmUgZ2VuZXJhdGVkIGV2ZXJ5IHRpbWUgdGhlIHBhZ2UgaXMgcmVmcmVzaGVkLlxuICAgIC8vIEl0IHJlbmRlcnMgdGhlIGRlYnVnIHRva2VuIHVzZWxlc3MgYmVjYXVzZSB5b3UgaGF2ZSB0byBtYW51YWxseSByZWdpc3Rlcih3aGl0ZWxpc3QpIHRoZSBuZXcgdG9rZW4gaW4gdGhlIGZpcmViYXNlIGNvbnNvbGUgYWdhaW4gYW5kIGFnYWluLlxuICAgIC8vIElmIHlvdSBzZWUgdGhpcyBlcnJvciB0cnlpbmcgdG8gdXNlIGRlYnVnIHRva2VuLCBpdCBwcm9iYWJseSBtZWFucyB5b3UgYXJlIHVzaW5nIGEgYnJvd3NlciB0aGF0IGRvZXNuJ3Qgc3VwcG9ydCBpbmRleGVkZGIuXG4gICAgLy8gWW91IHNob3VsZCBzd2l0Y2ggdG8gYSBkaWZmZXJlbnQgYnJvd3NlciB0aGF0IHN1cHBvcnRzIGluZGV4ZWRkYlxuICAgIHdyaXRlRGVidWdUb2tlblRvSW5kZXhlZERCKG5ld1Rva2VuKS5jYXRjaChlID0+XG4gICAgICBsb2dnZXIud2FybihgRmFpbGVkIHRvIHBlcnNpc3QgZGVidWcgdG9rZW4gdG8gSW5kZXhlZERCLiBFcnJvcjogJHtlfWApXG4gICAgKTtcbiAgICByZXR1cm4gbmV3VG9rZW47XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIGV4aXN0aW5nRGVidWdUb2tlbjtcbiAgfVxufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgZ2V0RGVidWdTdGF0ZSB9IGZyb20gJy4vc3RhdGUnO1xuaW1wb3J0IHsgcmVhZE9yQ3JlYXRlRGVidWdUb2tlbkZyb21TdG9yYWdlIH0gZnJvbSAnLi9zdG9yYWdlJztcbmltcG9ydCB7IERlZmVycmVkLCBnZXRHbG9iYWwgfSBmcm9tICdAZmlyZWJhc2UvdXRpbCc7XG5cbmRlY2xhcmUgZ2xvYmFsIHtcbiAgLy8gdmFyIG11c3QgYmUgdXNlZCBmb3IgZ2xvYmFsIHNjb3Blc1xuICAvLyBodHRwczovL3d3dy50eXBlc2NyaXB0bGFuZy5vcmcvZG9jcy9oYW5kYm9vay9yZWxlYXNlLW5vdGVzL3R5cGVzY3JpcHQtMy00Lmh0bWwjdHlwZS1jaGVja2luZy1mb3ItZ2xvYmFsdGhpc1xuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdmFyXG4gIHZhciBGSVJFQkFTRV9BUFBDSEVDS19ERUJVR19UT0tFTjogYm9vbGVhbiB8IHN0cmluZyB8IHVuZGVmaW5lZDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRGVidWdNb2RlKCk6IGJvb2xlYW4ge1xuICBjb25zdCBkZWJ1Z1N0YXRlID0gZ2V0RGVidWdTdGF0ZSgpO1xuICByZXR1cm4gZGVidWdTdGF0ZS5lbmFibGVkO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RGVidWdUb2tlbigpOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCBzdGF0ZSA9IGdldERlYnVnU3RhdGUoKTtcblxuICBpZiAoc3RhdGUuZW5hYmxlZCAmJiBzdGF0ZS50b2tlbikge1xuICAgIHJldHVybiBzdGF0ZS50b2tlbi5wcm9taXNlO1xuICB9IGVsc2Uge1xuICAgIC8vIHNob3VsZCBub3QgaGFwcGVuIVxuICAgIHRocm93IEVycm9yKGBcbiAgICAgICAgICAgIENhbid0IGdldCBkZWJ1ZyB0b2tlbiBpbiBwcm9kdWN0aW9uIG1vZGUuXG4gICAgICAgIGApO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpbml0aWFsaXplRGVidWdNb2RlKCk6IHZvaWQge1xuICBjb25zdCBnbG9iYWxzID0gZ2V0R2xvYmFsKCk7XG4gIGNvbnN0IGRlYnVnU3RhdGUgPSBnZXREZWJ1Z1N0YXRlKCk7XG4gIC8vIFNldCB0byB0cnVlIGlmIHRoaXMgZnVuY3Rpb24gaGFzIGJlZW4gY2FsbGVkLCB3aGV0aGVyIG9yIG5vdFxuICAvLyBpdCBlbmFibGVkIGRlYnVnIG1vZGUuXG4gIGRlYnVnU3RhdGUuaW5pdGlhbGl6ZWQgPSB0cnVlO1xuXG4gIGlmIChcbiAgICB0eXBlb2YgZ2xvYmFscy5GSVJFQkFTRV9BUFBDSEVDS19ERUJVR19UT0tFTiAhPT0gJ3N0cmluZycgJiZcbiAgICBnbG9iYWxzLkZJUkVCQVNFX0FQUENIRUNLX0RFQlVHX1RPS0VOICE9PSB0cnVlXG4gICkge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGRlYnVnU3RhdGUuZW5hYmxlZCA9IHRydWU7XG4gIGNvbnN0IGRlZmVycmVkVG9rZW4gPSBuZXcgRGVmZXJyZWQ8c3RyaW5nPigpO1xuICBkZWJ1Z1N0YXRlLnRva2VuID0gZGVmZXJyZWRUb2tlbjtcblxuICBpZiAodHlwZW9mIGdsb2JhbHMuRklSRUJBU0VfQVBQQ0hFQ0tfREVCVUdfVE9LRU4gPT09ICdzdHJpbmcnKSB7XG4gICAgZGVmZXJyZWRUb2tlbi5yZXNvbHZlKGdsb2JhbHMuRklSRUJBU0VfQVBQQ0hFQ0tfREVCVUdfVE9LRU4pO1xuICB9IGVsc2Uge1xuICAgIGRlZmVycmVkVG9rZW4ucmVzb2x2ZShyZWFkT3JDcmVhdGVEZWJ1Z1Rva2VuRnJvbVN0b3JhZ2UoKSk7XG4gIH1cbn1cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDIwIEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmltcG9ydCB7IEZpcmViYXNlQXBwIH0gZnJvbSAnQGZpcmViYXNlL2FwcCc7XG5pbXBvcnQge1xuICBBcHBDaGVja1Rva2VuUmVzdWx0LFxuICBBcHBDaGVja1Rva2VuSW50ZXJuYWwsXG4gIEFwcENoZWNrVG9rZW5PYnNlcnZlcixcbiAgTGlzdGVuZXJUeXBlXG59IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHsgQXBwQ2hlY2tUb2tlbkxpc3RlbmVyIH0gZnJvbSAnLi9wdWJsaWMtdHlwZXMnO1xuaW1wb3J0IHsgZ2V0U3RhdGVSZWZlcmVuY2UgfSBmcm9tICcuL3N0YXRlJztcbmltcG9ydCB7IFRPS0VOX1JFRlJFU0hfVElNRSB9IGZyb20gJy4vY29uc3RhbnRzJztcbmltcG9ydCB7IFJlZnJlc2hlciB9IGZyb20gJy4vcHJvYWN0aXZlLXJlZnJlc2gnO1xuaW1wb3J0IHsgZW5zdXJlQWN0aXZhdGVkIH0gZnJvbSAnLi91dGlsJztcbmltcG9ydCB7IGV4Y2hhbmdlVG9rZW4sIGdldEV4Y2hhbmdlRGVidWdUb2tlblJlcXVlc3QgfSBmcm9tICcuL2NsaWVudCc7XG5pbXBvcnQgeyB3cml0ZVRva2VuVG9TdG9yYWdlIH0gZnJvbSAnLi9zdG9yYWdlJztcbmltcG9ydCB7IGdldERlYnVnVG9rZW4sIGlzRGVidWdNb2RlIH0gZnJvbSAnLi9kZWJ1Zyc7XG5pbXBvcnQgeyBiYXNlNjQsIEZpcmViYXNlRXJyb3IgfSBmcm9tICdAZmlyZWJhc2UvdXRpbCc7XG5pbXBvcnQgeyBsb2dnZXIgfSBmcm9tICcuL2xvZ2dlcic7XG5pbXBvcnQgeyBBcHBDaGVja1NlcnZpY2UgfSBmcm9tICcuL2ZhY3RvcnknO1xuaW1wb3J0IHsgQXBwQ2hlY2tFcnJvciB9IGZyb20gJy4vZXJyb3JzJztcblxuLy8gSW5pdGlhbCBoYXJkY29kZWQgdmFsdWUgYWdyZWVkIHVwb24gYWNyb3NzIHBsYXRmb3JtcyBmb3IgaW5pdGlhbCBsYXVuY2guXG4vLyBGb3JtYXQgbGVmdCBvcGVuIGZvciBwb3NzaWJsZSBkeW5hbWljIGVycm9yIHZhbHVlcyBhbmQgb3RoZXIgZmllbGRzIGluIHRoZSBmdXR1cmUuXG5leHBvcnQgY29uc3QgZGVmYXVsdFRva2VuRXJyb3JEYXRhID0geyBlcnJvcjogJ1VOS05PV05fRVJST1InIH07XG5cbi8qKlxuICogU3RyaW5naWZ5IGFuZCBiYXNlNjQgZW5jb2RlIHRva2VuIGVycm9yIGRhdGEuXG4gKlxuICogQHBhcmFtIHRva2VuRXJyb3IgRXJyb3IgZGF0YSwgY3VycmVudGx5IGhhcmRjb2RlZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdER1bW15VG9rZW4oXG4gIHRva2VuRXJyb3JEYXRhOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+XG4pOiBzdHJpbmcge1xuICByZXR1cm4gYmFzZTY0LmVuY29kZVN0cmluZyhcbiAgICBKU09OLnN0cmluZ2lmeSh0b2tlbkVycm9yRGF0YSksXG4gICAgLyogd2ViU2FmZT0gKi8gZmFsc2VcbiAgKTtcbn1cblxuLyoqXG4gKiBUaGlzIGZ1bmN0aW9uIGFsd2F5cyByZXNvbHZlcy5cbiAqIFRoZSByZXN1bHQgd2lsbCBjb250YWluIGFuIGVycm9yIGZpZWxkIGlmIHRoZXJlIGlzIGFueSBlcnJvci5cbiAqIEluIGNhc2UgdGhlcmUgaXMgYW4gZXJyb3IsIHRoZSB0b2tlbiBmaWVsZCBpbiB0aGUgcmVzdWx0IHdpbGwgYmUgcG9wdWxhdGVkIHdpdGggYSBkdW1teSB2YWx1ZVxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VG9rZW4oXG4gIGFwcENoZWNrOiBBcHBDaGVja1NlcnZpY2UsXG4gIGZvcmNlUmVmcmVzaCA9IGZhbHNlLFxuICBzaG91bGRMb2dFcnJvcnMgPSBmYWxzZVxuKTogUHJvbWlzZTxBcHBDaGVja1Rva2VuUmVzdWx0PiB7XG4gIGNvbnN0IGFwcCA9IGFwcENoZWNrLmFwcDtcbiAgZW5zdXJlQWN0aXZhdGVkKGFwcCk7XG5cbiAgY29uc3Qgc3RhdGUgPSBnZXRTdGF0ZVJlZmVyZW5jZShhcHApO1xuXG4gIC8qKlxuICAgKiBGaXJzdCBjaGVjayBpZiB0aGVyZSBpcyBhIHRva2VuIGluIG1lbW9yeSBmcm9tIGEgcHJldmlvdXMgYGdldFRva2VuKClgIGNhbGwuXG4gICAqL1xuICBsZXQgdG9rZW46IEFwcENoZWNrVG9rZW5JbnRlcm5hbCB8IHVuZGVmaW5lZCA9IHN0YXRlLnRva2VuO1xuICBsZXQgZXJyb3I6IEVycm9yIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuXG4gIC8qKlxuICAgKiBJZiBhbiBpbnZhbGlkIHRva2VuIHdhcyBmb3VuZCBpbiBtZW1vcnksIGNsZWFyIHRva2VuIGZyb21cbiAgICogbWVtb3J5IGFuZCB1bnNldCB0aGUgbG9jYWwgdmFyaWFibGUgYHRva2VuYC5cbiAgICovXG4gIGlmICh0b2tlbiAmJiAhaXNWYWxpZCh0b2tlbikpIHtcbiAgICBzdGF0ZS50b2tlbiA9IHVuZGVmaW5lZDtcbiAgICB0b2tlbiA9IHVuZGVmaW5lZDtcbiAgfVxuXG4gIC8qKlxuICAgKiBJZiB0aGVyZSBpcyBubyB2YWxpZCB0b2tlbiBpbiBtZW1vcnksIHRyeSB0byBsb2FkIHRva2VuIGZyb20gaW5kZXhlZERCLlxuICAgKi9cbiAgaWYgKCF0b2tlbikge1xuICAgIC8vIGNhY2hlZFRva2VuUHJvbWlzZSBjb250YWlucyB0aGUgdG9rZW4gZm91bmQgaW4gSW5kZXhlZERCIG9yIHVuZGVmaW5lZCBpZiBub3QgZm91bmQuXG4gICAgY29uc3QgY2FjaGVkVG9rZW4gPSBhd2FpdCBzdGF0ZS5jYWNoZWRUb2tlblByb21pc2U7XG4gICAgaWYgKGNhY2hlZFRva2VuKSB7XG4gICAgICBpZiAoaXNWYWxpZChjYWNoZWRUb2tlbikpIHtcbiAgICAgICAgdG9rZW4gPSBjYWNoZWRUb2tlbjtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIElmIHRoZXJlIHdhcyBhbiBpbnZhbGlkIHRva2VuIGluIHRoZSBpbmRleGVkREIgY2FjaGUsIGNsZWFyIGl0LlxuICAgICAgICBhd2FpdCB3cml0ZVRva2VuVG9TdG9yYWdlKGFwcCwgdW5kZWZpbmVkKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvLyBSZXR1cm4gdGhlIGNhY2hlZCB0b2tlbiAoZnJvbSBlaXRoZXIgbWVtb3J5IG9yIGluZGV4ZWREQikgaWYgaXQncyB2YWxpZFxuICBpZiAoIWZvcmNlUmVmcmVzaCAmJiB0b2tlbiAmJiBpc1ZhbGlkKHRva2VuKSkge1xuICAgIHJldHVybiB7XG4gICAgICB0b2tlbjogdG9rZW4udG9rZW5cbiAgICB9O1xuICB9XG5cbiAgLy8gT25seSBzZXQgdG8gdHJ1ZSBpZiB0aGlzIGBnZXRUb2tlbigpYCBjYWxsIGlzIG1ha2luZyB0aGUgYWN0dWFsXG4gIC8vIFJFU1QgY2FsbCB0byB0aGUgZXhjaGFuZ2UgZW5kcG9pbnQsIHZlcnN1cyB3YWl0aW5nIGZvciBhbiBhbHJlYWR5XG4gIC8vIGluLWZsaWdodCBjYWxsIChzZWUgZGVidWcgYW5kIHJlZ3VsYXIgZXhjaGFuZ2UgZW5kcG9pbnQgcGF0aHMgYmVsb3cpXG4gIGxldCBzaG91bGRDYWxsTGlzdGVuZXJzID0gZmFsc2U7XG5cbiAgLyoqXG4gICAqIERFQlVHIE1PREVcbiAgICogSWYgZGVidWcgbW9kZSBpcyBzZXQsIGFuZCB0aGVyZSBpcyBubyBjYWNoZWQgdG9rZW4sIGZldGNoIGEgbmV3IEFwcFxuICAgKiBDaGVjayB0b2tlbiB1c2luZyB0aGUgZGVidWcgdG9rZW4sIGFuZCByZXR1cm4gaXQgZGlyZWN0bHkuXG4gICAqL1xuICBpZiAoaXNEZWJ1Z01vZGUoKSkge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBkZWJ1Z1Rva2VuID0gYXdhaXQgZ2V0RGVidWdUb2tlbigpO1xuICAgICAgLy8gQXZvaWQgbWFraW5nIGFub3RoZXIgY2FsbCB0byB0aGUgZXhjaGFuZ2UgZW5kcG9pbnQgaWYgb25lIGlzIGluIGZsaWdodC5cbiAgICAgIGlmICghc3RhdGUuZXhjaGFuZ2VUb2tlblByb21pc2UpIHtcbiAgICAgICAgc3RhdGUuZXhjaGFuZ2VUb2tlblByb21pc2UgPSBleGNoYW5nZVRva2VuKFxuICAgICAgICAgIGdldEV4Y2hhbmdlRGVidWdUb2tlblJlcXVlc3QoYXBwLCBkZWJ1Z1Rva2VuKSxcbiAgICAgICAgICBhcHBDaGVjay5oZWFydGJlYXRTZXJ2aWNlUHJvdmlkZXJcbiAgICAgICAgKS5maW5hbGx5KCgpID0+IHtcbiAgICAgICAgICAvLyBDbGVhciBwcm9taXNlIHdoZW4gc2V0dGxlZCAtIGVpdGhlciByZXNvbHZlZCBvciByZWplY3RlZC5cbiAgICAgICAgICBzdGF0ZS5leGNoYW5nZVRva2VuUHJvbWlzZSA9IHVuZGVmaW5lZDtcbiAgICAgICAgfSk7XG4gICAgICAgIHNob3VsZENhbGxMaXN0ZW5lcnMgPSB0cnVlO1xuICAgICAgfVxuICAgICAgY29uc3QgdG9rZW5Gcm9tRGVidWdFeGNoYW5nZTogQXBwQ2hlY2tUb2tlbkludGVybmFsID1cbiAgICAgICAgYXdhaXQgc3RhdGUuZXhjaGFuZ2VUb2tlblByb21pc2U7XG4gICAgICAvLyBXcml0ZSBkZWJ1ZyB0b2tlbiB0byBpbmRleGVkREIuXG4gICAgICBhd2FpdCB3cml0ZVRva2VuVG9TdG9yYWdlKGFwcCwgdG9rZW5Gcm9tRGVidWdFeGNoYW5nZSk7XG4gICAgICAvLyBXcml0ZSBkZWJ1ZyB0b2tlbiB0byBzdGF0ZS5cbiAgICAgIHN0YXRlLnRva2VuID0gdG9rZW5Gcm9tRGVidWdFeGNoYW5nZTtcbiAgICAgIHJldHVybiB7IHRva2VuOiB0b2tlbkZyb21EZWJ1Z0V4Y2hhbmdlLnRva2VuIH07XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgaWYgKFxuICAgICAgICAoZSBhcyBGaXJlYmFzZUVycm9yKS5jb2RlID09PSBgYXBwQ2hlY2svJHtBcHBDaGVja0Vycm9yLlRIUk9UVExFRH1gIHx8XG4gICAgICAgIChlIGFzIEZpcmViYXNlRXJyb3IpLmNvZGUgPT09XG4gICAgICAgICAgYGFwcENoZWNrLyR7QXBwQ2hlY2tFcnJvci5JTklUSUFMX1RIUk9UVExFfWBcbiAgICAgICkge1xuICAgICAgICAvLyBXYXJuIGlmIHRocm90dGxlZCwgYnV0IGRvIG5vdCB0cmVhdCBpdCBhcyBhbiBlcnJvci5cbiAgICAgICAgbG9nZ2VyLndhcm4oKGUgYXMgRmlyZWJhc2VFcnJvcikubWVzc2FnZSk7XG4gICAgICB9IGVsc2UgaWYgKHNob3VsZExvZ0Vycm9ycykge1xuICAgICAgICBsb2dnZXIuZXJyb3IoZSk7XG4gICAgICB9XG4gICAgICAvLyBSZXR1cm4gZHVtbXkgdG9rZW4gYW5kIGVycm9yXG4gICAgICByZXR1cm4gbWFrZUR1bW15VG9rZW5SZXN1bHQoZSBhcyBGaXJlYmFzZUVycm9yKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVGhlcmUgYXJlIG5vIHZhbGlkIHRva2VucyBpbiBtZW1vcnkgb3IgaW5kZXhlZERCIGFuZCB3ZSBhcmUgbm90IGluXG4gICAqIGRlYnVnIG1vZGUuXG4gICAqIFJlcXVlc3QgYSBuZXcgdG9rZW4gZnJvbSB0aGUgZXhjaGFuZ2UgZW5kcG9pbnQuXG4gICAqL1xuICB0cnkge1xuICAgIC8vIEF2b2lkIG1ha2luZyBhbm90aGVyIGNhbGwgdG8gdGhlIGV4Y2hhbmdlIGVuZHBvaW50IGlmIG9uZSBpcyBpbiBmbGlnaHQuXG4gICAgaWYgKCFzdGF0ZS5leGNoYW5nZVRva2VuUHJvbWlzZSkge1xuICAgICAgLy8gc3RhdGUucHJvdmlkZXIgaXMgcG9wdWxhdGVkIGluIGluaXRpYWxpemVBcHBDaGVjaygpXG4gICAgICAvLyBlbnN1cmVBY3RpdmF0ZWQoKSBhdCB0aGUgdG9wIG9mIHRoaXMgZnVuY3Rpb24gY2hlY2tzIHRoYXRcbiAgICAgIC8vIGluaXRpYWxpemVBcHBDaGVjaygpIGhhcyBiZWVuIGNhbGxlZC5cbiAgICAgIHN0YXRlLmV4Y2hhbmdlVG9rZW5Qcm9taXNlID0gc3RhdGUucHJvdmlkZXIhLmdldFRva2VuKCkuZmluYWxseSgoKSA9PiB7XG4gICAgICAgIC8vIENsZWFyIHByb21pc2Ugd2hlbiBzZXR0bGVkIC0gZWl0aGVyIHJlc29sdmVkIG9yIHJlamVjdGVkLlxuICAgICAgICBzdGF0ZS5leGNoYW5nZVRva2VuUHJvbWlzZSA9IHVuZGVmaW5lZDtcbiAgICAgIH0pO1xuICAgICAgc2hvdWxkQ2FsbExpc3RlbmVycyA9IHRydWU7XG4gICAgfVxuICAgIHRva2VuID0gYXdhaXQgZ2V0U3RhdGVSZWZlcmVuY2UoYXBwKS5leGNoYW5nZVRva2VuUHJvbWlzZTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIGlmIChcbiAgICAgIChlIGFzIEZpcmViYXNlRXJyb3IpLmNvZGUgPT09IGBhcHBDaGVjay8ke0FwcENoZWNrRXJyb3IuVEhST1RUTEVEfWAgfHxcbiAgICAgIChlIGFzIEZpcmViYXNlRXJyb3IpLmNvZGUgPT09IGBhcHBDaGVjay8ke0FwcENoZWNrRXJyb3IuSU5JVElBTF9USFJPVFRMRX1gXG4gICAgKSB7XG4gICAgICAvLyBXYXJuIGlmIHRocm90dGxlZCwgYnV0IGRvIG5vdCB0cmVhdCBpdCBhcyBhbiBlcnJvci5cbiAgICAgIGxvZ2dlci53YXJuKChlIGFzIEZpcmViYXNlRXJyb3IpLm1lc3NhZ2UpO1xuICAgIH0gZWxzZSBpZiAoc2hvdWxkTG9nRXJyb3JzKSB7XG4gICAgICBsb2dnZXIuZXJyb3IoZSk7XG4gICAgfVxuICAgIC8vIEFsd2F5cyBzYXZlIGVycm9yIHRvIGJlIGFkZGVkIHRvIGR1bW15IHRva2VuLlxuICAgIGVycm9yID0gZSBhcyBGaXJlYmFzZUVycm9yO1xuICB9XG5cbiAgbGV0IGludGVyb3BUb2tlblJlc3VsdDogQXBwQ2hlY2tUb2tlblJlc3VsdCB8IHVuZGVmaW5lZDtcbiAgaWYgKCF0b2tlbikge1xuICAgIC8vIElmIHRva2VuIGlzIHVuZGVmaW5lZCwgdGhlcmUgbXVzdCBiZSBhbiBlcnJvci5cbiAgICAvLyBSZXR1cm4gYSBkdW1teSB0b2tlbiBhbG9uZyB3aXRoIHRoZSBlcnJvci5cbiAgICBpbnRlcm9wVG9rZW5SZXN1bHQgPSBtYWtlRHVtbXlUb2tlblJlc3VsdChlcnJvciEpO1xuICB9IGVsc2UgaWYgKGVycm9yKSB7XG4gICAgaWYgKGlzVmFsaWQodG9rZW4pKSB7XG4gICAgICAvLyBJdCdzIGFsc28gcG9zc2libGUgYSB2YWxpZCB0b2tlbiBleGlzdHMsIGJ1dCB0aGVyZSdzIGFsc28gYW4gZXJyb3IuXG4gICAgICAvLyAoU3VjaCBhcyBpZiB0aGUgdG9rZW4gaXMgYWxtb3N0IGV4cGlyZWQsIHRyaWVzIHRvIHJlZnJlc2gsIGFuZFxuICAgICAgLy8gdGhlIGV4Y2hhbmdlIHJlcXVlc3QgZmFpbHMuKVxuICAgICAgLy8gV2UgYWRkIGEgc3BlY2lhbCBlcnJvciBwcm9wZXJ0eSBoZXJlIHNvIHRoYXQgdGhlIHJlZnJlc2hlciB3aWxsXG4gICAgICAvLyBjb3VudCB0aGlzIGFzIGEgZmFpbGVkIGF0dGVtcHQgYW5kIHVzZSB0aGUgYmFja29mZiBpbnN0ZWFkIG9mXG4gICAgICAvLyByZXRyeWluZyByZXBlYXRlZGx5IHdpdGggbm8gZGVsYXksIGJ1dCBhbnkgM1AgbGlzdGVuZXJzIHdpbGwgbm90XG4gICAgICAvLyBiZSBoaW5kZXJlZCBpbiBnZXR0aW5nIHRoZSBzdGlsbC12YWxpZCB0b2tlbi5cbiAgICAgIGludGVyb3BUb2tlblJlc3VsdCA9IHtcbiAgICAgICAgdG9rZW46IHRva2VuLnRva2VuLFxuICAgICAgICBpbnRlcm5hbEVycm9yOiBlcnJvclxuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gTm8gaW52YWxpZCB0b2tlbnMgc2hvdWxkIG1ha2UgaXQgdG8gdGhpcyBzdGVwLiBNZW1vcnkgYW5kIGNhY2hlZCB0b2tlbnNcbiAgICAgIC8vIGFyZSBjaGVja2VkLiBPdGhlciB0b2tlbnMgYXJlIGZyb20gZnJlc2ggZXhjaGFuZ2VzLiBCdXQganVzdCBpbiBjYXNlLlxuICAgICAgaW50ZXJvcFRva2VuUmVzdWx0ID0gbWFrZUR1bW15VG9rZW5SZXN1bHQoZXJyb3IhKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgaW50ZXJvcFRva2VuUmVzdWx0ID0ge1xuICAgICAgdG9rZW46IHRva2VuLnRva2VuXG4gICAgfTtcbiAgICAvLyB3cml0ZSB0aGUgbmV3IHRva2VuIHRvIHRoZSBtZW1vcnkgc3RhdGUgYXMgd2VsbCBhcyB0aGUgcGVyc2lzdGVudCBzdG9yYWdlLlxuICAgIC8vIE9ubHkgZG8gaXQgaWYgd2UgZ290IGEgdmFsaWQgbmV3IHRva2VuXG4gICAgc3RhdGUudG9rZW4gPSB0b2tlbjtcbiAgICBhd2FpdCB3cml0ZVRva2VuVG9TdG9yYWdlKGFwcCwgdG9rZW4pO1xuICB9XG5cbiAgaWYgKHNob3VsZENhbGxMaXN0ZW5lcnMpIHtcbiAgICBub3RpZnlUb2tlbkxpc3RlbmVycyhhcHAsIGludGVyb3BUb2tlblJlc3VsdCk7XG4gIH1cbiAgcmV0dXJuIGludGVyb3BUb2tlblJlc3VsdDtcbn1cblxuLyoqXG4gKiBJbnRlcm5hbCBBUEkgZm9yIGxpbWl0ZWQgdXNlIHRva2Vucy4gU2tpcHMgYWxsIEZBQyBzdGF0ZSBhbmQgc2ltcGx5IGNhbGxzXG4gKiB0aGUgdW5kZXJseWluZyBwcm92aWRlci5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldExpbWl0ZWRVc2VUb2tlbihcbiAgYXBwQ2hlY2s6IEFwcENoZWNrU2VydmljZVxuKTogUHJvbWlzZTxBcHBDaGVja1Rva2VuUmVzdWx0PiB7XG4gIGNvbnN0IGFwcCA9IGFwcENoZWNrLmFwcDtcbiAgZW5zdXJlQWN0aXZhdGVkKGFwcCk7XG5cbiAgY29uc3QgeyBwcm92aWRlciB9ID0gZ2V0U3RhdGVSZWZlcmVuY2UoYXBwKTtcblxuICBpZiAoaXNEZWJ1Z01vZGUoKSkge1xuICAgIGNvbnN0IGRlYnVnVG9rZW4gPSBhd2FpdCBnZXREZWJ1Z1Rva2VuKCk7XG4gICAgY29uc3QgcmVxdWVzdCA9IGdldEV4Y2hhbmdlRGVidWdUb2tlblJlcXVlc3QoYXBwLCBkZWJ1Z1Rva2VuKTtcbiAgICByZXF1ZXN0LmJvZHlbJ2xpbWl0ZWRfdXNlJ10gPSB0cnVlO1xuICAgIGNvbnN0IHsgdG9rZW4gfSA9IGF3YWl0IGV4Y2hhbmdlVG9rZW4oXG4gICAgICByZXF1ZXN0LFxuICAgICAgYXBwQ2hlY2suaGVhcnRiZWF0U2VydmljZVByb3ZpZGVyXG4gICAgKTtcbiAgICByZXR1cm4geyB0b2tlbiB9O1xuICB9IGVsc2Uge1xuICAgIC8vIHByb3ZpZGVyIGlzIGRlZmluaXRlbHkgdmFsaWQgc2luY2Ugd2UgZW5zdXJlIEFwcENoZWNrIHdhcyBhY3RpdmF0ZWRcbiAgICBjb25zdCB7IHRva2VuIH0gPSBhd2FpdCBwcm92aWRlciEuZ2V0VG9rZW4odHJ1ZSAvKiBpc0xpbWl0ZWRVc2UgKi8pO1xuICAgIHJldHVybiB7IHRva2VuIH07XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGFkZFRva2VuTGlzdGVuZXIoXG4gIGFwcENoZWNrOiBBcHBDaGVja1NlcnZpY2UsXG4gIHR5cGU6IExpc3RlbmVyVHlwZSxcbiAgbGlzdGVuZXI6IEFwcENoZWNrVG9rZW5MaXN0ZW5lcixcbiAgb25FcnJvcj86IChlcnJvcjogRXJyb3IpID0+IHZvaWRcbik6IHZvaWQge1xuICBjb25zdCB7IGFwcCB9ID0gYXBwQ2hlY2s7XG4gIGNvbnN0IHN0YXRlID0gZ2V0U3RhdGVSZWZlcmVuY2UoYXBwKTtcbiAgY29uc3QgdG9rZW5PYnNlcnZlcjogQXBwQ2hlY2tUb2tlbk9ic2VydmVyID0ge1xuICAgIG5leHQ6IGxpc3RlbmVyLFxuICAgIGVycm9yOiBvbkVycm9yLFxuICAgIHR5cGVcbiAgfTtcbiAgc3RhdGUudG9rZW5PYnNlcnZlcnMgPSBbLi4uc3RhdGUudG9rZW5PYnNlcnZlcnMsIHRva2VuT2JzZXJ2ZXJdO1xuXG4gIC8vIEludm9rZSB0aGUgbGlzdGVuZXIgYXN5bmMgaW1tZWRpYXRlbHkgaWYgdGhlcmUgaXMgYSB2YWxpZCB0b2tlblxuICAvLyBpbiBtZW1vcnkuXG4gIGlmIChzdGF0ZS50b2tlbiAmJiBpc1ZhbGlkKHN0YXRlLnRva2VuKSkge1xuICAgIGNvbnN0IHZhbGlkVG9rZW4gPSBzdGF0ZS50b2tlbjtcbiAgICBQcm9taXNlLnJlc29sdmUoKVxuICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICBsaXN0ZW5lcih7IHRva2VuOiB2YWxpZFRva2VuLnRva2VuIH0pO1xuICAgICAgICBpbml0VG9rZW5SZWZyZXNoZXIoYXBwQ2hlY2spO1xuICAgICAgfSlcbiAgICAgIC5jYXRjaCgoKSA9PiB7XG4gICAgICAgIC8qIHdlIGRvbid0IGNhcmUgYWJvdXQgZXhjZXB0aW9ucyB0aHJvd24gaW4gbGlzdGVuZXJzICovXG4gICAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBXYWl0IGZvciBhbnkgY2FjaGVkIHRva2VuIHByb21pc2UgdG8gcmVzb2x2ZSBiZWZvcmUgc3RhcnRpbmcgdGhlIHRva2VuXG4gICAqIHJlZnJlc2hlci4gVGhlIHJlZnJlc2hlciBjaGVja3MgdG8gc2VlIGlmIHRoZXJlIGlzIGFuIGV4aXN0aW5nIHRva2VuXG4gICAqIGluIHN0YXRlIGFuZCBjYWxscyB0aGUgZXhjaGFuZ2UgZW5kcG9pbnQgaWYgbm90LiBXZSBzaG91bGQgZmlyc3QgbGV0IHRoZVxuICAgKiBJbmRleGVkREIgY2hlY2sgaGF2ZSBhIGNoYW5jZSB0byBwb3B1bGF0ZSBzdGF0ZSBpZiBpdCBjYW4uXG4gICAqXG4gICAqIExpc3RlbmVyIGNhbGwgaXNuJ3QgbmVlZGVkIGhlcmUgYmVjYXVzZSBjYWNoZWRUb2tlblByb21pc2Ugd2lsbCBjYWxsIGFueVxuICAgKiBsaXN0ZW5lcnMgdGhhdCBleGlzdCB3aGVuIGl0IHJlc29sdmVzLlxuICAgKi9cblxuICAvLyBzdGF0ZS5jYWNoZWRUb2tlblByb21pc2UgaXMgYWx3YXlzIHBvcHVsYXRlZCBpbiBgYWN0aXZhdGUoKWAuXG4gIHZvaWQgc3RhdGUuY2FjaGVkVG9rZW5Qcm9taXNlIS50aGVuKCgpID0+IGluaXRUb2tlblJlZnJlc2hlcihhcHBDaGVjaykpO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVtb3ZlVG9rZW5MaXN0ZW5lcihcbiAgYXBwOiBGaXJlYmFzZUFwcCxcbiAgbGlzdGVuZXI6IEFwcENoZWNrVG9rZW5MaXN0ZW5lclxuKTogdm9pZCB7XG4gIGNvbnN0IHN0YXRlID0gZ2V0U3RhdGVSZWZlcmVuY2UoYXBwKTtcblxuICBjb25zdCBuZXdPYnNlcnZlcnMgPSBzdGF0ZS50b2tlbk9ic2VydmVycy5maWx0ZXIoXG4gICAgdG9rZW5PYnNlcnZlciA9PiB0b2tlbk9ic2VydmVyLm5leHQgIT09IGxpc3RlbmVyXG4gICk7XG4gIGlmIChcbiAgICBuZXdPYnNlcnZlcnMubGVuZ3RoID09PSAwICYmXG4gICAgc3RhdGUudG9rZW5SZWZyZXNoZXIgJiZcbiAgICBzdGF0ZS50b2tlblJlZnJlc2hlci5pc1J1bm5pbmcoKVxuICApIHtcbiAgICBzdGF0ZS50b2tlblJlZnJlc2hlci5zdG9wKCk7XG4gIH1cblxuICBzdGF0ZS50b2tlbk9ic2VydmVycyA9IG5ld09ic2VydmVycztcbn1cblxuLyoqXG4gKiBMb2dpYyB0byBjcmVhdGUgYW5kIHN0YXJ0IHJlZnJlc2hlciBhcyBuZWVkZWQuXG4gKi9cbmZ1bmN0aW9uIGluaXRUb2tlblJlZnJlc2hlcihhcHBDaGVjazogQXBwQ2hlY2tTZXJ2aWNlKTogdm9pZCB7XG4gIGNvbnN0IHsgYXBwIH0gPSBhcHBDaGVjaztcbiAgY29uc3Qgc3RhdGUgPSBnZXRTdGF0ZVJlZmVyZW5jZShhcHApO1xuICAvLyBDcmVhdGUgdGhlIHJlZnJlc2hlciBidXQgZG9uJ3Qgc3RhcnQgaXQgaWYgYGlzVG9rZW5BdXRvUmVmcmVzaEVuYWJsZWRgXG4gIC8vIGlzIG5vdCB0cnVlLlxuICBsZXQgcmVmcmVzaGVyOiBSZWZyZXNoZXIgfCB1bmRlZmluZWQgPSBzdGF0ZS50b2tlblJlZnJlc2hlcjtcbiAgaWYgKCFyZWZyZXNoZXIpIHtcbiAgICByZWZyZXNoZXIgPSBjcmVhdGVUb2tlblJlZnJlc2hlcihhcHBDaGVjayk7XG4gICAgc3RhdGUudG9rZW5SZWZyZXNoZXIgPSByZWZyZXNoZXI7XG4gIH1cbiAgaWYgKCFyZWZyZXNoZXIuaXNSdW5uaW5nKCkgJiYgc3RhdGUuaXNUb2tlbkF1dG9SZWZyZXNoRW5hYmxlZCkge1xuICAgIHJlZnJlc2hlci5zdGFydCgpO1xuICB9XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZVRva2VuUmVmcmVzaGVyKGFwcENoZWNrOiBBcHBDaGVja1NlcnZpY2UpOiBSZWZyZXNoZXIge1xuICBjb25zdCB7IGFwcCB9ID0gYXBwQ2hlY2s7XG4gIHJldHVybiBuZXcgUmVmcmVzaGVyKFxuICAgIC8vIEtlZXAgaW4gbWluZCB3aGVuIHRoaXMgZmFpbHMgZm9yIGFueSByZWFzb24gb3RoZXIgdGhhbiB0aGUgb25lc1xuICAgIC8vIGZvciB3aGljaCB3ZSBzaG91bGQgcmV0cnksIGl0IHdpbGwgZWZmZWN0aXZlbHkgc3RvcCB0aGUgcHJvYWN0aXZlIHJlZnJlc2guXG4gICAgYXN5bmMgKCkgPT4ge1xuICAgICAgY29uc3Qgc3RhdGUgPSBnZXRTdGF0ZVJlZmVyZW5jZShhcHApO1xuICAgICAgLy8gSWYgdGhlcmUgaXMgbm8gdG9rZW4sIHdlIHdpbGwgdHJ5IHRvIGxvYWQgaXQgZnJvbSBzdG9yYWdlIGFuZCB1c2UgaXRcbiAgICAgIC8vIElmIHRoZXJlIGlzIGEgdG9rZW4sIHdlIGZvcmNlIHJlZnJlc2ggaXQgYmVjYXVzZSB3ZSBrbm93IGl0J3MgZ29pbmcgdG8gZXhwaXJlIHNvb25cbiAgICAgIGxldCByZXN1bHQ7XG4gICAgICBpZiAoIXN0YXRlLnRva2VuKSB7XG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IGdldFRva2VuKGFwcENoZWNrKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc3VsdCA9IGF3YWl0IGdldFRva2VuKGFwcENoZWNrLCB0cnVlKTtcbiAgICAgIH1cblxuICAgICAgLyoqXG4gICAgICAgKiBnZXRUb2tlbigpIGFsd2F5cyByZXNvbHZlcy4gSW4gY2FzZSB0aGUgcmVzdWx0IGhhcyBhbiBlcnJvciBmaWVsZCBkZWZpbmVkLCBpdCBtZWFuc1xuICAgICAgICogdGhlIG9wZXJhdGlvbiBmYWlsZWQsIGFuZCB3ZSBzaG91bGQgcmV0cnkuXG4gICAgICAgKi9cbiAgICAgIGlmIChyZXN1bHQuZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgcmVzdWx0LmVycm9yO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBBIHNwZWNpYWwgYGludGVybmFsRXJyb3JgIGZpZWxkIHJlZmxlY3RzIHRoYXQgdGhlcmUgd2FzIGFuIGVycm9yXG4gICAgICAgKiBnZXR0aW5nIGEgbmV3IHRva2VuIGZyb20gdGhlIGV4Y2hhbmdlIGVuZHBvaW50LCBidXQgdGhlcmUncyBzdGlsbCBhXG4gICAgICAgKiBwcmV2aW91cyB0b2tlbiB0aGF0J3MgdmFsaWQgZm9yIG5vdyBhbmQgdGhpcyBzaG91bGQgYmUgcGFzc2VkIHRvIDJQLzNQXG4gICAgICAgKiByZXF1ZXN0cyBmb3IgYSB0b2tlbi4gQnV0IHdlIHdhbnQgdGhpcyBjYWxsYmFjayAoYHRoaXMub3BlcmF0aW9uYCBpblxuICAgICAgICogYFJlZnJlc2hlcmApIHRvIHRocm93IGluIG9yZGVyIHRvIGtpY2sgb2ZmIHRoZSBSZWZyZXNoZXIncyByZXRyeVxuICAgICAgICogYmFja29mZi4gKFNldHRpbmcgYGhhc1N1Y2NlZWRlZGAgdG8gZmFsc2UuKVxuICAgICAgICovXG4gICAgICBpZiAocmVzdWx0LmludGVybmFsRXJyb3IpIHtcbiAgICAgICAgdGhyb3cgcmVzdWx0LmludGVybmFsRXJyb3I7XG4gICAgICB9XG4gICAgfSxcbiAgICAoKSA9PiB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9LFxuICAgICgpID0+IHtcbiAgICAgIGNvbnN0IHN0YXRlID0gZ2V0U3RhdGVSZWZlcmVuY2UoYXBwKTtcblxuICAgICAgaWYgKHN0YXRlLnRva2VuKSB7XG4gICAgICAgIC8vIGlzc3VlZEF0VGltZSArICg1MCUgKiB0b3RhbCBUVEwpICsgNSBtaW51dGVzXG4gICAgICAgIGxldCBuZXh0UmVmcmVzaFRpbWVNaWxsaXMgPVxuICAgICAgICAgIHN0YXRlLnRva2VuLmlzc3VlZEF0VGltZU1pbGxpcyArXG4gICAgICAgICAgKHN0YXRlLnRva2VuLmV4cGlyZVRpbWVNaWxsaXMgLSBzdGF0ZS50b2tlbi5pc3N1ZWRBdFRpbWVNaWxsaXMpICpcbiAgICAgICAgICAgIDAuNSArXG4gICAgICAgICAgNSAqIDYwICogMTAwMDtcbiAgICAgICAgLy8gRG8gbm90IGFsbG93IHJlZnJlc2ggdGltZSB0byBiZSBwYXN0IChleHBpcmVUaW1lIC0gNSBtaW51dGVzKVxuICAgICAgICBjb25zdCBsYXRlc3RBbGxvd2FibGVSZWZyZXNoID1cbiAgICAgICAgICBzdGF0ZS50b2tlbi5leHBpcmVUaW1lTWlsbGlzIC0gNSAqIDYwICogMTAwMDtcbiAgICAgICAgbmV4dFJlZnJlc2hUaW1lTWlsbGlzID0gTWF0aC5taW4oXG4gICAgICAgICAgbmV4dFJlZnJlc2hUaW1lTWlsbGlzLFxuICAgICAgICAgIGxhdGVzdEFsbG93YWJsZVJlZnJlc2hcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIE1hdGgubWF4KDAsIG5leHRSZWZyZXNoVGltZU1pbGxpcyAtIERhdGUubm93KCkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmV0dXJuIDA7XG4gICAgICB9XG4gICAgfSxcbiAgICBUT0tFTl9SRUZSRVNIX1RJTUUuUkVUUklBTF9NSU5fV0FJVCxcbiAgICBUT0tFTl9SRUZSRVNIX1RJTUUuUkVUUklBTF9NQVhfV0FJVFxuICApO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gbm90aWZ5VG9rZW5MaXN0ZW5lcnMoXG4gIGFwcDogRmlyZWJhc2VBcHAsXG4gIHRva2VuOiBBcHBDaGVja1Rva2VuUmVzdWx0XG4pOiB2b2lkIHtcbiAgY29uc3Qgb2JzZXJ2ZXJzID0gZ2V0U3RhdGVSZWZlcmVuY2UoYXBwKS50b2tlbk9ic2VydmVycztcblxuICBmb3IgKGNvbnN0IG9ic2VydmVyIG9mIG9ic2VydmVycykge1xuICAgIHRyeSB7XG4gICAgICBpZiAob2JzZXJ2ZXIudHlwZSA9PT0gTGlzdGVuZXJUeXBlLkVYVEVSTkFMICYmIHRva2VuLmVycm9yICE9IG51bGwpIHtcbiAgICAgICAgLy8gSWYgdGhpcyBsaXN0ZW5lciB3YXMgYWRkZWQgYnkgYSAzUCBjYWxsLCBzZW5kIGFueSB0b2tlbiBlcnJvciB0b1xuICAgICAgICAvLyB0aGUgc3VwcGxpZWQgZXJyb3IgaGFuZGxlci4gQSAzUCBvYnNlcnZlciBhbHdheXMgaGFzIGFuIGVycm9yXG4gICAgICAgIC8vIGhhbmRsZXIuXG4gICAgICAgIG9ic2VydmVyLmVycm9yISh0b2tlbi5lcnJvcik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBJZiB0aGUgdG9rZW4gaGFzIG5vIGVycm9yIGZpZWxkLCBhbHdheXMgcmV0dXJuIHRoZSB0b2tlbi5cbiAgICAgICAgLy8gSWYgdGhpcyBpcyBhIDJQIGxpc3RlbmVyLCByZXR1cm4gdGhlIHRva2VuLCB3aGV0aGVyIG9yIG5vdCBpdFxuICAgICAgICAvLyBoYXMgYW4gZXJyb3IgZmllbGQuXG4gICAgICAgIG9ic2VydmVyLm5leHQodG9rZW4pO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIC8vIEVycm9ycyBpbiB0aGUgbGlzdGVuZXIgZnVuY3Rpb24gaXRzZWxmIGFyZSBhbHdheXMgaWdub3JlZC5cbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzVmFsaWQodG9rZW46IEFwcENoZWNrVG9rZW5JbnRlcm5hbCk6IGJvb2xlYW4ge1xuICByZXR1cm4gdG9rZW4uZXhwaXJlVGltZU1pbGxpcyAtIERhdGUubm93KCkgPiAwO1xufVxuXG5mdW5jdGlvbiBtYWtlRHVtbXlUb2tlblJlc3VsdChlcnJvcjogRXJyb3IpOiBBcHBDaGVja1Rva2VuUmVzdWx0IHtcbiAgcmV0dXJuIHtcbiAgICB0b2tlbjogZm9ybWF0RHVtbXlUb2tlbihkZWZhdWx0VG9rZW5FcnJvckRhdGEpLFxuICAgIGVycm9yXG4gIH07XG59XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAyMCBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG5pbXBvcnQgeyBBcHBDaGVjayB9IGZyb20gJy4vcHVibGljLXR5cGVzJztcbmltcG9ydCB7IEZpcmViYXNlQXBwLCBfRmlyZWJhc2VTZXJ2aWNlIH0gZnJvbSAnQGZpcmViYXNlL2FwcCc7XG5pbXBvcnQgeyBGaXJlYmFzZUFwcENoZWNrSW50ZXJuYWwsIExpc3RlbmVyVHlwZSB9IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHtcbiAgZ2V0VG9rZW4sXG4gIGdldExpbWl0ZWRVc2VUb2tlbixcbiAgYWRkVG9rZW5MaXN0ZW5lcixcbiAgcmVtb3ZlVG9rZW5MaXN0ZW5lclxufSBmcm9tICcuL2ludGVybmFsLWFwaSc7XG5pbXBvcnQgeyBQcm92aWRlciB9IGZyb20gJ0BmaXJlYmFzZS9jb21wb25lbnQnO1xuaW1wb3J0IHsgZ2V0U3RhdGVSZWZlcmVuY2UgfSBmcm9tICcuL3N0YXRlJztcblxuLyoqXG4gKiBBcHBDaGVjayBTZXJ2aWNlIGNsYXNzLlxuICovXG5leHBvcnQgY2xhc3MgQXBwQ2hlY2tTZXJ2aWNlIGltcGxlbWVudHMgQXBwQ2hlY2ssIF9GaXJlYmFzZVNlcnZpY2Uge1xuICBjb25zdHJ1Y3RvcihcbiAgICBwdWJsaWMgYXBwOiBGaXJlYmFzZUFwcCxcbiAgICBwdWJsaWMgaGVhcnRiZWF0U2VydmljZVByb3ZpZGVyOiBQcm92aWRlcjwnaGVhcnRiZWF0Jz5cbiAgKSB7fVxuICBfZGVsZXRlKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IHsgdG9rZW5PYnNlcnZlcnMgfSA9IGdldFN0YXRlUmVmZXJlbmNlKHRoaXMuYXBwKTtcbiAgICBmb3IgKGNvbnN0IHRva2VuT2JzZXJ2ZXIgb2YgdG9rZW5PYnNlcnZlcnMpIHtcbiAgICAgIHJlbW92ZVRva2VuTGlzdGVuZXIodGhpcy5hcHAsIHRva2VuT2JzZXJ2ZXIubmV4dCk7XG4gICAgfVxuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZmFjdG9yeShcbiAgYXBwOiBGaXJlYmFzZUFwcCxcbiAgaGVhcnRiZWF0U2VydmljZVByb3ZpZGVyOiBQcm92aWRlcjwnaGVhcnRiZWF0Jz5cbik6IEFwcENoZWNrU2VydmljZSB7XG4gIHJldHVybiBuZXcgQXBwQ2hlY2tTZXJ2aWNlKGFwcCwgaGVhcnRiZWF0U2VydmljZVByb3ZpZGVyKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGludGVybmFsRmFjdG9yeShcbiAgYXBwQ2hlY2s6IEFwcENoZWNrU2VydmljZVxuKTogRmlyZWJhc2VBcHBDaGVja0ludGVybmFsIHtcbiAgcmV0dXJuIHtcbiAgICBnZXRUb2tlbjogZm9yY2VSZWZyZXNoID0+IGdldFRva2VuKGFwcENoZWNrLCBmb3JjZVJlZnJlc2gpLFxuICAgIGdldExpbWl0ZWRVc2VUb2tlbjogKCkgPT4gZ2V0TGltaXRlZFVzZVRva2VuKGFwcENoZWNrKSxcbiAgICBhZGRUb2tlbkxpc3RlbmVyOiBsaXN0ZW5lciA9PlxuICAgICAgYWRkVG9rZW5MaXN0ZW5lcihhcHBDaGVjaywgTGlzdGVuZXJUeXBlLklOVEVSTkFMLCBsaXN0ZW5lciksXG4gICAgcmVtb3ZlVG9rZW5MaXN0ZW5lcjogbGlzdGVuZXIgPT4gcmVtb3ZlVG9rZW5MaXN0ZW5lcihhcHBDaGVjay5hcHAsIGxpc3RlbmVyKVxuICB9O1xufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgRmlyZWJhc2VBcHAgfSBmcm9tICdAZmlyZWJhc2UvYXBwJztcbmltcG9ydCB7IGdldFN0YXRlUmVmZXJlbmNlIH0gZnJvbSAnLi9zdGF0ZSc7XG5pbXBvcnQgeyBEZWZlcnJlZCB9IGZyb20gJ0BmaXJlYmFzZS91dGlsJztcbmltcG9ydCB7IGdldFJlY2FwdGNoYSwgZW5zdXJlQWN0aXZhdGVkIH0gZnJvbSAnLi91dGlsJztcblxuZXhwb3J0IGNvbnN0IFJFQ0FQVENIQV9VUkwgPSAnaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS9yZWNhcHRjaGEvYXBpLmpzJztcbmV4cG9ydCBjb25zdCBSRUNBUFRDSEFfRU5URVJQUklTRV9VUkwgPVxuICAnaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS9yZWNhcHRjaGEvZW50ZXJwcmlzZS5qcyc7XG5cbmV4cG9ydCBmdW5jdGlvbiBpbml0aWFsaXplVjMoXG4gIGFwcDogRmlyZWJhc2VBcHAsXG4gIHNpdGVLZXk6IHN0cmluZ1xuKTogUHJvbWlzZTxHcmVDQVBUQ0hBPiB7XG4gIGNvbnN0IGluaXRpYWxpemVkID0gbmV3IERlZmVycmVkPEdyZUNBUFRDSEE+KCk7XG5cbiAgY29uc3Qgc3RhdGUgPSBnZXRTdGF0ZVJlZmVyZW5jZShhcHApO1xuICBzdGF0ZS5yZUNBUFRDSEFTdGF0ZSA9IHsgaW5pdGlhbGl6ZWQgfTtcblxuICBjb25zdCBkaXZJZCA9IG1ha2VEaXYoYXBwKTtcblxuICBjb25zdCBncmVjYXB0Y2hhID0gZ2V0UmVjYXB0Y2hhKGZhbHNlKTtcbiAgaWYgKCFncmVjYXB0Y2hhKSB7XG4gICAgbG9hZFJlQ0FQVENIQVYzU2NyaXB0KCgpID0+IHtcbiAgICAgIGNvbnN0IGdyZWNhcHRjaGEgPSBnZXRSZWNhcHRjaGEoZmFsc2UpO1xuXG4gICAgICBpZiAoIWdyZWNhcHRjaGEpIHtcbiAgICAgICAgLy8gaXQgc2hvdWxkbid0IGhhcHBlbi5cbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdubyByZWNhcHRjaGEnKTtcbiAgICAgIH1cbiAgICAgIHF1ZXVlV2lkZ2V0UmVuZGVyKGFwcCwgc2l0ZUtleSwgZ3JlY2FwdGNoYSwgZGl2SWQsIGluaXRpYWxpemVkKTtcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICBxdWV1ZVdpZGdldFJlbmRlcihhcHAsIHNpdGVLZXksIGdyZWNhcHRjaGEsIGRpdklkLCBpbml0aWFsaXplZCk7XG4gIH1cbiAgcmV0dXJuIGluaXRpYWxpemVkLnByb21pc2U7XG59XG5leHBvcnQgZnVuY3Rpb24gaW5pdGlhbGl6ZUVudGVycHJpc2UoXG4gIGFwcDogRmlyZWJhc2VBcHAsXG4gIHNpdGVLZXk6IHN0cmluZ1xuKTogUHJvbWlzZTxHcmVDQVBUQ0hBPiB7XG4gIGNvbnN0IGluaXRpYWxpemVkID0gbmV3IERlZmVycmVkPEdyZUNBUFRDSEE+KCk7XG5cbiAgY29uc3Qgc3RhdGUgPSBnZXRTdGF0ZVJlZmVyZW5jZShhcHApO1xuICBzdGF0ZS5yZUNBUFRDSEFTdGF0ZSA9IHsgaW5pdGlhbGl6ZWQgfTtcblxuICBjb25zdCBkaXZJZCA9IG1ha2VEaXYoYXBwKTtcblxuICBjb25zdCBncmVjYXB0Y2hhID0gZ2V0UmVjYXB0Y2hhKHRydWUpO1xuICBpZiAoIWdyZWNhcHRjaGEpIHtcbiAgICBsb2FkUmVDQVBUQ0hBRW50ZXJwcmlzZVNjcmlwdCgoKSA9PiB7XG4gICAgICBjb25zdCBncmVjYXB0Y2hhID0gZ2V0UmVjYXB0Y2hhKHRydWUpO1xuXG4gICAgICBpZiAoIWdyZWNhcHRjaGEpIHtcbiAgICAgICAgLy8gaXQgc2hvdWxkbid0IGhhcHBlbi5cbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdubyByZWNhcHRjaGEnKTtcbiAgICAgIH1cbiAgICAgIHF1ZXVlV2lkZ2V0UmVuZGVyKGFwcCwgc2l0ZUtleSwgZ3JlY2FwdGNoYSwgZGl2SWQsIGluaXRpYWxpemVkKTtcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICBxdWV1ZVdpZGdldFJlbmRlcihhcHAsIHNpdGVLZXksIGdyZWNhcHRjaGEsIGRpdklkLCBpbml0aWFsaXplZCk7XG4gIH1cbiAgcmV0dXJuIGluaXRpYWxpemVkLnByb21pc2U7XG59XG5cbi8qKlxuICogQWRkIGxpc3RlbmVyIHRvIHJlbmRlciB0aGUgd2lkZ2V0IGFuZCByZXNvbHZlIHRoZSBwcm9taXNlIHdoZW5cbiAqIHRoZSBncmVjYXB0Y2hhLnJlYWR5KCkgZXZlbnQgZmlyZXMuXG4gKi9cbmZ1bmN0aW9uIHF1ZXVlV2lkZ2V0UmVuZGVyKFxuICBhcHA6IEZpcmViYXNlQXBwLFxuICBzaXRlS2V5OiBzdHJpbmcsXG4gIGdyZWNhcHRjaGE6IEdyZUNBUFRDSEEsXG4gIGNvbnRhaW5lcjogc3RyaW5nLFxuICBpbml0aWFsaXplZDogRGVmZXJyZWQ8R3JlQ0FQVENIQT5cbik6IHZvaWQge1xuICBncmVjYXB0Y2hhLnJlYWR5KCgpID0+IHtcbiAgICAvLyBJbnZpc2libGUgd2lkZ2V0cyBhbGxvdyB1cyB0byBzZXQgYSBkaWZmZXJlbnQgc2l0ZUtleSBmb3IgZWFjaCB3aWRnZXQsXG4gICAgLy8gc28gd2UgdXNlIHRoZW0gdG8gc3VwcG9ydCBtdWx0aXBsZSBhcHBzXG4gICAgcmVuZGVySW52aXNpYmxlV2lkZ2V0KGFwcCwgc2l0ZUtleSwgZ3JlY2FwdGNoYSwgY29udGFpbmVyKTtcbiAgICBpbml0aWFsaXplZC5yZXNvbHZlKGdyZWNhcHRjaGEpO1xuICB9KTtcbn1cblxuLyoqXG4gKiBBZGQgaW52aXNpYmxlIGRpdiB0byBwYWdlLlxuICovXG5mdW5jdGlvbiBtYWtlRGl2KGFwcDogRmlyZWJhc2VBcHApOiBzdHJpbmcge1xuICBjb25zdCBkaXZJZCA9IGBmaXJlX2FwcF9jaGVja18ke2FwcC5uYW1lfWA7XG4gIGNvbnN0IGludmlzaWJsZURpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICBpbnZpc2libGVEaXYuaWQgPSBkaXZJZDtcbiAgaW52aXNpYmxlRGl2LnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG5cbiAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChpbnZpc2libGVEaXYpO1xuICByZXR1cm4gZGl2SWQ7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRUb2tlbihhcHA6IEZpcmViYXNlQXBwKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgZW5zdXJlQWN0aXZhdGVkKGFwcCk7XG5cbiAgLy8gZW5zdXJlQWN0aXZhdGVkKCkgZ3VhcmFudGVlcyB0aGF0IHJlQ0FQVENIQVN0YXRlIGlzIHNldFxuICBjb25zdCByZUNBUFRDSEFTdGF0ZSA9IGdldFN0YXRlUmVmZXJlbmNlKGFwcCkucmVDQVBUQ0hBU3RhdGUhO1xuICBjb25zdCByZWNhcHRjaGEgPSBhd2FpdCByZUNBUFRDSEFTdGF0ZS5pbml0aWFsaXplZC5wcm9taXNlO1xuXG4gIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgX3JlamVjdCkgPT4ge1xuICAgIC8vIFVwZGF0ZWQgYWZ0ZXIgaW5pdGlhbGl6YXRpb24gaXMgY29tcGxldGUuXG4gICAgY29uc3QgcmVDQVBUQ0hBU3RhdGUgPSBnZXRTdGF0ZVJlZmVyZW5jZShhcHApLnJlQ0FQVENIQVN0YXRlITtcbiAgICByZWNhcHRjaGEucmVhZHkoKCkgPT4ge1xuICAgICAgcmVzb2x2ZShcbiAgICAgICAgLy8gd2lkZ2V0SWQgaXMgZ3VhcmFudGVlZCB0byBiZSBhdmFpbGFibGUgaWYgcmVDQVBUQ0hBU3RhdGUuaW5pdGlhbGl6ZWQucHJvbWlzZSByZXNvbHZlZC5cbiAgICAgICAgcmVjYXB0Y2hhLmV4ZWN1dGUocmVDQVBUQ0hBU3RhdGUud2lkZ2V0SWQhLCB7XG4gICAgICAgICAgYWN0aW9uOiAnZmlyZV9hcHBfY2hlY2snXG4gICAgICAgIH0pXG4gICAgICApO1xuICAgIH0pO1xuICB9KTtcbn1cblxuLyoqXG4gKlxuICogQHBhcmFtIGFwcFxuICogQHBhcmFtIGNvbnRhaW5lciAtIElkIG9mIGEgSFRNTCBlbGVtZW50LlxuICovXG5mdW5jdGlvbiByZW5kZXJJbnZpc2libGVXaWRnZXQoXG4gIGFwcDogRmlyZWJhc2VBcHAsXG4gIHNpdGVLZXk6IHN0cmluZyxcbiAgZ3JlY2FwdGNoYTogR3JlQ0FQVENIQSxcbiAgY29udGFpbmVyOiBzdHJpbmdcbik6IHZvaWQge1xuICBjb25zdCB3aWRnZXRJZCA9IGdyZWNhcHRjaGEucmVuZGVyKGNvbnRhaW5lciwge1xuICAgIHNpdGVrZXk6IHNpdGVLZXksXG4gICAgc2l6ZTogJ2ludmlzaWJsZScsXG4gICAgLy8gU3VjY2VzcyBjYWxsYmFjayAtIHNldCBzdGF0ZVxuICAgIGNhbGxiYWNrOiAoKSA9PiB7XG4gICAgICBnZXRTdGF0ZVJlZmVyZW5jZShhcHApLnJlQ0FQVENIQVN0YXRlIS5zdWNjZWVkZWQgPSB0cnVlO1xuICAgIH0sXG4gICAgLy8gRmFpbHVyZSBjYWxsYmFjayAtIHNldCBzdGF0ZVxuICAgICdlcnJvci1jYWxsYmFjayc6ICgpID0+IHtcbiAgICAgIGdldFN0YXRlUmVmZXJlbmNlKGFwcCkucmVDQVBUQ0hBU3RhdGUhLnN1Y2NlZWRlZCA9IGZhbHNlO1xuICAgIH1cbiAgfSk7XG5cbiAgY29uc3Qgc3RhdGUgPSBnZXRTdGF0ZVJlZmVyZW5jZShhcHApO1xuXG4gIHN0YXRlLnJlQ0FQVENIQVN0YXRlID0ge1xuICAgIC4uLnN0YXRlLnJlQ0FQVENIQVN0YXRlISwgLy8gc3RhdGUucmVDQVBUQ0hBU3RhdGUgaXMgc2V0IGluIHRoZSBpbml0aWFsaXplKClcbiAgICB3aWRnZXRJZFxuICB9O1xufVxuXG5mdW5jdGlvbiBsb2FkUmVDQVBUQ0hBVjNTY3JpcHQob25sb2FkOiAoKSA9PiB2b2lkKTogdm9pZCB7XG4gIGNvbnN0IHNjcmlwdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NjcmlwdCcpO1xuICBzY3JpcHQuc3JjID0gUkVDQVBUQ0hBX1VSTDtcbiAgc2NyaXB0Lm9ubG9hZCA9IG9ubG9hZDtcbiAgZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZChzY3JpcHQpO1xufVxuXG5mdW5jdGlvbiBsb2FkUmVDQVBUQ0hBRW50ZXJwcmlzZVNjcmlwdChvbmxvYWQ6ICgpID0+IHZvaWQpOiB2b2lkIHtcbiAgY29uc3Qgc2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc2NyaXB0Jyk7XG4gIC8vIFRoaXMgcGFyYW0gaXMgcmVxdWlyZWQgd2hlbiB3ZSBwbGFuIHRvIHJlbmRlciBhIHdpZGdldCBleHBsaWNpdGx5LlxuICBzY3JpcHQuc3JjID0gUkVDQVBUQ0hBX0VOVEVSUFJJU0VfVVJMICsgJz9yZW5kZXI9ZXhwbGljaXQnO1xuICBzY3JpcHQub25sb2FkID0gb25sb2FkO1xuICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKHNjcmlwdCk7XG59XG5cbmRlY2xhcmUgZ2xvYmFsIHtcbiAgaW50ZXJmYWNlIFdpbmRvdyB7XG4gICAgZ3JlY2FwdGNoYTogR3JlQ0FQVENIQVRvcExldmVsIHwgdW5kZWZpbmVkO1xuICB9XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgR3JlQ0FQVENIQVRvcExldmVsIGV4dGVuZHMgR3JlQ0FQVENIQSB7XG4gIGVudGVycHJpc2U6IEdyZUNBUFRDSEE7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgR3JlQ0FQVENIQSB7XG4gIHJlYWR5OiAoY2FsbGJhY2s6ICgpID0+IHZvaWQpID0+IHZvaWQ7XG4gIGV4ZWN1dGU6IChzaXRlS2V5OiBzdHJpbmcsIG9wdGlvbnM6IHsgYWN0aW9uOiBzdHJpbmcgfSkgPT4gUHJvbWlzZTxzdHJpbmc+O1xuICByZW5kZXI6IChcbiAgICBjb250YWluZXI6IHN0cmluZyB8IEhUTUxFbGVtZW50LFxuICAgIHBhcmFtZXRlcnM6IEdyZUNBUFRDSEFSZW5kZXJPcHRpb25cbiAgKSA9PiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgR3JlQ0FQVENIQVJlbmRlck9wdGlvbiB7XG4gIHNpdGVrZXk6IHN0cmluZztcbiAgc2l6ZTogJ2ludmlzaWJsZSc7XG4gIGNhbGxiYWNrOiAoKSA9PiB2b2lkO1xuICAnZXJyb3ItY2FsbGJhY2snOiAoKSA9PiB2b2lkO1xufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMjEgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgRmlyZWJhc2VBcHAsIF9nZXRQcm92aWRlciB9IGZyb20gJ0BmaXJlYmFzZS9hcHAnO1xuaW1wb3J0IHsgUHJvdmlkZXIgfSBmcm9tICdAZmlyZWJhc2UvY29tcG9uZW50JztcbmltcG9ydCB7XG4gIEZpcmViYXNlRXJyb3IsXG4gIGlzc3VlZEF0VGltZSxcbiAgY2FsY3VsYXRlQmFja29mZk1pbGxpc1xufSBmcm9tICdAZmlyZWJhc2UvdXRpbCc7XG5pbXBvcnQge1xuICBleGNoYW5nZVRva2VuLFxuICBnZXRFeGNoYW5nZVJlY2FwdGNoYUVudGVycHJpc2VUb2tlblJlcXVlc3QsXG4gIGdldEV4Y2hhbmdlUmVjYXB0Y2hhVjNUb2tlblJlcXVlc3Rcbn0gZnJvbSAnLi9jbGllbnQnO1xuaW1wb3J0IHsgT05FX0RBWSB9IGZyb20gJy4vY29uc3RhbnRzJztcbmltcG9ydCB7IEFwcENoZWNrRXJyb3IsIEVSUk9SX0ZBQ1RPUlkgfSBmcm9tICcuL2Vycm9ycyc7XG5pbXBvcnQgeyBDdXN0b21Qcm92aWRlck9wdGlvbnMgfSBmcm9tICcuL3B1YmxpYy10eXBlcyc7XG5pbXBvcnQge1xuICBnZXRUb2tlbiBhcyBnZXRSZUNBUFRDSEFUb2tlbixcbiAgaW5pdGlhbGl6ZVYzIGFzIGluaXRpYWxpemVSZWNhcHRjaGFWMyxcbiAgaW5pdGlhbGl6ZUVudGVycHJpc2UgYXMgaW5pdGlhbGl6ZVJlY2FwdGNoYUVudGVycHJpc2Vcbn0gZnJvbSAnLi9yZWNhcHRjaGEnO1xuaW1wb3J0IHsgZ2V0U3RhdGVSZWZlcmVuY2UgfSBmcm9tICcuL3N0YXRlJztcbmltcG9ydCB7IEFwcENoZWNrUHJvdmlkZXIsIEFwcENoZWNrVG9rZW5JbnRlcm5hbCwgVGhyb3R0bGVEYXRhIH0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyBnZXREdXJhdGlvblN0cmluZyB9IGZyb20gJy4vdXRpbCc7XG5cbi8qKlxuICogQXBwIENoZWNrIHByb3ZpZGVyIHRoYXQgY2FuIG9idGFpbiBhIHJlQ0FQVENIQSBWMyB0b2tlbiBhbmQgZXhjaGFuZ2UgaXRcbiAqIGZvciBhbiBBcHAgQ2hlY2sgdG9rZW4uXG4gKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgY2xhc3MgUmVDYXB0Y2hhVjNQcm92aWRlciBpbXBsZW1lbnRzIEFwcENoZWNrUHJvdmlkZXIge1xuICBwcml2YXRlIF9hcHA/OiBGaXJlYmFzZUFwcDtcbiAgcHJpdmF0ZSBfaGVhcnRiZWF0U2VydmljZVByb3ZpZGVyPzogUHJvdmlkZXI8J2hlYXJ0YmVhdCc+O1xuICAvKipcbiAgICogVGhyb3R0bGUgcmVxdWVzdHMgb24gY2VydGFpbiBlcnJvciBjb2RlcyB0byBwcmV2ZW50IHRvbyBtYW55IHJldHJpZXNcbiAgICogaW4gYSBzaG9ydCB0aW1lLlxuICAgKi9cbiAgcHJpdmF0ZSBfdGhyb3R0bGVEYXRhOiBUaHJvdHRsZURhdGEgfCBudWxsID0gbnVsbDtcbiAgLyoqXG4gICAqIENyZWF0ZSBhIFJlQ2FwdGNoYVYzUHJvdmlkZXIgaW5zdGFuY2UuXG4gICAqIEBwYXJhbSBzaXRlS2V5IC0gUmVDQVBUQ0hBIFYzIHNpdGVLZXkuXG4gICAqL1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9zaXRlS2V5OiBzdHJpbmcpIHt9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gQXBwIENoZWNrIHRva2VuLlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIGFzeW5jIGdldFRva2VuKFxuICAgIGlzTGltaXRlZFVzZTogYm9vbGVhbiA9IGZhbHNlXG4gICk6IFByb21pc2U8QXBwQ2hlY2tUb2tlbkludGVybmFsPiB7XG4gICAgdGhyb3dJZlRocm90dGxlZCh0aGlzLl90aHJvdHRsZURhdGEpO1xuXG4gICAgLy8gVG9wLWxldmVsIGBnZXRUb2tlbigpYCBoYXMgYWxyZWFkeSBjaGVja2VkIHRoYXQgQXBwIENoZWNrIGlzIGluaXRpYWxpemVkXG4gICAgLy8gYW5kIHRoZXJlZm9yZSB0aGlzLl9hcHAgYW5kIHRoaXMuX2hlYXJ0YmVhdFNlcnZpY2VQcm92aWRlciBhcmUgYXZhaWxhYmxlLlxuICAgIGNvbnN0IGF0dGVzdGVkQ2xhaW1zVG9rZW4gPSBhd2FpdCBnZXRSZUNBUFRDSEFUb2tlbih0aGlzLl9hcHAhKS5jYXRjaChcbiAgICAgIF9lID0+IHtcbiAgICAgICAgLy8gcmVDYXB0Y2hhLmV4ZWN1dGUoKSB0aHJvd3MgbnVsbCB3aGljaCBpcyBub3QgdmVyeSBkZXNjcmlwdGl2ZS5cbiAgICAgICAgdGhyb3cgRVJST1JfRkFDVE9SWS5jcmVhdGUoQXBwQ2hlY2tFcnJvci5SRUNBUFRDSEFfRVJST1IpO1xuICAgICAgfVxuICAgICk7XG4gICAgLy8gQ2hlY2sgaWYgYSBmYWlsdXJlIHN0YXRlIHdhcyBzZXQgYnkgdGhlIHJlY2FwdGNoYSBcImVycm9yLWNhbGxiYWNrXCIuXG4gICAgaWYgKCFnZXRTdGF0ZVJlZmVyZW5jZSh0aGlzLl9hcHAhKS5yZUNBUFRDSEFTdGF0ZT8uc3VjY2VlZGVkKSB7XG4gICAgICB0aHJvdyBFUlJPUl9GQUNUT1JZLmNyZWF0ZShBcHBDaGVja0Vycm9yLlJFQ0FQVENIQV9FUlJPUik7XG4gICAgfVxuICAgIGxldCByZXN1bHQ7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcXVlc3QgPSBnZXRFeGNoYW5nZVJlY2FwdGNoYVYzVG9rZW5SZXF1ZXN0KFxuICAgICAgICB0aGlzLl9hcHAhLFxuICAgICAgICBhdHRlc3RlZENsYWltc1Rva2VuXG4gICAgICApO1xuICAgICAgaWYgKGlzTGltaXRlZFVzZSkge1xuICAgICAgICByZXF1ZXN0LmJvZHlbJ2xpbWl0ZWRfdXNlJ10gPSB0cnVlO1xuICAgICAgfVxuICAgICAgcmVzdWx0ID0gYXdhaXQgZXhjaGFuZ2VUb2tlbihyZXF1ZXN0LCB0aGlzLl9oZWFydGJlYXRTZXJ2aWNlUHJvdmlkZXIhKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBpZiAoXG4gICAgICAgIChlIGFzIEZpcmViYXNlRXJyb3IpLmNvZGU/LmluY2x1ZGVzKEFwcENoZWNrRXJyb3IuRkVUQ0hfU1RBVFVTX0VSUk9SKVxuICAgICAgKSB7XG4gICAgICAgIHRoaXMuX3Rocm90dGxlRGF0YSA9IHNldEJhY2tvZmYoXG4gICAgICAgICAgTnVtYmVyKChlIGFzIEZpcmViYXNlRXJyb3IpLmN1c3RvbURhdGE/Lmh0dHBTdGF0dXMpLFxuICAgICAgICAgIHRoaXMuX3Rocm90dGxlRGF0YVxuICAgICAgICApO1xuICAgICAgICB0aHJvdyBFUlJPUl9GQUNUT1JZLmNyZWF0ZShBcHBDaGVja0Vycm9yLklOSVRJQUxfVEhST1RUTEUsIHtcbiAgICAgICAgICB0aW1lOiBnZXREdXJhdGlvblN0cmluZyhcbiAgICAgICAgICAgIHRoaXMuX3Rocm90dGxlRGF0YS5hbGxvd1JlcXVlc3RzQWZ0ZXIgLSBEYXRlLm5vdygpXG4gICAgICAgICAgKSxcbiAgICAgICAgICBodHRwU3RhdHVzOiB0aGlzLl90aHJvdHRsZURhdGEuaHR0cFN0YXR1c1xuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IGU7XG4gICAgICB9XG4gICAgfVxuICAgIC8vIElmIHN1Y2Nlc3NmdWwsIGNsZWFyIHRocm90dGxlIGRhdGEuXG4gICAgdGhpcy5fdGhyb3R0bGVEYXRhID0gbnVsbDtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG5cbiAgLyoqXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgaW5pdGlhbGl6ZShhcHA6IEZpcmViYXNlQXBwKTogdm9pZCB7XG4gICAgdGhpcy5fYXBwID0gYXBwO1xuICAgIHRoaXMuX2hlYXJ0YmVhdFNlcnZpY2VQcm92aWRlciA9IF9nZXRQcm92aWRlcihhcHAsICdoZWFydGJlYXQnKTtcbiAgICBpbml0aWFsaXplUmVjYXB0Y2hhVjMoYXBwLCB0aGlzLl9zaXRlS2V5KS5jYXRjaCgoKSA9PiB7XG4gICAgICAvKiB3ZSBkb24ndCBjYXJlIGFib3V0IHRoZSBpbml0aWFsaXphdGlvbiByZXN1bHQgKi9cbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIGlzRXF1YWwob3RoZXJQcm92aWRlcjogdW5rbm93bik6IGJvb2xlYW4ge1xuICAgIGlmIChvdGhlclByb3ZpZGVyIGluc3RhbmNlb2YgUmVDYXB0Y2hhVjNQcm92aWRlcikge1xuICAgICAgcmV0dXJuIHRoaXMuX3NpdGVLZXkgPT09IG90aGVyUHJvdmlkZXIuX3NpdGVLZXk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBBcHAgQ2hlY2sgcHJvdmlkZXIgdGhhdCBjYW4gb2J0YWluIGEgcmVDQVBUQ0hBIEVudGVycHJpc2UgdG9rZW4gYW5kIGV4Y2hhbmdlIGl0XG4gKiBmb3IgYW4gQXBwIENoZWNrIHRva2VuLlxuICpcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IGNsYXNzIFJlQ2FwdGNoYUVudGVycHJpc2VQcm92aWRlciBpbXBsZW1lbnRzIEFwcENoZWNrUHJvdmlkZXIge1xuICBwcml2YXRlIF9hcHA/OiBGaXJlYmFzZUFwcDtcbiAgcHJpdmF0ZSBfaGVhcnRiZWF0U2VydmljZVByb3ZpZGVyPzogUHJvdmlkZXI8J2hlYXJ0YmVhdCc+O1xuICAvKipcbiAgICogVGhyb3R0bGUgcmVxdWVzdHMgb24gY2VydGFpbiBlcnJvciBjb2RlcyB0byBwcmV2ZW50IHRvbyBtYW55IHJldHJpZXNcbiAgICogaW4gYSBzaG9ydCB0aW1lLlxuICAgKi9cbiAgcHJpdmF0ZSBfdGhyb3R0bGVEYXRhOiBUaHJvdHRsZURhdGEgfCBudWxsID0gbnVsbDtcbiAgLyoqXG4gICAqIENyZWF0ZSBhIFJlQ2FwdGNoYUVudGVycHJpc2VQcm92aWRlciBpbnN0YW5jZS5cbiAgICogQHBhcmFtIHNpdGVLZXkgLSByZUNBUFRDSEEgRW50ZXJwcmlzZSBzY29yZS1iYXNlZCBzaXRlIGtleS5cbiAgICovXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgX3NpdGVLZXk6IHN0cmluZykge31cblxuICAvKipcbiAgICogUmV0dXJucyBhbiBBcHAgQ2hlY2sgdG9rZW4uXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgYXN5bmMgZ2V0VG9rZW4oXG4gICAgaXNMaW1pdGVkVXNlOiBib29sZWFuID0gZmFsc2VcbiAgKTogUHJvbWlzZTxBcHBDaGVja1Rva2VuSW50ZXJuYWw+IHtcbiAgICB0aHJvd0lmVGhyb3R0bGVkKHRoaXMuX3Rocm90dGxlRGF0YSk7XG4gICAgLy8gVG9wLWxldmVsIGBnZXRUb2tlbigpYCBoYXMgYWxyZWFkeSBjaGVja2VkIHRoYXQgQXBwIENoZWNrIGlzIGluaXRpYWxpemVkXG4gICAgLy8gYW5kIHRoZXJlZm9yZSB0aGlzLl9hcHAgYW5kIHRoaXMuX2hlYXJ0YmVhdFNlcnZpY2VQcm92aWRlciBhcmUgYXZhaWxhYmxlLlxuICAgIGNvbnN0IGF0dGVzdGVkQ2xhaW1zVG9rZW4gPSBhd2FpdCBnZXRSZUNBUFRDSEFUb2tlbih0aGlzLl9hcHAhKS5jYXRjaChcbiAgICAgIF9lID0+IHtcbiAgICAgICAgLy8gcmVDYXB0Y2hhLmV4ZWN1dGUoKSB0aHJvd3MgbnVsbCB3aGljaCBpcyBub3QgdmVyeSBkZXNjcmlwdGl2ZS5cbiAgICAgICAgdGhyb3cgRVJST1JfRkFDVE9SWS5jcmVhdGUoQXBwQ2hlY2tFcnJvci5SRUNBUFRDSEFfRVJST1IpO1xuICAgICAgfVxuICAgICk7XG4gICAgLy8gQ2hlY2sgaWYgYSBmYWlsdXJlIHN0YXRlIHdhcyBzZXQgYnkgdGhlIHJlY2FwdGNoYSBcImVycm9yLWNhbGxiYWNrXCIuXG4gICAgaWYgKCFnZXRTdGF0ZVJlZmVyZW5jZSh0aGlzLl9hcHAhKS5yZUNBUFRDSEFTdGF0ZT8uc3VjY2VlZGVkKSB7XG4gICAgICB0aHJvdyBFUlJPUl9GQUNUT1JZLmNyZWF0ZShBcHBDaGVja0Vycm9yLlJFQ0FQVENIQV9FUlJPUik7XG4gICAgfVxuICAgIGxldCByZXN1bHQ7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlcXVlc3QgPSBnZXRFeGNoYW5nZVJlY2FwdGNoYUVudGVycHJpc2VUb2tlblJlcXVlc3QoXG4gICAgICAgIHRoaXMuX2FwcCEsXG4gICAgICAgIGF0dGVzdGVkQ2xhaW1zVG9rZW5cbiAgICAgICk7XG4gICAgICBpZiAoaXNMaW1pdGVkVXNlKSB7XG4gICAgICAgIHJlcXVlc3QuYm9keVsnbGltaXRlZF91c2UnXSA9IHRydWU7XG4gICAgICB9XG4gICAgICByZXN1bHQgPSBhd2FpdCBleGNoYW5nZVRva2VuKHJlcXVlc3QsIHRoaXMuX2hlYXJ0YmVhdFNlcnZpY2VQcm92aWRlciEpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGlmIChcbiAgICAgICAgKGUgYXMgRmlyZWJhc2VFcnJvcikuY29kZT8uaW5jbHVkZXMoQXBwQ2hlY2tFcnJvci5GRVRDSF9TVEFUVVNfRVJST1IpXG4gICAgICApIHtcbiAgICAgICAgdGhpcy5fdGhyb3R0bGVEYXRhID0gc2V0QmFja29mZihcbiAgICAgICAgICBOdW1iZXIoKGUgYXMgRmlyZWJhc2VFcnJvcikuY3VzdG9tRGF0YT8uaHR0cFN0YXR1cyksXG4gICAgICAgICAgdGhpcy5fdGhyb3R0bGVEYXRhXG4gICAgICAgICk7XG4gICAgICAgIHRocm93IEVSUk9SX0ZBQ1RPUlkuY3JlYXRlKEFwcENoZWNrRXJyb3IuSU5JVElBTF9USFJPVFRMRSwge1xuICAgICAgICAgIHRpbWU6IGdldER1cmF0aW9uU3RyaW5nKFxuICAgICAgICAgICAgdGhpcy5fdGhyb3R0bGVEYXRhLmFsbG93UmVxdWVzdHNBZnRlciAtIERhdGUubm93KClcbiAgICAgICAgICApLFxuICAgICAgICAgIGh0dHBTdGF0dXM6IHRoaXMuX3Rocm90dGxlRGF0YS5odHRwU3RhdHVzXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgZTtcbiAgICAgIH1cbiAgICB9XG4gICAgLy8gSWYgc3VjY2Vzc2Z1bCwgY2xlYXIgdGhyb3R0bGUgZGF0YS5cbiAgICB0aGlzLl90aHJvdHRsZURhdGEgPSBudWxsO1xuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICAvKipcbiAgICogQGludGVybmFsXG4gICAqL1xuICBpbml0aWFsaXplKGFwcDogRmlyZWJhc2VBcHApOiB2b2lkIHtcbiAgICB0aGlzLl9hcHAgPSBhcHA7XG4gICAgdGhpcy5faGVhcnRiZWF0U2VydmljZVByb3ZpZGVyID0gX2dldFByb3ZpZGVyKGFwcCwgJ2hlYXJ0YmVhdCcpO1xuICAgIGluaXRpYWxpemVSZWNhcHRjaGFFbnRlcnByaXNlKGFwcCwgdGhpcy5fc2l0ZUtleSkuY2F0Y2goKCkgPT4ge1xuICAgICAgLyogd2UgZG9uJ3QgY2FyZSBhYm91dCB0aGUgaW5pdGlhbGl6YXRpb24gcmVzdWx0ICovXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogQGludGVybmFsXG4gICAqL1xuICBpc0VxdWFsKG90aGVyUHJvdmlkZXI6IHVua25vd24pOiBib29sZWFuIHtcbiAgICBpZiAob3RoZXJQcm92aWRlciBpbnN0YW5jZW9mIFJlQ2FwdGNoYUVudGVycHJpc2VQcm92aWRlcikge1xuICAgICAgcmV0dXJuIHRoaXMuX3NpdGVLZXkgPT09IG90aGVyUHJvdmlkZXIuX3NpdGVLZXk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBDdXN0b20gcHJvdmlkZXIgY2xhc3MuXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCBjbGFzcyBDdXN0b21Qcm92aWRlciBpbXBsZW1lbnRzIEFwcENoZWNrUHJvdmlkZXIge1xuICBwcml2YXRlIF9hcHA/OiBGaXJlYmFzZUFwcDtcblxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9jdXN0b21Qcm92aWRlck9wdGlvbnM6IEN1c3RvbVByb3ZpZGVyT3B0aW9ucykge31cblxuICAvKipcbiAgICogQGludGVybmFsXG4gICAqL1xuICBhc3luYyBnZXRUb2tlbigpOiBQcm9taXNlPEFwcENoZWNrVG9rZW5JbnRlcm5hbD4ge1xuICAgIC8vIGN1c3RvbSBwcm92aWRlclxuICAgIGNvbnN0IGN1c3RvbVRva2VuID0gYXdhaXQgdGhpcy5fY3VzdG9tUHJvdmlkZXJPcHRpb25zLmdldFRva2VuKCk7XG4gICAgLy8gVHJ5IHRvIGV4dHJhY3QgSUFUIGZyb20gY3VzdG9tIHRva2VuLCBpbiBjYXNlIHRoaXMgdG9rZW4gaXMgbm90XG4gICAgLy8gYmVpbmcgbmV3bHkgaXNzdWVkLiBKV1QgdGltZXN0YW1wcyBhcmUgaW4gc2Vjb25kcyBzaW5jZSBlcG9jaC5cbiAgICBjb25zdCBpc3N1ZWRBdFRpbWVTZWNvbmRzID0gaXNzdWVkQXRUaW1lKGN1c3RvbVRva2VuLnRva2VuKTtcbiAgICAvLyBWZXJ5IGJhc2ljIHZhbGlkYXRpb24sIHVzZSBjdXJyZW50IHRpbWVzdGFtcCBhcyBJQVQgaWYgSldUXG4gICAgLy8gaGFzIG5vIGBpYXRgIGZpZWxkIG9yIHZhbHVlIGlzIG91dCBvZiBib3VuZHMuXG4gICAgY29uc3QgaXNzdWVkQXRUaW1lTWlsbGlzID1cbiAgICAgIGlzc3VlZEF0VGltZVNlY29uZHMgIT09IG51bGwgJiZcbiAgICAgIGlzc3VlZEF0VGltZVNlY29uZHMgPCBEYXRlLm5vdygpICYmXG4gICAgICBpc3N1ZWRBdFRpbWVTZWNvbmRzID4gMFxuICAgICAgICA/IGlzc3VlZEF0VGltZVNlY29uZHMgKiAxMDAwXG4gICAgICAgIDogRGF0ZS5ub3coKTtcblxuICAgIHJldHVybiB7IC4uLmN1c3RvbVRva2VuLCBpc3N1ZWRBdFRpbWVNaWxsaXMgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIGluaXRpYWxpemUoYXBwOiBGaXJlYmFzZUFwcCk6IHZvaWQge1xuICAgIHRoaXMuX2FwcCA9IGFwcDtcbiAgfVxuXG4gIC8qKlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIGlzRXF1YWwob3RoZXJQcm92aWRlcjogdW5rbm93bik6IGJvb2xlYW4ge1xuICAgIGlmIChvdGhlclByb3ZpZGVyIGluc3RhbmNlb2YgQ3VzdG9tUHJvdmlkZXIpIHtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIHRoaXMuX2N1c3RvbVByb3ZpZGVyT3B0aW9ucy5nZXRUb2tlbi50b1N0cmluZygpID09PVxuICAgICAgICBvdGhlclByb3ZpZGVyLl9jdXN0b21Qcm92aWRlck9wdGlvbnMuZ2V0VG9rZW4udG9TdHJpbmcoKVxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqIFNldCB0aHJvdHRsZSBkYXRhIHRvIGJsb2NrIHJlcXVlc3RzIHVudGlsIGFmdGVyIGEgY2VydGFpbiB0aW1lXG4gKiBkZXBlbmRpbmcgb24gdGhlIGZhaWxlZCByZXF1ZXN0J3Mgc3RhdHVzIGNvZGUuXG4gKiBAcGFyYW0gaHR0cFN0YXR1cyAtIFN0YXR1cyBjb2RlIG9mIGZhaWxlZCByZXF1ZXN0LlxuICogQHBhcmFtIHRocm90dGxlRGF0YSAtIGBUaHJvdHRsZURhdGFgIG9iamVjdCBjb250YWluaW5nIHByZXZpb3VzIHRocm90dGxlXG4gKiBkYXRhIHN0YXRlLlxuICogQHJldHVybnMgRGF0YSBhYm91dCBjdXJyZW50IHRocm90dGxlIHN0YXRlIGFuZCBleHBpcmF0aW9uIHRpbWUuXG4gKi9cbmZ1bmN0aW9uIHNldEJhY2tvZmYoXG4gIGh0dHBTdGF0dXM6IG51bWJlcixcbiAgdGhyb3R0bGVEYXRhOiBUaHJvdHRsZURhdGEgfCBudWxsXG4pOiBUaHJvdHRsZURhdGEge1xuICAvKipcbiAgICogQmxvY2sgcmV0cmllcyBmb3IgMSBkYXkgZm9yIHRoZSBmb2xsb3dpbmcgZXJyb3IgY29kZXM6XG4gICAqXG4gICAqIDQwNDogTGlrZWx5IG1hbGZvcm1lZCBVUkwuXG4gICAqXG4gICAqIDQwMzpcbiAgICogLSBBdHRlc3RhdGlvbiBmYWlsZWRcbiAgICogLSBXcm9uZyBBUEkga2V5XG4gICAqIC0gUHJvamVjdCBkZWxldGVkXG4gICAqL1xuICBpZiAoaHR0cFN0YXR1cyA9PT0gNDA0IHx8IGh0dHBTdGF0dXMgPT09IDQwMykge1xuICAgIHJldHVybiB7XG4gICAgICBiYWNrb2ZmQ291bnQ6IDEsXG4gICAgICBhbGxvd1JlcXVlc3RzQWZ0ZXI6IERhdGUubm93KCkgKyBPTkVfREFZLFxuICAgICAgaHR0cFN0YXR1c1xuICAgIH07XG4gIH0gZWxzZSB7XG4gICAgLyoqXG4gICAgICogRm9yIGFsbCBvdGhlciBlcnJvciBjb2RlcywgdGhlIHRpbWUgd2hlbiBpdCBpcyBvayB0byByZXRyeSBhZ2FpblxuICAgICAqIGlzIGJhc2VkIG9uIGV4cG9uZW50aWFsIGJhY2tvZmYuXG4gICAgICovXG4gICAgY29uc3QgYmFja29mZkNvdW50ID0gdGhyb3R0bGVEYXRhID8gdGhyb3R0bGVEYXRhLmJhY2tvZmZDb3VudCA6IDA7XG4gICAgY29uc3QgYmFja29mZk1pbGxpcyA9IGNhbGN1bGF0ZUJhY2tvZmZNaWxsaXMoYmFja29mZkNvdW50LCAxMDAwLCAyKTtcbiAgICByZXR1cm4ge1xuICAgICAgYmFja29mZkNvdW50OiBiYWNrb2ZmQ291bnQgKyAxLFxuICAgICAgYWxsb3dSZXF1ZXN0c0FmdGVyOiBEYXRlLm5vdygpICsgYmFja29mZk1pbGxpcyxcbiAgICAgIGh0dHBTdGF0dXNcbiAgICB9O1xuICB9XG59XG5cbmZ1bmN0aW9uIHRocm93SWZUaHJvdHRsZWQodGhyb3R0bGVEYXRhOiBUaHJvdHRsZURhdGEgfCBudWxsKTogdm9pZCB7XG4gIGlmICh0aHJvdHRsZURhdGEpIHtcbiAgICBpZiAoRGF0ZS5ub3coKSAtIHRocm90dGxlRGF0YS5hbGxvd1JlcXVlc3RzQWZ0ZXIgPD0gMCkge1xuICAgICAgLy8gSWYgYmVmb3JlLCB0aHJvdy5cbiAgICAgIHRocm93IEVSUk9SX0ZBQ1RPUlkuY3JlYXRlKEFwcENoZWNrRXJyb3IuVEhST1RUTEVELCB7XG4gICAgICAgIHRpbWU6IGdldER1cmF0aW9uU3RyaW5nKHRocm90dGxlRGF0YS5hbGxvd1JlcXVlc3RzQWZ0ZXIgLSBEYXRlLm5vdygpKSxcbiAgICAgICAgaHR0cFN0YXR1czogdGhyb3R0bGVEYXRhLmh0dHBTdGF0dXNcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMjAgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHtcbiAgQXBwQ2hlY2ssXG4gIEFwcENoZWNrT3B0aW9ucyxcbiAgQXBwQ2hlY2tUb2tlblJlc3VsdCxcbiAgVW5zdWJzY3JpYmUsXG4gIFBhcnRpYWxPYnNlcnZlclxufSBmcm9tICcuL3B1YmxpYy10eXBlcyc7XG5pbXBvcnQgeyBFUlJPUl9GQUNUT1JZLCBBcHBDaGVja0Vycm9yIH0gZnJvbSAnLi9lcnJvcnMnO1xuaW1wb3J0IHtcbiAgZ2V0U3RhdGVSZWZlcmVuY2UsXG4gIGdldERlYnVnU3RhdGUsXG4gIERFRkFVTFRfU1RBVEUsXG4gIHNldEluaXRpYWxTdGF0ZVxufSBmcm9tICcuL3N0YXRlJztcbmltcG9ydCB7IEZpcmViYXNlQXBwLCBnZXRBcHAsIF9nZXRQcm92aWRlciB9IGZyb20gJ0BmaXJlYmFzZS9hcHAnO1xuaW1wb3J0IHsgZ2V0TW9kdWxhckluc3RhbmNlLCBFcnJvckZuLCBOZXh0Rm4gfSBmcm9tICdAZmlyZWJhc2UvdXRpbCc7XG5pbXBvcnQgeyBBcHBDaGVja1NlcnZpY2UgfSBmcm9tICcuL2ZhY3RvcnknO1xuaW1wb3J0IHsgQXBwQ2hlY2tQcm92aWRlciwgTGlzdGVuZXJUeXBlIH0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQge1xuICBnZXRUb2tlbiBhcyBnZXRUb2tlbkludGVybmFsLFxuICBnZXRMaW1pdGVkVXNlVG9rZW4gYXMgZ2V0TGltaXRlZFVzZVRva2VuSW50ZXJuYWwsXG4gIGFkZFRva2VuTGlzdGVuZXIsXG4gIHJlbW92ZVRva2VuTGlzdGVuZXIsXG4gIGlzVmFsaWQsXG4gIG5vdGlmeVRva2VuTGlzdGVuZXJzXG59IGZyb20gJy4vaW50ZXJuYWwtYXBpJztcbmltcG9ydCB7IHJlYWRUb2tlbkZyb21TdG9yYWdlIH0gZnJvbSAnLi9zdG9yYWdlJztcbmltcG9ydCB7IGdldERlYnVnVG9rZW4sIGluaXRpYWxpemVEZWJ1Z01vZGUsIGlzRGVidWdNb2RlIH0gZnJvbSAnLi9kZWJ1Zyc7XG5pbXBvcnQgeyBsb2dnZXIgfSBmcm9tICcuL2xvZ2dlcic7XG5cbmRlY2xhcmUgbW9kdWxlICdAZmlyZWJhc2UvY29tcG9uZW50JyB7XG4gIGludGVyZmFjZSBOYW1lU2VydmljZU1hcHBpbmcge1xuICAgICdhcHAtY2hlY2snOiBBcHBDaGVja1NlcnZpY2U7XG4gIH1cbn1cblxuZXhwb3J0IHtcbiAgUmVDYXB0Y2hhVjNQcm92aWRlcixcbiAgQ3VzdG9tUHJvdmlkZXIsXG4gIFJlQ2FwdGNoYUVudGVycHJpc2VQcm92aWRlclxufSBmcm9tICcuL3Byb3ZpZGVycyc7XG5cbi8qKlxuICogQWN0aXZhdGUgQXBwIENoZWNrIGZvciB0aGUgZ2l2ZW4gYXBwLiBDYW4gYmUgY2FsbGVkIG9ubHkgb25jZSBwZXIgYXBwLlxuICogQHBhcmFtIGFwcCAtIHRoZSB7QGxpbmsgQGZpcmViYXNlL2FwcCNGaXJlYmFzZUFwcH0gdG8gYWN0aXZhdGUgQXBwIENoZWNrIGZvclxuICogQHBhcmFtIG9wdGlvbnMgLSBBcHAgQ2hlY2sgaW5pdGlhbGl6YXRpb24gb3B0aW9uc1xuICogQHB1YmxpY1xuICovXG5leHBvcnQgZnVuY3Rpb24gaW5pdGlhbGl6ZUFwcENoZWNrKFxuICBhcHA6IEZpcmViYXNlQXBwID0gZ2V0QXBwKCksXG4gIG9wdGlvbnM6IEFwcENoZWNrT3B0aW9uc1xuKTogQXBwQ2hlY2sge1xuICBhcHAgPSBnZXRNb2R1bGFySW5zdGFuY2UoYXBwKTtcbiAgY29uc3QgcHJvdmlkZXIgPSBfZ2V0UHJvdmlkZXIoYXBwLCAnYXBwLWNoZWNrJyk7XG5cbiAgLy8gRW5zdXJlIGluaXRpYWxpemVEZWJ1Z01vZGUoKSBpcyBvbmx5IGNhbGxlZCBvbmNlLlxuICBpZiAoIWdldERlYnVnU3RhdGUoKS5pbml0aWFsaXplZCkge1xuICAgIGluaXRpYWxpemVEZWJ1Z01vZGUoKTtcbiAgfVxuXG4gIC8vIExvZyBhIG1lc3NhZ2UgY29udGFpbmluZyB0aGUgZGVidWcgdG9rZW4gd2hlbiBgaW5pdGlhbGl6ZUFwcENoZWNrKClgXG4gIC8vIGlzIGNhbGxlZCBpbiBkZWJ1ZyBtb2RlLlxuICBpZiAoaXNEZWJ1Z01vZGUoKSkge1xuICAgIC8vIERvIG5vdCBibG9jayBpbml0aWFsaXphdGlvbiB0byBnZXQgdGhlIHRva2VuIGZvciB0aGUgbWVzc2FnZS5cbiAgICB2b2lkIGdldERlYnVnVG9rZW4oKS50aGVuKHRva2VuID0+XG4gICAgICAvLyBOb3QgdXNpbmcgbG9nZ2VyIGJlY2F1c2UgSSBkb24ndCB0aGluayB3ZSBldmVyIHdhbnQgdGhpcyBhY2NpZGVudGFsbHkgaGlkZGVuLlxuICAgICAgY29uc29sZS5sb2coXG4gICAgICAgIGBBcHAgQ2hlY2sgZGVidWcgdG9rZW46ICR7dG9rZW59LiBZb3Ugd2lsbCBuZWVkIHRvIGFkZCBpdCB0byB5b3VyIGFwcCdzIEFwcCBDaGVjayBzZXR0aW5ncyBpbiB0aGUgRmlyZWJhc2UgY29uc29sZSBmb3IgaXQgdG8gd29yay5gXG4gICAgICApXG4gICAgKTtcbiAgfVxuXG4gIGlmIChwcm92aWRlci5pc0luaXRpYWxpemVkKCkpIHtcbiAgICBjb25zdCBleGlzdGluZ0luc3RhbmNlID0gcHJvdmlkZXIuZ2V0SW1tZWRpYXRlKCk7XG4gICAgY29uc3QgaW5pdGlhbE9wdGlvbnMgPSBwcm92aWRlci5nZXRPcHRpb25zKCkgYXMgdW5rbm93biBhcyBBcHBDaGVja09wdGlvbnM7XG4gICAgaWYgKFxuICAgICAgaW5pdGlhbE9wdGlvbnMgJiZcbiAgICAgICEhaW5pdGlhbE9wdGlvbnMuaXNUb2tlbkF1dG9SZWZyZXNoRW5hYmxlZCA9PT1cbiAgICAgICAgISFvcHRpb25zLmlzVG9rZW5BdXRvUmVmcmVzaEVuYWJsZWQgJiZcbiAgICAgIGluaXRpYWxPcHRpb25zLnByb3ZpZGVyPy5pc0VxdWFsKG9wdGlvbnMucHJvdmlkZXIpXG4gICAgKSB7XG4gICAgICByZXR1cm4gZXhpc3RpbmdJbnN0YW5jZTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgRVJST1JfRkFDVE9SWS5jcmVhdGUoQXBwQ2hlY2tFcnJvci5BTFJFQURZX0lOSVRJQUxJWkVELCB7XG4gICAgICAgIGFwcE5hbWU6IGFwcC5uYW1lXG4gICAgICB9KTtcbiAgICB9XG4gIH1cblxuICBjb25zdCBhcHBDaGVjayA9IHByb3ZpZGVyLmluaXRpYWxpemUoeyBvcHRpb25zIH0pO1xuICBfYWN0aXZhdGUoYXBwLCBvcHRpb25zLnByb3ZpZGVyLCBvcHRpb25zLmlzVG9rZW5BdXRvUmVmcmVzaEVuYWJsZWQpO1xuICAvLyBJZiBpc1Rva2VuQXV0b1JlZnJlc2hFbmFibGVkIGlzIGZhbHNlLCBkbyBub3Qgc2VuZCBhbnkgcmVxdWVzdHMgdG8gdGhlXG4gIC8vIGV4Y2hhbmdlIGVuZHBvaW50IHdpdGhvdXQgYW4gZXhwbGljaXQgY2FsbCBmcm9tIHRoZSB1c2VyIGVpdGhlciBkaXJlY3RseVxuICAvLyBvciB0aHJvdWdoIGFub3RoZXIgRmlyZWJhc2UgbGlicmFyeSAoc3RvcmFnZSwgZnVuY3Rpb25zLCBldGMuKVxuICBpZiAoZ2V0U3RhdGVSZWZlcmVuY2UoYXBwKS5pc1Rva2VuQXV0b1JlZnJlc2hFbmFibGVkKSB7XG4gICAgLy8gQWRkaW5nIGEgbGlzdGVuZXIgd2lsbCBzdGFydCB0aGUgcmVmcmVzaGVyIGFuZCBmZXRjaCBhIHRva2VuIGlmIG5lZWRlZC5cbiAgICAvLyBUaGlzIGdldHMgYSB0b2tlbiByZWFkeSBhbmQgcHJldmVudHMgYSBkZWxheSB3aGVuIGFuIGludGVybmFsIGxpYnJhcnlcbiAgICAvLyByZXF1ZXN0cyB0aGUgdG9rZW4uXG4gICAgLy8gTGlzdGVuZXIgZnVuY3Rpb24gZG9lcyBub3QgbmVlZCB0byBkbyBhbnl0aGluZywgaXRzIGJhc2UgZnVuY3Rpb25hbGl0eVxuICAgIC8vIG9mIGNhbGxpbmcgZ2V0VG9rZW4oKSBhbHJlYWR5IGZldGNoZXMgdG9rZW4gYW5kIHdyaXRlcyBpdCB0byBtZW1vcnkvc3RvcmFnZS5cbiAgICBhZGRUb2tlbkxpc3RlbmVyKGFwcENoZWNrLCBMaXN0ZW5lclR5cGUuSU5URVJOQUwsICgpID0+IHt9KTtcbiAgfVxuXG4gIHJldHVybiBhcHBDaGVjaztcbn1cblxuLyoqXG4gKiBBY3RpdmF0ZSBBcHAgQ2hlY2tcbiAqIEBwYXJhbSBhcHAgLSBGaXJlYmFzZSBhcHAgdG8gYWN0aXZhdGUgQXBwIENoZWNrIGZvci5cbiAqIEBwYXJhbSBwcm92aWRlciAtIHJlQ0FQVENIQSB2MyBwcm92aWRlciBvclxuICogY3VzdG9tIHRva2VuIHByb3ZpZGVyLlxuICogQHBhcmFtIGlzVG9rZW5BdXRvUmVmcmVzaEVuYWJsZWQgLSBJZiB0cnVlLCB0aGUgU0RLIGF1dG9tYXRpY2FsbHlcbiAqIHJlZnJlc2hlcyBBcHAgQ2hlY2sgdG9rZW5zIGFzIG5lZWRlZC4gSWYgdW5kZWZpbmVkLCBkZWZhdWx0cyB0byB0aGVcbiAqIHZhbHVlIG9mIGBhcHAuYXV0b21hdGljRGF0YUNvbGxlY3Rpb25FbmFibGVkYCwgd2hpY2ggZGVmYXVsdHMgdG9cbiAqIGZhbHNlIGFuZCBjYW4gYmUgc2V0IGluIHRoZSBhcHAgY29uZmlnLlxuICovXG5mdW5jdGlvbiBfYWN0aXZhdGUoXG4gIGFwcDogRmlyZWJhc2VBcHAsXG4gIHByb3ZpZGVyOiBBcHBDaGVja1Byb3ZpZGVyLFxuICBpc1Rva2VuQXV0b1JlZnJlc2hFbmFibGVkOiBib29sZWFuID0gZmFsc2Vcbik6IHZvaWQge1xuICAvLyBDcmVhdGUgYW4gZW50cnkgaW4gdGhlIEFQUF9DSEVDS19TVEFURVMgbWFwLiBGdXJ0aGVyIGNoYW5nZXMgc2hvdWxkXG4gIC8vIGRpcmVjdGx5IG11dGF0ZSB0aGlzIG9iamVjdC5cbiAgY29uc3Qgc3RhdGUgPSBzZXRJbml0aWFsU3RhdGUoYXBwLCB7IC4uLkRFRkFVTFRfU1RBVEUgfSk7XG5cbiAgc3RhdGUuYWN0aXZhdGVkID0gdHJ1ZTtcbiAgc3RhdGUucHJvdmlkZXIgPSBwcm92aWRlcjsgLy8gUmVhZCBjYWNoZWQgdG9rZW4gZnJvbSBzdG9yYWdlIGlmIGl0IGV4aXN0cyBhbmQgc3RvcmUgaXQgaW4gbWVtb3J5LlxuICBzdGF0ZS5jYWNoZWRUb2tlblByb21pc2UgPSByZWFkVG9rZW5Gcm9tU3RvcmFnZShhcHApLnRoZW4oY2FjaGVkVG9rZW4gPT4ge1xuICAgIGlmIChjYWNoZWRUb2tlbiAmJiBpc1ZhbGlkKGNhY2hlZFRva2VuKSkge1xuICAgICAgc3RhdGUudG9rZW4gPSBjYWNoZWRUb2tlbjtcbiAgICAgIC8vIG5vdGlmeSBhbGwgbGlzdGVuZXJzIHdpdGggdGhlIGNhY2hlZCB0b2tlblxuICAgICAgbm90aWZ5VG9rZW5MaXN0ZW5lcnMoYXBwLCB7IHRva2VuOiBjYWNoZWRUb2tlbi50b2tlbiB9KTtcbiAgICB9XG4gICAgcmV0dXJuIGNhY2hlZFRva2VuO1xuICB9KTtcblxuICAvLyBHbG9iYWwgYGF1dG9tYXRpY0RhdGFDb2xsZWN0aW9uRW5hYmxlZGAgKGRlZmF1bHRzIHRvIHRydWUpIGFuZFxuICAvLyBgaXNUb2tlbkF1dG9SZWZyZXNoRW5hYmxlZGAgbXVzdCBib3RoIGJlIHRydWUuXG4gIHN0YXRlLmlzVG9rZW5BdXRvUmVmcmVzaEVuYWJsZWQgPVxuICAgIGlzVG9rZW5BdXRvUmVmcmVzaEVuYWJsZWQgJiYgYXBwLmF1dG9tYXRpY0RhdGFDb2xsZWN0aW9uRW5hYmxlZDtcblxuICBpZiAoIWFwcC5hdXRvbWF0aWNEYXRhQ29sbGVjdGlvbkVuYWJsZWQgJiYgaXNUb2tlbkF1dG9SZWZyZXNoRW5hYmxlZCkge1xuICAgIGxvZ2dlci53YXJuKFxuICAgICAgJ2Bpc1Rva2VuQXV0b1JlZnJlc2hFbmFibGVkYCBpcyB0cnVlIGJ1dCAnICtcbiAgICAgICAgJ2BhdXRvbWF0aWNEYXRhQ29sbGVjdGlvbkVuYWJsZWRgIHdhcyBzZXQgdG8gZmFsc2UgZHVyaW5nJyArXG4gICAgICAgICcgYGluaXRpYWxpemVBcHAoKWAuIFRoaXMgYmxvY2tzIGF1dG9tYXRpYyB0b2tlbiByZWZyZXNoLidcbiAgICApO1xuICB9XG5cbiAgc3RhdGUucHJvdmlkZXIuaW5pdGlhbGl6ZShhcHApO1xufVxuXG4vKipcbiAqIFNldCB3aGV0aGVyIEFwcCBDaGVjayB3aWxsIGF1dG9tYXRpY2FsbHkgcmVmcmVzaCB0b2tlbnMgYXMgbmVlZGVkLlxuICpcbiAqIEBwYXJhbSBhcHBDaGVja0luc3RhbmNlIC0gVGhlIEFwcCBDaGVjayBzZXJ2aWNlIGluc3RhbmNlLlxuICogQHBhcmFtIGlzVG9rZW5BdXRvUmVmcmVzaEVuYWJsZWQgLSBJZiB0cnVlLCB0aGUgU0RLIGF1dG9tYXRpY2FsbHlcbiAqIHJlZnJlc2hlcyBBcHAgQ2hlY2sgdG9rZW5zIGFzIG5lZWRlZC4gVGhpcyBvdmVycmlkZXMgYW55IHZhbHVlIHNldFxuICogZHVyaW5nIGBpbml0aWFsaXplQXBwQ2hlY2soKWAuXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzZXRUb2tlbkF1dG9SZWZyZXNoRW5hYmxlZChcbiAgYXBwQ2hlY2tJbnN0YW5jZTogQXBwQ2hlY2ssXG4gIGlzVG9rZW5BdXRvUmVmcmVzaEVuYWJsZWQ6IGJvb2xlYW5cbik6IHZvaWQge1xuICBjb25zdCBhcHAgPSBhcHBDaGVja0luc3RhbmNlLmFwcDtcbiAgY29uc3Qgc3RhdGUgPSBnZXRTdGF0ZVJlZmVyZW5jZShhcHApO1xuICAvLyBUaGlzIHdpbGwgZXhpc3QgaWYgYW55IHByb2R1Y3QgbGlicmFyaWVzIGhhdmUgY2FsbGVkXG4gIC8vIGBhZGRUb2tlbkxpc3RlbmVyKClgXG4gIGlmIChzdGF0ZS50b2tlblJlZnJlc2hlcikge1xuICAgIGlmIChpc1Rva2VuQXV0b1JlZnJlc2hFbmFibGVkID09PSB0cnVlKSB7XG4gICAgICBzdGF0ZS50b2tlblJlZnJlc2hlci5zdGFydCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdGF0ZS50b2tlblJlZnJlc2hlci5zdG9wKCk7XG4gICAgfVxuICB9XG4gIHN0YXRlLmlzVG9rZW5BdXRvUmVmcmVzaEVuYWJsZWQgPSBpc1Rva2VuQXV0b1JlZnJlc2hFbmFibGVkO1xufVxuLyoqXG4gKiBHZXQgdGhlIGN1cnJlbnQgQXBwIENoZWNrIHRva2VuLiBJZiBgZm9yY2VSZWZyZXNoYCBpcyBmYWxzZSwgdGhpcyBmdW5jdGlvbiBmaXJzdFxuICogY2hlY2tzIGZvciBhIHZhbGlkIHRva2VuIGluIG1lbW9yeSwgdGhlbiBsb2NhbCBwZXJzaXN0ZW5jZSAoSW5kZXhlZERCKS5cbiAqIElmIG5vdCBmb3VuZCwgb3IgaWYgYGZvcmNlUmVmcmVzaGAgaXMgdHJ1ZSwgaXQgbWFrZXMgYSByZXF1ZXN0IHRvIHRoZVxuICogQXBwIENoZWNrIGVuZHBvaW50IGZvciBhIGZyZXNoIHRva2VuLiBUaGF0IHJlcXVlc3QgYXR0YWNoZXNcbiAqIHRvIHRoZSBtb3N0IHJlY2VudCBpbi1mbGlnaHQgcmVxdWVzdCBpZiBvbmUgaXMgcHJlc2VudC5cbiAqXG4gKiBAcGFyYW0gYXBwQ2hlY2tJbnN0YW5jZSAtIFRoZSBBcHAgQ2hlY2sgc2VydmljZSBpbnN0YW5jZS5cbiAqIEBwYXJhbSBmb3JjZVJlZnJlc2ggLSBJZiB0cnVlLCB3aWxsIGFsd2F5cyB0cnkgdG8gZmV0Y2ggYSBmcmVzaCB0b2tlbi5cbiAqIElmIGZhbHNlLCB3aWxsIHVzZSBhIGNhY2hlZCB0b2tlbiBpZiBmb3VuZCBpbiBzdG9yYWdlLlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VG9rZW4oXG4gIGFwcENoZWNrSW5zdGFuY2U6IEFwcENoZWNrLFxuICBmb3JjZVJlZnJlc2g/OiBib29sZWFuXG4pOiBQcm9taXNlPEFwcENoZWNrVG9rZW5SZXN1bHQ+IHtcbiAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZ2V0VG9rZW5JbnRlcm5hbChcbiAgICBhcHBDaGVja0luc3RhbmNlIGFzIEFwcENoZWNrU2VydmljZSxcbiAgICBmb3JjZVJlZnJlc2hcbiAgKTtcbiAgaWYgKHJlc3VsdC5lcnJvcikge1xuICAgIHRocm93IHJlc3VsdC5lcnJvcjtcbiAgfVxuICBpZiAocmVzdWx0LmludGVybmFsRXJyb3IpIHtcbiAgICB0aHJvdyByZXN1bHQuaW50ZXJuYWxFcnJvcjtcbiAgfVxuICByZXR1cm4geyB0b2tlbjogcmVzdWx0LnRva2VuIH07XG59XG5cbi8qKlxuICogUmVxdWVzdHMgYSBGaXJlYmFzZSBBcHAgQ2hlY2sgdG9rZW4uIFRoaXMgbWV0aG9kIHNob3VsZCBiZSB1c2VkXG4gKiBvbmx5IGlmIHlvdSBuZWVkIHRvIGF1dGhvcml6ZSByZXF1ZXN0cyB0byBhIG5vbi1GaXJlYmFzZSBiYWNrZW5kLlxuICpcbiAqIFJldHVybnMgbGltaXRlZC11c2UgdG9rZW5zIHRoYXQgYXJlIGludGVuZGVkIGZvciB1c2Ugd2l0aCB5b3VyXG4gKiBub24tRmlyZWJhc2UgYmFja2VuZCBlbmRwb2ludHMgdGhhdCBhcmUgcHJvdGVjdGVkIHdpdGhcbiAqIDxhIGhyZWY9XCJodHRwczovL2ZpcmViYXNlLmdvb2dsZS5jb20vZG9jcy9hcHAtY2hlY2svY3VzdG9tLXJlc291cmNlLWJhY2tlbmQjcmVwbGF5LXByb3RlY3Rpb25cIj5cbiAqIFJlcGxheSBQcm90ZWN0aW9uPC9hPi4gVGhpcyBtZXRob2RcbiAqIGRvZXMgbm90IGFmZmVjdCB0aGUgdG9rZW4gZ2VuZXJhdGlvbiBiZWhhdmlvciBvZiB0aGVcbiAqICNnZXRBcHBDaGVja1Rva2VuKCkgbWV0aG9kLlxuICpcbiAqIEBwYXJhbSBhcHBDaGVja0luc3RhbmNlIC0gVGhlIEFwcCBDaGVjayBzZXJ2aWNlIGluc3RhbmNlLlxuICogQHJldHVybnMgVGhlIGxpbWl0ZWQgdXNlIHRva2VuLlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0TGltaXRlZFVzZVRva2VuKFxuICBhcHBDaGVja0luc3RhbmNlOiBBcHBDaGVja1xuKTogUHJvbWlzZTxBcHBDaGVja1Rva2VuUmVzdWx0PiB7XG4gIHJldHVybiBnZXRMaW1pdGVkVXNlVG9rZW5JbnRlcm5hbChhcHBDaGVja0luc3RhbmNlIGFzIEFwcENoZWNrU2VydmljZSk7XG59XG5cbi8qKlxuICogUmVnaXN0ZXJzIGEgbGlzdGVuZXIgdG8gY2hhbmdlcyBpbiB0aGUgdG9rZW4gc3RhdGUuIFRoZXJlIGNhbiBiZSBtb3JlXG4gKiB0aGFuIG9uZSBsaXN0ZW5lciByZWdpc3RlcmVkIGF0IHRoZSBzYW1lIHRpbWUgZm9yIG9uZSBvciBtb3JlXG4gKiBBcHAgQ2hlY2sgaW5zdGFuY2VzLiBUaGUgbGlzdGVuZXJzIGNhbGwgYmFjayBvbiB0aGUgVUkgdGhyZWFkIHdoZW5ldmVyXG4gKiB0aGUgY3VycmVudCB0b2tlbiBhc3NvY2lhdGVkIHdpdGggdGhpcyBBcHAgQ2hlY2sgaW5zdGFuY2UgY2hhbmdlcy5cbiAqXG4gKiBAcGFyYW0gYXBwQ2hlY2tJbnN0YW5jZSAtIFRoZSBBcHAgQ2hlY2sgc2VydmljZSBpbnN0YW5jZS5cbiAqIEBwYXJhbSBvYnNlcnZlciAtIEFuIG9iamVjdCB3aXRoIGBuZXh0YCwgYGVycm9yYCwgYW5kIGBjb21wbGV0ZWBcbiAqIHByb3BlcnRpZXMuIGBuZXh0YCBpcyBjYWxsZWQgd2l0aCBhblxuICoge0BsaW5rIEFwcENoZWNrVG9rZW5SZXN1bHR9XG4gKiB3aGVuZXZlciB0aGUgdG9rZW4gY2hhbmdlcy4gYGVycm9yYCBpcyBvcHRpb25hbCBhbmQgaXMgY2FsbGVkIGlmIGFuXG4gKiBlcnJvciBpcyB0aHJvd24gYnkgdGhlIGxpc3RlbmVyICh0aGUgYG5leHRgIGZ1bmN0aW9uKS4gYGNvbXBsZXRlYFxuICogaXMgdW51c2VkLCBhcyB0aGUgdG9rZW4gc3RyZWFtIGlzIHVuZW5kaW5nLlxuICpcbiAqIEByZXR1cm5zIEEgZnVuY3Rpb24gdGhhdCB1bnN1YnNjcmliZXMgdGhpcyBsaXN0ZW5lci5cbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIG9uVG9rZW5DaGFuZ2VkKFxuICBhcHBDaGVja0luc3RhbmNlOiBBcHBDaGVjayxcbiAgb2JzZXJ2ZXI6IFBhcnRpYWxPYnNlcnZlcjxBcHBDaGVja1Rva2VuUmVzdWx0PlxuKTogVW5zdWJzY3JpYmU7XG4vKipcbiAqIFJlZ2lzdGVycyBhIGxpc3RlbmVyIHRvIGNoYW5nZXMgaW4gdGhlIHRva2VuIHN0YXRlLiBUaGVyZSBjYW4gYmUgbW9yZVxuICogdGhhbiBvbmUgbGlzdGVuZXIgcmVnaXN0ZXJlZCBhdCB0aGUgc2FtZSB0aW1lIGZvciBvbmUgb3IgbW9yZVxuICogQXBwIENoZWNrIGluc3RhbmNlcy4gVGhlIGxpc3RlbmVycyBjYWxsIGJhY2sgb24gdGhlIFVJIHRocmVhZCB3aGVuZXZlclxuICogdGhlIGN1cnJlbnQgdG9rZW4gYXNzb2NpYXRlZCB3aXRoIHRoaXMgQXBwIENoZWNrIGluc3RhbmNlIGNoYW5nZXMuXG4gKlxuICogQHBhcmFtIGFwcENoZWNrSW5zdGFuY2UgLSBUaGUgQXBwIENoZWNrIHNlcnZpY2UgaW5zdGFuY2UuXG4gKiBAcGFyYW0gb25OZXh0IC0gV2hlbiB0aGUgdG9rZW4gY2hhbmdlcywgdGhpcyBmdW5jdGlvbiBpcyBjYWxsZWQgd2l0aCBhblxuICoge0BsaW5rIEFwcENoZWNrVG9rZW5SZXN1bHR9LlxuICogQHBhcmFtIG9uRXJyb3IgLSBPcHRpb25hbC4gQ2FsbGVkIGlmIHRoZXJlIGlzIGFuIGVycm9yIHRocm93biBieSB0aGVcbiAqIGxpc3RlbmVyICh0aGUgYG9uTmV4dGAgZnVuY3Rpb24pLlxuICogQHBhcmFtIG9uQ29tcGxldGlvbiAtIEN1cnJlbnRseSB1bnVzZWQsIGFzIHRoZSB0b2tlbiBzdHJlYW0gaXMgdW5lbmRpbmcuXG4gKiBAcmV0dXJucyBBIGZ1bmN0aW9uIHRoYXQgdW5zdWJzY3JpYmVzIHRoaXMgbGlzdGVuZXIuXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBvblRva2VuQ2hhbmdlZChcbiAgYXBwQ2hlY2tJbnN0YW5jZTogQXBwQ2hlY2ssXG4gIG9uTmV4dDogKHRva2VuUmVzdWx0OiBBcHBDaGVja1Rva2VuUmVzdWx0KSA9PiB2b2lkLFxuICBvbkVycm9yPzogKGVycm9yOiBFcnJvcikgPT4gdm9pZCxcbiAgb25Db21wbGV0aW9uPzogKCkgPT4gdm9pZFxuKTogVW5zdWJzY3JpYmU7XG4vKipcbiAqIFdyYXBzIGBhZGRUb2tlbkxpc3RlbmVyYC9gcmVtb3ZlVG9rZW5MaXN0ZW5lcmAgbWV0aG9kcyBpbiBhbiBgT2JzZXJ2ZXJgXG4gKiBwYXR0ZXJuIGZvciBwdWJsaWMgdXNlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gb25Ub2tlbkNoYW5nZWQoXG4gIGFwcENoZWNrSW5zdGFuY2U6IEFwcENoZWNrLFxuICBvbk5leHRPck9ic2VydmVyOlxuICAgIHwgKCh0b2tlblJlc3VsdDogQXBwQ2hlY2tUb2tlblJlc3VsdCkgPT4gdm9pZClcbiAgICB8IFBhcnRpYWxPYnNlcnZlcjxBcHBDaGVja1Rva2VuUmVzdWx0PixcbiAgb25FcnJvcj86IChlcnJvcjogRXJyb3IpID0+IHZvaWQsXG4gIC8qKlxuICAgKiBOT1RFOiBBbHRob3VnaCBhbiBgb25Db21wbGV0aW9uYCBjYWxsYmFjayBjYW4gYmUgcHJvdmlkZWQsIGl0IHdpbGxcbiAgICogbmV2ZXIgYmUgY2FsbGVkIGJlY2F1c2UgdGhlIHRva2VuIHN0cmVhbSBpcyBuZXZlci1lbmRpbmcuXG4gICAqIEl0IGlzIGFkZGVkIG9ubHkgZm9yIEFQSSBjb25zaXN0ZW5jeSB3aXRoIHRoZSBvYnNlcnZlciBwYXR0ZXJuLCB3aGljaFxuICAgKiB3ZSBmb2xsb3cgaW4gSlMgQVBJcy5cbiAgICovXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tdW51c2VkLXZhcnNcbiAgb25Db21wbGV0aW9uPzogKCkgPT4gdm9pZFxuKTogVW5zdWJzY3JpYmUge1xuICBsZXQgbmV4dEZuOiBOZXh0Rm48QXBwQ2hlY2tUb2tlblJlc3VsdD4gPSAoKSA9PiB7fTtcbiAgbGV0IGVycm9yRm46IEVycm9yRm4gPSAoKSA9PiB7fTtcbiAgaWYgKChvbk5leHRPck9ic2VydmVyIGFzIFBhcnRpYWxPYnNlcnZlcjxBcHBDaGVja1Rva2VuUmVzdWx0PikubmV4dCAhPSBudWxsKSB7XG4gICAgbmV4dEZuID0gKFxuICAgICAgb25OZXh0T3JPYnNlcnZlciBhcyBQYXJ0aWFsT2JzZXJ2ZXI8QXBwQ2hlY2tUb2tlblJlc3VsdD5cbiAgICApLm5leHQhLmJpbmQob25OZXh0T3JPYnNlcnZlcik7XG4gIH0gZWxzZSB7XG4gICAgbmV4dEZuID0gb25OZXh0T3JPYnNlcnZlciBhcyBOZXh0Rm48QXBwQ2hlY2tUb2tlblJlc3VsdD47XG4gIH1cbiAgaWYgKFxuICAgIChvbk5leHRPck9ic2VydmVyIGFzIFBhcnRpYWxPYnNlcnZlcjxBcHBDaGVja1Rva2VuUmVzdWx0PikuZXJyb3IgIT0gbnVsbFxuICApIHtcbiAgICBlcnJvckZuID0gKFxuICAgICAgb25OZXh0T3JPYnNlcnZlciBhcyBQYXJ0aWFsT2JzZXJ2ZXI8QXBwQ2hlY2tUb2tlblJlc3VsdD5cbiAgICApLmVycm9yIS5iaW5kKG9uTmV4dE9yT2JzZXJ2ZXIpO1xuICB9IGVsc2UgaWYgKG9uRXJyb3IpIHtcbiAgICBlcnJvckZuID0gb25FcnJvcjtcbiAgfVxuICBhZGRUb2tlbkxpc3RlbmVyKFxuICAgIGFwcENoZWNrSW5zdGFuY2UgYXMgQXBwQ2hlY2tTZXJ2aWNlLFxuICAgIExpc3RlbmVyVHlwZS5FWFRFUk5BTCxcbiAgICBuZXh0Rm4sXG4gICAgZXJyb3JGblxuICApO1xuICByZXR1cm4gKCkgPT4gcmVtb3ZlVG9rZW5MaXN0ZW5lcihhcHBDaGVja0luc3RhbmNlLmFwcCwgbmV4dEZuKTtcbn1cbiIsIi8qKlxuICogVGhlIEZpcmViYXNlIEFwcCBDaGVjayBXZWIgU0RLLlxuICpcbiAqIEByZW1hcmtzXG4gKiBGaXJlYmFzZSBBcHAgQ2hlY2sgZG9lcyBub3Qgd29yayBpbiBhIE5vZGUuanMgZW52aXJvbm1lbnQgdXNpbmcgYFJlQ2FwdGNoYVYzUHJvdmlkZXJgIG9yXG4gKiBgUmVDYXB0Y2hhRW50ZXJwcmlzZVByb3ZpZGVyYCwgYnV0IGNhbiBiZSB1c2VkIGluIE5vZGUuanMgaWYgeW91IHVzZVxuICogYEN1c3RvbVByb3ZpZGVyYCBhbmQgd3JpdGUgeW91ciBvd24gYXR0ZXN0YXRpb24gbWV0aG9kLlxuICpcbiAqIEBwYWNrYWdlRG9jdW1lbnRhdGlvblxuICovXG5cbi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDIxIEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5pbXBvcnQgeyByZWdpc3RlclZlcnNpb24sIF9yZWdpc3RlckNvbXBvbmVudCB9IGZyb20gJ0BmaXJlYmFzZS9hcHAnO1xuaW1wb3J0IHtcbiAgQ29tcG9uZW50LFxuICBDb21wb25lbnRUeXBlLFxuICBJbnN0YW50aWF0aW9uTW9kZVxufSBmcm9tICdAZmlyZWJhc2UvY29tcG9uZW50JztcbmltcG9ydCB7IF9BcHBDaGVja0NvbXBvbmVudE5hbWUgfSBmcm9tICcuL3B1YmxpYy10eXBlcyc7XG5pbXBvcnQgeyBmYWN0b3J5LCBpbnRlcm5hbEZhY3RvcnkgfSBmcm9tICcuL2ZhY3RvcnknO1xuaW1wb3J0IHsgX0FwcENoZWNrSW50ZXJuYWxDb21wb25lbnROYW1lIH0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyBuYW1lLCB2ZXJzaW9uIH0gZnJvbSAnLi4vcGFja2FnZS5qc29uJztcblxuLy8gVXNlZCBieSBvdGhlciBGaXJlYmFzZSBwYWNrYWdlcy5cbmV4cG9ydCB7IF9BcHBDaGVja0ludGVybmFsQ29tcG9uZW50TmFtZSB9O1xuXG5leHBvcnQgKiBmcm9tICcuL2FwaSc7XG5leHBvcnQgKiBmcm9tICcuL3B1YmxpYy10eXBlcyc7XG5cbmNvbnN0IEFQUF9DSEVDS19OQU1FOiBfQXBwQ2hlY2tDb21wb25lbnROYW1lID0gJ2FwcC1jaGVjayc7XG5jb25zdCBBUFBfQ0hFQ0tfTkFNRV9JTlRFUk5BTDogX0FwcENoZWNrSW50ZXJuYWxDb21wb25lbnROYW1lID1cbiAgJ2FwcC1jaGVjay1pbnRlcm5hbCc7XG5mdW5jdGlvbiByZWdpc3RlckFwcENoZWNrKCk6IHZvaWQge1xuICAvLyBUaGUgcHVibGljIGludGVyZmFjZVxuICBfcmVnaXN0ZXJDb21wb25lbnQoXG4gICAgbmV3IENvbXBvbmVudChcbiAgICAgIEFQUF9DSEVDS19OQU1FLFxuICAgICAgY29udGFpbmVyID0+IHtcbiAgICAgICAgLy8gZ2V0SW1tZWRpYXRlIGZvciBGaXJlYmFzZUFwcCB3aWxsIGFsd2F5cyBzdWNjZWVkXG4gICAgICAgIGNvbnN0IGFwcCA9IGNvbnRhaW5lci5nZXRQcm92aWRlcignYXBwJykuZ2V0SW1tZWRpYXRlKCk7XG4gICAgICAgIGNvbnN0IGhlYXJ0YmVhdFNlcnZpY2VQcm92aWRlciA9IGNvbnRhaW5lci5nZXRQcm92aWRlcignaGVhcnRiZWF0Jyk7XG4gICAgICAgIHJldHVybiBmYWN0b3J5KGFwcCwgaGVhcnRiZWF0U2VydmljZVByb3ZpZGVyKTtcbiAgICAgIH0sXG4gICAgICBDb21wb25lbnRUeXBlLlBVQkxJQ1xuICAgIClcbiAgICAgIC5zZXRJbnN0YW50aWF0aW9uTW9kZShJbnN0YW50aWF0aW9uTW9kZS5FWFBMSUNJVClcbiAgICAgIC8qKlxuICAgICAgICogSW5pdGlhbGl6ZSBhcHAtY2hlY2staW50ZXJuYWwgYWZ0ZXIgYXBwLWNoZWNrIGlzIGluaXRpYWxpemVkIHRvIG1ha2UgQXBwQ2hlY2sgYXZhaWxhYmxlIHRvXG4gICAgICAgKiBvdGhlciBGaXJlYmFzZSBTREtzXG4gICAgICAgKi9cbiAgICAgIC5zZXRJbnN0YW5jZUNyZWF0ZWRDYWxsYmFjayhcbiAgICAgICAgKGNvbnRhaW5lciwgX2lkZW50aWZpZXIsIF9hcHBjaGVja1NlcnZpY2UpID0+IHtcbiAgICAgICAgICBjb250YWluZXIuZ2V0UHJvdmlkZXIoQVBQX0NIRUNLX05BTUVfSU5URVJOQUwpLmluaXRpYWxpemUoKTtcbiAgICAgICAgfVxuICAgICAgKVxuICApO1xuXG4gIC8vIFRoZSBpbnRlcm5hbCBpbnRlcmZhY2UgdXNlZCBieSBvdGhlciBGaXJlYmFzZSBwcm9kdWN0c1xuICBfcmVnaXN0ZXJDb21wb25lbnQoXG4gICAgbmV3IENvbXBvbmVudChcbiAgICAgIEFQUF9DSEVDS19OQU1FX0lOVEVSTkFMLFxuICAgICAgY29udGFpbmVyID0+IHtcbiAgICAgICAgY29uc3QgYXBwQ2hlY2sgPSBjb250YWluZXIuZ2V0UHJvdmlkZXIoJ2FwcC1jaGVjaycpLmdldEltbWVkaWF0ZSgpO1xuICAgICAgICByZXR1cm4gaW50ZXJuYWxGYWN0b3J5KGFwcENoZWNrKTtcbiAgICAgIH0sXG4gICAgICBDb21wb25lbnRUeXBlLlBVQkxJQ1xuICAgICkuc2V0SW5zdGFudGlhdGlvbk1vZGUoSW5zdGFudGlhdGlvbk1vZGUuRVhQTElDSVQpXG4gICk7XG5cbiAgcmVnaXN0ZXJWZXJzaW9uKG5hbWUsIHZlcnNpb24pO1xufVxuXG5yZWdpc3RlckFwcENoZWNrKCk7XG4iXSwibmFtZXMiOlsiZ2V0VG9rZW4iLCJnZXRMaW1pdGVkVXNlVG9rZW4iLCJnZXRSZUNBUFRDSEFUb2tlbiIsImluaXRpYWxpemVSZWNhcHRjaGFWMyIsImluaXRpYWxpemVSZWNhcHRjaGFFbnRlcnByaXNlIiwiZ2V0VG9rZW5JbnRlcm5hbCIsImdldExpbWl0ZWRVc2VUb2tlbkludGVybmFsIl0sIm1hcHBpbmdzIjoiOzs7OztBQUFBOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztBQW9DSCxNQUFNLGdCQUFnQixHQUFHLElBQUksR0FBRyxFQUE4QjtBQUN2RCxNQUFNLGFBQWEsR0FBa0I7QUFDMUMsSUFBQSxTQUFTLEVBQUUsS0FBSztBQUNoQixJQUFBLGNBQWMsRUFBRTtDQUNqQjtBQUVELE1BQU0sV0FBVyxHQUFlO0FBQzlCLElBQUEsV0FBVyxFQUFFLEtBQUs7QUFDbEIsSUFBQSxPQUFPLEVBQUU7Q0FDVjtBQUVEOztBQUVHO0FBQ0csU0FBVSxpQkFBaUIsQ0FBQyxHQUFnQixFQUFBO0lBQ2hELE9BQU8sZ0JBQWdCLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsR0FBRyxhQUFhLEVBQUU7QUFDMUQ7QUFFQTs7O0FBR0c7QUFDRyxTQUFVLGVBQWUsQ0FDN0IsR0FBZ0IsRUFDaEIsS0FBb0IsRUFBQTtBQUVwQixJQUFBLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDO0FBQ2hDLElBQUEsT0FBTyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFrQjtBQUNuRDtTQVVnQixhQUFhLEdBQUE7QUFDM0IsSUFBQSxPQUFPLFdBQVc7QUFDcEI7O0FDM0ZBOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztBQUNJLE1BQU0sYUFBYSxHQUN4QixvREFBb0Q7QUFFL0MsTUFBTSwrQkFBK0IsR0FBRywwQkFBMEI7QUFDbEUsTUFBTSwwQ0FBMEMsR0FDckQsa0NBQWtDO0FBQzdCLE1BQU0sMkJBQTJCLEdBQUcsb0JBQW9CO0FBRXhELE1BQU0sa0JBQWtCLEdBQUc7QUFDaEMsSUFLQTs7O0FBR0c7SUFDSCxnQkFBZ0IsRUFBRSxFQUFFLEdBQUcsSUFBSTtBQUMzQjs7QUFFRztBQUNILElBQUEsZ0JBQWdCLEVBQUUsRUFBRSxHQUFHLEVBQUUsR0FBRztDQUM3QjtBQUVEOztBQUVHO0FBQ0ksTUFBTSxPQUFPLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsSUFBSTs7QUM1QzFDOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztBQUlIOzs7QUFHRztBQUNIO0FBQ0E7TUFDYSxTQUFTLENBQUE7SUFHcEIsV0FBQSxDQUNtQixTQUFpQyxFQUNqQyxXQUF3QyxFQUN4QyxlQUE2QixFQUM3QixVQUFrQixFQUNsQixVQUFrQixFQUFBO1FBSmxCLElBQUEsQ0FBQSxTQUFTLEdBQVQsU0FBUztRQUNULElBQUEsQ0FBQSxXQUFXLEdBQVgsV0FBVztRQUNYLElBQUEsQ0FBQSxlQUFlLEdBQWYsZUFBZTtRQUNmLElBQUEsQ0FBQSxVQUFVLEdBQVYsVUFBVTtRQUNWLElBQUEsQ0FBQSxVQUFVLEdBQVYsVUFBVTtRQVByQixJQUFBLENBQUEsT0FBTyxHQUE2QixJQUFJO0FBUzlDLFFBQUEsSUFBSSxDQUFDLHFCQUFxQixHQUFHLFVBQVU7QUFFdkMsUUFBQSxJQUFJLFVBQVUsR0FBRyxVQUFVLEVBQUU7QUFDM0IsWUFBQSxNQUFNLElBQUksS0FBSyxDQUNiLHlEQUF5RCxDQUMxRDtRQUNIO0lBQ0Y7SUFFQSxLQUFLLEdBQUE7QUFDSCxRQUFBLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUMsVUFBVTtRQUM1QyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFLOztBQUU5QixRQUFBLENBQUMsQ0FBQztJQUNKO0lBRUEsSUFBSSxHQUFBO0FBQ0YsUUFBQSxJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUU7QUFDaEIsWUFBQSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUM7QUFDaEMsWUFBQSxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUk7UUFDckI7SUFDRjtJQUVBLFNBQVMsR0FBQTtBQUNQLFFBQUEsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU87SUFDdkI7SUFFUSxNQUFNLE9BQU8sQ0FBQyxZQUFxQixFQUFBO1FBQ3pDLElBQUksQ0FBQyxJQUFJLEVBQUU7QUFDWCxRQUFBLElBQUk7QUFDRixZQUFBLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxRQUFRLEVBQUU7WUFDN0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUUsSUFBRzs7QUFFaEMsWUFBQSxDQUFDLENBQUM7WUFDRixNQUFNLEtBQUssQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDOzs7Ozs7QUFPMUMsWUFBQSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRTtBQUN0QixZQUFBLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPO0FBQzFCLFlBQUEsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLFFBQVEsRUFBRTtZQUM3QixJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRSxJQUFHOztBQUVoQyxZQUFBLENBQUMsQ0FBQztBQUNGLFlBQUEsTUFBTSxJQUFJLENBQUMsU0FBUyxFQUFFO0FBRXRCLFlBQUEsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUU7QUFDdEIsWUFBQSxNQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTztZQUUxQixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFLOztBQUU5QixZQUFBLENBQUMsQ0FBQztRQUNKO1FBQUUsT0FBTyxLQUFLLEVBQUU7QUFDZCxZQUFBLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsRUFBRTtnQkFDM0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBSzs7QUFFL0IsZ0JBQUEsQ0FBQyxDQUFDO1lBQ0o7aUJBQU87Z0JBQ0wsSUFBSSxDQUFDLElBQUksRUFBRTtZQUNiO1FBQ0Y7SUFDRjtBQUVRLElBQUEsVUFBVSxDQUFDLFlBQXFCLEVBQUE7UUFDdEMsSUFBSSxZQUFZLEVBQUU7OztBQUdoQixZQUFBLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLENBQUMsVUFBVTs7QUFFNUMsWUFBQSxPQUFPLElBQUksQ0FBQyxlQUFlLEVBQUU7UUFDL0I7YUFBTzs7QUFFTCxZQUFBLE1BQU0sd0JBQXdCLEdBQUcsSUFBSSxDQUFDLHFCQUFxQjs7QUFFM0QsWUFBQSxJQUFJLENBQUMscUJBQXFCLElBQUksQ0FBQzs7WUFFL0IsSUFBSSxJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLFVBQVUsRUFBRTtBQUNoRCxnQkFBQSxJQUFJLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLFVBQVU7WUFDOUM7QUFDQSxZQUFBLE9BQU8sd0JBQXdCO1FBQ2pDO0lBQ0Y7QUFDRDtBQUVELFNBQVMsS0FBSyxDQUFDLEVBQVUsRUFBQTtBQUN2QixJQUFBLE9BQU8sSUFBSSxPQUFPLENBQU8sT0FBTyxJQUFHO0FBQ2pDLFFBQUEsVUFBVSxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUM7QUFDekIsSUFBQSxDQUFDLENBQUM7QUFDSjs7QUM5SEE7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBa0JILE1BQU0sTUFBTSxHQUE0QjtBQUN0QyxJQUFBLENBQUEscUJBQUEsMkNBQ0UsK0VBQStFO1FBQy9FLDZFQUE2RTtRQUM3RSxzRUFBc0U7UUFDdEUsK0JBQStCO0FBQ2pDLElBQUEsQ0FBQSx1QkFBQSw2Q0FDRSw0RkFBNEY7UUFDNUYseUVBQXlFO0FBQzNFLElBQUEsQ0FBQSxxQkFBQSwyQ0FDRSxtRUFBbUU7UUFDbkUsMENBQTBDO0FBQzVDLElBQUEsQ0FBQSxtQkFBQSx5Q0FDRSx3Q0FBd0M7UUFDeEMsMkNBQTJDO0FBQzdDLElBQUEsQ0FBQSxvQkFBQSwwQ0FDRSx5RUFBeUU7QUFDM0UsSUFBQSxDQUFBLGNBQUEsb0NBQ0UsNkVBQTZFO0FBQy9FLElBQUEsQ0FBQSxhQUFBLG1DQUNFLGtGQUFrRjtBQUNwRixJQUFBLENBQUEsYUFBQSxxQ0FDRSxnRkFBZ0Y7QUFDbEYsSUFBQSxDQUFBLGlCQUFBLHVDQUFpQyxrQkFBa0I7QUFDbkQsSUFBQSxDQUFBLGtCQUFBLHdDQUFrQyxDQUFBLHlEQUFBLENBQTJEO0FBQzdGLElBQUEsQ0FBQSxXQUFBLGlDQUEyQixDQUFBLDRGQUFBO0NBQzVCO0FBZU0sTUFBTSxhQUFhLEdBQUcsSUFBSSxZQUFZLENBQzNDLFVBQVUsRUFDVixVQUFVLEVBQ1YsTUFBTSxDQUNQOztBQzlFRDs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUFPRyxTQUFVLFlBQVksQ0FDMUIsWUFBQSxHQUF3QixLQUFLLEVBQUE7SUFFN0IsSUFBSSxZQUFZLEVBQUU7QUFDaEIsUUFBQSxPQUFPLElBQUksQ0FBQyxVQUFVLEVBQUUsVUFBVTtJQUNwQztJQUNBLE9BQU8sSUFBSSxDQUFDLFVBQVU7QUFDeEI7QUFFTSxTQUFVLGVBQWUsQ0FBQyxHQUFnQixFQUFBO0lBQzlDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLEVBQUU7UUFDckMsTUFBTSxhQUFhLENBQUMsTUFBTSxDQUFBLHVCQUFBLDRDQUFzQztZQUM5RCxPQUFPLEVBQUUsR0FBRyxDQUFDO0FBQ2QsU0FBQSxDQUFDO0lBQ0o7QUFDRjtBQUVNLFNBQVUsaUJBQWlCLENBQUMsZ0JBQXdCLEVBQUE7SUFDeEQsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7QUFDeEQsSUFBQSxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDLENBQUM7QUFDbkQsSUFBQSxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsWUFBWSxHQUFHLElBQUksR0FBRyxJQUFJLEdBQUcsRUFBRSxJQUFJLElBQUksQ0FBQztJQUNsRSxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUN4QixDQUFDLFlBQVksR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLEVBQUUsR0FBRyxLQUFLLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FDdEQ7QUFDRCxJQUFBLE1BQU0sT0FBTyxHQUFHLFlBQVksR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLEVBQUUsR0FBRyxLQUFLLEdBQUcsSUFBSSxHQUFHLE9BQU8sR0FBRyxFQUFFO0lBRTdFLElBQUksTUFBTSxHQUFHLEVBQUU7SUFDZixJQUFJLElBQUksRUFBRTtBQUNSLFFBQUEsTUFBTSxJQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJO0lBQzVCO0lBQ0EsSUFBSSxLQUFLLEVBQUU7QUFDVCxRQUFBLE1BQU0sSUFBSSxHQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSTtJQUM3QjtBQUNBLElBQUEsTUFBTSxJQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsR0FBRyxJQUFJLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEdBQUc7QUFDbEQsSUFBQSxPQUFPLE1BQU07QUFDZjtBQUVBLFNBQVMsR0FBRyxDQUFDLEtBQWEsRUFBQTtBQUN4QixJQUFBLElBQUksS0FBSyxLQUFLLENBQUMsRUFBRTtBQUNmLFFBQUEsT0FBTyxJQUFJO0lBQ2I7QUFDQSxJQUFBLE9BQU8sS0FBSyxJQUFJLEVBQUUsR0FBRyxLQUFLLENBQUMsUUFBUSxFQUFFLEdBQUcsR0FBRyxHQUFHLEtBQUs7QUFDckQ7O0FDaEVBOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztBQTJCSSxlQUFlLGFBQWEsQ0FDakMsRUFBRSxHQUFHLEVBQUUsSUFBSSxFQUFtQixFQUM5Qix3QkFBK0MsRUFBQTtBQUUvQyxJQUFBLE1BQU0sT0FBTyxHQUFnQjtBQUMzQixRQUFBLGNBQWMsRUFBRTtLQUNqQjs7QUFFRCxJQUFBLE1BQU0sZ0JBQWdCLEdBQUcsd0JBQXdCLENBQUMsWUFBWSxDQUFDO0FBQzdELFFBQUEsUUFBUSxFQUFFO0FBQ1gsS0FBQSxDQUFDO0lBQ0YsSUFBSSxnQkFBZ0IsRUFBRTtBQUNwQixRQUFBLE1BQU0sZ0JBQWdCLEdBQUcsTUFBTSxnQkFBZ0IsQ0FBQyxtQkFBbUIsRUFBRTtRQUNyRSxJQUFJLGdCQUFnQixFQUFFO0FBQ3BCLFlBQUEsT0FBTyxDQUFDLG1CQUFtQixDQUFDLEdBQUcsZ0JBQWdCO1FBQ2pEO0lBQ0Y7QUFDQSxJQUFBLE1BQU0sT0FBTyxHQUFnQjtBQUMzQixRQUFBLE1BQU0sRUFBRSxNQUFNO0FBQ2QsUUFBQSxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7UUFDMUI7S0FDRDtBQUNELElBQUEsSUFBSSxRQUFRO0FBQ1osSUFBQSxJQUFJO1FBQ0YsUUFBUSxHQUFHLE1BQU0sS0FBSyxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUM7SUFDdEM7SUFBRSxPQUFPLGFBQWEsRUFBRTtRQUN0QixNQUFNLGFBQWEsQ0FBQyxNQUFNLENBQUEscUJBQUEsMENBQW9DO1lBQzVELG9CQUFvQixFQUFHLGFBQXVCLEVBQUU7QUFDakQsU0FBQSxDQUFDO0lBQ0o7QUFFQSxJQUFBLElBQUksUUFBUSxDQUFDLE1BQU0sS0FBSyxHQUFHLEVBQUU7UUFDM0IsTUFBTSxhQUFhLENBQUMsTUFBTSxDQUFBLG9CQUFBLHlDQUFtQztZQUMzRCxVQUFVLEVBQUUsUUFBUSxDQUFDO0FBQ3RCLFNBQUEsQ0FBQztJQUNKO0FBRUEsSUFBQSxJQUFJLFlBQThCO0FBQ2xDLElBQUEsSUFBSTs7QUFFRixRQUFBLFlBQVksR0FBRyxNQUFNLFFBQVEsQ0FBQyxJQUFJLEVBQUU7SUFDdEM7SUFBRSxPQUFPLGFBQWEsRUFBRTtRQUN0QixNQUFNLGFBQWEsQ0FBQyxNQUFNLENBQUEsbUJBQUEsd0NBQWtDO1lBQzFELG9CQUFvQixFQUFHLGFBQXVCLEVBQUU7QUFDakQsU0FBQSxDQUFDO0lBQ0o7OztJQUlBLE1BQU0sS0FBSyxHQUFHLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQztJQUNyRCxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtRQUNsRCxNQUFNLGFBQWEsQ0FBQyxNQUFNLENBQUEsbUJBQUEsd0NBQWtDO0FBQzFELFlBQUEsb0JBQW9CLEVBQ2xCLENBQUEsNERBQUEsQ0FBOEQ7Z0JBQzlELENBQUEsUUFBQSxFQUFXLFlBQVksQ0FBQyxHQUFHLENBQUE7QUFDOUIsU0FBQSxDQUFDO0lBQ0o7SUFDQSxNQUFNLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJO0FBRWxELElBQUEsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRTtJQUN0QixPQUFPO1FBQ0wsS0FBSyxFQUFFLFlBQVksQ0FBQyxLQUFLO1FBQ3pCLGdCQUFnQixFQUFFLEdBQUcsR0FBRyxrQkFBa0I7QUFDMUMsUUFBQSxrQkFBa0IsRUFBRTtLQUNyQjtBQUNIO0FBRU0sU0FBVSxrQ0FBa0MsQ0FDaEQsR0FBZ0IsRUFDaEIsY0FBc0IsRUFBQTtJQUV0QixNQUFNLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsR0FBRyxHQUFHLENBQUMsT0FBTztJQUVoRCxPQUFPO1FBQ0wsR0FBRyxFQUFFLENBQUEsRUFBRyxhQUFhLENBQUEsVUFBQSxFQUFhLFNBQVMsQ0FBQSxNQUFBLEVBQVMsS0FBSyxDQUFBLENBQUEsRUFBSSwrQkFBK0IsQ0FBQSxLQUFBLEVBQVEsTUFBTSxDQUFBLENBQUU7QUFDNUcsUUFBQSxJQUFJLEVBQUU7QUFDSixZQUFBLG9CQUFvQixFQUFFO0FBQ3ZCO0tBQ0Y7QUFDSDtBQUVNLFNBQVUsMENBQTBDLENBQ3hELEdBQWdCLEVBQ2hCLGNBQXNCLEVBQUE7SUFFdEIsTUFBTSxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFDLE9BQU87SUFFaEQsT0FBTztRQUNMLEdBQUcsRUFBRSxDQUFBLEVBQUcsYUFBYSxDQUFBLFVBQUEsRUFBYSxTQUFTLENBQUEsTUFBQSxFQUFTLEtBQUssQ0FBQSxDQUFBLEVBQUksMENBQTBDLENBQUEsS0FBQSxFQUFRLE1BQU0sQ0FBQSxDQUFFO0FBQ3ZILFFBQUEsSUFBSSxFQUFFO0FBQ0osWUFBQSw0QkFBNEIsRUFBRTtBQUMvQjtLQUNGO0FBQ0g7QUFFTSxTQUFVLDRCQUE0QixDQUMxQyxHQUFnQixFQUNoQixVQUFrQixFQUFBO0lBRWxCLE1BQU0sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxPQUFPO0lBRWhELE9BQU87UUFDTCxHQUFHLEVBQUUsQ0FBQSxFQUFHLGFBQWEsQ0FBQSxVQUFBLEVBQWEsU0FBUyxDQUFBLE1BQUEsRUFBUyxLQUFLLENBQUEsQ0FBQSxFQUFJLDJCQUEyQixDQUFBLEtBQUEsRUFBUSxNQUFNLENBQUEsQ0FBRTtBQUN4RyxRQUFBLElBQUksRUFBRTs7QUFFSixZQUFBLFdBQVcsRUFBRTtBQUNkO0tBQ0Y7QUFDSDs7QUN0SkE7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBS0gsTUFBTSxPQUFPLEdBQUcsNkJBQTZCO0FBQzdDLE1BQU0sVUFBVSxHQUFHLENBQUM7QUFDcEIsTUFBTSxVQUFVLEdBQUcsMEJBQTBCO0FBQzdDLE1BQU0sZUFBZSxHQUFHLGFBQWE7QUFFckMsSUFBSSxTQUFTLEdBQWdDLElBQUk7QUFDakQsU0FBUyxZQUFZLEdBQUE7SUFDbkIsSUFBSSxTQUFTLEVBQUU7QUFDYixRQUFBLE9BQU8sU0FBUztJQUNsQjtJQUVBLFNBQVMsR0FBRyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxNQUFNLEtBQUk7QUFDMUMsUUFBQSxJQUFJO1lBQ0YsTUFBTSxPQUFPLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDO0FBRW5ELFlBQUEsT0FBTyxDQUFDLFNBQVMsR0FBRyxLQUFLLElBQUc7QUFDMUIsZ0JBQUEsT0FBTyxDQUFFLEtBQUssQ0FBQyxNQUEyQixDQUFDLE1BQU0sQ0FBQztBQUNwRCxZQUFBLENBQUM7QUFFRCxZQUFBLE9BQU8sQ0FBQyxPQUFPLEdBQUcsS0FBSyxJQUFHO0FBQ3hCLGdCQUFBLE1BQU0sQ0FDSixhQUFhLENBQUMsTUFBTSxDQUFBLGNBQUEsbUNBQTZCO0FBQy9DLG9CQUFBLG9CQUFvQixFQUFHLEtBQUssQ0FBQyxNQUFxQixDQUFDLEtBQUssRUFBRTtBQUMzRCxpQkFBQSxDQUFDLENBQ0g7QUFDSCxZQUFBLENBQUM7QUFFRCxZQUFBLE9BQU8sQ0FBQyxlQUFlLEdBQUcsS0FBSyxJQUFHO0FBQ2hDLGdCQUFBLE1BQU0sRUFBRSxHQUFJLEtBQUssQ0FBQyxNQUEyQixDQUFDLE1BQU07Ozs7OztBQU9wRCxnQkFBQSxRQUFRLEtBQUssQ0FBQyxVQUFVO0FBQ3RCLG9CQUFBLEtBQUssQ0FBQztBQUNKLHdCQUFBLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLEVBQUU7QUFDL0IsNEJBQUEsT0FBTyxFQUFFO0FBQ1YseUJBQUEsQ0FBQzs7QUFFUixZQUFBLENBQUM7UUFDSDtRQUFFLE9BQU8sQ0FBQyxFQUFFO0FBQ1YsWUFBQSxNQUFNLENBQ0osYUFBYSxDQUFDLE1BQU0sQ0FBQSxjQUFBLG1DQUE2QjtnQkFDL0Msb0JBQW9CLEVBQUcsQ0FBVyxFQUFFO0FBQ3JDLGFBQUEsQ0FBQyxDQUNIO1FBQ0g7QUFDRixJQUFBLENBQUMsQ0FBQztBQUVGLElBQUEsT0FBTyxTQUFTO0FBQ2xCO0FBRU0sU0FBVSxzQkFBc0IsQ0FDcEMsR0FBZ0IsRUFBQTtBQUVoQixJQUFBLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBK0M7QUFDNUU7QUFFTSxTQUFVLHFCQUFxQixDQUNuQyxHQUFnQixFQUNoQixLQUE2QixFQUFBO0lBRTdCLE9BQU8sS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRSxLQUFLLENBQUM7QUFDdEM7QUFFTSxTQUFVLDBCQUEwQixDQUFDLEtBQWEsRUFBQTtBQUN0RCxJQUFBLE9BQU8sS0FBSyxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUM7QUFDdEM7U0FFZ0IsMkJBQTJCLEdBQUE7QUFDekMsSUFBQSxPQUFPLElBQUksQ0FBQyxlQUFlLENBQWdDO0FBQzdEO0FBRUEsZUFBZSxLQUFLLENBQUMsR0FBVyxFQUFFLEtBQWMsRUFBQTtBQUM5QyxJQUFBLE1BQU0sRUFBRSxHQUFHLE1BQU0sWUFBWSxFQUFFO0lBRS9CLE1BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLFdBQVcsQ0FBQztJQUMzRCxNQUFNLEtBQUssR0FBRyxXQUFXLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQztBQUNqRCxJQUFBLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDeEIsUUFBQSxZQUFZLEVBQUUsR0FBRztRQUNqQjtBQUNELEtBQUEsQ0FBQztJQUVGLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxLQUFJO0FBQ3JDLFFBQUEsT0FBTyxDQUFDLFNBQVMsR0FBRyxNQUFNLElBQUc7QUFDM0IsWUFBQSxPQUFPLEVBQUU7QUFDWCxRQUFBLENBQUM7QUFFRCxRQUFBLFdBQVcsQ0FBQyxPQUFPLEdBQUcsS0FBSyxJQUFHO0FBQzVCLFlBQUEsTUFBTSxDQUNKLGFBQWEsQ0FBQyxNQUFNLENBQUEsYUFBQSxvQ0FBOEI7QUFDaEQsZ0JBQUEsb0JBQW9CLEVBQUcsS0FBSyxDQUFDLE1BQXFCLENBQUMsS0FBSyxFQUFFO0FBQzNELGFBQUEsQ0FBQyxDQUNIO0FBQ0gsUUFBQSxDQUFDO0FBQ0gsSUFBQSxDQUFDLENBQUM7QUFDSjtBQUVBLGVBQWUsSUFBSSxDQUFDLEdBQVcsRUFBQTtBQUM3QixJQUFBLE1BQU0sRUFBRSxHQUFHLE1BQU0sWUFBWSxFQUFFO0lBRS9CLE1BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQztJQUMxRCxNQUFNLEtBQUssR0FBRyxXQUFXLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQztJQUNqRCxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztJQUU5QixPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sS0FBSTtBQUNyQyxRQUFBLE9BQU8sQ0FBQyxTQUFTLEdBQUcsS0FBSyxJQUFHO0FBQzFCLFlBQUEsTUFBTSxNQUFNLEdBQUksS0FBSyxDQUFDLE1BQXFCLENBQUMsTUFBTTtZQUVsRCxJQUFJLE1BQU0sRUFBRTtBQUNWLGdCQUFBLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1lBQ3ZCO2lCQUFPO2dCQUNMLE9BQU8sQ0FBQyxTQUFTLENBQUM7WUFDcEI7QUFDRixRQUFBLENBQUM7QUFFRCxRQUFBLFdBQVcsQ0FBQyxPQUFPLEdBQUcsS0FBSyxJQUFHO0FBQzVCLFlBQUEsTUFBTSxDQUNKLGFBQWEsQ0FBQyxNQUFNLENBQUEsYUFBQSxrQ0FBNEI7QUFDOUMsZ0JBQUEsb0JBQW9CLEVBQUcsS0FBSyxDQUFDLE1BQXFCLENBQUMsS0FBSyxFQUFFO0FBQzNELGFBQUEsQ0FBQyxDQUNIO0FBQ0gsUUFBQSxDQUFDO0FBQ0gsSUFBQSxDQUFDLENBQUM7QUFDSjtBQUVBLFNBQVMsVUFBVSxDQUFDLEdBQWdCLEVBQUE7SUFDbEMsT0FBTyxDQUFBLEVBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUEsQ0FBQSxFQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUEsQ0FBRTtBQUMzQzs7QUN0SkE7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBSUksTUFBTSxNQUFNLEdBQUcsSUFBSSxNQUFNLENBQUMscUJBQXFCLENBQUM7O0FDbkJ2RDs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUFhSDs7QUFFRztBQUNJLGVBQWUsb0JBQW9CLENBQ3hDLEdBQWdCLEVBQUE7SUFFaEIsSUFBSSxvQkFBb0IsRUFBRSxFQUFFO1FBQzFCLElBQUksS0FBSyxHQUFHLFNBQVM7QUFDckIsUUFBQSxJQUFJO0FBQ0YsWUFBQSxLQUFLLEdBQUcsTUFBTSxzQkFBc0IsQ0FBQyxHQUFHLENBQUM7UUFDM0M7UUFBRSxPQUFPLENBQUMsRUFBRTs7QUFFVixZQUFBLE1BQU0sQ0FBQyxJQUFJLENBQUMsK0NBQStDLENBQUMsQ0FBQSxDQUFFLENBQUM7UUFDakU7QUFDQSxRQUFBLE9BQU8sS0FBSztJQUNkO0FBRUEsSUFBQSxPQUFPLFNBQVM7QUFDbEI7QUFFQTs7QUFFRztBQUNHLFNBQVUsbUJBQW1CLENBQ2pDLEdBQWdCLEVBQ2hCLEtBQTZCLEVBQUE7SUFFN0IsSUFBSSxvQkFBb0IsRUFBRSxFQUFFO1FBQzFCLE9BQU8scUJBQXFCLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUc7O0FBRWpELFlBQUEsTUFBTSxDQUFDLElBQUksQ0FBQyw4Q0FBOEMsQ0FBQyxDQUFBLENBQUUsQ0FBQztBQUNoRSxRQUFBLENBQUMsQ0FBQztJQUNKO0FBRUEsSUFBQSxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUU7QUFDMUI7QUFFTyxlQUFlLGlDQUFpQyxHQUFBO0FBQ3JEOzs7QUFHRztJQUNILElBQUksa0JBQWtCLEdBQXVCLFNBQVM7QUFDdEQsSUFBQSxJQUFJO0FBQ0YsUUFBQSxrQkFBa0IsR0FBRyxNQUFNLDJCQUEyQixFQUFFO0lBQzFEO0lBQUUsT0FBTyxFQUFFLEVBQUU7O0lBRWI7SUFFQSxJQUFJLENBQUMsa0JBQWtCLEVBQUU7OztBQUd2QixRQUFBLE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxVQUFVLEVBQUU7Ozs7OztBQU1wQyxRQUFBLDBCQUEwQixDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQzFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQSxtREFBQSxFQUFzRCxDQUFDLENBQUEsQ0FBRSxDQUFDLENBQ3ZFO0FBQ0QsUUFBQSxPQUFPLFFBQVE7SUFDakI7U0FBTztBQUNMLFFBQUEsT0FBTyxrQkFBa0I7SUFDM0I7QUFDRjs7QUM3RkE7Ozs7Ozs7Ozs7Ozs7OztBQWVHO1NBYWEsV0FBVyxHQUFBO0FBQ3pCLElBQUEsTUFBTSxVQUFVLEdBQUcsYUFBYSxFQUFFO0lBQ2xDLE9BQU8sVUFBVSxDQUFDLE9BQU87QUFDM0I7QUFFTyxlQUFlLGFBQWEsR0FBQTtBQUNqQyxJQUFBLE1BQU0sS0FBSyxHQUFHLGFBQWEsRUFBRTtJQUU3QixJQUFJLEtBQUssQ0FBQyxPQUFPLElBQUksS0FBSyxDQUFDLEtBQUssRUFBRTtBQUNoQyxRQUFBLE9BQU8sS0FBSyxDQUFDLEtBQUssQ0FBQyxPQUFPO0lBQzVCO1NBQU87O0FBRUwsUUFBQSxNQUFNLEtBQUssQ0FBQzs7QUFFUCxRQUFBLENBQUEsQ0FBQztJQUNSO0FBQ0Y7U0FFZ0IsbUJBQW1CLEdBQUE7QUFDakMsSUFBQSxNQUFNLE9BQU8sR0FBRyxTQUFTLEVBQUU7QUFDM0IsSUFBQSxNQUFNLFVBQVUsR0FBRyxhQUFhLEVBQUU7OztBQUdsQyxJQUFBLFVBQVUsQ0FBQyxXQUFXLEdBQUcsSUFBSTtBQUU3QixJQUFBLElBQ0UsT0FBTyxPQUFPLENBQUMsNkJBQTZCLEtBQUssUUFBUTtBQUN6RCxRQUFBLE9BQU8sQ0FBQyw2QkFBNkIsS0FBSyxJQUFJLEVBQzlDO1FBQ0E7SUFDRjtBQUVBLElBQUEsVUFBVSxDQUFDLE9BQU8sR0FBRyxJQUFJO0FBQ3pCLElBQUEsTUFBTSxhQUFhLEdBQUcsSUFBSSxRQUFRLEVBQVU7QUFDNUMsSUFBQSxVQUFVLENBQUMsS0FBSyxHQUFHLGFBQWE7QUFFaEMsSUFBQSxJQUFJLE9BQU8sT0FBTyxDQUFDLDZCQUE2QixLQUFLLFFBQVEsRUFBRTtBQUM3RCxRQUFBLGFBQWEsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLDZCQUE2QixDQUFDO0lBQzlEO1NBQU87QUFDTCxRQUFBLGFBQWEsQ0FBQyxPQUFPLENBQUMsaUNBQWlDLEVBQUUsQ0FBQztJQUM1RDtBQUNGOztBQ3JFQTs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUFzQkg7QUFDQTtBQUNPLE1BQU0scUJBQXFCLEdBQUcsRUFBRSxLQUFLLEVBQUUsZUFBZSxFQUFFO0FBRS9EOzs7O0FBSUc7QUFDRyxTQUFVLGdCQUFnQixDQUM5QixjQUFzQyxFQUFBO0lBRXRDLE9BQU8sTUFBTSxDQUFDLFlBQVksQ0FDeEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUM7bUJBQ2YsS0FBSyxDQUNyQjtBQUNIO0FBRUE7Ozs7QUFJRztBQUNJLGVBQWVBLFVBQVEsQ0FDNUIsUUFBeUIsRUFDekIsWUFBWSxHQUFHLEtBQUssRUFDcEIsZUFBZSxHQUFHLEtBQUssRUFBQTtBQUV2QixJQUFBLE1BQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQyxHQUFHO0lBQ3hCLGVBQWUsQ0FBQyxHQUFHLENBQUM7QUFFcEIsSUFBQSxNQUFNLEtBQUssR0FBRyxpQkFBaUIsQ0FBQyxHQUFHLENBQUM7QUFFcEM7O0FBRUc7QUFDSCxJQUFBLElBQUksS0FBSyxHQUFzQyxLQUFLLENBQUMsS0FBSztJQUMxRCxJQUFJLEtBQUssR0FBc0IsU0FBUztBQUV4Qzs7O0FBR0c7SUFDSCxJQUFJLEtBQUssSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsRUFBRTtBQUM1QixRQUFBLEtBQUssQ0FBQyxLQUFLLEdBQUcsU0FBUztRQUN2QixLQUFLLEdBQUcsU0FBUztJQUNuQjtBQUVBOztBQUVHO0lBQ0gsSUFBSSxDQUFDLEtBQUssRUFBRTs7QUFFVixRQUFBLE1BQU0sV0FBVyxHQUFHLE1BQU0sS0FBSyxDQUFDLGtCQUFrQjtRQUNsRCxJQUFJLFdBQVcsRUFBRTtBQUNmLFlBQUEsSUFBSSxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7Z0JBQ3hCLEtBQUssR0FBRyxXQUFXO1lBQ3JCO2lCQUFPOztBQUVMLGdCQUFBLE1BQU0sbUJBQW1CLENBQUMsR0FBRyxFQUFFLFNBQVMsQ0FBQztZQUMzQztRQUNGO0lBQ0Y7O0lBR0EsSUFBSSxDQUFDLFlBQVksSUFBSSxLQUFLLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxFQUFFO1FBQzVDLE9BQU87WUFDTCxLQUFLLEVBQUUsS0FBSyxDQUFDO1NBQ2Q7SUFDSDs7OztJQUtBLElBQUksbUJBQW1CLEdBQUcsS0FBSztBQUUvQjs7OztBQUlHO0lBQ0gsSUFBSSxXQUFXLEVBQUUsRUFBRTtBQUNqQixRQUFBLElBQUk7QUFDRixZQUFBLE1BQU0sVUFBVSxHQUFHLE1BQU0sYUFBYSxFQUFFOztBQUV4QyxZQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsb0JBQW9CLEVBQUU7Z0JBQy9CLEtBQUssQ0FBQyxvQkFBb0IsR0FBRyxhQUFhLENBQ3hDLDRCQUE0QixDQUFDLEdBQUcsRUFBRSxVQUFVLENBQUMsRUFDN0MsUUFBUSxDQUFDLHdCQUF3QixDQUNsQyxDQUFDLE9BQU8sQ0FBQyxNQUFLOztBQUViLG9CQUFBLEtBQUssQ0FBQyxvQkFBb0IsR0FBRyxTQUFTO0FBQ3hDLGdCQUFBLENBQUMsQ0FBQztnQkFDRixtQkFBbUIsR0FBRyxJQUFJO1lBQzVCO0FBQ0EsWUFBQSxNQUFNLHNCQUFzQixHQUMxQixNQUFNLEtBQUssQ0FBQyxvQkFBb0I7O0FBRWxDLFlBQUEsTUFBTSxtQkFBbUIsQ0FBQyxHQUFHLEVBQUUsc0JBQXNCLENBQUM7O0FBRXRELFlBQUEsS0FBSyxDQUFDLEtBQUssR0FBRyxzQkFBc0I7QUFDcEMsWUFBQSxPQUFPLEVBQUUsS0FBSyxFQUFFLHNCQUFzQixDQUFDLEtBQUssRUFBRTtRQUNoRDtRQUFFLE9BQU8sQ0FBQyxFQUFFO0FBQ1YsWUFBQSxJQUNHLENBQW1CLENBQUMsSUFBSSxLQUFLLENBQUEsU0FBQSxFQUFZLDBDQUF1QixDQUFFO0FBQ2xFLGdCQUFBLENBQW1CLENBQUMsSUFBSTtvQkFDdkIsQ0FBQSxTQUFBLEVBQVksa0JBQUEsc0NBQThCLENBQUUsRUFDOUM7O0FBRUEsZ0JBQUEsTUFBTSxDQUFDLElBQUksQ0FBRSxDQUFtQixDQUFDLE9BQU8sQ0FBQztZQUMzQztpQkFBTyxJQUFJLGVBQWUsRUFBRTtBQUMxQixnQkFBQSxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUNqQjs7QUFFQSxZQUFBLE9BQU8sb0JBQW9CLENBQUMsQ0FBa0IsQ0FBQztRQUNqRDtJQUNGO0FBRUE7Ozs7QUFJRztBQUNILElBQUEsSUFBSTs7QUFFRixRQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsb0JBQW9CLEVBQUU7Ozs7QUFJL0IsWUFBQSxLQUFLLENBQUMsb0JBQW9CLEdBQUcsS0FBSyxDQUFDLFFBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLENBQUMsTUFBSzs7QUFFbkUsZ0JBQUEsS0FBSyxDQUFDLG9CQUFvQixHQUFHLFNBQVM7QUFDeEMsWUFBQSxDQUFDLENBQUM7WUFDRixtQkFBbUIsR0FBRyxJQUFJO1FBQzVCO1FBQ0EsS0FBSyxHQUFHLE1BQU0saUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsb0JBQW9CO0lBQzNEO0lBQUUsT0FBTyxDQUFDLEVBQUU7QUFDVixRQUFBLElBQ0csQ0FBbUIsQ0FBQyxJQUFJLEtBQUssQ0FBQSxTQUFBLEVBQVksMENBQXVCLENBQUU7QUFDbEUsWUFBQSxDQUFtQixDQUFDLElBQUksS0FBSyxZQUFZLGtCQUFBLHNDQUE4QixDQUFFLEVBQzFFOztBQUVBLFlBQUEsTUFBTSxDQUFDLElBQUksQ0FBRSxDQUFtQixDQUFDLE9BQU8sQ0FBQztRQUMzQzthQUFPLElBQUksZUFBZSxFQUFFO0FBQzFCLFlBQUEsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDakI7O1FBRUEsS0FBSyxHQUFHLENBQWtCO0lBQzVCO0FBRUEsSUFBQSxJQUFJLGtCQUFtRDtJQUN2RCxJQUFJLENBQUMsS0FBSyxFQUFFOzs7QUFHVixRQUFBLGtCQUFrQixHQUFHLG9CQUFvQixDQUFDLEtBQU0sQ0FBQztJQUNuRDtTQUFPLElBQUksS0FBSyxFQUFFO0FBQ2hCLFFBQUEsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUFDLEVBQUU7Ozs7Ozs7O0FBUWxCLFlBQUEsa0JBQWtCLEdBQUc7Z0JBQ25CLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSztBQUNsQixnQkFBQSxhQUFhLEVBQUU7YUFDaEI7UUFDSDthQUFPOzs7QUFHTCxZQUFBLGtCQUFrQixHQUFHLG9CQUFvQixDQUFDLEtBQU0sQ0FBQztRQUNuRDtJQUNGO1NBQU87QUFDTCxRQUFBLGtCQUFrQixHQUFHO1lBQ25CLEtBQUssRUFBRSxLQUFLLENBQUM7U0FDZDs7O0FBR0QsUUFBQSxLQUFLLENBQUMsS0FBSyxHQUFHLEtBQUs7QUFDbkIsUUFBQSxNQUFNLG1CQUFtQixDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUM7SUFDdkM7SUFFQSxJQUFJLG1CQUFtQixFQUFFO0FBQ3ZCLFFBQUEsb0JBQW9CLENBQUMsR0FBRyxFQUFFLGtCQUFrQixDQUFDO0lBQy9DO0FBQ0EsSUFBQSxPQUFPLGtCQUFrQjtBQUMzQjtBQUVBOzs7QUFHRztBQUNJLGVBQWVDLG9CQUFrQixDQUN0QyxRQUF5QixFQUFBO0FBRXpCLElBQUEsTUFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDLEdBQUc7SUFDeEIsZUFBZSxDQUFDLEdBQUcsQ0FBQztJQUVwQixNQUFNLEVBQUUsUUFBUSxFQUFFLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxDQUFDO0lBRTNDLElBQUksV0FBVyxFQUFFLEVBQUU7QUFDakIsUUFBQSxNQUFNLFVBQVUsR0FBRyxNQUFNLGFBQWEsRUFBRTtRQUN4QyxNQUFNLE9BQU8sR0FBRyw0QkFBNEIsQ0FBQyxHQUFHLEVBQUUsVUFBVSxDQUFDO0FBQzdELFFBQUEsT0FBTyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxJQUFJO0FBQ2xDLFFBQUEsTUFBTSxFQUFFLEtBQUssRUFBRSxHQUFHLE1BQU0sYUFBYSxDQUNuQyxPQUFPLEVBQ1AsUUFBUSxDQUFDLHdCQUF3QixDQUNsQztRQUNELE9BQU8sRUFBRSxLQUFLLEVBQUU7SUFDbEI7U0FBTzs7QUFFTCxRQUFBLE1BQU0sRUFBRSxLQUFLLEVBQUUsR0FBRyxNQUFNLFFBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxvQkFBb0I7UUFDbkUsT0FBTyxFQUFFLEtBQUssRUFBRTtJQUNsQjtBQUNGO0FBRU0sU0FBVSxnQkFBZ0IsQ0FDOUIsUUFBeUIsRUFDekIsSUFBa0IsRUFDbEIsUUFBK0IsRUFDL0IsT0FBZ0MsRUFBQTtBQUVoQyxJQUFBLE1BQU0sRUFBRSxHQUFHLEVBQUUsR0FBRyxRQUFRO0FBQ3hCLElBQUEsTUFBTSxLQUFLLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxDQUFDO0FBQ3BDLElBQUEsTUFBTSxhQUFhLEdBQTBCO0FBQzNDLFFBQUEsSUFBSSxFQUFFLFFBQVE7QUFDZCxRQUFBLEtBQUssRUFBRSxPQUFPO1FBQ2Q7S0FDRDtJQUNELEtBQUssQ0FBQyxjQUFjLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQyxjQUFjLEVBQUUsYUFBYSxDQUFDOzs7SUFJL0QsSUFBSSxLQUFLLENBQUMsS0FBSyxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUU7QUFDdkMsUUFBQSxNQUFNLFVBQVUsR0FBRyxLQUFLLENBQUMsS0FBSztRQUM5QixPQUFPLENBQUMsT0FBTzthQUNaLElBQUksQ0FBQyxNQUFLO1lBQ1QsUUFBUSxDQUFDLEVBQUUsS0FBSyxFQUFFLFVBQVUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNyQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUM7QUFDOUIsUUFBQSxDQUFDO2FBQ0EsS0FBSyxDQUFDLE1BQUs7O0FBRVosUUFBQSxDQUFDLENBQUM7SUFDTjtBQUVBOzs7Ozs7OztBQVFHOztBQUdILElBQUEsS0FBSyxLQUFLLENBQUMsa0JBQW1CLENBQUMsSUFBSSxDQUFDLE1BQU0sa0JBQWtCLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDekU7QUFFTSxTQUFVLG1CQUFtQixDQUNqQyxHQUFnQixFQUNoQixRQUErQixFQUFBO0FBRS9CLElBQUEsTUFBTSxLQUFLLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxDQUFDO0FBRXBDLElBQUEsTUFBTSxZQUFZLEdBQUcsS0FBSyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQzlDLGFBQWEsSUFBSSxhQUFhLENBQUMsSUFBSSxLQUFLLFFBQVEsQ0FDakQ7QUFDRCxJQUFBLElBQ0UsWUFBWSxDQUFDLE1BQU0sS0FBSyxDQUFDO0FBQ3pCLFFBQUEsS0FBSyxDQUFDLGNBQWM7QUFDcEIsUUFBQSxLQUFLLENBQUMsY0FBYyxDQUFDLFNBQVMsRUFBRSxFQUNoQztBQUNBLFFBQUEsS0FBSyxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUU7SUFDN0I7QUFFQSxJQUFBLEtBQUssQ0FBQyxjQUFjLEdBQUcsWUFBWTtBQUNyQztBQUVBOztBQUVHO0FBQ0gsU0FBUyxrQkFBa0IsQ0FBQyxRQUF5QixFQUFBO0FBQ25ELElBQUEsTUFBTSxFQUFFLEdBQUcsRUFBRSxHQUFHLFFBQVE7QUFDeEIsSUFBQSxNQUFNLEtBQUssR0FBRyxpQkFBaUIsQ0FBQyxHQUFHLENBQUM7OztBQUdwQyxJQUFBLElBQUksU0FBUyxHQUEwQixLQUFLLENBQUMsY0FBYztJQUMzRCxJQUFJLENBQUMsU0FBUyxFQUFFO0FBQ2QsUUFBQSxTQUFTLEdBQUcsb0JBQW9CLENBQUMsUUFBUSxDQUFDO0FBQzFDLFFBQUEsS0FBSyxDQUFDLGNBQWMsR0FBRyxTQUFTO0lBQ2xDO0lBQ0EsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxLQUFLLENBQUMseUJBQXlCLEVBQUU7UUFDN0QsU0FBUyxDQUFDLEtBQUssRUFBRTtJQUNuQjtBQUNGO0FBRUEsU0FBUyxvQkFBb0IsQ0FBQyxRQUF5QixFQUFBO0FBQ3JELElBQUEsTUFBTSxFQUFFLEdBQUcsRUFBRSxHQUFHLFFBQVE7QUFDeEIsSUFBQSxPQUFPLElBQUksU0FBUzs7O0FBR2xCLElBQUEsWUFBVztBQUNULFFBQUEsTUFBTSxLQUFLLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxDQUFDOzs7QUFHcEMsUUFBQSxJQUFJLE1BQU07QUFDVixRQUFBLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFO0FBQ2hCLFlBQUEsTUFBTSxHQUFHLE1BQU1ELFVBQVEsQ0FBQyxRQUFRLENBQUM7UUFDbkM7YUFBTztZQUNMLE1BQU0sR0FBRyxNQUFNQSxVQUFRLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQztRQUN6QztBQUVBOzs7QUFHRztBQUNILFFBQUEsSUFBSSxNQUFNLENBQUMsS0FBSyxFQUFFO1lBQ2hCLE1BQU0sTUFBTSxDQUFDLEtBQUs7UUFDcEI7QUFDQTs7Ozs7OztBQU9HO0FBQ0gsUUFBQSxJQUFJLE1BQU0sQ0FBQyxhQUFhLEVBQUU7WUFDeEIsTUFBTSxNQUFNLENBQUMsYUFBYTtRQUM1QjtJQUNGLENBQUMsRUFDRCxNQUFLO0FBQ0gsUUFBQSxPQUFPLElBQUk7SUFDYixDQUFDLEVBQ0QsTUFBSztBQUNILFFBQUEsTUFBTSxLQUFLLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxDQUFDO0FBRXBDLFFBQUEsSUFBSSxLQUFLLENBQUMsS0FBSyxFQUFFOztBQUVmLFlBQUEsSUFBSSxxQkFBcUIsR0FDdkIsS0FBSyxDQUFDLEtBQUssQ0FBQyxrQkFBa0I7Z0JBQzlCLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLGtCQUFrQjtvQkFDNUQsR0FBRztBQUNMLGdCQUFBLENBQUMsR0FBRyxFQUFFLEdBQUcsSUFBSTs7QUFFZixZQUFBLE1BQU0sc0JBQXNCLEdBQzFCLEtBQUssQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxJQUFJO1lBQzlDLHFCQUFxQixHQUFHLElBQUksQ0FBQyxHQUFHLENBQzlCLHFCQUFxQixFQUNyQixzQkFBc0IsQ0FDdkI7QUFDRCxZQUFBLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUscUJBQXFCLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ3hEO2FBQU87QUFDTCxZQUFBLE9BQU8sQ0FBQztRQUNWO0lBQ0YsQ0FBQyxFQUNELGtCQUFrQixDQUFDLGdCQUFnQixFQUNuQyxrQkFBa0IsQ0FBQyxnQkFBZ0IsQ0FDcEM7QUFDSDtBQUVNLFNBQVUsb0JBQW9CLENBQ2xDLEdBQWdCLEVBQ2hCLEtBQTBCLEVBQUE7SUFFMUIsTUFBTSxTQUFTLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsY0FBYztBQUV2RCxJQUFBLEtBQUssTUFBTSxRQUFRLElBQUksU0FBUyxFQUFFO0FBQ2hDLFFBQUEsSUFBSTtZQUNGLElBQUksUUFBUSxDQUFDLElBQUksS0FBQSxVQUFBLGdDQUE4QixLQUFLLENBQUMsS0FBSyxJQUFJLElBQUksRUFBRTs7OztBQUlsRSxnQkFBQSxRQUFRLENBQUMsS0FBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7WUFDOUI7aUJBQU87Ozs7QUFJTCxnQkFBQSxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUN0QjtRQUNGO1FBQUUsT0FBTyxDQUFDLEVBQUU7O1FBRVo7SUFDRjtBQUNGO0FBRU0sU0FBVSxPQUFPLENBQUMsS0FBNEIsRUFBQTtJQUNsRCxPQUFPLEtBQUssQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztBQUNoRDtBQUVBLFNBQVMsb0JBQW9CLENBQUMsS0FBWSxFQUFBO0lBQ3hDLE9BQU87QUFDTCxRQUFBLEtBQUssRUFBRSxnQkFBZ0IsQ0FBQyxxQkFBcUIsQ0FBQztRQUM5QztLQUNEO0FBQ0g7O0FDbGJBOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztBQWNIOztBQUVHO01BQ1UsZUFBZSxDQUFBO0lBQzFCLFdBQUEsQ0FDUyxHQUFnQixFQUNoQix3QkFBK0MsRUFBQTtRQUQvQyxJQUFBLENBQUEsR0FBRyxHQUFILEdBQUc7UUFDSCxJQUFBLENBQUEsd0JBQXdCLEdBQXhCLHdCQUF3QjtJQUM5QjtJQUNILE9BQU8sR0FBQTtRQUNMLE1BQU0sRUFBRSxjQUFjLEVBQUUsR0FBRyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQ3RELFFBQUEsS0FBSyxNQUFNLGFBQWEsSUFBSSxjQUFjLEVBQUU7WUFDMUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxhQUFhLENBQUMsSUFBSSxDQUFDO1FBQ25EO0FBQ0EsUUFBQSxPQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUU7SUFDMUI7QUFDRDtBQUVLLFNBQVUsT0FBTyxDQUNyQixHQUFnQixFQUNoQix3QkFBK0MsRUFBQTtBQUUvQyxJQUFBLE9BQU8sSUFBSSxlQUFlLENBQUMsR0FBRyxFQUFFLHdCQUF3QixDQUFDO0FBQzNEO0FBRU0sU0FBVSxlQUFlLENBQzdCLFFBQXlCLEVBQUE7SUFFekIsT0FBTztRQUNMLFFBQVEsRUFBRSxZQUFZLElBQUlBLFVBQVEsQ0FBQyxRQUFRLEVBQUUsWUFBWSxDQUFDO0FBQzFELFFBQUEsa0JBQWtCLEVBQUUsTUFBTUMsb0JBQWtCLENBQUMsUUFBUSxDQUFDO1FBQ3RELGdCQUFnQixFQUFFLFFBQVEsSUFDeEIsZ0JBQWdCLENBQUMsUUFBUSxFQUFBLFVBQUEsOEJBQXlCLFFBQVEsQ0FBQztBQUM3RCxRQUFBLG1CQUFtQixFQUFFLFFBQVEsSUFBSSxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLFFBQVE7S0FDNUU7QUFDSDs7Ozs7QUMvREE7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBT0ksTUFBTSxhQUFhLEdBQUcseUNBQXlDO0FBQy9ELE1BQU0sd0JBQXdCLEdBQ25DLGdEQUFnRDtBQUU1QyxTQUFVLFlBQVksQ0FDMUIsR0FBZ0IsRUFDaEIsT0FBZSxFQUFBO0FBRWYsSUFBQSxNQUFNLFdBQVcsR0FBRyxJQUFJLFFBQVEsRUFBYztBQUU5QyxJQUFBLE1BQU0sS0FBSyxHQUFHLGlCQUFpQixDQUFDLEdBQUcsQ0FBQztBQUNwQyxJQUFBLEtBQUssQ0FBQyxjQUFjLEdBQUcsRUFBRSxXQUFXLEVBQUU7QUFFdEMsSUFBQSxNQUFNLEtBQUssR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDO0FBRTFCLElBQUEsTUFBTSxVQUFVLEdBQUcsWUFBWSxDQUFDLEtBQUssQ0FBQztJQUN0QyxJQUFJLENBQUMsVUFBVSxFQUFFO1FBQ2YscUJBQXFCLENBQUMsTUFBSztBQUN6QixZQUFBLE1BQU0sVUFBVSxHQUFHLFlBQVksQ0FBQyxLQUFLLENBQUM7WUFFdEMsSUFBSSxDQUFDLFVBQVUsRUFBRTs7QUFFZixnQkFBQSxNQUFNLElBQUksS0FBSyxDQUFDLGNBQWMsQ0FBQztZQUNqQztZQUNBLGlCQUFpQixDQUFDLEdBQUcsRUFBRSxPQUFPLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxXQUFXLENBQUM7QUFDakUsUUFBQSxDQUFDLENBQUM7SUFDSjtTQUFPO1FBQ0wsaUJBQWlCLENBQUMsR0FBRyxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQztJQUNqRTtJQUNBLE9BQU8sV0FBVyxDQUFDLE9BQU87QUFDNUI7QUFDTSxTQUFVLG9CQUFvQixDQUNsQyxHQUFnQixFQUNoQixPQUFlLEVBQUE7QUFFZixJQUFBLE1BQU0sV0FBVyxHQUFHLElBQUksUUFBUSxFQUFjO0FBRTlDLElBQUEsTUFBTSxLQUFLLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxDQUFDO0FBQ3BDLElBQUEsS0FBSyxDQUFDLGNBQWMsR0FBRyxFQUFFLFdBQVcsRUFBRTtBQUV0QyxJQUFBLE1BQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUM7QUFFMUIsSUFBQSxNQUFNLFVBQVUsR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFDO0lBQ3JDLElBQUksQ0FBQyxVQUFVLEVBQUU7UUFDZiw2QkFBNkIsQ0FBQyxNQUFLO0FBQ2pDLFlBQUEsTUFBTSxVQUFVLEdBQUcsWUFBWSxDQUFDLElBQUksQ0FBQztZQUVyQyxJQUFJLENBQUMsVUFBVSxFQUFFOztBQUVmLGdCQUFBLE1BQU0sSUFBSSxLQUFLLENBQUMsY0FBYyxDQUFDO1lBQ2pDO1lBQ0EsaUJBQWlCLENBQUMsR0FBRyxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQztBQUNqRSxRQUFBLENBQUMsQ0FBQztJQUNKO1NBQU87UUFDTCxpQkFBaUIsQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsV0FBVyxDQUFDO0lBQ2pFO0lBQ0EsT0FBTyxXQUFXLENBQUMsT0FBTztBQUM1QjtBQUVBOzs7QUFHRztBQUNILFNBQVMsaUJBQWlCLENBQ3hCLEdBQWdCLEVBQ2hCLE9BQWUsRUFDZixVQUFzQixFQUN0QixTQUFpQixFQUNqQixXQUFpQyxFQUFBO0FBRWpDLElBQUEsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFLOzs7UUFHcEIscUJBQXFCLENBQUMsR0FBRyxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsU0FBUyxDQUFDO0FBQzFELFFBQUEsV0FBVyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUM7QUFDakMsSUFBQSxDQUFDLENBQUM7QUFDSjtBQUVBOztBQUVHO0FBQ0gsU0FBUyxPQUFPLENBQUMsR0FBZ0IsRUFBQTtBQUMvQixJQUFBLE1BQU0sS0FBSyxHQUFHLENBQUEsZUFBQSxFQUFrQixHQUFHLENBQUMsSUFBSSxFQUFFO0lBQzFDLE1BQU0sWUFBWSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDO0FBQ2xELElBQUEsWUFBWSxDQUFDLEVBQUUsR0FBRyxLQUFLO0FBQ3ZCLElBQUEsWUFBWSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsTUFBTTtBQUVuQyxJQUFBLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQztBQUN2QyxJQUFBLE9BQU8sS0FBSztBQUNkO0FBRU8sZUFBZUQsVUFBUSxDQUFDLEdBQWdCLEVBQUE7SUFDN0MsZUFBZSxDQUFDLEdBQUcsQ0FBQzs7SUFHcEIsTUFBTSxjQUFjLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsY0FBZTtJQUM3RCxNQUFNLFNBQVMsR0FBRyxNQUFNLGNBQWMsQ0FBQyxXQUFXLENBQUMsT0FBTztJQUUxRCxPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE9BQU8sS0FBSTs7UUFFdEMsTUFBTSxjQUFjLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsY0FBZTtBQUM3RCxRQUFBLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBSztZQUNuQixPQUFPOztBQUVMLFlBQUEsU0FBUyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsUUFBUyxFQUFFO0FBQzFDLGdCQUFBLE1BQU0sRUFBRTtBQUNULGFBQUEsQ0FBQyxDQUNIO0FBQ0gsUUFBQSxDQUFDLENBQUM7QUFDSixJQUFBLENBQUMsQ0FBQztBQUNKO0FBRUE7Ozs7QUFJRztBQUNILFNBQVMscUJBQXFCLENBQzVCLEdBQWdCLEVBQ2hCLE9BQWUsRUFDZixVQUFzQixFQUN0QixTQUFpQixFQUFBO0FBRWpCLElBQUEsTUFBTSxRQUFRLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUU7QUFDNUMsUUFBQSxPQUFPLEVBQUUsT0FBTztBQUNoQixRQUFBLElBQUksRUFBRSxXQUFXOztRQUVqQixRQUFRLEVBQUUsTUFBSztZQUNiLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLGNBQWUsQ0FBQyxTQUFTLEdBQUcsSUFBSTtRQUN6RCxDQUFDOztRQUVELGdCQUFnQixFQUFFLE1BQUs7WUFDckIsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUMsY0FBZSxDQUFDLFNBQVMsR0FBRyxLQUFLO1FBQzFEO0FBQ0QsS0FBQSxDQUFDO0FBRUYsSUFBQSxNQUFNLEtBQUssR0FBRyxpQkFBaUIsQ0FBQyxHQUFHLENBQUM7SUFFcEMsS0FBSyxDQUFDLGNBQWMsR0FBRztBQUNyQixRQUFBLEdBQUcsS0FBSyxDQUFDLGNBQWU7UUFDeEI7S0FDRDtBQUNIO0FBRUEsU0FBUyxxQkFBcUIsQ0FBQyxNQUFrQixFQUFBO0lBQy9DLE1BQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDO0FBQy9DLElBQUEsTUFBTSxDQUFDLEdBQUcsR0FBRyxhQUFhO0FBQzFCLElBQUEsTUFBTSxDQUFDLE1BQU0sR0FBRyxNQUFNO0FBQ3RCLElBQUEsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDO0FBQ25DO0FBRUEsU0FBUyw2QkFBNkIsQ0FBQyxNQUFrQixFQUFBO0lBQ3ZELE1BQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDOztBQUUvQyxJQUFBLE1BQU0sQ0FBQyxHQUFHLEdBQUcsd0JBQXdCLEdBQUcsa0JBQWtCO0FBQzFELElBQUEsTUFBTSxDQUFDLE1BQU0sR0FBRyxNQUFNO0FBQ3RCLElBQUEsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDO0FBQ25DOztBQ25MQTs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUEwQkg7Ozs7O0FBS0c7TUFDVSxtQkFBbUIsQ0FBQTtBQVE5Qjs7O0FBR0c7QUFDSCxJQUFBLFdBQUEsQ0FBb0IsUUFBZ0IsRUFBQTtRQUFoQixJQUFBLENBQUEsUUFBUSxHQUFSLFFBQVE7QUFUNUI7OztBQUdHO1FBQ0ssSUFBQSxDQUFBLGFBQWEsR0FBd0IsSUFBSTtJQUtWO0FBRXZDOzs7QUFHRztBQUNILElBQUEsTUFBTSxRQUFRLENBQ1osWUFBQSxHQUF3QixLQUFLLEVBQUE7QUFFN0IsUUFBQSxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDOzs7QUFJcEMsUUFBQSxNQUFNLG1CQUFtQixHQUFHLE1BQU1FLFVBQWlCLENBQUMsSUFBSSxDQUFDLElBQUssQ0FBQyxDQUFDLEtBQUssQ0FDbkUsRUFBRSxJQUFHOztBQUVILFlBQUEsTUFBTSxhQUFhLENBQUMsTUFBTSxDQUFBLGlCQUFBLHFDQUErQjtBQUMzRCxRQUFBLENBQUMsQ0FDRjs7QUFFRCxRQUFBLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsSUFBSyxDQUFDLENBQUMsY0FBYyxFQUFFLFNBQVMsRUFBRTtBQUM1RCxZQUFBLE1BQU0sYUFBYSxDQUFDLE1BQU0sQ0FBQSxpQkFBQSxxQ0FBK0I7UUFDM0Q7QUFDQSxRQUFBLElBQUksTUFBTTtBQUNWLFFBQUEsSUFBSTtZQUNGLE1BQU0sT0FBTyxHQUFHLGtDQUFrQyxDQUNoRCxJQUFJLENBQUMsSUFBSyxFQUNWLG1CQUFtQixDQUNwQjtZQUNELElBQUksWUFBWSxFQUFFO0FBQ2hCLGdCQUFBLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsSUFBSTtZQUNwQztZQUNBLE1BQU0sR0FBRyxNQUFNLGFBQWEsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLHlCQUEwQixDQUFDO1FBQ3hFO1FBQUUsT0FBTyxDQUFDLEVBQUU7QUFDVixZQUFBLElBQ0csQ0FBbUIsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFBLG9CQUFBLHdDQUFrQyxFQUNyRTtBQUNBLGdCQUFBLElBQUksQ0FBQyxhQUFhLEdBQUcsVUFBVSxDQUM3QixNQUFNLENBQUUsQ0FBbUIsQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDLEVBQ25ELElBQUksQ0FBQyxhQUFhLENBQ25CO2dCQUNELE1BQU0sYUFBYSxDQUFDLE1BQU0sQ0FBQSxrQkFBQSx1Q0FBaUM7QUFDekQsb0JBQUEsSUFBSSxFQUFFLGlCQUFpQixDQUNyQixJQUFJLENBQUMsYUFBYSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FDbkQ7QUFDRCxvQkFBQSxVQUFVLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQztBQUNoQyxpQkFBQSxDQUFDO1lBQ0o7aUJBQU87QUFDTCxnQkFBQSxNQUFNLENBQUM7WUFDVDtRQUNGOztBQUVBLFFBQUEsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJO0FBQ3pCLFFBQUEsT0FBTyxNQUFNO0lBQ2Y7QUFFQTs7QUFFRztBQUNILElBQUEsVUFBVSxDQUFDLEdBQWdCLEVBQUE7QUFDekIsUUFBQSxJQUFJLENBQUMsSUFBSSxHQUFHLEdBQUc7UUFDZixJQUFJLENBQUMseUJBQXlCLEdBQUcsWUFBWSxDQUFDLEdBQUcsRUFBRSxXQUFXLENBQUM7UUFDL0RDLFlBQXFCLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBSzs7QUFFckQsUUFBQSxDQUFDLENBQUM7SUFDSjtBQUVBOztBQUVHO0FBQ0gsSUFBQSxPQUFPLENBQUMsYUFBc0IsRUFBQTtBQUM1QixRQUFBLElBQUksYUFBYSxZQUFZLG1CQUFtQixFQUFFO0FBQ2hELFlBQUEsT0FBTyxJQUFJLENBQUMsUUFBUSxLQUFLLGFBQWEsQ0FBQyxRQUFRO1FBQ2pEO2FBQU87QUFDTCxZQUFBLE9BQU8sS0FBSztRQUNkO0lBQ0Y7QUFDRDtBQUVEOzs7OztBQUtHO01BQ1UsMkJBQTJCLENBQUE7QUFRdEM7OztBQUdHO0FBQ0gsSUFBQSxXQUFBLENBQW9CLFFBQWdCLEVBQUE7UUFBaEIsSUFBQSxDQUFBLFFBQVEsR0FBUixRQUFRO0FBVDVCOzs7QUFHRztRQUNLLElBQUEsQ0FBQSxhQUFhLEdBQXdCLElBQUk7SUFLVjtBQUV2Qzs7O0FBR0c7QUFDSCxJQUFBLE1BQU0sUUFBUSxDQUNaLFlBQUEsR0FBd0IsS0FBSyxFQUFBO0FBRTdCLFFBQUEsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQzs7O0FBR3BDLFFBQUEsTUFBTSxtQkFBbUIsR0FBRyxNQUFNRCxVQUFpQixDQUFDLElBQUksQ0FBQyxJQUFLLENBQUMsQ0FBQyxLQUFLLENBQ25FLEVBQUUsSUFBRzs7QUFFSCxZQUFBLE1BQU0sYUFBYSxDQUFDLE1BQU0sQ0FBQSxpQkFBQSxxQ0FBK0I7QUFDM0QsUUFBQSxDQUFDLENBQ0Y7O0FBRUQsUUFBQSxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLElBQUssQ0FBQyxDQUFDLGNBQWMsRUFBRSxTQUFTLEVBQUU7QUFDNUQsWUFBQSxNQUFNLGFBQWEsQ0FBQyxNQUFNLENBQUEsaUJBQUEscUNBQStCO1FBQzNEO0FBQ0EsUUFBQSxJQUFJLE1BQU07QUFDVixRQUFBLElBQUk7WUFDRixNQUFNLE9BQU8sR0FBRywwQ0FBMEMsQ0FDeEQsSUFBSSxDQUFDLElBQUssRUFDVixtQkFBbUIsQ0FDcEI7WUFDRCxJQUFJLFlBQVksRUFBRTtBQUNoQixnQkFBQSxPQUFPLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLElBQUk7WUFDcEM7WUFDQSxNQUFNLEdBQUcsTUFBTSxhQUFhLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyx5QkFBMEIsQ0FBQztRQUN4RTtRQUFFLE9BQU8sQ0FBQyxFQUFFO0FBQ1YsWUFBQSxJQUNHLENBQW1CLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQSxvQkFBQSx3Q0FBa0MsRUFDckU7QUFDQSxnQkFBQSxJQUFJLENBQUMsYUFBYSxHQUFHLFVBQVUsQ0FDN0IsTUFBTSxDQUFFLENBQW1CLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQyxFQUNuRCxJQUFJLENBQUMsYUFBYSxDQUNuQjtnQkFDRCxNQUFNLGFBQWEsQ0FBQyxNQUFNLENBQUEsa0JBQUEsdUNBQWlDO0FBQ3pELG9CQUFBLElBQUksRUFBRSxpQkFBaUIsQ0FDckIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQ25EO0FBQ0Qsb0JBQUEsVUFBVSxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUM7QUFDaEMsaUJBQUEsQ0FBQztZQUNKO2lCQUFPO0FBQ0wsZ0JBQUEsTUFBTSxDQUFDO1lBQ1Q7UUFDRjs7QUFFQSxRQUFBLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSTtBQUN6QixRQUFBLE9BQU8sTUFBTTtJQUNmO0FBRUE7O0FBRUc7QUFDSCxJQUFBLFVBQVUsQ0FBQyxHQUFnQixFQUFBO0FBQ3pCLFFBQUEsSUFBSSxDQUFDLElBQUksR0FBRyxHQUFHO1FBQ2YsSUFBSSxDQUFDLHlCQUF5QixHQUFHLFlBQVksQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDO1FBQy9ERSxvQkFBNkIsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFLOztBQUU3RCxRQUFBLENBQUMsQ0FBQztJQUNKO0FBRUE7O0FBRUc7QUFDSCxJQUFBLE9BQU8sQ0FBQyxhQUFzQixFQUFBO0FBQzVCLFFBQUEsSUFBSSxhQUFhLFlBQVksMkJBQTJCLEVBQUU7QUFDeEQsWUFBQSxPQUFPLElBQUksQ0FBQyxRQUFRLEtBQUssYUFBYSxDQUFDLFFBQVE7UUFDakQ7YUFBTztBQUNMLFlBQUEsT0FBTyxLQUFLO1FBQ2Q7SUFDRjtBQUNEO0FBRUQ7OztBQUdHO01BQ1UsY0FBYyxDQUFBO0FBR3pCLElBQUEsV0FBQSxDQUFvQixzQkFBNkMsRUFBQTtRQUE3QyxJQUFBLENBQUEsc0JBQXNCLEdBQXRCLHNCQUFzQjtJQUEwQjtBQUVwRTs7QUFFRztBQUNILElBQUEsTUFBTSxRQUFRLEdBQUE7O1FBRVosTUFBTSxXQUFXLEdBQUcsTUFBTSxJQUFJLENBQUMsc0JBQXNCLENBQUMsUUFBUSxFQUFFOzs7UUFHaEUsTUFBTSxtQkFBbUIsR0FBRyxZQUFZLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQzs7O0FBRzNELFFBQUEsTUFBTSxrQkFBa0IsR0FDdEIsbUJBQW1CLEtBQUssSUFBSTtBQUM1QixZQUFBLG1CQUFtQixHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUU7QUFDaEMsWUFBQSxtQkFBbUIsR0FBRztjQUNsQixtQkFBbUIsR0FBRztBQUN4QixjQUFFLElBQUksQ0FBQyxHQUFHLEVBQUU7QUFFaEIsUUFBQSxPQUFPLEVBQUUsR0FBRyxXQUFXLEVBQUUsa0JBQWtCLEVBQUU7SUFDL0M7QUFFQTs7QUFFRztBQUNILElBQUEsVUFBVSxDQUFDLEdBQWdCLEVBQUE7QUFDekIsUUFBQSxJQUFJLENBQUMsSUFBSSxHQUFHLEdBQUc7SUFDakI7QUFFQTs7QUFFRztBQUNILElBQUEsT0FBTyxDQUFDLGFBQXNCLEVBQUE7QUFDNUIsUUFBQSxJQUFJLGFBQWEsWUFBWSxjQUFjLEVBQUU7WUFDM0MsUUFDRSxJQUFJLENBQUMsc0JBQXNCLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRTtnQkFDL0MsYUFBYSxDQUFDLHNCQUFzQixDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUU7UUFFNUQ7YUFBTztBQUNMLFlBQUEsT0FBTyxLQUFLO1FBQ2Q7SUFDRjtBQUNEO0FBRUQ7Ozs7Ozs7QUFPRztBQUNILFNBQVMsVUFBVSxDQUNqQixVQUFrQixFQUNsQixZQUFpQyxFQUFBO0FBRWpDOzs7Ozs7Ozs7QUFTRztJQUNILElBQUksVUFBVSxLQUFLLEdBQUcsSUFBSSxVQUFVLEtBQUssR0FBRyxFQUFFO1FBQzVDLE9BQU87QUFDTCxZQUFBLFlBQVksRUFBRSxDQUFDO0FBQ2YsWUFBQSxrQkFBa0IsRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsT0FBTztZQUN4QztTQUNEO0lBQ0g7U0FBTztBQUNMOzs7QUFHRztBQUNILFFBQUEsTUFBTSxZQUFZLEdBQUcsWUFBWSxHQUFHLFlBQVksQ0FBQyxZQUFZLEdBQUcsQ0FBQztRQUNqRSxNQUFNLGFBQWEsR0FBRyxzQkFBc0IsQ0FBQyxZQUFZLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUNuRSxPQUFPO1lBQ0wsWUFBWSxFQUFFLFlBQVksR0FBRyxDQUFDO0FBQzlCLFlBQUEsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLGFBQWE7WUFDOUM7U0FDRDtJQUNIO0FBQ0Y7QUFFQSxTQUFTLGdCQUFnQixDQUFDLFlBQWlDLEVBQUE7SUFDekQsSUFBSSxZQUFZLEVBQUU7UUFDaEIsSUFBSSxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsWUFBWSxDQUFDLGtCQUFrQixJQUFJLENBQUMsRUFBRTs7WUFFckQsTUFBTSxhQUFhLENBQUMsTUFBTSxDQUFBLFdBQUEsZ0NBQTBCO2dCQUNsRCxJQUFJLEVBQUUsaUJBQWlCLENBQUMsWUFBWSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDckUsVUFBVSxFQUFFLFlBQVksQ0FBQztBQUMxQixhQUFBLENBQUM7UUFDSjtJQUNGO0FBQ0Y7O0FDblZBOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztBQTRDSDs7Ozs7QUFLRztTQUNhLGtCQUFrQixDQUNoQyxNQUFtQixNQUFNLEVBQUUsRUFDM0IsT0FBd0IsRUFBQTtBQUV4QixJQUFBLEdBQUcsR0FBRyxrQkFBa0IsQ0FBQyxHQUFHLENBQUM7SUFDN0IsTUFBTSxRQUFRLEdBQUcsWUFBWSxDQUFDLEdBQUcsRUFBRSxXQUFXLENBQUM7O0FBRy9DLElBQUEsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLFdBQVcsRUFBRTtBQUNoQyxRQUFBLG1CQUFtQixFQUFFO0lBQ3ZCOzs7SUFJQSxJQUFJLFdBQVcsRUFBRSxFQUFFOztBQUVqQixRQUFBLEtBQUssYUFBYSxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUs7O1FBRTdCLE9BQU8sQ0FBQyxHQUFHLENBQ1QsQ0FBQSx1QkFBQSxFQUEwQixLQUFLLENBQUEsa0dBQUEsQ0FBb0csQ0FDcEksQ0FDRjtJQUNIO0FBRUEsSUFBQSxJQUFJLFFBQVEsQ0FBQyxhQUFhLEVBQUUsRUFBRTtBQUM1QixRQUFBLE1BQU0sZ0JBQWdCLEdBQUcsUUFBUSxDQUFDLFlBQVksRUFBRTtBQUNoRCxRQUFBLE1BQU0sY0FBYyxHQUFHLFFBQVEsQ0FBQyxVQUFVLEVBQWdDO0FBQzFFLFFBQUEsSUFDRSxjQUFjO1lBQ2QsQ0FBQyxDQUFDLGNBQWMsQ0FBQyx5QkFBeUI7Z0JBQ3hDLENBQUMsQ0FBQyxPQUFPLENBQUMseUJBQXlCO1lBQ3JDLGNBQWMsQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsRUFDbEQ7QUFDQSxZQUFBLE9BQU8sZ0JBQWdCO1FBQ3pCO2FBQU87WUFDTCxNQUFNLGFBQWEsQ0FBQyxNQUFNLENBQUEscUJBQUEsMENBQW9DO2dCQUM1RCxPQUFPLEVBQUUsR0FBRyxDQUFDO0FBQ2QsYUFBQSxDQUFDO1FBQ0o7SUFDRjtJQUVBLE1BQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxVQUFVLENBQUMsRUFBRSxPQUFPLEVBQUUsQ0FBQztJQUNqRCxTQUFTLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLHlCQUF5QixDQUFDOzs7O0FBSW5FLElBQUEsSUFBSSxpQkFBaUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyx5QkFBeUIsRUFBRTs7Ozs7O1FBTXBELGdCQUFnQixDQUFDLFFBQVEsRUFBQSxVQUFBLDhCQUF5QixNQUFLLEVBQUUsQ0FBQyxDQUFDO0lBQzdEO0FBRUEsSUFBQSxPQUFPLFFBQVE7QUFDakI7QUFFQTs7Ozs7Ozs7O0FBU0c7QUFDSCxTQUFTLFNBQVMsQ0FDaEIsR0FBZ0IsRUFDaEIsUUFBMEIsRUFDMUIsNEJBQXFDLEtBQUssRUFBQTs7O0lBSTFDLE1BQU0sS0FBSyxHQUFHLGVBQWUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxHQUFHLGFBQWEsRUFBRSxDQUFDO0FBRXhELElBQUEsS0FBSyxDQUFDLFNBQVMsR0FBRyxJQUFJO0FBQ3RCLElBQUEsS0FBSyxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7QUFDMUIsSUFBQSxLQUFLLENBQUMsa0JBQWtCLEdBQUcsb0JBQW9CLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBRztBQUN0RSxRQUFBLElBQUksV0FBVyxJQUFJLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRTtBQUN2QyxZQUFBLEtBQUssQ0FBQyxLQUFLLEdBQUcsV0FBVzs7WUFFekIsb0JBQW9CLENBQUMsR0FBRyxFQUFFLEVBQUUsS0FBSyxFQUFFLFdBQVcsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUN6RDtBQUNBLFFBQUEsT0FBTyxXQUFXO0FBQ3BCLElBQUEsQ0FBQyxDQUFDOzs7QUFJRixJQUFBLEtBQUssQ0FBQyx5QkFBeUI7QUFDN0IsUUFBQSx5QkFBeUIsSUFBSSxHQUFHLENBQUMsOEJBQThCO0FBRWpFLElBQUEsSUFBSSxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsSUFBSSx5QkFBeUIsRUFBRTtRQUNwRSxNQUFNLENBQUMsSUFBSSxDQUNULDBDQUEwQztZQUN4QywwREFBMEQ7QUFDMUQsWUFBQSwwREFBMEQsQ0FDN0Q7SUFDSDtBQUVBLElBQUEsS0FBSyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDO0FBQ2hDO0FBRUE7Ozs7Ozs7O0FBUUc7QUFDRyxTQUFVLDBCQUEwQixDQUN4QyxnQkFBMEIsRUFDMUIseUJBQWtDLEVBQUE7QUFFbEMsSUFBQSxNQUFNLEdBQUcsR0FBRyxnQkFBZ0IsQ0FBQyxHQUFHO0FBQ2hDLElBQUEsTUFBTSxLQUFLLEdBQUcsaUJBQWlCLENBQUMsR0FBRyxDQUFDOzs7QUFHcEMsSUFBQSxJQUFJLEtBQUssQ0FBQyxjQUFjLEVBQUU7QUFDeEIsUUFBQSxJQUFJLHlCQUF5QixLQUFLLElBQUksRUFBRTtBQUN0QyxZQUFBLEtBQUssQ0FBQyxjQUFjLENBQUMsS0FBSyxFQUFFO1FBQzlCO2FBQU87QUFDTCxZQUFBLEtBQUssQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFO1FBQzdCO0lBQ0Y7QUFDQSxJQUFBLEtBQUssQ0FBQyx5QkFBeUIsR0FBRyx5QkFBeUI7QUFDN0Q7QUFDQTs7Ozs7Ozs7Ozs7QUFXRztBQUNJLGVBQWUsUUFBUSxDQUM1QixnQkFBMEIsRUFDMUIsWUFBc0IsRUFBQTtJQUV0QixNQUFNLE1BQU0sR0FBRyxNQUFNQyxVQUFnQixDQUNuQyxnQkFBbUMsRUFDbkMsWUFBWSxDQUNiO0FBQ0QsSUFBQSxJQUFJLE1BQU0sQ0FBQyxLQUFLLEVBQUU7UUFDaEIsTUFBTSxNQUFNLENBQUMsS0FBSztJQUNwQjtBQUNBLElBQUEsSUFBSSxNQUFNLENBQUMsYUFBYSxFQUFFO1FBQ3hCLE1BQU0sTUFBTSxDQUFDLGFBQWE7SUFDNUI7QUFDQSxJQUFBLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUssRUFBRTtBQUNoQztBQUVBOzs7Ozs7Ozs7Ozs7OztBQWNHO0FBQ0csU0FBVSxrQkFBa0IsQ0FDaEMsZ0JBQTBCLEVBQUE7QUFFMUIsSUFBQSxPQUFPQyxvQkFBMEIsQ0FBQyxnQkFBbUMsQ0FBQztBQUN4RTtBQTRDQTs7O0FBR0c7U0FDYSxjQUFjLENBQzVCLGdCQUEwQixFQUMxQixnQkFFd0MsRUFDeEMsT0FBZ0M7QUFDaEM7Ozs7O0FBS0c7QUFDSDtBQUNBLFlBQXlCLEVBQUE7QUFFekIsSUFBQSxJQUFJLE1BQU0sR0FBZ0MsTUFBSyxFQUFFLENBQUM7QUFDbEQsSUFBQSxJQUFJLE9BQU8sR0FBWSxNQUFLLEVBQUUsQ0FBQztBQUMvQixJQUFBLElBQUssZ0JBQXlELENBQUMsSUFBSSxJQUFJLElBQUksRUFBRTtRQUMzRSxNQUFNLEdBQ0osZ0JBQ0QsQ0FBQyxJQUFLLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDO0lBQ2hDO1NBQU87UUFDTCxNQUFNLEdBQUcsZ0JBQStDO0lBQzFEO0FBQ0EsSUFBQSxJQUNHLGdCQUF5RCxDQUFDLEtBQUssSUFBSSxJQUFJLEVBQ3hFO1FBQ0EsT0FBTyxHQUNMLGdCQUNELENBQUMsS0FBTSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztJQUNqQztTQUFPLElBQUksT0FBTyxFQUFFO1FBQ2xCLE9BQU8sR0FBRyxPQUFPO0lBQ25CO0FBQ0EsSUFBQSxnQkFBZ0IsQ0FDZCxnQkFBbUMsRUFBQSxVQUFBLDhCQUVuQyxNQUFNLEVBQ04sT0FBTyxDQUNSO0lBQ0QsT0FBTyxNQUFNLG1CQUFtQixDQUFDLGdCQUFnQixDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUM7QUFDaEU7O0FDM1VBOzs7Ozs7Ozs7QUFTRztBQUVIOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztBQWtCSCxNQUFNLGNBQWMsR0FBMkIsV0FBVztBQUMxRCxNQUFNLHVCQUF1QixHQUMzQixvQkFBb0I7QUFDdEIsU0FBUyxnQkFBZ0IsR0FBQTs7SUFFdkIsa0JBQWtCLENBQ2hCLElBQUksU0FBUyxDQUNYLGNBQWMsRUFDZCxTQUFTLElBQUc7O1FBRVYsTUFBTSxHQUFHLEdBQUcsU0FBUyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZLEVBQUU7UUFDdkQsTUFBTSx3QkFBd0IsR0FBRyxTQUFTLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQztBQUNuRSxRQUFBLE9BQU8sT0FBTyxDQUFDLEdBQUcsRUFBRSx3QkFBd0IsQ0FBQztBQUMvQyxJQUFBLENBQUMsRUFBQSxRQUFBO0FBR0EsU0FBQSxvQkFBb0IsQ0FBQSxVQUFBO0FBQ3JCOzs7QUFHRztTQUNGLDBCQUEwQixDQUN6QixDQUFDLFNBQVMsRUFBRSxXQUFXLEVBQUUsZ0JBQWdCLEtBQUk7UUFDM0MsU0FBUyxDQUFDLFdBQVcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLFVBQVUsRUFBRTtJQUM3RCxDQUFDLENBQ0YsQ0FDSjs7SUFHRCxrQkFBa0IsQ0FDaEIsSUFBSSxTQUFTLENBQ1gsdUJBQXVCLEVBQ3ZCLFNBQVMsSUFBRztRQUNWLE1BQU0sUUFBUSxHQUFHLFNBQVMsQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUMsWUFBWSxFQUFFO0FBQ2xFLFFBQUEsT0FBTyxlQUFlLENBQUMsUUFBUSxDQUFDO0FBQ2xDLElBQUEsQ0FBQyxFQUFBLFFBQUEsNEJBRUYsQ0FBQyxvQkFBb0IsQ0FBQSxVQUFBLGtDQUE0QixDQUNuRDtBQUVELElBQUEsZUFBZSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUM7QUFDaEM7QUFFQSxnQkFBZ0IsRUFBRTs7OzsiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNV19