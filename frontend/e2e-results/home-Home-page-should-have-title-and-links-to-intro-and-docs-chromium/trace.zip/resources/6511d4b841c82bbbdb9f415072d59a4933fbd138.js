//#region node_modules/.pnpm/nostics@1.2.0/node_modules/nostics/dist/formatters/ansi.mjs
/* @__NO_SIDE_EFFECTS__ */
function ansiFormatter(colors) {
	return (d) => {
		const header = `${colors.bold(colors.red(`[${d.name}]`))} ${d.message}`;
		const details = [];
		if (d.fix) details.push(`${colors.dim("fix:")} ${d.fix}`);
		if (d.sources?.length) details.push(`${colors.dim("sources:")} ${d.sources.join(", ")}`);
		if (d.docs) details.push(`${colors.dim("see:")} ${colors.cyan(d.docs)}`);
		if (details.length === 0) return header;
		return [header, ...details.map((detail, i) => {
			return `${colors.dim(i < details.length - 1 ? "├▶" : "╰▶")} ${detail}`;
		})].join("\n");
	};
}
//#endregion
export { ansiFormatter };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibm9zdGljc19mb3JtYXR0ZXJzX2Fuc2kuanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLnBucG0vbm9zdGljc0AxLjIuMC9ub2RlX21vZHVsZXMvbm9zdGljcy9kaXN0L2Zvcm1hdHRlcnMvYW5zaS5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8jcmVnaW9uIHNyYy9mb3JtYXR0ZXJzL2Fuc2kudHNcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBhbnNpRm9ybWF0dGVyKGNvbG9ycykge1xuXHRyZXR1cm4gKGQpID0+IHtcblx0XHRjb25zdCBoZWFkZXIgPSBgJHtjb2xvcnMuYm9sZChjb2xvcnMucmVkKGBbJHtkLm5hbWV9XWApKX0gJHtkLm1lc3NhZ2V9YDtcblx0XHRjb25zdCBkZXRhaWxzID0gW107XG5cdFx0aWYgKGQuZml4KSBkZXRhaWxzLnB1c2goYCR7Y29sb3JzLmRpbShcImZpeDpcIil9ICR7ZC5maXh9YCk7XG5cdFx0aWYgKGQuc291cmNlcz8ubGVuZ3RoKSBkZXRhaWxzLnB1c2goYCR7Y29sb3JzLmRpbShcInNvdXJjZXM6XCIpfSAke2Quc291cmNlcy5qb2luKFwiLCBcIil9YCk7XG5cdFx0aWYgKGQuZG9jcykgZGV0YWlscy5wdXNoKGAke2NvbG9ycy5kaW0oXCJzZWU6XCIpfSAke2NvbG9ycy5jeWFuKGQuZG9jcyl9YCk7XG5cdFx0aWYgKGRldGFpbHMubGVuZ3RoID09PSAwKSByZXR1cm4gaGVhZGVyO1xuXHRcdHJldHVybiBbaGVhZGVyLCAuLi5kZXRhaWxzLm1hcCgoZGV0YWlsLCBpKSA9PiB7XG5cdFx0XHRyZXR1cm4gYCR7Y29sb3JzLmRpbShpIDwgZGV0YWlscy5sZW5ndGggLSAxID8gXCLilJzilrZcIiA6IFwi4pWw4pa2XCIpfSAke2RldGFpbH1gO1xuXHRcdH0pXS5qb2luKFwiXFxuXCIpO1xuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBhbnNpRm9ybWF0dGVyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFuc2kubWpzLm1hcCJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF0sIm1hcHBpbmdzIjoiOztBQUVBLFNBQVMsY0FBYyxRQUFRO0NBQzlCLFFBQVEsTUFBTTtFQUNiLE1BQU0sU0FBUyxHQUFHLE9BQU8sS0FBSyxPQUFPLElBQUksSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLEVBQUUsR0FBRyxFQUFFO0VBQzlELE1BQU0sVUFBVSxDQUFDO0VBQ2pCLElBQUksRUFBRSxLQUFLLFFBQVEsS0FBSyxHQUFHLE9BQU8sSUFBSSxNQUFNLEVBQUUsR0FBRyxFQUFFLEtBQUs7RUFDeEQsSUFBSSxFQUFFLFNBQVMsUUFBUSxRQUFRLEtBQUssR0FBRyxPQUFPLElBQUksVUFBVSxFQUFFLEdBQUcsRUFBRSxRQUFRLEtBQUssSUFBSSxHQUFHO0VBQ3ZGLElBQUksRUFBRSxNQUFNLFFBQVEsS0FBSyxHQUFHLE9BQU8sSUFBSSxNQUFNLEVBQUUsR0FBRyxPQUFPLEtBQUssRUFBRSxJQUFJLEdBQUc7RUFDdkUsSUFBSSxRQUFRLFdBQVcsR0FBRyxPQUFPO0VBQ2pDLE9BQU8sQ0FBQyxRQUFRLEdBQUcsUUFBUSxLQUFLLFFBQVEsTUFBTTtHQUM3QyxPQUFPLEdBQUcsT0FBTyxJQUFJLElBQUksUUFBUSxTQUFTLElBQUksT0FBTyxJQUFJLEVBQUUsR0FBRztFQUMvRCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSTtDQUNkO0FBQ0QifQ==