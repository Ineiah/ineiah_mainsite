export const galleryImages = [
	{
		name: "Coupe styling mi-long",
		alt: "Coupe styling mi-long",
		image: ["/images/gallery/customer1.jpg", "/images/gallery/customer2.jpg"],
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Brushing volumineux",
		alt: "Brushing volumineux",
		image: ["/images/gallery/customer18.jpg", "/images/gallery/customer71.jpeg"],
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Hair contouring cheveux longs",
		alt: "Hair contouring cheveux longs",
		image: ["/images/gallery/customer32.jpg", "/images/gallery/customer33.jpg"],
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Soin à la Kératine et couleur",
		alt: "Soin à la Kératine et couleur",
		image: "/images/gallery/customer3.jpg",
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Coupe dégradée",
		alt: "Coupe dégradée",
		image: "/images/gallery/customer6.jpg",
		category: "image",
		url: null,
		isVisible: false,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Brushing Wavy cheveux XL",
		alt: "Brushing Wavy cheveux XL",
		image: "/images/gallery/customer7.jpg",
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Coupe coiffage cheveux courts",
		alt: "Coupe coiffage cheveux courts",
		image: "/images/gallery/customer8.jpg",
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Chignon élégant",
		alt: "Chignon élégant",
		image: "/images/gallery/customer9.jpg",
		category: "image",
		url: null,
		isVisible: false,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Shampoing coupe brushing wavy cheveux longs",
		alt: "Shampoing coupe brushing wavy cheveux longs",
		image: "/images/gallery/customer19.jpg",
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Shampoing coupe styling",
		alt: "Shampoing coupe styling",
		image: "/images/gallery/customer23.jpg",
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Couleur coupe brushing wavy cheveux longs",
		alt: "Couleur coupe brushing wavy cheveux longs",
		image: "/images/gallery/customer11.jpg",
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Coupe frange rideau cheveux mi-longs",
		alt: "Coupe frange rideau cheveux mi-longs",
		image: ["/images/gallery/customer13.jpg", "/images/gallery/customer14.jpg"],
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Styling XL",
		alt: "Styling XL",
		image: ["/images/gallery/customer29.jpg", "/images/gallery/customer30.jpg"],
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Coloration repousse longueur cheveux mi-longs",
		alt: "Coloration repousse longueur cheveux mi-longs",
		image: ["/images/gallery/customer24.jpg", "/images/gallery/customer25.jpg"],
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Styling XL",
		alt: "Styling XL",
		image: "/images/gallery/customer34.jpg",
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Chignon",
		alt: "Chignon",
		image: "/images/gallery/customer35.jpg",
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Test Video",
		alt: "Test Video",
		image: "/vid1.mov",
		category: "video",
		url: null,
		isVisible: false,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Soin Kératine Végétale",
		alt: "Soin Kératine Végétale",
		image: [
			"/images/kira/photoshoot46-small.webp",
			"/images/kira/photoshoot45.jpg",
			"/images/kira/photoshoot46.jpg",
			"/images/kira/photoshoot19.jpg",
			"/images/kira/photoshoot20.jpg",
			"/images/kira/photoshoot2.jpg",
			"/images/kira/photoshoot1.jpg"
		],
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: "_khreate_"
		},
		model: { instagram: "mei_linhconte" },
		brands: []
	},
	{
		name: "Soin Kératine Végétale",
		alt: "Soin Kératine Végétale",
		image: [
			"/images/gallery/customer36-small.webp",
			"/images/gallery/customer37-small.webp",
			"/images/gallery/customer38-small.webp"
		],
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Mise en forme boucles",
		alt: "Mise en forme boucles",
		image: "/images/gallery/customer39-small.webp",
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Mise en forme boucles",
		alt: "Mise en forme boucles",
		image: "/images/gallery/customer40-small.webp",
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Mise en forme boucles 3",
		alt: "Mise en forme boucles 3",
		image: [
			"/images/gallery/customer41-small.webp",
			"/images/gallery/customer42.jpg",
			"/images/gallery/customer44-small.webp"
		],
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: "_khreate_"
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Mise en forme boucles",
		alt: "Mise en forme boucles",
		image: "/images/gallery/customer62-small.webp",
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	},
	{
		name: "Mise en forme boucles",
		alt: "Mise en forme boucles",
		image: "/images/gallery/customer72-small.webp",
		category: "image",
		url: null,
		isVisible: true,
		author: {
			name: "",
			username: "",
			website: "",
			instagram: ""
		},
		model: { instagram: "" },
		brands: []
	}
];

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBRUEsT0FBTyxNQUFNLGdCQUF5QztDQUNwRDtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTyxDQUNMLGlDQUNBLCtCQUNGO0VBQ0EsVUFBVTtFQUNWLEtBQUs7RUFDTCxXQUFXO0VBQ1gsUUFBUTtHQUNOLE1BQU07R0FDTixVQUFVO0dBQ1YsU0FBUztHQUNULFdBQVc7RUFDYjtFQUNBLE9BQU8sRUFDTCxXQUFXLEdBQ2I7RUFDQSxRQUFRLENBQUM7Q0FDWDtDQUNBO0VBQ0UsTUFBTTtFQUNOLEtBQUs7RUFDTCxPQUFPLENBQ0wsa0NBQ0EsaUNBQ0Y7RUFDQSxVQUFVO0VBQ1YsS0FBSztFQUNMLFdBQVc7RUFDWCxRQUFRO0dBQ04sTUFBTTtHQUNOLFVBQVU7R0FDVixTQUFTO0dBQ1QsV0FBVztFQUNiO0VBQ0EsT0FBTyxFQUNMLFdBQVcsR0FDYjtFQUNBLFFBQVEsQ0FBQztDQUNYO0NBQ0E7RUFDRSxNQUFNO0VBQ04sS0FBSztFQUNMLE9BQU8sQ0FDTCxrQ0FDQSxnQ0FDRjtFQUNBLFVBQVU7RUFDVixLQUFLO0VBQ0wsV0FBVztFQUNYLFFBQVE7R0FDTixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVM7R0FDVCxXQUFXO0VBQ2I7RUFDQSxPQUFPLEVBQ0wsV0FBVyxHQUNiO0VBQ0EsUUFBUSxDQUFDO0NBQ1g7Q0FDQTtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsV0FBVztFQUNYLFFBQVE7R0FDTixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVM7R0FDVCxXQUFXO0VBQ2I7RUFDQSxPQUFPLEVBQ0wsV0FBVyxHQUNiO0VBQ0EsUUFBUSxDQUFDO0NBQ1g7Q0FDQTtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsV0FBVztFQUNYLFFBQVE7R0FDTixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVM7R0FDVCxXQUFXO0VBQ2I7RUFDQSxPQUFPLEVBQ0wsV0FBVyxHQUNiO0VBQ0EsUUFBUSxDQUFDO0NBQ1g7Q0FDQTtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsV0FBVztFQUNYLFFBQVE7R0FDTixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVM7R0FDVCxXQUFXO0VBQ2I7RUFDQSxPQUFPLEVBQ0wsV0FBVyxHQUNiO0VBQ0EsUUFBUSxDQUFDO0NBQ1g7Q0FDQTtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsV0FBVztFQUNYLFFBQVE7R0FDTixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVM7R0FDVCxXQUFXO0VBQ2I7RUFDQSxPQUFPLEVBQ0wsV0FBVyxHQUNiO0VBQ0EsUUFBUSxDQUFDO0NBQ1g7Q0FDQTtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsV0FBVztFQUNYLFFBQVE7R0FDTixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVM7R0FDVCxXQUFXO0VBQ2I7RUFDQSxPQUFPLEVBQ0wsV0FBVyxHQUNiO0VBQ0EsUUFBUSxDQUFDO0NBQ1g7Q0FDQTtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsV0FBVztFQUNYLFFBQVE7R0FDTixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVM7R0FDVCxXQUFXO0VBQ2I7RUFDQSxPQUFPLEVBQ0wsV0FBVyxHQUNiO0VBQ0EsUUFBUSxDQUFDO0NBQ1g7Q0FDQTtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsV0FBVztFQUNYLFFBQVE7R0FDTixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVM7R0FDVCxXQUFXO0VBQ2I7RUFDQSxPQUFPLEVBQ0wsV0FBVyxHQUNiO0VBQ0EsUUFBUSxDQUFDO0NBQ1g7Q0FDQTtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsV0FBVztFQUNYLFFBQVE7R0FDTixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVM7R0FDVCxXQUFXO0VBQ2I7RUFDQSxPQUFPLEVBQ0wsV0FBVyxHQUNiO0VBQ0EsUUFBUSxDQUFDO0NBQ1g7Q0FDQTtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTyxDQUNMLGtDQUNBLGdDQUNGO0VBQ0EsVUFBVTtFQUNWLEtBQUs7RUFDTCxXQUFXO0VBQ1gsUUFBUTtHQUNOLE1BQU07R0FDTixVQUFVO0dBQ1YsU0FBUztHQUNULFdBQVc7RUFDYjtFQUNBLE9BQU8sRUFDTCxXQUFXLEdBQ2I7RUFDQSxRQUFRLENBQUM7Q0FDWDtDQUNBO0VBQ0UsTUFBTTtFQUNOLEtBQUs7RUFDTCxPQUFPLENBQ0wsa0NBQ0EsZ0NBQ0Y7RUFDQSxVQUFVO0VBQ1YsS0FBSztFQUNMLFdBQVc7RUFDWCxRQUFRO0dBQ04sTUFBTTtHQUNOLFVBQVU7R0FDVixTQUFTO0dBQ1QsV0FBVztFQUNiO0VBQ0EsT0FBTyxFQUNMLFdBQVcsR0FDYjtFQUNBLFFBQVEsQ0FBQztDQUNYO0NBQ0E7RUFDRSxNQUFNO0VBQ04sS0FBSztFQUNMLE9BQU8sQ0FDTCxrQ0FDQSxnQ0FDRjtFQUNBLFVBQVU7RUFDVixLQUFLO0VBQ0wsV0FBVztFQUNYLFFBQVE7R0FDTixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVM7R0FDVCxXQUFXO0VBQ2I7RUFDQSxPQUFPLEVBQ0wsV0FBVyxHQUNiO0VBQ0EsUUFBUSxDQUFDO0NBQ1g7Q0FDQTtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsV0FBVztFQUNYLFFBQVE7R0FDTixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVM7R0FDVCxXQUFXO0VBQ2I7RUFDQSxPQUFPLEVBQ0wsV0FBVyxHQUNiO0VBQ0EsUUFBUSxDQUFDO0NBQ1g7Q0FDQTtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsV0FBVztFQUNYLFFBQVE7R0FDTixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVM7R0FDVCxXQUFXO0VBQ2I7RUFDQSxPQUFPLEVBQ0wsV0FBVyxHQUNiO0VBQ0EsUUFBUSxDQUFDO0NBQ1g7Q0FDQTtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsV0FBVztFQUNYLFFBQVE7R0FDTixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVM7R0FDVCxXQUFXO0VBQ2I7RUFDQSxPQUFPLEVBQ0wsV0FBVyxHQUNiO0VBQ0EsUUFBUSxDQUFDO0NBQ1g7Q0FDQTtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTztHQUNMO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7RUFDQSxVQUFVO0VBQ1YsS0FBSztFQUNMLFdBQVc7RUFDWCxRQUFRO0dBQ04sTUFBTTtHQUNOLFVBQVU7R0FDVixTQUFTO0dBQ1QsV0FBVztFQUNiO0VBQ0EsT0FBTyxFQUNMLFdBQVcsZ0JBQ2I7RUFDQSxRQUFRLENBQUM7Q0FDWDtDQUNBO0VBQ0UsTUFBTTtFQUNOLEtBQUs7RUFDTCxPQUFPO0dBQ0w7R0FDQTtHQUNBO0VBQ0Y7RUFDQSxVQUFVO0VBQ1YsS0FBSztFQUNMLFdBQVc7RUFDWCxRQUFRO0dBQ04sTUFBTTtHQUNOLFVBQVU7R0FDVixTQUFTO0dBQ1QsV0FBVztFQUNiO0VBQ0EsT0FBTyxFQUNMLFdBQVcsR0FDYjtFQUNBLFFBQVEsQ0FBQztDQUNYO0NBQ0E7RUFDRSxNQUFNO0VBQ04sS0FBSztFQUNMLE9BQU87RUFDUCxVQUFVO0VBQ1YsS0FBSztFQUNMLFdBQVc7RUFDWCxRQUFRO0dBQ04sTUFBTTtHQUNOLFVBQVU7R0FDVixTQUFTO0dBQ1QsV0FBVztFQUNiO0VBQ0EsT0FBTyxFQUNMLFdBQVcsR0FDYjtFQUNBLFFBQVEsQ0FBQztDQUNYO0NBQ0E7RUFDRSxNQUFNO0VBQ04sS0FBSztFQUNMLE9BQU87RUFDUCxVQUFVO0VBQ1YsS0FBSztFQUNMLFdBQVc7RUFDWCxRQUFRO0dBQ04sTUFBTTtHQUNOLFVBQVU7R0FDVixTQUFTO0dBQ1QsV0FBVztFQUNiO0VBQ0EsT0FBTyxFQUNMLFdBQVcsR0FDYjtFQUNBLFFBQVEsQ0FBQztDQUNYO0NBQ0E7RUFDRSxNQUFNO0VBQ04sS0FBSztFQUNMLE9BQU87R0FDTDtHQUNBO0dBQ0E7RUFDRjtFQUNBLFVBQVU7RUFDVixLQUFLO0VBQ0wsV0FBVztFQUNYLFFBQVE7R0FDTixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVM7R0FDVCxXQUFXO0VBQ2I7RUFDQSxPQUFPLEVBQ0wsV0FBVyxHQUNiO0VBQ0EsUUFBUSxDQUFDO0NBQ1g7Q0FDQTtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsV0FBVztFQUNYLFFBQVE7R0FDTixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVM7R0FDVCxXQUFXO0VBQ2I7RUFDQSxPQUFPLEVBQ0wsV0FBVyxHQUNiO0VBQ0EsUUFBUSxDQUFDO0NBQ1g7Q0FDQTtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTztFQUNQLFVBQVU7RUFDVixLQUFLO0VBQ0wsV0FBVztFQUNYLFFBQVE7R0FDTixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVM7R0FDVCxXQUFXO0VBQ2I7RUFDQSxPQUFPLEVBQ0wsV0FBVyxHQUNiO0VBQ0EsUUFBUSxDQUFDO0NBQ1g7QUFDRiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJpbWFnZXMudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBBcnJheWFibGUsIEdhbGxlcnlJbWFnZSB9IGZyb20gJ34vdHlwZXMnXG5cbmV4cG9ydCBjb25zdCBnYWxsZXJ5SW1hZ2VzOiBBcnJheWFibGU8R2FsbGVyeUltYWdlPiA9IFtcbiAge1xuICAgIG5hbWU6ICdDb3VwZSBzdHlsaW5nIG1pLWxvbmcnLFxuICAgIGFsdDogJ0NvdXBlIHN0eWxpbmcgbWktbG9uZycsXG4gICAgaW1hZ2U6IFtcbiAgICAgICcvaW1hZ2VzL2dhbGxlcnkvY3VzdG9tZXIxLmpwZycsXG4gICAgICAnL2ltYWdlcy9nYWxsZXJ5L2N1c3RvbWVyMi5qcGcnXG4gICAgXSxcbiAgICBjYXRlZ29yeTogJ2ltYWdlJyxcbiAgICB1cmw6IG51bGwsXG4gICAgaXNWaXNpYmxlOiB0cnVlLFxuICAgIGF1dGhvcjoge1xuICAgICAgbmFtZTogJycsXG4gICAgICB1c2VybmFtZTogJycsXG4gICAgICB3ZWJzaXRlOiAnJyxcbiAgICAgIGluc3RhZ3JhbTogJydcbiAgICB9LFxuICAgIG1vZGVsOiB7XG4gICAgICBpbnN0YWdyYW06ICcnXG4gICAgfSxcbiAgICBicmFuZHM6IFtdXG4gIH0sXG4gIHtcbiAgICBuYW1lOiAnQnJ1c2hpbmcgdm9sdW1pbmV1eCcsXG4gICAgYWx0OiAnQnJ1c2hpbmcgdm9sdW1pbmV1eCcsXG4gICAgaW1hZ2U6IFtcbiAgICAgICcvaW1hZ2VzL2dhbGxlcnkvY3VzdG9tZXIxOC5qcGcnLFxuICAgICAgJy9pbWFnZXMvZ2FsbGVyeS9jdXN0b21lcjcxLmpwZWcnXG4gICAgXSxcbiAgICBjYXRlZ29yeTogJ2ltYWdlJyxcbiAgICB1cmw6IG51bGwsXG4gICAgaXNWaXNpYmxlOiB0cnVlLFxuICAgIGF1dGhvcjoge1xuICAgICAgbmFtZTogJycsXG4gICAgICB1c2VybmFtZTogJycsXG4gICAgICB3ZWJzaXRlOiAnJyxcbiAgICAgIGluc3RhZ3JhbTogJydcbiAgICB9LFxuICAgIG1vZGVsOiB7XG4gICAgICBpbnN0YWdyYW06ICcnXG4gICAgfSxcbiAgICBicmFuZHM6IFtdXG4gIH0sXG4gIHtcbiAgICBuYW1lOiAnSGFpciBjb250b3VyaW5nIGNoZXZldXggbG9uZ3MnLFxuICAgIGFsdDogJ0hhaXIgY29udG91cmluZyBjaGV2ZXV4IGxvbmdzJyxcbiAgICBpbWFnZTogW1xuICAgICAgJy9pbWFnZXMvZ2FsbGVyeS9jdXN0b21lcjMyLmpwZycsXG4gICAgICAnL2ltYWdlcy9nYWxsZXJ5L2N1c3RvbWVyMzMuanBnJ1xuICAgIF0sXG4gICAgY2F0ZWdvcnk6ICdpbWFnZScsXG4gICAgdXJsOiBudWxsLFxuICAgIGlzVmlzaWJsZTogdHJ1ZSxcbiAgICBhdXRob3I6IHtcbiAgICAgIG5hbWU6ICcnLFxuICAgICAgdXNlcm5hbWU6ICcnLFxuICAgICAgd2Vic2l0ZTogJycsXG4gICAgICBpbnN0YWdyYW06ICcnXG4gICAgfSxcbiAgICBtb2RlbDoge1xuICAgICAgaW5zdGFncmFtOiAnJ1xuICAgIH0sXG4gICAgYnJhbmRzOiBbXVxuICB9LFxuICB7XG4gICAgbmFtZTogJ1NvaW4gw6AgbGEgS8OpcmF0aW5lIGV0IGNvdWxldXInLFxuICAgIGFsdDogJ1NvaW4gw6AgbGEgS8OpcmF0aW5lIGV0IGNvdWxldXInLFxuICAgIGltYWdlOiAnL2ltYWdlcy9nYWxsZXJ5L2N1c3RvbWVyMy5qcGcnLFxuICAgIGNhdGVnb3J5OiAnaW1hZ2UnLFxuICAgIHVybDogbnVsbCxcbiAgICBpc1Zpc2libGU6IHRydWUsXG4gICAgYXV0aG9yOiB7XG4gICAgICBuYW1lOiAnJyxcbiAgICAgIHVzZXJuYW1lOiAnJyxcbiAgICAgIHdlYnNpdGU6ICcnLFxuICAgICAgaW5zdGFncmFtOiAnJ1xuICAgIH0sXG4gICAgbW9kZWw6IHtcbiAgICAgIGluc3RhZ3JhbTogJydcbiAgICB9LFxuICAgIGJyYW5kczogW11cbiAgfSxcbiAge1xuICAgIG5hbWU6ICdDb3VwZSBkw6lncmFkw6llJyxcbiAgICBhbHQ6ICdDb3VwZSBkw6lncmFkw6llJyxcbiAgICBpbWFnZTogJy9pbWFnZXMvZ2FsbGVyeS9jdXN0b21lcjYuanBnJyxcbiAgICBjYXRlZ29yeTogJ2ltYWdlJyxcbiAgICB1cmw6IG51bGwsXG4gICAgaXNWaXNpYmxlOiBmYWxzZSxcbiAgICBhdXRob3I6IHtcbiAgICAgIG5hbWU6ICcnLFxuICAgICAgdXNlcm5hbWU6ICcnLFxuICAgICAgd2Vic2l0ZTogJycsXG4gICAgICBpbnN0YWdyYW06ICcnXG4gICAgfSxcbiAgICBtb2RlbDoge1xuICAgICAgaW5zdGFncmFtOiAnJ1xuICAgIH0sXG4gICAgYnJhbmRzOiBbXVxuICB9LFxuICB7XG4gICAgbmFtZTogJ0JydXNoaW5nIFdhdnkgY2hldmV1eCBYTCcsXG4gICAgYWx0OiAnQnJ1c2hpbmcgV2F2eSBjaGV2ZXV4IFhMJyxcbiAgICBpbWFnZTogJy9pbWFnZXMvZ2FsbGVyeS9jdXN0b21lcjcuanBnJyxcbiAgICBjYXRlZ29yeTogJ2ltYWdlJyxcbiAgICB1cmw6IG51bGwsXG4gICAgaXNWaXNpYmxlOiB0cnVlLFxuICAgIGF1dGhvcjoge1xuICAgICAgbmFtZTogJycsXG4gICAgICB1c2VybmFtZTogJycsXG4gICAgICB3ZWJzaXRlOiAnJyxcbiAgICAgIGluc3RhZ3JhbTogJydcbiAgICB9LFxuICAgIG1vZGVsOiB7XG4gICAgICBpbnN0YWdyYW06ICcnXG4gICAgfSxcbiAgICBicmFuZHM6IFtdXG4gIH0sXG4gIHtcbiAgICBuYW1lOiAnQ291cGUgY29pZmZhZ2UgY2hldmV1eCBjb3VydHMnLFxuICAgIGFsdDogJ0NvdXBlIGNvaWZmYWdlIGNoZXZldXggY291cnRzJyxcbiAgICBpbWFnZTogJy9pbWFnZXMvZ2FsbGVyeS9jdXN0b21lcjguanBnJyxcbiAgICBjYXRlZ29yeTogJ2ltYWdlJyxcbiAgICB1cmw6IG51bGwsXG4gICAgaXNWaXNpYmxlOiB0cnVlLFxuICAgIGF1dGhvcjoge1xuICAgICAgbmFtZTogJycsXG4gICAgICB1c2VybmFtZTogJycsXG4gICAgICB3ZWJzaXRlOiAnJyxcbiAgICAgIGluc3RhZ3JhbTogJydcbiAgICB9LFxuICAgIG1vZGVsOiB7XG4gICAgICBpbnN0YWdyYW06ICcnXG4gICAgfSxcbiAgICBicmFuZHM6IFtdXG4gIH0sXG4gIHtcbiAgICBuYW1lOiAnQ2hpZ25vbiDDqWzDqWdhbnQnLFxuICAgIGFsdDogJ0NoaWdub24gw6lsw6lnYW50JyxcbiAgICBpbWFnZTogJy9pbWFnZXMvZ2FsbGVyeS9jdXN0b21lcjkuanBnJyxcbiAgICBjYXRlZ29yeTogJ2ltYWdlJyxcbiAgICB1cmw6IG51bGwsXG4gICAgaXNWaXNpYmxlOiBmYWxzZSxcbiAgICBhdXRob3I6IHtcbiAgICAgIG5hbWU6ICcnLFxuICAgICAgdXNlcm5hbWU6ICcnLFxuICAgICAgd2Vic2l0ZTogJycsXG4gICAgICBpbnN0YWdyYW06ICcnXG4gICAgfSxcbiAgICBtb2RlbDoge1xuICAgICAgaW5zdGFncmFtOiAnJ1xuICAgIH0sXG4gICAgYnJhbmRzOiBbXVxuICB9LFxuICB7XG4gICAgbmFtZTogJ1NoYW1wb2luZyBjb3VwZSBicnVzaGluZyB3YXZ5IGNoZXZldXggbG9uZ3MnLFxuICAgIGFsdDogJ1NoYW1wb2luZyBjb3VwZSBicnVzaGluZyB3YXZ5IGNoZXZldXggbG9uZ3MnLFxuICAgIGltYWdlOiAnL2ltYWdlcy9nYWxsZXJ5L2N1c3RvbWVyMTkuanBnJyxcbiAgICBjYXRlZ29yeTogJ2ltYWdlJyxcbiAgICB1cmw6IG51bGwsXG4gICAgaXNWaXNpYmxlOiB0cnVlLFxuICAgIGF1dGhvcjoge1xuICAgICAgbmFtZTogJycsXG4gICAgICB1c2VybmFtZTogJycsXG4gICAgICB3ZWJzaXRlOiAnJyxcbiAgICAgIGluc3RhZ3JhbTogJydcbiAgICB9LFxuICAgIG1vZGVsOiB7XG4gICAgICBpbnN0YWdyYW06ICcnXG4gICAgfSxcbiAgICBicmFuZHM6IFtdXG4gIH0sXG4gIHtcbiAgICBuYW1lOiAnU2hhbXBvaW5nIGNvdXBlIHN0eWxpbmcnLFxuICAgIGFsdDogJ1NoYW1wb2luZyBjb3VwZSBzdHlsaW5nJyxcbiAgICBpbWFnZTogJy9pbWFnZXMvZ2FsbGVyeS9jdXN0b21lcjIzLmpwZycsXG4gICAgY2F0ZWdvcnk6ICdpbWFnZScsXG4gICAgdXJsOiBudWxsLFxuICAgIGlzVmlzaWJsZTogdHJ1ZSxcbiAgICBhdXRob3I6IHtcbiAgICAgIG5hbWU6ICcnLFxuICAgICAgdXNlcm5hbWU6ICcnLFxuICAgICAgd2Vic2l0ZTogJycsXG4gICAgICBpbnN0YWdyYW06ICcnXG4gICAgfSxcbiAgICBtb2RlbDoge1xuICAgICAgaW5zdGFncmFtOiAnJ1xuICAgIH0sXG4gICAgYnJhbmRzOiBbXVxuICB9LFxuICB7XG4gICAgbmFtZTogJ0NvdWxldXIgY291cGUgYnJ1c2hpbmcgd2F2eSBjaGV2ZXV4IGxvbmdzJyxcbiAgICBhbHQ6ICdDb3VsZXVyIGNvdXBlIGJydXNoaW5nIHdhdnkgY2hldmV1eCBsb25ncycsXG4gICAgaW1hZ2U6ICcvaW1hZ2VzL2dhbGxlcnkvY3VzdG9tZXIxMS5qcGcnLFxuICAgIGNhdGVnb3J5OiAnaW1hZ2UnLFxuICAgIHVybDogbnVsbCxcbiAgICBpc1Zpc2libGU6IHRydWUsXG4gICAgYXV0aG9yOiB7XG4gICAgICBuYW1lOiAnJyxcbiAgICAgIHVzZXJuYW1lOiAnJyxcbiAgICAgIHdlYnNpdGU6ICcnLFxuICAgICAgaW5zdGFncmFtOiAnJ1xuICAgIH0sXG4gICAgbW9kZWw6IHtcbiAgICAgIGluc3RhZ3JhbTogJydcbiAgICB9LFxuICAgIGJyYW5kczogW11cbiAgfSxcbiAge1xuICAgIG5hbWU6ICdDb3VwZSBmcmFuZ2UgcmlkZWF1IGNoZXZldXggbWktbG9uZ3MnLFxuICAgIGFsdDogJ0NvdXBlIGZyYW5nZSByaWRlYXUgY2hldmV1eCBtaS1sb25ncycsXG4gICAgaW1hZ2U6IFtcbiAgICAgICcvaW1hZ2VzL2dhbGxlcnkvY3VzdG9tZXIxMy5qcGcnLFxuICAgICAgJy9pbWFnZXMvZ2FsbGVyeS9jdXN0b21lcjE0LmpwZydcbiAgICBdLFxuICAgIGNhdGVnb3J5OiAnaW1hZ2UnLFxuICAgIHVybDogbnVsbCxcbiAgICBpc1Zpc2libGU6IHRydWUsXG4gICAgYXV0aG9yOiB7XG4gICAgICBuYW1lOiAnJyxcbiAgICAgIHVzZXJuYW1lOiAnJyxcbiAgICAgIHdlYnNpdGU6ICcnLFxuICAgICAgaW5zdGFncmFtOiAnJ1xuICAgIH0sXG4gICAgbW9kZWw6IHtcbiAgICAgIGluc3RhZ3JhbTogJydcbiAgICB9LFxuICAgIGJyYW5kczogW11cbiAgfSxcbiAge1xuICAgIG5hbWU6ICdTdHlsaW5nIFhMJyxcbiAgICBhbHQ6ICdTdHlsaW5nIFhMJyxcbiAgICBpbWFnZTogW1xuICAgICAgJy9pbWFnZXMvZ2FsbGVyeS9jdXN0b21lcjI5LmpwZycsXG4gICAgICAnL2ltYWdlcy9nYWxsZXJ5L2N1c3RvbWVyMzAuanBnJ1xuICAgIF0sXG4gICAgY2F0ZWdvcnk6ICdpbWFnZScsXG4gICAgdXJsOiBudWxsLFxuICAgIGlzVmlzaWJsZTogdHJ1ZSxcbiAgICBhdXRob3I6IHtcbiAgICAgIG5hbWU6ICcnLFxuICAgICAgdXNlcm5hbWU6ICcnLFxuICAgICAgd2Vic2l0ZTogJycsXG4gICAgICBpbnN0YWdyYW06ICcnXG4gICAgfSxcbiAgICBtb2RlbDoge1xuICAgICAgaW5zdGFncmFtOiAnJ1xuICAgIH0sXG4gICAgYnJhbmRzOiBbXVxuICB9LFxuICB7XG4gICAgbmFtZTogJ0NvbG9yYXRpb24gcmVwb3Vzc2UgbG9uZ3VldXIgY2hldmV1eCBtaS1sb25ncycsXG4gICAgYWx0OiAnQ29sb3JhdGlvbiByZXBvdXNzZSBsb25ndWV1ciBjaGV2ZXV4IG1pLWxvbmdzJyxcbiAgICBpbWFnZTogW1xuICAgICAgJy9pbWFnZXMvZ2FsbGVyeS9jdXN0b21lcjI0LmpwZycsXG4gICAgICAnL2ltYWdlcy9nYWxsZXJ5L2N1c3RvbWVyMjUuanBnJ1xuICAgIF0sXG4gICAgY2F0ZWdvcnk6ICdpbWFnZScsXG4gICAgdXJsOiBudWxsLFxuICAgIGlzVmlzaWJsZTogdHJ1ZSxcbiAgICBhdXRob3I6IHtcbiAgICAgIG5hbWU6ICcnLFxuICAgICAgdXNlcm5hbWU6ICcnLFxuICAgICAgd2Vic2l0ZTogJycsXG4gICAgICBpbnN0YWdyYW06ICcnXG4gICAgfSxcbiAgICBtb2RlbDoge1xuICAgICAgaW5zdGFncmFtOiAnJ1xuICAgIH0sXG4gICAgYnJhbmRzOiBbXVxuICB9LFxuICB7XG4gICAgbmFtZTogJ1N0eWxpbmcgWEwnLFxuICAgIGFsdDogJ1N0eWxpbmcgWEwnLFxuICAgIGltYWdlOiAnL2ltYWdlcy9nYWxsZXJ5L2N1c3RvbWVyMzQuanBnJyxcbiAgICBjYXRlZ29yeTogJ2ltYWdlJyxcbiAgICB1cmw6IG51bGwsXG4gICAgaXNWaXNpYmxlOiB0cnVlLFxuICAgIGF1dGhvcjoge1xuICAgICAgbmFtZTogJycsXG4gICAgICB1c2VybmFtZTogJycsXG4gICAgICB3ZWJzaXRlOiAnJyxcbiAgICAgIGluc3RhZ3JhbTogJydcbiAgICB9LFxuICAgIG1vZGVsOiB7XG4gICAgICBpbnN0YWdyYW06ICcnXG4gICAgfSxcbiAgICBicmFuZHM6IFtdXG4gIH0sXG4gIHtcbiAgICBuYW1lOiAnQ2hpZ25vbicsXG4gICAgYWx0OiAnQ2hpZ25vbicsXG4gICAgaW1hZ2U6ICcvaW1hZ2VzL2dhbGxlcnkvY3VzdG9tZXIzNS5qcGcnLFxuICAgIGNhdGVnb3J5OiAnaW1hZ2UnLFxuICAgIHVybDogbnVsbCxcbiAgICBpc1Zpc2libGU6IHRydWUsXG4gICAgYXV0aG9yOiB7XG4gICAgICBuYW1lOiAnJyxcbiAgICAgIHVzZXJuYW1lOiAnJyxcbiAgICAgIHdlYnNpdGU6ICcnLFxuICAgICAgaW5zdGFncmFtOiAnJ1xuICAgIH0sXG4gICAgbW9kZWw6IHtcbiAgICAgIGluc3RhZ3JhbTogJydcbiAgICB9LFxuICAgIGJyYW5kczogW11cbiAgfSxcbiAge1xuICAgIG5hbWU6ICdUZXN0IFZpZGVvJyxcbiAgICBhbHQ6ICdUZXN0IFZpZGVvJyxcbiAgICBpbWFnZTogJy92aWQxLm1vdicsXG4gICAgY2F0ZWdvcnk6ICd2aWRlbycsXG4gICAgdXJsOiBudWxsLFxuICAgIGlzVmlzaWJsZTogZmFsc2UsXG4gICAgYXV0aG9yOiB7XG4gICAgICBuYW1lOiAnJyxcbiAgICAgIHVzZXJuYW1lOiAnJyxcbiAgICAgIHdlYnNpdGU6ICcnLFxuICAgICAgaW5zdGFncmFtOiAnJ1xuICAgIH0sXG4gICAgbW9kZWw6IHtcbiAgICAgIGluc3RhZ3JhbTogJydcbiAgICB9LFxuICAgIGJyYW5kczogW11cbiAgfSxcbiAge1xuICAgIG5hbWU6ICdTb2luIEvDqXJhdGluZSBWw6lnw6l0YWxlJyxcbiAgICBhbHQ6ICdTb2luIEvDqXJhdGluZSBWw6lnw6l0YWxlJyxcbiAgICBpbWFnZTogW1xuICAgICAgJy9pbWFnZXMva2lyYS9waG90b3Nob290NDYtc21hbGwud2VicCcsXG4gICAgICAnL2ltYWdlcy9raXJhL3Bob3Rvc2hvb3Q0NS5qcGcnLFxuICAgICAgJy9pbWFnZXMva2lyYS9waG90b3Nob290NDYuanBnJyxcbiAgICAgICcvaW1hZ2VzL2tpcmEvcGhvdG9zaG9vdDE5LmpwZycsXG4gICAgICAnL2ltYWdlcy9raXJhL3Bob3Rvc2hvb3QyMC5qcGcnLFxuICAgICAgJy9pbWFnZXMva2lyYS9waG90b3Nob290Mi5qcGcnLFxuICAgICAgJy9pbWFnZXMva2lyYS9waG90b3Nob290MS5qcGcnXG4gICAgXSxcbiAgICBjYXRlZ29yeTogJ2ltYWdlJyxcbiAgICB1cmw6IG51bGwsXG4gICAgaXNWaXNpYmxlOiB0cnVlLFxuICAgIGF1dGhvcjoge1xuICAgICAgbmFtZTogJycsXG4gICAgICB1c2VybmFtZTogJycsXG4gICAgICB3ZWJzaXRlOiAnJyxcbiAgICAgIGluc3RhZ3JhbTogJ19raHJlYXRlXydcbiAgICB9LFxuICAgIG1vZGVsOiB7XG4gICAgICBpbnN0YWdyYW06ICdtZWlfbGluaGNvbnRlJ1xuICAgIH0sXG4gICAgYnJhbmRzOiBbXVxuICB9LFxuICB7XG4gICAgbmFtZTogJ1NvaW4gS8OpcmF0aW5lIFbDqWfDqXRhbGUnLFxuICAgIGFsdDogJ1NvaW4gS8OpcmF0aW5lIFbDqWfDqXRhbGUnLFxuICAgIGltYWdlOiBbXG4gICAgICAnL2ltYWdlcy9nYWxsZXJ5L2N1c3RvbWVyMzYtc21hbGwud2VicCcsXG4gICAgICAnL2ltYWdlcy9nYWxsZXJ5L2N1c3RvbWVyMzctc21hbGwud2VicCcsXG4gICAgICAnL2ltYWdlcy9nYWxsZXJ5L2N1c3RvbWVyMzgtc21hbGwud2VicCdcbiAgICBdLFxuICAgIGNhdGVnb3J5OiAnaW1hZ2UnLFxuICAgIHVybDogbnVsbCxcbiAgICBpc1Zpc2libGU6IHRydWUsXG4gICAgYXV0aG9yOiB7XG4gICAgICBuYW1lOiAnJyxcbiAgICAgIHVzZXJuYW1lOiAnJyxcbiAgICAgIHdlYnNpdGU6ICcnLFxuICAgICAgaW5zdGFncmFtOiAnJ1xuICAgIH0sXG4gICAgbW9kZWw6IHtcbiAgICAgIGluc3RhZ3JhbTogJydcbiAgICB9LFxuICAgIGJyYW5kczogW11cbiAgfSxcbiAge1xuICAgIG5hbWU6ICdNaXNlIGVuIGZvcm1lIGJvdWNsZXMnLFxuICAgIGFsdDogJ01pc2UgZW4gZm9ybWUgYm91Y2xlcycsXG4gICAgaW1hZ2U6ICcvaW1hZ2VzL2dhbGxlcnkvY3VzdG9tZXIzOS1zbWFsbC53ZWJwJyxcbiAgICBjYXRlZ29yeTogJ2ltYWdlJyxcbiAgICB1cmw6IG51bGwsXG4gICAgaXNWaXNpYmxlOiB0cnVlLFxuICAgIGF1dGhvcjoge1xuICAgICAgbmFtZTogJycsXG4gICAgICB1c2VybmFtZTogJycsXG4gICAgICB3ZWJzaXRlOiAnJyxcbiAgICAgIGluc3RhZ3JhbTogJydcbiAgICB9LFxuICAgIG1vZGVsOiB7XG4gICAgICBpbnN0YWdyYW06ICcnXG4gICAgfSxcbiAgICBicmFuZHM6IFtdXG4gIH0sXG4gIHtcbiAgICBuYW1lOiAnTWlzZSBlbiBmb3JtZSBib3VjbGVzJyxcbiAgICBhbHQ6ICdNaXNlIGVuIGZvcm1lIGJvdWNsZXMnLFxuICAgIGltYWdlOiAnL2ltYWdlcy9nYWxsZXJ5L2N1c3RvbWVyNDAtc21hbGwud2VicCcsXG4gICAgY2F0ZWdvcnk6ICdpbWFnZScsXG4gICAgdXJsOiBudWxsLFxuICAgIGlzVmlzaWJsZTogdHJ1ZSxcbiAgICBhdXRob3I6IHtcbiAgICAgIG5hbWU6ICcnLFxuICAgICAgdXNlcm5hbWU6ICcnLFxuICAgICAgd2Vic2l0ZTogJycsXG4gICAgICBpbnN0YWdyYW06ICcnXG4gICAgfSxcbiAgICBtb2RlbDoge1xuICAgICAgaW5zdGFncmFtOiAnJ1xuICAgIH0sXG4gICAgYnJhbmRzOiBbXVxuICB9LFxuICB7XG4gICAgbmFtZTogJ01pc2UgZW4gZm9ybWUgYm91Y2xlcyAzJyxcbiAgICBhbHQ6ICdNaXNlIGVuIGZvcm1lIGJvdWNsZXMgMycsXG4gICAgaW1hZ2U6IFtcbiAgICAgICcvaW1hZ2VzL2dhbGxlcnkvY3VzdG9tZXI0MS1zbWFsbC53ZWJwJyxcbiAgICAgICcvaW1hZ2VzL2dhbGxlcnkvY3VzdG9tZXI0Mi5qcGcnLFxuICAgICAgJy9pbWFnZXMvZ2FsbGVyeS9jdXN0b21lcjQ0LXNtYWxsLndlYnAnXG4gICAgXSxcbiAgICBjYXRlZ29yeTogJ2ltYWdlJyxcbiAgICB1cmw6IG51bGwsXG4gICAgaXNWaXNpYmxlOiB0cnVlLFxuICAgIGF1dGhvcjoge1xuICAgICAgbmFtZTogJycsXG4gICAgICB1c2VybmFtZTogJycsXG4gICAgICB3ZWJzaXRlOiAnJyxcbiAgICAgIGluc3RhZ3JhbTogJ19raHJlYXRlXydcbiAgICB9LFxuICAgIG1vZGVsOiB7XG4gICAgICBpbnN0YWdyYW06ICcnXG4gICAgfSxcbiAgICBicmFuZHM6IFtdXG4gIH0sXG4gIHtcbiAgICBuYW1lOiAnTWlzZSBlbiBmb3JtZSBib3VjbGVzJyxcbiAgICBhbHQ6ICdNaXNlIGVuIGZvcm1lIGJvdWNsZXMnLFxuICAgIGltYWdlOiAnL2ltYWdlcy9nYWxsZXJ5L2N1c3RvbWVyNjItc21hbGwud2VicCcsXG4gICAgY2F0ZWdvcnk6ICdpbWFnZScsXG4gICAgdXJsOiBudWxsLFxuICAgIGlzVmlzaWJsZTogdHJ1ZSxcbiAgICBhdXRob3I6IHtcbiAgICAgIG5hbWU6ICcnLFxuICAgICAgdXNlcm5hbWU6ICcnLFxuICAgICAgd2Vic2l0ZTogJycsXG4gICAgICBpbnN0YWdyYW06ICcnXG4gICAgfSxcbiAgICBtb2RlbDoge1xuICAgICAgaW5zdGFncmFtOiAnJ1xuICAgIH0sXG4gICAgYnJhbmRzOiBbXVxuICB9LFxuICB7XG4gICAgbmFtZTogJ01pc2UgZW4gZm9ybWUgYm91Y2xlcycsXG4gICAgYWx0OiAnTWlzZSBlbiBmb3JtZSBib3VjbGVzJyxcbiAgICBpbWFnZTogJy9pbWFnZXMvZ2FsbGVyeS9jdXN0b21lcjcyLXNtYWxsLndlYnAnLFxuICAgIGNhdGVnb3J5OiAnaW1hZ2UnLFxuICAgIHVybDogbnVsbCxcbiAgICBpc1Zpc2libGU6IHRydWUsXG4gICAgYXV0aG9yOiB7XG4gICAgICBuYW1lOiAnJyxcbiAgICAgIHVzZXJuYW1lOiAnJyxcbiAgICAgIHdlYnNpdGU6ICcnLFxuICAgICAgaW5zdGFncmFtOiAnJ1xuICAgIH0sXG4gICAgbW9kZWw6IHtcbiAgICAgIGluc3RhZ3JhbTogJydcbiAgICB9LFxuICAgIGJyYW5kczogW11cbiAgfVxuXVxuIl19