import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/components/hero/SectionReviews.vue");import { default as __nuxt_component_0 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/components/client-only.js?v=7e73afc2";
import { default as __nuxt_component_1 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+icon@2.4.1_magic-string@0.30.21_magicast@0.5.4_oxc-parser@0.142.0_rolldown@1.2.2__bc09e636b3a0e451fd4fcea89c56910f/node_modules/@nuxt/icon/dist/runtime/components/index.js?v=7e73afc2";
import { default as __nuxt_component_2 } from "/_nuxt/components/volt/Divider.vue";
import { default as __nuxt_component_3 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+image@2.1.0_@types+node@26.1.2_magic-string@1.1.0_magicast@0.5.4_oxc-parser@0.142_8c2f52bee20945aa2ec4d2e10b1999d3/node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue";
import { useReviewsComposable as _$__useReviewsComposable } from "/_nuxt/composables/reviews.ts";;import { __nuxtTimelineWrap } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+devtools@3.4.1_db0@0.3.4_better-sqlite3@13.0.2_drizzle-orm@0.45.2_@opentelemetry+_0e55243a794e05cb19a29a0506aae086/node_modules/@nuxt/devtools/dist/runtime/function-metrics-helpers.js?v=7e73afc2";const useReviewsComposable = __nuxtTimelineWrap("useReviewsComposable", _$__useReviewsComposable);
import { createElementId as __unimport_createElementId } from "/_nuxt/utils/ids.ts";
import { unref as __unimport_unref_ } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@8.2.0_@types+node@26.1.2_esbuild@0.28.1_jiti@2.7.0_sa_bcac4fa99282966dd94ca7ad2dfebde1/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=7e73afc2"
import { defineComponent as _defineComponent } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _sfc_main = /*@__PURE__*/ _defineComponent({
	__name: "HeroSectionReviews",
	setup(__props, { expose: __expose }) {
		__expose();
		/**
		* Reviews
		*/
		const { reviews, selectedReview, selectReview } = useReviewsComposable();
		/**
		* SEO
		*/
		// const { get } = useBusinessDetails()
		// useSchemaOrg(
		//   reviews.map(review => defineReview({
		//     author: {
		//       '@type': 'Person',
		//       'givenName': review.reviewer.givenName,
		//       'familyName': review.reviewer.familyName,
		//       'name': review.reviewer.name
		//     },
		//     itemReviewed: {
		//       '@type': 'BeautySalon',
		//       'name': get('legalName')
		//     },
		//     reviewBody: review.comment,
		//     reviewRating: {
		//       ratingValue: review.rating.toString(),
		//       bestRating: review.rating.toString(),
		//       worstRating: '1'
		//     }
		//   }))
		// )
		const __returned__ = {
			reviews,
			selectedReview,
			selectReview
		};
		Object.defineProperty(__returned__, "__isScriptSetup", {
			enumerable: false,
			value: true
		});
		return __returned__;
	}
});
import { toDisplayString as _toDisplayString, createTextVNode as _createTextVNode, resolveDirective as _resolveDirective, openBlock as _openBlock, createElementBlock as _createElementBlock, withDirectives as _withDirectives, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, createElementVNode as _createElementVNode, renderList as _renderList, Fragment as _Fragment, createBlock as _createBlock, createCommentVNode as _createCommentVNode } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _hoisted_1 = { class: "px-5 py-20 md:p-20 text-primary-100 bg-primary-500" };
const _hoisted_2 = { class: "mb-10 text-center max-w-3xl mx-auto" };
const _hoisted_3 = {
	delay: 400,
	enter: { transition: {
		type: "spring",
		stiffness: 20
	} },
	class: "text-3xl xl:text-5xl mb-5"
};
const _hoisted_4 = { class: "flex flex-wrap justify-center text-left gap-5 xl:gap-10 text-primary-500" };
const _hoisted_5 = ["onClick"];
const _hoisted_6 = ["id"];
const _hoisted_7 = { id: "review-rating" };
const _hoisted_8 = {
	key: 1,
	class: "font-thin leading-5 text-sm w-full h-25 overflow-hidden text-ellipsis"
};
const _hoisted_9 = { class: "flex items-center space-x-5 mt-5" };
const _hoisted_10 = { class: "space-y-0" };
const _hoisted_11 = { class: "font-bold" };
const _hoisted_12 = {
	key: 0,
	class: "text-sm font-thin"
};
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
	const _component_client_only = __nuxt_component_0;
	const _component_icon = __nuxt_component_1;
	const _component_volt_divider = __nuxt_component_2;
	const _component_nuxt_img = __nuxt_component_3;
	const _directive_motion_slide_visible_once_bottom = _resolveDirective("motion-slide-visible-once-bottom");
	return _openBlock(), _tracer(2,2,_createElementBlock("section", _hoisted_1, [_tracer(3,4,_createElementVNode("div", _hoisted_2, [_tracer(4,6,_createVNode(_component_client_only, null, {
		default: _withCtx(() => [_withDirectives((_openBlock(), _tracer(5,8,_createElementBlock("h3", _hoisted_3, [_createTextVNode(
			_toDisplayString(_ctx.$t("Ce que pensent mes clients")),
			1
			/* TEXT */
		)]))), [[_directive_motion_slide_visible_once_bottom]])]),
		_: 1
	})), _tracer(10,6,_createElementVNode(
		"p",
		null,
		_toDisplayString(_ctx.$t("Voici ce que mes clients pensent de moi. Je suis toujours à la recherche de moyens pour m'améliorer. Si vous avez une expérience positive avec moi, laissez un avis.")),
		1
		/* TEXT */
	))])), _tracer(15,4,_createElementVNode("div", _hoisted_4, [(_openBlock(true), _tracer(16,6,_createElementBlock(
		_Fragment,
		null,
		_renderList($setup.reviews, (review, idx) => {
			return _openBlock(), _tracer(16,6,_createElementBlock("article", {
				key: idx,
				class: "flex flex-col justify-left shadow-md rounded-xl bg-primary-200 dark:bg-primary-800",
				onClick: ($event) => $setup.selectReview(review)
			}, [_tracer(17,8,_createElementVNode("div", {
				id: ("createElementId" in _ctx ? _ctx.createElementId : __unimport_unref_(__unimport_createElementId))("review", null, idx.toString()),
				class: "flex flex-col justify-between p-5 max-w-70"
			}, [
				_tracer(18,10,_createElementVNode("div", _hoisted_7, [(_openBlock(true), _tracer(19,12,_createElementBlock(
					_Fragment,
					null,
					_renderList(review.rating, (i) => {
						return _openBlock(), _tracer(19,12,_createBlock(_component_icon, {
							key: i,
							name: "lucide:star"
						}));
					}),
					128
					/* KEYED_FRAGMENT */
				)))])),
				$setup.selectedReview && $setup.selectedReview.reviewer.name === review.reviewer.name ? (_openBlock(), _tracer(22,10,_createElementBlock(
					"div",
					{
						key: 0,
						class: "font-thin leading-5 text-sm w-full h-25 overflow-scroll",
						onClick: _cache[0] || (_cache[0] = ($event) => $setup.selectReview(null))
					},
					" \"" + _toDisplayString(review.comment) + "\" ",
					1
					/* TEXT */
				))) : (_openBlock(), _tracer(26,10,_createElementBlock(
					"div",
					_hoisted_8,
					" \"" + _toDisplayString(review.comment) + "\" ",
					1
					/* TEXT */
				))),
				_tracer(30,10,_createVNode(_component_volt_divider)),
				_tracer(32,10,_createElementVNode("div", _hoisted_9, [_tracer(33,12,_createVNode(_component_nuxt_img, {
					src: review.reviewer.avatar || "/placeholder2.svg",
					size: "large",
					class: "w-10 h-10 rounded-full"
				}, null, 8, ["src"])), _tracer(34,12,_createElementVNode("div", _hoisted_10, [_tracer(35,14,_createElementVNode(
					"h2",
					_hoisted_11,
					_toDisplayString(review.reviewer.name),
					1
					/* TEXT */
				)), review.reviewer.title ? (_openBlock(), _tracer(38,14,_createElementBlock(
					"p",
					_hoisted_12,
					_toDisplayString(review.reviewer.title),
					1
					/* TEXT */
				))) : _createCommentVNode("v-if", true)]))]))
			], 8, _hoisted_6))], 8, _hoisted_5));
		}),
		128
		/* KEYED_FRAGMENT */
	)))]))]));
}
_sfc_main.__hmrId = "52298c4c";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.on("file-changed", ({ file }) => {
	__VUE_HMR_RUNTIME__.CHANGED_FILE = file;
});
import.meta.hot.accept((mod) => {
	if (!mod) return;
	const { default: updated, _rerender_only } = mod;
	if (_rerender_only) {
		__VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
	} else {
		__VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
	}
});
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper";
export default /*#__PURE__*/ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "/Volumes/Coding/Projects/Websites/ineiah/frontend/app/components/hero/SectionReviews.vue"]]);

function _tracer(line, column, vnode) { return _tracerRecordPosition("app/components/hero/SectionReviews.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0VBcURBLE1BQU0sRUFBRSxTQUFTLGdCQUFnQixpQkFBaUIscUJBQXFCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXBENUQsNEJBQU0scURBQW9EO0FBQzVELDRCQUFNLHNDQUFxQzs7Q0FFSixPQUFPO0NBQU0sT0FBTztFQUFBO0VBQUE7Q0FBQTtDQUFtRCxPQUFNOztBQVVwSCw0QkFBTSwyRUFBMEU7OztBQUcxRSx5QkFBRyxnQkFBZTs7O0NBUVgsT0FBTTs7QUFNYiw0QkFBTSxtQ0FBa0M7QUFFdEMsNkJBQU0sWUFBVztBQUNoQiw2QkFBTSxZQUFXOzs7Q0FHVyxPQUFNOzs7Ozs7OztDQXBDbEQscURBNENVLFdBNUNWLFlBNENVLGFBM0NSLG9CQVVNLE9BVk4sWUFVTSxhQVRKLGFBSWM7RUFIWix3QkFFSyxDQUZMLCtEQUVLLE1BRkwsWUFFSyxDQURBO0dBQUEseUJBQUU7R0FBQTs7RUFBQTs7bUJBSVQ7RUFFSTtFQUFBO0VBQUEsaUJBREMsUUFBRTtFQUFBOztDQUFBLG9CQUlULG9CQThCTSxPQTlCTixZQThCTSxFQTdCSjtFQTRCVTtFQUFBO0VBQUEsWUE1QnVCLGlCQUFoQixRQUFRLFFBQUc7R0FBNUIsc0RBNEJVO0lBNUJpQyxLQUFLO0lBQUssT0FBTTtJQUFzRixVQUFLLFdBQUUsb0JBQWEsTUFBTTtvQkFDekssb0JBMEJNO0lBMUJBLElBQUksbUdBQWUsZ0JBQWlCLElBQUksU0FBUTtJQUFLLE9BQU07O2tCQUMvRCxvQkFFTSxPQUZOLFlBRU0sRUFESjtLQUErRDtLQUFBO0tBQUEsWUFBN0MsT0FBTyxTQUFaLE1BQUM7TUFBZCxnREFBK0Q7T0FBN0IsS0FBSztPQUFHLE1BQUs7Ozs7OztJQUd0Qyx5QkFBa0Isc0JBQWUsU0FBUyxTQUFTLE9BQU8sU0FBUyxRQUE5RTtLQUVNO0tBQUE7O01BRjhFLE9BQU07TUFBMkQsU0FBSyxzQ0FBRSxvQkFBWTtLQUFRO0tBQUEsUUFDN0ssaUJBQUcsT0FBTyxPQUFPLElBQUc7S0FDdkI7O0lBQUEsT0FFQTtLQUVNO0tBRk47S0FBMEYsUUFDdkYsaUJBQUcsT0FBTyxPQUFPLElBQUc7S0FDdkI7O0lBQUE7a0JBRUEsYUFBZ0I7a0JBRWhCLG9CQVVNLE9BVk4sWUFVTSxlQVRKLGFBQTZHO0tBQWxHLEtBQUssT0FBTyxTQUFTLFVBQU07S0FBeUIsTUFBSztLQUFRLE9BQU07eUNBQ2xGLG9CQU9NLE9BUE4sYUFPTSxlQU5KO0tBRUs7S0FGTDtLQUVLLGlCQURBLE9BQU8sU0FBUyxJQUFJO0tBQUE7O0lBQUEsSUFFaEIsT0FBTyxTQUFTLFNBQXpCO0tBRUk7S0FGSjtLQUVJLGlCQURDLE9BQU8sU0FBUyxLQUFLO0tBQUE7O0lBQUEiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIlNlY3Rpb25SZXZpZXdzLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XG4gIDxzZWN0aW9uIGNsYXNzPVwicHgtNSBweS0yMCBtZDpwLTIwIHRleHQtcHJpbWFyeS0xMDAgYmctcHJpbWFyeS01MDBcIj5cbiAgICA8ZGl2IGNsYXNzPVwibWItMTAgdGV4dC1jZW50ZXIgbWF4LXctM3hsIG14LWF1dG9cIj5cbiAgICAgIDxjbGllbnQtb25seT5cbiAgICAgICAgPGgzIHYtbW90aW9uLXNsaWRlLXZpc2libGUtb25jZS1ib3R0b20gOmRlbGF5PVwiNDAwXCIgOmVudGVyPVwieyB0cmFuc2l0aW9uOiB7IHR5cGU6ICdzcHJpbmcnLCBzdGlmZm5lc3M6IDIwIH0gfVwiIGNsYXNzPVwidGV4dC0zeGwgeGw6dGV4dC01eGwgbWItNVwiPlxuICAgICAgICAgIHt7ICR0KFwiQ2UgcXVlIHBlbnNlbnQgbWVzIGNsaWVudHNcIikgfX1cbiAgICAgICAgPC9oMz5cbiAgICAgIDwvY2xpZW50LW9ubHk+XG5cbiAgICAgIDxwPlxuICAgICAgICB7eyAkdChcIlZvaWNpIGNlIHF1ZSBtZXMgY2xpZW50cyBwZW5zZW50IGRlIG1vaS4gSmUgc3VpcyB0b3Vqb3VycyDDoCBsYSByZWNoZXJjaGUgZGUgbW95ZW5zIHBvdXIgbSdhbcOpbGlvcmVyLiBTaSB2b3VzIGF2ZXogdW5lIGV4cMOpcmllbmNlIHBvc2l0aXZlIGF2ZWMgbW9pLCBsYWlzc2V6IHVuIGF2aXMuXCIpIH19XG4gICAgICA8L3A+XG4gICAgPC9kaXY+XG5cbiAgICA8ZGl2IGNsYXNzPVwiZmxleCBmbGV4LXdyYXAganVzdGlmeS1jZW50ZXIgdGV4dC1sZWZ0IGdhcC01IHhsOmdhcC0xMCB0ZXh0LXByaW1hcnktNTAwXCI+XG4gICAgICA8YXJ0aWNsZSB2LWZvcj1cIihyZXZpZXcsIGlkeCkgaW4gcmV2aWV3c1wiIDprZXk9XCJpZHhcIiBjbGFzcz1cImZsZXggZmxleC1jb2wganVzdGlmeS1sZWZ0IHNoYWRvdy1tZCByb3VuZGVkLXhsIGJnLXByaW1hcnktMjAwIGRhcms6YmctcHJpbWFyeS04MDBcIiBAY2xpY2s9XCJzZWxlY3RSZXZpZXcocmV2aWV3KVwiPlxuICAgICAgICA8ZGl2IDppZD1cImNyZWF0ZUVsZW1lbnRJZCgncmV2aWV3JywgbnVsbCwgaWR4LnRvU3RyaW5nKCkpXCIgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBwLTUgbWF4LXctNzBcIj5cbiAgICAgICAgICA8ZGl2IGlkPVwicmV2aWV3LXJhdGluZ1wiPlxuICAgICAgICAgICAgPGljb24gdi1mb3I9XCJpIGluIHJldmlldy5yYXRpbmdcIiA6a2V5PVwiaVwiIG5hbWU9XCJsdWNpZGU6c3RhclwiIC8+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IHYtaWY9XCJzZWxlY3RlZFJldmlldyAmJiBzZWxlY3RlZFJldmlldy5yZXZpZXdlci5uYW1lID09PSByZXZpZXcucmV2aWV3ZXIubmFtZVwiIGNsYXNzPVwiZm9udC10aGluIGxlYWRpbmctNSB0ZXh0LXNtIHctZnVsbCBoLTI1IG92ZXJmbG93LXNjcm9sbFwiIEBjbGljaz1cInNlbGVjdFJldmlldyhudWxsKVwiPlxuICAgICAgICAgICAgXCJ7eyByZXZpZXcuY29tbWVudCB9fVwiXG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IHYtZWxzZSBjbGFzcz1cImZvbnQtdGhpbiBsZWFkaW5nLTUgdGV4dC1zbSB3LWZ1bGwgaC0yNSBvdmVyZmxvdy1oaWRkZW4gdGV4dC1lbGxpcHNpc1wiPlxuICAgICAgICAgICAgXCJ7eyByZXZpZXcuY29tbWVudCB9fVwiXG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8dm9sdC1kaXZpZGVyIC8+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC01IG10LTVcIj5cbiAgICAgICAgICAgIDxudXh0LWltZyA6c3JjPVwicmV2aWV3LnJldmlld2VyLmF2YXRhciB8fCAnL3BsYWNlaG9sZGVyMi5zdmcnXCIgc2l6ZT1cImxhcmdlXCIgY2xhc3M9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsXCIgLz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJzcGFjZS15LTBcIj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzPVwiZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAge3sgcmV2aWV3LnJldmlld2VyLm5hbWUgfX1cbiAgICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgICAgPHAgdi1pZj1cInJldmlldy5yZXZpZXdlci50aXRsZVwiIGNsYXNzPVwidGV4dC1zbSBmb250LXRoaW5cIj5cbiAgICAgICAgICAgICAgICB7eyByZXZpZXcucmV2aWV3ZXIudGl0bGUgfX1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9hcnRpY2xlPlxuICAgIDwvZGl2PlxuICA8L3NlY3Rpb24+XG48L3RlbXBsYXRlPlxuXG48c2NyaXB0IGxhbmc9XCJ0c1wiIHNldHVwPlxuLyoqXG4gKiBSZXZpZXdzXG4gKi9cblxuY29uc3QgeyByZXZpZXdzLCBzZWxlY3RlZFJldmlldywgc2VsZWN0UmV2aWV3IH0gPSB1c2VSZXZpZXdzQ29tcG9zYWJsZSgpXG5cbi8qKlxuICogU0VPXG4gKi9cblxuLy8gY29uc3QgeyBnZXQgfSA9IHVzZUJ1c2luZXNzRGV0YWlscygpXG5cbi8vIHVzZVNjaGVtYU9yZyhcbi8vICAgcmV2aWV3cy5tYXAocmV2aWV3ID0+IGRlZmluZVJldmlldyh7XG4vLyAgICAgYXV0aG9yOiB7XG4vLyAgICAgICAnQHR5cGUnOiAnUGVyc29uJyxcbi8vICAgICAgICdnaXZlbk5hbWUnOiByZXZpZXcucmV2aWV3ZXIuZ2l2ZW5OYW1lLFxuLy8gICAgICAgJ2ZhbWlseU5hbWUnOiByZXZpZXcucmV2aWV3ZXIuZmFtaWx5TmFtZSxcbi8vICAgICAgICduYW1lJzogcmV2aWV3LnJldmlld2VyLm5hbWVcbi8vICAgICB9LFxuLy8gICAgIGl0ZW1SZXZpZXdlZDoge1xuLy8gICAgICAgJ0B0eXBlJzogJ0JlYXV0eVNhbG9uJyxcbi8vICAgICAgICduYW1lJzogZ2V0KCdsZWdhbE5hbWUnKVxuLy8gICAgIH0sXG4vLyAgICAgcmV2aWV3Qm9keTogcmV2aWV3LmNvbW1lbnQsXG4vLyAgICAgcmV2aWV3UmF0aW5nOiB7XG4vLyAgICAgICByYXRpbmdWYWx1ZTogcmV2aWV3LnJhdGluZy50b1N0cmluZygpLFxuLy8gICAgICAgYmVzdFJhdGluZzogcmV2aWV3LnJhdGluZy50b1N0cmluZygpLFxuLy8gICAgICAgd29yc3RSYXRpbmc6ICcxJ1xuLy8gICAgIH1cbi8vICAgfSkpXG4vLyApXG48L3NjcmlwdD5cbiJdLCJmaWxlIjoiL1ZvbHVtZXMvQ29kaW5nL1Byb2plY3RzL1dlYnNpdGVzL2luZWlhaC9mcm9udGVuZC9hcHAvY29tcG9uZW50cy9oZXJvL1NlY3Rpb25SZXZpZXdzLnZ1ZSJ9