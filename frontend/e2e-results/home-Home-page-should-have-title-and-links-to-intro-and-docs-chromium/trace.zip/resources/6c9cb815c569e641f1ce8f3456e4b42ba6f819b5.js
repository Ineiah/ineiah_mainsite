//#region node_modules/.pnpm/tailwind-merge@3.6.0/node_modules/tailwind-merge/dist/bundle-mjs.mjs
/**
* Concatenates two arrays faster than the array spread operator.
*/
var concatArrays = (array1, array2) => {
	const combinedArray = new Array(array1.length + array2.length);
	for (let i = 0; i < array1.length; i++) combinedArray[i] = array1[i];
	for (let i = 0; i < array2.length; i++) combinedArray[array1.length + i] = array2[i];
	return combinedArray;
};
var createClassValidatorObject = (classGroupId, validator) => ({
	classGroupId,
	validator
});
var createClassPartObject = (nextPart = /* @__PURE__ */ new Map(), validators = null, classGroupId) => ({
	nextPart,
	validators,
	classGroupId
});
var CLASS_PART_SEPARATOR = "-";
var EMPTY_CONFLICTS = [];
var ARBITRARY_PROPERTY_PREFIX = "arbitrary..";
var createClassGroupUtils = (config) => {
	const classMap = createClassMap(config);
	const { conflictingClassGroups, conflictingClassGroupModifiers } = config;
	const getClassGroupId = (className) => {
		if (className.startsWith("[") && className.endsWith("]")) return getGroupIdForArbitraryProperty(className);
		const classParts = className.split(CLASS_PART_SEPARATOR);
		return getGroupRecursive(classParts, classParts[0] === "" && classParts.length > 1 ? 1 : 0, classMap);
	};
	const getConflictingClassGroupIds = (classGroupId, hasPostfixModifier) => {
		if (hasPostfixModifier) {
			const modifierConflicts = conflictingClassGroupModifiers[classGroupId];
			const baseConflicts = conflictingClassGroups[classGroupId];
			if (modifierConflicts) {
				if (baseConflicts) return concatArrays(baseConflicts, modifierConflicts);
				return modifierConflicts;
			}
			return baseConflicts || EMPTY_CONFLICTS;
		}
		return conflictingClassGroups[classGroupId] || EMPTY_CONFLICTS;
	};
	return {
		getClassGroupId,
		getConflictingClassGroupIds
	};
};
var getGroupRecursive = (classParts, startIndex, classPartObject) => {
	if (classParts.length - startIndex === 0) return classPartObject.classGroupId;
	const currentClassPart = classParts[startIndex];
	const nextClassPartObject = classPartObject.nextPart.get(currentClassPart);
	if (nextClassPartObject) {
		const result = getGroupRecursive(classParts, startIndex + 1, nextClassPartObject);
		if (result) return result;
	}
	const validators = classPartObject.validators;
	if (validators === null) return;
	const classRest = startIndex === 0 ? classParts.join(CLASS_PART_SEPARATOR) : classParts.slice(startIndex).join(CLASS_PART_SEPARATOR);
	const validatorsLength = validators.length;
	for (let i = 0; i < validatorsLength; i++) {
		const validatorObj = validators[i];
		if (validatorObj.validator(classRest)) return validatorObj.classGroupId;
	}
};
/**
* Get the class group ID for an arbitrary property.
*
* @param className - The class name to get the group ID for. Is expected to be string starting with `[` and ending with `]`.
*/
var getGroupIdForArbitraryProperty = (className) => className.slice(1, -1).indexOf(":") === -1 ? void 0 : (() => {
	const content = className.slice(1, -1);
	const colonIndex = content.indexOf(":");
	const property = content.slice(0, colonIndex);
	return property ? ARBITRARY_PROPERTY_PREFIX + property : void 0;
})();
/**
* Exported for testing only
*/
var createClassMap = (config) => {
	const { theme, classGroups } = config;
	return processClassGroups(classGroups, theme);
};
var processClassGroups = (classGroups, theme) => {
	const classMap = createClassPartObject();
	for (const classGroupId in classGroups) {
		const group = classGroups[classGroupId];
		processClassesRecursively(group, classMap, classGroupId, theme);
	}
	return classMap;
};
var processClassesRecursively = (classGroup, classPartObject, classGroupId, theme) => {
	const len = classGroup.length;
	for (let i = 0; i < len; i++) {
		const classDefinition = classGroup[i];
		processClassDefinition(classDefinition, classPartObject, classGroupId, theme);
	}
};
var processClassDefinition = (classDefinition, classPartObject, classGroupId, theme) => {
	if (typeof classDefinition === "string") {
		processStringDefinition(classDefinition, classPartObject, classGroupId);
		return;
	}
	if (typeof classDefinition === "function") {
		processFunctionDefinition(classDefinition, classPartObject, classGroupId, theme);
		return;
	}
	processObjectDefinition(classDefinition, classPartObject, classGroupId, theme);
};
var processStringDefinition = (classDefinition, classPartObject, classGroupId) => {
	const classPartObjectToEdit = classDefinition === "" ? classPartObject : getPart(classPartObject, classDefinition);
	classPartObjectToEdit.classGroupId = classGroupId;
};
var processFunctionDefinition = (classDefinition, classPartObject, classGroupId, theme) => {
	if (isThemeGetter(classDefinition)) {
		processClassesRecursively(classDefinition(theme), classPartObject, classGroupId, theme);
		return;
	}
	if (classPartObject.validators === null) classPartObject.validators = [];
	classPartObject.validators.push(createClassValidatorObject(classGroupId, classDefinition));
};
var processObjectDefinition = (classDefinition, classPartObject, classGroupId, theme) => {
	const entries = Object.entries(classDefinition);
	const len = entries.length;
	for (let i = 0; i < len; i++) {
		const [key, value] = entries[i];
		processClassesRecursively(value, getPart(classPartObject, key), classGroupId, theme);
	}
};
var getPart = (classPartObject, path) => {
	let current = classPartObject;
	const parts = path.split(CLASS_PART_SEPARATOR);
	const len = parts.length;
	for (let i = 0; i < len; i++) {
		const part = parts[i];
		let next = current.nextPart.get(part);
		if (!next) {
			next = createClassPartObject();
			current.nextPart.set(part, next);
		}
		current = next;
	}
	return current;
};
var isThemeGetter = (func) => "isThemeGetter" in func && func.isThemeGetter === true;
var createLruCache = (maxCacheSize) => {
	if (maxCacheSize < 1) return {
		get: () => void 0,
		set: () => {}
	};
	let cacheSize = 0;
	let cache = Object.create(null);
	let previousCache = Object.create(null);
	const update = (key, value) => {
		cache[key] = value;
		cacheSize++;
		if (cacheSize > maxCacheSize) {
			cacheSize = 0;
			previousCache = cache;
			cache = Object.create(null);
		}
	};
	return {
		get(key) {
			let value = cache[key];
			if (value !== void 0) return value;
			if ((value = previousCache[key]) !== void 0) {
				update(key, value);
				return value;
			}
		},
		set(key, value) {
			if (key in cache) cache[key] = value;
			else update(key, value);
		}
	};
};
var IMPORTANT_MODIFIER = "!";
var MODIFIER_SEPARATOR = ":";
var EMPTY_MODIFIERS = [];
var createResultObject = (modifiers, hasImportantModifier, baseClassName, maybePostfixModifierPosition, isExternal) => ({
	modifiers,
	hasImportantModifier,
	baseClassName,
	maybePostfixModifierPosition,
	isExternal
});
var createParseClassName = (config) => {
	const { prefix, experimentalParseClassName } = config;
	/**
	* Parse class name into parts.
	*
	* Inspired by `splitAtTopLevelOnly` used in Tailwind CSS
	* @see https://github.com/tailwindlabs/tailwindcss/blob/v3.2.2/src/util/splitAtTopLevelOnly.js
	*/
	let parseClassName = (className) => {
		const modifiers = [];
		let bracketDepth = 0;
		let parenDepth = 0;
		let modifierStart = 0;
		let postfixModifierPosition;
		const len = className.length;
		for (let index = 0; index < len; index++) {
			const currentCharacter = className[index];
			if (bracketDepth === 0 && parenDepth === 0) {
				if (currentCharacter === MODIFIER_SEPARATOR) {
					modifiers.push(className.slice(modifierStart, index));
					modifierStart = index + 1;
					continue;
				}
				if (currentCharacter === "/") {
					postfixModifierPosition = index;
					continue;
				}
			}
			if (currentCharacter === "[") bracketDepth++;
			else if (currentCharacter === "]") bracketDepth--;
			else if (currentCharacter === "(") parenDepth++;
			else if (currentCharacter === ")") parenDepth--;
		}
		const baseClassNameWithImportantModifier = modifiers.length === 0 ? className : className.slice(modifierStart);
		let baseClassName = baseClassNameWithImportantModifier;
		let hasImportantModifier = false;
		if (baseClassNameWithImportantModifier.endsWith(IMPORTANT_MODIFIER)) {
			baseClassName = baseClassNameWithImportantModifier.slice(0, -1);
			hasImportantModifier = true;
		} else if (baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER)) {
			baseClassName = baseClassNameWithImportantModifier.slice(1);
			hasImportantModifier = true;
		}
		const maybePostfixModifierPosition = postfixModifierPosition && postfixModifierPosition > modifierStart ? postfixModifierPosition - modifierStart : void 0;
		return createResultObject(modifiers, hasImportantModifier, baseClassName, maybePostfixModifierPosition);
	};
	if (prefix) {
		const fullPrefix = prefix + MODIFIER_SEPARATOR;
		const parseClassNameOriginal = parseClassName;
		parseClassName = (className) => className.startsWith(fullPrefix) ? parseClassNameOriginal(className.slice(fullPrefix.length)) : createResultObject(EMPTY_MODIFIERS, false, className, void 0, true);
	}
	if (experimentalParseClassName) {
		const parseClassNameOriginal = parseClassName;
		parseClassName = (className) => experimentalParseClassName({
			className,
			parseClassName: parseClassNameOriginal
		});
	}
	return parseClassName;
};
/**
* Sorts modifiers according to following schema:
* - Predefined modifiers are sorted alphabetically
* - When an arbitrary variant appears, it must be preserved which modifiers are before and after it
*/
var createSortModifiers = (config) => {
	const modifierWeights = /* @__PURE__ */ new Map();
	config.orderSensitiveModifiers.forEach((mod, index) => {
		modifierWeights.set(mod, 1e6 + index);
	});
	return (modifiers) => {
		const result = [];
		let currentSegment = [];
		for (let i = 0; i < modifiers.length; i++) {
			const modifier = modifiers[i];
			const isArbitrary = modifier[0] === "[";
			const isOrderSensitive = modifierWeights.has(modifier);
			if (isArbitrary || isOrderSensitive) {
				if (currentSegment.length > 0) {
					currentSegment.sort();
					result.push(...currentSegment);
					currentSegment = [];
				}
				result.push(modifier);
			} else currentSegment.push(modifier);
		}
		if (currentSegment.length > 0) {
			currentSegment.sort();
			result.push(...currentSegment);
		}
		return result;
	};
};
var createConfigUtils = (config) => ({
	cache: createLruCache(config.cacheSize),
	parseClassName: createParseClassName(config),
	sortModifiers: createSortModifiers(config),
	postfixLookupClassGroupIds: createPostfixLookupClassGroupIds(config),
	...createClassGroupUtils(config)
});
var createPostfixLookupClassGroupIds = (config) => {
	const lookup = Object.create(null);
	const classGroupIds = config.postfixLookupClassGroups;
	if (classGroupIds) for (let i = 0; i < classGroupIds.length; i++) lookup[classGroupIds[i]] = true;
	return lookup;
};
var SPLIT_CLASSES_REGEX = /\s+/;
var mergeClassList = (classList, configUtils) => {
	const { parseClassName, getClassGroupId, getConflictingClassGroupIds, sortModifiers, postfixLookupClassGroupIds } = configUtils;
	/**
	* Set of classGroupIds in following format:
	* `{importantModifier}{variantModifiers}{classGroupId}`
	* @example 'float'
	* @example 'hover:focus:bg-color'
	* @example 'md:!pr'
	*/
	const classGroupsInConflict = [];
	const classNames = classList.trim().split(SPLIT_CLASSES_REGEX);
	let result = "";
	for (let index = classNames.length - 1; index >= 0; index -= 1) {
		const originalClassName = classNames[index];
		const { isExternal, modifiers, hasImportantModifier, baseClassName, maybePostfixModifierPosition } = parseClassName(originalClassName);
		if (isExternal) {
			result = originalClassName + (result.length > 0 ? " " + result : result);
			continue;
		}
		let hasPostfixModifier = !!maybePostfixModifierPosition;
		let classGroupId;
		if (hasPostfixModifier) {
			classGroupId = getClassGroupId(baseClassName.substring(0, maybePostfixModifierPosition));
			const classGroupIdWithPostfix = classGroupId && postfixLookupClassGroupIds[classGroupId] ? getClassGroupId(baseClassName) : void 0;
			if (classGroupIdWithPostfix && classGroupIdWithPostfix !== classGroupId) {
				classGroupId = classGroupIdWithPostfix;
				hasPostfixModifier = false;
			}
		} else classGroupId = getClassGroupId(baseClassName);
		if (!classGroupId) {
			if (!hasPostfixModifier) {
				result = originalClassName + (result.length > 0 ? " " + result : result);
				continue;
			}
			classGroupId = getClassGroupId(baseClassName);
			if (!classGroupId) {
				result = originalClassName + (result.length > 0 ? " " + result : result);
				continue;
			}
			hasPostfixModifier = false;
		}
		const variantModifier = modifiers.length === 0 ? "" : modifiers.length === 1 ? modifiers[0] : sortModifiers(modifiers).join(":");
		const modifierId = hasImportantModifier ? variantModifier + IMPORTANT_MODIFIER : variantModifier;
		const classId = modifierId + classGroupId;
		if (classGroupsInConflict.indexOf(classId) > -1) continue;
		classGroupsInConflict.push(classId);
		const conflictGroups = getConflictingClassGroupIds(classGroupId, hasPostfixModifier);
		for (let i = 0; i < conflictGroups.length; ++i) {
			const group = conflictGroups[i];
			classGroupsInConflict.push(modifierId + group);
		}
		result = originalClassName + (result.length > 0 ? " " + result : result);
	}
	return result;
};
/**
* The code in this file is copied from https://github.com/lukeed/clsx and modified to suit the needs of tailwind-merge better.
*
* Specifically:
* - Runtime code from https://github.com/lukeed/clsx/blob/v1.2.1/src/index.js
* - TypeScript types from https://github.com/lukeed/clsx/blob/v1.2.1/clsx.d.ts
*
* Original code has MIT license: Copyright (c) Luke Edwards <luke.edwards05@gmail.com> (lukeed.com)
*/
var twJoin = (...classLists) => {
	let index = 0;
	let argument;
	let resolvedValue;
	let string = "";
	while (index < classLists.length) if (argument = classLists[index++]) {
		if (resolvedValue = toValue(argument)) {
			string && (string += " ");
			string += resolvedValue;
		}
	}
	return string;
};
var toValue = (mix) => {
	if (typeof mix === "string") return mix;
	let resolvedValue;
	let string = "";
	for (let k = 0; k < mix.length; k++) if (mix[k]) {
		if (resolvedValue = toValue(mix[k])) {
			string && (string += " ");
			string += resolvedValue;
		}
	}
	return string;
};
var createTailwindMerge = (createConfigFirst, ...createConfigRest) => {
	let configUtils;
	let cacheGet;
	let cacheSet;
	let functionToCall;
	const initTailwindMerge = (classList) => {
		configUtils = createConfigUtils(createConfigRest.reduce((previousConfig, createConfigCurrent) => createConfigCurrent(previousConfig), createConfigFirst()));
		cacheGet = configUtils.cache.get;
		cacheSet = configUtils.cache.set;
		functionToCall = tailwindMerge;
		return tailwindMerge(classList);
	};
	const tailwindMerge = (classList) => {
		const cachedResult = cacheGet(classList);
		if (cachedResult) return cachedResult;
		const result = mergeClassList(classList, configUtils);
		cacheSet(classList, result);
		return result;
	};
	functionToCall = initTailwindMerge;
	return (...args) => functionToCall(twJoin(...args));
};
var fallbackThemeArr = [];
var fromTheme = (key) => {
	const themeGetter = (theme) => theme[key] || fallbackThemeArr;
	themeGetter.isThemeGetter = true;
	return themeGetter;
};
var arbitraryValueRegex = /^\[(?:(\w[\w-]*):)?(.+)\]$/i;
var arbitraryVariableRegex = /^\((?:(\w[\w-]*):)?(.+)\)$/i;
var fractionRegex = /^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/;
var tshirtUnitRegex = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/;
var lengthUnitRegex = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/;
var colorFunctionRegex = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/;
var shadowRegex = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/;
var imageRegex = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/;
var isFraction = (value) => fractionRegex.test(value);
var isNumber = (value) => !!value && !Number.isNaN(Number(value));
var isInteger = (value) => !!value && Number.isInteger(Number(value));
var isPercent = (value) => value.endsWith("%") && isNumber(value.slice(0, -1));
var isTshirtSize = (value) => tshirtUnitRegex.test(value);
var isAny = () => true;
var isLengthOnly = (value) => lengthUnitRegex.test(value) && !colorFunctionRegex.test(value);
var isNever = () => false;
var isShadow = (value) => shadowRegex.test(value);
var isImage = (value) => imageRegex.test(value);
var isAnyNonArbitrary = (value) => !isArbitraryValue(value) && !isArbitraryVariable(value);
var isNamedContainerQuery = (value) => value.startsWith("@container") && (value[10] === "/" && value[11] !== void 0 || value[11] === "s" && value[16] !== void 0 && value.startsWith("-size/", 10) || value[11] === "n" && value[18] !== void 0 && value.startsWith("-normal/", 10));
var isArbitrarySize = (value) => getIsArbitraryValue(value, isLabelSize, isNever);
var isArbitraryValue = (value) => arbitraryValueRegex.test(value);
var isArbitraryLength = (value) => getIsArbitraryValue(value, isLabelLength, isLengthOnly);
var isArbitraryNumber = (value) => getIsArbitraryValue(value, isLabelNumber, isNumber);
var isArbitraryWeight = (value) => getIsArbitraryValue(value, isLabelWeight, isAny);
var isArbitraryFamilyName = (value) => getIsArbitraryValue(value, isLabelFamilyName, isNever);
var isArbitraryPosition = (value) => getIsArbitraryValue(value, isLabelPosition, isNever);
var isArbitraryImage = (value) => getIsArbitraryValue(value, isLabelImage, isImage);
var isArbitraryShadow = (value) => getIsArbitraryValue(value, isLabelShadow, isShadow);
var isArbitraryVariable = (value) => arbitraryVariableRegex.test(value);
var isArbitraryVariableLength = (value) => getIsArbitraryVariable(value, isLabelLength);
var isArbitraryVariableFamilyName = (value) => getIsArbitraryVariable(value, isLabelFamilyName);
var isArbitraryVariablePosition = (value) => getIsArbitraryVariable(value, isLabelPosition);
var isArbitraryVariableSize = (value) => getIsArbitraryVariable(value, isLabelSize);
var isArbitraryVariableImage = (value) => getIsArbitraryVariable(value, isLabelImage);
var isArbitraryVariableShadow = (value) => getIsArbitraryVariable(value, isLabelShadow, true);
var isArbitraryVariableWeight = (value) => getIsArbitraryVariable(value, isLabelWeight, true);
var getIsArbitraryValue = (value, testLabel, testValue) => {
	const result = arbitraryValueRegex.exec(value);
	if (result) {
		if (result[1]) return testLabel(result[1]);
		return testValue(result[2]);
	}
	return false;
};
var getIsArbitraryVariable = (value, testLabel, shouldMatchNoLabel = false) => {
	const result = arbitraryVariableRegex.exec(value);
	if (result) {
		if (result[1]) return testLabel(result[1]);
		return shouldMatchNoLabel;
	}
	return false;
};
var isLabelPosition = (label) => label === "position" || label === "percentage";
var isLabelImage = (label) => label === "image" || label === "url";
var isLabelSize = (label) => label === "length" || label === "size" || label === "bg-size";
var isLabelLength = (label) => label === "length";
var isLabelNumber = (label) => label === "number";
var isLabelFamilyName = (label) => label === "family-name";
var isLabelWeight = (label) => label === "number" || label === "weight";
var isLabelShadow = (label) => label === "shadow";
var validators = /*#__PURE__*/ Object.defineProperty({
	__proto__: null,
	isAny,
	isAnyNonArbitrary,
	isArbitraryFamilyName,
	isArbitraryImage,
	isArbitraryLength,
	isArbitraryNumber,
	isArbitraryPosition,
	isArbitraryShadow,
	isArbitrarySize,
	isArbitraryValue,
	isArbitraryVariable,
	isArbitraryVariableFamilyName,
	isArbitraryVariableImage,
	isArbitraryVariableLength,
	isArbitraryVariablePosition,
	isArbitraryVariableShadow,
	isArbitraryVariableSize,
	isArbitraryVariableWeight,
	isArbitraryWeight,
	isFraction,
	isInteger,
	isNamedContainerQuery,
	isNumber,
	isPercent,
	isTshirtSize
}, Symbol.toStringTag, { value: "Module" });
var getDefaultConfig = () => {
	/**
	* Theme getters for theme variable namespaces
	* @see https://tailwindcss.com/docs/theme#theme-variable-namespaces
	*/
	const themeColor = fromTheme("color");
	const themeFont = fromTheme("font");
	const themeText = fromTheme("text");
	const themeFontWeight = fromTheme("font-weight");
	const themeTracking = fromTheme("tracking");
	const themeLeading = fromTheme("leading");
	const themeBreakpoint = fromTheme("breakpoint");
	const themeContainer = fromTheme("container");
	const themeSpacing = fromTheme("spacing");
	const themeRadius = fromTheme("radius");
	const themeShadow = fromTheme("shadow");
	const themeInsetShadow = fromTheme("inset-shadow");
	const themeTextShadow = fromTheme("text-shadow");
	const themeDropShadow = fromTheme("drop-shadow");
	const themeBlur = fromTheme("blur");
	const themePerspective = fromTheme("perspective");
	const themeAspect = fromTheme("aspect");
	const themeEase = fromTheme("ease");
	const themeAnimate = fromTheme("animate");
	/**
	* Helpers to avoid repeating the same scales
	*
	* We use functions that create a new array every time they're called instead of static arrays.
	* This ensures that users who modify any scale by mutating the array (e.g. with `array.push(element)`) don't accidentally mutate arrays in other parts of the config.
	*/
	const scaleBreak = () => [
		"auto",
		"avoid",
		"all",
		"avoid-page",
		"page",
		"left",
		"right",
		"column"
	];
	const scalePosition = () => [
		"center",
		"top",
		"bottom",
		"left",
		"right",
		"top-left",
		"left-top",
		"top-right",
		"right-top",
		"bottom-right",
		"right-bottom",
		"bottom-left",
		"left-bottom"
	];
	const scalePositionWithArbitrary = () => [
		...scalePosition(),
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleOverflow = () => [
		"auto",
		"hidden",
		"clip",
		"visible",
		"scroll"
	];
	const scaleOverscroll = () => [
		"auto",
		"contain",
		"none"
	];
	const scaleUnambiguousSpacing = () => [
		isArbitraryVariable,
		isArbitraryValue,
		themeSpacing
	];
	const scaleInset = () => [
		isFraction,
		"full",
		"auto",
		...scaleUnambiguousSpacing()
	];
	const scaleGridTemplateColsRows = () => [
		isInteger,
		"none",
		"subgrid",
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleGridColRowStartAndEnd = () => [
		"auto",
		{ span: [
			"full",
			isInteger,
			isArbitraryVariable,
			isArbitraryValue
		] },
		isInteger,
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleGridColRowStartOrEnd = () => [
		isInteger,
		"auto",
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleGridAutoColsRows = () => [
		"auto",
		"min",
		"max",
		"fr",
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleAlignPrimaryAxis = () => [
		"start",
		"end",
		"center",
		"between",
		"around",
		"evenly",
		"stretch",
		"baseline",
		"center-safe",
		"end-safe"
	];
	const scaleAlignSecondaryAxis = () => [
		"start",
		"end",
		"center",
		"stretch",
		"center-safe",
		"end-safe"
	];
	const scaleMargin = () => ["auto", ...scaleUnambiguousSpacing()];
	const scaleSizing = () => [
		isFraction,
		"auto",
		"full",
		"dvw",
		"dvh",
		"lvw",
		"lvh",
		"svw",
		"svh",
		"min",
		"max",
		"fit",
		...scaleUnambiguousSpacing()
	];
	const scaleSizingInline = () => [
		isFraction,
		"screen",
		"full",
		"dvw",
		"lvw",
		"svw",
		"min",
		"max",
		"fit",
		...scaleUnambiguousSpacing()
	];
	const scaleSizingBlock = () => [
		isFraction,
		"screen",
		"full",
		"lh",
		"dvh",
		"lvh",
		"svh",
		"min",
		"max",
		"fit",
		...scaleUnambiguousSpacing()
	];
	const scaleColor = () => [
		themeColor,
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleBgPosition = () => [
		...scalePosition(),
		isArbitraryVariablePosition,
		isArbitraryPosition,
		{ position: [isArbitraryVariable, isArbitraryValue] }
	];
	const scaleBgRepeat = () => ["no-repeat", { repeat: [
		"",
		"x",
		"y",
		"space",
		"round"
	] }];
	const scaleBgSize = () => [
		"auto",
		"cover",
		"contain",
		isArbitraryVariableSize,
		isArbitrarySize,
		{ size: [isArbitraryVariable, isArbitraryValue] }
	];
	const scaleGradientStopPosition = () => [
		isPercent,
		isArbitraryVariableLength,
		isArbitraryLength
	];
	const scaleRadius = () => [
		"",
		"none",
		"full",
		themeRadius,
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleBorderWidth = () => [
		"",
		isNumber,
		isArbitraryVariableLength,
		isArbitraryLength
	];
	const scaleLineStyle = () => [
		"solid",
		"dashed",
		"dotted",
		"double"
	];
	const scaleBlendMode = () => [
		"normal",
		"multiply",
		"screen",
		"overlay",
		"darken",
		"lighten",
		"color-dodge",
		"color-burn",
		"hard-light",
		"soft-light",
		"difference",
		"exclusion",
		"hue",
		"saturation",
		"color",
		"luminosity"
	];
	const scaleMaskImagePosition = () => [
		isNumber,
		isPercent,
		isArbitraryVariablePosition,
		isArbitraryPosition
	];
	const scaleBlur = () => [
		"",
		"none",
		themeBlur,
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleRotate = () => [
		"none",
		isNumber,
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleScale = () => [
		"none",
		isNumber,
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleSkew = () => [
		isNumber,
		isArbitraryVariable,
		isArbitraryValue
	];
	const scaleTranslate = () => [
		isFraction,
		"full",
		...scaleUnambiguousSpacing()
	];
	return {
		cacheSize: 500,
		theme: {
			animate: [
				"spin",
				"ping",
				"pulse",
				"bounce"
			],
			aspect: ["video"],
			blur: [isTshirtSize],
			breakpoint: [isTshirtSize],
			color: [isAny],
			container: [isTshirtSize],
			"drop-shadow": [isTshirtSize],
			ease: [
				"in",
				"out",
				"in-out"
			],
			font: [isAnyNonArbitrary],
			"font-weight": [
				"thin",
				"extralight",
				"light",
				"normal",
				"medium",
				"semibold",
				"bold",
				"extrabold",
				"black"
			],
			"inset-shadow": [isTshirtSize],
			leading: [
				"none",
				"tight",
				"snug",
				"normal",
				"relaxed",
				"loose"
			],
			perspective: [
				"dramatic",
				"near",
				"normal",
				"midrange",
				"distant",
				"none"
			],
			radius: [isTshirtSize],
			shadow: [isTshirtSize],
			spacing: ["px", isNumber],
			text: [isTshirtSize],
			"text-shadow": [isTshirtSize],
			tracking: [
				"tighter",
				"tight",
				"normal",
				"wide",
				"wider",
				"widest"
			]
		},
		classGroups: {
			/**
			* Aspect Ratio
			* @see https://tailwindcss.com/docs/aspect-ratio
			*/
			aspect: [{ aspect: [
				"auto",
				"square",
				isFraction,
				isArbitraryValue,
				isArbitraryVariable,
				themeAspect
			] }],
			/**
			* Container
			* @see https://tailwindcss.com/docs/container
			* @deprecated since Tailwind CSS v4.0.0
			*/
			container: ["container"],
			/**
			* Container Type
			* @see https://tailwindcss.com/docs/responsive-design#container-queries
			*/
			"container-type": [{ "@container": [
				"",
				"normal",
				"size",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Container Name
			* @see https://tailwindcss.com/docs/responsive-design#named-containers
			*/
			"container-named": [isNamedContainerQuery],
			/**
			* Columns
			* @see https://tailwindcss.com/docs/columns
			*/
			columns: [{ columns: [
				isNumber,
				isArbitraryValue,
				isArbitraryVariable,
				themeContainer
			] }],
			/**
			* Break After
			* @see https://tailwindcss.com/docs/break-after
			*/
			"break-after": [{ "break-after": scaleBreak() }],
			/**
			* Break Before
			* @see https://tailwindcss.com/docs/break-before
			*/
			"break-before": [{ "break-before": scaleBreak() }],
			/**
			* Break Inside
			* @see https://tailwindcss.com/docs/break-inside
			*/
			"break-inside": [{ "break-inside": [
				"auto",
				"avoid",
				"avoid-page",
				"avoid-column"
			] }],
			/**
			* Box Decoration Break
			* @see https://tailwindcss.com/docs/box-decoration-break
			*/
			"box-decoration": [{ "box-decoration": ["slice", "clone"] }],
			/**
			* Box Sizing
			* @see https://tailwindcss.com/docs/box-sizing
			*/
			box: [{ box: ["border", "content"] }],
			/**
			* Display
			* @see https://tailwindcss.com/docs/display
			*/
			display: [
				"block",
				"inline-block",
				"inline",
				"flex",
				"inline-flex",
				"table",
				"inline-table",
				"table-caption",
				"table-cell",
				"table-column",
				"table-column-group",
				"table-footer-group",
				"table-header-group",
				"table-row-group",
				"table-row",
				"flow-root",
				"grid",
				"inline-grid",
				"contents",
				"list-item",
				"hidden"
			],
			/**
			* Screen Reader Only
			* @see https://tailwindcss.com/docs/display#screen-reader-only
			*/
			sr: ["sr-only", "not-sr-only"],
			/**
			* Floats
			* @see https://tailwindcss.com/docs/float
			*/
			float: [{ float: [
				"right",
				"left",
				"none",
				"start",
				"end"
			] }],
			/**
			* Clear
			* @see https://tailwindcss.com/docs/clear
			*/
			clear: [{ clear: [
				"left",
				"right",
				"both",
				"none",
				"start",
				"end"
			] }],
			/**
			* Isolation
			* @see https://tailwindcss.com/docs/isolation
			*/
			isolation: ["isolate", "isolation-auto"],
			/**
			* Object Fit
			* @see https://tailwindcss.com/docs/object-fit
			*/
			"object-fit": [{ object: [
				"contain",
				"cover",
				"fill",
				"none",
				"scale-down"
			] }],
			/**
			* Object Position
			* @see https://tailwindcss.com/docs/object-position
			*/
			"object-position": [{ object: scalePositionWithArbitrary() }],
			/**
			* Overflow
			* @see https://tailwindcss.com/docs/overflow
			*/
			overflow: [{ overflow: scaleOverflow() }],
			/**
			* Overflow X
			* @see https://tailwindcss.com/docs/overflow
			*/
			"overflow-x": [{ "overflow-x": scaleOverflow() }],
			/**
			* Overflow Y
			* @see https://tailwindcss.com/docs/overflow
			*/
			"overflow-y": [{ "overflow-y": scaleOverflow() }],
			/**
			* Overscroll Behavior
			* @see https://tailwindcss.com/docs/overscroll-behavior
			*/
			overscroll: [{ overscroll: scaleOverscroll() }],
			/**
			* Overscroll Behavior X
			* @see https://tailwindcss.com/docs/overscroll-behavior
			*/
			"overscroll-x": [{ "overscroll-x": scaleOverscroll() }],
			/**
			* Overscroll Behavior Y
			* @see https://tailwindcss.com/docs/overscroll-behavior
			*/
			"overscroll-y": [{ "overscroll-y": scaleOverscroll() }],
			/**
			* Position
			* @see https://tailwindcss.com/docs/position
			*/
			position: [
				"static",
				"fixed",
				"absolute",
				"relative",
				"sticky"
			],
			/**
			* Inset
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			inset: [{ inset: scaleInset() }],
			/**
			* Inset Inline
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			"inset-x": [{ "inset-x": scaleInset() }],
			/**
			* Inset Block
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			"inset-y": [{ "inset-y": scaleInset() }],
			/**
			* Inset Inline Start
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			* @todo class group will be renamed to `inset-s` in next major release
			*/
			start: [{
				"inset-s": scaleInset(),
				/**
				* @deprecated since Tailwind CSS v4.2.0 in favor of `inset-s-*` utilities.
				* @see https://github.com/tailwindlabs/tailwindcss/pull/19613
				*/
				start: scaleInset()
			}],
			/**
			* Inset Inline End
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			* @todo class group will be renamed to `inset-e` in next major release
			*/
			end: [{
				"inset-e": scaleInset(),
				/**
				* @deprecated since Tailwind CSS v4.2.0 in favor of `inset-e-*` utilities.
				* @see https://github.com/tailwindlabs/tailwindcss/pull/19613
				*/
				end: scaleInset()
			}],
			/**
			* Inset Block Start
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			"inset-bs": [{ "inset-bs": scaleInset() }],
			/**
			* Inset Block End
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			"inset-be": [{ "inset-be": scaleInset() }],
			/**
			* Top
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			top: [{ top: scaleInset() }],
			/**
			* Right
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			right: [{ right: scaleInset() }],
			/**
			* Bottom
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			bottom: [{ bottom: scaleInset() }],
			/**
			* Left
			* @see https://tailwindcss.com/docs/top-right-bottom-left
			*/
			left: [{ left: scaleInset() }],
			/**
			* Visibility
			* @see https://tailwindcss.com/docs/visibility
			*/
			visibility: [
				"visible",
				"invisible",
				"collapse"
			],
			/**
			* Z-Index
			* @see https://tailwindcss.com/docs/z-index
			*/
			z: [{ z: [
				isInteger,
				"auto",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Flex Basis
			* @see https://tailwindcss.com/docs/flex-basis
			*/
			basis: [{ basis: [
				isFraction,
				"full",
				"auto",
				themeContainer,
				...scaleUnambiguousSpacing()
			] }],
			/**
			* Flex Direction
			* @see https://tailwindcss.com/docs/flex-direction
			*/
			"flex-direction": [{ flex: [
				"row",
				"row-reverse",
				"col",
				"col-reverse"
			] }],
			/**
			* Flex Wrap
			* @see https://tailwindcss.com/docs/flex-wrap
			*/
			"flex-wrap": [{ flex: [
				"nowrap",
				"wrap",
				"wrap-reverse"
			] }],
			/**
			* Flex
			* @see https://tailwindcss.com/docs/flex
			*/
			flex: [{ flex: [
				isNumber,
				isFraction,
				"auto",
				"initial",
				"none",
				isArbitraryValue
			] }],
			/**
			* Flex Grow
			* @see https://tailwindcss.com/docs/flex-grow
			*/
			grow: [{ grow: [
				"",
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Flex Shrink
			* @see https://tailwindcss.com/docs/flex-shrink
			*/
			shrink: [{ shrink: [
				"",
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Order
			* @see https://tailwindcss.com/docs/order
			*/
			order: [{ order: [
				isInteger,
				"first",
				"last",
				"none",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Grid Template Columns
			* @see https://tailwindcss.com/docs/grid-template-columns
			*/
			"grid-cols": [{ "grid-cols": scaleGridTemplateColsRows() }],
			/**
			* Grid Column Start / End
			* @see https://tailwindcss.com/docs/grid-column
			*/
			"col-start-end": [{ col: scaleGridColRowStartAndEnd() }],
			/**
			* Grid Column Start
			* @see https://tailwindcss.com/docs/grid-column
			*/
			"col-start": [{ "col-start": scaleGridColRowStartOrEnd() }],
			/**
			* Grid Column End
			* @see https://tailwindcss.com/docs/grid-column
			*/
			"col-end": [{ "col-end": scaleGridColRowStartOrEnd() }],
			/**
			* Grid Template Rows
			* @see https://tailwindcss.com/docs/grid-template-rows
			*/
			"grid-rows": [{ "grid-rows": scaleGridTemplateColsRows() }],
			/**
			* Grid Row Start / End
			* @see https://tailwindcss.com/docs/grid-row
			*/
			"row-start-end": [{ row: scaleGridColRowStartAndEnd() }],
			/**
			* Grid Row Start
			* @see https://tailwindcss.com/docs/grid-row
			*/
			"row-start": [{ "row-start": scaleGridColRowStartOrEnd() }],
			/**
			* Grid Row End
			* @see https://tailwindcss.com/docs/grid-row
			*/
			"row-end": [{ "row-end": scaleGridColRowStartOrEnd() }],
			/**
			* Grid Auto Flow
			* @see https://tailwindcss.com/docs/grid-auto-flow
			*/
			"grid-flow": [{ "grid-flow": [
				"row",
				"col",
				"dense",
				"row-dense",
				"col-dense"
			] }],
			/**
			* Grid Auto Columns
			* @see https://tailwindcss.com/docs/grid-auto-columns
			*/
			"auto-cols": [{ "auto-cols": scaleGridAutoColsRows() }],
			/**
			* Grid Auto Rows
			* @see https://tailwindcss.com/docs/grid-auto-rows
			*/
			"auto-rows": [{ "auto-rows": scaleGridAutoColsRows() }],
			/**
			* Gap
			* @see https://tailwindcss.com/docs/gap
			*/
			gap: [{ gap: scaleUnambiguousSpacing() }],
			/**
			* Gap X
			* @see https://tailwindcss.com/docs/gap
			*/
			"gap-x": [{ "gap-x": scaleUnambiguousSpacing() }],
			/**
			* Gap Y
			* @see https://tailwindcss.com/docs/gap
			*/
			"gap-y": [{ "gap-y": scaleUnambiguousSpacing() }],
			/**
			* Justify Content
			* @see https://tailwindcss.com/docs/justify-content
			*/
			"justify-content": [{ justify: [...scaleAlignPrimaryAxis(), "normal"] }],
			/**
			* Justify Items
			* @see https://tailwindcss.com/docs/justify-items
			*/
			"justify-items": [{ "justify-items": [...scaleAlignSecondaryAxis(), "normal"] }],
			/**
			* Justify Self
			* @see https://tailwindcss.com/docs/justify-self
			*/
			"justify-self": [{ "justify-self": ["auto", ...scaleAlignSecondaryAxis()] }],
			/**
			* Align Content
			* @see https://tailwindcss.com/docs/align-content
			*/
			"align-content": [{ content: ["normal", ...scaleAlignPrimaryAxis()] }],
			/**
			* Align Items
			* @see https://tailwindcss.com/docs/align-items
			*/
			"align-items": [{ items: [...scaleAlignSecondaryAxis(), { baseline: ["", "last"] }] }],
			/**
			* Align Self
			* @see https://tailwindcss.com/docs/align-self
			*/
			"align-self": [{ self: [
				"auto",
				...scaleAlignSecondaryAxis(),
				{ baseline: ["", "last"] }
			] }],
			/**
			* Place Content
			* @see https://tailwindcss.com/docs/place-content
			*/
			"place-content": [{ "place-content": scaleAlignPrimaryAxis() }],
			/**
			* Place Items
			* @see https://tailwindcss.com/docs/place-items
			*/
			"place-items": [{ "place-items": [...scaleAlignSecondaryAxis(), "baseline"] }],
			/**
			* Place Self
			* @see https://tailwindcss.com/docs/place-self
			*/
			"place-self": [{ "place-self": ["auto", ...scaleAlignSecondaryAxis()] }],
			/**
			* Padding
			* @see https://tailwindcss.com/docs/padding
			*/
			p: [{ p: scaleUnambiguousSpacing() }],
			/**
			* Padding Inline
			* @see https://tailwindcss.com/docs/padding
			*/
			px: [{ px: scaleUnambiguousSpacing() }],
			/**
			* Padding Block
			* @see https://tailwindcss.com/docs/padding
			*/
			py: [{ py: scaleUnambiguousSpacing() }],
			/**
			* Padding Inline Start
			* @see https://tailwindcss.com/docs/padding
			*/
			ps: [{ ps: scaleUnambiguousSpacing() }],
			/**
			* Padding Inline End
			* @see https://tailwindcss.com/docs/padding
			*/
			pe: [{ pe: scaleUnambiguousSpacing() }],
			/**
			* Padding Block Start
			* @see https://tailwindcss.com/docs/padding
			*/
			pbs: [{ pbs: scaleUnambiguousSpacing() }],
			/**
			* Padding Block End
			* @see https://tailwindcss.com/docs/padding
			*/
			pbe: [{ pbe: scaleUnambiguousSpacing() }],
			/**
			* Padding Top
			* @see https://tailwindcss.com/docs/padding
			*/
			pt: [{ pt: scaleUnambiguousSpacing() }],
			/**
			* Padding Right
			* @see https://tailwindcss.com/docs/padding
			*/
			pr: [{ pr: scaleUnambiguousSpacing() }],
			/**
			* Padding Bottom
			* @see https://tailwindcss.com/docs/padding
			*/
			pb: [{ pb: scaleUnambiguousSpacing() }],
			/**
			* Padding Left
			* @see https://tailwindcss.com/docs/padding
			*/
			pl: [{ pl: scaleUnambiguousSpacing() }],
			/**
			* Margin
			* @see https://tailwindcss.com/docs/margin
			*/
			m: [{ m: scaleMargin() }],
			/**
			* Margin Inline
			* @see https://tailwindcss.com/docs/margin
			*/
			mx: [{ mx: scaleMargin() }],
			/**
			* Margin Block
			* @see https://tailwindcss.com/docs/margin
			*/
			my: [{ my: scaleMargin() }],
			/**
			* Margin Inline Start
			* @see https://tailwindcss.com/docs/margin
			*/
			ms: [{ ms: scaleMargin() }],
			/**
			* Margin Inline End
			* @see https://tailwindcss.com/docs/margin
			*/
			me: [{ me: scaleMargin() }],
			/**
			* Margin Block Start
			* @see https://tailwindcss.com/docs/margin
			*/
			mbs: [{ mbs: scaleMargin() }],
			/**
			* Margin Block End
			* @see https://tailwindcss.com/docs/margin
			*/
			mbe: [{ mbe: scaleMargin() }],
			/**
			* Margin Top
			* @see https://tailwindcss.com/docs/margin
			*/
			mt: [{ mt: scaleMargin() }],
			/**
			* Margin Right
			* @see https://tailwindcss.com/docs/margin
			*/
			mr: [{ mr: scaleMargin() }],
			/**
			* Margin Bottom
			* @see https://tailwindcss.com/docs/margin
			*/
			mb: [{ mb: scaleMargin() }],
			/**
			* Margin Left
			* @see https://tailwindcss.com/docs/margin
			*/
			ml: [{ ml: scaleMargin() }],
			/**
			* Space Between X
			* @see https://tailwindcss.com/docs/margin#adding-space-between-children
			*/
			"space-x": [{ "space-x": scaleUnambiguousSpacing() }],
			/**
			* Space Between X Reverse
			* @see https://tailwindcss.com/docs/margin#adding-space-between-children
			*/
			"space-x-reverse": ["space-x-reverse"],
			/**
			* Space Between Y
			* @see https://tailwindcss.com/docs/margin#adding-space-between-children
			*/
			"space-y": [{ "space-y": scaleUnambiguousSpacing() }],
			/**
			* Space Between Y Reverse
			* @see https://tailwindcss.com/docs/margin#adding-space-between-children
			*/
			"space-y-reverse": ["space-y-reverse"],
			/**
			* Size
			* @see https://tailwindcss.com/docs/width#setting-both-width-and-height
			*/
			size: [{ size: scaleSizing() }],
			/**
			* Inline Size
			* @see https://tailwindcss.com/docs/width
			*/
			"inline-size": [{ inline: ["auto", ...scaleSizingInline()] }],
			/**
			* Min-Inline Size
			* @see https://tailwindcss.com/docs/min-width
			*/
			"min-inline-size": [{ "min-inline": ["auto", ...scaleSizingInline()] }],
			/**
			* Max-Inline Size
			* @see https://tailwindcss.com/docs/max-width
			*/
			"max-inline-size": [{ "max-inline": ["none", ...scaleSizingInline()] }],
			/**
			* Block Size
			* @see https://tailwindcss.com/docs/height
			*/
			"block-size": [{ block: ["auto", ...scaleSizingBlock()] }],
			/**
			* Min-Block Size
			* @see https://tailwindcss.com/docs/min-height
			*/
			"min-block-size": [{ "min-block": ["auto", ...scaleSizingBlock()] }],
			/**
			* Max-Block Size
			* @see https://tailwindcss.com/docs/max-height
			*/
			"max-block-size": [{ "max-block": ["none", ...scaleSizingBlock()] }],
			/**
			* Width
			* @see https://tailwindcss.com/docs/width
			*/
			w: [{ w: [
				themeContainer,
				"screen",
				...scaleSizing()
			] }],
			/**
			* Min-Width
			* @see https://tailwindcss.com/docs/min-width
			*/
			"min-w": [{ "min-w": [
				themeContainer,
				"screen",
				"none",
				...scaleSizing()
			] }],
			/**
			* Max-Width
			* @see https://tailwindcss.com/docs/max-width
			*/
			"max-w": [{ "max-w": [
				themeContainer,
				"screen",
				"none",
				"prose",
				{ screen: [themeBreakpoint] },
				...scaleSizing()
			] }],
			/**
			* Height
			* @see https://tailwindcss.com/docs/height
			*/
			h: [{ h: [
				"screen",
				"lh",
				...scaleSizing()
			] }],
			/**
			* Min-Height
			* @see https://tailwindcss.com/docs/min-height
			*/
			"min-h": [{ "min-h": [
				"screen",
				"lh",
				"none",
				...scaleSizing()
			] }],
			/**
			* Max-Height
			* @see https://tailwindcss.com/docs/max-height
			*/
			"max-h": [{ "max-h": [
				"screen",
				"lh",
				...scaleSizing()
			] }],
			/**
			* Font Size
			* @see https://tailwindcss.com/docs/font-size
			*/
			"font-size": [{ text: [
				"base",
				themeText,
				isArbitraryVariableLength,
				isArbitraryLength
			] }],
			/**
			* Font Smoothing
			* @see https://tailwindcss.com/docs/font-smoothing
			*/
			"font-smoothing": ["antialiased", "subpixel-antialiased"],
			/**
			* Font Style
			* @see https://tailwindcss.com/docs/font-style
			*/
			"font-style": ["italic", "not-italic"],
			/**
			* Font Weight
			* @see https://tailwindcss.com/docs/font-weight
			*/
			"font-weight": [{ font: [
				themeFontWeight,
				isArbitraryVariableWeight,
				isArbitraryWeight
			] }],
			/**
			* Font Stretch
			* @see https://tailwindcss.com/docs/font-stretch
			*/
			"font-stretch": [{ "font-stretch": [
				"ultra-condensed",
				"extra-condensed",
				"condensed",
				"semi-condensed",
				"normal",
				"semi-expanded",
				"expanded",
				"extra-expanded",
				"ultra-expanded",
				isPercent,
				isArbitraryValue
			] }],
			/**
			* Font Family
			* @see https://tailwindcss.com/docs/font-family
			*/
			"font-family": [{ font: [
				isArbitraryVariableFamilyName,
				isArbitraryFamilyName,
				themeFont
			] }],
			/**
			* Font Feature Settings
			* @see https://tailwindcss.com/docs/font-feature-settings
			*/
			"font-features": [{ "font-features": [isArbitraryValue] }],
			/**
			* Font Variant Numeric
			* @see https://tailwindcss.com/docs/font-variant-numeric
			*/
			"fvn-normal": ["normal-nums"],
			/**
			* Font Variant Numeric
			* @see https://tailwindcss.com/docs/font-variant-numeric
			*/
			"fvn-ordinal": ["ordinal"],
			/**
			* Font Variant Numeric
			* @see https://tailwindcss.com/docs/font-variant-numeric
			*/
			"fvn-slashed-zero": ["slashed-zero"],
			/**
			* Font Variant Numeric
			* @see https://tailwindcss.com/docs/font-variant-numeric
			*/
			"fvn-figure": ["lining-nums", "oldstyle-nums"],
			/**
			* Font Variant Numeric
			* @see https://tailwindcss.com/docs/font-variant-numeric
			*/
			"fvn-spacing": ["proportional-nums", "tabular-nums"],
			/**
			* Font Variant Numeric
			* @see https://tailwindcss.com/docs/font-variant-numeric
			*/
			"fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
			/**
			* Letter Spacing
			* @see https://tailwindcss.com/docs/letter-spacing
			*/
			tracking: [{ tracking: [
				themeTracking,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Line Clamp
			* @see https://tailwindcss.com/docs/line-clamp
			*/
			"line-clamp": [{ "line-clamp": [
				isNumber,
				"none",
				isArbitraryVariable,
				isArbitraryNumber
			] }],
			/**
			* Line Height
			* @see https://tailwindcss.com/docs/line-height
			*/
			leading: [{ leading: [themeLeading, ...scaleUnambiguousSpacing()] }],
			/**
			* List Style Image
			* @see https://tailwindcss.com/docs/list-style-image
			*/
			"list-image": [{ "list-image": [
				"none",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* List Style Position
			* @see https://tailwindcss.com/docs/list-style-position
			*/
			"list-style-position": [{ list: ["inside", "outside"] }],
			/**
			* List Style Type
			* @see https://tailwindcss.com/docs/list-style-type
			*/
			"list-style-type": [{ list: [
				"disc",
				"decimal",
				"none",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Text Alignment
			* @see https://tailwindcss.com/docs/text-align
			*/
			"text-alignment": [{ text: [
				"left",
				"center",
				"right",
				"justify",
				"start",
				"end"
			] }],
			/**
			* Placeholder Color
			* @deprecated since Tailwind CSS v3.0.0
			* @see https://v3.tailwindcss.com/docs/placeholder-color
			*/
			"placeholder-color": [{ placeholder: scaleColor() }],
			/**
			* Text Color
			* @see https://tailwindcss.com/docs/text-color
			*/
			"text-color": [{ text: scaleColor() }],
			/**
			* Text Decoration
			* @see https://tailwindcss.com/docs/text-decoration
			*/
			"text-decoration": [
				"underline",
				"overline",
				"line-through",
				"no-underline"
			],
			/**
			* Text Decoration Style
			* @see https://tailwindcss.com/docs/text-decoration-style
			*/
			"text-decoration-style": [{ decoration: [...scaleLineStyle(), "wavy"] }],
			/**
			* Text Decoration Thickness
			* @see https://tailwindcss.com/docs/text-decoration-thickness
			*/
			"text-decoration-thickness": [{ decoration: [
				isNumber,
				"from-font",
				"auto",
				isArbitraryVariable,
				isArbitraryLength
			] }],
			/**
			* Text Decoration Color
			* @see https://tailwindcss.com/docs/text-decoration-color
			*/
			"text-decoration-color": [{ decoration: scaleColor() }],
			/**
			* Text Underline Offset
			* @see https://tailwindcss.com/docs/text-underline-offset
			*/
			"underline-offset": [{ "underline-offset": [
				isNumber,
				"auto",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Text Transform
			* @see https://tailwindcss.com/docs/text-transform
			*/
			"text-transform": [
				"uppercase",
				"lowercase",
				"capitalize",
				"normal-case"
			],
			/**
			* Text Overflow
			* @see https://tailwindcss.com/docs/text-overflow
			*/
			"text-overflow": [
				"truncate",
				"text-ellipsis",
				"text-clip"
			],
			/**
			* Text Wrap
			* @see https://tailwindcss.com/docs/text-wrap
			*/
			"text-wrap": [{ text: [
				"wrap",
				"nowrap",
				"balance",
				"pretty"
			] }],
			/**
			* Text Indent
			* @see https://tailwindcss.com/docs/text-indent
			*/
			indent: [{ indent: scaleUnambiguousSpacing() }],
			/**
			* Tab Size
			* @see https://tailwindcss.com/docs/tab-size
			*/
			"tab-size": [{ tab: [
				isInteger,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Vertical Alignment
			* @see https://tailwindcss.com/docs/vertical-align
			*/
			"vertical-align": [{ align: [
				"baseline",
				"top",
				"middle",
				"bottom",
				"text-top",
				"text-bottom",
				"sub",
				"super",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Whitespace
			* @see https://tailwindcss.com/docs/whitespace
			*/
			whitespace: [{ whitespace: [
				"normal",
				"nowrap",
				"pre",
				"pre-line",
				"pre-wrap",
				"break-spaces"
			] }],
			/**
			* Word Break
			* @see https://tailwindcss.com/docs/word-break
			*/
			break: [{ break: [
				"normal",
				"words",
				"all",
				"keep"
			] }],
			/**
			* Overflow Wrap
			* @see https://tailwindcss.com/docs/overflow-wrap
			*/
			wrap: [{ wrap: [
				"break-word",
				"anywhere",
				"normal"
			] }],
			/**
			* Hyphens
			* @see https://tailwindcss.com/docs/hyphens
			*/
			hyphens: [{ hyphens: [
				"none",
				"manual",
				"auto"
			] }],
			/**
			* Content
			* @see https://tailwindcss.com/docs/content
			*/
			content: [{ content: [
				"none",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Background Attachment
			* @see https://tailwindcss.com/docs/background-attachment
			*/
			"bg-attachment": [{ bg: [
				"fixed",
				"local",
				"scroll"
			] }],
			/**
			* Background Clip
			* @see https://tailwindcss.com/docs/background-clip
			*/
			"bg-clip": [{ "bg-clip": [
				"border",
				"padding",
				"content",
				"text"
			] }],
			/**
			* Background Origin
			* @see https://tailwindcss.com/docs/background-origin
			*/
			"bg-origin": [{ "bg-origin": [
				"border",
				"padding",
				"content"
			] }],
			/**
			* Background Position
			* @see https://tailwindcss.com/docs/background-position
			*/
			"bg-position": [{ bg: scaleBgPosition() }],
			/**
			* Background Repeat
			* @see https://tailwindcss.com/docs/background-repeat
			*/
			"bg-repeat": [{ bg: scaleBgRepeat() }],
			/**
			* Background Size
			* @see https://tailwindcss.com/docs/background-size
			*/
			"bg-size": [{ bg: scaleBgSize() }],
			/**
			* Background Image
			* @see https://tailwindcss.com/docs/background-image
			*/
			"bg-image": [{ bg: [
				"none",
				{
					linear: [
						{ to: [
							"t",
							"tr",
							"r",
							"br",
							"b",
							"bl",
							"l",
							"tl"
						] },
						isInteger,
						isArbitraryVariable,
						isArbitraryValue
					],
					radial: [
						"",
						isArbitraryVariable,
						isArbitraryValue
					],
					conic: [
						isInteger,
						isArbitraryVariable,
						isArbitraryValue
					]
				},
				isArbitraryVariableImage,
				isArbitraryImage
			] }],
			/**
			* Background Color
			* @see https://tailwindcss.com/docs/background-color
			*/
			"bg-color": [{ bg: scaleColor() }],
			/**
			* Gradient Color Stops From Position
			* @see https://tailwindcss.com/docs/gradient-color-stops
			*/
			"gradient-from-pos": [{ from: scaleGradientStopPosition() }],
			/**
			* Gradient Color Stops Via Position
			* @see https://tailwindcss.com/docs/gradient-color-stops
			*/
			"gradient-via-pos": [{ via: scaleGradientStopPosition() }],
			/**
			* Gradient Color Stops To Position
			* @see https://tailwindcss.com/docs/gradient-color-stops
			*/
			"gradient-to-pos": [{ to: scaleGradientStopPosition() }],
			/**
			* Gradient Color Stops From
			* @see https://tailwindcss.com/docs/gradient-color-stops
			*/
			"gradient-from": [{ from: scaleColor() }],
			/**
			* Gradient Color Stops Via
			* @see https://tailwindcss.com/docs/gradient-color-stops
			*/
			"gradient-via": [{ via: scaleColor() }],
			/**
			* Gradient Color Stops To
			* @see https://tailwindcss.com/docs/gradient-color-stops
			*/
			"gradient-to": [{ to: scaleColor() }],
			/**
			* Border Radius
			* @see https://tailwindcss.com/docs/border-radius
			*/
			rounded: [{ rounded: scaleRadius() }],
			/**
			* Border Radius Start
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-s": [{ "rounded-s": scaleRadius() }],
			/**
			* Border Radius End
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-e": [{ "rounded-e": scaleRadius() }],
			/**
			* Border Radius Top
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-t": [{ "rounded-t": scaleRadius() }],
			/**
			* Border Radius Right
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-r": [{ "rounded-r": scaleRadius() }],
			/**
			* Border Radius Bottom
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-b": [{ "rounded-b": scaleRadius() }],
			/**
			* Border Radius Left
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-l": [{ "rounded-l": scaleRadius() }],
			/**
			* Border Radius Start Start
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-ss": [{ "rounded-ss": scaleRadius() }],
			/**
			* Border Radius Start End
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-se": [{ "rounded-se": scaleRadius() }],
			/**
			* Border Radius End End
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-ee": [{ "rounded-ee": scaleRadius() }],
			/**
			* Border Radius End Start
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-es": [{ "rounded-es": scaleRadius() }],
			/**
			* Border Radius Top Left
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-tl": [{ "rounded-tl": scaleRadius() }],
			/**
			* Border Radius Top Right
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-tr": [{ "rounded-tr": scaleRadius() }],
			/**
			* Border Radius Bottom Right
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-br": [{ "rounded-br": scaleRadius() }],
			/**
			* Border Radius Bottom Left
			* @see https://tailwindcss.com/docs/border-radius
			*/
			"rounded-bl": [{ "rounded-bl": scaleRadius() }],
			/**
			* Border Width
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w": [{ border: scaleBorderWidth() }],
			/**
			* Border Width Inline
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-x": [{ "border-x": scaleBorderWidth() }],
			/**
			* Border Width Block
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-y": [{ "border-y": scaleBorderWidth() }],
			/**
			* Border Width Inline Start
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-s": [{ "border-s": scaleBorderWidth() }],
			/**
			* Border Width Inline End
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-e": [{ "border-e": scaleBorderWidth() }],
			/**
			* Border Width Block Start
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-bs": [{ "border-bs": scaleBorderWidth() }],
			/**
			* Border Width Block End
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-be": [{ "border-be": scaleBorderWidth() }],
			/**
			* Border Width Top
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-t": [{ "border-t": scaleBorderWidth() }],
			/**
			* Border Width Right
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-r": [{ "border-r": scaleBorderWidth() }],
			/**
			* Border Width Bottom
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-b": [{ "border-b": scaleBorderWidth() }],
			/**
			* Border Width Left
			* @see https://tailwindcss.com/docs/border-width
			*/
			"border-w-l": [{ "border-l": scaleBorderWidth() }],
			/**
			* Divide Width X
			* @see https://tailwindcss.com/docs/border-width#between-children
			*/
			"divide-x": [{ "divide-x": scaleBorderWidth() }],
			/**
			* Divide Width X Reverse
			* @see https://tailwindcss.com/docs/border-width#between-children
			*/
			"divide-x-reverse": ["divide-x-reverse"],
			/**
			* Divide Width Y
			* @see https://tailwindcss.com/docs/border-width#between-children
			*/
			"divide-y": [{ "divide-y": scaleBorderWidth() }],
			/**
			* Divide Width Y Reverse
			* @see https://tailwindcss.com/docs/border-width#between-children
			*/
			"divide-y-reverse": ["divide-y-reverse"],
			/**
			* Border Style
			* @see https://tailwindcss.com/docs/border-style
			*/
			"border-style": [{ border: [
				...scaleLineStyle(),
				"hidden",
				"none"
			] }],
			/**
			* Divide Style
			* @see https://tailwindcss.com/docs/border-style#setting-the-divider-style
			*/
			"divide-style": [{ divide: [
				...scaleLineStyle(),
				"hidden",
				"none"
			] }],
			/**
			* Border Color
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color": [{ border: scaleColor() }],
			/**
			* Border Color Inline
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-x": [{ "border-x": scaleColor() }],
			/**
			* Border Color Block
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-y": [{ "border-y": scaleColor() }],
			/**
			* Border Color Inline Start
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-s": [{ "border-s": scaleColor() }],
			/**
			* Border Color Inline End
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-e": [{ "border-e": scaleColor() }],
			/**
			* Border Color Block Start
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-bs": [{ "border-bs": scaleColor() }],
			/**
			* Border Color Block End
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-be": [{ "border-be": scaleColor() }],
			/**
			* Border Color Top
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-t": [{ "border-t": scaleColor() }],
			/**
			* Border Color Right
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-r": [{ "border-r": scaleColor() }],
			/**
			* Border Color Bottom
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-b": [{ "border-b": scaleColor() }],
			/**
			* Border Color Left
			* @see https://tailwindcss.com/docs/border-color
			*/
			"border-color-l": [{ "border-l": scaleColor() }],
			/**
			* Divide Color
			* @see https://tailwindcss.com/docs/divide-color
			*/
			"divide-color": [{ divide: scaleColor() }],
			/**
			* Outline Style
			* @see https://tailwindcss.com/docs/outline-style
			*/
			"outline-style": [{ outline: [
				...scaleLineStyle(),
				"none",
				"hidden"
			] }],
			/**
			* Outline Offset
			* @see https://tailwindcss.com/docs/outline-offset
			*/
			"outline-offset": [{ "outline-offset": [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Outline Width
			* @see https://tailwindcss.com/docs/outline-width
			*/
			"outline-w": [{ outline: [
				"",
				isNumber,
				isArbitraryVariableLength,
				isArbitraryLength
			] }],
			/**
			* Outline Color
			* @see https://tailwindcss.com/docs/outline-color
			*/
			"outline-color": [{ outline: scaleColor() }],
			/**
			* Box Shadow
			* @see https://tailwindcss.com/docs/box-shadow
			*/
			shadow: [{ shadow: [
				"",
				"none",
				themeShadow,
				isArbitraryVariableShadow,
				isArbitraryShadow
			] }],
			/**
			* Box Shadow Color
			* @see https://tailwindcss.com/docs/box-shadow#setting-the-shadow-color
			*/
			"shadow-color": [{ shadow: scaleColor() }],
			/**
			* Inset Box Shadow
			* @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-shadow
			*/
			"inset-shadow": [{ "inset-shadow": [
				"none",
				themeInsetShadow,
				isArbitraryVariableShadow,
				isArbitraryShadow
			] }],
			/**
			* Inset Box Shadow Color
			* @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-shadow-color
			*/
			"inset-shadow-color": [{ "inset-shadow": scaleColor() }],
			/**
			* Ring Width
			* @see https://tailwindcss.com/docs/box-shadow#adding-a-ring
			*/
			"ring-w": [{ ring: scaleBorderWidth() }],
			/**
			* Ring Width Inset
			* @see https://v3.tailwindcss.com/docs/ring-width#inset-rings
			* @deprecated since Tailwind CSS v4.0.0
			* @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
			*/
			"ring-w-inset": ["ring-inset"],
			/**
			* Ring Color
			* @see https://tailwindcss.com/docs/box-shadow#setting-the-ring-color
			*/
			"ring-color": [{ ring: scaleColor() }],
			/**
			* Ring Offset Width
			* @see https://v3.tailwindcss.com/docs/ring-offset-width
			* @deprecated since Tailwind CSS v4.0.0
			* @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
			*/
			"ring-offset-w": [{ "ring-offset": [isNumber, isArbitraryLength] }],
			/**
			* Ring Offset Color
			* @see https://v3.tailwindcss.com/docs/ring-offset-color
			* @deprecated since Tailwind CSS v4.0.0
			* @see https://github.com/tailwindlabs/tailwindcss/blob/v4.0.0/packages/tailwindcss/src/utilities.ts#L4158
			*/
			"ring-offset-color": [{ "ring-offset": scaleColor() }],
			/**
			* Inset Ring Width
			* @see https://tailwindcss.com/docs/box-shadow#adding-an-inset-ring
			*/
			"inset-ring-w": [{ "inset-ring": scaleBorderWidth() }],
			/**
			* Inset Ring Color
			* @see https://tailwindcss.com/docs/box-shadow#setting-the-inset-ring-color
			*/
			"inset-ring-color": [{ "inset-ring": scaleColor() }],
			/**
			* Text Shadow
			* @see https://tailwindcss.com/docs/text-shadow
			*/
			"text-shadow": [{ "text-shadow": [
				"none",
				themeTextShadow,
				isArbitraryVariableShadow,
				isArbitraryShadow
			] }],
			/**
			* Text Shadow Color
			* @see https://tailwindcss.com/docs/text-shadow#setting-the-shadow-color
			*/
			"text-shadow-color": [{ "text-shadow": scaleColor() }],
			/**
			* Opacity
			* @see https://tailwindcss.com/docs/opacity
			*/
			opacity: [{ opacity: [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Mix Blend Mode
			* @see https://tailwindcss.com/docs/mix-blend-mode
			*/
			"mix-blend": [{ "mix-blend": [
				...scaleBlendMode(),
				"plus-darker",
				"plus-lighter"
			] }],
			/**
			* Background Blend Mode
			* @see https://tailwindcss.com/docs/background-blend-mode
			*/
			"bg-blend": [{ "bg-blend": scaleBlendMode() }],
			/**
			* Mask Clip
			* @see https://tailwindcss.com/docs/mask-clip
			*/
			"mask-clip": [{ "mask-clip": [
				"border",
				"padding",
				"content",
				"fill",
				"stroke",
				"view"
			] }, "mask-no-clip"],
			/**
			* Mask Composite
			* @see https://tailwindcss.com/docs/mask-composite
			*/
			"mask-composite": [{ mask: [
				"add",
				"subtract",
				"intersect",
				"exclude"
			] }],
			/**
			* Mask Image
			* @see https://tailwindcss.com/docs/mask-image
			*/
			"mask-image-linear-pos": [{ "mask-linear": [isNumber] }],
			"mask-image-linear-from-pos": [{ "mask-linear-from": scaleMaskImagePosition() }],
			"mask-image-linear-to-pos": [{ "mask-linear-to": scaleMaskImagePosition() }],
			"mask-image-linear-from-color": [{ "mask-linear-from": scaleColor() }],
			"mask-image-linear-to-color": [{ "mask-linear-to": scaleColor() }],
			"mask-image-t-from-pos": [{ "mask-t-from": scaleMaskImagePosition() }],
			"mask-image-t-to-pos": [{ "mask-t-to": scaleMaskImagePosition() }],
			"mask-image-t-from-color": [{ "mask-t-from": scaleColor() }],
			"mask-image-t-to-color": [{ "mask-t-to": scaleColor() }],
			"mask-image-r-from-pos": [{ "mask-r-from": scaleMaskImagePosition() }],
			"mask-image-r-to-pos": [{ "mask-r-to": scaleMaskImagePosition() }],
			"mask-image-r-from-color": [{ "mask-r-from": scaleColor() }],
			"mask-image-r-to-color": [{ "mask-r-to": scaleColor() }],
			"mask-image-b-from-pos": [{ "mask-b-from": scaleMaskImagePosition() }],
			"mask-image-b-to-pos": [{ "mask-b-to": scaleMaskImagePosition() }],
			"mask-image-b-from-color": [{ "mask-b-from": scaleColor() }],
			"mask-image-b-to-color": [{ "mask-b-to": scaleColor() }],
			"mask-image-l-from-pos": [{ "mask-l-from": scaleMaskImagePosition() }],
			"mask-image-l-to-pos": [{ "mask-l-to": scaleMaskImagePosition() }],
			"mask-image-l-from-color": [{ "mask-l-from": scaleColor() }],
			"mask-image-l-to-color": [{ "mask-l-to": scaleColor() }],
			"mask-image-x-from-pos": [{ "mask-x-from": scaleMaskImagePosition() }],
			"mask-image-x-to-pos": [{ "mask-x-to": scaleMaskImagePosition() }],
			"mask-image-x-from-color": [{ "mask-x-from": scaleColor() }],
			"mask-image-x-to-color": [{ "mask-x-to": scaleColor() }],
			"mask-image-y-from-pos": [{ "mask-y-from": scaleMaskImagePosition() }],
			"mask-image-y-to-pos": [{ "mask-y-to": scaleMaskImagePosition() }],
			"mask-image-y-from-color": [{ "mask-y-from": scaleColor() }],
			"mask-image-y-to-color": [{ "mask-y-to": scaleColor() }],
			"mask-image-radial": [{ "mask-radial": [isArbitraryVariable, isArbitraryValue] }],
			"mask-image-radial-from-pos": [{ "mask-radial-from": scaleMaskImagePosition() }],
			"mask-image-radial-to-pos": [{ "mask-radial-to": scaleMaskImagePosition() }],
			"mask-image-radial-from-color": [{ "mask-radial-from": scaleColor() }],
			"mask-image-radial-to-color": [{ "mask-radial-to": scaleColor() }],
			"mask-image-radial-shape": [{ "mask-radial": ["circle", "ellipse"] }],
			"mask-image-radial-size": [{ "mask-radial": [{
				closest: ["side", "corner"],
				farthest: ["side", "corner"]
			}] }],
			"mask-image-radial-pos": [{ "mask-radial-at": scalePosition() }],
			"mask-image-conic-pos": [{ "mask-conic": [isNumber] }],
			"mask-image-conic-from-pos": [{ "mask-conic-from": scaleMaskImagePosition() }],
			"mask-image-conic-to-pos": [{ "mask-conic-to": scaleMaskImagePosition() }],
			"mask-image-conic-from-color": [{ "mask-conic-from": scaleColor() }],
			"mask-image-conic-to-color": [{ "mask-conic-to": scaleColor() }],
			/**
			* Mask Mode
			* @see https://tailwindcss.com/docs/mask-mode
			*/
			"mask-mode": [{ mask: [
				"alpha",
				"luminance",
				"match"
			] }],
			/**
			* Mask Origin
			* @see https://tailwindcss.com/docs/mask-origin
			*/
			"mask-origin": [{ "mask-origin": [
				"border",
				"padding",
				"content",
				"fill",
				"stroke",
				"view"
			] }],
			/**
			* Mask Position
			* @see https://tailwindcss.com/docs/mask-position
			*/
			"mask-position": [{ mask: scaleBgPosition() }],
			/**
			* Mask Repeat
			* @see https://tailwindcss.com/docs/mask-repeat
			*/
			"mask-repeat": [{ mask: scaleBgRepeat() }],
			/**
			* Mask Size
			* @see https://tailwindcss.com/docs/mask-size
			*/
			"mask-size": [{ mask: scaleBgSize() }],
			/**
			* Mask Type
			* @see https://tailwindcss.com/docs/mask-type
			*/
			"mask-type": [{ "mask-type": ["alpha", "luminance"] }],
			/**
			* Mask Image
			* @see https://tailwindcss.com/docs/mask-image
			*/
			"mask-image": [{ mask: [
				"none",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Filter
			* @see https://tailwindcss.com/docs/filter
			*/
			filter: [{ filter: [
				"",
				"none",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Blur
			* @see https://tailwindcss.com/docs/blur
			*/
			blur: [{ blur: scaleBlur() }],
			/**
			* Brightness
			* @see https://tailwindcss.com/docs/brightness
			*/
			brightness: [{ brightness: [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Contrast
			* @see https://tailwindcss.com/docs/contrast
			*/
			contrast: [{ contrast: [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Drop Shadow
			* @see https://tailwindcss.com/docs/drop-shadow
			*/
			"drop-shadow": [{ "drop-shadow": [
				"",
				"none",
				themeDropShadow,
				isArbitraryVariableShadow,
				isArbitraryShadow
			] }],
			/**
			* Drop Shadow Color
			* @see https://tailwindcss.com/docs/filter-drop-shadow#setting-the-shadow-color
			*/
			"drop-shadow-color": [{ "drop-shadow": scaleColor() }],
			/**
			* Grayscale
			* @see https://tailwindcss.com/docs/grayscale
			*/
			grayscale: [{ grayscale: [
				"",
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Hue Rotate
			* @see https://tailwindcss.com/docs/hue-rotate
			*/
			"hue-rotate": [{ "hue-rotate": [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Invert
			* @see https://tailwindcss.com/docs/invert
			*/
			invert: [{ invert: [
				"",
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Saturate
			* @see https://tailwindcss.com/docs/saturate
			*/
			saturate: [{ saturate: [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Sepia
			* @see https://tailwindcss.com/docs/sepia
			*/
			sepia: [{ sepia: [
				"",
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Filter
			* @see https://tailwindcss.com/docs/backdrop-filter
			*/
			"backdrop-filter": [{ "backdrop-filter": [
				"",
				"none",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Blur
			* @see https://tailwindcss.com/docs/backdrop-blur
			*/
			"backdrop-blur": [{ "backdrop-blur": scaleBlur() }],
			/**
			* Backdrop Brightness
			* @see https://tailwindcss.com/docs/backdrop-brightness
			*/
			"backdrop-brightness": [{ "backdrop-brightness": [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Contrast
			* @see https://tailwindcss.com/docs/backdrop-contrast
			*/
			"backdrop-contrast": [{ "backdrop-contrast": [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Grayscale
			* @see https://tailwindcss.com/docs/backdrop-grayscale
			*/
			"backdrop-grayscale": [{ "backdrop-grayscale": [
				"",
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Hue Rotate
			* @see https://tailwindcss.com/docs/backdrop-hue-rotate
			*/
			"backdrop-hue-rotate": [{ "backdrop-hue-rotate": [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Invert
			* @see https://tailwindcss.com/docs/backdrop-invert
			*/
			"backdrop-invert": [{ "backdrop-invert": [
				"",
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Opacity
			* @see https://tailwindcss.com/docs/backdrop-opacity
			*/
			"backdrop-opacity": [{ "backdrop-opacity": [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Saturate
			* @see https://tailwindcss.com/docs/backdrop-saturate
			*/
			"backdrop-saturate": [{ "backdrop-saturate": [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backdrop Sepia
			* @see https://tailwindcss.com/docs/backdrop-sepia
			*/
			"backdrop-sepia": [{ "backdrop-sepia": [
				"",
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Border Collapse
			* @see https://tailwindcss.com/docs/border-collapse
			*/
			"border-collapse": [{ border: ["collapse", "separate"] }],
			/**
			* Border Spacing
			* @see https://tailwindcss.com/docs/border-spacing
			*/
			"border-spacing": [{ "border-spacing": scaleUnambiguousSpacing() }],
			/**
			* Border Spacing X
			* @see https://tailwindcss.com/docs/border-spacing
			*/
			"border-spacing-x": [{ "border-spacing-x": scaleUnambiguousSpacing() }],
			/**
			* Border Spacing Y
			* @see https://tailwindcss.com/docs/border-spacing
			*/
			"border-spacing-y": [{ "border-spacing-y": scaleUnambiguousSpacing() }],
			/**
			* Table Layout
			* @see https://tailwindcss.com/docs/table-layout
			*/
			"table-layout": [{ table: ["auto", "fixed"] }],
			/**
			* Caption Side
			* @see https://tailwindcss.com/docs/caption-side
			*/
			caption: [{ caption: ["top", "bottom"] }],
			/**
			* Transition Property
			* @see https://tailwindcss.com/docs/transition-property
			*/
			transition: [{ transition: [
				"",
				"all",
				"colors",
				"opacity",
				"shadow",
				"transform",
				"none",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Transition Behavior
			* @see https://tailwindcss.com/docs/transition-behavior
			*/
			"transition-behavior": [{ transition: ["normal", "discrete"] }],
			/**
			* Transition Duration
			* @see https://tailwindcss.com/docs/transition-duration
			*/
			duration: [{ duration: [
				isNumber,
				"initial",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Transition Timing Function
			* @see https://tailwindcss.com/docs/transition-timing-function
			*/
			ease: [{ ease: [
				"linear",
				"initial",
				themeEase,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Transition Delay
			* @see https://tailwindcss.com/docs/transition-delay
			*/
			delay: [{ delay: [
				isNumber,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Animation
			* @see https://tailwindcss.com/docs/animation
			*/
			animate: [{ animate: [
				"none",
				themeAnimate,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Backface Visibility
			* @see https://tailwindcss.com/docs/backface-visibility
			*/
			backface: [{ backface: ["hidden", "visible"] }],
			/**
			* Perspective
			* @see https://tailwindcss.com/docs/perspective
			*/
			perspective: [{ perspective: [
				themePerspective,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Perspective Origin
			* @see https://tailwindcss.com/docs/perspective-origin
			*/
			"perspective-origin": [{ "perspective-origin": scalePositionWithArbitrary() }],
			/**
			* Rotate
			* @see https://tailwindcss.com/docs/rotate
			*/
			rotate: [{ rotate: scaleRotate() }],
			/**
			* Rotate X
			* @see https://tailwindcss.com/docs/rotate
			*/
			"rotate-x": [{ "rotate-x": scaleRotate() }],
			/**
			* Rotate Y
			* @see https://tailwindcss.com/docs/rotate
			*/
			"rotate-y": [{ "rotate-y": scaleRotate() }],
			/**
			* Rotate Z
			* @see https://tailwindcss.com/docs/rotate
			*/
			"rotate-z": [{ "rotate-z": scaleRotate() }],
			/**
			* Scale
			* @see https://tailwindcss.com/docs/scale
			*/
			scale: [{ scale: scaleScale() }],
			/**
			* Scale X
			* @see https://tailwindcss.com/docs/scale
			*/
			"scale-x": [{ "scale-x": scaleScale() }],
			/**
			* Scale Y
			* @see https://tailwindcss.com/docs/scale
			*/
			"scale-y": [{ "scale-y": scaleScale() }],
			/**
			* Scale Z
			* @see https://tailwindcss.com/docs/scale
			*/
			"scale-z": [{ "scale-z": scaleScale() }],
			/**
			* Scale 3D
			* @see https://tailwindcss.com/docs/scale
			*/
			"scale-3d": ["scale-3d"],
			/**
			* Skew
			* @see https://tailwindcss.com/docs/skew
			*/
			skew: [{ skew: scaleSkew() }],
			/**
			* Skew X
			* @see https://tailwindcss.com/docs/skew
			*/
			"skew-x": [{ "skew-x": scaleSkew() }],
			/**
			* Skew Y
			* @see https://tailwindcss.com/docs/skew
			*/
			"skew-y": [{ "skew-y": scaleSkew() }],
			/**
			* Transform
			* @see https://tailwindcss.com/docs/transform
			*/
			transform: [{ transform: [
				isArbitraryVariable,
				isArbitraryValue,
				"",
				"none",
				"gpu",
				"cpu"
			] }],
			/**
			* Transform Origin
			* @see https://tailwindcss.com/docs/transform-origin
			*/
			"transform-origin": [{ origin: scalePositionWithArbitrary() }],
			/**
			* Transform Style
			* @see https://tailwindcss.com/docs/transform-style
			*/
			"transform-style": [{ transform: ["3d", "flat"] }],
			/**
			* Translate
			* @see https://tailwindcss.com/docs/translate
			*/
			translate: [{ translate: scaleTranslate() }],
			/**
			* Translate X
			* @see https://tailwindcss.com/docs/translate
			*/
			"translate-x": [{ "translate-x": scaleTranslate() }],
			/**
			* Translate Y
			* @see https://tailwindcss.com/docs/translate
			*/
			"translate-y": [{ "translate-y": scaleTranslate() }],
			/**
			* Translate Z
			* @see https://tailwindcss.com/docs/translate
			*/
			"translate-z": [{ "translate-z": scaleTranslate() }],
			/**
			* Translate None
			* @see https://tailwindcss.com/docs/translate
			*/
			"translate-none": ["translate-none"],
			/**
			* Zoom
			* @see https://tailwindcss.com/docs/zoom
			*/
			zoom: [{ zoom: [
				isInteger,
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Accent Color
			* @see https://tailwindcss.com/docs/accent-color
			*/
			accent: [{ accent: scaleColor() }],
			/**
			* Appearance
			* @see https://tailwindcss.com/docs/appearance
			*/
			appearance: [{ appearance: ["none", "auto"] }],
			/**
			* Caret Color
			* @see https://tailwindcss.com/docs/just-in-time-mode#caret-color-utilities
			*/
			"caret-color": [{ caret: scaleColor() }],
			/**
			* Color Scheme
			* @see https://tailwindcss.com/docs/color-scheme
			*/
			"color-scheme": [{ scheme: [
				"normal",
				"dark",
				"light",
				"light-dark",
				"only-dark",
				"only-light"
			] }],
			/**
			* Cursor
			* @see https://tailwindcss.com/docs/cursor
			*/
			cursor: [{ cursor: [
				"auto",
				"default",
				"pointer",
				"wait",
				"text",
				"move",
				"help",
				"not-allowed",
				"none",
				"context-menu",
				"progress",
				"cell",
				"crosshair",
				"vertical-text",
				"alias",
				"copy",
				"no-drop",
				"grab",
				"grabbing",
				"all-scroll",
				"col-resize",
				"row-resize",
				"n-resize",
				"e-resize",
				"s-resize",
				"w-resize",
				"ne-resize",
				"nw-resize",
				"se-resize",
				"sw-resize",
				"ew-resize",
				"ns-resize",
				"nesw-resize",
				"nwse-resize",
				"zoom-in",
				"zoom-out",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Field Sizing
			* @see https://tailwindcss.com/docs/field-sizing
			*/
			"field-sizing": [{ "field-sizing": ["fixed", "content"] }],
			/**
			* Pointer Events
			* @see https://tailwindcss.com/docs/pointer-events
			*/
			"pointer-events": [{ "pointer-events": ["auto", "none"] }],
			/**
			* Resize
			* @see https://tailwindcss.com/docs/resize
			*/
			resize: [{ resize: [
				"none",
				"",
				"y",
				"x"
			] }],
			/**
			* Scroll Behavior
			* @see https://tailwindcss.com/docs/scroll-behavior
			*/
			"scroll-behavior": [{ scroll: ["auto", "smooth"] }],
			/**
			* Scrollbar Thumb Color
			* @see https://tailwindcss.com/docs/scrollbar-color
			*/
			"scrollbar-thumb-color": [{ "scrollbar-thumb": scaleColor() }],
			/**
			* Scrollbar Track Color
			* @see https://tailwindcss.com/docs/scrollbar-color
			*/
			"scrollbar-track-color": [{ "scrollbar-track": scaleColor() }],
			/**
			* Scrollbar Gutter
			* @see https://tailwindcss.com/docs/scrollbar-gutter
			*/
			"scrollbar-gutter": [{ "scrollbar-gutter": [
				"auto",
				"stable",
				"both"
			] }],
			/**
			* Scrollbar Width
			* @see https://tailwindcss.com/docs/scrollbar-width
			*/
			"scrollbar-w": [{ scrollbar: [
				"auto",
				"thin",
				"none"
			] }],
			/**
			* Scroll Margin
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-m": [{ "scroll-m": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Inline
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-mx": [{ "scroll-mx": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Block
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-my": [{ "scroll-my": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Inline Start
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-ms": [{ "scroll-ms": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Inline End
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-me": [{ "scroll-me": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Block Start
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-mbs": [{ "scroll-mbs": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Block End
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-mbe": [{ "scroll-mbe": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Top
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-mt": [{ "scroll-mt": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Right
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-mr": [{ "scroll-mr": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Bottom
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-mb": [{ "scroll-mb": scaleUnambiguousSpacing() }],
			/**
			* Scroll Margin Left
			* @see https://tailwindcss.com/docs/scroll-margin
			*/
			"scroll-ml": [{ "scroll-ml": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-p": [{ "scroll-p": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Inline
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-px": [{ "scroll-px": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Block
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-py": [{ "scroll-py": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Inline Start
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-ps": [{ "scroll-ps": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Inline End
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-pe": [{ "scroll-pe": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Block Start
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-pbs": [{ "scroll-pbs": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Block End
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-pbe": [{ "scroll-pbe": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Top
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-pt": [{ "scroll-pt": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Right
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-pr": [{ "scroll-pr": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Bottom
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-pb": [{ "scroll-pb": scaleUnambiguousSpacing() }],
			/**
			* Scroll Padding Left
			* @see https://tailwindcss.com/docs/scroll-padding
			*/
			"scroll-pl": [{ "scroll-pl": scaleUnambiguousSpacing() }],
			/**
			* Scroll Snap Align
			* @see https://tailwindcss.com/docs/scroll-snap-align
			*/
			"snap-align": [{ snap: [
				"start",
				"end",
				"center",
				"align-none"
			] }],
			/**
			* Scroll Snap Stop
			* @see https://tailwindcss.com/docs/scroll-snap-stop
			*/
			"snap-stop": [{ snap: ["normal", "always"] }],
			/**
			* Scroll Snap Type
			* @see https://tailwindcss.com/docs/scroll-snap-type
			*/
			"snap-type": [{ snap: [
				"none",
				"x",
				"y",
				"both"
			] }],
			/**
			* Scroll Snap Type Strictness
			* @see https://tailwindcss.com/docs/scroll-snap-type
			*/
			"snap-strictness": [{ snap: ["mandatory", "proximity"] }],
			/**
			* Touch Action
			* @see https://tailwindcss.com/docs/touch-action
			*/
			touch: [{ touch: [
				"auto",
				"none",
				"manipulation"
			] }],
			/**
			* Touch Action X
			* @see https://tailwindcss.com/docs/touch-action
			*/
			"touch-x": [{ "touch-pan": [
				"x",
				"left",
				"right"
			] }],
			/**
			* Touch Action Y
			* @see https://tailwindcss.com/docs/touch-action
			*/
			"touch-y": [{ "touch-pan": [
				"y",
				"up",
				"down"
			] }],
			/**
			* Touch Action Pinch Zoom
			* @see https://tailwindcss.com/docs/touch-action
			*/
			"touch-pz": ["touch-pinch-zoom"],
			/**
			* User Select
			* @see https://tailwindcss.com/docs/user-select
			*/
			select: [{ select: [
				"none",
				"text",
				"all",
				"auto"
			] }],
			/**
			* Will Change
			* @see https://tailwindcss.com/docs/will-change
			*/
			"will-change": [{ "will-change": [
				"auto",
				"scroll",
				"contents",
				"transform",
				isArbitraryVariable,
				isArbitraryValue
			] }],
			/**
			* Fill
			* @see https://tailwindcss.com/docs/fill
			*/
			fill: [{ fill: ["none", ...scaleColor()] }],
			/**
			* Stroke Width
			* @see https://tailwindcss.com/docs/stroke-width
			*/
			"stroke-w": [{ stroke: [
				isNumber,
				isArbitraryVariableLength,
				isArbitraryLength,
				isArbitraryNumber
			] }],
			/**
			* Stroke
			* @see https://tailwindcss.com/docs/stroke
			*/
			stroke: [{ stroke: ["none", ...scaleColor()] }],
			/**
			* Forced Color Adjust
			* @see https://tailwindcss.com/docs/forced-color-adjust
			*/
			"forced-color-adjust": [{ "forced-color-adjust": ["auto", "none"] }]
		},
		conflictingClassGroups: {
			"container-named": ["container-type"],
			overflow: ["overflow-x", "overflow-y"],
			overscroll: ["overscroll-x", "overscroll-y"],
			inset: [
				"inset-x",
				"inset-y",
				"inset-bs",
				"inset-be",
				"start",
				"end",
				"top",
				"right",
				"bottom",
				"left"
			],
			"inset-x": ["right", "left"],
			"inset-y": ["top", "bottom"],
			flex: [
				"basis",
				"grow",
				"shrink"
			],
			gap: ["gap-x", "gap-y"],
			p: [
				"px",
				"py",
				"ps",
				"pe",
				"pbs",
				"pbe",
				"pt",
				"pr",
				"pb",
				"pl"
			],
			px: ["pr", "pl"],
			py: ["pt", "pb"],
			m: [
				"mx",
				"my",
				"ms",
				"me",
				"mbs",
				"mbe",
				"mt",
				"mr",
				"mb",
				"ml"
			],
			mx: ["mr", "ml"],
			my: ["mt", "mb"],
			size: ["w", "h"],
			"font-size": ["leading"],
			"fvn-normal": [
				"fvn-ordinal",
				"fvn-slashed-zero",
				"fvn-figure",
				"fvn-spacing",
				"fvn-fraction"
			],
			"fvn-ordinal": ["fvn-normal"],
			"fvn-slashed-zero": ["fvn-normal"],
			"fvn-figure": ["fvn-normal"],
			"fvn-spacing": ["fvn-normal"],
			"fvn-fraction": ["fvn-normal"],
			"line-clamp": ["display", "overflow"],
			rounded: [
				"rounded-s",
				"rounded-e",
				"rounded-t",
				"rounded-r",
				"rounded-b",
				"rounded-l",
				"rounded-ss",
				"rounded-se",
				"rounded-ee",
				"rounded-es",
				"rounded-tl",
				"rounded-tr",
				"rounded-br",
				"rounded-bl"
			],
			"rounded-s": ["rounded-ss", "rounded-es"],
			"rounded-e": ["rounded-se", "rounded-ee"],
			"rounded-t": ["rounded-tl", "rounded-tr"],
			"rounded-r": ["rounded-tr", "rounded-br"],
			"rounded-b": ["rounded-br", "rounded-bl"],
			"rounded-l": ["rounded-tl", "rounded-bl"],
			"border-spacing": ["border-spacing-x", "border-spacing-y"],
			"border-w": [
				"border-w-x",
				"border-w-y",
				"border-w-s",
				"border-w-e",
				"border-w-bs",
				"border-w-be",
				"border-w-t",
				"border-w-r",
				"border-w-b",
				"border-w-l"
			],
			"border-w-x": ["border-w-r", "border-w-l"],
			"border-w-y": ["border-w-t", "border-w-b"],
			"border-color": [
				"border-color-x",
				"border-color-y",
				"border-color-s",
				"border-color-e",
				"border-color-bs",
				"border-color-be",
				"border-color-t",
				"border-color-r",
				"border-color-b",
				"border-color-l"
			],
			"border-color-x": ["border-color-r", "border-color-l"],
			"border-color-y": ["border-color-t", "border-color-b"],
			translate: [
				"translate-x",
				"translate-y",
				"translate-none"
			],
			"translate-none": [
				"translate",
				"translate-x",
				"translate-y",
				"translate-z"
			],
			"scroll-m": [
				"scroll-mx",
				"scroll-my",
				"scroll-ms",
				"scroll-me",
				"scroll-mbs",
				"scroll-mbe",
				"scroll-mt",
				"scroll-mr",
				"scroll-mb",
				"scroll-ml"
			],
			"scroll-mx": ["scroll-mr", "scroll-ml"],
			"scroll-my": ["scroll-mt", "scroll-mb"],
			"scroll-p": [
				"scroll-px",
				"scroll-py",
				"scroll-ps",
				"scroll-pe",
				"scroll-pbs",
				"scroll-pbe",
				"scroll-pt",
				"scroll-pr",
				"scroll-pb",
				"scroll-pl"
			],
			"scroll-px": ["scroll-pr", "scroll-pl"],
			"scroll-py": ["scroll-pt", "scroll-pb"],
			touch: [
				"touch-x",
				"touch-y",
				"touch-pz"
			],
			"touch-x": ["touch"],
			"touch-y": ["touch"],
			"touch-pz": ["touch"]
		},
		conflictingClassGroupModifiers: { "font-size": ["leading"] },
		postfixLookupClassGroups: ["container-type"],
		orderSensitiveModifiers: [
			"*",
			"**",
			"after",
			"backdrop",
			"before",
			"details-content",
			"file",
			"first-letter",
			"first-line",
			"marker",
			"placeholder",
			"selection"
		]
	};
};
/**
* @param baseConfig Config where other config will be merged into. This object will be mutated.
* @param configExtension Partial config to merge into the `baseConfig`.
*/
var mergeConfigs = (baseConfig, { cacheSize, prefix, experimentalParseClassName, extend = {}, override = {} }) => {
	overrideProperty(baseConfig, "cacheSize", cacheSize);
	overrideProperty(baseConfig, "prefix", prefix);
	overrideProperty(baseConfig, "experimentalParseClassName", experimentalParseClassName);
	overrideConfigProperties(baseConfig.theme, override.theme);
	overrideConfigProperties(baseConfig.classGroups, override.classGroups);
	overrideConfigProperties(baseConfig.conflictingClassGroups, override.conflictingClassGroups);
	overrideConfigProperties(baseConfig.conflictingClassGroupModifiers, override.conflictingClassGroupModifiers);
	overrideProperty(baseConfig, "postfixLookupClassGroups", override.postfixLookupClassGroups);
	overrideProperty(baseConfig, "orderSensitiveModifiers", override.orderSensitiveModifiers);
	mergeConfigProperties(baseConfig.theme, extend.theme);
	mergeConfigProperties(baseConfig.classGroups, extend.classGroups);
	mergeConfigProperties(baseConfig.conflictingClassGroups, extend.conflictingClassGroups);
	mergeConfigProperties(baseConfig.conflictingClassGroupModifiers, extend.conflictingClassGroupModifiers);
	mergeArrayProperties(baseConfig, extend, "postfixLookupClassGroups");
	mergeArrayProperties(baseConfig, extend, "orderSensitiveModifiers");
	return baseConfig;
};
var overrideProperty = (baseObject, overrideKey, overrideValue) => {
	if (overrideValue !== void 0) baseObject[overrideKey] = overrideValue;
};
var overrideConfigProperties = (baseObject, overrideObject) => {
	if (overrideObject) for (const key in overrideObject) overrideProperty(baseObject, key, overrideObject[key]);
};
var mergeConfigProperties = (baseObject, mergeObject) => {
	if (mergeObject) for (const key in mergeObject) mergeArrayProperties(baseObject, mergeObject, key);
};
var mergeArrayProperties = (baseObject, mergeObject, key) => {
	const mergeValue = mergeObject[key];
	if (mergeValue !== void 0) baseObject[key] = baseObject[key] ? baseObject[key].concat(mergeValue) : mergeValue;
};
var extendTailwindMerge = (configExtension, ...createConfig) => typeof configExtension === "function" ? createTailwindMerge(getDefaultConfig, configExtension, ...createConfig) : createTailwindMerge(() => mergeConfigs(getDefaultConfig(), configExtension), ...createConfig);
var twMerge = /*#__PURE__*/ createTailwindMerge(getDefaultConfig);
//#endregion
export { createTailwindMerge, extendTailwindMerge, fromTheme, getDefaultConfig, mergeConfigs, twJoin, twMerge, validators };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGFpbHdpbmQtbWVyZ2UuanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLnBucG0vdGFpbHdpbmQtbWVyZ2VAMy42LjAvbm9kZV9tb2R1bGVzL3RhaWx3aW5kLW1lcmdlL2Rpc3QvYnVuZGxlLW1qcy5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBDb25jYXRlbmF0ZXMgdHdvIGFycmF5cyBmYXN0ZXIgdGhhbiB0aGUgYXJyYXkgc3ByZWFkIG9wZXJhdG9yLlxuICovXG5jb25zdCBjb25jYXRBcnJheXMgPSAoYXJyYXkxLCBhcnJheTIpID0+IHtcbiAgLy8gUHJlLWFsbG9jYXRlIGZvciBiZXR0ZXIgVjggb3B0aW1pemF0aW9uXG4gIGNvbnN0IGNvbWJpbmVkQXJyYXkgPSBuZXcgQXJyYXkoYXJyYXkxLmxlbmd0aCArIGFycmF5Mi5sZW5ndGgpO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGFycmF5MS5sZW5ndGg7IGkrKykge1xuICAgIGNvbWJpbmVkQXJyYXlbaV0gPSBhcnJheTFbaV07XG4gIH1cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBhcnJheTIubGVuZ3RoOyBpKyspIHtcbiAgICBjb21iaW5lZEFycmF5W2FycmF5MS5sZW5ndGggKyBpXSA9IGFycmF5MltpXTtcbiAgfVxuICByZXR1cm4gY29tYmluZWRBcnJheTtcbn07XG5cbi8vIEZhY3RvcnkgZnVuY3Rpb24gZW5zdXJlcyBjb25zaXN0ZW50IG9iamVjdCBzaGFwZXNcbmNvbnN0IGNyZWF0ZUNsYXNzVmFsaWRhdG9yT2JqZWN0ID0gKGNsYXNzR3JvdXBJZCwgdmFsaWRhdG9yKSA9PiAoe1xuICBjbGFzc0dyb3VwSWQsXG4gIHZhbGlkYXRvclxufSk7XG4vLyBGYWN0b3J5IGVuc3VyZXMgY29uc2lzdGVudCBDbGFzc1BhcnRPYmplY3Qgc2hhcGVcbmNvbnN0IGNyZWF0ZUNsYXNzUGFydE9iamVjdCA9IChuZXh0UGFydCA9IG5ldyBNYXAoKSwgdmFsaWRhdG9ycyA9IG51bGwsIGNsYXNzR3JvdXBJZCkgPT4gKHtcbiAgbmV4dFBhcnQsXG4gIHZhbGlkYXRvcnMsXG4gIGNsYXNzR3JvdXBJZFxufSk7XG5jb25zdCBDTEFTU19QQVJUX1NFUEFSQVRPUiA9ICctJztcbmNvbnN0IEVNUFRZX0NPTkZMSUNUUyA9IFtdO1xuLy8gSSB1c2UgdHdvIGRvdHMgaGVyZSBiZWNhdXNlIG9uZSBkb3QgaXMgdXNlZCBhcyBwcmVmaXggZm9yIGNsYXNzIGdyb3VwcyBpbiBwbHVnaW5zXG5jb25zdCBBUkJJVFJBUllfUFJPUEVSVFlfUFJFRklYID0gJ2FyYml0cmFyeS4uJztcbmNvbnN0IGNyZWF0ZUNsYXNzR3JvdXBVdGlscyA9IGNvbmZpZyA9PiB7XG4gIGNvbnN0IGNsYXNzTWFwID0gY3JlYXRlQ2xhc3NNYXAoY29uZmlnKTtcbiAgY29uc3Qge1xuICAgIGNvbmZsaWN0aW5nQ2xhc3NHcm91cHMsXG4gICAgY29uZmxpY3RpbmdDbGFzc0dyb3VwTW9kaWZpZXJzXG4gIH0gPSBjb25maWc7XG4gIGNvbnN0IGdldENsYXNzR3JvdXBJZCA9IGNsYXNzTmFtZSA9PiB7XG4gICAgaWYgKGNsYXNzTmFtZS5zdGFydHNXaXRoKCdbJykgJiYgY2xhc3NOYW1lLmVuZHNXaXRoKCddJykpIHtcbiAgICAgIHJldHVybiBnZXRHcm91cElkRm9yQXJiaXRyYXJ5UHJvcGVydHkoY2xhc3NOYW1lKTtcbiAgICB9XG4gICAgY29uc3QgY2xhc3NQYXJ0cyA9IGNsYXNzTmFtZS5zcGxpdChDTEFTU19QQVJUX1NFUEFSQVRPUik7XG4gICAgLy8gQ2xhc3NlcyBsaWtlIGAtaW5zZXQtMWAgcHJvZHVjZSBhbiBlbXB0eSBzdHJpbmcgYXMgZmlyc3QgY2xhc3NQYXJ0LiBXZSBhc3N1bWUgdGhhdCBjbGFzc2VzIGZvciBuZWdhdGl2ZSB2YWx1ZXMgYXJlIHVzZWQgY29ycmVjdGx5IGFuZCBza2lwIGl0LlxuICAgIGNvbnN0IHN0YXJ0SW5kZXggPSBjbGFzc1BhcnRzWzBdID09PSAnJyAmJiBjbGFzc1BhcnRzLmxlbmd0aCA+IDEgPyAxIDogMDtcbiAgICByZXR1cm4gZ2V0R3JvdXBSZWN1cnNpdmUoY2xhc3NQYXJ0cywgc3RhcnRJbmRleCwgY2xhc3NNYXApO1xuICB9O1xuICBjb25zdCBnZXRDb25mbGljdGluZ0NsYXNzR3JvdXBJZHMgPSAoY2xhc3NHcm91cElkLCBoYXNQb3N0Zml4TW9kaWZpZXIpID0+IHtcbiAgICBpZiAoaGFzUG9zdGZpeE1vZGlmaWVyKSB7XG4gICAgICBjb25zdCBtb2RpZmllckNvbmZsaWN0cyA9IGNvbmZsaWN0aW5nQ2xhc3NHcm91cE1vZGlmaWVyc1tjbGFzc0dyb3VwSWRdO1xuICAgICAgY29uc3QgYmFzZUNvbmZsaWN0cyA9IGNvbmZsaWN0aW5nQ2xhc3NHcm91cHNbY2xhc3NHcm91cElkXTtcbiAgICAgIGlmIChtb2RpZmllckNvbmZsaWN0cykge1xuICAgICAgICBpZiAoYmFzZUNvbmZsaWN0cykge1xuICAgICAgICAgIC8vIE1lcmdlIGJhc2UgY29uZmxpY3RzIHdpdGggbW9kaWZpZXIgY29uZmxpY3RzXG4gICAgICAgICAgcmV0dXJuIGNvbmNhdEFycmF5cyhiYXNlQ29uZmxpY3RzLCBtb2RpZmllckNvbmZsaWN0cyk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gT25seSBtb2RpZmllciBjb25mbGljdHNcbiAgICAgICAgcmV0dXJuIG1vZGlmaWVyQ29uZmxpY3RzO1xuICAgICAgfVxuICAgICAgLy8gRmFsbCBiYWNrIHRvIHdpdGhvdXQgcG9zdGZpeCBpZiBubyBtb2RpZmllciBjb25mbGljdHNcbiAgICAgIHJldHVybiBiYXNlQ29uZmxpY3RzIHx8IEVNUFRZX0NPTkZMSUNUUztcbiAgICB9XG4gICAgcmV0dXJuIGNvbmZsaWN0aW5nQ2xhc3NHcm91cHNbY2xhc3NHcm91cElkXSB8fCBFTVBUWV9DT05GTElDVFM7XG4gIH07XG4gIHJldHVybiB7XG4gICAgZ2V0Q2xhc3NHcm91cElkLFxuICAgIGdldENvbmZsaWN0aW5nQ2xhc3NHcm91cElkc1xuICB9O1xufTtcbmNvbnN0IGdldEdyb3VwUmVjdXJzaXZlID0gKGNsYXNzUGFydHMsIHN0YXJ0SW5kZXgsIGNsYXNzUGFydE9iamVjdCkgPT4ge1xuICBjb25zdCBjbGFzc1BhdGhzTGVuZ3RoID0gY2xhc3NQYXJ0cy5sZW5ndGggLSBzdGFydEluZGV4O1xuICBpZiAoY2xhc3NQYXRoc0xlbmd0aCA9PT0gMCkge1xuICAgIHJldHVybiBjbGFzc1BhcnRPYmplY3QuY2xhc3NHcm91cElkO1xuICB9XG4gIGNvbnN0IGN1cnJlbnRDbGFzc1BhcnQgPSBjbGFzc1BhcnRzW3N0YXJ0SW5kZXhdO1xuICBjb25zdCBuZXh0Q2xhc3NQYXJ0T2JqZWN0ID0gY2xhc3NQYXJ0T2JqZWN0Lm5leHRQYXJ0LmdldChjdXJyZW50Q2xhc3NQYXJ0KTtcbiAgaWYgKG5leHRDbGFzc1BhcnRPYmplY3QpIHtcbiAgICBjb25zdCByZXN1bHQgPSBnZXRHcm91cFJlY3Vyc2l2ZShjbGFzc1BhcnRzLCBzdGFydEluZGV4ICsgMSwgbmV4dENsYXNzUGFydE9iamVjdCk7XG4gICAgaWYgKHJlc3VsdCkgcmV0dXJuIHJlc3VsdDtcbiAgfVxuICBjb25zdCB2YWxpZGF0b3JzID0gY2xhc3NQYXJ0T2JqZWN0LnZhbGlkYXRvcnM7XG4gIGlmICh2YWxpZGF0b3JzID09PSBudWxsKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICAvLyBCdWlsZCBjbGFzc1Jlc3Qgc3RyaW5nIGVmZmljaWVudGx5IGJ5IGpvaW5pbmcgZnJvbSBzdGFydEluZGV4IG9ud2FyZHNcbiAgY29uc3QgY2xhc3NSZXN0ID0gc3RhcnRJbmRleCA9PT0gMCA/IGNsYXNzUGFydHMuam9pbihDTEFTU19QQVJUX1NFUEFSQVRPUikgOiBjbGFzc1BhcnRzLnNsaWNlKHN0YXJ0SW5kZXgpLmpvaW4oQ0xBU1NfUEFSVF9TRVBBUkFUT1IpO1xuICBjb25zdCB2YWxpZGF0b3JzTGVuZ3RoID0gdmFsaWRhdG9ycy5sZW5ndGg7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgdmFsaWRhdG9yc0xlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgdmFsaWRhdG9yT2JqID0gdmFsaWRhdG9yc1tpXTtcbiAgICBpZiAodmFsaWRhdG9yT2JqLnZhbGlkYXRvcihjbGFzc1Jlc3QpKSB7XG4gICAgICByZXR1cm4gdmFsaWRhdG9yT2JqLmNsYXNzR3JvdXBJZDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn07XG4vKipcbiAqIEdldCB0aGUgY2xhc3MgZ3JvdXAgSUQgZm9yIGFuIGFyYml0cmFyeSBwcm9wZXJ0eS5cbiAqXG4gKiBAcGFyYW0gY2xhc3NOYW1lIC0gVGhlIGNsYXNzIG5hbWUgdG8gZ2V0IHRoZSBncm91cCBJRCBmb3IuIElzIGV4cGVjdGVkIHRvIGJlIHN0cmluZyBzdGFydGluZyB3aXRoIGBbYCBhbmQgZW5kaW5nIHdpdGggYF1gLlxuICovXG5jb25zdCBnZXRHcm91cElkRm9yQXJiaXRyYXJ5UHJvcGVydHkgPSBjbGFzc05hbWUgPT4gY2xhc3NOYW1lLnNsaWNlKDEsIC0xKS5pbmRleE9mKCc6JykgPT09IC0xID8gdW5kZWZpbmVkIDogKCgpID0+IHtcbiAgY29uc3QgY29udGVudCA9IGNsYXNzTmFtZS5zbGljZSgxLCAtMSk7XG4gIGNvbnN0IGNvbG9uSW5kZXggPSBjb250ZW50LmluZGV4T2YoJzonKTtcbiAgY29uc3QgcHJvcGVydHkgPSBjb250ZW50LnNsaWNlKDAsIGNvbG9uSW5kZXgpO1xuICByZXR1cm4gcHJvcGVydHkgPyBBUkJJVFJBUllfUFJPUEVSVFlfUFJFRklYICsgcHJvcGVydHkgOiB1bmRlZmluZWQ7XG59KSgpO1xuLyoqXG4gKiBFeHBvcnRlZCBmb3IgdGVzdGluZyBvbmx5XG4gKi9cbmNvbnN0IGNyZWF0ZUNsYXNzTWFwID0gY29uZmlnID0+IHtcbiAgY29uc3Qge1xuICAgIHRoZW1lLFxuICAgIGNsYXNzR3JvdXBzXG4gIH0gPSBjb25maWc7XG4gIHJldHVybiBwcm9jZXNzQ2xhc3NHcm91cHMoY2xhc3NHcm91cHMsIHRoZW1lKTtcbn07XG4vLyBTcGxpdCBpbnRvIHNlcGFyYXRlIGZ1bmN0aW9ucyB0byBtYWludGFpbiBtb25vbW9ycGhpYyBjYWxsIHNpdGVzXG5jb25zdCBwcm9jZXNzQ2xhc3NHcm91cHMgPSAoY2xhc3NHcm91cHMsIHRoZW1lKSA9PiB7XG4gIGNvbnN0IGNsYXNzTWFwID0gY3JlYXRlQ2xhc3NQYXJ0T2JqZWN0KCk7XG4gIGZvciAoY29uc3QgY2xhc3NHcm91cElkIGluIGNsYXNzR3JvdXBzKSB7XG4gICAgY29uc3QgZ3JvdXAgPSBjbGFzc0dyb3Vwc1tjbGFzc0dyb3VwSWRdO1xuICAgIHByb2Nlc3NDbGFzc2VzUmVjdXJzaXZlbHkoZ3JvdXAsIGNsYXNzTWFwLCBjbGFzc0dyb3VwSWQsIHRoZW1lKTtcbiAgfVxuICByZXR1cm4gY2xhc3NNYXA7XG59O1xuY29uc3QgcHJvY2Vzc0NsYXNzZXNSZWN1cnNpdmVseSA9IChjbGFzc0dyb3VwLCBjbGFzc1BhcnRPYmplY3QsIGNsYXNzR3JvdXBJZCwgdGhlbWUpID0+IHtcbiAgY29uc3QgbGVuID0gY2xhc3NHcm91cC5sZW5ndGg7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICBjb25zdCBjbGFzc0RlZmluaXRpb24gPSBjbGFzc0dyb3VwW2ldO1xuICAgIHByb2Nlc3NDbGFzc0RlZmluaXRpb24oY2xhc3NEZWZpbml0aW9uLCBjbGFzc1BhcnRPYmplY3QsIGNsYXNzR3JvdXBJZCwgdGhlbWUpO1xuICB9XG59O1xuLy8gU3BsaXQgaW50byBzZXBhcmF0ZSBmdW5jdGlvbnMgZm9yIGVhY2ggdHlwZSB0byBtYWludGFpbiBtb25vbW9ycGhpYyBjYWxsIHNpdGVzXG5jb25zdCBwcm9jZXNzQ2xhc3NEZWZpbml0aW9uID0gKGNsYXNzRGVmaW5pdGlvbiwgY2xhc3NQYXJ0T2JqZWN0LCBjbGFzc0dyb3VwSWQsIHRoZW1lKSA9PiB7XG4gIGlmICh0eXBlb2YgY2xhc3NEZWZpbml0aW9uID09PSAnc3RyaW5nJykge1xuICAgIHByb2Nlc3NTdHJpbmdEZWZpbml0aW9uKGNsYXNzRGVmaW5pdGlvbiwgY2xhc3NQYXJ0T2JqZWN0LCBjbGFzc0dyb3VwSWQpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAodHlwZW9mIGNsYXNzRGVmaW5pdGlvbiA9PT0gJ2Z1bmN0aW9uJykge1xuICAgIHByb2Nlc3NGdW5jdGlvbkRlZmluaXRpb24oY2xhc3NEZWZpbml0aW9uLCBjbGFzc1BhcnRPYmplY3QsIGNsYXNzR3JvdXBJZCwgdGhlbWUpO1xuICAgIHJldHVybjtcbiAgfVxuICBwcm9jZXNzT2JqZWN0RGVmaW5pdGlvbihjbGFzc0RlZmluaXRpb24sIGNsYXNzUGFydE9iamVjdCwgY2xhc3NHcm91cElkLCB0aGVtZSk7XG59O1xuY29uc3QgcHJvY2Vzc1N0cmluZ0RlZmluaXRpb24gPSAoY2xhc3NEZWZpbml0aW9uLCBjbGFzc1BhcnRPYmplY3QsIGNsYXNzR3JvdXBJZCkgPT4ge1xuICBjb25zdCBjbGFzc1BhcnRPYmplY3RUb0VkaXQgPSBjbGFzc0RlZmluaXRpb24gPT09ICcnID8gY2xhc3NQYXJ0T2JqZWN0IDogZ2V0UGFydChjbGFzc1BhcnRPYmplY3QsIGNsYXNzRGVmaW5pdGlvbik7XG4gIGNsYXNzUGFydE9iamVjdFRvRWRpdC5jbGFzc0dyb3VwSWQgPSBjbGFzc0dyb3VwSWQ7XG59O1xuY29uc3QgcHJvY2Vzc0Z1bmN0aW9uRGVmaW5pdGlvbiA9IChjbGFzc0RlZmluaXRpb24sIGNsYXNzUGFydE9iamVjdCwgY2xhc3NHcm91cElkLCB0aGVtZSkgPT4ge1xuICBpZiAoaXNUaGVtZUdldHRlcihjbGFzc0RlZmluaXRpb24pKSB7XG4gICAgcHJvY2Vzc0NsYXNzZXNSZWN1cnNpdmVseShjbGFzc0RlZmluaXRpb24odGhlbWUpLCBjbGFzc1BhcnRPYmplY3QsIGNsYXNzR3JvdXBJZCwgdGhlbWUpO1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoY2xhc3NQYXJ0T2JqZWN0LnZhbGlkYXRvcnMgPT09IG51bGwpIHtcbiAgICBjbGFzc1BhcnRPYmplY3QudmFsaWRhdG9ycyA9IFtdO1xuICB9XG4gIGNsYXNzUGFydE9iamVjdC52YWxpZGF0b3JzLnB1c2goY3JlYXRlQ2xhc3NWYWxpZGF0b3JPYmplY3QoY2xhc3NHcm91cElkLCBjbGFzc0RlZmluaXRpb24pKTtcbn07XG5jb25zdCBwcm9jZXNzT2JqZWN0RGVmaW5pdGlvbiA9IChjbGFzc0RlZmluaXRpb24sIGNsYXNzUGFydE9iamVjdCwgY2xhc3NHcm91cElkLCB0aGVtZSkgPT4ge1xuICBjb25zdCBlbnRyaWVzID0gT2JqZWN0LmVudHJpZXMoY2xhc3NEZWZpbml0aW9uKTtcbiAgY29uc3QgbGVuID0gZW50cmllcy5sZW5ndGg7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICBjb25zdCBba2V5LCB2YWx1ZV0gPSBlbnRyaWVzW2ldO1xuICAgIHByb2Nlc3NDbGFzc2VzUmVjdXJzaXZlbHkodmFsdWUsIGdldFBhcnQoY2xhc3NQYXJ0T2JqZWN0LCBrZXkpLCBjbGFzc0dyb3VwSWQsIHRoZW1lKTtcbiAgfVxufTtcbmNvbnN0IGdldFBhcnQgPSAoY2xhc3NQYXJ0T2JqZWN0LCBwYXRoKSA9PiB7XG4gIGxldCBjdXJyZW50ID0gY2xhc3NQYXJ0T2JqZWN0O1xuICBjb25zdCBwYXJ0cyA9IHBhdGguc3BsaXQoQ0xBU1NfUEFSVF9TRVBBUkFUT1IpO1xuICBjb25zdCBsZW4gPSBwYXJ0cy5sZW5ndGg7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICBjb25zdCBwYXJ0ID0gcGFydHNbaV07XG4gICAgbGV0IG5leHQgPSBjdXJyZW50Lm5leHRQYXJ0LmdldChwYXJ0KTtcbiAgICBpZiAoIW5leHQpIHtcbiAgICAgIG5leHQgPSBjcmVhdGVDbGFzc1BhcnRPYmplY3QoKTtcbiAgICAgIGN1cnJlbnQubmV4dFBhcnQuc2V0KHBhcnQsIG5leHQpO1xuICAgIH1cbiAgICBjdXJyZW50ID0gbmV4dDtcbiAgfVxuICByZXR1cm4gY3VycmVudDtcbn07XG4vLyBUeXBlIGd1YXJkIG1haW50YWlucyBtb25vbW9ycGhpYyBjaGVja1xuY29uc3QgaXNUaGVtZUdldHRlciA9IGZ1bmMgPT4gJ2lzVGhlbWVHZXR0ZXInIGluIGZ1bmMgJiYgZnVuYy5pc1RoZW1lR2V0dGVyID09PSB0cnVlO1xuXG4vLyBMUlUgY2FjaGUgaW1wbGVtZW50YXRpb24gdXNpbmcgcGxhaW4gb2JqZWN0cyBmb3Igc2ltcGxpY2l0eVxuY29uc3QgY3JlYXRlTHJ1Q2FjaGUgPSBtYXhDYWNoZVNpemUgPT4ge1xuICBpZiAobWF4Q2FjaGVTaXplIDwgMSkge1xuICAgIHJldHVybiB7XG4gICAgICBnZXQ6ICgpID0+IHVuZGVmaW5lZCxcbiAgICAgIHNldDogKCkgPT4ge31cbiAgICB9O1xuICB9XG4gIGxldCBjYWNoZVNpemUgPSAwO1xuICBsZXQgY2FjaGUgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBsZXQgcHJldmlvdXNDYWNoZSA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gIGNvbnN0IHVwZGF0ZSA9IChrZXksIHZhbHVlKSA9PiB7XG4gICAgY2FjaGVba2V5XSA9IHZhbHVlO1xuICAgIGNhY2hlU2l6ZSsrO1xuICAgIGlmIChjYWNoZVNpemUgPiBtYXhDYWNoZVNpemUpIHtcbiAgICAgIGNhY2hlU2l6ZSA9IDA7XG4gICAgICBwcmV2aW91c0NhY2hlID0gY2FjaGU7XG4gICAgICBjYWNoZSA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgfVxuICB9O1xuICByZXR1cm4ge1xuICAgIGdldChrZXkpIHtcbiAgICAgIGxldCB2YWx1ZSA9IGNhY2hlW2tleV07XG4gICAgICBpZiAodmFsdWUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICB9XG4gICAgICBpZiAoKHZhbHVlID0gcHJldmlvdXNDYWNoZVtrZXldKSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHVwZGF0ZShrZXksIHZhbHVlKTtcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgfVxuICAgIH0sXG4gICAgc2V0KGtleSwgdmFsdWUpIHtcbiAgICAgIGlmIChrZXkgaW4gY2FjaGUpIHtcbiAgICAgICAgY2FjaGVba2V5XSA9IHZhbHVlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdXBkYXRlKGtleSwgdmFsdWUpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbn07XG5jb25zdCBJTVBPUlRBTlRfTU9ESUZJRVIgPSAnISc7XG5jb25zdCBNT0RJRklFUl9TRVBBUkFUT1IgPSAnOic7XG5jb25zdCBFTVBUWV9NT0RJRklFUlMgPSBbXTtcbi8vIFByZS1hbGxvY2F0ZWQgcmVzdWx0IG9iamVjdCBzaGFwZSBmb3IgY29uc2lzdGVuY3lcbmNvbnN0IGNyZWF0ZVJlc3VsdE9iamVjdCA9IChtb2RpZmllcnMsIGhhc0ltcG9ydGFudE1vZGlmaWVyLCBiYXNlQ2xhc3NOYW1lLCBtYXliZVBvc3RmaXhNb2RpZmllclBvc2l0aW9uLCBpc0V4dGVybmFsKSA9PiAoe1xuICBtb2RpZmllcnMsXG4gIGhhc0ltcG9ydGFudE1vZGlmaWVyLFxuICBiYXNlQ2xhc3NOYW1lLFxuICBtYXliZVBvc3RmaXhNb2RpZmllclBvc2l0aW9uLFxuICBpc0V4dGVybmFsXG59KTtcbmNvbnN0IGNyZWF0ZVBhcnNlQ2xhc3NOYW1lID0gY29uZmlnID0+IHtcbiAgY29uc3Qge1xuICAgIHByZWZpeCxcbiAgICBleHBlcmltZW50YWxQYXJzZUNsYXNzTmFtZVxuICB9ID0gY29uZmlnO1xuICAvKipcbiAgICogUGFyc2UgY2xhc3MgbmFtZSBpbnRvIHBhcnRzLlxuICAgKlxuICAgKiBJbnNwaXJlZCBieSBgc3BsaXRBdFRvcExldmVsT25seWAgdXNlZCBpbiBUYWlsd2luZCBDU1NcbiAgICogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vdGFpbHdpbmRsYWJzL3RhaWx3aW5kY3NzL2Jsb2IvdjMuMi4yL3NyYy91dGlsL3NwbGl0QXRUb3BMZXZlbE9ubHkuanNcbiAgICovXG4gIGxldCBwYXJzZUNsYXNzTmFtZSA9IGNsYXNzTmFtZSA9PiB7XG4gICAgLy8gVXNlIHNpbXBsZSBhcnJheSB3aXRoIHB1c2ggZm9yIGJldHRlciBwZXJmb3JtYW5jZVxuICAgIGNvbnN0IG1vZGlmaWVycyA9IFtdO1xuICAgIGxldCBicmFja2V0RGVwdGggPSAwO1xuICAgIGxldCBwYXJlbkRlcHRoID0gMDtcbiAgICBsZXQgbW9kaWZpZXJTdGFydCA9IDA7XG4gICAgbGV0IHBvc3RmaXhNb2RpZmllclBvc2l0aW9uO1xuICAgIGNvbnN0IGxlbiA9IGNsYXNzTmFtZS5sZW5ndGg7XG4gICAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGxlbjsgaW5kZXgrKykge1xuICAgICAgY29uc3QgY3VycmVudENoYXJhY3RlciA9IGNsYXNzTmFtZVtpbmRleF07XG4gICAgICBpZiAoYnJhY2tldERlcHRoID09PSAwICYmIHBhcmVuRGVwdGggPT09IDApIHtcbiAgICAgICAgaWYgKGN1cnJlbnRDaGFyYWN0ZXIgPT09IE1PRElGSUVSX1NFUEFSQVRPUikge1xuICAgICAgICAgIG1vZGlmaWVycy5wdXNoKGNsYXNzTmFtZS5zbGljZShtb2RpZmllclN0YXJ0LCBpbmRleCkpO1xuICAgICAgICAgIG1vZGlmaWVyU3RhcnQgPSBpbmRleCArIDE7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGN1cnJlbnRDaGFyYWN0ZXIgPT09ICcvJykge1xuICAgICAgICAgIHBvc3RmaXhNb2RpZmllclBvc2l0aW9uID0gaW5kZXg7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChjdXJyZW50Q2hhcmFjdGVyID09PSAnWycpIGJyYWNrZXREZXB0aCsrO2Vsc2UgaWYgKGN1cnJlbnRDaGFyYWN0ZXIgPT09ICddJykgYnJhY2tldERlcHRoLS07ZWxzZSBpZiAoY3VycmVudENoYXJhY3RlciA9PT0gJygnKSBwYXJlbkRlcHRoKys7ZWxzZSBpZiAoY3VycmVudENoYXJhY3RlciA9PT0gJyknKSBwYXJlbkRlcHRoLS07XG4gICAgfVxuICAgIGNvbnN0IGJhc2VDbGFzc05hbWVXaXRoSW1wb3J0YW50TW9kaWZpZXIgPSBtb2RpZmllcnMubGVuZ3RoID09PSAwID8gY2xhc3NOYW1lIDogY2xhc3NOYW1lLnNsaWNlKG1vZGlmaWVyU3RhcnQpO1xuICAgIC8vIElubGluZSBpbXBvcnRhbnQgbW9kaWZpZXIgY2hlY2tcbiAgICBsZXQgYmFzZUNsYXNzTmFtZSA9IGJhc2VDbGFzc05hbWVXaXRoSW1wb3J0YW50TW9kaWZpZXI7XG4gICAgbGV0IGhhc0ltcG9ydGFudE1vZGlmaWVyID0gZmFsc2U7XG4gICAgaWYgKGJhc2VDbGFzc05hbWVXaXRoSW1wb3J0YW50TW9kaWZpZXIuZW5kc1dpdGgoSU1QT1JUQU5UX01PRElGSUVSKSkge1xuICAgICAgYmFzZUNsYXNzTmFtZSA9IGJhc2VDbGFzc05hbWVXaXRoSW1wb3J0YW50TW9kaWZpZXIuc2xpY2UoMCwgLTEpO1xuICAgICAgaGFzSW1wb3J0YW50TW9kaWZpZXIgPSB0cnVlO1xuICAgIH0gZWxzZSBpZiAoXG4gICAgLyoqXG4gICAgICogSW4gVGFpbHdpbmQgQ1NTIHYzIHRoZSBpbXBvcnRhbnQgbW9kaWZpZXIgd2FzIGF0IHRoZSBzdGFydCBvZiB0aGUgYmFzZSBjbGFzcyBuYW1lLiBUaGlzIGlzIHN0aWxsIHN1cHBvcnRlZCBmb3IgbGVnYWN5IHJlYXNvbnMuXG4gICAgICogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vZGNhc3RpbC90YWlsd2luZC1tZXJnZS9pc3N1ZXMvNTEzI2lzc3VlY29tbWVudC0yNjE0MDI5ODY0XG4gICAgICovXG4gICAgYmFzZUNsYXNzTmFtZVdpdGhJbXBvcnRhbnRNb2RpZmllci5zdGFydHNXaXRoKElNUE9SVEFOVF9NT0RJRklFUikpIHtcbiAgICAgIGJhc2VDbGFzc05hbWUgPSBiYXNlQ2xhc3NOYW1lV2l0aEltcG9ydGFudE1vZGlmaWVyLnNsaWNlKDEpO1xuICAgICAgaGFzSW1wb3J0YW50TW9kaWZpZXIgPSB0cnVlO1xuICAgIH1cbiAgICBjb25zdCBtYXliZVBvc3RmaXhNb2RpZmllclBvc2l0aW9uID0gcG9zdGZpeE1vZGlmaWVyUG9zaXRpb24gJiYgcG9zdGZpeE1vZGlmaWVyUG9zaXRpb24gPiBtb2RpZmllclN0YXJ0ID8gcG9zdGZpeE1vZGlmaWVyUG9zaXRpb24gLSBtb2RpZmllclN0YXJ0IDogdW5kZWZpbmVkO1xuICAgIHJldHVybiBjcmVhdGVSZXN1bHRPYmplY3QobW9kaWZpZXJzLCBoYXNJbXBvcnRhbnRNb2RpZmllciwgYmFzZUNsYXNzTmFtZSwgbWF5YmVQb3N0Zml4TW9kaWZpZXJQb3NpdGlvbik7XG4gIH07XG4gIGlmIChwcmVmaXgpIHtcbiAgICBjb25zdCBmdWxsUHJlZml4ID0gcHJlZml4ICsgTU9ESUZJRVJfU0VQQVJBVE9SO1xuICAgIGNvbnN0IHBhcnNlQ2xhc3NOYW1lT3JpZ2luYWwgPSBwYXJzZUNsYXNzTmFtZTtcbiAgICBwYXJzZUNsYXNzTmFtZSA9IGNsYXNzTmFtZSA9PiBjbGFzc05hbWUuc3RhcnRzV2l0aChmdWxsUHJlZml4KSA/IHBhcnNlQ2xhc3NOYW1lT3JpZ2luYWwoY2xhc3NOYW1lLnNsaWNlKGZ1bGxQcmVmaXgubGVuZ3RoKSkgOiBjcmVhdGVSZXN1bHRPYmplY3QoRU1QVFlfTU9ESUZJRVJTLCBmYWxzZSwgY2xhc3NOYW1lLCB1bmRlZmluZWQsIHRydWUpO1xuICB9XG4gIGlmIChleHBlcmltZW50YWxQYXJzZUNsYXNzTmFtZSkge1xuICAgIGNvbnN0IHBhcnNlQ2xhc3NOYW1lT3JpZ2luYWwgPSBwYXJzZUNsYXNzTmFtZTtcbiAgICBwYXJzZUNsYXNzTmFtZSA9IGNsYXNzTmFtZSA9PiBleHBlcmltZW50YWxQYXJzZUNsYXNzTmFtZSh7XG4gICAgICBjbGFzc05hbWUsXG4gICAgICBwYXJzZUNsYXNzTmFtZTogcGFyc2VDbGFzc05hbWVPcmlnaW5hbFxuICAgIH0pO1xuICB9XG4gIHJldHVybiBwYXJzZUNsYXNzTmFtZTtcbn07XG5cbi8qKlxuICogU29ydHMgbW9kaWZpZXJzIGFjY29yZGluZyB0byBmb2xsb3dpbmcgc2NoZW1hOlxuICogLSBQcmVkZWZpbmVkIG1vZGlmaWVycyBhcmUgc29ydGVkIGFscGhhYmV0aWNhbGx5XG4gKiAtIFdoZW4gYW4gYXJiaXRyYXJ5IHZhcmlhbnQgYXBwZWFycywgaXQgbXVzdCBiZSBwcmVzZXJ2ZWQgd2hpY2ggbW9kaWZpZXJzIGFyZSBiZWZvcmUgYW5kIGFmdGVyIGl0XG4gKi9cbmNvbnN0IGNyZWF0ZVNvcnRNb2RpZmllcnMgPSBjb25maWcgPT4ge1xuICAvLyBQcmUtY29tcHV0ZSB3ZWlnaHRzIGZvciBhbGwga25vd24gbW9kaWZpZXJzIGZvciBPKDEpIGNvbXBhcmlzb25cbiAgY29uc3QgbW9kaWZpZXJXZWlnaHRzID0gbmV3IE1hcCgpO1xuICAvLyBBc3NpZ24gd2VpZ2h0cyB0byBzZW5zaXRpdmUgbW9kaWZpZXJzIChoaWdoZXN0IHByaW9yaXR5LCBidXQgcHJlc2VydmUgb3JkZXIpXG4gIGNvbmZpZy5vcmRlclNlbnNpdGl2ZU1vZGlmaWVycy5mb3JFYWNoKChtb2QsIGluZGV4KSA9PiB7XG4gICAgbW9kaWZpZXJXZWlnaHRzLnNldChtb2QsIDEwMDAwMDAgKyBpbmRleCk7IC8vIEhpZ2ggd2VpZ2h0cyBmb3Igc2Vuc2l0aXZlIG1vZHNcbiAgfSk7XG4gIHJldHVybiBtb2RpZmllcnMgPT4ge1xuICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgIGxldCBjdXJyZW50U2VnbWVudCA9IFtdO1xuICAgIC8vIFByb2Nlc3MgbW9kaWZpZXJzIGluIG9uZSBwYXNzXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtb2RpZmllcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IG1vZGlmaWVyID0gbW9kaWZpZXJzW2ldO1xuICAgICAgLy8gQ2hlY2sgaWYgbW9kaWZpZXIgaXMgc2Vuc2l0aXZlIChzdGFydHMgd2l0aCAnWycgb3IgaW4gb3JkZXJTZW5zaXRpdmVNb2RpZmllcnMpXG4gICAgICBjb25zdCBpc0FyYml0cmFyeSA9IG1vZGlmaWVyWzBdID09PSAnWyc7XG4gICAgICBjb25zdCBpc09yZGVyU2Vuc2l0aXZlID0gbW9kaWZpZXJXZWlnaHRzLmhhcyhtb2RpZmllcik7XG4gICAgICBpZiAoaXNBcmJpdHJhcnkgfHwgaXNPcmRlclNlbnNpdGl2ZSkge1xuICAgICAgICAvLyBTb3J0IGFuZCBmbHVzaCBjdXJyZW50IHNlZ21lbnQgYWxwaGFiZXRpY2FsbHlcbiAgICAgICAgaWYgKGN1cnJlbnRTZWdtZW50Lmxlbmd0aCA+IDApIHtcbiAgICAgICAgICBjdXJyZW50U2VnbWVudC5zb3J0KCk7XG4gICAgICAgICAgcmVzdWx0LnB1c2goLi4uY3VycmVudFNlZ21lbnQpO1xuICAgICAgICAgIGN1cnJlbnRTZWdtZW50ID0gW107XG4gICAgICAgIH1cbiAgICAgICAgcmVzdWx0LnB1c2gobW9kaWZpZXIpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gUmVndWxhciBtb2RpZmllciAtIGFkZCB0byBjdXJyZW50IHNlZ21lbnQgZm9yIGJhdGNoIHNvcnRpbmdcbiAgICAgICAgY3VycmVudFNlZ21lbnQucHVzaChtb2RpZmllcik7XG4gICAgICB9XG4gICAgfVxuICAgIC8vIFNvcnQgYW5kIGFkZCBhbnkgcmVtYWluaW5nIHNlZ21lbnQgaXRlbXNcbiAgICBpZiAoY3VycmVudFNlZ21lbnQubGVuZ3RoID4gMCkge1xuICAgICAgY3VycmVudFNlZ21lbnQuc29ydCgpO1xuICAgICAgcmVzdWx0LnB1c2goLi4uY3VycmVudFNlZ21lbnQpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9O1xufTtcbmNvbnN0IGNyZWF0ZUNvbmZpZ1V0aWxzID0gY29uZmlnID0+ICh7XG4gIGNhY2hlOiBjcmVhdGVMcnVDYWNoZShjb25maWcuY2FjaGVTaXplKSxcbiAgcGFyc2VDbGFzc05hbWU6IGNyZWF0ZVBhcnNlQ2xhc3NOYW1lKGNvbmZpZyksXG4gIHNvcnRNb2RpZmllcnM6IGNyZWF0ZVNvcnRNb2RpZmllcnMoY29uZmlnKSxcbiAgcG9zdGZpeExvb2t1cENsYXNzR3JvdXBJZHM6IGNyZWF0ZVBvc3RmaXhMb29rdXBDbGFzc0dyb3VwSWRzKGNvbmZpZyksXG4gIC4uLmNyZWF0ZUNsYXNzR3JvdXBVdGlscyhjb25maWcpXG59KTtcbmNvbnN0IGNyZWF0ZVBvc3RmaXhMb29rdXBDbGFzc0dyb3VwSWRzID0gY29uZmlnID0+IHtcbiAgY29uc3QgbG9va3VwID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgY29uc3QgY2xhc3NHcm91cElkcyA9IGNvbmZpZy5wb3N0Zml4TG9va3VwQ2xhc3NHcm91cHM7XG4gIGlmIChjbGFzc0dyb3VwSWRzKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjbGFzc0dyb3VwSWRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBsb29rdXBbY2xhc3NHcm91cElkc1tpXV0gPSB0cnVlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbG9va3VwO1xufTtcbmNvbnN0IFNQTElUX0NMQVNTRVNfUkVHRVggPSAvXFxzKy87XG5jb25zdCBtZXJnZUNsYXNzTGlzdCA9IChjbGFzc0xpc3QsIGNvbmZpZ1V0aWxzKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBwYXJzZUNsYXNzTmFtZSxcbiAgICBnZXRDbGFzc0dyb3VwSWQsXG4gICAgZ2V0Q29uZmxpY3RpbmdDbGFzc0dyb3VwSWRzLFxuICAgIHNvcnRNb2RpZmllcnMsXG4gICAgcG9zdGZpeExvb2t1cENsYXNzR3JvdXBJZHNcbiAgfSA9IGNvbmZpZ1V0aWxzO1xuICAvKipcbiAgICogU2V0IG9mIGNsYXNzR3JvdXBJZHMgaW4gZm9sbG93aW5nIGZvcm1hdDpcbiAgICogYHtpbXBvcnRhbnRNb2RpZmllcn17dmFyaWFudE1vZGlmaWVyc317Y2xhc3NHcm91cElkfWBcbiAgICogQGV4YW1wbGUgJ2Zsb2F0J1xuICAgKiBAZXhhbXBsZSAnaG92ZXI6Zm9jdXM6YmctY29sb3InXG4gICAqIEBleGFtcGxlICdtZDohcHInXG4gICAqL1xuICBjb25zdCBjbGFzc0dyb3Vwc0luQ29uZmxpY3QgPSBbXTtcbiAgY29uc3QgY2xhc3NOYW1lcyA9IGNsYXNzTGlzdC50cmltKCkuc3BsaXQoU1BMSVRfQ0xBU1NFU19SRUdFWCk7XG4gIGxldCByZXN1bHQgPSAnJztcbiAgZm9yIChsZXQgaW5kZXggPSBjbGFzc05hbWVzLmxlbmd0aCAtIDE7IGluZGV4ID49IDA7IGluZGV4IC09IDEpIHtcbiAgICBjb25zdCBvcmlnaW5hbENsYXNzTmFtZSA9IGNsYXNzTmFtZXNbaW5kZXhdO1xuICAgIGNvbnN0IHtcbiAgICAgIGlzRXh0ZXJuYWwsXG4gICAgICBtb2RpZmllcnMsXG4gICAgICBoYXNJbXBvcnRhbnRNb2RpZmllcixcbiAgICAgIGJhc2VDbGFzc05hbWUsXG4gICAgICBtYXliZVBvc3RmaXhNb2RpZmllclBvc2l0aW9uXG4gICAgfSA9IHBhcnNlQ2xhc3NOYW1lKG9yaWdpbmFsQ2xhc3NOYW1lKTtcbiAgICBpZiAoaXNFeHRlcm5hbCkge1xuICAgICAgcmVzdWx0ID0gb3JpZ2luYWxDbGFzc05hbWUgKyAocmVzdWx0Lmxlbmd0aCA+IDAgPyAnICcgKyByZXN1bHQgOiByZXN1bHQpO1xuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGxldCBoYXNQb3N0Zml4TW9kaWZpZXIgPSAhIW1heWJlUG9zdGZpeE1vZGlmaWVyUG9zaXRpb247XG4gICAgbGV0IGNsYXNzR3JvdXBJZDtcbiAgICBpZiAoaGFzUG9zdGZpeE1vZGlmaWVyKSB7XG4gICAgICBjb25zdCBiYXNlQ2xhc3NOYW1lV2l0aG91dFBvc3RmaXggPSBiYXNlQ2xhc3NOYW1lLnN1YnN0cmluZygwLCBtYXliZVBvc3RmaXhNb2RpZmllclBvc2l0aW9uKTtcbiAgICAgIGNsYXNzR3JvdXBJZCA9IGdldENsYXNzR3JvdXBJZChiYXNlQ2xhc3NOYW1lV2l0aG91dFBvc3RmaXgpO1xuICAgICAgY29uc3QgY2xhc3NHcm91cElkV2l0aFBvc3RmaXggPSBjbGFzc0dyb3VwSWQgJiYgcG9zdGZpeExvb2t1cENsYXNzR3JvdXBJZHNbY2xhc3NHcm91cElkXSA/IGdldENsYXNzR3JvdXBJZChiYXNlQ2xhc3NOYW1lKSA6IHVuZGVmaW5lZDtcbiAgICAgIGlmIChjbGFzc0dyb3VwSWRXaXRoUG9zdGZpeCAmJiBjbGFzc0dyb3VwSWRXaXRoUG9zdGZpeCAhPT0gY2xhc3NHcm91cElkKSB7XG4gICAgICAgIGNsYXNzR3JvdXBJZCA9IGNsYXNzR3JvdXBJZFdpdGhQb3N0Zml4O1xuICAgICAgICBoYXNQb3N0Zml4TW9kaWZpZXIgPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgY2xhc3NHcm91cElkID0gZ2V0Q2xhc3NHcm91cElkKGJhc2VDbGFzc05hbWUpO1xuICAgIH1cbiAgICBpZiAoIWNsYXNzR3JvdXBJZCkge1xuICAgICAgaWYgKCFoYXNQb3N0Zml4TW9kaWZpZXIpIHtcbiAgICAgICAgLy8gTm90IGEgVGFpbHdpbmQgY2xhc3NcbiAgICAgICAgcmVzdWx0ID0gb3JpZ2luYWxDbGFzc05hbWUgKyAocmVzdWx0Lmxlbmd0aCA+IDAgPyAnICcgKyByZXN1bHQgOiByZXN1bHQpO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGNsYXNzR3JvdXBJZCA9IGdldENsYXNzR3JvdXBJZChiYXNlQ2xhc3NOYW1lKTtcbiAgICAgIGlmICghY2xhc3NHcm91cElkKSB7XG4gICAgICAgIC8vIE5vdCBhIFRhaWx3aW5kIGNsYXNzXG4gICAgICAgIHJlc3VsdCA9IG9yaWdpbmFsQ2xhc3NOYW1lICsgKHJlc3VsdC5sZW5ndGggPiAwID8gJyAnICsgcmVzdWx0IDogcmVzdWx0KTtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBoYXNQb3N0Zml4TW9kaWZpZXIgPSBmYWxzZTtcbiAgICB9XG4gICAgLy8gRmFzdCBwYXRoOiBza2lwIHNvcnRpbmcgZm9yIGVtcHR5IG9yIHNpbmdsZSBtb2RpZmllclxuICAgIGNvbnN0IHZhcmlhbnRNb2RpZmllciA9IG1vZGlmaWVycy5sZW5ndGggPT09IDAgPyAnJyA6IG1vZGlmaWVycy5sZW5ndGggPT09IDEgPyBtb2RpZmllcnNbMF0gOiBzb3J0TW9kaWZpZXJzKG1vZGlmaWVycykuam9pbignOicpO1xuICAgIGNvbnN0IG1vZGlmaWVySWQgPSBoYXNJbXBvcnRhbnRNb2RpZmllciA/IHZhcmlhbnRNb2RpZmllciArIElNUE9SVEFOVF9NT0RJRklFUiA6IHZhcmlhbnRNb2RpZmllcjtcbiAgICBjb25zdCBjbGFzc0lkID0gbW9kaWZpZXJJZCArIGNsYXNzR3JvdXBJZDtcbiAgICBpZiAoY2xhc3NHcm91cHNJbkNvbmZsaWN0LmluZGV4T2YoY2xhc3NJZCkgPiAtMSkge1xuICAgICAgLy8gVGFpbHdpbmQgY2xhc3Mgb21pdHRlZCBkdWUgdG8gY29uZmxpY3RcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjbGFzc0dyb3Vwc0luQ29uZmxpY3QucHVzaChjbGFzc0lkKTtcbiAgICBjb25zdCBjb25mbGljdEdyb3VwcyA9IGdldENvbmZsaWN0aW5nQ2xhc3NHcm91cElkcyhjbGFzc0dyb3VwSWQsIGhhc1Bvc3RmaXhNb2RpZmllcik7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb25mbGljdEdyb3Vwcy5sZW5ndGg7ICsraSkge1xuICAgICAgY29uc3QgZ3JvdXAgPSBjb25mbGljdEdyb3Vwc1tpXTtcbiAgICAgIGNsYXNzR3JvdXBzSW5Db25mbGljdC5wdXNoKG1vZGlmaWVySWQgKyBncm91cCk7XG4gICAgfVxuICAgIC8vIFRhaWx3aW5kIGNsYXNzIG5vdCBpbiBjb25mbGljdFxuICAgIHJlc3VsdCA9IG9yaWdpbmFsQ2xhc3NOYW1lICsgKHJlc3VsdC5sZW5ndGggPiAwID8gJyAnICsgcmVzdWx0IDogcmVzdWx0KTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufTtcblxuLyoqXG4gKiBUaGUgY29kZSBpbiB0aGlzIGZpbGUgaXMgY29waWVkIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL2x1a2VlZC9jbHN4IGFuZCBtb2RpZmllZCB0byBzdWl0IHRoZSBuZWVkcyBvZiB0YWlsd2luZC1tZXJnZSBiZXR0ZXIuXG4gKlxuICogU3BlY2lmaWNhbGx5OlxuICogLSBSdW50aW1lIGNvZGUgZnJvbSBodHRwczovL2dpdGh1Yi5jb20vbHVrZWVkL2Nsc3gvYmxvYi92MS4yLjEvc3JjL2luZGV4LmpzXG4gKiAtIFR5cGVTY3JpcHQgdHlwZXMgZnJvbSBodHRwczovL2dpdGh1Yi5jb20vbHVrZWVkL2Nsc3gvYmxvYi92MS4yLjEvY2xzeC5kLnRzXG4gKlxuICogT3JpZ2luYWwgY29kZSBoYXMgTUlUIGxpY2Vuc2U6IENvcHlyaWdodCAoYykgTHVrZSBFZHdhcmRzIDxsdWtlLmVkd2FyZHMwNUBnbWFpbC5jb20+IChsdWtlZWQuY29tKVxuICovXG5jb25zdCB0d0pvaW4gPSAoLi4uY2xhc3NMaXN0cykgPT4ge1xuICBsZXQgaW5kZXggPSAwO1xuICBsZXQgYXJndW1lbnQ7XG4gIGxldCByZXNvbHZlZFZhbHVlO1xuICBsZXQgc3RyaW5nID0gJyc7XG4gIHdoaWxlIChpbmRleCA8IGNsYXNzTGlzdHMubGVuZ3RoKSB7XG4gICAgaWYgKGFyZ3VtZW50ID0gY2xhc3NMaXN0c1tpbmRleCsrXSkge1xuICAgICAgaWYgKHJlc29sdmVkVmFsdWUgPSB0b1ZhbHVlKGFyZ3VtZW50KSkge1xuICAgICAgICBzdHJpbmcgJiYgKHN0cmluZyArPSAnICcpO1xuICAgICAgICBzdHJpbmcgKz0gcmVzb2x2ZWRWYWx1ZTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIHN0cmluZztcbn07XG5jb25zdCB0b1ZhbHVlID0gbWl4ID0+IHtcbiAgLy8gRmFzdCBwYXRoIGZvciBzdHJpbmdzXG4gIGlmICh0eXBlb2YgbWl4ID09PSAnc3RyaW5nJykge1xuICAgIHJldHVybiBtaXg7XG4gIH1cbiAgbGV0IHJlc29sdmVkVmFsdWU7XG4gIGxldCBzdHJpbmcgPSAnJztcbiAgZm9yIChsZXQgayA9IDA7IGsgPCBtaXgubGVuZ3RoOyBrKyspIHtcbiAgICBpZiAobWl4W2tdKSB7XG4gICAgICBpZiAocmVzb2x2ZWRWYWx1ZSA9IHRvVmFsdWUobWl4W2tdKSkge1xuICAgICAgICBzdHJpbmcgJiYgKHN0cmluZyArPSAnICcpO1xuICAgICAgICBzdHJpbmcgKz0gcmVzb2x2ZWRWYWx1ZTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIHN0cmluZztcbn07XG5jb25zdCBjcmVhdGVUYWlsd2luZE1lcmdlID0gKGNyZWF0ZUNvbmZpZ0ZpcnN0LCAuLi5jcmVhdGVDb25maWdSZXN0KSA9PiB7XG4gIGxldCBjb25maWdVdGlscztcbiAgbGV0IGNhY2hlR2V0O1xuICBsZXQgY2FjaGVTZXQ7XG4gIGxldCBmdW5jdGlvblRvQ2FsbDtcbiAgY29uc3QgaW5pdFRhaWx3aW5kTWVyZ2UgPSBjbGFzc0xpc3QgPT4ge1xuICAgIGNvbnN0IGNvbmZpZyA9IGNyZWF0ZUNvbmZpZ1Jlc3QucmVkdWNlKChwcmV2aW91c0NvbmZpZywgY3JlYXRlQ29uZmlnQ3VycmVudCkgPT4gY3JlYXRlQ29uZmlnQ3VycmVudChwcmV2aW91c0NvbmZpZyksIGNyZWF0ZUNvbmZpZ0ZpcnN0KCkpO1xuICAgIGNvbmZpZ1V0aWxzID0gY3JlYXRlQ29uZmlnVXRpbHMoY29uZmlnKTtcbiAgICBjYWNoZUdldCA9IGNvbmZpZ1V0aWxzLmNhY2hlLmdldDtcbiAgICBjYWNoZVNldCA9IGNvbmZpZ1V0aWxzLmNhY2hlLnNldDtcbiAgICBmdW5jdGlvblRvQ2FsbCA9IHRhaWx3aW5kTWVyZ2U7XG4gICAgcmV0dXJuIHRhaWx3aW5kTWVyZ2UoY2xhc3NMaXN0KTtcbiAgfTtcbiAgY29uc3QgdGFpbHdpbmRNZXJnZSA9IGNsYXNzTGlzdCA9PiB7XG4gICAgY29uc3QgY2FjaGVkUmVzdWx0ID0gY2FjaGVHZXQoY2xhc3NMaXN0KTtcbiAgICBpZiAoY2FjaGVkUmVzdWx0KSB7XG4gICAgICByZXR1cm4gY2FjaGVkUmVzdWx0O1xuICAgIH1cbiAgICBjb25zdCByZXN1bHQgPSBtZXJnZUNsYXNzTGlzdChjbGFzc0xpc3QsIGNvbmZpZ1V0aWxzKTtcbiAgICBjYWNoZVNldChjbGFzc0xpc3QsIHJlc3VsdCk7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfTtcbiAgZnVuY3Rpb25Ub0NhbGwgPSBpbml0VGFpbHdpbmRNZXJnZTtcbiAgcmV0dXJuICguLi5hcmdzKSA9PiBmdW5jdGlvblRvQ2FsbCh0d0pvaW4oLi4uYXJncykpO1xufTtcbmNvbnN0IGZhbGxiYWNrVGhlbWVBcnIgPSBbXTtcbmNvbnN0IGZyb21UaGVtZSA9IGtleSA9PiB7XG4gIGNvbnN0IHRoZW1lR2V0dGVyID0gdGhlbWUgPT4gdGhlbWVba2V5XSB8fCBmYWxsYmFja1RoZW1lQXJyO1xuICB0aGVtZUdldHRlci5pc1RoZW1lR2V0dGVyID0gdHJ1ZTtcbiAgcmV0dXJuIHRoZW1lR2V0dGVyO1xufTtcbmNvbnN0IGFyYml0cmFyeVZhbHVlUmVnZXggPSAvXlxcWyg/OihcXHdbXFx3LV0qKTopPyguKylcXF0kL2k7XG5jb25zdCBhcmJpdHJhcnlWYXJpYWJsZVJlZ2V4ID0gL15cXCgoPzooXFx3W1xcdy1dKik6KT8oLispXFwpJC9pO1xuY29uc3QgZnJhY3Rpb25SZWdleCA9IC9eXFxkKyg/OlxcLlxcZCspP1xcL1xcZCsoPzpcXC5cXGQrKT8kLztcbmNvbnN0IHRzaGlydFVuaXRSZWdleCA9IC9eKFxcZCsoXFwuXFxkKyk/KT8oeHN8c218bWR8bGd8eGwpJC87XG5jb25zdCBsZW5ndGhVbml0UmVnZXggPSAvXFxkKyglfHB4fHI/ZW18W3NkbF0/dihbaHdpYl18bWlufG1heCl8cHR8cGN8aW58Y218bW18Y2FwfGNofGV4fHI/bGh8Y3Eod3xofGl8YnxtaW58bWF4KSl8XFxiKGNhbGN8bWlufG1heHxjbGFtcClcXCguK1xcKXxeMCQvO1xuY29uc3QgY29sb3JGdW5jdGlvblJlZ2V4ID0gL14ocmdiYT98aHNsYT98aHdifChvayk/KGxhYnxsY2gpfGNvbG9yLW1peClcXCguK1xcKSQvO1xuLy8gU2hhZG93IGFsd2F5cyBiZWdpbnMgd2l0aCB4IGFuZCB5IG9mZnNldCBzZXBhcmF0ZWQgYnkgdW5kZXJzY29yZSBvcHRpb25hbGx5IHByZXBlbmRlZCBieSBpbnNldFxuY29uc3Qgc2hhZG93UmVnZXggPSAvXihpbnNldF8pPy0/KChcXGQrKT9cXC4/KFxcZCspW2Etel0rfDApXy0/KChcXGQrKT9cXC4/KFxcZCspW2Etel0rfDApLztcbmNvbnN0IGltYWdlUmVnZXggPSAvXih1cmx8aW1hZ2V8aW1hZ2Utc2V0fGNyb3NzLWZhZGV8ZWxlbWVudHwocmVwZWF0aW5nLSk/KGxpbmVhcnxyYWRpYWx8Y29uaWMpLWdyYWRpZW50KVxcKC4rXFwpJC87XG5jb25zdCBpc0ZyYWN0aW9uID0gdmFsdWUgPT4gZnJhY3Rpb25SZWdleC50ZXN0KHZhbHVlKTtcbmNvbnN0IGlzTnVtYmVyID0gdmFsdWUgPT4gISF2YWx1ZSAmJiAhTnVtYmVyLmlzTmFOKE51bWJlcih2YWx1ZSkpO1xuY29uc3QgaXNJbnRlZ2VyID0gdmFsdWUgPT4gISF2YWx1ZSAmJiBOdW1iZXIuaXNJbnRlZ2VyKE51bWJlcih2YWx1ZSkpO1xuY29uc3QgaXNQZXJjZW50ID0gdmFsdWUgPT4gdmFsdWUuZW5kc1dpdGgoJyUnKSAmJiBpc051bWJlcih2YWx1ZS5zbGljZSgwLCAtMSkpO1xuY29uc3QgaXNUc2hpcnRTaXplID0gdmFsdWUgPT4gdHNoaXJ0VW5pdFJlZ2V4LnRlc3QodmFsdWUpO1xuY29uc3QgaXNBbnkgPSAoKSA9PiB0cnVlO1xuY29uc3QgaXNMZW5ndGhPbmx5ID0gdmFsdWUgPT5cbi8vIGBjb2xvckZ1bmN0aW9uUmVnZXhgIGNoZWNrIGlzIG5lY2Vzc2FyeSBiZWNhdXNlIGNvbG9yIGZ1bmN0aW9ucyBjYW4gaGF2ZSBwZXJjZW50YWdlcyBpbiB0aGVtIHdoaWNoIHdoaWNoIHdvdWxkIGJlIGluY29ycmVjdGx5IGNsYXNzaWZpZWQgYXMgbGVuZ3Rocy5cbi8vIEZvciBleGFtcGxlLCBgaHNsKDAgMCUgMCUpYCB3b3VsZCBiZSBjbGFzc2lmaWVkIGFzIGEgbGVuZ3RoIHdpdGhvdXQgdGhpcyBjaGVjay5cbi8vIEkgY291bGQgYWxzbyB1c2UgbG9va2JlaGluZCBhc3NlcnRpb24gaW4gYGxlbmd0aFVuaXRSZWdleGAgYnV0IHRoYXQgaXNuJ3Qgc3VwcG9ydGVkIHdpZGVseSBlbm91Z2guXG5sZW5ndGhVbml0UmVnZXgudGVzdCh2YWx1ZSkgJiYgIWNvbG9yRnVuY3Rpb25SZWdleC50ZXN0KHZhbHVlKTtcbmNvbnN0IGlzTmV2ZXIgPSAoKSA9PiBmYWxzZTtcbmNvbnN0IGlzU2hhZG93ID0gdmFsdWUgPT4gc2hhZG93UmVnZXgudGVzdCh2YWx1ZSk7XG5jb25zdCBpc0ltYWdlID0gdmFsdWUgPT4gaW1hZ2VSZWdleC50ZXN0KHZhbHVlKTtcbmNvbnN0IGlzQW55Tm9uQXJiaXRyYXJ5ID0gdmFsdWUgPT4gIWlzQXJiaXRyYXJ5VmFsdWUodmFsdWUpICYmICFpc0FyYml0cmFyeVZhcmlhYmxlKHZhbHVlKTtcbmNvbnN0IGlzTmFtZWRDb250YWluZXJRdWVyeSA9IHZhbHVlID0+IHZhbHVlLnN0YXJ0c1dpdGgoJ0Bjb250YWluZXInKSAmJiAodmFsdWVbMTBdID09PSAnLycgJiYgdmFsdWVbMTFdICE9PSB1bmRlZmluZWQgfHwgdmFsdWVbMTFdID09PSAncycgJiYgdmFsdWVbMTZdICE9PSB1bmRlZmluZWQgJiYgdmFsdWUuc3RhcnRzV2l0aCgnLXNpemUvJywgMTApIHx8IHZhbHVlWzExXSA9PT0gJ24nICYmIHZhbHVlWzE4XSAhPT0gdW5kZWZpbmVkICYmIHZhbHVlLnN0YXJ0c1dpdGgoJy1ub3JtYWwvJywgMTApKTtcbmNvbnN0IGlzQXJiaXRyYXJ5U2l6ZSA9IHZhbHVlID0+IGdldElzQXJiaXRyYXJ5VmFsdWUodmFsdWUsIGlzTGFiZWxTaXplLCBpc05ldmVyKTtcbmNvbnN0IGlzQXJiaXRyYXJ5VmFsdWUgPSB2YWx1ZSA9PiBhcmJpdHJhcnlWYWx1ZVJlZ2V4LnRlc3QodmFsdWUpO1xuY29uc3QgaXNBcmJpdHJhcnlMZW5ndGggPSB2YWx1ZSA9PiBnZXRJc0FyYml0cmFyeVZhbHVlKHZhbHVlLCBpc0xhYmVsTGVuZ3RoLCBpc0xlbmd0aE9ubHkpO1xuY29uc3QgaXNBcmJpdHJhcnlOdW1iZXIgPSB2YWx1ZSA9PiBnZXRJc0FyYml0cmFyeVZhbHVlKHZhbHVlLCBpc0xhYmVsTnVtYmVyLCBpc051bWJlcik7XG5jb25zdCBpc0FyYml0cmFyeVdlaWdodCA9IHZhbHVlID0+IGdldElzQXJiaXRyYXJ5VmFsdWUodmFsdWUsIGlzTGFiZWxXZWlnaHQsIGlzQW55KTtcbmNvbnN0IGlzQXJiaXRyYXJ5RmFtaWx5TmFtZSA9IHZhbHVlID0+IGdldElzQXJiaXRyYXJ5VmFsdWUodmFsdWUsIGlzTGFiZWxGYW1pbHlOYW1lLCBpc05ldmVyKTtcbmNvbnN0IGlzQXJiaXRyYXJ5UG9zaXRpb24gPSB2YWx1ZSA9PiBnZXRJc0FyYml0cmFyeVZhbHVlKHZhbHVlLCBpc0xhYmVsUG9zaXRpb24sIGlzTmV2ZXIpO1xuY29uc3QgaXNBcmJpdHJhcnlJbWFnZSA9IHZhbHVlID0+IGdldElzQXJiaXRyYXJ5VmFsdWUodmFsdWUsIGlzTGFiZWxJbWFnZSwgaXNJbWFnZSk7XG5jb25zdCBpc0FyYml0cmFyeVNoYWRvdyA9IHZhbHVlID0+IGdldElzQXJiaXRyYXJ5VmFsdWUodmFsdWUsIGlzTGFiZWxTaGFkb3csIGlzU2hhZG93KTtcbmNvbnN0IGlzQXJiaXRyYXJ5VmFyaWFibGUgPSB2YWx1ZSA9PiBhcmJpdHJhcnlWYXJpYWJsZVJlZ2V4LnRlc3QodmFsdWUpO1xuY29uc3QgaXNBcmJpdHJhcnlWYXJpYWJsZUxlbmd0aCA9IHZhbHVlID0+IGdldElzQXJiaXRyYXJ5VmFyaWFibGUodmFsdWUsIGlzTGFiZWxMZW5ndGgpO1xuY29uc3QgaXNBcmJpdHJhcnlWYXJpYWJsZUZhbWlseU5hbWUgPSB2YWx1ZSA9PiBnZXRJc0FyYml0cmFyeVZhcmlhYmxlKHZhbHVlLCBpc0xhYmVsRmFtaWx5TmFtZSk7XG5jb25zdCBpc0FyYml0cmFyeVZhcmlhYmxlUG9zaXRpb24gPSB2YWx1ZSA9PiBnZXRJc0FyYml0cmFyeVZhcmlhYmxlKHZhbHVlLCBpc0xhYmVsUG9zaXRpb24pO1xuY29uc3QgaXNBcmJpdHJhcnlWYXJpYWJsZVNpemUgPSB2YWx1ZSA9PiBnZXRJc0FyYml0cmFyeVZhcmlhYmxlKHZhbHVlLCBpc0xhYmVsU2l6ZSk7XG5jb25zdCBpc0FyYml0cmFyeVZhcmlhYmxlSW1hZ2UgPSB2YWx1ZSA9PiBnZXRJc0FyYml0cmFyeVZhcmlhYmxlKHZhbHVlLCBpc0xhYmVsSW1hZ2UpO1xuY29uc3QgaXNBcmJpdHJhcnlWYXJpYWJsZVNoYWRvdyA9IHZhbHVlID0+IGdldElzQXJiaXRyYXJ5VmFyaWFibGUodmFsdWUsIGlzTGFiZWxTaGFkb3csIHRydWUpO1xuY29uc3QgaXNBcmJpdHJhcnlWYXJpYWJsZVdlaWdodCA9IHZhbHVlID0+IGdldElzQXJiaXRyYXJ5VmFyaWFibGUodmFsdWUsIGlzTGFiZWxXZWlnaHQsIHRydWUpO1xuLy8gSGVscGVyc1xuY29uc3QgZ2V0SXNBcmJpdHJhcnlWYWx1ZSA9ICh2YWx1ZSwgdGVzdExhYmVsLCB0ZXN0VmFsdWUpID0+IHtcbiAgY29uc3QgcmVzdWx0ID0gYXJiaXRyYXJ5VmFsdWVSZWdleC5leGVjKHZhbHVlKTtcbiAgaWYgKHJlc3VsdCkge1xuICAgIGlmIChyZXN1bHRbMV0pIHtcbiAgICAgIHJldHVybiB0ZXN0TGFiZWwocmVzdWx0WzFdKTtcbiAgICB9XG4gICAgcmV0dXJuIHRlc3RWYWx1ZShyZXN1bHRbMl0pO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn07XG5jb25zdCBnZXRJc0FyYml0cmFyeVZhcmlhYmxlID0gKHZhbHVlLCB0ZXN0TGFiZWwsIHNob3VsZE1hdGNoTm9MYWJlbCA9IGZhbHNlKSA9PiB7XG4gIGNvbnN0IHJlc3VsdCA9IGFyYml0cmFyeVZhcmlhYmxlUmVnZXguZXhlYyh2YWx1ZSk7XG4gIGlmIChyZXN1bHQpIHtcbiAgICBpZiAocmVzdWx0WzFdKSB7XG4gICAgICByZXR1cm4gdGVzdExhYmVsKHJlc3VsdFsxXSk7XG4gICAgfVxuICAgIHJldHVybiBzaG91bGRNYXRjaE5vTGFiZWw7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufTtcbi8vIExhYmVsc1xuY29uc3QgaXNMYWJlbFBvc2l0aW9uID0gbGFiZWwgPT4gbGFiZWwgPT09ICdwb3NpdGlvbicgfHwgbGFiZWwgPT09ICdwZXJjZW50YWdlJztcbmNvbnN0IGlzTGFiZWxJbWFnZSA9IGxhYmVsID0+IGxhYmVsID09PSAnaW1hZ2UnIHx8IGxhYmVsID09PSAndXJsJztcbmNvbnN0IGlzTGFiZWxTaXplID0gbGFiZWwgPT4gbGFiZWwgPT09ICdsZW5ndGgnIHx8IGxhYmVsID09PSAnc2l6ZScgfHwgbGFiZWwgPT09ICdiZy1zaXplJztcbmNvbnN0IGlzTGFiZWxMZW5ndGggPSBsYWJlbCA9PiBsYWJlbCA9PT0gJ2xlbmd0aCc7XG5jb25zdCBpc0xhYmVsTnVtYmVyID0gbGFiZWwgPT4gbGFiZWwgPT09ICdudW1iZXInO1xuY29uc3QgaXNMYWJlbEZhbWlseU5hbWUgPSBsYWJlbCA9PiBsYWJlbCA9PT0gJ2ZhbWlseS1uYW1lJztcbmNvbnN0IGlzTGFiZWxXZWlnaHQgPSBsYWJlbCA9PiBsYWJlbCA9PT0gJ251bWJlcicgfHwgbGFiZWwgPT09ICd3ZWlnaHQnO1xuY29uc3QgaXNMYWJlbFNoYWRvdyA9IGxhYmVsID0+IGxhYmVsID09PSAnc2hhZG93JztcbmNvbnN0IHZhbGlkYXRvcnMgPSAvKiNfX1BVUkVfXyovT2JqZWN0LmRlZmluZVByb3BlcnR5KHtcbiAgX19wcm90b19fOiBudWxsLFxuICBpc0FueSxcbiAgaXNBbnlOb25BcmJpdHJhcnksXG4gIGlzQXJiaXRyYXJ5RmFtaWx5TmFtZSxcbiAgaXNBcmJpdHJhcnlJbWFnZSxcbiAgaXNBcmJpdHJhcnlMZW5ndGgsXG4gIGlzQXJiaXRyYXJ5TnVtYmVyLFxuICBpc0FyYml0cmFyeVBvc2l0aW9uLFxuICBpc0FyYml0cmFyeVNoYWRvdyxcbiAgaXNBcmJpdHJhcnlTaXplLFxuICBpc0FyYml0cmFyeVZhbHVlLFxuICBpc0FyYml0cmFyeVZhcmlhYmxlLFxuICBpc0FyYml0cmFyeVZhcmlhYmxlRmFtaWx5TmFtZSxcbiAgaXNBcmJpdHJhcnlWYXJpYWJsZUltYWdlLFxuICBpc0FyYml0cmFyeVZhcmlhYmxlTGVuZ3RoLFxuICBpc0FyYml0cmFyeVZhcmlhYmxlUG9zaXRpb24sXG4gIGlzQXJiaXRyYXJ5VmFyaWFibGVTaGFkb3csXG4gIGlzQXJiaXRyYXJ5VmFyaWFibGVTaXplLFxuICBpc0FyYml0cmFyeVZhcmlhYmxlV2VpZ2h0LFxuICBpc0FyYml0cmFyeVdlaWdodCxcbiAgaXNGcmFjdGlvbixcbiAgaXNJbnRlZ2VyLFxuICBpc05hbWVkQ29udGFpbmVyUXVlcnksXG4gIGlzTnVtYmVyLFxuICBpc1BlcmNlbnQsXG4gIGlzVHNoaXJ0U2l6ZVxufSwgU3ltYm9sLnRvU3RyaW5nVGFnLCB7XG4gIHZhbHVlOiAnTW9kdWxlJ1xufSk7XG5jb25zdCBnZXREZWZhdWx0Q29uZmlnID0gKCkgPT4ge1xuICAvKipcbiAgICogVGhlbWUgZ2V0dGVycyBmb3IgdGhlbWUgdmFyaWFibGUgbmFtZXNwYWNlc1xuICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvdGhlbWUjdGhlbWUtdmFyaWFibGUtbmFtZXNwYWNlc1xuICAgKi9cbiAgLyoqKi9cbiAgY29uc3QgdGhlbWVDb2xvciA9IGZyb21UaGVtZSgnY29sb3InKTtcbiAgY29uc3QgdGhlbWVGb250ID0gZnJvbVRoZW1lKCdmb250Jyk7XG4gIGNvbnN0IHRoZW1lVGV4dCA9IGZyb21UaGVtZSgndGV4dCcpO1xuICBjb25zdCB0aGVtZUZvbnRXZWlnaHQgPSBmcm9tVGhlbWUoJ2ZvbnQtd2VpZ2h0Jyk7XG4gIGNvbnN0IHRoZW1lVHJhY2tpbmcgPSBmcm9tVGhlbWUoJ3RyYWNraW5nJyk7XG4gIGNvbnN0IHRoZW1lTGVhZGluZyA9IGZyb21UaGVtZSgnbGVhZGluZycpO1xuICBjb25zdCB0aGVtZUJyZWFrcG9pbnQgPSBmcm9tVGhlbWUoJ2JyZWFrcG9pbnQnKTtcbiAgY29uc3QgdGhlbWVDb250YWluZXIgPSBmcm9tVGhlbWUoJ2NvbnRhaW5lcicpO1xuICBjb25zdCB0aGVtZVNwYWNpbmcgPSBmcm9tVGhlbWUoJ3NwYWNpbmcnKTtcbiAgY29uc3QgdGhlbWVSYWRpdXMgPSBmcm9tVGhlbWUoJ3JhZGl1cycpO1xuICBjb25zdCB0aGVtZVNoYWRvdyA9IGZyb21UaGVtZSgnc2hhZG93Jyk7XG4gIGNvbnN0IHRoZW1lSW5zZXRTaGFkb3cgPSBmcm9tVGhlbWUoJ2luc2V0LXNoYWRvdycpO1xuICBjb25zdCB0aGVtZVRleHRTaGFkb3cgPSBmcm9tVGhlbWUoJ3RleHQtc2hhZG93Jyk7XG4gIGNvbnN0IHRoZW1lRHJvcFNoYWRvdyA9IGZyb21UaGVtZSgnZHJvcC1zaGFkb3cnKTtcbiAgY29uc3QgdGhlbWVCbHVyID0gZnJvbVRoZW1lKCdibHVyJyk7XG4gIGNvbnN0IHRoZW1lUGVyc3BlY3RpdmUgPSBmcm9tVGhlbWUoJ3BlcnNwZWN0aXZlJyk7XG4gIGNvbnN0IHRoZW1lQXNwZWN0ID0gZnJvbVRoZW1lKCdhc3BlY3QnKTtcbiAgY29uc3QgdGhlbWVFYXNlID0gZnJvbVRoZW1lKCdlYXNlJyk7XG4gIGNvbnN0IHRoZW1lQW5pbWF0ZSA9IGZyb21UaGVtZSgnYW5pbWF0ZScpO1xuICAvKipcbiAgICogSGVscGVycyB0byBhdm9pZCByZXBlYXRpbmcgdGhlIHNhbWUgc2NhbGVzXG4gICAqXG4gICAqIFdlIHVzZSBmdW5jdGlvbnMgdGhhdCBjcmVhdGUgYSBuZXcgYXJyYXkgZXZlcnkgdGltZSB0aGV5J3JlIGNhbGxlZCBpbnN0ZWFkIG9mIHN0YXRpYyBhcnJheXMuXG4gICAqIFRoaXMgZW5zdXJlcyB0aGF0IHVzZXJzIHdobyBtb2RpZnkgYW55IHNjYWxlIGJ5IG11dGF0aW5nIHRoZSBhcnJheSAoZS5nLiB3aXRoIGBhcnJheS5wdXNoKGVsZW1lbnQpYCkgZG9uJ3QgYWNjaWRlbnRhbGx5IG11dGF0ZSBhcnJheXMgaW4gb3RoZXIgcGFydHMgb2YgdGhlIGNvbmZpZy5cbiAgICovXG4gIC8qKiovXG4gIGNvbnN0IHNjYWxlQnJlYWsgPSAoKSA9PiBbJ2F1dG8nLCAnYXZvaWQnLCAnYWxsJywgJ2F2b2lkLXBhZ2UnLCAncGFnZScsICdsZWZ0JywgJ3JpZ2h0JywgJ2NvbHVtbiddO1xuICBjb25zdCBzY2FsZVBvc2l0aW9uID0gKCkgPT4gWydjZW50ZXInLCAndG9wJywgJ2JvdHRvbScsICdsZWZ0JywgJ3JpZ2h0JywgJ3RvcC1sZWZ0JyxcbiAgLy8gRGVwcmVjYXRlZCBzaW5jZSBUYWlsd2luZCBDU1MgdjQuMS4wLCBzZWUgaHR0cHM6Ly9naXRodWIuY29tL3RhaWx3aW5kbGFicy90YWlsd2luZGNzcy9wdWxsLzE3Mzc4XG4gICdsZWZ0LXRvcCcsICd0b3AtcmlnaHQnLFxuICAvLyBEZXByZWNhdGVkIHNpbmNlIFRhaWx3aW5kIENTUyB2NC4xLjAsIHNlZSBodHRwczovL2dpdGh1Yi5jb20vdGFpbHdpbmRsYWJzL3RhaWx3aW5kY3NzL3B1bGwvMTczNzhcbiAgJ3JpZ2h0LXRvcCcsICdib3R0b20tcmlnaHQnLFxuICAvLyBEZXByZWNhdGVkIHNpbmNlIFRhaWx3aW5kIENTUyB2NC4xLjAsIHNlZSBodHRwczovL2dpdGh1Yi5jb20vdGFpbHdpbmRsYWJzL3RhaWx3aW5kY3NzL3B1bGwvMTczNzhcbiAgJ3JpZ2h0LWJvdHRvbScsICdib3R0b20tbGVmdCcsXG4gIC8vIERlcHJlY2F0ZWQgc2luY2UgVGFpbHdpbmQgQ1NTIHY0LjEuMCwgc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS90YWlsd2luZGxhYnMvdGFpbHdpbmRjc3MvcHVsbC8xNzM3OFxuICAnbGVmdC1ib3R0b20nXTtcbiAgY29uc3Qgc2NhbGVQb3NpdGlvbldpdGhBcmJpdHJhcnkgPSAoKSA9PiBbLi4uc2NhbGVQb3NpdGlvbigpLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXTtcbiAgY29uc3Qgc2NhbGVPdmVyZmxvdyA9ICgpID0+IFsnYXV0bycsICdoaWRkZW4nLCAnY2xpcCcsICd2aXNpYmxlJywgJ3Njcm9sbCddO1xuICBjb25zdCBzY2FsZU92ZXJzY3JvbGwgPSAoKSA9PiBbJ2F1dG8nLCAnY29udGFpbicsICdub25lJ107XG4gIGNvbnN0IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nID0gKCkgPT4gW2lzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWUsIHRoZW1lU3BhY2luZ107XG4gIGNvbnN0IHNjYWxlSW5zZXQgPSAoKSA9PiBbaXNGcmFjdGlvbiwgJ2Z1bGwnLCAnYXV0bycsIC4uLnNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKCldO1xuICBjb25zdCBzY2FsZUdyaWRUZW1wbGF0ZUNvbHNSb3dzID0gKCkgPT4gW2lzSW50ZWdlciwgJ25vbmUnLCAnc3ViZ3JpZCcsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdO1xuICBjb25zdCBzY2FsZUdyaWRDb2xSb3dTdGFydEFuZEVuZCA9ICgpID0+IFsnYXV0bycsIHtcbiAgICBzcGFuOiBbJ2Z1bGwnLCBpc0ludGVnZXIsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gIH0sIGlzSW50ZWdlciwgaXNBcmJpdHJhcnlWYXJpYWJsZSwgaXNBcmJpdHJhcnlWYWx1ZV07XG4gIGNvbnN0IHNjYWxlR3JpZENvbFJvd1N0YXJ0T3JFbmQgPSAoKSA9PiBbaXNJbnRlZ2VyLCAnYXV0bycsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdO1xuICBjb25zdCBzY2FsZUdyaWRBdXRvQ29sc1Jvd3MgPSAoKSA9PiBbJ2F1dG8nLCAnbWluJywgJ21heCcsICdmcicsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdO1xuICBjb25zdCBzY2FsZUFsaWduUHJpbWFyeUF4aXMgPSAoKSA9PiBbJ3N0YXJ0JywgJ2VuZCcsICdjZW50ZXInLCAnYmV0d2VlbicsICdhcm91bmQnLCAnZXZlbmx5JywgJ3N0cmV0Y2gnLCAnYmFzZWxpbmUnLCAnY2VudGVyLXNhZmUnLCAnZW5kLXNhZmUnXTtcbiAgY29uc3Qgc2NhbGVBbGlnblNlY29uZGFyeUF4aXMgPSAoKSA9PiBbJ3N0YXJ0JywgJ2VuZCcsICdjZW50ZXInLCAnc3RyZXRjaCcsICdjZW50ZXItc2FmZScsICdlbmQtc2FmZSddO1xuICBjb25zdCBzY2FsZU1hcmdpbiA9ICgpID0+IFsnYXV0bycsIC4uLnNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKCldO1xuICBjb25zdCBzY2FsZVNpemluZyA9ICgpID0+IFtpc0ZyYWN0aW9uLCAnYXV0bycsICdmdWxsJywgJ2R2dycsICdkdmgnLCAnbHZ3JywgJ2x2aCcsICdzdncnLCAnc3ZoJywgJ21pbicsICdtYXgnLCAnZml0JywgLi4uc2NhbGVVbmFtYmlndW91c1NwYWNpbmcoKV07XG4gIGNvbnN0IHNjYWxlU2l6aW5nSW5saW5lID0gKCkgPT4gW2lzRnJhY3Rpb24sICdzY3JlZW4nLCAnZnVsbCcsICdkdncnLCAnbHZ3JywgJ3N2dycsICdtaW4nLCAnbWF4JywgJ2ZpdCcsIC4uLnNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKCldO1xuICBjb25zdCBzY2FsZVNpemluZ0Jsb2NrID0gKCkgPT4gW2lzRnJhY3Rpb24sICdzY3JlZW4nLCAnZnVsbCcsICdsaCcsICdkdmgnLCAnbHZoJywgJ3N2aCcsICdtaW4nLCAnbWF4JywgJ2ZpdCcsIC4uLnNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKCldO1xuICBjb25zdCBzY2FsZUNvbG9yID0gKCkgPT4gW3RoZW1lQ29sb3IsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdO1xuICBjb25zdCBzY2FsZUJnUG9zaXRpb24gPSAoKSA9PiBbLi4uc2NhbGVQb3NpdGlvbigpLCBpc0FyYml0cmFyeVZhcmlhYmxlUG9zaXRpb24sIGlzQXJiaXRyYXJ5UG9zaXRpb24sIHtcbiAgICBwb3NpdGlvbjogW2lzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gIH1dO1xuICBjb25zdCBzY2FsZUJnUmVwZWF0ID0gKCkgPT4gWyduby1yZXBlYXQnLCB7XG4gICAgcmVwZWF0OiBbJycsICd4JywgJ3knLCAnc3BhY2UnLCAncm91bmQnXVxuICB9XTtcbiAgY29uc3Qgc2NhbGVCZ1NpemUgPSAoKSA9PiBbJ2F1dG8nLCAnY292ZXInLCAnY29udGFpbicsIGlzQXJiaXRyYXJ5VmFyaWFibGVTaXplLCBpc0FyYml0cmFyeVNpemUsIHtcbiAgICBzaXplOiBbaXNBcmJpdHJhcnlWYXJpYWJsZSwgaXNBcmJpdHJhcnlWYWx1ZV1cbiAgfV07XG4gIGNvbnN0IHNjYWxlR3JhZGllbnRTdG9wUG9zaXRpb24gPSAoKSA9PiBbaXNQZXJjZW50LCBpc0FyYml0cmFyeVZhcmlhYmxlTGVuZ3RoLCBpc0FyYml0cmFyeUxlbmd0aF07XG4gIGNvbnN0IHNjYWxlUmFkaXVzID0gKCkgPT4gW1xuICAvLyBEZXByZWNhdGVkIHNpbmNlIFRhaWx3aW5kIENTUyB2NC4wLjBcbiAgJycsICdub25lJywgJ2Z1bGwnLCB0aGVtZVJhZGl1cywgaXNBcmJpdHJhcnlWYXJpYWJsZSwgaXNBcmJpdHJhcnlWYWx1ZV07XG4gIGNvbnN0IHNjYWxlQm9yZGVyV2lkdGggPSAoKSA9PiBbJycsIGlzTnVtYmVyLCBpc0FyYml0cmFyeVZhcmlhYmxlTGVuZ3RoLCBpc0FyYml0cmFyeUxlbmd0aF07XG4gIGNvbnN0IHNjYWxlTGluZVN0eWxlID0gKCkgPT4gWydzb2xpZCcsICdkYXNoZWQnLCAnZG90dGVkJywgJ2RvdWJsZSddO1xuICBjb25zdCBzY2FsZUJsZW5kTW9kZSA9ICgpID0+IFsnbm9ybWFsJywgJ211bHRpcGx5JywgJ3NjcmVlbicsICdvdmVybGF5JywgJ2RhcmtlbicsICdsaWdodGVuJywgJ2NvbG9yLWRvZGdlJywgJ2NvbG9yLWJ1cm4nLCAnaGFyZC1saWdodCcsICdzb2Z0LWxpZ2h0JywgJ2RpZmZlcmVuY2UnLCAnZXhjbHVzaW9uJywgJ2h1ZScsICdzYXR1cmF0aW9uJywgJ2NvbG9yJywgJ2x1bWlub3NpdHknXTtcbiAgY29uc3Qgc2NhbGVNYXNrSW1hZ2VQb3NpdGlvbiA9ICgpID0+IFtpc051bWJlciwgaXNQZXJjZW50LCBpc0FyYml0cmFyeVZhcmlhYmxlUG9zaXRpb24sIGlzQXJiaXRyYXJ5UG9zaXRpb25dO1xuICBjb25zdCBzY2FsZUJsdXIgPSAoKSA9PiBbXG4gIC8vIERlcHJlY2F0ZWQgc2luY2UgVGFpbHdpbmQgQ1NTIHY0LjAuMFxuICAnJywgJ25vbmUnLCB0aGVtZUJsdXIsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdO1xuICBjb25zdCBzY2FsZVJvdGF0ZSA9ICgpID0+IFsnbm9uZScsIGlzTnVtYmVyLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXTtcbiAgY29uc3Qgc2NhbGVTY2FsZSA9ICgpID0+IFsnbm9uZScsIGlzTnVtYmVyLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXTtcbiAgY29uc3Qgc2NhbGVTa2V3ID0gKCkgPT4gW2lzTnVtYmVyLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXTtcbiAgY29uc3Qgc2NhbGVUcmFuc2xhdGUgPSAoKSA9PiBbaXNGcmFjdGlvbiwgJ2Z1bGwnLCAuLi5zY2FsZVVuYW1iaWd1b3VzU3BhY2luZygpXTtcbiAgcmV0dXJuIHtcbiAgICBjYWNoZVNpemU6IDUwMCxcbiAgICB0aGVtZToge1xuICAgICAgYW5pbWF0ZTogWydzcGluJywgJ3BpbmcnLCAncHVsc2UnLCAnYm91bmNlJ10sXG4gICAgICBhc3BlY3Q6IFsndmlkZW8nXSxcbiAgICAgIGJsdXI6IFtpc1RzaGlydFNpemVdLFxuICAgICAgYnJlYWtwb2ludDogW2lzVHNoaXJ0U2l6ZV0sXG4gICAgICBjb2xvcjogW2lzQW55XSxcbiAgICAgIGNvbnRhaW5lcjogW2lzVHNoaXJ0U2l6ZV0sXG4gICAgICAnZHJvcC1zaGFkb3cnOiBbaXNUc2hpcnRTaXplXSxcbiAgICAgIGVhc2U6IFsnaW4nLCAnb3V0JywgJ2luLW91dCddLFxuICAgICAgZm9udDogW2lzQW55Tm9uQXJiaXRyYXJ5XSxcbiAgICAgICdmb250LXdlaWdodCc6IFsndGhpbicsICdleHRyYWxpZ2h0JywgJ2xpZ2h0JywgJ25vcm1hbCcsICdtZWRpdW0nLCAnc2VtaWJvbGQnLCAnYm9sZCcsICdleHRyYWJvbGQnLCAnYmxhY2snXSxcbiAgICAgICdpbnNldC1zaGFkb3cnOiBbaXNUc2hpcnRTaXplXSxcbiAgICAgIGxlYWRpbmc6IFsnbm9uZScsICd0aWdodCcsICdzbnVnJywgJ25vcm1hbCcsICdyZWxheGVkJywgJ2xvb3NlJ10sXG4gICAgICBwZXJzcGVjdGl2ZTogWydkcmFtYXRpYycsICduZWFyJywgJ25vcm1hbCcsICdtaWRyYW5nZScsICdkaXN0YW50JywgJ25vbmUnXSxcbiAgICAgIHJhZGl1czogW2lzVHNoaXJ0U2l6ZV0sXG4gICAgICBzaGFkb3c6IFtpc1RzaGlydFNpemVdLFxuICAgICAgc3BhY2luZzogWydweCcsIGlzTnVtYmVyXSxcbiAgICAgIHRleHQ6IFtpc1RzaGlydFNpemVdLFxuICAgICAgJ3RleHQtc2hhZG93JzogW2lzVHNoaXJ0U2l6ZV0sXG4gICAgICB0cmFja2luZzogWyd0aWdodGVyJywgJ3RpZ2h0JywgJ25vcm1hbCcsICd3aWRlJywgJ3dpZGVyJywgJ3dpZGVzdCddXG4gICAgfSxcbiAgICBjbGFzc0dyb3Vwczoge1xuICAgICAgLy8gLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIC0tLSBMYXlvdXQgLS0tXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLVxuICAgICAgLyoqXG4gICAgICAgKiBBc3BlY3QgUmF0aW9cbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9hc3BlY3QtcmF0aW9cbiAgICAgICAqL1xuICAgICAgYXNwZWN0OiBbe1xuICAgICAgICBhc3BlY3Q6IFsnYXV0bycsICdzcXVhcmUnLCBpc0ZyYWN0aW9uLCBpc0FyYml0cmFyeVZhbHVlLCBpc0FyYml0cmFyeVZhcmlhYmxlLCB0aGVtZUFzcGVjdF1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBDb250YWluZXJcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9jb250YWluZXJcbiAgICAgICAqIEBkZXByZWNhdGVkIHNpbmNlIFRhaWx3aW5kIENTUyB2NC4wLjBcbiAgICAgICAqL1xuICAgICAgY29udGFpbmVyOiBbJ2NvbnRhaW5lciddLFxuICAgICAgLyoqXG4gICAgICAgKiBDb250YWluZXIgVHlwZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3Jlc3BvbnNpdmUtZGVzaWduI2NvbnRhaW5lci1xdWVyaWVzXG4gICAgICAgKi9cbiAgICAgICdjb250YWluZXItdHlwZSc6IFt7XG4gICAgICAgICdAY29udGFpbmVyJzogWycnLCAnbm9ybWFsJywgJ3NpemUnLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIENvbnRhaW5lciBOYW1lXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvcmVzcG9uc2l2ZS1kZXNpZ24jbmFtZWQtY29udGFpbmVyc1xuICAgICAgICovXG4gICAgICAnY29udGFpbmVyLW5hbWVkJzogW2lzTmFtZWRDb250YWluZXJRdWVyeV0sXG4gICAgICAvKipcbiAgICAgICAqIENvbHVtbnNcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9jb2x1bW5zXG4gICAgICAgKi9cbiAgICAgIGNvbHVtbnM6IFt7XG4gICAgICAgIGNvbHVtbnM6IFtpc051bWJlciwgaXNBcmJpdHJhcnlWYWx1ZSwgaXNBcmJpdHJhcnlWYXJpYWJsZSwgdGhlbWVDb250YWluZXJdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQnJlYWsgQWZ0ZXJcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9icmVhay1hZnRlclxuICAgICAgICovXG4gICAgICAnYnJlYWstYWZ0ZXInOiBbe1xuICAgICAgICAnYnJlYWstYWZ0ZXInOiBzY2FsZUJyZWFrKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCcmVhayBCZWZvcmVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9icmVhay1iZWZvcmVcbiAgICAgICAqL1xuICAgICAgJ2JyZWFrLWJlZm9yZSc6IFt7XG4gICAgICAgICdicmVhay1iZWZvcmUnOiBzY2FsZUJyZWFrKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCcmVhayBJbnNpZGVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9icmVhay1pbnNpZGVcbiAgICAgICAqL1xuICAgICAgJ2JyZWFrLWluc2lkZSc6IFt7XG4gICAgICAgICdicmVhay1pbnNpZGUnOiBbJ2F1dG8nLCAnYXZvaWQnLCAnYXZvaWQtcGFnZScsICdhdm9pZC1jb2x1bW4nXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJveCBEZWNvcmF0aW9uIEJyZWFrXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYm94LWRlY29yYXRpb24tYnJlYWtcbiAgICAgICAqL1xuICAgICAgJ2JveC1kZWNvcmF0aW9uJzogW3tcbiAgICAgICAgJ2JveC1kZWNvcmF0aW9uJzogWydzbGljZScsICdjbG9uZSddXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQm94IFNpemluZ1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JveC1zaXppbmdcbiAgICAgICAqL1xuICAgICAgYm94OiBbe1xuICAgICAgICBib3g6IFsnYm9yZGVyJywgJ2NvbnRlbnQnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIERpc3BsYXlcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9kaXNwbGF5XG4gICAgICAgKi9cbiAgICAgIGRpc3BsYXk6IFsnYmxvY2snLCAnaW5saW5lLWJsb2NrJywgJ2lubGluZScsICdmbGV4JywgJ2lubGluZS1mbGV4JywgJ3RhYmxlJywgJ2lubGluZS10YWJsZScsICd0YWJsZS1jYXB0aW9uJywgJ3RhYmxlLWNlbGwnLCAndGFibGUtY29sdW1uJywgJ3RhYmxlLWNvbHVtbi1ncm91cCcsICd0YWJsZS1mb290ZXItZ3JvdXAnLCAndGFibGUtaGVhZGVyLWdyb3VwJywgJ3RhYmxlLXJvdy1ncm91cCcsICd0YWJsZS1yb3cnLCAnZmxvdy1yb290JywgJ2dyaWQnLCAnaW5saW5lLWdyaWQnLCAnY29udGVudHMnLCAnbGlzdC1pdGVtJywgJ2hpZGRlbiddLFxuICAgICAgLyoqXG4gICAgICAgKiBTY3JlZW4gUmVhZGVyIE9ubHlcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9kaXNwbGF5I3NjcmVlbi1yZWFkZXItb25seVxuICAgICAgICovXG4gICAgICBzcjogWydzci1vbmx5JywgJ25vdC1zci1vbmx5J10sXG4gICAgICAvKipcbiAgICAgICAqIEZsb2F0c1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2Zsb2F0XG4gICAgICAgKi9cbiAgICAgIGZsb2F0OiBbe1xuICAgICAgICBmbG9hdDogWydyaWdodCcsICdsZWZ0JywgJ25vbmUnLCAnc3RhcnQnLCAnZW5kJ11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBDbGVhclxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2NsZWFyXG4gICAgICAgKi9cbiAgICAgIGNsZWFyOiBbe1xuICAgICAgICBjbGVhcjogWydsZWZ0JywgJ3JpZ2h0JywgJ2JvdGgnLCAnbm9uZScsICdzdGFydCcsICdlbmQnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIElzb2xhdGlvblxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2lzb2xhdGlvblxuICAgICAgICovXG4gICAgICBpc29sYXRpb246IFsnaXNvbGF0ZScsICdpc29sYXRpb24tYXV0byddLFxuICAgICAgLyoqXG4gICAgICAgKiBPYmplY3QgRml0XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvb2JqZWN0LWZpdFxuICAgICAgICovXG4gICAgICAnb2JqZWN0LWZpdCc6IFt7XG4gICAgICAgIG9iamVjdDogWydjb250YWluJywgJ2NvdmVyJywgJ2ZpbGwnLCAnbm9uZScsICdzY2FsZS1kb3duJ11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBPYmplY3QgUG9zaXRpb25cbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9vYmplY3QtcG9zaXRpb25cbiAgICAgICAqL1xuICAgICAgJ29iamVjdC1wb3NpdGlvbic6IFt7XG4gICAgICAgIG9iamVjdDogc2NhbGVQb3NpdGlvbldpdGhBcmJpdHJhcnkoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIE92ZXJmbG93XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvb3ZlcmZsb3dcbiAgICAgICAqL1xuICAgICAgb3ZlcmZsb3c6IFt7XG4gICAgICAgIG92ZXJmbG93OiBzY2FsZU92ZXJmbG93KClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBPdmVyZmxvdyBYXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvb3ZlcmZsb3dcbiAgICAgICAqL1xuICAgICAgJ292ZXJmbG93LXgnOiBbe1xuICAgICAgICAnb3ZlcmZsb3cteCc6IHNjYWxlT3ZlcmZsb3coKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIE92ZXJmbG93IFlcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9vdmVyZmxvd1xuICAgICAgICovXG4gICAgICAnb3ZlcmZsb3cteSc6IFt7XG4gICAgICAgICdvdmVyZmxvdy15Jzogc2NhbGVPdmVyZmxvdygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogT3ZlcnNjcm9sbCBCZWhhdmlvclxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL292ZXJzY3JvbGwtYmVoYXZpb3JcbiAgICAgICAqL1xuICAgICAgb3ZlcnNjcm9sbDogW3tcbiAgICAgICAgb3ZlcnNjcm9sbDogc2NhbGVPdmVyc2Nyb2xsKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBPdmVyc2Nyb2xsIEJlaGF2aW9yIFhcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9vdmVyc2Nyb2xsLWJlaGF2aW9yXG4gICAgICAgKi9cbiAgICAgICdvdmVyc2Nyb2xsLXgnOiBbe1xuICAgICAgICAnb3ZlcnNjcm9sbC14Jzogc2NhbGVPdmVyc2Nyb2xsKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBPdmVyc2Nyb2xsIEJlaGF2aW9yIFlcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9vdmVyc2Nyb2xsLWJlaGF2aW9yXG4gICAgICAgKi9cbiAgICAgICdvdmVyc2Nyb2xsLXknOiBbe1xuICAgICAgICAnb3ZlcnNjcm9sbC15Jzogc2NhbGVPdmVyc2Nyb2xsKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBQb3NpdGlvblxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3Bvc2l0aW9uXG4gICAgICAgKi9cbiAgICAgIHBvc2l0aW9uOiBbJ3N0YXRpYycsICdmaXhlZCcsICdhYnNvbHV0ZScsICdyZWxhdGl2ZScsICdzdGlja3knXSxcbiAgICAgIC8qKlxuICAgICAgICogSW5zZXRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90b3AtcmlnaHQtYm90dG9tLWxlZnRcbiAgICAgICAqL1xuICAgICAgaW5zZXQ6IFt7XG4gICAgICAgIGluc2V0OiBzY2FsZUluc2V0KClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBJbnNldCBJbmxpbmVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90b3AtcmlnaHQtYm90dG9tLWxlZnRcbiAgICAgICAqL1xuICAgICAgJ2luc2V0LXgnOiBbe1xuICAgICAgICAnaW5zZXQteCc6IHNjYWxlSW5zZXQoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEluc2V0IEJsb2NrXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvdG9wLXJpZ2h0LWJvdHRvbS1sZWZ0XG4gICAgICAgKi9cbiAgICAgICdpbnNldC15JzogW3tcbiAgICAgICAgJ2luc2V0LXknOiBzY2FsZUluc2V0KClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBJbnNldCBJbmxpbmUgU3RhcnRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90b3AtcmlnaHQtYm90dG9tLWxlZnRcbiAgICAgICAqIEB0b2RvIGNsYXNzIGdyb3VwIHdpbGwgYmUgcmVuYW1lZCB0byBgaW5zZXQtc2AgaW4gbmV4dCBtYWpvciByZWxlYXNlXG4gICAgICAgKi9cbiAgICAgIHN0YXJ0OiBbe1xuICAgICAgICAnaW5zZXQtcyc6IHNjYWxlSW5zZXQoKSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIEBkZXByZWNhdGVkIHNpbmNlIFRhaWx3aW5kIENTUyB2NC4yLjAgaW4gZmF2b3Igb2YgYGluc2V0LXMtKmAgdXRpbGl0aWVzLlxuICAgICAgICAgKiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS90YWlsd2luZGxhYnMvdGFpbHdpbmRjc3MvcHVsbC8xOTYxM1xuICAgICAgICAgKi9cbiAgICAgICAgc3RhcnQ6IHNjYWxlSW5zZXQoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEluc2V0IElubGluZSBFbmRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90b3AtcmlnaHQtYm90dG9tLWxlZnRcbiAgICAgICAqIEB0b2RvIGNsYXNzIGdyb3VwIHdpbGwgYmUgcmVuYW1lZCB0byBgaW5zZXQtZWAgaW4gbmV4dCBtYWpvciByZWxlYXNlXG4gICAgICAgKi9cbiAgICAgIGVuZDogW3tcbiAgICAgICAgJ2luc2V0LWUnOiBzY2FsZUluc2V0KCksXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBAZGVwcmVjYXRlZCBzaW5jZSBUYWlsd2luZCBDU1MgdjQuMi4wIGluIGZhdm9yIG9mIGBpbnNldC1lLSpgIHV0aWxpdGllcy5cbiAgICAgICAgICogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vdGFpbHdpbmRsYWJzL3RhaWx3aW5kY3NzL3B1bGwvMTk2MTNcbiAgICAgICAgICovXG4gICAgICAgIGVuZDogc2NhbGVJbnNldCgpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogSW5zZXQgQmxvY2sgU3RhcnRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90b3AtcmlnaHQtYm90dG9tLWxlZnRcbiAgICAgICAqL1xuICAgICAgJ2luc2V0LWJzJzogW3tcbiAgICAgICAgJ2luc2V0LWJzJzogc2NhbGVJbnNldCgpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogSW5zZXQgQmxvY2sgRW5kXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvdG9wLXJpZ2h0LWJvdHRvbS1sZWZ0XG4gICAgICAgKi9cbiAgICAgICdpbnNldC1iZSc6IFt7XG4gICAgICAgICdpbnNldC1iZSc6IHNjYWxlSW5zZXQoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFRvcFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3RvcC1yaWdodC1ib3R0b20tbGVmdFxuICAgICAgICovXG4gICAgICB0b3A6IFt7XG4gICAgICAgIHRvcDogc2NhbGVJbnNldCgpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogUmlnaHRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90b3AtcmlnaHQtYm90dG9tLWxlZnRcbiAgICAgICAqL1xuICAgICAgcmlnaHQ6IFt7XG4gICAgICAgIHJpZ2h0OiBzY2FsZUluc2V0KClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3R0b21cbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90b3AtcmlnaHQtYm90dG9tLWxlZnRcbiAgICAgICAqL1xuICAgICAgYm90dG9tOiBbe1xuICAgICAgICBib3R0b206IHNjYWxlSW5zZXQoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIExlZnRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90b3AtcmlnaHQtYm90dG9tLWxlZnRcbiAgICAgICAqL1xuICAgICAgbGVmdDogW3tcbiAgICAgICAgbGVmdDogc2NhbGVJbnNldCgpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogVmlzaWJpbGl0eVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3Zpc2liaWxpdHlcbiAgICAgICAqL1xuICAgICAgdmlzaWJpbGl0eTogWyd2aXNpYmxlJywgJ2ludmlzaWJsZScsICdjb2xsYXBzZSddLFxuICAgICAgLyoqXG4gICAgICAgKiBaLUluZGV4XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvei1pbmRleFxuICAgICAgICovXG4gICAgICB6OiBbe1xuICAgICAgICB6OiBbaXNJbnRlZ2VyLCAnYXV0bycsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gLS0tIEZsZXhib3ggYW5kIEdyaWQgLS0tXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8qKlxuICAgICAgICogRmxleCBCYXNpc1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2ZsZXgtYmFzaXNcbiAgICAgICAqL1xuICAgICAgYmFzaXM6IFt7XG4gICAgICAgIGJhc2lzOiBbaXNGcmFjdGlvbiwgJ2Z1bGwnLCAnYXV0bycsIHRoZW1lQ29udGFpbmVyLCAuLi5zY2FsZVVuYW1iaWd1b3VzU3BhY2luZygpXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEZsZXggRGlyZWN0aW9uXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvZmxleC1kaXJlY3Rpb25cbiAgICAgICAqL1xuICAgICAgJ2ZsZXgtZGlyZWN0aW9uJzogW3tcbiAgICAgICAgZmxleDogWydyb3cnLCAncm93LXJldmVyc2UnLCAnY29sJywgJ2NvbC1yZXZlcnNlJ11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBGbGV4IFdyYXBcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9mbGV4LXdyYXBcbiAgICAgICAqL1xuICAgICAgJ2ZsZXgtd3JhcCc6IFt7XG4gICAgICAgIGZsZXg6IFsnbm93cmFwJywgJ3dyYXAnLCAnd3JhcC1yZXZlcnNlJ11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBGbGV4XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvZmxleFxuICAgICAgICovXG4gICAgICBmbGV4OiBbe1xuICAgICAgICBmbGV4OiBbaXNOdW1iZXIsIGlzRnJhY3Rpb24sICdhdXRvJywgJ2luaXRpYWwnLCAnbm9uZScsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogRmxleCBHcm93XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvZmxleC1ncm93XG4gICAgICAgKi9cbiAgICAgIGdyb3c6IFt7XG4gICAgICAgIGdyb3c6IFsnJywgaXNOdW1iZXIsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogRmxleCBTaHJpbmtcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9mbGV4LXNocmlua1xuICAgICAgICovXG4gICAgICBzaHJpbms6IFt7XG4gICAgICAgIHNocmluazogWycnLCBpc051bWJlciwgaXNBcmJpdHJhcnlWYXJpYWJsZSwgaXNBcmJpdHJhcnlWYWx1ZV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBPcmRlclxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL29yZGVyXG4gICAgICAgKi9cbiAgICAgIG9yZGVyOiBbe1xuICAgICAgICBvcmRlcjogW2lzSW50ZWdlciwgJ2ZpcnN0JywgJ2xhc3QnLCAnbm9uZScsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogR3JpZCBUZW1wbGF0ZSBDb2x1bW5zXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zXG4gICAgICAgKi9cbiAgICAgICdncmlkLWNvbHMnOiBbe1xuICAgICAgICAnZ3JpZC1jb2xzJzogc2NhbGVHcmlkVGVtcGxhdGVDb2xzUm93cygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogR3JpZCBDb2x1bW4gU3RhcnQgLyBFbmRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ncmlkLWNvbHVtblxuICAgICAgICovXG4gICAgICAnY29sLXN0YXJ0LWVuZCc6IFt7XG4gICAgICAgIGNvbDogc2NhbGVHcmlkQ29sUm93U3RhcnRBbmRFbmQoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEdyaWQgQ29sdW1uIFN0YXJ0XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvZ3JpZC1jb2x1bW5cbiAgICAgICAqL1xuICAgICAgJ2NvbC1zdGFydCc6IFt7XG4gICAgICAgICdjb2wtc3RhcnQnOiBzY2FsZUdyaWRDb2xSb3dTdGFydE9yRW5kKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBHcmlkIENvbHVtbiBFbmRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ncmlkLWNvbHVtblxuICAgICAgICovXG4gICAgICAnY29sLWVuZCc6IFt7XG4gICAgICAgICdjb2wtZW5kJzogc2NhbGVHcmlkQ29sUm93U3RhcnRPckVuZCgpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogR3JpZCBUZW1wbGF0ZSBSb3dzXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvZ3JpZC10ZW1wbGF0ZS1yb3dzXG4gICAgICAgKi9cbiAgICAgICdncmlkLXJvd3MnOiBbe1xuICAgICAgICAnZ3JpZC1yb3dzJzogc2NhbGVHcmlkVGVtcGxhdGVDb2xzUm93cygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogR3JpZCBSb3cgU3RhcnQgLyBFbmRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ncmlkLXJvd1xuICAgICAgICovXG4gICAgICAncm93LXN0YXJ0LWVuZCc6IFt7XG4gICAgICAgIHJvdzogc2NhbGVHcmlkQ29sUm93U3RhcnRBbmRFbmQoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEdyaWQgUm93IFN0YXJ0XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvZ3JpZC1yb3dcbiAgICAgICAqL1xuICAgICAgJ3Jvdy1zdGFydCc6IFt7XG4gICAgICAgICdyb3ctc3RhcnQnOiBzY2FsZUdyaWRDb2xSb3dTdGFydE9yRW5kKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBHcmlkIFJvdyBFbmRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ncmlkLXJvd1xuICAgICAgICovXG4gICAgICAncm93LWVuZCc6IFt7XG4gICAgICAgICdyb3ctZW5kJzogc2NhbGVHcmlkQ29sUm93U3RhcnRPckVuZCgpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogR3JpZCBBdXRvIEZsb3dcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ncmlkLWF1dG8tZmxvd1xuICAgICAgICovXG4gICAgICAnZ3JpZC1mbG93JzogW3tcbiAgICAgICAgJ2dyaWQtZmxvdyc6IFsncm93JywgJ2NvbCcsICdkZW5zZScsICdyb3ctZGVuc2UnLCAnY29sLWRlbnNlJ11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBHcmlkIEF1dG8gQ29sdW1uc1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2dyaWQtYXV0by1jb2x1bW5zXG4gICAgICAgKi9cbiAgICAgICdhdXRvLWNvbHMnOiBbe1xuICAgICAgICAnYXV0by1jb2xzJzogc2NhbGVHcmlkQXV0b0NvbHNSb3dzKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBHcmlkIEF1dG8gUm93c1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2dyaWQtYXV0by1yb3dzXG4gICAgICAgKi9cbiAgICAgICdhdXRvLXJvd3MnOiBbe1xuICAgICAgICAnYXV0by1yb3dzJzogc2NhbGVHcmlkQXV0b0NvbHNSb3dzKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBHYXBcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9nYXBcbiAgICAgICAqL1xuICAgICAgZ2FwOiBbe1xuICAgICAgICBnYXA6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBHYXAgWFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2dhcFxuICAgICAgICovXG4gICAgICAnZ2FwLXgnOiBbe1xuICAgICAgICAnZ2FwLXgnOiBzY2FsZVVuYW1iaWd1b3VzU3BhY2luZygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogR2FwIFlcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9nYXBcbiAgICAgICAqL1xuICAgICAgJ2dhcC15JzogW3tcbiAgICAgICAgJ2dhcC15Jzogc2NhbGVVbmFtYmlndW91c1NwYWNpbmcoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEp1c3RpZnkgQ29udGVudFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2p1c3RpZnktY29udGVudFxuICAgICAgICovXG4gICAgICAnanVzdGlmeS1jb250ZW50JzogW3tcbiAgICAgICAganVzdGlmeTogWy4uLnNjYWxlQWxpZ25QcmltYXJ5QXhpcygpLCAnbm9ybWFsJ11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBKdXN0aWZ5IEl0ZW1zXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvanVzdGlmeS1pdGVtc1xuICAgICAgICovXG4gICAgICAnanVzdGlmeS1pdGVtcyc6IFt7XG4gICAgICAgICdqdXN0aWZ5LWl0ZW1zJzogWy4uLnNjYWxlQWxpZ25TZWNvbmRhcnlBeGlzKCksICdub3JtYWwnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEp1c3RpZnkgU2VsZlxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2p1c3RpZnktc2VsZlxuICAgICAgICovXG4gICAgICAnanVzdGlmeS1zZWxmJzogW3tcbiAgICAgICAgJ2p1c3RpZnktc2VsZic6IFsnYXV0bycsIC4uLnNjYWxlQWxpZ25TZWNvbmRhcnlBeGlzKCldXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQWxpZ24gQ29udGVudFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2FsaWduLWNvbnRlbnRcbiAgICAgICAqL1xuICAgICAgJ2FsaWduLWNvbnRlbnQnOiBbe1xuICAgICAgICBjb250ZW50OiBbJ25vcm1hbCcsIC4uLnNjYWxlQWxpZ25QcmltYXJ5QXhpcygpXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEFsaWduIEl0ZW1zXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYWxpZ24taXRlbXNcbiAgICAgICAqL1xuICAgICAgJ2FsaWduLWl0ZW1zJzogW3tcbiAgICAgICAgaXRlbXM6IFsuLi5zY2FsZUFsaWduU2Vjb25kYXJ5QXhpcygpLCB7XG4gICAgICAgICAgYmFzZWxpbmU6IFsnJywgJ2xhc3QnXVxuICAgICAgICB9XVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEFsaWduIFNlbGZcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9hbGlnbi1zZWxmXG4gICAgICAgKi9cbiAgICAgICdhbGlnbi1zZWxmJzogW3tcbiAgICAgICAgc2VsZjogWydhdXRvJywgLi4uc2NhbGVBbGlnblNlY29uZGFyeUF4aXMoKSwge1xuICAgICAgICAgIGJhc2VsaW5lOiBbJycsICdsYXN0J11cbiAgICAgICAgfV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBQbGFjZSBDb250ZW50XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvcGxhY2UtY29udGVudFxuICAgICAgICovXG4gICAgICAncGxhY2UtY29udGVudCc6IFt7XG4gICAgICAgICdwbGFjZS1jb250ZW50Jzogc2NhbGVBbGlnblByaW1hcnlBeGlzKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBQbGFjZSBJdGVtc1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3BsYWNlLWl0ZW1zXG4gICAgICAgKi9cbiAgICAgICdwbGFjZS1pdGVtcyc6IFt7XG4gICAgICAgICdwbGFjZS1pdGVtcyc6IFsuLi5zY2FsZUFsaWduU2Vjb25kYXJ5QXhpcygpLCAnYmFzZWxpbmUnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFBsYWNlIFNlbGZcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9wbGFjZS1zZWxmXG4gICAgICAgKi9cbiAgICAgICdwbGFjZS1zZWxmJzogW3tcbiAgICAgICAgJ3BsYWNlLXNlbGYnOiBbJ2F1dG8nLCAuLi5zY2FsZUFsaWduU2Vjb25kYXJ5QXhpcygpXVxuICAgICAgfV0sXG4gICAgICAvLyBTcGFjaW5nXG4gICAgICAvKipcbiAgICAgICAqIFBhZGRpbmdcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9wYWRkaW5nXG4gICAgICAgKi9cbiAgICAgIHA6IFt7XG4gICAgICAgIHA6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBQYWRkaW5nIElubGluZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3BhZGRpbmdcbiAgICAgICAqL1xuICAgICAgcHg6IFt7XG4gICAgICAgIHB4OiBzY2FsZVVuYW1iaWd1b3VzU3BhY2luZygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogUGFkZGluZyBCbG9ja1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3BhZGRpbmdcbiAgICAgICAqL1xuICAgICAgcHk6IFt7XG4gICAgICAgIHB5OiBzY2FsZVVuYW1iaWd1b3VzU3BhY2luZygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogUGFkZGluZyBJbmxpbmUgU3RhcnRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9wYWRkaW5nXG4gICAgICAgKi9cbiAgICAgIHBzOiBbe1xuICAgICAgICBwczogc2NhbGVVbmFtYmlndW91c1NwYWNpbmcoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFBhZGRpbmcgSW5saW5lIEVuZFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3BhZGRpbmdcbiAgICAgICAqL1xuICAgICAgcGU6IFt7XG4gICAgICAgIHBlOiBzY2FsZVVuYW1iaWd1b3VzU3BhY2luZygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogUGFkZGluZyBCbG9jayBTdGFydFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3BhZGRpbmdcbiAgICAgICAqL1xuICAgICAgcGJzOiBbe1xuICAgICAgICBwYnM6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBQYWRkaW5nIEJsb2NrIEVuZFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3BhZGRpbmdcbiAgICAgICAqL1xuICAgICAgcGJlOiBbe1xuICAgICAgICBwYmU6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBQYWRkaW5nIFRvcFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3BhZGRpbmdcbiAgICAgICAqL1xuICAgICAgcHQ6IFt7XG4gICAgICAgIHB0OiBzY2FsZVVuYW1iaWd1b3VzU3BhY2luZygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogUGFkZGluZyBSaWdodFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3BhZGRpbmdcbiAgICAgICAqL1xuICAgICAgcHI6IFt7XG4gICAgICAgIHByOiBzY2FsZVVuYW1iaWd1b3VzU3BhY2luZygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogUGFkZGluZyBCb3R0b21cbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9wYWRkaW5nXG4gICAgICAgKi9cbiAgICAgIHBiOiBbe1xuICAgICAgICBwYjogc2NhbGVVbmFtYmlndW91c1NwYWNpbmcoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFBhZGRpbmcgTGVmdFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3BhZGRpbmdcbiAgICAgICAqL1xuICAgICAgcGw6IFt7XG4gICAgICAgIHBsOiBzY2FsZVVuYW1iaWd1b3VzU3BhY2luZygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogTWFyZ2luXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvbWFyZ2luXG4gICAgICAgKi9cbiAgICAgIG06IFt7XG4gICAgICAgIG06IHNjYWxlTWFyZ2luKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBNYXJnaW4gSW5saW5lXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvbWFyZ2luXG4gICAgICAgKi9cbiAgICAgIG14OiBbe1xuICAgICAgICBteDogc2NhbGVNYXJnaW4oKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIE1hcmdpbiBCbG9ja1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL21hcmdpblxuICAgICAgICovXG4gICAgICBteTogW3tcbiAgICAgICAgbXk6IHNjYWxlTWFyZ2luKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBNYXJnaW4gSW5saW5lIFN0YXJ0XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvbWFyZ2luXG4gICAgICAgKi9cbiAgICAgIG1zOiBbe1xuICAgICAgICBtczogc2NhbGVNYXJnaW4oKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIE1hcmdpbiBJbmxpbmUgRW5kXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvbWFyZ2luXG4gICAgICAgKi9cbiAgICAgIG1lOiBbe1xuICAgICAgICBtZTogc2NhbGVNYXJnaW4oKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIE1hcmdpbiBCbG9jayBTdGFydFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL21hcmdpblxuICAgICAgICovXG4gICAgICBtYnM6IFt7XG4gICAgICAgIG1iczogc2NhbGVNYXJnaW4oKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIE1hcmdpbiBCbG9jayBFbmRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9tYXJnaW5cbiAgICAgICAqL1xuICAgICAgbWJlOiBbe1xuICAgICAgICBtYmU6IHNjYWxlTWFyZ2luKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBNYXJnaW4gVG9wXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvbWFyZ2luXG4gICAgICAgKi9cbiAgICAgIG10OiBbe1xuICAgICAgICBtdDogc2NhbGVNYXJnaW4oKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIE1hcmdpbiBSaWdodFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL21hcmdpblxuICAgICAgICovXG4gICAgICBtcjogW3tcbiAgICAgICAgbXI6IHNjYWxlTWFyZ2luKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBNYXJnaW4gQm90dG9tXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvbWFyZ2luXG4gICAgICAgKi9cbiAgICAgIG1iOiBbe1xuICAgICAgICBtYjogc2NhbGVNYXJnaW4oKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIE1hcmdpbiBMZWZ0XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvbWFyZ2luXG4gICAgICAgKi9cbiAgICAgIG1sOiBbe1xuICAgICAgICBtbDogc2NhbGVNYXJnaW4oKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFNwYWNlIEJldHdlZW4gWFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL21hcmdpbiNhZGRpbmctc3BhY2UtYmV0d2Vlbi1jaGlsZHJlblxuICAgICAgICovXG4gICAgICAnc3BhY2UteCc6IFt7XG4gICAgICAgICdzcGFjZS14Jzogc2NhbGVVbmFtYmlndW91c1NwYWNpbmcoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFNwYWNlIEJldHdlZW4gWCBSZXZlcnNlXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvbWFyZ2luI2FkZGluZy1zcGFjZS1iZXR3ZWVuLWNoaWxkcmVuXG4gICAgICAgKi9cbiAgICAgICdzcGFjZS14LXJldmVyc2UnOiBbJ3NwYWNlLXgtcmV2ZXJzZSddLFxuICAgICAgLyoqXG4gICAgICAgKiBTcGFjZSBCZXR3ZWVuIFlcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9tYXJnaW4jYWRkaW5nLXNwYWNlLWJldHdlZW4tY2hpbGRyZW5cbiAgICAgICAqL1xuICAgICAgJ3NwYWNlLXknOiBbe1xuICAgICAgICAnc3BhY2UteSc6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTcGFjZSBCZXR3ZWVuIFkgUmV2ZXJzZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL21hcmdpbiNhZGRpbmctc3BhY2UtYmV0d2Vlbi1jaGlsZHJlblxuICAgICAgICovXG4gICAgICAnc3BhY2UteS1yZXZlcnNlJzogWydzcGFjZS15LXJldmVyc2UnXSxcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyAtLS0gU2l6aW5nIC0tLVxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8qKlxuICAgICAgICogU2l6ZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3dpZHRoI3NldHRpbmctYm90aC13aWR0aC1hbmQtaGVpZ2h0XG4gICAgICAgKi9cbiAgICAgIHNpemU6IFt7XG4gICAgICAgIHNpemU6IHNjYWxlU2l6aW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBJbmxpbmUgU2l6ZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3dpZHRoXG4gICAgICAgKi9cbiAgICAgICdpbmxpbmUtc2l6ZSc6IFt7XG4gICAgICAgIGlubGluZTogWydhdXRvJywgLi4uc2NhbGVTaXppbmdJbmxpbmUoKV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBNaW4tSW5saW5lIFNpemVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9taW4td2lkdGhcbiAgICAgICAqL1xuICAgICAgJ21pbi1pbmxpbmUtc2l6ZSc6IFt7XG4gICAgICAgICdtaW4taW5saW5lJzogWydhdXRvJywgLi4uc2NhbGVTaXppbmdJbmxpbmUoKV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBNYXgtSW5saW5lIFNpemVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9tYXgtd2lkdGhcbiAgICAgICAqL1xuICAgICAgJ21heC1pbmxpbmUtc2l6ZSc6IFt7XG4gICAgICAgICdtYXgtaW5saW5lJzogWydub25lJywgLi4uc2NhbGVTaXppbmdJbmxpbmUoKV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCbG9jayBTaXplXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvaGVpZ2h0XG4gICAgICAgKi9cbiAgICAgICdibG9jay1zaXplJzogW3tcbiAgICAgICAgYmxvY2s6IFsnYXV0bycsIC4uLnNjYWxlU2l6aW5nQmxvY2soKV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBNaW4tQmxvY2sgU2l6ZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL21pbi1oZWlnaHRcbiAgICAgICAqL1xuICAgICAgJ21pbi1ibG9jay1zaXplJzogW3tcbiAgICAgICAgJ21pbi1ibG9jayc6IFsnYXV0bycsIC4uLnNjYWxlU2l6aW5nQmxvY2soKV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBNYXgtQmxvY2sgU2l6ZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL21heC1oZWlnaHRcbiAgICAgICAqL1xuICAgICAgJ21heC1ibG9jay1zaXplJzogW3tcbiAgICAgICAgJ21heC1ibG9jayc6IFsnbm9uZScsIC4uLnNjYWxlU2l6aW5nQmxvY2soKV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBXaWR0aFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3dpZHRoXG4gICAgICAgKi9cbiAgICAgIHc6IFt7XG4gICAgICAgIHc6IFt0aGVtZUNvbnRhaW5lciwgJ3NjcmVlbicsIC4uLnNjYWxlU2l6aW5nKCldXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogTWluLVdpZHRoXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvbWluLXdpZHRoXG4gICAgICAgKi9cbiAgICAgICdtaW4tdyc6IFt7XG4gICAgICAgICdtaW4tdyc6IFt0aGVtZUNvbnRhaW5lciwgJ3NjcmVlbicsIC8qKiBEZXByZWNhdGVkLiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS90YWlsd2luZGxhYnMvdGFpbHdpbmRjc3MuY29tL2lzc3Vlcy8yMDI3I2lzc3VlY29tbWVudC0yNjIwMTUyNzU3ICovXG4gICAgICAgICdub25lJywgLi4uc2NhbGVTaXppbmcoKV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBNYXgtV2lkdGhcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9tYXgtd2lkdGhcbiAgICAgICAqL1xuICAgICAgJ21heC13JzogW3tcbiAgICAgICAgJ21heC13JzogW3RoZW1lQ29udGFpbmVyLCAnc2NyZWVuJywgJ25vbmUnLCAvKiogRGVwcmVjYXRlZCBzaW5jZSBUYWlsd2luZCBDU1MgdjQuMC4wLiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS90YWlsd2luZGxhYnMvdGFpbHdpbmRjc3MuY29tL2lzc3Vlcy8yMDI3I2lzc3VlY29tbWVudC0yNjIwMTUyNzU3ICovXG4gICAgICAgICdwcm9zZScsIC8qKiBEZXByZWNhdGVkIHNpbmNlIFRhaWx3aW5kIENTUyB2NC4wLjAuIEBzZWUgaHR0cHM6Ly9naXRodWIuY29tL3RhaWx3aW5kbGFicy90YWlsd2luZGNzcy5jb20vaXNzdWVzLzIwMjcjaXNzdWVjb21tZW50LTI2MjAxNTI3NTcgKi9cbiAgICAgICAge1xuICAgICAgICAgIHNjcmVlbjogW3RoZW1lQnJlYWtwb2ludF1cbiAgICAgICAgfSwgLi4uc2NhbGVTaXppbmcoKV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBIZWlnaHRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9oZWlnaHRcbiAgICAgICAqL1xuICAgICAgaDogW3tcbiAgICAgICAgaDogWydzY3JlZW4nLCAnbGgnLCAuLi5zY2FsZVNpemluZygpXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIE1pbi1IZWlnaHRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9taW4taGVpZ2h0XG4gICAgICAgKi9cbiAgICAgICdtaW4taCc6IFt7XG4gICAgICAgICdtaW4taCc6IFsnc2NyZWVuJywgJ2xoJywgJ25vbmUnLCAuLi5zY2FsZVNpemluZygpXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIE1heC1IZWlnaHRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9tYXgtaGVpZ2h0XG4gICAgICAgKi9cbiAgICAgICdtYXgtaCc6IFt7XG4gICAgICAgICdtYXgtaCc6IFsnc2NyZWVuJywgJ2xoJywgLi4uc2NhbGVTaXppbmcoKV1cbiAgICAgIH1dLFxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvLyAtLS0gVHlwb2dyYXBoeSAtLS1cbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLyoqXG4gICAgICAgKiBGb250IFNpemVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9mb250LXNpemVcbiAgICAgICAqL1xuICAgICAgJ2ZvbnQtc2l6ZSc6IFt7XG4gICAgICAgIHRleHQ6IFsnYmFzZScsIHRoZW1lVGV4dCwgaXNBcmJpdHJhcnlWYXJpYWJsZUxlbmd0aCwgaXNBcmJpdHJhcnlMZW5ndGhdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogRm9udCBTbW9vdGhpbmdcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9mb250LXNtb290aGluZ1xuICAgICAgICovXG4gICAgICAnZm9udC1zbW9vdGhpbmcnOiBbJ2FudGlhbGlhc2VkJywgJ3N1YnBpeGVsLWFudGlhbGlhc2VkJ10sXG4gICAgICAvKipcbiAgICAgICAqIEZvbnQgU3R5bGVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9mb250LXN0eWxlXG4gICAgICAgKi9cbiAgICAgICdmb250LXN0eWxlJzogWydpdGFsaWMnLCAnbm90LWl0YWxpYyddLFxuICAgICAgLyoqXG4gICAgICAgKiBGb250IFdlaWdodFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2ZvbnQtd2VpZ2h0XG4gICAgICAgKi9cbiAgICAgICdmb250LXdlaWdodCc6IFt7XG4gICAgICAgIGZvbnQ6IFt0aGVtZUZvbnRXZWlnaHQsIGlzQXJiaXRyYXJ5VmFyaWFibGVXZWlnaHQsIGlzQXJiaXRyYXJ5V2VpZ2h0XVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEZvbnQgU3RyZXRjaFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2ZvbnQtc3RyZXRjaFxuICAgICAgICovXG4gICAgICAnZm9udC1zdHJldGNoJzogW3tcbiAgICAgICAgJ2ZvbnQtc3RyZXRjaCc6IFsndWx0cmEtY29uZGVuc2VkJywgJ2V4dHJhLWNvbmRlbnNlZCcsICdjb25kZW5zZWQnLCAnc2VtaS1jb25kZW5zZWQnLCAnbm9ybWFsJywgJ3NlbWktZXhwYW5kZWQnLCAnZXhwYW5kZWQnLCAnZXh0cmEtZXhwYW5kZWQnLCAndWx0cmEtZXhwYW5kZWQnLCBpc1BlcmNlbnQsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogRm9udCBGYW1pbHlcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9mb250LWZhbWlseVxuICAgICAgICovXG4gICAgICAnZm9udC1mYW1pbHknOiBbe1xuICAgICAgICBmb250OiBbaXNBcmJpdHJhcnlWYXJpYWJsZUZhbWlseU5hbWUsIGlzQXJiaXRyYXJ5RmFtaWx5TmFtZSwgdGhlbWVGb250XVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEZvbnQgRmVhdHVyZSBTZXR0aW5nc1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2ZvbnQtZmVhdHVyZS1zZXR0aW5nc1xuICAgICAgICovXG4gICAgICAnZm9udC1mZWF0dXJlcyc6IFt7XG4gICAgICAgICdmb250LWZlYXR1cmVzJzogW2lzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogRm9udCBWYXJpYW50IE51bWVyaWNcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9mb250LXZhcmlhbnQtbnVtZXJpY1xuICAgICAgICovXG4gICAgICAnZnZuLW5vcm1hbCc6IFsnbm9ybWFsLW51bXMnXSxcbiAgICAgIC8qKlxuICAgICAgICogRm9udCBWYXJpYW50IE51bWVyaWNcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9mb250LXZhcmlhbnQtbnVtZXJpY1xuICAgICAgICovXG4gICAgICAnZnZuLW9yZGluYWwnOiBbJ29yZGluYWwnXSxcbiAgICAgIC8qKlxuICAgICAgICogRm9udCBWYXJpYW50IE51bWVyaWNcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9mb250LXZhcmlhbnQtbnVtZXJpY1xuICAgICAgICovXG4gICAgICAnZnZuLXNsYXNoZWQtemVybyc6IFsnc2xhc2hlZC16ZXJvJ10sXG4gICAgICAvKipcbiAgICAgICAqIEZvbnQgVmFyaWFudCBOdW1lcmljXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvZm9udC12YXJpYW50LW51bWVyaWNcbiAgICAgICAqL1xuICAgICAgJ2Z2bi1maWd1cmUnOiBbJ2xpbmluZy1udW1zJywgJ29sZHN0eWxlLW51bXMnXSxcbiAgICAgIC8qKlxuICAgICAgICogRm9udCBWYXJpYW50IE51bWVyaWNcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9mb250LXZhcmlhbnQtbnVtZXJpY1xuICAgICAgICovXG4gICAgICAnZnZuLXNwYWNpbmcnOiBbJ3Byb3BvcnRpb25hbC1udW1zJywgJ3RhYnVsYXItbnVtcyddLFxuICAgICAgLyoqXG4gICAgICAgKiBGb250IFZhcmlhbnQgTnVtZXJpY1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2ZvbnQtdmFyaWFudC1udW1lcmljXG4gICAgICAgKi9cbiAgICAgICdmdm4tZnJhY3Rpb24nOiBbJ2RpYWdvbmFsLWZyYWN0aW9ucycsICdzdGFja2VkLWZyYWN0aW9ucyddLFxuICAgICAgLyoqXG4gICAgICAgKiBMZXR0ZXIgU3BhY2luZ1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2xldHRlci1zcGFjaW5nXG4gICAgICAgKi9cbiAgICAgIHRyYWNraW5nOiBbe1xuICAgICAgICB0cmFja2luZzogW3RoZW1lVHJhY2tpbmcsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogTGluZSBDbGFtcFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2xpbmUtY2xhbXBcbiAgICAgICAqL1xuICAgICAgJ2xpbmUtY2xhbXAnOiBbe1xuICAgICAgICAnbGluZS1jbGFtcCc6IFtpc051bWJlciwgJ25vbmUnLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeU51bWJlcl1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBMaW5lIEhlaWdodFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2xpbmUtaGVpZ2h0XG4gICAgICAgKi9cbiAgICAgIGxlYWRpbmc6IFt7XG4gICAgICAgIGxlYWRpbmc6IFsvKiogRGVwcmVjYXRlZCBzaW5jZSBUYWlsd2luZCBDU1MgdjQuMC4wLiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS90YWlsd2luZGxhYnMvdGFpbHdpbmRjc3MuY29tL2lzc3Vlcy8yMDI3I2lzc3VlY29tbWVudC0yNjIwMTUyNzU3ICovXG4gICAgICAgIHRoZW1lTGVhZGluZywgLi4uc2NhbGVVbmFtYmlndW91c1NwYWNpbmcoKV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBMaXN0IFN0eWxlIEltYWdlXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvbGlzdC1zdHlsZS1pbWFnZVxuICAgICAgICovXG4gICAgICAnbGlzdC1pbWFnZSc6IFt7XG4gICAgICAgICdsaXN0LWltYWdlJzogWydub25lJywgaXNBcmJpdHJhcnlWYXJpYWJsZSwgaXNBcmJpdHJhcnlWYWx1ZV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBMaXN0IFN0eWxlIFBvc2l0aW9uXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvbGlzdC1zdHlsZS1wb3NpdGlvblxuICAgICAgICovXG4gICAgICAnbGlzdC1zdHlsZS1wb3NpdGlvbic6IFt7XG4gICAgICAgIGxpc3Q6IFsnaW5zaWRlJywgJ291dHNpZGUnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIExpc3QgU3R5bGUgVHlwZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2xpc3Qtc3R5bGUtdHlwZVxuICAgICAgICovXG4gICAgICAnbGlzdC1zdHlsZS10eXBlJzogW3tcbiAgICAgICAgbGlzdDogWydkaXNjJywgJ2RlY2ltYWwnLCAnbm9uZScsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogVGV4dCBBbGlnbm1lbnRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90ZXh0LWFsaWduXG4gICAgICAgKi9cbiAgICAgICd0ZXh0LWFsaWdubWVudCc6IFt7XG4gICAgICAgIHRleHQ6IFsnbGVmdCcsICdjZW50ZXInLCAncmlnaHQnLCAnanVzdGlmeScsICdzdGFydCcsICdlbmQnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFBsYWNlaG9sZGVyIENvbG9yXG4gICAgICAgKiBAZGVwcmVjYXRlZCBzaW5jZSBUYWlsd2luZCBDU1MgdjMuMC4wXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdjMudGFpbHdpbmRjc3MuY29tL2RvY3MvcGxhY2Vob2xkZXItY29sb3JcbiAgICAgICAqL1xuICAgICAgJ3BsYWNlaG9sZGVyLWNvbG9yJzogW3tcbiAgICAgICAgcGxhY2Vob2xkZXI6IHNjYWxlQ29sb3IoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFRleHQgQ29sb3JcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90ZXh0LWNvbG9yXG4gICAgICAgKi9cbiAgICAgICd0ZXh0LWNvbG9yJzogW3tcbiAgICAgICAgdGV4dDogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogVGV4dCBEZWNvcmF0aW9uXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvdGV4dC1kZWNvcmF0aW9uXG4gICAgICAgKi9cbiAgICAgICd0ZXh0LWRlY29yYXRpb24nOiBbJ3VuZGVybGluZScsICdvdmVybGluZScsICdsaW5lLXRocm91Z2gnLCAnbm8tdW5kZXJsaW5lJ10sXG4gICAgICAvKipcbiAgICAgICAqIFRleHQgRGVjb3JhdGlvbiBTdHlsZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3RleHQtZGVjb3JhdGlvbi1zdHlsZVxuICAgICAgICovXG4gICAgICAndGV4dC1kZWNvcmF0aW9uLXN0eWxlJzogW3tcbiAgICAgICAgZGVjb3JhdGlvbjogWy4uLnNjYWxlTGluZVN0eWxlKCksICd3YXZ5J11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBUZXh0IERlY29yYXRpb24gVGhpY2tuZXNzXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvdGV4dC1kZWNvcmF0aW9uLXRoaWNrbmVzc1xuICAgICAgICovXG4gICAgICAndGV4dC1kZWNvcmF0aW9uLXRoaWNrbmVzcyc6IFt7XG4gICAgICAgIGRlY29yYXRpb246IFtpc051bWJlciwgJ2Zyb20tZm9udCcsICdhdXRvJywgaXNBcmJpdHJhcnlWYXJpYWJsZSwgaXNBcmJpdHJhcnlMZW5ndGhdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogVGV4dCBEZWNvcmF0aW9uIENvbG9yXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvdGV4dC1kZWNvcmF0aW9uLWNvbG9yXG4gICAgICAgKi9cbiAgICAgICd0ZXh0LWRlY29yYXRpb24tY29sb3InOiBbe1xuICAgICAgICBkZWNvcmF0aW9uOiBzY2FsZUNvbG9yKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBUZXh0IFVuZGVybGluZSBPZmZzZXRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90ZXh0LXVuZGVybGluZS1vZmZzZXRcbiAgICAgICAqL1xuICAgICAgJ3VuZGVybGluZS1vZmZzZXQnOiBbe1xuICAgICAgICAndW5kZXJsaW5lLW9mZnNldCc6IFtpc051bWJlciwgJ2F1dG8nLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFRleHQgVHJhbnNmb3JtXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvdGV4dC10cmFuc2Zvcm1cbiAgICAgICAqL1xuICAgICAgJ3RleHQtdHJhbnNmb3JtJzogWyd1cHBlcmNhc2UnLCAnbG93ZXJjYXNlJywgJ2NhcGl0YWxpemUnLCAnbm9ybWFsLWNhc2UnXSxcbiAgICAgIC8qKlxuICAgICAgICogVGV4dCBPdmVyZmxvd1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3RleHQtb3ZlcmZsb3dcbiAgICAgICAqL1xuICAgICAgJ3RleHQtb3ZlcmZsb3cnOiBbJ3RydW5jYXRlJywgJ3RleHQtZWxsaXBzaXMnLCAndGV4dC1jbGlwJ10sXG4gICAgICAvKipcbiAgICAgICAqIFRleHQgV3JhcFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3RleHQtd3JhcFxuICAgICAgICovXG4gICAgICAndGV4dC13cmFwJzogW3tcbiAgICAgICAgdGV4dDogWyd3cmFwJywgJ25vd3JhcCcsICdiYWxhbmNlJywgJ3ByZXR0eSddXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogVGV4dCBJbmRlbnRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90ZXh0LWluZGVudFxuICAgICAgICovXG4gICAgICBpbmRlbnQ6IFt7XG4gICAgICAgIGluZGVudDogc2NhbGVVbmFtYmlndW91c1NwYWNpbmcoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFRhYiBTaXplXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvdGFiLXNpemVcbiAgICAgICAqL1xuICAgICAgJ3RhYi1zaXplJzogW3tcbiAgICAgICAgdGFiOiBbaXNJbnRlZ2VyLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFZlcnRpY2FsIEFsaWdubWVudFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3ZlcnRpY2FsLWFsaWduXG4gICAgICAgKi9cbiAgICAgICd2ZXJ0aWNhbC1hbGlnbic6IFt7XG4gICAgICAgIGFsaWduOiBbJ2Jhc2VsaW5lJywgJ3RvcCcsICdtaWRkbGUnLCAnYm90dG9tJywgJ3RleHQtdG9wJywgJ3RleHQtYm90dG9tJywgJ3N1YicsICdzdXBlcicsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogV2hpdGVzcGFjZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3doaXRlc3BhY2VcbiAgICAgICAqL1xuICAgICAgd2hpdGVzcGFjZTogW3tcbiAgICAgICAgd2hpdGVzcGFjZTogWydub3JtYWwnLCAnbm93cmFwJywgJ3ByZScsICdwcmUtbGluZScsICdwcmUtd3JhcCcsICdicmVhay1zcGFjZXMnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFdvcmQgQnJlYWtcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy93b3JkLWJyZWFrXG4gICAgICAgKi9cbiAgICAgIGJyZWFrOiBbe1xuICAgICAgICBicmVhazogWydub3JtYWwnLCAnd29yZHMnLCAnYWxsJywgJ2tlZXAnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIE92ZXJmbG93IFdyYXBcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9vdmVyZmxvdy13cmFwXG4gICAgICAgKi9cbiAgICAgIHdyYXA6IFt7XG4gICAgICAgIHdyYXA6IFsnYnJlYWstd29yZCcsICdhbnl3aGVyZScsICdub3JtYWwnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEh5cGhlbnNcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9oeXBoZW5zXG4gICAgICAgKi9cbiAgICAgIGh5cGhlbnM6IFt7XG4gICAgICAgIGh5cGhlbnM6IFsnbm9uZScsICdtYW51YWwnLCAnYXV0byddXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQ29udGVudFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2NvbnRlbnRcbiAgICAgICAqL1xuICAgICAgY29udGVudDogW3tcbiAgICAgICAgY29udGVudDogWydub25lJywgaXNBcmJpdHJhcnlWYXJpYWJsZSwgaXNBcmJpdHJhcnlWYWx1ZV1cbiAgICAgIH1dLFxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gLS0tIEJhY2tncm91bmRzIC0tLVxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLyoqXG4gICAgICAgKiBCYWNrZ3JvdW5kIEF0dGFjaG1lbnRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9iYWNrZ3JvdW5kLWF0dGFjaG1lbnRcbiAgICAgICAqL1xuICAgICAgJ2JnLWF0dGFjaG1lbnQnOiBbe1xuICAgICAgICBiZzogWydmaXhlZCcsICdsb2NhbCcsICdzY3JvbGwnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJhY2tncm91bmQgQ2xpcFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JhY2tncm91bmQtY2xpcFxuICAgICAgICovXG4gICAgICAnYmctY2xpcCc6IFt7XG4gICAgICAgICdiZy1jbGlwJzogWydib3JkZXInLCAncGFkZGluZycsICdjb250ZW50JywgJ3RleHQnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJhY2tncm91bmQgT3JpZ2luXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYmFja2dyb3VuZC1vcmlnaW5cbiAgICAgICAqL1xuICAgICAgJ2JnLW9yaWdpbic6IFt7XG4gICAgICAgICdiZy1vcmlnaW4nOiBbJ2JvcmRlcicsICdwYWRkaW5nJywgJ2NvbnRlbnQnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJhY2tncm91bmQgUG9zaXRpb25cbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9iYWNrZ3JvdW5kLXBvc2l0aW9uXG4gICAgICAgKi9cbiAgICAgICdiZy1wb3NpdGlvbic6IFt7XG4gICAgICAgIGJnOiBzY2FsZUJnUG9zaXRpb24oKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJhY2tncm91bmQgUmVwZWF0XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYmFja2dyb3VuZC1yZXBlYXRcbiAgICAgICAqL1xuICAgICAgJ2JnLXJlcGVhdCc6IFt7XG4gICAgICAgIGJnOiBzY2FsZUJnUmVwZWF0KClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCYWNrZ3JvdW5kIFNpemVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9iYWNrZ3JvdW5kLXNpemVcbiAgICAgICAqL1xuICAgICAgJ2JnLXNpemUnOiBbe1xuICAgICAgICBiZzogc2NhbGVCZ1NpemUoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJhY2tncm91bmQgSW1hZ2VcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9iYWNrZ3JvdW5kLWltYWdlXG4gICAgICAgKi9cbiAgICAgICdiZy1pbWFnZSc6IFt7XG4gICAgICAgIGJnOiBbJ25vbmUnLCB7XG4gICAgICAgICAgbGluZWFyOiBbe1xuICAgICAgICAgICAgdG86IFsndCcsICd0cicsICdyJywgJ2JyJywgJ2InLCAnYmwnLCAnbCcsICd0bCddXG4gICAgICAgICAgfSwgaXNJbnRlZ2VyLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXSxcbiAgICAgICAgICByYWRpYWw6IFsnJywgaXNBcmJpdHJhcnlWYXJpYWJsZSwgaXNBcmJpdHJhcnlWYWx1ZV0sXG4gICAgICAgICAgY29uaWM6IFtpc0ludGVnZXIsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICAgIH0sIGlzQXJiaXRyYXJ5VmFyaWFibGVJbWFnZSwgaXNBcmJpdHJhcnlJbWFnZV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCYWNrZ3JvdW5kIENvbG9yXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYmFja2dyb3VuZC1jb2xvclxuICAgICAgICovXG4gICAgICAnYmctY29sb3InOiBbe1xuICAgICAgICBiZzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogR3JhZGllbnQgQ29sb3IgU3RvcHMgRnJvbSBQb3NpdGlvblxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2dyYWRpZW50LWNvbG9yLXN0b3BzXG4gICAgICAgKi9cbiAgICAgICdncmFkaWVudC1mcm9tLXBvcyc6IFt7XG4gICAgICAgIGZyb206IHNjYWxlR3JhZGllbnRTdG9wUG9zaXRpb24oKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEdyYWRpZW50IENvbG9yIFN0b3BzIFZpYSBQb3NpdGlvblxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2dyYWRpZW50LWNvbG9yLXN0b3BzXG4gICAgICAgKi9cbiAgICAgICdncmFkaWVudC12aWEtcG9zJzogW3tcbiAgICAgICAgdmlhOiBzY2FsZUdyYWRpZW50U3RvcFBvc2l0aW9uKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBHcmFkaWVudCBDb2xvciBTdG9wcyBUbyBQb3NpdGlvblxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2dyYWRpZW50LWNvbG9yLXN0b3BzXG4gICAgICAgKi9cbiAgICAgICdncmFkaWVudC10by1wb3MnOiBbe1xuICAgICAgICB0bzogc2NhbGVHcmFkaWVudFN0b3BQb3NpdGlvbigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogR3JhZGllbnQgQ29sb3IgU3RvcHMgRnJvbVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2dyYWRpZW50LWNvbG9yLXN0b3BzXG4gICAgICAgKi9cbiAgICAgICdncmFkaWVudC1mcm9tJzogW3tcbiAgICAgICAgZnJvbTogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogR3JhZGllbnQgQ29sb3IgU3RvcHMgVmlhXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvZ3JhZGllbnQtY29sb3Itc3RvcHNcbiAgICAgICAqL1xuICAgICAgJ2dyYWRpZW50LXZpYSc6IFt7XG4gICAgICAgIHZpYTogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogR3JhZGllbnQgQ29sb3IgU3RvcHMgVG9cbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ncmFkaWVudC1jb2xvci1zdG9wc1xuICAgICAgICovXG4gICAgICAnZ3JhZGllbnQtdG8nOiBbe1xuICAgICAgICB0bzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gLS0tIEJvcmRlcnMgLS0tXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8qKlxuICAgICAgICogQm9yZGVyIFJhZGl1c1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JvcmRlci1yYWRpdXNcbiAgICAgICAqL1xuICAgICAgcm91bmRlZDogW3tcbiAgICAgICAgcm91bmRlZDogc2NhbGVSYWRpdXMoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJvcmRlciBSYWRpdXMgU3RhcnRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItcmFkaXVzXG4gICAgICAgKi9cbiAgICAgICdyb3VuZGVkLXMnOiBbe1xuICAgICAgICAncm91bmRlZC1zJzogc2NhbGVSYWRpdXMoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJvcmRlciBSYWRpdXMgRW5kXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYm9yZGVyLXJhZGl1c1xuICAgICAgICovXG4gICAgICAncm91bmRlZC1lJzogW3tcbiAgICAgICAgJ3JvdW5kZWQtZSc6IHNjYWxlUmFkaXVzKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3JkZXIgUmFkaXVzIFRvcFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JvcmRlci1yYWRpdXNcbiAgICAgICAqL1xuICAgICAgJ3JvdW5kZWQtdCc6IFt7XG4gICAgICAgICdyb3VuZGVkLXQnOiBzY2FsZVJhZGl1cygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQm9yZGVyIFJhZGl1cyBSaWdodFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JvcmRlci1yYWRpdXNcbiAgICAgICAqL1xuICAgICAgJ3JvdW5kZWQtcic6IFt7XG4gICAgICAgICdyb3VuZGVkLXInOiBzY2FsZVJhZGl1cygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQm9yZGVyIFJhZGl1cyBCb3R0b21cbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItcmFkaXVzXG4gICAgICAgKi9cbiAgICAgICdyb3VuZGVkLWInOiBbe1xuICAgICAgICAncm91bmRlZC1iJzogc2NhbGVSYWRpdXMoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJvcmRlciBSYWRpdXMgTGVmdFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JvcmRlci1yYWRpdXNcbiAgICAgICAqL1xuICAgICAgJ3JvdW5kZWQtbCc6IFt7XG4gICAgICAgICdyb3VuZGVkLWwnOiBzY2FsZVJhZGl1cygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQm9yZGVyIFJhZGl1cyBTdGFydCBTdGFydFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JvcmRlci1yYWRpdXNcbiAgICAgICAqL1xuICAgICAgJ3JvdW5kZWQtc3MnOiBbe1xuICAgICAgICAncm91bmRlZC1zcyc6IHNjYWxlUmFkaXVzKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3JkZXIgUmFkaXVzIFN0YXJ0IEVuZFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JvcmRlci1yYWRpdXNcbiAgICAgICAqL1xuICAgICAgJ3JvdW5kZWQtc2UnOiBbe1xuICAgICAgICAncm91bmRlZC1zZSc6IHNjYWxlUmFkaXVzKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3JkZXIgUmFkaXVzIEVuZCBFbmRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItcmFkaXVzXG4gICAgICAgKi9cbiAgICAgICdyb3VuZGVkLWVlJzogW3tcbiAgICAgICAgJ3JvdW5kZWQtZWUnOiBzY2FsZVJhZGl1cygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQm9yZGVyIFJhZGl1cyBFbmQgU3RhcnRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItcmFkaXVzXG4gICAgICAgKi9cbiAgICAgICdyb3VuZGVkLWVzJzogW3tcbiAgICAgICAgJ3JvdW5kZWQtZXMnOiBzY2FsZVJhZGl1cygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQm9yZGVyIFJhZGl1cyBUb3AgTGVmdFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JvcmRlci1yYWRpdXNcbiAgICAgICAqL1xuICAgICAgJ3JvdW5kZWQtdGwnOiBbe1xuICAgICAgICAncm91bmRlZC10bCc6IHNjYWxlUmFkaXVzKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3JkZXIgUmFkaXVzIFRvcCBSaWdodFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JvcmRlci1yYWRpdXNcbiAgICAgICAqL1xuICAgICAgJ3JvdW5kZWQtdHInOiBbe1xuICAgICAgICAncm91bmRlZC10cic6IHNjYWxlUmFkaXVzKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3JkZXIgUmFkaXVzIEJvdHRvbSBSaWdodFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JvcmRlci1yYWRpdXNcbiAgICAgICAqL1xuICAgICAgJ3JvdW5kZWQtYnInOiBbe1xuICAgICAgICAncm91bmRlZC1icic6IHNjYWxlUmFkaXVzKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3JkZXIgUmFkaXVzIEJvdHRvbSBMZWZ0XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYm9yZGVyLXJhZGl1c1xuICAgICAgICovXG4gICAgICAncm91bmRlZC1ibCc6IFt7XG4gICAgICAgICdyb3VuZGVkLWJsJzogc2NhbGVSYWRpdXMoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJvcmRlciBXaWR0aFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JvcmRlci13aWR0aFxuICAgICAgICovXG4gICAgICAnYm9yZGVyLXcnOiBbe1xuICAgICAgICBib3JkZXI6IHNjYWxlQm9yZGVyV2lkdGgoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJvcmRlciBXaWR0aCBJbmxpbmVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItd2lkdGhcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci13LXgnOiBbe1xuICAgICAgICAnYm9yZGVyLXgnOiBzY2FsZUJvcmRlcldpZHRoKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3JkZXIgV2lkdGggQmxvY2tcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItd2lkdGhcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci13LXknOiBbe1xuICAgICAgICAnYm9yZGVyLXknOiBzY2FsZUJvcmRlcldpZHRoKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3JkZXIgV2lkdGggSW5saW5lIFN0YXJ0XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYm9yZGVyLXdpZHRoXG4gICAgICAgKi9cbiAgICAgICdib3JkZXItdy1zJzogW3tcbiAgICAgICAgJ2JvcmRlci1zJzogc2NhbGVCb3JkZXJXaWR0aCgpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQm9yZGVyIFdpZHRoIElubGluZSBFbmRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItd2lkdGhcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci13LWUnOiBbe1xuICAgICAgICAnYm9yZGVyLWUnOiBzY2FsZUJvcmRlcldpZHRoKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3JkZXIgV2lkdGggQmxvY2sgU3RhcnRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItd2lkdGhcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci13LWJzJzogW3tcbiAgICAgICAgJ2JvcmRlci1icyc6IHNjYWxlQm9yZGVyV2lkdGgoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJvcmRlciBXaWR0aCBCbG9jayBFbmRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItd2lkdGhcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci13LWJlJzogW3tcbiAgICAgICAgJ2JvcmRlci1iZSc6IHNjYWxlQm9yZGVyV2lkdGgoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJvcmRlciBXaWR0aCBUb3BcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItd2lkdGhcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci13LXQnOiBbe1xuICAgICAgICAnYm9yZGVyLXQnOiBzY2FsZUJvcmRlcldpZHRoKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3JkZXIgV2lkdGggUmlnaHRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItd2lkdGhcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci13LXInOiBbe1xuICAgICAgICAnYm9yZGVyLXInOiBzY2FsZUJvcmRlcldpZHRoKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3JkZXIgV2lkdGggQm90dG9tXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYm9yZGVyLXdpZHRoXG4gICAgICAgKi9cbiAgICAgICdib3JkZXItdy1iJzogW3tcbiAgICAgICAgJ2JvcmRlci1iJzogc2NhbGVCb3JkZXJXaWR0aCgpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQm9yZGVyIFdpZHRoIExlZnRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItd2lkdGhcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci13LWwnOiBbe1xuICAgICAgICAnYm9yZGVyLWwnOiBzY2FsZUJvcmRlcldpZHRoKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBEaXZpZGUgV2lkdGggWFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JvcmRlci13aWR0aCNiZXR3ZWVuLWNoaWxkcmVuXG4gICAgICAgKi9cbiAgICAgICdkaXZpZGUteCc6IFt7XG4gICAgICAgICdkaXZpZGUteCc6IHNjYWxlQm9yZGVyV2lkdGgoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIERpdmlkZSBXaWR0aCBYIFJldmVyc2VcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItd2lkdGgjYmV0d2Vlbi1jaGlsZHJlblxuICAgICAgICovXG4gICAgICAnZGl2aWRlLXgtcmV2ZXJzZSc6IFsnZGl2aWRlLXgtcmV2ZXJzZSddLFxuICAgICAgLyoqXG4gICAgICAgKiBEaXZpZGUgV2lkdGggWVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JvcmRlci13aWR0aCNiZXR3ZWVuLWNoaWxkcmVuXG4gICAgICAgKi9cbiAgICAgICdkaXZpZGUteSc6IFt7XG4gICAgICAgICdkaXZpZGUteSc6IHNjYWxlQm9yZGVyV2lkdGgoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIERpdmlkZSBXaWR0aCBZIFJldmVyc2VcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItd2lkdGgjYmV0d2Vlbi1jaGlsZHJlblxuICAgICAgICovXG4gICAgICAnZGl2aWRlLXktcmV2ZXJzZSc6IFsnZGl2aWRlLXktcmV2ZXJzZSddLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3JkZXIgU3R5bGVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItc3R5bGVcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci1zdHlsZSc6IFt7XG4gICAgICAgIGJvcmRlcjogWy4uLnNjYWxlTGluZVN0eWxlKCksICdoaWRkZW4nLCAnbm9uZSddXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogRGl2aWRlIFN0eWxlXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYm9yZGVyLXN0eWxlI3NldHRpbmctdGhlLWRpdmlkZXItc3R5bGVcbiAgICAgICAqL1xuICAgICAgJ2RpdmlkZS1zdHlsZSc6IFt7XG4gICAgICAgIGRpdmlkZTogWy4uLnNjYWxlTGluZVN0eWxlKCksICdoaWRkZW4nLCAnbm9uZSddXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQm9yZGVyIENvbG9yXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYm9yZGVyLWNvbG9yXG4gICAgICAgKi9cbiAgICAgICdib3JkZXItY29sb3InOiBbe1xuICAgICAgICBib3JkZXI6IHNjYWxlQ29sb3IoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJvcmRlciBDb2xvciBJbmxpbmVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItY29sb3JcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci1jb2xvci14JzogW3tcbiAgICAgICAgJ2JvcmRlci14Jzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQm9yZGVyIENvbG9yIEJsb2NrXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYm9yZGVyLWNvbG9yXG4gICAgICAgKi9cbiAgICAgICdib3JkZXItY29sb3IteSc6IFt7XG4gICAgICAgICdib3JkZXIteSc6IHNjYWxlQ29sb3IoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJvcmRlciBDb2xvciBJbmxpbmUgU3RhcnRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItY29sb3JcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci1jb2xvci1zJzogW3tcbiAgICAgICAgJ2JvcmRlci1zJzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQm9yZGVyIENvbG9yIElubGluZSBFbmRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItY29sb3JcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci1jb2xvci1lJzogW3tcbiAgICAgICAgJ2JvcmRlci1lJzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQm9yZGVyIENvbG9yIEJsb2NrIFN0YXJ0XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYm9yZGVyLWNvbG9yXG4gICAgICAgKi9cbiAgICAgICdib3JkZXItY29sb3ItYnMnOiBbe1xuICAgICAgICAnYm9yZGVyLWJzJzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQm9yZGVyIENvbG9yIEJsb2NrIEVuZFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JvcmRlci1jb2xvclxuICAgICAgICovXG4gICAgICAnYm9yZGVyLWNvbG9yLWJlJzogW3tcbiAgICAgICAgJ2JvcmRlci1iZSc6IHNjYWxlQ29sb3IoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJvcmRlciBDb2xvciBUb3BcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItY29sb3JcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci1jb2xvci10JzogW3tcbiAgICAgICAgJ2JvcmRlci10Jzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQm9yZGVyIENvbG9yIFJpZ2h0XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYm9yZGVyLWNvbG9yXG4gICAgICAgKi9cbiAgICAgICdib3JkZXItY29sb3Itcic6IFt7XG4gICAgICAgICdib3JkZXItcic6IHNjYWxlQ29sb3IoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJvcmRlciBDb2xvciBCb3R0b21cbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItY29sb3JcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci1jb2xvci1iJzogW3tcbiAgICAgICAgJ2JvcmRlci1iJzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQm9yZGVyIENvbG9yIExlZnRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3JkZXItY29sb3JcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci1jb2xvci1sJzogW3tcbiAgICAgICAgJ2JvcmRlci1sJzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogRGl2aWRlIENvbG9yXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvZGl2aWRlLWNvbG9yXG4gICAgICAgKi9cbiAgICAgICdkaXZpZGUtY29sb3InOiBbe1xuICAgICAgICBkaXZpZGU6IHNjYWxlQ29sb3IoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIE91dGxpbmUgU3R5bGVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9vdXRsaW5lLXN0eWxlXG4gICAgICAgKi9cbiAgICAgICdvdXRsaW5lLXN0eWxlJzogW3tcbiAgICAgICAgb3V0bGluZTogWy4uLnNjYWxlTGluZVN0eWxlKCksICdub25lJywgJ2hpZGRlbiddXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogT3V0bGluZSBPZmZzZXRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9vdXRsaW5lLW9mZnNldFxuICAgICAgICovXG4gICAgICAnb3V0bGluZS1vZmZzZXQnOiBbe1xuICAgICAgICAnb3V0bGluZS1vZmZzZXQnOiBbaXNOdW1iZXIsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogT3V0bGluZSBXaWR0aFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL291dGxpbmUtd2lkdGhcbiAgICAgICAqL1xuICAgICAgJ291dGxpbmUtdyc6IFt7XG4gICAgICAgIG91dGxpbmU6IFsnJywgaXNOdW1iZXIsIGlzQXJiaXRyYXJ5VmFyaWFibGVMZW5ndGgsIGlzQXJiaXRyYXJ5TGVuZ3RoXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIE91dGxpbmUgQ29sb3JcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9vdXRsaW5lLWNvbG9yXG4gICAgICAgKi9cbiAgICAgICdvdXRsaW5lLWNvbG9yJzogW3tcbiAgICAgICAgb3V0bGluZTogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gLS0tIEVmZmVjdHMgLS0tXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8qKlxuICAgICAgICogQm94IFNoYWRvd1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JveC1zaGFkb3dcbiAgICAgICAqL1xuICAgICAgc2hhZG93OiBbe1xuICAgICAgICBzaGFkb3c6IFtcbiAgICAgICAgLy8gRGVwcmVjYXRlZCBzaW5jZSBUYWlsd2luZCBDU1MgdjQuMC4wXG4gICAgICAgICcnLCAnbm9uZScsIHRoZW1lU2hhZG93LCBpc0FyYml0cmFyeVZhcmlhYmxlU2hhZG93LCBpc0FyYml0cmFyeVNoYWRvd11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3ggU2hhZG93IENvbG9yXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYm94LXNoYWRvdyNzZXR0aW5nLXRoZS1zaGFkb3ctY29sb3JcbiAgICAgICAqL1xuICAgICAgJ3NoYWRvdy1jb2xvcic6IFt7XG4gICAgICAgIHNoYWRvdzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogSW5zZXQgQm94IFNoYWRvd1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JveC1zaGFkb3cjYWRkaW5nLWFuLWluc2V0LXNoYWRvd1xuICAgICAgICovXG4gICAgICAnaW5zZXQtc2hhZG93JzogW3tcbiAgICAgICAgJ2luc2V0LXNoYWRvdyc6IFsnbm9uZScsIHRoZW1lSW5zZXRTaGFkb3csIGlzQXJiaXRyYXJ5VmFyaWFibGVTaGFkb3csIGlzQXJiaXRyYXJ5U2hhZG93XVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEluc2V0IEJveCBTaGFkb3cgQ29sb3JcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3gtc2hhZG93I3NldHRpbmctdGhlLWluc2V0LXNoYWRvdy1jb2xvclxuICAgICAgICovXG4gICAgICAnaW5zZXQtc2hhZG93LWNvbG9yJzogW3tcbiAgICAgICAgJ2luc2V0LXNoYWRvdyc6IHNjYWxlQ29sb3IoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFJpbmcgV2lkdGhcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3gtc2hhZG93I2FkZGluZy1hLXJpbmdcbiAgICAgICAqL1xuICAgICAgJ3Jpbmctdyc6IFt7XG4gICAgICAgIHJpbmc6IHNjYWxlQm9yZGVyV2lkdGgoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFJpbmcgV2lkdGggSW5zZXRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly92My50YWlsd2luZGNzcy5jb20vZG9jcy9yaW5nLXdpZHRoI2luc2V0LXJpbmdzXG4gICAgICAgKiBAZGVwcmVjYXRlZCBzaW5jZSBUYWlsd2luZCBDU1MgdjQuMC4wXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS90YWlsd2luZGxhYnMvdGFpbHdpbmRjc3MvYmxvYi92NC4wLjAvcGFja2FnZXMvdGFpbHdpbmRjc3Mvc3JjL3V0aWxpdGllcy50cyNMNDE1OFxuICAgICAgICovXG4gICAgICAncmluZy13LWluc2V0JzogWydyaW5nLWluc2V0J10sXG4gICAgICAvKipcbiAgICAgICAqIFJpbmcgQ29sb3JcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9ib3gtc2hhZG93I3NldHRpbmctdGhlLXJpbmctY29sb3JcbiAgICAgICAqL1xuICAgICAgJ3JpbmctY29sb3InOiBbe1xuICAgICAgICByaW5nOiBzY2FsZUNvbG9yKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBSaW5nIE9mZnNldCBXaWR0aFxuICAgICAgICogQHNlZSBodHRwczovL3YzLnRhaWx3aW5kY3NzLmNvbS9kb2NzL3Jpbmctb2Zmc2V0LXdpZHRoXG4gICAgICAgKiBAZGVwcmVjYXRlZCBzaW5jZSBUYWlsd2luZCBDU1MgdjQuMC4wXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS90YWlsd2luZGxhYnMvdGFpbHdpbmRjc3MvYmxvYi92NC4wLjAvcGFja2FnZXMvdGFpbHdpbmRjc3Mvc3JjL3V0aWxpdGllcy50cyNMNDE1OFxuICAgICAgICovXG4gICAgICAncmluZy1vZmZzZXQtdyc6IFt7XG4gICAgICAgICdyaW5nLW9mZnNldCc6IFtpc051bWJlciwgaXNBcmJpdHJhcnlMZW5ndGhdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogUmluZyBPZmZzZXQgQ29sb3JcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly92My50YWlsd2luZGNzcy5jb20vZG9jcy9yaW5nLW9mZnNldC1jb2xvclxuICAgICAgICogQGRlcHJlY2F0ZWQgc2luY2UgVGFpbHdpbmQgQ1NTIHY0LjAuMFxuICAgICAgICogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vdGFpbHdpbmRsYWJzL3RhaWx3aW5kY3NzL2Jsb2IvdjQuMC4wL3BhY2thZ2VzL3RhaWx3aW5kY3NzL3NyYy91dGlsaXRpZXMudHMjTDQxNThcbiAgICAgICAqL1xuICAgICAgJ3Jpbmctb2Zmc2V0LWNvbG9yJzogW3tcbiAgICAgICAgJ3Jpbmctb2Zmc2V0Jzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogSW5zZXQgUmluZyBXaWR0aFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JveC1zaGFkb3cjYWRkaW5nLWFuLWluc2V0LXJpbmdcbiAgICAgICAqL1xuICAgICAgJ2luc2V0LXJpbmctdyc6IFt7XG4gICAgICAgICdpbnNldC1yaW5nJzogc2NhbGVCb3JkZXJXaWR0aCgpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogSW5zZXQgUmluZyBDb2xvclxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JveC1zaGFkb3cjc2V0dGluZy10aGUtaW5zZXQtcmluZy1jb2xvclxuICAgICAgICovXG4gICAgICAnaW5zZXQtcmluZy1jb2xvcic6IFt7XG4gICAgICAgICdpbnNldC1yaW5nJzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogVGV4dCBTaGFkb3dcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90ZXh0LXNoYWRvd1xuICAgICAgICovXG4gICAgICAndGV4dC1zaGFkb3cnOiBbe1xuICAgICAgICAndGV4dC1zaGFkb3cnOiBbJ25vbmUnLCB0aGVtZVRleHRTaGFkb3csIGlzQXJiaXRyYXJ5VmFyaWFibGVTaGFkb3csIGlzQXJiaXRyYXJ5U2hhZG93XVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFRleHQgU2hhZG93IENvbG9yXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvdGV4dC1zaGFkb3cjc2V0dGluZy10aGUtc2hhZG93LWNvbG9yXG4gICAgICAgKi9cbiAgICAgICd0ZXh0LXNoYWRvdy1jb2xvcic6IFt7XG4gICAgICAgICd0ZXh0LXNoYWRvdyc6IHNjYWxlQ29sb3IoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIE9wYWNpdHlcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9vcGFjaXR5XG4gICAgICAgKi9cbiAgICAgIG9wYWNpdHk6IFt7XG4gICAgICAgIG9wYWNpdHk6IFtpc051bWJlciwgaXNBcmJpdHJhcnlWYXJpYWJsZSwgaXNBcmJpdHJhcnlWYWx1ZV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBNaXggQmxlbmQgTW9kZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL21peC1ibGVuZC1tb2RlXG4gICAgICAgKi9cbiAgICAgICdtaXgtYmxlbmQnOiBbe1xuICAgICAgICAnbWl4LWJsZW5kJzogWy4uLnNjYWxlQmxlbmRNb2RlKCksICdwbHVzLWRhcmtlcicsICdwbHVzLWxpZ2h0ZXInXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJhY2tncm91bmQgQmxlbmQgTW9kZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JhY2tncm91bmQtYmxlbmQtbW9kZVxuICAgICAgICovXG4gICAgICAnYmctYmxlbmQnOiBbe1xuICAgICAgICAnYmctYmxlbmQnOiBzY2FsZUJsZW5kTW9kZSgpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogTWFzayBDbGlwXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvbWFzay1jbGlwXG4gICAgICAgKi9cbiAgICAgICdtYXNrLWNsaXAnOiBbe1xuICAgICAgICAnbWFzay1jbGlwJzogWydib3JkZXInLCAncGFkZGluZycsICdjb250ZW50JywgJ2ZpbGwnLCAnc3Ryb2tlJywgJ3ZpZXcnXVxuICAgICAgfSwgJ21hc2stbm8tY2xpcCddLFxuICAgICAgLyoqXG4gICAgICAgKiBNYXNrIENvbXBvc2l0ZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL21hc2stY29tcG9zaXRlXG4gICAgICAgKi9cbiAgICAgICdtYXNrLWNvbXBvc2l0ZSc6IFt7XG4gICAgICAgIG1hc2s6IFsnYWRkJywgJ3N1YnRyYWN0JywgJ2ludGVyc2VjdCcsICdleGNsdWRlJ11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBNYXNrIEltYWdlXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvbWFzay1pbWFnZVxuICAgICAgICovXG4gICAgICAnbWFzay1pbWFnZS1saW5lYXItcG9zJzogW3tcbiAgICAgICAgJ21hc2stbGluZWFyJzogW2lzTnVtYmVyXVxuICAgICAgfV0sXG4gICAgICAnbWFzay1pbWFnZS1saW5lYXItZnJvbS1wb3MnOiBbe1xuICAgICAgICAnbWFzay1saW5lYXItZnJvbSc6IHNjYWxlTWFza0ltYWdlUG9zaXRpb24oKVxuICAgICAgfV0sXG4gICAgICAnbWFzay1pbWFnZS1saW5lYXItdG8tcG9zJzogW3tcbiAgICAgICAgJ21hc2stbGluZWFyLXRvJzogc2NhbGVNYXNrSW1hZ2VQb3NpdGlvbigpXG4gICAgICB9XSxcbiAgICAgICdtYXNrLWltYWdlLWxpbmVhci1mcm9tLWNvbG9yJzogW3tcbiAgICAgICAgJ21hc2stbGluZWFyLWZyb20nOiBzY2FsZUNvbG9yKClcbiAgICAgIH1dLFxuICAgICAgJ21hc2staW1hZ2UtbGluZWFyLXRvLWNvbG9yJzogW3tcbiAgICAgICAgJ21hc2stbGluZWFyLXRvJzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgICdtYXNrLWltYWdlLXQtZnJvbS1wb3MnOiBbe1xuICAgICAgICAnbWFzay10LWZyb20nOiBzY2FsZU1hc2tJbWFnZVBvc2l0aW9uKClcbiAgICAgIH1dLFxuICAgICAgJ21hc2staW1hZ2UtdC10by1wb3MnOiBbe1xuICAgICAgICAnbWFzay10LXRvJzogc2NhbGVNYXNrSW1hZ2VQb3NpdGlvbigpXG4gICAgICB9XSxcbiAgICAgICdtYXNrLWltYWdlLXQtZnJvbS1jb2xvcic6IFt7XG4gICAgICAgICdtYXNrLXQtZnJvbSc6IHNjYWxlQ29sb3IoKVxuICAgICAgfV0sXG4gICAgICAnbWFzay1pbWFnZS10LXRvLWNvbG9yJzogW3tcbiAgICAgICAgJ21hc2stdC10byc6IHNjYWxlQ29sb3IoKVxuICAgICAgfV0sXG4gICAgICAnbWFzay1pbWFnZS1yLWZyb20tcG9zJzogW3tcbiAgICAgICAgJ21hc2stci1mcm9tJzogc2NhbGVNYXNrSW1hZ2VQb3NpdGlvbigpXG4gICAgICB9XSxcbiAgICAgICdtYXNrLWltYWdlLXItdG8tcG9zJzogW3tcbiAgICAgICAgJ21hc2stci10byc6IHNjYWxlTWFza0ltYWdlUG9zaXRpb24oKVxuICAgICAgfV0sXG4gICAgICAnbWFzay1pbWFnZS1yLWZyb20tY29sb3InOiBbe1xuICAgICAgICAnbWFzay1yLWZyb20nOiBzY2FsZUNvbG9yKClcbiAgICAgIH1dLFxuICAgICAgJ21hc2staW1hZ2Utci10by1jb2xvcic6IFt7XG4gICAgICAgICdtYXNrLXItdG8nOiBzY2FsZUNvbG9yKClcbiAgICAgIH1dLFxuICAgICAgJ21hc2staW1hZ2UtYi1mcm9tLXBvcyc6IFt7XG4gICAgICAgICdtYXNrLWItZnJvbSc6IHNjYWxlTWFza0ltYWdlUG9zaXRpb24oKVxuICAgICAgfV0sXG4gICAgICAnbWFzay1pbWFnZS1iLXRvLXBvcyc6IFt7XG4gICAgICAgICdtYXNrLWItdG8nOiBzY2FsZU1hc2tJbWFnZVBvc2l0aW9uKClcbiAgICAgIH1dLFxuICAgICAgJ21hc2staW1hZ2UtYi1mcm9tLWNvbG9yJzogW3tcbiAgICAgICAgJ21hc2stYi1mcm9tJzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgICdtYXNrLWltYWdlLWItdG8tY29sb3InOiBbe1xuICAgICAgICAnbWFzay1iLXRvJzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgICdtYXNrLWltYWdlLWwtZnJvbS1wb3MnOiBbe1xuICAgICAgICAnbWFzay1sLWZyb20nOiBzY2FsZU1hc2tJbWFnZVBvc2l0aW9uKClcbiAgICAgIH1dLFxuICAgICAgJ21hc2staW1hZ2UtbC10by1wb3MnOiBbe1xuICAgICAgICAnbWFzay1sLXRvJzogc2NhbGVNYXNrSW1hZ2VQb3NpdGlvbigpXG4gICAgICB9XSxcbiAgICAgICdtYXNrLWltYWdlLWwtZnJvbS1jb2xvcic6IFt7XG4gICAgICAgICdtYXNrLWwtZnJvbSc6IHNjYWxlQ29sb3IoKVxuICAgICAgfV0sXG4gICAgICAnbWFzay1pbWFnZS1sLXRvLWNvbG9yJzogW3tcbiAgICAgICAgJ21hc2stbC10byc6IHNjYWxlQ29sb3IoKVxuICAgICAgfV0sXG4gICAgICAnbWFzay1pbWFnZS14LWZyb20tcG9zJzogW3tcbiAgICAgICAgJ21hc2steC1mcm9tJzogc2NhbGVNYXNrSW1hZ2VQb3NpdGlvbigpXG4gICAgICB9XSxcbiAgICAgICdtYXNrLWltYWdlLXgtdG8tcG9zJzogW3tcbiAgICAgICAgJ21hc2steC10byc6IHNjYWxlTWFza0ltYWdlUG9zaXRpb24oKVxuICAgICAgfV0sXG4gICAgICAnbWFzay1pbWFnZS14LWZyb20tY29sb3InOiBbe1xuICAgICAgICAnbWFzay14LWZyb20nOiBzY2FsZUNvbG9yKClcbiAgICAgIH1dLFxuICAgICAgJ21hc2staW1hZ2UteC10by1jb2xvcic6IFt7XG4gICAgICAgICdtYXNrLXgtdG8nOiBzY2FsZUNvbG9yKClcbiAgICAgIH1dLFxuICAgICAgJ21hc2staW1hZ2UteS1mcm9tLXBvcyc6IFt7XG4gICAgICAgICdtYXNrLXktZnJvbSc6IHNjYWxlTWFza0ltYWdlUG9zaXRpb24oKVxuICAgICAgfV0sXG4gICAgICAnbWFzay1pbWFnZS15LXRvLXBvcyc6IFt7XG4gICAgICAgICdtYXNrLXktdG8nOiBzY2FsZU1hc2tJbWFnZVBvc2l0aW9uKClcbiAgICAgIH1dLFxuICAgICAgJ21hc2staW1hZ2UteS1mcm9tLWNvbG9yJzogW3tcbiAgICAgICAgJ21hc2steS1mcm9tJzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgICdtYXNrLWltYWdlLXktdG8tY29sb3InOiBbe1xuICAgICAgICAnbWFzay15LXRvJzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgICdtYXNrLWltYWdlLXJhZGlhbCc6IFt7XG4gICAgICAgICdtYXNrLXJhZGlhbCc6IFtpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXVxuICAgICAgfV0sXG4gICAgICAnbWFzay1pbWFnZS1yYWRpYWwtZnJvbS1wb3MnOiBbe1xuICAgICAgICAnbWFzay1yYWRpYWwtZnJvbSc6IHNjYWxlTWFza0ltYWdlUG9zaXRpb24oKVxuICAgICAgfV0sXG4gICAgICAnbWFzay1pbWFnZS1yYWRpYWwtdG8tcG9zJzogW3tcbiAgICAgICAgJ21hc2stcmFkaWFsLXRvJzogc2NhbGVNYXNrSW1hZ2VQb3NpdGlvbigpXG4gICAgICB9XSxcbiAgICAgICdtYXNrLWltYWdlLXJhZGlhbC1mcm9tLWNvbG9yJzogW3tcbiAgICAgICAgJ21hc2stcmFkaWFsLWZyb20nOiBzY2FsZUNvbG9yKClcbiAgICAgIH1dLFxuICAgICAgJ21hc2staW1hZ2UtcmFkaWFsLXRvLWNvbG9yJzogW3tcbiAgICAgICAgJ21hc2stcmFkaWFsLXRvJzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgICdtYXNrLWltYWdlLXJhZGlhbC1zaGFwZSc6IFt7XG4gICAgICAgICdtYXNrLXJhZGlhbCc6IFsnY2lyY2xlJywgJ2VsbGlwc2UnXVxuICAgICAgfV0sXG4gICAgICAnbWFzay1pbWFnZS1yYWRpYWwtc2l6ZSc6IFt7XG4gICAgICAgICdtYXNrLXJhZGlhbCc6IFt7XG4gICAgICAgICAgY2xvc2VzdDogWydzaWRlJywgJ2Nvcm5lciddLFxuICAgICAgICAgIGZhcnRoZXN0OiBbJ3NpZGUnLCAnY29ybmVyJ11cbiAgICAgICAgfV1cbiAgICAgIH1dLFxuICAgICAgJ21hc2staW1hZ2UtcmFkaWFsLXBvcyc6IFt7XG4gICAgICAgICdtYXNrLXJhZGlhbC1hdCc6IHNjYWxlUG9zaXRpb24oKVxuICAgICAgfV0sXG4gICAgICAnbWFzay1pbWFnZS1jb25pYy1wb3MnOiBbe1xuICAgICAgICAnbWFzay1jb25pYyc6IFtpc051bWJlcl1cbiAgICAgIH1dLFxuICAgICAgJ21hc2staW1hZ2UtY29uaWMtZnJvbS1wb3MnOiBbe1xuICAgICAgICAnbWFzay1jb25pYy1mcm9tJzogc2NhbGVNYXNrSW1hZ2VQb3NpdGlvbigpXG4gICAgICB9XSxcbiAgICAgICdtYXNrLWltYWdlLWNvbmljLXRvLXBvcyc6IFt7XG4gICAgICAgICdtYXNrLWNvbmljLXRvJzogc2NhbGVNYXNrSW1hZ2VQb3NpdGlvbigpXG4gICAgICB9XSxcbiAgICAgICdtYXNrLWltYWdlLWNvbmljLWZyb20tY29sb3InOiBbe1xuICAgICAgICAnbWFzay1jb25pYy1mcm9tJzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgICdtYXNrLWltYWdlLWNvbmljLXRvLWNvbG9yJzogW3tcbiAgICAgICAgJ21hc2stY29uaWMtdG8nOiBzY2FsZUNvbG9yKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBNYXNrIE1vZGVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9tYXNrLW1vZGVcbiAgICAgICAqL1xuICAgICAgJ21hc2stbW9kZSc6IFt7XG4gICAgICAgIG1hc2s6IFsnYWxwaGEnLCAnbHVtaW5hbmNlJywgJ21hdGNoJ11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBNYXNrIE9yaWdpblxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL21hc2stb3JpZ2luXG4gICAgICAgKi9cbiAgICAgICdtYXNrLW9yaWdpbic6IFt7XG4gICAgICAgICdtYXNrLW9yaWdpbic6IFsnYm9yZGVyJywgJ3BhZGRpbmcnLCAnY29udGVudCcsICdmaWxsJywgJ3N0cm9rZScsICd2aWV3J11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBNYXNrIFBvc2l0aW9uXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvbWFzay1wb3NpdGlvblxuICAgICAgICovXG4gICAgICAnbWFzay1wb3NpdGlvbic6IFt7XG4gICAgICAgIG1hc2s6IHNjYWxlQmdQb3NpdGlvbigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogTWFzayBSZXBlYXRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9tYXNrLXJlcGVhdFxuICAgICAgICovXG4gICAgICAnbWFzay1yZXBlYXQnOiBbe1xuICAgICAgICBtYXNrOiBzY2FsZUJnUmVwZWF0KClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBNYXNrIFNpemVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9tYXNrLXNpemVcbiAgICAgICAqL1xuICAgICAgJ21hc2stc2l6ZSc6IFt7XG4gICAgICAgIG1hc2s6IHNjYWxlQmdTaXplKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBNYXNrIFR5cGVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9tYXNrLXR5cGVcbiAgICAgICAqL1xuICAgICAgJ21hc2stdHlwZSc6IFt7XG4gICAgICAgICdtYXNrLXR5cGUnOiBbJ2FscGhhJywgJ2x1bWluYW5jZSddXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogTWFzayBJbWFnZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL21hc2staW1hZ2VcbiAgICAgICAqL1xuICAgICAgJ21hc2staW1hZ2UnOiBbe1xuICAgICAgICBtYXNrOiBbJ25vbmUnLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXVxuICAgICAgfV0sXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIC0tLSBGaWx0ZXJzIC0tLVxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvKipcbiAgICAgICAqIEZpbHRlclxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2ZpbHRlclxuICAgICAgICovXG4gICAgICBmaWx0ZXI6IFt7XG4gICAgICAgIGZpbHRlcjogW1xuICAgICAgICAvLyBEZXByZWNhdGVkIHNpbmNlIFRhaWx3aW5kIENTUyB2My4wLjBcbiAgICAgICAgJycsICdub25lJywgaXNBcmJpdHJhcnlWYXJpYWJsZSwgaXNBcmJpdHJhcnlWYWx1ZV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCbHVyXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYmx1clxuICAgICAgICovXG4gICAgICBibHVyOiBbe1xuICAgICAgICBibHVyOiBzY2FsZUJsdXIoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJyaWdodG5lc3NcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9icmlnaHRuZXNzXG4gICAgICAgKi9cbiAgICAgIGJyaWdodG5lc3M6IFt7XG4gICAgICAgIGJyaWdodG5lc3M6IFtpc051bWJlciwgaXNBcmJpdHJhcnlWYXJpYWJsZSwgaXNBcmJpdHJhcnlWYWx1ZV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBDb250cmFzdFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2NvbnRyYXN0XG4gICAgICAgKi9cbiAgICAgIGNvbnRyYXN0OiBbe1xuICAgICAgICBjb250cmFzdDogW2lzTnVtYmVyLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIERyb3AgU2hhZG93XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvZHJvcC1zaGFkb3dcbiAgICAgICAqL1xuICAgICAgJ2Ryb3Atc2hhZG93JzogW3tcbiAgICAgICAgJ2Ryb3Atc2hhZG93JzogW1xuICAgICAgICAvLyBEZXByZWNhdGVkIHNpbmNlIFRhaWx3aW5kIENTUyB2NC4wLjBcbiAgICAgICAgJycsICdub25lJywgdGhlbWVEcm9wU2hhZG93LCBpc0FyYml0cmFyeVZhcmlhYmxlU2hhZG93LCBpc0FyYml0cmFyeVNoYWRvd11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBEcm9wIFNoYWRvdyBDb2xvclxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2ZpbHRlci1kcm9wLXNoYWRvdyNzZXR0aW5nLXRoZS1zaGFkb3ctY29sb3JcbiAgICAgICAqL1xuICAgICAgJ2Ryb3Atc2hhZG93LWNvbG9yJzogW3tcbiAgICAgICAgJ2Ryb3Atc2hhZG93Jzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogR3JheXNjYWxlXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvZ3JheXNjYWxlXG4gICAgICAgKi9cbiAgICAgIGdyYXlzY2FsZTogW3tcbiAgICAgICAgZ3JheXNjYWxlOiBbJycsIGlzTnVtYmVyLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEh1ZSBSb3RhdGVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9odWUtcm90YXRlXG4gICAgICAgKi9cbiAgICAgICdodWUtcm90YXRlJzogW3tcbiAgICAgICAgJ2h1ZS1yb3RhdGUnOiBbaXNOdW1iZXIsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogSW52ZXJ0XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvaW52ZXJ0XG4gICAgICAgKi9cbiAgICAgIGludmVydDogW3tcbiAgICAgICAgaW52ZXJ0OiBbJycsIGlzTnVtYmVyLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFNhdHVyYXRlXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvc2F0dXJhdGVcbiAgICAgICAqL1xuICAgICAgc2F0dXJhdGU6IFt7XG4gICAgICAgIHNhdHVyYXRlOiBbaXNOdW1iZXIsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogU2VwaWFcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9zZXBpYVxuICAgICAgICovXG4gICAgICBzZXBpYTogW3tcbiAgICAgICAgc2VwaWE6IFsnJywgaXNOdW1iZXIsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQmFja2Ryb3AgRmlsdGVyXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYmFja2Ryb3AtZmlsdGVyXG4gICAgICAgKi9cbiAgICAgICdiYWNrZHJvcC1maWx0ZXInOiBbe1xuICAgICAgICAnYmFja2Ryb3AtZmlsdGVyJzogW1xuICAgICAgICAvLyBEZXByZWNhdGVkIHNpbmNlIFRhaWx3aW5kIENTUyB2My4wLjBcbiAgICAgICAgJycsICdub25lJywgaXNBcmJpdHJhcnlWYXJpYWJsZSwgaXNBcmJpdHJhcnlWYWx1ZV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCYWNrZHJvcCBCbHVyXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYmFja2Ryb3AtYmx1clxuICAgICAgICovXG4gICAgICAnYmFja2Ryb3AtYmx1cic6IFt7XG4gICAgICAgICdiYWNrZHJvcC1ibHVyJzogc2NhbGVCbHVyKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCYWNrZHJvcCBCcmlnaHRuZXNzXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYmFja2Ryb3AtYnJpZ2h0bmVzc1xuICAgICAgICovXG4gICAgICAnYmFja2Ryb3AtYnJpZ2h0bmVzcyc6IFt7XG4gICAgICAgICdiYWNrZHJvcC1icmlnaHRuZXNzJzogW2lzTnVtYmVyLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJhY2tkcm9wIENvbnRyYXN0XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYmFja2Ryb3AtY29udHJhc3RcbiAgICAgICAqL1xuICAgICAgJ2JhY2tkcm9wLWNvbnRyYXN0JzogW3tcbiAgICAgICAgJ2JhY2tkcm9wLWNvbnRyYXN0JzogW2lzTnVtYmVyLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJhY2tkcm9wIEdyYXlzY2FsZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JhY2tkcm9wLWdyYXlzY2FsZVxuICAgICAgICovXG4gICAgICAnYmFja2Ryb3AtZ3JheXNjYWxlJzogW3tcbiAgICAgICAgJ2JhY2tkcm9wLWdyYXlzY2FsZSc6IFsnJywgaXNOdW1iZXIsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQmFja2Ryb3AgSHVlIFJvdGF0ZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JhY2tkcm9wLWh1ZS1yb3RhdGVcbiAgICAgICAqL1xuICAgICAgJ2JhY2tkcm9wLWh1ZS1yb3RhdGUnOiBbe1xuICAgICAgICAnYmFja2Ryb3AtaHVlLXJvdGF0ZSc6IFtpc051bWJlciwgaXNBcmJpdHJhcnlWYXJpYWJsZSwgaXNBcmJpdHJhcnlWYWx1ZV1cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCYWNrZHJvcCBJbnZlcnRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9iYWNrZHJvcC1pbnZlcnRcbiAgICAgICAqL1xuICAgICAgJ2JhY2tkcm9wLWludmVydCc6IFt7XG4gICAgICAgICdiYWNrZHJvcC1pbnZlcnQnOiBbJycsIGlzTnVtYmVyLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEJhY2tkcm9wIE9wYWNpdHlcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9iYWNrZHJvcC1vcGFjaXR5XG4gICAgICAgKi9cbiAgICAgICdiYWNrZHJvcC1vcGFjaXR5JzogW3tcbiAgICAgICAgJ2JhY2tkcm9wLW9wYWNpdHknOiBbaXNOdW1iZXIsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQmFja2Ryb3AgU2F0dXJhdGVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9iYWNrZHJvcC1zYXR1cmF0ZVxuICAgICAgICovXG4gICAgICAnYmFja2Ryb3Atc2F0dXJhdGUnOiBbe1xuICAgICAgICAnYmFja2Ryb3Atc2F0dXJhdGUnOiBbaXNOdW1iZXIsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQmFja2Ryb3AgU2VwaWFcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9iYWNrZHJvcC1zZXBpYVxuICAgICAgICovXG4gICAgICAnYmFja2Ryb3Atc2VwaWEnOiBbe1xuICAgICAgICAnYmFja2Ryb3Atc2VwaWEnOiBbJycsIGlzTnVtYmVyLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXVxuICAgICAgfV0sXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gLS0tIFRhYmxlcyAtLS1cbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tXG4gICAgICAvKipcbiAgICAgICAqIEJvcmRlciBDb2xsYXBzZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JvcmRlci1jb2xsYXBzZVxuICAgICAgICovXG4gICAgICAnYm9yZGVyLWNvbGxhcHNlJzogW3tcbiAgICAgICAgYm9yZGVyOiBbJ2NvbGxhcHNlJywgJ3NlcGFyYXRlJ11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3JkZXIgU3BhY2luZ1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JvcmRlci1zcGFjaW5nXG4gICAgICAgKi9cbiAgICAgICdib3JkZXItc3BhY2luZyc6IFt7XG4gICAgICAgICdib3JkZXItc3BhY2luZyc6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3JkZXIgU3BhY2luZyBYXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYm9yZGVyLXNwYWNpbmdcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci1zcGFjaW5nLXgnOiBbe1xuICAgICAgICAnYm9yZGVyLXNwYWNpbmcteCc6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBCb3JkZXIgU3BhY2luZyBZXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYm9yZGVyLXNwYWNpbmdcbiAgICAgICAqL1xuICAgICAgJ2JvcmRlci1zcGFjaW5nLXknOiBbe1xuICAgICAgICAnYm9yZGVyLXNwYWNpbmcteSc6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBUYWJsZSBMYXlvdXRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90YWJsZS1sYXlvdXRcbiAgICAgICAqL1xuICAgICAgJ3RhYmxlLWxheW91dCc6IFt7XG4gICAgICAgIHRhYmxlOiBbJ2F1dG8nLCAnZml4ZWQnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIENhcHRpb24gU2lkZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2NhcHRpb24tc2lkZVxuICAgICAgICovXG4gICAgICBjYXB0aW9uOiBbe1xuICAgICAgICBjYXB0aW9uOiBbJ3RvcCcsICdib3R0b20nXVxuICAgICAgfV0sXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIC0tLSBUcmFuc2l0aW9ucyBhbmQgQW5pbWF0aW9uIC0tLVxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvKipcbiAgICAgICAqIFRyYW5zaXRpb24gUHJvcGVydHlcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90cmFuc2l0aW9uLXByb3BlcnR5XG4gICAgICAgKi9cbiAgICAgIHRyYW5zaXRpb246IFt7XG4gICAgICAgIHRyYW5zaXRpb246IFsnJywgJ2FsbCcsICdjb2xvcnMnLCAnb3BhY2l0eScsICdzaGFkb3cnLCAndHJhbnNmb3JtJywgJ25vbmUnLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFRyYW5zaXRpb24gQmVoYXZpb3JcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90cmFuc2l0aW9uLWJlaGF2aW9yXG4gICAgICAgKi9cbiAgICAgICd0cmFuc2l0aW9uLWJlaGF2aW9yJzogW3tcbiAgICAgICAgdHJhbnNpdGlvbjogWydub3JtYWwnLCAnZGlzY3JldGUnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFRyYW5zaXRpb24gRHVyYXRpb25cbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90cmFuc2l0aW9uLWR1cmF0aW9uXG4gICAgICAgKi9cbiAgICAgIGR1cmF0aW9uOiBbe1xuICAgICAgICBkdXJhdGlvbjogW2lzTnVtYmVyLCAnaW5pdGlhbCcsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogVHJhbnNpdGlvbiBUaW1pbmcgRnVuY3Rpb25cbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90cmFuc2l0aW9uLXRpbWluZy1mdW5jdGlvblxuICAgICAgICovXG4gICAgICBlYXNlOiBbe1xuICAgICAgICBlYXNlOiBbJ2xpbmVhcicsICdpbml0aWFsJywgdGhlbWVFYXNlLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFRyYW5zaXRpb24gRGVsYXlcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90cmFuc2l0aW9uLWRlbGF5XG4gICAgICAgKi9cbiAgICAgIGRlbGF5OiBbe1xuICAgICAgICBkZWxheTogW2lzTnVtYmVyLCBpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEFuaW1hdGlvblxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2FuaW1hdGlvblxuICAgICAgICovXG4gICAgICBhbmltYXRlOiBbe1xuICAgICAgICBhbmltYXRlOiBbJ25vbmUnLCB0aGVtZUFuaW1hdGUsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gLS0tIFRyYW5zZm9ybXMgLS0tXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8qKlxuICAgICAgICogQmFja2ZhY2UgVmlzaWJpbGl0eVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2JhY2tmYWNlLXZpc2liaWxpdHlcbiAgICAgICAqL1xuICAgICAgYmFja2ZhY2U6IFt7XG4gICAgICAgIGJhY2tmYWNlOiBbJ2hpZGRlbicsICd2aXNpYmxlJ11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBQZXJzcGVjdGl2ZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3BlcnNwZWN0aXZlXG4gICAgICAgKi9cbiAgICAgIHBlcnNwZWN0aXZlOiBbe1xuICAgICAgICBwZXJzcGVjdGl2ZTogW3RoZW1lUGVyc3BlY3RpdmUsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogUGVyc3BlY3RpdmUgT3JpZ2luXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvcGVyc3BlY3RpdmUtb3JpZ2luXG4gICAgICAgKi9cbiAgICAgICdwZXJzcGVjdGl2ZS1vcmlnaW4nOiBbe1xuICAgICAgICAncGVyc3BlY3RpdmUtb3JpZ2luJzogc2NhbGVQb3NpdGlvbldpdGhBcmJpdHJhcnkoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFJvdGF0ZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3JvdGF0ZVxuICAgICAgICovXG4gICAgICByb3RhdGU6IFt7XG4gICAgICAgIHJvdGF0ZTogc2NhbGVSb3RhdGUoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFJvdGF0ZSBYXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvcm90YXRlXG4gICAgICAgKi9cbiAgICAgICdyb3RhdGUteCc6IFt7XG4gICAgICAgICdyb3RhdGUteCc6IHNjYWxlUm90YXRlKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBSb3RhdGUgWVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3JvdGF0ZVxuICAgICAgICovXG4gICAgICAncm90YXRlLXknOiBbe1xuICAgICAgICAncm90YXRlLXknOiBzY2FsZVJvdGF0ZSgpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogUm90YXRlIFpcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9yb3RhdGVcbiAgICAgICAqL1xuICAgICAgJ3JvdGF0ZS16JzogW3tcbiAgICAgICAgJ3JvdGF0ZS16Jzogc2NhbGVSb3RhdGUoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFNjYWxlXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvc2NhbGVcbiAgICAgICAqL1xuICAgICAgc2NhbGU6IFt7XG4gICAgICAgIHNjYWxlOiBzY2FsZVNjYWxlKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTY2FsZSBYXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvc2NhbGVcbiAgICAgICAqL1xuICAgICAgJ3NjYWxlLXgnOiBbe1xuICAgICAgICAnc2NhbGUteCc6IHNjYWxlU2NhbGUoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFNjYWxlIFlcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9zY2FsZVxuICAgICAgICovXG4gICAgICAnc2NhbGUteSc6IFt7XG4gICAgICAgICdzY2FsZS15Jzogc2NhbGVTY2FsZSgpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogU2NhbGUgWlxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3NjYWxlXG4gICAgICAgKi9cbiAgICAgICdzY2FsZS16JzogW3tcbiAgICAgICAgJ3NjYWxlLXonOiBzY2FsZVNjYWxlKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTY2FsZSAzRFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3NjYWxlXG4gICAgICAgKi9cbiAgICAgICdzY2FsZS0zZCc6IFsnc2NhbGUtM2QnXSxcbiAgICAgIC8qKlxuICAgICAgICogU2tld1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3NrZXdcbiAgICAgICAqL1xuICAgICAgc2tldzogW3tcbiAgICAgICAgc2tldzogc2NhbGVTa2V3KClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTa2V3IFhcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9za2V3XG4gICAgICAgKi9cbiAgICAgICdza2V3LXgnOiBbe1xuICAgICAgICAnc2tldy14Jzogc2NhbGVTa2V3KClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTa2V3IFlcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9za2V3XG4gICAgICAgKi9cbiAgICAgICdza2V3LXknOiBbe1xuICAgICAgICAnc2tldy15Jzogc2NhbGVTa2V3KClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBUcmFuc2Zvcm1cbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90cmFuc2Zvcm1cbiAgICAgICAqL1xuICAgICAgdHJhbnNmb3JtOiBbe1xuICAgICAgICB0cmFuc2Zvcm06IFtpc0FyYml0cmFyeVZhcmlhYmxlLCBpc0FyYml0cmFyeVZhbHVlLCAnJywgJ25vbmUnLCAnZ3B1JywgJ2NwdSddXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogVHJhbnNmb3JtIE9yaWdpblxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3RyYW5zZm9ybS1vcmlnaW5cbiAgICAgICAqL1xuICAgICAgJ3RyYW5zZm9ybS1vcmlnaW4nOiBbe1xuICAgICAgICBvcmlnaW46IHNjYWxlUG9zaXRpb25XaXRoQXJiaXRyYXJ5KClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBUcmFuc2Zvcm0gU3R5bGVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90cmFuc2Zvcm0tc3R5bGVcbiAgICAgICAqL1xuICAgICAgJ3RyYW5zZm9ybS1zdHlsZSc6IFt7XG4gICAgICAgIHRyYW5zZm9ybTogWyczZCcsICdmbGF0J11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBUcmFuc2xhdGVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90cmFuc2xhdGVcbiAgICAgICAqL1xuICAgICAgdHJhbnNsYXRlOiBbe1xuICAgICAgICB0cmFuc2xhdGU6IHNjYWxlVHJhbnNsYXRlKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBUcmFuc2xhdGUgWFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3RyYW5zbGF0ZVxuICAgICAgICovXG4gICAgICAndHJhbnNsYXRlLXgnOiBbe1xuICAgICAgICAndHJhbnNsYXRlLXgnOiBzY2FsZVRyYW5zbGF0ZSgpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogVHJhbnNsYXRlIFlcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90cmFuc2xhdGVcbiAgICAgICAqL1xuICAgICAgJ3RyYW5zbGF0ZS15JzogW3tcbiAgICAgICAgJ3RyYW5zbGF0ZS15Jzogc2NhbGVUcmFuc2xhdGUoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFRyYW5zbGF0ZSBaXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvdHJhbnNsYXRlXG4gICAgICAgKi9cbiAgICAgICd0cmFuc2xhdGUteic6IFt7XG4gICAgICAgICd0cmFuc2xhdGUteic6IHNjYWxlVHJhbnNsYXRlKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBUcmFuc2xhdGUgTm9uZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3RyYW5zbGF0ZVxuICAgICAgICovXG4gICAgICAndHJhbnNsYXRlLW5vbmUnOiBbJ3RyYW5zbGF0ZS1ub25lJ10sXG4gICAgICAvKipcbiAgICAgICAqIFpvb21cbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy96b29tXG4gICAgICAgKi9cbiAgICAgIHpvb206IFt7XG4gICAgICAgIHpvb206IFtpc0ludGVnZXIsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAgICAgLy8gLS0tIEludGVyYWN0aXZpdHkgLS0tXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8qKlxuICAgICAgICogQWNjZW50IENvbG9yXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYWNjZW50LWNvbG9yXG4gICAgICAgKi9cbiAgICAgIGFjY2VudDogW3tcbiAgICAgICAgYWNjZW50OiBzY2FsZUNvbG9yKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBBcHBlYXJhbmNlXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvYXBwZWFyYW5jZVxuICAgICAgICovXG4gICAgICBhcHBlYXJhbmNlOiBbe1xuICAgICAgICBhcHBlYXJhbmNlOiBbJ25vbmUnLCAnYXV0byddXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogQ2FyZXQgQ29sb3JcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9qdXN0LWluLXRpbWUtbW9kZSNjYXJldC1jb2xvci11dGlsaXRpZXNcbiAgICAgICAqL1xuICAgICAgJ2NhcmV0LWNvbG9yJzogW3tcbiAgICAgICAgY2FyZXQ6IHNjYWxlQ29sb3IoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIENvbG9yIFNjaGVtZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2NvbG9yLXNjaGVtZVxuICAgICAgICovXG4gICAgICAnY29sb3Itc2NoZW1lJzogW3tcbiAgICAgICAgc2NoZW1lOiBbJ25vcm1hbCcsICdkYXJrJywgJ2xpZ2h0JywgJ2xpZ2h0LWRhcmsnLCAnb25seS1kYXJrJywgJ29ubHktbGlnaHQnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIEN1cnNvclxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2N1cnNvclxuICAgICAgICovXG4gICAgICBjdXJzb3I6IFt7XG4gICAgICAgIGN1cnNvcjogWydhdXRvJywgJ2RlZmF1bHQnLCAncG9pbnRlcicsICd3YWl0JywgJ3RleHQnLCAnbW92ZScsICdoZWxwJywgJ25vdC1hbGxvd2VkJywgJ25vbmUnLCAnY29udGV4dC1tZW51JywgJ3Byb2dyZXNzJywgJ2NlbGwnLCAnY3Jvc3NoYWlyJywgJ3ZlcnRpY2FsLXRleHQnLCAnYWxpYXMnLCAnY29weScsICduby1kcm9wJywgJ2dyYWInLCAnZ3JhYmJpbmcnLCAnYWxsLXNjcm9sbCcsICdjb2wtcmVzaXplJywgJ3Jvdy1yZXNpemUnLCAnbi1yZXNpemUnLCAnZS1yZXNpemUnLCAncy1yZXNpemUnLCAndy1yZXNpemUnLCAnbmUtcmVzaXplJywgJ253LXJlc2l6ZScsICdzZS1yZXNpemUnLCAnc3ctcmVzaXplJywgJ2V3LXJlc2l6ZScsICducy1yZXNpemUnLCAnbmVzdy1yZXNpemUnLCAnbndzZS1yZXNpemUnLCAnem9vbS1pbicsICd6b29tLW91dCcsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogRmllbGQgU2l6aW5nXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvZmllbGQtc2l6aW5nXG4gICAgICAgKi9cbiAgICAgICdmaWVsZC1zaXppbmcnOiBbe1xuICAgICAgICAnZmllbGQtc2l6aW5nJzogWydmaXhlZCcsICdjb250ZW50J11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBQb2ludGVyIEV2ZW50c1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3BvaW50ZXItZXZlbnRzXG4gICAgICAgKi9cbiAgICAgICdwb2ludGVyLWV2ZW50cyc6IFt7XG4gICAgICAgICdwb2ludGVyLWV2ZW50cyc6IFsnYXV0bycsICdub25lJ11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBSZXNpemVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9yZXNpemVcbiAgICAgICAqL1xuICAgICAgcmVzaXplOiBbe1xuICAgICAgICByZXNpemU6IFsnbm9uZScsICcnLCAneScsICd4J11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTY3JvbGwgQmVoYXZpb3JcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9zY3JvbGwtYmVoYXZpb3JcbiAgICAgICAqL1xuICAgICAgJ3Njcm9sbC1iZWhhdmlvcic6IFt7XG4gICAgICAgIHNjcm9sbDogWydhdXRvJywgJ3Ntb290aCddXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogU2Nyb2xsYmFyIFRodW1iIENvbG9yXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvc2Nyb2xsYmFyLWNvbG9yXG4gICAgICAgKi9cbiAgICAgICdzY3JvbGxiYXItdGh1bWItY29sb3InOiBbe1xuICAgICAgICAnc2Nyb2xsYmFyLXRodW1iJzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogU2Nyb2xsYmFyIFRyYWNrIENvbG9yXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvc2Nyb2xsYmFyLWNvbG9yXG4gICAgICAgKi9cbiAgICAgICdzY3JvbGxiYXItdHJhY2stY29sb3InOiBbe1xuICAgICAgICAnc2Nyb2xsYmFyLXRyYWNrJzogc2NhbGVDb2xvcigpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogU2Nyb2xsYmFyIEd1dHRlclxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3Njcm9sbGJhci1ndXR0ZXJcbiAgICAgICAqL1xuICAgICAgJ3Njcm9sbGJhci1ndXR0ZXInOiBbe1xuICAgICAgICAnc2Nyb2xsYmFyLWd1dHRlcic6IFsnYXV0bycsICdzdGFibGUnLCAnYm90aCddXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogU2Nyb2xsYmFyIFdpZHRoXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvc2Nyb2xsYmFyLXdpZHRoXG4gICAgICAgKi9cbiAgICAgICdzY3JvbGxiYXItdyc6IFt7XG4gICAgICAgIHNjcm9sbGJhcjogWydhdXRvJywgJ3RoaW4nLCAnbm9uZSddXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogU2Nyb2xsIE1hcmdpblxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3Njcm9sbC1tYXJnaW5cbiAgICAgICAqL1xuICAgICAgJ3Njcm9sbC1tJzogW3tcbiAgICAgICAgJ3Njcm9sbC1tJzogc2NhbGVVbmFtYmlndW91c1NwYWNpbmcoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFNjcm9sbCBNYXJnaW4gSW5saW5lXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvc2Nyb2xsLW1hcmdpblxuICAgICAgICovXG4gICAgICAnc2Nyb2xsLW14JzogW3tcbiAgICAgICAgJ3Njcm9sbC1teCc6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTY3JvbGwgTWFyZ2luIEJsb2NrXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvc2Nyb2xsLW1hcmdpblxuICAgICAgICovXG4gICAgICAnc2Nyb2xsLW15JzogW3tcbiAgICAgICAgJ3Njcm9sbC1teSc6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTY3JvbGwgTWFyZ2luIElubGluZSBTdGFydFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3Njcm9sbC1tYXJnaW5cbiAgICAgICAqL1xuICAgICAgJ3Njcm9sbC1tcyc6IFt7XG4gICAgICAgICdzY3JvbGwtbXMnOiBzY2FsZVVuYW1iaWd1b3VzU3BhY2luZygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogU2Nyb2xsIE1hcmdpbiBJbmxpbmUgRW5kXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvc2Nyb2xsLW1hcmdpblxuICAgICAgICovXG4gICAgICAnc2Nyb2xsLW1lJzogW3tcbiAgICAgICAgJ3Njcm9sbC1tZSc6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTY3JvbGwgTWFyZ2luIEJsb2NrIFN0YXJ0XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvc2Nyb2xsLW1hcmdpblxuICAgICAgICovXG4gICAgICAnc2Nyb2xsLW1icyc6IFt7XG4gICAgICAgICdzY3JvbGwtbWJzJzogc2NhbGVVbmFtYmlndW91c1NwYWNpbmcoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFNjcm9sbCBNYXJnaW4gQmxvY2sgRW5kXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvc2Nyb2xsLW1hcmdpblxuICAgICAgICovXG4gICAgICAnc2Nyb2xsLW1iZSc6IFt7XG4gICAgICAgICdzY3JvbGwtbWJlJzogc2NhbGVVbmFtYmlndW91c1NwYWNpbmcoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFNjcm9sbCBNYXJnaW4gVG9wXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvc2Nyb2xsLW1hcmdpblxuICAgICAgICovXG4gICAgICAnc2Nyb2xsLW10JzogW3tcbiAgICAgICAgJ3Njcm9sbC1tdCc6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTY3JvbGwgTWFyZ2luIFJpZ2h0XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvc2Nyb2xsLW1hcmdpblxuICAgICAgICovXG4gICAgICAnc2Nyb2xsLW1yJzogW3tcbiAgICAgICAgJ3Njcm9sbC1tcic6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTY3JvbGwgTWFyZ2luIEJvdHRvbVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3Njcm9sbC1tYXJnaW5cbiAgICAgICAqL1xuICAgICAgJ3Njcm9sbC1tYic6IFt7XG4gICAgICAgICdzY3JvbGwtbWInOiBzY2FsZVVuYW1iaWd1b3VzU3BhY2luZygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogU2Nyb2xsIE1hcmdpbiBMZWZ0XG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvc2Nyb2xsLW1hcmdpblxuICAgICAgICovXG4gICAgICAnc2Nyb2xsLW1sJzogW3tcbiAgICAgICAgJ3Njcm9sbC1tbCc6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTY3JvbGwgUGFkZGluZ1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3Njcm9sbC1wYWRkaW5nXG4gICAgICAgKi9cbiAgICAgICdzY3JvbGwtcCc6IFt7XG4gICAgICAgICdzY3JvbGwtcCc6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTY3JvbGwgUGFkZGluZyBJbmxpbmVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9zY3JvbGwtcGFkZGluZ1xuICAgICAgICovXG4gICAgICAnc2Nyb2xsLXB4JzogW3tcbiAgICAgICAgJ3Njcm9sbC1weCc6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTY3JvbGwgUGFkZGluZyBCbG9ja1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3Njcm9sbC1wYWRkaW5nXG4gICAgICAgKi9cbiAgICAgICdzY3JvbGwtcHknOiBbe1xuICAgICAgICAnc2Nyb2xsLXB5Jzogc2NhbGVVbmFtYmlndW91c1NwYWNpbmcoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFNjcm9sbCBQYWRkaW5nIElubGluZSBTdGFydFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3Njcm9sbC1wYWRkaW5nXG4gICAgICAgKi9cbiAgICAgICdzY3JvbGwtcHMnOiBbe1xuICAgICAgICAnc2Nyb2xsLXBzJzogc2NhbGVVbmFtYmlndW91c1NwYWNpbmcoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFNjcm9sbCBQYWRkaW5nIElubGluZSBFbmRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9zY3JvbGwtcGFkZGluZ1xuICAgICAgICovXG4gICAgICAnc2Nyb2xsLXBlJzogW3tcbiAgICAgICAgJ3Njcm9sbC1wZSc6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTY3JvbGwgUGFkZGluZyBCbG9jayBTdGFydFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3Njcm9sbC1wYWRkaW5nXG4gICAgICAgKi9cbiAgICAgICdzY3JvbGwtcGJzJzogW3tcbiAgICAgICAgJ3Njcm9sbC1wYnMnOiBzY2FsZVVuYW1iaWd1b3VzU3BhY2luZygpXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogU2Nyb2xsIFBhZGRpbmcgQmxvY2sgRW5kXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3Mvc2Nyb2xsLXBhZGRpbmdcbiAgICAgICAqL1xuICAgICAgJ3Njcm9sbC1wYmUnOiBbe1xuICAgICAgICAnc2Nyb2xsLXBiZSc6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTY3JvbGwgUGFkZGluZyBUb3BcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9zY3JvbGwtcGFkZGluZ1xuICAgICAgICovXG4gICAgICAnc2Nyb2xsLXB0JzogW3tcbiAgICAgICAgJ3Njcm9sbC1wdCc6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTY3JvbGwgUGFkZGluZyBSaWdodFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3Njcm9sbC1wYWRkaW5nXG4gICAgICAgKi9cbiAgICAgICdzY3JvbGwtcHInOiBbe1xuICAgICAgICAnc2Nyb2xsLXByJzogc2NhbGVVbmFtYmlndW91c1NwYWNpbmcoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFNjcm9sbCBQYWRkaW5nIEJvdHRvbVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3Njcm9sbC1wYWRkaW5nXG4gICAgICAgKi9cbiAgICAgICdzY3JvbGwtcGInOiBbe1xuICAgICAgICAnc2Nyb2xsLXBiJzogc2NhbGVVbmFtYmlndW91c1NwYWNpbmcoKVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFNjcm9sbCBQYWRkaW5nIExlZnRcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9zY3JvbGwtcGFkZGluZ1xuICAgICAgICovXG4gICAgICAnc2Nyb2xsLXBsJzogW3tcbiAgICAgICAgJ3Njcm9sbC1wbCc6IHNjYWxlVW5hbWJpZ3VvdXNTcGFjaW5nKClcbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBTY3JvbGwgU25hcCBBbGlnblxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3Njcm9sbC1zbmFwLWFsaWduXG4gICAgICAgKi9cbiAgICAgICdzbmFwLWFsaWduJzogW3tcbiAgICAgICAgc25hcDogWydzdGFydCcsICdlbmQnLCAnY2VudGVyJywgJ2FsaWduLW5vbmUnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFNjcm9sbCBTbmFwIFN0b3BcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9zY3JvbGwtc25hcC1zdG9wXG4gICAgICAgKi9cbiAgICAgICdzbmFwLXN0b3AnOiBbe1xuICAgICAgICBzbmFwOiBbJ25vcm1hbCcsICdhbHdheXMnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFNjcm9sbCBTbmFwIFR5cGVcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9zY3JvbGwtc25hcC10eXBlXG4gICAgICAgKi9cbiAgICAgICdzbmFwLXR5cGUnOiBbe1xuICAgICAgICBzbmFwOiBbJ25vbmUnLCAneCcsICd5JywgJ2JvdGgnXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFNjcm9sbCBTbmFwIFR5cGUgU3RyaWN0bmVzc1xuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3Njcm9sbC1zbmFwLXR5cGVcbiAgICAgICAqL1xuICAgICAgJ3NuYXAtc3RyaWN0bmVzcyc6IFt7XG4gICAgICAgIHNuYXA6IFsnbWFuZGF0b3J5JywgJ3Byb3hpbWl0eSddXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogVG91Y2ggQWN0aW9uXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvdG91Y2gtYWN0aW9uXG4gICAgICAgKi9cbiAgICAgIHRvdWNoOiBbe1xuICAgICAgICB0b3VjaDogWydhdXRvJywgJ25vbmUnLCAnbWFuaXB1bGF0aW9uJ11cbiAgICAgIH1dLFxuICAgICAgLyoqXG4gICAgICAgKiBUb3VjaCBBY3Rpb24gWFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3RvdWNoLWFjdGlvblxuICAgICAgICovXG4gICAgICAndG91Y2gteCc6IFt7XG4gICAgICAgICd0b3VjaC1wYW4nOiBbJ3gnLCAnbGVmdCcsICdyaWdodCddXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogVG91Y2ggQWN0aW9uIFlcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy90b3VjaC1hY3Rpb25cbiAgICAgICAqL1xuICAgICAgJ3RvdWNoLXknOiBbe1xuICAgICAgICAndG91Y2gtcGFuJzogWyd5JywgJ3VwJywgJ2Rvd24nXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFRvdWNoIEFjdGlvbiBQaW5jaCBab29tXG4gICAgICAgKiBAc2VlIGh0dHBzOi8vdGFpbHdpbmRjc3MuY29tL2RvY3MvdG91Y2gtYWN0aW9uXG4gICAgICAgKi9cbiAgICAgICd0b3VjaC1weic6IFsndG91Y2gtcGluY2gtem9vbSddLFxuICAgICAgLyoqXG4gICAgICAgKiBVc2VyIFNlbGVjdFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3VzZXItc2VsZWN0XG4gICAgICAgKi9cbiAgICAgIHNlbGVjdDogW3tcbiAgICAgICAgc2VsZWN0OiBbJ25vbmUnLCAndGV4dCcsICdhbGwnLCAnYXV0byddXG4gICAgICB9XSxcbiAgICAgIC8qKlxuICAgICAgICogV2lsbCBDaGFuZ2VcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy93aWxsLWNoYW5nZVxuICAgICAgICovXG4gICAgICAnd2lsbC1jaGFuZ2UnOiBbe1xuICAgICAgICAnd2lsbC1jaGFuZ2UnOiBbJ2F1dG8nLCAnc2Nyb2xsJywgJ2NvbnRlbnRzJywgJ3RyYW5zZm9ybScsIGlzQXJiaXRyYXJ5VmFyaWFibGUsIGlzQXJiaXRyYXJ5VmFsdWVdXG4gICAgICB9XSxcbiAgICAgIC8vIC0tLS0tLS0tLS0tXG4gICAgICAvLyAtLS0gU1ZHIC0tLVxuICAgICAgLy8gLS0tLS0tLS0tLS1cbiAgICAgIC8qKlxuICAgICAgICogRmlsbFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL2ZpbGxcbiAgICAgICAqL1xuICAgICAgZmlsbDogW3tcbiAgICAgICAgZmlsbDogWydub25lJywgLi4uc2NhbGVDb2xvcigpXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFN0cm9rZSBXaWR0aFxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3N0cm9rZS13aWR0aFxuICAgICAgICovXG4gICAgICAnc3Ryb2tlLXcnOiBbe1xuICAgICAgICBzdHJva2U6IFtpc051bWJlciwgaXNBcmJpdHJhcnlWYXJpYWJsZUxlbmd0aCwgaXNBcmJpdHJhcnlMZW5ndGgsIGlzQXJiaXRyYXJ5TnVtYmVyXVxuICAgICAgfV0sXG4gICAgICAvKipcbiAgICAgICAqIFN0cm9rZVxuICAgICAgICogQHNlZSBodHRwczovL3RhaWx3aW5kY3NzLmNvbS9kb2NzL3N0cm9rZVxuICAgICAgICovXG4gICAgICBzdHJva2U6IFt7XG4gICAgICAgIHN0cm9rZTogWydub25lJywgLi4uc2NhbGVDb2xvcigpXVxuICAgICAgfV0sXG4gICAgICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgICAgIC8vIC0tLSBBY2Nlc3NpYmlsaXR5IC0tLVxuICAgICAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gICAgICAvKipcbiAgICAgICAqIEZvcmNlZCBDb2xvciBBZGp1c3RcbiAgICAgICAqIEBzZWUgaHR0cHM6Ly90YWlsd2luZGNzcy5jb20vZG9jcy9mb3JjZWQtY29sb3ItYWRqdXN0XG4gICAgICAgKi9cbiAgICAgICdmb3JjZWQtY29sb3ItYWRqdXN0JzogW3tcbiAgICAgICAgJ2ZvcmNlZC1jb2xvci1hZGp1c3QnOiBbJ2F1dG8nLCAnbm9uZSddXG4gICAgICB9XVxuICAgIH0sXG4gICAgY29uZmxpY3RpbmdDbGFzc0dyb3Vwczoge1xuICAgICAgJ2NvbnRhaW5lci1uYW1lZCc6IFsnY29udGFpbmVyLXR5cGUnXSxcbiAgICAgIG92ZXJmbG93OiBbJ292ZXJmbG93LXgnLCAnb3ZlcmZsb3cteSddLFxuICAgICAgb3ZlcnNjcm9sbDogWydvdmVyc2Nyb2xsLXgnLCAnb3ZlcnNjcm9sbC15J10sXG4gICAgICBpbnNldDogWydpbnNldC14JywgJ2luc2V0LXknLCAnaW5zZXQtYnMnLCAnaW5zZXQtYmUnLCAnc3RhcnQnLCAnZW5kJywgJ3RvcCcsICdyaWdodCcsICdib3R0b20nLCAnbGVmdCddLFxuICAgICAgJ2luc2V0LXgnOiBbJ3JpZ2h0JywgJ2xlZnQnXSxcbiAgICAgICdpbnNldC15JzogWyd0b3AnLCAnYm90dG9tJ10sXG4gICAgICBmbGV4OiBbJ2Jhc2lzJywgJ2dyb3cnLCAnc2hyaW5rJ10sXG4gICAgICBnYXA6IFsnZ2FwLXgnLCAnZ2FwLXknXSxcbiAgICAgIHA6IFsncHgnLCAncHknLCAncHMnLCAncGUnLCAncGJzJywgJ3BiZScsICdwdCcsICdwcicsICdwYicsICdwbCddLFxuICAgICAgcHg6IFsncHInLCAncGwnXSxcbiAgICAgIHB5OiBbJ3B0JywgJ3BiJ10sXG4gICAgICBtOiBbJ214JywgJ215JywgJ21zJywgJ21lJywgJ21icycsICdtYmUnLCAnbXQnLCAnbXInLCAnbWInLCAnbWwnXSxcbiAgICAgIG14OiBbJ21yJywgJ21sJ10sXG4gICAgICBteTogWydtdCcsICdtYiddLFxuICAgICAgc2l6ZTogWyd3JywgJ2gnXSxcbiAgICAgICdmb250LXNpemUnOiBbJ2xlYWRpbmcnXSxcbiAgICAgICdmdm4tbm9ybWFsJzogWydmdm4tb3JkaW5hbCcsICdmdm4tc2xhc2hlZC16ZXJvJywgJ2Z2bi1maWd1cmUnLCAnZnZuLXNwYWNpbmcnLCAnZnZuLWZyYWN0aW9uJ10sXG4gICAgICAnZnZuLW9yZGluYWwnOiBbJ2Z2bi1ub3JtYWwnXSxcbiAgICAgICdmdm4tc2xhc2hlZC16ZXJvJzogWydmdm4tbm9ybWFsJ10sXG4gICAgICAnZnZuLWZpZ3VyZSc6IFsnZnZuLW5vcm1hbCddLFxuICAgICAgJ2Z2bi1zcGFjaW5nJzogWydmdm4tbm9ybWFsJ10sXG4gICAgICAnZnZuLWZyYWN0aW9uJzogWydmdm4tbm9ybWFsJ10sXG4gICAgICAnbGluZS1jbGFtcCc6IFsnZGlzcGxheScsICdvdmVyZmxvdyddLFxuICAgICAgcm91bmRlZDogWydyb3VuZGVkLXMnLCAncm91bmRlZC1lJywgJ3JvdW5kZWQtdCcsICdyb3VuZGVkLXInLCAncm91bmRlZC1iJywgJ3JvdW5kZWQtbCcsICdyb3VuZGVkLXNzJywgJ3JvdW5kZWQtc2UnLCAncm91bmRlZC1lZScsICdyb3VuZGVkLWVzJywgJ3JvdW5kZWQtdGwnLCAncm91bmRlZC10cicsICdyb3VuZGVkLWJyJywgJ3JvdW5kZWQtYmwnXSxcbiAgICAgICdyb3VuZGVkLXMnOiBbJ3JvdW5kZWQtc3MnLCAncm91bmRlZC1lcyddLFxuICAgICAgJ3JvdW5kZWQtZSc6IFsncm91bmRlZC1zZScsICdyb3VuZGVkLWVlJ10sXG4gICAgICAncm91bmRlZC10JzogWydyb3VuZGVkLXRsJywgJ3JvdW5kZWQtdHInXSxcbiAgICAgICdyb3VuZGVkLXInOiBbJ3JvdW5kZWQtdHInLCAncm91bmRlZC1iciddLFxuICAgICAgJ3JvdW5kZWQtYic6IFsncm91bmRlZC1icicsICdyb3VuZGVkLWJsJ10sXG4gICAgICAncm91bmRlZC1sJzogWydyb3VuZGVkLXRsJywgJ3JvdW5kZWQtYmwnXSxcbiAgICAgICdib3JkZXItc3BhY2luZyc6IFsnYm9yZGVyLXNwYWNpbmcteCcsICdib3JkZXItc3BhY2luZy15J10sXG4gICAgICAnYm9yZGVyLXcnOiBbJ2JvcmRlci13LXgnLCAnYm9yZGVyLXcteScsICdib3JkZXItdy1zJywgJ2JvcmRlci13LWUnLCAnYm9yZGVyLXctYnMnLCAnYm9yZGVyLXctYmUnLCAnYm9yZGVyLXctdCcsICdib3JkZXItdy1yJywgJ2JvcmRlci13LWInLCAnYm9yZGVyLXctbCddLFxuICAgICAgJ2JvcmRlci13LXgnOiBbJ2JvcmRlci13LXInLCAnYm9yZGVyLXctbCddLFxuICAgICAgJ2JvcmRlci13LXknOiBbJ2JvcmRlci13LXQnLCAnYm9yZGVyLXctYiddLFxuICAgICAgJ2JvcmRlci1jb2xvcic6IFsnYm9yZGVyLWNvbG9yLXgnLCAnYm9yZGVyLWNvbG9yLXknLCAnYm9yZGVyLWNvbG9yLXMnLCAnYm9yZGVyLWNvbG9yLWUnLCAnYm9yZGVyLWNvbG9yLWJzJywgJ2JvcmRlci1jb2xvci1iZScsICdib3JkZXItY29sb3ItdCcsICdib3JkZXItY29sb3ItcicsICdib3JkZXItY29sb3ItYicsICdib3JkZXItY29sb3ItbCddLFxuICAgICAgJ2JvcmRlci1jb2xvci14JzogWydib3JkZXItY29sb3ItcicsICdib3JkZXItY29sb3ItbCddLFxuICAgICAgJ2JvcmRlci1jb2xvci15JzogWydib3JkZXItY29sb3ItdCcsICdib3JkZXItY29sb3ItYiddLFxuICAgICAgdHJhbnNsYXRlOiBbJ3RyYW5zbGF0ZS14JywgJ3RyYW5zbGF0ZS15JywgJ3RyYW5zbGF0ZS1ub25lJ10sXG4gICAgICAndHJhbnNsYXRlLW5vbmUnOiBbJ3RyYW5zbGF0ZScsICd0cmFuc2xhdGUteCcsICd0cmFuc2xhdGUteScsICd0cmFuc2xhdGUteiddLFxuICAgICAgJ3Njcm9sbC1tJzogWydzY3JvbGwtbXgnLCAnc2Nyb2xsLW15JywgJ3Njcm9sbC1tcycsICdzY3JvbGwtbWUnLCAnc2Nyb2xsLW1icycsICdzY3JvbGwtbWJlJywgJ3Njcm9sbC1tdCcsICdzY3JvbGwtbXInLCAnc2Nyb2xsLW1iJywgJ3Njcm9sbC1tbCddLFxuICAgICAgJ3Njcm9sbC1teCc6IFsnc2Nyb2xsLW1yJywgJ3Njcm9sbC1tbCddLFxuICAgICAgJ3Njcm9sbC1teSc6IFsnc2Nyb2xsLW10JywgJ3Njcm9sbC1tYiddLFxuICAgICAgJ3Njcm9sbC1wJzogWydzY3JvbGwtcHgnLCAnc2Nyb2xsLXB5JywgJ3Njcm9sbC1wcycsICdzY3JvbGwtcGUnLCAnc2Nyb2xsLXBicycsICdzY3JvbGwtcGJlJywgJ3Njcm9sbC1wdCcsICdzY3JvbGwtcHInLCAnc2Nyb2xsLXBiJywgJ3Njcm9sbC1wbCddLFxuICAgICAgJ3Njcm9sbC1weCc6IFsnc2Nyb2xsLXByJywgJ3Njcm9sbC1wbCddLFxuICAgICAgJ3Njcm9sbC1weSc6IFsnc2Nyb2xsLXB0JywgJ3Njcm9sbC1wYiddLFxuICAgICAgdG91Y2g6IFsndG91Y2gteCcsICd0b3VjaC15JywgJ3RvdWNoLXB6J10sXG4gICAgICAndG91Y2gteCc6IFsndG91Y2gnXSxcbiAgICAgICd0b3VjaC15JzogWyd0b3VjaCddLFxuICAgICAgJ3RvdWNoLXB6JzogWyd0b3VjaCddXG4gICAgfSxcbiAgICBjb25mbGljdGluZ0NsYXNzR3JvdXBNb2RpZmllcnM6IHtcbiAgICAgICdmb250LXNpemUnOiBbJ2xlYWRpbmcnXVxuICAgIH0sXG4gICAgcG9zdGZpeExvb2t1cENsYXNzR3JvdXBzOiBbJ2NvbnRhaW5lci10eXBlJ10sXG4gICAgb3JkZXJTZW5zaXRpdmVNb2RpZmllcnM6IFsnKicsICcqKicsICdhZnRlcicsICdiYWNrZHJvcCcsICdiZWZvcmUnLCAnZGV0YWlscy1jb250ZW50JywgJ2ZpbGUnLCAnZmlyc3QtbGV0dGVyJywgJ2ZpcnN0LWxpbmUnLCAnbWFya2VyJywgJ3BsYWNlaG9sZGVyJywgJ3NlbGVjdGlvbiddXG4gIH07XG59O1xuXG4vKipcbiAqIEBwYXJhbSBiYXNlQ29uZmlnIENvbmZpZyB3aGVyZSBvdGhlciBjb25maWcgd2lsbCBiZSBtZXJnZWQgaW50by4gVGhpcyBvYmplY3Qgd2lsbCBiZSBtdXRhdGVkLlxuICogQHBhcmFtIGNvbmZpZ0V4dGVuc2lvbiBQYXJ0aWFsIGNvbmZpZyB0byBtZXJnZSBpbnRvIHRoZSBgYmFzZUNvbmZpZ2AuXG4gKi9cbmNvbnN0IG1lcmdlQ29uZmlncyA9IChiYXNlQ29uZmlnLCB7XG4gIGNhY2hlU2l6ZSxcbiAgcHJlZml4LFxuICBleHBlcmltZW50YWxQYXJzZUNsYXNzTmFtZSxcbiAgZXh0ZW5kID0ge30sXG4gIG92ZXJyaWRlID0ge31cbn0pID0+IHtcbiAgb3ZlcnJpZGVQcm9wZXJ0eShiYXNlQ29uZmlnLCAnY2FjaGVTaXplJywgY2FjaGVTaXplKTtcbiAgb3ZlcnJpZGVQcm9wZXJ0eShiYXNlQ29uZmlnLCAncHJlZml4JywgcHJlZml4KTtcbiAgb3ZlcnJpZGVQcm9wZXJ0eShiYXNlQ29uZmlnLCAnZXhwZXJpbWVudGFsUGFyc2VDbGFzc05hbWUnLCBleHBlcmltZW50YWxQYXJzZUNsYXNzTmFtZSk7XG4gIG92ZXJyaWRlQ29uZmlnUHJvcGVydGllcyhiYXNlQ29uZmlnLnRoZW1lLCBvdmVycmlkZS50aGVtZSk7XG4gIG92ZXJyaWRlQ29uZmlnUHJvcGVydGllcyhiYXNlQ29uZmlnLmNsYXNzR3JvdXBzLCBvdmVycmlkZS5jbGFzc0dyb3Vwcyk7XG4gIG92ZXJyaWRlQ29uZmlnUHJvcGVydGllcyhiYXNlQ29uZmlnLmNvbmZsaWN0aW5nQ2xhc3NHcm91cHMsIG92ZXJyaWRlLmNvbmZsaWN0aW5nQ2xhc3NHcm91cHMpO1xuICBvdmVycmlkZUNvbmZpZ1Byb3BlcnRpZXMoYmFzZUNvbmZpZy5jb25mbGljdGluZ0NsYXNzR3JvdXBNb2RpZmllcnMsIG92ZXJyaWRlLmNvbmZsaWN0aW5nQ2xhc3NHcm91cE1vZGlmaWVycyk7XG4gIG92ZXJyaWRlUHJvcGVydHkoYmFzZUNvbmZpZywgJ3Bvc3RmaXhMb29rdXBDbGFzc0dyb3VwcycsIG92ZXJyaWRlLnBvc3RmaXhMb29rdXBDbGFzc0dyb3Vwcyk7XG4gIG92ZXJyaWRlUHJvcGVydHkoYmFzZUNvbmZpZywgJ29yZGVyU2Vuc2l0aXZlTW9kaWZpZXJzJywgb3ZlcnJpZGUub3JkZXJTZW5zaXRpdmVNb2RpZmllcnMpO1xuICBtZXJnZUNvbmZpZ1Byb3BlcnRpZXMoYmFzZUNvbmZpZy50aGVtZSwgZXh0ZW5kLnRoZW1lKTtcbiAgbWVyZ2VDb25maWdQcm9wZXJ0aWVzKGJhc2VDb25maWcuY2xhc3NHcm91cHMsIGV4dGVuZC5jbGFzc0dyb3Vwcyk7XG4gIG1lcmdlQ29uZmlnUHJvcGVydGllcyhiYXNlQ29uZmlnLmNvbmZsaWN0aW5nQ2xhc3NHcm91cHMsIGV4dGVuZC5jb25mbGljdGluZ0NsYXNzR3JvdXBzKTtcbiAgbWVyZ2VDb25maWdQcm9wZXJ0aWVzKGJhc2VDb25maWcuY29uZmxpY3RpbmdDbGFzc0dyb3VwTW9kaWZpZXJzLCBleHRlbmQuY29uZmxpY3RpbmdDbGFzc0dyb3VwTW9kaWZpZXJzKTtcbiAgbWVyZ2VBcnJheVByb3BlcnRpZXMoYmFzZUNvbmZpZywgZXh0ZW5kLCAncG9zdGZpeExvb2t1cENsYXNzR3JvdXBzJyk7XG4gIG1lcmdlQXJyYXlQcm9wZXJ0aWVzKGJhc2VDb25maWcsIGV4dGVuZCwgJ29yZGVyU2Vuc2l0aXZlTW9kaWZpZXJzJyk7XG4gIHJldHVybiBiYXNlQ29uZmlnO1xufTtcbmNvbnN0IG92ZXJyaWRlUHJvcGVydHkgPSAoYmFzZU9iamVjdCwgb3ZlcnJpZGVLZXksIG92ZXJyaWRlVmFsdWUpID0+IHtcbiAgaWYgKG92ZXJyaWRlVmFsdWUgIT09IHVuZGVmaW5lZCkge1xuICAgIGJhc2VPYmplY3Rbb3ZlcnJpZGVLZXldID0gb3ZlcnJpZGVWYWx1ZTtcbiAgfVxufTtcbmNvbnN0IG92ZXJyaWRlQ29uZmlnUHJvcGVydGllcyA9IChiYXNlT2JqZWN0LCBvdmVycmlkZU9iamVjdCkgPT4ge1xuICBpZiAob3ZlcnJpZGVPYmplY3QpIHtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBvdmVycmlkZU9iamVjdCkge1xuICAgICAgb3ZlcnJpZGVQcm9wZXJ0eShiYXNlT2JqZWN0LCBrZXksIG92ZXJyaWRlT2JqZWN0W2tleV0pO1xuICAgIH1cbiAgfVxufTtcbmNvbnN0IG1lcmdlQ29uZmlnUHJvcGVydGllcyA9IChiYXNlT2JqZWN0LCBtZXJnZU9iamVjdCkgPT4ge1xuICBpZiAobWVyZ2VPYmplY3QpIHtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBtZXJnZU9iamVjdCkge1xuICAgICAgbWVyZ2VBcnJheVByb3BlcnRpZXMoYmFzZU9iamVjdCwgbWVyZ2VPYmplY3QsIGtleSk7XG4gICAgfVxuICB9XG59O1xuY29uc3QgbWVyZ2VBcnJheVByb3BlcnRpZXMgPSAoYmFzZU9iamVjdCwgbWVyZ2VPYmplY3QsIGtleSkgPT4ge1xuICBjb25zdCBtZXJnZVZhbHVlID0gbWVyZ2VPYmplY3Rba2V5XTtcbiAgaWYgKG1lcmdlVmFsdWUgIT09IHVuZGVmaW5lZCkge1xuICAgIGJhc2VPYmplY3Rba2V5XSA9IGJhc2VPYmplY3Rba2V5XSA/IGJhc2VPYmplY3Rba2V5XS5jb25jYXQobWVyZ2VWYWx1ZSkgOiBtZXJnZVZhbHVlO1xuICB9XG59O1xuY29uc3QgZXh0ZW5kVGFpbHdpbmRNZXJnZSA9IChjb25maWdFeHRlbnNpb24sIC4uLmNyZWF0ZUNvbmZpZykgPT4gdHlwZW9mIGNvbmZpZ0V4dGVuc2lvbiA9PT0gJ2Z1bmN0aW9uJyA/IGNyZWF0ZVRhaWx3aW5kTWVyZ2UoZ2V0RGVmYXVsdENvbmZpZywgY29uZmlnRXh0ZW5zaW9uLCAuLi5jcmVhdGVDb25maWcpIDogY3JlYXRlVGFpbHdpbmRNZXJnZSgoKSA9PiBtZXJnZUNvbmZpZ3MoZ2V0RGVmYXVsdENvbmZpZygpLCBjb25maWdFeHRlbnNpb24pLCAuLi5jcmVhdGVDb25maWcpO1xuY29uc3QgdHdNZXJnZSA9IC8qI19fUFVSRV9fKi9jcmVhdGVUYWlsd2luZE1lcmdlKGdldERlZmF1bHRDb25maWcpO1xuZXhwb3J0IHsgY3JlYXRlVGFpbHdpbmRNZXJnZSwgZXh0ZW5kVGFpbHdpbmRNZXJnZSwgZnJvbVRoZW1lLCBnZXREZWZhdWx0Q29uZmlnLCBtZXJnZUNvbmZpZ3MsIHR3Sm9pbiwgdHdNZXJnZSwgdmFsaWRhdG9ycyB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YnVuZGxlLW1qcy5tanMubWFwXG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdLCJtYXBwaW5ncyI6Ijs7OztBQUdBLElBQU0sZ0JBQWdCLFFBQVEsV0FBVztDQUV2QyxNQUFNLGdCQUFnQixJQUFJLE1BQU0sT0FBTyxTQUFTLE9BQU8sTUFBTTtDQUM3RCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEtBQ2pDLGNBQWMsS0FBSyxPQUFPO0NBRTVCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsS0FDakMsY0FBYyxPQUFPLFNBQVMsS0FBSyxPQUFPO0NBRTVDLE9BQU87QUFDVDtBQUdBLElBQU0sOEJBQThCLGNBQWMsZUFBZTtDQUMvRDtDQUNBO0FBQ0Y7QUFFQSxJQUFNLHlCQUF5QiwyQkFBVyxJQUFJLElBQUksR0FBRyxhQUFhLE1BQU0sa0JBQWtCO0NBQ3hGO0NBQ0E7Q0FDQTtBQUNGO0FBQ0EsSUFBTSx1QkFBdUI7QUFDN0IsSUFBTSxrQkFBa0IsQ0FBQztBQUV6QixJQUFNLDRCQUE0QjtBQUNsQyxJQUFNLHlCQUF3QixXQUFVO0NBQ3RDLE1BQU0sV0FBVyxlQUFlLE1BQU07Q0FDdEMsTUFBTSxFQUNKLHdCQUNBLG1DQUNFO0NBQ0osTUFBTSxtQkFBa0IsY0FBYTtFQUNuQyxJQUFJLFVBQVUsV0FBVyxHQUFHLEtBQUssVUFBVSxTQUFTLEdBQUcsR0FDckQsT0FBTywrQkFBK0IsU0FBUztFQUVqRCxNQUFNLGFBQWEsVUFBVSxNQUFNLG9CQUFvQjtFQUd2RCxPQUFPLGtCQUFrQixZQUROLFdBQVcsT0FBTyxNQUFNLFdBQVcsU0FBUyxJQUFJLElBQUksR0FDdEIsUUFBUTtDQUMzRDtDQUNBLE1BQU0sK0JBQStCLGNBQWMsdUJBQXVCO0VBQ3hFLElBQUksb0JBQW9CO0dBQ3RCLE1BQU0sb0JBQW9CLCtCQUErQjtHQUN6RCxNQUFNLGdCQUFnQix1QkFBdUI7R0FDN0MsSUFBSSxtQkFBbUI7SUFDckIsSUFBSSxlQUVGLE9BQU8sYUFBYSxlQUFlLGlCQUFpQjtJQUd0RCxPQUFPO0dBQ1Q7R0FFQSxPQUFPLGlCQUFpQjtFQUMxQjtFQUNBLE9BQU8sdUJBQXVCLGlCQUFpQjtDQUNqRDtDQUNBLE9BQU87RUFDTDtFQUNBO0NBQ0Y7QUFDRjtBQUNBLElBQU0scUJBQXFCLFlBQVksWUFBWSxvQkFBb0I7Q0FFckUsSUFEeUIsV0FBVyxTQUFTLGVBQ3BCLEdBQ3ZCLE9BQU8sZ0JBQWdCO0NBRXpCLE1BQU0sbUJBQW1CLFdBQVc7Q0FDcEMsTUFBTSxzQkFBc0IsZ0JBQWdCLFNBQVMsSUFBSSxnQkFBZ0I7Q0FDekUsSUFBSSxxQkFBcUI7RUFDdkIsTUFBTSxTQUFTLGtCQUFrQixZQUFZLGFBQWEsR0FBRyxtQkFBbUI7RUFDaEYsSUFBSSxRQUFRLE9BQU87Q0FDckI7Q0FDQSxNQUFNLGFBQWEsZ0JBQWdCO0NBQ25DLElBQUksZUFBZSxNQUNqQjtDQUdGLE1BQU0sWUFBWSxlQUFlLElBQUksV0FBVyxLQUFLLG9CQUFvQixJQUFJLFdBQVcsTUFBTSxVQUFVLENBQUMsQ0FBQyxLQUFLLG9CQUFvQjtDQUNuSSxNQUFNLG1CQUFtQixXQUFXO0NBQ3BDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxrQkFBa0IsS0FBSztFQUN6QyxNQUFNLGVBQWUsV0FBVztFQUNoQyxJQUFJLGFBQWEsVUFBVSxTQUFTLEdBQ2xDLE9BQU8sYUFBYTtDQUV4QjtBQUVGOzs7Ozs7QUFNQSxJQUFNLGtDQUFpQyxjQUFhLFVBQVUsTUFBTSxHQUFHLEVBQUUsQ0FBQyxDQUFDLFFBQVEsR0FBRyxNQUFNLEtBQUssS0FBQSxXQUFtQjtDQUNsSCxNQUFNLFVBQVUsVUFBVSxNQUFNLEdBQUcsRUFBRTtDQUNyQyxNQUFNLGFBQWEsUUFBUSxRQUFRLEdBQUc7Q0FDdEMsTUFBTSxXQUFXLFFBQVEsTUFBTSxHQUFHLFVBQVU7Q0FDNUMsT0FBTyxXQUFXLDRCQUE0QixXQUFXLEtBQUE7QUFDM0QsRUFBQSxDQUFHOzs7O0FBSUgsSUFBTSxrQkFBaUIsV0FBVTtDQUMvQixNQUFNLEVBQ0osT0FDQSxnQkFDRTtDQUNKLE9BQU8sbUJBQW1CLGFBQWEsS0FBSztBQUM5QztBQUVBLElBQU0sc0JBQXNCLGFBQWEsVUFBVTtDQUNqRCxNQUFNLFdBQVcsc0JBQXNCO0NBQ3ZDLEtBQUssTUFBTSxnQkFBZ0IsYUFBYTtFQUN0QyxNQUFNLFFBQVEsWUFBWTtFQUMxQiwwQkFBMEIsT0FBTyxVQUFVLGNBQWMsS0FBSztDQUNoRTtDQUNBLE9BQU87QUFDVDtBQUNBLElBQU0sNkJBQTZCLFlBQVksaUJBQWlCLGNBQWMsVUFBVTtDQUN0RixNQUFNLE1BQU0sV0FBVztDQUN2QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxLQUFLO0VBQzVCLE1BQU0sa0JBQWtCLFdBQVc7RUFDbkMsdUJBQXVCLGlCQUFpQixpQkFBaUIsY0FBYyxLQUFLO0NBQzlFO0FBQ0Y7QUFFQSxJQUFNLDBCQUEwQixpQkFBaUIsaUJBQWlCLGNBQWMsVUFBVTtDQUN4RixJQUFJLE9BQU8sb0JBQW9CLFVBQVU7RUFDdkMsd0JBQXdCLGlCQUFpQixpQkFBaUIsWUFBWTtFQUN0RTtDQUNGO0NBQ0EsSUFBSSxPQUFPLG9CQUFvQixZQUFZO0VBQ3pDLDBCQUEwQixpQkFBaUIsaUJBQWlCLGNBQWMsS0FBSztFQUMvRTtDQUNGO0NBQ0Esd0JBQXdCLGlCQUFpQixpQkFBaUIsY0FBYyxLQUFLO0FBQy9FO0FBQ0EsSUFBTSwyQkFBMkIsaUJBQWlCLGlCQUFpQixpQkFBaUI7Q0FDbEYsTUFBTSx3QkFBd0Isb0JBQW9CLEtBQUssa0JBQWtCLFFBQVEsaUJBQWlCLGVBQWU7Q0FDakgsc0JBQXNCLGVBQWU7QUFDdkM7QUFDQSxJQUFNLDZCQUE2QixpQkFBaUIsaUJBQWlCLGNBQWMsVUFBVTtDQUMzRixJQUFJLGNBQWMsZUFBZSxHQUFHO0VBQ2xDLDBCQUEwQixnQkFBZ0IsS0FBSyxHQUFHLGlCQUFpQixjQUFjLEtBQUs7RUFDdEY7Q0FDRjtDQUNBLElBQUksZ0JBQWdCLGVBQWUsTUFDakMsZ0JBQWdCLGFBQWEsQ0FBQztDQUVoQyxnQkFBZ0IsV0FBVyxLQUFLLDJCQUEyQixjQUFjLGVBQWUsQ0FBQztBQUMzRjtBQUNBLElBQU0sMkJBQTJCLGlCQUFpQixpQkFBaUIsY0FBYyxVQUFVO0NBQ3pGLE1BQU0sVUFBVSxPQUFPLFFBQVEsZUFBZTtDQUM5QyxNQUFNLE1BQU0sUUFBUTtDQUNwQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxLQUFLO0VBQzVCLE1BQU0sQ0FBQyxLQUFLLFNBQVMsUUFBUTtFQUM3QiwwQkFBMEIsT0FBTyxRQUFRLGlCQUFpQixHQUFHLEdBQUcsY0FBYyxLQUFLO0NBQ3JGO0FBQ0Y7QUFDQSxJQUFNLFdBQVcsaUJBQWlCLFNBQVM7Q0FDekMsSUFBSSxVQUFVO0NBQ2QsTUFBTSxRQUFRLEtBQUssTUFBTSxvQkFBb0I7Q0FDN0MsTUFBTSxNQUFNLE1BQU07Q0FDbEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSztFQUM1QixNQUFNLE9BQU8sTUFBTTtFQUNuQixJQUFJLE9BQU8sUUFBUSxTQUFTLElBQUksSUFBSTtFQUNwQyxJQUFJLENBQUMsTUFBTTtHQUNULE9BQU8sc0JBQXNCO0dBQzdCLFFBQVEsU0FBUyxJQUFJLE1BQU0sSUFBSTtFQUNqQztFQUNBLFVBQVU7Q0FDWjtDQUNBLE9BQU87QUFDVDtBQUVBLElBQU0saUJBQWdCLFNBQVEsbUJBQW1CLFFBQVEsS0FBSyxrQkFBa0I7QUFHaEYsSUFBTSxrQkFBaUIsaUJBQWdCO0NBQ3JDLElBQUksZUFBZSxHQUNqQixPQUFPO0VBQ0wsV0FBVyxLQUFBO0VBQ1gsV0FBVyxDQUFDO0NBQ2Q7Q0FFRixJQUFJLFlBQVk7Q0FDaEIsSUFBSSxRQUFRLE9BQU8sT0FBTyxJQUFJO0NBQzlCLElBQUksZ0JBQWdCLE9BQU8sT0FBTyxJQUFJO0NBQ3RDLE1BQU0sVUFBVSxLQUFLLFVBQVU7RUFDN0IsTUFBTSxPQUFPO0VBQ2I7RUFDQSxJQUFJLFlBQVksY0FBYztHQUM1QixZQUFZO0dBQ1osZ0JBQWdCO0dBQ2hCLFFBQVEsT0FBTyxPQUFPLElBQUk7RUFDNUI7Q0FDRjtDQUNBLE9BQU87RUFDTCxJQUFJLEtBQUs7R0FDUCxJQUFJLFFBQVEsTUFBTTtHQUNsQixJQUFJLFVBQVUsS0FBQSxHQUNaLE9BQU87R0FFVCxLQUFLLFFBQVEsY0FBYyxVQUFVLEtBQUEsR0FBVztJQUM5QyxPQUFPLEtBQUssS0FBSztJQUNqQixPQUFPO0dBQ1Q7RUFDRjtFQUNBLElBQUksS0FBSyxPQUFPO0dBQ2QsSUFBSSxPQUFPLE9BQ1QsTUFBTSxPQUFPO1FBRWIsT0FBTyxLQUFLLEtBQUs7RUFFckI7Q0FDRjtBQUNGO0FBQ0EsSUFBTSxxQkFBcUI7QUFDM0IsSUFBTSxxQkFBcUI7QUFDM0IsSUFBTSxrQkFBa0IsQ0FBQztBQUV6QixJQUFNLHNCQUFzQixXQUFXLHNCQUFzQixlQUFlLDhCQUE4QixnQkFBZ0I7Q0FDeEg7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGO0FBQ0EsSUFBTSx3QkFBdUIsV0FBVTtDQUNyQyxNQUFNLEVBQ0osUUFDQSwrQkFDRTs7Ozs7OztDQU9KLElBQUksa0JBQWlCLGNBQWE7RUFFaEMsTUFBTSxZQUFZLENBQUM7RUFDbkIsSUFBSSxlQUFlO0VBQ25CLElBQUksYUFBYTtFQUNqQixJQUFJLGdCQUFnQjtFQUNwQixJQUFJO0VBQ0osTUFBTSxNQUFNLFVBQVU7RUFDdEIsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLEtBQUssU0FBUztHQUN4QyxNQUFNLG1CQUFtQixVQUFVO0dBQ25DLElBQUksaUJBQWlCLEtBQUssZUFBZSxHQUFHO0lBQzFDLElBQUkscUJBQXFCLG9CQUFvQjtLQUMzQyxVQUFVLEtBQUssVUFBVSxNQUFNLGVBQWUsS0FBSyxDQUFDO0tBQ3BELGdCQUFnQixRQUFRO0tBQ3hCO0lBQ0Y7SUFDQSxJQUFJLHFCQUFxQixLQUFLO0tBQzVCLDBCQUEwQjtLQUMxQjtJQUNGO0dBQ0Y7R0FDQSxJQUFJLHFCQUFxQixLQUFLO1FBQW9CLElBQUkscUJBQXFCLEtBQUs7UUFBb0IsSUFBSSxxQkFBcUIsS0FBSztRQUFrQixJQUFJLHFCQUFxQixLQUFLO0VBQ3BMO0VBQ0EsTUFBTSxxQ0FBcUMsVUFBVSxXQUFXLElBQUksWUFBWSxVQUFVLE1BQU0sYUFBYTtFQUU3RyxJQUFJLGdCQUFnQjtFQUNwQixJQUFJLHVCQUF1QjtFQUMzQixJQUFJLG1DQUFtQyxTQUFTLGtCQUFrQixHQUFHO0dBQ25FLGdCQUFnQixtQ0FBbUMsTUFBTSxHQUFHLEVBQUU7R0FDOUQsdUJBQXVCO0VBQ3pCLE9BQU8sSUFLUCxtQ0FBbUMsV0FBVyxrQkFBa0IsR0FBRztHQUNqRSxnQkFBZ0IsbUNBQW1DLE1BQU0sQ0FBQztHQUMxRCx1QkFBdUI7RUFDekI7RUFDQSxNQUFNLCtCQUErQiwyQkFBMkIsMEJBQTBCLGdCQUFnQiwwQkFBMEIsZ0JBQWdCLEtBQUE7RUFDcEosT0FBTyxtQkFBbUIsV0FBVyxzQkFBc0IsZUFBZSw0QkFBNEI7Q0FDeEc7Q0FDQSxJQUFJLFFBQVE7RUFDVixNQUFNLGFBQWEsU0FBUztFQUM1QixNQUFNLHlCQUF5QjtFQUMvQixrQkFBaUIsY0FBYSxVQUFVLFdBQVcsVUFBVSxJQUFJLHVCQUF1QixVQUFVLE1BQU0sV0FBVyxNQUFNLENBQUMsSUFBSSxtQkFBbUIsaUJBQWlCLE9BQU8sV0FBVyxLQUFBLEdBQVcsSUFBSTtDQUNyTTtDQUNBLElBQUksNEJBQTRCO0VBQzlCLE1BQU0seUJBQXlCO0VBQy9CLGtCQUFpQixjQUFhLDJCQUEyQjtHQUN2RDtHQUNBLGdCQUFnQjtFQUNsQixDQUFDO0NBQ0g7Q0FDQSxPQUFPO0FBQ1Q7Ozs7OztBQU9BLElBQU0sdUJBQXNCLFdBQVU7Q0FFcEMsTUFBTSxrQ0FBa0IsSUFBSSxJQUFJO0NBRWhDLE9BQU8sd0JBQXdCLFNBQVMsS0FBSyxVQUFVO0VBQ3JELGdCQUFnQixJQUFJLEtBQUssTUFBVSxLQUFLO0NBQzFDLENBQUM7Q0FDRCxRQUFPLGNBQWE7RUFDbEIsTUFBTSxTQUFTLENBQUM7RUFDaEIsSUFBSSxpQkFBaUIsQ0FBQztFQUV0QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxRQUFRLEtBQUs7R0FDekMsTUFBTSxXQUFXLFVBQVU7R0FFM0IsTUFBTSxjQUFjLFNBQVMsT0FBTztHQUNwQyxNQUFNLG1CQUFtQixnQkFBZ0IsSUFBSSxRQUFRO0dBQ3JELElBQUksZUFBZSxrQkFBa0I7SUFFbkMsSUFBSSxlQUFlLFNBQVMsR0FBRztLQUM3QixlQUFlLEtBQUs7S0FDcEIsT0FBTyxLQUFLLEdBQUcsY0FBYztLQUM3QixpQkFBaUIsQ0FBQztJQUNwQjtJQUNBLE9BQU8sS0FBSyxRQUFRO0dBQ3RCLE9BRUUsZUFBZSxLQUFLLFFBQVE7RUFFaEM7RUFFQSxJQUFJLGVBQWUsU0FBUyxHQUFHO0dBQzdCLGVBQWUsS0FBSztHQUNwQixPQUFPLEtBQUssR0FBRyxjQUFjO0VBQy9CO0VBQ0EsT0FBTztDQUNUO0FBQ0Y7QUFDQSxJQUFNLHFCQUFvQixZQUFXO0NBQ25DLE9BQU8sZUFBZSxPQUFPLFNBQVM7Q0FDdEMsZ0JBQWdCLHFCQUFxQixNQUFNO0NBQzNDLGVBQWUsb0JBQW9CLE1BQU07Q0FDekMsNEJBQTRCLGlDQUFpQyxNQUFNO0NBQ25FLEdBQUcsc0JBQXNCLE1BQU07QUFDakM7QUFDQSxJQUFNLG9DQUFtQyxXQUFVO0NBQ2pELE1BQU0sU0FBUyxPQUFPLE9BQU8sSUFBSTtDQUNqQyxNQUFNLGdCQUFnQixPQUFPO0NBQzdCLElBQUksZUFDRixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksY0FBYyxRQUFRLEtBQ3hDLE9BQU8sY0FBYyxNQUFNO0NBRy9CLE9BQU87QUFDVDtBQUNBLElBQU0sc0JBQXNCO0FBQzVCLElBQU0sa0JBQWtCLFdBQVcsZ0JBQWdCO0NBQ2pELE1BQU0sRUFDSixnQkFDQSxpQkFDQSw2QkFDQSxlQUNBLCtCQUNFOzs7Ozs7OztDQVFKLE1BQU0sd0JBQXdCLENBQUM7Q0FDL0IsTUFBTSxhQUFhLFVBQVUsS0FBSyxDQUFDLENBQUMsTUFBTSxtQkFBbUI7Q0FDN0QsSUFBSSxTQUFTO0NBQ2IsS0FBSyxJQUFJLFFBQVEsV0FBVyxTQUFTLEdBQUcsU0FBUyxHQUFHLFNBQVMsR0FBRztFQUM5RCxNQUFNLG9CQUFvQixXQUFXO0VBQ3JDLE1BQU0sRUFDSixZQUNBLFdBQ0Esc0JBQ0EsZUFDQSxpQ0FDRSxlQUFlLGlCQUFpQjtFQUNwQyxJQUFJLFlBQVk7R0FDZCxTQUFTLHFCQUFxQixPQUFPLFNBQVMsSUFBSSxNQUFNLFNBQVM7R0FDakU7RUFDRjtFQUNBLElBQUkscUJBQXFCLENBQUMsQ0FBQztFQUMzQixJQUFJO0VBQ0osSUFBSSxvQkFBb0I7R0FFdEIsZUFBZSxnQkFEcUIsY0FBYyxVQUFVLEdBQUcsNEJBQ04sQ0FBQztHQUMxRCxNQUFNLDBCQUEwQixnQkFBZ0IsMkJBQTJCLGdCQUFnQixnQkFBZ0IsYUFBYSxJQUFJLEtBQUE7R0FDNUgsSUFBSSwyQkFBMkIsNEJBQTRCLGNBQWM7SUFDdkUsZUFBZTtJQUNmLHFCQUFxQjtHQUN2QjtFQUNGLE9BQ0UsZUFBZSxnQkFBZ0IsYUFBYTtFQUU5QyxJQUFJLENBQUMsY0FBYztHQUNqQixJQUFJLENBQUMsb0JBQW9CO0lBRXZCLFNBQVMscUJBQXFCLE9BQU8sU0FBUyxJQUFJLE1BQU0sU0FBUztJQUNqRTtHQUNGO0dBQ0EsZUFBZSxnQkFBZ0IsYUFBYTtHQUM1QyxJQUFJLENBQUMsY0FBYztJQUVqQixTQUFTLHFCQUFxQixPQUFPLFNBQVMsSUFBSSxNQUFNLFNBQVM7SUFDakU7R0FDRjtHQUNBLHFCQUFxQjtFQUN2QjtFQUVBLE1BQU0sa0JBQWtCLFVBQVUsV0FBVyxJQUFJLEtBQUssVUFBVSxXQUFXLElBQUksVUFBVSxLQUFLLGNBQWMsU0FBUyxDQUFDLENBQUMsS0FBSyxHQUFHO0VBQy9ILE1BQU0sYUFBYSx1QkFBdUIsa0JBQWtCLHFCQUFxQjtFQUNqRixNQUFNLFVBQVUsYUFBYTtFQUM3QixJQUFJLHNCQUFzQixRQUFRLE9BQU8sSUFBSSxJQUUzQztFQUVGLHNCQUFzQixLQUFLLE9BQU87RUFDbEMsTUFBTSxpQkFBaUIsNEJBQTRCLGNBQWMsa0JBQWtCO0VBQ25GLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxlQUFlLFFBQVEsRUFBRSxHQUFHO0dBQzlDLE1BQU0sUUFBUSxlQUFlO0dBQzdCLHNCQUFzQixLQUFLLGFBQWEsS0FBSztFQUMvQztFQUVBLFNBQVMscUJBQXFCLE9BQU8sU0FBUyxJQUFJLE1BQU0sU0FBUztDQUNuRTtDQUNBLE9BQU87QUFDVDs7Ozs7Ozs7OztBQVdBLElBQU0sVUFBVSxHQUFHLGVBQWU7Q0FDaEMsSUFBSSxRQUFRO0NBQ1osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJLFNBQVM7Q0FDYixPQUFPLFFBQVEsV0FBVyxRQUN4QixJQUFJLFdBQVcsV0FBVyxVQUNwQjtNQUFBLGdCQUFnQixRQUFRLFFBQVEsR0FBRztHQUNyQyxXQUFXLFVBQVU7R0FDckIsVUFBVTtFQUNaOztDQUdKLE9BQU87QUFDVDtBQUNBLElBQU0sV0FBVSxRQUFPO0NBRXJCLElBQUksT0FBTyxRQUFRLFVBQ2pCLE9BQU87Q0FFVCxJQUFJO0NBQ0osSUFBSSxTQUFTO0NBQ2IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUM5QixJQUFJLElBQUksSUFDRjtNQUFBLGdCQUFnQixRQUFRLElBQUksRUFBRSxHQUFHO0dBQ25DLFdBQVcsVUFBVTtHQUNyQixVQUFVO0VBQ1o7O0NBR0osT0FBTztBQUNUO0FBQ0EsSUFBTSx1QkFBdUIsbUJBQW1CLEdBQUcscUJBQXFCO0NBQ3RFLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixNQUFNLHFCQUFvQixjQUFhO0VBRXJDLGNBQWMsa0JBREMsaUJBQWlCLFFBQVEsZ0JBQWdCLHdCQUF3QixvQkFBb0IsY0FBYyxHQUFHLGtCQUFrQixDQUN2RyxDQUFNO0VBQ3RDLFdBQVcsWUFBWSxNQUFNO0VBQzdCLFdBQVcsWUFBWSxNQUFNO0VBQzdCLGlCQUFpQjtFQUNqQixPQUFPLGNBQWMsU0FBUztDQUNoQztDQUNBLE1BQU0saUJBQWdCLGNBQWE7RUFDakMsTUFBTSxlQUFlLFNBQVMsU0FBUztFQUN2QyxJQUFJLGNBQ0YsT0FBTztFQUVULE1BQU0sU0FBUyxlQUFlLFdBQVcsV0FBVztFQUNwRCxTQUFTLFdBQVcsTUFBTTtFQUMxQixPQUFPO0NBQ1Q7Q0FDQSxpQkFBaUI7Q0FDakIsUUFBUSxHQUFHLFNBQVMsZUFBZSxPQUFPLEdBQUcsSUFBSSxDQUFDO0FBQ3BEO0FBQ0EsSUFBTSxtQkFBbUIsQ0FBQztBQUMxQixJQUFNLGFBQVksUUFBTztDQUN2QixNQUFNLGVBQWMsVUFBUyxNQUFNLFFBQVE7Q0FDM0MsWUFBWSxnQkFBZ0I7Q0FDNUIsT0FBTztBQUNUO0FBQ0EsSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSx5QkFBeUI7QUFDL0IsSUFBTSxnQkFBZ0I7QUFDdEIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxrQkFBa0I7QUFDeEIsSUFBTSxxQkFBcUI7QUFFM0IsSUFBTSxjQUFjO0FBQ3BCLElBQU0sYUFBYTtBQUNuQixJQUFNLGNBQWEsVUFBUyxjQUFjLEtBQUssS0FBSztBQUNwRCxJQUFNLFlBQVcsVUFBUyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sTUFBTSxPQUFPLEtBQUssQ0FBQztBQUNoRSxJQUFNLGFBQVksVUFBUyxDQUFDLENBQUMsU0FBUyxPQUFPLFVBQVUsT0FBTyxLQUFLLENBQUM7QUFDcEUsSUFBTSxhQUFZLFVBQVMsTUFBTSxTQUFTLEdBQUcsS0FBSyxTQUFTLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUM3RSxJQUFNLGdCQUFlLFVBQVMsZ0JBQWdCLEtBQUssS0FBSztBQUN4RCxJQUFNLGNBQWM7QUFDcEIsSUFBTSxnQkFBZSxVQUlyQixnQkFBZ0IsS0FBSyxLQUFLLEtBQUssQ0FBQyxtQkFBbUIsS0FBSyxLQUFLO0FBQzdELElBQU0sZ0JBQWdCO0FBQ3RCLElBQU0sWUFBVyxVQUFTLFlBQVksS0FBSyxLQUFLO0FBQ2hELElBQU0sV0FBVSxVQUFTLFdBQVcsS0FBSyxLQUFLO0FBQzlDLElBQU0scUJBQW9CLFVBQVMsQ0FBQyxpQkFBaUIsS0FBSyxLQUFLLENBQUMsb0JBQW9CLEtBQUs7QUFDekYsSUFBTSx5QkFBd0IsVUFBUyxNQUFNLFdBQVcsWUFBWSxNQUFNLE1BQU0sUUFBUSxPQUFPLE1BQU0sUUFBUSxLQUFBLEtBQWEsTUFBTSxRQUFRLE9BQU8sTUFBTSxRQUFRLEtBQUEsS0FBYSxNQUFNLFdBQVcsVUFBVSxFQUFFLEtBQUssTUFBTSxRQUFRLE9BQU8sTUFBTSxRQUFRLEtBQUEsS0FBYSxNQUFNLFdBQVcsWUFBWSxFQUFFO0FBQzNSLElBQU0sbUJBQWtCLFVBQVMsb0JBQW9CLE9BQU8sYUFBYSxPQUFPO0FBQ2hGLElBQU0sb0JBQW1CLFVBQVMsb0JBQW9CLEtBQUssS0FBSztBQUNoRSxJQUFNLHFCQUFvQixVQUFTLG9CQUFvQixPQUFPLGVBQWUsWUFBWTtBQUN6RixJQUFNLHFCQUFvQixVQUFTLG9CQUFvQixPQUFPLGVBQWUsUUFBUTtBQUNyRixJQUFNLHFCQUFvQixVQUFTLG9CQUFvQixPQUFPLGVBQWUsS0FBSztBQUNsRixJQUFNLHlCQUF3QixVQUFTLG9CQUFvQixPQUFPLG1CQUFtQixPQUFPO0FBQzVGLElBQU0sdUJBQXNCLFVBQVMsb0JBQW9CLE9BQU8saUJBQWlCLE9BQU87QUFDeEYsSUFBTSxvQkFBbUIsVUFBUyxvQkFBb0IsT0FBTyxjQUFjLE9BQU87QUFDbEYsSUFBTSxxQkFBb0IsVUFBUyxvQkFBb0IsT0FBTyxlQUFlLFFBQVE7QUFDckYsSUFBTSx1QkFBc0IsVUFBUyx1QkFBdUIsS0FBSyxLQUFLO0FBQ3RFLElBQU0sNkJBQTRCLFVBQVMsdUJBQXVCLE9BQU8sYUFBYTtBQUN0RixJQUFNLGlDQUFnQyxVQUFTLHVCQUF1QixPQUFPLGlCQUFpQjtBQUM5RixJQUFNLCtCQUE4QixVQUFTLHVCQUF1QixPQUFPLGVBQWU7QUFDMUYsSUFBTSwyQkFBMEIsVUFBUyx1QkFBdUIsT0FBTyxXQUFXO0FBQ2xGLElBQU0sNEJBQTJCLFVBQVMsdUJBQXVCLE9BQU8sWUFBWTtBQUNwRixJQUFNLDZCQUE0QixVQUFTLHVCQUF1QixPQUFPLGVBQWUsSUFBSTtBQUM1RixJQUFNLDZCQUE0QixVQUFTLHVCQUF1QixPQUFPLGVBQWUsSUFBSTtBQUU1RixJQUFNLHVCQUF1QixPQUFPLFdBQVcsY0FBYztDQUMzRCxNQUFNLFNBQVMsb0JBQW9CLEtBQUssS0FBSztDQUM3QyxJQUFJLFFBQVE7RUFDVixJQUFJLE9BQU8sSUFDVCxPQUFPLFVBQVUsT0FBTyxFQUFFO0VBRTVCLE9BQU8sVUFBVSxPQUFPLEVBQUU7Q0FDNUI7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxJQUFNLDBCQUEwQixPQUFPLFdBQVcscUJBQXFCLFVBQVU7Q0FDL0UsTUFBTSxTQUFTLHVCQUF1QixLQUFLLEtBQUs7Q0FDaEQsSUFBSSxRQUFRO0VBQ1YsSUFBSSxPQUFPLElBQ1QsT0FBTyxVQUFVLE9BQU8sRUFBRTtFQUU1QixPQUFPO0NBQ1Q7Q0FDQSxPQUFPO0FBQ1Q7QUFFQSxJQUFNLG1CQUFrQixVQUFTLFVBQVUsY0FBYyxVQUFVO0FBQ25FLElBQU0sZ0JBQWUsVUFBUyxVQUFVLFdBQVcsVUFBVTtBQUM3RCxJQUFNLGVBQWMsVUFBUyxVQUFVLFlBQVksVUFBVSxVQUFVLFVBQVU7QUFDakYsSUFBTSxpQkFBZ0IsVUFBUyxVQUFVO0FBQ3pDLElBQU0saUJBQWdCLFVBQVMsVUFBVTtBQUN6QyxJQUFNLHFCQUFvQixVQUFTLFVBQVU7QUFDN0MsSUFBTSxpQkFBZ0IsVUFBUyxVQUFVLFlBQVksVUFBVTtBQUMvRCxJQUFNLGlCQUFnQixVQUFTLFVBQVU7QUFDekMsSUFBTSxhQUEwQixxQkFBTyxlQUFlO0NBQ3BELFdBQVc7Q0FDWDtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGLEdBQUcsT0FBTyxhQUFhLEVBQ3JCLE9BQU8sU0FDVCxDQUFDO0FBQ0QsSUFBTSx5QkFBeUI7Ozs7O0NBTTdCLE1BQU0sYUFBYSxVQUFVLE9BQU87Q0FDcEMsTUFBTSxZQUFZLFVBQVUsTUFBTTtDQUNsQyxNQUFNLFlBQVksVUFBVSxNQUFNO0NBQ2xDLE1BQU0sa0JBQWtCLFVBQVUsYUFBYTtDQUMvQyxNQUFNLGdCQUFnQixVQUFVLFVBQVU7Q0FDMUMsTUFBTSxlQUFlLFVBQVUsU0FBUztDQUN4QyxNQUFNLGtCQUFrQixVQUFVLFlBQVk7Q0FDOUMsTUFBTSxpQkFBaUIsVUFBVSxXQUFXO0NBQzVDLE1BQU0sZUFBZSxVQUFVLFNBQVM7Q0FDeEMsTUFBTSxjQUFjLFVBQVUsUUFBUTtDQUN0QyxNQUFNLGNBQWMsVUFBVSxRQUFRO0NBQ3RDLE1BQU0sbUJBQW1CLFVBQVUsY0FBYztDQUNqRCxNQUFNLGtCQUFrQixVQUFVLGFBQWE7Q0FDL0MsTUFBTSxrQkFBa0IsVUFBVSxhQUFhO0NBQy9DLE1BQU0sWUFBWSxVQUFVLE1BQU07Q0FDbEMsTUFBTSxtQkFBbUIsVUFBVSxhQUFhO0NBQ2hELE1BQU0sY0FBYyxVQUFVLFFBQVE7Q0FDdEMsTUFBTSxZQUFZLFVBQVUsTUFBTTtDQUNsQyxNQUFNLGVBQWUsVUFBVSxTQUFTOzs7Ozs7O0NBUXhDLE1BQU0sbUJBQW1CO0VBQUM7RUFBUTtFQUFTO0VBQU87RUFBYztFQUFRO0VBQVE7RUFBUztDQUFRO0NBQ2pHLE1BQU0sc0JBQXNCO0VBQUM7RUFBVTtFQUFPO0VBQVU7RUFBUTtFQUFTO0VBRXpFO0VBQVk7RUFFWjtFQUFhO0VBRWI7RUFBZ0I7RUFFaEI7Q0FBYTtDQUNiLE1BQU0sbUNBQW1DO0VBQUMsR0FBRyxjQUFjO0VBQUc7RUFBcUI7Q0FBZ0I7Q0FDbkcsTUFBTSxzQkFBc0I7RUFBQztFQUFRO0VBQVU7RUFBUTtFQUFXO0NBQVE7Q0FDMUUsTUFBTSx3QkFBd0I7RUFBQztFQUFRO0VBQVc7Q0FBTTtDQUN4RCxNQUFNLGdDQUFnQztFQUFDO0VBQXFCO0VBQWtCO0NBQVk7Q0FDMUYsTUFBTSxtQkFBbUI7RUFBQztFQUFZO0VBQVE7RUFBUSxHQUFHLHdCQUF3QjtDQUFDO0NBQ2xGLE1BQU0sa0NBQWtDO0VBQUM7RUFBVztFQUFRO0VBQVc7RUFBcUI7Q0FBZ0I7Q0FDNUcsTUFBTSxtQ0FBbUM7RUFBQztFQUFRLEVBQ2hELE1BQU07R0FBQztHQUFRO0dBQVc7R0FBcUI7RUFBZ0IsRUFDakU7RUFBRztFQUFXO0VBQXFCO0NBQWdCO0NBQ25ELE1BQU0sa0NBQWtDO0VBQUM7RUFBVztFQUFRO0VBQXFCO0NBQWdCO0NBQ2pHLE1BQU0sOEJBQThCO0VBQUM7RUFBUTtFQUFPO0VBQU87RUFBTTtFQUFxQjtDQUFnQjtDQUN0RyxNQUFNLDhCQUE4QjtFQUFDO0VBQVM7RUFBTztFQUFVO0VBQVc7RUFBVTtFQUFVO0VBQVc7RUFBWTtFQUFlO0NBQVU7Q0FDOUksTUFBTSxnQ0FBZ0M7RUFBQztFQUFTO0VBQU87RUFBVTtFQUFXO0VBQWU7Q0FBVTtDQUNyRyxNQUFNLG9CQUFvQixDQUFDLFFBQVEsR0FBRyx3QkFBd0IsQ0FBQztDQUMvRCxNQUFNLG9CQUFvQjtFQUFDO0VBQVk7RUFBUTtFQUFRO0VBQU87RUFBTztFQUFPO0VBQU87RUFBTztFQUFPO0VBQU87RUFBTztFQUFPLEdBQUcsd0JBQXdCO0NBQUM7Q0FDbEosTUFBTSwwQkFBMEI7RUFBQztFQUFZO0VBQVU7RUFBUTtFQUFPO0VBQU87RUFBTztFQUFPO0VBQU87RUFBTyxHQUFHLHdCQUF3QjtDQUFDO0NBQ3JJLE1BQU0seUJBQXlCO0VBQUM7RUFBWTtFQUFVO0VBQVE7RUFBTTtFQUFPO0VBQU87RUFBTztFQUFPO0VBQU87RUFBTyxHQUFHLHdCQUF3QjtDQUFDO0NBQzFJLE1BQU0sbUJBQW1CO0VBQUM7RUFBWTtFQUFxQjtDQUFnQjtDQUMzRSxNQUFNLHdCQUF3QjtFQUFDLEdBQUcsY0FBYztFQUFHO0VBQTZCO0VBQXFCLEVBQ25HLFVBQVUsQ0FBQyxxQkFBcUIsZ0JBQWdCLEVBQ2xEO0NBQUM7Q0FDRCxNQUFNLHNCQUFzQixDQUFDLGFBQWEsRUFDeEMsUUFBUTtFQUFDO0VBQUk7RUFBSztFQUFLO0VBQVM7Q0FBTyxFQUN6QyxDQUFDO0NBQ0QsTUFBTSxvQkFBb0I7RUFBQztFQUFRO0VBQVM7RUFBVztFQUF5QjtFQUFpQixFQUMvRixNQUFNLENBQUMscUJBQXFCLGdCQUFnQixFQUM5QztDQUFDO0NBQ0QsTUFBTSxrQ0FBa0M7RUFBQztFQUFXO0VBQTJCO0NBQWlCO0NBQ2hHLE1BQU0sb0JBQW9CO0VBRTFCO0VBQUk7RUFBUTtFQUFRO0VBQWE7RUFBcUI7Q0FBZ0I7Q0FDdEUsTUFBTSx5QkFBeUI7RUFBQztFQUFJO0VBQVU7RUFBMkI7Q0FBaUI7Q0FDMUYsTUFBTSx1QkFBdUI7RUFBQztFQUFTO0VBQVU7RUFBVTtDQUFRO0NBQ25FLE1BQU0sdUJBQXVCO0VBQUM7RUFBVTtFQUFZO0VBQVU7RUFBVztFQUFVO0VBQVc7RUFBZTtFQUFjO0VBQWM7RUFBYztFQUFjO0VBQWE7RUFBTztFQUFjO0VBQVM7Q0FBWTtDQUM1TixNQUFNLCtCQUErQjtFQUFDO0VBQVU7RUFBVztFQUE2QjtDQUFtQjtDQUMzRyxNQUFNLGtCQUFrQjtFQUV4QjtFQUFJO0VBQVE7RUFBVztFQUFxQjtDQUFnQjtDQUM1RCxNQUFNLG9CQUFvQjtFQUFDO0VBQVE7RUFBVTtFQUFxQjtDQUFnQjtDQUNsRixNQUFNLG1CQUFtQjtFQUFDO0VBQVE7RUFBVTtFQUFxQjtDQUFnQjtDQUNqRixNQUFNLGtCQUFrQjtFQUFDO0VBQVU7RUFBcUI7Q0FBZ0I7Q0FDeEUsTUFBTSx1QkFBdUI7RUFBQztFQUFZO0VBQVEsR0FBRyx3QkFBd0I7Q0FBQztDQUM5RSxPQUFPO0VBQ0wsV0FBVztFQUNYLE9BQU87R0FDTCxTQUFTO0lBQUM7SUFBUTtJQUFRO0lBQVM7R0FBUTtHQUMzQyxRQUFRLENBQUMsT0FBTztHQUNoQixNQUFNLENBQUMsWUFBWTtHQUNuQixZQUFZLENBQUMsWUFBWTtHQUN6QixPQUFPLENBQUMsS0FBSztHQUNiLFdBQVcsQ0FBQyxZQUFZO0dBQ3hCLGVBQWUsQ0FBQyxZQUFZO0dBQzVCLE1BQU07SUFBQztJQUFNO0lBQU87R0FBUTtHQUM1QixNQUFNLENBQUMsaUJBQWlCO0dBQ3hCLGVBQWU7SUFBQztJQUFRO0lBQWM7SUFBUztJQUFVO0lBQVU7SUFBWTtJQUFRO0lBQWE7R0FBTztHQUMzRyxnQkFBZ0IsQ0FBQyxZQUFZO0dBQzdCLFNBQVM7SUFBQztJQUFRO0lBQVM7SUFBUTtJQUFVO0lBQVc7R0FBTztHQUMvRCxhQUFhO0lBQUM7SUFBWTtJQUFRO0lBQVU7SUFBWTtJQUFXO0dBQU07R0FDekUsUUFBUSxDQUFDLFlBQVk7R0FDckIsUUFBUSxDQUFDLFlBQVk7R0FDckIsU0FBUyxDQUFDLE1BQU0sUUFBUTtHQUN4QixNQUFNLENBQUMsWUFBWTtHQUNuQixlQUFlLENBQUMsWUFBWTtHQUM1QixVQUFVO0lBQUM7SUFBVztJQUFTO0lBQVU7SUFBUTtJQUFTO0dBQVE7RUFDcEU7RUFDQSxhQUFhOzs7OztHQVFYLFFBQVEsQ0FBQyxFQUNQLFFBQVE7SUFBQztJQUFRO0lBQVU7SUFBWTtJQUFrQjtJQUFxQjtHQUFXLEVBQzNGLENBQUM7Ozs7OztHQU1ELFdBQVcsQ0FBQyxXQUFXOzs7OztHQUt2QixrQkFBa0IsQ0FBQyxFQUNqQixjQUFjO0lBQUM7SUFBSTtJQUFVO0lBQVE7SUFBcUI7R0FBZ0IsRUFDNUUsQ0FBQzs7Ozs7R0FLRCxtQkFBbUIsQ0FBQyxxQkFBcUI7Ozs7O0dBS3pDLFNBQVMsQ0FBQyxFQUNSLFNBQVM7SUFBQztJQUFVO0lBQWtCO0lBQXFCO0dBQWMsRUFDM0UsQ0FBQzs7Ozs7R0FLRCxlQUFlLENBQUMsRUFDZCxlQUFlLFdBQVcsRUFDNUIsQ0FBQzs7Ozs7R0FLRCxnQkFBZ0IsQ0FBQyxFQUNmLGdCQUFnQixXQUFXLEVBQzdCLENBQUM7Ozs7O0dBS0QsZ0JBQWdCLENBQUMsRUFDZixnQkFBZ0I7SUFBQztJQUFRO0lBQVM7SUFBYztHQUFjLEVBQ2hFLENBQUM7Ozs7O0dBS0Qsa0JBQWtCLENBQUMsRUFDakIsa0JBQWtCLENBQUMsU0FBUyxPQUFPLEVBQ3JDLENBQUM7Ozs7O0dBS0QsS0FBSyxDQUFDLEVBQ0osS0FBSyxDQUFDLFVBQVUsU0FBUyxFQUMzQixDQUFDOzs7OztHQUtELFNBQVM7SUFBQztJQUFTO0lBQWdCO0lBQVU7SUFBUTtJQUFlO0lBQVM7SUFBZ0I7SUFBaUI7SUFBYztJQUFnQjtJQUFzQjtJQUFzQjtJQUFzQjtJQUFtQjtJQUFhO0lBQWE7SUFBUTtJQUFlO0lBQVk7SUFBYTtHQUFROzs7OztHQUtuVCxJQUFJLENBQUMsV0FBVyxhQUFhOzs7OztHQUs3QixPQUFPLENBQUMsRUFDTixPQUFPO0lBQUM7SUFBUztJQUFRO0lBQVE7SUFBUztHQUFLLEVBQ2pELENBQUM7Ozs7O0dBS0QsT0FBTyxDQUFDLEVBQ04sT0FBTztJQUFDO0lBQVE7SUFBUztJQUFRO0lBQVE7SUFBUztHQUFLLEVBQ3pELENBQUM7Ozs7O0dBS0QsV0FBVyxDQUFDLFdBQVcsZ0JBQWdCOzs7OztHQUt2QyxjQUFjLENBQUMsRUFDYixRQUFRO0lBQUM7SUFBVztJQUFTO0lBQVE7SUFBUTtHQUFZLEVBQzNELENBQUM7Ozs7O0dBS0QsbUJBQW1CLENBQUMsRUFDbEIsUUFBUSwyQkFBMkIsRUFDckMsQ0FBQzs7Ozs7R0FLRCxVQUFVLENBQUMsRUFDVCxVQUFVLGNBQWMsRUFDMUIsQ0FBQzs7Ozs7R0FLRCxjQUFjLENBQUMsRUFDYixjQUFjLGNBQWMsRUFDOUIsQ0FBQzs7Ozs7R0FLRCxjQUFjLENBQUMsRUFDYixjQUFjLGNBQWMsRUFDOUIsQ0FBQzs7Ozs7R0FLRCxZQUFZLENBQUMsRUFDWCxZQUFZLGdCQUFnQixFQUM5QixDQUFDOzs7OztHQUtELGdCQUFnQixDQUFDLEVBQ2YsZ0JBQWdCLGdCQUFnQixFQUNsQyxDQUFDOzs7OztHQUtELGdCQUFnQixDQUFDLEVBQ2YsZ0JBQWdCLGdCQUFnQixFQUNsQyxDQUFDOzs7OztHQUtELFVBQVU7SUFBQztJQUFVO0lBQVM7SUFBWTtJQUFZO0dBQVE7Ozs7O0dBSzlELE9BQU8sQ0FBQyxFQUNOLE9BQU8sV0FBVyxFQUNwQixDQUFDOzs7OztHQUtELFdBQVcsQ0FBQyxFQUNWLFdBQVcsV0FBVyxFQUN4QixDQUFDOzs7OztHQUtELFdBQVcsQ0FBQyxFQUNWLFdBQVcsV0FBVyxFQUN4QixDQUFDOzs7Ozs7R0FNRCxPQUFPLENBQUM7SUFDTixXQUFXLFdBQVc7Ozs7O0lBS3RCLE9BQU8sV0FBVztHQUNwQixDQUFDOzs7Ozs7R0FNRCxLQUFLLENBQUM7SUFDSixXQUFXLFdBQVc7Ozs7O0lBS3RCLEtBQUssV0FBVztHQUNsQixDQUFDOzs7OztHQUtELFlBQVksQ0FBQyxFQUNYLFlBQVksV0FBVyxFQUN6QixDQUFDOzs7OztHQUtELFlBQVksQ0FBQyxFQUNYLFlBQVksV0FBVyxFQUN6QixDQUFDOzs7OztHQUtELEtBQUssQ0FBQyxFQUNKLEtBQUssV0FBVyxFQUNsQixDQUFDOzs7OztHQUtELE9BQU8sQ0FBQyxFQUNOLE9BQU8sV0FBVyxFQUNwQixDQUFDOzs7OztHQUtELFFBQVEsQ0FBQyxFQUNQLFFBQVEsV0FBVyxFQUNyQixDQUFDOzs7OztHQUtELE1BQU0sQ0FBQyxFQUNMLE1BQU0sV0FBVyxFQUNuQixDQUFDOzs7OztHQUtELFlBQVk7SUFBQztJQUFXO0lBQWE7R0FBVTs7Ozs7R0FLL0MsR0FBRyxDQUFDLEVBQ0YsR0FBRztJQUFDO0lBQVc7SUFBUTtJQUFxQjtHQUFnQixFQUM5RCxDQUFDOzs7OztHQVFELE9BQU8sQ0FBQyxFQUNOLE9BQU87SUFBQztJQUFZO0lBQVE7SUFBUTtJQUFnQixHQUFHLHdCQUF3QjtHQUFDLEVBQ2xGLENBQUM7Ozs7O0dBS0Qsa0JBQWtCLENBQUMsRUFDakIsTUFBTTtJQUFDO0lBQU87SUFBZTtJQUFPO0dBQWEsRUFDbkQsQ0FBQzs7Ozs7R0FLRCxhQUFhLENBQUMsRUFDWixNQUFNO0lBQUM7SUFBVTtJQUFRO0dBQWMsRUFDekMsQ0FBQzs7Ozs7R0FLRCxNQUFNLENBQUMsRUFDTCxNQUFNO0lBQUM7SUFBVTtJQUFZO0lBQVE7SUFBVztJQUFRO0dBQWdCLEVBQzFFLENBQUM7Ozs7O0dBS0QsTUFBTSxDQUFDLEVBQ0wsTUFBTTtJQUFDO0lBQUk7SUFBVTtJQUFxQjtHQUFnQixFQUM1RCxDQUFDOzs7OztHQUtELFFBQVEsQ0FBQyxFQUNQLFFBQVE7SUFBQztJQUFJO0lBQVU7SUFBcUI7R0FBZ0IsRUFDOUQsQ0FBQzs7Ozs7R0FLRCxPQUFPLENBQUMsRUFDTixPQUFPO0lBQUM7SUFBVztJQUFTO0lBQVE7SUFBUTtJQUFxQjtHQUFnQixFQUNuRixDQUFDOzs7OztHQUtELGFBQWEsQ0FBQyxFQUNaLGFBQWEsMEJBQTBCLEVBQ3pDLENBQUM7Ozs7O0dBS0QsaUJBQWlCLENBQUMsRUFDaEIsS0FBSywyQkFBMkIsRUFDbEMsQ0FBQzs7Ozs7R0FLRCxhQUFhLENBQUMsRUFDWixhQUFhLDBCQUEwQixFQUN6QyxDQUFDOzs7OztHQUtELFdBQVcsQ0FBQyxFQUNWLFdBQVcsMEJBQTBCLEVBQ3ZDLENBQUM7Ozs7O0dBS0QsYUFBYSxDQUFDLEVBQ1osYUFBYSwwQkFBMEIsRUFDekMsQ0FBQzs7Ozs7R0FLRCxpQkFBaUIsQ0FBQyxFQUNoQixLQUFLLDJCQUEyQixFQUNsQyxDQUFDOzs7OztHQUtELGFBQWEsQ0FBQyxFQUNaLGFBQWEsMEJBQTBCLEVBQ3pDLENBQUM7Ozs7O0dBS0QsV0FBVyxDQUFDLEVBQ1YsV0FBVywwQkFBMEIsRUFDdkMsQ0FBQzs7Ozs7R0FLRCxhQUFhLENBQUMsRUFDWixhQUFhO0lBQUM7SUFBTztJQUFPO0lBQVM7SUFBYTtHQUFXLEVBQy9ELENBQUM7Ozs7O0dBS0QsYUFBYSxDQUFDLEVBQ1osYUFBYSxzQkFBc0IsRUFDckMsQ0FBQzs7Ozs7R0FLRCxhQUFhLENBQUMsRUFDWixhQUFhLHNCQUFzQixFQUNyQyxDQUFDOzs7OztHQUtELEtBQUssQ0FBQyxFQUNKLEtBQUssd0JBQXdCLEVBQy9CLENBQUM7Ozs7O0dBS0QsU0FBUyxDQUFDLEVBQ1IsU0FBUyx3QkFBd0IsRUFDbkMsQ0FBQzs7Ozs7R0FLRCxTQUFTLENBQUMsRUFDUixTQUFTLHdCQUF3QixFQUNuQyxDQUFDOzs7OztHQUtELG1CQUFtQixDQUFDLEVBQ2xCLFNBQVMsQ0FBQyxHQUFHLHNCQUFzQixHQUFHLFFBQVEsRUFDaEQsQ0FBQzs7Ozs7R0FLRCxpQkFBaUIsQ0FBQyxFQUNoQixpQkFBaUIsQ0FBQyxHQUFHLHdCQUF3QixHQUFHLFFBQVEsRUFDMUQsQ0FBQzs7Ozs7R0FLRCxnQkFBZ0IsQ0FBQyxFQUNmLGdCQUFnQixDQUFDLFFBQVEsR0FBRyx3QkFBd0IsQ0FBQyxFQUN2RCxDQUFDOzs7OztHQUtELGlCQUFpQixDQUFDLEVBQ2hCLFNBQVMsQ0FBQyxVQUFVLEdBQUcsc0JBQXNCLENBQUMsRUFDaEQsQ0FBQzs7Ozs7R0FLRCxlQUFlLENBQUMsRUFDZCxPQUFPLENBQUMsR0FBRyx3QkFBd0IsR0FBRyxFQUNwQyxVQUFVLENBQUMsSUFBSSxNQUFNLEVBQ3ZCLENBQUMsRUFDSCxDQUFDOzs7OztHQUtELGNBQWMsQ0FBQyxFQUNiLE1BQU07SUFBQztJQUFRLEdBQUcsd0JBQXdCO0lBQUcsRUFDM0MsVUFBVSxDQUFDLElBQUksTUFBTSxFQUN2QjtHQUFDLEVBQ0gsQ0FBQzs7Ozs7R0FLRCxpQkFBaUIsQ0FBQyxFQUNoQixpQkFBaUIsc0JBQXNCLEVBQ3pDLENBQUM7Ozs7O0dBS0QsZUFBZSxDQUFDLEVBQ2QsZUFBZSxDQUFDLEdBQUcsd0JBQXdCLEdBQUcsVUFBVSxFQUMxRCxDQUFDOzs7OztHQUtELGNBQWMsQ0FBQyxFQUNiLGNBQWMsQ0FBQyxRQUFRLEdBQUcsd0JBQXdCLENBQUMsRUFDckQsQ0FBQzs7Ozs7R0FNRCxHQUFHLENBQUMsRUFDRixHQUFHLHdCQUF3QixFQUM3QixDQUFDOzs7OztHQUtELElBQUksQ0FBQyxFQUNILElBQUksd0JBQXdCLEVBQzlCLENBQUM7Ozs7O0dBS0QsSUFBSSxDQUFDLEVBQ0gsSUFBSSx3QkFBd0IsRUFDOUIsQ0FBQzs7Ozs7R0FLRCxJQUFJLENBQUMsRUFDSCxJQUFJLHdCQUF3QixFQUM5QixDQUFDOzs7OztHQUtELElBQUksQ0FBQyxFQUNILElBQUksd0JBQXdCLEVBQzlCLENBQUM7Ozs7O0dBS0QsS0FBSyxDQUFDLEVBQ0osS0FBSyx3QkFBd0IsRUFDL0IsQ0FBQzs7Ozs7R0FLRCxLQUFLLENBQUMsRUFDSixLQUFLLHdCQUF3QixFQUMvQixDQUFDOzs7OztHQUtELElBQUksQ0FBQyxFQUNILElBQUksd0JBQXdCLEVBQzlCLENBQUM7Ozs7O0dBS0QsSUFBSSxDQUFDLEVBQ0gsSUFBSSx3QkFBd0IsRUFDOUIsQ0FBQzs7Ozs7R0FLRCxJQUFJLENBQUMsRUFDSCxJQUFJLHdCQUF3QixFQUM5QixDQUFDOzs7OztHQUtELElBQUksQ0FBQyxFQUNILElBQUksd0JBQXdCLEVBQzlCLENBQUM7Ozs7O0dBS0QsR0FBRyxDQUFDLEVBQ0YsR0FBRyxZQUFZLEVBQ2pCLENBQUM7Ozs7O0dBS0QsSUFBSSxDQUFDLEVBQ0gsSUFBSSxZQUFZLEVBQ2xCLENBQUM7Ozs7O0dBS0QsSUFBSSxDQUFDLEVBQ0gsSUFBSSxZQUFZLEVBQ2xCLENBQUM7Ozs7O0dBS0QsSUFBSSxDQUFDLEVBQ0gsSUFBSSxZQUFZLEVBQ2xCLENBQUM7Ozs7O0dBS0QsSUFBSSxDQUFDLEVBQ0gsSUFBSSxZQUFZLEVBQ2xCLENBQUM7Ozs7O0dBS0QsS0FBSyxDQUFDLEVBQ0osS0FBSyxZQUFZLEVBQ25CLENBQUM7Ozs7O0dBS0QsS0FBSyxDQUFDLEVBQ0osS0FBSyxZQUFZLEVBQ25CLENBQUM7Ozs7O0dBS0QsSUFBSSxDQUFDLEVBQ0gsSUFBSSxZQUFZLEVBQ2xCLENBQUM7Ozs7O0dBS0QsSUFBSSxDQUFDLEVBQ0gsSUFBSSxZQUFZLEVBQ2xCLENBQUM7Ozs7O0dBS0QsSUFBSSxDQUFDLEVBQ0gsSUFBSSxZQUFZLEVBQ2xCLENBQUM7Ozs7O0dBS0QsSUFBSSxDQUFDLEVBQ0gsSUFBSSxZQUFZLEVBQ2xCLENBQUM7Ozs7O0dBS0QsV0FBVyxDQUFDLEVBQ1YsV0FBVyx3QkFBd0IsRUFDckMsQ0FBQzs7Ozs7R0FLRCxtQkFBbUIsQ0FBQyxpQkFBaUI7Ozs7O0dBS3JDLFdBQVcsQ0FBQyxFQUNWLFdBQVcsd0JBQXdCLEVBQ3JDLENBQUM7Ozs7O0dBS0QsbUJBQW1CLENBQUMsaUJBQWlCOzs7OztHQVFyQyxNQUFNLENBQUMsRUFDTCxNQUFNLFlBQVksRUFDcEIsQ0FBQzs7Ozs7R0FLRCxlQUFlLENBQUMsRUFDZCxRQUFRLENBQUMsUUFBUSxHQUFHLGtCQUFrQixDQUFDLEVBQ3pDLENBQUM7Ozs7O0dBS0QsbUJBQW1CLENBQUMsRUFDbEIsY0FBYyxDQUFDLFFBQVEsR0FBRyxrQkFBa0IsQ0FBQyxFQUMvQyxDQUFDOzs7OztHQUtELG1CQUFtQixDQUFDLEVBQ2xCLGNBQWMsQ0FBQyxRQUFRLEdBQUcsa0JBQWtCLENBQUMsRUFDL0MsQ0FBQzs7Ozs7R0FLRCxjQUFjLENBQUMsRUFDYixPQUFPLENBQUMsUUFBUSxHQUFHLGlCQUFpQixDQUFDLEVBQ3ZDLENBQUM7Ozs7O0dBS0Qsa0JBQWtCLENBQUMsRUFDakIsYUFBYSxDQUFDLFFBQVEsR0FBRyxpQkFBaUIsQ0FBQyxFQUM3QyxDQUFDOzs7OztHQUtELGtCQUFrQixDQUFDLEVBQ2pCLGFBQWEsQ0FBQyxRQUFRLEdBQUcsaUJBQWlCLENBQUMsRUFDN0MsQ0FBQzs7Ozs7R0FLRCxHQUFHLENBQUMsRUFDRixHQUFHO0lBQUM7SUFBZ0I7SUFBVSxHQUFHLFlBQVk7R0FBQyxFQUNoRCxDQUFDOzs7OztHQUtELFNBQVMsQ0FBQyxFQUNSLFNBQVM7SUFBQztJQUFnQjtJQUMxQjtJQUFRLEdBQUcsWUFBWTtHQUFDLEVBQzFCLENBQUM7Ozs7O0dBS0QsU0FBUyxDQUFDLEVBQ1IsU0FBUztJQUFDO0lBQWdCO0lBQVU7SUFDcEM7SUFDQSxFQUNFLFFBQVEsQ0FBQyxlQUFlLEVBQzFCO0lBQUcsR0FBRyxZQUFZO0dBQUMsRUFDckIsQ0FBQzs7Ozs7R0FLRCxHQUFHLENBQUMsRUFDRixHQUFHO0lBQUM7SUFBVTtJQUFNLEdBQUcsWUFBWTtHQUFDLEVBQ3RDLENBQUM7Ozs7O0dBS0QsU0FBUyxDQUFDLEVBQ1IsU0FBUztJQUFDO0lBQVU7SUFBTTtJQUFRLEdBQUcsWUFBWTtHQUFDLEVBQ3BELENBQUM7Ozs7O0dBS0QsU0FBUyxDQUFDLEVBQ1IsU0FBUztJQUFDO0lBQVU7SUFBTSxHQUFHLFlBQVk7R0FBQyxFQUM1QyxDQUFDOzs7OztHQVFELGFBQWEsQ0FBQyxFQUNaLE1BQU07SUFBQztJQUFRO0lBQVc7SUFBMkI7R0FBaUIsRUFDeEUsQ0FBQzs7Ozs7R0FLRCxrQkFBa0IsQ0FBQyxlQUFlLHNCQUFzQjs7Ozs7R0FLeEQsY0FBYyxDQUFDLFVBQVUsWUFBWTs7Ozs7R0FLckMsZUFBZSxDQUFDLEVBQ2QsTUFBTTtJQUFDO0lBQWlCO0lBQTJCO0dBQWlCLEVBQ3RFLENBQUM7Ozs7O0dBS0QsZ0JBQWdCLENBQUMsRUFDZixnQkFBZ0I7SUFBQztJQUFtQjtJQUFtQjtJQUFhO0lBQWtCO0lBQVU7SUFBaUI7SUFBWTtJQUFrQjtJQUFrQjtJQUFXO0dBQWdCLEVBQzlMLENBQUM7Ozs7O0dBS0QsZUFBZSxDQUFDLEVBQ2QsTUFBTTtJQUFDO0lBQStCO0lBQXVCO0dBQVMsRUFDeEUsQ0FBQzs7Ozs7R0FLRCxpQkFBaUIsQ0FBQyxFQUNoQixpQkFBaUIsQ0FBQyxnQkFBZ0IsRUFDcEMsQ0FBQzs7Ozs7R0FLRCxjQUFjLENBQUMsYUFBYTs7Ozs7R0FLNUIsZUFBZSxDQUFDLFNBQVM7Ozs7O0dBS3pCLG9CQUFvQixDQUFDLGNBQWM7Ozs7O0dBS25DLGNBQWMsQ0FBQyxlQUFlLGVBQWU7Ozs7O0dBSzdDLGVBQWUsQ0FBQyxxQkFBcUIsY0FBYzs7Ozs7R0FLbkQsZ0JBQWdCLENBQUMsc0JBQXNCLG1CQUFtQjs7Ozs7R0FLMUQsVUFBVSxDQUFDLEVBQ1QsVUFBVTtJQUFDO0lBQWU7SUFBcUI7R0FBZ0IsRUFDakUsQ0FBQzs7Ozs7R0FLRCxjQUFjLENBQUMsRUFDYixjQUFjO0lBQUM7SUFBVTtJQUFRO0lBQXFCO0dBQWlCLEVBQ3pFLENBQUM7Ozs7O0dBS0QsU0FBUyxDQUFDLEVBQ1IsU0FBUyxDQUNULGNBQWMsR0FBRyx3QkFBd0IsQ0FBQyxFQUM1QyxDQUFDOzs7OztHQUtELGNBQWMsQ0FBQyxFQUNiLGNBQWM7SUFBQztJQUFRO0lBQXFCO0dBQWdCLEVBQzlELENBQUM7Ozs7O0dBS0QsdUJBQXVCLENBQUMsRUFDdEIsTUFBTSxDQUFDLFVBQVUsU0FBUyxFQUM1QixDQUFDOzs7OztHQUtELG1CQUFtQixDQUFDLEVBQ2xCLE1BQU07SUFBQztJQUFRO0lBQVc7SUFBUTtJQUFxQjtHQUFnQixFQUN6RSxDQUFDOzs7OztHQUtELGtCQUFrQixDQUFDLEVBQ2pCLE1BQU07SUFBQztJQUFRO0lBQVU7SUFBUztJQUFXO0lBQVM7R0FBSyxFQUM3RCxDQUFDOzs7Ozs7R0FNRCxxQkFBcUIsQ0FBQyxFQUNwQixhQUFhLFdBQVcsRUFDMUIsQ0FBQzs7Ozs7R0FLRCxjQUFjLENBQUMsRUFDYixNQUFNLFdBQVcsRUFDbkIsQ0FBQzs7Ozs7R0FLRCxtQkFBbUI7SUFBQztJQUFhO0lBQVk7SUFBZ0I7R0FBYzs7Ozs7R0FLM0UseUJBQXlCLENBQUMsRUFDeEIsWUFBWSxDQUFDLEdBQUcsZUFBZSxHQUFHLE1BQU0sRUFDMUMsQ0FBQzs7Ozs7R0FLRCw2QkFBNkIsQ0FBQyxFQUM1QixZQUFZO0lBQUM7SUFBVTtJQUFhO0lBQVE7SUFBcUI7R0FBaUIsRUFDcEYsQ0FBQzs7Ozs7R0FLRCx5QkFBeUIsQ0FBQyxFQUN4QixZQUFZLFdBQVcsRUFDekIsQ0FBQzs7Ozs7R0FLRCxvQkFBb0IsQ0FBQyxFQUNuQixvQkFBb0I7SUFBQztJQUFVO0lBQVE7SUFBcUI7R0FBZ0IsRUFDOUUsQ0FBQzs7Ozs7R0FLRCxrQkFBa0I7SUFBQztJQUFhO0lBQWE7SUFBYztHQUFhOzs7OztHQUt4RSxpQkFBaUI7SUFBQztJQUFZO0lBQWlCO0dBQVc7Ozs7O0dBSzFELGFBQWEsQ0FBQyxFQUNaLE1BQU07SUFBQztJQUFRO0lBQVU7SUFBVztHQUFRLEVBQzlDLENBQUM7Ozs7O0dBS0QsUUFBUSxDQUFDLEVBQ1AsUUFBUSx3QkFBd0IsRUFDbEMsQ0FBQzs7Ozs7R0FLRCxZQUFZLENBQUMsRUFDWCxLQUFLO0lBQUM7SUFBVztJQUFxQjtHQUFnQixFQUN4RCxDQUFDOzs7OztHQUtELGtCQUFrQixDQUFDLEVBQ2pCLE9BQU87SUFBQztJQUFZO0lBQU87SUFBVTtJQUFVO0lBQVk7SUFBZTtJQUFPO0lBQVM7SUFBcUI7R0FBZ0IsRUFDakksQ0FBQzs7Ozs7R0FLRCxZQUFZLENBQUMsRUFDWCxZQUFZO0lBQUM7SUFBVTtJQUFVO0lBQU87SUFBWTtJQUFZO0dBQWMsRUFDaEYsQ0FBQzs7Ozs7R0FLRCxPQUFPLENBQUMsRUFDTixPQUFPO0lBQUM7SUFBVTtJQUFTO0lBQU87R0FBTSxFQUMxQyxDQUFDOzs7OztHQUtELE1BQU0sQ0FBQyxFQUNMLE1BQU07SUFBQztJQUFjO0lBQVk7R0FBUSxFQUMzQyxDQUFDOzs7OztHQUtELFNBQVMsQ0FBQyxFQUNSLFNBQVM7SUFBQztJQUFRO0lBQVU7R0FBTSxFQUNwQyxDQUFDOzs7OztHQUtELFNBQVMsQ0FBQyxFQUNSLFNBQVM7SUFBQztJQUFRO0lBQXFCO0dBQWdCLEVBQ3pELENBQUM7Ozs7O0dBUUQsaUJBQWlCLENBQUMsRUFDaEIsSUFBSTtJQUFDO0lBQVM7SUFBUztHQUFRLEVBQ2pDLENBQUM7Ozs7O0dBS0QsV0FBVyxDQUFDLEVBQ1YsV0FBVztJQUFDO0lBQVU7SUFBVztJQUFXO0dBQU0sRUFDcEQsQ0FBQzs7Ozs7R0FLRCxhQUFhLENBQUMsRUFDWixhQUFhO0lBQUM7SUFBVTtJQUFXO0dBQVMsRUFDOUMsQ0FBQzs7Ozs7R0FLRCxlQUFlLENBQUMsRUFDZCxJQUFJLGdCQUFnQixFQUN0QixDQUFDOzs7OztHQUtELGFBQWEsQ0FBQyxFQUNaLElBQUksY0FBYyxFQUNwQixDQUFDOzs7OztHQUtELFdBQVcsQ0FBQyxFQUNWLElBQUksWUFBWSxFQUNsQixDQUFDOzs7OztHQUtELFlBQVksQ0FBQyxFQUNYLElBQUk7SUFBQztJQUFRO0tBQ1gsUUFBUTtNQUFDLEVBQ1AsSUFBSTtPQUFDO09BQUs7T0FBTTtPQUFLO09BQU07T0FBSztPQUFNO09BQUs7TUFBSSxFQUNqRDtNQUFHO01BQVc7TUFBcUI7S0FBZ0I7S0FDbkQsUUFBUTtNQUFDO01BQUk7TUFBcUI7S0FBZ0I7S0FDbEQsT0FBTztNQUFDO01BQVc7TUFBcUI7S0FBZ0I7SUFDMUQ7SUFBRztJQUEwQjtHQUFnQixFQUMvQyxDQUFDOzs7OztHQUtELFlBQVksQ0FBQyxFQUNYLElBQUksV0FBVyxFQUNqQixDQUFDOzs7OztHQUtELHFCQUFxQixDQUFDLEVBQ3BCLE1BQU0sMEJBQTBCLEVBQ2xDLENBQUM7Ozs7O0dBS0Qsb0JBQW9CLENBQUMsRUFDbkIsS0FBSywwQkFBMEIsRUFDakMsQ0FBQzs7Ozs7R0FLRCxtQkFBbUIsQ0FBQyxFQUNsQixJQUFJLDBCQUEwQixFQUNoQyxDQUFDOzs7OztHQUtELGlCQUFpQixDQUFDLEVBQ2hCLE1BQU0sV0FBVyxFQUNuQixDQUFDOzs7OztHQUtELGdCQUFnQixDQUFDLEVBQ2YsS0FBSyxXQUFXLEVBQ2xCLENBQUM7Ozs7O0dBS0QsZUFBZSxDQUFDLEVBQ2QsSUFBSSxXQUFXLEVBQ2pCLENBQUM7Ozs7O0dBUUQsU0FBUyxDQUFDLEVBQ1IsU0FBUyxZQUFZLEVBQ3ZCLENBQUM7Ozs7O0dBS0QsYUFBYSxDQUFDLEVBQ1osYUFBYSxZQUFZLEVBQzNCLENBQUM7Ozs7O0dBS0QsYUFBYSxDQUFDLEVBQ1osYUFBYSxZQUFZLEVBQzNCLENBQUM7Ozs7O0dBS0QsYUFBYSxDQUFDLEVBQ1osYUFBYSxZQUFZLEVBQzNCLENBQUM7Ozs7O0dBS0QsYUFBYSxDQUFDLEVBQ1osYUFBYSxZQUFZLEVBQzNCLENBQUM7Ozs7O0dBS0QsYUFBYSxDQUFDLEVBQ1osYUFBYSxZQUFZLEVBQzNCLENBQUM7Ozs7O0dBS0QsYUFBYSxDQUFDLEVBQ1osYUFBYSxZQUFZLEVBQzNCLENBQUM7Ozs7O0dBS0QsY0FBYyxDQUFDLEVBQ2IsY0FBYyxZQUFZLEVBQzVCLENBQUM7Ozs7O0dBS0QsY0FBYyxDQUFDLEVBQ2IsY0FBYyxZQUFZLEVBQzVCLENBQUM7Ozs7O0dBS0QsY0FBYyxDQUFDLEVBQ2IsY0FBYyxZQUFZLEVBQzVCLENBQUM7Ozs7O0dBS0QsY0FBYyxDQUFDLEVBQ2IsY0FBYyxZQUFZLEVBQzVCLENBQUM7Ozs7O0dBS0QsY0FBYyxDQUFDLEVBQ2IsY0FBYyxZQUFZLEVBQzVCLENBQUM7Ozs7O0dBS0QsY0FBYyxDQUFDLEVBQ2IsY0FBYyxZQUFZLEVBQzVCLENBQUM7Ozs7O0dBS0QsY0FBYyxDQUFDLEVBQ2IsY0FBYyxZQUFZLEVBQzVCLENBQUM7Ozs7O0dBS0QsY0FBYyxDQUFDLEVBQ2IsY0FBYyxZQUFZLEVBQzVCLENBQUM7Ozs7O0dBS0QsWUFBWSxDQUFDLEVBQ1gsUUFBUSxpQkFBaUIsRUFDM0IsQ0FBQzs7Ozs7R0FLRCxjQUFjLENBQUMsRUFDYixZQUFZLGlCQUFpQixFQUMvQixDQUFDOzs7OztHQUtELGNBQWMsQ0FBQyxFQUNiLFlBQVksaUJBQWlCLEVBQy9CLENBQUM7Ozs7O0dBS0QsY0FBYyxDQUFDLEVBQ2IsWUFBWSxpQkFBaUIsRUFDL0IsQ0FBQzs7Ozs7R0FLRCxjQUFjLENBQUMsRUFDYixZQUFZLGlCQUFpQixFQUMvQixDQUFDOzs7OztHQUtELGVBQWUsQ0FBQyxFQUNkLGFBQWEsaUJBQWlCLEVBQ2hDLENBQUM7Ozs7O0dBS0QsZUFBZSxDQUFDLEVBQ2QsYUFBYSxpQkFBaUIsRUFDaEMsQ0FBQzs7Ozs7R0FLRCxjQUFjLENBQUMsRUFDYixZQUFZLGlCQUFpQixFQUMvQixDQUFDOzs7OztHQUtELGNBQWMsQ0FBQyxFQUNiLFlBQVksaUJBQWlCLEVBQy9CLENBQUM7Ozs7O0dBS0QsY0FBYyxDQUFDLEVBQ2IsWUFBWSxpQkFBaUIsRUFDL0IsQ0FBQzs7Ozs7R0FLRCxjQUFjLENBQUMsRUFDYixZQUFZLGlCQUFpQixFQUMvQixDQUFDOzs7OztHQUtELFlBQVksQ0FBQyxFQUNYLFlBQVksaUJBQWlCLEVBQy9CLENBQUM7Ozs7O0dBS0Qsb0JBQW9CLENBQUMsa0JBQWtCOzs7OztHQUt2QyxZQUFZLENBQUMsRUFDWCxZQUFZLGlCQUFpQixFQUMvQixDQUFDOzs7OztHQUtELG9CQUFvQixDQUFDLGtCQUFrQjs7Ozs7R0FLdkMsZ0JBQWdCLENBQUMsRUFDZixRQUFRO0lBQUMsR0FBRyxlQUFlO0lBQUc7SUFBVTtHQUFNLEVBQ2hELENBQUM7Ozs7O0dBS0QsZ0JBQWdCLENBQUMsRUFDZixRQUFRO0lBQUMsR0FBRyxlQUFlO0lBQUc7SUFBVTtHQUFNLEVBQ2hELENBQUM7Ozs7O0dBS0QsZ0JBQWdCLENBQUMsRUFDZixRQUFRLFdBQVcsRUFDckIsQ0FBQzs7Ozs7R0FLRCxrQkFBa0IsQ0FBQyxFQUNqQixZQUFZLFdBQVcsRUFDekIsQ0FBQzs7Ozs7R0FLRCxrQkFBa0IsQ0FBQyxFQUNqQixZQUFZLFdBQVcsRUFDekIsQ0FBQzs7Ozs7R0FLRCxrQkFBa0IsQ0FBQyxFQUNqQixZQUFZLFdBQVcsRUFDekIsQ0FBQzs7Ozs7R0FLRCxrQkFBa0IsQ0FBQyxFQUNqQixZQUFZLFdBQVcsRUFDekIsQ0FBQzs7Ozs7R0FLRCxtQkFBbUIsQ0FBQyxFQUNsQixhQUFhLFdBQVcsRUFDMUIsQ0FBQzs7Ozs7R0FLRCxtQkFBbUIsQ0FBQyxFQUNsQixhQUFhLFdBQVcsRUFDMUIsQ0FBQzs7Ozs7R0FLRCxrQkFBa0IsQ0FBQyxFQUNqQixZQUFZLFdBQVcsRUFDekIsQ0FBQzs7Ozs7R0FLRCxrQkFBa0IsQ0FBQyxFQUNqQixZQUFZLFdBQVcsRUFDekIsQ0FBQzs7Ozs7R0FLRCxrQkFBa0IsQ0FBQyxFQUNqQixZQUFZLFdBQVcsRUFDekIsQ0FBQzs7Ozs7R0FLRCxrQkFBa0IsQ0FBQyxFQUNqQixZQUFZLFdBQVcsRUFDekIsQ0FBQzs7Ozs7R0FLRCxnQkFBZ0IsQ0FBQyxFQUNmLFFBQVEsV0FBVyxFQUNyQixDQUFDOzs7OztHQUtELGlCQUFpQixDQUFDLEVBQ2hCLFNBQVM7SUFBQyxHQUFHLGVBQWU7SUFBRztJQUFRO0dBQVEsRUFDakQsQ0FBQzs7Ozs7R0FLRCxrQkFBa0IsQ0FBQyxFQUNqQixrQkFBa0I7SUFBQztJQUFVO0lBQXFCO0dBQWdCLEVBQ3BFLENBQUM7Ozs7O0dBS0QsYUFBYSxDQUFDLEVBQ1osU0FBUztJQUFDO0lBQUk7SUFBVTtJQUEyQjtHQUFpQixFQUN0RSxDQUFDOzs7OztHQUtELGlCQUFpQixDQUFDLEVBQ2hCLFNBQVMsV0FBVyxFQUN0QixDQUFDOzs7OztHQVFELFFBQVEsQ0FBQyxFQUNQLFFBQVE7SUFFUjtJQUFJO0lBQVE7SUFBYTtJQUEyQjtHQUFpQixFQUN2RSxDQUFDOzs7OztHQUtELGdCQUFnQixDQUFDLEVBQ2YsUUFBUSxXQUFXLEVBQ3JCLENBQUM7Ozs7O0dBS0QsZ0JBQWdCLENBQUMsRUFDZixnQkFBZ0I7SUFBQztJQUFRO0lBQWtCO0lBQTJCO0dBQWlCLEVBQ3pGLENBQUM7Ozs7O0dBS0Qsc0JBQXNCLENBQUMsRUFDckIsZ0JBQWdCLFdBQVcsRUFDN0IsQ0FBQzs7Ozs7R0FLRCxVQUFVLENBQUMsRUFDVCxNQUFNLGlCQUFpQixFQUN6QixDQUFDOzs7Ozs7O0dBT0QsZ0JBQWdCLENBQUMsWUFBWTs7Ozs7R0FLN0IsY0FBYyxDQUFDLEVBQ2IsTUFBTSxXQUFXLEVBQ25CLENBQUM7Ozs7Ozs7R0FPRCxpQkFBaUIsQ0FBQyxFQUNoQixlQUFlLENBQUMsVUFBVSxpQkFBaUIsRUFDN0MsQ0FBQzs7Ozs7OztHQU9ELHFCQUFxQixDQUFDLEVBQ3BCLGVBQWUsV0FBVyxFQUM1QixDQUFDOzs7OztHQUtELGdCQUFnQixDQUFDLEVBQ2YsY0FBYyxpQkFBaUIsRUFDakMsQ0FBQzs7Ozs7R0FLRCxvQkFBb0IsQ0FBQyxFQUNuQixjQUFjLFdBQVcsRUFDM0IsQ0FBQzs7Ozs7R0FLRCxlQUFlLENBQUMsRUFDZCxlQUFlO0lBQUM7SUFBUTtJQUFpQjtJQUEyQjtHQUFpQixFQUN2RixDQUFDOzs7OztHQUtELHFCQUFxQixDQUFDLEVBQ3BCLGVBQWUsV0FBVyxFQUM1QixDQUFDOzs7OztHQUtELFNBQVMsQ0FBQyxFQUNSLFNBQVM7SUFBQztJQUFVO0lBQXFCO0dBQWdCLEVBQzNELENBQUM7Ozs7O0dBS0QsYUFBYSxDQUFDLEVBQ1osYUFBYTtJQUFDLEdBQUcsZUFBZTtJQUFHO0lBQWU7R0FBYyxFQUNsRSxDQUFDOzs7OztHQUtELFlBQVksQ0FBQyxFQUNYLFlBQVksZUFBZSxFQUM3QixDQUFDOzs7OztHQUtELGFBQWEsQ0FBQyxFQUNaLGFBQWE7SUFBQztJQUFVO0lBQVc7SUFBVztJQUFRO0lBQVU7R0FBTSxFQUN4RSxHQUFHLGNBQWM7Ozs7O0dBS2pCLGtCQUFrQixDQUFDLEVBQ2pCLE1BQU07SUFBQztJQUFPO0lBQVk7SUFBYTtHQUFTLEVBQ2xELENBQUM7Ozs7O0dBS0QseUJBQXlCLENBQUMsRUFDeEIsZUFBZSxDQUFDLFFBQVEsRUFDMUIsQ0FBQztHQUNELDhCQUE4QixDQUFDLEVBQzdCLG9CQUFvQix1QkFBdUIsRUFDN0MsQ0FBQztHQUNELDRCQUE0QixDQUFDLEVBQzNCLGtCQUFrQix1QkFBdUIsRUFDM0MsQ0FBQztHQUNELGdDQUFnQyxDQUFDLEVBQy9CLG9CQUFvQixXQUFXLEVBQ2pDLENBQUM7R0FDRCw4QkFBOEIsQ0FBQyxFQUM3QixrQkFBa0IsV0FBVyxFQUMvQixDQUFDO0dBQ0QseUJBQXlCLENBQUMsRUFDeEIsZUFBZSx1QkFBdUIsRUFDeEMsQ0FBQztHQUNELHVCQUF1QixDQUFDLEVBQ3RCLGFBQWEsdUJBQXVCLEVBQ3RDLENBQUM7R0FDRCwyQkFBMkIsQ0FBQyxFQUMxQixlQUFlLFdBQVcsRUFDNUIsQ0FBQztHQUNELHlCQUF5QixDQUFDLEVBQ3hCLGFBQWEsV0FBVyxFQUMxQixDQUFDO0dBQ0QseUJBQXlCLENBQUMsRUFDeEIsZUFBZSx1QkFBdUIsRUFDeEMsQ0FBQztHQUNELHVCQUF1QixDQUFDLEVBQ3RCLGFBQWEsdUJBQXVCLEVBQ3RDLENBQUM7R0FDRCwyQkFBMkIsQ0FBQyxFQUMxQixlQUFlLFdBQVcsRUFDNUIsQ0FBQztHQUNELHlCQUF5QixDQUFDLEVBQ3hCLGFBQWEsV0FBVyxFQUMxQixDQUFDO0dBQ0QseUJBQXlCLENBQUMsRUFDeEIsZUFBZSx1QkFBdUIsRUFDeEMsQ0FBQztHQUNELHVCQUF1QixDQUFDLEVBQ3RCLGFBQWEsdUJBQXVCLEVBQ3RDLENBQUM7R0FDRCwyQkFBMkIsQ0FBQyxFQUMxQixlQUFlLFdBQVcsRUFDNUIsQ0FBQztHQUNELHlCQUF5QixDQUFDLEVBQ3hCLGFBQWEsV0FBVyxFQUMxQixDQUFDO0dBQ0QseUJBQXlCLENBQUMsRUFDeEIsZUFBZSx1QkFBdUIsRUFDeEMsQ0FBQztHQUNELHVCQUF1QixDQUFDLEVBQ3RCLGFBQWEsdUJBQXVCLEVBQ3RDLENBQUM7R0FDRCwyQkFBMkIsQ0FBQyxFQUMxQixlQUFlLFdBQVcsRUFDNUIsQ0FBQztHQUNELHlCQUF5QixDQUFDLEVBQ3hCLGFBQWEsV0FBVyxFQUMxQixDQUFDO0dBQ0QseUJBQXlCLENBQUMsRUFDeEIsZUFBZSx1QkFBdUIsRUFDeEMsQ0FBQztHQUNELHVCQUF1QixDQUFDLEVBQ3RCLGFBQWEsdUJBQXVCLEVBQ3RDLENBQUM7R0FDRCwyQkFBMkIsQ0FBQyxFQUMxQixlQUFlLFdBQVcsRUFDNUIsQ0FBQztHQUNELHlCQUF5QixDQUFDLEVBQ3hCLGFBQWEsV0FBVyxFQUMxQixDQUFDO0dBQ0QseUJBQXlCLENBQUMsRUFDeEIsZUFBZSx1QkFBdUIsRUFDeEMsQ0FBQztHQUNELHVCQUF1QixDQUFDLEVBQ3RCLGFBQWEsdUJBQXVCLEVBQ3RDLENBQUM7R0FDRCwyQkFBMkIsQ0FBQyxFQUMxQixlQUFlLFdBQVcsRUFDNUIsQ0FBQztHQUNELHlCQUF5QixDQUFDLEVBQ3hCLGFBQWEsV0FBVyxFQUMxQixDQUFDO0dBQ0QscUJBQXFCLENBQUMsRUFDcEIsZUFBZSxDQUFDLHFCQUFxQixnQkFBZ0IsRUFDdkQsQ0FBQztHQUNELDhCQUE4QixDQUFDLEVBQzdCLG9CQUFvQix1QkFBdUIsRUFDN0MsQ0FBQztHQUNELDRCQUE0QixDQUFDLEVBQzNCLGtCQUFrQix1QkFBdUIsRUFDM0MsQ0FBQztHQUNELGdDQUFnQyxDQUFDLEVBQy9CLG9CQUFvQixXQUFXLEVBQ2pDLENBQUM7R0FDRCw4QkFBOEIsQ0FBQyxFQUM3QixrQkFBa0IsV0FBVyxFQUMvQixDQUFDO0dBQ0QsMkJBQTJCLENBQUMsRUFDMUIsZUFBZSxDQUFDLFVBQVUsU0FBUyxFQUNyQyxDQUFDO0dBQ0QsMEJBQTBCLENBQUMsRUFDekIsZUFBZSxDQUFDO0lBQ2QsU0FBUyxDQUFDLFFBQVEsUUFBUTtJQUMxQixVQUFVLENBQUMsUUFBUSxRQUFRO0dBQzdCLENBQUMsRUFDSCxDQUFDO0dBQ0QseUJBQXlCLENBQUMsRUFDeEIsa0JBQWtCLGNBQWMsRUFDbEMsQ0FBQztHQUNELHdCQUF3QixDQUFDLEVBQ3ZCLGNBQWMsQ0FBQyxRQUFRLEVBQ3pCLENBQUM7R0FDRCw2QkFBNkIsQ0FBQyxFQUM1QixtQkFBbUIsdUJBQXVCLEVBQzVDLENBQUM7R0FDRCwyQkFBMkIsQ0FBQyxFQUMxQixpQkFBaUIsdUJBQXVCLEVBQzFDLENBQUM7R0FDRCwrQkFBK0IsQ0FBQyxFQUM5QixtQkFBbUIsV0FBVyxFQUNoQyxDQUFDO0dBQ0QsNkJBQTZCLENBQUMsRUFDNUIsaUJBQWlCLFdBQVcsRUFDOUIsQ0FBQzs7Ozs7R0FLRCxhQUFhLENBQUMsRUFDWixNQUFNO0lBQUM7SUFBUztJQUFhO0dBQU8sRUFDdEMsQ0FBQzs7Ozs7R0FLRCxlQUFlLENBQUMsRUFDZCxlQUFlO0lBQUM7SUFBVTtJQUFXO0lBQVc7SUFBUTtJQUFVO0dBQU0sRUFDMUUsQ0FBQzs7Ozs7R0FLRCxpQkFBaUIsQ0FBQyxFQUNoQixNQUFNLGdCQUFnQixFQUN4QixDQUFDOzs7OztHQUtELGVBQWUsQ0FBQyxFQUNkLE1BQU0sY0FBYyxFQUN0QixDQUFDOzs7OztHQUtELGFBQWEsQ0FBQyxFQUNaLE1BQU0sWUFBWSxFQUNwQixDQUFDOzs7OztHQUtELGFBQWEsQ0FBQyxFQUNaLGFBQWEsQ0FBQyxTQUFTLFdBQVcsRUFDcEMsQ0FBQzs7Ozs7R0FLRCxjQUFjLENBQUMsRUFDYixNQUFNO0lBQUM7SUFBUTtJQUFxQjtHQUFnQixFQUN0RCxDQUFDOzs7OztHQVFELFFBQVEsQ0FBQyxFQUNQLFFBQVE7SUFFUjtJQUFJO0lBQVE7SUFBcUI7R0FBZ0IsRUFDbkQsQ0FBQzs7Ozs7R0FLRCxNQUFNLENBQUMsRUFDTCxNQUFNLFVBQVUsRUFDbEIsQ0FBQzs7Ozs7R0FLRCxZQUFZLENBQUMsRUFDWCxZQUFZO0lBQUM7SUFBVTtJQUFxQjtHQUFnQixFQUM5RCxDQUFDOzs7OztHQUtELFVBQVUsQ0FBQyxFQUNULFVBQVU7SUFBQztJQUFVO0lBQXFCO0dBQWdCLEVBQzVELENBQUM7Ozs7O0dBS0QsZUFBZSxDQUFDLEVBQ2QsZUFBZTtJQUVmO0lBQUk7SUFBUTtJQUFpQjtJQUEyQjtHQUFpQixFQUMzRSxDQUFDOzs7OztHQUtELHFCQUFxQixDQUFDLEVBQ3BCLGVBQWUsV0FBVyxFQUM1QixDQUFDOzs7OztHQUtELFdBQVcsQ0FBQyxFQUNWLFdBQVc7SUFBQztJQUFJO0lBQVU7SUFBcUI7R0FBZ0IsRUFDakUsQ0FBQzs7Ozs7R0FLRCxjQUFjLENBQUMsRUFDYixjQUFjO0lBQUM7SUFBVTtJQUFxQjtHQUFnQixFQUNoRSxDQUFDOzs7OztHQUtELFFBQVEsQ0FBQyxFQUNQLFFBQVE7SUFBQztJQUFJO0lBQVU7SUFBcUI7R0FBZ0IsRUFDOUQsQ0FBQzs7Ozs7R0FLRCxVQUFVLENBQUMsRUFDVCxVQUFVO0lBQUM7SUFBVTtJQUFxQjtHQUFnQixFQUM1RCxDQUFDOzs7OztHQUtELE9BQU8sQ0FBQyxFQUNOLE9BQU87SUFBQztJQUFJO0lBQVU7SUFBcUI7R0FBZ0IsRUFDN0QsQ0FBQzs7Ozs7R0FLRCxtQkFBbUIsQ0FBQyxFQUNsQixtQkFBbUI7SUFFbkI7SUFBSTtJQUFRO0lBQXFCO0dBQWdCLEVBQ25ELENBQUM7Ozs7O0dBS0QsaUJBQWlCLENBQUMsRUFDaEIsaUJBQWlCLFVBQVUsRUFDN0IsQ0FBQzs7Ozs7R0FLRCx1QkFBdUIsQ0FBQyxFQUN0Qix1QkFBdUI7SUFBQztJQUFVO0lBQXFCO0dBQWdCLEVBQ3pFLENBQUM7Ozs7O0dBS0QscUJBQXFCLENBQUMsRUFDcEIscUJBQXFCO0lBQUM7SUFBVTtJQUFxQjtHQUFnQixFQUN2RSxDQUFDOzs7OztHQUtELHNCQUFzQixDQUFDLEVBQ3JCLHNCQUFzQjtJQUFDO0lBQUk7SUFBVTtJQUFxQjtHQUFnQixFQUM1RSxDQUFDOzs7OztHQUtELHVCQUF1QixDQUFDLEVBQ3RCLHVCQUF1QjtJQUFDO0lBQVU7SUFBcUI7R0FBZ0IsRUFDekUsQ0FBQzs7Ozs7R0FLRCxtQkFBbUIsQ0FBQyxFQUNsQixtQkFBbUI7SUFBQztJQUFJO0lBQVU7SUFBcUI7R0FBZ0IsRUFDekUsQ0FBQzs7Ozs7R0FLRCxvQkFBb0IsQ0FBQyxFQUNuQixvQkFBb0I7SUFBQztJQUFVO0lBQXFCO0dBQWdCLEVBQ3RFLENBQUM7Ozs7O0dBS0QscUJBQXFCLENBQUMsRUFDcEIscUJBQXFCO0lBQUM7SUFBVTtJQUFxQjtHQUFnQixFQUN2RSxDQUFDOzs7OztHQUtELGtCQUFrQixDQUFDLEVBQ2pCLGtCQUFrQjtJQUFDO0lBQUk7SUFBVTtJQUFxQjtHQUFnQixFQUN4RSxDQUFDOzs7OztHQVFELG1CQUFtQixDQUFDLEVBQ2xCLFFBQVEsQ0FBQyxZQUFZLFVBQVUsRUFDakMsQ0FBQzs7Ozs7R0FLRCxrQkFBa0IsQ0FBQyxFQUNqQixrQkFBa0Isd0JBQXdCLEVBQzVDLENBQUM7Ozs7O0dBS0Qsb0JBQW9CLENBQUMsRUFDbkIsb0JBQW9CLHdCQUF3QixFQUM5QyxDQUFDOzs7OztHQUtELG9CQUFvQixDQUFDLEVBQ25CLG9CQUFvQix3QkFBd0IsRUFDOUMsQ0FBQzs7Ozs7R0FLRCxnQkFBZ0IsQ0FBQyxFQUNmLE9BQU8sQ0FBQyxRQUFRLE9BQU8sRUFDekIsQ0FBQzs7Ozs7R0FLRCxTQUFTLENBQUMsRUFDUixTQUFTLENBQUMsT0FBTyxRQUFRLEVBQzNCLENBQUM7Ozs7O0dBUUQsWUFBWSxDQUFDLEVBQ1gsWUFBWTtJQUFDO0lBQUk7SUFBTztJQUFVO0lBQVc7SUFBVTtJQUFhO0lBQVE7SUFBcUI7R0FBZ0IsRUFDbkgsQ0FBQzs7Ozs7R0FLRCx1QkFBdUIsQ0FBQyxFQUN0QixZQUFZLENBQUMsVUFBVSxVQUFVLEVBQ25DLENBQUM7Ozs7O0dBS0QsVUFBVSxDQUFDLEVBQ1QsVUFBVTtJQUFDO0lBQVU7SUFBVztJQUFxQjtHQUFnQixFQUN2RSxDQUFDOzs7OztHQUtELE1BQU0sQ0FBQyxFQUNMLE1BQU07SUFBQztJQUFVO0lBQVc7SUFBVztJQUFxQjtHQUFnQixFQUM5RSxDQUFDOzs7OztHQUtELE9BQU8sQ0FBQyxFQUNOLE9BQU87SUFBQztJQUFVO0lBQXFCO0dBQWdCLEVBQ3pELENBQUM7Ozs7O0dBS0QsU0FBUyxDQUFDLEVBQ1IsU0FBUztJQUFDO0lBQVE7SUFBYztJQUFxQjtHQUFnQixFQUN2RSxDQUFDOzs7OztHQVFELFVBQVUsQ0FBQyxFQUNULFVBQVUsQ0FBQyxVQUFVLFNBQVMsRUFDaEMsQ0FBQzs7Ozs7R0FLRCxhQUFhLENBQUMsRUFDWixhQUFhO0lBQUM7SUFBa0I7SUFBcUI7R0FBZ0IsRUFDdkUsQ0FBQzs7Ozs7R0FLRCxzQkFBc0IsQ0FBQyxFQUNyQixzQkFBc0IsMkJBQTJCLEVBQ25ELENBQUM7Ozs7O0dBS0QsUUFBUSxDQUFDLEVBQ1AsUUFBUSxZQUFZLEVBQ3RCLENBQUM7Ozs7O0dBS0QsWUFBWSxDQUFDLEVBQ1gsWUFBWSxZQUFZLEVBQzFCLENBQUM7Ozs7O0dBS0QsWUFBWSxDQUFDLEVBQ1gsWUFBWSxZQUFZLEVBQzFCLENBQUM7Ozs7O0dBS0QsWUFBWSxDQUFDLEVBQ1gsWUFBWSxZQUFZLEVBQzFCLENBQUM7Ozs7O0dBS0QsT0FBTyxDQUFDLEVBQ04sT0FBTyxXQUFXLEVBQ3BCLENBQUM7Ozs7O0dBS0QsV0FBVyxDQUFDLEVBQ1YsV0FBVyxXQUFXLEVBQ3hCLENBQUM7Ozs7O0dBS0QsV0FBVyxDQUFDLEVBQ1YsV0FBVyxXQUFXLEVBQ3hCLENBQUM7Ozs7O0dBS0QsV0FBVyxDQUFDLEVBQ1YsV0FBVyxXQUFXLEVBQ3hCLENBQUM7Ozs7O0dBS0QsWUFBWSxDQUFDLFVBQVU7Ozs7O0dBS3ZCLE1BQU0sQ0FBQyxFQUNMLE1BQU0sVUFBVSxFQUNsQixDQUFDOzs7OztHQUtELFVBQVUsQ0FBQyxFQUNULFVBQVUsVUFBVSxFQUN0QixDQUFDOzs7OztHQUtELFVBQVUsQ0FBQyxFQUNULFVBQVUsVUFBVSxFQUN0QixDQUFDOzs7OztHQUtELFdBQVcsQ0FBQyxFQUNWLFdBQVc7SUFBQztJQUFxQjtJQUFrQjtJQUFJO0lBQVE7SUFBTztHQUFLLEVBQzdFLENBQUM7Ozs7O0dBS0Qsb0JBQW9CLENBQUMsRUFDbkIsUUFBUSwyQkFBMkIsRUFDckMsQ0FBQzs7Ozs7R0FLRCxtQkFBbUIsQ0FBQyxFQUNsQixXQUFXLENBQUMsTUFBTSxNQUFNLEVBQzFCLENBQUM7Ozs7O0dBS0QsV0FBVyxDQUFDLEVBQ1YsV0FBVyxlQUFlLEVBQzVCLENBQUM7Ozs7O0dBS0QsZUFBZSxDQUFDLEVBQ2QsZUFBZSxlQUFlLEVBQ2hDLENBQUM7Ozs7O0dBS0QsZUFBZSxDQUFDLEVBQ2QsZUFBZSxlQUFlLEVBQ2hDLENBQUM7Ozs7O0dBS0QsZUFBZSxDQUFDLEVBQ2QsZUFBZSxlQUFlLEVBQ2hDLENBQUM7Ozs7O0dBS0Qsa0JBQWtCLENBQUMsZ0JBQWdCOzs7OztHQUtuQyxNQUFNLENBQUMsRUFDTCxNQUFNO0lBQUM7SUFBVztJQUFxQjtHQUFnQixFQUN6RCxDQUFDOzs7OztHQVFELFFBQVEsQ0FBQyxFQUNQLFFBQVEsV0FBVyxFQUNyQixDQUFDOzs7OztHQUtELFlBQVksQ0FBQyxFQUNYLFlBQVksQ0FBQyxRQUFRLE1BQU0sRUFDN0IsQ0FBQzs7Ozs7R0FLRCxlQUFlLENBQUMsRUFDZCxPQUFPLFdBQVcsRUFDcEIsQ0FBQzs7Ozs7R0FLRCxnQkFBZ0IsQ0FBQyxFQUNmLFFBQVE7SUFBQztJQUFVO0lBQVE7SUFBUztJQUFjO0lBQWE7R0FBWSxFQUM3RSxDQUFDOzs7OztHQUtELFFBQVEsQ0FBQyxFQUNQLFFBQVE7SUFBQztJQUFRO0lBQVc7SUFBVztJQUFRO0lBQVE7SUFBUTtJQUFRO0lBQWU7SUFBUTtJQUFnQjtJQUFZO0lBQVE7SUFBYTtJQUFpQjtJQUFTO0lBQVE7SUFBVztJQUFRO0lBQVk7SUFBYztJQUFjO0lBQWM7SUFBWTtJQUFZO0lBQVk7SUFBWTtJQUFhO0lBQWE7SUFBYTtJQUFhO0lBQWE7SUFBYTtJQUFlO0lBQWU7SUFBVztJQUFZO0lBQXFCO0dBQWdCLEVBQ3BkLENBQUM7Ozs7O0dBS0QsZ0JBQWdCLENBQUMsRUFDZixnQkFBZ0IsQ0FBQyxTQUFTLFNBQVMsRUFDckMsQ0FBQzs7Ozs7R0FLRCxrQkFBa0IsQ0FBQyxFQUNqQixrQkFBa0IsQ0FBQyxRQUFRLE1BQU0sRUFDbkMsQ0FBQzs7Ozs7R0FLRCxRQUFRLENBQUMsRUFDUCxRQUFRO0lBQUM7SUFBUTtJQUFJO0lBQUs7R0FBRyxFQUMvQixDQUFDOzs7OztHQUtELG1CQUFtQixDQUFDLEVBQ2xCLFFBQVEsQ0FBQyxRQUFRLFFBQVEsRUFDM0IsQ0FBQzs7Ozs7R0FLRCx5QkFBeUIsQ0FBQyxFQUN4QixtQkFBbUIsV0FBVyxFQUNoQyxDQUFDOzs7OztHQUtELHlCQUF5QixDQUFDLEVBQ3hCLG1CQUFtQixXQUFXLEVBQ2hDLENBQUM7Ozs7O0dBS0Qsb0JBQW9CLENBQUMsRUFDbkIsb0JBQW9CO0lBQUM7SUFBUTtJQUFVO0dBQU0sRUFDL0MsQ0FBQzs7Ozs7R0FLRCxlQUFlLENBQUMsRUFDZCxXQUFXO0lBQUM7SUFBUTtJQUFRO0dBQU0sRUFDcEMsQ0FBQzs7Ozs7R0FLRCxZQUFZLENBQUMsRUFDWCxZQUFZLHdCQUF3QixFQUN0QyxDQUFDOzs7OztHQUtELGFBQWEsQ0FBQyxFQUNaLGFBQWEsd0JBQXdCLEVBQ3ZDLENBQUM7Ozs7O0dBS0QsYUFBYSxDQUFDLEVBQ1osYUFBYSx3QkFBd0IsRUFDdkMsQ0FBQzs7Ozs7R0FLRCxhQUFhLENBQUMsRUFDWixhQUFhLHdCQUF3QixFQUN2QyxDQUFDOzs7OztHQUtELGFBQWEsQ0FBQyxFQUNaLGFBQWEsd0JBQXdCLEVBQ3ZDLENBQUM7Ozs7O0dBS0QsY0FBYyxDQUFDLEVBQ2IsY0FBYyx3QkFBd0IsRUFDeEMsQ0FBQzs7Ozs7R0FLRCxjQUFjLENBQUMsRUFDYixjQUFjLHdCQUF3QixFQUN4QyxDQUFDOzs7OztHQUtELGFBQWEsQ0FBQyxFQUNaLGFBQWEsd0JBQXdCLEVBQ3ZDLENBQUM7Ozs7O0dBS0QsYUFBYSxDQUFDLEVBQ1osYUFBYSx3QkFBd0IsRUFDdkMsQ0FBQzs7Ozs7R0FLRCxhQUFhLENBQUMsRUFDWixhQUFhLHdCQUF3QixFQUN2QyxDQUFDOzs7OztHQUtELGFBQWEsQ0FBQyxFQUNaLGFBQWEsd0JBQXdCLEVBQ3ZDLENBQUM7Ozs7O0dBS0QsWUFBWSxDQUFDLEVBQ1gsWUFBWSx3QkFBd0IsRUFDdEMsQ0FBQzs7Ozs7R0FLRCxhQUFhLENBQUMsRUFDWixhQUFhLHdCQUF3QixFQUN2QyxDQUFDOzs7OztHQUtELGFBQWEsQ0FBQyxFQUNaLGFBQWEsd0JBQXdCLEVBQ3ZDLENBQUM7Ozs7O0dBS0QsYUFBYSxDQUFDLEVBQ1osYUFBYSx3QkFBd0IsRUFDdkMsQ0FBQzs7Ozs7R0FLRCxhQUFhLENBQUMsRUFDWixhQUFhLHdCQUF3QixFQUN2QyxDQUFDOzs7OztHQUtELGNBQWMsQ0FBQyxFQUNiLGNBQWMsd0JBQXdCLEVBQ3hDLENBQUM7Ozs7O0dBS0QsY0FBYyxDQUFDLEVBQ2IsY0FBYyx3QkFBd0IsRUFDeEMsQ0FBQzs7Ozs7R0FLRCxhQUFhLENBQUMsRUFDWixhQUFhLHdCQUF3QixFQUN2QyxDQUFDOzs7OztHQUtELGFBQWEsQ0FBQyxFQUNaLGFBQWEsd0JBQXdCLEVBQ3ZDLENBQUM7Ozs7O0dBS0QsYUFBYSxDQUFDLEVBQ1osYUFBYSx3QkFBd0IsRUFDdkMsQ0FBQzs7Ozs7R0FLRCxhQUFhLENBQUMsRUFDWixhQUFhLHdCQUF3QixFQUN2QyxDQUFDOzs7OztHQUtELGNBQWMsQ0FBQyxFQUNiLE1BQU07SUFBQztJQUFTO0lBQU87SUFBVTtHQUFZLEVBQy9DLENBQUM7Ozs7O0dBS0QsYUFBYSxDQUFDLEVBQ1osTUFBTSxDQUFDLFVBQVUsUUFBUSxFQUMzQixDQUFDOzs7OztHQUtELGFBQWEsQ0FBQyxFQUNaLE1BQU07SUFBQztJQUFRO0lBQUs7SUFBSztHQUFNLEVBQ2pDLENBQUM7Ozs7O0dBS0QsbUJBQW1CLENBQUMsRUFDbEIsTUFBTSxDQUFDLGFBQWEsV0FBVyxFQUNqQyxDQUFDOzs7OztHQUtELE9BQU8sQ0FBQyxFQUNOLE9BQU87SUFBQztJQUFRO0lBQVE7R0FBYyxFQUN4QyxDQUFDOzs7OztHQUtELFdBQVcsQ0FBQyxFQUNWLGFBQWE7SUFBQztJQUFLO0lBQVE7R0FBTyxFQUNwQyxDQUFDOzs7OztHQUtELFdBQVcsQ0FBQyxFQUNWLGFBQWE7SUFBQztJQUFLO0lBQU07R0FBTSxFQUNqQyxDQUFDOzs7OztHQUtELFlBQVksQ0FBQyxrQkFBa0I7Ozs7O0dBSy9CLFFBQVEsQ0FBQyxFQUNQLFFBQVE7SUFBQztJQUFRO0lBQVE7SUFBTztHQUFNLEVBQ3hDLENBQUM7Ozs7O0dBS0QsZUFBZSxDQUFDLEVBQ2QsZUFBZTtJQUFDO0lBQVE7SUFBVTtJQUFZO0lBQWE7SUFBcUI7R0FBZ0IsRUFDbEcsQ0FBQzs7Ozs7R0FRRCxNQUFNLENBQUMsRUFDTCxNQUFNLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxFQUNoQyxDQUFDOzs7OztHQUtELFlBQVksQ0FBQyxFQUNYLFFBQVE7SUFBQztJQUFVO0lBQTJCO0lBQW1CO0dBQWlCLEVBQ3BGLENBQUM7Ozs7O0dBS0QsUUFBUSxDQUFDLEVBQ1AsUUFBUSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUMsRUFDbEMsQ0FBQzs7Ozs7R0FRRCx1QkFBdUIsQ0FBQyxFQUN0Qix1QkFBdUIsQ0FBQyxRQUFRLE1BQU0sRUFDeEMsQ0FBQztFQUNIO0VBQ0Esd0JBQXdCO0dBQ3RCLG1CQUFtQixDQUFDLGdCQUFnQjtHQUNwQyxVQUFVLENBQUMsY0FBYyxZQUFZO0dBQ3JDLFlBQVksQ0FBQyxnQkFBZ0IsY0FBYztHQUMzQyxPQUFPO0lBQUM7SUFBVztJQUFXO0lBQVk7SUFBWTtJQUFTO0lBQU87SUFBTztJQUFTO0lBQVU7R0FBTTtHQUN0RyxXQUFXLENBQUMsU0FBUyxNQUFNO0dBQzNCLFdBQVcsQ0FBQyxPQUFPLFFBQVE7R0FDM0IsTUFBTTtJQUFDO0lBQVM7SUFBUTtHQUFRO0dBQ2hDLEtBQUssQ0FBQyxTQUFTLE9BQU87R0FDdEIsR0FBRztJQUFDO0lBQU07SUFBTTtJQUFNO0lBQU07SUFBTztJQUFPO0lBQU07SUFBTTtJQUFNO0dBQUk7R0FDaEUsSUFBSSxDQUFDLE1BQU0sSUFBSTtHQUNmLElBQUksQ0FBQyxNQUFNLElBQUk7R0FDZixHQUFHO0lBQUM7SUFBTTtJQUFNO0lBQU07SUFBTTtJQUFPO0lBQU87SUFBTTtJQUFNO0lBQU07R0FBSTtHQUNoRSxJQUFJLENBQUMsTUFBTSxJQUFJO0dBQ2YsSUFBSSxDQUFDLE1BQU0sSUFBSTtHQUNmLE1BQU0sQ0FBQyxLQUFLLEdBQUc7R0FDZixhQUFhLENBQUMsU0FBUztHQUN2QixjQUFjO0lBQUM7SUFBZTtJQUFvQjtJQUFjO0lBQWU7R0FBYztHQUM3RixlQUFlLENBQUMsWUFBWTtHQUM1QixvQkFBb0IsQ0FBQyxZQUFZO0dBQ2pDLGNBQWMsQ0FBQyxZQUFZO0dBQzNCLGVBQWUsQ0FBQyxZQUFZO0dBQzVCLGdCQUFnQixDQUFDLFlBQVk7R0FDN0IsY0FBYyxDQUFDLFdBQVcsVUFBVTtHQUNwQyxTQUFTO0lBQUM7SUFBYTtJQUFhO0lBQWE7SUFBYTtJQUFhO0lBQWE7SUFBYztJQUFjO0lBQWM7SUFBYztJQUFjO0lBQWM7SUFBYztHQUFZO0dBQ3RNLGFBQWEsQ0FBQyxjQUFjLFlBQVk7R0FDeEMsYUFBYSxDQUFDLGNBQWMsWUFBWTtHQUN4QyxhQUFhLENBQUMsY0FBYyxZQUFZO0dBQ3hDLGFBQWEsQ0FBQyxjQUFjLFlBQVk7R0FDeEMsYUFBYSxDQUFDLGNBQWMsWUFBWTtHQUN4QyxhQUFhLENBQUMsY0FBYyxZQUFZO0dBQ3hDLGtCQUFrQixDQUFDLG9CQUFvQixrQkFBa0I7R0FDekQsWUFBWTtJQUFDO0lBQWM7SUFBYztJQUFjO0lBQWM7SUFBZTtJQUFlO0lBQWM7SUFBYztJQUFjO0dBQVk7R0FDekosY0FBYyxDQUFDLGNBQWMsWUFBWTtHQUN6QyxjQUFjLENBQUMsY0FBYyxZQUFZO0dBQ3pDLGdCQUFnQjtJQUFDO0lBQWtCO0lBQWtCO0lBQWtCO0lBQWtCO0lBQW1CO0lBQW1CO0lBQWtCO0lBQWtCO0lBQWtCO0dBQWdCO0dBQ3JNLGtCQUFrQixDQUFDLGtCQUFrQixnQkFBZ0I7R0FDckQsa0JBQWtCLENBQUMsa0JBQWtCLGdCQUFnQjtHQUNyRCxXQUFXO0lBQUM7SUFBZTtJQUFlO0dBQWdCO0dBQzFELGtCQUFrQjtJQUFDO0lBQWE7SUFBZTtJQUFlO0dBQWE7R0FDM0UsWUFBWTtJQUFDO0lBQWE7SUFBYTtJQUFhO0lBQWE7SUFBYztJQUFjO0lBQWE7SUFBYTtJQUFhO0dBQVc7R0FDL0ksYUFBYSxDQUFDLGFBQWEsV0FBVztHQUN0QyxhQUFhLENBQUMsYUFBYSxXQUFXO0dBQ3RDLFlBQVk7SUFBQztJQUFhO0lBQWE7SUFBYTtJQUFhO0lBQWM7SUFBYztJQUFhO0lBQWE7SUFBYTtHQUFXO0dBQy9JLGFBQWEsQ0FBQyxhQUFhLFdBQVc7R0FDdEMsYUFBYSxDQUFDLGFBQWEsV0FBVztHQUN0QyxPQUFPO0lBQUM7SUFBVztJQUFXO0dBQVU7R0FDeEMsV0FBVyxDQUFDLE9BQU87R0FDbkIsV0FBVyxDQUFDLE9BQU87R0FDbkIsWUFBWSxDQUFDLE9BQU87RUFDdEI7RUFDQSxnQ0FBZ0MsRUFDOUIsYUFBYSxDQUFDLFNBQVMsRUFDekI7RUFDQSwwQkFBMEIsQ0FBQyxnQkFBZ0I7RUFDM0MseUJBQXlCO0dBQUM7R0FBSztHQUFNO0dBQVM7R0FBWTtHQUFVO0dBQW1CO0dBQVE7R0FBZ0I7R0FBYztHQUFVO0dBQWU7RUFBVztDQUNuSztBQUNGOzs7OztBQU1BLElBQU0sZ0JBQWdCLFlBQVksRUFDaEMsV0FDQSxRQUNBLDRCQUNBLFNBQVMsQ0FBQyxHQUNWLFdBQVcsQ0FBQyxRQUNSO0NBQ0osaUJBQWlCLFlBQVksYUFBYSxTQUFTO0NBQ25ELGlCQUFpQixZQUFZLFVBQVUsTUFBTTtDQUM3QyxpQkFBaUIsWUFBWSw4QkFBOEIsMEJBQTBCO0NBQ3JGLHlCQUF5QixXQUFXLE9BQU8sU0FBUyxLQUFLO0NBQ3pELHlCQUF5QixXQUFXLGFBQWEsU0FBUyxXQUFXO0NBQ3JFLHlCQUF5QixXQUFXLHdCQUF3QixTQUFTLHNCQUFzQjtDQUMzRix5QkFBeUIsV0FBVyxnQ0FBZ0MsU0FBUyw4QkFBOEI7Q0FDM0csaUJBQWlCLFlBQVksNEJBQTRCLFNBQVMsd0JBQXdCO0NBQzFGLGlCQUFpQixZQUFZLDJCQUEyQixTQUFTLHVCQUF1QjtDQUN4RixzQkFBc0IsV0FBVyxPQUFPLE9BQU8sS0FBSztDQUNwRCxzQkFBc0IsV0FBVyxhQUFhLE9BQU8sV0FBVztDQUNoRSxzQkFBc0IsV0FBVyx3QkFBd0IsT0FBTyxzQkFBc0I7Q0FDdEYsc0JBQXNCLFdBQVcsZ0NBQWdDLE9BQU8sOEJBQThCO0NBQ3RHLHFCQUFxQixZQUFZLFFBQVEsMEJBQTBCO0NBQ25FLHFCQUFxQixZQUFZLFFBQVEseUJBQXlCO0NBQ2xFLE9BQU87QUFDVDtBQUNBLElBQU0sb0JBQW9CLFlBQVksYUFBYSxrQkFBa0I7Q0FDbkUsSUFBSSxrQkFBa0IsS0FBQSxHQUNwQixXQUFXLGVBQWU7QUFFOUI7QUFDQSxJQUFNLDRCQUE0QixZQUFZLG1CQUFtQjtDQUMvRCxJQUFJLGdCQUNGLEtBQUssTUFBTSxPQUFPLGdCQUNoQixpQkFBaUIsWUFBWSxLQUFLLGVBQWUsSUFBSTtBQUczRDtBQUNBLElBQU0seUJBQXlCLFlBQVksZ0JBQWdCO0NBQ3pELElBQUksYUFDRixLQUFLLE1BQU0sT0FBTyxhQUNoQixxQkFBcUIsWUFBWSxhQUFhLEdBQUc7QUFHdkQ7QUFDQSxJQUFNLHdCQUF3QixZQUFZLGFBQWEsUUFBUTtDQUM3RCxNQUFNLGFBQWEsWUFBWTtDQUMvQixJQUFJLGVBQWUsS0FBQSxHQUNqQixXQUFXLE9BQU8sV0FBVyxPQUFPLFdBQVcsSUFBSSxDQUFDLE9BQU8sVUFBVSxJQUFJO0FBRTdFO0FBQ0EsSUFBTSx1QkFBdUIsaUJBQWlCLEdBQUcsaUJBQWlCLE9BQU8sb0JBQW9CLGFBQWEsb0JBQW9CLGtCQUFrQixpQkFBaUIsR0FBRyxZQUFZLElBQUksMEJBQTBCLGFBQWEsaUJBQWlCLEdBQUcsZUFBZSxHQUFHLEdBQUcsWUFBWTtBQUNoUixJQUFNLFVBQXVCLGtDQUFvQixnQkFBZ0IifQ==