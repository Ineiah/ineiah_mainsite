/**
* @vue/shared v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
// @__NO_SIDE_EFFECTS__
function makeMap(str) {
	const map = /* @__PURE__ */ Object.create(null);
	for (const key of str.split(",")) map[key] = 1;
	return (val) => val in map;
}
const EMPTY_OBJ = !!("development" !== "production") ? Object.freeze({}) : {};
const EMPTY_ARR = !!("development" !== "production") ? Object.freeze([]) : [];
const NOOP = () => {};
const NO = () => false;
const isOn = (key) => key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && (key.charCodeAt(2) > 122 || key.charCodeAt(2) < 97);
const isModelListener = (key) => key.startsWith("onUpdate:");
const extend = Object.assign;
const remove = (arr, el) => {
	const i = arr.indexOf(el);
	if (i > -1) {
		arr.splice(i, 1);
	}
};
const hasOwnProperty = Object.prototype.hasOwnProperty;
const hasOwn = (val, key) => hasOwnProperty.call(val, key);
const isArray = Array.isArray;
const isMap = (val) => toTypeString(val) === "[object Map]";
const isSet = (val) => toTypeString(val) === "[object Set]";
const isDate = (val) => toTypeString(val) === "[object Date]";
const isRegExp = (val) => toTypeString(val) === "[object RegExp]";
const isFunction = (val) => typeof val === "function";
const isString = (val) => typeof val === "string";
const isSymbol = (val) => typeof val === "symbol";
const isObject = (val) => val !== null && typeof val === "object";
const isPromise = (val) => {
	return (isObject(val) || isFunction(val)) && isFunction(val.then) && isFunction(val.catch);
};
const objectToString = Object.prototype.toString;
const toTypeString = (value) => objectToString.call(value);
const toRawType = (value) => {
	return toTypeString(value).slice(8, -1);
};
const isPlainObject = (val) => toTypeString(val) === "[object Object]";
const isIntegerKey = (key) => isString(key) && key !== "NaN" && key[0] !== "-" && "" + parseInt(key, 10) === key;
const isReservedProp = /* @__PURE__ */ makeMap(
	// the leading comma is intentional so empty string "" is also included
	",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"
);
const isBuiltInDirective = /* @__PURE__ */ makeMap("bind,cloak,else-if,else,for,html,if,model,on,once,pre,show,slot,text,memo");
const cacheStringFunction = (fn) => {
	const cache = /* @__PURE__ */ Object.create(null);
	return ((str) => {
		const hit = cache[str];
		return hit || (cache[str] = fn(str));
	});
};
const camelizeRE = /-\w/g;
const camelize = cacheStringFunction((str) => {
	return str.replace(camelizeRE, (c) => c.slice(1).toUpperCase());
});
const hyphenateRE = /\B([A-Z])/g;
const hyphenate = cacheStringFunction((str) => str.replace(hyphenateRE, "-$1").toLowerCase());
const capitalize = cacheStringFunction((str) => {
	return str.charAt(0).toUpperCase() + str.slice(1);
});
const toHandlerKey = cacheStringFunction((str) => {
	const s = str ? `on${capitalize(str)}` : ``;
	return s;
});
const hasChanged = (value, oldValue) => !Object.is(value, oldValue);
const invokeArrayFns = (fns, ...arg) => {
	for (let i = 0; i < fns.length; i++) {
		fns[i](...arg);
	}
};
const def = (obj, key, value, writable = false) => {
	Object.defineProperty(obj, key, {
		configurable: true,
		enumerable: false,
		writable,
		value
	});
};
const looseToNumber = (val) => {
	const n = parseFloat(val);
	return isNaN(n) ? val : n;
};
const toNumber = (val) => {
	const n = isString(val) ? Number(val) : NaN;
	return isNaN(n) ? val : n;
};
let _globalThis;
const getGlobalThis = () => {
	return _globalThis || (_globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
};
const identRE = /^[_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*$/;
function genPropsAccessExp(name) {
	return identRE.test(name) ? `__props.${name}` : `__props[${JSON.stringify(name)}]`;
}
function genCacheKey(source, options) {
	return source + JSON.stringify(options, (_, val) => typeof val === "function" ? val.toString() : val);
}
const PatchFlags = {
	"TEXT": 1,
	"1": "TEXT",
	"CLASS": 2,
	"2": "CLASS",
	"STYLE": 4,
	"4": "STYLE",
	"PROPS": 8,
	"8": "PROPS",
	"FULL_PROPS": 16,
	"16": "FULL_PROPS",
	"NEED_HYDRATION": 32,
	"32": "NEED_HYDRATION",
	"STABLE_FRAGMENT": 64,
	"64": "STABLE_FRAGMENT",
	"KEYED_FRAGMENT": 128,
	"128": "KEYED_FRAGMENT",
	"UNKEYED_FRAGMENT": 256,
	"256": "UNKEYED_FRAGMENT",
	"NEED_PATCH": 512,
	"512": "NEED_PATCH",
	"DYNAMIC_SLOTS": 1024,
	"1024": "DYNAMIC_SLOTS",
	"DEV_ROOT_FRAGMENT": 2048,
	"2048": "DEV_ROOT_FRAGMENT",
	"CACHED": -1,
	"-1": "CACHED",
	"BAIL": -2,
	"-2": "BAIL"
};
const PatchFlagNames = {
	[1]: `TEXT`,
	[2]: `CLASS`,
	[4]: `STYLE`,
	[8]: `PROPS`,
	[16]: `FULL_PROPS`,
	[32]: `NEED_HYDRATION`,
	[64]: `STABLE_FRAGMENT`,
	[128]: `KEYED_FRAGMENT`,
	[256]: `UNKEYED_FRAGMENT`,
	[512]: `NEED_PATCH`,
	[1024]: `DYNAMIC_SLOTS`,
	[2048]: `DEV_ROOT_FRAGMENT`,
	[-1]: `CACHED`,
	[-2]: `BAIL`
};
const ShapeFlags = {
	"ELEMENT": 1,
	"1": "ELEMENT",
	"FUNCTIONAL_COMPONENT": 2,
	"2": "FUNCTIONAL_COMPONENT",
	"STATEFUL_COMPONENT": 4,
	"4": "STATEFUL_COMPONENT",
	"TEXT_CHILDREN": 8,
	"8": "TEXT_CHILDREN",
	"ARRAY_CHILDREN": 16,
	"16": "ARRAY_CHILDREN",
	"SLOTS_CHILDREN": 32,
	"32": "SLOTS_CHILDREN",
	"TELEPORT": 64,
	"64": "TELEPORT",
	"SUSPENSE": 128,
	"128": "SUSPENSE",
	"COMPONENT_SHOULD_KEEP_ALIVE": 256,
	"256": "COMPONENT_SHOULD_KEEP_ALIVE",
	"COMPONENT_KEPT_ALIVE": 512,
	"512": "COMPONENT_KEPT_ALIVE",
	"COMPONENT": 6,
	"6": "COMPONENT"
};
const SlotFlags = {
	"STABLE": 1,
	"1": "STABLE",
	"DYNAMIC": 2,
	"2": "DYNAMIC",
	"FORWARDED": 3,
	"3": "FORWARDED"
};
const slotFlagsText = {
	[1]: "STABLE",
	[2]: "DYNAMIC",
	[3]: "FORWARDED"
};
const GLOBALS_ALLOWED = "Infinity,undefined,NaN,isFinite,isNaN,parseFloat,parseInt,decodeURI,decodeURIComponent,encodeURI,encodeURIComponent,Math,Number,Date,Array,Object,Boolean,String,RegExp,Map,Set,JSON,Intl,BigInt,console,Error,Symbol";
const isGloballyAllowed = /* @__PURE__ */ makeMap(GLOBALS_ALLOWED);
const isGloballyWhitelisted = isGloballyAllowed;
const range = 2;
function generateCodeFrame(source, start = 0, end = source.length) {
	start = Math.max(0, Math.min(start, source.length));
	end = Math.max(0, Math.min(end, source.length));
	if (start > end) return "";
	let lines = source.split(/(\r?\n)/);
	const newlineSequences = lines.filter((_, idx) => idx % 2 === 1);
	lines = lines.filter((_, idx) => idx % 2 === 0);
	let count = 0;
	const res = [];
	for (let i = 0; i < lines.length; i++) {
		count += lines[i].length + (newlineSequences[i] && newlineSequences[i].length || 0);
		if (count >= start) {
			for (let j = i - range; j <= i + range || end > count; j++) {
				if (j < 0 || j >= lines.length) continue;
				const line = j + 1;
				res.push(`${line}${" ".repeat(Math.max(3 - String(line).length, 0))}|  ${lines[j]}`);
				const lineLength = lines[j].length;
				const newLineSeqLength = newlineSequences[j] && newlineSequences[j].length || 0;
				if (j === i) {
					const pad = start - (count - (lineLength + newLineSeqLength));
					const length = Math.max(1, end > count ? lineLength - pad : end - start);
					res.push(`   |  ` + " ".repeat(pad) + "^".repeat(length));
				} else if (j > i) {
					if (end > count) {
						const length = Math.max(Math.min(end - count, lineLength), 1);
						res.push(`   |  ` + "^".repeat(length));
					}
					count += lineLength + newLineSeqLength;
				}
			}
			break;
		}
	}
	return res.join("\n");
}
function normalizeStyle(value) {
	if (isArray(value)) {
		const res = {};
		for (let i = 0; i < value.length; i++) {
			const item = value[i];
			const normalized = isString(item) ? parseStringStyle(item) : normalizeStyle(item);
			if (normalized) {
				for (const key in normalized) {
					res[key] = normalized[key];
				}
			}
		}
		return res;
	} else if (isString(value) || isObject(value)) {
		return value;
	}
}
const listDelimiterRE = /;(?![^(]*\))/g;
const propertyDelimiterRE = /:([^]+)/;
const styleCommentRE = /\/\*[^]*?\*\//g;
function parseStringStyle(cssText) {
	const ret = {};
	cssText.replace(styleCommentRE, "").split(listDelimiterRE).forEach((item) => {
		if (item) {
			const tmp = item.split(propertyDelimiterRE);
			tmp.length > 1 && (ret[tmp[0].trim()] = tmp[1].trim());
		}
	});
	return ret;
}
function stringifyStyle(styles) {
	if (!styles) return "";
	if (isString(styles)) return styles;
	let ret = "";
	for (const key in styles) {
		const value = styles[key];
		if (isString(value) || typeof value === "number") {
			const normalizedKey = key.startsWith(`--`) ? key : hyphenate(key);
			ret += `${normalizedKey}:${value};`;
		}
	}
	return ret;
}
function normalizeClass(value) {
	let res = "";
	if (isString(value)) {
		res = value;
	} else if (isArray(value)) {
		for (let i = 0; i < value.length; i++) {
			const normalized = normalizeClass(value[i]);
			if (normalized) {
				res += normalized + " ";
			}
		}
	} else if (isObject(value)) {
		for (const name in value) {
			if (value[name]) {
				res += name + " ";
			}
		}
	}
	return res.trim();
}
function normalizeProps(props) {
	if (!props) return null;
	let { class: klass, style } = props;
	if (klass && !isString(klass)) {
		props.class = normalizeClass(klass);
	}
	if (style) {
		props.style = normalizeStyle(style);
	}
	return props;
}
const HTML_TAGS = "html,body,base,head,link,meta,style,title,address,article,aside,footer,header,hgroup,h1,h2,h3,h4,h5,h6,nav,section,div,dd,dl,dt,figcaption,figure,picture,hr,img,li,main,ol,p,pre,ul,a,b,abbr,bdi,bdo,br,cite,code,data,dfn,em,i,kbd,mark,q,rp,rt,ruby,s,samp,small,span,strong,sub,sup,time,u,var,wbr,area,audio,map,track,video,embed,object,param,source,canvas,script,noscript,del,ins,caption,col,colgroup,table,thead,tbody,td,th,tr,button,datalist,fieldset,form,input,label,legend,meter,optgroup,option,output,progress,select,textarea,details,dialog,menu,summary,template,blockquote,iframe,tfoot";
const SVG_TAGS = "svg,animate,animateMotion,animateTransform,circle,clipPath,color-profile,defs,desc,discard,ellipse,feBlend,feColorMatrix,feComponentTransfer,feComposite,feConvolveMatrix,feDiffuseLighting,feDisplacementMap,feDistantLight,feDropShadow,feFlood,feFuncA,feFuncB,feFuncG,feFuncR,feGaussianBlur,feImage,feMerge,feMergeNode,feMorphology,feOffset,fePointLight,feSpecularLighting,feSpotLight,feTile,feTurbulence,filter,foreignObject,g,hatch,hatchpath,image,line,linearGradient,marker,mask,mesh,meshgradient,meshpatch,meshrow,metadata,mpath,path,pattern,polygon,polyline,radialGradient,rect,set,solidcolor,stop,switch,symbol,text,textPath,title,tspan,unknown,use,view";
const MATH_TAGS = "annotation,annotation-xml,maction,maligngroup,malignmark,math,menclose,merror,mfenced,mfrac,mfraction,mglyph,mi,mlabeledtr,mlongdiv,mmultiscripts,mn,mo,mover,mpadded,mphantom,mprescripts,mroot,mrow,ms,mscarries,mscarry,msgroup,msline,mspace,msqrt,msrow,mstack,mstyle,msub,msubsup,msup,mtable,mtd,mtext,mtr,munder,munderover,none,semantics";
const VOID_TAGS = "area,base,br,col,embed,hr,img,input,link,meta,param,source,track,wbr";
const isHTMLTag = /* @__PURE__ */ makeMap(HTML_TAGS);
const isSVGTag = /* @__PURE__ */ makeMap(SVG_TAGS);
const isMathMLTag = /* @__PURE__ */ makeMap(MATH_TAGS);
const isVoidTag = /* @__PURE__ */ makeMap(VOID_TAGS);
const specialBooleanAttrs = `itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly`;
const isSpecialBooleanAttr = /* @__PURE__ */ makeMap(specialBooleanAttrs);
const isBooleanAttr = /* @__PURE__ */ makeMap(specialBooleanAttrs + `,async,autofocus,autoplay,controls,default,defer,disabled,hidden,inert,loop,open,required,reversed,scoped,seamless,checked,muted,multiple,selected`);
function includeBooleanAttr(value) {
	return !!value || value === "";
}
const unsafeAttrCharRE = /[>/="'\u0009\u000a\u000c\u0020]/;
const attrValidationCache = {};
function isSSRSafeAttrName(name) {
	if (attrValidationCache.hasOwnProperty(name)) {
		return attrValidationCache[name];
	}
	const isUnsafe = unsafeAttrCharRE.test(name);
	if (isUnsafe) {
		console.error(`unsafe attribute name: ${name}`);
	}
	return attrValidationCache[name] = !isUnsafe;
}
const propsToAttrMap = {
	acceptCharset: "accept-charset",
	className: "class",
	htmlFor: "for",
	httpEquiv: "http-equiv"
};
const isKnownHtmlAttr = /* @__PURE__ */ makeMap(`accept,accept-charset,accesskey,action,align,allow,alt,async,autocapitalize,autocomplete,autofocus,autoplay,background,bgcolor,border,buffered,capture,challenge,charset,checked,cite,class,code,codebase,color,cols,colspan,content,contenteditable,contextmenu,controls,coords,crossorigin,csp,data,datetime,decoding,default,defer,dir,dirname,disabled,download,draggable,dropzone,enctype,enterkeyhint,for,form,formaction,formenctype,formmethod,formnovalidate,formtarget,headers,height,hidden,high,href,hreflang,http-equiv,icon,id,importance,inert,integrity,ismap,itemprop,keytype,kind,label,lang,language,loading,list,loop,low,manifest,max,maxlength,minlength,media,min,multiple,muted,name,novalidate,open,optimum,pattern,ping,placeholder,poster,preload,radiogroup,readonly,referrerpolicy,rel,required,reversed,rows,rowspan,sandbox,scope,scoped,selected,shape,size,sizes,slot,span,spellcheck,src,srcdoc,srclang,srcset,start,step,style,summary,tabindex,target,title,translate,type,usemap,value,width,wrap`);
const isKnownSvgAttr = /* @__PURE__ */ makeMap(`xmlns,accent-height,accumulate,additive,alignment-baseline,alphabetic,amplitude,arabic-form,ascent,attributeName,attributeType,azimuth,baseFrequency,baseline-shift,baseProfile,bbox,begin,bias,by,calcMode,cap-height,class,clip,clipPathUnits,clip-path,clip-rule,color,color-interpolation,color-interpolation-filters,color-profile,color-rendering,contentScriptType,contentStyleType,crossorigin,cursor,cx,cy,d,decelerate,descent,diffuseConstant,direction,display,divisor,dominant-baseline,dur,dx,dy,edgeMode,elevation,enable-background,end,exponent,fill,fill-opacity,fill-rule,filter,filterRes,filterUnits,flood-color,flood-opacity,font-family,font-size,font-size-adjust,font-stretch,font-style,font-variant,font-weight,format,from,fr,fx,fy,g1,g2,glyph-name,glyph-orientation-horizontal,glyph-orientation-vertical,glyphRef,gradientTransform,gradientUnits,hanging,height,href,hreflang,horiz-adv-x,horiz-origin-x,id,ideographic,image-rendering,in,in2,intercept,k,k1,k2,k3,k4,kernelMatrix,kernelUnitLength,kerning,keyPoints,keySplines,keyTimes,lang,lengthAdjust,letter-spacing,lighting-color,limitingConeAngle,local,marker-end,marker-mid,marker-start,markerHeight,markerUnits,markerWidth,mask,maskContentUnits,maskUnits,mathematical,max,media,method,min,mode,name,numOctaves,offset,opacity,operator,order,orient,orientation,origin,overflow,overline-position,overline-thickness,panose-1,paint-order,path,pathLength,patternContentUnits,patternTransform,patternUnits,ping,pointer-events,points,pointsAtX,pointsAtY,pointsAtZ,preserveAlpha,preserveAspectRatio,primitiveUnits,r,radius,referrerPolicy,refX,refY,rel,rendering-intent,repeatCount,repeatDur,requiredExtensions,requiredFeatures,restart,result,rotate,rx,ry,scale,seed,shape-rendering,slope,spacing,specularConstant,specularExponent,speed,spreadMethod,startOffset,stdDeviation,stemh,stemv,stitchTiles,stop-color,stop-opacity,strikethrough-position,strikethrough-thickness,string,stroke,stroke-dasharray,stroke-dashoffset,stroke-linecap,stroke-linejoin,stroke-miterlimit,stroke-opacity,stroke-width,style,surfaceScale,systemLanguage,tabindex,tableValues,target,targetX,targetY,text-anchor,text-decoration,text-rendering,textLength,to,transform,transform-origin,type,u1,u2,underline-position,underline-thickness,unicode,unicode-bidi,unicode-range,units-per-em,v-alphabetic,v-hanging,v-ideographic,v-mathematical,values,vector-effect,version,vert-adv-y,vert-origin-x,vert-origin-y,viewBox,viewTarget,visibility,width,widths,word-spacing,writing-mode,x,x-height,x1,x2,xChannelSelector,xlink:actuate,xlink:arcrole,xlink:href,xlink:role,xlink:show,xlink:title,xlink:type,xmlns:xlink,xml:base,xml:lang,xml:space,y,y1,y2,yChannelSelector,z,zoomAndPan`);
const isKnownMathMLAttr = /* @__PURE__ */ makeMap(`accent,accentunder,actiontype,align,alignmentscope,altimg,altimg-height,altimg-valign,altimg-width,alttext,bevelled,close,columnsalign,columnlines,columnspan,denomalign,depth,dir,display,displaystyle,encoding,equalcolumns,equalrows,fence,fontstyle,fontweight,form,frame,framespacing,groupalign,height,href,id,indentalign,indentalignfirst,indentalignlast,indentshift,indentshiftfirst,indentshiftlast,indextype,justify,largetop,largeop,lquote,lspace,mathbackground,mathcolor,mathsize,mathvariant,maxsize,minlabelspacing,mode,other,overflow,position,rowalign,rowlines,rowspan,rquote,rspace,scriptlevel,scriptminsize,scriptsizemultiplier,selection,separator,separators,shift,side,src,stackalign,stretchy,subscriptshift,superscriptshift,symmetric,voffset,width,widths,xlink:href,xlink:show,xlink:type,xmlns`);
function isRenderableAttrValue(value) {
	if (value == null) {
		return false;
	}
	const type = typeof value;
	return type === "string" || type === "number" || type === "boolean";
}
const escapeRE = /["'&<>]/;
function escapeHtml(string) {
	const str = "" + string;
	const match = escapeRE.exec(str);
	if (!match) {
		return str;
	}
	let html = "";
	let escaped;
	let index;
	let lastIndex = 0;
	for (index = match.index; index < str.length; index++) {
		switch (str.charCodeAt(index)) {
			case 34:
				escaped = "&quot;";
				break;
			case 38:
				escaped = "&amp;";
				break;
			case 39:
				escaped = "&#39;";
				break;
			case 60:
				escaped = "&lt;";
				break;
			case 62:
				escaped = "&gt;";
				break;
			default: continue;
		}
		if (lastIndex !== index) {
			html += str.slice(lastIndex, index);
		}
		lastIndex = index + 1;
		html += escaped;
	}
	return lastIndex !== index ? html + str.slice(lastIndex, index) : html;
}
const commentStripRE = /^(?:-?>)+|<!--|-->|--!>|<!-$/g;
function escapeHtmlComment(src) {
	let prev;
	do {
		prev = src;
		src = src.replace(commentStripRE, "");
	} while (src !== prev);
	return src;
}
const cssVarNameEscapeSymbolsRE = /[ !"#$%&'()*+,./:;<=>?@[\\\]^`{|}~]/g;
function getEscapedCssVarName(key, doubleEscape) {
	return key.replace(cssVarNameEscapeSymbolsRE, (s) => doubleEscape ? s === "\"" ? "\\\\\\\"" : `\\\\${s}` : `\\${s}`);
}
function looseCompareArrays(a, b) {
	if (a.length !== b.length) return false;
	let equal = true;
	for (let i = 0; equal && i < a.length; i++) {
		equal = looseEqual(a[i], b[i]);
	}
	return equal;
}
function looseEqual(a, b) {
	if (a === b) return true;
	let aValidType = isDate(a);
	let bValidType = isDate(b);
	if (aValidType || bValidType) {
		return aValidType && bValidType ? a.getTime() === b.getTime() : false;
	}
	aValidType = isSymbol(a);
	bValidType = isSymbol(b);
	if (aValidType || bValidType) {
		return a === b;
	}
	aValidType = isArray(a);
	bValidType = isArray(b);
	if (aValidType || bValidType) {
		return aValidType && bValidType ? looseCompareArrays(a, b) : false;
	}
	aValidType = isObject(a);
	bValidType = isObject(b);
	if (aValidType || bValidType) {
		if (!aValidType || !bValidType) {
			return false;
		}
		const aKeysCount = Object.keys(a).length;
		const bKeysCount = Object.keys(b).length;
		if (aKeysCount !== bKeysCount) {
			return false;
		}
		for (const key in a) {
			const aHasKey = a.hasOwnProperty(key);
			const bHasKey = b.hasOwnProperty(key);
			if (aHasKey && !bHasKey || !aHasKey && bHasKey || !looseEqual(a[key], b[key])) {
				return false;
			}
		}
	}
	return String(a) === String(b);
}
function looseIndexOf(arr, val) {
	return arr.findIndex((item) => looseEqual(item, val));
}
const isRef = (val) => {
	return !!(val && val["__v_isRef"] === true);
};
const toDisplayString = (val) => {
	return isString(val) ? val : val == null ? "" : isArray(val) || isObject(val) && (val.toString === objectToString || !isFunction(val.toString)) ? isRef(val) ? toDisplayString(val.value) : JSON.stringify(val, replacer, 2) : String(val);
};
const replacer = (_key, val) => {
	if (isRef(val)) {
		return replacer(_key, val.value);
	} else if (isMap(val)) {
		return { [`Map(${val.size})`]: [...val.entries()].reduce((entries, [key, val2], i) => {
			entries[stringifySymbol(key, i) + " =>"] = val2;
			return entries;
		}, {}) };
	} else if (isSet(val)) {
		return { [`Set(${val.size})`]: [...val.values()].map((v) => stringifySymbol(v)) };
	} else if (isSymbol(val)) {
		return stringifySymbol(val);
	} else if (isObject(val) && !isArray(val) && !isPlainObject(val)) {
		return String(val);
	}
	return val;
};
const stringifySymbol = (v, i = "") => {
	var _a;
	return isSymbol(v) ? `Symbol(${(_a = v.description) != null ? _a : i})` : v;
};
function normalizeCssVarValue(value) {
	if (value == null) {
		return "initial";
	}
	if (typeof value === "string") {
		return value === "" ? " " : value;
	}
	if (typeof value !== "number" || !Number.isFinite(value)) {
		if (!!("development" !== "production")) {
			console.warn("[Vue warn] Invalid value used for CSS binding. Expected a string or a finite number but received:", value);
		}
	}
	return String(value);
}
export { EMPTY_ARR, EMPTY_OBJ, NO, NOOP, PatchFlagNames, PatchFlags, ShapeFlags, SlotFlags, camelize, capitalize, cssVarNameEscapeSymbolsRE, def, escapeHtml, escapeHtmlComment, extend, genCacheKey, genPropsAccessExp, generateCodeFrame, getEscapedCssVarName, getGlobalThis, hasChanged, hasOwn, hyphenate, includeBooleanAttr, invokeArrayFns, isArray, isBooleanAttr, isBuiltInDirective, isDate, isFunction, isGloballyAllowed, isGloballyWhitelisted, isHTMLTag, isIntegerKey, isKnownHtmlAttr, isKnownMathMLAttr, isKnownSvgAttr, isMap, isMathMLTag, isModelListener, isObject, isOn, isPlainObject, isPromise, isRegExp, isRenderableAttrValue, isReservedProp, isSSRSafeAttrName, isSVGTag, isSet, isSpecialBooleanAttr, isString, isSymbol, isVoidTag, looseEqual, looseIndexOf, looseToNumber, makeMap, normalizeClass, normalizeCssVarValue, normalizeProps, normalizeStyle, objectToString, parseStringStyle, propsToAttrMap, remove, slotFlagsText, stringifyStyle, toDisplayString, toHandlerKey, toNumber, toRawType, toTypeString };

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7O0FBTUEsU0FBUyxRQUFRLEtBQUs7Q0FDcEIsTUFBTSxNQUFzQix1QkFBTyxPQUFPLElBQUk7Q0FDOUMsS0FBSyxNQUFNLE9BQU8sSUFBSSxNQUFNLEdBQUcsR0FBRyxJQUFJLE9BQU87Q0FDN0MsUUFBUSxRQUFRLE9BQU87QUFDekI7QUFFQSxNQUFNLFlBQVksQ0FBQyxvQkFBMkIsZ0JBQWdCLE9BQU8sT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ25GLE1BQU0sWUFBWSxDQUFDLG9CQUEyQixnQkFBZ0IsT0FBTyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDbkYsTUFBTSxhQUFhLENBQ25CO0FBQ0EsTUFBTSxXQUFXO0FBQ2pCLE1BQU0sUUFBUSxRQUFRLElBQUksV0FBVyxDQUFDLE1BQU0sT0FBTyxJQUFJLFdBQVcsQ0FBQyxNQUFNLFFBQ3hFLElBQUksV0FBVyxDQUFDLElBQUksT0FBTyxJQUFJLFdBQVcsQ0FBQyxJQUFJO0FBQ2hELE1BQU0sbUJBQW1CLFFBQVEsSUFBSSxXQUFXLFdBQVc7QUFDM0QsTUFBTSxTQUFTLE9BQU87QUFDdEIsTUFBTSxVQUFVLEtBQUssT0FBTztDQUMxQixNQUFNLElBQUksSUFBSSxRQUFRLEVBQUU7Q0FDeEIsSUFBSSxJQUFJLENBQUMsR0FBRztFQUNWLElBQUksT0FBTyxHQUFHLENBQUM7Q0FDakI7QUFDRjtBQUNBLE1BQU0saUJBQWlCLE9BQU8sVUFBVTtBQUN4QyxNQUFNLFVBQVUsS0FBSyxRQUFRLGVBQWUsS0FBSyxLQUFLLEdBQUc7QUFDekQsTUFBTSxVQUFVLE1BQU07QUFDdEIsTUFBTSxTQUFTLFFBQVEsYUFBYSxHQUFHLE1BQU07QUFDN0MsTUFBTSxTQUFTLFFBQVEsYUFBYSxHQUFHLE1BQU07QUFDN0MsTUFBTSxVQUFVLFFBQVEsYUFBYSxHQUFHLE1BQU07QUFDOUMsTUFBTSxZQUFZLFFBQVEsYUFBYSxHQUFHLE1BQU07QUFDaEQsTUFBTSxjQUFjLFFBQVEsT0FBTyxRQUFRO0FBQzNDLE1BQU0sWUFBWSxRQUFRLE9BQU8sUUFBUTtBQUN6QyxNQUFNLFlBQVksUUFBUSxPQUFPLFFBQVE7QUFDekMsTUFBTSxZQUFZLFFBQVEsUUFBUSxRQUFRLE9BQU8sUUFBUTtBQUN6RCxNQUFNLGFBQWEsUUFBUTtDQUN6QixRQUFRLFNBQVMsR0FBRyxLQUFLLFdBQVcsR0FBRyxNQUFNLFdBQVcsSUFBSSxJQUFJLEtBQUssV0FBVyxJQUFJLEtBQUs7QUFDM0Y7QUFDQSxNQUFNLGlCQUFpQixPQUFPLFVBQVU7QUFDeEMsTUFBTSxnQkFBZ0IsVUFBVSxlQUFlLEtBQUssS0FBSztBQUN6RCxNQUFNLGFBQWEsVUFBVTtDQUMzQixPQUFPLGFBQWEsS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztBQUN4QztBQUNBLE1BQU0saUJBQWlCLFFBQVEsYUFBYSxHQUFHLE1BQU07QUFDckQsTUFBTSxnQkFBZ0IsUUFBUSxTQUFTLEdBQUcsS0FBSyxRQUFRLFNBQVMsSUFBSSxPQUFPLE9BQU8sS0FBSyxTQUFTLEtBQUssRUFBRSxNQUFNO0FBQzdHLE1BQU0saUJBQWlDOztDQUVyQztBQUNGO0FBQ0EsTUFBTSxxQkFBcUMsd0JBQ3pDLDJFQUNGO0FBQ0EsTUFBTSx1QkFBdUIsT0FBTztDQUNsQyxNQUFNLFFBQXdCLHVCQUFPLE9BQU8sSUFBSTtDQUNoRCxTQUFTLFFBQVE7RUFDZixNQUFNLE1BQU0sTUFBTTtFQUNsQixPQUFPLFFBQVEsTUFBTSxPQUFPLEdBQUcsR0FBRztDQUNwQztBQUNGO0FBQ0EsTUFBTSxhQUFhO0FBQ25CLE1BQU0sV0FBVyxxQkFDZCxRQUFRO0NBQ1AsT0FBTyxJQUFJLFFBQVEsYUFBYSxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUM7QUFDaEUsQ0FDRjtBQUNBLE1BQU0sY0FBYztBQUNwQixNQUFNLFlBQVkscUJBQ2YsUUFBUSxJQUFJLFFBQVEsYUFBYSxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQ3ZEO0FBQ0EsTUFBTSxhQUFhLHFCQUFxQixRQUFRO0NBQzlDLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLFlBQVksSUFBSSxJQUFJLE1BQU0sQ0FBQztBQUNsRCxDQUFDO0FBQ0QsTUFBTSxlQUFlLHFCQUNsQixRQUFRO0NBQ1AsTUFBTSxJQUFJLE1BQU0sS0FBSyxXQUFXLEdBQUcsTUFBTTtDQUN6QyxPQUFPO0FBQ1QsQ0FDRjtBQUNBLE1BQU0sY0FBYyxPQUFPLGFBQWEsQ0FBQyxPQUFPLEdBQUcsT0FBTyxRQUFRO0FBQ2xFLE1BQU0sa0JBQWtCLEtBQUssR0FBRyxRQUFRO0NBQ3RDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsS0FBSztFQUNuQyxJQUFJLEVBQUUsQ0FBQyxHQUFHLEdBQUc7Q0FDZjtBQUNGO0FBQ0EsTUFBTSxPQUFPLEtBQUssS0FBSyxPQUFPLFdBQVcsVUFBVTtDQUNqRCxPQUFPLGVBQWUsS0FBSyxLQUFLO0VBQzlCLGNBQWM7RUFDZCxZQUFZO0VBQ1o7RUFDQTtDQUNGLENBQUM7QUFDSDtBQUNBLE1BQU0saUJBQWlCLFFBQVE7Q0FDN0IsTUFBTSxJQUFJLFdBQVcsR0FBRztDQUN4QixPQUFPLE1BQU0sQ0FBQyxJQUFJLE1BQU07QUFDMUI7QUFDQSxNQUFNLFlBQVksUUFBUTtDQUN4QixNQUFNLElBQUksU0FBUyxHQUFHLElBQUksT0FBTyxHQUFHLElBQUk7Q0FDeEMsT0FBTyxNQUFNLENBQUMsSUFBSSxNQUFNO0FBQzFCO0FBQ0EsSUFBSTtBQUNKLE1BQU0sc0JBQXNCO0NBQzFCLE9BQU8sZ0JBQWdCLGNBQWMsT0FBTyxlQUFlLGNBQWMsYUFBYSxPQUFPLFNBQVMsY0FBYyxPQUFPLE9BQU8sV0FBVyxjQUFjLFNBQVMsT0FBTyxXQUFXLGNBQWMsU0FBUyxDQUFDO0FBQ2hOO0FBQ0EsTUFBTSxVQUFVO0FBQ2hCLFNBQVMsa0JBQWtCLE1BQU07Q0FDL0IsT0FBTyxRQUFRLEtBQUssSUFBSSxJQUFJLFdBQVcsU0FBUyxXQUFXLEtBQUssVUFBVSxJQUFJLEVBQUU7QUFDbEY7QUFDQSxTQUFTLFlBQVksUUFBUSxTQUFTO0NBQ3BDLE9BQU8sU0FBUyxLQUFLLFVBQ25CLFVBQ0MsR0FBRyxRQUFRLE9BQU8sUUFBUSxhQUFhLElBQUksU0FBUyxJQUFJLEdBQzNEO0FBQ0Y7QUFFQSxNQUFNLGFBQWE7Q0FDakIsUUFBUTtDQUNSLEtBQUs7Q0FDTCxTQUFTO0NBQ1QsS0FBSztDQUNMLFNBQVM7Q0FDVCxLQUFLO0NBQ0wsU0FBUztDQUNULEtBQUs7Q0FDTCxjQUFjO0NBQ2QsTUFBTTtDQUNOLGtCQUFrQjtDQUNsQixNQUFNO0NBQ04sbUJBQW1CO0NBQ25CLE1BQU07Q0FDTixrQkFBa0I7Q0FDbEIsT0FBTztDQUNQLG9CQUFvQjtDQUNwQixPQUFPO0NBQ1AsY0FBYztDQUNkLE9BQU87Q0FDUCxpQkFBaUI7Q0FDakIsUUFBUTtDQUNSLHFCQUFxQjtDQUNyQixRQUFRO0NBQ1IsVUFBVSxDQUFDO0NBQ1gsTUFBTTtDQUNOLFFBQVEsQ0FBQztDQUNULE1BQU07QUFDUjtBQUNBLE1BQU0saUJBQWlCO0VBQ3BCLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7RUFDSixLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxNQUFNO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixPQUFPO0VBQ1AsT0FBTztFQUNQLENBQUMsSUFBSTtFQUNMLENBQUMsSUFBSTtBQUNSO0FBRUEsTUFBTSxhQUFhO0NBQ2pCLFdBQVc7Q0FDWCxLQUFLO0NBQ0wsd0JBQXdCO0NBQ3hCLEtBQUs7Q0FDTCxzQkFBc0I7Q0FDdEIsS0FBSztDQUNMLGlCQUFpQjtDQUNqQixLQUFLO0NBQ0wsa0JBQWtCO0NBQ2xCLE1BQU07Q0FDTixrQkFBa0I7Q0FDbEIsTUFBTTtDQUNOLFlBQVk7Q0FDWixNQUFNO0NBQ04sWUFBWTtDQUNaLE9BQU87Q0FDUCwrQkFBK0I7Q0FDL0IsT0FBTztDQUNQLHdCQUF3QjtDQUN4QixPQUFPO0NBQ1AsYUFBYTtDQUNiLEtBQUs7QUFDUDtBQUVBLE1BQU0sWUFBWTtDQUNoQixVQUFVO0NBQ1YsS0FBSztDQUNMLFdBQVc7Q0FDWCxLQUFLO0NBQ0wsYUFBYTtDQUNiLEtBQUs7QUFDUDtBQUNBLE1BQU0sZ0JBQWdCO0VBQ25CLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtBQUNQO0FBRUEsTUFBTSxrQkFBa0I7QUFDeEIsTUFBTSxvQkFBb0Msd0JBQVEsZUFBZTtBQUNqRSxNQUFNLHdCQUF3QjtBQUU5QixNQUFNLFFBQVE7QUFDZCxTQUFTLGtCQUFrQixRQUFRLFFBQVEsR0FBRyxNQUFNLE9BQU8sUUFBUTtDQUNqRSxRQUFRLEtBQUssSUFBSSxHQUFHLEtBQUssSUFBSSxPQUFPLE9BQU8sTUFBTSxDQUFDO0NBQ2xELE1BQU0sS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEtBQUssT0FBTyxNQUFNLENBQUM7Q0FDOUMsSUFBSSxRQUFRLEtBQUssT0FBTztDQUN4QixJQUFJLFFBQVEsT0FBTyxNQUFNLFNBQVM7Q0FDbEMsTUFBTSxtQkFBbUIsTUFBTSxRQUFRLEdBQUcsUUFBUSxNQUFNLE1BQU0sQ0FBQztDQUMvRCxRQUFRLE1BQU0sUUFBUSxHQUFHLFFBQVEsTUFBTSxNQUFNLENBQUM7Q0FDOUMsSUFBSSxRQUFRO0NBQ1osTUFBTSxNQUFNLENBQUM7Q0FDYixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7RUFDckMsU0FBUyxNQUFNLEVBQUUsQ0FBQyxVQUFVLGlCQUFpQixNQUFNLGlCQUFpQixFQUFFLENBQUMsVUFBVTtFQUNqRixJQUFJLFNBQVMsT0FBTztHQUNsQixLQUFLLElBQUksSUFBSSxJQUFJLE9BQU8sS0FBSyxJQUFJLFNBQVMsTUFBTSxPQUFPLEtBQUs7SUFDMUQsSUFBSSxJQUFJLEtBQUssS0FBSyxNQUFNLFFBQVE7SUFDaEMsTUFBTSxPQUFPLElBQUk7SUFDakIsSUFBSSxLQUNGLEdBQUcsT0FBTyxJQUFJLE9BQU8sS0FBSyxJQUFJLElBQUksT0FBTyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEtBQUssTUFBTSxJQUN4RTtJQUNBLE1BQU0sYUFBYSxNQUFNLEVBQUUsQ0FBQztJQUM1QixNQUFNLG1CQUFtQixpQkFBaUIsTUFBTSxpQkFBaUIsRUFBRSxDQUFDLFVBQVU7SUFDOUUsSUFBSSxNQUFNLEdBQUc7S0FDWCxNQUFNLE1BQU0sU0FBUyxTQUFTLGFBQWE7S0FDM0MsTUFBTSxTQUFTLEtBQUssSUFDbEIsR0FDQSxNQUFNLFFBQVEsYUFBYSxNQUFNLE1BQU0sS0FDekM7S0FDQSxJQUFJLEtBQUssV0FBVyxJQUFJLE9BQU8sR0FBRyxJQUFJLElBQUksT0FBTyxNQUFNLENBQUM7SUFDMUQsT0FBTyxJQUFJLElBQUksR0FBRztLQUNoQixJQUFJLE1BQU0sT0FBTztNQUNmLE1BQU0sU0FBUyxLQUFLLElBQUksS0FBSyxJQUFJLE1BQU0sT0FBTyxVQUFVLEdBQUcsQ0FBQztNQUM1RCxJQUFJLEtBQUssV0FBVyxJQUFJLE9BQU8sTUFBTSxDQUFDO0tBQ3hDO0tBQ0EsU0FBUyxhQUFhO0lBQ3hCO0dBQ0Y7R0FDQTtFQUNGO0NBQ0Y7Q0FDQSxPQUFPLElBQUksS0FBSyxJQUFJO0FBQ3RCO0FBRUEsU0FBUyxlQUFlLE9BQU87Q0FDN0IsSUFBSSxRQUFRLEtBQUssR0FBRztFQUNsQixNQUFNLE1BQU0sQ0FBQztFQUNiLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztHQUNyQyxNQUFNLE9BQU8sTUFBTTtHQUNuQixNQUFNLGFBQWEsU0FBUyxJQUFJLElBQUksaUJBQWlCLElBQUksSUFBSSxlQUFlLElBQUk7R0FDaEYsSUFBSSxZQUFZO0lBQ2QsS0FBSyxNQUFNLE9BQU8sWUFBWTtLQUM1QixJQUFJLE9BQU8sV0FBVztJQUN4QjtHQUNGO0VBQ0Y7RUFDQSxPQUFPO0NBQ1QsT0FBTyxJQUFJLFNBQVMsS0FBSyxLQUFLLFNBQVMsS0FBSyxHQUFHO0VBQzdDLE9BQU87Q0FDVDtBQUNGO0FBQ0EsTUFBTSxrQkFBa0I7QUFDeEIsTUFBTSxzQkFBc0I7QUFDNUIsTUFBTSxpQkFBaUI7QUFDdkIsU0FBUyxpQkFBaUIsU0FBUztDQUNqQyxNQUFNLE1BQU0sQ0FBQztDQUNiLFFBQVEsUUFBUSxnQkFBZ0IsRUFBRSxDQUFDLENBQUMsTUFBTSxlQUFlLENBQUMsQ0FBQyxTQUFTLFNBQVM7RUFDM0UsSUFBSSxNQUFNO0dBQ1IsTUFBTSxNQUFNLEtBQUssTUFBTSxtQkFBbUI7R0FDMUMsSUFBSSxTQUFTLE1BQU0sSUFBSSxJQUFJLEVBQUUsQ0FBQyxLQUFLLEtBQUssSUFBSSxFQUFFLENBQUMsS0FBSztFQUN0RDtDQUNGLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGVBQWUsUUFBUTtDQUM5QixJQUFJLENBQUMsUUFBUSxPQUFPO0NBQ3BCLElBQUksU0FBUyxNQUFNLEdBQUcsT0FBTztDQUM3QixJQUFJLE1BQU07Q0FDVixLQUFLLE1BQU0sT0FBTyxRQUFRO0VBQ3hCLE1BQU0sUUFBUSxPQUFPO0VBQ3JCLElBQUksU0FBUyxLQUFLLEtBQUssT0FBTyxVQUFVLFVBQVU7R0FDaEQsTUFBTSxnQkFBZ0IsSUFBSSxXQUFXLElBQUksSUFBSSxNQUFNLFVBQVUsR0FBRztHQUNoRSxPQUFPLEdBQUcsY0FBYyxHQUFHLE1BQU07RUFDbkM7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsZUFBZSxPQUFPO0NBQzdCLElBQUksTUFBTTtDQUNWLElBQUksU0FBUyxLQUFLLEdBQUc7RUFDbkIsTUFBTTtDQUNSLE9BQU8sSUFBSSxRQUFRLEtBQUssR0FBRztFQUN6QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7R0FDckMsTUFBTSxhQUFhLGVBQWUsTUFBTSxFQUFFO0dBQzFDLElBQUksWUFBWTtJQUNkLE9BQU8sYUFBYTtHQUN0QjtFQUNGO0NBQ0YsT0FBTyxJQUFJLFNBQVMsS0FBSyxHQUFHO0VBQzFCLEtBQUssTUFBTSxRQUFRLE9BQU87R0FDeEIsSUFBSSxNQUFNLE9BQU87SUFDZixPQUFPLE9BQU87R0FDaEI7RUFDRjtDQUNGO0NBQ0EsT0FBTyxJQUFJLEtBQUs7QUFDbEI7QUFDQSxTQUFTLGVBQWUsT0FBTztDQUM3QixJQUFJLENBQUMsT0FBTyxPQUFPO0NBQ25CLElBQUksRUFBRSxPQUFPLE9BQU8sVUFBVTtDQUM5QixJQUFJLFNBQVMsQ0FBQyxTQUFTLEtBQUssR0FBRztFQUM3QixNQUFNLFFBQVEsZUFBZSxLQUFLO0NBQ3BDO0NBQ0EsSUFBSSxPQUFPO0VBQ1QsTUFBTSxRQUFRLGVBQWUsS0FBSztDQUNwQztDQUNBLE9BQU87QUFDVDtBQUVBLE1BQU0sWUFBWTtBQUNsQixNQUFNLFdBQVc7QUFDakIsTUFBTSxZQUFZO0FBQ2xCLE1BQU0sWUFBWTtBQUNsQixNQUFNLFlBQTRCLHdCQUFRLFNBQVM7QUFDbkQsTUFBTSxXQUEyQix3QkFBUSxRQUFRO0FBQ2pELE1BQU0sY0FBOEIsd0JBQVEsU0FBUztBQUNyRCxNQUFNLFlBQTRCLHdCQUFRLFNBQVM7QUFFbkQsTUFBTSxzQkFBc0I7QUFDNUIsTUFBTSx1QkFBdUMsd0JBQVEsbUJBQW1CO0FBQ3hFLE1BQU0sZ0JBQWdDLHdCQUNwQyxzQkFBc0Isb0pBQ3hCO0FBQ0EsU0FBUyxtQkFBbUIsT0FBTztDQUNqQyxPQUFPLENBQUMsQ0FBQyxTQUFTLFVBQVU7QUFDOUI7QUFDQSxNQUFNLG1CQUFtQjtBQUN6QixNQUFNLHNCQUFzQixDQUFDO0FBQzdCLFNBQVMsa0JBQWtCLE1BQU07Q0FDL0IsSUFBSSxvQkFBb0IsZUFBZSxJQUFJLEdBQUc7RUFDNUMsT0FBTyxvQkFBb0I7Q0FDN0I7Q0FDQSxNQUFNLFdBQVcsaUJBQWlCLEtBQUssSUFBSTtDQUMzQyxJQUFJLFVBQVU7RUFDWixRQUFRLE1BQU0sMEJBQTBCLE1BQU07Q0FDaEQ7Q0FDQSxPQUFPLG9CQUFvQixRQUFRLENBQUM7QUFDdEM7QUFDQSxNQUFNLGlCQUFpQjtDQUNyQixlQUFlO0NBQ2YsV0FBVztDQUNYLFNBQVM7Q0FDVCxXQUFXO0FBQ2I7QUFDQSxNQUFNLGtCQUFrQyx3QkFDdEMsdytCQUNGO0FBQ0EsTUFBTSxpQkFBaUMsd0JBQ3JDLGtvRkFDRjtBQUNBLE1BQU0sb0JBQW9DLHdCQUN4QyxteUJBQ0Y7QUFDQSxTQUFTLHNCQUFzQixPQUFPO0NBQ3BDLElBQUksU0FBUyxNQUFNO0VBQ2pCLE9BQU87Q0FDVDtDQUNBLE1BQU0sT0FBTyxPQUFPO0NBQ3BCLE9BQU8sU0FBUyxZQUFZLFNBQVMsWUFBWSxTQUFTO0FBQzVEO0FBRUEsTUFBTSxXQUFXO0FBQ2pCLFNBQVMsV0FBVyxRQUFRO0NBQzFCLE1BQU0sTUFBTSxLQUFLO0NBQ2pCLE1BQU0sUUFBUSxTQUFTLEtBQUssR0FBRztDQUMvQixJQUFJLENBQUMsT0FBTztFQUNWLE9BQU87Q0FDVDtDQUNBLElBQUksT0FBTztDQUNYLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSSxZQUFZO0NBQ2hCLEtBQUssUUFBUSxNQUFNLE9BQU8sUUFBUSxJQUFJLFFBQVEsU0FBUztFQUNyRCxRQUFRLElBQUksV0FBVyxLQUFLLEdBQTVCO0dBQ0UsS0FBSztJQUNILFVBQVU7SUFDVjtHQUNGLEtBQUs7SUFDSCxVQUFVO0lBQ1Y7R0FDRixLQUFLO0lBQ0gsVUFBVTtJQUNWO0dBQ0YsS0FBSztJQUNILFVBQVU7SUFDVjtHQUNGLEtBQUs7SUFDSCxVQUFVO0lBQ1Y7R0FDRixTQUNFO0VBQ0o7RUFDQSxJQUFJLGNBQWMsT0FBTztHQUN2QixRQUFRLElBQUksTUFBTSxXQUFXLEtBQUs7RUFDcEM7RUFDQSxZQUFZLFFBQVE7RUFDcEIsUUFBUTtDQUNWO0NBQ0EsT0FBTyxjQUFjLFFBQVEsT0FBTyxJQUFJLE1BQU0sV0FBVyxLQUFLLElBQUk7QUFDcEU7QUFDQSxNQUFNLGlCQUFpQjtBQUN2QixTQUFTLGtCQUFrQixLQUFLO0NBQzlCLElBQUk7Q0FDSixHQUFHO0VBQ0QsT0FBTztFQUNQLE1BQU0sSUFBSSxRQUFRLGdCQUFnQixFQUFFO0NBQ3RDLFNBQVMsUUFBUTtDQUNqQixPQUFPO0FBQ1Q7QUFDQSxNQUFNLDRCQUE0QjtBQUNsQyxTQUFTLHFCQUFxQixLQUFLLGNBQWM7Q0FDL0MsT0FBTyxJQUFJLFFBQ1QsNEJBQ0MsTUFBTSxlQUFlLE1BQU0sT0FBTSxhQUFZLE9BQU8sTUFBTSxLQUFLLEdBQ2xFO0FBQ0Y7QUFFQSxTQUFTLG1CQUFtQixHQUFHLEdBQUc7Q0FDaEMsSUFBSSxFQUFFLFdBQVcsRUFBRSxRQUFRLE9BQU87Q0FDbEMsSUFBSSxRQUFRO0NBQ1osS0FBSyxJQUFJLElBQUksR0FBRyxTQUFTLElBQUksRUFBRSxRQUFRLEtBQUs7RUFDMUMsUUFBUSxXQUFXLEVBQUUsSUFBSSxFQUFFLEVBQUU7Q0FDL0I7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLFdBQVcsR0FBRyxHQUFHO0NBQ3hCLElBQUksTUFBTSxHQUFHLE9BQU87Q0FDcEIsSUFBSSxhQUFhLE9BQU8sQ0FBQztDQUN6QixJQUFJLGFBQWEsT0FBTyxDQUFDO0NBQ3pCLElBQUksY0FBYyxZQUFZO0VBQzVCLE9BQU8sY0FBYyxhQUFhLEVBQUUsUUFBUSxNQUFNLEVBQUUsUUFBUSxJQUFJO0NBQ2xFO0NBQ0EsYUFBYSxTQUFTLENBQUM7Q0FDdkIsYUFBYSxTQUFTLENBQUM7Q0FDdkIsSUFBSSxjQUFjLFlBQVk7RUFDNUIsT0FBTyxNQUFNO0NBQ2Y7Q0FDQSxhQUFhLFFBQVEsQ0FBQztDQUN0QixhQUFhLFFBQVEsQ0FBQztDQUN0QixJQUFJLGNBQWMsWUFBWTtFQUM1QixPQUFPLGNBQWMsYUFBYSxtQkFBbUIsR0FBRyxDQUFDLElBQUk7Q0FDL0Q7Q0FDQSxhQUFhLFNBQVMsQ0FBQztDQUN2QixhQUFhLFNBQVMsQ0FBQztDQUN2QixJQUFJLGNBQWMsWUFBWTtFQUM1QixJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVk7R0FDOUIsT0FBTztFQUNUO0VBQ0EsTUFBTSxhQUFhLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQztFQUNsQyxNQUFNLGFBQWEsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDO0VBQ2xDLElBQUksZUFBZSxZQUFZO0dBQzdCLE9BQU87RUFDVDtFQUNBLEtBQUssTUFBTSxPQUFPLEdBQUc7R0FDbkIsTUFBTSxVQUFVLEVBQUUsZUFBZSxHQUFHO0dBQ3BDLE1BQU0sVUFBVSxFQUFFLGVBQWUsR0FBRztHQUNwQyxJQUFJLFdBQVcsQ0FBQyxXQUFXLENBQUMsV0FBVyxXQUFXLENBQUMsV0FBVyxFQUFFLE1BQU0sRUFBRSxJQUFJLEdBQUc7SUFDN0UsT0FBTztHQUNUO0VBQ0Y7Q0FDRjtDQUNBLE9BQU8sT0FBTyxDQUFDLE1BQU0sT0FBTyxDQUFDO0FBQy9CO0FBQ0EsU0FBUyxhQUFhLEtBQUssS0FBSztDQUM5QixPQUFPLElBQUksV0FBVyxTQUFTLFdBQVcsTUFBTSxHQUFHLENBQUM7QUFDdEQ7QUFFQSxNQUFNLFNBQVMsUUFBUTtDQUNyQixPQUFPLENBQUMsRUFBRSxPQUFPLElBQUksaUJBQWlCO0FBQ3hDO0FBQ0EsTUFBTSxtQkFBbUIsUUFBUTtDQUMvQixPQUFPLFNBQVMsR0FBRyxJQUFJLE1BQU0sT0FBTyxPQUFPLEtBQUssUUFBUSxHQUFHLEtBQUssU0FBUyxHQUFHLE1BQU0sSUFBSSxhQUFhLGtCQUFrQixDQUFDLFdBQVcsSUFBSSxRQUFRLEtBQUssTUFBTSxHQUFHLElBQUksZ0JBQWdCLElBQUksS0FBSyxJQUFJLEtBQUssVUFBVSxLQUFLLFVBQVUsQ0FBQyxJQUFJLE9BQU8sR0FBRztBQUMzTztBQUNBLE1BQU0sWUFBWSxNQUFNLFFBQVE7Q0FDOUIsSUFBSSxNQUFNLEdBQUcsR0FBRztFQUNkLE9BQU8sU0FBUyxNQUFNLElBQUksS0FBSztDQUNqQyxPQUFPLElBQUksTUFBTSxHQUFHLEdBQUc7RUFDckIsT0FBTyxHQUNKLE9BQU8sSUFBSSxLQUFLLEtBQUssQ0FBQyxHQUFHLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxRQUN0QyxTQUFTLENBQUMsS0FBSyxPQUFPLE1BQU07R0FDM0IsUUFBUSxnQkFBZ0IsS0FBSyxDQUFDLElBQUksU0FBUztHQUMzQyxPQUFPO0VBQ1QsR0FDQSxDQUFDLENBQ0gsRUFDRjtDQUNGLE9BQU8sSUFBSSxNQUFNLEdBQUcsR0FBRztFQUNyQixPQUFPLEdBQ0osT0FBTyxJQUFJLEtBQUssS0FBSyxDQUFDLEdBQUcsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssTUFBTSxnQkFBZ0IsQ0FBQyxDQUFDLEVBQ3ZFO0NBQ0YsT0FBTyxJQUFJLFNBQVMsR0FBRyxHQUFHO0VBQ3hCLE9BQU8sZ0JBQWdCLEdBQUc7Q0FDNUIsT0FBTyxJQUFJLFNBQVMsR0FBRyxLQUFLLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxjQUFjLEdBQUcsR0FBRztFQUNoRSxPQUFPLE9BQU8sR0FBRztDQUNuQjtDQUNBLE9BQU87QUFDVDtBQUNBLE1BQU0sbUJBQW1CLEdBQUcsSUFBSSxPQUFPO0NBQ3JDLElBQUk7Q0FDSixPQUdFLFNBQVMsQ0FBQyxJQUFJLFdBQVcsS0FBSyxFQUFFLGdCQUFnQixPQUFPLEtBQUssRUFBRSxLQUFLO0FBRXZFO0FBRUEsU0FBUyxxQkFBcUIsT0FBTztDQUNuQyxJQUFJLFNBQVMsTUFBTTtFQUNqQixPQUFPO0NBQ1Q7Q0FDQSxJQUFJLE9BQU8sVUFBVSxVQUFVO0VBQzdCLE9BQU8sVUFBVSxLQUFLLE1BQU07Q0FDOUI7Q0FDQSxJQUFJLE9BQU8sVUFBVSxZQUFZLENBQUMsT0FBTyxTQUFTLEtBQUssR0FBRztFQUN4RCxJQUFJLENBQUMsb0JBQTJCLGVBQWU7R0FDN0MsUUFBUSxLQUNOLHFHQUNBLEtBQ0Y7RUFDRjtDQUNGO0NBQ0EsT0FBTyxPQUFPLEtBQUs7QUFDckI7QUFFQSxTQUFTLFdBQVcsV0FBVyxJQUFJLE1BQU0sZ0JBQWdCLFlBQVksWUFBWSxXQUFXLFVBQVUsWUFBWSwyQkFBMkIsS0FBSyxZQUFZLG1CQUFtQixRQUFRLGFBQWEsbUJBQW1CLG1CQUFtQixzQkFBc0IsZUFBZSxZQUFZLFFBQVEsV0FBVyxvQkFBb0IsZ0JBQWdCLFNBQVMsZUFBZSxvQkFBb0IsUUFBUSxZQUFZLG1CQUFtQix1QkFBdUIsV0FBVyxjQUFjLGlCQUFpQixtQkFBbUIsZ0JBQWdCLE9BQU8sYUFBYSxpQkFBaUIsVUFBVSxNQUFNLGVBQWUsV0FBVyxVQUFVLHVCQUF1QixnQkFBZ0IsbUJBQW1CLFVBQVUsT0FBTyxzQkFBc0IsVUFBVSxVQUFVLFdBQVcsWUFBWSxjQUFjLGVBQWUsU0FBUyxnQkFBZ0Isc0JBQXNCLGdCQUFnQixnQkFBZ0IsZ0JBQWdCLGtCQUFrQixnQkFBZ0IsUUFBUSxlQUFlLGdCQUFnQixpQkFBaUIsY0FBYyxVQUFVLFdBQVciLCJuYW1lcyI6W10sInNvdXJjZXMiOlsic2hhcmVkLmVzbS1idW5kbGVyLmpzP3Y9N2U3M2FmYzIiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXG4qIEB2dWUvc2hhcmVkIHYzLjUuNDBcbiogKGMpIDIwMTgtcHJlc2VudCBZdXhpIChFdmFuKSBZb3UgYW5kIFZ1ZSBjb250cmlidXRvcnNcbiogQGxpY2Vuc2UgTUlUXG4qKi9cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiBtYWtlTWFwKHN0cikge1xuICBjb25zdCBtYXAgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgZm9yIChjb25zdCBrZXkgb2Ygc3RyLnNwbGl0KFwiLFwiKSkgbWFwW2tleV0gPSAxO1xuICByZXR1cm4gKHZhbCkgPT4gdmFsIGluIG1hcDtcbn1cblxuY29uc3QgRU1QVFlfT0JKID0gISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IE9iamVjdC5mcmVlemUoe30pIDoge307XG5jb25zdCBFTVBUWV9BUlIgPSAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gT2JqZWN0LmZyZWV6ZShbXSkgOiBbXTtcbmNvbnN0IE5PT1AgPSAoKSA9PiB7XG59O1xuY29uc3QgTk8gPSAoKSA9PiBmYWxzZTtcbmNvbnN0IGlzT24gPSAoa2V5KSA9PiBrZXkuY2hhckNvZGVBdCgwKSA9PT0gMTExICYmIGtleS5jaGFyQ29kZUF0KDEpID09PSAxMTAgJiYgLy8gdXBwZXJjYXNlIGxldHRlclxuKGtleS5jaGFyQ29kZUF0KDIpID4gMTIyIHx8IGtleS5jaGFyQ29kZUF0KDIpIDwgOTcpO1xuY29uc3QgaXNNb2RlbExpc3RlbmVyID0gKGtleSkgPT4ga2V5LnN0YXJ0c1dpdGgoXCJvblVwZGF0ZTpcIik7XG5jb25zdCBleHRlbmQgPSBPYmplY3QuYXNzaWduO1xuY29uc3QgcmVtb3ZlID0gKGFyciwgZWwpID0+IHtcbiAgY29uc3QgaSA9IGFyci5pbmRleE9mKGVsKTtcbiAgaWYgKGkgPiAtMSkge1xuICAgIGFyci5zcGxpY2UoaSwgMSk7XG4gIH1cbn07XG5jb25zdCBoYXNPd25Qcm9wZXJ0eSA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG5jb25zdCBoYXNPd24gPSAodmFsLCBrZXkpID0+IGhhc093blByb3BlcnR5LmNhbGwodmFsLCBrZXkpO1xuY29uc3QgaXNBcnJheSA9IEFycmF5LmlzQXJyYXk7XG5jb25zdCBpc01hcCA9ICh2YWwpID0+IHRvVHlwZVN0cmluZyh2YWwpID09PSBcIltvYmplY3QgTWFwXVwiO1xuY29uc3QgaXNTZXQgPSAodmFsKSA9PiB0b1R5cGVTdHJpbmcodmFsKSA9PT0gXCJbb2JqZWN0IFNldF1cIjtcbmNvbnN0IGlzRGF0ZSA9ICh2YWwpID0+IHRvVHlwZVN0cmluZyh2YWwpID09PSBcIltvYmplY3QgRGF0ZV1cIjtcbmNvbnN0IGlzUmVnRXhwID0gKHZhbCkgPT4gdG9UeXBlU3RyaW5nKHZhbCkgPT09IFwiW29iamVjdCBSZWdFeHBdXCI7XG5jb25zdCBpc0Z1bmN0aW9uID0gKHZhbCkgPT4gdHlwZW9mIHZhbCA9PT0gXCJmdW5jdGlvblwiO1xuY29uc3QgaXNTdHJpbmcgPSAodmFsKSA9PiB0eXBlb2YgdmFsID09PSBcInN0cmluZ1wiO1xuY29uc3QgaXNTeW1ib2wgPSAodmFsKSA9PiB0eXBlb2YgdmFsID09PSBcInN5bWJvbFwiO1xuY29uc3QgaXNPYmplY3QgPSAodmFsKSA9PiB2YWwgIT09IG51bGwgJiYgdHlwZW9mIHZhbCA9PT0gXCJvYmplY3RcIjtcbmNvbnN0IGlzUHJvbWlzZSA9ICh2YWwpID0+IHtcbiAgcmV0dXJuIChpc09iamVjdCh2YWwpIHx8IGlzRnVuY3Rpb24odmFsKSkgJiYgaXNGdW5jdGlvbih2YWwudGhlbikgJiYgaXNGdW5jdGlvbih2YWwuY2F0Y2gpO1xufTtcbmNvbnN0IG9iamVjdFRvU3RyaW5nID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZztcbmNvbnN0IHRvVHlwZVN0cmluZyA9ICh2YWx1ZSkgPT4gb2JqZWN0VG9TdHJpbmcuY2FsbCh2YWx1ZSk7XG5jb25zdCB0b1Jhd1R5cGUgPSAodmFsdWUpID0+IHtcbiAgcmV0dXJuIHRvVHlwZVN0cmluZyh2YWx1ZSkuc2xpY2UoOCwgLTEpO1xufTtcbmNvbnN0IGlzUGxhaW5PYmplY3QgPSAodmFsKSA9PiB0b1R5cGVTdHJpbmcodmFsKSA9PT0gXCJbb2JqZWN0IE9iamVjdF1cIjtcbmNvbnN0IGlzSW50ZWdlcktleSA9IChrZXkpID0+IGlzU3RyaW5nKGtleSkgJiYga2V5ICE9PSBcIk5hTlwiICYmIGtleVswXSAhPT0gXCItXCIgJiYgXCJcIiArIHBhcnNlSW50KGtleSwgMTApID09PSBrZXk7XG5jb25zdCBpc1Jlc2VydmVkUHJvcCA9IC8qIEBfX1BVUkVfXyAqLyBtYWtlTWFwKFxuICAvLyB0aGUgbGVhZGluZyBjb21tYSBpcyBpbnRlbnRpb25hbCBzbyBlbXB0eSBzdHJpbmcgXCJcIiBpcyBhbHNvIGluY2x1ZGVkXG4gIFwiLGtleSxyZWYscmVmX2ZvcixyZWZfa2V5LG9uVm5vZGVCZWZvcmVNb3VudCxvblZub2RlTW91bnRlZCxvblZub2RlQmVmb3JlVXBkYXRlLG9uVm5vZGVVcGRhdGVkLG9uVm5vZGVCZWZvcmVVbm1vdW50LG9uVm5vZGVVbm1vdW50ZWRcIlxuKTtcbmNvbnN0IGlzQnVpbHRJbkRpcmVjdGl2ZSA9IC8qIEBfX1BVUkVfXyAqLyBtYWtlTWFwKFxuICBcImJpbmQsY2xvYWssZWxzZS1pZixlbHNlLGZvcixodG1sLGlmLG1vZGVsLG9uLG9uY2UscHJlLHNob3csc2xvdCx0ZXh0LG1lbW9cIlxuKTtcbmNvbnN0IGNhY2hlU3RyaW5nRnVuY3Rpb24gPSAoZm4pID0+IHtcbiAgY29uc3QgY2FjaGUgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgcmV0dXJuICgoc3RyKSA9PiB7XG4gICAgY29uc3QgaGl0ID0gY2FjaGVbc3RyXTtcbiAgICByZXR1cm4gaGl0IHx8IChjYWNoZVtzdHJdID0gZm4oc3RyKSk7XG4gIH0pO1xufTtcbmNvbnN0IGNhbWVsaXplUkUgPSAvLVxcdy9nO1xuY29uc3QgY2FtZWxpemUgPSBjYWNoZVN0cmluZ0Z1bmN0aW9uKFxuICAoc3RyKSA9PiB7XG4gICAgcmV0dXJuIHN0ci5yZXBsYWNlKGNhbWVsaXplUkUsIChjKSA9PiBjLnNsaWNlKDEpLnRvVXBwZXJDYXNlKCkpO1xuICB9XG4pO1xuY29uc3QgaHlwaGVuYXRlUkUgPSAvXFxCKFtBLVpdKS9nO1xuY29uc3QgaHlwaGVuYXRlID0gY2FjaGVTdHJpbmdGdW5jdGlvbihcbiAgKHN0cikgPT4gc3RyLnJlcGxhY2UoaHlwaGVuYXRlUkUsIFwiLSQxXCIpLnRvTG93ZXJDYXNlKClcbik7XG5jb25zdCBjYXBpdGFsaXplID0gY2FjaGVTdHJpbmdGdW5jdGlvbigoc3RyKSA9PiB7XG4gIHJldHVybiBzdHIuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkgKyBzdHIuc2xpY2UoMSk7XG59KTtcbmNvbnN0IHRvSGFuZGxlcktleSA9IGNhY2hlU3RyaW5nRnVuY3Rpb24oXG4gIChzdHIpID0+IHtcbiAgICBjb25zdCBzID0gc3RyID8gYG9uJHtjYXBpdGFsaXplKHN0cil9YCA6IGBgO1xuICAgIHJldHVybiBzO1xuICB9XG4pO1xuY29uc3QgaGFzQ2hhbmdlZCA9ICh2YWx1ZSwgb2xkVmFsdWUpID0+ICFPYmplY3QuaXModmFsdWUsIG9sZFZhbHVlKTtcbmNvbnN0IGludm9rZUFycmF5Rm5zID0gKGZucywgLi4uYXJnKSA9PiB7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgZm5zLmxlbmd0aDsgaSsrKSB7XG4gICAgZm5zW2ldKC4uLmFyZyk7XG4gIH1cbn07XG5jb25zdCBkZWYgPSAob2JqLCBrZXksIHZhbHVlLCB3cml0YWJsZSA9IGZhbHNlKSA9PiB7XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvYmosIGtleSwge1xuICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICB3cml0YWJsZSxcbiAgICB2YWx1ZVxuICB9KTtcbn07XG5jb25zdCBsb29zZVRvTnVtYmVyID0gKHZhbCkgPT4ge1xuICBjb25zdCBuID0gcGFyc2VGbG9hdCh2YWwpO1xuICByZXR1cm4gaXNOYU4obikgPyB2YWwgOiBuO1xufTtcbmNvbnN0IHRvTnVtYmVyID0gKHZhbCkgPT4ge1xuICBjb25zdCBuID0gaXNTdHJpbmcodmFsKSA/IE51bWJlcih2YWwpIDogTmFOO1xuICByZXR1cm4gaXNOYU4obikgPyB2YWwgOiBuO1xufTtcbmxldCBfZ2xvYmFsVGhpcztcbmNvbnN0IGdldEdsb2JhbFRoaXMgPSAoKSA9PiB7XG4gIHJldHVybiBfZ2xvYmFsVGhpcyB8fCAoX2dsb2JhbFRoaXMgPSB0eXBlb2YgZ2xvYmFsVGhpcyAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbFRoaXMgOiB0eXBlb2Ygc2VsZiAhPT0gXCJ1bmRlZmluZWRcIiA/IHNlbGYgOiB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiID8gd2luZG93IDogdHlwZW9mIGdsb2JhbCAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbCA6IHt9KTtcbn07XG5jb25zdCBpZGVudFJFID0gL15bXyRhLXpBLVpcXHhBMC1cXHVGRkZGXVtfJGEtekEtWjAtOVxceEEwLVxcdUZGRkZdKiQvO1xuZnVuY3Rpb24gZ2VuUHJvcHNBY2Nlc3NFeHAobmFtZSkge1xuICByZXR1cm4gaWRlbnRSRS50ZXN0KG5hbWUpID8gYF9fcHJvcHMuJHtuYW1lfWAgOiBgX19wcm9wc1ske0pTT04uc3RyaW5naWZ5KG5hbWUpfV1gO1xufVxuZnVuY3Rpb24gZ2VuQ2FjaGVLZXkoc291cmNlLCBvcHRpb25zKSB7XG4gIHJldHVybiBzb3VyY2UgKyBKU09OLnN0cmluZ2lmeShcbiAgICBvcHRpb25zLFxuICAgIChfLCB2YWwpID0+IHR5cGVvZiB2YWwgPT09IFwiZnVuY3Rpb25cIiA/IHZhbC50b1N0cmluZygpIDogdmFsXG4gICk7XG59XG5cbmNvbnN0IFBhdGNoRmxhZ3MgPSB7XG4gIFwiVEVYVFwiOiAxLFxuICBcIjFcIjogXCJURVhUXCIsXG4gIFwiQ0xBU1NcIjogMixcbiAgXCIyXCI6IFwiQ0xBU1NcIixcbiAgXCJTVFlMRVwiOiA0LFxuICBcIjRcIjogXCJTVFlMRVwiLFxuICBcIlBST1BTXCI6IDgsXG4gIFwiOFwiOiBcIlBST1BTXCIsXG4gIFwiRlVMTF9QUk9QU1wiOiAxNixcbiAgXCIxNlwiOiBcIkZVTExfUFJPUFNcIixcbiAgXCJORUVEX0hZRFJBVElPTlwiOiAzMixcbiAgXCIzMlwiOiBcIk5FRURfSFlEUkFUSU9OXCIsXG4gIFwiU1RBQkxFX0ZSQUdNRU5UXCI6IDY0LFxuICBcIjY0XCI6IFwiU1RBQkxFX0ZSQUdNRU5UXCIsXG4gIFwiS0VZRURfRlJBR01FTlRcIjogMTI4LFxuICBcIjEyOFwiOiBcIktFWUVEX0ZSQUdNRU5UXCIsXG4gIFwiVU5LRVlFRF9GUkFHTUVOVFwiOiAyNTYsXG4gIFwiMjU2XCI6IFwiVU5LRVlFRF9GUkFHTUVOVFwiLFxuICBcIk5FRURfUEFUQ0hcIjogNTEyLFxuICBcIjUxMlwiOiBcIk5FRURfUEFUQ0hcIixcbiAgXCJEWU5BTUlDX1NMT1RTXCI6IDEwMjQsXG4gIFwiMTAyNFwiOiBcIkRZTkFNSUNfU0xPVFNcIixcbiAgXCJERVZfUk9PVF9GUkFHTUVOVFwiOiAyMDQ4LFxuICBcIjIwNDhcIjogXCJERVZfUk9PVF9GUkFHTUVOVFwiLFxuICBcIkNBQ0hFRFwiOiAtMSxcbiAgXCItMVwiOiBcIkNBQ0hFRFwiLFxuICBcIkJBSUxcIjogLTIsXG4gIFwiLTJcIjogXCJCQUlMXCJcbn07XG5jb25zdCBQYXRjaEZsYWdOYW1lcyA9IHtcbiAgWzFdOiBgVEVYVGAsXG4gIFsyXTogYENMQVNTYCxcbiAgWzRdOiBgU1RZTEVgLFxuICBbOF06IGBQUk9QU2AsXG4gIFsxNl06IGBGVUxMX1BST1BTYCxcbiAgWzMyXTogYE5FRURfSFlEUkFUSU9OYCxcbiAgWzY0XTogYFNUQUJMRV9GUkFHTUVOVGAsXG4gIFsxMjhdOiBgS0VZRURfRlJBR01FTlRgLFxuICBbMjU2XTogYFVOS0VZRURfRlJBR01FTlRgLFxuICBbNTEyXTogYE5FRURfUEFUQ0hgLFxuICBbMTAyNF06IGBEWU5BTUlDX1NMT1RTYCxcbiAgWzIwNDhdOiBgREVWX1JPT1RfRlJBR01FTlRgLFxuICBbLTFdOiBgQ0FDSEVEYCxcbiAgWy0yXTogYEJBSUxgXG59O1xuXG5jb25zdCBTaGFwZUZsYWdzID0ge1xuICBcIkVMRU1FTlRcIjogMSxcbiAgXCIxXCI6IFwiRUxFTUVOVFwiLFxuICBcIkZVTkNUSU9OQUxfQ09NUE9ORU5UXCI6IDIsXG4gIFwiMlwiOiBcIkZVTkNUSU9OQUxfQ09NUE9ORU5UXCIsXG4gIFwiU1RBVEVGVUxfQ09NUE9ORU5UXCI6IDQsXG4gIFwiNFwiOiBcIlNUQVRFRlVMX0NPTVBPTkVOVFwiLFxuICBcIlRFWFRfQ0hJTERSRU5cIjogOCxcbiAgXCI4XCI6IFwiVEVYVF9DSElMRFJFTlwiLFxuICBcIkFSUkFZX0NISUxEUkVOXCI6IDE2LFxuICBcIjE2XCI6IFwiQVJSQVlfQ0hJTERSRU5cIixcbiAgXCJTTE9UU19DSElMRFJFTlwiOiAzMixcbiAgXCIzMlwiOiBcIlNMT1RTX0NISUxEUkVOXCIsXG4gIFwiVEVMRVBPUlRcIjogNjQsXG4gIFwiNjRcIjogXCJURUxFUE9SVFwiLFxuICBcIlNVU1BFTlNFXCI6IDEyOCxcbiAgXCIxMjhcIjogXCJTVVNQRU5TRVwiLFxuICBcIkNPTVBPTkVOVF9TSE9VTERfS0VFUF9BTElWRVwiOiAyNTYsXG4gIFwiMjU2XCI6IFwiQ09NUE9ORU5UX1NIT1VMRF9LRUVQX0FMSVZFXCIsXG4gIFwiQ09NUE9ORU5UX0tFUFRfQUxJVkVcIjogNTEyLFxuICBcIjUxMlwiOiBcIkNPTVBPTkVOVF9LRVBUX0FMSVZFXCIsXG4gIFwiQ09NUE9ORU5UXCI6IDYsXG4gIFwiNlwiOiBcIkNPTVBPTkVOVFwiXG59O1xuXG5jb25zdCBTbG90RmxhZ3MgPSB7XG4gIFwiU1RBQkxFXCI6IDEsXG4gIFwiMVwiOiBcIlNUQUJMRVwiLFxuICBcIkRZTkFNSUNcIjogMixcbiAgXCIyXCI6IFwiRFlOQU1JQ1wiLFxuICBcIkZPUldBUkRFRFwiOiAzLFxuICBcIjNcIjogXCJGT1JXQVJERURcIlxufTtcbmNvbnN0IHNsb3RGbGFnc1RleHQgPSB7XG4gIFsxXTogXCJTVEFCTEVcIixcbiAgWzJdOiBcIkRZTkFNSUNcIixcbiAgWzNdOiBcIkZPUldBUkRFRFwiXG59O1xuXG5jb25zdCBHTE9CQUxTX0FMTE9XRUQgPSBcIkluZmluaXR5LHVuZGVmaW5lZCxOYU4saXNGaW5pdGUsaXNOYU4scGFyc2VGbG9hdCxwYXJzZUludCxkZWNvZGVVUkksZGVjb2RlVVJJQ29tcG9uZW50LGVuY29kZVVSSSxlbmNvZGVVUklDb21wb25lbnQsTWF0aCxOdW1iZXIsRGF0ZSxBcnJheSxPYmplY3QsQm9vbGVhbixTdHJpbmcsUmVnRXhwLE1hcCxTZXQsSlNPTixJbnRsLEJpZ0ludCxjb25zb2xlLEVycm9yLFN5bWJvbFwiO1xuY29uc3QgaXNHbG9iYWxseUFsbG93ZWQgPSAvKiBAX19QVVJFX18gKi8gbWFrZU1hcChHTE9CQUxTX0FMTE9XRUQpO1xuY29uc3QgaXNHbG9iYWxseVdoaXRlbGlzdGVkID0gaXNHbG9iYWxseUFsbG93ZWQ7XG5cbmNvbnN0IHJhbmdlID0gMjtcbmZ1bmN0aW9uIGdlbmVyYXRlQ29kZUZyYW1lKHNvdXJjZSwgc3RhcnQgPSAwLCBlbmQgPSBzb3VyY2UubGVuZ3RoKSB7XG4gIHN0YXJ0ID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oc3RhcnQsIHNvdXJjZS5sZW5ndGgpKTtcbiAgZW5kID0gTWF0aC5tYXgoMCwgTWF0aC5taW4oZW5kLCBzb3VyY2UubGVuZ3RoKSk7XG4gIGlmIChzdGFydCA+IGVuZCkgcmV0dXJuIFwiXCI7XG4gIGxldCBsaW5lcyA9IHNvdXJjZS5zcGxpdCgvKFxccj9cXG4pLyk7XG4gIGNvbnN0IG5ld2xpbmVTZXF1ZW5jZXMgPSBsaW5lcy5maWx0ZXIoKF8sIGlkeCkgPT4gaWR4ICUgMiA9PT0gMSk7XG4gIGxpbmVzID0gbGluZXMuZmlsdGVyKChfLCBpZHgpID0+IGlkeCAlIDIgPT09IDApO1xuICBsZXQgY291bnQgPSAwO1xuICBjb25zdCByZXMgPSBbXTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsaW5lcy5sZW5ndGg7IGkrKykge1xuICAgIGNvdW50ICs9IGxpbmVzW2ldLmxlbmd0aCArIChuZXdsaW5lU2VxdWVuY2VzW2ldICYmIG5ld2xpbmVTZXF1ZW5jZXNbaV0ubGVuZ3RoIHx8IDApO1xuICAgIGlmIChjb3VudCA+PSBzdGFydCkge1xuICAgICAgZm9yIChsZXQgaiA9IGkgLSByYW5nZTsgaiA8PSBpICsgcmFuZ2UgfHwgZW5kID4gY291bnQ7IGorKykge1xuICAgICAgICBpZiAoaiA8IDAgfHwgaiA+PSBsaW5lcy5sZW5ndGgpIGNvbnRpbnVlO1xuICAgICAgICBjb25zdCBsaW5lID0gaiArIDE7XG4gICAgICAgIHJlcy5wdXNoKFxuICAgICAgICAgIGAke2xpbmV9JHtcIiBcIi5yZXBlYXQoTWF0aC5tYXgoMyAtIFN0cmluZyhsaW5lKS5sZW5ndGgsIDApKX18ICAke2xpbmVzW2pdfWBcbiAgICAgICAgKTtcbiAgICAgICAgY29uc3QgbGluZUxlbmd0aCA9IGxpbmVzW2pdLmxlbmd0aDtcbiAgICAgICAgY29uc3QgbmV3TGluZVNlcUxlbmd0aCA9IG5ld2xpbmVTZXF1ZW5jZXNbal0gJiYgbmV3bGluZVNlcXVlbmNlc1tqXS5sZW5ndGggfHwgMDtcbiAgICAgICAgaWYgKGogPT09IGkpIHtcbiAgICAgICAgICBjb25zdCBwYWQgPSBzdGFydCAtIChjb3VudCAtIChsaW5lTGVuZ3RoICsgbmV3TGluZVNlcUxlbmd0aCkpO1xuICAgICAgICAgIGNvbnN0IGxlbmd0aCA9IE1hdGgubWF4KFxuICAgICAgICAgICAgMSxcbiAgICAgICAgICAgIGVuZCA+IGNvdW50ID8gbGluZUxlbmd0aCAtIHBhZCA6IGVuZCAtIHN0YXJ0XG4gICAgICAgICAgKTtcbiAgICAgICAgICByZXMucHVzaChgICAgfCAgYCArIFwiIFwiLnJlcGVhdChwYWQpICsgXCJeXCIucmVwZWF0KGxlbmd0aCkpO1xuICAgICAgICB9IGVsc2UgaWYgKGogPiBpKSB7XG4gICAgICAgICAgaWYgKGVuZCA+IGNvdW50KSB7XG4gICAgICAgICAgICBjb25zdCBsZW5ndGggPSBNYXRoLm1heChNYXRoLm1pbihlbmQgLSBjb3VudCwgbGluZUxlbmd0aCksIDEpO1xuICAgICAgICAgICAgcmVzLnB1c2goYCAgIHwgIGAgKyBcIl5cIi5yZXBlYXQobGVuZ3RoKSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvdW50ICs9IGxpbmVMZW5ndGggKyBuZXdMaW5lU2VxTGVuZ3RoO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBicmVhaztcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlcy5qb2luKFwiXFxuXCIpO1xufVxuXG5mdW5jdGlvbiBub3JtYWxpemVTdHlsZSh2YWx1ZSkge1xuICBpZiAoaXNBcnJheSh2YWx1ZSkpIHtcbiAgICBjb25zdCByZXMgPSB7fTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHZhbHVlLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBpdGVtID0gdmFsdWVbaV07XG4gICAgICBjb25zdCBub3JtYWxpemVkID0gaXNTdHJpbmcoaXRlbSkgPyBwYXJzZVN0cmluZ1N0eWxlKGl0ZW0pIDogbm9ybWFsaXplU3R5bGUoaXRlbSk7XG4gICAgICBpZiAobm9ybWFsaXplZCkge1xuICAgICAgICBmb3IgKGNvbnN0IGtleSBpbiBub3JtYWxpemVkKSB7XG4gICAgICAgICAgcmVzW2tleV0gPSBub3JtYWxpemVkW2tleV07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHJlcztcbiAgfSBlbHNlIGlmIChpc1N0cmluZyh2YWx1ZSkgfHwgaXNPYmplY3QodmFsdWUpKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG59XG5jb25zdCBsaXN0RGVsaW1pdGVyUkUgPSAvOyg/IVteKF0qXFwpKS9nO1xuY29uc3QgcHJvcGVydHlEZWxpbWl0ZXJSRSA9IC86KFteXSspLztcbmNvbnN0IHN0eWxlQ29tbWVudFJFID0gL1xcL1xcKlteXSo/XFwqXFwvL2c7XG5mdW5jdGlvbiBwYXJzZVN0cmluZ1N0eWxlKGNzc1RleHQpIHtcbiAgY29uc3QgcmV0ID0ge307XG4gIGNzc1RleHQucmVwbGFjZShzdHlsZUNvbW1lbnRSRSwgXCJcIikuc3BsaXQobGlzdERlbGltaXRlclJFKS5mb3JFYWNoKChpdGVtKSA9PiB7XG4gICAgaWYgKGl0ZW0pIHtcbiAgICAgIGNvbnN0IHRtcCA9IGl0ZW0uc3BsaXQocHJvcGVydHlEZWxpbWl0ZXJSRSk7XG4gICAgICB0bXAubGVuZ3RoID4gMSAmJiAocmV0W3RtcFswXS50cmltKCldID0gdG1wWzFdLnRyaW0oKSk7XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIHJldDtcbn1cbmZ1bmN0aW9uIHN0cmluZ2lmeVN0eWxlKHN0eWxlcykge1xuICBpZiAoIXN0eWxlcykgcmV0dXJuIFwiXCI7XG4gIGlmIChpc1N0cmluZyhzdHlsZXMpKSByZXR1cm4gc3R5bGVzO1xuICBsZXQgcmV0ID0gXCJcIjtcbiAgZm9yIChjb25zdCBrZXkgaW4gc3R5bGVzKSB7XG4gICAgY29uc3QgdmFsdWUgPSBzdHlsZXNba2V5XTtcbiAgICBpZiAoaXNTdHJpbmcodmFsdWUpIHx8IHR5cGVvZiB2YWx1ZSA9PT0gXCJudW1iZXJcIikge1xuICAgICAgY29uc3Qgbm9ybWFsaXplZEtleSA9IGtleS5zdGFydHNXaXRoKGAtLWApID8ga2V5IDogaHlwaGVuYXRlKGtleSk7XG4gICAgICByZXQgKz0gYCR7bm9ybWFsaXplZEtleX06JHt2YWx1ZX07YDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJldDtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZUNsYXNzKHZhbHVlKSB7XG4gIGxldCByZXMgPSBcIlwiO1xuICBpZiAoaXNTdHJpbmcodmFsdWUpKSB7XG4gICAgcmVzID0gdmFsdWU7XG4gIH0gZWxzZSBpZiAoaXNBcnJheSh2YWx1ZSkpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHZhbHVlLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBub3JtYWxpemVkID0gbm9ybWFsaXplQ2xhc3ModmFsdWVbaV0pO1xuICAgICAgaWYgKG5vcm1hbGl6ZWQpIHtcbiAgICAgICAgcmVzICs9IG5vcm1hbGl6ZWQgKyBcIiBcIjtcbiAgICAgIH1cbiAgICB9XG4gIH0gZWxzZSBpZiAoaXNPYmplY3QodmFsdWUpKSB7XG4gICAgZm9yIChjb25zdCBuYW1lIGluIHZhbHVlKSB7XG4gICAgICBpZiAodmFsdWVbbmFtZV0pIHtcbiAgICAgICAgcmVzICs9IG5hbWUgKyBcIiBcIjtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlcy50cmltKCk7XG59XG5mdW5jdGlvbiBub3JtYWxpemVQcm9wcyhwcm9wcykge1xuICBpZiAoIXByb3BzKSByZXR1cm4gbnVsbDtcbiAgbGV0IHsgY2xhc3M6IGtsYXNzLCBzdHlsZSB9ID0gcHJvcHM7XG4gIGlmIChrbGFzcyAmJiAhaXNTdHJpbmcoa2xhc3MpKSB7XG4gICAgcHJvcHMuY2xhc3MgPSBub3JtYWxpemVDbGFzcyhrbGFzcyk7XG4gIH1cbiAgaWYgKHN0eWxlKSB7XG4gICAgcHJvcHMuc3R5bGUgPSBub3JtYWxpemVTdHlsZShzdHlsZSk7XG4gIH1cbiAgcmV0dXJuIHByb3BzO1xufVxuXG5jb25zdCBIVE1MX1RBR1MgPSBcImh0bWwsYm9keSxiYXNlLGhlYWQsbGluayxtZXRhLHN0eWxlLHRpdGxlLGFkZHJlc3MsYXJ0aWNsZSxhc2lkZSxmb290ZXIsaGVhZGVyLGhncm91cCxoMSxoMixoMyxoNCxoNSxoNixuYXYsc2VjdGlvbixkaXYsZGQsZGwsZHQsZmlnY2FwdGlvbixmaWd1cmUscGljdHVyZSxocixpbWcsbGksbWFpbixvbCxwLHByZSx1bCxhLGIsYWJicixiZGksYmRvLGJyLGNpdGUsY29kZSxkYXRhLGRmbixlbSxpLGtiZCxtYXJrLHEscnAscnQscnVieSxzLHNhbXAsc21hbGwsc3BhbixzdHJvbmcsc3ViLHN1cCx0aW1lLHUsdmFyLHdicixhcmVhLGF1ZGlvLG1hcCx0cmFjayx2aWRlbyxlbWJlZCxvYmplY3QscGFyYW0sc291cmNlLGNhbnZhcyxzY3JpcHQsbm9zY3JpcHQsZGVsLGlucyxjYXB0aW9uLGNvbCxjb2xncm91cCx0YWJsZSx0aGVhZCx0Ym9keSx0ZCx0aCx0cixidXR0b24sZGF0YWxpc3QsZmllbGRzZXQsZm9ybSxpbnB1dCxsYWJlbCxsZWdlbmQsbWV0ZXIsb3B0Z3JvdXAsb3B0aW9uLG91dHB1dCxwcm9ncmVzcyxzZWxlY3QsdGV4dGFyZWEsZGV0YWlscyxkaWFsb2csbWVudSxzdW1tYXJ5LHRlbXBsYXRlLGJsb2NrcXVvdGUsaWZyYW1lLHRmb290XCI7XG5jb25zdCBTVkdfVEFHUyA9IFwic3ZnLGFuaW1hdGUsYW5pbWF0ZU1vdGlvbixhbmltYXRlVHJhbnNmb3JtLGNpcmNsZSxjbGlwUGF0aCxjb2xvci1wcm9maWxlLGRlZnMsZGVzYyxkaXNjYXJkLGVsbGlwc2UsZmVCbGVuZCxmZUNvbG9yTWF0cml4LGZlQ29tcG9uZW50VHJhbnNmZXIsZmVDb21wb3NpdGUsZmVDb252b2x2ZU1hdHJpeCxmZURpZmZ1c2VMaWdodGluZyxmZURpc3BsYWNlbWVudE1hcCxmZURpc3RhbnRMaWdodCxmZURyb3BTaGFkb3csZmVGbG9vZCxmZUZ1bmNBLGZlRnVuY0IsZmVGdW5jRyxmZUZ1bmNSLGZlR2F1c3NpYW5CbHVyLGZlSW1hZ2UsZmVNZXJnZSxmZU1lcmdlTm9kZSxmZU1vcnBob2xvZ3ksZmVPZmZzZXQsZmVQb2ludExpZ2h0LGZlU3BlY3VsYXJMaWdodGluZyxmZVNwb3RMaWdodCxmZVRpbGUsZmVUdXJidWxlbmNlLGZpbHRlcixmb3JlaWduT2JqZWN0LGcsaGF0Y2gsaGF0Y2hwYXRoLGltYWdlLGxpbmUsbGluZWFyR3JhZGllbnQsbWFya2VyLG1hc2ssbWVzaCxtZXNoZ3JhZGllbnQsbWVzaHBhdGNoLG1lc2hyb3csbWV0YWRhdGEsbXBhdGgscGF0aCxwYXR0ZXJuLHBvbHlnb24scG9seWxpbmUscmFkaWFsR3JhZGllbnQscmVjdCxzZXQsc29saWRjb2xvcixzdG9wLHN3aXRjaCxzeW1ib2wsdGV4dCx0ZXh0UGF0aCx0aXRsZSx0c3Bhbix1bmtub3duLHVzZSx2aWV3XCI7XG5jb25zdCBNQVRIX1RBR1MgPSBcImFubm90YXRpb24sYW5ub3RhdGlvbi14bWwsbWFjdGlvbixtYWxpZ25ncm91cCxtYWxpZ25tYXJrLG1hdGgsbWVuY2xvc2UsbWVycm9yLG1mZW5jZWQsbWZyYWMsbWZyYWN0aW9uLG1nbHlwaCxtaSxtbGFiZWxlZHRyLG1sb25nZGl2LG1tdWx0aXNjcmlwdHMsbW4sbW8sbW92ZXIsbXBhZGRlZCxtcGhhbnRvbSxtcHJlc2NyaXB0cyxtcm9vdCxtcm93LG1zLG1zY2Fycmllcyxtc2NhcnJ5LG1zZ3JvdXAsbXNsaW5lLG1zcGFjZSxtc3FydCxtc3Jvdyxtc3RhY2ssbXN0eWxlLG1zdWIsbXN1YnN1cCxtc3VwLG10YWJsZSxtdGQsbXRleHQsbXRyLG11bmRlcixtdW5kZXJvdmVyLG5vbmUsc2VtYW50aWNzXCI7XG5jb25zdCBWT0lEX1RBR1MgPSBcImFyZWEsYmFzZSxicixjb2wsZW1iZWQsaHIsaW1nLGlucHV0LGxpbmssbWV0YSxwYXJhbSxzb3VyY2UsdHJhY2ssd2JyXCI7XG5jb25zdCBpc0hUTUxUYWcgPSAvKiBAX19QVVJFX18gKi8gbWFrZU1hcChIVE1MX1RBR1MpO1xuY29uc3QgaXNTVkdUYWcgPSAvKiBAX19QVVJFX18gKi8gbWFrZU1hcChTVkdfVEFHUyk7XG5jb25zdCBpc01hdGhNTFRhZyA9IC8qIEBfX1BVUkVfXyAqLyBtYWtlTWFwKE1BVEhfVEFHUyk7XG5jb25zdCBpc1ZvaWRUYWcgPSAvKiBAX19QVVJFX18gKi8gbWFrZU1hcChWT0lEX1RBR1MpO1xuXG5jb25zdCBzcGVjaWFsQm9vbGVhbkF0dHJzID0gYGl0ZW1zY29wZSxhbGxvd2Z1bGxzY3JlZW4sZm9ybW5vdmFsaWRhdGUsaXNtYXAsbm9tb2R1bGUsbm92YWxpZGF0ZSxyZWFkb25seWA7XG5jb25zdCBpc1NwZWNpYWxCb29sZWFuQXR0ciA9IC8qIEBfX1BVUkVfXyAqLyBtYWtlTWFwKHNwZWNpYWxCb29sZWFuQXR0cnMpO1xuY29uc3QgaXNCb29sZWFuQXR0ciA9IC8qIEBfX1BVUkVfXyAqLyBtYWtlTWFwKFxuICBzcGVjaWFsQm9vbGVhbkF0dHJzICsgYCxhc3luYyxhdXRvZm9jdXMsYXV0b3BsYXksY29udHJvbHMsZGVmYXVsdCxkZWZlcixkaXNhYmxlZCxoaWRkZW4saW5lcnQsbG9vcCxvcGVuLHJlcXVpcmVkLHJldmVyc2VkLHNjb3BlZCxzZWFtbGVzcyxjaGVja2VkLG11dGVkLG11bHRpcGxlLHNlbGVjdGVkYFxuKTtcbmZ1bmN0aW9uIGluY2x1ZGVCb29sZWFuQXR0cih2YWx1ZSkge1xuICByZXR1cm4gISF2YWx1ZSB8fCB2YWx1ZSA9PT0gXCJcIjtcbn1cbmNvbnN0IHVuc2FmZUF0dHJDaGFyUkUgPSAvWz4vPVwiJ1xcdTAwMDlcXHUwMDBhXFx1MDAwY1xcdTAwMjBdLztcbmNvbnN0IGF0dHJWYWxpZGF0aW9uQ2FjaGUgPSB7fTtcbmZ1bmN0aW9uIGlzU1NSU2FmZUF0dHJOYW1lKG5hbWUpIHtcbiAgaWYgKGF0dHJWYWxpZGF0aW9uQ2FjaGUuaGFzT3duUHJvcGVydHkobmFtZSkpIHtcbiAgICByZXR1cm4gYXR0clZhbGlkYXRpb25DYWNoZVtuYW1lXTtcbiAgfVxuICBjb25zdCBpc1Vuc2FmZSA9IHVuc2FmZUF0dHJDaGFyUkUudGVzdChuYW1lKTtcbiAgaWYgKGlzVW5zYWZlKSB7XG4gICAgY29uc29sZS5lcnJvcihgdW5zYWZlIGF0dHJpYnV0ZSBuYW1lOiAke25hbWV9YCk7XG4gIH1cbiAgcmV0dXJuIGF0dHJWYWxpZGF0aW9uQ2FjaGVbbmFtZV0gPSAhaXNVbnNhZmU7XG59XG5jb25zdCBwcm9wc1RvQXR0ck1hcCA9IHtcbiAgYWNjZXB0Q2hhcnNldDogXCJhY2NlcHQtY2hhcnNldFwiLFxuICBjbGFzc05hbWU6IFwiY2xhc3NcIixcbiAgaHRtbEZvcjogXCJmb3JcIixcbiAgaHR0cEVxdWl2OiBcImh0dHAtZXF1aXZcIlxufTtcbmNvbnN0IGlzS25vd25IdG1sQXR0ciA9IC8qIEBfX1BVUkVfXyAqLyBtYWtlTWFwKFxuICBgYWNjZXB0LGFjY2VwdC1jaGFyc2V0LGFjY2Vzc2tleSxhY3Rpb24sYWxpZ24sYWxsb3csYWx0LGFzeW5jLGF1dG9jYXBpdGFsaXplLGF1dG9jb21wbGV0ZSxhdXRvZm9jdXMsYXV0b3BsYXksYmFja2dyb3VuZCxiZ2NvbG9yLGJvcmRlcixidWZmZXJlZCxjYXB0dXJlLGNoYWxsZW5nZSxjaGFyc2V0LGNoZWNrZWQsY2l0ZSxjbGFzcyxjb2RlLGNvZGViYXNlLGNvbG9yLGNvbHMsY29sc3Bhbixjb250ZW50LGNvbnRlbnRlZGl0YWJsZSxjb250ZXh0bWVudSxjb250cm9scyxjb29yZHMsY3Jvc3NvcmlnaW4sY3NwLGRhdGEsZGF0ZXRpbWUsZGVjb2RpbmcsZGVmYXVsdCxkZWZlcixkaXIsZGlybmFtZSxkaXNhYmxlZCxkb3dubG9hZCxkcmFnZ2FibGUsZHJvcHpvbmUsZW5jdHlwZSxlbnRlcmtleWhpbnQsZm9yLGZvcm0sZm9ybWFjdGlvbixmb3JtZW5jdHlwZSxmb3JtbWV0aG9kLGZvcm1ub3ZhbGlkYXRlLGZvcm10YXJnZXQsaGVhZGVycyxoZWlnaHQsaGlkZGVuLGhpZ2gsaHJlZixocmVmbGFuZyxodHRwLWVxdWl2LGljb24saWQsaW1wb3J0YW5jZSxpbmVydCxpbnRlZ3JpdHksaXNtYXAsaXRlbXByb3Asa2V5dHlwZSxraW5kLGxhYmVsLGxhbmcsbGFuZ3VhZ2UsbG9hZGluZyxsaXN0LGxvb3AsbG93LG1hbmlmZXN0LG1heCxtYXhsZW5ndGgsbWlubGVuZ3RoLG1lZGlhLG1pbixtdWx0aXBsZSxtdXRlZCxuYW1lLG5vdmFsaWRhdGUsb3BlbixvcHRpbXVtLHBhdHRlcm4scGluZyxwbGFjZWhvbGRlcixwb3N0ZXIscHJlbG9hZCxyYWRpb2dyb3VwLHJlYWRvbmx5LHJlZmVycmVycG9saWN5LHJlbCxyZXF1aXJlZCxyZXZlcnNlZCxyb3dzLHJvd3NwYW4sc2FuZGJveCxzY29wZSxzY29wZWQsc2VsZWN0ZWQsc2hhcGUsc2l6ZSxzaXplcyxzbG90LHNwYW4sc3BlbGxjaGVjayxzcmMsc3JjZG9jLHNyY2xhbmcsc3Jjc2V0LHN0YXJ0LHN0ZXAsc3R5bGUsc3VtbWFyeSx0YWJpbmRleCx0YXJnZXQsdGl0bGUsdHJhbnNsYXRlLHR5cGUsdXNlbWFwLHZhbHVlLHdpZHRoLHdyYXBgXG4pO1xuY29uc3QgaXNLbm93blN2Z0F0dHIgPSAvKiBAX19QVVJFX18gKi8gbWFrZU1hcChcbiAgYHhtbG5zLGFjY2VudC1oZWlnaHQsYWNjdW11bGF0ZSxhZGRpdGl2ZSxhbGlnbm1lbnQtYmFzZWxpbmUsYWxwaGFiZXRpYyxhbXBsaXR1ZGUsYXJhYmljLWZvcm0sYXNjZW50LGF0dHJpYnV0ZU5hbWUsYXR0cmlidXRlVHlwZSxhemltdXRoLGJhc2VGcmVxdWVuY3ksYmFzZWxpbmUtc2hpZnQsYmFzZVByb2ZpbGUsYmJveCxiZWdpbixiaWFzLGJ5LGNhbGNNb2RlLGNhcC1oZWlnaHQsY2xhc3MsY2xpcCxjbGlwUGF0aFVuaXRzLGNsaXAtcGF0aCxjbGlwLXJ1bGUsY29sb3IsY29sb3ItaW50ZXJwb2xhdGlvbixjb2xvci1pbnRlcnBvbGF0aW9uLWZpbHRlcnMsY29sb3ItcHJvZmlsZSxjb2xvci1yZW5kZXJpbmcsY29udGVudFNjcmlwdFR5cGUsY29udGVudFN0eWxlVHlwZSxjcm9zc29yaWdpbixjdXJzb3IsY3gsY3ksZCxkZWNlbGVyYXRlLGRlc2NlbnQsZGlmZnVzZUNvbnN0YW50LGRpcmVjdGlvbixkaXNwbGF5LGRpdmlzb3IsZG9taW5hbnQtYmFzZWxpbmUsZHVyLGR4LGR5LGVkZ2VNb2RlLGVsZXZhdGlvbixlbmFibGUtYmFja2dyb3VuZCxlbmQsZXhwb25lbnQsZmlsbCxmaWxsLW9wYWNpdHksZmlsbC1ydWxlLGZpbHRlcixmaWx0ZXJSZXMsZmlsdGVyVW5pdHMsZmxvb2QtY29sb3IsZmxvb2Qtb3BhY2l0eSxmb250LWZhbWlseSxmb250LXNpemUsZm9udC1zaXplLWFkanVzdCxmb250LXN0cmV0Y2gsZm9udC1zdHlsZSxmb250LXZhcmlhbnQsZm9udC13ZWlnaHQsZm9ybWF0LGZyb20sZnIsZngsZnksZzEsZzIsZ2x5cGgtbmFtZSxnbHlwaC1vcmllbnRhdGlvbi1ob3Jpem9udGFsLGdseXBoLW9yaWVudGF0aW9uLXZlcnRpY2FsLGdseXBoUmVmLGdyYWRpZW50VHJhbnNmb3JtLGdyYWRpZW50VW5pdHMsaGFuZ2luZyxoZWlnaHQsaHJlZixocmVmbGFuZyxob3Jpei1hZHYteCxob3Jpei1vcmlnaW4teCxpZCxpZGVvZ3JhcGhpYyxpbWFnZS1yZW5kZXJpbmcsaW4saW4yLGludGVyY2VwdCxrLGsxLGsyLGszLGs0LGtlcm5lbE1hdHJpeCxrZXJuZWxVbml0TGVuZ3RoLGtlcm5pbmcsa2V5UG9pbnRzLGtleVNwbGluZXMsa2V5VGltZXMsbGFuZyxsZW5ndGhBZGp1c3QsbGV0dGVyLXNwYWNpbmcsbGlnaHRpbmctY29sb3IsbGltaXRpbmdDb25lQW5nbGUsbG9jYWwsbWFya2VyLWVuZCxtYXJrZXItbWlkLG1hcmtlci1zdGFydCxtYXJrZXJIZWlnaHQsbWFya2VyVW5pdHMsbWFya2VyV2lkdGgsbWFzayxtYXNrQ29udGVudFVuaXRzLG1hc2tVbml0cyxtYXRoZW1hdGljYWwsbWF4LG1lZGlhLG1ldGhvZCxtaW4sbW9kZSxuYW1lLG51bU9jdGF2ZXMsb2Zmc2V0LG9wYWNpdHksb3BlcmF0b3Isb3JkZXIsb3JpZW50LG9yaWVudGF0aW9uLG9yaWdpbixvdmVyZmxvdyxvdmVybGluZS1wb3NpdGlvbixvdmVybGluZS10aGlja25lc3MscGFub3NlLTEscGFpbnQtb3JkZXIscGF0aCxwYXRoTGVuZ3RoLHBhdHRlcm5Db250ZW50VW5pdHMscGF0dGVyblRyYW5zZm9ybSxwYXR0ZXJuVW5pdHMscGluZyxwb2ludGVyLWV2ZW50cyxwb2ludHMscG9pbnRzQXRYLHBvaW50c0F0WSxwb2ludHNBdFoscHJlc2VydmVBbHBoYSxwcmVzZXJ2ZUFzcGVjdFJhdGlvLHByaW1pdGl2ZVVuaXRzLHIscmFkaXVzLHJlZmVycmVyUG9saWN5LHJlZlgscmVmWSxyZWwscmVuZGVyaW5nLWludGVudCxyZXBlYXRDb3VudCxyZXBlYXREdXIscmVxdWlyZWRFeHRlbnNpb25zLHJlcXVpcmVkRmVhdHVyZXMscmVzdGFydCxyZXN1bHQscm90YXRlLHJ4LHJ5LHNjYWxlLHNlZWQsc2hhcGUtcmVuZGVyaW5nLHNsb3BlLHNwYWNpbmcsc3BlY3VsYXJDb25zdGFudCxzcGVjdWxhckV4cG9uZW50LHNwZWVkLHNwcmVhZE1ldGhvZCxzdGFydE9mZnNldCxzdGREZXZpYXRpb24sc3RlbWgsc3RlbXYsc3RpdGNoVGlsZXMsc3RvcC1jb2xvcixzdG9wLW9wYWNpdHksc3RyaWtldGhyb3VnaC1wb3NpdGlvbixzdHJpa2V0aHJvdWdoLXRoaWNrbmVzcyxzdHJpbmcsc3Ryb2tlLHN0cm9rZS1kYXNoYXJyYXksc3Ryb2tlLWRhc2hvZmZzZXQsc3Ryb2tlLWxpbmVjYXAsc3Ryb2tlLWxpbmVqb2luLHN0cm9rZS1taXRlcmxpbWl0LHN0cm9rZS1vcGFjaXR5LHN0cm9rZS13aWR0aCxzdHlsZSxzdXJmYWNlU2NhbGUsc3lzdGVtTGFuZ3VhZ2UsdGFiaW5kZXgsdGFibGVWYWx1ZXMsdGFyZ2V0LHRhcmdldFgsdGFyZ2V0WSx0ZXh0LWFuY2hvcix0ZXh0LWRlY29yYXRpb24sdGV4dC1yZW5kZXJpbmcsdGV4dExlbmd0aCx0byx0cmFuc2Zvcm0sdHJhbnNmb3JtLW9yaWdpbix0eXBlLHUxLHUyLHVuZGVybGluZS1wb3NpdGlvbix1bmRlcmxpbmUtdGhpY2tuZXNzLHVuaWNvZGUsdW5pY29kZS1iaWRpLHVuaWNvZGUtcmFuZ2UsdW5pdHMtcGVyLWVtLHYtYWxwaGFiZXRpYyx2LWhhbmdpbmcsdi1pZGVvZ3JhcGhpYyx2LW1hdGhlbWF0aWNhbCx2YWx1ZXMsdmVjdG9yLWVmZmVjdCx2ZXJzaW9uLHZlcnQtYWR2LXksdmVydC1vcmlnaW4teCx2ZXJ0LW9yaWdpbi15LHZpZXdCb3gsdmlld1RhcmdldCx2aXNpYmlsaXR5LHdpZHRoLHdpZHRocyx3b3JkLXNwYWNpbmcsd3JpdGluZy1tb2RlLHgseC1oZWlnaHQseDEseDIseENoYW5uZWxTZWxlY3Rvcix4bGluazphY3R1YXRlLHhsaW5rOmFyY3JvbGUseGxpbms6aHJlZix4bGluazpyb2xlLHhsaW5rOnNob3cseGxpbms6dGl0bGUseGxpbms6dHlwZSx4bWxuczp4bGluayx4bWw6YmFzZSx4bWw6bGFuZyx4bWw6c3BhY2UseSx5MSx5Mix5Q2hhbm5lbFNlbGVjdG9yLHosem9vbUFuZFBhbmBcbik7XG5jb25zdCBpc0tub3duTWF0aE1MQXR0ciA9IC8qIEBfX1BVUkVfXyAqLyBtYWtlTWFwKFxuICBgYWNjZW50LGFjY2VudHVuZGVyLGFjdGlvbnR5cGUsYWxpZ24sYWxpZ25tZW50c2NvcGUsYWx0aW1nLGFsdGltZy1oZWlnaHQsYWx0aW1nLXZhbGlnbixhbHRpbWctd2lkdGgsYWx0dGV4dCxiZXZlbGxlZCxjbG9zZSxjb2x1bW5zYWxpZ24sY29sdW1ubGluZXMsY29sdW1uc3BhbixkZW5vbWFsaWduLGRlcHRoLGRpcixkaXNwbGF5LGRpc3BsYXlzdHlsZSxlbmNvZGluZyxlcXVhbGNvbHVtbnMsZXF1YWxyb3dzLGZlbmNlLGZvbnRzdHlsZSxmb250d2VpZ2h0LGZvcm0sZnJhbWUsZnJhbWVzcGFjaW5nLGdyb3VwYWxpZ24saGVpZ2h0LGhyZWYsaWQsaW5kZW50YWxpZ24saW5kZW50YWxpZ25maXJzdCxpbmRlbnRhbGlnbmxhc3QsaW5kZW50c2hpZnQsaW5kZW50c2hpZnRmaXJzdCxpbmRlbnRzaGlmdGxhc3QsaW5kZXh0eXBlLGp1c3RpZnksbGFyZ2V0b3AsbGFyZ2VvcCxscXVvdGUsbHNwYWNlLG1hdGhiYWNrZ3JvdW5kLG1hdGhjb2xvcixtYXRoc2l6ZSxtYXRodmFyaWFudCxtYXhzaXplLG1pbmxhYmVsc3BhY2luZyxtb2RlLG90aGVyLG92ZXJmbG93LHBvc2l0aW9uLHJvd2FsaWduLHJvd2xpbmVzLHJvd3NwYW4scnF1b3RlLHJzcGFjZSxzY3JpcHRsZXZlbCxzY3JpcHRtaW5zaXplLHNjcmlwdHNpemVtdWx0aXBsaWVyLHNlbGVjdGlvbixzZXBhcmF0b3Isc2VwYXJhdG9ycyxzaGlmdCxzaWRlLHNyYyxzdGFja2FsaWduLHN0cmV0Y2h5LHN1YnNjcmlwdHNoaWZ0LHN1cGVyc2NyaXB0c2hpZnQsc3ltbWV0cmljLHZvZmZzZXQsd2lkdGgsd2lkdGhzLHhsaW5rOmhyZWYseGxpbms6c2hvdyx4bGluazp0eXBlLHhtbG5zYFxuKTtcbmZ1bmN0aW9uIGlzUmVuZGVyYWJsZUF0dHJWYWx1ZSh2YWx1ZSkge1xuICBpZiAodmFsdWUgPT0gbnVsbCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBjb25zdCB0eXBlID0gdHlwZW9mIHZhbHVlO1xuICByZXR1cm4gdHlwZSA9PT0gXCJzdHJpbmdcIiB8fCB0eXBlID09PSBcIm51bWJlclwiIHx8IHR5cGUgPT09IFwiYm9vbGVhblwiO1xufVxuXG5jb25zdCBlc2NhcGVSRSA9IC9bXCInJjw+XS87XG5mdW5jdGlvbiBlc2NhcGVIdG1sKHN0cmluZykge1xuICBjb25zdCBzdHIgPSBcIlwiICsgc3RyaW5nO1xuICBjb25zdCBtYXRjaCA9IGVzY2FwZVJFLmV4ZWMoc3RyKTtcbiAgaWYgKCFtYXRjaCkge1xuICAgIHJldHVybiBzdHI7XG4gIH1cbiAgbGV0IGh0bWwgPSBcIlwiO1xuICBsZXQgZXNjYXBlZDtcbiAgbGV0IGluZGV4O1xuICBsZXQgbGFzdEluZGV4ID0gMDtcbiAgZm9yIChpbmRleCA9IG1hdGNoLmluZGV4OyBpbmRleCA8IHN0ci5sZW5ndGg7IGluZGV4KyspIHtcbiAgICBzd2l0Y2ggKHN0ci5jaGFyQ29kZUF0KGluZGV4KSkge1xuICAgICAgY2FzZSAzNDpcbiAgICAgICAgZXNjYXBlZCA9IFwiJnF1b3Q7XCI7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAzODpcbiAgICAgICAgZXNjYXBlZCA9IFwiJmFtcDtcIjtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIDM5OlxuICAgICAgICBlc2NhcGVkID0gXCImIzM5O1wiO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgNjA6XG4gICAgICAgIGVzY2FwZWQgPSBcIiZsdDtcIjtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIDYyOlxuICAgICAgICBlc2NhcGVkID0gXCImZ3Q7XCI7XG4gICAgICAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChsYXN0SW5kZXggIT09IGluZGV4KSB7XG4gICAgICBodG1sICs9IHN0ci5zbGljZShsYXN0SW5kZXgsIGluZGV4KTtcbiAgICB9XG4gICAgbGFzdEluZGV4ID0gaW5kZXggKyAxO1xuICAgIGh0bWwgKz0gZXNjYXBlZDtcbiAgfVxuICByZXR1cm4gbGFzdEluZGV4ICE9PSBpbmRleCA/IGh0bWwgKyBzdHIuc2xpY2UobGFzdEluZGV4LCBpbmRleCkgOiBodG1sO1xufVxuY29uc3QgY29tbWVudFN0cmlwUkUgPSAvXig/Oi0/PikrfDwhLS18LS0+fC0tIT58PCEtJC9nO1xuZnVuY3Rpb24gZXNjYXBlSHRtbENvbW1lbnQoc3JjKSB7XG4gIGxldCBwcmV2O1xuICBkbyB7XG4gICAgcHJldiA9IHNyYztcbiAgICBzcmMgPSBzcmMucmVwbGFjZShjb21tZW50U3RyaXBSRSwgXCJcIik7XG4gIH0gd2hpbGUgKHNyYyAhPT0gcHJldik7XG4gIHJldHVybiBzcmM7XG59XG5jb25zdCBjc3NWYXJOYW1lRXNjYXBlU3ltYm9sc1JFID0gL1sgIVwiIyQlJicoKSorLC4vOjs8PT4/QFtcXFxcXFxdXmB7fH1+XS9nO1xuZnVuY3Rpb24gZ2V0RXNjYXBlZENzc1Zhck5hbWUoa2V5LCBkb3VibGVFc2NhcGUpIHtcbiAgcmV0dXJuIGtleS5yZXBsYWNlKFxuICAgIGNzc1Zhck5hbWVFc2NhcGVTeW1ib2xzUkUsXG4gICAgKHMpID0+IGRvdWJsZUVzY2FwZSA/IHMgPT09ICdcIicgPyAnXFxcXFxcXFxcXFxcXCInIDogYFxcXFxcXFxcJHtzfWAgOiBgXFxcXCR7c31gXG4gICk7XG59XG5cbmZ1bmN0aW9uIGxvb3NlQ29tcGFyZUFycmF5cyhhLCBiKSB7XG4gIGlmIChhLmxlbmd0aCAhPT0gYi5sZW5ndGgpIHJldHVybiBmYWxzZTtcbiAgbGV0IGVxdWFsID0gdHJ1ZTtcbiAgZm9yIChsZXQgaSA9IDA7IGVxdWFsICYmIGkgPCBhLmxlbmd0aDsgaSsrKSB7XG4gICAgZXF1YWwgPSBsb29zZUVxdWFsKGFbaV0sIGJbaV0pO1xuICB9XG4gIHJldHVybiBlcXVhbDtcbn1cbmZ1bmN0aW9uIGxvb3NlRXF1YWwoYSwgYikge1xuICBpZiAoYSA9PT0gYikgcmV0dXJuIHRydWU7XG4gIGxldCBhVmFsaWRUeXBlID0gaXNEYXRlKGEpO1xuICBsZXQgYlZhbGlkVHlwZSA9IGlzRGF0ZShiKTtcbiAgaWYgKGFWYWxpZFR5cGUgfHwgYlZhbGlkVHlwZSkge1xuICAgIHJldHVybiBhVmFsaWRUeXBlICYmIGJWYWxpZFR5cGUgPyBhLmdldFRpbWUoKSA9PT0gYi5nZXRUaW1lKCkgOiBmYWxzZTtcbiAgfVxuICBhVmFsaWRUeXBlID0gaXNTeW1ib2woYSk7XG4gIGJWYWxpZFR5cGUgPSBpc1N5bWJvbChiKTtcbiAgaWYgKGFWYWxpZFR5cGUgfHwgYlZhbGlkVHlwZSkge1xuICAgIHJldHVybiBhID09PSBiO1xuICB9XG4gIGFWYWxpZFR5cGUgPSBpc0FycmF5KGEpO1xuICBiVmFsaWRUeXBlID0gaXNBcnJheShiKTtcbiAgaWYgKGFWYWxpZFR5cGUgfHwgYlZhbGlkVHlwZSkge1xuICAgIHJldHVybiBhVmFsaWRUeXBlICYmIGJWYWxpZFR5cGUgPyBsb29zZUNvbXBhcmVBcnJheXMoYSwgYikgOiBmYWxzZTtcbiAgfVxuICBhVmFsaWRUeXBlID0gaXNPYmplY3QoYSk7XG4gIGJWYWxpZFR5cGUgPSBpc09iamVjdChiKTtcbiAgaWYgKGFWYWxpZFR5cGUgfHwgYlZhbGlkVHlwZSkge1xuICAgIGlmICghYVZhbGlkVHlwZSB8fCAhYlZhbGlkVHlwZSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBhS2V5c0NvdW50ID0gT2JqZWN0LmtleXMoYSkubGVuZ3RoO1xuICAgIGNvbnN0IGJLZXlzQ291bnQgPSBPYmplY3Qua2V5cyhiKS5sZW5ndGg7XG4gICAgaWYgKGFLZXlzQ291bnQgIT09IGJLZXlzQ291bnQpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBrZXkgaW4gYSkge1xuICAgICAgY29uc3QgYUhhc0tleSA9IGEuaGFzT3duUHJvcGVydHkoa2V5KTtcbiAgICAgIGNvbnN0IGJIYXNLZXkgPSBiLmhhc093blByb3BlcnR5KGtleSk7XG4gICAgICBpZiAoYUhhc0tleSAmJiAhYkhhc0tleSB8fCAhYUhhc0tleSAmJiBiSGFzS2V5IHx8ICFsb29zZUVxdWFsKGFba2V5XSwgYltrZXldKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBTdHJpbmcoYSkgPT09IFN0cmluZyhiKTtcbn1cbmZ1bmN0aW9uIGxvb3NlSW5kZXhPZihhcnIsIHZhbCkge1xuICByZXR1cm4gYXJyLmZpbmRJbmRleCgoaXRlbSkgPT4gbG9vc2VFcXVhbChpdGVtLCB2YWwpKTtcbn1cblxuY29uc3QgaXNSZWYgPSAodmFsKSA9PiB7XG4gIHJldHVybiAhISh2YWwgJiYgdmFsW1wiX192X2lzUmVmXCJdID09PSB0cnVlKTtcbn07XG5jb25zdCB0b0Rpc3BsYXlTdHJpbmcgPSAodmFsKSA9PiB7XG4gIHJldHVybiBpc1N0cmluZyh2YWwpID8gdmFsIDogdmFsID09IG51bGwgPyBcIlwiIDogaXNBcnJheSh2YWwpIHx8IGlzT2JqZWN0KHZhbCkgJiYgKHZhbC50b1N0cmluZyA9PT0gb2JqZWN0VG9TdHJpbmcgfHwgIWlzRnVuY3Rpb24odmFsLnRvU3RyaW5nKSkgPyBpc1JlZih2YWwpID8gdG9EaXNwbGF5U3RyaW5nKHZhbC52YWx1ZSkgOiBKU09OLnN0cmluZ2lmeSh2YWwsIHJlcGxhY2VyLCAyKSA6IFN0cmluZyh2YWwpO1xufTtcbmNvbnN0IHJlcGxhY2VyID0gKF9rZXksIHZhbCkgPT4ge1xuICBpZiAoaXNSZWYodmFsKSkge1xuICAgIHJldHVybiByZXBsYWNlcihfa2V5LCB2YWwudmFsdWUpO1xuICB9IGVsc2UgaWYgKGlzTWFwKHZhbCkpIHtcbiAgICByZXR1cm4ge1xuICAgICAgW2BNYXAoJHt2YWwuc2l6ZX0pYF06IFsuLi52YWwuZW50cmllcygpXS5yZWR1Y2UoXG4gICAgICAgIChlbnRyaWVzLCBba2V5LCB2YWwyXSwgaSkgPT4ge1xuICAgICAgICAgIGVudHJpZXNbc3RyaW5naWZ5U3ltYm9sKGtleSwgaSkgKyBcIiA9PlwiXSA9IHZhbDI7XG4gICAgICAgICAgcmV0dXJuIGVudHJpZXM7XG4gICAgICAgIH0sXG4gICAgICAgIHt9XG4gICAgICApXG4gICAgfTtcbiAgfSBlbHNlIGlmIChpc1NldCh2YWwpKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIFtgU2V0KCR7dmFsLnNpemV9KWBdOiBbLi4udmFsLnZhbHVlcygpXS5tYXAoKHYpID0+IHN0cmluZ2lmeVN5bWJvbCh2KSlcbiAgICB9O1xuICB9IGVsc2UgaWYgKGlzU3ltYm9sKHZhbCkpIHtcbiAgICByZXR1cm4gc3RyaW5naWZ5U3ltYm9sKHZhbCk7XG4gIH0gZWxzZSBpZiAoaXNPYmplY3QodmFsKSAmJiAhaXNBcnJheSh2YWwpICYmICFpc1BsYWluT2JqZWN0KHZhbCkpIHtcbiAgICByZXR1cm4gU3RyaW5nKHZhbCk7XG4gIH1cbiAgcmV0dXJuIHZhbDtcbn07XG5jb25zdCBzdHJpbmdpZnlTeW1ib2wgPSAodiwgaSA9IFwiXCIpID0+IHtcbiAgdmFyIF9hO1xuICByZXR1cm4gKFxuICAgIC8vIFN5bWJvbC5kZXNjcmlwdGlvbiBpbiBlczIwMTkrIHNvIHdlIG5lZWQgdG8gY2FzdCBoZXJlIHRvIHBhc3NcbiAgICAvLyB0aGUgbGliOiBlczIwMTYgY2hlY2tcbiAgICBpc1N5bWJvbCh2KSA/IGBTeW1ib2woJHsoX2EgPSB2LmRlc2NyaXB0aW9uKSAhPSBudWxsID8gX2EgOiBpfSlgIDogdlxuICApO1xufTtcblxuZnVuY3Rpb24gbm9ybWFsaXplQ3NzVmFyVmFsdWUodmFsdWUpIHtcbiAgaWYgKHZhbHVlID09IG51bGwpIHtcbiAgICByZXR1cm4gXCJpbml0aWFsXCI7XG4gIH1cbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIikge1xuICAgIHJldHVybiB2YWx1ZSA9PT0gXCJcIiA/IFwiIFwiIDogdmFsdWU7XG4gIH1cbiAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gXCJudW1iZXJcIiB8fCAhTnVtYmVyLmlzRmluaXRlKHZhbHVlKSkge1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgIFwiW1Z1ZSB3YXJuXSBJbnZhbGlkIHZhbHVlIHVzZWQgZm9yIENTUyBiaW5kaW5nLiBFeHBlY3RlZCBhIHN0cmluZyBvciBhIGZpbml0ZSBudW1iZXIgYnV0IHJlY2VpdmVkOlwiLFxuICAgICAgICB2YWx1ZVxuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIFN0cmluZyh2YWx1ZSk7XG59XG5cbmV4cG9ydCB7IEVNUFRZX0FSUiwgRU1QVFlfT0JKLCBOTywgTk9PUCwgUGF0Y2hGbGFnTmFtZXMsIFBhdGNoRmxhZ3MsIFNoYXBlRmxhZ3MsIFNsb3RGbGFncywgY2FtZWxpemUsIGNhcGl0YWxpemUsIGNzc1Zhck5hbWVFc2NhcGVTeW1ib2xzUkUsIGRlZiwgZXNjYXBlSHRtbCwgZXNjYXBlSHRtbENvbW1lbnQsIGV4dGVuZCwgZ2VuQ2FjaGVLZXksIGdlblByb3BzQWNjZXNzRXhwLCBnZW5lcmF0ZUNvZGVGcmFtZSwgZ2V0RXNjYXBlZENzc1Zhck5hbWUsIGdldEdsb2JhbFRoaXMsIGhhc0NoYW5nZWQsIGhhc093biwgaHlwaGVuYXRlLCBpbmNsdWRlQm9vbGVhbkF0dHIsIGludm9rZUFycmF5Rm5zLCBpc0FycmF5LCBpc0Jvb2xlYW5BdHRyLCBpc0J1aWx0SW5EaXJlY3RpdmUsIGlzRGF0ZSwgaXNGdW5jdGlvbiwgaXNHbG9iYWxseUFsbG93ZWQsIGlzR2xvYmFsbHlXaGl0ZWxpc3RlZCwgaXNIVE1MVGFnLCBpc0ludGVnZXJLZXksIGlzS25vd25IdG1sQXR0ciwgaXNLbm93bk1hdGhNTEF0dHIsIGlzS25vd25TdmdBdHRyLCBpc01hcCwgaXNNYXRoTUxUYWcsIGlzTW9kZWxMaXN0ZW5lciwgaXNPYmplY3QsIGlzT24sIGlzUGxhaW5PYmplY3QsIGlzUHJvbWlzZSwgaXNSZWdFeHAsIGlzUmVuZGVyYWJsZUF0dHJWYWx1ZSwgaXNSZXNlcnZlZFByb3AsIGlzU1NSU2FmZUF0dHJOYW1lLCBpc1NWR1RhZywgaXNTZXQsIGlzU3BlY2lhbEJvb2xlYW5BdHRyLCBpc1N0cmluZywgaXNTeW1ib2wsIGlzVm9pZFRhZywgbG9vc2VFcXVhbCwgbG9vc2VJbmRleE9mLCBsb29zZVRvTnVtYmVyLCBtYWtlTWFwLCBub3JtYWxpemVDbGFzcywgbm9ybWFsaXplQ3NzVmFyVmFsdWUsIG5vcm1hbGl6ZVByb3BzLCBub3JtYWxpemVTdHlsZSwgb2JqZWN0VG9TdHJpbmcsIHBhcnNlU3RyaW5nU3R5bGUsIHByb3BzVG9BdHRyTWFwLCByZW1vdmUsIHNsb3RGbGFnc1RleHQsIHN0cmluZ2lmeVN0eWxlLCB0b0Rpc3BsYXlTdHJpbmcsIHRvSGFuZGxlcktleSwgdG9OdW1iZXIsIHRvUmF3VHlwZSwgdG9UeXBlU3RyaW5nIH07XG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==