export * from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@firebase+auth@1.13.4_@firebase+app@0.16.0/node_modules/@firebase/auth/dist/esm/index.js?v=7e73afc2";
                                     
