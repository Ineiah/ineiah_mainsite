import { h as hasOwn } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/unhead@3.3.1_esbuild@0.28.1_rolldown@1.2.2_rollup@4.62.4_vite@8.2.0_@types+node@26.1.2__626a09bc236bc26ef03db1436f1ed41d/node_modules/unhead/dist/shared/unhead.Bf_fPVYA.mjs?v=7e73afc2";

const TAG_HTML = 0;
const TAG_HEAD = 1;
const TAG_TITLE = 4;
const TAG_META = 5;
const TAG_BODY = 44;
const TAG_SCRIPT = 52;
const TAG_STYLE = 53;
const TAG_LINK = 54;
const TAG_BASE = 56;
const LT_CHAR = 60;
const GT_CHAR = 62;
const SLASH_CHAR = 47;
const EQUALS_CHAR = 61;
const QUOTE_CHAR = 34;
const APOS_CHAR = 39;
const EXCLAMATION_CHAR = 33;
const BACKSLASH_CHAR = 92;
const DASH_CHAR = 45;
const TagIdMap = {
  html: TAG_HTML,
  head: TAG_HEAD,
  title: TAG_TITLE,
  meta: TAG_META,
  body: TAG_BODY,
  script: TAG_SCRIPT,
  style: TAG_STYLE,
  link: TAG_LINK,
  base: TAG_BASE
};
const HEAD_ELEMENTS_TO_EXTRACT = /* @__PURE__ */ new Set([TAG_TITLE, TAG_META, TAG_LINK, TAG_SCRIPT, TAG_STYLE, TAG_BASE]);
function prepareTemplate(html) {
  const template = parseHtmlForIndexes(html);
  Object.freeze(template.input);
  Object.freeze(template.indexes);
  return Object.freeze(template);
}
function isWhitespace(charCode) {
  return charCode === 32 || charCode === 9 || charCode === 10 || charCode === 13;
}
function processCommentOrDoctype(htmlChunk, position) {
  let i = position;
  const chunkLength = htmlChunk.length;
  if (i + 3 < chunkLength && htmlChunk.charCodeAt(i + 2) === DASH_CHAR && htmlChunk.charCodeAt(i + 3) === DASH_CHAR) {
    i += 4;
    while (i < chunkLength - 2) {
      if (htmlChunk.charCodeAt(i) === DASH_CHAR && htmlChunk.charCodeAt(i + 1) === DASH_CHAR && htmlChunk.charCodeAt(i + 2) === GT_CHAR) {
        i += 3;
        return {
          complete: true,
          newPosition: i,
          remainingText: ""
        };
      }
      i++;
    }
    return {
      complete: false,
      newPosition: position,
      remainingText: htmlChunk.substring(position)
    };
  } else {
    i += 2;
    while (i < chunkLength) {
      if (htmlChunk.charCodeAt(i) === GT_CHAR) {
        i++;
        return {
          complete: true,
          newPosition: i,
          remainingText: ""
        };
      }
      i++;
    }
    return {
      complete: false,
      newPosition: i,
      remainingText: htmlChunk.substring(position, i)
    };
  }
}
function parseAttributes(attrStr) {
  if (!attrStr)
    return {};
  const result = {};
  const setAttr = (attrName, value) => {
    if (!hasOwn(result, attrName))
      result[attrName] = value;
  };
  const len = attrStr.length;
  let i = 0;
  const WHITESPACE = 0;
  const NAME = 1;
  const AFTER_NAME = 2;
  const BEFORE_VALUE = 3;
  const QUOTED_VALUE = 4;
  const UNQUOTED_VALUE = 5;
  let state = WHITESPACE;
  let nameStart = 0;
  let nameEnd = 0;
  let valueStart = 0;
  let quoteChar = 0;
  let name = "";
  while (i < len) {
    const charCode = attrStr.charCodeAt(i);
    const isSpace = isWhitespace(charCode);
    switch (state) {
      case WHITESPACE:
        if (!isSpace) {
          state = NAME;
          nameStart = i;
          nameEnd = 0;
        }
        break;
      case NAME:
        if (charCode === EQUALS_CHAR || isSpace) {
          nameEnd = i;
          name = attrStr.substring(nameStart, nameEnd).toLowerCase();
          state = charCode === EQUALS_CHAR ? BEFORE_VALUE : AFTER_NAME;
        }
        break;
      case AFTER_NAME:
        if (charCode === EQUALS_CHAR) {
          state = BEFORE_VALUE;
        } else if (!isSpace) {
          setAttr(name, "");
          state = NAME;
          nameStart = i;
          nameEnd = 0;
        }
        break;
      case BEFORE_VALUE:
        if (charCode === QUOTE_CHAR || charCode === APOS_CHAR) {
          quoteChar = charCode;
          state = QUOTED_VALUE;
          valueStart = i + 1;
        } else if (!isSpace) {
          state = UNQUOTED_VALUE;
          valueStart = i;
        }
        break;
      case QUOTED_VALUE:
        if (charCode === quoteChar) {
          setAttr(name, attrStr.substring(valueStart, i));
          state = WHITESPACE;
        }
        break;
      case UNQUOTED_VALUE:
        if (isSpace || charCode === GT_CHAR) {
          setAttr(name, attrStr.substring(valueStart, i));
          state = WHITESPACE;
        }
        break;
    }
    i++;
  }
  if (state === QUOTED_VALUE || state === UNQUOTED_VALUE) {
    if (name) {
      setAttr(name, attrStr.substring(valueStart, i));
    }
  } else if (state === NAME || state === AFTER_NAME || state === BEFORE_VALUE) {
    nameEnd = nameEnd || i;
    const currentName = attrStr.substring(nameStart, nameEnd).toLowerCase();
    if (currentName) {
      setAttr(currentName, "");
    }
  }
  return result;
}
function parseHtmlForIndexes(html) {
  const indexes = {
    htmlTagStart: html.indexOf("<html"),
    htmlTagEnd: -1,
    headTagEnd: html.indexOf("</head>"),
    bodyTagStart: html.indexOf("<body"),
    bodyTagEnd: -1,
    bodyCloseTagStart: html.indexOf("</body>")
  };
  if (indexes.htmlTagStart >= 0) {
    const htmlTagEndPos = html.indexOf(">", indexes.htmlTagStart);
    if (htmlTagEndPos >= 0) {
      indexes.htmlTagEnd = htmlTagEndPos + 1;
    }
  }
  if (indexes.bodyTagStart >= 0) {
    const bodyTagEndPos = html.indexOf(">", indexes.bodyTagStart);
    if (bodyTagEndPos >= 0) {
      indexes.bodyTagEnd = bodyTagEndPos + 1;
    }
  }
  return { html, input: {}, indexes };
}
function parseHtmlForUnheadExtraction(html) {
  const input = {};
  const htmlParts = [];
  let position = 0;
  let inHead = false;
  let foundBodyStart = false;
  let lastCopyPosition = 0;
  let currentOutputLength = 0;
  const indexes = {
    htmlTagStart: -1,
    htmlTagEnd: -1,
    headTagEnd: -1,
    bodyTagStart: -1,
    bodyTagEnd: -1,
    bodyCloseTagStart: -1
  };
  function copyAccumulatedText() {
    if (lastCopyPosition < position) {
      const textToAdd = html.substring(lastCopyPosition, position);
      htmlParts.push(textToAdd);
      currentOutputLength += textToAdd.length;
      lastCopyPosition = position;
    }
  }
  function addText(text) {
    htmlParts.push(text);
    currentOutputLength += text.length;
  }
  while (position < html.length && !foundBodyStart) {
    const currentCharCode = html.charCodeAt(position);
    if (currentCharCode !== LT_CHAR) {
      position++;
      continue;
    }
    if (position + 1 >= html.length) {
      copyAccumulatedText();
      addText(html[position]);
      break;
    }
    const nextCharCode = html.charCodeAt(position + 1);
    if (nextCharCode === EXCLAMATION_CHAR) {
      const result = processCommentOrDoctype(html, position);
      if (result.complete) {
        copyAccumulatedText();
        addText(html.substring(position, result.newPosition));
        position = result.newPosition;
        lastCopyPosition = position;
      } else {
        copyAccumulatedText();
        addText(html.substring(position));
        break;
      }
      continue;
    }
    if (nextCharCode === SLASH_CHAR) {
      let tagEnd2 = position + 2;
      while (tagEnd2 < html.length && html.charCodeAt(tagEnd2) !== GT_CHAR) {
        tagEnd2++;
      }
      if (tagEnd2 >= html.length) {
        copyAccumulatedText();
        addText(html.substring(position));
        break;
      }
      const tagName2 = html.substring(position + 2, tagEnd2).toLowerCase().trim();
      const tagId2 = TagIdMap[tagName2] ?? -1;
      if (tagId2 === TAG_HEAD) {
        inHead = false;
        copyAccumulatedText();
        const headCloseStart = currentOutputLength;
        addText(html.substring(position, tagEnd2 + 1));
        indexes.headTagEnd = headCloseStart;
      } else {
        copyAccumulatedText();
        addText(html.substring(position, tagEnd2 + 1));
      }
      position = tagEnd2 + 1;
      lastCopyPosition = position;
      continue;
    }
    const tagStart = position + 1;
    let tagNameEnd = tagStart;
    while (tagNameEnd < html.length) {
      const c = html.charCodeAt(tagNameEnd);
      if (isWhitespace(c) || c === SLASH_CHAR || c === GT_CHAR) {
        break;
      }
      tagNameEnd++;
    }
    if (tagNameEnd >= html.length) {
      copyAccumulatedText();
      addText(html.substring(position));
      break;
    }
    const tagName = html.substring(tagStart, tagNameEnd).toLowerCase();
    const tagId = TagIdMap[tagName] ?? -1;
    let tagEnd = tagNameEnd;
    let inQuote = false;
    let quoteChar = 0;
    let foundEnd = false;
    let isSelfClosing = false;
    while (tagEnd < html.length && !foundEnd) {
      const c = html.charCodeAt(tagEnd);
      if (inQuote) {
        if (c === quoteChar) {
          inQuote = false;
        }
      } else if (c === QUOTE_CHAR || c === APOS_CHAR) {
        inQuote = true;
        quoteChar = c;
      } else if (c === SLASH_CHAR && tagEnd + 1 < html.length && html.charCodeAt(tagEnd + 1) === GT_CHAR) {
        isSelfClosing = true;
        tagEnd += 2;
        foundEnd = true;
        continue;
      } else if (c === GT_CHAR) {
        tagEnd++;
        foundEnd = true;
        continue;
      }
      tagEnd++;
    }
    if (!foundEnd) {
      copyAccumulatedText();
      addText(html.substring(position));
      break;
    }
    const attributesStr = html.substring(tagNameEnd, tagEnd - (isSelfClosing ? 2 : 1)).trim();
    const attributes = parseAttributes(attributesStr);
    if (tagId === TAG_HTML) {
      copyAccumulatedText();
      indexes.htmlTagStart = currentOutputLength;
      if (Object.keys(attributes).length > 0) {
        input.htmlAttrs = attributes;
        addText(`<${tagName}>`);
      } else {
        addText(html.substring(position, tagEnd));
      }
      indexes.htmlTagEnd = currentOutputLength;
    } else if (tagId === TAG_BODY) {
      copyAccumulatedText();
      indexes.bodyTagStart = currentOutputLength;
      if (Object.keys(attributes).length > 0) {
        input.bodyAttrs = attributes;
        addText(`<${tagName}>`);
      } else {
        addText(html.substring(position, tagEnd));
      }
      indexes.bodyTagEnd = currentOutputLength;
      foundBodyStart = true;
      position = tagEnd;
      lastCopyPosition = position;
      break;
    } else if (tagId === TAG_HEAD) {
      inHead = true;
      copyAccumulatedText();
      addText(html.substring(position, tagEnd));
    } else if (inHead && HEAD_ELEMENTS_TO_EXTRACT.has(tagId)) {
      if (tagId === TAG_TITLE) {
        if (!isSelfClosing) {
          const titleEnd = findClosingTag(html, tagEnd, tagName);
          if (titleEnd !== -1) {
            const titleContent = html.substring(tagEnd, titleEnd).trim();
            if (titleContent && !input.title) {
              input.title = titleContent;
            }
            position = findTagEnd(html, titleEnd, tagName);
            lastCopyPosition = position;
            continue;
          }
        }
      } else if (tagId === TAG_SCRIPT) {
        const scriptAttrs = { ...attributes };
        if (!isSelfClosing) {
          const scriptEnd = findClosingTag(html, tagEnd, tagName);
          if (scriptEnd !== -1) {
            const scriptContent = html.substring(tagEnd, scriptEnd);
            scriptAttrs.innerHTML = scriptContent || "";
            position = findTagEnd(html, scriptEnd, tagName);
          } else {
            scriptAttrs.innerHTML = "";
            position = tagEnd;
          }
        } else {
          scriptAttrs.innerHTML = "";
          position = tagEnd;
        }
        lastCopyPosition = position;
        (input.script ||= []).push(scriptAttrs);
        continue;
      } else if (tagId === TAG_STYLE) {
        const styleAttrs = { ...attributes };
        if (!isSelfClosing) {
          const styleEnd = findClosingTag(html, tagEnd, tagName);
          if (styleEnd !== -1) {
            const styleContent = html.substring(tagEnd, styleEnd);
            styleAttrs.textContent = styleContent || "";
            position = findTagEnd(html, styleEnd, tagName);
          } else {
            styleAttrs.textContent = "";
            position = tagEnd;
          }
        } else {
          styleAttrs.textContent = "";
          position = tagEnd;
        }
        lastCopyPosition = position;
        (input.style ||= []).push(styleAttrs);
        continue;
      } else if (tagId === TAG_META) {
        (input.meta ||= []).push(attributes);
        position = tagEnd;
        lastCopyPosition = position;
        continue;
      } else if (tagId === TAG_LINK) {
        (input.link ||= []).push(attributes);
        position = tagEnd;
        lastCopyPosition = position;
        continue;
      } else if (tagId === TAG_BASE && !input.base) {
        input.base = attributes;
        position = tagEnd;
        lastCopyPosition = position;
        continue;
      }
    } else {
      copyAccumulatedText();
      addText(html.substring(position, tagEnd));
    }
    position = tagEnd;
    lastCopyPosition = position;
  }
  const remainingHtml = html.substring(position);
  const bodyCloseIndex = remainingHtml.indexOf("</body>");
  if (bodyCloseIndex !== -1) {
    indexes.bodyCloseTagStart = currentOutputLength + bodyCloseIndex;
  }
  copyAccumulatedText();
  addText(remainingHtml);
  return { html: htmlParts.join(""), input, indexes };
}
function findClosingTag(html, startPos, tagName) {
  const tagId = TagIdMap[tagName];
  const isScriptOrStyle = tagId === TAG_SCRIPT || tagId === TAG_STYLE;
  if (!isScriptOrStyle) {
    const closingTag2 = `</${tagName}`;
    const index = html.indexOf(closingTag2, startPos);
    return index === -1 ? -1 : index;
  }
  const closingTag = `</${tagName}`;
  let pos = startPos;
  let inSingleQuote = false;
  let inDoubleQuote = false;
  let inBacktick = false;
  let lastCharWasBackslash = false;
  while (pos < html.length) {
    const currentCharCode = html.charCodeAt(pos);
    if (!lastCharWasBackslash) {
      if (currentCharCode === APOS_CHAR && !inDoubleQuote && !inBacktick) {
        inSingleQuote = !inSingleQuote;
      } else if (currentCharCode === QUOTE_CHAR && !inSingleQuote && !inBacktick) {
        inDoubleQuote = !inDoubleQuote;
      } else if (currentCharCode === 96 && !inSingleQuote && !inDoubleQuote) {
        inBacktick = !inBacktick;
      }
    }
    lastCharWasBackslash = currentCharCode === BACKSLASH_CHAR && !lastCharWasBackslash;
    const inQuotes = inSingleQuote || inDoubleQuote || inBacktick;
    if (!inQuotes && html.startsWith(closingTag, pos)) {
      const afterTagPos = pos + closingTag.length;
      if (afterTagPos >= html.length) {
        return pos;
      }
      const nextChar = html.charCodeAt(afterTagPos);
      if (nextChar === GT_CHAR || isWhitespace(nextChar)) {
        return pos;
      }
    }
    pos++;
  }
  return -1;
}
function findTagEnd(html, closingTagStart, tagName) {
  let pos = closingTagStart + tagName.length + 2;
  while (pos < html.length && html.charCodeAt(pos) !== GT_CHAR) {
    pos++;
  }
  return pos < html.length ? pos + 1 : pos;
}
function applyHeadToHtml(template, headHtml) {
  const { html, indexes } = template;
  const parts = [];
  let lastIndex = 0;
  if (indexes.htmlTagStart >= 0) {
    parts.push(html.substring(lastIndex, indexes.htmlTagStart));
    parts.push(`<html${headHtml.htmlAttrs}>`);
    lastIndex = indexes.htmlTagEnd;
  }
  if (indexes.headTagEnd >= 0) {
    parts.push(html.substring(lastIndex, indexes.headTagEnd));
    parts.push(headHtml.headTags);
    parts.push("</head>");
    lastIndex = indexes.headTagEnd + 7;
  }
  if (indexes.bodyTagStart >= 0) {
    parts.push(html.substring(lastIndex, indexes.bodyTagStart));
    if (headHtml.bodyTagsOpen) {
      parts.push(`<body${headHtml.bodyAttrs}>
${headHtml.bodyTagsOpen}`);
    } else {
      parts.push(`<body${headHtml.bodyAttrs}>`);
    }
    lastIndex = indexes.bodyTagEnd;
  }
  if (indexes.bodyCloseTagStart >= 0) {
    parts.push(html.substring(lastIndex, indexes.bodyCloseTagStart));
    parts.push(headHtml.bodyTags);
    parts.push(html.substring(indexes.bodyCloseTagStart));
  } else {
    parts.push(html.substring(lastIndex));
  }
  return parts.join("");
}

export { TagIdMap, applyHeadToHtml, parseAttributes, parseHtmlForIndexes, parseHtmlForUnheadExtraction, prepareTemplate };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBhcnNlci5tanM/dj03ZTczYWZjMiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBoIGFzIGhhc093biB9IGZyb20gXCIvX251eHQvQGZzL1ZvbHVtZXMvQ29kaW5nL1Byb2plY3RzL1dlYnNpdGVzL2luZWlhaC9mcm9udGVuZC9ub2RlX21vZHVsZXMvLnBucG0vdW5oZWFkQDMuMy4xX2VzYnVpbGRAMC4yOC4xX3JvbGxkb3duQDEuMi4yX3JvbGx1cEA0LjYyLjRfdml0ZUA4LjIuMF9AdHlwZXMrbm9kZUAyNi4xLjJfXzYyNmEwOWJjMjM2YmMyNmVmMDNkYjE0MzZmMWVkNDFkL25vZGVfbW9kdWxlcy91bmhlYWQvZGlzdC9zaGFyZWQvdW5oZWFkLkJmX2ZQVllBLm1qcz92PTdlNzNhZmMyXCI7XG5cbmNvbnN0IFRBR19IVE1MID0gMDtcbmNvbnN0IFRBR19IRUFEID0gMTtcbmNvbnN0IFRBR19USVRMRSA9IDQ7XG5jb25zdCBUQUdfTUVUQSA9IDU7XG5jb25zdCBUQUdfQk9EWSA9IDQ0O1xuY29uc3QgVEFHX1NDUklQVCA9IDUyO1xuY29uc3QgVEFHX1NUWUxFID0gNTM7XG5jb25zdCBUQUdfTElOSyA9IDU0O1xuY29uc3QgVEFHX0JBU0UgPSA1NjtcbmNvbnN0IExUX0NIQVIgPSA2MDtcbmNvbnN0IEdUX0NIQVIgPSA2MjtcbmNvbnN0IFNMQVNIX0NIQVIgPSA0NztcbmNvbnN0IEVRVUFMU19DSEFSID0gNjE7XG5jb25zdCBRVU9URV9DSEFSID0gMzQ7XG5jb25zdCBBUE9TX0NIQVIgPSAzOTtcbmNvbnN0IEVYQ0xBTUFUSU9OX0NIQVIgPSAzMztcbmNvbnN0IEJBQ0tTTEFTSF9DSEFSID0gOTI7XG5jb25zdCBEQVNIX0NIQVIgPSA0NTtcbmNvbnN0IFRhZ0lkTWFwID0ge1xuICBodG1sOiBUQUdfSFRNTCxcbiAgaGVhZDogVEFHX0hFQUQsXG4gIHRpdGxlOiBUQUdfVElUTEUsXG4gIG1ldGE6IFRBR19NRVRBLFxuICBib2R5OiBUQUdfQk9EWSxcbiAgc2NyaXB0OiBUQUdfU0NSSVBULFxuICBzdHlsZTogVEFHX1NUWUxFLFxuICBsaW5rOiBUQUdfTElOSyxcbiAgYmFzZTogVEFHX0JBU0Vcbn07XG5jb25zdCBIRUFEX0VMRU1FTlRTX1RPX0VYVFJBQ1QgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldChbVEFHX1RJVExFLCBUQUdfTUVUQSwgVEFHX0xJTkssIFRBR19TQ1JJUFQsIFRBR19TVFlMRSwgVEFHX0JBU0VdKTtcbmZ1bmN0aW9uIHByZXBhcmVUZW1wbGF0ZShodG1sKSB7XG4gIGNvbnN0IHRlbXBsYXRlID0gcGFyc2VIdG1sRm9ySW5kZXhlcyhodG1sKTtcbiAgT2JqZWN0LmZyZWV6ZSh0ZW1wbGF0ZS5pbnB1dCk7XG4gIE9iamVjdC5mcmVlemUodGVtcGxhdGUuaW5kZXhlcyk7XG4gIHJldHVybiBPYmplY3QuZnJlZXplKHRlbXBsYXRlKTtcbn1cbmZ1bmN0aW9uIGlzV2hpdGVzcGFjZShjaGFyQ29kZSkge1xuICByZXR1cm4gY2hhckNvZGUgPT09IDMyIHx8IGNoYXJDb2RlID09PSA5IHx8IGNoYXJDb2RlID09PSAxMCB8fCBjaGFyQ29kZSA9PT0gMTM7XG59XG5mdW5jdGlvbiBwcm9jZXNzQ29tbWVudE9yRG9jdHlwZShodG1sQ2h1bmssIHBvc2l0aW9uKSB7XG4gIGxldCBpID0gcG9zaXRpb247XG4gIGNvbnN0IGNodW5rTGVuZ3RoID0gaHRtbENodW5rLmxlbmd0aDtcbiAgaWYgKGkgKyAzIDwgY2h1bmtMZW5ndGggJiYgaHRtbENodW5rLmNoYXJDb2RlQXQoaSArIDIpID09PSBEQVNIX0NIQVIgJiYgaHRtbENodW5rLmNoYXJDb2RlQXQoaSArIDMpID09PSBEQVNIX0NIQVIpIHtcbiAgICBpICs9IDQ7XG4gICAgd2hpbGUgKGkgPCBjaHVua0xlbmd0aCAtIDIpIHtcbiAgICAgIGlmIChodG1sQ2h1bmsuY2hhckNvZGVBdChpKSA9PT0gREFTSF9DSEFSICYmIGh0bWxDaHVuay5jaGFyQ29kZUF0KGkgKyAxKSA9PT0gREFTSF9DSEFSICYmIGh0bWxDaHVuay5jaGFyQ29kZUF0KGkgKyAyKSA9PT0gR1RfQ0hBUikge1xuICAgICAgICBpICs9IDM7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgY29tcGxldGU6IHRydWUsXG4gICAgICAgICAgbmV3UG9zaXRpb246IGksXG4gICAgICAgICAgcmVtYWluaW5nVGV4dDogXCJcIlxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgaSsrO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgY29tcGxldGU6IGZhbHNlLFxuICAgICAgbmV3UG9zaXRpb246IHBvc2l0aW9uLFxuICAgICAgcmVtYWluaW5nVGV4dDogaHRtbENodW5rLnN1YnN0cmluZyhwb3NpdGlvbilcbiAgICB9O1xuICB9IGVsc2Uge1xuICAgIGkgKz0gMjtcbiAgICB3aGlsZSAoaSA8IGNodW5rTGVuZ3RoKSB7XG4gICAgICBpZiAoaHRtbENodW5rLmNoYXJDb2RlQXQoaSkgPT09IEdUX0NIQVIpIHtcbiAgICAgICAgaSsrO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGNvbXBsZXRlOiB0cnVlLFxuICAgICAgICAgIG5ld1Bvc2l0aW9uOiBpLFxuICAgICAgICAgIHJlbWFpbmluZ1RleHQ6IFwiXCJcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGkrKztcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIGNvbXBsZXRlOiBmYWxzZSxcbiAgICAgIG5ld1Bvc2l0aW9uOiBpLFxuICAgICAgcmVtYWluaW5nVGV4dDogaHRtbENodW5rLnN1YnN0cmluZyhwb3NpdGlvbiwgaSlcbiAgICB9O1xuICB9XG59XG5mdW5jdGlvbiBwYXJzZUF0dHJpYnV0ZXMoYXR0clN0cikge1xuICBpZiAoIWF0dHJTdHIpXG4gICAgcmV0dXJuIHt9O1xuICBjb25zdCByZXN1bHQgPSB7fTtcbiAgY29uc3Qgc2V0QXR0ciA9IChhdHRyTmFtZSwgdmFsdWUpID0+IHtcbiAgICBpZiAoIWhhc093bihyZXN1bHQsIGF0dHJOYW1lKSlcbiAgICAgIHJlc3VsdFthdHRyTmFtZV0gPSB2YWx1ZTtcbiAgfTtcbiAgY29uc3QgbGVuID0gYXR0clN0ci5sZW5ndGg7XG4gIGxldCBpID0gMDtcbiAgY29uc3QgV0hJVEVTUEFDRSA9IDA7XG4gIGNvbnN0IE5BTUUgPSAxO1xuICBjb25zdCBBRlRFUl9OQU1FID0gMjtcbiAgY29uc3QgQkVGT1JFX1ZBTFVFID0gMztcbiAgY29uc3QgUVVPVEVEX1ZBTFVFID0gNDtcbiAgY29uc3QgVU5RVU9URURfVkFMVUUgPSA1O1xuICBsZXQgc3RhdGUgPSBXSElURVNQQUNFO1xuICBsZXQgbmFtZVN0YXJ0ID0gMDtcbiAgbGV0IG5hbWVFbmQgPSAwO1xuICBsZXQgdmFsdWVTdGFydCA9IDA7XG4gIGxldCBxdW90ZUNoYXIgPSAwO1xuICBsZXQgbmFtZSA9IFwiXCI7XG4gIHdoaWxlIChpIDwgbGVuKSB7XG4gICAgY29uc3QgY2hhckNvZGUgPSBhdHRyU3RyLmNoYXJDb2RlQXQoaSk7XG4gICAgY29uc3QgaXNTcGFjZSA9IGlzV2hpdGVzcGFjZShjaGFyQ29kZSk7XG4gICAgc3dpdGNoIChzdGF0ZSkge1xuICAgICAgY2FzZSBXSElURVNQQUNFOlxuICAgICAgICBpZiAoIWlzU3BhY2UpIHtcbiAgICAgICAgICBzdGF0ZSA9IE5BTUU7XG4gICAgICAgICAgbmFtZVN0YXJ0ID0gaTtcbiAgICAgICAgICBuYW1lRW5kID0gMDtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgTkFNRTpcbiAgICAgICAgaWYgKGNoYXJDb2RlID09PSBFUVVBTFNfQ0hBUiB8fCBpc1NwYWNlKSB7XG4gICAgICAgICAgbmFtZUVuZCA9IGk7XG4gICAgICAgICAgbmFtZSA9IGF0dHJTdHIuc3Vic3RyaW5nKG5hbWVTdGFydCwgbmFtZUVuZCkudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgICBzdGF0ZSA9IGNoYXJDb2RlID09PSBFUVVBTFNfQ0hBUiA/IEJFRk9SRV9WQUxVRSA6IEFGVEVSX05BTUU7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIEFGVEVSX05BTUU6XG4gICAgICAgIGlmIChjaGFyQ29kZSA9PT0gRVFVQUxTX0NIQVIpIHtcbiAgICAgICAgICBzdGF0ZSA9IEJFRk9SRV9WQUxVRTtcbiAgICAgICAgfSBlbHNlIGlmICghaXNTcGFjZSkge1xuICAgICAgICAgIHNldEF0dHIobmFtZSwgXCJcIik7XG4gICAgICAgICAgc3RhdGUgPSBOQU1FO1xuICAgICAgICAgIG5hbWVTdGFydCA9IGk7XG4gICAgICAgICAgbmFtZUVuZCA9IDA7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIEJFRk9SRV9WQUxVRTpcbiAgICAgICAgaWYgKGNoYXJDb2RlID09PSBRVU9URV9DSEFSIHx8IGNoYXJDb2RlID09PSBBUE9TX0NIQVIpIHtcbiAgICAgICAgICBxdW90ZUNoYXIgPSBjaGFyQ29kZTtcbiAgICAgICAgICBzdGF0ZSA9IFFVT1RFRF9WQUxVRTtcbiAgICAgICAgICB2YWx1ZVN0YXJ0ID0gaSArIDE7XG4gICAgICAgIH0gZWxzZSBpZiAoIWlzU3BhY2UpIHtcbiAgICAgICAgICBzdGF0ZSA9IFVOUVVPVEVEX1ZBTFVFO1xuICAgICAgICAgIHZhbHVlU3RhcnQgPSBpO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBRVU9URURfVkFMVUU6XG4gICAgICAgIGlmIChjaGFyQ29kZSA9PT0gcXVvdGVDaGFyKSB7XG4gICAgICAgICAgc2V0QXR0cihuYW1lLCBhdHRyU3RyLnN1YnN0cmluZyh2YWx1ZVN0YXJ0LCBpKSk7XG4gICAgICAgICAgc3RhdGUgPSBXSElURVNQQUNFO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBVTlFVT1RFRF9WQUxVRTpcbiAgICAgICAgaWYgKGlzU3BhY2UgfHwgY2hhckNvZGUgPT09IEdUX0NIQVIpIHtcbiAgICAgICAgICBzZXRBdHRyKG5hbWUsIGF0dHJTdHIuc3Vic3RyaW5nKHZhbHVlU3RhcnQsIGkpKTtcbiAgICAgICAgICBzdGF0ZSA9IFdISVRFU1BBQ0U7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGkrKztcbiAgfVxuICBpZiAoc3RhdGUgPT09IFFVT1RFRF9WQUxVRSB8fCBzdGF0ZSA9PT0gVU5RVU9URURfVkFMVUUpIHtcbiAgICBpZiAobmFtZSkge1xuICAgICAgc2V0QXR0cihuYW1lLCBhdHRyU3RyLnN1YnN0cmluZyh2YWx1ZVN0YXJ0LCBpKSk7XG4gICAgfVxuICB9IGVsc2UgaWYgKHN0YXRlID09PSBOQU1FIHx8IHN0YXRlID09PSBBRlRFUl9OQU1FIHx8IHN0YXRlID09PSBCRUZPUkVfVkFMVUUpIHtcbiAgICBuYW1lRW5kID0gbmFtZUVuZCB8fCBpO1xuICAgIGNvbnN0IGN1cnJlbnROYW1lID0gYXR0clN0ci5zdWJzdHJpbmcobmFtZVN0YXJ0LCBuYW1lRW5kKS50b0xvd2VyQ2FzZSgpO1xuICAgIGlmIChjdXJyZW50TmFtZSkge1xuICAgICAgc2V0QXR0cihjdXJyZW50TmFtZSwgXCJcIik7XG4gICAgfVxuICB9XG4gIHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBwYXJzZUh0bWxGb3JJbmRleGVzKGh0bWwpIHtcbiAgY29uc3QgaW5kZXhlcyA9IHtcbiAgICBodG1sVGFnU3RhcnQ6IGh0bWwuaW5kZXhPZihcIjxodG1sXCIpLFxuICAgIGh0bWxUYWdFbmQ6IC0xLFxuICAgIGhlYWRUYWdFbmQ6IGh0bWwuaW5kZXhPZihcIjwvaGVhZD5cIiksXG4gICAgYm9keVRhZ1N0YXJ0OiBodG1sLmluZGV4T2YoXCI8Ym9keVwiKSxcbiAgICBib2R5VGFnRW5kOiAtMSxcbiAgICBib2R5Q2xvc2VUYWdTdGFydDogaHRtbC5pbmRleE9mKFwiPC9ib2R5PlwiKVxuICB9O1xuICBpZiAoaW5kZXhlcy5odG1sVGFnU3RhcnQgPj0gMCkge1xuICAgIGNvbnN0IGh0bWxUYWdFbmRQb3MgPSBodG1sLmluZGV4T2YoXCI+XCIsIGluZGV4ZXMuaHRtbFRhZ1N0YXJ0KTtcbiAgICBpZiAoaHRtbFRhZ0VuZFBvcyA+PSAwKSB7XG4gICAgICBpbmRleGVzLmh0bWxUYWdFbmQgPSBodG1sVGFnRW5kUG9zICsgMTtcbiAgICB9XG4gIH1cbiAgaWYgKGluZGV4ZXMuYm9keVRhZ1N0YXJ0ID49IDApIHtcbiAgICBjb25zdCBib2R5VGFnRW5kUG9zID0gaHRtbC5pbmRleE9mKFwiPlwiLCBpbmRleGVzLmJvZHlUYWdTdGFydCk7XG4gICAgaWYgKGJvZHlUYWdFbmRQb3MgPj0gMCkge1xuICAgICAgaW5kZXhlcy5ib2R5VGFnRW5kID0gYm9keVRhZ0VuZFBvcyArIDE7XG4gICAgfVxuICB9XG4gIHJldHVybiB7IGh0bWwsIGlucHV0OiB7fSwgaW5kZXhlcyB9O1xufVxuZnVuY3Rpb24gcGFyc2VIdG1sRm9yVW5oZWFkRXh0cmFjdGlvbihodG1sKSB7XG4gIGNvbnN0IGlucHV0ID0ge307XG4gIGNvbnN0IGh0bWxQYXJ0cyA9IFtdO1xuICBsZXQgcG9zaXRpb24gPSAwO1xuICBsZXQgaW5IZWFkID0gZmFsc2U7XG4gIGxldCBmb3VuZEJvZHlTdGFydCA9IGZhbHNlO1xuICBsZXQgbGFzdENvcHlQb3NpdGlvbiA9IDA7XG4gIGxldCBjdXJyZW50T3V0cHV0TGVuZ3RoID0gMDtcbiAgY29uc3QgaW5kZXhlcyA9IHtcbiAgICBodG1sVGFnU3RhcnQ6IC0xLFxuICAgIGh0bWxUYWdFbmQ6IC0xLFxuICAgIGhlYWRUYWdFbmQ6IC0xLFxuICAgIGJvZHlUYWdTdGFydDogLTEsXG4gICAgYm9keVRhZ0VuZDogLTEsXG4gICAgYm9keUNsb3NlVGFnU3RhcnQ6IC0xXG4gIH07XG4gIGZ1bmN0aW9uIGNvcHlBY2N1bXVsYXRlZFRleHQoKSB7XG4gICAgaWYgKGxhc3RDb3B5UG9zaXRpb24gPCBwb3NpdGlvbikge1xuICAgICAgY29uc3QgdGV4dFRvQWRkID0gaHRtbC5zdWJzdHJpbmcobGFzdENvcHlQb3NpdGlvbiwgcG9zaXRpb24pO1xuICAgICAgaHRtbFBhcnRzLnB1c2godGV4dFRvQWRkKTtcbiAgICAgIGN1cnJlbnRPdXRwdXRMZW5ndGggKz0gdGV4dFRvQWRkLmxlbmd0aDtcbiAgICAgIGxhc3RDb3B5UG9zaXRpb24gPSBwb3NpdGlvbjtcbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gYWRkVGV4dCh0ZXh0KSB7XG4gICAgaHRtbFBhcnRzLnB1c2godGV4dCk7XG4gICAgY3VycmVudE91dHB1dExlbmd0aCArPSB0ZXh0Lmxlbmd0aDtcbiAgfVxuICB3aGlsZSAocG9zaXRpb24gPCBodG1sLmxlbmd0aCAmJiAhZm91bmRCb2R5U3RhcnQpIHtcbiAgICBjb25zdCBjdXJyZW50Q2hhckNvZGUgPSBodG1sLmNoYXJDb2RlQXQocG9zaXRpb24pO1xuICAgIGlmIChjdXJyZW50Q2hhckNvZGUgIT09IExUX0NIQVIpIHtcbiAgICAgIHBvc2l0aW9uKys7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKHBvc2l0aW9uICsgMSA+PSBodG1sLmxlbmd0aCkge1xuICAgICAgY29weUFjY3VtdWxhdGVkVGV4dCgpO1xuICAgICAgYWRkVGV4dChodG1sW3Bvc2l0aW9uXSk7XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgY29uc3QgbmV4dENoYXJDb2RlID0gaHRtbC5jaGFyQ29kZUF0KHBvc2l0aW9uICsgMSk7XG4gICAgaWYgKG5leHRDaGFyQ29kZSA9PT0gRVhDTEFNQVRJT05fQ0hBUikge1xuICAgICAgY29uc3QgcmVzdWx0ID0gcHJvY2Vzc0NvbW1lbnRPckRvY3R5cGUoaHRtbCwgcG9zaXRpb24pO1xuICAgICAgaWYgKHJlc3VsdC5jb21wbGV0ZSkge1xuICAgICAgICBjb3B5QWNjdW11bGF0ZWRUZXh0KCk7XG4gICAgICAgIGFkZFRleHQoaHRtbC5zdWJzdHJpbmcocG9zaXRpb24sIHJlc3VsdC5uZXdQb3NpdGlvbikpO1xuICAgICAgICBwb3NpdGlvbiA9IHJlc3VsdC5uZXdQb3NpdGlvbjtcbiAgICAgICAgbGFzdENvcHlQb3NpdGlvbiA9IHBvc2l0aW9uO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29weUFjY3VtdWxhdGVkVGV4dCgpO1xuICAgICAgICBhZGRUZXh0KGh0bWwuc3Vic3RyaW5nKHBvc2l0aW9uKSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY29udGludWU7XG4gICAgfVxuICAgIGlmIChuZXh0Q2hhckNvZGUgPT09IFNMQVNIX0NIQVIpIHtcbiAgICAgIGxldCB0YWdFbmQyID0gcG9zaXRpb24gKyAyO1xuICAgICAgd2hpbGUgKHRhZ0VuZDIgPCBodG1sLmxlbmd0aCAmJiBodG1sLmNoYXJDb2RlQXQodGFnRW5kMikgIT09IEdUX0NIQVIpIHtcbiAgICAgICAgdGFnRW5kMisrO1xuICAgICAgfVxuICAgICAgaWYgKHRhZ0VuZDIgPj0gaHRtbC5sZW5ndGgpIHtcbiAgICAgICAgY29weUFjY3VtdWxhdGVkVGV4dCgpO1xuICAgICAgICBhZGRUZXh0KGh0bWwuc3Vic3RyaW5nKHBvc2l0aW9uKSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY29uc3QgdGFnTmFtZTIgPSBodG1sLnN1YnN0cmluZyhwb3NpdGlvbiArIDIsIHRhZ0VuZDIpLnRvTG93ZXJDYXNlKCkudHJpbSgpO1xuICAgICAgY29uc3QgdGFnSWQyID0gVGFnSWRNYXBbdGFnTmFtZTJdID8/IC0xO1xuICAgICAgaWYgKHRhZ0lkMiA9PT0gVEFHX0hFQUQpIHtcbiAgICAgICAgaW5IZWFkID0gZmFsc2U7XG4gICAgICAgIGNvcHlBY2N1bXVsYXRlZFRleHQoKTtcbiAgICAgICAgY29uc3QgaGVhZENsb3NlU3RhcnQgPSBjdXJyZW50T3V0cHV0TGVuZ3RoO1xuICAgICAgICBhZGRUZXh0KGh0bWwuc3Vic3RyaW5nKHBvc2l0aW9uLCB0YWdFbmQyICsgMSkpO1xuICAgICAgICBpbmRleGVzLmhlYWRUYWdFbmQgPSBoZWFkQ2xvc2VTdGFydDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvcHlBY2N1bXVsYXRlZFRleHQoKTtcbiAgICAgICAgYWRkVGV4dChodG1sLnN1YnN0cmluZyhwb3NpdGlvbiwgdGFnRW5kMiArIDEpKTtcbiAgICAgIH1cbiAgICAgIHBvc2l0aW9uID0gdGFnRW5kMiArIDE7XG4gICAgICBsYXN0Q29weVBvc2l0aW9uID0gcG9zaXRpb247XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgY29uc3QgdGFnU3RhcnQgPSBwb3NpdGlvbiArIDE7XG4gICAgbGV0IHRhZ05hbWVFbmQgPSB0YWdTdGFydDtcbiAgICB3aGlsZSAodGFnTmFtZUVuZCA8IGh0bWwubGVuZ3RoKSB7XG4gICAgICBjb25zdCBjID0gaHRtbC5jaGFyQ29kZUF0KHRhZ05hbWVFbmQpO1xuICAgICAgaWYgKGlzV2hpdGVzcGFjZShjKSB8fCBjID09PSBTTEFTSF9DSEFSIHx8IGMgPT09IEdUX0NIQVIpIHtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICB0YWdOYW1lRW5kKys7XG4gICAgfVxuICAgIGlmICh0YWdOYW1lRW5kID49IGh0bWwubGVuZ3RoKSB7XG4gICAgICBjb3B5QWNjdW11bGF0ZWRUZXh0KCk7XG4gICAgICBhZGRUZXh0KGh0bWwuc3Vic3RyaW5nKHBvc2l0aW9uKSk7XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgY29uc3QgdGFnTmFtZSA9IGh0bWwuc3Vic3RyaW5nKHRhZ1N0YXJ0LCB0YWdOYW1lRW5kKS50b0xvd2VyQ2FzZSgpO1xuICAgIGNvbnN0IHRhZ0lkID0gVGFnSWRNYXBbdGFnTmFtZV0gPz8gLTE7XG4gICAgbGV0IHRhZ0VuZCA9IHRhZ05hbWVFbmQ7XG4gICAgbGV0IGluUXVvdGUgPSBmYWxzZTtcbiAgICBsZXQgcXVvdGVDaGFyID0gMDtcbiAgICBsZXQgZm91bmRFbmQgPSBmYWxzZTtcbiAgICBsZXQgaXNTZWxmQ2xvc2luZyA9IGZhbHNlO1xuICAgIHdoaWxlICh0YWdFbmQgPCBodG1sLmxlbmd0aCAmJiAhZm91bmRFbmQpIHtcbiAgICAgIGNvbnN0IGMgPSBodG1sLmNoYXJDb2RlQXQodGFnRW5kKTtcbiAgICAgIGlmIChpblF1b3RlKSB7XG4gICAgICAgIGlmIChjID09PSBxdW90ZUNoYXIpIHtcbiAgICAgICAgICBpblF1b3RlID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoYyA9PT0gUVVPVEVfQ0hBUiB8fCBjID09PSBBUE9TX0NIQVIpIHtcbiAgICAgICAgaW5RdW90ZSA9IHRydWU7XG4gICAgICAgIHF1b3RlQ2hhciA9IGM7XG4gICAgICB9IGVsc2UgaWYgKGMgPT09IFNMQVNIX0NIQVIgJiYgdGFnRW5kICsgMSA8IGh0bWwubGVuZ3RoICYmIGh0bWwuY2hhckNvZGVBdCh0YWdFbmQgKyAxKSA9PT0gR1RfQ0hBUikge1xuICAgICAgICBpc1NlbGZDbG9zaW5nID0gdHJ1ZTtcbiAgICAgICAgdGFnRW5kICs9IDI7XG4gICAgICAgIGZvdW5kRW5kID0gdHJ1ZTtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9IGVsc2UgaWYgKGMgPT09IEdUX0NIQVIpIHtcbiAgICAgICAgdGFnRW5kKys7XG4gICAgICAgIGZvdW5kRW5kID0gdHJ1ZTtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICB0YWdFbmQrKztcbiAgICB9XG4gICAgaWYgKCFmb3VuZEVuZCkge1xuICAgICAgY29weUFjY3VtdWxhdGVkVGV4dCgpO1xuICAgICAgYWRkVGV4dChodG1sLnN1YnN0cmluZyhwb3NpdGlvbikpO1xuICAgICAgYnJlYWs7XG4gICAgfVxuICAgIGNvbnN0IGF0dHJpYnV0ZXNTdHIgPSBodG1sLnN1YnN0cmluZyh0YWdOYW1lRW5kLCB0YWdFbmQgLSAoaXNTZWxmQ2xvc2luZyA/IDIgOiAxKSkudHJpbSgpO1xuICAgIGNvbnN0IGF0dHJpYnV0ZXMgPSBwYXJzZUF0dHJpYnV0ZXMoYXR0cmlidXRlc1N0cik7XG4gICAgaWYgKHRhZ0lkID09PSBUQUdfSFRNTCkge1xuICAgICAgY29weUFjY3VtdWxhdGVkVGV4dCgpO1xuICAgICAgaW5kZXhlcy5odG1sVGFnU3RhcnQgPSBjdXJyZW50T3V0cHV0TGVuZ3RoO1xuICAgICAgaWYgKE9iamVjdC5rZXlzKGF0dHJpYnV0ZXMpLmxlbmd0aCA+IDApIHtcbiAgICAgICAgaW5wdXQuaHRtbEF0dHJzID0gYXR0cmlidXRlcztcbiAgICAgICAgYWRkVGV4dChgPCR7dGFnTmFtZX0+YCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhZGRUZXh0KGh0bWwuc3Vic3RyaW5nKHBvc2l0aW9uLCB0YWdFbmQpKTtcbiAgICAgIH1cbiAgICAgIGluZGV4ZXMuaHRtbFRhZ0VuZCA9IGN1cnJlbnRPdXRwdXRMZW5ndGg7XG4gICAgfSBlbHNlIGlmICh0YWdJZCA9PT0gVEFHX0JPRFkpIHtcbiAgICAgIGNvcHlBY2N1bXVsYXRlZFRleHQoKTtcbiAgICAgIGluZGV4ZXMuYm9keVRhZ1N0YXJ0ID0gY3VycmVudE91dHB1dExlbmd0aDtcbiAgICAgIGlmIChPYmplY3Qua2V5cyhhdHRyaWJ1dGVzKS5sZW5ndGggPiAwKSB7XG4gICAgICAgIGlucHV0LmJvZHlBdHRycyA9IGF0dHJpYnV0ZXM7XG4gICAgICAgIGFkZFRleHQoYDwke3RhZ05hbWV9PmApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYWRkVGV4dChodG1sLnN1YnN0cmluZyhwb3NpdGlvbiwgdGFnRW5kKSk7XG4gICAgICB9XG4gICAgICBpbmRleGVzLmJvZHlUYWdFbmQgPSBjdXJyZW50T3V0cHV0TGVuZ3RoO1xuICAgICAgZm91bmRCb2R5U3RhcnQgPSB0cnVlO1xuICAgICAgcG9zaXRpb24gPSB0YWdFbmQ7XG4gICAgICBsYXN0Q29weVBvc2l0aW9uID0gcG9zaXRpb247XG4gICAgICBicmVhaztcbiAgICB9IGVsc2UgaWYgKHRhZ0lkID09PSBUQUdfSEVBRCkge1xuICAgICAgaW5IZWFkID0gdHJ1ZTtcbiAgICAgIGNvcHlBY2N1bXVsYXRlZFRleHQoKTtcbiAgICAgIGFkZFRleHQoaHRtbC5zdWJzdHJpbmcocG9zaXRpb24sIHRhZ0VuZCkpO1xuICAgIH0gZWxzZSBpZiAoaW5IZWFkICYmIEhFQURfRUxFTUVOVFNfVE9fRVhUUkFDVC5oYXModGFnSWQpKSB7XG4gICAgICBpZiAodGFnSWQgPT09IFRBR19USVRMRSkge1xuICAgICAgICBpZiAoIWlzU2VsZkNsb3NpbmcpIHtcbiAgICAgICAgICBjb25zdCB0aXRsZUVuZCA9IGZpbmRDbG9zaW5nVGFnKGh0bWwsIHRhZ0VuZCwgdGFnTmFtZSk7XG4gICAgICAgICAgaWYgKHRpdGxlRW5kICE9PSAtMSkge1xuICAgICAgICAgICAgY29uc3QgdGl0bGVDb250ZW50ID0gaHRtbC5zdWJzdHJpbmcodGFnRW5kLCB0aXRsZUVuZCkudHJpbSgpO1xuICAgICAgICAgICAgaWYgKHRpdGxlQ29udGVudCAmJiAhaW5wdXQudGl0bGUpIHtcbiAgICAgICAgICAgICAgaW5wdXQudGl0bGUgPSB0aXRsZUNvbnRlbnQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBwb3NpdGlvbiA9IGZpbmRUYWdFbmQoaHRtbCwgdGl0bGVFbmQsIHRhZ05hbWUpO1xuICAgICAgICAgICAgbGFzdENvcHlQb3NpdGlvbiA9IHBvc2l0aW9uO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKHRhZ0lkID09PSBUQUdfU0NSSVBUKSB7XG4gICAgICAgIGNvbnN0IHNjcmlwdEF0dHJzID0geyAuLi5hdHRyaWJ1dGVzIH07XG4gICAgICAgIGlmICghaXNTZWxmQ2xvc2luZykge1xuICAgICAgICAgIGNvbnN0IHNjcmlwdEVuZCA9IGZpbmRDbG9zaW5nVGFnKGh0bWwsIHRhZ0VuZCwgdGFnTmFtZSk7XG4gICAgICAgICAgaWYgKHNjcmlwdEVuZCAhPT0gLTEpIHtcbiAgICAgICAgICAgIGNvbnN0IHNjcmlwdENvbnRlbnQgPSBodG1sLnN1YnN0cmluZyh0YWdFbmQsIHNjcmlwdEVuZCk7XG4gICAgICAgICAgICBzY3JpcHRBdHRycy5pbm5lckhUTUwgPSBzY3JpcHRDb250ZW50IHx8IFwiXCI7XG4gICAgICAgICAgICBwb3NpdGlvbiA9IGZpbmRUYWdFbmQoaHRtbCwgc2NyaXB0RW5kLCB0YWdOYW1lKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2NyaXB0QXR0cnMuaW5uZXJIVE1MID0gXCJcIjtcbiAgICAgICAgICAgIHBvc2l0aW9uID0gdGFnRW5kO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzY3JpcHRBdHRycy5pbm5lckhUTUwgPSBcIlwiO1xuICAgICAgICAgIHBvc2l0aW9uID0gdGFnRW5kO1xuICAgICAgICB9XG4gICAgICAgIGxhc3RDb3B5UG9zaXRpb24gPSBwb3NpdGlvbjtcbiAgICAgICAgKGlucHV0LnNjcmlwdCB8fD0gW10pLnB1c2goc2NyaXB0QXR0cnMpO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH0gZWxzZSBpZiAodGFnSWQgPT09IFRBR19TVFlMRSkge1xuICAgICAgICBjb25zdCBzdHlsZUF0dHJzID0geyAuLi5hdHRyaWJ1dGVzIH07XG4gICAgICAgIGlmICghaXNTZWxmQ2xvc2luZykge1xuICAgICAgICAgIGNvbnN0IHN0eWxlRW5kID0gZmluZENsb3NpbmdUYWcoaHRtbCwgdGFnRW5kLCB0YWdOYW1lKTtcbiAgICAgICAgICBpZiAoc3R5bGVFbmQgIT09IC0xKSB7XG4gICAgICAgICAgICBjb25zdCBzdHlsZUNvbnRlbnQgPSBodG1sLnN1YnN0cmluZyh0YWdFbmQsIHN0eWxlRW5kKTtcbiAgICAgICAgICAgIHN0eWxlQXR0cnMudGV4dENvbnRlbnQgPSBzdHlsZUNvbnRlbnQgfHwgXCJcIjtcbiAgICAgICAgICAgIHBvc2l0aW9uID0gZmluZFRhZ0VuZChodG1sLCBzdHlsZUVuZCwgdGFnTmFtZSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHN0eWxlQXR0cnMudGV4dENvbnRlbnQgPSBcIlwiO1xuICAgICAgICAgICAgcG9zaXRpb24gPSB0YWdFbmQ7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHN0eWxlQXR0cnMudGV4dENvbnRlbnQgPSBcIlwiO1xuICAgICAgICAgIHBvc2l0aW9uID0gdGFnRW5kO1xuICAgICAgICB9XG4gICAgICAgIGxhc3RDb3B5UG9zaXRpb24gPSBwb3NpdGlvbjtcbiAgICAgICAgKGlucHV0LnN0eWxlIHx8PSBbXSkucHVzaChzdHlsZUF0dHJzKTtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9IGVsc2UgaWYgKHRhZ0lkID09PSBUQUdfTUVUQSkge1xuICAgICAgICAoaW5wdXQubWV0YSB8fD0gW10pLnB1c2goYXR0cmlidXRlcyk7XG4gICAgICAgIHBvc2l0aW9uID0gdGFnRW5kO1xuICAgICAgICBsYXN0Q29weVBvc2l0aW9uID0gcG9zaXRpb247XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfSBlbHNlIGlmICh0YWdJZCA9PT0gVEFHX0xJTkspIHtcbiAgICAgICAgKGlucHV0LmxpbmsgfHw9IFtdKS5wdXNoKGF0dHJpYnV0ZXMpO1xuICAgICAgICBwb3NpdGlvbiA9IHRhZ0VuZDtcbiAgICAgICAgbGFzdENvcHlQb3NpdGlvbiA9IHBvc2l0aW9uO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH0gZWxzZSBpZiAodGFnSWQgPT09IFRBR19CQVNFICYmICFpbnB1dC5iYXNlKSB7XG4gICAgICAgIGlucHV0LmJhc2UgPSBhdHRyaWJ1dGVzO1xuICAgICAgICBwb3NpdGlvbiA9IHRhZ0VuZDtcbiAgICAgICAgbGFzdENvcHlQb3NpdGlvbiA9IHBvc2l0aW9uO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgY29weUFjY3VtdWxhdGVkVGV4dCgpO1xuICAgICAgYWRkVGV4dChodG1sLnN1YnN0cmluZyhwb3NpdGlvbiwgdGFnRW5kKSk7XG4gICAgfVxuICAgIHBvc2l0aW9uID0gdGFnRW5kO1xuICAgIGxhc3RDb3B5UG9zaXRpb24gPSBwb3NpdGlvbjtcbiAgfVxuICBjb25zdCByZW1haW5pbmdIdG1sID0gaHRtbC5zdWJzdHJpbmcocG9zaXRpb24pO1xuICBjb25zdCBib2R5Q2xvc2VJbmRleCA9IHJlbWFpbmluZ0h0bWwuaW5kZXhPZihcIjwvYm9keT5cIik7XG4gIGlmIChib2R5Q2xvc2VJbmRleCAhPT0gLTEpIHtcbiAgICBpbmRleGVzLmJvZHlDbG9zZVRhZ1N0YXJ0ID0gY3VycmVudE91dHB1dExlbmd0aCArIGJvZHlDbG9zZUluZGV4O1xuICB9XG4gIGNvcHlBY2N1bXVsYXRlZFRleHQoKTtcbiAgYWRkVGV4dChyZW1haW5pbmdIdG1sKTtcbiAgcmV0dXJuIHsgaHRtbDogaHRtbFBhcnRzLmpvaW4oXCJcIiksIGlucHV0LCBpbmRleGVzIH07XG59XG5mdW5jdGlvbiBmaW5kQ2xvc2luZ1RhZyhodG1sLCBzdGFydFBvcywgdGFnTmFtZSkge1xuICBjb25zdCB0YWdJZCA9IFRhZ0lkTWFwW3RhZ05hbWVdO1xuICBjb25zdCBpc1NjcmlwdE9yU3R5bGUgPSB0YWdJZCA9PT0gVEFHX1NDUklQVCB8fCB0YWdJZCA9PT0gVEFHX1NUWUxFO1xuICBpZiAoIWlzU2NyaXB0T3JTdHlsZSkge1xuICAgIGNvbnN0IGNsb3NpbmdUYWcyID0gYDwvJHt0YWdOYW1lfWA7XG4gICAgY29uc3QgaW5kZXggPSBodG1sLmluZGV4T2YoY2xvc2luZ1RhZzIsIHN0YXJ0UG9zKTtcbiAgICByZXR1cm4gaW5kZXggPT09IC0xID8gLTEgOiBpbmRleDtcbiAgfVxuICBjb25zdCBjbG9zaW5nVGFnID0gYDwvJHt0YWdOYW1lfWA7XG4gIGxldCBwb3MgPSBzdGFydFBvcztcbiAgbGV0IGluU2luZ2xlUXVvdGUgPSBmYWxzZTtcbiAgbGV0IGluRG91YmxlUXVvdGUgPSBmYWxzZTtcbiAgbGV0IGluQmFja3RpY2sgPSBmYWxzZTtcbiAgbGV0IGxhc3RDaGFyV2FzQmFja3NsYXNoID0gZmFsc2U7XG4gIHdoaWxlIChwb3MgPCBodG1sLmxlbmd0aCkge1xuICAgIGNvbnN0IGN1cnJlbnRDaGFyQ29kZSA9IGh0bWwuY2hhckNvZGVBdChwb3MpO1xuICAgIGlmICghbGFzdENoYXJXYXNCYWNrc2xhc2gpIHtcbiAgICAgIGlmIChjdXJyZW50Q2hhckNvZGUgPT09IEFQT1NfQ0hBUiAmJiAhaW5Eb3VibGVRdW90ZSAmJiAhaW5CYWNrdGljaykge1xuICAgICAgICBpblNpbmdsZVF1b3RlID0gIWluU2luZ2xlUXVvdGU7XG4gICAgICB9IGVsc2UgaWYgKGN1cnJlbnRDaGFyQ29kZSA9PT0gUVVPVEVfQ0hBUiAmJiAhaW5TaW5nbGVRdW90ZSAmJiAhaW5CYWNrdGljaykge1xuICAgICAgICBpbkRvdWJsZVF1b3RlID0gIWluRG91YmxlUXVvdGU7XG4gICAgICB9IGVsc2UgaWYgKGN1cnJlbnRDaGFyQ29kZSA9PT0gOTYgJiYgIWluU2luZ2xlUXVvdGUgJiYgIWluRG91YmxlUXVvdGUpIHtcbiAgICAgICAgaW5CYWNrdGljayA9ICFpbkJhY2t0aWNrO1xuICAgICAgfVxuICAgIH1cbiAgICBsYXN0Q2hhcldhc0JhY2tzbGFzaCA9IGN1cnJlbnRDaGFyQ29kZSA9PT0gQkFDS1NMQVNIX0NIQVIgJiYgIWxhc3RDaGFyV2FzQmFja3NsYXNoO1xuICAgIGNvbnN0IGluUXVvdGVzID0gaW5TaW5nbGVRdW90ZSB8fCBpbkRvdWJsZVF1b3RlIHx8IGluQmFja3RpY2s7XG4gICAgaWYgKCFpblF1b3RlcyAmJiBodG1sLnN0YXJ0c1dpdGgoY2xvc2luZ1RhZywgcG9zKSkge1xuICAgICAgY29uc3QgYWZ0ZXJUYWdQb3MgPSBwb3MgKyBjbG9zaW5nVGFnLmxlbmd0aDtcbiAgICAgIGlmIChhZnRlclRhZ1BvcyA+PSBodG1sLmxlbmd0aCkge1xuICAgICAgICByZXR1cm4gcG9zO1xuICAgICAgfVxuICAgICAgY29uc3QgbmV4dENoYXIgPSBodG1sLmNoYXJDb2RlQXQoYWZ0ZXJUYWdQb3MpO1xuICAgICAgaWYgKG5leHRDaGFyID09PSBHVF9DSEFSIHx8IGlzV2hpdGVzcGFjZShuZXh0Q2hhcikpIHtcbiAgICAgICAgcmV0dXJuIHBvcztcbiAgICAgIH1cbiAgICB9XG4gICAgcG9zKys7XG4gIH1cbiAgcmV0dXJuIC0xO1xufVxuZnVuY3Rpb24gZmluZFRhZ0VuZChodG1sLCBjbG9zaW5nVGFnU3RhcnQsIHRhZ05hbWUpIHtcbiAgbGV0IHBvcyA9IGNsb3NpbmdUYWdTdGFydCArIHRhZ05hbWUubGVuZ3RoICsgMjtcbiAgd2hpbGUgKHBvcyA8IGh0bWwubGVuZ3RoICYmIGh0bWwuY2hhckNvZGVBdChwb3MpICE9PSBHVF9DSEFSKSB7XG4gICAgcG9zKys7XG4gIH1cbiAgcmV0dXJuIHBvcyA8IGh0bWwubGVuZ3RoID8gcG9zICsgMSA6IHBvcztcbn1cbmZ1bmN0aW9uIGFwcGx5SGVhZFRvSHRtbCh0ZW1wbGF0ZSwgaGVhZEh0bWwpIHtcbiAgY29uc3QgeyBodG1sLCBpbmRleGVzIH0gPSB0ZW1wbGF0ZTtcbiAgY29uc3QgcGFydHMgPSBbXTtcbiAgbGV0IGxhc3RJbmRleCA9IDA7XG4gIGlmIChpbmRleGVzLmh0bWxUYWdTdGFydCA+PSAwKSB7XG4gICAgcGFydHMucHVzaChodG1sLnN1YnN0cmluZyhsYXN0SW5kZXgsIGluZGV4ZXMuaHRtbFRhZ1N0YXJ0KSk7XG4gICAgcGFydHMucHVzaChgPGh0bWwke2hlYWRIdG1sLmh0bWxBdHRyc30+YCk7XG4gICAgbGFzdEluZGV4ID0gaW5kZXhlcy5odG1sVGFnRW5kO1xuICB9XG4gIGlmIChpbmRleGVzLmhlYWRUYWdFbmQgPj0gMCkge1xuICAgIHBhcnRzLnB1c2goaHRtbC5zdWJzdHJpbmcobGFzdEluZGV4LCBpbmRleGVzLmhlYWRUYWdFbmQpKTtcbiAgICBwYXJ0cy5wdXNoKGhlYWRIdG1sLmhlYWRUYWdzKTtcbiAgICBwYXJ0cy5wdXNoKFwiPC9oZWFkPlwiKTtcbiAgICBsYXN0SW5kZXggPSBpbmRleGVzLmhlYWRUYWdFbmQgKyA3O1xuICB9XG4gIGlmIChpbmRleGVzLmJvZHlUYWdTdGFydCA+PSAwKSB7XG4gICAgcGFydHMucHVzaChodG1sLnN1YnN0cmluZyhsYXN0SW5kZXgsIGluZGV4ZXMuYm9keVRhZ1N0YXJ0KSk7XG4gICAgaWYgKGhlYWRIdG1sLmJvZHlUYWdzT3Blbikge1xuICAgICAgcGFydHMucHVzaChgPGJvZHkke2hlYWRIdG1sLmJvZHlBdHRyc30+XG4ke2hlYWRIdG1sLmJvZHlUYWdzT3Blbn1gKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcGFydHMucHVzaChgPGJvZHkke2hlYWRIdG1sLmJvZHlBdHRyc30+YCk7XG4gICAgfVxuICAgIGxhc3RJbmRleCA9IGluZGV4ZXMuYm9keVRhZ0VuZDtcbiAgfVxuICBpZiAoaW5kZXhlcy5ib2R5Q2xvc2VUYWdTdGFydCA+PSAwKSB7XG4gICAgcGFydHMucHVzaChodG1sLnN1YnN0cmluZyhsYXN0SW5kZXgsIGluZGV4ZXMuYm9keUNsb3NlVGFnU3RhcnQpKTtcbiAgICBwYXJ0cy5wdXNoKGhlYWRIdG1sLmJvZHlUYWdzKTtcbiAgICBwYXJ0cy5wdXNoKGh0bWwuc3Vic3RyaW5nKGluZGV4ZXMuYm9keUNsb3NlVGFnU3RhcnQpKTtcbiAgfSBlbHNlIHtcbiAgICBwYXJ0cy5wdXNoKGh0bWwuc3Vic3RyaW5nKGxhc3RJbmRleCkpO1xuICB9XG4gIHJldHVybiBwYXJ0cy5qb2luKFwiXCIpO1xufVxuXG5leHBvcnQgeyBUYWdJZE1hcCwgYXBwbHlIZWFkVG9IdG1sLCBwYXJzZUF0dHJpYnV0ZXMsIHBhcnNlSHRtbEZvckluZGV4ZXMsIHBhcnNlSHRtbEZvclVuaGVhZEV4dHJhY3Rpb24sIHByZXBhcmVUZW1wbGF0ZSB9O1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLG1DQUFtQyxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDOztBQUVwUyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDbkIsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUNyQixLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ3BCLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDbkIsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUNuQixLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ2xCLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDbEIsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUNyQixLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ3RCLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDckIsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUNwQixLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDM0IsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUN6QixLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ3BCLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRO0FBQ2hCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRO0FBQ2hCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTO0FBQ2xCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRO0FBQ2hCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRO0FBQ2hCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxVQUFVO0FBQ3BCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTO0FBQ2xCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRO0FBQ2hCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNSLENBQUM7QUFDRCxLQUFLLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMxSCxRQUFRLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUM7QUFDNUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQztBQUMvQixDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7QUFDaEM7QUFDQSxRQUFRLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUNoRjtBQUNBLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxTQUFTLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN0RCxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNsQixDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU07QUFDdEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3JILENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN6SSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxRQUFRO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsUUFBUTtBQUNqRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQy9DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUk7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDOUIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU07QUFDNUIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsVUFBVTtBQUN4QixDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVTtBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNqRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNwRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFVBQVU7QUFDdEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVTtBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDdEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFlBQVk7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDL0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFlBQVk7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxjQUFjO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVk7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFVBQVU7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsY0FBYztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFVBQVU7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDMUQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQy9FLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDM0UsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNmO0FBQ0EsUUFBUSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUM7QUFDakUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUM7QUFDakUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3JDO0FBQ0EsUUFBUSxDQUFDLDRCQUE0QixDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNwQixDQUFDLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUM1QixDQUFDLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNsRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTTtBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNO0FBQ3RDLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO0FBQ3JELENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUM1RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUM3RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVztBQUNyQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzVFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNqRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLG1CQUFtQjtBQUNsRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsY0FBYztBQUMzQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDaEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUN0RSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxVQUFVO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUN0RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDMUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzdGLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLGFBQWEsQ0FBQztBQUNyRCxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsbUJBQW1CO0FBQ2hELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsVUFBVTtBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxtQkFBbUI7QUFDOUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsbUJBQW1CO0FBQ2hELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsVUFBVTtBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxtQkFBbUI7QUFDOUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQy9DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDOUQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3hFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsWUFBWTtBQUN4QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMxRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2pFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNuRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMzRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQztBQUMvQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNqRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMxRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUMvQixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7QUFDaEQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUN6RCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLGNBQWM7QUFDcEUsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUM7QUFDeEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDckQ7QUFDQSxRQUFRLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUztBQUNyRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3JELENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNwQyxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ3BCLENBQUMsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzNCLENBQUMsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzNCLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3hCLENBQUMsQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDbEMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7QUFDaEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDMUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDbEYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDN0UsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQjtBQUN0RixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVTtBQUNqRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUN2RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNO0FBQ2pELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDdEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQzFELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDWDtBQUNBLFFBQVEsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDcEQsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNoRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQzFDO0FBQ0EsUUFBUSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ3BDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQy9ELENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVU7QUFDbEMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQzdELENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUMvRCxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9DLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVU7QUFDbEMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUNwRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUN6RCxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2Qjs7QUFFQSxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQzsifQ==