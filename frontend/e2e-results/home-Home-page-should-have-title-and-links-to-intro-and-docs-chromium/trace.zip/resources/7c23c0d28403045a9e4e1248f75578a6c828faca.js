import { ref, watch, computed } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
import { refDefault, useUrlSearchParams } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vueuse+core@14.4.0_vue@3.5.40_typescript@6.0.3_/node_modules/@vueuse/core/dist/index.js?v=7e73afc2";
import { galleryImages } from "/_nuxt/composables/gallery/images.ts";
/**
* Custom composable to manage the image gallery state and filtering logic.
* Currently, it returns all images without filtering, but it can be extended to implement search functionality.
*/
export function useImageGallery() {
	const _images = ref(galleryImages);
	const images = refDefault(_images, []);
	const search = ref("");
	const query = useUrlSearchParams();
	watch(search, (newValue) => {
		query.q = newValue;
	});
	const filteredImages = computed(() => {
		// if (search.value === '') return images.value
		return images.value.filter((img) => img.name.toLowerCase().includes(search.value.toLowerCase()));
	});
	const keywords = computed(() => {
		return [
			"Shampoing",
			"Coupe",
			"Brushing",
			"Coloration",
			"Soin",
			"Chignon",
			"Styling",
			"Hair contouring"
		];
	});
	function isVideo(value) {
		if (typeof value === "string") {
			return value.endsWith(".mp4") || value.endsWith(".webm") || value.endsWith(".ogg");
		} else if (Array.isArray(value)) {
			return value.some((item) => item.endsWith(".mp4") || item.endsWith(".webm") || item.endsWith(".ogg"));
		}
		return false;
	}
	return {
		/**
		* A reactive reference to the array of gallery images. Each image has a name, a
		* path (or paths) to the image file(s), and a category indicating whether it's an image or a video.
		* This data can be used to display the gallery and implement filtering based on the search query.
		*/
		images,
		/**
		* A reactive reference to the search query entered by the user. This can be used to
		* filter the images in the gallery based on their names.
		* @default '''
		*/
		search,
		/**
		* A computed property that filters the images based on the search query. It checks if
		* the image name includes the search term (case-insensitive). Currently, it returns all images, but
		* it can be extended to implement actual filtering logic.
		*/
		filteredImages,
		/**
		* A computed property that generates a list of unique keywords from the image names
		* in the gallery. This can be used for filtering or categorization purposes.
		*/
		keywords,
		/**
		* Checks if the provided value is a video file based on its extension. It supports both string and array of strings.
		* @param value - The value to check, which can be a string or an array of strings representing image paths.
		*/
		isVideo
	};
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7QUFDQSxTQUFTLHFCQUFxQjs7Ozs7QUFNOUIsT0FBTyxTQUFTLGtCQUFrQjtDQUNoQyxNQUFNLFVBQVUsSUFBSSxhQUFhO0NBQ2pDLE1BQU0sU0FBUyxXQUFXLFNBQVMsQ0FBQyxDQUFDO0NBRXJDLE1BQU0sU0FBUyxJQUFZLEVBQUU7Q0FDN0IsTUFBTSxRQUFRLG1CQUFtQjtDQUVqQyxNQUFNLFNBQVMsYUFBYTtFQUMxQixNQUFNLElBQUk7Q0FDWixDQUFDO0NBRUQsTUFBTSxpQkFBaUIsZUFBZTs7RUFFcEMsT0FBTyxPQUFPLE1BQU0sUUFBTyxRQUFPLElBQUksS0FBSyxZQUFZLENBQUMsQ0FBQyxTQUFTLE9BQU8sTUFBTSxZQUFZLENBQUMsQ0FBQztDQUMvRixDQUFDO0NBRUQsTUFBTSxXQUFXLGVBQWU7RUFDOUIsT0FBTztHQUNMO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRjtDQUNGLENBQUM7Q0FFRCxTQUFTLFFBQVEsT0FBNEM7RUFDM0QsSUFBSSxPQUFPLFVBQVUsVUFBVTtHQUM3QixPQUFPLE1BQU0sU0FBUyxNQUFNLEtBQUssTUFBTSxTQUFTLE9BQU8sS0FBSyxNQUFNLFNBQVMsTUFBTTtFQUNuRixPQUNLLElBQUksTUFBTSxRQUFRLEtBQUssR0FBRztHQUM3QixPQUFPLE1BQU0sTUFBSyxTQUFRLEtBQUssU0FBUyxNQUFNLEtBQUssS0FBSyxTQUFTLE9BQU8sS0FBSyxLQUFLLFNBQVMsTUFBTSxDQUFDO0VBQ3BHO0VBQ0EsT0FBTztDQUNUO0NBRUEsT0FBTzs7Ozs7O0VBTUw7Ozs7OztFQU1BOzs7Ozs7RUFNQTs7Ozs7RUFLQTs7Ozs7RUFLQTtDQUNGO0FBQ0YiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImJhc2UudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBBcnJheWFibGUgfSBmcm9tICd+L3R5cGVzJ1xuaW1wb3J0IHsgZ2FsbGVyeUltYWdlcyB9IGZyb20gJy4vaW1hZ2VzJ1xuXG4vKipcbiAqIEN1c3RvbSBjb21wb3NhYmxlIHRvIG1hbmFnZSB0aGUgaW1hZ2UgZ2FsbGVyeSBzdGF0ZSBhbmQgZmlsdGVyaW5nIGxvZ2ljLlxuICogQ3VycmVudGx5LCBpdCByZXR1cm5zIGFsbCBpbWFnZXMgd2l0aG91dCBmaWx0ZXJpbmcsIGJ1dCBpdCBjYW4gYmUgZXh0ZW5kZWQgdG8gaW1wbGVtZW50IHNlYXJjaCBmdW5jdGlvbmFsaXR5LlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlSW1hZ2VHYWxsZXJ5KCkge1xuICBjb25zdCBfaW1hZ2VzID0gcmVmKGdhbGxlcnlJbWFnZXMpXG4gIGNvbnN0IGltYWdlcyA9IHJlZkRlZmF1bHQoX2ltYWdlcywgW10pIC8vIEVuc3VyZSBpbWFnZXMgaXMgYWx3YXlzIGFuIGFycmF5XG5cbiAgY29uc3Qgc2VhcmNoID0gcmVmPHN0cmluZz4oJycpXG4gIGNvbnN0IHF1ZXJ5ID0gdXNlVXJsU2VhcmNoUGFyYW1zKClcblxuICB3YXRjaChzZWFyY2gsIChuZXdWYWx1ZSkgPT4ge1xuICAgIHF1ZXJ5LnEgPSBuZXdWYWx1ZVxuICB9KVxuXG4gIGNvbnN0IGZpbHRlcmVkSW1hZ2VzID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIC8vIGlmIChzZWFyY2gudmFsdWUgPT09ICcnKSByZXR1cm4gaW1hZ2VzLnZhbHVlXG4gICAgcmV0dXJuIGltYWdlcy52YWx1ZS5maWx0ZXIoaW1nID0+IGltZy5uYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoc2VhcmNoLnZhbHVlLnRvTG93ZXJDYXNlKCkpKSAvLyBDdXJyZW50bHkgcmV0dXJucyBhbGwgaW1hZ2VzXG4gIH0pXG5cbiAgY29uc3Qga2V5d29yZHMgPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgcmV0dXJuIFtcbiAgICAgICdTaGFtcG9pbmcnLFxuICAgICAgJ0NvdXBlJyxcbiAgICAgICdCcnVzaGluZycsXG4gICAgICAnQ29sb3JhdGlvbicsXG4gICAgICAnU29pbicsXG4gICAgICAnQ2hpZ25vbicsXG4gICAgICAnU3R5bGluZycsXG4gICAgICAnSGFpciBjb250b3VyaW5nJ1xuICAgIF1cbiAgfSlcblxuICBmdW5jdGlvbiBpc1ZpZGVvKHZhbHVlOiBzdHJpbmcgfCBBcnJheWFibGU8c3RyaW5nPik6IGJvb2xlYW4ge1xuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnKSB7XG4gICAgICByZXR1cm4gdmFsdWUuZW5kc1dpdGgoJy5tcDQnKSB8fCB2YWx1ZS5lbmRzV2l0aCgnLndlYm0nKSB8fCB2YWx1ZS5lbmRzV2l0aCgnLm9nZycpXG4gICAgfVxuICAgIGVsc2UgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICByZXR1cm4gdmFsdWUuc29tZShpdGVtID0+IGl0ZW0uZW5kc1dpdGgoJy5tcDQnKSB8fCBpdGVtLmVuZHNXaXRoKCcud2VibScpIHx8IGl0ZW0uZW5kc1dpdGgoJy5vZ2cnKSlcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICByZXR1cm4ge1xuICAgIC8qKlxuICAgICAqIEEgcmVhY3RpdmUgcmVmZXJlbmNlIHRvIHRoZSBhcnJheSBvZiBnYWxsZXJ5IGltYWdlcy4gRWFjaCBpbWFnZSBoYXMgYSBuYW1lLCBhXG4gICAgICogcGF0aCAob3IgcGF0aHMpIHRvIHRoZSBpbWFnZSBmaWxlKHMpLCBhbmQgYSBjYXRlZ29yeSBpbmRpY2F0aW5nIHdoZXRoZXIgaXQncyBhbiBpbWFnZSBvciBhIHZpZGVvLlxuICAgICAqIFRoaXMgZGF0YSBjYW4gYmUgdXNlZCB0byBkaXNwbGF5IHRoZSBnYWxsZXJ5IGFuZCBpbXBsZW1lbnQgZmlsdGVyaW5nIGJhc2VkIG9uIHRoZSBzZWFyY2ggcXVlcnkuXG4gICAgICovXG4gICAgaW1hZ2VzLFxuICAgIC8qKlxuICAgICAqIEEgcmVhY3RpdmUgcmVmZXJlbmNlIHRvIHRoZSBzZWFyY2ggcXVlcnkgZW50ZXJlZCBieSB0aGUgdXNlci4gVGhpcyBjYW4gYmUgdXNlZCB0b1xuICAgICAqIGZpbHRlciB0aGUgaW1hZ2VzIGluIHRoZSBnYWxsZXJ5IGJhc2VkIG9uIHRoZWlyIG5hbWVzLlxuICAgICAqIEBkZWZhdWx0ICcnJ1xuICAgICAqL1xuICAgIHNlYXJjaCxcbiAgICAvKipcbiAgICAgKiBBIGNvbXB1dGVkIHByb3BlcnR5IHRoYXQgZmlsdGVycyB0aGUgaW1hZ2VzIGJhc2VkIG9uIHRoZSBzZWFyY2ggcXVlcnkuIEl0IGNoZWNrcyBpZlxuICAgICAqIHRoZSBpbWFnZSBuYW1lIGluY2x1ZGVzIHRoZSBzZWFyY2ggdGVybSAoY2FzZS1pbnNlbnNpdGl2ZSkuIEN1cnJlbnRseSwgaXQgcmV0dXJucyBhbGwgaW1hZ2VzLCBidXRcbiAgICAgKiBpdCBjYW4gYmUgZXh0ZW5kZWQgdG8gaW1wbGVtZW50IGFjdHVhbCBmaWx0ZXJpbmcgbG9naWMuXG4gICAgICovXG4gICAgZmlsdGVyZWRJbWFnZXMsXG4gICAgLyoqXG4gICAgICogQSBjb21wdXRlZCBwcm9wZXJ0eSB0aGF0IGdlbmVyYXRlcyBhIGxpc3Qgb2YgdW5pcXVlIGtleXdvcmRzIGZyb20gdGhlIGltYWdlIG5hbWVzXG4gICAgICogaW4gdGhlIGdhbGxlcnkuIFRoaXMgY2FuIGJlIHVzZWQgZm9yIGZpbHRlcmluZyBvciBjYXRlZ29yaXphdGlvbiBwdXJwb3Nlcy5cbiAgICAgKi9cbiAgICBrZXl3b3JkcyxcbiAgICAvKipcbiAgICAgKiBDaGVja3MgaWYgdGhlIHByb3ZpZGVkIHZhbHVlIGlzIGEgdmlkZW8gZmlsZSBiYXNlZCBvbiBpdHMgZXh0ZW5zaW9uLiBJdCBzdXBwb3J0cyBib3RoIHN0cmluZyBhbmQgYXJyYXkgb2Ygc3RyaW5ncy5cbiAgICAgKiBAcGFyYW0gdmFsdWUgLSBUaGUgdmFsdWUgdG8gY2hlY2ssIHdoaWNoIGNhbiBiZSBhIHN0cmluZyBvciBhbiBhcnJheSBvZiBzdHJpbmdzIHJlcHJlc2VudGluZyBpbWFnZSBwYXRocy5cbiAgICAgKi9cbiAgICBpc1ZpZGVvXG4gIH1cbn1cbiJdLCJmaWxlIjoiL1ZvbHVtZXMvQ29kaW5nL1Byb2plY3RzL1dlYnNpdGVzL2luZWlhaC9mcm9udGVuZC9hcHAvY29tcG9zYWJsZXMvZ2FsbGVyeS9iYXNlLnRzIn0=