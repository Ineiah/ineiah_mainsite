import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/app.vue");import { default as __nuxt_component_0 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/pages/runtime/page.js?v=7e73afc2";
import { createClientOnly } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/components/client-only.js?v=7e73afc2";
import { default as __nuxt_component_1_client } from "/_nuxt/components/cookie/Banner.client.vue";
const __nuxt_component_1_client_wrapped = createClientOnly(__nuxt_component_1_client)
import { createLazyIfComponent } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/components/runtime/lazy-hydrated-component.js?v=7e73afc2";
const __nuxt_component_2_client_lazy_if = createLazyIfComponent("components/cookie/Options.client.vue", () => import("/_nuxt/components/cookie/Options.client.vue").then(c => c.default || c))
import { default as __nuxt_component_3 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/components/dev-only.js?v=7e73afc2";
import { default as __nuxt_component_4 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/components/nuxt-layout.js?v=7e73afc2";
import { useNuxtApp } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/nuxt.js?v=7e73afc2";
import { useMediaQuery } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vueuse+core@14.4.0_vue@3.5.40_typescript@6.0.3_/node_modules/@vueuse/core/dist/index.js?v=7e73afc2";
import { useState as _$__useState } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/composables/state.js?v=7e73afc2";
import { useI18n } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue-i18n@11.4.8_vue@3.5.40_typescript@6.0.3_/node_modules/vue-i18n/dist/vue-i18n.esm-bundler.js";
import { useCookieComposable as _$__useCookieComposable } from "/_nuxt/composables/index.ts";
import { onMounted, onUnmounted } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
import { useBusinessDetails as _$__useBusinessDetails } from "/_nuxt/composables/business/base.ts";
import { useServices as _$__useServices } from "/_nuxt/composables/services/base.ts";
import { useWorkingDaysComposable as _$__useWorkingDaysComposable } from "/_nuxt/composables/business/working_hours.ts";
import { useHead as _$__useHead } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/composables/head.js?v=7e73afc2";
import { useSchemaOrg as _$__useSchemaOrg } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt-schema-org@6.2.8_e1ea9efbc155025faaca417da5a26175/node_modules/nuxt-schema-org/dist/runtime/app/composables/useSchemaOrg.js?v=7e73afc2";
import { defineOrganization } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.cache/vite/client/deps/@unhead_schema-org_vue.js?v=7e73afc2";
import { useLocaleHead as _$__useLocaleHead } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxtjs+i18n@10.6.0_@vue+compiler-dom@3.5.40_db0@0.3.4_better-sqlite3@13.0.2_drizzle-or_ebcb91ac37e09cc979ede2167e22c07a/node_modules/@nuxtjs/i18n/dist/runtime/composables/index.js?v=7e73afc2";
import { useSlug } from "/_nuxt/utils/text.ts";;import { __nuxtTimelineWrap } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+devtools@3.4.1_db0@0.3.4_better-sqlite3@13.0.2_drizzle-orm@0.45.2_@opentelemetry+_0e55243a794e05cb19a29a0506aae086/node_modules/@nuxt/devtools/dist/runtime/function-metrics-helpers.js?v=7e73afc2";const useState = __nuxtTimelineWrap("useState", _$__useState);const useCookieComposable = __nuxtTimelineWrap("useCookieComposable", _$__useCookieComposable);const useBusinessDetails = __nuxtTimelineWrap("useBusinessDetails", _$__useBusinessDetails);const useServices = __nuxtTimelineWrap("useServices", _$__useServices);const useWorkingDaysComposable = __nuxtTimelineWrap("useWorkingDaysComposable", _$__useWorkingDaysComposable);const useHead = __nuxtTimelineWrap("useHead", _$__useHead);const useSchemaOrg = __nuxtTimelineWrap("useSchemaOrg", _$__useSchemaOrg);const useLocaleHead = __nuxtTimelineWrap("useLocaleHead", _$__useLocaleHead);
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@8.2.0_@types+node@26.1.2_esbuild@0.28.1_jiti@2.7.0_sa_bcac4fa99282966dd94ca7ad2dfebde1/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=7e73afc2"
import { defineComponent as _defineComponent } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
import { provideSSRWidth } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vueuse+core@14.4.0_vue@3.5.40_typescript@6.0.3_/node_modules/@vueuse/core/dist/index.js?v=7e73afc2";
const _sfc_main = /*@__PURE__*/ _defineComponent({
	__name: "app",
	setup(__props, { expose: __expose }) {
		__expose();
		const nuxtApp = useNuxtApp();
		provideSSRWidth(1024, nuxtApp.vueApp);
		const isMobile = useMediaQuery("(min-width: 320px)");
		const isLargeScreen = useMediaQuery("(min-width: 1024px)");
		useState("isMobile", () => isMobile);
		useState("isLargeScreen", () => isLargeScreen);
		const { locales, locale } = useI18n();
		useState("ogLocaleAlternate", () => locales.value.filter((l) => l.code !== locale.value).map((l) => l.code));
		/**
		* Cookie
		*/
		const { showOptions } = useCookieComposable();
		/**
		* Background theme
		*/
		const tokens = ["bg-primary-500/20", "dark:bg-primary-800"];
		onMounted(() => {
			document.querySelector("html")?.classList.add(...tokens);
		});
		onUnmounted(() => {
			document.querySelector("html")?.classList.remove(...tokens);
		});
		/**
		* General SEO Tags
		*/
		const { geoLocation, founderImage, organizationLogo, organizationImages, get } = useBusinessDetails();
		const { services } = useServices();
		const { workingDays, days } = useWorkingDaysComposable({
			only: "Weekdays",
			startTime: "09:00",
			endTime: "17:00"
		});
		useHead({ meta: [
			{
				name: "geo.region",
				content: "FR-HDF"
			},
			{
				name: "geo.placename",
				content: get("address").city
			},
			{
				name: "geo.position",
				content: geoLocation.value
			},
			{
				name: "ICBM",
				content: geoLocation.value
			}
		] });
		useHead({
			htmlAttrs: { lang: locale.value },
			link: [{
				rel: "icon",
				type: "image/png",
				href: "/favicon.png"
			}]
		});
		useSchemaOrg([defineOrganization({
			"@type": "HairSalon",
			"name": get("legalName"),
			"legalName": get("legalName"),
			"alternateName": "Inéïah Beauté",
			"description": get("description"),
			"logo": organizationLogo.value,
			"email": get("contact").email,
			"telephone": get("contact").telephone,
			"sameAs": get("sameAs"),
			"image": organizationImages.value,
			"priceRange": "$$",
			"foundingDate": get("foundingDate"),
			"foundingLocation": {
				"@type": "Place",
				"name": get("foundingLocation")
			},
			"founder": {
				"@type": "Person",
				"name": get("founder"),
				"jobTitle": "Founder & CEO",
				"description": get("founderDescription"),
				"image": founderImage.value,
				"url": null,
				"sameAs": get("sameAs"),
				"worksFor": {
					"@type": "Organization",
					"name": get("legalName")
				}
			},
			"numberOfEmployees": {
				"@type": "QuantitativeValue",
				"value": 1
			},
			"hasOfferCatalog": {
				"@type": "OfferCatalog",
				"name": "Services",
				"itemListElement": services.value.flatMap((service) => {
					return service.services.map((subService) => ({
						"@type": "Offer",
						"@id": useSlug(service.name, subService.name || "", subService.gender),
						"price": subService.price,
						"priceCurrency": "EUR",
						"availability": "https://schema.org/InStock",
						"itemOffered": {
							"@type": "Service",
							"name": `${service.name} - ${subService.name || ""} - ${subService.gender}`.trim(),
							"description": service.globalDescription,
							"serviceType": null,
							"provider": {
								"@type": "Organization",
								"name": get("legalName")
							}
						}
					}));
				})
			},
			"taxId": null,
			"vatId": null,
			"address": {
				streetAddress: get("address").street,
				addressLocality: get("address").city,
				postalCode: get("address").postalCode,
				addressCountry: "FR"
			},
			"currenciesAccepted": "EUR",
			"areaServed": {
				"@type": "Place",
				"name": get("address").city,
				"sameAs": `https://fr.wikipedia.org/wiki/${get("address").city}`
			},
			"paymentAccepted": [
				"Credit Card",
				"Apple Pay",
				"Google Pay"
			],
			"openingHoursSpecification": workingDays.value.map((item) => ({
				"@type": "OpeningHoursSpecification",
				"dayOfWeek": item.day,
				"opens": item.startTime,
				"closes": item.endTime
			})),
			"contactPoint": [{
				"@type": "ContactPoint",
				"contactType": "customer service",
				"telephone": get("contact").telephone,
				"email": get("contact").email,
				"availableLanguage": ["English", "French"],
				"hoursAvailable": {
					"@type": "OpeningHoursSpecification",
					"dayOfWeek": days.value,
					"opens": "09:00:00",
					"closes": "15:00:00"
				}
			}]
		})]);
		/**
		* Href Lang
		*/
		const head = useLocaleHead({
			addDirAttribute: true,
			addSeoAttributes: true
		});
		useHead({
			htmlAttrs: { lang: head.value.htmlAttrs?.lang },
			link: [...head.value.link || []],
			meta: [...head.value.meta || []]
		});
		const __returned__ = {
			nuxtApp,
			isMobile,
			isLargeScreen,
			locales,
			locale,
			showOptions,
			tokens,
			geoLocation,
			founderImage,
			organizationLogo,
			organizationImages,
			get,
			services,
			workingDays,
			days,
			head
		};
		Object.defineProperty(__returned__, "__isScriptSetup", {
			enumerable: false,
			value: true
		});
		return __returned__;
	}
});
import { resolveComponent as _resolveComponent, createVNode as _createVNode, withCtx as _withCtx, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _hoisted_1 = { class: "font-sans bg-primary-100 dark:bg-primary-800 relative" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
	const _component_nuxt_page = __nuxt_component_0;
	const _component_cookie_banner = __nuxt_component_1_client_wrapped;
	const _component_LazyIfCookieOptions = __nuxt_component_2_client_lazy_if;
	const _component_dev_only = __nuxt_component_3;
	const _component_nuxt_layout = __nuxt_component_4;
	return _openBlock(), _tracer(2,2,_createElementBlock("section", _hoisted_1, [_tracer(3,4,_createVNode(_component_nuxt_layout, null, {
		default: _withCtx(() => [_tracer(4,6,_createVNode(_component_nuxt_page)), _tracer(6,6,_createVNode(_component_dev_only, null, {
			default: _withCtx(() => [_tracer(7,8,_createVNode(_component_cookie_banner)), _tracer(8,8,_createVNode(_component_LazyIfCookieOptions, {
				show: $setup.showOptions,
				"hydrate-when": $setup.showOptions
			}, null, 8, ["show", "hydrate-when"]))]),
			_: 1
		}))]),
		_: 1
	}))]));
}
import "/_nuxt/app.vue?vue&type=style&index=0&lang.scss";
_sfc_main.__hmrId = "938b83b0";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.on("file-changed", ({ file }) => {
	__VUE_HMR_RUNTIME__.CHANGED_FILE = file;
});
import.meta.hot.accept((mod) => {
	if (!mod) return;
	const { default: updated, _rerender_only } = mod;
	if (_rerender_only) {
		__VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
	} else {
		__VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
	}
});
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper";
export default /*#__PURE__*/ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "/Volumes/Coding/Projects/Websites/ineiah/frontend/app/app.vue"]]);

function _tracer(line, column, vnode) { return _tracerRecordPosition("app/app.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBY0EsU0FBUyx1QkFBdUI7Ozs7O0VBRWhDLE1BQU0sVUFBVSxXQUFXO0VBQzNCLGdCQUFnQixNQUFNLFFBQVEsTUFBTTtFQUVwQyxNQUFNLFdBQVcsY0FBYyxvQkFBb0I7RUFDbkQsTUFBTSxnQkFBZ0IsY0FBYyxxQkFBcUI7RUFFekQsU0FBUyxrQkFBa0IsUUFBUTtFQUNuQyxTQUFTLHVCQUF1QixhQUFhO0VBRTdDLE1BQU0sRUFBRSxTQUFTLFdBQVcsUUFBUTtFQUNwQyxTQUFTLDJCQUEyQixRQUFRLE1BQU0sUUFBTyxNQUFLLEVBQUUsU0FBUyxPQUFPLEtBQUssQ0FBQyxDQUFDLEtBQUksTUFBSyxFQUFFLElBQUksQ0FBQzs7OztFQU12RyxNQUFNLEVBQUUsZ0JBQWdCLG9CQUFvQjs7OztFQU01QyxNQUFNLFNBQVMsQ0FBQyxxQkFBcUIscUJBQXFCO0VBRTFELGdCQUFnQjtHQUNkLFNBQVMsY0FBYyxNQUFNLENBQUMsRUFBRSxVQUFVLElBQUksR0FBRyxNQUFNO0VBQ3pELENBQUM7RUFFRCxrQkFBa0I7R0FDaEIsU0FBUyxjQUFjLE1BQU0sQ0FBQyxFQUFFLFVBQVUsT0FBTyxHQUFHLE1BQU07RUFDNUQsQ0FBQzs7OztFQU1ELE1BQU0sRUFBRSxhQUFhLGNBQWMsa0JBQWtCLG9CQUFvQixRQUFRLG1CQUFtQjtFQUVwRyxNQUFNLEVBQUUsYUFBYSxZQUFZO0VBRWpDLE1BQU0sRUFBRSxhQUFhLFNBQVMseUJBQXlCO0dBQ3JELE1BQU07R0FDTixXQUFXO0dBQ1gsU0FBUztFQUNYLENBQUM7RUFFRCxRQUFRLEVBQ04sTUFBTTtHQUNKO0lBQ0UsTUFBTTtJQUNOLFNBQVM7R0FDWDtHQUNBO0lBQ0UsTUFBTTtJQUNOLFNBQVMsSUFBSSxTQUFTLENBQUMsQ0FBQztHQUMxQjtHQUNBO0lBQ0UsTUFBTTtJQUNOLFNBQVMsWUFBWTtHQUN2QjtHQUNBO0lBQ0UsTUFBTTtJQUNOLFNBQVMsWUFBWTtHQUN2QjtFQUNGLEVBQ0YsQ0FBQztFQUVELFFBQVE7R0FDTixXQUFXLEVBQ1QsTUFBTSxPQUFPLE1BQ2Y7R0FDQSxNQUFNLENBQ0o7SUFDRSxLQUFLO0lBQ0wsTUFBTTtJQUNOLE1BQU07R0FDUixDQUNGO0VBQ0YsQ0FBQztFQUVELGFBQ0UsQ0FDRSxtQkFBbUI7R0FDakIsU0FBUztHQUNULFFBQVEsSUFBSSxXQUFXO0dBQ3ZCLGFBQWEsSUFBSSxXQUFXO0dBQzVCLGlCQUFpQjtHQUNqQixlQUFlLElBQUksYUFBYTtHQUNoQyxRQUFRLGlCQUFpQjtHQUN6QixTQUFTLElBQUksU0FBUyxDQUFDLENBQUM7R0FDeEIsYUFBYSxJQUFJLFNBQVMsQ0FBQyxDQUFDO0dBQzVCLFVBQVUsSUFBSSxRQUFRO0dBQ3RCLFNBQVMsbUJBQW1CO0dBQzVCLGNBQWM7R0FDZCxnQkFBZ0IsSUFBSSxjQUFjO0dBQ2xDLG9CQUFvQjtJQUNsQixTQUFTO0lBQ1QsUUFBUSxJQUFJLGtCQUFrQjtHQUNoQztHQUNBLFdBQVc7SUFDVCxTQUFTO0lBQ1QsUUFBUSxJQUFJLFNBQVM7SUFDckIsWUFBWTtJQUNaLGVBQWUsSUFBSSxvQkFBb0I7SUFDdkMsU0FBUyxhQUFhO0lBQ3RCLE9BQU87SUFDUCxVQUFVLElBQUksUUFBUTtJQUN0QixZQUFZO0tBQ1YsU0FBUztLQUNULFFBQVEsSUFBSSxXQUFXO0lBQ3pCO0dBQ0Y7R0FDQSxxQkFBcUI7SUFDbkIsU0FBUztJQUNULFNBQVM7R0FDWDtHQUNBLG1CQUFtQjtJQUNqQixTQUFTO0lBQ1QsUUFBUTtJQUNSLG1CQUFtQixTQUFTLE1BQU0sU0FBUyxZQUFZO0tBQ3JELE9BQU8sUUFBUSxTQUFTLEtBQUksZ0JBQWU7TUFDekMsU0FBUztNQUNULE9BQU8sUUFBUSxRQUFRLE1BQU0sV0FBVyxRQUFRLElBQUksV0FBVyxNQUFNO01BQ3JFLFNBQVMsV0FBVztNQUNwQixpQkFBaUI7TUFDakIsZ0JBQWdCO01BQ2hCLGVBQWU7T0FDYixTQUFTO09BQ1QsUUFBUSxHQUFHLFFBQVEsS0FBSyxLQUFLLFdBQVcsUUFBUSxHQUFHLEtBQUssV0FBVyxTQUFTLEtBQUs7T0FDakYsZUFBZSxRQUFRO09BQ3ZCLGVBQWU7T0FDZixZQUFZO1FBQ1YsU0FBUztRQUNULFFBQVEsSUFBSSxXQUFXO09BQ3pCO01BQ0Y7S0FDRixFQUFFO0lBQ0osQ0FBQztHQUNIO0dBQ0EsU0FBUztHQUNULFNBQVM7R0FDVCxXQUFXO0lBQ1QsZUFBZSxJQUFJLFNBQVMsQ0FBQyxDQUFDO0lBQzlCLGlCQUFpQixJQUFJLFNBQVMsQ0FBQyxDQUFDO0lBQ2hDLFlBQVksSUFBSSxTQUFTLENBQUMsQ0FBQztJQUMzQixnQkFBZ0I7R0FDbEI7R0FDQSxzQkFBc0I7R0FDdEIsY0FBYztJQUNaLFNBQVM7SUFDVCxRQUFRLElBQUksU0FBUyxDQUFDLENBQUM7SUFDdkIsVUFBVSxpQ0FBaUMsSUFBSSxTQUFTLENBQUMsQ0FBQztHQUM1RDtHQUNBLG1CQUFtQjtJQUNqQjtJQUNBO0lBQ0E7R0FDRjtHQUNBLDZCQUE2QixZQUFZLE1BQU0sS0FBSSxVQUFTO0lBQzFELFNBQVM7SUFDVCxhQUFhLEtBQUs7SUFDbEIsU0FBUyxLQUFLO0lBQ2QsVUFBVSxLQUFLO0dBQ2pCLEVBQUU7R0FDRixnQkFBZ0IsQ0FDZDtJQUNFLFNBQVM7SUFDVCxlQUFlO0lBQ2YsYUFBYSxJQUFJLFNBQVMsQ0FBQyxDQUFDO0lBQzVCLFNBQVMsSUFBSSxTQUFTLENBQUMsQ0FBQztJQUN4QixxQkFBcUIsQ0FBQyxXQUFXLFFBQVE7SUFDekMsa0JBQWtCO0tBQ2hCLFNBQVM7S0FDVCxhQUFhLEtBQUs7S0FDbEIsU0FBUztLQUNULFVBQVU7SUFDWjtHQUNGLENBQ0Y7RUFDRixDQUFDLENBQ0gsQ0FDRjs7OztFQU1BLE1BQU0sT0FBTyxjQUFjO0dBQ3pCLGlCQUFpQjtHQUNqQixrQkFBa0I7RUFDcEIsQ0FBQztFQUVELFFBQVE7R0FDTixXQUFXLEVBQUUsTUFBTSxLQUFLLE1BQU0sV0FBVyxLQUFLO0dBQzlDLE1BQU0sQ0FBQyxHQUFJLEtBQUssTUFBTSxRQUFRLENBQUMsQ0FBRTtHQUNqQyxNQUFNLENBQUMsR0FBSSxLQUFLLE1BQU0sUUFBUSxDQUFDLENBQUU7RUFDbkMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBbk5VLDRCQUFNLHdEQUF1RDs7Ozs7OztDQUF0RSxxREFTUyxXQVRULFlBU1MsYUFSUCxhQU9hO0VBTlgsd0JBQVksYUFBWixhQUFZLG9DQUVaLGFBR1U7R0FGUix3QkFBZ0IsYUFBaEIsYUFBZ0Isd0NBQ2hCO0lBQUE7SUFBQSIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiYXBwLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XG4gIDxzZWN0aW9uIGNsYXNzPVwiZm9udC1zYW5zIGJnLXByaW1hcnktMTAwIGRhcms6YmctcHJpbWFyeS04MDAgcmVsYXRpdmVcIj5cbiAgICA8bnV4dC1sYXlvdXQ+XG4gICAgICA8bnV4dC1wYWdlIC8+XG5cbiAgICAgIDxkZXYtb25seT5cbiAgICAgICAgPGNvb2tpZS1iYW5uZXIgLz5cbiAgICAgICAgPGxhenktY29va2llLW9wdGlvbnMgOnNob3c9XCJzaG93T3B0aW9uc1wiIDpoeWRyYXRlLXdoZW49XCJzaG93T3B0aW9uc1wiIC8+XG4gICAgICA8L2Rldi1vbmx5PlxuICAgIDwvbnV4dC1sYXlvdXQ+XG4gIDwvc2VjdGlvbj5cbjwvdGVtcGxhdGU+XG5cbjxzY3JpcHQgc2V0dXAgbGFuZz1cInRzXCI+XG5pbXBvcnQgeyBwcm92aWRlU1NSV2lkdGggfSBmcm9tICdAdnVldXNlL2NvcmUnXG5cbmNvbnN0IG51eHRBcHAgPSB1c2VOdXh0QXBwKClcbnByb3ZpZGVTU1JXaWR0aCgxMDI0LCBudXh0QXBwLnZ1ZUFwcClcblxuY29uc3QgaXNNb2JpbGUgPSB1c2VNZWRpYVF1ZXJ5KCcobWluLXdpZHRoOiAzMjBweCknKVxuY29uc3QgaXNMYXJnZVNjcmVlbiA9IHVzZU1lZGlhUXVlcnkoJyhtaW4td2lkdGg6IDEwMjRweCknKVxuXG51c2VTdGF0ZSgnaXNNb2JpbGUnLCAoKSA9PiBpc01vYmlsZSlcbnVzZVN0YXRlKCdpc0xhcmdlU2NyZWVuJywgKCkgPT4gaXNMYXJnZVNjcmVlbilcblxuY29uc3QgeyBsb2NhbGVzLCBsb2NhbGUgfSA9IHVzZUkxOG4oKVxudXNlU3RhdGUoJ29nTG9jYWxlQWx0ZXJuYXRlJywgKCkgPT4gbG9jYWxlcy52YWx1ZS5maWx0ZXIobCA9PiBsLmNvZGUgIT09IGxvY2FsZS52YWx1ZSkubWFwKGwgPT4gbC5jb2RlKSlcblxuLyoqXG4gKiBDb29raWVcbiAqL1xuXG5jb25zdCB7IHNob3dPcHRpb25zIH0gPSB1c2VDb29raWVDb21wb3NhYmxlKClcblxuLyoqXG4gKiBCYWNrZ3JvdW5kIHRoZW1lXG4gKi9cblxuY29uc3QgdG9rZW5zID0gWydiZy1wcmltYXJ5LTUwMC8yMCcsICdkYXJrOmJnLXByaW1hcnktODAwJ11cblxub25Nb3VudGVkKCgpID0+IHtcbiAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignaHRtbCcpPy5jbGFzc0xpc3QuYWRkKC4uLnRva2Vucylcbn0pXG5cbm9uVW5tb3VudGVkKCgpID0+IHtcbiAgZG9jdW1lbnQucXVlcnlTZWxlY3RvcignaHRtbCcpPy5jbGFzc0xpc3QucmVtb3ZlKC4uLnRva2Vucylcbn0pXG5cbi8qKlxuICogR2VuZXJhbCBTRU8gVGFnc1xuICovXG5cbmNvbnN0IHsgZ2VvTG9jYXRpb24sIGZvdW5kZXJJbWFnZSwgb3JnYW5pemF0aW9uTG9nbywgb3JnYW5pemF0aW9uSW1hZ2VzLCBnZXQgfSA9IHVzZUJ1c2luZXNzRGV0YWlscygpXG5cbmNvbnN0IHsgc2VydmljZXMgfSA9IHVzZVNlcnZpY2VzKClcblxuY29uc3QgeyB3b3JraW5nRGF5cywgZGF5cyB9ID0gdXNlV29ya2luZ0RheXNDb21wb3NhYmxlKHtcbiAgb25seTogJ1dlZWtkYXlzJyxcbiAgc3RhcnRUaW1lOiAnMDk6MDAnLFxuICBlbmRUaW1lOiAnMTc6MDAnXG59KVxuXG51c2VIZWFkKHtcbiAgbWV0YTogW1xuICAgIHtcbiAgICAgIG5hbWU6ICdnZW8ucmVnaW9uJyxcbiAgICAgIGNvbnRlbnQ6ICdGUi1IREYnXG4gICAgfSxcbiAgICB7XG4gICAgICBuYW1lOiAnZ2VvLnBsYWNlbmFtZScsXG4gICAgICBjb250ZW50OiBnZXQoJ2FkZHJlc3MnKS5jaXR5XG4gICAgfSxcbiAgICB7XG4gICAgICBuYW1lOiAnZ2VvLnBvc2l0aW9uJyxcbiAgICAgIGNvbnRlbnQ6IGdlb0xvY2F0aW9uLnZhbHVlXG4gICAgfSxcbiAgICB7XG4gICAgICBuYW1lOiAnSUNCTScsXG4gICAgICBjb250ZW50OiBnZW9Mb2NhdGlvbi52YWx1ZVxuICAgIH1cbiAgXVxufSlcblxudXNlSGVhZCh7XG4gIGh0bWxBdHRyczoge1xuICAgIGxhbmc6IGxvY2FsZS52YWx1ZVxuICB9LFxuICBsaW5rOiBbXG4gICAge1xuICAgICAgcmVsOiAnaWNvbicsXG4gICAgICB0eXBlOiAnaW1hZ2UvcG5nJyxcbiAgICAgIGhyZWY6ICcvZmF2aWNvbi5wbmcnXG4gICAgfVxuICBdXG59KVxuXG51c2VTY2hlbWFPcmcoXG4gIFtcbiAgICBkZWZpbmVPcmdhbml6YXRpb24oe1xuICAgICAgJ0B0eXBlJzogJ0hhaXJTYWxvbicsXG4gICAgICAnbmFtZSc6IGdldCgnbGVnYWxOYW1lJyksXG4gICAgICAnbGVnYWxOYW1lJzogZ2V0KCdsZWdhbE5hbWUnKSxcbiAgICAgICdhbHRlcm5hdGVOYW1lJzogJ0luw6nDr2FoIEJlYXV0w6knLFxuICAgICAgJ2Rlc2NyaXB0aW9uJzogZ2V0KCdkZXNjcmlwdGlvbicpLFxuICAgICAgJ2xvZ28nOiBvcmdhbml6YXRpb25Mb2dvLnZhbHVlLFxuICAgICAgJ2VtYWlsJzogZ2V0KCdjb250YWN0JykuZW1haWwsXG4gICAgICAndGVsZXBob25lJzogZ2V0KCdjb250YWN0JykudGVsZXBob25lLFxuICAgICAgJ3NhbWVBcyc6IGdldCgnc2FtZUFzJyksXG4gICAgICAnaW1hZ2UnOiBvcmdhbml6YXRpb25JbWFnZXMudmFsdWUsXG4gICAgICAncHJpY2VSYW5nZSc6ICckJCcsXG4gICAgICAnZm91bmRpbmdEYXRlJzogZ2V0KCdmb3VuZGluZ0RhdGUnKSxcbiAgICAgICdmb3VuZGluZ0xvY2F0aW9uJzoge1xuICAgICAgICAnQHR5cGUnOiAnUGxhY2UnLFxuICAgICAgICAnbmFtZSc6IGdldCgnZm91bmRpbmdMb2NhdGlvbicpXG4gICAgICB9LFxuICAgICAgJ2ZvdW5kZXInOiB7XG4gICAgICAgICdAdHlwZSc6ICdQZXJzb24nLFxuICAgICAgICAnbmFtZSc6IGdldCgnZm91bmRlcicpLFxuICAgICAgICAnam9iVGl0bGUnOiAnRm91bmRlciAmIENFTycsXG4gICAgICAgICdkZXNjcmlwdGlvbic6IGdldCgnZm91bmRlckRlc2NyaXB0aW9uJyksXG4gICAgICAgICdpbWFnZSc6IGZvdW5kZXJJbWFnZS52YWx1ZSxcbiAgICAgICAgJ3VybCc6IG51bGwsXG4gICAgICAgICdzYW1lQXMnOiBnZXQoJ3NhbWVBcycpLFxuICAgICAgICAnd29ya3NGb3InOiB7XG4gICAgICAgICAgJ0B0eXBlJzogJ09yZ2FuaXphdGlvbicsXG4gICAgICAgICAgJ25hbWUnOiBnZXQoJ2xlZ2FsTmFtZScpXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICAnbnVtYmVyT2ZFbXBsb3llZXMnOiB7XG4gICAgICAgICdAdHlwZSc6ICdRdWFudGl0YXRpdmVWYWx1ZScsXG4gICAgICAgICd2YWx1ZSc6IDFcbiAgICAgIH0sXG4gICAgICAnaGFzT2ZmZXJDYXRhbG9nJzoge1xuICAgICAgICAnQHR5cGUnOiAnT2ZmZXJDYXRhbG9nJyxcbiAgICAgICAgJ25hbWUnOiAnU2VydmljZXMnLFxuICAgICAgICAnaXRlbUxpc3RFbGVtZW50Jzogc2VydmljZXMudmFsdWUuZmxhdE1hcCgoc2VydmljZSkgPT4ge1xuICAgICAgICAgIHJldHVybiBzZXJ2aWNlLnNlcnZpY2VzLm1hcChzdWJTZXJ2aWNlID0+ICh7XG4gICAgICAgICAgICAnQHR5cGUnOiAnT2ZmZXInLFxuICAgICAgICAgICAgJ0BpZCc6IHVzZVNsdWcoc2VydmljZS5uYW1lLCBzdWJTZXJ2aWNlLm5hbWUgfHwgJycsIHN1YlNlcnZpY2UuZ2VuZGVyKSxcbiAgICAgICAgICAgICdwcmljZSc6IHN1YlNlcnZpY2UucHJpY2UsXG4gICAgICAgICAgICAncHJpY2VDdXJyZW5jeSc6ICdFVVInLFxuICAgICAgICAgICAgJ2F2YWlsYWJpbGl0eSc6ICdodHRwczovL3NjaGVtYS5vcmcvSW5TdG9jaycsXG4gICAgICAgICAgICAnaXRlbU9mZmVyZWQnOiB7XG4gICAgICAgICAgICAgICdAdHlwZSc6ICdTZXJ2aWNlJyxcbiAgICAgICAgICAgICAgJ25hbWUnOiBgJHtzZXJ2aWNlLm5hbWV9IC0gJHtzdWJTZXJ2aWNlLm5hbWUgfHwgJyd9IC0gJHtzdWJTZXJ2aWNlLmdlbmRlcn1gLnRyaW0oKSxcbiAgICAgICAgICAgICAgJ2Rlc2NyaXB0aW9uJzogc2VydmljZS5nbG9iYWxEZXNjcmlwdGlvbixcbiAgICAgICAgICAgICAgJ3NlcnZpY2VUeXBlJzogbnVsbCxcbiAgICAgICAgICAgICAgJ3Byb3ZpZGVyJzoge1xuICAgICAgICAgICAgICAgICdAdHlwZSc6ICdPcmdhbml6YXRpb24nLFxuICAgICAgICAgICAgICAgICduYW1lJzogZ2V0KCdsZWdhbE5hbWUnKVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSkpXG4gICAgICAgIH0pXG4gICAgICB9LFxuICAgICAgJ3RheElkJzogbnVsbCxcbiAgICAgICd2YXRJZCc6IG51bGwsXG4gICAgICAnYWRkcmVzcyc6IHtcbiAgICAgICAgc3RyZWV0QWRkcmVzczogZ2V0KCdhZGRyZXNzJykuc3RyZWV0LFxuICAgICAgICBhZGRyZXNzTG9jYWxpdHk6IGdldCgnYWRkcmVzcycpLmNpdHksXG4gICAgICAgIHBvc3RhbENvZGU6IGdldCgnYWRkcmVzcycpLnBvc3RhbENvZGUsXG4gICAgICAgIGFkZHJlc3NDb3VudHJ5OiAnRlInXG4gICAgICB9LFxuICAgICAgJ2N1cnJlbmNpZXNBY2NlcHRlZCc6ICdFVVInLFxuICAgICAgJ2FyZWFTZXJ2ZWQnOiB7XG4gICAgICAgICdAdHlwZSc6ICdQbGFjZScsXG4gICAgICAgICduYW1lJzogZ2V0KCdhZGRyZXNzJykuY2l0eSxcbiAgICAgICAgJ3NhbWVBcyc6IGBodHRwczovL2ZyLndpa2lwZWRpYS5vcmcvd2lraS8ke2dldCgnYWRkcmVzcycpLmNpdHl9YFxuICAgICAgfSxcbiAgICAgICdwYXltZW50QWNjZXB0ZWQnOiBbXG4gICAgICAgICdDcmVkaXQgQ2FyZCcsXG4gICAgICAgICdBcHBsZSBQYXknLFxuICAgICAgICAnR29vZ2xlIFBheSdcbiAgICAgIF0sXG4gICAgICAnb3BlbmluZ0hvdXJzU3BlY2lmaWNhdGlvbic6IHdvcmtpbmdEYXlzLnZhbHVlLm1hcChpdGVtID0+ICh7XG4gICAgICAgICdAdHlwZSc6ICdPcGVuaW5nSG91cnNTcGVjaWZpY2F0aW9uJyxcbiAgICAgICAgJ2RheU9mV2Vlayc6IGl0ZW0uZGF5LFxuICAgICAgICAnb3BlbnMnOiBpdGVtLnN0YXJ0VGltZSxcbiAgICAgICAgJ2Nsb3Nlcyc6IGl0ZW0uZW5kVGltZVxuICAgICAgfSkpLFxuICAgICAgJ2NvbnRhY3RQb2ludCc6IFtcbiAgICAgICAge1xuICAgICAgICAgICdAdHlwZSc6ICdDb250YWN0UG9pbnQnLFxuICAgICAgICAgICdjb250YWN0VHlwZSc6ICdjdXN0b21lciBzZXJ2aWNlJyxcbiAgICAgICAgICAndGVsZXBob25lJzogZ2V0KCdjb250YWN0JykudGVsZXBob25lLFxuICAgICAgICAgICdlbWFpbCc6IGdldCgnY29udGFjdCcpLmVtYWlsLFxuICAgICAgICAgICdhdmFpbGFibGVMYW5ndWFnZSc6IFsnRW5nbGlzaCcsICdGcmVuY2gnXSxcbiAgICAgICAgICAnaG91cnNBdmFpbGFibGUnOiB7XG4gICAgICAgICAgICAnQHR5cGUnOiAnT3BlbmluZ0hvdXJzU3BlY2lmaWNhdGlvbicsXG4gICAgICAgICAgICAnZGF5T2ZXZWVrJzogZGF5cy52YWx1ZSxcbiAgICAgICAgICAgICdvcGVucyc6ICcwOTowMDowMCcsXG4gICAgICAgICAgICAnY2xvc2VzJzogJzE1OjAwOjAwJ1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgXVxuICAgIH0pXG4gIF1cbilcblxuLyoqXG4gKiBIcmVmIExhbmdcbiAqL1xuXG5jb25zdCBoZWFkID0gdXNlTG9jYWxlSGVhZCh7XG4gIGFkZERpckF0dHJpYnV0ZTogdHJ1ZSxcbiAgYWRkU2VvQXR0cmlidXRlczogdHJ1ZVxufSlcblxudXNlSGVhZCh7XG4gIGh0bWxBdHRyczogeyBsYW5nOiBoZWFkLnZhbHVlLmh0bWxBdHRycz8ubGFuZyB9LFxuICBsaW5rOiBbLi4uKGhlYWQudmFsdWUubGluayB8fCBbXSldLFxuICBtZXRhOiBbLi4uKGhlYWQudmFsdWUubWV0YSB8fCBbXSldXG59KVxuPC9zY3JpcHQ+XG5cbjxzdHlsZSBsYW5nPVwic2Nzc1wiPlxuLnBhZ2Uge1xuXG4gICYtZW50ZXItYWN0aXZlLFxuICAmLWxlYXZlLWFjdGl2ZSB7XG4gICAgdHJhbnNpdGlvbjogYWxsIDAuNHM7XG4gIH1cblxuICAmLWVudGVyLWZyb20sXG4gICYtbGVhdmUtYWN0aXZlIHtcbiAgICBmaWx0ZXI6IGJsdXIoMXJlbSk7XG4gIH1cbn1cbjwvc3R5bGU+XG4iXSwiZmlsZSI6Ii9Wb2x1bWVzL0NvZGluZy9Qcm9qZWN0cy9XZWJzaXRlcy9pbmVpYWgvZnJvbnRlbmQvYXBwL2FwcC52dWUifQ==