/*!
* vue-router v5.2.0
* (c) 2026 Eduardo San Martin Morote
* @license MIT
*/
import { createConsoleReporter, defineDiagnostics } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.cache/vite/client/deps/nostics.js?v=7e73afc2";
import { inject } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
//#region src/utils/index.ts
/**
* Identity function that returns the value as is.
*
* @param v - the value to return
*
* @internal
*/
const identityFn = (v) => v;
/**
* Allows differentiating lazy components from functional components and vue-class-component
* @internal
*
* @param component
*/
function isRouteComponent(component) {
	return typeof component === "object" || "displayName" in component || "props" in component || "__vccOpts" in component;
}
function isESModule(obj) {
	return obj.__esModule || obj[Symbol.toStringTag] === "Module" || obj.default && isRouteComponent(obj.default);
}
const assign = Object.assign;
function applyToParams(fn, params) {
	const newParams = {};
	for (const key in params) {
		const value = params[key];
		newParams[key] = isArray(value) ? value.map(fn) : fn(value);
	}
	return newParams;
}
const noop = () => {};
/**
* Typesafe alternative to Array.isArray
* https://github.com/microsoft/TypeScript/pull/48228
*
* @internal
*/
const isArray = Array.isArray;
function mergeOptions(defaults, partialOptions) {
	const options = {};
	for (const key in defaults) options[key] = key in partialOptions ? partialOptions[key] : defaults[key];
	return options;
}
//#endregion
//#region src/errors.ts
const NavigationFailureSymbol = Symbol("development" !== "production" ? "navigation failure" : "");
/**
* Enumeration with all possible types for navigation failures. Can be passed to
* {@link isNavigationFailure} to check for specific failures.
*/
let NavigationFailureType = /* @__PURE__ */ function(NavigationFailureType) {
	/**
	* An aborted navigation is a navigation that failed because a navigation
	* guard returned `false` or called `next(false)`
	*/
	NavigationFailureType[NavigationFailureType["aborted"] = 4] = "aborted";
	/**
	* A cancelled navigation is a navigation that failed because a more recent
	* navigation finished started (not necessarily finished).
	*/
	NavigationFailureType[NavigationFailureType["cancelled"] = 8] = "cancelled";
	/**
	* A duplicated navigation is a navigation that failed because it was
	* initiated while already being at the exact same location.
	*/
	NavigationFailureType[NavigationFailureType["duplicated"] = 16] = "duplicated";
	return NavigationFailureType;
}({});
const ErrorTypeMessages = {
	[1]({ location, currentLocation }) {
		return `No match for\n ${JSON.stringify(location)}${currentLocation ? "\nwhile being at\n" + JSON.stringify(currentLocation) : ""}`;
	},
	[2]({ from, to }) {
		return `Redirected from "${from.fullPath}" to "${stringifyRoute(to)}" via a navigation guard.`;
	},
	[4]({ from, to }) {
		return `Navigation aborted from "${from.fullPath}" to "${to.fullPath}" via a navigation guard.`;
	},
	[8]({ from, to }) {
		return `Navigation cancelled from "${from.fullPath}" to "${to.fullPath}" with a new navigation.`;
	},
	[16]({ from, to: _to }) {
		return `Avoided redundant navigation to current location: "${from.fullPath}".`;
	}
};
/**
* Creates a typed NavigationFailure object.
* @internal
* @param type - NavigationFailureType
* @param params - { from, to }
*/
function createRouterError(type, params) {
	if ("development" !== "production" || false) return assign(new Error(ErrorTypeMessages[type](params)), {
		type,
		[NavigationFailureSymbol]: true
	}, params);
	else return assign(/* @__PURE__ */ new Error(), {
		type,
		[NavigationFailureSymbol]: true
	}, params);
}
function isNavigationFailure(error, type) {
	return error instanceof Error && NavigationFailureSymbol in error && (type == null || !!(error.type & type));
}
const propertiesToLog = [
	"params",
	"query",
	"hash"
];
/**
* Stringifies a raw location for display in dev warnings.
*
* @internal
*/
function stringifyRoute(to) {
	if (!to || typeof to === "string") return to;
	if (to.path != null) return to.path;
	const location = {};
	for (const key of propertiesToLog) if (key in to) location[key] = to[key];
	return JSON.stringify(location, null, 2);
}
//#endregion
//#region src/diagnostics.ts
/**
* Runtime diagnostics catalog for Vue Router.
*
* Every entry has a stable `VUE_ROUTER_R####` code, a `why` that states the problem
* (the diagnosis only, never the remedy) and a `fix` that states the remedy
* (only, never the diagnosis). They are complementary: the reporter prints
* both, so neither repeats the other. The diagnosis substrings asserted by the
* warning tests stay in `why`. All call sites stay behind the existing `__DEV__` (or
* `process.env.NODE_ENV !== 'production'`) guards and remain bare expression
* statements so they tree-shake out of production builds.
*
* Codes are permanent: never rename or reuse one.
* - `VUE_ROUTER_R0###` core runtime warnings
* - `VUE_ROUTER_R1###` experimental data-loaders
*/
const diagnostics = /*#__PURE__*/ defineDiagnostics({
	reporters: [/*#__PURE__*/ createConsoleReporter()],
	codes: {
		VUE_ROUTER_R0001: {
			why: (p) => `Parent route "${p.name}" not found when adding child route`,
			fix: "Add the parent route before its children, or check the parent name for typos.",
			docs: "https://router.vuejs.org/guide/advanced/dynamic-routing.html#Adding-nested-routes"
		},
		VUE_ROUTER_R0002: {
			why: (p) => `Cannot remove non-existent route "${p.name}"`,
			fix: "Check the route name; it may already have been removed or was never added.",
			docs: "https://router.vuejs.org/guide/advanced/dynamic-routing.html#Removing-routes"
		},
		VUE_ROUTER_R0003: {
			why: (p) => `Location "${stringifyRoute(p.location)}" resolved to "${p.href}". A resolved location cannot start with multiple slashes.`,
			fix: "Remove the leading slashes from the location or fix the route configuration."
		},
		VUE_ROUTER_R0004: {
			why: (p) => `No match found for location with path "${stringifyRoute(p.path)}"`,
			fix: "Add a route matching this path or check for typos in the location.",
			docs: "https://router.vuejs.org/guide/essentials/dynamic-matching.html#Catch-all-404-Not-found-Route"
		},
		VUE_ROUTER_R0005: {
			why: (p) => `router.resolve() was passed an invalid location. This will fail in production.\nLocation: ${stringifyRoute(p.rawLocation)}`,
			fix: "Pass a valid route location: a string path or an object with `path` or `name`."
		},
		VUE_ROUTER_R0006: {
			why: (p) => `Path "${p.path}" was passed with params but they will be ignored because a "path" was passed.`,
			fix: "Use a named route `{ name, params }` instead of `{ path, params }`.",
			docs: "https://router.vuejs.org/guide/essentials/navigation.html#Navigate-to-a-different-location"
		},
		VUE_ROUTER_R0007: {
			why: (p) => `A \`hash\` should always start with the character "#" but received "${p.hash}".`,
			fix: (p) => `Prepend "#" to the hash in your route location: use "#${p.hash}".`
		},
		VUE_ROUTER_R0008: {
			why: (p) => `Invalid redirect found:\n${p.target}\n when navigating to "${p.to}".\nThis will break in production.`,
			fix: "A redirect must resolve to a location with a `name` or `path`; return one of those (or a string path) from `redirect`.",
			docs: "https://router.vuejs.org/guide/essentials/redirect-and-alias.html#Redirect"
		},
		VUE_ROUTER_R0009: {
			why: (p) => `Detected a possibly infinite redirection in a navigation guard when going from "${p.from}" to "${p.to}". Aborting to avoid a Stack Overflow. This might break in production if not fixed.`,
			fix: "A guard is returning a new location on every call; make that return conditional so it only redirects when actually needed.",
			docs: "https://router.vuejs.org/guide/advanced/navigation-guards.html#Global-Before-Guards"
		},
		VUE_ROUTER_R0010: {
			why: "Uncaught error during route navigation",
			fix: "Register an error handler with `router.onError()` to handle navigation errors."
		},
		VUE_ROUTER_R0011: {
			why: "Unexpected error when starting the router:",
			fix: "Inspect the actual cause; a navigation guard or async component likely threw during the initial navigation."
		},
		VUE_ROUTER_R0020: {
			why: (p) => `No active route record was found when calling \`${p.fn}()\`. Maybe you called it inside of App.vue?`,
			fix: "Call it from a component rendered inside <router-view> (a page component or one of its children), not from App.vue.",
			docs: "https://router.vuejs.org/guide/advanced/composition-api.html#Navigation-Guards"
		},
		VUE_ROUTER_R0021: {
			why: "No active route record was found when reactivating component with navigation guard. This is likely a bug in vue-router.",
			fix: "Report with a minimal reproduction at https://github.com/vuejs/router/issues/new/choose."
		},
		VUE_ROUTER_R0022: {
			why: (p) => `${p.fn}() was called outside of component setup but it must be called at the top of a setup function`,
			fix: "Call it synchronously at the top of `setup()`, before any `await`.",
			docs: "https://router.vuejs.org/guide/advanced/composition-api.html#Navigation-Guards"
		},
		VUE_ROUTER_R0023: {
			why: (p) => `The "next" callback was never called inside of ${p.name ? `"${p.name}"` : ""}:\n${p.guard}`,
			fix: "Make sure `next()` runs on every branch, including early returns and async paths, or drop the `next` parameter and return the value instead.",
			docs: "https://router.vuejs.org/guide/advanced/navigation-guards.html#Optional-third-argument-next"
		},
		VUE_ROUTER_R0024: {
			why: (p) => `The "next" callback was called more than once in one navigation guard when going from "${p.from}" to "${p.to}". This will fail in production.`,
			fix: "Call `next()` exactly once per guard: remove the extra call, or migrate to returning the value you passed to `next()`.",
			docs: "https://router.vuejs.org/guide/advanced/navigation-guards.html#Optional-third-argument-next"
		},
		VUE_ROUTER_R0025: {
			why: "The `next()` callback in navigation guards is deprecated.",
			fix: "Return the value instead: `next()` becomes `return`, `next(false)` becomes `return false`, `next(\"/path\")` becomes `return \"/path\"`.",
			docs: "https://router.vuejs.org/guide/advanced/navigation-guards.html#Optional-third-argument-next"
		},
		VUE_ROUTER_R0026: {
			why: (p) => `Record with path "${p.path}" is either missing a "component(s)" or "children" property.`,
			fix: "Add a `component`, `components`, or `children` to the route record.",
			docs: "https://router.vuejs.org/guide/essentials/nested-routes.html"
		},
		VUE_ROUTER_R0027: {
			why: (p) => `Component "${p.name}" in record with path "${p.path}" is not a valid component. Received "${p.received}".`,
			fix: "Pass a component or a function returning a Promise that resolves to one."
		},
		VUE_ROUTER_R0028: {
			why: (p) => `Component "${p.name}" in record with path "${p.path}" is a Promise instead of a function that returns a Promise. This will break in production if not fixed.`,
			fix: `Defer the import in an arrow function so it loads lazily: write "() => import('./MyPage.vue')", not "import('./MyPage.vue')".`,
			docs: "https://router.vuejs.org/guide/advanced/lazy-loading.html"
		},
		VUE_ROUTER_R0029: {
			why: (p) => `Component "${p.name}" in record with path "${p.path}" is defined using "defineAsyncComponent()".`,
			fix: `Drop the wrapper and pass "() => import('./MyPage.vue')" directly; the router handles lazy components itself.`,
			docs: "https://router.vuejs.org/guide/advanced/lazy-loading.html#Relationship-to-async-components"
		},
		VUE_ROUTER_R0030: {
			why: (p) => `Component "${p.name}" in record with path "${p.path}" is a function that does not return a Promise. This will break in production if not fixed.`,
			fix: "Return a dynamic import (`() => import(\"./MyPage.vue\")`) from the function, or add a `displayName` if it is a functional component.",
			docs: "https://router.vuejs.org/guide/advanced/lazy-loading.html"
		},
		VUE_ROUTER_R0040: {
			why: (p) => `Because "${p.el}" starts with "#", scrollBehavior resolves it as an element id via document.getElementById("${p.el.slice(1)}"), not as a CSS selector. No element has that id, but "${p.el}" does match an element with document.querySelector().`,
			fix: (p) => `Resolve the element yourself and return the node: el: document.querySelector('${p.el}').`,
			docs: "https://router.vuejs.org/guide/advanced/scroll-behavior.html"
		},
		VUE_ROUTER_R0041: {
			why: (p) => `The selector "${p.el}" is invalid. See https://mathiasbynens.be/notes/css-escapes or CSS.escape (https://developer.mozilla.org/en-US/docs/Web/API/CSS/escape) for the escaping rules.`,
			fix: "Build an id selector as `#${CSS.escape(id)}` so special characters in the id are escaped.",
			docs: "https://router.vuejs.org/guide/advanced/scroll-behavior.html"
		},
		VUE_ROUTER_R0042: {
			why: (p) => `Couldn't find element using selector "${p.el}" returned by scrollBehavior.`,
			fix: "Return a selector that matches an existing element, or guard against missing elements.",
			docs: "https://router.vuejs.org/guide/advanced/scroll-behavior.html"
		},
		VUE_ROUTER_R0050: {
			why: (p) => {
				let to;
				try {
					to = p.to === void 0 ? "undefined" : JSON.stringify(p.to);
				} catch {
					to = String(p.to);
				}
				return `Invalid value for prop "to" in useLink()\n- to: ${to}`;
			},
			fix: "Pass a valid route location (a string path or an object) to the \"to\" prop."
		},
		VUE_ROUTER_R0060: {
			why: (p) => `<router-view> can no longer be used directly inside <${p.comp}>.`,
			fix: (p) => `Wrap the slot's resolved component with <${p.comp}> instead of nesting <router-view> in it:\n\n<router-view v-slot="{ Component }">\n  <${p.comp}>\n    <component :is="Component" />\n  </${p.comp}>\n</router-view>`,
			docs: "https://router.vuejs.org/guide/advanced/router-view-slot.html#KeepAlive-Transition"
		},
		VUE_ROUTER_R0070: {
			why: (p) => `Cannot resolve a relative location without an absolute path. Trying to resolve "${p.to}" from "${p.from}".`,
			fix: (p) => `Resolve from an absolute \`from\` path that starts with "/", e.g. "/${p.from}".`
		},
		VUE_ROUTER_R0080: {
			why: (p) => `Error decoding "${p.text}". Using original value`,
			fix: "Ensure the value is correctly percent-encoded."
		},
		VUE_ROUTER_R0090: {
			why: (p) => `Found duplicated params with name "${p.name}" for path "${p.path}". Only the last one will be available on "$route.params".`,
			fix: "Give each param a unique name within the path.",
			docs: "https://router.vuejs.org/guide/essentials/route-matching-syntax.html"
		},
		VUE_ROUTER_R0100: {
			why: (p) => `Discarded invalid param(s) "${p.params}" when navigating.` + p.inherited + ` See https://github.com/vuejs/router/commit/e887570 for more details.`,
			fix: "Only pass params that exist on the target route."
		},
		VUE_ROUTER_R0101: {
			why: (p) => `The Matcher cannot resolve relative paths but received "${p.path}". Unless you directly called \`matcher.resolve("${p.path}")\`, this is probably a bug in vue-router. Please open an issue at https://github.com/vuejs/router/issues/new/choose.`,
			fix: "Pass an absolute path (starting with \"/\") to the matcher."
		},
		VUE_ROUTER_R0102: {
			why: (p) => `Alias "${p.alias}" and the original record: "${p.original}" must have the exact same param named "${p.name}"`,
			fix: "Use the same param names in the alias as in the original route.",
			docs: "https://router.vuejs.org/guide/essentials/redirect-and-alias.html#Alias"
		},
		VUE_ROUTER_R0103: {
			why: (p) => `The route named "${p.name}" has a child without a name, an empty path, and no children. Using that name won't render the empty path child, so this is probably a mistake.`,
			fix: "Move the `name` onto the empty-path child; or, if intentional, give the child its own name to silence this.",
			docs: "https://router.vuejs.org/guide/essentials/nested-routes.html#Nested-Named-Routes"
		},
		VUE_ROUTER_R0104: {
			why: (p) => `Absolute path "${p.path}" must have the exact same param named "${p.name}" as its parent "${p.parent}".`,
			fix: "Include the parent route params in the absolute child path.",
			docs: "https://router.vuejs.org/guide/essentials/nested-routes.html"
		},
		VUE_ROUTER_R0105: {
			why: (p) => `Finding ancestor route "${p.ancestor}" failed for "${p.record}"`,
			fix: "Report a reproduction at https://github.com/vuejs/router/issues/new/choose."
		},
		VUE_ROUTER_R0110: {
			why: `A hash base must end with a "#"`,
			fix: (p) => `Append "#" to the "base" argument passed to "createWebHashHistory()": "${p.base}" should be "${p.suggestion}".`
		},
		VUE_ROUTER_R0120: {
			why: "Error with push/replace State",
			fix: "The browser rejected the history API call; check for cross-origin or rate-limit issues."
		},
		VUE_ROUTER_R0121: {
			why: "history.state seems to have been manually replaced without preserving the necessary values.\nYou can find more information at https://router.vuejs.org/guide/migration/#Usage-of-history-state",
			fix: "Merge the router's state into your own when calling it manually: `history.replaceState({ ...history.state, ...yourState }, '', url)`.",
			docs: "https://router.vuejs.org/guide/migration.html#Usage-of-history-state"
		},
		VUE_ROUTER_R1001: {
			why: (p) => `Data loader "${String(p.key)}" has a different parent than the current context. This shouldn't be happening.`,
			fix: "Report a bug with a minimal reproduction at https://github.com/vuejs/router/."
		},
		VUE_ROUTER_R1002: {
			why: "Returning a NavigationResult is deprecated.",
			fix: "Replace `return new NavigationResult(to)` with `reroute(to)`, which throws internally to reroute.",
			docs: "https://router.vuejs.org/data-loaders/navigation-aware.html#Controlling-the-navigation-with-reroute-"
		},
		VUE_ROUTER_R1003: {
			why: (p) => `Loader "${p.key}"'s "commit()" was called but there is no staged data.`,
			fix: "Ensure the loader resolved before calling `commit()`.",
			docs: "https://router.vuejs.org/data-loaders/defining-loaders.html#Delaying-data-updates-with-commit"
		},
		VUE_ROUTER_R1004: {
			why: (p) => "A loader returned a NavigationResult but is not registered on the route." + p.key,
			fix: "Export the loader from the page component so it gets registered, e.g. `export const useUserData = defineLoader(...)`.",
			docs: "https://router.vuejs.org/data-loaders/organization.html"
		},
		VUE_ROUTER_R1005: {
			why: (p) => `Data loader "${p.key}" has itself as parent. This shouldn't be happening.`,
			fix: "Report a bug with a minimal reproduction at https://github.com/vuejs/router/."
		},
		VUE_ROUTER_R1006: {
			why: (p) => `A query was defined with the same key as the loader "[${p.key}]".\nSee https://pinia-colada.esm.dev/#TODO`,
			fix: "If the key is meant to match, use the data loader directly; otherwise rename the `useQuery()` key so it no longer collides.",
			docs: "https://router.vuejs.org/data-loaders/colada.html"
		},
		VUE_ROUTER_R1007: {
			why: "Data Loader was setup twice.",
			fix: "Register `DataLoaderPlugin` a single time via `app.use()`.",
			docs: "https://router.vuejs.org/data-loaders.html#Installation"
		},
		VUE_ROUTER_R1008: {
			why: "Data Loader is experimental and subject to breaking changes in the future.",
			docs: "https://router.vuejs.org/data-loaders.html"
		},
		VUE_ROUTER_R1009: {
			why: "Returning a NavigationResult from a loader is deprecated.",
			fix: "Call `reroute(to)` inside the loader instead of returning `new NavigationResult(to)`; it throws internally to reroute.",
			docs: "https://router.vuejs.org/data-loaders/navigation-aware.html#Controlling-the-navigation-with-reroute-"
		}
	}
});
//#endregion
//#region src/injectionSymbols.ts
/**
* RouteRecord being rendered by the closest ancestor Router View. Used for
* `onBeforeRouteUpdate` and `onBeforeRouteLeave`. rvlm stands for Router View
* Location Matched
*
* @internal
*/
const matchedRouteKey = Symbol("development" !== "production" ? "router view location matched" : "");
/**
* Allows overriding the router view depth to control which component in
* `matched` is rendered. rvd stands for Router View Depth
*
* @internal
*/
const viewDepthKey = Symbol("development" !== "production" ? "router view depth" : "");
/**
* Allows overriding the router instance returned by `useRouter` in tests. r
* stands for router
*
* @internal
*/
const routerKey = Symbol("development" !== "production" ? "router" : "");
/**
* Allows overriding the current route returned by `useRoute` in tests. rl
* stands for route location
*
* @internal
*/
const routeLocationKey = Symbol("development" !== "production" ? "route location" : "");
/**
* Allows overriding the current route used by router-view. Internally this is
* used when the `route` prop is passed.
*
* @internal
*/
const routerViewLocationKey = Symbol("development" !== "production" ? "router view location" : "");
//#endregion
//#region src/useApi.ts
/**
* Returns the router instance. Equivalent to using `$router` inside
* templates.
*/
function useRouter() {
	return inject(routerKey);
}
/**
* Returns the current route location. Equivalent to using `$route` inside
* templates.
*/
function useRoute(_name) {
	return inject(routeLocationKey);
}
//#endregion
export { isRouteComponent as _, routerKey as a, diagnostics as c, isNavigationFailure as d, applyToParams as f, isESModule as g, isArray as h, routeLocationKey as i, NavigationFailureType as l, identityFn as m, useRouter as n, routerViewLocationKey as o, assign as p, matchedRouteKey as r, viewDepthKey as s, useRoute as t, createRouterError as u, mergeOptions as v, noop as y };

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFLQSxTQUFTLHVCQUF1Qix5QkFBeUI7QUFDekQsU0FBUyxjQUFjOzs7Ozs7Ozs7QUFTdkIsTUFBTSxjQUFjLE1BQU07Ozs7Ozs7QUFPMUIsU0FBUyxpQkFBaUIsV0FBVztDQUNwQyxPQUFPLE9BQU8sY0FBYyxZQUFZLGlCQUFpQixhQUFhLFdBQVcsYUFBYSxlQUFlO0FBQzlHO0FBQ0EsU0FBUyxXQUFXLEtBQUs7Q0FDeEIsT0FBTyxJQUFJLGNBQWMsSUFBSSxPQUFPLGlCQUFpQixZQUFZLElBQUksV0FBVyxpQkFBaUIsSUFBSSxPQUFPO0FBQzdHO0FBQ0EsTUFBTSxTQUFTLE9BQU87QUFDdEIsU0FBUyxjQUFjLElBQUksUUFBUTtDQUNsQyxNQUFNLFlBQVksQ0FBQztDQUNuQixLQUFLLE1BQU0sT0FBTyxRQUFRO0VBQ3pCLE1BQU0sUUFBUSxPQUFPO0VBQ3JCLFVBQVUsT0FBTyxRQUFRLEtBQUssSUFBSSxNQUFNLElBQUksRUFBRSxJQUFJLEdBQUcsS0FBSztDQUMzRDtDQUNBLE9BQU87QUFDUjtBQUNBLE1BQU0sYUFBYSxDQUFDOzs7Ozs7O0FBT3BCLE1BQU0sVUFBVSxNQUFNO0FBQ3RCLFNBQVMsYUFBYSxVQUFVLGdCQUFnQjtDQUMvQyxNQUFNLFVBQVUsQ0FBQztDQUNqQixLQUFLLE1BQU0sT0FBTyxVQUFVLFFBQVEsT0FBTyxPQUFPLGlCQUFpQixlQUFlLE9BQU8sU0FBUztDQUNsRyxPQUFPO0FBQ1I7OztBQUdBLE1BQU0sMEJBQTBCLHlCQUFnQyxlQUFlLHVCQUF1QixFQUFFOzs7OztBQUt4RyxJQUFJLHdCQUF3Qyx5QkFBUyx1QkFBdUI7Ozs7O0NBSzNFLHNCQUFzQixzQkFBc0IsYUFBYSxLQUFLOzs7OztDQUs5RCxzQkFBc0Isc0JBQXNCLGVBQWUsS0FBSzs7Ozs7Q0FLaEUsc0JBQXNCLHNCQUFzQixnQkFBZ0IsTUFBTTtDQUNsRSxPQUFPO0FBQ1IsRUFBRSxDQUFDLENBQUM7QUFDSixNQUFNLG9CQUFvQjtDQUN6QixDQUFDLEdBQUcsRUFBRSxVQUFVLG1CQUFtQjtFQUNsQyxPQUFPLGtCQUFrQixLQUFLLFVBQVUsUUFBUSxJQUFJLGtCQUFrQix1QkFBdUIsS0FBSyxVQUFVLGVBQWUsSUFBSTtDQUNoSTtDQUNBLENBQUMsR0FBRyxFQUFFLE1BQU0sTUFBTTtFQUNqQixPQUFPLG9CQUFvQixLQUFLLFNBQVMsUUFBUSxlQUFlLEVBQUUsRUFBRTtDQUNyRTtDQUNBLENBQUMsR0FBRyxFQUFFLE1BQU0sTUFBTTtFQUNqQixPQUFPLDRCQUE0QixLQUFLLFNBQVMsUUFBUSxHQUFHLFNBQVM7Q0FDdEU7Q0FDQSxDQUFDLEdBQUcsRUFBRSxNQUFNLE1BQU07RUFDakIsT0FBTyw4QkFBOEIsS0FBSyxTQUFTLFFBQVEsR0FBRyxTQUFTO0NBQ3hFO0NBQ0EsQ0FBQyxJQUFJLEVBQUUsTUFBTSxJQUFJLE9BQU87RUFDdkIsT0FBTyxzREFBc0QsS0FBSyxTQUFTO0NBQzVFO0FBQ0Q7Ozs7Ozs7QUFPQSxTQUFTLGtCQUFrQixNQUFNLFFBQVE7Q0FDeEMsc0JBQTZCLGdCQUFnQixPQUFPLE9BQU8sT0FBTyxJQUFJLE1BQU0sa0JBQWtCLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRztFQUM3RztHQUNDLDBCQUEwQjtDQUM1QixHQUFHLE1BQU07TUFDSixPQUFPLHVCQUF1QixJQUFJLE1BQU0sR0FBRztFQUMvQztHQUNDLDBCQUEwQjtDQUM1QixHQUFHLE1BQU07QUFDVjtBQUNBLFNBQVMsb0JBQW9CLE9BQU8sTUFBTTtDQUN6QyxPQUFPLGlCQUFpQixTQUFTLDJCQUEyQixVQUFVLFFBQVEsUUFBUSxDQUFDLEVBQUUsTUFBTSxPQUFPO0FBQ3ZHO0FBQ0EsTUFBTSxrQkFBa0I7Q0FDdkI7Q0FDQTtDQUNBO0FBQ0Q7Ozs7OztBQU1BLFNBQVMsZUFBZSxJQUFJO0NBQzNCLElBQUksQ0FBQyxNQUFNLE9BQU8sT0FBTyxVQUFVLE9BQU87Q0FDMUMsSUFBSSxHQUFHLFFBQVEsTUFBTSxPQUFPLEdBQUc7Q0FDL0IsTUFBTSxXQUFXLENBQUM7Q0FDbEIsS0FBSyxNQUFNLE9BQU8saUJBQWlCLElBQUksT0FBTyxJQUFJLFNBQVMsT0FBTyxHQUFHO0NBQ3JFLE9BQU8sS0FBSyxVQUFVLFVBQVUsTUFBTSxDQUFDO0FBQ3hDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFrQkEsTUFBTSxjQUE0QixnQ0FBa0I7Q0FDbkQsV0FBVyxDQUFlLG9DQUFzQixDQUFDO0NBQ2pELE9BQU87RUFDTixrQkFBa0I7R0FDakIsTUFBTSxNQUFNLGlCQUFpQixFQUFFLEtBQUs7R0FDcEMsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0scUNBQXFDLEVBQUUsS0FBSztHQUN4RCxLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxhQUFhLGVBQWUsRUFBRSxRQUFRLEVBQUUsaUJBQWlCLEVBQUUsS0FBSztHQUM1RSxLQUFLO0VBQ047RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLDBDQUEwQyxlQUFlLEVBQUUsSUFBSSxFQUFFO0dBQzdFLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLDZGQUE2RixlQUFlLEVBQUUsV0FBVztHQUNySSxLQUFLO0VBQ047RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLFNBQVMsRUFBRSxLQUFLO0dBQzVCLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLHVFQUF1RSxFQUFFLEtBQUs7R0FDMUYsTUFBTSxNQUFNLHlEQUF5RCxFQUFFLEtBQUs7RUFDN0U7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLDRCQUE0QixFQUFFLE9BQU8seUJBQXlCLEVBQUUsR0FBRztHQUMvRSxLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxtRkFBbUYsRUFBRSxLQUFLLFFBQVEsRUFBRSxHQUFHO0dBQ25ILEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsS0FBSztHQUNMLEtBQUs7RUFDTjtFQUNBLGtCQUFrQjtHQUNqQixLQUFLO0dBQ0wsS0FBSztFQUNOO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxtREFBbUQsRUFBRSxHQUFHO0dBQ3BFLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsS0FBSztHQUNMLEtBQUs7RUFDTjtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0sR0FBRyxFQUFFLEdBQUc7R0FDcEIsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0sa0RBQWtELEVBQUUsT0FBTyxJQUFJLEVBQUUsS0FBSyxLQUFLLEdBQUcsS0FBSyxFQUFFO0dBQ2pHLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLDBGQUEwRixFQUFFLEtBQUssUUFBUSxFQUFFLEdBQUc7R0FDMUgsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixLQUFLO0dBQ0wsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0scUJBQXFCLEVBQUUsS0FBSztHQUN4QyxLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxjQUFjLEVBQUUsS0FBSyx5QkFBeUIsRUFBRSxLQUFLLHdDQUF3QyxFQUFFLFNBQVM7R0FDcEgsS0FBSztFQUNOO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxjQUFjLEVBQUUsS0FBSyx5QkFBeUIsRUFBRSxLQUFLO0dBQ2pFLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLGNBQWMsRUFBRSxLQUFLLHlCQUF5QixFQUFFLEtBQUs7R0FDakUsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0sY0FBYyxFQUFFLEtBQUsseUJBQXlCLEVBQUUsS0FBSztHQUNqRSxLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxZQUFZLEVBQUUsR0FBRyw4RkFBOEYsRUFBRSxHQUFHLE1BQU0sQ0FBQyxFQUFFLDBEQUEwRCxFQUFFLEdBQUc7R0FDeE0sTUFBTSxNQUFNLGlGQUFpRixFQUFFLEdBQUc7R0FDbEcsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxpQkFBaUIsRUFBRSxHQUFHO0dBQ2xDLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLHlDQUF5QyxFQUFFLEdBQUc7R0FDMUQsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU07SUFDWCxJQUFJO0lBQ0osSUFBSTtLQUNILEtBQUssRUFBRSxPQUFPLEtBQUssSUFBSSxjQUFjLEtBQUssVUFBVSxFQUFFLEVBQUU7SUFDekQsUUFBUTtLQUNQLEtBQUssT0FBTyxFQUFFLEVBQUU7SUFDakI7SUFDQSxPQUFPLG1EQUFtRDtHQUMzRDtHQUNBLEtBQUs7RUFDTjtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0sd0RBQXdELEVBQUUsS0FBSztHQUMzRSxNQUFNLE1BQU0sNENBQTRDLEVBQUUsS0FBSyx3RkFBd0YsRUFBRSxLQUFLLDRDQUE0QyxFQUFFLEtBQUs7R0FDak4sTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxtRkFBbUYsRUFBRSxHQUFHLFVBQVUsRUFBRSxLQUFLO0dBQ3JILE1BQU0sTUFBTSx1RUFBdUUsRUFBRSxLQUFLO0VBQzNGO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxtQkFBbUIsRUFBRSxLQUFLO0dBQ3RDLEtBQUs7RUFDTjtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0sc0NBQXNDLEVBQUUsS0FBSyxjQUFjLEVBQUUsS0FBSztHQUM5RSxLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSwrQkFBK0IsRUFBRSxPQUFPLHNCQUFzQixFQUFFLFlBQVk7R0FDeEYsS0FBSztFQUNOO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSwyREFBMkQsRUFBRSxLQUFLLG1EQUFtRCxFQUFFLEtBQUs7R0FDeEksS0FBSztFQUNOO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxVQUFVLEVBQUUsTUFBTSw4QkFBOEIsRUFBRSxTQUFTLDBDQUEwQyxFQUFFLEtBQUs7R0FDeEgsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixNQUFNLE1BQU0sb0JBQW9CLEVBQUUsS0FBSztHQUN2QyxLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxrQkFBa0IsRUFBRSxLQUFLLDBDQUEwQyxFQUFFLEtBQUssbUJBQW1CLEVBQUUsT0FBTztHQUNsSCxLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSwyQkFBMkIsRUFBRSxTQUFTLGdCQUFnQixFQUFFLE9BQU87R0FDM0UsS0FBSztFQUNOO0VBQ0Esa0JBQWtCO0dBQ2pCLEtBQUs7R0FDTCxNQUFNLE1BQU0sMEVBQTBFLEVBQUUsS0FBSyxlQUFlLEVBQUUsV0FBVztFQUMxSDtFQUNBLGtCQUFrQjtHQUNqQixLQUFLO0dBQ0wsS0FBSztFQUNOO0VBQ0Esa0JBQWtCO0dBQ2pCLEtBQUs7R0FDTCxLQUFLO0dBQ0wsTUFBTTtFQUNQO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSxnQkFBZ0IsT0FBTyxFQUFFLEdBQUcsRUFBRTtHQUMxQyxLQUFLO0VBQ047RUFDQSxrQkFBa0I7R0FDakIsS0FBSztHQUNMLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLFdBQVcsRUFBRSxJQUFJO0dBQzdCLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLDZFQUE2RSxFQUFFO0dBQzNGLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsTUFBTSxNQUFNLGdCQUFnQixFQUFFLElBQUk7R0FDbEMsS0FBSztFQUNOO0VBQ0Esa0JBQWtCO0dBQ2pCLE1BQU0sTUFBTSx5REFBeUQsRUFBRSxJQUFJO0dBQzNFLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsS0FBSztHQUNMLEtBQUs7R0FDTCxNQUFNO0VBQ1A7RUFDQSxrQkFBa0I7R0FDakIsS0FBSztHQUNMLE1BQU07RUFDUDtFQUNBLGtCQUFrQjtHQUNqQixLQUFLO0dBQ0wsS0FBSztHQUNMLE1BQU07RUFDUDtDQUNEO0FBQ0QsQ0FBQzs7Ozs7Ozs7OztBQVVELE1BQU0sa0JBQWtCLHlCQUFnQyxlQUFlLGlDQUFpQyxFQUFFOzs7Ozs7O0FBTzFHLE1BQU0sZUFBZSx5QkFBZ0MsZUFBZSxzQkFBc0IsRUFBRTs7Ozs7OztBQU81RixNQUFNLFlBQVkseUJBQWdDLGVBQWUsV0FBVyxFQUFFOzs7Ozs7O0FBTzlFLE1BQU0sbUJBQW1CLHlCQUFnQyxlQUFlLG1CQUFtQixFQUFFOzs7Ozs7O0FBTzdGLE1BQU0sd0JBQXdCLHlCQUFnQyxlQUFlLHlCQUF5QixFQUFFOzs7Ozs7O0FBT3hHLFNBQVMsWUFBWTtDQUNwQixPQUFPLE9BQU8sU0FBUztBQUN4Qjs7Ozs7QUFLQSxTQUFTLFNBQVMsT0FBTztDQUN4QixPQUFPLE9BQU8sZ0JBQWdCO0FBQy9COztBQUVBLFNBQVMsb0JBQW9CLEdBQUcsYUFBYSxHQUFHLGVBQWUsR0FBRyx1QkFBdUIsR0FBRyxpQkFBaUIsR0FBRyxjQUFjLEdBQUcsV0FBVyxHQUFHLG9CQUFvQixHQUFHLHlCQUF5QixHQUFHLGNBQWMsR0FBRyxhQUFhLEdBQUcseUJBQXlCLEdBQUcsVUFBVSxHQUFHLG1CQUFtQixHQUFHLGdCQUFnQixHQUFHLFlBQVksR0FBRyxxQkFBcUIsR0FBRyxnQkFBZ0IsR0FBRyxRQUFRIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInVzZUFwaS1DUk9KSmRoRS5qcz92PTdlNzNhZmMyIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuKiB2dWUtcm91dGVyIHY1LjIuMFxuKiAoYykgMjAyNiBFZHVhcmRvIFNhbiBNYXJ0aW4gTW9yb3RlXG4qIEBsaWNlbnNlIE1JVFxuKi9cbmltcG9ydCB7IGNyZWF0ZUNvbnNvbGVSZXBvcnRlciwgZGVmaW5lRGlhZ25vc3RpY3MgfSBmcm9tIFwibm9zdGljc1wiO1xuaW1wb3J0IHsgaW5qZWN0IH0gZnJvbSBcInZ1ZVwiO1xuLy8jcmVnaW9uIHNyYy91dGlscy9pbmRleC50c1xuLyoqXG4qIElkZW50aXR5IGZ1bmN0aW9uIHRoYXQgcmV0dXJucyB0aGUgdmFsdWUgYXMgaXMuXG4qXG4qIEBwYXJhbSB2IC0gdGhlIHZhbHVlIHRvIHJldHVyblxuKlxuKiBAaW50ZXJuYWxcbiovXG5jb25zdCBpZGVudGl0eUZuID0gKHYpID0+IHY7XG4vKipcbiogQWxsb3dzIGRpZmZlcmVudGlhdGluZyBsYXp5IGNvbXBvbmVudHMgZnJvbSBmdW5jdGlvbmFsIGNvbXBvbmVudHMgYW5kIHZ1ZS1jbGFzcy1jb21wb25lbnRcbiogQGludGVybmFsXG4qXG4qIEBwYXJhbSBjb21wb25lbnRcbiovXG5mdW5jdGlvbiBpc1JvdXRlQ29tcG9uZW50KGNvbXBvbmVudCkge1xuXHRyZXR1cm4gdHlwZW9mIGNvbXBvbmVudCA9PT0gXCJvYmplY3RcIiB8fCBcImRpc3BsYXlOYW1lXCIgaW4gY29tcG9uZW50IHx8IFwicHJvcHNcIiBpbiBjb21wb25lbnQgfHwgXCJfX3ZjY09wdHNcIiBpbiBjb21wb25lbnQ7XG59XG5mdW5jdGlvbiBpc0VTTW9kdWxlKG9iaikge1xuXHRyZXR1cm4gb2JqLl9fZXNNb2R1bGUgfHwgb2JqW1N5bWJvbC50b1N0cmluZ1RhZ10gPT09IFwiTW9kdWxlXCIgfHwgb2JqLmRlZmF1bHQgJiYgaXNSb3V0ZUNvbXBvbmVudChvYmouZGVmYXVsdCk7XG59XG5jb25zdCBhc3NpZ24gPSBPYmplY3QuYXNzaWduO1xuZnVuY3Rpb24gYXBwbHlUb1BhcmFtcyhmbiwgcGFyYW1zKSB7XG5cdGNvbnN0IG5ld1BhcmFtcyA9IHt9O1xuXHRmb3IgKGNvbnN0IGtleSBpbiBwYXJhbXMpIHtcblx0XHRjb25zdCB2YWx1ZSA9IHBhcmFtc1trZXldO1xuXHRcdG5ld1BhcmFtc1trZXldID0gaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZS5tYXAoZm4pIDogZm4odmFsdWUpO1xuXHR9XG5cdHJldHVybiBuZXdQYXJhbXM7XG59XG5jb25zdCBub29wID0gKCkgPT4ge307XG4vKipcbiogVHlwZXNhZmUgYWx0ZXJuYXRpdmUgdG8gQXJyYXkuaXNBcnJheVxuKiBodHRwczovL2dpdGh1Yi5jb20vbWljcm9zb2Z0L1R5cGVTY3JpcHQvcHVsbC80ODIyOFxuKlxuKiBAaW50ZXJuYWxcbiovXG5jb25zdCBpc0FycmF5ID0gQXJyYXkuaXNBcnJheTtcbmZ1bmN0aW9uIG1lcmdlT3B0aW9ucyhkZWZhdWx0cywgcGFydGlhbE9wdGlvbnMpIHtcblx0Y29uc3Qgb3B0aW9ucyA9IHt9O1xuXHRmb3IgKGNvbnN0IGtleSBpbiBkZWZhdWx0cykgb3B0aW9uc1trZXldID0ga2V5IGluIHBhcnRpYWxPcHRpb25zID8gcGFydGlhbE9wdGlvbnNba2V5XSA6IGRlZmF1bHRzW2tleV07XG5cdHJldHVybiBvcHRpb25zO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2Vycm9ycy50c1xuY29uc3QgTmF2aWdhdGlvbkZhaWx1cmVTeW1ib2wgPSBTeW1ib2wocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gXCJuYXZpZ2F0aW9uIGZhaWx1cmVcIiA6IFwiXCIpO1xuLyoqXG4qIEVudW1lcmF0aW9uIHdpdGggYWxsIHBvc3NpYmxlIHR5cGVzIGZvciBuYXZpZ2F0aW9uIGZhaWx1cmVzLiBDYW4gYmUgcGFzc2VkIHRvXG4qIHtAbGluayBpc05hdmlnYXRpb25GYWlsdXJlfSB0byBjaGVjayBmb3Igc3BlY2lmaWMgZmFpbHVyZXMuXG4qL1xubGV0IE5hdmlnYXRpb25GYWlsdXJlVHlwZSA9IC8qIEBfX1BVUkVfXyAqLyBmdW5jdGlvbihOYXZpZ2F0aW9uRmFpbHVyZVR5cGUpIHtcblx0LyoqXG5cdCogQW4gYWJvcnRlZCBuYXZpZ2F0aW9uIGlzIGEgbmF2aWdhdGlvbiB0aGF0IGZhaWxlZCBiZWNhdXNlIGEgbmF2aWdhdGlvblxuXHQqIGd1YXJkIHJldHVybmVkIGBmYWxzZWAgb3IgY2FsbGVkIGBuZXh0KGZhbHNlKWBcblx0Ki9cblx0TmF2aWdhdGlvbkZhaWx1cmVUeXBlW05hdmlnYXRpb25GYWlsdXJlVHlwZVtcImFib3J0ZWRcIl0gPSA0XSA9IFwiYWJvcnRlZFwiO1xuXHQvKipcblx0KiBBIGNhbmNlbGxlZCBuYXZpZ2F0aW9uIGlzIGEgbmF2aWdhdGlvbiB0aGF0IGZhaWxlZCBiZWNhdXNlIGEgbW9yZSByZWNlbnRcblx0KiBuYXZpZ2F0aW9uIGZpbmlzaGVkIHN0YXJ0ZWQgKG5vdCBuZWNlc3NhcmlseSBmaW5pc2hlZCkuXG5cdCovXG5cdE5hdmlnYXRpb25GYWlsdXJlVHlwZVtOYXZpZ2F0aW9uRmFpbHVyZVR5cGVbXCJjYW5jZWxsZWRcIl0gPSA4XSA9IFwiY2FuY2VsbGVkXCI7XG5cdC8qKlxuXHQqIEEgZHVwbGljYXRlZCBuYXZpZ2F0aW9uIGlzIGEgbmF2aWdhdGlvbiB0aGF0IGZhaWxlZCBiZWNhdXNlIGl0IHdhc1xuXHQqIGluaXRpYXRlZCB3aGlsZSBhbHJlYWR5IGJlaW5nIGF0IHRoZSBleGFjdCBzYW1lIGxvY2F0aW9uLlxuXHQqL1xuXHROYXZpZ2F0aW9uRmFpbHVyZVR5cGVbTmF2aWdhdGlvbkZhaWx1cmVUeXBlW1wiZHVwbGljYXRlZFwiXSA9IDE2XSA9IFwiZHVwbGljYXRlZFwiO1xuXHRyZXR1cm4gTmF2aWdhdGlvbkZhaWx1cmVUeXBlO1xufSh7fSk7XG5jb25zdCBFcnJvclR5cGVNZXNzYWdlcyA9IHtcblx0WzFdKHsgbG9jYXRpb24sIGN1cnJlbnRMb2NhdGlvbiB9KSB7XG5cdFx0cmV0dXJuIGBObyBtYXRjaCBmb3JcXG4gJHtKU09OLnN0cmluZ2lmeShsb2NhdGlvbil9JHtjdXJyZW50TG9jYXRpb24gPyBcIlxcbndoaWxlIGJlaW5nIGF0XFxuXCIgKyBKU09OLnN0cmluZ2lmeShjdXJyZW50TG9jYXRpb24pIDogXCJcIn1gO1xuXHR9LFxuXHRbMl0oeyBmcm9tLCB0byB9KSB7XG5cdFx0cmV0dXJuIGBSZWRpcmVjdGVkIGZyb20gXCIke2Zyb20uZnVsbFBhdGh9XCIgdG8gXCIke3N0cmluZ2lmeVJvdXRlKHRvKX1cIiB2aWEgYSBuYXZpZ2F0aW9uIGd1YXJkLmA7XG5cdH0sXG5cdFs0XSh7IGZyb20sIHRvIH0pIHtcblx0XHRyZXR1cm4gYE5hdmlnYXRpb24gYWJvcnRlZCBmcm9tIFwiJHtmcm9tLmZ1bGxQYXRofVwiIHRvIFwiJHt0by5mdWxsUGF0aH1cIiB2aWEgYSBuYXZpZ2F0aW9uIGd1YXJkLmA7XG5cdH0sXG5cdFs4XSh7IGZyb20sIHRvIH0pIHtcblx0XHRyZXR1cm4gYE5hdmlnYXRpb24gY2FuY2VsbGVkIGZyb20gXCIke2Zyb20uZnVsbFBhdGh9XCIgdG8gXCIke3RvLmZ1bGxQYXRofVwiIHdpdGggYSBuZXcgbmF2aWdhdGlvbi5gO1xuXHR9LFxuXHRbMTZdKHsgZnJvbSwgdG86IF90byB9KSB7XG5cdFx0cmV0dXJuIGBBdm9pZGVkIHJlZHVuZGFudCBuYXZpZ2F0aW9uIHRvIGN1cnJlbnQgbG9jYXRpb246IFwiJHtmcm9tLmZ1bGxQYXRofVwiLmA7XG5cdH1cbn07XG4vKipcbiogQ3JlYXRlcyBhIHR5cGVkIE5hdmlnYXRpb25GYWlsdXJlIG9iamVjdC5cbiogQGludGVybmFsXG4qIEBwYXJhbSB0eXBlIC0gTmF2aWdhdGlvbkZhaWx1cmVUeXBlXG4qIEBwYXJhbSBwYXJhbXMgLSB7IGZyb20sIHRvIH1cbiovXG5mdW5jdGlvbiBjcmVhdGVSb3V0ZXJFcnJvcih0eXBlLCBwYXJhbXMpIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiB8fCBmYWxzZSkgcmV0dXJuIGFzc2lnbihuZXcgRXJyb3IoRXJyb3JUeXBlTWVzc2FnZXNbdHlwZV0ocGFyYW1zKSksIHtcblx0XHR0eXBlLFxuXHRcdFtOYXZpZ2F0aW9uRmFpbHVyZVN5bWJvbF06IHRydWVcblx0fSwgcGFyYW1zKTtcblx0ZWxzZSByZXR1cm4gYXNzaWduKC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoKSwge1xuXHRcdHR5cGUsXG5cdFx0W05hdmlnYXRpb25GYWlsdXJlU3ltYm9sXTogdHJ1ZVxuXHR9LCBwYXJhbXMpO1xufVxuZnVuY3Rpb24gaXNOYXZpZ2F0aW9uRmFpbHVyZShlcnJvciwgdHlwZSkge1xuXHRyZXR1cm4gZXJyb3IgaW5zdGFuY2VvZiBFcnJvciAmJiBOYXZpZ2F0aW9uRmFpbHVyZVN5bWJvbCBpbiBlcnJvciAmJiAodHlwZSA9PSBudWxsIHx8ICEhKGVycm9yLnR5cGUgJiB0eXBlKSk7XG59XG5jb25zdCBwcm9wZXJ0aWVzVG9Mb2cgPSBbXG5cdFwicGFyYW1zXCIsXG5cdFwicXVlcnlcIixcblx0XCJoYXNoXCJcbl07XG4vKipcbiogU3RyaW5naWZpZXMgYSByYXcgbG9jYXRpb24gZm9yIGRpc3BsYXkgaW4gZGV2IHdhcm5pbmdzLlxuKlxuKiBAaW50ZXJuYWxcbiovXG5mdW5jdGlvbiBzdHJpbmdpZnlSb3V0ZSh0bykge1xuXHRpZiAoIXRvIHx8IHR5cGVvZiB0byA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIHRvO1xuXHRpZiAodG8ucGF0aCAhPSBudWxsKSByZXR1cm4gdG8ucGF0aDtcblx0Y29uc3QgbG9jYXRpb24gPSB7fTtcblx0Zm9yIChjb25zdCBrZXkgb2YgcHJvcGVydGllc1RvTG9nKSBpZiAoa2V5IGluIHRvKSBsb2NhdGlvbltrZXldID0gdG9ba2V5XTtcblx0cmV0dXJuIEpTT04uc3RyaW5naWZ5KGxvY2F0aW9uLCBudWxsLCAyKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9kaWFnbm9zdGljcy50c1xuLyoqXG4qIFJ1bnRpbWUgZGlhZ25vc3RpY3MgY2F0YWxvZyBmb3IgVnVlIFJvdXRlci5cbipcbiogRXZlcnkgZW50cnkgaGFzIGEgc3RhYmxlIGBWVUVfUk9VVEVSX1IjIyMjYCBjb2RlLCBhIGB3aHlgIHRoYXQgc3RhdGVzIHRoZSBwcm9ibGVtXG4qICh0aGUgZGlhZ25vc2lzIG9ubHksIG5ldmVyIHRoZSByZW1lZHkpIGFuZCBhIGBmaXhgIHRoYXQgc3RhdGVzIHRoZSByZW1lZHlcbiogKG9ubHksIG5ldmVyIHRoZSBkaWFnbm9zaXMpLiBUaGV5IGFyZSBjb21wbGVtZW50YXJ5OiB0aGUgcmVwb3J0ZXIgcHJpbnRzXG4qIGJvdGgsIHNvIG5laXRoZXIgcmVwZWF0cyB0aGUgb3RoZXIuIFRoZSBkaWFnbm9zaXMgc3Vic3RyaW5ncyBhc3NlcnRlZCBieSB0aGVcbiogd2FybmluZyB0ZXN0cyBzdGF5IGluIGB3aHlgLiBBbGwgY2FsbCBzaXRlcyBzdGF5IGJlaGluZCB0aGUgZXhpc3RpbmcgYF9fREVWX19gIChvclxuKiBgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJ2ApIGd1YXJkcyBhbmQgcmVtYWluIGJhcmUgZXhwcmVzc2lvblxuKiBzdGF0ZW1lbnRzIHNvIHRoZXkgdHJlZS1zaGFrZSBvdXQgb2YgcHJvZHVjdGlvbiBidWlsZHMuXG4qXG4qIENvZGVzIGFyZSBwZXJtYW5lbnQ6IG5ldmVyIHJlbmFtZSBvciByZXVzZSBvbmUuXG4qIC0gYFZVRV9ST1VURVJfUjAjIyNgIGNvcmUgcnVudGltZSB3YXJuaW5nc1xuKiAtIGBWVUVfUk9VVEVSX1IxIyMjYCBleHBlcmltZW50YWwgZGF0YS1sb2FkZXJzXG4qL1xuY29uc3QgZGlhZ25vc3RpY3MgPSAvKiNfX1BVUkVfXyovIGRlZmluZURpYWdub3N0aWNzKHtcblx0cmVwb3J0ZXJzOiBbLyojX19QVVJFX18qLyBjcmVhdGVDb25zb2xlUmVwb3J0ZXIoKV0sXG5cdGNvZGVzOiB7XG5cdFx0VlVFX1JPVVRFUl9SMDAwMToge1xuXHRcdFx0d2h5OiAocCkgPT4gYFBhcmVudCByb3V0ZSBcIiR7cC5uYW1lfVwiIG5vdCBmb3VuZCB3aGVuIGFkZGluZyBjaGlsZCByb3V0ZWAsXG5cdFx0XHRmaXg6IFwiQWRkIHRoZSBwYXJlbnQgcm91dGUgYmVmb3JlIGl0cyBjaGlsZHJlbiwgb3IgY2hlY2sgdGhlIHBhcmVudCBuYW1lIGZvciB0eXBvcy5cIixcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL2FkdmFuY2VkL2R5bmFtaWMtcm91dGluZy5odG1sI0FkZGluZy1uZXN0ZWQtcm91dGVzXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMDI6IHtcblx0XHRcdHdoeTogKHApID0+IGBDYW5ub3QgcmVtb3ZlIG5vbi1leGlzdGVudCByb3V0ZSBcIiR7cC5uYW1lfVwiYCxcblx0XHRcdGZpeDogXCJDaGVjayB0aGUgcm91dGUgbmFtZTsgaXQgbWF5IGFscmVhZHkgaGF2ZSBiZWVuIHJlbW92ZWQgb3Igd2FzIG5ldmVyIGFkZGVkLlwiLFxuXHRcdFx0ZG9jczogXCJodHRwczovL3JvdXRlci52dWVqcy5vcmcvZ3VpZGUvYWR2YW5jZWQvZHluYW1pYy1yb3V0aW5nLmh0bWwjUmVtb3Zpbmctcm91dGVzXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMDM6IHtcblx0XHRcdHdoeTogKHApID0+IGBMb2NhdGlvbiBcIiR7c3RyaW5naWZ5Um91dGUocC5sb2NhdGlvbil9XCIgcmVzb2x2ZWQgdG8gXCIke3AuaHJlZn1cIi4gQSByZXNvbHZlZCBsb2NhdGlvbiBjYW5ub3Qgc3RhcnQgd2l0aCBtdWx0aXBsZSBzbGFzaGVzLmAsXG5cdFx0XHRmaXg6IFwiUmVtb3ZlIHRoZSBsZWFkaW5nIHNsYXNoZXMgZnJvbSB0aGUgbG9jYXRpb24gb3IgZml4IHRoZSByb3V0ZSBjb25maWd1cmF0aW9uLlwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDA0OiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgTm8gbWF0Y2ggZm91bmQgZm9yIGxvY2F0aW9uIHdpdGggcGF0aCBcIiR7c3RyaW5naWZ5Um91dGUocC5wYXRoKX1cImAsXG5cdFx0XHRmaXg6IFwiQWRkIGEgcm91dGUgbWF0Y2hpbmcgdGhpcyBwYXRoIG9yIGNoZWNrIGZvciB0eXBvcyBpbiB0aGUgbG9jYXRpb24uXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9lc3NlbnRpYWxzL2R5bmFtaWMtbWF0Y2hpbmcuaHRtbCNDYXRjaC1hbGwtNDA0LU5vdC1mb3VuZC1Sb3V0ZVwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDA1OiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgcm91dGVyLnJlc29sdmUoKSB3YXMgcGFzc2VkIGFuIGludmFsaWQgbG9jYXRpb24uIFRoaXMgd2lsbCBmYWlsIGluIHByb2R1Y3Rpb24uXFxuTG9jYXRpb246ICR7c3RyaW5naWZ5Um91dGUocC5yYXdMb2NhdGlvbil9YCxcblx0XHRcdGZpeDogXCJQYXNzIGEgdmFsaWQgcm91dGUgbG9jYXRpb246IGEgc3RyaW5nIHBhdGggb3IgYW4gb2JqZWN0IHdpdGggYHBhdGhgIG9yIGBuYW1lYC5cIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDAwNjoge1xuXHRcdFx0d2h5OiAocCkgPT4gYFBhdGggXCIke3AucGF0aH1cIiB3YXMgcGFzc2VkIHdpdGggcGFyYW1zIGJ1dCB0aGV5IHdpbGwgYmUgaWdub3JlZCBiZWNhdXNlIGEgXCJwYXRoXCIgd2FzIHBhc3NlZC5gLFxuXHRcdFx0Zml4OiBcIlVzZSBhIG5hbWVkIHJvdXRlIGB7IG5hbWUsIHBhcmFtcyB9YCBpbnN0ZWFkIG9mIGB7IHBhdGgsIHBhcmFtcyB9YC5cIixcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL2Vzc2VudGlhbHMvbmF2aWdhdGlvbi5odG1sI05hdmlnYXRlLXRvLWEtZGlmZmVyZW50LWxvY2F0aW9uXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMDc6IHtcblx0XHRcdHdoeTogKHApID0+IGBBIFxcYGhhc2hcXGAgc2hvdWxkIGFsd2F5cyBzdGFydCB3aXRoIHRoZSBjaGFyYWN0ZXIgXCIjXCIgYnV0IHJlY2VpdmVkIFwiJHtwLmhhc2h9XCIuYCxcblx0XHRcdGZpeDogKHApID0+IGBQcmVwZW5kIFwiI1wiIHRvIHRoZSBoYXNoIGluIHlvdXIgcm91dGUgbG9jYXRpb246IHVzZSBcIiMke3AuaGFzaH1cIi5gXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDA4OiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgSW52YWxpZCByZWRpcmVjdCBmb3VuZDpcXG4ke3AudGFyZ2V0fVxcbiB3aGVuIG5hdmlnYXRpbmcgdG8gXCIke3AudG99XCIuXFxuVGhpcyB3aWxsIGJyZWFrIGluIHByb2R1Y3Rpb24uYCxcblx0XHRcdGZpeDogXCJBIHJlZGlyZWN0IG11c3QgcmVzb2x2ZSB0byBhIGxvY2F0aW9uIHdpdGggYSBgbmFtZWAgb3IgYHBhdGhgOyByZXR1cm4gb25lIG9mIHRob3NlIChvciBhIHN0cmluZyBwYXRoKSBmcm9tIGByZWRpcmVjdGAuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9lc3NlbnRpYWxzL3JlZGlyZWN0LWFuZC1hbGlhcy5odG1sI1JlZGlyZWN0XCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMDk6IHtcblx0XHRcdHdoeTogKHApID0+IGBEZXRlY3RlZCBhIHBvc3NpYmx5IGluZmluaXRlIHJlZGlyZWN0aW9uIGluIGEgbmF2aWdhdGlvbiBndWFyZCB3aGVuIGdvaW5nIGZyb20gXCIke3AuZnJvbX1cIiB0byBcIiR7cC50b31cIi4gQWJvcnRpbmcgdG8gYXZvaWQgYSBTdGFjayBPdmVyZmxvdy4gVGhpcyBtaWdodCBicmVhayBpbiBwcm9kdWN0aW9uIGlmIG5vdCBmaXhlZC5gLFxuXHRcdFx0Zml4OiBcIkEgZ3VhcmQgaXMgcmV0dXJuaW5nIGEgbmV3IGxvY2F0aW9uIG9uIGV2ZXJ5IGNhbGw7IG1ha2UgdGhhdCByZXR1cm4gY29uZGl0aW9uYWwgc28gaXQgb25seSByZWRpcmVjdHMgd2hlbiBhY3R1YWxseSBuZWVkZWQuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9hZHZhbmNlZC9uYXZpZ2F0aW9uLWd1YXJkcy5odG1sI0dsb2JhbC1CZWZvcmUtR3VhcmRzXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMTA6IHtcblx0XHRcdHdoeTogXCJVbmNhdWdodCBlcnJvciBkdXJpbmcgcm91dGUgbmF2aWdhdGlvblwiLFxuXHRcdFx0Zml4OiBcIlJlZ2lzdGVyIGFuIGVycm9yIGhhbmRsZXIgd2l0aCBgcm91dGVyLm9uRXJyb3IoKWAgdG8gaGFuZGxlIG5hdmlnYXRpb24gZXJyb3JzLlwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDExOiB7XG5cdFx0XHR3aHk6IFwiVW5leHBlY3RlZCBlcnJvciB3aGVuIHN0YXJ0aW5nIHRoZSByb3V0ZXI6XCIsXG5cdFx0XHRmaXg6IFwiSW5zcGVjdCB0aGUgYWN0dWFsIGNhdXNlOyBhIG5hdmlnYXRpb24gZ3VhcmQgb3IgYXN5bmMgY29tcG9uZW50IGxpa2VseSB0aHJldyBkdXJpbmcgdGhlIGluaXRpYWwgbmF2aWdhdGlvbi5cIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDAyMDoge1xuXHRcdFx0d2h5OiAocCkgPT4gYE5vIGFjdGl2ZSByb3V0ZSByZWNvcmQgd2FzIGZvdW5kIHdoZW4gY2FsbGluZyBcXGAke3AuZm59KClcXGAuIE1heWJlIHlvdSBjYWxsZWQgaXQgaW5zaWRlIG9mIEFwcC52dWU/YCxcblx0XHRcdGZpeDogXCJDYWxsIGl0IGZyb20gYSBjb21wb25lbnQgcmVuZGVyZWQgaW5zaWRlIDxyb3V0ZXItdmlldz4gKGEgcGFnZSBjb21wb25lbnQgb3Igb25lIG9mIGl0cyBjaGlsZHJlbiksIG5vdCBmcm9tIEFwcC52dWUuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9hZHZhbmNlZC9jb21wb3NpdGlvbi1hcGkuaHRtbCNOYXZpZ2F0aW9uLUd1YXJkc1wiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDIxOiB7XG5cdFx0XHR3aHk6IFwiTm8gYWN0aXZlIHJvdXRlIHJlY29yZCB3YXMgZm91bmQgd2hlbiByZWFjdGl2YXRpbmcgY29tcG9uZW50IHdpdGggbmF2aWdhdGlvbiBndWFyZC4gVGhpcyBpcyBsaWtlbHkgYSBidWcgaW4gdnVlLXJvdXRlci5cIixcblx0XHRcdGZpeDogXCJSZXBvcnQgd2l0aCBhIG1pbmltYWwgcmVwcm9kdWN0aW9uIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS92dWVqcy9yb3V0ZXIvaXNzdWVzL25ldy9jaG9vc2UuXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMjI6IHtcblx0XHRcdHdoeTogKHApID0+IGAke3AuZm59KCkgd2FzIGNhbGxlZCBvdXRzaWRlIG9mIGNvbXBvbmVudCBzZXR1cCBidXQgaXQgbXVzdCBiZSBjYWxsZWQgYXQgdGhlIHRvcCBvZiBhIHNldHVwIGZ1bmN0aW9uYCxcblx0XHRcdGZpeDogXCJDYWxsIGl0IHN5bmNocm9ub3VzbHkgYXQgdGhlIHRvcCBvZiBgc2V0dXAoKWAsIGJlZm9yZSBhbnkgYGF3YWl0YC5cIixcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL2FkdmFuY2VkL2NvbXBvc2l0aW9uLWFwaS5odG1sI05hdmlnYXRpb24tR3VhcmRzXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMjM6IHtcblx0XHRcdHdoeTogKHApID0+IGBUaGUgXCJuZXh0XCIgY2FsbGJhY2sgd2FzIG5ldmVyIGNhbGxlZCBpbnNpZGUgb2YgJHtwLm5hbWUgPyBgXCIke3AubmFtZX1cImAgOiBcIlwifTpcXG4ke3AuZ3VhcmR9YCxcblx0XHRcdGZpeDogXCJNYWtlIHN1cmUgYG5leHQoKWAgcnVucyBvbiBldmVyeSBicmFuY2gsIGluY2x1ZGluZyBlYXJseSByZXR1cm5zIGFuZCBhc3luYyBwYXRocywgb3IgZHJvcCB0aGUgYG5leHRgIHBhcmFtZXRlciBhbmQgcmV0dXJuIHRoZSB2YWx1ZSBpbnN0ZWFkLlwiLFxuXHRcdFx0ZG9jczogXCJodHRwczovL3JvdXRlci52dWVqcy5vcmcvZ3VpZGUvYWR2YW5jZWQvbmF2aWdhdGlvbi1ndWFyZHMuaHRtbCNPcHRpb25hbC10aGlyZC1hcmd1bWVudC1uZXh0XCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMjQ6IHtcblx0XHRcdHdoeTogKHApID0+IGBUaGUgXCJuZXh0XCIgY2FsbGJhY2sgd2FzIGNhbGxlZCBtb3JlIHRoYW4gb25jZSBpbiBvbmUgbmF2aWdhdGlvbiBndWFyZCB3aGVuIGdvaW5nIGZyb20gXCIke3AuZnJvbX1cIiB0byBcIiR7cC50b31cIi4gVGhpcyB3aWxsIGZhaWwgaW4gcHJvZHVjdGlvbi5gLFxuXHRcdFx0Zml4OiBcIkNhbGwgYG5leHQoKWAgZXhhY3RseSBvbmNlIHBlciBndWFyZDogcmVtb3ZlIHRoZSBleHRyYSBjYWxsLCBvciBtaWdyYXRlIHRvIHJldHVybmluZyB0aGUgdmFsdWUgeW91IHBhc3NlZCB0byBgbmV4dCgpYC5cIixcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL2FkdmFuY2VkL25hdmlnYXRpb24tZ3VhcmRzLmh0bWwjT3B0aW9uYWwtdGhpcmQtYXJndW1lbnQtbmV4dFwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDI1OiB7XG5cdFx0XHR3aHk6IFwiVGhlIGBuZXh0KClgIGNhbGxiYWNrIGluIG5hdmlnYXRpb24gZ3VhcmRzIGlzIGRlcHJlY2F0ZWQuXCIsXG5cdFx0XHRmaXg6IFwiUmV0dXJuIHRoZSB2YWx1ZSBpbnN0ZWFkOiBgbmV4dCgpYCBiZWNvbWVzIGByZXR1cm5gLCBgbmV4dChmYWxzZSlgIGJlY29tZXMgYHJldHVybiBmYWxzZWAsIGBuZXh0KFxcXCIvcGF0aFxcXCIpYCBiZWNvbWVzIGByZXR1cm4gXFxcIi9wYXRoXFxcImAuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9hZHZhbmNlZC9uYXZpZ2F0aW9uLWd1YXJkcy5odG1sI09wdGlvbmFsLXRoaXJkLWFyZ3VtZW50LW5leHRcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDAyNjoge1xuXHRcdFx0d2h5OiAocCkgPT4gYFJlY29yZCB3aXRoIHBhdGggXCIke3AucGF0aH1cIiBpcyBlaXRoZXIgbWlzc2luZyBhIFwiY29tcG9uZW50KHMpXCIgb3IgXCJjaGlsZHJlblwiIHByb3BlcnR5LmAsXG5cdFx0XHRmaXg6IFwiQWRkIGEgYGNvbXBvbmVudGAsIGBjb21wb25lbnRzYCwgb3IgYGNoaWxkcmVuYCB0byB0aGUgcm91dGUgcmVjb3JkLlwiLFxuXHRcdFx0ZG9jczogXCJodHRwczovL3JvdXRlci52dWVqcy5vcmcvZ3VpZGUvZXNzZW50aWFscy9uZXN0ZWQtcm91dGVzLmh0bWxcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDAyNzoge1xuXHRcdFx0d2h5OiAocCkgPT4gYENvbXBvbmVudCBcIiR7cC5uYW1lfVwiIGluIHJlY29yZCB3aXRoIHBhdGggXCIke3AucGF0aH1cIiBpcyBub3QgYSB2YWxpZCBjb21wb25lbnQuIFJlY2VpdmVkIFwiJHtwLnJlY2VpdmVkfVwiLmAsXG5cdFx0XHRmaXg6IFwiUGFzcyBhIGNvbXBvbmVudCBvciBhIGZ1bmN0aW9uIHJldHVybmluZyBhIFByb21pc2UgdGhhdCByZXNvbHZlcyB0byBvbmUuXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwMjg6IHtcblx0XHRcdHdoeTogKHApID0+IGBDb21wb25lbnQgXCIke3AubmFtZX1cIiBpbiByZWNvcmQgd2l0aCBwYXRoIFwiJHtwLnBhdGh9XCIgaXMgYSBQcm9taXNlIGluc3RlYWQgb2YgYSBmdW5jdGlvbiB0aGF0IHJldHVybnMgYSBQcm9taXNlLiBUaGlzIHdpbGwgYnJlYWsgaW4gcHJvZHVjdGlvbiBpZiBub3QgZml4ZWQuYCxcblx0XHRcdGZpeDogYERlZmVyIHRoZSBpbXBvcnQgaW4gYW4gYXJyb3cgZnVuY3Rpb24gc28gaXQgbG9hZHMgbGF6aWx5OiB3cml0ZSBcIigpID0+IGltcG9ydCgnLi9NeVBhZ2UudnVlJylcIiwgbm90IFwiaW1wb3J0KCcuL015UGFnZS52dWUnKVwiLmAsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9hZHZhbmNlZC9sYXp5LWxvYWRpbmcuaHRtbFwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDI5OiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgQ29tcG9uZW50IFwiJHtwLm5hbWV9XCIgaW4gcmVjb3JkIHdpdGggcGF0aCBcIiR7cC5wYXRofVwiIGlzIGRlZmluZWQgdXNpbmcgXCJkZWZpbmVBc3luY0NvbXBvbmVudCgpXCIuYCxcblx0XHRcdGZpeDogYERyb3AgdGhlIHdyYXBwZXIgYW5kIHBhc3MgXCIoKSA9PiBpbXBvcnQoJy4vTXlQYWdlLnZ1ZScpXCIgZGlyZWN0bHk7IHRoZSByb3V0ZXIgaGFuZGxlcyBsYXp5IGNvbXBvbmVudHMgaXRzZWxmLmAsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9hZHZhbmNlZC9sYXp5LWxvYWRpbmcuaHRtbCNSZWxhdGlvbnNoaXAtdG8tYXN5bmMtY29tcG9uZW50c1wiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDMwOiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgQ29tcG9uZW50IFwiJHtwLm5hbWV9XCIgaW4gcmVjb3JkIHdpdGggcGF0aCBcIiR7cC5wYXRofVwiIGlzIGEgZnVuY3Rpb24gdGhhdCBkb2VzIG5vdCByZXR1cm4gYSBQcm9taXNlLiBUaGlzIHdpbGwgYnJlYWsgaW4gcHJvZHVjdGlvbiBpZiBub3QgZml4ZWQuYCxcblx0XHRcdGZpeDogXCJSZXR1cm4gYSBkeW5hbWljIGltcG9ydCAoYCgpID0+IGltcG9ydChcXFwiLi9NeVBhZ2UudnVlXFxcIilgKSBmcm9tIHRoZSBmdW5jdGlvbiwgb3IgYWRkIGEgYGRpc3BsYXlOYW1lYCBpZiBpdCBpcyBhIGZ1bmN0aW9uYWwgY29tcG9uZW50LlwiLFxuXHRcdFx0ZG9jczogXCJodHRwczovL3JvdXRlci52dWVqcy5vcmcvZ3VpZGUvYWR2YW5jZWQvbGF6eS1sb2FkaW5nLmh0bWxcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDA0MDoge1xuXHRcdFx0d2h5OiAocCkgPT4gYEJlY2F1c2UgXCIke3AuZWx9XCIgc3RhcnRzIHdpdGggXCIjXCIsIHNjcm9sbEJlaGF2aW9yIHJlc29sdmVzIGl0IGFzIGFuIGVsZW1lbnQgaWQgdmlhIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwiJHtwLmVsLnNsaWNlKDEpfVwiKSwgbm90IGFzIGEgQ1NTIHNlbGVjdG9yLiBObyBlbGVtZW50IGhhcyB0aGF0IGlkLCBidXQgXCIke3AuZWx9XCIgZG9lcyBtYXRjaCBhbiBlbGVtZW50IHdpdGggZG9jdW1lbnQucXVlcnlTZWxlY3RvcigpLmAsXG5cdFx0XHRmaXg6IChwKSA9PiBgUmVzb2x2ZSB0aGUgZWxlbWVudCB5b3Vyc2VsZiBhbmQgcmV0dXJuIHRoZSBub2RlOiBlbDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcignJHtwLmVsfScpLmAsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9hZHZhbmNlZC9zY3JvbGwtYmVoYXZpb3IuaHRtbFwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDQxOiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgVGhlIHNlbGVjdG9yIFwiJHtwLmVsfVwiIGlzIGludmFsaWQuIFNlZSBodHRwczovL21hdGhpYXNieW5lbnMuYmUvbm90ZXMvY3NzLWVzY2FwZXMgb3IgQ1NTLmVzY2FwZSAoaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQVBJL0NTUy9lc2NhcGUpIGZvciB0aGUgZXNjYXBpbmcgcnVsZXMuYCxcblx0XHRcdGZpeDogXCJCdWlsZCBhbiBpZCBzZWxlY3RvciBhcyBgIyR7Q1NTLmVzY2FwZShpZCl9YCBzbyBzcGVjaWFsIGNoYXJhY3RlcnMgaW4gdGhlIGlkIGFyZSBlc2NhcGVkLlwiLFxuXHRcdFx0ZG9jczogXCJodHRwczovL3JvdXRlci52dWVqcy5vcmcvZ3VpZGUvYWR2YW5jZWQvc2Nyb2xsLWJlaGF2aW9yLmh0bWxcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDA0Mjoge1xuXHRcdFx0d2h5OiAocCkgPT4gYENvdWxkbid0IGZpbmQgZWxlbWVudCB1c2luZyBzZWxlY3RvciBcIiR7cC5lbH1cIiByZXR1cm5lZCBieSBzY3JvbGxCZWhhdmlvci5gLFxuXHRcdFx0Zml4OiBcIlJldHVybiBhIHNlbGVjdG9yIHRoYXQgbWF0Y2hlcyBhbiBleGlzdGluZyBlbGVtZW50LCBvciBndWFyZCBhZ2FpbnN0IG1pc3NpbmcgZWxlbWVudHMuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9hZHZhbmNlZC9zY3JvbGwtYmVoYXZpb3IuaHRtbFwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDUwOiB7XG5cdFx0XHR3aHk6IChwKSA9PiB7XG5cdFx0XHRcdGxldCB0bztcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHR0byA9IHAudG8gPT09IHZvaWQgMCA/IFwidW5kZWZpbmVkXCIgOiBKU09OLnN0cmluZ2lmeShwLnRvKTtcblx0XHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdFx0dG8gPSBTdHJpbmcocC50byk7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIGBJbnZhbGlkIHZhbHVlIGZvciBwcm9wIFwidG9cIiBpbiB1c2VMaW5rKClcXG4tIHRvOiAke3RvfWA7XG5cdFx0XHR9LFxuXHRcdFx0Zml4OiBcIlBhc3MgYSB2YWxpZCByb3V0ZSBsb2NhdGlvbiAoYSBzdHJpbmcgcGF0aCBvciBhbiBvYmplY3QpIHRvIHRoZSBcXFwidG9cXFwiIHByb3AuXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAwNjA6IHtcblx0XHRcdHdoeTogKHApID0+IGA8cm91dGVyLXZpZXc+IGNhbiBubyBsb25nZXIgYmUgdXNlZCBkaXJlY3RseSBpbnNpZGUgPCR7cC5jb21wfT4uYCxcblx0XHRcdGZpeDogKHApID0+IGBXcmFwIHRoZSBzbG90J3MgcmVzb2x2ZWQgY29tcG9uZW50IHdpdGggPCR7cC5jb21wfT4gaW5zdGVhZCBvZiBuZXN0aW5nIDxyb3V0ZXItdmlldz4gaW4gaXQ6XFxuXFxuPHJvdXRlci12aWV3IHYtc2xvdD1cInsgQ29tcG9uZW50IH1cIj5cXG4gIDwke3AuY29tcH0+XFxuICAgIDxjb21wb25lbnQgOmlzPVwiQ29tcG9uZW50XCIgLz5cXG4gIDwvJHtwLmNvbXB9Plxcbjwvcm91dGVyLXZpZXc+YCxcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL2FkdmFuY2VkL3JvdXRlci12aWV3LXNsb3QuaHRtbCNLZWVwQWxpdmUtVHJhbnNpdGlvblwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDcwOiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgQ2Fubm90IHJlc29sdmUgYSByZWxhdGl2ZSBsb2NhdGlvbiB3aXRob3V0IGFuIGFic29sdXRlIHBhdGguIFRyeWluZyB0byByZXNvbHZlIFwiJHtwLnRvfVwiIGZyb20gXCIke3AuZnJvbX1cIi5gLFxuXHRcdFx0Zml4OiAocCkgPT4gYFJlc29sdmUgZnJvbSBhbiBhYnNvbHV0ZSBcXGBmcm9tXFxgIHBhdGggdGhhdCBzdGFydHMgd2l0aCBcIi9cIiwgZS5nLiBcIi8ke3AuZnJvbX1cIi5gXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMDgwOiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgRXJyb3IgZGVjb2RpbmcgXCIke3AudGV4dH1cIi4gVXNpbmcgb3JpZ2luYWwgdmFsdWVgLFxuXHRcdFx0Zml4OiBcIkVuc3VyZSB0aGUgdmFsdWUgaXMgY29ycmVjdGx5IHBlcmNlbnQtZW5jb2RlZC5cIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDA5MDoge1xuXHRcdFx0d2h5OiAocCkgPT4gYEZvdW5kIGR1cGxpY2F0ZWQgcGFyYW1zIHdpdGggbmFtZSBcIiR7cC5uYW1lfVwiIGZvciBwYXRoIFwiJHtwLnBhdGh9XCIuIE9ubHkgdGhlIGxhc3Qgb25lIHdpbGwgYmUgYXZhaWxhYmxlIG9uIFwiJHJvdXRlLnBhcmFtc1wiLmAsXG5cdFx0XHRmaXg6IFwiR2l2ZSBlYWNoIHBhcmFtIGEgdW5pcXVlIG5hbWUgd2l0aGluIHRoZSBwYXRoLlwiLFxuXHRcdFx0ZG9jczogXCJodHRwczovL3JvdXRlci52dWVqcy5vcmcvZ3VpZGUvZXNzZW50aWFscy9yb3V0ZS1tYXRjaGluZy1zeW50YXguaHRtbFwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMTAwOiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgRGlzY2FyZGVkIGludmFsaWQgcGFyYW0ocykgXCIke3AucGFyYW1zfVwiIHdoZW4gbmF2aWdhdGluZy5gICsgcC5pbmhlcml0ZWQgKyBgIFNlZSBodHRwczovL2dpdGh1Yi5jb20vdnVlanMvcm91dGVyL2NvbW1pdC9lODg3NTcwIGZvciBtb3JlIGRldGFpbHMuYCxcblx0XHRcdGZpeDogXCJPbmx5IHBhc3MgcGFyYW1zIHRoYXQgZXhpc3Qgb24gdGhlIHRhcmdldCByb3V0ZS5cIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDEwMToge1xuXHRcdFx0d2h5OiAocCkgPT4gYFRoZSBNYXRjaGVyIGNhbm5vdCByZXNvbHZlIHJlbGF0aXZlIHBhdGhzIGJ1dCByZWNlaXZlZCBcIiR7cC5wYXRofVwiLiBVbmxlc3MgeW91IGRpcmVjdGx5IGNhbGxlZCBcXGBtYXRjaGVyLnJlc29sdmUoXCIke3AucGF0aH1cIilcXGAsIHRoaXMgaXMgcHJvYmFibHkgYSBidWcgaW4gdnVlLXJvdXRlci4gUGxlYXNlIG9wZW4gYW4gaXNzdWUgYXQgaHR0cHM6Ly9naXRodWIuY29tL3Z1ZWpzL3JvdXRlci9pc3N1ZXMvbmV3L2Nob29zZS5gLFxuXHRcdFx0Zml4OiBcIlBhc3MgYW4gYWJzb2x1dGUgcGF0aCAoc3RhcnRpbmcgd2l0aCBcXFwiL1xcXCIpIHRvIHRoZSBtYXRjaGVyLlwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMTAyOiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgQWxpYXMgXCIke3AuYWxpYXN9XCIgYW5kIHRoZSBvcmlnaW5hbCByZWNvcmQ6IFwiJHtwLm9yaWdpbmFsfVwiIG11c3QgaGF2ZSB0aGUgZXhhY3Qgc2FtZSBwYXJhbSBuYW1lZCBcIiR7cC5uYW1lfVwiYCxcblx0XHRcdGZpeDogXCJVc2UgdGhlIHNhbWUgcGFyYW0gbmFtZXMgaW4gdGhlIGFsaWFzIGFzIGluIHRoZSBvcmlnaW5hbCByb3V0ZS5cIixcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL2Vzc2VudGlhbHMvcmVkaXJlY3QtYW5kLWFsaWFzLmh0bWwjQWxpYXNcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDEwMzoge1xuXHRcdFx0d2h5OiAocCkgPT4gYFRoZSByb3V0ZSBuYW1lZCBcIiR7cC5uYW1lfVwiIGhhcyBhIGNoaWxkIHdpdGhvdXQgYSBuYW1lLCBhbiBlbXB0eSBwYXRoLCBhbmQgbm8gY2hpbGRyZW4uIFVzaW5nIHRoYXQgbmFtZSB3b24ndCByZW5kZXIgdGhlIGVtcHR5IHBhdGggY2hpbGQsIHNvIHRoaXMgaXMgcHJvYmFibHkgYSBtaXN0YWtlLmAsXG5cdFx0XHRmaXg6IFwiTW92ZSB0aGUgYG5hbWVgIG9udG8gdGhlIGVtcHR5LXBhdGggY2hpbGQ7IG9yLCBpZiBpbnRlbnRpb25hbCwgZ2l2ZSB0aGUgY2hpbGQgaXRzIG93biBuYW1lIHRvIHNpbGVuY2UgdGhpcy5cIixcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL2Vzc2VudGlhbHMvbmVzdGVkLXJvdXRlcy5odG1sI05lc3RlZC1OYW1lZC1Sb3V0ZXNcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDEwNDoge1xuXHRcdFx0d2h5OiAocCkgPT4gYEFic29sdXRlIHBhdGggXCIke3AucGF0aH1cIiBtdXN0IGhhdmUgdGhlIGV4YWN0IHNhbWUgcGFyYW0gbmFtZWQgXCIke3AubmFtZX1cIiBhcyBpdHMgcGFyZW50IFwiJHtwLnBhcmVudH1cIi5gLFxuXHRcdFx0Zml4OiBcIkluY2x1ZGUgdGhlIHBhcmVudCByb3V0ZSBwYXJhbXMgaW4gdGhlIGFic29sdXRlIGNoaWxkIHBhdGguXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9ndWlkZS9lc3NlbnRpYWxzL25lc3RlZC1yb3V0ZXMuaHRtbFwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IwMTA1OiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgRmluZGluZyBhbmNlc3RvciByb3V0ZSBcIiR7cC5hbmNlc3Rvcn1cIiBmYWlsZWQgZm9yIFwiJHtwLnJlY29yZH1cImAsXG5cdFx0XHRmaXg6IFwiUmVwb3J0IGEgcmVwcm9kdWN0aW9uIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS92dWVqcy9yb3V0ZXIvaXNzdWVzL25ldy9jaG9vc2UuXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAxMTA6IHtcblx0XHRcdHdoeTogYEEgaGFzaCBiYXNlIG11c3QgZW5kIHdpdGggYSBcIiNcImAsXG5cdFx0XHRmaXg6IChwKSA9PiBgQXBwZW5kIFwiI1wiIHRvIHRoZSBcImJhc2VcIiBhcmd1bWVudCBwYXNzZWQgdG8gXCJjcmVhdGVXZWJIYXNoSGlzdG9yeSgpXCI6IFwiJHtwLmJhc2V9XCIgc2hvdWxkIGJlIFwiJHtwLnN1Z2dlc3Rpb259XCIuYFxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMDEyMDoge1xuXHRcdFx0d2h5OiBcIkVycm9yIHdpdGggcHVzaC9yZXBsYWNlIFN0YXRlXCIsXG5cdFx0XHRmaXg6IFwiVGhlIGJyb3dzZXIgcmVqZWN0ZWQgdGhlIGhpc3RvcnkgQVBJIGNhbGw7IGNoZWNrIGZvciBjcm9zcy1vcmlnaW4gb3IgcmF0ZS1saW1pdCBpc3N1ZXMuXCJcblx0XHR9LFxuXHRcdFZVRV9ST1VURVJfUjAxMjE6IHtcblx0XHRcdHdoeTogXCJoaXN0b3J5LnN0YXRlIHNlZW1zIHRvIGhhdmUgYmVlbiBtYW51YWxseSByZXBsYWNlZCB3aXRob3V0IHByZXNlcnZpbmcgdGhlIG5lY2Vzc2FyeSB2YWx1ZXMuXFxuWW91IGNhbiBmaW5kIG1vcmUgaW5mb3JtYXRpb24gYXQgaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL21pZ3JhdGlvbi8jVXNhZ2Utb2YtaGlzdG9yeS1zdGF0ZVwiLFxuXHRcdFx0Zml4OiBcIk1lcmdlIHRoZSByb3V0ZXIncyBzdGF0ZSBpbnRvIHlvdXIgb3duIHdoZW4gY2FsbGluZyBpdCBtYW51YWxseTogYGhpc3RvcnkucmVwbGFjZVN0YXRlKHsgLi4uaGlzdG9yeS5zdGF0ZSwgLi4ueW91clN0YXRlIH0sICcnLCB1cmwpYC5cIixcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2d1aWRlL21pZ3JhdGlvbi5odG1sI1VzYWdlLW9mLWhpc3Rvcnktc3RhdGVcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMTAwMToge1xuXHRcdFx0d2h5OiAocCkgPT4gYERhdGEgbG9hZGVyIFwiJHtTdHJpbmcocC5rZXkpfVwiIGhhcyBhIGRpZmZlcmVudCBwYXJlbnQgdGhhbiB0aGUgY3VycmVudCBjb250ZXh0LiBUaGlzIHNob3VsZG4ndCBiZSBoYXBwZW5pbmcuYCxcblx0XHRcdGZpeDogXCJSZXBvcnQgYSBidWcgd2l0aCBhIG1pbmltYWwgcmVwcm9kdWN0aW9uIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS92dWVqcy9yb3V0ZXIvLlwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IxMDAyOiB7XG5cdFx0XHR3aHk6IFwiUmV0dXJuaW5nIGEgTmF2aWdhdGlvblJlc3VsdCBpcyBkZXByZWNhdGVkLlwiLFxuXHRcdFx0Zml4OiBcIlJlcGxhY2UgYHJldHVybiBuZXcgTmF2aWdhdGlvblJlc3VsdCh0bylgIHdpdGggYHJlcm91dGUodG8pYCwgd2hpY2ggdGhyb3dzIGludGVybmFsbHkgdG8gcmVyb3V0ZS5cIixcblx0XHRcdGRvY3M6IFwiaHR0cHM6Ly9yb3V0ZXIudnVlanMub3JnL2RhdGEtbG9hZGVycy9uYXZpZ2F0aW9uLWF3YXJlLmh0bWwjQ29udHJvbGxpbmctdGhlLW5hdmlnYXRpb24td2l0aC1yZXJvdXRlLVwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IxMDAzOiB7XG5cdFx0XHR3aHk6IChwKSA9PiBgTG9hZGVyIFwiJHtwLmtleX1cIidzIFwiY29tbWl0KClcIiB3YXMgY2FsbGVkIGJ1dCB0aGVyZSBpcyBubyBzdGFnZWQgZGF0YS5gLFxuXHRcdFx0Zml4OiBcIkVuc3VyZSB0aGUgbG9hZGVyIHJlc29sdmVkIGJlZm9yZSBjYWxsaW5nIGBjb21taXQoKWAuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9kYXRhLWxvYWRlcnMvZGVmaW5pbmctbG9hZGVycy5odG1sI0RlbGF5aW5nLWRhdGEtdXBkYXRlcy13aXRoLWNvbW1pdFwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IxMDA0OiB7XG5cdFx0XHR3aHk6IChwKSA9PiBcIkEgbG9hZGVyIHJldHVybmVkIGEgTmF2aWdhdGlvblJlc3VsdCBidXQgaXMgbm90IHJlZ2lzdGVyZWQgb24gdGhlIHJvdXRlLlwiICsgcC5rZXksXG5cdFx0XHRmaXg6IFwiRXhwb3J0IHRoZSBsb2FkZXIgZnJvbSB0aGUgcGFnZSBjb21wb25lbnQgc28gaXQgZ2V0cyByZWdpc3RlcmVkLCBlLmcuIGBleHBvcnQgY29uc3QgdXNlVXNlckRhdGEgPSBkZWZpbmVMb2FkZXIoLi4uKWAuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9kYXRhLWxvYWRlcnMvb3JnYW5pemF0aW9uLmh0bWxcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMTAwNToge1xuXHRcdFx0d2h5OiAocCkgPT4gYERhdGEgbG9hZGVyIFwiJHtwLmtleX1cIiBoYXMgaXRzZWxmIGFzIHBhcmVudC4gVGhpcyBzaG91bGRuJ3QgYmUgaGFwcGVuaW5nLmAsXG5cdFx0XHRmaXg6IFwiUmVwb3J0IGEgYnVnIHdpdGggYSBtaW5pbWFsIHJlcHJvZHVjdGlvbiBhdCBodHRwczovL2dpdGh1Yi5jb20vdnVlanMvcm91dGVyLy5cIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMTAwNjoge1xuXHRcdFx0d2h5OiAocCkgPT4gYEEgcXVlcnkgd2FzIGRlZmluZWQgd2l0aCB0aGUgc2FtZSBrZXkgYXMgdGhlIGxvYWRlciBcIlske3Aua2V5fV1cIi5cXG5TZWUgaHR0cHM6Ly9waW5pYS1jb2xhZGEuZXNtLmRldi8jVE9ET2AsXG5cdFx0XHRmaXg6IFwiSWYgdGhlIGtleSBpcyBtZWFudCB0byBtYXRjaCwgdXNlIHRoZSBkYXRhIGxvYWRlciBkaXJlY3RseTsgb3RoZXJ3aXNlIHJlbmFtZSB0aGUgYHVzZVF1ZXJ5KClgIGtleSBzbyBpdCBubyBsb25nZXIgY29sbGlkZXMuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9kYXRhLWxvYWRlcnMvY29sYWRhLmh0bWxcIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMTAwNzoge1xuXHRcdFx0d2h5OiBcIkRhdGEgTG9hZGVyIHdhcyBzZXR1cCB0d2ljZS5cIixcblx0XHRcdGZpeDogXCJSZWdpc3RlciBgRGF0YUxvYWRlclBsdWdpbmAgYSBzaW5nbGUgdGltZSB2aWEgYGFwcC51c2UoKWAuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9kYXRhLWxvYWRlcnMuaHRtbCNJbnN0YWxsYXRpb25cIlxuXHRcdH0sXG5cdFx0VlVFX1JPVVRFUl9SMTAwODoge1xuXHRcdFx0d2h5OiBcIkRhdGEgTG9hZGVyIGlzIGV4cGVyaW1lbnRhbCBhbmQgc3ViamVjdCB0byBicmVha2luZyBjaGFuZ2VzIGluIHRoZSBmdXR1cmUuXCIsXG5cdFx0XHRkb2NzOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9kYXRhLWxvYWRlcnMuaHRtbFwiXG5cdFx0fSxcblx0XHRWVUVfUk9VVEVSX1IxMDA5OiB7XG5cdFx0XHR3aHk6IFwiUmV0dXJuaW5nIGEgTmF2aWdhdGlvblJlc3VsdCBmcm9tIGEgbG9hZGVyIGlzIGRlcHJlY2F0ZWQuXCIsXG5cdFx0XHRmaXg6IFwiQ2FsbCBgcmVyb3V0ZSh0bylgIGluc2lkZSB0aGUgbG9hZGVyIGluc3RlYWQgb2YgcmV0dXJuaW5nIGBuZXcgTmF2aWdhdGlvblJlc3VsdCh0bylgOyBpdCB0aHJvd3MgaW50ZXJuYWxseSB0byByZXJvdXRlLlwiLFxuXHRcdFx0ZG9jczogXCJodHRwczovL3JvdXRlci52dWVqcy5vcmcvZGF0YS1sb2FkZXJzL25hdmlnYXRpb24tYXdhcmUuaHRtbCNDb250cm9sbGluZy10aGUtbmF2aWdhdGlvbi13aXRoLXJlcm91dGUtXCJcblx0XHR9XG5cdH1cbn0pO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2luamVjdGlvblN5bWJvbHMudHNcbi8qKlxuKiBSb3V0ZVJlY29yZCBiZWluZyByZW5kZXJlZCBieSB0aGUgY2xvc2VzdCBhbmNlc3RvciBSb3V0ZXIgVmlldy4gVXNlZCBmb3JcbiogYG9uQmVmb3JlUm91dGVVcGRhdGVgIGFuZCBgb25CZWZvcmVSb3V0ZUxlYXZlYC4gcnZsbSBzdGFuZHMgZm9yIFJvdXRlciBWaWV3XG4qIExvY2F0aW9uIE1hdGNoZWRcbipcbiogQGludGVybmFsXG4qL1xuY29uc3QgbWF0Y2hlZFJvdXRlS2V5ID0gU3ltYm9sKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFwicm91dGVyIHZpZXcgbG9jYXRpb24gbWF0Y2hlZFwiIDogXCJcIik7XG4vKipcbiogQWxsb3dzIG92ZXJyaWRpbmcgdGhlIHJvdXRlciB2aWV3IGRlcHRoIHRvIGNvbnRyb2wgd2hpY2ggY29tcG9uZW50IGluXG4qIGBtYXRjaGVkYCBpcyByZW5kZXJlZC4gcnZkIHN0YW5kcyBmb3IgUm91dGVyIFZpZXcgRGVwdGhcbipcbiogQGludGVybmFsXG4qL1xuY29uc3Qgdmlld0RlcHRoS2V5ID0gU3ltYm9sKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFwicm91dGVyIHZpZXcgZGVwdGhcIiA6IFwiXCIpO1xuLyoqXG4qIEFsbG93cyBvdmVycmlkaW5nIHRoZSByb3V0ZXIgaW5zdGFuY2UgcmV0dXJuZWQgYnkgYHVzZVJvdXRlcmAgaW4gdGVzdHMuIHJcbiogc3RhbmRzIGZvciByb3V0ZXJcbipcbiogQGludGVybmFsXG4qL1xuY29uc3Qgcm91dGVyS2V5ID0gU3ltYm9sKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFwicm91dGVyXCIgOiBcIlwiKTtcbi8qKlxuKiBBbGxvd3Mgb3ZlcnJpZGluZyB0aGUgY3VycmVudCByb3V0ZSByZXR1cm5lZCBieSBgdXNlUm91dGVgIGluIHRlc3RzLiBybFxuKiBzdGFuZHMgZm9yIHJvdXRlIGxvY2F0aW9uXG4qXG4qIEBpbnRlcm5hbFxuKi9cbmNvbnN0IHJvdXRlTG9jYXRpb25LZXkgPSBTeW1ib2wocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gXCJyb3V0ZSBsb2NhdGlvblwiIDogXCJcIik7XG4vKipcbiogQWxsb3dzIG92ZXJyaWRpbmcgdGhlIGN1cnJlbnQgcm91dGUgdXNlZCBieSByb3V0ZXItdmlldy4gSW50ZXJuYWxseSB0aGlzIGlzXG4qIHVzZWQgd2hlbiB0aGUgYHJvdXRlYCBwcm9wIGlzIHBhc3NlZC5cbipcbiogQGludGVybmFsXG4qL1xuY29uc3Qgcm91dGVyVmlld0xvY2F0aW9uS2V5ID0gU3ltYm9sKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFwicm91dGVyIHZpZXcgbG9jYXRpb25cIiA6IFwiXCIpO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3VzZUFwaS50c1xuLyoqXG4qIFJldHVybnMgdGhlIHJvdXRlciBpbnN0YW5jZS4gRXF1aXZhbGVudCB0byB1c2luZyBgJHJvdXRlcmAgaW5zaWRlXG4qIHRlbXBsYXRlcy5cbiovXG5mdW5jdGlvbiB1c2VSb3V0ZXIoKSB7XG5cdHJldHVybiBpbmplY3Qocm91dGVyS2V5KTtcbn1cbi8qKlxuKiBSZXR1cm5zIHRoZSBjdXJyZW50IHJvdXRlIGxvY2F0aW9uLiBFcXVpdmFsZW50IHRvIHVzaW5nIGAkcm91dGVgIGluc2lkZVxuKiB0ZW1wbGF0ZXMuXG4qL1xuZnVuY3Rpb24gdXNlUm91dGUoX25hbWUpIHtcblx0cmV0dXJuIGluamVjdChyb3V0ZUxvY2F0aW9uS2V5KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgaXNSb3V0ZUNvbXBvbmVudCBhcyBfLCByb3V0ZXJLZXkgYXMgYSwgZGlhZ25vc3RpY3MgYXMgYywgaXNOYXZpZ2F0aW9uRmFpbHVyZSBhcyBkLCBhcHBseVRvUGFyYW1zIGFzIGYsIGlzRVNNb2R1bGUgYXMgZywgaXNBcnJheSBhcyBoLCByb3V0ZUxvY2F0aW9uS2V5IGFzIGksIE5hdmlnYXRpb25GYWlsdXJlVHlwZSBhcyBsLCBpZGVudGl0eUZuIGFzIG0sIHVzZVJvdXRlciBhcyBuLCByb3V0ZXJWaWV3TG9jYXRpb25LZXkgYXMgbywgYXNzaWduIGFzIHAsIG1hdGNoZWRSb3V0ZUtleSBhcyByLCB2aWV3RGVwdGhLZXkgYXMgcywgdXNlUm91dGUgYXMgdCwgY3JlYXRlUm91dGVyRXJyb3IgYXMgdSwgbWVyZ2VPcHRpb25zIGFzIHYsIG5vb3AgYXMgeSB9O1xuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=