/*!
* vue-i18n v11.4.8
* (c) 2026 kazuya kawaguchi
* Released under the MIT License.
*/
import { createCompileError, CORE_ERROR_CODES_EXTEND_POINT, CORE_WARN_CODES_EXTEND_POINT, isMessageAST, AST_NODE_PROPS_KEYS, DEFAULT_LOCALE, updateFallbackLocale, setFallbackContext, createCoreContext, clearDateTimeFormat, clearNumberFormat, setAdditionalMeta, getFallbackContext, NOT_REOSLVED, isTranslateFallbackWarn, isTranslateMissingWarn, fallbackWithLocaleChain, parseTranslateArgs, translate, MISSING_RESOLVE_VALUE, parseDateTimeArgs, datetime, parseNumberArgs, number, isMessageFunction, NUMBER_FORMAT_OPTIONS_KEYS, DATETIME_FORMAT_OPTIONS_KEYS, registerMessageCompiler, compile, registerMessageResolver, resolveValue, registerLocaleFallbacker, setDevToolsHook } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@intlify+core-base@11.4.8/node_modules/@intlify/core-base/dist/core-base.mjs?v=7e73afc2";
import { getGlobalThis, makeSymbol, format, isObject, create, isPlainObject, isArray, deepCopy, isString, hasOwn, warn, isBoolean, isRegExp, isFunction, inBrowser, assign, isNumber, createEmitter, warnOnce, isEmptyObject } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@intlify+shared@11.4.8/node_modules/@intlify/shared/dist/shared.mjs?v=7e73afc2";
import * as Vue from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
import { createVNode, Text, computed, watch, ref, shallowRef, Fragment, defineComponent, h, getCurrentScope, onScopeDispose, effectScope, inject, onMounted, onUnmounted, isRef } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
import { setupDevtoolsPlugin } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vue+devtools-api@6.6.4/node_modules/@vue/devtools-api/lib/esm/index.js?v=7e73afc2";
/**
* Vue I18n Version
*
* @remarks
* Semver format. Same format as the package.json `version` field.
*
* @VueI18nGeneral
*/
const VERSION = "11.4.8";
/**
* This is only called in esm-bundler builds.
* istanbul-ignore-next
*/
function initFeatureFlags() {
	if (typeof __VUE_I18N_FULL_INSTALL__ !== "boolean") {
		getGlobalThis().__VUE_I18N_FULL_INSTALL__ = true;
	}
	if (typeof __VUE_I18N_LEGACY_API__ !== "boolean") {
		getGlobalThis().__VUE_I18N_LEGACY_API__ = true;
	}
	if (typeof __INTLIFY_DROP_MESSAGE_COMPILER__ !== "boolean") {
		getGlobalThis().__INTLIFY_DROP_MESSAGE_COMPILER__ = false;
	}
	if (typeof __INTLIFY_PROD_DEVTOOLS__ !== "boolean") {
		getGlobalThis().__INTLIFY_PROD_DEVTOOLS__ = false;
	}
}
const I18nErrorCodes = {
	// composer module errors
	UNEXPECTED_RETURN_TYPE: CORE_ERROR_CODES_EXTEND_POINT,
	// legacy module errors
	INVALID_ARGUMENT: 25,
	// i18n module errors
	MUST_BE_CALL_SETUP_TOP: 26,
	NOT_INSTALLED: 27,
	// directive module errors
	REQUIRED_VALUE: 28,
	INVALID_VALUE: 29,
	// vue-devtools errors
	CANNOT_SETUP_VUE_DEVTOOLS_PLUGIN: 30,
	NOT_INSTALLED_WITH_PROVIDE: 31,
	// unexpected error
	UNEXPECTED_ERROR: 32,
	// not compatible legacy vue-i18n constructor
	NOT_COMPATIBLE_LEGACY_VUE_I18N: 33,
	// Not available Compostion API in Legacy API mode. Please make sure that the legacy API mode is working properly
	NOT_AVAILABLE_COMPOSITION_IN_LEGACY: 34
};
function createI18nError(code, ...args) {
	return createCompileError(code, null, "development" !== "production" ? {
		messages: errorMessages,
		args
	} : undefined);
}
const errorMessages = {
	[I18nErrorCodes.UNEXPECTED_RETURN_TYPE]: "Unexpected return type in composer",
	[I18nErrorCodes.INVALID_ARGUMENT]: "Invalid argument",
	[I18nErrorCodes.MUST_BE_CALL_SETUP_TOP]: "Must be called at the top of a `setup` function",
	[I18nErrorCodes.NOT_INSTALLED]: "Need to install with `app.use` function",
	[I18nErrorCodes.UNEXPECTED_ERROR]: "Unexpected error",
	[I18nErrorCodes.REQUIRED_VALUE]: `Required in value: {0}`,
	[I18nErrorCodes.INVALID_VALUE]: `Invalid value`,
	[I18nErrorCodes.CANNOT_SETUP_VUE_DEVTOOLS_PLUGIN]: `Cannot setup vue-devtools plugin`,
	[I18nErrorCodes.NOT_INSTALLED_WITH_PROVIDE]: "Need to install with `provide` function",
	[I18nErrorCodes.NOT_COMPATIBLE_LEGACY_VUE_I18N]: "Not compatible legacy VueI18n.",
	[I18nErrorCodes.NOT_AVAILABLE_COMPOSITION_IN_LEGACY]: "Not available Compostion API in Legacy API mode. Please make sure that the legacy API mode is working properly"
};
const TranslateVNodeSymbol = /* #__PURE__*/ makeSymbol("__translateVNode");
const DatetimePartsSymbol = /* #__PURE__*/ makeSymbol("__datetimeParts");
const NumberPartsSymbol = /* #__PURE__*/ makeSymbol("__numberParts");
const EnableEmitter = /* #__PURE__*/ makeSymbol("__enableEmitter");
const DisableEmitter = /* #__PURE__*/ makeSymbol("__disableEmitter");
const SetPluralRulesSymbol = makeSymbol("__setPluralRules");
makeSymbol("__intlifyMeta");
const InejctWithOptionSymbol = /* #__PURE__*/ makeSymbol("__injectWithOption");
const DisposeSymbol = /* #__PURE__*/ makeSymbol("__dispose");
const I18nWarnCodes = {
	FALLBACK_TO_ROOT: CORE_WARN_CODES_EXTEND_POINT,
	NOT_FOUND_PARENT_SCOPE: CORE_WARN_CODES_EXTEND_POINT + 1,
	IGNORE_OBJ_FLATTEN: CORE_WARN_CODES_EXTEND_POINT + 2,
	/**
	* @deprecated will be removed at vue-i18n v12
	*/
	DEPRECATE_LEGACY_MODE: CORE_WARN_CODES_EXTEND_POINT + 3,
	/**
	* @deprecated will be removed at vue-i18n v12
	*/
	DEPRECATE_TRANSLATE_CUSTOME_DIRECTIVE: CORE_WARN_CODES_EXTEND_POINT + 4,
	// duplicate `useI18n` calling
	DUPLICATE_USE_I18N_CALLING: CORE_WARN_CODES_EXTEND_POINT + 5
};
const warnMessages = {
	[I18nWarnCodes.FALLBACK_TO_ROOT]: `Fall back to {type} '{key}' with root locale.`,
	[I18nWarnCodes.NOT_FOUND_PARENT_SCOPE]: `Not found parent scope. use the global scope.`,
	[I18nWarnCodes.IGNORE_OBJ_FLATTEN]: `Ignore object flatten: '{key}' key has an string value`,
	/**
	* @deprecated will be removed at vue-i18n v12
	*/
	[I18nWarnCodes.DEPRECATE_LEGACY_MODE]: `Legacy API mode has been deprecated in v11. Use Composition API mode instead.\nAbout how to use the Composition API mode, see https://vue-i18n.intlify.dev/guide/advanced/composition.html`,
	/**
	* @deprecated will be removed at vue-i18n v12
	*/
	[I18nWarnCodes.DEPRECATE_TRANSLATE_CUSTOME_DIRECTIVE]: `'v-t' has been deprecated in v11. Use translate APIs ('t' or '$t') instead.`,
	[I18nWarnCodes.DUPLICATE_USE_I18N_CALLING]: "Duplicate `useI18n` calling by local scope. Please don't call it on local scope, due to it does not work properly in component."
};
function getWarnMessage(code, ...args) {
	return format(warnMessages[code], ...args);
}
/* eslint-disable @typescript-eslint/no-explicit-any */
/**
* Transform flat json in obj to normal json in obj
*/
function handleFlatJson(obj) {
	// check obj
	if (!isObject(obj)) {
		return obj;
	}
	if (isMessageAST(obj)) {
		return obj;
	}
	for (const key in obj) {
		// check key
		if (!hasOwn(obj, key)) {
			continue;
		}
		// handle for normal json
		if (!key.includes(".")) {
			// recursive process value if value is also a object
			if (isObject(obj[key])) {
				handleFlatJson(obj[key]);
			}
		} else {
			// go to the last object
			const subKeys = key.split(".");
			const lastIndex = subKeys.length - 1;
			let currentObj = obj;
			let hasStringValue = false;
			for (let i = 0; i < lastIndex; i++) {
				if (subKeys[i] === "__proto__") {
					throw new Error(`unsafe key: ${subKeys[i]}`);
				}
				if (!(subKeys[i] in currentObj)) {
					currentObj[subKeys[i]] = create();
				}
				if (!isObject(currentObj[subKeys[i]])) {
					"development" !== "production" && warn(getWarnMessage(I18nWarnCodes.IGNORE_OBJ_FLATTEN, { key: subKeys[i] }));
					hasStringValue = true;
					break;
				}
				currentObj = currentObj[subKeys[i]];
			}
			// update last object value, delete old property
			if (!hasStringValue) {
				if (!isMessageAST(currentObj)) {
					currentObj[subKeys[lastIndex]] = obj[key];
					delete obj[key];
				} else {
					/**
					* NOTE:
					* if the last object is a message AST and subKeys[lastIndex] has message AST prop key, ignore to copy and key deletion
					*/
					if (!AST_NODE_PROPS_KEYS.includes(subKeys[lastIndex])) {
						delete obj[key];
					}
				}
			}
			// recursive process value if value is also a object
			if (!isMessageAST(currentObj)) {
				const target = currentObj[subKeys[lastIndex]];
				if (isObject(target)) {
					handleFlatJson(target);
				}
			}
		}
	}
	return obj;
}
function getLocaleMessages(locale, options) {
	const { messages, __i18n, messageResolver, flatJson } = options;
	// prettier-ignore
	const ret = isPlainObject(messages) ? messages : isArray(__i18n) ? create() : { [locale]: create() };
	// merge locale messages of i18n custom block
	if (isArray(__i18n)) {
		__i18n.forEach((custom) => {
			if ("locale" in custom && "resource" in custom) {
				const { locale, resource } = custom;
				if (locale) {
					ret[locale] = ret[locale] || create();
					deepCopy(resource, ret[locale]);
				} else {
					deepCopy(resource, ret);
				}
			} else {
				isString(custom) && deepCopy(JSON.parse(custom), ret);
			}
		});
	}
	// handle messages for flat json
	if (messageResolver == null && flatJson) {
		for (const key in ret) {
			if (hasOwn(ret, key)) {
				handleFlatJson(ret[key]);
			}
		}
	}
	return ret;
}
function getComponentOptions(instance) {
	return instance.type;
}
function adjustI18nResources(gl, options, componentOptions) {
	// prettier-ignore
	let messages = isObject(options.messages) ? options.messages : create();
	if ("__i18nGlobal" in componentOptions) {
		messages = getLocaleMessages(gl.locale.value, {
			messages,
			__i18n: componentOptions.__i18nGlobal
		});
	}
	// merge locale messages
	const locales = Object.keys(messages);
	if (locales.length) {
		locales.forEach((locale) => {
			gl.mergeLocaleMessage(locale, messages[locale]);
		});
	}
	{
		// merge datetime formats
		if (isObject(options.datetimeFormats)) {
			const locales = Object.keys(options.datetimeFormats);
			if (locales.length) {
				locales.forEach((locale) => {
					gl.mergeDateTimeFormat(locale, options.datetimeFormats[locale]);
				});
			}
		}
		// merge number formats
		if (isObject(options.numberFormats)) {
			const locales = Object.keys(options.numberFormats);
			if (locales.length) {
				locales.forEach((locale) => {
					gl.mergeNumberFormat(locale, options.numberFormats[locale]);
				});
			}
		}
	}
}
function createTextNode(key) {
	return createVNode(Text, null, key, 0);
}
function getCurrentInstance() {
	// NOTE(kazupon): avoid bundler warning
	const key = "currentInstance";
	if (key in Vue) {
		return Vue[key];
	} else {
		return Vue.getCurrentInstance();
	}
}
/* eslint-enable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-explicit-any */
// extend VNode interface
const DEVTOOLS_META = "__INTLIFY_META__";
const NOOP_RETURN_ARRAY = () => [];
const NOOP_RETURN_FALSE = () => false;
let composerID = 0;
function defineCoreMissingHandler(missing) {
	return ((ctx, locale, key, type) => {
		return missing(locale, key, getCurrentInstance() || undefined, type);
	});
}
// for Intlify DevTools
const getMetaInfo = /* @__NO_SIDE_EFFECTS__ */ () => {
	const instance = getCurrentInstance();
	let meta = null;
	return instance && (meta = getComponentOptions(instance)[DEVTOOLS_META]) ? { [DEVTOOLS_META]: meta } : null;
};
/**
* Create composer interface factory
*
* @internal
*/
function createComposer(options = {}) {
	const { __root, __injectWithOption } = options;
	const _isGlobal = __root === undefined;
	const flatJson = options.flatJson;
	const _ref = inBrowser ? ref : shallowRef;
	let _inheritLocale = isBoolean(options.inheritLocale) ? options.inheritLocale : true;
	const _locale = _ref(
		// prettier-ignore
		__root && _inheritLocale ? __root.locale.value : isString(options.locale) ? options.locale : DEFAULT_LOCALE
	);
	const _fallbackLocale = _ref(
		// prettier-ignore
		__root && _inheritLocale ? __root.fallbackLocale.value : isString(options.fallbackLocale) || isArray(options.fallbackLocale) || isPlainObject(options.fallbackLocale) || options.fallbackLocale === false ? options.fallbackLocale : _locale.value
	);
	const _messages = _ref(getLocaleMessages(_locale.value, options));
	// prettier-ignore
	const _datetimeFormats = _ref(isPlainObject(options.datetimeFormats) ? options.datetimeFormats : { [_locale.value]: {} });
	// prettier-ignore
	const _numberFormats = _ref(isPlainObject(options.numberFormats) ? options.numberFormats : { [_locale.value]: {} });
	// warning suppress options
	// prettier-ignore
	let _missingWarn = __root ? __root.missingWarn : isBoolean(options.missingWarn) || isRegExp(options.missingWarn) ? options.missingWarn : true;
	// prettier-ignore
	let _fallbackWarn = __root ? __root.fallbackWarn : isBoolean(options.fallbackWarn) || isRegExp(options.fallbackWarn) ? options.fallbackWarn : true;
	// prettier-ignore
	let _fallbackRoot = __root ? __root.fallbackRoot : isBoolean(options.fallbackRoot) ? options.fallbackRoot : true;
	// configure fall back to root
	let _fallbackFormat = !!options.fallbackFormat;
	// runtime missing
	let _missing = isFunction(options.missing) ? options.missing : null;
	let _runtimeMissing = isFunction(options.missing) ? defineCoreMissingHandler(options.missing) : null;
	// postTranslation handler
	let _postTranslation = isFunction(options.postTranslation) ? options.postTranslation : null;
	// prettier-ignore
	let _warnHtmlMessage = __root ? __root.warnHtmlMessage : isBoolean(options.warnHtmlMessage) ? options.warnHtmlMessage : true;
	let _escapeParameter = !!options.escapeParameter;
	// custom linked modifiers
	// prettier-ignore
	const _modifiers = __root ? __root.modifiers : isPlainObject(options.modifiers) ? options.modifiers : {};
	// pluralRules
	let _pluralRules = options.pluralRules || __root && __root.pluralRules;
	// runtime context
	// eslint-disable-next-line prefer-const
	let _context;
	const getCoreContext = () => {
		_isGlobal && setFallbackContext(null);
		const ctxOptions = {
			version: VERSION,
			locale: _locale.value,
			fallbackLocale: _fallbackLocale.value,
			messages: _messages.value,
			modifiers: _modifiers,
			pluralRules: _pluralRules,
			missing: _runtimeMissing === null ? undefined : _runtimeMissing,
			missingWarn: _missingWarn,
			fallbackWarn: _fallbackWarn,
			fallbackFormat: _fallbackFormat,
			unresolving: true,
			postTranslation: _postTranslation === null ? undefined : _postTranslation,
			warnHtmlMessage: _warnHtmlMessage,
			escapeParameter: _escapeParameter,
			messageResolver: options.messageResolver,
			messageCompiler: options.messageCompiler,
			__meta: { framework: "vue" }
		};
		{
			ctxOptions.datetimeFormats = _datetimeFormats.value;
			ctxOptions.numberFormats = _numberFormats.value;
			ctxOptions.__datetimeFormatters = isPlainObject(_context) ? _context.__datetimeFormatters : undefined;
			ctxOptions.__numberFormatters = isPlainObject(_context) ? _context.__numberFormatters : undefined;
		}
		if ("development" !== "production") {
			ctxOptions.__v_emitter = isPlainObject(_context) ? _context.__v_emitter : undefined;
		}
		const ctx = createCoreContext(ctxOptions);
		_isGlobal && setFallbackContext(ctx);
		return ctx;
	};
	_context = getCoreContext();
	updateFallbackLocale(_context, _locale.value, _fallbackLocale.value);
	// track reactivity
	function trackReactivityValues() {
		return [
			_locale.value,
			_fallbackLocale.value,
			_messages.value,
			_datetimeFormats.value,
			_numberFormats.value
		];
	}
	// locale
	const locale = computed({
		get: () => _locale.value,
		set: (val) => {
			_context.locale = val;
			_locale.value = val;
		}
	});
	// fallbackLocale
	const fallbackLocale = computed({
		get: () => _fallbackLocale.value,
		set: (val) => {
			_context.fallbackLocale = val;
			_fallbackLocale.value = val;
			updateFallbackLocale(_context, _locale.value, val);
		}
	});
	// messages
	const messages = computed(() => _messages.value);
	// datetimeFormats
	const datetimeFormats = /* #__PURE__*/ computed(() => _datetimeFormats.value);
	// numberFormats
	const numberFormats = /* #__PURE__*/ computed(() => _numberFormats.value);
	// getPostTranslationHandler
	function getPostTranslationHandler() {
		return isFunction(_postTranslation) ? _postTranslation : null;
	}
	// setPostTranslationHandler
	function setPostTranslationHandler(handler) {
		_postTranslation = handler;
		_context.postTranslation = handler;
	}
	// getMissingHandler
	function getMissingHandler() {
		return _missing;
	}
	// setMissingHandler
	function setMissingHandler(handler) {
		if (handler !== null) {
			_runtimeMissing = defineCoreMissingHandler(handler);
		}
		_missing = handler;
		_context.missing = _runtimeMissing;
	}
	function isResolvedTranslateMessage(type, arg) {
		return type !== "translate" || !arg.resolvedMessage;
	}
	const wrapWithDeps = (fn, argumentParser, warnType, fallbackSuccess, fallbackFail, successCondition) => {
		trackReactivityValues();
		// NOTE: experimental !!
		let ret;
		try {
			if ("development" !== "production" || __INTLIFY_PROD_DEVTOOLS__) {
				setAdditionalMeta(getMetaInfo());
			}
			if (!_isGlobal) {
				_context.fallbackContext = __root ? getFallbackContext() : undefined;
			}
			ret = fn(_context);
		} finally {
			if ("development" !== "production" || __INTLIFY_PROD_DEVTOOLS__) {
				setAdditionalMeta(null);
			}
			if (!_isGlobal) {
				_context.fallbackContext = undefined;
			}
		}
		if (warnType !== "translate exists" && isNumber(ret) && ret === NOT_REOSLVED || warnType === "translate exists" && !ret) {
			const [key, arg2] = argumentParser();
			if ("development" !== "production" && __root && isString(key) && isResolvedTranslateMessage(warnType, arg2)) {
				if (_fallbackRoot && (isTranslateFallbackWarn(_fallbackWarn, key) || isTranslateMissingWarn(_missingWarn, key))) {
					warn(getWarnMessage(I18nWarnCodes.FALLBACK_TO_ROOT, {
						key,
						type: warnType
					}));
				}
				// for vue-devtools timeline event
				if ("development" !== "production") {
					const { __v_emitter: emitter } = _context;
					if (emitter && _fallbackRoot) {
						emitter.emit("fallback", {
							type: warnType,
							key,
							to: "global",
							groupId: `${warnType}:${key}`
						});
					}
				}
			}
			return __root && _fallbackRoot ? fallbackSuccess(__root) : fallbackFail(key);
		} else if (successCondition(ret)) {
			return ret;
		} else {
			/* istanbul ignore next */
			throw createI18nError(I18nErrorCodes.UNEXPECTED_RETURN_TYPE);
		}
	};
	// t
	function t(...args) {
		return wrapWithDeps((context) => Reflect.apply(translate, null, [context, ...args]), () => parseTranslateArgs(...args), "translate", (root) => Reflect.apply(root.t, root, [...args]), (key) => key, (val) => isString(val));
	}
	// rt
	function rt(...args) {
		const [arg1, arg2, arg3] = args;
		if (arg3 && !isObject(arg3)) {
			throw createI18nError(I18nErrorCodes.INVALID_ARGUMENT);
		}
		return t(...[
			arg1,
			arg2,
			assign({ resolvedMessage: true }, arg3 || {})
		]);
	}
	// d
	function d(...args) {
		return wrapWithDeps((context) => Reflect.apply(datetime, null, [context, ...args]), () => parseDateTimeArgs(...args), "datetime format", (root) => Reflect.apply(root.d, root, [...args]), () => MISSING_RESOLVE_VALUE, (val) => isString(val) || isArray(val));
	}
	// n
	function n(...args) {
		return wrapWithDeps((context) => Reflect.apply(number, null, [context, ...args]), () => parseNumberArgs(...args), "number format", (root) => Reflect.apply(root.n, root, [...args]), () => MISSING_RESOLVE_VALUE, (val) => isString(val) || isArray(val));
	}
	// for custom processor
	function normalize(values) {
		return values.map((val) => isString(val) || isNumber(val) || isBoolean(val) ? createTextNode(String(val)) : val);
	}
	const interpolate = (val) => val;
	const processor = {
		normalize,
		interpolate,
		type: "vnode"
	};
	// translateVNode, using for `i18n-t` component
	function translateVNode(...args) {
		return wrapWithDeps((context) => {
			let ret;
			const _context = context;
			try {
				_context.processor = processor;
				ret = Reflect.apply(translate, null, [_context, ...args]);
			} finally {
				_context.processor = null;
			}
			return ret;
		}, () => parseTranslateArgs(...args), "translate", (root) => root[TranslateVNodeSymbol](...args), (key) => [createTextNode(key)], (val) => isArray(val));
	}
	// numberParts, using for `i18n-n` component
	function numberParts(...args) {
		return wrapWithDeps((context) => Reflect.apply(number, null, [context, ...args]), () => parseNumberArgs(...args), "number format", (root) => root[NumberPartsSymbol](...args), NOOP_RETURN_ARRAY, (val) => isString(val) || isArray(val));
	}
	// datetimeParts, using for `i18n-d` component
	function datetimeParts(...args) {
		return wrapWithDeps((context) => Reflect.apply(datetime, null, [context, ...args]), () => parseDateTimeArgs(...args), "datetime format", (root) => root[DatetimePartsSymbol](...args), NOOP_RETURN_ARRAY, (val) => isString(val) || isArray(val));
	}
	function setPluralRules(rules) {
		_pluralRules = rules;
		_context.pluralRules = _pluralRules;
	}
	// te
	function te(key, locale) {
		return wrapWithDeps(() => {
			if (!key) {
				return false;
			}
			const targetLocale = isString(locale) ? locale : _locale.value;
			// When locale is explicitly specified, check only that locale (no fallback chain)
			// When locale is not specified, check the fallback locale chain
			const locales = isString(locale) ? [targetLocale] : fallbackWithLocaleChain(_context, _fallbackLocale.value, targetLocale);
			for (let i = 0; i < locales.length; i++) {
				const message = getLocaleMessage(locales[i]);
				let resolved = _context.messageResolver(message, key);
				// if null, resolve with object key path (for flat keys containing dots)
				if (resolved === null) {
					resolved = message[key];
				}
				if (isMessageAST(resolved) || isMessageFunction(resolved) || isString(resolved)) {
					return true;
				}
			}
			return false;
		}, () => [key], "translate exists", (root) => {
			return Reflect.apply(root.te, root, [key, locale]);
		}, NOOP_RETURN_FALSE, (val) => isBoolean(val));
	}
	function resolveMessages(key) {
		let messages = null;
		const locales = fallbackWithLocaleChain(_context, _fallbackLocale.value, _locale.value);
		for (let i = 0; i < locales.length; i++) {
			const targetLocaleMessages = _messages.value[locales[i]] || {};
			const messageValue = _context.messageResolver(targetLocaleMessages, key);
			if (messageValue != null) {
				messages = messageValue;
				break;
			}
		}
		return messages;
	}
	// tm
	function tm(key) {
		const messages = resolveMessages(key);
		// prettier-ignore
		return messages != null ? messages : __root ? __root.tm(key) || {} : {};
	}
	// getLocaleMessage
	function getLocaleMessage(locale) {
		return _messages.value[locale] || {};
	}
	// setLocaleMessage
	function setLocaleMessage(locale, message) {
		if (flatJson) {
			const _message = { [locale]: message };
			for (const key in _message) {
				if (hasOwn(_message, key)) {
					handleFlatJson(_message[key]);
				}
			}
			message = _message[locale];
		}
		_messages.value[locale] = message;
		_context.messages = _messages.value;
	}
	// mergeLocaleMessage
	function mergeLocaleMessage(locale, message) {
		_messages.value[locale] = _messages.value[locale] || {};
		const _message = { [locale]: message };
		if (flatJson) {
			for (const key in _message) {
				if (hasOwn(_message, key)) {
					handleFlatJson(_message[key]);
				}
			}
		}
		message = _message[locale];
		deepCopy(message, _messages.value[locale]);
		_context.messages = _messages.value;
	}
	// getDateTimeFormat
	function getDateTimeFormat(locale) {
		return _datetimeFormats.value[locale] || {};
	}
	// setDateTimeFormat
	function setDateTimeFormat(locale, format) {
		_datetimeFormats.value[locale] = format;
		_context.datetimeFormats = _datetimeFormats.value;
		clearDateTimeFormat(_context, locale, format);
	}
	// mergeDateTimeFormat
	function mergeDateTimeFormat(locale, format) {
		_datetimeFormats.value[locale] = assign(_datetimeFormats.value[locale] || {}, format);
		_context.datetimeFormats = _datetimeFormats.value;
		clearDateTimeFormat(_context, locale, format);
	}
	// getNumberFormat
	function getNumberFormat(locale) {
		return _numberFormats.value[locale] || {};
	}
	// setNumberFormat
	function setNumberFormat(locale, format) {
		_numberFormats.value[locale] = format;
		_context.numberFormats = _numberFormats.value;
		clearNumberFormat(_context, locale, format);
	}
	// mergeNumberFormat
	function mergeNumberFormat(locale, format) {
		_numberFormats.value[locale] = assign(_numberFormats.value[locale] || {}, format);
		_context.numberFormats = _numberFormats.value;
		clearNumberFormat(_context, locale, format);
	}
	// for debug
	composerID++;
	// watch root locale & fallbackLocale
	if (__root && inBrowser) {
		watch(__root.locale, (val) => {
			if (_inheritLocale) {
				_locale.value = val;
				_context.locale = val;
				updateFallbackLocale(_context, _locale.value, _fallbackLocale.value);
			}
		});
		watch(__root.fallbackLocale, (val) => {
			if (_inheritLocale) {
				_fallbackLocale.value = val;
				_context.fallbackLocale = val;
				updateFallbackLocale(_context, _locale.value, _fallbackLocale.value);
			}
		});
	}
	// define basic composition API!
	const composer = {
		id: composerID,
		locale,
		fallbackLocale,
		get inheritLocale() {
			return _inheritLocale;
		},
		set inheritLocale(val) {
			_inheritLocale = val;
			if (val && __root) {
				_locale.value = __root.locale.value;
				_fallbackLocale.value = __root.fallbackLocale.value;
				updateFallbackLocale(_context, _locale.value, _fallbackLocale.value);
			}
		},
		get availableLocales() {
			return Object.keys(_messages.value).sort();
		},
		messages,
		get modifiers() {
			return _modifiers;
		},
		get pluralRules() {
			return _pluralRules || {};
		},
		get isGlobal() {
			return _isGlobal;
		},
		get missingWarn() {
			return _missingWarn;
		},
		set missingWarn(val) {
			_missingWarn = val;
			_context.missingWarn = _missingWarn;
		},
		get fallbackWarn() {
			return _fallbackWarn;
		},
		set fallbackWarn(val) {
			_fallbackWarn = val;
			_context.fallbackWarn = _fallbackWarn;
		},
		get fallbackRoot() {
			return _fallbackRoot;
		},
		set fallbackRoot(val) {
			_fallbackRoot = val;
		},
		get fallbackFormat() {
			return _fallbackFormat;
		},
		set fallbackFormat(val) {
			_fallbackFormat = val;
			_context.fallbackFormat = _fallbackFormat;
		},
		get warnHtmlMessage() {
			return _warnHtmlMessage;
		},
		set warnHtmlMessage(val) {
			_warnHtmlMessage = val;
			_context.warnHtmlMessage = val;
		},
		get escapeParameter() {
			return _escapeParameter;
		},
		set escapeParameter(val) {
			_escapeParameter = val;
			_context.escapeParameter = val;
		},
		t,
		getLocaleMessage,
		setLocaleMessage,
		mergeLocaleMessage,
		getPostTranslationHandler,
		setPostTranslationHandler,
		getMissingHandler,
		setMissingHandler,
		[SetPluralRulesSymbol]: setPluralRules
	};
	{
		composer.datetimeFormats = datetimeFormats;
		composer.numberFormats = numberFormats;
		composer.rt = rt;
		composer.te = te;
		composer.tm = tm;
		composer.d = d;
		composer.n = n;
		composer.getDateTimeFormat = getDateTimeFormat;
		composer.setDateTimeFormat = setDateTimeFormat;
		composer.mergeDateTimeFormat = mergeDateTimeFormat;
		composer.getNumberFormat = getNumberFormat;
		composer.setNumberFormat = setNumberFormat;
		composer.mergeNumberFormat = mergeNumberFormat;
		composer[InejctWithOptionSymbol] = __injectWithOption;
		composer[TranslateVNodeSymbol] = translateVNode;
		composer[DatetimePartsSymbol] = datetimeParts;
		composer[NumberPartsSymbol] = numberParts;
	}
	// for vue-devtools timeline event
	if ("development" !== "production") {
		composer[EnableEmitter] = (emitter) => {
			_context.__v_emitter = emitter;
		};
		composer[DisableEmitter] = () => {
			_context.__v_emitter = undefined;
		};
	}
	return composer;
}
/* eslint-enable @typescript-eslint/no-explicit-any */
const VUE_I18N_COMPONENT_TYPES = "vue-i18n: composer properties";
const VueDevToolsLabels = {
	"vue-devtools-plugin-vue-i18n": "Vue I18n DevTools",
	"vue-i18n-resource-inspector": "Vue I18n DevTools",
	"vue-i18n-timeline": "Vue I18n"
};
const VueDevToolsPlaceholders = { "vue-i18n-resource-inspector": "Search for scopes ..." };
const VueDevToolsTimelineColors = { "vue-i18n-timeline": 16764185 };
let devtoolsApi;
async function enableDevTools(app, i18n) {
	return new Promise((resolve, reject) => {
		try {
			setupDevtoolsPlugin({
				id: "vue-devtools-plugin-vue-i18n",
				label: VueDevToolsLabels["vue-devtools-plugin-vue-i18n"],
				packageName: "vue-i18n",
				homepage: "https://vue-i18n.intlify.dev",
				logo: "https://vue-i18n.intlify.dev/vue-i18n-devtools-logo.png",
				componentStateTypes: [VUE_I18N_COMPONENT_TYPES],
				app
			}, (api) => {
				devtoolsApi = api;
				api.on.visitComponentTree(({ componentInstance, treeNode }) => {
					updateComponentTreeTags(componentInstance, treeNode, i18n);
				});
				api.on.inspectComponent(({ componentInstance, instanceData }) => {
					if (componentInstance.__VUE_I18N__ && instanceData) {
						if (i18n.mode === "legacy") {
							// ignore global scope on legacy mode
							if (componentInstance.__VUE_I18N__ !== i18n.global.__composer) {
								inspectComposer(instanceData, componentInstance.__VUE_I18N__);
							}
						} else {
							inspectComposer(instanceData, componentInstance.__VUE_I18N__);
						}
					}
				});
				api.addInspector({
					id: "vue-i18n-resource-inspector",
					label: VueDevToolsLabels["vue-i18n-resource-inspector"],
					icon: "language",
					treeFilterPlaceholder: VueDevToolsPlaceholders["vue-i18n-resource-inspector"]
				});
				api.on.getInspectorTree((payload) => {
					if (payload.app === app && payload.inspectorId === "vue-i18n-resource-inspector") {
						registerScope(payload, i18n);
					}
				});
				const roots = new Map();
				api.on.getInspectorState(async (payload) => {
					if (payload.app === app && payload.inspectorId === "vue-i18n-resource-inspector") {
						api.unhighlightElement();
						inspectScope(payload, i18n);
						if (payload.nodeId === "global") {
							if (!roots.has(payload.app)) {
								const [root] = await api.getComponentInstances(payload.app);
								roots.set(payload.app, root);
							}
							api.highlightElement(roots.get(payload.app));
						} else {
							const instance = getComponentInstance(payload.nodeId, i18n);
							instance && api.highlightElement(instance);
						}
					}
				});
				api.on.editInspectorState((payload) => {
					if (payload.app === app && payload.inspectorId === "vue-i18n-resource-inspector") {
						editScope(payload, i18n);
					}
				});
				api.addTimelineLayer({
					id: "vue-i18n-timeline",
					label: VueDevToolsLabels["vue-i18n-timeline"],
					color: VueDevToolsTimelineColors["vue-i18n-timeline"]
				});
				resolve(true);
			});
		} catch (e) {
			console.error(e);
			// eslint-disable-next-line @typescript-eslint/prefer-promise-reject-errors
			reject(false);
		}
	});
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function getI18nScopeLable(instance) {
	return instance.type.name || instance.type.displayName || instance.type.__file || "Anonymous";
}
function updateComponentTreeTags(instance, treeNode, i18n) {
	// prettier-ignore
	const global = i18n.mode === "composition" ? i18n.global : i18n.global.__composer;
	if (instance && instance.__VUE_I18N__) {
		// add custom tags local scope only
		if (instance.__VUE_I18N__ !== global) {
			const tag = {
				label: `i18n (${getI18nScopeLable(instance)} Scope)`,
				textColor: 0,
				backgroundColor: 16764185
			};
			treeNode.tags.push(tag);
		}
	}
}
function inspectComposer(instanceData, composer) {
	const type = VUE_I18N_COMPONENT_TYPES;
	instanceData.state.push({
		type,
		key: "locale",
		editable: true,
		value: composer.locale.value
	});
	instanceData.state.push({
		type,
		key: "availableLocales",
		editable: false,
		value: composer.availableLocales
	});
	instanceData.state.push({
		type,
		key: "fallbackLocale",
		editable: true,
		value: composer.fallbackLocale.value
	});
	instanceData.state.push({
		type,
		key: "inheritLocale",
		editable: true,
		value: composer.inheritLocale
	});
	instanceData.state.push({
		type,
		key: "messages",
		editable: false,
		value: getLocaleMessageValue(composer.messages.value)
	});
	{
		instanceData.state.push({
			type,
			key: "datetimeFormats",
			editable: false,
			value: composer.datetimeFormats.value
		});
		instanceData.state.push({
			type,
			key: "numberFormats",
			editable: false,
			value: composer.numberFormats.value
		});
	}
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function getLocaleMessageValue(messages) {
	const value = {};
	Object.keys(messages).forEach((key) => {
		const v = messages[key];
		if (isFunction(v) && "source" in v) {
			value[key] = getMessageFunctionDetails(v);
		} else if (isMessageAST(v) && v.loc && v.loc.source) {
			value[key] = v.loc.source;
		} else if (isObject(v)) {
			value[key] = getLocaleMessageValue(v);
		} else {
			value[key] = v;
		}
	});
	return value;
}
const ESC = {
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"&": "&amp;"
};
function escape(s) {
	return s.replace(/[<>"&]/g, escapeChar);
}
function escapeChar(a) {
	return ESC[a] || a;
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function getMessageFunctionDetails(func) {
	const argString = func.source ? `("${escape(func.source)}")` : `(?)`;
	return { _custom: {
		type: "function",
		display: `<span>ƒ</span> ${argString}`
	} };
}
function registerScope(payload, i18n) {
	payload.rootNodes.push({
		id: "global",
		label: "Global Scope"
	});
	// prettier-ignore
	const global = i18n.mode === "composition" ? i18n.global : i18n.global.__composer;
	for (const [keyInstance, instance] of i18n.__instances) {
		// prettier-ignore
		const composer = i18n.mode === "composition" ? instance : instance.__composer;
		if (global === composer) {
			continue;
		}
		payload.rootNodes.push({
			id: composer.id.toString(),
			label: `${getI18nScopeLable(keyInstance)} Scope`
		});
	}
}
function getComponentInstance(nodeId, i18n) {
	let instance = null;
	if (nodeId !== "global") {
		for (const [component, composer] of i18n.__instances.entries()) {
			if (composer.id.toString() === nodeId) {
				instance = component;
				break;
			}
		}
	}
	return instance;
}
function getComposer$2(nodeId, i18n) {
	if (nodeId === "global") {
		return i18n.mode === "composition" ? i18n.global : i18n.global.__composer;
	} else {
		const instance = Array.from(i18n.__instances.values()).find((item) => item.id.toString() === nodeId);
		if (instance) {
			return i18n.mode === "composition" ? instance : instance.__composer;
		} else {
			return null;
		}
	}
}
function inspectScope(payload, i18n) {
	const composer = getComposer$2(payload.nodeId, i18n);
	if (composer) {
		// TODO:
		// eslint-disable-next-line @typescript-eslint/no-explicit-any
		payload.state = makeScopeInspectState(composer);
	}
	return null;
}
function makeScopeInspectState(composer) {
	const state = {};
	const localeType = "Locale related info";
	const localeStates = [
		{
			type: localeType,
			key: "locale",
			editable: true,
			value: composer.locale.value
		},
		{
			type: localeType,
			key: "fallbackLocale",
			editable: true,
			value: composer.fallbackLocale.value
		},
		{
			type: localeType,
			key: "availableLocales",
			editable: false,
			value: composer.availableLocales
		},
		{
			type: localeType,
			key: "inheritLocale",
			editable: true,
			value: composer.inheritLocale
		}
	];
	state[localeType] = localeStates;
	const localeMessagesType = "Locale messages info";
	const localeMessagesStates = [{
		type: localeMessagesType,
		key: "messages",
		editable: false,
		value: getLocaleMessageValue(composer.messages.value)
	}];
	state[localeMessagesType] = localeMessagesStates;
	{
		const datetimeFormatsType = "Datetime formats info";
		const datetimeFormatsStates = [{
			type: datetimeFormatsType,
			key: "datetimeFormats",
			editable: false,
			value: composer.datetimeFormats.value
		}];
		state[datetimeFormatsType] = datetimeFormatsStates;
		const numberFormatsType = "Datetime formats info";
		const numberFormatsStates = [{
			type: numberFormatsType,
			key: "numberFormats",
			editable: false,
			value: composer.numberFormats.value
		}];
		state[numberFormatsType] = numberFormatsStates;
	}
	return state;
}
function addTimelineEvent(event, payload) {
	if (devtoolsApi) {
		let groupId;
		if (payload && "groupId" in payload) {
			groupId = payload.groupId;
			delete payload.groupId;
		}
		devtoolsApi.addTimelineEvent({
			layerId: "vue-i18n-timeline",
			event: {
				title: event,
				groupId,
				time: Date.now(),
				meta: {},
				data: payload || {},
				logType: event === "compile-error" ? "error" : event === "fallback" || event === "missing" ? "warning" : "default"
			}
		});
	}
}
function editScope(payload, i18n) {
	const composer = getComposer$2(payload.nodeId, i18n);
	if (composer) {
		const [field] = payload.path;
		if (field === "locale" && isString(payload.state.value)) {
			composer.locale.value = payload.state.value;
		} else if (field === "fallbackLocale" && (isString(payload.state.value) || isArray(payload.state.value) || isObject(payload.state.value))) {
			composer.fallbackLocale.value = payload.state.value;
		} else if (field === "inheritLocale" && isBoolean(payload.state.value)) {
			composer.inheritLocale = payload.state.value;
		}
	}
}
/* eslint-disable @typescript-eslint/no-explicit-any */
/**
* Convert to I18n Composer Options from VueI18n Options
*
* @internal
*/
function convertComposerOptions(options) {
	const locale = isString(options.locale) ? options.locale : DEFAULT_LOCALE;
	const fallbackLocale = isString(options.fallbackLocale) || isArray(options.fallbackLocale) || isPlainObject(options.fallbackLocale) || options.fallbackLocale === false ? options.fallbackLocale : locale;
	const missing = isFunction(options.missing) ? options.missing : undefined;
	const missingWarn = isBoolean(options.silentTranslationWarn) || isRegExp(options.silentTranslationWarn) ? !options.silentTranslationWarn : true;
	const fallbackWarn = isBoolean(options.silentFallbackWarn) || isRegExp(options.silentFallbackWarn) ? !options.silentFallbackWarn : true;
	const fallbackRoot = isBoolean(options.fallbackRoot) ? options.fallbackRoot : true;
	const fallbackFormat = !!options.formatFallbackMessages;
	const modifiers = isPlainObject(options.modifiers) ? options.modifiers : {};
	const pluralizationRules = options.pluralizationRules;
	const postTranslation = isFunction(options.postTranslation) ? options.postTranslation : undefined;
	const warnHtmlMessage = isString(options.warnHtmlInMessage) ? options.warnHtmlInMessage !== "off" : true;
	const escapeParameter = !!options.escapeParameterHtml;
	const inheritLocale = isBoolean(options.sync) ? options.sync : true;
	let messages = options.messages;
	if (isPlainObject(options.sharedMessages)) {
		const sharedMessages = options.sharedMessages;
		const locales = Object.keys(sharedMessages);
		messages = locales.reduce((messages, locale) => {
			const message = messages[locale] || (messages[locale] = {});
			assign(message, sharedMessages[locale]);
			return messages;
		}, messages || {});
	}
	const { __i18n, __root, __injectWithOption } = options;
	const datetimeFormats = options.datetimeFormats;
	const numberFormats = options.numberFormats;
	const flatJson = options.flatJson;
	return {
		locale,
		fallbackLocale,
		messages,
		flatJson,
		datetimeFormats,
		numberFormats,
		missing,
		missingWarn,
		fallbackWarn,
		fallbackRoot,
		fallbackFormat,
		modifiers,
		pluralRules: pluralizationRules,
		postTranslation,
		warnHtmlMessage,
		escapeParameter,
		messageResolver: options.messageResolver,
		inheritLocale,
		__i18n,
		__root,
		__injectWithOption
	};
}
/**
* create VueI18n interface factory
*
* @internal
*
* @deprecated will be removed at vue-i18n v12
*/
function createVueI18n(options = {}) {
	const composer = createComposer(convertComposerOptions(options));
	const { __extender } = options;
	// defines VueI18n
	const vueI18n = {
		// id
		id: composer.id,
		// locale
		get locale() {
			return composer.locale.value;
		},
		set locale(val) {
			composer.locale.value = val;
		},
		// fallbackLocale
		get fallbackLocale() {
			return composer.fallbackLocale.value;
		},
		set fallbackLocale(val) {
			composer.fallbackLocale.value = val;
		},
		// messages
		get messages() {
			return composer.messages.value;
		},
		// datetimeFormats
		get datetimeFormats() {
			return composer.datetimeFormats.value;
		},
		// numberFormats
		get numberFormats() {
			return composer.numberFormats.value;
		},
		// availableLocales
		get availableLocales() {
			return composer.availableLocales;
		},
		// missing
		get missing() {
			return composer.getMissingHandler();
		},
		set missing(handler) {
			composer.setMissingHandler(handler);
		},
		// silentTranslationWarn
		get silentTranslationWarn() {
			return isBoolean(composer.missingWarn) ? !composer.missingWarn : composer.missingWarn;
		},
		set silentTranslationWarn(val) {
			composer.missingWarn = isBoolean(val) ? !val : val;
		},
		// silentFallbackWarn
		get silentFallbackWarn() {
			return isBoolean(composer.fallbackWarn) ? !composer.fallbackWarn : composer.fallbackWarn;
		},
		set silentFallbackWarn(val) {
			composer.fallbackWarn = isBoolean(val) ? !val : val;
		},
		// modifiers
		get modifiers() {
			return composer.modifiers;
		},
		// formatFallbackMessages
		get formatFallbackMessages() {
			return composer.fallbackFormat;
		},
		set formatFallbackMessages(val) {
			composer.fallbackFormat = val;
		},
		// postTranslation
		get postTranslation() {
			return composer.getPostTranslationHandler();
		},
		set postTranslation(handler) {
			composer.setPostTranslationHandler(handler);
		},
		// sync
		get sync() {
			return composer.inheritLocale;
		},
		set sync(val) {
			composer.inheritLocale = val;
		},
		// warnInHtmlMessage
		get warnHtmlInMessage() {
			return composer.warnHtmlMessage ? "warn" : "off";
		},
		set warnHtmlInMessage(val) {
			composer.warnHtmlMessage = val !== "off";
		},
		// escapeParameterHtml
		get escapeParameterHtml() {
			return composer.escapeParameter;
		},
		set escapeParameterHtml(val) {
			composer.escapeParameter = val;
		},
		// pluralizationRules
		get pluralizationRules() {
			return composer.pluralRules || {};
		},
		// for internal
		__composer: composer,
		// t
		t(...args) {
			return Reflect.apply(composer.t, composer, [...args]);
		},
		// rt
		rt(...args) {
			return Reflect.apply(composer.rt, composer, [...args]);
		},
		// te
		te(key, locale) {
			return composer.te(key, locale);
		},
		// tm
		tm(key) {
			return composer.tm(key);
		},
		// getLocaleMessage
		getLocaleMessage(locale) {
			return composer.getLocaleMessage(locale);
		},
		// setLocaleMessage
		setLocaleMessage(locale, message) {
			composer.setLocaleMessage(locale, message);
		},
		// mergeLocaleMessage
		mergeLocaleMessage(locale, message) {
			composer.mergeLocaleMessage(locale, message);
		},
		// d
		d(...args) {
			return Reflect.apply(composer.d, composer, [...args]);
		},
		// getDateTimeFormat
		getDateTimeFormat(locale) {
			return composer.getDateTimeFormat(locale);
		},
		// setDateTimeFormat
		setDateTimeFormat(locale, format) {
			composer.setDateTimeFormat(locale, format);
		},
		// mergeDateTimeFormat
		mergeDateTimeFormat(locale, format) {
			composer.mergeDateTimeFormat(locale, format);
		},
		// n
		n(...args) {
			return Reflect.apply(composer.n, composer, [...args]);
		},
		// getNumberFormat
		getNumberFormat(locale) {
			return composer.getNumberFormat(locale);
		},
		// setNumberFormat
		setNumberFormat(locale, format) {
			composer.setNumberFormat(locale, format);
		},
		// mergeNumberFormat
		mergeNumberFormat(locale, format) {
			composer.mergeNumberFormat(locale, format);
		}
	};
	vueI18n.__extender = __extender;
	// for vue-devtools timeline event
	if ("development" !== "production") {
		vueI18n.__enableEmitter = (emitter) => {
			const __composer = composer;
			__composer[EnableEmitter] && __composer[EnableEmitter](emitter);
		};
		vueI18n.__disableEmitter = () => {
			const __composer = composer;
			__composer[DisableEmitter] && __composer[DisableEmitter]();
		};
	}
	return vueI18n;
}
/* eslint-enable @typescript-eslint/no-explicit-any */
/**
* Supports compatibility for legacy vue-i18n APIs
* This mixin is used when we use vue-i18n@v9.x or later
*/
function defineMixin(vuei18n, composer, i18n) {
	return {
		beforeCreate() {
			const instance = getCurrentInstance();
			/* istanbul ignore if */
			if (!instance) {
				throw createI18nError(I18nErrorCodes.UNEXPECTED_ERROR);
			}
			const options = this.$options;
			if (options.i18n) {
				const optionsI18n = options.i18n;
				if (options.__i18n) {
					optionsI18n.__i18n = options.__i18n;
				}
				optionsI18n.__root = composer;
				if (this === this.$root) {
					// merge option and gttach global
					this.$i18n = mergeToGlobal(vuei18n, optionsI18n);
				} else {
					optionsI18n.__injectWithOption = true;
					optionsI18n.__extender = i18n.__vueI18nExtend;
					// atttach local VueI18n instance
					this.$i18n = createVueI18n(optionsI18n);
					// extend VueI18n instance
					const _vueI18n = this.$i18n;
					if (_vueI18n.__extender) {
						_vueI18n.__disposer = _vueI18n.__extender(this.$i18n);
					}
				}
			} else if (options.__i18n) {
				if (this === this.$root) {
					// merge option and gttach global
					this.$i18n = mergeToGlobal(vuei18n, options);
				} else {
					// atttach local VueI18n instance
					this.$i18n = createVueI18n({
						__i18n: options.__i18n,
						__injectWithOption: true,
						__extender: i18n.__vueI18nExtend,
						__root: composer
					});
					// extend VueI18n instance
					const _vueI18n = this.$i18n;
					if (_vueI18n.__extender) {
						_vueI18n.__disposer = _vueI18n.__extender(this.$i18n);
					}
				}
			} else {
				// attach global VueI18n instance
				this.$i18n = vuei18n;
			}
			if (options.__i18nGlobal) {
				adjustI18nResources(composer, options, options);
			}
			// defines vue-i18n legacy APIs
			this.$t = (...args) => this.$i18n.t(...args);
			this.$rt = (...args) => this.$i18n.rt(...args);
			this.$te = (key, locale) => this.$i18n.te(key, locale);
			this.$d = (...args) => this.$i18n.d(...args);
			this.$n = (...args) => this.$i18n.n(...args);
			this.$tm = (key) => this.$i18n.tm(key);
			i18n.__setInstance(instance, this.$i18n);
		},
		mounted() {
			/* istanbul ignore if */
			if (("development" !== "production" || __VUE_PROD_DEVTOOLS__) && true && this.$i18n) {
				const instance = getCurrentInstance();
				if (!instance) {
					return;
				}
				const _vueI18n = this.$i18n;
				instance.__VUE_I18N__ = _vueI18n.__composer;
				const emitter = this.__v_emitter = createEmitter();
				_vueI18n.__enableEmitter && _vueI18n.__enableEmitter(emitter);
				emitter.on("*", addTimelineEvent);
			}
		},
		unmounted() {
			const instance = getCurrentInstance();
			/* istanbul ignore if */
			if (!instance) {
				throw createI18nError(I18nErrorCodes.UNEXPECTED_ERROR);
			}
			const _vueI18n = this.$i18n;
			/* istanbul ignore if */
			if (("development" !== "production" || __VUE_PROD_DEVTOOLS__) && true && instance.__VUE_I18N__) {
				if (this.__v_emitter) {
					this.__v_emitter.off("*", addTimelineEvent);
					delete this.__v_emitter;
				}
				if (_vueI18n) {
					_vueI18n.__disableEmitter && _vueI18n.__disableEmitter();
					delete instance.__VUE_I18N__;
				}
			}
			// setup-only components skip beforeCreate but still run unmounted
			if (!_vueI18n) {
				return;
			}
			delete this.$t;
			delete this.$rt;
			delete this.$te;
			delete this.$d;
			delete this.$n;
			delete this.$tm;
			if (_vueI18n?.__disposer) {
				_vueI18n.__disposer();
				delete _vueI18n.__disposer;
				delete _vueI18n.__extender;
			}
			i18n.__deleteInstance(instance);
			delete this.$i18n;
		}
	};
}
function mergeToGlobal(g, options) {
	g.locale = options.locale || g.locale;
	g.fallbackLocale = options.fallbackLocale || g.fallbackLocale;
	g.missing = options.missing || g.missing;
	g.silentTranslationWarn = options.silentTranslationWarn || g.silentFallbackWarn;
	g.silentFallbackWarn = options.silentFallbackWarn || g.silentFallbackWarn;
	g.formatFallbackMessages = options.formatFallbackMessages || g.formatFallbackMessages;
	g.postTranslation = options.postTranslation || g.postTranslation;
	g.warnHtmlInMessage = options.warnHtmlInMessage || g.warnHtmlInMessage;
	g.escapeParameterHtml = options.escapeParameterHtml || g.escapeParameterHtml;
	g.sync = options.sync || g.sync;
	g.__composer[SetPluralRulesSymbol](options.pluralizationRules || g.pluralizationRules);
	const messages = getLocaleMessages(g.locale, {
		messages: options.messages,
		__i18n: options.__i18n
	});
	Object.keys(messages).forEach((locale) => g.mergeLocaleMessage(locale, messages[locale]));
	if (options.datetimeFormats) {
		Object.keys(options.datetimeFormats).forEach((locale) => g.mergeDateTimeFormat(locale, options.datetimeFormats[locale]));
	}
	if (options.numberFormats) {
		Object.keys(options.numberFormats).forEach((locale) => g.mergeNumberFormat(locale, options.numberFormats[locale]));
	}
	return g;
}
const baseFormatProps = {
	tag: { type: [String, Object] },
	locale: { type: String },
	scope: {
		type: String,
		// NOTE: avoid https://github.com/microsoft/rushstack/issues/1050
		validator: (val) => val === "parent" || val === "global",
		default: "parent"
	},
	i18n: { type: Object }
};
function getInterpolateArg({ slots }, keys) {
	if (keys.length === 1 && keys[0] === "default") {
		// default slot with list
		const ret = slots.default ? slots.default() : [];
		// eslint-disable-next-line @typescript-eslint/no-explicit-any
		return ret.reduce((slot, current) => {
			return [...slot, ...current.type === Fragment ? current.children : [current]];
		}, []);
	} else {
		// named slots
		return keys.reduce((arg, key) => {
			const slot = slots[key];
			if (slot) {
				arg[key] = slot();
			}
			return arg;
		}, create());
	}
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function getFragmentableTag() {
	return Fragment;
}
const TranslationImpl = /*#__PURE__*/ defineComponent({
	/* eslint-disable */
	name: "i18n-t",
	props: assign({
		keypath: {
			type: String,
			required: true
		},
		plural: {
			type: [Number, String],
			validator: (val) => isNumber(val) || !isNaN(val)
		}
	}, baseFormatProps),
	/* eslint-enable */
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	setup(props, context) {
		const { slots, attrs } = context;
		// NOTE: avoid https://github.com/microsoft/rushstack/issues/1050
		const i18n = props.i18n || useI18n({
			useScope: props.scope,
			__useComponent: true
		});
		return () => {
			const renderChildren = () => {
				const keys = Object.keys(slots).filter((key) => key[0] !== "_");
				const options = create();
				if (props.locale) {
					options.locale = props.locale;
				}
				if (props.plural !== undefined) {
					options.plural = isString(props.plural) ? +props.plural : props.plural;
				}
				const arg = getInterpolateArg(context, keys);
				// eslint-disable-next-line @typescript-eslint/no-explicit-any
				return i18n[TranslateVNodeSymbol](props.keypath, arg, options);
			};
			const assignedAttrs = assign(create(), attrs);
			const tag = isString(props.tag) || isObject(props.tag) ? props.tag : getFragmentableTag();
			return isObject(tag) ? h(tag, assignedAttrs, { default: renderChildren }) : h(tag, assignedAttrs, renderChildren());
		};
	}
});
/**
* export the public type for h/tsx inference
* also to avoid inline import() in generated d.ts files
*/
/**
* Translation Component
*
* @remarks
* See the following items for property about details
*
* @VueI18nSee [TranslationProps](component#translationprops)
* @VueI18nSee [BaseFormatProps](component#baseformatprops)
* @VueI18nSee [Component Interpolation](../guide/advanced/component)
*
* @example
* ```html
* <div id="app">
*   <!-- ... -->
*   <i18n keypath="term" tag="label" for="tos">
*     <a :href="url" target="_blank">{{ $t('tos') }}</a>
*   </i18n>
*   <!-- ... -->
* </div>
* ```
* ```js
* import { createApp } from 'vue'
* import { createI18n } from 'vue-i18n'
*
* const messages = {
*   en: {
*     tos: 'Term of Service',
*     term: 'I accept xxx {0}.'
*   },
*   ja: {
*     tos: '利用規約',
*     term: '私は xxx の{0}に同意します。'
*   }
* }
*
* const i18n = createI18n({
*   locale: 'en',
*   messages
* })
*
* const app = createApp({
*   data: {
*     url: '/term'
*   }
* }).use(i18n).mount('#app')
* ```
*
* @VueI18nComponent
*/
const Translation = TranslationImpl;
const I18nT = Translation;
function isVNode(target) {
	return isArray(target) && !isString(target[0]);
}
function renderFormatter(props, context, slotKeys, partFormatter) {
	const { slots, attrs } = context;
	return () => {
		const renderChildren = () => {
			const options = { part: true };
			let overrides = create();
			if (props.locale) {
				options.locale = props.locale;
			}
			if (isString(props.format)) {
				options.key = props.format;
			} else if (isObject(props.format)) {
				// eslint-disable-next-line @typescript-eslint/no-explicit-any
				if (isString(props.format.key)) {
					// eslint-disable-next-line @typescript-eslint/no-explicit-any
					options.key = props.format.key;
				}
				// Filter out number format options only
				overrides = Object.keys(props.format).reduce((options, prop) => {
					return slotKeys.includes(prop) ? assign(create(), options, { [prop]: props.format[prop] }) : options;
				}, create());
			}
			const parts = partFormatter(...[
				props.value,
				options,
				overrides
			]);
			let children = [options.key];
			if (isArray(parts)) {
				children = parts.map((part, index) => {
					const slot = slots[part.type];
					const node = slot ? slot({
						[part.type]: part.value,
						index,
						parts
					}) : [part.value];
					if (isVNode(node)) {
						node[0].key = `${part.type}-${index}`;
					}
					return node;
				});
			} else if (isString(parts)) {
				children = [parts];
			}
			return children;
		};
		const assignedAttrs = assign(create(), attrs);
		const tag = isString(props.tag) || isObject(props.tag) ? props.tag : getFragmentableTag();
		return isObject(tag) ? h(tag, assignedAttrs, { default: renderChildren }) : h(tag, assignedAttrs, renderChildren());
	};
}
const NumberFormatImpl = /*#__PURE__*/ defineComponent({
	/* eslint-disable */
	name: "i18n-n",
	props: assign({
		value: {
			type: Number,
			required: true
		},
		format: { type: [String, Object] }
	}, baseFormatProps),
	/* eslint-enable */
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	setup(props, context) {
		const i18n = props.i18n || useI18n({
			useScope: props.scope,
			__useComponent: true
		});
		return renderFormatter(props, context, NUMBER_FORMAT_OPTIONS_KEYS, (...args) => i18n[NumberPartsSymbol](...args));
	}
});
/**
* export the public type for h/tsx inference
* also to avoid inline import() in generated d.ts files
*/
/**
* Number Format Component
*
* @remarks
* See the following items for property about details
*
* @VueI18nSee [FormattableProps](component#formattableprops)
* @VueI18nSee [BaseFormatProps](component#baseformatprops)
* @VueI18nSee [Custom Formatting](../guide/essentials/number#custom-formatting)
*
* @VueI18nDanger
* Not supported IE, due to no support `Intl.NumberFormat#formatToParts` in [IE](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/NumberFormat/formatToParts)
*
* If you want to use it, you need to use [polyfill](https://github.com/formatjs/formatjs/tree/main/packages/intl-numberformat)
*
* @VueI18nComponent
*/
const NumberFormat = NumberFormatImpl;
const I18nN = NumberFormat;
function getComposer$1(i18n, instance) {
	const i18nInternal = i18n;
	if (i18n.mode === "composition") {
		return i18nInternal.__getInstance(instance) || i18n.global;
	} else {
		const vueI18n = i18nInternal.__getInstance(instance);
		return vueI18n != null ? vueI18n.__composer : i18n.global.__composer;
	}
}
/**
* @deprecated will be removed at vue-i18n v12
*/
function vTDirective(i18n) {
	const _process = (binding) => {
		if ("development" !== "production") {
			warnOnce(getWarnMessage(I18nWarnCodes.DEPRECATE_TRANSLATE_CUSTOME_DIRECTIVE));
		}
		const { instance, value } = binding;
		/* istanbul ignore if */
		if (!instance || !instance.$) {
			throw createI18nError(I18nErrorCodes.UNEXPECTED_ERROR);
		}
		const composer = getComposer$1(i18n, instance.$);
		const parsedValue = parseValue(value);
		return [Reflect.apply(composer.t, composer, [...makeParams(parsedValue)]), composer];
	};
	const register = (el, binding) => {
		const [textContent, composer] = _process(binding);
		if (inBrowser) {
			el.__i18nWatcher = watch(composer.locale, () => {
				binding.instance && binding.instance.$forceUpdate();
			});
		}
		el.__composer = composer;
		el.textContent = textContent;
	};
	const unregister = (el) => {
		if (inBrowser && el.__i18nWatcher) {
			el.__i18nWatcher();
			el.__i18nWatcher = undefined;
			delete el.__i18nWatcher;
		}
		if (el.__composer) {
			el.__composer = undefined;
			delete el.__composer;
		}
	};
	const update = (el, { value }) => {
		if (el.__composer) {
			const composer = el.__composer;
			const parsedValue = parseValue(value);
			el.textContent = Reflect.apply(composer.t, composer, [...makeParams(parsedValue)]);
		}
	};
	const getSSRProps = (binding) => {
		const [textContent] = _process(binding);
		return { textContent };
	};
	return {
		created: register,
		unmounted: unregister,
		beforeUpdate: update,
		getSSRProps
	};
}
function parseValue(value) {
	if (isString(value)) {
		return { path: value };
	} else if (isPlainObject(value)) {
		if (!("path" in value)) {
			throw createI18nError(I18nErrorCodes.REQUIRED_VALUE, "path");
		}
		return value;
	} else {
		throw createI18nError(I18nErrorCodes.INVALID_VALUE);
	}
}
function makeParams(value) {
	const { path, locale, args, choice, plural } = value;
	const options = {};
	const named = args || {};
	if (isString(locale)) {
		options.locale = locale;
	}
	if (isNumber(choice)) {
		options.plural = choice;
	}
	if (isNumber(plural)) {
		options.plural = plural;
	}
	return [
		path,
		named,
		options
	];
}
function apply(app, i18n, ...options) {
	const pluginOptions = isPlainObject(options[0]) ? options[0] : {};
	const globalInstall = isBoolean(pluginOptions.globalInstall) ? pluginOptions.globalInstall : true;
	if (globalInstall) {
		[Translation.name, "I18nT"].forEach((name) => app.component(name, Translation));
		[NumberFormat.name, "I18nN"].forEach((name) => app.component(name, NumberFormat));
		[DatetimeFormat.name, "I18nD"].forEach((name) => app.component(name, DatetimeFormat));
	}
	// install directive
	{
		app.directive("t", vTDirective(i18n));
	}
}
/**
* Injection key for {@link useI18n}
*
* @remarks
* The global injection key for I18n instances with `useI18n`. this injection key is used in Web Components.
* Specify the i18n instance created by {@link createI18n} together with `provide` function.
*
* @VueI18nGeneral
*/
const I18nInjectionKey = /* #__PURE__*/ makeSymbol("global-vue-i18n");
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function createI18n(options = {}) {
	// prettier-ignore
	const __legacyMode = __VUE_I18N_LEGACY_API__ && isBoolean(options.legacy) ? options.legacy : __VUE_I18N_LEGACY_API__;
	if ("development" !== "production" && __legacyMode) {
		warnOnce(getWarnMessage(I18nWarnCodes.DEPRECATE_LEGACY_MODE));
	}
	// prettier-ignore
	const __globalInjection = isBoolean(options.globalInjection) ? options.globalInjection : true;
	const __instances = new Map();
	const [globalScope, __global] = createGlobal(options, __legacyMode);
	const symbol = /* #__PURE__*/ makeSymbol("development" !== "production" ? "vue-i18n" : "");
	function __getInstance(component) {
		return __instances.get(component) || null;
	}
	function __setInstance(component, instance) {
		__instances.set(component, instance);
	}
	function __deleteInstance(component) {
		__instances.delete(component);
	}
	const i18n = {
		// mode
		get mode() {
			return __VUE_I18N_LEGACY_API__ && __legacyMode ? "legacy" : "composition";
		},
		// install plugin
		async install(app, ...options) {
			if (("development" !== "production" || __VUE_PROD_DEVTOOLS__) && true) {
				app.__VUE_I18N__ = i18n;
			}
			// setup global provider
			app.__VUE_I18N_SYMBOL__ = symbol;
			app.provide(app.__VUE_I18N_SYMBOL__, i18n);
			// set composer & vuei18n extend hook options from plugin options
			if (isPlainObject(options[0])) {
				const opts = options[0];
				i18n.__composerExtend = opts.__composerExtend;
				i18n.__vueI18nExtend = opts.__vueI18nExtend;
			}
			// global method and properties injection for Composition API
			let globalReleaseHandler = null;
			if (!__legacyMode && __globalInjection) {
				globalReleaseHandler = injectGlobalFields(app, i18n.global);
			}
			// install built-in components and directive
			if (__VUE_I18N_FULL_INSTALL__) {
				apply(app, i18n, ...options);
			}
			// setup mixin for Legacy API
			if (__VUE_I18N_LEGACY_API__ && __legacyMode) {
				app.mixin(defineMixin(__global, __global.__composer, i18n));
			}
			// release global scope
			const unmountApp = app.unmount;
			app.unmount = () => {
				globalReleaseHandler && globalReleaseHandler();
				i18n.dispose();
				unmountApp();
			};
			// setup vue-devtools plugin
			if (("development" !== "production" || __VUE_PROD_DEVTOOLS__) && true) {
				const ret = await enableDevTools(app, i18n);
				if (!ret) {
					throw createI18nError(I18nErrorCodes.CANNOT_SETUP_VUE_DEVTOOLS_PLUGIN);
				}
				const emitter = createEmitter();
				if (__legacyMode) {
					const _vueI18n = __global;
					_vueI18n.__enableEmitter && _vueI18n.__enableEmitter(emitter);
				} else {
					// eslint-disable-next-line @typescript-eslint/no-explicit-any
					const _composer = __global;
					_composer[EnableEmitter] && _composer[EnableEmitter](emitter);
				}
				emitter.on("*", addTimelineEvent);
			}
		},
		// global accessor
		get global() {
			return __global;
		},
		dispose() {
			globalScope.stop();
		},
		// @internal
		__instances,
		// @internal
		__getInstance,
		// @internal
		__setInstance,
		// @internal
		__deleteInstance
	};
	return i18n;
}
function useI18n(options = {}) {
	const instance = getCurrentInstance();
	if (instance == null) {
		throw createI18nError(I18nErrorCodes.MUST_BE_CALL_SETUP_TOP);
	}
	if (!instance.isCE && instance.appContext.app != null && !instance.appContext.app.__VUE_I18N_SYMBOL__) {
		throw createI18nError(I18nErrorCodes.NOT_INSTALLED);
	}
	const i18n = getI18nInstance(instance);
	const gl = getGlobalComposer(i18n);
	const componentOptions = getComponentOptions(instance);
	const scope = getScope(options, componentOptions);
	if (scope === "global") {
		adjustI18nResources(gl, options, componentOptions);
		return gl;
	}
	if (scope === "parent") {
		// eslint-disable-next-line @typescript-eslint/no-explicit-any
		let composer = getComposer(i18n, instance, options.__useComponent);
		if (composer == null) {
			if ("development" !== "production") {
				warn(getWarnMessage(I18nWarnCodes.NOT_FOUND_PARENT_SCOPE));
			}
			composer = gl;
		}
		return composer;
	}
	// Isolated scope - independent composer not tied to component
	if (scope === "isolated") {
		// Composition API mode only
		if (i18n.mode !== "composition") {
			throw createI18nError(I18nErrorCodes.NOT_AVAILABLE_COMPOSITION_IN_LEGACY);
		}
		const i18nInternalIso = i18n;
		const composerOptions = assign({}, options);
		// Find parent composer via parent chain (or fall back to global)
		const parentComposer = getComposer(i18n, instance);
		composerOptions.__root = parentComposer || gl;
		const composer = createComposer(composerOptions);
		// ComposerExtend hook
		if (i18nInternalIso.__composerExtend) {
			composer[DisposeSymbol] = i18nInternalIso.__composerExtend(composer);
		}
		// Setup devtools emitter (no target.__VUE_I18N__ attachment -
		// multiple isolated composers per component are allowed)
		let emitter = null;
		if (("development" !== "production" || __VUE_PROD_DEVTOOLS__) && true) {
			emitter = createEmitter();
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			const _composer = composer;
			_composer[EnableEmitter] && _composer[EnableEmitter](emitter);
			emitter.on("*", addTimelineEvent);
		}
		// Lifecycle cleanup via onScopeDispose
		const currentScope = getCurrentScope();
		if (currentScope) {
			onScopeDispose(() => {
				if (("development" !== "production" || __VUE_PROD_DEVTOOLS__) && true) {
					emitter && emitter.off("*", addTimelineEvent);
					// eslint-disable-next-line @typescript-eslint/no-explicit-any
					const _composer = composer;
					_composer[DisableEmitter] && _composer[DisableEmitter]();
				}
				// eslint-disable-next-line @typescript-eslint/no-explicit-any
				const dispose = composer[DisposeSymbol];
				if (dispose) {
					dispose();
					// eslint-disable-next-line @typescript-eslint/no-explicit-any
					delete composer[DisposeSymbol];
				}
			});
		}
		return composer;
	}
	const i18nInternal = i18n;
	let composer = i18nInternal.__getInstance(instance);
	if (composer == null) {
		const composerOptions = assign({}, options);
		if ("__i18n" in componentOptions) {
			composerOptions.__i18n = componentOptions.__i18n;
		}
		if (gl) {
			composerOptions.__root = gl;
		}
		composer = createComposer(composerOptions);
		if (i18nInternal.__composerExtend) {
			composer[DisposeSymbol] = i18nInternal.__composerExtend(composer);
		}
		setupLifeCycle(i18nInternal, instance, composer);
		i18nInternal.__setInstance(instance, composer);
	} else {
		if ("development" !== "production" && scope === "local") {
			warn(getWarnMessage(I18nWarnCodes.DUPLICATE_USE_I18N_CALLING));
		}
	}
	return composer;
}
function createGlobal(options, legacyMode) {
	const scope = effectScope();
	const obj = __VUE_I18N_LEGACY_API__ && legacyMode ? scope.run(() => createVueI18n(options)) : scope.run(() => createComposer(options));
	if (obj == null) {
		throw createI18nError(I18nErrorCodes.UNEXPECTED_ERROR);
	}
	return [scope, obj];
}
function getI18nInstance(instance) {
	const i18n = inject(!instance.isCE ? instance.appContext.app.__VUE_I18N_SYMBOL__ : I18nInjectionKey);
	/* istanbul ignore if */
	if (!i18n) {
		throw createI18nError(!instance.isCE ? I18nErrorCodes.UNEXPECTED_ERROR : I18nErrorCodes.NOT_INSTALLED_WITH_PROVIDE);
	}
	return i18n;
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function getScope(options, componentOptions) {
	// prettier-ignore
	return isEmptyObject(options) ? "__i18n" in componentOptions ? "local" : "global" : !options.useScope ? "local" : options.useScope;
}
function getGlobalComposer(i18n) {
	// prettier-ignore
	return i18n.mode === "composition" ? i18n.global : i18n.global.__composer;
}
function getComposer(i18n, target, useComponent = false) {
	let composer = null;
	const root = target.root;
	let current = getParentComponentInstance(target, useComponent);
	while (current != null) {
		const i18nInternal = i18n;
		if (i18n.mode === "composition") {
			composer = i18nInternal.__getInstance(current);
		} else {
			if (__VUE_I18N_LEGACY_API__) {
				const vueI18n = i18nInternal.__getInstance(current);
				if (vueI18n != null) {
					composer = vueI18n.__composer;
					if (useComponent && composer && !composer[InejctWithOptionSymbol]) {
						composer = null;
					}
				}
			}
		}
		if (composer != null) {
			break;
		}
		if (root === current) {
			break;
		}
		current = current.parent;
	}
	return composer;
}
function getParentComponentInstance(target, useComponent = false) {
	if (target == null) {
		return null;
	}
	// if `useComponent: true` will be specified, we get lexical scope owner instance for use-case slots
	return !useComponent ? target.parent : target.vnode.ctx || target.parent;
}
function setupLifeCycle(i18n, target, composer) {
	let emitter = null;
	onMounted(() => {
		// inject composer instance to DOM for intlify-devtools
		if (("development" !== "production" || __VUE_PROD_DEVTOOLS__) && true) {
			target.__VUE_I18N__ = composer;
			emitter = createEmitter();
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			const _composer = composer;
			_composer[EnableEmitter] && _composer[EnableEmitter](emitter);
			emitter.on("*", addTimelineEvent);
		}
	}, target);
	onUnmounted(() => {
		// eslint-disable-next-line @typescript-eslint/no-explicit-any
		const _composer = composer;
		// remove composer instance from DOM for intlify-devtools
		if (("development" !== "production" || __VUE_PROD_DEVTOOLS__) && true) {
			emitter && emitter.off("*", addTimelineEvent);
			_composer[DisableEmitter] && _composer[DisableEmitter]();
			delete target.__VUE_I18N__;
		}
		i18n.__deleteInstance(target);
		// dispose extended resources
		const dispose = _composer[DisposeSymbol];
		if (dispose) {
			dispose();
			delete _composer[DisposeSymbol];
		}
	}, target);
}
const globalExportProps = [
	"locale",
	"fallbackLocale",
	"availableLocales"
];
const globalExportMethods = [
	"t",
	"rt",
	"d",
	"n",
	"tm",
	"te"
];
function injectGlobalFields(app, composer) {
	const i18n = Object.create(null);
	globalExportProps.forEach((prop) => {
		const desc = Object.getOwnPropertyDescriptor(composer, prop);
		if (!desc) {
			throw createI18nError(I18nErrorCodes.UNEXPECTED_ERROR);
		}
		const wrap = isRef(desc.value) ? {
			get() {
				return desc.value.value;
			},
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			set(val) {
				desc.value.value = val;
			}
		} : { get() {
			return desc.get && desc.get();
		} };
		Object.defineProperty(i18n, prop, wrap);
	});
	app.config.globalProperties.$i18n = i18n;
	globalExportMethods.forEach((method) => {
		const desc = Object.getOwnPropertyDescriptor(composer, method);
		if (!desc || !desc.value) {
			throw createI18nError(I18nErrorCodes.UNEXPECTED_ERROR);
		}
		Object.defineProperty(app.config.globalProperties, `$${method}`, desc);
	});
	const dispose = () => {
		// eslint-disable-next-line @typescript-eslint/no-explicit-any
		delete app.config.globalProperties.$i18n;
		globalExportMethods.forEach((method) => {
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			delete app.config.globalProperties[`$${method}`];
		});
	};
	return dispose;
}
const DatetimeFormatImpl = /* #__PURE__*/ defineComponent({
	/* eslint-disable */
	name: "i18n-d",
	props: assign({
		value: {
			type: [Number, Date],
			required: true
		},
		format: { type: [String, Object] }
	}, baseFormatProps),
	/* eslint-enable */
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	setup(props, context) {
		const i18n = props.i18n || useI18n({
			useScope: props.scope,
			__useComponent: true
		});
		return renderFormatter(props, context, DATETIME_FORMAT_OPTIONS_KEYS, (...args) => i18n[DatetimePartsSymbol](...args));
	}
});
/**
* Datetime Format Component
*
* @remarks
* See the following items for property about details
*
* @VueI18nSee [FormattableProps](component#formattableprops)
* @VueI18nSee [BaseFormatProps](component#baseformatprops)
* @VueI18nSee [Custom Formatting](../guide/essentials/datetime#custom-formatting)
*
* @VueI18nDanger
* Not supported IE, due to no support `Intl.DateTimeFormat#formatToParts` in [IE](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/DateTimeFormat/formatToParts)
*
* If you want to use it, you need to use [polyfill](https://github.com/formatjs/formatjs/tree/main/packages/intl-datetimeformat)
*
* @VueI18nComponent
*/
const DatetimeFormat = DatetimeFormatImpl;
const I18nD = DatetimeFormat;
{
	initFeatureFlags();
}
// register message compiler at vue-i18n
registerMessageCompiler(compile);
// register message resolver at vue-i18n
registerMessageResolver(resolveValue);
// register fallback locale at vue-i18n
registerLocaleFallbacker(fallbackWithLocaleChain);
// NOTE: experimental !!
if ("development" !== "production" || __INTLIFY_PROD_DEVTOOLS__) {
	const target = getGlobalThis();
	target.__INTLIFY__ = true;
	setDevToolsHook(target.__INTLIFY_DEVTOOLS_GLOBAL_HOOK__);
}
if ("development" !== "production");
export { DatetimeFormat, I18nD, I18nInjectionKey, I18nN, I18nT, NumberFormat, Translation, VERSION, createI18n, useI18n, vTDirective };

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFLQSxTQUFTLG9CQUFvQiwrQkFBK0IsOEJBQThCLGNBQWMscUJBQXFCLGdCQUFnQixzQkFBc0Isb0JBQW9CLG1CQUFtQixxQkFBcUIsbUJBQW1CLG1CQUFtQixvQkFBb0IsY0FBYyx5QkFBeUIsd0JBQXdCLHlCQUF5QixvQkFBb0IsV0FBVyx1QkFBdUIsbUJBQW1CLFVBQVUsaUJBQWlCLFFBQVEsbUJBQW1CLDRCQUE0Qiw4QkFBOEIseUJBQXlCLFNBQVMseUJBQXlCLGNBQWMsMEJBQTBCLHVCQUF1QjtBQUNwcUIsU0FBUyxlQUFlLFlBQVksUUFBUSxVQUFVLFFBQVEsZUFBZSxTQUFTLFVBQVUsVUFBVSxRQUFRLE1BQU0sV0FBVyxVQUFVLFlBQVksV0FBVyxRQUFRLFVBQVUsZUFBZSxVQUFVLHFCQUFxQjtBQUNwTyxZQUFZLFNBQVM7QUFDckIsU0FBUyxhQUFhLE1BQU0sVUFBVSxPQUFPLEtBQUssWUFBWSxVQUFVLGlCQUFpQixHQUFHLGlCQUFpQixnQkFBZ0IsYUFBYSxRQUFRLFdBQVcsYUFBYSxhQUFhO0FBQ3ZMLFNBQVMsMkJBQTJCOzs7Ozs7Ozs7QUFVcEMsTUFBTSxVQUFVOzs7OztBQUtoQixTQUFTLG1CQUFtQjtDQUN4QixJQUFJLE9BQU8sOEJBQThCLFdBQVc7RUFDaEQsY0FBYyxDQUFDLENBQUMsNEJBQTRCO0NBQ2hEO0NBQ0EsSUFBSSxPQUFPLDRCQUE0QixXQUFXO0VBQzlDLGNBQWMsQ0FBQyxDQUFDLDBCQUEwQjtDQUM5QztDQUNBLElBQUksT0FBTyxzQ0FBc0MsV0FBVztFQUN4RCxjQUFjLENBQUMsQ0FBQyxvQ0FBb0M7Q0FDeEQ7Q0FDQSxJQUFJLE9BQU8sOEJBQThCLFdBQVc7RUFDaEQsY0FBYyxDQUFDLENBQUMsNEJBQTRCO0NBQ2hEO0FBQ0o7QUFFQSxNQUFNLGlCQUFpQjs7Q0FFbkIsd0JBQXdCOztDQUV4QixrQkFBa0I7O0NBRWxCLHdCQUF3QjtDQUN4QixlQUFlOztDQUVmLGdCQUFnQjtDQUNoQixlQUFlOztDQUVmLGtDQUFrQztDQUNsQyw0QkFBNEI7O0NBRTVCLGtCQUFrQjs7Q0FFbEIsZ0NBQWdDOztDQUVoQyxxQ0FBcUM7QUFDekM7QUFDQSxTQUFTLGdCQUFnQixNQUFNLEdBQUcsTUFBTTtDQUNwQyxPQUFPLG1CQUFtQixNQUFNLHdCQUFnQyxlQUFnQjtFQUFFLFVBQVU7RUFBZTtDQUFLLElBQUksU0FBUztBQUNqSTtBQUNBLE1BQU0sZ0JBQWdCO0VBQ2pCLGVBQWUseUJBQXlCO0VBQ3hDLGVBQWUsbUJBQW1CO0VBQ2xDLGVBQWUseUJBQXlCO0VBQ3hDLGVBQWUsZ0JBQWdCO0VBQy9CLGVBQWUsbUJBQW1CO0VBQ2xDLGVBQWUsaUJBQWlCO0VBQ2hDLGVBQWUsZ0JBQWdCO0VBQy9CLGVBQWUsbUNBQW1DO0VBQ2xELGVBQWUsNkJBQTZCO0VBQzVDLGVBQWUsaUNBQWlDO0VBQ2hELGVBQWUsc0NBQXNDO0FBQzFEO0FBRUEsTUFBTSx1QkFDUywwQkFBVyxrQkFBa0I7QUFDNUMsTUFBTSxzQkFBcUMsMEJBQVcsaUJBQWlCO0FBQ3ZFLE1BQU0sb0JBQW1DLDBCQUFXLGVBQWU7QUFDbkUsTUFBTSxnQkFBK0IsMEJBQVcsaUJBQWlCO0FBQ2pFLE1BQU0saUJBQWdDLDBCQUFXLGtCQUFrQjtBQUNuRSxNQUFNLHVCQUF1QixXQUFXLGtCQUFrQjtBQUMxRCxXQUFXLGVBQWU7QUFDMUIsTUFBTSx5QkFDUywwQkFBVyxvQkFBb0I7QUFDOUMsTUFBTSxnQkFBK0IsMEJBQVcsV0FBVztBQUUzRCxNQUFNLGdCQUFnQjtDQUNsQixrQkFBa0I7Q0FDbEIsd0JBQXlCLCtCQUErQjtDQUN4RCxvQkFBcUIsK0JBQStCOzs7O0NBSXBELHVCQUF3QiwrQkFBK0I7Ozs7Q0FJdkQsdUNBQXdDLCtCQUNwQzs7Q0FFSiw0QkFBNkIsK0JBQStCO0FBQ2hFO0FBQ0EsTUFBTSxlQUFlO0VBQ2hCLGNBQWMsbUJBQW1CO0VBQ2pDLGNBQWMseUJBQXlCO0VBQ3ZDLGNBQWMscUJBQXFCOzs7O0VBSW5DLGNBQWMsd0JBQXdCOzs7O0VBSXRDLGNBQWMsd0NBQXdDO0VBQ3RELGNBQWMsNkJBQTZCO0FBQ2hEO0FBQ0EsU0FBUyxlQUFlLE1BQU0sR0FBRyxNQUFNO0NBQ25DLE9BQU8sT0FBTyxhQUFhLE9BQU8sR0FBRyxJQUFJO0FBQzdDOzs7OztBQU1BLFNBQVMsZUFBZSxLQUFLOztDQUV6QixJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUc7RUFDaEIsT0FBTztDQUNYO0NBQ0EsSUFBSSxhQUFhLEdBQUcsR0FBRztFQUNuQixPQUFPO0NBQ1g7Q0FDQSxLQUFLLE1BQU0sT0FBTyxLQUFLOztFQUVuQixJQUFJLENBQUMsT0FBTyxLQUFLLEdBQUcsR0FBRztHQUNuQjtFQUNKOztFQUVBLElBQUksQ0FBQyxJQUFJLFNBQVMsR0FBRyxHQUFHOztHQUVwQixJQUFJLFNBQVMsSUFBSSxJQUFJLEdBQUc7SUFDcEIsZUFBZSxJQUFJLElBQUk7R0FDM0I7RUFDSixPQUVLOztHQUVELE1BQU0sVUFBVSxJQUFJLE1BQU0sR0FBRztHQUM3QixNQUFNLFlBQVksUUFBUSxTQUFTO0dBQ25DLElBQUksYUFBYTtHQUNqQixJQUFJLGlCQUFpQjtHQUNyQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksV0FBVyxLQUFLO0lBQ2hDLElBQUksUUFBUSxPQUFPLGFBQWE7S0FDNUIsTUFBTSxJQUFJLE1BQU0sZUFBZSxRQUFRLElBQUk7SUFDL0M7SUFDQSxJQUFJLEVBQUUsUUFBUSxNQUFNLGFBQWE7S0FDN0IsV0FBVyxRQUFRLE1BQU0sT0FBTztJQUNwQztJQUNBLElBQUksQ0FBQyxTQUFTLFdBQVcsUUFBUSxHQUFHLEdBQUc7S0FDbkMsa0JBQTBCLGdCQUN0QixLQUFLLGVBQWUsY0FBYyxvQkFBb0IsRUFDbEQsS0FBSyxRQUFRLEdBQ2pCLENBQUMsQ0FBQztLQUNOLGlCQUFpQjtLQUNqQjtJQUNKO0lBQ0EsYUFBYSxXQUFXLFFBQVE7R0FDcEM7O0dBRUEsSUFBSSxDQUFDLGdCQUFnQjtJQUNqQixJQUFJLENBQUMsYUFBYSxVQUFVLEdBQUc7S0FDM0IsV0FBVyxRQUFRLGNBQWMsSUFBSTtLQUNyQyxPQUFPLElBQUk7SUFDZixPQUNLOzs7OztLQUtELElBQUksQ0FBQyxvQkFBb0IsU0FBUyxRQUFRLFVBQVUsR0FBRztNQUNuRCxPQUFPLElBQUk7S0FDZjtJQUNKO0dBQ0o7O0dBRUEsSUFBSSxDQUFDLGFBQWEsVUFBVSxHQUFHO0lBQzNCLE1BQU0sU0FBUyxXQUFXLFFBQVE7SUFDbEMsSUFBSSxTQUFTLE1BQU0sR0FBRztLQUNsQixlQUFlLE1BQU07SUFDekI7R0FDSjtFQUNKO0NBQ0o7Q0FDQSxPQUFPO0FBQ1g7QUFDQSxTQUFTLGtCQUFrQixRQUFRLFNBQVM7Q0FDeEMsTUFBTSxFQUFFLFVBQVUsUUFBUSxpQkFBaUIsYUFBYTs7Q0FFeEQsTUFBTSxNQUFPLGNBQWMsUUFBUSxJQUM3QixXQUNBLFFBQVEsTUFBTSxJQUNWLE9BQU8sSUFDUCxHQUFHLFNBQVMsT0FBTyxFQUFFOztDQUUvQixJQUFJLFFBQVEsTUFBTSxHQUFHO0VBQ2pCLE9BQU8sU0FBUSxXQUFVO0dBQ3JCLElBQUksWUFBWSxVQUFVLGNBQWMsUUFBUTtJQUM1QyxNQUFNLEVBQUUsUUFBUSxhQUFhO0lBQzdCLElBQUksUUFBUTtLQUNSLElBQUksVUFBVSxJQUFJLFdBQVcsT0FBTztLQUNwQyxTQUFTLFVBQVUsSUFBSSxPQUFPO0lBQ2xDLE9BQ0s7S0FDRCxTQUFTLFVBQVUsR0FBRztJQUMxQjtHQUNKLE9BQ0s7SUFDRCxTQUFTLE1BQU0sS0FBSyxTQUFTLEtBQUssTUFBTSxNQUFNLEdBQUcsR0FBRztHQUN4RDtFQUNKLENBQUM7Q0FDTDs7Q0FFQSxJQUFJLG1CQUFtQixRQUFRLFVBQVU7RUFDckMsS0FBSyxNQUFNLE9BQU8sS0FBSztHQUNuQixJQUFJLE9BQU8sS0FBSyxHQUFHLEdBQUc7SUFDbEIsZUFBZSxJQUFJLElBQUk7R0FDM0I7RUFDSjtDQUNKO0NBQ0EsT0FBTztBQUNYO0FBQ0EsU0FBUyxvQkFBb0IsVUFBVTtDQUNuQyxPQUFPLFNBQVM7QUFDcEI7QUFDQSxTQUFTLG9CQUFvQixJQUFJLFNBQVMsa0JBQWtCOztDQUV4RCxJQUFJLFdBQVcsU0FBUyxRQUFRLFFBQVEsSUFDbEMsUUFBUSxXQUNSLE9BQU87Q0FDYixJQUFJLGtCQUFrQixrQkFBa0I7RUFDcEMsV0FBVyxrQkFBa0IsR0FBRyxPQUFPLE9BQU87R0FDMUM7R0FDQSxRQUFRLGlCQUFpQjtFQUM3QixDQUFDO0NBQ0w7O0NBRUEsTUFBTSxVQUFVLE9BQU8sS0FBSyxRQUFRO0NBQ3BDLElBQUksUUFBUSxRQUFRO0VBQ2hCLFFBQVEsU0FBUSxXQUFVO0dBQ3RCLEdBQUcsbUJBQW1CLFFBQVEsU0FBUyxPQUFPO0VBQ2xELENBQUM7Q0FDTDtDQUNBOztFQUVJLElBQUksU0FBUyxRQUFRLGVBQWUsR0FBRztHQUNuQyxNQUFNLFVBQVUsT0FBTyxLQUFLLFFBQVEsZUFBZTtHQUNuRCxJQUFJLFFBQVEsUUFBUTtJQUNoQixRQUFRLFNBQVEsV0FBVTtLQUN0QixHQUFHLG9CQUFvQixRQUFRLFFBQVEsZ0JBQWdCLE9BQU87SUFDbEUsQ0FBQztHQUNMO0VBQ0o7O0VBRUEsSUFBSSxTQUFTLFFBQVEsYUFBYSxHQUFHO0dBQ2pDLE1BQU0sVUFBVSxPQUFPLEtBQUssUUFBUSxhQUFhO0dBQ2pELElBQUksUUFBUSxRQUFRO0lBQ2hCLFFBQVEsU0FBUSxXQUFVO0tBQ3RCLEdBQUcsa0JBQWtCLFFBQVEsUUFBUSxjQUFjLE9BQU87SUFDOUQsQ0FBQztHQUNMO0VBQ0o7Q0FDSjtBQUNKO0FBQ0EsU0FBUyxlQUFlLEtBQUs7Q0FDekIsT0FBTyxZQUFZLE1BQU0sTUFBTSxLQUFLLENBQUM7QUFDekM7QUFDQSxTQUFTLHFCQUFxQjs7Q0FFMUIsTUFBTSxNQUFNO0NBQ1osSUFBSSxPQUFPLEtBQUs7RUFDWixPQUFPLElBQUk7Q0FDZixPQUNLO0VBQ0QsT0FBTyxJQUFJLG1CQUFtQjtDQUNsQztBQUNKOzs7O0FBS0EsTUFBTSxnQkFBZ0I7QUFDdEIsTUFBTSwwQkFBMEIsQ0FBQztBQUNqQyxNQUFNLDBCQUEwQjtBQUNoQyxJQUFJLGFBQWE7QUFDakIsU0FBUyx5QkFBeUIsU0FBUztDQUN2QyxTQUFTLEtBQUssUUFBUSxLQUFLLFNBQVM7RUFDaEMsT0FBTyxRQUFRLFFBQVEsS0FBSyxtQkFBbUIsS0FBSyxXQUFXLElBQUk7Q0FDdkU7QUFDSjs7QUFHQSxNQUFNLCtDQUFvQjtDQUN0QixNQUFNLFdBQVcsbUJBQW1CO0NBQ3BDLElBQUksT0FBTztDQUNYLE9BQU8sYUFBYSxPQUFPLG9CQUFvQixRQUFRLENBQUMsQ0FBQyxrQkFDbkQsR0FBRyxnQkFBZ0IsS0FBSyxJQUN4QjtBQUNWOzs7Ozs7QUFNQSxTQUFTLGVBQWUsVUFBVSxDQUFDLEdBQUc7Q0FDbEMsTUFBTSxFQUFFLFFBQVEsdUJBQXVCO0NBQ3ZDLE1BQU0sWUFBWSxXQUFXO0NBQzdCLE1BQU0sV0FBVyxRQUFRO0NBQ3pCLE1BQU0sT0FBTyxZQUFZLE1BQU07Q0FDL0IsSUFBSSxpQkFBaUIsVUFBVSxRQUFRLGFBQWEsSUFDOUMsUUFBUSxnQkFDUjtDQUNOLE1BQU0sVUFBVTs7RUFFaEIsVUFBVSxpQkFDSixPQUFPLE9BQU8sUUFDZCxTQUFTLFFBQVEsTUFBTSxJQUNuQixRQUFRLFNBQ1I7Q0FBYztDQUN4QixNQUFNLGtCQUFrQjs7RUFFeEIsVUFBVSxpQkFDSixPQUFPLGVBQWUsUUFDdEIsU0FBUyxRQUFRLGNBQWMsS0FDN0IsUUFBUSxRQUFRLGNBQWMsS0FDOUIsY0FBYyxRQUFRLGNBQWMsS0FDcEMsUUFBUSxtQkFBbUIsUUFDekIsUUFBUSxpQkFDUixRQUFRO0NBQUs7Q0FDdkIsTUFBTSxZQUFZLEtBQUssa0JBQWtCLFFBQVEsT0FBTyxPQUFPLENBQUM7O0NBRWhFLE1BQU0sbUJBQW1CLEtBQUssY0FBYyxRQUFRLGVBQWUsSUFDekQsUUFBUSxrQkFDUixHQUFHLFFBQVEsUUFBUSxDQUFDLEVBQUUsQ0FBQzs7Q0FHakMsTUFBTSxpQkFBaUIsS0FBSyxjQUFjLFFBQVEsYUFBYSxJQUNyRCxRQUFRLGdCQUNSLEdBQUcsUUFBUSxRQUFRLENBQUMsRUFBRSxDQUFDOzs7Q0FJakMsSUFBSSxlQUFlLFNBQ2IsT0FBTyxjQUNQLFVBQVUsUUFBUSxXQUFXLEtBQUssU0FBUyxRQUFRLFdBQVcsSUFDMUQsUUFBUSxjQUNSOztDQUVWLElBQUksZ0JBQWdCLFNBQ2QsT0FBTyxlQUNQLFVBQVUsUUFBUSxZQUFZLEtBQUssU0FBUyxRQUFRLFlBQVksSUFDNUQsUUFBUSxlQUNSOztDQUVWLElBQUksZ0JBQWdCLFNBQ2QsT0FBTyxlQUNQLFVBQVUsUUFBUSxZQUFZLElBQzFCLFFBQVEsZUFDUjs7Q0FFVixJQUFJLGtCQUFrQixDQUFDLENBQUMsUUFBUTs7Q0FFaEMsSUFBSSxXQUFXLFdBQVcsUUFBUSxPQUFPLElBQUksUUFBUSxVQUFVO0NBQy9ELElBQUksa0JBQWtCLFdBQVcsUUFBUSxPQUFPLElBQzFDLHlCQUF5QixRQUFRLE9BQU8sSUFDeEM7O0NBRU4sSUFBSSxtQkFBbUIsV0FBVyxRQUFRLGVBQWUsSUFDbkQsUUFBUSxrQkFDUjs7Q0FFTixJQUFJLG1CQUFtQixTQUNqQixPQUFPLGtCQUNQLFVBQVUsUUFBUSxlQUFlLElBQzdCLFFBQVEsa0JBQ1I7Q0FDVixJQUFJLG1CQUFtQixDQUFDLENBQUMsUUFBUTs7O0NBR2pDLE1BQU0sYUFBYSxTQUNiLE9BQU8sWUFDUCxjQUFjLFFBQVEsU0FBUyxJQUMzQixRQUFRLFlBQ1IsQ0FBQzs7Q0FFWCxJQUFJLGVBQWUsUUFBUSxlQUFnQixVQUFVLE9BQU87OztDQUc1RCxJQUFJO0NBQ0osTUFBTSx1QkFBdUI7RUFDekIsYUFBYSxtQkFBbUIsSUFBSTtFQUNwQyxNQUFNLGFBQWE7R0FDZixTQUFTO0dBQ1QsUUFBUSxRQUFRO0dBQ2hCLGdCQUFnQixnQkFBZ0I7R0FDaEMsVUFBVSxVQUFVO0dBQ3BCLFdBQVc7R0FDWCxhQUFhO0dBQ2IsU0FBUyxvQkFBb0IsT0FBTyxZQUFZO0dBQ2hELGFBQWE7R0FDYixjQUFjO0dBQ2QsZ0JBQWdCO0dBQ2hCLGFBQWE7R0FDYixpQkFBaUIscUJBQXFCLE9BQU8sWUFBWTtHQUN6RCxpQkFBaUI7R0FDakIsaUJBQWlCO0dBQ2pCLGlCQUFpQixRQUFRO0dBQ3pCLGlCQUFpQixRQUFRO0dBQ3pCLFFBQVEsRUFBRSxXQUFXLE1BQU07RUFDL0I7RUFDQTtHQUNJLFdBQVcsa0JBQWtCLGlCQUFpQjtHQUM5QyxXQUFXLGdCQUFnQixlQUFlO0dBQzFDLFdBQVcsdUJBQXVCLGNBQWMsUUFBUSxJQUNsRCxTQUFTLHVCQUNUO0dBQ04sV0FBVyxxQkFBcUIsY0FBYyxRQUFRLElBQ2hELFNBQVMscUJBQ1Q7RUFDVjtFQUNBLHNCQUE4QixjQUFlO0dBQ3pDLFdBQVcsY0FBYyxjQUFjLFFBQVEsSUFDekMsU0FBUyxjQUNUO0VBQ1Y7RUFDQSxNQUFNLE1BQU0sa0JBQWtCLFVBQVU7RUFDeEMsYUFBYSxtQkFBbUIsR0FBRztFQUNuQyxPQUFPO0NBQ1g7Q0FDQSxXQUFXLGVBQWU7Q0FDMUIscUJBQXFCLFVBQVUsUUFBUSxPQUFPLGdCQUFnQixLQUFLOztDQUVuRSxTQUFTLHdCQUF3QjtFQUM3QixPQUFPO0dBQ0MsUUFBUTtHQUNSLGdCQUFnQjtHQUNoQixVQUFVO0dBQ1YsaUJBQWlCO0dBQ2pCLGVBQWU7RUFDbkI7Q0FFUjs7Q0FFQSxNQUFNLFNBQVMsU0FBUztFQUNwQixXQUFXLFFBQVE7RUFDbkIsTUFBSyxRQUFPO0dBQ1IsU0FBUyxTQUFTO0dBQ2xCLFFBQVEsUUFBUTtFQUNwQjtDQUNKLENBQUM7O0NBRUQsTUFBTSxpQkFBaUIsU0FBUztFQUM1QixXQUFXLGdCQUFnQjtFQUMzQixNQUFLLFFBQU87R0FDUixTQUFTLGlCQUFpQjtHQUMxQixnQkFBZ0IsUUFBUTtHQUN4QixxQkFBcUIsVUFBVSxRQUFRLE9BQU8sR0FBRztFQUNyRDtDQUNKLENBQUM7O0NBRUQsTUFBTSxXQUFXLGVBQWUsVUFBVSxLQUFLOztDQUUvQyxNQUFNLGtCQUFpQyw4QkFBZSxpQkFBaUIsS0FBSzs7Q0FFNUUsTUFBTSxnQkFBK0IsOEJBQWUsZUFBZSxLQUFLOztDQUV4RSxTQUFTLDRCQUE0QjtFQUNqQyxPQUFPLFdBQVcsZ0JBQWdCLElBQUksbUJBQW1CO0NBQzdEOztDQUVBLFNBQVMsMEJBQTBCLFNBQVM7RUFDeEMsbUJBQW1CO0VBQ25CLFNBQVMsa0JBQWtCO0NBQy9COztDQUVBLFNBQVMsb0JBQW9CO0VBQ3pCLE9BQU87Q0FDWDs7Q0FFQSxTQUFTLGtCQUFrQixTQUFTO0VBQ2hDLElBQUksWUFBWSxNQUFNO0dBQ2xCLGtCQUFrQix5QkFBeUIsT0FBTztFQUN0RDtFQUNBLFdBQVc7RUFDWCxTQUFTLFVBQVU7Q0FDdkI7Q0FDQSxTQUFTLDJCQUEyQixNQUFNLEtBQUs7RUFDM0MsT0FBTyxTQUFTLGVBQWUsQ0FBQyxJQUFJO0NBQ3hDO0NBQ0EsTUFBTSxnQkFBZ0IsSUFBSSxnQkFBZ0IsVUFBVSxpQkFBaUIsY0FBYyxxQkFBcUI7RUFDcEcsc0JBQXNCOztFQUV0QixJQUFJO0VBQ0osSUFBSTtHQUNBLHNCQUE4QixnQkFBaUIsMkJBQTJCO0lBQ3RFLGtCQUFrQixZQUFZLENBQUM7R0FDbkM7R0FDQSxJQUFJLENBQUMsV0FBVztJQUNaLFNBQVMsa0JBQWtCLFNBQ3JCLG1CQUFtQixJQUNuQjtHQUNWO0dBQ0EsTUFBTSxHQUFHLFFBQVE7RUFDckIsVUFDUTtHQUNKLHNCQUE4QixnQkFBaUIsMkJBQTJCO0lBQ3RFLGtCQUFrQixJQUFJO0dBQzFCO0dBQ0EsSUFBSSxDQUFDLFdBQVc7SUFDWixTQUFTLGtCQUFrQjtHQUMvQjtFQUNKO0VBQ0EsSUFBSyxhQUFhLHNCQUNkLFNBQVMsR0FBRyxLQUNaLFFBQVEsZ0JBQ1AsYUFBYSxzQkFBc0IsQ0FBQyxLQUN2QztHQUNFLE1BQU0sQ0FBQyxLQUFLLFFBQVEsZUFBZTtHQUNuQyxzQkFBOEIsZ0JBQzFCLFVBQ0EsU0FBUyxHQUFHLEtBQ1osMkJBQTJCLFVBQVUsSUFBSSxHQUFHO0lBQzVDLElBQUksa0JBQ0Msd0JBQXdCLGVBQWUsR0FBRyxLQUN2Qyx1QkFBdUIsY0FBYyxHQUFHLElBQUk7S0FDaEQsS0FBSyxlQUFlLGNBQWMsa0JBQWtCO01BQ2hEO01BQ0EsTUFBTTtLQUNWLENBQUMsQ0FBQztJQUNOOztJQUVBLHNCQUE4QixjQUFlO0tBQ3pDLE1BQU0sRUFBRSxhQUFhLFlBQVk7S0FDakMsSUFBSSxXQUFXLGVBQWU7TUFDMUIsUUFBUSxLQUFLLFlBQVk7T0FDckIsTUFBTTtPQUNOO09BQ0EsSUFBSTtPQUNKLFNBQVMsR0FBRyxTQUFTLEdBQUc7TUFDNUIsQ0FBQztLQUNMO0lBQ0o7R0FDSjtHQUNBLE9BQU8sVUFBVSxnQkFDWCxnQkFBZ0IsTUFBTSxJQUN0QixhQUFhLEdBQUc7RUFDMUIsT0FDSyxJQUFJLGlCQUFpQixHQUFHLEdBQUc7R0FDNUIsT0FBTztFQUNYLE9BQ0s7O0dBRUQsTUFBTSxnQkFBZ0IsZUFBZSxzQkFBc0I7RUFDL0Q7Q0FDSjs7Q0FFQSxTQUFTLEVBQUUsR0FBRyxNQUFNO0VBQ2hCLE9BQU8sY0FBYSxZQUFXLFFBQVEsTUFBTSxXQUFXLE1BQU0sQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsbUJBQW1CLEdBQUcsSUFBSSxHQUFHLGNBQWEsU0FBUSxRQUFRLE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFHLFFBQU8sTUFBSyxRQUFPLFNBQVMsR0FBRyxDQUFDO0NBQ3ZOOztDQUVBLFNBQVMsR0FBRyxHQUFHLE1BQU07RUFDakIsTUFBTSxDQUFDLE1BQU0sTUFBTSxRQUFRO0VBQzNCLElBQUksUUFBUSxDQUFDLFNBQVMsSUFBSSxHQUFHO0dBQ3pCLE1BQU0sZ0JBQWdCLGVBQWUsZ0JBQWdCO0VBQ3pEO0VBQ0EsT0FBTyxFQUFFLEdBQUc7R0FBQztHQUFNO0dBQU0sT0FBTyxFQUFFLGlCQUFpQixLQUFLLEdBQUcsUUFBUSxDQUFDLENBQUM7RUFBQyxDQUFDO0NBQzNFOztDQUVBLFNBQVMsRUFBRSxHQUFHLE1BQU07RUFDaEIsT0FBTyxjQUFhLFlBQVcsUUFBUSxNQUFNLFVBQVUsTUFBTSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxrQkFBa0IsR0FBRyxJQUFJLEdBQUcsb0JBQW1CLFNBQVEsUUFBUSxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyx3QkFBdUIsUUFBTyxTQUFTLEdBQUcsS0FBSyxRQUFRLEdBQUcsQ0FBQztDQUM1UDs7Q0FFQSxTQUFTLEVBQUUsR0FBRyxNQUFNO0VBQ2hCLE9BQU8sY0FBYSxZQUFXLFFBQVEsTUFBTSxRQUFRLE1BQU0sQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsZ0JBQWdCLEdBQUcsSUFBSSxHQUFHLGtCQUFpQixTQUFRLFFBQVEsTUFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLFNBQVMsd0JBQXVCLFFBQU8sU0FBUyxHQUFHLEtBQUssUUFBUSxHQUFHLENBQUM7Q0FDdFA7O0NBRUEsU0FBUyxVQUFVLFFBQVE7RUFDdkIsT0FBTyxPQUFPLEtBQUksUUFBTyxTQUFTLEdBQUcsS0FBSyxTQUFTLEdBQUcsS0FBSyxVQUFVLEdBQUcsSUFDbEUsZUFBZSxPQUFPLEdBQUcsQ0FBQyxJQUMxQixHQUFHO0NBQ2I7Q0FDQSxNQUFNLGVBQWUsUUFBUTtDQUM3QixNQUFNLFlBQVk7RUFDZDtFQUNBO0VBQ0EsTUFBTTtDQUNWOztDQUVBLFNBQVMsZUFBZSxHQUFHLE1BQU07RUFDN0IsT0FBTyxjQUFhLFlBQVc7R0FDM0IsSUFBSTtHQUNKLE1BQU0sV0FBVztHQUNqQixJQUFJO0lBQ0EsU0FBUyxZQUFZO0lBQ3JCLE1BQU0sUUFBUSxNQUFNLFdBQVcsTUFBTSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7R0FDNUQsVUFDUTtJQUNKLFNBQVMsWUFBWTtHQUN6QjtHQUNBLE9BQU87RUFDWCxTQUFTLG1CQUFtQixHQUFHLElBQUksR0FBRyxjQUFhLFNBQVEsS0FBSyxxQkFBcUIsQ0FBQyxHQUFHLElBQUksSUFBRyxRQUFPLENBQUMsZUFBZSxHQUFHLENBQUMsSUFBRyxRQUFPLFFBQVEsR0FBRyxDQUFDO0NBQ3JKOztDQUVBLFNBQVMsWUFBWSxHQUFHLE1BQU07RUFDMUIsT0FBTyxjQUFhLFlBQVcsUUFBUSxNQUFNLFFBQVEsTUFBTSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxnQkFBZ0IsR0FBRyxJQUFJLEdBQUcsa0JBQWlCLFNBQVEsS0FBSyxrQkFBa0IsQ0FBQyxHQUFHLElBQUksR0FBRyxvQkFBbUIsUUFBTyxTQUFTLEdBQUcsS0FBSyxRQUFRLEdBQUcsQ0FBQztDQUN0Tzs7Q0FFQSxTQUFTLGNBQWMsR0FBRyxNQUFNO0VBQzVCLE9BQU8sY0FBYSxZQUFXLFFBQVEsTUFBTSxVQUFVLE1BQU0sQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsa0JBQWtCLEdBQUcsSUFBSSxHQUFHLG9CQUFtQixTQUFRLEtBQUssb0JBQW9CLENBQUMsR0FBRyxJQUFJLEdBQUcsb0JBQW1CLFFBQU8sU0FBUyxHQUFHLEtBQUssUUFBUSxHQUFHLENBQUM7Q0FDOU87Q0FDQSxTQUFTLGVBQWUsT0FBTztFQUMzQixlQUFlO0VBQ2YsU0FBUyxjQUFjO0NBQzNCOztDQUVBLFNBQVMsR0FBRyxLQUFLLFFBQVE7RUFDckIsT0FBTyxtQkFBbUI7R0FDdEIsSUFBSSxDQUFDLEtBQUs7SUFDTixPQUFPO0dBQ1g7R0FDQSxNQUFNLGVBQWUsU0FBUyxNQUFNLElBQUksU0FBUyxRQUFROzs7R0FHekQsTUFBTSxVQUFVLFNBQVMsTUFBTSxJQUN6QixDQUFDLFlBQVksSUFDYix3QkFBd0IsVUFBVSxnQkFBZ0IsT0FBTyxZQUFZO0dBQzNFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsS0FBSztJQUNyQyxNQUFNLFVBQVUsaUJBQWlCLFFBQVEsRUFBRTtJQUMzQyxJQUFJLFdBQVcsU0FBUyxnQkFBZ0IsU0FBUyxHQUFHOztJQUVwRCxJQUFJLGFBQWEsTUFBTTtLQUNuQixXQUFXLFFBQVE7SUFDdkI7SUFDQSxJQUFJLGFBQWEsUUFBUSxLQUNyQixrQkFBa0IsUUFBUSxLQUMxQixTQUFTLFFBQVEsR0FBRztLQUNwQixPQUFPO0lBQ1g7R0FDSjtHQUNBLE9BQU87RUFDWCxTQUFTLENBQUMsR0FBRyxHQUFHLHFCQUFvQixTQUFRO0dBQ3hDLE9BQU8sUUFBUSxNQUFNLEtBQUssSUFBSSxNQUFNLENBQUMsS0FBSyxNQUFNLENBQUM7RUFDckQsR0FBRyxvQkFBbUIsUUFBTyxVQUFVLEdBQUcsQ0FBQztDQUMvQztDQUNBLFNBQVMsZ0JBQWdCLEtBQUs7RUFDMUIsSUFBSSxXQUFXO0VBQ2YsTUFBTSxVQUFVLHdCQUF3QixVQUFVLGdCQUFnQixPQUFPLFFBQVEsS0FBSztFQUN0RixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUs7R0FDckMsTUFBTSx1QkFBdUIsVUFBVSxNQUFNLFFBQVEsT0FBTyxDQUFDO0dBQzdELE1BQU0sZUFBZSxTQUFTLGdCQUFnQixzQkFBc0IsR0FBRztHQUN2RSxJQUFJLGdCQUFnQixNQUFNO0lBQ3RCLFdBQVc7SUFDWDtHQUNKO0VBQ0o7RUFDQSxPQUFPO0NBQ1g7O0NBRUEsU0FBUyxHQUFHLEtBQUs7RUFDYixNQUFNLFdBQVcsZ0JBQWdCLEdBQUc7O0VBRXBDLE9BQU8sWUFBWSxPQUNiLFdBQ0EsU0FDSSxPQUFPLEdBQUcsR0FBRyxLQUFLLENBQUMsSUFDbkIsQ0FBQztDQUNmOztDQUVBLFNBQVMsaUJBQWlCLFFBQVE7RUFDOUIsT0FBUSxVQUFVLE1BQU0sV0FBVyxDQUFDO0NBQ3hDOztDQUVBLFNBQVMsaUJBQWlCLFFBQVEsU0FBUztFQUN2QyxJQUFJLFVBQVU7R0FDVixNQUFNLFdBQVcsR0FBRyxTQUFTLFFBQVE7R0FDckMsS0FBSyxNQUFNLE9BQU8sVUFBVTtJQUN4QixJQUFJLE9BQU8sVUFBVSxHQUFHLEdBQUc7S0FDdkIsZUFBZSxTQUFTLElBQUk7SUFDaEM7R0FDSjtHQUNBLFVBQVUsU0FBUztFQUN2QjtFQUNBLFVBQVUsTUFBTSxVQUFVO0VBQzFCLFNBQVMsV0FBVyxVQUFVO0NBQ2xDOztDQUVBLFNBQVMsbUJBQW1CLFFBQVEsU0FBUztFQUN6QyxVQUFVLE1BQU0sVUFBVSxVQUFVLE1BQU0sV0FBVyxDQUFDO0VBQ3RELE1BQU0sV0FBVyxHQUFHLFNBQVMsUUFBUTtFQUNyQyxJQUFJLFVBQVU7R0FDVixLQUFLLE1BQU0sT0FBTyxVQUFVO0lBQ3hCLElBQUksT0FBTyxVQUFVLEdBQUcsR0FBRztLQUN2QixlQUFlLFNBQVMsSUFBSTtJQUNoQztHQUNKO0VBQ0o7RUFDQSxVQUFVLFNBQVM7RUFDbkIsU0FBUyxTQUFTLFVBQVUsTUFBTSxPQUFPO0VBQ3pDLFNBQVMsV0FBVyxVQUFVO0NBQ2xDOztDQUVBLFNBQVMsa0JBQWtCLFFBQVE7RUFDL0IsT0FBTyxpQkFBaUIsTUFBTSxXQUFXLENBQUM7Q0FDOUM7O0NBRUEsU0FBUyxrQkFBa0IsUUFBUSxRQUFRO0VBQ3ZDLGlCQUFpQixNQUFNLFVBQVU7RUFDakMsU0FBUyxrQkFBa0IsaUJBQWlCO0VBQzVDLG9CQUFvQixVQUFVLFFBQVEsTUFBTTtDQUNoRDs7Q0FFQSxTQUFTLG9CQUFvQixRQUFRLFFBQVE7RUFDekMsaUJBQWlCLE1BQU0sVUFBVSxPQUFPLGlCQUFpQixNQUFNLFdBQVcsQ0FBQyxHQUFHLE1BQU07RUFDcEYsU0FBUyxrQkFBa0IsaUJBQWlCO0VBQzVDLG9CQUFvQixVQUFVLFFBQVEsTUFBTTtDQUNoRDs7Q0FFQSxTQUFTLGdCQUFnQixRQUFRO0VBQzdCLE9BQU8sZUFBZSxNQUFNLFdBQVcsQ0FBQztDQUM1Qzs7Q0FFQSxTQUFTLGdCQUFnQixRQUFRLFFBQVE7RUFDckMsZUFBZSxNQUFNLFVBQVU7RUFDL0IsU0FBUyxnQkFBZ0IsZUFBZTtFQUN4QyxrQkFBa0IsVUFBVSxRQUFRLE1BQU07Q0FDOUM7O0NBRUEsU0FBUyxrQkFBa0IsUUFBUSxRQUFRO0VBQ3ZDLGVBQWUsTUFBTSxVQUFVLE9BQU8sZUFBZSxNQUFNLFdBQVcsQ0FBQyxHQUFHLE1BQU07RUFDaEYsU0FBUyxnQkFBZ0IsZUFBZTtFQUN4QyxrQkFBa0IsVUFBVSxRQUFRLE1BQU07Q0FDOUM7O0NBRUE7O0NBRUEsSUFBSSxVQUFVLFdBQVc7RUFDckIsTUFBTSxPQUFPLFNBQVMsUUFBUTtHQUMxQixJQUFJLGdCQUFnQjtJQUNoQixRQUFRLFFBQVE7SUFDaEIsU0FBUyxTQUFTO0lBQ2xCLHFCQUFxQixVQUFVLFFBQVEsT0FBTyxnQkFBZ0IsS0FBSztHQUN2RTtFQUNKLENBQUM7RUFDRCxNQUFNLE9BQU8saUJBQWlCLFFBQVE7R0FDbEMsSUFBSSxnQkFBZ0I7SUFDaEIsZ0JBQWdCLFFBQVE7SUFDeEIsU0FBUyxpQkFBaUI7SUFDMUIscUJBQXFCLFVBQVUsUUFBUSxPQUFPLGdCQUFnQixLQUFLO0dBQ3ZFO0VBQ0osQ0FBQztDQUNMOztDQUVBLE1BQU0sV0FBVztFQUNiLElBQUk7RUFDSjtFQUNBO0VBQ0EsSUFBSSxnQkFBZ0I7R0FDaEIsT0FBTztFQUNYO0VBQ0EsSUFBSSxjQUFjLEtBQUs7R0FDbkIsaUJBQWlCO0dBQ2pCLElBQUksT0FBTyxRQUFRO0lBQ2YsUUFBUSxRQUFRLE9BQU8sT0FBTztJQUM5QixnQkFBZ0IsUUFBUSxPQUFPLGVBQWU7SUFDOUMscUJBQXFCLFVBQVUsUUFBUSxPQUFPLGdCQUFnQixLQUFLO0dBQ3ZFO0VBQ0o7RUFDQSxJQUFJLG1CQUFtQjtHQUNuQixPQUFPLE9BQU8sS0FBSyxVQUFVLEtBQUssQ0FBQyxDQUFDLEtBQUs7RUFDN0M7RUFDQTtFQUNBLElBQUksWUFBWTtHQUNaLE9BQU87RUFDWDtFQUNBLElBQUksY0FBYztHQUNkLE9BQU8sZ0JBQWdCLENBQUM7RUFDNUI7RUFDQSxJQUFJLFdBQVc7R0FDWCxPQUFPO0VBQ1g7RUFDQSxJQUFJLGNBQWM7R0FDZCxPQUFPO0VBQ1g7RUFDQSxJQUFJLFlBQVksS0FBSztHQUNqQixlQUFlO0dBQ2YsU0FBUyxjQUFjO0VBQzNCO0VBQ0EsSUFBSSxlQUFlO0dBQ2YsT0FBTztFQUNYO0VBQ0EsSUFBSSxhQUFhLEtBQUs7R0FDbEIsZ0JBQWdCO0dBQ2hCLFNBQVMsZUFBZTtFQUM1QjtFQUNBLElBQUksZUFBZTtHQUNmLE9BQU87RUFDWDtFQUNBLElBQUksYUFBYSxLQUFLO0dBQ2xCLGdCQUFnQjtFQUNwQjtFQUNBLElBQUksaUJBQWlCO0dBQ2pCLE9BQU87RUFDWDtFQUNBLElBQUksZUFBZSxLQUFLO0dBQ3BCLGtCQUFrQjtHQUNsQixTQUFTLGlCQUFpQjtFQUM5QjtFQUNBLElBQUksa0JBQWtCO0dBQ2xCLE9BQU87RUFDWDtFQUNBLElBQUksZ0JBQWdCLEtBQUs7R0FDckIsbUJBQW1CO0dBQ25CLFNBQVMsa0JBQWtCO0VBQy9CO0VBQ0EsSUFBSSxrQkFBa0I7R0FDbEIsT0FBTztFQUNYO0VBQ0EsSUFBSSxnQkFBZ0IsS0FBSztHQUNyQixtQkFBbUI7R0FDbkIsU0FBUyxrQkFBa0I7RUFDL0I7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0dBQ0MsdUJBQXVCO0NBQzVCO0NBQ0E7RUFDSSxTQUFTLGtCQUFrQjtFQUMzQixTQUFTLGdCQUFnQjtFQUN6QixTQUFTLEtBQUs7RUFDZCxTQUFTLEtBQUs7RUFDZCxTQUFTLEtBQUs7RUFDZCxTQUFTLElBQUk7RUFDYixTQUFTLElBQUk7RUFDYixTQUFTLG9CQUFvQjtFQUM3QixTQUFTLG9CQUFvQjtFQUM3QixTQUFTLHNCQUFzQjtFQUMvQixTQUFTLGtCQUFrQjtFQUMzQixTQUFTLGtCQUFrQjtFQUMzQixTQUFTLG9CQUFvQjtFQUM3QixTQUFTLDBCQUEwQjtFQUNuQyxTQUFTLHdCQUF3QjtFQUNqQyxTQUFTLHVCQUF1QjtFQUNoQyxTQUFTLHFCQUFxQjtDQUNsQzs7Q0FFQSxzQkFBOEIsY0FBZTtFQUN6QyxTQUFTLGtCQUFrQixZQUFZO0dBQ25DLFNBQVMsY0FBYztFQUMzQjtFQUNBLFNBQVMsd0JBQXdCO0dBQzdCLFNBQVMsY0FBYztFQUMzQjtDQUNKO0NBQ0EsT0FBTztBQUNYOztBQUdBLE1BQU0sMkJBQTJCO0FBQ2pDLE1BQU0sb0JBQW9CO0NBQ3RCLGdDQUFnQztDQUNoQywrQkFBK0I7Q0FDL0IscUJBQXFCO0FBQ3pCO0FBQ0EsTUFBTSwwQkFBMEIsRUFDNUIsK0JBQStCLHdCQUNuQztBQUNBLE1BQU0sNEJBQTRCLEVBQzlCLHFCQUFxQixTQUN6QjtBQUNBLElBQUk7QUFDSixlQUFlLGVBQWUsS0FBSyxNQUFNO0NBQ3JDLE9BQU8sSUFBSSxTQUFTLFNBQVMsV0FBVztFQUNwQyxJQUFJO0dBQ0Esb0JBQW9CO0lBQ2hCLElBQUk7SUFDSixPQUFPLGtCQUFrQjtJQUN6QixhQUFhO0lBQ2IsVUFBVTtJQUNWLE1BQU07SUFDTixxQkFBcUIsQ0FBQyx3QkFBd0I7SUFDekM7R0FDVCxJQUFHLFFBQU87SUFDTixjQUFjO0lBQ2QsSUFBSSxHQUFHLG9CQUFvQixFQUFFLG1CQUFtQixlQUFlO0tBQzNELHdCQUF3QixtQkFBbUIsVUFBVSxJQUFJO0lBQzdELENBQUM7SUFDRCxJQUFJLEdBQUcsa0JBQWtCLEVBQUUsbUJBQW1CLG1CQUFtQjtLQUM3RCxJQUFJLGtCQUFrQixnQkFBZ0IsY0FBYztNQUNoRCxJQUFJLEtBQUssU0FBUyxVQUFVOztPQUV4QixJQUFJLGtCQUFrQixpQkFDbEIsS0FBSyxPQUFPLFlBQVk7UUFDeEIsZ0JBQWdCLGNBQWMsa0JBQWtCLFlBQVk7T0FDaEU7TUFDSixPQUNLO09BQ0QsZ0JBQWdCLGNBQWMsa0JBQWtCLFlBQVk7TUFDaEU7S0FDSjtJQUNKLENBQUM7SUFDRCxJQUFJLGFBQWE7S0FDYixJQUFJO0tBQ0osT0FBTyxrQkFBa0I7S0FDekIsTUFBTTtLQUNOLHVCQUF1Qix3QkFBd0I7SUFDbkQsQ0FBQztJQUNELElBQUksR0FBRyxrQkFBaUIsWUFBVztLQUMvQixJQUFJLFFBQVEsUUFBUSxPQUNoQixRQUFRLGdCQUFnQiwrQkFBK0I7TUFDdkQsY0FBYyxTQUFTLElBQUk7S0FDL0I7SUFDSixDQUFDO0lBQ0QsTUFBTSxRQUFRLElBQUksSUFBSTtJQUN0QixJQUFJLEdBQUcsa0JBQWtCLE9BQU8sWUFBWTtLQUN4QyxJQUFJLFFBQVEsUUFBUSxPQUNoQixRQUFRLGdCQUFnQiwrQkFBK0I7TUFDdkQsSUFBSSxtQkFBbUI7TUFDdkIsYUFBYSxTQUFTLElBQUk7TUFDMUIsSUFBSSxRQUFRLFdBQVcsVUFBVTtPQUM3QixJQUFJLENBQUMsTUFBTSxJQUFJLFFBQVEsR0FBRyxHQUFHO1FBQ3pCLE1BQU0sQ0FBQyxRQUFRLE1BQU0sSUFBSSxzQkFBc0IsUUFBUSxHQUFHO1FBQzFELE1BQU0sSUFBSSxRQUFRLEtBQUssSUFBSTtPQUMvQjtPQUNBLElBQUksaUJBQWlCLE1BQU0sSUFBSSxRQUFRLEdBQUcsQ0FBQztNQUMvQyxPQUNLO09BQ0QsTUFBTSxXQUFXLHFCQUFxQixRQUFRLFFBQVEsSUFBSTtPQUMxRCxZQUFZLElBQUksaUJBQWlCLFFBQVE7TUFDN0M7S0FDSjtJQUNKLENBQUM7SUFDRCxJQUFJLEdBQUcsb0JBQW1CLFlBQVc7S0FDakMsSUFBSSxRQUFRLFFBQVEsT0FDaEIsUUFBUSxnQkFBZ0IsK0JBQStCO01BQ3ZELFVBQVUsU0FBUyxJQUFJO0tBQzNCO0lBQ0osQ0FBQztJQUNELElBQUksaUJBQWlCO0tBQ2pCLElBQUk7S0FDSixPQUFPLGtCQUFrQjtLQUN6QixPQUFPLDBCQUEwQjtJQUNyQyxDQUFDO0lBQ0QsUUFBUSxJQUFJO0dBQ2hCLENBQUM7RUFDTCxTQUNPLEdBQUc7R0FDTixRQUFRLE1BQU0sQ0FBQzs7R0FFZixPQUFPLEtBQUs7RUFDaEI7Q0FDSixDQUFDO0FBQ0w7O0FBRUEsU0FBUyxrQkFBa0IsVUFBVTtDQUNqQyxPQUFRLFNBQVMsS0FBSyxRQUNsQixTQUFTLEtBQUssZUFDZCxTQUFTLEtBQUssVUFDZDtBQUNSO0FBQ0EsU0FBUyx3QkFBd0IsVUFDakMsVUFBVSxNQUFNOztDQUVaLE1BQU0sU0FBUyxLQUFLLFNBQVMsZ0JBQ3ZCLEtBQUssU0FDTCxLQUFLLE9BQU87Q0FDbEIsSUFBSSxZQUFZLFNBQVMsY0FBYzs7RUFFbkMsSUFBSSxTQUFTLGlCQUFpQixRQUFRO0dBQ2xDLE1BQU0sTUFBTTtJQUNSLE9BQU8sU0FBUyxrQkFBa0IsUUFBUSxFQUFFO0lBQzVDLFdBQVc7SUFDWCxpQkFBaUI7R0FDckI7R0FDQSxTQUFTLEtBQUssS0FBSyxHQUFHO0VBQzFCO0NBQ0o7QUFDSjtBQUNBLFNBQVMsZ0JBQWdCLGNBQWMsVUFBVTtDQUM3QyxNQUFNLE9BQU87Q0FDYixhQUFhLE1BQU0sS0FBSztFQUNwQjtFQUNBLEtBQUs7RUFDTCxVQUFVO0VBQ1YsT0FBTyxTQUFTLE9BQU87Q0FDM0IsQ0FBQztDQUNELGFBQWEsTUFBTSxLQUFLO0VBQ3BCO0VBQ0EsS0FBSztFQUNMLFVBQVU7RUFDVixPQUFPLFNBQVM7Q0FDcEIsQ0FBQztDQUNELGFBQWEsTUFBTSxLQUFLO0VBQ3BCO0VBQ0EsS0FBSztFQUNMLFVBQVU7RUFDVixPQUFPLFNBQVMsZUFBZTtDQUNuQyxDQUFDO0NBQ0QsYUFBYSxNQUFNLEtBQUs7RUFDcEI7RUFDQSxLQUFLO0VBQ0wsVUFBVTtFQUNWLE9BQU8sU0FBUztDQUNwQixDQUFDO0NBQ0QsYUFBYSxNQUFNLEtBQUs7RUFDcEI7RUFDQSxLQUFLO0VBQ0wsVUFBVTtFQUNWLE9BQU8sc0JBQXNCLFNBQVMsU0FBUyxLQUFLO0NBQ3hELENBQUM7Q0FDRDtFQUNJLGFBQWEsTUFBTSxLQUFLO0dBQ3BCO0dBQ0EsS0FBSztHQUNMLFVBQVU7R0FDVixPQUFPLFNBQVMsZ0JBQWdCO0VBQ3BDLENBQUM7RUFDRCxhQUFhLE1BQU0sS0FBSztHQUNwQjtHQUNBLEtBQUs7R0FDTCxVQUFVO0dBQ1YsT0FBTyxTQUFTLGNBQWM7RUFDbEMsQ0FBQztDQUNMO0FBQ0o7O0FBRUEsU0FBUyxzQkFBc0IsVUFBVTtDQUNyQyxNQUFNLFFBQVEsQ0FBQztDQUNmLE9BQU8sS0FBSyxRQUFRLENBQUMsQ0FBQyxTQUFTLFFBQVE7RUFDbkMsTUFBTSxJQUFJLFNBQVM7RUFDbkIsSUFBSSxXQUFXLENBQUMsS0FBSyxZQUFZLEdBQUc7R0FDaEMsTUFBTSxPQUFPLDBCQUEwQixDQUFDO0VBQzVDLE9BQ0ssSUFBSSxhQUFhLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxJQUFJLFFBQVE7R0FDL0MsTUFBTSxPQUFPLEVBQUUsSUFBSTtFQUN2QixPQUNLLElBQUksU0FBUyxDQUFDLEdBQUc7R0FDbEIsTUFBTSxPQUFPLHNCQUFzQixDQUFDO0VBQ3hDLE9BQ0s7R0FDRCxNQUFNLE9BQU87RUFDakI7Q0FDSixDQUFDO0NBQ0QsT0FBTztBQUNYO0FBQ0EsTUFBTSxNQUFNO0NBQ1IsS0FBSztDQUNMLEtBQUs7Q0FDTCxNQUFLO0NBQ0wsS0FBSztBQUNUO0FBQ0EsU0FBUyxPQUFPLEdBQUc7Q0FDZixPQUFPLEVBQUUsUUFBUSxXQUFXLFVBQVU7QUFDMUM7QUFDQSxTQUFTLFdBQVcsR0FBRztDQUNuQixPQUFPLElBQUksTUFBTTtBQUNyQjs7QUFFQSxTQUFTLDBCQUEwQixNQUFNO0NBQ3JDLE1BQU0sWUFBWSxLQUFLLFNBQVMsS0FBSyxPQUFPLEtBQUssTUFBTSxFQUFFLE1BQU07Q0FDL0QsT0FBTyxFQUNILFNBQVM7RUFDTCxNQUFNO0VBQ04sU0FBUyxrQkFBa0I7Q0FDL0IsRUFDSjtBQUNKO0FBQ0EsU0FBUyxjQUFjLFNBQVMsTUFBTTtDQUNsQyxRQUFRLFVBQVUsS0FBSztFQUNuQixJQUFJO0VBQ0osT0FBTztDQUNYLENBQUM7O0NBRUQsTUFBTSxTQUFTLEtBQUssU0FBUyxnQkFDdkIsS0FBSyxTQUNMLEtBQUssT0FBTztDQUNsQixLQUFLLE1BQU0sQ0FBQyxhQUFhLGFBQWEsS0FBSyxhQUFhOztFQUVwRCxNQUFNLFdBQVcsS0FBSyxTQUFTLGdCQUN6QixXQUNBLFNBQVM7RUFDZixJQUFJLFdBQVcsVUFBVTtHQUNyQjtFQUNKO0VBQ0EsUUFBUSxVQUFVLEtBQUs7R0FDbkIsSUFBSSxTQUFTLEdBQUcsU0FBUztHQUN6QixPQUFPLEdBQUcsa0JBQWtCLFdBQVcsRUFBRTtFQUM3QyxDQUFDO0NBQ0w7QUFDSjtBQUNBLFNBQVMscUJBQXFCLFFBQVEsTUFBTTtDQUN4QyxJQUFJLFdBQVc7Q0FDZixJQUFJLFdBQVcsVUFBVTtFQUNyQixLQUFLLE1BQU0sQ0FBQyxXQUFXLGFBQWEsS0FBSyxZQUFZLFFBQVEsR0FBRztHQUM1RCxJQUFJLFNBQVMsR0FBRyxTQUFTLE1BQU0sUUFBUTtJQUNuQyxXQUFXO0lBQ1g7R0FDSjtFQUNKO0NBQ0o7Q0FDQSxPQUFPO0FBQ1g7QUFDQSxTQUFTLGNBQWMsUUFBUSxNQUFNO0NBQ2pDLElBQUksV0FBVyxVQUFVO0VBQ3JCLE9BQU8sS0FBSyxTQUFTLGdCQUNmLEtBQUssU0FDTCxLQUFLLE9BQU87Q0FDdEIsT0FDSztFQUNELE1BQU0sV0FBVyxNQUFNLEtBQUssS0FBSyxZQUFZLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBSyxTQUFRLEtBQUssR0FBRyxTQUFTLE1BQU0sTUFBTTtFQUNqRyxJQUFJLFVBQVU7R0FDVixPQUFPLEtBQUssU0FBUyxnQkFDZixXQUNBLFNBQVM7RUFDbkIsT0FDSztHQUNELE9BQU87RUFDWDtDQUNKO0FBQ0o7QUFDQSxTQUFTLGFBQWEsU0FBUyxNQUU3QjtDQUNFLE1BQU0sV0FBVyxjQUFjLFFBQVEsUUFBUSxJQUFJO0NBQ25ELElBQUksVUFBVTs7O0VBR1YsUUFBUSxRQUFRLHNCQUFzQixRQUFRO0NBQ2xEO0NBQ0EsT0FBTztBQUNYO0FBQ0EsU0FBUyxzQkFBc0IsVUFBVTtDQUNyQyxNQUFNLFFBQVEsQ0FBQztDQUNmLE1BQU0sYUFBYTtDQUNuQixNQUFNLGVBQWU7RUFDakI7R0FDSSxNQUFNO0dBQ04sS0FBSztHQUNMLFVBQVU7R0FDVixPQUFPLFNBQVMsT0FBTztFQUMzQjtFQUNBO0dBQ0ksTUFBTTtHQUNOLEtBQUs7R0FDTCxVQUFVO0dBQ1YsT0FBTyxTQUFTLGVBQWU7RUFDbkM7RUFDQTtHQUNJLE1BQU07R0FDTixLQUFLO0dBQ0wsVUFBVTtHQUNWLE9BQU8sU0FBUztFQUNwQjtFQUNBO0dBQ0ksTUFBTTtHQUNOLEtBQUs7R0FDTCxVQUFVO0dBQ1YsT0FBTyxTQUFTO0VBQ3BCO0NBQ0o7Q0FDQSxNQUFNLGNBQWM7Q0FDcEIsTUFBTSxxQkFBcUI7Q0FDM0IsTUFBTSx1QkFBdUIsQ0FDekI7RUFDSSxNQUFNO0VBQ04sS0FBSztFQUNMLFVBQVU7RUFDVixPQUFPLHNCQUFzQixTQUFTLFNBQVMsS0FBSztDQUN4RCxDQUNKO0NBQ0EsTUFBTSxzQkFBc0I7Q0FDNUI7RUFDSSxNQUFNLHNCQUFzQjtFQUM1QixNQUFNLHdCQUF3QixDQUMxQjtHQUNJLE1BQU07R0FDTixLQUFLO0dBQ0wsVUFBVTtHQUNWLE9BQU8sU0FBUyxnQkFBZ0I7RUFDcEMsQ0FDSjtFQUNBLE1BQU0sdUJBQXVCO0VBQzdCLE1BQU0sb0JBQW9CO0VBQzFCLE1BQU0sc0JBQXNCLENBQ3hCO0dBQ0ksTUFBTTtHQUNOLEtBQUs7R0FDTCxVQUFVO0dBQ1YsT0FBTyxTQUFTLGNBQWM7RUFDbEMsQ0FDSjtFQUNBLE1BQU0scUJBQXFCO0NBQy9CO0NBQ0EsT0FBTztBQUNYO0FBQ0EsU0FBUyxpQkFBaUIsT0FBTyxTQUFTO0NBQ3RDLElBQUksYUFBYTtFQUNiLElBQUk7RUFDSixJQUFJLFdBQVcsYUFBYSxTQUFTO0dBQ2pDLFVBQVUsUUFBUTtHQUNsQixPQUFPLFFBQVE7RUFDbkI7RUFDQSxZQUFZLGlCQUFpQjtHQUN6QixTQUFTO0dBQ1QsT0FBTztJQUNILE9BQU87SUFDUDtJQUNBLE1BQU0sS0FBSyxJQUFJO0lBQ2YsTUFBTSxDQUFDO0lBQ1AsTUFBTSxXQUFXLENBQUM7SUFDbEIsU0FBUyxVQUFVLGtCQUNiLFVBQ0EsVUFBVSxjQUFjLFVBQVUsWUFDOUIsWUFDQTtHQUNkO0VBQ0osQ0FBQztDQUNMO0FBQ0o7QUFDQSxTQUFTLFVBQVUsU0FBUyxNQUFNO0NBQzlCLE1BQU0sV0FBVyxjQUFjLFFBQVEsUUFBUSxJQUFJO0NBQ25ELElBQUksVUFBVTtFQUNWLE1BQU0sQ0FBQyxTQUFTLFFBQVE7RUFDeEIsSUFBSSxVQUFVLFlBQVksU0FBUyxRQUFRLE1BQU0sS0FBSyxHQUFHO0dBQ3JELFNBQVMsT0FBTyxRQUFRLFFBQVEsTUFBTTtFQUMxQyxPQUNLLElBQUksVUFBVSxxQkFDZCxTQUFTLFFBQVEsTUFBTSxLQUFLLEtBQ3pCLFFBQVEsUUFBUSxNQUFNLEtBQUssS0FDM0IsU0FBUyxRQUFRLE1BQU0sS0FBSyxJQUFJO0dBQ3BDLFNBQVMsZUFBZSxRQUFRLFFBQVEsTUFBTTtFQUNsRCxPQUNLLElBQUksVUFBVSxtQkFBbUIsVUFBVSxRQUFRLE1BQU0sS0FBSyxHQUFHO0dBQ2xFLFNBQVMsZ0JBQWdCLFFBQVEsTUFBTTtFQUMzQztDQUNKO0FBQ0o7Ozs7Ozs7QUFRQSxTQUFTLHVCQUF1QixTQUFTO0NBQ3JDLE1BQU0sU0FBUyxTQUFTLFFBQVEsTUFBTSxJQUFJLFFBQVEsU0FBUztDQUMzRCxNQUFNLGlCQUFpQixTQUFTLFFBQVEsY0FBYyxLQUNsRCxRQUFRLFFBQVEsY0FBYyxLQUM5QixjQUFjLFFBQVEsY0FBYyxLQUNwQyxRQUFRLG1CQUFtQixRQUN6QixRQUFRLGlCQUNSO0NBQ04sTUFBTSxVQUFVLFdBQVcsUUFBUSxPQUFPLElBQUksUUFBUSxVQUFVO0NBQ2hFLE1BQU0sY0FBYyxVQUFVLFFBQVEscUJBQXFCLEtBQ3ZELFNBQVMsUUFBUSxxQkFBcUIsSUFDcEMsQ0FBQyxRQUFRLHdCQUNUO0NBQ04sTUFBTSxlQUFlLFVBQVUsUUFBUSxrQkFBa0IsS0FDckQsU0FBUyxRQUFRLGtCQUFrQixJQUNqQyxDQUFDLFFBQVEscUJBQ1Q7Q0FDTixNQUFNLGVBQWUsVUFBVSxRQUFRLFlBQVksSUFDN0MsUUFBUSxlQUNSO0NBQ04sTUFBTSxpQkFBaUIsQ0FBQyxDQUFDLFFBQVE7Q0FDakMsTUFBTSxZQUFZLGNBQWMsUUFBUSxTQUFTLElBQUksUUFBUSxZQUFZLENBQUM7Q0FDMUUsTUFBTSxxQkFBcUIsUUFBUTtDQUNuQyxNQUFNLGtCQUFrQixXQUFXLFFBQVEsZUFBZSxJQUNwRCxRQUFRLGtCQUNSO0NBQ04sTUFBTSxrQkFBa0IsU0FBUyxRQUFRLGlCQUFpQixJQUNwRCxRQUFRLHNCQUFzQixRQUM5QjtDQUNOLE1BQU0sa0JBQWtCLENBQUMsQ0FBQyxRQUFRO0NBQ2xDLE1BQU0sZ0JBQWdCLFVBQVUsUUFBUSxJQUFJLElBQUksUUFBUSxPQUFPO0NBQy9ELElBQUksV0FBVyxRQUFRO0NBQ3ZCLElBQUksY0FBYyxRQUFRLGNBQWMsR0FBRztFQUN2QyxNQUFNLGlCQUFpQixRQUFRO0VBQy9CLE1BQU0sVUFBVSxPQUFPLEtBQUssY0FBYztFQUMxQyxXQUFXLFFBQVEsUUFBUSxVQUFVLFdBQVc7R0FDNUMsTUFBTSxVQUFVLFNBQVMsWUFBWSxTQUFTLFVBQVUsQ0FBQztHQUN6RCxPQUFPLFNBQVMsZUFBZSxPQUFPO0dBQ3RDLE9BQU87RUFDWCxHQUFJLFlBQVksQ0FBQyxDQUFFO0NBQ3ZCO0NBQ0EsTUFBTSxFQUFFLFFBQVEsUUFBUSx1QkFBdUI7Q0FDL0MsTUFBTSxrQkFBa0IsUUFBUTtDQUNoQyxNQUFNLGdCQUFnQixRQUFRO0NBQzlCLE1BQU0sV0FBVyxRQUFRO0NBQ3pCLE9BQU87RUFDSDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxhQUFhO0VBQ2I7RUFDQTtFQUNBO0VBQ0EsaUJBQWlCLFFBQVE7RUFDekI7RUFDQTtFQUNBO0VBQ0E7Q0FDSjtBQUNKOzs7Ozs7OztBQVFBLFNBQVMsY0FBYyxVQUFVLENBQUMsR0FBRztDQUNqQyxNQUFNLFdBQVcsZUFBZSx1QkFBdUIsT0FBTyxDQUFDO0NBQy9ELE1BQU0sRUFBRSxlQUFlOztDQUV2QixNQUFNLFVBQVU7O0VBRVosSUFBSSxTQUFTOztFQUViLElBQUksU0FBUztHQUNULE9BQU8sU0FBUyxPQUFPO0VBQzNCO0VBQ0EsSUFBSSxPQUFPLEtBQUs7R0FDWixTQUFTLE9BQU8sUUFBUTtFQUM1Qjs7RUFFQSxJQUFJLGlCQUFpQjtHQUNqQixPQUFPLFNBQVMsZUFBZTtFQUNuQztFQUNBLElBQUksZUFBZSxLQUFLO0dBQ3BCLFNBQVMsZUFBZSxRQUFRO0VBQ3BDOztFQUVBLElBQUksV0FBVztHQUNYLE9BQU8sU0FBUyxTQUFTO0VBQzdCOztFQUVBLElBQUksa0JBQWtCO0dBQ2xCLE9BQU8sU0FBUyxnQkFBZ0I7RUFDcEM7O0VBRUEsSUFBSSxnQkFBZ0I7R0FDaEIsT0FBTyxTQUFTLGNBQWM7RUFDbEM7O0VBRUEsSUFBSSxtQkFBbUI7R0FDbkIsT0FBTyxTQUFTO0VBQ3BCOztFQUVBLElBQUksVUFBVTtHQUNWLE9BQU8sU0FBUyxrQkFBa0I7RUFDdEM7RUFDQSxJQUFJLFFBQVEsU0FBUztHQUNqQixTQUFTLGtCQUFrQixPQUFPO0VBQ3RDOztFQUVBLElBQUksd0JBQXdCO0dBQ3hCLE9BQU8sVUFBVSxTQUFTLFdBQVcsSUFDL0IsQ0FBQyxTQUFTLGNBQ1YsU0FBUztFQUNuQjtFQUNBLElBQUksc0JBQXNCLEtBQUs7R0FDM0IsU0FBUyxjQUFjLFVBQVUsR0FBRyxJQUFJLENBQUMsTUFBTTtFQUNuRDs7RUFFQSxJQUFJLHFCQUFxQjtHQUNyQixPQUFPLFVBQVUsU0FBUyxZQUFZLElBQ2hDLENBQUMsU0FBUyxlQUNWLFNBQVM7RUFDbkI7RUFDQSxJQUFJLG1CQUFtQixLQUFLO0dBQ3hCLFNBQVMsZUFBZSxVQUFVLEdBQUcsSUFBSSxDQUFDLE1BQU07RUFDcEQ7O0VBRUEsSUFBSSxZQUFZO0dBQ1osT0FBTyxTQUFTO0VBQ3BCOztFQUVBLElBQUkseUJBQXlCO0dBQ3pCLE9BQU8sU0FBUztFQUNwQjtFQUNBLElBQUksdUJBQXVCLEtBQUs7R0FDNUIsU0FBUyxpQkFBaUI7RUFDOUI7O0VBRUEsSUFBSSxrQkFBa0I7R0FDbEIsT0FBTyxTQUFTLDBCQUEwQjtFQUM5QztFQUNBLElBQUksZ0JBQWdCLFNBQVM7R0FDekIsU0FBUywwQkFBMEIsT0FBTztFQUM5Qzs7RUFFQSxJQUFJLE9BQU87R0FDUCxPQUFPLFNBQVM7RUFDcEI7RUFDQSxJQUFJLEtBQUssS0FBSztHQUNWLFNBQVMsZ0JBQWdCO0VBQzdCOztFQUVBLElBQUksb0JBQW9CO0dBQ3BCLE9BQU8sU0FBUyxrQkFBa0IsU0FBUztFQUMvQztFQUNBLElBQUksa0JBQWtCLEtBQUs7R0FDdkIsU0FBUyxrQkFBa0IsUUFBUTtFQUN2Qzs7RUFFQSxJQUFJLHNCQUFzQjtHQUN0QixPQUFPLFNBQVM7RUFDcEI7RUFDQSxJQUFJLG9CQUFvQixLQUFLO0dBQ3pCLFNBQVMsa0JBQWtCO0VBQy9COztFQUVBLElBQUkscUJBQXFCO0dBQ3JCLE9BQU8sU0FBUyxlQUFlLENBQUM7RUFDcEM7O0VBRUEsWUFBWTs7RUFFWixFQUFFLEdBQUcsTUFBTTtHQUNQLE9BQU8sUUFBUSxNQUFNLFNBQVMsR0FBRyxVQUFVLENBQUMsR0FBRyxJQUFJLENBQUM7RUFDeEQ7O0VBRUEsR0FBRyxHQUFHLE1BQU07R0FDUixPQUFPLFFBQVEsTUFBTSxTQUFTLElBQUksVUFBVSxDQUFDLEdBQUcsSUFBSSxDQUFDO0VBQ3pEOztFQUVBLEdBQUcsS0FBSyxRQUFRO0dBQ1osT0FBTyxTQUFTLEdBQUcsS0FBSyxNQUFNO0VBQ2xDOztFQUVBLEdBQUcsS0FBSztHQUNKLE9BQU8sU0FBUyxHQUFHLEdBQUc7RUFDMUI7O0VBRUEsaUJBQWlCLFFBQVE7R0FDckIsT0FBTyxTQUFTLGlCQUFpQixNQUFNO0VBQzNDOztFQUVBLGlCQUFpQixRQUFRLFNBQVM7R0FDOUIsU0FBUyxpQkFBaUIsUUFBUSxPQUFPO0VBQzdDOztFQUVBLG1CQUFtQixRQUFRLFNBQVM7R0FDaEMsU0FBUyxtQkFBbUIsUUFBUSxPQUFPO0VBQy9DOztFQUVBLEVBQUUsR0FBRyxNQUFNO0dBQ1AsT0FBTyxRQUFRLE1BQU0sU0FBUyxHQUFHLFVBQVUsQ0FBQyxHQUFHLElBQUksQ0FBQztFQUN4RDs7RUFFQSxrQkFBa0IsUUFBUTtHQUN0QixPQUFPLFNBQVMsa0JBQWtCLE1BQU07RUFDNUM7O0VBRUEsa0JBQWtCLFFBQVEsUUFBUTtHQUM5QixTQUFTLGtCQUFrQixRQUFRLE1BQU07RUFDN0M7O0VBRUEsb0JBQW9CLFFBQVEsUUFBUTtHQUNoQyxTQUFTLG9CQUFvQixRQUFRLE1BQU07RUFDL0M7O0VBRUEsRUFBRSxHQUFHLE1BQU07R0FDUCxPQUFPLFFBQVEsTUFBTSxTQUFTLEdBQUcsVUFBVSxDQUFDLEdBQUcsSUFBSSxDQUFDO0VBQ3hEOztFQUVBLGdCQUFnQixRQUFRO0dBQ3BCLE9BQU8sU0FBUyxnQkFBZ0IsTUFBTTtFQUMxQzs7RUFFQSxnQkFBZ0IsUUFBUSxRQUFRO0dBQzVCLFNBQVMsZ0JBQWdCLFFBQVEsTUFBTTtFQUMzQzs7RUFFQSxrQkFBa0IsUUFBUSxRQUFRO0dBQzlCLFNBQVMsa0JBQWtCLFFBQVEsTUFBTTtFQUM3QztDQUNKO0NBQ0EsUUFBUSxhQUFhOztDQUVyQixzQkFBOEIsY0FBZTtFQUN6QyxRQUFRLG1CQUFtQixZQUFZO0dBQ25DLE1BQU0sYUFBYTtHQUNuQixXQUFXLGtCQUFrQixXQUFXLGNBQWMsQ0FBQyxPQUFPO0VBQ2xFO0VBQ0EsUUFBUSx5QkFBeUI7R0FDN0IsTUFBTSxhQUFhO0dBQ25CLFdBQVcsbUJBQW1CLFdBQVcsZUFBZSxDQUFDO0VBQzdEO0NBQ0o7Q0FDQSxPQUFPO0FBQ1g7Ozs7OztBQU9BLFNBQVMsWUFBWSxTQUFTLFVBQVUsTUFBTTtDQUMxQyxPQUFPO0VBQ0gsZUFBZTtHQUNYLE1BQU0sV0FBVyxtQkFBbUI7O0dBRXBDLElBQUksQ0FBQyxVQUFVO0lBQ1gsTUFBTSxnQkFBZ0IsZUFBZSxnQkFBZ0I7R0FDekQ7R0FDQSxNQUFNLFVBQVUsS0FBSztHQUNyQixJQUFJLFFBQVEsTUFBTTtJQUNkLE1BQU0sY0FBYyxRQUFRO0lBQzVCLElBQUksUUFBUSxRQUFRO0tBQ2hCLFlBQVksU0FBUyxRQUFRO0lBQ2pDO0lBQ0EsWUFBWSxTQUFTO0lBQ3JCLElBQUksU0FBUyxLQUFLLE9BQU87O0tBRXJCLEtBQUssUUFBUSxjQUFjLFNBQVMsV0FBVztJQUNuRCxPQUNLO0tBQ0QsWUFBWSxxQkFBcUI7S0FDakMsWUFBWSxhQUFhLEtBQUs7O0tBRTlCLEtBQUssUUFBUSxjQUFjLFdBQVc7O0tBRXRDLE1BQU0sV0FBVyxLQUFLO0tBQ3RCLElBQUksU0FBUyxZQUFZO01BQ3JCLFNBQVMsYUFBYSxTQUFTLFdBQVcsS0FBSyxLQUFLO0tBQ3hEO0lBQ0o7R0FDSixPQUNLLElBQUksUUFBUSxRQUFRO0lBQ3JCLElBQUksU0FBUyxLQUFLLE9BQU87O0tBRXJCLEtBQUssUUFBUSxjQUFjLFNBQVMsT0FBTztJQUMvQyxPQUNLOztLQUVELEtBQUssUUFBUSxjQUFjO01BQ3ZCLFFBQVEsUUFBUTtNQUNoQixvQkFBb0I7TUFDcEIsWUFBWSxLQUFLO01BQ2pCLFFBQVE7S0FDWixDQUFDOztLQUVELE1BQU0sV0FBVyxLQUFLO0tBQ3RCLElBQUksU0FBUyxZQUFZO01BQ3JCLFNBQVMsYUFBYSxTQUFTLFdBQVcsS0FBSyxLQUFLO0tBQ3hEO0lBQ0o7R0FDSixPQUNLOztJQUVELEtBQUssUUFBUTtHQUNqQjtHQUNBLElBQUksUUFBUSxjQUFjO0lBQ3RCLG9CQUFvQixVQUFVLFNBQVMsT0FBTztHQUNsRDs7R0FFQSxLQUFLLE1BQU0sR0FBRyxTQUFTLEtBQUssTUFBTSxFQUFFLEdBQUcsSUFBSTtHQUMzQyxLQUFLLE9BQU8sR0FBRyxTQUFTLEtBQUssTUFBTSxHQUFHLEdBQUcsSUFBSTtHQUM3QyxLQUFLLE9BQU8sS0FBSyxXQUFXLEtBQUssTUFBTSxHQUFHLEtBQUssTUFBTTtHQUNyRCxLQUFLLE1BQU0sR0FBRyxTQUFTLEtBQUssTUFBTSxFQUFFLEdBQUcsSUFBSTtHQUMzQyxLQUFLLE1BQU0sR0FBRyxTQUFTLEtBQUssTUFBTSxFQUFFLEdBQUcsSUFBSTtHQUMzQyxLQUFLLE9BQU8sUUFBUSxLQUFLLE1BQU0sR0FBRyxHQUFHO0dBQ3JDLEtBQUssY0FBYyxVQUFVLEtBQUssS0FBSztFQUMzQztFQUNBLFVBQVU7O0dBRU4sdUJBQStCLGdCQUFpQiwwQkFDNUMsUUFDQSxLQUFLLE9BQU87SUFDWixNQUFNLFdBQVcsbUJBQW1CO0lBQ3BDLElBQUksQ0FBQyxVQUFVO0tBQ1g7SUFDSjtJQUNBLE1BQU0sV0FBVyxLQUFLO0lBQ3RCLFNBQVMsZUFBZSxTQUFTO0lBQ2pDLE1BQU0sVUFBVyxLQUFLLGNBQ2xCLGNBQWM7SUFDbEIsU0FBUyxtQkFBbUIsU0FBUyxnQkFBZ0IsT0FBTztJQUM1RCxRQUFRLEdBQUcsS0FBSyxnQkFBZ0I7R0FDcEM7RUFDSjtFQUNBLFlBQVk7R0FDUixNQUFNLFdBQVcsbUJBQW1COztHQUVwQyxJQUFJLENBQUMsVUFBVTtJQUNYLE1BQU0sZ0JBQWdCLGVBQWUsZ0JBQWdCO0dBQ3pEO0dBQ0EsTUFBTSxXQUFXLEtBQUs7O0dBRXRCLHVCQUErQixnQkFBaUIsMEJBQzVDLFFBQ0EsU0FBUyxjQUFjO0lBQ3ZCLElBQUksS0FBSyxhQUFhO0tBQ2xCLEtBQUssWUFBWSxJQUFJLEtBQUssZ0JBQWdCO0tBQzFDLE9BQU8sS0FBSztJQUNoQjtJQUNBLElBQUksVUFBVTtLQUNWLFNBQVMsb0JBQW9CLFNBQVMsaUJBQWlCO0tBQ3ZELE9BQU8sU0FBUztJQUNwQjtHQUNKOztHQUVBLElBQUksQ0FBQyxVQUFVO0lBQ1g7R0FDSjtHQUNBLE9BQU8sS0FBSztHQUNaLE9BQU8sS0FBSztHQUNaLE9BQU8sS0FBSztHQUNaLE9BQU8sS0FBSztHQUNaLE9BQU8sS0FBSztHQUNaLE9BQU8sS0FBSztHQUNaLElBQUksVUFBVSxZQUFZO0lBQ3RCLFNBQVMsV0FBVztJQUNwQixPQUFPLFNBQVM7SUFDaEIsT0FBTyxTQUFTO0dBQ3BCO0dBQ0EsS0FBSyxpQkFBaUIsUUFBUTtHQUM5QixPQUFPLEtBQUs7RUFDaEI7Q0FDSjtBQUNKO0FBQ0EsU0FBUyxjQUFjLEdBQUcsU0FBUztDQUMvQixFQUFFLFNBQVMsUUFBUSxVQUFVLEVBQUU7Q0FDL0IsRUFBRSxpQkFBaUIsUUFBUSxrQkFBa0IsRUFBRTtDQUMvQyxFQUFFLFVBQVUsUUFBUSxXQUFXLEVBQUU7Q0FDakMsRUFBRSx3QkFDRSxRQUFRLHlCQUF5QixFQUFFO0NBQ3ZDLEVBQUUscUJBQXFCLFFBQVEsc0JBQXNCLEVBQUU7Q0FDdkQsRUFBRSx5QkFDRSxRQUFRLDBCQUEwQixFQUFFO0NBQ3hDLEVBQUUsa0JBQWtCLFFBQVEsbUJBQW1CLEVBQUU7Q0FDakQsRUFBRSxvQkFBb0IsUUFBUSxxQkFBcUIsRUFBRTtDQUNyRCxFQUFFLHNCQUFzQixRQUFRLHVCQUF1QixFQUFFO0NBQ3pELEVBQUUsT0FBTyxRQUFRLFFBQVEsRUFBRTtDQUMzQixFQUFFLFdBQVcscUJBQXFCLENBQUMsUUFBUSxzQkFBc0IsRUFBRSxrQkFBa0I7Q0FDckYsTUFBTSxXQUFXLGtCQUFrQixFQUFFLFFBQVE7RUFDekMsVUFBVSxRQUFRO0VBQ2xCLFFBQVEsUUFBUTtDQUNwQixDQUFDO0NBQ0QsT0FBTyxLQUFLLFFBQVEsQ0FBQyxDQUFDLFNBQVEsV0FBVSxFQUFFLG1CQUFtQixRQUFRLFNBQVMsT0FBTyxDQUFDO0NBQ3RGLElBQUksUUFBUSxpQkFBaUI7RUFDekIsT0FBTyxLQUFLLFFBQVEsZUFBZSxDQUFDLENBQUMsU0FBUSxXQUFVLEVBQUUsb0JBQW9CLFFBQVEsUUFBUSxnQkFBZ0IsT0FBTyxDQUFDO0NBQ3pIO0NBQ0EsSUFBSSxRQUFRLGVBQWU7RUFDdkIsT0FBTyxLQUFLLFFBQVEsYUFBYSxDQUFDLENBQUMsU0FBUSxXQUFVLEVBQUUsa0JBQWtCLFFBQVEsUUFBUSxjQUFjLE9BQU8sQ0FBQztDQUNuSDtDQUNBLE9BQU87QUFDWDtBQUVBLE1BQU0sa0JBQWtCO0NBQ3BCLEtBQUssRUFDRCxNQUFNLENBQUMsUUFBUSxNQUFNLEVBQ3pCO0NBQ0EsUUFBUSxFQUNKLE1BQU0sT0FDVjtDQUNBLE9BQU87RUFDSCxNQUFNOztFQUVOLFlBQVksUUFBaUMsUUFBUSxZQUFZLFFBQVE7RUFDekUsU0FBUztDQUNiO0NBQ0EsTUFBTSxFQUNGLE1BQU0sT0FDVjtBQUNKO0FBRUEsU0FBUyxrQkFFVCxFQUFFLFNBQ0YsTUFBTTtDQUNGLElBQUksS0FBSyxXQUFXLEtBQUssS0FBSyxPQUFPLFdBQVc7O0VBRTVDLE1BQU0sTUFBTSxNQUFNLFVBQVUsTUFBTSxRQUFRLElBQUksQ0FBQzs7RUFFL0MsT0FBTyxJQUFJLFFBQVEsTUFBTSxZQUFZO0dBQ2pDLE9BQU8sQ0FDSCxHQUFHLE1BRUgsR0FBSSxRQUFRLFNBQVMsV0FBVyxRQUFRLFdBQVcsQ0FBQyxPQUFPLENBQy9EO0VBQ0osR0FBRyxDQUFDLENBQUM7Q0FDVCxPQUNLOztFQUVELE9BQU8sS0FBSyxRQUFRLEtBQUssUUFBUTtHQUM3QixNQUFNLE9BQU8sTUFBTTtHQUNuQixJQUFJLE1BQU07SUFDTixJQUFJLE9BQU8sS0FBSztHQUNwQjtHQUNBLE9BQU87RUFDWCxHQUFHLE9BQU8sQ0FBQztDQUNmO0FBQ0o7O0FBRUEsU0FBUyxxQkFBcUI7Q0FDMUIsT0FBTztBQUNYO0FBRUEsTUFBTSxrQkFBZ0MsOEJBQWdCOztDQUVsRCxNQUFNO0NBQ04sT0FBTyxPQUFPO0VBQ1YsU0FBUztHQUNMLE1BQU07R0FDTixVQUFVO0VBQ2Q7RUFDQSxRQUFRO0dBQ0osTUFBTSxDQUFDLFFBQVEsTUFBTTtHQUNyQixZQUFZLFFBQVEsU0FBUyxHQUFHLEtBQUssQ0FBQyxNQUFNLEdBQUc7RUFDbkQ7Q0FDSixHQUFHLGVBQWU7OztDQUdsQixNQUFNLE9BQU8sU0FBUztFQUNsQixNQUFNLEVBQUUsT0FBTyxVQUFVOztFQUV6QixNQUFNLE9BQU8sTUFBTSxRQUNmLFFBQVE7R0FDSixVQUFVLE1BQU07R0FDaEIsZ0JBQWdCO0VBQ3BCLENBQUM7RUFDTCxhQUFhO0dBQ1QsTUFBTSx1QkFBdUI7SUFDekIsTUFBTSxPQUFPLE9BQU8sS0FBSyxLQUFLLENBQUMsQ0FBQyxRQUFPLFFBQU8sSUFBSSxPQUFPLEdBQUc7SUFDNUQsTUFBTSxVQUFVLE9BQU87SUFDdkIsSUFBSSxNQUFNLFFBQVE7S0FDZCxRQUFRLFNBQVMsTUFBTTtJQUMzQjtJQUNBLElBQUksTUFBTSxXQUFXLFdBQVc7S0FDNUIsUUFBUSxTQUFTLFNBQVMsTUFBTSxNQUFNLElBQUksQ0FBQyxNQUFNLFNBQVMsTUFBTTtJQUNwRTtJQUNBLE1BQU0sTUFBTSxrQkFBa0IsU0FBUyxJQUFJOztJQUUzQyxPQUFPLEtBQUsscUJBQXFCLENBQUMsTUFBTSxTQUFTLEtBQUssT0FBTztHQUNqRTtHQUNBLE1BQU0sZ0JBQWdCLE9BQU8sT0FBTyxHQUFHLEtBQUs7R0FDNUMsTUFBTSxNQUFNLFNBQVMsTUFBTSxHQUFHLEtBQUssU0FBUyxNQUFNLEdBQUcsSUFDL0MsTUFBTSxNQUNOLG1CQUFtQjtHQUN6QixPQUFPLFNBQVMsR0FBRyxJQUNiLEVBQUUsS0FBSyxlQUFlLEVBQUUsU0FBUyxlQUFlLENBQUMsSUFDakQsRUFBRSxLQUFLLGVBQWUsZUFBZSxDQUFDO0VBQ2hEO0NBQ0o7QUFDSixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFzREQsTUFBTSxjQUFjO0FBQ3BCLE1BQU0sUUFBUTtBQUVkLFNBQVMsUUFBUSxRQUFRO0NBQ3JCLE9BQU8sUUFBUSxNQUFNLEtBQUssQ0FBQyxTQUFTLE9BQU8sRUFBRTtBQUNqRDtBQUNBLFNBQVMsZ0JBQWdCLE9BQU8sU0FBUyxVQUFVLGVBQWU7Q0FDOUQsTUFBTSxFQUFFLE9BQU8sVUFBVTtDQUN6QixhQUFhO0VBQ1QsTUFBTSx1QkFBdUI7R0FDekIsTUFBTSxVQUFVLEVBQUUsTUFBTSxLQUFLO0dBQzdCLElBQUksWUFBWSxPQUFPO0dBQ3ZCLElBQUksTUFBTSxRQUFRO0lBQ2QsUUFBUSxTQUFTLE1BQU07R0FDM0I7R0FDQSxJQUFJLFNBQVMsTUFBTSxNQUFNLEdBQUc7SUFDeEIsUUFBUSxNQUFNLE1BQU07R0FDeEIsT0FDSyxJQUFJLFNBQVMsTUFBTSxNQUFNLEdBQUc7O0lBRTdCLElBQUksU0FBUyxNQUFNLE9BQU8sR0FBRyxHQUFHOztLQUU1QixRQUFRLE1BQU0sTUFBTSxPQUFPO0lBQy9COztJQUVBLFlBQVksT0FBTyxLQUFLLE1BQU0sTUFBTSxDQUFDLENBQUMsUUFBUSxTQUFTLFNBQVM7S0FDNUQsT0FBTyxTQUFTLFNBQVMsSUFBSSxJQUN2QixPQUFPLE9BQU8sR0FBRyxTQUFTLEdBQUcsT0FBTyxNQUFNLE9BQU8sTUFBTSxDQUFDLElBQ3hEO0lBQ1YsR0FBRyxPQUFPLENBQUM7R0FDZjtHQUNBLE1BQU0sUUFBUSxjQUFjLEdBQUc7SUFBQyxNQUFNO0lBQU87SUFBUztHQUFTLENBQUM7R0FDaEUsSUFBSSxXQUFXLENBQUMsUUFBUSxHQUFHO0dBQzNCLElBQUksUUFBUSxLQUFLLEdBQUc7SUFDaEIsV0FBVyxNQUFNLEtBQUssTUFBTSxVQUFVO0tBQ2xDLE1BQU0sT0FBTyxNQUFNLEtBQUs7S0FDeEIsTUFBTSxPQUFPLE9BQ1AsS0FBSztPQUFHLEtBQUssT0FBTyxLQUFLO01BQU87TUFBTztLQUFNLENBQUMsSUFDOUMsQ0FBQyxLQUFLLEtBQUs7S0FDakIsSUFBSSxRQUFRLElBQUksR0FBRztNQUNmLEtBQUssRUFBRSxDQUFDLE1BQU0sR0FBRyxLQUFLLEtBQUssR0FBRztLQUNsQztLQUNBLE9BQU87SUFDWCxDQUFDO0dBQ0wsT0FDSyxJQUFJLFNBQVMsS0FBSyxHQUFHO0lBQ3RCLFdBQVcsQ0FBQyxLQUFLO0dBQ3JCO0dBQ0EsT0FBTztFQUNYO0VBQ0EsTUFBTSxnQkFBZ0IsT0FBTyxPQUFPLEdBQUcsS0FBSztFQUM1QyxNQUFNLE1BQU0sU0FBUyxNQUFNLEdBQUcsS0FBSyxTQUFTLE1BQU0sR0FBRyxJQUMvQyxNQUFNLE1BQ04sbUJBQW1CO0VBQ3pCLE9BQU8sU0FBUyxHQUFHLElBQ2IsRUFBRSxLQUFLLGVBQWUsRUFBRSxTQUFTLGVBQWUsQ0FBQyxJQUNqRCxFQUFFLEtBQUssZUFBZSxlQUFlLENBQUM7Q0FDaEQ7QUFDSjtBQUVBLE1BQU0sbUJBQWlDLDhCQUFnQjs7Q0FFbkQsTUFBTTtDQUNOLE9BQU8sT0FBTztFQUNWLE9BQU87R0FDSCxNQUFNO0dBQ04sVUFBVTtFQUNkO0VBQ0EsUUFBUSxFQUNKLE1BQU0sQ0FBQyxRQUFRLE1BQU0sRUFDekI7Q0FDSixHQUFHLGVBQWU7OztDQUdsQixNQUFNLE9BQU8sU0FBUztFQUNsQixNQUFNLE9BQU8sTUFBTSxRQUNmLFFBQVE7R0FDSixVQUFVLE1BQU07R0FDaEIsZ0JBQWdCO0VBQ3BCLENBQUM7RUFDTCxPQUFPLGdCQUFnQixPQUFPLFNBQVMsNkJBQTZCLEdBQUcsU0FFdkUsS0FBSyxrQkFBa0IsQ0FBQyxHQUFHLElBQUksQ0FBQztDQUNwQztBQUNKLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFzQkQsTUFBTSxlQUFlO0FBQ3JCLE1BQU0sUUFBUTtBQUVkLFNBQVMsY0FBYyxNQUFNLFVBQVU7Q0FDbkMsTUFBTSxlQUFlO0NBQ3JCLElBQUksS0FBSyxTQUFTLGVBQWU7RUFDN0IsT0FBUSxhQUFhLGNBQWMsUUFBUSxLQUFLLEtBQUs7Q0FDekQsT0FDSztFQUNELE1BQU0sVUFBVSxhQUFhLGNBQWMsUUFBUTtFQUNuRCxPQUFPLFdBQVcsT0FDWixRQUFRLGFBQ1IsS0FBSyxPQUFPO0NBQ3RCO0FBQ0o7Ozs7QUFJQSxTQUFTLFlBQVksTUFBTTtDQUN2QixNQUFNLFlBQVksWUFBWTtFQUMxQixzQkFBOEIsY0FBZTtHQUN6QyxTQUFTLGVBQWUsY0FBYyxxQ0FBcUMsQ0FBQztFQUNoRjtFQUNBLE1BQU0sRUFBRSxVQUFVLFVBQVU7O0VBRTVCLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxHQUFHO0dBQzFCLE1BQU0sZ0JBQWdCLGVBQWUsZ0JBQWdCO0VBQ3pEO0VBQ0EsTUFBTSxXQUFXLGNBQWMsTUFBTSxTQUFTLENBQUM7RUFDL0MsTUFBTSxjQUFjLFdBQVcsS0FBSztFQUNwQyxPQUFPLENBQ0gsUUFBUSxNQUFNLFNBQVMsR0FBRyxVQUFVLENBQUMsR0FBRyxXQUFXLFdBQVcsQ0FBQyxDQUFDLEdBQ2hFLFFBQ0o7Q0FDSjtDQUNBLE1BQU0sWUFBWSxJQUFJLFlBQVk7RUFDOUIsTUFBTSxDQUFDLGFBQWEsWUFBWSxTQUFTLE9BQU87RUFDaEQsSUFBSSxXQUFXO0dBQ1gsR0FBRyxnQkFBZ0IsTUFBTSxTQUFTLGNBQWM7SUFDNUMsUUFBUSxZQUFZLFFBQVEsU0FBUyxhQUFhO0dBQ3RELENBQUM7RUFDTDtFQUNBLEdBQUcsYUFBYTtFQUNoQixHQUFHLGNBQWM7Q0FDckI7Q0FDQSxNQUFNLGNBQWMsT0FBTztFQUN2QixJQUFJLGFBQWEsR0FBRyxlQUFlO0dBQy9CLEdBQUcsY0FBYztHQUNqQixHQUFHLGdCQUFnQjtHQUNuQixPQUFPLEdBQUc7RUFDZDtFQUNBLElBQUksR0FBRyxZQUFZO0dBQ2YsR0FBRyxhQUFhO0dBQ2hCLE9BQU8sR0FBRztFQUNkO0NBQ0o7Q0FDQSxNQUFNLFVBQVUsSUFBSSxFQUFFLFlBQVk7RUFDOUIsSUFBSSxHQUFHLFlBQVk7R0FDZixNQUFNLFdBQVcsR0FBRztHQUNwQixNQUFNLGNBQWMsV0FBVyxLQUFLO0dBQ3BDLEdBQUcsY0FBYyxRQUFRLE1BQU0sU0FBUyxHQUFHLFVBQVUsQ0FDakQsR0FBRyxXQUFXLFdBQVcsQ0FDN0IsQ0FBQztFQUNMO0NBQ0o7Q0FDQSxNQUFNLGVBQWUsWUFBWTtFQUM3QixNQUFNLENBQUMsZUFBZSxTQUFTLE9BQU87RUFDdEMsT0FBTyxFQUFFLFlBQVk7Q0FDekI7Q0FDQSxPQUFPO0VBQ0gsU0FBUztFQUNULFdBQVc7RUFDWCxjQUFjO0VBQ2Q7Q0FDSjtBQUNKO0FBQ0EsU0FBUyxXQUFXLE9BQU87Q0FDdkIsSUFBSSxTQUFTLEtBQUssR0FBRztFQUNqQixPQUFPLEVBQUUsTUFBTSxNQUFNO0NBQ3pCLE9BQ0ssSUFBSSxjQUFjLEtBQUssR0FBRztFQUMzQixJQUFJLEVBQUUsVUFBVSxRQUFRO0dBQ3BCLE1BQU0sZ0JBQWdCLGVBQWUsZ0JBQWdCLE1BQU07RUFDL0Q7RUFDQSxPQUFPO0NBQ1gsT0FDSztFQUNELE1BQU0sZ0JBQWdCLGVBQWUsYUFBYTtDQUN0RDtBQUNKO0FBQ0EsU0FBUyxXQUFXLE9BQU87Q0FDdkIsTUFBTSxFQUFFLE1BQU0sUUFBUSxNQUFNLFFBQVEsV0FBVztDQUMvQyxNQUFNLFVBQVUsQ0FBQztDQUNqQixNQUFNLFFBQVEsUUFBUSxDQUFDO0NBQ3ZCLElBQUksU0FBUyxNQUFNLEdBQUc7RUFDbEIsUUFBUSxTQUFTO0NBQ3JCO0NBQ0EsSUFBSSxTQUFTLE1BQU0sR0FBRztFQUNsQixRQUFRLFNBQVM7Q0FDckI7Q0FDQSxJQUFJLFNBQVMsTUFBTSxHQUFHO0VBQ2xCLFFBQVEsU0FBUztDQUNyQjtDQUNBLE9BQU87RUFBQztFQUFNO0VBQU87Q0FBTztBQUNoQztBQUVBLFNBQVMsTUFBTSxLQUFLLE1BQU0sR0FBRyxTQUFTO0NBQ2xDLE1BQU0sZ0JBQWdCLGNBQWMsUUFBUSxFQUFFLElBQ3hDLFFBQVEsS0FDUixDQUFDO0NBQ1AsTUFBTSxnQkFBZ0IsVUFBVSxjQUFjLGFBQWEsSUFDckQsY0FBYyxnQkFDZDtDQUNOLElBQUksZUFBZTtFQUNmLENBQUMsWUFBWSxNQUFNLE9BQU8sQ0FBQyxDQUFDLFNBQVEsU0FBUSxJQUFJLFVBQVUsTUFBTSxXQUFXLENBQUM7RUFDNUUsQ0FBQyxhQUFhLE1BQU0sT0FBTyxDQUFDLENBQUMsU0FBUSxTQUFRLElBQUksVUFBVSxNQUFNLFlBQVksQ0FBQztFQUM5RSxDQUFDLGVBQWUsTUFBTSxPQUFPLENBQUMsQ0FBQyxTQUFRLFNBQVEsSUFBSSxVQUFVLE1BQU0sY0FBYyxDQUFDO0NBQ3RGOztDQUVBO0VBQ0ksSUFBSSxVQUFVLEtBQUssWUFBWSxJQUFJLENBQUM7Q0FDeEM7QUFDSjs7Ozs7Ozs7OztBQVdBLE1BQU0sbUJBQ1MsMEJBQVcsaUJBQWlCOztBQUUzQyxTQUFTLFdBQVcsVUFBVSxDQUFDLEdBQUc7O0NBRTlCLE1BQU0sZUFBZSwyQkFBMkIsVUFBVSxRQUFRLE1BQU0sSUFDOUQsUUFBUSxTQUNSO0NBQ1Ysc0JBQThCLGdCQUFpQixjQUFjO0VBQ3pELFNBQVMsZUFBZSxjQUFjLHFCQUFxQixDQUFDO0NBQ2hFOztDQUVBLE1BQU0sb0JBQW9CLFVBQVUsUUFBUSxlQUFlLElBQ3JELFFBQVEsa0JBQ1I7Q0FDTixNQUFNLGNBQWMsSUFBSSxJQUFJO0NBQzVCLE1BQU0sQ0FBQyxhQUFhLFlBQVksYUFBYSxTQUFTLFlBQVk7Q0FDbEUsTUFBTSxTQUF3Qiw0Q0FBcUMsZUFBZ0IsYUFBYSxFQUFFO0NBQ2xHLFNBQVMsY0FBYyxXQUFXO0VBQzlCLE9BQU8sWUFBWSxJQUFJLFNBQVMsS0FBSztDQUN6QztDQUNBLFNBQVMsY0FBYyxXQUFXLFVBQVU7RUFDeEMsWUFBWSxJQUFJLFdBQVcsUUFBUTtDQUN2QztDQUNBLFNBQVMsaUJBQWlCLFdBQVc7RUFDakMsWUFBWSxPQUFPLFNBQVM7Q0FDaEM7Q0FDQSxNQUFNLE9BQU87O0VBRVQsSUFBSSxPQUFPO0dBQ1AsT0FBTywyQkFBMkIsZUFDNUIsV0FDQTtFQUNWOztFQUVBLE1BQU0sUUFBUSxLQUFLLEdBQUcsU0FBUztHQUMzQix1QkFBK0IsZ0JBQWlCLDBCQUEwQixNQUFNO0lBQzVFLElBQUksZUFBZTtHQUN2Qjs7R0FFQSxJQUFJLHNCQUFzQjtHQUMxQixJQUFJLFFBQVEsSUFBSSxxQkFBcUIsSUFBSTs7R0FFekMsSUFBSSxjQUFjLFFBQVEsRUFBRSxHQUFHO0lBQzNCLE1BQU0sT0FBTyxRQUFRO0lBQ3JCLEtBQUssbUJBQ0QsS0FBSztJQUNULEtBQUssa0JBQ0QsS0FBSztHQUNiOztHQUVBLElBQUksdUJBQXVCO0dBQzNCLElBQUksQ0FBQyxnQkFBZ0IsbUJBQW1CO0lBQ3BDLHVCQUF1QixtQkFBbUIsS0FBSyxLQUFLLE1BQU07R0FDOUQ7O0dBRUEsSUFBSSwyQkFBMkI7SUFDM0IsTUFBTSxLQUFLLE1BQU0sR0FBRyxPQUFPO0dBQy9COztHQUVBLElBQUksMkJBQTJCLGNBQWM7SUFDekMsSUFBSSxNQUFNLFlBQVksVUFBVSxTQUFTLFlBQVksSUFBSSxDQUFDO0dBQzlEOztHQUVBLE1BQU0sYUFBYSxJQUFJO0dBQ3ZCLElBQUksZ0JBQWdCO0lBQ2hCLHdCQUF3QixxQkFBcUI7SUFDN0MsS0FBSyxRQUFRO0lBQ2IsV0FBVztHQUNmOztHQUVBLHVCQUErQixnQkFBaUIsMEJBQTBCLE1BQU07SUFDNUUsTUFBTSxNQUFNLE1BQU0sZUFBZSxLQUFLLElBQUk7SUFDMUMsSUFBSSxDQUFDLEtBQUs7S0FDTixNQUFNLGdCQUFnQixlQUFlLGdDQUFnQztJQUN6RTtJQUNBLE1BQU0sVUFBVSxjQUFjO0lBQzlCLElBQUksY0FBYztLQUNkLE1BQU0sV0FBVztLQUNqQixTQUFTLG1CQUFtQixTQUFTLGdCQUFnQixPQUFPO0lBQ2hFLE9BQ0s7O0tBRUQsTUFBTSxZQUFZO0tBQ2xCLFVBQVUsa0JBQWtCLFVBQVUsY0FBYyxDQUFDLE9BQU87SUFDaEU7SUFDQSxRQUFRLEdBQUcsS0FBSyxnQkFBZ0I7R0FDcEM7RUFDSjs7RUFFQSxJQUFJLFNBQVM7R0FDVCxPQUFPO0VBQ1g7RUFDQSxVQUFVO0dBQ04sWUFBWSxLQUFLO0VBQ3JCOztFQUVBOztFQUVBOztFQUVBOztFQUVBO0NBQ0o7Q0FDQSxPQUFPO0FBQ1g7QUFDQSxTQUFTLFFBQVEsVUFBVSxDQUFDLEdBQUc7Q0FDM0IsTUFBTSxXQUFXLG1CQUFtQjtDQUNwQyxJQUFJLFlBQVksTUFBTTtFQUNsQixNQUFNLGdCQUFnQixlQUFlLHNCQUFzQjtDQUMvRDtDQUNBLElBQUksQ0FBQyxTQUFTLFFBQ1YsU0FBUyxXQUFXLE9BQU8sUUFDM0IsQ0FBQyxTQUFTLFdBQVcsSUFBSSxxQkFBcUI7RUFDOUMsTUFBTSxnQkFBZ0IsZUFBZSxhQUFhO0NBQ3REO0NBQ0EsTUFBTSxPQUFPLGdCQUFnQixRQUFRO0NBQ3JDLE1BQU0sS0FBSyxrQkFBa0IsSUFBSTtDQUNqQyxNQUFNLG1CQUFtQixvQkFBb0IsUUFBUTtDQUNyRCxNQUFNLFFBQVEsU0FBUyxTQUFTLGdCQUFnQjtDQUNoRCxJQUFJLFVBQVUsVUFBVTtFQUNwQixvQkFBb0IsSUFBSSxTQUFTLGdCQUFnQjtFQUNqRCxPQUFPO0NBQ1g7Q0FDQSxJQUFJLFVBQVUsVUFBVTs7RUFFcEIsSUFBSSxXQUFXLFlBQVksTUFBTSxVQUFVLFFBQVEsY0FBYztFQUNqRSxJQUFJLFlBQVksTUFBTTtHQUNsQixzQkFBOEIsY0FBZTtJQUN6QyxLQUFLLGVBQWUsY0FBYyxzQkFBc0IsQ0FBQztHQUM3RDtHQUNBLFdBQVc7RUFDZjtFQUNBLE9BQU87Q0FDWDs7Q0FFQSxJQUFJLFVBQVUsWUFBWTs7RUFFdEIsSUFBSSxLQUFLLFNBQVMsZUFBZTtHQUM3QixNQUFNLGdCQUFnQixlQUFlLG1DQUFtQztFQUM1RTtFQUNBLE1BQU0sa0JBQWtCO0VBQ3hCLE1BQU0sa0JBQWtCLE9BQU8sQ0FBQyxHQUFHLE9BQU87O0VBRTFDLE1BQU0saUJBQWlCLFlBQVksTUFBTSxRQUFRO0VBQ2pELGdCQUFnQixTQUFTLGtCQUFrQjtFQUMzQyxNQUFNLFdBQVcsZUFBZSxlQUFlOztFQUUvQyxJQUFJLGdCQUFnQixrQkFBa0I7R0FDbEMsU0FBUyxpQkFDTCxnQkFBZ0IsaUJBQWlCLFFBQVE7RUFDakQ7OztFQUdBLElBQUksVUFBVTtFQUNkLHVCQUErQixnQkFBaUIsMEJBQTBCLE1BQU07R0FDNUUsVUFBVSxjQUFjOztHQUV4QixNQUFNLFlBQVk7R0FDbEIsVUFBVSxrQkFBa0IsVUFBVSxjQUFjLENBQUMsT0FBTztHQUM1RCxRQUFRLEdBQUcsS0FBSyxnQkFBZ0I7RUFDcEM7O0VBRUEsTUFBTSxlQUFlLGdCQUFnQjtFQUNyQyxJQUFJLGNBQWM7R0FDZCxxQkFBcUI7SUFDakIsdUJBQStCLGdCQUFpQiwwQkFBMEIsTUFBTTtLQUM1RSxXQUFXLFFBQVEsSUFBSSxLQUFLLGdCQUFnQjs7S0FFNUMsTUFBTSxZQUFZO0tBQ2xCLFVBQVUsbUJBQW1CLFVBQVUsZUFBZSxDQUFDO0lBQzNEOztJQUVBLE1BQU0sVUFBVSxTQUFTO0lBQ3pCLElBQUksU0FBUztLQUNULFFBQVE7O0tBRVIsT0FBTyxTQUFTO0lBQ3BCO0dBQ0osQ0FBQztFQUNMO0VBQ0EsT0FBTztDQUNYO0NBQ0EsTUFBTSxlQUFlO0NBQ3JCLElBQUksV0FBVyxhQUFhLGNBQWMsUUFBUTtDQUNsRCxJQUFJLFlBQVksTUFBTTtFQUNsQixNQUFNLGtCQUFrQixPQUFPLENBQUMsR0FBRyxPQUFPO0VBQzFDLElBQUksWUFBWSxrQkFBa0I7R0FDOUIsZ0JBQWdCLFNBQVMsaUJBQWlCO0VBQzlDO0VBQ0EsSUFBSSxJQUFJO0dBQ0osZ0JBQWdCLFNBQVM7RUFDN0I7RUFDQSxXQUFXLGVBQWUsZUFBZTtFQUN6QyxJQUFJLGFBQWEsa0JBQWtCO0dBQy9CLFNBQVMsaUJBQ0wsYUFBYSxpQkFBaUIsUUFBUTtFQUM5QztFQUNBLGVBQWUsY0FBYyxVQUFVLFFBQVE7RUFDL0MsYUFBYSxjQUFjLFVBQVUsUUFBUTtDQUNqRCxPQUNLO0VBQ0Qsc0JBQThCLGdCQUFpQixVQUFVLFNBQVM7R0FDOUQsS0FBSyxlQUFlLGNBQWMsMEJBQTBCLENBQUM7RUFDakU7Q0FDSjtDQUNBLE9BQU87QUFDWDtBQUNBLFNBQVMsYUFBYSxTQUFTLFlBQVk7Q0FDdkMsTUFBTSxRQUFRLFlBQVk7Q0FDMUIsTUFBTSxNQUFNLDJCQUEyQixhQUNqQyxNQUFNLFVBQVUsY0FBYyxPQUFPLENBQUMsSUFDdEMsTUFBTSxVQUFVLGVBQWUsT0FBTyxDQUFDO0NBQzdDLElBQUksT0FBTyxNQUFNO0VBQ2IsTUFBTSxnQkFBZ0IsZUFBZSxnQkFBZ0I7Q0FDekQ7Q0FDQSxPQUFPLENBQUMsT0FBTyxHQUFHO0FBQ3RCO0FBQ0EsU0FBUyxnQkFBZ0IsVUFBVTtDQUMvQixNQUFNLE9BQU8sT0FBTyxDQUFDLFNBQVMsT0FDeEIsU0FBUyxXQUFXLElBQUksc0JBQ3hCLGdCQUFnQjs7Q0FFdEIsSUFBSSxDQUFDLE1BQU07RUFDUCxNQUFNLGdCQUFnQixDQUFDLFNBQVMsT0FDMUIsZUFBZSxtQkFDZixlQUFlLDBCQUEwQjtDQUNuRDtDQUNBLE9BQU87QUFDWDs7QUFFQSxTQUFTLFNBQVMsU0FBUyxrQkFBa0I7O0NBRXpDLE9BQU8sY0FBYyxPQUFPLElBQ3JCLFlBQVksbUJBQ1QsVUFDQSxXQUNKLENBQUMsUUFBUSxXQUNMLFVBQ0EsUUFBUTtBQUN0QjtBQUNBLFNBQVMsa0JBQWtCLE1BQU07O0NBRTdCLE9BQU8sS0FBSyxTQUFTLGdCQUNmLEtBQUssU0FDTCxLQUFLLE9BQU87QUFDdEI7QUFDQSxTQUFTLFlBQVksTUFBTSxRQUFRLGVBQWUsT0FBTztDQUNyRCxJQUFJLFdBQVc7Q0FDZixNQUFNLE9BQU8sT0FBTztDQUNwQixJQUFJLFVBQVUsMkJBQTJCLFFBQVEsWUFBWTtDQUM3RCxPQUFPLFdBQVcsTUFBTTtFQUNwQixNQUFNLGVBQWU7RUFDckIsSUFBSSxLQUFLLFNBQVMsZUFBZTtHQUM3QixXQUFXLGFBQWEsY0FBYyxPQUFPO0VBQ2pELE9BQ0s7R0FDRCxJQUFJLHlCQUF5QjtJQUN6QixNQUFNLFVBQVUsYUFBYSxjQUFjLE9BQU87SUFDbEQsSUFBSSxXQUFXLE1BQU07S0FDakIsV0FBVyxRQUNOO0tBQ0wsSUFBSSxnQkFDQSxZQUNBLENBQUMsU0FBUyx5QkFDWjtNQUNFLFdBQVc7S0FDZjtJQUNKO0dBQ0o7RUFDSjtFQUNBLElBQUksWUFBWSxNQUFNO0dBQ2xCO0VBQ0o7RUFDQSxJQUFJLFNBQVMsU0FBUztHQUNsQjtFQUNKO0VBQ0EsVUFBVSxRQUFRO0NBQ3RCO0NBQ0EsT0FBTztBQUNYO0FBQ0EsU0FBUywyQkFBMkIsUUFBUSxlQUFlLE9BQU87Q0FDOUQsSUFBSSxVQUFVLE1BQU07RUFDaEIsT0FBTztDQUNYOztDQUVBLE9BQU8sQ0FBQyxlQUNGLE9BQU8sU0FDUCxPQUFPLE1BQU0sT0FBTyxPQUFPO0FBQ3JDO0FBQ0EsU0FBUyxlQUFlLE1BQU0sUUFBUSxVQUFVO0NBQzVDLElBQUksVUFBVTtDQUNkLGdCQUFnQjs7RUFFWix1QkFBK0IsZ0JBQWlCLDBCQUEwQixNQUFNO0dBQzVFLE9BQU8sZUFBZTtHQUN0QixVQUFVLGNBQWM7O0dBRXhCLE1BQU0sWUFBWTtHQUNsQixVQUFVLGtCQUFrQixVQUFVLGNBQWMsQ0FBQyxPQUFPO0dBQzVELFFBQVEsR0FBRyxLQUFLLGdCQUFnQjtFQUNwQztDQUNKLEdBQUcsTUFBTTtDQUNULGtCQUFrQjs7RUFFZCxNQUFNLFlBQVk7O0VBRWxCLHVCQUErQixnQkFBaUIsMEJBQTBCLE1BQU07R0FDNUUsV0FBVyxRQUFRLElBQUksS0FBSyxnQkFBZ0I7R0FDNUMsVUFBVSxtQkFBbUIsVUFBVSxlQUFlLENBQUM7R0FDdkQsT0FBTyxPQUFPO0VBQ2xCO0VBQ0EsS0FBSyxpQkFBaUIsTUFBTTs7RUFFNUIsTUFBTSxVQUFVLFVBQVU7RUFDMUIsSUFBSSxTQUFTO0dBQ1QsUUFBUTtHQUNSLE9BQU8sVUFBVTtFQUNyQjtDQUNKLEdBQUcsTUFBTTtBQUNiO0FBQ0EsTUFBTSxvQkFBb0I7Q0FDdEI7Q0FDQTtDQUNBO0FBQ0o7QUFDQSxNQUFNLHNCQUFzQjtDQUFDO0NBQUs7Q0FBTTtDQUFLO0NBQUs7Q0FBTTtBQUFJO0FBRTVELFNBQVMsbUJBQW1CLEtBQUssVUFBVTtDQUN2QyxNQUFNLE9BQU8sT0FBTyxPQUFPLElBQUk7Q0FDL0Isa0JBQWtCLFNBQVEsU0FBUTtFQUM5QixNQUFNLE9BQU8sT0FBTyx5QkFBeUIsVUFBVSxJQUFJO0VBQzNELElBQUksQ0FBQyxNQUFNO0dBQ1AsTUFBTSxnQkFBZ0IsZUFBZSxnQkFBZ0I7RUFDekQ7RUFDQSxNQUFNLE9BQU8sTUFBTSxLQUFLLEtBQUssSUFDdkI7R0FDRSxNQUFNO0lBQ0YsT0FBTyxLQUFLLE1BQU07R0FDdEI7O0dBRUEsSUFBSSxLQUFLO0lBQ0wsS0FBSyxNQUFNLFFBQVE7R0FDdkI7RUFDSixJQUNFLEVBQ0UsTUFBTTtHQUNGLE9BQU8sS0FBSyxPQUFPLEtBQUssSUFBSTtFQUNoQyxFQUNKO0VBQ0osT0FBTyxlQUFlLE1BQU0sTUFBTSxJQUFJO0NBQzFDLENBQUM7Q0FDRCxJQUFJLE9BQU8saUJBQWlCLFFBQVE7Q0FDcEMsb0JBQW9CLFNBQVEsV0FBVTtFQUNsQyxNQUFNLE9BQU8sT0FBTyx5QkFBeUIsVUFBVSxNQUFNO0VBQzdELElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxPQUFPO0dBQ3RCLE1BQU0sZ0JBQWdCLGVBQWUsZ0JBQWdCO0VBQ3pEO0VBQ0EsT0FBTyxlQUFlLElBQUksT0FBTyxrQkFBa0IsSUFBSSxVQUFVLElBQUk7Q0FDekUsQ0FBQztDQUNELE1BQU0sZ0JBQWdCOztFQUVsQixPQUFPLElBQUksT0FBTyxpQkFBaUI7RUFDbkMsb0JBQW9CLFNBQVEsV0FBVTs7R0FFbEMsT0FBTyxJQUFJLE9BQU8saUJBQWlCLElBQUk7RUFDM0MsQ0FBQztDQUNMO0NBQ0EsT0FBTztBQUNYO0FBRUEsTUFBTSxxQkFBb0MsK0JBQWdCOztDQUV0RCxNQUFNO0NBQ04sT0FBTyxPQUFPO0VBQ1YsT0FBTztHQUNILE1BQU0sQ0FBQyxRQUFRLElBQUk7R0FDbkIsVUFBVTtFQUNkO0VBQ0EsUUFBUSxFQUNKLE1BQU0sQ0FBQyxRQUFRLE1BQU0sRUFDekI7Q0FDSixHQUFHLGVBQWU7OztDQUdsQixNQUFNLE9BQU8sU0FBUztFQUNsQixNQUFNLE9BQU8sTUFBTSxRQUNmLFFBQVE7R0FDSixVQUFVLE1BQU07R0FDaEIsZ0JBQWdCO0VBQ3BCLENBQUM7RUFDTCxPQUFPLGdCQUFnQixPQUFPLFNBQVMsK0JBQStCLEdBQUcsU0FFekUsS0FBSyxvQkFBb0IsQ0FBQyxHQUFHLElBQUksQ0FBQztDQUN0QztBQUNKLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWtCRCxNQUFNLGlCQUFpQjtBQUN2QixNQUFNLFFBQVE7QUFFZDtDQUNJLGlCQUFpQjtBQUNyQjs7QUFFQSx3QkFBd0IsT0FBTzs7QUFFL0Isd0JBQXdCLFlBQVk7O0FBRXBDLHlCQUF5Qix1QkFBdUI7O0FBRWhELHNCQUE4QixnQkFBaUIsMkJBQTJCO0NBQ3RFLE1BQU0sU0FBUyxjQUFjO0NBQzdCLE9BQU8sY0FBYztDQUNyQixnQkFBZ0IsT0FBTyxnQ0FBZ0M7QUFDM0Q7QUFDQSxzQkFBOEI7QUFFOUIsU0FBUyxnQkFBZ0IsT0FBTyxrQkFBa0IsT0FBTyxPQUFPLGNBQWMsYUFBYSxTQUFTLFlBQVksU0FBUyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJ2dWUtaTE4bi5tanM/dj03ZTczYWZjMiJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAgKiB2dWUtaTE4biB2MTEuNC44XG4gICogKGMpIDIwMjYga2F6dXlhIGthd2FndWNoaVxuICAqIFJlbGVhc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZS5cbiAgKi9cbmltcG9ydCB7IGNyZWF0ZUNvbXBpbGVFcnJvciwgQ09SRV9FUlJPUl9DT0RFU19FWFRFTkRfUE9JTlQsIENPUkVfV0FSTl9DT0RFU19FWFRFTkRfUE9JTlQsIGlzTWVzc2FnZUFTVCwgQVNUX05PREVfUFJPUFNfS0VZUywgREVGQVVMVF9MT0NBTEUsIHVwZGF0ZUZhbGxiYWNrTG9jYWxlLCBzZXRGYWxsYmFja0NvbnRleHQsIGNyZWF0ZUNvcmVDb250ZXh0LCBjbGVhckRhdGVUaW1lRm9ybWF0LCBjbGVhck51bWJlckZvcm1hdCwgc2V0QWRkaXRpb25hbE1ldGEsIGdldEZhbGxiYWNrQ29udGV4dCwgTk9UX1JFT1NMVkVELCBpc1RyYW5zbGF0ZUZhbGxiYWNrV2FybiwgaXNUcmFuc2xhdGVNaXNzaW5nV2FybiwgZmFsbGJhY2tXaXRoTG9jYWxlQ2hhaW4sIHBhcnNlVHJhbnNsYXRlQXJncywgdHJhbnNsYXRlLCBNSVNTSU5HX1JFU09MVkVfVkFMVUUsIHBhcnNlRGF0ZVRpbWVBcmdzLCBkYXRldGltZSwgcGFyc2VOdW1iZXJBcmdzLCBudW1iZXIsIGlzTWVzc2FnZUZ1bmN0aW9uLCBOVU1CRVJfRk9STUFUX09QVElPTlNfS0VZUywgREFURVRJTUVfRk9STUFUX09QVElPTlNfS0VZUywgcmVnaXN0ZXJNZXNzYWdlQ29tcGlsZXIsIGNvbXBpbGUsIHJlZ2lzdGVyTWVzc2FnZVJlc29sdmVyLCByZXNvbHZlVmFsdWUsIHJlZ2lzdGVyTG9jYWxlRmFsbGJhY2tlciwgc2V0RGV2VG9vbHNIb29rIH0gZnJvbSAnQGludGxpZnkvY29yZS1iYXNlJztcbmltcG9ydCB7IGdldEdsb2JhbFRoaXMsIG1ha2VTeW1ib2wsIGZvcm1hdCwgaXNPYmplY3QsIGNyZWF0ZSwgaXNQbGFpbk9iamVjdCwgaXNBcnJheSwgZGVlcENvcHksIGlzU3RyaW5nLCBoYXNPd24sIHdhcm4sIGlzQm9vbGVhbiwgaXNSZWdFeHAsIGlzRnVuY3Rpb24sIGluQnJvd3NlciwgYXNzaWduLCBpc051bWJlciwgY3JlYXRlRW1pdHRlciwgd2Fybk9uY2UsIGlzRW1wdHlPYmplY3QgfSBmcm9tICdAaW50bGlmeS9zaGFyZWQnO1xuaW1wb3J0ICogYXMgVnVlIGZyb20gJ3Z1ZSc7XG5pbXBvcnQgeyBjcmVhdGVWTm9kZSwgVGV4dCwgY29tcHV0ZWQsIHdhdGNoLCByZWYsIHNoYWxsb3dSZWYsIEZyYWdtZW50LCBkZWZpbmVDb21wb25lbnQsIGgsIGdldEN1cnJlbnRTY29wZSwgb25TY29wZURpc3Bvc2UsIGVmZmVjdFNjb3BlLCBpbmplY3QsIG9uTW91bnRlZCwgb25Vbm1vdW50ZWQsIGlzUmVmIH0gZnJvbSAndnVlJztcbmltcG9ydCB7IHNldHVwRGV2dG9vbHNQbHVnaW4gfSBmcm9tICdAdnVlL2RldnRvb2xzLWFwaSc7XG5cbi8qKlxuICogVnVlIEkxOG4gVmVyc2lvblxuICpcbiAqIEByZW1hcmtzXG4gKiBTZW12ZXIgZm9ybWF0LiBTYW1lIGZvcm1hdCBhcyB0aGUgcGFja2FnZS5qc29uIGB2ZXJzaW9uYCBmaWVsZC5cbiAqXG4gKiBAVnVlSTE4bkdlbmVyYWxcbiAqL1xuY29uc3QgVkVSU0lPTiA9ICcxMS40LjgnO1xuLyoqXG4gKiBUaGlzIGlzIG9ubHkgY2FsbGVkIGluIGVzbS1idW5kbGVyIGJ1aWxkcy5cbiAqIGlzdGFuYnVsLWlnbm9yZS1uZXh0XG4gKi9cbmZ1bmN0aW9uIGluaXRGZWF0dXJlRmxhZ3MoKSB7XG4gICAgaWYgKHR5cGVvZiBfX1ZVRV9JMThOX0ZVTExfSU5TVEFMTF9fICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgZ2V0R2xvYmFsVGhpcygpLl9fVlVFX0kxOE5fRlVMTF9JTlNUQUxMX18gPSB0cnVlO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIF9fVlVFX0kxOE5fTEVHQUNZX0FQSV9fICE9PSAnYm9vbGVhbicpIHtcbiAgICAgICAgZ2V0R2xvYmFsVGhpcygpLl9fVlVFX0kxOE5fTEVHQUNZX0FQSV9fID0gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBfX0lOVExJRllfRFJPUF9NRVNTQUdFX0NPTVBJTEVSX18gIT09ICdib29sZWFuJykge1xuICAgICAgICBnZXRHbG9iYWxUaGlzKCkuX19JTlRMSUZZX0RST1BfTUVTU0FHRV9DT01QSUxFUl9fID0gZmFsc2U7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgX19JTlRMSUZZX1BST0RfREVWVE9PTFNfXyAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIGdldEdsb2JhbFRoaXMoKS5fX0lOVExJRllfUFJPRF9ERVZUT09MU19fID0gZmFsc2U7XG4gICAgfVxufVxuXG5jb25zdCBJMThuRXJyb3JDb2RlcyA9IHtcbiAgICAvLyBjb21wb3NlciBtb2R1bGUgZXJyb3JzXG4gICAgVU5FWFBFQ1RFRF9SRVRVUk5fVFlQRTogQ09SRV9FUlJPUl9DT0RFU19FWFRFTkRfUE9JTlQsIC8vIDI0XG4gICAgLy8gbGVnYWN5IG1vZHVsZSBlcnJvcnNcbiAgICBJTlZBTElEX0FSR1VNRU5UOiAyNSxcbiAgICAvLyBpMThuIG1vZHVsZSBlcnJvcnNcbiAgICBNVVNUX0JFX0NBTExfU0VUVVBfVE9QOiAyNixcbiAgICBOT1RfSU5TVEFMTEVEOiAyNyxcbiAgICAvLyBkaXJlY3RpdmUgbW9kdWxlIGVycm9yc1xuICAgIFJFUVVJUkVEX1ZBTFVFOiAyOCxcbiAgICBJTlZBTElEX1ZBTFVFOiAyOSxcbiAgICAvLyB2dWUtZGV2dG9vbHMgZXJyb3JzXG4gICAgQ0FOTk9UX1NFVFVQX1ZVRV9ERVZUT09MU19QTFVHSU46IDMwLFxuICAgIE5PVF9JTlNUQUxMRURfV0lUSF9QUk9WSURFOiAzMSxcbiAgICAvLyB1bmV4cGVjdGVkIGVycm9yXG4gICAgVU5FWFBFQ1RFRF9FUlJPUjogMzIsXG4gICAgLy8gbm90IGNvbXBhdGlibGUgbGVnYWN5IHZ1ZS1pMThuIGNvbnN0cnVjdG9yXG4gICAgTk9UX0NPTVBBVElCTEVfTEVHQUNZX1ZVRV9JMThOOiAzMyxcbiAgICAvLyBOb3QgYXZhaWxhYmxlIENvbXBvc3Rpb24gQVBJIGluIExlZ2FjeSBBUEkgbW9kZS4gUGxlYXNlIG1ha2Ugc3VyZSB0aGF0IHRoZSBsZWdhY3kgQVBJIG1vZGUgaXMgd29ya2luZyBwcm9wZXJseVxuICAgIE5PVF9BVkFJTEFCTEVfQ09NUE9TSVRJT05fSU5fTEVHQUNZOiAzNFxufTtcbmZ1bmN0aW9uIGNyZWF0ZUkxOG5FcnJvcihjb2RlLCAuLi5hcmdzKSB7XG4gICAgcmV0dXJuIGNyZWF0ZUNvbXBpbGVFcnJvcihjb2RlLCBudWxsLCAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgPyB7IG1lc3NhZ2VzOiBlcnJvck1lc3NhZ2VzLCBhcmdzIH0gOiB1bmRlZmluZWQpO1xufVxuY29uc3QgZXJyb3JNZXNzYWdlcyA9IHtcbiAgICBbSTE4bkVycm9yQ29kZXMuVU5FWFBFQ1RFRF9SRVRVUk5fVFlQRV06ICdVbmV4cGVjdGVkIHJldHVybiB0eXBlIGluIGNvbXBvc2VyJyxcbiAgICBbSTE4bkVycm9yQ29kZXMuSU5WQUxJRF9BUkdVTUVOVF06ICdJbnZhbGlkIGFyZ3VtZW50JyxcbiAgICBbSTE4bkVycm9yQ29kZXMuTVVTVF9CRV9DQUxMX1NFVFVQX1RPUF06ICdNdXN0IGJlIGNhbGxlZCBhdCB0aGUgdG9wIG9mIGEgYHNldHVwYCBmdW5jdGlvbicsXG4gICAgW0kxOG5FcnJvckNvZGVzLk5PVF9JTlNUQUxMRURdOiAnTmVlZCB0byBpbnN0YWxsIHdpdGggYGFwcC51c2VgIGZ1bmN0aW9uJyxcbiAgICBbSTE4bkVycm9yQ29kZXMuVU5FWFBFQ1RFRF9FUlJPUl06ICdVbmV4cGVjdGVkIGVycm9yJyxcbiAgICBbSTE4bkVycm9yQ29kZXMuUkVRVUlSRURfVkFMVUVdOiBgUmVxdWlyZWQgaW4gdmFsdWU6IHswfWAsXG4gICAgW0kxOG5FcnJvckNvZGVzLklOVkFMSURfVkFMVUVdOiBgSW52YWxpZCB2YWx1ZWAsXG4gICAgW0kxOG5FcnJvckNvZGVzLkNBTk5PVF9TRVRVUF9WVUVfREVWVE9PTFNfUExVR0lOXTogYENhbm5vdCBzZXR1cCB2dWUtZGV2dG9vbHMgcGx1Z2luYCxcbiAgICBbSTE4bkVycm9yQ29kZXMuTk9UX0lOU1RBTExFRF9XSVRIX1BST1ZJREVdOiAnTmVlZCB0byBpbnN0YWxsIHdpdGggYHByb3ZpZGVgIGZ1bmN0aW9uJyxcbiAgICBbSTE4bkVycm9yQ29kZXMuTk9UX0NPTVBBVElCTEVfTEVHQUNZX1ZVRV9JMThOXTogJ05vdCBjb21wYXRpYmxlIGxlZ2FjeSBWdWVJMThuLicsXG4gICAgW0kxOG5FcnJvckNvZGVzLk5PVF9BVkFJTEFCTEVfQ09NUE9TSVRJT05fSU5fTEVHQUNZXTogJ05vdCBhdmFpbGFibGUgQ29tcG9zdGlvbiBBUEkgaW4gTGVnYWN5IEFQSSBtb2RlLiBQbGVhc2UgbWFrZSBzdXJlIHRoYXQgdGhlIGxlZ2FjeSBBUEkgbW9kZSBpcyB3b3JraW5nIHByb3Blcmx5J1xufTtcblxuY29uc3QgVHJhbnNsYXRlVk5vZGVTeW1ib2wgPSBcbi8qICNfX1BVUkVfXyovIG1ha2VTeW1ib2woJ19fdHJhbnNsYXRlVk5vZGUnKTtcbmNvbnN0IERhdGV0aW1lUGFydHNTeW1ib2wgPSAvKiAjX19QVVJFX18qLyBtYWtlU3ltYm9sKCdfX2RhdGV0aW1lUGFydHMnKTtcbmNvbnN0IE51bWJlclBhcnRzU3ltYm9sID0gLyogI19fUFVSRV9fKi8gbWFrZVN5bWJvbCgnX19udW1iZXJQYXJ0cycpO1xuY29uc3QgRW5hYmxlRW1pdHRlciA9IC8qICNfX1BVUkVfXyovIG1ha2VTeW1ib2woJ19fZW5hYmxlRW1pdHRlcicpO1xuY29uc3QgRGlzYWJsZUVtaXR0ZXIgPSAvKiAjX19QVVJFX18qLyBtYWtlU3ltYm9sKCdfX2Rpc2FibGVFbWl0dGVyJyk7XG5jb25zdCBTZXRQbHVyYWxSdWxlc1N5bWJvbCA9IG1ha2VTeW1ib2woJ19fc2V0UGx1cmFsUnVsZXMnKTtcbm1ha2VTeW1ib2woJ19faW50bGlmeU1ldGEnKTtcbmNvbnN0IEluZWpjdFdpdGhPcHRpb25TeW1ib2wgPSBcbi8qICNfX1BVUkVfXyovIG1ha2VTeW1ib2woJ19faW5qZWN0V2l0aE9wdGlvbicpO1xuY29uc3QgRGlzcG9zZVN5bWJvbCA9IC8qICNfX1BVUkVfXyovIG1ha2VTeW1ib2woJ19fZGlzcG9zZScpO1xuXG5jb25zdCBJMThuV2FybkNvZGVzID0ge1xuICAgIEZBTExCQUNLX1RPX1JPT1Q6IENPUkVfV0FSTl9DT0RFU19FWFRFTkRfUE9JTlQsIC8vIDEwXG4gICAgTk9UX0ZPVU5EX1BBUkVOVF9TQ09QRTogKENPUkVfV0FSTl9DT0RFU19FWFRFTkRfUE9JTlQgKyAxKSxcbiAgICBJR05PUkVfT0JKX0ZMQVRURU46IChDT1JFX1dBUk5fQ09ERVNfRVhURU5EX1BPSU5UICsgMiksXG4gICAgLyoqXG4gICAgICogQGRlcHJlY2F0ZWQgd2lsbCBiZSByZW1vdmVkIGF0IHZ1ZS1pMThuIHYxMlxuICAgICAqL1xuICAgIERFUFJFQ0FURV9MRUdBQ1lfTU9ERTogKENPUkVfV0FSTl9DT0RFU19FWFRFTkRfUE9JTlQgKyAzKSxcbiAgICAvKipcbiAgICAgKiBAZGVwcmVjYXRlZCB3aWxsIGJlIHJlbW92ZWQgYXQgdnVlLWkxOG4gdjEyXG4gICAgICovXG4gICAgREVQUkVDQVRFX1RSQU5TTEFURV9DVVNUT01FX0RJUkVDVElWRTogKENPUkVfV0FSTl9DT0RFU19FWFRFTkRfUE9JTlQgK1xuICAgICAgICA0KSxcbiAgICAvLyBkdXBsaWNhdGUgYHVzZUkxOG5gIGNhbGxpbmdcbiAgICBEVVBMSUNBVEVfVVNFX0kxOE5fQ0FMTElORzogKENPUkVfV0FSTl9DT0RFU19FWFRFTkRfUE9JTlQgKyA1KVxufTtcbmNvbnN0IHdhcm5NZXNzYWdlcyA9IHtcbiAgICBbSTE4bldhcm5Db2Rlcy5GQUxMQkFDS19UT19ST09UXTogYEZhbGwgYmFjayB0byB7dHlwZX0gJ3trZXl9JyB3aXRoIHJvb3QgbG9jYWxlLmAsXG4gICAgW0kxOG5XYXJuQ29kZXMuTk9UX0ZPVU5EX1BBUkVOVF9TQ09QRV06IGBOb3QgZm91bmQgcGFyZW50IHNjb3BlLiB1c2UgdGhlIGdsb2JhbCBzY29wZS5gLFxuICAgIFtJMThuV2FybkNvZGVzLklHTk9SRV9PQkpfRkxBVFRFTl06IGBJZ25vcmUgb2JqZWN0IGZsYXR0ZW46ICd7a2V5fScga2V5IGhhcyBhbiBzdHJpbmcgdmFsdWVgLFxuICAgIC8qKlxuICAgICAqIEBkZXByZWNhdGVkIHdpbGwgYmUgcmVtb3ZlZCBhdCB2dWUtaTE4biB2MTJcbiAgICAgKi9cbiAgICBbSTE4bldhcm5Db2Rlcy5ERVBSRUNBVEVfTEVHQUNZX01PREVdOiBgTGVnYWN5IEFQSSBtb2RlIGhhcyBiZWVuIGRlcHJlY2F0ZWQgaW4gdjExLiBVc2UgQ29tcG9zaXRpb24gQVBJIG1vZGUgaW5zdGVhZC5cXG5BYm91dCBob3cgdG8gdXNlIHRoZSBDb21wb3NpdGlvbiBBUEkgbW9kZSwgc2VlIGh0dHBzOi8vdnVlLWkxOG4uaW50bGlmeS5kZXYvZ3VpZGUvYWR2YW5jZWQvY29tcG9zaXRpb24uaHRtbGAsXG4gICAgLyoqXG4gICAgICogQGRlcHJlY2F0ZWQgd2lsbCBiZSByZW1vdmVkIGF0IHZ1ZS1pMThuIHYxMlxuICAgICAqL1xuICAgIFtJMThuV2FybkNvZGVzLkRFUFJFQ0FURV9UUkFOU0xBVEVfQ1VTVE9NRV9ESVJFQ1RJVkVdOiBgJ3YtdCcgaGFzIGJlZW4gZGVwcmVjYXRlZCBpbiB2MTEuIFVzZSB0cmFuc2xhdGUgQVBJcyAoJ3QnIG9yICckdCcpIGluc3RlYWQuYCxcbiAgICBbSTE4bldhcm5Db2Rlcy5EVVBMSUNBVEVfVVNFX0kxOE5fQ0FMTElOR106IFwiRHVwbGljYXRlIGB1c2VJMThuYCBjYWxsaW5nIGJ5IGxvY2FsIHNjb3BlLiBQbGVhc2UgZG9uJ3QgY2FsbCBpdCBvbiBsb2NhbCBzY29wZSwgZHVlIHRvIGl0IGRvZXMgbm90IHdvcmsgcHJvcGVybHkgaW4gY29tcG9uZW50LlwiXG59O1xuZnVuY3Rpb24gZ2V0V2Fybk1lc3NhZ2UoY29kZSwgLi4uYXJncykge1xuICAgIHJldHVybiBmb3JtYXQod2Fybk1lc3NhZ2VzW2NvZGVdLCAuLi5hcmdzKTtcbn1cblxuLyogZXNsaW50LWRpc2FibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuLyoqXG4gKiBUcmFuc2Zvcm0gZmxhdCBqc29uIGluIG9iaiB0byBub3JtYWwganNvbiBpbiBvYmpcbiAqL1xuZnVuY3Rpb24gaGFuZGxlRmxhdEpzb24ob2JqKSB7XG4gICAgLy8gY2hlY2sgb2JqXG4gICAgaWYgKCFpc09iamVjdChvYmopKSB7XG4gICAgICAgIHJldHVybiBvYmo7XG4gICAgfVxuICAgIGlmIChpc01lc3NhZ2VBU1Qob2JqKSkge1xuICAgICAgICByZXR1cm4gb2JqO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IGtleSBpbiBvYmopIHtcbiAgICAgICAgLy8gY2hlY2sga2V5XG4gICAgICAgIGlmICghaGFzT3duKG9iaiwga2V5KSkge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgLy8gaGFuZGxlIGZvciBub3JtYWwganNvblxuICAgICAgICBpZiAoIWtleS5pbmNsdWRlcygnLicpKSB7XG4gICAgICAgICAgICAvLyByZWN1cnNpdmUgcHJvY2VzcyB2YWx1ZSBpZiB2YWx1ZSBpcyBhbHNvIGEgb2JqZWN0XG4gICAgICAgICAgICBpZiAoaXNPYmplY3Qob2JqW2tleV0pKSB7XG4gICAgICAgICAgICAgICAgaGFuZGxlRmxhdEpzb24ob2JqW2tleV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIGhhbmRsZSBmb3IgZmxhdCBqc29uLCB0cmFuc2Zvcm0gdG8gbm9ybWFsIGpzb25cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAvLyBnbyB0byB0aGUgbGFzdCBvYmplY3RcbiAgICAgICAgICAgIGNvbnN0IHN1YktleXMgPSBrZXkuc3BsaXQoJy4nKTtcbiAgICAgICAgICAgIGNvbnN0IGxhc3RJbmRleCA9IHN1YktleXMubGVuZ3RoIC0gMTtcbiAgICAgICAgICAgIGxldCBjdXJyZW50T2JqID0gb2JqO1xuICAgICAgICAgICAgbGV0IGhhc1N0cmluZ1ZhbHVlID0gZmFsc2U7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxhc3RJbmRleDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgaWYgKHN1YktleXNbaV0gPT09ICdfX3Byb3RvX18nKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgdW5zYWZlIGtleTogJHtzdWJLZXlzW2ldfWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoIShzdWJLZXlzW2ldIGluIGN1cnJlbnRPYmopKSB7XG4gICAgICAgICAgICAgICAgICAgIGN1cnJlbnRPYmpbc3ViS2V5c1tpXV0gPSBjcmVhdGUoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKCFpc09iamVjdChjdXJyZW50T2JqW3N1YktleXNbaV1dKSkge1xuICAgICAgICAgICAgICAgICAgICAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIHdhcm4oZ2V0V2Fybk1lc3NhZ2UoSTE4bldhcm5Db2Rlcy5JR05PUkVfT0JKX0ZMQVRURU4sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk6IHN1YktleXNbaV1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgICAgICAgICAgaGFzU3RyaW5nVmFsdWUgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY3VycmVudE9iaiA9IGN1cnJlbnRPYmpbc3ViS2V5c1tpXV07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyB1cGRhdGUgbGFzdCBvYmplY3QgdmFsdWUsIGRlbGV0ZSBvbGQgcHJvcGVydHlcbiAgICAgICAgICAgIGlmICghaGFzU3RyaW5nVmFsdWUpIHtcbiAgICAgICAgICAgICAgICBpZiAoIWlzTWVzc2FnZUFTVChjdXJyZW50T2JqKSkge1xuICAgICAgICAgICAgICAgICAgICBjdXJyZW50T2JqW3N1YktleXNbbGFzdEluZGV4XV0gPSBvYmpba2V5XTtcbiAgICAgICAgICAgICAgICAgICAgZGVsZXRlIG9ialtrZXldO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAqIE5PVEU6XG4gICAgICAgICAgICAgICAgICAgICAqIGlmIHRoZSBsYXN0IG9iamVjdCBpcyBhIG1lc3NhZ2UgQVNUIGFuZCBzdWJLZXlzW2xhc3RJbmRleF0gaGFzIG1lc3NhZ2UgQVNUIHByb3Aga2V5LCBpZ25vcmUgdG8gY29weSBhbmQga2V5IGRlbGV0aW9uXG4gICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICBpZiAoIUFTVF9OT0RFX1BST1BTX0tFWVMuaW5jbHVkZXMoc3ViS2V5c1tsYXN0SW5kZXhdKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZGVsZXRlIG9ialtrZXldO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gcmVjdXJzaXZlIHByb2Nlc3MgdmFsdWUgaWYgdmFsdWUgaXMgYWxzbyBhIG9iamVjdFxuICAgICAgICAgICAgaWYgKCFpc01lc3NhZ2VBU1QoY3VycmVudE9iaikpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB0YXJnZXQgPSBjdXJyZW50T2JqW3N1YktleXNbbGFzdEluZGV4XV07XG4gICAgICAgICAgICAgICAgaWYgKGlzT2JqZWN0KHRhcmdldCkpIHtcbiAgICAgICAgICAgICAgICAgICAgaGFuZGxlRmxhdEpzb24odGFyZ2V0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG9iajtcbn1cbmZ1bmN0aW9uIGdldExvY2FsZU1lc3NhZ2VzKGxvY2FsZSwgb3B0aW9ucykge1xuICAgIGNvbnN0IHsgbWVzc2FnZXMsIF9faTE4biwgbWVzc2FnZVJlc29sdmVyLCBmbGF0SnNvbiB9ID0gb3B0aW9ucztcbiAgICAvLyBwcmV0dGllci1pZ25vcmVcbiAgICBjb25zdCByZXQgPSAoaXNQbGFpbk9iamVjdChtZXNzYWdlcylcbiAgICAgICAgPyBtZXNzYWdlc1xuICAgICAgICA6IGlzQXJyYXkoX19pMThuKVxuICAgICAgICAgICAgPyBjcmVhdGUoKVxuICAgICAgICAgICAgOiB7IFtsb2NhbGVdOiBjcmVhdGUoKSB9KTtcbiAgICAvLyBtZXJnZSBsb2NhbGUgbWVzc2FnZXMgb2YgaTE4biBjdXN0b20gYmxvY2tcbiAgICBpZiAoaXNBcnJheShfX2kxOG4pKSB7XG4gICAgICAgIF9faTE4bi5mb3JFYWNoKGN1c3RvbSA9PiB7XG4gICAgICAgICAgICBpZiAoJ2xvY2FsZScgaW4gY3VzdG9tICYmICdyZXNvdXJjZScgaW4gY3VzdG9tKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgeyBsb2NhbGUsIHJlc291cmNlIH0gPSBjdXN0b207XG4gICAgICAgICAgICAgICAgaWYgKGxvY2FsZSkge1xuICAgICAgICAgICAgICAgICAgICByZXRbbG9jYWxlXSA9IHJldFtsb2NhbGVdIHx8IGNyZWF0ZSgpO1xuICAgICAgICAgICAgICAgICAgICBkZWVwQ29weShyZXNvdXJjZSwgcmV0W2xvY2FsZV0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgZGVlcENvcHkocmVzb3VyY2UsIHJldCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgaXNTdHJpbmcoY3VzdG9tKSAmJiBkZWVwQ29weShKU09OLnBhcnNlKGN1c3RvbSksIHJldCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvLyBoYW5kbGUgbWVzc2FnZXMgZm9yIGZsYXQganNvblxuICAgIGlmIChtZXNzYWdlUmVzb2x2ZXIgPT0gbnVsbCAmJiBmbGF0SnNvbikge1xuICAgICAgICBmb3IgKGNvbnN0IGtleSBpbiByZXQpIHtcbiAgICAgICAgICAgIGlmIChoYXNPd24ocmV0LCBrZXkpKSB7XG4gICAgICAgICAgICAgICAgaGFuZGxlRmxhdEpzb24ocmV0W2tleV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiByZXQ7XG59XG5mdW5jdGlvbiBnZXRDb21wb25lbnRPcHRpb25zKGluc3RhbmNlKSB7XG4gICAgcmV0dXJuIGluc3RhbmNlLnR5cGU7XG59XG5mdW5jdGlvbiBhZGp1c3RJMThuUmVzb3VyY2VzKGdsLCBvcHRpb25zLCBjb21wb25lbnRPcHRpb25zKSB7XG4gICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgbGV0IG1lc3NhZ2VzID0gaXNPYmplY3Qob3B0aW9ucy5tZXNzYWdlcylcbiAgICAgICAgPyBvcHRpb25zLm1lc3NhZ2VzXG4gICAgICAgIDogY3JlYXRlKCk7XG4gICAgaWYgKCdfX2kxOG5HbG9iYWwnIGluIGNvbXBvbmVudE9wdGlvbnMpIHtcbiAgICAgICAgbWVzc2FnZXMgPSBnZXRMb2NhbGVNZXNzYWdlcyhnbC5sb2NhbGUudmFsdWUsIHtcbiAgICAgICAgICAgIG1lc3NhZ2VzLFxuICAgICAgICAgICAgX19pMThuOiBjb21wb25lbnRPcHRpb25zLl9faTE4bkdsb2JhbFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgLy8gbWVyZ2UgbG9jYWxlIG1lc3NhZ2VzXG4gICAgY29uc3QgbG9jYWxlcyA9IE9iamVjdC5rZXlzKG1lc3NhZ2VzKTtcbiAgICBpZiAobG9jYWxlcy5sZW5ndGgpIHtcbiAgICAgICAgbG9jYWxlcy5mb3JFYWNoKGxvY2FsZSA9PiB7XG4gICAgICAgICAgICBnbC5tZXJnZUxvY2FsZU1lc3NhZ2UobG9jYWxlLCBtZXNzYWdlc1tsb2NhbGVdKTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHtcbiAgICAgICAgLy8gbWVyZ2UgZGF0ZXRpbWUgZm9ybWF0c1xuICAgICAgICBpZiAoaXNPYmplY3Qob3B0aW9ucy5kYXRldGltZUZvcm1hdHMpKSB7XG4gICAgICAgICAgICBjb25zdCBsb2NhbGVzID0gT2JqZWN0LmtleXMob3B0aW9ucy5kYXRldGltZUZvcm1hdHMpO1xuICAgICAgICAgICAgaWYgKGxvY2FsZXMubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgbG9jYWxlcy5mb3JFYWNoKGxvY2FsZSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGdsLm1lcmdlRGF0ZVRpbWVGb3JtYXQobG9jYWxlLCBvcHRpb25zLmRhdGV0aW1lRm9ybWF0c1tsb2NhbGVdKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBtZXJnZSBudW1iZXIgZm9ybWF0c1xuICAgICAgICBpZiAoaXNPYmplY3Qob3B0aW9ucy5udW1iZXJGb3JtYXRzKSkge1xuICAgICAgICAgICAgY29uc3QgbG9jYWxlcyA9IE9iamVjdC5rZXlzKG9wdGlvbnMubnVtYmVyRm9ybWF0cyk7XG4gICAgICAgICAgICBpZiAobG9jYWxlcy5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICBsb2NhbGVzLmZvckVhY2gobG9jYWxlID0+IHtcbiAgICAgICAgICAgICAgICAgICAgZ2wubWVyZ2VOdW1iZXJGb3JtYXQobG9jYWxlLCBvcHRpb25zLm51bWJlckZvcm1hdHNbbG9jYWxlXSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG5mdW5jdGlvbiBjcmVhdGVUZXh0Tm9kZShrZXkpIHtcbiAgICByZXR1cm4gY3JlYXRlVk5vZGUoVGV4dCwgbnVsbCwga2V5LCAwKTtcbn1cbmZ1bmN0aW9uIGdldEN1cnJlbnRJbnN0YW5jZSgpIHtcbiAgICAvLyBOT1RFKGthenVwb24pOiBhdm9pZCBidW5kbGVyIHdhcm5pbmdcbiAgICBjb25zdCBrZXkgPSAnY3VycmVudEluc3RhbmNlJztcbiAgICBpZiAoa2V5IGluIFZ1ZSkge1xuICAgICAgICByZXR1cm4gVnVlW2tleV07XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICByZXR1cm4gVnVlLmdldEN1cnJlbnRJbnN0YW5jZSgpO1xuICAgIH1cbn1cbi8qIGVzbGludC1lbmFibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuXG4vKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG4vLyBleHRlbmQgVk5vZGUgaW50ZXJmYWNlXG5jb25zdCBERVZUT09MU19NRVRBID0gJ19fSU5UTElGWV9NRVRBX18nO1xuY29uc3QgTk9PUF9SRVRVUk5fQVJSQVkgPSAoKSA9PiBbXTtcbmNvbnN0IE5PT1BfUkVUVVJOX0ZBTFNFID0gKCkgPT4gZmFsc2U7XG5sZXQgY29tcG9zZXJJRCA9IDA7XG5mdW5jdGlvbiBkZWZpbmVDb3JlTWlzc2luZ0hhbmRsZXIobWlzc2luZykge1xuICAgIHJldHVybiAoKGN0eCwgbG9jYWxlLCBrZXksIHR5cGUpID0+IHtcbiAgICAgICAgcmV0dXJuIG1pc3NpbmcobG9jYWxlLCBrZXksIGdldEN1cnJlbnRJbnN0YW5jZSgpIHx8IHVuZGVmaW5lZCwgdHlwZSk7XG4gICAgfSk7XG59XG4vLyBmb3IgSW50bGlmeSBEZXZUb29sc1xuLyogI19fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmNvbnN0IGdldE1ldGFJbmZvID0gKCkgPT4ge1xuICAgIGNvbnN0IGluc3RhbmNlID0gZ2V0Q3VycmVudEluc3RhbmNlKCk7XG4gICAgbGV0IG1ldGEgPSBudWxsO1xuICAgIHJldHVybiBpbnN0YW5jZSAmJiAobWV0YSA9IGdldENvbXBvbmVudE9wdGlvbnMoaW5zdGFuY2UpW0RFVlRPT0xTX01FVEFdKVxuICAgICAgICA/IHsgW0RFVlRPT0xTX01FVEFdOiBtZXRhIH1cbiAgICAgICAgOiBudWxsO1xufTtcbi8qKlxuICogQ3JlYXRlIGNvbXBvc2VyIGludGVyZmFjZSBmYWN0b3J5XG4gKlxuICogQGludGVybmFsXG4gKi9cbmZ1bmN0aW9uIGNyZWF0ZUNvbXBvc2VyKG9wdGlvbnMgPSB7fSkge1xuICAgIGNvbnN0IHsgX19yb290LCBfX2luamVjdFdpdGhPcHRpb24gfSA9IG9wdGlvbnM7XG4gICAgY29uc3QgX2lzR2xvYmFsID0gX19yb290ID09PSB1bmRlZmluZWQ7XG4gICAgY29uc3QgZmxhdEpzb24gPSBvcHRpb25zLmZsYXRKc29uO1xuICAgIGNvbnN0IF9yZWYgPSBpbkJyb3dzZXIgPyByZWYgOiBzaGFsbG93UmVmO1xuICAgIGxldCBfaW5oZXJpdExvY2FsZSA9IGlzQm9vbGVhbihvcHRpb25zLmluaGVyaXRMb2NhbGUpXG4gICAgICAgID8gb3B0aW9ucy5pbmhlcml0TG9jYWxlXG4gICAgICAgIDogdHJ1ZTtcbiAgICBjb25zdCBfbG9jYWxlID0gX3JlZihcbiAgICAvLyBwcmV0dGllci1pZ25vcmVcbiAgICBfX3Jvb3QgJiYgX2luaGVyaXRMb2NhbGVcbiAgICAgICAgPyBfX3Jvb3QubG9jYWxlLnZhbHVlXG4gICAgICAgIDogaXNTdHJpbmcob3B0aW9ucy5sb2NhbGUpXG4gICAgICAgICAgICA/IG9wdGlvbnMubG9jYWxlXG4gICAgICAgICAgICA6IERFRkFVTFRfTE9DQUxFKTtcbiAgICBjb25zdCBfZmFsbGJhY2tMb2NhbGUgPSBfcmVmKFxuICAgIC8vIHByZXR0aWVyLWlnbm9yZVxuICAgIF9fcm9vdCAmJiBfaW5oZXJpdExvY2FsZVxuICAgICAgICA/IF9fcm9vdC5mYWxsYmFja0xvY2FsZS52YWx1ZVxuICAgICAgICA6IGlzU3RyaW5nKG9wdGlvbnMuZmFsbGJhY2tMb2NhbGUpIHx8XG4gICAgICAgICAgICBpc0FycmF5KG9wdGlvbnMuZmFsbGJhY2tMb2NhbGUpIHx8XG4gICAgICAgICAgICBpc1BsYWluT2JqZWN0KG9wdGlvbnMuZmFsbGJhY2tMb2NhbGUpIHx8XG4gICAgICAgICAgICBvcHRpb25zLmZhbGxiYWNrTG9jYWxlID09PSBmYWxzZVxuICAgICAgICAgICAgPyBvcHRpb25zLmZhbGxiYWNrTG9jYWxlXG4gICAgICAgICAgICA6IF9sb2NhbGUudmFsdWUpO1xuICAgIGNvbnN0IF9tZXNzYWdlcyA9IF9yZWYoZ2V0TG9jYWxlTWVzc2FnZXMoX2xvY2FsZS52YWx1ZSwgb3B0aW9ucykpO1xuICAgIC8vIHByZXR0aWVyLWlnbm9yZVxuICAgIGNvbnN0IF9kYXRldGltZUZvcm1hdHMgPSBfcmVmKGlzUGxhaW5PYmplY3Qob3B0aW9ucy5kYXRldGltZUZvcm1hdHMpXG4gICAgICAgICAgICA/IG9wdGlvbnMuZGF0ZXRpbWVGb3JtYXRzXG4gICAgICAgICAgICA6IHsgW19sb2NhbGUudmFsdWVdOiB7fSB9KVxuICAgICAgICA7XG4gICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgY29uc3QgX251bWJlckZvcm1hdHMgPSBfcmVmKGlzUGxhaW5PYmplY3Qob3B0aW9ucy5udW1iZXJGb3JtYXRzKVxuICAgICAgICAgICAgPyBvcHRpb25zLm51bWJlckZvcm1hdHNcbiAgICAgICAgICAgIDogeyBbX2xvY2FsZS52YWx1ZV06IHt9IH0pXG4gICAgICAgIDtcbiAgICAvLyB3YXJuaW5nIHN1cHByZXNzIG9wdGlvbnNcbiAgICAvLyBwcmV0dGllci1pZ25vcmVcbiAgICBsZXQgX21pc3NpbmdXYXJuID0gX19yb290XG4gICAgICAgID8gX19yb290Lm1pc3NpbmdXYXJuXG4gICAgICAgIDogaXNCb29sZWFuKG9wdGlvbnMubWlzc2luZ1dhcm4pIHx8IGlzUmVnRXhwKG9wdGlvbnMubWlzc2luZ1dhcm4pXG4gICAgICAgICAgICA/IG9wdGlvbnMubWlzc2luZ1dhcm5cbiAgICAgICAgICAgIDogdHJ1ZTtcbiAgICAvLyBwcmV0dGllci1pZ25vcmVcbiAgICBsZXQgX2ZhbGxiYWNrV2FybiA9IF9fcm9vdFxuICAgICAgICA/IF9fcm9vdC5mYWxsYmFja1dhcm5cbiAgICAgICAgOiBpc0Jvb2xlYW4ob3B0aW9ucy5mYWxsYmFja1dhcm4pIHx8IGlzUmVnRXhwKG9wdGlvbnMuZmFsbGJhY2tXYXJuKVxuICAgICAgICAgICAgPyBvcHRpb25zLmZhbGxiYWNrV2FyblxuICAgICAgICAgICAgOiB0cnVlO1xuICAgIC8vIHByZXR0aWVyLWlnbm9yZVxuICAgIGxldCBfZmFsbGJhY2tSb290ID0gX19yb290XG4gICAgICAgID8gX19yb290LmZhbGxiYWNrUm9vdFxuICAgICAgICA6IGlzQm9vbGVhbihvcHRpb25zLmZhbGxiYWNrUm9vdClcbiAgICAgICAgICAgID8gb3B0aW9ucy5mYWxsYmFja1Jvb3RcbiAgICAgICAgICAgIDogdHJ1ZTtcbiAgICAvLyBjb25maWd1cmUgZmFsbCBiYWNrIHRvIHJvb3RcbiAgICBsZXQgX2ZhbGxiYWNrRm9ybWF0ID0gISFvcHRpb25zLmZhbGxiYWNrRm9ybWF0O1xuICAgIC8vIHJ1bnRpbWUgbWlzc2luZ1xuICAgIGxldCBfbWlzc2luZyA9IGlzRnVuY3Rpb24ob3B0aW9ucy5taXNzaW5nKSA/IG9wdGlvbnMubWlzc2luZyA6IG51bGw7XG4gICAgbGV0IF9ydW50aW1lTWlzc2luZyA9IGlzRnVuY3Rpb24ob3B0aW9ucy5taXNzaW5nKVxuICAgICAgICA/IGRlZmluZUNvcmVNaXNzaW5nSGFuZGxlcihvcHRpb25zLm1pc3NpbmcpXG4gICAgICAgIDogbnVsbDtcbiAgICAvLyBwb3N0VHJhbnNsYXRpb24gaGFuZGxlclxuICAgIGxldCBfcG9zdFRyYW5zbGF0aW9uID0gaXNGdW5jdGlvbihvcHRpb25zLnBvc3RUcmFuc2xhdGlvbilcbiAgICAgICAgPyBvcHRpb25zLnBvc3RUcmFuc2xhdGlvblxuICAgICAgICA6IG51bGw7XG4gICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgbGV0IF93YXJuSHRtbE1lc3NhZ2UgPSBfX3Jvb3RcbiAgICAgICAgPyBfX3Jvb3Qud2Fybkh0bWxNZXNzYWdlXG4gICAgICAgIDogaXNCb29sZWFuKG9wdGlvbnMud2Fybkh0bWxNZXNzYWdlKVxuICAgICAgICAgICAgPyBvcHRpb25zLndhcm5IdG1sTWVzc2FnZVxuICAgICAgICAgICAgOiB0cnVlO1xuICAgIGxldCBfZXNjYXBlUGFyYW1ldGVyID0gISFvcHRpb25zLmVzY2FwZVBhcmFtZXRlcjtcbiAgICAvLyBjdXN0b20gbGlua2VkIG1vZGlmaWVyc1xuICAgIC8vIHByZXR0aWVyLWlnbm9yZVxuICAgIGNvbnN0IF9tb2RpZmllcnMgPSBfX3Jvb3RcbiAgICAgICAgPyBfX3Jvb3QubW9kaWZpZXJzXG4gICAgICAgIDogaXNQbGFpbk9iamVjdChvcHRpb25zLm1vZGlmaWVycylcbiAgICAgICAgICAgID8gb3B0aW9ucy5tb2RpZmllcnNcbiAgICAgICAgICAgIDoge307XG4gICAgLy8gcGx1cmFsUnVsZXNcbiAgICBsZXQgX3BsdXJhbFJ1bGVzID0gb3B0aW9ucy5wbHVyYWxSdWxlcyB8fCAoX19yb290ICYmIF9fcm9vdC5wbHVyYWxSdWxlcyk7XG4gICAgLy8gcnVudGltZSBjb250ZXh0XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHByZWZlci1jb25zdFxuICAgIGxldCBfY29udGV4dDtcbiAgICBjb25zdCBnZXRDb3JlQ29udGV4dCA9ICgpID0+IHtcbiAgICAgICAgX2lzR2xvYmFsICYmIHNldEZhbGxiYWNrQ29udGV4dChudWxsKTtcbiAgICAgICAgY29uc3QgY3R4T3B0aW9ucyA9IHtcbiAgICAgICAgICAgIHZlcnNpb246IFZFUlNJT04sXG4gICAgICAgICAgICBsb2NhbGU6IF9sb2NhbGUudmFsdWUsXG4gICAgICAgICAgICBmYWxsYmFja0xvY2FsZTogX2ZhbGxiYWNrTG9jYWxlLnZhbHVlLFxuICAgICAgICAgICAgbWVzc2FnZXM6IF9tZXNzYWdlcy52YWx1ZSxcbiAgICAgICAgICAgIG1vZGlmaWVyczogX21vZGlmaWVycyxcbiAgICAgICAgICAgIHBsdXJhbFJ1bGVzOiBfcGx1cmFsUnVsZXMsXG4gICAgICAgICAgICBtaXNzaW5nOiBfcnVudGltZU1pc3NpbmcgPT09IG51bGwgPyB1bmRlZmluZWQgOiBfcnVudGltZU1pc3NpbmcsXG4gICAgICAgICAgICBtaXNzaW5nV2FybjogX21pc3NpbmdXYXJuLFxuICAgICAgICAgICAgZmFsbGJhY2tXYXJuOiBfZmFsbGJhY2tXYXJuLFxuICAgICAgICAgICAgZmFsbGJhY2tGb3JtYXQ6IF9mYWxsYmFja0Zvcm1hdCxcbiAgICAgICAgICAgIHVucmVzb2x2aW5nOiB0cnVlLFxuICAgICAgICAgICAgcG9zdFRyYW5zbGF0aW9uOiBfcG9zdFRyYW5zbGF0aW9uID09PSBudWxsID8gdW5kZWZpbmVkIDogX3Bvc3RUcmFuc2xhdGlvbixcbiAgICAgICAgICAgIHdhcm5IdG1sTWVzc2FnZTogX3dhcm5IdG1sTWVzc2FnZSxcbiAgICAgICAgICAgIGVzY2FwZVBhcmFtZXRlcjogX2VzY2FwZVBhcmFtZXRlcixcbiAgICAgICAgICAgIG1lc3NhZ2VSZXNvbHZlcjogb3B0aW9ucy5tZXNzYWdlUmVzb2x2ZXIsXG4gICAgICAgICAgICBtZXNzYWdlQ29tcGlsZXI6IG9wdGlvbnMubWVzc2FnZUNvbXBpbGVyLFxuICAgICAgICAgICAgX19tZXRhOiB7IGZyYW1ld29yazogJ3Z1ZScgfVxuICAgICAgICB9O1xuICAgICAgICB7XG4gICAgICAgICAgICBjdHhPcHRpb25zLmRhdGV0aW1lRm9ybWF0cyA9IF9kYXRldGltZUZvcm1hdHMudmFsdWU7XG4gICAgICAgICAgICBjdHhPcHRpb25zLm51bWJlckZvcm1hdHMgPSBfbnVtYmVyRm9ybWF0cy52YWx1ZTtcbiAgICAgICAgICAgIGN0eE9wdGlvbnMuX19kYXRldGltZUZvcm1hdHRlcnMgPSBpc1BsYWluT2JqZWN0KF9jb250ZXh0KVxuICAgICAgICAgICAgICAgID8gX2NvbnRleHQuX19kYXRldGltZUZvcm1hdHRlcnNcbiAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIGN0eE9wdGlvbnMuX19udW1iZXJGb3JtYXR0ZXJzID0gaXNQbGFpbk9iamVjdChfY29udGV4dClcbiAgICAgICAgICAgICAgICA/IF9jb250ZXh0Ll9fbnVtYmVyRm9ybWF0dGVyc1xuICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIGlmICgocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykpIHtcbiAgICAgICAgICAgIGN0eE9wdGlvbnMuX192X2VtaXR0ZXIgPSBpc1BsYWluT2JqZWN0KF9jb250ZXh0KVxuICAgICAgICAgICAgICAgID8gX2NvbnRleHQuX192X2VtaXR0ZXJcbiAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjdHggPSBjcmVhdGVDb3JlQ29udGV4dChjdHhPcHRpb25zKTtcbiAgICAgICAgX2lzR2xvYmFsICYmIHNldEZhbGxiYWNrQ29udGV4dChjdHgpO1xuICAgICAgICByZXR1cm4gY3R4O1xuICAgIH07XG4gICAgX2NvbnRleHQgPSBnZXRDb3JlQ29udGV4dCgpO1xuICAgIHVwZGF0ZUZhbGxiYWNrTG9jYWxlKF9jb250ZXh0LCBfbG9jYWxlLnZhbHVlLCBfZmFsbGJhY2tMb2NhbGUudmFsdWUpO1xuICAgIC8vIHRyYWNrIHJlYWN0aXZpdHlcbiAgICBmdW5jdGlvbiB0cmFja1JlYWN0aXZpdHlWYWx1ZXMoKSB7XG4gICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICAgICAgX2xvY2FsZS52YWx1ZSxcbiAgICAgICAgICAgICAgICBfZmFsbGJhY2tMb2NhbGUudmFsdWUsXG4gICAgICAgICAgICAgICAgX21lc3NhZ2VzLnZhbHVlLFxuICAgICAgICAgICAgICAgIF9kYXRldGltZUZvcm1hdHMudmFsdWUsXG4gICAgICAgICAgICAgICAgX251bWJlckZvcm1hdHMudmFsdWVcbiAgICAgICAgICAgIF1cbiAgICAgICAgICAgIDtcbiAgICB9XG4gICAgLy8gbG9jYWxlXG4gICAgY29uc3QgbG9jYWxlID0gY29tcHV0ZWQoe1xuICAgICAgICBnZXQ6ICgpID0+IF9sb2NhbGUudmFsdWUsXG4gICAgICAgIHNldDogdmFsID0+IHtcbiAgICAgICAgICAgIF9jb250ZXh0LmxvY2FsZSA9IHZhbDtcbiAgICAgICAgICAgIF9sb2NhbGUudmFsdWUgPSB2YWw7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICAvLyBmYWxsYmFja0xvY2FsZVxuICAgIGNvbnN0IGZhbGxiYWNrTG9jYWxlID0gY29tcHV0ZWQoe1xuICAgICAgICBnZXQ6ICgpID0+IF9mYWxsYmFja0xvY2FsZS52YWx1ZSxcbiAgICAgICAgc2V0OiB2YWwgPT4ge1xuICAgICAgICAgICAgX2NvbnRleHQuZmFsbGJhY2tMb2NhbGUgPSB2YWw7XG4gICAgICAgICAgICBfZmFsbGJhY2tMb2NhbGUudmFsdWUgPSB2YWw7XG4gICAgICAgICAgICB1cGRhdGVGYWxsYmFja0xvY2FsZShfY29udGV4dCwgX2xvY2FsZS52YWx1ZSwgdmFsKTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIC8vIG1lc3NhZ2VzXG4gICAgY29uc3QgbWVzc2FnZXMgPSBjb21wdXRlZCgoKSA9PiBfbWVzc2FnZXMudmFsdWUpO1xuICAgIC8vIGRhdGV0aW1lRm9ybWF0c1xuICAgIGNvbnN0IGRhdGV0aW1lRm9ybWF0cyA9IC8qICNfX1BVUkVfXyovIGNvbXB1dGVkKCgpID0+IF9kYXRldGltZUZvcm1hdHMudmFsdWUpO1xuICAgIC8vIG51bWJlckZvcm1hdHNcbiAgICBjb25zdCBudW1iZXJGb3JtYXRzID0gLyogI19fUFVSRV9fKi8gY29tcHV0ZWQoKCkgPT4gX251bWJlckZvcm1hdHMudmFsdWUpO1xuICAgIC8vIGdldFBvc3RUcmFuc2xhdGlvbkhhbmRsZXJcbiAgICBmdW5jdGlvbiBnZXRQb3N0VHJhbnNsYXRpb25IYW5kbGVyKCkge1xuICAgICAgICByZXR1cm4gaXNGdW5jdGlvbihfcG9zdFRyYW5zbGF0aW9uKSA/IF9wb3N0VHJhbnNsYXRpb24gOiBudWxsO1xuICAgIH1cbiAgICAvLyBzZXRQb3N0VHJhbnNsYXRpb25IYW5kbGVyXG4gICAgZnVuY3Rpb24gc2V0UG9zdFRyYW5zbGF0aW9uSGFuZGxlcihoYW5kbGVyKSB7XG4gICAgICAgIF9wb3N0VHJhbnNsYXRpb24gPSBoYW5kbGVyO1xuICAgICAgICBfY29udGV4dC5wb3N0VHJhbnNsYXRpb24gPSBoYW5kbGVyO1xuICAgIH1cbiAgICAvLyBnZXRNaXNzaW5nSGFuZGxlclxuICAgIGZ1bmN0aW9uIGdldE1pc3NpbmdIYW5kbGVyKCkge1xuICAgICAgICByZXR1cm4gX21pc3Npbmc7XG4gICAgfVxuICAgIC8vIHNldE1pc3NpbmdIYW5kbGVyXG4gICAgZnVuY3Rpb24gc2V0TWlzc2luZ0hhbmRsZXIoaGFuZGxlcikge1xuICAgICAgICBpZiAoaGFuZGxlciAhPT0gbnVsbCkge1xuICAgICAgICAgICAgX3J1bnRpbWVNaXNzaW5nID0gZGVmaW5lQ29yZU1pc3NpbmdIYW5kbGVyKGhhbmRsZXIpO1xuICAgICAgICB9XG4gICAgICAgIF9taXNzaW5nID0gaGFuZGxlcjtcbiAgICAgICAgX2NvbnRleHQubWlzc2luZyA9IF9ydW50aW1lTWlzc2luZztcbiAgICB9XG4gICAgZnVuY3Rpb24gaXNSZXNvbHZlZFRyYW5zbGF0ZU1lc3NhZ2UodHlwZSwgYXJnKSB7XG4gICAgICAgIHJldHVybiB0eXBlICE9PSAndHJhbnNsYXRlJyB8fCAhYXJnLnJlc29sdmVkTWVzc2FnZTtcbiAgICB9XG4gICAgY29uc3Qgd3JhcFdpdGhEZXBzID0gKGZuLCBhcmd1bWVudFBhcnNlciwgd2FyblR5cGUsIGZhbGxiYWNrU3VjY2VzcywgZmFsbGJhY2tGYWlsLCBzdWNjZXNzQ29uZGl0aW9uKSA9PiB7XG4gICAgICAgIHRyYWNrUmVhY3Rpdml0eVZhbHVlcygpOyAvLyB0cmFjayByZWFjdGl2ZSBkZXBlbmRlbmN5XG4gICAgICAgIC8vIE5PVEU6IGV4cGVyaW1lbnRhbCAhIVxuICAgICAgICBsZXQgcmV0O1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB8fCBfX0lOVExJRllfUFJPRF9ERVZUT09MU19fKSB7XG4gICAgICAgICAgICAgICAgc2V0QWRkaXRpb25hbE1ldGEoZ2V0TWV0YUluZm8oKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIV9pc0dsb2JhbCkge1xuICAgICAgICAgICAgICAgIF9jb250ZXh0LmZhbGxiYWNrQ29udGV4dCA9IF9fcm9vdFxuICAgICAgICAgICAgICAgICAgICA/IGdldEZhbGxiYWNrQ29udGV4dCgpXG4gICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0ID0gZm4oX2NvbnRleHQpO1xuICAgICAgICB9XG4gICAgICAgIGZpbmFsbHkge1xuICAgICAgICAgICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB8fCBfX0lOVExJRllfUFJPRF9ERVZUT09MU19fKSB7XG4gICAgICAgICAgICAgICAgc2V0QWRkaXRpb25hbE1ldGEobnVsbCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIV9pc0dsb2JhbCkge1xuICAgICAgICAgICAgICAgIF9jb250ZXh0LmZhbGxiYWNrQ29udGV4dCA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoKHdhcm5UeXBlICE9PSAndHJhbnNsYXRlIGV4aXN0cycgJiYgLy8gZm9yIG5vdCBgdGVgIChlLmcgYHRgKVxuICAgICAgICAgICAgaXNOdW1iZXIocmV0KSAmJlxuICAgICAgICAgICAgcmV0ID09PSBOT1RfUkVPU0xWRUQpIHx8XG4gICAgICAgICAgICAod2FyblR5cGUgPT09ICd0cmFuc2xhdGUgZXhpc3RzJyAmJiAhcmV0KSAvLyBmb3IgYHRlYFxuICAgICAgICApIHtcbiAgICAgICAgICAgIGNvbnN0IFtrZXksIGFyZzJdID0gYXJndW1lbnRQYXJzZXIoKTtcbiAgICAgICAgICAgIGlmICgocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgJiZcbiAgICAgICAgICAgICAgICBfX3Jvb3QgJiZcbiAgICAgICAgICAgICAgICBpc1N0cmluZyhrZXkpICYmXG4gICAgICAgICAgICAgICAgaXNSZXNvbHZlZFRyYW5zbGF0ZU1lc3NhZ2Uod2FyblR5cGUsIGFyZzIpKSB7XG4gICAgICAgICAgICAgICAgaWYgKF9mYWxsYmFja1Jvb3QgJiZcbiAgICAgICAgICAgICAgICAgICAgKGlzVHJhbnNsYXRlRmFsbGJhY2tXYXJuKF9mYWxsYmFja1dhcm4sIGtleSkgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzVHJhbnNsYXRlTWlzc2luZ1dhcm4oX21pc3NpbmdXYXJuLCBrZXkpKSkge1xuICAgICAgICAgICAgICAgICAgICB3YXJuKGdldFdhcm5NZXNzYWdlKEkxOG5XYXJuQ29kZXMuRkFMTEJBQ0tfVE9fUk9PVCwge1xuICAgICAgICAgICAgICAgICAgICAgICAga2V5LFxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZTogd2FyblR5cGVcbiAgICAgICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvLyBmb3IgdnVlLWRldnRvb2xzIHRpbWVsaW5lIGV2ZW50XG4gICAgICAgICAgICAgICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB7IF9fdl9lbWl0dGVyOiBlbWl0dGVyIH0gPSBfY29udGV4dDtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVtaXR0ZXIgJiYgX2ZhbGxiYWNrUm9vdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZW1pdHRlci5lbWl0KCdmYWxsYmFjaycsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiB3YXJuVHlwZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdG86ICdnbG9iYWwnLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwSWQ6IGAke3dhcm5UeXBlfToke2tleX1gXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBfX3Jvb3QgJiYgX2ZhbGxiYWNrUm9vdFxuICAgICAgICAgICAgICAgID8gZmFsbGJhY2tTdWNjZXNzKF9fcm9vdClcbiAgICAgICAgICAgICAgICA6IGZhbGxiYWNrRmFpbChrZXkpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHN1Y2Nlc3NDb25kaXRpb24ocmV0KSkge1xuICAgICAgICAgICAgcmV0dXJuIHJldDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIC8qIGlzdGFuYnVsIGlnbm9yZSBuZXh0ICovXG4gICAgICAgICAgICB0aHJvdyBjcmVhdGVJMThuRXJyb3IoSTE4bkVycm9yQ29kZXMuVU5FWFBFQ1RFRF9SRVRVUk5fVFlQRSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIC8vIHRcbiAgICBmdW5jdGlvbiB0KC4uLmFyZ3MpIHtcbiAgICAgICAgcmV0dXJuIHdyYXBXaXRoRGVwcyhjb250ZXh0ID0+IFJlZmxlY3QuYXBwbHkodHJhbnNsYXRlLCBudWxsLCBbY29udGV4dCwgLi4uYXJnc10pLCAoKSA9PiBwYXJzZVRyYW5zbGF0ZUFyZ3MoLi4uYXJncyksICd0cmFuc2xhdGUnLCByb290ID0+IFJlZmxlY3QuYXBwbHkocm9vdC50LCByb290LCBbLi4uYXJnc10pLCBrZXkgPT4ga2V5LCB2YWwgPT4gaXNTdHJpbmcodmFsKSk7XG4gICAgfVxuICAgIC8vIHJ0XG4gICAgZnVuY3Rpb24gcnQoLi4uYXJncykge1xuICAgICAgICBjb25zdCBbYXJnMSwgYXJnMiwgYXJnM10gPSBhcmdzO1xuICAgICAgICBpZiAoYXJnMyAmJiAhaXNPYmplY3QoYXJnMykpIHtcbiAgICAgICAgICAgIHRocm93IGNyZWF0ZUkxOG5FcnJvcihJMThuRXJyb3JDb2Rlcy5JTlZBTElEX0FSR1VNRU5UKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdCguLi5bYXJnMSwgYXJnMiwgYXNzaWduKHsgcmVzb2x2ZWRNZXNzYWdlOiB0cnVlIH0sIGFyZzMgfHwge30pXSk7XG4gICAgfVxuICAgIC8vIGRcbiAgICBmdW5jdGlvbiBkKC4uLmFyZ3MpIHtcbiAgICAgICAgcmV0dXJuIHdyYXBXaXRoRGVwcyhjb250ZXh0ID0+IFJlZmxlY3QuYXBwbHkoZGF0ZXRpbWUsIG51bGwsIFtjb250ZXh0LCAuLi5hcmdzXSksICgpID0+IHBhcnNlRGF0ZVRpbWVBcmdzKC4uLmFyZ3MpLCAnZGF0ZXRpbWUgZm9ybWF0Jywgcm9vdCA9PiBSZWZsZWN0LmFwcGx5KHJvb3QuZCwgcm9vdCwgWy4uLmFyZ3NdKSwgKCkgPT4gTUlTU0lOR19SRVNPTFZFX1ZBTFVFLCB2YWwgPT4gaXNTdHJpbmcodmFsKSB8fCBpc0FycmF5KHZhbCkpO1xuICAgIH1cbiAgICAvLyBuXG4gICAgZnVuY3Rpb24gbiguLi5hcmdzKSB7XG4gICAgICAgIHJldHVybiB3cmFwV2l0aERlcHMoY29udGV4dCA9PiBSZWZsZWN0LmFwcGx5KG51bWJlciwgbnVsbCwgW2NvbnRleHQsIC4uLmFyZ3NdKSwgKCkgPT4gcGFyc2VOdW1iZXJBcmdzKC4uLmFyZ3MpLCAnbnVtYmVyIGZvcm1hdCcsIHJvb3QgPT4gUmVmbGVjdC5hcHBseShyb290Lm4sIHJvb3QsIFsuLi5hcmdzXSksICgpID0+IE1JU1NJTkdfUkVTT0xWRV9WQUxVRSwgdmFsID0+IGlzU3RyaW5nKHZhbCkgfHwgaXNBcnJheSh2YWwpKTtcbiAgICB9XG4gICAgLy8gZm9yIGN1c3RvbSBwcm9jZXNzb3JcbiAgICBmdW5jdGlvbiBub3JtYWxpemUodmFsdWVzKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZXMubWFwKHZhbCA9PiBpc1N0cmluZyh2YWwpIHx8IGlzTnVtYmVyKHZhbCkgfHwgaXNCb29sZWFuKHZhbClcbiAgICAgICAgICAgID8gY3JlYXRlVGV4dE5vZGUoU3RyaW5nKHZhbCkpXG4gICAgICAgICAgICA6IHZhbCk7XG4gICAgfVxuICAgIGNvbnN0IGludGVycG9sYXRlID0gKHZhbCkgPT4gdmFsO1xuICAgIGNvbnN0IHByb2Nlc3NvciA9IHtcbiAgICAgICAgbm9ybWFsaXplLFxuICAgICAgICBpbnRlcnBvbGF0ZSxcbiAgICAgICAgdHlwZTogJ3Zub2RlJ1xuICAgIH07XG4gICAgLy8gdHJhbnNsYXRlVk5vZGUsIHVzaW5nIGZvciBgaTE4bi10YCBjb21wb25lbnRcbiAgICBmdW5jdGlvbiB0cmFuc2xhdGVWTm9kZSguLi5hcmdzKSB7XG4gICAgICAgIHJldHVybiB3cmFwV2l0aERlcHMoY29udGV4dCA9PiB7XG4gICAgICAgICAgICBsZXQgcmV0O1xuICAgICAgICAgICAgY29uc3QgX2NvbnRleHQgPSBjb250ZXh0O1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBfY29udGV4dC5wcm9jZXNzb3IgPSBwcm9jZXNzb3I7XG4gICAgICAgICAgICAgICAgcmV0ID0gUmVmbGVjdC5hcHBseSh0cmFuc2xhdGUsIG51bGwsIFtfY29udGV4dCwgLi4uYXJnc10pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICAgICAgX2NvbnRleHQucHJvY2Vzc29yID0gbnVsbDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiByZXQ7XG4gICAgICAgIH0sICgpID0+IHBhcnNlVHJhbnNsYXRlQXJncyguLi5hcmdzKSwgJ3RyYW5zbGF0ZScsIHJvb3QgPT4gcm9vdFtUcmFuc2xhdGVWTm9kZVN5bWJvbF0oLi4uYXJncyksIGtleSA9PiBbY3JlYXRlVGV4dE5vZGUoa2V5KV0sIHZhbCA9PiBpc0FycmF5KHZhbCkpO1xuICAgIH1cbiAgICAvLyBudW1iZXJQYXJ0cywgdXNpbmcgZm9yIGBpMThuLW5gIGNvbXBvbmVudFxuICAgIGZ1bmN0aW9uIG51bWJlclBhcnRzKC4uLmFyZ3MpIHtcbiAgICAgICAgcmV0dXJuIHdyYXBXaXRoRGVwcyhjb250ZXh0ID0+IFJlZmxlY3QuYXBwbHkobnVtYmVyLCBudWxsLCBbY29udGV4dCwgLi4uYXJnc10pLCAoKSA9PiBwYXJzZU51bWJlckFyZ3MoLi4uYXJncyksICdudW1iZXIgZm9ybWF0Jywgcm9vdCA9PiByb290W051bWJlclBhcnRzU3ltYm9sXSguLi5hcmdzKSwgTk9PUF9SRVRVUk5fQVJSQVksIHZhbCA9PiBpc1N0cmluZyh2YWwpIHx8IGlzQXJyYXkodmFsKSk7XG4gICAgfVxuICAgIC8vIGRhdGV0aW1lUGFydHMsIHVzaW5nIGZvciBgaTE4bi1kYCBjb21wb25lbnRcbiAgICBmdW5jdGlvbiBkYXRldGltZVBhcnRzKC4uLmFyZ3MpIHtcbiAgICAgICAgcmV0dXJuIHdyYXBXaXRoRGVwcyhjb250ZXh0ID0+IFJlZmxlY3QuYXBwbHkoZGF0ZXRpbWUsIG51bGwsIFtjb250ZXh0LCAuLi5hcmdzXSksICgpID0+IHBhcnNlRGF0ZVRpbWVBcmdzKC4uLmFyZ3MpLCAnZGF0ZXRpbWUgZm9ybWF0Jywgcm9vdCA9PiByb290W0RhdGV0aW1lUGFydHNTeW1ib2xdKC4uLmFyZ3MpLCBOT09QX1JFVFVSTl9BUlJBWSwgdmFsID0+IGlzU3RyaW5nKHZhbCkgfHwgaXNBcnJheSh2YWwpKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gc2V0UGx1cmFsUnVsZXMocnVsZXMpIHtcbiAgICAgICAgX3BsdXJhbFJ1bGVzID0gcnVsZXM7XG4gICAgICAgIF9jb250ZXh0LnBsdXJhbFJ1bGVzID0gX3BsdXJhbFJ1bGVzO1xuICAgIH1cbiAgICAvLyB0ZVxuICAgIGZ1bmN0aW9uIHRlKGtleSwgbG9jYWxlKSB7XG4gICAgICAgIHJldHVybiB3cmFwV2l0aERlcHMoKCkgPT4ge1xuICAgICAgICAgICAgaWYgKCFrZXkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCB0YXJnZXRMb2NhbGUgPSBpc1N0cmluZyhsb2NhbGUpID8gbG9jYWxlIDogX2xvY2FsZS52YWx1ZTtcbiAgICAgICAgICAgIC8vIFdoZW4gbG9jYWxlIGlzIGV4cGxpY2l0bHkgc3BlY2lmaWVkLCBjaGVjayBvbmx5IHRoYXQgbG9jYWxlIChubyBmYWxsYmFjayBjaGFpbilcbiAgICAgICAgICAgIC8vIFdoZW4gbG9jYWxlIGlzIG5vdCBzcGVjaWZpZWQsIGNoZWNrIHRoZSBmYWxsYmFjayBsb2NhbGUgY2hhaW5cbiAgICAgICAgICAgIGNvbnN0IGxvY2FsZXMgPSBpc1N0cmluZyhsb2NhbGUpXG4gICAgICAgICAgICAgICAgPyBbdGFyZ2V0TG9jYWxlXVxuICAgICAgICAgICAgICAgIDogZmFsbGJhY2tXaXRoTG9jYWxlQ2hhaW4oX2NvbnRleHQsIF9mYWxsYmFja0xvY2FsZS52YWx1ZSwgdGFyZ2V0TG9jYWxlKTtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbG9jYWxlcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBnZXRMb2NhbGVNZXNzYWdlKGxvY2FsZXNbaV0pO1xuICAgICAgICAgICAgICAgIGxldCByZXNvbHZlZCA9IF9jb250ZXh0Lm1lc3NhZ2VSZXNvbHZlcihtZXNzYWdlLCBrZXkpO1xuICAgICAgICAgICAgICAgIC8vIGlmIG51bGwsIHJlc29sdmUgd2l0aCBvYmplY3Qga2V5IHBhdGggKGZvciBmbGF0IGtleXMgY29udGFpbmluZyBkb3RzKVxuICAgICAgICAgICAgICAgIGlmIChyZXNvbHZlZCA9PT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICByZXNvbHZlZCA9IG1lc3NhZ2Vba2V5XTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGlzTWVzc2FnZUFTVChyZXNvbHZlZCkgfHxcbiAgICAgICAgICAgICAgICAgICAgaXNNZXNzYWdlRnVuY3Rpb24ocmVzb2x2ZWQpIHx8XG4gICAgICAgICAgICAgICAgICAgIGlzU3RyaW5nKHJlc29sdmVkKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH0sICgpID0+IFtrZXldLCAndHJhbnNsYXRlIGV4aXN0cycsIHJvb3QgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIFJlZmxlY3QuYXBwbHkocm9vdC50ZSwgcm9vdCwgW2tleSwgbG9jYWxlXSk7XG4gICAgICAgIH0sIE5PT1BfUkVUVVJOX0ZBTFNFLCB2YWwgPT4gaXNCb29sZWFuKHZhbCkpO1xuICAgIH1cbiAgICBmdW5jdGlvbiByZXNvbHZlTWVzc2FnZXMoa2V5KSB7XG4gICAgICAgIGxldCBtZXNzYWdlcyA9IG51bGw7XG4gICAgICAgIGNvbnN0IGxvY2FsZXMgPSBmYWxsYmFja1dpdGhMb2NhbGVDaGFpbihfY29udGV4dCwgX2ZhbGxiYWNrTG9jYWxlLnZhbHVlLCBfbG9jYWxlLnZhbHVlKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsb2NhbGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCB0YXJnZXRMb2NhbGVNZXNzYWdlcyA9IF9tZXNzYWdlcy52YWx1ZVtsb2NhbGVzW2ldXSB8fCB7fTtcbiAgICAgICAgICAgIGNvbnN0IG1lc3NhZ2VWYWx1ZSA9IF9jb250ZXh0Lm1lc3NhZ2VSZXNvbHZlcih0YXJnZXRMb2NhbGVNZXNzYWdlcywga2V5KTtcbiAgICAgICAgICAgIGlmIChtZXNzYWdlVmFsdWUgIT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIG1lc3NhZ2VzID0gbWVzc2FnZVZhbHVlO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBtZXNzYWdlcztcbiAgICB9XG4gICAgLy8gdG1cbiAgICBmdW5jdGlvbiB0bShrZXkpIHtcbiAgICAgICAgY29uc3QgbWVzc2FnZXMgPSByZXNvbHZlTWVzc2FnZXMoa2V5KTtcbiAgICAgICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgICAgIHJldHVybiBtZXNzYWdlcyAhPSBudWxsXG4gICAgICAgICAgICA/IG1lc3NhZ2VzXG4gICAgICAgICAgICA6IF9fcm9vdFxuICAgICAgICAgICAgICAgID8gX19yb290LnRtKGtleSkgfHwge31cbiAgICAgICAgICAgICAgICA6IHt9O1xuICAgIH1cbiAgICAvLyBnZXRMb2NhbGVNZXNzYWdlXG4gICAgZnVuY3Rpb24gZ2V0TG9jYWxlTWVzc2FnZShsb2NhbGUpIHtcbiAgICAgICAgcmV0dXJuIChfbWVzc2FnZXMudmFsdWVbbG9jYWxlXSB8fCB7fSk7XG4gICAgfVxuICAgIC8vIHNldExvY2FsZU1lc3NhZ2VcbiAgICBmdW5jdGlvbiBzZXRMb2NhbGVNZXNzYWdlKGxvY2FsZSwgbWVzc2FnZSkge1xuICAgICAgICBpZiAoZmxhdEpzb24pIHtcbiAgICAgICAgICAgIGNvbnN0IF9tZXNzYWdlID0geyBbbG9jYWxlXTogbWVzc2FnZSB9O1xuICAgICAgICAgICAgZm9yIChjb25zdCBrZXkgaW4gX21lc3NhZ2UpIHtcbiAgICAgICAgICAgICAgICBpZiAoaGFzT3duKF9tZXNzYWdlLCBrZXkpKSB7XG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZUZsYXRKc29uKF9tZXNzYWdlW2tleV0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG1lc3NhZ2UgPSBfbWVzc2FnZVtsb2NhbGVdO1xuICAgICAgICB9XG4gICAgICAgIF9tZXNzYWdlcy52YWx1ZVtsb2NhbGVdID0gbWVzc2FnZTtcbiAgICAgICAgX2NvbnRleHQubWVzc2FnZXMgPSBfbWVzc2FnZXMudmFsdWU7XG4gICAgfVxuICAgIC8vIG1lcmdlTG9jYWxlTWVzc2FnZVxuICAgIGZ1bmN0aW9uIG1lcmdlTG9jYWxlTWVzc2FnZShsb2NhbGUsIG1lc3NhZ2UpIHtcbiAgICAgICAgX21lc3NhZ2VzLnZhbHVlW2xvY2FsZV0gPSBfbWVzc2FnZXMudmFsdWVbbG9jYWxlXSB8fCB7fTtcbiAgICAgICAgY29uc3QgX21lc3NhZ2UgPSB7IFtsb2NhbGVdOiBtZXNzYWdlIH07XG4gICAgICAgIGlmIChmbGF0SnNvbikge1xuICAgICAgICAgICAgZm9yIChjb25zdCBrZXkgaW4gX21lc3NhZ2UpIHtcbiAgICAgICAgICAgICAgICBpZiAoaGFzT3duKF9tZXNzYWdlLCBrZXkpKSB7XG4gICAgICAgICAgICAgICAgICAgIGhhbmRsZUZsYXRKc29uKF9tZXNzYWdlW2tleV0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBtZXNzYWdlID0gX21lc3NhZ2VbbG9jYWxlXTtcbiAgICAgICAgZGVlcENvcHkobWVzc2FnZSwgX21lc3NhZ2VzLnZhbHVlW2xvY2FsZV0pO1xuICAgICAgICBfY29udGV4dC5tZXNzYWdlcyA9IF9tZXNzYWdlcy52YWx1ZTtcbiAgICB9XG4gICAgLy8gZ2V0RGF0ZVRpbWVGb3JtYXRcbiAgICBmdW5jdGlvbiBnZXREYXRlVGltZUZvcm1hdChsb2NhbGUpIHtcbiAgICAgICAgcmV0dXJuIF9kYXRldGltZUZvcm1hdHMudmFsdWVbbG9jYWxlXSB8fCB7fTtcbiAgICB9XG4gICAgLy8gc2V0RGF0ZVRpbWVGb3JtYXRcbiAgICBmdW5jdGlvbiBzZXREYXRlVGltZUZvcm1hdChsb2NhbGUsIGZvcm1hdCkge1xuICAgICAgICBfZGF0ZXRpbWVGb3JtYXRzLnZhbHVlW2xvY2FsZV0gPSBmb3JtYXQ7XG4gICAgICAgIF9jb250ZXh0LmRhdGV0aW1lRm9ybWF0cyA9IF9kYXRldGltZUZvcm1hdHMudmFsdWU7XG4gICAgICAgIGNsZWFyRGF0ZVRpbWVGb3JtYXQoX2NvbnRleHQsIGxvY2FsZSwgZm9ybWF0KTtcbiAgICB9XG4gICAgLy8gbWVyZ2VEYXRlVGltZUZvcm1hdFxuICAgIGZ1bmN0aW9uIG1lcmdlRGF0ZVRpbWVGb3JtYXQobG9jYWxlLCBmb3JtYXQpIHtcbiAgICAgICAgX2RhdGV0aW1lRm9ybWF0cy52YWx1ZVtsb2NhbGVdID0gYXNzaWduKF9kYXRldGltZUZvcm1hdHMudmFsdWVbbG9jYWxlXSB8fCB7fSwgZm9ybWF0KTtcbiAgICAgICAgX2NvbnRleHQuZGF0ZXRpbWVGb3JtYXRzID0gX2RhdGV0aW1lRm9ybWF0cy52YWx1ZTtcbiAgICAgICAgY2xlYXJEYXRlVGltZUZvcm1hdChfY29udGV4dCwgbG9jYWxlLCBmb3JtYXQpO1xuICAgIH1cbiAgICAvLyBnZXROdW1iZXJGb3JtYXRcbiAgICBmdW5jdGlvbiBnZXROdW1iZXJGb3JtYXQobG9jYWxlKSB7XG4gICAgICAgIHJldHVybiBfbnVtYmVyRm9ybWF0cy52YWx1ZVtsb2NhbGVdIHx8IHt9O1xuICAgIH1cbiAgICAvLyBzZXROdW1iZXJGb3JtYXRcbiAgICBmdW5jdGlvbiBzZXROdW1iZXJGb3JtYXQobG9jYWxlLCBmb3JtYXQpIHtcbiAgICAgICAgX251bWJlckZvcm1hdHMudmFsdWVbbG9jYWxlXSA9IGZvcm1hdDtcbiAgICAgICAgX2NvbnRleHQubnVtYmVyRm9ybWF0cyA9IF9udW1iZXJGb3JtYXRzLnZhbHVlO1xuICAgICAgICBjbGVhck51bWJlckZvcm1hdChfY29udGV4dCwgbG9jYWxlLCBmb3JtYXQpO1xuICAgIH1cbiAgICAvLyBtZXJnZU51bWJlckZvcm1hdFxuICAgIGZ1bmN0aW9uIG1lcmdlTnVtYmVyRm9ybWF0KGxvY2FsZSwgZm9ybWF0KSB7XG4gICAgICAgIF9udW1iZXJGb3JtYXRzLnZhbHVlW2xvY2FsZV0gPSBhc3NpZ24oX251bWJlckZvcm1hdHMudmFsdWVbbG9jYWxlXSB8fCB7fSwgZm9ybWF0KTtcbiAgICAgICAgX2NvbnRleHQubnVtYmVyRm9ybWF0cyA9IF9udW1iZXJGb3JtYXRzLnZhbHVlO1xuICAgICAgICBjbGVhck51bWJlckZvcm1hdChfY29udGV4dCwgbG9jYWxlLCBmb3JtYXQpO1xuICAgIH1cbiAgICAvLyBmb3IgZGVidWdcbiAgICBjb21wb3NlcklEKys7XG4gICAgLy8gd2F0Y2ggcm9vdCBsb2NhbGUgJiBmYWxsYmFja0xvY2FsZVxuICAgIGlmIChfX3Jvb3QgJiYgaW5Ccm93c2VyKSB7XG4gICAgICAgIHdhdGNoKF9fcm9vdC5sb2NhbGUsICh2YWwpID0+IHtcbiAgICAgICAgICAgIGlmIChfaW5oZXJpdExvY2FsZSkge1xuICAgICAgICAgICAgICAgIF9sb2NhbGUudmFsdWUgPSB2YWw7XG4gICAgICAgICAgICAgICAgX2NvbnRleHQubG9jYWxlID0gdmFsO1xuICAgICAgICAgICAgICAgIHVwZGF0ZUZhbGxiYWNrTG9jYWxlKF9jb250ZXh0LCBfbG9jYWxlLnZhbHVlLCBfZmFsbGJhY2tMb2NhbGUudmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgd2F0Y2goX19yb290LmZhbGxiYWNrTG9jYWxlLCAodmFsKSA9PiB7XG4gICAgICAgICAgICBpZiAoX2luaGVyaXRMb2NhbGUpIHtcbiAgICAgICAgICAgICAgICBfZmFsbGJhY2tMb2NhbGUudmFsdWUgPSB2YWw7XG4gICAgICAgICAgICAgICAgX2NvbnRleHQuZmFsbGJhY2tMb2NhbGUgPSB2YWw7XG4gICAgICAgICAgICAgICAgdXBkYXRlRmFsbGJhY2tMb2NhbGUoX2NvbnRleHQsIF9sb2NhbGUudmFsdWUsIF9mYWxsYmFja0xvY2FsZS52YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvLyBkZWZpbmUgYmFzaWMgY29tcG9zaXRpb24gQVBJIVxuICAgIGNvbnN0IGNvbXBvc2VyID0ge1xuICAgICAgICBpZDogY29tcG9zZXJJRCxcbiAgICAgICAgbG9jYWxlLFxuICAgICAgICBmYWxsYmFja0xvY2FsZSxcbiAgICAgICAgZ2V0IGluaGVyaXRMb2NhbGUoKSB7XG4gICAgICAgICAgICByZXR1cm4gX2luaGVyaXRMb2NhbGU7XG4gICAgICAgIH0sXG4gICAgICAgIHNldCBpbmhlcml0TG9jYWxlKHZhbCkge1xuICAgICAgICAgICAgX2luaGVyaXRMb2NhbGUgPSB2YWw7XG4gICAgICAgICAgICBpZiAodmFsICYmIF9fcm9vdCkge1xuICAgICAgICAgICAgICAgIF9sb2NhbGUudmFsdWUgPSBfX3Jvb3QubG9jYWxlLnZhbHVlO1xuICAgICAgICAgICAgICAgIF9mYWxsYmFja0xvY2FsZS52YWx1ZSA9IF9fcm9vdC5mYWxsYmFja0xvY2FsZS52YWx1ZTtcbiAgICAgICAgICAgICAgICB1cGRhdGVGYWxsYmFja0xvY2FsZShfY29udGV4dCwgX2xvY2FsZS52YWx1ZSwgX2ZhbGxiYWNrTG9jYWxlLnZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgZ2V0IGF2YWlsYWJsZUxvY2FsZXMoKSB7XG4gICAgICAgICAgICByZXR1cm4gT2JqZWN0LmtleXMoX21lc3NhZ2VzLnZhbHVlKS5zb3J0KCk7XG4gICAgICAgIH0sXG4gICAgICAgIG1lc3NhZ2VzLFxuICAgICAgICBnZXQgbW9kaWZpZXJzKCkge1xuICAgICAgICAgICAgcmV0dXJuIF9tb2RpZmllcnM7XG4gICAgICAgIH0sXG4gICAgICAgIGdldCBwbHVyYWxSdWxlcygpIHtcbiAgICAgICAgICAgIHJldHVybiBfcGx1cmFsUnVsZXMgfHwge307XG4gICAgICAgIH0sXG4gICAgICAgIGdldCBpc0dsb2JhbCgpIHtcbiAgICAgICAgICAgIHJldHVybiBfaXNHbG9iYWw7XG4gICAgICAgIH0sXG4gICAgICAgIGdldCBtaXNzaW5nV2FybigpIHtcbiAgICAgICAgICAgIHJldHVybiBfbWlzc2luZ1dhcm47XG4gICAgICAgIH0sXG4gICAgICAgIHNldCBtaXNzaW5nV2Fybih2YWwpIHtcbiAgICAgICAgICAgIF9taXNzaW5nV2FybiA9IHZhbDtcbiAgICAgICAgICAgIF9jb250ZXh0Lm1pc3NpbmdXYXJuID0gX21pc3NpbmdXYXJuO1xuICAgICAgICB9LFxuICAgICAgICBnZXQgZmFsbGJhY2tXYXJuKCkge1xuICAgICAgICAgICAgcmV0dXJuIF9mYWxsYmFja1dhcm47XG4gICAgICAgIH0sXG4gICAgICAgIHNldCBmYWxsYmFja1dhcm4odmFsKSB7XG4gICAgICAgICAgICBfZmFsbGJhY2tXYXJuID0gdmFsO1xuICAgICAgICAgICAgX2NvbnRleHQuZmFsbGJhY2tXYXJuID0gX2ZhbGxiYWNrV2FybjtcbiAgICAgICAgfSxcbiAgICAgICAgZ2V0IGZhbGxiYWNrUm9vdCgpIHtcbiAgICAgICAgICAgIHJldHVybiBfZmFsbGJhY2tSb290O1xuICAgICAgICB9LFxuICAgICAgICBzZXQgZmFsbGJhY2tSb290KHZhbCkge1xuICAgICAgICAgICAgX2ZhbGxiYWNrUm9vdCA9IHZhbDtcbiAgICAgICAgfSxcbiAgICAgICAgZ2V0IGZhbGxiYWNrRm9ybWF0KCkge1xuICAgICAgICAgICAgcmV0dXJuIF9mYWxsYmFja0Zvcm1hdDtcbiAgICAgICAgfSxcbiAgICAgICAgc2V0IGZhbGxiYWNrRm9ybWF0KHZhbCkge1xuICAgICAgICAgICAgX2ZhbGxiYWNrRm9ybWF0ID0gdmFsO1xuICAgICAgICAgICAgX2NvbnRleHQuZmFsbGJhY2tGb3JtYXQgPSBfZmFsbGJhY2tGb3JtYXQ7XG4gICAgICAgIH0sXG4gICAgICAgIGdldCB3YXJuSHRtbE1lc3NhZ2UoKSB7XG4gICAgICAgICAgICByZXR1cm4gX3dhcm5IdG1sTWVzc2FnZTtcbiAgICAgICAgfSxcbiAgICAgICAgc2V0IHdhcm5IdG1sTWVzc2FnZSh2YWwpIHtcbiAgICAgICAgICAgIF93YXJuSHRtbE1lc3NhZ2UgPSB2YWw7XG4gICAgICAgICAgICBfY29udGV4dC53YXJuSHRtbE1lc3NhZ2UgPSB2YWw7XG4gICAgICAgIH0sXG4gICAgICAgIGdldCBlc2NhcGVQYXJhbWV0ZXIoKSB7XG4gICAgICAgICAgICByZXR1cm4gX2VzY2FwZVBhcmFtZXRlcjtcbiAgICAgICAgfSxcbiAgICAgICAgc2V0IGVzY2FwZVBhcmFtZXRlcih2YWwpIHtcbiAgICAgICAgICAgIF9lc2NhcGVQYXJhbWV0ZXIgPSB2YWw7XG4gICAgICAgICAgICBfY29udGV4dC5lc2NhcGVQYXJhbWV0ZXIgPSB2YWw7XG4gICAgICAgIH0sXG4gICAgICAgIHQsXG4gICAgICAgIGdldExvY2FsZU1lc3NhZ2UsXG4gICAgICAgIHNldExvY2FsZU1lc3NhZ2UsXG4gICAgICAgIG1lcmdlTG9jYWxlTWVzc2FnZSxcbiAgICAgICAgZ2V0UG9zdFRyYW5zbGF0aW9uSGFuZGxlcixcbiAgICAgICAgc2V0UG9zdFRyYW5zbGF0aW9uSGFuZGxlcixcbiAgICAgICAgZ2V0TWlzc2luZ0hhbmRsZXIsXG4gICAgICAgIHNldE1pc3NpbmdIYW5kbGVyLFxuICAgICAgICBbU2V0UGx1cmFsUnVsZXNTeW1ib2xdOiBzZXRQbHVyYWxSdWxlc1xuICAgIH07XG4gICAge1xuICAgICAgICBjb21wb3Nlci5kYXRldGltZUZvcm1hdHMgPSBkYXRldGltZUZvcm1hdHM7XG4gICAgICAgIGNvbXBvc2VyLm51bWJlckZvcm1hdHMgPSBudW1iZXJGb3JtYXRzO1xuICAgICAgICBjb21wb3Nlci5ydCA9IHJ0O1xuICAgICAgICBjb21wb3Nlci50ZSA9IHRlO1xuICAgICAgICBjb21wb3Nlci50bSA9IHRtO1xuICAgICAgICBjb21wb3Nlci5kID0gZDtcbiAgICAgICAgY29tcG9zZXIubiA9IG47XG4gICAgICAgIGNvbXBvc2VyLmdldERhdGVUaW1lRm9ybWF0ID0gZ2V0RGF0ZVRpbWVGb3JtYXQ7XG4gICAgICAgIGNvbXBvc2VyLnNldERhdGVUaW1lRm9ybWF0ID0gc2V0RGF0ZVRpbWVGb3JtYXQ7XG4gICAgICAgIGNvbXBvc2VyLm1lcmdlRGF0ZVRpbWVGb3JtYXQgPSBtZXJnZURhdGVUaW1lRm9ybWF0O1xuICAgICAgICBjb21wb3Nlci5nZXROdW1iZXJGb3JtYXQgPSBnZXROdW1iZXJGb3JtYXQ7XG4gICAgICAgIGNvbXBvc2VyLnNldE51bWJlckZvcm1hdCA9IHNldE51bWJlckZvcm1hdDtcbiAgICAgICAgY29tcG9zZXIubWVyZ2VOdW1iZXJGb3JtYXQgPSBtZXJnZU51bWJlckZvcm1hdDtcbiAgICAgICAgY29tcG9zZXJbSW5lamN0V2l0aE9wdGlvblN5bWJvbF0gPSBfX2luamVjdFdpdGhPcHRpb247XG4gICAgICAgIGNvbXBvc2VyW1RyYW5zbGF0ZVZOb2RlU3ltYm9sXSA9IHRyYW5zbGF0ZVZOb2RlO1xuICAgICAgICBjb21wb3NlcltEYXRldGltZVBhcnRzU3ltYm9sXSA9IGRhdGV0aW1lUGFydHM7XG4gICAgICAgIGNvbXBvc2VyW051bWJlclBhcnRzU3ltYm9sXSA9IG51bWJlclBhcnRzO1xuICAgIH1cbiAgICAvLyBmb3IgdnVlLWRldnRvb2xzIHRpbWVsaW5lIGV2ZW50XG4gICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSkge1xuICAgICAgICBjb21wb3NlcltFbmFibGVFbWl0dGVyXSA9IChlbWl0dGVyKSA9PiB7XG4gICAgICAgICAgICBfY29udGV4dC5fX3ZfZW1pdHRlciA9IGVtaXR0ZXI7XG4gICAgICAgIH07XG4gICAgICAgIGNvbXBvc2VyW0Rpc2FibGVFbWl0dGVyXSA9ICgpID0+IHtcbiAgICAgICAgICAgIF9jb250ZXh0Ll9fdl9lbWl0dGVyID0gdW5kZWZpbmVkO1xuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gY29tcG9zZXI7XG59XG4vKiBlc2xpbnQtZW5hYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cblxuY29uc3QgVlVFX0kxOE5fQ09NUE9ORU5UX1RZUEVTID0gJ3Z1ZS1pMThuOiBjb21wb3NlciBwcm9wZXJ0aWVzJztcbmNvbnN0IFZ1ZURldlRvb2xzTGFiZWxzID0ge1xuICAgICd2dWUtZGV2dG9vbHMtcGx1Z2luLXZ1ZS1pMThuJzogJ1Z1ZSBJMThuIERldlRvb2xzJyxcbiAgICAndnVlLWkxOG4tcmVzb3VyY2UtaW5zcGVjdG9yJzogJ1Z1ZSBJMThuIERldlRvb2xzJyxcbiAgICAndnVlLWkxOG4tdGltZWxpbmUnOiAnVnVlIEkxOG4nXG59O1xuY29uc3QgVnVlRGV2VG9vbHNQbGFjZWhvbGRlcnMgPSB7XG4gICAgJ3Z1ZS1pMThuLXJlc291cmNlLWluc3BlY3Rvcic6ICdTZWFyY2ggZm9yIHNjb3BlcyAuLi4nXG59O1xuY29uc3QgVnVlRGV2VG9vbHNUaW1lbGluZUNvbG9ycyA9IHtcbiAgICAndnVlLWkxOG4tdGltZWxpbmUnOiAweGZmY2QxOVxufTtcbmxldCBkZXZ0b29sc0FwaTtcbmFzeW5jIGZ1bmN0aW9uIGVuYWJsZURldlRvb2xzKGFwcCwgaTE4bikge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBzZXR1cERldnRvb2xzUGx1Z2luKHtcbiAgICAgICAgICAgICAgICBpZDogJ3Z1ZS1kZXZ0b29scy1wbHVnaW4tdnVlLWkxOG4nLFxuICAgICAgICAgICAgICAgIGxhYmVsOiBWdWVEZXZUb29sc0xhYmVsc1sndnVlLWRldnRvb2xzLXBsdWdpbi12dWUtaTE4biddLFxuICAgICAgICAgICAgICAgIHBhY2thZ2VOYW1lOiAndnVlLWkxOG4nLFxuICAgICAgICAgICAgICAgIGhvbWVwYWdlOiAnaHR0cHM6Ly92dWUtaTE4bi5pbnRsaWZ5LmRldicsXG4gICAgICAgICAgICAgICAgbG9nbzogJ2h0dHBzOi8vdnVlLWkxOG4uaW50bGlmeS5kZXYvdnVlLWkxOG4tZGV2dG9vbHMtbG9nby5wbmcnLFxuICAgICAgICAgICAgICAgIGNvbXBvbmVudFN0YXRlVHlwZXM6IFtWVUVfSTE4Tl9DT01QT05FTlRfVFlQRVNdLFxuICAgICAgICAgICAgICAgIGFwcDogYXBwIC8vIGVzbGludC1kaXNhYmxlLWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgICAgICAgICAgfSwgYXBpID0+IHtcbiAgICAgICAgICAgICAgICBkZXZ0b29sc0FwaSA9IGFwaTtcbiAgICAgICAgICAgICAgICBhcGkub24udmlzaXRDb21wb25lbnRUcmVlKCh7IGNvbXBvbmVudEluc3RhbmNlLCB0cmVlTm9kZSB9KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZUNvbXBvbmVudFRyZWVUYWdzKGNvbXBvbmVudEluc3RhbmNlLCB0cmVlTm9kZSwgaTE4bik7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgYXBpLm9uLmluc3BlY3RDb21wb25lbnQoKHsgY29tcG9uZW50SW5zdGFuY2UsIGluc3RhbmNlRGF0YSB9KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb21wb25lbnRJbnN0YW5jZS5fX1ZVRV9JMThOX18gJiYgaW5zdGFuY2VEYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaTE4bi5tb2RlID09PSAnbGVnYWN5Jykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIGlnbm9yZSBnbG9iYWwgc2NvcGUgb24gbGVnYWN5IG1vZGVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoY29tcG9uZW50SW5zdGFuY2UuX19WVUVfSTE4Tl9fICE9PVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpMThuLmdsb2JhbC5fX2NvbXBvc2VyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluc3BlY3RDb21wb3NlcihpbnN0YW5jZURhdGEsIGNvbXBvbmVudEluc3RhbmNlLl9fVlVFX0kxOE5fXyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5zcGVjdENvbXBvc2VyKGluc3RhbmNlRGF0YSwgY29tcG9uZW50SW5zdGFuY2UuX19WVUVfSTE4Tl9fKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGFwaS5hZGRJbnNwZWN0b3Ioe1xuICAgICAgICAgICAgICAgICAgICBpZDogJ3Z1ZS1pMThuLXJlc291cmNlLWluc3BlY3RvcicsXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsOiBWdWVEZXZUb29sc0xhYmVsc1sndnVlLWkxOG4tcmVzb3VyY2UtaW5zcGVjdG9yJ10sXG4gICAgICAgICAgICAgICAgICAgIGljb246ICdsYW5ndWFnZScsXG4gICAgICAgICAgICAgICAgICAgIHRyZWVGaWx0ZXJQbGFjZWhvbGRlcjogVnVlRGV2VG9vbHNQbGFjZWhvbGRlcnNbJ3Z1ZS1pMThuLXJlc291cmNlLWluc3BlY3RvciddXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgYXBpLm9uLmdldEluc3BlY3RvclRyZWUocGF5bG9hZCA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChwYXlsb2FkLmFwcCA9PT0gYXBwICYmXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXlsb2FkLmluc3BlY3RvcklkID09PSAndnVlLWkxOG4tcmVzb3VyY2UtaW5zcGVjdG9yJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVnaXN0ZXJTY29wZShwYXlsb2FkLCBpMThuKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIGNvbnN0IHJvb3RzID0gbmV3IE1hcCgpO1xuICAgICAgICAgICAgICAgIGFwaS5vbi5nZXRJbnNwZWN0b3JTdGF0ZShhc3luYyAocGF5bG9hZCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAocGF5bG9hZC5hcHAgPT09IGFwcCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgcGF5bG9hZC5pbnNwZWN0b3JJZCA9PT0gJ3Z1ZS1pMThuLXJlc291cmNlLWluc3BlY3RvcicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGFwaS51bmhpZ2hsaWdodEVsZW1lbnQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGluc3BlY3RTY29wZShwYXlsb2FkLCBpMThuKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChwYXlsb2FkLm5vZGVJZCA9PT0gJ2dsb2JhbCcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXJvb3RzLmhhcyhwYXlsb2FkLmFwcCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgW3Jvb3RdID0gYXdhaXQgYXBpLmdldENvbXBvbmVudEluc3RhbmNlcyhwYXlsb2FkLmFwcCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvb3RzLnNldChwYXlsb2FkLmFwcCwgcm9vdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFwaS5oaWdobGlnaHRFbGVtZW50KHJvb3RzLmdldChwYXlsb2FkLmFwcCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaW5zdGFuY2UgPSBnZXRDb21wb25lbnRJbnN0YW5jZShwYXlsb2FkLm5vZGVJZCwgaTE4bik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5zdGFuY2UgJiYgYXBpLmhpZ2hsaWdodEVsZW1lbnQoaW5zdGFuY2UpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgYXBpLm9uLmVkaXRJbnNwZWN0b3JTdGF0ZShwYXlsb2FkID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBheWxvYWQuYXBwID09PSBhcHAgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIHBheWxvYWQuaW5zcGVjdG9ySWQgPT09ICd2dWUtaTE4bi1yZXNvdXJjZS1pbnNwZWN0b3InKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBlZGl0U2NvcGUocGF5bG9hZCwgaTE4bik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBhcGkuYWRkVGltZWxpbmVMYXllcih7XG4gICAgICAgICAgICAgICAgICAgIGlkOiAndnVlLWkxOG4tdGltZWxpbmUnLFxuICAgICAgICAgICAgICAgICAgICBsYWJlbDogVnVlRGV2VG9vbHNMYWJlbHNbJ3Z1ZS1pMThuLXRpbWVsaW5lJ10sXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiBWdWVEZXZUb29sc1RpbWVsaW5lQ29sb3JzWyd2dWUtaTE4bi10aW1lbGluZSddXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZSh0cnVlKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9wcmVmZXItcHJvbWlzZS1yZWplY3QtZXJyb3JzXG4gICAgICAgICAgICByZWplY3QoZmFsc2UpO1xuICAgICAgICB9XG4gICAgfSk7XG59XG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuZnVuY3Rpb24gZ2V0STE4blNjb3BlTGFibGUoaW5zdGFuY2UpIHtcbiAgICByZXR1cm4gKGluc3RhbmNlLnR5cGUubmFtZSB8fFxuICAgICAgICBpbnN0YW5jZS50eXBlLmRpc3BsYXlOYW1lIHx8XG4gICAgICAgIGluc3RhbmNlLnR5cGUuX19maWxlIHx8XG4gICAgICAgICdBbm9ueW1vdXMnKTtcbn1cbmZ1bmN0aW9uIHVwZGF0ZUNvbXBvbmVudFRyZWVUYWdzKGluc3RhbmNlLCAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbnRyZWVOb2RlLCBpMThuKSB7XG4gICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgY29uc3QgZ2xvYmFsID0gaTE4bi5tb2RlID09PSAnY29tcG9zaXRpb24nXG4gICAgICAgID8gaTE4bi5nbG9iYWxcbiAgICAgICAgOiBpMThuLmdsb2JhbC5fX2NvbXBvc2VyO1xuICAgIGlmIChpbnN0YW5jZSAmJiBpbnN0YW5jZS5fX1ZVRV9JMThOX18pIHtcbiAgICAgICAgLy8gYWRkIGN1c3RvbSB0YWdzIGxvY2FsIHNjb3BlIG9ubHlcbiAgICAgICAgaWYgKGluc3RhbmNlLl9fVlVFX0kxOE5fXyAhPT0gZ2xvYmFsKSB7XG4gICAgICAgICAgICBjb25zdCB0YWcgPSB7XG4gICAgICAgICAgICAgICAgbGFiZWw6IGBpMThuICgke2dldEkxOG5TY29wZUxhYmxlKGluc3RhbmNlKX0gU2NvcGUpYCxcbiAgICAgICAgICAgICAgICB0ZXh0Q29sb3I6IDB4MDAwMDAwLFxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogMHhmZmNkMTlcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB0cmVlTm9kZS50YWdzLnB1c2godGFnKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbmZ1bmN0aW9uIGluc3BlY3RDb21wb3NlcihpbnN0YW5jZURhdGEsIGNvbXBvc2VyKSB7XG4gICAgY29uc3QgdHlwZSA9IFZVRV9JMThOX0NPTVBPTkVOVF9UWVBFUztcbiAgICBpbnN0YW5jZURhdGEuc3RhdGUucHVzaCh7XG4gICAgICAgIHR5cGUsXG4gICAgICAgIGtleTogJ2xvY2FsZScsXG4gICAgICAgIGVkaXRhYmxlOiB0cnVlLFxuICAgICAgICB2YWx1ZTogY29tcG9zZXIubG9jYWxlLnZhbHVlXG4gICAgfSk7XG4gICAgaW5zdGFuY2VEYXRhLnN0YXRlLnB1c2goe1xuICAgICAgICB0eXBlLFxuICAgICAgICBrZXk6ICdhdmFpbGFibGVMb2NhbGVzJyxcbiAgICAgICAgZWRpdGFibGU6IGZhbHNlLFxuICAgICAgICB2YWx1ZTogY29tcG9zZXIuYXZhaWxhYmxlTG9jYWxlc1xuICAgIH0pO1xuICAgIGluc3RhbmNlRGF0YS5zdGF0ZS5wdXNoKHtcbiAgICAgICAgdHlwZSxcbiAgICAgICAga2V5OiAnZmFsbGJhY2tMb2NhbGUnLFxuICAgICAgICBlZGl0YWJsZTogdHJ1ZSxcbiAgICAgICAgdmFsdWU6IGNvbXBvc2VyLmZhbGxiYWNrTG9jYWxlLnZhbHVlXG4gICAgfSk7XG4gICAgaW5zdGFuY2VEYXRhLnN0YXRlLnB1c2goe1xuICAgICAgICB0eXBlLFxuICAgICAgICBrZXk6ICdpbmhlcml0TG9jYWxlJyxcbiAgICAgICAgZWRpdGFibGU6IHRydWUsXG4gICAgICAgIHZhbHVlOiBjb21wb3Nlci5pbmhlcml0TG9jYWxlXG4gICAgfSk7XG4gICAgaW5zdGFuY2VEYXRhLnN0YXRlLnB1c2goe1xuICAgICAgICB0eXBlLFxuICAgICAgICBrZXk6ICdtZXNzYWdlcycsXG4gICAgICAgIGVkaXRhYmxlOiBmYWxzZSxcbiAgICAgICAgdmFsdWU6IGdldExvY2FsZU1lc3NhZ2VWYWx1ZShjb21wb3Nlci5tZXNzYWdlcy52YWx1ZSlcbiAgICB9KTtcbiAgICB7XG4gICAgICAgIGluc3RhbmNlRGF0YS5zdGF0ZS5wdXNoKHtcbiAgICAgICAgICAgIHR5cGUsXG4gICAgICAgICAgICBrZXk6ICdkYXRldGltZUZvcm1hdHMnLFxuICAgICAgICAgICAgZWRpdGFibGU6IGZhbHNlLFxuICAgICAgICAgICAgdmFsdWU6IGNvbXBvc2VyLmRhdGV0aW1lRm9ybWF0cy52YWx1ZVxuICAgICAgICB9KTtcbiAgICAgICAgaW5zdGFuY2VEYXRhLnN0YXRlLnB1c2goe1xuICAgICAgICAgICAgdHlwZSxcbiAgICAgICAgICAgIGtleTogJ251bWJlckZvcm1hdHMnLFxuICAgICAgICAgICAgZWRpdGFibGU6IGZhbHNlLFxuICAgICAgICAgICAgdmFsdWU6IGNvbXBvc2VyLm51bWJlckZvcm1hdHMudmFsdWVcbiAgICAgICAgfSk7XG4gICAgfVxufVxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbmZ1bmN0aW9uIGdldExvY2FsZU1lc3NhZ2VWYWx1ZShtZXNzYWdlcykge1xuICAgIGNvbnN0IHZhbHVlID0ge307XG4gICAgT2JqZWN0LmtleXMobWVzc2FnZXMpLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgICBjb25zdCB2ID0gbWVzc2FnZXNba2V5XTtcbiAgICAgICAgaWYgKGlzRnVuY3Rpb24odikgJiYgJ3NvdXJjZScgaW4gdikge1xuICAgICAgICAgICAgdmFsdWVba2V5XSA9IGdldE1lc3NhZ2VGdW5jdGlvbkRldGFpbHModik7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoaXNNZXNzYWdlQVNUKHYpICYmIHYubG9jICYmIHYubG9jLnNvdXJjZSkge1xuICAgICAgICAgICAgdmFsdWVba2V5XSA9IHYubG9jLnNvdXJjZTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChpc09iamVjdCh2KSkge1xuICAgICAgICAgICAgdmFsdWVba2V5XSA9IGdldExvY2FsZU1lc3NhZ2VWYWx1ZSh2KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHZhbHVlW2tleV0gPSB2O1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIHZhbHVlO1xufVxuY29uc3QgRVNDID0ge1xuICAgICc8JzogJyZsdDsnLFxuICAgICc+JzogJyZndDsnLFxuICAgICdcIic6ICcmcXVvdDsnLFxuICAgICcmJzogJyZhbXA7J1xufTtcbmZ1bmN0aW9uIGVzY2FwZShzKSB7XG4gICAgcmV0dXJuIHMucmVwbGFjZSgvWzw+XCImXS9nLCBlc2NhcGVDaGFyKTtcbn1cbmZ1bmN0aW9uIGVzY2FwZUNoYXIoYSkge1xuICAgIHJldHVybiBFU0NbYV0gfHwgYTtcbn1cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG5mdW5jdGlvbiBnZXRNZXNzYWdlRnVuY3Rpb25EZXRhaWxzKGZ1bmMpIHtcbiAgICBjb25zdCBhcmdTdHJpbmcgPSBmdW5jLnNvdXJjZSA/IGAoXCIke2VzY2FwZShmdW5jLnNvdXJjZSl9XCIpYCA6IGAoPylgO1xuICAgIHJldHVybiB7XG4gICAgICAgIF9jdXN0b206IHtcbiAgICAgICAgICAgIHR5cGU6ICdmdW5jdGlvbicsXG4gICAgICAgICAgICBkaXNwbGF5OiBgPHNwYW4+xpI8L3NwYW4+ICR7YXJnU3RyaW5nfWBcbiAgICAgICAgfVxuICAgIH07XG59XG5mdW5jdGlvbiByZWdpc3RlclNjb3BlKHBheWxvYWQsIGkxOG4pIHtcbiAgICBwYXlsb2FkLnJvb3ROb2Rlcy5wdXNoKHtcbiAgICAgICAgaWQ6ICdnbG9iYWwnLFxuICAgICAgICBsYWJlbDogJ0dsb2JhbCBTY29wZSdcbiAgICB9KTtcbiAgICAvLyBwcmV0dGllci1pZ25vcmVcbiAgICBjb25zdCBnbG9iYWwgPSBpMThuLm1vZGUgPT09ICdjb21wb3NpdGlvbidcbiAgICAgICAgPyBpMThuLmdsb2JhbFxuICAgICAgICA6IGkxOG4uZ2xvYmFsLl9fY29tcG9zZXI7XG4gICAgZm9yIChjb25zdCBba2V5SW5zdGFuY2UsIGluc3RhbmNlXSBvZiBpMThuLl9faW5zdGFuY2VzKSB7XG4gICAgICAgIC8vIHByZXR0aWVyLWlnbm9yZVxuICAgICAgICBjb25zdCBjb21wb3NlciA9IGkxOG4ubW9kZSA9PT0gJ2NvbXBvc2l0aW9uJ1xuICAgICAgICAgICAgPyBpbnN0YW5jZVxuICAgICAgICAgICAgOiBpbnN0YW5jZS5fX2NvbXBvc2VyO1xuICAgICAgICBpZiAoZ2xvYmFsID09PSBjb21wb3Nlcikge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgcGF5bG9hZC5yb290Tm9kZXMucHVzaCh7XG4gICAgICAgICAgICBpZDogY29tcG9zZXIuaWQudG9TdHJpbmcoKSxcbiAgICAgICAgICAgIGxhYmVsOiBgJHtnZXRJMThuU2NvcGVMYWJsZShrZXlJbnN0YW5jZSl9IFNjb3BlYFxuICAgICAgICB9KTtcbiAgICB9XG59XG5mdW5jdGlvbiBnZXRDb21wb25lbnRJbnN0YW5jZShub2RlSWQsIGkxOG4pIHtcbiAgICBsZXQgaW5zdGFuY2UgPSBudWxsO1xuICAgIGlmIChub2RlSWQgIT09ICdnbG9iYWwnKSB7XG4gICAgICAgIGZvciAoY29uc3QgW2NvbXBvbmVudCwgY29tcG9zZXJdIG9mIGkxOG4uX19pbnN0YW5jZXMuZW50cmllcygpKSB7XG4gICAgICAgICAgICBpZiAoY29tcG9zZXIuaWQudG9TdHJpbmcoKSA9PT0gbm9kZUlkKSB7XG4gICAgICAgICAgICAgICAgaW5zdGFuY2UgPSBjb21wb25lbnQ7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGluc3RhbmNlO1xufVxuZnVuY3Rpb24gZ2V0Q29tcG9zZXIkMihub2RlSWQsIGkxOG4pIHtcbiAgICBpZiAobm9kZUlkID09PSAnZ2xvYmFsJykge1xuICAgICAgICByZXR1cm4gaTE4bi5tb2RlID09PSAnY29tcG9zaXRpb24nXG4gICAgICAgICAgICA/IGkxOG4uZ2xvYmFsXG4gICAgICAgICAgICA6IGkxOG4uZ2xvYmFsLl9fY29tcG9zZXI7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBjb25zdCBpbnN0YW5jZSA9IEFycmF5LmZyb20oaTE4bi5fX2luc3RhbmNlcy52YWx1ZXMoKSkuZmluZChpdGVtID0+IGl0ZW0uaWQudG9TdHJpbmcoKSA9PT0gbm9kZUlkKTtcbiAgICAgICAgaWYgKGluc3RhbmNlKSB7XG4gICAgICAgICAgICByZXR1cm4gaTE4bi5tb2RlID09PSAnY29tcG9zaXRpb24nXG4gICAgICAgICAgICAgICAgPyBpbnN0YW5jZVxuICAgICAgICAgICAgICAgIDogaW5zdGFuY2UuX19jb21wb3NlcjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgfVxufVxuZnVuY3Rpb24gaW5zcGVjdFNjb3BlKHBheWxvYWQsIGkxOG5cbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4pIHtcbiAgICBjb25zdCBjb21wb3NlciA9IGdldENvbXBvc2VyJDIocGF5bG9hZC5ub2RlSWQsIGkxOG4pO1xuICAgIGlmIChjb21wb3Nlcikge1xuICAgICAgICAvLyBUT0RPOlxuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgICAgICBwYXlsb2FkLnN0YXRlID0gbWFrZVNjb3BlSW5zcGVjdFN0YXRlKGNvbXBvc2VyKTtcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiBtYWtlU2NvcGVJbnNwZWN0U3RhdGUoY29tcG9zZXIpIHtcbiAgICBjb25zdCBzdGF0ZSA9IHt9O1xuICAgIGNvbnN0IGxvY2FsZVR5cGUgPSAnTG9jYWxlIHJlbGF0ZWQgaW5mbyc7XG4gICAgY29uc3QgbG9jYWxlU3RhdGVzID0gW1xuICAgICAgICB7XG4gICAgICAgICAgICB0eXBlOiBsb2NhbGVUeXBlLFxuICAgICAgICAgICAga2V5OiAnbG9jYWxlJyxcbiAgICAgICAgICAgIGVkaXRhYmxlOiB0cnVlLFxuICAgICAgICAgICAgdmFsdWU6IGNvbXBvc2VyLmxvY2FsZS52YWx1ZVxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgICB0eXBlOiBsb2NhbGVUeXBlLFxuICAgICAgICAgICAga2V5OiAnZmFsbGJhY2tMb2NhbGUnLFxuICAgICAgICAgICAgZWRpdGFibGU6IHRydWUsXG4gICAgICAgICAgICB2YWx1ZTogY29tcG9zZXIuZmFsbGJhY2tMb2NhbGUudmFsdWVcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgICAgdHlwZTogbG9jYWxlVHlwZSxcbiAgICAgICAgICAgIGtleTogJ2F2YWlsYWJsZUxvY2FsZXMnLFxuICAgICAgICAgICAgZWRpdGFibGU6IGZhbHNlLFxuICAgICAgICAgICAgdmFsdWU6IGNvbXBvc2VyLmF2YWlsYWJsZUxvY2FsZXNcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgICAgdHlwZTogbG9jYWxlVHlwZSxcbiAgICAgICAgICAgIGtleTogJ2luaGVyaXRMb2NhbGUnLFxuICAgICAgICAgICAgZWRpdGFibGU6IHRydWUsXG4gICAgICAgICAgICB2YWx1ZTogY29tcG9zZXIuaW5oZXJpdExvY2FsZVxuICAgICAgICB9XG4gICAgXTtcbiAgICBzdGF0ZVtsb2NhbGVUeXBlXSA9IGxvY2FsZVN0YXRlcztcbiAgICBjb25zdCBsb2NhbGVNZXNzYWdlc1R5cGUgPSAnTG9jYWxlIG1lc3NhZ2VzIGluZm8nO1xuICAgIGNvbnN0IGxvY2FsZU1lc3NhZ2VzU3RhdGVzID0gW1xuICAgICAgICB7XG4gICAgICAgICAgICB0eXBlOiBsb2NhbGVNZXNzYWdlc1R5cGUsXG4gICAgICAgICAgICBrZXk6ICdtZXNzYWdlcycsXG4gICAgICAgICAgICBlZGl0YWJsZTogZmFsc2UsXG4gICAgICAgICAgICB2YWx1ZTogZ2V0TG9jYWxlTWVzc2FnZVZhbHVlKGNvbXBvc2VyLm1lc3NhZ2VzLnZhbHVlKVxuICAgICAgICB9XG4gICAgXTtcbiAgICBzdGF0ZVtsb2NhbGVNZXNzYWdlc1R5cGVdID0gbG9jYWxlTWVzc2FnZXNTdGF0ZXM7XG4gICAge1xuICAgICAgICBjb25zdCBkYXRldGltZUZvcm1hdHNUeXBlID0gJ0RhdGV0aW1lIGZvcm1hdHMgaW5mbyc7XG4gICAgICAgIGNvbnN0IGRhdGV0aW1lRm9ybWF0c1N0YXRlcyA9IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0eXBlOiBkYXRldGltZUZvcm1hdHNUeXBlLFxuICAgICAgICAgICAgICAgIGtleTogJ2RhdGV0aW1lRm9ybWF0cycsXG4gICAgICAgICAgICAgICAgZWRpdGFibGU6IGZhbHNlLFxuICAgICAgICAgICAgICAgIHZhbHVlOiBjb21wb3Nlci5kYXRldGltZUZvcm1hdHMudmFsdWVcbiAgICAgICAgICAgIH1cbiAgICAgICAgXTtcbiAgICAgICAgc3RhdGVbZGF0ZXRpbWVGb3JtYXRzVHlwZV0gPSBkYXRldGltZUZvcm1hdHNTdGF0ZXM7XG4gICAgICAgIGNvbnN0IG51bWJlckZvcm1hdHNUeXBlID0gJ0RhdGV0aW1lIGZvcm1hdHMgaW5mbyc7XG4gICAgICAgIGNvbnN0IG51bWJlckZvcm1hdHNTdGF0ZXMgPSBbXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgdHlwZTogbnVtYmVyRm9ybWF0c1R5cGUsXG4gICAgICAgICAgICAgICAga2V5OiAnbnVtYmVyRm9ybWF0cycsXG4gICAgICAgICAgICAgICAgZWRpdGFibGU6IGZhbHNlLFxuICAgICAgICAgICAgICAgIHZhbHVlOiBjb21wb3Nlci5udW1iZXJGb3JtYXRzLnZhbHVlXG4gICAgICAgICAgICB9XG4gICAgICAgIF07XG4gICAgICAgIHN0YXRlW251bWJlckZvcm1hdHNUeXBlXSA9IG51bWJlckZvcm1hdHNTdGF0ZXM7XG4gICAgfVxuICAgIHJldHVybiBzdGF0ZTtcbn1cbmZ1bmN0aW9uIGFkZFRpbWVsaW5lRXZlbnQoZXZlbnQsIHBheWxvYWQpIHtcbiAgICBpZiAoZGV2dG9vbHNBcGkpIHtcbiAgICAgICAgbGV0IGdyb3VwSWQ7XG4gICAgICAgIGlmIChwYXlsb2FkICYmICdncm91cElkJyBpbiBwYXlsb2FkKSB7XG4gICAgICAgICAgICBncm91cElkID0gcGF5bG9hZC5ncm91cElkO1xuICAgICAgICAgICAgZGVsZXRlIHBheWxvYWQuZ3JvdXBJZDtcbiAgICAgICAgfVxuICAgICAgICBkZXZ0b29sc0FwaS5hZGRUaW1lbGluZUV2ZW50KHtcbiAgICAgICAgICAgIGxheWVySWQ6ICd2dWUtaTE4bi10aW1lbGluZScsXG4gICAgICAgICAgICBldmVudDoge1xuICAgICAgICAgICAgICAgIHRpdGxlOiBldmVudCxcbiAgICAgICAgICAgICAgICBncm91cElkLFxuICAgICAgICAgICAgICAgIHRpbWU6IERhdGUubm93KCksXG4gICAgICAgICAgICAgICAgbWV0YToge30sXG4gICAgICAgICAgICAgICAgZGF0YTogcGF5bG9hZCB8fCB7fSxcbiAgICAgICAgICAgICAgICBsb2dUeXBlOiBldmVudCA9PT0gJ2NvbXBpbGUtZXJyb3InXG4gICAgICAgICAgICAgICAgICAgID8gJ2Vycm9yJ1xuICAgICAgICAgICAgICAgICAgICA6IGV2ZW50ID09PSAnZmFsbGJhY2snIHx8IGV2ZW50ID09PSAnbWlzc2luZydcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ3dhcm5pbmcnXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdkZWZhdWx0J1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG59XG5mdW5jdGlvbiBlZGl0U2NvcGUocGF5bG9hZCwgaTE4bikge1xuICAgIGNvbnN0IGNvbXBvc2VyID0gZ2V0Q29tcG9zZXIkMihwYXlsb2FkLm5vZGVJZCwgaTE4bik7XG4gICAgaWYgKGNvbXBvc2VyKSB7XG4gICAgICAgIGNvbnN0IFtmaWVsZF0gPSBwYXlsb2FkLnBhdGg7XG4gICAgICAgIGlmIChmaWVsZCA9PT0gJ2xvY2FsZScgJiYgaXNTdHJpbmcocGF5bG9hZC5zdGF0ZS52YWx1ZSkpIHtcbiAgICAgICAgICAgIGNvbXBvc2VyLmxvY2FsZS52YWx1ZSA9IHBheWxvYWQuc3RhdGUudmFsdWU7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoZmllbGQgPT09ICdmYWxsYmFja0xvY2FsZScgJiZcbiAgICAgICAgICAgIChpc1N0cmluZyhwYXlsb2FkLnN0YXRlLnZhbHVlKSB8fFxuICAgICAgICAgICAgICAgIGlzQXJyYXkocGF5bG9hZC5zdGF0ZS52YWx1ZSkgfHxcbiAgICAgICAgICAgICAgICBpc09iamVjdChwYXlsb2FkLnN0YXRlLnZhbHVlKSkpIHtcbiAgICAgICAgICAgIGNvbXBvc2VyLmZhbGxiYWNrTG9jYWxlLnZhbHVlID0gcGF5bG9hZC5zdGF0ZS52YWx1ZTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChmaWVsZCA9PT0gJ2luaGVyaXRMb2NhbGUnICYmIGlzQm9vbGVhbihwYXlsb2FkLnN0YXRlLnZhbHVlKSkge1xuICAgICAgICAgICAgY29tcG9zZXIuaW5oZXJpdExvY2FsZSA9IHBheWxvYWQuc3RhdGUudmFsdWU7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbi8qKlxuICogQ29udmVydCB0byBJMThuIENvbXBvc2VyIE9wdGlvbnMgZnJvbSBWdWVJMThuIE9wdGlvbnNcbiAqXG4gKiBAaW50ZXJuYWxcbiAqL1xuZnVuY3Rpb24gY29udmVydENvbXBvc2VyT3B0aW9ucyhvcHRpb25zKSB7XG4gICAgY29uc3QgbG9jYWxlID0gaXNTdHJpbmcob3B0aW9ucy5sb2NhbGUpID8gb3B0aW9ucy5sb2NhbGUgOiBERUZBVUxUX0xPQ0FMRTtcbiAgICBjb25zdCBmYWxsYmFja0xvY2FsZSA9IGlzU3RyaW5nKG9wdGlvbnMuZmFsbGJhY2tMb2NhbGUpIHx8XG4gICAgICAgIGlzQXJyYXkob3B0aW9ucy5mYWxsYmFja0xvY2FsZSkgfHxcbiAgICAgICAgaXNQbGFpbk9iamVjdChvcHRpb25zLmZhbGxiYWNrTG9jYWxlKSB8fFxuICAgICAgICBvcHRpb25zLmZhbGxiYWNrTG9jYWxlID09PSBmYWxzZVxuICAgICAgICA/IG9wdGlvbnMuZmFsbGJhY2tMb2NhbGVcbiAgICAgICAgOiBsb2NhbGU7XG4gICAgY29uc3QgbWlzc2luZyA9IGlzRnVuY3Rpb24ob3B0aW9ucy5taXNzaW5nKSA/IG9wdGlvbnMubWlzc2luZyA6IHVuZGVmaW5lZDtcbiAgICBjb25zdCBtaXNzaW5nV2FybiA9IGlzQm9vbGVhbihvcHRpb25zLnNpbGVudFRyYW5zbGF0aW9uV2FybikgfHxcbiAgICAgICAgaXNSZWdFeHAob3B0aW9ucy5zaWxlbnRUcmFuc2xhdGlvbldhcm4pXG4gICAgICAgID8gIW9wdGlvbnMuc2lsZW50VHJhbnNsYXRpb25XYXJuXG4gICAgICAgIDogdHJ1ZTtcbiAgICBjb25zdCBmYWxsYmFja1dhcm4gPSBpc0Jvb2xlYW4ob3B0aW9ucy5zaWxlbnRGYWxsYmFja1dhcm4pIHx8XG4gICAgICAgIGlzUmVnRXhwKG9wdGlvbnMuc2lsZW50RmFsbGJhY2tXYXJuKVxuICAgICAgICA/ICFvcHRpb25zLnNpbGVudEZhbGxiYWNrV2FyblxuICAgICAgICA6IHRydWU7XG4gICAgY29uc3QgZmFsbGJhY2tSb290ID0gaXNCb29sZWFuKG9wdGlvbnMuZmFsbGJhY2tSb290KVxuICAgICAgICA/IG9wdGlvbnMuZmFsbGJhY2tSb290XG4gICAgICAgIDogdHJ1ZTtcbiAgICBjb25zdCBmYWxsYmFja0Zvcm1hdCA9ICEhb3B0aW9ucy5mb3JtYXRGYWxsYmFja01lc3NhZ2VzO1xuICAgIGNvbnN0IG1vZGlmaWVycyA9IGlzUGxhaW5PYmplY3Qob3B0aW9ucy5tb2RpZmllcnMpID8gb3B0aW9ucy5tb2RpZmllcnMgOiB7fTtcbiAgICBjb25zdCBwbHVyYWxpemF0aW9uUnVsZXMgPSBvcHRpb25zLnBsdXJhbGl6YXRpb25SdWxlcztcbiAgICBjb25zdCBwb3N0VHJhbnNsYXRpb24gPSBpc0Z1bmN0aW9uKG9wdGlvbnMucG9zdFRyYW5zbGF0aW9uKVxuICAgICAgICA/IG9wdGlvbnMucG9zdFRyYW5zbGF0aW9uXG4gICAgICAgIDogdW5kZWZpbmVkO1xuICAgIGNvbnN0IHdhcm5IdG1sTWVzc2FnZSA9IGlzU3RyaW5nKG9wdGlvbnMud2Fybkh0bWxJbk1lc3NhZ2UpXG4gICAgICAgID8gb3B0aW9ucy53YXJuSHRtbEluTWVzc2FnZSAhPT0gJ29mZidcbiAgICAgICAgOiB0cnVlO1xuICAgIGNvbnN0IGVzY2FwZVBhcmFtZXRlciA9ICEhb3B0aW9ucy5lc2NhcGVQYXJhbWV0ZXJIdG1sO1xuICAgIGNvbnN0IGluaGVyaXRMb2NhbGUgPSBpc0Jvb2xlYW4ob3B0aW9ucy5zeW5jKSA/IG9wdGlvbnMuc3luYyA6IHRydWU7XG4gICAgbGV0IG1lc3NhZ2VzID0gb3B0aW9ucy5tZXNzYWdlcztcbiAgICBpZiAoaXNQbGFpbk9iamVjdChvcHRpb25zLnNoYXJlZE1lc3NhZ2VzKSkge1xuICAgICAgICBjb25zdCBzaGFyZWRNZXNzYWdlcyA9IG9wdGlvbnMuc2hhcmVkTWVzc2FnZXM7XG4gICAgICAgIGNvbnN0IGxvY2FsZXMgPSBPYmplY3Qua2V5cyhzaGFyZWRNZXNzYWdlcyk7XG4gICAgICAgIG1lc3NhZ2VzID0gbG9jYWxlcy5yZWR1Y2UoKG1lc3NhZ2VzLCBsb2NhbGUpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBtZXNzYWdlc1tsb2NhbGVdIHx8IChtZXNzYWdlc1tsb2NhbGVdID0ge30pO1xuICAgICAgICAgICAgYXNzaWduKG1lc3NhZ2UsIHNoYXJlZE1lc3NhZ2VzW2xvY2FsZV0pO1xuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2VzO1xuICAgICAgICB9LCAobWVzc2FnZXMgfHwge30pKTtcbiAgICB9XG4gICAgY29uc3QgeyBfX2kxOG4sIF9fcm9vdCwgX19pbmplY3RXaXRoT3B0aW9uIH0gPSBvcHRpb25zO1xuICAgIGNvbnN0IGRhdGV0aW1lRm9ybWF0cyA9IG9wdGlvbnMuZGF0ZXRpbWVGb3JtYXRzO1xuICAgIGNvbnN0IG51bWJlckZvcm1hdHMgPSBvcHRpb25zLm51bWJlckZvcm1hdHM7XG4gICAgY29uc3QgZmxhdEpzb24gPSBvcHRpb25zLmZsYXRKc29uO1xuICAgIHJldHVybiB7XG4gICAgICAgIGxvY2FsZSxcbiAgICAgICAgZmFsbGJhY2tMb2NhbGUsXG4gICAgICAgIG1lc3NhZ2VzLFxuICAgICAgICBmbGF0SnNvbixcbiAgICAgICAgZGF0ZXRpbWVGb3JtYXRzLFxuICAgICAgICBudW1iZXJGb3JtYXRzLFxuICAgICAgICBtaXNzaW5nLFxuICAgICAgICBtaXNzaW5nV2FybixcbiAgICAgICAgZmFsbGJhY2tXYXJuLFxuICAgICAgICBmYWxsYmFja1Jvb3QsXG4gICAgICAgIGZhbGxiYWNrRm9ybWF0LFxuICAgICAgICBtb2RpZmllcnMsXG4gICAgICAgIHBsdXJhbFJ1bGVzOiBwbHVyYWxpemF0aW9uUnVsZXMsXG4gICAgICAgIHBvc3RUcmFuc2xhdGlvbixcbiAgICAgICAgd2Fybkh0bWxNZXNzYWdlLFxuICAgICAgICBlc2NhcGVQYXJhbWV0ZXIsXG4gICAgICAgIG1lc3NhZ2VSZXNvbHZlcjogb3B0aW9ucy5tZXNzYWdlUmVzb2x2ZXIsXG4gICAgICAgIGluaGVyaXRMb2NhbGUsXG4gICAgICAgIF9faTE4bixcbiAgICAgICAgX19yb290LFxuICAgICAgICBfX2luamVjdFdpdGhPcHRpb25cbiAgICB9O1xufVxuLyoqXG4gKiBjcmVhdGUgVnVlSTE4biBpbnRlcmZhY2UgZmFjdG9yeVxuICpcbiAqIEBpbnRlcm5hbFxuICpcbiAqIEBkZXByZWNhdGVkIHdpbGwgYmUgcmVtb3ZlZCBhdCB2dWUtaTE4biB2MTJcbiAqL1xuZnVuY3Rpb24gY3JlYXRlVnVlSTE4bihvcHRpb25zID0ge30pIHtcbiAgICBjb25zdCBjb21wb3NlciA9IGNyZWF0ZUNvbXBvc2VyKGNvbnZlcnRDb21wb3Nlck9wdGlvbnMob3B0aW9ucykpO1xuICAgIGNvbnN0IHsgX19leHRlbmRlciB9ID0gb3B0aW9ucztcbiAgICAvLyBkZWZpbmVzIFZ1ZUkxOG5cbiAgICBjb25zdCB2dWVJMThuID0ge1xuICAgICAgICAvLyBpZFxuICAgICAgICBpZDogY29tcG9zZXIuaWQsXG4gICAgICAgIC8vIGxvY2FsZVxuICAgICAgICBnZXQgbG9jYWxlKCkge1xuICAgICAgICAgICAgcmV0dXJuIGNvbXBvc2VyLmxvY2FsZS52YWx1ZTtcbiAgICAgICAgfSxcbiAgICAgICAgc2V0IGxvY2FsZSh2YWwpIHtcbiAgICAgICAgICAgIGNvbXBvc2VyLmxvY2FsZS52YWx1ZSA9IHZhbDtcbiAgICAgICAgfSxcbiAgICAgICAgLy8gZmFsbGJhY2tMb2NhbGVcbiAgICAgICAgZ2V0IGZhbGxiYWNrTG9jYWxlKCkge1xuICAgICAgICAgICAgcmV0dXJuIGNvbXBvc2VyLmZhbGxiYWNrTG9jYWxlLnZhbHVlO1xuICAgICAgICB9LFxuICAgICAgICBzZXQgZmFsbGJhY2tMb2NhbGUodmFsKSB7XG4gICAgICAgICAgICBjb21wb3Nlci5mYWxsYmFja0xvY2FsZS52YWx1ZSA9IHZhbDtcbiAgICAgICAgfSxcbiAgICAgICAgLy8gbWVzc2FnZXNcbiAgICAgICAgZ2V0IG1lc3NhZ2VzKCkge1xuICAgICAgICAgICAgcmV0dXJuIGNvbXBvc2VyLm1lc3NhZ2VzLnZhbHVlO1xuICAgICAgICB9LFxuICAgICAgICAvLyBkYXRldGltZUZvcm1hdHNcbiAgICAgICAgZ2V0IGRhdGV0aW1lRm9ybWF0cygpIHtcbiAgICAgICAgICAgIHJldHVybiBjb21wb3Nlci5kYXRldGltZUZvcm1hdHMudmFsdWU7XG4gICAgICAgIH0sXG4gICAgICAgIC8vIG51bWJlckZvcm1hdHNcbiAgICAgICAgZ2V0IG51bWJlckZvcm1hdHMoKSB7XG4gICAgICAgICAgICByZXR1cm4gY29tcG9zZXIubnVtYmVyRm9ybWF0cy52YWx1ZTtcbiAgICAgICAgfSxcbiAgICAgICAgLy8gYXZhaWxhYmxlTG9jYWxlc1xuICAgICAgICBnZXQgYXZhaWxhYmxlTG9jYWxlcygpIHtcbiAgICAgICAgICAgIHJldHVybiBjb21wb3Nlci5hdmFpbGFibGVMb2NhbGVzO1xuICAgICAgICB9LFxuICAgICAgICAvLyBtaXNzaW5nXG4gICAgICAgIGdldCBtaXNzaW5nKCkge1xuICAgICAgICAgICAgcmV0dXJuIGNvbXBvc2VyLmdldE1pc3NpbmdIYW5kbGVyKCk7XG4gICAgICAgIH0sXG4gICAgICAgIHNldCBtaXNzaW5nKGhhbmRsZXIpIHtcbiAgICAgICAgICAgIGNvbXBvc2VyLnNldE1pc3NpbmdIYW5kbGVyKGhhbmRsZXIpO1xuICAgICAgICB9LFxuICAgICAgICAvLyBzaWxlbnRUcmFuc2xhdGlvbldhcm5cbiAgICAgICAgZ2V0IHNpbGVudFRyYW5zbGF0aW9uV2FybigpIHtcbiAgICAgICAgICAgIHJldHVybiBpc0Jvb2xlYW4oY29tcG9zZXIubWlzc2luZ1dhcm4pXG4gICAgICAgICAgICAgICAgPyAhY29tcG9zZXIubWlzc2luZ1dhcm5cbiAgICAgICAgICAgICAgICA6IGNvbXBvc2VyLm1pc3NpbmdXYXJuO1xuICAgICAgICB9LFxuICAgICAgICBzZXQgc2lsZW50VHJhbnNsYXRpb25XYXJuKHZhbCkge1xuICAgICAgICAgICAgY29tcG9zZXIubWlzc2luZ1dhcm4gPSBpc0Jvb2xlYW4odmFsKSA/ICF2YWwgOiB2YWw7XG4gICAgICAgIH0sXG4gICAgICAgIC8vIHNpbGVudEZhbGxiYWNrV2FyblxuICAgICAgICBnZXQgc2lsZW50RmFsbGJhY2tXYXJuKCkge1xuICAgICAgICAgICAgcmV0dXJuIGlzQm9vbGVhbihjb21wb3Nlci5mYWxsYmFja1dhcm4pXG4gICAgICAgICAgICAgICAgPyAhY29tcG9zZXIuZmFsbGJhY2tXYXJuXG4gICAgICAgICAgICAgICAgOiBjb21wb3Nlci5mYWxsYmFja1dhcm47XG4gICAgICAgIH0sXG4gICAgICAgIHNldCBzaWxlbnRGYWxsYmFja1dhcm4odmFsKSB7XG4gICAgICAgICAgICBjb21wb3Nlci5mYWxsYmFja1dhcm4gPSBpc0Jvb2xlYW4odmFsKSA/ICF2YWwgOiB2YWw7XG4gICAgICAgIH0sXG4gICAgICAgIC8vIG1vZGlmaWVyc1xuICAgICAgICBnZXQgbW9kaWZpZXJzKCkge1xuICAgICAgICAgICAgcmV0dXJuIGNvbXBvc2VyLm1vZGlmaWVycztcbiAgICAgICAgfSxcbiAgICAgICAgLy8gZm9ybWF0RmFsbGJhY2tNZXNzYWdlc1xuICAgICAgICBnZXQgZm9ybWF0RmFsbGJhY2tNZXNzYWdlcygpIHtcbiAgICAgICAgICAgIHJldHVybiBjb21wb3Nlci5mYWxsYmFja0Zvcm1hdDtcbiAgICAgICAgfSxcbiAgICAgICAgc2V0IGZvcm1hdEZhbGxiYWNrTWVzc2FnZXModmFsKSB7XG4gICAgICAgICAgICBjb21wb3Nlci5mYWxsYmFja0Zvcm1hdCA9IHZhbDtcbiAgICAgICAgfSxcbiAgICAgICAgLy8gcG9zdFRyYW5zbGF0aW9uXG4gICAgICAgIGdldCBwb3N0VHJhbnNsYXRpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4gY29tcG9zZXIuZ2V0UG9zdFRyYW5zbGF0aW9uSGFuZGxlcigpO1xuICAgICAgICB9LFxuICAgICAgICBzZXQgcG9zdFRyYW5zbGF0aW9uKGhhbmRsZXIpIHtcbiAgICAgICAgICAgIGNvbXBvc2VyLnNldFBvc3RUcmFuc2xhdGlvbkhhbmRsZXIoaGFuZGxlcik7XG4gICAgICAgIH0sXG4gICAgICAgIC8vIHN5bmNcbiAgICAgICAgZ2V0IHN5bmMoKSB7XG4gICAgICAgICAgICByZXR1cm4gY29tcG9zZXIuaW5oZXJpdExvY2FsZTtcbiAgICAgICAgfSxcbiAgICAgICAgc2V0IHN5bmModmFsKSB7XG4gICAgICAgICAgICBjb21wb3Nlci5pbmhlcml0TG9jYWxlID0gdmFsO1xuICAgICAgICB9LFxuICAgICAgICAvLyB3YXJuSW5IdG1sTWVzc2FnZVxuICAgICAgICBnZXQgd2Fybkh0bWxJbk1lc3NhZ2UoKSB7XG4gICAgICAgICAgICByZXR1cm4gY29tcG9zZXIud2Fybkh0bWxNZXNzYWdlID8gJ3dhcm4nIDogJ29mZic7XG4gICAgICAgIH0sXG4gICAgICAgIHNldCB3YXJuSHRtbEluTWVzc2FnZSh2YWwpIHtcbiAgICAgICAgICAgIGNvbXBvc2VyLndhcm5IdG1sTWVzc2FnZSA9IHZhbCAhPT0gJ29mZic7XG4gICAgICAgIH0sXG4gICAgICAgIC8vIGVzY2FwZVBhcmFtZXRlckh0bWxcbiAgICAgICAgZ2V0IGVzY2FwZVBhcmFtZXRlckh0bWwoKSB7XG4gICAgICAgICAgICByZXR1cm4gY29tcG9zZXIuZXNjYXBlUGFyYW1ldGVyO1xuICAgICAgICB9LFxuICAgICAgICBzZXQgZXNjYXBlUGFyYW1ldGVySHRtbCh2YWwpIHtcbiAgICAgICAgICAgIGNvbXBvc2VyLmVzY2FwZVBhcmFtZXRlciA9IHZhbDtcbiAgICAgICAgfSxcbiAgICAgICAgLy8gcGx1cmFsaXphdGlvblJ1bGVzXG4gICAgICAgIGdldCBwbHVyYWxpemF0aW9uUnVsZXMoKSB7XG4gICAgICAgICAgICByZXR1cm4gY29tcG9zZXIucGx1cmFsUnVsZXMgfHwge307XG4gICAgICAgIH0sXG4gICAgICAgIC8vIGZvciBpbnRlcm5hbFxuICAgICAgICBfX2NvbXBvc2VyOiBjb21wb3NlcixcbiAgICAgICAgLy8gdFxuICAgICAgICB0KC4uLmFyZ3MpIHtcbiAgICAgICAgICAgIHJldHVybiBSZWZsZWN0LmFwcGx5KGNvbXBvc2VyLnQsIGNvbXBvc2VyLCBbLi4uYXJnc10pO1xuICAgICAgICB9LFxuICAgICAgICAvLyBydFxuICAgICAgICBydCguLi5hcmdzKSB7XG4gICAgICAgICAgICByZXR1cm4gUmVmbGVjdC5hcHBseShjb21wb3Nlci5ydCwgY29tcG9zZXIsIFsuLi5hcmdzXSk7XG4gICAgICAgIH0sXG4gICAgICAgIC8vIHRlXG4gICAgICAgIHRlKGtleSwgbG9jYWxlKSB7XG4gICAgICAgICAgICByZXR1cm4gY29tcG9zZXIudGUoa2V5LCBsb2NhbGUpO1xuICAgICAgICB9LFxuICAgICAgICAvLyB0bVxuICAgICAgICB0bShrZXkpIHtcbiAgICAgICAgICAgIHJldHVybiBjb21wb3Nlci50bShrZXkpO1xuICAgICAgICB9LFxuICAgICAgICAvLyBnZXRMb2NhbGVNZXNzYWdlXG4gICAgICAgIGdldExvY2FsZU1lc3NhZ2UobG9jYWxlKSB7XG4gICAgICAgICAgICByZXR1cm4gY29tcG9zZXIuZ2V0TG9jYWxlTWVzc2FnZShsb2NhbGUpO1xuICAgICAgICB9LFxuICAgICAgICAvLyBzZXRMb2NhbGVNZXNzYWdlXG4gICAgICAgIHNldExvY2FsZU1lc3NhZ2UobG9jYWxlLCBtZXNzYWdlKSB7XG4gICAgICAgICAgICBjb21wb3Nlci5zZXRMb2NhbGVNZXNzYWdlKGxvY2FsZSwgbWVzc2FnZSk7XG4gICAgICAgIH0sXG4gICAgICAgIC8vIG1lcmdlTG9jYWxlTWVzc2FnZVxuICAgICAgICBtZXJnZUxvY2FsZU1lc3NhZ2UobG9jYWxlLCBtZXNzYWdlKSB7XG4gICAgICAgICAgICBjb21wb3Nlci5tZXJnZUxvY2FsZU1lc3NhZ2UobG9jYWxlLCBtZXNzYWdlKTtcbiAgICAgICAgfSxcbiAgICAgICAgLy8gZFxuICAgICAgICBkKC4uLmFyZ3MpIHtcbiAgICAgICAgICAgIHJldHVybiBSZWZsZWN0LmFwcGx5KGNvbXBvc2VyLmQsIGNvbXBvc2VyLCBbLi4uYXJnc10pO1xuICAgICAgICB9LFxuICAgICAgICAvLyBnZXREYXRlVGltZUZvcm1hdFxuICAgICAgICBnZXREYXRlVGltZUZvcm1hdChsb2NhbGUpIHtcbiAgICAgICAgICAgIHJldHVybiBjb21wb3Nlci5nZXREYXRlVGltZUZvcm1hdChsb2NhbGUpO1xuICAgICAgICB9LFxuICAgICAgICAvLyBzZXREYXRlVGltZUZvcm1hdFxuICAgICAgICBzZXREYXRlVGltZUZvcm1hdChsb2NhbGUsIGZvcm1hdCkge1xuICAgICAgICAgICAgY29tcG9zZXIuc2V0RGF0ZVRpbWVGb3JtYXQobG9jYWxlLCBmb3JtYXQpO1xuICAgICAgICB9LFxuICAgICAgICAvLyBtZXJnZURhdGVUaW1lRm9ybWF0XG4gICAgICAgIG1lcmdlRGF0ZVRpbWVGb3JtYXQobG9jYWxlLCBmb3JtYXQpIHtcbiAgICAgICAgICAgIGNvbXBvc2VyLm1lcmdlRGF0ZVRpbWVGb3JtYXQobG9jYWxlLCBmb3JtYXQpO1xuICAgICAgICB9LFxuICAgICAgICAvLyBuXG4gICAgICAgIG4oLi4uYXJncykge1xuICAgICAgICAgICAgcmV0dXJuIFJlZmxlY3QuYXBwbHkoY29tcG9zZXIubiwgY29tcG9zZXIsIFsuLi5hcmdzXSk7XG4gICAgICAgIH0sXG4gICAgICAgIC8vIGdldE51bWJlckZvcm1hdFxuICAgICAgICBnZXROdW1iZXJGb3JtYXQobG9jYWxlKSB7XG4gICAgICAgICAgICByZXR1cm4gY29tcG9zZXIuZ2V0TnVtYmVyRm9ybWF0KGxvY2FsZSk7XG4gICAgICAgIH0sXG4gICAgICAgIC8vIHNldE51bWJlckZvcm1hdFxuICAgICAgICBzZXROdW1iZXJGb3JtYXQobG9jYWxlLCBmb3JtYXQpIHtcbiAgICAgICAgICAgIGNvbXBvc2VyLnNldE51bWJlckZvcm1hdChsb2NhbGUsIGZvcm1hdCk7XG4gICAgICAgIH0sXG4gICAgICAgIC8vIG1lcmdlTnVtYmVyRm9ybWF0XG4gICAgICAgIG1lcmdlTnVtYmVyRm9ybWF0KGxvY2FsZSwgZm9ybWF0KSB7XG4gICAgICAgICAgICBjb21wb3Nlci5tZXJnZU51bWJlckZvcm1hdChsb2NhbGUsIGZvcm1hdCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIHZ1ZUkxOG4uX19leHRlbmRlciA9IF9fZXh0ZW5kZXI7XG4gICAgLy8gZm9yIHZ1ZS1kZXZ0b29scyB0aW1lbGluZSBldmVudFxuICAgIGlmICgocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykpIHtcbiAgICAgICAgdnVlSTE4bi5fX2VuYWJsZUVtaXR0ZXIgPSAoZW1pdHRlcikgPT4ge1xuICAgICAgICAgICAgY29uc3QgX19jb21wb3NlciA9IGNvbXBvc2VyO1xuICAgICAgICAgICAgX19jb21wb3NlcltFbmFibGVFbWl0dGVyXSAmJiBfX2NvbXBvc2VyW0VuYWJsZUVtaXR0ZXJdKGVtaXR0ZXIpO1xuICAgICAgICB9O1xuICAgICAgICB2dWVJMThuLl9fZGlzYWJsZUVtaXR0ZXIgPSAoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBfX2NvbXBvc2VyID0gY29tcG9zZXI7XG4gICAgICAgICAgICBfX2NvbXBvc2VyW0Rpc2FibGVFbWl0dGVyXSAmJiBfX2NvbXBvc2VyW0Rpc2FibGVFbWl0dGVyXSgpO1xuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gdnVlSTE4bjtcbn1cbi8qIGVzbGludC1lbmFibGUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAqL1xuXG4vKipcbiAqIFN1cHBvcnRzIGNvbXBhdGliaWxpdHkgZm9yIGxlZ2FjeSB2dWUtaTE4biBBUElzXG4gKiBUaGlzIG1peGluIGlzIHVzZWQgd2hlbiB3ZSB1c2UgdnVlLWkxOG5AdjkueCBvciBsYXRlclxuICovXG5mdW5jdGlvbiBkZWZpbmVNaXhpbih2dWVpMThuLCBjb21wb3NlciwgaTE4bikge1xuICAgIHJldHVybiB7XG4gICAgICAgIGJlZm9yZUNyZWF0ZSgpIHtcbiAgICAgICAgICAgIGNvbnN0IGluc3RhbmNlID0gZ2V0Q3VycmVudEluc3RhbmNlKCk7XG4gICAgICAgICAgICAvKiBpc3RhbmJ1bCBpZ25vcmUgaWYgKi9cbiAgICAgICAgICAgIGlmICghaW5zdGFuY2UpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBjcmVhdGVJMThuRXJyb3IoSTE4bkVycm9yQ29kZXMuVU5FWFBFQ1RFRF9FUlJPUik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBvcHRpb25zID0gdGhpcy4kb3B0aW9ucztcbiAgICAgICAgICAgIGlmIChvcHRpb25zLmkxOG4pIHtcbiAgICAgICAgICAgICAgICBjb25zdCBvcHRpb25zSTE4biA9IG9wdGlvbnMuaTE4bjtcbiAgICAgICAgICAgICAgICBpZiAob3B0aW9ucy5fX2kxOG4pIHtcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9uc0kxOG4uX19pMThuID0gb3B0aW9ucy5fX2kxOG47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIG9wdGlvbnNJMThuLl9fcm9vdCA9IGNvbXBvc2VyO1xuICAgICAgICAgICAgICAgIGlmICh0aGlzID09PSB0aGlzLiRyb290KSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIG1lcmdlIG9wdGlvbiBhbmQgZ3R0YWNoIGdsb2JhbFxuICAgICAgICAgICAgICAgICAgICB0aGlzLiRpMThuID0gbWVyZ2VUb0dsb2JhbCh2dWVpMThuLCBvcHRpb25zSTE4bik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBvcHRpb25zSTE4bi5fX2luamVjdFdpdGhPcHRpb24gPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICBvcHRpb25zSTE4bi5fX2V4dGVuZGVyID0gaTE4bi5fX3Z1ZUkxOG5FeHRlbmQ7XG4gICAgICAgICAgICAgICAgICAgIC8vIGF0dHRhY2ggbG9jYWwgVnVlSTE4biBpbnN0YW5jZVxuICAgICAgICAgICAgICAgICAgICB0aGlzLiRpMThuID0gY3JlYXRlVnVlSTE4bihvcHRpb25zSTE4bik7XG4gICAgICAgICAgICAgICAgICAgIC8vIGV4dGVuZCBWdWVJMThuIGluc3RhbmNlXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IF92dWVJMThuID0gdGhpcy4kaTE4bjtcbiAgICAgICAgICAgICAgICAgICAgaWYgKF92dWVJMThuLl9fZXh0ZW5kZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF92dWVJMThuLl9fZGlzcG9zZXIgPSBfdnVlSTE4bi5fX2V4dGVuZGVyKHRoaXMuJGkxOG4pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAob3B0aW9ucy5fX2kxOG4pIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcyA9PT0gdGhpcy4kcm9vdCkge1xuICAgICAgICAgICAgICAgICAgICAvLyBtZXJnZSBvcHRpb24gYW5kIGd0dGFjaCBnbG9iYWxcbiAgICAgICAgICAgICAgICAgICAgdGhpcy4kaTE4biA9IG1lcmdlVG9HbG9iYWwodnVlaTE4biwgb3B0aW9ucyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAvLyBhdHR0YWNoIGxvY2FsIFZ1ZUkxOG4gaW5zdGFuY2VcbiAgICAgICAgICAgICAgICAgICAgdGhpcy4kaTE4biA9IGNyZWF0ZVZ1ZUkxOG4oe1xuICAgICAgICAgICAgICAgICAgICAgICAgX19pMThuOiBvcHRpb25zLl9faTE4bixcbiAgICAgICAgICAgICAgICAgICAgICAgIF9faW5qZWN0V2l0aE9wdGlvbjogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF9fZXh0ZW5kZXI6IGkxOG4uX192dWVJMThuRXh0ZW5kLFxuICAgICAgICAgICAgICAgICAgICAgICAgX19yb290OiBjb21wb3NlclxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgLy8gZXh0ZW5kIFZ1ZUkxOG4gaW5zdGFuY2VcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgX3Z1ZUkxOG4gPSB0aGlzLiRpMThuO1xuICAgICAgICAgICAgICAgICAgICBpZiAoX3Z1ZUkxOG4uX19leHRlbmRlcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgX3Z1ZUkxOG4uX19kaXNwb3NlciA9IF92dWVJMThuLl9fZXh0ZW5kZXIodGhpcy4kaTE4bik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBhdHRhY2ggZ2xvYmFsIFZ1ZUkxOG4gaW5zdGFuY2VcbiAgICAgICAgICAgICAgICB0aGlzLiRpMThuID0gdnVlaTE4bjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChvcHRpb25zLl9faTE4bkdsb2JhbCkge1xuICAgICAgICAgICAgICAgIGFkanVzdEkxOG5SZXNvdXJjZXMoY29tcG9zZXIsIG9wdGlvbnMsIG9wdGlvbnMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gZGVmaW5lcyB2dWUtaTE4biBsZWdhY3kgQVBJc1xuICAgICAgICAgICAgdGhpcy4kdCA9ICguLi5hcmdzKSA9PiB0aGlzLiRpMThuLnQoLi4uYXJncyk7XG4gICAgICAgICAgICB0aGlzLiRydCA9ICguLi5hcmdzKSA9PiB0aGlzLiRpMThuLnJ0KC4uLmFyZ3MpO1xuICAgICAgICAgICAgdGhpcy4kdGUgPSAoa2V5LCBsb2NhbGUpID0+IHRoaXMuJGkxOG4udGUoa2V5LCBsb2NhbGUpO1xuICAgICAgICAgICAgdGhpcy4kZCA9ICguLi5hcmdzKSA9PiB0aGlzLiRpMThuLmQoLi4uYXJncyk7XG4gICAgICAgICAgICB0aGlzLiRuID0gKC4uLmFyZ3MpID0+IHRoaXMuJGkxOG4ubiguLi5hcmdzKTtcbiAgICAgICAgICAgIHRoaXMuJHRtID0gKGtleSkgPT4gdGhpcy4kaTE4bi50bShrZXkpO1xuICAgICAgICAgICAgaTE4bi5fX3NldEluc3RhbmNlKGluc3RhbmNlLCB0aGlzLiRpMThuKTtcbiAgICAgICAgfSxcbiAgICAgICAgbW91bnRlZCgpIHtcbiAgICAgICAgICAgIC8qIGlzdGFuYnVsIGlnbm9yZSBpZiAqL1xuICAgICAgICAgICAgaWYgKCgocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgfHwgX19WVUVfUFJPRF9ERVZUT09MU19fKSAmJlxuICAgICAgICAgICAgICAgIHRydWUgJiZcbiAgICAgICAgICAgICAgICB0aGlzLiRpMThuKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaW5zdGFuY2UgPSBnZXRDdXJyZW50SW5zdGFuY2UoKTtcbiAgICAgICAgICAgICAgICBpZiAoIWluc3RhbmNlKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgX3Z1ZUkxOG4gPSB0aGlzLiRpMThuO1xuICAgICAgICAgICAgICAgIGluc3RhbmNlLl9fVlVFX0kxOE5fXyA9IF92dWVJMThuLl9fY29tcG9zZXI7XG4gICAgICAgICAgICAgICAgY29uc3QgZW1pdHRlciA9ICh0aGlzLl9fdl9lbWl0dGVyID1cbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlRW1pdHRlcigpKTtcbiAgICAgICAgICAgICAgICBfdnVlSTE4bi5fX2VuYWJsZUVtaXR0ZXIgJiYgX3Z1ZUkxOG4uX19lbmFibGVFbWl0dGVyKGVtaXR0ZXIpO1xuICAgICAgICAgICAgICAgIGVtaXR0ZXIub24oJyonLCBhZGRUaW1lbGluZUV2ZW50KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgdW5tb3VudGVkKCkge1xuICAgICAgICAgICAgY29uc3QgaW5zdGFuY2UgPSBnZXRDdXJyZW50SW5zdGFuY2UoKTtcbiAgICAgICAgICAgIC8qIGlzdGFuYnVsIGlnbm9yZSBpZiAqL1xuICAgICAgICAgICAgaWYgKCFpbnN0YW5jZSkge1xuICAgICAgICAgICAgICAgIHRocm93IGNyZWF0ZUkxOG5FcnJvcihJMThuRXJyb3JDb2Rlcy5VTkVYUEVDVEVEX0VSUk9SKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IF92dWVJMThuID0gdGhpcy4kaTE4bjtcbiAgICAgICAgICAgIC8qIGlzdGFuYnVsIGlnbm9yZSBpZiAqL1xuICAgICAgICAgICAgaWYgKCgocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgfHwgX19WVUVfUFJPRF9ERVZUT09MU19fKSAmJlxuICAgICAgICAgICAgICAgIHRydWUgJiZcbiAgICAgICAgICAgICAgICBpbnN0YW5jZS5fX1ZVRV9JMThOX18pIHtcbiAgICAgICAgICAgICAgICBpZiAodGhpcy5fX3ZfZW1pdHRlcikge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLl9fdl9lbWl0dGVyLm9mZignKicsIGFkZFRpbWVsaW5lRXZlbnQpO1xuICAgICAgICAgICAgICAgICAgICBkZWxldGUgdGhpcy5fX3ZfZW1pdHRlcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKF92dWVJMThuKSB7XG4gICAgICAgICAgICAgICAgICAgIF92dWVJMThuLl9fZGlzYWJsZUVtaXR0ZXIgJiYgX3Z1ZUkxOG4uX19kaXNhYmxlRW1pdHRlcigpO1xuICAgICAgICAgICAgICAgICAgICBkZWxldGUgaW5zdGFuY2UuX19WVUVfSTE4Tl9fO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIHNldHVwLW9ubHkgY29tcG9uZW50cyBza2lwIGJlZm9yZUNyZWF0ZSBidXQgc3RpbGwgcnVuIHVubW91bnRlZFxuICAgICAgICAgICAgaWYgKCFfdnVlSTE4bikge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLiR0O1xuICAgICAgICAgICAgZGVsZXRlIHRoaXMuJHJ0O1xuICAgICAgICAgICAgZGVsZXRlIHRoaXMuJHRlO1xuICAgICAgICAgICAgZGVsZXRlIHRoaXMuJGQ7XG4gICAgICAgICAgICBkZWxldGUgdGhpcy4kbjtcbiAgICAgICAgICAgIGRlbGV0ZSB0aGlzLiR0bTtcbiAgICAgICAgICAgIGlmIChfdnVlSTE4bj8uX19kaXNwb3Nlcikge1xuICAgICAgICAgICAgICAgIF92dWVJMThuLl9fZGlzcG9zZXIoKTtcbiAgICAgICAgICAgICAgICBkZWxldGUgX3Z1ZUkxOG4uX19kaXNwb3NlcjtcbiAgICAgICAgICAgICAgICBkZWxldGUgX3Z1ZUkxOG4uX19leHRlbmRlcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGkxOG4uX19kZWxldGVJbnN0YW5jZShpbnN0YW5jZSk7XG4gICAgICAgICAgICBkZWxldGUgdGhpcy4kaTE4bjtcbiAgICAgICAgfVxuICAgIH07XG59XG5mdW5jdGlvbiBtZXJnZVRvR2xvYmFsKGcsIG9wdGlvbnMpIHtcbiAgICBnLmxvY2FsZSA9IG9wdGlvbnMubG9jYWxlIHx8IGcubG9jYWxlO1xuICAgIGcuZmFsbGJhY2tMb2NhbGUgPSBvcHRpb25zLmZhbGxiYWNrTG9jYWxlIHx8IGcuZmFsbGJhY2tMb2NhbGU7XG4gICAgZy5taXNzaW5nID0gb3B0aW9ucy5taXNzaW5nIHx8IGcubWlzc2luZztcbiAgICBnLnNpbGVudFRyYW5zbGF0aW9uV2FybiA9XG4gICAgICAgIG9wdGlvbnMuc2lsZW50VHJhbnNsYXRpb25XYXJuIHx8IGcuc2lsZW50RmFsbGJhY2tXYXJuO1xuICAgIGcuc2lsZW50RmFsbGJhY2tXYXJuID0gb3B0aW9ucy5zaWxlbnRGYWxsYmFja1dhcm4gfHwgZy5zaWxlbnRGYWxsYmFja1dhcm47XG4gICAgZy5mb3JtYXRGYWxsYmFja01lc3NhZ2VzID1cbiAgICAgICAgb3B0aW9ucy5mb3JtYXRGYWxsYmFja01lc3NhZ2VzIHx8IGcuZm9ybWF0RmFsbGJhY2tNZXNzYWdlcztcbiAgICBnLnBvc3RUcmFuc2xhdGlvbiA9IG9wdGlvbnMucG9zdFRyYW5zbGF0aW9uIHx8IGcucG9zdFRyYW5zbGF0aW9uO1xuICAgIGcud2Fybkh0bWxJbk1lc3NhZ2UgPSBvcHRpb25zLndhcm5IdG1sSW5NZXNzYWdlIHx8IGcud2Fybkh0bWxJbk1lc3NhZ2U7XG4gICAgZy5lc2NhcGVQYXJhbWV0ZXJIdG1sID0gb3B0aW9ucy5lc2NhcGVQYXJhbWV0ZXJIdG1sIHx8IGcuZXNjYXBlUGFyYW1ldGVySHRtbDtcbiAgICBnLnN5bmMgPSBvcHRpb25zLnN5bmMgfHwgZy5zeW5jO1xuICAgIGcuX19jb21wb3NlcltTZXRQbHVyYWxSdWxlc1N5bWJvbF0ob3B0aW9ucy5wbHVyYWxpemF0aW9uUnVsZXMgfHwgZy5wbHVyYWxpemF0aW9uUnVsZXMpO1xuICAgIGNvbnN0IG1lc3NhZ2VzID0gZ2V0TG9jYWxlTWVzc2FnZXMoZy5sb2NhbGUsIHtcbiAgICAgICAgbWVzc2FnZXM6IG9wdGlvbnMubWVzc2FnZXMsXG4gICAgICAgIF9faTE4bjogb3B0aW9ucy5fX2kxOG5cbiAgICB9KTtcbiAgICBPYmplY3Qua2V5cyhtZXNzYWdlcykuZm9yRWFjaChsb2NhbGUgPT4gZy5tZXJnZUxvY2FsZU1lc3NhZ2UobG9jYWxlLCBtZXNzYWdlc1tsb2NhbGVdKSk7XG4gICAgaWYgKG9wdGlvbnMuZGF0ZXRpbWVGb3JtYXRzKSB7XG4gICAgICAgIE9iamVjdC5rZXlzKG9wdGlvbnMuZGF0ZXRpbWVGb3JtYXRzKS5mb3JFYWNoKGxvY2FsZSA9PiBnLm1lcmdlRGF0ZVRpbWVGb3JtYXQobG9jYWxlLCBvcHRpb25zLmRhdGV0aW1lRm9ybWF0c1tsb2NhbGVdKSk7XG4gICAgfVxuICAgIGlmIChvcHRpb25zLm51bWJlckZvcm1hdHMpIHtcbiAgICAgICAgT2JqZWN0LmtleXMob3B0aW9ucy5udW1iZXJGb3JtYXRzKS5mb3JFYWNoKGxvY2FsZSA9PiBnLm1lcmdlTnVtYmVyRm9ybWF0KGxvY2FsZSwgb3B0aW9ucy5udW1iZXJGb3JtYXRzW2xvY2FsZV0pKTtcbiAgICB9XG4gICAgcmV0dXJuIGc7XG59XG5cbmNvbnN0IGJhc2VGb3JtYXRQcm9wcyA9IHtcbiAgICB0YWc6IHtcbiAgICAgICAgdHlwZTogW1N0cmluZywgT2JqZWN0XVxuICAgIH0sXG4gICAgbG9jYWxlOiB7XG4gICAgICAgIHR5cGU6IFN0cmluZ1xuICAgIH0sXG4gICAgc2NvcGU6IHtcbiAgICAgICAgdHlwZTogU3RyaW5nLFxuICAgICAgICAvLyBOT1RFOiBhdm9pZCBodHRwczovL2dpdGh1Yi5jb20vbWljcm9zb2Z0L3J1c2hzdGFjay9pc3N1ZXMvMTA1MFxuICAgICAgICB2YWxpZGF0b3I6ICh2YWwgLyogQ29tcG9uZW50STE4blNjb3BlICovKSA9PiB2YWwgPT09ICdwYXJlbnQnIHx8IHZhbCA9PT0gJ2dsb2JhbCcsXG4gICAgICAgIGRlZmF1bHQ6ICdwYXJlbnQnIC8qIENvbXBvbmVudEkxOG5TY29wZSAqL1xuICAgIH0sXG4gICAgaTE4bjoge1xuICAgICAgICB0eXBlOiBPYmplY3RcbiAgICB9XG59O1xuXG5mdW5jdGlvbiBnZXRJbnRlcnBvbGF0ZUFyZyhcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG57IHNsb3RzIH0sIC8vIFNldHVwQ29udGV4dCxcbmtleXMpIHtcbiAgICBpZiAoa2V5cy5sZW5ndGggPT09IDEgJiYga2V5c1swXSA9PT0gJ2RlZmF1bHQnKSB7XG4gICAgICAgIC8vIGRlZmF1bHQgc2xvdCB3aXRoIGxpc3RcbiAgICAgICAgY29uc3QgcmV0ID0gc2xvdHMuZGVmYXVsdCA/IHNsb3RzLmRlZmF1bHQoKSA6IFtdO1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgICAgICByZXR1cm4gcmV0LnJlZHVjZSgoc2xvdCwgY3VycmVudCkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgICAgICAuLi5zbG90LFxuICAgICAgICAgICAgICAgIC8vIHByZXR0aWVyLWlnbm9yZVxuICAgICAgICAgICAgICAgIC4uLihjdXJyZW50LnR5cGUgPT09IEZyYWdtZW50ID8gY3VycmVudC5jaGlsZHJlbiA6IFtjdXJyZW50XSlcbiAgICAgICAgICAgIF07XG4gICAgICAgIH0sIFtdKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIC8vIG5hbWVkIHNsb3RzXG4gICAgICAgIHJldHVybiBrZXlzLnJlZHVjZSgoYXJnLCBrZXkpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHNsb3QgPSBzbG90c1trZXldO1xuICAgICAgICAgICAgaWYgKHNsb3QpIHtcbiAgICAgICAgICAgICAgICBhcmdba2V5XSA9IHNsb3QoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBhcmc7XG4gICAgICAgIH0sIGNyZWF0ZSgpKTtcbiAgICB9XG59XG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuZnVuY3Rpb24gZ2V0RnJhZ21lbnRhYmxlVGFnKCkge1xuICAgIHJldHVybiBGcmFnbWVudDtcbn1cblxuY29uc3QgVHJhbnNsYXRpb25JbXBsID0gLyojX19QVVJFX18qLyBkZWZpbmVDb21wb25lbnQoe1xuICAgIC8qIGVzbGludC1kaXNhYmxlICovXG4gICAgbmFtZTogJ2kxOG4tdCcsXG4gICAgcHJvcHM6IGFzc2lnbih7XG4gICAgICAgIGtleXBhdGg6IHtcbiAgICAgICAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgICAgICAgIHJlcXVpcmVkOiB0cnVlXG4gICAgICAgIH0sXG4gICAgICAgIHBsdXJhbDoge1xuICAgICAgICAgICAgdHlwZTogW051bWJlciwgU3RyaW5nXSxcbiAgICAgICAgICAgIHZhbGlkYXRvcjogKHZhbCkgPT4gaXNOdW1iZXIodmFsKSB8fCAhaXNOYU4odmFsKVxuICAgICAgICB9XG4gICAgfSwgYmFzZUZvcm1hdFByb3BzKSxcbiAgICAvKiBlc2xpbnQtZW5hYmxlICovXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbiAgICBzZXR1cChwcm9wcywgY29udGV4dCkge1xuICAgICAgICBjb25zdCB7IHNsb3RzLCBhdHRycyB9ID0gY29udGV4dDtcbiAgICAgICAgLy8gTk9URTogYXZvaWQgaHR0cHM6Ly9naXRodWIuY29tL21pY3Jvc29mdC9ydXNoc3RhY2svaXNzdWVzLzEwNTBcbiAgICAgICAgY29uc3QgaTE4biA9IHByb3BzLmkxOG4gfHxcbiAgICAgICAgICAgIHVzZUkxOG4oe1xuICAgICAgICAgICAgICAgIHVzZVNjb3BlOiBwcm9wcy5zY29wZSxcbiAgICAgICAgICAgICAgICBfX3VzZUNvbXBvbmVudDogdHJ1ZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCByZW5kZXJDaGlsZHJlbiA9ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXMoc2xvdHMpLmZpbHRlcihrZXkgPT4ga2V5WzBdICE9PSAnXycpO1xuICAgICAgICAgICAgICAgIGNvbnN0IG9wdGlvbnMgPSBjcmVhdGUoKTtcbiAgICAgICAgICAgICAgICBpZiAocHJvcHMubG9jYWxlKSB7XG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnMubG9jYWxlID0gcHJvcHMubG9jYWxlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAocHJvcHMucGx1cmFsICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9ucy5wbHVyYWwgPSBpc1N0cmluZyhwcm9wcy5wbHVyYWwpID8gK3Byb3BzLnBsdXJhbCA6IHByb3BzLnBsdXJhbDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgYXJnID0gZ2V0SW50ZXJwb2xhdGVBcmcoY29udGV4dCwga2V5cyk7XG4gICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbiAgICAgICAgICAgICAgICByZXR1cm4gaTE4bltUcmFuc2xhdGVWTm9kZVN5bWJvbF0ocHJvcHMua2V5cGF0aCwgYXJnLCBvcHRpb25zKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBjb25zdCBhc3NpZ25lZEF0dHJzID0gYXNzaWduKGNyZWF0ZSgpLCBhdHRycyk7XG4gICAgICAgICAgICBjb25zdCB0YWcgPSBpc1N0cmluZyhwcm9wcy50YWcpIHx8IGlzT2JqZWN0KHByb3BzLnRhZylcbiAgICAgICAgICAgICAgICA/IHByb3BzLnRhZ1xuICAgICAgICAgICAgICAgIDogZ2V0RnJhZ21lbnRhYmxlVGFnKCk7XG4gICAgICAgICAgICByZXR1cm4gaXNPYmplY3QodGFnKVxuICAgICAgICAgICAgICAgID8gaCh0YWcsIGFzc2lnbmVkQXR0cnMsIHsgZGVmYXVsdDogcmVuZGVyQ2hpbGRyZW4gfSlcbiAgICAgICAgICAgICAgICA6IGgodGFnLCBhc3NpZ25lZEF0dHJzLCByZW5kZXJDaGlsZHJlbigpKTtcbiAgICAgICAgfTtcbiAgICB9XG59KTtcbi8qKlxuICogZXhwb3J0IHRoZSBwdWJsaWMgdHlwZSBmb3IgaC90c3ggaW5mZXJlbmNlXG4gKiBhbHNvIHRvIGF2b2lkIGlubGluZSBpbXBvcnQoKSBpbiBnZW5lcmF0ZWQgZC50cyBmaWxlc1xuICovXG4vKipcbiAqIFRyYW5zbGF0aW9uIENvbXBvbmVudFxuICpcbiAqIEByZW1hcmtzXG4gKiBTZWUgdGhlIGZvbGxvd2luZyBpdGVtcyBmb3IgcHJvcGVydHkgYWJvdXQgZGV0YWlsc1xuICpcbiAqIEBWdWVJMThuU2VlIFtUcmFuc2xhdGlvblByb3BzXShjb21wb25lbnQjdHJhbnNsYXRpb25wcm9wcylcbiAqIEBWdWVJMThuU2VlIFtCYXNlRm9ybWF0UHJvcHNdKGNvbXBvbmVudCNiYXNlZm9ybWF0cHJvcHMpXG4gKiBAVnVlSTE4blNlZSBbQ29tcG9uZW50IEludGVycG9sYXRpb25dKC4uL2d1aWRlL2FkdmFuY2VkL2NvbXBvbmVudClcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgaHRtbFxuICogPGRpdiBpZD1cImFwcFwiPlxuICogICA8IS0tIC4uLiAtLT5cbiAqICAgPGkxOG4ga2V5cGF0aD1cInRlcm1cIiB0YWc9XCJsYWJlbFwiIGZvcj1cInRvc1wiPlxuICogICAgIDxhIDpocmVmPVwidXJsXCIgdGFyZ2V0PVwiX2JsYW5rXCI+e3sgJHQoJ3RvcycpIH19PC9hPlxuICogICA8L2kxOG4+XG4gKiAgIDwhLS0gLi4uIC0tPlxuICogPC9kaXY+XG4gKiBgYGBcbiAqIGBgYGpzXG4gKiBpbXBvcnQgeyBjcmVhdGVBcHAgfSBmcm9tICd2dWUnXG4gKiBpbXBvcnQgeyBjcmVhdGVJMThuIH0gZnJvbSAndnVlLWkxOG4nXG4gKlxuICogY29uc3QgbWVzc2FnZXMgPSB7XG4gKiAgIGVuOiB7XG4gKiAgICAgdG9zOiAnVGVybSBvZiBTZXJ2aWNlJyxcbiAqICAgICB0ZXJtOiAnSSBhY2NlcHQgeHh4IHswfS4nXG4gKiAgIH0sXG4gKiAgIGphOiB7XG4gKiAgICAgdG9zOiAn5Yip55So6KaP57SEJyxcbiAqICAgICB0ZXJtOiAn56eB44GvIHh4eCDjga57MH3jgavlkIzmhI/jgZfjgb7jgZnjgIInXG4gKiAgIH1cbiAqIH1cbiAqXG4gKiBjb25zdCBpMThuID0gY3JlYXRlSTE4bih7XG4gKiAgIGxvY2FsZTogJ2VuJyxcbiAqICAgbWVzc2FnZXNcbiAqIH0pXG4gKlxuICogY29uc3QgYXBwID0gY3JlYXRlQXBwKHtcbiAqICAgZGF0YToge1xuICogICAgIHVybDogJy90ZXJtJ1xuICogICB9XG4gKiB9KS51c2UoaTE4bikubW91bnQoJyNhcHAnKVxuICogYGBgXG4gKlxuICogQFZ1ZUkxOG5Db21wb25lbnRcbiAqL1xuY29uc3QgVHJhbnNsYXRpb24gPSBUcmFuc2xhdGlvbkltcGw7XG5jb25zdCBJMThuVCA9IFRyYW5zbGF0aW9uO1xuXG5mdW5jdGlvbiBpc1ZOb2RlKHRhcmdldCkge1xuICAgIHJldHVybiBpc0FycmF5KHRhcmdldCkgJiYgIWlzU3RyaW5nKHRhcmdldFswXSk7XG59XG5mdW5jdGlvbiByZW5kZXJGb3JtYXR0ZXIocHJvcHMsIGNvbnRleHQsIHNsb3RLZXlzLCBwYXJ0Rm9ybWF0dGVyKSB7XG4gICAgY29uc3QgeyBzbG90cywgYXR0cnMgfSA9IGNvbnRleHQ7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgY29uc3QgcmVuZGVyQ2hpbGRyZW4gPSAoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBvcHRpb25zID0geyBwYXJ0OiB0cnVlIH07XG4gICAgICAgICAgICBsZXQgb3ZlcnJpZGVzID0gY3JlYXRlKCk7XG4gICAgICAgICAgICBpZiAocHJvcHMubG9jYWxlKSB7XG4gICAgICAgICAgICAgICAgb3B0aW9ucy5sb2NhbGUgPSBwcm9wcy5sb2NhbGU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaXNTdHJpbmcocHJvcHMuZm9ybWF0KSkge1xuICAgICAgICAgICAgICAgIG9wdGlvbnMua2V5ID0gcHJvcHMuZm9ybWF0O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoaXNPYmplY3QocHJvcHMuZm9ybWF0KSkge1xuICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICAgICAgICAgICAgaWYgKGlzU3RyaW5nKHByb3BzLmZvcm1hdC5rZXkpKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICAgICAgICAgICAgICAgIG9wdGlvbnMua2V5ID0gcHJvcHMuZm9ybWF0LmtleTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gRmlsdGVyIG91dCBudW1iZXIgZm9ybWF0IG9wdGlvbnMgb25seVxuICAgICAgICAgICAgICAgIG92ZXJyaWRlcyA9IE9iamVjdC5rZXlzKHByb3BzLmZvcm1hdCkucmVkdWNlKChvcHRpb25zLCBwcm9wKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBzbG90S2V5cy5pbmNsdWRlcyhwcm9wKVxuICAgICAgICAgICAgICAgICAgICAgICAgPyBhc3NpZ24oY3JlYXRlKCksIG9wdGlvbnMsIHsgW3Byb3BdOiBwcm9wcy5mb3JtYXRbcHJvcF0gfSkgLy8gZXNsaW50LWRpc2FibGUtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICAgICAgICAgICAgICAgICAgICA6IG9wdGlvbnM7XG4gICAgICAgICAgICAgICAgfSwgY3JlYXRlKCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgcGFydHMgPSBwYXJ0Rm9ybWF0dGVyKC4uLltwcm9wcy52YWx1ZSwgb3B0aW9ucywgb3ZlcnJpZGVzXSk7XG4gICAgICAgICAgICBsZXQgY2hpbGRyZW4gPSBbb3B0aW9ucy5rZXldO1xuICAgICAgICAgICAgaWYgKGlzQXJyYXkocGFydHMpKSB7XG4gICAgICAgICAgICAgICAgY2hpbGRyZW4gPSBwYXJ0cy5tYXAoKHBhcnQsIGluZGV4KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHNsb3QgPSBzbG90c1twYXJ0LnR5cGVdO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBub2RlID0gc2xvdFxuICAgICAgICAgICAgICAgICAgICAgICAgPyBzbG90KHsgW3BhcnQudHlwZV06IHBhcnQudmFsdWUsIGluZGV4LCBwYXJ0cyB9KVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBbcGFydC52YWx1ZV07XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc1ZOb2RlKG5vZGUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBub2RlWzBdLmtleSA9IGAke3BhcnQudHlwZX0tJHtpbmRleH1gO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBub2RlO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoaXNTdHJpbmcocGFydHMpKSB7XG4gICAgICAgICAgICAgICAgY2hpbGRyZW4gPSBbcGFydHNdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGNoaWxkcmVuO1xuICAgICAgICB9O1xuICAgICAgICBjb25zdCBhc3NpZ25lZEF0dHJzID0gYXNzaWduKGNyZWF0ZSgpLCBhdHRycyk7XG4gICAgICAgIGNvbnN0IHRhZyA9IGlzU3RyaW5nKHByb3BzLnRhZykgfHwgaXNPYmplY3QocHJvcHMudGFnKVxuICAgICAgICAgICAgPyBwcm9wcy50YWdcbiAgICAgICAgICAgIDogZ2V0RnJhZ21lbnRhYmxlVGFnKCk7XG4gICAgICAgIHJldHVybiBpc09iamVjdCh0YWcpXG4gICAgICAgICAgICA/IGgodGFnLCBhc3NpZ25lZEF0dHJzLCB7IGRlZmF1bHQ6IHJlbmRlckNoaWxkcmVuIH0pXG4gICAgICAgICAgICA6IGgodGFnLCBhc3NpZ25lZEF0dHJzLCByZW5kZXJDaGlsZHJlbigpKTtcbiAgICB9O1xufVxuXG5jb25zdCBOdW1iZXJGb3JtYXRJbXBsID0gLyojX19QVVJFX18qLyBkZWZpbmVDb21wb25lbnQoe1xuICAgIC8qIGVzbGludC1kaXNhYmxlICovXG4gICAgbmFtZTogJ2kxOG4tbicsXG4gICAgcHJvcHM6IGFzc2lnbih7XG4gICAgICAgIHZhbHVlOiB7XG4gICAgICAgICAgICB0eXBlOiBOdW1iZXIsXG4gICAgICAgICAgICByZXF1aXJlZDogdHJ1ZVxuICAgICAgICB9LFxuICAgICAgICBmb3JtYXQ6IHtcbiAgICAgICAgICAgIHR5cGU6IFtTdHJpbmcsIE9iamVjdF1cbiAgICAgICAgfVxuICAgIH0sIGJhc2VGb3JtYXRQcm9wcyksXG4gICAgLyogZXNsaW50LWVuYWJsZSAqL1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgc2V0dXAocHJvcHMsIGNvbnRleHQpIHtcbiAgICAgICAgY29uc3QgaTE4biA9IHByb3BzLmkxOG4gfHxcbiAgICAgICAgICAgIHVzZUkxOG4oe1xuICAgICAgICAgICAgICAgIHVzZVNjb3BlOiBwcm9wcy5zY29wZSxcbiAgICAgICAgICAgICAgICBfX3VzZUNvbXBvbmVudDogdHJ1ZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZW5kZXJGb3JtYXR0ZXIocHJvcHMsIGNvbnRleHQsIE5VTUJFUl9GT1JNQVRfT1BUSU9OU19LRVlTLCAoLi4uYXJncykgPT4gXG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICAgIGkxOG5bTnVtYmVyUGFydHNTeW1ib2xdKC4uLmFyZ3MpKTtcbiAgICB9XG59KTtcbi8qKlxuICogZXhwb3J0IHRoZSBwdWJsaWMgdHlwZSBmb3IgaC90c3ggaW5mZXJlbmNlXG4gKiBhbHNvIHRvIGF2b2lkIGlubGluZSBpbXBvcnQoKSBpbiBnZW5lcmF0ZWQgZC50cyBmaWxlc1xuICovXG4vKipcbiAqIE51bWJlciBGb3JtYXQgQ29tcG9uZW50XG4gKlxuICogQHJlbWFya3NcbiAqIFNlZSB0aGUgZm9sbG93aW5nIGl0ZW1zIGZvciBwcm9wZXJ0eSBhYm91dCBkZXRhaWxzXG4gKlxuICogQFZ1ZUkxOG5TZWUgW0Zvcm1hdHRhYmxlUHJvcHNdKGNvbXBvbmVudCNmb3JtYXR0YWJsZXByb3BzKVxuICogQFZ1ZUkxOG5TZWUgW0Jhc2VGb3JtYXRQcm9wc10oY29tcG9uZW50I2Jhc2Vmb3JtYXRwcm9wcylcbiAqIEBWdWVJMThuU2VlIFtDdXN0b20gRm9ybWF0dGluZ10oLi4vZ3VpZGUvZXNzZW50aWFscy9udW1iZXIjY3VzdG9tLWZvcm1hdHRpbmcpXG4gKlxuICogQFZ1ZUkxOG5EYW5nZXJcbiAqIE5vdCBzdXBwb3J0ZWQgSUUsIGR1ZSB0byBubyBzdXBwb3J0IGBJbnRsLk51bWJlckZvcm1hdCNmb3JtYXRUb1BhcnRzYCBpbiBbSUVdKGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0phdmFTY3JpcHQvUmVmZXJlbmNlL0dsb2JhbF9PYmplY3RzL0ludGwvTnVtYmVyRm9ybWF0L2Zvcm1hdFRvUGFydHMpXG4gKlxuICogSWYgeW91IHdhbnQgdG8gdXNlIGl0LCB5b3UgbmVlZCB0byB1c2UgW3BvbHlmaWxsXShodHRwczovL2dpdGh1Yi5jb20vZm9ybWF0anMvZm9ybWF0anMvdHJlZS9tYWluL3BhY2thZ2VzL2ludGwtbnVtYmVyZm9ybWF0KVxuICpcbiAqIEBWdWVJMThuQ29tcG9uZW50XG4gKi9cbmNvbnN0IE51bWJlckZvcm1hdCA9IE51bWJlckZvcm1hdEltcGw7XG5jb25zdCBJMThuTiA9IE51bWJlckZvcm1hdDtcblxuZnVuY3Rpb24gZ2V0Q29tcG9zZXIkMShpMThuLCBpbnN0YW5jZSkge1xuICAgIGNvbnN0IGkxOG5JbnRlcm5hbCA9IGkxOG47XG4gICAgaWYgKGkxOG4ubW9kZSA9PT0gJ2NvbXBvc2l0aW9uJykge1xuICAgICAgICByZXR1cm4gKGkxOG5JbnRlcm5hbC5fX2dldEluc3RhbmNlKGluc3RhbmNlKSB8fCBpMThuLmdsb2JhbCk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBjb25zdCB2dWVJMThuID0gaTE4bkludGVybmFsLl9fZ2V0SW5zdGFuY2UoaW5zdGFuY2UpO1xuICAgICAgICByZXR1cm4gdnVlSTE4biAhPSBudWxsXG4gICAgICAgICAgICA/IHZ1ZUkxOG4uX19jb21wb3NlclxuICAgICAgICAgICAgOiBpMThuLmdsb2JhbC5fX2NvbXBvc2VyO1xuICAgIH1cbn1cbi8qKlxuICogQGRlcHJlY2F0ZWQgd2lsbCBiZSByZW1vdmVkIGF0IHZ1ZS1pMThuIHYxMlxuICovXG5mdW5jdGlvbiB2VERpcmVjdGl2ZShpMThuKSB7XG4gICAgY29uc3QgX3Byb2Nlc3MgPSAoYmluZGluZykgPT4ge1xuICAgICAgICBpZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpKSB7XG4gICAgICAgICAgICB3YXJuT25jZShnZXRXYXJuTWVzc2FnZShJMThuV2FybkNvZGVzLkRFUFJFQ0FURV9UUkFOU0xBVEVfQ1VTVE9NRV9ESVJFQ1RJVkUpKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB7IGluc3RhbmNlLCB2YWx1ZSB9ID0gYmluZGluZztcbiAgICAgICAgLyogaXN0YW5idWwgaWdub3JlIGlmICovXG4gICAgICAgIGlmICghaW5zdGFuY2UgfHwgIWluc3RhbmNlLiQpIHtcbiAgICAgICAgICAgIHRocm93IGNyZWF0ZUkxOG5FcnJvcihJMThuRXJyb3JDb2Rlcy5VTkVYUEVDVEVEX0VSUk9SKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjb21wb3NlciA9IGdldENvbXBvc2VyJDEoaTE4biwgaW5zdGFuY2UuJCk7XG4gICAgICAgIGNvbnN0IHBhcnNlZFZhbHVlID0gcGFyc2VWYWx1ZSh2YWx1ZSk7XG4gICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICBSZWZsZWN0LmFwcGx5KGNvbXBvc2VyLnQsIGNvbXBvc2VyLCBbLi4ubWFrZVBhcmFtcyhwYXJzZWRWYWx1ZSldKSxcbiAgICAgICAgICAgIGNvbXBvc2VyXG4gICAgICAgIF07XG4gICAgfTtcbiAgICBjb25zdCByZWdpc3RlciA9IChlbCwgYmluZGluZykgPT4ge1xuICAgICAgICBjb25zdCBbdGV4dENvbnRlbnQsIGNvbXBvc2VyXSA9IF9wcm9jZXNzKGJpbmRpbmcpO1xuICAgICAgICBpZiAoaW5Ccm93c2VyKSB7XG4gICAgICAgICAgICBlbC5fX2kxOG5XYXRjaGVyID0gd2F0Y2goY29tcG9zZXIubG9jYWxlLCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgYmluZGluZy5pbnN0YW5jZSAmJiBiaW5kaW5nLmluc3RhbmNlLiRmb3JjZVVwZGF0ZSgpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWwuX19jb21wb3NlciA9IGNvbXBvc2VyO1xuICAgICAgICBlbC50ZXh0Q29udGVudCA9IHRleHRDb250ZW50O1xuICAgIH07XG4gICAgY29uc3QgdW5yZWdpc3RlciA9IChlbCkgPT4ge1xuICAgICAgICBpZiAoaW5Ccm93c2VyICYmIGVsLl9faTE4bldhdGNoZXIpIHtcbiAgICAgICAgICAgIGVsLl9faTE4bldhdGNoZXIoKTtcbiAgICAgICAgICAgIGVsLl9faTE4bldhdGNoZXIgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICBkZWxldGUgZWwuX19pMThuV2F0Y2hlcjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZWwuX19jb21wb3Nlcikge1xuICAgICAgICAgICAgZWwuX19jb21wb3NlciA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIGRlbGV0ZSBlbC5fX2NvbXBvc2VyO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCB1cGRhdGUgPSAoZWwsIHsgdmFsdWUgfSkgPT4ge1xuICAgICAgICBpZiAoZWwuX19jb21wb3Nlcikge1xuICAgICAgICAgICAgY29uc3QgY29tcG9zZXIgPSBlbC5fX2NvbXBvc2VyO1xuICAgICAgICAgICAgY29uc3QgcGFyc2VkVmFsdWUgPSBwYXJzZVZhbHVlKHZhbHVlKTtcbiAgICAgICAgICAgIGVsLnRleHRDb250ZW50ID0gUmVmbGVjdC5hcHBseShjb21wb3Nlci50LCBjb21wb3NlciwgW1xuICAgICAgICAgICAgICAgIC4uLm1ha2VQYXJhbXMocGFyc2VkVmFsdWUpXG4gICAgICAgICAgICBdKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgZ2V0U1NSUHJvcHMgPSAoYmluZGluZykgPT4ge1xuICAgICAgICBjb25zdCBbdGV4dENvbnRlbnRdID0gX3Byb2Nlc3MoYmluZGluZyk7XG4gICAgICAgIHJldHVybiB7IHRleHRDb250ZW50IH07XG4gICAgfTtcbiAgICByZXR1cm4ge1xuICAgICAgICBjcmVhdGVkOiByZWdpc3RlcixcbiAgICAgICAgdW5tb3VudGVkOiB1bnJlZ2lzdGVyLFxuICAgICAgICBiZWZvcmVVcGRhdGU6IHVwZGF0ZSxcbiAgICAgICAgZ2V0U1NSUHJvcHNcbiAgICB9O1xufVxuZnVuY3Rpb24gcGFyc2VWYWx1ZSh2YWx1ZSkge1xuICAgIGlmIChpc1N0cmluZyh2YWx1ZSkpIHtcbiAgICAgICAgcmV0dXJuIHsgcGF0aDogdmFsdWUgfTtcbiAgICB9XG4gICAgZWxzZSBpZiAoaXNQbGFpbk9iamVjdCh2YWx1ZSkpIHtcbiAgICAgICAgaWYgKCEoJ3BhdGgnIGluIHZhbHVlKSkge1xuICAgICAgICAgICAgdGhyb3cgY3JlYXRlSTE4bkVycm9yKEkxOG5FcnJvckNvZGVzLlJFUVVJUkVEX1ZBTFVFLCAncGF0aCcpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHRocm93IGNyZWF0ZUkxOG5FcnJvcihJMThuRXJyb3JDb2Rlcy5JTlZBTElEX1ZBTFVFKTtcbiAgICB9XG59XG5mdW5jdGlvbiBtYWtlUGFyYW1zKHZhbHVlKSB7XG4gICAgY29uc3QgeyBwYXRoLCBsb2NhbGUsIGFyZ3MsIGNob2ljZSwgcGx1cmFsIH0gPSB2YWx1ZTtcbiAgICBjb25zdCBvcHRpb25zID0ge307XG4gICAgY29uc3QgbmFtZWQgPSBhcmdzIHx8IHt9O1xuICAgIGlmIChpc1N0cmluZyhsb2NhbGUpKSB7XG4gICAgICAgIG9wdGlvbnMubG9jYWxlID0gbG9jYWxlO1xuICAgIH1cbiAgICBpZiAoaXNOdW1iZXIoY2hvaWNlKSkge1xuICAgICAgICBvcHRpb25zLnBsdXJhbCA9IGNob2ljZTtcbiAgICB9XG4gICAgaWYgKGlzTnVtYmVyKHBsdXJhbCkpIHtcbiAgICAgICAgb3B0aW9ucy5wbHVyYWwgPSBwbHVyYWw7XG4gICAgfVxuICAgIHJldHVybiBbcGF0aCwgbmFtZWQsIG9wdGlvbnNdO1xufVxuXG5mdW5jdGlvbiBhcHBseShhcHAsIGkxOG4sIC4uLm9wdGlvbnMpIHtcbiAgICBjb25zdCBwbHVnaW5PcHRpb25zID0gaXNQbGFpbk9iamVjdChvcHRpb25zWzBdKVxuICAgICAgICA/IG9wdGlvbnNbMF1cbiAgICAgICAgOiB7fTtcbiAgICBjb25zdCBnbG9iYWxJbnN0YWxsID0gaXNCb29sZWFuKHBsdWdpbk9wdGlvbnMuZ2xvYmFsSW5zdGFsbClcbiAgICAgICAgPyBwbHVnaW5PcHRpb25zLmdsb2JhbEluc3RhbGxcbiAgICAgICAgOiB0cnVlO1xuICAgIGlmIChnbG9iYWxJbnN0YWxsKSB7XG4gICAgICAgIFtUcmFuc2xhdGlvbi5uYW1lLCAnSTE4blQnXS5mb3JFYWNoKG5hbWUgPT4gYXBwLmNvbXBvbmVudChuYW1lLCBUcmFuc2xhdGlvbikpO1xuICAgICAgICBbTnVtYmVyRm9ybWF0Lm5hbWUsICdJMThuTiddLmZvckVhY2gobmFtZSA9PiBhcHAuY29tcG9uZW50KG5hbWUsIE51bWJlckZvcm1hdCkpO1xuICAgICAgICBbRGF0ZXRpbWVGb3JtYXQubmFtZSwgJ0kxOG5EJ10uZm9yRWFjaChuYW1lID0+IGFwcC5jb21wb25lbnQobmFtZSwgRGF0ZXRpbWVGb3JtYXQpKTtcbiAgICB9XG4gICAgLy8gaW5zdGFsbCBkaXJlY3RpdmVcbiAgICB7XG4gICAgICAgIGFwcC5kaXJlY3RpdmUoJ3QnLCB2VERpcmVjdGl2ZShpMThuKSk7XG4gICAgfVxufVxuXG4vKipcbiAqIEluamVjdGlvbiBrZXkgZm9yIHtAbGluayB1c2VJMThufVxuICpcbiAqIEByZW1hcmtzXG4gKiBUaGUgZ2xvYmFsIGluamVjdGlvbiBrZXkgZm9yIEkxOG4gaW5zdGFuY2VzIHdpdGggYHVzZUkxOG5gLiB0aGlzIGluamVjdGlvbiBrZXkgaXMgdXNlZCBpbiBXZWIgQ29tcG9uZW50cy5cbiAqIFNwZWNpZnkgdGhlIGkxOG4gaW5zdGFuY2UgY3JlYXRlZCBieSB7QGxpbmsgY3JlYXRlSTE4bn0gdG9nZXRoZXIgd2l0aCBgcHJvdmlkZWAgZnVuY3Rpb24uXG4gKlxuICogQFZ1ZUkxOG5HZW5lcmFsXG4gKi9cbmNvbnN0IEkxOG5JbmplY3Rpb25LZXkgPSBcbi8qICNfX1BVUkVfXyovIG1ha2VTeW1ib2woJ2dsb2JhbC12dWUtaTE4bicpO1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbmZ1bmN0aW9uIGNyZWF0ZUkxOG4ob3B0aW9ucyA9IHt9KSB7XG4gICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgY29uc3QgX19sZWdhY3lNb2RlID0gX19WVUVfSTE4Tl9MRUdBQ1lfQVBJX18gJiYgaXNCb29sZWFuKG9wdGlvbnMubGVnYWN5KVxuICAgICAgICAgICAgPyBvcHRpb25zLmxlZ2FjeVxuICAgICAgICAgICAgOiBfX1ZVRV9JMThOX0xFR0FDWV9BUElfXztcbiAgICBpZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpICYmIF9fbGVnYWN5TW9kZSkge1xuICAgICAgICB3YXJuT25jZShnZXRXYXJuTWVzc2FnZShJMThuV2FybkNvZGVzLkRFUFJFQ0FURV9MRUdBQ1lfTU9ERSkpO1xuICAgIH1cbiAgICAvLyBwcmV0dGllci1pZ25vcmVcbiAgICBjb25zdCBfX2dsb2JhbEluamVjdGlvbiA9IGlzQm9vbGVhbihvcHRpb25zLmdsb2JhbEluamVjdGlvbilcbiAgICAgICAgPyBvcHRpb25zLmdsb2JhbEluamVjdGlvblxuICAgICAgICA6IHRydWU7XG4gICAgY29uc3QgX19pbnN0YW5jZXMgPSBuZXcgTWFwKCk7XG4gICAgY29uc3QgW2dsb2JhbFNjb3BlLCBfX2dsb2JhbF0gPSBjcmVhdGVHbG9iYWwob3B0aW9ucywgX19sZWdhY3lNb2RlKTtcbiAgICBjb25zdCBzeW1ib2wgPSAvKiAjX19QVVJFX18qLyBtYWtlU3ltYm9sKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSA/ICd2dWUtaTE4bicgOiAnJyk7XG4gICAgZnVuY3Rpb24gX19nZXRJbnN0YW5jZShjb21wb25lbnQpIHtcbiAgICAgICAgcmV0dXJuIF9faW5zdGFuY2VzLmdldChjb21wb25lbnQpIHx8IG51bGw7XG4gICAgfVxuICAgIGZ1bmN0aW9uIF9fc2V0SW5zdGFuY2UoY29tcG9uZW50LCBpbnN0YW5jZSkge1xuICAgICAgICBfX2luc3RhbmNlcy5zZXQoY29tcG9uZW50LCBpbnN0YW5jZSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIF9fZGVsZXRlSW5zdGFuY2UoY29tcG9uZW50KSB7XG4gICAgICAgIF9faW5zdGFuY2VzLmRlbGV0ZShjb21wb25lbnQpO1xuICAgIH1cbiAgICBjb25zdCBpMThuID0ge1xuICAgICAgICAvLyBtb2RlXG4gICAgICAgIGdldCBtb2RlKCkge1xuICAgICAgICAgICAgcmV0dXJuIF9fVlVFX0kxOE5fTEVHQUNZX0FQSV9fICYmIF9fbGVnYWN5TW9kZVxuICAgICAgICAgICAgICAgID8gJ2xlZ2FjeSdcbiAgICAgICAgICAgICAgICA6ICdjb21wb3NpdGlvbic7XG4gICAgICAgIH0sXG4gICAgICAgIC8vIGluc3RhbGwgcGx1Z2luXG4gICAgICAgIGFzeW5jIGluc3RhbGwoYXBwLCAuLi5vcHRpb25zKSB7XG4gICAgICAgICAgICBpZiAoKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pICYmIHRydWUpIHtcbiAgICAgICAgICAgICAgICBhcHAuX19WVUVfSTE4Tl9fID0gaTE4bjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIHNldHVwIGdsb2JhbCBwcm92aWRlclxuICAgICAgICAgICAgYXBwLl9fVlVFX0kxOE5fU1lNQk9MX18gPSBzeW1ib2w7XG4gICAgICAgICAgICBhcHAucHJvdmlkZShhcHAuX19WVUVfSTE4Tl9TWU1CT0xfXywgaTE4bik7XG4gICAgICAgICAgICAvLyBzZXQgY29tcG9zZXIgJiB2dWVpMThuIGV4dGVuZCBob29rIG9wdGlvbnMgZnJvbSBwbHVnaW4gb3B0aW9uc1xuICAgICAgICAgICAgaWYgKGlzUGxhaW5PYmplY3Qob3B0aW9uc1swXSkpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBvcHRzID0gb3B0aW9uc1swXTtcbiAgICAgICAgICAgICAgICBpMThuLl9fY29tcG9zZXJFeHRlbmQgPVxuICAgICAgICAgICAgICAgICAgICBvcHRzLl9fY29tcG9zZXJFeHRlbmQ7XG4gICAgICAgICAgICAgICAgaTE4bi5fX3Z1ZUkxOG5FeHRlbmQgPVxuICAgICAgICAgICAgICAgICAgICBvcHRzLl9fdnVlSTE4bkV4dGVuZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIGdsb2JhbCBtZXRob2QgYW5kIHByb3BlcnRpZXMgaW5qZWN0aW9uIGZvciBDb21wb3NpdGlvbiBBUElcbiAgICAgICAgICAgIGxldCBnbG9iYWxSZWxlYXNlSGFuZGxlciA9IG51bGw7XG4gICAgICAgICAgICBpZiAoIV9fbGVnYWN5TW9kZSAmJiBfX2dsb2JhbEluamVjdGlvbikge1xuICAgICAgICAgICAgICAgIGdsb2JhbFJlbGVhc2VIYW5kbGVyID0gaW5qZWN0R2xvYmFsRmllbGRzKGFwcCwgaTE4bi5nbG9iYWwpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gaW5zdGFsbCBidWlsdC1pbiBjb21wb25lbnRzIGFuZCBkaXJlY3RpdmVcbiAgICAgICAgICAgIGlmIChfX1ZVRV9JMThOX0ZVTExfSU5TVEFMTF9fKSB7XG4gICAgICAgICAgICAgICAgYXBwbHkoYXBwLCBpMThuLCAuLi5vcHRpb25zKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIHNldHVwIG1peGluIGZvciBMZWdhY3kgQVBJXG4gICAgICAgICAgICBpZiAoX19WVUVfSTE4Tl9MRUdBQ1lfQVBJX18gJiYgX19sZWdhY3lNb2RlKSB7XG4gICAgICAgICAgICAgICAgYXBwLm1peGluKGRlZmluZU1peGluKF9fZ2xvYmFsLCBfX2dsb2JhbC5fX2NvbXBvc2VyLCBpMThuKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyByZWxlYXNlIGdsb2JhbCBzY29wZVxuICAgICAgICAgICAgY29uc3QgdW5tb3VudEFwcCA9IGFwcC51bm1vdW50O1xuICAgICAgICAgICAgYXBwLnVubW91bnQgPSAoKSA9PiB7XG4gICAgICAgICAgICAgICAgZ2xvYmFsUmVsZWFzZUhhbmRsZXIgJiYgZ2xvYmFsUmVsZWFzZUhhbmRsZXIoKTtcbiAgICAgICAgICAgICAgICBpMThuLmRpc3Bvc2UoKTtcbiAgICAgICAgICAgICAgICB1bm1vdW50QXBwKCk7XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgLy8gc2V0dXAgdnVlLWRldnRvb2xzIHBsdWdpblxuICAgICAgICAgICAgaWYgKCgocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgfHwgX19WVUVfUFJPRF9ERVZUT09MU19fKSAmJiB0cnVlKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmV0ID0gYXdhaXQgZW5hYmxlRGV2VG9vbHMoYXBwLCBpMThuKTtcbiAgICAgICAgICAgICAgICBpZiAoIXJldCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBjcmVhdGVJMThuRXJyb3IoSTE4bkVycm9yQ29kZXMuQ0FOTk9UX1NFVFVQX1ZVRV9ERVZUT09MU19QTFVHSU4pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBlbWl0dGVyID0gY3JlYXRlRW1pdHRlcigpO1xuICAgICAgICAgICAgICAgIGlmIChfX2xlZ2FjeU1vZGUpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgX3Z1ZUkxOG4gPSBfX2dsb2JhbDtcbiAgICAgICAgICAgICAgICAgICAgX3Z1ZUkxOG4uX19lbmFibGVFbWl0dGVyICYmIF92dWVJMThuLl9fZW5hYmxlRW1pdHRlcihlbWl0dGVyKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IF9jb21wb3NlciA9IF9fZ2xvYmFsO1xuICAgICAgICAgICAgICAgICAgICBfY29tcG9zZXJbRW5hYmxlRW1pdHRlcl0gJiYgX2NvbXBvc2VyW0VuYWJsZUVtaXR0ZXJdKGVtaXR0ZXIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbWl0dGVyLm9uKCcqJywgYWRkVGltZWxpbmVFdmVudCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIC8vIGdsb2JhbCBhY2Nlc3NvclxuICAgICAgICBnZXQgZ2xvYmFsKCkge1xuICAgICAgICAgICAgcmV0dXJuIF9fZ2xvYmFsO1xuICAgICAgICB9LFxuICAgICAgICBkaXNwb3NlKCkge1xuICAgICAgICAgICAgZ2xvYmFsU2NvcGUuc3RvcCgpO1xuICAgICAgICB9LFxuICAgICAgICAvLyBAaW50ZXJuYWxcbiAgICAgICAgX19pbnN0YW5jZXMsXG4gICAgICAgIC8vIEBpbnRlcm5hbFxuICAgICAgICBfX2dldEluc3RhbmNlLFxuICAgICAgICAvLyBAaW50ZXJuYWxcbiAgICAgICAgX19zZXRJbnN0YW5jZSxcbiAgICAgICAgLy8gQGludGVybmFsXG4gICAgICAgIF9fZGVsZXRlSW5zdGFuY2VcbiAgICB9O1xuICAgIHJldHVybiBpMThuO1xufVxuZnVuY3Rpb24gdXNlSTE4bihvcHRpb25zID0ge30pIHtcbiAgICBjb25zdCBpbnN0YW5jZSA9IGdldEN1cnJlbnRJbnN0YW5jZSgpO1xuICAgIGlmIChpbnN0YW5jZSA9PSBudWxsKSB7XG4gICAgICAgIHRocm93IGNyZWF0ZUkxOG5FcnJvcihJMThuRXJyb3JDb2Rlcy5NVVNUX0JFX0NBTExfU0VUVVBfVE9QKTtcbiAgICB9XG4gICAgaWYgKCFpbnN0YW5jZS5pc0NFICYmXG4gICAgICAgIGluc3RhbmNlLmFwcENvbnRleHQuYXBwICE9IG51bGwgJiZcbiAgICAgICAgIWluc3RhbmNlLmFwcENvbnRleHQuYXBwLl9fVlVFX0kxOE5fU1lNQk9MX18pIHtcbiAgICAgICAgdGhyb3cgY3JlYXRlSTE4bkVycm9yKEkxOG5FcnJvckNvZGVzLk5PVF9JTlNUQUxMRUQpO1xuICAgIH1cbiAgICBjb25zdCBpMThuID0gZ2V0STE4bkluc3RhbmNlKGluc3RhbmNlKTtcbiAgICBjb25zdCBnbCA9IGdldEdsb2JhbENvbXBvc2VyKGkxOG4pO1xuICAgIGNvbnN0IGNvbXBvbmVudE9wdGlvbnMgPSBnZXRDb21wb25lbnRPcHRpb25zKGluc3RhbmNlKTtcbiAgICBjb25zdCBzY29wZSA9IGdldFNjb3BlKG9wdGlvbnMsIGNvbXBvbmVudE9wdGlvbnMpO1xuICAgIGlmIChzY29wZSA9PT0gJ2dsb2JhbCcpIHtcbiAgICAgICAgYWRqdXN0STE4blJlc291cmNlcyhnbCwgb3B0aW9ucywgY29tcG9uZW50T3B0aW9ucyk7XG4gICAgICAgIHJldHVybiBnbDtcbiAgICB9XG4gICAgaWYgKHNjb3BlID09PSAncGFyZW50Jykge1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgICAgICBsZXQgY29tcG9zZXIgPSBnZXRDb21wb3NlcihpMThuLCBpbnN0YW5jZSwgb3B0aW9ucy5fX3VzZUNvbXBvbmVudCk7XG4gICAgICAgIGlmIChjb21wb3NlciA9PSBudWxsKSB7XG4gICAgICAgICAgICBpZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpKSB7XG4gICAgICAgICAgICAgICAgd2FybihnZXRXYXJuTWVzc2FnZShJMThuV2FybkNvZGVzLk5PVF9GT1VORF9QQVJFTlRfU0NPUEUpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbXBvc2VyID0gZ2w7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNvbXBvc2VyO1xuICAgIH1cbiAgICAvLyBJc29sYXRlZCBzY29wZSAtIGluZGVwZW5kZW50IGNvbXBvc2VyIG5vdCB0aWVkIHRvIGNvbXBvbmVudFxuICAgIGlmIChzY29wZSA9PT0gJ2lzb2xhdGVkJykge1xuICAgICAgICAvLyBDb21wb3NpdGlvbiBBUEkgbW9kZSBvbmx5XG4gICAgICAgIGlmIChpMThuLm1vZGUgIT09ICdjb21wb3NpdGlvbicpIHtcbiAgICAgICAgICAgIHRocm93IGNyZWF0ZUkxOG5FcnJvcihJMThuRXJyb3JDb2Rlcy5OT1RfQVZBSUxBQkxFX0NPTVBPU0lUSU9OX0lOX0xFR0FDWSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgaTE4bkludGVybmFsSXNvID0gaTE4bjtcbiAgICAgICAgY29uc3QgY29tcG9zZXJPcHRpb25zID0gYXNzaWduKHt9LCBvcHRpb25zKTtcbiAgICAgICAgLy8gRmluZCBwYXJlbnQgY29tcG9zZXIgdmlhIHBhcmVudCBjaGFpbiAob3IgZmFsbCBiYWNrIHRvIGdsb2JhbClcbiAgICAgICAgY29uc3QgcGFyZW50Q29tcG9zZXIgPSBnZXRDb21wb3NlcihpMThuLCBpbnN0YW5jZSk7XG4gICAgICAgIGNvbXBvc2VyT3B0aW9ucy5fX3Jvb3QgPSBwYXJlbnRDb21wb3NlciB8fCBnbDtcbiAgICAgICAgY29uc3QgY29tcG9zZXIgPSBjcmVhdGVDb21wb3Nlcihjb21wb3Nlck9wdGlvbnMpO1xuICAgICAgICAvLyBDb21wb3NlckV4dGVuZCBob29rXG4gICAgICAgIGlmIChpMThuSW50ZXJuYWxJc28uX19jb21wb3NlckV4dGVuZCkge1xuICAgICAgICAgICAgY29tcG9zZXJbRGlzcG9zZVN5bWJvbF0gPVxuICAgICAgICAgICAgICAgIGkxOG5JbnRlcm5hbElzby5fX2NvbXBvc2VyRXh0ZW5kKGNvbXBvc2VyKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBTZXR1cCBkZXZ0b29scyBlbWl0dGVyIChubyB0YXJnZXQuX19WVUVfSTE4Tl9fIGF0dGFjaG1lbnQgLVxuICAgICAgICAvLyBtdWx0aXBsZSBpc29sYXRlZCBjb21wb3NlcnMgcGVyIGNvbXBvbmVudCBhcmUgYWxsb3dlZClcbiAgICAgICAgbGV0IGVtaXR0ZXIgPSBudWxsO1xuICAgICAgICBpZiAoKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pICYmIHRydWUpIHtcbiAgICAgICAgICAgIGVtaXR0ZXIgPSBjcmVhdGVFbWl0dGVyKCk7XG4gICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgICAgICAgICAgY29uc3QgX2NvbXBvc2VyID0gY29tcG9zZXI7XG4gICAgICAgICAgICBfY29tcG9zZXJbRW5hYmxlRW1pdHRlcl0gJiYgX2NvbXBvc2VyW0VuYWJsZUVtaXR0ZXJdKGVtaXR0ZXIpO1xuICAgICAgICAgICAgZW1pdHRlci5vbignKicsIGFkZFRpbWVsaW5lRXZlbnQpO1xuICAgICAgICB9XG4gICAgICAgIC8vIExpZmVjeWNsZSBjbGVhbnVwIHZpYSBvblNjb3BlRGlzcG9zZVxuICAgICAgICBjb25zdCBjdXJyZW50U2NvcGUgPSBnZXRDdXJyZW50U2NvcGUoKTtcbiAgICAgICAgaWYgKGN1cnJlbnRTY29wZSkge1xuICAgICAgICAgICAgb25TY29wZURpc3Bvc2UoKCkgPT4ge1xuICAgICAgICAgICAgICAgIGlmICgoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykgJiYgdHJ1ZSkge1xuICAgICAgICAgICAgICAgICAgICBlbWl0dGVyICYmIGVtaXR0ZXIub2ZmKCcqJywgYWRkVGltZWxpbmVFdmVudCk7XG4gICAgICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IF9jb21wb3NlciA9IGNvbXBvc2VyO1xuICAgICAgICAgICAgICAgICAgICBfY29tcG9zZXJbRGlzYWJsZUVtaXR0ZXJdICYmIF9jb21wb3NlcltEaXNhYmxlRW1pdHRlcl0oKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbiAgICAgICAgICAgICAgICBjb25zdCBkaXNwb3NlID0gY29tcG9zZXJbRGlzcG9zZVN5bWJvbF07XG4gICAgICAgICAgICAgICAgaWYgKGRpc3Bvc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgZGlzcG9zZSgpO1xuICAgICAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgICAgICAgICAgICAgICAgICBkZWxldGUgY29tcG9zZXJbRGlzcG9zZVN5bWJvbF07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNvbXBvc2VyO1xuICAgIH1cbiAgICBjb25zdCBpMThuSW50ZXJuYWwgPSBpMThuO1xuICAgIGxldCBjb21wb3NlciA9IGkxOG5JbnRlcm5hbC5fX2dldEluc3RhbmNlKGluc3RhbmNlKTtcbiAgICBpZiAoY29tcG9zZXIgPT0gbnVsbCkge1xuICAgICAgICBjb25zdCBjb21wb3Nlck9wdGlvbnMgPSBhc3NpZ24oe30sIG9wdGlvbnMpO1xuICAgICAgICBpZiAoJ19faTE4bicgaW4gY29tcG9uZW50T3B0aW9ucykge1xuICAgICAgICAgICAgY29tcG9zZXJPcHRpb25zLl9faTE4biA9IGNvbXBvbmVudE9wdGlvbnMuX19pMThuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChnbCkge1xuICAgICAgICAgICAgY29tcG9zZXJPcHRpb25zLl9fcm9vdCA9IGdsO1xuICAgICAgICB9XG4gICAgICAgIGNvbXBvc2VyID0gY3JlYXRlQ29tcG9zZXIoY29tcG9zZXJPcHRpb25zKTtcbiAgICAgICAgaWYgKGkxOG5JbnRlcm5hbC5fX2NvbXBvc2VyRXh0ZW5kKSB7XG4gICAgICAgICAgICBjb21wb3NlcltEaXNwb3NlU3ltYm9sXSA9XG4gICAgICAgICAgICAgICAgaTE4bkludGVybmFsLl9fY29tcG9zZXJFeHRlbmQoY29tcG9zZXIpO1xuICAgICAgICB9XG4gICAgICAgIHNldHVwTGlmZUN5Y2xlKGkxOG5JbnRlcm5hbCwgaW5zdGFuY2UsIGNvbXBvc2VyKTtcbiAgICAgICAgaTE4bkludGVybmFsLl9fc2V0SW5zdGFuY2UoaW5zdGFuY2UsIGNvbXBvc2VyKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGlmICgocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgJiYgc2NvcGUgPT09ICdsb2NhbCcpIHtcbiAgICAgICAgICAgIHdhcm4oZ2V0V2Fybk1lc3NhZ2UoSTE4bldhcm5Db2Rlcy5EVVBMSUNBVEVfVVNFX0kxOE5fQ0FMTElORykpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBjb21wb3Nlcjtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUdsb2JhbChvcHRpb25zLCBsZWdhY3lNb2RlKSB7XG4gICAgY29uc3Qgc2NvcGUgPSBlZmZlY3RTY29wZSgpO1xuICAgIGNvbnN0IG9iaiA9IF9fVlVFX0kxOE5fTEVHQUNZX0FQSV9fICYmIGxlZ2FjeU1vZGVcbiAgICAgICAgPyBzY29wZS5ydW4oKCkgPT4gY3JlYXRlVnVlSTE4bihvcHRpb25zKSlcbiAgICAgICAgOiBzY29wZS5ydW4oKCkgPT4gY3JlYXRlQ29tcG9zZXIob3B0aW9ucykpO1xuICAgIGlmIChvYmogPT0gbnVsbCkge1xuICAgICAgICB0aHJvdyBjcmVhdGVJMThuRXJyb3IoSTE4bkVycm9yQ29kZXMuVU5FWFBFQ1RFRF9FUlJPUik7XG4gICAgfVxuICAgIHJldHVybiBbc2NvcGUsIG9ial07XG59XG5mdW5jdGlvbiBnZXRJMThuSW5zdGFuY2UoaW5zdGFuY2UpIHtcbiAgICBjb25zdCBpMThuID0gaW5qZWN0KCFpbnN0YW5jZS5pc0NFXG4gICAgICAgID8gaW5zdGFuY2UuYXBwQ29udGV4dC5hcHAuX19WVUVfSTE4Tl9TWU1CT0xfX1xuICAgICAgICA6IEkxOG5JbmplY3Rpb25LZXkpO1xuICAgIC8qIGlzdGFuYnVsIGlnbm9yZSBpZiAqL1xuICAgIGlmICghaTE4bikge1xuICAgICAgICB0aHJvdyBjcmVhdGVJMThuRXJyb3IoIWluc3RhbmNlLmlzQ0VcbiAgICAgICAgICAgID8gSTE4bkVycm9yQ29kZXMuVU5FWFBFQ1RFRF9FUlJPUlxuICAgICAgICAgICAgOiBJMThuRXJyb3JDb2Rlcy5OT1RfSU5TVEFMTEVEX1dJVEhfUFJPVklERSk7XG4gICAgfVxuICAgIHJldHVybiBpMThuO1xufVxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbmZ1bmN0aW9uIGdldFNjb3BlKG9wdGlvbnMsIGNvbXBvbmVudE9wdGlvbnMpIHtcbiAgICAvLyBwcmV0dGllci1pZ25vcmVcbiAgICByZXR1cm4gaXNFbXB0eU9iamVjdChvcHRpb25zKVxuICAgICAgICA/ICgnX19pMThuJyBpbiBjb21wb25lbnRPcHRpb25zKVxuICAgICAgICAgICAgPyAnbG9jYWwnXG4gICAgICAgICAgICA6ICdnbG9iYWwnXG4gICAgICAgIDogIW9wdGlvbnMudXNlU2NvcGVcbiAgICAgICAgICAgID8gJ2xvY2FsJ1xuICAgICAgICAgICAgOiBvcHRpb25zLnVzZVNjb3BlO1xufVxuZnVuY3Rpb24gZ2V0R2xvYmFsQ29tcG9zZXIoaTE4bikge1xuICAgIC8vIHByZXR0aWVyLWlnbm9yZVxuICAgIHJldHVybiBpMThuLm1vZGUgPT09ICdjb21wb3NpdGlvbidcbiAgICAgICAgPyBpMThuLmdsb2JhbFxuICAgICAgICA6IGkxOG4uZ2xvYmFsLl9fY29tcG9zZXI7XG59XG5mdW5jdGlvbiBnZXRDb21wb3NlcihpMThuLCB0YXJnZXQsIHVzZUNvbXBvbmVudCA9IGZhbHNlKSB7XG4gICAgbGV0IGNvbXBvc2VyID0gbnVsbDtcbiAgICBjb25zdCByb290ID0gdGFyZ2V0LnJvb3Q7XG4gICAgbGV0IGN1cnJlbnQgPSBnZXRQYXJlbnRDb21wb25lbnRJbnN0YW5jZSh0YXJnZXQsIHVzZUNvbXBvbmVudCk7XG4gICAgd2hpbGUgKGN1cnJlbnQgIT0gbnVsbCkge1xuICAgICAgICBjb25zdCBpMThuSW50ZXJuYWwgPSBpMThuO1xuICAgICAgICBpZiAoaTE4bi5tb2RlID09PSAnY29tcG9zaXRpb24nKSB7XG4gICAgICAgICAgICBjb21wb3NlciA9IGkxOG5JbnRlcm5hbC5fX2dldEluc3RhbmNlKGN1cnJlbnQpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgaWYgKF9fVlVFX0kxOE5fTEVHQUNZX0FQSV9fKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgdnVlSTE4biA9IGkxOG5JbnRlcm5hbC5fX2dldEluc3RhbmNlKGN1cnJlbnQpO1xuICAgICAgICAgICAgICAgIGlmICh2dWVJMThuICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgY29tcG9zZXIgPSB2dWVJMThuXG4gICAgICAgICAgICAgICAgICAgICAgICAuX19jb21wb3NlcjtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHVzZUNvbXBvbmVudCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgY29tcG9zZXIgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICFjb21wb3NlcltJbmVqY3RXaXRoT3B0aW9uU3ltYm9sXSAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbiAgICAgICAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb21wb3NlciA9IG51bGw7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNvbXBvc2VyICE9IG51bGwpIHtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyb290ID09PSBjdXJyZW50KSB7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBjdXJyZW50ID0gY3VycmVudC5wYXJlbnQ7XG4gICAgfVxuICAgIHJldHVybiBjb21wb3Nlcjtcbn1cbmZ1bmN0aW9uIGdldFBhcmVudENvbXBvbmVudEluc3RhbmNlKHRhcmdldCwgdXNlQ29tcG9uZW50ID0gZmFsc2UpIHtcbiAgICBpZiAodGFyZ2V0ID09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIC8vIGlmIGB1c2VDb21wb25lbnQ6IHRydWVgIHdpbGwgYmUgc3BlY2lmaWVkLCB3ZSBnZXQgbGV4aWNhbCBzY29wZSBvd25lciBpbnN0YW5jZSBmb3IgdXNlLWNhc2Ugc2xvdHNcbiAgICByZXR1cm4gIXVzZUNvbXBvbmVudFxuICAgICAgICA/IHRhcmdldC5wYXJlbnRcbiAgICAgICAgOiB0YXJnZXQudm5vZGUuY3R4IHx8IHRhcmdldC5wYXJlbnQ7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxufVxuZnVuY3Rpb24gc2V0dXBMaWZlQ3ljbGUoaTE4biwgdGFyZ2V0LCBjb21wb3Nlcikge1xuICAgIGxldCBlbWl0dGVyID0gbnVsbDtcbiAgICBvbk1vdW50ZWQoKCkgPT4ge1xuICAgICAgICAvLyBpbmplY3QgY29tcG9zZXIgaW5zdGFuY2UgdG8gRE9NIGZvciBpbnRsaWZ5LWRldnRvb2xzXG4gICAgICAgIGlmICgoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykgJiYgdHJ1ZSkge1xuICAgICAgICAgICAgdGFyZ2V0Ll9fVlVFX0kxOE5fXyA9IGNvbXBvc2VyO1xuICAgICAgICAgICAgZW1pdHRlciA9IGNyZWF0ZUVtaXR0ZXIoKTtcbiAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICAgICAgICBjb25zdCBfY29tcG9zZXIgPSBjb21wb3NlcjtcbiAgICAgICAgICAgIF9jb21wb3NlcltFbmFibGVFbWl0dGVyXSAmJiBfY29tcG9zZXJbRW5hYmxlRW1pdHRlcl0oZW1pdHRlcik7XG4gICAgICAgICAgICBlbWl0dGVyLm9uKCcqJywgYWRkVGltZWxpbmVFdmVudCk7XG4gICAgICAgIH1cbiAgICB9LCB0YXJnZXQpO1xuICAgIG9uVW5tb3VudGVkKCgpID0+IHtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbiAgICAgICAgY29uc3QgX2NvbXBvc2VyID0gY29tcG9zZXI7XG4gICAgICAgIC8vIHJlbW92ZSBjb21wb3NlciBpbnN0YW5jZSBmcm9tIERPTSBmb3IgaW50bGlmeS1kZXZ0b29sc1xuICAgICAgICBpZiAoKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pICYmIHRydWUpIHtcbiAgICAgICAgICAgIGVtaXR0ZXIgJiYgZW1pdHRlci5vZmYoJyonLCBhZGRUaW1lbGluZUV2ZW50KTtcbiAgICAgICAgICAgIF9jb21wb3NlcltEaXNhYmxlRW1pdHRlcl0gJiYgX2NvbXBvc2VyW0Rpc2FibGVFbWl0dGVyXSgpO1xuICAgICAgICAgICAgZGVsZXRlIHRhcmdldC5fX1ZVRV9JMThOX187XG4gICAgICAgIH1cbiAgICAgICAgaTE4bi5fX2RlbGV0ZUluc3RhbmNlKHRhcmdldCk7XG4gICAgICAgIC8vIGRpc3Bvc2UgZXh0ZW5kZWQgcmVzb3VyY2VzXG4gICAgICAgIGNvbnN0IGRpc3Bvc2UgPSBfY29tcG9zZXJbRGlzcG9zZVN5bWJvbF07XG4gICAgICAgIGlmIChkaXNwb3NlKSB7XG4gICAgICAgICAgICBkaXNwb3NlKCk7XG4gICAgICAgICAgICBkZWxldGUgX2NvbXBvc2VyW0Rpc3Bvc2VTeW1ib2xdO1xuICAgICAgICB9XG4gICAgfSwgdGFyZ2V0KTtcbn1cbmNvbnN0IGdsb2JhbEV4cG9ydFByb3BzID0gW1xuICAgICdsb2NhbGUnLFxuICAgICdmYWxsYmFja0xvY2FsZScsXG4gICAgJ2F2YWlsYWJsZUxvY2FsZXMnXG5dO1xuY29uc3QgZ2xvYmFsRXhwb3J0TWV0aG9kcyA9IFsndCcsICdydCcsICdkJywgJ24nLCAndG0nLCAndGUnXVxuICAgIDtcbmZ1bmN0aW9uIGluamVjdEdsb2JhbEZpZWxkcyhhcHAsIGNvbXBvc2VyKSB7XG4gICAgY29uc3QgaTE4biA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgZ2xvYmFsRXhwb3J0UHJvcHMuZm9yRWFjaChwcm9wID0+IHtcbiAgICAgICAgY29uc3QgZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoY29tcG9zZXIsIHByb3ApO1xuICAgICAgICBpZiAoIWRlc2MpIHtcbiAgICAgICAgICAgIHRocm93IGNyZWF0ZUkxOG5FcnJvcihJMThuRXJyb3JDb2Rlcy5VTkVYUEVDVEVEX0VSUk9SKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB3cmFwID0gaXNSZWYoZGVzYy52YWx1ZSkgLy8gY2hlY2sgY29tcHV0ZWQgcHJvcHNcbiAgICAgICAgICAgID8ge1xuICAgICAgICAgICAgICAgIGdldCgpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGRlc2MudmFsdWUudmFsdWU7XG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgICAgICAgICAgICAgIHNldCh2YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgZGVzYy52YWx1ZS52YWx1ZSA9IHZhbDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICA6IHtcbiAgICAgICAgICAgICAgICBnZXQoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBkZXNjLmdldCAmJiBkZXNjLmdldCgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH07XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShpMThuLCBwcm9wLCB3cmFwKTtcbiAgICB9KTtcbiAgICBhcHAuY29uZmlnLmdsb2JhbFByb3BlcnRpZXMuJGkxOG4gPSBpMThuO1xuICAgIGdsb2JhbEV4cG9ydE1ldGhvZHMuZm9yRWFjaChtZXRob2QgPT4ge1xuICAgICAgICBjb25zdCBkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihjb21wb3NlciwgbWV0aG9kKTtcbiAgICAgICAgaWYgKCFkZXNjIHx8ICFkZXNjLnZhbHVlKSB7XG4gICAgICAgICAgICB0aHJvdyBjcmVhdGVJMThuRXJyb3IoSTE4bkVycm9yQ29kZXMuVU5FWFBFQ1RFRF9FUlJPUik7XG4gICAgICAgIH1cbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGFwcC5jb25maWcuZ2xvYmFsUHJvcGVydGllcywgYCQke21ldGhvZH1gLCBkZXNjKTtcbiAgICB9KTtcbiAgICBjb25zdCBkaXNwb3NlID0gKCkgPT4ge1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgICAgICBkZWxldGUgYXBwLmNvbmZpZy5nbG9iYWxQcm9wZXJ0aWVzLiRpMThuO1xuICAgICAgICBnbG9iYWxFeHBvcnRNZXRob2RzLmZvckVhY2gobWV0aG9kID0+IHtcbiAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICAgICAgICBkZWxldGUgYXBwLmNvbmZpZy5nbG9iYWxQcm9wZXJ0aWVzW2AkJHttZXRob2R9YF07XG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgcmV0dXJuIGRpc3Bvc2U7XG59XG5cbmNvbnN0IERhdGV0aW1lRm9ybWF0SW1wbCA9IC8qICNfX1BVUkVfXyovIGRlZmluZUNvbXBvbmVudCh7XG4gICAgLyogZXNsaW50LWRpc2FibGUgKi9cbiAgICBuYW1lOiAnaTE4bi1kJyxcbiAgICBwcm9wczogYXNzaWduKHtcbiAgICAgICAgdmFsdWU6IHtcbiAgICAgICAgICAgIHR5cGU6IFtOdW1iZXIsIERhdGVdLFxuICAgICAgICAgICAgcmVxdWlyZWQ6IHRydWVcbiAgICAgICAgfSxcbiAgICAgICAgZm9ybWF0OiB7XG4gICAgICAgICAgICB0eXBlOiBbU3RyaW5nLCBPYmplY3RdXG4gICAgICAgIH1cbiAgICB9LCBiYXNlRm9ybWF0UHJvcHMpLFxuICAgIC8qIGVzbGludC1lbmFibGUgKi9cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgIHNldHVwKHByb3BzLCBjb250ZXh0KSB7XG4gICAgICAgIGNvbnN0IGkxOG4gPSBwcm9wcy5pMThuIHx8XG4gICAgICAgICAgICB1c2VJMThuKHtcbiAgICAgICAgICAgICAgICB1c2VTY29wZTogcHJvcHMuc2NvcGUsXG4gICAgICAgICAgICAgICAgX191c2VDb21wb25lbnQ6IHRydWVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVuZGVyRm9ybWF0dGVyKHByb3BzLCBjb250ZXh0LCBEQVRFVElNRV9GT1JNQVRfT1BUSU9OU19LRVlTLCAoLi4uYXJncykgPT4gXG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICAgIGkxOG5bRGF0ZXRpbWVQYXJ0c1N5bWJvbF0oLi4uYXJncykpO1xuICAgIH1cbn0pO1xuLyoqXG4gKiBEYXRldGltZSBGb3JtYXQgQ29tcG9uZW50XG4gKlxuICogQHJlbWFya3NcbiAqIFNlZSB0aGUgZm9sbG93aW5nIGl0ZW1zIGZvciBwcm9wZXJ0eSBhYm91dCBkZXRhaWxzXG4gKlxuICogQFZ1ZUkxOG5TZWUgW0Zvcm1hdHRhYmxlUHJvcHNdKGNvbXBvbmVudCNmb3JtYXR0YWJsZXByb3BzKVxuICogQFZ1ZUkxOG5TZWUgW0Jhc2VGb3JtYXRQcm9wc10oY29tcG9uZW50I2Jhc2Vmb3JtYXRwcm9wcylcbiAqIEBWdWVJMThuU2VlIFtDdXN0b20gRm9ybWF0dGluZ10oLi4vZ3VpZGUvZXNzZW50aWFscy9kYXRldGltZSNjdXN0b20tZm9ybWF0dGluZylcbiAqXG4gKiBAVnVlSTE4bkRhbmdlclxuICogTm90IHN1cHBvcnRlZCBJRSwgZHVlIHRvIG5vIHN1cHBvcnQgYEludGwuRGF0ZVRpbWVGb3JtYXQjZm9ybWF0VG9QYXJ0c2AgaW4gW0lFXShodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9KYXZhU2NyaXB0L1JlZmVyZW5jZS9HbG9iYWxfT2JqZWN0cy9JbnRsL0RhdGVUaW1lRm9ybWF0L2Zvcm1hdFRvUGFydHMpXG4gKlxuICogSWYgeW91IHdhbnQgdG8gdXNlIGl0LCB5b3UgbmVlZCB0byB1c2UgW3BvbHlmaWxsXShodHRwczovL2dpdGh1Yi5jb20vZm9ybWF0anMvZm9ybWF0anMvdHJlZS9tYWluL3BhY2thZ2VzL2ludGwtZGF0ZXRpbWVmb3JtYXQpXG4gKlxuICogQFZ1ZUkxOG5Db21wb25lbnRcbiAqL1xuY29uc3QgRGF0ZXRpbWVGb3JtYXQgPSBEYXRldGltZUZvcm1hdEltcGw7XG5jb25zdCBJMThuRCA9IERhdGV0aW1lRm9ybWF0O1xuXG57XG4gICAgaW5pdEZlYXR1cmVGbGFncygpO1xufVxuLy8gcmVnaXN0ZXIgbWVzc2FnZSBjb21waWxlciBhdCB2dWUtaTE4blxucmVnaXN0ZXJNZXNzYWdlQ29tcGlsZXIoY29tcGlsZSk7XG4vLyByZWdpc3RlciBtZXNzYWdlIHJlc29sdmVyIGF0IHZ1ZS1pMThuXG5yZWdpc3Rlck1lc3NhZ2VSZXNvbHZlcihyZXNvbHZlVmFsdWUpO1xuLy8gcmVnaXN0ZXIgZmFsbGJhY2sgbG9jYWxlIGF0IHZ1ZS1pMThuXG5yZWdpc3RlckxvY2FsZUZhbGxiYWNrZXIoZmFsbGJhY2tXaXRoTG9jYWxlQ2hhaW4pO1xuLy8gTk9URTogZXhwZXJpbWVudGFsICEhXG5pZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHx8IF9fSU5UTElGWV9QUk9EX0RFVlRPT0xTX18pIHtcbiAgICBjb25zdCB0YXJnZXQgPSBnZXRHbG9iYWxUaGlzKCk7XG4gICAgdGFyZ2V0Ll9fSU5UTElGWV9fID0gdHJ1ZTtcbiAgICBzZXREZXZUb29sc0hvb2sodGFyZ2V0Ll9fSU5UTElGWV9ERVZUT09MU19HTE9CQUxfSE9PS19fKTtcbn1cbmlmICgocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykpIDtcblxuZXhwb3J0IHsgRGF0ZXRpbWVGb3JtYXQsIEkxOG5ELCBJMThuSW5qZWN0aW9uS2V5LCBJMThuTiwgSTE4blQsIE51bWJlckZvcm1hdCwgVHJhbnNsYXRpb24sIFZFUlNJT04sIGNyZWF0ZUkxOG4sIHVzZUkxOG4sIHZURGlyZWN0aXZlIH07XG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==