import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/pages/runtime/component-stub.js?macro=true");
const __nuxt_page_meta = {}
export default __nuxt_page_meta

// Vite
if (import.meta.hot) {
  import.meta.hot.accept(mod => {
    Object.assign(__nuxt_page_meta, mod)
  })
}
// webpack
if (import.meta.webpackHot) {
  import.meta.webpackHot.accept((err) => {
    if (err) { window.location = window.location.href }
  })
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbXBvbmVudC1zdHViLmpzP21hY3JvPXRydWUiXSwic291cmNlc0NvbnRlbnQiOlsiLy8jcmVnaW9uIHNyYy9wYWdlcy9ydW50aW1lL2NvbXBvbmVudC1zdHViLnRzXG52YXIgY29tcG9uZW50X3N0dWJfZGVmYXVsdCA9IHt9O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjb21wb25lbnRfc3R1Yl9kZWZhdWx0IGFzIGRlZmF1bHQgfTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=