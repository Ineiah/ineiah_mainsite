import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/components/hero/SectionColor.vue");import { default as __nuxt_component_0 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/components/client-only.js?v=7e73afc2";
import { default as __nuxt_component_1 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+icon@2.4.1_magic-string@0.30.21_magicast@0.5.4_oxc-parser@0.142.0_rolldown@1.2.2__bc09e636b3a0e451fd4fcea89c56910f/node_modules/@nuxt/icon/dist/runtime/components/index.js?v=7e73afc2";
import { default as __nuxt_component_2 } from "/_nuxt/components/volt/Button.vue";
import { default as __nuxt_component_3 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxtjs+i18n@10.6.0_@vue+compiler-dom@3.5.40_db0@0.3.4_better-sqlite3@13.0.2_drizzle-or_ebcb91ac37e09cc979ede2167e22c07a/node_modules/@nuxtjs/i18n/dist/runtime/components/NuxtLinkLocale.js?v=7e73afc2";
import { default as __nuxt_component_4 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+image@2.1.0_@types+node@26.1.2_magic-string@1.1.0_magicast@0.5.4_oxc-parser@0.142_8c2f52bee20945aa2ec4d2e10b1999d3/node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue";
import { useBusinessDetails as _$__useBusinessDetails } from "/_nuxt/composables/business/base.ts";;import { __nuxtTimelineWrap } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+devtools@3.4.1_db0@0.3.4_better-sqlite3@13.0.2_drizzle-orm@0.45.2_@opentelemetry+_0e55243a794e05cb19a29a0506aae086/node_modules/@nuxt/devtools/dist/runtime/function-metrics-helpers.js?v=7e73afc2";const useBusinessDetails = __nuxtTimelineWrap("useBusinessDetails", _$__useBusinessDetails);
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@8.2.0_@types+node@26.1.2_esbuild@0.28.1_jiti@2.7.0_sa_bcac4fa99282966dd94ca7ad2dfebde1/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=7e73afc2"
import { defineComponent as _defineComponent } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _sfc_main = /*@__PURE__*/ _defineComponent({
	__name: "HeroSectionColor",
	setup(__props, { expose: __expose }) {
		__expose();
		/**
		* Business details
		*/
		const { get } = useBusinessDetails();
		const __returned__ = { get };
		Object.defineProperty(__returned__, "__isScriptSetup", {
			enumerable: false,
			value: true
		});
		return __returned__;
	}
});
import { toDisplayString as _toDisplayString, createElementVNode as _createElementVNode, createTextVNode as _createTextVNode, resolveDirective as _resolveDirective, openBlock as _openBlock, createElementBlock as _createElementBlock, withDirectives as _withDirectives, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _hoisted_1 = { class: "grid grid-cols-1 md:grid-cols-2 auto-rows-min mt-10 bg-primary-500 dark:bg-primary-700 dark:text-primary-200 overflow-hidden" };
const _hoisted_2 = { class: "items-center md:flex md:p-10" };
const _hoisted_3 = { class: "p-10 text-center md:text-left md:max-w-lg" };
const _hoisted_4 = {
	delay: 600,
	enter: { transition: {
		type: "spring",
		stiffness: 20
	} },
	class: "text-3xl font-bold mb-4 md:text-5xl text-primary-800 dark:text-primary-400 font-title leading-10 md:leading-15"
};
const _hoisted_5 = { class: "italic" };
const _hoisted_6 = { class: "text-3xl font-bold mb-4 md:text-5xl text-primary-800 font-title leading-10 md:leading-15" };
const _hoisted_7 = { class: "italic" };
const _hoisted_8 = { class: "h-auto" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
	const _component_client_only = __nuxt_component_0;
	const _component_icon = __nuxt_component_1;
	const _component_volt_button = __nuxt_component_2;
	const _component_nuxt_link_locale = __nuxt_component_3;
	const _component_nuxt_img = __nuxt_component_4;
	const _directive_motion_slide_visible_once_bottom = _resolveDirective("motion-slide-visible-once-bottom");
	const _directive_motion_fade_visible_once = _resolveDirective("motion-fade-visible-once");
	return _openBlock(), _tracer(2,2,_createElementBlock("div", _hoisted_1, [_tracer(3,4,_createElementVNode("div", _hoisted_2, [_tracer(4,6,_createElementVNode("div", _hoisted_3, [
		_tracer(5,8,_createVNode(_component_client_only, null, {
			fallback: _withCtx(() => [_tracer(11,12,_createElementVNode("h2", _hoisted_6, [_cache[1] || (_cache[1] = _createTextVNode(
				" L'histoire de ",
				-1
				/* CACHED */
			)), _tracer(12,28,_createElementVNode(
				"span",
				_hoisted_7,
				_toDisplayString($setup.get("legalName")),
				1
				/* TEXT */
			))]))]),
			default: _withCtx(() => [_withDirectives((_openBlock(), _tracer(6,10,_createElementBlock("h2", _hoisted_4, [_cache[0] || (_cache[0] = _createTextVNode(
				" L'histoire de ",
				-1
				/* CACHED */
			)), _tracer(7,26,_createElementVNode(
				"span",
				_hoisted_5,
				_toDisplayString($setup.get("legalName")),
				1
				/* TEXT */
			))]))), [[_directive_motion_slide_visible_once_bottom]])]),
			_: 1
		})),
		_cache[2] || (_cache[2] = _tracer(17,8,_createElementVNode(
			"div",
			{ class: "space-y-3" },
			[_tracer(18,10,_createElementVNode("p", { class: "font-light" }, " Notre histoire, c'est avant tout une histoire humaine. Une histoire de passion, de transmission et d'amour du cheveu sous toutes ses formes. Née d'un désir profond de rendre la coiffure professionnelle accessible à toutes les textures — cheveux afros, bouclés, ondulés, caucasiens — La Beauté D'Inéïah s'est imposée comme la référence de la coiffure multiculturelle à Lille et dans le Nord. ")), _tracer(25,10,_createElementVNode("p", null, " Derrière chaque coupe, chaque soin, chaque séance de kératine végétale ou chaque balayage se cache un parcours exigeant et passionné. Formée auprès des plus grands noms de la coiffure professionnelle, Inéïah met plus de 25 ans d'expertise au service de ta chevelure, avec une attention particulière portée aux cheveux texturés si souvent mal compris. Découvre l'histoire de cette aventure et la vision qui anime chaque rendez-vous. "))],
			-1
			/* CACHED */
		))),
		_tracer(33,8,_createVNode(_component_nuxt_link_locale, { to: "/notre-histoire" }, {
			default: _withCtx(() => [_tracer(34,10,_createVNode(_component_volt_button, {
				size: "large",
				class: "mt-10",
				rounded: ""
			}, {
				default: _withCtx(() => [_createTextVNode(
					_toDisplayString(_ctx.$t("Découvrir")) + " ",
					1
					/* TEXT */
				), _tracer(36,12,_createVNode(_component_icon, { name: "fa7-solid:arrow-right" }))]),
				_: 1
			}))]),
			_: 1
		}))
	]))])), _tracer(42,4,_createElementVNode("div", _hoisted_8, [_tracer(43,6,_createVNode(_component_client_only, null, {
		default: _withCtx(() => [_withDirectives(_tracer(44,8,_createVNode(_component_nuxt_img, {
			delay: 600,
			alt: `Hair Artist - ${$setup.get("founder")}`,
			src: "/images/kira/photoshoot40-small.webp",
			class: "aspect-square object-cover h-full xl:w-full"
		}, null, 8, ["alt"])), [[_directive_motion_fade_visible_once]])]),
		_: 1
	}))]))]));
}
_sfc_main.__hmrId = "c833c749";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.on("file-changed", ({ file }) => {
	__VUE_HMR_RUNTIME__.CHANGED_FILE = file;
});
import.meta.hot.accept((mod) => {
	if (!mod) return;
	const { default: updated, _rerender_only } = mod;
	if (_rerender_only) {
		__VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
	} else {
		__VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
	}
});
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper";
export default /*#__PURE__*/ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "/Volumes/Coding/Projects/Websites/ineiah/frontend/app/components/hero/SectionColor.vue"]]);

function _tracer(line, column, vnode) { return _tracerRecordPosition("app/components/hero/SectionColor.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0VBc0RBLE1BQU0sRUFBRSxRQUFRLG1CQUFtQjs7Ozs7Ozs7OztBQXJENUIsNEJBQU0sK0hBQThIO0FBQ2xJLDRCQUFNLCtCQUE4QjtBQUNsQyw0QkFBTSw0Q0FBMkM7O0NBRVYsT0FBTztDQUFNLE9BQU87RUFBQTtFQUFBO0NBQUE7Q0FBbUQsT0FBTTs7QUFDL0YsNEJBQU0sU0FBUTtBQUk5Qiw0QkFBTSwyRkFBMEY7QUFDOUUsNEJBQU0sU0FBUTtBQThCdkMsNEJBQU0sU0FBUTs7Ozs7Ozs7O0NBeENyQixxREE2Q00sT0E3Q04sWUE2Q00sYUE1Q0osb0JBcUNNLE9BckNOLFlBcUNNLGFBcENKLG9CQW1DTSxPQW5DTixZQW1DTTtjQWxDSixhQVVjO0dBTEQsVUFBUSxlQUdaLGVBRkwsb0JBRUssTUFGTCxZQUVLLENBRmdHO0lBQUE7SUFDckY7O0dBQUE7SUFBa0Q7SUFBbEQ7SUFBa0QsaUJBQTFCLFdBQUc7SUFBQTs7R0FBQTtHQU43Qyx3QkFFSyxDQUZMLGdFQUVLLE1BRkwsWUFFSyxDQUZpTztJQUFBO0lBQ3ROOztHQUFBO0lBQWtEO0lBQWxEO0lBQWtELGlCQUExQixXQUFHO0lBQUE7O0dBQUE7OztFQVU3QztHQWNNO0dBQUEsRUFkRCxPQUFNLFlBQVc7R0FBQSxlQUNwQixvQkFLSSxPQUxELE9BQU0sYUFBWSxHQUFDLDBZQUt0QixrQkFFQSxvQkFLSSxXQUxELG1iQUtIOzs7O2VBR0YsYUFLbUIsK0JBTEQsSUFBRyxrQkFBaUI7R0FDcEMsd0JBR2MsZUFIZCxhQUdjO0lBSEQsTUFBSztJQUFRLE9BQU07SUFBUTs7SUFDdEMsd0JBQXFCLENBQWxCO0tBQUEseUJBQUUsZ0JBQWdCO0tBQ3JCOztJQUFBLDhCQUFxQyxtQkFBL0IsTUFBSyx3QkFBdUI7Ozs7O3NCQU0xQyxvQkFJTSxPQUpOLFlBSU0sY0FISixhQUVjO0VBRFosd0JBQTRMLENBQTVMLDBDQUE0TDtHQUF0SixPQUFPO0dBQU0sS0FBRyxpQkFBbUIsV0FBRztHQUFlLEtBQUk7R0FBdUMsT0FBTSIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiU2VjdGlvbkNvbG9yLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XG4gIDxkaXYgY2xhc3M9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGF1dG8tcm93cy1taW4gbXQtMTAgYmctcHJpbWFyeS01MDAgZGFyazpiZy1wcmltYXJ5LTcwMCBkYXJrOnRleHQtcHJpbWFyeS0yMDAgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgPGRpdiBjbGFzcz1cIml0ZW1zLWNlbnRlciBtZDpmbGV4IG1kOnAtMTBcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJwLTEwIHRleHQtY2VudGVyIG1kOnRleHQtbGVmdCBtZDptYXgtdy1sZ1wiPlxuICAgICAgICA8Y2xpZW50LW9ubHk+XG4gICAgICAgICAgPGgyIHYtbW90aW9uLXNsaWRlLXZpc2libGUtb25jZS1ib3R0b20gOmRlbGF5PVwiNjAwXCIgOmVudGVyPVwieyB0cmFuc2l0aW9uOiB7IHR5cGU6ICdzcHJpbmcnLCBzdGlmZm5lc3M6IDIwIH0gfVwiIGNsYXNzPVwidGV4dC0zeGwgZm9udC1ib2xkIG1iLTQgbWQ6dGV4dC01eGwgdGV4dC1wcmltYXJ5LTgwMCBkYXJrOnRleHQtcHJpbWFyeS00MDAgZm9udC10aXRsZSBsZWFkaW5nLTEwIG1kOmxlYWRpbmctMTVcIj5cbiAgICAgICAgICAgIEwnaGlzdG9pcmUgZGUgPHNwYW4gY2xhc3M9XCJpdGFsaWNcIj57eyBnZXQoJ2xlZ2FsTmFtZScpIH19PC9zcGFuPlxuICAgICAgICAgIDwvaDI+XG5cbiAgICAgICAgICA8dGVtcGxhdGUgI2ZhbGxiYWNrPlxuICAgICAgICAgICAgPGgyIGNsYXNzPVwidGV4dC0zeGwgZm9udC1ib2xkIG1iLTQgbWQ6dGV4dC01eGwgdGV4dC1wcmltYXJ5LTgwMCBmb250LXRpdGxlIGxlYWRpbmctMTAgbWQ6bGVhZGluZy0xNVwiPlxuICAgICAgICAgICAgICBMJ2hpc3RvaXJlIGRlIDxzcGFuIGNsYXNzPVwiaXRhbGljXCI+e3sgZ2V0KCdsZWdhbE5hbWUnKSB9fTwvc3Bhbj5cbiAgICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPC90ZW1wbGF0ZT5cbiAgICAgICAgPC9jbGllbnQtb25seT5cblxuICAgICAgICA8ZGl2IGNsYXNzPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgPHAgY2xhc3M9XCJmb250LWxpZ2h0XCI+XG4gICAgICAgICAgICBOb3RyZSBoaXN0b2lyZSwgYydlc3QgYXZhbnQgdG91dCB1bmUgaGlzdG9pcmUgaHVtYWluZS4gVW5lIGhpc3RvaXJlIGRlIHBhc3Npb24sIGRlIHRyYW5zbWlzc2lvbiBldFxuICAgICAgICAgICAgZCdhbW91ciBkdSBjaGV2ZXUgc291cyB0b3V0ZXMgc2VzIGZvcm1lcy4gTsOpZSBkJ3VuIGTDqXNpciBwcm9mb25kIGRlIHJlbmRyZSBsYSBjb2lmZnVyZSBwcm9mZXNzaW9ubmVsbGUgYWNjZXNzaWJsZVxuICAgICAgICAgICAgw6AgdG91dGVzIGxlcyB0ZXh0dXJlcyDigJQgY2hldmV1eCBhZnJvcywgYm91Y2zDqXMsIG9uZHVsw6lzLCBjYXVjYXNpZW5zIOKAlCBMYSBCZWF1dMOpIEQnSW7DqcOvYWggcydlc3QgaW1wb3PDqWUgY29tbWUgbGEgcsOpZsOpcmVuY2VcbiAgICAgICAgICAgIGRlIGxhIGNvaWZmdXJlIG11bHRpY3VsdHVyZWxsZSDDoCBMaWxsZSBldCBkYW5zIGxlIE5vcmQuXG4gICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgPHA+XG4gICAgICAgICAgICBEZXJyacOocmUgY2hhcXVlIGNvdXBlLCBjaGFxdWUgc29pbiwgY2hhcXVlIHPDqWFuY2UgZGUga8OpcmF0aW5lIHbDqWfDqXRhbGUgb3UgY2hhcXVlIGJhbGF5YWdlIHNlIGNhY2hlIHVuIHBhcmNvdXJzIGV4aWdlYW50XG4gICAgICAgICAgICBldCBwYXNzaW9ubsOpLiBGb3Jtw6llIGF1cHLDqHMgZGVzIHBsdXMgZ3JhbmRzIG5vbXMgZGUgbGEgY29pZmZ1cmUgcHJvZmVzc2lvbm5lbGxlLCBJbsOpw69haCBtZXQgcGx1cyBkZSAyNSBhbnMgZCdleHBlcnRpc2UgYXVcbiAgICAgICAgICAgIHNlcnZpY2UgZGUgdGEgY2hldmVsdXJlLCBhdmVjIHVuZSBhdHRlbnRpb24gcGFydGljdWxpw6hyZSBwb3J0w6llIGF1eCBjaGV2ZXV4IHRleHR1csOpcyBzaSBzb3V2ZW50IG1hbCBjb21wcmlzLiBEw6ljb3V2cmUgbCdoaXN0b2lyZVxuICAgICAgICAgICAgZGUgY2V0dGUgYXZlbnR1cmUgZXQgbGEgdmlzaW9uIHF1aSBhbmltZSBjaGFxdWUgcmVuZGV6LXZvdXMuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8bnV4dC1saW5rLWxvY2FsZSB0bz1cIi9ub3RyZS1oaXN0b2lyZVwiPlxuICAgICAgICAgIDx2b2x0LWJ1dHRvbiBzaXplPVwibGFyZ2VcIiBjbGFzcz1cIm10LTEwXCIgcm91bmRlZD5cbiAgICAgICAgICAgIHt7ICR0KFwiRMOpY291dnJpclwiKSB9fVxuICAgICAgICAgICAgPGljb24gbmFtZT1cImZhNy1zb2xpZDphcnJvdy1yaWdodFwiIC8+XG4gICAgICAgICAgPC92b2x0LWJ1dHRvbj5cbiAgICAgICAgPC9udXh0LWxpbmstbG9jYWxlPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG5cbiAgICA8ZGl2IGNsYXNzPVwiaC1hdXRvXCI+XG4gICAgICA8Y2xpZW50LW9ubHk+XG4gICAgICAgIDxudXh0LWltZyB2LW1vdGlvbi1mYWRlLXZpc2libGUtb25jZSA6ZGVsYXk9XCI2MDBcIiA6YWx0PVwiYEhhaXIgQXJ0aXN0IC0gJHtnZXQoJ2ZvdW5kZXInKX1gXCIgc3JjPVwiL2ltYWdlcy9raXJhL3Bob3Rvc2hvb3Q0MC1zbWFsbC53ZWJwXCIgY2xhc3M9XCJhc3BlY3Qtc3F1YXJlIG9iamVjdC1jb3ZlciBoLWZ1bGwgeGw6dy1mdWxsXCIgLz5cbiAgICAgIDwvY2xpZW50LW9ubHk+XG4gICAgPC9kaXY+XG4gIDwvZGl2PlxuPC90ZW1wbGF0ZT5cblxuPHNjcmlwdCBzZXR1cCBsYW5nPVwidHNcIj5cbi8qKlxuICogQnVzaW5lc3MgZGV0YWlsc1xuICovXG5cbmNvbnN0IHsgZ2V0IH0gPSB1c2VCdXNpbmVzc0RldGFpbHMoKVxuPC9zY3JpcHQ+XG4iXSwiZmlsZSI6Ii9Wb2x1bWVzL0NvZGluZy9Qcm9qZWN0cy9XZWJzaXRlcy9pbmVpYWgvZnJvbnRlbmQvYXBwL2NvbXBvbmVudHMvaGVyby9TZWN0aW9uQ29sb3IudnVlIn0=