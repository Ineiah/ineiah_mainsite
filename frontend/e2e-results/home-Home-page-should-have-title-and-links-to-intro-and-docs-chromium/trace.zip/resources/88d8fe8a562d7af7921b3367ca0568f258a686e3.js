import { createGlobalState, useSessionStorage, useToggle, isDefined } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vueuse+core@14.4.0_vue@3.5.40_typescript@6.0.3_/node_modules/@vueuse/core/dist/index.js?v=7e73afc2";
import { ref, watch } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
import { useState as _$__useState } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/composables/state.js?v=7e73afc2";;import { __nuxtTimelineWrap } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+devtools@3.4.1_db0@0.3.4_better-sqlite3@13.0.2_drizzle-orm@0.45.2_@opentelemetry+_0e55243a794e05cb19a29a0506aae086/node_modules/@nuxt/devtools/dist/runtime/function-metrics-helpers.js?v=7e73afc2";const useState = __nuxtTimelineWrap("useState", _$__useState);
export * from "/_nuxt/composables/business/index.ts";
export * from "/_nuxt/composables/dark_mode.ts";
export * from "/_nuxt/composables/faq.ts";
export * from "/_nuxt/composables/gallery/index.ts";
export * from "/_nuxt/composables/socials.ts";
export * from "/_nuxt/composables/reviews.ts";
export * from "/_nuxt/composables/services/index.ts";
export * from "/_nuxt/composables/google_search/index.ts";
export * from "/_nuxt/composables/legal/index.ts";
export const useDevComposable = createGlobalState(() => {
	const showImage = ref(true);
	const showVideo = ref(false);
	const showCarousel = ref(false);
	watch(showImage, (newImage) => {
		if (newImage) {
			showImage.value = newImage;
			showVideo.value = false;
			showCarousel.value = false;
		}
	});
	watch(showVideo, (newVideo) => {
		if (newVideo) {
			showVideo.value = newVideo;
			showImage.value = false;
			showCarousel.value = false;
		}
	});
	watch(showCarousel, (newCarousel) => {
		if (newCarousel) {
			showCarousel.value = newCarousel;
			showImage.value = false;
			showVideo.value = false;
		}
	});
	const showVideoBlock = ref(false);
	return {
		showImage,
		showVideo,
		showCarousel,
		showVideoBlock
	};
});
/**
* Composable to manage cookie banner state
*/
export const useCookieComposable = createGlobalState(() => {
	const cookieAccepted = useSessionStorage("cookieAccepted", () => false);
	const showBanner = useState("showCookieBanner", () => !cookieAccepted.value);
	const showOptions = useState("showCookieOptions", () => false);
	const toggleShowBanner = useToggle(showBanner);
	const toggleShowOptions = useToggle(showOptions);
	function accept(callback) {
		cookieAccepted.value = true;
		showBanner.value = false;
		if (isDefined(callback)) {
			callback();
		}
	}
	return {
		/**
		* Whether the user has accepted cookies
		* @default false
		*/
		cookieAccepted,
		/**
		* Whether to show the cookie banner
		* @default true
		*/
		showBanner,
		/**
		* Whether to show the cookie options modal
		* @default false
		*/
		showOptions,
		/**
		* Toggles the visibility of the cookie banner
		*/
		toggleShowBanner,
		/**
		* Toggles the visibility of the cookie options modal
		*/
		toggleShowOptions,
		/**
		* Accepts the cookie policy and hides the banner
		*/
		accept
	};
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7O0FBQUEsY0FBYztBQUNkLGNBQWM7QUFDZCxjQUFjO0FBQ2QsY0FBYztBQUNkLGNBQWM7QUFDZCxjQUFjO0FBQ2QsY0FBYztBQUNkLGNBQWM7QUFDZCxjQUFjO0FBRWQsT0FBTyxNQUFNLG1CQUFtQix3QkFBd0I7Q0FDdEQsTUFBTSxZQUFZLElBQWEsSUFBSTtDQUNuQyxNQUFNLFlBQVksSUFBYSxLQUFLO0NBQ3BDLE1BQU0sZUFBZSxJQUFhLEtBQUs7Q0FFdkMsTUFBTSxZQUFZLGFBQWE7RUFDN0IsSUFBSSxVQUFVO0dBQ1osVUFBVSxRQUFRO0dBQ2xCLFVBQVUsUUFBUTtHQUNsQixhQUFhLFFBQVE7RUFDdkI7Q0FDRixDQUFDO0NBRUQsTUFBTSxZQUFZLGFBQWE7RUFDN0IsSUFBSSxVQUFVO0dBQ1osVUFBVSxRQUFRO0dBQ2xCLFVBQVUsUUFBUTtHQUNsQixhQUFhLFFBQVE7RUFDdkI7Q0FDRixDQUFDO0NBRUQsTUFBTSxlQUFlLGdCQUFnQjtFQUNuQyxJQUFJLGFBQWE7R0FDZixhQUFhLFFBQVE7R0FDckIsVUFBVSxRQUFRO0dBQ2xCLFVBQVUsUUFBUTtFQUNwQjtDQUNGLENBQUM7Q0FFRCxNQUFNLGlCQUFpQixJQUFJLEtBQUs7Q0FFaEMsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7QUFDRixDQUFDOzs7O0FBS0QsT0FBTyxNQUFNLHNCQUFzQix3QkFBd0I7Q0FDekQsTUFBTSxpQkFBaUIsa0JBQWtCLHdCQUF3QixLQUFLO0NBQ3RFLE1BQU0sYUFBYSxTQUFTLDBCQUEwQixDQUFDLGVBQWUsS0FBSztDQUMzRSxNQUFNLGNBQWMsU0FBUywyQkFBMkIsS0FBSztDQUU3RCxNQUFNLG1CQUFtQixVQUFVLFVBQVU7Q0FDN0MsTUFBTSxvQkFBb0IsVUFBVSxXQUFXO0NBRS9DLFNBQVMsT0FBTyxVQUF1QjtFQUNyQyxlQUFlLFFBQVE7RUFDdkIsV0FBVyxRQUFRO0VBRW5CLElBQUksVUFBVSxRQUFRLEdBQUc7R0FDdkIsU0FBUztFQUNYO0NBQ0Y7Q0FFQSxPQUFPOzs7OztFQUtMOzs7OztFQUtBOzs7OztFQUtBOzs7O0VBSUE7Ozs7RUFJQTs7OztFQUlBO0NBQ0Y7QUFDRixDQUFDIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJpbmRleC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgKiBmcm9tICcuL2J1c2luZXNzJ1xuZXhwb3J0ICogZnJvbSAnLi9kYXJrX21vZGUnXG5leHBvcnQgKiBmcm9tICcuL2ZhcSdcbmV4cG9ydCAqIGZyb20gJy4vZ2FsbGVyeSdcbmV4cG9ydCAqIGZyb20gJy4vc29jaWFscydcbmV4cG9ydCAqIGZyb20gJy4vcmV2aWV3cydcbmV4cG9ydCAqIGZyb20gJy4vc2VydmljZXMnXG5leHBvcnQgKiBmcm9tICcuL2dvb2dsZV9zZWFyY2gnXG5leHBvcnQgKiBmcm9tICcuL2xlZ2FsJ1xuXG5leHBvcnQgY29uc3QgdXNlRGV2Q29tcG9zYWJsZSA9IGNyZWF0ZUdsb2JhbFN0YXRlKCgpID0+IHtcbiAgY29uc3Qgc2hvd0ltYWdlID0gcmVmPGJvb2xlYW4+KHRydWUpXG4gIGNvbnN0IHNob3dWaWRlbyA9IHJlZjxib29sZWFuPihmYWxzZSlcbiAgY29uc3Qgc2hvd0Nhcm91c2VsID0gcmVmPGJvb2xlYW4+KGZhbHNlKVxuXG4gIHdhdGNoKHNob3dJbWFnZSwgKG5ld0ltYWdlKSA9PiB7XG4gICAgaWYgKG5ld0ltYWdlKSB7XG4gICAgICBzaG93SW1hZ2UudmFsdWUgPSBuZXdJbWFnZVxuICAgICAgc2hvd1ZpZGVvLnZhbHVlID0gZmFsc2VcbiAgICAgIHNob3dDYXJvdXNlbC52YWx1ZSA9IGZhbHNlXG4gICAgfVxuICB9KVxuXG4gIHdhdGNoKHNob3dWaWRlbywgKG5ld1ZpZGVvKSA9PiB7XG4gICAgaWYgKG5ld1ZpZGVvKSB7XG4gICAgICBzaG93VmlkZW8udmFsdWUgPSBuZXdWaWRlb1xuICAgICAgc2hvd0ltYWdlLnZhbHVlID0gZmFsc2VcbiAgICAgIHNob3dDYXJvdXNlbC52YWx1ZSA9IGZhbHNlXG4gICAgfVxuICB9KVxuXG4gIHdhdGNoKHNob3dDYXJvdXNlbCwgKG5ld0Nhcm91c2VsKSA9PiB7XG4gICAgaWYgKG5ld0Nhcm91c2VsKSB7XG4gICAgICBzaG93Q2Fyb3VzZWwudmFsdWUgPSBuZXdDYXJvdXNlbFxuICAgICAgc2hvd0ltYWdlLnZhbHVlID0gZmFsc2VcbiAgICAgIHNob3dWaWRlby52YWx1ZSA9IGZhbHNlXG4gICAgfVxuICB9KVxuXG4gIGNvbnN0IHNob3dWaWRlb0Jsb2NrID0gcmVmKGZhbHNlKVxuXG4gIHJldHVybiB7XG4gICAgc2hvd0ltYWdlLFxuICAgIHNob3dWaWRlbyxcbiAgICBzaG93Q2Fyb3VzZWwsXG4gICAgc2hvd1ZpZGVvQmxvY2tcbiAgfVxufSlcblxuLyoqXG4gKiBDb21wb3NhYmxlIHRvIG1hbmFnZSBjb29raWUgYmFubmVyIHN0YXRlXG4gKi9cbmV4cG9ydCBjb25zdCB1c2VDb29raWVDb21wb3NhYmxlID0gY3JlYXRlR2xvYmFsU3RhdGUoKCkgPT4ge1xuICBjb25zdCBjb29raWVBY2NlcHRlZCA9IHVzZVNlc3Npb25TdG9yYWdlKCdjb29raWVBY2NlcHRlZCcsICgpID0+IGZhbHNlKVxuICBjb25zdCBzaG93QmFubmVyID0gdXNlU3RhdGUoJ3Nob3dDb29raWVCYW5uZXInLCAoKSA9PiAhY29va2llQWNjZXB0ZWQudmFsdWUpXG4gIGNvbnN0IHNob3dPcHRpb25zID0gdXNlU3RhdGUoJ3Nob3dDb29raWVPcHRpb25zJywgKCkgPT4gZmFsc2UpXG5cbiAgY29uc3QgdG9nZ2xlU2hvd0Jhbm5lciA9IHVzZVRvZ2dsZShzaG93QmFubmVyKVxuICBjb25zdCB0b2dnbGVTaG93T3B0aW9ucyA9IHVzZVRvZ2dsZShzaG93T3B0aW9ucylcblxuICBmdW5jdGlvbiBhY2NlcHQoY2FsbGJhY2s/OiAoKSA9PiB2b2lkKSB7XG4gICAgY29va2llQWNjZXB0ZWQudmFsdWUgPSB0cnVlXG4gICAgc2hvd0Jhbm5lci52YWx1ZSA9IGZhbHNlXG5cbiAgICBpZiAoaXNEZWZpbmVkKGNhbGxiYWNrKSkge1xuICAgICAgY2FsbGJhY2soKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiB7XG4gICAgLyoqXG4gICAgICogV2hldGhlciB0aGUgdXNlciBoYXMgYWNjZXB0ZWQgY29va2llc1xuICAgICAqIEBkZWZhdWx0IGZhbHNlXG4gICAgICovXG4gICAgY29va2llQWNjZXB0ZWQsXG4gICAgLyoqXG4gICAgICogV2hldGhlciB0byBzaG93IHRoZSBjb29raWUgYmFubmVyXG4gICAgICogQGRlZmF1bHQgdHJ1ZVxuICAgICAqL1xuICAgIHNob3dCYW5uZXIsXG4gICAgLyoqXG4gICAgICogV2hldGhlciB0byBzaG93IHRoZSBjb29raWUgb3B0aW9ucyBtb2RhbFxuICAgICAqIEBkZWZhdWx0IGZhbHNlXG4gICAgICovXG4gICAgc2hvd09wdGlvbnMsXG4gICAgLyoqXG4gICAgICogVG9nZ2xlcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgY29va2llIGJhbm5lclxuICAgICAqL1xuICAgIHRvZ2dsZVNob3dCYW5uZXIsXG4gICAgLyoqXG4gICAgICogVG9nZ2xlcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgY29va2llIG9wdGlvbnMgbW9kYWxcbiAgICAgKi9cbiAgICB0b2dnbGVTaG93T3B0aW9ucyxcbiAgICAvKipcbiAgICAgKiBBY2NlcHRzIHRoZSBjb29raWUgcG9saWN5IGFuZCBoaWRlcyB0aGUgYmFubmVyXG4gICAgICovXG4gICAgYWNjZXB0XG4gIH1cbn0pXG4iXSwiZmlsZSI6Ii9Wb2x1bWVzL0NvZGluZy9Qcm9qZWN0cy9XZWJzaXRlcy9pbmVpYWgvZnJvbnRlbmQvYXBwL2NvbXBvc2FibGVzL2luZGV4LnRzIn0=