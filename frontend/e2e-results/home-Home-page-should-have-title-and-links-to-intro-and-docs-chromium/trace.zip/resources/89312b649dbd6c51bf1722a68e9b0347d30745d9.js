import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/components/hero/SectionImage.vue");import { default as __nuxt_component_0 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+image@2.1.0_@types+node@26.1.2_magic-string@1.1.0_magicast@0.5.4_oxc-parser@0.142_8c2f52bee20945aa2ec4d2e10b1999d3/node_modules/@nuxt/image/dist/runtime/components/NuxtImg.vue";
import { default as __nuxt_component_1 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/components/client-only.js?v=7e73afc2";
import { default as __nuxt_component_2 } from "/_nuxt/components/base/TelephoneButton.vue";
import { useBusinessDetails as _$__useBusinessDetails } from "/_nuxt/composables/business/base.ts";;import { __nuxtTimelineWrap } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+devtools@3.4.1_db0@0.3.4_better-sqlite3@13.0.2_drizzle-orm@0.45.2_@opentelemetry+_0e55243a794e05cb19a29a0506aae086/node_modules/@nuxt/devtools/dist/runtime/function-metrics-helpers.js?v=7e73afc2";const useBusinessDetails = __nuxtTimelineWrap("useBusinessDetails", _$__useBusinessDetails);
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@8.2.0_@types+node@26.1.2_esbuild@0.28.1_jiti@2.7.0_sa_bcac4fa99282966dd94ca7ad2dfebde1/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=7e73afc2"
import { defineComponent as _defineComponent } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _sfc_main = /*@__PURE__*/ _defineComponent({
	__name: "HeroSectionImage",
	setup(__props, { expose: __expose }) {
		__expose();
		/**
		* Business details
		*/
		const { get } = useBusinessDetails();
		const __returned__ = { get };
		Object.defineProperty(__returned__, "__isScriptSetup", {
			enumerable: false,
			value: true
		});
		return __returned__;
	}
});
import { resolveComponent as _resolveComponent, resolveDirective as _resolveDirective, createVNode as _createVNode, withDirectives as _withDirectives, createElementVNode as _createElementVNode, createTextVNode as _createTextVNode, withCtx as _withCtx, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _hoisted_1 = { class: "p-5 md:p-15 overflow-hidden" };
const _hoisted_2 = { class: "grid grid-cols-1 xl:grid-cols-2 gap-10" };
const _hoisted_3 = { class: "group" };
const _hoisted_4 = { class: "flex flex-col justify-center dark:text-primary-200" };
const _hoisted_5 = {
	delay: 600,
	enter: { transition: {
		type: "spring",
		stiffness: 20
	} },
	class: "text-5xl font-bold mb-10 text-primary-500 font-title leading-15"
};
const _hoisted_6 = {
	id: "cta-1",
	class: "mt-10"
};
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
	const _component_nuxt_img = __nuxt_component_0;
	const _component_client_only = __nuxt_component_1;
	const _component_base_telephone_button = __nuxt_component_2;
	const _directive_motion_slide_visible_once_left = _resolveDirective("motion-slide-visible-once-left");
	const _directive_motion_slide_visible_once_bottom = _resolveDirective("motion-slide-visible-once-bottom");
	return _openBlock(), _tracer(2,2,_createElementBlock("div", _hoisted_1, [_tracer(3,4,_createElementVNode("div", _hoisted_2, [_tracer(4,6,_createVNode(_component_client_only, null, {
		fallback: _withCtx(() => [..._cache[0] || (_cache[0] = [_createTextVNode(
			" Loading image... ",
			-1
			/* CACHED */
		)])]),
		default: _withCtx(() => [_tracer(5,8,_createElementVNode("div", _hoisted_3, [_withDirectives(_tracer(6,10,_createVNode(_component_nuxt_img, {
			delay: 200,
			alt: `Coiffure femme cheveux bouclés par ${$setup.get("legalName")}`,
			src: "/images/kira/photoshoot46-small.webp",
			class: "rounded-lg aspect-square object-cover w-full"
		}, null, 8, ["alt"])), [[_directive_motion_slide_visible_once_left]])]))]),
		_: 1
	})), _tracer(14,6,_createElementVNode("div", _hoisted_4, [
		_tracer(15,8,_createVNode(_component_client_only, null, {
			default: _withCtx(() => [_withDirectives((_openBlock(), _tracer(16,10,_createElementBlock("h2", _hoisted_5, [..._cache[1] || (_cache[1] = [
				_createTextVNode(
					" La coiffure pensée pour ",
					-1
					/* CACHED */
				),
				_tracer(17,36,_createElementVNode(
					"span",
					{ class: "text-primary-800 dark:text-primary-400" },
					"tous",
					-1
					/* CACHED */
				)),
				_createTextVNode(
					" les types de cheveux ",
					-1
					/* CACHED */
				)
			])]))), [[_directive_motion_slide_visible_once_bottom]])]),
			_: 1
		})),
		_cache[2] || (_cache[2] = _tracer(21,8,_createElementVNode(
			"div",
			{ class: "space-y-3" },
			[
				_tracer(22,10,_createElementVNode("p", null, " Bien plus qu'une coiffeuse, Inéïah révèle la beauté qui sommeille en chaque chevelure. Ici, à Lille, chaque rendez-vous est bien plus qu'une coupe ou un soin — c'est un moment suspendu, pensé pour toi, rien que pour toi. ")),
				_tracer(28,10,_createElementVNode("p", null, " Tes cheveux bouclés, crépus, frisés ou lisses ont une histoire. Ils ont traversé des saisons, subi les aléas du quotidien, parfois été incompris. Chez Inéïah, cette histoire est écoutée avec attention, dès le premier diagnostic capillaire. Ton passé est entendu, ton présent est choyé, et ton futur est sublimé. ")),
				_tracer(34,10,_createElementVNode("p", null, " Avec plus de 25 ans d'expérience sur tous types de cheveux — cheveux afros, bouclés, ondulés ou caucasiens — et des soins haut de gamme comme l'Olaplex, la kératine végétale ou les produits Les Secrets de Loly, chaque prestation est pensée sur-mesure. Que tu rêves d'une coupe structurante, d'un balayage lumineux sur cheveux bouclés, d'une coloration respectueuse sur cheveux crépus, ou simplement d'un soin réparateur profond, Inéïah a les mains et l'expertise qu'il te faut. "))
			],
			-1
			/* CACHED */
		))),
		_tracer(42,8,_createElementVNode("div", _hoisted_6, [_tracer(43,10,_createVNode(_component_base_telephone_button, {
			id: "tel-call-us-intermediate-1",
			"with-icon": true,
			size: "large",
			text: "Je veux me faire belle"
		}))]))
	]))]))]));
}
_sfc_main.__hmrId = "ba47a467";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.on("file-changed", ({ file }) => {
	__VUE_HMR_RUNTIME__.CHANGED_FILE = file;
});
import.meta.hot.accept((mod) => {
	if (!mod) return;
	const { default: updated, _rerender_only } = mod;
	if (_rerender_only) {
		__VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
	} else {
		__VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
	}
});
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper";
export default /*#__PURE__*/ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "/Volumes/Coding/Projects/Websites/ineiah/frontend/app/components/hero/SectionImage.vue"]]);

function _tracer(line, column, vnode) { return _tracerRecordPosition("app/components/hero/SectionImage.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztFQXNEQSxNQUFNLEVBQUUsUUFBUSxtQkFBbUI7Ozs7Ozs7Ozs7QUFyRDVCLDRCQUFNLDhCQUE2QjtBQUNqQyw0QkFBTSx5Q0FBd0M7QUFFMUMsNEJBQU0sUUFBTztBQVNmLDRCQUFNLHFEQUFvRDs7Q0FFbkIsT0FBTztDQUFNLE9BQU87RUFBQTtFQUFBO0NBQUE7Q0FBbUQsT0FBTTs7O0NBMEJsSCxJQUFHO0NBQVEsT0FBTTs7Ozs7Ozs7Q0F4QzVCLHFEQTZDTSxPQTdDTixZQTZDTSxhQTVDSixvQkEyQ00sT0EzQ04sWUEyQ00sYUExQ0osYUFRYztFQUhELFVBQVEsZUFFbkIsK0JBRm9CO0dBQUE7R0FFcEI7O0VBQUE7RUFOQSx3QkFFTSxhQUZOLG9CQUVNLE9BRk4sWUFFTSxDQURKLDBDQUEwTjtHQUE5SyxPQUFPO0dBQU0sS0FBRyxzQ0FBd0MsV0FBRztHQUFpQixLQUFJO0dBQXVDLE9BQU07OzttQkFRN0ssb0JBK0JNLE9BL0JOLFlBK0JNO2VBOUJKLGFBSWM7R0FIWix3QkFFSyxDQUZMLGlFQUVLLE1BRkwsWUFFSztJQUZrTDtLQUFBO0tBQzdKOztJQUFBO2tCQUFBO0tBQWdFO0tBQUEsRUFBMUQsT0FBTSx5Q0FBd0M7S0FBQztLQUFJOztJQUFBO0lBQU87S0FBQTtLQUMxRjs7SUFBQTs7OztFQUdGO0dBbUJNO0dBQUEsRUFuQkQsT0FBTSxZQUFXO0dBQUE7a0JBQ3BCLG9CQUlJLFdBSkQsZ09BSUg7a0JBRUEsb0JBSUksV0FKRCwyVEFJSDtrQkFFQSxvQkFLSSxXQUxELGllQUtIOzs7OztlQUdGLG9CQUVNLE9BRk4sWUFFTSxlQURKLGFBQXNIO0dBQS9GLElBQUc7R0FBOEIsYUFBVztHQUFNLE1BQUs7R0FBUSxNQUFLIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJTZWN0aW9uSW1hZ2UudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjx0ZW1wbGF0ZT5cbiAgPGRpdiBjbGFzcz1cInAtNSBtZDpwLTE1IG92ZXJmbG93LWhpZGRlblwiPlxuICAgIDxkaXYgY2xhc3M9XCJncmlkIGdyaWQtY29scy0xIHhsOmdyaWQtY29scy0yIGdhcC0xMFwiPlxuICAgICAgPGNsaWVudC1vbmx5PlxuICAgICAgICA8ZGl2IGNsYXNzPVwiZ3JvdXBcIj5cbiAgICAgICAgICA8bnV4dC1pbWcgdi1tb3Rpb24tc2xpZGUtdmlzaWJsZS1vbmNlLWxlZnQgOmRlbGF5PVwiMjAwXCIgOmFsdD1cImBDb2lmZnVyZSBmZW1tZSBjaGV2ZXV4IGJvdWNsw6lzIHBhciAke2dldCgnbGVnYWxOYW1lJyl9YFwiIHNyYz1cIi9pbWFnZXMva2lyYS9waG90b3Nob290NDYtc21hbGwud2VicFwiIGNsYXNzPVwicm91bmRlZC1sZyBhc3BlY3Qtc3F1YXJlIG9iamVjdC1jb3ZlciB3LWZ1bGxcIiAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8dGVtcGxhdGUgI2ZhbGxiYWNrPlxuICAgICAgICAgIExvYWRpbmcgaW1hZ2UuLi5cbiAgICAgICAgPC90ZW1wbGF0ZT5cbiAgICAgIDwvY2xpZW50LW9ubHk+XG5cbiAgICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyIGRhcms6dGV4dC1wcmltYXJ5LTIwMFwiPlxuICAgICAgICA8Y2xpZW50LW9ubHk+XG4gICAgICAgICAgPGgyIHYtbW90aW9uLXNsaWRlLXZpc2libGUtb25jZS1ib3R0b20gOmRlbGF5PVwiNjAwXCIgOmVudGVyPVwieyB0cmFuc2l0aW9uOiB7IHR5cGU6ICdzcHJpbmcnLCBzdGlmZm5lc3M6IDIwIH0gfVwiIGNsYXNzPVwidGV4dC01eGwgZm9udC1ib2xkIG1iLTEwIHRleHQtcHJpbWFyeS01MDAgZm9udC10aXRsZSBsZWFkaW5nLTE1XCI+XG4gICAgICAgICAgICBMYSBjb2lmZnVyZSBwZW5zw6llIHBvdXIgPHNwYW4gY2xhc3M9XCJ0ZXh0LXByaW1hcnktODAwIGRhcms6dGV4dC1wcmltYXJ5LTQwMFwiPnRvdXM8L3NwYW4+IGxlcyB0eXBlcyBkZSBjaGV2ZXV4XG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgPC9jbGllbnQtb25seT5cblxuICAgICAgICA8ZGl2IGNsYXNzPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgPHA+XG4gICAgICAgICAgICBCaWVuIHBsdXMgcXUndW5lIGNvaWZmZXVzZSwgSW7DqcOvYWggcsOpdsOobGUgbGEgYmVhdXTDqSBxdWkgc29tbWVpbGxlIGVuXG4gICAgICAgICAgICBjaGFxdWUgY2hldmVsdXJlLiBJY2ksIMOgIExpbGxlLCBjaGFxdWUgcmVuZGV6LXZvdXMgZXN0IGJpZW4gcGx1cyBxdSd1bmUgY291cGUgb3UgdW4gc29pbiDigJRcbiAgICAgICAgICAgIGMnZXN0IHVuIG1vbWVudCBzdXNwZW5kdSwgcGVuc8OpIHBvdXIgdG9pLCByaWVuIHF1ZSBwb3VyIHRvaS5cbiAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICA8cD5cbiAgICAgICAgICAgIFRlcyBjaGV2ZXV4IGJvdWNsw6lzLCBjcsOpcHVzLCBmcmlzw6lzIG91IGxpc3NlcyBvbnQgdW5lIGhpc3RvaXJlLiBJbHMgb250IHRyYXZlcnPDqSBkZXMgc2Fpc29ucywgc3ViaVxuICAgICAgICAgICAgbGVzIGFsw6lhcyBkdSBxdW90aWRpZW4sIHBhcmZvaXMgw6l0w6kgaW5jb21wcmlzLiBDaGV6IEluw6nDr2FoLCBjZXR0ZSBoaXN0b2lyZSBlc3Qgw6ljb3V0w6llIGF2ZWMgYXR0ZW50aW9uLCBkw6hzIGxlIHByZW1pZXJcbiAgICAgICAgICAgIGRpYWdub3N0aWMgY2FwaWxsYWlyZS4gVG9uIHBhc3PDqSBlc3QgZW50ZW5kdSwgdG9uIHByw6lzZW50IGVzdCBjaG95w6ksIGV0IHRvbiBmdXR1ciBlc3Qgc3VibGltw6kuXG4gICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgPHA+XG4gICAgICAgICAgICBBdmVjIHBsdXMgZGUgMjUgYW5zIGQnZXhww6lyaWVuY2Ugc3VyIHRvdXMgdHlwZXMgZGUgY2hldmV1eCDigJQgY2hldmV1eCBhZnJvcywgYm91Y2zDqXMsIG9uZHVsw6lzIG91IGNhdWNhc2llbnMg4oCUXG4gICAgICAgICAgICBldCBkZXMgc29pbnMgaGF1dCBkZSBnYW1tZSBjb21tZSBsJ09sYXBsZXgsIGxhIGvDqXJhdGluZSB2w6lnw6l0YWxlIG91IGxlcyBwcm9kdWl0cyBMZXMgU2VjcmV0cyBkZSBMb2x5LCBjaGFxdWUgcHJlc3RhdGlvbiBlc3RcbiAgICAgICAgICAgIHBlbnPDqWUgc3VyLW1lc3VyZS4gUXVlIHR1IHLDqnZlcyBkJ3VuZSBjb3VwZSBzdHJ1Y3R1cmFudGUsIGQndW4gYmFsYXlhZ2UgbHVtaW5ldXggc3VyIGNoZXZldXggYm91Y2zDqXMsIGQndW5lIGNvbG9yYXRpb25cbiAgICAgICAgICAgIHJlc3BlY3R1ZXVzZSBzdXIgY2hldmV1eCBjcsOpcHVzLCBvdSBzaW1wbGVtZW50IGQndW4gc29pbiByw6lwYXJhdGV1ciBwcm9mb25kLCBJbsOpw69haCBhIGxlcyBtYWlucyBldCBsJ2V4cGVydGlzZSBxdSdpbCB0ZSBmYXV0LlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBpZD1cImN0YS0xXCIgY2xhc3M9XCJtdC0xMFwiPlxuICAgICAgICAgIDxiYXNlLXRlbGVwaG9uZS1idXR0b24gaWQ9XCJ0ZWwtY2FsbC11cy1pbnRlcm1lZGlhdGUtMVwiIDp3aXRoLWljb249XCJ0cnVlXCIgc2l6ZT1cImxhcmdlXCIgdGV4dD1cIkplIHZldXggbWUgZmFpcmUgYmVsbGVcIiAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG5cbjxzY3JpcHQgc2V0dXAgbGFuZz1cInRzXCI+XG4vKipcbiAqIEJ1c2luZXNzIGRldGFpbHNcbiAqL1xuXG5jb25zdCB7IGdldCB9ID0gdXNlQnVzaW5lc3NEZXRhaWxzKClcbjwvc2NyaXB0PlxuIl0sImZpbGUiOiIvVm9sdW1lcy9Db2RpbmcvUHJvamVjdHMvV2Vic2l0ZXMvaW5laWFoL2Zyb250ZW5kL2FwcC9jb21wb25lbnRzL2hlcm8vU2VjdGlvbkltYWdlLnZ1ZSJ9