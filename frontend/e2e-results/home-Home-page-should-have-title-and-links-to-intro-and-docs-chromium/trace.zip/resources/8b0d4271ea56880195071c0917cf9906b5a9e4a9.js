import { defineNuxtPlugin } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/nuxt.js?v=7e73afc2";
// import { InferSeoMetaPlugin } from '@unhead/bundler'
// import { injectHead } from '#imports'
export default defineNuxtPlugin(() => {
	// const head = injectHead()
	// const { get } = useBusinessDetails()
	/**
	* Generate Open Graph title by removing the legal name from the end of the page title.
	* This is because the legal name is already included in the og:site_name meta tag, and including
	* it in the og:title would be redundant.
	*/
	// head.use(
	//   InferSeoMetaPlugin({
	//     ogTitle: title => title?.replace(` - ${get('legalName')}`, '') || ''
	//   })
	// )
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7O0FBR0EsZUFBZSx1QkFBdUI7Ozs7Ozs7Ozs7Ozs7QUFjdEMsQ0FBQyIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiaGVhZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBpbXBvcnQgeyBJbmZlclNlb01ldGFQbHVnaW4gfSBmcm9tICdAdW5oZWFkL2J1bmRsZXInXG4vLyBpbXBvcnQgeyBpbmplY3RIZWFkIH0gZnJvbSAnI2ltcG9ydHMnXG5cbmV4cG9ydCBkZWZhdWx0IGRlZmluZU51eHRQbHVnaW4oKCkgPT4ge1xuICAvLyBjb25zdCBoZWFkID0gaW5qZWN0SGVhZCgpXG4gIC8vIGNvbnN0IHsgZ2V0IH0gPSB1c2VCdXNpbmVzc0RldGFpbHMoKVxuXG4gIC8qKlxuICAgKiBHZW5lcmF0ZSBPcGVuIEdyYXBoIHRpdGxlIGJ5IHJlbW92aW5nIHRoZSBsZWdhbCBuYW1lIGZyb20gdGhlIGVuZCBvZiB0aGUgcGFnZSB0aXRsZS5cbiAgICogVGhpcyBpcyBiZWNhdXNlIHRoZSBsZWdhbCBuYW1lIGlzIGFscmVhZHkgaW5jbHVkZWQgaW4gdGhlIG9nOnNpdGVfbmFtZSBtZXRhIHRhZywgYW5kIGluY2x1ZGluZ1xuICAgKiBpdCBpbiB0aGUgb2c6dGl0bGUgd291bGQgYmUgcmVkdW5kYW50LlxuICAgKi9cbiAgLy8gaGVhZC51c2UoXG4gIC8vICAgSW5mZXJTZW9NZXRhUGx1Z2luKHtcbiAgLy8gICAgIG9nVGl0bGU6IHRpdGxlID0+IHRpdGxlPy5yZXBsYWNlKGAgLSAke2dldCgnbGVnYWxOYW1lJyl9YCwgJycpIHx8ICcnXG4gIC8vICAgfSlcbiAgLy8gKVxufSlcbiJdLCJmaWxlIjoiL1ZvbHVtZXMvQ29kaW5nL1Byb2plY3RzL1dlYnNpdGVzL2luZWlhaC9mcm9udGVuZC9hcHAvcGx1Z2lucy9oZWFkLnRzIn0=