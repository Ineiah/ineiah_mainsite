import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/components/base/TelephoneButton.vue");import { default as __nuxt_component_0 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+icon@2.4.1_magic-string@0.30.21_magicast@0.5.4_oxc-parser@0.142.0_rolldown@1.2.2__bc09e636b3a0e451fd4fcea89c56910f/node_modules/@nuxt/icon/dist/runtime/components/index.js?v=7e73afc2";
import { default as __nuxt_component_1 } from "/_nuxt/components/volt/Button.vue";
import { default as __nuxt_component_2 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/components/client-only.js?v=7e73afc2";
import { useBusinessDetails as _$__useBusinessDetails } from "/_nuxt/composables/business/base.ts";
import { computed } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";;import { __nuxtTimelineWrap } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+devtools@3.4.1_db0@0.3.4_better-sqlite3@13.0.2_drizzle-orm@0.45.2_@opentelemetry+_0e55243a794e05cb19a29a0506aae086/node_modules/@nuxt/devtools/dist/runtime/function-metrics-helpers.js?v=7e73afc2";const useBusinessDetails = __nuxtTimelineWrap("useBusinessDetails", _$__useBusinessDetails);
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@8.2.0_@types+node@26.1.2_esbuild@0.28.1_jiti@2.7.0_sa_bcac4fa99282966dd94ca7ad2dfebde1/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=7e73afc2"
import { defineComponent as _defineComponent } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
// Prevent Vue from auto-inheriting attrs on the root <ClientOnly>
const _sfc_main = /*@__PURE__*/ _defineComponent({
	...{ inheritAttrs: false },
	__name: "BaseTelephoneButton",
	props: {
		id: {
			type: String,
			required: false
		},
		buttonClass: {
			type: String,
			required: false
		},
		telephone: {
			type: [String, null],
			required: false,
			default: null
		},
		text: {
			type: String,
			required: false,
			default: "Me contacter"
		},
		withIcon: {
			type: Boolean,
			required: false
		},
		size: {
			type: null,
			required: false,
			default: "small"
		}
	},
	setup(__props, { expose: __expose }) {
		__expose();
		const { businessDetails } = useBusinessDetails();
		const fallbackTelephone = businessDetails.contact.telephone;
		const resolvedTelephone = computed(() => __props.telephone || fallbackTelephone);
		const __returned__ = {
			businessDetails,
			fallbackTelephone,
			resolvedTelephone
		};
		Object.defineProperty(__returned__, "__isScriptSetup", {
			enumerable: false,
			value: true
		});
		return __returned__;
	}
});
import { resolveComponent as _resolveComponent, openBlock as _openBlock, createBlock as _createBlock, createCommentVNode as _createCommentVNode, renderSlot as _renderSlot, toDisplayString as _toDisplayString, createTextVNode as _createTextVNode, withCtx as _withCtx, createVNode as _createVNode, normalizeClass as _normalizeClass, createElementVNode as _createElementVNode } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _hoisted_1 = ["id", "href"];
const _hoisted_2 = ["href"];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
	const _component_icon = __nuxt_component_0;
	const _component_volt_button = __nuxt_component_1;
	const _component_client_only = __nuxt_component_2;
	return _openBlock(), _tracer(2,2,_createBlock(_component_client_only, null, {
		fallback: _withCtx(() => [_tracer(13,6,_createElementVNode("a", {
			href: `tel:${$setup.fallbackTelephone}`,
			class: "block"
		}, [_tracer(14,8,_createVNode(_component_volt_button, {
			size: $props.size,
			class: "w-full md:w-auto",
			rounded: ""
		}, {
			default: _withCtx(() => [$props.withIcon ? (_openBlock(), _tracer(15,10,_createBlock(_component_icon, {
				key: 0,
				name: "i-fa7-solid:phone"
			}))) : _createCommentVNode("v-if", true), _createTextVNode(
				" " + _toDisplayString($props.text),
				1
				/* TEXT */
			)]),
			_: 1
		}, 8, ["size"]))], 8, _hoisted_2))]),
		default: _withCtx(() => [_tracer(3,4,_createElementVNode("a", {
			id: $props.id,
			class: _normalizeClass([$props.buttonClass, "block"]),
			href: `tel:${$setup.resolvedTelephone}`
		}, [_tracer(4,6,_createVNode(_component_volt_button, {
			size: $props.size,
			class: "w-full md:w-auto",
			rounded: ""
		}, {
			default: _withCtx(() => [$props.withIcon ? (_openBlock(), _tracer(5,8,_createBlock(_component_icon, {
				key: 0,
				name: "i-fa7-solid:phone"
			}))) : _createCommentVNode("v-if", true), _renderSlot(_ctx.$slots, "default", {}, () => [_createTextVNode(
				_toDisplayString(_ctx.$t($props.text)),
				1
				/* TEXT */
			)])]),
			_: 3
		}, 8, ["size"]))], 10, _hoisted_1))]),
		_: 3
	}));
}
_sfc_main.__hmrId = "87f5d538";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.on("file-changed", ({ file }) => {
	__VUE_HMR_RUNTIME__.CHANGED_FILE = file;
});
import.meta.hot.accept((mod) => {
	if (!mod) return;
	const { default: updated, _rerender_only } = mod;
	if (_rerender_only) {
		__VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
	} else {
		__VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
	}
});
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper";
export default /*#__PURE__*/ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "/Volumes/Coding/Projects/Websites/ineiah/frontend/app/components/base/TelephoneButton.vue"]]);

function _tracer(line, column, vnode) { return _tracerRecordPosition("app/components/base/TelephoneButton.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBNkJBLE1BQU0sRUFBRSxvQkFBb0IsbUJBQW1CO0VBVy9DLE1BQU0sb0JBQW9CLGdCQUFnQixRQUFRO0VBQ2xELE1BQU0sb0JBQW9CLGVBQWUscUJBQWEsaUJBQWlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQXhDckUsOENBa0JjO0VBUkQsVUFBUSxlQU1iLGNBTEosb0JBS0k7R0FMQSxNQUFJLE9BQVM7R0FBcUIsT0FBTTttQkFDMUMsYUFHYztHQUhBLE1BQU07R0FBTSxPQUFNO0dBQW1COztHQUNqRCx3QkFBaUQsQ0FBckMsbUJBQVoseUNBQWlEOztJQUEzQixNQUFLOzZDQUFzQjtJQUFBLE1BQ2pELGlCQUFHLFdBQUk7SUFBQTs7R0FBQTs7O0VBYmIsd0JBT0ksYUFQSixvQkFPSTtHQVBBLElBQUk7R0FBSyxPQUFLLGlCQUFFLG9CQUFzRCxPQUFPO0dBQS9DLE1BQUksT0FBUztrQkFDN0MsYUFLYztHQUxBLE1BQU07R0FBTSxPQUFNO0dBQW1COztHQUNqRCx3QkFBaUQsQ0FBckMsbUJBQVosdUNBQWlEOztJQUEzQixNQUFLOzZDQUMzQixZQUVPLG1DQURGO0lBQUEseUJBQUcsV0FBSTtJQUFBOztHQUFBIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJUZWxlcGhvbmVCdXR0b24udnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjx0ZW1wbGF0ZT5cbiAgPGNsaWVudC1vbmx5PlxuICAgIDxhIDppZD1cImlkXCIgOmNsYXNzPVwiYnV0dG9uQ2xhc3NcIiA6aHJlZj1cImB0ZWw6JHtyZXNvbHZlZFRlbGVwaG9uZX1gXCIgY2xhc3M9XCJibG9ja1wiPlxuICAgICAgPHZvbHQtYnV0dG9uIDpzaXplPVwic2l6ZVwiIGNsYXNzPVwidy1mdWxsIG1kOnctYXV0b1wiIHJvdW5kZWQ+XG4gICAgICAgIDxpY29uIHYtaWY9XCJ3aXRoSWNvblwiIG5hbWU9XCJpLWZhNy1zb2xpZDpwaG9uZVwiIC8+XG4gICAgICAgIDxzbG90PlxuICAgICAgICAgIHt7ICR0KHRleHQpIH19XG4gICAgICAgIDwvc2xvdD5cbiAgICAgIDwvdm9sdC1idXR0b24+XG4gICAgPC9hPlxuXG4gICAgPHRlbXBsYXRlICNmYWxsYmFjaz5cbiAgICAgIDxhIDpocmVmPVwiYHRlbDoke2ZhbGxiYWNrVGVsZXBob25lfWBcIiBjbGFzcz1cImJsb2NrXCI+XG4gICAgICAgIDx2b2x0LWJ1dHRvbiA6c2l6ZT1cInNpemVcIiBjbGFzcz1cInctZnVsbCBtZDp3LWF1dG9cIiByb3VuZGVkPlxuICAgICAgICAgIDxpY29uIHYtaWY9XCJ3aXRoSWNvblwiIG5hbWU9XCJpLWZhNy1zb2xpZDpwaG9uZVwiIC8+XG4gICAgICAgICAge3sgdGV4dCB9fVxuICAgICAgICA8L3ZvbHQtYnV0dG9uPlxuICAgICAgPC9hPlxuICAgIDwvdGVtcGxhdGU+XG4gIDwvY2xpZW50LW9ubHk+XG48L3RlbXBsYXRlPlxuXG48c2NyaXB0IHNldHVwIGxhbmc9XCJ0c1wiPlxuaW1wb3J0IHR5cGUgeyBCdXR0b25Qcm9wcyB9IGZyb20gJ3ByaW1ldnVlL2J1dHRvbidcbmltcG9ydCB0eXBlIHsgTnVsbGFibGUgfSBmcm9tICd+L3R5cGVzJ1xuXG4vLyBQcmV2ZW50IFZ1ZSBmcm9tIGF1dG8taW5oZXJpdGluZyBhdHRycyBvbiB0aGUgcm9vdCA8Q2xpZW50T25seT5cbmRlZmluZU9wdGlvbnMoeyBpbmhlcml0QXR0cnM6IGZhbHNlIH0pXG5cbmNvbnN0IHsgYnVzaW5lc3NEZXRhaWxzIH0gPSB1c2VCdXNpbmVzc0RldGFpbHMoKVxuXG5jb25zdCB7XG4gIGlkLFxuICBidXR0b25DbGFzcyxcbiAgdGVsZXBob25lID0gbnVsbCxcbiAgdGV4dCA9ICdNZSBjb250YWN0ZXInLFxuICB3aXRoSWNvbixcbiAgc2l6ZSA9ICdzbWFsbCdcbn0gPSBkZWZpbmVQcm9wczx7IGlkPzogc3RyaW5nLCBidXR0b25DbGFzcz86IHN0cmluZywgdGVsZXBob25lPzogTnVsbGFibGU8c3RyaW5nPiwgdGV4dD86IHN0cmluZywgd2l0aEljb24/OiBib29sZWFuLCBzaXplPzogQnV0dG9uUHJvcHNbJ3NpemUnXSB9PigpXG5cbmNvbnN0IGZhbGxiYWNrVGVsZXBob25lID0gYnVzaW5lc3NEZXRhaWxzLmNvbnRhY3QudGVsZXBob25lXG5jb25zdCByZXNvbHZlZFRlbGVwaG9uZSA9IGNvbXB1dGVkKCgpID0+IHRlbGVwaG9uZSB8fCBmYWxsYmFja1RlbGVwaG9uZSlcbjwvc2NyaXB0PlxuIl0sImZpbGUiOiIvVm9sdW1lcy9Db2RpbmcvUHJvamVjdHMvV2Vic2l0ZXMvaW5laWFoL2Zyb250ZW5kL2FwcC9jb21wb25lbnRzL2Jhc2UvVGVsZXBob25lQnV0dG9uLnZ1ZSJ9