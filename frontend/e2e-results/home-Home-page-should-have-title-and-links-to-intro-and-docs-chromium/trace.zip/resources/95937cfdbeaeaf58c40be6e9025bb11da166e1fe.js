import { t as __commonJSMin } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.cache/vite/client/deps/rolldown-runtime-BvCyGRYZ.js?v=7e73afc2";
//#region node_modules/.pnpm/dayjs@1.11.21/node_modules/dayjs/plugin/utc.js
var require_utc = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(t, i) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = i() : "function" == typeof define && define.amd ? define(i) : (t = "undefined" != typeof globalThis ? globalThis : t || self).dayjs_plugin_utc = i();
	})(exports, (function() {
		"use strict";
		var t = "minute", i = /[+-]\d\d(?::?\d\d)?/g, e = /([+-]|\d\d)/g;
		return function(s, f, n) {
			var u = f.prototype;
			n.utc = function(t) {
				return new f({
					date: t,
					utc: !0,
					args: arguments
				});
			}, u.utc = function(i) {
				var e = n(this.toDate(), {
					locale: this.$L,
					utc: !0
				});
				return i ? e.add(this.utcOffset(), t) : e;
			}, u.local = function() {
				return n(this.toDate(), {
					locale: this.$L,
					utc: !1
				});
			};
			var r = u.parse;
			u.parse = function(t) {
				t.utc && (this.$u = !0), this.$utils().u(t.$offset) || (this.$offset = t.$offset), r.call(this, t);
			};
			var o = u.init;
			u.init = function() {
				if (this.$u) {
					var t = this.$d;
					this.$y = t.getUTCFullYear(), this.$M = t.getUTCMonth(), this.$D = t.getUTCDate(), this.$W = t.getUTCDay(), this.$H = t.getUTCHours(), this.$m = t.getUTCMinutes(), this.$s = t.getUTCSeconds(), this.$ms = t.getUTCMilliseconds();
				} else o.call(this);
			};
			var a = u.utcOffset;
			u.utcOffset = function(s, f) {
				var n = this.$utils().u;
				if (n(s)) return this.$u ? 0 : n(this.$offset) ? a.call(this) : this.$offset;
				if ("string" == typeof s && (s = function(t) {
					void 0 === t && (t = "");
					var s = t.match(i);
					if (!s) return null;
					var f = ("" + s[0]).match(e) || [
						"-",
						0,
						0
					], n = f[0], u = 60 * +f[1] + +f[2];
					return 0 === u ? 0 : "+" === n ? u : -u;
				}(s), null === s)) return this;
				var u = Math.abs(s) <= 16 ? 60 * s : s;
				if (0 === u) return this.utc(f);
				var r = this.clone();
				if (f) return r.$offset = u, r.$u = !1, r;
				var o = this.$u ? this.toDate().getTimezoneOffset() : -1 * this.utcOffset();
				return (r = this.local().add(u + o, t)).$offset = u, r.$x.$localOffset = o, r;
			};
			var h = u.format;
			u.format = function(t) {
				var i = t || (this.$u ? "YYYY-MM-DDTHH:mm:ss[Z]" : "");
				return h.call(this, i);
			}, u.valueOf = function() {
				var t = this.$utils().u(this.$offset) ? 0 : this.$offset + (this.$x.$localOffset || this.$d.getTimezoneOffset());
				return this.$d.valueOf() - 6e4 * t;
			}, u.isUTC = function() {
				return !!this.$u;
			}, u.toISOString = function() {
				return this.toDate().toISOString();
			}, u.toString = function() {
				return this.toDate().toUTCString();
			};
			var l = u.toDate;
			u.toDate = function(t) {
				return "s" === t && this.$offset ? n(this.format("YYYY-MM-DD HH:mm:ss:SSS")).toDate() : l.call(this);
			};
			var c = u.diff;
			u.diff = function(t, i, e) {
				if (t && this.$u === t.$u) return c.call(this, t, i, e);
				var s = this.local(), f = n(t).local();
				return c.call(s, f, i, e);
			};
		};
	}));
}));
//#endregion
export default require_utc();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF5anNfcGx1Z2luX3V0Yy5qcyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8ucG5wbS9kYXlqc0AxLjExLjIxL25vZGVfbW9kdWxlcy9kYXlqcy9wbHVnaW4vdXRjLmpzIl0sInNvdXJjZXNDb250ZW50IjpbIiFmdW5jdGlvbih0LGkpe1wib2JqZWN0XCI9PXR5cGVvZiBleHBvcnRzJiZcInVuZGVmaW5lZFwiIT10eXBlb2YgbW9kdWxlP21vZHVsZS5leHBvcnRzPWkoKTpcImZ1bmN0aW9uXCI9PXR5cGVvZiBkZWZpbmUmJmRlZmluZS5hbWQ/ZGVmaW5lKGkpOih0PVwidW5kZWZpbmVkXCIhPXR5cGVvZiBnbG9iYWxUaGlzP2dsb2JhbFRoaXM6dHx8c2VsZikuZGF5anNfcGx1Z2luX3V0Yz1pKCl9KHRoaXMsKGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7dmFyIHQ9XCJtaW51dGVcIixpPS9bKy1dXFxkXFxkKD86Oj9cXGRcXGQpPy9nLGU9LyhbKy1dfFxcZFxcZCkvZztyZXR1cm4gZnVuY3Rpb24ocyxmLG4pe3ZhciB1PWYucHJvdG90eXBlO24udXRjPWZ1bmN0aW9uKHQpe3ZhciBpPXtkYXRlOnQsdXRjOiEwLGFyZ3M6YXJndW1lbnRzfTtyZXR1cm4gbmV3IGYoaSl9LHUudXRjPWZ1bmN0aW9uKGkpe3ZhciBlPW4odGhpcy50b0RhdGUoKSx7bG9jYWxlOnRoaXMuJEwsdXRjOiEwfSk7cmV0dXJuIGk/ZS5hZGQodGhpcy51dGNPZmZzZXQoKSx0KTplfSx1LmxvY2FsPWZ1bmN0aW9uKCl7cmV0dXJuIG4odGhpcy50b0RhdGUoKSx7bG9jYWxlOnRoaXMuJEwsdXRjOiExfSl9O3ZhciByPXUucGFyc2U7dS5wYXJzZT1mdW5jdGlvbih0KXt0LnV0YyYmKHRoaXMuJHU9ITApLHRoaXMuJHV0aWxzKCkudSh0LiRvZmZzZXQpfHwodGhpcy4kb2Zmc2V0PXQuJG9mZnNldCksci5jYWxsKHRoaXMsdCl9O3ZhciBvPXUuaW5pdDt1LmluaXQ9ZnVuY3Rpb24oKXtpZih0aGlzLiR1KXt2YXIgdD10aGlzLiRkO3RoaXMuJHk9dC5nZXRVVENGdWxsWWVhcigpLHRoaXMuJE09dC5nZXRVVENNb250aCgpLHRoaXMuJEQ9dC5nZXRVVENEYXRlKCksdGhpcy4kVz10LmdldFVUQ0RheSgpLHRoaXMuJEg9dC5nZXRVVENIb3VycygpLHRoaXMuJG09dC5nZXRVVENNaW51dGVzKCksdGhpcy4kcz10LmdldFVUQ1NlY29uZHMoKSx0aGlzLiRtcz10LmdldFVUQ01pbGxpc2Vjb25kcygpfWVsc2Ugby5jYWxsKHRoaXMpfTt2YXIgYT11LnV0Y09mZnNldDt1LnV0Y09mZnNldD1mdW5jdGlvbihzLGYpe3ZhciBuPXRoaXMuJHV0aWxzKCkudTtpZihuKHMpKXJldHVybiB0aGlzLiR1PzA6bih0aGlzLiRvZmZzZXQpP2EuY2FsbCh0aGlzKTp0aGlzLiRvZmZzZXQ7aWYoXCJzdHJpbmdcIj09dHlwZW9mIHMmJihzPWZ1bmN0aW9uKHQpe3ZvaWQgMD09PXQmJih0PVwiXCIpO3ZhciBzPXQubWF0Y2goaSk7aWYoIXMpcmV0dXJuIG51bGw7dmFyIGY9KFwiXCIrc1swXSkubWF0Y2goZSl8fFtcIi1cIiwwLDBdLG49ZlswXSx1PTYwKitmWzFdKyArZlsyXTtyZXR1cm4gMD09PXU/MDpcIitcIj09PW4/dTotdX0ocyksbnVsbD09PXMpKXJldHVybiB0aGlzO3ZhciB1PU1hdGguYWJzKHMpPD0xNj82MCpzOnM7aWYoMD09PXUpcmV0dXJuIHRoaXMudXRjKGYpO3ZhciByPXRoaXMuY2xvbmUoKTtpZihmKXJldHVybiByLiRvZmZzZXQ9dSxyLiR1PSExLHI7dmFyIG89dGhpcy4kdT90aGlzLnRvRGF0ZSgpLmdldFRpbWV6b25lT2Zmc2V0KCk6LTEqdGhpcy51dGNPZmZzZXQoKTtyZXR1cm4ocj10aGlzLmxvY2FsKCkuYWRkKHUrbyx0KSkuJG9mZnNldD11LHIuJHguJGxvY2FsT2Zmc2V0PW8scn07dmFyIGg9dS5mb3JtYXQ7dS5mb3JtYXQ9ZnVuY3Rpb24odCl7dmFyIGk9dHx8KHRoaXMuJHU/XCJZWVlZLU1NLUREVEhIOm1tOnNzW1pdXCI6XCJcIik7cmV0dXJuIGguY2FsbCh0aGlzLGkpfSx1LnZhbHVlT2Y9ZnVuY3Rpb24oKXt2YXIgdD10aGlzLiR1dGlscygpLnUodGhpcy4kb2Zmc2V0KT8wOnRoaXMuJG9mZnNldCsodGhpcy4keC4kbG9jYWxPZmZzZXR8fHRoaXMuJGQuZ2V0VGltZXpvbmVPZmZzZXQoKSk7cmV0dXJuIHRoaXMuJGQudmFsdWVPZigpLTZlNCp0fSx1LmlzVVRDPWZ1bmN0aW9uKCl7cmV0dXJuISF0aGlzLiR1fSx1LnRvSVNPU3RyaW5nPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMudG9EYXRlKCkudG9JU09TdHJpbmcoKX0sdS50b1N0cmluZz1mdW5jdGlvbigpe3JldHVybiB0aGlzLnRvRGF0ZSgpLnRvVVRDU3RyaW5nKCl9O3ZhciBsPXUudG9EYXRlO3UudG9EYXRlPWZ1bmN0aW9uKHQpe3JldHVyblwic1wiPT09dCYmdGhpcy4kb2Zmc2V0P24odGhpcy5mb3JtYXQoXCJZWVlZLU1NLUREIEhIOm1tOnNzOlNTU1wiKSkudG9EYXRlKCk6bC5jYWxsKHRoaXMpfTt2YXIgYz11LmRpZmY7dS5kaWZmPWZ1bmN0aW9uKHQsaSxlKXtpZih0JiZ0aGlzLiR1PT09dC4kdSlyZXR1cm4gYy5jYWxsKHRoaXMsdCxpLGUpO3ZhciBzPXRoaXMubG9jYWwoKSxmPW4odCkubG9jYWwoKTtyZXR1cm4gYy5jYWxsKHMsZixpLGUpfX19KSk7Il0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXSwibWFwcGluZ3MiOiI7OztDQUFBLENBQUMsU0FBUyxHQUFFLEdBQUU7RUFBQyxZQUFVLE9BQU8sV0FBUyxlQUFhLE9BQU8sU0FBTyxPQUFPLFVBQVEsRUFBRSxJQUFFLGNBQVksT0FBTyxVQUFRLE9BQU8sTUFBSSxPQUFPLENBQUMsSUFBRSxDQUFDLElBQUUsZUFBYSxPQUFPLGFBQVcsYUFBVyxLQUFHLEtBQUEsQ0FBTSxtQkFBaUIsRUFBRTtDQUFDLEVBQUEsQ0FBQyxVQUFPLFdBQVU7RUFBQztFQUFhLElBQUksSUFBRSxVQUFTLElBQUUsd0JBQXVCLElBQUU7RUFBZSxPQUFPLFNBQVMsR0FBRSxHQUFFLEdBQUU7R0FBQyxJQUFJLElBQUUsRUFBRTtHQUFVLEVBQUUsTUFBSSxTQUFTLEdBQUU7SUFBc0MsT0FBTyxJQUFJLEVBQUU7S0FBM0MsTUFBSztLQUFFLEtBQUksQ0FBQztLQUFFLE1BQUs7SUFBd0IsQ0FBQztHQUFDLEdBQUUsRUFBRSxNQUFJLFNBQVMsR0FBRTtJQUFDLElBQUksSUFBRSxFQUFFLEtBQUssT0FBTyxHQUFFO0tBQUMsUUFBTyxLQUFLO0tBQUcsS0FBSSxDQUFDO0lBQUMsQ0FBQztJQUFFLE9BQU8sSUFBRSxFQUFFLElBQUksS0FBSyxVQUFVLEdBQUUsQ0FBQyxJQUFFO0dBQUMsR0FBRSxFQUFFLFFBQU0sV0FBVTtJQUFDLE9BQU8sRUFBRSxLQUFLLE9BQU8sR0FBRTtLQUFDLFFBQU8sS0FBSztLQUFHLEtBQUksQ0FBQztJQUFDLENBQUM7R0FBQztHQUFFLElBQUksSUFBRSxFQUFFO0dBQU0sRUFBRSxRQUFNLFNBQVMsR0FBRTtJQUFDLEVBQUUsUUFBTSxLQUFLLEtBQUcsQ0FBQyxJQUFHLEtBQUssT0FBTyxDQUFDLENBQUMsRUFBRSxFQUFFLE9BQU8sTUFBSSxLQUFLLFVBQVEsRUFBRSxVQUFTLEVBQUUsS0FBSyxNQUFLLENBQUM7R0FBQztHQUFFLElBQUksSUFBRSxFQUFFO0dBQUssRUFBRSxPQUFLLFdBQVU7SUFBQyxJQUFHLEtBQUssSUFBRztLQUFDLElBQUksSUFBRSxLQUFLO0tBQUcsS0FBSyxLQUFHLEVBQUUsZUFBZSxHQUFFLEtBQUssS0FBRyxFQUFFLFlBQVksR0FBRSxLQUFLLEtBQUcsRUFBRSxXQUFXLEdBQUUsS0FBSyxLQUFHLEVBQUUsVUFBVSxHQUFFLEtBQUssS0FBRyxFQUFFLFlBQVksR0FBRSxLQUFLLEtBQUcsRUFBRSxjQUFjLEdBQUUsS0FBSyxLQUFHLEVBQUUsY0FBYyxHQUFFLEtBQUssTUFBSSxFQUFFLG1CQUFtQjtJQUFDLE9BQU0sRUFBRSxLQUFLLElBQUk7R0FBQztHQUFFLElBQUksSUFBRSxFQUFFO0dBQVUsRUFBRSxZQUFVLFNBQVMsR0FBRSxHQUFFO0lBQUMsSUFBSSxJQUFFLEtBQUssT0FBTyxDQUFDLENBQUM7SUFBRSxJQUFHLEVBQUUsQ0FBQyxHQUFFLE9BQU8sS0FBSyxLQUFHLElBQUUsRUFBRSxLQUFLLE9BQU8sSUFBRSxFQUFFLEtBQUssSUFBSSxJQUFFLEtBQUs7SUFBUSxJQUFHLFlBQVUsT0FBTyxNQUFJLElBQUUsU0FBUyxHQUFFO0tBQUMsS0FBSyxNQUFJLE1BQUksSUFBRTtLQUFJLElBQUksSUFBRSxFQUFFLE1BQU0sQ0FBQztLQUFFLElBQUcsQ0FBQyxHQUFFLE9BQU87S0FBSyxJQUFJLEtBQUcsS0FBRyxFQUFFLEdBQUEsQ0FBSSxNQUFNLENBQUMsS0FBRztNQUFDO01BQUk7TUFBRTtLQUFDLEdBQUUsSUFBRSxFQUFFLElBQUcsSUFBRSxLQUFHLENBQUMsRUFBRSxLQUFJLENBQUMsRUFBRTtLQUFHLE9BQU8sTUFBSSxJQUFFLElBQUUsUUFBTSxJQUFFLElBQUUsQ0FBQztJQUFDLEVBQUUsQ0FBQyxHQUFFLFNBQU8sSUFBRyxPQUFPO0lBQUssSUFBSSxJQUFFLEtBQUssSUFBSSxDQUFDLEtBQUcsS0FBRyxLQUFHLElBQUU7SUFBRSxJQUFHLE1BQUksR0FBRSxPQUFPLEtBQUssSUFBSSxDQUFDO0lBQUUsSUFBSSxJQUFFLEtBQUssTUFBTTtJQUFFLElBQUcsR0FBRSxPQUFPLEVBQUUsVUFBUSxHQUFFLEVBQUUsS0FBRyxDQUFDLEdBQUU7SUFBRSxJQUFJLElBQUUsS0FBSyxLQUFHLEtBQUssT0FBTyxDQUFDLENBQUMsa0JBQWtCLElBQUUsS0FBRyxLQUFLLFVBQVU7SUFBRSxPQUFNLENBQUMsSUFBRSxLQUFLLE1BQU0sQ0FBQyxDQUFDLElBQUksSUFBRSxHQUFFLENBQUMsRUFBQSxDQUFHLFVBQVEsR0FBRSxFQUFFLEdBQUcsZUFBYSxHQUFFO0dBQUM7R0FBRSxJQUFJLElBQUUsRUFBRTtHQUFPLEVBQUUsU0FBTyxTQUFTLEdBQUU7SUFBQyxJQUFJLElBQUUsTUFBSSxLQUFLLEtBQUcsMkJBQXlCO0lBQUksT0FBTyxFQUFFLEtBQUssTUFBSyxDQUFDO0dBQUMsR0FBRSxFQUFFLFVBQVEsV0FBVTtJQUFDLElBQUksSUFBRSxLQUFLLE9BQU8sQ0FBQyxDQUFDLEVBQUUsS0FBSyxPQUFPLElBQUUsSUFBRSxLQUFLLFdBQVMsS0FBSyxHQUFHLGdCQUFjLEtBQUssR0FBRyxrQkFBa0I7SUFBRyxPQUFPLEtBQUssR0FBRyxRQUFRLElBQUUsTUFBSTtHQUFDLEdBQUUsRUFBRSxRQUFNLFdBQVU7SUFBQyxPQUFNLENBQUMsQ0FBQyxLQUFLO0dBQUUsR0FBRSxFQUFFLGNBQVksV0FBVTtJQUFDLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxZQUFZO0dBQUMsR0FBRSxFQUFFLFdBQVMsV0FBVTtJQUFDLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxZQUFZO0dBQUM7R0FBRSxJQUFJLElBQUUsRUFBRTtHQUFPLEVBQUUsU0FBTyxTQUFTLEdBQUU7SUFBQyxPQUFNLFFBQU0sS0FBRyxLQUFLLFVBQVEsRUFBRSxLQUFLLE9BQU8seUJBQXlCLENBQUMsQ0FBQyxDQUFDLE9BQU8sSUFBRSxFQUFFLEtBQUssSUFBSTtHQUFDO0dBQUUsSUFBSSxJQUFFLEVBQUU7R0FBSyxFQUFFLE9BQUssU0FBUyxHQUFFLEdBQUUsR0FBRTtJQUFDLElBQUcsS0FBRyxLQUFLLE9BQUssRUFBRSxJQUFHLE9BQU8sRUFBRSxLQUFLLE1BQUssR0FBRSxHQUFFLENBQUM7SUFBRSxJQUFJLElBQUUsS0FBSyxNQUFNLEdBQUUsSUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU07SUFBRSxPQUFPLEVBQUUsS0FBSyxHQUFFLEdBQUUsR0FBRSxDQUFDO0dBQUM7RUFBQztDQUFDLEVBQUUifQ==