import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/error.vue");import { default as __nuxt_component_0 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxtjs+i18n@10.6.0_@vue+compiler-dom@3.5.40_db0@0.3.4_better-sqlite3@13.0.2_drizzle-or_ebcb91ac37e09cc979ede2167e22c07a/node_modules/@nuxtjs/i18n/dist/runtime/components/NuxtLinkLocale.js?v=7e73afc2";
import { default as __nuxt_component_1 } from "/_nuxt/components/volt/Card.vue";
import { default as __nuxt_component_2 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/components/dev-only.js?v=7e73afc2";
import { default as __nuxt_component_3 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/components/nuxt-layout.js?v=7e73afc2";
import { useError as _$__useError, clearError as _$__clearError } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/composables/error.js?v=7e73afc2";
import { preloadRouteComponents as _$__preloadRouteComponents } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/composables/preload.js?v=7e73afc2";;import { __nuxtTimelineWrap } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+devtools@3.4.1_db0@0.3.4_better-sqlite3@13.0.2_drizzle-orm@0.45.2_@opentelemetry+_0e55243a794e05cb19a29a0506aae086/node_modules/@nuxt/devtools/dist/runtime/function-metrics-helpers.js?v=7e73afc2";const useError = __nuxtTimelineWrap("useError", _$__useError);const preloadRouteComponents = __nuxtTimelineWrap("preloadRouteComponents", _$__preloadRouteComponents);const clearError = __nuxtTimelineWrap("clearError", _$__clearError);
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@8.2.0_@types+node@26.1.2_esbuild@0.28.1_jiti@2.7.0_sa_bcac4fa99282966dd94ca7ad2dfebde1/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=7e73afc2"
import { withAsyncContext as _withAsyncContext, defineComponent as _defineComponent } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _sfc_main = /*@__PURE__*/ _defineComponent({
	__name: "error",
	async setup(__props, { expose: __expose }) {
		__expose();
		let __temp, __restore;
		/**
		* Utils
		*/
		const error = useError();
		[__temp, __restore] = _withAsyncContext(() => preloadRouteComponents("/")), await __temp, __restore();
		/**
		* A function that handles the
		* redirect to the home page
		*/
		function handleError() {
			void clearError({ redirect: "/" });
		}
		const __returned__ = {
			error,
			handleError
		};
		Object.defineProperty(__returned__, "__isScriptSetup", {
			enumerable: false,
			value: true
		});
		return __returned__;
	}
});
import { toDisplayString as _toDisplayString, createElementVNode as _createElementVNode, createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _hoisted_1 = { class: "font-sans relative" };
const _hoisted_2 = { class: "error-page my-20" };
const _hoisted_3 = { class: "mx-auto md:max-w-2xl" };
const _hoisted_4 = { class: "text-5xl" };
const _hoisted_5 = { class: "text-2xl font-light" };
const _hoisted_6 = { class: "p-5 rounded-3xl bg-primary-100 mt-10" };
const _hoisted_7 = { class: "bg-primary-200 rounded-3xl p-10 max-w-4xl overflow-x-scroll" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
	const _component_nuxt_link_locale = __nuxt_component_0;
	const _component_volt_card = __nuxt_component_1;
	const _component_dev_only = __nuxt_component_2;
	const _component_nuxt_layout = __nuxt_component_3;
	return _openBlock(), _tracer(2,2,_createElementBlock("section", _hoisted_1, [_tracer(3,4,_createVNode(_component_nuxt_layout, null, {
		default: _withCtx(() => [_tracer(4,6,_createElementVNode("section", _hoisted_2, [_tracer(5,8,_createElementVNode("div", _hoisted_3, [_tracer(6,10,_createVNode(_component_volt_card, null, {
			content: _withCtx(() => [
				_tracer(8,14,_createElementVNode(
					"h1",
					_hoisted_4,
					_toDisplayString($setup.error?.status),
					1
					/* TEXT */
				)),
				_tracer(11,14,_createElementVNode(
					"p",
					_hoisted_5,
					_toDisplayString($setup.error?.message),
					1
					/* TEXT */
				)),
				_tracer(15,14,_createVNode(_component_nuxt_link_locale, {
					id: "link-error",
					to: "/",
					"aria-label": "Accueil",
					onClick: $setup.handleError
				}, {
					default: _withCtx(() => [..._cache[0] || (_cache[0] = [_createTextVNode(
						_toDisplayString("Accueil"),
						-1
						/* CACHED */
					)])]),
					_: 1
				}))
			]),
			_: 1
		})), _tracer(21,10,_createVNode(_component_dev_only, null, {
			default: _withCtx(() => [_tracer(22,12,_createElementVNode("div", _hoisted_6, [_tracer(23,14,_createElementVNode("div", _hoisted_7, [_tracer(24,16,_createElementVNode(
				"pre",
				null,
				"                  " + _toDisplayString(JSON.stringify($setup.error, null, 2)) + "\n                ",
				1
				/* TEXT */
			))]))]))]),
			_: 1
		}))]))]))]),
		_: 1
	}))]));
}
_sfc_main.__hmrId = "f249f6ff";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.on("file-changed", ({ file }) => {
	__VUE_HMR_RUNTIME__.CHANGED_FILE = file;
});
import.meta.hot.accept((mod) => {
	if (!mod) return;
	const { default: updated, _rerender_only } = mod;
	if (_rerender_only) {
		__VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
	} else {
		__VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
	}
});
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper";
export default /*#__PURE__*/ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "/Volumes/Coding/Projects/Websites/ineiah/frontend/app/error.vue"]]);

function _tracer(line, column, vnode) { return _tracerRecordPosition("app/error.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztFQXdDQSxNQUFNLFFBQVEsU0FBUztFQUV2Qiw4Q0FBTSx1QkFBdUIsR0FBRzs7Ozs7RUFNaEMsU0FBUyxjQUFjO0dBQ3JCLEtBQUssV0FBVyxFQUFFLFVBQVUsSUFBSSxDQUFDO0VBQ25DOzs7Ozs7Ozs7Ozs7O0FBakRXLDRCQUFNLHFCQUFvQjtBQUV0Qiw0QkFBTSxtQkFBa0I7QUFDMUIsNEJBQU0sdUJBQXNCO0FBR3ZCLDRCQUFNLFdBQVU7QUFHakIsNEJBQU0sc0JBQXFCO0FBVzNCLDRCQUFNLHVDQUFzQztBQUMxQyw0QkFBTSw4REFBNkQ7Ozs7OztDQXJCcEYscURBK0JVLFdBL0JWLFlBK0JVLGFBOUJSLGFBNkJjO0VBNUJaLHdCQTJCVSxhQTNCVixvQkEyQlUsV0EzQlYsWUEyQlUsYUExQlIsb0JBeUJNLE9BekJOLFlBeUJNLGNBeEJKLGFBYVk7R0FaQyxTQUFPLGVBR1g7aUJBRkw7S0FFSztLQUZMO0tBRUssaUJBREEsY0FBTyxNQUFNO0tBQUE7O0lBQUE7a0JBRWxCO0tBRUk7S0FGSjtLQUVJLGlCQURDLGNBQU8sT0FBTztLQUFBOztJQUFBO2tCQUduQixhQUVtQjtLQUZELElBQUc7S0FBYSxJQUFHO0tBQUksY0FBVztLQUFXLFNBQU87O0tBQ3BFLHdCQUFlLCtCQUFaO01BQUEsMEJBQVM7TUFBQTs7S0FBQTs7Ozs7cUJBS2xCLGFBUVc7R0FQVCx3QkFNTSxlQU5OLG9CQU1NLE9BTk4sWUFNTSxlQUxKLG9CQUlNLE9BSk4sWUFJTSxlQUhKO0lBRU07SUFBQTtJQUZELHVCQUNILGlCQUFHLEtBQUssVUFBVSxjQUFLLFlBQWE7SUFDdEM7O0dBQUEiLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImVycm9yLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XG4gIDxzZWN0aW9uIGNsYXNzPVwiZm9udC1zYW5zIHJlbGF0aXZlXCI+XG4gICAgPG51eHQtbGF5b3V0PlxuICAgICAgPHNlY3Rpb24gY2xhc3M9XCJlcnJvci1wYWdlIG15LTIwXCI+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJteC1hdXRvIG1kOm1heC13LTJ4bFwiPlxuICAgICAgICAgIDx2b2x0LWNhcmQ+XG4gICAgICAgICAgICA8dGVtcGxhdGUgI2NvbnRlbnQ+XG4gICAgICAgICAgICAgIDxoMSBjbGFzcz1cInRleHQtNXhsXCI+XG4gICAgICAgICAgICAgICAge3sgZXJyb3I/LnN0YXR1cyB9fVxuICAgICAgICAgICAgICA8L2gxPlxuICAgICAgICAgICAgICA8cCBjbGFzcz1cInRleHQtMnhsIGZvbnQtbGlnaHRcIj5cbiAgICAgICAgICAgICAgICB7eyBlcnJvcj8ubWVzc2FnZSB9fVxuICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgPG51eHQtbGluay1sb2NhbGUgaWQ9XCJsaW5rLWVycm9yXCIgdG89XCIvXCIgYXJpYS1sYWJlbD1cIkFjY3VlaWxcIiBAY2xpY2s9XCJoYW5kbGVFcnJvclwiPlxuICAgICAgICAgICAgICAgIHt7ICdBY2N1ZWlsJyB9fVxuICAgICAgICAgICAgICA8L251eHQtbGluay1sb2NhbGU+XG4gICAgICAgICAgICA8L3RlbXBsYXRlPlxuICAgICAgICAgIDwvdm9sdC1jYXJkPlxuXG4gICAgICAgICAgPGRldi1vbmx5PlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cInAtNSByb3VuZGVkLTN4bCBiZy1wcmltYXJ5LTEwMCBtdC0xMFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiYmctcHJpbWFyeS0yMDAgcm91bmRlZC0zeGwgcC0xMCBtYXgtdy00eGwgb3ZlcmZsb3cteC1zY3JvbGxcIj5cbiAgICAgICAgICAgICAgICA8cHJlPlxuICAgICAgICAgICAgICAgICAge3sgSlNPTi5zdHJpbmdpZnkoZXJyb3IsIG51bGwsIDIpIH19XG4gICAgICAgICAgICAgICAgPC9wcmU+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kZXYtb25seT5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L3NlY3Rpb24+XG4gICAgPC9udXh0LWxheW91dD5cbiAgPC9zZWN0aW9uPlxuPC90ZW1wbGF0ZT5cblxuPHNjcmlwdCBzZXR1cCBsYW5nPVwidHNcIj5cbi8qKlxuICogVXRpbHNcbiAqL1xuXG5jb25zdCBlcnJvciA9IHVzZUVycm9yKClcblxuYXdhaXQgcHJlbG9hZFJvdXRlQ29tcG9uZW50cygnLycpXG5cbi8qKlxuICogQSBmdW5jdGlvbiB0aGF0IGhhbmRsZXMgdGhlXG4gKiByZWRpcmVjdCB0byB0aGUgaG9tZSBwYWdlXG4gKi9cbmZ1bmN0aW9uIGhhbmRsZUVycm9yKCkge1xuICB2b2lkIGNsZWFyRXJyb3IoeyByZWRpcmVjdDogJy8nIH0pXG59XG48L3NjcmlwdD5cbiJdLCJmaWxlIjoiL1ZvbHVtZXMvQ29kaW5nL1Byb2plY3RzL1dlYnNpdGVzL2luZWlhaC9mcm9udGVuZC9hcHAvZXJyb3IudnVlIn0=