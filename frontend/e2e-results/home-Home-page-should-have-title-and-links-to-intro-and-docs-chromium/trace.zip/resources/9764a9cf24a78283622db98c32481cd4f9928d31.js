/*!
* shared v11.4.8
* (c) 2026 kazuya kawaguchi
* Released under the MIT License.
*/
/**
* Original Utilities
* written by kazuya kawaguchi
*/
const inBrowser = typeof window !== "undefined";
let mark;
let measure;
if ("development" !== "production") {
	const perf = inBrowser && window.performance;
	if (perf && perf.mark && perf.measure && perf.clearMarks && perf.clearMeasures) {
		mark = (tag) => {
			perf.mark(tag);
		};
		measure = (name, startTag, endTag) => {
			perf.measure(name, startTag, endTag);
			perf.clearMarks(startTag);
			perf.clearMarks(endTag);
		};
	}
}
const RE_ARGS = /\{([0-9a-zA-Z]+)\}/g;
/* eslint-disable */
function format(message, ...args) {
	if (args.length === 1 && isObject(args[0])) {
		args = args[0];
	}
	if (!args || !args.hasOwnProperty) {
		args = {};
	}
	return message.replace(RE_ARGS, (match, identifier) => {
		return args.hasOwnProperty(identifier) ? args[identifier] : "";
	});
}
const makeSymbol = (name, shareable = false) => !shareable ? Symbol(name) : Symbol.for(name);
const generateFormatCacheKey = (locale, key, source) => friendlyJSONstringify({
	l: locale,
	k: key,
	s: source
});
const friendlyJSONstringify = (json) => JSON.stringify(json).replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029").replace(/\u0027/g, "\\u0027");
const isNumber = (val) => typeof val === "number" && isFinite(val);
const isDate = (val) => toTypeString(val) === "[object Date]";
const isRegExp = (val) => toTypeString(val) === "[object RegExp]";
const isEmptyObject = (val) => isPlainObject(val) && Object.keys(val).length === 0;
const assign = Object.assign;
const _create = Object.create;
const create = (obj = null) => _create(obj);
let _globalThis;
const getGlobalThis = () => {
	// prettier-ignore
	return _globalThis || (_globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : create());
};
const hasOwnProperty = Object.prototype.hasOwnProperty;
function hasOwn(obj, key) {
	return hasOwnProperty.call(obj, key);
}
/* eslint-enable */
/**
* Useful Utilities By Evan you
* Modified by kazuya kawaguchi
* MIT License
* https://github.com/vuejs/vue-next/blob/master/packages/shared/src/index.ts
* https://github.com/vuejs/vue-next/blob/master/packages/shared/src/codeframe.ts
*/
const isArray = Array.isArray;
const isFunction = (val) => typeof val === "function";
const isString = (val) => typeof val === "string";
const isBoolean = (val) => typeof val === "boolean";
const isSymbol = (val) => typeof val === "symbol";
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const isObject = (val) => val !== null && typeof val === "object";
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const isPromise = (val) => {
	return isObject(val) && isFunction(val.then) && isFunction(val.catch);
};
const objectToString = Object.prototype.toString;
const toTypeString = (value) => objectToString.call(value);
const isPlainObject = (val) => toTypeString(val) === "[object Object]";
// for converting list and named values to displayed strings.
const toDisplayString = (val) => {
	return val == null ? "" : isArray(val) || isPlainObject(val) && val.toString === objectToString ? JSON.stringify(val, null, 2) : String(val);
};
function join(items, separator = "") {
	return items.reduce((str, item, index) => index === 0 ? str + item : str + separator + item, "");
}
const RANGE = 2;
function generateCodeFrame(source, start = 0, end = source.length) {
	const lines = source.split(/\r?\n/);
	let count = 0;
	const res = [];
	for (let i = 0; i < lines.length; i++) {
		count += lines[i].length + 1;
		if (count >= start) {
			for (let j = i - RANGE; j <= i + RANGE || end > count; j++) {
				if (j < 0 || j >= lines.length) continue;
				const line = j + 1;
				res.push(`${line}${" ".repeat(3 - String(line).length)}|  ${lines[j]}`);
				const lineLength = lines[j].length;
				if (j === i) {
					// push underline
					const pad = start - (count - lineLength) + 1;
					const length = Math.max(1, end > count ? lineLength - pad : end - start);
					res.push(`   |  ` + " ".repeat(pad) + "^".repeat(length));
				} else if (j > i) {
					if (end > count) {
						const length = Math.max(Math.min(end - count, lineLength), 1);
						res.push(`   |  ` + "^".repeat(length));
					}
					count += lineLength + 1;
				}
			}
			break;
		}
	}
	return res.join("\n");
}
function warn(msg, err) {
	if (typeof console !== "undefined") {
		console.warn(`[intlify] ` + msg);
		/* istanbul ignore if */
		if (err) {
			console.warn(err.stack);
		}
	}
}
const hasWarned = {};
function warnOnce(msg) {
	if (!hasWarned[msg]) {
		hasWarned[msg] = true;
		warn(msg);
	}
}
function escapeHtml(rawText) {
	return rawText.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;").replace(/\//g, "&#x2F;").replace(/=/g, "&#x3D;");
}
function escapeAttributeValue(value) {
	return value.replace(/&(?![a-z0-9#]{2,6};)/gi, "&amp;").replace(/"/g, "&quot;").replace(/'/g, "&apos;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
const javascriptSchemePattern = /^javascript:/i;
const urlAttributePattern = /^(?:href|src|action|formaction)$/i;
const numericCharacterReferencePattern = /&#(?:x([0-9a-f]+)|(\d+));?/gi;
const namedWhitespaceCharacterReferencePattern = /&(?:Tab|NewLine);/g;
const colonCharacterReferencePattern = /&colon;?/gi;
// eslint-disable-next-line no-control-regex -- URL scheme normalization requires the full control range
const controlOrWhitespacePattern = /[\u0000-\u0020\u007f-\u009f]/g;
const eventHandlerPattern = /(?:^|[\s"'<>/])on\w+\s*=\s*["']?[^"'>]+["']?/i;
const eventHandlerAttributePattern = /(^|[\s"'<>/])on(\w+\s*=)/gi;
const unquotedUrlAttributePattern = /(^|[\s"'<>/])((?:href|src|action|formaction)\s*=\s*)([^\s"'=<>`]+)/gi;
function decodeNumericCharacterReference(match, hex, decimal) {
	const digits = hex || decimal;
	if (!digits) {
		return match;
	}
	const codePoint = Number.parseInt(digits, hex ? 16 : 10);
	return codePoint <= 127 ? String.fromCharCode(codePoint) : match;
}
function hasJavascriptScheme(value) {
	const normalized = value.replace(numericCharacterReferencePattern, decodeNumericCharacterReference).replace(namedWhitespaceCharacterReferencePattern, "").replace(colonCharacterReferencePattern, ":").replace(controlOrWhitespacePattern, "");
	return javascriptSchemePattern.test(normalized);
}
function sanitizeStyleValue(value) {
	const urlPattern = /url\s*\(/gi;
	let sanitized = "";
	let cursor = 0;
	let match;
	while ((match = urlPattern.exec(value)) !== null) {
		const urlStart = match.index;
		const openParenIndex = urlPattern.lastIndex - 1;
		let index = openParenIndex + 1;
		let depth = 1;
		let quote = null;
		for (; index < value.length; index++) {
			const char = value[index];
			if (quote) {
				if (char === quote) {
					quote = null;
				}
				continue;
			}
			if (char === "\"" || char === "'") {
				quote = char;
			} else if (char === "(") {
				depth++;
			} else if (char === ")") {
				depth--;
				if (depth === 0) {
					break;
				}
			}
		}
		if (depth !== 0) {
			break;
		}
		const rawUrlValue = value.slice(openParenIndex + 1, index).trim();
		const unquotedUrlValue = rawUrlValue.startsWith("\"") && rawUrlValue.endsWith("\"") || rawUrlValue.startsWith("'") && rawUrlValue.endsWith("'") ? rawUrlValue.slice(1, -1).trim() : rawUrlValue;
		sanitized += value.slice(cursor, urlStart);
		sanitized += hasJavascriptScheme(unquotedUrlValue) ? "url(about:blank)" : value.slice(urlStart, index + 1);
		cursor = index + 1;
	}
	return sanitized + value.slice(cursor);
}
function sanitizeAttributeValue(attrName, value) {
	if (urlAttributePattern.test(attrName) && hasJavascriptScheme(value)) {
		return "about:blank";
	}
	const sanitizedValue = attrName.toLowerCase() === "style" ? sanitizeStyleValue(value) : value;
	return escapeAttributeValue(sanitizedValue);
}
function sanitizeTranslatedHtml(html) {
	// Escape dangerous characters in attribute values
	// Process attributes with double quotes
	html = html.replace(/([\w:-]+)\s*=\s*"([^"]*)"/g, (_, attrName, attrValue) => `${attrName}="${sanitizeAttributeValue(attrName, attrValue)}"`);
	// Process attributes with single quotes
	html = html.replace(/([\w:-]+)\s*=\s*'([^']*)'/g, (_, attrName, attrValue) => `${attrName}='${sanitizeAttributeValue(attrName, attrValue)}'`);
	// Detect and neutralize event handler attributes
	if (eventHandlerPattern.test(html)) {
		if ("development" !== "production") {
			warn("Potentially dangerous event handlers detected in translation. " + "Consider removing onclick, onerror, etc. from your translation messages.");
		}
		// Neutralize event handler attributes by escaping 'on'
		html = html.replace(eventHandlerAttributePattern, "$1&#111;n$2");
	}
	// Disable javascript: URLs in unquoted attributes
	html = html.replace(unquotedUrlAttributePattern, (match, boundary, prefix, attrValue) => hasJavascriptScheme(attrValue) ? `${boundary}${prefix}about:blank` : match);
	return html;
}
/**
* Event emitter, forked from the below:
* - original repository url: https://github.com/developit/mitt
* - code url: https://github.com/developit/mitt/blob/master/src/index.ts
* - author: Jason Miller (https://github.com/developit)
* - license: MIT
*/
/**
* Create a event emitter
*
* @returns An event emitter
*/
function createEmitter() {
	const events = new Map();
	const emitter = {
		events,
		on(event, handler) {
			const handlers = events.get(event);
			const added = handlers && handlers.push(handler);
			if (!added) {
				events.set(event, [handler]);
			}
		},
		off(event, handler) {
			const handlers = events.get(event);
			if (handlers) {
				handlers.splice(handlers.indexOf(handler) >>> 0, 1);
			}
		},
		emit(event, payload) {
			(events.get(event) || []).slice().map((handler) => handler(payload));
			(events.get("*") || []).slice().map((handler) => handler(event, payload));
		}
	};
	return emitter;
}
const isNotObjectOrIsArray = (val) => !isObject(val) || isArray(val);
// eslint-disable-next-line @typescript-eslint/no-explicit-any
function deepCopy(src, des) {
	// src and des should both be objects, and none of them can be a array
	if (isNotObjectOrIsArray(src) || isNotObjectOrIsArray(des)) {
		throw new Error("Invalid value");
	}
	const stack = [{
		src,
		des
	}];
	while (stack.length) {
		const { src, des } = stack.pop();
		// using `Object.keys` which skips prototype properties
		Object.keys(src).forEach((key) => {
			if (key === "__proto__") {
				return;
			}
			// if src[key] is an object/array, set des[key]
			// to empty object/array to prevent setting by reference
			if (isObject(src[key]) && !isObject(des[key])) {
				des[key] = Array.isArray(src[key]) ? [] : create();
			}
			if (isNotObjectOrIsArray(des[key]) || isNotObjectOrIsArray(src[key])) {
				// replace with src[key] when:
				// src[key] or des[key] is not an object, or
				// src[key] or des[key] is an array
				des[key] = src[key];
			} else {
				// src[key] and des[key] are both objects, merge them
				stack.push({
					src: src[key],
					des: des[key]
				});
			}
		});
	}
}
export { assign, create, createEmitter, deepCopy, escapeHtml, format, friendlyJSONstringify, generateCodeFrame, generateFormatCacheKey, getGlobalThis, hasOwn, inBrowser, isArray, isBoolean, isDate, isEmptyObject, isFunction, isNumber, isObject, isPlainObject, isPromise, isRegExp, isString, isSymbol, join, makeSymbol, mark, measure, objectToString, sanitizeTranslatedHtml, toDisplayString, toTypeString, warn, warnOnce };

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBU0EsTUFBTSxZQUFZLE9BQU8sV0FBVztBQUNwQyxJQUFJO0FBQ0osSUFBSTtBQUNKLHNCQUE4QixjQUFlO0NBQ3pDLE1BQU0sT0FBTyxhQUFhLE9BQU87Q0FDakMsSUFBSSxRQUNBLEtBQUssUUFDTCxLQUFLLFdBQ0wsS0FBSyxjQUVMLEtBQUssZUFBZTtFQUNwQixRQUFRLFFBQVE7R0FDWixLQUFLLEtBQUssR0FBRztFQUNqQjtFQUNBLFdBQVcsTUFBTSxVQUFVLFdBQVc7R0FDbEMsS0FBSyxRQUFRLE1BQU0sVUFBVSxNQUFNO0dBQ25DLEtBQUssV0FBVyxRQUFRO0dBQ3hCLEtBQUssV0FBVyxNQUFNO0VBQzFCO0NBQ0o7QUFDSjtBQUNBLE1BQU0sVUFBVTs7QUFFaEIsU0FBUyxPQUFPLFNBQVMsR0FBRyxNQUFNO0NBQzlCLElBQUksS0FBSyxXQUFXLEtBQUssU0FBUyxLQUFLLEVBQUUsR0FBRztFQUN4QyxPQUFPLEtBQUs7Q0FDaEI7Q0FDQSxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssZ0JBQWdCO0VBQy9CLE9BQU8sQ0FBQztDQUNaO0NBQ0EsT0FBTyxRQUFRLFFBQVEsVUFBVSxPQUFPLGVBQWU7RUFDbkQsT0FBTyxLQUFLLGVBQWUsVUFBVSxJQUFJLEtBQUssY0FBYztDQUNoRSxDQUFDO0FBQ0w7QUFDQSxNQUFNLGNBQWMsTUFBTSxZQUFZLFVBQVUsQ0FBQyxZQUFZLE9BQU8sSUFBSSxJQUFJLE9BQU8sSUFBSSxJQUFJO0FBQzNGLE1BQU0sMEJBQTBCLFFBQVEsS0FBSyxXQUFXLHNCQUFzQjtDQUFFLEdBQUc7Q0FBUSxHQUFHO0NBQUssR0FBRztBQUFPLENBQUM7QUFDOUcsTUFBTSx5QkFBeUIsU0FBUyxLQUFLLFVBQVUsSUFBSSxDQUFDLENBQ3ZELFFBQVEsV0FBVyxTQUFTLENBQUMsQ0FDN0IsUUFBUSxXQUFXLFNBQVMsQ0FBQyxDQUM3QixRQUFRLFdBQVcsU0FBUztBQUNqQyxNQUFNLFlBQVksUUFBUSxPQUFPLFFBQVEsWUFBWSxTQUFTLEdBQUc7QUFDakUsTUFBTSxVQUFVLFFBQVEsYUFBYSxHQUFHLE1BQU07QUFDOUMsTUFBTSxZQUFZLFFBQVEsYUFBYSxHQUFHLE1BQU07QUFDaEQsTUFBTSxpQkFBaUIsUUFBUSxjQUFjLEdBQUcsS0FBSyxPQUFPLEtBQUssR0FBRyxDQUFDLENBQUMsV0FBVztBQUNqRixNQUFNLFNBQVMsT0FBTztBQUN0QixNQUFNLFVBQVUsT0FBTztBQUN2QixNQUFNLFVBQVUsTUFBTSxTQUFTLFFBQVEsR0FBRztBQUMxQyxJQUFJO0FBQ0osTUFBTSxzQkFBc0I7O0NBRXhCLE9BQVEsZ0JBQ0gsY0FDRyxPQUFPLGVBQWUsY0FDaEIsYUFDQSxPQUFPLFNBQVMsY0FDWixPQUNBLE9BQU8sV0FBVyxjQUNkLFNBQ0EsT0FBTyxXQUFXLGNBQ2QsU0FDQSxPQUFPO0FBQ3JDO0FBQ0EsTUFBTSxpQkFBaUIsT0FBTyxVQUFVO0FBQ3hDLFNBQVMsT0FBTyxLQUFLLEtBQUs7Q0FDdEIsT0FBTyxlQUFlLEtBQUssS0FBSyxHQUFHO0FBQ3ZDOzs7Ozs7Ozs7QUFTQSxNQUFNLFVBQVUsTUFBTTtBQUN0QixNQUFNLGNBQWMsUUFBUSxPQUFPLFFBQVE7QUFDM0MsTUFBTSxZQUFZLFFBQVEsT0FBTyxRQUFRO0FBQ3pDLE1BQU0sYUFBYSxRQUFRLE9BQU8sUUFBUTtBQUMxQyxNQUFNLFlBQVksUUFBUSxPQUFPLFFBQVE7O0FBRXpDLE1BQU0sWUFBWSxRQUFRLFFBQVEsUUFBUSxPQUFPLFFBQVE7O0FBRXpELE1BQU0sYUFBYSxRQUFRO0NBQ3ZCLE9BQU8sU0FBUyxHQUFHLEtBQUssV0FBVyxJQUFJLElBQUksS0FBSyxXQUFXLElBQUksS0FBSztBQUN4RTtBQUNBLE1BQU0saUJBQWlCLE9BQU8sVUFBVTtBQUN4QyxNQUFNLGdCQUFnQixVQUFVLGVBQWUsS0FBSyxLQUFLO0FBQ3pELE1BQU0saUJBQWlCLFFBQVEsYUFBYSxHQUFHLE1BQU07O0FBRXJELE1BQU0sbUJBQW1CLFFBQVE7Q0FDN0IsT0FBTyxPQUFPLE9BQ1IsS0FDQSxRQUFRLEdBQUcsS0FBTSxjQUFjLEdBQUcsS0FBSyxJQUFJLGFBQWEsaUJBQ3BELEtBQUssVUFBVSxLQUFLLE1BQU0sQ0FBQyxJQUMzQixPQUFPLEdBQUc7QUFDeEI7QUFDQSxTQUFTLEtBQUssT0FBTyxZQUFZLElBQUk7Q0FDakMsT0FBTyxNQUFNLFFBQVEsS0FBSyxNQUFNLFVBQVcsVUFBVSxJQUFJLE1BQU0sT0FBTyxNQUFNLFlBQVksTUFBTyxFQUFFO0FBQ3JHO0FBQ0EsTUFBTSxRQUFRO0FBQ2QsU0FBUyxrQkFBa0IsUUFBUSxRQUFRLEdBQUcsTUFBTSxPQUFPLFFBQVE7Q0FDL0QsTUFBTSxRQUFRLE9BQU8sTUFBTSxPQUFPO0NBQ2xDLElBQUksUUFBUTtDQUNaLE1BQU0sTUFBTSxDQUFDO0NBQ2IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0VBQ25DLFNBQVMsTUFBTSxFQUFFLENBQUMsU0FBUztFQUMzQixJQUFJLFNBQVMsT0FBTztHQUNoQixLQUFLLElBQUksSUFBSSxJQUFJLE9BQU8sS0FBSyxJQUFJLFNBQVMsTUFBTSxPQUFPLEtBQUs7SUFDeEQsSUFBSSxJQUFJLEtBQUssS0FBSyxNQUFNLFFBQ3BCO0lBQ0osTUFBTSxPQUFPLElBQUk7SUFDakIsSUFBSSxLQUFLLEdBQUcsT0FBTyxJQUFJLE9BQU8sSUFBSSxPQUFPLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRSxLQUFLLE1BQU0sSUFBSTtJQUN0RSxNQUFNLGFBQWEsTUFBTSxFQUFFLENBQUM7SUFDNUIsSUFBSSxNQUFNLEdBQUc7O0tBRVQsTUFBTSxNQUFNLFNBQVMsUUFBUSxjQUFjO0tBQzNDLE1BQU0sU0FBUyxLQUFLLElBQUksR0FBRyxNQUFNLFFBQVEsYUFBYSxNQUFNLE1BQU0sS0FBSztLQUN2RSxJQUFJLEtBQUssV0FBVyxJQUFJLE9BQU8sR0FBRyxJQUFJLElBQUksT0FBTyxNQUFNLENBQUM7SUFDNUQsT0FDSyxJQUFJLElBQUksR0FBRztLQUNaLElBQUksTUFBTSxPQUFPO01BQ2IsTUFBTSxTQUFTLEtBQUssSUFBSSxLQUFLLElBQUksTUFBTSxPQUFPLFVBQVUsR0FBRyxDQUFDO01BQzVELElBQUksS0FBSyxXQUFXLElBQUksT0FBTyxNQUFNLENBQUM7S0FDMUM7S0FDQSxTQUFTLGFBQWE7SUFDMUI7R0FDSjtHQUNBO0VBQ0o7Q0FDSjtDQUNBLE9BQU8sSUFBSSxLQUFLLElBQUk7QUFDeEI7QUFFQSxTQUFTLEtBQUssS0FBSyxLQUFLO0NBQ3BCLElBQUksT0FBTyxZQUFZLGFBQWE7RUFDaEMsUUFBUSxLQUFLLGVBQWUsR0FBRzs7RUFFL0IsSUFBSSxLQUFLO0dBQ0wsUUFBUSxLQUFLLElBQUksS0FBSztFQUMxQjtDQUNKO0FBQ0o7QUFDQSxNQUFNLFlBQVksQ0FBQztBQUNuQixTQUFTLFNBQVMsS0FBSztDQUNuQixJQUFJLENBQUMsVUFBVSxNQUFNO0VBQ2pCLFVBQVUsT0FBTztFQUNqQixLQUFLLEdBQUc7Q0FDWjtBQUNKO0FBRUEsU0FBUyxXQUFXLFNBQVM7Q0FDekIsT0FBTyxRQUNGLFFBQVEsTUFBTSxPQUFPLENBQUMsQ0FDdEIsUUFBUSxNQUFNLE1BQU0sQ0FBQyxDQUNyQixRQUFRLE1BQU0sTUFBTSxDQUFDLENBQ3JCLFFBQVEsTUFBTSxRQUFRLENBQUMsQ0FDdkIsUUFBUSxNQUFNLFFBQVEsQ0FBQyxDQUN2QixRQUFRLE9BQU8sUUFBUSxDQUFDLENBQ3hCLFFBQVEsTUFBTSxRQUFRO0FBQy9CO0FBQ0EsU0FBUyxxQkFBcUIsT0FBTztDQUNqQyxPQUFPLE1BQ0YsUUFBUSwwQkFBMEIsT0FBTyxDQUFDLENBQzFDLFFBQVEsTUFBTSxRQUFRLENBQUMsQ0FDdkIsUUFBUSxNQUFNLFFBQVEsQ0FBQyxDQUN2QixRQUFRLE1BQU0sTUFBTSxDQUFDLENBQ3JCLFFBQVEsTUFBTSxNQUFNO0FBQzdCO0FBQ0EsTUFBTSwwQkFBMEI7QUFDaEMsTUFBTSxzQkFBc0I7QUFDNUIsTUFBTSxtQ0FBbUM7QUFDekMsTUFBTSwyQ0FBMkM7QUFDakQsTUFBTSxpQ0FBaUM7O0FBRXZDLE1BQU0sNkJBQTZCO0FBQ25DLE1BQU0sc0JBQXNCO0FBQzVCLE1BQU0sK0JBQStCO0FBQ3JDLE1BQU0sOEJBQThCO0FBQ3BDLFNBQVMsZ0NBQWdDLE9BQU8sS0FBSyxTQUFTO0NBQzFELE1BQU0sU0FBUyxPQUFPO0NBQ3RCLElBQUksQ0FBQyxRQUFRO0VBQ1QsT0FBTztDQUNYO0NBQ0EsTUFBTSxZQUFZLE9BQU8sU0FBUyxRQUFRLE1BQU0sS0FBSyxFQUFFO0NBQ3ZELE9BQU8sYUFBYSxNQUFPLE9BQU8sYUFBYSxTQUFTLElBQUk7QUFDaEU7QUFDQSxTQUFTLG9CQUFvQixPQUFPO0NBQ2hDLE1BQU0sYUFBYSxNQUNkLFFBQVEsa0NBQWtDLCtCQUErQixDQUFDLENBQzFFLFFBQVEsMENBQTBDLEVBQUUsQ0FBQyxDQUNyRCxRQUFRLGdDQUFnQyxHQUFHLENBQUMsQ0FDNUMsUUFBUSw0QkFBNEIsRUFBRTtDQUMzQyxPQUFPLHdCQUF3QixLQUFLLFVBQVU7QUFDbEQ7QUFDQSxTQUFTLG1CQUFtQixPQUFPO0NBQy9CLE1BQU0sYUFBYTtDQUNuQixJQUFJLFlBQVk7Q0FDaEIsSUFBSSxTQUFTO0NBQ2IsSUFBSTtDQUNKLFFBQVEsUUFBUSxXQUFXLEtBQUssS0FBSyxPQUFPLE1BQU07RUFDOUMsTUFBTSxXQUFXLE1BQU07RUFDdkIsTUFBTSxpQkFBaUIsV0FBVyxZQUFZO0VBQzlDLElBQUksUUFBUSxpQkFBaUI7RUFDN0IsSUFBSSxRQUFRO0VBQ1osSUFBSSxRQUFRO0VBQ1osT0FBTyxRQUFRLE1BQU0sUUFBUSxTQUFTO0dBQ2xDLE1BQU0sT0FBTyxNQUFNO0dBQ25CLElBQUksT0FBTztJQUNQLElBQUksU0FBUyxPQUFPO0tBQ2hCLFFBQVE7SUFDWjtJQUNBO0dBQ0o7R0FDQSxJQUFJLFNBQVMsUUFBTyxTQUFTLEtBQUs7SUFDOUIsUUFBUTtHQUNaLE9BQ0ssSUFBSSxTQUFTLEtBQUs7SUFDbkI7R0FDSixPQUNLLElBQUksU0FBUyxLQUFLO0lBQ25CO0lBQ0EsSUFBSSxVQUFVLEdBQUc7S0FDYjtJQUNKO0dBQ0o7RUFDSjtFQUNBLElBQUksVUFBVSxHQUFHO0dBQ2I7RUFDSjtFQUNBLE1BQU0sY0FBYyxNQUFNLE1BQU0saUJBQWlCLEdBQUcsS0FBSyxDQUFDLENBQUMsS0FBSztFQUNoRSxNQUFNLG1CQUFvQixZQUFZLFdBQVcsSUFBRyxLQUFLLFlBQVksU0FBUyxJQUFHLEtBQzVFLFlBQVksV0FBVyxHQUFHLEtBQUssWUFBWSxTQUFTLEdBQUcsSUFDdEQsWUFBWSxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQzlCO0VBQ04sYUFBYSxNQUFNLE1BQU0sUUFBUSxRQUFRO0VBQ3pDLGFBQWEsb0JBQW9CLGdCQUFnQixJQUMzQyxxQkFDQSxNQUFNLE1BQU0sVUFBVSxRQUFRLENBQUM7RUFDckMsU0FBUyxRQUFRO0NBQ3JCO0NBQ0EsT0FBTyxZQUFZLE1BQU0sTUFBTSxNQUFNO0FBQ3pDO0FBQ0EsU0FBUyx1QkFBdUIsVUFBVSxPQUFPO0NBQzdDLElBQUksb0JBQW9CLEtBQUssUUFBUSxLQUFLLG9CQUFvQixLQUFLLEdBQUc7RUFDbEUsT0FBTztDQUNYO0NBQ0EsTUFBTSxpQkFBaUIsU0FBUyxZQUFZLE1BQU0sVUFBVSxtQkFBbUIsS0FBSyxJQUFJO0NBQ3hGLE9BQU8scUJBQXFCLGNBQWM7QUFDOUM7QUFDQSxTQUFTLHVCQUF1QixNQUFNOzs7Q0FHbEMsT0FBTyxLQUFLLFFBQVEsK0JBQStCLEdBQUcsVUFBVSxjQUFjLEdBQUcsU0FBUyxJQUFJLHVCQUF1QixVQUFVLFNBQVMsRUFBRSxFQUFFOztDQUU1SSxPQUFPLEtBQUssUUFBUSwrQkFBK0IsR0FBRyxVQUFVLGNBQWMsR0FBRyxTQUFTLElBQUksdUJBQXVCLFVBQVUsU0FBUyxFQUFFLEVBQUU7O0NBRTVJLElBQUksb0JBQW9CLEtBQUssSUFBSSxHQUFHO0VBQ2hDLHNCQUE4QixjQUFlO0dBQ3pDLEtBQUssbUVBQ0QsMEVBQTBFO0VBQ2xGOztFQUVBLE9BQU8sS0FBSyxRQUFRLDhCQUE4QixhQUFhO0NBQ25FOztDQUVBLE9BQU8sS0FBSyxRQUFRLDhCQUE4QixPQUFPLFVBQVUsUUFBUSxjQUFjLG9CQUFvQixTQUFTLElBQUksR0FBRyxXQUFXLE9BQU8sZUFBZSxLQUFLO0NBQ25LLE9BQU87QUFDWDs7Ozs7Ozs7Ozs7OztBQWNBLFNBQVMsZ0JBQWdCO0NBQ3JCLE1BQU0sU0FBUyxJQUFJLElBQUk7Q0FDdkIsTUFBTSxVQUFVO0VBQ1o7RUFDQSxHQUFHLE9BQU8sU0FBUztHQUNmLE1BQU0sV0FBVyxPQUFPLElBQUksS0FBSztHQUNqQyxNQUFNLFFBQVEsWUFBWSxTQUFTLEtBQUssT0FBTztHQUMvQyxJQUFJLENBQUMsT0FBTztJQUNSLE9BQU8sSUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDO0dBQy9CO0VBQ0o7RUFDQSxJQUFJLE9BQU8sU0FBUztHQUNoQixNQUFNLFdBQVcsT0FBTyxJQUFJLEtBQUs7R0FDakMsSUFBSSxVQUFVO0lBQ1YsU0FBUyxPQUFPLFNBQVMsUUFBUSxPQUFPLE1BQU0sR0FBRyxDQUFDO0dBQ3REO0VBQ0o7RUFDQSxLQUFLLE9BQU8sU0FBUztHQUNqQixDQUFDLE9BQU8sSUFBSSxLQUFLLEtBQUssQ0FBQyxFQUFDLENBQ25CLE1BQU0sQ0FBQyxDQUNQLEtBQUksWUFBVyxRQUFRLE9BQU8sQ0FBQztHQUNwQyxDQUFDLE9BQU8sSUFBSSxHQUFHLEtBQUssQ0FBQyxFQUFDLENBQ2pCLE1BQU0sQ0FBQyxDQUNQLEtBQUksWUFBVyxRQUFRLE9BQU8sT0FBTyxDQUFDO0VBQy9DO0NBQ0o7Q0FDQSxPQUFPO0FBQ1g7QUFFQSxNQUFNLHdCQUF3QixRQUFRLENBQUMsU0FBUyxHQUFHLEtBQUssUUFBUSxHQUFHOztBQUVuRSxTQUFTLFNBQVMsS0FBSyxLQUFLOztDQUV4QixJQUFJLHFCQUFxQixHQUFHLEtBQUsscUJBQXFCLEdBQUcsR0FBRztFQUN4RCxNQUFNLElBQUksTUFBTSxlQUFlO0NBQ25DO0NBQ0EsTUFBTSxRQUFRLENBQUM7RUFBRTtFQUFLO0NBQUksQ0FBQztDQUMzQixPQUFPLE1BQU0sUUFBUTtFQUNqQixNQUFNLEVBQUUsS0FBSyxRQUFRLE1BQU0sSUFBSTs7RUFFL0IsT0FBTyxLQUFLLEdBQUcsQ0FBQyxDQUFDLFNBQVEsUUFBTztHQUM1QixJQUFJLFFBQVEsYUFBYTtJQUNyQjtHQUNKOzs7R0FHQSxJQUFJLFNBQVMsSUFBSSxJQUFJLEtBQUssQ0FBQyxTQUFTLElBQUksSUFBSSxHQUFHO0lBQzNDLElBQUksT0FBTyxNQUFNLFFBQVEsSUFBSSxJQUFJLElBQUksQ0FBQyxJQUFJLE9BQU87R0FDckQ7R0FDQSxJQUFJLHFCQUFxQixJQUFJLElBQUksS0FBSyxxQkFBcUIsSUFBSSxJQUFJLEdBQUc7Ozs7SUFJbEUsSUFBSSxPQUFPLElBQUk7R0FDbkIsT0FDSzs7SUFFRCxNQUFNLEtBQUs7S0FBRSxLQUFLLElBQUk7S0FBTSxLQUFLLElBQUk7SUFBSyxDQUFDO0dBQy9DO0VBQ0osQ0FBQztDQUNMO0FBQ0o7QUFFQSxTQUFTLFFBQVEsUUFBUSxlQUFlLFVBQVUsWUFBWSxRQUFRLHVCQUF1QixtQkFBbUIsd0JBQXdCLGVBQWUsUUFBUSxXQUFXLFNBQVMsV0FBVyxRQUFRLGVBQWUsWUFBWSxVQUFVLFVBQVUsZUFBZSxXQUFXLFVBQVUsVUFBVSxVQUFVLE1BQU0sWUFBWSxNQUFNLFNBQVMsZ0JBQWdCLHdCQUF3QixpQkFBaUIsY0FBYyxNQUFNIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInNoYXJlZC5tanM/dj03ZTczYWZjMiJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcbiAgKiBzaGFyZWQgdjExLjQuOFxuICAqIChjKSAyMDI2IGthenV5YSBrYXdhZ3VjaGlcbiAgKiBSZWxlYXNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuXG4gICovXG4vKipcbiAqIE9yaWdpbmFsIFV0aWxpdGllc1xuICogd3JpdHRlbiBieSBrYXp1eWEga2F3YWd1Y2hpXG4gKi9cbmNvbnN0IGluQnJvd3NlciA9IHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnO1xubGV0IG1hcms7XG5sZXQgbWVhc3VyZTtcbmlmICgocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykpIHtcbiAgICBjb25zdCBwZXJmID0gaW5Ccm93c2VyICYmIHdpbmRvdy5wZXJmb3JtYW5jZTtcbiAgICBpZiAocGVyZiAmJlxuICAgICAgICBwZXJmLm1hcmsgJiZcbiAgICAgICAgcGVyZi5tZWFzdXJlICYmXG4gICAgICAgIHBlcmYuY2xlYXJNYXJrcyAmJlxuICAgICAgICAvLyBAdHMtaWdub3JlIGJyb3dzZXIgY29tcGF0XG4gICAgICAgIHBlcmYuY2xlYXJNZWFzdXJlcykge1xuICAgICAgICBtYXJrID0gKHRhZykgPT4ge1xuICAgICAgICAgICAgcGVyZi5tYXJrKHRhZyk7XG4gICAgICAgIH07XG4gICAgICAgIG1lYXN1cmUgPSAobmFtZSwgc3RhcnRUYWcsIGVuZFRhZykgPT4ge1xuICAgICAgICAgICAgcGVyZi5tZWFzdXJlKG5hbWUsIHN0YXJ0VGFnLCBlbmRUYWcpO1xuICAgICAgICAgICAgcGVyZi5jbGVhck1hcmtzKHN0YXJ0VGFnKTtcbiAgICAgICAgICAgIHBlcmYuY2xlYXJNYXJrcyhlbmRUYWcpO1xuICAgICAgICB9O1xuICAgIH1cbn1cbmNvbnN0IFJFX0FSR1MgPSAvXFx7KFswLTlhLXpBLVpdKylcXH0vZztcbi8qIGVzbGludC1kaXNhYmxlICovXG5mdW5jdGlvbiBmb3JtYXQobWVzc2FnZSwgLi4uYXJncykge1xuICAgIGlmIChhcmdzLmxlbmd0aCA9PT0gMSAmJiBpc09iamVjdChhcmdzWzBdKSkge1xuICAgICAgICBhcmdzID0gYXJnc1swXTtcbiAgICB9XG4gICAgaWYgKCFhcmdzIHx8ICFhcmdzLmhhc093blByb3BlcnR5KSB7XG4gICAgICAgIGFyZ3MgPSB7fTtcbiAgICB9XG4gICAgcmV0dXJuIG1lc3NhZ2UucmVwbGFjZShSRV9BUkdTLCAobWF0Y2gsIGlkZW50aWZpZXIpID0+IHtcbiAgICAgICAgcmV0dXJuIGFyZ3MuaGFzT3duUHJvcGVydHkoaWRlbnRpZmllcikgPyBhcmdzW2lkZW50aWZpZXJdIDogJyc7XG4gICAgfSk7XG59XG5jb25zdCBtYWtlU3ltYm9sID0gKG5hbWUsIHNoYXJlYWJsZSA9IGZhbHNlKSA9PiAhc2hhcmVhYmxlID8gU3ltYm9sKG5hbWUpIDogU3ltYm9sLmZvcihuYW1lKTtcbmNvbnN0IGdlbmVyYXRlRm9ybWF0Q2FjaGVLZXkgPSAobG9jYWxlLCBrZXksIHNvdXJjZSkgPT4gZnJpZW5kbHlKU09Oc3RyaW5naWZ5KHsgbDogbG9jYWxlLCBrOiBrZXksIHM6IHNvdXJjZSB9KTtcbmNvbnN0IGZyaWVuZGx5SlNPTnN0cmluZ2lmeSA9IChqc29uKSA9PiBKU09OLnN0cmluZ2lmeShqc29uKVxuICAgIC5yZXBsYWNlKC9cXHUyMDI4L2csICdcXFxcdTIwMjgnKVxuICAgIC5yZXBsYWNlKC9cXHUyMDI5L2csICdcXFxcdTIwMjknKVxuICAgIC5yZXBsYWNlKC9cXHUwMDI3L2csICdcXFxcdTAwMjcnKTtcbmNvbnN0IGlzTnVtYmVyID0gKHZhbCkgPT4gdHlwZW9mIHZhbCA9PT0gJ251bWJlcicgJiYgaXNGaW5pdGUodmFsKTtcbmNvbnN0IGlzRGF0ZSA9ICh2YWwpID0+IHRvVHlwZVN0cmluZyh2YWwpID09PSAnW29iamVjdCBEYXRlXSc7XG5jb25zdCBpc1JlZ0V4cCA9ICh2YWwpID0+IHRvVHlwZVN0cmluZyh2YWwpID09PSAnW29iamVjdCBSZWdFeHBdJztcbmNvbnN0IGlzRW1wdHlPYmplY3QgPSAodmFsKSA9PiBpc1BsYWluT2JqZWN0KHZhbCkgJiYgT2JqZWN0LmtleXModmFsKS5sZW5ndGggPT09IDA7XG5jb25zdCBhc3NpZ24gPSBPYmplY3QuYXNzaWduO1xuY29uc3QgX2NyZWF0ZSA9IE9iamVjdC5jcmVhdGU7XG5jb25zdCBjcmVhdGUgPSAob2JqID0gbnVsbCkgPT4gX2NyZWF0ZShvYmopO1xubGV0IF9nbG9iYWxUaGlzO1xuY29uc3QgZ2V0R2xvYmFsVGhpcyA9ICgpID0+IHtcbiAgICAvLyBwcmV0dGllci1pZ25vcmVcbiAgICByZXR1cm4gKF9nbG9iYWxUaGlzIHx8XG4gICAgICAgIChfZ2xvYmFsVGhpcyA9XG4gICAgICAgICAgICB0eXBlb2YgZ2xvYmFsVGhpcyAhPT0gJ3VuZGVmaW5lZCdcbiAgICAgICAgICAgICAgICA/IGdsb2JhbFRoaXNcbiAgICAgICAgICAgICAgICA6IHR5cGVvZiBzZWxmICE9PSAndW5kZWZpbmVkJ1xuICAgICAgICAgICAgICAgICAgICA/IHNlbGZcbiAgICAgICAgICAgICAgICAgICAgOiB0eXBlb2Ygd2luZG93ICE9PSAndW5kZWZpbmVkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgPyB3aW5kb3dcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdHlwZW9mIGdsb2JhbCAhPT0gJ3VuZGVmaW5lZCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGdsb2JhbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogY3JlYXRlKCkpKTtcbn07XG5jb25zdCBoYXNPd25Qcm9wZXJ0eSA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG5mdW5jdGlvbiBoYXNPd24ob2JqLCBrZXkpIHtcbiAgICByZXR1cm4gaGFzT3duUHJvcGVydHkuY2FsbChvYmosIGtleSk7XG59XG4vKiBlc2xpbnQtZW5hYmxlICovXG4vKipcbiAqIFVzZWZ1bCBVdGlsaXRpZXMgQnkgRXZhbiB5b3VcbiAqIE1vZGlmaWVkIGJ5IGthenV5YSBrYXdhZ3VjaGlcbiAqIE1JVCBMaWNlbnNlXG4gKiBodHRwczovL2dpdGh1Yi5jb20vdnVlanMvdnVlLW5leHQvYmxvYi9tYXN0ZXIvcGFja2FnZXMvc2hhcmVkL3NyYy9pbmRleC50c1xuICogaHR0cHM6Ly9naXRodWIuY29tL3Z1ZWpzL3Z1ZS1uZXh0L2Jsb2IvbWFzdGVyL3BhY2thZ2VzL3NoYXJlZC9zcmMvY29kZWZyYW1lLnRzXG4gKi9cbmNvbnN0IGlzQXJyYXkgPSBBcnJheS5pc0FycmF5O1xuY29uc3QgaXNGdW5jdGlvbiA9ICh2YWwpID0+IHR5cGVvZiB2YWwgPT09ICdmdW5jdGlvbic7XG5jb25zdCBpc1N0cmluZyA9ICh2YWwpID0+IHR5cGVvZiB2YWwgPT09ICdzdHJpbmcnO1xuY29uc3QgaXNCb29sZWFuID0gKHZhbCkgPT4gdHlwZW9mIHZhbCA9PT0gJ2Jvb2xlYW4nO1xuY29uc3QgaXNTeW1ib2wgPSAodmFsKSA9PiB0eXBlb2YgdmFsID09PSAnc3ltYm9sJztcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG5jb25zdCBpc09iamVjdCA9ICh2YWwpID0+IHZhbCAhPT0gbnVsbCAmJiB0eXBlb2YgdmFsID09PSAnb2JqZWN0Jztcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG5jb25zdCBpc1Byb21pc2UgPSAodmFsKSA9PiB7XG4gICAgcmV0dXJuIGlzT2JqZWN0KHZhbCkgJiYgaXNGdW5jdGlvbih2YWwudGhlbikgJiYgaXNGdW5jdGlvbih2YWwuY2F0Y2gpO1xufTtcbmNvbnN0IG9iamVjdFRvU3RyaW5nID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZztcbmNvbnN0IHRvVHlwZVN0cmluZyA9ICh2YWx1ZSkgPT4gb2JqZWN0VG9TdHJpbmcuY2FsbCh2YWx1ZSk7XG5jb25zdCBpc1BsYWluT2JqZWN0ID0gKHZhbCkgPT4gdG9UeXBlU3RyaW5nKHZhbCkgPT09ICdbb2JqZWN0IE9iamVjdF0nO1xuLy8gZm9yIGNvbnZlcnRpbmcgbGlzdCBhbmQgbmFtZWQgdmFsdWVzIHRvIGRpc3BsYXllZCBzdHJpbmdzLlxuY29uc3QgdG9EaXNwbGF5U3RyaW5nID0gKHZhbCkgPT4ge1xuICAgIHJldHVybiB2YWwgPT0gbnVsbFxuICAgICAgICA/ICcnXG4gICAgICAgIDogaXNBcnJheSh2YWwpIHx8IChpc1BsYWluT2JqZWN0KHZhbCkgJiYgdmFsLnRvU3RyaW5nID09PSBvYmplY3RUb1N0cmluZylcbiAgICAgICAgICAgID8gSlNPTi5zdHJpbmdpZnkodmFsLCBudWxsLCAyKVxuICAgICAgICAgICAgOiBTdHJpbmcodmFsKTtcbn07XG5mdW5jdGlvbiBqb2luKGl0ZW1zLCBzZXBhcmF0b3IgPSAnJykge1xuICAgIHJldHVybiBpdGVtcy5yZWR1Y2UoKHN0ciwgaXRlbSwgaW5kZXgpID0+IChpbmRleCA9PT0gMCA/IHN0ciArIGl0ZW0gOiBzdHIgKyBzZXBhcmF0b3IgKyBpdGVtKSwgJycpO1xufVxuY29uc3QgUkFOR0UgPSAyO1xuZnVuY3Rpb24gZ2VuZXJhdGVDb2RlRnJhbWUoc291cmNlLCBzdGFydCA9IDAsIGVuZCA9IHNvdXJjZS5sZW5ndGgpIHtcbiAgICBjb25zdCBsaW5lcyA9IHNvdXJjZS5zcGxpdCgvXFxyP1xcbi8pO1xuICAgIGxldCBjb3VudCA9IDA7XG4gICAgY29uc3QgcmVzID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsaW5lcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb3VudCArPSBsaW5lc1tpXS5sZW5ndGggKyAxO1xuICAgICAgICBpZiAoY291bnQgPj0gc3RhcnQpIHtcbiAgICAgICAgICAgIGZvciAobGV0IGogPSBpIC0gUkFOR0U7IGogPD0gaSArIFJBTkdFIHx8IGVuZCA+IGNvdW50OyBqKyspIHtcbiAgICAgICAgICAgICAgICBpZiAoaiA8IDAgfHwgaiA+PSBsaW5lcy5sZW5ndGgpXG4gICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICAgIGNvbnN0IGxpbmUgPSBqICsgMTtcbiAgICAgICAgICAgICAgICByZXMucHVzaChgJHtsaW5lfSR7JyAnLnJlcGVhdCgzIC0gU3RyaW5nKGxpbmUpLmxlbmd0aCl9fCAgJHtsaW5lc1tqXX1gKTtcbiAgICAgICAgICAgICAgICBjb25zdCBsaW5lTGVuZ3RoID0gbGluZXNbal0ubGVuZ3RoO1xuICAgICAgICAgICAgICAgIGlmIChqID09PSBpKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIHB1c2ggdW5kZXJsaW5lXG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHBhZCA9IHN0YXJ0IC0gKGNvdW50IC0gbGluZUxlbmd0aCkgKyAxO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBsZW5ndGggPSBNYXRoLm1heCgxLCBlbmQgPiBjb3VudCA/IGxpbmVMZW5ndGggLSBwYWQgOiBlbmQgLSBzdGFydCk7XG4gICAgICAgICAgICAgICAgICAgIHJlcy5wdXNoKGAgICB8ICBgICsgJyAnLnJlcGVhdChwYWQpICsgJ14nLnJlcGVhdChsZW5ndGgpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoaiA+IGkpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVuZCA+IGNvdW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBsZW5ndGggPSBNYXRoLm1heChNYXRoLm1pbihlbmQgLSBjb3VudCwgbGluZUxlbmd0aCksIDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVzLnB1c2goYCAgIHwgIGAgKyAnXicucmVwZWF0KGxlbmd0aCkpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNvdW50ICs9IGxpbmVMZW5ndGggKyAxO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiByZXMuam9pbignXFxuJyk7XG59XG5cbmZ1bmN0aW9uIHdhcm4obXNnLCBlcnIpIHtcbiAgICBpZiAodHlwZW9mIGNvbnNvbGUgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihgW2ludGxpZnldIGAgKyBtc2cpO1xuICAgICAgICAvKiBpc3RhbmJ1bCBpZ25vcmUgaWYgKi9cbiAgICAgICAgaWYgKGVycikge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKGVyci5zdGFjayk7XG4gICAgICAgIH1cbiAgICB9XG59XG5jb25zdCBoYXNXYXJuZWQgPSB7fTtcbmZ1bmN0aW9uIHdhcm5PbmNlKG1zZykge1xuICAgIGlmICghaGFzV2FybmVkW21zZ10pIHtcbiAgICAgICAgaGFzV2FybmVkW21zZ10gPSB0cnVlO1xuICAgICAgICB3YXJuKG1zZyk7XG4gICAgfVxufVxuXG5mdW5jdGlvbiBlc2NhcGVIdG1sKHJhd1RleHQpIHtcbiAgICByZXR1cm4gcmF3VGV4dFxuICAgICAgICAucmVwbGFjZSgvJi9nLCAnJmFtcDsnKSAvLyBlc2NhcGUgYCZgIGZpcnN0IHRvIGF2b2lkIGRvdWJsZSBlc2NhcGluZ1xuICAgICAgICAucmVwbGFjZSgvPC9nLCAnJmx0OycpXG4gICAgICAgIC5yZXBsYWNlKC8+L2csICcmZ3Q7JylcbiAgICAgICAgLnJlcGxhY2UoL1wiL2csICcmcXVvdDsnKVxuICAgICAgICAucmVwbGFjZSgvJy9nLCAnJmFwb3M7JylcbiAgICAgICAgLnJlcGxhY2UoL1xcLy9nLCAnJiN4MkY7JykgLy8gZXNjYXBlIGAvYCB0byBwcmV2ZW50IGNsb3NpbmcgdGFncyBvciBKYXZhU2NyaXB0IFVSTHNcbiAgICAgICAgLnJlcGxhY2UoLz0vZywgJyYjeDNEOycpOyAvLyBlc2NhcGUgYD1gIHRvIHByZXZlbnQgYXR0cmlidXRlIGluamVjdGlvblxufVxuZnVuY3Rpb24gZXNjYXBlQXR0cmlidXRlVmFsdWUodmFsdWUpIHtcbiAgICByZXR1cm4gdmFsdWVcbiAgICAgICAgLnJlcGxhY2UoLyYoPyFbYS16MC05I117Miw2fTspL2dpLCAnJmFtcDsnKSAvLyBlc2NhcGUgdW5lc2NhcGVkIGAmYFxuICAgICAgICAucmVwbGFjZSgvXCIvZywgJyZxdW90OycpXG4gICAgICAgIC5yZXBsYWNlKC8nL2csICcmYXBvczsnKVxuICAgICAgICAucmVwbGFjZSgvPC9nLCAnJmx0OycpXG4gICAgICAgIC5yZXBsYWNlKC8+L2csICcmZ3Q7Jyk7XG59XG5jb25zdCBqYXZhc2NyaXB0U2NoZW1lUGF0dGVybiA9IC9eamF2YXNjcmlwdDovaTtcbmNvbnN0IHVybEF0dHJpYnV0ZVBhdHRlcm4gPSAvXig/OmhyZWZ8c3JjfGFjdGlvbnxmb3JtYWN0aW9uKSQvaTtcbmNvbnN0IG51bWVyaWNDaGFyYWN0ZXJSZWZlcmVuY2VQYXR0ZXJuID0gLyYjKD86eChbMC05YS1mXSspfChcXGQrKSk7Py9naTtcbmNvbnN0IG5hbWVkV2hpdGVzcGFjZUNoYXJhY3RlclJlZmVyZW5jZVBhdHRlcm4gPSAvJig/OlRhYnxOZXdMaW5lKTsvZztcbmNvbnN0IGNvbG9uQ2hhcmFjdGVyUmVmZXJlbmNlUGF0dGVybiA9IC8mY29sb247Py9naTtcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1jb250cm9sLXJlZ2V4IC0tIFVSTCBzY2hlbWUgbm9ybWFsaXphdGlvbiByZXF1aXJlcyB0aGUgZnVsbCBjb250cm9sIHJhbmdlXG5jb25zdCBjb250cm9sT3JXaGl0ZXNwYWNlUGF0dGVybiA9IC9bXFx1MDAwMC1cXHUwMDIwXFx1MDA3Zi1cXHUwMDlmXS9nO1xuY29uc3QgZXZlbnRIYW5kbGVyUGF0dGVybiA9IC8oPzpefFtcXHNcIic8Pi9dKW9uXFx3K1xccyo9XFxzKltcIiddP1teXCInPl0rW1wiJ10/L2k7XG5jb25zdCBldmVudEhhbmRsZXJBdHRyaWJ1dGVQYXR0ZXJuID0gLyhefFtcXHNcIic8Pi9dKW9uKFxcdytcXHMqPSkvZ2k7XG5jb25zdCB1bnF1b3RlZFVybEF0dHJpYnV0ZVBhdHRlcm4gPSAvKF58W1xcc1wiJzw+L10pKCg/OmhyZWZ8c3JjfGFjdGlvbnxmb3JtYWN0aW9uKVxccyo9XFxzKikoW15cXHNcIic9PD5gXSspL2dpO1xuZnVuY3Rpb24gZGVjb2RlTnVtZXJpY0NoYXJhY3RlclJlZmVyZW5jZShtYXRjaCwgaGV4LCBkZWNpbWFsKSB7XG4gICAgY29uc3QgZGlnaXRzID0gaGV4IHx8IGRlY2ltYWw7XG4gICAgaWYgKCFkaWdpdHMpIHtcbiAgICAgICAgcmV0dXJuIG1hdGNoO1xuICAgIH1cbiAgICBjb25zdCBjb2RlUG9pbnQgPSBOdW1iZXIucGFyc2VJbnQoZGlnaXRzLCBoZXggPyAxNiA6IDEwKTtcbiAgICByZXR1cm4gY29kZVBvaW50IDw9IDB4N2YgPyBTdHJpbmcuZnJvbUNoYXJDb2RlKGNvZGVQb2ludCkgOiBtYXRjaDtcbn1cbmZ1bmN0aW9uIGhhc0phdmFzY3JpcHRTY2hlbWUodmFsdWUpIHtcbiAgICBjb25zdCBub3JtYWxpemVkID0gdmFsdWVcbiAgICAgICAgLnJlcGxhY2UobnVtZXJpY0NoYXJhY3RlclJlZmVyZW5jZVBhdHRlcm4sIGRlY29kZU51bWVyaWNDaGFyYWN0ZXJSZWZlcmVuY2UpXG4gICAgICAgIC5yZXBsYWNlKG5hbWVkV2hpdGVzcGFjZUNoYXJhY3RlclJlZmVyZW5jZVBhdHRlcm4sICcnKVxuICAgICAgICAucmVwbGFjZShjb2xvbkNoYXJhY3RlclJlZmVyZW5jZVBhdHRlcm4sICc6JylcbiAgICAgICAgLnJlcGxhY2UoY29udHJvbE9yV2hpdGVzcGFjZVBhdHRlcm4sICcnKTtcbiAgICByZXR1cm4gamF2YXNjcmlwdFNjaGVtZVBhdHRlcm4udGVzdChub3JtYWxpemVkKTtcbn1cbmZ1bmN0aW9uIHNhbml0aXplU3R5bGVWYWx1ZSh2YWx1ZSkge1xuICAgIGNvbnN0IHVybFBhdHRlcm4gPSAvdXJsXFxzKlxcKC9naTtcbiAgICBsZXQgc2FuaXRpemVkID0gJyc7XG4gICAgbGV0IGN1cnNvciA9IDA7XG4gICAgbGV0IG1hdGNoO1xuICAgIHdoaWxlICgobWF0Y2ggPSB1cmxQYXR0ZXJuLmV4ZWModmFsdWUpKSAhPT0gbnVsbCkge1xuICAgICAgICBjb25zdCB1cmxTdGFydCA9IG1hdGNoLmluZGV4O1xuICAgICAgICBjb25zdCBvcGVuUGFyZW5JbmRleCA9IHVybFBhdHRlcm4ubGFzdEluZGV4IC0gMTtcbiAgICAgICAgbGV0IGluZGV4ID0gb3BlblBhcmVuSW5kZXggKyAxO1xuICAgICAgICBsZXQgZGVwdGggPSAxO1xuICAgICAgICBsZXQgcXVvdGUgPSBudWxsO1xuICAgICAgICBmb3IgKDsgaW5kZXggPCB2YWx1ZS5sZW5ndGg7IGluZGV4KyspIHtcbiAgICAgICAgICAgIGNvbnN0IGNoYXIgPSB2YWx1ZVtpbmRleF07XG4gICAgICAgICAgICBpZiAocXVvdGUpIHtcbiAgICAgICAgICAgICAgICBpZiAoY2hhciA9PT0gcXVvdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgcXVvdGUgPSBudWxsO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjaGFyID09PSAnXCInIHx8IGNoYXIgPT09IFwiJ1wiKSB7XG4gICAgICAgICAgICAgICAgcXVvdGUgPSBjaGFyO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoY2hhciA9PT0gJygnKSB7XG4gICAgICAgICAgICAgICAgZGVwdGgrKztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGNoYXIgPT09ICcpJykge1xuICAgICAgICAgICAgICAgIGRlcHRoLS07XG4gICAgICAgICAgICAgICAgaWYgKGRlcHRoID09PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoZGVwdGggIT09IDApIHtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHJhd1VybFZhbHVlID0gdmFsdWUuc2xpY2Uob3BlblBhcmVuSW5kZXggKyAxLCBpbmRleCkudHJpbSgpO1xuICAgICAgICBjb25zdCB1bnF1b3RlZFVybFZhbHVlID0gKHJhd1VybFZhbHVlLnN0YXJ0c1dpdGgoJ1wiJykgJiYgcmF3VXJsVmFsdWUuZW5kc1dpdGgoJ1wiJykpIHx8XG4gICAgICAgICAgICAocmF3VXJsVmFsdWUuc3RhcnRzV2l0aChcIidcIikgJiYgcmF3VXJsVmFsdWUuZW5kc1dpdGgoXCInXCIpKVxuICAgICAgICAgICAgPyByYXdVcmxWYWx1ZS5zbGljZSgxLCAtMSkudHJpbSgpXG4gICAgICAgICAgICA6IHJhd1VybFZhbHVlO1xuICAgICAgICBzYW5pdGl6ZWQgKz0gdmFsdWUuc2xpY2UoY3Vyc29yLCB1cmxTdGFydCk7XG4gICAgICAgIHNhbml0aXplZCArPSBoYXNKYXZhc2NyaXB0U2NoZW1lKHVucXVvdGVkVXJsVmFsdWUpXG4gICAgICAgICAgICA/ICd1cmwoYWJvdXQ6YmxhbmspJ1xuICAgICAgICAgICAgOiB2YWx1ZS5zbGljZSh1cmxTdGFydCwgaW5kZXggKyAxKTtcbiAgICAgICAgY3Vyc29yID0gaW5kZXggKyAxO1xuICAgIH1cbiAgICByZXR1cm4gc2FuaXRpemVkICsgdmFsdWUuc2xpY2UoY3Vyc29yKTtcbn1cbmZ1bmN0aW9uIHNhbml0aXplQXR0cmlidXRlVmFsdWUoYXR0ck5hbWUsIHZhbHVlKSB7XG4gICAgaWYgKHVybEF0dHJpYnV0ZVBhdHRlcm4udGVzdChhdHRyTmFtZSkgJiYgaGFzSmF2YXNjcmlwdFNjaGVtZSh2YWx1ZSkpIHtcbiAgICAgICAgcmV0dXJuICdhYm91dDpibGFuayc7XG4gICAgfVxuICAgIGNvbnN0IHNhbml0aXplZFZhbHVlID0gYXR0ck5hbWUudG9Mb3dlckNhc2UoKSA9PT0gJ3N0eWxlJyA/IHNhbml0aXplU3R5bGVWYWx1ZSh2YWx1ZSkgOiB2YWx1ZTtcbiAgICByZXR1cm4gZXNjYXBlQXR0cmlidXRlVmFsdWUoc2FuaXRpemVkVmFsdWUpO1xufVxuZnVuY3Rpb24gc2FuaXRpemVUcmFuc2xhdGVkSHRtbChodG1sKSB7XG4gICAgLy8gRXNjYXBlIGRhbmdlcm91cyBjaGFyYWN0ZXJzIGluIGF0dHJpYnV0ZSB2YWx1ZXNcbiAgICAvLyBQcm9jZXNzIGF0dHJpYnV0ZXMgd2l0aCBkb3VibGUgcXVvdGVzXG4gICAgaHRtbCA9IGh0bWwucmVwbGFjZSgvKFtcXHc6LV0rKVxccyo9XFxzKlwiKFteXCJdKilcIi9nLCAoXywgYXR0ck5hbWUsIGF0dHJWYWx1ZSkgPT4gYCR7YXR0ck5hbWV9PVwiJHtzYW5pdGl6ZUF0dHJpYnV0ZVZhbHVlKGF0dHJOYW1lLCBhdHRyVmFsdWUpfVwiYCk7XG4gICAgLy8gUHJvY2VzcyBhdHRyaWJ1dGVzIHdpdGggc2luZ2xlIHF1b3Rlc1xuICAgIGh0bWwgPSBodG1sLnJlcGxhY2UoLyhbXFx3Oi1dKylcXHMqPVxccyonKFteJ10qKScvZywgKF8sIGF0dHJOYW1lLCBhdHRyVmFsdWUpID0+IGAke2F0dHJOYW1lfT0nJHtzYW5pdGl6ZUF0dHJpYnV0ZVZhbHVlKGF0dHJOYW1lLCBhdHRyVmFsdWUpfSdgKTtcbiAgICAvLyBEZXRlY3QgYW5kIG5ldXRyYWxpemUgZXZlbnQgaGFuZGxlciBhdHRyaWJ1dGVzXG4gICAgaWYgKGV2ZW50SGFuZGxlclBhdHRlcm4udGVzdChodG1sKSkge1xuICAgICAgICBpZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpKSB7XG4gICAgICAgICAgICB3YXJuKCdQb3RlbnRpYWxseSBkYW5nZXJvdXMgZXZlbnQgaGFuZGxlcnMgZGV0ZWN0ZWQgaW4gdHJhbnNsYXRpb24uICcgK1xuICAgICAgICAgICAgICAgICdDb25zaWRlciByZW1vdmluZyBvbmNsaWNrLCBvbmVycm9yLCBldGMuIGZyb20geW91ciB0cmFuc2xhdGlvbiBtZXNzYWdlcy4nKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBOZXV0cmFsaXplIGV2ZW50IGhhbmRsZXIgYXR0cmlidXRlcyBieSBlc2NhcGluZyAnb24nXG4gICAgICAgIGh0bWwgPSBodG1sLnJlcGxhY2UoZXZlbnRIYW5kbGVyQXR0cmlidXRlUGF0dGVybiwgJyQxJiMxMTE7biQyJyk7XG4gICAgfVxuICAgIC8vIERpc2FibGUgamF2YXNjcmlwdDogVVJMcyBpbiB1bnF1b3RlZCBhdHRyaWJ1dGVzXG4gICAgaHRtbCA9IGh0bWwucmVwbGFjZSh1bnF1b3RlZFVybEF0dHJpYnV0ZVBhdHRlcm4sIChtYXRjaCwgYm91bmRhcnksIHByZWZpeCwgYXR0clZhbHVlKSA9PiBoYXNKYXZhc2NyaXB0U2NoZW1lKGF0dHJWYWx1ZSkgPyBgJHtib3VuZGFyeX0ke3ByZWZpeH1hYm91dDpibGFua2AgOiBtYXRjaCk7XG4gICAgcmV0dXJuIGh0bWw7XG59XG5cbi8qKlxuICogRXZlbnQgZW1pdHRlciwgZm9ya2VkIGZyb20gdGhlIGJlbG93OlxuICogLSBvcmlnaW5hbCByZXBvc2l0b3J5IHVybDogaHR0cHM6Ly9naXRodWIuY29tL2RldmVsb3BpdC9taXR0XG4gKiAtIGNvZGUgdXJsOiBodHRwczovL2dpdGh1Yi5jb20vZGV2ZWxvcGl0L21pdHQvYmxvYi9tYXN0ZXIvc3JjL2luZGV4LnRzXG4gKiAtIGF1dGhvcjogSmFzb24gTWlsbGVyIChodHRwczovL2dpdGh1Yi5jb20vZGV2ZWxvcGl0KVxuICogLSBsaWNlbnNlOiBNSVRcbiAqL1xuLyoqXG4gKiBDcmVhdGUgYSBldmVudCBlbWl0dGVyXG4gKlxuICogQHJldHVybnMgQW4gZXZlbnQgZW1pdHRlclxuICovXG5mdW5jdGlvbiBjcmVhdGVFbWl0dGVyKCkge1xuICAgIGNvbnN0IGV2ZW50cyA9IG5ldyBNYXAoKTtcbiAgICBjb25zdCBlbWl0dGVyID0ge1xuICAgICAgICBldmVudHMsXG4gICAgICAgIG9uKGV2ZW50LCBoYW5kbGVyKSB7XG4gICAgICAgICAgICBjb25zdCBoYW5kbGVycyA9IGV2ZW50cy5nZXQoZXZlbnQpO1xuICAgICAgICAgICAgY29uc3QgYWRkZWQgPSBoYW5kbGVycyAmJiBoYW5kbGVycy5wdXNoKGhhbmRsZXIpO1xuICAgICAgICAgICAgaWYgKCFhZGRlZCkge1xuICAgICAgICAgICAgICAgIGV2ZW50cy5zZXQoZXZlbnQsIFtoYW5kbGVyXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIG9mZihldmVudCwgaGFuZGxlcikge1xuICAgICAgICAgICAgY29uc3QgaGFuZGxlcnMgPSBldmVudHMuZ2V0KGV2ZW50KTtcbiAgICAgICAgICAgIGlmIChoYW5kbGVycykge1xuICAgICAgICAgICAgICAgIGhhbmRsZXJzLnNwbGljZShoYW5kbGVycy5pbmRleE9mKGhhbmRsZXIpID4+PiAwLCAxKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgZW1pdChldmVudCwgcGF5bG9hZCkge1xuICAgICAgICAgICAgKGV2ZW50cy5nZXQoZXZlbnQpIHx8IFtdKVxuICAgICAgICAgICAgICAgIC5zbGljZSgpXG4gICAgICAgICAgICAgICAgLm1hcChoYW5kbGVyID0+IGhhbmRsZXIocGF5bG9hZCkpO1xuICAgICAgICAgICAgKGV2ZW50cy5nZXQoJyonKSB8fCBbXSlcbiAgICAgICAgICAgICAgICAuc2xpY2UoKVxuICAgICAgICAgICAgICAgIC5tYXAoaGFuZGxlciA9PiBoYW5kbGVyKGV2ZW50LCBwYXlsb2FkKSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIHJldHVybiBlbWl0dGVyO1xufVxuXG5jb25zdCBpc05vdE9iamVjdE9ySXNBcnJheSA9ICh2YWwpID0+ICFpc09iamVjdCh2YWwpIHx8IGlzQXJyYXkodmFsKTtcbi8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG5mdW5jdGlvbiBkZWVwQ29weShzcmMsIGRlcykge1xuICAgIC8vIHNyYyBhbmQgZGVzIHNob3VsZCBib3RoIGJlIG9iamVjdHMsIGFuZCBub25lIG9mIHRoZW0gY2FuIGJlIGEgYXJyYXlcbiAgICBpZiAoaXNOb3RPYmplY3RPcklzQXJyYXkoc3JjKSB8fCBpc05vdE9iamVjdE9ySXNBcnJheShkZXMpKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCB2YWx1ZScpO1xuICAgIH1cbiAgICBjb25zdCBzdGFjayA9IFt7IHNyYywgZGVzIH1dO1xuICAgIHdoaWxlIChzdGFjay5sZW5ndGgpIHtcbiAgICAgICAgY29uc3QgeyBzcmMsIGRlcyB9ID0gc3RhY2sucG9wKCk7XG4gICAgICAgIC8vIHVzaW5nIGBPYmplY3Qua2V5c2Agd2hpY2ggc2tpcHMgcHJvdG90eXBlIHByb3BlcnRpZXNcbiAgICAgICAgT2JqZWN0LmtleXMoc3JjKS5mb3JFYWNoKGtleSA9PiB7XG4gICAgICAgICAgICBpZiAoa2V5ID09PSAnX19wcm90b19fJykge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIGlmIHNyY1trZXldIGlzIGFuIG9iamVjdC9hcnJheSwgc2V0IGRlc1trZXldXG4gICAgICAgICAgICAvLyB0byBlbXB0eSBvYmplY3QvYXJyYXkgdG8gcHJldmVudCBzZXR0aW5nIGJ5IHJlZmVyZW5jZVxuICAgICAgICAgICAgaWYgKGlzT2JqZWN0KHNyY1trZXldKSAmJiAhaXNPYmplY3QoZGVzW2tleV0pKSB7XG4gICAgICAgICAgICAgICAgZGVzW2tleV0gPSBBcnJheS5pc0FycmF5KHNyY1trZXldKSA/IFtdIDogY3JlYXRlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaXNOb3RPYmplY3RPcklzQXJyYXkoZGVzW2tleV0pIHx8IGlzTm90T2JqZWN0T3JJc0FycmF5KHNyY1trZXldKSkge1xuICAgICAgICAgICAgICAgIC8vIHJlcGxhY2Ugd2l0aCBzcmNba2V5XSB3aGVuOlxuICAgICAgICAgICAgICAgIC8vIHNyY1trZXldIG9yIGRlc1trZXldIGlzIG5vdCBhbiBvYmplY3QsIG9yXG4gICAgICAgICAgICAgICAgLy8gc3JjW2tleV0gb3IgZGVzW2tleV0gaXMgYW4gYXJyYXlcbiAgICAgICAgICAgICAgICBkZXNba2V5XSA9IHNyY1trZXldO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gc3JjW2tleV0gYW5kIGRlc1trZXldIGFyZSBib3RoIG9iamVjdHMsIG1lcmdlIHRoZW1cbiAgICAgICAgICAgICAgICBzdGFjay5wdXNoKHsgc3JjOiBzcmNba2V5XSwgZGVzOiBkZXNba2V5XSB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxufVxuXG5leHBvcnQgeyBhc3NpZ24sIGNyZWF0ZSwgY3JlYXRlRW1pdHRlciwgZGVlcENvcHksIGVzY2FwZUh0bWwsIGZvcm1hdCwgZnJpZW5kbHlKU09Oc3RyaW5naWZ5LCBnZW5lcmF0ZUNvZGVGcmFtZSwgZ2VuZXJhdGVGb3JtYXRDYWNoZUtleSwgZ2V0R2xvYmFsVGhpcywgaGFzT3duLCBpbkJyb3dzZXIsIGlzQXJyYXksIGlzQm9vbGVhbiwgaXNEYXRlLCBpc0VtcHR5T2JqZWN0LCBpc0Z1bmN0aW9uLCBpc051bWJlciwgaXNPYmplY3QsIGlzUGxhaW5PYmplY3QsIGlzUHJvbWlzZSwgaXNSZWdFeHAsIGlzU3RyaW5nLCBpc1N5bWJvbCwgam9pbiwgbWFrZVN5bWJvbCwgbWFyaywgbWVhc3VyZSwgb2JqZWN0VG9TdHJpbmcsIHNhbml0aXplVHJhbnNsYXRlZEh0bWwsIHRvRGlzcGxheVN0cmluZywgdG9UeXBlU3RyaW5nLCB3YXJuLCB3YXJuT25jZSB9O1xuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=