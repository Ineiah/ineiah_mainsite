import { injectHead, useHead } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/composables/head.js?v=7e73afc2";
import { TemplateParamsPlugin, defineHeadPlugin } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/unhead@3.3.1_esbuild@0.28.1_rolldown@1.2.2_rollup@4.62.4_vite@8.2.0_@types+node@26.1.2__626a09bc236bc26ef03db1436f1ed41d/node_modules/unhead/dist/plugins.mjs?v=7e73afc2";
import { processTemplateParams } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/unhead@3.3.1_esbuild@0.28.1_rolldown@1.2.2_rollup@4.62.4_vite@8.2.0_@types+node@26.1.2__626a09bc236bc26ef03db1436f1ed41d/node_modules/unhead/dist/utils.mjs?v=7e73afc2";
import { computed, defineComponent, h, isRef, ref, unref } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";

//#region node_modules/.pnpm/nuxt-schema-org@6.2.8_e1ea9efbc155025faaca417da5a26175/node_modules/nuxt-schema-org/dist/vendor/schema-org-v3/shared/schema-org.BfytO5kO.mjs
// @__NO_SIDE_EFFECTS__
function defineSchemaOrgResolver(schema) {
	return schema;
}
var PROTOCOL_RE = /^[\s\w\0+.-]{2,}:(?:[/\\]{2})?/;
var JOIN_LEADING_SLASH_RE = /^\.?\//;
function hasProtocol(input) {
	return PROTOCOL_RE.test(input);
}
function withoutTrailingSlash(input = "") {
	return (input.endsWith("/") ? input.slice(0, -1) : input) || "/";
}
function withTrailingSlash(input = "") {
	return input.endsWith("/") ? input : `${input}/`;
}
function joinURL(base, input) {
	if (!input || input === "/") return base || "";
	return base ? withTrailingSlash(base) + input.replace(JOIN_LEADING_SLASH_RE, "") : input;
}
function withBase(input, base) {
	if (!base || base === "/" || hasProtocol(input)) return input;
	const normalizedBase = withoutTrailingSlash(base);
	if (input.startsWith(normalizedBase)) {
		const nextChar = input[normalizedBase.length];
		if (!nextChar || nextChar === "/" || nextChar === "?") return input;
	}
	return joinURL(normalizedBase, input);
}
function idReference(node) {
	return { "@id": typeof node !== "string" ? node["@id"] : node };
}
function resolvableDateToDate(val) {
	try {
		const date = val instanceof Date ? val : new Date(Date.parse(val));
		const month = String(date.getMonth() + 1).padStart(2, "0");
		const day = String(date.getDate()).padStart(2, "0");
		return `${date.getFullYear()}-${month}-${day}`;
	} catch {}
	return typeof val === "string" ? val : val.toString();
}
var IS_VALID_W3C_DATE = [
	/(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d+([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))/,
	/^\d{4}-[01]\d-[0-3]\d$/,
	/^\d{4}-[01]\d$/,
	/^\d{4}$/
];
function isValidW3CDate(d) {
	return IS_VALID_W3C_DATE.some((r) => r.test(d));
}
function resolvableDateToIso(val) {
	if (!val) return val;
	try {
		if (val instanceof Date) return val.toISOString();
		else if (isValidW3CDate(val)) return val;
		else return new Date(Date.parse(val)).toISOString();
	} catch {}
	return typeof val === "string" ? val : val.toString();
}
var IdentityId = "#identity";
function setIfEmpty(node, field, value) {
	if (node?.[field] === void 0 && value != null) node[field] = value;
}
function asArray(input) {
	return Array.isArray(input) ? input : [input];
}
function dedupeMerge(node, field, value) {
	const data = new Set(asArray(node[field]));
	data.add(value);
	node[field] = [...data].filter(Boolean);
}
function prefixId(url, id) {
	if (hasProtocol(id)) return id;
	if (!id.includes("#")) id = `#${id}`;
	return `${url || ""}${id}`;
}
function trimLength(val, length) {
	if (!val) return val;
	if (val.length > length) {
		const trimmedString = val.substring(0, length);
		return trimmedString.substring(0, Math.min(trimmedString.length, trimmedString.lastIndexOf(" ")));
	}
	return val;
}
function resolveDefaultType(node, defaultType) {
	const val = node["@type"];
	if (val === defaultType) return;
	if (typeof val === "string" && typeof defaultType === "string") {
		if (val !== defaultType) node["@type"] = [defaultType, val];
		return;
	}
	const types = new Set(asArray(defaultType));
	for (const t of asArray(val)) types.add(t);
	node["@type"] = types.size === 1 ? val : [...types];
}
function resolveWithBase(base, urlOrPath) {
	if (!base || !urlOrPath || hasProtocol(urlOrPath) || urlOrPath[0] !== "/" && urlOrPath[0] !== "#") return urlOrPath;
	return withBase(urlOrPath, base);
}
function resolveAsGraphKey(key) {
	if (!key) return key;
	return key.substring(key.lastIndexOf("#"));
}
function stripEmptyProperties(obj) {
	for (const k in obj) {
		if (!Object.hasOwn(obj, k)) continue;
		const v = obj[k];
		if (v === "" || v === void 0) delete obj[k];
		else if (typeof v === "object" && v !== null) {
			if (v.__v_isReadonly || v.__v_isRef) continue;
			stripEmptyProperties(v);
		}
	}
	return obj;
}
function stripNullProperties(obj) {
	if (Array.isArray(obj)) {
		let next = 0;
		for (let i = 0; i < obj.length; i++) {
			const v = obj[i];
			if (v === null) continue;
			if (typeof v === "object" && v !== null) stripNullProperties(v);
			obj[next++] = v;
		}
		obj.length = next;
		return obj;
	}
	for (const k in obj) {
		if (!Object.hasOwn(obj, k)) continue;
		const v = obj[k];
		if (v === null) delete obj[k];
		else if (typeof v === "object") {
			if (v.__v_isReadonly || v.__v_isRef) continue;
			stripNullProperties(v);
		}
	}
	return obj;
}
function isImageObject(node) {
	return typeof node.url === "string";
}
var imageResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	alias: "image",
	cast(input) {
		if (typeof input === "string") input = { url: input };
		return input;
	},
	defaults: { "@type": "ImageObject" },
	inheritMeta: ["inLanguage"],
	idPrefix: "host",
	resolve(image, { meta }) {
		image.url = resolveWithBase(meta.host, image.url);
		setIfEmpty(image, "contentUrl", image.url);
		if (image.height && !image.width) delete image.height;
		if (image.width && !image.height) delete image.width;
		return image;
	}
});
var ALIAS_RE = /([a-z])([A-Z])/g;
function nextNodeId(ctx, alias) {
	ctx.nodeIdCounters[alias] = (ctx.nodeIdCounters[alias] || 0) + 1;
	return ctx.nodeIdCounters[alias].toString();
}
function resolveMeta(meta) {
	if (!meta.path) meta.path = "/";
	if (!meta.host && typeof document !== "undefined") meta.host = document.location.host;
	if (meta.path !== "/") {
		if (meta.trailingSlash && !meta.path.endsWith("/")) meta.path = withTrailingSlash(meta.path);
		else if (!meta.trailingSlash && meta.path.endsWith("/")) meta.path = withoutTrailingSlash(meta.path);
	}
	meta.url = joinURL(meta.host || "", meta.path);
	return meta;
}
function resolveNode(node, ctx, resolver) {
	if (resolver?.cast) node = resolver.cast(node, ctx);
	if (resolver?.defaults) {
		let defaults = resolver.defaults;
		if (typeof defaults === "function") defaults = defaults(ctx);
		node = {
			...defaults,
			...node
		};
	}
	const inheritMeta = resolver?.inheritMeta;
	if (inheritMeta) for (let i = 0; i < inheritMeta.length; i++) {
		const entry = inheritMeta[i];
		if (typeof entry === "string") setIfEmpty(node, entry, ctx.meta[entry]);
		else setIfEmpty(node, entry.key, ctx.meta[entry.meta]);
	}
	if (resolver?.resolve) node = resolver.resolve(node, ctx);
	for (const k in node) {
		const v = node[k];
		if (Array.isArray(v)) for (let i = 0; i < v.length; i++) {
			const item = v[i];
			if (typeof item === "object" && item?._resolver) node[k][i] = resolveRelation(item, ctx, item._resolver);
		}
		else if (typeof v === "object" && v?._resolver) node[k] = resolveRelation(v, ctx, v._resolver);
	}
	stripEmptyProperties(node);
	return node;
}
function resolveNodeId(node, ctx, resolver, resolveAsRoot = false) {
	if (node["@id"] && node["@id"].startsWith("http")) return node;
	const prefix = resolver ? (Array.isArray(resolver.idPrefix) ? resolver.idPrefix[0] : resolver.idPrefix) || "url" : "url";
	const rootId = node["@id"] || (resolver ? Array.isArray(resolver.idPrefix) ? resolver.idPrefix?.[1] : void 0 : "");
	if (!node["@id"] && resolveAsRoot && rootId) {
		node["@id"] = prefixId(ctx.meta[prefix], rootId);
		return node;
	}
	if (node["@id"]?.startsWith("#/schema/") || node["@id"]?.startsWith("/")) {
		node["@id"] = prefixId(ctx.meta[prefix], node["@id"]);
		return node;
	}
	let alias = resolver?.alias;
	if (!alias) alias = (asArray(node["@type"])?.[0] || "").replace(ALIAS_RE, "$1-$2").toLowerCase();
	node["@id"] = prefixId(ctx.meta[prefix], `#/schema/${alias}/${node["@id"] || nextNodeId(ctx, alias)}`);
	return node;
}
function resolveRelation(input, ctx, fallbackResolver, options = {}) {
	if (!input) return input;
	const items = asArray(input);
	const ids = [];
	for (let i = 0; i < items.length; i++) {
		const a = items[i];
		if (!a) {
			ids.push(a);
			continue;
		}
		let keyCount = 0;
		for (const _ in a) keyCount++;
		if (keyCount === 1 && a["@id"] || keyCount === 2 && a["@id"] && a["@type"]) {
			ids.push(resolveNodeId({ "@id": ctx.find(a["@id"])?.["@id"] || a["@id"] }, ctx));
			continue;
		}
		let resolver = fallbackResolver;
		if (a._resolver && typeof a._resolver !== "string") {
			resolver = a._resolver;
			delete a._resolver;
		}
		if (!resolver) {
			ids.push(a);
			continue;
		}
		let node = resolveNode(a, ctx, resolver);
		if (options.afterResolve) options.afterResolve(node);
		if (options.generateId || options.root) node = resolveNodeId(node, ctx, resolver, false);
		if (options.root) {
			if (resolver.resolveRootNode) resolver.resolveRootNode(node, ctx);
			ctx.push(node);
			ids.push(idReference(node["@id"]));
			continue;
		}
		ids.push(node);
	}
	return !options.array && ids.length === 1 ? ids[0] : ids;
}
function merge(target, source) {
	if (!source) return target;
	for (const key in source) {
		if (!Object.hasOwn(source, key) || key === "__proto__" || key === "constructor" || key === "prototype") continue;
		const value = source[key];
		if (value === void 0) continue;
		if (Array.isArray(target[key])) if (Array.isArray(value)) {
			const merged = [...target[key], ...value];
			if (key === "@type") target[key] = [...new Set(merged)];
			else if (key === "itemListElement") {
				merged.sort((a, b) => (a.position || 0) - (b.position || 0));
				for (let i = 0; i < merged.length; i++) merged[i].position = i + 1;
				target[key] = merged;
			} else if (key === "potentialAction") {
				const byType = /* @__PURE__ */ Object.create(null);
				for (const action of merged) {
					const type = action["@type"];
					if (byType[type]) {
						if (action.target && byType[type].target) {
							const a = Array.isArray(byType[type].target) ? byType[type].target : [byType[type].target];
							const b = Array.isArray(action.target) ? action.target : [action.target];
							byType[type].target = [.../* @__PURE__ */ new Set([...a, ...b])];
						}
					} else byType[type] = { ...action };
				}
				target[key] = Object.values(byType);
			} else if (merged.length > 0 && merged.every((item) => item && typeof item === "object" && item["@type"])) {
				const byType = /* @__PURE__ */ Object.create(null);
				for (const item of merged) byType[item["@type"]] = item;
				target[key] = Object.values(byType);
			} else target[key] = merged;
		} else target[key] = merge(target[key], [value]);
		else if (target[key] && typeof target[key] === "object" && typeof value === "object" && !Array.isArray(value)) target[key] = merge({ ...target[key] }, value);
		else target[key] = value;
	}
	return target;
}
var DOMAIN_RE = /(?:https?:)?\/\//;
function indexNode(index, node) {
	if (!node["@id"]) return;
	const nodeId = node["@id"];
	const fragmentKey = resolveAsGraphKey(nodeId);
	index.set(fragmentKey, node);
	index.set(nodeId, node);
	const domainKey = nodeId.replace(DOMAIN_RE, "").split("/")[0];
	index.set(domainKey, node);
}
function createSchemaOrgGraph() {
	let ctx;
	function find(id, guard) {
		const matchFragment = id[0] === "#";
		const matchDomain = id[0] === "/" && id[1] === "/";
		const key = matchFragment ? resolveAsGraphKey(id) : matchDomain ? id.replace(DOMAIN_RE, "").split("/")[0] : id;
		let node = ctx.nodeIndex.size > 0 ? ctx.nodeIndex.get(key) : void 0;
		if (!node) for (let i = 0; i < ctx.nodes.length; i++) {
			const candidate = ctx.nodes[i];
			const nodeId = candidate["@id"];
			if (!nodeId) continue;
			if ((matchFragment ? resolveAsGraphKey(nodeId) : matchDomain ? nodeId.replace(DOMAIN_RE, "").split("/")[0] : nodeId) === key) {
				node = candidate;
				break;
			}
		}
		if (!node || guard && !guard(node)) return null;
		return node;
	}
	ctx = {
		find,
		push(input) {
			if (Array.isArray(input)) for (let i = 0; i < input.length; i++) {
				const registeredNode = input[i];
				ctx.nodes.push(registeredNode);
				if (ctx.nodeIndex.size > 0) indexNode(ctx.nodeIndex, registeredNode);
			}
			else {
				const registeredNode = input;
				ctx.nodes.push(registeredNode);
				if (ctx.nodeIndex.size > 0) indexNode(ctx.nodeIndex, registeredNode);
			}
		},
		resolveGraph(meta) {
			for (const k in ctx.nodeIdCounters) delete ctx.nodeIdCounters[k];
			ctx.meta = resolveMeta({ ...meta });
			const len = ctx.nodes.length;
			for (let i = 0; i < len; i++) {
				let node = ctx.nodes[i];
				const resolver = node._resolver;
				node = resolveNode(node, ctx, resolver);
				node = resolveNodeId(node, ctx, resolver, true);
				ctx.nodes[i] = node;
			}
			const dedupedNodes = /* @__PURE__ */ Object.create(null);
			let hasDuplicates = false;
			ctx.nodeIndex.clear();
			for (let i = 0; i < ctx.nodes.length; i++) {
				const n = ctx.nodes[i];
				const nodeKey = resolveAsGraphKey(n["@id"]);
				if (dedupedNodes[nodeKey]) {
					hasDuplicates = true;
					if (n._dedupeStrategy !== "replace") dedupedNodes[nodeKey] = merge(dedupedNodes[nodeKey], n);
					else dedupedNodes[nodeKey] = n;
				} else dedupedNodes[nodeKey] = n;
			}
			if (hasDuplicates) ctx.nodes = Object.values(dedupedNodes);
			for (let i = 0; i < ctx.nodes.length; i++) indexNode(ctx.nodeIndex, ctx.nodes[i]);
			const countBeforeRelations = ctx.nodes.length;
			for (let i = 0; i < ctx.nodes.length; i++) {
				const node = ctx.nodes[i];
				if (node.image && typeof node.image === "string") node.image = resolveRelation(node.image, ctx, imageResolver, { root: true });
				node.translationOfWork = resolveRelation(node.translationOfWork, ctx);
				node.workTranslation = resolveRelation(node.workTranslation, ctx);
				const resolver = node._resolver;
				if (resolver?.resolveRootNode) resolver.resolveRootNode(node, ctx);
			}
			for (let i = 0; i < ctx.nodes.length; i++) delete ctx.nodes[i]._resolver;
			for (let i = 0; i < ctx.nodes.length; i++) stripNullProperties(ctx.nodes[i]);
			const needsDedupe = ctx.nodes.length > countBeforeRelations;
			const normalizedNodes = needsDedupe ? /* @__PURE__ */ Object.create(null) : null;
			const result = needsDedupe ? null : [];
			for (let i = 0; i < ctx.nodes.length; i++) {
				const n = ctx.nodes[i];
				const nodeKey = resolveAsGraphKey(n["@id"]);
				const keys = Object.keys(n);
				keys.sort();
				const newNode = {};
				let relationCount = 0;
				for (let j = 0; j < keys.length; j++) {
					const k = keys[j];
					if (k[0] === "_") continue;
					const v = n[k];
					if (v !== null && (Array.isArray(v) || typeof v === "object")) keys[relationCount++] = k;
					else newNode[k] = v;
				}
				for (let j = 0; j < relationCount; j++) {
					const k = keys[j];
					newNode[k] = n[k];
				}
				if (needsDedupe) normalizedNodes[nodeKey] = normalizedNodes[nodeKey] ? merge(normalizedNodes[nodeKey], newNode) : newNode;
				else result.push(newNode);
			}
			return needsDedupe ? Object.values(normalizedNodes) : result;
		},
		nodes: [],
		nodeIndex: /* @__PURE__ */ new Map(),
		nodeIdCounters: /* @__PURE__ */ Object.create(null),
		meta: resolveMeta({})
	};
	return ctx;
}
var quantitativeValueResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	cast(node) {
		if (typeof node === "number") return { value: node };
		return node;
	},
	defaults: { "@type": "QuantitativeValue" }
});
var monetaryAmountResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "MonetaryAmount" },
	resolve(node, ctx) {
		if (typeof node.value === "object") node.value = resolveRelation(node.value, ctx, quantitativeValueResolver);
		return node;
	}
});
var merchantReturnPolicyResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "MerchantReturnPolicy" },
	resolve(node, ctx) {
		if (node.returnPolicyCategory) node.returnPolicyCategory = withBase(node.returnPolicyCategory, "https://schema.org/");
		if (node.returnFees) node.returnFees = withBase(node.returnFees, "https://schema.org/");
		if (node.returnMethod) node.returnMethod = withBase(node.returnMethod, "https://schema.org/");
		node.returnShippingFeesAmount = resolveRelation(node.returnShippingFeesAmount, ctx, monetaryAmountResolver);
		return node;
	}
});
var definedRegionResolver = /* @__PURE__ */ defineSchemaOrgResolver({ defaults: { "@type": "DefinedRegion" } });
var shippingDeliveryTimeResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "ShippingDeliveryTime" },
	resolve(node, ctx) {
		node.handlingTime = resolveRelation(node.handlingTime, ctx, quantitativeValueResolver);
		node.transitTime = resolveRelation(node.transitTime, ctx, quantitativeValueResolver);
		return node;
	}
});
var offerShippingDetailsResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "OfferShippingDetails" },
	resolve(node, ctx) {
		node.deliveryTime = resolveRelation(node.deliveryTime, ctx, shippingDeliveryTimeResolver);
		node.shippingDestination = resolveRelation(node.shippingDestination, ctx, definedRegionResolver);
		node.shippingRate = resolveRelation(node.shippingRate, ctx, monetaryAmountResolver);
		return node;
	}
});
var offerResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	cast(node) {
		if (typeof node === "number" || typeof node === "string") return { price: node };
		return node;
	},
	defaults: {
		"@type": "Offer",
		"availability": "InStock"
	},
	resolve(node, ctx) {
		setIfEmpty(node, "priceCurrency", ctx.meta.currency);
		setIfEmpty(node, "priceValidUntil", new Date(Date.UTC((/* @__PURE__ */ new Date()).getFullYear() + 1, 12, -1, 0, 0, 0)));
		if (node.url) resolveWithBase(ctx.meta.host, node.url);
		if (node.availability) node.availability = withBase(node.availability, "https://schema.org/");
		if (node.itemCondition) node.itemCondition = withBase(node.itemCondition, "https://schema.org/");
		if (node.priceValidUntil) node.priceValidUntil = resolvableDateToIso(node.priceValidUntil);
		node.hasMerchantReturnPolicy = resolveRelation(node.hasMerchantReturnPolicy, ctx, merchantReturnPolicyResolver);
		node.shippingDetails = resolveRelation(node.shippingDetails, ctx, offerShippingDetailsResolver);
		return node;
	}
});
var aggregateOfferResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "AggregateOffer" },
	inheritMeta: [{
		meta: "currency",
		key: "priceCurrency"
	}],
	resolve(node, ctx) {
		node.offers = resolveRelation(node.offers, ctx, offerResolver);
		if (node.offers) setIfEmpty(node, "offerCount", asArray(node.offers).length);
		return node;
	}
});
var aggregateRatingResolver = /* @__PURE__ */ defineSchemaOrgResolver({ defaults: { "@type": "AggregateRating" } });
var listItemResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	cast(node) {
		if (typeof node === "string") node = { name: node };
		return node;
	},
	defaults: { "@type": "ListItem" },
	resolve(node, ctx) {
		if (typeof node.item === "string") node.item = resolveWithBase(ctx.meta.host, node.item);
		else if (typeof node.item === "object") node.item = resolveRelation(node.item, ctx);
		return node;
	}
});
var PrimaryBreadcrumbId = "#breadcrumb";
var breadcrumbResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "BreadcrumbList" },
	idPrefix: ["url", PrimaryBreadcrumbId],
	resolve(breadcrumb, ctx) {
		if (breadcrumb.itemListElement) {
			let index = 1;
			breadcrumb.itemListElement = resolveRelation(breadcrumb.itemListElement, ctx, listItemResolver, {
				array: true,
				afterResolve(node) {
					setIfEmpty(node, "position", index++);
				}
			});
		}
		return breadcrumb;
	},
	resolveRootNode(node, { find }) {
		const webPage = find(PrimaryWebPageId);
		if (webPage) setIfEmpty(webPage, "breadcrumb", idReference(node));
	}
});
var addressResolver = /* @__PURE__ */ defineSchemaOrgResolver({ defaults: { "@type": "PostalAddress" } });
var searchActionResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: {
		"@type": "SearchAction",
		"target": { "@type": "EntryPoint" },
		"query-input": {
			"@type": "PropertyValueSpecification",
			"valueRequired": true,
			"valueName": "search_term_string"
		}
	},
	resolve(node, ctx) {
		if (typeof node.target === "string") node.target = {
			"@type": "EntryPoint",
			"urlTemplate": resolveWithBase(ctx.meta.host, node.target)
		};
		return node;
	}
});
var PrimaryWebSiteId = "#website";
var webSiteResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "WebSite" },
	inheritMeta: ["inLanguage", {
		meta: "host",
		key: "url"
	}],
	idPrefix: ["host", PrimaryWebSiteId],
	resolve(node, ctx) {
		node.potentialAction = resolveRelation(node.potentialAction, ctx, searchActionResolver, { array: true });
		node.publisher = resolveRelation(node.publisher, ctx);
		node.dateModified = resolvableDateToIso(node.dateModified);
		node.datePublished = resolvableDateToIso(node.datePublished);
		return node;
	},
	resolveRootNode(node, { find }) {
		if (resolveAsGraphKey(node["@id"]) === "#website") {
			const identity = find(IdentityId);
			if (identity) setIfEmpty(node, "publisher", idReference(identity));
			const webPage = find(PrimaryWebPageId);
			if (webPage) setIfEmpty(webPage, "isPartOf", idReference(node));
		}
		return node;
	}
});
var organizationResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	cast(node) {
		if (typeof node === "string") return { name: node };
		return node;
	},
	defaults: { "@type": "Organization" },
	idPrefix: ["host", IdentityId],
	inheritMeta: [{
		meta: "host",
		key: "url"
	}],
	resolve(node, ctx) {
		resolveDefaultType(node, "Organization");
		node.address = resolveRelation(node.address, ctx, addressResolver);
		return node;
	},
	resolveRootNode(node, ctx) {
		const isIdentity = resolveAsGraphKey(node["@id"]) === IdentityId;
		const webPage = ctx.find(PrimaryWebPageId);
		if (node.logo && isIdentity) {
			const logoNode = resolveRelation(Array.isArray(node.logo) ? node.logo[0] : node.logo, ctx, imageResolver, {
				root: true,
				afterResolve(logo) {
					logo["@id"] = prefixId(ctx.meta.host, "#logo");
					setIfEmpty(logo, "caption", node.name);
				}
			});
			if (webPage && logoNode) setIfEmpty(webPage, "primaryImageOfPage", idReference(logoNode));
			if (node["@type"] === "Organization") node.logo = logoNode;
			else if (!ctx.find("#organization")) {
				const resolvedLogo = logoNode && typeof logoNode === "object" && logoNode["@id"] ? ctx.find(logoNode["@id"], isImageObject) : null;
				ctx.nodes.push({
					"@type": "Organization",
					"name": node.name,
					"url": node.url,
					"sameAs": node.sameAs,
					"address": node.address,
					"logo": resolvedLogo?.url,
					"_priority": -1,
					"@id": prefixId(ctx.meta.host, "#organization")
				});
			}
			if (node["@type"] !== "Organization") delete node.logo;
		}
		if (isIdentity && webPage) setIfEmpty(webPage, "about", idReference(node));
		const webSite = ctx.find(PrimaryWebSiteId);
		if (webSite) setIfEmpty(webSite, "publisher", idReference(node));
	}
});
var readActionResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "ReadAction" },
	resolve(node, ctx) {
		node.target ||= [];
		if (!node.target.includes(ctx.meta.url)) node.target.unshift(ctx.meta.url);
		return node;
	}
});
var PrimaryWebPageId = "#webpage";
var webPageResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults({ meta }) {
		const endPath = withoutTrailingSlash(meta.url.substring(meta.url.lastIndexOf("/") + 1));
		let type = "WebPage";
		switch (endPath) {
			case "about":
			case "about-us":
				type = "AboutPage";
				break;
			case "search":
				type = "SearchResultsPage";
				break;
			case "checkout":
				type = "CheckoutPage";
				break;
			case "contact":
			case "get-in-touch":
			case "contact-us":
				type = "ContactPage";
				break;
			case "faq": type = "FAQPage";
		}
		return { "@type": type };
	},
	idPrefix: ["url", PrimaryWebPageId],
	inheritMeta: [
		{
			meta: "title",
			key: "name"
		},
		"description",
		"datePublished",
		"dateModified",
		"url"
	],
	resolve(node, ctx) {
		node.dateModified = resolvableDateToIso(node.dateModified);
		node.datePublished = resolvableDateToIso(node.datePublished);
		resolveDefaultType(node, "WebPage");
		node.about = resolveRelation(node.about, ctx, organizationResolver);
		node.breadcrumb = resolveRelation(node.breadcrumb, ctx, breadcrumbResolver);
		node.author = resolveRelation(node.author, ctx, personResolver);
		node.primaryImageOfPage = resolveRelation(node.primaryImageOfPage, ctx, imageResolver);
		if (node.potentialAction) {
			const resolveAction = (action) => {
				if (!action || typeof action !== "object") return action;
				const type = action["@type"];
				return type === "ReadAction" || Array.isArray(type) && type.includes("ReadAction") || "target" in action ? resolveRelation(action, ctx, readActionResolver) : resolveRelation(action, ctx);
			};
			node.potentialAction = Array.isArray(node.potentialAction) ? node.potentialAction.map(resolveAction) : resolveAction(node.potentialAction);
		}
		if (node["@type"] === "WebPage" && ctx.meta.url) setIfEmpty(node, "potentialAction", [{
			"@type": "ReadAction",
			"target": [ctx.meta.url]
		}]);
		return node;
	},
	resolveRootNode(webPage, { find, meta }) {
		const identity = find(IdentityId);
		const webSite = find(PrimaryWebSiteId);
		const logo = find("#logo");
		if (identity && meta.url === meta.host) setIfEmpty(webPage, "about", idReference(identity));
		if (logo) setIfEmpty(webPage, "primaryImageOfPage", idReference(logo));
		if (webSite) setIfEmpty(webPage, "isPartOf", idReference(webSite));
		const breadcrumb = find(PrimaryBreadcrumbId);
		if (breadcrumb) setIfEmpty(webPage, "breadcrumb", idReference(breadcrumb));
		return webPage;
	}
});
var personResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	cast(node) {
		if (typeof node === "string") return { name: node };
		return node;
	},
	defaults: { "@type": "Person" },
	idPrefix: ["host", IdentityId],
	resolve(node, ctx) {
		if (node.url) node.url = resolveWithBase(ctx.meta.host, node.url);
		return node;
	},
	resolveRootNode(node, { find, meta }) {
		if (resolveAsGraphKey(node["@id"]) === IdentityId) {
			setIfEmpty(node, "url", meta.host);
			const webPage = find(PrimaryWebPageId);
			if (webPage) setIfEmpty(webPage, "about", idReference(node));
			const webSite = find(PrimaryWebSiteId);
			if (webSite) setIfEmpty(webSite, "publisher", idReference(node));
		}
		const article = find(PrimaryArticleId);
		if (article) setIfEmpty(article, "author", idReference(node));
	}
});
var PrimaryArticleId = "#article";
var articleResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "Article" },
	inheritMeta: [
		"inLanguage",
		"description",
		"image",
		"dateModified",
		"datePublished",
		{
			meta: "title",
			key: "headline"
		}
	],
	idPrefix: ["url", PrimaryArticleId],
	resolve(node, ctx) {
		node.author = resolveRelation(node.author, ctx, personResolver, { root: true });
		node.publisher = resolveRelation(node.publisher, ctx);
		node.dateModified = resolvableDateToIso(node.dateModified);
		node.datePublished = resolvableDateToIso(node.datePublished);
		resolveDefaultType(node, "Article");
		node.headline = trimLength(node.headline, 110);
		return node;
	},
	resolveRootNode(node, { find, meta }) {
		const webPage = find(PrimaryWebPageId);
		const identity = find(IdentityId);
		if (node.image && !node.thumbnailUrl) {
			const firstImage = asArray(node.image)[0];
			if (typeof firstImage === "string") setIfEmpty(node, "thumbnailUrl", resolveWithBase(meta.host, firstImage));
			else if (firstImage?.["@id"]) setIfEmpty(node, "thumbnailUrl", find(firstImage["@id"], isImageObject)?.url);
		}
		if (identity) {
			setIfEmpty(node, "publisher", idReference(identity));
			setIfEmpty(node, "author", idReference(identity));
		}
		if (webPage) {
			setIfEmpty(node, "isPartOf", idReference(webPage));
			setIfEmpty(node, "mainEntityOfPage", idReference(webPage));
			setIfEmpty(webPage, "potentialAction", [{
				"@type": "ReadAction",
				"target": [meta.url]
			}]);
			setIfEmpty(webPage, "dateModified", node.dateModified);
			setIfEmpty(webPage, "datePublished", node.datePublished);
		}
		return node;
	}
});
var bookEditionResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "Book" },
	inheritMeta: ["inLanguage"],
	resolve(node, ctx) {
		if (node.bookFormat) node.bookFormat = withBase(node.bookFormat, "https://schema.org/");
		if (node.datePublished) node.datePublished = resolvableDateToDate(node.datePublished);
		node.author = resolveRelation(node.author, ctx);
		return node;
	},
	resolveRootNode(node, { find }) {
		const identity = find(IdentityId);
		if (identity) setIfEmpty(node, "provider", idReference(identity));
		return node;
	}
});
var bookResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "Book" },
	inheritMeta: [
		"description",
		"url",
		{
			meta: "title",
			key: "name"
		}
	],
	idPrefix: ["url", "#book"],
	resolve(node, ctx) {
		node.workExample = resolveRelation(node.workExample, ctx, bookEditionResolver);
		node.author = resolveRelation(node.author, ctx);
		if (node.url && ctx.meta.host) node.url = withBase(node.url, ctx.meta.host);
		return node;
	},
	resolveRootNode(node, { find }) {
		const identity = find(IdentityId);
		if (identity) setIfEmpty(node, "author", idReference(identity));
		return node;
	}
});
var commentResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "Comment" },
	idPrefix: "url",
	resolve(node, ctx) {
		node.author = resolveRelation(node.author, ctx, personResolver, { root: true });
		node.dateCreated = resolvableDateToIso(node.dateCreated);
		node.dateModified = resolvableDateToIso(node.dateModified);
		return node;
	},
	resolveRootNode(node, { find }) {
		const article = find(PrimaryArticleId);
		if (article) setIfEmpty(node, "about", idReference(article));
	}
});
var courseResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "Course" },
	resolve(node, ctx) {
		node.provider = resolveRelation(node.provider, ctx, organizationResolver, { root: true });
		return node;
	},
	resolveRootNode(node, { find }) {
		const identity = find(IdentityId);
		if (identity) setIfEmpty(node, "provider", idReference(identity));
		return node;
	}
});
var datasetResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "Dataset" },
	inheritMeta: [
		"description",
		"url",
		"dateModified",
		"datePublished",
		{
			meta: "title",
			key: "name"
		}
	],
	idPrefix: ["url", "#dataset"],
	resolve(node, ctx) {
		resolveDefaultType(node, "Dataset");
		node.creator = resolveRelation(node.creator, ctx, personResolver, { root: true });
		node.dateModified = resolvableDateToIso(node.dateModified);
		node.datePublished = resolvableDateToIso(node.datePublished);
		return node;
	}
});
var placeResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "Place" },
	resolve(node, ctx) {
		if (typeof node.address !== "string") node.address = resolveRelation(node.address, ctx, addressResolver);
		return node;
	}
});
var virtualLocationResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	cast(node) {
		if (typeof node === "string") return { url: node };
		return node;
	},
	defaults: { "@type": "VirtualLocation" }
});
var eventResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "Event" },
	inheritMeta: [
		"inLanguage",
		"description",
		"image",
		{
			meta: "title",
			key: "name"
		}
	],
	idPrefix: ["url", "#event"],
	resolve(node, ctx) {
		if (node.location) {
			const resolveLocation = (location) => {
				const type = typeof location === "object" && location !== null ? location["@type"] : void 0;
				return typeof location === "string" || typeof location === "object" && location !== null && (type === "VirtualLocation" || Array.isArray(type) && type.includes("VirtualLocation") || typeof location.url !== "undefined") ? resolveRelation(location, ctx, virtualLocationResolver) : resolveRelation(location, ctx, placeResolver);
			};
			if (Array.isArray(node.location)) {
				const locations = node.location.map(resolveLocation);
				node.location = locations.length === 1 ? locations[0] : locations;
			} else node.location = resolveLocation(node.location);
		}
		node.performer = resolveRelation(node.performer, ctx, personResolver, { root: true });
		node.organizer = resolveRelation(node.organizer, ctx, organizationResolver, { root: true });
		node.offers = resolveRelation(node.offers, ctx, offerResolver);
		if (node.eventAttendanceMode) node.eventAttendanceMode = withBase(node.eventAttendanceMode, "https://schema.org/");
		if (node.eventStatus) node.eventStatus = withBase(node.eventStatus, "https://schema.org/");
		const isOnline = node.eventStatus === "https://schema.org/EventMovedOnline" || node.eventAttendanceMode === "https://schema.org/OnlineEventAttendanceMode";
		[
			"startDate",
			"previousStartDate",
			"endDate"
		].forEach((date) => {
			if (!isOnline) {
				if (node[date] instanceof Date && node[date].getHours() === 0 && node[date].getMinutes() === 0) node[date] = resolvableDateToDate(node[date]);
			} else node[date] = resolvableDateToIso(node[date]);
		});
		setIfEmpty(node, "endDate", node.startDate);
		return node;
	},
	resolveRootNode(node, { find }) {
		const identity = find(IdentityId);
		if (identity) setIfEmpty(node, "organizer", idReference(identity));
	}
});
var openingHoursResolver = /* @__PURE__ */ defineSchemaOrgResolver({ defaults: {
	"@type": "OpeningHoursSpecification",
	"opens": "00:00",
	"closes": "23:59"
} });
var localBusinessResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": ["Organization", "LocalBusiness"] },
	inheritMeta: [{
		key: "url",
		meta: "host"
	}, {
		key: "currenciesAccepted",
		meta: "currency"
	}],
	idPrefix: ["host", IdentityId],
	resolve(node, ctx) {
		resolveDefaultType(node, ["Organization", "LocalBusiness"]);
		node.address = resolveRelation(node.address, ctx, addressResolver);
		node.openingHoursSpecification = resolveRelation(node.openingHoursSpecification, ctx, openingHoursResolver);
		node = resolveNode({ ...node }, ctx, organizationResolver);
		return node;
	},
	resolveRootNode(node, ctx) {
		organizationResolver.resolveRootNode(node, ctx);
		return node;
	}
});
var ratingResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	cast(node) {
		if (typeof node === "number") return { ratingValue: node };
		return node;
	},
	defaults: {
		"@type": "Rating",
		"bestRating": 5,
		"worstRating": 1
	}
});
var foodEstablishmentResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": [
		"Organization",
		"LocalBusiness",
		"FoodEstablishment"
	] },
	inheritMeta: [{
		key: "url",
		meta: "host"
	}, {
		key: "currenciesAccepted",
		meta: "currency"
	}],
	idPrefix: ["host", IdentityId],
	resolve(node, ctx) {
		resolveDefaultType(node, [
			"Organization",
			"LocalBusiness",
			"FoodEstablishment"
		]);
		node.starRating = resolveRelation(node.starRating, ctx, ratingResolver);
		node = resolveNode(node, ctx, localBusinessResolver);
		return node;
	},
	resolveRootNode(node, ctx) {
		localBusinessResolver.resolveRootNode(node, ctx);
		return node;
	}
});
var howToStepDirectionResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	cast(node) {
		if (typeof node === "string") return { text: node };
		return node;
	},
	defaults: { "@type": "HowToDirection" }
});
var howToStepResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	cast(node) {
		if (typeof node === "string") return { text: node };
		return node;
	},
	defaults: { "@type": "HowToStep" },
	resolve(step, ctx) {
		if (step.url) step.url = resolveWithBase(ctx.meta.url, step.url);
		if (step.image) step.image = resolveRelation(step.image, ctx, imageResolver, { root: true });
		if (step.itemListElement) step.itemListElement = resolveRelation(step.itemListElement, ctx, howToStepDirectionResolver);
		return step;
	}
});
var howToResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "HowTo" },
	inheritMeta: [
		"description",
		"image",
		"inLanguage",
		{
			meta: "title",
			key: "name"
		}
	],
	idPrefix: ["url", "#howto"],
	resolve(node, ctx) {
		node.step = resolveRelation(node.step, ctx, howToStepResolver);
		return node;
	},
	resolveRootNode(node, { find }) {
		const webPage = find(PrimaryWebPageId);
		if (webPage) setIfEmpty(node, "mainEntityOfPage", idReference(webPage));
	}
});
var itemListResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "ItemList" },
	resolve(node, ctx) {
		if (node.itemListElement) {
			let index = 1;
			node.itemListElement = resolveRelation(node.itemListElement, ctx, listItemResolver, {
				array: true,
				afterResolve(node2) {
					setIfEmpty(node2, "position", index++);
				}
			});
		}
		return node;
	}
});
var jobPostingResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "JobPosting" },
	idPrefix: ["url", "#job-posting"],
	resolve(node, ctx) {
		node.datePosted = resolvableDateToIso(node.datePosted);
		node.hiringOrganization = resolveRelation(node.hiringOrganization, ctx, organizationResolver);
		node.jobLocation = resolveRelation(node.jobLocation, ctx, placeResolver);
		node.baseSalary = resolveRelation(node.baseSalary, ctx, monetaryAmountResolver);
		node.validThrough = resolvableDateToIso(node.validThrough);
		return node;
	},
	resolveRootNode(jobPosting, { find }) {
		const webPage = find(PrimaryWebPageId);
		const identity = find(IdentityId);
		if (identity) setIfEmpty(jobPosting, "hiringOrganization", idReference(identity));
		if (webPage) setIfEmpty(jobPosting, "mainEntityOfPage", idReference(webPage));
		return jobPosting;
	}
});
var reviewResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "Review" },
	inheritMeta: ["inLanguage"],
	resolve(review, ctx) {
		review.reviewRating = resolveRelation(review.reviewRating, ctx, ratingResolver);
		review.author = resolveRelation(review.author, ctx, personResolver);
		return review;
	}
});
var videoResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	cast(input) {
		if (typeof input === "string") input = { url: input };
		return input;
	},
	alias: "video",
	defaults: { "@type": "VideoObject" },
	inheritMeta: [
		{
			meta: "title",
			key: "name"
		},
		"description",
		"image",
		"inLanguage",
		{
			meta: "datePublished",
			key: "uploadDate"
		}
	],
	idPrefix: "host",
	resolve(video, ctx) {
		if (video.uploadDate) video.uploadDate = resolvableDateToIso(video.uploadDate);
		video.url = resolveWithBase(ctx.meta.host, video.url);
		if (video.caption && !video.description) video.description = video.caption;
		if (!video.description) video.description = "No description";
		if (video.thumbnailUrl && (typeof video.thumbnailUrl === "string" || Array.isArray(video.thumbnailUrl))) {
			const images = asArray(video.thumbnailUrl).map((image) => resolveWithBase(ctx.meta.host, image));
			video.thumbnailUrl = images.length > 1 ? images : images[0];
		}
		if (video.thumbnail) video.thumbnail = resolveRelation(video.thumbnail, ctx, imageResolver);
		return video;
	},
	resolveRootNode(video, { find, meta }) {
		if (video.image && !video.thumbnailUrl) {
			const firstImage = asArray(video.image)[0];
			if (typeof firstImage === "string") setIfEmpty(video, "thumbnailUrl", resolveWithBase(meta.host, firstImage));
			else if (firstImage?.["@id"]) setIfEmpty(video, "thumbnailUrl", find(firstImage["@id"], isImageObject)?.url);
		}
	}
});
var movieResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "Movie" },
	resolve(node, ctx) {
		node.aggregateRating = resolveRelation(node.aggregateRating, ctx, aggregateRatingResolver);
		node.review = resolveRelation(node.review, ctx, reviewResolver);
		node.director = resolveRelation(node.director, ctx, personResolver);
		node.actor = resolveRelation(node.actor, ctx, personResolver);
		node.trailer = resolveRelation(node.trailer, ctx, videoResolver);
		node.productionCompany = resolveRelation(node.productionCompany, ctx, organizationResolver);
		if (node.dateCreated) node.dateCreated = resolvableDateToDate(node.dateCreated);
		return node;
	}
});
var musicAlbumResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "MusicAlbum" },
	idPrefix: "host",
	resolve(node, ctx) {
		if (node.datePublished) node.datePublished = resolvableDateToIso(node.datePublished);
		if (node.url) node.url = resolveWithBase(ctx.meta.host, node.url);
		node.byArtist = resolveRelation(node.byArtist, ctx, personResolver);
		node.aggregateRating = resolveRelation(node.aggregateRating, ctx, aggregateRatingResolver);
		node.review = resolveRelation(node.review, ctx, reviewResolver);
		return node;
	}
});
var musicGroupResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "MusicGroup" },
	idPrefix: "host",
	inheritMeta: [{
		meta: "host",
		key: "url"
	}],
	resolve(node, ctx) {
		if (node.foundingDate) node.foundingDate = resolvableDateToDate(node.foundingDate);
		if (node.dissolutionDate) node.dissolutionDate = resolvableDateToDate(node.dissolutionDate);
		if (node.url) node.url = resolveWithBase(ctx.meta.host, node.url);
		node.member = resolveRelation(node.member, ctx, personResolver);
		return node;
	}
});
var musicPlaylistResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "MusicPlaylist" },
	idPrefix: "host",
	resolve(node, ctx) {
		if (node.datePublished) node.datePublished = resolvableDateToIso(node.datePublished);
		if (node.dateModified) node.dateModified = resolvableDateToIso(node.dateModified);
		if (node.url) node.url = resolveWithBase(ctx.meta.host, node.url);
		node.creator = resolveRelation(node.creator, ctx, personResolver);
		node.aggregateRating = resolveRelation(node.aggregateRating, ctx, aggregateRatingResolver);
		return node;
	}
});
var musicRecordingResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "MusicRecording" },
	idPrefix: "host",
	resolve(node, ctx) {
		if (node.datePublished) node.datePublished = resolvableDateToIso(node.datePublished);
		if (node.url) node.url = resolveWithBase(ctx.meta.host, node.url);
		if (node.audio) node.audio = resolveWithBase(ctx.meta.host, node.audio);
		node.byArtist = resolveRelation(node.byArtist, ctx, personResolver);
		node.aggregateRating = resolveRelation(node.aggregateRating, ctx, aggregateRatingResolver);
		return node;
	}
});
var podcastEpisodeResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "PodcastEpisode" },
	inheritMeta: ["inLanguage"],
	resolve(node, ctx) {
		node.author = resolveRelation(node.author, ctx, personResolver);
		node.aggregateRating = resolveRelation(node.aggregateRating, ctx, aggregateRatingResolver);
		node.review = resolveRelation(node.review, ctx, reviewResolver);
		if (node.datePublished) node.datePublished = resolvableDateToIso(node.datePublished);
		if (node.uploadDate) node.uploadDate = resolvableDateToIso(node.uploadDate);
		return node;
	}
});
var podcastSeasonResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "PodcastSeason" },
	resolve(node, ctx) {
		node.actor = resolveRelation(node.actor, ctx, personResolver);
		node.director = resolveRelation(node.director, ctx, personResolver);
		node.productionCompany = resolveRelation(node.productionCompany, ctx, organizationResolver);
		node.aggregateRating = resolveRelation(node.aggregateRating, ctx, aggregateRatingResolver);
		if (node.datePublished) node.datePublished = resolvableDateToIso(node.datePublished);
		if (node.startDate) node.startDate = resolvableDateToIso(node.startDate);
		if (node.endDate) node.endDate = resolvableDateToIso(node.endDate);
		return node;
	}
});
var podcastSeriesResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "PodcastSeries" },
	resolve(node, ctx) {
		node.author = resolveRelation(node.author, ctx, personResolver);
		node.aggregateRating = resolveRelation(node.aggregateRating, ctx, aggregateRatingResolver);
		if (node.datePublished) node.datePublished = resolvableDateToIso(node.datePublished);
		if (node.startDate) node.startDate = resolvableDateToIso(node.startDate);
		if (node.endDate) node.endDate = resolvableDateToIso(node.endDate);
		return node;
	}
});
var productResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "Product" },
	inheritMeta: [
		"description",
		"image",
		{
			meta: "title",
			key: "name"
		}
	],
	idPrefix: ["url", "#product"],
	resolve(node, ctx) {
		node.aggregateOffer = resolveRelation(node.aggregateOffer, ctx, aggregateOfferResolver);
		node.aggregateRating = resolveRelation(node.aggregateRating, ctx, aggregateRatingResolver);
		node.offers = resolveRelation(node.offers, ctx, offerResolver);
		node.review = resolveRelation(node.review, ctx, reviewResolver);
		return node;
	},
	resolveRootNode(product, { find }) {
		const webPage = find(PrimaryWebPageId);
		const identity = find(IdentityId);
		if (identity) setIfEmpty(product, "brand", idReference(identity));
		if (webPage) setIfEmpty(product, "mainEntityOfPage", idReference(webPage));
		return product;
	}
});
var answerResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	cast(node) {
		if (typeof node === "string") return { text: node };
		return node;
	},
	defaults: { "@type": "Answer" }
});
var questionResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "Question" },
	inheritMeta: ["inLanguage"],
	idPrefix: "url",
	resolve(question, ctx) {
		if (question.question) {
			question.name = question.question;
			delete question.question;
		}
		if (question.answer) {
			question.acceptedAnswer = question.answer;
			delete question.answer;
		}
		question.acceptedAnswer = resolveRelation(question.acceptedAnswer, ctx, answerResolver);
		question.dateCreated = resolvableDateToIso(question.dateCreated);
		return question;
	},
	resolveRootNode(question, { find }) {
		const webPage = find(PrimaryWebPageId);
		if (webPage && asArray(webPage["@type"]).includes("FAQPage")) dedupeMerge(webPage, "mainEntity", idReference(question));
	}
});
var recipeResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "Recipe" },
	inheritMeta: [
		{
			meta: "title",
			key: "name"
		},
		"description",
		"image",
		"datePublished"
	],
	idPrefix: ["url", "#recipe"],
	resolve(node, ctx) {
		node.recipeInstructions = resolveRelation(node.recipeInstructions, ctx, howToStepResolver);
		return node;
	},
	resolveRootNode(node, { find }) {
		const article = find(PrimaryArticleId);
		const webPage = find(PrimaryWebPageId);
		if (article) setIfEmpty(node, "mainEntityOfPage", idReference(article));
		else if (webPage) setIfEmpty(node, "mainEntityOfPage", idReference(webPage));
		if (article?.author) setIfEmpty(node, "author", article.author);
		return node;
	}
});
var serviceResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "Service" },
	inheritMeta: [
		"description",
		"image",
		{
			meta: "title",
			key: "name"
		}
	],
	idPrefix: ["url", "#service"],
	resolve(node, ctx) {
		resolveDefaultType(node, "Service");
		node.offers = resolveRelation(node.offers, ctx, offerResolver);
		node.aggregateRating = resolveRelation(node.aggregateRating, ctx, aggregateRatingResolver);
		node.review = resolveRelation(node.review, ctx, reviewResolver);
		return node;
	},
	resolveRootNode(service, { find }) {
		const webPage = find(PrimaryWebPageId);
		const identity = find(IdentityId);
		if (identity) setIfEmpty(service, "provider", idReference(identity));
		if (identity) setIfEmpty(service, "brand", idReference(identity));
		if (webPage) setIfEmpty(service, "mainEntityOfPage", idReference(webPage));
		return service;
	}
});
var softwareAppResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "SoftwareApplication" },
	resolve(node, ctx) {
		resolveDefaultType(node, "SoftwareApplication");
		node.offers = resolveRelation(node.offers, ctx, offerResolver);
		node.aggregateRating = resolveRelation(node.aggregateRating, ctx, aggregateRatingResolver);
		node.review = resolveRelation(node.review, ctx, reviewResolver);
		return node;
	}
});
var tvEpisodeResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "TVEpisode" },
	resolve(node, ctx) {
		node.actor = resolveRelation(node.actor, ctx, personResolver);
		node.director = resolveRelation(node.director, ctx, personResolver);
		node.musicBy = resolveRelation(node.musicBy, ctx, personResolver);
		node.video = resolveRelation(node.video, ctx, videoResolver);
		node.aggregateRating = resolveRelation(node.aggregateRating, ctx, aggregateRatingResolver);
		node.review = resolveRelation(node.review, ctx, reviewResolver);
		if (node.datePublished) node.datePublished = resolvableDateToIso(node.datePublished);
		if (node.uploadDate) node.uploadDate = resolvableDateToIso(node.uploadDate);
		return node;
	}
});
var tvSeasonResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "TVSeason" },
	resolve(node, ctx) {
		node.actor = resolveRelation(node.actor, ctx, personResolver);
		node.director = resolveRelation(node.director, ctx, personResolver);
		node.productionCompany = resolveRelation(node.productionCompany, ctx, organizationResolver);
		node.aggregateRating = resolveRelation(node.aggregateRating, ctx, aggregateRatingResolver);
		node.trailer = resolveRelation(node.trailer, ctx, videoResolver);
		if (node.datePublished) node.datePublished = resolvableDateToIso(node.datePublished);
		if (node.startDate) node.startDate = resolvableDateToIso(node.startDate);
		if (node.endDate) node.endDate = resolvableDateToIso(node.endDate);
		return node;
	}
});
var tvSeriesResolver = /* @__PURE__ */ defineSchemaOrgResolver({
	defaults: { "@type": "TVSeries" },
	resolve(node, ctx) {
		node.actor = resolveRelation(node.actor, ctx, personResolver);
		node.director = resolveRelation(node.director, ctx, personResolver);
		node.creator = resolveRelation(node.creator, ctx, personResolver);
		node.productionCompany = resolveRelation(node.productionCompany, ctx, organizationResolver);
		node.aggregateRating = resolveRelation(node.aggregateRating, ctx, aggregateRatingResolver);
		node.trailer = resolveRelation(node.trailer, ctx, videoResolver);
		if (node.datePublished) node.datePublished = resolvableDateToIso(node.datePublished);
		if (node.startDate) node.startDate = resolvableDateToIso(node.startDate);
		if (node.endDate) node.endDate = resolvableDateToIso(node.endDate);
		return node;
	}
});
function mergeObjects(target, source) {
	const result = { ...target };
	for (const key in source) {
		if (!Object.hasOwn(source, key) || source[key] === void 0 || key === "__proto__" || key === "constructor" || key === "prototype") continue;
		if (result[key] && typeof result[key] === "object" && typeof source[key] === "object" && !Array.isArray(result[key]) && !Array.isArray(source[key])) result[key] = mergeObjects(result[key], source[key]);
		else if (!result[key]) result[key] = source[key];
	}
	return result;
}
function isSchemaOrgTag(tag) {
	return tag.tag === "script" && tag.props.type === "application/ld+json" && tag.props.nodes || tag.key === "schema-org-graph";
}
function UnheadSchemaOrg(config = {}, meta = () => ({}), options) {
	config = resolveMeta({ ...config });
	let graph;
	let resolvedMeta = {};
	return defineHeadPlugin((head) => {
		head.use(TemplateParamsPlugin);
		function collectTag(tag) {
			if (tag.tag === "script" && tag.props.type === "application/ld+json" && tag.props.nodes) {
				const nodes = tag.props.nodes;
				for (const node of Array.isArray(nodes) ? nodes : [nodes]) {
					if (typeof node !== "object" || node === null) continue;
					const newNode = {
						...node,
						_dedupeStrategy: tag.tagDuplicateStrategy
					};
					graph.push(newNode);
				}
				tag.tagPosition = tag.tagPosition || (config.tagPosition === "head" ? "head" : "bodyClose");
			}
			if (tag.tag === "htmlAttrs" && typeof tag.props.lang === "string") resolvedMeta.inLanguage = tag.props.lang;
			else if (tag.tag === "title" && tag.textContent != null && typeof tag.textContent !== "function") resolvedMeta.title = String(tag.textContent);
			else if (tag.tag === "meta" && tag.props.name === "description" && typeof tag.props.content === "string") resolvedMeta.description = tag.props.content;
			else if (tag.tag === "link" && tag.props.rel === "canonical" && typeof tag.props.href === "string") {
				resolvedMeta.url = tag.props.href;
				if (resolvedMeta.url && !resolvedMeta.host) try {
					resolvedMeta.host = new URL(resolvedMeta.url).origin;
				} catch {}
			} else if (tag.tag === "meta" && tag.props.property === "og:image" && typeof tag.props.content === "string") resolvedMeta.image = tag.props.content;
			else if (tag.tag === "templateParams" && tag.props.schemaOrg) resolvedMeta = {
				...resolvedMeta,
				...tag.props.schemaOrg
			};
		}
		return {
			key: "schema-org",
			hooks: {
				"entries:resolve": (ctx) => {
					graph = graph || createSchemaOrgGraph();
					graph.nodes = [];
					graph.nodeIndex.clear();
					resolvedMeta = {};
					for (const entry of ctx.entries) if (entry._tags) {
						if (entry._tags.some(isSchemaOrgTag)) {
							delete entry._tags;
							continue;
						}
						for (const tag of entry._tags) collectTag(tag);
					}
				},
				"entries:normalize": ({ tags }) => {
					for (const tag of tags) collectTag(tag);
				},
				"tags:resolve": (ctx) => {
					for (const k in ctx.tags) {
						const tag = ctx.tags[k];
						if (tag.tag === "script" && tag.props.type === "application/ld+json" && tag.props.nodes) {
							delete tag.props.nodes;
							const resolvedGraph = graph.resolveGraph({
								...meta?.() || {},
								...config,
								...resolvedMeta
							});
							if (!resolvedGraph.length) {
								tag.props = {};
								return;
							}
							const minify = options?.minify || false;
							tag.innerHTML = JSON.stringify({
								"@context": "https://schema.org",
								"@graph": resolvedGraph
							}, (_, value) => {
								if (typeof value === "string") return processTemplateParams(value, head._templateParams, head._separator);
								return value;
							}, minify ? 0 : 2);
							return;
						}
					}
				},
				"tags:afterResolve": (ctx) => {
					let firstNodeIdx;
					let toRemove;
					for (let i = 0; i < ctx.tags.length; i++) {
						const tag = ctx.tags[i];
						if (!tag?.props) continue;
						if (isSchemaOrgTag(tag)) {
							delete tag.props.nodes;
							if (typeof firstNodeIdx === "undefined") {
								firstNodeIdx = i;
								continue;
							}
							ctx.tags[firstNodeIdx].props = mergeObjects(ctx.tags[firstNodeIdx].props, tag.props);
							delete ctx.tags[firstNodeIdx].props.nodes;
							(toRemove ||= /* @__PURE__ */ new Set()).add(i);
						}
					}
					if (toRemove) ctx.tags = ctx.tags.filter((_, i) => !toRemove.has(i));
				}
			}
		};
	}, "schema-org");
}
function normalizeSchemaOrgInput(input) {
	const script = input?.script;
	const graph = script?.[0];
	if (Array.isArray(script) && script.length === 1 && graph && typeof graph === "object" && graph.type === "application/ld+json" && graph.key === "schema-org-graph" && "nodes" in graph) return input;
	return { script: [{
		type: "application/ld+json",
		key: "schema-org-graph",
		nodes: input
	}] };
}
//#endregion
//#region node_modules/.pnpm/nuxt-schema-org@6.2.8_e1ea9efbc155025faaca417da5a26175/node_modules/nuxt-schema-org/dist/vendor/schema-org-v3/vue/meta.mjs
var schemaOrgAutoImports = [{
	from: "@unhead/schema-org/vue",
	imports: [
		"defineAddress",
		"defineAggregateOffer",
		"defineAggregateRating",
		"defineArticle",
		"defineBook",
		"defineBookEdition",
		"defineBreadcrumb",
		"defineComment",
		"defineCourse",
		"defineDataset",
		"defineEvent",
		"defineFoodEstablishment",
		"defineHowTo",
		"defineHowToStep",
		"defineImage",
		"defineItemList",
		"defineJobPosting",
		"defineListItem",
		"defineLocalBusiness",
		"defineMovie",
		"defineMusicAlbum",
		"defineMusicGroup",
		"defineMusicPlaylist",
		"defineMusicRecording",
		"defineOffer",
		"defineOpeningHours",
		"defineOrganization",
		"definePerson",
		"definePlace",
		"definePodcastEpisode",
		"definePodcastSeason",
		"definePodcastSeries",
		"defineProduct",
		"defineQuestion",
		"defineReadAction",
		"defineRecipe",
		"defineReview",
		"defineSearchAction",
		"defineService",
		"defineSoftwareApp",
		"defineTVEpisode",
		"defineTVSeason",
		"defineTVSeries",
		"defineVideo",
		"defineVirtualLocation",
		"defineWebPage",
		"defineWebSite",
		"useSchemaOrg"
	]
}];
var schemaOrgComponents = [
	"SchemaOrgArticle",
	"SchemaOrgBreadcrumb",
	"SchemaOrgComment",
	"SchemaOrgEvent",
	"SchemaOrgFoodEstablishment",
	"SchemaOrgHowTo",
	"SchemaOrgImage",
	"SchemaOrgJobPosting",
	"SchemaOrgLocalBusiness",
	"SchemaOrgOrganization",
	"SchemaOrgPerson",
	"SchemaOrgProduct",
	"SchemaOrgQuestion",
	"SchemaOrgRecipe",
	"SchemaOrgReview",
	"SchemaOrgVideo",
	"SchemaOrgWebPage",
	"SchemaOrgWebSite",
	"SchemaOrgMovie",
	"SchemaOrgCourse",
	"SchemaOrgItemList",
	"SchemaOrgBook",
	"SchemaOrgSoftwareApp"
];
function SchemaOrgResolver(options = {}) {
	const { prefix = "" } = options;
	return {
		type: "component",
		resolve: (name) => {
			if (name.startsWith(prefix)) {
				const componentName = name.substring(prefix.length);
				if (schemaOrgComponents.includes(componentName)) return {
					name: componentName,
					from: "@unhead/schema-org/vue"
				};
			}
		}
	};
}
//#endregion
//#region node_modules/.pnpm/nuxt-schema-org@6.2.8_e1ea9efbc155025faaca417da5a26175/node_modules/nuxt-schema-org/dist/vendor/schema-org-v3/vue.mjs
function withResolver(input, resolver) {
	return {
		...input,
		_resolver: resolver
	};
}
function provideResolver(input, resolver) {
	const resolvedInput = input || {};
	if (isRef(resolvedInput)) return computed(() => {
		const value = resolvedInput.value;
		return value && typeof value === "object" ? withResolver(value, resolver) : value;
	});
	return withResolver(resolvedInput, resolver);
}
function defineAddress(input) {
	return provideResolver(input, addressResolver);
}
function defineAggregateOffer(input) {
	return provideResolver(input, aggregateOfferResolver);
}
function defineAggregateRating(input) {
	return provideResolver(input, aggregateRatingResolver);
}
function defineArticle(input) {
	return provideResolver(input, articleResolver);
}
function defineBreadcrumb(input) {
	return provideResolver(input, breadcrumbResolver);
}
function defineComment(input) {
	return provideResolver(input, commentResolver);
}
function defineEvent(input) {
	return provideResolver(input, eventResolver);
}
function defineFoodEstablishment(input) {
	return provideResolver(input, foodEstablishmentResolver);
}
function defineVirtualLocation(input) {
	return provideResolver(input, virtualLocationResolver);
}
function definePlace(input) {
	return provideResolver(input, placeResolver);
}
function defineHowTo(input) {
	return provideResolver(input, howToResolver);
}
function defineHowToStep(input) {
	return provideResolver(input, howToStepResolver);
}
function defineImage(input) {
	return provideResolver(input, imageResolver);
}
function defineJobPosting(input) {
	return provideResolver(input, jobPostingResolver);
}
function defineLocalBusiness(input) {
	return provideResolver(input, localBusinessResolver);
}
function defineOffer(input) {
	return provideResolver(input, offerResolver);
}
function defineOpeningHours(input) {
	return provideResolver(input, openingHoursResolver);
}
function defineOrganization(input) {
	return provideResolver(input, organizationResolver);
}
function definePerson(input) {
	return provideResolver(input, personResolver);
}
function defineProduct(input) {
	return provideResolver(input, productResolver);
}
function defineQuestion(input) {
	return provideResolver(input, questionResolver);
}
function defineRecipe(input) {
	return provideResolver(input, recipeResolver);
}
function defineReview(input) {
	return provideResolver(input, reviewResolver);
}
function defineVideo(input) {
	return provideResolver(input, videoResolver);
}
function defineWebPage(input) {
	return provideResolver(input, webPageResolver);
}
function defineWebSite(input) {
	return provideResolver(input, webSiteResolver);
}
function defineBook(input) {
	return provideResolver(input, bookResolver);
}
function defineCourse(input) {
	return provideResolver(input, courseResolver);
}
function defineItemList(input) {
	return provideResolver(input, itemListResolver);
}
function defineListItem(input) {
	return provideResolver(input, listItemResolver);
}
function defineMovie(input) {
	return provideResolver(input, movieResolver);
}
function defineSearchAction(input) {
	return provideResolver(input, searchActionResolver);
}
function defineReadAction(input) {
	return provideResolver(input, readActionResolver);
}
function defineSoftwareApp(input) {
	return provideResolver(input, softwareAppResolver);
}
function defineBookEdition(input) {
	return provideResolver(input, bookEditionResolver);
}
function defineDataset(input) {
	return provideResolver(input, datasetResolver);
}
function defineMusicRecording(input) {
	return provideResolver(input, musicRecordingResolver);
}
function defineMusicAlbum(input) {
	return provideResolver(input, musicAlbumResolver);
}
function defineMusicGroup(input) {
	return provideResolver(input, musicGroupResolver);
}
function defineMusicPlaylist(input) {
	return provideResolver(input, musicPlaylistResolver);
}
function definePodcastSeries(input) {
	return provideResolver(input, podcastSeriesResolver);
}
function definePodcastEpisode(input) {
	return provideResolver(input, podcastEpisodeResolver);
}
function definePodcastSeason(input) {
	return provideResolver(input, podcastSeasonResolver);
}
function defineTVSeries(input) {
	return provideResolver(input, tvSeriesResolver);
}
function defineTVSeason(input) {
	return provideResolver(input, tvSeasonResolver);
}
function defineTVEpisode(input) {
	return provideResolver(input, tvEpisodeResolver);
}
function defineService(input) {
	return provideResolver(input, serviceResolver);
}
function useSchemaOrg(input = [], options = {}) {
	(options.head || injectHead()).use(UnheadSchemaOrg());
	const entry = useHead(normalizeSchemaOrgInput(input), options);
	const corePatch = entry.patch;
	const publicEntry = entry;
	publicEntry.patch = (input2) => corePatch(normalizeSchemaOrgInput(input2));
	return publicEntry;
}
var KEBAB_RE = /-./g;
function shallowVNodesToText(nodes) {
	let text = "";
	for (const node of nodes) if (typeof node.children === "string") text += node.children.trim();
	return text;
}
function fixKey(s) {
	let key = s.replace(KEBAB_RE, (x) => x[1].toUpperCase());
	if (key === "type" || key === "id") key = `@${key}`;
	return key;
}
function ignoreKey(s) {
	if (s.startsWith("aria-") || s.startsWith("data-")) return false;
	return s === "class" || s === "style";
}
function defineSchemaOrgComponent(name, defineFn) {
	return defineComponent({
		name,
		props: { as: String },
		setup(props, { slots, attrs }) {
			const node = ref(null);
			const nodePartial = computed(() => {
				const val = {};
				Object.entries(unref(attrs)).forEach(([key, value]) => {
					if (!ignoreKey(key)) val[fixKey(key)] = unref(value);
				});
				if (!node.value) for (const [key, slot] of Object.entries(slots)) {
					if (!slot || key === "default") continue;
					val[fixKey(key)] = shallowVNodesToText(slot(props));
				}
				return val;
			});
			if (defineFn) useSchemaOrg(defineFn(unref(nodePartial)));
			return () => {
				const data = unref(nodePartial);
				if (!slots.default) return null;
				const childSlots = [];
				if (slots.default) childSlots.push(slots.default(data));
				return h(props.as || "div", {}, childSlots);
			};
		}
	});
}
var SchemaOrgArticle = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgArticle", defineArticle);
var SchemaOrgBreadcrumb = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgBreadcrumb", defineBreadcrumb);
var SchemaOrgComment = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgComment", defineComment);
var SchemaOrgEvent = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgEvent", defineEvent);
var SchemaOrgFoodEstablishment = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgFoodEstablishment", defineFoodEstablishment);
var SchemaOrgHowTo = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgHowTo", defineHowTo);
var SchemaOrgImage = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgImage", defineImage);
var SchemaOrgJobPosting = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgJobPosting", defineJobPosting);
var SchemaOrgLocalBusiness = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgLocalBusiness", defineLocalBusiness);
var SchemaOrgOrganization = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgOrganization", defineOrganization);
var SchemaOrgPerson = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgPerson", definePerson);
var SchemaOrgProduct = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgProduct", defineProduct);
var SchemaOrgQuestion = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgQuestion", defineQuestion);
var SchemaOrgRecipe = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgRecipe", defineRecipe);
var SchemaOrgReview = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgReview", defineReview);
var SchemaOrgVideo = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgVideo", defineVideo);
var SchemaOrgWebPage = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgWebPage", defineWebPage);
var SchemaOrgWebSite = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgWebSite", defineWebSite);
var SchemaOrgMovie = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgMovie", defineMovie);
var SchemaOrgCourse = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgCourse", defineCourse);
var SchemaOrgItemList = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgItemList", defineItemList);
var SchemaOrgBook = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgBook", defineBook);
var SchemaOrgSoftwareApp = /* @__PURE__ */ defineSchemaOrgComponent("SchemaOrgSoftwareApp", defineSoftwareApp);
//#endregion
export { SchemaOrgArticle, SchemaOrgBook, SchemaOrgBreadcrumb, SchemaOrgComment, SchemaOrgCourse, SchemaOrgEvent, SchemaOrgFoodEstablishment, SchemaOrgHowTo, SchemaOrgImage, SchemaOrgItemList, SchemaOrgJobPosting, SchemaOrgLocalBusiness, SchemaOrgMovie, SchemaOrgOrganization, SchemaOrgPerson, SchemaOrgProduct, SchemaOrgQuestion, SchemaOrgRecipe, SchemaOrgResolver, SchemaOrgReview, SchemaOrgSoftwareApp, SchemaOrgVideo, SchemaOrgWebPage, SchemaOrgWebSite, UnheadSchemaOrg, defineAddress, defineAggregateOffer, defineAggregateRating, defineArticle, defineBook, defineBookEdition, defineBreadcrumb, defineComment, defineCourse, defineDataset, defineEvent, defineFoodEstablishment, defineHowTo, defineHowToStep, defineImage, defineItemList, defineJobPosting, defineListItem, defineLocalBusiness, defineMovie, defineMusicAlbum, defineMusicGroup, defineMusicPlaylist, defineMusicRecording, defineOffer, defineOpeningHours, defineOrganization, definePerson, definePlace, definePodcastEpisode, definePodcastSeason, definePodcastSeries, defineProduct, defineQuestion, defineReadAction, defineRecipe, defineReview, defineSchemaOrgComponent, defineSearchAction, defineService, defineSoftwareApp, defineTVEpisode, defineTVSeason, defineTVSeries, defineVideo, defineVirtualLocation, defineWebPage, defineWebSite, schemaOrgAutoImports, schemaOrgComponents, useSchemaOrg };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUlBLFNBQVMsd0JBQXdCLFFBQVE7Q0FDdkMsT0FBTztBQUNUO0FBRUEsSUFBTSxjQUFjO0FBQ3BCLElBQU0sd0JBQXdCO0FBQzlCLFNBQVMsWUFBWSxPQUFPO0NBQzFCLE9BQU8sWUFBWSxLQUFLLEtBQUs7QUFDL0I7QUFDQSxTQUFTLHFCQUFxQixRQUFRLElBQUk7Q0FDeEMsUUFBUSxNQUFNLFNBQVMsR0FBRyxJQUFJLE1BQU0sTUFBTSxHQUFHLEVBQUUsSUFBSSxVQUFVO0FBQy9EO0FBQ0EsU0FBUyxrQkFBa0IsUUFBUSxJQUFJO0NBQ3JDLE9BQU8sTUFBTSxTQUFTLEdBQUcsSUFBSSxRQUFRLEdBQUcsTUFBTTtBQUNoRDtBQUNBLFNBQVMsUUFBUSxNQUFNLE9BQU87Q0FDNUIsSUFBSSxDQUFDLFNBQVMsVUFBVSxLQUN0QixPQUFPLFFBQVE7Q0FDakIsT0FBTyxPQUFPLGtCQUFrQixJQUFJLElBQUksTUFBTSxRQUFRLHVCQUF1QixFQUFFLElBQUk7QUFDckY7QUFDQSxTQUFTLFNBQVMsT0FBTyxNQUFNO0NBQzdCLElBQUksQ0FBQyxRQUFRLFNBQVMsT0FBTyxZQUFZLEtBQUssR0FDNUMsT0FBTztDQUNULE1BQU0saUJBQWlCLHFCQUFxQixJQUFJO0NBQ2hELElBQUksTUFBTSxXQUFXLGNBQWMsR0FBRztFQUNwQyxNQUFNLFdBQVcsTUFBTSxlQUFlO0VBQ3RDLElBQUksQ0FBQyxZQUFZLGFBQWEsT0FBTyxhQUFhLEtBQ2hELE9BQU87Q0FDWDtDQUNBLE9BQU8sUUFBUSxnQkFBZ0IsS0FBSztBQUN0QztBQUNBLFNBQVMsWUFBWSxNQUFNO0NBQ3pCLE9BQU8sRUFDTCxPQUFPLE9BQU8sU0FBUyxXQUFXLEtBQUssU0FBUyxLQUNsRDtBQUNGO0FBQ0EsU0FBUyxxQkFBcUIsS0FBSztDQUNqQyxJQUFJO0VBQ0YsTUFBTSxPQUFPLGVBQWUsT0FBTyxNQUFNLElBQUksS0FBSyxLQUFLLE1BQU0sR0FBRyxDQUFDO0VBQ2pFLE1BQU0sUUFBUSxPQUFPLEtBQUssU0FBUyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0VBQ3pELE1BQU0sTUFBTSxPQUFPLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRztFQUNsRCxPQUFPLEdBQUcsS0FBSyxZQUFZLEVBQUUsR0FBRyxNQUFNLEdBQUc7Q0FDM0MsUUFBUSxDQUNSO0NBQ0EsT0FBTyxPQUFPLFFBQVEsV0FBVyxNQUFNLElBQUksU0FBUztBQUN0RDtBQUNBLElBQU0sb0JBQW9CO0NBQ3hCO0NBQ0E7Q0FDQTtDQUNBO0FBQ0Y7QUFDQSxTQUFTLGVBQWUsR0FBRztDQUN6QixPQUFPLGtCQUFrQixNQUFNLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztBQUNoRDtBQUNBLFNBQVMsb0JBQW9CLEtBQUs7Q0FDaEMsSUFBSSxDQUFDLEtBQ0gsT0FBTztDQUNULElBQUk7RUFDRixJQUFJLGVBQWUsTUFDakIsT0FBTyxJQUFJLFlBQVk7T0FDcEIsSUFBSSxlQUFlLEdBQUcsR0FDekIsT0FBTztPQUVQLE9BQU8sSUFBSSxLQUFLLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFlBQVk7Q0FDakQsUUFBUSxDQUNSO0NBQ0EsT0FBTyxPQUFPLFFBQVEsV0FBVyxNQUFNLElBQUksU0FBUztBQUN0RDtBQUNBLElBQU0sYUFBYTtBQUNuQixTQUFTLFdBQVcsTUFBTSxPQUFPLE9BQU87Q0FDdEMsSUFBSSxPQUFPLFdBQVcsS0FBSyxLQUFLLFNBQVMsTUFDdkMsS0FBSyxTQUFTO0FBQ2xCO0FBQ0EsU0FBUyxRQUFRLE9BQU87Q0FDdEIsT0FBTyxNQUFNLFFBQVEsS0FBSyxJQUFJLFFBQVEsQ0FBQyxLQUFLO0FBQzlDO0FBQ0EsU0FBUyxZQUFZLE1BQU0sT0FBTyxPQUFPO0NBQ3ZDLE1BQU0sT0FBTyxJQUFJLElBQUksUUFBUSxLQUFLLE1BQU0sQ0FBQztDQUN6QyxLQUFLLElBQUksS0FBSztDQUNkLEtBQUssU0FBUyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsT0FBTyxPQUFPO0FBQ3hDO0FBQ0EsU0FBUyxTQUFTLEtBQUssSUFBSTtDQUN6QixJQUFJLFlBQVksRUFBRSxHQUNoQixPQUFPO0NBQ1QsSUFBSSxDQUFDLEdBQUcsU0FBUyxHQUFHLEdBQ2xCLEtBQUssSUFBSTtDQUNYLE9BQU8sR0FBRyxPQUFPLEtBQUs7QUFDeEI7QUFDQSxTQUFTLFdBQVcsS0FBSyxRQUFRO0NBQy9CLElBQUksQ0FBQyxLQUNILE9BQU87Q0FDVCxJQUFJLElBQUksU0FBUyxRQUFRO0VBQ3ZCLE1BQU0sZ0JBQWdCLElBQUksVUFBVSxHQUFHLE1BQU07RUFDN0MsT0FBTyxjQUFjLFVBQVUsR0FBRyxLQUFLLElBQUksY0FBYyxRQUFRLGNBQWMsWUFBWSxHQUFHLENBQUMsQ0FBQztDQUNsRztDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsbUJBQW1CLE1BQU0sYUFBYTtDQUM3QyxNQUFNLE1BQU0sS0FBSztDQUNqQixJQUFJLFFBQVEsYUFDVjtDQUNGLElBQUksT0FBTyxRQUFRLFlBQVksT0FBTyxnQkFBZ0IsVUFBVTtFQUM5RCxJQUFJLFFBQVEsYUFDVixLQUFLLFdBQVcsQ0FBQyxhQUFhLEdBQUc7RUFDbkM7Q0FDRjtDQUNBLE1BQU0sUUFBUSxJQUFJLElBQUksUUFBUSxXQUFXLENBQUM7Q0FDMUMsS0FBSyxNQUFNLEtBQUssUUFBUSxHQUFHLEdBQ3pCLE1BQU0sSUFBSSxDQUFDO0NBQ2IsS0FBSyxXQUFXLE1BQU0sU0FBUyxJQUFJLE1BQU0sQ0FBQyxHQUFHLEtBQUs7QUFDcEQ7QUFDQSxTQUFTLGdCQUFnQixNQUFNLFdBQVc7Q0FDeEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLFlBQVksU0FBUyxLQUFLLFVBQVUsT0FBTyxPQUFPLFVBQVUsT0FBTyxLQUM1RixPQUFPO0NBQ1QsT0FBTyxTQUFTLFdBQVcsSUFBSTtBQUNqQztBQUNBLFNBQVMsa0JBQWtCLEtBQUs7Q0FDOUIsSUFBSSxDQUFDLEtBQ0gsT0FBTztDQUNULE9BQU8sSUFBSSxVQUFVLElBQUksWUFBWSxHQUFHLENBQUM7QUFDM0M7QUFDQSxTQUFTLHFCQUFxQixLQUFLO0NBQ2pDLEtBQUssTUFBTSxLQUFLLEtBQUs7RUFDbkIsSUFBSSxDQUFDLE9BQU8sT0FBTyxLQUFLLENBQUMsR0FDdkI7RUFDRixNQUFNLElBQUksSUFBSTtFQUNkLElBQUksTUFBTSxNQUFNLE1BQU0sS0FBSyxHQUN6QixPQUFPLElBQUk7T0FDTixJQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sTUFBTTtHQUM5QyxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsV0FDeEI7R0FDRixxQkFBcUIsQ0FBQztFQUN4QjtDQUNGO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxvQkFBb0IsS0FBSztDQUNoQyxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQUc7RUFDdEIsSUFBSSxPQUFPO0VBQ1gsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLO0dBQ25DLE1BQU0sSUFBSSxJQUFJO0dBQ2QsSUFBSSxNQUFNLE1BQ1I7R0FDRixJQUFJLE9BQU8sTUFBTSxZQUFZLE1BQU0sTUFDakMsb0JBQW9CLENBQUM7R0FDdkIsSUFBSSxVQUFVO0VBQ2hCO0VBQ0EsSUFBSSxTQUFTO0VBQ2IsT0FBTztDQUNUO0NBQ0EsS0FBSyxNQUFNLEtBQUssS0FBSztFQUNuQixJQUFJLENBQUMsT0FBTyxPQUFPLEtBQUssQ0FBQyxHQUN2QjtFQUNGLE1BQU0sSUFBSSxJQUFJO0VBQ2QsSUFBSSxNQUFNLE1BQ1IsT0FBTyxJQUFJO09BQ04sSUFBSSxPQUFPLE1BQU0sVUFBVTtHQUNoQyxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsV0FDeEI7R0FDRixvQkFBb0IsQ0FBQztFQUN2QjtDQUNGO0NBQ0EsT0FBTztBQUNUO0FBRUEsU0FBUyxjQUFjLE1BQU07Q0FDM0IsT0FBTyxPQUFPLEtBQUssUUFBUTtBQUM3QjtBQUNBLElBQU0sZ0JBQWdCLHdDQUF3QjtDQUM1QyxPQUFPO0NBQ1AsS0FBSyxPQUFPO0VBQ1YsSUFBSSxPQUFPLFVBQVUsVUFDbkIsUUFBUSxFQUNOLEtBQUssTUFDUDtFQUVGLE9BQU87Q0FDVDtDQUNBLFVBQVUsRUFDUixTQUFTLGNBQ1g7Q0FDQSxhQUFhLENBRVgsWUFDRjtDQUNBLFVBQVU7Q0FDVixRQUFRLE9BQU8sRUFBRSxRQUFRO0VBQ3ZCLE1BQU0sTUFBTSxnQkFBZ0IsS0FBSyxNQUFNLE1BQU0sR0FBRztFQUNoRCxXQUFXLE9BQU8sY0FBYyxNQUFNLEdBQUc7RUFDekMsSUFBSSxNQUFNLFVBQVUsQ0FBQyxNQUFNLE9BQ3pCLE9BQU8sTUFBTTtFQUNmLElBQUksTUFBTSxTQUFTLENBQUMsTUFBTSxRQUN4QixPQUFPLE1BQU07RUFDZixPQUFPO0NBQ1Q7QUFDRixDQUFDO0FBRUQsSUFBTSxXQUFXO0FBQ2pCLFNBQVMsV0FBVyxLQUFLLE9BQU87Q0FDOUIsSUFBSSxlQUFlLFVBQVUsSUFBSSxlQUFlLFVBQVUsS0FBSztDQUMvRCxPQUFPLElBQUksZUFBZSxNQUFNLENBQUMsU0FBUztBQUM1QztBQUNBLFNBQVMsWUFBWSxNQUFNO0NBQ3pCLElBQUksQ0FBQyxLQUFLLE1BQ1IsS0FBSyxPQUFPO0NBQ2QsSUFBSSxDQUFDLEtBQUssUUFBUSxPQUFPLGFBQWEsYUFDcEMsS0FBSyxPQUFPLFNBQVMsU0FBUztDQUNoQyxJQUFJLEtBQUssU0FBUyxLQUNaO01BQUEsS0FBSyxpQkFBaUIsQ0FBQyxLQUFLLEtBQUssU0FBUyxHQUFHLEdBQy9DLEtBQUssT0FBTyxrQkFBa0IsS0FBSyxJQUFJO09BQ3BDLElBQUksQ0FBQyxLQUFLLGlCQUFpQixLQUFLLEtBQUssU0FBUyxHQUFHLEdBQ3BELEtBQUssT0FBTyxxQkFBcUIsS0FBSyxJQUFJO0NBQUE7Q0FFOUMsS0FBSyxNQUFNLFFBQVEsS0FBSyxRQUFRLElBQUksS0FBSyxJQUFJO0NBQzdDLE9BQU87QUFDVDtBQUNBLFNBQVMsWUFBWSxNQUFNLEtBQUssVUFBVTtDQUN4QyxJQUFJLFVBQVUsTUFDWixPQUFPLFNBQVMsS0FBSyxNQUFNLEdBQUc7Q0FDaEMsSUFBSSxVQUFVLFVBQVU7RUFDdEIsSUFBSSxXQUFXLFNBQVM7RUFDeEIsSUFBSSxPQUFPLGFBQWEsWUFDdEIsV0FBVyxTQUFTLEdBQUc7RUFDekIsT0FBTztHQUFFLEdBQUc7R0FBVSxHQUFHO0VBQUs7Q0FDaEM7Q0FDQSxNQUFNLGNBQWMsVUFBVTtDQUM5QixJQUFJLGFBQ0YsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFlBQVksUUFBUSxLQUFLO0VBQzNDLE1BQU0sUUFBUSxZQUFZO0VBQzFCLElBQUksT0FBTyxVQUFVLFVBQ25CLFdBQVcsTUFBTSxPQUFPLElBQUksS0FBSyxNQUFNO09BRXZDLFdBQVcsTUFBTSxNQUFNLEtBQUssSUFBSSxLQUFLLE1BQU0sS0FBSztDQUNwRDtDQUVGLElBQUksVUFBVSxTQUNaLE9BQU8sU0FBUyxRQUFRLE1BQU0sR0FBRztDQUNuQyxLQUFLLE1BQU0sS0FBSyxNQUFNO0VBQ3BCLE1BQU0sSUFBSSxLQUFLO0VBQ2YsSUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUNqQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUs7R0FDakMsTUFBTSxPQUFPLEVBQUU7R0FDZixJQUFJLE9BQU8sU0FBUyxZQUFZLE1BQU0sV0FDcEMsS0FBSyxFQUFFLENBQUMsS0FBSyxnQkFBZ0IsTUFBTSxLQUFLLEtBQUssU0FBUztFQUMxRDtPQUNLLElBQUksT0FBTyxNQUFNLFlBQVksR0FBRyxXQUNyQyxLQUFLLEtBQUssZ0JBQWdCLEdBQUcsS0FBSyxFQUFFLFNBQVM7Q0FFakQ7Q0FDQSxxQkFBcUIsSUFBSTtDQUN6QixPQUFPO0FBQ1Q7QUFDQSxTQUFTLGNBQWMsTUFBTSxLQUFLLFVBQVUsZ0JBQWdCLE9BQU87Q0FDakUsSUFBSSxLQUFLLFVBQVUsS0FBSyxNQUFNLENBQUMsV0FBVyxNQUFNLEdBQzlDLE9BQU87Q0FDVCxNQUFNLFNBQVMsWUFBWSxNQUFNLFFBQVEsU0FBUyxRQUFRLElBQUksU0FBUyxTQUFTLEtBQUssU0FBUyxhQUFhLFFBQVE7Q0FDbkgsTUFBTSxTQUFTLEtBQUssV0FBVyxXQUFXLE1BQU0sUUFBUSxTQUFTLFFBQVEsSUFBSSxTQUFTLFdBQVcsS0FBSyxLQUFLLElBQUk7Q0FDL0csSUFBSSxDQUFDLEtBQUssVUFBVSxpQkFBaUIsUUFBUTtFQUMzQyxLQUFLLFNBQVMsU0FBUyxJQUFJLEtBQUssU0FBUyxNQUFNO0VBQy9DLE9BQU87Q0FDVDtDQUNBLElBQUksS0FBSyxNQUFNLEVBQUUsV0FBVyxXQUFXLEtBQUssS0FBSyxNQUFNLEVBQUUsV0FBVyxHQUFHLEdBQUc7RUFDeEUsS0FBSyxTQUFTLFNBQVMsSUFBSSxLQUFLLFNBQVMsS0FBSyxNQUFNO0VBQ3BELE9BQU87Q0FDVDtDQUNBLElBQUksUUFBUSxVQUFVO0NBQ3RCLElBQUksQ0FBQyxPQUVILFNBRGEsUUFBUSxLQUFLLFFBQVEsQ0FBQyxHQUFHLE1BQU0sSUFDL0IsUUFBUSxVQUFVLE9BQU8sQ0FBQyxDQUFDLFlBQVk7Q0FFdEQsS0FBSyxTQUFTLFNBQVMsSUFBSSxLQUFLLFNBQVMsWUFBWSxNQUFNLEdBQUcsS0FBSyxVQUFVLFdBQVcsS0FBSyxLQUFLLEdBQUc7Q0FDckcsT0FBTztBQUNUO0FBQ0EsU0FBUyxnQkFBZ0IsT0FBTyxLQUFLLGtCQUFrQixVQUFVLENBQUMsR0FBRztDQUNuRSxJQUFJLENBQUMsT0FDSCxPQUFPO0NBQ1QsTUFBTSxRQUFRLFFBQVEsS0FBSztDQUMzQixNQUFNLE1BQU0sQ0FBQztDQUNiLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztFQUNyQyxNQUFNLElBQUksTUFBTTtFQUNoQixJQUFJLENBQUMsR0FBRztHQUNOLElBQUksS0FBSyxDQUFDO0dBQ1Y7RUFDRjtFQUNBLElBQUksV0FBVztFQUNmLEtBQUssTUFBTSxLQUFLLEdBQUc7RUFDbkIsSUFBSSxhQUFhLEtBQUssRUFBRSxVQUFVLGFBQWEsS0FBSyxFQUFFLFVBQVUsRUFBRSxVQUFVO0dBQzFFLElBQUksS0FBSyxjQUFjLEVBQ3JCLE9BQU8sSUFBSSxLQUFLLEVBQUUsTUFBTSxDQUFDLEdBQUcsVUFBVSxFQUFFLE9BQzFDLEdBQUcsR0FBRyxDQUFDO0dBQ1A7RUFDRjtFQUNBLElBQUksV0FBVztFQUNmLElBQUksRUFBRSxhQUFhLE9BQU8sRUFBRSxjQUFjLFVBQVU7R0FDbEQsV0FBVyxFQUFFO0dBQ2IsT0FBTyxFQUFFO0VBQ1g7RUFDQSxJQUFJLENBQUMsVUFBVTtHQUNiLElBQUksS0FBSyxDQUFDO0dBQ1Y7RUFDRjtFQUNBLElBQUksT0FBTyxZQUFZLEdBQUcsS0FBSyxRQUFRO0VBQ3ZDLElBQUksUUFBUSxjQUNWLFFBQVEsYUFBYSxJQUFJO0VBQzNCLElBQUksUUFBUSxjQUFjLFFBQVEsTUFDaEMsT0FBTyxjQUFjLE1BQU0sS0FBSyxVQUFVLEtBQUs7RUFDakQsSUFBSSxRQUFRLE1BQU07R0FDaEIsSUFBSSxTQUFTLGlCQUNYLFNBQVMsZ0JBQWdCLE1BQU0sR0FBRztHQUNwQyxJQUFJLEtBQUssSUFBSTtHQUNiLElBQUksS0FBSyxZQUFZLEtBQUssTUFBTSxDQUFDO0dBQ2pDO0VBQ0Y7RUFDQSxJQUFJLEtBQUssSUFBSTtDQUNmO0NBQ0EsT0FBTyxDQUFDLFFBQVEsU0FBUyxJQUFJLFdBQVcsSUFBSSxJQUFJLEtBQUs7QUFDdkQ7QUFFQSxTQUFTLE1BQU0sUUFBUSxRQUFRO0NBQzdCLElBQUksQ0FBQyxRQUNILE9BQU87Q0FDVCxLQUFLLE1BQU0sT0FBTyxRQUFRO0VBQ3hCLElBQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxHQUFHLEtBQUssUUFBUSxlQUFlLFFBQVEsaUJBQWlCLFFBQVEsYUFDekY7RUFDRixNQUFNLFFBQVEsT0FBTztFQUNyQixJQUFJLFVBQVUsS0FBSyxHQUNqQjtFQUNGLElBQUksTUFBTSxRQUFRLE9BQU8sSUFBSSxHQUMzQixJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQUc7R0FDeEIsTUFBTSxTQUFTLENBQUMsR0FBRyxPQUFPLE1BQU0sR0FBRyxLQUFLO0dBQ3hDLElBQUksUUFBUSxTQUNWLE9BQU8sT0FBTyxDQUFDLEdBQUcsSUFBSSxJQUFJLE1BQU0sQ0FBQztRQUM1QixJQUFJLFFBQVEsbUJBQW1CO0lBQ3BDLE9BQU8sTUFBTSxHQUFHLE9BQU8sRUFBRSxZQUFZLE1BQU0sRUFBRSxZQUFZLEVBQUU7SUFDM0QsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxLQUNqQyxPQUFPLEVBQUUsQ0FBQyxXQUFXLElBQUk7SUFDM0IsT0FBTyxPQUFPO0dBQ2hCLE9BQU8sSUFBSSxRQUFRLG1CQUFtQjtJQUNwQyxNQUFNLFNBQXlCLHVCQUFPLE9BQU8sSUFBSTtJQUNqRCxLQUFLLE1BQU0sVUFBVSxRQUFRO0tBQzNCLE1BQU0sT0FBTyxPQUFPO0tBQ3BCLElBQUksT0FBTyxPQUNMO1VBQUEsT0FBTyxVQUFVLE9BQU8sS0FBSyxDQUFDLFFBQVE7T0FDeEMsTUFBTSxJQUFJLE1BQU0sUUFBUSxPQUFPLEtBQUssQ0FBQyxNQUFNLElBQUksT0FBTyxLQUFLLENBQUMsU0FBUyxDQUFDLE9BQU8sS0FBSyxDQUFDLE1BQU07T0FDekYsTUFBTSxJQUFJLE1BQU0sUUFBUSxPQUFPLE1BQU0sSUFBSSxPQUFPLFNBQVMsQ0FBQyxPQUFPLE1BQU07T0FDdkUsT0FBTyxLQUFLLENBQUMsU0FBUyxDQUFDLG1CQUFtQixJQUFJLElBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztNQUNqRTtZQUVBLE9BQU8sUUFBUSxFQUFFLEdBQUcsT0FBTztJQUUvQjtJQUNBLE9BQU8sT0FBTyxPQUFPLE9BQU8sTUFBTTtHQUNwQyxPQUlFLElBSHdCLE9BQU8sU0FBUyxLQUFLLE9BQU8sT0FDakQsU0FBUyxRQUFRLE9BQU8sU0FBUyxZQUFZLEtBQUssUUFDckQsR0FDcUI7SUFDbkIsTUFBTSxTQUF5Qix1QkFBTyxPQUFPLElBQUk7SUFDakQsS0FBSyxNQUFNLFFBQVEsUUFDakIsT0FBTyxLQUFLLFlBQVk7SUFDMUIsT0FBTyxPQUFPLE9BQU8sT0FBTyxNQUFNO0dBQ3BDLE9BQ0UsT0FBTyxPQUFPO0VBR3BCLE9BQ0UsT0FBTyxPQUFPLE1BQU0sT0FBTyxNQUFNLENBQUMsS0FBSyxDQUFDO09BRXJDLElBQUksT0FBTyxRQUFRLE9BQU8sT0FBTyxTQUFTLFlBQVksT0FBTyxVQUFVLFlBQVksQ0FBQyxNQUFNLFFBQVEsS0FBSyxHQUM1RyxPQUFPLE9BQU8sTUFBTSxFQUFFLEdBQUcsT0FBTyxLQUFLLEdBQUcsS0FBSztPQUU3QyxPQUFPLE9BQU87Q0FFbEI7Q0FDQSxPQUFPO0FBQ1Q7QUFFQSxJQUFNLFlBQVk7QUFDbEIsU0FBUyxVQUFVLE9BQU8sTUFBTTtDQUM5QixJQUFJLENBQUMsS0FBSyxRQUNSO0NBQ0YsTUFBTSxTQUFTLEtBQUs7Q0FDcEIsTUFBTSxjQUFjLGtCQUFrQixNQUFNO0NBQzVDLE1BQU0sSUFBSSxhQUFhLElBQUk7Q0FDM0IsTUFBTSxJQUFJLFFBQVEsSUFBSTtDQUN0QixNQUFNLFlBQVksT0FBTyxRQUFRLFdBQVcsRUFBRSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztDQUMzRCxNQUFNLElBQUksV0FBVyxJQUFJO0FBQzNCO0FBQ0EsU0FBUyx1QkFBdUI7Q0FDOUIsSUFBSTtDQUNKLFNBQVMsS0FBSyxJQUFJLE9BQU87RUFDdkIsTUFBTSxnQkFBZ0IsR0FBRyxPQUFPO0VBQ2hDLE1BQU0sY0FBYyxHQUFHLE9BQU8sT0FBTyxHQUFHLE9BQU87RUFDL0MsTUFBTSxNQUFNLGdCQUFnQixrQkFBa0IsRUFBRSxJQUFJLGNBQWMsR0FBRyxRQUFRLFdBQVcsRUFBRSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLO0VBQzVHLElBQUksT0FBTyxJQUFJLFVBQVUsT0FBTyxJQUFJLElBQUksVUFBVSxJQUFJLEdBQUcsSUFBSSxLQUFLO0VBQ2xFLElBQUksQ0FBQyxNQUNILEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLE1BQU0sUUFBUSxLQUFLO0dBQ3pDLE1BQU0sWUFBWSxJQUFJLE1BQU07R0FDNUIsTUFBTSxTQUFTLFVBQVU7R0FDekIsSUFBSSxDQUFDLFFBQ0g7R0FFRixLQURnQixnQkFBZ0Isa0JBQWtCLE1BQU0sSUFBSSxjQUFjLE9BQU8sUUFBUSxXQUFXLEVBQUUsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsS0FBSyxZQUN4RyxLQUFLO0lBQ25CLE9BQU87SUFDUDtHQUNGO0VBQ0Y7RUFFRixJQUFJLENBQUMsUUFBUSxTQUFTLENBQUMsTUFBTSxJQUFJLEdBQy9CLE9BQU87RUFDVCxPQUFPO0NBQ1Q7Q0FDQSxNQUFNO0VBQ0o7RUFDQSxLQUFLLE9BQU87R0FDVixJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQ3JCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztJQUNyQyxNQUFNLGlCQUFpQixNQUFNO0lBQzdCLElBQUksTUFBTSxLQUFLLGNBQWM7SUFDN0IsSUFBSSxJQUFJLFVBQVUsT0FBTyxHQUN2QixVQUFVLElBQUksV0FBVyxjQUFjO0dBQzNDO1FBQ0s7SUFDTCxNQUFNLGlCQUFpQjtJQUN2QixJQUFJLE1BQU0sS0FBSyxjQUFjO0lBQzdCLElBQUksSUFBSSxVQUFVLE9BQU8sR0FDdkIsVUFBVSxJQUFJLFdBQVcsY0FBYztHQUMzQztFQUNGO0VBQ0EsYUFBYSxNQUFNO0dBQ2pCLEtBQUssTUFBTSxLQUFLLElBQUksZ0JBQWdCLE9BQU8sSUFBSSxlQUFlO0dBQzlELElBQUksT0FBTyxZQUFZLEVBQUUsR0FBRyxLQUFLLENBQUM7R0FDbEMsTUFBTSxNQUFNLElBQUksTUFBTTtHQUN0QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxLQUFLO0lBQzVCLElBQUksT0FBTyxJQUFJLE1BQU07SUFDckIsTUFBTSxXQUFXLEtBQUs7SUFDdEIsT0FBTyxZQUFZLE1BQU0sS0FBSyxRQUFRO0lBQ3RDLE9BQU8sY0FBYyxNQUFNLEtBQUssVUFBVSxJQUFJO0lBQzlDLElBQUksTUFBTSxLQUFLO0dBQ2pCO0dBQ0EsTUFBTSxlQUErQix1QkFBTyxPQUFPLElBQUk7R0FDdkQsSUFBSSxnQkFBZ0I7R0FDcEIsSUFBSSxVQUFVLE1BQU07R0FDcEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksTUFBTSxRQUFRLEtBQUs7SUFDekMsTUFBTSxJQUFJLElBQUksTUFBTTtJQUNwQixNQUFNLFVBQVUsa0JBQWtCLEVBQUUsTUFBTTtJQUMxQyxJQUFJLGFBQWEsVUFBVTtLQUN6QixnQkFBZ0I7S0FDaEIsSUFBSSxFQUFFLG9CQUFvQixXQUN4QixhQUFhLFdBQVcsTUFBTSxhQUFhLFVBQVUsQ0FBQztVQUV0RCxhQUFhLFdBQVc7SUFDNUIsT0FDRSxhQUFhLFdBQVc7R0FFNUI7R0FDQSxJQUFJLGVBQ0YsSUFBSSxRQUFRLE9BQU8sT0FBTyxZQUFZO0dBQ3hDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLE1BQU0sUUFBUSxLQUNwQyxVQUFVLElBQUksV0FBVyxJQUFJLE1BQU0sRUFBRTtHQUN2QyxNQUFNLHVCQUF1QixJQUFJLE1BQU07R0FDdkMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksTUFBTSxRQUFRLEtBQUs7SUFDekMsTUFBTSxPQUFPLElBQUksTUFBTTtJQUN2QixJQUFJLEtBQUssU0FBUyxPQUFPLEtBQUssVUFBVSxVQUN0QyxLQUFLLFFBQVEsZ0JBQWdCLEtBQUssT0FBTyxLQUFLLGVBQWUsRUFDM0QsTUFBTSxLQUNSLENBQUM7SUFFSCxLQUFLLG9CQUFvQixnQkFBZ0IsS0FBSyxtQkFBbUIsR0FBRztJQUNwRSxLQUFLLGtCQUFrQixnQkFBZ0IsS0FBSyxpQkFBaUIsR0FBRztJQUNoRSxNQUFNLFdBQVcsS0FBSztJQUN0QixJQUFJLFVBQVUsaUJBQ1osU0FBUyxnQkFBZ0IsTUFBTSxHQUFHO0dBQ3RDO0dBQ0EsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksTUFBTSxRQUFRLEtBQ3BDLE9BQU8sSUFBSSxNQUFNLEVBQUUsQ0FBQztHQUN0QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxNQUFNLFFBQVEsS0FDcEMsb0JBQW9CLElBQUksTUFBTSxFQUFFO0dBQ2xDLE1BQU0sY0FBYyxJQUFJLE1BQU0sU0FBUztHQUN2QyxNQUFNLGtCQUFrQixjQUE4Qix1QkFBTyxPQUFPLElBQUksSUFBSTtHQUM1RSxNQUFNLFNBQVMsY0FBYyxPQUFPLENBQUM7R0FDckMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksTUFBTSxRQUFRLEtBQUs7SUFDekMsTUFBTSxJQUFJLElBQUksTUFBTTtJQUNwQixNQUFNLFVBQVUsa0JBQWtCLEVBQUUsTUFBTTtJQUMxQyxNQUFNLE9BQU8sT0FBTyxLQUFLLENBQUM7SUFDMUIsS0FBSyxLQUFLO0lBQ1YsTUFBTSxVQUFVLENBQUM7SUFDakIsSUFBSSxnQkFBZ0I7SUFDcEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLO0tBQ3BDLE1BQU0sSUFBSSxLQUFLO0tBQ2YsSUFBSSxFQUFFLE9BQU8sS0FDWDtLQUNGLE1BQU0sSUFBSSxFQUFFO0tBQ1osSUFBSSxNQUFNLFNBQVMsTUFBTSxRQUFRLENBQUMsS0FBSyxPQUFPLE1BQU0sV0FDbEQsS0FBSyxtQkFBbUI7VUFFeEIsUUFBUSxLQUFLO0lBQ2pCO0lBQ0EsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGVBQWUsS0FBSztLQUN0QyxNQUFNLElBQUksS0FBSztLQUNmLFFBQVEsS0FBSyxFQUFFO0lBQ2pCO0lBQ0EsSUFBSSxhQUNGLGdCQUFnQixXQUFXLGdCQUFnQixXQUFXLE1BQU0sZ0JBQWdCLFVBQVUsT0FBTyxJQUFJO1NBRWpHLE9BQU8sS0FBSyxPQUFPO0dBRXZCO0dBQ0EsT0FBTyxjQUFjLE9BQU8sT0FBTyxlQUFlLElBQUk7RUFDeEQ7RUFDQSxPQUFPLENBQUM7RUFDUiwyQkFBMkIsSUFBSSxJQUFJO0VBQ25DLGdCQUFnQyx1QkFBTyxPQUFPLElBQUk7RUFDbEQsTUFBTSxZQUFZLENBQUMsQ0FBQztDQUN0QjtDQUNBLE9BQU87QUFDVDtBQUVBLElBQU0sNEJBQTRCLHdDQUF3QjtDQUN4RCxLQUFLLE1BQU07RUFDVCxJQUFJLE9BQU8sU0FBUyxVQUNsQixPQUFPLEVBQ0wsT0FBTyxLQUNUO0VBRUYsT0FBTztDQUNUO0NBQ0EsVUFBVSxFQUNSLFNBQVMsb0JBQ1g7QUFDRixDQUFDO0FBQ0QsSUFBTSx5QkFBeUIsd0NBQXdCO0NBQ3JELFVBQVUsRUFDUixTQUFTLGlCQUNYO0NBQ0EsUUFBUSxNQUFNLEtBQUs7RUFDakIsSUFBSSxPQUFPLEtBQUssVUFBVSxVQUN4QixLQUFLLFFBQVEsZ0JBQWdCLEtBQUssT0FBTyxLQUFLLHlCQUF5QjtFQUN6RSxPQUFPO0NBQ1Q7QUFDRixDQUFDO0FBRUQsSUFBTSwrQkFBK0Isd0NBQXdCO0NBQzNELFVBQVUsRUFDUixTQUFTLHVCQUNYO0NBQ0EsUUFBUSxNQUFNLEtBQUs7RUFDakIsSUFBSSxLQUFLLHNCQUNQLEtBQUssdUJBQXVCLFNBQVMsS0FBSyxzQkFBc0IscUJBQXFCO0VBQ3ZGLElBQUksS0FBSyxZQUNQLEtBQUssYUFBYSxTQUFTLEtBQUssWUFBWSxxQkFBcUI7RUFDbkUsSUFBSSxLQUFLLGNBQ1AsS0FBSyxlQUFlLFNBQVMsS0FBSyxjQUFjLHFCQUFxQjtFQUN2RSxLQUFLLDJCQUEyQixnQkFBZ0IsS0FBSywwQkFBMEIsS0FBSyxzQkFBc0I7RUFDMUcsT0FBTztDQUNUO0FBQ0YsQ0FBQztBQUVELElBQU0sd0JBQXdCLHdDQUF3QixFQUNwRCxVQUFVLEVBQ1IsU0FBUyxnQkFDWCxFQUNGLENBQUM7QUFFRCxJQUFNLCtCQUErQix3Q0FBd0I7Q0FDM0QsVUFBVSxFQUNSLFNBQVMsdUJBQ1g7Q0FDQSxRQUFRLE1BQU0sS0FBSztFQUNqQixLQUFLLGVBQWUsZ0JBQWdCLEtBQUssY0FBYyxLQUFLLHlCQUF5QjtFQUNyRixLQUFLLGNBQWMsZ0JBQWdCLEtBQUssYUFBYSxLQUFLLHlCQUF5QjtFQUNuRixPQUFPO0NBQ1Q7QUFDRixDQUFDO0FBRUQsSUFBTSwrQkFBK0Isd0NBQXdCO0NBQzNELFVBQVUsRUFDUixTQUFTLHVCQUNYO0NBQ0EsUUFBUSxNQUFNLEtBQUs7RUFDakIsS0FBSyxlQUFlLGdCQUFnQixLQUFLLGNBQWMsS0FBSyw0QkFBNEI7RUFDeEYsS0FBSyxzQkFBc0IsZ0JBQWdCLEtBQUsscUJBQXFCLEtBQUsscUJBQXFCO0VBQy9GLEtBQUssZUFBZSxnQkFBZ0IsS0FBSyxjQUFjLEtBQUssc0JBQXNCO0VBQ2xGLE9BQU87Q0FDVDtBQUNGLENBQUM7QUFFRCxJQUFNLGdCQUFnQix3Q0FBd0I7Q0FDNUMsS0FBSyxNQUFNO0VBQ1QsSUFBSSxPQUFPLFNBQVMsWUFBWSxPQUFPLFNBQVMsVUFDOUMsT0FBTyxFQUNMLE9BQU8sS0FDVDtFQUVGLE9BQU87Q0FDVDtDQUNBLFVBQVU7RUFDUixTQUFTO0VBQ1QsZ0JBQWdCO0NBQ2xCO0NBQ0EsUUFBUSxNQUFNLEtBQUs7RUFDakIsV0FBVyxNQUFNLGlCQUFpQixJQUFJLEtBQUssUUFBUTtFQUNuRCxXQUFXLE1BQU0sbUJBQW1CLElBQUksS0FBSyxLQUFLLHFCQUFxQixJQUFJLEtBQUssR0FBRyxZQUFZLElBQUksR0FBRyxJQUFJLElBQUksR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDO0VBQ3ZILElBQUksS0FBSyxLQUNQLGdCQUFnQixJQUFJLEtBQUssTUFBTSxLQUFLLEdBQUc7RUFDekMsSUFBSSxLQUFLLGNBQ1AsS0FBSyxlQUFlLFNBQVMsS0FBSyxjQUFjLHFCQUFxQjtFQUN2RSxJQUFJLEtBQUssZUFDUCxLQUFLLGdCQUFnQixTQUFTLEtBQUssZUFBZSxxQkFBcUI7RUFDekUsSUFBSSxLQUFLLGlCQUNQLEtBQUssa0JBQWtCLG9CQUFvQixLQUFLLGVBQWU7RUFDakUsS0FBSywwQkFBMEIsZ0JBQWdCLEtBQUsseUJBQXlCLEtBQUssNEJBQTRCO0VBQzlHLEtBQUssa0JBQWtCLGdCQUFnQixLQUFLLGlCQUFpQixLQUFLLDRCQUE0QjtFQUM5RixPQUFPO0NBQ1Q7QUFDRixDQUFDO0FBRUQsSUFBTSx5QkFBeUIsd0NBQXdCO0NBQ3JELFVBQVUsRUFDUixTQUFTLGlCQUNYO0NBQ0EsYUFBYSxDQUNYO0VBQUUsTUFBTTtFQUFZLEtBQUs7Q0FBZ0IsQ0FDM0M7Q0FDQSxRQUFRLE1BQU0sS0FBSztFQUNqQixLQUFLLFNBQVMsZ0JBQWdCLEtBQUssUUFBUSxLQUFLLGFBQWE7RUFDN0QsSUFBSSxLQUFLLFFBQ1AsV0FBVyxNQUFNLGNBQWMsUUFBUSxLQUFLLE1BQU0sQ0FBQyxDQUFDLE1BQU07RUFDNUQsT0FBTztDQUNUO0FBQ0YsQ0FBQztBQUVELElBQU0sMEJBQTBCLHdDQUF3QixFQUN0RCxVQUFVLEVBQ1IsU0FBUyxrQkFDWCxFQUNGLENBQUM7QUFFRCxJQUFNLG1CQUFtQix3Q0FBd0I7Q0FDL0MsS0FBSyxNQUFNO0VBQ1QsSUFBSSxPQUFPLFNBQVMsVUFDbEIsT0FBTyxFQUNMLE1BQU0sS0FDUjtFQUVGLE9BQU87Q0FDVDtDQUNBLFVBQVUsRUFDUixTQUFTLFdBQ1g7Q0FDQSxRQUFRLE1BQU0sS0FBSztFQUNqQixJQUFJLE9BQU8sS0FBSyxTQUFTLFVBQ3ZCLEtBQUssT0FBTyxnQkFBZ0IsSUFBSSxLQUFLLE1BQU0sS0FBSyxJQUFJO09BQ2pELElBQUksT0FBTyxLQUFLLFNBQVMsVUFDNUIsS0FBSyxPQUFPLGdCQUFnQixLQUFLLE1BQU0sR0FBRztFQUM1QyxPQUFPO0NBQ1Q7QUFDRixDQUFDO0FBRUQsSUFBTSxzQkFBc0I7QUFDNUIsSUFBTSxxQkFBcUIsd0NBQXdCO0NBQ2pELFVBQVUsRUFDUixTQUFTLGlCQUNYO0NBQ0EsVUFBVSxDQUFDLE9BQU8sbUJBQW1CO0NBQ3JDLFFBQVEsWUFBWSxLQUFLO0VBQ3ZCLElBQUksV0FBVyxpQkFBaUI7R0FDOUIsSUFBSSxRQUFRO0dBQ1osV0FBVyxrQkFBa0IsZ0JBQWdCLFdBQVcsaUJBQWlCLEtBQUssa0JBQWtCO0lBQzlGLE9BQU87SUFDUCxhQUFhLE1BQU07S0FDakIsV0FBVyxNQUFNLFlBQVksT0FBTztJQUN0QztHQUNGLENBQUM7RUFDSDtFQUNBLE9BQU87Q0FDVDtDQUNBLGdCQUFnQixNQUFNLEVBQUUsUUFBUTtFQUM5QixNQUFNLFVBQVUsS0FBSyxnQkFBZ0I7RUFDckMsSUFBSSxTQUNGLFdBQVcsU0FBUyxjQUFjLFlBQVksSUFBSSxDQUFDO0NBQ3ZEO0FBQ0YsQ0FBQztBQUVELElBQU0sa0JBQWtCLHdDQUF3QixFQUM5QyxVQUFVLEVBQ1IsU0FBUyxnQkFDWCxFQUNGLENBQUM7QUFFRCxJQUFNLHVCQUF1Qix3Q0FBd0I7Q0FDbkQsVUFBVTtFQUNSLFNBQVM7RUFDVCxVQUFVLEVBQ1IsU0FBUyxhQUNYO0VBQ0EsZUFBZTtHQUNiLFNBQVM7R0FDVCxpQkFBaUI7R0FDakIsYUFBYTtFQUNmO0NBQ0Y7Q0FDQSxRQUFRLE1BQU0sS0FBSztFQUNqQixJQUFJLE9BQU8sS0FBSyxXQUFXLFVBQ3pCLEtBQUssU0FBUztHQUNaLFNBQVM7R0FDVCxlQUFlLGdCQUFnQixJQUFJLEtBQUssTUFBTSxLQUFLLE1BQU07RUFDM0Q7RUFFRixPQUFPO0NBQ1Q7QUFDRixDQUFDO0FBRUQsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxrQkFBa0Isd0NBQXdCO0NBQzlDLFVBQVUsRUFDUixTQUFTLFVBQ1g7Q0FDQSxhQUFhLENBQ1gsY0FDQTtFQUFFLE1BQU07RUFBUSxLQUFLO0NBQU0sQ0FDN0I7Q0FDQSxVQUFVLENBQUMsUUFBUSxnQkFBZ0I7Q0FDbkMsUUFBUSxNQUFNLEtBQUs7RUFDakIsS0FBSyxrQkFBa0IsZ0JBQWdCLEtBQUssaUJBQWlCLEtBQUssc0JBQXNCLEVBQ3RGLE9BQU8sS0FDVCxDQUFDO0VBQ0QsS0FBSyxZQUFZLGdCQUFnQixLQUFLLFdBQVcsR0FBRztFQUNwRCxLQUFLLGVBQWUsb0JBQW9CLEtBQUssWUFBWTtFQUN6RCxLQUFLLGdCQUFnQixvQkFBb0IsS0FBSyxhQUFhO0VBQzNELE9BQU87Q0FDVDtDQUNBLGdCQUFnQixNQUFNLEVBQUUsUUFBUTtFQUM5QixJQUFJLGtCQUFrQixLQUFLLE1BQU0sa0JBQXdCO0dBQ3ZELE1BQU0sV0FBVyxLQUFLLFVBQVU7R0FDaEMsSUFBSSxVQUNGLFdBQVcsTUFBTSxhQUFhLFlBQVksUUFBUSxDQUFDO0dBQ3JELE1BQU0sVUFBVSxLQUFLLGdCQUFnQjtHQUNyQyxJQUFJLFNBQ0YsV0FBVyxTQUFTLFlBQVksWUFBWSxJQUFJLENBQUM7RUFDckQ7RUFDQSxPQUFPO0NBQ1Q7QUFDRixDQUFDO0FBRUQsSUFBTSx1QkFBdUIsd0NBQXdCO0NBQ25ELEtBQUssTUFBTTtFQUNULElBQUksT0FBTyxTQUFTLFVBQ2xCLE9BQU8sRUFDTCxNQUFNLEtBQ1I7RUFFRixPQUFPO0NBQ1Q7Q0FDQSxVQUFVLEVBQ1IsU0FBUyxlQUNYO0NBQ0EsVUFBVSxDQUFDLFFBQVEsVUFBVTtDQUM3QixhQUFhLENBQ1g7RUFBRSxNQUFNO0VBQVEsS0FBSztDQUFNLENBQzdCO0NBQ0EsUUFBUSxNQUFNLEtBQUs7RUFDakIsbUJBQW1CLE1BQU0sY0FBYztFQUN2QyxLQUFLLFVBQVUsZ0JBQWdCLEtBQUssU0FBUyxLQUFLLGVBQWU7RUFDakUsT0FBTztDQUNUO0NBQ0EsZ0JBQWdCLE1BQU0sS0FBSztFQUN6QixNQUFNLGFBQWEsa0JBQWtCLEtBQUssTUFBTSxNQUFNO0VBQ3RELE1BQU0sVUFBVSxJQUFJLEtBQUssZ0JBQWdCO0VBQ3pDLElBQUksS0FBSyxRQUFRLFlBQVk7R0FFM0IsTUFBTSxXQUFXLGdCQURDLE1BQU0sUUFBUSxLQUFLLElBQUksSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLE1BQ3JCLEtBQUssZUFBZTtJQUM5RCxNQUFNO0lBQ04sYUFBYSxNQUFNO0tBQ2pCLEtBQUssU0FBUyxTQUFTLElBQUksS0FBSyxNQUFNLE9BQU87S0FDN0MsV0FBVyxNQUFNLFdBQVcsS0FBSyxJQUFJO0lBQ3ZDO0dBQ0YsQ0FBQztHQUNELElBQUksV0FBVyxVQUNiLFdBQVcsU0FBUyxzQkFBc0IsWUFBWSxRQUFRLENBQUM7R0FDakUsSUFBSSxLQUFLLGFBQWEsZ0JBQ3BCLEtBQUssT0FBTztRQUNQLElBQUksQ0FBQyxJQUFJLEtBQUssZUFBZSxHQUFHO0lBQ3JDLE1BQU0sZUFBZSxZQUFZLE9BQU8sYUFBYSxZQUFZLFNBQVMsU0FBUyxJQUFJLEtBQUssU0FBUyxRQUFRLGFBQWEsSUFBSTtJQUM5SCxJQUFJLE1BQU0sS0FBSztLQUdiLFNBQVM7S0FDVCxRQUFRLEtBQUs7S0FDYixPQUFPLEtBQUs7S0FDWixVQUFVLEtBQUs7S0FFZixXQUFXLEtBQUs7S0FFaEIsUUFBUSxjQUFjO0tBQ3RCLGFBQWE7S0FDYixPQUFPLFNBQVMsSUFBSSxLQUFLLE1BQU0sZUFBZTtJQUVoRCxDQUFDO0dBQ0g7R0FDQSxJQUFJLEtBQUssYUFBYSxnQkFDcEIsT0FBTyxLQUFLO0VBQ2hCO0VBQ0EsSUFBSSxjQUFjLFNBQ2hCLFdBQVcsU0FBUyxTQUFTLFlBQVksSUFBSSxDQUFDO0VBQ2hELE1BQU0sVUFBVSxJQUFJLEtBQUssZ0JBQWdCO0VBQ3pDLElBQUksU0FDRixXQUFXLFNBQVMsYUFBYSxZQUFZLElBQUksQ0FBQztDQUN0RDtBQUNGLENBQUM7QUFFRCxJQUFNLHFCQUFxQix3Q0FBd0I7Q0FDakQsVUFBVSxFQUNSLFNBQVMsYUFDWDtDQUNBLFFBQVEsTUFBTSxLQUFLO0VBQ2pCLEtBQUssV0FBVyxDQUFDO0VBQ2pCLElBQUksQ0FBQyxLQUFLLE9BQU8sU0FBUyxJQUFJLEtBQUssR0FBRyxHQUNwQyxLQUFLLE9BQU8sUUFBUSxJQUFJLEtBQUssR0FBRztFQUNsQyxPQUFPO0NBQ1Q7QUFDRixDQUFDO0FBRUQsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxrQkFBa0Isd0NBQXdCO0NBQzlDLFNBQVMsRUFBRSxRQUFRO0VBQ2pCLE1BQU0sVUFBVSxxQkFBcUIsS0FBSyxJQUFJLFVBQVUsS0FBSyxJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsQ0FBQztFQUN0RixJQUFJLE9BQU87RUFDWCxRQUFRLFNBQVI7R0FDRSxLQUFLO0dBQ0wsS0FBSztJQUNILE9BQU87SUFDUDtHQUNGLEtBQUs7SUFDSCxPQUFPO0lBQ1A7R0FDRixLQUFLO0lBQ0gsT0FBTztJQUNQO0dBQ0YsS0FBSztHQUNMLEtBQUs7R0FDTCxLQUFLO0lBQ0gsT0FBTztJQUNQO0dBQ0YsS0FBSyxPQUNILE9BQU87RUFFWDtFQUlBLE9BQU8sRUFGTCxTQUFTLEtBRUc7Q0FDaEI7Q0FDQSxVQUFVLENBQUMsT0FBTyxnQkFBZ0I7Q0FDbEMsYUFBYTtFQUNYO0dBQUUsTUFBTTtHQUFTLEtBQUs7RUFBTztFQUM3QjtFQUNBO0VBQ0E7RUFDQTtDQUNGO0NBQ0EsUUFBUSxNQUFNLEtBQUs7RUFDakIsS0FBSyxlQUFlLG9CQUFvQixLQUFLLFlBQVk7RUFDekQsS0FBSyxnQkFBZ0Isb0JBQW9CLEtBQUssYUFBYTtFQUMzRCxtQkFBbUIsTUFBTSxTQUFTO0VBQ2xDLEtBQUssUUFBUSxnQkFBZ0IsS0FBSyxPQUFPLEtBQUssb0JBQW9CO0VBQ2xFLEtBQUssYUFBYSxnQkFBZ0IsS0FBSyxZQUFZLEtBQUssa0JBQWtCO0VBQzFFLEtBQUssU0FBUyxnQkFBZ0IsS0FBSyxRQUFRLEtBQUssY0FBYztFQUM5RCxLQUFLLHFCQUFxQixnQkFBZ0IsS0FBSyxvQkFBb0IsS0FBSyxhQUFhO0VBQ3JGLElBQUksS0FBSyxpQkFBaUI7R0FDeEIsTUFBTSxpQkFBaUIsV0FBVztJQUNoQyxJQUFJLENBQUMsVUFBVSxPQUFPLFdBQVcsVUFDL0IsT0FBTztJQUNULE1BQU0sT0FBTyxPQUFPO0lBRXBCLE9BRHFCLFNBQVMsZ0JBQWdCLE1BQU0sUUFBUSxJQUFJLEtBQUssS0FBSyxTQUFTLFlBQVksS0FBSyxZQUFZLFNBQzFGLGdCQUFnQixRQUFRLEtBQUssa0JBQWtCLElBQUksZ0JBQWdCLFFBQVEsR0FBRztHQUN0RztHQUNBLEtBQUssa0JBQWtCLE1BQU0sUUFBUSxLQUFLLGVBQWUsSUFBSSxLQUFLLGdCQUFnQixJQUFJLGFBQWEsSUFBSSxjQUFjLEtBQUssZUFBZTtFQUMzSTtFQUNBLElBQUksS0FBSyxhQUFhLGFBQWEsSUFBSSxLQUFLLEtBQzFDLFdBQVcsTUFBTSxtQkFBbUIsQ0FDbEM7R0FDRSxTQUFTO0dBQ1QsVUFBVSxDQUFDLElBQUksS0FBSyxHQUFHO0VBQ3pCLENBQ0YsQ0FBQztFQUVILE9BQU87Q0FDVDtDQUNBLGdCQUFnQixTQUFTLEVBQUUsTUFBTSxRQUFRO0VBQ3ZDLE1BQU0sV0FBVyxLQUFLLFVBQVU7RUFDaEMsTUFBTSxVQUFVLEtBQUssZ0JBQWdCO0VBQ3JDLE1BQU0sT0FBTyxLQUFLLE9BQU87RUFDekIsSUFBSSxZQUFZLEtBQUssUUFBUSxLQUFLLE1BQ2hDLFdBQVcsU0FBUyxTQUFTLFlBQVksUUFBUSxDQUFDO0VBQ3BELElBQUksTUFDRixXQUFXLFNBQVMsc0JBQXNCLFlBQVksSUFBSSxDQUFDO0VBQzdELElBQUksU0FDRixXQUFXLFNBQVMsWUFBWSxZQUFZLE9BQU8sQ0FBQztFQUN0RCxNQUFNLGFBQWEsS0FBSyxtQkFBbUI7RUFDM0MsSUFBSSxZQUNGLFdBQVcsU0FBUyxjQUFjLFlBQVksVUFBVSxDQUFDO0VBQzNELE9BQU87Q0FDVDtBQUNGLENBQUM7QUFFRCxJQUFNLGlCQUFpQix3Q0FBd0I7Q0FDN0MsS0FBSyxNQUFNO0VBQ1QsSUFBSSxPQUFPLFNBQVMsVUFDbEIsT0FBTyxFQUNMLE1BQU0sS0FDUjtFQUVGLE9BQU87Q0FDVDtDQUNBLFVBQVUsRUFDUixTQUFTLFNBQ1g7Q0FDQSxVQUFVLENBQUMsUUFBUSxVQUFVO0NBQzdCLFFBQVEsTUFBTSxLQUFLO0VBQ2pCLElBQUksS0FBSyxLQUNQLEtBQUssTUFBTSxnQkFBZ0IsSUFBSSxLQUFLLE1BQU0sS0FBSyxHQUFHO0VBQ3BELE9BQU87Q0FDVDtDQUNBLGdCQUFnQixNQUFNLEVBQUUsTUFBTSxRQUFRO0VBQ3BDLElBQUksa0JBQWtCLEtBQUssTUFBTSxNQUFNLFlBQVk7R0FDakQsV0FBVyxNQUFNLE9BQU8sS0FBSyxJQUFJO0dBQ2pDLE1BQU0sVUFBVSxLQUFLLGdCQUFnQjtHQUNyQyxJQUFJLFNBQ0YsV0FBVyxTQUFTLFNBQVMsWUFBWSxJQUFJLENBQUM7R0FDaEQsTUFBTSxVQUFVLEtBQUssZ0JBQWdCO0dBQ3JDLElBQUksU0FDRixXQUFXLFNBQVMsYUFBYSxZQUFZLElBQUksQ0FBQztFQUN0RDtFQUNBLE1BQU0sVUFBVSxLQUFLLGdCQUFnQjtFQUNyQyxJQUFJLFNBQ0YsV0FBVyxTQUFTLFVBQVUsWUFBWSxJQUFJLENBQUM7Q0FDbkQ7QUFDRixDQUFDO0FBRUQsSUFBTSxtQkFBbUI7QUFDekIsSUFBTSxrQkFBa0Isd0NBQXdCO0NBQzlDLFVBQVUsRUFDUixTQUFTLFVBQ1g7Q0FDQSxhQUFhO0VBQ1g7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0dBQUUsTUFBTTtHQUFTLEtBQUs7RUFBVztDQUNuQztDQUNBLFVBQVUsQ0FBQyxPQUFPLGdCQUFnQjtDQUNsQyxRQUFRLE1BQU0sS0FBSztFQUNqQixLQUFLLFNBQVMsZ0JBQWdCLEtBQUssUUFBUSxLQUFLLGdCQUFnQixFQUM5RCxNQUFNLEtBQ1IsQ0FBQztFQUNELEtBQUssWUFBWSxnQkFBZ0IsS0FBSyxXQUFXLEdBQUc7RUFDcEQsS0FBSyxlQUFlLG9CQUFvQixLQUFLLFlBQVk7RUFDekQsS0FBSyxnQkFBZ0Isb0JBQW9CLEtBQUssYUFBYTtFQUMzRCxtQkFBbUIsTUFBTSxTQUFTO0VBQ2xDLEtBQUssV0FBVyxXQUFXLEtBQUssVUFBVSxHQUFHO0VBQzdDLE9BQU87Q0FDVDtDQUNBLGdCQUFnQixNQUFNLEVBQUUsTUFBTSxRQUFRO0VBQ3BDLE1BQU0sVUFBVSxLQUFLLGdCQUFnQjtFQUNyQyxNQUFNLFdBQVcsS0FBSyxVQUFVO0VBQ2hDLElBQUksS0FBSyxTQUFTLENBQUMsS0FBSyxjQUFjO0dBQ3BDLE1BQU0sYUFBYSxRQUFRLEtBQUssS0FBSyxDQUFDLENBQUM7R0FDdkMsSUFBSSxPQUFPLGVBQWUsVUFDeEIsV0FBVyxNQUFNLGdCQUFnQixnQkFBZ0IsS0FBSyxNQUFNLFVBQVUsQ0FBQztRQUNwRSxJQUFJLGFBQWEsUUFDcEIsV0FBVyxNQUFNLGdCQUFnQixLQUFLLFdBQVcsUUFBUSxhQUFhLENBQUMsRUFBRSxHQUFHO0VBQ2hGO0VBQ0EsSUFBSSxVQUFVO0dBQ1osV0FBVyxNQUFNLGFBQWEsWUFBWSxRQUFRLENBQUM7R0FDbkQsV0FBVyxNQUFNLFVBQVUsWUFBWSxRQUFRLENBQUM7RUFDbEQ7RUFDQSxJQUFJLFNBQVM7R0FDWCxXQUFXLE1BQU0sWUFBWSxZQUFZLE9BQU8sQ0FBQztHQUNqRCxXQUFXLE1BQU0sb0JBQW9CLFlBQVksT0FBTyxDQUFDO0dBQ3pELFdBQVcsU0FBUyxtQkFBbUIsQ0FDckM7SUFDRSxTQUFTO0lBQ1QsVUFBVSxDQUFDLEtBQUssR0FBRztHQUNyQixDQUNGLENBQUM7R0FDRCxXQUFXLFNBQVMsZ0JBQWdCLEtBQUssWUFBWTtHQUNyRCxXQUFXLFNBQVMsaUJBQWlCLEtBQUssYUFBYTtFQUN6RDtFQUNBLE9BQU87Q0FDVDtBQUNGLENBQUM7QUFFRCxJQUFNLHNCQUFzQix3Q0FBd0I7Q0FDbEQsVUFBVSxFQUNSLFNBQVMsT0FDWDtDQUNBLGFBQWEsQ0FDWCxZQUNGO0NBQ0EsUUFBUSxNQUFNLEtBQUs7RUFDakIsSUFBSSxLQUFLLFlBQ1AsS0FBSyxhQUFhLFNBQVMsS0FBSyxZQUFZLHFCQUFxQjtFQUNuRSxJQUFJLEtBQUssZUFDUCxLQUFLLGdCQUFnQixxQkFBcUIsS0FBSyxhQUFhO0VBQzlELEtBQUssU0FBUyxnQkFBZ0IsS0FBSyxRQUFRLEdBQUc7RUFDOUMsT0FBTztDQUNUO0NBQ0EsZ0JBQWdCLE1BQU0sRUFBRSxRQUFRO0VBQzlCLE1BQU0sV0FBVyxLQUFLLFVBQVU7RUFDaEMsSUFBSSxVQUNGLFdBQVcsTUFBTSxZQUFZLFlBQVksUUFBUSxDQUFDO0VBQ3BELE9BQU87Q0FDVDtBQUNGLENBQUM7QUFFRCxJQUFNLGVBQWUsd0NBQXdCO0NBQzNDLFVBQVUsRUFDUixTQUFTLE9BQ1g7Q0FDQSxhQUFhO0VBQ1g7RUFDQTtFQUNBO0dBQUUsTUFBTTtHQUFTLEtBQUs7RUFBTztDQUMvQjtDQUNBLFVBQVUsQ0FBQyxPQUFPLE9BQWE7Q0FDL0IsUUFBUSxNQUFNLEtBQUs7RUFDakIsS0FBSyxjQUFjLGdCQUFnQixLQUFLLGFBQWEsS0FBSyxtQkFBbUI7RUFDN0UsS0FBSyxTQUFTLGdCQUFnQixLQUFLLFFBQVEsR0FBRztFQUM5QyxJQUFJLEtBQUssT0FBTyxJQUFJLEtBQUssTUFDdkIsS0FBSyxNQUFNLFNBQVMsS0FBSyxLQUFLLElBQUksS0FBSyxJQUFJO0VBQzdDLE9BQU87Q0FDVDtDQUNBLGdCQUFnQixNQUFNLEVBQUUsUUFBUTtFQUM5QixNQUFNLFdBQVcsS0FBSyxVQUFVO0VBQ2hDLElBQUksVUFDRixXQUFXLE1BQU0sVUFBVSxZQUFZLFFBQVEsQ0FBQztFQUNsRCxPQUFPO0NBQ1Q7QUFDRixDQUFDO0FBRUQsSUFBTSxrQkFBa0Isd0NBQXdCO0NBQzlDLFVBQVUsRUFDUixTQUFTLFVBQ1g7Q0FDQSxVQUFVO0NBQ1YsUUFBUSxNQUFNLEtBQUs7RUFDakIsS0FBSyxTQUFTLGdCQUFnQixLQUFLLFFBQVEsS0FBSyxnQkFBZ0IsRUFDOUQsTUFBTSxLQUNSLENBQUM7RUFDRCxLQUFLLGNBQWMsb0JBQW9CLEtBQUssV0FBVztFQUN2RCxLQUFLLGVBQWUsb0JBQW9CLEtBQUssWUFBWTtFQUN6RCxPQUFPO0NBQ1Q7Q0FDQSxnQkFBZ0IsTUFBTSxFQUFFLFFBQVE7RUFDOUIsTUFBTSxVQUFVLEtBQUssZ0JBQWdCO0VBQ3JDLElBQUksU0FDRixXQUFXLE1BQU0sU0FBUyxZQUFZLE9BQU8sQ0FBQztDQUNsRDtBQUNGLENBQUM7QUFFRCxJQUFNLGlCQUFpQix3Q0FBd0I7Q0FDN0MsVUFBVSxFQUNSLFNBQVMsU0FDWDtDQUNBLFFBQVEsTUFBTSxLQUFLO0VBQ2pCLEtBQUssV0FBVyxnQkFBZ0IsS0FBSyxVQUFVLEtBQUssc0JBQXNCLEVBQ3hFLE1BQU0sS0FDUixDQUFDO0VBQ0QsT0FBTztDQUNUO0NBQ0EsZ0JBQWdCLE1BQU0sRUFBRSxRQUFRO0VBQzlCLE1BQU0sV0FBVyxLQUFLLFVBQVU7RUFDaEMsSUFBSSxVQUNGLFdBQVcsTUFBTSxZQUFZLFlBQVksUUFBUSxDQUFDO0VBQ3BELE9BQU87Q0FDVDtBQUNGLENBQUM7QUFHRCxJQUFNLGtCQUFrQix3Q0FBd0I7Q0FDOUMsVUFBVSxFQUNSLFNBQVMsVUFDWDtDQUNBLGFBQWE7RUFDWDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0dBQUUsTUFBTTtHQUFTLEtBQUs7RUFBTztDQUMvQjtDQUNBLFVBQVUsQ0FBQyxPQUFPLFVBQWdCO0NBQ2xDLFFBQVEsTUFBTSxLQUFLO0VBQ2pCLG1CQUFtQixNQUFNLFNBQVM7RUFDbEMsS0FBSyxVQUFVLGdCQUFnQixLQUFLLFNBQVMsS0FBSyxnQkFBZ0IsRUFDaEUsTUFBTSxLQUNSLENBQUM7RUFDRCxLQUFLLGVBQWUsb0JBQW9CLEtBQUssWUFBWTtFQUN6RCxLQUFLLGdCQUFnQixvQkFBb0IsS0FBSyxhQUFhO0VBQzNELE9BQU87Q0FDVDtBQUNGLENBQUM7QUFFRCxJQUFNLGdCQUFnQix3Q0FBd0I7Q0FDNUMsVUFBVSxFQUNSLFNBQVMsUUFDWDtDQUNBLFFBQVEsTUFBTSxLQUFLO0VBQ2pCLElBQUksT0FBTyxLQUFLLFlBQVksVUFDMUIsS0FBSyxVQUFVLGdCQUFnQixLQUFLLFNBQVMsS0FBSyxlQUFlO0VBQ25FLE9BQU87Q0FDVDtBQUNGLENBQUM7QUFFRCxJQUFNLDBCQUEwQix3Q0FBd0I7Q0FDdEQsS0FBSyxNQUFNO0VBQ1QsSUFBSSxPQUFPLFNBQVMsVUFDbEIsT0FBTyxFQUNMLEtBQUssS0FDUDtFQUVGLE9BQU87Q0FDVDtDQUNBLFVBQVUsRUFDUixTQUFTLGtCQUNYO0FBQ0YsQ0FBQztBQUdELElBQU0sZ0JBQWdCLHdDQUF3QjtDQUM1QyxVQUFVLEVBQ1IsU0FBUyxRQUNYO0NBQ0EsYUFBYTtFQUNYO0VBQ0E7RUFDQTtFQUNBO0dBQUUsTUFBTTtHQUFTLEtBQUs7RUFBTztDQUMvQjtDQUNBLFVBQVUsQ0FBQyxPQUFPLFFBQWM7Q0FDaEMsUUFBUSxNQUFNLEtBQUs7RUFDakIsSUFBSSxLQUFLLFVBQVU7R0FDakIsTUFBTSxtQkFBbUIsYUFBYTtJQUNwQyxNQUFNLE9BQU8sT0FBTyxhQUFhLFlBQVksYUFBYSxPQUFPLFNBQVMsV0FBVyxLQUFLO0lBRTFGLE9BRGtCLE9BQU8sYUFBYSxZQUFZLE9BQU8sYUFBYSxZQUFZLGFBQWEsU0FBUyxTQUFTLHFCQUFxQixNQUFNLFFBQVEsSUFBSSxLQUFLLEtBQUssU0FBUyxpQkFBaUIsS0FBSyxPQUFPLFNBQVMsUUFBUSxlQUN0TSxnQkFBZ0IsVUFBVSxLQUFLLHVCQUF1QixJQUFJLGdCQUFnQixVQUFVLEtBQUssYUFBYTtHQUMzSDtHQUNBLElBQUksTUFBTSxRQUFRLEtBQUssUUFBUSxHQUFHO0lBQ2hDLE1BQU0sWUFBWSxLQUFLLFNBQVMsSUFBSSxlQUFlO0lBQ25ELEtBQUssV0FBVyxVQUFVLFdBQVcsSUFBSSxVQUFVLEtBQUs7R0FDMUQsT0FDRSxLQUFLLFdBQVcsZ0JBQWdCLEtBQUssUUFBUTtFQUVqRDtFQUNBLEtBQUssWUFBWSxnQkFBZ0IsS0FBSyxXQUFXLEtBQUssZ0JBQWdCLEVBQ3BFLE1BQU0sS0FDUixDQUFDO0VBQ0QsS0FBSyxZQUFZLGdCQUFnQixLQUFLLFdBQVcsS0FBSyxzQkFBc0IsRUFDMUUsTUFBTSxLQUNSLENBQUM7RUFDRCxLQUFLLFNBQVMsZ0JBQWdCLEtBQUssUUFBUSxLQUFLLGFBQWE7RUFDN0QsSUFBSSxLQUFLLHFCQUNQLEtBQUssc0JBQXNCLFNBQVMsS0FBSyxxQkFBcUIscUJBQXFCO0VBQ3JGLElBQUksS0FBSyxhQUNQLEtBQUssY0FBYyxTQUFTLEtBQUssYUFBYSxxQkFBcUI7RUFDckUsTUFBTSxXQUFXLEtBQUssZ0JBQWdCLHlDQUF5QyxLQUFLLHdCQUF3QjtFQUU1RztHQURlO0dBQWE7R0FBcUI7RUFDN0MsQ0FBQyxDQUFDLFNBQVMsU0FBUztHQUN0QixJQUFJLENBQUMsVUFDQztRQUFBLEtBQUssaUJBQWlCLFFBQVEsS0FBSyxLQUFLLENBQUMsU0FBUyxNQUFNLEtBQUssS0FBSyxLQUFLLENBQUMsV0FBVyxNQUFNLEdBQzNGLEtBQUssUUFBUSxxQkFBcUIsS0FBSyxLQUFLO0dBQUEsT0FFOUMsS0FBSyxRQUFRLG9CQUFvQixLQUFLLEtBQUs7RUFFL0MsQ0FBQztFQUNELFdBQVcsTUFBTSxXQUFXLEtBQUssU0FBUztFQUMxQyxPQUFPO0NBQ1Q7Q0FDQSxnQkFBZ0IsTUFBTSxFQUFFLFFBQVE7RUFDOUIsTUFBTSxXQUFXLEtBQUssVUFBVTtFQUNoQyxJQUFJLFVBQ0YsV0FBVyxNQUFNLGFBQWEsWUFBWSxRQUFRLENBQUM7Q0FDdkQ7QUFDRixDQUFDO0FBRUQsSUFBTSx1QkFBdUIsd0NBQXdCLEVBQ25ELFVBQVU7Q0FDUixTQUFTO0NBQ1QsU0FBUztDQUNULFVBQVU7QUFDWixFQUNGLENBQUM7QUFFRCxJQUFNLHdCQUF3Qix3Q0FBd0I7Q0FDcEQsVUFBVSxFQUNSLFNBQVMsQ0FBQyxnQkFBZ0IsZUFBZSxFQUMzQztDQUNBLGFBQWEsQ0FDWDtFQUFFLEtBQUs7RUFBTyxNQUFNO0NBQU8sR0FDM0I7RUFBRSxLQUFLO0VBQXNCLE1BQU07Q0FBVyxDQUNoRDtDQUNBLFVBQVUsQ0FBQyxRQUFRLFVBQVU7Q0FDN0IsUUFBUSxNQUFNLEtBQUs7RUFDakIsbUJBQW1CLE1BQU0sQ0FBQyxnQkFBZ0IsZUFBZSxDQUFDO0VBQzFELEtBQUssVUFBVSxnQkFBZ0IsS0FBSyxTQUFTLEtBQUssZUFBZTtFQUNqRSxLQUFLLDRCQUE0QixnQkFBZ0IsS0FBSywyQkFBMkIsS0FBSyxvQkFBb0I7RUFDMUcsT0FBTyxZQUFZLEVBQUUsR0FBRyxLQUFLLEdBQUcsS0FBSyxvQkFBb0I7RUFDekQsT0FBTztDQUNUO0NBQ0EsZ0JBQWdCLE1BQU0sS0FBSztFQUN6QixxQkFBcUIsZ0JBQWdCLE1BQU0sR0FBRztFQUM5QyxPQUFPO0NBQ1Q7QUFDRixDQUFDO0FBRUQsSUFBTSxpQkFBaUIsd0NBQXdCO0NBQzdDLEtBQUssTUFBTTtFQUNULElBQUksT0FBTyxTQUFTLFVBQ2xCLE9BQU8sRUFDTCxhQUFhLEtBQ2Y7RUFFRixPQUFPO0NBQ1Q7Q0FDQSxVQUFVO0VBQ1IsU0FBUztFQUNULGNBQWM7RUFDZCxlQUFlO0NBQ2pCO0FBQ0YsQ0FBQztBQUVELElBQU0sNEJBQTRCLHdDQUF3QjtDQUN4RCxVQUFVLEVBQ1IsU0FBUztFQUFDO0VBQWdCO0VBQWlCO0NBQW1CLEVBQ2hFO0NBQ0EsYUFBYSxDQUNYO0VBQUUsS0FBSztFQUFPLE1BQU07Q0FBTyxHQUMzQjtFQUFFLEtBQUs7RUFBc0IsTUFBTTtDQUFXLENBQ2hEO0NBQ0EsVUFBVSxDQUFDLFFBQVEsVUFBVTtDQUM3QixRQUFRLE1BQU0sS0FBSztFQUNqQixtQkFBbUIsTUFBTTtHQUFDO0dBQWdCO0dBQWlCO0VBQW1CLENBQUM7RUFDL0UsS0FBSyxhQUFhLGdCQUFnQixLQUFLLFlBQVksS0FBSyxjQUFjO0VBQ3RFLE9BQU8sWUFBWSxNQUFNLEtBQUsscUJBQXFCO0VBQ25ELE9BQU87Q0FDVDtDQUNBLGdCQUFnQixNQUFNLEtBQUs7RUFDekIsc0JBQXNCLGdCQUFnQixNQUFNLEdBQUc7RUFDL0MsT0FBTztDQUNUO0FBQ0YsQ0FBQztBQUVELElBQU0sNkJBQTZCLHdDQUF3QjtDQUN6RCxLQUFLLE1BQU07RUFDVCxJQUFJLE9BQU8sU0FBUyxVQUNsQixPQUFPLEVBQ0wsTUFBTSxLQUNSO0VBRUYsT0FBTztDQUNUO0NBQ0EsVUFBVSxFQUNSLFNBQVMsaUJBQ1g7QUFDRixDQUFDO0FBRUQsSUFBTSxvQkFBb0Isd0NBQXdCO0NBQ2hELEtBQUssTUFBTTtFQUNULElBQUksT0FBTyxTQUFTLFVBQ2xCLE9BQU8sRUFDTCxNQUFNLEtBQ1I7RUFFRixPQUFPO0NBQ1Q7Q0FDQSxVQUFVLEVBQ1IsU0FBUyxZQUNYO0NBQ0EsUUFBUSxNQUFNLEtBQUs7RUFDakIsSUFBSSxLQUFLLEtBQ1AsS0FBSyxNQUFNLGdCQUFnQixJQUFJLEtBQUssS0FBSyxLQUFLLEdBQUc7RUFDbkQsSUFBSSxLQUFLLE9BQ1AsS0FBSyxRQUFRLGdCQUFnQixLQUFLLE9BQU8sS0FBSyxlQUFlLEVBQzNELE1BQU0sS0FDUixDQUFDO0VBRUgsSUFBSSxLQUFLLGlCQUNQLEtBQUssa0JBQWtCLGdCQUFnQixLQUFLLGlCQUFpQixLQUFLLDBCQUEwQjtFQUM5RixPQUFPO0NBQ1Q7QUFDRixDQUFDO0FBR0QsSUFBTSxnQkFBZ0Isd0NBQXdCO0NBQzVDLFVBQVUsRUFDUixTQUFTLFFBQ1g7Q0FDQSxhQUFhO0VBQ1g7RUFDQTtFQUNBO0VBQ0E7R0FBRSxNQUFNO0dBQVMsS0FBSztFQUFPO0NBQy9CO0NBQ0EsVUFBVSxDQUFDLE9BQU8sUUFBTztDQUN6QixRQUFRLE1BQU0sS0FBSztFQUNqQixLQUFLLE9BQU8sZ0JBQWdCLEtBQUssTUFBTSxLQUFLLGlCQUFpQjtFQUM3RCxPQUFPO0NBQ1Q7Q0FDQSxnQkFBZ0IsTUFBTSxFQUFFLFFBQVE7RUFDOUIsTUFBTSxVQUFVLEtBQUssZ0JBQWdCO0VBQ3JDLElBQUksU0FDRixXQUFXLE1BQU0sb0JBQW9CLFlBQVksT0FBTyxDQUFDO0NBQzdEO0FBQ0YsQ0FBQztBQUVELElBQU0sbUJBQW1CLHdDQUF3QjtDQUMvQyxVQUFVLEVBQ1IsU0FBUyxXQUNYO0NBQ0EsUUFBUSxNQUFNLEtBQUs7RUFDakIsSUFBSSxLQUFLLGlCQUFpQjtHQUN4QixJQUFJLFFBQVE7R0FDWixLQUFLLGtCQUFrQixnQkFBZ0IsS0FBSyxpQkFBaUIsS0FBSyxrQkFBa0I7SUFDbEYsT0FBTztJQUNQLGFBQWEsT0FBTztLQUNsQixXQUFXLE9BQU8sWUFBWSxPQUFPO0lBQ3ZDO0dBQ0YsQ0FBQztFQUNIO0VBQ0EsT0FBTztDQUNUO0FBQ0YsQ0FBQztBQUVELElBQU0scUJBQXFCLHdDQUF3QjtDQUNqRCxVQUFVLEVBQ1IsU0FBUyxhQUNYO0NBQ0EsVUFBVSxDQUFDLE9BQU8sY0FBYztDQUNoQyxRQUFRLE1BQU0sS0FBSztFQUNqQixLQUFLLGFBQWEsb0JBQW9CLEtBQUssVUFBVTtFQUNyRCxLQUFLLHFCQUFxQixnQkFBZ0IsS0FBSyxvQkFBb0IsS0FBSyxvQkFBb0I7RUFDNUYsS0FBSyxjQUFjLGdCQUFnQixLQUFLLGFBQWEsS0FBSyxhQUFhO0VBQ3ZFLEtBQUssYUFBYSxnQkFBZ0IsS0FBSyxZQUFZLEtBQUssc0JBQXNCO0VBQzlFLEtBQUssZUFBZSxvQkFBb0IsS0FBSyxZQUFZO0VBQ3pELE9BQU87Q0FDVDtDQUNBLGdCQUFnQixZQUFZLEVBQUUsUUFBUTtFQUNwQyxNQUFNLFVBQVUsS0FBSyxnQkFBZ0I7RUFDckMsTUFBTSxXQUFXLEtBQUssVUFBVTtFQUNoQyxJQUFJLFVBQ0YsV0FBVyxZQUFZLHNCQUFzQixZQUFZLFFBQVEsQ0FBQztFQUNwRSxJQUFJLFNBQ0YsV0FBVyxZQUFZLG9CQUFvQixZQUFZLE9BQU8sQ0FBQztFQUNqRSxPQUFPO0NBQ1Q7QUFDRixDQUFDO0FBRUQsSUFBTSxpQkFBaUIsd0NBQXdCO0NBQzdDLFVBQVUsRUFDUixTQUFTLFNBQ1g7Q0FDQSxhQUFhLENBQ1gsWUFDRjtDQUNBLFFBQVEsUUFBUSxLQUFLO0VBQ25CLE9BQU8sZUFBZSxnQkFBZ0IsT0FBTyxjQUFjLEtBQUssY0FBYztFQUM5RSxPQUFPLFNBQVMsZ0JBQWdCLE9BQU8sUUFBUSxLQUFLLGNBQWM7RUFDbEUsT0FBTztDQUNUO0FBQ0YsQ0FBQztBQUVELElBQU0sZ0JBQWdCLHdDQUF3QjtDQUM1QyxLQUFLLE9BQU87RUFDVixJQUFJLE9BQU8sVUFBVSxVQUNuQixRQUFRLEVBQ04sS0FBSyxNQUNQO0VBRUYsT0FBTztDQUNUO0NBQ0EsT0FBTztDQUNQLFVBQVUsRUFDUixTQUFTLGNBQ1g7Q0FDQSxhQUFhO0VBQ1g7R0FBRSxNQUFNO0dBQVMsS0FBSztFQUFPO0VBQzdCO0VBQ0E7RUFDQTtFQUNBO0dBQUUsTUFBTTtHQUFpQixLQUFLO0VBQWE7Q0FDN0M7Q0FDQSxVQUFVO0NBQ1YsUUFBUSxPQUFPLEtBQUs7RUFDbEIsSUFBSSxNQUFNLFlBQ1IsTUFBTSxhQUFhLG9CQUFvQixNQUFNLFVBQVU7RUFDekQsTUFBTSxNQUFNLGdCQUFnQixJQUFJLEtBQUssTUFBTSxNQUFNLEdBQUc7RUFDcEQsSUFBSSxNQUFNLFdBQVcsQ0FBQyxNQUFNLGFBQzFCLE1BQU0sY0FBYyxNQUFNO0VBQzVCLElBQUksQ0FBQyxNQUFNLGFBQ1QsTUFBTSxjQUFjO0VBQ3RCLElBQUksTUFBTSxpQkFBaUIsT0FBTyxNQUFNLGlCQUFpQixZQUFZLE1BQU0sUUFBUSxNQUFNLFlBQVksSUFBSTtHQUN2RyxNQUFNLFNBQVMsUUFBUSxNQUFNLFlBQVksQ0FBQyxDQUFDLEtBQUssVUFBVSxnQkFBZ0IsSUFBSSxLQUFLLE1BQU0sS0FBSyxDQUFDO0dBQy9GLE1BQU0sZUFBZSxPQUFPLFNBQVMsSUFBSSxTQUFTLE9BQU87RUFDM0Q7RUFDQSxJQUFJLE1BQU0sV0FDUixNQUFNLFlBQVksZ0JBQWdCLE1BQU0sV0FBVyxLQUFLLGFBQWE7RUFDdkUsT0FBTztDQUNUO0NBQ0EsZ0JBQWdCLE9BQU8sRUFBRSxNQUFNLFFBQVE7RUFDckMsSUFBSSxNQUFNLFNBQVMsQ0FBQyxNQUFNLGNBQWM7R0FDdEMsTUFBTSxhQUFhLFFBQVEsTUFBTSxLQUFLLENBQUMsQ0FBQztHQUN4QyxJQUFJLE9BQU8sZUFBZSxVQUN4QixXQUFXLE9BQU8sZ0JBQWdCLGdCQUFnQixLQUFLLE1BQU0sVUFBVSxDQUFDO1FBQ3JFLElBQUksYUFBYSxRQUNwQixXQUFXLE9BQU8sZ0JBQWdCLEtBQUssV0FBVyxRQUFRLGFBQWEsQ0FBQyxFQUFFLEdBQUc7RUFDakY7Q0FDRjtBQUNGLENBQUM7QUFFRCxJQUFNLGdCQUFnQix3Q0FBd0I7Q0FDNUMsVUFBVSxFQUNSLFNBQVMsUUFDWDtDQUNBLFFBQVEsTUFBTSxLQUFLO0VBQ2pCLEtBQUssa0JBQWtCLGdCQUFnQixLQUFLLGlCQUFpQixLQUFLLHVCQUF1QjtFQUN6RixLQUFLLFNBQVMsZ0JBQWdCLEtBQUssUUFBUSxLQUFLLGNBQWM7RUFDOUQsS0FBSyxXQUFXLGdCQUFnQixLQUFLLFVBQVUsS0FBSyxjQUFjO0VBQ2xFLEtBQUssUUFBUSxnQkFBZ0IsS0FBSyxPQUFPLEtBQUssY0FBYztFQUM1RCxLQUFLLFVBQVUsZ0JBQWdCLEtBQUssU0FBUyxLQUFLLGFBQWE7RUFDL0QsS0FBSyxvQkFBb0IsZ0JBQWdCLEtBQUssbUJBQW1CLEtBQUssb0JBQW9CO0VBQzFGLElBQUksS0FBSyxhQUNQLEtBQUssY0FBYyxxQkFBcUIsS0FBSyxXQUFXO0VBQzFELE9BQU87Q0FDVDtBQUNGLENBQUM7QUFFRCxJQUFNLHFCQUFxQix3Q0FBd0I7Q0FDakQsVUFBVSxFQUNSLFNBQVMsYUFDWDtDQUNBLFVBQVU7Q0FDVixRQUFRLE1BQU0sS0FBSztFQUNqQixJQUFJLEtBQUssZUFDUCxLQUFLLGdCQUFnQixvQkFBb0IsS0FBSyxhQUFhO0VBQzdELElBQUksS0FBSyxLQUNQLEtBQUssTUFBTSxnQkFBZ0IsSUFBSSxLQUFLLE1BQU0sS0FBSyxHQUFHO0VBQ3BELEtBQUssV0FBVyxnQkFBZ0IsS0FBSyxVQUFVLEtBQUssY0FBYztFQUNsRSxLQUFLLGtCQUFrQixnQkFBZ0IsS0FBSyxpQkFBaUIsS0FBSyx1QkFBdUI7RUFDekYsS0FBSyxTQUFTLGdCQUFnQixLQUFLLFFBQVEsS0FBSyxjQUFjO0VBQzlELE9BQU87Q0FDVDtBQUNGLENBQUM7QUFFRCxJQUFNLHFCQUFxQix3Q0FBd0I7Q0FDakQsVUFBVSxFQUNSLFNBQVMsYUFDWDtDQUNBLFVBQVU7Q0FDVixhQUFhLENBQ1g7RUFBRSxNQUFNO0VBQVEsS0FBSztDQUFNLENBQzdCO0NBQ0EsUUFBUSxNQUFNLEtBQUs7RUFDakIsSUFBSSxLQUFLLGNBQ1AsS0FBSyxlQUFlLHFCQUFxQixLQUFLLFlBQVk7RUFDNUQsSUFBSSxLQUFLLGlCQUNQLEtBQUssa0JBQWtCLHFCQUFxQixLQUFLLGVBQWU7RUFDbEUsSUFBSSxLQUFLLEtBQ1AsS0FBSyxNQUFNLGdCQUFnQixJQUFJLEtBQUssTUFBTSxLQUFLLEdBQUc7RUFDcEQsS0FBSyxTQUFTLGdCQUFnQixLQUFLLFFBQVEsS0FBSyxjQUFjO0VBQzlELE9BQU87Q0FDVDtBQUNGLENBQUM7QUFFRCxJQUFNLHdCQUF3Qix3Q0FBd0I7Q0FDcEQsVUFBVSxFQUNSLFNBQVMsZ0JBQ1g7Q0FDQSxVQUFVO0NBQ1YsUUFBUSxNQUFNLEtBQUs7RUFDakIsSUFBSSxLQUFLLGVBQ1AsS0FBSyxnQkFBZ0Isb0JBQW9CLEtBQUssYUFBYTtFQUM3RCxJQUFJLEtBQUssY0FDUCxLQUFLLGVBQWUsb0JBQW9CLEtBQUssWUFBWTtFQUMzRCxJQUFJLEtBQUssS0FDUCxLQUFLLE1BQU0sZ0JBQWdCLElBQUksS0FBSyxNQUFNLEtBQUssR0FBRztFQUNwRCxLQUFLLFVBQVUsZ0JBQWdCLEtBQUssU0FBUyxLQUFLLGNBQWM7RUFDaEUsS0FBSyxrQkFBa0IsZ0JBQWdCLEtBQUssaUJBQWlCLEtBQUssdUJBQXVCO0VBQ3pGLE9BQU87Q0FDVDtBQUNGLENBQUM7QUFFRCxJQUFNLHlCQUF5Qix3Q0FBd0I7Q0FDckQsVUFBVSxFQUNSLFNBQVMsaUJBQ1g7Q0FDQSxVQUFVO0NBQ1YsUUFBUSxNQUFNLEtBQUs7RUFDakIsSUFBSSxLQUFLLGVBQ1AsS0FBSyxnQkFBZ0Isb0JBQW9CLEtBQUssYUFBYTtFQUM3RCxJQUFJLEtBQUssS0FDUCxLQUFLLE1BQU0sZ0JBQWdCLElBQUksS0FBSyxNQUFNLEtBQUssR0FBRztFQUNwRCxJQUFJLEtBQUssT0FDUCxLQUFLLFFBQVEsZ0JBQWdCLElBQUksS0FBSyxNQUFNLEtBQUssS0FBSztFQUN4RCxLQUFLLFdBQVcsZ0JBQWdCLEtBQUssVUFBVSxLQUFLLGNBQWM7RUFDbEUsS0FBSyxrQkFBa0IsZ0JBQWdCLEtBQUssaUJBQWlCLEtBQUssdUJBQXVCO0VBQ3pGLE9BQU87Q0FDVDtBQUNGLENBQUM7QUFFRCxJQUFNLHlCQUF5Qix3Q0FBd0I7Q0FDckQsVUFBVSxFQUNSLFNBQVMsaUJBQ1g7Q0FDQSxhQUFhLENBQ1gsWUFDRjtDQUNBLFFBQVEsTUFBTSxLQUFLO0VBQ2pCLEtBQUssU0FBUyxnQkFBZ0IsS0FBSyxRQUFRLEtBQUssY0FBYztFQUM5RCxLQUFLLGtCQUFrQixnQkFBZ0IsS0FBSyxpQkFBaUIsS0FBSyx1QkFBdUI7RUFDekYsS0FBSyxTQUFTLGdCQUFnQixLQUFLLFFBQVEsS0FBSyxjQUFjO0VBQzlELElBQUksS0FBSyxlQUNQLEtBQUssZ0JBQWdCLG9CQUFvQixLQUFLLGFBQWE7RUFDN0QsSUFBSSxLQUFLLFlBQ1AsS0FBSyxhQUFhLG9CQUFvQixLQUFLLFVBQVU7RUFDdkQsT0FBTztDQUNUO0FBQ0YsQ0FBQztBQUVELElBQU0sd0JBQXdCLHdDQUF3QjtDQUNwRCxVQUFVLEVBQ1IsU0FBUyxnQkFDWDtDQUNBLFFBQVEsTUFBTSxLQUFLO0VBQ2pCLEtBQUssUUFBUSxnQkFBZ0IsS0FBSyxPQUFPLEtBQUssY0FBYztFQUM1RCxLQUFLLFdBQVcsZ0JBQWdCLEtBQUssVUFBVSxLQUFLLGNBQWM7RUFDbEUsS0FBSyxvQkFBb0IsZ0JBQWdCLEtBQUssbUJBQW1CLEtBQUssb0JBQW9CO0VBQzFGLEtBQUssa0JBQWtCLGdCQUFnQixLQUFLLGlCQUFpQixLQUFLLHVCQUF1QjtFQUN6RixJQUFJLEtBQUssZUFDUCxLQUFLLGdCQUFnQixvQkFBb0IsS0FBSyxhQUFhO0VBQzdELElBQUksS0FBSyxXQUNQLEtBQUssWUFBWSxvQkFBb0IsS0FBSyxTQUFTO0VBQ3JELElBQUksS0FBSyxTQUNQLEtBQUssVUFBVSxvQkFBb0IsS0FBSyxPQUFPO0VBQ2pELE9BQU87Q0FDVDtBQUNGLENBQUM7QUFFRCxJQUFNLHdCQUF3Qix3Q0FBd0I7Q0FDcEQsVUFBVSxFQUNSLFNBQVMsZ0JBQ1g7Q0FDQSxRQUFRLE1BQU0sS0FBSztFQUNqQixLQUFLLFNBQVMsZ0JBQWdCLEtBQUssUUFBUSxLQUFLLGNBQWM7RUFDOUQsS0FBSyxrQkFBa0IsZ0JBQWdCLEtBQUssaUJBQWlCLEtBQUssdUJBQXVCO0VBQ3pGLElBQUksS0FBSyxlQUNQLEtBQUssZ0JBQWdCLG9CQUFvQixLQUFLLGFBQWE7RUFDN0QsSUFBSSxLQUFLLFdBQ1AsS0FBSyxZQUFZLG9CQUFvQixLQUFLLFNBQVM7RUFDckQsSUFBSSxLQUFLLFNBQ1AsS0FBSyxVQUFVLG9CQUFvQixLQUFLLE9BQU87RUFDakQsT0FBTztDQUNUO0FBQ0YsQ0FBQztBQUdELElBQU0sa0JBQWtCLHdDQUF3QjtDQUM5QyxVQUFVLEVBQ1IsU0FBUyxVQUNYO0NBQ0EsYUFBYTtFQUNYO0VBQ0E7RUFDQTtHQUFFLE1BQU07R0FBUyxLQUFLO0VBQU87Q0FDL0I7Q0FDQSxVQUFVLENBQUMsT0FBTyxVQUFTO0NBQzNCLFFBQVEsTUFBTSxLQUFLO0VBQ2pCLEtBQUssaUJBQWlCLGdCQUFnQixLQUFLLGdCQUFnQixLQUFLLHNCQUFzQjtFQUN0RixLQUFLLGtCQUFrQixnQkFBZ0IsS0FBSyxpQkFBaUIsS0FBSyx1QkFBdUI7RUFDekYsS0FBSyxTQUFTLGdCQUFnQixLQUFLLFFBQVEsS0FBSyxhQUFhO0VBQzdELEtBQUssU0FBUyxnQkFBZ0IsS0FBSyxRQUFRLEtBQUssY0FBYztFQUM5RCxPQUFPO0NBQ1Q7Q0FDQSxnQkFBZ0IsU0FBUyxFQUFFLFFBQVE7RUFDakMsTUFBTSxVQUFVLEtBQUssZ0JBQWdCO0VBQ3JDLE1BQU0sV0FBVyxLQUFLLFVBQVU7RUFDaEMsSUFBSSxVQUNGLFdBQVcsU0FBUyxTQUFTLFlBQVksUUFBUSxDQUFDO0VBQ3BELElBQUksU0FDRixXQUFXLFNBQVMsb0JBQW9CLFlBQVksT0FBTyxDQUFDO0VBQzlELE9BQU87Q0FDVDtBQUNGLENBQUM7QUFFRCxJQUFNLGlCQUFpQix3Q0FBd0I7Q0FDN0MsS0FBSyxNQUFNO0VBQ1QsSUFBSSxPQUFPLFNBQVMsVUFDbEIsT0FBTyxFQUNMLE1BQU0sS0FDUjtFQUVGLE9BQU87Q0FDVDtDQUNBLFVBQVUsRUFDUixTQUFTLFNBQ1g7QUFDRixDQUFDO0FBRUQsSUFBTSxtQkFBbUIsd0NBQXdCO0NBQy9DLFVBQVUsRUFDUixTQUFTLFdBQ1g7Q0FDQSxhQUFhLENBQ1gsWUFDRjtDQUNBLFVBQVU7Q0FDVixRQUFRLFVBQVUsS0FBSztFQUNyQixJQUFJLFNBQVMsVUFBVTtHQUNyQixTQUFTLE9BQU8sU0FBUztHQUN6QixPQUFPLFNBQVM7RUFDbEI7RUFDQSxJQUFJLFNBQVMsUUFBUTtHQUNuQixTQUFTLGlCQUFpQixTQUFTO0dBQ25DLE9BQU8sU0FBUztFQUNsQjtFQUNBLFNBQVMsaUJBQWlCLGdCQUFnQixTQUFTLGdCQUFnQixLQUFLLGNBQWM7RUFDdEYsU0FBUyxjQUFjLG9CQUFvQixTQUFTLFdBQVc7RUFDL0QsT0FBTztDQUNUO0NBQ0EsZ0JBQWdCLFVBQVUsRUFBRSxRQUFRO0VBQ2xDLE1BQU0sVUFBVSxLQUFLLGdCQUFnQjtFQUNyQyxJQUFJLFdBQVcsUUFBUSxRQUFRLFFBQVEsQ0FBQyxDQUFDLFNBQVMsU0FBUyxHQUN6RCxZQUFZLFNBQVMsY0FBYyxZQUFZLFFBQVEsQ0FBQztDQUM1RDtBQUNGLENBQUM7QUFHRCxJQUFNLGlCQUFpQix3Q0FBd0I7Q0FDN0MsVUFBVSxFQUNSLFNBQVMsU0FDWDtDQUNBLGFBQWE7RUFDWDtHQUFFLE1BQU07R0FBUyxLQUFLO0VBQU87RUFDN0I7RUFDQTtFQUNBO0NBQ0Y7Q0FDQSxVQUFVLENBQUMsT0FBTyxTQUFRO0NBQzFCLFFBQVEsTUFBTSxLQUFLO0VBQ2pCLEtBQUsscUJBQXFCLGdCQUFnQixLQUFLLG9CQUFvQixLQUFLLGlCQUFpQjtFQUN6RixPQUFPO0NBQ1Q7Q0FDQSxnQkFBZ0IsTUFBTSxFQUFFLFFBQVE7RUFDOUIsTUFBTSxVQUFVLEtBQUssZ0JBQWdCO0VBQ3JDLE1BQU0sVUFBVSxLQUFLLGdCQUFnQjtFQUNyQyxJQUFJLFNBQ0YsV0FBVyxNQUFNLG9CQUFvQixZQUFZLE9BQU8sQ0FBQztPQUN0RCxJQUFJLFNBQ1AsV0FBVyxNQUFNLG9CQUFvQixZQUFZLE9BQU8sQ0FBQztFQUMzRCxJQUFJLFNBQVMsUUFDWCxXQUFXLE1BQU0sVUFBVSxRQUFRLE1BQU07RUFDM0MsT0FBTztDQUNUO0FBQ0YsQ0FBQztBQUdELElBQU0sa0JBQWtCLHdDQUF3QjtDQUM5QyxVQUFVLEVBQ1IsU0FBUyxVQUNYO0NBQ0EsYUFBYTtFQUNYO0VBQ0E7RUFDQTtHQUFFLE1BQU07R0FBUyxLQUFLO0VBQU87Q0FDL0I7Q0FDQSxVQUFVLENBQUMsT0FBTyxVQUFTO0NBQzNCLFFBQVEsTUFBTSxLQUFLO0VBQ2pCLG1CQUFtQixNQUFNLFNBQVM7RUFDbEMsS0FBSyxTQUFTLGdCQUFnQixLQUFLLFFBQVEsS0FBSyxhQUFhO0VBQzdELEtBQUssa0JBQWtCLGdCQUFnQixLQUFLLGlCQUFpQixLQUFLLHVCQUF1QjtFQUN6RixLQUFLLFNBQVMsZ0JBQWdCLEtBQUssUUFBUSxLQUFLLGNBQWM7RUFDOUQsT0FBTztDQUNUO0NBQ0EsZ0JBQWdCLFNBQVMsRUFBRSxRQUFRO0VBQ2pDLE1BQU0sVUFBVSxLQUFLLGdCQUFnQjtFQUNyQyxNQUFNLFdBQVcsS0FBSyxVQUFVO0VBQ2hDLElBQUksVUFDRixXQUFXLFNBQVMsWUFBWSxZQUFZLFFBQVEsQ0FBQztFQUN2RCxJQUFJLFVBQ0YsV0FBVyxTQUFTLFNBQVMsWUFBWSxRQUFRLENBQUM7RUFDcEQsSUFBSSxTQUNGLFdBQVcsU0FBUyxvQkFBb0IsWUFBWSxPQUFPLENBQUM7RUFDOUQsT0FBTztDQUNUO0FBQ0YsQ0FBQztBQUVELElBQU0sc0JBQXNCLHdDQUF3QjtDQUNsRCxVQUFVLEVBQ1IsU0FBUyxzQkFDWDtDQUNBLFFBQVEsTUFBTSxLQUFLO0VBQ2pCLG1CQUFtQixNQUFNLHFCQUFxQjtFQUM5QyxLQUFLLFNBQVMsZ0JBQWdCLEtBQUssUUFBUSxLQUFLLGFBQWE7RUFDN0QsS0FBSyxrQkFBa0IsZ0JBQWdCLEtBQUssaUJBQWlCLEtBQUssdUJBQXVCO0VBQ3pGLEtBQUssU0FBUyxnQkFBZ0IsS0FBSyxRQUFRLEtBQUssY0FBYztFQUM5RCxPQUFPO0NBQ1Q7QUFDRixDQUFDO0FBRUQsSUFBTSxvQkFBb0Isd0NBQXdCO0NBQ2hELFVBQVUsRUFDUixTQUFTLFlBQ1g7Q0FDQSxRQUFRLE1BQU0sS0FBSztFQUNqQixLQUFLLFFBQVEsZ0JBQWdCLEtBQUssT0FBTyxLQUFLLGNBQWM7RUFDNUQsS0FBSyxXQUFXLGdCQUFnQixLQUFLLFVBQVUsS0FBSyxjQUFjO0VBQ2xFLEtBQUssVUFBVSxnQkFBZ0IsS0FBSyxTQUFTLEtBQUssY0FBYztFQUNoRSxLQUFLLFFBQVEsZ0JBQWdCLEtBQUssT0FBTyxLQUFLLGFBQWE7RUFDM0QsS0FBSyxrQkFBa0IsZ0JBQWdCLEtBQUssaUJBQWlCLEtBQUssdUJBQXVCO0VBQ3pGLEtBQUssU0FBUyxnQkFBZ0IsS0FBSyxRQUFRLEtBQUssY0FBYztFQUM5RCxJQUFJLEtBQUssZUFDUCxLQUFLLGdCQUFnQixvQkFBb0IsS0FBSyxhQUFhO0VBQzdELElBQUksS0FBSyxZQUNQLEtBQUssYUFBYSxvQkFBb0IsS0FBSyxVQUFVO0VBQ3ZELE9BQU87Q0FDVDtBQUNGLENBQUM7QUFFRCxJQUFNLG1CQUFtQix3Q0FBd0I7Q0FDL0MsVUFBVSxFQUNSLFNBQVMsV0FDWDtDQUNBLFFBQVEsTUFBTSxLQUFLO0VBQ2pCLEtBQUssUUFBUSxnQkFBZ0IsS0FBSyxPQUFPLEtBQUssY0FBYztFQUM1RCxLQUFLLFdBQVcsZ0JBQWdCLEtBQUssVUFBVSxLQUFLLGNBQWM7RUFDbEUsS0FBSyxvQkFBb0IsZ0JBQWdCLEtBQUssbUJBQW1CLEtBQUssb0JBQW9CO0VBQzFGLEtBQUssa0JBQWtCLGdCQUFnQixLQUFLLGlCQUFpQixLQUFLLHVCQUF1QjtFQUN6RixLQUFLLFVBQVUsZ0JBQWdCLEtBQUssU0FBUyxLQUFLLGFBQWE7RUFDL0QsSUFBSSxLQUFLLGVBQ1AsS0FBSyxnQkFBZ0Isb0JBQW9CLEtBQUssYUFBYTtFQUM3RCxJQUFJLEtBQUssV0FDUCxLQUFLLFlBQVksb0JBQW9CLEtBQUssU0FBUztFQUNyRCxJQUFJLEtBQUssU0FDUCxLQUFLLFVBQVUsb0JBQW9CLEtBQUssT0FBTztFQUNqRCxPQUFPO0NBQ1Q7QUFDRixDQUFDO0FBRUQsSUFBTSxtQkFBbUIsd0NBQXdCO0NBQy9DLFVBQVUsRUFDUixTQUFTLFdBQ1g7Q0FDQSxRQUFRLE1BQU0sS0FBSztFQUNqQixLQUFLLFFBQVEsZ0JBQWdCLEtBQUssT0FBTyxLQUFLLGNBQWM7RUFDNUQsS0FBSyxXQUFXLGdCQUFnQixLQUFLLFVBQVUsS0FBSyxjQUFjO0VBQ2xFLEtBQUssVUFBVSxnQkFBZ0IsS0FBSyxTQUFTLEtBQUssY0FBYztFQUNoRSxLQUFLLG9CQUFvQixnQkFBZ0IsS0FBSyxtQkFBbUIsS0FBSyxvQkFBb0I7RUFDMUYsS0FBSyxrQkFBa0IsZ0JBQWdCLEtBQUssaUJBQWlCLEtBQUssdUJBQXVCO0VBQ3pGLEtBQUssVUFBVSxnQkFBZ0IsS0FBSyxTQUFTLEtBQUssYUFBYTtFQUMvRCxJQUFJLEtBQUssZUFDUCxLQUFLLGdCQUFnQixvQkFBb0IsS0FBSyxhQUFhO0VBQzdELElBQUksS0FBSyxXQUNQLEtBQUssWUFBWSxvQkFBb0IsS0FBSyxTQUFTO0VBQ3JELElBQUksS0FBSyxTQUNQLEtBQUssVUFBVSxvQkFBb0IsS0FBSyxPQUFPO0VBQ2pELE9BQU87Q0FDVDtBQUNGLENBQUM7QUFFRCxTQUFTLGFBQWEsUUFBUSxRQUFRO0NBQ3BDLE1BQU0sU0FBUyxFQUFFLEdBQUcsT0FBTztDQUMzQixLQUFLLE1BQU0sT0FBTyxRQUFRO0VBQ3hCLElBQUksQ0FBQyxPQUFPLE9BQU8sUUFBUSxHQUFHLEtBQUssT0FBTyxTQUFTLEtBQUssS0FBSyxRQUFRLGVBQWUsUUFBUSxpQkFBaUIsUUFBUSxhQUNuSDtFQUVGLElBRHVCLE9BQU8sUUFBUSxPQUFPLE9BQU8sU0FBUyxZQUFZLE9BQU8sT0FBTyxTQUFTLFlBQVksQ0FBQyxNQUFNLFFBQVEsT0FBTyxJQUFJLEtBQUssQ0FBQyxNQUFNLFFBQVEsT0FBTyxJQUFJLEdBRW5LLE9BQU8sT0FBTyxhQUFhLE9BQU8sTUFBTSxPQUFPLElBQUk7T0FDaEQsSUFBSSxDQUFDLE9BQU8sTUFDZixPQUFPLE9BQU8sT0FBTztDQUN6QjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsZUFBZSxLQUFLO0NBQzNCLE9BQU8sSUFBSSxRQUFRLFlBQVksSUFBSSxNQUFNLFNBQVMseUJBQXlCLElBQUksTUFBTSxTQUFTLElBQUksUUFBUTtBQUM1RztBQUNBLFNBQVMsZ0JBQWdCLFNBQVMsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxJQUFJLFNBQVM7Q0FDaEUsU0FBUyxZQUFZLEVBQUUsR0FBRyxPQUFPLENBQUM7Q0FDbEMsSUFBSTtDQUNKLElBQUksZUFBZSxDQUFDO0NBQ3BCLE9BQU8sa0JBQWtCLFNBQVM7RUFDaEMsS0FBSyxJQUFJLG9CQUFvQjtFQUM3QixTQUFTLFdBQVcsS0FBSztHQUN2QixJQUFJLElBQUksUUFBUSxZQUFZLElBQUksTUFBTSxTQUFTLHlCQUF5QixJQUFJLE1BQU0sT0FBTztJQUN2RixNQUFNLFFBQVEsSUFBSSxNQUFNO0lBQ3hCLEtBQUssTUFBTSxRQUFRLE1BQU0sUUFBUSxLQUFLLElBQUksUUFBUSxDQUFDLEtBQUssR0FBRztLQUN6RCxJQUFJLE9BQU8sU0FBUyxZQUFZLFNBQVMsTUFDdkM7S0FFRixNQUFNLFVBQVU7TUFDZCxHQUFHO01BQ0gsaUJBQWlCLElBQUk7S0FDdkI7S0FDQSxNQUFNLEtBQUssT0FBTztJQUNwQjtJQUNBLElBQUksY0FBYyxJQUFJLGdCQUFnQixPQUFPLGdCQUFnQixTQUFTLFNBQVM7R0FDakY7R0FDQSxJQUFJLElBQUksUUFBUSxlQUFlLE9BQU8sSUFBSSxNQUFNLFNBQVMsVUFDdkQsYUFBYSxhQUFhLElBQUksTUFBTTtRQUMvQixJQUFJLElBQUksUUFBUSxXQUFXLElBQUksZUFBZSxRQUFRLE9BQU8sSUFBSSxnQkFBZ0IsWUFDdEYsYUFBYSxRQUFRLE9BQU8sSUFBSSxXQUFXO1FBQ3RDLElBQUksSUFBSSxRQUFRLFVBQVUsSUFBSSxNQUFNLFNBQVMsaUJBQWlCLE9BQU8sSUFBSSxNQUFNLFlBQVksVUFDaEcsYUFBYSxjQUFjLElBQUksTUFBTTtRQUNoQyxJQUFJLElBQUksUUFBUSxVQUFVLElBQUksTUFBTSxRQUFRLGVBQWUsT0FBTyxJQUFJLE1BQU0sU0FBUyxVQUFVO0lBQ3BHLGFBQWEsTUFBTSxJQUFJLE1BQU07SUFDN0IsSUFBSSxhQUFhLE9BQU8sQ0FBQyxhQUFhLE1BQ3BDLElBQUk7S0FDRixhQUFhLE9BQU8sSUFBSSxJQUFJLGFBQWEsR0FBRyxDQUFDLENBQUM7SUFDaEQsUUFBUSxDQUNSO0dBRUosT0FBTyxJQUFJLElBQUksUUFBUSxVQUFVLElBQUksTUFBTSxhQUFhLGNBQWMsT0FBTyxJQUFJLE1BQU0sWUFBWSxVQUNqRyxhQUFhLFFBQVEsSUFBSSxNQUFNO1FBQzFCLElBQUksSUFBSSxRQUFRLG9CQUFvQixJQUFJLE1BQU0sV0FDbkQsZUFBZTtJQUNiLEdBQUc7SUFDSCxHQUFHLElBQUksTUFBTTtHQUNmO0VBRUo7RUFDQSxPQUFPO0dBQ0wsS0FBSztHQUNMLE9BQU87SUFDTCxvQkFBb0IsUUFBUTtLQUMxQixRQUFRLFNBQVMscUJBQXFCO0tBQ3RDLE1BQU0sUUFBUSxDQUFDO0tBQ2YsTUFBTSxVQUFVLE1BQU07S0FDdEIsZUFBZSxDQUFDO0tBQ2hCLEtBQUssTUFBTSxTQUFTLElBQUksU0FDdEIsSUFBSSxNQUFNLE9BQU87TUFDZixJQUFJLE1BQU0sTUFBTSxLQUFLLGNBQWMsR0FBRztPQUNwQyxPQUFPLE1BQU07T0FDYjtNQUNGO01BQ0EsS0FBSyxNQUFNLE9BQU8sTUFBTSxPQUN0QixXQUFXLEdBQUc7S0FDbEI7SUFFSjtJQUNBLHNCQUFzQixFQUFFLFdBQVc7S0FDakMsS0FBSyxNQUFNLE9BQU8sTUFDaEIsV0FBVyxHQUFHO0lBQ2xCO0lBQ0EsaUJBQWlCLFFBQVE7S0FDdkIsS0FBSyxNQUFNLEtBQUssSUFBSSxNQUFNO01BQ3hCLE1BQU0sTUFBTSxJQUFJLEtBQUs7TUFDckIsSUFBSSxJQUFJLFFBQVEsWUFBWSxJQUFJLE1BQU0sU0FBUyx5QkFBeUIsSUFBSSxNQUFNLE9BQU87T0FDdkYsT0FBTyxJQUFJLE1BQU07T0FDakIsTUFBTSxnQkFBZ0IsTUFBTSxhQUFhO1FBQUUsR0FBRyxPQUFPLEtBQUssQ0FBQztRQUFHLEdBQUc7UUFBUSxHQUFHO09BQWEsQ0FBQztPQUMxRixJQUFJLENBQUMsY0FBYyxRQUFRO1FBQ3pCLElBQUksUUFBUSxDQUFDO1FBQ2I7T0FDRjtPQUNBLE1BQU0sU0FBUyxTQUFTLFVBQVU7T0FDbEMsSUFBSSxZQUFZLEtBQUssVUFBVTtRQUM3QixZQUFZO1FBQ1osVUFBVTtPQUNaLElBQUksR0FBRyxVQUFVO1FBQ2YsSUFBSSxPQUFPLFVBQVUsVUFDbkIsT0FBTyxzQkFBc0IsT0FBTyxLQUFLLGlCQUFpQixLQUFLLFVBQVU7UUFDM0UsT0FBTztPQUNULEdBQUcsU0FBUyxJQUFJLENBQUM7T0FDakI7TUFDRjtLQUNGO0lBQ0Y7SUFDQSxzQkFBc0IsUUFBUTtLQUM1QixJQUFJO0tBQ0osSUFBSTtLQUNKLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQUssUUFBUSxLQUFLO01BQ3hDLE1BQU0sTUFBTSxJQUFJLEtBQUs7TUFDckIsSUFBSSxDQUFDLEtBQUssT0FDUjtNQUNGLElBQUksZUFBZSxHQUFHLEdBQUc7T0FDdkIsT0FBTyxJQUFJLE1BQU07T0FDakIsSUFBSSxPQUFPLGlCQUFpQixhQUFhO1FBQ3ZDLGVBQWU7UUFDZjtPQUNGO09BQ0EsSUFBSSxLQUFLLGFBQWEsQ0FBQyxRQUFRLGFBQWEsSUFBSSxLQUFLLGFBQWEsQ0FBQyxPQUFPLElBQUksS0FBSztPQUNuRixPQUFPLElBQUksS0FBSyxhQUFhLENBQUMsTUFBTTtPQUNwQyxDQUFDLDZCQUE2QixJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7TUFDaEQ7S0FDRjtLQUNBLElBQUksVUFDRixJQUFJLE9BQU8sSUFBSSxLQUFLLFFBQVEsR0FBRyxNQUFNLENBQUMsU0FBUyxJQUFJLENBQUMsQ0FBQztJQUN6RDtHQUNGO0VBQ0Y7Q0FDRixHQUFHLFlBQVk7QUFDakI7QUFrSkEsU0FBUyx3QkFBd0IsT0FBTztDQUN0QyxNQUFNLFNBQVMsT0FBTztDQUN0QixNQUFNLFFBQVEsU0FBUztDQUN2QixJQUFJLE1BQU0sUUFBUSxNQUFNLEtBQUssT0FBTyxXQUFXLEtBQUssU0FBUyxPQUFPLFVBQVUsWUFBWSxNQUFNLFNBQVMseUJBQXlCLE1BQU0sUUFBUSxzQkFBc0IsV0FBVyxPQUMvSyxPQUFPO0NBRVQsT0FBTyxFQUNMLFFBQVEsQ0FDTjtFQUNFLE1BQU07RUFDTixLQUFLO0VBQ0wsT0FBTztDQUNULENBQ0YsRUFDRjtBQUNGOzs7QUNoaEVBLElBQU0sdUJBQXVCLENBQzNCO0NBQ0UsTUFBTTtDQUNOLFNBQVM7RUNKWDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0QzQ1c7QUFDWCxDQUNGO0FBQ0EsSUFBTSxzQkFBc0I7Q0FDMUI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGO0FBQ0EsU0FBUyxrQkFBa0IsVUFBVSxDQUFDLEdBQUc7Q0FDdkMsTUFBTSxFQUFFLFNBQVMsT0FBTztDQUN4QixPQUFPO0VBQ0wsTUFBTTtFQUNOLFVBQVUsU0FBUztHQUNqQixJQUFJLEtBQUssV0FBVyxNQUFNLEdBQUc7SUFDM0IsTUFBTSxnQkFBZ0IsS0FBSyxVQUFVLE9BQU8sTUFBTTtJQUNsRCxJQUFJLG9CQUFvQixTQUFTLGFBQWEsR0FDNUMsT0FBTztLQUNMLE1BQU07S0FDTixNQUFNO0lBQ1I7R0FFSjtFQUNGO0NBQ0Y7QUFDRjs7O0FFekNBLFNBQVMsYUFBYSxPQUFPLFVBQVU7Q0FDckMsT0FBTztFQUFFLEdBQUc7RUFBTyxXQUFXO0NBQVM7QUFDekM7QUFDQSxTQUFTLGdCQUFnQixPQUFPLFVBQVU7Q0FDeEMsTUFBTSxnQkFBZ0IsU0FBUyxDQUFDO0NBQ2hDLElBQUksTUFBTSxhQUFhLEdBQ3JCLE9BQU8sZUFBZTtFQUNwQixNQUFNLFFBQVEsY0FBYztFQUM1QixPQUFPLFNBQVMsT0FBTyxVQUFVLFdBQVcsYUFBYSxPQUFPLFFBQVEsSUFBSTtDQUM5RSxDQUFDO0NBRUgsT0FBTyxhQUFhLGVBQWUsUUFBUTtBQUM3QztBQUNBLFNBQVMsY0FBYyxPQUFPO0NBQzVCLE9BQU8sZ0JBQWdCLE9BQU8sZUFBZTtBQUMvQztBQUNBLFNBQVMscUJBQXFCLE9BQU87Q0FDbkMsT0FBTyxnQkFBZ0IsT0FBTyxzQkFBc0I7QUFDdEQ7QUFDQSxTQUFTLHNCQUFzQixPQUFPO0NBQ3BDLE9BQU8sZ0JBQWdCLE9BQU8sdUJBQXVCO0FBQ3ZEO0FBQ0EsU0FBUyxjQUFjLE9BQU87Q0FDNUIsT0FBTyxnQkFBZ0IsT0FBTyxlQUFlO0FBQy9DO0FBQ0EsU0FBUyxpQkFBaUIsT0FBTztDQUMvQixPQUFPLGdCQUFnQixPQUFPLGtCQUFrQjtBQUNsRDtBQUNBLFNBQVMsY0FBYyxPQUFPO0NBQzVCLE9BQU8sZ0JBQWdCLE9BQU8sZUFBZTtBQUMvQztBQUNBLFNBQVMsWUFBWSxPQUFPO0NBQzFCLE9BQU8sZ0JBQWdCLE9BQU8sYUFBYTtBQUM3QztBQUNBLFNBQVMsd0JBQXdCLE9BQU87Q0FDdEMsT0FBTyxnQkFBZ0IsT0FBTyx5QkFBeUI7QUFDekQ7QUFDQSxTQUFTLHNCQUFzQixPQUFPO0NBQ3BDLE9BQU8sZ0JBQWdCLE9BQU8sdUJBQXVCO0FBQ3ZEO0FBQ0EsU0FBUyxZQUFZLE9BQU87Q0FDMUIsT0FBTyxnQkFBZ0IsT0FBTyxhQUFhO0FBQzdDO0FBQ0EsU0FBUyxZQUFZLE9BQU87Q0FDMUIsT0FBTyxnQkFBZ0IsT0FBTyxhQUFhO0FBQzdDO0FBQ0EsU0FBUyxnQkFBZ0IsT0FBTztDQUM5QixPQUFPLGdCQUFnQixPQUFPLGlCQUFpQjtBQUNqRDtBQUNBLFNBQVMsWUFBWSxPQUFPO0NBQzFCLE9BQU8sZ0JBQWdCLE9BQU8sYUFBYTtBQUM3QztBQUNBLFNBQVMsaUJBQWlCLE9BQU87Q0FDL0IsT0FBTyxnQkFBZ0IsT0FBTyxrQkFBa0I7QUFDbEQ7QUFDQSxTQUFTLG9CQUFvQixPQUFPO0NBQ2xDLE9BQU8sZ0JBQWdCLE9BQU8scUJBQXFCO0FBQ3JEO0FBQ0EsU0FBUyxZQUFZLE9BQU87Q0FDMUIsT0FBTyxnQkFBZ0IsT0FBTyxhQUFhO0FBQzdDO0FBQ0EsU0FBUyxtQkFBbUIsT0FBTztDQUNqQyxPQUFPLGdCQUFnQixPQUFPLG9CQUFvQjtBQUNwRDtBQUNBLFNBQVMsbUJBQW1CLE9BQU87Q0FDakMsT0FBTyxnQkFBZ0IsT0FBTyxvQkFBb0I7QUFDcEQ7QUFDQSxTQUFTLGFBQWEsT0FBTztDQUMzQixPQUFPLGdCQUFnQixPQUFPLGNBQWM7QUFDOUM7QUFDQSxTQUFTLGNBQWMsT0FBTztDQUM1QixPQUFPLGdCQUFnQixPQUFPLGVBQWU7QUFDL0M7QUFDQSxTQUFTLGVBQWUsT0FBTztDQUM3QixPQUFPLGdCQUFnQixPQUFPLGdCQUFnQjtBQUNoRDtBQUNBLFNBQVMsYUFBYSxPQUFPO0NBQzNCLE9BQU8sZ0JBQWdCLE9BQU8sY0FBYztBQUM5QztBQUNBLFNBQVMsYUFBYSxPQUFPO0NBQzNCLE9BQU8sZ0JBQWdCLE9BQU8sY0FBYztBQUM5QztBQUNBLFNBQVMsWUFBWSxPQUFPO0NBQzFCLE9BQU8sZ0JBQWdCLE9BQU8sYUFBYTtBQUM3QztBQUNBLFNBQVMsY0FBYyxPQUFPO0NBQzVCLE9BQU8sZ0JBQWdCLE9BQU8sZUFBZTtBQUMvQztBQUNBLFNBQVMsY0FBYyxPQUFPO0NBQzVCLE9BQU8sZ0JBQWdCLE9BQU8sZUFBZTtBQUMvQztBQUNBLFNBQVMsV0FBVyxPQUFPO0NBQ3pCLE9BQU8sZ0JBQWdCLE9BQU8sWUFBWTtBQUM1QztBQUNBLFNBQVMsYUFBYSxPQUFPO0NBQzNCLE9BQU8sZ0JBQWdCLE9BQU8sY0FBYztBQUM5QztBQUNBLFNBQVMsZUFBZSxPQUFPO0NBQzdCLE9BQU8sZ0JBQWdCLE9BQU8sZ0JBQWdCO0FBQ2hEO0FBQ0EsU0FBUyxlQUFlLE9BQU87Q0FDN0IsT0FBTyxnQkFBZ0IsT0FBTyxnQkFBZ0I7QUFDaEQ7QUFDQSxTQUFTLFlBQVksT0FBTztDQUMxQixPQUFPLGdCQUFnQixPQUFPLGFBQWE7QUFDN0M7QUFDQSxTQUFTLG1CQUFtQixPQUFPO0NBQ2pDLE9BQU8sZ0JBQWdCLE9BQU8sb0JBQW9CO0FBQ3BEO0FBQ0EsU0FBUyxpQkFBaUIsT0FBTztDQUMvQixPQUFPLGdCQUFnQixPQUFPLGtCQUFrQjtBQUNsRDtBQUNBLFNBQVMsa0JBQWtCLE9BQU87Q0FDaEMsT0FBTyxnQkFBZ0IsT0FBTyxtQkFBbUI7QUFDbkQ7QUFDQSxTQUFTLGtCQUFrQixPQUFPO0NBQ2hDLE9BQU8sZ0JBQWdCLE9BQU8sbUJBQW1CO0FBQ25EO0FBQ0EsU0FBUyxjQUFjLE9BQU87Q0FDNUIsT0FBTyxnQkFBZ0IsT0FBTyxlQUFlO0FBQy9DO0FBQ0EsU0FBUyxxQkFBcUIsT0FBTztDQUNuQyxPQUFPLGdCQUFnQixPQUFPLHNCQUFzQjtBQUN0RDtBQUNBLFNBQVMsaUJBQWlCLE9BQU87Q0FDL0IsT0FBTyxnQkFBZ0IsT0FBTyxrQkFBa0I7QUFDbEQ7QUFDQSxTQUFTLGlCQUFpQixPQUFPO0NBQy9CLE9BQU8sZ0JBQWdCLE9BQU8sa0JBQWtCO0FBQ2xEO0FBQ0EsU0FBUyxvQkFBb0IsT0FBTztDQUNsQyxPQUFPLGdCQUFnQixPQUFPLHFCQUFxQjtBQUNyRDtBQUNBLFNBQVMsb0JBQW9CLE9BQU87Q0FDbEMsT0FBTyxnQkFBZ0IsT0FBTyxxQkFBcUI7QUFDckQ7QUFDQSxTQUFTLHFCQUFxQixPQUFPO0NBQ25DLE9BQU8sZ0JBQWdCLE9BQU8sc0JBQXNCO0FBQ3REO0FBQ0EsU0FBUyxvQkFBb0IsT0FBTztDQUNsQyxPQUFPLGdCQUFnQixPQUFPLHFCQUFxQjtBQUNyRDtBQUNBLFNBQVMsZUFBZSxPQUFPO0NBQzdCLE9BQU8sZ0JBQWdCLE9BQU8sZ0JBQWdCO0FBQ2hEO0FBQ0EsU0FBUyxlQUFlLE9BQU87Q0FDN0IsT0FBTyxnQkFBZ0IsT0FBTyxnQkFBZ0I7QUFDaEQ7QUFDQSxTQUFTLGdCQUFnQixPQUFPO0NBQzlCLE9BQU8sZ0JBQWdCLE9BQU8saUJBQWlCO0FBQ2pEO0FBQ0EsU0FBUyxjQUFjLE9BQU87Q0FDNUIsT0FBTyxnQkFBZ0IsT0FBTyxlQUFlO0FBQy9DO0FBQ0EsU0FBUyxhQUFhLFFBQVEsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxHQUFHO0NBRTlDLENBRGUsUUFBUSxRQUFRLFdBQVcsR0FDbkMsSUFBSSxnQkFBZ0IsQ0FBQztDQUM1QixNQUFNLFFBQVEsUUFBUSx3QkFBd0IsS0FBSyxHQUFHLE9BQU87Q0FDN0QsTUFBTSxZQUFZLE1BQU07Q0FDeEIsTUFBTSxjQUFjO0NBQ3BCLFlBQVksU0FBUyxXQUFXLFVBQVUsd0JBQXdCLE1BQU0sQ0FBQztDQUN6RSxPQUFPO0FBQ1Q7QUFFQSxJQUFNLFdBQVc7QUFDakIsU0FBUyxvQkFBb0IsT0FBTztDQUNsQyxJQUFJLE9BQU87Q0FDWCxLQUFLLE1BQU0sUUFBUSxPQUNqQixJQUFJLE9BQU8sS0FBSyxhQUFhLFVBQzNCLFFBQVEsS0FBSyxTQUFTLEtBQUs7Q0FFL0IsT0FBTztBQUNUO0FBQ0EsU0FBUyxPQUFPLEdBQUc7Q0FDakIsSUFBSSxNQUFNLEVBQUUsUUFBUSxXQUFXLE1BQU0sRUFBRSxFQUFFLENBQUMsWUFBWSxDQUFDO0NBQ3ZELElBQUksUUFBUSxVQUFVLFFBQVEsTUFDNUIsTUFBTSxJQUFJO0NBQ1osT0FBTztBQUNUO0FBQ0EsU0FBUyxVQUFVLEdBQUc7Q0FDcEIsSUFBSSxFQUFFLFdBQVcsT0FBTyxLQUFLLEVBQUUsV0FBVyxPQUFPLEdBQy9DLE9BQU87Q0FDVCxPQUFPLE1BQU0sV0FBVyxNQUFNO0FBQ2hDO0FBQ0EsU0FBUyx5QkFBeUIsTUFBTSxVQUFVO0NBQ2hELE9BQU8sZ0JBQWdCO0VBQ3JCO0VBQ0EsT0FBTyxFQUNMLElBQUksT0FDTjtFQUNBLE1BQU0sT0FBTyxFQUFFLE9BQU8sU0FBUztHQUM3QixNQUFNLE9BQU8sSUFBSSxJQUFJO0dBQ3JCLE1BQU0sY0FBYyxlQUFlO0lBQ2pDLE1BQU0sTUFBTSxDQUFDO0lBQ2IsT0FBTyxRQUFRLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxXQUFXO0tBQ3JELElBQUksQ0FBQyxVQUFVLEdBQUcsR0FDaEIsSUFBSSxPQUFPLEdBQUcsS0FBSyxNQUFNLEtBQUs7SUFFbEMsQ0FBQztJQUNELElBQUksQ0FBQyxLQUFLLE9BQ1IsS0FBSyxNQUFNLENBQUMsS0FBSyxTQUFTLE9BQU8sUUFBUSxLQUFLLEdBQUc7S0FDL0MsSUFBSSxDQUFDLFFBQVEsUUFBUSxXQUNuQjtLQUNGLElBQUksT0FBTyxHQUFHLEtBQUssb0JBQW9CLEtBQUssS0FBSyxDQUFDO0lBQ3BEO0lBRUYsT0FBTztHQUNULENBQUM7R0FDRCxJQUFJLFVBQ0YsYUFBYSxTQUFTLE1BQU0sV0FBVyxDQUFDLENBQUM7R0FFM0MsYUFBYTtJQUNYLE1BQU0sT0FBTyxNQUFNLFdBQVc7SUFDOUIsSUFBSSxDQUFDLE1BQU0sU0FDVCxPQUFPO0lBQ1QsTUFBTSxhQUFhLENBQUM7SUFDcEIsSUFBSSxNQUFNLFNBQ1IsV0FBVyxLQUFLLE1BQU0sUUFBUSxJQUFJLENBQUM7SUFDckMsT0FBTyxFQUFFLE1BQU0sTUFBTSxPQUFPLENBQUMsR0FBRyxVQUFVO0dBQzVDO0VBQ0Y7Q0FDRixDQUFDO0FBQ0g7QUFDQSxJQUFNLG1CQUFtQyx5Q0FBeUIsb0JBQW9CLGFBQWE7QUFDbkcsSUFBTSxzQkFBc0MseUNBQXlCLHVCQUF1QixnQkFBZ0I7QUFDNUcsSUFBTSxtQkFBbUMseUNBQXlCLG9CQUFvQixhQUFhO0FBQ25HLElBQU0saUJBQWlDLHlDQUF5QixrQkFBa0IsV0FBVztBQUM3RixJQUFNLDZCQUE2Qyx5Q0FBeUIsOEJBQThCLHVCQUF1QjtBQUNqSSxJQUFNLGlCQUFpQyx5Q0FBeUIsa0JBQWtCLFdBQVc7QUFDN0YsSUFBTSxpQkFBaUMseUNBQXlCLGtCQUFrQixXQUFXO0FBQzdGLElBQU0sc0JBQXNDLHlDQUF5Qix1QkFBdUIsZ0JBQWdCO0FBQzVHLElBQU0seUJBQXlDLHlDQUF5QiwwQkFBMEIsbUJBQW1CO0FBQ3JILElBQU0sd0JBQXdDLHlDQUF5Qix5QkFBeUIsa0JBQWtCO0FBQ2xILElBQU0sa0JBQWtDLHlDQUF5QixtQkFBbUIsWUFBWTtBQUNoRyxJQUFNLG1CQUFtQyx5Q0FBeUIsb0JBQW9CLGFBQWE7QUFDbkcsSUFBTSxvQkFBb0MseUNBQXlCLHFCQUFxQixjQUFjO0FBQ3RHLElBQU0sa0JBQWtDLHlDQUF5QixtQkFBbUIsWUFBWTtBQUNoRyxJQUFNLGtCQUFrQyx5Q0FBeUIsbUJBQW1CLFlBQVk7QUFDaEcsSUFBTSxpQkFBaUMseUNBQXlCLGtCQUFrQixXQUFXO0FBQzdGLElBQU0sbUJBQW1DLHlDQUF5QixvQkFBb0IsYUFBYTtBQUNuRyxJQUFNLG1CQUFtQyx5Q0FBeUIsb0JBQW9CLGFBQWE7QUFDbkcsSUFBTSxpQkFBaUMseUNBQXlCLGtCQUFrQixXQUFXO0FBQzdGLElBQU0sa0JBQWtDLHlDQUF5QixtQkFBbUIsWUFBWTtBQUNoRyxJQUFNLG9CQUFvQyx5Q0FBeUIscUJBQXFCLGNBQWM7QUFDdEcsSUFBTSxnQkFBZ0MseUNBQXlCLGlCQUFpQixVQUFVO0FBQzFGLElBQU0sdUJBQXVDLHlDQUF5Qix3QkFBd0IsaUJBQWlCIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbMCwxLDIsM10sInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLnBucG0vbnV4dC1zY2hlbWEtb3JnQDYuMi44X2UxZWE5ZWZiYzE1NTAyNWZhYWNhNDE3ZGE1YTI2MTc1L25vZGVfbW9kdWxlcy9udXh0LXNjaGVtYS1vcmcvZGlzdC92ZW5kb3Ivc2NoZW1hLW9yZy12My9zaGFyZWQvc2NoZW1hLW9yZy5CZnl0TzVrTy5tanMiLCIuLi8uLi8uLi8uLi8ucG5wbS9udXh0LXNjaGVtYS1vcmdANi4yLjhfZTFlYTllZmJjMTU1MDI1ZmFhY2E0MTdkYTVhMjYxNzUvbm9kZV9tb2R1bGVzL251eHQtc2NoZW1hLW9yZy9kaXN0L3ZlbmRvci9zY2hlbWEtb3JnLXYzL3Z1ZS9tZXRhLm1qcyIsIi4uLy4uLy4uLy4uLy5wbnBtL251eHQtc2NoZW1hLW9yZ0A2LjIuOF9lMWVhOWVmYmMxNTUwMjVmYWFjYTQxN2RhNWEyNjE3NS9ub2RlX21vZHVsZXMvbnV4dC1zY2hlbWEtb3JnL2Rpc3QvdmVuZG9yL3NjaGVtYS1vcmctdjMvaW1wb3J0cy5tanMiLCIuLi8uLi8uLi8uLi8ucG5wbS9udXh0LXNjaGVtYS1vcmdANi4yLjhfZTFlYTllZmJjMTU1MDI1ZmFhY2E0MTdkYTVhMjYxNzUvbm9kZV9tb2R1bGVzL251eHQtc2NoZW1hLW9yZy9kaXN0L3ZlbmRvci9zY2hlbWEtb3JnLXYzL3Z1ZS5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZGVmaW5lSGVhZFBsdWdpbiwgVGVtcGxhdGVQYXJhbXNQbHVnaW4gfSBmcm9tICd1bmhlYWQvcGx1Z2lucyc7XG5pbXBvcnQgeyBwcm9jZXNzVGVtcGxhdGVQYXJhbXMgfSBmcm9tICd1bmhlYWQvdXRpbHMnO1xuXG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoc2NoZW1hKSB7XG4gIHJldHVybiBzY2hlbWE7XG59XG5cbmNvbnN0IFBST1RPQ09MX1JFID0gL15bXFxzXFx3XFwwKy4tXXsyLH06KD86Wy9cXFxcXXsyfSk/LztcbmNvbnN0IEpPSU5fTEVBRElOR19TTEFTSF9SRSA9IC9eXFwuP1xcLy87XG5mdW5jdGlvbiBoYXNQcm90b2NvbChpbnB1dCkge1xuICByZXR1cm4gUFJPVE9DT0xfUkUudGVzdChpbnB1dCk7XG59XG5mdW5jdGlvbiB3aXRob3V0VHJhaWxpbmdTbGFzaChpbnB1dCA9IFwiXCIpIHtcbiAgcmV0dXJuIChpbnB1dC5lbmRzV2l0aChcIi9cIikgPyBpbnB1dC5zbGljZSgwLCAtMSkgOiBpbnB1dCkgfHwgXCIvXCI7XG59XG5mdW5jdGlvbiB3aXRoVHJhaWxpbmdTbGFzaChpbnB1dCA9IFwiXCIpIHtcbiAgcmV0dXJuIGlucHV0LmVuZHNXaXRoKFwiL1wiKSA/IGlucHV0IDogYCR7aW5wdXR9L2A7XG59XG5mdW5jdGlvbiBqb2luVVJMKGJhc2UsIGlucHV0KSB7XG4gIGlmICghaW5wdXQgfHwgaW5wdXQgPT09IFwiL1wiKVxuICAgIHJldHVybiBiYXNlIHx8IFwiXCI7XG4gIHJldHVybiBiYXNlID8gd2l0aFRyYWlsaW5nU2xhc2goYmFzZSkgKyBpbnB1dC5yZXBsYWNlKEpPSU5fTEVBRElOR19TTEFTSF9SRSwgXCJcIikgOiBpbnB1dDtcbn1cbmZ1bmN0aW9uIHdpdGhCYXNlKGlucHV0LCBiYXNlKSB7XG4gIGlmICghYmFzZSB8fCBiYXNlID09PSBcIi9cIiB8fCBoYXNQcm90b2NvbChpbnB1dCkpXG4gICAgcmV0dXJuIGlucHV0O1xuICBjb25zdCBub3JtYWxpemVkQmFzZSA9IHdpdGhvdXRUcmFpbGluZ1NsYXNoKGJhc2UpO1xuICBpZiAoaW5wdXQuc3RhcnRzV2l0aChub3JtYWxpemVkQmFzZSkpIHtcbiAgICBjb25zdCBuZXh0Q2hhciA9IGlucHV0W25vcm1hbGl6ZWRCYXNlLmxlbmd0aF07XG4gICAgaWYgKCFuZXh0Q2hhciB8fCBuZXh0Q2hhciA9PT0gXCIvXCIgfHwgbmV4dENoYXIgPT09IFwiP1wiKVxuICAgICAgcmV0dXJuIGlucHV0O1xuICB9XG4gIHJldHVybiBqb2luVVJMKG5vcm1hbGl6ZWRCYXNlLCBpbnB1dCk7XG59XG5mdW5jdGlvbiBpZFJlZmVyZW5jZShub2RlKSB7XG4gIHJldHVybiB7XG4gICAgXCJAaWRcIjogdHlwZW9mIG5vZGUgIT09IFwic3RyaW5nXCIgPyBub2RlW1wiQGlkXCJdIDogbm9kZVxuICB9O1xufVxuZnVuY3Rpb24gcmVzb2x2YWJsZURhdGVUb0RhdGUodmFsKSB7XG4gIHRyeSB7XG4gICAgY29uc3QgZGF0ZSA9IHZhbCBpbnN0YW5jZW9mIERhdGUgPyB2YWwgOiBuZXcgRGF0ZShEYXRlLnBhcnNlKHZhbCkpO1xuICAgIGNvbnN0IG1vbnRoID0gU3RyaW5nKGRhdGUuZ2V0TW9udGgoKSArIDEpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcbiAgICBjb25zdCBkYXkgPSBTdHJpbmcoZGF0ZS5nZXREYXRlKCkpLnBhZFN0YXJ0KDIsIFwiMFwiKTtcbiAgICByZXR1cm4gYCR7ZGF0ZS5nZXRGdWxsWWVhcigpfS0ke21vbnRofS0ke2RheX1gO1xuICB9IGNhdGNoIHtcbiAgfVxuICByZXR1cm4gdHlwZW9mIHZhbCA9PT0gXCJzdHJpbmdcIiA/IHZhbCA6IHZhbC50b1N0cmluZygpO1xufVxuY29uc3QgSVNfVkFMSURfVzNDX0RBVEUgPSBbXG4gIC8oXFxkezR9LVswMV1cXGQtWzAtM11cXGRUWzAtMl1cXGQ6WzAtNV1cXGQ6WzAtNV1cXGRcXC5cXGQrKFsrLV1bMC0yXVxcZDpbMC01XVxcZHxaKSl8KFxcZHs0fS1bMDFdXFxkLVswLTNdXFxkVFswLTJdXFxkOlswLTVdXFxkOlswLTVdXFxkKFsrLV1bMC0yXVxcZDpbMC01XVxcZHxaKSl8KFxcZHs0fS1bMDFdXFxkLVswLTNdXFxkVFswLTJdXFxkOlswLTVdXFxkKFsrLV1bMC0yXVxcZDpbMC01XVxcZHxaKSkvLFxuICAvXlxcZHs0fS1bMDFdXFxkLVswLTNdXFxkJC8sXG4gIC9eXFxkezR9LVswMV1cXGQkLyxcbiAgL15cXGR7NH0kL1xuXTtcbmZ1bmN0aW9uIGlzVmFsaWRXM0NEYXRlKGQpIHtcbiAgcmV0dXJuIElTX1ZBTElEX1czQ19EQVRFLnNvbWUoKHIpID0+IHIudGVzdChkKSk7XG59XG5mdW5jdGlvbiByZXNvbHZhYmxlRGF0ZVRvSXNvKHZhbCkge1xuICBpZiAoIXZhbClcbiAgICByZXR1cm4gdmFsO1xuICB0cnkge1xuICAgIGlmICh2YWwgaW5zdGFuY2VvZiBEYXRlKVxuICAgICAgcmV0dXJuIHZhbC50b0lTT1N0cmluZygpO1xuICAgIGVsc2UgaWYgKGlzVmFsaWRXM0NEYXRlKHZhbCkpXG4gICAgICByZXR1cm4gdmFsO1xuICAgIGVsc2VcbiAgICAgIHJldHVybiBuZXcgRGF0ZShEYXRlLnBhcnNlKHZhbCkpLnRvSVNPU3RyaW5nKCk7XG4gIH0gY2F0Y2gge1xuICB9XG4gIHJldHVybiB0eXBlb2YgdmFsID09PSBcInN0cmluZ1wiID8gdmFsIDogdmFsLnRvU3RyaW5nKCk7XG59XG5jb25zdCBJZGVudGl0eUlkID0gXCIjaWRlbnRpdHlcIjtcbmZ1bmN0aW9uIHNldElmRW1wdHkobm9kZSwgZmllbGQsIHZhbHVlKSB7XG4gIGlmIChub2RlPy5bZmllbGRdID09PSB2b2lkIDAgJiYgdmFsdWUgIT0gbnVsbClcbiAgICBub2RlW2ZpZWxkXSA9IHZhbHVlO1xufVxuZnVuY3Rpb24gYXNBcnJheShpbnB1dCkge1xuICByZXR1cm4gQXJyYXkuaXNBcnJheShpbnB1dCkgPyBpbnB1dCA6IFtpbnB1dF07XG59XG5mdW5jdGlvbiBkZWR1cGVNZXJnZShub2RlLCBmaWVsZCwgdmFsdWUpIHtcbiAgY29uc3QgZGF0YSA9IG5ldyBTZXQoYXNBcnJheShub2RlW2ZpZWxkXSkpO1xuICBkYXRhLmFkZCh2YWx1ZSk7XG4gIG5vZGVbZmllbGRdID0gWy4uLmRhdGFdLmZpbHRlcihCb29sZWFuKTtcbn1cbmZ1bmN0aW9uIHByZWZpeElkKHVybCwgaWQpIHtcbiAgaWYgKGhhc1Byb3RvY29sKGlkKSlcbiAgICByZXR1cm4gaWQ7XG4gIGlmICghaWQuaW5jbHVkZXMoXCIjXCIpKVxuICAgIGlkID0gYCMke2lkfWA7XG4gIHJldHVybiBgJHt1cmwgfHwgXCJcIn0ke2lkfWA7XG59XG5mdW5jdGlvbiB0cmltTGVuZ3RoKHZhbCwgbGVuZ3RoKSB7XG4gIGlmICghdmFsKVxuICAgIHJldHVybiB2YWw7XG4gIGlmICh2YWwubGVuZ3RoID4gbGVuZ3RoKSB7XG4gICAgY29uc3QgdHJpbW1lZFN0cmluZyA9IHZhbC5zdWJzdHJpbmcoMCwgbGVuZ3RoKTtcbiAgICByZXR1cm4gdHJpbW1lZFN0cmluZy5zdWJzdHJpbmcoMCwgTWF0aC5taW4odHJpbW1lZFN0cmluZy5sZW5ndGgsIHRyaW1tZWRTdHJpbmcubGFzdEluZGV4T2YoXCIgXCIpKSk7XG4gIH1cbiAgcmV0dXJuIHZhbDtcbn1cbmZ1bmN0aW9uIHJlc29sdmVEZWZhdWx0VHlwZShub2RlLCBkZWZhdWx0VHlwZSkge1xuICBjb25zdCB2YWwgPSBub2RlW1wiQHR5cGVcIl07XG4gIGlmICh2YWwgPT09IGRlZmF1bHRUeXBlKVxuICAgIHJldHVybjtcbiAgaWYgKHR5cGVvZiB2YWwgPT09IFwic3RyaW5nXCIgJiYgdHlwZW9mIGRlZmF1bHRUeXBlID09PSBcInN0cmluZ1wiKSB7XG4gICAgaWYgKHZhbCAhPT0gZGVmYXVsdFR5cGUpXG4gICAgICBub2RlW1wiQHR5cGVcIl0gPSBbZGVmYXVsdFR5cGUsIHZhbF07XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHR5cGVzID0gbmV3IFNldChhc0FycmF5KGRlZmF1bHRUeXBlKSk7XG4gIGZvciAoY29uc3QgdCBvZiBhc0FycmF5KHZhbCkpXG4gICAgdHlwZXMuYWRkKHQpO1xuICBub2RlW1wiQHR5cGVcIl0gPSB0eXBlcy5zaXplID09PSAxID8gdmFsIDogWy4uLnR5cGVzXTtcbn1cbmZ1bmN0aW9uIHJlc29sdmVXaXRoQmFzZShiYXNlLCB1cmxPclBhdGgpIHtcbiAgaWYgKCFiYXNlIHx8ICF1cmxPclBhdGggfHwgaGFzUHJvdG9jb2wodXJsT3JQYXRoKSB8fCB1cmxPclBhdGhbMF0gIT09IFwiL1wiICYmIHVybE9yUGF0aFswXSAhPT0gXCIjXCIpXG4gICAgcmV0dXJuIHVybE9yUGF0aDtcbiAgcmV0dXJuIHdpdGhCYXNlKHVybE9yUGF0aCwgYmFzZSk7XG59XG5mdW5jdGlvbiByZXNvbHZlQXNHcmFwaEtleShrZXkpIHtcbiAgaWYgKCFrZXkpXG4gICAgcmV0dXJuIGtleTtcbiAgcmV0dXJuIGtleS5zdWJzdHJpbmcoa2V5Lmxhc3RJbmRleE9mKFwiI1wiKSk7XG59XG5mdW5jdGlvbiBzdHJpcEVtcHR5UHJvcGVydGllcyhvYmopIHtcbiAgZm9yIChjb25zdCBrIGluIG9iaikge1xuICAgIGlmICghT2JqZWN0Lmhhc093bihvYmosIGspKVxuICAgICAgY29udGludWU7XG4gICAgY29uc3QgdiA9IG9ialtrXTtcbiAgICBpZiAodiA9PT0gXCJcIiB8fCB2ID09PSB2b2lkIDApIHtcbiAgICAgIGRlbGV0ZSBvYmpba107XG4gICAgfSBlbHNlIGlmICh0eXBlb2YgdiA9PT0gXCJvYmplY3RcIiAmJiB2ICE9PSBudWxsKSB7XG4gICAgICBpZiAodi5fX3ZfaXNSZWFkb25seSB8fCB2Ll9fdl9pc1JlZilcbiAgICAgICAgY29udGludWU7XG4gICAgICBzdHJpcEVtcHR5UHJvcGVydGllcyh2KTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG9iajtcbn1cbmZ1bmN0aW9uIHN0cmlwTnVsbFByb3BlcnRpZXMob2JqKSB7XG4gIGlmIChBcnJheS5pc0FycmF5KG9iaikpIHtcbiAgICBsZXQgbmV4dCA9IDA7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBvYmoubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IHYgPSBvYmpbaV07XG4gICAgICBpZiAodiA9PT0gbnVsbClcbiAgICAgICAgY29udGludWU7XG4gICAgICBpZiAodHlwZW9mIHYgPT09IFwib2JqZWN0XCIgJiYgdiAhPT0gbnVsbClcbiAgICAgICAgc3RyaXBOdWxsUHJvcGVydGllcyh2KTtcbiAgICAgIG9ialtuZXh0KytdID0gdjtcbiAgICB9XG4gICAgb2JqLmxlbmd0aCA9IG5leHQ7XG4gICAgcmV0dXJuIG9iajtcbiAgfVxuICBmb3IgKGNvbnN0IGsgaW4gb2JqKSB7XG4gICAgaWYgKCFPYmplY3QuaGFzT3duKG9iaiwgaykpXG4gICAgICBjb250aW51ZTtcbiAgICBjb25zdCB2ID0gb2JqW2tdO1xuICAgIGlmICh2ID09PSBudWxsKSB7XG4gICAgICBkZWxldGUgb2JqW2tdO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHYgPT09IFwib2JqZWN0XCIpIHtcbiAgICAgIGlmICh2Ll9fdl9pc1JlYWRvbmx5IHx8IHYuX192X2lzUmVmKVxuICAgICAgICBjb250aW51ZTtcbiAgICAgIHN0cmlwTnVsbFByb3BlcnRpZXModik7XG4gICAgfVxuICB9XG4gIHJldHVybiBvYmo7XG59XG5cbmZ1bmN0aW9uIGlzSW1hZ2VPYmplY3Qobm9kZSkge1xuICByZXR1cm4gdHlwZW9mIG5vZGUudXJsID09PSBcInN0cmluZ1wiO1xufVxuY29uc3QgaW1hZ2VSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgYWxpYXM6IFwiaW1hZ2VcIixcbiAgY2FzdChpbnB1dCkge1xuICAgIGlmICh0eXBlb2YgaW5wdXQgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIGlucHV0ID0ge1xuICAgICAgICB1cmw6IGlucHV0XG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gaW5wdXQ7XG4gIH0sXG4gIGRlZmF1bHRzOiB7XG4gICAgXCJAdHlwZVwiOiBcIkltYWdlT2JqZWN0XCJcbiAgfSxcbiAgaW5oZXJpdE1ldGE6IFtcbiAgICAvLyBAdG9kbyBwb3NzaWJseSBvbmx5IGRvIGlmIHRoZXJlJ3MgYSBjYXB0aW9uXG4gICAgXCJpbkxhbmd1YWdlXCJcbiAgXSxcbiAgaWRQcmVmaXg6IFwiaG9zdFwiLFxuICByZXNvbHZlKGltYWdlLCB7IG1ldGEgfSkge1xuICAgIGltYWdlLnVybCA9IHJlc29sdmVXaXRoQmFzZShtZXRhLmhvc3QsIGltYWdlLnVybCk7XG4gICAgc2V0SWZFbXB0eShpbWFnZSwgXCJjb250ZW50VXJsXCIsIGltYWdlLnVybCk7XG4gICAgaWYgKGltYWdlLmhlaWdodCAmJiAhaW1hZ2Uud2lkdGgpXG4gICAgICBkZWxldGUgaW1hZ2UuaGVpZ2h0O1xuICAgIGlmIChpbWFnZS53aWR0aCAmJiAhaW1hZ2UuaGVpZ2h0KVxuICAgICAgZGVsZXRlIGltYWdlLndpZHRoO1xuICAgIHJldHVybiBpbWFnZTtcbiAgfVxufSk7XG5cbmNvbnN0IEFMSUFTX1JFID0gLyhbYS16XSkoW0EtWl0pL2c7XG5mdW5jdGlvbiBuZXh0Tm9kZUlkKGN0eCwgYWxpYXMpIHtcbiAgY3R4Lm5vZGVJZENvdW50ZXJzW2FsaWFzXSA9IChjdHgubm9kZUlkQ291bnRlcnNbYWxpYXNdIHx8IDApICsgMTtcbiAgcmV0dXJuIGN0eC5ub2RlSWRDb3VudGVyc1thbGlhc10udG9TdHJpbmcoKTtcbn1cbmZ1bmN0aW9uIHJlc29sdmVNZXRhKG1ldGEpIHtcbiAgaWYgKCFtZXRhLnBhdGgpXG4gICAgbWV0YS5wYXRoID0gXCIvXCI7XG4gIGlmICghbWV0YS5ob3N0ICYmIHR5cGVvZiBkb2N1bWVudCAhPT0gXCJ1bmRlZmluZWRcIilcbiAgICBtZXRhLmhvc3QgPSBkb2N1bWVudC5sb2NhdGlvbi5ob3N0O1xuICBpZiAobWV0YS5wYXRoICE9PSBcIi9cIikge1xuICAgIGlmIChtZXRhLnRyYWlsaW5nU2xhc2ggJiYgIW1ldGEucGF0aC5lbmRzV2l0aChcIi9cIikpXG4gICAgICBtZXRhLnBhdGggPSB3aXRoVHJhaWxpbmdTbGFzaChtZXRhLnBhdGgpO1xuICAgIGVsc2UgaWYgKCFtZXRhLnRyYWlsaW5nU2xhc2ggJiYgbWV0YS5wYXRoLmVuZHNXaXRoKFwiL1wiKSlcbiAgICAgIG1ldGEucGF0aCA9IHdpdGhvdXRUcmFpbGluZ1NsYXNoKG1ldGEucGF0aCk7XG4gIH1cbiAgbWV0YS51cmwgPSBqb2luVVJMKG1ldGEuaG9zdCB8fCBcIlwiLCBtZXRhLnBhdGgpO1xuICByZXR1cm4gbWV0YTtcbn1cbmZ1bmN0aW9uIHJlc29sdmVOb2RlKG5vZGUsIGN0eCwgcmVzb2x2ZXIpIHtcbiAgaWYgKHJlc29sdmVyPy5jYXN0KVxuICAgIG5vZGUgPSByZXNvbHZlci5jYXN0KG5vZGUsIGN0eCk7XG4gIGlmIChyZXNvbHZlcj8uZGVmYXVsdHMpIHtcbiAgICBsZXQgZGVmYXVsdHMgPSByZXNvbHZlci5kZWZhdWx0cztcbiAgICBpZiAodHlwZW9mIGRlZmF1bHRzID09PSBcImZ1bmN0aW9uXCIpXG4gICAgICBkZWZhdWx0cyA9IGRlZmF1bHRzKGN0eCk7XG4gICAgbm9kZSA9IHsgLi4uZGVmYXVsdHMsIC4uLm5vZGUgfTtcbiAgfVxuICBjb25zdCBpbmhlcml0TWV0YSA9IHJlc29sdmVyPy5pbmhlcml0TWV0YTtcbiAgaWYgKGluaGVyaXRNZXRhKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbmhlcml0TWV0YS5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgZW50cnkgPSBpbmhlcml0TWV0YVtpXTtcbiAgICAgIGlmICh0eXBlb2YgZW50cnkgPT09IFwic3RyaW5nXCIpXG4gICAgICAgIHNldElmRW1wdHkobm9kZSwgZW50cnksIGN0eC5tZXRhW2VudHJ5XSk7XG4gICAgICBlbHNlXG4gICAgICAgIHNldElmRW1wdHkobm9kZSwgZW50cnkua2V5LCBjdHgubWV0YVtlbnRyeS5tZXRhXSk7XG4gICAgfVxuICB9XG4gIGlmIChyZXNvbHZlcj8ucmVzb2x2ZSlcbiAgICBub2RlID0gcmVzb2x2ZXIucmVzb2x2ZShub2RlLCBjdHgpO1xuICBmb3IgKGNvbnN0IGsgaW4gbm9kZSkge1xuICAgIGNvbnN0IHYgPSBub2RlW2tdO1xuICAgIGlmIChBcnJheS5pc0FycmF5KHYpKSB7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHYubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3QgaXRlbSA9IHZbaV07XG4gICAgICAgIGlmICh0eXBlb2YgaXRlbSA9PT0gXCJvYmplY3RcIiAmJiBpdGVtPy5fcmVzb2x2ZXIpXG4gICAgICAgICAgbm9kZVtrXVtpXSA9IHJlc29sdmVSZWxhdGlvbihpdGVtLCBjdHgsIGl0ZW0uX3Jlc29sdmVyKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHR5cGVvZiB2ID09PSBcIm9iamVjdFwiICYmIHY/Ll9yZXNvbHZlcikge1xuICAgICAgbm9kZVtrXSA9IHJlc29sdmVSZWxhdGlvbih2LCBjdHgsIHYuX3Jlc29sdmVyKTtcbiAgICB9XG4gIH1cbiAgc3RyaXBFbXB0eVByb3BlcnRpZXMobm9kZSk7XG4gIHJldHVybiBub2RlO1xufVxuZnVuY3Rpb24gcmVzb2x2ZU5vZGVJZChub2RlLCBjdHgsIHJlc29sdmVyLCByZXNvbHZlQXNSb290ID0gZmFsc2UpIHtcbiAgaWYgKG5vZGVbXCJAaWRcIl0gJiYgbm9kZVtcIkBpZFwiXS5zdGFydHNXaXRoKFwiaHR0cFwiKSlcbiAgICByZXR1cm4gbm9kZTtcbiAgY29uc3QgcHJlZml4ID0gcmVzb2x2ZXIgPyAoQXJyYXkuaXNBcnJheShyZXNvbHZlci5pZFByZWZpeCkgPyByZXNvbHZlci5pZFByZWZpeFswXSA6IHJlc29sdmVyLmlkUHJlZml4KSB8fCBcInVybFwiIDogXCJ1cmxcIjtcbiAgY29uc3Qgcm9vdElkID0gbm9kZVtcIkBpZFwiXSB8fCAocmVzb2x2ZXIgPyBBcnJheS5pc0FycmF5KHJlc29sdmVyLmlkUHJlZml4KSA/IHJlc29sdmVyLmlkUHJlZml4Py5bMV0gOiB2b2lkIDAgOiBcIlwiKTtcbiAgaWYgKCFub2RlW1wiQGlkXCJdICYmIHJlc29sdmVBc1Jvb3QgJiYgcm9vdElkKSB7XG4gICAgbm9kZVtcIkBpZFwiXSA9IHByZWZpeElkKGN0eC5tZXRhW3ByZWZpeF0sIHJvb3RJZCk7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbiAgaWYgKG5vZGVbXCJAaWRcIl0/LnN0YXJ0c1dpdGgoXCIjL3NjaGVtYS9cIikgfHwgbm9kZVtcIkBpZFwiXT8uc3RhcnRzV2l0aChcIi9cIikpIHtcbiAgICBub2RlW1wiQGlkXCJdID0gcHJlZml4SWQoY3R4Lm1ldGFbcHJlZml4XSwgbm9kZVtcIkBpZFwiXSk7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbiAgbGV0IGFsaWFzID0gcmVzb2x2ZXI/LmFsaWFzO1xuICBpZiAoIWFsaWFzKSB7XG4gICAgY29uc3QgdHlwZSA9IGFzQXJyYXkobm9kZVtcIkB0eXBlXCJdKT8uWzBdIHx8IFwiXCI7XG4gICAgYWxpYXMgPSB0eXBlLnJlcGxhY2UoQUxJQVNfUkUsIFwiJDEtJDJcIikudG9Mb3dlckNhc2UoKTtcbiAgfVxuICBub2RlW1wiQGlkXCJdID0gcHJlZml4SWQoY3R4Lm1ldGFbcHJlZml4XSwgYCMvc2NoZW1hLyR7YWxpYXN9LyR7bm9kZVtcIkBpZFwiXSB8fCBuZXh0Tm9kZUlkKGN0eCwgYWxpYXMpfWApO1xuICByZXR1cm4gbm9kZTtcbn1cbmZ1bmN0aW9uIHJlc29sdmVSZWxhdGlvbihpbnB1dCwgY3R4LCBmYWxsYmFja1Jlc29sdmVyLCBvcHRpb25zID0ge30pIHtcbiAgaWYgKCFpbnB1dClcbiAgICByZXR1cm4gaW5wdXQ7XG4gIGNvbnN0IGl0ZW1zID0gYXNBcnJheShpbnB1dCk7XG4gIGNvbnN0IGlkcyA9IFtdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGl0ZW1zLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgYSA9IGl0ZW1zW2ldO1xuICAgIGlmICghYSkge1xuICAgICAgaWRzLnB1c2goYSk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgbGV0IGtleUNvdW50ID0gMDtcbiAgICBmb3IgKGNvbnN0IF8gaW4gYSkga2V5Q291bnQrKztcbiAgICBpZiAoa2V5Q291bnQgPT09IDEgJiYgYVtcIkBpZFwiXSB8fCBrZXlDb3VudCA9PT0gMiAmJiBhW1wiQGlkXCJdICYmIGFbXCJAdHlwZVwiXSkge1xuICAgICAgaWRzLnB1c2gocmVzb2x2ZU5vZGVJZCh7XG4gICAgICAgIFwiQGlkXCI6IGN0eC5maW5kKGFbXCJAaWRcIl0pPy5bXCJAaWRcIl0gfHwgYVtcIkBpZFwiXVxuICAgICAgfSwgY3R4KSk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgbGV0IHJlc29sdmVyID0gZmFsbGJhY2tSZXNvbHZlcjtcbiAgICBpZiAoYS5fcmVzb2x2ZXIgJiYgdHlwZW9mIGEuX3Jlc29sdmVyICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICByZXNvbHZlciA9IGEuX3Jlc29sdmVyO1xuICAgICAgZGVsZXRlIGEuX3Jlc29sdmVyO1xuICAgIH1cbiAgICBpZiAoIXJlc29sdmVyKSB7XG4gICAgICBpZHMucHVzaChhKTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBsZXQgbm9kZSA9IHJlc29sdmVOb2RlKGEsIGN0eCwgcmVzb2x2ZXIpO1xuICAgIGlmIChvcHRpb25zLmFmdGVyUmVzb2x2ZSlcbiAgICAgIG9wdGlvbnMuYWZ0ZXJSZXNvbHZlKG5vZGUpO1xuICAgIGlmIChvcHRpb25zLmdlbmVyYXRlSWQgfHwgb3B0aW9ucy5yb290KVxuICAgICAgbm9kZSA9IHJlc29sdmVOb2RlSWQobm9kZSwgY3R4LCByZXNvbHZlciwgZmFsc2UpO1xuICAgIGlmIChvcHRpb25zLnJvb3QpIHtcbiAgICAgIGlmIChyZXNvbHZlci5yZXNvbHZlUm9vdE5vZGUpXG4gICAgICAgIHJlc29sdmVyLnJlc29sdmVSb290Tm9kZShub2RlLCBjdHgpO1xuICAgICAgY3R4LnB1c2gobm9kZSk7XG4gICAgICBpZHMucHVzaChpZFJlZmVyZW5jZShub2RlW1wiQGlkXCJdKSk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWRzLnB1c2gobm9kZSk7XG4gIH1cbiAgcmV0dXJuICFvcHRpb25zLmFycmF5ICYmIGlkcy5sZW5ndGggPT09IDEgPyBpZHNbMF0gOiBpZHM7XG59XG5cbmZ1bmN0aW9uIG1lcmdlKHRhcmdldCwgc291cmNlKSB7XG4gIGlmICghc291cmNlKVxuICAgIHJldHVybiB0YXJnZXQ7XG4gIGZvciAoY29uc3Qga2V5IGluIHNvdXJjZSkge1xuICAgIGlmICghT2JqZWN0Lmhhc093bihzb3VyY2UsIGtleSkgfHwga2V5ID09PSBcIl9fcHJvdG9fX1wiIHx8IGtleSA9PT0gXCJjb25zdHJ1Y3RvclwiIHx8IGtleSA9PT0gXCJwcm90b3R5cGVcIilcbiAgICAgIGNvbnRpbnVlO1xuICAgIGNvbnN0IHZhbHVlID0gc291cmNlW2tleV07XG4gICAgaWYgKHZhbHVlID09PSB2b2lkIDApXG4gICAgICBjb250aW51ZTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheSh0YXJnZXRba2V5XSkpIHtcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgICAgICBjb25zdCBtZXJnZWQgPSBbLi4udGFyZ2V0W2tleV0sIC4uLnZhbHVlXTtcbiAgICAgICAgaWYgKGtleSA9PT0gXCJAdHlwZVwiKSB7XG4gICAgICAgICAgdGFyZ2V0W2tleV0gPSBbLi4ubmV3IFNldChtZXJnZWQpXTtcbiAgICAgICAgfSBlbHNlIGlmIChrZXkgPT09IFwiaXRlbUxpc3RFbGVtZW50XCIpIHtcbiAgICAgICAgICBtZXJnZWQuc29ydCgoYSwgYikgPT4gKGEucG9zaXRpb24gfHwgMCkgLSAoYi5wb3NpdGlvbiB8fCAwKSk7XG4gICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtZXJnZWQubGVuZ3RoOyBpKyspXG4gICAgICAgICAgICBtZXJnZWRbaV0ucG9zaXRpb24gPSBpICsgMTtcbiAgICAgICAgICB0YXJnZXRba2V5XSA9IG1lcmdlZDtcbiAgICAgICAgfSBlbHNlIGlmIChrZXkgPT09IFwicG90ZW50aWFsQWN0aW9uXCIpIHtcbiAgICAgICAgICBjb25zdCBieVR5cGUgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgICAgICBmb3IgKGNvbnN0IGFjdGlvbiBvZiBtZXJnZWQpIHtcbiAgICAgICAgICAgIGNvbnN0IHR5cGUgPSBhY3Rpb25bXCJAdHlwZVwiXTtcbiAgICAgICAgICAgIGlmIChieVR5cGVbdHlwZV0pIHtcbiAgICAgICAgICAgICAgaWYgKGFjdGlvbi50YXJnZXQgJiYgYnlUeXBlW3R5cGVdLnRhcmdldCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGEgPSBBcnJheS5pc0FycmF5KGJ5VHlwZVt0eXBlXS50YXJnZXQpID8gYnlUeXBlW3R5cGVdLnRhcmdldCA6IFtieVR5cGVbdHlwZV0udGFyZ2V0XTtcbiAgICAgICAgICAgICAgICBjb25zdCBiID0gQXJyYXkuaXNBcnJheShhY3Rpb24udGFyZ2V0KSA/IGFjdGlvbi50YXJnZXQgOiBbYWN0aW9uLnRhcmdldF07XG4gICAgICAgICAgICAgICAgYnlUeXBlW3R5cGVdLnRhcmdldCA9IFsuLi4vKiBAX19QVVJFX18gKi8gbmV3IFNldChbLi4uYSwgLi4uYl0pXTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgYnlUeXBlW3R5cGVdID0geyAuLi5hY3Rpb24gfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgdGFyZ2V0W2tleV0gPSBPYmplY3QudmFsdWVzKGJ5VHlwZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY29uc3QgaGFzVHlwZWRPYmplY3RzID0gbWVyZ2VkLmxlbmd0aCA+IDAgJiYgbWVyZ2VkLmV2ZXJ5KFxuICAgICAgICAgICAgKGl0ZW0pID0+IGl0ZW0gJiYgdHlwZW9mIGl0ZW0gPT09IFwib2JqZWN0XCIgJiYgaXRlbVtcIkB0eXBlXCJdXG4gICAgICAgICAgKTtcbiAgICAgICAgICBpZiAoaGFzVHlwZWRPYmplY3RzKSB7XG4gICAgICAgICAgICBjb25zdCBieVR5cGUgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgaXRlbSBvZiBtZXJnZWQpXG4gICAgICAgICAgICAgIGJ5VHlwZVtpdGVtW1wiQHR5cGVcIl1dID0gaXRlbTtcbiAgICAgICAgICAgIHRhcmdldFtrZXldID0gT2JqZWN0LnZhbHVlcyhieVR5cGUpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0YXJnZXRba2V5XSA9IG1lcmdlZDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRhcmdldFtrZXldID0gbWVyZ2UodGFyZ2V0W2tleV0sIFt2YWx1ZV0pO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAodGFyZ2V0W2tleV0gJiYgdHlwZW9mIHRhcmdldFtrZXldID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiB2YWx1ZSA9PT0gXCJvYmplY3RcIiAmJiAhQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgIHRhcmdldFtrZXldID0gbWVyZ2UoeyAuLi50YXJnZXRba2V5XSB9LCB2YWx1ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRhcmdldFtrZXldID0gdmFsdWU7XG4gICAgfVxuICB9XG4gIHJldHVybiB0YXJnZXQ7XG59XG5cbmNvbnN0IERPTUFJTl9SRSA9IC8oPzpodHRwcz86KT9cXC9cXC8vO1xuZnVuY3Rpb24gaW5kZXhOb2RlKGluZGV4LCBub2RlKSB7XG4gIGlmICghbm9kZVtcIkBpZFwiXSlcbiAgICByZXR1cm47XG4gIGNvbnN0IG5vZGVJZCA9IG5vZGVbXCJAaWRcIl07XG4gIGNvbnN0IGZyYWdtZW50S2V5ID0gcmVzb2x2ZUFzR3JhcGhLZXkobm9kZUlkKTtcbiAgaW5kZXguc2V0KGZyYWdtZW50S2V5LCBub2RlKTtcbiAgaW5kZXguc2V0KG5vZGVJZCwgbm9kZSk7XG4gIGNvbnN0IGRvbWFpbktleSA9IG5vZGVJZC5yZXBsYWNlKERPTUFJTl9SRSwgXCJcIikuc3BsaXQoXCIvXCIpWzBdO1xuICBpbmRleC5zZXQoZG9tYWluS2V5LCBub2RlKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVNjaGVtYU9yZ0dyYXBoKCkge1xuICBsZXQgY3R4O1xuICBmdW5jdGlvbiBmaW5kKGlkLCBndWFyZCkge1xuICAgIGNvbnN0IG1hdGNoRnJhZ21lbnQgPSBpZFswXSA9PT0gXCIjXCI7XG4gICAgY29uc3QgbWF0Y2hEb21haW4gPSBpZFswXSA9PT0gXCIvXCIgJiYgaWRbMV0gPT09IFwiL1wiO1xuICAgIGNvbnN0IGtleSA9IG1hdGNoRnJhZ21lbnQgPyByZXNvbHZlQXNHcmFwaEtleShpZCkgOiBtYXRjaERvbWFpbiA/IGlkLnJlcGxhY2UoRE9NQUlOX1JFLCBcIlwiKS5zcGxpdChcIi9cIilbMF0gOiBpZDtcbiAgICBsZXQgbm9kZSA9IGN0eC5ub2RlSW5kZXguc2l6ZSA+IDAgPyBjdHgubm9kZUluZGV4LmdldChrZXkpIDogdm9pZCAwO1xuICAgIGlmICghbm9kZSkge1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjdHgubm9kZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3QgY2FuZGlkYXRlID0gY3R4Lm5vZGVzW2ldO1xuICAgICAgICBjb25zdCBub2RlSWQgPSBjYW5kaWRhdGVbXCJAaWRcIl07XG4gICAgICAgIGlmICghbm9kZUlkKVxuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICBjb25zdCBub2RlS2V5ID0gbWF0Y2hGcmFnbWVudCA/IHJlc29sdmVBc0dyYXBoS2V5KG5vZGVJZCkgOiBtYXRjaERvbWFpbiA/IG5vZGVJZC5yZXBsYWNlKERPTUFJTl9SRSwgXCJcIikuc3BsaXQoXCIvXCIpWzBdIDogbm9kZUlkO1xuICAgICAgICBpZiAobm9kZUtleSA9PT0ga2V5KSB7XG4gICAgICAgICAgbm9kZSA9IGNhbmRpZGF0ZTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBpZiAoIW5vZGUgfHwgZ3VhcmQgJiYgIWd1YXJkKG5vZGUpKVxuICAgICAgcmV0dXJuIG51bGw7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbiAgY3R4ID0ge1xuICAgIGZpbmQsXG4gICAgcHVzaChpbnB1dCkge1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoaW5wdXQpKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW5wdXQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBjb25zdCByZWdpc3RlcmVkTm9kZSA9IGlucHV0W2ldO1xuICAgICAgICAgIGN0eC5ub2Rlcy5wdXNoKHJlZ2lzdGVyZWROb2RlKTtcbiAgICAgICAgICBpZiAoY3R4Lm5vZGVJbmRleC5zaXplID4gMClcbiAgICAgICAgICAgIGluZGV4Tm9kZShjdHgubm9kZUluZGV4LCByZWdpc3RlcmVkTm9kZSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHJlZ2lzdGVyZWROb2RlID0gaW5wdXQ7XG4gICAgICAgIGN0eC5ub2Rlcy5wdXNoKHJlZ2lzdGVyZWROb2RlKTtcbiAgICAgICAgaWYgKGN0eC5ub2RlSW5kZXguc2l6ZSA+IDApXG4gICAgICAgICAgaW5kZXhOb2RlKGN0eC5ub2RlSW5kZXgsIHJlZ2lzdGVyZWROb2RlKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIHJlc29sdmVHcmFwaChtZXRhKSB7XG4gICAgICBmb3IgKGNvbnN0IGsgaW4gY3R4Lm5vZGVJZENvdW50ZXJzKSBkZWxldGUgY3R4Lm5vZGVJZENvdW50ZXJzW2tdO1xuICAgICAgY3R4Lm1ldGEgPSByZXNvbHZlTWV0YSh7IC4uLm1ldGEgfSk7XG4gICAgICBjb25zdCBsZW4gPSBjdHgubm9kZXMubGVuZ3RoO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgICAgICBsZXQgbm9kZSA9IGN0eC5ub2Rlc1tpXTtcbiAgICAgICAgY29uc3QgcmVzb2x2ZXIgPSBub2RlLl9yZXNvbHZlcjtcbiAgICAgICAgbm9kZSA9IHJlc29sdmVOb2RlKG5vZGUsIGN0eCwgcmVzb2x2ZXIpO1xuICAgICAgICBub2RlID0gcmVzb2x2ZU5vZGVJZChub2RlLCBjdHgsIHJlc29sdmVyLCB0cnVlKTtcbiAgICAgICAgY3R4Lm5vZGVzW2ldID0gbm9kZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGRlZHVwZWROb2RlcyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgICAgbGV0IGhhc0R1cGxpY2F0ZXMgPSBmYWxzZTtcbiAgICAgIGN0eC5ub2RlSW5kZXguY2xlYXIoKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY3R4Lm5vZGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IG4gPSBjdHgubm9kZXNbaV07XG4gICAgICAgIGNvbnN0IG5vZGVLZXkgPSByZXNvbHZlQXNHcmFwaEtleShuW1wiQGlkXCJdKTtcbiAgICAgICAgaWYgKGRlZHVwZWROb2Rlc1tub2RlS2V5XSkge1xuICAgICAgICAgIGhhc0R1cGxpY2F0ZXMgPSB0cnVlO1xuICAgICAgICAgIGlmIChuLl9kZWR1cGVTdHJhdGVneSAhPT0gXCJyZXBsYWNlXCIpXG4gICAgICAgICAgICBkZWR1cGVkTm9kZXNbbm9kZUtleV0gPSBtZXJnZShkZWR1cGVkTm9kZXNbbm9kZUtleV0sIG4pO1xuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIGRlZHVwZWROb2Rlc1tub2RlS2V5XSA9IG47XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZGVkdXBlZE5vZGVzW25vZGVLZXldID0gbjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKGhhc0R1cGxpY2F0ZXMpXG4gICAgICAgIGN0eC5ub2RlcyA9IE9iamVjdC52YWx1ZXMoZGVkdXBlZE5vZGVzKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY3R4Lm5vZGVzLmxlbmd0aDsgaSsrKVxuICAgICAgICBpbmRleE5vZGUoY3R4Lm5vZGVJbmRleCwgY3R4Lm5vZGVzW2ldKTtcbiAgICAgIGNvbnN0IGNvdW50QmVmb3JlUmVsYXRpb25zID0gY3R4Lm5vZGVzLmxlbmd0aDtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY3R4Lm5vZGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IG5vZGUgPSBjdHgubm9kZXNbaV07XG4gICAgICAgIGlmIChub2RlLmltYWdlICYmIHR5cGVvZiBub2RlLmltYWdlID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgbm9kZS5pbWFnZSA9IHJlc29sdmVSZWxhdGlvbihub2RlLmltYWdlLCBjdHgsIGltYWdlUmVzb2x2ZXIsIHtcbiAgICAgICAgICAgIHJvb3Q6IHRydWVcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBub2RlLnRyYW5zbGF0aW9uT2ZXb3JrID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUudHJhbnNsYXRpb25PZldvcmssIGN0eCk7XG4gICAgICAgIG5vZGUud29ya1RyYW5zbGF0aW9uID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUud29ya1RyYW5zbGF0aW9uLCBjdHgpO1xuICAgICAgICBjb25zdCByZXNvbHZlciA9IG5vZGUuX3Jlc29sdmVyO1xuICAgICAgICBpZiAocmVzb2x2ZXI/LnJlc29sdmVSb290Tm9kZSlcbiAgICAgICAgICByZXNvbHZlci5yZXNvbHZlUm9vdE5vZGUobm9kZSwgY3R4KTtcbiAgICAgIH1cbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY3R4Lm5vZGVzLmxlbmd0aDsgaSsrKVxuICAgICAgICBkZWxldGUgY3R4Lm5vZGVzW2ldLl9yZXNvbHZlcjtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY3R4Lm5vZGVzLmxlbmd0aDsgaSsrKVxuICAgICAgICBzdHJpcE51bGxQcm9wZXJ0aWVzKGN0eC5ub2Rlc1tpXSk7XG4gICAgICBjb25zdCBuZWVkc0RlZHVwZSA9IGN0eC5ub2Rlcy5sZW5ndGggPiBjb3VudEJlZm9yZVJlbGF0aW9ucztcbiAgICAgIGNvbnN0IG5vcm1hbGl6ZWROb2RlcyA9IG5lZWRzRGVkdXBlID8gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCkgOiBudWxsO1xuICAgICAgY29uc3QgcmVzdWx0ID0gbmVlZHNEZWR1cGUgPyBudWxsIDogW107XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGN0eC5ub2Rlcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBuID0gY3R4Lm5vZGVzW2ldO1xuICAgICAgICBjb25zdCBub2RlS2V5ID0gcmVzb2x2ZUFzR3JhcGhLZXkobltcIkBpZFwiXSk7XG4gICAgICAgIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhuKTtcbiAgICAgICAga2V5cy5zb3J0KCk7XG4gICAgICAgIGNvbnN0IG5ld05vZGUgPSB7fTtcbiAgICAgICAgbGV0IHJlbGF0aW9uQ291bnQgPSAwO1xuICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8IGtleXMubGVuZ3RoOyBqKyspIHtcbiAgICAgICAgICBjb25zdCBrID0ga2V5c1tqXTtcbiAgICAgICAgICBpZiAoa1swXSA9PT0gXCJfXCIpXG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICBjb25zdCB2ID0gbltrXTtcbiAgICAgICAgICBpZiAodiAhPT0gbnVsbCAmJiAoQXJyYXkuaXNBcnJheSh2KSB8fCB0eXBlb2YgdiA9PT0gXCJvYmplY3RcIikpXG4gICAgICAgICAgICBrZXlzW3JlbGF0aW9uQ291bnQrK10gPSBrO1xuICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgIG5ld05vZGVba10gPSB2O1xuICAgICAgICB9XG4gICAgICAgIGZvciAobGV0IGogPSAwOyBqIDwgcmVsYXRpb25Db3VudDsgaisrKSB7XG4gICAgICAgICAgY29uc3QgayA9IGtleXNbal07XG4gICAgICAgICAgbmV3Tm9kZVtrXSA9IG5ba107XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG5lZWRzRGVkdXBlKSB7XG4gICAgICAgICAgbm9ybWFsaXplZE5vZGVzW25vZGVLZXldID0gbm9ybWFsaXplZE5vZGVzW25vZGVLZXldID8gbWVyZ2Uobm9ybWFsaXplZE5vZGVzW25vZGVLZXldLCBuZXdOb2RlKSA6IG5ld05vZGU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVzdWx0LnB1c2gobmV3Tm9kZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBuZWVkc0RlZHVwZSA/IE9iamVjdC52YWx1ZXMobm9ybWFsaXplZE5vZGVzKSA6IHJlc3VsdDtcbiAgICB9LFxuICAgIG5vZGVzOiBbXSxcbiAgICBub2RlSW5kZXg6IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCksXG4gICAgbm9kZUlkQ291bnRlcnM6IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpLFxuICAgIG1ldGE6IHJlc29sdmVNZXRhKHt9KVxuICB9O1xuICByZXR1cm4gY3R4O1xufVxuXG5jb25zdCBxdWFudGl0YXRpdmVWYWx1ZVJlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBjYXN0KG5vZGUpIHtcbiAgICBpZiAodHlwZW9mIG5vZGUgPT09IFwibnVtYmVyXCIpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHZhbHVlOiBub2RlXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gbm9kZTtcbiAgfSxcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiUXVhbnRpdGF0aXZlVmFsdWVcIlxuICB9XG59KTtcbmNvbnN0IG1vbmV0YXJ5QW1vdW50UmVzb2x2ZXIgPSBkZWZpbmVTY2hlbWFPcmdSZXNvbHZlcih7XG4gIGRlZmF1bHRzOiB7XG4gICAgXCJAdHlwZVwiOiBcIk1vbmV0YXJ5QW1vdW50XCJcbiAgfSxcbiAgcmVzb2x2ZShub2RlLCBjdHgpIHtcbiAgICBpZiAodHlwZW9mIG5vZGUudmFsdWUgPT09IFwib2JqZWN0XCIpXG4gICAgICBub2RlLnZhbHVlID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUudmFsdWUsIGN0eCwgcXVhbnRpdGF0aXZlVmFsdWVSZXNvbHZlcik7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn0pO1xuXG5jb25zdCBtZXJjaGFudFJldHVyblBvbGljeVJlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJNZXJjaGFudFJldHVyblBvbGljeVwiXG4gIH0sXG4gIHJlc29sdmUobm9kZSwgY3R4KSB7XG4gICAgaWYgKG5vZGUucmV0dXJuUG9saWN5Q2F0ZWdvcnkpXG4gICAgICBub2RlLnJldHVyblBvbGljeUNhdGVnb3J5ID0gd2l0aEJhc2Uobm9kZS5yZXR1cm5Qb2xpY3lDYXRlZ29yeSwgXCJodHRwczovL3NjaGVtYS5vcmcvXCIpO1xuICAgIGlmIChub2RlLnJldHVybkZlZXMpXG4gICAgICBub2RlLnJldHVybkZlZXMgPSB3aXRoQmFzZShub2RlLnJldHVybkZlZXMsIFwiaHR0cHM6Ly9zY2hlbWEub3JnL1wiKTtcbiAgICBpZiAobm9kZS5yZXR1cm5NZXRob2QpXG4gICAgICBub2RlLnJldHVybk1ldGhvZCA9IHdpdGhCYXNlKG5vZGUucmV0dXJuTWV0aG9kLCBcImh0dHBzOi8vc2NoZW1hLm9yZy9cIik7XG4gICAgbm9kZS5yZXR1cm5TaGlwcGluZ0ZlZXNBbW91bnQgPSByZXNvbHZlUmVsYXRpb24obm9kZS5yZXR1cm5TaGlwcGluZ0ZlZXNBbW91bnQsIGN0eCwgbW9uZXRhcnlBbW91bnRSZXNvbHZlcik7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn0pO1xuXG5jb25zdCBkZWZpbmVkUmVnaW9uUmVzb2x2ZXIgPSBkZWZpbmVTY2hlbWFPcmdSZXNvbHZlcih7XG4gIGRlZmF1bHRzOiB7XG4gICAgXCJAdHlwZVwiOiBcIkRlZmluZWRSZWdpb25cIlxuICB9XG59KTtcblxuY29uc3Qgc2hpcHBpbmdEZWxpdmVyeVRpbWVSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiU2hpcHBpbmdEZWxpdmVyeVRpbWVcIlxuICB9LFxuICByZXNvbHZlKG5vZGUsIGN0eCkge1xuICAgIG5vZGUuaGFuZGxpbmdUaW1lID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUuaGFuZGxpbmdUaW1lLCBjdHgsIHF1YW50aXRhdGl2ZVZhbHVlUmVzb2x2ZXIpO1xuICAgIG5vZGUudHJhbnNpdFRpbWUgPSByZXNvbHZlUmVsYXRpb24obm9kZS50cmFuc2l0VGltZSwgY3R4LCBxdWFudGl0YXRpdmVWYWx1ZVJlc29sdmVyKTtcbiAgICByZXR1cm4gbm9kZTtcbiAgfVxufSk7XG5cbmNvbnN0IG9mZmVyU2hpcHBpbmdEZXRhaWxzUmVzb2x2ZXIgPSBkZWZpbmVTY2hlbWFPcmdSZXNvbHZlcih7XG4gIGRlZmF1bHRzOiB7XG4gICAgXCJAdHlwZVwiOiBcIk9mZmVyU2hpcHBpbmdEZXRhaWxzXCJcbiAgfSxcbiAgcmVzb2x2ZShub2RlLCBjdHgpIHtcbiAgICBub2RlLmRlbGl2ZXJ5VGltZSA9IHJlc29sdmVSZWxhdGlvbihub2RlLmRlbGl2ZXJ5VGltZSwgY3R4LCBzaGlwcGluZ0RlbGl2ZXJ5VGltZVJlc29sdmVyKTtcbiAgICBub2RlLnNoaXBwaW5nRGVzdGluYXRpb24gPSByZXNvbHZlUmVsYXRpb24obm9kZS5zaGlwcGluZ0Rlc3RpbmF0aW9uLCBjdHgsIGRlZmluZWRSZWdpb25SZXNvbHZlcik7XG4gICAgbm9kZS5zaGlwcGluZ1JhdGUgPSByZXNvbHZlUmVsYXRpb24obm9kZS5zaGlwcGluZ1JhdGUsIGN0eCwgbW9uZXRhcnlBbW91bnRSZXNvbHZlcik7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn0pO1xuXG5jb25zdCBvZmZlclJlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBjYXN0KG5vZGUpIHtcbiAgICBpZiAodHlwZW9mIG5vZGUgPT09IFwibnVtYmVyXCIgfHwgdHlwZW9mIG5vZGUgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHByaWNlOiBub2RlXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gbm9kZTtcbiAgfSxcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiT2ZmZXJcIixcbiAgICBcImF2YWlsYWJpbGl0eVwiOiBcIkluU3RvY2tcIlxuICB9LFxuICByZXNvbHZlKG5vZGUsIGN0eCkge1xuICAgIHNldElmRW1wdHkobm9kZSwgXCJwcmljZUN1cnJlbmN5XCIsIGN0eC5tZXRhLmN1cnJlbmN5KTtcbiAgICBzZXRJZkVtcHR5KG5vZGUsIFwicHJpY2VWYWxpZFVudGlsXCIsIG5ldyBEYXRlKERhdGUuVVRDKCgvKiBAX19QVVJFX18gKi8gbmV3IERhdGUoKSkuZ2V0RnVsbFllYXIoKSArIDEsIDEyLCAtMSwgMCwgMCwgMCkpKTtcbiAgICBpZiAobm9kZS51cmwpXG4gICAgICByZXNvbHZlV2l0aEJhc2UoY3R4Lm1ldGEuaG9zdCwgbm9kZS51cmwpO1xuICAgIGlmIChub2RlLmF2YWlsYWJpbGl0eSlcbiAgICAgIG5vZGUuYXZhaWxhYmlsaXR5ID0gd2l0aEJhc2Uobm9kZS5hdmFpbGFiaWxpdHksIFwiaHR0cHM6Ly9zY2hlbWEub3JnL1wiKTtcbiAgICBpZiAobm9kZS5pdGVtQ29uZGl0aW9uKVxuICAgICAgbm9kZS5pdGVtQ29uZGl0aW9uID0gd2l0aEJhc2Uobm9kZS5pdGVtQ29uZGl0aW9uLCBcImh0dHBzOi8vc2NoZW1hLm9yZy9cIik7XG4gICAgaWYgKG5vZGUucHJpY2VWYWxpZFVudGlsKVxuICAgICAgbm9kZS5wcmljZVZhbGlkVW50aWwgPSByZXNvbHZhYmxlRGF0ZVRvSXNvKG5vZGUucHJpY2VWYWxpZFVudGlsKTtcbiAgICBub2RlLmhhc01lcmNoYW50UmV0dXJuUG9saWN5ID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUuaGFzTWVyY2hhbnRSZXR1cm5Qb2xpY3ksIGN0eCwgbWVyY2hhbnRSZXR1cm5Qb2xpY3lSZXNvbHZlcik7XG4gICAgbm9kZS5zaGlwcGluZ0RldGFpbHMgPSByZXNvbHZlUmVsYXRpb24obm9kZS5zaGlwcGluZ0RldGFpbHMsIGN0eCwgb2ZmZXJTaGlwcGluZ0RldGFpbHNSZXNvbHZlcik7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn0pO1xuXG5jb25zdCBhZ2dyZWdhdGVPZmZlclJlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJBZ2dyZWdhdGVPZmZlclwiXG4gIH0sXG4gIGluaGVyaXRNZXRhOiBbXG4gICAgeyBtZXRhOiBcImN1cnJlbmN5XCIsIGtleTogXCJwcmljZUN1cnJlbmN5XCIgfVxuICBdLFxuICByZXNvbHZlKG5vZGUsIGN0eCkge1xuICAgIG5vZGUub2ZmZXJzID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUub2ZmZXJzLCBjdHgsIG9mZmVyUmVzb2x2ZXIpO1xuICAgIGlmIChub2RlLm9mZmVycylcbiAgICAgIHNldElmRW1wdHkobm9kZSwgXCJvZmZlckNvdW50XCIsIGFzQXJyYXkobm9kZS5vZmZlcnMpLmxlbmd0aCk7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn0pO1xuXG5jb25zdCBhZ2dyZWdhdGVSYXRpbmdSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiQWdncmVnYXRlUmF0aW5nXCJcbiAgfVxufSk7XG5cbmNvbnN0IGxpc3RJdGVtUmVzb2x2ZXIgPSBkZWZpbmVTY2hlbWFPcmdSZXNvbHZlcih7XG4gIGNhc3Qobm9kZSkge1xuICAgIGlmICh0eXBlb2Ygbm9kZSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgbm9kZSA9IHtcbiAgICAgICAgbmFtZTogbm9kZVxuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIG5vZGU7XG4gIH0sXG4gIGRlZmF1bHRzOiB7XG4gICAgXCJAdHlwZVwiOiBcIkxpc3RJdGVtXCJcbiAgfSxcbiAgcmVzb2x2ZShub2RlLCBjdHgpIHtcbiAgICBpZiAodHlwZW9mIG5vZGUuaXRlbSA9PT0gXCJzdHJpbmdcIilcbiAgICAgIG5vZGUuaXRlbSA9IHJlc29sdmVXaXRoQmFzZShjdHgubWV0YS5ob3N0LCBub2RlLml0ZW0pO1xuICAgIGVsc2UgaWYgKHR5cGVvZiBub2RlLml0ZW0gPT09IFwib2JqZWN0XCIpXG4gICAgICBub2RlLml0ZW0gPSByZXNvbHZlUmVsYXRpb24obm9kZS5pdGVtLCBjdHgpO1xuICAgIHJldHVybiBub2RlO1xuICB9XG59KTtcblxuY29uc3QgUHJpbWFyeUJyZWFkY3J1bWJJZCA9IFwiI2JyZWFkY3J1bWJcIjtcbmNvbnN0IGJyZWFkY3J1bWJSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiQnJlYWRjcnVtYkxpc3RcIlxuICB9LFxuICBpZFByZWZpeDogW1widXJsXCIsIFByaW1hcnlCcmVhZGNydW1iSWRdLFxuICByZXNvbHZlKGJyZWFkY3J1bWIsIGN0eCkge1xuICAgIGlmIChicmVhZGNydW1iLml0ZW1MaXN0RWxlbWVudCkge1xuICAgICAgbGV0IGluZGV4ID0gMTtcbiAgICAgIGJyZWFkY3J1bWIuaXRlbUxpc3RFbGVtZW50ID0gcmVzb2x2ZVJlbGF0aW9uKGJyZWFkY3J1bWIuaXRlbUxpc3RFbGVtZW50LCBjdHgsIGxpc3RJdGVtUmVzb2x2ZXIsIHtcbiAgICAgICAgYXJyYXk6IHRydWUsXG4gICAgICAgIGFmdGVyUmVzb2x2ZShub2RlKSB7XG4gICAgICAgICAgc2V0SWZFbXB0eShub2RlLCBcInBvc2l0aW9uXCIsIGluZGV4KyspO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIGJyZWFkY3J1bWI7XG4gIH0sXG4gIHJlc29sdmVSb290Tm9kZShub2RlLCB7IGZpbmQgfSkge1xuICAgIGNvbnN0IHdlYlBhZ2UgPSBmaW5kKFByaW1hcnlXZWJQYWdlSWQpO1xuICAgIGlmICh3ZWJQYWdlKVxuICAgICAgc2V0SWZFbXB0eSh3ZWJQYWdlLCBcImJyZWFkY3J1bWJcIiwgaWRSZWZlcmVuY2Uobm9kZSkpO1xuICB9XG59KTtcblxuY29uc3QgYWRkcmVzc1Jlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJQb3N0YWxBZGRyZXNzXCJcbiAgfVxufSk7XG5cbmNvbnN0IHNlYXJjaEFjdGlvblJlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJTZWFyY2hBY3Rpb25cIixcbiAgICBcInRhcmdldFwiOiB7XG4gICAgICBcIkB0eXBlXCI6IFwiRW50cnlQb2ludFwiXG4gICAgfSxcbiAgICBcInF1ZXJ5LWlucHV0XCI6IHtcbiAgICAgIFwiQHR5cGVcIjogXCJQcm9wZXJ0eVZhbHVlU3BlY2lmaWNhdGlvblwiLFxuICAgICAgXCJ2YWx1ZVJlcXVpcmVkXCI6IHRydWUsXG4gICAgICBcInZhbHVlTmFtZVwiOiBcInNlYXJjaF90ZXJtX3N0cmluZ1wiXG4gICAgfVxuICB9LFxuICByZXNvbHZlKG5vZGUsIGN0eCkge1xuICAgIGlmICh0eXBlb2Ygbm9kZS50YXJnZXQgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIG5vZGUudGFyZ2V0ID0ge1xuICAgICAgICBcIkB0eXBlXCI6IFwiRW50cnlQb2ludFwiLFxuICAgICAgICBcInVybFRlbXBsYXRlXCI6IHJlc29sdmVXaXRoQmFzZShjdHgubWV0YS5ob3N0LCBub2RlLnRhcmdldClcbiAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBub2RlO1xuICB9XG59KTtcblxuY29uc3QgUHJpbWFyeVdlYlNpdGVJZCA9IFwiI3dlYnNpdGVcIjtcbmNvbnN0IHdlYlNpdGVSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiV2ViU2l0ZVwiXG4gIH0sXG4gIGluaGVyaXRNZXRhOiBbXG4gICAgXCJpbkxhbmd1YWdlXCIsXG4gICAgeyBtZXRhOiBcImhvc3RcIiwga2V5OiBcInVybFwiIH1cbiAgXSxcbiAgaWRQcmVmaXg6IFtcImhvc3RcIiwgUHJpbWFyeVdlYlNpdGVJZF0sXG4gIHJlc29sdmUobm9kZSwgY3R4KSB7XG4gICAgbm9kZS5wb3RlbnRpYWxBY3Rpb24gPSByZXNvbHZlUmVsYXRpb24obm9kZS5wb3RlbnRpYWxBY3Rpb24sIGN0eCwgc2VhcmNoQWN0aW9uUmVzb2x2ZXIsIHtcbiAgICAgIGFycmF5OiB0cnVlXG4gICAgfSk7XG4gICAgbm9kZS5wdWJsaXNoZXIgPSByZXNvbHZlUmVsYXRpb24obm9kZS5wdWJsaXNoZXIsIGN0eCk7XG4gICAgbm9kZS5kYXRlTW9kaWZpZWQgPSByZXNvbHZhYmxlRGF0ZVRvSXNvKG5vZGUuZGF0ZU1vZGlmaWVkKTtcbiAgICBub2RlLmRhdGVQdWJsaXNoZWQgPSByZXNvbHZhYmxlRGF0ZVRvSXNvKG5vZGUuZGF0ZVB1Ymxpc2hlZCk7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH0sXG4gIHJlc29sdmVSb290Tm9kZShub2RlLCB7IGZpbmQgfSkge1xuICAgIGlmIChyZXNvbHZlQXNHcmFwaEtleShub2RlW1wiQGlkXCJdKSA9PT0gUHJpbWFyeVdlYlNpdGVJZCkge1xuICAgICAgY29uc3QgaWRlbnRpdHkgPSBmaW5kKElkZW50aXR5SWQpO1xuICAgICAgaWYgKGlkZW50aXR5KVxuICAgICAgICBzZXRJZkVtcHR5KG5vZGUsIFwicHVibGlzaGVyXCIsIGlkUmVmZXJlbmNlKGlkZW50aXR5KSk7XG4gICAgICBjb25zdCB3ZWJQYWdlID0gZmluZChQcmltYXJ5V2ViUGFnZUlkKTtcbiAgICAgIGlmICh3ZWJQYWdlKVxuICAgICAgICBzZXRJZkVtcHR5KHdlYlBhZ2UsIFwiaXNQYXJ0T2ZcIiwgaWRSZWZlcmVuY2Uobm9kZSkpO1xuICAgIH1cbiAgICByZXR1cm4gbm9kZTtcbiAgfVxufSk7XG5cbmNvbnN0IG9yZ2FuaXphdGlvblJlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBjYXN0KG5vZGUpIHtcbiAgICBpZiAodHlwZW9mIG5vZGUgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIG5hbWU6IG5vZGVcbiAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBub2RlO1xuICB9LFxuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJPcmdhbml6YXRpb25cIlxuICB9LFxuICBpZFByZWZpeDogW1wiaG9zdFwiLCBJZGVudGl0eUlkXSxcbiAgaW5oZXJpdE1ldGE6IFtcbiAgICB7IG1ldGE6IFwiaG9zdFwiLCBrZXk6IFwidXJsXCIgfVxuICBdLFxuICByZXNvbHZlKG5vZGUsIGN0eCkge1xuICAgIHJlc29sdmVEZWZhdWx0VHlwZShub2RlLCBcIk9yZ2FuaXphdGlvblwiKTtcbiAgICBub2RlLmFkZHJlc3MgPSByZXNvbHZlUmVsYXRpb24obm9kZS5hZGRyZXNzLCBjdHgsIGFkZHJlc3NSZXNvbHZlcik7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH0sXG4gIHJlc29sdmVSb290Tm9kZShub2RlLCBjdHgpIHtcbiAgICBjb25zdCBpc0lkZW50aXR5ID0gcmVzb2x2ZUFzR3JhcGhLZXkobm9kZVtcIkBpZFwiXSkgPT09IElkZW50aXR5SWQ7XG4gICAgY29uc3Qgd2ViUGFnZSA9IGN0eC5maW5kKFByaW1hcnlXZWJQYWdlSWQpO1xuICAgIGlmIChub2RlLmxvZ28gJiYgaXNJZGVudGl0eSkge1xuICAgICAgY29uc3QgbG9nb0lucHV0ID0gQXJyYXkuaXNBcnJheShub2RlLmxvZ28pID8gbm9kZS5sb2dvWzBdIDogbm9kZS5sb2dvO1xuICAgICAgY29uc3QgbG9nb05vZGUgPSByZXNvbHZlUmVsYXRpb24obG9nb0lucHV0LCBjdHgsIGltYWdlUmVzb2x2ZXIsIHtcbiAgICAgICAgcm9vdDogdHJ1ZSxcbiAgICAgICAgYWZ0ZXJSZXNvbHZlKGxvZ28pIHtcbiAgICAgICAgICBsb2dvW1wiQGlkXCJdID0gcHJlZml4SWQoY3R4Lm1ldGEuaG9zdCwgXCIjbG9nb1wiKTtcbiAgICAgICAgICBzZXRJZkVtcHR5KGxvZ28sIFwiY2FwdGlvblwiLCBub2RlLm5hbWUpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICAgIGlmICh3ZWJQYWdlICYmIGxvZ29Ob2RlKVxuICAgICAgICBzZXRJZkVtcHR5KHdlYlBhZ2UsIFwicHJpbWFyeUltYWdlT2ZQYWdlXCIsIGlkUmVmZXJlbmNlKGxvZ29Ob2RlKSk7XG4gICAgICBpZiAobm9kZVtcIkB0eXBlXCJdID09PSBcIk9yZ2FuaXphdGlvblwiKSB7XG4gICAgICAgIG5vZGUubG9nbyA9IGxvZ29Ob2RlO1xuICAgICAgfSBlbHNlIGlmICghY3R4LmZpbmQoXCIjb3JnYW5pemF0aW9uXCIpKSB7XG4gICAgICAgIGNvbnN0IHJlc29sdmVkTG9nbyA9IGxvZ29Ob2RlICYmIHR5cGVvZiBsb2dvTm9kZSA9PT0gXCJvYmplY3RcIiAmJiBsb2dvTm9kZVtcIkBpZFwiXSA/IGN0eC5maW5kKGxvZ29Ob2RlW1wiQGlkXCJdLCBpc0ltYWdlT2JqZWN0KSA6IG51bGw7XG4gICAgICAgIGN0eC5ub2Rlcy5wdXNoKHtcbiAgICAgICAgICAvLyB3ZSB3YW50IHRvIG1ha2UgYSBzaW1wbGUgbm9kZSB0aGF0IGhhcyB0aGUgZXNzZW50aWFscywgdGhpcyB3aWxsIGFsbG93IHBhcmVudCBub2RlcyB0byBpbmplY3RcbiAgICAgICAgICAvLyBhcyB3ZWxsIHdpdGhvdXQgaW5zZXJ0aW5nIGludmFsaWQgZGF0YSAoaS5lIExvY2FsQnVzaW5lc3Mgb3BlcmF0aW5nSG91cnMpXG4gICAgICAgICAgXCJAdHlwZVwiOiBcIk9yZ2FuaXphdGlvblwiLFxuICAgICAgICAgIFwibmFtZVwiOiBub2RlLm5hbWUsXG4gICAgICAgICAgXCJ1cmxcIjogbm9kZS51cmwsXG4gICAgICAgICAgXCJzYW1lQXNcIjogbm9kZS5zYW1lQXMsXG4gICAgICAgICAgLy8gJ2ltYWdlJzogaWRSZWZlcmVuY2UobG9nb05vZGUpLFxuICAgICAgICAgIFwiYWRkcmVzc1wiOiBub2RlLmFkZHJlc3MsXG4gICAgICAgICAgLy8gbmVlZHMgdG8gYmUgYSBVUkxcbiAgICAgICAgICBcImxvZ29cIjogcmVzb2x2ZWRMb2dvPy51cmwsXG4gICAgICAgICAgXCJfcHJpb3JpdHlcIjogLTEsXG4gICAgICAgICAgXCJAaWRcIjogcHJlZml4SWQoY3R4Lm1ldGEuaG9zdCwgXCIjb3JnYW5pemF0aW9uXCIpXG4gICAgICAgICAgLy8gYXZvaWQgdGhlIGlkIHNvIG5vdGhpbmcgY2FuIGxpbmsgdG8gaXRcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBpZiAobm9kZVtcIkB0eXBlXCJdICE9PSBcIk9yZ2FuaXphdGlvblwiKVxuICAgICAgICBkZWxldGUgbm9kZS5sb2dvO1xuICAgIH1cbiAgICBpZiAoaXNJZGVudGl0eSAmJiB3ZWJQYWdlKVxuICAgICAgc2V0SWZFbXB0eSh3ZWJQYWdlLCBcImFib3V0XCIsIGlkUmVmZXJlbmNlKG5vZGUpKTtcbiAgICBjb25zdCB3ZWJTaXRlID0gY3R4LmZpbmQoUHJpbWFyeVdlYlNpdGVJZCk7XG4gICAgaWYgKHdlYlNpdGUpXG4gICAgICBzZXRJZkVtcHR5KHdlYlNpdGUsIFwicHVibGlzaGVyXCIsIGlkUmVmZXJlbmNlKG5vZGUpKTtcbiAgfVxufSk7XG5cbmNvbnN0IHJlYWRBY3Rpb25SZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiUmVhZEFjdGlvblwiXG4gIH0sXG4gIHJlc29sdmUobm9kZSwgY3R4KSB7XG4gICAgbm9kZS50YXJnZXQgfHw9IFtdO1xuICAgIGlmICghbm9kZS50YXJnZXQuaW5jbHVkZXMoY3R4Lm1ldGEudXJsKSlcbiAgICAgIG5vZGUudGFyZ2V0LnVuc2hpZnQoY3R4Lm1ldGEudXJsKTtcbiAgICByZXR1cm4gbm9kZTtcbiAgfVxufSk7XG5cbmNvbnN0IFByaW1hcnlXZWJQYWdlSWQgPSBcIiN3ZWJwYWdlXCI7XG5jb25zdCB3ZWJQYWdlUmVzb2x2ZXIgPSBkZWZpbmVTY2hlbWFPcmdSZXNvbHZlcih7XG4gIGRlZmF1bHRzKHsgbWV0YSB9KSB7XG4gICAgY29uc3QgZW5kUGF0aCA9IHdpdGhvdXRUcmFpbGluZ1NsYXNoKG1ldGEudXJsLnN1YnN0cmluZyhtZXRhLnVybC5sYXN0SW5kZXhPZihcIi9cIikgKyAxKSk7XG4gICAgbGV0IHR5cGUgPSBcIldlYlBhZ2VcIjtcbiAgICBzd2l0Y2ggKGVuZFBhdGgpIHtcbiAgICAgIGNhc2UgXCJhYm91dFwiOlxuICAgICAgY2FzZSBcImFib3V0LXVzXCI6XG4gICAgICAgIHR5cGUgPSBcIkFib3V0UGFnZVwiO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgXCJzZWFyY2hcIjpcbiAgICAgICAgdHlwZSA9IFwiU2VhcmNoUmVzdWx0c1BhZ2VcIjtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIFwiY2hlY2tvdXRcIjpcbiAgICAgICAgdHlwZSA9IFwiQ2hlY2tvdXRQYWdlXCI7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImNvbnRhY3RcIjpcbiAgICAgIGNhc2UgXCJnZXQtaW4tdG91Y2hcIjpcbiAgICAgIGNhc2UgXCJjb250YWN0LXVzXCI6XG4gICAgICAgIHR5cGUgPSBcIkNvbnRhY3RQYWdlXCI7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBcImZhcVwiOlxuICAgICAgICB0eXBlID0gXCJGQVFQYWdlXCI7XG4gICAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBjb25zdCBkZWZhdWx0cyA9IHtcbiAgICAgIFwiQHR5cGVcIjogdHlwZVxuICAgIH07XG4gICAgcmV0dXJuIGRlZmF1bHRzO1xuICB9LFxuICBpZFByZWZpeDogW1widXJsXCIsIFByaW1hcnlXZWJQYWdlSWRdLFxuICBpbmhlcml0TWV0YTogW1xuICAgIHsgbWV0YTogXCJ0aXRsZVwiLCBrZXk6IFwibmFtZVwiIH0sXG4gICAgXCJkZXNjcmlwdGlvblwiLFxuICAgIFwiZGF0ZVB1Ymxpc2hlZFwiLFxuICAgIFwiZGF0ZU1vZGlmaWVkXCIsXG4gICAgXCJ1cmxcIlxuICBdLFxuICByZXNvbHZlKG5vZGUsIGN0eCkge1xuICAgIG5vZGUuZGF0ZU1vZGlmaWVkID0gcmVzb2x2YWJsZURhdGVUb0lzbyhub2RlLmRhdGVNb2RpZmllZCk7XG4gICAgbm9kZS5kYXRlUHVibGlzaGVkID0gcmVzb2x2YWJsZURhdGVUb0lzbyhub2RlLmRhdGVQdWJsaXNoZWQpO1xuICAgIHJlc29sdmVEZWZhdWx0VHlwZShub2RlLCBcIldlYlBhZ2VcIik7XG4gICAgbm9kZS5hYm91dCA9IHJlc29sdmVSZWxhdGlvbihub2RlLmFib3V0LCBjdHgsIG9yZ2FuaXphdGlvblJlc29sdmVyKTtcbiAgICBub2RlLmJyZWFkY3J1bWIgPSByZXNvbHZlUmVsYXRpb24obm9kZS5icmVhZGNydW1iLCBjdHgsIGJyZWFkY3J1bWJSZXNvbHZlcik7XG4gICAgbm9kZS5hdXRob3IgPSByZXNvbHZlUmVsYXRpb24obm9kZS5hdXRob3IsIGN0eCwgcGVyc29uUmVzb2x2ZXIpO1xuICAgIG5vZGUucHJpbWFyeUltYWdlT2ZQYWdlID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUucHJpbWFyeUltYWdlT2ZQYWdlLCBjdHgsIGltYWdlUmVzb2x2ZXIpO1xuICAgIGlmIChub2RlLnBvdGVudGlhbEFjdGlvbikge1xuICAgICAgY29uc3QgcmVzb2x2ZUFjdGlvbiA9IChhY3Rpb24pID0+IHtcbiAgICAgICAgaWYgKCFhY3Rpb24gfHwgdHlwZW9mIGFjdGlvbiAhPT0gXCJvYmplY3RcIilcbiAgICAgICAgICByZXR1cm4gYWN0aW9uO1xuICAgICAgICBjb25zdCB0eXBlID0gYWN0aW9uW1wiQHR5cGVcIl07XG4gICAgICAgIGNvbnN0IGlzUmVhZEFjdGlvbiA9IHR5cGUgPT09IFwiUmVhZEFjdGlvblwiIHx8IEFycmF5LmlzQXJyYXkodHlwZSkgJiYgdHlwZS5pbmNsdWRlcyhcIlJlYWRBY3Rpb25cIikgfHwgXCJ0YXJnZXRcIiBpbiBhY3Rpb247XG4gICAgICAgIHJldHVybiBpc1JlYWRBY3Rpb24gPyByZXNvbHZlUmVsYXRpb24oYWN0aW9uLCBjdHgsIHJlYWRBY3Rpb25SZXNvbHZlcikgOiByZXNvbHZlUmVsYXRpb24oYWN0aW9uLCBjdHgpO1xuICAgICAgfTtcbiAgICAgIG5vZGUucG90ZW50aWFsQWN0aW9uID0gQXJyYXkuaXNBcnJheShub2RlLnBvdGVudGlhbEFjdGlvbikgPyBub2RlLnBvdGVudGlhbEFjdGlvbi5tYXAocmVzb2x2ZUFjdGlvbikgOiByZXNvbHZlQWN0aW9uKG5vZGUucG90ZW50aWFsQWN0aW9uKTtcbiAgICB9XG4gICAgaWYgKG5vZGVbXCJAdHlwZVwiXSA9PT0gXCJXZWJQYWdlXCIgJiYgY3R4Lm1ldGEudXJsKSB7XG4gICAgICBzZXRJZkVtcHR5KG5vZGUsIFwicG90ZW50aWFsQWN0aW9uXCIsIFtcbiAgICAgICAge1xuICAgICAgICAgIFwiQHR5cGVcIjogXCJSZWFkQWN0aW9uXCIsXG4gICAgICAgICAgXCJ0YXJnZXRcIjogW2N0eC5tZXRhLnVybF1cbiAgICAgICAgfVxuICAgICAgXSk7XG4gICAgfVxuICAgIHJldHVybiBub2RlO1xuICB9LFxuICByZXNvbHZlUm9vdE5vZGUod2ViUGFnZSwgeyBmaW5kLCBtZXRhIH0pIHtcbiAgICBjb25zdCBpZGVudGl0eSA9IGZpbmQoSWRlbnRpdHlJZCk7XG4gICAgY29uc3Qgd2ViU2l0ZSA9IGZpbmQoUHJpbWFyeVdlYlNpdGVJZCk7XG4gICAgY29uc3QgbG9nbyA9IGZpbmQoXCIjbG9nb1wiKTtcbiAgICBpZiAoaWRlbnRpdHkgJiYgbWV0YS51cmwgPT09IG1ldGEuaG9zdClcbiAgICAgIHNldElmRW1wdHkod2ViUGFnZSwgXCJhYm91dFwiLCBpZFJlZmVyZW5jZShpZGVudGl0eSkpO1xuICAgIGlmIChsb2dvKVxuICAgICAgc2V0SWZFbXB0eSh3ZWJQYWdlLCBcInByaW1hcnlJbWFnZU9mUGFnZVwiLCBpZFJlZmVyZW5jZShsb2dvKSk7XG4gICAgaWYgKHdlYlNpdGUpXG4gICAgICBzZXRJZkVtcHR5KHdlYlBhZ2UsIFwiaXNQYXJ0T2ZcIiwgaWRSZWZlcmVuY2Uod2ViU2l0ZSkpO1xuICAgIGNvbnN0IGJyZWFkY3J1bWIgPSBmaW5kKFByaW1hcnlCcmVhZGNydW1iSWQpO1xuICAgIGlmIChicmVhZGNydW1iKVxuICAgICAgc2V0SWZFbXB0eSh3ZWJQYWdlLCBcImJyZWFkY3J1bWJcIiwgaWRSZWZlcmVuY2UoYnJlYWRjcnVtYikpO1xuICAgIHJldHVybiB3ZWJQYWdlO1xuICB9XG59KTtcblxuY29uc3QgcGVyc29uUmVzb2x2ZXIgPSBkZWZpbmVTY2hlbWFPcmdSZXNvbHZlcih7XG4gIGNhc3Qobm9kZSkge1xuICAgIGlmICh0eXBlb2Ygbm9kZSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbmFtZTogbm9kZVxuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIG5vZGU7XG4gIH0sXG4gIGRlZmF1bHRzOiB7XG4gICAgXCJAdHlwZVwiOiBcIlBlcnNvblwiXG4gIH0sXG4gIGlkUHJlZml4OiBbXCJob3N0XCIsIElkZW50aXR5SWRdLFxuICByZXNvbHZlKG5vZGUsIGN0eCkge1xuICAgIGlmIChub2RlLnVybClcbiAgICAgIG5vZGUudXJsID0gcmVzb2x2ZVdpdGhCYXNlKGN0eC5tZXRhLmhvc3QsIG5vZGUudXJsKTtcbiAgICByZXR1cm4gbm9kZTtcbiAgfSxcbiAgcmVzb2x2ZVJvb3ROb2RlKG5vZGUsIHsgZmluZCwgbWV0YSB9KSB7XG4gICAgaWYgKHJlc29sdmVBc0dyYXBoS2V5KG5vZGVbXCJAaWRcIl0pID09PSBJZGVudGl0eUlkKSB7XG4gICAgICBzZXRJZkVtcHR5KG5vZGUsIFwidXJsXCIsIG1ldGEuaG9zdCk7XG4gICAgICBjb25zdCB3ZWJQYWdlID0gZmluZChQcmltYXJ5V2ViUGFnZUlkKTtcbiAgICAgIGlmICh3ZWJQYWdlKVxuICAgICAgICBzZXRJZkVtcHR5KHdlYlBhZ2UsIFwiYWJvdXRcIiwgaWRSZWZlcmVuY2Uobm9kZSkpO1xuICAgICAgY29uc3Qgd2ViU2l0ZSA9IGZpbmQoUHJpbWFyeVdlYlNpdGVJZCk7XG4gICAgICBpZiAod2ViU2l0ZSlcbiAgICAgICAgc2V0SWZFbXB0eSh3ZWJTaXRlLCBcInB1Ymxpc2hlclwiLCBpZFJlZmVyZW5jZShub2RlKSk7XG4gICAgfVxuICAgIGNvbnN0IGFydGljbGUgPSBmaW5kKFByaW1hcnlBcnRpY2xlSWQpO1xuICAgIGlmIChhcnRpY2xlKVxuICAgICAgc2V0SWZFbXB0eShhcnRpY2xlLCBcImF1dGhvclwiLCBpZFJlZmVyZW5jZShub2RlKSk7XG4gIH1cbn0pO1xuXG5jb25zdCBQcmltYXJ5QXJ0aWNsZUlkID0gXCIjYXJ0aWNsZVwiO1xuY29uc3QgYXJ0aWNsZVJlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJBcnRpY2xlXCJcbiAgfSxcbiAgaW5oZXJpdE1ldGE6IFtcbiAgICBcImluTGFuZ3VhZ2VcIixcbiAgICBcImRlc2NyaXB0aW9uXCIsXG4gICAgXCJpbWFnZVwiLFxuICAgIFwiZGF0ZU1vZGlmaWVkXCIsXG4gICAgXCJkYXRlUHVibGlzaGVkXCIsXG4gICAgeyBtZXRhOiBcInRpdGxlXCIsIGtleTogXCJoZWFkbGluZVwiIH1cbiAgXSxcbiAgaWRQcmVmaXg6IFtcInVybFwiLCBQcmltYXJ5QXJ0aWNsZUlkXSxcbiAgcmVzb2x2ZShub2RlLCBjdHgpIHtcbiAgICBub2RlLmF1dGhvciA9IHJlc29sdmVSZWxhdGlvbihub2RlLmF1dGhvciwgY3R4LCBwZXJzb25SZXNvbHZlciwge1xuICAgICAgcm9vdDogdHJ1ZVxuICAgIH0pO1xuICAgIG5vZGUucHVibGlzaGVyID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUucHVibGlzaGVyLCBjdHgpO1xuICAgIG5vZGUuZGF0ZU1vZGlmaWVkID0gcmVzb2x2YWJsZURhdGVUb0lzbyhub2RlLmRhdGVNb2RpZmllZCk7XG4gICAgbm9kZS5kYXRlUHVibGlzaGVkID0gcmVzb2x2YWJsZURhdGVUb0lzbyhub2RlLmRhdGVQdWJsaXNoZWQpO1xuICAgIHJlc29sdmVEZWZhdWx0VHlwZShub2RlLCBcIkFydGljbGVcIik7XG4gICAgbm9kZS5oZWFkbGluZSA9IHRyaW1MZW5ndGgobm9kZS5oZWFkbGluZSwgMTEwKTtcbiAgICByZXR1cm4gbm9kZTtcbiAgfSxcbiAgcmVzb2x2ZVJvb3ROb2RlKG5vZGUsIHsgZmluZCwgbWV0YSB9KSB7XG4gICAgY29uc3Qgd2ViUGFnZSA9IGZpbmQoUHJpbWFyeVdlYlBhZ2VJZCk7XG4gICAgY29uc3QgaWRlbnRpdHkgPSBmaW5kKElkZW50aXR5SWQpO1xuICAgIGlmIChub2RlLmltYWdlICYmICFub2RlLnRodW1ibmFpbFVybCkge1xuICAgICAgY29uc3QgZmlyc3RJbWFnZSA9IGFzQXJyYXkobm9kZS5pbWFnZSlbMF07XG4gICAgICBpZiAodHlwZW9mIGZpcnN0SW1hZ2UgPT09IFwic3RyaW5nXCIpXG4gICAgICAgIHNldElmRW1wdHkobm9kZSwgXCJ0aHVtYm5haWxVcmxcIiwgcmVzb2x2ZVdpdGhCYXNlKG1ldGEuaG9zdCwgZmlyc3RJbWFnZSkpO1xuICAgICAgZWxzZSBpZiAoZmlyc3RJbWFnZT8uW1wiQGlkXCJdKVxuICAgICAgICBzZXRJZkVtcHR5KG5vZGUsIFwidGh1bWJuYWlsVXJsXCIsIGZpbmQoZmlyc3RJbWFnZVtcIkBpZFwiXSwgaXNJbWFnZU9iamVjdCk/LnVybCk7XG4gICAgfVxuICAgIGlmIChpZGVudGl0eSkge1xuICAgICAgc2V0SWZFbXB0eShub2RlLCBcInB1Ymxpc2hlclwiLCBpZFJlZmVyZW5jZShpZGVudGl0eSkpO1xuICAgICAgc2V0SWZFbXB0eShub2RlLCBcImF1dGhvclwiLCBpZFJlZmVyZW5jZShpZGVudGl0eSkpO1xuICAgIH1cbiAgICBpZiAod2ViUGFnZSkge1xuICAgICAgc2V0SWZFbXB0eShub2RlLCBcImlzUGFydE9mXCIsIGlkUmVmZXJlbmNlKHdlYlBhZ2UpKTtcbiAgICAgIHNldElmRW1wdHkobm9kZSwgXCJtYWluRW50aXR5T2ZQYWdlXCIsIGlkUmVmZXJlbmNlKHdlYlBhZ2UpKTtcbiAgICAgIHNldElmRW1wdHkod2ViUGFnZSwgXCJwb3RlbnRpYWxBY3Rpb25cIiwgW1xuICAgICAgICB7XG4gICAgICAgICAgXCJAdHlwZVwiOiBcIlJlYWRBY3Rpb25cIixcbiAgICAgICAgICBcInRhcmdldFwiOiBbbWV0YS51cmxdXG4gICAgICAgIH1cbiAgICAgIF0pO1xuICAgICAgc2V0SWZFbXB0eSh3ZWJQYWdlLCBcImRhdGVNb2RpZmllZFwiLCBub2RlLmRhdGVNb2RpZmllZCk7XG4gICAgICBzZXRJZkVtcHR5KHdlYlBhZ2UsIFwiZGF0ZVB1Ymxpc2hlZFwiLCBub2RlLmRhdGVQdWJsaXNoZWQpO1xuICAgIH1cbiAgICByZXR1cm4gbm9kZTtcbiAgfVxufSk7XG5cbmNvbnN0IGJvb2tFZGl0aW9uUmVzb2x2ZXIgPSBkZWZpbmVTY2hlbWFPcmdSZXNvbHZlcih7XG4gIGRlZmF1bHRzOiB7XG4gICAgXCJAdHlwZVwiOiBcIkJvb2tcIlxuICB9LFxuICBpbmhlcml0TWV0YTogW1xuICAgIFwiaW5MYW5ndWFnZVwiXG4gIF0sXG4gIHJlc29sdmUobm9kZSwgY3R4KSB7XG4gICAgaWYgKG5vZGUuYm9va0Zvcm1hdClcbiAgICAgIG5vZGUuYm9va0Zvcm1hdCA9IHdpdGhCYXNlKG5vZGUuYm9va0Zvcm1hdCwgXCJodHRwczovL3NjaGVtYS5vcmcvXCIpO1xuICAgIGlmIChub2RlLmRhdGVQdWJsaXNoZWQpXG4gICAgICBub2RlLmRhdGVQdWJsaXNoZWQgPSByZXNvbHZhYmxlRGF0ZVRvRGF0ZShub2RlLmRhdGVQdWJsaXNoZWQpO1xuICAgIG5vZGUuYXV0aG9yID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUuYXV0aG9yLCBjdHgpO1xuICAgIHJldHVybiBub2RlO1xuICB9LFxuICByZXNvbHZlUm9vdE5vZGUobm9kZSwgeyBmaW5kIH0pIHtcbiAgICBjb25zdCBpZGVudGl0eSA9IGZpbmQoSWRlbnRpdHlJZCk7XG4gICAgaWYgKGlkZW50aXR5KVxuICAgICAgc2V0SWZFbXB0eShub2RlLCBcInByb3ZpZGVyXCIsIGlkUmVmZXJlbmNlKGlkZW50aXR5KSk7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn0pO1xuY29uc3QgUHJpbWFyeUJvb2tJZCA9IFwiI2Jvb2tcIjtcbmNvbnN0IGJvb2tSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiQm9va1wiXG4gIH0sXG4gIGluaGVyaXRNZXRhOiBbXG4gICAgXCJkZXNjcmlwdGlvblwiLFxuICAgIFwidXJsXCIsXG4gICAgeyBtZXRhOiBcInRpdGxlXCIsIGtleTogXCJuYW1lXCIgfVxuICBdLFxuICBpZFByZWZpeDogW1widXJsXCIsIFByaW1hcnlCb29rSWRdLFxuICByZXNvbHZlKG5vZGUsIGN0eCkge1xuICAgIG5vZGUud29ya0V4YW1wbGUgPSByZXNvbHZlUmVsYXRpb24obm9kZS53b3JrRXhhbXBsZSwgY3R4LCBib29rRWRpdGlvblJlc29sdmVyKTtcbiAgICBub2RlLmF1dGhvciA9IHJlc29sdmVSZWxhdGlvbihub2RlLmF1dGhvciwgY3R4KTtcbiAgICBpZiAobm9kZS51cmwgJiYgY3R4Lm1ldGEuaG9zdClcbiAgICAgIG5vZGUudXJsID0gd2l0aEJhc2Uobm9kZS51cmwsIGN0eC5tZXRhLmhvc3QpO1xuICAgIHJldHVybiBub2RlO1xuICB9LFxuICByZXNvbHZlUm9vdE5vZGUobm9kZSwgeyBmaW5kIH0pIHtcbiAgICBjb25zdCBpZGVudGl0eSA9IGZpbmQoSWRlbnRpdHlJZCk7XG4gICAgaWYgKGlkZW50aXR5KVxuICAgICAgc2V0SWZFbXB0eShub2RlLCBcImF1dGhvclwiLCBpZFJlZmVyZW5jZShpZGVudGl0eSkpO1xuICAgIHJldHVybiBub2RlO1xuICB9XG59KTtcblxuY29uc3QgY29tbWVudFJlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJDb21tZW50XCJcbiAgfSxcbiAgaWRQcmVmaXg6IFwidXJsXCIsXG4gIHJlc29sdmUobm9kZSwgY3R4KSB7XG4gICAgbm9kZS5hdXRob3IgPSByZXNvbHZlUmVsYXRpb24obm9kZS5hdXRob3IsIGN0eCwgcGVyc29uUmVzb2x2ZXIsIHtcbiAgICAgIHJvb3Q6IHRydWVcbiAgICB9KTtcbiAgICBub2RlLmRhdGVDcmVhdGVkID0gcmVzb2x2YWJsZURhdGVUb0lzbyhub2RlLmRhdGVDcmVhdGVkKTtcbiAgICBub2RlLmRhdGVNb2RpZmllZCA9IHJlc29sdmFibGVEYXRlVG9Jc28obm9kZS5kYXRlTW9kaWZpZWQpO1xuICAgIHJldHVybiBub2RlO1xuICB9LFxuICByZXNvbHZlUm9vdE5vZGUobm9kZSwgeyBmaW5kIH0pIHtcbiAgICBjb25zdCBhcnRpY2xlID0gZmluZChQcmltYXJ5QXJ0aWNsZUlkKTtcbiAgICBpZiAoYXJ0aWNsZSlcbiAgICAgIHNldElmRW1wdHkobm9kZSwgXCJhYm91dFwiLCBpZFJlZmVyZW5jZShhcnRpY2xlKSk7XG4gIH1cbn0pO1xuXG5jb25zdCBjb3Vyc2VSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiQ291cnNlXCJcbiAgfSxcbiAgcmVzb2x2ZShub2RlLCBjdHgpIHtcbiAgICBub2RlLnByb3ZpZGVyID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUucHJvdmlkZXIsIGN0eCwgb3JnYW5pemF0aW9uUmVzb2x2ZXIsIHtcbiAgICAgIHJvb3Q6IHRydWVcbiAgICB9KTtcbiAgICByZXR1cm4gbm9kZTtcbiAgfSxcbiAgcmVzb2x2ZVJvb3ROb2RlKG5vZGUsIHsgZmluZCB9KSB7XG4gICAgY29uc3QgaWRlbnRpdHkgPSBmaW5kKElkZW50aXR5SWQpO1xuICAgIGlmIChpZGVudGl0eSlcbiAgICAgIHNldElmRW1wdHkobm9kZSwgXCJwcm92aWRlclwiLCBpZFJlZmVyZW5jZShpZGVudGl0eSkpO1xuICAgIHJldHVybiBub2RlO1xuICB9XG59KTtcblxuY29uc3QgUHJpbWFyeURhdGFzZXRJZCA9IFwiI2RhdGFzZXRcIjtcbmNvbnN0IGRhdGFzZXRSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiRGF0YXNldFwiXG4gIH0sXG4gIGluaGVyaXRNZXRhOiBbXG4gICAgXCJkZXNjcmlwdGlvblwiLFxuICAgIFwidXJsXCIsXG4gICAgXCJkYXRlTW9kaWZpZWRcIixcbiAgICBcImRhdGVQdWJsaXNoZWRcIixcbiAgICB7IG1ldGE6IFwidGl0bGVcIiwga2V5OiBcIm5hbWVcIiB9XG4gIF0sXG4gIGlkUHJlZml4OiBbXCJ1cmxcIiwgUHJpbWFyeURhdGFzZXRJZF0sXG4gIHJlc29sdmUobm9kZSwgY3R4KSB7XG4gICAgcmVzb2x2ZURlZmF1bHRUeXBlKG5vZGUsIFwiRGF0YXNldFwiKTtcbiAgICBub2RlLmNyZWF0b3IgPSByZXNvbHZlUmVsYXRpb24obm9kZS5jcmVhdG9yLCBjdHgsIHBlcnNvblJlc29sdmVyLCB7XG4gICAgICByb290OiB0cnVlXG4gICAgfSk7XG4gICAgbm9kZS5kYXRlTW9kaWZpZWQgPSByZXNvbHZhYmxlRGF0ZVRvSXNvKG5vZGUuZGF0ZU1vZGlmaWVkKTtcbiAgICBub2RlLmRhdGVQdWJsaXNoZWQgPSByZXNvbHZhYmxlRGF0ZVRvSXNvKG5vZGUuZGF0ZVB1Ymxpc2hlZCk7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn0pO1xuXG5jb25zdCBwbGFjZVJlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJQbGFjZVwiXG4gIH0sXG4gIHJlc29sdmUobm9kZSwgY3R4KSB7XG4gICAgaWYgKHR5cGVvZiBub2RlLmFkZHJlc3MgIT09IFwic3RyaW5nXCIpXG4gICAgICBub2RlLmFkZHJlc3MgPSByZXNvbHZlUmVsYXRpb24obm9kZS5hZGRyZXNzLCBjdHgsIGFkZHJlc3NSZXNvbHZlcik7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn0pO1xuXG5jb25zdCB2aXJ0dWFsTG9jYXRpb25SZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgY2FzdChub2RlKSB7XG4gICAgaWYgKHR5cGVvZiBub2RlID09PSBcInN0cmluZ1wiKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB1cmw6IG5vZGVcbiAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBub2RlO1xuICB9LFxuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJWaXJ0dWFsTG9jYXRpb25cIlxuICB9XG59KTtcblxuY29uc3QgUHJpbWFyeUV2ZW50SWQgPSBcIiNldmVudFwiO1xuY29uc3QgZXZlbnRSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiRXZlbnRcIlxuICB9LFxuICBpbmhlcml0TWV0YTogW1xuICAgIFwiaW5MYW5ndWFnZVwiLFxuICAgIFwiZGVzY3JpcHRpb25cIixcbiAgICBcImltYWdlXCIsXG4gICAgeyBtZXRhOiBcInRpdGxlXCIsIGtleTogXCJuYW1lXCIgfVxuICBdLFxuICBpZFByZWZpeDogW1widXJsXCIsIFByaW1hcnlFdmVudElkXSxcbiAgcmVzb2x2ZShub2RlLCBjdHgpIHtcbiAgICBpZiAobm9kZS5sb2NhdGlvbikge1xuICAgICAgY29uc3QgcmVzb2x2ZUxvY2F0aW9uID0gKGxvY2F0aW9uKSA9PiB7XG4gICAgICAgIGNvbnN0IHR5cGUgPSB0eXBlb2YgbG9jYXRpb24gPT09IFwib2JqZWN0XCIgJiYgbG9jYXRpb24gIT09IG51bGwgPyBsb2NhdGlvbltcIkB0eXBlXCJdIDogdm9pZCAwO1xuICAgICAgICBjb25zdCBpc1ZpcnR1YWwgPSB0eXBlb2YgbG9jYXRpb24gPT09IFwic3RyaW5nXCIgfHwgdHlwZW9mIGxvY2F0aW9uID09PSBcIm9iamVjdFwiICYmIGxvY2F0aW9uICE9PSBudWxsICYmICh0eXBlID09PSBcIlZpcnR1YWxMb2NhdGlvblwiIHx8IEFycmF5LmlzQXJyYXkodHlwZSkgJiYgdHlwZS5pbmNsdWRlcyhcIlZpcnR1YWxMb2NhdGlvblwiKSB8fCB0eXBlb2YgbG9jYXRpb24udXJsICE9PSBcInVuZGVmaW5lZFwiKTtcbiAgICAgICAgcmV0dXJuIGlzVmlydHVhbCA/IHJlc29sdmVSZWxhdGlvbihsb2NhdGlvbiwgY3R4LCB2aXJ0dWFsTG9jYXRpb25SZXNvbHZlcikgOiByZXNvbHZlUmVsYXRpb24obG9jYXRpb24sIGN0eCwgcGxhY2VSZXNvbHZlcik7XG4gICAgICB9O1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkobm9kZS5sb2NhdGlvbikpIHtcbiAgICAgICAgY29uc3QgbG9jYXRpb25zID0gbm9kZS5sb2NhdGlvbi5tYXAocmVzb2x2ZUxvY2F0aW9uKTtcbiAgICAgICAgbm9kZS5sb2NhdGlvbiA9IGxvY2F0aW9ucy5sZW5ndGggPT09IDEgPyBsb2NhdGlvbnNbMF0gOiBsb2NhdGlvbnM7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBub2RlLmxvY2F0aW9uID0gcmVzb2x2ZUxvY2F0aW9uKG5vZGUubG9jYXRpb24pO1xuICAgICAgfVxuICAgIH1cbiAgICBub2RlLnBlcmZvcm1lciA9IHJlc29sdmVSZWxhdGlvbihub2RlLnBlcmZvcm1lciwgY3R4LCBwZXJzb25SZXNvbHZlciwge1xuICAgICAgcm9vdDogdHJ1ZVxuICAgIH0pO1xuICAgIG5vZGUub3JnYW5pemVyID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUub3JnYW5pemVyLCBjdHgsIG9yZ2FuaXphdGlvblJlc29sdmVyLCB7XG4gICAgICByb290OiB0cnVlXG4gICAgfSk7XG4gICAgbm9kZS5vZmZlcnMgPSByZXNvbHZlUmVsYXRpb24obm9kZS5vZmZlcnMsIGN0eCwgb2ZmZXJSZXNvbHZlcik7XG4gICAgaWYgKG5vZGUuZXZlbnRBdHRlbmRhbmNlTW9kZSlcbiAgICAgIG5vZGUuZXZlbnRBdHRlbmRhbmNlTW9kZSA9IHdpdGhCYXNlKG5vZGUuZXZlbnRBdHRlbmRhbmNlTW9kZSwgXCJodHRwczovL3NjaGVtYS5vcmcvXCIpO1xuICAgIGlmIChub2RlLmV2ZW50U3RhdHVzKVxuICAgICAgbm9kZS5ldmVudFN0YXR1cyA9IHdpdGhCYXNlKG5vZGUuZXZlbnRTdGF0dXMsIFwiaHR0cHM6Ly9zY2hlbWEub3JnL1wiKTtcbiAgICBjb25zdCBpc09ubGluZSA9IG5vZGUuZXZlbnRTdGF0dXMgPT09IFwiaHR0cHM6Ly9zY2hlbWEub3JnL0V2ZW50TW92ZWRPbmxpbmVcIiB8fCBub2RlLmV2ZW50QXR0ZW5kYW5jZU1vZGUgPT09IFwiaHR0cHM6Ly9zY2hlbWEub3JnL09ubGluZUV2ZW50QXR0ZW5kYW5jZU1vZGVcIjtcbiAgICBjb25zdCBkYXRlcyA9IFtcInN0YXJ0RGF0ZVwiLCBcInByZXZpb3VzU3RhcnREYXRlXCIsIFwiZW5kRGF0ZVwiXTtcbiAgICBkYXRlcy5mb3JFYWNoKChkYXRlKSA9PiB7XG4gICAgICBpZiAoIWlzT25saW5lKSB7XG4gICAgICAgIGlmIChub2RlW2RhdGVdIGluc3RhbmNlb2YgRGF0ZSAmJiBub2RlW2RhdGVdLmdldEhvdXJzKCkgPT09IDAgJiYgbm9kZVtkYXRlXS5nZXRNaW51dGVzKCkgPT09IDApXG4gICAgICAgICAgbm9kZVtkYXRlXSA9IHJlc29sdmFibGVEYXRlVG9EYXRlKG5vZGVbZGF0ZV0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbm9kZVtkYXRlXSA9IHJlc29sdmFibGVEYXRlVG9Jc28obm9kZVtkYXRlXSk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgc2V0SWZFbXB0eShub2RlLCBcImVuZERhdGVcIiwgbm9kZS5zdGFydERhdGUpO1xuICAgIHJldHVybiBub2RlO1xuICB9LFxuICByZXNvbHZlUm9vdE5vZGUobm9kZSwgeyBmaW5kIH0pIHtcbiAgICBjb25zdCBpZGVudGl0eSA9IGZpbmQoSWRlbnRpdHlJZCk7XG4gICAgaWYgKGlkZW50aXR5KVxuICAgICAgc2V0SWZFbXB0eShub2RlLCBcIm9yZ2FuaXplclwiLCBpZFJlZmVyZW5jZShpZGVudGl0eSkpO1xuICB9XG59KTtcblxuY29uc3Qgb3BlbmluZ0hvdXJzUmVzb2x2ZXIgPSBkZWZpbmVTY2hlbWFPcmdSZXNvbHZlcih7XG4gIGRlZmF1bHRzOiB7XG4gICAgXCJAdHlwZVwiOiBcIk9wZW5pbmdIb3Vyc1NwZWNpZmljYXRpb25cIixcbiAgICBcIm9wZW5zXCI6IFwiMDA6MDBcIixcbiAgICBcImNsb3Nlc1wiOiBcIjIzOjU5XCJcbiAgfVxufSk7XG5cbmNvbnN0IGxvY2FsQnVzaW5lc3NSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFtcIk9yZ2FuaXphdGlvblwiLCBcIkxvY2FsQnVzaW5lc3NcIl1cbiAgfSxcbiAgaW5oZXJpdE1ldGE6IFtcbiAgICB7IGtleTogXCJ1cmxcIiwgbWV0YTogXCJob3N0XCIgfSxcbiAgICB7IGtleTogXCJjdXJyZW5jaWVzQWNjZXB0ZWRcIiwgbWV0YTogXCJjdXJyZW5jeVwiIH1cbiAgXSxcbiAgaWRQcmVmaXg6IFtcImhvc3RcIiwgSWRlbnRpdHlJZF0sXG4gIHJlc29sdmUobm9kZSwgY3R4KSB7XG4gICAgcmVzb2x2ZURlZmF1bHRUeXBlKG5vZGUsIFtcIk9yZ2FuaXphdGlvblwiLCBcIkxvY2FsQnVzaW5lc3NcIl0pO1xuICAgIG5vZGUuYWRkcmVzcyA9IHJlc29sdmVSZWxhdGlvbihub2RlLmFkZHJlc3MsIGN0eCwgYWRkcmVzc1Jlc29sdmVyKTtcbiAgICBub2RlLm9wZW5pbmdIb3Vyc1NwZWNpZmljYXRpb24gPSByZXNvbHZlUmVsYXRpb24obm9kZS5vcGVuaW5nSG91cnNTcGVjaWZpY2F0aW9uLCBjdHgsIG9wZW5pbmdIb3Vyc1Jlc29sdmVyKTtcbiAgICBub2RlID0gcmVzb2x2ZU5vZGUoeyAuLi5ub2RlIH0sIGN0eCwgb3JnYW5pemF0aW9uUmVzb2x2ZXIpO1xuICAgIHJldHVybiBub2RlO1xuICB9LFxuICByZXNvbHZlUm9vdE5vZGUobm9kZSwgY3R4KSB7XG4gICAgb3JnYW5pemF0aW9uUmVzb2x2ZXIucmVzb2x2ZVJvb3ROb2RlKG5vZGUsIGN0eCk7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn0pO1xuXG5jb25zdCByYXRpbmdSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgY2FzdChub2RlKSB7XG4gICAgaWYgKHR5cGVvZiBub2RlID09PSBcIm51bWJlclwiKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICByYXRpbmdWYWx1ZTogbm9kZVxuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIG5vZGU7XG4gIH0sXG4gIGRlZmF1bHRzOiB7XG4gICAgXCJAdHlwZVwiOiBcIlJhdGluZ1wiLFxuICAgIFwiYmVzdFJhdGluZ1wiOiA1LFxuICAgIFwid29yc3RSYXRpbmdcIjogMVxuICB9XG59KTtcblxuY29uc3QgZm9vZEVzdGFibGlzaG1lbnRSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFtcIk9yZ2FuaXphdGlvblwiLCBcIkxvY2FsQnVzaW5lc3NcIiwgXCJGb29kRXN0YWJsaXNobWVudFwiXVxuICB9LFxuICBpbmhlcml0TWV0YTogW1xuICAgIHsga2V5OiBcInVybFwiLCBtZXRhOiBcImhvc3RcIiB9LFxuICAgIHsga2V5OiBcImN1cnJlbmNpZXNBY2NlcHRlZFwiLCBtZXRhOiBcImN1cnJlbmN5XCIgfVxuICBdLFxuICBpZFByZWZpeDogW1wiaG9zdFwiLCBJZGVudGl0eUlkXSxcbiAgcmVzb2x2ZShub2RlLCBjdHgpIHtcbiAgICByZXNvbHZlRGVmYXVsdFR5cGUobm9kZSwgW1wiT3JnYW5pemF0aW9uXCIsIFwiTG9jYWxCdXNpbmVzc1wiLCBcIkZvb2RFc3RhYmxpc2htZW50XCJdKTtcbiAgICBub2RlLnN0YXJSYXRpbmcgPSByZXNvbHZlUmVsYXRpb24obm9kZS5zdGFyUmF0aW5nLCBjdHgsIHJhdGluZ1Jlc29sdmVyKTtcbiAgICBub2RlID0gcmVzb2x2ZU5vZGUobm9kZSwgY3R4LCBsb2NhbEJ1c2luZXNzUmVzb2x2ZXIpO1xuICAgIHJldHVybiBub2RlO1xuICB9LFxuICByZXNvbHZlUm9vdE5vZGUobm9kZSwgY3R4KSB7XG4gICAgbG9jYWxCdXNpbmVzc1Jlc29sdmVyLnJlc29sdmVSb290Tm9kZShub2RlLCBjdHgpO1xuICAgIHJldHVybiBub2RlO1xuICB9XG59KTtcblxuY29uc3QgaG93VG9TdGVwRGlyZWN0aW9uUmVzb2x2ZXIgPSBkZWZpbmVTY2hlbWFPcmdSZXNvbHZlcih7XG4gIGNhc3Qobm9kZSkge1xuICAgIGlmICh0eXBlb2Ygbm9kZSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdGV4dDogbm9kZVxuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIG5vZGU7XG4gIH0sXG4gIGRlZmF1bHRzOiB7XG4gICAgXCJAdHlwZVwiOiBcIkhvd1RvRGlyZWN0aW9uXCJcbiAgfVxufSk7XG5cbmNvbnN0IGhvd1RvU3RlcFJlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBjYXN0KG5vZGUpIHtcbiAgICBpZiAodHlwZW9mIG5vZGUgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHRleHQ6IG5vZGVcbiAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBub2RlO1xuICB9LFxuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJIb3dUb1N0ZXBcIlxuICB9LFxuICByZXNvbHZlKHN0ZXAsIGN0eCkge1xuICAgIGlmIChzdGVwLnVybClcbiAgICAgIHN0ZXAudXJsID0gcmVzb2x2ZVdpdGhCYXNlKGN0eC5tZXRhLnVybCwgc3RlcC51cmwpO1xuICAgIGlmIChzdGVwLmltYWdlKSB7XG4gICAgICBzdGVwLmltYWdlID0gcmVzb2x2ZVJlbGF0aW9uKHN0ZXAuaW1hZ2UsIGN0eCwgaW1hZ2VSZXNvbHZlciwge1xuICAgICAgICByb290OiB0cnVlXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKHN0ZXAuaXRlbUxpc3RFbGVtZW50KVxuICAgICAgc3RlcC5pdGVtTGlzdEVsZW1lbnQgPSByZXNvbHZlUmVsYXRpb24oc3RlcC5pdGVtTGlzdEVsZW1lbnQsIGN0eCwgaG93VG9TdGVwRGlyZWN0aW9uUmVzb2x2ZXIpO1xuICAgIHJldHVybiBzdGVwO1xuICB9XG59KTtcblxuY29uc3QgSG93VG9JZCA9IFwiI2hvd3RvXCI7XG5jb25zdCBob3dUb1Jlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJIb3dUb1wiXG4gIH0sXG4gIGluaGVyaXRNZXRhOiBbXG4gICAgXCJkZXNjcmlwdGlvblwiLFxuICAgIFwiaW1hZ2VcIixcbiAgICBcImluTGFuZ3VhZ2VcIixcbiAgICB7IG1ldGE6IFwidGl0bGVcIiwga2V5OiBcIm5hbWVcIiB9XG4gIF0sXG4gIGlkUHJlZml4OiBbXCJ1cmxcIiwgSG93VG9JZF0sXG4gIHJlc29sdmUobm9kZSwgY3R4KSB7XG4gICAgbm9kZS5zdGVwID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUuc3RlcCwgY3R4LCBob3dUb1N0ZXBSZXNvbHZlcik7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH0sXG4gIHJlc29sdmVSb290Tm9kZShub2RlLCB7IGZpbmQgfSkge1xuICAgIGNvbnN0IHdlYlBhZ2UgPSBmaW5kKFByaW1hcnlXZWJQYWdlSWQpO1xuICAgIGlmICh3ZWJQYWdlKVxuICAgICAgc2V0SWZFbXB0eShub2RlLCBcIm1haW5FbnRpdHlPZlBhZ2VcIiwgaWRSZWZlcmVuY2Uod2ViUGFnZSkpO1xuICB9XG59KTtcblxuY29uc3QgaXRlbUxpc3RSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiSXRlbUxpc3RcIlxuICB9LFxuICByZXNvbHZlKG5vZGUsIGN0eCkge1xuICAgIGlmIChub2RlLml0ZW1MaXN0RWxlbWVudCkge1xuICAgICAgbGV0IGluZGV4ID0gMTtcbiAgICAgIG5vZGUuaXRlbUxpc3RFbGVtZW50ID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUuaXRlbUxpc3RFbGVtZW50LCBjdHgsIGxpc3RJdGVtUmVzb2x2ZXIsIHtcbiAgICAgICAgYXJyYXk6IHRydWUsXG4gICAgICAgIGFmdGVyUmVzb2x2ZShub2RlMikge1xuICAgICAgICAgIHNldElmRW1wdHkobm9kZTIsIFwicG9zaXRpb25cIiwgaW5kZXgrKyk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gbm9kZTtcbiAgfVxufSk7XG5cbmNvbnN0IGpvYlBvc3RpbmdSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiSm9iUG9zdGluZ1wiXG4gIH0sXG4gIGlkUHJlZml4OiBbXCJ1cmxcIiwgXCIjam9iLXBvc3RpbmdcIl0sXG4gIHJlc29sdmUobm9kZSwgY3R4KSB7XG4gICAgbm9kZS5kYXRlUG9zdGVkID0gcmVzb2x2YWJsZURhdGVUb0lzbyhub2RlLmRhdGVQb3N0ZWQpO1xuICAgIG5vZGUuaGlyaW5nT3JnYW5pemF0aW9uID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUuaGlyaW5nT3JnYW5pemF0aW9uLCBjdHgsIG9yZ2FuaXphdGlvblJlc29sdmVyKTtcbiAgICBub2RlLmpvYkxvY2F0aW9uID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUuam9iTG9jYXRpb24sIGN0eCwgcGxhY2VSZXNvbHZlcik7XG4gICAgbm9kZS5iYXNlU2FsYXJ5ID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUuYmFzZVNhbGFyeSwgY3R4LCBtb25ldGFyeUFtb3VudFJlc29sdmVyKTtcbiAgICBub2RlLnZhbGlkVGhyb3VnaCA9IHJlc29sdmFibGVEYXRlVG9Jc28obm9kZS52YWxpZFRocm91Z2gpO1xuICAgIHJldHVybiBub2RlO1xuICB9LFxuICByZXNvbHZlUm9vdE5vZGUoam9iUG9zdGluZywgeyBmaW5kIH0pIHtcbiAgICBjb25zdCB3ZWJQYWdlID0gZmluZChQcmltYXJ5V2ViUGFnZUlkKTtcbiAgICBjb25zdCBpZGVudGl0eSA9IGZpbmQoSWRlbnRpdHlJZCk7XG4gICAgaWYgKGlkZW50aXR5KVxuICAgICAgc2V0SWZFbXB0eShqb2JQb3N0aW5nLCBcImhpcmluZ09yZ2FuaXphdGlvblwiLCBpZFJlZmVyZW5jZShpZGVudGl0eSkpO1xuICAgIGlmICh3ZWJQYWdlKVxuICAgICAgc2V0SWZFbXB0eShqb2JQb3N0aW5nLCBcIm1haW5FbnRpdHlPZlBhZ2VcIiwgaWRSZWZlcmVuY2Uod2ViUGFnZSkpO1xuICAgIHJldHVybiBqb2JQb3N0aW5nO1xuICB9XG59KTtcblxuY29uc3QgcmV2aWV3UmVzb2x2ZXIgPSBkZWZpbmVTY2hlbWFPcmdSZXNvbHZlcih7XG4gIGRlZmF1bHRzOiB7XG4gICAgXCJAdHlwZVwiOiBcIlJldmlld1wiXG4gIH0sXG4gIGluaGVyaXRNZXRhOiBbXG4gICAgXCJpbkxhbmd1YWdlXCJcbiAgXSxcbiAgcmVzb2x2ZShyZXZpZXcsIGN0eCkge1xuICAgIHJldmlldy5yZXZpZXdSYXRpbmcgPSByZXNvbHZlUmVsYXRpb24ocmV2aWV3LnJldmlld1JhdGluZywgY3R4LCByYXRpbmdSZXNvbHZlcik7XG4gICAgcmV2aWV3LmF1dGhvciA9IHJlc29sdmVSZWxhdGlvbihyZXZpZXcuYXV0aG9yLCBjdHgsIHBlcnNvblJlc29sdmVyKTtcbiAgICByZXR1cm4gcmV2aWV3O1xuICB9XG59KTtcblxuY29uc3QgdmlkZW9SZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgY2FzdChpbnB1dCkge1xuICAgIGlmICh0eXBlb2YgaW5wdXQgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIGlucHV0ID0ge1xuICAgICAgICB1cmw6IGlucHV0XG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gaW5wdXQ7XG4gIH0sXG4gIGFsaWFzOiBcInZpZGVvXCIsXG4gIGRlZmF1bHRzOiB7XG4gICAgXCJAdHlwZVwiOiBcIlZpZGVvT2JqZWN0XCJcbiAgfSxcbiAgaW5oZXJpdE1ldGE6IFtcbiAgICB7IG1ldGE6IFwidGl0bGVcIiwga2V5OiBcIm5hbWVcIiB9LFxuICAgIFwiZGVzY3JpcHRpb25cIixcbiAgICBcImltYWdlXCIsXG4gICAgXCJpbkxhbmd1YWdlXCIsXG4gICAgeyBtZXRhOiBcImRhdGVQdWJsaXNoZWRcIiwga2V5OiBcInVwbG9hZERhdGVcIiB9XG4gIF0sXG4gIGlkUHJlZml4OiBcImhvc3RcIixcbiAgcmVzb2x2ZSh2aWRlbywgY3R4KSB7XG4gICAgaWYgKHZpZGVvLnVwbG9hZERhdGUpXG4gICAgICB2aWRlby51cGxvYWREYXRlID0gcmVzb2x2YWJsZURhdGVUb0lzbyh2aWRlby51cGxvYWREYXRlKTtcbiAgICB2aWRlby51cmwgPSByZXNvbHZlV2l0aEJhc2UoY3R4Lm1ldGEuaG9zdCwgdmlkZW8udXJsKTtcbiAgICBpZiAodmlkZW8uY2FwdGlvbiAmJiAhdmlkZW8uZGVzY3JpcHRpb24pXG4gICAgICB2aWRlby5kZXNjcmlwdGlvbiA9IHZpZGVvLmNhcHRpb247XG4gICAgaWYgKCF2aWRlby5kZXNjcmlwdGlvbilcbiAgICAgIHZpZGVvLmRlc2NyaXB0aW9uID0gXCJObyBkZXNjcmlwdGlvblwiO1xuICAgIGlmICh2aWRlby50aHVtYm5haWxVcmwgJiYgKHR5cGVvZiB2aWRlby50aHVtYm5haWxVcmwgPT09IFwic3RyaW5nXCIgfHwgQXJyYXkuaXNBcnJheSh2aWRlby50aHVtYm5haWxVcmwpKSkge1xuICAgICAgY29uc3QgaW1hZ2VzID0gYXNBcnJheSh2aWRlby50aHVtYm5haWxVcmwpLm1hcCgoaW1hZ2UpID0+IHJlc29sdmVXaXRoQmFzZShjdHgubWV0YS5ob3N0LCBpbWFnZSkpO1xuICAgICAgdmlkZW8udGh1bWJuYWlsVXJsID0gaW1hZ2VzLmxlbmd0aCA+IDEgPyBpbWFnZXMgOiBpbWFnZXNbMF07XG4gICAgfVxuICAgIGlmICh2aWRlby50aHVtYm5haWwpXG4gICAgICB2aWRlby50aHVtYm5haWwgPSByZXNvbHZlUmVsYXRpb24odmlkZW8udGh1bWJuYWlsLCBjdHgsIGltYWdlUmVzb2x2ZXIpO1xuICAgIHJldHVybiB2aWRlbztcbiAgfSxcbiAgcmVzb2x2ZVJvb3ROb2RlKHZpZGVvLCB7IGZpbmQsIG1ldGEgfSkge1xuICAgIGlmICh2aWRlby5pbWFnZSAmJiAhdmlkZW8udGh1bWJuYWlsVXJsKSB7XG4gICAgICBjb25zdCBmaXJzdEltYWdlID0gYXNBcnJheSh2aWRlby5pbWFnZSlbMF07XG4gICAgICBpZiAodHlwZW9mIGZpcnN0SW1hZ2UgPT09IFwic3RyaW5nXCIpXG4gICAgICAgIHNldElmRW1wdHkodmlkZW8sIFwidGh1bWJuYWlsVXJsXCIsIHJlc29sdmVXaXRoQmFzZShtZXRhLmhvc3QsIGZpcnN0SW1hZ2UpKTtcbiAgICAgIGVsc2UgaWYgKGZpcnN0SW1hZ2U/LltcIkBpZFwiXSlcbiAgICAgICAgc2V0SWZFbXB0eSh2aWRlbywgXCJ0aHVtYm5haWxVcmxcIiwgZmluZChmaXJzdEltYWdlW1wiQGlkXCJdLCBpc0ltYWdlT2JqZWN0KT8udXJsKTtcbiAgICB9XG4gIH1cbn0pO1xuXG5jb25zdCBtb3ZpZVJlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJNb3ZpZVwiXG4gIH0sXG4gIHJlc29sdmUobm9kZSwgY3R4KSB7XG4gICAgbm9kZS5hZ2dyZWdhdGVSYXRpbmcgPSByZXNvbHZlUmVsYXRpb24obm9kZS5hZ2dyZWdhdGVSYXRpbmcsIGN0eCwgYWdncmVnYXRlUmF0aW5nUmVzb2x2ZXIpO1xuICAgIG5vZGUucmV2aWV3ID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUucmV2aWV3LCBjdHgsIHJldmlld1Jlc29sdmVyKTtcbiAgICBub2RlLmRpcmVjdG9yID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUuZGlyZWN0b3IsIGN0eCwgcGVyc29uUmVzb2x2ZXIpO1xuICAgIG5vZGUuYWN0b3IgPSByZXNvbHZlUmVsYXRpb24obm9kZS5hY3RvciwgY3R4LCBwZXJzb25SZXNvbHZlcik7XG4gICAgbm9kZS50cmFpbGVyID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUudHJhaWxlciwgY3R4LCB2aWRlb1Jlc29sdmVyKTtcbiAgICBub2RlLnByb2R1Y3Rpb25Db21wYW55ID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUucHJvZHVjdGlvbkNvbXBhbnksIGN0eCwgb3JnYW5pemF0aW9uUmVzb2x2ZXIpO1xuICAgIGlmIChub2RlLmRhdGVDcmVhdGVkKVxuICAgICAgbm9kZS5kYXRlQ3JlYXRlZCA9IHJlc29sdmFibGVEYXRlVG9EYXRlKG5vZGUuZGF0ZUNyZWF0ZWQpO1xuICAgIHJldHVybiBub2RlO1xuICB9XG59KTtcblxuY29uc3QgbXVzaWNBbGJ1bVJlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJNdXNpY0FsYnVtXCJcbiAgfSxcbiAgaWRQcmVmaXg6IFwiaG9zdFwiLFxuICByZXNvbHZlKG5vZGUsIGN0eCkge1xuICAgIGlmIChub2RlLmRhdGVQdWJsaXNoZWQpXG4gICAgICBub2RlLmRhdGVQdWJsaXNoZWQgPSByZXNvbHZhYmxlRGF0ZVRvSXNvKG5vZGUuZGF0ZVB1Ymxpc2hlZCk7XG4gICAgaWYgKG5vZGUudXJsKVxuICAgICAgbm9kZS51cmwgPSByZXNvbHZlV2l0aEJhc2UoY3R4Lm1ldGEuaG9zdCwgbm9kZS51cmwpO1xuICAgIG5vZGUuYnlBcnRpc3QgPSByZXNvbHZlUmVsYXRpb24obm9kZS5ieUFydGlzdCwgY3R4LCBwZXJzb25SZXNvbHZlcik7XG4gICAgbm9kZS5hZ2dyZWdhdGVSYXRpbmcgPSByZXNvbHZlUmVsYXRpb24obm9kZS5hZ2dyZWdhdGVSYXRpbmcsIGN0eCwgYWdncmVnYXRlUmF0aW5nUmVzb2x2ZXIpO1xuICAgIG5vZGUucmV2aWV3ID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUucmV2aWV3LCBjdHgsIHJldmlld1Jlc29sdmVyKTtcbiAgICByZXR1cm4gbm9kZTtcbiAgfVxufSk7XG5cbmNvbnN0IG11c2ljR3JvdXBSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiTXVzaWNHcm91cFwiXG4gIH0sXG4gIGlkUHJlZml4OiBcImhvc3RcIixcbiAgaW5oZXJpdE1ldGE6IFtcbiAgICB7IG1ldGE6IFwiaG9zdFwiLCBrZXk6IFwidXJsXCIgfVxuICBdLFxuICByZXNvbHZlKG5vZGUsIGN0eCkge1xuICAgIGlmIChub2RlLmZvdW5kaW5nRGF0ZSlcbiAgICAgIG5vZGUuZm91bmRpbmdEYXRlID0gcmVzb2x2YWJsZURhdGVUb0RhdGUobm9kZS5mb3VuZGluZ0RhdGUpO1xuICAgIGlmIChub2RlLmRpc3NvbHV0aW9uRGF0ZSlcbiAgICAgIG5vZGUuZGlzc29sdXRpb25EYXRlID0gcmVzb2x2YWJsZURhdGVUb0RhdGUobm9kZS5kaXNzb2x1dGlvbkRhdGUpO1xuICAgIGlmIChub2RlLnVybClcbiAgICAgIG5vZGUudXJsID0gcmVzb2x2ZVdpdGhCYXNlKGN0eC5tZXRhLmhvc3QsIG5vZGUudXJsKTtcbiAgICBub2RlLm1lbWJlciA9IHJlc29sdmVSZWxhdGlvbihub2RlLm1lbWJlciwgY3R4LCBwZXJzb25SZXNvbHZlcik7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn0pO1xuXG5jb25zdCBtdXNpY1BsYXlsaXN0UmVzb2x2ZXIgPSBkZWZpbmVTY2hlbWFPcmdSZXNvbHZlcih7XG4gIGRlZmF1bHRzOiB7XG4gICAgXCJAdHlwZVwiOiBcIk11c2ljUGxheWxpc3RcIlxuICB9LFxuICBpZFByZWZpeDogXCJob3N0XCIsXG4gIHJlc29sdmUobm9kZSwgY3R4KSB7XG4gICAgaWYgKG5vZGUuZGF0ZVB1Ymxpc2hlZClcbiAgICAgIG5vZGUuZGF0ZVB1Ymxpc2hlZCA9IHJlc29sdmFibGVEYXRlVG9Jc28obm9kZS5kYXRlUHVibGlzaGVkKTtcbiAgICBpZiAobm9kZS5kYXRlTW9kaWZpZWQpXG4gICAgICBub2RlLmRhdGVNb2RpZmllZCA9IHJlc29sdmFibGVEYXRlVG9Jc28obm9kZS5kYXRlTW9kaWZpZWQpO1xuICAgIGlmIChub2RlLnVybClcbiAgICAgIG5vZGUudXJsID0gcmVzb2x2ZVdpdGhCYXNlKGN0eC5tZXRhLmhvc3QsIG5vZGUudXJsKTtcbiAgICBub2RlLmNyZWF0b3IgPSByZXNvbHZlUmVsYXRpb24obm9kZS5jcmVhdG9yLCBjdHgsIHBlcnNvblJlc29sdmVyKTtcbiAgICBub2RlLmFnZ3JlZ2F0ZVJhdGluZyA9IHJlc29sdmVSZWxhdGlvbihub2RlLmFnZ3JlZ2F0ZVJhdGluZywgY3R4LCBhZ2dyZWdhdGVSYXRpbmdSZXNvbHZlcik7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn0pO1xuXG5jb25zdCBtdXNpY1JlY29yZGluZ1Jlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJNdXNpY1JlY29yZGluZ1wiXG4gIH0sXG4gIGlkUHJlZml4OiBcImhvc3RcIixcbiAgcmVzb2x2ZShub2RlLCBjdHgpIHtcbiAgICBpZiAobm9kZS5kYXRlUHVibGlzaGVkKVxuICAgICAgbm9kZS5kYXRlUHVibGlzaGVkID0gcmVzb2x2YWJsZURhdGVUb0lzbyhub2RlLmRhdGVQdWJsaXNoZWQpO1xuICAgIGlmIChub2RlLnVybClcbiAgICAgIG5vZGUudXJsID0gcmVzb2x2ZVdpdGhCYXNlKGN0eC5tZXRhLmhvc3QsIG5vZGUudXJsKTtcbiAgICBpZiAobm9kZS5hdWRpbylcbiAgICAgIG5vZGUuYXVkaW8gPSByZXNvbHZlV2l0aEJhc2UoY3R4Lm1ldGEuaG9zdCwgbm9kZS5hdWRpbyk7XG4gICAgbm9kZS5ieUFydGlzdCA9IHJlc29sdmVSZWxhdGlvbihub2RlLmJ5QXJ0aXN0LCBjdHgsIHBlcnNvblJlc29sdmVyKTtcbiAgICBub2RlLmFnZ3JlZ2F0ZVJhdGluZyA9IHJlc29sdmVSZWxhdGlvbihub2RlLmFnZ3JlZ2F0ZVJhdGluZywgY3R4LCBhZ2dyZWdhdGVSYXRpbmdSZXNvbHZlcik7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn0pO1xuXG5jb25zdCBwb2RjYXN0RXBpc29kZVJlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJQb2RjYXN0RXBpc29kZVwiXG4gIH0sXG4gIGluaGVyaXRNZXRhOiBbXG4gICAgXCJpbkxhbmd1YWdlXCJcbiAgXSxcbiAgcmVzb2x2ZShub2RlLCBjdHgpIHtcbiAgICBub2RlLmF1dGhvciA9IHJlc29sdmVSZWxhdGlvbihub2RlLmF1dGhvciwgY3R4LCBwZXJzb25SZXNvbHZlcik7XG4gICAgbm9kZS5hZ2dyZWdhdGVSYXRpbmcgPSByZXNvbHZlUmVsYXRpb24obm9kZS5hZ2dyZWdhdGVSYXRpbmcsIGN0eCwgYWdncmVnYXRlUmF0aW5nUmVzb2x2ZXIpO1xuICAgIG5vZGUucmV2aWV3ID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUucmV2aWV3LCBjdHgsIHJldmlld1Jlc29sdmVyKTtcbiAgICBpZiAobm9kZS5kYXRlUHVibGlzaGVkKVxuICAgICAgbm9kZS5kYXRlUHVibGlzaGVkID0gcmVzb2x2YWJsZURhdGVUb0lzbyhub2RlLmRhdGVQdWJsaXNoZWQpO1xuICAgIGlmIChub2RlLnVwbG9hZERhdGUpXG4gICAgICBub2RlLnVwbG9hZERhdGUgPSByZXNvbHZhYmxlRGF0ZVRvSXNvKG5vZGUudXBsb2FkRGF0ZSk7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn0pO1xuXG5jb25zdCBwb2RjYXN0U2Vhc29uUmVzb2x2ZXIgPSBkZWZpbmVTY2hlbWFPcmdSZXNvbHZlcih7XG4gIGRlZmF1bHRzOiB7XG4gICAgXCJAdHlwZVwiOiBcIlBvZGNhc3RTZWFzb25cIlxuICB9LFxuICByZXNvbHZlKG5vZGUsIGN0eCkge1xuICAgIG5vZGUuYWN0b3IgPSByZXNvbHZlUmVsYXRpb24obm9kZS5hY3RvciwgY3R4LCBwZXJzb25SZXNvbHZlcik7XG4gICAgbm9kZS5kaXJlY3RvciA9IHJlc29sdmVSZWxhdGlvbihub2RlLmRpcmVjdG9yLCBjdHgsIHBlcnNvblJlc29sdmVyKTtcbiAgICBub2RlLnByb2R1Y3Rpb25Db21wYW55ID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUucHJvZHVjdGlvbkNvbXBhbnksIGN0eCwgb3JnYW5pemF0aW9uUmVzb2x2ZXIpO1xuICAgIG5vZGUuYWdncmVnYXRlUmF0aW5nID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUuYWdncmVnYXRlUmF0aW5nLCBjdHgsIGFnZ3JlZ2F0ZVJhdGluZ1Jlc29sdmVyKTtcbiAgICBpZiAobm9kZS5kYXRlUHVibGlzaGVkKVxuICAgICAgbm9kZS5kYXRlUHVibGlzaGVkID0gcmVzb2x2YWJsZURhdGVUb0lzbyhub2RlLmRhdGVQdWJsaXNoZWQpO1xuICAgIGlmIChub2RlLnN0YXJ0RGF0ZSlcbiAgICAgIG5vZGUuc3RhcnREYXRlID0gcmVzb2x2YWJsZURhdGVUb0lzbyhub2RlLnN0YXJ0RGF0ZSk7XG4gICAgaWYgKG5vZGUuZW5kRGF0ZSlcbiAgICAgIG5vZGUuZW5kRGF0ZSA9IHJlc29sdmFibGVEYXRlVG9Jc28obm9kZS5lbmREYXRlKTtcbiAgICByZXR1cm4gbm9kZTtcbiAgfVxufSk7XG5cbmNvbnN0IHBvZGNhc3RTZXJpZXNSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiUG9kY2FzdFNlcmllc1wiXG4gIH0sXG4gIHJlc29sdmUobm9kZSwgY3R4KSB7XG4gICAgbm9kZS5hdXRob3IgPSByZXNvbHZlUmVsYXRpb24obm9kZS5hdXRob3IsIGN0eCwgcGVyc29uUmVzb2x2ZXIpO1xuICAgIG5vZGUuYWdncmVnYXRlUmF0aW5nID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUuYWdncmVnYXRlUmF0aW5nLCBjdHgsIGFnZ3JlZ2F0ZVJhdGluZ1Jlc29sdmVyKTtcbiAgICBpZiAobm9kZS5kYXRlUHVibGlzaGVkKVxuICAgICAgbm9kZS5kYXRlUHVibGlzaGVkID0gcmVzb2x2YWJsZURhdGVUb0lzbyhub2RlLmRhdGVQdWJsaXNoZWQpO1xuICAgIGlmIChub2RlLnN0YXJ0RGF0ZSlcbiAgICAgIG5vZGUuc3RhcnREYXRlID0gcmVzb2x2YWJsZURhdGVUb0lzbyhub2RlLnN0YXJ0RGF0ZSk7XG4gICAgaWYgKG5vZGUuZW5kRGF0ZSlcbiAgICAgIG5vZGUuZW5kRGF0ZSA9IHJlc29sdmFibGVEYXRlVG9Jc28obm9kZS5lbmREYXRlKTtcbiAgICByZXR1cm4gbm9kZTtcbiAgfVxufSk7XG5cbmNvbnN0IFByb2R1Y3RJZCA9IFwiI3Byb2R1Y3RcIjtcbmNvbnN0IHByb2R1Y3RSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiUHJvZHVjdFwiXG4gIH0sXG4gIGluaGVyaXRNZXRhOiBbXG4gICAgXCJkZXNjcmlwdGlvblwiLFxuICAgIFwiaW1hZ2VcIixcbiAgICB7IG1ldGE6IFwidGl0bGVcIiwga2V5OiBcIm5hbWVcIiB9XG4gIF0sXG4gIGlkUHJlZml4OiBbXCJ1cmxcIiwgUHJvZHVjdElkXSxcbiAgcmVzb2x2ZShub2RlLCBjdHgpIHtcbiAgICBub2RlLmFnZ3JlZ2F0ZU9mZmVyID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUuYWdncmVnYXRlT2ZmZXIsIGN0eCwgYWdncmVnYXRlT2ZmZXJSZXNvbHZlcik7XG4gICAgbm9kZS5hZ2dyZWdhdGVSYXRpbmcgPSByZXNvbHZlUmVsYXRpb24obm9kZS5hZ2dyZWdhdGVSYXRpbmcsIGN0eCwgYWdncmVnYXRlUmF0aW5nUmVzb2x2ZXIpO1xuICAgIG5vZGUub2ZmZXJzID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUub2ZmZXJzLCBjdHgsIG9mZmVyUmVzb2x2ZXIpO1xuICAgIG5vZGUucmV2aWV3ID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUucmV2aWV3LCBjdHgsIHJldmlld1Jlc29sdmVyKTtcbiAgICByZXR1cm4gbm9kZTtcbiAgfSxcbiAgcmVzb2x2ZVJvb3ROb2RlKHByb2R1Y3QsIHsgZmluZCB9KSB7XG4gICAgY29uc3Qgd2ViUGFnZSA9IGZpbmQoUHJpbWFyeVdlYlBhZ2VJZCk7XG4gICAgY29uc3QgaWRlbnRpdHkgPSBmaW5kKElkZW50aXR5SWQpO1xuICAgIGlmIChpZGVudGl0eSlcbiAgICAgIHNldElmRW1wdHkocHJvZHVjdCwgXCJicmFuZFwiLCBpZFJlZmVyZW5jZShpZGVudGl0eSkpO1xuICAgIGlmICh3ZWJQYWdlKVxuICAgICAgc2V0SWZFbXB0eShwcm9kdWN0LCBcIm1haW5FbnRpdHlPZlBhZ2VcIiwgaWRSZWZlcmVuY2Uod2ViUGFnZSkpO1xuICAgIHJldHVybiBwcm9kdWN0O1xuICB9XG59KTtcblxuY29uc3QgYW5zd2VyUmVzb2x2ZXIgPSBkZWZpbmVTY2hlbWFPcmdSZXNvbHZlcih7XG4gIGNhc3Qobm9kZSkge1xuICAgIGlmICh0eXBlb2Ygbm9kZSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdGV4dDogbm9kZVxuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIG5vZGU7XG4gIH0sXG4gIGRlZmF1bHRzOiB7XG4gICAgXCJAdHlwZVwiOiBcIkFuc3dlclwiXG4gIH1cbn0pO1xuXG5jb25zdCBxdWVzdGlvblJlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJRdWVzdGlvblwiXG4gIH0sXG4gIGluaGVyaXRNZXRhOiBbXG4gICAgXCJpbkxhbmd1YWdlXCJcbiAgXSxcbiAgaWRQcmVmaXg6IFwidXJsXCIsXG4gIHJlc29sdmUocXVlc3Rpb24sIGN0eCkge1xuICAgIGlmIChxdWVzdGlvbi5xdWVzdGlvbikge1xuICAgICAgcXVlc3Rpb24ubmFtZSA9IHF1ZXN0aW9uLnF1ZXN0aW9uO1xuICAgICAgZGVsZXRlIHF1ZXN0aW9uLnF1ZXN0aW9uO1xuICAgIH1cbiAgICBpZiAocXVlc3Rpb24uYW5zd2VyKSB7XG4gICAgICBxdWVzdGlvbi5hY2NlcHRlZEFuc3dlciA9IHF1ZXN0aW9uLmFuc3dlcjtcbiAgICAgIGRlbGV0ZSBxdWVzdGlvbi5hbnN3ZXI7XG4gICAgfVxuICAgIHF1ZXN0aW9uLmFjY2VwdGVkQW5zd2VyID0gcmVzb2x2ZVJlbGF0aW9uKHF1ZXN0aW9uLmFjY2VwdGVkQW5zd2VyLCBjdHgsIGFuc3dlclJlc29sdmVyKTtcbiAgICBxdWVzdGlvbi5kYXRlQ3JlYXRlZCA9IHJlc29sdmFibGVEYXRlVG9Jc28ocXVlc3Rpb24uZGF0ZUNyZWF0ZWQpO1xuICAgIHJldHVybiBxdWVzdGlvbjtcbiAgfSxcbiAgcmVzb2x2ZVJvb3ROb2RlKHF1ZXN0aW9uLCB7IGZpbmQgfSkge1xuICAgIGNvbnN0IHdlYlBhZ2UgPSBmaW5kKFByaW1hcnlXZWJQYWdlSWQpO1xuICAgIGlmICh3ZWJQYWdlICYmIGFzQXJyYXkod2ViUGFnZVtcIkB0eXBlXCJdKS5pbmNsdWRlcyhcIkZBUVBhZ2VcIikpXG4gICAgICBkZWR1cGVNZXJnZSh3ZWJQYWdlLCBcIm1haW5FbnRpdHlcIiwgaWRSZWZlcmVuY2UocXVlc3Rpb24pKTtcbiAgfVxufSk7XG5cbmNvbnN0IFJlY2lwZUlkID0gXCIjcmVjaXBlXCI7XG5jb25zdCByZWNpcGVSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiUmVjaXBlXCJcbiAgfSxcbiAgaW5oZXJpdE1ldGE6IFtcbiAgICB7IG1ldGE6IFwidGl0bGVcIiwga2V5OiBcIm5hbWVcIiB9LFxuICAgIFwiZGVzY3JpcHRpb25cIixcbiAgICBcImltYWdlXCIsXG4gICAgXCJkYXRlUHVibGlzaGVkXCJcbiAgXSxcbiAgaWRQcmVmaXg6IFtcInVybFwiLCBSZWNpcGVJZF0sXG4gIHJlc29sdmUobm9kZSwgY3R4KSB7XG4gICAgbm9kZS5yZWNpcGVJbnN0cnVjdGlvbnMgPSByZXNvbHZlUmVsYXRpb24obm9kZS5yZWNpcGVJbnN0cnVjdGlvbnMsIGN0eCwgaG93VG9TdGVwUmVzb2x2ZXIpO1xuICAgIHJldHVybiBub2RlO1xuICB9LFxuICByZXNvbHZlUm9vdE5vZGUobm9kZSwgeyBmaW5kIH0pIHtcbiAgICBjb25zdCBhcnRpY2xlID0gZmluZChQcmltYXJ5QXJ0aWNsZUlkKTtcbiAgICBjb25zdCB3ZWJQYWdlID0gZmluZChQcmltYXJ5V2ViUGFnZUlkKTtcbiAgICBpZiAoYXJ0aWNsZSlcbiAgICAgIHNldElmRW1wdHkobm9kZSwgXCJtYWluRW50aXR5T2ZQYWdlXCIsIGlkUmVmZXJlbmNlKGFydGljbGUpKTtcbiAgICBlbHNlIGlmICh3ZWJQYWdlKVxuICAgICAgc2V0SWZFbXB0eShub2RlLCBcIm1haW5FbnRpdHlPZlBhZ2VcIiwgaWRSZWZlcmVuY2Uod2ViUGFnZSkpO1xuICAgIGlmIChhcnRpY2xlPy5hdXRob3IpXG4gICAgICBzZXRJZkVtcHR5KG5vZGUsIFwiYXV0aG9yXCIsIGFydGljbGUuYXV0aG9yKTtcbiAgICByZXR1cm4gbm9kZTtcbiAgfVxufSk7XG5cbmNvbnN0IFNlcnZpY2VJZCA9IFwiI3NlcnZpY2VcIjtcbmNvbnN0IHNlcnZpY2VSZXNvbHZlciA9IGRlZmluZVNjaGVtYU9yZ1Jlc29sdmVyKHtcbiAgZGVmYXVsdHM6IHtcbiAgICBcIkB0eXBlXCI6IFwiU2VydmljZVwiXG4gIH0sXG4gIGluaGVyaXRNZXRhOiBbXG4gICAgXCJkZXNjcmlwdGlvblwiLFxuICAgIFwiaW1hZ2VcIixcbiAgICB7IG1ldGE6IFwidGl0bGVcIiwga2V5OiBcIm5hbWVcIiB9XG4gIF0sXG4gIGlkUHJlZml4OiBbXCJ1cmxcIiwgU2VydmljZUlkXSxcbiAgcmVzb2x2ZShub2RlLCBjdHgpIHtcbiAgICByZXNvbHZlRGVmYXVsdFR5cGUobm9kZSwgXCJTZXJ2aWNlXCIpO1xuICAgIG5vZGUub2ZmZXJzID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUub2ZmZXJzLCBjdHgsIG9mZmVyUmVzb2x2ZXIpO1xuICAgIG5vZGUuYWdncmVnYXRlUmF0aW5nID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUuYWdncmVnYXRlUmF0aW5nLCBjdHgsIGFnZ3JlZ2F0ZVJhdGluZ1Jlc29sdmVyKTtcbiAgICBub2RlLnJldmlldyA9IHJlc29sdmVSZWxhdGlvbihub2RlLnJldmlldywgY3R4LCByZXZpZXdSZXNvbHZlcik7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH0sXG4gIHJlc29sdmVSb290Tm9kZShzZXJ2aWNlLCB7IGZpbmQgfSkge1xuICAgIGNvbnN0IHdlYlBhZ2UgPSBmaW5kKFByaW1hcnlXZWJQYWdlSWQpO1xuICAgIGNvbnN0IGlkZW50aXR5ID0gZmluZChJZGVudGl0eUlkKTtcbiAgICBpZiAoaWRlbnRpdHkpXG4gICAgICBzZXRJZkVtcHR5KHNlcnZpY2UsIFwicHJvdmlkZXJcIiwgaWRSZWZlcmVuY2UoaWRlbnRpdHkpKTtcbiAgICBpZiAoaWRlbnRpdHkpXG4gICAgICBzZXRJZkVtcHR5KHNlcnZpY2UsIFwiYnJhbmRcIiwgaWRSZWZlcmVuY2UoaWRlbnRpdHkpKTtcbiAgICBpZiAod2ViUGFnZSlcbiAgICAgIHNldElmRW1wdHkoc2VydmljZSwgXCJtYWluRW50aXR5T2ZQYWdlXCIsIGlkUmVmZXJlbmNlKHdlYlBhZ2UpKTtcbiAgICByZXR1cm4gc2VydmljZTtcbiAgfVxufSk7XG5cbmNvbnN0IHNvZnR3YXJlQXBwUmVzb2x2ZXIgPSBkZWZpbmVTY2hlbWFPcmdSZXNvbHZlcih7XG4gIGRlZmF1bHRzOiB7XG4gICAgXCJAdHlwZVwiOiBcIlNvZnR3YXJlQXBwbGljYXRpb25cIlxuICB9LFxuICByZXNvbHZlKG5vZGUsIGN0eCkge1xuICAgIHJlc29sdmVEZWZhdWx0VHlwZShub2RlLCBcIlNvZnR3YXJlQXBwbGljYXRpb25cIik7XG4gICAgbm9kZS5vZmZlcnMgPSByZXNvbHZlUmVsYXRpb24obm9kZS5vZmZlcnMsIGN0eCwgb2ZmZXJSZXNvbHZlcik7XG4gICAgbm9kZS5hZ2dyZWdhdGVSYXRpbmcgPSByZXNvbHZlUmVsYXRpb24obm9kZS5hZ2dyZWdhdGVSYXRpbmcsIGN0eCwgYWdncmVnYXRlUmF0aW5nUmVzb2x2ZXIpO1xuICAgIG5vZGUucmV2aWV3ID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUucmV2aWV3LCBjdHgsIHJldmlld1Jlc29sdmVyKTtcbiAgICByZXR1cm4gbm9kZTtcbiAgfVxufSk7XG5cbmNvbnN0IHR2RXBpc29kZVJlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJUVkVwaXNvZGVcIlxuICB9LFxuICByZXNvbHZlKG5vZGUsIGN0eCkge1xuICAgIG5vZGUuYWN0b3IgPSByZXNvbHZlUmVsYXRpb24obm9kZS5hY3RvciwgY3R4LCBwZXJzb25SZXNvbHZlcik7XG4gICAgbm9kZS5kaXJlY3RvciA9IHJlc29sdmVSZWxhdGlvbihub2RlLmRpcmVjdG9yLCBjdHgsIHBlcnNvblJlc29sdmVyKTtcbiAgICBub2RlLm11c2ljQnkgPSByZXNvbHZlUmVsYXRpb24obm9kZS5tdXNpY0J5LCBjdHgsIHBlcnNvblJlc29sdmVyKTtcbiAgICBub2RlLnZpZGVvID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUudmlkZW8sIGN0eCwgdmlkZW9SZXNvbHZlcik7XG4gICAgbm9kZS5hZ2dyZWdhdGVSYXRpbmcgPSByZXNvbHZlUmVsYXRpb24obm9kZS5hZ2dyZWdhdGVSYXRpbmcsIGN0eCwgYWdncmVnYXRlUmF0aW5nUmVzb2x2ZXIpO1xuICAgIG5vZGUucmV2aWV3ID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUucmV2aWV3LCBjdHgsIHJldmlld1Jlc29sdmVyKTtcbiAgICBpZiAobm9kZS5kYXRlUHVibGlzaGVkKVxuICAgICAgbm9kZS5kYXRlUHVibGlzaGVkID0gcmVzb2x2YWJsZURhdGVUb0lzbyhub2RlLmRhdGVQdWJsaXNoZWQpO1xuICAgIGlmIChub2RlLnVwbG9hZERhdGUpXG4gICAgICBub2RlLnVwbG9hZERhdGUgPSByZXNvbHZhYmxlRGF0ZVRvSXNvKG5vZGUudXBsb2FkRGF0ZSk7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn0pO1xuXG5jb25zdCB0dlNlYXNvblJlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJUVlNlYXNvblwiXG4gIH0sXG4gIHJlc29sdmUobm9kZSwgY3R4KSB7XG4gICAgbm9kZS5hY3RvciA9IHJlc29sdmVSZWxhdGlvbihub2RlLmFjdG9yLCBjdHgsIHBlcnNvblJlc29sdmVyKTtcbiAgICBub2RlLmRpcmVjdG9yID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUuZGlyZWN0b3IsIGN0eCwgcGVyc29uUmVzb2x2ZXIpO1xuICAgIG5vZGUucHJvZHVjdGlvbkNvbXBhbnkgPSByZXNvbHZlUmVsYXRpb24obm9kZS5wcm9kdWN0aW9uQ29tcGFueSwgY3R4LCBvcmdhbml6YXRpb25SZXNvbHZlcik7XG4gICAgbm9kZS5hZ2dyZWdhdGVSYXRpbmcgPSByZXNvbHZlUmVsYXRpb24obm9kZS5hZ2dyZWdhdGVSYXRpbmcsIGN0eCwgYWdncmVnYXRlUmF0aW5nUmVzb2x2ZXIpO1xuICAgIG5vZGUudHJhaWxlciA9IHJlc29sdmVSZWxhdGlvbihub2RlLnRyYWlsZXIsIGN0eCwgdmlkZW9SZXNvbHZlcik7XG4gICAgaWYgKG5vZGUuZGF0ZVB1Ymxpc2hlZClcbiAgICAgIG5vZGUuZGF0ZVB1Ymxpc2hlZCA9IHJlc29sdmFibGVEYXRlVG9Jc28obm9kZS5kYXRlUHVibGlzaGVkKTtcbiAgICBpZiAobm9kZS5zdGFydERhdGUpXG4gICAgICBub2RlLnN0YXJ0RGF0ZSA9IHJlc29sdmFibGVEYXRlVG9Jc28obm9kZS5zdGFydERhdGUpO1xuICAgIGlmIChub2RlLmVuZERhdGUpXG4gICAgICBub2RlLmVuZERhdGUgPSByZXNvbHZhYmxlRGF0ZVRvSXNvKG5vZGUuZW5kRGF0ZSk7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn0pO1xuXG5jb25zdCB0dlNlcmllc1Jlc29sdmVyID0gZGVmaW5lU2NoZW1hT3JnUmVzb2x2ZXIoe1xuICBkZWZhdWx0czoge1xuICAgIFwiQHR5cGVcIjogXCJUVlNlcmllc1wiXG4gIH0sXG4gIHJlc29sdmUobm9kZSwgY3R4KSB7XG4gICAgbm9kZS5hY3RvciA9IHJlc29sdmVSZWxhdGlvbihub2RlLmFjdG9yLCBjdHgsIHBlcnNvblJlc29sdmVyKTtcbiAgICBub2RlLmRpcmVjdG9yID0gcmVzb2x2ZVJlbGF0aW9uKG5vZGUuZGlyZWN0b3IsIGN0eCwgcGVyc29uUmVzb2x2ZXIpO1xuICAgIG5vZGUuY3JlYXRvciA9IHJlc29sdmVSZWxhdGlvbihub2RlLmNyZWF0b3IsIGN0eCwgcGVyc29uUmVzb2x2ZXIpO1xuICAgIG5vZGUucHJvZHVjdGlvbkNvbXBhbnkgPSByZXNvbHZlUmVsYXRpb24obm9kZS5wcm9kdWN0aW9uQ29tcGFueSwgY3R4LCBvcmdhbml6YXRpb25SZXNvbHZlcik7XG4gICAgbm9kZS5hZ2dyZWdhdGVSYXRpbmcgPSByZXNvbHZlUmVsYXRpb24obm9kZS5hZ2dyZWdhdGVSYXRpbmcsIGN0eCwgYWdncmVnYXRlUmF0aW5nUmVzb2x2ZXIpO1xuICAgIG5vZGUudHJhaWxlciA9IHJlc29sdmVSZWxhdGlvbihub2RlLnRyYWlsZXIsIGN0eCwgdmlkZW9SZXNvbHZlcik7XG4gICAgaWYgKG5vZGUuZGF0ZVB1Ymxpc2hlZClcbiAgICAgIG5vZGUuZGF0ZVB1Ymxpc2hlZCA9IHJlc29sdmFibGVEYXRlVG9Jc28obm9kZS5kYXRlUHVibGlzaGVkKTtcbiAgICBpZiAobm9kZS5zdGFydERhdGUpXG4gICAgICBub2RlLnN0YXJ0RGF0ZSA9IHJlc29sdmFibGVEYXRlVG9Jc28obm9kZS5zdGFydERhdGUpO1xuICAgIGlmIChub2RlLmVuZERhdGUpXG4gICAgICBub2RlLmVuZERhdGUgPSByZXNvbHZhYmxlRGF0ZVRvSXNvKG5vZGUuZW5kRGF0ZSk7XG4gICAgcmV0dXJuIG5vZGU7XG4gIH1cbn0pO1xuXG5mdW5jdGlvbiBtZXJnZU9iamVjdHModGFyZ2V0LCBzb3VyY2UpIHtcbiAgY29uc3QgcmVzdWx0ID0geyAuLi50YXJnZXQgfTtcbiAgZm9yIChjb25zdCBrZXkgaW4gc291cmNlKSB7XG4gICAgaWYgKCFPYmplY3QuaGFzT3duKHNvdXJjZSwga2V5KSB8fCBzb3VyY2Vba2V5XSA9PT0gdm9pZCAwIHx8IGtleSA9PT0gXCJfX3Byb3RvX19cIiB8fCBrZXkgPT09IFwiY29uc3RydWN0b3JcIiB8fCBrZXkgPT09IFwicHJvdG90eXBlXCIpXG4gICAgICBjb250aW51ZTtcbiAgICBjb25zdCBpc05lc3RlZE9iamVjdCA9IHJlc3VsdFtrZXldICYmIHR5cGVvZiByZXN1bHRba2V5XSA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2Ygc291cmNlW2tleV0gPT09IFwib2JqZWN0XCIgJiYgIUFycmF5LmlzQXJyYXkocmVzdWx0W2tleV0pICYmICFBcnJheS5pc0FycmF5KHNvdXJjZVtrZXldKTtcbiAgICBpZiAoaXNOZXN0ZWRPYmplY3QpXG4gICAgICByZXN1bHRba2V5XSA9IG1lcmdlT2JqZWN0cyhyZXN1bHRba2V5XSwgc291cmNlW2tleV0pO1xuICAgIGVsc2UgaWYgKCFyZXN1bHRba2V5XSlcbiAgICAgIHJlc3VsdFtrZXldID0gc291cmNlW2tleV07XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIGlzU2NoZW1hT3JnVGFnKHRhZykge1xuICByZXR1cm4gdGFnLnRhZyA9PT0gXCJzY3JpcHRcIiAmJiB0YWcucHJvcHMudHlwZSA9PT0gXCJhcHBsaWNhdGlvbi9sZCtqc29uXCIgJiYgdGFnLnByb3BzLm5vZGVzIHx8IHRhZy5rZXkgPT09IFwic2NoZW1hLW9yZy1ncmFwaFwiO1xufVxuZnVuY3Rpb24gVW5oZWFkU2NoZW1hT3JnKGNvbmZpZyA9IHt9LCBtZXRhID0gKCkgPT4gKHt9KSwgb3B0aW9ucykge1xuICBjb25maWcgPSByZXNvbHZlTWV0YSh7IC4uLmNvbmZpZyB9KTtcbiAgbGV0IGdyYXBoO1xuICBsZXQgcmVzb2x2ZWRNZXRhID0ge307XG4gIHJldHVybiBkZWZpbmVIZWFkUGx1Z2luKChoZWFkKSA9PiB7XG4gICAgaGVhZC51c2UoVGVtcGxhdGVQYXJhbXNQbHVnaW4pO1xuICAgIGZ1bmN0aW9uIGNvbGxlY3RUYWcodGFnKSB7XG4gICAgICBpZiAodGFnLnRhZyA9PT0gXCJzY3JpcHRcIiAmJiB0YWcucHJvcHMudHlwZSA9PT0gXCJhcHBsaWNhdGlvbi9sZCtqc29uXCIgJiYgdGFnLnByb3BzLm5vZGVzKSB7XG4gICAgICAgIGNvbnN0IG5vZGVzID0gdGFnLnByb3BzLm5vZGVzO1xuICAgICAgICBmb3IgKGNvbnN0IG5vZGUgb2YgQXJyYXkuaXNBcnJheShub2RlcykgPyBub2RlcyA6IFtub2Rlc10pIHtcbiAgICAgICAgICBpZiAodHlwZW9mIG5vZGUgIT09IFwib2JqZWN0XCIgfHwgbm9kZSA9PT0gbnVsbCkge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IG5ld05vZGUgPSB7XG4gICAgICAgICAgICAuLi5ub2RlLFxuICAgICAgICAgICAgX2RlZHVwZVN0cmF0ZWd5OiB0YWcudGFnRHVwbGljYXRlU3RyYXRlZ3lcbiAgICAgICAgICB9O1xuICAgICAgICAgIGdyYXBoLnB1c2gobmV3Tm9kZSk7XG4gICAgICAgIH1cbiAgICAgICAgdGFnLnRhZ1Bvc2l0aW9uID0gdGFnLnRhZ1Bvc2l0aW9uIHx8IChjb25maWcudGFnUG9zaXRpb24gPT09IFwiaGVhZFwiID8gXCJoZWFkXCIgOiBcImJvZHlDbG9zZVwiKTtcbiAgICAgIH1cbiAgICAgIGlmICh0YWcudGFnID09PSBcImh0bWxBdHRyc1wiICYmIHR5cGVvZiB0YWcucHJvcHMubGFuZyA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICByZXNvbHZlZE1ldGEuaW5MYW5ndWFnZSA9IHRhZy5wcm9wcy5sYW5nO1xuICAgICAgfSBlbHNlIGlmICh0YWcudGFnID09PSBcInRpdGxlXCIgJiYgdGFnLnRleHRDb250ZW50ICE9IG51bGwgJiYgdHlwZW9mIHRhZy50ZXh0Q29udGVudCAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgIHJlc29sdmVkTWV0YS50aXRsZSA9IFN0cmluZyh0YWcudGV4dENvbnRlbnQpO1xuICAgICAgfSBlbHNlIGlmICh0YWcudGFnID09PSBcIm1ldGFcIiAmJiB0YWcucHJvcHMubmFtZSA9PT0gXCJkZXNjcmlwdGlvblwiICYmIHR5cGVvZiB0YWcucHJvcHMuY29udGVudCA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICByZXNvbHZlZE1ldGEuZGVzY3JpcHRpb24gPSB0YWcucHJvcHMuY29udGVudDtcbiAgICAgIH0gZWxzZSBpZiAodGFnLnRhZyA9PT0gXCJsaW5rXCIgJiYgdGFnLnByb3BzLnJlbCA9PT0gXCJjYW5vbmljYWxcIiAmJiB0eXBlb2YgdGFnLnByb3BzLmhyZWYgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgcmVzb2x2ZWRNZXRhLnVybCA9IHRhZy5wcm9wcy5ocmVmO1xuICAgICAgICBpZiAocmVzb2x2ZWRNZXRhLnVybCAmJiAhcmVzb2x2ZWRNZXRhLmhvc3QpIHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgcmVzb2x2ZWRNZXRhLmhvc3QgPSBuZXcgVVJMKHJlc29sdmVkTWV0YS51cmwpLm9yaWdpbjtcbiAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAodGFnLnRhZyA9PT0gXCJtZXRhXCIgJiYgdGFnLnByb3BzLnByb3BlcnR5ID09PSBcIm9nOmltYWdlXCIgJiYgdHlwZW9mIHRhZy5wcm9wcy5jb250ZW50ID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHJlc29sdmVkTWV0YS5pbWFnZSA9IHRhZy5wcm9wcy5jb250ZW50O1xuICAgICAgfSBlbHNlIGlmICh0YWcudGFnID09PSBcInRlbXBsYXRlUGFyYW1zXCIgJiYgdGFnLnByb3BzLnNjaGVtYU9yZykge1xuICAgICAgICByZXNvbHZlZE1ldGEgPSB7XG4gICAgICAgICAgLi4ucmVzb2x2ZWRNZXRhLFxuICAgICAgICAgIC4uLnRhZy5wcm9wcy5zY2hlbWFPcmdcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIGtleTogXCJzY2hlbWEtb3JnXCIsXG4gICAgICBob29rczoge1xuICAgICAgICBcImVudHJpZXM6cmVzb2x2ZVwiOiAoY3R4KSA9PiB7XG4gICAgICAgICAgZ3JhcGggPSBncmFwaCB8fCBjcmVhdGVTY2hlbWFPcmdHcmFwaCgpO1xuICAgICAgICAgIGdyYXBoLm5vZGVzID0gW107XG4gICAgICAgICAgZ3JhcGgubm9kZUluZGV4LmNsZWFyKCk7XG4gICAgICAgICAgcmVzb2x2ZWRNZXRhID0ge307XG4gICAgICAgICAgZm9yIChjb25zdCBlbnRyeSBvZiBjdHguZW50cmllcykge1xuICAgICAgICAgICAgaWYgKGVudHJ5Ll90YWdzKSB7XG4gICAgICAgICAgICAgIGlmIChlbnRyeS5fdGFncy5zb21lKGlzU2NoZW1hT3JnVGFnKSkge1xuICAgICAgICAgICAgICAgIGRlbGV0ZSBlbnRyeS5fdGFncztcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBmb3IgKGNvbnN0IHRhZyBvZiBlbnRyeS5fdGFncylcbiAgICAgICAgICAgICAgICBjb2xsZWN0VGFnKHRhZyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImVudHJpZXM6bm9ybWFsaXplXCI6ICh7IHRhZ3MgfSkgPT4ge1xuICAgICAgICAgIGZvciAoY29uc3QgdGFnIG9mIHRhZ3MpXG4gICAgICAgICAgICBjb2xsZWN0VGFnKHRhZyk7XG4gICAgICAgIH0sXG4gICAgICAgIFwidGFnczpyZXNvbHZlXCI6IChjdHgpID0+IHtcbiAgICAgICAgICBmb3IgKGNvbnN0IGsgaW4gY3R4LnRhZ3MpIHtcbiAgICAgICAgICAgIGNvbnN0IHRhZyA9IGN0eC50YWdzW2tdO1xuICAgICAgICAgICAgaWYgKHRhZy50YWcgPT09IFwic2NyaXB0XCIgJiYgdGFnLnByb3BzLnR5cGUgPT09IFwiYXBwbGljYXRpb24vbGQranNvblwiICYmIHRhZy5wcm9wcy5ub2Rlcykge1xuICAgICAgICAgICAgICBkZWxldGUgdGFnLnByb3BzLm5vZGVzO1xuICAgICAgICAgICAgICBjb25zdCByZXNvbHZlZEdyYXBoID0gZ3JhcGgucmVzb2x2ZUdyYXBoKHsgLi4ubWV0YT8uKCkgfHwge30sIC4uLmNvbmZpZywgLi4ucmVzb2x2ZWRNZXRhIH0pO1xuICAgICAgICAgICAgICBpZiAoIXJlc29sdmVkR3JhcGgubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgdGFnLnByb3BzID0ge307XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGNvbnN0IG1pbmlmeSA9IG9wdGlvbnM/Lm1pbmlmeSB8fCBwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCI7XG4gICAgICAgICAgICAgIHRhZy5pbm5lckhUTUwgPSBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICAgICAgXCJAY29udGV4dFwiOiBcImh0dHBzOi8vc2NoZW1hLm9yZ1wiLFxuICAgICAgICAgICAgICAgIFwiQGdyYXBoXCI6IHJlc29sdmVkR3JhcGhcbiAgICAgICAgICAgICAgfSwgKF8sIHZhbHVlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIilcbiAgICAgICAgICAgICAgICAgIHJldHVybiBwcm9jZXNzVGVtcGxhdGVQYXJhbXModmFsdWUsIGhlYWQuX3RlbXBsYXRlUGFyYW1zLCBoZWFkLl9zZXBhcmF0b3IpO1xuICAgICAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgICAgICAgfSwgbWluaWZ5ID8gMCA6IDIpO1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcInRhZ3M6YWZ0ZXJSZXNvbHZlXCI6IChjdHgpID0+IHtcbiAgICAgICAgICBsZXQgZmlyc3ROb2RlSWR4O1xuICAgICAgICAgIGxldCB0b1JlbW92ZTtcbiAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGN0eC50YWdzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCB0YWcgPSBjdHgudGFnc1tpXTtcbiAgICAgICAgICAgIGlmICghdGFnPy5wcm9wcylcbiAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICBpZiAoaXNTY2hlbWFPcmdUYWcodGFnKSkge1xuICAgICAgICAgICAgICBkZWxldGUgdGFnLnByb3BzLm5vZGVzO1xuICAgICAgICAgICAgICBpZiAodHlwZW9mIGZpcnN0Tm9kZUlkeCA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgICAgIGZpcnN0Tm9kZUlkeCA9IGk7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgY3R4LnRhZ3NbZmlyc3ROb2RlSWR4XS5wcm9wcyA9IG1lcmdlT2JqZWN0cyhjdHgudGFnc1tmaXJzdE5vZGVJZHhdLnByb3BzLCB0YWcucHJvcHMpO1xuICAgICAgICAgICAgICBkZWxldGUgY3R4LnRhZ3NbZmlyc3ROb2RlSWR4XS5wcm9wcy5ub2RlcztcbiAgICAgICAgICAgICAgKHRvUmVtb3ZlIHx8PSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpKS5hZGQoaSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICh0b1JlbW92ZSlcbiAgICAgICAgICAgIGN0eC50YWdzID0gY3R4LnRhZ3MuZmlsdGVyKChfLCBpKSA9PiAhdG9SZW1vdmUuaGFzKGkpKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gIH0sIFwic2NoZW1hLW9yZ1wiKTtcbn1cblxuZnVuY3Rpb24gcHJvdmlkZVJlc29sdmVyKGlucHV0LCByZXNvbHZlcikge1xuICByZXR1cm4geyAuLi5pbnB1dCB8fCB7fSwgX3Jlc29sdmVyOiByZXNvbHZlciB9O1xufVxuZnVuY3Rpb24gZGVmaW5lQWRkcmVzcyhpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBhZGRyZXNzUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lQWdncmVnYXRlT2ZmZXIoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgYWdncmVnYXRlT2ZmZXJSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVBZ2dyZWdhdGVSYXRpbmcoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgYWdncmVnYXRlUmF0aW5nUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lQXJ0aWNsZShpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBhcnRpY2xlUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lQnJlYWRjcnVtYihpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBicmVhZGNydW1iUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lQ29tbWVudChpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBjb21tZW50UmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lRXZlbnQoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgZXZlbnRSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVGb29kRXN0YWJsaXNobWVudChpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBmb29kRXN0YWJsaXNobWVudFJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZVZpcnR1YWxMb2NhdGlvbihpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCB2aXJ0dWFsTG9jYXRpb25SZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVQbGFjZShpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBwbGFjZVJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZUhvd1RvKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIGhvd1RvUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lSG93VG9TdGVwKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIGhvd1RvU3RlcFJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZUltYWdlKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIGltYWdlUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lSm9iUG9zdGluZyhpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBqb2JQb3N0aW5nUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lTG9jYWxCdXNpbmVzcyhpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBsb2NhbEJ1c2luZXNzUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lT2ZmZXIoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgb2ZmZXJSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVPcGVuaW5nSG91cnMoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgb3BlbmluZ0hvdXJzUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lT3JnYW5pemF0aW9uKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIG9yZ2FuaXphdGlvblJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZVBlcnNvbihpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBwZXJzb25SZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVQcm9kdWN0KGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIHByb2R1Y3RSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVRdWVzdGlvbihpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBxdWVzdGlvblJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZVJlY2lwZShpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCByZWNpcGVSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVSZXZpZXcoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgcmV2aWV3UmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lVmlkZW8oaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgdmlkZW9SZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVXZWJQYWdlKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIHdlYlBhZ2VSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVXZWJTaXRlKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIHdlYlNpdGVSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVCb29rKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIGJvb2tSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVDb3Vyc2UoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgY291cnNlUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lSXRlbUxpc3QoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgaXRlbUxpc3RSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVMaXN0SXRlbShpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBsaXN0SXRlbVJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZU1vdmllKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIG1vdmllUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lU2VhcmNoQWN0aW9uKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIHNlYXJjaEFjdGlvblJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZVJlYWRBY3Rpb24oaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgcmVhZEFjdGlvblJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZURhdGFzZXQoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgZGF0YXNldFJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZU11c2ljUmVjb3JkaW5nKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIG11c2ljUmVjb3JkaW5nUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lTXVzaWNBbGJ1bShpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBtdXNpY0FsYnVtUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lTXVzaWNHcm91cChpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBtdXNpY0dyb3VwUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lTXVzaWNQbGF5bGlzdChpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBtdXNpY1BsYXlsaXN0UmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lUG9kY2FzdFNlcmllcyhpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBwb2RjYXN0U2VyaWVzUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lUG9kY2FzdEVwaXNvZGUoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgcG9kY2FzdEVwaXNvZGVSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVQb2RjYXN0U2Vhc29uKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIHBvZGNhc3RTZWFzb25SZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVUVlNlcmllcyhpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCB0dlNlcmllc1Jlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZVRWU2Vhc29uKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIHR2U2Vhc29uUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lVFZFcGlzb2RlKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIHR2RXBpc29kZVJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZVNlcnZpY2UoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgc2VydmljZVJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZVNvZnR3YXJlQXBwKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIHNvZnR3YXJlQXBwUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lQm9va0VkaXRpb24oaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgYm9va0VkaXRpb25SZXNvbHZlcik7XG59XG5mdW5jdGlvbiBub3JtYWxpemVTY2hlbWFPcmdJbnB1dChpbnB1dCkge1xuICBjb25zdCBzY3JpcHQgPSBpbnB1dD8uc2NyaXB0O1xuICBjb25zdCBncmFwaCA9IHNjcmlwdD8uWzBdO1xuICBpZiAoQXJyYXkuaXNBcnJheShzY3JpcHQpICYmIHNjcmlwdC5sZW5ndGggPT09IDEgJiYgZ3JhcGggJiYgdHlwZW9mIGdyYXBoID09PSBcIm9iamVjdFwiICYmIGdyYXBoLnR5cGUgPT09IFwiYXBwbGljYXRpb24vbGQranNvblwiICYmIGdyYXBoLmtleSA9PT0gXCJzY2hlbWEtb3JnLWdyYXBoXCIgJiYgXCJub2Rlc1wiIGluIGdyYXBoKSB7XG4gICAgcmV0dXJuIGlucHV0O1xuICB9XG4gIHJldHVybiB7XG4gICAgc2NyaXB0OiBbXG4gICAgICB7XG4gICAgICAgIHR5cGU6IFwiYXBwbGljYXRpb24vbGQranNvblwiLFxuICAgICAgICBrZXk6IFwic2NoZW1hLW9yZy1ncmFwaFwiLFxuICAgICAgICBub2RlczogaW5wdXRcbiAgICAgIH1cbiAgICBdXG4gIH07XG59XG5mdW5jdGlvbiB1c2VTY2hlbWFPcmcodW5oZWFkLCBpbnB1dCA9IFtdLCBvcHRpb25zID0ge30pIHtcbiAgdW5oZWFkLnVzZShVbmhlYWRTY2hlbWFPcmcoKSk7XG4gIGNvbnN0IGVudHJ5ID0gdW5oZWFkLnB1c2goXG4gICAgbm9ybWFsaXplU2NoZW1hT3JnSW5wdXQoaW5wdXQpLFxuICAgIG9wdGlvbnNcbiAgKTtcbiAgY29uc3QgY29yZVBhdGNoID0gZW50cnkucGF0Y2g7XG4gIGNvbnN0IHB1YmxpY0VudHJ5ID0gZW50cnk7XG4gIHB1YmxpY0VudHJ5LnBhdGNoID0gKGlucHV0MikgPT4gY29yZVBhdGNoKG5vcm1hbGl6ZVNjaGVtYU9yZ0lucHV0KGlucHV0MikpO1xuICByZXR1cm4gcHVibGljRW50cnk7XG59XG5cbmV4cG9ydCB7IGRlZmluZVBvZGNhc3RTZWFzb24gYXMgJCwgZGVmaW5lQ291cnNlIGFzIEEsIGRlZmluZURhdGFzZXQgYXMgQiwgZGVmaW5lRXZlbnQgYXMgQywgZGVmaW5lRm9vZEVzdGFibGlzaG1lbnQgYXMgRCwgZGVmaW5lSG93VG8gYXMgRSwgZGVmaW5lSG93VG9TdGVwIGFzIEYsIGRlZmluZUltYWdlIGFzIEcsIEhvd1RvSWQgYXMgSCwgZGVmaW5lSXRlbUxpc3QgYXMgSSwgZGVmaW5lSm9iUG9zdGluZyBhcyBKLCBkZWZpbmVMaXN0SXRlbSBhcyBLLCBkZWZpbmVMb2NhbEJ1c2luZXNzIGFzIEwsIGRlZmluZU1vdmllIGFzIE0sIGRlZmluZU11c2ljQWxidW0gYXMgTiwgZGVmaW5lTXVzaWNHcm91cCBhcyBPLCBQcmltYXJ5QXJ0aWNsZUlkIGFzIFAsIGRlZmluZU11c2ljUGxheWxpc3QgYXMgUSwgUmVjaXBlSWQgYXMgUiwgU2VydmljZUlkIGFzIFMsIGRlZmluZU11c2ljUmVjb3JkaW5nIGFzIFQsIFVuaGVhZFNjaGVtYU9yZyBhcyBVLCBkZWZpbmVPZmZlciBhcyBWLCBkZWZpbmVPcGVuaW5nSG91cnMgYXMgVywgZGVmaW5lT3JnYW5pemF0aW9uIGFzIFgsIGRlZmluZVBlcnNvbiBhcyBZLCBkZWZpbmVQbGFjZSBhcyBaLCBkZWZpbmVQb2RjYXN0RXBpc29kZSBhcyBfLCBQcmltYXJ5Qm9va0lkIGFzIGEsIHdlYlNpdGVSZXNvbHZlciBhcyBhJCwgZGVmaW5lUG9kY2FzdFNlcmllcyBhcyBhMCwgZGVmaW5lUHJvZHVjdCBhcyBhMSwgZGVmaW5lUXVlc3Rpb24gYXMgYTIsIGRlZmluZVJlYWRBY3Rpb24gYXMgYTMsIGRlZmluZVJlY2lwZSBhcyBhNCwgZGVmaW5lUmV2aWV3IGFzIGE1LCBkZWZpbmVTY2hlbWFPcmdSZXNvbHZlciBhcyBhNiwgZGVmaW5lU2VhcmNoQWN0aW9uIGFzIGE3LCBkZWZpbmVTZXJ2aWNlIGFzIGE4LCBkZWZpbmVTb2Z0d2FyZUFwcCBhcyBhOSwgb3BlbmluZ0hvdXJzUmVzb2x2ZXIgYXMgYUEsIG9yZ2FuaXphdGlvblJlc29sdmVyIGFzIGFCLCBwZXJzb25SZXNvbHZlciBhcyBhQywgcGxhY2VSZXNvbHZlciBhcyBhRCwgcG9kY2FzdEVwaXNvZGVSZXNvbHZlciBhcyBhRSwgcG9kY2FzdFNlYXNvblJlc29sdmVyIGFzIGFGLCBwb2RjYXN0U2VyaWVzUmVzb2x2ZXIgYXMgYUcsIHByb2R1Y3RSZXNvbHZlciBhcyBhSCwgcXVlc3Rpb25SZXNvbHZlciBhcyBhSSwgcmF0aW5nUmVzb2x2ZXIgYXMgYUosIHJlYWRBY3Rpb25SZXNvbHZlciBhcyBhSywgcmVjaXBlUmVzb2x2ZXIgYXMgYUwsIHJlc29sdmVNZXRhIGFzIGFNLCByZXNvbHZlTm9kZSBhcyBhTiwgcmVzb2x2ZU5vZGVJZCBhcyBhTywgcmVzb2x2ZVJlbGF0aW9uIGFzIGFQLCByZXZpZXdSZXNvbHZlciBhcyBhUSwgc2VhcmNoQWN0aW9uUmVzb2x2ZXIgYXMgYVIsIHNlcnZpY2VSZXNvbHZlciBhcyBhUywgc29mdHdhcmVBcHBSZXNvbHZlciBhcyBhVCwgdHZFcGlzb2RlUmVzb2x2ZXIgYXMgYVUsIHR2U2Vhc29uUmVzb2x2ZXIgYXMgYVYsIHR2U2VyaWVzUmVzb2x2ZXIgYXMgYVcsIHVzZVNjaGVtYU9yZyBhcyBhWCwgdmlkZW9SZXNvbHZlciBhcyBhWSwgdmlydHVhbExvY2F0aW9uUmVzb2x2ZXIgYXMgYVosIHdlYlBhZ2VSZXNvbHZlciBhcyBhXywgZGVmaW5lVFZFcGlzb2RlIGFzIGFhLCBkZWZpbmVUVlNlYXNvbiBhcyBhYiwgZGVmaW5lVFZTZXJpZXMgYXMgYWMsIGRlZmluZVZpZGVvIGFzIGFkLCBkZWZpbmVWaXJ0dWFsTG9jYXRpb24gYXMgYWUsIGRlZmluZVdlYlBhZ2UgYXMgYWYsIGRlZmluZVdlYlNpdGUgYXMgYWcsIGV2ZW50UmVzb2x2ZXIgYXMgYWgsIGZvb2RFc3RhYmxpc2htZW50UmVzb2x2ZXIgYXMgYWksIGhvd1RvUmVzb2x2ZXIgYXMgYWosIGhvd1RvU3RlcERpcmVjdGlvblJlc29sdmVyIGFzIGFrLCBob3dUb1N0ZXBSZXNvbHZlciBhcyBhbCwgaW1hZ2VSZXNvbHZlciBhcyBhbSwgaXNJbWFnZU9iamVjdCBhcyBhbiwgaXRlbUxpc3RSZXNvbHZlciBhcyBhbywgam9iUG9zdGluZ1Jlc29sdmVyIGFzIGFwLCBsaXN0SXRlbVJlc29sdmVyIGFzIGFxLCBsb2NhbEJ1c2luZXNzUmVzb2x2ZXIgYXMgYXIsIG1lcmdlIGFzIGFzLCBtb3ZpZVJlc29sdmVyIGFzIGF0LCBtdXNpY0FsYnVtUmVzb2x2ZXIgYXMgYXUsIG11c2ljR3JvdXBSZXNvbHZlciBhcyBhdiwgbXVzaWNQbGF5bGlzdFJlc29sdmVyIGFzIGF3LCBtdXNpY1JlY29yZGluZ1Jlc29sdmVyIGFzIGF4LCBub3JtYWxpemVTY2hlbWFPcmdJbnB1dCBhcyBheSwgb2ZmZXJSZXNvbHZlciBhcyBheiwgUHJpbWFyeUJyZWFkY3J1bWJJZCBhcyBiLCBQcmltYXJ5RGF0YXNldElkIGFzIGMsIFByaW1hcnlFdmVudElkIGFzIGQsIFByaW1hcnlXZWJQYWdlSWQgYXMgZSwgUHJpbWFyeVdlYlNpdGVJZCBhcyBmLCBQcm9kdWN0SWQgYXMgZywgYWRkcmVzc1Jlc29sdmVyIGFzIGgsIGFnZ3JlZ2F0ZU9mZmVyUmVzb2x2ZXIgYXMgaSwgYWdncmVnYXRlUmF0aW5nUmVzb2x2ZXIgYXMgaiwgYXJ0aWNsZVJlc29sdmVyIGFzIGssIGJvb2tFZGl0aW9uUmVzb2x2ZXIgYXMgbCwgYm9va1Jlc29sdmVyIGFzIG0sIGJyZWFkY3J1bWJSZXNvbHZlciBhcyBuLCBjb21tZW50UmVzb2x2ZXIgYXMgbywgY291cnNlUmVzb2x2ZXIgYXMgcCwgY3JlYXRlU2NoZW1hT3JnR3JhcGggYXMgcSwgZGF0YXNldFJlc29sdmVyIGFzIHIsIGRlZmluZUFkZHJlc3MgYXMgcywgZGVmaW5lQWdncmVnYXRlT2ZmZXIgYXMgdCwgZGVmaW5lQWdncmVnYXRlUmF0aW5nIGFzIHUsIGRlZmluZUFydGljbGUgYXMgdiwgZGVmaW5lQm9vayBhcyB3LCBkZWZpbmVCb29rRWRpdGlvbiBhcyB4LCBkZWZpbmVCcmVhZGNydW1iIGFzIHksIGRlZmluZUNvbW1lbnQgYXMgeiB9O1xuIiwiaW1wb3J0IHsgc2NoZW1hQXV0b0ltcG9ydHMgfSBmcm9tICcuLi9pbXBvcnRzLm1qcyc7XG5cbmNvbnN0IHNjaGVtYU9yZ0F1dG9JbXBvcnRzID0gW1xuICB7XG4gICAgZnJvbTogXCJAdW5oZWFkL3NjaGVtYS1vcmcvdnVlXCIsXG4gICAgaW1wb3J0czogc2NoZW1hQXV0b0ltcG9ydHNcbiAgfVxuXTtcbmNvbnN0IHNjaGVtYU9yZ0NvbXBvbmVudHMgPSBbXG4gIFwiU2NoZW1hT3JnQXJ0aWNsZVwiLFxuICBcIlNjaGVtYU9yZ0JyZWFkY3J1bWJcIixcbiAgXCJTY2hlbWFPcmdDb21tZW50XCIsXG4gIFwiU2NoZW1hT3JnRXZlbnRcIixcbiAgXCJTY2hlbWFPcmdGb29kRXN0YWJsaXNobWVudFwiLFxuICBcIlNjaGVtYU9yZ0hvd1RvXCIsXG4gIFwiU2NoZW1hT3JnSW1hZ2VcIixcbiAgXCJTY2hlbWFPcmdKb2JQb3N0aW5nXCIsXG4gIFwiU2NoZW1hT3JnTG9jYWxCdXNpbmVzc1wiLFxuICBcIlNjaGVtYU9yZ09yZ2FuaXphdGlvblwiLFxuICBcIlNjaGVtYU9yZ1BlcnNvblwiLFxuICBcIlNjaGVtYU9yZ1Byb2R1Y3RcIixcbiAgXCJTY2hlbWFPcmdRdWVzdGlvblwiLFxuICBcIlNjaGVtYU9yZ1JlY2lwZVwiLFxuICBcIlNjaGVtYU9yZ1Jldmlld1wiLFxuICBcIlNjaGVtYU9yZ1ZpZGVvXCIsXG4gIFwiU2NoZW1hT3JnV2ViUGFnZVwiLFxuICBcIlNjaGVtYU9yZ1dlYlNpdGVcIixcbiAgXCJTY2hlbWFPcmdNb3ZpZVwiLFxuICBcIlNjaGVtYU9yZ0NvdXJzZVwiLFxuICBcIlNjaGVtYU9yZ0l0ZW1MaXN0XCIsXG4gIFwiU2NoZW1hT3JnQm9va1wiLFxuICBcIlNjaGVtYU9yZ1NvZnR3YXJlQXBwXCJcbl07XG5mdW5jdGlvbiBTY2hlbWFPcmdSZXNvbHZlcihvcHRpb25zID0ge30pIHtcbiAgY29uc3QgeyBwcmVmaXggPSBcIlwiIH0gPSBvcHRpb25zO1xuICByZXR1cm4ge1xuICAgIHR5cGU6IFwiY29tcG9uZW50XCIsXG4gICAgcmVzb2x2ZTogKG5hbWUpID0+IHtcbiAgICAgIGlmIChuYW1lLnN0YXJ0c1dpdGgocHJlZml4KSkge1xuICAgICAgICBjb25zdCBjb21wb25lbnROYW1lID0gbmFtZS5zdWJzdHJpbmcocHJlZml4Lmxlbmd0aCk7XG4gICAgICAgIGlmIChzY2hlbWFPcmdDb21wb25lbnRzLmluY2x1ZGVzKGNvbXBvbmVudE5hbWUpKSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIG5hbWU6IGNvbXBvbmVudE5hbWUsXG4gICAgICAgICAgICBmcm9tOiBcIkB1bmhlYWQvc2NoZW1hLW9yZy92dWVcIlxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH07XG59XG5cbmV4cG9ydCB7IFNjaGVtYU9yZ1Jlc29sdmVyLCBzY2hlbWFPcmdBdXRvSW1wb3J0cywgc2NoZW1hT3JnQ29tcG9uZW50cyB9O1xuIiwiY29uc3Qgc2NoZW1hQXV0b0ltcG9ydHMgPSBbXG4gIFwiZGVmaW5lQWRkcmVzc1wiLFxuICBcImRlZmluZUFnZ3JlZ2F0ZU9mZmVyXCIsXG4gIFwiZGVmaW5lQWdncmVnYXRlUmF0aW5nXCIsXG4gIFwiZGVmaW5lQXJ0aWNsZVwiLFxuICBcImRlZmluZUJvb2tcIixcbiAgXCJkZWZpbmVCb29rRWRpdGlvblwiLFxuICBcImRlZmluZUJyZWFkY3J1bWJcIixcbiAgXCJkZWZpbmVDb21tZW50XCIsXG4gIFwiZGVmaW5lQ291cnNlXCIsXG4gIFwiZGVmaW5lRGF0YXNldFwiLFxuICBcImRlZmluZUV2ZW50XCIsXG4gIFwiZGVmaW5lRm9vZEVzdGFibGlzaG1lbnRcIixcbiAgXCJkZWZpbmVIb3dUb1wiLFxuICBcImRlZmluZUhvd1RvU3RlcFwiLFxuICBcImRlZmluZUltYWdlXCIsXG4gIFwiZGVmaW5lSXRlbUxpc3RcIixcbiAgXCJkZWZpbmVKb2JQb3N0aW5nXCIsXG4gIFwiZGVmaW5lTGlzdEl0ZW1cIixcbiAgXCJkZWZpbmVMb2NhbEJ1c2luZXNzXCIsXG4gIFwiZGVmaW5lTW92aWVcIixcbiAgXCJkZWZpbmVNdXNpY0FsYnVtXCIsXG4gIFwiZGVmaW5lTXVzaWNHcm91cFwiLFxuICBcImRlZmluZU11c2ljUGxheWxpc3RcIixcbiAgXCJkZWZpbmVNdXNpY1JlY29yZGluZ1wiLFxuICBcImRlZmluZU9mZmVyXCIsXG4gIFwiZGVmaW5lT3BlbmluZ0hvdXJzXCIsXG4gIFwiZGVmaW5lT3JnYW5pemF0aW9uXCIsXG4gIFwiZGVmaW5lUGVyc29uXCIsXG4gIFwiZGVmaW5lUGxhY2VcIixcbiAgXCJkZWZpbmVQb2RjYXN0RXBpc29kZVwiLFxuICBcImRlZmluZVBvZGNhc3RTZWFzb25cIixcbiAgXCJkZWZpbmVQb2RjYXN0U2VyaWVzXCIsXG4gIFwiZGVmaW5lUHJvZHVjdFwiLFxuICBcImRlZmluZVF1ZXN0aW9uXCIsXG4gIFwiZGVmaW5lUmVhZEFjdGlvblwiLFxuICBcImRlZmluZVJlY2lwZVwiLFxuICBcImRlZmluZVJldmlld1wiLFxuICBcImRlZmluZVNlYXJjaEFjdGlvblwiLFxuICBcImRlZmluZVNlcnZpY2VcIixcbiAgXCJkZWZpbmVTb2Z0d2FyZUFwcFwiLFxuICBcImRlZmluZVRWRXBpc29kZVwiLFxuICBcImRlZmluZVRWU2Vhc29uXCIsXG4gIFwiZGVmaW5lVFZTZXJpZXNcIixcbiAgXCJkZWZpbmVWaWRlb1wiLFxuICBcImRlZmluZVZpcnR1YWxMb2NhdGlvblwiLFxuICBcImRlZmluZVdlYlBhZ2VcIixcbiAgXCJkZWZpbmVXZWJTaXRlXCIsXG4gIFwidXNlU2NoZW1hT3JnXCJcbl07XG5cbmV4cG9ydCB7IHNjaGVtYUF1dG9JbXBvcnRzIH07XG4iLCJpbXBvcnQgeyBVIGFzIFVuaGVhZFNjaGVtYU9yZywgYXkgYXMgbm9ybWFsaXplU2NoZW1hT3JnSW5wdXQsIGggYXMgYWRkcmVzc1Jlc29sdmVyLCBpIGFzIGFnZ3JlZ2F0ZU9mZmVyUmVzb2x2ZXIsIGogYXMgYWdncmVnYXRlUmF0aW5nUmVzb2x2ZXIsIGsgYXMgYXJ0aWNsZVJlc29sdmVyLCBuIGFzIGJyZWFkY3J1bWJSZXNvbHZlciwgbyBhcyBjb21tZW50UmVzb2x2ZXIsIGFoIGFzIGV2ZW50UmVzb2x2ZXIsIGFpIGFzIGZvb2RFc3RhYmxpc2htZW50UmVzb2x2ZXIsIGFaIGFzIHZpcnR1YWxMb2NhdGlvblJlc29sdmVyLCBhRCBhcyBwbGFjZVJlc29sdmVyLCBhaiBhcyBob3dUb1Jlc29sdmVyLCBhbCBhcyBob3dUb1N0ZXBSZXNvbHZlciwgYW0gYXMgaW1hZ2VSZXNvbHZlciwgYXAgYXMgam9iUG9zdGluZ1Jlc29sdmVyLCBhciBhcyBsb2NhbEJ1c2luZXNzUmVzb2x2ZXIsIGF6IGFzIG9mZmVyUmVzb2x2ZXIsIGFBIGFzIG9wZW5pbmdIb3Vyc1Jlc29sdmVyLCBhQiBhcyBvcmdhbml6YXRpb25SZXNvbHZlciwgYUMgYXMgcGVyc29uUmVzb2x2ZXIsIGFIIGFzIHByb2R1Y3RSZXNvbHZlciwgYUkgYXMgcXVlc3Rpb25SZXNvbHZlciwgYUwgYXMgcmVjaXBlUmVzb2x2ZXIsIGFRIGFzIHJldmlld1Jlc29sdmVyLCBhWSBhcyB2aWRlb1Jlc29sdmVyLCBhXyBhcyB3ZWJQYWdlUmVzb2x2ZXIsIGEkIGFzIHdlYlNpdGVSZXNvbHZlciwgbSBhcyBib29rUmVzb2x2ZXIsIHAgYXMgY291cnNlUmVzb2x2ZXIsIGFvIGFzIGl0ZW1MaXN0UmVzb2x2ZXIsIGFxIGFzIGxpc3RJdGVtUmVzb2x2ZXIsIGF0IGFzIG1vdmllUmVzb2x2ZXIsIGFSIGFzIHNlYXJjaEFjdGlvblJlc29sdmVyLCBhSyBhcyByZWFkQWN0aW9uUmVzb2x2ZXIsIGFUIGFzIHNvZnR3YXJlQXBwUmVzb2x2ZXIsIGwgYXMgYm9va0VkaXRpb25SZXNvbHZlciwgciBhcyBkYXRhc2V0UmVzb2x2ZXIsIGF4IGFzIG11c2ljUmVjb3JkaW5nUmVzb2x2ZXIsIGF1IGFzIG11c2ljQWxidW1SZXNvbHZlciwgYXYgYXMgbXVzaWNHcm91cFJlc29sdmVyLCBhdyBhcyBtdXNpY1BsYXlsaXN0UmVzb2x2ZXIsIGFHIGFzIHBvZGNhc3RTZXJpZXNSZXNvbHZlciwgYUUgYXMgcG9kY2FzdEVwaXNvZGVSZXNvbHZlciwgYUYgYXMgcG9kY2FzdFNlYXNvblJlc29sdmVyLCBhVyBhcyB0dlNlcmllc1Jlc29sdmVyLCBhViBhcyB0dlNlYXNvblJlc29sdmVyLCBhVSBhcyB0dkVwaXNvZGVSZXNvbHZlciwgYVMgYXMgc2VydmljZVJlc29sdmVyIH0gZnJvbSAnLi9zaGFyZWQvc2NoZW1hLW9yZy5CZnl0TzVrTy5tanMnO1xuZXhwb3J0IHsgU2NoZW1hT3JnUmVzb2x2ZXIsIHNjaGVtYU9yZ0F1dG9JbXBvcnRzLCBzY2hlbWFPcmdDb21wb25lbnRzIH0gZnJvbSAnLi92dWUvbWV0YS5tanMnO1xuaW1wb3J0IHsgaXNSZWYsIGNvbXB1dGVkLCBkZWZpbmVDb21wb25lbnQsIHJlZiwgdW5yZWYsIGggfSBmcm9tICd2dWUnO1xuaW1wb3J0IHsgaW5qZWN0SGVhZCwgdXNlSGVhZCB9IGZyb20gJ0B1bmhlYWQvdnVlJztcbmltcG9ydCAndW5oZWFkL3BsdWdpbnMnO1xuaW1wb3J0ICd1bmhlYWQvdXRpbHMnO1xuaW1wb3J0ICcuL2ltcG9ydHMubWpzJztcblxuZnVuY3Rpb24gd2l0aFJlc29sdmVyKGlucHV0LCByZXNvbHZlcikge1xuICByZXR1cm4geyAuLi5pbnB1dCwgX3Jlc29sdmVyOiByZXNvbHZlciB9O1xufVxuZnVuY3Rpb24gcHJvdmlkZVJlc29sdmVyKGlucHV0LCByZXNvbHZlcikge1xuICBjb25zdCByZXNvbHZlZElucHV0ID0gaW5wdXQgfHwge307XG4gIGlmIChpc1JlZihyZXNvbHZlZElucHV0KSkge1xuICAgIHJldHVybiBjb21wdXRlZCgoKSA9PiB7XG4gICAgICBjb25zdCB2YWx1ZSA9IHJlc29sdmVkSW5wdXQudmFsdWU7XG4gICAgICByZXR1cm4gdmFsdWUgJiYgdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiID8gd2l0aFJlc29sdmVyKHZhbHVlLCByZXNvbHZlcikgOiB2YWx1ZTtcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gd2l0aFJlc29sdmVyKHJlc29sdmVkSW5wdXQsIHJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZUFkZHJlc3MoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgYWRkcmVzc1Jlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZUFnZ3JlZ2F0ZU9mZmVyKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIGFnZ3JlZ2F0ZU9mZmVyUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lQWdncmVnYXRlUmF0aW5nKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIGFnZ3JlZ2F0ZVJhdGluZ1Jlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZUFydGljbGUoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgYXJ0aWNsZVJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZUJyZWFkY3J1bWIoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgYnJlYWRjcnVtYlJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZUNvbW1lbnQoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgY29tbWVudFJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZUV2ZW50KGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIGV2ZW50UmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lRm9vZEVzdGFibGlzaG1lbnQoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgZm9vZEVzdGFibGlzaG1lbnRSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVWaXJ0dWFsTG9jYXRpb24oaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgdmlydHVhbExvY2F0aW9uUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lUGxhY2UoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgcGxhY2VSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVIb3dUbyhpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBob3dUb1Jlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZUhvd1RvU3RlcChpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBob3dUb1N0ZXBSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVJbWFnZShpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBpbWFnZVJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZUpvYlBvc3RpbmcoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgam9iUG9zdGluZ1Jlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZUxvY2FsQnVzaW5lc3MoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgbG9jYWxCdXNpbmVzc1Jlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZU9mZmVyKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIG9mZmVyUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lT3BlbmluZ0hvdXJzKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIG9wZW5pbmdIb3Vyc1Jlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZU9yZ2FuaXphdGlvbihpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBvcmdhbml6YXRpb25SZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVQZXJzb24oaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgcGVyc29uUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lUHJvZHVjdChpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBwcm9kdWN0UmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lUXVlc3Rpb24oaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgcXVlc3Rpb25SZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVSZWNpcGUoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgcmVjaXBlUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lUmV2aWV3KGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIHJldmlld1Jlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZVZpZGVvKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIHZpZGVvUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lV2ViUGFnZShpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCB3ZWJQYWdlUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lV2ViU2l0ZShpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCB3ZWJTaXRlUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lQm9vayhpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBib29rUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lQ291cnNlKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIGNvdXJzZVJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZUl0ZW1MaXN0KGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIGl0ZW1MaXN0UmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lTGlzdEl0ZW0oaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgbGlzdEl0ZW1SZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVNb3ZpZShpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBtb3ZpZVJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZVNlYXJjaEFjdGlvbihpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBzZWFyY2hBY3Rpb25SZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVSZWFkQWN0aW9uKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIHJlYWRBY3Rpb25SZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVTb2Z0d2FyZUFwcChpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBzb2Z0d2FyZUFwcFJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZUJvb2tFZGl0aW9uKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIGJvb2tFZGl0aW9uUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lRGF0YXNldChpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBkYXRhc2V0UmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lTXVzaWNSZWNvcmRpbmcoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgbXVzaWNSZWNvcmRpbmdSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVNdXNpY0FsYnVtKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIG11c2ljQWxidW1SZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVNdXNpY0dyb3VwKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIG11c2ljR3JvdXBSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVNdXNpY1BsYXlsaXN0KGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIG11c2ljUGxheWxpc3RSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVQb2RjYXN0U2VyaWVzKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIHBvZGNhc3RTZXJpZXNSZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVQb2RjYXN0RXBpc29kZShpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBwb2RjYXN0RXBpc29kZVJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZVBvZGNhc3RTZWFzb24oaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgcG9kY2FzdFNlYXNvblJlc29sdmVyKTtcbn1cbmZ1bmN0aW9uIGRlZmluZVRWU2VyaWVzKGlucHV0KSB7XG4gIHJldHVybiBwcm92aWRlUmVzb2x2ZXIoaW5wdXQsIHR2U2VyaWVzUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lVFZTZWFzb24oaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgdHZTZWFzb25SZXNvbHZlcik7XG59XG5mdW5jdGlvbiBkZWZpbmVUVkVwaXNvZGUoaW5wdXQpIHtcbiAgcmV0dXJuIHByb3ZpZGVSZXNvbHZlcihpbnB1dCwgdHZFcGlzb2RlUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gZGVmaW5lU2VydmljZShpbnB1dCkge1xuICByZXR1cm4gcHJvdmlkZVJlc29sdmVyKGlucHV0LCBzZXJ2aWNlUmVzb2x2ZXIpO1xufVxuZnVuY3Rpb24gdXNlU2NoZW1hT3JnKGlucHV0ID0gW10sIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB1bmhlYWQgPSBvcHRpb25zLmhlYWQgfHwgaW5qZWN0SGVhZCgpO1xuICB1bmhlYWQudXNlKFVuaGVhZFNjaGVtYU9yZygpKTtcbiAgY29uc3QgZW50cnkgPSB1c2VIZWFkKG5vcm1hbGl6ZVNjaGVtYU9yZ0lucHV0KGlucHV0KSwgb3B0aW9ucyk7XG4gIGNvbnN0IGNvcmVQYXRjaCA9IGVudHJ5LnBhdGNoO1xuICBjb25zdCBwdWJsaWNFbnRyeSA9IGVudHJ5O1xuICBwdWJsaWNFbnRyeS5wYXRjaCA9IChpbnB1dDIpID0+IGNvcmVQYXRjaChub3JtYWxpemVTY2hlbWFPcmdJbnB1dChpbnB1dDIpKTtcbiAgcmV0dXJuIHB1YmxpY0VudHJ5O1xufVxuXG5jb25zdCBLRUJBQl9SRSA9IC8tLi9nO1xuZnVuY3Rpb24gc2hhbGxvd1ZOb2Rlc1RvVGV4dChub2Rlcykge1xuICBsZXQgdGV4dCA9IFwiXCI7XG4gIGZvciAoY29uc3Qgbm9kZSBvZiBub2Rlcykge1xuICAgIGlmICh0eXBlb2Ygbm9kZS5jaGlsZHJlbiA9PT0gXCJzdHJpbmdcIilcbiAgICAgIHRleHQgKz0gbm9kZS5jaGlsZHJlbi50cmltKCk7XG4gIH1cbiAgcmV0dXJuIHRleHQ7XG59XG5mdW5jdGlvbiBmaXhLZXkocykge1xuICBsZXQga2V5ID0gcy5yZXBsYWNlKEtFQkFCX1JFLCAoeCkgPT4geFsxXS50b1VwcGVyQ2FzZSgpKTtcbiAgaWYgKGtleSA9PT0gXCJ0eXBlXCIgfHwga2V5ID09PSBcImlkXCIpXG4gICAga2V5ID0gYEAke2tleX1gO1xuICByZXR1cm4ga2V5O1xufVxuZnVuY3Rpb24gaWdub3JlS2V5KHMpIHtcbiAgaWYgKHMuc3RhcnRzV2l0aChcImFyaWEtXCIpIHx8IHMuc3RhcnRzV2l0aChcImRhdGEtXCIpKVxuICAgIHJldHVybiBmYWxzZTtcbiAgcmV0dXJuIHMgPT09IFwiY2xhc3NcIiB8fCBzID09PSBcInN0eWxlXCI7XG59XG5mdW5jdGlvbiBkZWZpbmVTY2hlbWFPcmdDb21wb25lbnQobmFtZSwgZGVmaW5lRm4pIHtcbiAgcmV0dXJuIGRlZmluZUNvbXBvbmVudCh7XG4gICAgbmFtZSxcbiAgICBwcm9wczoge1xuICAgICAgYXM6IFN0cmluZ1xuICAgIH0sXG4gICAgc2V0dXAocHJvcHMsIHsgc2xvdHMsIGF0dHJzIH0pIHtcbiAgICAgIGNvbnN0IG5vZGUgPSByZWYobnVsbCk7XG4gICAgICBjb25zdCBub2RlUGFydGlhbCA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICAgICAgY29uc3QgdmFsID0ge307XG4gICAgICAgIE9iamVjdC5lbnRyaWVzKHVucmVmKGF0dHJzKSkuZm9yRWFjaCgoW2tleSwgdmFsdWVdKSA9PiB7XG4gICAgICAgICAgaWYgKCFpZ25vcmVLZXkoa2V5KSkge1xuICAgICAgICAgICAgdmFsW2ZpeEtleShrZXkpXSA9IHVucmVmKHZhbHVlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgICBpZiAoIW5vZGUudmFsdWUpIHtcbiAgICAgICAgICBmb3IgKGNvbnN0IFtrZXksIHNsb3RdIG9mIE9iamVjdC5lbnRyaWVzKHNsb3RzKSkge1xuICAgICAgICAgICAgaWYgKCFzbG90IHx8IGtleSA9PT0gXCJkZWZhdWx0XCIpXG4gICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgdmFsW2ZpeEtleShrZXkpXSA9IHNoYWxsb3dWTm9kZXNUb1RleHQoc2xvdChwcm9wcykpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdmFsO1xuICAgICAgfSk7XG4gICAgICBpZiAoZGVmaW5lRm4pIHtcbiAgICAgICAgdXNlU2NoZW1hT3JnKGRlZmluZUZuKHVucmVmKG5vZGVQYXJ0aWFsKSkpO1xuICAgICAgfVxuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgY29uc3QgZGF0YSA9IHVucmVmKG5vZGVQYXJ0aWFsKTtcbiAgICAgICAgaWYgKCFzbG90cy5kZWZhdWx0KVxuICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICBjb25zdCBjaGlsZFNsb3RzID0gW107XG4gICAgICAgIGlmIChzbG90cy5kZWZhdWx0KVxuICAgICAgICAgIGNoaWxkU2xvdHMucHVzaChzbG90cy5kZWZhdWx0KGRhdGEpKTtcbiAgICAgICAgcmV0dXJuIGgocHJvcHMuYXMgfHwgXCJkaXZcIiwge30sIGNoaWxkU2xvdHMpO1xuICAgICAgfTtcbiAgICB9XG4gIH0pO1xufVxuY29uc3QgU2NoZW1hT3JnQXJ0aWNsZSA9IC8qIEBfX1BVUkVfXyAqLyBkZWZpbmVTY2hlbWFPcmdDb21wb25lbnQoXCJTY2hlbWFPcmdBcnRpY2xlXCIsIGRlZmluZUFydGljbGUpO1xuY29uc3QgU2NoZW1hT3JnQnJlYWRjcnVtYiA9IC8qIEBfX1BVUkVfXyAqLyBkZWZpbmVTY2hlbWFPcmdDb21wb25lbnQoXCJTY2hlbWFPcmdCcmVhZGNydW1iXCIsIGRlZmluZUJyZWFkY3J1bWIpO1xuY29uc3QgU2NoZW1hT3JnQ29tbWVudCA9IC8qIEBfX1BVUkVfXyAqLyBkZWZpbmVTY2hlbWFPcmdDb21wb25lbnQoXCJTY2hlbWFPcmdDb21tZW50XCIsIGRlZmluZUNvbW1lbnQpO1xuY29uc3QgU2NoZW1hT3JnRXZlbnQgPSAvKiBAX19QVVJFX18gKi8gZGVmaW5lU2NoZW1hT3JnQ29tcG9uZW50KFwiU2NoZW1hT3JnRXZlbnRcIiwgZGVmaW5lRXZlbnQpO1xuY29uc3QgU2NoZW1hT3JnRm9vZEVzdGFibGlzaG1lbnQgPSAvKiBAX19QVVJFX18gKi8gZGVmaW5lU2NoZW1hT3JnQ29tcG9uZW50KFwiU2NoZW1hT3JnRm9vZEVzdGFibGlzaG1lbnRcIiwgZGVmaW5lRm9vZEVzdGFibGlzaG1lbnQpO1xuY29uc3QgU2NoZW1hT3JnSG93VG8gPSAvKiBAX19QVVJFX18gKi8gZGVmaW5lU2NoZW1hT3JnQ29tcG9uZW50KFwiU2NoZW1hT3JnSG93VG9cIiwgZGVmaW5lSG93VG8pO1xuY29uc3QgU2NoZW1hT3JnSW1hZ2UgPSAvKiBAX19QVVJFX18gKi8gZGVmaW5lU2NoZW1hT3JnQ29tcG9uZW50KFwiU2NoZW1hT3JnSW1hZ2VcIiwgZGVmaW5lSW1hZ2UpO1xuY29uc3QgU2NoZW1hT3JnSm9iUG9zdGluZyA9IC8qIEBfX1BVUkVfXyAqLyBkZWZpbmVTY2hlbWFPcmdDb21wb25lbnQoXCJTY2hlbWFPcmdKb2JQb3N0aW5nXCIsIGRlZmluZUpvYlBvc3RpbmcpO1xuY29uc3QgU2NoZW1hT3JnTG9jYWxCdXNpbmVzcyA9IC8qIEBfX1BVUkVfXyAqLyBkZWZpbmVTY2hlbWFPcmdDb21wb25lbnQoXCJTY2hlbWFPcmdMb2NhbEJ1c2luZXNzXCIsIGRlZmluZUxvY2FsQnVzaW5lc3MpO1xuY29uc3QgU2NoZW1hT3JnT3JnYW5pemF0aW9uID0gLyogQF9fUFVSRV9fICovIGRlZmluZVNjaGVtYU9yZ0NvbXBvbmVudChcIlNjaGVtYU9yZ09yZ2FuaXphdGlvblwiLCBkZWZpbmVPcmdhbml6YXRpb24pO1xuY29uc3QgU2NoZW1hT3JnUGVyc29uID0gLyogQF9fUFVSRV9fICovIGRlZmluZVNjaGVtYU9yZ0NvbXBvbmVudChcIlNjaGVtYU9yZ1BlcnNvblwiLCBkZWZpbmVQZXJzb24pO1xuY29uc3QgU2NoZW1hT3JnUHJvZHVjdCA9IC8qIEBfX1BVUkVfXyAqLyBkZWZpbmVTY2hlbWFPcmdDb21wb25lbnQoXCJTY2hlbWFPcmdQcm9kdWN0XCIsIGRlZmluZVByb2R1Y3QpO1xuY29uc3QgU2NoZW1hT3JnUXVlc3Rpb24gPSAvKiBAX19QVVJFX18gKi8gZGVmaW5lU2NoZW1hT3JnQ29tcG9uZW50KFwiU2NoZW1hT3JnUXVlc3Rpb25cIiwgZGVmaW5lUXVlc3Rpb24pO1xuY29uc3QgU2NoZW1hT3JnUmVjaXBlID0gLyogQF9fUFVSRV9fICovIGRlZmluZVNjaGVtYU9yZ0NvbXBvbmVudChcIlNjaGVtYU9yZ1JlY2lwZVwiLCBkZWZpbmVSZWNpcGUpO1xuY29uc3QgU2NoZW1hT3JnUmV2aWV3ID0gLyogQF9fUFVSRV9fICovIGRlZmluZVNjaGVtYU9yZ0NvbXBvbmVudChcIlNjaGVtYU9yZ1Jldmlld1wiLCBkZWZpbmVSZXZpZXcpO1xuY29uc3QgU2NoZW1hT3JnVmlkZW8gPSAvKiBAX19QVVJFX18gKi8gZGVmaW5lU2NoZW1hT3JnQ29tcG9uZW50KFwiU2NoZW1hT3JnVmlkZW9cIiwgZGVmaW5lVmlkZW8pO1xuY29uc3QgU2NoZW1hT3JnV2ViUGFnZSA9IC8qIEBfX1BVUkVfXyAqLyBkZWZpbmVTY2hlbWFPcmdDb21wb25lbnQoXCJTY2hlbWFPcmdXZWJQYWdlXCIsIGRlZmluZVdlYlBhZ2UpO1xuY29uc3QgU2NoZW1hT3JnV2ViU2l0ZSA9IC8qIEBfX1BVUkVfXyAqLyBkZWZpbmVTY2hlbWFPcmdDb21wb25lbnQoXCJTY2hlbWFPcmdXZWJTaXRlXCIsIGRlZmluZVdlYlNpdGUpO1xuY29uc3QgU2NoZW1hT3JnTW92aWUgPSAvKiBAX19QVVJFX18gKi8gZGVmaW5lU2NoZW1hT3JnQ29tcG9uZW50KFwiU2NoZW1hT3JnTW92aWVcIiwgZGVmaW5lTW92aWUpO1xuY29uc3QgU2NoZW1hT3JnQ291cnNlID0gLyogQF9fUFVSRV9fICovIGRlZmluZVNjaGVtYU9yZ0NvbXBvbmVudChcIlNjaGVtYU9yZ0NvdXJzZVwiLCBkZWZpbmVDb3Vyc2UpO1xuY29uc3QgU2NoZW1hT3JnSXRlbUxpc3QgPSAvKiBAX19QVVJFX18gKi8gZGVmaW5lU2NoZW1hT3JnQ29tcG9uZW50KFwiU2NoZW1hT3JnSXRlbUxpc3RcIiwgZGVmaW5lSXRlbUxpc3QpO1xuY29uc3QgU2NoZW1hT3JnQm9vayA9IC8qIEBfX1BVUkVfXyAqLyBkZWZpbmVTY2hlbWFPcmdDb21wb25lbnQoXCJTY2hlbWFPcmdCb29rXCIsIGRlZmluZUJvb2spO1xuY29uc3QgU2NoZW1hT3JnU29mdHdhcmVBcHAgPSAvKiBAX19QVVJFX18gKi8gZGVmaW5lU2NoZW1hT3JnQ29tcG9uZW50KFwiU2NoZW1hT3JnU29mdHdhcmVBcHBcIiwgZGVmaW5lU29mdHdhcmVBcHApO1xuXG5leHBvcnQgeyBTY2hlbWFPcmdBcnRpY2xlLCBTY2hlbWFPcmdCb29rLCBTY2hlbWFPcmdCcmVhZGNydW1iLCBTY2hlbWFPcmdDb21tZW50LCBTY2hlbWFPcmdDb3Vyc2UsIFNjaGVtYU9yZ0V2ZW50LCBTY2hlbWFPcmdGb29kRXN0YWJsaXNobWVudCwgU2NoZW1hT3JnSG93VG8sIFNjaGVtYU9yZ0ltYWdlLCBTY2hlbWFPcmdJdGVtTGlzdCwgU2NoZW1hT3JnSm9iUG9zdGluZywgU2NoZW1hT3JnTG9jYWxCdXNpbmVzcywgU2NoZW1hT3JnTW92aWUsIFNjaGVtYU9yZ09yZ2FuaXphdGlvbiwgU2NoZW1hT3JnUGVyc29uLCBTY2hlbWFPcmdQcm9kdWN0LCBTY2hlbWFPcmdRdWVzdGlvbiwgU2NoZW1hT3JnUmVjaXBlLCBTY2hlbWFPcmdSZXZpZXcsIFNjaGVtYU9yZ1NvZnR3YXJlQXBwLCBTY2hlbWFPcmdWaWRlbywgU2NoZW1hT3JnV2ViUGFnZSwgU2NoZW1hT3JnV2ViU2l0ZSwgVW5oZWFkU2NoZW1hT3JnLCBkZWZpbmVBZGRyZXNzLCBkZWZpbmVBZ2dyZWdhdGVPZmZlciwgZGVmaW5lQWdncmVnYXRlUmF0aW5nLCBkZWZpbmVBcnRpY2xlLCBkZWZpbmVCb29rLCBkZWZpbmVCb29rRWRpdGlvbiwgZGVmaW5lQnJlYWRjcnVtYiwgZGVmaW5lQ29tbWVudCwgZGVmaW5lQ291cnNlLCBkZWZpbmVEYXRhc2V0LCBkZWZpbmVFdmVudCwgZGVmaW5lRm9vZEVzdGFibGlzaG1lbnQsIGRlZmluZUhvd1RvLCBkZWZpbmVIb3dUb1N0ZXAsIGRlZmluZUltYWdlLCBkZWZpbmVJdGVtTGlzdCwgZGVmaW5lSm9iUG9zdGluZywgZGVmaW5lTGlzdEl0ZW0sIGRlZmluZUxvY2FsQnVzaW5lc3MsIGRlZmluZU1vdmllLCBkZWZpbmVNdXNpY0FsYnVtLCBkZWZpbmVNdXNpY0dyb3VwLCBkZWZpbmVNdXNpY1BsYXlsaXN0LCBkZWZpbmVNdXNpY1JlY29yZGluZywgZGVmaW5lT2ZmZXIsIGRlZmluZU9wZW5pbmdIb3VycywgZGVmaW5lT3JnYW5pemF0aW9uLCBkZWZpbmVQZXJzb24sIGRlZmluZVBsYWNlLCBkZWZpbmVQb2RjYXN0RXBpc29kZSwgZGVmaW5lUG9kY2FzdFNlYXNvbiwgZGVmaW5lUG9kY2FzdFNlcmllcywgZGVmaW5lUHJvZHVjdCwgZGVmaW5lUXVlc3Rpb24sIGRlZmluZVJlYWRBY3Rpb24sIGRlZmluZVJlY2lwZSwgZGVmaW5lUmV2aWV3LCBkZWZpbmVTY2hlbWFPcmdDb21wb25lbnQsIGRlZmluZVNlYXJjaEFjdGlvbiwgZGVmaW5lU2VydmljZSwgZGVmaW5lU29mdHdhcmVBcHAsIGRlZmluZVRWRXBpc29kZSwgZGVmaW5lVFZTZWFzb24sIGRlZmluZVRWU2VyaWVzLCBkZWZpbmVWaWRlbywgZGVmaW5lVmlydHVhbExvY2F0aW9uLCBkZWZpbmVXZWJQYWdlLCBkZWZpbmVXZWJTaXRlLCB1c2VTY2hlbWFPcmcgfTtcbiJdLCJmaWxlIjoiL1ZvbHVtZXMvQ29kaW5nL1Byb2plY3RzL1dlYnNpdGVzL2luZWlhaC9mcm9udGVuZC9ub2RlX21vZHVsZXMvLmNhY2hlL3ZpdGUvY2xpZW50L2RlcHMvQHVuaGVhZF9zY2hlbWEtb3JnX3Z1ZS5qcyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzXX0=