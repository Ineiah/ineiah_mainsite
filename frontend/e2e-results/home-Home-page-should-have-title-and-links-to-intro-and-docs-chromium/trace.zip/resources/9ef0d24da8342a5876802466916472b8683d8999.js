import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/components/volt/Label.vue");import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@8.2.0_@types+node@26.1.2_esbuild@0.28.1_jiti@2.7.0_sa_bcac4fa99282966dd94ca7ad2dfebde1/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=7e73afc2"
import { defineComponent as _defineComponent } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const theme = `
  flex items-center gap-2 text-sm leading-none font-medium select-none 
  group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 
  peer-disabled:cursor-not-allowed peer-disabled:opacity-50 relative text-surface-900 dark:text-surface-100
`;
const _sfc_main = /*@__PURE__*/ _defineComponent({
	__name: "VoltLabel",
	props: {
		labelFor: {
			type: String,
			required: true
		},
		label: {
			type: String,
			required: false
		}
	},
	setup(__props, { expose: __expose }) {
		__expose();
		const __returned__ = { theme };
		Object.defineProperty(__returned__, "__isScriptSetup", {
			enumerable: false,
			value: true
		});
		return __returned__;
	}
});
import { renderSlot as _renderSlot, toDisplayString as _toDisplayString, createTextVNode as _createTextVNode, createElementVNode as _createElementVNode, normalizeClass as _normalizeClass, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _hoisted_1 = ["for"];
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
	return _openBlock(), _tracer(2,2,_createElementBlock("div", { class: _normalizeClass($setup.theme) }, [_renderSlot(_ctx.$slots, "default"), _tracer(4,4,_createElementVNode("label", { for: $props.labelFor }, [_renderSlot(_ctx.$slots, "label", {}, () => [_createTextVNode(
		_toDisplayString($props.label),
		1
		/* TEXT */
	)])], 8, _hoisted_1))]));
}
_sfc_main.__hmrId = "3e411f35";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.on("file-changed", ({ file }) => {
	__VUE_HMR_RUNTIME__.CHANGED_FILE = file;
});
import.meta.hot.accept((mod) => {
	if (!mod) return;
	const { default: updated, _rerender_only } = mod;
	if (_rerender_only) {
		__VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
	} else {
		__VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
	}
});
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper";
export default /*#__PURE__*/ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "/Volumes/Coding/Projects/Websites/ineiah/frontend/app/components/volt/Label.vue"]]);

function _tracer(line, column, vnode) { return _tracerRecordPosition("app/components/volt/Label.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7QUFjQSxNQUFNLFFBQVE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQWJaLHFEQU9NLFNBUEEsT0FBSyxnQkFBRSxZQUFLLE1BQ2hCLFlBQVEscUNBQ1Isb0JBSVEsV0FKQSxLQUFLLGdCQUFRLElBQ25CLFlBRU8saUNBREY7RUFBQSw2QkFBSztFQUFBOztDQUFBIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJMYWJlbC52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxuICA8ZGl2IDpjbGFzcz1cInRoZW1lXCI+XG4gICAgPHNsb3QgLz5cbiAgICA8bGFiZWwgOmZvcj1cImxhYmVsRm9yXCI+XG4gICAgICA8c2xvdCBuYW1lPVwibGFiZWxcIj5cbiAgICAgICAge3sgbGFiZWwgfX1cbiAgICAgIDwvc2xvdD5cbiAgICA8L2xhYmVsPlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG5cbjxzY3JpcHQgc2V0dXAgbGFuZz1cInRzXCI+XG5kZWZpbmVQcm9wczx7IGxhYmVsRm9yOiBzdHJpbmcsIGxhYmVsPzogc3RyaW5nIH0+KClcblxuY29uc3QgdGhlbWUgPSBgXG4gIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gbGVhZGluZy1ub25lIGZvbnQtbWVkaXVtIHNlbGVjdC1ub25lIFxuICBncm91cC1kYXRhLVtkaXNhYmxlZD10cnVlXTpwb2ludGVyLWV2ZW50cy1ub25lIGdyb3VwLWRhdGEtW2Rpc2FibGVkPXRydWVdOm9wYWNpdHktNTAgXG4gIHBlZXItZGlzYWJsZWQ6Y3Vyc29yLW5vdC1hbGxvd2VkIHBlZXItZGlzYWJsZWQ6b3BhY2l0eS01MCByZWxhdGl2ZSB0ZXh0LXN1cmZhY2UtOTAwIGRhcms6dGV4dC1zdXJmYWNlLTEwMFxuYFxuPC9zY3JpcHQ+XG4iXSwiZmlsZSI6Ii9Wb2x1bWVzL0NvZGluZy9Qcm9qZWN0cy9XZWJzaXRlcy9pbmVpYWgvZnJvbnRlbmQvYXBwL2NvbXBvbmVudHMvdm9sdC9MYWJlbC52dWUifQ==