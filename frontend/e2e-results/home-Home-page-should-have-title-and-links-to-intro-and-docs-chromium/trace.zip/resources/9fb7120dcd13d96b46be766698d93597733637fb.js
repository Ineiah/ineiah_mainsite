export const defaultServices = [
	{
		name: "Shampoings • Coupes • Mise en forme",
		globalDescription: "Rafraîchissez votre coupe et donnez-lui un coup de fraîcheur avec la restructuration, qui vous apportera forme et volume en quelques coups de ciseaux ! La coupe sur cheveux secs permet de rééquilibrer les volumes, la longueur et le style de la coupe (faire une frange, couper les pointes…)",
		includes: [
			"Diagnostic / Conseils",
			"Shampooing conditionner",
			"Séchage (naturel ou brushing)"
		],
		services: [
			{
				name: "Court",
				price: 45,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 60,
				image: "/images/services/customer15.jpg",
				category: "Coupe"
			},
			{
				name: "Mi-Long",
				price: 55,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 90,
				image: "/images/services/customer18.jpg",
				category: "Coupe"
			},
			{
				name: "XL",
				price: 75,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 120,
				image: "/images/services/customer1.jpg",
				category: "Coupe"
			},
			{
				name: "Transformation",
				price: 75,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 120,
				image: "/images/services/customer2.jpg",
				category: "Coupe"
			}
		]
	},
	{
		name: "Shampoings • Mise en forme",
		globalDescription: "Le shampoing coiffage est un service de soins capillaires qui combine un nettoyage en profondeur avec une mise en forme professionnelle. Il comprend généralement un shampooing adapté à votre type de cheveux, suivi d'un conditionnement pour nourrir et protéger les cheveux, et se termine par un coiffage personnalisé pour mettre en valeur votre style et votre personnalité.",
		includes: [
			"Diagnostic / Conseils",
			"Shampooing conditionner",
			"Séchage (naturel ou brushing)"
		],
		services: [
			{
				name: "Court",
				price: 32,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 45,
				image: "/images/services/customer15.jpg",
				category: "Coupe"
			},
			{
				name: "Mi-Long",
				price: 42,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 60,
				image: "/images/services/customer15.jpg",
				category: "Coupe"
			},
			{
				name: "Long",
				price: 52,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 90,
				image: "/images/services/customer15.jpg",
				category: "Coupe"
			},
			{
				name: "XL",
				price: 62,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 120,
				image: "/images/services/customer15.jpg",
				category: "Coupe"
			}
		]
	},
	{
		name: "Coupe seule",
		globalDescription: "Le shampoing coiffage est un service de soins capillaires qui combine un nettoyage en profondeur avec une mise en forme professionnelle. Il comprend généralement un shampooing adapté à votre type de cheveux, suivi d'un conditionnement pour nourrir et protéger les cheveux, et se termine par un coiffage personnalisé pour mettre en valeur votre style et votre personnalité.",
		includes: [
			"Diagnostic / Conseils",
			"Shampooing conditionner",
			"Séchage (naturel ou brushing)"
		],
		services: [{
			name: null,
			price: null,
			priceText: "25 à 45€",
			gender: "Mixte",
			description: null,
			includes: [],
			duration: null,
			image: "/images/services/customer15.jpg",
			category: "Coupe"
		}]
	},
	{
		name: "Soins Olaplex",
		globalDescription: "Olaplex est un traitement capillaire révolutionnaire qui répare les cheveux endommagés en reconstruisant les liaisons disulfures brisées. Il est idéal pour les cheveux fragilisés par les traitements chimiques, la chaleur ou les agressions environnementales, offrant une restauration profonde et durable pour des cheveux plus forts, plus sains et plus brillants.",
		includes: ["Soin réparateur profond / Anti-casse"],
		services: [
			{
				name: "Court",
				price: 30,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 60,
				image: "/images/services/customer15.jpg",
				category: "Soin"
			},
			{
				name: "Mi-long",
				price: 60,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 60,
				image: "/images/services/customer15.jpg",
				category: "Soin"
			},
			{
				name: "Long",
				price: 60,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 60,
				image: "/images/services/customer15.jpg",
				category: "Soin"
			},
			{
				name: "XL",
				price: 90,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 60,
				image: "/images/services/customer15.jpg",
				category: "Soin"
			}
		]
	},
	{
		name: "Soins Kératine Végétale / Botox Naturel",
		globalDescription: "Le soin à la kératine végétale est un traitement capillaire naturel qui utilise des ingrédients d'origine végétale pour lisser, nourrir et renforcer les cheveux. Contrairement aux traitements à la kératine traditionnels qui contiennent souvent des produits chimiques agressifs, ce soin offre une alternative plus douce et respectueuse de la santé capillaire, tout en offrant des résultats durables pour des cheveux plus lisses, plus brillants et plus faciles à coiffer.",
		includes: ["Soin réparateur profond / Anti-casse"],
		services: [
			{
				name: "Court",
				price: 75,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 30,
				image: "/images/services/customer15.jpg",
				category: "Soin"
			},
			{
				name: "Mi-long",
				price: 85,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 50,
				image: "/images/services/customer15.jpg",
				category: "Soin"
			},
			{
				name: "Long",
				price: 95,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 70,
				image: "/images/services/customer15.jpg",
				category: "Soin"
			},
			{
				name: "XL",
				price: 150,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 90,
				image: "/images/services/customer15.jpg",
				category: "Soin"
			}
		]
	},
	{
		name: "Couleurs",
		globalDescription: "La coloration capillaire est un processus de transformation qui permet de changer la couleur naturelle des cheveux en utilisant des produits chimiques ou naturels. Que vous souhaitiez couvrir des cheveux gris, ajouter des reflets, ou opter pour une teinte complètement différente, la coloration offre une multitude d'options pour exprimer votre style et votre personnalité à travers vos cheveux.",
		includes: ["Soin réparateur profond / Anti-casse"],
		services: [
			{
				name: "Court",
				price: 75,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 30,
				image: "/images/services/customer7.jpg",
				category: "Coloration"
			},
			{
				name: "Mi-long",
				price: 85,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 50,
				image: "/images/services/customer7.jpg",
				category: "Coloration"
			},
			{
				name: "Long",
				price: 95,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 70,
				image: "/images/services/customer7.jpg",
				category: "Coloration"
			},
			{
				name: "XL",
				price: 105,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 90,
				image: "/images/services/customer7.jpg",
				category: "Coloration"
			}
		]
	},
	{
		name: "Hair Contouring",
		globalDescription: "Le hair contouring est une technique de coloration qui utilise des nuances et des reflets pour sculpter et mettre en valeur les traits du visage. Cette méthode permet de créer un effet de lumière et de profondeur personnalisé, tout en respectant la santé des cheveux grâce à des produits de qualité et des soins adaptés.",
		includes: ["Soin réparateur profond / Anti-casse"],
		services: [
			{
				name: "Court",
				price: 75,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 30,
				image: "/images/services/customer15.jpg",
				category: "Hair Contouring"
			},
			{
				name: "Mi-long",
				price: 85,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 50,
				image: "/images/services/customer15.jpg",
				category: "Hair Contouring"
			},
			{
				name: "Long",
				price: 95,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 70,
				image: "/images/services/customer15.jpg",
				category: "Hair Contouring"
			},
			{
				name: "XL",
				price: 105,
				priceText: null,
				gender: "Mixte",
				description: null,
				includes: [],
				duration: 90,
				image: "/images/services/customer15.jpg",
				category: "Hair Contouring"
			}
		]
	},
	{
		name: "Tarifs enfants",
		globalDescription: "Le tarif enfant s'applique généralement aux enfants de moins de 12 ans, offrant des prix réduits pour les coupes et les soins adaptés à leurs besoins spécifiques. Ces tarifs permettent aux parents de faire profiter à leurs enfants de services de qualité tout en respectant leur budget, avec des prestations conçues pour les cheveux délicats des plus jeunes.",
		includes: [
			"Diagnostic / Conseils",
			"Shampooing conditionner",
			"Séchage (naturel ou brushing)"
		],
		services: [{
			name: null,
			price: null,
			priceText: "15 à 25€",
			gender: "Mixte",
			description: null,
			includes: [],
			duration: null,
			image: "/images/services/customer15.jpg",
			category: "Coupe"
		}]
	}
];

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBRUEsT0FBTyxNQUFNLGtCQUFvQztDQUMvQztFQUNFLE1BQU07RUFDTixtQkFBbUI7RUFDbkIsVUFBVTtHQUNSO0dBQ0E7R0FDQTtFQUNGO0VBQ0EsVUFBVTtHQUNSO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtFQUNGO0NBQ0Y7Q0FDQTtFQUNFLE1BQU07RUFDTixtQkFBbUI7RUFDbkIsVUFBVTtHQUNSO0dBQ0E7R0FDQTtFQUNGO0VBQ0EsVUFBVTtHQUNSO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtFQUNGO0NBQ0Y7Q0FDQTtFQUNFLE1BQU07RUFDTixtQkFBbUI7RUFDbkIsVUFBVTtHQUNSO0dBQ0E7R0FDQTtFQUNGO0VBQ0EsVUFBVSxDQUNSO0dBQ0UsTUFBTTtHQUNOLE9BQU87R0FDUCxXQUFXO0dBQ1gsUUFBUTtHQUNSLGFBQWE7R0FDYixVQUFVLENBQUM7R0FDWCxVQUFVO0dBQ1YsT0FBTztHQUNQLFVBQVU7RUFDWixDQUNGO0NBQ0Y7Q0FDQTtFQUNFLE1BQU07RUFDTixtQkFBbUI7RUFDbkIsVUFBVSxDQUNSLHNDQUNGO0VBQ0EsVUFBVTtHQUNSO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FFWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtFQUNGO0NBQ0Y7Q0FDQTtFQUNFLE1BQU07RUFDTixtQkFBbUI7RUFDbkIsVUFBVSxDQUNSLHNDQUNGO0VBQ0EsVUFBVTtHQUNSO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtFQUNGO0NBQ0Y7Q0FDQTtFQUNFLE1BQU07RUFDTixtQkFBbUI7RUFDbkIsVUFBVSxDQUNSLHNDQUNGO0VBQ0EsVUFBVTtHQUNSO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtFQUNGO0NBQ0Y7Q0FDQTtFQUNFLE1BQU07RUFDTixtQkFBbUI7RUFDbkIsVUFBVSxDQUNSLHNDQUNGO0VBQ0EsVUFBVTtHQUNSO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtHQUNBO0lBQ0UsTUFBTTtJQUNOLE9BQU87SUFDUCxXQUFXO0lBQ1gsUUFBUTtJQUNSLGFBQWE7SUFDYixVQUFVLENBQUM7SUFDWCxVQUFVO0lBQ1YsT0FBTztJQUNQLFVBQVU7R0FDWjtFQUNGO0NBQ0Y7Q0FDQTtFQUNFLE1BQU07RUFDTixtQkFBbUI7RUFDbkIsVUFBVTtHQUNSO0dBQ0E7R0FDQTtFQUNGO0VBQ0EsVUFBVSxDQUNSO0dBQ0UsTUFBTTtHQUNOLE9BQU87R0FDUCxXQUFXO0dBQ1gsUUFBUTtHQUNSLGFBQWE7R0FDYixVQUFVLENBQUM7R0FDWCxVQUFVO0dBQ1YsT0FBTztHQUNQLFVBQVU7RUFDWixDQUNGO0NBQ0Y7QUFDRiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJpdGVtcy50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IFNlcnZpY2VTZWN0aW9uIH0gZnJvbSAnfi90eXBlcydcblxuZXhwb3J0IGNvbnN0IGRlZmF1bHRTZXJ2aWNlczogU2VydmljZVNlY3Rpb25bXSA9IFtcbiAge1xuICAgIG5hbWU6ICdTaGFtcG9pbmdzIOKAoiBDb3VwZXMg4oCiIE1pc2UgZW4gZm9ybWUnLFxuICAgIGdsb2JhbERlc2NyaXB0aW9uOiAnUmFmcmHDrmNoaXNzZXogdm90cmUgY291cGUgZXQgZG9ubmV6LWx1aSB1biBjb3VwIGRlIGZyYcOuY2hldXIgYXZlYyBsYSByZXN0cnVjdHVyYXRpb24sIHF1aSB2b3VzIGFwcG9ydGVyYSBmb3JtZSBldCB2b2x1bWUgZW4gcXVlbHF1ZXMgY291cHMgZGUgY2lzZWF1eCAhIExhIGNvdXBlIHN1ciBjaGV2ZXV4IHNlY3MgcGVybWV0IGRlIHLDqcOpcXVpbGlicmVyIGxlcyB2b2x1bWVzLCBsYSBsb25ndWV1ciBldCBsZSBzdHlsZSBkZSBsYSBjb3VwZSAoZmFpcmUgdW5lIGZyYW5nZSwgY291cGVyIGxlcyBwb2ludGVz4oCmKScsXG4gICAgaW5jbHVkZXM6IFtcbiAgICAgICdEaWFnbm9zdGljIC8gQ29uc2VpbHMnLFxuICAgICAgJ1NoYW1wb29pbmcgY29uZGl0aW9ubmVyJyxcbiAgICAgICdTw6ljaGFnZSAobmF0dXJlbCBvdSBicnVzaGluZyknXG4gICAgXSxcbiAgICBzZXJ2aWNlczogW1xuICAgICAge1xuICAgICAgICBuYW1lOiAnQ291cnQnLFxuICAgICAgICBwcmljZTogNDUsXG4gICAgICAgIHByaWNlVGV4dDogbnVsbCxcbiAgICAgICAgZ2VuZGVyOiAnTWl4dGUnLFxuICAgICAgICBkZXNjcmlwdGlvbjogbnVsbCxcbiAgICAgICAgaW5jbHVkZXM6IFtdLFxuICAgICAgICBkdXJhdGlvbjogNjAsXG4gICAgICAgIGltYWdlOiAnL2ltYWdlcy9zZXJ2aWNlcy9jdXN0b21lcjE1LmpwZycsXG4gICAgICAgIGNhdGVnb3J5OiAnQ291cGUnXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBuYW1lOiAnTWktTG9uZycsXG4gICAgICAgIHByaWNlOiA1NSxcbiAgICAgICAgcHJpY2VUZXh0OiBudWxsLFxuICAgICAgICBnZW5kZXI6ICdNaXh0ZScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBudWxsLFxuICAgICAgICBpbmNsdWRlczogW10sXG4gICAgICAgIGR1cmF0aW9uOiA5MCxcbiAgICAgICAgaW1hZ2U6ICcvaW1hZ2VzL3NlcnZpY2VzL2N1c3RvbWVyMTguanBnJyxcbiAgICAgICAgY2F0ZWdvcnk6ICdDb3VwZSdcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIG5hbWU6ICdYTCcsXG4gICAgICAgIHByaWNlOiA3NSxcbiAgICAgICAgcHJpY2VUZXh0OiBudWxsLFxuICAgICAgICBnZW5kZXI6ICdNaXh0ZScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBudWxsLFxuICAgICAgICBpbmNsdWRlczogW10sXG4gICAgICAgIGR1cmF0aW9uOiAxMjAsXG4gICAgICAgIGltYWdlOiAnL2ltYWdlcy9zZXJ2aWNlcy9jdXN0b21lcjEuanBnJyxcbiAgICAgICAgY2F0ZWdvcnk6ICdDb3VwZSdcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIG5hbWU6ICdUcmFuc2Zvcm1hdGlvbicsXG4gICAgICAgIHByaWNlOiA3NSxcbiAgICAgICAgcHJpY2VUZXh0OiBudWxsLFxuICAgICAgICBnZW5kZXI6ICdNaXh0ZScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBudWxsLFxuICAgICAgICBpbmNsdWRlczogW10sXG4gICAgICAgIGR1cmF0aW9uOiAxMjAsXG4gICAgICAgIGltYWdlOiAnL2ltYWdlcy9zZXJ2aWNlcy9jdXN0b21lcjIuanBnJyxcbiAgICAgICAgY2F0ZWdvcnk6ICdDb3VwZSdcbiAgICAgIH1cbiAgICBdXG4gIH0sXG4gIHtcbiAgICBuYW1lOiAnU2hhbXBvaW5ncyDigKIgTWlzZSBlbiBmb3JtZScsXG4gICAgZ2xvYmFsRGVzY3JpcHRpb246ICdMZSBzaGFtcG9pbmcgY29pZmZhZ2UgZXN0IHVuIHNlcnZpY2UgZGUgc29pbnMgY2FwaWxsYWlyZXMgcXVpIGNvbWJpbmUgdW4gbmV0dG95YWdlIGVuIHByb2ZvbmRldXIgYXZlYyB1bmUgbWlzZSBlbiBmb3JtZSBwcm9mZXNzaW9ubmVsbGUuIElsIGNvbXByZW5kIGfDqW7DqXJhbGVtZW50IHVuIHNoYW1wb29pbmcgYWRhcHTDqSDDoCB2b3RyZSB0eXBlIGRlIGNoZXZldXgsIHN1aXZpIGRcXCd1biBjb25kaXRpb25uZW1lbnQgcG91ciBub3VycmlyIGV0IHByb3TDqWdlciBsZXMgY2hldmV1eCwgZXQgc2UgdGVybWluZSBwYXIgdW4gY29pZmZhZ2UgcGVyc29ubmFsaXPDqSBwb3VyIG1ldHRyZSBlbiB2YWxldXIgdm90cmUgc3R5bGUgZXQgdm90cmUgcGVyc29ubmFsaXTDqS4nLFxuICAgIGluY2x1ZGVzOiBbXG4gICAgICAnRGlhZ25vc3RpYyAvIENvbnNlaWxzJyxcbiAgICAgICdTaGFtcG9vaW5nIGNvbmRpdGlvbm5lcicsXG4gICAgICAnU8OpY2hhZ2UgKG5hdHVyZWwgb3UgYnJ1c2hpbmcpJ1xuICAgIF0sXG4gICAgc2VydmljZXM6IFtcbiAgICAgIHtcbiAgICAgICAgbmFtZTogJ0NvdXJ0JyxcbiAgICAgICAgcHJpY2U6IDMyLFxuICAgICAgICBwcmljZVRleHQ6IG51bGwsXG4gICAgICAgIGdlbmRlcjogJ01peHRlJyxcbiAgICAgICAgZGVzY3JpcHRpb246IG51bGwsXG4gICAgICAgIGluY2x1ZGVzOiBbXSxcbiAgICAgICAgZHVyYXRpb246IDQ1LFxuICAgICAgICBpbWFnZTogJy9pbWFnZXMvc2VydmljZXMvY3VzdG9tZXIxNS5qcGcnLFxuICAgICAgICBjYXRlZ29yeTogJ0NvdXBlJ1xuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbmFtZTogJ01pLUxvbmcnLFxuICAgICAgICBwcmljZTogNDIsXG4gICAgICAgIHByaWNlVGV4dDogbnVsbCxcbiAgICAgICAgZ2VuZGVyOiAnTWl4dGUnLFxuICAgICAgICBkZXNjcmlwdGlvbjogbnVsbCxcbiAgICAgICAgaW5jbHVkZXM6IFtdLFxuICAgICAgICBkdXJhdGlvbjogNjAsXG4gICAgICAgIGltYWdlOiAnL2ltYWdlcy9zZXJ2aWNlcy9jdXN0b21lcjE1LmpwZycsXG4gICAgICAgIGNhdGVnb3J5OiAnQ291cGUnXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBuYW1lOiAnTG9uZycsXG4gICAgICAgIHByaWNlOiA1MixcbiAgICAgICAgcHJpY2VUZXh0OiBudWxsLFxuICAgICAgICBnZW5kZXI6ICdNaXh0ZScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBudWxsLFxuICAgICAgICBpbmNsdWRlczogW10sXG4gICAgICAgIGR1cmF0aW9uOiA5MCxcbiAgICAgICAgaW1hZ2U6ICcvaW1hZ2VzL3NlcnZpY2VzL2N1c3RvbWVyMTUuanBnJyxcbiAgICAgICAgY2F0ZWdvcnk6ICdDb3VwZSdcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIG5hbWU6ICdYTCcsXG4gICAgICAgIHByaWNlOiA2MixcbiAgICAgICAgcHJpY2VUZXh0OiBudWxsLFxuICAgICAgICBnZW5kZXI6ICdNaXh0ZScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBudWxsLFxuICAgICAgICBpbmNsdWRlczogW10sXG4gICAgICAgIGR1cmF0aW9uOiAxMjAsXG4gICAgICAgIGltYWdlOiAnL2ltYWdlcy9zZXJ2aWNlcy9jdXN0b21lcjE1LmpwZycsXG4gICAgICAgIGNhdGVnb3J5OiAnQ291cGUnXG4gICAgICB9XG4gICAgXVxuICB9LFxuICB7XG4gICAgbmFtZTogJ0NvdXBlIHNldWxlJyxcbiAgICBnbG9iYWxEZXNjcmlwdGlvbjogJ0xlIHNoYW1wb2luZyBjb2lmZmFnZSBlc3QgdW4gc2VydmljZSBkZSBzb2lucyBjYXBpbGxhaXJlcyBxdWkgY29tYmluZSB1biBuZXR0b3lhZ2UgZW4gcHJvZm9uZGV1ciBhdmVjIHVuZSBtaXNlIGVuIGZvcm1lIHByb2Zlc3Npb25uZWxsZS4gSWwgY29tcHJlbmQgZ8OpbsOpcmFsZW1lbnQgdW4gc2hhbXBvb2luZyBhZGFwdMOpIMOgIHZvdHJlIHR5cGUgZGUgY2hldmV1eCwgc3VpdmkgZFxcJ3VuIGNvbmRpdGlvbm5lbWVudCBwb3VyIG5vdXJyaXIgZXQgcHJvdMOpZ2VyIGxlcyBjaGV2ZXV4LCBldCBzZSB0ZXJtaW5lIHBhciB1biBjb2lmZmFnZSBwZXJzb25uYWxpc8OpIHBvdXIgbWV0dHJlIGVuIHZhbGV1ciB2b3RyZSBzdHlsZSBldCB2b3RyZSBwZXJzb25uYWxpdMOpLicsXG4gICAgaW5jbHVkZXM6IFtcbiAgICAgICdEaWFnbm9zdGljIC8gQ29uc2VpbHMnLFxuICAgICAgJ1NoYW1wb29pbmcgY29uZGl0aW9ubmVyJyxcbiAgICAgICdTw6ljaGFnZSAobmF0dXJlbCBvdSBicnVzaGluZyknXG4gICAgXSxcbiAgICBzZXJ2aWNlczogW1xuICAgICAge1xuICAgICAgICBuYW1lOiBudWxsLFxuICAgICAgICBwcmljZTogbnVsbCxcbiAgICAgICAgcHJpY2VUZXh0OiAnMjUgw6AgNDXigqwnLFxuICAgICAgICBnZW5kZXI6ICdNaXh0ZScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBudWxsLFxuICAgICAgICBpbmNsdWRlczogW10sXG4gICAgICAgIGR1cmF0aW9uOiBudWxsLFxuICAgICAgICBpbWFnZTogJy9pbWFnZXMvc2VydmljZXMvY3VzdG9tZXIxNS5qcGcnLFxuICAgICAgICBjYXRlZ29yeTogJ0NvdXBlJ1xuICAgICAgfVxuICAgIF1cbiAgfSxcbiAge1xuICAgIG5hbWU6ICdTb2lucyBPbGFwbGV4JyxcbiAgICBnbG9iYWxEZXNjcmlwdGlvbjogJ09sYXBsZXggZXN0IHVuIHRyYWl0ZW1lbnQgY2FwaWxsYWlyZSByw6l2b2x1dGlvbm5haXJlIHF1aSByw6lwYXJlIGxlcyBjaGV2ZXV4IGVuZG9tbWFnw6lzIGVuIHJlY29uc3RydWlzYW50IGxlcyBsaWFpc29ucyBkaXN1bGZ1cmVzIGJyaXPDqWVzLiBJbCBlc3QgaWTDqWFsIHBvdXIgbGVzIGNoZXZldXggZnJhZ2lsaXPDqXMgcGFyIGxlcyB0cmFpdGVtZW50cyBjaGltaXF1ZXMsIGxhIGNoYWxldXIgb3UgbGVzIGFncmVzc2lvbnMgZW52aXJvbm5lbWVudGFsZXMsIG9mZnJhbnQgdW5lIHJlc3RhdXJhdGlvbiBwcm9mb25kZSBldCBkdXJhYmxlIHBvdXIgZGVzIGNoZXZldXggcGx1cyBmb3J0cywgcGx1cyBzYWlucyBldCBwbHVzIGJyaWxsYW50cy4nLFxuICAgIGluY2x1ZGVzOiBbXG4gICAgICAnU29pbiByw6lwYXJhdGV1ciBwcm9mb25kIC8gQW50aS1jYXNzZSdcbiAgICBdLFxuICAgIHNlcnZpY2VzOiBbXG4gICAgICB7XG4gICAgICAgIG5hbWU6ICdDb3VydCcsXG4gICAgICAgIHByaWNlOiAzMCxcbiAgICAgICAgcHJpY2VUZXh0OiBudWxsLFxuICAgICAgICBnZW5kZXI6ICdNaXh0ZScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBudWxsLFxuICAgICAgICBpbmNsdWRlczogW10sXG4gICAgICAgIGR1cmF0aW9uOiA2MCxcbiAgICAgICAgaW1hZ2U6ICcvaW1hZ2VzL3NlcnZpY2VzL2N1c3RvbWVyMTUuanBnJyxcbiAgICAgICAgY2F0ZWdvcnk6ICdTb2luJ1xuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbmFtZTogJ01pLWxvbmcnLFxuICAgICAgICBwcmljZTogNjAsXG4gICAgICAgIHByaWNlVGV4dDogbnVsbCxcbiAgICAgICAgZ2VuZGVyOiAnTWl4dGUnLFxuICAgICAgICBkZXNjcmlwdGlvbjogbnVsbCxcbiAgICAgICAgaW5jbHVkZXM6IFtdLFxuICAgICAgICBkdXJhdGlvbjogNjAsXG4gICAgICAgIGltYWdlOiAnL2ltYWdlcy9zZXJ2aWNlcy9jdXN0b21lcjE1LmpwZycsXG4gICAgICAgIGNhdGVnb3J5OiAnU29pbidcblxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbmFtZTogJ0xvbmcnLFxuICAgICAgICBwcmljZTogNjAsXG4gICAgICAgIHByaWNlVGV4dDogbnVsbCxcbiAgICAgICAgZ2VuZGVyOiAnTWl4dGUnLFxuICAgICAgICBkZXNjcmlwdGlvbjogbnVsbCxcbiAgICAgICAgaW5jbHVkZXM6IFtdLFxuICAgICAgICBkdXJhdGlvbjogNjAsXG4gICAgICAgIGltYWdlOiAnL2ltYWdlcy9zZXJ2aWNlcy9jdXN0b21lcjE1LmpwZycsXG4gICAgICAgIGNhdGVnb3J5OiAnU29pbidcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIG5hbWU6ICdYTCcsXG4gICAgICAgIHByaWNlOiA5MCxcbiAgICAgICAgcHJpY2VUZXh0OiBudWxsLFxuICAgICAgICBnZW5kZXI6ICdNaXh0ZScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBudWxsLFxuICAgICAgICBpbmNsdWRlczogW10sXG4gICAgICAgIGR1cmF0aW9uOiA2MCxcbiAgICAgICAgaW1hZ2U6ICcvaW1hZ2VzL3NlcnZpY2VzL2N1c3RvbWVyMTUuanBnJyxcbiAgICAgICAgY2F0ZWdvcnk6ICdTb2luJ1xuICAgICAgfVxuICAgIF1cbiAgfSxcbiAge1xuICAgIG5hbWU6ICdTb2lucyBLw6lyYXRpbmUgVsOpZ8OpdGFsZSAvIEJvdG94IE5hdHVyZWwnLFxuICAgIGdsb2JhbERlc2NyaXB0aW9uOiAnTGUgc29pbiDDoCBsYSBrw6lyYXRpbmUgdsOpZ8OpdGFsZSBlc3QgdW4gdHJhaXRlbWVudCBjYXBpbGxhaXJlIG5hdHVyZWwgcXVpIHV0aWxpc2UgZGVzIGluZ3LDqWRpZW50cyBkXFwnb3JpZ2luZSB2w6lnw6l0YWxlIHBvdXIgbGlzc2VyLCBub3VycmlyIGV0IHJlbmZvcmNlciBsZXMgY2hldmV1eC4gQ29udHJhaXJlbWVudCBhdXggdHJhaXRlbWVudHMgw6AgbGEga8OpcmF0aW5lIHRyYWRpdGlvbm5lbHMgcXVpIGNvbnRpZW5uZW50IHNvdXZlbnQgZGVzIHByb2R1aXRzIGNoaW1pcXVlcyBhZ3Jlc3NpZnMsIGNlIHNvaW4gb2ZmcmUgdW5lIGFsdGVybmF0aXZlIHBsdXMgZG91Y2UgZXQgcmVzcGVjdHVldXNlIGRlIGxhIHNhbnTDqSBjYXBpbGxhaXJlLCB0b3V0IGVuIG9mZnJhbnQgZGVzIHLDqXN1bHRhdHMgZHVyYWJsZXMgcG91ciBkZXMgY2hldmV1eCBwbHVzIGxpc3NlcywgcGx1cyBicmlsbGFudHMgZXQgcGx1cyBmYWNpbGVzIMOgIGNvaWZmZXIuJyxcbiAgICBpbmNsdWRlczogW1xuICAgICAgJ1NvaW4gcsOpcGFyYXRldXIgcHJvZm9uZCAvIEFudGktY2Fzc2UnXG4gICAgXSxcbiAgICBzZXJ2aWNlczogW1xuICAgICAge1xuICAgICAgICBuYW1lOiAnQ291cnQnLFxuICAgICAgICBwcmljZTogNzUsXG4gICAgICAgIHByaWNlVGV4dDogbnVsbCxcbiAgICAgICAgZ2VuZGVyOiAnTWl4dGUnLFxuICAgICAgICBkZXNjcmlwdGlvbjogbnVsbCxcbiAgICAgICAgaW5jbHVkZXM6IFtdLFxuICAgICAgICBkdXJhdGlvbjogMzAsXG4gICAgICAgIGltYWdlOiAnL2ltYWdlcy9zZXJ2aWNlcy9jdXN0b21lcjE1LmpwZycsXG4gICAgICAgIGNhdGVnb3J5OiAnU29pbidcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIG5hbWU6ICdNaS1sb25nJyxcbiAgICAgICAgcHJpY2U6IDg1LFxuICAgICAgICBwcmljZVRleHQ6IG51bGwsXG4gICAgICAgIGdlbmRlcjogJ01peHRlJyxcbiAgICAgICAgZGVzY3JpcHRpb246IG51bGwsXG4gICAgICAgIGluY2x1ZGVzOiBbXSxcbiAgICAgICAgZHVyYXRpb246IDUwLFxuICAgICAgICBpbWFnZTogJy9pbWFnZXMvc2VydmljZXMvY3VzdG9tZXIxNS5qcGcnLFxuICAgICAgICBjYXRlZ29yeTogJ1NvaW4nXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBuYW1lOiAnTG9uZycsXG4gICAgICAgIHByaWNlOiA5NSxcbiAgICAgICAgcHJpY2VUZXh0OiBudWxsLFxuICAgICAgICBnZW5kZXI6ICdNaXh0ZScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBudWxsLFxuICAgICAgICBpbmNsdWRlczogW10sXG4gICAgICAgIGR1cmF0aW9uOiA3MCxcbiAgICAgICAgaW1hZ2U6ICcvaW1hZ2VzL3NlcnZpY2VzL2N1c3RvbWVyMTUuanBnJyxcbiAgICAgICAgY2F0ZWdvcnk6ICdTb2luJ1xuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbmFtZTogJ1hMJyxcbiAgICAgICAgcHJpY2U6IDE1MCxcbiAgICAgICAgcHJpY2VUZXh0OiBudWxsLFxuICAgICAgICBnZW5kZXI6ICdNaXh0ZScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBudWxsLFxuICAgICAgICBpbmNsdWRlczogW10sXG4gICAgICAgIGR1cmF0aW9uOiA5MCxcbiAgICAgICAgaW1hZ2U6ICcvaW1hZ2VzL3NlcnZpY2VzL2N1c3RvbWVyMTUuanBnJyxcbiAgICAgICAgY2F0ZWdvcnk6ICdTb2luJ1xuICAgICAgfVxuICAgIF1cbiAgfSxcbiAge1xuICAgIG5hbWU6ICdDb3VsZXVycycsXG4gICAgZ2xvYmFsRGVzY3JpcHRpb246ICdMYSBjb2xvcmF0aW9uIGNhcGlsbGFpcmUgZXN0IHVuIHByb2Nlc3N1cyBkZSB0cmFuc2Zvcm1hdGlvbiBxdWkgcGVybWV0IGRlIGNoYW5nZXIgbGEgY291bGV1ciBuYXR1cmVsbGUgZGVzIGNoZXZldXggZW4gdXRpbGlzYW50IGRlcyBwcm9kdWl0cyBjaGltaXF1ZXMgb3UgbmF0dXJlbHMuIFF1ZSB2b3VzIHNvdWhhaXRpZXogY291dnJpciBkZXMgY2hldmV1eCBncmlzLCBham91dGVyIGRlcyByZWZsZXRzLCBvdSBvcHRlciBwb3VyIHVuZSB0ZWludGUgY29tcGzDqHRlbWVudCBkaWZmw6lyZW50ZSwgbGEgY29sb3JhdGlvbiBvZmZyZSB1bmUgbXVsdGl0dWRlIGRcXCdvcHRpb25zIHBvdXIgZXhwcmltZXIgdm90cmUgc3R5bGUgZXQgdm90cmUgcGVyc29ubmFsaXTDqSDDoCB0cmF2ZXJzIHZvcyBjaGV2ZXV4LicsXG4gICAgaW5jbHVkZXM6IFtcbiAgICAgICdTb2luIHLDqXBhcmF0ZXVyIHByb2ZvbmQgLyBBbnRpLWNhc3NlJ1xuICAgIF0sXG4gICAgc2VydmljZXM6IFtcbiAgICAgIHtcbiAgICAgICAgbmFtZTogJ0NvdXJ0JyxcbiAgICAgICAgcHJpY2U6IDc1LFxuICAgICAgICBwcmljZVRleHQ6IG51bGwsXG4gICAgICAgIGdlbmRlcjogJ01peHRlJyxcbiAgICAgICAgZGVzY3JpcHRpb246IG51bGwsXG4gICAgICAgIGluY2x1ZGVzOiBbXSxcbiAgICAgICAgZHVyYXRpb246IDMwLFxuICAgICAgICBpbWFnZTogJy9pbWFnZXMvc2VydmljZXMvY3VzdG9tZXI3LmpwZycsXG4gICAgICAgIGNhdGVnb3J5OiAnQ29sb3JhdGlvbidcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIG5hbWU6ICdNaS1sb25nJyxcbiAgICAgICAgcHJpY2U6IDg1LFxuICAgICAgICBwcmljZVRleHQ6IG51bGwsXG4gICAgICAgIGdlbmRlcjogJ01peHRlJyxcbiAgICAgICAgZGVzY3JpcHRpb246IG51bGwsXG4gICAgICAgIGluY2x1ZGVzOiBbXSxcbiAgICAgICAgZHVyYXRpb246IDUwLFxuICAgICAgICBpbWFnZTogJy9pbWFnZXMvc2VydmljZXMvY3VzdG9tZXI3LmpwZycsXG4gICAgICAgIGNhdGVnb3J5OiAnQ29sb3JhdGlvbidcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIG5hbWU6ICdMb25nJyxcbiAgICAgICAgcHJpY2U6IDk1LFxuICAgICAgICBwcmljZVRleHQ6IG51bGwsXG4gICAgICAgIGdlbmRlcjogJ01peHRlJyxcbiAgICAgICAgZGVzY3JpcHRpb246IG51bGwsXG4gICAgICAgIGluY2x1ZGVzOiBbXSxcbiAgICAgICAgZHVyYXRpb246IDcwLFxuICAgICAgICBpbWFnZTogJy9pbWFnZXMvc2VydmljZXMvY3VzdG9tZXI3LmpwZycsXG4gICAgICAgIGNhdGVnb3J5OiAnQ29sb3JhdGlvbidcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIG5hbWU6ICdYTCcsXG4gICAgICAgIHByaWNlOiAxMDUsXG4gICAgICAgIHByaWNlVGV4dDogbnVsbCxcbiAgICAgICAgZ2VuZGVyOiAnTWl4dGUnLFxuICAgICAgICBkZXNjcmlwdGlvbjogbnVsbCxcbiAgICAgICAgaW5jbHVkZXM6IFtdLFxuICAgICAgICBkdXJhdGlvbjogOTAsXG4gICAgICAgIGltYWdlOiAnL2ltYWdlcy9zZXJ2aWNlcy9jdXN0b21lcjcuanBnJyxcbiAgICAgICAgY2F0ZWdvcnk6ICdDb2xvcmF0aW9uJ1xuICAgICAgfVxuICAgIF1cbiAgfSxcbiAge1xuICAgIG5hbWU6ICdIYWlyIENvbnRvdXJpbmcnLFxuICAgIGdsb2JhbERlc2NyaXB0aW9uOiAnTGUgaGFpciBjb250b3VyaW5nIGVzdCB1bmUgdGVjaG5pcXVlIGRlIGNvbG9yYXRpb24gcXVpIHV0aWxpc2UgZGVzIG51YW5jZXMgZXQgZGVzIHJlZmxldHMgcG91ciBzY3VscHRlciBldCBtZXR0cmUgZW4gdmFsZXVyIGxlcyB0cmFpdHMgZHUgdmlzYWdlLiBDZXR0ZSBtw6l0aG9kZSBwZXJtZXQgZGUgY3LDqWVyIHVuIGVmZmV0IGRlIGx1bWnDqHJlIGV0IGRlIHByb2ZvbmRldXIgcGVyc29ubmFsaXPDqSwgdG91dCBlbiByZXNwZWN0YW50IGxhIHNhbnTDqSBkZXMgY2hldmV1eCBncsOiY2Ugw6AgZGVzIHByb2R1aXRzIGRlIHF1YWxpdMOpIGV0IGRlcyBzb2lucyBhZGFwdMOpcy4nLFxuICAgIGluY2x1ZGVzOiBbXG4gICAgICAnU29pbiByw6lwYXJhdGV1ciBwcm9mb25kIC8gQW50aS1jYXNzZSdcbiAgICBdLFxuICAgIHNlcnZpY2VzOiBbXG4gICAgICB7XG4gICAgICAgIG5hbWU6ICdDb3VydCcsXG4gICAgICAgIHByaWNlOiA3NSxcbiAgICAgICAgcHJpY2VUZXh0OiBudWxsLFxuICAgICAgICBnZW5kZXI6ICdNaXh0ZScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBudWxsLFxuICAgICAgICBpbmNsdWRlczogW10sXG4gICAgICAgIGR1cmF0aW9uOiAzMCxcbiAgICAgICAgaW1hZ2U6ICcvaW1hZ2VzL3NlcnZpY2VzL2N1c3RvbWVyMTUuanBnJyxcbiAgICAgICAgY2F0ZWdvcnk6ICdIYWlyIENvbnRvdXJpbmcnXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBuYW1lOiAnTWktbG9uZycsXG4gICAgICAgIHByaWNlOiA4NSxcbiAgICAgICAgcHJpY2VUZXh0OiBudWxsLFxuICAgICAgICBnZW5kZXI6ICdNaXh0ZScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBudWxsLFxuICAgICAgICBpbmNsdWRlczogW10sXG4gICAgICAgIGR1cmF0aW9uOiA1MCxcbiAgICAgICAgaW1hZ2U6ICcvaW1hZ2VzL3NlcnZpY2VzL2N1c3RvbWVyMTUuanBnJyxcbiAgICAgICAgY2F0ZWdvcnk6ICdIYWlyIENvbnRvdXJpbmcnXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBuYW1lOiAnTG9uZycsXG4gICAgICAgIHByaWNlOiA5NSxcbiAgICAgICAgcHJpY2VUZXh0OiBudWxsLFxuICAgICAgICBnZW5kZXI6ICdNaXh0ZScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiBudWxsLFxuICAgICAgICBpbmNsdWRlczogW10sXG4gICAgICAgIGR1cmF0aW9uOiA3MCxcbiAgICAgICAgaW1hZ2U6ICcvaW1hZ2VzL3NlcnZpY2VzL2N1c3RvbWVyMTUuanBnJyxcbiAgICAgICAgY2F0ZWdvcnk6ICdIYWlyIENvbnRvdXJpbmcnXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBuYW1lOiAnWEwnLFxuICAgICAgICBwcmljZTogMTA1LFxuICAgICAgICBwcmljZVRleHQ6IG51bGwsXG4gICAgICAgIGdlbmRlcjogJ01peHRlJyxcbiAgICAgICAgZGVzY3JpcHRpb246IG51bGwsXG4gICAgICAgIGluY2x1ZGVzOiBbXSxcbiAgICAgICAgZHVyYXRpb246IDkwLFxuICAgICAgICBpbWFnZTogJy9pbWFnZXMvc2VydmljZXMvY3VzdG9tZXIxNS5qcGcnLFxuICAgICAgICBjYXRlZ29yeTogJ0hhaXIgQ29udG91cmluZydcbiAgICAgIH1cbiAgICBdXG4gIH0sXG4gIHtcbiAgICBuYW1lOiAnVGFyaWZzIGVuZmFudHMnLFxuICAgIGdsb2JhbERlc2NyaXB0aW9uOiAnTGUgdGFyaWYgZW5mYW50IHNcXCdhcHBsaXF1ZSBnw6luw6lyYWxlbWVudCBhdXggZW5mYW50cyBkZSBtb2lucyBkZSAxMiBhbnMsIG9mZnJhbnQgZGVzIHByaXggcsOpZHVpdHMgcG91ciBsZXMgY291cGVzIGV0IGxlcyBzb2lucyBhZGFwdMOpcyDDoCBsZXVycyBiZXNvaW5zIHNww6ljaWZpcXVlcy4gQ2VzIHRhcmlmcyBwZXJtZXR0ZW50IGF1eCBwYXJlbnRzIGRlIGZhaXJlIHByb2ZpdGVyIMOgIGxldXJzIGVuZmFudHMgZGUgc2VydmljZXMgZGUgcXVhbGl0w6kgdG91dCBlbiByZXNwZWN0YW50IGxldXIgYnVkZ2V0LCBhdmVjIGRlcyBwcmVzdGF0aW9ucyBjb27Dp3VlcyBwb3VyIGxlcyBjaGV2ZXV4IGTDqWxpY2F0cyBkZXMgcGx1cyBqZXVuZXMuJyxcbiAgICBpbmNsdWRlczogW1xuICAgICAgJ0RpYWdub3N0aWMgLyBDb25zZWlscycsXG4gICAgICAnU2hhbXBvb2luZyBjb25kaXRpb25uZXInLFxuICAgICAgJ1PDqWNoYWdlIChuYXR1cmVsIG91IGJydXNoaW5nKSdcbiAgICBdLFxuICAgIHNlcnZpY2VzOiBbXG4gICAgICB7XG4gICAgICAgIG5hbWU6IG51bGwsXG4gICAgICAgIHByaWNlOiBudWxsLFxuICAgICAgICBwcmljZVRleHQ6ICcxNSDDoCAyNeKCrCcsXG4gICAgICAgIGdlbmRlcjogJ01peHRlJyxcbiAgICAgICAgZGVzY3JpcHRpb246IG51bGwsXG4gICAgICAgIGluY2x1ZGVzOiBbXSxcbiAgICAgICAgZHVyYXRpb246IG51bGwsXG4gICAgICAgIGltYWdlOiAnL2ltYWdlcy9zZXJ2aWNlcy9jdXN0b21lcjE1LmpwZycsXG4gICAgICAgIGNhdGVnb3J5OiAnQ291cGUnXG4gICAgICB9XG4gICAgXVxuICB9XG5dXG4iXX0=