export const faqList = [
	{
		id: "reservations",
		title: "Rendez-Vous & Réservations",
		questions: [{
			question: "Comment prendre rendez-vous ?",
			answer: "Vous pouvez prendre rendez-vous directement en ligne via le numéro indiqué sur notre site ou par email."
		}, {
			question: "Puis-je prendre rendez-vous par téléphone ou par message ?",
			answer: "Oui, vous pouvez également prendre rendez-vous par téléphone ou par message en utilisant les coordonnées fournies sur notre site."
		}]
	},
	{
		id: "payment",
		title: "Paiement & Acompte",
		questions: [
			{
				question: "Dois-je payer à l'avance ?",
				answer: "Oui. Le paiement à l'avance est requis pour confirmer votre rendez-vous. Le montant de l'acompte sera déduit du total de votre service le jour du rendez-vous et s'élève à 30€."
			},
			{
				question: "Proposez-vous le paiement en plusieurs fois ?",
				answer: "Oui, nous proposons le paiement en 3 fois sans frais pour les services supérieurs à 150€. Veuillez nous contacter pour plus de détails."
			},
			{
				question: "J’ai payé mon acompte, mais je dois annuler. Est-ce remboursable ?",
				answer: "L'acompte n'est généralement pas remboursable en cas d'annulation. Veuillez consulter nos conditions d'annulation pour plus de détails."
			}
		]
	},
	{
		id: "preparation",
		title: "Préparation au rendez-vous",
		questions: [
			{
				question: "Dois-je venir les cheveux lavés ?",
				answer: "Il est préférable de venir les cheveux propres et démêlés pour votre rendez-vous afin de garantir les meilleurs résultats possibles."
			},
			{
				question: "Je ne suis pas sûre de ce que je veux, puis-je venir pour un conseil ?",
				answer: "Oui, vous pouvez venir pour un conseil afin de discuter de vos besoins et de vos préférences avec moi. Le rendez-vous de conseil peut être facturé séparément. Le montant pour une séance de conseil est de 15€."
			},
			{
				question: "Dois-je arriver les cheveux attaché ?",
				answer: "Il est recommandé de ne pas attacher vos cheveux pour votre rendez-vous, afin de permettre une meilleure évaluation de la texture et de la condition de vos cheveux. Cependant, assurez-vous qu'ils soient bien démêlés et propres."
			}
		]
	},
	{
		id: "age-restrictions",
		title: "Conditions d'âge",
		questions: [{
			question: "Prenez-vous les mineur(e)s ?",
			answer: "Les mineur(e)s sont les bienvenu(e)s, mais doivent être accompagné(e)s d’un(e) parent ou tuteur(trice) légal(e) qui devra signer une autorisation parentale avant le début du rendez-vous."
		}]
	},
	{
		id: "values",
		title: "Valeurs & Engagements",
		questions: [{
			question: "Utilisez-vous des produits respectueux de l'environnement ?",
			answer: `L'éco-responsabilité fait partie intégrante de ma façon de travailler. Je sélectionne avec soin des produits capillaires naturels et respectueux de 
        l'environnement — des marques comme Végétalement Provence ou Les Secrets de Loly, reconnues pour leur formulation saine, sans sulfates ni silicones agressifs, 
        et engagées dans une démarche durable. Au-delà des produits, j'applique des pratiques responsables au quotidien : réduction des déchets, utilisation raisonnée 
        de l'eau et choix de marques dont les valeurs environnementales correspondent aux miennes. Prendre soin de tes cheveux ne devrait pas se faire au détriment de la planète.`
		}, {
			question: "Quels shampoings et soins recommandés pour cheveux afros très secs ?",
			answer: `Je recommande d’utiliser des shampoings et soins spécialement formulés pour les cheveux afros très secs, qui contiennent des 
        ingrédients hydratants et nourrissants tels que l’huile de coco, le beurre de karité et l’huile d’argan. Je peux vous conseiller 
        des produits spécifiques lors de votre rendez-vous.`
		}]
	}
];
export function useFaq() {
	return { faqList };
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBV0EsT0FBTyxNQUFNLFVBQXdCO0NBQ25DO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxXQUFXLENBQ1Q7R0FDRSxVQUFVO0dBQ1YsUUFBUTtFQUNWLEdBQ0E7R0FDRSxVQUFVO0dBQ1YsUUFBUTtFQUNWLENBQ0Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxXQUFXO0dBQ1Q7SUFDRSxVQUFVO0lBQ1YsUUFBUTtHQUNWO0dBQ0E7SUFDRSxVQUFVO0lBQ1YsUUFBUTtHQUNWO0dBQ0E7SUFDRSxVQUFVO0lBQ1YsUUFBUTtHQUNWO0VBQ0Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxXQUFXO0dBQ1Q7SUFDRSxVQUFVO0lBQ1YsUUFBUTtHQUNWO0dBQ0E7SUFDRSxVQUFVO0lBQ1YsUUFBUTtHQUNWO0dBQ0E7SUFDRSxVQUFVO0lBQ1YsUUFBUTtHQUNWO0VBQ0Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxXQUFXLENBQ1Q7R0FDRSxVQUFVO0dBQ1YsUUFBUTtFQUNWLENBQ0Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxXQUFXLENBQ1Q7R0FDRSxVQUFVO0dBQ1YsUUFBUTs7OztFQUlWLEdBQ0E7R0FDRSxVQUFVO0dBQ1YsUUFBUTs7O0VBR1YsQ0FDRjtDQUNGO0FBQ0Y7QUFFQSxPQUFPLFNBQVMsU0FBUztDQUN2QixPQUFPLEVBQ0wsUUFDRjtBQUNGIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImZhcS50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgaW50ZXJmYWNlIFF1ZXN0aW9uIHtcbiAgcXVlc3Rpb246IHN0cmluZ1xuICBhbnN3ZXI6IHN0cmluZ1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEZBUVNlY3Rpb24ge1xuICBpZDogc3RyaW5nXG4gIHRpdGxlOiBzdHJpbmdcbiAgcXVlc3Rpb25zOiBRdWVzdGlvbltdXG59XG5cbmV4cG9ydCBjb25zdCBmYXFMaXN0OiBGQVFTZWN0aW9uW10gPSBbXG4gIHtcbiAgICBpZDogJ3Jlc2VydmF0aW9ucycsXG4gICAgdGl0bGU6ICdSZW5kZXotVm91cyAmIFLDqXNlcnZhdGlvbnMnLFxuICAgIHF1ZXN0aW9uczogW1xuICAgICAge1xuICAgICAgICBxdWVzdGlvbjogJ0NvbW1lbnQgcHJlbmRyZSByZW5kZXotdm91cyA/JyxcbiAgICAgICAgYW5zd2VyOiAnVm91cyBwb3V2ZXogcHJlbmRyZSByZW5kZXotdm91cyBkaXJlY3RlbWVudCBlbiBsaWduZSB2aWEgbGUgbnVtw6lybyBpbmRpcXXDqSBzdXIgbm90cmUgc2l0ZSBvdSBwYXIgZW1haWwuJ1xuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgcXVlc3Rpb246ICdQdWlzLWplIHByZW5kcmUgcmVuZGV6LXZvdXMgcGFyIHTDqWzDqXBob25lIG91IHBhciBtZXNzYWdlID8nLFxuICAgICAgICBhbnN3ZXI6ICdPdWksIHZvdXMgcG91dmV6IMOpZ2FsZW1lbnQgcHJlbmRyZSByZW5kZXotdm91cyBwYXIgdMOpbMOpcGhvbmUgb3UgcGFyIG1lc3NhZ2UgZW4gdXRpbGlzYW50IGxlcyBjb29yZG9ubsOpZXMgZm91cm5pZXMgc3VyIG5vdHJlIHNpdGUuJ1xuICAgICAgfVxuICAgIF1cbiAgfSxcbiAge1xuICAgIGlkOiAncGF5bWVudCcsXG4gICAgdGl0bGU6ICdQYWllbWVudCAmIEFjb21wdGUnLFxuICAgIHF1ZXN0aW9uczogW1xuICAgICAge1xuICAgICAgICBxdWVzdGlvbjogJ0RvaXMtamUgcGF5ZXIgw6AgbFxcJ2F2YW5jZSA/JyxcbiAgICAgICAgYW5zd2VyOiAnT3VpLiBMZSBwYWllbWVudCDDoCBsXFwnYXZhbmNlIGVzdCByZXF1aXMgcG91ciBjb25maXJtZXIgdm90cmUgcmVuZGV6LXZvdXMuIExlIG1vbnRhbnQgZGUgbFxcJ2Fjb21wdGUgc2VyYSBkw6lkdWl0IGR1IHRvdGFsIGRlIHZvdHJlIHNlcnZpY2UgbGUgam91ciBkdSByZW5kZXotdm91cyBldCBzXFwnw6lsw6h2ZSDDoCAzMOKCrC4nXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBxdWVzdGlvbjogJ1Byb3Bvc2V6LXZvdXMgbGUgcGFpZW1lbnQgZW4gcGx1c2lldXJzIGZvaXMgPycsXG4gICAgICAgIGFuc3dlcjogJ091aSwgbm91cyBwcm9wb3NvbnMgbGUgcGFpZW1lbnQgZW4gMyBmb2lzIHNhbnMgZnJhaXMgcG91ciBsZXMgc2VydmljZXMgc3Vww6lyaWV1cnMgw6AgMTUw4oKsLiBWZXVpbGxleiBub3VzIGNvbnRhY3RlciBwb3VyIHBsdXMgZGUgZMOpdGFpbHMuJ1xuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgcXVlc3Rpb246ICdK4oCZYWkgcGF5w6kgbW9uIGFjb21wdGUsIG1haXMgamUgZG9pcyBhbm51bGVyLiBFc3QtY2UgcmVtYm91cnNhYmxlID8nLFxuICAgICAgICBhbnN3ZXI6ICdMXFwnYWNvbXB0ZSBuXFwnZXN0IGfDqW7DqXJhbGVtZW50IHBhcyByZW1ib3Vyc2FibGUgZW4gY2FzIGRcXCdhbm51bGF0aW9uLiBWZXVpbGxleiBjb25zdWx0ZXIgbm9zIGNvbmRpdGlvbnMgZFxcJ2FubnVsYXRpb24gcG91ciBwbHVzIGRlIGTDqXRhaWxzLidcbiAgICAgIH1cbiAgICBdXG4gIH0sXG4gIHtcbiAgICBpZDogJ3ByZXBhcmF0aW9uJyxcbiAgICB0aXRsZTogJ1Byw6lwYXJhdGlvbiBhdSByZW5kZXotdm91cycsXG4gICAgcXVlc3Rpb25zOiBbXG4gICAgICB7XG4gICAgICAgIHF1ZXN0aW9uOiAnRG9pcy1qZSB2ZW5pciBsZXMgY2hldmV1eCBsYXbDqXMgPycsXG4gICAgICAgIGFuc3dlcjogJ0lsIGVzdCBwcsOpZsOpcmFibGUgZGUgdmVuaXIgbGVzIGNoZXZldXggcHJvcHJlcyBldCBkw6ltw6psw6lzIHBvdXIgdm90cmUgcmVuZGV6LXZvdXMgYWZpbiBkZSBnYXJhbnRpciBsZXMgbWVpbGxldXJzIHLDqXN1bHRhdHMgcG9zc2libGVzLidcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHF1ZXN0aW9uOiAnSmUgbmUgc3VpcyBwYXMgc8O7cmUgZGUgY2UgcXVlIGplIHZldXgsIHB1aXMtamUgdmVuaXIgcG91ciB1biBjb25zZWlsID8nLFxuICAgICAgICBhbnN3ZXI6ICdPdWksIHZvdXMgcG91dmV6IHZlbmlyIHBvdXIgdW4gY29uc2VpbCBhZmluIGRlIGRpc2N1dGVyIGRlIHZvcyBiZXNvaW5zIGV0IGRlIHZvcyBwcsOpZsOpcmVuY2VzIGF2ZWMgbW9pLiBMZSByZW5kZXotdm91cyBkZSBjb25zZWlsIHBldXQgw6p0cmUgZmFjdHVyw6kgc8OpcGFyw6ltZW50LiBMZSBtb250YW50IHBvdXIgdW5lIHPDqWFuY2UgZGUgY29uc2VpbCBlc3QgZGUgMTXigqwuJ1xuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgcXVlc3Rpb246ICdEb2lzLWplIGFycml2ZXIgbGVzIGNoZXZldXggYXR0YWNow6kgPycsXG4gICAgICAgIGFuc3dlcjogJ0lsIGVzdCByZWNvbW1hbmTDqSBkZSBuZSBwYXMgYXR0YWNoZXIgdm9zIGNoZXZldXggcG91ciB2b3RyZSByZW5kZXotdm91cywgYWZpbiBkZSBwZXJtZXR0cmUgdW5lIG1laWxsZXVyZSDDqXZhbHVhdGlvbiBkZSBsYSB0ZXh0dXJlIGV0IGRlIGxhIGNvbmRpdGlvbiBkZSB2b3MgY2hldmV1eC4gQ2VwZW5kYW50LCBhc3N1cmV6LXZvdXMgcXVcXCdpbHMgc29pZW50IGJpZW4gZMOpbcOqbMOpcyBldCBwcm9wcmVzLidcbiAgICAgIH1cbiAgICBdXG4gIH0sXG4gIHtcbiAgICBpZDogJ2FnZS1yZXN0cmljdGlvbnMnLFxuICAgIHRpdGxlOiAnQ29uZGl0aW9ucyBkXFwnw6JnZScsXG4gICAgcXVlc3Rpb25zOiBbXG4gICAgICB7XG4gICAgICAgIHF1ZXN0aW9uOiAnUHJlbmV6LXZvdXMgbGVzIG1pbmV1cihlKXMgPycsXG4gICAgICAgIGFuc3dlcjogJ0xlcyBtaW5ldXIoZSlzIHNvbnQgbGVzIGJpZW52ZW51KGUpcywgbWFpcyBkb2l2ZW50IMOqdHJlIGFjY29tcGFnbsOpKGUpcyBk4oCZdW4oZSkgcGFyZW50IG91IHR1dGV1cih0cmljZSkgbMOpZ2FsKGUpIHF1aSBkZXZyYSBzaWduZXIgdW5lIGF1dG9yaXNhdGlvbiBwYXJlbnRhbGUgYXZhbnQgbGUgZMOpYnV0IGR1IHJlbmRlei12b3VzLidcbiAgICAgIH1cbiAgICBdXG4gIH0sXG4gIHtcbiAgICBpZDogJ3ZhbHVlcycsXG4gICAgdGl0bGU6ICdWYWxldXJzICYgRW5nYWdlbWVudHMnLFxuICAgIHF1ZXN0aW9uczogW1xuICAgICAge1xuICAgICAgICBxdWVzdGlvbjogJ1V0aWxpc2V6LXZvdXMgZGVzIHByb2R1aXRzIHJlc3BlY3R1ZXV4IGRlIGxcXCdlbnZpcm9ubmVtZW50ID8nLFxuICAgICAgICBhbnN3ZXI6IGBMJ8OpY28tcmVzcG9uc2FiaWxpdMOpIGZhaXQgcGFydGllIGludMOpZ3JhbnRlIGRlIG1hIGZhw6dvbiBkZSB0cmF2YWlsbGVyLiBKZSBzw6lsZWN0aW9ubmUgYXZlYyBzb2luIGRlcyBwcm9kdWl0cyBjYXBpbGxhaXJlcyBuYXR1cmVscyBldCByZXNwZWN0dWV1eCBkZSBcbiAgICAgICAgbCdlbnZpcm9ubmVtZW50IOKAlCBkZXMgbWFycXVlcyBjb21tZSBWw6lnw6l0YWxlbWVudCBQcm92ZW5jZSBvdSBMZXMgU2VjcmV0cyBkZSBMb2x5LCByZWNvbm51ZXMgcG91ciBsZXVyIGZvcm11bGF0aW9uIHNhaW5lLCBzYW5zIHN1bGZhdGVzIG5pIHNpbGljb25lcyBhZ3Jlc3NpZnMsIFxuICAgICAgICBldCBlbmdhZ8OpZXMgZGFucyB1bmUgZMOpbWFyY2hlIGR1cmFibGUuIEF1LWRlbMOgIGRlcyBwcm9kdWl0cywgaidhcHBsaXF1ZSBkZXMgcHJhdGlxdWVzIHJlc3BvbnNhYmxlcyBhdSBxdW90aWRpZW4gOiByw6lkdWN0aW9uIGRlcyBkw6ljaGV0cywgdXRpbGlzYXRpb24gcmFpc29ubsOpZSBcbiAgICAgICAgZGUgbCdlYXUgZXQgY2hvaXggZGUgbWFycXVlcyBkb250IGxlcyB2YWxldXJzIGVudmlyb25uZW1lbnRhbGVzIGNvcnJlc3BvbmRlbnQgYXV4IG1pZW5uZXMuIFByZW5kcmUgc29pbiBkZSB0ZXMgY2hldmV1eCBuZSBkZXZyYWl0IHBhcyBzZSBmYWlyZSBhdSBkw6l0cmltZW50IGRlIGxhIHBsYW7DqHRlLmBcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHF1ZXN0aW9uOiAnUXVlbHMgc2hhbXBvaW5ncyBldCBzb2lucyByZWNvbW1hbmTDqXMgcG91ciBjaGV2ZXV4IGFmcm9zIHRyw6hzIHNlY3MgPycsXG4gICAgICAgIGFuc3dlcjogYEplIHJlY29tbWFuZGUgZOKAmXV0aWxpc2VyIGRlcyBzaGFtcG9pbmdzIGV0IHNvaW5zIHNww6ljaWFsZW1lbnQgZm9ybXVsw6lzIHBvdXIgbGVzIGNoZXZldXggYWZyb3MgdHLDqHMgc2VjcywgcXVpIGNvbnRpZW5uZW50IGRlcyBcbiAgICAgICAgaW5ncsOpZGllbnRzIGh5ZHJhdGFudHMgZXQgbm91cnJpc3NhbnRzIHRlbHMgcXVlIGzigJlodWlsZSBkZSBjb2NvLCBsZSBiZXVycmUgZGUga2FyaXTDqSBldCBs4oCZaHVpbGUgZOKAmWFyZ2FuLiBKZSBwZXV4IHZvdXMgY29uc2VpbGxlciBcbiAgICAgICAgZGVzIHByb2R1aXRzIHNww6ljaWZpcXVlcyBsb3JzIGRlIHZvdHJlIHJlbmRlei12b3VzLmBcbiAgICAgIH1cbiAgICBdXG4gIH1cbl1cblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUZhcSgpIHtcbiAgcmV0dXJuIHtcbiAgICBmYXFMaXN0XG4gIH1cbn1cbiJdfQ==