import { defineNuxtPlugin } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/nuxt.js?v=7e73afc2";
import { useHead as _$__useHead } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/composables/head.js?v=7e73afc2";;import { __nuxtTimelineWrap } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+devtools@3.4.1_db0@0.3.4_better-sqlite3@13.0.2_drizzle-orm@0.45.2_@opentelemetry+_0e55243a794e05cb19a29a0506aae086/node_modules/@nuxt/devtools/dist/runtime/function-metrics-helpers.js?v=7e73afc2";const useHead = __nuxtTimelineWrap("useHead", _$__useHead);
export default defineNuxtPlugin({
	name: "pinterest",
	parallel: true,
	setup() {
		useHead({ meta: [{
			name: "p:domain_verify",
			content: "4fe3486c456fa2f68f9f31cab6823a51",
			// @ts-expect-error Key is not in type
			crossorigin: "anonymous"
		}] });
	}
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7QUFBQSxlQUFlLGlCQUFpQjtDQUM5QixNQUFNO0NBQ04sVUFBVTtDQUNWLFFBQVE7RUFDTixRQUFRLEVBQ04sTUFBTSxDQUNKO0dBQ0UsTUFBTTtHQUNOLFNBQVM7O0dBRVQsYUFBYTtFQUNmLENBQ0YsRUFDRixDQUFDO0NBQ0g7QUFDRixDQUFDIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJwaW50ZXJlc3QuY2xpZW50LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGRlZmluZU51eHRQbHVnaW4oe1xuICBuYW1lOiAncGludGVyZXN0JyxcbiAgcGFyYWxsZWw6IHRydWUsXG4gIHNldHVwKCkge1xuICAgIHVzZUhlYWQoe1xuICAgICAgbWV0YTogW1xuICAgICAgICB7XG4gICAgICAgICAgbmFtZTogJ3A6ZG9tYWluX3ZlcmlmeScsXG4gICAgICAgICAgY29udGVudDogJzRmZTM0ODZjNDU2ZmEyZjY4ZjlmMzFjYWI2ODIzYTUxJyxcbiAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yIEtleSBpcyBub3QgaW4gdHlwZVxuICAgICAgICAgIGNyb3Nzb3JpZ2luOiAnYW5vbnltb3VzJ1xuICAgICAgICB9XG4gICAgICBdXG4gICAgfSlcbiAgfVxufSlcbiJdLCJmaWxlIjoiL1ZvbHVtZXMvQ29kaW5nL1Byb2plY3RzL1dlYnNpdGVzL2luZWlhaC9mcm9udGVuZC9hcHAvcGx1Z2lucy9waW50ZXJlc3QuY2xpZW50LnRzIn0=