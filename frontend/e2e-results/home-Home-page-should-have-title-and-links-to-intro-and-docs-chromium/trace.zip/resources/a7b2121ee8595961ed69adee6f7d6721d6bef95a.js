/*!
* vue-router v5.2.0
* (c) 2026 Eduardo San Martin Morote
* @license MIT
*/
import { C as isSameRouteLocation, E as parseURL, F as isBrowser, M as encodeHash, N as encodeParam, O as stringifyURL, S as START_LOCATION_NORMALIZED, T as isSameRouteRecord, _ as saveScrollPosition, a as loadRouteLocation, b as normalizeBase, c as useCallbacks, d as stringifyQuery, f as isRouteLocation, g as getScrollKey, h as getSavedScrollPosition, i as guardToPromiseFn, j as decode, k as stripBase, l as normalizeQuery, m as computeScrollPosition, n as extractChangingRecords, o as onBeforeRouteLeave, p as isRouteName, r as extractComponentsGuards, s as onBeforeRouteUpdate, t as addDevtools, u as parseQuery, v as scrollToPosition, w as isSameRouteLocationParams, y as createHref } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue-router@5.2.0_@vue+compiler-sfc@3.5.40_esbuild@0.28.1_pinia@4.0.2_@vue+devtools-api@_da13f14f8d547f2ae66d0a1be426cab8/node_modules/vue-router/dist/devtools-Bpr7ZAVB.js?v=7e73afc2";
import { a as routerKey, c as diagnostics, d as isNavigationFailure, f as applyToParams, h as isArray, i as routeLocationKey, l as NavigationFailureType, n as useRouter, o as routerViewLocationKey, p as assign, r as matchedRouteKey, s as viewDepthKey, t as useRoute, u as createRouterError, v as mergeOptions, y as noop } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue-router@5.2.0_@vue+compiler-sfc@3.5.40_esbuild@0.28.1_pinia@4.0.2_@vue+devtools-api@_da13f14f8d547f2ae66d0a1be426cab8/node_modules/vue-router/dist/useApi-CROJJdhE.js?v=7e73afc2";
import { computed, defineComponent, getCurrentInstance, h, inject, nextTick, provide, reactive, ref, shallowReactive, shallowRef, unref, watch, watchEffect } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
//#region src/history/html5.ts
let createBaseLocation = () => location.protocol + "//" + location.host;
/**
* Creates a normalized history location from a window.location object
* @param base - The base path
* @param location - The window.location object
*/
function createCurrentLocation(base, location) {
	const { pathname, search, hash } = location;
	const hashPos = base.indexOf("#");
	if (hashPos > -1) {
		let slicePos = hash.includes(base.slice(hashPos)) ? base.slice(hashPos).length : 1;
		let pathFromHash = hash.slice(slicePos);
		if (pathFromHash[0] !== "/") pathFromHash = "/" + pathFromHash;
		return stripBase(pathFromHash, "");
	}
	return stripBase(pathname, base) + search + hash;
}
function useHistoryListeners(base, historyState, currentLocation, replace) {
	let listeners = [];
	let teardowns = [];
	let pauseState = null;
	const popStateHandler = ({ state }) => {
		const to = createCurrentLocation(base, location);
		const from = currentLocation.value;
		const fromState = historyState.value;
		let delta = 0;
		if (state) {
			currentLocation.value = to;
			historyState.value = state;
			if (pauseState && pauseState === from) {
				pauseState = null;
				return;
			}
			delta = fromState ? state.position - fromState.position : 0;
		} else replace(to);
		listeners.forEach((listener) => {
			listener(currentLocation.value, from, {
				delta,
				type: "pop",
				direction: delta ? delta > 0 ? "forward" : "back" : ""
			});
		});
	};
	function pauseListeners() {
		pauseState = currentLocation.value;
	}
	function listen(callback) {
		listeners.push(callback);
		const teardown = () => {
			const index = listeners.indexOf(callback);
			if (index > -1) listeners.splice(index, 1);
		};
		teardowns.push(teardown);
		return teardown;
	}
	function beforeUnloadListener() {
		if (document.visibilityState === "hidden") {
			const { history } = window;
			if (!history.state) return;
			history.replaceState(assign({}, history.state, { scroll: computeScrollPosition() }), "");
		}
	}
	function destroy() {
		for (const teardown of teardowns) teardown();
		teardowns = [];
		window.removeEventListener("popstate", popStateHandler);
		window.removeEventListener("pagehide", beforeUnloadListener);
		document.removeEventListener("visibilitychange", beforeUnloadListener);
	}
	window.addEventListener("popstate", popStateHandler);
	window.addEventListener("pagehide", beforeUnloadListener);
	document.addEventListener("visibilitychange", beforeUnloadListener);
	return {
		pauseListeners,
		listen,
		destroy
	};
}
/**
* Creates a state object
*/
function buildState(back, current, forward, replaced = false, computeScroll = false) {
	return {
		back,
		current,
		forward,
		replaced,
		position: window.history.length,
		scroll: computeScroll ? computeScrollPosition() : null
	};
}
function useHistoryStateNavigation(base) {
	const { history, location } = window;
	const currentLocation = { value: createCurrentLocation(base, location) };
	const historyState = { value: history.state };
	if (!historyState.value) changeLocation(currentLocation.value, {
		back: null,
		current: currentLocation.value,
		forward: null,
		position: history.length - 1,
		replaced: true,
		scroll: null
	}, true);
	function changeLocation(to, state, replace) {
		/**
		* if a base tag is provided, and we are on a normal domain, we have to
		* respect the provided `base` attribute because pushState() will use it and
		* potentially erase anything before the `#` like at
		* https://github.com/vuejs/router/issues/685 where a base of
		* `/folder/#` but a base of `/` would erase the `/folder/` section. If
		* there is no host, the `<base>` tag makes no sense and if there isn't a
		* base tag we can just use everything after the `#`.
		*/
		const hashIndex = base.indexOf("#");
		const url = hashIndex > -1 ? (location.host && document.querySelector("base") ? base : base.slice(hashIndex)) + to : createBaseLocation() + base + to;
		try {
			history[replace ? "replaceState" : "pushState"](state, "", url);
			historyState.value = state;
		} catch (err) {
			if ("development" !== "production") diagnostics.VUE_ROUTER_R0120({ cause: err });
			else console.error(err);
			location[replace ? "replace" : "assign"](url);
		}
	}
	function replace(to, data) {
		changeLocation(to, assign({}, history.state, buildState(historyState.value.back, to, historyState.value.forward, true), data, { position: historyState.value.position }), true);
		currentLocation.value = to;
	}
	function push(to, data) {
		const currentState = assign({}, historyState.value, history.state, {
			forward: to,
			scroll: computeScrollPosition()
		});
		if ("development" !== "production" && !history.state) diagnostics.VUE_ROUTER_R0121();
		changeLocation(currentState.current, currentState, true);
		changeLocation(to, assign({}, buildState(currentLocation.value, to, null), { position: currentState.position + 1 }, data), false);
		currentLocation.value = to;
	}
	return {
		location: currentLocation,
		state: historyState,
		push,
		replace
	};
}
/**
* Creates an HTML5 history. Most common history for single page applications.
*
* @param base -
*/
function createWebHistory(base) {
	base = normalizeBase(base);
	const historyNavigation = useHistoryStateNavigation(base);
	const historyListeners = useHistoryListeners(base, historyNavigation.state, historyNavigation.location, historyNavigation.replace);
	function go(delta, triggerListeners = true) {
		if (!triggerListeners) historyListeners.pauseListeners();
		history.go(delta);
	}
	const routerHistory = assign({
		location: "",
		base,
		go,
		createHref: createHref.bind(null, base)
	}, historyNavigation, historyListeners);
	Object.defineProperty(routerHistory, "location", {
		enumerable: true,
		get: () => historyNavigation.location.value
	});
	Object.defineProperty(routerHistory, "state", {
		enumerable: true,
		get: () => historyNavigation.state.value
	});
	return routerHistory;
}
//#endregion
//#region src/history/hash.ts
/**
* Creates a hash history. Useful for web applications with no host (e.g. `file://`) or when configuring a server to
* handle any URL is not possible.
*
* @param base - optional base to provide. Defaults to `location.pathname + location.search` If there is a `<base>` tag
* in the `head`, its value will be ignored in favor of this parameter **but note it affects all the history.pushState()
* calls**, meaning that if you use a `<base>` tag, it's `href` value **has to match this parameter** (ignoring anything
* after the `#`).
*
* @example
* ```js
* // at https://example.com/folder
* createWebHashHistory() // gives a url of `https://example.com/folder#`
* createWebHashHistory('/folder/') // gives a url of `https://example.com/folder/#`
* // if the `#` is provided in the base, it won't be added by `createWebHashHistory`
* createWebHashHistory('/folder/#/app/') // gives a url of `https://example.com/folder/#/app/`
* // you should avoid doing this because it changes the original url and breaks copying urls
* createWebHashHistory('/other-folder/') // gives a url of `https://example.com/other-folder/#`
*
* // at file:///usr/etc/folder/index.html
* // for locations with no `host`, the base is ignored
* createWebHashHistory('/iAmIgnored') // gives a url of `file:///usr/etc/folder/index.html#`
* ```
*/
function createWebHashHistory(base) {
	base = location.host ? base || location.pathname + location.search : "";
	if (!base.includes("#")) base += "#";
	if ("development" !== "production" && !base.endsWith("#/") && !base.endsWith("#")) diagnostics.VUE_ROUTER_R0110({
		base,
		suggestion: base.replace(/#.*$/, "#")
	});
	return createWebHistory(base);
}
//#endregion
//#region src/history/memory.ts
/**
* Creates an in-memory based history. The main purpose of this history is to handle SSR. It starts in a special location that is nowhere.
* It's up to the user to replace that location with the starter location by either calling `router.push` or `router.replace`.
*
* @param base - Base applied to all urls, defaults to '/'
* @returns a history object that can be passed to the router constructor
*/
function createMemoryHistory(base = "") {
	let listeners = [];
	let queue = [["", {}]];
	let position = 0;
	base = normalizeBase(base);
	function setLocation(location, state = {}) {
		position++;
		if (position !== queue.length) queue.splice(position);
		queue.push([location, state]);
	}
	function triggerListeners(to, from, { direction, delta }) {
		const info = {
			direction,
			delta,
			type: "pop"
		};
		for (const callback of listeners) callback(to, from, info);
	}
	const routerHistory = {
		location: "",
		state: {},
		base,
		createHref: createHref.bind(null, base),
		replace(to, state) {
			queue.splice(position--, 1);
			setLocation(to, state);
		},
		push(to, state) {
			setLocation(to, state);
		},
		listen(callback) {
			listeners.push(callback);
			return () => {
				const index = listeners.indexOf(callback);
				if (index > -1) listeners.splice(index, 1);
			};
		},
		destroy() {
			listeners = [];
			queue = [["", {}]];
			position = 0;
		},
		go(delta, shouldTrigger = true) {
			const from = this.location;
			const direction = delta < 0 ? "back" : "forward";
			position = Math.max(0, Math.min(position + delta, queue.length - 1));
			if (shouldTrigger) triggerListeners(this.location, from, {
				direction,
				delta
			});
		}
	};
	Object.defineProperty(routerHistory, "location", {
		enumerable: true,
		get: () => queue[position][0]
	});
	Object.defineProperty(routerHistory, "state", {
		enumerable: true,
		get: () => queue[position][1]
	});
	return routerHistory;
}
//#endregion
//#region src/matcher/pathTokenizer.ts
const ROOT_TOKEN = {
	type: 0,
	value: ""
};
const VALID_PARAM_RE = /[a-zA-Z0-9_]/;
function tokenizePath(path) {
	if (!path) return [[]];
	if (path === "/") return [[ROOT_TOKEN]];
	if (!path.startsWith("/")) throw new Error("development" !== "production" ? `Route paths should start with a "/": "${path}" should be "/${path}".` : `Invalid path "${path}"`);
	function crash(message) {
		throw new Error(`ERR (${state})/"${buffer}": ${message}`);
	}
	let state = 0;
	let previousState = state;
	const tokens = [];
	let segment;
	function finalizeSegment() {
		if (segment) tokens.push(segment);
		segment = [];
	}
	let i = 0;
	let char;
	let buffer = "";
	let customRe = "";
	function consumeBuffer() {
		if (!buffer) return;
		if (state === 0) segment.push({
			type: 0,
			value: buffer
		});
		else if (state === 1 || state === 2 || state === 3) {
			if (segment.length > 1 && (char === "*" || char === "+")) crash(`A repeatable param (${buffer}) must be alone in its segment. eg: '/:ids+.`);
			segment.push({
				type: 1,
				value: buffer,
				regexp: customRe,
				repeatable: char === "*" || char === "+",
				optional: char === "*" || char === "?"
			});
		} else crash("Invalid state to consume buffer");
		buffer = "";
	}
	function addCharToBuffer() {
		buffer += char;
	}
	while (i < path.length) {
		char = path[i++];
		switch (state) {
			case 0:
				if (char === "\\") {
					previousState = state;
					state = 4;
				} else if (char === "/") {
					if (buffer) consumeBuffer();
					finalizeSegment();
				} else if (char === ":") {
					consumeBuffer();
					state = 1;
				} else addCharToBuffer();
				break;
			case 4:
				addCharToBuffer();
				state = previousState;
				break;
			case 1:
				if (char === "(") state = 2;
				else if (VALID_PARAM_RE.test(char)) addCharToBuffer();
				else {
					consumeBuffer();
					state = 0;
					if (char !== "*" && char !== "?" && char !== "+") i--;
				}
				break;
			case 2:
				if (char === ")") if (customRe[customRe.length - 1] == "\\") customRe = customRe.slice(0, -1) + char;
				else state = 3;
				else customRe += char;
				break;
			case 3:
				consumeBuffer();
				state = 0;
				if (char !== "*" && char !== "?" && char !== "+") i--;
				customRe = "";
				break;
			default:
				crash("Unknown state");
				break;
		}
	}
	if (state === 2) crash(`Unfinished custom RegExp for param "${buffer}"`);
	consumeBuffer();
	finalizeSegment();
	return tokens;
}
//#endregion
//#region src/matcher/pathParserRanker.ts
const BASE_PARAM_PATTERN = "[^/]+?";
const BASE_PATH_PARSER_OPTIONS = {
	sensitive: false,
	strict: false,
	start: true,
	end: true
};
const REGEX_CHARS_RE = /[.+*?^${}()[\]/\\]/g;
/**
* Creates a path parser from an array of Segments (a segment is an array of Tokens)
*
* @param segments - array of segments returned by tokenizePath
* @param extraOptions - optional options for the regexp
* @returns a PathParser
*/
function tokensToParser(segments, extraOptions) {
	const options = assign({}, BASE_PATH_PARSER_OPTIONS, extraOptions);
	const score = [];
	let pattern = options.start ? "^" : "";
	const keys = [];
	for (const segment of segments) {
		const segmentScores = segment.length ? [] : [90];
		if (options.strict && !segment.length) pattern += "/";
		for (let tokenIndex = 0; tokenIndex < segment.length; tokenIndex++) {
			const token = segment[tokenIndex];
			let subSegmentScore = 40 + (options.sensitive ? .25 : 0);
			if (token.type === 0) {
				if (!tokenIndex) pattern += "/";
				pattern += token.value.replace(REGEX_CHARS_RE, "\\$&");
				subSegmentScore += 40;
			} else if (token.type === 1) {
				const { value, repeatable, optional, regexp } = token;
				keys.push({
					name: value,
					repeatable,
					optional
				});
				const re = regexp ? regexp : BASE_PARAM_PATTERN;
				if (re !== BASE_PARAM_PATTERN) {
					subSegmentScore += 10;
					try {
						new RegExp(`(${re})`);
					} catch (err) {
						throw new Error(`Invalid custom RegExp for param "${value}" (${re}): ` + err.message);
					}
				}
				let subPattern = repeatable ? `((?:${re})(?:/(?:${re}))*)` : `(${re})`;
				if (!tokenIndex) subPattern = optional && segment.length < 2 ? `(?:/${subPattern})` : "/" + subPattern;
				if (optional) subPattern += "?";
				pattern += subPattern;
				subSegmentScore += 20;
				if (optional) subSegmentScore += -8;
				if (repeatable) subSegmentScore += -20;
				if (re === ".*") subSegmentScore += -50;
			}
			segmentScores.push(subSegmentScore);
		}
		score.push(segmentScores);
	}
	if (options.strict && options.end) {
		const i = score.length - 1;
		score[i][score[i].length - 1] += .7000000000000001;
	}
	if (!options.strict) pattern += "/?";
	if (options.end) pattern += "$";
	else if (options.strict && !pattern.endsWith("/")) pattern += "(?:/|$)";
	const re = new RegExp(pattern, options.sensitive ? "" : "i");
	function parse(path) {
		const match = path.match(re);
		const params = {};
		if (!match) return null;
		for (let i = 1; i < match.length; i++) {
			const value = match[i] || "";
			const key = keys[i - 1];
			params[key.name] = value && key.repeatable ? value.split("/") : value;
		}
		return params;
	}
	function stringify(params) {
		let path = "";
		let avoidDuplicatedSlash = false;
		for (const segment of segments) {
			if (!avoidDuplicatedSlash || !path.endsWith("/")) path += "/";
			avoidDuplicatedSlash = false;
			for (const token of segment) if (token.type === 0) path += token.value;
			else if (token.type === 1) {
				const { value, repeatable, optional } = token;
				const param = value in params ? params[value] : "";
				if (isArray(param) && !repeatable) throw new Error(`Provided param "${value}" is an array but it is not repeatable (* or + modifiers)`);
				const text = isArray(param) ? param.join("/") : param;
				if (!text) if (optional) {
					if (segment.length < 2) if (path.endsWith("/")) path = path.slice(0, -1);
					else avoidDuplicatedSlash = true;
				} else throw new Error(`Missing required param "${value}"`);
				path += text;
			}
		}
		return path || "/";
	}
	return {
		re,
		score,
		keys,
		parse,
		stringify
	};
}
/**
* Compares an array of numbers as used in PathParser.score and returns a
* number. This function can be used to `sort` an array
*
* @param a - first array of numbers
* @param b - second array of numbers
* @returns 0 if both are equal, < 0 if a should be sorted first, > 0 if b
* should be sorted first
*/
function compareScoreArray(a, b) {
	let i = 0;
	while (i < a.length && i < b.length) {
		const diff = b[i] - a[i];
		if (diff) return diff;
		i++;
	}
	if (a.length < b.length) return a.length === 1 && a[0] === 80 ? -1 : 1;
	else if (a.length > b.length) return b.length === 1 && b[0] === 80 ? 1 : -1;
	return 0;
}
/**
* Compare function that can be used with `sort` to sort an array of PathParser
*
* @param a - first PathParser
* @param b - second PathParser
* @returns 0 if both are equal, < 0 if a should be sorted first, > 0 if b
*/
function comparePathParserScore(a, b) {
	let i = 0;
	const aScore = a.score;
	const bScore = b.score;
	while (i < aScore.length && i < bScore.length) {
		const comp = compareScoreArray(aScore[i], bScore[i]);
		if (comp) return comp;
		i++;
	}
	if (Math.abs(bScore.length - aScore.length) === 1) {
		if (isLastScoreNegative(aScore)) return 1;
		if (isLastScoreNegative(bScore)) return -1;
	}
	return bScore.length - aScore.length;
}
/**
* This allows detecting splats at the end of a path: /home/:id(.*)*
*
* @param score - score to check
* @returns true if the last entry is negative
*/
function isLastScoreNegative(score) {
	const last = score[score.length - 1];
	return score.length > 0 && last[last.length - 1] < 0;
}
const PATH_PARSER_OPTIONS_DEFAULTS = {
	strict: false,
	end: true,
	sensitive: false
};
//#endregion
//#region src/matcher/pathMatcher.ts
function createRouteRecordMatcher(record, parent, options) {
	const parser = tokensToParser(tokenizePath(record.path), options);
	if ("development" !== "production") {
		const existingKeys = /* @__PURE__ */ new Set();
		for (const key of parser.keys) {
			if (existingKeys.has(key.name)) diagnostics.VUE_ROUTER_R0090({
				name: key.name,
				path: record.path
			});
			existingKeys.add(key.name);
		}
	}
	const matcher = assign(parser, {
		record,
		parent,
		children: [],
		alias: []
	});
	if (parent) {
		if (!matcher.record.aliasOf === !parent.record.aliasOf) parent.children.push(matcher);
	}
	return matcher;
}
//#endregion
//#region src/matcher/index.ts
/**
* Creates a Router Matcher.
*
* @internal
* @param routes - array of initial routes
* @param globalOptions - global route options
*/
function createRouterMatcher(routes, globalOptions) {
	const matchers = [];
	const matcherMap = /* @__PURE__ */ new Map();
	globalOptions = mergeOptions(PATH_PARSER_OPTIONS_DEFAULTS, globalOptions);
	function getRecordMatcher(name) {
		return matcherMap.get(name);
	}
	function addRoute(record, parent, originalRecord) {
		const isRootAdd = !originalRecord;
		const mainNormalizedRecord = normalizeRouteRecord(record);
		if ("development" !== "production") checkChildMissingNameWithEmptyPath(mainNormalizedRecord, parent);
		mainNormalizedRecord.aliasOf = originalRecord && originalRecord.record;
		const options = mergeOptions(globalOptions, record);
		const normalizedRecords = [mainNormalizedRecord];
		if ("alias" in record) {
			const aliases = typeof record.alias === "string" ? [record.alias] : record.alias;
			for (const alias of aliases) normalizedRecords.push(normalizeRouteRecord(assign({}, mainNormalizedRecord, {
				components: originalRecord ? originalRecord.record.components : mainNormalizedRecord.components,
				path: alias,
				aliasOf: originalRecord ? originalRecord.record : mainNormalizedRecord
			})));
		}
		let matcher;
		let originalMatcher;
		for (const normalizedRecord of normalizedRecords) {
			const { path } = normalizedRecord;
			if (parent && path[0] !== "/") {
				const parentPath = parent.record.path;
				const connectingSlash = parentPath[parentPath.length - 1] === "/" ? "" : "/";
				normalizedRecord.path = parent.record.path + (path && connectingSlash + path);
			}
			if ("development" !== "production" && normalizedRecord.path === "*") throw new Error("Catch all routes (\"*\") must now be defined using a param with a custom regexp.\nSee more at https://router.vuejs.org/guide/migration/#Removed-star-or-catch-all-routes.");
			matcher = createRouteRecordMatcher(normalizedRecord, parent, options);
			if ("development" !== "production" && parent && path[0] === "/") checkMissingParamsInAbsolutePath(matcher, parent);
			if (originalRecord) {
				originalRecord.alias.push(matcher);
				if ("development" !== "production") checkSameParams(originalRecord, matcher);
			} else {
				originalMatcher = originalMatcher || matcher;
				if (originalMatcher !== matcher) originalMatcher.alias.push(matcher);
				if (isRootAdd && record.name && !isAliasRecord(matcher)) {
					if ("development" !== "production") checkSameNameAsAncestor(record, parent);
					removeRoute(record.name);
				}
			}
			if (isMatchable(matcher)) insertMatcher(matcher);
			if (mainNormalizedRecord.children) {
				const children = mainNormalizedRecord.children;
				for (let i = 0; i < children.length; i++) addRoute(children[i], matcher, originalRecord && originalRecord.children[i]);
			}
			originalRecord = originalRecord || matcher;
		}
		return originalMatcher ? () => {
			removeRoute(originalMatcher);
		} : noop;
	}
	function removeRoute(matcherRef) {
		if (isRouteName(matcherRef)) {
			const matcher = matcherMap.get(matcherRef);
			if (matcher) {
				matcherMap.delete(matcherRef);
				matchers.splice(matchers.indexOf(matcher), 1);
				matcher.children.forEach(removeRoute);
				matcher.alias.forEach(removeRoute);
			}
		} else {
			const index = matchers.indexOf(matcherRef);
			if (index > -1) {
				matchers.splice(index, 1);
				if (matcherRef.record.name) matcherMap.delete(matcherRef.record.name);
				matcherRef.children.forEach(removeRoute);
				matcherRef.alias.forEach(removeRoute);
			}
		}
	}
	function getRoutes() {
		return matchers;
	}
	function insertMatcher(matcher) {
		const index = findInsertionIndex(matcher, matchers);
		matchers.splice(index, 0, matcher);
		if (matcher.record.name && !isAliasRecord(matcher)) matcherMap.set(matcher.record.name, matcher);
	}
	function resolve(location, currentLocation) {
		let matcher;
		let params = {};
		let path;
		let name;
		if ("name" in location && location.name) {
			matcher = matcherMap.get(location.name);
			if (!matcher) throw createRouterError(1, { location });
			if ("development" !== "production") {
				const invalidParams = Object.keys(location.params || {}).filter((paramName) => !matcher.keys.find((k) => k.name === paramName));
				if (invalidParams.length) {
					const isInherited = !matcher.keys.length && invalidParams.some((name) => name in currentLocation.params);
					diagnostics.VUE_ROUTER_R0100({
						params: invalidParams.join("\", \""),
						inherited: isInherited ? ` If you are using a catch-all route with a named redirect, pass an empty \`params\` object: \`redirect: { name: '...', params: {} }\`.` : ""
					});
				}
			}
			name = matcher.record.name;
			params = assign(pickParams(currentLocation.params, matcher.keys.filter((k) => !k.optional).concat(matcher.parent ? matcher.parent.keys.filter((k) => k.optional) : []).map((k) => k.name)), location.params && pickParams(location.params, matcher.keys.map((k) => k.name)));
			path = matcher.stringify(params);
		} else if (location.path != null) {
			path = location.path;
			if ("development" !== "production" && !path.startsWith("/")) diagnostics.VUE_ROUTER_R0101({ path });
			matcher = matchers.find((m) => m.re.test(path));
			if (matcher) {
				params = matcher.parse(path);
				name = matcher.record.name;
				matcher.keys.forEach((key) => {
					if (key.optional && !params[key.name]) delete params[key.name];
				});
			}
		} else {
			matcher = currentLocation.name ? matcherMap.get(currentLocation.name) : matchers.find((m) => m.re.test(currentLocation.path));
			if (!matcher) throw createRouterError(1, {
				location,
				currentLocation
			});
			name = matcher.record.name;
			params = assign({}, currentLocation.params, location.params);
			path = matcher.stringify(params);
		}
		const matched = [];
		let parentMatcher = matcher;
		while (parentMatcher) {
			matched.unshift(parentMatcher.record);
			parentMatcher = parentMatcher.parent;
		}
		return {
			name,
			path,
			params,
			matched,
			meta: mergeMetaFields(matched)
		};
	}
	routes.forEach((route) => addRoute(route));
	function clearRoutes() {
		matchers.length = 0;
		matcherMap.clear();
	}
	return {
		addRoute,
		resolve,
		removeRoute,
		clearRoutes,
		getRoutes,
		getRecordMatcher
	};
}
/**
* Picks an object param to contain only specified keys.
*
* @param params - params object to pick from
* @param keys - keys to pick
*/
function pickParams(params, keys) {
	const newParams = {};
	for (const key of keys) if (key in params) newParams[key] = params[key];
	return newParams;
}
/**
* Normalizes a RouteRecordRaw. Creates a copy
*
* @param record
* @returns the normalized version
*/
function normalizeRouteRecord(record) {
	const normalized = {
		path: record.path,
		redirect: record.redirect,
		name: record.name,
		meta: record.meta || {},
		aliasOf: record.aliasOf,
		beforeEnter: record.beforeEnter,
		props: normalizeRecordProps(record),
		children: record.children || [],
		instances: {},
		leaveGuards: /* @__PURE__ */ new Set(),
		updateGuards: /* @__PURE__ */ new Set(),
		enterCallbacks: {},
		components: "components" in record ? record.components || null : record.component && { default: record.component }
	};
	Object.defineProperty(normalized, "mods", { value: {} });
	return normalized;
}
/**
* Normalize the optional `props` in a record to always be an object similar to
* components. Also accept a boolean for components.
* @param record
*/
function normalizeRecordProps(record) {
	const propsObject = {};
	const props = record.props || false;
	if ("component" in record) propsObject.default = props;
	else for (const name in record.components) propsObject[name] = typeof props === "object" ? props[name] : props;
	return propsObject;
}
/**
* Checks if a record or any of its parent is an alias
* @param record
*/
function isAliasRecord(record) {
	while (record) {
		if (record.record.aliasOf) return true;
		record = record.parent;
	}
	return false;
}
/**
* Merge meta fields of an array of records
*
* @param matched - array of matched records
*/
function mergeMetaFields(matched) {
	return matched.reduce((meta, record) => assign(meta, record.meta), {});
}
function isSameParam(a, b) {
	return a.name === b.name && a.optional === b.optional && a.repeatable === b.repeatable;
}
/**
* Check if a path and its alias have the same required params
*
* @param a - original record
* @param b - alias record
*/
function checkSameParams(a, b) {
	for (const key of a.keys) if (!key.optional && !b.keys.find(isSameParam.bind(null, key))) {
		diagnostics.VUE_ROUTER_R0102({
			alias: b.record.path,
			original: a.record.path,
			name: key.name
		});
		return;
	}
	for (const key of b.keys) if (!key.optional && !a.keys.find(isSameParam.bind(null, key))) {
		diagnostics.VUE_ROUTER_R0102({
			alias: b.record.path,
			original: a.record.path,
			name: key.name
		});
		return;
	}
}
/**
* A route with a name and a child with an empty path without a name should warn when adding the route
*
* @param mainNormalizedRecord - RouteRecordNormalized
* @param parent - RouteRecordMatcher
*/
function checkChildMissingNameWithEmptyPath(mainNormalizedRecord, parent) {
	if (parent && parent.record.name && !mainNormalizedRecord.name && !mainNormalizedRecord.path && mainNormalizedRecord.children.length === 0) diagnostics.VUE_ROUTER_R0103({ name: String(parent.record.name) });
}
function checkSameNameAsAncestor(record, parent) {
	for (let ancestor = parent; ancestor; ancestor = ancestor.parent) if (ancestor.record.name === record.name) throw new Error(`A route named "${String(record.name)}" has been added as a ${parent === ancestor ? "child" : "descendant"} of a route with the same name. Route names must be unique and a nested route cannot use the same name as an ancestor.`);
}
function checkMissingParamsInAbsolutePath(record, parent) {
	for (const key of parent.keys) if (!record.keys.find(isSameParam.bind(null, key))) {
		diagnostics.VUE_ROUTER_R0104({
			path: record.record.path,
			name: key.name,
			parent: parent.record.path
		});
		return;
	}
}
/**
* Performs a binary search to find the correct insertion index for a new matcher.
*
* Matchers are primarily sorted by their score. If scores are tied then we also consider parent/child relationships,
* with descendants coming before ancestors. If there's still a tie, new routes are inserted after existing routes.
*
* @param matcher - new matcher to be inserted
* @param matchers - existing matchers
*/
function findInsertionIndex(matcher, matchers) {
	let lower = 0;
	let upper = matchers.length;
	while (lower !== upper) {
		const mid = lower + upper >> 1;
		if (comparePathParserScore(matcher, matchers[mid]) < 0) upper = mid;
		else lower = mid + 1;
	}
	const insertionAncestor = getInsertionAncestor(matcher);
	if (insertionAncestor) {
		upper = matchers.lastIndexOf(insertionAncestor, upper - 1);
		if ("development" !== "production" && upper < 0) diagnostics.VUE_ROUTER_R0105({
			ancestor: insertionAncestor.record.path,
			record: matcher.record.path
		});
	}
	return upper;
}
function getInsertionAncestor(matcher) {
	let ancestor = matcher;
	while (ancestor = ancestor.parent) if (isMatchable(ancestor) && comparePathParserScore(matcher, ancestor) === 0) return ancestor;
}
/**
* Checks if a matcher can be reachable. This means if it's possible to reach it as a route. For example, routes without
* a component, or name, or redirect, are just used to group other routes.
* @param matcher
* @param matcher.record record of the matcher
* @returns
*/
function isMatchable({ record }) {
	return !!(record.name || record.components && Object.keys(record.components).length || record.redirect);
}
//#endregion
//#region src/RouterLink.ts
/**
* Returns the internal behavior of a {@link RouterLink} without the rendering part.
*
* @param props - a `to` location and an optional `replace` flag
*/
function useLink(props) {
	const router = inject(routerKey);
	const currentRoute = inject(routeLocationKey);
	let hasPrevious = false;
	let previousTo = null;
	const route = computed(() => {
		const to = unref(props.to);
		if ("development" !== "production" && (!hasPrevious || to !== previousTo)) {
			if (!isRouteLocation(to)) diagnostics.VUE_ROUTER_R0050({ to });
			previousTo = to;
			hasPrevious = true;
		}
		return router.resolve(to);
	});
	const activeRecordIndex = computed(() => {
		const { matched } = route.value;
		const { length } = matched;
		const routeMatched = matched[length - 1];
		const currentMatched = currentRoute.matched;
		if (!routeMatched || !currentMatched.length) return -1;
		const index = currentMatched.findIndex(isSameRouteRecord.bind(null, routeMatched));
		if (index > -1) return index;
		const parentRecordPath = getOriginalPath(matched[length - 2]);
		return length > 1 && getOriginalPath(routeMatched) === parentRecordPath && currentMatched[currentMatched.length - 1].path !== parentRecordPath ? currentMatched.findIndex(isSameRouteRecord.bind(null, matched[length - 2])) : index;
	});
	const isActive = computed(() => activeRecordIndex.value > -1 && includesParams(currentRoute.params, route.value.params));
	const isExactActive = computed(() => activeRecordIndex.value > -1 && activeRecordIndex.value === currentRoute.matched.length - 1 && isSameRouteLocationParams(currentRoute.params, route.value.params));
	function navigate(e = {}) {
		if (guardEvent(e)) {
			const p = router[unref(props.replace) ? "replace" : "push"](unref(props.to)).catch(noop);
			if (props.viewTransition && typeof document !== "undefined" && "startViewTransition" in document) document.startViewTransition(() => p);
			return p;
		}
		return Promise.resolve();
	}
	if (("development" !== "production" || __VUE_PROD_DEVTOOLS__) && isBrowser) {
		const instance = getCurrentInstance();
		if (instance) {
			const linkContextDevtools = {
				route: route.value,
				isActive: isActive.value,
				isExactActive: isExactActive.value,
				error: null
			};
			instance.__vrl_devtools = instance.__vrl_devtools || [];
			instance.__vrl_devtools.push(linkContextDevtools);
			watchEffect(() => {
				linkContextDevtools.route = route.value;
				linkContextDevtools.isActive = isActive.value;
				linkContextDevtools.isExactActive = isExactActive.value;
				linkContextDevtools.error = isRouteLocation(unref(props.to)) ? null : "Invalid \"to\" value";
			}, { flush: "post" });
		}
	}
	/**
	* NOTE: update {@link _RouterLinkI}'s `$slots` type when updating this
	*/
	return {
		route,
		href: computed(() => route.value.href),
		isActive,
		isExactActive,
		navigate
	};
}
function preferSingleVNode(vnodes) {
	return vnodes.length === 1 ? vnodes[0] : vnodes;
}
/**
* Component to render a link that triggers a navigation on click.
*/
const RouterLink = /* @__PURE__ */ defineComponent({
	name: "RouterLink",
	compatConfig: { MODE: 3 },
	props: {
		to: {
			type: [String, Object],
			required: true
		},
		replace: Boolean,
		activeClass: String,
		exactActiveClass: String,
		custom: Boolean,
		ariaCurrentValue: {
			type: String,
			default: "page"
		},
		viewTransition: Boolean
	},
	useLink,
	setup(props, { slots }) {
		const link = reactive(useLink(props));
		const { options } = inject(routerKey);
		const elClass = computed(() => ({
			[getLinkClass(props.activeClass, options.linkActiveClass, "router-link-active")]: link.isActive,
			[getLinkClass(props.exactActiveClass, options.linkExactActiveClass, "router-link-exact-active")]: link.isExactActive
		}));
		return () => {
			const children = slots.default && preferSingleVNode(slots.default(link));
			return props.custom ? children : h("a", {
				"aria-current": link.isExactActive ? props.ariaCurrentValue : null,
				href: link.href,
				onClick: link.navigate,
				class: elClass.value
			}, children);
		};
	}
});
function guardEvent(e) {
	if (e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) return;
	if (e.defaultPrevented) return;
	if (e.button !== void 0 && e.button !== 0) return;
	if (e.currentTarget && e.currentTarget.getAttribute) {
		const target = e.currentTarget.getAttribute("target");
		if (/\b_blank\b/i.test(target)) return;
	}
	if (e.preventDefault) e.preventDefault();
	return true;
}
function includesParams(outer, inner) {
	for (const key in inner) {
		const innerValue = inner[key];
		const outerValue = outer[key];
		if (typeof innerValue === "string") {
			if (innerValue !== outerValue) return false;
		} else if (!isArray(outerValue) || outerValue.length !== innerValue.length || innerValue.some((value, i) => value.valueOf() !== outerValue[i].valueOf())) return false;
	}
	return true;
}
/**
* Get the original path value of a record by following its aliasOf
* @param record
*/
function getOriginalPath(record) {
	return record ? record.aliasOf ? record.aliasOf.path : record.path : "";
}
/**
* Utility class to get the active class based on defaults.
* @param propClass
* @param globalClass
* @param defaultClass
*/
const getLinkClass = (propClass, globalClass, defaultClass) => propClass != null ? propClass : globalClass != null ? globalClass : defaultClass;
//#endregion
//#region src/RouterView.ts
const RouterViewImpl = /*#__PURE__*/ defineComponent({
	name: "RouterView",
	inheritAttrs: false,
	props: {
		name: {
			type: String,
			default: "default"
		},
		route: Object
	},
	compatConfig: { MODE: 3 },
	setup(props, { attrs, slots }) {
		"development" !== "production" && warnDeprecatedUsage();
		const injectedRoute = inject(routerViewLocationKey);
		const routeToDisplay = computed(() => props.route || injectedRoute.value);
		const injectedDepth = inject(viewDepthKey, 0);
		const depth = computed(() => {
			let initialDepth = unref(injectedDepth);
			const { matched } = routeToDisplay.value;
			let matchedRoute;
			while ((matchedRoute = matched[initialDepth]) && !matchedRoute.components) initialDepth++;
			return initialDepth;
		});
		const matchedRouteRef = computed(() => routeToDisplay.value.matched[depth.value]);
		provide(viewDepthKey, computed(() => depth.value + 1));
		provide(matchedRouteKey, matchedRouteRef);
		provide(routerViewLocationKey, routeToDisplay);
		const viewRef = ref();
		watch(() => [
			viewRef.value,
			matchedRouteRef.value,
			props.name
		], ([instance, to, name], [oldInstance, from, _oldName]) => {
			if (to) {
				to.instances[name] = instance;
				if (from && from !== to && instance && instance === oldInstance) {
					if (!to.leaveGuards.size) to.leaveGuards = from.leaveGuards;
					if (!to.updateGuards.size) to.updateGuards = from.updateGuards;
				}
			}
			if (instance && to && (!from || !isSameRouteRecord(to, from) || !oldInstance)) (to.enterCallbacks[name] || []).forEach((callback) => callback(instance));
		}, { flush: "post" });
		return () => {
			const route = routeToDisplay.value;
			const currentName = props.name;
			const matchedRoute = matchedRouteRef.value;
			const ViewComponent = matchedRoute && matchedRoute.components[currentName];
			if (!ViewComponent) return normalizeSlot(slots.default, {
				Component: ViewComponent,
				route
			});
			const routePropsOption = matchedRoute.props[currentName];
			const routeProps = routePropsOption ? routePropsOption === true ? route.params : typeof routePropsOption === "function" ? routePropsOption(route) : routePropsOption : null;
			const onVnodeUnmounted = (vnode) => {
				if (vnode.component.isUnmounted) matchedRoute.instances[currentName] = null;
			};
			const component = h(ViewComponent, assign({}, routeProps, attrs, {
				onVnodeUnmounted,
				ref: viewRef
			}));
			if (("development" !== "production" || __VUE_PROD_DEVTOOLS__) && isBrowser && component.ref) {
				const info = {
					depth: depth.value,
					name: matchedRoute.name,
					path: matchedRoute.path,
					meta: matchedRoute.meta
				};
				(isArray(component.ref) ? component.ref.map((r) => r.i) : [component.ref.i]).forEach((instance) => {
					instance.__vrv_devtools = info;
				});
			}
			return normalizeSlot(slots.default, {
				Component: component,
				route
			}) || component;
		};
	}
});
function normalizeSlot(slot, data) {
	if (!slot) return null;
	const slotContent = slot(data);
	return slotContent.length === 1 ? slotContent[0] : slotContent;
}
/**
* Component to display the current route the user is at.
*/
const RouterView = RouterViewImpl;
function warnDeprecatedUsage() {
	const instance = getCurrentInstance();
	const parentName = instance.parent && instance.parent.type.name;
	const parentSubTreeType = instance.parent && instance.parent.subTree && instance.parent.subTree.type;
	if (parentName && (parentName === "KeepAlive" || parentName.includes("Transition")) && typeof parentSubTreeType === "object" && parentSubTreeType.name === "RouterView") {
		const comp = parentName === "KeepAlive" ? "keep-alive" : "transition";
		diagnostics.VUE_ROUTER_R0060({ comp });
	}
}
//#endregion
//#region src/router.ts
/**
* Creates a Router instance that can be used by a Vue app.
*
* @param options - {@link RouterOptions}
*/
function createRouter(options) {
	const matcher = createRouterMatcher(options.routes, options);
	const parseQuery$1 = options.parseQuery || parseQuery;
	const stringifyQuery$1 = options.stringifyQuery || stringifyQuery;
	const routerHistory = options.history;
	if ("development" !== "production" && !routerHistory) throw new Error("Provide the \"history\" option when calling \"createRouter()\": https://router.vuejs.org/api/interfaces/RouterOptions.html#history");
	const beforeGuards = useCallbacks();
	const beforeResolveGuards = useCallbacks();
	const afterGuards = useCallbacks();
	const currentRoute = shallowRef(START_LOCATION_NORMALIZED);
	let pendingLocation = START_LOCATION_NORMALIZED;
	if (isBrowser && options.scrollBehavior && "scrollRestoration" in history) history.scrollRestoration = "manual";
	const normalizeParams = applyToParams.bind(null, (paramValue) => "" + paramValue);
	const encodeParams = applyToParams.bind(null, encodeParam);
	const decodeParams = applyToParams.bind(null, decode);
	function addRoute(parentOrRoute, route) {
		let parent;
		let record;
		if (isRouteName(parentOrRoute)) {
			parent = matcher.getRecordMatcher(parentOrRoute);
			if ("development" !== "production" && !parent) diagnostics.VUE_ROUTER_R0001({ name: String(parentOrRoute) });
			record = route;
		} else record = parentOrRoute;
		return matcher.addRoute(record, parent);
	}
	function removeRoute(name) {
		const recordMatcher = matcher.getRecordMatcher(name);
		if (recordMatcher) matcher.removeRoute(recordMatcher);
		else if ("development" !== "production") diagnostics.VUE_ROUTER_R0002({ name: String(name) });
	}
	function getRoutes() {
		return matcher.getRoutes().map((routeMatcher) => routeMatcher.record);
	}
	function hasRoute(name) {
		return !!matcher.getRecordMatcher(name);
	}
	function resolve(rawLocation, currentLocation) {
		currentLocation = assign({}, currentLocation || currentRoute.value);
		if (typeof rawLocation === "string") {
			const locationNormalized = parseURL(parseQuery$1, rawLocation, currentLocation.path);
			const matchedRoute = matcher.resolve({ path: locationNormalized.path }, currentLocation);
			const href = routerHistory.createHref(locationNormalized.fullPath);
			if ("development" !== "production") {
				if (href.startsWith("//")) diagnostics.VUE_ROUTER_R0003({
					location: rawLocation,
					href
				});
				else if (!matchedRoute.matched.length) diagnostics.VUE_ROUTER_R0004({ path: rawLocation });
			}
			return assign(locationNormalized, matchedRoute, {
				params: decodeParams(matchedRoute.params),
				redirectedFrom: void 0,
				href
			});
		}
		if ("development" !== "production" && !isRouteLocation(rawLocation)) {
			diagnostics.VUE_ROUTER_R0005({ rawLocation });
			return resolve({});
		}
		let matcherLocation;
		if (rawLocation.path != null) {
			if ("development" !== "production" && "params" in rawLocation && !("name" in rawLocation) && Object.keys(rawLocation.params).length) diagnostics.VUE_ROUTER_R0006({ path: rawLocation.path });
			matcherLocation = assign({}, rawLocation, { path: parseURL(parseQuery$1, rawLocation.path, currentLocation.path).path });
		} else {
			const targetParams = assign({}, rawLocation.params);
			for (const key in targetParams) if (targetParams[key] == null) delete targetParams[key];
			matcherLocation = assign({}, rawLocation, { params: encodeParams(targetParams) });
			currentLocation.params = encodeParams(currentLocation.params);
		}
		const matchedRoute = matcher.resolve(matcherLocation, currentLocation);
		const hash = rawLocation.hash || "";
		if ("development" !== "production" && hash && !hash.startsWith("#")) diagnostics.VUE_ROUTER_R0007({ hash });
		matchedRoute.params = normalizeParams(decodeParams(matchedRoute.params));
		const fullPath = stringifyURL(stringifyQuery$1, assign({}, rawLocation, {
			hash: encodeHash(hash),
			path: matchedRoute.path
		}));
		const href = routerHistory.createHref(fullPath);
		if ("development" !== "production") {
			if (href.startsWith("//")) diagnostics.VUE_ROUTER_R0003({
				location: rawLocation,
				href
			});
			else if (!matchedRoute.matched.length) diagnostics.VUE_ROUTER_R0004({ path: rawLocation.path != null ? rawLocation.path : rawLocation });
		}
		return assign({
			fullPath,
			hash,
			query: stringifyQuery$1 === stringifyQuery ? normalizeQuery(rawLocation.query) : rawLocation.query || {}
		}, matchedRoute, {
			redirectedFrom: void 0,
			href
		});
	}
	function locationAsObject(to) {
		return typeof to === "string" ? parseURL(parseQuery$1, to, currentRoute.value.path) : assign({}, to);
	}
	function checkCanceledNavigation(to, from) {
		if (pendingLocation !== to) return createRouterError(8, {
			from,
			to
		});
	}
	function push(to) {
		return pushWithRedirect(to);
	}
	function replace(to) {
		return push(assign(locationAsObject(to), { replace: true }));
	}
	function handleRedirectRecord(to, from) {
		const lastMatched = to.matched[to.matched.length - 1];
		if (lastMatched && lastMatched.redirect) {
			const { redirect } = lastMatched;
			let newTargetLocation = typeof redirect === "function" ? redirect(to, from) : redirect;
			if (typeof newTargetLocation === "string") {
				newTargetLocation = newTargetLocation.includes("?") || newTargetLocation.includes("#") ? newTargetLocation = locationAsObject(newTargetLocation) : { path: newTargetLocation };
				newTargetLocation.params = {};
			}
			if ("development" !== "production" && newTargetLocation.path == null && !("name" in newTargetLocation)) {
				diagnostics.VUE_ROUTER_R0008({
					target: JSON.stringify(newTargetLocation, null, 2),
					to: to.fullPath
				});
				throw new Error("Invalid redirect");
			}
			return assign({
				query: to.query,
				hash: to.hash,
				params: newTargetLocation.path != null ? {} : to.params
			}, newTargetLocation);
		}
	}
	function pushWithRedirect(to, redirectedFrom) {
		const targetLocation = pendingLocation = resolve(to);
		const from = currentRoute.value;
		const data = to.state;
		const force = to.force;
		const replace = to.replace === true;
		const shouldRedirect = handleRedirectRecord(targetLocation, from);
		if (shouldRedirect) return pushWithRedirect(assign(locationAsObject(shouldRedirect), {
			state: typeof shouldRedirect === "object" ? assign({}, data, shouldRedirect.state) : data,
			force,
			replace
		}), redirectedFrom || targetLocation);
		const toLocation = targetLocation;
		toLocation.redirectedFrom = redirectedFrom;
		let failure;
		if (!force && isSameRouteLocation(stringifyQuery$1, from, targetLocation)) {
			failure = createRouterError(16, {
				to: toLocation,
				from
			});
			handleScroll(from, from, true, false);
		}
		return (failure ? Promise.resolve(failure) : navigate(toLocation, from)).catch((error) => isNavigationFailure(error) ? isNavigationFailure(error, 2) ? error : markAsReady(error) : triggerError(error, toLocation, from)).then((failure) => {
			if (failure) {
				if (isNavigationFailure(failure, 2)) {
					if ("development" !== "production" && isSameRouteLocation(stringifyQuery$1, resolve(failure.to), toLocation) && redirectedFrom && (redirectedFrom._count = redirectedFrom._count ? redirectedFrom._count + 1 : 1) > 30) {
						diagnostics.VUE_ROUTER_R0009({
							from: from.fullPath,
							to: toLocation.fullPath
						});
						return Promise.reject(/* @__PURE__ */ new Error("Infinite redirect in navigation guard"));
					}
					return pushWithRedirect(assign({ replace }, locationAsObject(failure.to), {
						state: typeof failure.to === "object" ? assign({}, data, failure.to.state) : data,
						force
					}), redirectedFrom || toLocation);
				}
			} else failure = finalizeNavigation(toLocation, from, true, replace, data);
			triggerAfterEach(toLocation, from, failure);
			return failure;
		});
	}
	/**
	* Helper to reject and skip all navigation guards if a new navigation happened
	* @param to
	* @param from
	*/
	function checkCanceledNavigationAndReject(to, from) {
		const error = checkCanceledNavigation(to, from);
		return error ? Promise.reject(error) : Promise.resolve();
	}
	function runWithContext(fn) {
		const app = installedApps.values().next().value;
		return app && typeof app.runWithContext === "function" ? app.runWithContext(fn) : fn();
	}
	function navigate(to, from) {
		let guards;
		const [leavingRecords, updatingRecords, enteringRecords] = extractChangingRecords(to, from);
		guards = extractComponentsGuards(leavingRecords.reverse(), "beforeRouteLeave", to, from);
		for (const record of leavingRecords) record.leaveGuards.forEach((guard) => {
			guards.push(guardToPromiseFn(guard, to, from));
		});
		const canceledNavigationCheck = checkCanceledNavigationAndReject.bind(null, to, from);
		guards.push(canceledNavigationCheck);
		return runGuardQueue(guards).then(() => {
			guards = [];
			for (const guard of beforeGuards.list()) guards.push(guardToPromiseFn(guard, to, from));
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).then(() => {
			guards = extractComponentsGuards(updatingRecords, "beforeRouteUpdate", to, from);
			for (const record of updatingRecords) record.updateGuards.forEach((guard) => {
				guards.push(guardToPromiseFn(guard, to, from));
			});
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).then(() => {
			guards = [];
			for (const record of enteringRecords) if (record.beforeEnter) if (isArray(record.beforeEnter)) for (const beforeEnter of record.beforeEnter) guards.push(guardToPromiseFn(beforeEnter, to, from));
			else guards.push(guardToPromiseFn(record.beforeEnter, to, from));
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).then(() => {
			to.matched.forEach((record) => record.enterCallbacks = {});
			guards = extractComponentsGuards(enteringRecords, "beforeRouteEnter", to, from, runWithContext);
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).then(() => {
			guards = [];
			for (const guard of beforeResolveGuards.list()) guards.push(guardToPromiseFn(guard, to, from));
			guards.push(canceledNavigationCheck);
			return runGuardQueue(guards);
		}).catch((err) => isNavigationFailure(err, 8) ? err : Promise.reject(err));
	}
	function triggerAfterEach(to, from, failure) {
		afterGuards.list().forEach((guard) => runWithContext(() => guard(to, from, failure)));
	}
	/**
	* - Cleans up any navigation guards
	* - Changes the url if necessary
	* - Calls the scrollBehavior
	*/
	function finalizeNavigation(toLocation, from, isPush, replace, data) {
		const error = checkCanceledNavigation(toLocation, from);
		if (error) return error;
		const isFirstNavigation = from === START_LOCATION_NORMALIZED;
		const state = !isBrowser ? {} : history.state;
		if (isPush) if (replace || isFirstNavigation) routerHistory.replace(toLocation.fullPath, assign({ scroll: isFirstNavigation && state && state.scroll }, data));
		else routerHistory.push(toLocation.fullPath, data);
		currentRoute.value = toLocation;
		handleScroll(toLocation, from, isPush, isFirstNavigation);
		markAsReady();
	}
	let removeHistoryListener;
	function setupListeners() {
		if (removeHistoryListener) return;
		removeHistoryListener = routerHistory.listen((to, _from, info) => {
			if (!router.listening) return;
			const toLocation = resolve(to);
			const shouldRedirect = handleRedirectRecord(toLocation, router.currentRoute.value);
			if (shouldRedirect) {
				pushWithRedirect(assign(shouldRedirect, {
					replace: true,
					force: true
				}), toLocation).catch(noop);
				return;
			}
			pendingLocation = toLocation;
			const from = currentRoute.value;
			if (isBrowser) saveScrollPosition(getScrollKey(from.fullPath, info.delta), computeScrollPosition());
			navigate(toLocation, from).catch((error) => {
				if (isNavigationFailure(error, 12)) return error;
				if (isNavigationFailure(error, 2)) {
					pushWithRedirect(assign(locationAsObject(error.to), { force: true }), toLocation).then((failure) => {
						if (isNavigationFailure(failure, 20) && !info.delta && info.type === "pop") routerHistory.go(-1, false);
					}).catch(noop);
					return Promise.reject();
				}
				if (info.delta) routerHistory.go(-info.delta, false);
				return triggerError(error, toLocation, from);
			}).then((failure) => {
				failure = failure || finalizeNavigation(toLocation, from, false);
				if (failure) {
					if (info.delta && !isNavigationFailure(failure, 8)) routerHistory.go(-info.delta, false);
					else if (info.type === "pop" && isNavigationFailure(failure, 20)) routerHistory.go(-1, false);
				}
				triggerAfterEach(toLocation, from, failure);
			}).catch(noop);
		});
	}
	let readyHandlers = useCallbacks();
	let errorListeners = useCallbacks();
	let ready;
	/**
	* Trigger errorListeners added via onError and throws the error as well
	*
	* @param error - error to throw
	* @param to - location we were navigating to when the error happened
	* @param from - location we were navigating from when the error happened
	* @returns the error as a rejected promise
	*/
	function triggerError(error, to, from) {
		markAsReady(error);
		const list = errorListeners.list();
		if (list.length) list.forEach((handler) => handler(error, to, from));
		else {
			if ("development" !== "production") diagnostics.VUE_ROUTER_R0010();
			console.error(error);
		}
		return Promise.reject(error);
	}
	function isReady() {
		if (ready && currentRoute.value !== START_LOCATION_NORMALIZED) return Promise.resolve();
		return new Promise((resolve, reject) => {
			readyHandlers.add([resolve, reject]);
		});
	}
	function markAsReady(err) {
		if (!ready) {
			ready = !err;
			setupListeners();
			readyHandlers.list().forEach(([resolve, reject]) => err ? reject(err) : resolve());
			readyHandlers.reset();
		}
		return err;
	}
	function handleScroll(to, from, isPush, isFirstNavigation) {
		const { scrollBehavior } = options;
		if (!isBrowser || !scrollBehavior) return Promise.resolve();
		const scrollPosition = !isPush && getSavedScrollPosition(getScrollKey(to.fullPath, 0)) || (isFirstNavigation || !isPush) && history.state && history.state.scroll || null;
		return nextTick().then(() => scrollBehavior(to, from, scrollPosition)).then((position) => to === currentRoute.value && position && scrollToPosition(position)).catch((err) => to === currentRoute.value && triggerError(err, to, from));
	}
	const go = (delta) => routerHistory.go(delta);
	let started;
	const installedApps = /* @__PURE__ */ new Set();
	const router = {
		currentRoute,
		listening: true,
		addRoute,
		removeRoute,
		clearRoutes: matcher.clearRoutes,
		hasRoute,
		getRoutes,
		resolve,
		options,
		push,
		replace,
		go,
		back: () => go(-1),
		forward: () => go(1),
		beforeEach: beforeGuards.add,
		beforeResolve: beforeResolveGuards.add,
		afterEach: afterGuards.add,
		onError: errorListeners.add,
		isReady,
		install(app) {
			app.component("RouterLink", RouterLink);
			app.component("RouterView", RouterView);
			app.config.globalProperties.$router = router;
			Object.defineProperty(app.config.globalProperties, "$route", {
				enumerable: true,
				get: () => unref(currentRoute)
			});
			if (isBrowser && !started && currentRoute.value === START_LOCATION_NORMALIZED) {
				started = true;
				push(routerHistory.location).catch((err) => {
					if ("development" !== "production") diagnostics.VUE_ROUTER_R0011({ cause: err });
				});
			}
			const reactiveRoute = {};
			for (const key in START_LOCATION_NORMALIZED) Object.defineProperty(reactiveRoute, key, {
				get: () => currentRoute.value[key],
				enumerable: true
			});
			app.provide(routerKey, router);
			app.provide(routeLocationKey, shallowReactive(reactiveRoute));
			app.provide(routerViewLocationKey, currentRoute);
			const unmountApp = app.unmount;
			installedApps.add(app);
			app.unmount = function() {
				installedApps.delete(app);
				if (installedApps.size < 1) {
					pendingLocation = START_LOCATION_NORMALIZED;
					removeHistoryListener && removeHistoryListener();
					removeHistoryListener = null;
					currentRoute.value = START_LOCATION_NORMALIZED;
					started = false;
					ready = false;
				}
				unmountApp();
			};
			if (("development" !== "production" || __VUE_PROD_DEVTOOLS__) && isBrowser && true) addDevtools(app, router, matcher);
		}
	};
	function runGuardQueue(guards) {
		return guards.reduce((promise, guard) => promise.then(() => runWithContext(guard)), Promise.resolve());
	}
	return router;
}
//#endregion
export { NavigationFailureType, RouterLink, RouterView, START_LOCATION_NORMALIZED as START_LOCATION, createMemoryHistory, createRouter, createRouterMatcher, createWebHashHistory, createWebHistory, isNavigationFailure, loadRouteLocation, matchedRouteKey, onBeforeRouteLeave, onBeforeRouteUpdate, parseQuery, routeLocationKey, routerKey, routerViewLocationKey, stringifyQuery, useLink, useRoute, useRouter, viewDepthKey };

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFLQSxTQUFTLEtBQUsscUJBQXFCLEtBQUssVUFBVSxLQUFLLFdBQVcsS0FBSyxZQUFZLEtBQUssYUFBYSxLQUFLLGNBQWMsS0FBSywyQkFBMkIsS0FBSyxtQkFBbUIsS0FBSyxvQkFBb0IsS0FBSyxtQkFBbUIsS0FBSyxlQUFlLEtBQUssY0FBYyxLQUFLLGdCQUFnQixLQUFLLGlCQUFpQixLQUFLLGNBQWMsS0FBSyx3QkFBd0IsS0FBSyxrQkFBa0IsS0FBSyxRQUFRLEtBQUssV0FBVyxLQUFLLGdCQUFnQixLQUFLLHVCQUF1QixLQUFLLHdCQUF3QixLQUFLLG9CQUFvQixLQUFLLGFBQWEsS0FBSyx5QkFBeUIsS0FBSyxxQkFBcUIsS0FBSyxhQUFhLEtBQUssWUFBWSxLQUFLLGtCQUFrQixLQUFLLDJCQUEyQixLQUFLLGtCQUFrQjtBQUN6ckIsU0FBUyxLQUFLLFdBQVcsS0FBSyxhQUFhLEtBQUsscUJBQXFCLEtBQUssZUFBZSxLQUFLLFNBQVMsS0FBSyxrQkFBa0IsS0FBSyx1QkFBdUIsS0FBSyxXQUFXLEtBQUssdUJBQXVCLEtBQUssUUFBUSxLQUFLLGlCQUFpQixLQUFLLGNBQWMsS0FBSyxVQUFVLEtBQUssbUJBQW1CLEtBQUssY0FBYyxLQUFLLFlBQVk7QUFDdlUsU0FBUyxVQUFVLGlCQUFpQixvQkFBb0IsR0FBRyxRQUFRLFVBQVUsU0FBUyxVQUFVLEtBQUssaUJBQWlCLFlBQVksT0FBTyxPQUFPLG1CQUFtQjs7QUFFbkssSUFBSSwyQkFBMkIsU0FBUyxXQUFXLE9BQU8sU0FBUzs7Ozs7O0FBTW5FLFNBQVMsc0JBQXNCLE1BQU0sVUFBVTtDQUM5QyxNQUFNLEVBQUUsVUFBVSxRQUFRLFNBQVM7Q0FDbkMsTUFBTSxVQUFVLEtBQUssUUFBUSxHQUFHO0NBQ2hDLElBQUksVUFBVSxDQUFDLEdBQUc7RUFDakIsSUFBSSxXQUFXLEtBQUssU0FBUyxLQUFLLE1BQU0sT0FBTyxDQUFDLElBQUksS0FBSyxNQUFNLE9BQU8sQ0FBQyxDQUFDLFNBQVM7RUFDakYsSUFBSSxlQUFlLEtBQUssTUFBTSxRQUFRO0VBQ3RDLElBQUksYUFBYSxPQUFPLEtBQUssZUFBZSxNQUFNO0VBQ2xELE9BQU8sVUFBVSxjQUFjLEVBQUU7Q0FDbEM7Q0FDQSxPQUFPLFVBQVUsVUFBVSxJQUFJLElBQUksU0FBUztBQUM3QztBQUNBLFNBQVMsb0JBQW9CLE1BQU0sY0FBYyxpQkFBaUIsU0FBUztDQUMxRSxJQUFJLFlBQVksQ0FBQztDQUNqQixJQUFJLFlBQVksQ0FBQztDQUNqQixJQUFJLGFBQWE7Q0FDakIsTUFBTSxtQkFBbUIsRUFBRSxZQUFZO0VBQ3RDLE1BQU0sS0FBSyxzQkFBc0IsTUFBTSxRQUFRO0VBQy9DLE1BQU0sT0FBTyxnQkFBZ0I7RUFDN0IsTUFBTSxZQUFZLGFBQWE7RUFDL0IsSUFBSSxRQUFRO0VBQ1osSUFBSSxPQUFPO0dBQ1YsZ0JBQWdCLFFBQVE7R0FDeEIsYUFBYSxRQUFRO0dBQ3JCLElBQUksY0FBYyxlQUFlLE1BQU07SUFDdEMsYUFBYTtJQUNiO0dBQ0Q7R0FDQSxRQUFRLFlBQVksTUFBTSxXQUFXLFVBQVUsV0FBVztFQUMzRCxPQUFPLFFBQVEsRUFBRTtFQUNqQixVQUFVLFNBQVMsYUFBYTtHQUMvQixTQUFTLGdCQUFnQixPQUFPLE1BQU07SUFDckM7SUFDQSxNQUFNO0lBQ04sV0FBVyxRQUFRLFFBQVEsSUFBSSxZQUFZLFNBQVM7R0FDckQsQ0FBQztFQUNGLENBQUM7Q0FDRjtDQUNBLFNBQVMsaUJBQWlCO0VBQ3pCLGFBQWEsZ0JBQWdCO0NBQzlCO0NBQ0EsU0FBUyxPQUFPLFVBQVU7RUFDekIsVUFBVSxLQUFLLFFBQVE7RUFDdkIsTUFBTSxpQkFBaUI7R0FDdEIsTUFBTSxRQUFRLFVBQVUsUUFBUSxRQUFRO0dBQ3hDLElBQUksUUFBUSxDQUFDLEdBQUcsVUFBVSxPQUFPLE9BQU8sQ0FBQztFQUMxQztFQUNBLFVBQVUsS0FBSyxRQUFRO0VBQ3ZCLE9BQU87Q0FDUjtDQUNBLFNBQVMsdUJBQXVCO0VBQy9CLElBQUksU0FBUyxvQkFBb0IsVUFBVTtHQUMxQyxNQUFNLEVBQUUsWUFBWTtHQUNwQixJQUFJLENBQUMsUUFBUSxPQUFPO0dBQ3BCLFFBQVEsYUFBYSxPQUFPLENBQUMsR0FBRyxRQUFRLE9BQU8sRUFBRSxRQUFRLHNCQUFzQixFQUFFLENBQUMsR0FBRyxFQUFFO0VBQ3hGO0NBQ0Q7Q0FDQSxTQUFTLFVBQVU7RUFDbEIsS0FBSyxNQUFNLFlBQVksV0FBVyxTQUFTO0VBQzNDLFlBQVksQ0FBQztFQUNiLE9BQU8sb0JBQW9CLFlBQVksZUFBZTtFQUN0RCxPQUFPLG9CQUFvQixZQUFZLG9CQUFvQjtFQUMzRCxTQUFTLG9CQUFvQixvQkFBb0Isb0JBQW9CO0NBQ3RFO0NBQ0EsT0FBTyxpQkFBaUIsWUFBWSxlQUFlO0NBQ25ELE9BQU8saUJBQWlCLFlBQVksb0JBQW9CO0NBQ3hELFNBQVMsaUJBQWlCLG9CQUFvQixvQkFBb0I7Q0FDbEUsT0FBTztFQUNOO0VBQ0E7RUFDQTtDQUNEO0FBQ0Q7Ozs7QUFJQSxTQUFTLFdBQVcsTUFBTSxTQUFTLFNBQVMsV0FBVyxPQUFPLGdCQUFnQixPQUFPO0NBQ3BGLE9BQU87RUFDTjtFQUNBO0VBQ0E7RUFDQTtFQUNBLFVBQVUsT0FBTyxRQUFRO0VBQ3pCLFFBQVEsZ0JBQWdCLHNCQUFzQixJQUFJO0NBQ25EO0FBQ0Q7QUFDQSxTQUFTLDBCQUEwQixNQUFNO0NBQ3hDLE1BQU0sRUFBRSxTQUFTLGFBQWE7Q0FDOUIsTUFBTSxrQkFBa0IsRUFBRSxPQUFPLHNCQUFzQixNQUFNLFFBQVEsRUFBRTtDQUN2RSxNQUFNLGVBQWUsRUFBRSxPQUFPLFFBQVEsTUFBTTtDQUM1QyxJQUFJLENBQUMsYUFBYSxPQUFPLGVBQWUsZ0JBQWdCLE9BQU87RUFDOUQsTUFBTTtFQUNOLFNBQVMsZ0JBQWdCO0VBQ3pCLFNBQVM7RUFDVCxVQUFVLFFBQVEsU0FBUztFQUMzQixVQUFVO0VBQ1YsUUFBUTtDQUNULEdBQUcsSUFBSTtDQUNQLFNBQVMsZUFBZSxJQUFJLE9BQU8sU0FBUzs7Ozs7Ozs7OztFQVUzQyxNQUFNLFlBQVksS0FBSyxRQUFRLEdBQUc7RUFDbEMsTUFBTSxNQUFNLFlBQVksQ0FBQyxLQUFLLFNBQVMsUUFBUSxTQUFTLGNBQWMsTUFBTSxJQUFJLE9BQU8sS0FBSyxNQUFNLFNBQVMsS0FBSyxLQUFLLG1CQUFtQixJQUFJLE9BQU87RUFDbkosSUFBSTtHQUNILFFBQVEsVUFBVSxpQkFBaUIsWUFBWSxDQUFDLE9BQU8sSUFBSSxHQUFHO0dBQzlELGFBQWEsUUFBUTtFQUN0QixTQUFTLEtBQUs7R0FDYixzQkFBNkIsY0FBYyxZQUFZLGlCQUFpQixFQUFFLE9BQU8sSUFBSSxDQUFDO1FBQ2pGLFFBQVEsTUFBTSxHQUFHO0dBQ3RCLFNBQVMsVUFBVSxZQUFZLFNBQVMsQ0FBQyxHQUFHO0VBQzdDO0NBQ0Q7Q0FDQSxTQUFTLFFBQVEsSUFBSSxNQUFNO0VBQzFCLGVBQWUsSUFBSSxPQUFPLENBQUMsR0FBRyxRQUFRLE9BQU8sV0FBVyxhQUFhLE1BQU0sTUFBTSxJQUFJLGFBQWEsTUFBTSxTQUFTLElBQUksR0FBRyxNQUFNLEVBQUUsVUFBVSxhQUFhLE1BQU0sU0FBUyxDQUFDLEdBQUcsSUFBSTtFQUM5SyxnQkFBZ0IsUUFBUTtDQUN6QjtDQUNBLFNBQVMsS0FBSyxJQUFJLE1BQU07RUFDdkIsTUFBTSxlQUFlLE9BQU8sQ0FBQyxHQUFHLGFBQWEsT0FBTyxRQUFRLE9BQU87R0FDbEUsU0FBUztHQUNULFFBQVEsc0JBQXNCO0VBQy9CLENBQUM7RUFDRCxzQkFBNkIsZ0JBQWdCLENBQUMsUUFBUSxPQUFPLFlBQVksaUJBQWlCO0VBQzFGLGVBQWUsYUFBYSxTQUFTLGNBQWMsSUFBSTtFQUN2RCxlQUFlLElBQUksT0FBTyxDQUFDLEdBQUcsV0FBVyxnQkFBZ0IsT0FBTyxJQUFJLElBQUksR0FBRyxFQUFFLFVBQVUsYUFBYSxXQUFXLEVBQUUsR0FBRyxJQUFJLEdBQUcsS0FBSztFQUNoSSxnQkFBZ0IsUUFBUTtDQUN6QjtDQUNBLE9BQU87RUFDTixVQUFVO0VBQ1YsT0FBTztFQUNQO0VBQ0E7Q0FDRDtBQUNEOzs7Ozs7QUFNQSxTQUFTLGlCQUFpQixNQUFNO0NBQy9CLE9BQU8sY0FBYyxJQUFJO0NBQ3pCLE1BQU0sb0JBQW9CLDBCQUEwQixJQUFJO0NBQ3hELE1BQU0sbUJBQW1CLG9CQUFvQixNQUFNLGtCQUFrQixPQUFPLGtCQUFrQixVQUFVLGtCQUFrQixPQUFPO0NBQ2pJLFNBQVMsR0FBRyxPQUFPLG1CQUFtQixNQUFNO0VBQzNDLElBQUksQ0FBQyxrQkFBa0IsaUJBQWlCLGVBQWU7RUFDdkQsUUFBUSxHQUFHLEtBQUs7Q0FDakI7Q0FDQSxNQUFNLGdCQUFnQixPQUFPO0VBQzVCLFVBQVU7RUFDVjtFQUNBO0VBQ0EsWUFBWSxXQUFXLEtBQUssTUFBTSxJQUFJO0NBQ3ZDLEdBQUcsbUJBQW1CLGdCQUFnQjtDQUN0QyxPQUFPLGVBQWUsZUFBZSxZQUFZO0VBQ2hELFlBQVk7RUFDWixXQUFXLGtCQUFrQixTQUFTO0NBQ3ZDLENBQUM7Q0FDRCxPQUFPLGVBQWUsZUFBZSxTQUFTO0VBQzdDLFlBQVk7RUFDWixXQUFXLGtCQUFrQixNQUFNO0NBQ3BDLENBQUM7Q0FDRCxPQUFPO0FBQ1I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQTJCQSxTQUFTLHFCQUFxQixNQUFNO0NBQ25DLE9BQU8sU0FBUyxPQUFPLFFBQVEsU0FBUyxXQUFXLFNBQVMsU0FBUztDQUNyRSxJQUFJLENBQUMsS0FBSyxTQUFTLEdBQUcsR0FBRyxRQUFRO0NBQ2pDLHNCQUE2QixnQkFBZ0IsQ0FBQyxLQUFLLFNBQVMsSUFBSSxLQUFLLENBQUMsS0FBSyxTQUFTLEdBQUcsR0FBRyxZQUFZLGlCQUFpQjtFQUN0SDtFQUNBLFlBQVksS0FBSyxRQUFRLFFBQVEsR0FBRztDQUNyQyxDQUFDO0NBQ0QsT0FBTyxpQkFBaUIsSUFBSTtBQUM3Qjs7Ozs7Ozs7OztBQVVBLFNBQVMsb0JBQW9CLE9BQU8sSUFBSTtDQUN2QyxJQUFJLFlBQVksQ0FBQztDQUNqQixJQUFJLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Q0FDckIsSUFBSSxXQUFXO0NBQ2YsT0FBTyxjQUFjLElBQUk7Q0FDekIsU0FBUyxZQUFZLFVBQVUsUUFBUSxDQUFDLEdBQUc7RUFDMUM7RUFDQSxJQUFJLGFBQWEsTUFBTSxRQUFRLE1BQU0sT0FBTyxRQUFRO0VBQ3BELE1BQU0sS0FBSyxDQUFDLFVBQVUsS0FBSyxDQUFDO0NBQzdCO0NBQ0EsU0FBUyxpQkFBaUIsSUFBSSxNQUFNLEVBQUUsV0FBVyxTQUFTO0VBQ3pELE1BQU0sT0FBTztHQUNaO0dBQ0E7R0FDQSxNQUFNO0VBQ1A7RUFDQSxLQUFLLE1BQU0sWUFBWSxXQUFXLFNBQVMsSUFBSSxNQUFNLElBQUk7Q0FDMUQ7Q0FDQSxNQUFNLGdCQUFnQjtFQUNyQixVQUFVO0VBQ1YsT0FBTyxDQUFDO0VBQ1I7RUFDQSxZQUFZLFdBQVcsS0FBSyxNQUFNLElBQUk7RUFDdEMsUUFBUSxJQUFJLE9BQU87R0FDbEIsTUFBTSxPQUFPLFlBQVksQ0FBQztHQUMxQixZQUFZLElBQUksS0FBSztFQUN0QjtFQUNBLEtBQUssSUFBSSxPQUFPO0dBQ2YsWUFBWSxJQUFJLEtBQUs7RUFDdEI7RUFDQSxPQUFPLFVBQVU7R0FDaEIsVUFBVSxLQUFLLFFBQVE7R0FDdkIsYUFBYTtJQUNaLE1BQU0sUUFBUSxVQUFVLFFBQVEsUUFBUTtJQUN4QyxJQUFJLFFBQVEsQ0FBQyxHQUFHLFVBQVUsT0FBTyxPQUFPLENBQUM7R0FDMUM7RUFDRDtFQUNBLFVBQVU7R0FDVCxZQUFZLENBQUM7R0FDYixRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0dBQ2pCLFdBQVc7RUFDWjtFQUNBLEdBQUcsT0FBTyxnQkFBZ0IsTUFBTTtHQUMvQixNQUFNLE9BQU8sS0FBSztHQUNsQixNQUFNLFlBQVksUUFBUSxJQUFJLFNBQVM7R0FDdkMsV0FBVyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksV0FBVyxPQUFPLE1BQU0sU0FBUyxDQUFDLENBQUM7R0FDbkUsSUFBSSxlQUFlLGlCQUFpQixLQUFLLFVBQVUsTUFBTTtJQUN4RDtJQUNBO0dBQ0QsQ0FBQztFQUNGO0NBQ0Q7Q0FDQSxPQUFPLGVBQWUsZUFBZSxZQUFZO0VBQ2hELFlBQVk7RUFDWixXQUFXLE1BQU0sU0FBUyxDQUFDO0NBQzVCLENBQUM7Q0FDRCxPQUFPLGVBQWUsZUFBZSxTQUFTO0VBQzdDLFlBQVk7RUFDWixXQUFXLE1BQU0sU0FBUyxDQUFDO0NBQzVCLENBQUM7Q0FDRCxPQUFPO0FBQ1I7OztBQUdBLE1BQU0sYUFBYTtDQUNsQixNQUFNO0NBQ04sT0FBTztBQUNSO0FBQ0EsTUFBTSxpQkFBaUI7QUFDdkIsU0FBUyxhQUFhLE1BQU07Q0FDM0IsSUFBSSxDQUFDLE1BQU0sT0FBTyxDQUFDLENBQUMsQ0FBQztDQUNyQixJQUFJLFNBQVMsS0FBSyxPQUFPLENBQUMsQ0FBQyxVQUFVLENBQUM7Q0FDdEMsSUFBSSxDQUFDLEtBQUssV0FBVyxHQUFHLEdBQUcsTUFBTSxJQUFJLHdCQUErQixlQUFlLHlDQUF5QyxLQUFLLGdCQUFnQixLQUFLLE1BQU0saUJBQWlCLEtBQUssRUFBRTtDQUNwTCxTQUFTLE1BQU0sU0FBUztFQUN2QixNQUFNLElBQUksTUFBTSxRQUFRLE1BQU0sS0FBSyxPQUFPLEtBQUssU0FBUztDQUN6RDtDQUNBLElBQUksUUFBUTtDQUNaLElBQUksZ0JBQWdCO0NBQ3BCLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLElBQUk7Q0FDSixTQUFTLGtCQUFrQjtFQUMxQixJQUFJLFNBQVMsT0FBTyxLQUFLLE9BQU87RUFDaEMsVUFBVSxDQUFDO0NBQ1o7Q0FDQSxJQUFJLElBQUk7Q0FDUixJQUFJO0NBQ0osSUFBSSxTQUFTO0NBQ2IsSUFBSSxXQUFXO0NBQ2YsU0FBUyxnQkFBZ0I7RUFDeEIsSUFBSSxDQUFDLFFBQVE7RUFDYixJQUFJLFVBQVUsR0FBRyxRQUFRLEtBQUs7R0FDN0IsTUFBTTtHQUNOLE9BQU87RUFDUixDQUFDO09BQ0ksSUFBSSxVQUFVLEtBQUssVUFBVSxLQUFLLFVBQVUsR0FBRztHQUNuRCxJQUFJLFFBQVEsU0FBUyxNQUFNLFNBQVMsT0FBTyxTQUFTLE1BQU0sTUFBTSx1QkFBdUIsT0FBTyw2Q0FBNkM7R0FDM0ksUUFBUSxLQUFLO0lBQ1osTUFBTTtJQUNOLE9BQU87SUFDUCxRQUFRO0lBQ1IsWUFBWSxTQUFTLE9BQU8sU0FBUztJQUNyQyxVQUFVLFNBQVMsT0FBTyxTQUFTO0dBQ3BDLENBQUM7RUFDRixPQUFPLE1BQU0saUNBQWlDO0VBQzlDLFNBQVM7Q0FDVjtDQUNBLFNBQVMsa0JBQWtCO0VBQzFCLFVBQVU7Q0FDWDtDQUNBLE9BQU8sSUFBSSxLQUFLLFFBQVE7RUFDdkIsT0FBTyxLQUFLO0VBQ1osUUFBUSxPQUFSO0dBQ0MsS0FBSztJQUNKLElBQUksU0FBUyxNQUFNO0tBQ2xCLGdCQUFnQjtLQUNoQixRQUFRO0lBQ1QsT0FBTyxJQUFJLFNBQVMsS0FBSztLQUN4QixJQUFJLFFBQVEsY0FBYztLQUMxQixnQkFBZ0I7SUFDakIsT0FBTyxJQUFJLFNBQVMsS0FBSztLQUN4QixjQUFjO0tBQ2QsUUFBUTtJQUNULE9BQU8sZ0JBQWdCO0lBQ3ZCO0dBQ0QsS0FBSztJQUNKLGdCQUFnQjtJQUNoQixRQUFRO0lBQ1I7R0FDRCxLQUFLO0lBQ0osSUFBSSxTQUFTLEtBQUssUUFBUTtTQUNyQixJQUFJLGVBQWUsS0FBSyxJQUFJLEdBQUcsZ0JBQWdCO1NBQy9DO0tBQ0osY0FBYztLQUNkLFFBQVE7S0FDUixJQUFJLFNBQVMsT0FBTyxTQUFTLE9BQU8sU0FBUyxLQUFLO0lBQ25EO0lBQ0E7R0FDRCxLQUFLO0lBQ0osSUFBSSxTQUFTLEtBQUssSUFBSSxTQUFTLFNBQVMsU0FBUyxNQUFNLE1BQU0sV0FBVyxTQUFTLE1BQU0sR0FBRyxDQUFDLENBQUMsSUFBSTtTQUMzRixRQUFRO1NBQ1IsWUFBWTtJQUNqQjtHQUNELEtBQUs7SUFDSixjQUFjO0lBQ2QsUUFBUTtJQUNSLElBQUksU0FBUyxPQUFPLFNBQVMsT0FBTyxTQUFTLEtBQUs7SUFDbEQsV0FBVztJQUNYO0dBQ0Q7SUFDQyxNQUFNLGVBQWU7SUFDckI7RUFDRjtDQUNEO0NBQ0EsSUFBSSxVQUFVLEdBQUcsTUFBTSx1Q0FBdUMsT0FBTyxFQUFFO0NBQ3ZFLGNBQWM7Q0FDZCxnQkFBZ0I7Q0FDaEIsT0FBTztBQUNSOzs7QUFHQSxNQUFNLHFCQUFxQjtBQUMzQixNQUFNLDJCQUEyQjtDQUNoQyxXQUFXO0NBQ1gsUUFBUTtDQUNSLE9BQU87Q0FDUCxLQUFLO0FBQ047QUFDQSxNQUFNLGlCQUFpQjs7Ozs7Ozs7QUFRdkIsU0FBUyxlQUFlLFVBQVUsY0FBYztDQUMvQyxNQUFNLFVBQVUsT0FBTyxDQUFDLEdBQUcsMEJBQTBCLFlBQVk7Q0FDakUsTUFBTSxRQUFRLENBQUM7Q0FDZixJQUFJLFVBQVUsUUFBUSxRQUFRLE1BQU07Q0FDcEMsTUFBTSxPQUFPLENBQUM7Q0FDZCxLQUFLLE1BQU0sV0FBVyxVQUFVO0VBQy9CLE1BQU0sZ0JBQWdCLFFBQVEsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFO0VBQy9DLElBQUksUUFBUSxVQUFVLENBQUMsUUFBUSxRQUFRLFdBQVc7RUFDbEQsS0FBSyxJQUFJLGFBQWEsR0FBRyxhQUFhLFFBQVEsUUFBUSxjQUFjO0dBQ25FLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLElBQUksa0JBQWtCLE1BQU0sUUFBUSxZQUFZLE1BQU07R0FDdEQsSUFBSSxNQUFNLFNBQVMsR0FBRztJQUNyQixJQUFJLENBQUMsWUFBWSxXQUFXO0lBQzVCLFdBQVcsTUFBTSxNQUFNLFFBQVEsZ0JBQWdCLE1BQU07SUFDckQsbUJBQW1CO0dBQ3BCLE9BQU8sSUFBSSxNQUFNLFNBQVMsR0FBRztJQUM1QixNQUFNLEVBQUUsT0FBTyxZQUFZLFVBQVUsV0FBVztJQUNoRCxLQUFLLEtBQUs7S0FDVCxNQUFNO0tBQ047S0FDQTtJQUNELENBQUM7SUFDRCxNQUFNLEtBQUssU0FBUyxTQUFTO0lBQzdCLElBQUksT0FBTyxvQkFBb0I7S0FDOUIsbUJBQW1CO0tBQ25CLElBQUk7TUFDSCxJQUFJLE9BQU8sSUFBSSxHQUFHLEVBQUU7S0FDckIsU0FBUyxLQUFLO01BQ2IsTUFBTSxJQUFJLE1BQU0sb0NBQW9DLE1BQU0sS0FBSyxHQUFHLE9BQU8sSUFBSSxPQUFPO0tBQ3JGO0lBQ0Q7SUFDQSxJQUFJLGFBQWEsYUFBYSxPQUFPLEdBQUcsVUFBVSxHQUFHLFFBQVEsSUFBSSxHQUFHO0lBQ3BFLElBQUksQ0FBQyxZQUFZLGFBQWEsWUFBWSxRQUFRLFNBQVMsSUFBSSxPQUFPLFdBQVcsS0FBSyxNQUFNO0lBQzVGLElBQUksVUFBVSxjQUFjO0lBQzVCLFdBQVc7SUFDWCxtQkFBbUI7SUFDbkIsSUFBSSxVQUFVLG1CQUFtQixDQUFDO0lBQ2xDLElBQUksWUFBWSxtQkFBbUIsQ0FBQztJQUNwQyxJQUFJLE9BQU8sTUFBTSxtQkFBbUIsQ0FBQztHQUN0QztHQUNBLGNBQWMsS0FBSyxlQUFlO0VBQ25DO0VBQ0EsTUFBTSxLQUFLLGFBQWE7Q0FDekI7Q0FDQSxJQUFJLFFBQVEsVUFBVSxRQUFRLEtBQUs7RUFDbEMsTUFBTSxJQUFJLE1BQU0sU0FBUztFQUN6QixNQUFNLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxTQUFTLE1BQU07Q0FDbEM7Q0FDQSxJQUFJLENBQUMsUUFBUSxRQUFRLFdBQVc7Q0FDaEMsSUFBSSxRQUFRLEtBQUssV0FBVztNQUN2QixJQUFJLFFBQVEsVUFBVSxDQUFDLFFBQVEsU0FBUyxHQUFHLEdBQUcsV0FBVztDQUM5RCxNQUFNLEtBQUssSUFBSSxPQUFPLFNBQVMsUUFBUSxZQUFZLEtBQUssR0FBRztDQUMzRCxTQUFTLE1BQU0sTUFBTTtFQUNwQixNQUFNLFFBQVEsS0FBSyxNQUFNLEVBQUU7RUFDM0IsTUFBTSxTQUFTLENBQUM7RUFDaEIsSUFBSSxDQUFDLE9BQU8sT0FBTztFQUNuQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7R0FDdEMsTUFBTSxRQUFRLE1BQU0sTUFBTTtHQUMxQixNQUFNLE1BQU0sS0FBSyxJQUFJO0dBQ3JCLE9BQU8sSUFBSSxRQUFRLFNBQVMsSUFBSSxhQUFhLE1BQU0sTUFBTSxHQUFHLElBQUk7RUFDakU7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxTQUFTLFVBQVUsUUFBUTtFQUMxQixJQUFJLE9BQU87RUFDWCxJQUFJLHVCQUF1QjtFQUMzQixLQUFLLE1BQU0sV0FBVyxVQUFVO0dBQy9CLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxLQUFLLFNBQVMsR0FBRyxHQUFHLFFBQVE7R0FDMUQsdUJBQXVCO0dBQ3ZCLEtBQUssTUFBTSxTQUFTLFNBQVMsSUFBSSxNQUFNLFNBQVMsR0FBRyxRQUFRLE1BQU07UUFDNUQsSUFBSSxNQUFNLFNBQVMsR0FBRztJQUMxQixNQUFNLEVBQUUsT0FBTyxZQUFZLGFBQWE7SUFDeEMsTUFBTSxRQUFRLFNBQVMsU0FBUyxPQUFPLFNBQVM7SUFDaEQsSUFBSSxRQUFRLEtBQUssS0FBSyxDQUFDLFlBQVksTUFBTSxJQUFJLE1BQU0sbUJBQW1CLE1BQU0sMERBQTBEO0lBQ3RJLE1BQU0sT0FBTyxRQUFRLEtBQUssSUFBSSxNQUFNLEtBQUssR0FBRyxJQUFJO0lBQ2hELElBQUksQ0FBQyxNQUFNLElBQUksVUFBVTtLQUN4QixJQUFJLFFBQVEsU0FBUyxHQUFHLElBQUksS0FBSyxTQUFTLEdBQUcsR0FBRyxPQUFPLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQztVQUNsRSx1QkFBdUI7SUFDN0IsT0FBTyxNQUFNLElBQUksTUFBTSwyQkFBMkIsTUFBTSxFQUFFO0lBQzFELFFBQVE7R0FDVDtFQUNEO0VBQ0EsT0FBTyxRQUFRO0NBQ2hCO0NBQ0EsT0FBTztFQUNOO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRDtBQUNEOzs7Ozs7Ozs7O0FBVUEsU0FBUyxrQkFBa0IsR0FBRyxHQUFHO0NBQ2hDLElBQUksSUFBSTtDQUNSLE9BQU8sSUFBSSxFQUFFLFVBQVUsSUFBSSxFQUFFLFFBQVE7RUFDcEMsTUFBTSxPQUFPLEVBQUUsS0FBSyxFQUFFO0VBQ3RCLElBQUksTUFBTSxPQUFPO0VBQ2pCO0NBQ0Q7Q0FDQSxJQUFJLEVBQUUsU0FBUyxFQUFFLFFBQVEsT0FBTyxFQUFFLFdBQVcsS0FBSyxFQUFFLE9BQU8sS0FBSyxDQUFDLElBQUk7TUFDaEUsSUFBSSxFQUFFLFNBQVMsRUFBRSxRQUFRLE9BQU8sRUFBRSxXQUFXLEtBQUssRUFBRSxPQUFPLEtBQUssSUFBSSxDQUFDO0NBQzFFLE9BQU87QUFDUjs7Ozs7Ozs7QUFRQSxTQUFTLHVCQUF1QixHQUFHLEdBQUc7Q0FDckMsSUFBSSxJQUFJO0NBQ1IsTUFBTSxTQUFTLEVBQUU7Q0FDakIsTUFBTSxTQUFTLEVBQUU7Q0FDakIsT0FBTyxJQUFJLE9BQU8sVUFBVSxJQUFJLE9BQU8sUUFBUTtFQUM5QyxNQUFNLE9BQU8sa0JBQWtCLE9BQU8sSUFBSSxPQUFPLEVBQUU7RUFDbkQsSUFBSSxNQUFNLE9BQU87RUFDakI7Q0FDRDtDQUNBLElBQUksS0FBSyxJQUFJLE9BQU8sU0FBUyxPQUFPLE1BQU0sTUFBTSxHQUFHO0VBQ2xELElBQUksb0JBQW9CLE1BQU0sR0FBRyxPQUFPO0VBQ3hDLElBQUksb0JBQW9CLE1BQU0sR0FBRyxPQUFPLENBQUM7Q0FDMUM7Q0FDQSxPQUFPLE9BQU8sU0FBUyxPQUFPO0FBQy9COzs7Ozs7O0FBT0EsU0FBUyxvQkFBb0IsT0FBTztDQUNuQyxNQUFNLE9BQU8sTUFBTSxNQUFNLFNBQVM7Q0FDbEMsT0FBTyxNQUFNLFNBQVMsS0FBSyxLQUFLLEtBQUssU0FBUyxLQUFLO0FBQ3BEO0FBQ0EsTUFBTSwrQkFBK0I7Q0FDcEMsUUFBUTtDQUNSLEtBQUs7Q0FDTCxXQUFXO0FBQ1o7OztBQUdBLFNBQVMseUJBQXlCLFFBQVEsUUFBUSxTQUFTO0NBQzFELE1BQU0sU0FBUyxlQUFlLGFBQWEsT0FBTyxJQUFJLEdBQUcsT0FBTztDQUNoRSxzQkFBNkIsY0FBYztFQUMxQyxNQUFNLCtCQUErQixJQUFJLElBQUk7RUFDN0MsS0FBSyxNQUFNLE9BQU8sT0FBTyxNQUFNO0dBQzlCLElBQUksYUFBYSxJQUFJLElBQUksSUFBSSxHQUFHLFlBQVksaUJBQWlCO0lBQzVELE1BQU0sSUFBSTtJQUNWLE1BQU0sT0FBTztHQUNkLENBQUM7R0FDRCxhQUFhLElBQUksSUFBSSxJQUFJO0VBQzFCO0NBQ0Q7Q0FDQSxNQUFNLFVBQVUsT0FBTyxRQUFRO0VBQzlCO0VBQ0E7RUFDQSxVQUFVLENBQUM7RUFDWCxPQUFPLENBQUM7Q0FDVCxDQUFDO0NBQ0QsSUFBSSxRQUFRO0VBQ1gsSUFBSSxDQUFDLFFBQVEsT0FBTyxZQUFZLENBQUMsT0FBTyxPQUFPLFNBQVMsT0FBTyxTQUFTLEtBQUssT0FBTztDQUNyRjtDQUNBLE9BQU87QUFDUjs7Ozs7Ozs7OztBQVVBLFNBQVMsb0JBQW9CLFFBQVEsZUFBZTtDQUNuRCxNQUFNLFdBQVcsQ0FBQztDQUNsQixNQUFNLDZCQUE2QixJQUFJLElBQUk7Q0FDM0MsZ0JBQWdCLGFBQWEsOEJBQThCLGFBQWE7Q0FDeEUsU0FBUyxpQkFBaUIsTUFBTTtFQUMvQixPQUFPLFdBQVcsSUFBSSxJQUFJO0NBQzNCO0NBQ0EsU0FBUyxTQUFTLFFBQVEsUUFBUSxnQkFBZ0I7RUFDakQsTUFBTSxZQUFZLENBQUM7RUFDbkIsTUFBTSx1QkFBdUIscUJBQXFCLE1BQU07RUFDeEQsc0JBQTZCLGNBQWMsbUNBQW1DLHNCQUFzQixNQUFNO0VBQzFHLHFCQUFxQixVQUFVLGtCQUFrQixlQUFlO0VBQ2hFLE1BQU0sVUFBVSxhQUFhLGVBQWUsTUFBTTtFQUNsRCxNQUFNLG9CQUFvQixDQUFDLG9CQUFvQjtFQUMvQyxJQUFJLFdBQVcsUUFBUTtHQUN0QixNQUFNLFVBQVUsT0FBTyxPQUFPLFVBQVUsV0FBVyxDQUFDLE9BQU8sS0FBSyxJQUFJLE9BQU87R0FDM0UsS0FBSyxNQUFNLFNBQVMsU0FBUyxrQkFBa0IsS0FBSyxxQkFBcUIsT0FBTyxDQUFDLEdBQUcsc0JBQXNCO0lBQ3pHLFlBQVksaUJBQWlCLGVBQWUsT0FBTyxhQUFhLHFCQUFxQjtJQUNyRixNQUFNO0lBQ04sU0FBUyxpQkFBaUIsZUFBZSxTQUFTO0dBQ25ELENBQUMsQ0FBQyxDQUFDO0VBQ0o7RUFDQSxJQUFJO0VBQ0osSUFBSTtFQUNKLEtBQUssTUFBTSxvQkFBb0IsbUJBQW1CO0dBQ2pELE1BQU0sRUFBRSxTQUFTO0dBQ2pCLElBQUksVUFBVSxLQUFLLE9BQU8sS0FBSztJQUM5QixNQUFNLGFBQWEsT0FBTyxPQUFPO0lBQ2pDLE1BQU0sa0JBQWtCLFdBQVcsV0FBVyxTQUFTLE9BQU8sTUFBTSxLQUFLO0lBQ3pFLGlCQUFpQixPQUFPLE9BQU8sT0FBTyxRQUFRLFFBQVEsa0JBQWtCO0dBQ3pFO0dBQ0Esc0JBQTZCLGdCQUFnQixpQkFBaUIsU0FBUyxLQUFLLE1BQU0sSUFBSSxNQUFNLDJLQUEySztHQUN2USxVQUFVLHlCQUF5QixrQkFBa0IsUUFBUSxPQUFPO0dBQ3BFLHNCQUE2QixnQkFBZ0IsVUFBVSxLQUFLLE9BQU8sS0FBSyxpQ0FBaUMsU0FBUyxNQUFNO0dBQ3hILElBQUksZ0JBQWdCO0lBQ25CLGVBQWUsTUFBTSxLQUFLLE9BQU87SUFDakMsc0JBQTZCLGNBQWMsZ0JBQWdCLGdCQUFnQixPQUFPO0dBQ25GLE9BQU87SUFDTixrQkFBa0IsbUJBQW1CO0lBQ3JDLElBQUksb0JBQW9CLFNBQVMsZ0JBQWdCLE1BQU0sS0FBSyxPQUFPO0lBQ25FLElBQUksYUFBYSxPQUFPLFFBQVEsQ0FBQyxjQUFjLE9BQU8sR0FBRztLQUN4RCxzQkFBNkIsY0FBYyx3QkFBd0IsUUFBUSxNQUFNO0tBQ2pGLFlBQVksT0FBTyxJQUFJO0lBQ3hCO0dBQ0Q7R0FDQSxJQUFJLFlBQVksT0FBTyxHQUFHLGNBQWMsT0FBTztHQUMvQyxJQUFJLHFCQUFxQixVQUFVO0lBQ2xDLE1BQU0sV0FBVyxxQkFBcUI7SUFDdEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLLFNBQVMsU0FBUyxJQUFJLFNBQVMsa0JBQWtCLGVBQWUsU0FBUyxFQUFFO0dBQ3RIO0dBQ0EsaUJBQWlCLGtCQUFrQjtFQUNwQztFQUNBLE9BQU8sd0JBQXdCO0dBQzlCLFlBQVksZUFBZTtFQUM1QixJQUFJO0NBQ0w7Q0FDQSxTQUFTLFlBQVksWUFBWTtFQUNoQyxJQUFJLFlBQVksVUFBVSxHQUFHO0dBQzVCLE1BQU0sVUFBVSxXQUFXLElBQUksVUFBVTtHQUN6QyxJQUFJLFNBQVM7SUFDWixXQUFXLE9BQU8sVUFBVTtJQUM1QixTQUFTLE9BQU8sU0FBUyxRQUFRLE9BQU8sR0FBRyxDQUFDO0lBQzVDLFFBQVEsU0FBUyxRQUFRLFdBQVc7SUFDcEMsUUFBUSxNQUFNLFFBQVEsV0FBVztHQUNsQztFQUNELE9BQU87R0FDTixNQUFNLFFBQVEsU0FBUyxRQUFRLFVBQVU7R0FDekMsSUFBSSxRQUFRLENBQUMsR0FBRztJQUNmLFNBQVMsT0FBTyxPQUFPLENBQUM7SUFDeEIsSUFBSSxXQUFXLE9BQU8sTUFBTSxXQUFXLE9BQU8sV0FBVyxPQUFPLElBQUk7SUFDcEUsV0FBVyxTQUFTLFFBQVEsV0FBVztJQUN2QyxXQUFXLE1BQU0sUUFBUSxXQUFXO0dBQ3JDO0VBQ0Q7Q0FDRDtDQUNBLFNBQVMsWUFBWTtFQUNwQixPQUFPO0NBQ1I7Q0FDQSxTQUFTLGNBQWMsU0FBUztFQUMvQixNQUFNLFFBQVEsbUJBQW1CLFNBQVMsUUFBUTtFQUNsRCxTQUFTLE9BQU8sT0FBTyxHQUFHLE9BQU87RUFDakMsSUFBSSxRQUFRLE9BQU8sUUFBUSxDQUFDLGNBQWMsT0FBTyxHQUFHLFdBQVcsSUFBSSxRQUFRLE9BQU8sTUFBTSxPQUFPO0NBQ2hHO0NBQ0EsU0FBUyxRQUFRLFVBQVUsaUJBQWlCO0VBQzNDLElBQUk7RUFDSixJQUFJLFNBQVMsQ0FBQztFQUNkLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSSxVQUFVLFlBQVksU0FBUyxNQUFNO0dBQ3hDLFVBQVUsV0FBVyxJQUFJLFNBQVMsSUFBSTtHQUN0QyxJQUFJLENBQUMsU0FBUyxNQUFNLGtCQUFrQixHQUFHLEVBQUUsU0FBUyxDQUFDO0dBQ3JELHNCQUE2QixjQUFjO0lBQzFDLE1BQU0sZ0JBQWdCLE9BQU8sS0FBSyxTQUFTLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLGNBQWMsQ0FBQyxRQUFRLEtBQUssTUFBTSxNQUFNLEVBQUUsU0FBUyxTQUFTLENBQUM7SUFDOUgsSUFBSSxjQUFjLFFBQVE7S0FDekIsTUFBTSxjQUFjLENBQUMsUUFBUSxLQUFLLFVBQVUsY0FBYyxNQUFNLFNBQVMsUUFBUSxnQkFBZ0IsTUFBTTtLQUN2RyxZQUFZLGlCQUFpQjtNQUM1QixRQUFRLGNBQWMsS0FBSyxRQUFRO01BQ25DLFdBQVcsY0FBYywySUFBMkk7S0FDckssQ0FBQztJQUNGO0dBQ0Q7R0FDQSxPQUFPLFFBQVEsT0FBTztHQUN0QixTQUFTLE9BQU8sV0FBVyxnQkFBZ0IsUUFBUSxRQUFRLEtBQUssUUFBUSxNQUFNLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxPQUFPLFFBQVEsU0FBUyxRQUFRLE9BQU8sS0FBSyxRQUFRLE1BQU0sRUFBRSxRQUFRLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU0sRUFBRSxJQUFJLENBQUMsR0FBRyxTQUFTLFVBQVUsV0FBVyxTQUFTLFFBQVEsUUFBUSxLQUFLLEtBQUssTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO0dBQzNRLE9BQU8sUUFBUSxVQUFVLE1BQU07RUFDaEMsT0FBTyxJQUFJLFNBQVMsUUFBUSxNQUFNO0dBQ2pDLE9BQU8sU0FBUztHQUNoQixzQkFBNkIsZ0JBQWdCLENBQUMsS0FBSyxXQUFXLEdBQUcsR0FBRyxZQUFZLGlCQUFpQixFQUFFLEtBQUssQ0FBQztHQUN6RyxVQUFVLFNBQVMsTUFBTSxNQUFNLEVBQUUsR0FBRyxLQUFLLElBQUksQ0FBQztHQUM5QyxJQUFJLFNBQVM7SUFDWixTQUFTLFFBQVEsTUFBTSxJQUFJO0lBQzNCLE9BQU8sUUFBUSxPQUFPO0lBQ3RCLFFBQVEsS0FBSyxTQUFTLFFBQVE7S0FDN0IsSUFBSSxJQUFJLFlBQVksQ0FBQyxPQUFPLElBQUksT0FBTyxPQUFPLE9BQU8sSUFBSTtJQUMxRCxDQUFDO0dBQ0Y7RUFDRCxPQUFPO0dBQ04sVUFBVSxnQkFBZ0IsT0FBTyxXQUFXLElBQUksZ0JBQWdCLElBQUksSUFBSSxTQUFTLE1BQU0sTUFBTSxFQUFFLEdBQUcsS0FBSyxnQkFBZ0IsSUFBSSxDQUFDO0dBQzVILElBQUksQ0FBQyxTQUFTLE1BQU0sa0JBQWtCLEdBQUc7SUFDeEM7SUFDQTtHQUNELENBQUM7R0FDRCxPQUFPLFFBQVEsT0FBTztHQUN0QixTQUFTLE9BQU8sQ0FBQyxHQUFHLGdCQUFnQixRQUFRLFNBQVMsTUFBTTtHQUMzRCxPQUFPLFFBQVEsVUFBVSxNQUFNO0VBQ2hDO0VBQ0EsTUFBTSxVQUFVLENBQUM7RUFDakIsSUFBSSxnQkFBZ0I7RUFDcEIsT0FBTyxlQUFlO0dBQ3JCLFFBQVEsUUFBUSxjQUFjLE1BQU07R0FDcEMsZ0JBQWdCLGNBQWM7RUFDL0I7RUFDQSxPQUFPO0dBQ047R0FDQTtHQUNBO0dBQ0E7R0FDQSxNQUFNLGdCQUFnQixPQUFPO0VBQzlCO0NBQ0Q7Q0FDQSxPQUFPLFNBQVMsVUFBVSxTQUFTLEtBQUssQ0FBQztDQUN6QyxTQUFTLGNBQWM7RUFDdEIsU0FBUyxTQUFTO0VBQ2xCLFdBQVcsTUFBTTtDQUNsQjtDQUNBLE9BQU87RUFDTjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRDtBQUNEOzs7Ozs7O0FBT0EsU0FBUyxXQUFXLFFBQVEsTUFBTTtDQUNqQyxNQUFNLFlBQVksQ0FBQztDQUNuQixLQUFLLE1BQU0sT0FBTyxNQUFNLElBQUksT0FBTyxRQUFRLFVBQVUsT0FBTyxPQUFPO0NBQ25FLE9BQU87QUFDUjs7Ozs7OztBQU9BLFNBQVMscUJBQXFCLFFBQVE7Q0FDckMsTUFBTSxhQUFhO0VBQ2xCLE1BQU0sT0FBTztFQUNiLFVBQVUsT0FBTztFQUNqQixNQUFNLE9BQU87RUFDYixNQUFNLE9BQU8sUUFBUSxDQUFDO0VBQ3RCLFNBQVMsT0FBTztFQUNoQixhQUFhLE9BQU87RUFDcEIsT0FBTyxxQkFBcUIsTUFBTTtFQUNsQyxVQUFVLE9BQU8sWUFBWSxDQUFDO0VBQzlCLFdBQVcsQ0FBQztFQUNaLDZCQUE2QixJQUFJLElBQUk7RUFDckMsOEJBQThCLElBQUksSUFBSTtFQUN0QyxnQkFBZ0IsQ0FBQztFQUNqQixZQUFZLGdCQUFnQixTQUFTLE9BQU8sY0FBYyxPQUFPLE9BQU8sYUFBYSxFQUFFLFNBQVMsT0FBTyxVQUFVO0NBQ2xIO0NBQ0EsT0FBTyxlQUFlLFlBQVksUUFBUSxFQUFFLE9BQU8sQ0FBQyxFQUFFLENBQUM7Q0FDdkQsT0FBTztBQUNSOzs7Ozs7QUFNQSxTQUFTLHFCQUFxQixRQUFRO0NBQ3JDLE1BQU0sY0FBYyxDQUFDO0NBQ3JCLE1BQU0sUUFBUSxPQUFPLFNBQVM7Q0FDOUIsSUFBSSxlQUFlLFFBQVEsWUFBWSxVQUFVO01BQzVDLEtBQUssTUFBTSxRQUFRLE9BQU8sWUFBWSxZQUFZLFFBQVEsT0FBTyxVQUFVLFdBQVcsTUFBTSxRQUFRO0NBQ3pHLE9BQU87QUFDUjs7Ozs7QUFLQSxTQUFTLGNBQWMsUUFBUTtDQUM5QixPQUFPLFFBQVE7RUFDZCxJQUFJLE9BQU8sT0FBTyxTQUFTLE9BQU87RUFDbEMsU0FBUyxPQUFPO0NBQ2pCO0NBQ0EsT0FBTztBQUNSOzs7Ozs7QUFNQSxTQUFTLGdCQUFnQixTQUFTO0NBQ2pDLE9BQU8sUUFBUSxRQUFRLE1BQU0sV0FBVyxPQUFPLE1BQU0sT0FBTyxJQUFJLEdBQUcsQ0FBQyxDQUFDO0FBQ3RFO0FBQ0EsU0FBUyxZQUFZLEdBQUcsR0FBRztDQUMxQixPQUFPLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRSxhQUFhLEVBQUUsWUFBWSxFQUFFLGVBQWUsRUFBRTtBQUM3RTs7Ozs7OztBQU9BLFNBQVMsZ0JBQWdCLEdBQUcsR0FBRztDQUM5QixLQUFLLE1BQU0sT0FBTyxFQUFFLE1BQU0sSUFBSSxDQUFDLElBQUksWUFBWSxDQUFDLEVBQUUsS0FBSyxLQUFLLFlBQVksS0FBSyxNQUFNLEdBQUcsQ0FBQyxHQUFHO0VBQ3pGLFlBQVksaUJBQWlCO0dBQzVCLE9BQU8sRUFBRSxPQUFPO0dBQ2hCLFVBQVUsRUFBRSxPQUFPO0dBQ25CLE1BQU0sSUFBSTtFQUNYLENBQUM7RUFDRDtDQUNEO0NBQ0EsS0FBSyxNQUFNLE9BQU8sRUFBRSxNQUFNLElBQUksQ0FBQyxJQUFJLFlBQVksQ0FBQyxFQUFFLEtBQUssS0FBSyxZQUFZLEtBQUssTUFBTSxHQUFHLENBQUMsR0FBRztFQUN6RixZQUFZLGlCQUFpQjtHQUM1QixPQUFPLEVBQUUsT0FBTztHQUNoQixVQUFVLEVBQUUsT0FBTztHQUNuQixNQUFNLElBQUk7RUFDWCxDQUFDO0VBQ0Q7Q0FDRDtBQUNEOzs7Ozs7O0FBT0EsU0FBUyxtQ0FBbUMsc0JBQXNCLFFBQVE7Q0FDekUsSUFBSSxVQUFVLE9BQU8sT0FBTyxRQUFRLENBQUMscUJBQXFCLFFBQVEsQ0FBQyxxQkFBcUIsUUFBUSxxQkFBcUIsU0FBUyxXQUFXLEdBQUcsWUFBWSxpQkFBaUIsRUFBRSxNQUFNLE9BQU8sT0FBTyxPQUFPLElBQUksRUFBRSxDQUFDO0FBQzlNO0FBQ0EsU0FBUyx3QkFBd0IsUUFBUSxRQUFRO0NBQ2hELEtBQUssSUFBSSxXQUFXLFFBQVEsVUFBVSxXQUFXLFNBQVMsUUFBUSxJQUFJLFNBQVMsT0FBTyxTQUFTLE9BQU8sTUFBTSxNQUFNLElBQUksTUFBTSxrQkFBa0IsT0FBTyxPQUFPLElBQUksRUFBRSx3QkFBd0IsV0FBVyxXQUFXLFVBQVUsYUFBYSx1SEFBdUg7QUFDL1Y7QUFDQSxTQUFTLGlDQUFpQyxRQUFRLFFBQVE7Q0FDekQsS0FBSyxNQUFNLE9BQU8sT0FBTyxNQUFNLElBQUksQ0FBQyxPQUFPLEtBQUssS0FBSyxZQUFZLEtBQUssTUFBTSxHQUFHLENBQUMsR0FBRztFQUNsRixZQUFZLGlCQUFpQjtHQUM1QixNQUFNLE9BQU8sT0FBTztHQUNwQixNQUFNLElBQUk7R0FDVixRQUFRLE9BQU8sT0FBTztFQUN2QixDQUFDO0VBQ0Q7Q0FDRDtBQUNEOzs7Ozs7Ozs7O0FBVUEsU0FBUyxtQkFBbUIsU0FBUyxVQUFVO0NBQzlDLElBQUksUUFBUTtDQUNaLElBQUksUUFBUSxTQUFTO0NBQ3JCLE9BQU8sVUFBVSxPQUFPO0VBQ3ZCLE1BQU0sTUFBTSxRQUFRLFNBQVM7RUFDN0IsSUFBSSx1QkFBdUIsU0FBUyxTQUFTLElBQUksSUFBSSxHQUFHLFFBQVE7T0FDM0QsUUFBUSxNQUFNO0NBQ3BCO0NBQ0EsTUFBTSxvQkFBb0IscUJBQXFCLE9BQU87Q0FDdEQsSUFBSSxtQkFBbUI7RUFDdEIsUUFBUSxTQUFTLFlBQVksbUJBQW1CLFFBQVEsQ0FBQztFQUN6RCxzQkFBNkIsZ0JBQWdCLFFBQVEsR0FBRyxZQUFZLGlCQUFpQjtHQUNwRixVQUFVLGtCQUFrQixPQUFPO0dBQ25DLFFBQVEsUUFBUSxPQUFPO0VBQ3hCLENBQUM7Q0FDRjtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMscUJBQXFCLFNBQVM7Q0FDdEMsSUFBSSxXQUFXO0NBQ2YsT0FBTyxXQUFXLFNBQVMsUUFBUSxJQUFJLFlBQVksUUFBUSxLQUFLLHVCQUF1QixTQUFTLFFBQVEsTUFBTSxHQUFHLE9BQU87QUFDekg7Ozs7Ozs7O0FBUUEsU0FBUyxZQUFZLEVBQUUsVUFBVTtDQUNoQyxPQUFPLENBQUMsRUFBRSxPQUFPLFFBQVEsT0FBTyxjQUFjLE9BQU8sS0FBSyxPQUFPLFVBQVUsQ0FBQyxDQUFDLFVBQVUsT0FBTztBQUMvRjs7Ozs7Ozs7QUFRQSxTQUFTLFFBQVEsT0FBTztDQUN2QixNQUFNLFNBQVMsT0FBTyxTQUFTO0NBQy9CLE1BQU0sZUFBZSxPQUFPLGdCQUFnQjtDQUM1QyxJQUFJLGNBQWM7Q0FDbEIsSUFBSSxhQUFhO0NBQ2pCLE1BQU0sUUFBUSxlQUFlO0VBQzVCLE1BQU0sS0FBSyxNQUFNLE1BQU0sRUFBRTtFQUN6QixzQkFBNkIsaUJBQWlCLENBQUMsZUFBZSxPQUFPLGFBQWE7R0FDakYsSUFBSSxDQUFDLGdCQUFnQixFQUFFLEdBQUcsWUFBWSxpQkFBaUIsRUFBRSxHQUFHLENBQUM7R0FDN0QsYUFBYTtHQUNiLGNBQWM7RUFDZjtFQUNBLE9BQU8sT0FBTyxRQUFRLEVBQUU7Q0FDekIsQ0FBQztDQUNELE1BQU0sb0JBQW9CLGVBQWU7RUFDeEMsTUFBTSxFQUFFLFlBQVksTUFBTTtFQUMxQixNQUFNLEVBQUUsV0FBVztFQUNuQixNQUFNLGVBQWUsUUFBUSxTQUFTO0VBQ3RDLE1BQU0saUJBQWlCLGFBQWE7RUFDcEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsUUFBUSxPQUFPLENBQUM7RUFDckQsTUFBTSxRQUFRLGVBQWUsVUFBVSxrQkFBa0IsS0FBSyxNQUFNLFlBQVksQ0FBQztFQUNqRixJQUFJLFFBQVEsQ0FBQyxHQUFHLE9BQU87RUFDdkIsTUFBTSxtQkFBbUIsZ0JBQWdCLFFBQVEsU0FBUyxFQUFFO0VBQzVELE9BQU8sU0FBUyxLQUFLLGdCQUFnQixZQUFZLE1BQU0sb0JBQW9CLGVBQWUsZUFBZSxTQUFTLEVBQUUsQ0FBQyxTQUFTLG1CQUFtQixlQUFlLFVBQVUsa0JBQWtCLEtBQUssTUFBTSxRQUFRLFNBQVMsRUFBRSxDQUFDLElBQUk7Q0FDaE8sQ0FBQztDQUNELE1BQU0sV0FBVyxlQUFlLGtCQUFrQixRQUFRLENBQUMsS0FBSyxlQUFlLGFBQWEsUUFBUSxNQUFNLE1BQU0sTUFBTSxDQUFDO0NBQ3ZILE1BQU0sZ0JBQWdCLGVBQWUsa0JBQWtCLFFBQVEsQ0FBQyxLQUFLLGtCQUFrQixVQUFVLGFBQWEsUUFBUSxTQUFTLEtBQUssMEJBQTBCLGFBQWEsUUFBUSxNQUFNLE1BQU0sTUFBTSxDQUFDO0NBQ3RNLFNBQVMsU0FBUyxJQUFJLENBQUMsR0FBRztFQUN6QixJQUFJLFdBQVcsQ0FBQyxHQUFHO0dBQ2xCLE1BQU0sSUFBSSxPQUFPLE1BQU0sTUFBTSxPQUFPLElBQUksWUFBWSxPQUFPLENBQUMsTUFBTSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFJO0dBQ3ZGLElBQUksTUFBTSxrQkFBa0IsT0FBTyxhQUFhLGVBQWUseUJBQXlCLFVBQVUsU0FBUywwQkFBMEIsQ0FBQztHQUN0SSxPQUFPO0VBQ1I7RUFDQSxPQUFPLFFBQVEsUUFBUTtDQUN4QjtDQUNBLHVCQUE4QixnQkFBZ0IsMEJBQTBCLFdBQVc7RUFDbEYsTUFBTSxXQUFXLG1CQUFtQjtFQUNwQyxJQUFJLFVBQVU7R0FDYixNQUFNLHNCQUFzQjtJQUMzQixPQUFPLE1BQU07SUFDYixVQUFVLFNBQVM7SUFDbkIsZUFBZSxjQUFjO0lBQzdCLE9BQU87R0FDUjtHQUNBLFNBQVMsaUJBQWlCLFNBQVMsa0JBQWtCLENBQUM7R0FDdEQsU0FBUyxlQUFlLEtBQUssbUJBQW1CO0dBQ2hELGtCQUFrQjtJQUNqQixvQkFBb0IsUUFBUSxNQUFNO0lBQ2xDLG9CQUFvQixXQUFXLFNBQVM7SUFDeEMsb0JBQW9CLGdCQUFnQixjQUFjO0lBQ2xELG9CQUFvQixRQUFRLGdCQUFnQixNQUFNLE1BQU0sRUFBRSxDQUFDLElBQUksT0FBTztHQUN2RSxHQUFHLEVBQUUsT0FBTyxPQUFPLENBQUM7RUFDckI7Q0FDRDs7OztDQUlBLE9BQU87RUFDTjtFQUNBLE1BQU0sZUFBZSxNQUFNLE1BQU0sSUFBSTtFQUNyQztFQUNBO0VBQ0E7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxrQkFBa0IsUUFBUTtDQUNsQyxPQUFPLE9BQU8sV0FBVyxJQUFJLE9BQU8sS0FBSztBQUMxQzs7OztBQUlBLE1BQU0sYUFBNkIsZ0NBQWdCO0NBQ2xELE1BQU07Q0FDTixjQUFjLEVBQUUsTUFBTSxFQUFFO0NBQ3hCLE9BQU87RUFDTixJQUFJO0dBQ0gsTUFBTSxDQUFDLFFBQVEsTUFBTTtHQUNyQixVQUFVO0VBQ1g7RUFDQSxTQUFTO0VBQ1QsYUFBYTtFQUNiLGtCQUFrQjtFQUNsQixRQUFRO0VBQ1Isa0JBQWtCO0dBQ2pCLE1BQU07R0FDTixTQUFTO0VBQ1Y7RUFDQSxnQkFBZ0I7Q0FDakI7Q0FDQTtDQUNBLE1BQU0sT0FBTyxFQUFFLFNBQVM7RUFDdkIsTUFBTSxPQUFPLFNBQVMsUUFBUSxLQUFLLENBQUM7RUFDcEMsTUFBTSxFQUFFLFlBQVksT0FBTyxTQUFTO0VBQ3BDLE1BQU0sVUFBVSxnQkFBZ0I7SUFDOUIsYUFBYSxNQUFNLGFBQWEsUUFBUSxpQkFBaUIsb0JBQW9CLElBQUksS0FBSztJQUN0RixhQUFhLE1BQU0sa0JBQWtCLFFBQVEsc0JBQXNCLDBCQUEwQixJQUFJLEtBQUs7RUFDeEcsRUFBRTtFQUNGLGFBQWE7R0FDWixNQUFNLFdBQVcsTUFBTSxXQUFXLGtCQUFrQixNQUFNLFFBQVEsSUFBSSxDQUFDO0dBQ3ZFLE9BQU8sTUFBTSxTQUFTLFdBQVcsRUFBRSxLQUFLO0lBQ3ZDLGdCQUFnQixLQUFLLGdCQUFnQixNQUFNLG1CQUFtQjtJQUM5RCxNQUFNLEtBQUs7SUFDWCxTQUFTLEtBQUs7SUFDZCxPQUFPLFFBQVE7R0FDaEIsR0FBRyxRQUFRO0VBQ1o7Q0FDRDtBQUNELENBQUM7QUFDRCxTQUFTLFdBQVcsR0FBRztDQUN0QixJQUFJLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxXQUFXLEVBQUUsVUFBVTtDQUN0RCxJQUFJLEVBQUUsa0JBQWtCO0NBQ3hCLElBQUksRUFBRSxXQUFXLEtBQUssS0FBSyxFQUFFLFdBQVcsR0FBRztDQUMzQyxJQUFJLEVBQUUsaUJBQWlCLEVBQUUsY0FBYyxjQUFjO0VBQ3BELE1BQU0sU0FBUyxFQUFFLGNBQWMsYUFBYSxRQUFRO0VBQ3BELElBQUksY0FBYyxLQUFLLE1BQU0sR0FBRztDQUNqQztDQUNBLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxlQUFlO0NBQ3ZDLE9BQU87QUFDUjtBQUNBLFNBQVMsZUFBZSxPQUFPLE9BQU87Q0FDckMsS0FBSyxNQUFNLE9BQU8sT0FBTztFQUN4QixNQUFNLGFBQWEsTUFBTTtFQUN6QixNQUFNLGFBQWEsTUFBTTtFQUN6QixJQUFJLE9BQU8sZUFBZSxVQUFVO0dBQ25DLElBQUksZUFBZSxZQUFZLE9BQU87RUFDdkMsT0FBTyxJQUFJLENBQUMsUUFBUSxVQUFVLEtBQUssV0FBVyxXQUFXLFdBQVcsVUFBVSxXQUFXLE1BQU0sT0FBTyxNQUFNLE1BQU0sUUFBUSxNQUFNLFdBQVcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxHQUFHLE9BQU87Q0FDbEs7Q0FDQSxPQUFPO0FBQ1I7Ozs7O0FBS0EsU0FBUyxnQkFBZ0IsUUFBUTtDQUNoQyxPQUFPLFNBQVMsT0FBTyxVQUFVLE9BQU8sUUFBUSxPQUFPLE9BQU8sT0FBTztBQUN0RTs7Ozs7OztBQU9BLE1BQU0sZ0JBQWdCLFdBQVcsYUFBYSxpQkFBaUIsYUFBYSxPQUFPLFlBQVksZUFBZSxPQUFPLGNBQWM7OztBQUduSSxNQUFNLGlCQUErQiw4QkFBZ0I7Q0FDcEQsTUFBTTtDQUNOLGNBQWM7Q0FDZCxPQUFPO0VBQ04sTUFBTTtHQUNMLE1BQU07R0FDTixTQUFTO0VBQ1Y7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxjQUFjLEVBQUUsTUFBTSxFQUFFO0NBQ3hCLE1BQU0sT0FBTyxFQUFFLE9BQU8sU0FBUztFQUM5QixrQkFBeUIsZ0JBQWdCLG9CQUFvQjtFQUM3RCxNQUFNLGdCQUFnQixPQUFPLHFCQUFxQjtFQUNsRCxNQUFNLGlCQUFpQixlQUFlLE1BQU0sU0FBUyxjQUFjLEtBQUs7RUFDeEUsTUFBTSxnQkFBZ0IsT0FBTyxjQUFjLENBQUM7RUFDNUMsTUFBTSxRQUFRLGVBQWU7R0FDNUIsSUFBSSxlQUFlLE1BQU0sYUFBYTtHQUN0QyxNQUFNLEVBQUUsWUFBWSxlQUFlO0dBQ25DLElBQUk7R0FDSixRQUFRLGVBQWUsUUFBUSxrQkFBa0IsQ0FBQyxhQUFhLFlBQVk7R0FDM0UsT0FBTztFQUNSLENBQUM7RUFDRCxNQUFNLGtCQUFrQixlQUFlLGVBQWUsTUFBTSxRQUFRLE1BQU0sTUFBTTtFQUNoRixRQUFRLGNBQWMsZUFBZSxNQUFNLFFBQVEsQ0FBQyxDQUFDO0VBQ3JELFFBQVEsaUJBQWlCLGVBQWU7RUFDeEMsUUFBUSx1QkFBdUIsY0FBYztFQUM3QyxNQUFNLFVBQVUsSUFBSTtFQUNwQixZQUFZO0dBQ1gsUUFBUTtHQUNSLGdCQUFnQjtHQUNoQixNQUFNO0VBQ1AsSUFBSSxDQUFDLFVBQVUsSUFBSSxPQUFPLENBQUMsYUFBYSxNQUFNLGNBQWM7R0FDM0QsSUFBSSxJQUFJO0lBQ1AsR0FBRyxVQUFVLFFBQVE7SUFDckIsSUFBSSxRQUFRLFNBQVMsTUFBTSxZQUFZLGFBQWEsYUFBYTtLQUNoRSxJQUFJLENBQUMsR0FBRyxZQUFZLE1BQU0sR0FBRyxjQUFjLEtBQUs7S0FDaEQsSUFBSSxDQUFDLEdBQUcsYUFBYSxNQUFNLEdBQUcsZUFBZSxLQUFLO0lBQ25EO0dBQ0Q7R0FDQSxJQUFJLFlBQVksT0FBTyxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsSUFBSSxJQUFJLEtBQUssQ0FBQyxjQUFjLENBQUMsR0FBRyxlQUFlLFNBQVMsQ0FBQyxFQUFDLENBQUUsU0FBUyxhQUFhLFNBQVMsUUFBUSxDQUFDO0VBQ3hKLEdBQUcsRUFBRSxPQUFPLE9BQU8sQ0FBQztFQUNwQixhQUFhO0dBQ1osTUFBTSxRQUFRLGVBQWU7R0FDN0IsTUFBTSxjQUFjLE1BQU07R0FDMUIsTUFBTSxlQUFlLGdCQUFnQjtHQUNyQyxNQUFNLGdCQUFnQixnQkFBZ0IsYUFBYSxXQUFXO0dBQzlELElBQUksQ0FBQyxlQUFlLE9BQU8sY0FBYyxNQUFNLFNBQVM7SUFDdkQsV0FBVztJQUNYO0dBQ0QsQ0FBQztHQUNELE1BQU0sbUJBQW1CLGFBQWEsTUFBTTtHQUM1QyxNQUFNLGFBQWEsbUJBQW1CLHFCQUFxQixPQUFPLE1BQU0sU0FBUyxPQUFPLHFCQUFxQixhQUFhLGlCQUFpQixLQUFLLElBQUksbUJBQW1CO0dBQ3ZLLE1BQU0sb0JBQW9CLFVBQVU7SUFDbkMsSUFBSSxNQUFNLFVBQVUsYUFBYSxhQUFhLFVBQVUsZUFBZTtHQUN4RTtHQUNBLE1BQU0sWUFBWSxFQUFFLGVBQWUsT0FBTyxDQUFDLEdBQUcsWUFBWSxPQUFPO0lBQ2hFO0lBQ0EsS0FBSztHQUNOLENBQUMsQ0FBQztHQUNGLHVCQUE4QixnQkFBZ0IsMEJBQTBCLGFBQWEsVUFBVSxLQUFLO0lBQ25HLE1BQU0sT0FBTztLQUNaLE9BQU8sTUFBTTtLQUNiLE1BQU0sYUFBYTtLQUNuQixNQUFNLGFBQWE7S0FDbkIsTUFBTSxhQUFhO0lBQ3BCO0lBQ0EsQ0FBQyxRQUFRLFVBQVUsR0FBRyxJQUFJLFVBQVUsSUFBSSxLQUFLLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFVLElBQUksQ0FBQyxFQUFDLENBQUUsU0FBUyxhQUFhO0tBQ2xHLFNBQVMsaUJBQWlCO0lBQzNCLENBQUM7R0FDRjtHQUNBLE9BQU8sY0FBYyxNQUFNLFNBQVM7SUFDbkMsV0FBVztJQUNYO0dBQ0QsQ0FBQyxLQUFLO0VBQ1A7Q0FDRDtBQUNELENBQUM7QUFDRCxTQUFTLGNBQWMsTUFBTSxNQUFNO0NBQ2xDLElBQUksQ0FBQyxNQUFNLE9BQU87Q0FDbEIsTUFBTSxjQUFjLEtBQUssSUFBSTtDQUM3QixPQUFPLFlBQVksV0FBVyxJQUFJLFlBQVksS0FBSztBQUNwRDs7OztBQUlBLE1BQU0sYUFBYTtBQUNuQixTQUFTLHNCQUFzQjtDQUM5QixNQUFNLFdBQVcsbUJBQW1CO0NBQ3BDLE1BQU0sYUFBYSxTQUFTLFVBQVUsU0FBUyxPQUFPLEtBQUs7Q0FDM0QsTUFBTSxvQkFBb0IsU0FBUyxVQUFVLFNBQVMsT0FBTyxXQUFXLFNBQVMsT0FBTyxRQUFRO0NBQ2hHLElBQUksZUFBZSxlQUFlLGVBQWUsV0FBVyxTQUFTLFlBQVksTUFBTSxPQUFPLHNCQUFzQixZQUFZLGtCQUFrQixTQUFTLGNBQWM7RUFDeEssTUFBTSxPQUFPLGVBQWUsY0FBYyxlQUFlO0VBQ3pELFlBQVksaUJBQWlCLEVBQUUsS0FBSyxDQUFDO0NBQ3RDO0FBQ0Q7Ozs7Ozs7O0FBUUEsU0FBUyxhQUFhLFNBQVM7Q0FDOUIsTUFBTSxVQUFVLG9CQUFvQixRQUFRLFFBQVEsT0FBTztDQUMzRCxNQUFNLGVBQWUsUUFBUSxjQUFjO0NBQzNDLE1BQU0sbUJBQW1CLFFBQVEsa0JBQWtCO0NBQ25ELE1BQU0sZ0JBQWdCLFFBQVE7Q0FDOUIsc0JBQTZCLGdCQUFnQixDQUFDLGVBQWUsTUFBTSxJQUFJLE1BQU0sb0lBQW9JO0NBQ2pOLE1BQU0sZUFBZSxhQUFhO0NBQ2xDLE1BQU0sc0JBQXNCLGFBQWE7Q0FDekMsTUFBTSxjQUFjLGFBQWE7Q0FDakMsTUFBTSxlQUFlLFdBQVcseUJBQXlCO0NBQ3pELElBQUksa0JBQWtCO0NBQ3RCLElBQUksYUFBYSxRQUFRLGtCQUFrQix1QkFBdUIsU0FBUyxRQUFRLG9CQUFvQjtDQUN2RyxNQUFNLGtCQUFrQixjQUFjLEtBQUssT0FBTyxlQUFlLEtBQUssVUFBVTtDQUNoRixNQUFNLGVBQWUsY0FBYyxLQUFLLE1BQU0sV0FBVztDQUN6RCxNQUFNLGVBQWUsY0FBYyxLQUFLLE1BQU0sTUFBTTtDQUNwRCxTQUFTLFNBQVMsZUFBZSxPQUFPO0VBQ3ZDLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSSxZQUFZLGFBQWEsR0FBRztHQUMvQixTQUFTLFFBQVEsaUJBQWlCLGFBQWE7R0FDL0Msc0JBQTZCLGdCQUFnQixDQUFDLFFBQVEsWUFBWSxpQkFBaUIsRUFBRSxNQUFNLE9BQU8sYUFBYSxFQUFFLENBQUM7R0FDbEgsU0FBUztFQUNWLE9BQU8sU0FBUztFQUNoQixPQUFPLFFBQVEsU0FBUyxRQUFRLE1BQU07Q0FDdkM7Q0FDQSxTQUFTLFlBQVksTUFBTTtFQUMxQixNQUFNLGdCQUFnQixRQUFRLGlCQUFpQixJQUFJO0VBQ25ELElBQUksZUFBZSxRQUFRLFlBQVksYUFBYTtPQUMvQyxzQkFBNkIsY0FBYyxZQUFZLGlCQUFpQixFQUFFLE1BQU0sT0FBTyxJQUFJLEVBQUUsQ0FBQztDQUNwRztDQUNBLFNBQVMsWUFBWTtFQUNwQixPQUFPLFFBQVEsVUFBVSxDQUFDLENBQUMsS0FBSyxpQkFBaUIsYUFBYSxNQUFNO0NBQ3JFO0NBQ0EsU0FBUyxTQUFTLE1BQU07RUFDdkIsT0FBTyxDQUFDLENBQUMsUUFBUSxpQkFBaUIsSUFBSTtDQUN2QztDQUNBLFNBQVMsUUFBUSxhQUFhLGlCQUFpQjtFQUM5QyxrQkFBa0IsT0FBTyxDQUFDLEdBQUcsbUJBQW1CLGFBQWEsS0FBSztFQUNsRSxJQUFJLE9BQU8sZ0JBQWdCLFVBQVU7R0FDcEMsTUFBTSxxQkFBcUIsU0FBUyxjQUFjLGFBQWEsZ0JBQWdCLElBQUk7R0FDbkYsTUFBTSxlQUFlLFFBQVEsUUFBUSxFQUFFLE1BQU0sbUJBQW1CLEtBQUssR0FBRyxlQUFlO0dBQ3ZGLE1BQU0sT0FBTyxjQUFjLFdBQVcsbUJBQW1CLFFBQVE7R0FDakUsc0JBQTZCLGNBQWM7SUFDMUMsSUFBSSxLQUFLLFdBQVcsSUFBSSxHQUFHLFlBQVksaUJBQWlCO0tBQ3ZELFVBQVU7S0FDVjtJQUNELENBQUM7U0FDSSxJQUFJLENBQUMsYUFBYSxRQUFRLFFBQVEsWUFBWSxpQkFBaUIsRUFBRSxNQUFNLFlBQVksQ0FBQztHQUMxRjtHQUNBLE9BQU8sT0FBTyxvQkFBb0IsY0FBYztJQUMvQyxRQUFRLGFBQWEsYUFBYSxNQUFNO0lBQ3hDLGdCQUFnQixLQUFLO0lBQ3JCO0dBQ0QsQ0FBQztFQUNGO0VBQ0Esc0JBQTZCLGdCQUFnQixDQUFDLGdCQUFnQixXQUFXLEdBQUc7R0FDM0UsWUFBWSxpQkFBaUIsRUFBRSxZQUFZLENBQUM7R0FDNUMsT0FBTyxRQUFRLENBQUMsQ0FBQztFQUNsQjtFQUNBLElBQUk7RUFDSixJQUFJLFlBQVksUUFBUSxNQUFNO0dBQzdCLHNCQUE2QixnQkFBZ0IsWUFBWSxlQUFlLEVBQUUsVUFBVSxnQkFBZ0IsT0FBTyxLQUFLLFlBQVksTUFBTSxDQUFDLENBQUMsUUFBUSxZQUFZLGlCQUFpQixFQUFFLE1BQU0sWUFBWSxLQUFLLENBQUM7R0FDbk0sa0JBQWtCLE9BQU8sQ0FBQyxHQUFHLGFBQWEsRUFBRSxNQUFNLFNBQVMsY0FBYyxZQUFZLE1BQU0sZ0JBQWdCLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQztFQUN4SCxPQUFPO0dBQ04sTUFBTSxlQUFlLE9BQU8sQ0FBQyxHQUFHLFlBQVksTUFBTTtHQUNsRCxLQUFLLE1BQU0sT0FBTyxjQUFjLElBQUksYUFBYSxRQUFRLE1BQU0sT0FBTyxhQUFhO0dBQ25GLGtCQUFrQixPQUFPLENBQUMsR0FBRyxhQUFhLEVBQUUsUUFBUSxhQUFhLFlBQVksRUFBRSxDQUFDO0dBQ2hGLGdCQUFnQixTQUFTLGFBQWEsZ0JBQWdCLE1BQU07RUFDN0Q7RUFDQSxNQUFNLGVBQWUsUUFBUSxRQUFRLGlCQUFpQixlQUFlO0VBQ3JFLE1BQU0sT0FBTyxZQUFZLFFBQVE7RUFDakMsc0JBQTZCLGdCQUFnQixRQUFRLENBQUMsS0FBSyxXQUFXLEdBQUcsR0FBRyxZQUFZLGlCQUFpQixFQUFFLEtBQUssQ0FBQztFQUNqSCxhQUFhLFNBQVMsZ0JBQWdCLGFBQWEsYUFBYSxNQUFNLENBQUM7RUFDdkUsTUFBTSxXQUFXLGFBQWEsa0JBQWtCLE9BQU8sQ0FBQyxHQUFHLGFBQWE7R0FDdkUsTUFBTSxXQUFXLElBQUk7R0FDckIsTUFBTSxhQUFhO0VBQ3BCLENBQUMsQ0FBQztFQUNGLE1BQU0sT0FBTyxjQUFjLFdBQVcsUUFBUTtFQUM5QyxzQkFBNkIsY0FBYztHQUMxQyxJQUFJLEtBQUssV0FBVyxJQUFJLEdBQUcsWUFBWSxpQkFBaUI7SUFDdkQsVUFBVTtJQUNWO0dBQ0QsQ0FBQztRQUNJLElBQUksQ0FBQyxhQUFhLFFBQVEsUUFBUSxZQUFZLGlCQUFpQixFQUFFLE1BQU0sWUFBWSxRQUFRLE9BQU8sWUFBWSxPQUFPLFlBQVksQ0FBQztFQUN4STtFQUNBLE9BQU8sT0FBTztHQUNiO0dBQ0E7R0FDQSxPQUFPLHFCQUFxQixpQkFBaUIsZUFBZSxZQUFZLEtBQUssSUFBSSxZQUFZLFNBQVMsQ0FBQztFQUN4RyxHQUFHLGNBQWM7R0FDaEIsZ0JBQWdCLEtBQUs7R0FDckI7RUFDRCxDQUFDO0NBQ0Y7Q0FDQSxTQUFTLGlCQUFpQixJQUFJO0VBQzdCLE9BQU8sT0FBTyxPQUFPLFdBQVcsU0FBUyxjQUFjLElBQUksYUFBYSxNQUFNLElBQUksSUFBSSxPQUFPLENBQUMsR0FBRyxFQUFFO0NBQ3BHO0NBQ0EsU0FBUyx3QkFBd0IsSUFBSSxNQUFNO0VBQzFDLElBQUksb0JBQW9CLElBQUksT0FBTyxrQkFBa0IsR0FBRztHQUN2RDtHQUNBO0VBQ0QsQ0FBQztDQUNGO0NBQ0EsU0FBUyxLQUFLLElBQUk7RUFDakIsT0FBTyxpQkFBaUIsRUFBRTtDQUMzQjtDQUNBLFNBQVMsUUFBUSxJQUFJO0VBQ3BCLE9BQU8sS0FBSyxPQUFPLGlCQUFpQixFQUFFLEdBQUcsRUFBRSxTQUFTLEtBQUssQ0FBQyxDQUFDO0NBQzVEO0NBQ0EsU0FBUyxxQkFBcUIsSUFBSSxNQUFNO0VBQ3ZDLE1BQU0sY0FBYyxHQUFHLFFBQVEsR0FBRyxRQUFRLFNBQVM7RUFDbkQsSUFBSSxlQUFlLFlBQVksVUFBVTtHQUN4QyxNQUFNLEVBQUUsYUFBYTtHQUNyQixJQUFJLG9CQUFvQixPQUFPLGFBQWEsYUFBYSxTQUFTLElBQUksSUFBSSxJQUFJO0dBQzlFLElBQUksT0FBTyxzQkFBc0IsVUFBVTtJQUMxQyxvQkFBb0Isa0JBQWtCLFNBQVMsR0FBRyxLQUFLLGtCQUFrQixTQUFTLEdBQUcsSUFBSSxvQkFBb0IsaUJBQWlCLGlCQUFpQixJQUFJLEVBQUUsTUFBTSxrQkFBa0I7SUFDN0ssa0JBQWtCLFNBQVMsQ0FBQztHQUM3QjtHQUNBLHNCQUE2QixnQkFBZ0Isa0JBQWtCLFFBQVEsUUFBUSxFQUFFLFVBQVUsb0JBQW9CO0lBQzlHLFlBQVksaUJBQWlCO0tBQzVCLFFBQVEsS0FBSyxVQUFVLG1CQUFtQixNQUFNLENBQUM7S0FDakQsSUFBSSxHQUFHO0lBQ1IsQ0FBQztJQUNELE1BQU0sSUFBSSxNQUFNLGtCQUFrQjtHQUNuQztHQUNBLE9BQU8sT0FBTztJQUNiLE9BQU8sR0FBRztJQUNWLE1BQU0sR0FBRztJQUNULFFBQVEsa0JBQWtCLFFBQVEsT0FBTyxDQUFDLElBQUksR0FBRztHQUNsRCxHQUFHLGlCQUFpQjtFQUNyQjtDQUNEO0NBQ0EsU0FBUyxpQkFBaUIsSUFBSSxnQkFBZ0I7RUFDN0MsTUFBTSxpQkFBaUIsa0JBQWtCLFFBQVEsRUFBRTtFQUNuRCxNQUFNLE9BQU8sYUFBYTtFQUMxQixNQUFNLE9BQU8sR0FBRztFQUNoQixNQUFNLFFBQVEsR0FBRztFQUNqQixNQUFNLFVBQVUsR0FBRyxZQUFZO0VBQy9CLE1BQU0saUJBQWlCLHFCQUFxQixnQkFBZ0IsSUFBSTtFQUNoRSxJQUFJLGdCQUFnQixPQUFPLGlCQUFpQixPQUFPLGlCQUFpQixjQUFjLEdBQUc7R0FDcEYsT0FBTyxPQUFPLG1CQUFtQixXQUFXLE9BQU8sQ0FBQyxHQUFHLE1BQU0sZUFBZSxLQUFLLElBQUk7R0FDckY7R0FDQTtFQUNELENBQUMsR0FBRyxrQkFBa0IsY0FBYztFQUNwQyxNQUFNLGFBQWE7RUFDbkIsV0FBVyxpQkFBaUI7RUFDNUIsSUFBSTtFQUNKLElBQUksQ0FBQyxTQUFTLG9CQUFvQixrQkFBa0IsTUFBTSxjQUFjLEdBQUc7R0FDMUUsVUFBVSxrQkFBa0IsSUFBSTtJQUMvQixJQUFJO0lBQ0o7R0FDRCxDQUFDO0dBQ0QsYUFBYSxNQUFNLE1BQU0sTUFBTSxLQUFLO0VBQ3JDO0VBQ0EsUUFBUSxVQUFVLFFBQVEsUUFBUSxPQUFPLElBQUksU0FBUyxZQUFZLElBQUksRUFBQyxDQUFFLE9BQU8sVUFBVSxvQkFBb0IsS0FBSyxJQUFJLG9CQUFvQixPQUFPLENBQUMsSUFBSSxRQUFRLFlBQVksS0FBSyxJQUFJLGFBQWEsT0FBTyxZQUFZLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxZQUFZO0dBQzVPLElBQUksU0FBUztJQUNaLElBQUksb0JBQW9CLFNBQVMsQ0FBQyxHQUFHO0tBQ3BDLHNCQUE2QixnQkFBZ0Isb0JBQW9CLGtCQUFrQixRQUFRLFFBQVEsRUFBRSxHQUFHLFVBQVUsS0FBSyxtQkFBbUIsZUFBZSxTQUFTLGVBQWUsU0FBUyxlQUFlLFNBQVMsSUFBSSxLQUFLLElBQUk7TUFDOU4sWUFBWSxpQkFBaUI7T0FDNUIsTUFBTSxLQUFLO09BQ1gsSUFBSSxXQUFXO01BQ2hCLENBQUM7TUFDRCxPQUFPLFFBQVEsdUJBQXVCLElBQUksTUFBTSx1Q0FBdUMsQ0FBQztLQUN6RjtLQUNBLE9BQU8saUJBQWlCLE9BQU8sRUFBRSxRQUFRLEdBQUcsaUJBQWlCLFFBQVEsRUFBRSxHQUFHO01BQ3pFLE9BQU8sT0FBTyxRQUFRLE9BQU8sV0FBVyxPQUFPLENBQUMsR0FBRyxNQUFNLFFBQVEsR0FBRyxLQUFLLElBQUk7TUFDN0U7S0FDRCxDQUFDLEdBQUcsa0JBQWtCLFVBQVU7SUFDakM7R0FDRCxPQUFPLFVBQVUsbUJBQW1CLFlBQVksTUFBTSxNQUFNLFNBQVMsSUFBSTtHQUN6RSxpQkFBaUIsWUFBWSxNQUFNLE9BQU87R0FDMUMsT0FBTztFQUNSLENBQUM7Q0FDRjs7Ozs7O0NBTUEsU0FBUyxpQ0FBaUMsSUFBSSxNQUFNO0VBQ25ELE1BQU0sUUFBUSx3QkFBd0IsSUFBSSxJQUFJO0VBQzlDLE9BQU8sUUFBUSxRQUFRLE9BQU8sS0FBSyxJQUFJLFFBQVEsUUFBUTtDQUN4RDtDQUNBLFNBQVMsZUFBZSxJQUFJO0VBQzNCLE1BQU0sTUFBTSxjQUFjLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0VBQzFDLE9BQU8sT0FBTyxPQUFPLElBQUksbUJBQW1CLGFBQWEsSUFBSSxlQUFlLEVBQUUsSUFBSSxHQUFHO0NBQ3RGO0NBQ0EsU0FBUyxTQUFTLElBQUksTUFBTTtFQUMzQixJQUFJO0VBQ0osTUFBTSxDQUFDLGdCQUFnQixpQkFBaUIsbUJBQW1CLHVCQUF1QixJQUFJLElBQUk7RUFDMUYsU0FBUyx3QkFBd0IsZUFBZSxRQUFRLEdBQUcsb0JBQW9CLElBQUksSUFBSTtFQUN2RixLQUFLLE1BQU0sVUFBVSxnQkFBZ0IsT0FBTyxZQUFZLFNBQVMsVUFBVTtHQUMxRSxPQUFPLEtBQUssaUJBQWlCLE9BQU8sSUFBSSxJQUFJLENBQUM7RUFDOUMsQ0FBQztFQUNELE1BQU0sMEJBQTBCLGlDQUFpQyxLQUFLLE1BQU0sSUFBSSxJQUFJO0VBQ3BGLE9BQU8sS0FBSyx1QkFBdUI7RUFDbkMsT0FBTyxjQUFjLE1BQU0sQ0FBQyxDQUFDLFdBQVc7R0FDdkMsU0FBUyxDQUFDO0dBQ1YsS0FBSyxNQUFNLFNBQVMsYUFBYSxLQUFLLEdBQUcsT0FBTyxLQUFLLGlCQUFpQixPQUFPLElBQUksSUFBSSxDQUFDO0dBQ3RGLE9BQU8sS0FBSyx1QkFBdUI7R0FDbkMsT0FBTyxjQUFjLE1BQU07RUFDNUIsQ0FBQyxDQUFDLENBQUMsV0FBVztHQUNiLFNBQVMsd0JBQXdCLGlCQUFpQixxQkFBcUIsSUFBSSxJQUFJO0dBQy9FLEtBQUssTUFBTSxVQUFVLGlCQUFpQixPQUFPLGFBQWEsU0FBUyxVQUFVO0lBQzVFLE9BQU8sS0FBSyxpQkFBaUIsT0FBTyxJQUFJLElBQUksQ0FBQztHQUM5QyxDQUFDO0dBQ0QsT0FBTyxLQUFLLHVCQUF1QjtHQUNuQyxPQUFPLGNBQWMsTUFBTTtFQUM1QixDQUFDLENBQUMsQ0FBQyxXQUFXO0dBQ2IsU0FBUyxDQUFDO0dBQ1YsS0FBSyxNQUFNLFVBQVUsaUJBQWlCLElBQUksT0FBTyxhQUFhLElBQUksUUFBUSxPQUFPLFdBQVcsR0FBRyxLQUFLLE1BQU0sZUFBZSxPQUFPLGFBQWEsT0FBTyxLQUFLLGlCQUFpQixhQUFhLElBQUksSUFBSSxDQUFDO1FBQzNMLE9BQU8sS0FBSyxpQkFBaUIsT0FBTyxhQUFhLElBQUksSUFBSSxDQUFDO0dBQy9ELE9BQU8sS0FBSyx1QkFBdUI7R0FDbkMsT0FBTyxjQUFjLE1BQU07RUFDNUIsQ0FBQyxDQUFDLENBQUMsV0FBVztHQUNiLEdBQUcsUUFBUSxTQUFTLFdBQVcsT0FBTyxpQkFBaUIsQ0FBQyxDQUFDO0dBQ3pELFNBQVMsd0JBQXdCLGlCQUFpQixvQkFBb0IsSUFBSSxNQUFNLGNBQWM7R0FDOUYsT0FBTyxLQUFLLHVCQUF1QjtHQUNuQyxPQUFPLGNBQWMsTUFBTTtFQUM1QixDQUFDLENBQUMsQ0FBQyxXQUFXO0dBQ2IsU0FBUyxDQUFDO0dBQ1YsS0FBSyxNQUFNLFNBQVMsb0JBQW9CLEtBQUssR0FBRyxPQUFPLEtBQUssaUJBQWlCLE9BQU8sSUFBSSxJQUFJLENBQUM7R0FDN0YsT0FBTyxLQUFLLHVCQUF1QjtHQUNuQyxPQUFPLGNBQWMsTUFBTTtFQUM1QixDQUFDLENBQUMsQ0FBQyxPQUFPLFFBQVEsb0JBQW9CLEtBQUssQ0FBQyxJQUFJLE1BQU0sUUFBUSxPQUFPLEdBQUcsQ0FBQztDQUMxRTtDQUNBLFNBQVMsaUJBQWlCLElBQUksTUFBTSxTQUFTO0VBQzVDLFlBQVksS0FBSyxDQUFDLENBQUMsU0FBUyxVQUFVLHFCQUFxQixNQUFNLElBQUksTUFBTSxPQUFPLENBQUMsQ0FBQztDQUNyRjs7Ozs7O0NBTUEsU0FBUyxtQkFBbUIsWUFBWSxNQUFNLFFBQVEsU0FBUyxNQUFNO0VBQ3BFLE1BQU0sUUFBUSx3QkFBd0IsWUFBWSxJQUFJO0VBQ3RELElBQUksT0FBTyxPQUFPO0VBQ2xCLE1BQU0sb0JBQW9CLFNBQVM7RUFDbkMsTUFBTSxRQUFRLENBQUMsWUFBWSxDQUFDLElBQUksUUFBUTtFQUN4QyxJQUFJLFFBQVEsSUFBSSxXQUFXLG1CQUFtQixjQUFjLFFBQVEsV0FBVyxVQUFVLE9BQU8sRUFBRSxRQUFRLHFCQUFxQixTQUFTLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQztPQUN4SixjQUFjLEtBQUssV0FBVyxVQUFVLElBQUk7RUFDakQsYUFBYSxRQUFRO0VBQ3JCLGFBQWEsWUFBWSxNQUFNLFFBQVEsaUJBQWlCO0VBQ3hELFlBQVk7Q0FDYjtDQUNBLElBQUk7Q0FDSixTQUFTLGlCQUFpQjtFQUN6QixJQUFJLHVCQUF1QjtFQUMzQix3QkFBd0IsY0FBYyxRQUFRLElBQUksT0FBTyxTQUFTO0dBQ2pFLElBQUksQ0FBQyxPQUFPLFdBQVc7R0FDdkIsTUFBTSxhQUFhLFFBQVEsRUFBRTtHQUM3QixNQUFNLGlCQUFpQixxQkFBcUIsWUFBWSxPQUFPLGFBQWEsS0FBSztHQUNqRixJQUFJLGdCQUFnQjtJQUNuQixpQkFBaUIsT0FBTyxnQkFBZ0I7S0FDdkMsU0FBUztLQUNULE9BQU87SUFDUixDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUMsTUFBTSxJQUFJO0lBQzFCO0dBQ0Q7R0FDQSxrQkFBa0I7R0FDbEIsTUFBTSxPQUFPLGFBQWE7R0FDMUIsSUFBSSxXQUFXLG1CQUFtQixhQUFhLEtBQUssVUFBVSxLQUFLLEtBQUssR0FBRyxzQkFBc0IsQ0FBQztHQUNsRyxTQUFTLFlBQVksSUFBSSxDQUFDLENBQUMsT0FBTyxVQUFVO0lBQzNDLElBQUksb0JBQW9CLE9BQU8sRUFBRSxHQUFHLE9BQU87SUFDM0MsSUFBSSxvQkFBb0IsT0FBTyxDQUFDLEdBQUc7S0FDbEMsaUJBQWlCLE9BQU8saUJBQWlCLE1BQU0sRUFBRSxHQUFHLEVBQUUsT0FBTyxLQUFLLENBQUMsR0FBRyxVQUFVLENBQUMsQ0FBQyxNQUFNLFlBQVk7TUFDbkcsSUFBSSxvQkFBb0IsU0FBUyxFQUFFLEtBQUssQ0FBQyxLQUFLLFNBQVMsS0FBSyxTQUFTLE9BQU8sY0FBYyxHQUFHLENBQUMsR0FBRyxLQUFLO0tBQ3ZHLENBQUMsQ0FBQyxDQUFDLE1BQU0sSUFBSTtLQUNiLE9BQU8sUUFBUSxPQUFPO0lBQ3ZCO0lBQ0EsSUFBSSxLQUFLLE9BQU8sY0FBYyxHQUFHLENBQUMsS0FBSyxPQUFPLEtBQUs7SUFDbkQsT0FBTyxhQUFhLE9BQU8sWUFBWSxJQUFJO0dBQzVDLENBQUMsQ0FBQyxDQUFDLE1BQU0sWUFBWTtJQUNwQixVQUFVLFdBQVcsbUJBQW1CLFlBQVksTUFBTSxLQUFLO0lBQy9ELElBQUksU0FBUztLQUNaLElBQUksS0FBSyxTQUFTLENBQUMsb0JBQW9CLFNBQVMsQ0FBQyxHQUFHLGNBQWMsR0FBRyxDQUFDLEtBQUssT0FBTyxLQUFLO1VBQ2xGLElBQUksS0FBSyxTQUFTLFNBQVMsb0JBQW9CLFNBQVMsRUFBRSxHQUFHLGNBQWMsR0FBRyxDQUFDLEdBQUcsS0FBSztJQUM3RjtJQUNBLGlCQUFpQixZQUFZLE1BQU0sT0FBTztHQUMzQyxDQUFDLENBQUMsQ0FBQyxNQUFNLElBQUk7RUFDZCxDQUFDO0NBQ0Y7Q0FDQSxJQUFJLGdCQUFnQixhQUFhO0NBQ2pDLElBQUksaUJBQWlCLGFBQWE7Q0FDbEMsSUFBSTs7Ozs7Ozs7O0NBU0osU0FBUyxhQUFhLE9BQU8sSUFBSSxNQUFNO0VBQ3RDLFlBQVksS0FBSztFQUNqQixNQUFNLE9BQU8sZUFBZSxLQUFLO0VBQ2pDLElBQUksS0FBSyxRQUFRLEtBQUssU0FBUyxZQUFZLFFBQVEsT0FBTyxJQUFJLElBQUksQ0FBQztPQUM5RDtHQUNKLHNCQUE2QixjQUFjLFlBQVksaUJBQWlCO0dBQ3hFLFFBQVEsTUFBTSxLQUFLO0VBQ3BCO0VBQ0EsT0FBTyxRQUFRLE9BQU8sS0FBSztDQUM1QjtDQUNBLFNBQVMsVUFBVTtFQUNsQixJQUFJLFNBQVMsYUFBYSxVQUFVLDJCQUEyQixPQUFPLFFBQVEsUUFBUTtFQUN0RixPQUFPLElBQUksU0FBUyxTQUFTLFdBQVc7R0FDdkMsY0FBYyxJQUFJLENBQUMsU0FBUyxNQUFNLENBQUM7RUFDcEMsQ0FBQztDQUNGO0NBQ0EsU0FBUyxZQUFZLEtBQUs7RUFDekIsSUFBSSxDQUFDLE9BQU87R0FDWCxRQUFRLENBQUM7R0FDVCxlQUFlO0dBQ2YsY0FBYyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsU0FBUyxZQUFZLE1BQU0sT0FBTyxHQUFHLElBQUksUUFBUSxDQUFDO0dBQ2pGLGNBQWMsTUFBTTtFQUNyQjtFQUNBLE9BQU87Q0FDUjtDQUNBLFNBQVMsYUFBYSxJQUFJLE1BQU0sUUFBUSxtQkFBbUI7RUFDMUQsTUFBTSxFQUFFLG1CQUFtQjtFQUMzQixJQUFJLENBQUMsYUFBYSxDQUFDLGdCQUFnQixPQUFPLFFBQVEsUUFBUTtFQUMxRCxNQUFNLGlCQUFpQixDQUFDLFVBQVUsdUJBQXVCLGFBQWEsR0FBRyxVQUFVLENBQUMsQ0FBQyxNQUFNLHFCQUFxQixDQUFDLFdBQVcsUUFBUSxTQUFTLFFBQVEsTUFBTSxVQUFVO0VBQ3JLLE9BQU8sU0FBUyxDQUFDLENBQUMsV0FBVyxlQUFlLElBQUksTUFBTSxjQUFjLENBQUMsQ0FBQyxDQUFDLE1BQU0sYUFBYSxPQUFPLGFBQWEsU0FBUyxZQUFZLGlCQUFpQixRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sUUFBUSxPQUFPLGFBQWEsU0FBUyxhQUFhLEtBQUssSUFBSSxJQUFJLENBQUM7Q0FDdk87Q0FDQSxNQUFNLE1BQU0sVUFBVSxjQUFjLEdBQUcsS0FBSztDQUM1QyxJQUFJO0NBQ0osTUFBTSxnQ0FBZ0MsSUFBSSxJQUFJO0NBQzlDLE1BQU0sU0FBUztFQUNkO0VBQ0EsV0FBVztFQUNYO0VBQ0E7RUFDQSxhQUFhLFFBQVE7RUFDckI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxZQUFZLEdBQUcsQ0FBQyxDQUFDO0VBQ2pCLGVBQWUsR0FBRyxDQUFDO0VBQ25CLFlBQVksYUFBYTtFQUN6QixlQUFlLG9CQUFvQjtFQUNuQyxXQUFXLFlBQVk7RUFDdkIsU0FBUyxlQUFlO0VBQ3hCO0VBQ0EsUUFBUSxLQUFLO0dBQ1osSUFBSSxVQUFVLGNBQWMsVUFBVTtHQUN0QyxJQUFJLFVBQVUsY0FBYyxVQUFVO0dBQ3RDLElBQUksT0FBTyxpQkFBaUIsVUFBVTtHQUN0QyxPQUFPLGVBQWUsSUFBSSxPQUFPLGtCQUFrQixVQUFVO0lBQzVELFlBQVk7SUFDWixXQUFXLE1BQU0sWUFBWTtHQUM5QixDQUFDO0dBQ0QsSUFBSSxhQUFhLENBQUMsV0FBVyxhQUFhLFVBQVUsMkJBQTJCO0lBQzlFLFVBQVU7SUFDVixLQUFLLGNBQWMsUUFBUSxDQUFDLENBQUMsT0FBTyxRQUFRO0tBQzNDLHNCQUE2QixjQUFjLFlBQVksaUJBQWlCLEVBQUUsT0FBTyxJQUFJLENBQUM7SUFDdkYsQ0FBQztHQUNGO0dBQ0EsTUFBTSxnQkFBZ0IsQ0FBQztHQUN2QixLQUFLLE1BQU0sT0FBTywyQkFBMkIsT0FBTyxlQUFlLGVBQWUsS0FBSztJQUN0RixXQUFXLGFBQWEsTUFBTTtJQUM5QixZQUFZO0dBQ2IsQ0FBQztHQUNELElBQUksUUFBUSxXQUFXLE1BQU07R0FDN0IsSUFBSSxRQUFRLGtCQUFrQixnQkFBZ0IsYUFBYSxDQUFDO0dBQzVELElBQUksUUFBUSx1QkFBdUIsWUFBWTtHQUMvQyxNQUFNLGFBQWEsSUFBSTtHQUN2QixjQUFjLElBQUksR0FBRztHQUNyQixJQUFJLFVBQVUsV0FBVztJQUN4QixjQUFjLE9BQU8sR0FBRztJQUN4QixJQUFJLGNBQWMsT0FBTyxHQUFHO0tBQzNCLGtCQUFrQjtLQUNsQix5QkFBeUIsc0JBQXNCO0tBQy9DLHdCQUF3QjtLQUN4QixhQUFhLFFBQVE7S0FDckIsVUFBVTtLQUNWLFFBQVE7SUFDVDtJQUNBLFdBQVc7R0FDWjtHQUNBLHVCQUE4QixnQkFBZ0IsMEJBQTBCLGFBQWEsTUFBTSxZQUFZLEtBQUssUUFBUSxPQUFPO0VBQzVIO0NBQ0Q7Q0FDQSxTQUFTLGNBQWMsUUFBUTtFQUM5QixPQUFPLE9BQU8sUUFBUSxTQUFTLFVBQVUsUUFBUSxXQUFXLGVBQWUsS0FBSyxDQUFDLEdBQUcsUUFBUSxRQUFRLENBQUM7Q0FDdEc7Q0FDQSxPQUFPO0FBQ1I7O0FBRUEsU0FBUyx1QkFBdUIsWUFBWSxZQUFZLDZCQUE2QixnQkFBZ0IscUJBQXFCLGNBQWMscUJBQXFCLHNCQUFzQixrQkFBa0IscUJBQXFCLG1CQUFtQixpQkFBaUIsb0JBQW9CLHFCQUFxQixZQUFZLGtCQUFrQixXQUFXLHVCQUF1QixnQkFBZ0IsU0FBUyxVQUFVLFdBQVciLCJuYW1lcyI6W10sInNvdXJjZXMiOlsidnVlLXJvdXRlci5qcz92PTdlNzNhZmMyIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuKiB2dWUtcm91dGVyIHY1LjIuMFxuKiAoYykgMjAyNiBFZHVhcmRvIFNhbiBNYXJ0aW4gTW9yb3RlXG4qIEBsaWNlbnNlIE1JVFxuKi9cbmltcG9ydCB7IEMgYXMgaXNTYW1lUm91dGVMb2NhdGlvbiwgRSBhcyBwYXJzZVVSTCwgRiBhcyBpc0Jyb3dzZXIsIE0gYXMgZW5jb2RlSGFzaCwgTiBhcyBlbmNvZGVQYXJhbSwgTyBhcyBzdHJpbmdpZnlVUkwsIFMgYXMgU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRCwgVCBhcyBpc1NhbWVSb3V0ZVJlY29yZCwgXyBhcyBzYXZlU2Nyb2xsUG9zaXRpb24sIGEgYXMgbG9hZFJvdXRlTG9jYXRpb24sIGIgYXMgbm9ybWFsaXplQmFzZSwgYyBhcyB1c2VDYWxsYmFja3MsIGQgYXMgc3RyaW5naWZ5UXVlcnksIGYgYXMgaXNSb3V0ZUxvY2F0aW9uLCBnIGFzIGdldFNjcm9sbEtleSwgaCBhcyBnZXRTYXZlZFNjcm9sbFBvc2l0aW9uLCBpIGFzIGd1YXJkVG9Qcm9taXNlRm4sIGogYXMgZGVjb2RlLCBrIGFzIHN0cmlwQmFzZSwgbCBhcyBub3JtYWxpemVRdWVyeSwgbSBhcyBjb21wdXRlU2Nyb2xsUG9zaXRpb24sIG4gYXMgZXh0cmFjdENoYW5naW5nUmVjb3JkcywgbyBhcyBvbkJlZm9yZVJvdXRlTGVhdmUsIHAgYXMgaXNSb3V0ZU5hbWUsIHIgYXMgZXh0cmFjdENvbXBvbmVudHNHdWFyZHMsIHMgYXMgb25CZWZvcmVSb3V0ZVVwZGF0ZSwgdCBhcyBhZGREZXZ0b29scywgdSBhcyBwYXJzZVF1ZXJ5LCB2IGFzIHNjcm9sbFRvUG9zaXRpb24sIHcgYXMgaXNTYW1lUm91dGVMb2NhdGlvblBhcmFtcywgeSBhcyBjcmVhdGVIcmVmIH0gZnJvbSBcIi4vZGV2dG9vbHMtQnByN1pBVkIuanNcIjtcbmltcG9ydCB7IGEgYXMgcm91dGVyS2V5LCBjIGFzIGRpYWdub3N0aWNzLCBkIGFzIGlzTmF2aWdhdGlvbkZhaWx1cmUsIGYgYXMgYXBwbHlUb1BhcmFtcywgaCBhcyBpc0FycmF5LCBpIGFzIHJvdXRlTG9jYXRpb25LZXksIGwgYXMgTmF2aWdhdGlvbkZhaWx1cmVUeXBlLCBuIGFzIHVzZVJvdXRlciwgbyBhcyByb3V0ZXJWaWV3TG9jYXRpb25LZXksIHAgYXMgYXNzaWduLCByIGFzIG1hdGNoZWRSb3V0ZUtleSwgcyBhcyB2aWV3RGVwdGhLZXksIHQgYXMgdXNlUm91dGUsIHUgYXMgY3JlYXRlUm91dGVyRXJyb3IsIHYgYXMgbWVyZ2VPcHRpb25zLCB5IGFzIG5vb3AgfSBmcm9tIFwiLi91c2VBcGktQ1JPSkpkaEUuanNcIjtcbmltcG9ydCB7IGNvbXB1dGVkLCBkZWZpbmVDb21wb25lbnQsIGdldEN1cnJlbnRJbnN0YW5jZSwgaCwgaW5qZWN0LCBuZXh0VGljaywgcHJvdmlkZSwgcmVhY3RpdmUsIHJlZiwgc2hhbGxvd1JlYWN0aXZlLCBzaGFsbG93UmVmLCB1bnJlZiwgd2F0Y2gsIHdhdGNoRWZmZWN0IH0gZnJvbSBcInZ1ZVwiO1xuLy8jcmVnaW9uIHNyYy9oaXN0b3J5L2h0bWw1LnRzXG5sZXQgY3JlYXRlQmFzZUxvY2F0aW9uID0gKCkgPT4gbG9jYXRpb24ucHJvdG9jb2wgKyBcIi8vXCIgKyBsb2NhdGlvbi5ob3N0O1xuLyoqXG4qIENyZWF0ZXMgYSBub3JtYWxpemVkIGhpc3RvcnkgbG9jYXRpb24gZnJvbSBhIHdpbmRvdy5sb2NhdGlvbiBvYmplY3RcbiogQHBhcmFtIGJhc2UgLSBUaGUgYmFzZSBwYXRoXG4qIEBwYXJhbSBsb2NhdGlvbiAtIFRoZSB3aW5kb3cubG9jYXRpb24gb2JqZWN0XG4qL1xuZnVuY3Rpb24gY3JlYXRlQ3VycmVudExvY2F0aW9uKGJhc2UsIGxvY2F0aW9uKSB7XG5cdGNvbnN0IHsgcGF0aG5hbWUsIHNlYXJjaCwgaGFzaCB9ID0gbG9jYXRpb247XG5cdGNvbnN0IGhhc2hQb3MgPSBiYXNlLmluZGV4T2YoXCIjXCIpO1xuXHRpZiAoaGFzaFBvcyA+IC0xKSB7XG5cdFx0bGV0IHNsaWNlUG9zID0gaGFzaC5pbmNsdWRlcyhiYXNlLnNsaWNlKGhhc2hQb3MpKSA/IGJhc2Uuc2xpY2UoaGFzaFBvcykubGVuZ3RoIDogMTtcblx0XHRsZXQgcGF0aEZyb21IYXNoID0gaGFzaC5zbGljZShzbGljZVBvcyk7XG5cdFx0aWYgKHBhdGhGcm9tSGFzaFswXSAhPT0gXCIvXCIpIHBhdGhGcm9tSGFzaCA9IFwiL1wiICsgcGF0aEZyb21IYXNoO1xuXHRcdHJldHVybiBzdHJpcEJhc2UocGF0aEZyb21IYXNoLCBcIlwiKTtcblx0fVxuXHRyZXR1cm4gc3RyaXBCYXNlKHBhdGhuYW1lLCBiYXNlKSArIHNlYXJjaCArIGhhc2g7XG59XG5mdW5jdGlvbiB1c2VIaXN0b3J5TGlzdGVuZXJzKGJhc2UsIGhpc3RvcnlTdGF0ZSwgY3VycmVudExvY2F0aW9uLCByZXBsYWNlKSB7XG5cdGxldCBsaXN0ZW5lcnMgPSBbXTtcblx0bGV0IHRlYXJkb3ducyA9IFtdO1xuXHRsZXQgcGF1c2VTdGF0ZSA9IG51bGw7XG5cdGNvbnN0IHBvcFN0YXRlSGFuZGxlciA9ICh7IHN0YXRlIH0pID0+IHtcblx0XHRjb25zdCB0byA9IGNyZWF0ZUN1cnJlbnRMb2NhdGlvbihiYXNlLCBsb2NhdGlvbik7XG5cdFx0Y29uc3QgZnJvbSA9IGN1cnJlbnRMb2NhdGlvbi52YWx1ZTtcblx0XHRjb25zdCBmcm9tU3RhdGUgPSBoaXN0b3J5U3RhdGUudmFsdWU7XG5cdFx0bGV0IGRlbHRhID0gMDtcblx0XHRpZiAoc3RhdGUpIHtcblx0XHRcdGN1cnJlbnRMb2NhdGlvbi52YWx1ZSA9IHRvO1xuXHRcdFx0aGlzdG9yeVN0YXRlLnZhbHVlID0gc3RhdGU7XG5cdFx0XHRpZiAocGF1c2VTdGF0ZSAmJiBwYXVzZVN0YXRlID09PSBmcm9tKSB7XG5cdFx0XHRcdHBhdXNlU3RhdGUgPSBudWxsO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0XHRkZWx0YSA9IGZyb21TdGF0ZSA/IHN0YXRlLnBvc2l0aW9uIC0gZnJvbVN0YXRlLnBvc2l0aW9uIDogMDtcblx0XHR9IGVsc2UgcmVwbGFjZSh0byk7XG5cdFx0bGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiB7XG5cdFx0XHRsaXN0ZW5lcihjdXJyZW50TG9jYXRpb24udmFsdWUsIGZyb20sIHtcblx0XHRcdFx0ZGVsdGEsXG5cdFx0XHRcdHR5cGU6IFwicG9wXCIsXG5cdFx0XHRcdGRpcmVjdGlvbjogZGVsdGEgPyBkZWx0YSA+IDAgPyBcImZvcndhcmRcIiA6IFwiYmFja1wiIDogXCJcIlxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdH07XG5cdGZ1bmN0aW9uIHBhdXNlTGlzdGVuZXJzKCkge1xuXHRcdHBhdXNlU3RhdGUgPSBjdXJyZW50TG9jYXRpb24udmFsdWU7XG5cdH1cblx0ZnVuY3Rpb24gbGlzdGVuKGNhbGxiYWNrKSB7XG5cdFx0bGlzdGVuZXJzLnB1c2goY2FsbGJhY2spO1xuXHRcdGNvbnN0IHRlYXJkb3duID0gKCkgPT4ge1xuXHRcdFx0Y29uc3QgaW5kZXggPSBsaXN0ZW5lcnMuaW5kZXhPZihjYWxsYmFjayk7XG5cdFx0XHRpZiAoaW5kZXggPiAtMSkgbGlzdGVuZXJzLnNwbGljZShpbmRleCwgMSk7XG5cdFx0fTtcblx0XHR0ZWFyZG93bnMucHVzaCh0ZWFyZG93bik7XG5cdFx0cmV0dXJuIHRlYXJkb3duO1xuXHR9XG5cdGZ1bmN0aW9uIGJlZm9yZVVubG9hZExpc3RlbmVyKCkge1xuXHRcdGlmIChkb2N1bWVudC52aXNpYmlsaXR5U3RhdGUgPT09IFwiaGlkZGVuXCIpIHtcblx0XHRcdGNvbnN0IHsgaGlzdG9yeSB9ID0gd2luZG93O1xuXHRcdFx0aWYgKCFoaXN0b3J5LnN0YXRlKSByZXR1cm47XG5cdFx0XHRoaXN0b3J5LnJlcGxhY2VTdGF0ZShhc3NpZ24oe30sIGhpc3Rvcnkuc3RhdGUsIHsgc2Nyb2xsOiBjb21wdXRlU2Nyb2xsUG9zaXRpb24oKSB9KSwgXCJcIik7XG5cdFx0fVxuXHR9XG5cdGZ1bmN0aW9uIGRlc3Ryb3koKSB7XG5cdFx0Zm9yIChjb25zdCB0ZWFyZG93biBvZiB0ZWFyZG93bnMpIHRlYXJkb3duKCk7XG5cdFx0dGVhcmRvd25zID0gW107XG5cdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJwb3BzdGF0ZVwiLCBwb3BTdGF0ZUhhbmRsZXIpO1xuXHRcdHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwicGFnZWhpZGVcIiwgYmVmb3JlVW5sb2FkTGlzdGVuZXIpO1xuXHRcdGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJ2aXNpYmlsaXR5Y2hhbmdlXCIsIGJlZm9yZVVubG9hZExpc3RlbmVyKTtcblx0fVxuXHR3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcInBvcHN0YXRlXCIsIHBvcFN0YXRlSGFuZGxlcik7XG5cdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicGFnZWhpZGVcIiwgYmVmb3JlVW5sb2FkTGlzdGVuZXIpO1xuXHRkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwidmlzaWJpbGl0eWNoYW5nZVwiLCBiZWZvcmVVbmxvYWRMaXN0ZW5lcik7XG5cdHJldHVybiB7XG5cdFx0cGF1c2VMaXN0ZW5lcnMsXG5cdFx0bGlzdGVuLFxuXHRcdGRlc3Ryb3lcblx0fTtcbn1cbi8qKlxuKiBDcmVhdGVzIGEgc3RhdGUgb2JqZWN0XG4qL1xuZnVuY3Rpb24gYnVpbGRTdGF0ZShiYWNrLCBjdXJyZW50LCBmb3J3YXJkLCByZXBsYWNlZCA9IGZhbHNlLCBjb21wdXRlU2Nyb2xsID0gZmFsc2UpIHtcblx0cmV0dXJuIHtcblx0XHRiYWNrLFxuXHRcdGN1cnJlbnQsXG5cdFx0Zm9yd2FyZCxcblx0XHRyZXBsYWNlZCxcblx0XHRwb3NpdGlvbjogd2luZG93Lmhpc3RvcnkubGVuZ3RoLFxuXHRcdHNjcm9sbDogY29tcHV0ZVNjcm9sbCA/IGNvbXB1dGVTY3JvbGxQb3NpdGlvbigpIDogbnVsbFxuXHR9O1xufVxuZnVuY3Rpb24gdXNlSGlzdG9yeVN0YXRlTmF2aWdhdGlvbihiYXNlKSB7XG5cdGNvbnN0IHsgaGlzdG9yeSwgbG9jYXRpb24gfSA9IHdpbmRvdztcblx0Y29uc3QgY3VycmVudExvY2F0aW9uID0geyB2YWx1ZTogY3JlYXRlQ3VycmVudExvY2F0aW9uKGJhc2UsIGxvY2F0aW9uKSB9O1xuXHRjb25zdCBoaXN0b3J5U3RhdGUgPSB7IHZhbHVlOiBoaXN0b3J5LnN0YXRlIH07XG5cdGlmICghaGlzdG9yeVN0YXRlLnZhbHVlKSBjaGFuZ2VMb2NhdGlvbihjdXJyZW50TG9jYXRpb24udmFsdWUsIHtcblx0XHRiYWNrOiBudWxsLFxuXHRcdGN1cnJlbnQ6IGN1cnJlbnRMb2NhdGlvbi52YWx1ZSxcblx0XHRmb3J3YXJkOiBudWxsLFxuXHRcdHBvc2l0aW9uOiBoaXN0b3J5Lmxlbmd0aCAtIDEsXG5cdFx0cmVwbGFjZWQ6IHRydWUsXG5cdFx0c2Nyb2xsOiBudWxsXG5cdH0sIHRydWUpO1xuXHRmdW5jdGlvbiBjaGFuZ2VMb2NhdGlvbih0bywgc3RhdGUsIHJlcGxhY2UpIHtcblx0XHQvKipcblx0XHQqIGlmIGEgYmFzZSB0YWcgaXMgcHJvdmlkZWQsIGFuZCB3ZSBhcmUgb24gYSBub3JtYWwgZG9tYWluLCB3ZSBoYXZlIHRvXG5cdFx0KiByZXNwZWN0IHRoZSBwcm92aWRlZCBgYmFzZWAgYXR0cmlidXRlIGJlY2F1c2UgcHVzaFN0YXRlKCkgd2lsbCB1c2UgaXQgYW5kXG5cdFx0KiBwb3RlbnRpYWxseSBlcmFzZSBhbnl0aGluZyBiZWZvcmUgdGhlIGAjYCBsaWtlIGF0XG5cdFx0KiBodHRwczovL2dpdGh1Yi5jb20vdnVlanMvcm91dGVyL2lzc3Vlcy82ODUgd2hlcmUgYSBiYXNlIG9mXG5cdFx0KiBgL2ZvbGRlci8jYCBidXQgYSBiYXNlIG9mIGAvYCB3b3VsZCBlcmFzZSB0aGUgYC9mb2xkZXIvYCBzZWN0aW9uLiBJZlxuXHRcdCogdGhlcmUgaXMgbm8gaG9zdCwgdGhlIGA8YmFzZT5gIHRhZyBtYWtlcyBubyBzZW5zZSBhbmQgaWYgdGhlcmUgaXNuJ3QgYVxuXHRcdCogYmFzZSB0YWcgd2UgY2FuIGp1c3QgdXNlIGV2ZXJ5dGhpbmcgYWZ0ZXIgdGhlIGAjYC5cblx0XHQqL1xuXHRcdGNvbnN0IGhhc2hJbmRleCA9IGJhc2UuaW5kZXhPZihcIiNcIik7XG5cdFx0Y29uc3QgdXJsID0gaGFzaEluZGV4ID4gLTEgPyAobG9jYXRpb24uaG9zdCAmJiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwiYmFzZVwiKSA/IGJhc2UgOiBiYXNlLnNsaWNlKGhhc2hJbmRleCkpICsgdG8gOiBjcmVhdGVCYXNlTG9jYXRpb24oKSArIGJhc2UgKyB0bztcblx0XHR0cnkge1xuXHRcdFx0aGlzdG9yeVtyZXBsYWNlID8gXCJyZXBsYWNlU3RhdGVcIiA6IFwicHVzaFN0YXRlXCJdKHN0YXRlLCBcIlwiLCB1cmwpO1xuXHRcdFx0aGlzdG9yeVN0YXRlLnZhbHVlID0gc3RhdGU7XG5cdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMTIwKHsgY2F1c2U6IGVyciB9KTtcblx0XHRcdGVsc2UgY29uc29sZS5lcnJvcihlcnIpO1xuXHRcdFx0bG9jYXRpb25bcmVwbGFjZSA/IFwicmVwbGFjZVwiIDogXCJhc3NpZ25cIl0odXJsKTtcblx0XHR9XG5cdH1cblx0ZnVuY3Rpb24gcmVwbGFjZSh0bywgZGF0YSkge1xuXHRcdGNoYW5nZUxvY2F0aW9uKHRvLCBhc3NpZ24oe30sIGhpc3Rvcnkuc3RhdGUsIGJ1aWxkU3RhdGUoaGlzdG9yeVN0YXRlLnZhbHVlLmJhY2ssIHRvLCBoaXN0b3J5U3RhdGUudmFsdWUuZm9yd2FyZCwgdHJ1ZSksIGRhdGEsIHsgcG9zaXRpb246IGhpc3RvcnlTdGF0ZS52YWx1ZS5wb3NpdGlvbiB9KSwgdHJ1ZSk7XG5cdFx0Y3VycmVudExvY2F0aW9uLnZhbHVlID0gdG87XG5cdH1cblx0ZnVuY3Rpb24gcHVzaCh0bywgZGF0YSkge1xuXHRcdGNvbnN0IGN1cnJlbnRTdGF0ZSA9IGFzc2lnbih7fSwgaGlzdG9yeVN0YXRlLnZhbHVlLCBoaXN0b3J5LnN0YXRlLCB7XG5cdFx0XHRmb3J3YXJkOiB0byxcblx0XHRcdHNjcm9sbDogY29tcHV0ZVNjcm9sbFBvc2l0aW9uKClcblx0XHR9KTtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFoaXN0b3J5LnN0YXRlKSBkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMTIxKCk7XG5cdFx0Y2hhbmdlTG9jYXRpb24oY3VycmVudFN0YXRlLmN1cnJlbnQsIGN1cnJlbnRTdGF0ZSwgdHJ1ZSk7XG5cdFx0Y2hhbmdlTG9jYXRpb24odG8sIGFzc2lnbih7fSwgYnVpbGRTdGF0ZShjdXJyZW50TG9jYXRpb24udmFsdWUsIHRvLCBudWxsKSwgeyBwb3NpdGlvbjogY3VycmVudFN0YXRlLnBvc2l0aW9uICsgMSB9LCBkYXRhKSwgZmFsc2UpO1xuXHRcdGN1cnJlbnRMb2NhdGlvbi52YWx1ZSA9IHRvO1xuXHR9XG5cdHJldHVybiB7XG5cdFx0bG9jYXRpb246IGN1cnJlbnRMb2NhdGlvbixcblx0XHRzdGF0ZTogaGlzdG9yeVN0YXRlLFxuXHRcdHB1c2gsXG5cdFx0cmVwbGFjZVxuXHR9O1xufVxuLyoqXG4qIENyZWF0ZXMgYW4gSFRNTDUgaGlzdG9yeS4gTW9zdCBjb21tb24gaGlzdG9yeSBmb3Igc2luZ2xlIHBhZ2UgYXBwbGljYXRpb25zLlxuKlxuKiBAcGFyYW0gYmFzZSAtXG4qL1xuZnVuY3Rpb24gY3JlYXRlV2ViSGlzdG9yeShiYXNlKSB7XG5cdGJhc2UgPSBub3JtYWxpemVCYXNlKGJhc2UpO1xuXHRjb25zdCBoaXN0b3J5TmF2aWdhdGlvbiA9IHVzZUhpc3RvcnlTdGF0ZU5hdmlnYXRpb24oYmFzZSk7XG5cdGNvbnN0IGhpc3RvcnlMaXN0ZW5lcnMgPSB1c2VIaXN0b3J5TGlzdGVuZXJzKGJhc2UsIGhpc3RvcnlOYXZpZ2F0aW9uLnN0YXRlLCBoaXN0b3J5TmF2aWdhdGlvbi5sb2NhdGlvbiwgaGlzdG9yeU5hdmlnYXRpb24ucmVwbGFjZSk7XG5cdGZ1bmN0aW9uIGdvKGRlbHRhLCB0cmlnZ2VyTGlzdGVuZXJzID0gdHJ1ZSkge1xuXHRcdGlmICghdHJpZ2dlckxpc3RlbmVycykgaGlzdG9yeUxpc3RlbmVycy5wYXVzZUxpc3RlbmVycygpO1xuXHRcdGhpc3RvcnkuZ28oZGVsdGEpO1xuXHR9XG5cdGNvbnN0IHJvdXRlckhpc3RvcnkgPSBhc3NpZ24oe1xuXHRcdGxvY2F0aW9uOiBcIlwiLFxuXHRcdGJhc2UsXG5cdFx0Z28sXG5cdFx0Y3JlYXRlSHJlZjogY3JlYXRlSHJlZi5iaW5kKG51bGwsIGJhc2UpXG5cdH0sIGhpc3RvcnlOYXZpZ2F0aW9uLCBoaXN0b3J5TGlzdGVuZXJzKTtcblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KHJvdXRlckhpc3RvcnksIFwibG9jYXRpb25cIiwge1xuXHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0Z2V0OiAoKSA9PiBoaXN0b3J5TmF2aWdhdGlvbi5sb2NhdGlvbi52YWx1ZVxuXHR9KTtcblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KHJvdXRlckhpc3RvcnksIFwic3RhdGVcIiwge1xuXHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0Z2V0OiAoKSA9PiBoaXN0b3J5TmF2aWdhdGlvbi5zdGF0ZS52YWx1ZVxuXHR9KTtcblx0cmV0dXJuIHJvdXRlckhpc3Rvcnk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvaGlzdG9yeS9oYXNoLnRzXG4vKipcbiogQ3JlYXRlcyBhIGhhc2ggaGlzdG9yeS4gVXNlZnVsIGZvciB3ZWIgYXBwbGljYXRpb25zIHdpdGggbm8gaG9zdCAoZS5nLiBgZmlsZTovL2ApIG9yIHdoZW4gY29uZmlndXJpbmcgYSBzZXJ2ZXIgdG9cbiogaGFuZGxlIGFueSBVUkwgaXMgbm90IHBvc3NpYmxlLlxuKlxuKiBAcGFyYW0gYmFzZSAtIG9wdGlvbmFsIGJhc2UgdG8gcHJvdmlkZS4gRGVmYXVsdHMgdG8gYGxvY2F0aW9uLnBhdGhuYW1lICsgbG9jYXRpb24uc2VhcmNoYCBJZiB0aGVyZSBpcyBhIGA8YmFzZT5gIHRhZ1xuKiBpbiB0aGUgYGhlYWRgLCBpdHMgdmFsdWUgd2lsbCBiZSBpZ25vcmVkIGluIGZhdm9yIG9mIHRoaXMgcGFyYW1ldGVyICoqYnV0IG5vdGUgaXQgYWZmZWN0cyBhbGwgdGhlIGhpc3RvcnkucHVzaFN0YXRlKClcbiogY2FsbHMqKiwgbWVhbmluZyB0aGF0IGlmIHlvdSB1c2UgYSBgPGJhc2U+YCB0YWcsIGl0J3MgYGhyZWZgIHZhbHVlICoqaGFzIHRvIG1hdGNoIHRoaXMgcGFyYW1ldGVyKiogKGlnbm9yaW5nIGFueXRoaW5nXG4qIGFmdGVyIHRoZSBgI2ApLlxuKlxuKiBAZXhhbXBsZVxuKiBgYGBqc1xuKiAvLyBhdCBodHRwczovL2V4YW1wbGUuY29tL2ZvbGRlclxuKiBjcmVhdGVXZWJIYXNoSGlzdG9yeSgpIC8vIGdpdmVzIGEgdXJsIG9mIGBodHRwczovL2V4YW1wbGUuY29tL2ZvbGRlciNgXG4qIGNyZWF0ZVdlYkhhc2hIaXN0b3J5KCcvZm9sZGVyLycpIC8vIGdpdmVzIGEgdXJsIG9mIGBodHRwczovL2V4YW1wbGUuY29tL2ZvbGRlci8jYFxuKiAvLyBpZiB0aGUgYCNgIGlzIHByb3ZpZGVkIGluIHRoZSBiYXNlLCBpdCB3b24ndCBiZSBhZGRlZCBieSBgY3JlYXRlV2ViSGFzaEhpc3RvcnlgXG4qIGNyZWF0ZVdlYkhhc2hIaXN0b3J5KCcvZm9sZGVyLyMvYXBwLycpIC8vIGdpdmVzIGEgdXJsIG9mIGBodHRwczovL2V4YW1wbGUuY29tL2ZvbGRlci8jL2FwcC9gXG4qIC8vIHlvdSBzaG91bGQgYXZvaWQgZG9pbmcgdGhpcyBiZWNhdXNlIGl0IGNoYW5nZXMgdGhlIG9yaWdpbmFsIHVybCBhbmQgYnJlYWtzIGNvcHlpbmcgdXJsc1xuKiBjcmVhdGVXZWJIYXNoSGlzdG9yeSgnL290aGVyLWZvbGRlci8nKSAvLyBnaXZlcyBhIHVybCBvZiBgaHR0cHM6Ly9leGFtcGxlLmNvbS9vdGhlci1mb2xkZXIvI2BcbipcbiogLy8gYXQgZmlsZTovLy91c3IvZXRjL2ZvbGRlci9pbmRleC5odG1sXG4qIC8vIGZvciBsb2NhdGlvbnMgd2l0aCBubyBgaG9zdGAsIHRoZSBiYXNlIGlzIGlnbm9yZWRcbiogY3JlYXRlV2ViSGFzaEhpc3RvcnkoJy9pQW1JZ25vcmVkJykgLy8gZ2l2ZXMgYSB1cmwgb2YgYGZpbGU6Ly8vdXNyL2V0Yy9mb2xkZXIvaW5kZXguaHRtbCNgXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIGNyZWF0ZVdlYkhhc2hIaXN0b3J5KGJhc2UpIHtcblx0YmFzZSA9IGxvY2F0aW9uLmhvc3QgPyBiYXNlIHx8IGxvY2F0aW9uLnBhdGhuYW1lICsgbG9jYXRpb24uc2VhcmNoIDogXCJcIjtcblx0aWYgKCFiYXNlLmluY2x1ZGVzKFwiI1wiKSkgYmFzZSArPSBcIiNcIjtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhYmFzZS5lbmRzV2l0aChcIiMvXCIpICYmICFiYXNlLmVuZHNXaXRoKFwiI1wiKSkgZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDExMCh7XG5cdFx0YmFzZSxcblx0XHRzdWdnZXN0aW9uOiBiYXNlLnJlcGxhY2UoLyMuKiQvLCBcIiNcIilcblx0fSk7XG5cdHJldHVybiBjcmVhdGVXZWJIaXN0b3J5KGJhc2UpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2hpc3RvcnkvbWVtb3J5LnRzXG4vKipcbiogQ3JlYXRlcyBhbiBpbi1tZW1vcnkgYmFzZWQgaGlzdG9yeS4gVGhlIG1haW4gcHVycG9zZSBvZiB0aGlzIGhpc3RvcnkgaXMgdG8gaGFuZGxlIFNTUi4gSXQgc3RhcnRzIGluIGEgc3BlY2lhbCBsb2NhdGlvbiB0aGF0IGlzIG5vd2hlcmUuXG4qIEl0J3MgdXAgdG8gdGhlIHVzZXIgdG8gcmVwbGFjZSB0aGF0IGxvY2F0aW9uIHdpdGggdGhlIHN0YXJ0ZXIgbG9jYXRpb24gYnkgZWl0aGVyIGNhbGxpbmcgYHJvdXRlci5wdXNoYCBvciBgcm91dGVyLnJlcGxhY2VgLlxuKlxuKiBAcGFyYW0gYmFzZSAtIEJhc2UgYXBwbGllZCB0byBhbGwgdXJscywgZGVmYXVsdHMgdG8gJy8nXG4qIEByZXR1cm5zIGEgaGlzdG9yeSBvYmplY3QgdGhhdCBjYW4gYmUgcGFzc2VkIHRvIHRoZSByb3V0ZXIgY29uc3RydWN0b3JcbiovXG5mdW5jdGlvbiBjcmVhdGVNZW1vcnlIaXN0b3J5KGJhc2UgPSBcIlwiKSB7XG5cdGxldCBsaXN0ZW5lcnMgPSBbXTtcblx0bGV0IHF1ZXVlID0gW1tcIlwiLCB7fV1dO1xuXHRsZXQgcG9zaXRpb24gPSAwO1xuXHRiYXNlID0gbm9ybWFsaXplQmFzZShiYXNlKTtcblx0ZnVuY3Rpb24gc2V0TG9jYXRpb24obG9jYXRpb24sIHN0YXRlID0ge30pIHtcblx0XHRwb3NpdGlvbisrO1xuXHRcdGlmIChwb3NpdGlvbiAhPT0gcXVldWUubGVuZ3RoKSBxdWV1ZS5zcGxpY2UocG9zaXRpb24pO1xuXHRcdHF1ZXVlLnB1c2goW2xvY2F0aW9uLCBzdGF0ZV0pO1xuXHR9XG5cdGZ1bmN0aW9uIHRyaWdnZXJMaXN0ZW5lcnModG8sIGZyb20sIHsgZGlyZWN0aW9uLCBkZWx0YSB9KSB7XG5cdFx0Y29uc3QgaW5mbyA9IHtcblx0XHRcdGRpcmVjdGlvbixcblx0XHRcdGRlbHRhLFxuXHRcdFx0dHlwZTogXCJwb3BcIlxuXHRcdH07XG5cdFx0Zm9yIChjb25zdCBjYWxsYmFjayBvZiBsaXN0ZW5lcnMpIGNhbGxiYWNrKHRvLCBmcm9tLCBpbmZvKTtcblx0fVxuXHRjb25zdCByb3V0ZXJIaXN0b3J5ID0ge1xuXHRcdGxvY2F0aW9uOiBcIlwiLFxuXHRcdHN0YXRlOiB7fSxcblx0XHRiYXNlLFxuXHRcdGNyZWF0ZUhyZWY6IGNyZWF0ZUhyZWYuYmluZChudWxsLCBiYXNlKSxcblx0XHRyZXBsYWNlKHRvLCBzdGF0ZSkge1xuXHRcdFx0cXVldWUuc3BsaWNlKHBvc2l0aW9uLS0sIDEpO1xuXHRcdFx0c2V0TG9jYXRpb24odG8sIHN0YXRlKTtcblx0XHR9LFxuXHRcdHB1c2godG8sIHN0YXRlKSB7XG5cdFx0XHRzZXRMb2NhdGlvbih0bywgc3RhdGUpO1xuXHRcdH0sXG5cdFx0bGlzdGVuKGNhbGxiYWNrKSB7XG5cdFx0XHRsaXN0ZW5lcnMucHVzaChjYWxsYmFjayk7XG5cdFx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0XHRjb25zdCBpbmRleCA9IGxpc3RlbmVycy5pbmRleE9mKGNhbGxiYWNrKTtcblx0XHRcdFx0aWYgKGluZGV4ID4gLTEpIGxpc3RlbmVycy5zcGxpY2UoaW5kZXgsIDEpO1xuXHRcdFx0fTtcblx0XHR9LFxuXHRcdGRlc3Ryb3koKSB7XG5cdFx0XHRsaXN0ZW5lcnMgPSBbXTtcblx0XHRcdHF1ZXVlID0gW1tcIlwiLCB7fV1dO1xuXHRcdFx0cG9zaXRpb24gPSAwO1xuXHRcdH0sXG5cdFx0Z28oZGVsdGEsIHNob3VsZFRyaWdnZXIgPSB0cnVlKSB7XG5cdFx0XHRjb25zdCBmcm9tID0gdGhpcy5sb2NhdGlvbjtcblx0XHRcdGNvbnN0IGRpcmVjdGlvbiA9IGRlbHRhIDwgMCA/IFwiYmFja1wiIDogXCJmb3J3YXJkXCI7XG5cdFx0XHRwb3NpdGlvbiA9IE1hdGgubWF4KDAsIE1hdGgubWluKHBvc2l0aW9uICsgZGVsdGEsIHF1ZXVlLmxlbmd0aCAtIDEpKTtcblx0XHRcdGlmIChzaG91bGRUcmlnZ2VyKSB0cmlnZ2VyTGlzdGVuZXJzKHRoaXMubG9jYXRpb24sIGZyb20sIHtcblx0XHRcdFx0ZGlyZWN0aW9uLFxuXHRcdFx0XHRkZWx0YVxuXHRcdFx0fSk7XG5cdFx0fVxuXHR9O1xuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkocm91dGVySGlzdG9yeSwgXCJsb2NhdGlvblwiLCB7XG5cdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRnZXQ6ICgpID0+IHF1ZXVlW3Bvc2l0aW9uXVswXVxuXHR9KTtcblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KHJvdXRlckhpc3RvcnksIFwic3RhdGVcIiwge1xuXHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0Z2V0OiAoKSA9PiBxdWV1ZVtwb3NpdGlvbl1bMV1cblx0fSk7XG5cdHJldHVybiByb3V0ZXJIaXN0b3J5O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21hdGNoZXIvcGF0aFRva2VuaXplci50c1xuY29uc3QgUk9PVF9UT0tFTiA9IHtcblx0dHlwZTogMCxcblx0dmFsdWU6IFwiXCJcbn07XG5jb25zdCBWQUxJRF9QQVJBTV9SRSA9IC9bYS16QS1aMC05X10vO1xuZnVuY3Rpb24gdG9rZW5pemVQYXRoKHBhdGgpIHtcblx0aWYgKCFwYXRoKSByZXR1cm4gW1tdXTtcblx0aWYgKHBhdGggPT09IFwiL1wiKSByZXR1cm4gW1tST09UX1RPS0VOXV07XG5cdGlmICghcGF0aC5zdGFydHNXaXRoKFwiL1wiKSkgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IGBSb3V0ZSBwYXRocyBzaG91bGQgc3RhcnQgd2l0aCBhIFwiL1wiOiBcIiR7cGF0aH1cIiBzaG91bGQgYmUgXCIvJHtwYXRofVwiLmAgOiBgSW52YWxpZCBwYXRoIFwiJHtwYXRofVwiYCk7XG5cdGZ1bmN0aW9uIGNyYXNoKG1lc3NhZ2UpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoYEVSUiAoJHtzdGF0ZX0pL1wiJHtidWZmZXJ9XCI6ICR7bWVzc2FnZX1gKTtcblx0fVxuXHRsZXQgc3RhdGUgPSAwO1xuXHRsZXQgcHJldmlvdXNTdGF0ZSA9IHN0YXRlO1xuXHRjb25zdCB0b2tlbnMgPSBbXTtcblx0bGV0IHNlZ21lbnQ7XG5cdGZ1bmN0aW9uIGZpbmFsaXplU2VnbWVudCgpIHtcblx0XHRpZiAoc2VnbWVudCkgdG9rZW5zLnB1c2goc2VnbWVudCk7XG5cdFx0c2VnbWVudCA9IFtdO1xuXHR9XG5cdGxldCBpID0gMDtcblx0bGV0IGNoYXI7XG5cdGxldCBidWZmZXIgPSBcIlwiO1xuXHRsZXQgY3VzdG9tUmUgPSBcIlwiO1xuXHRmdW5jdGlvbiBjb25zdW1lQnVmZmVyKCkge1xuXHRcdGlmICghYnVmZmVyKSByZXR1cm47XG5cdFx0aWYgKHN0YXRlID09PSAwKSBzZWdtZW50LnB1c2goe1xuXHRcdFx0dHlwZTogMCxcblx0XHRcdHZhbHVlOiBidWZmZXJcblx0XHR9KTtcblx0XHRlbHNlIGlmIChzdGF0ZSA9PT0gMSB8fCBzdGF0ZSA9PT0gMiB8fCBzdGF0ZSA9PT0gMykge1xuXHRcdFx0aWYgKHNlZ21lbnQubGVuZ3RoID4gMSAmJiAoY2hhciA9PT0gXCIqXCIgfHwgY2hhciA9PT0gXCIrXCIpKSBjcmFzaChgQSByZXBlYXRhYmxlIHBhcmFtICgke2J1ZmZlcn0pIG11c3QgYmUgYWxvbmUgaW4gaXRzIHNlZ21lbnQuIGVnOiAnLzppZHMrLmApO1xuXHRcdFx0c2VnbWVudC5wdXNoKHtcblx0XHRcdFx0dHlwZTogMSxcblx0XHRcdFx0dmFsdWU6IGJ1ZmZlcixcblx0XHRcdFx0cmVnZXhwOiBjdXN0b21SZSxcblx0XHRcdFx0cmVwZWF0YWJsZTogY2hhciA9PT0gXCIqXCIgfHwgY2hhciA9PT0gXCIrXCIsXG5cdFx0XHRcdG9wdGlvbmFsOiBjaGFyID09PSBcIipcIiB8fCBjaGFyID09PSBcIj9cIlxuXHRcdFx0fSk7XG5cdFx0fSBlbHNlIGNyYXNoKFwiSW52YWxpZCBzdGF0ZSB0byBjb25zdW1lIGJ1ZmZlclwiKTtcblx0XHRidWZmZXIgPSBcIlwiO1xuXHR9XG5cdGZ1bmN0aW9uIGFkZENoYXJUb0J1ZmZlcigpIHtcblx0XHRidWZmZXIgKz0gY2hhcjtcblx0fVxuXHR3aGlsZSAoaSA8IHBhdGgubGVuZ3RoKSB7XG5cdFx0Y2hhciA9IHBhdGhbaSsrXTtcblx0XHRzd2l0Y2ggKHN0YXRlKSB7XG5cdFx0XHRjYXNlIDA6XG5cdFx0XHRcdGlmIChjaGFyID09PSBcIlxcXFxcIikge1xuXHRcdFx0XHRcdHByZXZpb3VzU3RhdGUgPSBzdGF0ZTtcblx0XHRcdFx0XHRzdGF0ZSA9IDQ7XG5cdFx0XHRcdH0gZWxzZSBpZiAoY2hhciA9PT0gXCIvXCIpIHtcblx0XHRcdFx0XHRpZiAoYnVmZmVyKSBjb25zdW1lQnVmZmVyKCk7XG5cdFx0XHRcdFx0ZmluYWxpemVTZWdtZW50KCk7XG5cdFx0XHRcdH0gZWxzZSBpZiAoY2hhciA9PT0gXCI6XCIpIHtcblx0XHRcdFx0XHRjb25zdW1lQnVmZmVyKCk7XG5cdFx0XHRcdFx0c3RhdGUgPSAxO1xuXHRcdFx0XHR9IGVsc2UgYWRkQ2hhclRvQnVmZmVyKCk7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0Y2FzZSA0OlxuXHRcdFx0XHRhZGRDaGFyVG9CdWZmZXIoKTtcblx0XHRcdFx0c3RhdGUgPSBwcmV2aW91c1N0YXRlO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdGNhc2UgMTpcblx0XHRcdFx0aWYgKGNoYXIgPT09IFwiKFwiKSBzdGF0ZSA9IDI7XG5cdFx0XHRcdGVsc2UgaWYgKFZBTElEX1BBUkFNX1JFLnRlc3QoY2hhcikpIGFkZENoYXJUb0J1ZmZlcigpO1xuXHRcdFx0XHRlbHNlIHtcblx0XHRcdFx0XHRjb25zdW1lQnVmZmVyKCk7XG5cdFx0XHRcdFx0c3RhdGUgPSAwO1xuXHRcdFx0XHRcdGlmIChjaGFyICE9PSBcIipcIiAmJiBjaGFyICE9PSBcIj9cIiAmJiBjaGFyICE9PSBcIitcIikgaS0tO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0Y2FzZSAyOlxuXHRcdFx0XHRpZiAoY2hhciA9PT0gXCIpXCIpIGlmIChjdXN0b21SZVtjdXN0b21SZS5sZW5ndGggLSAxXSA9PSBcIlxcXFxcIikgY3VzdG9tUmUgPSBjdXN0b21SZS5zbGljZSgwLCAtMSkgKyBjaGFyO1xuXHRcdFx0XHRlbHNlIHN0YXRlID0gMztcblx0XHRcdFx0ZWxzZSBjdXN0b21SZSArPSBjaGFyO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdGNhc2UgMzpcblx0XHRcdFx0Y29uc3VtZUJ1ZmZlcigpO1xuXHRcdFx0XHRzdGF0ZSA9IDA7XG5cdFx0XHRcdGlmIChjaGFyICE9PSBcIipcIiAmJiBjaGFyICE9PSBcIj9cIiAmJiBjaGFyICE9PSBcIitcIikgaS0tO1xuXHRcdFx0XHRjdXN0b21SZSA9IFwiXCI7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0Y3Jhc2goXCJVbmtub3duIHN0YXRlXCIpO1xuXHRcdFx0XHRicmVhaztcblx0XHR9XG5cdH1cblx0aWYgKHN0YXRlID09PSAyKSBjcmFzaChgVW5maW5pc2hlZCBjdXN0b20gUmVnRXhwIGZvciBwYXJhbSBcIiR7YnVmZmVyfVwiYCk7XG5cdGNvbnN1bWVCdWZmZXIoKTtcblx0ZmluYWxpemVTZWdtZW50KCk7XG5cdHJldHVybiB0b2tlbnM7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWF0Y2hlci9wYXRoUGFyc2VyUmFua2VyLnRzXG5jb25zdCBCQVNFX1BBUkFNX1BBVFRFUk4gPSBcIlteL10rP1wiO1xuY29uc3QgQkFTRV9QQVRIX1BBUlNFUl9PUFRJT05TID0ge1xuXHRzZW5zaXRpdmU6IGZhbHNlLFxuXHRzdHJpY3Q6IGZhbHNlLFxuXHRzdGFydDogdHJ1ZSxcblx0ZW5kOiB0cnVlXG59O1xuY29uc3QgUkVHRVhfQ0hBUlNfUkUgPSAvWy4rKj9eJHt9KClbXFxdL1xcXFxdL2c7XG4vKipcbiogQ3JlYXRlcyBhIHBhdGggcGFyc2VyIGZyb20gYW4gYXJyYXkgb2YgU2VnbWVudHMgKGEgc2VnbWVudCBpcyBhbiBhcnJheSBvZiBUb2tlbnMpXG4qXG4qIEBwYXJhbSBzZWdtZW50cyAtIGFycmF5IG9mIHNlZ21lbnRzIHJldHVybmVkIGJ5IHRva2VuaXplUGF0aFxuKiBAcGFyYW0gZXh0cmFPcHRpb25zIC0gb3B0aW9uYWwgb3B0aW9ucyBmb3IgdGhlIHJlZ2V4cFxuKiBAcmV0dXJucyBhIFBhdGhQYXJzZXJcbiovXG5mdW5jdGlvbiB0b2tlbnNUb1BhcnNlcihzZWdtZW50cywgZXh0cmFPcHRpb25zKSB7XG5cdGNvbnN0IG9wdGlvbnMgPSBhc3NpZ24oe30sIEJBU0VfUEFUSF9QQVJTRVJfT1BUSU9OUywgZXh0cmFPcHRpb25zKTtcblx0Y29uc3Qgc2NvcmUgPSBbXTtcblx0bGV0IHBhdHRlcm4gPSBvcHRpb25zLnN0YXJ0ID8gXCJeXCIgOiBcIlwiO1xuXHRjb25zdCBrZXlzID0gW107XG5cdGZvciAoY29uc3Qgc2VnbWVudCBvZiBzZWdtZW50cykge1xuXHRcdGNvbnN0IHNlZ21lbnRTY29yZXMgPSBzZWdtZW50Lmxlbmd0aCA/IFtdIDogWzkwXTtcblx0XHRpZiAob3B0aW9ucy5zdHJpY3QgJiYgIXNlZ21lbnQubGVuZ3RoKSBwYXR0ZXJuICs9IFwiL1wiO1xuXHRcdGZvciAobGV0IHRva2VuSW5kZXggPSAwOyB0b2tlbkluZGV4IDwgc2VnbWVudC5sZW5ndGg7IHRva2VuSW5kZXgrKykge1xuXHRcdFx0Y29uc3QgdG9rZW4gPSBzZWdtZW50W3Rva2VuSW5kZXhdO1xuXHRcdFx0bGV0IHN1YlNlZ21lbnRTY29yZSA9IDQwICsgKG9wdGlvbnMuc2Vuc2l0aXZlID8gLjI1IDogMCk7XG5cdFx0XHRpZiAodG9rZW4udHlwZSA9PT0gMCkge1xuXHRcdFx0XHRpZiAoIXRva2VuSW5kZXgpIHBhdHRlcm4gKz0gXCIvXCI7XG5cdFx0XHRcdHBhdHRlcm4gKz0gdG9rZW4udmFsdWUucmVwbGFjZShSRUdFWF9DSEFSU19SRSwgXCJcXFxcJCZcIik7XG5cdFx0XHRcdHN1YlNlZ21lbnRTY29yZSArPSA0MDtcblx0XHRcdH0gZWxzZSBpZiAodG9rZW4udHlwZSA9PT0gMSkge1xuXHRcdFx0XHRjb25zdCB7IHZhbHVlLCByZXBlYXRhYmxlLCBvcHRpb25hbCwgcmVnZXhwIH0gPSB0b2tlbjtcblx0XHRcdFx0a2V5cy5wdXNoKHtcblx0XHRcdFx0XHRuYW1lOiB2YWx1ZSxcblx0XHRcdFx0XHRyZXBlYXRhYmxlLFxuXHRcdFx0XHRcdG9wdGlvbmFsXG5cdFx0XHRcdH0pO1xuXHRcdFx0XHRjb25zdCByZSA9IHJlZ2V4cCA/IHJlZ2V4cCA6IEJBU0VfUEFSQU1fUEFUVEVSTjtcblx0XHRcdFx0aWYgKHJlICE9PSBCQVNFX1BBUkFNX1BBVFRFUk4pIHtcblx0XHRcdFx0XHRzdWJTZWdtZW50U2NvcmUgKz0gMTA7XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdG5ldyBSZWdFeHAoYCgke3JlfSlgKTtcblx0XHRcdFx0XHR9IGNhdGNoIChlcnIpIHtcblx0XHRcdFx0XHRcdHRocm93IG5ldyBFcnJvcihgSW52YWxpZCBjdXN0b20gUmVnRXhwIGZvciBwYXJhbSBcIiR7dmFsdWV9XCIgKCR7cmV9KTogYCArIGVyci5tZXNzYWdlKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0bGV0IHN1YlBhdHRlcm4gPSByZXBlYXRhYmxlID8gYCgoPzoke3JlfSkoPzovKD86JHtyZX0pKSopYCA6IGAoJHtyZX0pYDtcblx0XHRcdFx0aWYgKCF0b2tlbkluZGV4KSBzdWJQYXR0ZXJuID0gb3B0aW9uYWwgJiYgc2VnbWVudC5sZW5ndGggPCAyID8gYCg/Oi8ke3N1YlBhdHRlcm59KWAgOiBcIi9cIiArIHN1YlBhdHRlcm47XG5cdFx0XHRcdGlmIChvcHRpb25hbCkgc3ViUGF0dGVybiArPSBcIj9cIjtcblx0XHRcdFx0cGF0dGVybiArPSBzdWJQYXR0ZXJuO1xuXHRcdFx0XHRzdWJTZWdtZW50U2NvcmUgKz0gMjA7XG5cdFx0XHRcdGlmIChvcHRpb25hbCkgc3ViU2VnbWVudFNjb3JlICs9IC04O1xuXHRcdFx0XHRpZiAocmVwZWF0YWJsZSkgc3ViU2VnbWVudFNjb3JlICs9IC0yMDtcblx0XHRcdFx0aWYgKHJlID09PSBcIi4qXCIpIHN1YlNlZ21lbnRTY29yZSArPSAtNTA7XG5cdFx0XHR9XG5cdFx0XHRzZWdtZW50U2NvcmVzLnB1c2goc3ViU2VnbWVudFNjb3JlKTtcblx0XHR9XG5cdFx0c2NvcmUucHVzaChzZWdtZW50U2NvcmVzKTtcblx0fVxuXHRpZiAob3B0aW9ucy5zdHJpY3QgJiYgb3B0aW9ucy5lbmQpIHtcblx0XHRjb25zdCBpID0gc2NvcmUubGVuZ3RoIC0gMTtcblx0XHRzY29yZVtpXVtzY29yZVtpXS5sZW5ndGggLSAxXSArPSAuNzAwMDAwMDAwMDAwMDAwMTtcblx0fVxuXHRpZiAoIW9wdGlvbnMuc3RyaWN0KSBwYXR0ZXJuICs9IFwiLz9cIjtcblx0aWYgKG9wdGlvbnMuZW5kKSBwYXR0ZXJuICs9IFwiJFwiO1xuXHRlbHNlIGlmIChvcHRpb25zLnN0cmljdCAmJiAhcGF0dGVybi5lbmRzV2l0aChcIi9cIikpIHBhdHRlcm4gKz0gXCIoPzovfCQpXCI7XG5cdGNvbnN0IHJlID0gbmV3IFJlZ0V4cChwYXR0ZXJuLCBvcHRpb25zLnNlbnNpdGl2ZSA/IFwiXCIgOiBcImlcIik7XG5cdGZ1bmN0aW9uIHBhcnNlKHBhdGgpIHtcblx0XHRjb25zdCBtYXRjaCA9IHBhdGgubWF0Y2gocmUpO1xuXHRcdGNvbnN0IHBhcmFtcyA9IHt9O1xuXHRcdGlmICghbWF0Y2gpIHJldHVybiBudWxsO1xuXHRcdGZvciAobGV0IGkgPSAxOyBpIDwgbWF0Y2gubGVuZ3RoOyBpKyspIHtcblx0XHRcdGNvbnN0IHZhbHVlID0gbWF0Y2hbaV0gfHwgXCJcIjtcblx0XHRcdGNvbnN0IGtleSA9IGtleXNbaSAtIDFdO1xuXHRcdFx0cGFyYW1zW2tleS5uYW1lXSA9IHZhbHVlICYmIGtleS5yZXBlYXRhYmxlID8gdmFsdWUuc3BsaXQoXCIvXCIpIDogdmFsdWU7XG5cdFx0fVxuXHRcdHJldHVybiBwYXJhbXM7XG5cdH1cblx0ZnVuY3Rpb24gc3RyaW5naWZ5KHBhcmFtcykge1xuXHRcdGxldCBwYXRoID0gXCJcIjtcblx0XHRsZXQgYXZvaWREdXBsaWNhdGVkU2xhc2ggPSBmYWxzZTtcblx0XHRmb3IgKGNvbnN0IHNlZ21lbnQgb2Ygc2VnbWVudHMpIHtcblx0XHRcdGlmICghYXZvaWREdXBsaWNhdGVkU2xhc2ggfHwgIXBhdGguZW5kc1dpdGgoXCIvXCIpKSBwYXRoICs9IFwiL1wiO1xuXHRcdFx0YXZvaWREdXBsaWNhdGVkU2xhc2ggPSBmYWxzZTtcblx0XHRcdGZvciAoY29uc3QgdG9rZW4gb2Ygc2VnbWVudCkgaWYgKHRva2VuLnR5cGUgPT09IDApIHBhdGggKz0gdG9rZW4udmFsdWU7XG5cdFx0XHRlbHNlIGlmICh0b2tlbi50eXBlID09PSAxKSB7XG5cdFx0XHRcdGNvbnN0IHsgdmFsdWUsIHJlcGVhdGFibGUsIG9wdGlvbmFsIH0gPSB0b2tlbjtcblx0XHRcdFx0Y29uc3QgcGFyYW0gPSB2YWx1ZSBpbiBwYXJhbXMgPyBwYXJhbXNbdmFsdWVdIDogXCJcIjtcblx0XHRcdFx0aWYgKGlzQXJyYXkocGFyYW0pICYmICFyZXBlYXRhYmxlKSB0aHJvdyBuZXcgRXJyb3IoYFByb3ZpZGVkIHBhcmFtIFwiJHt2YWx1ZX1cIiBpcyBhbiBhcnJheSBidXQgaXQgaXMgbm90IHJlcGVhdGFibGUgKCogb3IgKyBtb2RpZmllcnMpYCk7XG5cdFx0XHRcdGNvbnN0IHRleHQgPSBpc0FycmF5KHBhcmFtKSA/IHBhcmFtLmpvaW4oXCIvXCIpIDogcGFyYW07XG5cdFx0XHRcdGlmICghdGV4dCkgaWYgKG9wdGlvbmFsKSB7XG5cdFx0XHRcdFx0aWYgKHNlZ21lbnQubGVuZ3RoIDwgMikgaWYgKHBhdGguZW5kc1dpdGgoXCIvXCIpKSBwYXRoID0gcGF0aC5zbGljZSgwLCAtMSk7XG5cdFx0XHRcdFx0ZWxzZSBhdm9pZER1cGxpY2F0ZWRTbGFzaCA9IHRydWU7XG5cdFx0XHRcdH0gZWxzZSB0aHJvdyBuZXcgRXJyb3IoYE1pc3NpbmcgcmVxdWlyZWQgcGFyYW0gXCIke3ZhbHVlfVwiYCk7XG5cdFx0XHRcdHBhdGggKz0gdGV4dDtcblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIHBhdGggfHwgXCIvXCI7XG5cdH1cblx0cmV0dXJuIHtcblx0XHRyZSxcblx0XHRzY29yZSxcblx0XHRrZXlzLFxuXHRcdHBhcnNlLFxuXHRcdHN0cmluZ2lmeVxuXHR9O1xufVxuLyoqXG4qIENvbXBhcmVzIGFuIGFycmF5IG9mIG51bWJlcnMgYXMgdXNlZCBpbiBQYXRoUGFyc2VyLnNjb3JlIGFuZCByZXR1cm5zIGFcbiogbnVtYmVyLiBUaGlzIGZ1bmN0aW9uIGNhbiBiZSB1c2VkIHRvIGBzb3J0YCBhbiBhcnJheVxuKlxuKiBAcGFyYW0gYSAtIGZpcnN0IGFycmF5IG9mIG51bWJlcnNcbiogQHBhcmFtIGIgLSBzZWNvbmQgYXJyYXkgb2YgbnVtYmVyc1xuKiBAcmV0dXJucyAwIGlmIGJvdGggYXJlIGVxdWFsLCA8IDAgaWYgYSBzaG91bGQgYmUgc29ydGVkIGZpcnN0LCA+IDAgaWYgYlxuKiBzaG91bGQgYmUgc29ydGVkIGZpcnN0XG4qL1xuZnVuY3Rpb24gY29tcGFyZVNjb3JlQXJyYXkoYSwgYikge1xuXHRsZXQgaSA9IDA7XG5cdHdoaWxlIChpIDwgYS5sZW5ndGggJiYgaSA8IGIubGVuZ3RoKSB7XG5cdFx0Y29uc3QgZGlmZiA9IGJbaV0gLSBhW2ldO1xuXHRcdGlmIChkaWZmKSByZXR1cm4gZGlmZjtcblx0XHRpKys7XG5cdH1cblx0aWYgKGEubGVuZ3RoIDwgYi5sZW5ndGgpIHJldHVybiBhLmxlbmd0aCA9PT0gMSAmJiBhWzBdID09PSA4MCA/IC0xIDogMTtcblx0ZWxzZSBpZiAoYS5sZW5ndGggPiBiLmxlbmd0aCkgcmV0dXJuIGIubGVuZ3RoID09PSAxICYmIGJbMF0gPT09IDgwID8gMSA6IC0xO1xuXHRyZXR1cm4gMDtcbn1cbi8qKlxuKiBDb21wYXJlIGZ1bmN0aW9uIHRoYXQgY2FuIGJlIHVzZWQgd2l0aCBgc29ydGAgdG8gc29ydCBhbiBhcnJheSBvZiBQYXRoUGFyc2VyXG4qXG4qIEBwYXJhbSBhIC0gZmlyc3QgUGF0aFBhcnNlclxuKiBAcGFyYW0gYiAtIHNlY29uZCBQYXRoUGFyc2VyXG4qIEByZXR1cm5zIDAgaWYgYm90aCBhcmUgZXF1YWwsIDwgMCBpZiBhIHNob3VsZCBiZSBzb3J0ZWQgZmlyc3QsID4gMCBpZiBiXG4qL1xuZnVuY3Rpb24gY29tcGFyZVBhdGhQYXJzZXJTY29yZShhLCBiKSB7XG5cdGxldCBpID0gMDtcblx0Y29uc3QgYVNjb3JlID0gYS5zY29yZTtcblx0Y29uc3QgYlNjb3JlID0gYi5zY29yZTtcblx0d2hpbGUgKGkgPCBhU2NvcmUubGVuZ3RoICYmIGkgPCBiU2NvcmUubGVuZ3RoKSB7XG5cdFx0Y29uc3QgY29tcCA9IGNvbXBhcmVTY29yZUFycmF5KGFTY29yZVtpXSwgYlNjb3JlW2ldKTtcblx0XHRpZiAoY29tcCkgcmV0dXJuIGNvbXA7XG5cdFx0aSsrO1xuXHR9XG5cdGlmIChNYXRoLmFicyhiU2NvcmUubGVuZ3RoIC0gYVNjb3JlLmxlbmd0aCkgPT09IDEpIHtcblx0XHRpZiAoaXNMYXN0U2NvcmVOZWdhdGl2ZShhU2NvcmUpKSByZXR1cm4gMTtcblx0XHRpZiAoaXNMYXN0U2NvcmVOZWdhdGl2ZShiU2NvcmUpKSByZXR1cm4gLTE7XG5cdH1cblx0cmV0dXJuIGJTY29yZS5sZW5ndGggLSBhU2NvcmUubGVuZ3RoO1xufVxuLyoqXG4qIFRoaXMgYWxsb3dzIGRldGVjdGluZyBzcGxhdHMgYXQgdGhlIGVuZCBvZiBhIHBhdGg6IC9ob21lLzppZCguKikqXG4qXG4qIEBwYXJhbSBzY29yZSAtIHNjb3JlIHRvIGNoZWNrXG4qIEByZXR1cm5zIHRydWUgaWYgdGhlIGxhc3QgZW50cnkgaXMgbmVnYXRpdmVcbiovXG5mdW5jdGlvbiBpc0xhc3RTY29yZU5lZ2F0aXZlKHNjb3JlKSB7XG5cdGNvbnN0IGxhc3QgPSBzY29yZVtzY29yZS5sZW5ndGggLSAxXTtcblx0cmV0dXJuIHNjb3JlLmxlbmd0aCA+IDAgJiYgbGFzdFtsYXN0Lmxlbmd0aCAtIDFdIDwgMDtcbn1cbmNvbnN0IFBBVEhfUEFSU0VSX09QVElPTlNfREVGQVVMVFMgPSB7XG5cdHN0cmljdDogZmFsc2UsXG5cdGVuZDogdHJ1ZSxcblx0c2Vuc2l0aXZlOiBmYWxzZVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tYXRjaGVyL3BhdGhNYXRjaGVyLnRzXG5mdW5jdGlvbiBjcmVhdGVSb3V0ZVJlY29yZE1hdGNoZXIocmVjb3JkLCBwYXJlbnQsIG9wdGlvbnMpIHtcblx0Y29uc3QgcGFyc2VyID0gdG9rZW5zVG9QYXJzZXIodG9rZW5pemVQYXRoKHJlY29yZC5wYXRoKSwgb3B0aW9ucyk7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRjb25zdCBleGlzdGluZ0tleXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdGZvciAoY29uc3Qga2V5IG9mIHBhcnNlci5rZXlzKSB7XG5cdFx0XHRpZiAoZXhpc3RpbmdLZXlzLmhhcyhrZXkubmFtZSkpIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwOTAoe1xuXHRcdFx0XHRuYW1lOiBrZXkubmFtZSxcblx0XHRcdFx0cGF0aDogcmVjb3JkLnBhdGhcblx0XHRcdH0pO1xuXHRcdFx0ZXhpc3RpbmdLZXlzLmFkZChrZXkubmFtZSk7XG5cdFx0fVxuXHR9XG5cdGNvbnN0IG1hdGNoZXIgPSBhc3NpZ24ocGFyc2VyLCB7XG5cdFx0cmVjb3JkLFxuXHRcdHBhcmVudCxcblx0XHRjaGlsZHJlbjogW10sXG5cdFx0YWxpYXM6IFtdXG5cdH0pO1xuXHRpZiAocGFyZW50KSB7XG5cdFx0aWYgKCFtYXRjaGVyLnJlY29yZC5hbGlhc09mID09PSAhcGFyZW50LnJlY29yZC5hbGlhc09mKSBwYXJlbnQuY2hpbGRyZW4ucHVzaChtYXRjaGVyKTtcblx0fVxuXHRyZXR1cm4gbWF0Y2hlcjtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tYXRjaGVyL2luZGV4LnRzXG4vKipcbiogQ3JlYXRlcyBhIFJvdXRlciBNYXRjaGVyLlxuKlxuKiBAaW50ZXJuYWxcbiogQHBhcmFtIHJvdXRlcyAtIGFycmF5IG9mIGluaXRpYWwgcm91dGVzXG4qIEBwYXJhbSBnbG9iYWxPcHRpb25zIC0gZ2xvYmFsIHJvdXRlIG9wdGlvbnNcbiovXG5mdW5jdGlvbiBjcmVhdGVSb3V0ZXJNYXRjaGVyKHJvdXRlcywgZ2xvYmFsT3B0aW9ucykge1xuXHRjb25zdCBtYXRjaGVycyA9IFtdO1xuXHRjb25zdCBtYXRjaGVyTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0Z2xvYmFsT3B0aW9ucyA9IG1lcmdlT3B0aW9ucyhQQVRIX1BBUlNFUl9PUFRJT05TX0RFRkFVTFRTLCBnbG9iYWxPcHRpb25zKTtcblx0ZnVuY3Rpb24gZ2V0UmVjb3JkTWF0Y2hlcihuYW1lKSB7XG5cdFx0cmV0dXJuIG1hdGNoZXJNYXAuZ2V0KG5hbWUpO1xuXHR9XG5cdGZ1bmN0aW9uIGFkZFJvdXRlKHJlY29yZCwgcGFyZW50LCBvcmlnaW5hbFJlY29yZCkge1xuXHRcdGNvbnN0IGlzUm9vdEFkZCA9ICFvcmlnaW5hbFJlY29yZDtcblx0XHRjb25zdCBtYWluTm9ybWFsaXplZFJlY29yZCA9IG5vcm1hbGl6ZVJvdXRlUmVjb3JkKHJlY29yZCk7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgY2hlY2tDaGlsZE1pc3NpbmdOYW1lV2l0aEVtcHR5UGF0aChtYWluTm9ybWFsaXplZFJlY29yZCwgcGFyZW50KTtcblx0XHRtYWluTm9ybWFsaXplZFJlY29yZC5hbGlhc09mID0gb3JpZ2luYWxSZWNvcmQgJiYgb3JpZ2luYWxSZWNvcmQucmVjb3JkO1xuXHRcdGNvbnN0IG9wdGlvbnMgPSBtZXJnZU9wdGlvbnMoZ2xvYmFsT3B0aW9ucywgcmVjb3JkKTtcblx0XHRjb25zdCBub3JtYWxpemVkUmVjb3JkcyA9IFttYWluTm9ybWFsaXplZFJlY29yZF07XG5cdFx0aWYgKFwiYWxpYXNcIiBpbiByZWNvcmQpIHtcblx0XHRcdGNvbnN0IGFsaWFzZXMgPSB0eXBlb2YgcmVjb3JkLmFsaWFzID09PSBcInN0cmluZ1wiID8gW3JlY29yZC5hbGlhc10gOiByZWNvcmQuYWxpYXM7XG5cdFx0XHRmb3IgKGNvbnN0IGFsaWFzIG9mIGFsaWFzZXMpIG5vcm1hbGl6ZWRSZWNvcmRzLnB1c2gobm9ybWFsaXplUm91dGVSZWNvcmQoYXNzaWduKHt9LCBtYWluTm9ybWFsaXplZFJlY29yZCwge1xuXHRcdFx0XHRjb21wb25lbnRzOiBvcmlnaW5hbFJlY29yZCA/IG9yaWdpbmFsUmVjb3JkLnJlY29yZC5jb21wb25lbnRzIDogbWFpbk5vcm1hbGl6ZWRSZWNvcmQuY29tcG9uZW50cyxcblx0XHRcdFx0cGF0aDogYWxpYXMsXG5cdFx0XHRcdGFsaWFzT2Y6IG9yaWdpbmFsUmVjb3JkID8gb3JpZ2luYWxSZWNvcmQucmVjb3JkIDogbWFpbk5vcm1hbGl6ZWRSZWNvcmRcblx0XHRcdH0pKSk7XG5cdFx0fVxuXHRcdGxldCBtYXRjaGVyO1xuXHRcdGxldCBvcmlnaW5hbE1hdGNoZXI7XG5cdFx0Zm9yIChjb25zdCBub3JtYWxpemVkUmVjb3JkIG9mIG5vcm1hbGl6ZWRSZWNvcmRzKSB7XG5cdFx0XHRjb25zdCB7IHBhdGggfSA9IG5vcm1hbGl6ZWRSZWNvcmQ7XG5cdFx0XHRpZiAocGFyZW50ICYmIHBhdGhbMF0gIT09IFwiL1wiKSB7XG5cdFx0XHRcdGNvbnN0IHBhcmVudFBhdGggPSBwYXJlbnQucmVjb3JkLnBhdGg7XG5cdFx0XHRcdGNvbnN0IGNvbm5lY3RpbmdTbGFzaCA9IHBhcmVudFBhdGhbcGFyZW50UGF0aC5sZW5ndGggLSAxXSA9PT0gXCIvXCIgPyBcIlwiIDogXCIvXCI7XG5cdFx0XHRcdG5vcm1hbGl6ZWRSZWNvcmQucGF0aCA9IHBhcmVudC5yZWNvcmQucGF0aCArIChwYXRoICYmIGNvbm5lY3RpbmdTbGFzaCArIHBhdGgpO1xuXHRcdFx0fVxuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBub3JtYWxpemVkUmVjb3JkLnBhdGggPT09IFwiKlwiKSB0aHJvdyBuZXcgRXJyb3IoXCJDYXRjaCBhbGwgcm91dGVzIChcXFwiKlxcXCIpIG11c3Qgbm93IGJlIGRlZmluZWQgdXNpbmcgYSBwYXJhbSB3aXRoIGEgY3VzdG9tIHJlZ2V4cC5cXG5TZWUgbW9yZSBhdCBodHRwczovL3JvdXRlci52dWVqcy5vcmcvZ3VpZGUvbWlncmF0aW9uLyNSZW1vdmVkLXN0YXItb3ItY2F0Y2gtYWxsLXJvdXRlcy5cIik7XG5cdFx0XHRtYXRjaGVyID0gY3JlYXRlUm91dGVSZWNvcmRNYXRjaGVyKG5vcm1hbGl6ZWRSZWNvcmQsIHBhcmVudCwgb3B0aW9ucyk7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIHBhcmVudCAmJiBwYXRoWzBdID09PSBcIi9cIikgY2hlY2tNaXNzaW5nUGFyYW1zSW5BYnNvbHV0ZVBhdGgobWF0Y2hlciwgcGFyZW50KTtcblx0XHRcdGlmIChvcmlnaW5hbFJlY29yZCkge1xuXHRcdFx0XHRvcmlnaW5hbFJlY29yZC5hbGlhcy5wdXNoKG1hdGNoZXIpO1xuXHRcdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBjaGVja1NhbWVQYXJhbXMob3JpZ2luYWxSZWNvcmQsIG1hdGNoZXIpO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0b3JpZ2luYWxNYXRjaGVyID0gb3JpZ2luYWxNYXRjaGVyIHx8IG1hdGNoZXI7XG5cdFx0XHRcdGlmIChvcmlnaW5hbE1hdGNoZXIgIT09IG1hdGNoZXIpIG9yaWdpbmFsTWF0Y2hlci5hbGlhcy5wdXNoKG1hdGNoZXIpO1xuXHRcdFx0XHRpZiAoaXNSb290QWRkICYmIHJlY29yZC5uYW1lICYmICFpc0FsaWFzUmVjb3JkKG1hdGNoZXIpKSB7XG5cdFx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgY2hlY2tTYW1lTmFtZUFzQW5jZXN0b3IocmVjb3JkLCBwYXJlbnQpO1xuXHRcdFx0XHRcdHJlbW92ZVJvdXRlKHJlY29yZC5uYW1lKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKGlzTWF0Y2hhYmxlKG1hdGNoZXIpKSBpbnNlcnRNYXRjaGVyKG1hdGNoZXIpO1xuXHRcdFx0aWYgKG1haW5Ob3JtYWxpemVkUmVjb3JkLmNoaWxkcmVuKSB7XG5cdFx0XHRcdGNvbnN0IGNoaWxkcmVuID0gbWFpbk5vcm1hbGl6ZWRSZWNvcmQuY2hpbGRyZW47XG5cdFx0XHRcdGZvciAobGV0IGkgPSAwOyBpIDwgY2hpbGRyZW4ubGVuZ3RoOyBpKyspIGFkZFJvdXRlKGNoaWxkcmVuW2ldLCBtYXRjaGVyLCBvcmlnaW5hbFJlY29yZCAmJiBvcmlnaW5hbFJlY29yZC5jaGlsZHJlbltpXSk7XG5cdFx0XHR9XG5cdFx0XHRvcmlnaW5hbFJlY29yZCA9IG9yaWdpbmFsUmVjb3JkIHx8IG1hdGNoZXI7XG5cdFx0fVxuXHRcdHJldHVybiBvcmlnaW5hbE1hdGNoZXIgPyAoKSA9PiB7XG5cdFx0XHRyZW1vdmVSb3V0ZShvcmlnaW5hbE1hdGNoZXIpO1xuXHRcdH0gOiBub29wO1xuXHR9XG5cdGZ1bmN0aW9uIHJlbW92ZVJvdXRlKG1hdGNoZXJSZWYpIHtcblx0XHRpZiAoaXNSb3V0ZU5hbWUobWF0Y2hlclJlZikpIHtcblx0XHRcdGNvbnN0IG1hdGNoZXIgPSBtYXRjaGVyTWFwLmdldChtYXRjaGVyUmVmKTtcblx0XHRcdGlmIChtYXRjaGVyKSB7XG5cdFx0XHRcdG1hdGNoZXJNYXAuZGVsZXRlKG1hdGNoZXJSZWYpO1xuXHRcdFx0XHRtYXRjaGVycy5zcGxpY2UobWF0Y2hlcnMuaW5kZXhPZihtYXRjaGVyKSwgMSk7XG5cdFx0XHRcdG1hdGNoZXIuY2hpbGRyZW4uZm9yRWFjaChyZW1vdmVSb3V0ZSk7XG5cdFx0XHRcdG1hdGNoZXIuYWxpYXMuZm9yRWFjaChyZW1vdmVSb3V0ZSk7XG5cdFx0XHR9XG5cdFx0fSBlbHNlIHtcblx0XHRcdGNvbnN0IGluZGV4ID0gbWF0Y2hlcnMuaW5kZXhPZihtYXRjaGVyUmVmKTtcblx0XHRcdGlmIChpbmRleCA+IC0xKSB7XG5cdFx0XHRcdG1hdGNoZXJzLnNwbGljZShpbmRleCwgMSk7XG5cdFx0XHRcdGlmIChtYXRjaGVyUmVmLnJlY29yZC5uYW1lKSBtYXRjaGVyTWFwLmRlbGV0ZShtYXRjaGVyUmVmLnJlY29yZC5uYW1lKTtcblx0XHRcdFx0bWF0Y2hlclJlZi5jaGlsZHJlbi5mb3JFYWNoKHJlbW92ZVJvdXRlKTtcblx0XHRcdFx0bWF0Y2hlclJlZi5hbGlhcy5mb3JFYWNoKHJlbW92ZVJvdXRlKTtcblx0XHRcdH1cblx0XHR9XG5cdH1cblx0ZnVuY3Rpb24gZ2V0Um91dGVzKCkge1xuXHRcdHJldHVybiBtYXRjaGVycztcblx0fVxuXHRmdW5jdGlvbiBpbnNlcnRNYXRjaGVyKG1hdGNoZXIpIHtcblx0XHRjb25zdCBpbmRleCA9IGZpbmRJbnNlcnRpb25JbmRleChtYXRjaGVyLCBtYXRjaGVycyk7XG5cdFx0bWF0Y2hlcnMuc3BsaWNlKGluZGV4LCAwLCBtYXRjaGVyKTtcblx0XHRpZiAobWF0Y2hlci5yZWNvcmQubmFtZSAmJiAhaXNBbGlhc1JlY29yZChtYXRjaGVyKSkgbWF0Y2hlck1hcC5zZXQobWF0Y2hlci5yZWNvcmQubmFtZSwgbWF0Y2hlcik7XG5cdH1cblx0ZnVuY3Rpb24gcmVzb2x2ZShsb2NhdGlvbiwgY3VycmVudExvY2F0aW9uKSB7XG5cdFx0bGV0IG1hdGNoZXI7XG5cdFx0bGV0IHBhcmFtcyA9IHt9O1xuXHRcdGxldCBwYXRoO1xuXHRcdGxldCBuYW1lO1xuXHRcdGlmIChcIm5hbWVcIiBpbiBsb2NhdGlvbiAmJiBsb2NhdGlvbi5uYW1lKSB7XG5cdFx0XHRtYXRjaGVyID0gbWF0Y2hlck1hcC5nZXQobG9jYXRpb24ubmFtZSk7XG5cdFx0XHRpZiAoIW1hdGNoZXIpIHRocm93IGNyZWF0ZVJvdXRlckVycm9yKDEsIHsgbG9jYXRpb24gfSk7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0XHRcdGNvbnN0IGludmFsaWRQYXJhbXMgPSBPYmplY3Qua2V5cyhsb2NhdGlvbi5wYXJhbXMgfHwge30pLmZpbHRlcigocGFyYW1OYW1lKSA9PiAhbWF0Y2hlci5rZXlzLmZpbmQoKGspID0+IGsubmFtZSA9PT0gcGFyYW1OYW1lKSk7XG5cdFx0XHRcdGlmIChpbnZhbGlkUGFyYW1zLmxlbmd0aCkge1xuXHRcdFx0XHRcdGNvbnN0IGlzSW5oZXJpdGVkID0gIW1hdGNoZXIua2V5cy5sZW5ndGggJiYgaW52YWxpZFBhcmFtcy5zb21lKChuYW1lKSA9PiBuYW1lIGluIGN1cnJlbnRMb2NhdGlvbi5wYXJhbXMpO1xuXHRcdFx0XHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAxMDAoe1xuXHRcdFx0XHRcdFx0cGFyYW1zOiBpbnZhbGlkUGFyYW1zLmpvaW4oXCJcXFwiLCBcXFwiXCIpLFxuXHRcdFx0XHRcdFx0aW5oZXJpdGVkOiBpc0luaGVyaXRlZCA/IGAgSWYgeW91IGFyZSB1c2luZyBhIGNhdGNoLWFsbCByb3V0ZSB3aXRoIGEgbmFtZWQgcmVkaXJlY3QsIHBhc3MgYW4gZW1wdHkgXFxgcGFyYW1zXFxgIG9iamVjdDogXFxgcmVkaXJlY3Q6IHsgbmFtZTogJy4uLicsIHBhcmFtczoge30gfVxcYC5gIDogXCJcIlxuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRuYW1lID0gbWF0Y2hlci5yZWNvcmQubmFtZTtcblx0XHRcdHBhcmFtcyA9IGFzc2lnbihwaWNrUGFyYW1zKGN1cnJlbnRMb2NhdGlvbi5wYXJhbXMsIG1hdGNoZXIua2V5cy5maWx0ZXIoKGspID0+ICFrLm9wdGlvbmFsKS5jb25jYXQobWF0Y2hlci5wYXJlbnQgPyBtYXRjaGVyLnBhcmVudC5rZXlzLmZpbHRlcigoaykgPT4gay5vcHRpb25hbCkgOiBbXSkubWFwKChrKSA9PiBrLm5hbWUpKSwgbG9jYXRpb24ucGFyYW1zICYmIHBpY2tQYXJhbXMobG9jYXRpb24ucGFyYW1zLCBtYXRjaGVyLmtleXMubWFwKChrKSA9PiBrLm5hbWUpKSk7XG5cdFx0XHRwYXRoID0gbWF0Y2hlci5zdHJpbmdpZnkocGFyYW1zKTtcblx0XHR9IGVsc2UgaWYgKGxvY2F0aW9uLnBhdGggIT0gbnVsbCkge1xuXHRcdFx0cGF0aCA9IGxvY2F0aW9uLnBhdGg7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFwYXRoLnN0YXJ0c1dpdGgoXCIvXCIpKSBkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMTAxKHsgcGF0aCB9KTtcblx0XHRcdG1hdGNoZXIgPSBtYXRjaGVycy5maW5kKChtKSA9PiBtLnJlLnRlc3QocGF0aCkpO1xuXHRcdFx0aWYgKG1hdGNoZXIpIHtcblx0XHRcdFx0cGFyYW1zID0gbWF0Y2hlci5wYXJzZShwYXRoKTtcblx0XHRcdFx0bmFtZSA9IG1hdGNoZXIucmVjb3JkLm5hbWU7XG5cdFx0XHRcdG1hdGNoZXIua2V5cy5mb3JFYWNoKChrZXkpID0+IHtcblx0XHRcdFx0XHRpZiAoa2V5Lm9wdGlvbmFsICYmICFwYXJhbXNba2V5Lm5hbWVdKSBkZWxldGUgcGFyYW1zW2tleS5uYW1lXTtcblx0XHRcdFx0fSk7XG5cdFx0XHR9XG5cdFx0fSBlbHNlIHtcblx0XHRcdG1hdGNoZXIgPSBjdXJyZW50TG9jYXRpb24ubmFtZSA/IG1hdGNoZXJNYXAuZ2V0KGN1cnJlbnRMb2NhdGlvbi5uYW1lKSA6IG1hdGNoZXJzLmZpbmQoKG0pID0+IG0ucmUudGVzdChjdXJyZW50TG9jYXRpb24ucGF0aCkpO1xuXHRcdFx0aWYgKCFtYXRjaGVyKSB0aHJvdyBjcmVhdGVSb3V0ZXJFcnJvcigxLCB7XG5cdFx0XHRcdGxvY2F0aW9uLFxuXHRcdFx0XHRjdXJyZW50TG9jYXRpb25cblx0XHRcdH0pO1xuXHRcdFx0bmFtZSA9IG1hdGNoZXIucmVjb3JkLm5hbWU7XG5cdFx0XHRwYXJhbXMgPSBhc3NpZ24oe30sIGN1cnJlbnRMb2NhdGlvbi5wYXJhbXMsIGxvY2F0aW9uLnBhcmFtcyk7XG5cdFx0XHRwYXRoID0gbWF0Y2hlci5zdHJpbmdpZnkocGFyYW1zKTtcblx0XHR9XG5cdFx0Y29uc3QgbWF0Y2hlZCA9IFtdO1xuXHRcdGxldCBwYXJlbnRNYXRjaGVyID0gbWF0Y2hlcjtcblx0XHR3aGlsZSAocGFyZW50TWF0Y2hlcikge1xuXHRcdFx0bWF0Y2hlZC51bnNoaWZ0KHBhcmVudE1hdGNoZXIucmVjb3JkKTtcblx0XHRcdHBhcmVudE1hdGNoZXIgPSBwYXJlbnRNYXRjaGVyLnBhcmVudDtcblx0XHR9XG5cdFx0cmV0dXJuIHtcblx0XHRcdG5hbWUsXG5cdFx0XHRwYXRoLFxuXHRcdFx0cGFyYW1zLFxuXHRcdFx0bWF0Y2hlZCxcblx0XHRcdG1ldGE6IG1lcmdlTWV0YUZpZWxkcyhtYXRjaGVkKVxuXHRcdH07XG5cdH1cblx0cm91dGVzLmZvckVhY2goKHJvdXRlKSA9PiBhZGRSb3V0ZShyb3V0ZSkpO1xuXHRmdW5jdGlvbiBjbGVhclJvdXRlcygpIHtcblx0XHRtYXRjaGVycy5sZW5ndGggPSAwO1xuXHRcdG1hdGNoZXJNYXAuY2xlYXIoKTtcblx0fVxuXHRyZXR1cm4ge1xuXHRcdGFkZFJvdXRlLFxuXHRcdHJlc29sdmUsXG5cdFx0cmVtb3ZlUm91dGUsXG5cdFx0Y2xlYXJSb3V0ZXMsXG5cdFx0Z2V0Um91dGVzLFxuXHRcdGdldFJlY29yZE1hdGNoZXJcblx0fTtcbn1cbi8qKlxuKiBQaWNrcyBhbiBvYmplY3QgcGFyYW0gdG8gY29udGFpbiBvbmx5IHNwZWNpZmllZCBrZXlzLlxuKlxuKiBAcGFyYW0gcGFyYW1zIC0gcGFyYW1zIG9iamVjdCB0byBwaWNrIGZyb21cbiogQHBhcmFtIGtleXMgLSBrZXlzIHRvIHBpY2tcbiovXG5mdW5jdGlvbiBwaWNrUGFyYW1zKHBhcmFtcywga2V5cykge1xuXHRjb25zdCBuZXdQYXJhbXMgPSB7fTtcblx0Zm9yIChjb25zdCBrZXkgb2Yga2V5cykgaWYgKGtleSBpbiBwYXJhbXMpIG5ld1BhcmFtc1trZXldID0gcGFyYW1zW2tleV07XG5cdHJldHVybiBuZXdQYXJhbXM7XG59XG4vKipcbiogTm9ybWFsaXplcyBhIFJvdXRlUmVjb3JkUmF3LiBDcmVhdGVzIGEgY29weVxuKlxuKiBAcGFyYW0gcmVjb3JkXG4qIEByZXR1cm5zIHRoZSBub3JtYWxpemVkIHZlcnNpb25cbiovXG5mdW5jdGlvbiBub3JtYWxpemVSb3V0ZVJlY29yZChyZWNvcmQpIHtcblx0Y29uc3Qgbm9ybWFsaXplZCA9IHtcblx0XHRwYXRoOiByZWNvcmQucGF0aCxcblx0XHRyZWRpcmVjdDogcmVjb3JkLnJlZGlyZWN0LFxuXHRcdG5hbWU6IHJlY29yZC5uYW1lLFxuXHRcdG1ldGE6IHJlY29yZC5tZXRhIHx8IHt9LFxuXHRcdGFsaWFzT2Y6IHJlY29yZC5hbGlhc09mLFxuXHRcdGJlZm9yZUVudGVyOiByZWNvcmQuYmVmb3JlRW50ZXIsXG5cdFx0cHJvcHM6IG5vcm1hbGl6ZVJlY29yZFByb3BzKHJlY29yZCksXG5cdFx0Y2hpbGRyZW46IHJlY29yZC5jaGlsZHJlbiB8fCBbXSxcblx0XHRpbnN0YW5jZXM6IHt9LFxuXHRcdGxlYXZlR3VhcmRzOiAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpLFxuXHRcdHVwZGF0ZUd1YXJkczogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSxcblx0XHRlbnRlckNhbGxiYWNrczoge30sXG5cdFx0Y29tcG9uZW50czogXCJjb21wb25lbnRzXCIgaW4gcmVjb3JkID8gcmVjb3JkLmNvbXBvbmVudHMgfHwgbnVsbCA6IHJlY29yZC5jb21wb25lbnQgJiYgeyBkZWZhdWx0OiByZWNvcmQuY29tcG9uZW50IH1cblx0fTtcblx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5vcm1hbGl6ZWQsIFwibW9kc1wiLCB7IHZhbHVlOiB7fSB9KTtcblx0cmV0dXJuIG5vcm1hbGl6ZWQ7XG59XG4vKipcbiogTm9ybWFsaXplIHRoZSBvcHRpb25hbCBgcHJvcHNgIGluIGEgcmVjb3JkIHRvIGFsd2F5cyBiZSBhbiBvYmplY3Qgc2ltaWxhciB0b1xuKiBjb21wb25lbnRzLiBBbHNvIGFjY2VwdCBhIGJvb2xlYW4gZm9yIGNvbXBvbmVudHMuXG4qIEBwYXJhbSByZWNvcmRcbiovXG5mdW5jdGlvbiBub3JtYWxpemVSZWNvcmRQcm9wcyhyZWNvcmQpIHtcblx0Y29uc3QgcHJvcHNPYmplY3QgPSB7fTtcblx0Y29uc3QgcHJvcHMgPSByZWNvcmQucHJvcHMgfHwgZmFsc2U7XG5cdGlmIChcImNvbXBvbmVudFwiIGluIHJlY29yZCkgcHJvcHNPYmplY3QuZGVmYXVsdCA9IHByb3BzO1xuXHRlbHNlIGZvciAoY29uc3QgbmFtZSBpbiByZWNvcmQuY29tcG9uZW50cykgcHJvcHNPYmplY3RbbmFtZV0gPSB0eXBlb2YgcHJvcHMgPT09IFwib2JqZWN0XCIgPyBwcm9wc1tuYW1lXSA6IHByb3BzO1xuXHRyZXR1cm4gcHJvcHNPYmplY3Q7XG59XG4vKipcbiogQ2hlY2tzIGlmIGEgcmVjb3JkIG9yIGFueSBvZiBpdHMgcGFyZW50IGlzIGFuIGFsaWFzXG4qIEBwYXJhbSByZWNvcmRcbiovXG5mdW5jdGlvbiBpc0FsaWFzUmVjb3JkKHJlY29yZCkge1xuXHR3aGlsZSAocmVjb3JkKSB7XG5cdFx0aWYgKHJlY29yZC5yZWNvcmQuYWxpYXNPZikgcmV0dXJuIHRydWU7XG5cdFx0cmVjb3JkID0gcmVjb3JkLnBhcmVudDtcblx0fVxuXHRyZXR1cm4gZmFsc2U7XG59XG4vKipcbiogTWVyZ2UgbWV0YSBmaWVsZHMgb2YgYW4gYXJyYXkgb2YgcmVjb3Jkc1xuKlxuKiBAcGFyYW0gbWF0Y2hlZCAtIGFycmF5IG9mIG1hdGNoZWQgcmVjb3Jkc1xuKi9cbmZ1bmN0aW9uIG1lcmdlTWV0YUZpZWxkcyhtYXRjaGVkKSB7XG5cdHJldHVybiBtYXRjaGVkLnJlZHVjZSgobWV0YSwgcmVjb3JkKSA9PiBhc3NpZ24obWV0YSwgcmVjb3JkLm1ldGEpLCB7fSk7XG59XG5mdW5jdGlvbiBpc1NhbWVQYXJhbShhLCBiKSB7XG5cdHJldHVybiBhLm5hbWUgPT09IGIubmFtZSAmJiBhLm9wdGlvbmFsID09PSBiLm9wdGlvbmFsICYmIGEucmVwZWF0YWJsZSA9PT0gYi5yZXBlYXRhYmxlO1xufVxuLyoqXG4qIENoZWNrIGlmIGEgcGF0aCBhbmQgaXRzIGFsaWFzIGhhdmUgdGhlIHNhbWUgcmVxdWlyZWQgcGFyYW1zXG4qXG4qIEBwYXJhbSBhIC0gb3JpZ2luYWwgcmVjb3JkXG4qIEBwYXJhbSBiIC0gYWxpYXMgcmVjb3JkXG4qL1xuZnVuY3Rpb24gY2hlY2tTYW1lUGFyYW1zKGEsIGIpIHtcblx0Zm9yIChjb25zdCBrZXkgb2YgYS5rZXlzKSBpZiAoIWtleS5vcHRpb25hbCAmJiAhYi5rZXlzLmZpbmQoaXNTYW1lUGFyYW0uYmluZChudWxsLCBrZXkpKSkge1xuXHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAxMDIoe1xuXHRcdFx0YWxpYXM6IGIucmVjb3JkLnBhdGgsXG5cdFx0XHRvcmlnaW5hbDogYS5yZWNvcmQucGF0aCxcblx0XHRcdG5hbWU6IGtleS5uYW1lXG5cdFx0fSk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGZvciAoY29uc3Qga2V5IG9mIGIua2V5cykgaWYgKCFrZXkub3B0aW9uYWwgJiYgIWEua2V5cy5maW5kKGlzU2FtZVBhcmFtLmJpbmQobnVsbCwga2V5KSkpIHtcblx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMTAyKHtcblx0XHRcdGFsaWFzOiBiLnJlY29yZC5wYXRoLFxuXHRcdFx0b3JpZ2luYWw6IGEucmVjb3JkLnBhdGgsXG5cdFx0XHRuYW1lOiBrZXkubmFtZVxuXHRcdH0pO1xuXHRcdHJldHVybjtcblx0fVxufVxuLyoqXG4qIEEgcm91dGUgd2l0aCBhIG5hbWUgYW5kIGEgY2hpbGQgd2l0aCBhbiBlbXB0eSBwYXRoIHdpdGhvdXQgYSBuYW1lIHNob3VsZCB3YXJuIHdoZW4gYWRkaW5nIHRoZSByb3V0ZVxuKlxuKiBAcGFyYW0gbWFpbk5vcm1hbGl6ZWRSZWNvcmQgLSBSb3V0ZVJlY29yZE5vcm1hbGl6ZWRcbiogQHBhcmFtIHBhcmVudCAtIFJvdXRlUmVjb3JkTWF0Y2hlclxuKi9cbmZ1bmN0aW9uIGNoZWNrQ2hpbGRNaXNzaW5nTmFtZVdpdGhFbXB0eVBhdGgobWFpbk5vcm1hbGl6ZWRSZWNvcmQsIHBhcmVudCkge1xuXHRpZiAocGFyZW50ICYmIHBhcmVudC5yZWNvcmQubmFtZSAmJiAhbWFpbk5vcm1hbGl6ZWRSZWNvcmQubmFtZSAmJiAhbWFpbk5vcm1hbGl6ZWRSZWNvcmQucGF0aCAmJiBtYWluTm9ybWFsaXplZFJlY29yZC5jaGlsZHJlbi5sZW5ndGggPT09IDApIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAxMDMoeyBuYW1lOiBTdHJpbmcocGFyZW50LnJlY29yZC5uYW1lKSB9KTtcbn1cbmZ1bmN0aW9uIGNoZWNrU2FtZU5hbWVBc0FuY2VzdG9yKHJlY29yZCwgcGFyZW50KSB7XG5cdGZvciAobGV0IGFuY2VzdG9yID0gcGFyZW50OyBhbmNlc3RvcjsgYW5jZXN0b3IgPSBhbmNlc3Rvci5wYXJlbnQpIGlmIChhbmNlc3Rvci5yZWNvcmQubmFtZSA9PT0gcmVjb3JkLm5hbWUpIHRocm93IG5ldyBFcnJvcihgQSByb3V0ZSBuYW1lZCBcIiR7U3RyaW5nKHJlY29yZC5uYW1lKX1cIiBoYXMgYmVlbiBhZGRlZCBhcyBhICR7cGFyZW50ID09PSBhbmNlc3RvciA/IFwiY2hpbGRcIiA6IFwiZGVzY2VuZGFudFwifSBvZiBhIHJvdXRlIHdpdGggdGhlIHNhbWUgbmFtZS4gUm91dGUgbmFtZXMgbXVzdCBiZSB1bmlxdWUgYW5kIGEgbmVzdGVkIHJvdXRlIGNhbm5vdCB1c2UgdGhlIHNhbWUgbmFtZSBhcyBhbiBhbmNlc3Rvci5gKTtcbn1cbmZ1bmN0aW9uIGNoZWNrTWlzc2luZ1BhcmFtc0luQWJzb2x1dGVQYXRoKHJlY29yZCwgcGFyZW50KSB7XG5cdGZvciAoY29uc3Qga2V5IG9mIHBhcmVudC5rZXlzKSBpZiAoIXJlY29yZC5rZXlzLmZpbmQoaXNTYW1lUGFyYW0uYmluZChudWxsLCBrZXkpKSkge1xuXHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAxMDQoe1xuXHRcdFx0cGF0aDogcmVjb3JkLnJlY29yZC5wYXRoLFxuXHRcdFx0bmFtZToga2V5Lm5hbWUsXG5cdFx0XHRwYXJlbnQ6IHBhcmVudC5yZWNvcmQucGF0aFxuXHRcdH0pO1xuXHRcdHJldHVybjtcblx0fVxufVxuLyoqXG4qIFBlcmZvcm1zIGEgYmluYXJ5IHNlYXJjaCB0byBmaW5kIHRoZSBjb3JyZWN0IGluc2VydGlvbiBpbmRleCBmb3IgYSBuZXcgbWF0Y2hlci5cbipcbiogTWF0Y2hlcnMgYXJlIHByaW1hcmlseSBzb3J0ZWQgYnkgdGhlaXIgc2NvcmUuIElmIHNjb3JlcyBhcmUgdGllZCB0aGVuIHdlIGFsc28gY29uc2lkZXIgcGFyZW50L2NoaWxkIHJlbGF0aW9uc2hpcHMsXG4qIHdpdGggZGVzY2VuZGFudHMgY29taW5nIGJlZm9yZSBhbmNlc3RvcnMuIElmIHRoZXJlJ3Mgc3RpbGwgYSB0aWUsIG5ldyByb3V0ZXMgYXJlIGluc2VydGVkIGFmdGVyIGV4aXN0aW5nIHJvdXRlcy5cbipcbiogQHBhcmFtIG1hdGNoZXIgLSBuZXcgbWF0Y2hlciB0byBiZSBpbnNlcnRlZFxuKiBAcGFyYW0gbWF0Y2hlcnMgLSBleGlzdGluZyBtYXRjaGVyc1xuKi9cbmZ1bmN0aW9uIGZpbmRJbnNlcnRpb25JbmRleChtYXRjaGVyLCBtYXRjaGVycykge1xuXHRsZXQgbG93ZXIgPSAwO1xuXHRsZXQgdXBwZXIgPSBtYXRjaGVycy5sZW5ndGg7XG5cdHdoaWxlIChsb3dlciAhPT0gdXBwZXIpIHtcblx0XHRjb25zdCBtaWQgPSBsb3dlciArIHVwcGVyID4+IDE7XG5cdFx0aWYgKGNvbXBhcmVQYXRoUGFyc2VyU2NvcmUobWF0Y2hlciwgbWF0Y2hlcnNbbWlkXSkgPCAwKSB1cHBlciA9IG1pZDtcblx0XHRlbHNlIGxvd2VyID0gbWlkICsgMTtcblx0fVxuXHRjb25zdCBpbnNlcnRpb25BbmNlc3RvciA9IGdldEluc2VydGlvbkFuY2VzdG9yKG1hdGNoZXIpO1xuXHRpZiAoaW5zZXJ0aW9uQW5jZXN0b3IpIHtcblx0XHR1cHBlciA9IG1hdGNoZXJzLmxhc3RJbmRleE9mKGluc2VydGlvbkFuY2VzdG9yLCB1cHBlciAtIDEpO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgdXBwZXIgPCAwKSBkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMTA1KHtcblx0XHRcdGFuY2VzdG9yOiBpbnNlcnRpb25BbmNlc3Rvci5yZWNvcmQucGF0aCxcblx0XHRcdHJlY29yZDogbWF0Y2hlci5yZWNvcmQucGF0aFxuXHRcdH0pO1xuXHR9XG5cdHJldHVybiB1cHBlcjtcbn1cbmZ1bmN0aW9uIGdldEluc2VydGlvbkFuY2VzdG9yKG1hdGNoZXIpIHtcblx0bGV0IGFuY2VzdG9yID0gbWF0Y2hlcjtcblx0d2hpbGUgKGFuY2VzdG9yID0gYW5jZXN0b3IucGFyZW50KSBpZiAoaXNNYXRjaGFibGUoYW5jZXN0b3IpICYmIGNvbXBhcmVQYXRoUGFyc2VyU2NvcmUobWF0Y2hlciwgYW5jZXN0b3IpID09PSAwKSByZXR1cm4gYW5jZXN0b3I7XG59XG4vKipcbiogQ2hlY2tzIGlmIGEgbWF0Y2hlciBjYW4gYmUgcmVhY2hhYmxlLiBUaGlzIG1lYW5zIGlmIGl0J3MgcG9zc2libGUgdG8gcmVhY2ggaXQgYXMgYSByb3V0ZS4gRm9yIGV4YW1wbGUsIHJvdXRlcyB3aXRob3V0XG4qIGEgY29tcG9uZW50LCBvciBuYW1lLCBvciByZWRpcmVjdCwgYXJlIGp1c3QgdXNlZCB0byBncm91cCBvdGhlciByb3V0ZXMuXG4qIEBwYXJhbSBtYXRjaGVyXG4qIEBwYXJhbSBtYXRjaGVyLnJlY29yZCByZWNvcmQgb2YgdGhlIG1hdGNoZXJcbiogQHJldHVybnNcbiovXG5mdW5jdGlvbiBpc01hdGNoYWJsZSh7IHJlY29yZCB9KSB7XG5cdHJldHVybiAhIShyZWNvcmQubmFtZSB8fCByZWNvcmQuY29tcG9uZW50cyAmJiBPYmplY3Qua2V5cyhyZWNvcmQuY29tcG9uZW50cykubGVuZ3RoIHx8IHJlY29yZC5yZWRpcmVjdCk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvUm91dGVyTGluay50c1xuLyoqXG4qIFJldHVybnMgdGhlIGludGVybmFsIGJlaGF2aW9yIG9mIGEge0BsaW5rIFJvdXRlckxpbmt9IHdpdGhvdXQgdGhlIHJlbmRlcmluZyBwYXJ0LlxuKlxuKiBAcGFyYW0gcHJvcHMgLSBhIGB0b2AgbG9jYXRpb24gYW5kIGFuIG9wdGlvbmFsIGByZXBsYWNlYCBmbGFnXG4qL1xuZnVuY3Rpb24gdXNlTGluayhwcm9wcykge1xuXHRjb25zdCByb3V0ZXIgPSBpbmplY3Qocm91dGVyS2V5KTtcblx0Y29uc3QgY3VycmVudFJvdXRlID0gaW5qZWN0KHJvdXRlTG9jYXRpb25LZXkpO1xuXHRsZXQgaGFzUHJldmlvdXMgPSBmYWxzZTtcblx0bGV0IHByZXZpb3VzVG8gPSBudWxsO1xuXHRjb25zdCByb3V0ZSA9IGNvbXB1dGVkKCgpID0+IHtcblx0XHRjb25zdCB0byA9IHVucmVmKHByb3BzLnRvKTtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICghaGFzUHJldmlvdXMgfHwgdG8gIT09IHByZXZpb3VzVG8pKSB7XG5cdFx0XHRpZiAoIWlzUm91dGVMb2NhdGlvbih0bykpIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwNTAoeyB0byB9KTtcblx0XHRcdHByZXZpb3VzVG8gPSB0bztcblx0XHRcdGhhc1ByZXZpb3VzID0gdHJ1ZTtcblx0XHR9XG5cdFx0cmV0dXJuIHJvdXRlci5yZXNvbHZlKHRvKTtcblx0fSk7XG5cdGNvbnN0IGFjdGl2ZVJlY29yZEluZGV4ID0gY29tcHV0ZWQoKCkgPT4ge1xuXHRcdGNvbnN0IHsgbWF0Y2hlZCB9ID0gcm91dGUudmFsdWU7XG5cdFx0Y29uc3QgeyBsZW5ndGggfSA9IG1hdGNoZWQ7XG5cdFx0Y29uc3Qgcm91dGVNYXRjaGVkID0gbWF0Y2hlZFtsZW5ndGggLSAxXTtcblx0XHRjb25zdCBjdXJyZW50TWF0Y2hlZCA9IGN1cnJlbnRSb3V0ZS5tYXRjaGVkO1xuXHRcdGlmICghcm91dGVNYXRjaGVkIHx8ICFjdXJyZW50TWF0Y2hlZC5sZW5ndGgpIHJldHVybiAtMTtcblx0XHRjb25zdCBpbmRleCA9IGN1cnJlbnRNYXRjaGVkLmZpbmRJbmRleChpc1NhbWVSb3V0ZVJlY29yZC5iaW5kKG51bGwsIHJvdXRlTWF0Y2hlZCkpO1xuXHRcdGlmIChpbmRleCA+IC0xKSByZXR1cm4gaW5kZXg7XG5cdFx0Y29uc3QgcGFyZW50UmVjb3JkUGF0aCA9IGdldE9yaWdpbmFsUGF0aChtYXRjaGVkW2xlbmd0aCAtIDJdKTtcblx0XHRyZXR1cm4gbGVuZ3RoID4gMSAmJiBnZXRPcmlnaW5hbFBhdGgocm91dGVNYXRjaGVkKSA9PT0gcGFyZW50UmVjb3JkUGF0aCAmJiBjdXJyZW50TWF0Y2hlZFtjdXJyZW50TWF0Y2hlZC5sZW5ndGggLSAxXS5wYXRoICE9PSBwYXJlbnRSZWNvcmRQYXRoID8gY3VycmVudE1hdGNoZWQuZmluZEluZGV4KGlzU2FtZVJvdXRlUmVjb3JkLmJpbmQobnVsbCwgbWF0Y2hlZFtsZW5ndGggLSAyXSkpIDogaW5kZXg7XG5cdH0pO1xuXHRjb25zdCBpc0FjdGl2ZSA9IGNvbXB1dGVkKCgpID0+IGFjdGl2ZVJlY29yZEluZGV4LnZhbHVlID4gLTEgJiYgaW5jbHVkZXNQYXJhbXMoY3VycmVudFJvdXRlLnBhcmFtcywgcm91dGUudmFsdWUucGFyYW1zKSk7XG5cdGNvbnN0IGlzRXhhY3RBY3RpdmUgPSBjb21wdXRlZCgoKSA9PiBhY3RpdmVSZWNvcmRJbmRleC52YWx1ZSA+IC0xICYmIGFjdGl2ZVJlY29yZEluZGV4LnZhbHVlID09PSBjdXJyZW50Um91dGUubWF0Y2hlZC5sZW5ndGggLSAxICYmIGlzU2FtZVJvdXRlTG9jYXRpb25QYXJhbXMoY3VycmVudFJvdXRlLnBhcmFtcywgcm91dGUudmFsdWUucGFyYW1zKSk7XG5cdGZ1bmN0aW9uIG5hdmlnYXRlKGUgPSB7fSkge1xuXHRcdGlmIChndWFyZEV2ZW50KGUpKSB7XG5cdFx0XHRjb25zdCBwID0gcm91dGVyW3VucmVmKHByb3BzLnJlcGxhY2UpID8gXCJyZXBsYWNlXCIgOiBcInB1c2hcIl0odW5yZWYocHJvcHMudG8pKS5jYXRjaChub29wKTtcblx0XHRcdGlmIChwcm9wcy52aWV3VHJhbnNpdGlvbiAmJiB0eXBlb2YgZG9jdW1lbnQgIT09IFwidW5kZWZpbmVkXCIgJiYgXCJzdGFydFZpZXdUcmFuc2l0aW9uXCIgaW4gZG9jdW1lbnQpIGRvY3VtZW50LnN0YXJ0Vmlld1RyYW5zaXRpb24oKCkgPT4gcCk7XG5cdFx0XHRyZXR1cm4gcDtcblx0XHR9XG5cdFx0cmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuXHR9XG5cdGlmICgocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykgJiYgaXNCcm93c2VyKSB7XG5cdFx0Y29uc3QgaW5zdGFuY2UgPSBnZXRDdXJyZW50SW5zdGFuY2UoKTtcblx0XHRpZiAoaW5zdGFuY2UpIHtcblx0XHRcdGNvbnN0IGxpbmtDb250ZXh0RGV2dG9vbHMgPSB7XG5cdFx0XHRcdHJvdXRlOiByb3V0ZS52YWx1ZSxcblx0XHRcdFx0aXNBY3RpdmU6IGlzQWN0aXZlLnZhbHVlLFxuXHRcdFx0XHRpc0V4YWN0QWN0aXZlOiBpc0V4YWN0QWN0aXZlLnZhbHVlLFxuXHRcdFx0XHRlcnJvcjogbnVsbFxuXHRcdFx0fTtcblx0XHRcdGluc3RhbmNlLl9fdnJsX2RldnRvb2xzID0gaW5zdGFuY2UuX192cmxfZGV2dG9vbHMgfHwgW107XG5cdFx0XHRpbnN0YW5jZS5fX3ZybF9kZXZ0b29scy5wdXNoKGxpbmtDb250ZXh0RGV2dG9vbHMpO1xuXHRcdFx0d2F0Y2hFZmZlY3QoKCkgPT4ge1xuXHRcdFx0XHRsaW5rQ29udGV4dERldnRvb2xzLnJvdXRlID0gcm91dGUudmFsdWU7XG5cdFx0XHRcdGxpbmtDb250ZXh0RGV2dG9vbHMuaXNBY3RpdmUgPSBpc0FjdGl2ZS52YWx1ZTtcblx0XHRcdFx0bGlua0NvbnRleHREZXZ0b29scy5pc0V4YWN0QWN0aXZlID0gaXNFeGFjdEFjdGl2ZS52YWx1ZTtcblx0XHRcdFx0bGlua0NvbnRleHREZXZ0b29scy5lcnJvciA9IGlzUm91dGVMb2NhdGlvbih1bnJlZihwcm9wcy50bykpID8gbnVsbCA6IFwiSW52YWxpZCBcXFwidG9cXFwiIHZhbHVlXCI7XG5cdFx0XHR9LCB7IGZsdXNoOiBcInBvc3RcIiB9KTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogTk9URTogdXBkYXRlIHtAbGluayBfUm91dGVyTGlua0l9J3MgYCRzbG90c2AgdHlwZSB3aGVuIHVwZGF0aW5nIHRoaXNcblx0Ki9cblx0cmV0dXJuIHtcblx0XHRyb3V0ZSxcblx0XHRocmVmOiBjb21wdXRlZCgoKSA9PiByb3V0ZS52YWx1ZS5ocmVmKSxcblx0XHRpc0FjdGl2ZSxcblx0XHRpc0V4YWN0QWN0aXZlLFxuXHRcdG5hdmlnYXRlXG5cdH07XG59XG5mdW5jdGlvbiBwcmVmZXJTaW5nbGVWTm9kZSh2bm9kZXMpIHtcblx0cmV0dXJuIHZub2Rlcy5sZW5ndGggPT09IDEgPyB2bm9kZXNbMF0gOiB2bm9kZXM7XG59XG4vKipcbiogQ29tcG9uZW50IHRvIHJlbmRlciBhIGxpbmsgdGhhdCB0cmlnZ2VycyBhIG5hdmlnYXRpb24gb24gY2xpY2suXG4qL1xuY29uc3QgUm91dGVyTGluayA9IC8qIEBfX1BVUkVfXyAqLyBkZWZpbmVDb21wb25lbnQoe1xuXHRuYW1lOiBcIlJvdXRlckxpbmtcIixcblx0Y29tcGF0Q29uZmlnOiB7IE1PREU6IDMgfSxcblx0cHJvcHM6IHtcblx0XHR0bzoge1xuXHRcdFx0dHlwZTogW1N0cmluZywgT2JqZWN0XSxcblx0XHRcdHJlcXVpcmVkOiB0cnVlXG5cdFx0fSxcblx0XHRyZXBsYWNlOiBCb29sZWFuLFxuXHRcdGFjdGl2ZUNsYXNzOiBTdHJpbmcsXG5cdFx0ZXhhY3RBY3RpdmVDbGFzczogU3RyaW5nLFxuXHRcdGN1c3RvbTogQm9vbGVhbixcblx0XHRhcmlhQ3VycmVudFZhbHVlOiB7XG5cdFx0XHR0eXBlOiBTdHJpbmcsXG5cdFx0XHRkZWZhdWx0OiBcInBhZ2VcIlxuXHRcdH0sXG5cdFx0dmlld1RyYW5zaXRpb246IEJvb2xlYW5cblx0fSxcblx0dXNlTGluayxcblx0c2V0dXAocHJvcHMsIHsgc2xvdHMgfSkge1xuXHRcdGNvbnN0IGxpbmsgPSByZWFjdGl2ZSh1c2VMaW5rKHByb3BzKSk7XG5cdFx0Y29uc3QgeyBvcHRpb25zIH0gPSBpbmplY3Qocm91dGVyS2V5KTtcblx0XHRjb25zdCBlbENsYXNzID0gY29tcHV0ZWQoKCkgPT4gKHtcblx0XHRcdFtnZXRMaW5rQ2xhc3MocHJvcHMuYWN0aXZlQ2xhc3MsIG9wdGlvbnMubGlua0FjdGl2ZUNsYXNzLCBcInJvdXRlci1saW5rLWFjdGl2ZVwiKV06IGxpbmsuaXNBY3RpdmUsXG5cdFx0XHRbZ2V0TGlua0NsYXNzKHByb3BzLmV4YWN0QWN0aXZlQ2xhc3MsIG9wdGlvbnMubGlua0V4YWN0QWN0aXZlQ2xhc3MsIFwicm91dGVyLWxpbmstZXhhY3QtYWN0aXZlXCIpXTogbGluay5pc0V4YWN0QWN0aXZlXG5cdFx0fSkpO1xuXHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRjb25zdCBjaGlsZHJlbiA9IHNsb3RzLmRlZmF1bHQgJiYgcHJlZmVyU2luZ2xlVk5vZGUoc2xvdHMuZGVmYXVsdChsaW5rKSk7XG5cdFx0XHRyZXR1cm4gcHJvcHMuY3VzdG9tID8gY2hpbGRyZW4gOiBoKFwiYVwiLCB7XG5cdFx0XHRcdFwiYXJpYS1jdXJyZW50XCI6IGxpbmsuaXNFeGFjdEFjdGl2ZSA/IHByb3BzLmFyaWFDdXJyZW50VmFsdWUgOiBudWxsLFxuXHRcdFx0XHRocmVmOiBsaW5rLmhyZWYsXG5cdFx0XHRcdG9uQ2xpY2s6IGxpbmsubmF2aWdhdGUsXG5cdFx0XHRcdGNsYXNzOiBlbENsYXNzLnZhbHVlXG5cdFx0XHR9LCBjaGlsZHJlbik7XG5cdFx0fTtcblx0fVxufSk7XG5mdW5jdGlvbiBndWFyZEV2ZW50KGUpIHtcblx0aWYgKGUubWV0YUtleSB8fCBlLmFsdEtleSB8fCBlLmN0cmxLZXkgfHwgZS5zaGlmdEtleSkgcmV0dXJuO1xuXHRpZiAoZS5kZWZhdWx0UHJldmVudGVkKSByZXR1cm47XG5cdGlmIChlLmJ1dHRvbiAhPT0gdm9pZCAwICYmIGUuYnV0dG9uICE9PSAwKSByZXR1cm47XG5cdGlmIChlLmN1cnJlbnRUYXJnZXQgJiYgZS5jdXJyZW50VGFyZ2V0LmdldEF0dHJpYnV0ZSkge1xuXHRcdGNvbnN0IHRhcmdldCA9IGUuY3VycmVudFRhcmdldC5nZXRBdHRyaWJ1dGUoXCJ0YXJnZXRcIik7XG5cdFx0aWYgKC9cXGJfYmxhbmtcXGIvaS50ZXN0KHRhcmdldCkpIHJldHVybjtcblx0fVxuXHRpZiAoZS5wcmV2ZW50RGVmYXVsdCkgZS5wcmV2ZW50RGVmYXVsdCgpO1xuXHRyZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIGluY2x1ZGVzUGFyYW1zKG91dGVyLCBpbm5lcikge1xuXHRmb3IgKGNvbnN0IGtleSBpbiBpbm5lcikge1xuXHRcdGNvbnN0IGlubmVyVmFsdWUgPSBpbm5lcltrZXldO1xuXHRcdGNvbnN0IG91dGVyVmFsdWUgPSBvdXRlcltrZXldO1xuXHRcdGlmICh0eXBlb2YgaW5uZXJWYWx1ZSA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0aWYgKGlubmVyVmFsdWUgIT09IG91dGVyVmFsdWUpIHJldHVybiBmYWxzZTtcblx0XHR9IGVsc2UgaWYgKCFpc0FycmF5KG91dGVyVmFsdWUpIHx8IG91dGVyVmFsdWUubGVuZ3RoICE9PSBpbm5lclZhbHVlLmxlbmd0aCB8fCBpbm5lclZhbHVlLnNvbWUoKHZhbHVlLCBpKSA9PiB2YWx1ZS52YWx1ZU9mKCkgIT09IG91dGVyVmFsdWVbaV0udmFsdWVPZigpKSkgcmV0dXJuIGZhbHNlO1xuXHR9XG5cdHJldHVybiB0cnVlO1xufVxuLyoqXG4qIEdldCB0aGUgb3JpZ2luYWwgcGF0aCB2YWx1ZSBvZiBhIHJlY29yZCBieSBmb2xsb3dpbmcgaXRzIGFsaWFzT2ZcbiogQHBhcmFtIHJlY29yZFxuKi9cbmZ1bmN0aW9uIGdldE9yaWdpbmFsUGF0aChyZWNvcmQpIHtcblx0cmV0dXJuIHJlY29yZCA/IHJlY29yZC5hbGlhc09mID8gcmVjb3JkLmFsaWFzT2YucGF0aCA6IHJlY29yZC5wYXRoIDogXCJcIjtcbn1cbi8qKlxuKiBVdGlsaXR5IGNsYXNzIHRvIGdldCB0aGUgYWN0aXZlIGNsYXNzIGJhc2VkIG9uIGRlZmF1bHRzLlxuKiBAcGFyYW0gcHJvcENsYXNzXG4qIEBwYXJhbSBnbG9iYWxDbGFzc1xuKiBAcGFyYW0gZGVmYXVsdENsYXNzXG4qL1xuY29uc3QgZ2V0TGlua0NsYXNzID0gKHByb3BDbGFzcywgZ2xvYmFsQ2xhc3MsIGRlZmF1bHRDbGFzcykgPT4gcHJvcENsYXNzICE9IG51bGwgPyBwcm9wQ2xhc3MgOiBnbG9iYWxDbGFzcyAhPSBudWxsID8gZ2xvYmFsQ2xhc3MgOiBkZWZhdWx0Q2xhc3M7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvUm91dGVyVmlldy50c1xuY29uc3QgUm91dGVyVmlld0ltcGwgPSAvKiNfX1BVUkVfXyovIGRlZmluZUNvbXBvbmVudCh7XG5cdG5hbWU6IFwiUm91dGVyVmlld1wiLFxuXHRpbmhlcml0QXR0cnM6IGZhbHNlLFxuXHRwcm9wczoge1xuXHRcdG5hbWU6IHtcblx0XHRcdHR5cGU6IFN0cmluZyxcblx0XHRcdGRlZmF1bHQ6IFwiZGVmYXVsdFwiXG5cdFx0fSxcblx0XHRyb3V0ZTogT2JqZWN0XG5cdH0sXG5cdGNvbXBhdENvbmZpZzogeyBNT0RFOiAzIH0sXG5cdHNldHVwKHByb3BzLCB7IGF0dHJzLCBzbG90cyB9KSB7XG5cdFx0cHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIHdhcm5EZXByZWNhdGVkVXNhZ2UoKTtcblx0XHRjb25zdCBpbmplY3RlZFJvdXRlID0gaW5qZWN0KHJvdXRlclZpZXdMb2NhdGlvbktleSk7XG5cdFx0Y29uc3Qgcm91dGVUb0Rpc3BsYXkgPSBjb21wdXRlZCgoKSA9PiBwcm9wcy5yb3V0ZSB8fCBpbmplY3RlZFJvdXRlLnZhbHVlKTtcblx0XHRjb25zdCBpbmplY3RlZERlcHRoID0gaW5qZWN0KHZpZXdEZXB0aEtleSwgMCk7XG5cdFx0Y29uc3QgZGVwdGggPSBjb21wdXRlZCgoKSA9PiB7XG5cdFx0XHRsZXQgaW5pdGlhbERlcHRoID0gdW5yZWYoaW5qZWN0ZWREZXB0aCk7XG5cdFx0XHRjb25zdCB7IG1hdGNoZWQgfSA9IHJvdXRlVG9EaXNwbGF5LnZhbHVlO1xuXHRcdFx0bGV0IG1hdGNoZWRSb3V0ZTtcblx0XHRcdHdoaWxlICgobWF0Y2hlZFJvdXRlID0gbWF0Y2hlZFtpbml0aWFsRGVwdGhdKSAmJiAhbWF0Y2hlZFJvdXRlLmNvbXBvbmVudHMpIGluaXRpYWxEZXB0aCsrO1xuXHRcdFx0cmV0dXJuIGluaXRpYWxEZXB0aDtcblx0XHR9KTtcblx0XHRjb25zdCBtYXRjaGVkUm91dGVSZWYgPSBjb21wdXRlZCgoKSA9PiByb3V0ZVRvRGlzcGxheS52YWx1ZS5tYXRjaGVkW2RlcHRoLnZhbHVlXSk7XG5cdFx0cHJvdmlkZSh2aWV3RGVwdGhLZXksIGNvbXB1dGVkKCgpID0+IGRlcHRoLnZhbHVlICsgMSkpO1xuXHRcdHByb3ZpZGUobWF0Y2hlZFJvdXRlS2V5LCBtYXRjaGVkUm91dGVSZWYpO1xuXHRcdHByb3ZpZGUocm91dGVyVmlld0xvY2F0aW9uS2V5LCByb3V0ZVRvRGlzcGxheSk7XG5cdFx0Y29uc3Qgdmlld1JlZiA9IHJlZigpO1xuXHRcdHdhdGNoKCgpID0+IFtcblx0XHRcdHZpZXdSZWYudmFsdWUsXG5cdFx0XHRtYXRjaGVkUm91dGVSZWYudmFsdWUsXG5cdFx0XHRwcm9wcy5uYW1lXG5cdFx0XSwgKFtpbnN0YW5jZSwgdG8sIG5hbWVdLCBbb2xkSW5zdGFuY2UsIGZyb20sIF9vbGROYW1lXSkgPT4ge1xuXHRcdFx0aWYgKHRvKSB7XG5cdFx0XHRcdHRvLmluc3RhbmNlc1tuYW1lXSA9IGluc3RhbmNlO1xuXHRcdFx0XHRpZiAoZnJvbSAmJiBmcm9tICE9PSB0byAmJiBpbnN0YW5jZSAmJiBpbnN0YW5jZSA9PT0gb2xkSW5zdGFuY2UpIHtcblx0XHRcdFx0XHRpZiAoIXRvLmxlYXZlR3VhcmRzLnNpemUpIHRvLmxlYXZlR3VhcmRzID0gZnJvbS5sZWF2ZUd1YXJkcztcblx0XHRcdFx0XHRpZiAoIXRvLnVwZGF0ZUd1YXJkcy5zaXplKSB0by51cGRhdGVHdWFyZHMgPSBmcm9tLnVwZGF0ZUd1YXJkcztcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKGluc3RhbmNlICYmIHRvICYmICghZnJvbSB8fCAhaXNTYW1lUm91dGVSZWNvcmQodG8sIGZyb20pIHx8ICFvbGRJbnN0YW5jZSkpICh0by5lbnRlckNhbGxiYWNrc1tuYW1lXSB8fCBbXSkuZm9yRWFjaCgoY2FsbGJhY2spID0+IGNhbGxiYWNrKGluc3RhbmNlKSk7XG5cdFx0fSwgeyBmbHVzaDogXCJwb3N0XCIgfSk7XG5cdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdGNvbnN0IHJvdXRlID0gcm91dGVUb0Rpc3BsYXkudmFsdWU7XG5cdFx0XHRjb25zdCBjdXJyZW50TmFtZSA9IHByb3BzLm5hbWU7XG5cdFx0XHRjb25zdCBtYXRjaGVkUm91dGUgPSBtYXRjaGVkUm91dGVSZWYudmFsdWU7XG5cdFx0XHRjb25zdCBWaWV3Q29tcG9uZW50ID0gbWF0Y2hlZFJvdXRlICYmIG1hdGNoZWRSb3V0ZS5jb21wb25lbnRzW2N1cnJlbnROYW1lXTtcblx0XHRcdGlmICghVmlld0NvbXBvbmVudCkgcmV0dXJuIG5vcm1hbGl6ZVNsb3Qoc2xvdHMuZGVmYXVsdCwge1xuXHRcdFx0XHRDb21wb25lbnQ6IFZpZXdDb21wb25lbnQsXG5cdFx0XHRcdHJvdXRlXG5cdFx0XHR9KTtcblx0XHRcdGNvbnN0IHJvdXRlUHJvcHNPcHRpb24gPSBtYXRjaGVkUm91dGUucHJvcHNbY3VycmVudE5hbWVdO1xuXHRcdFx0Y29uc3Qgcm91dGVQcm9wcyA9IHJvdXRlUHJvcHNPcHRpb24gPyByb3V0ZVByb3BzT3B0aW9uID09PSB0cnVlID8gcm91dGUucGFyYW1zIDogdHlwZW9mIHJvdXRlUHJvcHNPcHRpb24gPT09IFwiZnVuY3Rpb25cIiA/IHJvdXRlUHJvcHNPcHRpb24ocm91dGUpIDogcm91dGVQcm9wc09wdGlvbiA6IG51bGw7XG5cdFx0XHRjb25zdCBvblZub2RlVW5tb3VudGVkID0gKHZub2RlKSA9PiB7XG5cdFx0XHRcdGlmICh2bm9kZS5jb21wb25lbnQuaXNVbm1vdW50ZWQpIG1hdGNoZWRSb3V0ZS5pbnN0YW5jZXNbY3VycmVudE5hbWVdID0gbnVsbDtcblx0XHRcdH07XG5cdFx0XHRjb25zdCBjb21wb25lbnQgPSBoKFZpZXdDb21wb25lbnQsIGFzc2lnbih7fSwgcm91dGVQcm9wcywgYXR0cnMsIHtcblx0XHRcdFx0b25Wbm9kZVVubW91bnRlZCxcblx0XHRcdFx0cmVmOiB2aWV3UmVmXG5cdFx0XHR9KSk7XG5cdFx0XHRpZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pICYmIGlzQnJvd3NlciAmJiBjb21wb25lbnQucmVmKSB7XG5cdFx0XHRcdGNvbnN0IGluZm8gPSB7XG5cdFx0XHRcdFx0ZGVwdGg6IGRlcHRoLnZhbHVlLFxuXHRcdFx0XHRcdG5hbWU6IG1hdGNoZWRSb3V0ZS5uYW1lLFxuXHRcdFx0XHRcdHBhdGg6IG1hdGNoZWRSb3V0ZS5wYXRoLFxuXHRcdFx0XHRcdG1ldGE6IG1hdGNoZWRSb3V0ZS5tZXRhXG5cdFx0XHRcdH07XG5cdFx0XHRcdChpc0FycmF5KGNvbXBvbmVudC5yZWYpID8gY29tcG9uZW50LnJlZi5tYXAoKHIpID0+IHIuaSkgOiBbY29tcG9uZW50LnJlZi5pXSkuZm9yRWFjaCgoaW5zdGFuY2UpID0+IHtcblx0XHRcdFx0XHRpbnN0YW5jZS5fX3Zydl9kZXZ0b29scyA9IGluZm87XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIG5vcm1hbGl6ZVNsb3Qoc2xvdHMuZGVmYXVsdCwge1xuXHRcdFx0XHRDb21wb25lbnQ6IGNvbXBvbmVudCxcblx0XHRcdFx0cm91dGVcblx0XHRcdH0pIHx8IGNvbXBvbmVudDtcblx0XHR9O1xuXHR9XG59KTtcbmZ1bmN0aW9uIG5vcm1hbGl6ZVNsb3Qoc2xvdCwgZGF0YSkge1xuXHRpZiAoIXNsb3QpIHJldHVybiBudWxsO1xuXHRjb25zdCBzbG90Q29udGVudCA9IHNsb3QoZGF0YSk7XG5cdHJldHVybiBzbG90Q29udGVudC5sZW5ndGggPT09IDEgPyBzbG90Q29udGVudFswXSA6IHNsb3RDb250ZW50O1xufVxuLyoqXG4qIENvbXBvbmVudCB0byBkaXNwbGF5IHRoZSBjdXJyZW50IHJvdXRlIHRoZSB1c2VyIGlzIGF0LlxuKi9cbmNvbnN0IFJvdXRlclZpZXcgPSBSb3V0ZXJWaWV3SW1wbDtcbmZ1bmN0aW9uIHdhcm5EZXByZWNhdGVkVXNhZ2UoKSB7XG5cdGNvbnN0IGluc3RhbmNlID0gZ2V0Q3VycmVudEluc3RhbmNlKCk7XG5cdGNvbnN0IHBhcmVudE5hbWUgPSBpbnN0YW5jZS5wYXJlbnQgJiYgaW5zdGFuY2UucGFyZW50LnR5cGUubmFtZTtcblx0Y29uc3QgcGFyZW50U3ViVHJlZVR5cGUgPSBpbnN0YW5jZS5wYXJlbnQgJiYgaW5zdGFuY2UucGFyZW50LnN1YlRyZWUgJiYgaW5zdGFuY2UucGFyZW50LnN1YlRyZWUudHlwZTtcblx0aWYgKHBhcmVudE5hbWUgJiYgKHBhcmVudE5hbWUgPT09IFwiS2VlcEFsaXZlXCIgfHwgcGFyZW50TmFtZS5pbmNsdWRlcyhcIlRyYW5zaXRpb25cIikpICYmIHR5cGVvZiBwYXJlbnRTdWJUcmVlVHlwZSA9PT0gXCJvYmplY3RcIiAmJiBwYXJlbnRTdWJUcmVlVHlwZS5uYW1lID09PSBcIlJvdXRlclZpZXdcIikge1xuXHRcdGNvbnN0IGNvbXAgPSBwYXJlbnROYW1lID09PSBcIktlZXBBbGl2ZVwiID8gXCJrZWVwLWFsaXZlXCIgOiBcInRyYW5zaXRpb25cIjtcblx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDYwKHsgY29tcCB9KTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3JvdXRlci50c1xuLyoqXG4qIENyZWF0ZXMgYSBSb3V0ZXIgaW5zdGFuY2UgdGhhdCBjYW4gYmUgdXNlZCBieSBhIFZ1ZSBhcHAuXG4qXG4qIEBwYXJhbSBvcHRpb25zIC0ge0BsaW5rIFJvdXRlck9wdGlvbnN9XG4qL1xuZnVuY3Rpb24gY3JlYXRlUm91dGVyKG9wdGlvbnMpIHtcblx0Y29uc3QgbWF0Y2hlciA9IGNyZWF0ZVJvdXRlck1hdGNoZXIob3B0aW9ucy5yb3V0ZXMsIG9wdGlvbnMpO1xuXHRjb25zdCBwYXJzZVF1ZXJ5JDEgPSBvcHRpb25zLnBhcnNlUXVlcnkgfHwgcGFyc2VRdWVyeTtcblx0Y29uc3Qgc3RyaW5naWZ5UXVlcnkkMSA9IG9wdGlvbnMuc3RyaW5naWZ5UXVlcnkgfHwgc3RyaW5naWZ5UXVlcnk7XG5cdGNvbnN0IHJvdXRlckhpc3RvcnkgPSBvcHRpb25zLmhpc3Rvcnk7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgIXJvdXRlckhpc3RvcnkpIHRocm93IG5ldyBFcnJvcihcIlByb3ZpZGUgdGhlIFxcXCJoaXN0b3J5XFxcIiBvcHRpb24gd2hlbiBjYWxsaW5nIFxcXCJjcmVhdGVSb3V0ZXIoKVxcXCI6IGh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9hcGkvaW50ZXJmYWNlcy9Sb3V0ZXJPcHRpb25zLmh0bWwjaGlzdG9yeVwiKTtcblx0Y29uc3QgYmVmb3JlR3VhcmRzID0gdXNlQ2FsbGJhY2tzKCk7XG5cdGNvbnN0IGJlZm9yZVJlc29sdmVHdWFyZHMgPSB1c2VDYWxsYmFja3MoKTtcblx0Y29uc3QgYWZ0ZXJHdWFyZHMgPSB1c2VDYWxsYmFja3MoKTtcblx0Y29uc3QgY3VycmVudFJvdXRlID0gc2hhbGxvd1JlZihTVEFSVF9MT0NBVElPTl9OT1JNQUxJWkVEKTtcblx0bGV0IHBlbmRpbmdMb2NhdGlvbiA9IFNUQVJUX0xPQ0FUSU9OX05PUk1BTElaRUQ7XG5cdGlmIChpc0Jyb3dzZXIgJiYgb3B0aW9ucy5zY3JvbGxCZWhhdmlvciAmJiBcInNjcm9sbFJlc3RvcmF0aW9uXCIgaW4gaGlzdG9yeSkgaGlzdG9yeS5zY3JvbGxSZXN0b3JhdGlvbiA9IFwibWFudWFsXCI7XG5cdGNvbnN0IG5vcm1hbGl6ZVBhcmFtcyA9IGFwcGx5VG9QYXJhbXMuYmluZChudWxsLCAocGFyYW1WYWx1ZSkgPT4gXCJcIiArIHBhcmFtVmFsdWUpO1xuXHRjb25zdCBlbmNvZGVQYXJhbXMgPSBhcHBseVRvUGFyYW1zLmJpbmQobnVsbCwgZW5jb2RlUGFyYW0pO1xuXHRjb25zdCBkZWNvZGVQYXJhbXMgPSBhcHBseVRvUGFyYW1zLmJpbmQobnVsbCwgZGVjb2RlKTtcblx0ZnVuY3Rpb24gYWRkUm91dGUocGFyZW50T3JSb3V0ZSwgcm91dGUpIHtcblx0XHRsZXQgcGFyZW50O1xuXHRcdGxldCByZWNvcmQ7XG5cdFx0aWYgKGlzUm91dGVOYW1lKHBhcmVudE9yUm91dGUpKSB7XG5cdFx0XHRwYXJlbnQgPSBtYXRjaGVyLmdldFJlY29yZE1hdGNoZXIocGFyZW50T3JSb3V0ZSk7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFwYXJlbnQpIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMDEoeyBuYW1lOiBTdHJpbmcocGFyZW50T3JSb3V0ZSkgfSk7XG5cdFx0XHRyZWNvcmQgPSByb3V0ZTtcblx0XHR9IGVsc2UgcmVjb3JkID0gcGFyZW50T3JSb3V0ZTtcblx0XHRyZXR1cm4gbWF0Y2hlci5hZGRSb3V0ZShyZWNvcmQsIHBhcmVudCk7XG5cdH1cblx0ZnVuY3Rpb24gcmVtb3ZlUm91dGUobmFtZSkge1xuXHRcdGNvbnN0IHJlY29yZE1hdGNoZXIgPSBtYXRjaGVyLmdldFJlY29yZE1hdGNoZXIobmFtZSk7XG5cdFx0aWYgKHJlY29yZE1hdGNoZXIpIG1hdGNoZXIucmVtb3ZlUm91dGUocmVjb3JkTWF0Y2hlcik7XG5cdFx0ZWxzZSBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDAyKHsgbmFtZTogU3RyaW5nKG5hbWUpIH0pO1xuXHR9XG5cdGZ1bmN0aW9uIGdldFJvdXRlcygpIHtcblx0XHRyZXR1cm4gbWF0Y2hlci5nZXRSb3V0ZXMoKS5tYXAoKHJvdXRlTWF0Y2hlcikgPT4gcm91dGVNYXRjaGVyLnJlY29yZCk7XG5cdH1cblx0ZnVuY3Rpb24gaGFzUm91dGUobmFtZSkge1xuXHRcdHJldHVybiAhIW1hdGNoZXIuZ2V0UmVjb3JkTWF0Y2hlcihuYW1lKTtcblx0fVxuXHRmdW5jdGlvbiByZXNvbHZlKHJhd0xvY2F0aW9uLCBjdXJyZW50TG9jYXRpb24pIHtcblx0XHRjdXJyZW50TG9jYXRpb24gPSBhc3NpZ24oe30sIGN1cnJlbnRMb2NhdGlvbiB8fCBjdXJyZW50Um91dGUudmFsdWUpO1xuXHRcdGlmICh0eXBlb2YgcmF3TG9jYXRpb24gPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdGNvbnN0IGxvY2F0aW9uTm9ybWFsaXplZCA9IHBhcnNlVVJMKHBhcnNlUXVlcnkkMSwgcmF3TG9jYXRpb24sIGN1cnJlbnRMb2NhdGlvbi5wYXRoKTtcblx0XHRcdGNvbnN0IG1hdGNoZWRSb3V0ZSA9IG1hdGNoZXIucmVzb2x2ZSh7IHBhdGg6IGxvY2F0aW9uTm9ybWFsaXplZC5wYXRoIH0sIGN1cnJlbnRMb2NhdGlvbik7XG5cdFx0XHRjb25zdCBocmVmID0gcm91dGVySGlzdG9yeS5jcmVhdGVIcmVmKGxvY2F0aW9uTm9ybWFsaXplZC5mdWxsUGF0aCk7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0XHRcdGlmIChocmVmLnN0YXJ0c1dpdGgoXCIvL1wiKSkgZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDAwMyh7XG5cdFx0XHRcdFx0bG9jYXRpb246IHJhd0xvY2F0aW9uLFxuXHRcdFx0XHRcdGhyZWZcblx0XHRcdFx0fSk7XG5cdFx0XHRcdGVsc2UgaWYgKCFtYXRjaGVkUm91dGUubWF0Y2hlZC5sZW5ndGgpIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMDQoeyBwYXRoOiByYXdMb2NhdGlvbiB9KTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBhc3NpZ24obG9jYXRpb25Ob3JtYWxpemVkLCBtYXRjaGVkUm91dGUsIHtcblx0XHRcdFx0cGFyYW1zOiBkZWNvZGVQYXJhbXMobWF0Y2hlZFJvdXRlLnBhcmFtcyksXG5cdFx0XHRcdHJlZGlyZWN0ZWRGcm9tOiB2b2lkIDAsXG5cdFx0XHRcdGhyZWZcblx0XHRcdH0pO1xuXHRcdH1cblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFpc1JvdXRlTG9jYXRpb24ocmF3TG9jYXRpb24pKSB7XG5cdFx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDA1KHsgcmF3TG9jYXRpb24gfSk7XG5cdFx0XHRyZXR1cm4gcmVzb2x2ZSh7fSk7XG5cdFx0fVxuXHRcdGxldCBtYXRjaGVyTG9jYXRpb247XG5cdFx0aWYgKHJhd0xvY2F0aW9uLnBhdGggIT0gbnVsbCkge1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBcInBhcmFtc1wiIGluIHJhd0xvY2F0aW9uICYmICEoXCJuYW1lXCIgaW4gcmF3TG9jYXRpb24pICYmIE9iamVjdC5rZXlzKHJhd0xvY2F0aW9uLnBhcmFtcykubGVuZ3RoKSBkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDA2KHsgcGF0aDogcmF3TG9jYXRpb24ucGF0aCB9KTtcblx0XHRcdG1hdGNoZXJMb2NhdGlvbiA9IGFzc2lnbih7fSwgcmF3TG9jYXRpb24sIHsgcGF0aDogcGFyc2VVUkwocGFyc2VRdWVyeSQxLCByYXdMb2NhdGlvbi5wYXRoLCBjdXJyZW50TG9jYXRpb24ucGF0aCkucGF0aCB9KTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0Y29uc3QgdGFyZ2V0UGFyYW1zID0gYXNzaWduKHt9LCByYXdMb2NhdGlvbi5wYXJhbXMpO1xuXHRcdFx0Zm9yIChjb25zdCBrZXkgaW4gdGFyZ2V0UGFyYW1zKSBpZiAodGFyZ2V0UGFyYW1zW2tleV0gPT0gbnVsbCkgZGVsZXRlIHRhcmdldFBhcmFtc1trZXldO1xuXHRcdFx0bWF0Y2hlckxvY2F0aW9uID0gYXNzaWduKHt9LCByYXdMb2NhdGlvbiwgeyBwYXJhbXM6IGVuY29kZVBhcmFtcyh0YXJnZXRQYXJhbXMpIH0pO1xuXHRcdFx0Y3VycmVudExvY2F0aW9uLnBhcmFtcyA9IGVuY29kZVBhcmFtcyhjdXJyZW50TG9jYXRpb24ucGFyYW1zKTtcblx0XHR9XG5cdFx0Y29uc3QgbWF0Y2hlZFJvdXRlID0gbWF0Y2hlci5yZXNvbHZlKG1hdGNoZXJMb2NhdGlvbiwgY3VycmVudExvY2F0aW9uKTtcblx0XHRjb25zdCBoYXNoID0gcmF3TG9jYXRpb24uaGFzaCB8fCBcIlwiO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgaGFzaCAmJiAhaGFzaC5zdGFydHNXaXRoKFwiI1wiKSkgZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDAwNyh7IGhhc2ggfSk7XG5cdFx0bWF0Y2hlZFJvdXRlLnBhcmFtcyA9IG5vcm1hbGl6ZVBhcmFtcyhkZWNvZGVQYXJhbXMobWF0Y2hlZFJvdXRlLnBhcmFtcykpO1xuXHRcdGNvbnN0IGZ1bGxQYXRoID0gc3RyaW5naWZ5VVJMKHN0cmluZ2lmeVF1ZXJ5JDEsIGFzc2lnbih7fSwgcmF3TG9jYXRpb24sIHtcblx0XHRcdGhhc2g6IGVuY29kZUhhc2goaGFzaCksXG5cdFx0XHRwYXRoOiBtYXRjaGVkUm91dGUucGF0aFxuXHRcdH0pKTtcblx0XHRjb25zdCBocmVmID0gcm91dGVySGlzdG9yeS5jcmVhdGVIcmVmKGZ1bGxQYXRoKTtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0XHRpZiAoaHJlZi5zdGFydHNXaXRoKFwiLy9cIikpIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMDMoe1xuXHRcdFx0XHRsb2NhdGlvbjogcmF3TG9jYXRpb24sXG5cdFx0XHRcdGhyZWZcblx0XHRcdH0pO1xuXHRcdFx0ZWxzZSBpZiAoIW1hdGNoZWRSb3V0ZS5tYXRjaGVkLmxlbmd0aCkgZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDAwNCh7IHBhdGg6IHJhd0xvY2F0aW9uLnBhdGggIT0gbnVsbCA/IHJhd0xvY2F0aW9uLnBhdGggOiByYXdMb2NhdGlvbiB9KTtcblx0XHR9XG5cdFx0cmV0dXJuIGFzc2lnbih7XG5cdFx0XHRmdWxsUGF0aCxcblx0XHRcdGhhc2gsXG5cdFx0XHRxdWVyeTogc3RyaW5naWZ5UXVlcnkkMSA9PT0gc3RyaW5naWZ5UXVlcnkgPyBub3JtYWxpemVRdWVyeShyYXdMb2NhdGlvbi5xdWVyeSkgOiByYXdMb2NhdGlvbi5xdWVyeSB8fCB7fVxuXHRcdH0sIG1hdGNoZWRSb3V0ZSwge1xuXHRcdFx0cmVkaXJlY3RlZEZyb206IHZvaWQgMCxcblx0XHRcdGhyZWZcblx0XHR9KTtcblx0fVxuXHRmdW5jdGlvbiBsb2NhdGlvbkFzT2JqZWN0KHRvKSB7XG5cdFx0cmV0dXJuIHR5cGVvZiB0byA9PT0gXCJzdHJpbmdcIiA/IHBhcnNlVVJMKHBhcnNlUXVlcnkkMSwgdG8sIGN1cnJlbnRSb3V0ZS52YWx1ZS5wYXRoKSA6IGFzc2lnbih7fSwgdG8pO1xuXHR9XG5cdGZ1bmN0aW9uIGNoZWNrQ2FuY2VsZWROYXZpZ2F0aW9uKHRvLCBmcm9tKSB7XG5cdFx0aWYgKHBlbmRpbmdMb2NhdGlvbiAhPT0gdG8pIHJldHVybiBjcmVhdGVSb3V0ZXJFcnJvcig4LCB7XG5cdFx0XHRmcm9tLFxuXHRcdFx0dG9cblx0XHR9KTtcblx0fVxuXHRmdW5jdGlvbiBwdXNoKHRvKSB7XG5cdFx0cmV0dXJuIHB1c2hXaXRoUmVkaXJlY3QodG8pO1xuXHR9XG5cdGZ1bmN0aW9uIHJlcGxhY2UodG8pIHtcblx0XHRyZXR1cm4gcHVzaChhc3NpZ24obG9jYXRpb25Bc09iamVjdCh0byksIHsgcmVwbGFjZTogdHJ1ZSB9KSk7XG5cdH1cblx0ZnVuY3Rpb24gaGFuZGxlUmVkaXJlY3RSZWNvcmQodG8sIGZyb20pIHtcblx0XHRjb25zdCBsYXN0TWF0Y2hlZCA9IHRvLm1hdGNoZWRbdG8ubWF0Y2hlZC5sZW5ndGggLSAxXTtcblx0XHRpZiAobGFzdE1hdGNoZWQgJiYgbGFzdE1hdGNoZWQucmVkaXJlY3QpIHtcblx0XHRcdGNvbnN0IHsgcmVkaXJlY3QgfSA9IGxhc3RNYXRjaGVkO1xuXHRcdFx0bGV0IG5ld1RhcmdldExvY2F0aW9uID0gdHlwZW9mIHJlZGlyZWN0ID09PSBcImZ1bmN0aW9uXCIgPyByZWRpcmVjdCh0bywgZnJvbSkgOiByZWRpcmVjdDtcblx0XHRcdGlmICh0eXBlb2YgbmV3VGFyZ2V0TG9jYXRpb24gPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdFx0bmV3VGFyZ2V0TG9jYXRpb24gPSBuZXdUYXJnZXRMb2NhdGlvbi5pbmNsdWRlcyhcIj9cIikgfHwgbmV3VGFyZ2V0TG9jYXRpb24uaW5jbHVkZXMoXCIjXCIpID8gbmV3VGFyZ2V0TG9jYXRpb24gPSBsb2NhdGlvbkFzT2JqZWN0KG5ld1RhcmdldExvY2F0aW9uKSA6IHsgcGF0aDogbmV3VGFyZ2V0TG9jYXRpb24gfTtcblx0XHRcdFx0bmV3VGFyZ2V0TG9jYXRpb24ucGFyYW1zID0ge307XG5cdFx0XHR9XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIG5ld1RhcmdldExvY2F0aW9uLnBhdGggPT0gbnVsbCAmJiAhKFwibmFtZVwiIGluIG5ld1RhcmdldExvY2F0aW9uKSkge1xuXHRcdFx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDA4KHtcblx0XHRcdFx0XHR0YXJnZXQ6IEpTT04uc3RyaW5naWZ5KG5ld1RhcmdldExvY2F0aW9uLCBudWxsLCAyKSxcblx0XHRcdFx0XHR0bzogdG8uZnVsbFBhdGhcblx0XHRcdFx0fSk7XG5cdFx0XHRcdHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgcmVkaXJlY3RcIik7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gYXNzaWduKHtcblx0XHRcdFx0cXVlcnk6IHRvLnF1ZXJ5LFxuXHRcdFx0XHRoYXNoOiB0by5oYXNoLFxuXHRcdFx0XHRwYXJhbXM6IG5ld1RhcmdldExvY2F0aW9uLnBhdGggIT0gbnVsbCA/IHt9IDogdG8ucGFyYW1zXG5cdFx0XHR9LCBuZXdUYXJnZXRMb2NhdGlvbik7XG5cdFx0fVxuXHR9XG5cdGZ1bmN0aW9uIHB1c2hXaXRoUmVkaXJlY3QodG8sIHJlZGlyZWN0ZWRGcm9tKSB7XG5cdFx0Y29uc3QgdGFyZ2V0TG9jYXRpb24gPSBwZW5kaW5nTG9jYXRpb24gPSByZXNvbHZlKHRvKTtcblx0XHRjb25zdCBmcm9tID0gY3VycmVudFJvdXRlLnZhbHVlO1xuXHRcdGNvbnN0IGRhdGEgPSB0by5zdGF0ZTtcblx0XHRjb25zdCBmb3JjZSA9IHRvLmZvcmNlO1xuXHRcdGNvbnN0IHJlcGxhY2UgPSB0by5yZXBsYWNlID09PSB0cnVlO1xuXHRcdGNvbnN0IHNob3VsZFJlZGlyZWN0ID0gaGFuZGxlUmVkaXJlY3RSZWNvcmQodGFyZ2V0TG9jYXRpb24sIGZyb20pO1xuXHRcdGlmIChzaG91bGRSZWRpcmVjdCkgcmV0dXJuIHB1c2hXaXRoUmVkaXJlY3QoYXNzaWduKGxvY2F0aW9uQXNPYmplY3Qoc2hvdWxkUmVkaXJlY3QpLCB7XG5cdFx0XHRzdGF0ZTogdHlwZW9mIHNob3VsZFJlZGlyZWN0ID09PSBcIm9iamVjdFwiID8gYXNzaWduKHt9LCBkYXRhLCBzaG91bGRSZWRpcmVjdC5zdGF0ZSkgOiBkYXRhLFxuXHRcdFx0Zm9yY2UsXG5cdFx0XHRyZXBsYWNlXG5cdFx0fSksIHJlZGlyZWN0ZWRGcm9tIHx8IHRhcmdldExvY2F0aW9uKTtcblx0XHRjb25zdCB0b0xvY2F0aW9uID0gdGFyZ2V0TG9jYXRpb247XG5cdFx0dG9Mb2NhdGlvbi5yZWRpcmVjdGVkRnJvbSA9IHJlZGlyZWN0ZWRGcm9tO1xuXHRcdGxldCBmYWlsdXJlO1xuXHRcdGlmICghZm9yY2UgJiYgaXNTYW1lUm91dGVMb2NhdGlvbihzdHJpbmdpZnlRdWVyeSQxLCBmcm9tLCB0YXJnZXRMb2NhdGlvbikpIHtcblx0XHRcdGZhaWx1cmUgPSBjcmVhdGVSb3V0ZXJFcnJvcigxNiwge1xuXHRcdFx0XHR0bzogdG9Mb2NhdGlvbixcblx0XHRcdFx0ZnJvbVxuXHRcdFx0fSk7XG5cdFx0XHRoYW5kbGVTY3JvbGwoZnJvbSwgZnJvbSwgdHJ1ZSwgZmFsc2UpO1xuXHRcdH1cblx0XHRyZXR1cm4gKGZhaWx1cmUgPyBQcm9taXNlLnJlc29sdmUoZmFpbHVyZSkgOiBuYXZpZ2F0ZSh0b0xvY2F0aW9uLCBmcm9tKSkuY2F0Y2goKGVycm9yKSA9PiBpc05hdmlnYXRpb25GYWlsdXJlKGVycm9yKSA/IGlzTmF2aWdhdGlvbkZhaWx1cmUoZXJyb3IsIDIpID8gZXJyb3IgOiBtYXJrQXNSZWFkeShlcnJvcikgOiB0cmlnZ2VyRXJyb3IoZXJyb3IsIHRvTG9jYXRpb24sIGZyb20pKS50aGVuKChmYWlsdXJlKSA9PiB7XG5cdFx0XHRpZiAoZmFpbHVyZSkge1xuXHRcdFx0XHRpZiAoaXNOYXZpZ2F0aW9uRmFpbHVyZShmYWlsdXJlLCAyKSkge1xuXHRcdFx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgaXNTYW1lUm91dGVMb2NhdGlvbihzdHJpbmdpZnlRdWVyeSQxLCByZXNvbHZlKGZhaWx1cmUudG8pLCB0b0xvY2F0aW9uKSAmJiByZWRpcmVjdGVkRnJvbSAmJiAocmVkaXJlY3RlZEZyb20uX2NvdW50ID0gcmVkaXJlY3RlZEZyb20uX2NvdW50ID8gcmVkaXJlY3RlZEZyb20uX2NvdW50ICsgMSA6IDEpID4gMzApIHtcblx0XHRcdFx0XHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMDkoe1xuXHRcdFx0XHRcdFx0XHRmcm9tOiBmcm9tLmZ1bGxQYXRoLFxuXHRcdFx0XHRcdFx0XHR0bzogdG9Mb2NhdGlvbi5mdWxsUGF0aFxuXHRcdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0XHRyZXR1cm4gUHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihcIkluZmluaXRlIHJlZGlyZWN0IGluIG5hdmlnYXRpb24gZ3VhcmRcIikpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRyZXR1cm4gcHVzaFdpdGhSZWRpcmVjdChhc3NpZ24oeyByZXBsYWNlIH0sIGxvY2F0aW9uQXNPYmplY3QoZmFpbHVyZS50byksIHtcblx0XHRcdFx0XHRcdHN0YXRlOiB0eXBlb2YgZmFpbHVyZS50byA9PT0gXCJvYmplY3RcIiA/IGFzc2lnbih7fSwgZGF0YSwgZmFpbHVyZS50by5zdGF0ZSkgOiBkYXRhLFxuXHRcdFx0XHRcdFx0Zm9yY2Vcblx0XHRcdFx0XHR9KSwgcmVkaXJlY3RlZEZyb20gfHwgdG9Mb2NhdGlvbik7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBmYWlsdXJlID0gZmluYWxpemVOYXZpZ2F0aW9uKHRvTG9jYXRpb24sIGZyb20sIHRydWUsIHJlcGxhY2UsIGRhdGEpO1xuXHRcdFx0dHJpZ2dlckFmdGVyRWFjaCh0b0xvY2F0aW9uLCBmcm9tLCBmYWlsdXJlKTtcblx0XHRcdHJldHVybiBmYWlsdXJlO1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIEhlbHBlciB0byByZWplY3QgYW5kIHNraXAgYWxsIG5hdmlnYXRpb24gZ3VhcmRzIGlmIGEgbmV3IG5hdmlnYXRpb24gaGFwcGVuZWRcblx0KiBAcGFyYW0gdG9cblx0KiBAcGFyYW0gZnJvbVxuXHQqL1xuXHRmdW5jdGlvbiBjaGVja0NhbmNlbGVkTmF2aWdhdGlvbkFuZFJlamVjdCh0bywgZnJvbSkge1xuXHRcdGNvbnN0IGVycm9yID0gY2hlY2tDYW5jZWxlZE5hdmlnYXRpb24odG8sIGZyb20pO1xuXHRcdHJldHVybiBlcnJvciA/IFByb21pc2UucmVqZWN0KGVycm9yKSA6IFByb21pc2UucmVzb2x2ZSgpO1xuXHR9XG5cdGZ1bmN0aW9uIHJ1bldpdGhDb250ZXh0KGZuKSB7XG5cdFx0Y29uc3QgYXBwID0gaW5zdGFsbGVkQXBwcy52YWx1ZXMoKS5uZXh0KCkudmFsdWU7XG5cdFx0cmV0dXJuIGFwcCAmJiB0eXBlb2YgYXBwLnJ1bldpdGhDb250ZXh0ID09PSBcImZ1bmN0aW9uXCIgPyBhcHAucnVuV2l0aENvbnRleHQoZm4pIDogZm4oKTtcblx0fVxuXHRmdW5jdGlvbiBuYXZpZ2F0ZSh0bywgZnJvbSkge1xuXHRcdGxldCBndWFyZHM7XG5cdFx0Y29uc3QgW2xlYXZpbmdSZWNvcmRzLCB1cGRhdGluZ1JlY29yZHMsIGVudGVyaW5nUmVjb3Jkc10gPSBleHRyYWN0Q2hhbmdpbmdSZWNvcmRzKHRvLCBmcm9tKTtcblx0XHRndWFyZHMgPSBleHRyYWN0Q29tcG9uZW50c0d1YXJkcyhsZWF2aW5nUmVjb3Jkcy5yZXZlcnNlKCksIFwiYmVmb3JlUm91dGVMZWF2ZVwiLCB0bywgZnJvbSk7XG5cdFx0Zm9yIChjb25zdCByZWNvcmQgb2YgbGVhdmluZ1JlY29yZHMpIHJlY29yZC5sZWF2ZUd1YXJkcy5mb3JFYWNoKChndWFyZCkgPT4ge1xuXHRcdFx0Z3VhcmRzLnB1c2goZ3VhcmRUb1Byb21pc2VGbihndWFyZCwgdG8sIGZyb20pKTtcblx0XHR9KTtcblx0XHRjb25zdCBjYW5jZWxlZE5hdmlnYXRpb25DaGVjayA9IGNoZWNrQ2FuY2VsZWROYXZpZ2F0aW9uQW5kUmVqZWN0LmJpbmQobnVsbCwgdG8sIGZyb20pO1xuXHRcdGd1YXJkcy5wdXNoKGNhbmNlbGVkTmF2aWdhdGlvbkNoZWNrKTtcblx0XHRyZXR1cm4gcnVuR3VhcmRRdWV1ZShndWFyZHMpLnRoZW4oKCkgPT4ge1xuXHRcdFx0Z3VhcmRzID0gW107XG5cdFx0XHRmb3IgKGNvbnN0IGd1YXJkIG9mIGJlZm9yZUd1YXJkcy5saXN0KCkpIGd1YXJkcy5wdXNoKGd1YXJkVG9Qcm9taXNlRm4oZ3VhcmQsIHRvLCBmcm9tKSk7XG5cdFx0XHRndWFyZHMucHVzaChjYW5jZWxlZE5hdmlnYXRpb25DaGVjayk7XG5cdFx0XHRyZXR1cm4gcnVuR3VhcmRRdWV1ZShndWFyZHMpO1xuXHRcdH0pLnRoZW4oKCkgPT4ge1xuXHRcdFx0Z3VhcmRzID0gZXh0cmFjdENvbXBvbmVudHNHdWFyZHModXBkYXRpbmdSZWNvcmRzLCBcImJlZm9yZVJvdXRlVXBkYXRlXCIsIHRvLCBmcm9tKTtcblx0XHRcdGZvciAoY29uc3QgcmVjb3JkIG9mIHVwZGF0aW5nUmVjb3JkcykgcmVjb3JkLnVwZGF0ZUd1YXJkcy5mb3JFYWNoKChndWFyZCkgPT4ge1xuXHRcdFx0XHRndWFyZHMucHVzaChndWFyZFRvUHJvbWlzZUZuKGd1YXJkLCB0bywgZnJvbSkpO1xuXHRcdFx0fSk7XG5cdFx0XHRndWFyZHMucHVzaChjYW5jZWxlZE5hdmlnYXRpb25DaGVjayk7XG5cdFx0XHRyZXR1cm4gcnVuR3VhcmRRdWV1ZShndWFyZHMpO1xuXHRcdH0pLnRoZW4oKCkgPT4ge1xuXHRcdFx0Z3VhcmRzID0gW107XG5cdFx0XHRmb3IgKGNvbnN0IHJlY29yZCBvZiBlbnRlcmluZ1JlY29yZHMpIGlmIChyZWNvcmQuYmVmb3JlRW50ZXIpIGlmIChpc0FycmF5KHJlY29yZC5iZWZvcmVFbnRlcikpIGZvciAoY29uc3QgYmVmb3JlRW50ZXIgb2YgcmVjb3JkLmJlZm9yZUVudGVyKSBndWFyZHMucHVzaChndWFyZFRvUHJvbWlzZUZuKGJlZm9yZUVudGVyLCB0bywgZnJvbSkpO1xuXHRcdFx0ZWxzZSBndWFyZHMucHVzaChndWFyZFRvUHJvbWlzZUZuKHJlY29yZC5iZWZvcmVFbnRlciwgdG8sIGZyb20pKTtcblx0XHRcdGd1YXJkcy5wdXNoKGNhbmNlbGVkTmF2aWdhdGlvbkNoZWNrKTtcblx0XHRcdHJldHVybiBydW5HdWFyZFF1ZXVlKGd1YXJkcyk7XG5cdFx0fSkudGhlbigoKSA9PiB7XG5cdFx0XHR0by5tYXRjaGVkLmZvckVhY2goKHJlY29yZCkgPT4gcmVjb3JkLmVudGVyQ2FsbGJhY2tzID0ge30pO1xuXHRcdFx0Z3VhcmRzID0gZXh0cmFjdENvbXBvbmVudHNHdWFyZHMoZW50ZXJpbmdSZWNvcmRzLCBcImJlZm9yZVJvdXRlRW50ZXJcIiwgdG8sIGZyb20sIHJ1bldpdGhDb250ZXh0KTtcblx0XHRcdGd1YXJkcy5wdXNoKGNhbmNlbGVkTmF2aWdhdGlvbkNoZWNrKTtcblx0XHRcdHJldHVybiBydW5HdWFyZFF1ZXVlKGd1YXJkcyk7XG5cdFx0fSkudGhlbigoKSA9PiB7XG5cdFx0XHRndWFyZHMgPSBbXTtcblx0XHRcdGZvciAoY29uc3QgZ3VhcmQgb2YgYmVmb3JlUmVzb2x2ZUd1YXJkcy5saXN0KCkpIGd1YXJkcy5wdXNoKGd1YXJkVG9Qcm9taXNlRm4oZ3VhcmQsIHRvLCBmcm9tKSk7XG5cdFx0XHRndWFyZHMucHVzaChjYW5jZWxlZE5hdmlnYXRpb25DaGVjayk7XG5cdFx0XHRyZXR1cm4gcnVuR3VhcmRRdWV1ZShndWFyZHMpO1xuXHRcdH0pLmNhdGNoKChlcnIpID0+IGlzTmF2aWdhdGlvbkZhaWx1cmUoZXJyLCA4KSA/IGVyciA6IFByb21pc2UucmVqZWN0KGVycikpO1xuXHR9XG5cdGZ1bmN0aW9uIHRyaWdnZXJBZnRlckVhY2godG8sIGZyb20sIGZhaWx1cmUpIHtcblx0XHRhZnRlckd1YXJkcy5saXN0KCkuZm9yRWFjaCgoZ3VhcmQpID0+IHJ1bldpdGhDb250ZXh0KCgpID0+IGd1YXJkKHRvLCBmcm9tLCBmYWlsdXJlKSkpO1xuXHR9XG5cdC8qKlxuXHQqIC0gQ2xlYW5zIHVwIGFueSBuYXZpZ2F0aW9uIGd1YXJkc1xuXHQqIC0gQ2hhbmdlcyB0aGUgdXJsIGlmIG5lY2Vzc2FyeVxuXHQqIC0gQ2FsbHMgdGhlIHNjcm9sbEJlaGF2aW9yXG5cdCovXG5cdGZ1bmN0aW9uIGZpbmFsaXplTmF2aWdhdGlvbih0b0xvY2F0aW9uLCBmcm9tLCBpc1B1c2gsIHJlcGxhY2UsIGRhdGEpIHtcblx0XHRjb25zdCBlcnJvciA9IGNoZWNrQ2FuY2VsZWROYXZpZ2F0aW9uKHRvTG9jYXRpb24sIGZyb20pO1xuXHRcdGlmIChlcnJvcikgcmV0dXJuIGVycm9yO1xuXHRcdGNvbnN0IGlzRmlyc3ROYXZpZ2F0aW9uID0gZnJvbSA9PT0gU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRDtcblx0XHRjb25zdCBzdGF0ZSA9ICFpc0Jyb3dzZXIgPyB7fSA6IGhpc3Rvcnkuc3RhdGU7XG5cdFx0aWYgKGlzUHVzaCkgaWYgKHJlcGxhY2UgfHwgaXNGaXJzdE5hdmlnYXRpb24pIHJvdXRlckhpc3RvcnkucmVwbGFjZSh0b0xvY2F0aW9uLmZ1bGxQYXRoLCBhc3NpZ24oeyBzY3JvbGw6IGlzRmlyc3ROYXZpZ2F0aW9uICYmIHN0YXRlICYmIHN0YXRlLnNjcm9sbCB9LCBkYXRhKSk7XG5cdFx0ZWxzZSByb3V0ZXJIaXN0b3J5LnB1c2godG9Mb2NhdGlvbi5mdWxsUGF0aCwgZGF0YSk7XG5cdFx0Y3VycmVudFJvdXRlLnZhbHVlID0gdG9Mb2NhdGlvbjtcblx0XHRoYW5kbGVTY3JvbGwodG9Mb2NhdGlvbiwgZnJvbSwgaXNQdXNoLCBpc0ZpcnN0TmF2aWdhdGlvbik7XG5cdFx0bWFya0FzUmVhZHkoKTtcblx0fVxuXHRsZXQgcmVtb3ZlSGlzdG9yeUxpc3RlbmVyO1xuXHRmdW5jdGlvbiBzZXR1cExpc3RlbmVycygpIHtcblx0XHRpZiAocmVtb3ZlSGlzdG9yeUxpc3RlbmVyKSByZXR1cm47XG5cdFx0cmVtb3ZlSGlzdG9yeUxpc3RlbmVyID0gcm91dGVySGlzdG9yeS5saXN0ZW4oKHRvLCBfZnJvbSwgaW5mbykgPT4ge1xuXHRcdFx0aWYgKCFyb3V0ZXIubGlzdGVuaW5nKSByZXR1cm47XG5cdFx0XHRjb25zdCB0b0xvY2F0aW9uID0gcmVzb2x2ZSh0byk7XG5cdFx0XHRjb25zdCBzaG91bGRSZWRpcmVjdCA9IGhhbmRsZVJlZGlyZWN0UmVjb3JkKHRvTG9jYXRpb24sIHJvdXRlci5jdXJyZW50Um91dGUudmFsdWUpO1xuXHRcdFx0aWYgKHNob3VsZFJlZGlyZWN0KSB7XG5cdFx0XHRcdHB1c2hXaXRoUmVkaXJlY3QoYXNzaWduKHNob3VsZFJlZGlyZWN0LCB7XG5cdFx0XHRcdFx0cmVwbGFjZTogdHJ1ZSxcblx0XHRcdFx0XHRmb3JjZTogdHJ1ZVxuXHRcdFx0XHR9KSwgdG9Mb2NhdGlvbikuY2F0Y2gobm9vcCk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdHBlbmRpbmdMb2NhdGlvbiA9IHRvTG9jYXRpb247XG5cdFx0XHRjb25zdCBmcm9tID0gY3VycmVudFJvdXRlLnZhbHVlO1xuXHRcdFx0aWYgKGlzQnJvd3Nlcikgc2F2ZVNjcm9sbFBvc2l0aW9uKGdldFNjcm9sbEtleShmcm9tLmZ1bGxQYXRoLCBpbmZvLmRlbHRhKSwgY29tcHV0ZVNjcm9sbFBvc2l0aW9uKCkpO1xuXHRcdFx0bmF2aWdhdGUodG9Mb2NhdGlvbiwgZnJvbSkuY2F0Y2goKGVycm9yKSA9PiB7XG5cdFx0XHRcdGlmIChpc05hdmlnYXRpb25GYWlsdXJlKGVycm9yLCAxMikpIHJldHVybiBlcnJvcjtcblx0XHRcdFx0aWYgKGlzTmF2aWdhdGlvbkZhaWx1cmUoZXJyb3IsIDIpKSB7XG5cdFx0XHRcdFx0cHVzaFdpdGhSZWRpcmVjdChhc3NpZ24obG9jYXRpb25Bc09iamVjdChlcnJvci50byksIHsgZm9yY2U6IHRydWUgfSksIHRvTG9jYXRpb24pLnRoZW4oKGZhaWx1cmUpID0+IHtcblx0XHRcdFx0XHRcdGlmIChpc05hdmlnYXRpb25GYWlsdXJlKGZhaWx1cmUsIDIwKSAmJiAhaW5mby5kZWx0YSAmJiBpbmZvLnR5cGUgPT09IFwicG9wXCIpIHJvdXRlckhpc3RvcnkuZ28oLTEsIGZhbHNlKTtcblx0XHRcdFx0XHR9KS5jYXRjaChub29wKTtcblx0XHRcdFx0XHRyZXR1cm4gUHJvbWlzZS5yZWplY3QoKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoaW5mby5kZWx0YSkgcm91dGVySGlzdG9yeS5nbygtaW5mby5kZWx0YSwgZmFsc2UpO1xuXHRcdFx0XHRyZXR1cm4gdHJpZ2dlckVycm9yKGVycm9yLCB0b0xvY2F0aW9uLCBmcm9tKTtcblx0XHRcdH0pLnRoZW4oKGZhaWx1cmUpID0+IHtcblx0XHRcdFx0ZmFpbHVyZSA9IGZhaWx1cmUgfHwgZmluYWxpemVOYXZpZ2F0aW9uKHRvTG9jYXRpb24sIGZyb20sIGZhbHNlKTtcblx0XHRcdFx0aWYgKGZhaWx1cmUpIHtcblx0XHRcdFx0XHRpZiAoaW5mby5kZWx0YSAmJiAhaXNOYXZpZ2F0aW9uRmFpbHVyZShmYWlsdXJlLCA4KSkgcm91dGVySGlzdG9yeS5nbygtaW5mby5kZWx0YSwgZmFsc2UpO1xuXHRcdFx0XHRcdGVsc2UgaWYgKGluZm8udHlwZSA9PT0gXCJwb3BcIiAmJiBpc05hdmlnYXRpb25GYWlsdXJlKGZhaWx1cmUsIDIwKSkgcm91dGVySGlzdG9yeS5nbygtMSwgZmFsc2UpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHRyaWdnZXJBZnRlckVhY2godG9Mb2NhdGlvbiwgZnJvbSwgZmFpbHVyZSk7XG5cdFx0XHR9KS5jYXRjaChub29wKTtcblx0XHR9KTtcblx0fVxuXHRsZXQgcmVhZHlIYW5kbGVycyA9IHVzZUNhbGxiYWNrcygpO1xuXHRsZXQgZXJyb3JMaXN0ZW5lcnMgPSB1c2VDYWxsYmFja3MoKTtcblx0bGV0IHJlYWR5O1xuXHQvKipcblx0KiBUcmlnZ2VyIGVycm9yTGlzdGVuZXJzIGFkZGVkIHZpYSBvbkVycm9yIGFuZCB0aHJvd3MgdGhlIGVycm9yIGFzIHdlbGxcblx0KlxuXHQqIEBwYXJhbSBlcnJvciAtIGVycm9yIHRvIHRocm93XG5cdCogQHBhcmFtIHRvIC0gbG9jYXRpb24gd2Ugd2VyZSBuYXZpZ2F0aW5nIHRvIHdoZW4gdGhlIGVycm9yIGhhcHBlbmVkXG5cdCogQHBhcmFtIGZyb20gLSBsb2NhdGlvbiB3ZSB3ZXJlIG5hdmlnYXRpbmcgZnJvbSB3aGVuIHRoZSBlcnJvciBoYXBwZW5lZFxuXHQqIEByZXR1cm5zIHRoZSBlcnJvciBhcyBhIHJlamVjdGVkIHByb21pc2Vcblx0Ki9cblx0ZnVuY3Rpb24gdHJpZ2dlckVycm9yKGVycm9yLCB0bywgZnJvbSkge1xuXHRcdG1hcmtBc1JlYWR5KGVycm9yKTtcblx0XHRjb25zdCBsaXN0ID0gZXJyb3JMaXN0ZW5lcnMubGlzdCgpO1xuXHRcdGlmIChsaXN0Lmxlbmd0aCkgbGlzdC5mb3JFYWNoKChoYW5kbGVyKSA9PiBoYW5kbGVyKGVycm9yLCB0bywgZnJvbSkpO1xuXHRcdGVsc2Uge1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDAxMCgpO1xuXHRcdFx0Y29uc29sZS5lcnJvcihlcnJvcik7XG5cdFx0fVxuXHRcdHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XG5cdH1cblx0ZnVuY3Rpb24gaXNSZWFkeSgpIHtcblx0XHRpZiAocmVhZHkgJiYgY3VycmVudFJvdXRlLnZhbHVlICE9PSBTVEFSVF9MT0NBVElPTl9OT1JNQUxJWkVEKSByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG5cdFx0cmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdHJlYWR5SGFuZGxlcnMuYWRkKFtyZXNvbHZlLCByZWplY3RdKTtcblx0XHR9KTtcblx0fVxuXHRmdW5jdGlvbiBtYXJrQXNSZWFkeShlcnIpIHtcblx0XHRpZiAoIXJlYWR5KSB7XG5cdFx0XHRyZWFkeSA9ICFlcnI7XG5cdFx0XHRzZXR1cExpc3RlbmVycygpO1xuXHRcdFx0cmVhZHlIYW5kbGVycy5saXN0KCkuZm9yRWFjaCgoW3Jlc29sdmUsIHJlamVjdF0pID0+IGVyciA/IHJlamVjdChlcnIpIDogcmVzb2x2ZSgpKTtcblx0XHRcdHJlYWR5SGFuZGxlcnMucmVzZXQoKTtcblx0XHR9XG5cdFx0cmV0dXJuIGVycjtcblx0fVxuXHRmdW5jdGlvbiBoYW5kbGVTY3JvbGwodG8sIGZyb20sIGlzUHVzaCwgaXNGaXJzdE5hdmlnYXRpb24pIHtcblx0XHRjb25zdCB7IHNjcm9sbEJlaGF2aW9yIH0gPSBvcHRpb25zO1xuXHRcdGlmICghaXNCcm93c2VyIHx8ICFzY3JvbGxCZWhhdmlvcikgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuXHRcdGNvbnN0IHNjcm9sbFBvc2l0aW9uID0gIWlzUHVzaCAmJiBnZXRTYXZlZFNjcm9sbFBvc2l0aW9uKGdldFNjcm9sbEtleSh0by5mdWxsUGF0aCwgMCkpIHx8IChpc0ZpcnN0TmF2aWdhdGlvbiB8fCAhaXNQdXNoKSAmJiBoaXN0b3J5LnN0YXRlICYmIGhpc3Rvcnkuc3RhdGUuc2Nyb2xsIHx8IG51bGw7XG5cdFx0cmV0dXJuIG5leHRUaWNrKCkudGhlbigoKSA9PiBzY3JvbGxCZWhhdmlvcih0bywgZnJvbSwgc2Nyb2xsUG9zaXRpb24pKS50aGVuKChwb3NpdGlvbikgPT4gdG8gPT09IGN1cnJlbnRSb3V0ZS52YWx1ZSAmJiBwb3NpdGlvbiAmJiBzY3JvbGxUb1Bvc2l0aW9uKHBvc2l0aW9uKSkuY2F0Y2goKGVycikgPT4gdG8gPT09IGN1cnJlbnRSb3V0ZS52YWx1ZSAmJiB0cmlnZ2VyRXJyb3IoZXJyLCB0bywgZnJvbSkpO1xuXHR9XG5cdGNvbnN0IGdvID0gKGRlbHRhKSA9PiByb3V0ZXJIaXN0b3J5LmdvKGRlbHRhKTtcblx0bGV0IHN0YXJ0ZWQ7XG5cdGNvbnN0IGluc3RhbGxlZEFwcHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRjb25zdCByb3V0ZXIgPSB7XG5cdFx0Y3VycmVudFJvdXRlLFxuXHRcdGxpc3RlbmluZzogdHJ1ZSxcblx0XHRhZGRSb3V0ZSxcblx0XHRyZW1vdmVSb3V0ZSxcblx0XHRjbGVhclJvdXRlczogbWF0Y2hlci5jbGVhclJvdXRlcyxcblx0XHRoYXNSb3V0ZSxcblx0XHRnZXRSb3V0ZXMsXG5cdFx0cmVzb2x2ZSxcblx0XHRvcHRpb25zLFxuXHRcdHB1c2gsXG5cdFx0cmVwbGFjZSxcblx0XHRnbyxcblx0XHRiYWNrOiAoKSA9PiBnbygtMSksXG5cdFx0Zm9yd2FyZDogKCkgPT4gZ28oMSksXG5cdFx0YmVmb3JlRWFjaDogYmVmb3JlR3VhcmRzLmFkZCxcblx0XHRiZWZvcmVSZXNvbHZlOiBiZWZvcmVSZXNvbHZlR3VhcmRzLmFkZCxcblx0XHRhZnRlckVhY2g6IGFmdGVyR3VhcmRzLmFkZCxcblx0XHRvbkVycm9yOiBlcnJvckxpc3RlbmVycy5hZGQsXG5cdFx0aXNSZWFkeSxcblx0XHRpbnN0YWxsKGFwcCkge1xuXHRcdFx0YXBwLmNvbXBvbmVudChcIlJvdXRlckxpbmtcIiwgUm91dGVyTGluayk7XG5cdFx0XHRhcHAuY29tcG9uZW50KFwiUm91dGVyVmlld1wiLCBSb3V0ZXJWaWV3KTtcblx0XHRcdGFwcC5jb25maWcuZ2xvYmFsUHJvcGVydGllcy4kcm91dGVyID0gcm91dGVyO1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGFwcC5jb25maWcuZ2xvYmFsUHJvcGVydGllcywgXCIkcm91dGVcIiwge1xuXHRcdFx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuXHRcdFx0XHRnZXQ6ICgpID0+IHVucmVmKGN1cnJlbnRSb3V0ZSlcblx0XHRcdH0pO1xuXHRcdFx0aWYgKGlzQnJvd3NlciAmJiAhc3RhcnRlZCAmJiBjdXJyZW50Um91dGUudmFsdWUgPT09IFNUQVJUX0xPQ0FUSU9OX05PUk1BTElaRUQpIHtcblx0XHRcdFx0c3RhcnRlZCA9IHRydWU7XG5cdFx0XHRcdHB1c2gocm91dGVySGlzdG9yeS5sb2NhdGlvbikuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMTEoeyBjYXVzZTogZXJyIH0pO1xuXHRcdFx0XHR9KTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IHJlYWN0aXZlUm91dGUgPSB7fTtcblx0XHRcdGZvciAoY29uc3Qga2V5IGluIFNUQVJUX0xPQ0FUSU9OX05PUk1BTElaRUQpIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShyZWFjdGl2ZVJvdXRlLCBrZXksIHtcblx0XHRcdFx0Z2V0OiAoKSA9PiBjdXJyZW50Um91dGUudmFsdWVba2V5XSxcblx0XHRcdFx0ZW51bWVyYWJsZTogdHJ1ZVxuXHRcdFx0fSk7XG5cdFx0XHRhcHAucHJvdmlkZShyb3V0ZXJLZXksIHJvdXRlcik7XG5cdFx0XHRhcHAucHJvdmlkZShyb3V0ZUxvY2F0aW9uS2V5LCBzaGFsbG93UmVhY3RpdmUocmVhY3RpdmVSb3V0ZSkpO1xuXHRcdFx0YXBwLnByb3ZpZGUocm91dGVyVmlld0xvY2F0aW9uS2V5LCBjdXJyZW50Um91dGUpO1xuXHRcdFx0Y29uc3QgdW5tb3VudEFwcCA9IGFwcC51bm1vdW50O1xuXHRcdFx0aW5zdGFsbGVkQXBwcy5hZGQoYXBwKTtcblx0XHRcdGFwcC51bm1vdW50ID0gZnVuY3Rpb24oKSB7XG5cdFx0XHRcdGluc3RhbGxlZEFwcHMuZGVsZXRlKGFwcCk7XG5cdFx0XHRcdGlmIChpbnN0YWxsZWRBcHBzLnNpemUgPCAxKSB7XG5cdFx0XHRcdFx0cGVuZGluZ0xvY2F0aW9uID0gU1RBUlRfTE9DQVRJT05fTk9STUFMSVpFRDtcblx0XHRcdFx0XHRyZW1vdmVIaXN0b3J5TGlzdGVuZXIgJiYgcmVtb3ZlSGlzdG9yeUxpc3RlbmVyKCk7XG5cdFx0XHRcdFx0cmVtb3ZlSGlzdG9yeUxpc3RlbmVyID0gbnVsbDtcblx0XHRcdFx0XHRjdXJyZW50Um91dGUudmFsdWUgPSBTVEFSVF9MT0NBVElPTl9OT1JNQUxJWkVEO1xuXHRcdFx0XHRcdHN0YXJ0ZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRyZWFkeSA9IGZhbHNlO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHVubW91bnRBcHAoKTtcblx0XHRcdH07XG5cdFx0XHRpZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pICYmIGlzQnJvd3NlciAmJiB0cnVlKSBhZGREZXZ0b29scyhhcHAsIHJvdXRlciwgbWF0Y2hlcik7XG5cdFx0fVxuXHR9O1xuXHRmdW5jdGlvbiBydW5HdWFyZFF1ZXVlKGd1YXJkcykge1xuXHRcdHJldHVybiBndWFyZHMucmVkdWNlKChwcm9taXNlLCBndWFyZCkgPT4gcHJvbWlzZS50aGVuKCgpID0+IHJ1bldpdGhDb250ZXh0KGd1YXJkKSksIFByb21pc2UucmVzb2x2ZSgpKTtcblx0fVxuXHRyZXR1cm4gcm91dGVyO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBOYXZpZ2F0aW9uRmFpbHVyZVR5cGUsIFJvdXRlckxpbmssIFJvdXRlclZpZXcsIFNUQVJUX0xPQ0FUSU9OX05PUk1BTElaRUQgYXMgU1RBUlRfTE9DQVRJT04sIGNyZWF0ZU1lbW9yeUhpc3RvcnksIGNyZWF0ZVJvdXRlciwgY3JlYXRlUm91dGVyTWF0Y2hlciwgY3JlYXRlV2ViSGFzaEhpc3RvcnksIGNyZWF0ZVdlYkhpc3RvcnksIGlzTmF2aWdhdGlvbkZhaWx1cmUsIGxvYWRSb3V0ZUxvY2F0aW9uLCBtYXRjaGVkUm91dGVLZXksIG9uQmVmb3JlUm91dGVMZWF2ZSwgb25CZWZvcmVSb3V0ZVVwZGF0ZSwgcGFyc2VRdWVyeSwgcm91dGVMb2NhdGlvbktleSwgcm91dGVyS2V5LCByb3V0ZXJWaWV3TG9jYXRpb25LZXksIHN0cmluZ2lmeVF1ZXJ5LCB1c2VMaW5rLCB1c2VSb3V0ZSwgdXNlUm91dGVyLCB2aWV3RGVwdGhLZXkgfTtcbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19