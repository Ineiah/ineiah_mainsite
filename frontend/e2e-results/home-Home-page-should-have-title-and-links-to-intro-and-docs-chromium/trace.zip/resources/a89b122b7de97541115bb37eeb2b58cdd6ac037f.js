/**
* Composable to generate slugs from string values, removing accents
* @param {...string[]} args - The string values to generate the slug from
*/
export function useSlug(...args) {
	return args.map((arg) => arg.toLowerCase().replace(/\s+/g, "-")).join("-").replace(/[\u0300-\u036f]/g, "");
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUlBLE9BQU8sU0FBUyxRQUFRLEdBQUcsTUFBd0I7Q0FDakQsT0FBTyxLQUFLLEtBQUksUUFBTyxJQUFJLFlBQVksQ0FBQyxDQUFDLFFBQVEsUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsUUFBUSxvQkFBb0IsRUFBRTtBQUN6RyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJ0ZXh0LnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQ29tcG9zYWJsZSB0byBnZW5lcmF0ZSBzbHVncyBmcm9tIHN0cmluZyB2YWx1ZXMsIHJlbW92aW5nIGFjY2VudHNcbiAqIEBwYXJhbSB7Li4uc3RyaW5nW119IGFyZ3MgLSBUaGUgc3RyaW5nIHZhbHVlcyB0byBnZW5lcmF0ZSB0aGUgc2x1ZyBmcm9tXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VTbHVnKC4uLmFyZ3M6IHN0cmluZ1tdKTogc3RyaW5nIHtcbiAgcmV0dXJuIGFyZ3MubWFwKGFyZyA9PiBhcmcudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9cXHMrL2csICctJykpLmpvaW4oJy0nKS5yZXBsYWNlKC9bXFx1MDMwMC1cXHUwMzZmXS9nLCBcIlwiKVxufVxuIl19