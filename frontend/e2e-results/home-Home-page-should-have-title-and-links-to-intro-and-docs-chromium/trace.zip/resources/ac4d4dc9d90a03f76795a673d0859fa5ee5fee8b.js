import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/components/cookie/Banner.client.vue");import { default as __nuxt_component_0 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/components/nuxt-link.js?v=7e73afc2";
import { default as __nuxt_component_1 } from "/_nuxt/components/volt/ContrastButton.vue";
import { useCookieComposable as _$__useCookieComposable } from "/_nuxt/composables/index.ts";
import { useConsent as _$__useConsent } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt-ganalytics@2.4.3_7e158c19982a345ee7382822a039f27d/node_modules/nuxt-ganalytics/dist/runtime/composables/index.js?v=7e73afc2";;import { __nuxtTimelineWrap } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+devtools@3.4.1_db0@0.3.4_better-sqlite3@13.0.2_drizzle-orm@0.45.2_@opentelemetry+_0e55243a794e05cb19a29a0506aae086/node_modules/@nuxt/devtools/dist/runtime/function-metrics-helpers.js?v=7e73afc2";const useCookieComposable = __nuxtTimelineWrap("useCookieComposable", _$__useCookieComposable);const useConsent = __nuxtTimelineWrap("useConsent", _$__useConsent);
import { recordPosition as _tracerRecordPosition } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vite-plugin-vue-tracer@1.4.0_vite@8.2.0_@types+node@26.1.2_esbuild@0.28.1_jiti@2.7.0_sa_bcac4fa99282966dd94ca7ad2dfebde1/node_modules/vite-plugin-vue-tracer/dist/client/record.mjs?v=7e73afc2"
import { defineComponent as _defineComponent } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _sfc_main = /*@__PURE__*/ _defineComponent({
	__name: "CookieBanner",
	setup(__props, { expose: __expose }) {
		__expose();
		/**
		* Cookie
		*/
		const { toggleShowOptions, showBanner, accept } = useCookieComposable();
		/**
		* Consent Google Analytics
		*/
		const { acceptAll } = useConsent();
		const __returned__ = {
			toggleShowOptions,
			showBanner,
			accept,
			acceptAll
		};
		Object.defineProperty(__returned__, "__isScriptSetup", {
			enumerable: false,
			value: true
		});
		return __returned__;
	}
});
import { createElementVNode as _createElementVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, toDisplayString as _toDisplayString, createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, createCommentVNode as _createCommentVNode, createStaticVNode as _createStaticVNode } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _hoisted_1 = {
	key: 0,
	class: "fixed top-7/12 left-5 [--shadow:rgba(60,64,67,0.3)_0_1px_2px_0,rgba(60,64,67,0.15)_0_2px_6px_2px] w-4/5 h-auto z-50 rounded-2xl bg-primary-100 dark:bg-primary-400 [box-shadow:var(--shadow)] max-w-75"
};
const _hoisted_2 = { class: "flex flex-col items-center justify-between pt-9 px-6 pb-6 relative" };
const _hoisted_3 = { class: "text-sm font-semibold mb-2 text-left mr-auto text-surface-700 dark:text-surface-50" };
const _hoisted_4 = { class: "w-full mb-4 text-sm text-justify text-surface-800 dark:text-surface-50" };
const _hoisted_5 = { class: "w-full mb-6 text-sm text-justify text-surface-800 dark:text-surface-50" };
const _hoisted_6 = { class: "grid grid-cols-2 w-full content-center" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
	const _component_nuxt_link = __nuxt_component_0;
	const _component_volt_contrast_button = __nuxt_component_1;
	return $setup.showBanner ? (_openBlock(), _tracer(2,2,_createElementBlock("div", _hoisted_1, [_tracer(3,4,_createElementVNode("div", _hoisted_2, [
		_cache[2] || (_cache[2] = _createStaticVNode("<span class=\"relative mx-auto -mt-16 mb-8\"><svg xmlns=\"http://www.w3.org/2000/svg\" fill=\"none\" height=\"46\" width=\"65\"><path stroke=\"#000\" fill=\"#EAB789\" d=\"M49.157 15.69L44.58.655l-12.422 1.96L21.044.654l-8.499 2.615-6.538 5.23-4.576 9.153v11.114l4.576 8.5 7.846 5.23 10.46 1.96 7.845-2.614 9.153 2.615 11.768-2.615 7.846-7.846 1.96-5.884.655-7.191-7.846-1.308-6.537-3.922z\"></path><path fill=\"#9C6750\" d=\"M32.286 3.749c-6.94 3.65-11.69 11.053-11.69 19.591 0 8.137 4.313 15.242 10.724 19.052a20.513 20.513 0 01-8.723 1.937c-11.598 0-21-9.626-21-21.5 0-11.875 9.402-21.5 21-21.5 3.495 0 6.79.874 9.689 2.42z\" clip-rule=\"evenodd\" fill-rule=\"evenodd\"></path><path fill=\"#634647\" d=\"M64.472 20.305a.954.954 0 00-1.172-.824 4.508 4.508 0 01-3.958-.934.953.953 0 00-1.076-.11c-.46.252-.977.383-1.502.382a3.154 3.154 0 01-2.97-2.11.954.954 0 00-.833-.634 4.54 4.54 0 01-4.205-4.507c.002-.23.022-.46.06-.687a.952.952 0 00-.213-.767 3.497 3.497 0 01-.614-3.5.953.953 0 00-.382-1.138 3.522 3.522 0 01-1.5-3.992.951.951 0 00-.762-1.227A22.611 22.611 0 0032.3 2.16 22.41 22.41 0 0022.657.001a22.654 22.654 0 109.648 43.15 22.644 22.644 0 0032.167-22.847zM22.657 43.4a20.746 20.746 0 110-41.493c2.566-.004 5.11.473 7.501 1.407a22.64 22.64 0 00.003 38.682 20.6 20.6 0 01-7.504 1.404zm19.286 0a20.746 20.746 0 112.131-41.384 5.417 5.417 0 001.918 4.635 5.346 5.346 0 00-.133 1.182A5.441 5.441 0 0046.879 11a5.804 5.804 0 00-.028.568 6.456 6.456 0 005.38 6.345 5.053 5.053 0 006.378 2.472 6.412 6.412 0 004.05 1.12 20.768 20.768 0 01-20.716 21.897z\"></path><path fill=\"#644647\" d=\"M54.962 34.3a17.719 17.719 0 01-2.602 2.378.954.954 0 001.14 1.53 19.637 19.637 0 002.884-2.634.955.955 0 00-1.422-1.274z\"></path><path stroke-width=\"1.8\" stroke=\"#644647\" fill=\"#845556\" d=\"M44.5 32.829c-.512 0-1.574.215-2 .5-.426.284-.342.263-.537.736a2.59 2.59 0 104.98.99c0-.686-.458-1.241-.943-1.726-.485-.486-.814-.5-1.5-.5zm-30.916-2.5c-.296 0-.912.134-1.159.311-.246.177-.197.164-.31.459a1.725 1.725 0 00-.086.932c.058.312.2.6.41.825.21.226.477.38.768.442.291.062.593.03.867-.092s.508-.329.673-.594a1.7 1.7 0 00.253-.896c0-.428-.266-.774-.547-1.076-.281-.302-.471-.31-.869-.311zm17.805-11.375c-.143-.492-.647-1.451-1.04-1.78-.392-.33-.348-.255-.857-.31a2.588 2.588 0 10.441 5.06c.66-.194 1.064-.788 1.395-1.39.33-.601.252-.92.06-1.58zm-22 2c-.143-.492-.647-1.451-1.04-1.78-.391-.33-.347-.255-.856-.31a2.589 2.589 0 10.44 5.06c.66-.194 1.064-.788 1.395-1.39.33-.601.252-.92.06-1.58zM38.112 7.329c-.395 0-1.216.179-1.545.415-.328.236-.263.218-.415.611-.151.393-.19.826-.114 1.243.078.417.268.8.548 1.1.28.301.636.506 1.024.59.388.082.79.04 1.155-.123.366-.163.678-.438.898-.792.22-.354.337-.77.337-1.195 0-.57-.354-1.031-.73-1.434-.374-.403-.628-.415-1.158-.415zm-19.123.703c.023-.296-.062-.92-.219-1.18-.157-.26-.148-.21-.432-.347a1.726 1.726 0 00-.922-.159 1.654 1.654 0 00-.856.344 1.471 1.471 0 00-.501.73c-.085.285-.077.589.023.872.1.282.287.532.538.718a1.7 1.7 0 00.873.323c.427.033.793-.204 1.116-.46.324-.256.347-.445.38-.841z\"></path><path fill=\"#634647\" d=\"M15.027 15.605a.954.954 0 00-1.553 1.108l1.332 1.863a.955.955 0 001.705-.77.955.955 0 00-.153-.34l-1.331-1.861z\"></path><path fill=\"#644647\" d=\"M43.31 23.21a.954.954 0 101.553-1.11l-1.266-1.772a.954.954 0 10-1.552 1.11l1.266 1.772z\"></path><path fill=\"#634647\" d=\"M19.672 35.374a.954.954 0 00-.954.953v2.363a.954.954 0 001.907 0v-2.362a.954.954 0 00-.953-.954z\"></path><path fill=\"#644647\" d=\"M33.129 29.18l-2.803 1.065a.953.953 0 00-.053 1.764.957.957 0 00.73.022l2.803-1.065a.953.953 0 00-.677-1.783v-.003zm24.373-3.628l-2.167.823a.956.956 0 00-.054 1.764.954.954 0 00.73.021l2.169-.823a.954.954 0 10-.678-1.784v-.001z\"></path></svg></span>", 1)),
		_tracer(18,6,_createElementVNode(
			"h5",
			_hoisted_3,
			_toDisplayString(_ctx.$t("Votre vie privée est importante pour nous")),
			1
			/* TEXT */
		)),
		_tracer(22,6,_createElementVNode(
			"p",
			_hoisted_4,
			_toDisplayString(_ctx.$t("Nous traitons vos informations personnelles afin de mesurer et d'améliorer nos sites et services, de soutenir nos campagnes et de vous proposer des contenus personnalisés.")),
			1
			/* TEXT */
		)),
		_tracer(26,6,_createElementVNode("p", _hoisted_5, [_createTextVNode(
			_toDisplayString(_ctx.$t("Pour plus d'informations, consultez notre Politique de confidentialité.")) + " ",
			1
			/* TEXT */
		), _tracer(27,92,_createVNode(_component_nuxt_link, {
			class: "text-surface-600 hover:text-surface-700 hover:underline underline-offset-2",
			href: "/legal/confidentialite"
		}, {
			default: _withCtx(() => [_createTextVNode(
				_toDisplayString(_ctx.$t("Politique de confidentialité")),
				1
				/* TEXT */
			)]),
			_: 1
		}))])),
		_tracer(32,6,_createElementVNode("div", _hoisted_6, [
			_tracer(33,8,_createElementVNode(
				"button",
				{
					class: "text-sm text-surface-600 cursor-pointer font-semibold transition-colors hover:text-surface-700 hover:underline underline-offset-2",
					onClick: _cache[0] || (_cache[0] = () => $setup.toggleShowOptions())
				},
				_toDisplayString(_ctx.$t("Plus d'options")),
				1
				/* TEXT */
			)),
			_createCommentVNode(" cursor-pointer py-2 px-8 w-max break-keep text-sm rounded-lg transition-colors text-[#634647] hover:text-[#ddad81] bg-[#ddad81] hover:bg-[#634647] "),
			_tracer(38,8,_createVNode(_component_volt_contrast_button, {
				class: "font-semibold",
				onClick: _cache[1] || (_cache[1] = () => $setup.accept($setup.acceptAll))
			}, {
				default: _withCtx(() => [_createTextVNode(
					_toDisplayString(_ctx.$t("Accepter tout")),
					1
					/* TEXT */
				)]),
				_: 1
			}))
		]))
	]))]))) : _createCommentVNode("v-if", true);
}
_sfc_main.__hmrId = "c39e63ac";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.on("file-changed", ({ file }) => {
	__VUE_HMR_RUNTIME__.CHANGED_FILE = file;
});
import.meta.hot.accept((mod) => {
	if (!mod) return;
	const { default: updated, _rerender_only } = mod;
	if (_rerender_only) {
		__VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
	} else {
		__VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
	}
});
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper";
export default /*#__PURE__*/ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "/Volumes/Coding/Projects/Websites/ineiah/frontend/app/components/cookie/Banner.client.vue"]]);

function _tracer(line, column, vnode) { return _tracerRecordPosition("app/components/cookie/Banner.client.vue", line, column, vnode) }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztFQWlEQSxNQUFNLEVBQUUsbUJBQW1CLFlBQVksV0FBVyxvQkFBb0I7Ozs7RUFLdEUsTUFBTSxFQUFFLGNBQWMsV0FBVzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FyRFIsT0FBTTs7QUFDdEIsNEJBQU0scUVBQW9FO0FBZXpFLDRCQUFNLHFGQUFvRjtBQUkzRiw0QkFBTSx5RUFBd0U7QUFJOUUsNEJBQU0seUVBQXdFO0FBTTVFLDRCQUFNLHlDQUF3Qzs7OztDQTlCNUMsNEJBQVgsOENBeUNNLE9BekNOLFlBeUNNLGFBeENKLG9CQXVDTSxPQXZDTixZQXVDTTs7ZUF4Qko7R0FFSztHQUZMO0dBRUssaUJBREEsUUFBRTtHQUFBOztFQUFBO2VBR1A7R0FFSTtHQUZKO0dBRUksaUJBREMsUUFBRTtHQUFBOztFQUFBO2VBR1Asb0JBSUksS0FKSixZQUlJLENBSEM7R0FBQSx5QkFBRSw4RUFBOEU7R0FBQzs7RUFBQSw4QkFFeEU7R0FGbUYsT0FBTTtHQUE2RSxNQUFLOztHQUNyTCx3QkFBd0MsQ0FBckM7SUFBQSx5QkFBRTtJQUFBOztHQUFBOzs7ZUFJVCxvQkFTTSxPQVROLFlBU007Z0JBUko7SUFFUztJQUFBO0tBRkQsT0FBTTtLQUFxSSxTQUFLLGdDQUFRLHlCQUFpQjtJQUM1SztJQUFBLHlCQUFFO0lBQUE7O0dBQUE7R0FHUDtnQkFDQSxhQUV1QjtJQUZELE9BQU07SUFBaUIsU0FBSyxnQ0FBUSxjQUFPLGdCQUFTOztJQUN4RSx3QkFBeUIsQ0FBdEI7S0FBQSx5QkFBRTtLQUFBOztJQUFBIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJCYW5uZXIuY2xpZW50LnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XG4gIDxkaXYgdi1pZj1cInNob3dCYW5uZXJcIiBjbGFzcz1cImZpeGVkIHRvcC03LzEyIGxlZnQtNSBbLS1zaGFkb3c6cmdiYSg2MCw2NCw2NywwLjMpXzBfMXB4XzJweF8wLHJnYmEoNjAsNjQsNjcsMC4xNSlfMF8ycHhfNnB4XzJweF0gdy00LzUgaC1hdXRvIHotNTAgcm91bmRlZC0yeGwgYmctcHJpbWFyeS0xMDAgZGFyazpiZy1wcmltYXJ5LTQwMCBbYm94LXNoYWRvdzp2YXIoLS1zaGFkb3cpXSBtYXgtdy03NVwiPlxuICAgIDxkaXYgY2xhc3M9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHQtOSBweC02IHBiLTYgcmVsYXRpdmVcIj5cbiAgICAgIDxzcGFuIGNsYXNzPVwicmVsYXRpdmUgbXgtYXV0byAtbXQtMTYgbWItOFwiPlxuICAgICAgICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiBmaWxsPVwibm9uZVwiIGhlaWdodD1cIjQ2XCIgd2lkdGg9XCI2NVwiPlxuICAgICAgICAgIDxwYXRoIHN0cm9rZT1cIiMwMDBcIiBmaWxsPVwiI0VBQjc4OVwiIGQ9XCJNNDkuMTU3IDE1LjY5TDQ0LjU4LjY1NWwtMTIuNDIyIDEuOTZMMjEuMDQ0LjY1NGwtOC40OTkgMi42MTUtNi41MzggNS4yMy00LjU3NiA5LjE1M3YxMS4xMTRsNC41NzYgOC41IDcuODQ2IDUuMjMgMTAuNDYgMS45NiA3Ljg0NS0yLjYxNCA5LjE1MyAyLjYxNSAxMS43NjgtMi42MTUgNy44NDYtNy44NDYgMS45Ni01Ljg4NC42NTUtNy4xOTEtNy44NDYtMS4zMDgtNi41MzctMy45MjJ6XCIgLz5cbiAgICAgICAgICA8cGF0aCBmaWxsPVwiIzlDNjc1MFwiIGQ9XCJNMzIuMjg2IDMuNzQ5Yy02Ljk0IDMuNjUtMTEuNjkgMTEuMDUzLTExLjY5IDE5LjU5MSAwIDguMTM3IDQuMzEzIDE1LjI0MiAxMC43MjQgMTkuMDUyYTIwLjUxMyAyMC41MTMgMCAwMS04LjcyMyAxLjkzN2MtMTEuNTk4IDAtMjEtOS42MjYtMjEtMjEuNSAwLTExLjg3NSA5LjQwMi0yMS41IDIxLTIxLjUgMy40OTUgMCA2Ljc5Ljg3NCA5LjY4OSAyLjQyelwiIGNsaXAtcnVsZT1cImV2ZW5vZGRcIiBmaWxsLXJ1bGU9XCJldmVub2RkXCIgLz5cbiAgICAgICAgICA8cGF0aCBmaWxsPVwiIzYzNDY0N1wiIGQ9XCJNNjQuNDcyIDIwLjMwNWEuOTU0Ljk1NCAwIDAwLTEuMTcyLS44MjQgNC41MDggNC41MDggMCAwMS0zLjk1OC0uOTM0Ljk1My45NTMgMCAwMC0xLjA3Ni0uMTFjLS40Ni4yNTItLjk3Ny4zODMtMS41MDIuMzgyYTMuMTU0IDMuMTU0IDAgMDEtMi45Ny0yLjExLjk1NC45NTQgMCAwMC0uODMzLS42MzQgNC41NCA0LjU0IDAgMDEtNC4yMDUtNC41MDdjLjAwMi0uMjMuMDIyLS40Ni4wNi0uNjg3YS45NTIuOTUyIDAgMDAtLjIxMy0uNzY3IDMuNDk3IDMuNDk3IDAgMDEtLjYxNC0zLjUuOTUzLjk1MyAwIDAwLS4zODItMS4xMzggMy41MjIgMy41MjIgMCAwMS0xLjUtMy45OTIuOTUxLjk1MSAwIDAwLS43NjItMS4yMjdBMjIuNjExIDIyLjYxMSAwIDAwMzIuMyAyLjE2IDIyLjQxIDIyLjQxIDAgMDAyMi42NTcuMDAxYTIyLjY1NCAyMi42NTQgMCAxMDkuNjQ4IDQzLjE1IDIyLjY0NCAyMi42NDQgMCAwMDMyLjE2Ny0yMi44NDd6TTIyLjY1NyA0My40YTIwLjc0NiAyMC43NDYgMCAxMTAtNDEuNDkzYzIuNTY2LS4wMDQgNS4xMS40NzMgNy41MDEgMS40MDdhMjIuNjQgMjIuNjQgMCAwMC4wMDMgMzguNjgyIDIwLjYgMjAuNiAwIDAxLTcuNTA0IDEuNDA0em0xOS4yODYgMGEyMC43NDYgMjAuNzQ2IDAgMTEyLjEzMS00MS4zODQgNS40MTcgNS40MTcgMCAwMDEuOTE4IDQuNjM1IDUuMzQ2IDUuMzQ2IDAgMDAtLjEzMyAxLjE4MkE1LjQ0MSA1LjQ0MSAwIDAwNDYuODc5IDExYTUuODA0IDUuODA0IDAgMDAtLjAyOC41NjggNi40NTYgNi40NTYgMCAwMDUuMzggNi4zNDUgNS4wNTMgNS4wNTMgMCAwMDYuMzc4IDIuNDcyIDYuNDEyIDYuNDEyIDAgMDA0LjA1IDEuMTIgMjAuNzY4IDIwLjc2OCAwIDAxLTIwLjcxNiAyMS44OTd6XCIgLz5cbiAgICAgICAgICA8cGF0aCBmaWxsPVwiIzY0NDY0N1wiIGQ9XCJNNTQuOTYyIDM0LjNhMTcuNzE5IDE3LjcxOSAwIDAxLTIuNjAyIDIuMzc4Ljk1NC45NTQgMCAwMDEuMTQgMS41MyAxOS42MzcgMTkuNjM3IDAgMDAyLjg4NC0yLjYzNC45NTUuOTU1IDAgMDAtMS40MjItMS4yNzR6XCIgLz5cbiAgICAgICAgICA8cGF0aCBzdHJva2Utd2lkdGg9XCIxLjhcIiBzdHJva2U9XCIjNjQ0NjQ3XCIgZmlsbD1cIiM4NDU1NTZcIiBkPVwiTTQ0LjUgMzIuODI5Yy0uNTEyIDAtMS41NzQuMjE1LTIgLjUtLjQyNi4yODQtLjM0Mi4yNjMtLjUzNy43MzZhMi41OSAyLjU5IDAgMTA0Ljk4Ljk5YzAtLjY4Ni0uNDU4LTEuMjQxLS45NDMtMS43MjYtLjQ4NS0uNDg2LS44MTQtLjUtMS41LS41em0tMzAuOTE2LTIuNWMtLjI5NiAwLS45MTIuMTM0LTEuMTU5LjMxMS0uMjQ2LjE3Ny0uMTk3LjE2NC0uMzEuNDU5YTEuNzI1IDEuNzI1IDAgMDAtLjA4Ni45MzJjLjA1OC4zMTIuMi42LjQxLjgyNS4yMS4yMjYuNDc3LjM4Ljc2OC40NDIuMjkxLjA2Mi41OTMuMDMuODY3LS4wOTJzLjUwOC0uMzI5LjY3My0uNTk0YTEuNyAxLjcgMCAwMC4yNTMtLjg5NmMwLS40MjgtLjI2Ni0uNzc0LS41NDctMS4wNzYtLjI4MS0uMzAyLS40NzEtLjMxLS44NjktLjMxMXptMTcuODA1LTExLjM3NWMtLjE0My0uNDkyLS42NDctMS40NTEtMS4wNC0xLjc4LS4zOTItLjMzLS4zNDgtLjI1NS0uODU3LS4zMWEyLjU4OCAyLjU4OCAwIDEwLjQ0MSA1LjA2Yy42Ni0uMTk0IDEuMDY0LS43ODggMS4zOTUtMS4zOS4zMy0uNjAxLjI1Mi0uOTIuMDYtMS41OHptLTIyIDJjLS4xNDMtLjQ5Mi0uNjQ3LTEuNDUxLTEuMDQtMS43OC0uMzkxLS4zMy0uMzQ3LS4yNTUtLjg1Ni0uMzFhMi41ODkgMi41ODkgMCAxMC40NCA1LjA2Yy42Ni0uMTk0IDEuMDY0LS43ODggMS4zOTUtMS4zOS4zMy0uNjAxLjI1Mi0uOTIuMDYtMS41OHpNMzguMTEyIDcuMzI5Yy0uMzk1IDAtMS4yMTYuMTc5LTEuNTQ1LjQxNS0uMzI4LjIzNi0uMjYzLjIxOC0uNDE1LjYxMS0uMTUxLjM5My0uMTkuODI2LS4xMTQgMS4yNDMuMDc4LjQxNy4yNjguOC41NDggMS4xLjI4LjMwMS42MzYuNTA2IDEuMDI0LjU5LjM4OC4wODIuNzkuMDQgMS4xNTUtLjEyMy4zNjYtLjE2My42NzgtLjQzOC44OTgtLjc5Mi4yMi0uMzU0LjMzNy0uNzcuMzM3LTEuMTk1IDAtLjU3LS4zNTQtMS4wMzEtLjczLTEuNDM0LS4zNzQtLjQwMy0uNjI4LS40MTUtMS4xNTgtLjQxNXptLTE5LjEyMy43MDNjLjAyMy0uMjk2LS4wNjItLjkyLS4yMTktMS4xOC0uMTU3LS4yNi0uMTQ4LS4yMS0uNDMyLS4zNDdhMS43MjYgMS43MjYgMCAwMC0uOTIyLS4xNTkgMS42NTQgMS42NTQgMCAwMC0uODU2LjM0NCAxLjQ3MSAxLjQ3MSAwIDAwLS41MDEuNzNjLS4wODUuMjg1LS4wNzcuNTg5LjAyMy44NzIuMS4yODIuMjg3LjUzMi41MzguNzE4YTEuNyAxLjcgMCAwMC44NzMuMzIzYy40MjcuMDMzLjc5My0uMjA0IDEuMTE2LS40Ni4zMjQtLjI1Ni4zNDctLjQ0NS4zOC0uODQxelwiIC8+XG4gICAgICAgICAgPHBhdGggZmlsbD1cIiM2MzQ2NDdcIiBkPVwiTTE1LjAyNyAxNS42MDVhLjk1NC45NTQgMCAwMC0xLjU1MyAxLjEwOGwxLjMzMiAxLjg2M2EuOTU1Ljk1NSAwIDAwMS43MDUtLjc3Ljk1NS45NTUgMCAwMC0uMTUzLS4zNGwtMS4zMzEtMS44NjF6XCIgLz5cbiAgICAgICAgICA8cGF0aCBmaWxsPVwiIzY0NDY0N1wiIGQ9XCJNNDMuMzEgMjMuMjFhLjk1NC45NTQgMCAxMDEuNTUzLTEuMTFsLTEuMjY2LTEuNzcyYS45NTQuOTU0IDAgMTAtMS41NTIgMS4xMWwxLjI2NiAxLjc3MnpcIiAvPlxuICAgICAgICAgIDxwYXRoIGZpbGw9XCIjNjM0NjQ3XCIgZD1cIk0xOS42NzIgMzUuMzc0YS45NTQuOTU0IDAgMDAtLjk1NC45NTN2Mi4zNjNhLjk1NC45NTQgMCAwMDEuOTA3IDB2LTIuMzYyYS45NTQuOTU0IDAgMDAtLjk1My0uOTU0elwiIC8+XG4gICAgICAgICAgPHBhdGggZmlsbD1cIiM2NDQ2NDdcIiBkPVwiTTMzLjEyOSAyOS4xOGwtMi44MDMgMS4wNjVhLjk1My45NTMgMCAwMC0uMDUzIDEuNzY0Ljk1Ny45NTcgMCAwMC43My4wMjJsMi44MDMtMS4wNjVhLjk1My45NTMgMCAwMC0uNjc3LTEuNzgzdi0uMDAzem0yNC4zNzMtMy42MjhsLTIuMTY3LjgyM2EuOTU2Ljk1NiAwIDAwLS4wNTQgMS43NjQuOTU0Ljk1NCAwIDAwLjczLjAyMWwyLjE2OS0uODIzYS45NTQuOTU0IDAgMTAtLjY3OC0xLjc4NHYtLjAwMXpcIiAvPlxuICAgICAgICA8L3N2Zz5cbiAgICAgIDwvc3Bhbj5cblxuICAgICAgPGg1IGNsYXNzPVwidGV4dC1zbSBmb250LXNlbWlib2xkIG1iLTIgdGV4dC1sZWZ0IG1yLWF1dG8gdGV4dC1zdXJmYWNlLTcwMCBkYXJrOnRleHQtc3VyZmFjZS01MFwiPlxuICAgICAgICB7eyAkdChcIlZvdHJlIHZpZSBwcml2w6llIGVzdCBpbXBvcnRhbnRlIHBvdXIgbm91c1wiKSB9fVxuICAgICAgPC9oNT5cblxuICAgICAgPHAgY2xhc3M9XCJ3LWZ1bGwgbWItNCB0ZXh0LXNtIHRleHQtanVzdGlmeSB0ZXh0LXN1cmZhY2UtODAwIGRhcms6dGV4dC1zdXJmYWNlLTUwXCI+XG4gICAgICAgIHt7ICR0KFwiTm91cyB0cmFpdG9ucyB2b3MgaW5mb3JtYXRpb25zIHBlcnNvbm5lbGxlcyBhZmluIGRlIG1lc3VyZXIgZXQgZCdhbcOpbGlvcmVyIG5vcyBzaXRlcyBldCBzZXJ2aWNlcywgZGUgc291dGVuaXIgbm9zIGNhbXBhZ25lcyBldCBkZSB2b3VzIHByb3Bvc2VyIGRlcyBjb250ZW51cyBwZXJzb25uYWxpc8Opcy5cIikgfX1cbiAgICAgIDwvcD5cblxuICAgICAgPHAgY2xhc3M9XCJ3LWZ1bGwgbWItNiB0ZXh0LXNtIHRleHQtanVzdGlmeSB0ZXh0LXN1cmZhY2UtODAwIGRhcms6dGV4dC1zdXJmYWNlLTUwXCI+XG4gICAgICAgIHt7ICR0KFwiUG91ciBwbHVzIGQnaW5mb3JtYXRpb25zLCBjb25zdWx0ZXogbm90cmUgUG9saXRpcXVlIGRlIGNvbmZpZGVudGlhbGl0w6kuXCIpIH19IDxudXh0LWxpbmsgY2xhc3M9XCJ0ZXh0LXN1cmZhY2UtNjAwIGhvdmVyOnRleHQtc3VyZmFjZS03MDAgaG92ZXI6dW5kZXJsaW5lIHVuZGVybGluZS1vZmZzZXQtMlwiIGhyZWY9XCIvbGVnYWwvY29uZmlkZW50aWFsaXRlXCI+XG4gICAgICAgICAge3sgJHQoXCJQb2xpdGlxdWUgZGUgY29uZmlkZW50aWFsaXTDqVwiKSB9fVxuICAgICAgICA8L251eHQtbGluaz5cbiAgICAgIDwvcD5cblxuICAgICAgPGRpdiBjbGFzcz1cImdyaWQgZ3JpZC1jb2xzLTIgdy1mdWxsIGNvbnRlbnQtY2VudGVyXCI+XG4gICAgICAgIDxidXR0b24gY2xhc3M9XCJ0ZXh0LXNtIHRleHQtc3VyZmFjZS02MDAgY3Vyc29yLXBvaW50ZXIgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uLWNvbG9ycyBob3Zlcjp0ZXh0LXN1cmZhY2UtNzAwIGhvdmVyOnVuZGVybGluZSB1bmRlcmxpbmUtb2Zmc2V0LTJcIiBAY2xpY2s9XCIoKSA9PiB0b2dnbGVTaG93T3B0aW9ucygpXCI+XG4gICAgICAgICAge3sgJHQoXCJQbHVzIGQnb3B0aW9uc1wiKSB9fVxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICA8IS0tIGN1cnNvci1wb2ludGVyIHB5LTIgcHgtOCB3LW1heCBicmVhay1rZWVwIHRleHQtc20gcm91bmRlZC1sZyB0cmFuc2l0aW9uLWNvbG9ycyB0ZXh0LVsjNjM0NjQ3XSBob3Zlcjp0ZXh0LVsjZGRhZDgxXSBiZy1bI2RkYWQ4MV0gaG92ZXI6YmctWyM2MzQ2NDddIC0tPlxuICAgICAgICA8dm9sdC1jb250cmFzdC1idXR0b24gY2xhc3M9XCJmb250LXNlbWlib2xkXCIgQGNsaWNrPVwiKCkgPT4gYWNjZXB0KGFjY2VwdEFsbClcIj5cbiAgICAgICAgICB7eyAkdChcIkFjY2VwdGVyIHRvdXRcIikgfX1cbiAgICAgICAgPC92b2x0LWNvbnRyYXN0LWJ1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG5cbjxzY3JpcHQgc2V0dXAgbGFuZz1cInRzXCI+XG4vKipcbiAqIENvb2tpZVxuICovXG5jb25zdCB7IHRvZ2dsZVNob3dPcHRpb25zLCBzaG93QmFubmVyLCBhY2NlcHQgfSA9IHVzZUNvb2tpZUNvbXBvc2FibGUoKVxuXG4vKipcbiAqIENvbnNlbnQgR29vZ2xlIEFuYWx5dGljc1xuICovXG5jb25zdCB7IGFjY2VwdEFsbCB9ID0gdXNlQ29uc2VudCgpXG48L3NjcmlwdD5cbiJdLCJmaWxlIjoiL1ZvbHVtZXMvQ29kaW5nL1Byb2plY3RzL1dlYnNpdGVzL2luZWlhaC9mcm9udGVuZC9hcHAvY29tcG9uZW50cy9jb29raWUvQmFubmVyLmNsaWVudC52dWUifQ==