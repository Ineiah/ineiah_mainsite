import { t as __commonJSMin } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.cache/vite/client/deps/rolldown-runtime-BvCyGRYZ.js?v=7e73afc2";
//#region node_modules/.pnpm/dayjs@1.11.21/node_modules/dayjs/plugin/duration.js
var require_duration = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(t, s) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = s() : "function" == typeof define && define.amd ? define(s) : (t = "undefined" != typeof globalThis ? globalThis : t || self).dayjs_plugin_duration = s();
	})(exports, (function() {
		"use strict";
		var t, s, n = 1e3, i = 6e4, e = 36e5, r = 864e5, o = 31536e6, u = 2628e6, d = /^(-|\+)?P(?:([-+]?[0-9,.]*)Y)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)W)?(?:([-+]?[0-9,.]*)D)?(?:T(?:([-+]?[0-9,.]*)H)?(?:([-+]?[0-9,.]*)M)?(?:([-+]?[0-9,.]*)S)?)?$/, a = /\[([^\]]+)]|YYYY|YY|Y|M{1,2}|D{1,2}|H{1,2}|m{1,2}|s{1,2}|SSS/g, h = {
			years: o,
			months: u,
			days: r,
			hours: e,
			minutes: i,
			seconds: n,
			milliseconds: 1,
			weeks: 6048e5
		}, c = function(t) {
			return t instanceof g;
		}, f = function(t, s, n) {
			return new g(t, n, s.$l);
		}, m = function(t) {
			return s.p(t) + "s";
		}, l = function(t) {
			return t < 0;
		}, $ = function(t) {
			return l(t) ? Math.ceil(t) : Math.floor(t);
		}, y = function(t) {
			return Math.abs(t);
		}, v = function(t, s) {
			return t ? l(t) ? {
				negative: !0,
				format: "" + y(t) + s
			} : {
				negative: !1,
				format: "" + t + s
			} : {
				negative: !1,
				format: ""
			};
		}, g = function() {
			function l(t, s, n) {
				var i = this;
				if (this.$d = {}, this.$l = n, void 0 === t && (this.$ms = 0, this.parseFromMilliseconds()), s) return f(t * h[m(s)], this);
				if ("number" == typeof t) return this.$ms = t, this.parseFromMilliseconds(), this;
				if ("object" == typeof t) return Object.keys(t).forEach((function(s) {
					i.$d[m(s)] = t[s];
				})), this.calMilliseconds(), this;
				if ("string" == typeof t) {
					var e = t.match(d);
					if (e) {
						var r = e.slice(2).map((function(t) {
							return null != t ? Number(t) : 0;
						}));
						return this.$d.years = r[0], this.$d.months = r[1], this.$d.weeks = r[2], this.$d.days = r[3], this.$d.hours = r[4], this.$d.minutes = r[5], this.$d.seconds = r[6], this.calMilliseconds(), this;
					}
				}
				return this;
			}
			var y = l.prototype;
			return y.calMilliseconds = function() {
				var t = this;
				this.$ms = Object.keys(this.$d).reduce((function(s, n) {
					return s + (t.$d[n] || 0) * h[n];
				}), 0);
			}, y.parseFromMilliseconds = function() {
				var t = this.$ms;
				this.$d.years = $(t / o), t %= o, this.$d.months = $(t / u), t %= u, this.$d.days = $(t / r), t %= r, this.$d.hours = $(t / e), t %= e, this.$d.minutes = $(t / i), t %= i, this.$d.seconds = $(t / n), t %= n, this.$d.milliseconds = t;
			}, y.toISOString = function() {
				var t = v(this.$d.years, "Y"), s = v(this.$d.months, "M"), n = +this.$d.days || 0;
				this.$d.weeks && (n += 7 * this.$d.weeks);
				var i = v(n, "D"), e = v(this.$d.hours, "H"), r = v(this.$d.minutes, "M"), o = this.$d.seconds || 0;
				this.$d.milliseconds && (o += this.$d.milliseconds / 1e3, o = Math.round(1e3 * o) / 1e3);
				var u = v(o, "S"), d = t.negative || s.negative || i.negative || e.negative || r.negative || u.negative, a = e.format || r.format || u.format ? "T" : "", h = (d ? "-" : "") + "P" + t.format + s.format + i.format + a + e.format + r.format + u.format;
				return "P" === h || "-P" === h ? "P0D" : h;
			}, y.toJSON = function() {
				return this.toISOString();
			}, y.format = function(t) {
				var n = t || "YYYY-MM-DDTHH:mm:ss", i = {
					Y: this.$d.years,
					YY: s.s(this.$d.years, 2, "0"),
					YYYY: s.s(this.$d.years, 4, "0"),
					M: this.$d.months,
					MM: s.s(this.$d.months, 2, "0"),
					D: this.$d.days,
					DD: s.s(this.$d.days, 2, "0"),
					H: this.$d.hours,
					HH: s.s(this.$d.hours, 2, "0"),
					m: this.$d.minutes,
					mm: s.s(this.$d.minutes, 2, "0"),
					s: this.$d.seconds,
					ss: s.s(this.$d.seconds, 2, "0"),
					SSS: s.s(this.$d.milliseconds, 3, "0")
				};
				return n.replace(a, (function(t, s) {
					return s || String(i[t]);
				}));
			}, y.as = function(t) {
				return this.$ms / h[m(t)];
			}, y.get = function(t) {
				var s = this.$ms, n = m(t);
				return "milliseconds" === n ? s %= 1e3 : s = "weeks" === n ? $(s / h[n]) : this.$d[n], s || 0;
			}, y.add = function(t, s, n) {
				var i;
				return i = s ? t * h[m(s)] : c(t) ? t.$ms : f(t, this).$ms, f(this.$ms + i * (n ? -1 : 1), this);
			}, y.subtract = function(t, s) {
				return this.add(t, s, !0);
			}, y.locale = function(t) {
				var s = this.clone();
				return s.$l = t, s;
			}, y.clone = function() {
				return f(this.$ms, this);
			}, y.humanize = function(s) {
				return t().add(this.$ms, "ms").locale(this.$l).fromNow(!s);
			}, y.valueOf = function() {
				return this.asMilliseconds();
			}, y.milliseconds = function() {
				return this.get("milliseconds");
			}, y.asMilliseconds = function() {
				return this.as("milliseconds");
			}, y.seconds = function() {
				return this.get("seconds");
			}, y.asSeconds = function() {
				return this.as("seconds");
			}, y.minutes = function() {
				return this.get("minutes");
			}, y.asMinutes = function() {
				return this.as("minutes");
			}, y.hours = function() {
				return this.get("hours");
			}, y.asHours = function() {
				return this.as("hours");
			}, y.days = function() {
				return this.get("days");
			}, y.asDays = function() {
				return this.as("days");
			}, y.weeks = function() {
				return this.get("weeks");
			}, y.asWeeks = function() {
				return this.as("weeks");
			}, y.months = function() {
				return this.get("months");
			}, y.asMonths = function() {
				return this.as("months");
			}, y.years = function() {
				return this.get("years");
			}, y.asYears = function() {
				return this.as("years");
			}, l;
		}(), p = function(t, s, n) {
			return t.add(s.years() * n, "y").add(s.months() * n, "M").add(s.days() * n, "d").add(s.hours() * n, "h").add(s.minutes() * n, "m").add(s.seconds() * n, "s").add(s.milliseconds() * n, "ms");
		};
		return function(n, i, e) {
			t = e, s = e().$utils(), e.duration = function(t, s) {
				return f(t, { $l: e.locale() }, s);
			}, e.isDuration = c;
			var r = i.prototype.add, o = i.prototype.subtract;
			i.prototype.add = function(t, s) {
				return c(t) ? p(this, t, 1) : r.bind(this)(t, s);
			}, i.prototype.subtract = function(t, s) {
				return c(t) ? p(this, t, -1) : o.bind(this)(t, s);
			};
		};
	}));
}));
//#endregion
export default require_duration();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF5anNfcGx1Z2luX2R1cmF0aW9uLmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy5wbnBtL2RheWpzQDEuMTEuMjEvbm9kZV9tb2R1bGVzL2RheWpzL3BsdWdpbi9kdXJhdGlvbi5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIhZnVuY3Rpb24odCxzKXtcIm9iamVjdFwiPT10eXBlb2YgZXhwb3J0cyYmXCJ1bmRlZmluZWRcIiE9dHlwZW9mIG1vZHVsZT9tb2R1bGUuZXhwb3J0cz1zKCk6XCJmdW5jdGlvblwiPT10eXBlb2YgZGVmaW5lJiZkZWZpbmUuYW1kP2RlZmluZShzKToodD1cInVuZGVmaW5lZFwiIT10eXBlb2YgZ2xvYmFsVGhpcz9nbG9iYWxUaGlzOnR8fHNlbGYpLmRheWpzX3BsdWdpbl9kdXJhdGlvbj1zKCl9KHRoaXMsKGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7dmFyIHQscyxuPTFlMyxpPTZlNCxlPTM2ZTUscj04NjRlNSxvPTMxNTM2ZTYsdT0yNjI4ZTYsZD0vXigtfFxcKyk/UCg/OihbLStdP1swLTksLl0qKVkpPyg/OihbLStdP1swLTksLl0qKU0pPyg/OihbLStdP1swLTksLl0qKVcpPyg/OihbLStdP1swLTksLl0qKUQpPyg/OlQoPzooWy0rXT9bMC05LC5dKilIKT8oPzooWy0rXT9bMC05LC5dKilNKT8oPzooWy0rXT9bMC05LC5dKilTKT8pPyQvLGE9L1xcWyhbXlxcXV0rKV18WVlZWXxZWXxZfE17MSwyfXxEezEsMn18SHsxLDJ9fG17MSwyfXxzezEsMn18U1NTL2csaD17eWVhcnM6byxtb250aHM6dSxkYXlzOnIsaG91cnM6ZSxtaW51dGVzOmksc2Vjb25kczpuLG1pbGxpc2Vjb25kczoxLHdlZWtzOjYwNDhlNX0sYz1mdW5jdGlvbih0KXtyZXR1cm4gdCBpbnN0YW5jZW9mIGd9LGY9ZnVuY3Rpb24odCxzLG4pe3JldHVybiBuZXcgZyh0LG4scy4kbCl9LG09ZnVuY3Rpb24odCl7cmV0dXJuIHMucCh0KStcInNcIn0sbD1mdW5jdGlvbih0KXtyZXR1cm4gdDwwfSwkPWZ1bmN0aW9uKHQpe3JldHVybiBsKHQpP01hdGguY2VpbCh0KTpNYXRoLmZsb29yKHQpfSx5PWZ1bmN0aW9uKHQpe3JldHVybiBNYXRoLmFicyh0KX0sdj1mdW5jdGlvbih0LHMpe3JldHVybiB0P2wodCk/e25lZ2F0aXZlOiEwLGZvcm1hdDpcIlwiK3kodCkrc306e25lZ2F0aXZlOiExLGZvcm1hdDpcIlwiK3Qrc306e25lZ2F0aXZlOiExLGZvcm1hdDpcIlwifX0sZz1mdW5jdGlvbigpe2Z1bmN0aW9uIGwodCxzLG4pe3ZhciBpPXRoaXM7aWYodGhpcy4kZD17fSx0aGlzLiRsPW4sdm9pZCAwPT09dCYmKHRoaXMuJG1zPTAsdGhpcy5wYXJzZUZyb21NaWxsaXNlY29uZHMoKSkscylyZXR1cm4gZih0KmhbbShzKV0sdGhpcyk7aWYoXCJudW1iZXJcIj09dHlwZW9mIHQpcmV0dXJuIHRoaXMuJG1zPXQsdGhpcy5wYXJzZUZyb21NaWxsaXNlY29uZHMoKSx0aGlzO2lmKFwib2JqZWN0XCI9PXR5cGVvZiB0KXJldHVybiBPYmplY3Qua2V5cyh0KS5mb3JFYWNoKChmdW5jdGlvbihzKXtpLiRkW20ocyldPXRbc119KSksdGhpcy5jYWxNaWxsaXNlY29uZHMoKSx0aGlzO2lmKFwic3RyaW5nXCI9PXR5cGVvZiB0KXt2YXIgZT10Lm1hdGNoKGQpO2lmKGUpe3ZhciByPWUuc2xpY2UoMikubWFwKChmdW5jdGlvbih0KXtyZXR1cm4gbnVsbCE9dD9OdW1iZXIodCk6MH0pKTtyZXR1cm4gdGhpcy4kZC55ZWFycz1yWzBdLHRoaXMuJGQubW9udGhzPXJbMV0sdGhpcy4kZC53ZWVrcz1yWzJdLHRoaXMuJGQuZGF5cz1yWzNdLHRoaXMuJGQuaG91cnM9cls0XSx0aGlzLiRkLm1pbnV0ZXM9cls1XSx0aGlzLiRkLnNlY29uZHM9cls2XSx0aGlzLmNhbE1pbGxpc2Vjb25kcygpLHRoaXN9fXJldHVybiB0aGlzfXZhciB5PWwucHJvdG90eXBlO3JldHVybiB5LmNhbE1pbGxpc2Vjb25kcz1mdW5jdGlvbigpe3ZhciB0PXRoaXM7dGhpcy4kbXM9T2JqZWN0LmtleXModGhpcy4kZCkucmVkdWNlKChmdW5jdGlvbihzLG4pe3JldHVybiBzKyh0LiRkW25dfHwwKSpoW25dfSksMCl9LHkucGFyc2VGcm9tTWlsbGlzZWNvbmRzPWZ1bmN0aW9uKCl7dmFyIHQ9dGhpcy4kbXM7dGhpcy4kZC55ZWFycz0kKHQvbyksdCU9byx0aGlzLiRkLm1vbnRocz0kKHQvdSksdCU9dSx0aGlzLiRkLmRheXM9JCh0L3IpLHQlPXIsdGhpcy4kZC5ob3Vycz0kKHQvZSksdCU9ZSx0aGlzLiRkLm1pbnV0ZXM9JCh0L2kpLHQlPWksdGhpcy4kZC5zZWNvbmRzPSQodC9uKSx0JT1uLHRoaXMuJGQubWlsbGlzZWNvbmRzPXR9LHkudG9JU09TdHJpbmc9ZnVuY3Rpb24oKXt2YXIgdD12KHRoaXMuJGQueWVhcnMsXCJZXCIpLHM9dih0aGlzLiRkLm1vbnRocyxcIk1cIiksbj0rdGhpcy4kZC5kYXlzfHwwO3RoaXMuJGQud2Vla3MmJihuKz03KnRoaXMuJGQud2Vla3MpO3ZhciBpPXYobixcIkRcIiksZT12KHRoaXMuJGQuaG91cnMsXCJIXCIpLHI9dih0aGlzLiRkLm1pbnV0ZXMsXCJNXCIpLG89dGhpcy4kZC5zZWNvbmRzfHwwO3RoaXMuJGQubWlsbGlzZWNvbmRzJiYobys9dGhpcy4kZC5taWxsaXNlY29uZHMvMWUzLG89TWF0aC5yb3VuZCgxZTMqbykvMWUzKTt2YXIgdT12KG8sXCJTXCIpLGQ9dC5uZWdhdGl2ZXx8cy5uZWdhdGl2ZXx8aS5uZWdhdGl2ZXx8ZS5uZWdhdGl2ZXx8ci5uZWdhdGl2ZXx8dS5uZWdhdGl2ZSxhPWUuZm9ybWF0fHxyLmZvcm1hdHx8dS5mb3JtYXQ/XCJUXCI6XCJcIixoPShkP1wiLVwiOlwiXCIpK1wiUFwiK3QuZm9ybWF0K3MuZm9ybWF0K2kuZm9ybWF0K2ErZS5mb3JtYXQrci5mb3JtYXQrdS5mb3JtYXQ7cmV0dXJuXCJQXCI9PT1ofHxcIi1QXCI9PT1oP1wiUDBEXCI6aH0seS50b0pTT049ZnVuY3Rpb24oKXtyZXR1cm4gdGhpcy50b0lTT1N0cmluZygpfSx5LmZvcm1hdD1mdW5jdGlvbih0KXt2YXIgbj10fHxcIllZWVktTU0tRERUSEg6bW06c3NcIixpPXtZOnRoaXMuJGQueWVhcnMsWVk6cy5zKHRoaXMuJGQueWVhcnMsMixcIjBcIiksWVlZWTpzLnModGhpcy4kZC55ZWFycyw0LFwiMFwiKSxNOnRoaXMuJGQubW9udGhzLE1NOnMucyh0aGlzLiRkLm1vbnRocywyLFwiMFwiKSxEOnRoaXMuJGQuZGF5cyxERDpzLnModGhpcy4kZC5kYXlzLDIsXCIwXCIpLEg6dGhpcy4kZC5ob3VycyxISDpzLnModGhpcy4kZC5ob3VycywyLFwiMFwiKSxtOnRoaXMuJGQubWludXRlcyxtbTpzLnModGhpcy4kZC5taW51dGVzLDIsXCIwXCIpLHM6dGhpcy4kZC5zZWNvbmRzLHNzOnMucyh0aGlzLiRkLnNlY29uZHMsMixcIjBcIiksU1NTOnMucyh0aGlzLiRkLm1pbGxpc2Vjb25kcywzLFwiMFwiKX07cmV0dXJuIG4ucmVwbGFjZShhLChmdW5jdGlvbih0LHMpe3JldHVybiBzfHxTdHJpbmcoaVt0XSl9KSl9LHkuYXM9ZnVuY3Rpb24odCl7cmV0dXJuIHRoaXMuJG1zL2hbbSh0KV19LHkuZ2V0PWZ1bmN0aW9uKHQpe3ZhciBzPXRoaXMuJG1zLG49bSh0KTtyZXR1cm5cIm1pbGxpc2Vjb25kc1wiPT09bj9zJT0xZTM6cz1cIndlZWtzXCI9PT1uPyQocy9oW25dKTp0aGlzLiRkW25dLHN8fDB9LHkuYWRkPWZ1bmN0aW9uKHQscyxuKXt2YXIgaTtyZXR1cm4gaT1zP3QqaFttKHMpXTpjKHQpP3QuJG1zOmYodCx0aGlzKS4kbXMsZih0aGlzLiRtcytpKihuPy0xOjEpLHRoaXMpfSx5LnN1YnRyYWN0PWZ1bmN0aW9uKHQscyl7cmV0dXJuIHRoaXMuYWRkKHQscywhMCl9LHkubG9jYWxlPWZ1bmN0aW9uKHQpe3ZhciBzPXRoaXMuY2xvbmUoKTtyZXR1cm4gcy4kbD10LHN9LHkuY2xvbmU9ZnVuY3Rpb24oKXtyZXR1cm4gZih0aGlzLiRtcyx0aGlzKX0seS5odW1hbml6ZT1mdW5jdGlvbihzKXtyZXR1cm4gdCgpLmFkZCh0aGlzLiRtcyxcIm1zXCIpLmxvY2FsZSh0aGlzLiRsKS5mcm9tTm93KCFzKX0seS52YWx1ZU9mPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuYXNNaWxsaXNlY29uZHMoKX0seS5taWxsaXNlY29uZHM9ZnVuY3Rpb24oKXtyZXR1cm4gdGhpcy5nZXQoXCJtaWxsaXNlY29uZHNcIil9LHkuYXNNaWxsaXNlY29uZHM9ZnVuY3Rpb24oKXtyZXR1cm4gdGhpcy5hcyhcIm1pbGxpc2Vjb25kc1wiKX0seS5zZWNvbmRzPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuZ2V0KFwic2Vjb25kc1wiKX0seS5hc1NlY29uZHM9ZnVuY3Rpb24oKXtyZXR1cm4gdGhpcy5hcyhcInNlY29uZHNcIil9LHkubWludXRlcz1mdW5jdGlvbigpe3JldHVybiB0aGlzLmdldChcIm1pbnV0ZXNcIil9LHkuYXNNaW51dGVzPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuYXMoXCJtaW51dGVzXCIpfSx5LmhvdXJzPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuZ2V0KFwiaG91cnNcIil9LHkuYXNIb3Vycz1mdW5jdGlvbigpe3JldHVybiB0aGlzLmFzKFwiaG91cnNcIil9LHkuZGF5cz1mdW5jdGlvbigpe3JldHVybiB0aGlzLmdldChcImRheXNcIil9LHkuYXNEYXlzPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuYXMoXCJkYXlzXCIpfSx5LndlZWtzPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuZ2V0KFwid2Vla3NcIil9LHkuYXNXZWVrcz1mdW5jdGlvbigpe3JldHVybiB0aGlzLmFzKFwid2Vla3NcIil9LHkubW9udGhzPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuZ2V0KFwibW9udGhzXCIpfSx5LmFzTW9udGhzPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuYXMoXCJtb250aHNcIil9LHkueWVhcnM9ZnVuY3Rpb24oKXtyZXR1cm4gdGhpcy5nZXQoXCJ5ZWFyc1wiKX0seS5hc1llYXJzPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXMuYXMoXCJ5ZWFyc1wiKX0sbH0oKSxwPWZ1bmN0aW9uKHQscyxuKXtyZXR1cm4gdC5hZGQocy55ZWFycygpKm4sXCJ5XCIpLmFkZChzLm1vbnRocygpKm4sXCJNXCIpLmFkZChzLmRheXMoKSpuLFwiZFwiKS5hZGQocy5ob3VycygpKm4sXCJoXCIpLmFkZChzLm1pbnV0ZXMoKSpuLFwibVwiKS5hZGQocy5zZWNvbmRzKCkqbixcInNcIikuYWRkKHMubWlsbGlzZWNvbmRzKCkqbixcIm1zXCIpfTtyZXR1cm4gZnVuY3Rpb24obixpLGUpe3Q9ZSxzPWUoKS4kdXRpbHMoKSxlLmR1cmF0aW9uPWZ1bmN0aW9uKHQscyl7dmFyIG49ZS5sb2NhbGUoKTtyZXR1cm4gZih0LHskbDpufSxzKX0sZS5pc0R1cmF0aW9uPWM7dmFyIHI9aS5wcm90b3R5cGUuYWRkLG89aS5wcm90b3R5cGUuc3VidHJhY3Q7aS5wcm90b3R5cGUuYWRkPWZ1bmN0aW9uKHQscyl7cmV0dXJuIGModCk/cCh0aGlzLHQsMSk6ci5iaW5kKHRoaXMpKHQscyl9LGkucHJvdG90eXBlLnN1YnRyYWN0PWZ1bmN0aW9uKHQscyl7cmV0dXJuIGModCk/cCh0aGlzLHQsLTEpOm8uYmluZCh0aGlzKSh0LHMpfX19KSk7Il0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXSwibWFwcGluZ3MiOiI7OztDQUFBLENBQUMsU0FBUyxHQUFFLEdBQUU7RUFBQyxZQUFVLE9BQU8sV0FBUyxlQUFhLE9BQU8sU0FBTyxPQUFPLFVBQVEsRUFBRSxJQUFFLGNBQVksT0FBTyxVQUFRLE9BQU8sTUFBSSxPQUFPLENBQUMsSUFBRSxDQUFDLElBQUUsZUFBYSxPQUFPLGFBQVcsYUFBVyxLQUFHLEtBQUEsQ0FBTSx3QkFBc0IsRUFBRTtDQUFDLEVBQUEsQ0FBQyxVQUFPLFdBQVU7RUFBQztFQUFhLElBQUksR0FBRSxHQUFFLElBQUUsS0FBSSxJQUFFLEtBQUksSUFBRSxNQUFLLElBQUUsT0FBTSxJQUFFLFNBQVEsSUFBRSxRQUFPLElBQUUsdUtBQXNLLElBQUUsaUVBQWdFLElBQUU7R0FBQyxPQUFNO0dBQUUsUUFBTztHQUFFLE1BQUs7R0FBRSxPQUFNO0dBQUUsU0FBUTtHQUFFLFNBQVE7R0FBRSxjQUFhO0dBQUUsT0FBTTtFQUFNLEdBQUUsSUFBRSxTQUFTLEdBQUU7R0FBQyxPQUFPLGFBQWE7RUFBQyxHQUFFLElBQUUsU0FBUyxHQUFFLEdBQUUsR0FBRTtHQUFDLE9BQU8sSUFBSSxFQUFFLEdBQUUsR0FBRSxFQUFFLEVBQUU7RUFBQyxHQUFFLElBQUUsU0FBUyxHQUFFO0dBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxJQUFFO0VBQUcsR0FBRSxJQUFFLFNBQVMsR0FBRTtHQUFDLE9BQU8sSUFBRTtFQUFDLEdBQUUsSUFBRSxTQUFTLEdBQUU7R0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFFLEtBQUssS0FBSyxDQUFDLElBQUUsS0FBSyxNQUFNLENBQUM7RUFBQyxHQUFFLElBQUUsU0FBUyxHQUFFO0dBQUMsT0FBTyxLQUFLLElBQUksQ0FBQztFQUFDLEdBQUUsSUFBRSxTQUFTLEdBQUUsR0FBRTtHQUFDLE9BQU8sSUFBRSxFQUFFLENBQUMsSUFBRTtJQUFDLFVBQVMsQ0FBQztJQUFFLFFBQU8sS0FBRyxFQUFFLENBQUMsSUFBRTtHQUFDLElBQUU7SUFBQyxVQUFTLENBQUM7SUFBRSxRQUFPLEtBQUcsSUFBRTtHQUFDLElBQUU7SUFBQyxVQUFTLENBQUM7SUFBRSxRQUFPO0dBQUU7RUFBQyxHQUFFLElBQUUsV0FBVTtHQUFDLFNBQVMsRUFBRSxHQUFFLEdBQUUsR0FBRTtJQUFDLElBQUksSUFBRTtJQUFLLElBQUcsS0FBSyxLQUFHLENBQUMsR0FBRSxLQUFLLEtBQUcsR0FBRSxLQUFLLE1BQUksTUFBSSxLQUFLLE1BQUksR0FBRSxLQUFLLHNCQUFzQixJQUFHLEdBQUUsT0FBTyxFQUFFLElBQUUsRUFBRSxFQUFFLENBQUMsSUFBRyxJQUFJO0lBQUUsSUFBRyxZQUFVLE9BQU8sR0FBRSxPQUFPLEtBQUssTUFBSSxHQUFFLEtBQUssc0JBQXNCLEdBQUU7SUFBSyxJQUFHLFlBQVUsT0FBTyxHQUFFLE9BQU8sT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVMsU0FBUyxHQUFFO0tBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxLQUFHLEVBQUU7SUFBRSxFQUFFLEdBQUUsS0FBSyxnQkFBZ0IsR0FBRTtJQUFLLElBQUcsWUFBVSxPQUFPLEdBQUU7S0FBQyxJQUFJLElBQUUsRUFBRSxNQUFNLENBQUM7S0FBRSxJQUFHLEdBQUU7TUFBQyxJQUFJLElBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBUyxHQUFFO09BQUMsT0FBTyxRQUFNLElBQUUsT0FBTyxDQUFDLElBQUU7TUFBQyxFQUFFO01BQUUsT0FBTyxLQUFLLEdBQUcsUUFBTSxFQUFFLElBQUcsS0FBSyxHQUFHLFNBQU8sRUFBRSxJQUFHLEtBQUssR0FBRyxRQUFNLEVBQUUsSUFBRyxLQUFLLEdBQUcsT0FBSyxFQUFFLElBQUcsS0FBSyxHQUFHLFFBQU0sRUFBRSxJQUFHLEtBQUssR0FBRyxVQUFRLEVBQUUsSUFBRyxLQUFLLEdBQUcsVUFBUSxFQUFFLElBQUcsS0FBSyxnQkFBZ0IsR0FBRTtLQUFJO0lBQUM7SUFBQyxPQUFPO0dBQUk7R0FBQyxJQUFJLElBQUUsRUFBRTtHQUFVLE9BQU8sRUFBRSxrQkFBZ0IsV0FBVTtJQUFDLElBQUksSUFBRTtJQUFLLEtBQUssTUFBSSxPQUFPLEtBQUssS0FBSyxFQUFFLENBQUMsQ0FBQyxRQUFRLFNBQVMsR0FBRSxHQUFFO0tBQUMsT0FBTyxLQUFHLEVBQUUsR0FBRyxNQUFJLEtBQUcsRUFBRTtJQUFFLElBQUcsQ0FBQztHQUFDLEdBQUUsRUFBRSx3QkFBc0IsV0FBVTtJQUFDLElBQUksSUFBRSxLQUFLO0lBQUksS0FBSyxHQUFHLFFBQU0sRUFBRSxJQUFFLENBQUMsR0FBRSxLQUFHLEdBQUUsS0FBSyxHQUFHLFNBQU8sRUFBRSxJQUFFLENBQUMsR0FBRSxLQUFHLEdBQUUsS0FBSyxHQUFHLE9BQUssRUFBRSxJQUFFLENBQUMsR0FBRSxLQUFHLEdBQUUsS0FBSyxHQUFHLFFBQU0sRUFBRSxJQUFFLENBQUMsR0FBRSxLQUFHLEdBQUUsS0FBSyxHQUFHLFVBQVEsRUFBRSxJQUFFLENBQUMsR0FBRSxLQUFHLEdBQUUsS0FBSyxHQUFHLFVBQVEsRUFBRSxJQUFFLENBQUMsR0FBRSxLQUFHLEdBQUUsS0FBSyxHQUFHLGVBQWE7R0FBQyxHQUFFLEVBQUUsY0FBWSxXQUFVO0lBQUMsSUFBSSxJQUFFLEVBQUUsS0FBSyxHQUFHLE9BQU0sR0FBRyxHQUFFLElBQUUsRUFBRSxLQUFLLEdBQUcsUUFBTyxHQUFHLEdBQUUsSUFBRSxDQUFDLEtBQUssR0FBRyxRQUFNO0lBQUUsS0FBSyxHQUFHLFVBQVEsS0FBRyxJQUFFLEtBQUssR0FBRztJQUFPLElBQUksSUFBRSxFQUFFLEdBQUUsR0FBRyxHQUFFLElBQUUsRUFBRSxLQUFLLEdBQUcsT0FBTSxHQUFHLEdBQUUsSUFBRSxFQUFFLEtBQUssR0FBRyxTQUFRLEdBQUcsR0FBRSxJQUFFLEtBQUssR0FBRyxXQUFTO0lBQUUsS0FBSyxHQUFHLGlCQUFlLEtBQUcsS0FBSyxHQUFHLGVBQWEsS0FBSSxJQUFFLEtBQUssTUFBTSxNQUFJLENBQUMsSUFBRTtJQUFLLElBQUksSUFBRSxFQUFFLEdBQUUsR0FBRyxHQUFFLElBQUUsRUFBRSxZQUFVLEVBQUUsWUFBVSxFQUFFLFlBQVUsRUFBRSxZQUFVLEVBQUUsWUFBVSxFQUFFLFVBQVMsSUFBRSxFQUFFLFVBQVEsRUFBRSxVQUFRLEVBQUUsU0FBTyxNQUFJLElBQUcsS0FBRyxJQUFFLE1BQUksTUFBSSxNQUFJLEVBQUUsU0FBTyxFQUFFLFNBQU8sRUFBRSxTQUFPLElBQUUsRUFBRSxTQUFPLEVBQUUsU0FBTyxFQUFFO0lBQU8sT0FBTSxRQUFNLEtBQUcsU0FBTyxJQUFFLFFBQU07R0FBQyxHQUFFLEVBQUUsU0FBTyxXQUFVO0lBQUMsT0FBTyxLQUFLLFlBQVk7R0FBQyxHQUFFLEVBQUUsU0FBTyxTQUFTLEdBQUU7SUFBQyxJQUFJLElBQUUsS0FBRyx1QkFBc0IsSUFBRTtLQUFDLEdBQUUsS0FBSyxHQUFHO0tBQU0sSUFBRyxFQUFFLEVBQUUsS0FBSyxHQUFHLE9BQU0sR0FBRSxHQUFHO0tBQUUsTUFBSyxFQUFFLEVBQUUsS0FBSyxHQUFHLE9BQU0sR0FBRSxHQUFHO0tBQUUsR0FBRSxLQUFLLEdBQUc7S0FBTyxJQUFHLEVBQUUsRUFBRSxLQUFLLEdBQUcsUUFBTyxHQUFFLEdBQUc7S0FBRSxHQUFFLEtBQUssR0FBRztLQUFLLElBQUcsRUFBRSxFQUFFLEtBQUssR0FBRyxNQUFLLEdBQUUsR0FBRztLQUFFLEdBQUUsS0FBSyxHQUFHO0tBQU0sSUFBRyxFQUFFLEVBQUUsS0FBSyxHQUFHLE9BQU0sR0FBRSxHQUFHO0tBQUUsR0FBRSxLQUFLLEdBQUc7S0FBUSxJQUFHLEVBQUUsRUFBRSxLQUFLLEdBQUcsU0FBUSxHQUFFLEdBQUc7S0FBRSxHQUFFLEtBQUssR0FBRztLQUFRLElBQUcsRUFBRSxFQUFFLEtBQUssR0FBRyxTQUFRLEdBQUUsR0FBRztLQUFFLEtBQUksRUFBRSxFQUFFLEtBQUssR0FBRyxjQUFhLEdBQUUsR0FBRztJQUFDO0lBQUUsT0FBTyxFQUFFLFFBQVEsSUFBRyxTQUFTLEdBQUUsR0FBRTtLQUFDLE9BQU8sS0FBRyxPQUFPLEVBQUUsRUFBRTtJQUFDLEVBQUU7R0FBQyxHQUFFLEVBQUUsS0FBRyxTQUFTLEdBQUU7SUFBQyxPQUFPLEtBQUssTUFBSSxFQUFFLEVBQUUsQ0FBQztHQUFFLEdBQUUsRUFBRSxNQUFJLFNBQVMsR0FBRTtJQUFDLElBQUksSUFBRSxLQUFLLEtBQUksSUFBRSxFQUFFLENBQUM7SUFBRSxPQUFNLG1CQUFpQixJQUFFLEtBQUcsTUFBSSxJQUFFLFlBQVUsSUFBRSxFQUFFLElBQUUsRUFBRSxFQUFFLElBQUUsS0FBSyxHQUFHLElBQUcsS0FBRztHQUFDLEdBQUUsRUFBRSxNQUFJLFNBQVMsR0FBRSxHQUFFLEdBQUU7SUFBQyxJQUFJO0lBQUUsT0FBTyxJQUFFLElBQUUsSUFBRSxFQUFFLEVBQUUsQ0FBQyxLQUFHLEVBQUUsQ0FBQyxJQUFFLEVBQUUsTUFBSSxFQUFFLEdBQUUsSUFBSSxDQUFDLENBQUMsS0FBSSxFQUFFLEtBQUssTUFBSSxLQUFHLElBQUUsS0FBRyxJQUFHLElBQUk7R0FBQyxHQUFFLEVBQUUsV0FBUyxTQUFTLEdBQUUsR0FBRTtJQUFDLE9BQU8sS0FBSyxJQUFJLEdBQUUsR0FBRSxDQUFDLENBQUM7R0FBQyxHQUFFLEVBQUUsU0FBTyxTQUFTLEdBQUU7SUFBQyxJQUFJLElBQUUsS0FBSyxNQUFNO0lBQUUsT0FBTyxFQUFFLEtBQUcsR0FBRTtHQUFDLEdBQUUsRUFBRSxRQUFNLFdBQVU7SUFBQyxPQUFPLEVBQUUsS0FBSyxLQUFJLElBQUk7R0FBQyxHQUFFLEVBQUUsV0FBUyxTQUFTLEdBQUU7SUFBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLElBQUksS0FBSyxLQUFJLElBQUksQ0FBQyxDQUFDLE9BQU8sS0FBSyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztHQUFDLEdBQUUsRUFBRSxVQUFRLFdBQVU7SUFBQyxPQUFPLEtBQUssZUFBZTtHQUFDLEdBQUUsRUFBRSxlQUFhLFdBQVU7SUFBQyxPQUFPLEtBQUssSUFBSSxjQUFjO0dBQUMsR0FBRSxFQUFFLGlCQUFlLFdBQVU7SUFBQyxPQUFPLEtBQUssR0FBRyxjQUFjO0dBQUMsR0FBRSxFQUFFLFVBQVEsV0FBVTtJQUFDLE9BQU8sS0FBSyxJQUFJLFNBQVM7R0FBQyxHQUFFLEVBQUUsWUFBVSxXQUFVO0lBQUMsT0FBTyxLQUFLLEdBQUcsU0FBUztHQUFDLEdBQUUsRUFBRSxVQUFRLFdBQVU7SUFBQyxPQUFPLEtBQUssSUFBSSxTQUFTO0dBQUMsR0FBRSxFQUFFLFlBQVUsV0FBVTtJQUFDLE9BQU8sS0FBSyxHQUFHLFNBQVM7R0FBQyxHQUFFLEVBQUUsUUFBTSxXQUFVO0lBQUMsT0FBTyxLQUFLLElBQUksT0FBTztHQUFDLEdBQUUsRUFBRSxVQUFRLFdBQVU7SUFBQyxPQUFPLEtBQUssR0FBRyxPQUFPO0dBQUMsR0FBRSxFQUFFLE9BQUssV0FBVTtJQUFDLE9BQU8sS0FBSyxJQUFJLE1BQU07R0FBQyxHQUFFLEVBQUUsU0FBTyxXQUFVO0lBQUMsT0FBTyxLQUFLLEdBQUcsTUFBTTtHQUFDLEdBQUUsRUFBRSxRQUFNLFdBQVU7SUFBQyxPQUFPLEtBQUssSUFBSSxPQUFPO0dBQUMsR0FBRSxFQUFFLFVBQVEsV0FBVTtJQUFDLE9BQU8sS0FBSyxHQUFHLE9BQU87R0FBQyxHQUFFLEVBQUUsU0FBTyxXQUFVO0lBQUMsT0FBTyxLQUFLLElBQUksUUFBUTtHQUFDLEdBQUUsRUFBRSxXQUFTLFdBQVU7SUFBQyxPQUFPLEtBQUssR0FBRyxRQUFRO0dBQUMsR0FBRSxFQUFFLFFBQU0sV0FBVTtJQUFDLE9BQU8sS0FBSyxJQUFJLE9BQU87R0FBQyxHQUFFLEVBQUUsVUFBUSxXQUFVO0lBQUMsT0FBTyxLQUFLLEdBQUcsT0FBTztHQUFDLEdBQUU7RUFBQyxFQUFFLEdBQUUsSUFBRSxTQUFTLEdBQUUsR0FBRSxHQUFFO0dBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLElBQUUsR0FBRSxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsT0FBTyxJQUFFLEdBQUUsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLEtBQUssSUFBRSxHQUFFLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxNQUFNLElBQUUsR0FBRSxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsUUFBUSxJQUFFLEdBQUUsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLFFBQVEsSUFBRSxHQUFFLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxhQUFhLElBQUUsR0FBRSxJQUFJO0VBQUM7RUFBRSxPQUFPLFNBQVMsR0FBRSxHQUFFLEdBQUU7R0FBQyxJQUFFLEdBQUUsSUFBRSxFQUFFLENBQUMsQ0FBQyxPQUFPLEdBQUUsRUFBRSxXQUFTLFNBQVMsR0FBRSxHQUFFO0lBQWtCLE9BQU8sRUFBRSxHQUFFLEVBQUMsSUFBdkIsRUFBRSxPQUF3QixFQUFDLEdBQUUsQ0FBQztHQUFDLEdBQUUsRUFBRSxhQUFXO0dBQUUsSUFBSSxJQUFFLEVBQUUsVUFBVSxLQUFJLElBQUUsRUFBRSxVQUFVO0dBQVMsRUFBRSxVQUFVLE1BQUksU0FBUyxHQUFFLEdBQUU7SUFBQyxPQUFPLEVBQUUsQ0FBQyxJQUFFLEVBQUUsTUFBSyxHQUFFLENBQUMsSUFBRSxFQUFFLEtBQUssSUFBSSxDQUFDLENBQUMsR0FBRSxDQUFDO0dBQUMsR0FBRSxFQUFFLFVBQVUsV0FBUyxTQUFTLEdBQUUsR0FBRTtJQUFDLE9BQU8sRUFBRSxDQUFDLElBQUUsRUFBRSxNQUFLLEdBQUUsRUFBRSxJQUFFLEVBQUUsS0FBSyxJQUFJLENBQUMsQ0FBQyxHQUFFLENBQUM7R0FBQztFQUFDO0NBQUMsRUFBRSJ9