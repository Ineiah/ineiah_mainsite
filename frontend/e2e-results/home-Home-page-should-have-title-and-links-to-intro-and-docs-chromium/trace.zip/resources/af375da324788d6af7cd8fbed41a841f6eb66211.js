/**
* @vue/runtime-core v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
import { pauseTracking, resetTracking, isRef, toRaw, traverse, watch as watch$1, shallowRef, readonly, isReactive, ref, isShallow, isReadonly, shallowReadArray, toReadonly, toReactive, shallowReadonly, track, reactive, customRef, shallowReactive, trigger, ReactiveEffect, isProxy, proxyRefs, markRaw, EffectScope, computed as computed$1 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vue+reactivity@3.5.40/node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js?v=7e73afc2";
export { EffectScope, ReactiveEffect, TrackOpTypes, TriggerOpTypes, customRef, effect, effectScope, getCurrentScope, getCurrentWatcher, isProxy, isReactive, isReadonly, isRef, isShallow, markRaw, onScopeDispose, onWatcherCleanup, proxyRefs, reactive, readonly, ref, shallowReactive, shallowReadonly, shallowRef, stop, toRaw, toRef, toRefs, toValue, triggerRef, unref } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vue+reactivity@3.5.40/node_modules/@vue/reactivity/dist/reactivity.esm-bundler.js?v=7e73afc2";
import { isString, isFunction, EMPTY_OBJ, isPromise, isArray, NOOP, getGlobalThis, extend, isBuiltInDirective, NO, hasOwn, remove, def, isOn, isReservedProp, normalizeClass, stringifyStyle, normalizeStyle, isKnownSvgAttr, isBooleanAttr, isKnownHtmlAttr, includeBooleanAttr, isRenderableAttrValue, normalizeCssVarValue, getEscapedCssVarName, isObject, isRegExp, invokeArrayFns, toHandlerKey, camelize, capitalize, isSymbol, isGloballyAllowed, hyphenate, hasChanged, looseToNumber, isModelListener, looseEqual, EMPTY_ARR, toRawType, makeMap, toNumber } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vue+shared@3.5.40/node_modules/@vue/shared/dist/shared.esm-bundler.js?v=7e73afc2";
export { camelize, capitalize, normalizeClass, normalizeProps, normalizeStyle, toDisplayString, toHandlerKey } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vue+shared@3.5.40/node_modules/@vue/shared/dist/shared.esm-bundler.js?v=7e73afc2";
const stack = [];
function pushWarningContext(vnode) {
	stack.push(vnode);
}
function popWarningContext() {
	stack.pop();
}
let isWarning = false;
function warn$1(msg, ...args) {
	if (isWarning) return;
	isWarning = true;
	pauseTracking();
	const instance = stack.length ? stack[stack.length - 1].component : null;
	const appWarnHandler = instance && instance.appContext.config.warnHandler;
	const trace = getComponentTrace();
	if (appWarnHandler) {
		callWithErrorHandling(appWarnHandler, instance, 11, [
			msg + args.map((a) => {
				var _a, _b;
				return (_b = (_a = a.toString) == null ? void 0 : _a.call(a)) != null ? _b : JSON.stringify(a);
			}).join(""),
			instance && instance.proxy,
			trace.map(({ vnode }) => `at <${formatComponentName(instance, vnode.type)}>`).join("\n"),
			trace
		]);
	} else {
		const warnArgs = [`[Vue warn]: ${msg}`, ...args];
		if (trace.length && true) {
			warnArgs.push(`
`, ...formatTrace(trace));
		}
		console.warn(...warnArgs);
	}
	resetTracking();
	isWarning = false;
}
function getComponentTrace() {
	let currentVNode = stack[stack.length - 1];
	if (!currentVNode) {
		return [];
	}
	const normalizedStack = [];
	while (currentVNode) {
		const last = normalizedStack[0];
		if (last && last.vnode === currentVNode) {
			last.recurseCount++;
		} else {
			normalizedStack.push({
				vnode: currentVNode,
				recurseCount: 0
			});
		}
		const parentInstance = currentVNode.component && currentVNode.component.parent;
		currentVNode = parentInstance && parentInstance.vnode;
	}
	return normalizedStack;
}
function formatTrace(trace) {
	const logs = [];
	trace.forEach((entry, i) => {
		logs.push(...i === 0 ? [] : [`
`], ...formatTraceEntry(entry));
	});
	return logs;
}
function formatTraceEntry({ vnode, recurseCount }) {
	const postfix = recurseCount > 0 ? `... (${recurseCount} recursive calls)` : ``;
	const isRoot = vnode.component ? vnode.component.parent == null : false;
	const open = ` at <${formatComponentName(vnode.component, vnode.type, isRoot)}`;
	const close = `>` + postfix;
	return vnode.props ? [
		open,
		...formatProps(vnode.props),
		close
	] : [open + close];
}
function formatProps(props) {
	const res = [];
	const keys = Object.keys(props);
	keys.slice(0, 3).forEach((key) => {
		res.push(...formatProp(key, props[key]));
	});
	if (keys.length > 3) {
		res.push(` ...`);
	}
	return res;
}
function formatProp(key, value, raw) {
	if (isString(value)) {
		value = JSON.stringify(value);
		return raw ? value : [`${key}=${value}`];
	} else if (typeof value === "number" || typeof value === "boolean" || value == null) {
		return raw ? value : [`${key}=${value}`];
	} else if (isRef(value)) {
		value = formatProp(key, toRaw(value.value), true);
		return raw ? value : [
			`${key}=Ref<`,
			value,
			`>`
		];
	} else if (isFunction(value)) {
		return [`${key}=fn${value.name ? `<${value.name}>` : ``}`];
	} else {
		value = toRaw(value);
		return raw ? value : [`${key}=`, value];
	}
}
function assertNumber(val, type) {
	if (!!!("development" !== "production")) return;
	if (val === void 0) {
		return;
	} else if (typeof val !== "number") {
		warn$1(`${type} is not a valid number - got ${JSON.stringify(val)}.`);
	} else if (isNaN(val)) {
		warn$1(`${type} is NaN - the duration expression might be incorrect.`);
	}
}
const ErrorCodes = {
	"SETUP_FUNCTION": 0,
	"0": "SETUP_FUNCTION",
	"RENDER_FUNCTION": 1,
	"1": "RENDER_FUNCTION",
	"NATIVE_EVENT_HANDLER": 5,
	"5": "NATIVE_EVENT_HANDLER",
	"COMPONENT_EVENT_HANDLER": 6,
	"6": "COMPONENT_EVENT_HANDLER",
	"VNODE_HOOK": 7,
	"7": "VNODE_HOOK",
	"DIRECTIVE_HOOK": 8,
	"8": "DIRECTIVE_HOOK",
	"TRANSITION_HOOK": 9,
	"9": "TRANSITION_HOOK",
	"APP_ERROR_HANDLER": 10,
	"10": "APP_ERROR_HANDLER",
	"APP_WARN_HANDLER": 11,
	"11": "APP_WARN_HANDLER",
	"FUNCTION_REF": 12,
	"12": "FUNCTION_REF",
	"ASYNC_COMPONENT_LOADER": 13,
	"13": "ASYNC_COMPONENT_LOADER",
	"SCHEDULER": 14,
	"14": "SCHEDULER",
	"COMPONENT_UPDATE": 15,
	"15": "COMPONENT_UPDATE",
	"APP_UNMOUNT_CLEANUP": 16,
	"16": "APP_UNMOUNT_CLEANUP"
};
const ErrorTypeStrings$1 = {
	["sp"]: "serverPrefetch hook",
	["bc"]: "beforeCreate hook",
	["c"]: "created hook",
	["bm"]: "beforeMount hook",
	["m"]: "mounted hook",
	["bu"]: "beforeUpdate hook",
	["u"]: "updated",
	["bum"]: "beforeUnmount hook",
	["um"]: "unmounted hook",
	["a"]: "activated hook",
	["da"]: "deactivated hook",
	["ec"]: "errorCaptured hook",
	["rtc"]: "renderTracked hook",
	["rtg"]: "renderTriggered hook",
	[0]: "setup function",
	[1]: "render function",
	[2]: "watcher getter",
	[3]: "watcher callback",
	[4]: "watcher cleanup function",
	[5]: "native event handler",
	[6]: "component event handler",
	[7]: "vnode hook",
	[8]: "directive hook",
	[9]: "transition hook",
	[10]: "app errorHandler",
	[11]: "app warnHandler",
	[12]: "ref function",
	[13]: "async component loader",
	[14]: "scheduler flush",
	[15]: "component update",
	[16]: "app unmount cleanup function"
};
function callWithErrorHandling(fn, instance, type, args) {
	try {
		return args ? fn(...args) : fn();
	} catch (err) {
		handleError(err, instance, type);
	}
}
function callWithAsyncErrorHandling(fn, instance, type, args) {
	if (isFunction(fn)) {
		const res = callWithErrorHandling(fn, instance, type, args);
		if (res && isPromise(res)) {
			res.catch((err) => {
				handleError(err, instance, type);
			});
		}
		return res;
	}
	if (isArray(fn)) {
		const values = [];
		for (let i = 0; i < fn.length; i++) {
			values.push(callWithAsyncErrorHandling(fn[i], instance, type, args));
		}
		return values;
	} else if (!!("development" !== "production")) {
		warn$1(`Invalid value type passed to callWithAsyncErrorHandling(): ${typeof fn}`);
	}
}
function handleError(err, instance, type, throwInDev = true) {
	const contextVNode = instance ? instance.vnode : null;
	const { errorHandler, throwUnhandledErrorInProduction } = instance && instance.appContext.config || EMPTY_OBJ;
	if (instance) {
		let cur = instance.parent;
		const exposedInstance = instance.proxy;
		const errorInfo = !!("development" !== "production") ? ErrorTypeStrings$1[type] : `https://vuejs.org/error-reference/#runtime-${type}`;
		while (cur) {
			const errorCapturedHooks = cur.ec;
			if (errorCapturedHooks) {
				for (let i = 0; i < errorCapturedHooks.length; i++) {
					if (errorCapturedHooks[i](err, exposedInstance, errorInfo) === false) {
						return;
					}
				}
			}
			cur = cur.parent;
		}
		if (errorHandler) {
			pauseTracking();
			callWithErrorHandling(errorHandler, null, 10, [
				err,
				exposedInstance,
				errorInfo
			]);
			resetTracking();
			return;
		}
	}
	logError(err, type, contextVNode, throwInDev, throwUnhandledErrorInProduction);
}
function logError(err, type, contextVNode, throwInDev = true, throwInProd = false) {
	if (!!("development" !== "production")) {
		const info = ErrorTypeStrings$1[type];
		if (contextVNode) {
			pushWarningContext(contextVNode);
		}
		warn$1(`Unhandled error${info ? ` during execution of ${info}` : ``}`);
		if (contextVNode) {
			popWarningContext();
		}
		if (throwInDev) {
			throw err;
		} else {
			console.error(err);
		}
	} else if (throwInProd) {
		throw err;
	} else {
		console.error(err);
	}
}
const queue = [];
let flushIndex = -1;
const pendingPostFlushCbs = [];
let activePostFlushCbs = null;
let postFlushIndex = 0;
const resolvedPromise = /* @__PURE__ */ Promise.resolve();
let currentFlushPromise = null;
const RECURSION_LIMIT = 100;
function nextTick(fn) {
	const p = currentFlushPromise || resolvedPromise;
	return fn ? p.then(this ? fn.bind(this) : fn) : p;
}
function findInsertionIndex(id) {
	let start = flushIndex + 1;
	let end = queue.length;
	while (start < end) {
		const middle = start + end >>> 1;
		const middleJob = queue[middle];
		const middleJobId = getId(middleJob);
		if (middleJobId < id || middleJobId === id && middleJob.flags & 2) {
			start = middle + 1;
		} else {
			end = middle;
		}
	}
	return start;
}
function queueJob(job) {
	if (!(job.flags & 1)) {
		const jobId = getId(job);
		const lastJob = queue[queue.length - 1];
		if (!lastJob || !(job.flags & 2) && jobId >= getId(lastJob)) {
			queue.push(job);
		} else {
			queue.splice(findInsertionIndex(jobId), 0, job);
		}
		job.flags |= 1;
		queueFlush();
	}
}
function queueFlush() {
	if (!currentFlushPromise) {
		currentFlushPromise = resolvedPromise.then(flushJobs);
	}
}
function queuePostFlushCb(cb) {
	if (!isArray(cb)) {
		if (activePostFlushCbs && cb.id === -1) {
			activePostFlushCbs.splice(postFlushIndex + 1, 0, cb);
		} else if (!(cb.flags & 1)) {
			pendingPostFlushCbs.push(cb);
			cb.flags |= 1;
		}
	} else {
		pendingPostFlushCbs.push(...cb);
	}
	queueFlush();
}
function flushPreFlushCbs(instance, seen, i = flushIndex + 1) {
	if (!!("development" !== "production")) {
		seen = seen || /* @__PURE__ */ new Map();
	}
	for (; i < queue.length; i++) {
		const cb = queue[i];
		if (cb && cb.flags & 2) {
			if (instance && cb.id !== instance.uid) {
				continue;
			}
			if (!!("development" !== "production") && checkRecursiveUpdates(seen, cb)) {
				continue;
			}
			queue.splice(i, 1);
			i--;
			if (cb.flags & 4) {
				cb.flags &= -2;
			}
			cb();
			if (!(cb.flags & 4)) {
				cb.flags &= -2;
			}
		}
	}
}
function flushPostFlushCbs(seen) {
	if (pendingPostFlushCbs.length) {
		const deduped = [...new Set(pendingPostFlushCbs)].sort((a, b) => getId(a) - getId(b));
		pendingPostFlushCbs.length = 0;
		if (activePostFlushCbs) {
			activePostFlushCbs.push(...deduped);
			return;
		}
		activePostFlushCbs = deduped;
		if (!!("development" !== "production")) {
			seen = seen || /* @__PURE__ */ new Map();
		}
		for (postFlushIndex = 0; postFlushIndex < activePostFlushCbs.length; postFlushIndex++) {
			const cb = activePostFlushCbs[postFlushIndex];
			if (!!("development" !== "production") && checkRecursiveUpdates(seen, cb)) {
				continue;
			}
			if (cb.flags & 4) {
				cb.flags &= -2;
			}
			if (!(cb.flags & 8)) cb();
			cb.flags &= -2;
		}
		activePostFlushCbs = null;
		postFlushIndex = 0;
	}
}
const getId = (job) => job.id == null ? job.flags & 2 ? -1 : Infinity : job.id;
function flushJobs(seen) {
	if (!!("development" !== "production")) {
		seen = seen || /* @__PURE__ */ new Map();
	}
	const check = !!("development" !== "production") ? (job) => checkRecursiveUpdates(seen, job) : NOOP;
	try {
		for (flushIndex = 0; flushIndex < queue.length; flushIndex++) {
			const job = queue[flushIndex];
			if (job && !(job.flags & 8)) {
				if (!!("development" !== "production") && check(job)) {
					continue;
				}
				if (job.flags & 4) {
					job.flags &= ~1;
				}
				callWithErrorHandling(job, job.i, job.i ? 15 : 14);
				if (!(job.flags & 4)) {
					job.flags &= ~1;
				}
			}
		}
	} finally {
		for (; flushIndex < queue.length; flushIndex++) {
			const job = queue[flushIndex];
			if (job) {
				job.flags &= -2;
			}
		}
		flushIndex = -1;
		queue.length = 0;
		flushPostFlushCbs(seen);
		currentFlushPromise = null;
		if (queue.length || pendingPostFlushCbs.length) {
			flushJobs(seen);
		}
	}
}
function checkRecursiveUpdates(seen, fn) {
	const count = seen.get(fn) || 0;
	if (count > RECURSION_LIMIT) {
		const instance = fn.i;
		const componentName = instance && getComponentName(instance.type);
		handleError(`Maximum recursive updates exceeded${componentName ? ` in component <${componentName}>` : ``}. This means you have a reactive effect that is mutating its own dependencies and thus recursively triggering itself. Possible sources include component template, render function, updated hook or watcher source function.`, null, 10);
		return true;
	}
	seen.set(fn, count + 1);
	return false;
}
let isHmrUpdating = false;
const setHmrUpdating = (v) => {
	try {
		return isHmrUpdating;
	} finally {
		isHmrUpdating = v;
	}
};
const hmrDirtyComponents = /* @__PURE__ */ new Map();
if (!!("development" !== "production")) {
	getGlobalThis().__VUE_HMR_RUNTIME__ = {
		createRecord: tryWrap(createRecord),
		rerender: tryWrap(rerender),
		reload: tryWrap(reload)
	};
}
const map = /* @__PURE__ */ new Map();
function registerHMR(instance) {
	const id = instance.type.__hmrId;
	let record = map.get(id);
	if (!record) {
		createRecord(id, instance.type);
		record = map.get(id);
	}
	record.instances.add(instance);
}
function unregisterHMR(instance) {
	map.get(instance.type.__hmrId).instances.delete(instance);
}
function createRecord(id, initialDef) {
	if (map.has(id)) {
		return false;
	}
	map.set(id, {
		initialDef: normalizeClassComponent(initialDef),
		instances: /* @__PURE__ */ new Set()
	});
	return true;
}
function normalizeClassComponent(component) {
	return isClassComponent(component) ? component.__vccOpts : component;
}
function rerender(id, newRender) {
	const record = map.get(id);
	if (!record) {
		return;
	}
	record.initialDef.render = newRender;
	[...record.instances].forEach((instance) => {
		if (newRender) {
			instance.render = newRender;
			normalizeClassComponent(instance.type).render = newRender;
		}
		instance.renderCache = [];
		isHmrUpdating = true;
		if (!(instance.job.flags & 8)) {
			instance.update();
		}
		isHmrUpdating = false;
	});
}
function reload(id, newComp) {
	const record = map.get(id);
	if (!record) return;
	newComp = normalizeClassComponent(newComp);
	updateComponentDef(record.initialDef, newComp);
	const instances = [...record.instances];
	for (let i = 0; i < instances.length; i++) {
		const instance = instances[i];
		const oldComp = normalizeClassComponent(instance.type);
		let dirtyInstances = hmrDirtyComponents.get(oldComp);
		if (!dirtyInstances) {
			if (oldComp !== record.initialDef) {
				updateComponentDef(oldComp, newComp);
			}
			hmrDirtyComponents.set(oldComp, dirtyInstances = /* @__PURE__ */ new Set());
		}
		dirtyInstances.add(instance);
		instance.appContext.propsCache.delete(instance.type);
		instance.appContext.emitsCache.delete(instance.type);
		instance.appContext.optionsCache.delete(instance.type);
		if (instance.ceReload) {
			dirtyInstances.add(instance);
			instance.ceReload(newComp.styles);
			dirtyInstances.delete(instance);
		} else if (instance.parent) {
			queueJob(() => {
				if (!(instance.job.flags & 8)) {
					isHmrUpdating = true;
					instance.parent.update();
					isHmrUpdating = false;
					dirtyInstances.delete(instance);
				}
			});
		} else if (instance.appContext.reload) {
			instance.appContext.reload();
		} else if (typeof window !== "undefined") {
			window.location.reload();
		} else {
			console.warn("[HMR] Root or manually mounted instance modified. Full reload required.");
		}
		if (instance.root.ce && instance !== instance.root) {
			instance.root.ce._removeChildStyle(oldComp);
		}
	}
	queuePostFlushCb(() => {
		hmrDirtyComponents.clear();
	});
}
function updateComponentDef(oldComp, newComp) {
	extend(oldComp, newComp);
	for (const key in oldComp) {
		if (key !== "__file" && !(key in newComp)) {
			delete oldComp[key];
		}
	}
}
function tryWrap(fn) {
	return (id, arg) => {
		try {
			return fn(id, arg);
		} catch (e) {
			console.error(e);
			console.warn(`[HMR] Something went wrong during Vue component hot-reload. Full reload required.`);
		}
	};
}
let devtools$1;
let buffer = [];
let devtoolsNotInstalled = false;
function emit$1(event, ...args) {
	if (devtools$1) {
		devtools$1.emit(event, ...args);
	} else if (!devtoolsNotInstalled) {
		buffer.push({
			event,
			args
		});
	}
}
function setDevtoolsHook$1(hook, target) {
	var _a, _b;
	devtools$1 = hook;
	if (devtools$1) {
		devtools$1.enabled = true;
		buffer.forEach(({ event, args }) => devtools$1.emit(event, ...args));
		buffer = [];
	} else if (typeof window !== "undefined" && window.HTMLElement && !((_b = (_a = window.navigator) == null ? void 0 : _a.userAgent) == null ? void 0 : _b.includes("jsdom"))) {
		const replay = target.__VUE_DEVTOOLS_HOOK_REPLAY__ = target.__VUE_DEVTOOLS_HOOK_REPLAY__ || [];
		replay.push((newHook) => {
			setDevtoolsHook$1(newHook, target);
		});
		setTimeout(() => {
			if (!devtools$1) {
				target.__VUE_DEVTOOLS_HOOK_REPLAY__ = null;
				devtoolsNotInstalled = true;
				buffer = [];
			}
		}, 3e3);
	} else {
		devtoolsNotInstalled = true;
		buffer = [];
	}
}
function devtoolsInitApp(app, version) {
	emit$1("app:init", app, version, {
		Fragment,
		Text,
		Comment,
		Static
	});
}
function devtoolsUnmountApp(app) {
	emit$1("app:unmount", app);
}
const devtoolsComponentAdded = /* @__PURE__ */ createDevtoolsComponentHook(
	"component:added"
	/* COMPONENT_ADDED */
);
const devtoolsComponentUpdated = /* @__PURE__ */ createDevtoolsComponentHook(
	"component:updated"
	/* COMPONENT_UPDATED */
);
const _devtoolsComponentRemoved = /* @__PURE__ */ createDevtoolsComponentHook("component:removed");
const devtoolsComponentRemoved = (component) => {
	if (devtools$1 && typeof devtools$1.cleanupBuffer === "function" && !devtools$1.cleanupBuffer(component)) {
		_devtoolsComponentRemoved(component);
	}
};
// @__NO_SIDE_EFFECTS__
function createDevtoolsComponentHook(hook) {
	return (component) => {
		emit$1(hook, component.appContext.app, component.uid, component.parent ? component.parent.uid : void 0, component);
	};
}
const devtoolsPerfStart = /* @__PURE__ */ createDevtoolsPerformanceHook(
	"perf:start"
	/* PERFORMANCE_START */
);
const devtoolsPerfEnd = /* @__PURE__ */ createDevtoolsPerformanceHook(
	"perf:end"
	/* PERFORMANCE_END */
);
function createDevtoolsPerformanceHook(hook) {
	return (component, type, time) => {
		emit$1(hook, component.appContext.app, component.uid, component, type, time);
	};
}
function devtoolsComponentEmit(component, event, params) {
	emit$1("component:emit", component.appContext.app, component, event, params);
}
let currentRenderingInstance = null;
let currentScopeId = null;
function setCurrentRenderingInstance(instance) {
	const prev = currentRenderingInstance;
	currentRenderingInstance = instance;
	currentScopeId = instance && instance.type.__scopeId || null;
	return prev;
}
function pushScopeId(id) {
	currentScopeId = id;
}
function popScopeId() {
	currentScopeId = null;
}
const withScopeId = (_id) => withCtx;
function withCtx(fn, ctx = currentRenderingInstance, isNonScopedSlot) {
	if (!ctx) return fn;
	if (fn._n) {
		return fn;
	}
	const renderFnWithContext = (...args) => {
		if (renderFnWithContext._d) {
			setBlockTracking(-1);
		}
		const prevInstance = setCurrentRenderingInstance(ctx);
		const prevStackSize = blockStack.length;
		let res;
		try {
			res = fn(...args);
		} finally {
			for (let i = blockStack.length; i > prevStackSize; i--) closeBlock();
			setCurrentRenderingInstance(prevInstance);
			if (renderFnWithContext._d) {
				setBlockTracking(1);
			}
		}
		if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
			devtoolsComponentUpdated(ctx);
		}
		return res;
	};
	renderFnWithContext._n = true;
	renderFnWithContext._c = true;
	renderFnWithContext._d = true;
	return renderFnWithContext;
}
function validateDirectiveName(name) {
	if (isBuiltInDirective(name)) {
		warn$1("Do not use built-in directive ids as custom directive id: " + name);
	}
}
function withDirectives(vnode, directives) {
	if (currentRenderingInstance === null) {
		!!("development" !== "production") && warn$1(`withDirectives can only be used inside render functions.`);
		return vnode;
	}
	const instance = getComponentPublicInstance(currentRenderingInstance);
	const bindings = vnode.dirs || (vnode.dirs = []);
	for (let i = 0; i < directives.length; i++) {
		let [dir, value, arg, modifiers = EMPTY_OBJ] = directives[i];
		if (dir) {
			if (isFunction(dir)) {
				dir = {
					mounted: dir,
					updated: dir
				};
			}
			if (dir.deep) {
				traverse(value);
			}
			bindings.push({
				dir,
				instance,
				value,
				oldValue: void 0,
				arg,
				modifiers
			});
		}
	}
	return vnode;
}
function invokeDirectiveHook(vnode, prevVNode, instance, name) {
	const bindings = vnode.dirs;
	const oldBindings = prevVNode && prevVNode.dirs;
	for (let i = 0; i < bindings.length; i++) {
		const binding = bindings[i];
		if (oldBindings) {
			binding.oldValue = oldBindings[i].value;
		}
		let hook = binding.dir[name];
		if (hook) {
			pauseTracking();
			callWithAsyncErrorHandling(hook, instance, 8, [
				vnode.el,
				binding,
				vnode,
				prevVNode
			]);
			resetTracking();
		}
	}
}
function provide(key, value) {
	if (!!("development" !== "production")) {
		if (!currentInstance || currentInstance.isMounted) {
			warn$1(`provide() can only be used inside setup().`);
		}
	}
	if (currentInstance) {
		let provides = currentInstance.provides;
		const parentProvides = currentInstance.parent && currentInstance.parent.provides;
		if (parentProvides === provides) {
			provides = currentInstance.provides = Object.create(parentProvides);
		}
		provides[key] = value;
	}
}
function inject(key, defaultValue, treatDefaultAsFactory = false) {
	const instance = getCurrentInstance();
	if (instance || currentApp) {
		let provides = currentApp ? currentApp._context.provides : instance ? instance.parent == null || instance.ce ? instance.vnode.appContext && instance.vnode.appContext.provides : instance.parent.provides : void 0;
		if (provides && key in provides) {
			return provides[key];
		} else if (arguments.length > 1) {
			return treatDefaultAsFactory && isFunction(defaultValue) ? defaultValue.call(instance && instance.proxy) : defaultValue;
		} else if (!!("development" !== "production")) {
			warn$1(`injection "${String(key)}" not found.`);
		}
	} else if (!!("development" !== "production")) {
		warn$1(`inject() can only be used inside setup() or functional components.`);
	}
}
function hasInjectionContext() {
	return !!(getCurrentInstance() || currentApp);
}
const ssrContextKey = /* @__PURE__ */ Symbol.for("v-scx");
const useSSRContext = () => {
	{
		const ctx = inject(ssrContextKey);
		if (!ctx) {
			!!("development" !== "production") && warn$1(`Server rendering context not provided. Make sure to only call useSSRContext() conditionally in the server build.`);
		}
		return ctx;
	}
};
function watchEffect(effect, options) {
	return doWatch(effect, null, options);
}
function watchPostEffect(effect, options) {
	return doWatch(effect, null, !!("development" !== "production") ? extend({}, options, { flush: "post" }) : { flush: "post" });
}
function watchSyncEffect(effect, options) {
	return doWatch(effect, null, !!("development" !== "production") ? extend({}, options, { flush: "sync" }) : { flush: "sync" });
}
function watch(source, cb, options) {
	if (!!("development" !== "production") && !isFunction(cb)) {
		warn$1(`\`watch(fn, options?)\` signature has been moved to a separate API. Use \`watchEffect(fn, options?)\` instead. \`watch\` now only supports \`watch(source, cb, options?) signature.`);
	}
	return doWatch(source, cb, options);
}
function doWatch(source, cb, options = EMPTY_OBJ) {
	const { immediate, deep, flush, once } = options;
	if (!!("development" !== "production") && !cb) {
		if (immediate !== void 0) {
			warn$1(`watch() "immediate" option is only respected when using the watch(source, callback, options?) signature.`);
		}
		if (deep !== void 0) {
			warn$1(`watch() "deep" option is only respected when using the watch(source, callback, options?) signature.`);
		}
		if (once !== void 0) {
			warn$1(`watch() "once" option is only respected when using the watch(source, callback, options?) signature.`);
		}
	}
	const baseWatchOptions = extend({}, options);
	if (!!("development" !== "production")) baseWatchOptions.onWarn = warn$1;
	const runsImmediately = cb && immediate || !cb && flush !== "post";
	let ssrCleanup;
	if (isInSSRComponentSetup) {
		if (flush === "sync") {
			const ctx = useSSRContext();
			ssrCleanup = ctx.__watcherHandles || (ctx.__watcherHandles = []);
		} else if (!runsImmediately) {
			const watchStopHandle = () => {};
			watchStopHandle.stop = NOOP;
			watchStopHandle.resume = NOOP;
			watchStopHandle.pause = NOOP;
			return watchStopHandle;
		}
	}
	const instance = currentInstance;
	baseWatchOptions.call = (fn, type, args) => callWithAsyncErrorHandling(fn, instance, type, args);
	let isPre = false;
	if (flush === "post") {
		baseWatchOptions.scheduler = (job) => {
			queuePostRenderEffect(job, instance && instance.suspense);
		};
	} else if (flush !== "sync") {
		isPre = true;
		baseWatchOptions.scheduler = (job, isFirstRun) => {
			if (isFirstRun) {
				job();
			} else {
				queueJob(job);
			}
		};
	}
	baseWatchOptions.augmentJob = (job) => {
		if (cb) {
			job.flags |= 4;
		}
		if (isPre) {
			job.flags |= 2;
			if (instance) {
				job.id = instance.uid;
				job.i = instance;
			}
		}
	};
	const watchHandle = watch$1(source, cb, baseWatchOptions);
	if (isInSSRComponentSetup) {
		if (ssrCleanup) {
			ssrCleanup.push(watchHandle);
		} else if (runsImmediately) {
			watchHandle();
		}
	}
	return watchHandle;
}
function instanceWatch(source, value, options) {
	const publicThis = this.proxy;
	const getter = isString(source) ? source.includes(".") ? createPathGetter(publicThis, source) : () => publicThis[source] : source.bind(publicThis, publicThis);
	let cb;
	if (isFunction(value)) {
		cb = value;
	} else {
		cb = value.handler;
		options = value;
	}
	const reset = setCurrentInstance(this);
	const res = doWatch(getter, cb.bind(publicThis), options);
	reset();
	return res;
}
function createPathGetter(ctx, path) {
	const segments = path.split(".");
	return () => {
		let cur = ctx;
		for (let i = 0; i < segments.length && cur; i++) {
			cur = cur[segments[i]];
		}
		return cur;
	};
}
const pendingMounts = /* @__PURE__ */ new WeakMap();
const TeleportEndKey = /* @__PURE__ */ Symbol("_vte");
const isTeleport = (type) => type.__isTeleport;
const isTeleportDisabled = (props) => props && (props.disabled || props.disabled === "");
const isTeleportDeferred = (props) => props && (props.defer || props.defer === "");
const isTargetSVG = (target) => typeof SVGElement !== "undefined" && target instanceof SVGElement;
const isTargetMathML = (target) => typeof MathMLElement === "function" && target instanceof MathMLElement;
const resolveTarget = (props, select) => {
	const targetSelector = props && props.to;
	if (isString(targetSelector)) {
		if (!select) {
			!!("development" !== "production") && warn$1(`Current renderer does not support string target for Teleports. (missing querySelector renderer option)`);
			return null;
		} else {
			const target = select(targetSelector);
			if (!!("development" !== "production") && !target && !isTeleportDisabled(props)) {
				warn$1(`Failed to locate Teleport target with selector "${targetSelector}". Note the target element must exist before the component is mounted - i.e. the target cannot be rendered by the component itself, and ideally should be outside of the entire Vue component tree.`);
			}
			return target;
		}
	} else {
		if (!!("development" !== "production") && !targetSelector && !isTeleportDisabled(props)) {
			warn$1(`Invalid Teleport target: ${targetSelector}`);
		}
		return targetSelector;
	}
};
const TeleportImpl = {
	name: "Teleport",
	__isTeleport: true,
	process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, internals) {
		const { mc: mountChildren, pc: patchChildren, pbc: patchBlockChildren, o: { insert, querySelector, createText, createComment, parentNode } } = internals;
		const disabled = isTeleportDisabled(n2.props);
		let { dynamicChildren } = n2;
		if (!!("development" !== "production") && isHmrUpdating) {
			optimized = false;
			dynamicChildren = null;
		}
		const mount = (vnode, container2, anchor2) => {
			if (vnode.shapeFlag & 16) {
				mountChildren(vnode.children, container2, anchor2, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			}
		};
		const mountToTarget = (vnode = n2) => {
			const disabled2 = isTeleportDisabled(vnode.props);
			const target = vnode.target = resolveTarget(vnode.props, querySelector);
			const targetAnchor = prepareAnchor(target, vnode, createText, insert);
			if (target) {
				if (namespace !== "svg" && isTargetSVG(target)) {
					namespace = "svg";
				} else if (namespace !== "mathml" && isTargetMathML(target)) {
					namespace = "mathml";
				}
				if (parentComponent && parentComponent.isCE) {
					(parentComponent.ce._teleportTargets || (parentComponent.ce._teleportTargets = /* @__PURE__ */ new Set())).add(target);
				}
				if (!disabled2) {
					mount(vnode, target, targetAnchor);
					updateCssVars(vnode, false);
				}
			} else if (!!("development" !== "production") && !disabled2) {
				warn$1("Invalid Teleport target on mount:", target, `(${typeof target})`);
			}
		};
		const queuePendingMount = (vnode) => {
			const mountJob = () => {
				if (pendingMounts.get(vnode) !== mountJob) return;
				pendingMounts.delete(vnode);
				if (isTeleportDisabled(vnode.props)) {
					const mountContainer = parentNode(vnode.el) || container;
					mount(vnode, mountContainer, vnode.anchor);
					updateCssVars(vnode, true);
				}
				mountToTarget(vnode);
			};
			pendingMounts.set(vnode, mountJob);
			queuePostRenderEffect(mountJob, parentSuspense);
		};
		if (n1 == null) {
			const placeholder = n2.el = !!("development" !== "production") ? createComment("teleport start") : createText("");
			const mainAnchor = n2.anchor = !!("development" !== "production") ? createComment("teleport end") : createText("");
			insert(placeholder, container, anchor);
			insert(mainAnchor, container, anchor);
			if (isTeleportDeferred(n2.props) || parentSuspense && parentSuspense.pendingBranch) {
				queuePendingMount(n2);
				return;
			}
			if (disabled) {
				mount(n2, container, mainAnchor);
				updateCssVars(n2, true);
			}
			mountToTarget();
		} else {
			n2.el = n1.el;
			const mainAnchor = n2.anchor = n1.anchor;
			const pendingMount = pendingMounts.get(n1);
			if (pendingMount) {
				pendingMount.flags |= 8;
				pendingMounts.delete(n1);
				queuePendingMount(n2);
				return;
			}
			n2.targetStart = n1.targetStart;
			const target = n2.target = n1.target;
			const targetAnchor = n2.targetAnchor = n1.targetAnchor;
			const wasDisabled = isTeleportDisabled(n1.props);
			const currentContainer = wasDisabled ? container : target;
			const currentAnchor = wasDisabled ? mainAnchor : targetAnchor;
			if (namespace === "svg" || isTargetSVG(target)) {
				namespace = "svg";
			} else if (namespace === "mathml" || isTargetMathML(target)) {
				namespace = "mathml";
			}
			if (dynamicChildren) {
				patchBlockChildren(n1.dynamicChildren, dynamicChildren, currentContainer, parentComponent, parentSuspense, namespace, slotScopeIds);
				traverseStaticChildren(n1, n2, !!!("development" !== "production"));
			} else if (!optimized) {
				patchChildren(n1, n2, currentContainer, currentAnchor, parentComponent, parentSuspense, namespace, slotScopeIds, false);
			}
			if (disabled) {
				if (!wasDisabled) {
					moveTeleport(n2, container, mainAnchor, internals, 1);
				} else {
					if (n2.props && n1.props && n2.props.to !== n1.props.to) {
						n2.props.to = n1.props.to;
					}
				}
			} else {
				if ((n2.props && n2.props.to) !== (n1.props && n1.props.to)) {
					const nextTarget = resolveTarget(n2.props, querySelector);
					if (nextTarget) {
						n2.target = nextTarget;
						moveTeleport(n2, nextTarget, null, internals, 0);
					} else if (!!("development" !== "production")) {
						warn$1("Invalid Teleport target on update:", target, `(${typeof target})`);
					}
				} else if (wasDisabled) {
					moveTeleport(n2, target, targetAnchor, internals, 1);
				}
			}
			updateCssVars(n2, disabled);
		}
	},
	remove(vnode, parentComponent, parentSuspense, { um: unmount, o: { remove: hostRemove } }, doRemove) {
		const { shapeFlag, children, anchor, targetStart, targetAnchor, target, props } = vnode;
		const disabled = isTeleportDisabled(props);
		const shouldRemove = doRemove || !disabled;
		const pendingMount = pendingMounts.get(vnode);
		if (pendingMount) {
			pendingMount.flags |= 8;
			pendingMounts.delete(vnode);
		}
		if (target) {
			hostRemove(targetStart);
			hostRemove(targetAnchor);
		}
		doRemove && hostRemove(anchor);
		if (!pendingMount && (disabled || target) && shapeFlag & 16) {
			for (let i = 0; i < children.length; i++) {
				const child = children[i];
				unmount(child, parentComponent, parentSuspense, shouldRemove, !!child.dynamicChildren);
			}
		}
	},
	move: moveTeleport,
	hydrate: hydrateTeleport
};
function moveTeleport(vnode, container, parentAnchor, { o: { insert }, m: move }, moveType = 2) {
	if (moveType === 0) {
		insert(vnode.targetAnchor, container, parentAnchor);
	}
	const { el, anchor, shapeFlag, children, props } = vnode;
	const isReorder = moveType === 2;
	if (isReorder) {
		insert(el, container, parentAnchor);
	}
	if (!pendingMounts.has(vnode) && (!isReorder || isTeleportDisabled(props))) {
		if (shapeFlag & 16) {
			for (let i = 0; i < children.length; i++) {
				move(children[i], container, parentAnchor, 2);
			}
		}
	}
	if (isReorder) {
		insert(anchor, container, parentAnchor);
	}
}
function hydrateTeleport(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized, { o: { nextSibling, parentNode, querySelector, insert, createText } }, hydrateChildren) {
	function hydrateAnchor(target2, targetNode) {
		let targetAnchor = targetNode;
		while (targetAnchor) {
			if (targetAnchor && targetAnchor.nodeType === 8) {
				if (targetAnchor.data === "teleport start anchor") {
					vnode.targetStart = targetAnchor;
				} else if (targetAnchor.data === "teleport anchor") {
					vnode.targetAnchor = targetAnchor;
					target2._lpa = vnode.targetAnchor && nextSibling(vnode.targetAnchor);
					break;
				}
			}
			targetAnchor = nextSibling(targetAnchor);
		}
	}
	function hydrateDisabledTeleport(node2, vnode2) {
		vnode2.anchor = hydrateChildren(nextSibling(node2), vnode2, parentNode(node2), parentComponent, parentSuspense, slotScopeIds, optimized);
	}
	const target = vnode.target = resolveTarget(vnode.props, querySelector);
	const disabled = isTeleportDisabled(vnode.props);
	if (target) {
		const targetNode = target._lpa || target.firstChild;
		if (vnode.shapeFlag & 16) {
			if (disabled) {
				hydrateDisabledTeleport(node, vnode);
				hydrateAnchor(target, targetNode);
				if (!vnode.targetAnchor) {
					prepareAnchor(
						target,
						vnode,
						createText,
						insert,
						// if target is the same as the main view, insert anchors before current node
						// to avoid hydrating mismatch
						parentNode(node) === target ? node : null
					);
				}
			} else {
				vnode.anchor = nextSibling(node);
				hydrateAnchor(target, targetNode);
				if (!vnode.targetAnchor) {
					prepareAnchor(target, vnode, createText, insert);
				}
				hydrateChildren(targetNode && nextSibling(targetNode), vnode, target, parentComponent, parentSuspense, slotScopeIds, optimized);
			}
		}
		updateCssVars(vnode, disabled);
	} else if (disabled) {
		if (vnode.shapeFlag & 16) {
			hydrateDisabledTeleport(node, vnode);
			vnode.targetStart = node;
			vnode.targetAnchor = nextSibling(node);
		}
	}
	return vnode.anchor && nextSibling(vnode.anchor);
}
const Teleport = TeleportImpl;
function updateCssVars(vnode, isDisabled) {
	const ctx = vnode.ctx;
	if (ctx && ctx.ut) {
		let node, anchor;
		if (isDisabled) {
			node = vnode.el;
			anchor = vnode.anchor;
		} else {
			node = vnode.targetStart;
			anchor = vnode.targetAnchor;
		}
		while (node && node !== anchor) {
			if (node.nodeType === 1) node.setAttribute("data-v-owner", ctx.uid);
			node = node.nextSibling;
		}
		ctx.ut();
	}
}
function prepareAnchor(target, vnode, createText, insert, anchor = null) {
	const targetStart = vnode.targetStart = createText("");
	const targetAnchor = vnode.targetAnchor = createText("");
	targetStart[TeleportEndKey] = targetAnchor;
	if (target) {
		insert(targetStart, target, anchor);
		insert(targetAnchor, target, anchor);
	}
	return targetAnchor;
}
const leaveCbKey = /* @__PURE__ */ Symbol("_leaveCb");
const enterCbKey = /* @__PURE__ */ Symbol("_enterCb");
function useTransitionState() {
	const state = {
		isMounted: false,
		isLeaving: false,
		isUnmounting: false,
		leavingVNodes: /* @__PURE__ */ new Map()
	};
	onMounted(() => {
		state.isMounted = true;
	});
	onBeforeUnmount(() => {
		state.isUnmounting = true;
	});
	return state;
}
const TransitionHookValidator = [Function, Array];
const BaseTransitionPropsValidators = {
	mode: String,
	appear: Boolean,
	persisted: Boolean,
	// enter
	onBeforeEnter: TransitionHookValidator,
	onEnter: TransitionHookValidator,
	onAfterEnter: TransitionHookValidator,
	onEnterCancelled: TransitionHookValidator,
	// leave
	onBeforeLeave: TransitionHookValidator,
	onLeave: TransitionHookValidator,
	onAfterLeave: TransitionHookValidator,
	onLeaveCancelled: TransitionHookValidator,
	// appear
	onBeforeAppear: TransitionHookValidator,
	onAppear: TransitionHookValidator,
	onAfterAppear: TransitionHookValidator,
	onAppearCancelled: TransitionHookValidator
};
const recursiveGetSubtree = (instance) => {
	const subTree = instance.subTree;
	return subTree.component ? recursiveGetSubtree(subTree.component) : subTree;
};
const BaseTransitionImpl = {
	name: `BaseTransition`,
	props: BaseTransitionPropsValidators,
	setup(props, { slots }) {
		const instance = getCurrentInstance();
		const state = useTransitionState();
		return () => {
			const children = slots.default && getTransitionRawChildren(slots.default(), true);
			const child = children && children.length ? findNonCommentChild(children) : 
			// Keep explicit default-slot conditionals on the same transition path
			// as regular v-if branches, which render a comment placeholder.
			instance.subTree ? createCommentVNode() : void 0;
			if (!child) {
				return;
			}
			const rawProps = toRaw(props);
			const { mode } = rawProps;
			if (!!("development" !== "production") && mode && mode !== "in-out" && mode !== "out-in" && mode !== "default") {
				warn$1(`invalid <transition> mode: ${mode}`);
			}
			if (state.isLeaving) {
				return emptyPlaceholder(child);
			}
			const innerChild = getInnerChild$1(child);
			if (!innerChild) {
				return emptyPlaceholder(child);
			}
			let enterHooks = resolveTransitionHooks(
				innerChild,
				rawProps,
				state,
				instance,
				// #11061, ensure enterHooks is fresh after clone
				(hooks) => enterHooks = hooks
			);
			if (innerChild.type !== Comment) {
				setTransitionHooks(innerChild, enterHooks);
			}
			let oldInnerChild = instance.subTree && getInnerChild$1(instance.subTree);
			if (oldInnerChild && oldInnerChild.type !== Comment && !isSameVNodeType(oldInnerChild, innerChild) && recursiveGetSubtree(instance).type !== Comment) {
				let leavingHooks = resolveTransitionHooks(oldInnerChild, rawProps, state, instance);
				setTransitionHooks(oldInnerChild, leavingHooks);
				if (mode === "out-in" && innerChild.type !== Comment) {
					state.isLeaving = true;
					leavingHooks.afterLeave = () => {
						state.isLeaving = false;
						if (!(instance.job.flags & 8)) {
							instance.update();
						}
						delete leavingHooks.afterLeave;
						oldInnerChild = void 0;
					};
					return emptyPlaceholder(child);
				} else if (mode === "in-out" && innerChild.type !== Comment) {
					leavingHooks.delayLeave = (el, earlyRemove, delayedLeave) => {
						const leavingVNodesCache = getLeavingNodesForType(state, oldInnerChild);
						leavingVNodesCache[String(oldInnerChild.key)] = oldInnerChild;
						el[leaveCbKey] = () => {
							earlyRemove();
							el[leaveCbKey] = void 0;
							delete enterHooks.delayedLeave;
							oldInnerChild = void 0;
						};
						enterHooks.delayedLeave = () => {
							delayedLeave();
							delete enterHooks.delayedLeave;
							oldInnerChild = void 0;
						};
					};
				} else {
					oldInnerChild = void 0;
				}
			} else if (oldInnerChild) {
				oldInnerChild = void 0;
			}
			return child;
		};
	}
};
function findNonCommentChild(children) {
	let child = children[0];
	if (children.length > 1) {
		let hasFound = false;
		for (const c of children) {
			if (c.type !== Comment) {
				if (!!("development" !== "production") && hasFound) {
					warn$1("<transition> can only be used on a single element or component. Use <transition-group> for lists.");
					break;
				}
				child = c;
				hasFound = true;
				if (!!!("development" !== "production")) break;
			}
		}
	}
	return child;
}
const BaseTransition = BaseTransitionImpl;
function getLeavingNodesForType(state, vnode) {
	const { leavingVNodes } = state;
	let leavingVNodesCache = leavingVNodes.get(vnode.type);
	if (!leavingVNodesCache) {
		leavingVNodesCache = /* @__PURE__ */ Object.create(null);
		leavingVNodes.set(vnode.type, leavingVNodesCache);
	}
	return leavingVNodesCache;
}
function resolveTransitionHooks(vnode, props, state, instance, postClone) {
	const { appear, mode, persisted = false, onBeforeEnter, onEnter, onAfterEnter, onEnterCancelled, onBeforeLeave, onLeave, onAfterLeave, onLeaveCancelled, onBeforeAppear, onAppear, onAfterAppear, onAppearCancelled } = props;
	const key = String(vnode.key);
	const leavingVNodesCache = getLeavingNodesForType(state, vnode);
	const callHook = (hook, args) => {
		hook && callWithAsyncErrorHandling(hook, instance, 9, args);
	};
	const callAsyncHook = (hook, args) => {
		const done = args[1];
		callHook(hook, args);
		if (isArray(hook)) {
			if (hook.every((hook2) => hook2.length <= 1)) done();
		} else if (hook.length <= 1) {
			done();
		}
	};
	const hooks = {
		mode,
		persisted,
		beforeEnter(el) {
			let hook = onBeforeEnter;
			if (!state.isMounted) {
				if (appear) {
					hook = onBeforeAppear || onBeforeEnter;
				} else {
					return;
				}
			}
			if (el[leaveCbKey]) {
				el[leaveCbKey](
					true
					/* cancelled */
				);
			}
			const leavingVNode = leavingVNodesCache[key];
			if (leavingVNode && isSameVNodeType(vnode, leavingVNode) && leavingVNode.el[leaveCbKey]) {
				leavingVNode.el[leaveCbKey]();
			}
			callHook(hook, [el]);
		},
		enter(el) {
			if (!isHmrUpdating && leavingVNodesCache[key] === vnode) return;
			let hook = onEnter;
			let afterHook = onAfterEnter;
			let cancelHook = onEnterCancelled;
			if (!state.isMounted) {
				if (appear) {
					hook = onAppear || onEnter;
					afterHook = onAfterAppear || onAfterEnter;
					cancelHook = onAppearCancelled || onEnterCancelled;
				} else {
					return;
				}
			}
			let called = false;
			el[enterCbKey] = (cancelled) => {
				if (called) return;
				called = true;
				if (cancelled) {
					callHook(cancelHook, [el]);
				} else {
					callHook(afterHook, [el]);
				}
				if (hooks.delayedLeave) {
					hooks.delayedLeave();
				}
				el[enterCbKey] = void 0;
			};
			const done = el[enterCbKey].bind(null, false);
			if (hook) {
				callAsyncHook(hook, [el, done]);
			} else {
				done();
			}
		},
		leave(el, remove) {
			const key2 = String(vnode.key);
			if (el[enterCbKey]) {
				el[enterCbKey](
					true
					/* cancelled */
				);
			}
			if (state.isUnmounting) {
				return remove();
			}
			callHook(onBeforeLeave, [el]);
			let called = false;
			el[leaveCbKey] = (cancelled) => {
				if (called) return;
				called = true;
				remove();
				if (cancelled) {
					callHook(onLeaveCancelled, [el]);
				} else {
					callHook(onAfterLeave, [el]);
				}
				el[leaveCbKey] = void 0;
				if (leavingVNodesCache[key2] === vnode) {
					delete leavingVNodesCache[key2];
				}
			};
			const done = el[leaveCbKey].bind(null, false);
			leavingVNodesCache[key2] = vnode;
			if (onLeave) {
				callAsyncHook(onLeave, [el, done]);
			} else {
				done();
			}
		},
		clone(vnode2) {
			const hooks2 = resolveTransitionHooks(vnode2, props, state, instance, postClone);
			if (postClone) postClone(hooks2);
			return hooks2;
		}
	};
	return hooks;
}
function emptyPlaceholder(vnode) {
	if (isKeepAlive(vnode)) {
		vnode = cloneVNode(vnode);
		vnode.children = null;
		return vnode;
	}
}
function getInnerChild$1(vnode) {
	if (!isKeepAlive(vnode)) {
		if (isTeleport(vnode.type) && vnode.children) {
			return findNonCommentChild(vnode.children);
		}
		return vnode;
	}
	if (vnode.component) {
		return vnode.component.subTree;
	}
	const { shapeFlag, children } = vnode;
	if (children) {
		if (shapeFlag & 16) {
			return children[0];
		}
		if (shapeFlag & 32 && isFunction(children.default)) {
			return children.default();
		}
	}
}
function setTransitionHooks(vnode, hooks) {
	if (vnode.shapeFlag & 6 && vnode.component) {
		vnode.transition = hooks;
		setTransitionHooks(vnode.component.subTree, hooks);
	} else if (vnode.shapeFlag & 128) {
		vnode.ssContent.transition = hooks.clone(vnode.ssContent);
		vnode.ssFallback.transition = hooks.clone(vnode.ssFallback);
	} else {
		vnode.transition = hooks;
	}
}
function getTransitionRawChildren(children, keepComment = false, parentKey) {
	let ret = [];
	let keyedFragmentCount = 0;
	for (let i = 0; i < children.length; i++) {
		let child = children[i];
		const key = parentKey == null ? child.key : String(parentKey) + String(child.key != null ? child.key : i);
		if (child.type === Fragment) {
			if (child.patchFlag & 128) keyedFragmentCount++;
			ret = ret.concat(getTransitionRawChildren(child.children, keepComment, key));
		} else if (keepComment || child.type !== Comment) {
			ret.push(key != null ? cloneVNode(child, { key }) : child);
		}
	}
	if (keyedFragmentCount > 1) {
		for (let i = 0; i < ret.length; i++) {
			ret[i].patchFlag = -2;
		}
	}
	return ret;
}
// @__NO_SIDE_EFFECTS__
function defineComponent(options, extraOptions) {
	return isFunction(options) ? /* @__PURE__ */ (() => extend({ name: options.name }, extraOptions, { setup: options }))() : options;
}
function useId() {
	const i = getCurrentInstance();
	if (i) {
		return (i.appContext.config.idPrefix || "v") + "-" + i.ids[0] + i.ids[1]++;
	} else if (!!("development" !== "production")) {
		warn$1(`useId() is called when there is no active component instance to be associated with.`);
	}
	return "";
}
function markAsyncBoundary(instance) {
	instance.ids = [
		instance.ids[0] + instance.ids[2]++ + "-",
		0,
		0
	];
}
const knownTemplateRefs = /* @__PURE__ */ new WeakSet();
function useTemplateRef(key) {
	const i = getCurrentInstance();
	const r = shallowRef(null);
	if (i) {
		const refs = i.refs === EMPTY_OBJ ? i.refs = {} : i.refs;
		if (!!("development" !== "production") && isTemplateRefKey(refs, key)) {
			warn$1(`useTemplateRef('${key}') already exists.`);
		} else {
			Object.defineProperty(refs, key, {
				enumerable: true,
				get: () => r.value,
				set: (val) => r.value = val
			});
		}
	} else if (!!("development" !== "production")) {
		warn$1(`useTemplateRef() is called when there is no active component instance to be associated with.`);
	}
	const ret = !!("development" !== "production") ? readonly(r) : r;
	if (!!("development" !== "production")) {
		knownTemplateRefs.add(ret);
	}
	return ret;
}
function isTemplateRefKey(refs, key) {
	let desc;
	return !!((desc = Object.getOwnPropertyDescriptor(refs, key)) && !desc.configurable);
}
const pendingSetRefMap = /* @__PURE__ */ new WeakMap();
function setRef(rawRef, oldRawRef, parentSuspense, vnode, isUnmount = false) {
	if (isArray(rawRef)) {
		rawRef.forEach((r, i) => setRef(r, oldRawRef && (isArray(oldRawRef) ? oldRawRef[i] : oldRawRef), parentSuspense, vnode, isUnmount));
		return;
	}
	if (isAsyncWrapper(vnode) && !isUnmount) {
		if (vnode.shapeFlag & 512 && vnode.type.__asyncResolved && vnode.component.subTree.component) {
			setRef(rawRef, oldRawRef, parentSuspense, vnode.component.subTree);
		}
		return;
	}
	const refValue = vnode.shapeFlag & 4 ? getComponentPublicInstance(vnode.component) : vnode.el;
	const value = isUnmount ? null : refValue;
	const { i: owner, r: ref } = rawRef;
	if (!!("development" !== "production") && !owner) {
		warn$1(`Missing ref owner context. ref cannot be used on hoisted vnodes. A vnode with ref must be created inside the render function.`);
		return;
	}
	const oldRef = oldRawRef && oldRawRef.r;
	const refs = owner.refs === EMPTY_OBJ ? owner.refs = {} : owner.refs;
	const setupState = owner.setupState;
	const rawSetupState = toRaw(setupState);
	const canSetSetupRef = setupState === EMPTY_OBJ ? NO : (key) => {
		if (!!("development" !== "production")) {
			if (hasOwn(rawSetupState, key) && !isRef(rawSetupState[key])) {
				warn$1(`Template ref "${key}" used on a non-ref value. It will not work in the production build.`);
			}
			if (knownTemplateRefs.has(rawSetupState[key])) {
				return false;
			}
		}
		if (isTemplateRefKey(refs, key)) {
			return false;
		}
		return hasOwn(rawSetupState, key);
	};
	const canSetRef = (ref2, key) => {
		if (!!("development" !== "production") && knownTemplateRefs.has(ref2)) {
			return false;
		}
		if (key && isTemplateRefKey(refs, key)) {
			return false;
		}
		return true;
	};
	if (oldRef != null && oldRef !== ref) {
		invalidatePendingSetRef(oldRawRef);
		if (isString(oldRef)) {
			refs[oldRef] = null;
			if (canSetSetupRef(oldRef)) {
				setupState[oldRef] = null;
			}
		} else if (isRef(oldRef)) {
			const oldRawRefAtom = oldRawRef;
			if (canSetRef(oldRef, oldRawRefAtom.k)) {
				oldRef.value = null;
			}
			if (oldRawRefAtom.k) refs[oldRawRefAtom.k] = null;
		}
	}
	if (isFunction(ref)) {
		callWithErrorHandling(ref, owner, 12, [value, refs]);
	} else {
		const _isString = isString(ref);
		const _isRef = isRef(ref);
		if (_isString || _isRef) {
			const doSet = () => {
				if (rawRef.f) {
					const existing = _isString ? canSetSetupRef(ref) ? setupState[ref] : refs[ref] : canSetRef(ref) || !rawRef.k ? ref.value : refs[rawRef.k];
					if (isUnmount) {
						isArray(existing) && remove(existing, refValue);
					} else {
						if (!isArray(existing)) {
							if (_isString) {
								refs[ref] = [refValue];
								if (canSetSetupRef(ref)) {
									setupState[ref] = refs[ref];
								}
							} else {
								const newVal = [refValue];
								if (canSetRef(ref, rawRef.k)) {
									ref.value = newVal;
								}
								if (rawRef.k) refs[rawRef.k] = newVal;
							}
						} else if (!existing.includes(refValue)) {
							existing.push(refValue);
						}
					}
				} else if (_isString) {
					refs[ref] = value;
					if (canSetSetupRef(ref)) {
						setupState[ref] = value;
					}
				} else if (_isRef) {
					if (canSetRef(ref, rawRef.k)) {
						ref.value = value;
					}
					if (rawRef.k) refs[rawRef.k] = value;
				} else if (!!("development" !== "production")) {
					warn$1("Invalid template ref type:", ref, `(${typeof ref})`);
				}
			};
			if (value) {
				const job = () => {
					doSet();
					pendingSetRefMap.delete(rawRef);
				};
				job.id = -1;
				pendingSetRefMap.set(rawRef, job);
				queuePostRenderEffect(job, parentSuspense);
			} else {
				invalidatePendingSetRef(rawRef);
				doSet();
			}
		} else if (!!("development" !== "production")) {
			warn$1("Invalid template ref type:", ref, `(${typeof ref})`);
		}
	}
}
function invalidatePendingSetRef(rawRef) {
	const pendingSetRef = pendingSetRefMap.get(rawRef);
	if (pendingSetRef) {
		pendingSetRef.flags |= 8;
		pendingSetRefMap.delete(rawRef);
	}
}
let hasLoggedMismatchError = false;
const logMismatchError = () => {
	if (hasLoggedMismatchError) {
		return;
	}
	console.error("Hydration completed but contains mismatches.");
	hasLoggedMismatchError = true;
};
const isSVGContainer = (container) => container.namespaceURI.includes("svg") && container.tagName !== "foreignObject";
const isMathMLContainer = (container) => container.namespaceURI.includes("MathML");
const getContainerType = (container) => {
	if (container.nodeType !== 1) return void 0;
	if (isSVGContainer(container)) return "svg";
	if (isMathMLContainer(container)) return "mathml";
	return void 0;
};
const isComment = (node) => node.nodeType === 8;
function createHydrationFunctions(rendererInternals) {
	const { mt: mountComponent, p: patch, o: { patchProp, createText, nextSibling, parentNode, remove, insert, createComment } } = rendererInternals;
	const hydrate = (vnode, container) => {
		if (!container.hasChildNodes()) {
			(!!("development" !== "production") || __VUE_PROD_HYDRATION_MISMATCH_DETAILS__) && warn$1(`Attempting to hydrate existing markup but container is empty. Performing full mount instead.`);
			patch(null, vnode, container);
			flushPostFlushCbs();
			container._vnode = vnode;
			return;
		}
		hydrateNode(container.firstChild, vnode, null, null, null);
		flushPostFlushCbs();
		container._vnode = vnode;
	};
	const hydrateNode = (node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized = false) => {
		optimized = optimized || !!vnode.dynamicChildren;
		const isFragmentStart = isComment(node) && node.data === "[";
		const onMismatch = () => handleMismatch(node, vnode, parentComponent, parentSuspense, slotScopeIds, isFragmentStart);
		const { type, ref, shapeFlag, patchFlag } = vnode;
		let domType = node.nodeType;
		vnode.el = node;
		if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
			def(node, "__vnode", vnode, true);
			def(node, "__vueParentComponent", parentComponent, true);
		}
		if (patchFlag === -2) {
			optimized = false;
			vnode.dynamicChildren = null;
		}
		let nextNode = null;
		switch (type) {
			case Text:
				if (domType !== 3) {
					if (vnode.children === "") {
						insert(vnode.el = createText(""), parentNode(node), node);
						nextNode = node;
					} else {
						nextNode = onMismatch();
					}
				} else {
					if (node.data !== vnode.children) {
						(!!("development" !== "production") || __VUE_PROD_HYDRATION_MISMATCH_DETAILS__) && warn$1(`Hydration text mismatch in`, node.parentNode, `
  - rendered on server: ${JSON.stringify(node.data)}
  - expected on client: ${JSON.stringify(vnode.children)}`);
						logMismatchError();
						node.data = vnode.children;
					}
					nextNode = nextSibling(node);
				}
				break;
			case Comment:
				if (isTemplateNode(node)) {
					nextNode = nextSibling(node);
					replaceNode(vnode.el = node.content.firstChild, node, parentComponent);
				} else if (domType !== 8 || isFragmentStart) {
					nextNode = onMismatch();
				} else {
					nextNode = nextSibling(node);
				}
				break;
			case Static:
				if (isFragmentStart) {
					node = nextSibling(node);
					domType = node.nodeType;
				}
				if (domType === 1 || domType === 3) {
					nextNode = node;
					const needToAdoptContent = !vnode.children.length;
					for (let i = 0; i < vnode.staticCount; i++) {
						if (needToAdoptContent) vnode.children += nextNode.nodeType === 1 ? nextNode.outerHTML : nextNode.data;
						if (i === vnode.staticCount - 1) {
							vnode.anchor = nextNode;
						}
						nextNode = nextSibling(nextNode);
					}
					return isFragmentStart ? nextSibling(nextNode) : nextNode;
				} else {
					onMismatch();
				}
				break;
			case Fragment:
				if (!isFragmentStart) {
					nextNode = onMismatch();
				} else {
					nextNode = hydrateFragment(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized);
				}
				break;
			default: if (shapeFlag & 1) {
				if ((domType !== 1 || vnode.type.toLowerCase() !== node.tagName.toLowerCase()) && !isTemplateNode(node)) {
					nextNode = onMismatch();
				} else {
					nextNode = hydrateElement(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized);
				}
			} else if (shapeFlag & 6) {
				vnode.slotScopeIds = slotScopeIds;
				const container = parentNode(node);
				if (isFragmentStart) {
					nextNode = locateClosingAnchor(node);
				} else if (isComment(node) && node.data === "teleport start") {
					nextNode = locateClosingAnchor(node, node.data, "teleport end");
				} else {
					nextNode = nextSibling(node);
				}
				mountComponent(vnode, container, null, parentComponent, parentSuspense, getContainerType(container), optimized);
				if (isAsyncWrapper(vnode) && !vnode.type.__asyncResolved) {
					let subTree;
					if (isFragmentStart) {
						subTree = createVNode(Fragment);
						subTree.anchor = nextNode ? nextNode.previousSibling : container.lastChild;
					} else {
						subTree = node.nodeType === 3 ? createTextVNode("") : createVNode("div");
					}
					subTree.el = node;
					vnode.component.subTree = subTree;
				}
			} else if (shapeFlag & 64) {
				if (domType !== 8) {
					nextNode = onMismatch();
				} else {
					nextNode = vnode.type.hydrate(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized, rendererInternals, hydrateChildren);
				}
			} else if (shapeFlag & 128) {
				nextNode = vnode.type.hydrate(node, vnode, parentComponent, parentSuspense, getContainerType(parentNode(node)), slotScopeIds, optimized, rendererInternals, hydrateNode);
			} else if (!!("development" !== "production") || __VUE_PROD_HYDRATION_MISMATCH_DETAILS__) {
				warn$1("Invalid HostVNode type:", type, `(${typeof type})`);
			}
		}
		if (ref != null) {
			setRef(ref, null, parentSuspense, vnode);
		}
		return nextNode;
	};
	const hydrateElement = (el, vnode, parentComponent, parentSuspense, slotScopeIds, optimized) => {
		optimized = optimized || !!vnode.dynamicChildren;
		const { type, dynamicProps, props, patchFlag, shapeFlag, dirs, transition } = vnode;
		const forcePatch = type === "input" || type === "option";
		const hasDynamicProps = !!dynamicProps;
		if (!!("development" !== "production") || forcePatch || hasDynamicProps || patchFlag !== -1) {
			if (dirs) {
				invokeDirectiveHook(vnode, null, parentComponent, "created");
			}
			let needCallTransitionHooks = false;
			if (isTemplateNode(el)) {
				needCallTransitionHooks = needTransition(
					null,
					// no need check parentSuspense in hydration
					transition
				) && parentComponent && parentComponent.vnode.props && parentComponent.vnode.props.appear;
				const content = el.content.firstChild;
				if (needCallTransitionHooks) {
					const cls = content.getAttribute("class");
					if (cls) content.$cls = cls;
					transition.beforeEnter(content);
				}
				replaceNode(content, el, parentComponent);
				vnode.el = el = content;
			}
			if (shapeFlag & 16 && !(props && (props.innerHTML || props.textContent))) {
				let next = hydrateChildren(el.firstChild, vnode, el, parentComponent, parentSuspense, slotScopeIds, optimized);
				if (next && !isMismatchAllowed(
					el,
					1
					/* CHILDREN */
				)) {
					(!!("development" !== "production") || __VUE_PROD_HYDRATION_MISMATCH_DETAILS__) && warn$1(`Hydration children mismatch on`, el, `
Server rendered element contains more child nodes than client vdom.`);
					logMismatchError();
				}
				while (next) {
					const cur = next;
					next = next.nextSibling;
					remove(cur);
				}
			} else if (shapeFlag & 8) {
				let clientText = vnode.children;
				if (clientText[0] === "\n" && (el.tagName === "PRE" || el.tagName === "TEXTAREA")) {
					clientText = clientText.slice(1);
				}
				const { textContent } = el;
				if (textContent !== clientText && textContent !== clientText.replace(/\r\n|\r/g, "\n")) {
					if (!isMismatchAllowed(
						el,
						0
						/* TEXT */
					)) {
						(!!("development" !== "production") || __VUE_PROD_HYDRATION_MISMATCH_DETAILS__) && warn$1(`Hydration text content mismatch on`, el, `
  - rendered on server: ${textContent}
  - expected on client: ${clientText}`);
						logMismatchError();
					}
					el.textContent = vnode.children;
				}
			}
			if (props) {
				if (!!("development" !== "production") || __VUE_PROD_HYDRATION_MISMATCH_DETAILS__ || forcePatch || hasDynamicProps || !optimized || patchFlag & (16 | 32)) {
					const isCustomElement = el.tagName.includes("-");
					const namespace = el.namespaceURI.includes("svg") ? "svg" : el.namespaceURI.includes("MathML") ? "mathml" : void 0;
					for (const key in props) {
						if ((!!("development" !== "production") || __VUE_PROD_HYDRATION_MISMATCH_DETAILS__) && !(dirs && dirs.some((d) => d.dir.created)) && propHasMismatch(el, key, props[key], vnode, parentComponent)) {
							logMismatchError();
						}
						if (forcePatch && (key.endsWith("value") || key === "indeterminate") || isOn(key) && !isReservedProp(key) || key[0] === "." || isCustomElement && !isReservedProp(key) || dynamicProps && dynamicProps.includes(key)) {
							patchProp(el, key, null, props[key], namespace, parentComponent);
						}
					}
				} else if (props.onClick) {
					patchProp(el, "onClick", null, props.onClick, void 0, parentComponent);
				} else if (patchFlag & 4 && isReactive(props.style)) {
					for (const key in props.style) props.style[key];
				}
			}
			let vnodeHooks;
			if (vnodeHooks = props && props.onVnodeBeforeMount) {
				invokeVNodeHook(vnodeHooks, parentComponent, vnode);
			}
			if (dirs) {
				invokeDirectiveHook(vnode, null, parentComponent, "beforeMount");
			}
			if ((vnodeHooks = props && props.onVnodeMounted) || dirs || needCallTransitionHooks) {
				queueEffectWithSuspense(() => {
					vnodeHooks && invokeVNodeHook(vnodeHooks, parentComponent, vnode);
					needCallTransitionHooks && transition.enter(el);
					dirs && invokeDirectiveHook(vnode, null, parentComponent, "mounted");
				}, parentSuspense);
			}
		}
		return el.nextSibling;
	};
	const hydrateChildren = (node, parentVNode, container, parentComponent, parentSuspense, slotScopeIds, optimized) => {
		optimized = optimized || !!parentVNode.dynamicChildren;
		const children = parentVNode.children;
		const l = children.length;
		let hasCheckedMismatch = false;
		for (let i = 0; i < l; i++) {
			const vnode = optimized ? children[i] : children[i] = normalizeVNode(children[i]);
			const isText = vnode.type === Text;
			if (node) {
				if (isText && !optimized) {
					if (i + 1 < l && normalizeVNode(children[i + 1]).type === Text) {
						insert(createText(node.data.slice(vnode.children.length)), container, nextSibling(node));
						node.data = vnode.children;
					}
				}
				node = hydrateNode(node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized);
			} else if (isText && !vnode.children) {
				insert(vnode.el = createText(""), container);
			} else {
				if (!hasCheckedMismatch) {
					hasCheckedMismatch = true;
					if (!isMismatchAllowed(
						container,
						1
						/* CHILDREN */
					)) {
						(!!("development" !== "production") || __VUE_PROD_HYDRATION_MISMATCH_DETAILS__) && warn$1(`Hydration children mismatch on`, container, `
Server rendered element contains fewer child nodes than client vdom.`);
						logMismatchError();
					}
				}
				patch(null, vnode, container, null, parentComponent, parentSuspense, getContainerType(container), slotScopeIds);
			}
		}
		return node;
	};
	const hydrateFragment = (node, vnode, parentComponent, parentSuspense, slotScopeIds, optimized) => {
		const { slotScopeIds: fragmentSlotScopeIds } = vnode;
		if (fragmentSlotScopeIds) {
			slotScopeIds = slotScopeIds ? slotScopeIds.concat(fragmentSlotScopeIds) : fragmentSlotScopeIds;
		}
		const container = parentNode(node);
		const next = hydrateChildren(nextSibling(node), vnode, container, parentComponent, parentSuspense, slotScopeIds, optimized);
		if (next && isComment(next) && next.data === "]") {
			return nextSibling(vnode.anchor = next);
		} else {
			logMismatchError();
			insert(vnode.anchor = createComment(`]`), container, next);
			return next;
		}
	};
	const handleMismatch = (node, vnode, parentComponent, parentSuspense, slotScopeIds, isFragment) => {
		if (!isNodeMismatchAllowed(node, vnode)) {
			(!!("development" !== "production") || __VUE_PROD_HYDRATION_MISMATCH_DETAILS__) && warn$1(`Hydration node mismatch:
- rendered on server:`, node, node.nodeType === 3 ? `(text)` : isComment(node) && node.data === "[" ? `(start of fragment)` : ``, `
- expected on client:`, vnode.type);
			logMismatchError();
		}
		vnode.el = null;
		if (isFragment) {
			const end = locateClosingAnchor(node);
			while (true) {
				const next2 = nextSibling(node);
				if (next2 && next2 !== end) {
					remove(next2);
				} else {
					break;
				}
			}
		}
		const next = nextSibling(node);
		const container = parentNode(node);
		remove(node);
		patch(null, vnode, container, next, parentComponent, parentSuspense, getContainerType(container), slotScopeIds);
		if (parentComponent) {
			parentComponent.vnode.el = vnode.el;
			updateHOCHostEl(parentComponent, vnode.el);
		}
		return next;
	};
	const locateClosingAnchor = (node, open = "[", close = "]") => {
		let match = 0;
		while (node) {
			node = nextSibling(node);
			if (node && isComment(node)) {
				if (node.data === open) match++;
				if (node.data === close) {
					if (match === 0) {
						return nextSibling(node);
					} else {
						match--;
					}
				}
			}
		}
		return node;
	};
	const replaceNode = (newNode, oldNode, parentComponent) => {
		const parentNode2 = oldNode.parentNode;
		if (parentNode2) {
			parentNode2.replaceChild(newNode, oldNode);
		}
		let parent = parentComponent;
		while (parent) {
			if (parent.vnode.el === oldNode) {
				parent.vnode.el = parent.subTree.el = newNode;
			}
			parent = parent.parent;
		}
	};
	const isTemplateNode = (node) => {
		return node.nodeType === 1 && node.tagName === "TEMPLATE";
	};
	return [hydrate, hydrateNode];
}
function propHasMismatch(el, key, clientValue, vnode, instance) {
	let mismatchType;
	let mismatchKey;
	let actual;
	let expected;
	if (key === "class") {
		if (el.$cls) {
			actual = el.$cls;
			delete el.$cls;
		} else {
			actual = el.getAttribute("class");
		}
		expected = normalizeClass(clientValue);
		if (!isSetEqual(toClassSet(actual || ""), toClassSet(expected))) {
			mismatchType = 2;
			mismatchKey = `class`;
		}
	} else if (key === "style") {
		actual = el.getAttribute("style") || "";
		expected = isString(clientValue) ? clientValue : stringifyStyle(normalizeStyle(clientValue));
		const actualMap = toStyleMap(actual);
		const expectedMap = toStyleMap(expected);
		if (vnode.dirs) {
			for (const { dir, value } of vnode.dirs) {
				if (dir.name === "show" && !value) {
					expectedMap.set("display", "none");
				}
			}
		}
		if (instance) {
			resolveCssVars(instance, vnode, expectedMap);
		}
		if (!isMapEqual(actualMap, expectedMap)) {
			mismatchType = 3;
			mismatchKey = "style";
		}
	} else if (el instanceof SVGElement && isKnownSvgAttr(key) || el instanceof HTMLElement && (isBooleanAttr(key) || isKnownHtmlAttr(key))) {
		if (isBooleanAttr(key)) {
			actual = el.hasAttribute(key);
			expected = includeBooleanAttr(clientValue);
		} else if (clientValue == null) {
			actual = el.hasAttribute(key);
			expected = false;
		} else {
			if (el.hasAttribute(key)) {
				actual = el.getAttribute(key);
			} else if (key === "value" && el.tagName === "TEXTAREA") {
				actual = el.value;
			} else {
				actual = false;
			}
			expected = isRenderableAttrValue(clientValue) ? String(clientValue) : false;
		}
		if (actual !== expected) {
			mismatchType = 4;
			mismatchKey = key;
		}
	}
	if (mismatchType != null && !isMismatchAllowed(el, mismatchType)) {
		const format = (v) => v === false ? `(not rendered)` : `${mismatchKey}="${v}"`;
		const preSegment = `Hydration ${MismatchTypeString[mismatchType]} mismatch on`;
		const postSegment = `
  - rendered on server: ${format(actual)}
  - expected on client: ${format(expected)}
  Note: this mismatch is check-only. The DOM will not be rectified in production due to performance overhead.
  You should fix the source of the mismatch.`;
		{
			warn$1(preSegment, el, postSegment);
		}
		return true;
	}
	return false;
}
function toClassSet(str) {
	return new Set(str.trim().split(/\s+/));
}
function isSetEqual(a, b) {
	if (a.size !== b.size) {
		return false;
	}
	for (const s of a) {
		if (!b.has(s)) {
			return false;
		}
	}
	return true;
}
function toStyleMap(str) {
	const styleMap = /* @__PURE__ */ new Map();
	for (const item of str.split(";")) {
		let [key, value] = item.split(":");
		key = key.trim();
		value = value && value.trim();
		if (key && value) {
			styleMap.set(key, value);
		}
	}
	return styleMap;
}
function isMapEqual(a, b) {
	if (a.size !== b.size) {
		return false;
	}
	for (const [key, value] of a) {
		if (value !== b.get(key)) {
			return false;
		}
	}
	return true;
}
function resolveCssVars(instance, vnode, expectedMap) {
	const root = instance.subTree;
	if (instance.getCssVars && (vnode === root || root && root.type === Fragment && root.children.includes(vnode))) {
		const cssVars = instance.getCssVars();
		for (const key in cssVars) {
			const value = normalizeCssVarValue(cssVars[key]);
			expectedMap.set(`--${getEscapedCssVarName(key, false)}`, value);
		}
	}
	if (vnode === root && instance.parent) {
		resolveCssVars(instance.parent, instance.vnode, expectedMap);
	}
}
const allowMismatchAttr = "data-allow-mismatch";
const MismatchTypeString = {
	[0]: "text",
	[1]: "children",
	[2]: "class",
	[3]: "style",
	[4]: "attribute"
};
function isMismatchAllowed(el, allowedType) {
	if (allowedType === 0 || allowedType === 1) {
		while (el && !el.hasAttribute(allowMismatchAttr)) {
			el = el.parentElement;
		}
	}
	return isMismatchAllowedByAttr(el && el.getAttribute(allowMismatchAttr), allowedType);
}
function isMismatchAllowedByAttr(allowedAttr, allowedType) {
	if (allowedAttr == null) {
		return false;
	} else if (allowedAttr === "") {
		return true;
	} else {
		const list = allowedAttr.split(",");
		if (allowedType === 0 && list.includes("children")) {
			return true;
		}
		return list.includes(MismatchTypeString[allowedType]);
	}
}
function isNodeMismatchAllowed(node, vnode) {
	return isMismatchAllowed(
		node.parentElement,
		1
		/* CHILDREN */
	) || isMismatchAllowedByNode(node) || isMismatchAllowedByVNode(vnode);
}
function isMismatchAllowedByNode(node) {
	return node.nodeType === 1 && isMismatchAllowedByAttr(node.getAttribute(allowMismatchAttr), 1);
}
function isMismatchAllowedByVNode({ props }) {
	const allowedAttr = props && props[allowMismatchAttr];
	return typeof allowedAttr === "string" && isMismatchAllowedByAttr(
		allowedAttr,
		1
		/* CHILDREN */
	);
}
const requestIdleCallback = getGlobalThis().requestIdleCallback || ((cb) => setTimeout(cb, 1));
const cancelIdleCallback = getGlobalThis().cancelIdleCallback || ((id) => clearTimeout(id));
const hydrateOnIdle = (timeout = 1e4) => (hydrate) => {
	const id = requestIdleCallback(hydrate, { timeout });
	return () => cancelIdleCallback(id);
};
function elementIsVisibleInViewport(el) {
	const { top, left, bottom, right } = el.getBoundingClientRect();
	const { innerHeight, innerWidth } = window;
	return (top > 0 && top < innerHeight || bottom > 0 && bottom < innerHeight) && (left > 0 && left < innerWidth || right > 0 && right < innerWidth);
}
const hydrateOnVisible = (opts) => (hydrate, forEach) => {
	const ob = new IntersectionObserver((entries) => {
		for (const e of entries) {
			if (!e.isIntersecting) continue;
			ob.disconnect();
			hydrate();
			break;
		}
	}, opts);
	forEach((el) => {
		if (!(el instanceof Element)) return;
		if (elementIsVisibleInViewport(el)) {
			hydrate();
			ob.disconnect();
			return false;
		}
		ob.observe(el);
	});
	return () => ob.disconnect();
};
const hydrateOnMediaQuery = (query) => (hydrate) => {
	if (query) {
		const mql = matchMedia(query);
		if (mql.matches) {
			hydrate();
		} else {
			mql.addEventListener("change", hydrate, { once: true });
			return () => mql.removeEventListener("change", hydrate);
		}
	}
};
const hydrateOnInteraction = (interactions = []) => (hydrate, forEach) => {
	if (isString(interactions)) interactions = [interactions];
	let hasHydrated = false;
	const doHydrate = (e) => {
		if (!hasHydrated) {
			hasHydrated = true;
			teardown();
			hydrate();
			e.target.dispatchEvent(new e.constructor(e.type, e));
		}
	};
	const teardown = () => {
		forEach((el) => {
			for (const i of interactions) {
				el.removeEventListener(i, doHydrate);
			}
		});
	};
	forEach((el) => {
		for (const i of interactions) {
			el.addEventListener(i, doHydrate, { once: true });
		}
	});
	return teardown;
};
function forEachElement(node, cb) {
	if (isComment(node) && node.data === "[") {
		let depth = 1;
		let next = node.nextSibling;
		while (next) {
			if (next.nodeType === 1) {
				const result = cb(next);
				if (result === false) {
					break;
				}
			} else if (isComment(next)) {
				if (next.data === "]") {
					if (--depth === 0) break;
				} else if (next.data === "[") {
					depth++;
				}
			}
			next = next.nextSibling;
		}
	} else {
		cb(node);
	}
}
const isAsyncWrapper = (i) => !!i.type.__asyncLoader;
// @__NO_SIDE_EFFECTS__
function defineAsyncComponent(source) {
	if (isFunction(source)) {
		source = { loader: source };
	}
	const { loader, loadingComponent, errorComponent, delay = 200, hydrate: hydrateStrategy, timeout, suspensible = true, onError: userOnError } = source;
	let pendingRequest = null;
	let resolvedComp;
	let retries = 0;
	const retry = () => {
		retries++;
		pendingRequest = null;
		return load();
	};
	const load = () => {
		let thisRequest;
		return pendingRequest || (thisRequest = pendingRequest = loader().catch((err) => {
			err = err instanceof Error ? err : new Error(String(err));
			if (userOnError) {
				return new Promise((resolve, reject) => {
					const userRetry = () => resolve(retry());
					const userFail = () => reject(err);
					userOnError(err, userRetry, userFail, retries + 1);
				});
			} else {
				throw err;
			}
		}).then((comp) => {
			if (thisRequest !== pendingRequest && pendingRequest) {
				return pendingRequest;
			}
			if (!!("development" !== "production") && !comp) {
				warn$1(`Async component loader resolved to undefined. If you are using retry(), make sure to return its return value.`);
			}
			if (comp && (comp.__esModule || comp[Symbol.toStringTag] === "Module")) {
				comp = comp.default;
			}
			if (!!("development" !== "production") && comp && !isObject(comp) && !isFunction(comp)) {
				throw new Error(`Invalid async component load result: ${comp}`);
			}
			resolvedComp = comp;
			return comp;
		}));
	};
	return defineComponent({
		name: "AsyncComponentWrapper",
		__asyncLoader: load,
		__asyncHydrate(el, instance, hydrate) {
			const wasConnected = el.isConnected;
			let patched = false;
			(instance.bu || (instance.bu = [])).push(() => patched = true);
			const performHydrate = () => {
				if (patched) {
					if (!!("development" !== "production")) {
						warn$1(`Skipping lazy hydration for component '${getComponentName(resolvedComp) || resolvedComp.__file}': it was updated before lazy hydration performed.`);
					}
					return;
				}
				if (!el.parentNode || wasConnected && !el.isConnected) return;
				hydrate();
			};
			const doHydrate = hydrateStrategy ? () => {
				const teardown = hydrateStrategy(performHydrate, (cb) => forEachElement(el, cb));
				if (teardown) {
					(instance.bum || (instance.bum = [])).push(teardown);
				}
			} : performHydrate;
			if (resolvedComp) {
				doHydrate();
			} else {
				load().then(() => !instance.isUnmounted && doHydrate());
			}
		},
		get __asyncResolved() {
			return resolvedComp;
		},
		setup() {
			const instance = currentInstance;
			markAsyncBoundary(instance);
			if (resolvedComp) {
				return () => createInnerComp(resolvedComp, instance);
			}
			const onError = (err) => {
				pendingRequest = null;
				handleError(err, instance, 13, !errorComponent);
			};
			if (suspensible && instance.suspense || isInSSRComponentSetup) {
				return load().then((comp) => {
					return () => createInnerComp(comp, instance);
				}).catch((err) => {
					onError(err);
					return () => errorComponent ? createVNode(errorComponent, { error: err }) : null;
				});
			}
			const loaded = ref(false);
			const error = ref();
			const delayed = ref(!!delay);
			let timeoutTimer;
			let delayTimer;
			onUnmounted(() => {
				if (timeoutTimer != null) clearTimeout(timeoutTimer);
				if (delayTimer != null) clearTimeout(delayTimer);
			});
			if (delay) {
				delayTimer = setTimeout(() => {
					if (instance.isUnmounted) return;
					delayed.value = false;
				}, delay);
			}
			if (timeout != null) {
				timeoutTimer = setTimeout(() => {
					if (instance.isUnmounted) return;
					if (!loaded.value && !error.value) {
						const err = new Error(`Async component timed out after ${timeout}ms.`);
						onError(err);
						error.value = err;
					}
				}, timeout);
			}
			load().then(() => {
				if (instance.isUnmounted) return;
				loaded.value = true;
				if (instance.parent && isKeepAlive(instance.parent.vnode)) {
					instance.parent.update();
				}
			}).catch((err) => {
				if (instance.isUnmounted) {
					pendingRequest = null;
					return;
				}
				onError(err);
				error.value = err;
			});
			return () => {
				if (loaded.value && resolvedComp) {
					return createInnerComp(resolvedComp, instance);
				} else if (error.value && errorComponent) {
					return createVNode(errorComponent, { error: error.value });
				} else if (loadingComponent && !delayed.value) {
					return createInnerComp(loadingComponent, instance);
				}
			};
		}
	});
}
function createInnerComp(comp, parent) {
	const { ref: ref2, props, children, ce } = parent.vnode;
	const vnode = createVNode(comp, props, children);
	vnode.ref = ref2;
	vnode.ce = ce;
	delete parent.vnode.ce;
	return vnode;
}
const isKeepAlive = (vnode) => vnode.type.__isKeepAlive;
const KeepAliveImpl = {
	name: `KeepAlive`,
	// Marker for special handling inside the renderer. We are not using a ===
	// check directly on KeepAlive in the renderer, because importing it directly
	// would prevent it from being tree-shaken.
	__isKeepAlive: true,
	props: {
		include: [
			String,
			RegExp,
			Array
		],
		exclude: [
			String,
			RegExp,
			Array
		],
		max: [String, Number]
	},
	setup(props, { slots }) {
		const instance = getCurrentInstance();
		const sharedContext = instance.ctx;
		if (!sharedContext.renderer) {
			return () => {
				const children = slots.default && slots.default();
				return children && children.length === 1 ? children[0] : children;
			};
		}
		const cache = /* @__PURE__ */ new Map();
		const keys = /* @__PURE__ */ new Set();
		let current = null;
		if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
			instance.__v_cache = cache;
		}
		const parentSuspense = instance.suspense;
		const { renderer: { p: patch, m: move, um: _unmount, o: { createElement } } } = sharedContext;
		const storageContainer = createElement("div");
		sharedContext.activate = (vnode, container, anchor, namespace, optimized) => {
			const instance2 = vnode.component;
			move(vnode, container, anchor, 0, parentSuspense);
			patch(instance2.vnode, vnode, container, anchor, instance2, parentSuspense, namespace, vnode.slotScopeIds, optimized);
			queuePostRenderEffect(() => {
				instance2.isDeactivated = false;
				if (instance2.a) {
					invokeArrayFns(instance2.a);
				}
				const vnodeHook = vnode.props && vnode.props.onVnodeMounted;
				if (vnodeHook) {
					invokeVNodeHook(vnodeHook, instance2.parent, vnode);
				}
			}, parentSuspense);
			if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
				devtoolsComponentAdded(instance2);
			}
		};
		sharedContext.deactivate = (vnode) => {
			const instance2 = vnode.component;
			invalidateMount(instance2.m);
			invalidateMount(instance2.a);
			move(vnode, storageContainer, null, 1, parentSuspense);
			queuePostRenderEffect(() => {
				if (instance2.da) {
					invokeArrayFns(instance2.da);
				}
				const vnodeHook = vnode.props && vnode.props.onVnodeUnmounted;
				if (vnodeHook) {
					invokeVNodeHook(vnodeHook, instance2.parent, vnode);
				}
				instance2.isDeactivated = true;
			}, parentSuspense);
			if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
				devtoolsComponentAdded(instance2);
			}
			if (!!("development" !== "production") && true) {
				instance2.__keepAliveStorageContainer = storageContainer;
			}
		};
		function unmount(vnode) {
			resetShapeFlag(vnode);
			_unmount(vnode, instance, parentSuspense, true);
		}
		function pruneCache(filter) {
			cache.forEach((vnode, key) => {
				const name = getComponentName(isAsyncWrapper(vnode) ? vnode.type.__asyncResolved || {} : vnode.type);
				if (name && !filter(name)) {
					pruneCacheEntry(key);
				}
			});
		}
		function pruneCacheEntry(key) {
			const cached = cache.get(key);
			if (cached && (!current || !isSameVNodeType(cached, current))) {
				unmount(cached);
			} else if (current) {
				resetShapeFlag(current);
			}
			cache.delete(key);
			keys.delete(key);
		}
		watch(
			() => [props.include, props.exclude],
			([include, exclude]) => {
				include && pruneCache((name) => matches(include, name));
				exclude && pruneCache((name) => !matches(exclude, name));
			},
			// prune post-render after `current` has been updated
			{
				flush: "post",
				deep: true
			}
		);
		let pendingCacheKey = null;
		const cacheSubtree = () => {
			if (pendingCacheKey != null) {
				if (isSuspense(instance.subTree.type)) {
					queuePostRenderEffect(() => {
						cache.set(pendingCacheKey, getInnerChild(instance.subTree));
					}, instance.subTree.suspense);
				} else {
					cache.set(pendingCacheKey, getInnerChild(instance.subTree));
				}
			}
		};
		onMounted(cacheSubtree);
		onUpdated(cacheSubtree);
		onBeforeUnmount(() => {
			cache.forEach((cached) => {
				const { subTree, suspense } = instance;
				const vnode = getInnerChild(subTree);
				if (cached.type === vnode.type && cached.key === vnode.key) {
					resetShapeFlag(vnode);
					const da = vnode.component.da;
					da && queuePostRenderEffect(da, suspense);
					return;
				}
				unmount(cached);
			});
		});
		return () => {
			pendingCacheKey = null;
			if (!slots.default) {
				return current = null;
			}
			const children = slots.default();
			const rawVNode = children[0];
			if (children.length > 1) {
				if (!!("development" !== "production")) {
					warn$1(`KeepAlive should contain exactly one component child.`);
				}
				current = null;
				return children;
			} else if (!isVNode(rawVNode) || !(rawVNode.shapeFlag & 4) && !(rawVNode.shapeFlag & 128)) {
				current = null;
				return rawVNode;
			}
			let vnode = getInnerChild(rawVNode);
			if (vnode.type === Comment) {
				current = null;
				return vnode;
			}
			const comp = vnode.type;
			const name = getComponentName(isAsyncWrapper(vnode) ? vnode.type.__asyncResolved || {} : comp);
			const { include, exclude, max } = props;
			if (include && (!name || !matches(include, name)) || exclude && name && matches(exclude, name)) {
				vnode.shapeFlag &= -257;
				current = vnode;
				return rawVNode;
			}
			const key = vnode.key == null ? comp : vnode.key;
			const cachedVNode = cache.get(key);
			if (vnode.el) {
				vnode = cloneVNode(vnode);
				if (rawVNode.shapeFlag & 128) {
					rawVNode.ssContent = vnode;
				}
			}
			pendingCacheKey = key;
			if (cachedVNode) {
				vnode.el = cachedVNode.el;
				vnode.component = cachedVNode.component;
				if (vnode.transition) {
					setTransitionHooks(vnode, vnode.transition);
				}
				vnode.shapeFlag |= 512;
				keys.delete(key);
				keys.add(key);
			} else {
				keys.add(key);
				if (max && keys.size > parseInt(max, 10)) {
					pruneCacheEntry(keys.values().next().value);
				}
			}
			vnode.shapeFlag |= 256;
			current = vnode;
			return isSuspense(rawVNode.type) ? rawVNode : vnode;
		};
	}
};
const KeepAlive = KeepAliveImpl;
function matches(pattern, name) {
	if (isArray(pattern)) {
		return pattern.some((p) => matches(p, name));
	} else if (isString(pattern)) {
		return pattern.split(",").includes(name);
	} else if (isRegExp(pattern)) {
		pattern.lastIndex = 0;
		return pattern.test(name);
	}
	return false;
}
function onActivated(hook, target) {
	registerKeepAliveHook(hook, "a", target);
}
function onDeactivated(hook, target) {
	registerKeepAliveHook(hook, "da", target);
}
function registerKeepAliveHook(hook, type, target = currentInstance) {
	const wrappedHook = hook.__wdc || (hook.__wdc = () => {
		let current = target;
		while (current) {
			if (current.isDeactivated) {
				return;
			}
			current = current.parent;
		}
		return hook();
	});
	injectHook(type, wrappedHook, target);
	if (target) {
		let current = target.parent;
		while (current && current.parent) {
			if (isKeepAlive(current.parent.vnode)) {
				injectToKeepAliveRoot(wrappedHook, type, target, current);
			}
			current = current.parent;
		}
	}
}
function injectToKeepAliveRoot(hook, type, target, keepAliveRoot) {
	const injected = injectHook(
		type,
		hook,
		keepAliveRoot,
		true
		/* prepend */
	);
	onUnmounted(() => {
		remove(keepAliveRoot[type], injected);
	}, target);
}
function resetShapeFlag(vnode) {
	vnode.shapeFlag &= -257;
	vnode.shapeFlag &= -513;
}
function getInnerChild(vnode) {
	return vnode.shapeFlag & 128 ? vnode.ssContent : vnode;
}
function injectHook(type, hook, target = currentInstance, prepend = false) {
	if (target) {
		const hooks = target[type] || (target[type] = []);
		const wrappedHook = hook.__weh || (hook.__weh = (...args) => {
			pauseTracking();
			const reset = setCurrentInstance(target);
			const res = callWithAsyncErrorHandling(hook, target, type, args);
			reset();
			resetTracking();
			return res;
		});
		if (prepend) {
			hooks.unshift(wrappedHook);
		} else {
			hooks.push(wrappedHook);
		}
		return wrappedHook;
	} else if (!!("development" !== "production")) {
		const apiName = toHandlerKey(ErrorTypeStrings$1[type].replace(/ hook$/, ""));
		warn$1(`${apiName} is called when there is no active component instance to be associated with. Lifecycle injection APIs can only be used during execution of setup().` + ` If you are using async setup(), make sure to register lifecycle hooks before the first await statement.`);
	}
}
const createHook = (lifecycle) => (hook, target = currentInstance) => {
	if (!isInSSRComponentSetup || lifecycle === "sp") {
		injectHook(lifecycle, (...args) => hook(...args), target);
	}
};
const onBeforeMount = createHook("bm");
const onMounted = createHook("m");
const onBeforeUpdate = createHook("bu");
const onUpdated = createHook("u");
const onBeforeUnmount = createHook("bum");
const onUnmounted = createHook("um");
const onServerPrefetch = createHook("sp");
const onRenderTriggered = createHook("rtg");
const onRenderTracked = createHook("rtc");
function onErrorCaptured(hook, target = currentInstance) {
	injectHook("ec", hook, target);
}
const COMPONENTS = "components";
const DIRECTIVES = "directives";
function resolveComponent(name, maybeSelfReference) {
	return resolveAsset(COMPONENTS, name, true, maybeSelfReference) || name;
}
const NULL_DYNAMIC_COMPONENT = /* @__PURE__ */ Symbol.for("v-ndc");
function resolveDynamicComponent(component) {
	if (isString(component)) {
		return resolveAsset(COMPONENTS, component, false) || component;
	} else {
		return component || NULL_DYNAMIC_COMPONENT;
	}
}
function resolveDirective(name) {
	return resolveAsset(DIRECTIVES, name);
}
function resolveAsset(type, name, warnMissing = true, maybeSelfReference = false) {
	const instance = currentRenderingInstance || currentInstance;
	if (instance) {
		const Component = instance.type;
		if (type === COMPONENTS) {
			const selfName = getComponentName(Component, false);
			if (selfName && (selfName === name || selfName === camelize(name) || selfName === capitalize(camelize(name)))) {
				return Component;
			}
		}
		const res = resolve(instance[type] || Component[type], name) || resolve(instance.appContext[type], name);
		if (!res && maybeSelfReference) {
			return Component;
		}
		if (!!("development" !== "production") && warnMissing && !res) {
			const extra = type === COMPONENTS ? `
If this is a native custom element, make sure to exclude it from component resolution via compilerOptions.isCustomElement.` : ``;
			warn$1(`Failed to resolve ${type.slice(0, -1)}: ${name}${extra}`);
		}
		return res;
	} else if (!!("development" !== "production")) {
		warn$1(`resolve${capitalize(type.slice(0, -1))} can only be used in render() or setup().`);
	}
}
function resolve(registry, name) {
	return registry && (registry[name] || registry[camelize(name)] || registry[capitalize(camelize(name))]);
}
function renderList(source, renderItem, cache, index) {
	let ret;
	const cached = cache && cache[index];
	const sourceIsArray = isArray(source);
	if (sourceIsArray || isString(source)) {
		const sourceIsReactiveArray = sourceIsArray && isReactive(source);
		let needsWrap = false;
		let isReadonlySource = false;
		if (sourceIsReactiveArray) {
			needsWrap = !isShallow(source);
			isReadonlySource = isReadonly(source);
			source = shallowReadArray(source);
		}
		ret = new Array(source.length);
		for (let i = 0, l = source.length; i < l; i++) {
			ret[i] = renderItem(needsWrap ? isReadonlySource ? toReadonly(toReactive(source[i])) : toReactive(source[i]) : source[i], i, void 0, cached && cached[i]);
		}
	} else if (typeof source === "number") {
		if (!!("development" !== "production") && (!Number.isInteger(source) || source < 0)) {
			warn$1(`The v-for range expects a positive integer value but got ${source}.`);
			ret = [];
		} else {
			ret = new Array(source);
			for (let i = 0; i < source; i++) {
				ret[i] = renderItem(i + 1, i, void 0, cached && cached[i]);
			}
		}
	} else if (isObject(source)) {
		if (source[Symbol.iterator]) {
			ret = Array.from(source, (item, i) => renderItem(item, i, void 0, cached && cached[i]));
		} else {
			const keys = Object.keys(source);
			ret = new Array(keys.length);
			for (let i = 0, l = keys.length; i < l; i++) {
				const key = keys[i];
				ret[i] = renderItem(source[key], key, i, cached && cached[i]);
			}
		}
	} else {
		ret = [];
	}
	if (cache) {
		cache[index] = ret;
	}
	return ret;
}
function createSlots(slots, dynamicSlots) {
	for (let i = 0; i < dynamicSlots.length; i++) {
		const slot = dynamicSlots[i];
		if (isArray(slot)) {
			for (let j = 0; j < slot.length; j++) {
				slots[slot[j].name] = slot[j].fn;
			}
		} else if (slot) {
			slots[slot.name] = slot.key ? (...args) => {
				const res = slot.fn(...args);
				if (res) res.key = slot.key;
				return res;
			} : slot.fn;
		}
	}
	return slots;
}
function renderSlot(slots, name, props = {}, fallback, noSlotted, branchKey) {
	if (currentRenderingInstance.ce || currentRenderingInstance.parent && isAsyncWrapper(currentRenderingInstance.parent) && currentRenderingInstance.parent.ce) {
		const slotProps = branchKey != null && props.key == null ? extend({}, props, { key: branchKey }) : props;
		const hasProps = Object.keys(slotProps).length > 0;
		if (name !== "default") slotProps.name = name;
		return openBlock(), createBlock(Fragment, null, [createVNode("slot", slotProps, fallback && fallback())], hasProps ? -2 : 64);
	}
	let slot = slots[name];
	if (!!("development" !== "production") && slot && slot.length > 1) {
		warn$1(`SSR-optimized slot function detected in a non-SSR-optimized render function. You need to mark this component with $dynamic-slots in the parent template.`);
		slot = () => [];
	}
	if (slot && slot._c) {
		slot._d = false;
	}
	const prevStackSize = blockStack.length;
	openBlock();
	let rendered;
	try {
		const validSlotContent = slot && ensureValidVNode(slot(props));
		const slotKey = props.key || branchKey || validSlotContent && validSlotContent.key;
		rendered = createBlock(Fragment, { key: (slotKey && !isSymbol(slotKey) ? slotKey : `_${name}`) + (!validSlotContent && fallback ? "_fb" : "") }, validSlotContent || (fallback ? fallback() : []), validSlotContent && slots._ === 1 ? 64 : -2);
	} catch (err) {
		for (let i = blockStack.length; i > prevStackSize; i--) closeBlock();
		throw err;
	} finally {
		if (slot && slot._c) {
			slot._d = true;
		}
	}
	if (!noSlotted && rendered.scopeId) {
		rendered.slotScopeIds = [rendered.scopeId + "-s"];
	}
	return rendered;
}
function ensureValidVNode(vnodes) {
	return vnodes.some((child) => {
		if (!isVNode(child)) return true;
		if (child.type === Comment) return false;
		if (child.type === Fragment && !ensureValidVNode(child.children)) return false;
		return true;
	}) ? vnodes : null;
}
function toHandlers(obj, preserveCaseIfNecessary) {
	const ret = {};
	if (!!("development" !== "production") && !isObject(obj)) {
		warn$1(`v-on with no argument expects an object value.`);
		return ret;
	}
	for (const key in obj) {
		ret[preserveCaseIfNecessary && /[A-Z]/.test(key) ? `on:${key}` : toHandlerKey(key)] = obj[key];
	}
	return ret;
}
const getPublicInstance = (i) => {
	if (!i) return null;
	if (isStatefulComponent(i)) return getComponentPublicInstance(i);
	return getPublicInstance(i.parent);
};
const publicPropertiesMap = /* @__PURE__ */ extend(/* @__PURE__ */ Object.create(null), {
	$: (i) => i,
	$el: (i) => i.vnode.el,
	$data: (i) => i.data,
	$props: (i) => !!("development" !== "production") ? shallowReadonly(i.props) : i.props,
	$attrs: (i) => !!("development" !== "production") ? shallowReadonly(i.attrs) : i.attrs,
	$slots: (i) => !!("development" !== "production") ? shallowReadonly(i.slots) : i.slots,
	$refs: (i) => !!("development" !== "production") ? shallowReadonly(i.refs) : i.refs,
	$parent: (i) => getPublicInstance(i.parent),
	$root: (i) => getPublicInstance(i.root),
	$host: (i) => i.ce,
	$emit: (i) => i.emit,
	$options: (i) => __VUE_OPTIONS_API__ ? resolveMergedOptions(i) : i.type,
	$forceUpdate: (i) => i.f || (i.f = () => {
		queueJob(i.update);
	}),
	$nextTick: (i) => i.n || (i.n = nextTick.bind(i.proxy)),
	$watch: (i) => __VUE_OPTIONS_API__ ? instanceWatch.bind(i) : NOOP
});
const isReservedPrefix = (key) => key === "_" || key === "$";
const hasSetupBinding = (state, key) => state !== EMPTY_OBJ && !state.__isScriptSetup && hasOwn(state, key);
const PublicInstanceProxyHandlers = {
	get({ _: instance }, key) {
		if (key === "__v_skip") {
			return true;
		}
		const { ctx, setupState, data, props, accessCache, type, appContext } = instance;
		if (!!("development" !== "production") && key === "__isVue") {
			return true;
		}
		if (key[0] !== "$") {
			const n = accessCache[key];
			if (n !== void 0) {
				switch (n) {
					case 1: return setupState[key];
					case 2: return data[key];
					case 4: return ctx[key];
					case 3: return props[key];
				}
			} else if (hasSetupBinding(setupState, key)) {
				accessCache[key] = 1;
				return setupState[key];
			} else if (__VUE_OPTIONS_API__ && data !== EMPTY_OBJ && hasOwn(data, key)) {
				accessCache[key] = 2;
				return data[key];
			} else if (hasOwn(props, key)) {
				accessCache[key] = 3;
				return props[key];
			} else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
				accessCache[key] = 4;
				return ctx[key];
			} else if (!__VUE_OPTIONS_API__ || shouldCacheAccess) {
				accessCache[key] = 0;
			}
		}
		const publicGetter = publicPropertiesMap[key];
		let cssModule, globalProperties;
		if (publicGetter) {
			if (key === "$attrs") {
				track(instance.attrs, "get", "");
				!!("development" !== "production") && markAttrsAccessed();
			} else if (!!("development" !== "production") && key === "$slots") {
				track(instance, "get", key);
			}
			return publicGetter(instance);
		} else if ((cssModule = type.__cssModules) && (cssModule = cssModule[key])) {
			return cssModule;
		} else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
			accessCache[key] = 4;
			return ctx[key];
		} else if (globalProperties = appContext.config.globalProperties, hasOwn(globalProperties, key)) {
			{
				return globalProperties[key];
			}
		} else if (!!("development" !== "production") && currentRenderingInstance && (!isString(key) || key.indexOf("__v") !== 0)) {
			if (data !== EMPTY_OBJ && isReservedPrefix(key[0]) && hasOwn(data, key)) {
				warn$1(`Property ${JSON.stringify(key)} must be accessed via $data because it starts with a reserved character ("$" or "_") and is not proxied on the render context.`);
			} else if (instance === currentRenderingInstance) {
				warn$1(`Property ${JSON.stringify(key)} was accessed during render but is not defined on instance.`);
			}
		}
	},
	set({ _: instance }, key, value) {
		const { data, setupState, ctx } = instance;
		if (hasSetupBinding(setupState, key)) {
			setupState[key] = value;
			return true;
		} else if (!!("development" !== "production") && setupState.__isScriptSetup && hasOwn(setupState, key)) {
			warn$1(`Cannot mutate <script setup> binding "${key}" from Options API.`);
			return false;
		} else if (__VUE_OPTIONS_API__ && data !== EMPTY_OBJ && hasOwn(data, key)) {
			data[key] = value;
			return true;
		} else if (hasOwn(instance.props, key)) {
			!!("development" !== "production") && warn$1(`Attempting to mutate prop "${key}". Props are readonly.`);
			return false;
		}
		if (key[0] === "$" && key.slice(1) in instance) {
			!!("development" !== "production") && warn$1(`Attempting to mutate public property "${key}". Properties starting with $ are reserved and readonly.`);
			return false;
		} else {
			if (!!("development" !== "production") && key in instance.appContext.config.globalProperties) {
				Object.defineProperty(ctx, key, {
					enumerable: true,
					configurable: true,
					value
				});
			} else {
				ctx[key] = value;
			}
		}
		return true;
	},
	has({ _: { data, setupState, accessCache, ctx, appContext, props, type } }, key) {
		let cssModules;
		return !!(accessCache[key] || __VUE_OPTIONS_API__ && data !== EMPTY_OBJ && key[0] !== "$" && hasOwn(data, key) || hasSetupBinding(setupState, key) || hasOwn(props, key) || hasOwn(ctx, key) || hasOwn(publicPropertiesMap, key) || hasOwn(appContext.config.globalProperties, key) || (cssModules = type.__cssModules) && cssModules[key]);
	},
	defineProperty(target, key, descriptor) {
		if (descriptor.get != null) {
			target._.accessCache[key] = 0;
		} else if (hasOwn(descriptor, "value")) {
			this.set(target, key, descriptor.value, null);
		}
		return Reflect.defineProperty(target, key, descriptor);
	}
};
if (!!("development" !== "production") && true) {
	PublicInstanceProxyHandlers.ownKeys = (target) => {
		warn$1(`Avoid app logic that relies on enumerating keys on a component instance. The keys will be empty in production mode to avoid performance overhead.`);
		return Reflect.ownKeys(target);
	};
}
const RuntimeCompiledPublicInstanceProxyHandlers = /* @__PURE__ */ extend({}, PublicInstanceProxyHandlers, {
	get(target, key) {
		if (key === Symbol.unscopables) {
			return;
		}
		return PublicInstanceProxyHandlers.get(target, key, target);
	},
	has(_, key) {
		const has = key[0] !== "_" && !isGloballyAllowed(key);
		if (!!("development" !== "production") && !has && PublicInstanceProxyHandlers.has(_, key)) {
			warn$1(`Property ${JSON.stringify(key)} should not start with _ which is a reserved prefix for Vue internals.`);
		}
		return has;
	}
});
function createDevRenderContext(instance) {
	const target = {};
	Object.defineProperty(target, `_`, {
		configurable: true,
		enumerable: false,
		get: () => instance
	});
	Object.keys(publicPropertiesMap).forEach((key) => {
		Object.defineProperty(target, key, {
			configurable: true,
			enumerable: false,
			get: () => publicPropertiesMap[key](instance),
			// intercepted by the proxy so no need for implementation,
			// but needed to prevent set errors
			set: NOOP
		});
	});
	return target;
}
function exposePropsOnRenderContext(instance) {
	const { ctx, propsOptions: [propsOptions] } = instance;
	if (propsOptions) {
		Object.keys(propsOptions).forEach((key) => {
			Object.defineProperty(ctx, key, {
				enumerable: true,
				configurable: true,
				get: () => instance.props[key],
				set: NOOP
			});
		});
	}
}
function exposeSetupStateOnRenderContext(instance) {
	const { ctx, setupState } = instance;
	Object.keys(toRaw(setupState)).forEach((key) => {
		if (!setupState.__isScriptSetup) {
			if (isReservedPrefix(key[0])) {
				warn$1(`setup() return property ${JSON.stringify(key)} should not start with "$" or "_" which are reserved prefixes for Vue internals.`);
				return;
			}
			Object.defineProperty(ctx, key, {
				enumerable: true,
				configurable: true,
				get: () => setupState[key],
				set: NOOP
			});
		}
	});
}
const warnRuntimeUsage = (method) => warn$1(`${method}() is a compiler-hint helper that is only usable inside <script setup> of a single file component. Its arguments should be compiled away and passing it at runtime has no effect.`);
function defineProps() {
	if (!!("development" !== "production")) {
		warnRuntimeUsage(`defineProps`);
	}
	return null;
}
function defineEmits() {
	if (!!("development" !== "production")) {
		warnRuntimeUsage(`defineEmits`);
	}
	return null;
}
function defineExpose(exposed) {
	if (!!("development" !== "production")) {
		warnRuntimeUsage(`defineExpose`);
	}
}
function defineOptions(options) {
	if (!!("development" !== "production")) {
		warnRuntimeUsage(`defineOptions`);
	}
}
function defineSlots() {
	if (!!("development" !== "production")) {
		warnRuntimeUsage(`defineSlots`);
	}
	return null;
}
function defineModel() {
	if (!!("development" !== "production")) {
		warnRuntimeUsage("defineModel");
	}
}
function withDefaults(props, defaults) {
	if (!!("development" !== "production")) {
		warnRuntimeUsage(`withDefaults`);
	}
	return null;
}
function useSlots() {
	return getContext("useSlots").slots;
}
function useAttrs() {
	return getContext("useAttrs").attrs;
}
function getContext(calledFunctionName) {
	const i = getCurrentInstance();
	if (!!("development" !== "production") && !i) {
		warn$1(`${calledFunctionName}() called without active instance.`);
	}
	return i.setupContext || (i.setupContext = createSetupContext(i));
}
function normalizePropsOrEmits(props) {
	return isArray(props) ? props.reduce((normalized, p) => (normalized[p] = null, normalized), {}) : props;
}
function mergeDefaults(raw, defaults) {
	const props = normalizePropsOrEmits(raw);
	for (const key in defaults) {
		if (key.startsWith("__skip")) continue;
		let opt = props[key];
		if (opt) {
			if (isArray(opt) || isFunction(opt)) {
				opt = props[key] = {
					type: opt,
					default: defaults[key]
				};
			} else {
				opt.default = defaults[key];
			}
		} else if (opt === null) {
			opt = props[key] = { default: defaults[key] };
		} else if (!!("development" !== "production")) {
			warn$1(`props default key "${key}" has no corresponding declaration.`);
		}
		if (opt && defaults[`__skip_${key}`]) {
			opt.skipFactory = true;
		}
	}
	return props;
}
function mergeModels(a, b) {
	if (!a || !b) return a || b;
	if (isArray(a) && isArray(b)) return a.concat(b);
	return extend({}, normalizePropsOrEmits(a), normalizePropsOrEmits(b));
}
function createPropsRestProxy(props, excludedKeys) {
	const ret = {};
	for (const key in props) {
		if (!excludedKeys.includes(key)) {
			Object.defineProperty(ret, key, {
				enumerable: true,
				get: () => props[key]
			});
		}
	}
	return ret;
}
function withAsyncContext(getAwaitable) {
	const ctx = getCurrentInstance();
	const inSSRSetup = isInSSRComponentSetup;
	if (!!("development" !== "production") && !ctx) {
		warn$1(`withAsyncContext called without active current instance. This is likely a bug.`);
	}
	let awaitable = getAwaitable();
	unsetCurrentInstance();
	if (inSSRSetup) {
		setInSSRSetupState(false);
	}
	const restore = () => {
		setCurrentInstance(ctx);
		if (inSSRSetup) {
			setInSSRSetupState(true);
		}
	};
	const cleanup = () => {
		if (getCurrentInstance() !== ctx) ctx.scope.off();
		unsetCurrentInstance();
		if (inSSRSetup) {
			setInSSRSetupState(false);
		}
	};
	if (isPromise(awaitable)) {
		awaitable = awaitable.catch((e) => {
			restore();
			Promise.resolve().then(() => Promise.resolve().then(cleanup));
			throw e;
		});
	}
	return [awaitable, () => {
		restore();
		Promise.resolve().then(cleanup);
	}];
}
function createDuplicateChecker() {
	const cache = /* @__PURE__ */ Object.create(null);
	return (type, key) => {
		if (cache[key]) {
			warn$1(`${type} property "${key}" is already defined in ${cache[key]}.`);
		} else {
			cache[key] = type;
		}
	};
}
let shouldCacheAccess = true;
function applyOptions(instance) {
	const options = resolveMergedOptions(instance);
	const publicThis = instance.proxy;
	const ctx = instance.ctx;
	shouldCacheAccess = false;
	if (options.beforeCreate) {
		callHook(options.beforeCreate, instance, "bc");
	}
	const { data: dataOptions, computed: computedOptions, methods, watch: watchOptions, provide: provideOptions, inject: injectOptions, created, beforeMount, mounted, beforeUpdate, updated, activated, deactivated, beforeDestroy, beforeUnmount, destroyed, unmounted, render, renderTracked, renderTriggered, errorCaptured, serverPrefetch, expose, inheritAttrs, components, directives, filters } = options;
	const checkDuplicateProperties = !!("development" !== "production") ? createDuplicateChecker() : null;
	if (!!("development" !== "production")) {
		const [propsOptions] = instance.propsOptions;
		if (propsOptions) {
			for (const key in propsOptions) {
				checkDuplicateProperties("Props", key);
			}
		}
	}
	if (injectOptions) {
		resolveInjections(injectOptions, ctx, checkDuplicateProperties);
	}
	if (methods) {
		for (const key in methods) {
			const methodHandler = methods[key];
			if (isFunction(methodHandler)) {
				if (!!("development" !== "production")) {
					Object.defineProperty(ctx, key, {
						value: methodHandler.bind(publicThis),
						configurable: true,
						enumerable: true,
						writable: true
					});
				} else {
					ctx[key] = methodHandler.bind(publicThis);
				}
				if (!!("development" !== "production")) {
					checkDuplicateProperties("Methods", key);
				}
			} else if (!!("development" !== "production")) {
				warn$1(`Method "${key}" has type "${typeof methodHandler}" in the component definition. Did you reference the function correctly?`);
			}
		}
	}
	if (dataOptions) {
		if (!!("development" !== "production") && !isFunction(dataOptions)) {
			warn$1(`The data option must be a function. Plain object usage is no longer supported.`);
		}
		const data = dataOptions.call(publicThis, publicThis);
		if (!!("development" !== "production") && isPromise(data)) {
			warn$1(`data() returned a Promise - note data() cannot be async; If you intend to perform data fetching before component renders, use async setup() + <Suspense>.`);
		}
		if (!isObject(data)) {
			!!("development" !== "production") && warn$1(`data() should return an object.`);
		} else {
			instance.data = reactive(data);
			if (!!("development" !== "production")) {
				for (const key in data) {
					checkDuplicateProperties("Data", key);
					if (!isReservedPrefix(key[0])) {
						Object.defineProperty(ctx, key, {
							configurable: true,
							enumerable: true,
							get: () => data[key],
							set: NOOP
						});
					}
				}
			}
		}
	}
	shouldCacheAccess = true;
	if (computedOptions) {
		for (const key in computedOptions) {
			const opt = computedOptions[key];
			const get = isFunction(opt) ? opt.bind(publicThis, publicThis) : isFunction(opt.get) ? opt.get.bind(publicThis, publicThis) : NOOP;
			if (!!("development" !== "production") && get === NOOP) {
				warn$1(`Computed property "${key}" has no getter.`);
			}
			const set = !isFunction(opt) && isFunction(opt.set) ? opt.set.bind(publicThis) : !!("development" !== "production") ? () => {
				warn$1(`Write operation failed: computed property "${key}" is readonly.`);
			} : NOOP;
			const c = computed({
				get,
				set
			});
			Object.defineProperty(ctx, key, {
				enumerable: true,
				configurable: true,
				get: () => c.value,
				set: (v) => c.value = v
			});
			if (!!("development" !== "production")) {
				checkDuplicateProperties("Computed", key);
			}
		}
	}
	if (watchOptions) {
		for (const key in watchOptions) {
			createWatcher(watchOptions[key], ctx, publicThis, key);
		}
	}
	if (provideOptions) {
		const provides = isFunction(provideOptions) ? provideOptions.call(publicThis) : provideOptions;
		Reflect.ownKeys(provides).forEach((key) => {
			provide(key, provides[key]);
		});
	}
	if (created) {
		callHook(created, instance, "c");
	}
	function registerLifecycleHook(register, hook) {
		if (isArray(hook)) {
			hook.forEach((_hook) => register(_hook.bind(publicThis)));
		} else if (hook) {
			register(hook.bind(publicThis));
		}
	}
	registerLifecycleHook(onBeforeMount, beforeMount);
	registerLifecycleHook(onMounted, mounted);
	registerLifecycleHook(onBeforeUpdate, beforeUpdate);
	registerLifecycleHook(onUpdated, updated);
	registerLifecycleHook(onActivated, activated);
	registerLifecycleHook(onDeactivated, deactivated);
	registerLifecycleHook(onErrorCaptured, errorCaptured);
	registerLifecycleHook(onRenderTracked, renderTracked);
	registerLifecycleHook(onRenderTriggered, renderTriggered);
	registerLifecycleHook(onBeforeUnmount, beforeUnmount);
	registerLifecycleHook(onUnmounted, unmounted);
	registerLifecycleHook(onServerPrefetch, serverPrefetch);
	if (isArray(expose)) {
		if (expose.length) {
			const exposed = instance.exposed || (instance.exposed = {});
			expose.forEach((key) => {
				Object.defineProperty(exposed, key, {
					get: () => publicThis[key],
					set: (val) => publicThis[key] = val,
					enumerable: true
				});
			});
		} else if (!instance.exposed) {
			instance.exposed = {};
		}
	}
	if (render && instance.render === NOOP) {
		instance.render = render;
	}
	if (inheritAttrs != null) {
		instance.inheritAttrs = inheritAttrs;
	}
	if (components) instance.components = components;
	if (directives) instance.directives = directives;
	if (serverPrefetch) {
		markAsyncBoundary(instance);
	}
}
function resolveInjections(injectOptions, ctx, checkDuplicateProperties = NOOP) {
	if (isArray(injectOptions)) {
		injectOptions = normalizeInject(injectOptions);
	}
	for (const key in injectOptions) {
		const opt = injectOptions[key];
		let injected;
		if (isObject(opt)) {
			if ("default" in opt) {
				injected = inject(opt.from || key, opt.default, true);
			} else {
				injected = inject(opt.from || key);
			}
		} else {
			injected = inject(opt);
		}
		if (isRef(injected)) {
			Object.defineProperty(ctx, key, {
				enumerable: true,
				configurable: true,
				get: () => injected.value,
				set: (v) => injected.value = v
			});
		} else {
			ctx[key] = injected;
		}
		if (!!("development" !== "production")) {
			checkDuplicateProperties("Inject", key);
		}
	}
}
function callHook(hook, instance, type) {
	callWithAsyncErrorHandling(isArray(hook) ? hook.map((h) => h.bind(instance.proxy)) : hook.bind(instance.proxy), instance, type);
}
function createWatcher(raw, ctx, publicThis, key) {
	let getter = key.includes(".") ? createPathGetter(publicThis, key) : () => publicThis[key];
	if (isString(raw)) {
		const handler = ctx[raw];
		if (isFunction(handler)) {
			{
				watch(getter, handler);
			}
		} else if (!!("development" !== "production")) {
			warn$1(`Invalid watch handler specified by key "${raw}"`, handler);
		}
	} else if (isFunction(raw)) {
		{
			watch(getter, raw.bind(publicThis));
		}
	} else if (isObject(raw)) {
		if (isArray(raw)) {
			raw.forEach((r) => createWatcher(r, ctx, publicThis, key));
		} else {
			const handler = isFunction(raw.handler) ? raw.handler.bind(publicThis) : ctx[raw.handler];
			if (isFunction(handler)) {
				watch(getter, handler, raw);
			} else if (!!("development" !== "production")) {
				warn$1(`Invalid watch handler specified by key "${raw.handler}"`, handler);
			}
		}
	} else if (!!("development" !== "production")) {
		warn$1(`Invalid watch option: "${key}"`, raw);
	}
}
function resolveMergedOptions(instance) {
	const base = instance.type;
	const { mixins, extends: extendsOptions } = base;
	const { mixins: globalMixins, optionsCache: cache, config: { optionMergeStrategies } } = instance.appContext;
	const cached = cache.get(base);
	let resolved;
	if (cached) {
		resolved = cached;
	} else if (!globalMixins.length && !mixins && !extendsOptions) {
		{
			resolved = base;
		}
	} else {
		resolved = {};
		if (globalMixins.length) {
			globalMixins.forEach((m) => mergeOptions(resolved, m, optionMergeStrategies, true));
		}
		mergeOptions(resolved, base, optionMergeStrategies);
	}
	if (isObject(base)) {
		cache.set(base, resolved);
	}
	return resolved;
}
function mergeOptions(to, from, strats, asMixin = false) {
	const { mixins, extends: extendsOptions } = from;
	if (extendsOptions) {
		mergeOptions(to, extendsOptions, strats, true);
	}
	if (mixins) {
		mixins.forEach((m) => mergeOptions(to, m, strats, true));
	}
	for (const key in from) {
		if (asMixin && key === "expose") {
			!!("development" !== "production") && warn$1(`"expose" option is ignored when declared in mixins or extends. It should only be declared in the base component itself.`);
		} else {
			const strat = internalOptionMergeStrats[key] || strats && strats[key];
			to[key] = strat ? strat(to[key], from[key]) : from[key];
		}
	}
	return to;
}
const internalOptionMergeStrats = {
	data: mergeDataFn,
	props: mergeEmitsOrPropsOptions,
	emits: mergeEmitsOrPropsOptions,
	// objects
	methods: mergeObjectOptions,
	computed: mergeObjectOptions,
	// lifecycle
	beforeCreate: mergeAsArray,
	created: mergeAsArray,
	beforeMount: mergeAsArray,
	mounted: mergeAsArray,
	beforeUpdate: mergeAsArray,
	updated: mergeAsArray,
	beforeDestroy: mergeAsArray,
	beforeUnmount: mergeAsArray,
	destroyed: mergeAsArray,
	unmounted: mergeAsArray,
	activated: mergeAsArray,
	deactivated: mergeAsArray,
	errorCaptured: mergeAsArray,
	serverPrefetch: mergeAsArray,
	// assets
	components: mergeObjectOptions,
	directives: mergeObjectOptions,
	// watch
	watch: mergeWatchOptions,
	// provide / inject
	provide: mergeDataFn,
	inject: mergeInject
};
function mergeDataFn(to, from) {
	if (!from) {
		return to;
	}
	if (!to) {
		return from;
	}
	return function mergedDataFn() {
		return extend(isFunction(to) ? to.call(this, this) : to, isFunction(from) ? from.call(this, this) : from);
	};
}
function mergeInject(to, from) {
	return mergeObjectOptions(normalizeInject(to), normalizeInject(from));
}
function normalizeInject(raw) {
	if (isArray(raw)) {
		const res = {};
		for (let i = 0; i < raw.length; i++) {
			res[raw[i]] = raw[i];
		}
		return res;
	}
	return raw;
}
function mergeAsArray(to, from) {
	return to ? [...new Set([].concat(to, from))] : from;
}
function mergeObjectOptions(to, from) {
	return to ? extend(/* @__PURE__ */ Object.create(null), to, from) : from;
}
function mergeEmitsOrPropsOptions(to, from) {
	if (to) {
		if (isArray(to) && isArray(from)) {
			return [.../* @__PURE__ */ new Set([...to, ...from])];
		}
		return extend(/* @__PURE__ */ Object.create(null), normalizePropsOrEmits(to), normalizePropsOrEmits(from != null ? from : {}));
	} else {
		return from;
	}
}
function mergeWatchOptions(to, from) {
	if (!to) return from;
	if (!from) return to;
	const merged = extend(/* @__PURE__ */ Object.create(null), to);
	for (const key in from) {
		merged[key] = mergeAsArray(to[key], from[key]);
	}
	return merged;
}
function createAppContext() {
	return {
		app: null,
		config: {
			isNativeTag: NO,
			performance: false,
			globalProperties: {},
			optionMergeStrategies: {},
			errorHandler: void 0,
			warnHandler: void 0,
			compilerOptions: {}
		},
		mixins: [],
		components: {},
		directives: {},
		provides: /* @__PURE__ */ Object.create(null),
		optionsCache: /* @__PURE__ */ new WeakMap(),
		propsCache: /* @__PURE__ */ new WeakMap(),
		emitsCache: /* @__PURE__ */ new WeakMap()
	};
}
let uid$1 = 0;
function createAppAPI(render, hydrate) {
	return function createApp(rootComponent, rootProps = null) {
		if (!isFunction(rootComponent)) {
			rootComponent = extend({}, rootComponent);
		}
		if (rootProps != null && !isObject(rootProps)) {
			!!("development" !== "production") && warn$1(`root props passed to app.mount() must be an object.`);
			rootProps = null;
		}
		const context = createAppContext();
		const installedPlugins = /* @__PURE__ */ new WeakSet();
		const pluginCleanupFns = [];
		let isMounted = false;
		const app = context.app = {
			_uid: uid$1++,
			_component: rootComponent,
			_props: rootProps,
			_container: null,
			_context: context,
			_instance: null,
			version,
			get config() {
				return context.config;
			},
			set config(v) {
				if (!!("development" !== "production")) {
					warn$1(`app.config cannot be replaced. Modify individual options instead.`);
				}
			},
			use(plugin, ...options) {
				if (installedPlugins.has(plugin)) {
					!!("development" !== "production") && warn$1(`Plugin has already been applied to target app.`);
				} else if (plugin && isFunction(plugin.install)) {
					installedPlugins.add(plugin);
					plugin.install(app, ...options);
				} else if (isFunction(plugin)) {
					installedPlugins.add(plugin);
					plugin(app, ...options);
				} else if (!!("development" !== "production")) {
					warn$1(`A plugin must either be a function or an object with an "install" function.`);
				}
				return app;
			},
			mixin(mixin) {
				if (__VUE_OPTIONS_API__) {
					if (!context.mixins.includes(mixin)) {
						context.mixins.push(mixin);
					} else if (!!("development" !== "production")) {
						warn$1("Mixin has already been applied to target app" + (mixin.name ? `: ${mixin.name}` : ""));
					}
				} else if (!!("development" !== "production")) {
					warn$1("Mixins are only available in builds supporting Options API");
				}
				return app;
			},
			component(name, component) {
				if (!!("development" !== "production")) {
					validateComponentName(name, context.config);
				}
				if (!component) {
					return context.components[name];
				}
				if (!!("development" !== "production") && context.components[name]) {
					warn$1(`Component "${name}" has already been registered in target app.`);
				}
				context.components[name] = component;
				return app;
			},
			directive(name, directive) {
				if (!!("development" !== "production")) {
					validateDirectiveName(name);
				}
				if (!directive) {
					return context.directives[name];
				}
				if (!!("development" !== "production") && context.directives[name]) {
					warn$1(`Directive "${name}" has already been registered in target app.`);
				}
				context.directives[name] = directive;
				return app;
			},
			mount(rootContainer, isHydrate, namespace) {
				if (!isMounted) {
					if (!!("development" !== "production") && rootContainer.__vue_app__) {
						warn$1(`There is already an app instance mounted on the host container.
 If you want to mount another app on the same host container, you need to unmount the previous app by calling \`app.unmount()\` first.`);
					}
					const vnode = app._ceVNode || createVNode(rootComponent, rootProps);
					vnode.appContext = context;
					if (namespace === true) {
						namespace = "svg";
					} else if (namespace === false) {
						namespace = void 0;
					}
					if (!!("development" !== "production")) {
						context.reload = () => {
							const cloned = cloneVNode(vnode);
							cloned.el = null;
							render(cloned, rootContainer, namespace);
						};
					}
					if (isHydrate && hydrate) {
						hydrate(vnode, rootContainer);
					} else {
						render(vnode, rootContainer, namespace);
					}
					isMounted = true;
					app._container = rootContainer;
					rootContainer.__vue_app__ = app;
					if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
						app._instance = vnode.component;
						devtoolsInitApp(app, version);
					}
					return getComponentPublicInstance(vnode.component);
				} else if (!!("development" !== "production")) {
					warn$1(`App has already been mounted.
If you want to remount the same app, move your app creation logic into a factory function and create fresh app instances for each mount - e.g. \`const createMyApp = () => createApp(App)\``);
				}
			},
			onUnmount(cleanupFn) {
				if (!!("development" !== "production") && typeof cleanupFn !== "function") {
					warn$1(`Expected function as first argument to app.onUnmount(), but got ${typeof cleanupFn}`);
				}
				pluginCleanupFns.push(cleanupFn);
			},
			unmount() {
				if (isMounted) {
					callWithAsyncErrorHandling(pluginCleanupFns, app._instance, 16);
					render(null, app._container);
					if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
						app._instance = null;
						devtoolsUnmountApp(app);
					}
					delete app._container.__vue_app__;
				} else if (!!("development" !== "production")) {
					warn$1(`Cannot unmount an app that is not mounted.`);
				}
			},
			provide(key, value) {
				if (!!("development" !== "production") && key in context.provides) {
					if (hasOwn(context.provides, key)) {
						warn$1(`App already provides property with key "${String(key)}". It will be overwritten with the new value.`);
					} else {
						warn$1(`App already provides property with key "${String(key)}" inherited from its parent element. It will be overwritten with the new value.`);
					}
				}
				context.provides[key] = value;
				return app;
			},
			runWithContext(fn) {
				const lastApp = currentApp;
				currentApp = app;
				try {
					return fn();
				} finally {
					currentApp = lastApp;
				}
			}
		};
		return app;
	};
}
let currentApp = null;
function useModel(props, name, options = EMPTY_OBJ) {
	const i = getCurrentInstance();
	if (!!("development" !== "production") && !i) {
		warn$1(`useModel() called without active instance.`);
		return ref();
	}
	const camelizedName = camelize(name);
	if (!!("development" !== "production") && !i.propsOptions[0][camelizedName]) {
		warn$1(`useModel() called with prop "${name}" which is not declared.`);
		return ref();
	}
	const hyphenatedName = hyphenate(name);
	const modifiers = getModelModifiers(props, camelizedName);
	const res = customRef((track, trigger) => {
		let localValue;
		let prevSetValue = EMPTY_OBJ;
		let prevEmittedValue;
		watchSyncEffect(() => {
			const propValue = props[camelizedName];
			if (hasChanged(localValue, propValue)) {
				localValue = propValue;
				trigger();
			}
		});
		return {
			get() {
				track();
				return options.get ? options.get(localValue) : localValue;
			},
			set(value) {
				const emittedValue = options.set ? options.set(value) : value;
				if (!hasChanged(emittedValue, localValue) && !(prevSetValue !== EMPTY_OBJ && hasChanged(value, prevSetValue))) {
					return;
				}
				const rawProps = i.vnode.props;
				const hasVModel = !!(rawProps && (name in rawProps || camelizedName in rawProps || hyphenatedName in rawProps) && (`onUpdate:${name}` in rawProps || `onUpdate:${camelizedName}` in rawProps || `onUpdate:${hyphenatedName}` in rawProps));
				if (!hasVModel) {
					localValue = value;
					trigger();
				}
				i.emit(`update:${name}`, emittedValue);
				if (hasChanged(value, prevSetValue) && (hasChanged(value, emittedValue) && !hasChanged(emittedValue, prevEmittedValue) || hasVModel && prevSetValue !== EMPTY_OBJ && !hasChanged(emittedValue, localValue))) {
					trigger();
				}
				prevSetValue = value;
				prevEmittedValue = emittedValue;
			}
		};
	});
	res[Symbol.iterator] = () => {
		let i2 = 0;
		return { next() {
			if (i2 < 2) {
				return {
					value: i2++ ? modifiers || EMPTY_OBJ : res,
					done: false
				};
			} else {
				return { done: true };
			}
		} };
	};
	return res;
}
const getModelModifiers = (props, modelName) => {
	return modelName === "modelValue" || modelName === "model-value" ? props.modelModifiers : props[`${modelName}Modifiers`] || props[`${camelize(modelName)}Modifiers`] || props[`${hyphenate(modelName)}Modifiers`];
};
function emit(instance, event, ...rawArgs) {
	if (instance.isUnmounted) return;
	const props = instance.vnode.props || EMPTY_OBJ;
	if (!!("development" !== "production")) {
		const { emitsOptions, propsOptions: [propsOptions] } = instance;
		if (emitsOptions) {
			if (!(event in emitsOptions) && true) {
				if (!propsOptions || !(toHandlerKey(camelize(event)) in propsOptions)) {
					warn$1(`Component emitted event "${event}" but it is neither declared in the emits option nor as an "${toHandlerKey(camelize(event))}" prop.`);
				}
			} else {
				const validator = emitsOptions[event];
				if (isFunction(validator)) {
					const isValid = validator(...rawArgs);
					if (!isValid) {
						warn$1(`Invalid event arguments: event validation failed for event "${event}".`);
					}
				}
			}
		}
	}
	let args = rawArgs;
	const isModelListener = event.startsWith("update:");
	const modifiers = isModelListener && getModelModifiers(props, event.slice(7));
	if (modifiers) {
		if (modifiers.trim) {
			args = rawArgs.map((a) => isString(a) ? a.trim() : a);
		}
		if (modifiers.number) {
			args = rawArgs.map(looseToNumber);
		}
	}
	if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
		devtoolsComponentEmit(instance, event, args);
	}
	if (!!("development" !== "production")) {
		const lowerCaseEvent = event.toLowerCase();
		if (lowerCaseEvent !== event && props[toHandlerKey(lowerCaseEvent)]) {
			warn$1(`Event "${lowerCaseEvent}" is emitted in component ${formatComponentName(instance, instance.type)} but the handler is registered for "${event}". Note that HTML attributes are case-insensitive and you cannot use v-on to listen to camelCase events when using in-DOM templates. You should probably use "${hyphenate(event)}" instead of "${event}".`);
		}
	}
	let handlerName;
	let handler = props[handlerName = toHandlerKey(event)] || props[handlerName = toHandlerKey(camelize(event))];
	if (!handler && isModelListener) {
		handler = props[handlerName = toHandlerKey(hyphenate(event))];
	}
	if (handler) {
		callWithAsyncErrorHandling(handler, instance, 6, args);
	}
	const onceHandler = props[handlerName + `Once`];
	if (onceHandler) {
		if (!instance.emitted) {
			instance.emitted = {};
		} else if (instance.emitted[handlerName]) {
			return;
		}
		instance.emitted[handlerName] = true;
		callWithAsyncErrorHandling(onceHandler, instance, 6, args);
	}
}
const mixinEmitsCache = /* @__PURE__ */ new WeakMap();
function normalizeEmitsOptions(comp, appContext, asMixin = false) {
	const cache = __VUE_OPTIONS_API__ && asMixin ? mixinEmitsCache : appContext.emitsCache;
	const cached = cache.get(comp);
	if (cached !== void 0) {
		return cached;
	}
	const raw = comp.emits;
	let normalized = {};
	let hasExtends = false;
	if (__VUE_OPTIONS_API__ && !isFunction(comp)) {
		const extendEmits = (raw2) => {
			const normalizedFromExtend = normalizeEmitsOptions(raw2, appContext, true);
			if (normalizedFromExtend) {
				hasExtends = true;
				extend(normalized, normalizedFromExtend);
			}
		};
		if (!asMixin && appContext.mixins.length) {
			appContext.mixins.forEach(extendEmits);
		}
		if (comp.extends) {
			extendEmits(comp.extends);
		}
		if (comp.mixins) {
			comp.mixins.forEach(extendEmits);
		}
	}
	if (!raw && !hasExtends) {
		if (isObject(comp)) {
			cache.set(comp, null);
		}
		return null;
	}
	if (isArray(raw)) {
		raw.forEach((key) => normalized[key] = null);
	} else {
		extend(normalized, raw);
	}
	if (isObject(comp)) {
		cache.set(comp, normalized);
	}
	return normalized;
}
function isEmitListener(options, key) {
	if (!options || !isOn(key)) {
		return false;
	}
	key = key.slice(2);
	key = key === "Once" ? key : key.replace(/Once$/, "");
	return hasOwn(options, key[0].toLowerCase() + key.slice(1)) || hasOwn(options, hyphenate(key)) || hasOwn(options, key);
}
let accessedAttrs = false;
function markAttrsAccessed() {
	accessedAttrs = true;
}
function renderComponentRoot(instance) {
	const { type: Component, vnode, proxy, withProxy, propsOptions: [propsOptions], slots, attrs, emit, render, renderCache, props, data, setupState, ctx, inheritAttrs } = instance;
	const prev = setCurrentRenderingInstance(instance);
	let result;
	let fallthroughAttrs;
	if (!!("development" !== "production")) {
		accessedAttrs = false;
	}
	try {
		if (vnode.shapeFlag & 4) {
			const proxyToUse = withProxy || proxy;
			const thisProxy = !!("development" !== "production") && setupState.__isScriptSetup ? new Proxy(proxyToUse, { get(target, key, receiver) {
				warn$1(`Property '${String(key)}' was accessed via 'this'. Avoid using 'this' in templates.`);
				return Reflect.get(target, key, receiver);
			} }) : proxyToUse;
			result = normalizeVNode(render.call(thisProxy, proxyToUse, renderCache, !!("development" !== "production") ? shallowReadonly(props) : props, setupState, data, ctx));
			fallthroughAttrs = attrs;
		} else {
			const render2 = Component;
			if (!!("development" !== "production") && attrs === props) {
				markAttrsAccessed();
			}
			result = normalizeVNode(render2.length > 1 ? render2(!!("development" !== "production") ? shallowReadonly(props) : props, !!("development" !== "production") ? {
				get attrs() {
					markAttrsAccessed();
					return shallowReadonly(attrs);
				},
				slots,
				emit
			} : {
				attrs,
				slots,
				emit
			}) : render2(!!("development" !== "production") ? shallowReadonly(props) : props, null));
			fallthroughAttrs = Component.props ? attrs : getFunctionalFallthrough(attrs);
		}
	} catch (err) {
		blockStack.length = 0;
		handleError(err, instance, 1);
		result = createVNode(Comment);
	}
	let root = result;
	let setRoot = void 0;
	if (!!("development" !== "production") && result.patchFlag > 0 && result.patchFlag & 2048) {
		[root, setRoot] = getChildRoot(result);
	}
	if (fallthroughAttrs && inheritAttrs !== false) {
		const keys = Object.keys(fallthroughAttrs);
		const { shapeFlag } = root;
		if (keys.length) {
			if (shapeFlag & (1 | 6)) {
				if (propsOptions && keys.some(isModelListener)) {
					fallthroughAttrs = filterModelListeners(fallthroughAttrs, propsOptions);
				}
				root = cloneVNode(root, fallthroughAttrs, false, true);
			} else if (!!("development" !== "production") && !accessedAttrs && root.type !== Comment) {
				const allAttrs = Object.keys(attrs);
				const eventAttrs = [];
				const extraAttrs = [];
				for (let i = 0, l = allAttrs.length; i < l; i++) {
					const key = allAttrs[i];
					if (isOn(key)) {
						if (!isModelListener(key)) {
							eventAttrs.push(key[2].toLowerCase() + key.slice(3));
						}
					} else {
						extraAttrs.push(key);
					}
				}
				if (extraAttrs.length) {
					warn$1(`Extraneous non-props attributes (${extraAttrs.join(", ")}) were passed to component but could not be automatically inherited because component renders fragment or text or teleport root nodes.`);
				}
				if (eventAttrs.length) {
					warn$1(`Extraneous non-emits event listeners (${eventAttrs.join(", ")}) were passed to component but could not be automatically inherited because component renders fragment or text root nodes. If the listener is intended to be a component custom event listener only, declare it using the "emits" option.`);
				}
			}
		}
	}
	if (vnode.dirs) {
		if (!!("development" !== "production") && !isElementRoot(root)) {
			warn$1(`Runtime directive used on component with non-element root node. The directives will not function as intended.`);
		}
		root = cloneVNode(root, null, false, true);
		root.dirs = root.dirs ? root.dirs.concat(vnode.dirs) : vnode.dirs;
	}
	if (vnode.transition) {
		if (!!("development" !== "production") && !isElementRoot(root)) {
			warn$1(`Component inside <Transition> renders non-element root node that cannot be animated.`);
		}
		setTransitionHooks(root, vnode.transition);
	}
	if (!!("development" !== "production") && setRoot) {
		setRoot(root);
	} else {
		result = root;
	}
	setCurrentRenderingInstance(prev);
	return result;
}
const getChildRoot = (vnode) => {
	const rawChildren = vnode.children;
	const dynamicChildren = vnode.dynamicChildren;
	const childRoot = filterSingleRoot(rawChildren, false);
	if (!childRoot) {
		return [vnode, void 0];
	} else if (!!("development" !== "production") && childRoot.patchFlag > 0 && childRoot.patchFlag & 2048) {
		return getChildRoot(childRoot);
	}
	const index = rawChildren.indexOf(childRoot);
	const dynamicIndex = dynamicChildren ? dynamicChildren.indexOf(childRoot) : -1;
	const setRoot = (updatedRoot) => {
		rawChildren[index] = updatedRoot;
		if (dynamicChildren) {
			if (dynamicIndex > -1) {
				dynamicChildren[dynamicIndex] = updatedRoot;
			} else if (updatedRoot.patchFlag > 0) {
				vnode.dynamicChildren = [...dynamicChildren, updatedRoot];
			}
		}
	};
	return [normalizeVNode(childRoot), setRoot];
};
function filterSingleRoot(children, recurse = true) {
	let singleRoot;
	for (let i = 0; i < children.length; i++) {
		const child = children[i];
		if (isVNode(child)) {
			if (child.type !== Comment || child.children === "v-if") {
				if (singleRoot) {
					return;
				} else {
					singleRoot = child;
					if (!!("development" !== "production") && recurse && singleRoot.patchFlag > 0 && singleRoot.patchFlag & 2048) {
						return filterSingleRoot(singleRoot.children);
					}
				}
			}
		} else {
			return;
		}
	}
	return singleRoot;
}
const getFunctionalFallthrough = (attrs) => {
	let res;
	for (const key in attrs) {
		if (key === "class" || key === "style" || isOn(key)) {
			(res || (res = {}))[key] = attrs[key];
		}
	}
	return res;
};
const filterModelListeners = (attrs, props) => {
	const res = {};
	for (const key in attrs) {
		if (!isModelListener(key) || !(key.slice(9) in props)) {
			res[key] = attrs[key];
		}
	}
	return res;
};
const isElementRoot = (vnode) => {
	return vnode.shapeFlag & (6 | 1) || vnode.type === Comment;
};
function shouldUpdateComponent(prevVNode, nextVNode, optimized) {
	const { props: prevProps, children: prevChildren, component } = prevVNode;
	const { props: nextProps, children: nextChildren, patchFlag } = nextVNode;
	const emits = component.emitsOptions;
	if (!!("development" !== "production") && (prevChildren || nextChildren) && isHmrUpdating) {
		return true;
	}
	if (nextVNode.dirs || nextVNode.transition) {
		return true;
	}
	if (optimized && patchFlag >= 0) {
		if (patchFlag & 1024) {
			return true;
		}
		if (patchFlag & 16) {
			if (!prevProps) {
				return !!nextProps;
			}
			return hasPropsChanged(prevProps, nextProps, emits);
		} else if (patchFlag & 8) {
			const dynamicProps = nextVNode.dynamicProps;
			for (let i = 0; i < dynamicProps.length; i++) {
				const key = dynamicProps[i];
				if (hasPropValueChanged(nextProps, prevProps, key) && !isEmitListener(emits, key)) {
					return true;
				}
			}
		}
	} else {
		if (prevChildren || nextChildren) {
			if (!nextChildren || !nextChildren.$stable) {
				return true;
			}
		}
		if (prevProps === nextProps) {
			return false;
		}
		if (!prevProps) {
			return !!nextProps;
		}
		if (!nextProps) {
			return true;
		}
		return hasPropsChanged(prevProps, nextProps, emits);
	}
	return false;
}
function hasPropsChanged(prevProps, nextProps, emitsOptions) {
	const nextKeys = Object.keys(nextProps);
	if (nextKeys.length !== Object.keys(prevProps).length) {
		return true;
	}
	for (let i = 0; i < nextKeys.length; i++) {
		const key = nextKeys[i];
		if (hasPropValueChanged(nextProps, prevProps, key) && !isEmitListener(emitsOptions, key)) {
			return true;
		}
	}
	return false;
}
function hasPropValueChanged(nextProps, prevProps, key) {
	const nextProp = nextProps[key];
	const prevProp = prevProps[key];
	if (key === "style" && isObject(nextProp) && isObject(prevProp)) {
		return !looseEqual(nextProp, prevProp);
	}
	return nextProp !== prevProp;
}
function updateHOCHostEl({ vnode, parent, suspense }, el) {
	while (parent) {
		const root = parent.subTree;
		if (root.suspense && root.suspense.activeBranch === vnode) {
			root.suspense.vnode.el = root.el = el;
			vnode = root;
		}
		if (root === vnode) {
			(vnode = parent.vnode).el = el;
			parent = parent.parent;
		} else {
			break;
		}
	}
	if (suspense && suspense.activeBranch === vnode) {
		suspense.vnode.el = el;
	}
}
const internalObjectProto = {};
const createInternalObject = () => Object.create(internalObjectProto);
const isInternalObject = (obj) => Object.getPrototypeOf(obj) === internalObjectProto;
function initProps(instance, rawProps, isStateful, isSSR = false) {
	const props = {};
	const attrs = createInternalObject();
	instance.propsDefaults = /* @__PURE__ */ Object.create(null);
	setFullProps(instance, rawProps, props, attrs);
	for (const key in instance.propsOptions[0]) {
		if (!(key in props)) {
			props[key] = void 0;
		}
	}
	if (!!("development" !== "production")) {
		validateProps(rawProps || {}, props, instance);
	}
	if (isStateful) {
		instance.props = isSSR ? props : shallowReactive(props);
	} else {
		if (!instance.type.props) {
			instance.props = attrs;
		} else {
			instance.props = props;
		}
	}
	instance.attrs = attrs;
}
function isInHmrContext(instance) {
	while (instance) {
		if (instance.type.__hmrId) return true;
		instance = instance.parent;
	}
}
function updateProps(instance, rawProps, rawPrevProps, optimized) {
	const { props, attrs, vnode: { patchFlag } } = instance;
	const rawCurrentProps = toRaw(props);
	const [options] = instance.propsOptions;
	let hasAttrsChanged = false;
	if (!(!!("development" !== "production") && isInHmrContext(instance)) && (optimized || patchFlag > 0) && !(patchFlag & 16)) {
		if (patchFlag & 8) {
			const propsToUpdate = instance.vnode.dynamicProps;
			for (let i = 0; i < propsToUpdate.length; i++) {
				let key = propsToUpdate[i];
				if (isEmitListener(instance.emitsOptions, key)) {
					continue;
				}
				const value = rawProps[key];
				if (options) {
					if (hasOwn(attrs, key)) {
						if (value !== attrs[key]) {
							attrs[key] = value;
							hasAttrsChanged = true;
						}
					} else {
						const camelizedKey = camelize(key);
						props[camelizedKey] = resolvePropValue(options, rawCurrentProps, camelizedKey, value, instance, false);
					}
				} else {
					if (value !== attrs[key]) {
						attrs[key] = value;
						hasAttrsChanged = true;
					}
				}
			}
		}
	} else {
		if (setFullProps(instance, rawProps, props, attrs)) {
			hasAttrsChanged = true;
		}
		let kebabKey;
		for (const key in rawCurrentProps) {
			if (!rawProps || !hasOwn(rawProps, key) && ((kebabKey = hyphenate(key)) === key || !hasOwn(rawProps, kebabKey))) {
				if (options) {
					if (rawPrevProps && (rawPrevProps[key] !== void 0 || rawPrevProps[kebabKey] !== void 0)) {
						props[key] = resolvePropValue(options, rawCurrentProps, key, void 0, instance, true);
					}
				} else {
					delete props[key];
				}
			}
		}
		if (attrs !== rawCurrentProps) {
			for (const key in attrs) {
				if (!rawProps || !hasOwn(rawProps, key) && true) {
					delete attrs[key];
					hasAttrsChanged = true;
				}
			}
		}
	}
	if (hasAttrsChanged) {
		trigger(instance.attrs, "set", "");
	}
	if (!!("development" !== "production")) {
		validateProps(rawProps || {}, props, instance);
	}
}
function setFullProps(instance, rawProps, props, attrs) {
	const [options, needCastKeys] = instance.propsOptions;
	let hasAttrsChanged = false;
	let rawCastValues;
	if (rawProps) {
		for (let key in rawProps) {
			if (isReservedProp(key)) {
				continue;
			}
			const value = rawProps[key];
			let camelKey;
			if (options && hasOwn(options, camelKey = camelize(key))) {
				if (!needCastKeys || !needCastKeys.includes(camelKey)) {
					props[camelKey] = value;
				} else {
					(rawCastValues || (rawCastValues = {}))[camelKey] = value;
				}
			} else if (!isEmitListener(instance.emitsOptions, key)) {
				if (!(key in attrs) || value !== attrs[key]) {
					attrs[key] = value;
					hasAttrsChanged = true;
				}
			}
		}
	}
	if (needCastKeys) {
		const rawCurrentProps = toRaw(props);
		const castValues = rawCastValues || EMPTY_OBJ;
		for (let i = 0; i < needCastKeys.length; i++) {
			const key = needCastKeys[i];
			props[key] = resolvePropValue(options, rawCurrentProps, key, castValues[key], instance, !hasOwn(castValues, key));
		}
	}
	return hasAttrsChanged;
}
function resolvePropValue(options, props, key, value, instance, isAbsent) {
	const opt = options[key];
	if (opt != null) {
		const hasDefault = hasOwn(opt, "default");
		if (hasDefault && value === void 0) {
			const defaultValue = opt.default;
			if (opt.type !== Function && !opt.skipFactory && isFunction(defaultValue)) {
				const { propsDefaults } = instance;
				if (key in propsDefaults) {
					value = propsDefaults[key];
				} else {
					const reset = setCurrentInstance(instance);
					value = propsDefaults[key] = defaultValue.call(null, props);
					reset();
				}
			} else {
				value = defaultValue;
			}
			if (instance.ce) {
				instance.ce._setProp(key, value);
			}
		}
		if (opt[0]) {
			if (isAbsent && !hasDefault) {
				value = false;
			} else if (opt[1] && (value === "" || value === hyphenate(key))) {
				value = true;
			}
		}
	}
	return value;
}
const mixinPropsCache = /* @__PURE__ */ new WeakMap();
function normalizePropsOptions(comp, appContext, asMixin = false) {
	const cache = __VUE_OPTIONS_API__ && asMixin ? mixinPropsCache : appContext.propsCache;
	const cached = cache.get(comp);
	if (cached) {
		return cached;
	}
	const raw = comp.props;
	const normalized = {};
	const needCastKeys = [];
	let hasExtends = false;
	if (__VUE_OPTIONS_API__ && !isFunction(comp)) {
		const extendProps = (raw2) => {
			hasExtends = true;
			const [props, keys] = normalizePropsOptions(raw2, appContext, true);
			extend(normalized, props);
			if (keys) needCastKeys.push(...keys);
		};
		if (!asMixin && appContext.mixins.length) {
			appContext.mixins.forEach(extendProps);
		}
		if (comp.extends) {
			extendProps(comp.extends);
		}
		if (comp.mixins) {
			comp.mixins.forEach(extendProps);
		}
	}
	if (!raw && !hasExtends) {
		if (isObject(comp)) {
			cache.set(comp, EMPTY_ARR);
		}
		return EMPTY_ARR;
	}
	if (isArray(raw)) {
		for (let i = 0; i < raw.length; i++) {
			if (!!("development" !== "production") && !isString(raw[i])) {
				warn$1(`props must be strings when using array syntax.`, raw[i]);
			}
			const normalizedKey = camelize(raw[i]);
			if (validatePropName(normalizedKey)) {
				normalized[normalizedKey] = EMPTY_OBJ;
			}
		}
	} else if (raw) {
		if (!!("development" !== "production") && !isObject(raw)) {
			warn$1(`invalid props options`, raw);
		}
		for (const key in raw) {
			const normalizedKey = camelize(key);
			if (validatePropName(normalizedKey)) {
				const opt = raw[key];
				const prop = normalized[normalizedKey] = isArray(opt) || isFunction(opt) ? { type: opt } : extend({}, opt);
				const propType = prop.type;
				let shouldCast = false;
				let shouldCastTrue = true;
				if (isArray(propType)) {
					for (let index = 0; index < propType.length; ++index) {
						const type = propType[index];
						const typeName = isFunction(type) && type.name;
						if (typeName === "Boolean") {
							shouldCast = true;
							break;
						} else if (typeName === "String") {
							shouldCastTrue = false;
						}
					}
				} else {
					shouldCast = isFunction(propType) && propType.name === "Boolean";
				}
				prop[0] = shouldCast;
				prop[1] = shouldCastTrue;
				if (shouldCast || hasOwn(prop, "default")) {
					needCastKeys.push(normalizedKey);
				}
			}
		}
	}
	const res = [normalized, needCastKeys];
	if (isObject(comp)) {
		cache.set(comp, res);
	}
	return res;
}
function validatePropName(key) {
	if (key[0] !== "$" && !isReservedProp(key)) {
		return true;
	} else if (!!("development" !== "production")) {
		warn$1(`Invalid prop name: "${key}" is a reserved property.`);
	}
	return false;
}
function getType(ctor) {
	if (ctor === null) {
		return "null";
	}
	if (typeof ctor === "function") {
		return ctor.name || "";
	} else if (typeof ctor === "object") {
		const name = ctor.constructor && ctor.constructor.name;
		return name || "";
	}
	return "";
}
function validateProps(rawProps, props, instance) {
	const resolvedValues = toRaw(props);
	const options = instance.propsOptions[0];
	const camelizePropsKey = Object.keys(rawProps).map((key) => camelize(key));
	for (const key in options) {
		let opt = options[key];
		if (opt == null) continue;
		validateProp(key, resolvedValues[key], opt, !!("development" !== "production") ? shallowReadonly(resolvedValues) : resolvedValues, !camelizePropsKey.includes(key));
	}
}
function validateProp(name, value, prop, props, isAbsent) {
	const { type, required, validator, skipCheck } = prop;
	if (required && isAbsent) {
		warn$1("Missing required prop: \"" + name + "\"");
		return;
	}
	if (value == null && !required) {
		return;
	}
	if (type != null && type !== true && !skipCheck) {
		let isValid = false;
		const types = isArray(type) ? type : [type];
		const expectedTypes = [];
		for (let i = 0; i < types.length && !isValid; i++) {
			const { valid, expectedType } = assertType(value, types[i]);
			expectedTypes.push(expectedType || "");
			isValid = valid;
		}
		if (!isValid) {
			warn$1(getInvalidTypeMessage(name, value, expectedTypes));
			return;
		}
	}
	if (validator && !validator(value, props)) {
		warn$1("Invalid prop: custom validator check failed for prop \"" + name + "\".");
	}
}
const isSimpleType = /* @__PURE__ */ makeMap("String,Number,Boolean,Function,Symbol,BigInt");
function assertType(value, type) {
	let valid;
	const expectedType = getType(type);
	if (expectedType === "null") {
		valid = value === null;
	} else if (isSimpleType(expectedType)) {
		const t = typeof value;
		valid = t === expectedType.toLowerCase();
		if (!valid && t === "object") {
			valid = value instanceof type;
		}
	} else if (expectedType === "Object") {
		valid = isObject(value);
	} else if (expectedType === "Array") {
		valid = isArray(value);
	} else {
		valid = value instanceof type;
	}
	return {
		valid,
		expectedType
	};
}
function getInvalidTypeMessage(name, value, expectedTypes) {
	if (expectedTypes.length === 0) {
		return `Prop type [] for prop "${name}" won't match anything. Did you mean to use type Array instead?`;
	}
	let message = `Invalid prop: type check failed for prop "${name}". Expected ${expectedTypes.map(capitalize).join(" | ")}`;
	const expectedType = expectedTypes[0];
	const receivedType = toRawType(value);
	const expectedValue = styleValue(value, expectedType);
	const receivedValue = styleValue(value, receivedType);
	if (expectedTypes.length === 1 && isExplicable(expectedType) && isCoercible(expectedType, receivedType)) {
		message += ` with value ${expectedValue}`;
	}
	message += `, got ${receivedType} `;
	if (isExplicable(receivedType)) {
		message += `with value ${receivedValue}.`;
	}
	return message;
}
function styleValue(value, type) {
	if (isSymbol(value)) {
		return value.toString();
	} else if (type === "String") {
		return `"${value}"`;
	} else if (type === "Number") {
		return `${Number(value)}`;
	} else {
		return `${value}`;
	}
}
function isExplicable(type) {
	const explicitTypes = [
		"string",
		"number",
		"boolean"
	];
	return explicitTypes.some((elem) => type.toLowerCase() === elem);
}
function isCoercible(...args) {
	return args.every((elem) => {
		const value = elem.toLowerCase();
		return value !== "boolean" && value !== "symbol";
	});
}
const isInternalKey = (key) => key === "_" || key === "_ctx" || key === "$stable";
const normalizeSlotValue = (value) => isArray(value) ? value.map(normalizeVNode) : [normalizeVNode(value)];
const normalizeSlot = (key, rawSlot, ctx) => {
	if (rawSlot._n) {
		return rawSlot;
	}
	const normalized = withCtx((...args) => {
		if (!!("development" !== "production") && currentInstance && !(ctx === null && currentRenderingInstance) && !(ctx && ctx.root !== currentInstance.root)) {
			warn$1(`Slot "${key}" invoked outside of the render function: this will not track dependencies used in the slot. Invoke the slot function inside the render function instead.`);
		}
		return normalizeSlotValue(rawSlot(...args));
	}, ctx);
	normalized._c = false;
	return normalized;
};
const normalizeObjectSlots = (rawSlots, slots, instance) => {
	const ctx = rawSlots._ctx;
	for (const key in rawSlots) {
		if (isInternalKey(key)) continue;
		const value = rawSlots[key];
		if (isFunction(value)) {
			slots[key] = normalizeSlot(key, value, ctx);
		} else if (value != null) {
			if (!!("development" !== "production") && true) {
				warn$1(`Non-function value encountered for slot "${key}". Prefer function slots for better performance.`);
			}
			const normalized = normalizeSlotValue(value);
			slots[key] = () => normalized;
		}
	}
};
const normalizeVNodeSlots = (instance, children) => {
	if (!!("development" !== "production") && !isKeepAlive(instance.vnode) && true) {
		warn$1(`Non-function value encountered for default slot. Prefer function slots for better performance.`);
	}
	const normalized = normalizeSlotValue(children);
	instance.slots.default = () => normalized;
};
const assignSlots = (slots, children, optimized) => {
	for (const key in children) {
		if (optimized || !isInternalKey(key)) {
			slots[key] = children[key];
		}
	}
};
const initSlots = (instance, children, optimized) => {
	const slots = instance.slots = createInternalObject();
	if (instance.vnode.shapeFlag & 32) {
		const type = children._;
		if (type) {
			assignSlots(slots, children, optimized);
			if (optimized) {
				def(slots, "_", type, true);
			}
		} else {
			normalizeObjectSlots(children, slots);
		}
	} else if (children) {
		normalizeVNodeSlots(instance, children);
	}
};
const updateSlots = (instance, children, optimized) => {
	const { vnode, slots } = instance;
	let needDeletionCheck = true;
	let deletionComparisonTarget = EMPTY_OBJ;
	if (vnode.shapeFlag & 32) {
		const type = children._;
		if (type) {
			if (!!("development" !== "production") && isHmrUpdating) {
				assignSlots(slots, children, optimized);
				trigger(instance, "set", "$slots");
			} else if (optimized && type === 1) {
				needDeletionCheck = false;
			} else {
				assignSlots(slots, children, optimized);
			}
		} else {
			needDeletionCheck = !children.$stable;
			normalizeObjectSlots(children, slots);
		}
		deletionComparisonTarget = children;
	} else if (children) {
		normalizeVNodeSlots(instance, children);
		deletionComparisonTarget = { default: 1 };
	}
	if (needDeletionCheck) {
		for (const key in slots) {
			if (!isInternalKey(key) && deletionComparisonTarget[key] == null) {
				delete slots[key];
			}
		}
	}
};
let supported;
let perf;
function startMeasure(instance, type) {
	if (instance.appContext.config.performance && isSupported()) {
		perf.mark(`vue-${type}-${instance.uid}`);
	}
	if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
		devtoolsPerfStart(instance, type, isSupported() ? perf.now() : Date.now());
	}
}
function endMeasure(instance, type) {
	if (instance.appContext.config.performance && isSupported()) {
		const startTag = `vue-${type}-${instance.uid}`;
		const endTag = startTag + `:end`;
		const measureName = `<${formatComponentName(instance, instance.type)}> ${type}`;
		perf.mark(endTag);
		perf.measure(measureName, startTag, endTag);
		perf.clearMeasures(measureName);
		perf.clearMarks(startTag);
		perf.clearMarks(endTag);
	}
	if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
		devtoolsPerfEnd(instance, type, isSupported() ? perf.now() : Date.now());
	}
}
function isSupported() {
	if (supported !== void 0) {
		return supported;
	}
	if (typeof window !== "undefined" && window.performance) {
		supported = true;
		perf = window.performance;
	} else {
		supported = false;
	}
	return supported;
}
function initFeatureFlags() {
	const needWarn = [];
	if (typeof __VUE_OPTIONS_API__ !== "boolean") {
		!!("development" !== "production") && needWarn.push(`__VUE_OPTIONS_API__`);
		getGlobalThis().__VUE_OPTIONS_API__ = true;
	}
	if (typeof __VUE_PROD_DEVTOOLS__ !== "boolean") {
		!!("development" !== "production") && needWarn.push(`__VUE_PROD_DEVTOOLS__`);
		getGlobalThis().__VUE_PROD_DEVTOOLS__ = false;
	}
	if (typeof __VUE_PROD_HYDRATION_MISMATCH_DETAILS__ !== "boolean") {
		!!("development" !== "production") && needWarn.push(`__VUE_PROD_HYDRATION_MISMATCH_DETAILS__`);
		getGlobalThis().__VUE_PROD_HYDRATION_MISMATCH_DETAILS__ = false;
	}
	if (!!("development" !== "production") && needWarn.length) {
		const multi = needWarn.length > 1;
		console.warn(`Feature flag${multi ? `s` : ``} ${needWarn.join(", ")} ${multi ? `are` : `is`} not explicitly defined. You are running the esm-bundler build of Vue, which expects these compile-time feature flags to be globally injected via the bundler config in order to get better tree-shaking in the production bundle.

For more details, see https://link.vuejs.org/feature-flags.`);
	}
}
const queuePostRenderEffect = queueEffectWithSuspense;
function createRenderer(options) {
	return baseCreateRenderer(options);
}
function createHydrationRenderer(options) {
	return baseCreateRenderer(options, createHydrationFunctions);
}
function baseCreateRenderer(options, createHydrationFns) {
	{
		initFeatureFlags();
	}
	const target = getGlobalThis();
	target.__VUE__ = true;
	if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
		setDevtoolsHook$1(target.__VUE_DEVTOOLS_GLOBAL_HOOK__, target);
	}
	const { insert: hostInsert, remove: hostRemove, patchProp: hostPatchProp, createElement: hostCreateElement, createText: hostCreateText, createComment: hostCreateComment, setText: hostSetText, setElementText: hostSetElementText, parentNode: hostParentNode, nextSibling: hostNextSibling, setScopeId: hostSetScopeId = NOOP, insertStaticContent: hostInsertStaticContent } = options;
	const patch = (n1, n2, container, anchor = null, parentComponent = null, parentSuspense = null, namespace = void 0, slotScopeIds = null, optimized = !!("development" !== "production") && isHmrUpdating ? false : !!n2.dynamicChildren) => {
		if (n1 === n2) {
			return;
		}
		if (n1 && !isSameVNodeType(n1, n2)) {
			anchor = getNextHostNode(n1);
			unmount(n1, parentComponent, parentSuspense, true);
			n1 = null;
		}
		if (n2.patchFlag === -2) {
			optimized = false;
			n2.dynamicChildren = null;
		}
		const { type, ref, shapeFlag } = n2;
		switch (type) {
			case Text:
				processText(n1, n2, container, anchor);
				break;
			case Comment:
				processCommentNode(n1, n2, container, anchor);
				break;
			case Static:
				if (n1 == null) {
					mountStaticNode(n2, container, anchor, namespace);
				} else if (!!("development" !== "production")) {
					patchStaticNode(n1, n2, container, namespace);
				}
				break;
			case Fragment:
				processFragment(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
				break;
			default: if (shapeFlag & 1) {
				processElement(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			} else if (shapeFlag & 6) {
				processComponent(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			} else if (shapeFlag & 64) {
				type.process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, internals);
			} else if (shapeFlag & 128) {
				type.process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, internals);
			} else if (!!("development" !== "production")) {
				warn$1("Invalid VNode type:", type, `(${typeof type})`);
			}
		}
		if (ref != null && parentComponent) {
			setRef(ref, n1 && n1.ref, parentSuspense, n2 || n1, !n2);
		} else if (ref == null && n1 && n1.ref != null) {
			setRef(n1.ref, null, parentSuspense, n1, true);
		}
	};
	const processText = (n1, n2, container, anchor) => {
		if (n1 == null) {
			hostInsert(n2.el = hostCreateText(n2.children), container, anchor);
		} else {
			const el = n2.el = n1.el;
			if (n2.children !== n1.children) {
				hostSetText(el, n2.children);
			}
		}
	};
	const processCommentNode = (n1, n2, container, anchor) => {
		if (n1 == null) {
			hostInsert(n2.el = hostCreateComment(n2.children || ""), container, anchor);
		} else {
			n2.el = n1.el;
		}
	};
	const mountStaticNode = (n2, container, anchor, namespace) => {
		[n2.el, n2.anchor] = hostInsertStaticContent(n2.children, container, anchor, namespace, n2.el, n2.anchor);
	};
	const patchStaticNode = (n1, n2, container, namespace) => {
		if (n2.children !== n1.children) {
			const anchor = hostNextSibling(n1.anchor);
			removeStaticNode(n1);
			[n2.el, n2.anchor] = hostInsertStaticContent(n2.children, container, anchor, namespace);
		} else {
			n2.el = n1.el;
			n2.anchor = n1.anchor;
		}
	};
	const moveStaticNode = ({ el, anchor }, container, nextSibling) => {
		let next;
		while (el && el !== anchor) {
			next = hostNextSibling(el);
			hostInsert(el, container, nextSibling);
			el = next;
		}
		hostInsert(anchor, container, nextSibling);
	};
	const removeStaticNode = ({ el, anchor }) => {
		let next;
		while (el && el !== anchor) {
			next = hostNextSibling(el);
			hostRemove(el);
			el = next;
		}
		hostRemove(anchor);
	};
	const processElement = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
		if (n2.type === "svg") {
			namespace = "svg";
		} else if (n2.type === "math") {
			namespace = "mathml";
		}
		if (n1 == null) {
			mountElement(n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
		} else {
			const customElement = n1.el && n1.el._isVueCE ? n1.el : null;
			try {
				if (customElement) {
					customElement._beginPatch();
				}
				patchElement(n1, n2, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			} finally {
				if (customElement) {
					customElement._endPatch();
				}
			}
		}
	};
	const mountElement = (vnode, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
		let el;
		let vnodeHook;
		const { props, shapeFlag, transition, dirs } = vnode;
		el = vnode.el = hostCreateElement(vnode.type, namespace, props && props.is, props);
		if (shapeFlag & 8) {
			hostSetElementText(el, vnode.children);
		} else if (shapeFlag & 16) {
			mountChildren(vnode.children, el, null, parentComponent, parentSuspense, resolveChildrenNamespace(vnode, namespace), slotScopeIds, optimized);
		}
		if (dirs) {
			invokeDirectiveHook(vnode, null, parentComponent, "created");
		}
		setScopeId(el, vnode, vnode.scopeId, slotScopeIds, parentComponent);
		if (props) {
			for (const key in props) {
				if (key !== "value" && !isReservedProp(key)) {
					hostPatchProp(el, key, null, props[key], namespace, parentComponent);
				}
			}
			if ("value" in props) {
				hostPatchProp(el, "value", null, props.value, namespace);
			}
			if (vnodeHook = props.onVnodeBeforeMount) {
				invokeVNodeHook(vnodeHook, parentComponent, vnode);
			}
		}
		if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
			def(el, "__vnode", vnode, true);
			def(el, "__vueParentComponent", parentComponent, true);
		}
		if (dirs) {
			invokeDirectiveHook(vnode, null, parentComponent, "beforeMount");
		}
		const needCallTransitionHooks = needTransition(parentSuspense, transition);
		if (needCallTransitionHooks) {
			transition.beforeEnter(el);
		}
		hostInsert(el, container, anchor);
		if ((vnodeHook = props && props.onVnodeMounted) || needCallTransitionHooks || dirs) {
			const isHmr = !!("development" !== "production") && isHmrUpdating;
			queuePostRenderEffect(() => {
				let prev;
				if (!!("development" !== "production")) prev = setHmrUpdating(isHmr);
				try {
					vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
					needCallTransitionHooks && transition.enter(el);
					dirs && invokeDirectiveHook(vnode, null, parentComponent, "mounted");
				} finally {
					if (!!("development" !== "production")) setHmrUpdating(prev);
				}
			}, parentSuspense);
		}
	};
	const setScopeId = (el, vnode, scopeId, slotScopeIds, parentComponent) => {
		if (scopeId) {
			hostSetScopeId(el, scopeId);
		}
		if (slotScopeIds) {
			for (let i = 0; i < slotScopeIds.length; i++) {
				hostSetScopeId(el, slotScopeIds[i]);
			}
		}
		if (parentComponent) {
			let subTree = parentComponent.subTree;
			if (!!("development" !== "production") && subTree.patchFlag > 0 && subTree.patchFlag & 2048) {
				subTree = filterSingleRoot(subTree.children) || subTree;
			}
			if (vnode === subTree || isSuspense(subTree.type) && (subTree.ssContent === vnode || subTree.ssFallback === vnode)) {
				const parentVNode = parentComponent.vnode;
				setScopeId(el, parentVNode, parentVNode.scopeId, parentVNode.slotScopeIds, parentComponent.parent);
			}
		}
	};
	const mountChildren = (children, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, start = 0) => {
		for (let i = start; i < children.length; i++) {
			const child = children[i] = optimized ? cloneIfMounted(children[i]) : normalizeVNode(children[i]);
			patch(null, child, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
		}
	};
	const patchElement = (n1, n2, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
		const el = n2.el = n1.el;
		if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
			el.__vnode = n2;
		}
		let { patchFlag, dynamicChildren, dirs } = n2;
		patchFlag |= n1.patchFlag & 16;
		const oldProps = n1.props || EMPTY_OBJ;
		const newProps = n2.props || EMPTY_OBJ;
		let vnodeHook;
		parentComponent && toggleRecurse(parentComponent, false);
		if (vnodeHook = newProps.onVnodeBeforeUpdate) {
			invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
		}
		if (dirs) {
			invokeDirectiveHook(n2, n1, parentComponent, "beforeUpdate");
		}
		parentComponent && toggleRecurse(parentComponent, true);
		if (!!("development" !== "production") && isHmrUpdating || dynamicChildren && (!n1.dynamicChildren || n1.dynamicChildren.length !== dynamicChildren.length)) {
			patchFlag = 0;
			optimized = false;
			dynamicChildren = null;
		}
		if (oldProps.innerHTML && newProps.innerHTML == null || oldProps.textContent && newProps.textContent == null) {
			hostSetElementText(el, "");
		}
		if (dynamicChildren) {
			patchBlockChildren(n1.dynamicChildren, dynamicChildren, el, parentComponent, parentSuspense, resolveChildrenNamespace(n2, namespace), slotScopeIds);
			if (!!("development" !== "production")) {
				traverseStaticChildren(n1, n2);
			}
		} else if (!optimized) {
			patchChildren(n1, n2, el, null, parentComponent, parentSuspense, resolveChildrenNamespace(n2, namespace), slotScopeIds, false);
		}
		if (patchFlag > 0) {
			if (patchFlag & 16) {
				patchProps(el, oldProps, newProps, parentComponent, namespace);
			} else {
				if (patchFlag & 2) {
					if (oldProps.class !== newProps.class) {
						hostPatchProp(el, "class", null, newProps.class, namespace);
					}
				}
				if (patchFlag & 4) {
					hostPatchProp(el, "style", oldProps.style, newProps.style, namespace);
				}
				if (patchFlag & 8) {
					const propsToUpdate = n2.dynamicProps;
					for (let i = 0; i < propsToUpdate.length; i++) {
						const key = propsToUpdate[i];
						const prev = oldProps[key];
						const next = newProps[key];
						if (next !== prev || key === "value") {
							hostPatchProp(el, key, prev, next, namespace, parentComponent);
						}
					}
				}
			}
			if (patchFlag & 1) {
				if (n1.children !== n2.children) {
					hostSetElementText(el, n2.children);
				}
			}
		} else if (!optimized && dynamicChildren == null) {
			patchProps(el, oldProps, newProps, parentComponent, namespace);
		}
		if ((vnodeHook = newProps.onVnodeUpdated) || dirs) {
			queuePostRenderEffect(() => {
				vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
				dirs && invokeDirectiveHook(n2, n1, parentComponent, "updated");
			}, parentSuspense);
		}
	};
	const patchBlockChildren = (oldChildren, newChildren, fallbackContainer, parentComponent, parentSuspense, namespace, slotScopeIds) => {
		for (let i = 0; i < newChildren.length; i++) {
			const oldVNode = oldChildren[i];
			const newVNode = newChildren[i];
			const container = oldVNode.el && (oldVNode.type === Fragment || !isSameVNodeType(oldVNode, newVNode) || oldVNode.shapeFlag & (6 | 64 | 128)) ? hostParentNode(oldVNode.el) : 
			// In other cases, the parent container is not actually used so we
			// just pass the block element here to avoid a DOM parentNode call.
			fallbackContainer;
			patch(oldVNode, newVNode, container, null, parentComponent, parentSuspense, namespace, slotScopeIds, true);
		}
	};
	const patchProps = (el, oldProps, newProps, parentComponent, namespace) => {
		if (oldProps !== newProps) {
			if (oldProps !== EMPTY_OBJ) {
				for (const key in oldProps) {
					if (!isReservedProp(key) && !(key in newProps)) {
						hostPatchProp(el, key, oldProps[key], null, namespace, parentComponent);
					}
				}
			}
			for (const key in newProps) {
				if (isReservedProp(key)) continue;
				const next = newProps[key];
				const prev = oldProps[key];
				if (next !== prev && key !== "value") {
					hostPatchProp(el, key, prev, next, namespace, parentComponent);
				}
			}
			if ("value" in newProps) {
				hostPatchProp(el, "value", oldProps.value, newProps.value, namespace);
			}
		}
	};
	const processFragment = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
		const fragmentStartAnchor = n2.el = n1 ? n1.el : hostCreateText("");
		const fragmentEndAnchor = n2.anchor = n1 ? n1.anchor : hostCreateText("");
		let { patchFlag, dynamicChildren, slotScopeIds: fragmentSlotScopeIds } = n2;
		if (!!("development" !== "production") && (isHmrUpdating || patchFlag & 2048)) {
			patchFlag = 0;
			optimized = false;
			dynamicChildren = null;
		}
		if (fragmentSlotScopeIds) {
			slotScopeIds = slotScopeIds ? slotScopeIds.concat(fragmentSlotScopeIds) : fragmentSlotScopeIds;
		}
		if (n1 == null) {
			hostInsert(fragmentStartAnchor, container, anchor);
			hostInsert(fragmentEndAnchor, container, anchor);
			mountChildren(
				// #10007
				// such fragment like `<></>` will be compiled into
				// a fragment which doesn't have a children.
				// In this case fallback to an empty array
				n2.children || [],
				container,
				fragmentEndAnchor,
				parentComponent,
				parentSuspense,
				namespace,
				slotScopeIds,
				optimized
			);
		} else {
			if (patchFlag > 0 && patchFlag & 64 && dynamicChildren && n1.dynamicChildren && n1.dynamicChildren.length === dynamicChildren.length) {
				patchBlockChildren(n1.dynamicChildren, dynamicChildren, container, parentComponent, parentSuspense, namespace, slotScopeIds);
				if (!!("development" !== "production")) {
					traverseStaticChildren(n1, n2);
				} else if (n2.key != null || parentComponent && n2 === parentComponent.subTree) {
					traverseStaticChildren(
						n1,
						n2,
						true
						/* shallow */
					);
				}
			} else {
				patchChildren(n1, n2, container, fragmentEndAnchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			}
		}
	};
	const processComponent = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
		n2.slotScopeIds = slotScopeIds;
		if (n1 == null) {
			if (n2.shapeFlag & 512) {
				parentComponent.ctx.activate(n2, container, anchor, namespace, optimized);
			} else {
				mountComponent(n2, container, anchor, parentComponent, parentSuspense, namespace, optimized);
			}
		} else {
			updateComponent(n1, n2, optimized);
		}
	};
	const mountComponent = (initialVNode, container, anchor, parentComponent, parentSuspense, namespace, optimized) => {
		const instance = initialVNode.component = createComponentInstance(initialVNode, parentComponent, parentSuspense);
		if (!!("development" !== "production") && instance.type.__hmrId) {
			registerHMR(instance);
		}
		if (!!("development" !== "production")) {
			pushWarningContext(initialVNode);
			startMeasure(instance, `mount`);
		}
		if (isKeepAlive(initialVNode)) {
			instance.ctx.renderer = internals;
		}
		{
			if (!!("development" !== "production")) {
				startMeasure(instance, `init`);
			}
			setupComponent(instance, false, optimized);
			if (!!("development" !== "production")) {
				endMeasure(instance, `init`);
			}
		}
		if (!!("development" !== "production") && isHmrUpdating) initialVNode.el = null;
		if (instance.asyncDep) {
			parentSuspense && parentSuspense.registerDep(instance, setupRenderEffect, optimized);
			if (!initialVNode.el) {
				const placeholder = instance.subTree = createVNode(Comment);
				processCommentNode(null, placeholder, container, anchor);
				initialVNode.placeholder = placeholder.el;
			}
		} else {
			setupRenderEffect(instance, initialVNode, container, anchor, parentSuspense, namespace, optimized);
		}
		if (!!("development" !== "production")) {
			popWarningContext();
			endMeasure(instance, `mount`);
		}
	};
	const updateComponent = (n1, n2, optimized) => {
		const instance = n2.component = n1.component;
		if (shouldUpdateComponent(n1, n2, optimized)) {
			if (instance.asyncDep && !instance.asyncResolved) {
				if (!!("development" !== "production")) {
					pushWarningContext(n2);
				}
				updateComponentPreRender(instance, n2, optimized);
				if (!!("development" !== "production")) {
					popWarningContext();
				}
				return;
			} else {
				instance.next = n2;
				instance.update();
			}
		} else {
			n2.el = n1.el;
			instance.vnode = n2;
		}
	};
	const setupRenderEffect = (instance, initialVNode, container, anchor, parentSuspense, namespace, optimized) => {
		const componentUpdateFn = () => {
			if (!instance.isMounted) {
				let vnodeHook;
				const { el, props } = initialVNode;
				const { bm, m, parent, root, type } = instance;
				const isAsyncWrapperVNode = isAsyncWrapper(initialVNode);
				toggleRecurse(instance, false);
				if (bm) {
					invokeArrayFns(bm);
				}
				if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeBeforeMount)) {
					invokeVNodeHook(vnodeHook, parent, initialVNode);
				}
				toggleRecurse(instance, true);
				if (el && hydrateNode) {
					const hydrateSubTree = () => {
						if (!!("development" !== "production")) {
							startMeasure(instance, `render`);
						}
						instance.subTree = renderComponentRoot(instance);
						if (!!("development" !== "production")) {
							endMeasure(instance, `render`);
						}
						if (!!("development" !== "production")) {
							startMeasure(instance, `hydrate`);
						}
						hydrateNode(el, instance.subTree, instance, parentSuspense, null);
						if (!!("development" !== "production")) {
							endMeasure(instance, `hydrate`);
						}
					};
					if (isAsyncWrapperVNode && type.__asyncHydrate) {
						type.__asyncHydrate(el, instance, hydrateSubTree);
					} else {
						hydrateSubTree();
					}
				} else {
					if (root.ce && root.ce._hasShadowRoot()) {
						root.ce._injectChildStyle(type, instance.parent ? instance.parent.type : void 0);
					}
					if (!!("development" !== "production")) {
						startMeasure(instance, `render`);
					}
					const subTree = instance.subTree = renderComponentRoot(instance);
					if (!!("development" !== "production")) {
						endMeasure(instance, `render`);
					}
					if (!!("development" !== "production")) {
						startMeasure(instance, `patch`);
					}
					patch(null, subTree, container, anchor, instance, parentSuspense, namespace);
					if (!!("development" !== "production")) {
						endMeasure(instance, `patch`);
					}
					initialVNode.el = subTree.el;
				}
				if (m) {
					queuePostRenderEffect(m, parentSuspense);
				}
				if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeMounted)) {
					const scopedInitialVNode = initialVNode;
					queuePostRenderEffect(() => invokeVNodeHook(vnodeHook, parent, scopedInitialVNode), parentSuspense);
				}
				if (initialVNode.shapeFlag & 256 || parent && isAsyncWrapper(parent.vnode) && parent.vnode.shapeFlag & 256) {
					instance.a && queuePostRenderEffect(instance.a, parentSuspense);
				}
				instance.isMounted = true;
				if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
					devtoolsComponentAdded(instance);
				}
				initialVNode = container = anchor = null;
			} else {
				let { next, bu, u, parent, vnode } = instance;
				{
					const nonHydratedAsyncRoot = locateNonHydratedAsyncRoot(instance);
					if (nonHydratedAsyncRoot) {
						if (next) {
							next.el = vnode.el;
							updateComponentPreRender(instance, next, optimized);
						}
						nonHydratedAsyncRoot.asyncDep.then(() => {
							queuePostRenderEffect(() => {
								if (!instance.isUnmounted) update();
							}, parentSuspense);
						});
						return;
					}
				}
				let originNext = next;
				let vnodeHook;
				if (!!("development" !== "production")) {
					pushWarningContext(next || instance.vnode);
				}
				toggleRecurse(instance, false);
				if (next) {
					next.el = vnode.el;
					updateComponentPreRender(instance, next, optimized);
				} else {
					next = vnode;
				}
				if (bu) {
					invokeArrayFns(bu);
				}
				if (vnodeHook = next.props && next.props.onVnodeBeforeUpdate) {
					invokeVNodeHook(vnodeHook, parent, next, vnode);
				}
				toggleRecurse(instance, true);
				if (!!("development" !== "production")) {
					startMeasure(instance, `render`);
				}
				const nextTree = renderComponentRoot(instance);
				if (!!("development" !== "production")) {
					endMeasure(instance, `render`);
				}
				const prevTree = instance.subTree;
				instance.subTree = nextTree;
				if (!!("development" !== "production")) {
					startMeasure(instance, `patch`);
				}
				patch(
					prevTree,
					nextTree,
					// parent may have changed if it's in a teleport
					hostParentNode(prevTree.el),
					// anchor may have changed if it's in a fragment
					getNextHostNode(prevTree),
					instance,
					parentSuspense,
					namespace
				);
				if (!!("development" !== "production")) {
					endMeasure(instance, `patch`);
				}
				next.el = nextTree.el;
				if (originNext === null) {
					updateHOCHostEl(instance, nextTree.el);
				}
				if (u) {
					queuePostRenderEffect(u, parentSuspense);
				}
				if (vnodeHook = next.props && next.props.onVnodeUpdated) {
					queuePostRenderEffect(() => invokeVNodeHook(vnodeHook, parent, next, vnode), parentSuspense);
				}
				if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
					devtoolsComponentUpdated(instance);
				}
				if (!!("development" !== "production")) {
					popWarningContext();
				}
			}
		};
		instance.scope.on();
		const effect = instance.effect = new ReactiveEffect(componentUpdateFn);
		instance.scope.off();
		const update = instance.update = effect.run.bind(effect);
		const job = instance.job = effect.runIfDirty.bind(effect);
		job.i = instance;
		job.id = instance.uid;
		effect.scheduler = () => queueJob(job);
		toggleRecurse(instance, true);
		if (!!("development" !== "production")) {
			effect.onTrack = instance.rtc ? (e) => invokeArrayFns(instance.rtc, e) : void 0;
			effect.onTrigger = instance.rtg ? (e) => invokeArrayFns(instance.rtg, e) : void 0;
		}
		update();
	};
	const updateComponentPreRender = (instance, nextVNode, optimized) => {
		nextVNode.component = instance;
		const prevProps = instance.vnode.props;
		instance.vnode = nextVNode;
		instance.next = null;
		updateProps(instance, nextVNode.props, prevProps, optimized);
		updateSlots(instance, nextVNode.children, optimized);
		pauseTracking();
		flushPreFlushCbs(instance);
		resetTracking();
	};
	const patchChildren = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized = false) => {
		const c1 = n1 && n1.children;
		const prevShapeFlag = n1 ? n1.shapeFlag : 0;
		const c2 = n2.children;
		const { patchFlag, shapeFlag } = n2;
		if (patchFlag > 0) {
			if (patchFlag & 128) {
				patchKeyedChildren(c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
				return;
			} else if (patchFlag & 256) {
				patchUnkeyedChildren(c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
				return;
			}
		}
		if (shapeFlag & 8) {
			if (prevShapeFlag & 16) {
				unmountChildren(c1, parentComponent, parentSuspense);
			}
			if (c2 !== c1) {
				hostSetElementText(container, c2);
			}
		} else {
			if (prevShapeFlag & 16) {
				if (shapeFlag & 16) {
					patchKeyedChildren(c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
				} else {
					unmountChildren(c1, parentComponent, parentSuspense, true);
				}
			} else {
				if (prevShapeFlag & 8) {
					hostSetElementText(container, "");
				}
				if (shapeFlag & 16) {
					mountChildren(c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
				}
			}
		}
	};
	const patchUnkeyedChildren = (c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
		c1 = c1 || EMPTY_ARR;
		c2 = c2 || EMPTY_ARR;
		const oldLength = c1.length;
		const newLength = c2.length;
		const commonLength = Math.min(oldLength, newLength);
		let i;
		for (i = 0; i < commonLength; i++) {
			const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
			patch(c1[i], nextChild, container, null, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
		}
		if (oldLength > newLength) {
			unmountChildren(c1, parentComponent, parentSuspense, true, false, commonLength);
		} else {
			mountChildren(c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, commonLength);
		}
	};
	const patchKeyedChildren = (c1, c2, container, parentAnchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
		let i = 0;
		const l2 = c2.length;
		let e1 = c1.length - 1;
		let e2 = l2 - 1;
		while (i <= e1 && i <= e2) {
			const n1 = c1[i];
			const n2 = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
			if (isSameVNodeType(n1, n2)) {
				patch(n1, n2, container, null, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			} else {
				break;
			}
			i++;
		}
		while (i <= e1 && i <= e2) {
			const n1 = c1[e1];
			const n2 = c2[e2] = optimized ? cloneIfMounted(c2[e2]) : normalizeVNode(c2[e2]);
			if (isSameVNodeType(n1, n2)) {
				patch(n1, n2, container, null, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
			} else {
				break;
			}
			e1--;
			e2--;
		}
		if (i > e1) {
			if (i <= e2) {
				const nextPos = e2 + 1;
				const anchor = nextPos < l2 ? c2[nextPos].el : parentAnchor;
				while (i <= e2) {
					patch(null, c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]), container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
					i++;
				}
			}
		} else if (i > e2) {
			while (i <= e1) {
				unmount(c1[i], parentComponent, parentSuspense, true);
				i++;
			}
		} else {
			const s1 = i;
			const s2 = i;
			const keyToNewIndexMap = /* @__PURE__ */ new Map();
			for (i = s2; i <= e2; i++) {
				const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
				if (nextChild.key != null) {
					if (!!("development" !== "production") && keyToNewIndexMap.has(nextChild.key)) {
						warn$1(`Duplicate keys found during update:`, JSON.stringify(nextChild.key), `Make sure keys are unique.`);
					}
					keyToNewIndexMap.set(nextChild.key, i);
				}
			}
			let j;
			let patched = 0;
			const toBePatched = e2 - s2 + 1;
			let moved = false;
			let maxNewIndexSoFar = 0;
			const newIndexToOldIndexMap = new Array(toBePatched);
			for (i = 0; i < toBePatched; i++) newIndexToOldIndexMap[i] = 0;
			for (i = s1; i <= e1; i++) {
				const prevChild = c1[i];
				if (patched >= toBePatched) {
					unmount(prevChild, parentComponent, parentSuspense, true);
					continue;
				}
				let newIndex;
				if (prevChild.key != null) {
					newIndex = keyToNewIndexMap.get(prevChild.key);
				} else {
					for (j = s2; j <= e2; j++) {
						if (newIndexToOldIndexMap[j - s2] === 0 && isSameVNodeType(prevChild, c2[j])) {
							newIndex = j;
							break;
						}
					}
				}
				if (newIndex === void 0) {
					unmount(prevChild, parentComponent, parentSuspense, true);
				} else {
					newIndexToOldIndexMap[newIndex - s2] = i + 1;
					if (newIndex >= maxNewIndexSoFar) {
						maxNewIndexSoFar = newIndex;
					} else {
						moved = true;
					}
					patch(prevChild, c2[newIndex], container, null, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
					patched++;
				}
			}
			const increasingNewIndexSequence = moved ? getSequence(newIndexToOldIndexMap) : EMPTY_ARR;
			j = increasingNewIndexSequence.length - 1;
			for (i = toBePatched - 1; i >= 0; i--) {
				const nextIndex = s2 + i;
				const nextChild = c2[nextIndex];
				const anchorVNode = c2[nextIndex + 1];
				const anchor = nextIndex + 1 < l2 ? anchorVNode.el || resolveAsyncComponentPlaceholder(anchorVNode) : parentAnchor;
				if (newIndexToOldIndexMap[i] === 0) {
					patch(null, nextChild, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized);
				} else if (moved) {
					if (j < 0 || i !== increasingNewIndexSequence[j]) {
						move(nextChild, container, anchor, 2);
					} else {
						j--;
					}
				}
			}
		}
	};
	const move = (vnode, container, anchor, moveType, parentSuspense = null) => {
		const { el, type, transition, children, shapeFlag } = vnode;
		if (shapeFlag & 6) {
			move(vnode.component.subTree, container, anchor, moveType);
			return;
		}
		if (shapeFlag & 128) {
			vnode.suspense.move(container, anchor, moveType);
			return;
		}
		if (shapeFlag & 64) {
			type.move(vnode, container, anchor, internals);
			return;
		}
		if (type === Fragment) {
			hostInsert(el, container, anchor);
			for (let i = 0; i < children.length; i++) {
				move(children[i], container, anchor, moveType);
			}
			hostInsert(vnode.anchor, container, anchor);
			return;
		}
		if (type === Static) {
			moveStaticNode(vnode, container, anchor);
			return;
		}
		const needTransition2 = moveType !== 2 && shapeFlag & 1 && transition;
		if (needTransition2) {
			if (moveType === 0) {
				if (transition.persisted && !el[leaveCbKey]) {
					hostInsert(el, container, anchor);
				} else {
					transition.beforeEnter(el);
					hostInsert(el, container, anchor);
					queuePostRenderEffect(() => transition.enter(el), parentSuspense);
				}
			} else {
				const { leave, delayLeave, afterLeave } = transition;
				const remove2 = () => {
					if (vnode.ctx.isUnmounted) {
						hostRemove(el);
					} else {
						hostInsert(el, container, anchor);
					}
				};
				const performLeave = () => {
					const wasLeaving = el._isLeaving || !!el[leaveCbKey];
					if (el._isLeaving) {
						el[leaveCbKey](
							true
							/* cancelled */
						);
					}
					if (transition.persisted && !wasLeaving) {
						remove2();
					} else {
						leave(el, () => {
							remove2();
							afterLeave && afterLeave();
						});
					}
				};
				if (delayLeave) {
					delayLeave(el, remove2, performLeave);
				} else {
					performLeave();
				}
			}
		} else {
			hostInsert(el, container, anchor);
		}
	};
	const unmount = (vnode, parentComponent, parentSuspense, doRemove = false, optimized = false) => {
		const { type, props, ref, children, dynamicChildren, shapeFlag, patchFlag, dirs, cacheIndex, memo } = vnode;
		if (patchFlag === -2) {
			optimized = false;
		}
		if (ref != null) {
			pauseTracking();
			setRef(ref, null, parentSuspense, vnode, true);
			resetTracking();
		}
		if (cacheIndex != null) {
			parentComponent.renderCache[cacheIndex] = void 0;
		}
		if (shapeFlag & 256) {
			parentComponent.ctx.deactivate(vnode);
			return;
		}
		const shouldInvokeDirs = shapeFlag & 1 && dirs;
		const shouldInvokeVnodeHook = !isAsyncWrapper(vnode);
		let vnodeHook;
		if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeBeforeUnmount)) {
			invokeVNodeHook(vnodeHook, parentComponent, vnode);
		}
		if (shapeFlag & 6) {
			unmountComponent(vnode.component, parentSuspense, doRemove);
		} else {
			if (shapeFlag & 128) {
				vnode.suspense.unmount(parentSuspense, doRemove);
				return;
			}
			if (shouldInvokeDirs) {
				invokeDirectiveHook(vnode, null, parentComponent, "beforeUnmount");
			}
			if (shapeFlag & 64) {
				vnode.type.remove(vnode, parentComponent, parentSuspense, internals, doRemove);
			} else if (dynamicChildren && !dynamicChildren.hasOnce && (type !== Fragment || patchFlag > 0 && patchFlag & 64)) {
				unmountChildren(dynamicChildren, parentComponent, parentSuspense, false, true);
			} else if (type === Fragment && patchFlag & (128 | 256) || !optimized && shapeFlag & 16) {
				unmountChildren(children, parentComponent, parentSuspense);
			}
			if (doRemove) {
				remove(vnode);
			}
		}
		const shouldInvalidateMemo = memo != null && cacheIndex == null;
		if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeUnmounted) || shouldInvokeDirs || shouldInvalidateMemo) {
			queuePostRenderEffect(() => {
				vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
				shouldInvokeDirs && invokeDirectiveHook(vnode, null, parentComponent, "unmounted");
				if (shouldInvalidateMemo) {
					vnode.el = null;
				}
			}, parentSuspense);
		}
	};
	const remove = (vnode) => {
		const { type, el, anchor, transition } = vnode;
		if (type === Fragment) {
			if (!!("development" !== "production") && vnode.patchFlag > 0 && vnode.patchFlag & 2048 && transition && !transition.persisted) {
				vnode.children.forEach((child) => {
					if (child.type === Comment) {
						hostRemove(child.el);
					} else {
						remove(child);
					}
				});
			} else {
				removeFragment(el, anchor);
			}
			return;
		}
		if (type === Static) {
			removeStaticNode(vnode);
			return;
		}
		const performRemove = () => {
			hostRemove(el);
			if (transition && !transition.persisted && transition.afterLeave) {
				transition.afterLeave();
			}
		};
		if (vnode.shapeFlag & 1 && transition && !transition.persisted) {
			const { leave, delayLeave } = transition;
			const performLeave = () => leave(el, performRemove);
			if (delayLeave) {
				delayLeave(vnode.el, performRemove, performLeave);
			} else {
				performLeave();
			}
		} else {
			performRemove();
		}
	};
	const removeFragment = (cur, end) => {
		let next;
		while (cur !== end) {
			next = hostNextSibling(cur);
			hostRemove(cur);
			cur = next;
		}
		hostRemove(end);
	};
	const unmountComponent = (instance, parentSuspense, doRemove) => {
		if (!!("development" !== "production") && instance.type.__hmrId) {
			unregisterHMR(instance);
		}
		const { bum, scope, job, subTree, um, m, a } = instance;
		invalidateMount(m);
		invalidateMount(a);
		if (bum) {
			invokeArrayFns(bum);
		}
		scope.stop();
		if (job) {
			job.flags |= 8;
			unmount(subTree, instance, parentSuspense, doRemove);
		}
		if (um) {
			queuePostRenderEffect(um, parentSuspense);
		}
		queuePostRenderEffect(() => {
			instance.isUnmounted = true;
		}, parentSuspense);
		if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
			devtoolsComponentRemoved(instance);
		}
	};
	const unmountChildren = (children, parentComponent, parentSuspense, doRemove = false, optimized = false, start = 0) => {
		for (let i = start; i < children.length; i++) {
			unmount(children[i], parentComponent, parentSuspense, doRemove, optimized);
		}
	};
	const getNextHostNode = (vnode) => {
		if (vnode.shapeFlag & 6) {
			return getNextHostNode(vnode.component.subTree);
		}
		if (vnode.shapeFlag & 128) {
			return vnode.suspense.next();
		}
		const el = hostNextSibling(vnode.anchor || vnode.el);
		const teleportEnd = el && el[TeleportEndKey];
		return teleportEnd ? hostNextSibling(teleportEnd) : el;
	};
	let isFlushing = false;
	const render = (vnode, container, namespace) => {
		let instance;
		if (vnode == null) {
			if (container._vnode) {
				unmount(container._vnode, null, null, true);
				instance = container._vnode.component;
			}
		} else {
			patch(container._vnode || null, vnode, container, null, null, null, namespace);
		}
		container._vnode = vnode;
		if (!isFlushing) {
			isFlushing = true;
			flushPreFlushCbs(instance);
			flushPostFlushCbs();
			isFlushing = false;
		}
	};
	const internals = {
		p: patch,
		um: unmount,
		m: move,
		r: remove,
		mt: mountComponent,
		mc: mountChildren,
		pc: patchChildren,
		pbc: patchBlockChildren,
		n: getNextHostNode,
		o: options
	};
	let hydrate;
	let hydrateNode;
	if (createHydrationFns) {
		[hydrate, hydrateNode] = createHydrationFns(internals);
	}
	return {
		render,
		hydrate,
		createApp: createAppAPI(render, hydrate)
	};
}
function resolveChildrenNamespace({ type, props }, currentNamespace) {
	return currentNamespace === "svg" && type === "foreignObject" || currentNamespace === "mathml" && type === "annotation-xml" && props && props.encoding && props.encoding.includes("html") ? void 0 : currentNamespace;
}
function toggleRecurse({ effect, job }, allowed) {
	if (allowed) {
		effect.flags |= 32;
		job.flags |= 4;
	} else {
		effect.flags &= -33;
		job.flags &= -5;
	}
}
function needTransition(parentSuspense, transition) {
	return (!parentSuspense || parentSuspense && !parentSuspense.pendingBranch) && transition && !transition.persisted;
}
function traverseStaticChildren(n1, n2, shallow = false) {
	const ch1 = n1.children;
	const ch2 = n2.children;
	if (isArray(ch1) && isArray(ch2)) {
		for (let i = 0; i < ch1.length; i++) {
			const c1 = ch1[i];
			let c2 = ch2[i];
			if (c2.shapeFlag & 1 && !c2.dynamicChildren) {
				if (c2.patchFlag <= 0 || c2.patchFlag === 32) {
					c2 = ch2[i] = cloneIfMounted(ch2[i]);
					c2.el = c1.el;
				}
				if (!shallow && c2.patchFlag !== -2) traverseStaticChildren(c1, c2);
			}
			if (c2.type === Text) {
				if (c2.patchFlag === -1) {
					c2 = ch2[i] = cloneIfMounted(c2);
				}
				c2.el = c1.el;
			}
			if (c2.type === Comment && !c2.el) {
				c2.el = c1.el;
			}
			if (!!("development" !== "production")) {
				c2.el && (c2.el.__vnode = c2);
			}
		}
	}
}
function getSequence(arr) {
	const p = arr.slice();
	const result = [0];
	let i, j, u, v, c;
	const len = arr.length;
	for (i = 0; i < len; i++) {
		const arrI = arr[i];
		if (arrI !== 0) {
			j = result[result.length - 1];
			if (arr[j] < arrI) {
				p[i] = j;
				result.push(i);
				continue;
			}
			u = 0;
			v = result.length - 1;
			while (u < v) {
				c = u + v >> 1;
				if (arr[result[c]] < arrI) {
					u = c + 1;
				} else {
					v = c;
				}
			}
			if (arrI < arr[result[u]]) {
				if (u > 0) {
					p[i] = result[u - 1];
				}
				result[u] = i;
			}
		}
	}
	u = result.length;
	v = result[u - 1];
	while (u-- > 0) {
		result[u] = v;
		v = p[v];
	}
	return result;
}
function locateNonHydratedAsyncRoot(instance) {
	const subComponent = instance.subTree.component;
	if (subComponent) {
		if (subComponent.asyncDep && !subComponent.asyncResolved) {
			return subComponent;
		} else {
			return locateNonHydratedAsyncRoot(subComponent);
		}
	}
}
function invalidateMount(hooks) {
	if (hooks) {
		for (let i = 0; i < hooks.length; i++) hooks[i].flags |= 8;
	}
}
function resolveAsyncComponentPlaceholder(anchorVnode) {
	if (anchorVnode.placeholder) {
		return anchorVnode.placeholder;
	}
	const instance = anchorVnode.component;
	if (instance) {
		return resolveAsyncComponentPlaceholder(instance.subTree);
	}
	return null;
}
const isSuspense = (type) => type.__isSuspense;
let suspenseId = 0;
const SuspenseImpl = {
	name: "Suspense",
	// In order to make Suspense tree-shakable, we need to avoid importing it
	// directly in the renderer. The renderer checks for the __isSuspense flag
	// on a vnode's type and calls the `process` method, passing in renderer
	// internals.
	__isSuspense: true,
	process(n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals) {
		if (n1 == null) {
			mountSuspense(n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals);
		} else {
			if (parentSuspense && parentSuspense.deps > 0 && !n1.suspense.isInFallback) {
				n2.suspense = n1.suspense;
				n2.suspense.vnode = n2;
				n2.el = n1.el;
				return;
			}
			patchSuspense(n1, n2, container, anchor, parentComponent, namespace, slotScopeIds, optimized, rendererInternals);
		}
	},
	hydrate: hydrateSuspense,
	normalize: normalizeSuspenseChildren
};
const Suspense = SuspenseImpl;
function triggerEvent(vnode, name) {
	const eventListener = vnode.props && vnode.props[name];
	if (isFunction(eventListener)) {
		eventListener();
	}
}
function mountSuspense(vnode, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals) {
	const { p: patch, o: { createElement } } = rendererInternals;
	const hiddenContainer = createElement("div");
	const suspense = vnode.suspense = createSuspenseBoundary(vnode, parentSuspense, parentComponent, container, hiddenContainer, anchor, namespace, slotScopeIds, optimized, rendererInternals);
	patch(null, suspense.pendingBranch = vnode.ssContent, hiddenContainer, null, parentComponent, suspense, namespace, slotScopeIds);
	if (suspense.deps > 0) {
		triggerEvent(vnode, "onPending");
		triggerEvent(vnode, "onFallback");
		patch(
			null,
			vnode.ssFallback,
			container,
			anchor,
			parentComponent,
			null,
			// fallback tree will not have suspense context
			namespace,
			slotScopeIds
		);
		setActiveBranch(suspense, vnode.ssFallback);
	} else {
		suspense.resolve(false, true);
	}
}
function patchSuspense(n1, n2, container, anchor, parentComponent, namespace, slotScopeIds, optimized, { p: patch, um: unmount, o: { createElement } }) {
	const suspense = n2.suspense = n1.suspense;
	suspense.vnode = n2;
	n2.el = n1.el;
	const newBranch = n2.ssContent;
	const newFallback = n2.ssFallback;
	const { activeBranch, pendingBranch, isInFallback, isHydrating } = suspense;
	if (pendingBranch) {
		suspense.pendingBranch = newBranch;
		if (isSameVNodeType(pendingBranch, newBranch)) {
			patch(pendingBranch, newBranch, suspense.hiddenContainer, null, parentComponent, suspense, namespace, slotScopeIds, optimized);
			if (suspense.deps <= 0) {
				suspense.resolve();
			} else if (isInFallback) {
				if (!isHydrating) {
					patch(
						activeBranch,
						newFallback,
						container,
						anchor,
						parentComponent,
						null,
						// fallback tree will not have suspense context
						namespace,
						slotScopeIds,
						optimized
					);
					setActiveBranch(suspense, newFallback);
				}
			}
		} else {
			suspense.pendingId = suspenseId++;
			if (isHydrating) {
				suspense.isHydrating = false;
				suspense.activeBranch = pendingBranch;
			} else {
				unmount(pendingBranch, parentComponent, suspense);
			}
			suspense.deps = 0;
			suspense.effects.length = 0;
			suspense.hiddenContainer = createElement("div");
			if (isInFallback) {
				patch(null, newBranch, suspense.hiddenContainer, null, parentComponent, suspense, namespace, slotScopeIds, optimized);
				if (suspense.deps <= 0) {
					suspense.resolve();
				} else {
					patch(
						activeBranch,
						newFallback,
						container,
						anchor,
						parentComponent,
						null,
						// fallback tree will not have suspense context
						namespace,
						slotScopeIds,
						optimized
					);
					setActiveBranch(suspense, newFallback);
				}
			} else if (activeBranch && isSameVNodeType(activeBranch, newBranch)) {
				patch(activeBranch, newBranch, container, anchor, parentComponent, suspense, namespace, slotScopeIds, optimized);
				suspense.resolve(true);
			} else {
				patch(null, newBranch, suspense.hiddenContainer, null, parentComponent, suspense, namespace, slotScopeIds, optimized);
				if (suspense.deps <= 0) {
					suspense.resolve();
				}
			}
		}
	} else {
		if (activeBranch && isSameVNodeType(activeBranch, newBranch)) {
			patch(activeBranch, newBranch, container, anchor, parentComponent, suspense, namespace, slotScopeIds, optimized);
			setActiveBranch(suspense, newBranch);
		} else {
			triggerEvent(n2, "onPending");
			suspense.pendingBranch = newBranch;
			if (newBranch.shapeFlag & 512) {
				suspense.pendingId = newBranch.component.suspenseId;
			} else {
				suspense.pendingId = suspenseId++;
			}
			patch(null, newBranch, suspense.hiddenContainer, null, parentComponent, suspense, namespace, slotScopeIds, optimized);
			if (suspense.deps <= 0) {
				suspense.resolve();
			} else {
				const { timeout, pendingId } = suspense;
				if (timeout > 0) {
					setTimeout(() => {
						if (suspense.pendingId === pendingId) {
							suspense.fallback(newFallback);
						}
					}, timeout);
				} else if (timeout === 0) {
					suspense.fallback(newFallback);
				}
			}
		}
	}
}
let hasWarned = false;
function createSuspenseBoundary(vnode, parentSuspense, parentComponent, container, hiddenContainer, anchor, namespace, slotScopeIds, optimized, rendererInternals, isHydrating = false) {
	if (!!("development" !== "production") && true && !hasWarned) {
		hasWarned = true;
		console[console.info ? "info" : "log"](`<Suspense> is an experimental feature and its API will likely change.`);
	}
	const { p: patch, m: move, um: unmount, n: next, o: { parentNode, remove } } = rendererInternals;
	let parentSuspenseId;
	const isSuspensible = isVNodeSuspensible(vnode);
	if (isSuspensible) {
		if (parentSuspense && parentSuspense.pendingBranch) {
			parentSuspenseId = parentSuspense.pendingId;
			parentSuspense.deps++;
		}
	}
	const timeout = vnode.props ? toNumber(vnode.props.timeout) : void 0;
	if (!!("development" !== "production")) {
		assertNumber(timeout, `Suspense timeout`);
	}
	const initialAnchor = anchor;
	const suspense = {
		vnode,
		parent: parentSuspense,
		parentComponent,
		namespace,
		container,
		hiddenContainer,
		deps: 0,
		pendingId: suspenseId++,
		timeout: typeof timeout === "number" ? timeout : -1,
		activeBranch: null,
		isFallbackMountPending: false,
		pendingBranch: null,
		isInFallback: !isHydrating,
		isHydrating,
		isUnmounted: false,
		effects: [],
		resolve(resume = false, sync = false) {
			if (!!("development" !== "production")) {
				if (!resume && !suspense.pendingBranch) {
					throw new Error(`suspense.resolve() is called without a pending branch.`);
				}
				if (suspense.isUnmounted) {
					throw new Error(`suspense.resolve() is called on an already unmounted suspense boundary.`);
				}
			}
			const { vnode: vnode2, activeBranch, pendingBranch, pendingId, effects, parentComponent: parentComponent2, container: container2, isInFallback } = suspense;
			let delayEnter = false;
			if (suspense.isHydrating) {
				suspense.isHydrating = false;
			} else if (!resume) {
				delayEnter = activeBranch && pendingBranch.transition && pendingBranch.transition.mode === "out-in";
				let hasUpdatedAnchor = false;
				if (delayEnter) {
					activeBranch.transition.afterLeave = () => {
						if (pendingId === suspense.pendingId) {
							move(pendingBranch, container2, anchor === initialAnchor && !hasUpdatedAnchor ? next(activeBranch) : anchor, 0);
							queuePostFlushCb(effects);
							if (isInFallback && vnode2.ssFallback) {
								vnode2.ssFallback.el = null;
							}
						}
					};
				}
				if (activeBranch && !suspense.isFallbackMountPending) {
					if (parentNode(activeBranch.el) === container2) {
						anchor = next(activeBranch);
						hasUpdatedAnchor = true;
					}
					unmount(activeBranch, parentComponent2, suspense, true);
					if (!delayEnter && isInFallback && vnode2.ssFallback) {
						queuePostRenderEffect(() => vnode2.ssFallback.el = null, suspense);
					}
				}
				if (!delayEnter) {
					move(pendingBranch, container2, anchor, 0);
				}
			}
			suspense.isFallbackMountPending = false;
			setActiveBranch(suspense, pendingBranch);
			suspense.pendingBranch = null;
			suspense.isInFallback = false;
			let parent = suspense.parent;
			let hasUnresolvedAncestor = false;
			while (parent) {
				if (parent.pendingBranch) {
					parent.effects.push(...effects);
					hasUnresolvedAncestor = true;
					break;
				}
				parent = parent.parent;
			}
			if (!hasUnresolvedAncestor && !delayEnter) {
				queuePostFlushCb(effects);
			}
			suspense.effects = [];
			if (isSuspensible) {
				if (parentSuspense && parentSuspense.pendingBranch && parentSuspenseId === parentSuspense.pendingId) {
					parentSuspense.deps--;
					if (parentSuspense.deps === 0 && !sync) {
						parentSuspense.resolve();
					}
				}
			}
			triggerEvent(vnode2, "onResolve");
		},
		fallback(fallbackVNode) {
			if (!suspense.pendingBranch) {
				return;
			}
			const { vnode: vnode2, activeBranch, parentComponent: parentComponent2, container: container2, namespace: namespace2 } = suspense;
			triggerEvent(vnode2, "onFallback");
			const anchor2 = next(activeBranch);
			const mountFallback = () => {
				suspense.isFallbackMountPending = false;
				if (!suspense.isInFallback) {
					return;
				}
				patch(
					null,
					fallbackVNode,
					container2,
					anchor2,
					parentComponent2,
					null,
					// fallback tree will not have suspense context
					namespace2,
					slotScopeIds,
					optimized
				);
				setActiveBranch(suspense, fallbackVNode);
			};
			const delayEnter = fallbackVNode.transition && fallbackVNode.transition.mode === "out-in";
			if (delayEnter) {
				suspense.isFallbackMountPending = true;
				activeBranch.transition.afterLeave = mountFallback;
			}
			suspense.isInFallback = true;
			unmount(
				activeBranch,
				parentComponent2,
				null,
				// no suspense so unmount hooks fire now
				true
				// shouldRemove
			);
			if (!delayEnter) {
				mountFallback();
			}
		},
		move(container2, anchor2, type) {
			suspense.activeBranch && move(suspense.activeBranch, container2, anchor2, type);
			suspense.container = container2;
		},
		next() {
			return suspense.activeBranch && next(suspense.activeBranch);
		},
		registerDep(instance, setupRenderEffect, optimized2) {
			const isInPendingSuspense = !!suspense.pendingBranch;
			if (isInPendingSuspense) {
				suspense.deps++;
			}
			const hydratedEl = instance.vnode.el;
			instance.asyncDep.catch((err) => {
				handleError(err, instance, 0);
			}).then((asyncSetupResult) => {
				if (instance.isUnmounted || suspense.isUnmounted || suspense.pendingId !== instance.suspenseId) {
					return;
				}
				unsetCurrentInstance();
				instance.asyncResolved = true;
				const { vnode: vnode2 } = instance;
				if (!!("development" !== "production")) {
					pushWarningContext(vnode2);
				}
				handleSetupResult(instance, asyncSetupResult, false);
				if (hydratedEl) {
					vnode2.el = hydratedEl;
				}
				const placeholder = !hydratedEl && instance.subTree.el;
				setupRenderEffect(
					instance,
					vnode2,
					// component may have been moved before resolve.
					// if this is not a hydration, instance.subTree will be the comment
					// placeholder.
					parentNode(hydratedEl || instance.subTree.el),
					// anchor will not be used if this is hydration, so only need to
					// consider the comment placeholder case.
					hydratedEl ? null : next(instance.subTree),
					suspense,
					namespace,
					optimized2
				);
				if (placeholder) {
					vnode2.placeholder = null;
					remove(placeholder);
				}
				updateHOCHostEl(instance, vnode2.el);
				if (!!("development" !== "production")) {
					popWarningContext();
				}
				if (isInPendingSuspense && --suspense.deps === 0) {
					suspense.resolve();
				}
			});
		},
		unmount(parentSuspense2, doRemove) {
			suspense.isUnmounted = true;
			if (suspense.activeBranch) {
				unmount(suspense.activeBranch, parentComponent, parentSuspense2, doRemove);
			}
			if (suspense.pendingBranch) {
				unmount(suspense.pendingBranch, parentComponent, parentSuspense2, doRemove);
			}
		}
	};
	return suspense;
}
function hydrateSuspense(node, vnode, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, rendererInternals, hydrateNode) {
	const suspense = vnode.suspense = createSuspenseBoundary(
		vnode,
		parentSuspense,
		parentComponent,
		node.parentNode,
		// eslint-disable-next-line no-restricted-globals
		document.createElement("div"),
		null,
		namespace,
		slotScopeIds,
		optimized,
		rendererInternals,
		true
	);
	const result = hydrateNode(node, suspense.pendingBranch = vnode.ssContent, parentComponent, suspense, slotScopeIds, optimized);
	if (suspense.deps === 0) {
		suspense.resolve(false, true);
	}
	return result;
}
function normalizeSuspenseChildren(vnode) {
	const { shapeFlag, children } = vnode;
	const isSlotChildren = shapeFlag & 32;
	vnode.ssContent = normalizeSuspenseSlot(isSlotChildren ? children.default : children);
	vnode.ssFallback = isSlotChildren ? normalizeSuspenseSlot(children.fallback) : createVNode(Comment);
}
function normalizeSuspenseSlot(s) {
	let block;
	if (isFunction(s)) {
		const trackBlock = isBlockTreeEnabled && s._c;
		if (trackBlock) {
			s._d = false;
			openBlock();
		}
		s = s();
		if (trackBlock) {
			s._d = true;
			block = currentBlock;
			closeBlock();
		}
	}
	if (isArray(s)) {
		const singleChild = filterSingleRoot(s);
		if (!!("development" !== "production") && !singleChild && s.filter((child) => child !== NULL_DYNAMIC_COMPONENT).length > 0) {
			warn$1(`<Suspense> slots expect a single root node.`);
		}
		s = singleChild;
	}
	s = normalizeVNode(s);
	if (block && !s.dynamicChildren) {
		s.dynamicChildren = block.filter((c) => c !== s);
	}
	return s;
}
function queueEffectWithSuspense(fn, suspense) {
	if (suspense && suspense.pendingBranch) {
		if (isArray(fn)) {
			suspense.effects.push(...fn);
		} else {
			suspense.effects.push(fn);
		}
	} else {
		queuePostFlushCb(fn);
	}
}
function setActiveBranch(suspense, branch) {
	suspense.activeBranch = branch;
	const { vnode, parentComponent } = suspense;
	let el = branch.el;
	while (!el && branch.component) {
		branch = branch.component.subTree;
		el = branch.el;
	}
	vnode.el = el;
	if (parentComponent && parentComponent.subTree === vnode) {
		parentComponent.vnode.el = el;
		updateHOCHostEl(parentComponent, el);
	}
}
function isVNodeSuspensible(vnode) {
	const suspensible = vnode.props && vnode.props.suspensible;
	return suspensible != null && suspensible !== false;
}
const Fragment = /* @__PURE__ */ Symbol.for("v-fgt");
const Text = /* @__PURE__ */ Symbol.for("v-txt");
const Comment = /* @__PURE__ */ Symbol.for("v-cmt");
const Static = /* @__PURE__ */ Symbol.for("v-stc");
const blockStack = [];
let currentBlock = null;
function openBlock(disableTracking = false) {
	blockStack.push(currentBlock = disableTracking ? null : []);
}
function closeBlock() {
	blockStack.pop();
	currentBlock = blockStack[blockStack.length - 1] || null;
}
let isBlockTreeEnabled = 1;
function setBlockTracking(value, inVOnce = false) {
	isBlockTreeEnabled += value;
	if (value < 0 && currentBlock && inVOnce) {
		currentBlock.hasOnce = true;
	}
}
function setupBlock(vnode) {
	vnode.dynamicChildren = isBlockTreeEnabled > 0 ? currentBlock || EMPTY_ARR : null;
	closeBlock();
	if (isBlockTreeEnabled > 0 && currentBlock) {
		currentBlock.push(vnode);
	}
	return vnode;
}
function createElementBlock(type, props, children, patchFlag, dynamicProps, shapeFlag) {
	return setupBlock(createBaseVNode(type, props, children, patchFlag, dynamicProps, shapeFlag, true));
}
function createBlock(type, props, children, patchFlag, dynamicProps) {
	return setupBlock(createVNode(type, props, children, patchFlag, dynamicProps, true));
}
function isVNode(value) {
	return value ? value.__v_isVNode === true : false;
}
function isSameVNodeType(n1, n2) {
	if (!!("development" !== "production") && n2.shapeFlag & 6 && n1.component) {
		const dirtyInstances = hmrDirtyComponents.get(n2.type);
		if (dirtyInstances && dirtyInstances.has(n1.component)) {
			n1.shapeFlag &= -257;
			n2.shapeFlag &= -513;
			return false;
		}
	}
	return n1.type === n2.type && n1.key === n2.key;
}
let vnodeArgsTransformer;
function transformVNodeArgs(transformer) {
	vnodeArgsTransformer = transformer;
}
const createVNodeWithArgsTransform = (...args) => {
	return _createVNode(...vnodeArgsTransformer ? vnodeArgsTransformer(args, currentRenderingInstance) : args);
};
const normalizeKey = ({ key }) => key != null ? key : null;
const normalizeRef = ({ ref, ref_key, ref_for }) => {
	if (typeof ref === "number") {
		ref = "" + ref;
	}
	return ref != null ? isString(ref) || isRef(ref) || isFunction(ref) ? {
		i: currentRenderingInstance,
		r: ref,
		k: ref_key,
		f: !!ref_for
	} : ref : null;
};
function createBaseVNode(type, props = null, children = null, patchFlag = 0, dynamicProps = null, shapeFlag = type === Fragment ? 0 : 1, isBlockNode = false, needFullChildrenNormalization = false) {
	const vnode = {
		__v_isVNode: true,
		__v_skip: true,
		type,
		props,
		key: props && normalizeKey(props),
		ref: props && normalizeRef(props),
		scopeId: currentScopeId,
		slotScopeIds: null,
		children,
		component: null,
		suspense: null,
		ssContent: null,
		ssFallback: null,
		dirs: null,
		transition: null,
		el: null,
		anchor: null,
		target: null,
		targetStart: null,
		targetAnchor: null,
		staticCount: 0,
		shapeFlag,
		patchFlag,
		dynamicProps,
		dynamicChildren: null,
		appContext: null,
		ctx: currentRenderingInstance
	};
	if (needFullChildrenNormalization) {
		normalizeChildren(vnode, children);
		if (shapeFlag & 128) {
			type.normalize(vnode);
		}
	} else if (children) {
		vnode.shapeFlag |= isString(children) ? 8 : 16;
	}
	if (!!("development" !== "production") && vnode.key !== vnode.key) {
		warn$1(`VNode created with invalid key (NaN). VNode type:`, vnode.type);
	}
	if (isBlockTreeEnabled > 0 && !isBlockNode && currentBlock && (vnode.patchFlag > 0 || shapeFlag & 6) && vnode.patchFlag !== 32) {
		currentBlock.push(vnode);
	}
	return vnode;
}
const createVNode = !!("development" !== "production") ? createVNodeWithArgsTransform : _createVNode;
function _createVNode(type, props = null, children = null, patchFlag = 0, dynamicProps = null, isBlockNode = false) {
	if (!type || type === NULL_DYNAMIC_COMPONENT) {
		if (!!("development" !== "production") && !type) {
			warn$1(`Invalid vnode type when creating vnode: ${type}.`);
		}
		type = Comment;
	}
	if (isVNode(type)) {
		const cloned = cloneVNode(
			type,
			props,
			true
			/* mergeRef: true */
		);
		if (children) {
			normalizeChildren(cloned, children);
		}
		if (isBlockTreeEnabled > 0 && !isBlockNode && currentBlock) {
			if (cloned.shapeFlag & 6) {
				currentBlock[currentBlock.indexOf(type)] = cloned;
			} else {
				currentBlock.push(cloned);
			}
		}
		cloned.patchFlag = -2;
		return cloned;
	}
	if (isClassComponent(type)) {
		type = type.__vccOpts;
	}
	if (props) {
		props = guardReactiveProps(props);
		let { class: klass, style } = props;
		if (klass && !isString(klass)) {
			props.class = normalizeClass(klass);
		}
		if (isObject(style)) {
			if (isProxy(style) && !isArray(style)) {
				style = extend({}, style);
			}
			props.style = normalizeStyle(style);
		}
	}
	const shapeFlag = isString(type) ? 1 : isSuspense(type) ? 128 : isTeleport(type) ? 64 : isObject(type) ? 4 : isFunction(type) ? 2 : 0;
	if (!!("development" !== "production") && shapeFlag & 4 && isProxy(type)) {
		type = toRaw(type);
		warn$1(`Vue received a Component that was made a reactive object. This can lead to unnecessary performance overhead and should be avoided by marking the component with \`markRaw\` or using \`shallowRef\` instead of \`ref\`.`, `
Component that was made reactive: `, type);
	}
	return createBaseVNode(type, props, children, patchFlag, dynamicProps, shapeFlag, isBlockNode, true);
}
function guardReactiveProps(props) {
	if (!props) return null;
	return isProxy(props) || isInternalObject(props) ? extend({}, props) : props;
}
function cloneVNode(vnode, extraProps, mergeRef = false, cloneTransition = false) {
	const { props, ref, patchFlag, children, transition } = vnode;
	const mergedProps = extraProps ? mergeProps(props || {}, extraProps) : props;
	const cloned = {
		__v_isVNode: true,
		__v_skip: true,
		type: vnode.type,
		props: mergedProps,
		key: mergedProps && normalizeKey(mergedProps),
		ref: extraProps && extraProps.ref ? mergeRef && ref ? isArray(ref) ? ref.concat(normalizeRef(extraProps)) : [ref, normalizeRef(extraProps)] : normalizeRef(extraProps) : ref,
		scopeId: vnode.scopeId,
		slotScopeIds: vnode.slotScopeIds,
		children: !!("development" !== "production") && patchFlag === -1 && isArray(children) ? children.map(deepCloneVNode) : children,
		target: vnode.target,
		targetStart: vnode.targetStart,
		targetAnchor: vnode.targetAnchor,
		staticCount: vnode.staticCount,
		shapeFlag: vnode.shapeFlag,
		// if the vnode is cloned with extra props, we can no longer assume its
		// existing patch flag to be reliable and need to add the FULL_PROPS flag.
		// note: preserve flag for fragments since they use the flag for children
		// fast paths only.
		patchFlag: extraProps && vnode.type !== Fragment ? patchFlag === -1 ? 16 : patchFlag | 16 : patchFlag,
		dynamicProps: vnode.dynamicProps,
		dynamicChildren: vnode.dynamicChildren,
		appContext: vnode.appContext,
		dirs: vnode.dirs,
		transition,
		// These should technically only be non-null on mounted VNodes. However,
		// they *should* be copied for kept-alive vnodes. So we just always copy
		// them since them being non-null during a mount doesn't affect the logic as
		// they will simply be overwritten.
		component: vnode.component,
		suspense: vnode.suspense,
		ssContent: vnode.ssContent && cloneVNode(vnode.ssContent),
		ssFallback: vnode.ssFallback && cloneVNode(vnode.ssFallback),
		placeholder: vnode.placeholder,
		el: vnode.el,
		anchor: vnode.anchor,
		ctx: vnode.ctx,
		ce: vnode.ce
	};
	if (transition && cloneTransition) {
		setTransitionHooks(cloned, transition.clone(cloned));
	}
	return cloned;
}
function deepCloneVNode(vnode) {
	const cloned = cloneVNode(vnode);
	if (isArray(vnode.children)) {
		cloned.children = vnode.children.map(deepCloneVNode);
	}
	return cloned;
}
function createTextVNode(text = " ", flag = 0) {
	return createVNode(Text, null, text, flag);
}
function createStaticVNode(content, numberOfNodes) {
	const vnode = createVNode(Static, null, content);
	vnode.staticCount = numberOfNodes;
	return vnode;
}
function createCommentVNode(text = "", asBlock = false) {
	return asBlock ? (openBlock(), createBlock(Comment, null, text)) : createVNode(Comment, null, text);
}
function normalizeVNode(child) {
	if (child == null || typeof child === "boolean") {
		return createVNode(Comment);
	} else if (isArray(child)) {
		return createVNode(
			Fragment,
			null,
			// #3666, avoid reference pollution when reusing vnode
			child.slice()
		);
	} else if (isVNode(child)) {
		return cloneIfMounted(child);
	} else {
		return createVNode(Text, null, String(child));
	}
}
function cloneIfMounted(child) {
	return child.el === null && child.patchFlag !== -1 || child.memo ? child : cloneVNode(child);
}
function normalizeChildren(vnode, children) {
	let type = 0;
	const { shapeFlag } = vnode;
	if (children == null) {
		children = null;
	} else if (isArray(children)) {
		type = 16;
	} else if (typeof children === "object") {
		if (shapeFlag & (1 | 64)) {
			const slot = children.default;
			if (slot) {
				slot._c && (slot._d = false);
				normalizeChildren(vnode, slot());
				slot._c && (slot._d = true);
			}
			return;
		} else {
			type = 32;
			const slotFlag = children._;
			if (!slotFlag && !isInternalObject(children)) {
				children._ctx = currentRenderingInstance;
			} else if (slotFlag === 3 && currentRenderingInstance) {
				if (currentRenderingInstance.slots._ === 1) {
					children._ = 1;
				} else {
					children._ = 2;
					vnode.patchFlag |= 1024;
				}
			}
		}
	} else if (isFunction(children)) {
		if (shapeFlag & (1 | 64)) {
			normalizeChildren(vnode, { default: children });
			return;
		}
		children = {
			default: children,
			_ctx: currentRenderingInstance
		};
		type = 32;
	} else {
		children = String(children);
		if (shapeFlag & 64) {
			type = 16;
			children = [createTextVNode(children)];
		} else {
			type = 8;
		}
	}
	vnode.children = children;
	vnode.shapeFlag |= type;
}
function mergeProps(...args) {
	const ret = {};
	for (let i = 0; i < args.length; i++) {
		const toMerge = args[i];
		for (const key in toMerge) {
			if (key === "class") {
				if (ret.class !== toMerge.class) {
					ret.class = normalizeClass([ret.class, toMerge.class]);
				}
			} else if (key === "style") {
				ret.style = normalizeStyle([ret.style, toMerge.style]);
			} else if (isOn(key)) {
				const existing = ret[key];
				const incoming = toMerge[key];
				if (incoming && existing !== incoming && !(isArray(existing) && existing.includes(incoming))) {
					ret[key] = existing ? [].concat(existing, incoming) : incoming;
				} else if (incoming == null && existing == null && !isModelListener(key)) {
					ret[key] = incoming;
				}
			} else if (key !== "") {
				ret[key] = toMerge[key];
			}
		}
	}
	return ret;
}
function invokeVNodeHook(hook, instance, vnode, prevVNode = null) {
	callWithAsyncErrorHandling(hook, instance, 7, [vnode, prevVNode]);
}
const emptyAppContext = createAppContext();
let uid = 0;
function createComponentInstance(vnode, parent, suspense) {
	const type = vnode.type;
	const appContext = (parent ? parent.appContext : vnode.appContext) || emptyAppContext;
	const instance = {
		uid: uid++,
		vnode,
		type,
		parent,
		appContext,
		root: null,
		// to be immediately set
		next: null,
		subTree: null,
		// will be set synchronously right after creation
		effect: null,
		update: null,
		// will be set synchronously right after creation
		job: null,
		scope: new EffectScope(
			true
			/* detached */
		),
		render: null,
		proxy: null,
		exposed: null,
		exposeProxy: null,
		withProxy: null,
		provides: parent ? parent.provides : Object.create(appContext.provides),
		ids: parent ? parent.ids : [
			"",
			0,
			0
		],
		accessCache: null,
		renderCache: [],
		// local resolved assets
		components: null,
		directives: null,
		// resolved props and emits options
		propsOptions: normalizePropsOptions(type, appContext),
		emitsOptions: normalizeEmitsOptions(type, appContext),
		// emit
		emit: null,
		// to be set immediately
		emitted: null,
		// props default value
		propsDefaults: EMPTY_OBJ,
		// inheritAttrs
		inheritAttrs: type.inheritAttrs,
		// state
		ctx: EMPTY_OBJ,
		data: EMPTY_OBJ,
		props: EMPTY_OBJ,
		attrs: EMPTY_OBJ,
		slots: EMPTY_OBJ,
		refs: EMPTY_OBJ,
		setupState: EMPTY_OBJ,
		setupContext: null,
		// suspense related
		suspense,
		suspenseId: suspense ? suspense.pendingId : 0,
		asyncDep: null,
		asyncResolved: false,
		// lifecycle hooks
		// not using enums here because it results in computed properties
		isMounted: false,
		isUnmounted: false,
		isDeactivated: false,
		bc: null,
		c: null,
		bm: null,
		m: null,
		bu: null,
		u: null,
		um: null,
		bum: null,
		da: null,
		a: null,
		rtg: null,
		rtc: null,
		ec: null,
		sp: null
	};
	if (!!("development" !== "production")) {
		instance.ctx = createDevRenderContext(instance);
	} else {
		instance.ctx = { _: instance };
	}
	instance.root = parent ? parent.root : instance;
	instance.emit = emit.bind(null, instance);
	if (vnode.ce) {
		vnode.ce(instance);
	}
	return instance;
}
let currentInstance = null;
const getCurrentInstance = () => currentInstance || currentRenderingInstance;
let internalSetCurrentInstance;
let setInSSRSetupState;
{
	const g = getGlobalThis();
	const registerGlobalSetter = (key, setter) => {
		let setters;
		if (!(setters = g[key])) setters = g[key] = [];
		setters.push(setter);
		return (v) => {
			if (setters.length > 1) setters.forEach((set) => set(v));
			else setters[0](v);
		};
	};
	internalSetCurrentInstance = registerGlobalSetter(`__VUE_INSTANCE_SETTERS__`, (v) => currentInstance = v);
	setInSSRSetupState = registerGlobalSetter(`__VUE_SSR_SETTERS__`, (v) => isInSSRComponentSetup = v);
}
const setCurrentInstance = (instance) => {
	const prev = currentInstance;
	internalSetCurrentInstance(instance);
	instance.scope.on();
	return () => {
		instance.scope.off();
		internalSetCurrentInstance(prev);
	};
};
const unsetCurrentInstance = () => {
	currentInstance && currentInstance.scope.off();
	internalSetCurrentInstance(null);
};
const isBuiltInTag = /* @__PURE__ */ makeMap("slot,component");
function validateComponentName(name, { isNativeTag }) {
	if (isBuiltInTag(name) || isNativeTag(name)) {
		warn$1("Do not use built-in or reserved HTML elements as component id: " + name);
	}
}
function isStatefulComponent(instance) {
	return instance.vnode.shapeFlag & 4;
}
let isInSSRComponentSetup = false;
function setupComponent(instance, isSSR = false, optimized = false) {
	isSSR && setInSSRSetupState(isSSR);
	const { props, children } = instance.vnode;
	const isStateful = isStatefulComponent(instance);
	initProps(instance, props, isStateful, isSSR);
	initSlots(instance, children, optimized || isSSR);
	const setupResult = isStateful ? setupStatefulComponent(instance, isSSR) : void 0;
	isSSR && setInSSRSetupState(false);
	return setupResult;
}
function setupStatefulComponent(instance, isSSR) {
	const Component = instance.type;
	if (!!("development" !== "production")) {
		if (Component.name) {
			validateComponentName(Component.name, instance.appContext.config);
		}
		if (Component.components) {
			const names = Object.keys(Component.components);
			for (let i = 0; i < names.length; i++) {
				validateComponentName(names[i], instance.appContext.config);
			}
		}
		if (Component.directives) {
			const names = Object.keys(Component.directives);
			for (let i = 0; i < names.length; i++) {
				validateDirectiveName(names[i]);
			}
		}
		if (Component.compilerOptions && isRuntimeOnly()) {
			warn$1(`"compilerOptions" is only supported when using a build of Vue that includes the runtime compiler. Since you are using a runtime-only build, the options should be passed via your build tool config instead.`);
		}
	}
	instance.accessCache = /* @__PURE__ */ Object.create(null);
	instance.proxy = new Proxy(instance.ctx, PublicInstanceProxyHandlers);
	if (!!("development" !== "production")) {
		exposePropsOnRenderContext(instance);
	}
	const { setup } = Component;
	if (setup) {
		pauseTracking();
		const setupContext = instance.setupContext = setup.length > 1 ? createSetupContext(instance) : null;
		const reset = setCurrentInstance(instance);
		const setupResult = callWithErrorHandling(setup, instance, 0, [!!("development" !== "production") ? shallowReadonly(instance.props) : instance.props, setupContext]);
		const isAsyncSetup = isPromise(setupResult);
		resetTracking();
		reset();
		if ((isAsyncSetup || instance.sp) && !isAsyncWrapper(instance)) {
			markAsyncBoundary(instance);
		}
		if (isAsyncSetup) {
			setupResult.then(unsetCurrentInstance, unsetCurrentInstance);
			if (isSSR) {
				return setupResult.then((resolvedResult) => {
					handleSetupResult(instance, resolvedResult, isSSR);
				}).catch((e) => {
					handleError(e, instance, 0);
				});
			} else {
				instance.asyncDep = setupResult;
				if (!!("development" !== "production") && !instance.suspense) {
					const name = formatComponentName(instance, Component);
					warn$1(`Component <${name}>: setup function returned a promise, but no <Suspense> boundary was found in the parent component tree. A component with async setup() must be nested in a <Suspense> in order to be rendered.`);
				}
			}
		} else {
			handleSetupResult(instance, setupResult, isSSR);
		}
	} else {
		finishComponentSetup(instance, isSSR);
	}
}
function handleSetupResult(instance, setupResult, isSSR) {
	if (isFunction(setupResult)) {
		if (instance.type.__ssrInlineRender) {
			instance.ssrRender = setupResult;
		} else {
			instance.render = setupResult;
		}
	} else if (isObject(setupResult)) {
		if (!!("development" !== "production") && isVNode(setupResult)) {
			warn$1(`setup() should not return VNodes directly - return a render function instead.`);
		}
		if (!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) {
			instance.devtoolsRawSetupState = setupResult;
		}
		instance.setupState = proxyRefs(setupResult);
		if (!!("development" !== "production")) {
			exposeSetupStateOnRenderContext(instance);
		}
	} else if (!!("development" !== "production") && setupResult !== void 0) {
		warn$1(`setup() should return an object. Received: ${setupResult === null ? "null" : typeof setupResult}`);
	}
	finishComponentSetup(instance, isSSR);
}
let compile;
let installWithProxy;
function registerRuntimeCompiler(_compile) {
	compile = _compile;
	installWithProxy = (i) => {
		if (i.render._rc) {
			i.withProxy = new Proxy(i.ctx, RuntimeCompiledPublicInstanceProxyHandlers);
		}
	};
}
const isRuntimeOnly = () => !compile;
function finishComponentSetup(instance, isSSR, skipOptions) {
	const Component = instance.type;
	if (!instance.render) {
		if (!isSSR && compile && !Component.render) {
			const template = Component.template || __VUE_OPTIONS_API__ && resolveMergedOptions(instance).template;
			if (template) {
				if (!!("development" !== "production")) {
					startMeasure(instance, `compile`);
				}
				const { isCustomElement, compilerOptions } = instance.appContext.config;
				const { delimiters, compilerOptions: componentCompilerOptions } = Component;
				const finalCompilerOptions = extend(extend({
					isCustomElement,
					delimiters
				}, compilerOptions), componentCompilerOptions);
				Component.render = compile(template, finalCompilerOptions);
				if (!!("development" !== "production")) {
					endMeasure(instance, `compile`);
				}
			}
		}
		instance.render = Component.render || NOOP;
		if (installWithProxy) {
			installWithProxy(instance);
		}
	}
	if (__VUE_OPTIONS_API__ && true) {
		const reset = setCurrentInstance(instance);
		pauseTracking();
		try {
			applyOptions(instance);
		} finally {
			resetTracking();
			reset();
		}
	}
	if (!!("development" !== "production") && !Component.render && instance.render === NOOP && !isSSR) {
		if (!compile && Component.template) {
			warn$1(`Component provided template option but runtime compilation is not supported in this build of Vue.` + ` Configure your bundler to alias "vue" to "vue/dist/vue.esm-bundler.js".`);
		} else {
			warn$1(`Component is missing template or render function: `, Component);
		}
	}
}
const attrsProxyHandlers = !!("development" !== "production") ? {
	get(target, key) {
		markAttrsAccessed();
		track(target, "get", "");
		return target[key];
	},
	set() {
		warn$1(`setupContext.attrs is readonly.`);
		return false;
	},
	deleteProperty() {
		warn$1(`setupContext.attrs is readonly.`);
		return false;
	}
} : { get(target, key) {
	track(target, "get", "");
	return target[key];
} };
function getSlotsProxy(instance) {
	return new Proxy(instance.slots, { get(target, key) {
		track(instance, "get", "$slots");
		return target[key];
	} });
}
function createSetupContext(instance) {
	const expose = (exposed) => {
		if (!!("development" !== "production")) {
			if (instance.exposed) {
				warn$1(`expose() should be called only once per setup().`);
			}
			if (exposed != null) {
				let exposedType = typeof exposed;
				if (exposedType === "object") {
					if (isArray(exposed)) {
						exposedType = "array";
					} else if (isRef(exposed)) {
						exposedType = "ref";
					}
				}
				if (exposedType !== "object") {
					warn$1(`expose() should be passed a plain object, received ${exposedType}.`);
				}
			}
		}
		instance.exposed = exposed || {};
	};
	if (!!("development" !== "production")) {
		let attrsProxy;
		let slotsProxy;
		return Object.freeze({
			get attrs() {
				return attrsProxy || (attrsProxy = new Proxy(instance.attrs, attrsProxyHandlers));
			},
			get slots() {
				return slotsProxy || (slotsProxy = getSlotsProxy(instance));
			},
			get emit() {
				return (event, ...args) => instance.emit(event, ...args);
			},
			expose
		});
	} else {
		return {
			attrs: new Proxy(instance.attrs, attrsProxyHandlers),
			slots: instance.slots,
			emit: instance.emit,
			expose
		};
	}
}
function getComponentPublicInstance(instance) {
	if (instance.exposed) {
		return instance.exposeProxy || (instance.exposeProxy = new Proxy(proxyRefs(markRaw(instance.exposed)), {
			get(target, key) {
				if (key in target) {
					return target[key];
				} else if (key in publicPropertiesMap) {
					return publicPropertiesMap[key](instance);
				}
			},
			has(target, key) {
				return key in target || key in publicPropertiesMap;
			}
		}));
	} else {
		return instance.proxy;
	}
}
const classifyRE = /(?:^|[-_])\w/g;
const classify = (str) => str.replace(classifyRE, (c) => c.toUpperCase()).replace(/[-_]/g, "");
function getComponentName(Component, includeInferred = true) {
	return isFunction(Component) ? Component.displayName || Component.name : Component.name || includeInferred && Component.__name;
}
function formatComponentName(instance, Component, isRoot = false) {
	let name = getComponentName(Component);
	if (!name && Component.__file) {
		const match = Component.__file.match(/([^/\\]+)\.\w+$/);
		if (match) {
			name = match[1];
		}
	}
	if (!name && instance) {
		const inferFromRegistry = (registry) => {
			for (const key in registry) {
				if (registry[key] === Component) {
					return key;
				}
			}
		};
		name = inferFromRegistry(instance.components) || instance.parent && inferFromRegistry(instance.parent.type.components) || inferFromRegistry(instance.appContext.components);
	}
	return name ? classify(name) : isRoot ? `App` : `Anonymous`;
}
function isClassComponent(value) {
	return isFunction(value) && "__vccOpts" in value;
}
const computed = (getterOrOptions, debugOptions) => {
	const c = computed$1(getterOrOptions, debugOptions, isInSSRComponentSetup);
	if (!!("development" !== "production")) {
		const i = getCurrentInstance();
		if (i && i.appContext.config.warnRecursiveComputed) {
			c._warnRecursive = true;
		}
	}
	return c;
};
function h(type, propsOrChildren, children) {
	try {
		setBlockTracking(-1);
		const l = arguments.length;
		if (l === 2) {
			if (isObject(propsOrChildren) && !isArray(propsOrChildren)) {
				if (isVNode(propsOrChildren)) {
					return createVNode(type, null, [propsOrChildren]);
				}
				return createVNode(type, propsOrChildren);
			} else {
				return createVNode(type, null, propsOrChildren);
			}
		} else {
			if (l > 3) {
				children = Array.prototype.slice.call(arguments, 2);
			} else if (l === 3 && isVNode(children)) {
				children = [children];
			}
			return createVNode(type, propsOrChildren, children);
		}
	} finally {
		setBlockTracking(1);
	}
}
function initCustomFormatter() {
	if (!!!("development" !== "production") || typeof window === "undefined") {
		return;
	}
	const vueStyle = { style: "color:#3ba776" };
	const numberStyle = { style: "color:#1677ff" };
	const stringStyle = { style: "color:#f5222d" };
	const keywordStyle = { style: "color:#eb2f96" };
	const formatter = {
		__vue_custom_formatter: true,
		header(obj) {
			if (!isObject(obj)) {
				return null;
			}
			if (obj.__isVue) {
				return [
					"div",
					vueStyle,
					`VueInstance`
				];
			} else if (isRef(obj)) {
				pauseTracking();
				const value = obj.value;
				resetTracking();
				return [
					"div",
					{},
					[
						"span",
						vueStyle,
						genRefFlag(obj)
					],
					"<",
					formatValue(value),
					`>`
				];
			} else if (isReactive(obj)) {
				return [
					"div",
					{},
					[
						"span",
						vueStyle,
						isShallow(obj) ? "ShallowReactive" : "Reactive"
					],
					"<",
					formatValue(obj),
					`>${isReadonly(obj) ? ` (readonly)` : ``}`
				];
			} else if (isReadonly(obj)) {
				return [
					"div",
					{},
					[
						"span",
						vueStyle,
						isShallow(obj) ? "ShallowReadonly" : "Readonly"
					],
					"<",
					formatValue(obj),
					">"
				];
			}
			return null;
		},
		hasBody(obj) {
			return obj && obj.__isVue;
		},
		body(obj) {
			if (obj && obj.__isVue) {
				return [
					"div",
					{},
					...formatInstance(obj.$)
				];
			}
		}
	};
	function formatInstance(instance) {
		const blocks = [];
		if (instance.type.props && instance.props) {
			blocks.push(createInstanceBlock("props", toRaw(instance.props)));
		}
		if (instance.setupState !== EMPTY_OBJ) {
			blocks.push(createInstanceBlock("setup", instance.setupState));
		}
		if (instance.data !== EMPTY_OBJ) {
			blocks.push(createInstanceBlock("data", toRaw(instance.data)));
		}
		const computed = extractKeys(instance, "computed");
		if (computed) {
			blocks.push(createInstanceBlock("computed", computed));
		}
		const injected = extractKeys(instance, "inject");
		if (injected) {
			blocks.push(createInstanceBlock("injected", injected));
		}
		blocks.push([
			"div",
			{},
			[
				"span",
				{ style: keywordStyle.style + ";opacity:0.66" },
				"$ (internal): "
			],
			["object", { object: instance }]
		]);
		return blocks;
	}
	function createInstanceBlock(type, target) {
		target = extend({}, target);
		if (!Object.keys(target).length) {
			return ["span", {}];
		}
		return [
			"div",
			{ style: "line-height:1.25em;margin-bottom:0.6em" },
			[
				"div",
				{ style: "color:#476582" },
				type
			],
			[
				"div",
				{ style: "padding-left:1.25em" },
				...Object.keys(target).map((key) => {
					return [
						"div",
						{},
						[
							"span",
							keywordStyle,
							key + ": "
						],
						formatValue(target[key], false)
					];
				})
			]
		];
	}
	function formatValue(v, asRaw = true) {
		if (typeof v === "number") {
			return [
				"span",
				numberStyle,
				v
			];
		} else if (typeof v === "string") {
			return [
				"span",
				stringStyle,
				JSON.stringify(v)
			];
		} else if (typeof v === "boolean") {
			return [
				"span",
				keywordStyle,
				v
			];
		} else if (isObject(v)) {
			return ["object", { object: asRaw ? toRaw(v) : v }];
		} else {
			return [
				"span",
				stringStyle,
				String(v)
			];
		}
	}
	function extractKeys(instance, type) {
		const Comp = instance.type;
		if (isFunction(Comp)) {
			return;
		}
		const extracted = {};
		for (const key in instance.ctx) {
			if (isKeyOfType(Comp, key, type)) {
				extracted[key] = instance.ctx[key];
			}
		}
		return extracted;
	}
	function isKeyOfType(Comp, key, type) {
		const opts = Comp[type];
		if (isArray(opts) && opts.includes(key) || isObject(opts) && key in opts) {
			return true;
		}
		if (Comp.extends && isKeyOfType(Comp.extends, key, type)) {
			return true;
		}
		if (Comp.mixins && Comp.mixins.some((m) => isKeyOfType(m, key, type))) {
			return true;
		}
	}
	function genRefFlag(v) {
		if (isShallow(v)) {
			return `ShallowRef`;
		}
		if (v.effect) {
			return `ComputedRef`;
		}
		return `Ref`;
	}
	if (window.devtoolsFormatters) {
		window.devtoolsFormatters.push(formatter);
	} else {
		window.devtoolsFormatters = [formatter];
	}
}
function withMemo(memo, render, cache, index) {
	const cached = cache[index];
	if (cached && isMemoSame(cached, memo)) {
		return cached;
	}
	const ret = render();
	ret.memo = memo.slice();
	ret.cacheIndex = index;
	return cache[index] = ret;
}
function isMemoSame(cached, memo) {
	const prev = cached.memo;
	if (prev.length != memo.length) {
		return false;
	}
	for (let i = 0; i < prev.length; i++) {
		if (hasChanged(prev[i], memo[i])) {
			return false;
		}
	}
	if (isBlockTreeEnabled > 0 && currentBlock) {
		currentBlock.push(cached);
	}
	return true;
}
const version = "3.5.40";
const warn = !!("development" !== "production") ? warn$1 : NOOP;
const ErrorTypeStrings = ErrorTypeStrings$1;
const devtools = !!("development" !== "production") || true ? devtools$1 : void 0;
const setDevtoolsHook = !!("development" !== "production") || true ? setDevtoolsHook$1 : NOOP;
const _ssrUtils = {
	createComponentInstance,
	setupComponent,
	renderComponentRoot,
	setCurrentRenderingInstance,
	isVNode,
	normalizeVNode,
	getComponentPublicInstance,
	ensureValidVNode,
	pushWarningContext,
	popWarningContext
};
const ssrUtils = _ssrUtils;
const resolveFilter = null;
const compatUtils = null;
const DeprecationTypes = null;
export { BaseTransition, BaseTransitionPropsValidators, Comment, DeprecationTypes, ErrorCodes, ErrorTypeStrings, Fragment, KeepAlive, Static, Suspense, Teleport, Text, assertNumber, callWithAsyncErrorHandling, callWithErrorHandling, cloneVNode, compatUtils, computed, createBlock, createCommentVNode, createElementBlock, createBaseVNode as createElementVNode, createHydrationRenderer, createPropsRestProxy, createRenderer, createSlots, createStaticVNode, createTextVNode, createVNode, defineAsyncComponent, defineComponent, defineEmits, defineExpose, defineModel, defineOptions, defineProps, defineSlots, devtools, getCurrentInstance, getTransitionRawChildren, guardReactiveProps, h, handleError, hasInjectionContext, hydrateOnIdle, hydrateOnInteraction, hydrateOnMediaQuery, hydrateOnVisible, initCustomFormatter, inject, isMemoSame, isRuntimeOnly, isVNode, mergeDefaults, mergeModels, mergeProps, nextTick, onActivated, onBeforeMount, onBeforeUnmount, onBeforeUpdate, onDeactivated, onErrorCaptured, onMounted, onRenderTracked, onRenderTriggered, onServerPrefetch, onUnmounted, onUpdated, openBlock, popScopeId, provide, pushScopeId, queuePostFlushCb, registerRuntimeCompiler, renderList, renderSlot, resolveComponent, resolveDirective, resolveDynamicComponent, resolveFilter, resolveTransitionHooks, setBlockTracking, setDevtoolsHook, setTransitionHooks, ssrContextKey, ssrUtils, toHandlers, transformVNodeArgs, useAttrs, useId, useModel, useSSRContext, useSlots, useTemplateRef, useTransitionState, version, warn, watch, watchEffect, watchPostEffect, watchSyncEffect, withAsyncContext, withCtx, withDefaults, withDirectives, withMemo, withScopeId };

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFLQSxTQUFTLGVBQWUsZUFBZSxPQUFPLE9BQU8sVUFBVSxTQUFTLFNBQVMsWUFBWSxVQUFVLFlBQVksS0FBSyxXQUFXLFlBQVksa0JBQWtCLFlBQVksWUFBWSxpQkFBaUIsT0FBTyxVQUFVLFdBQVcsaUJBQWlCLFNBQVMsZ0JBQWdCLFNBQVMsV0FBVyxTQUFTLGFBQWEsWUFBWSxrQkFBa0I7QUFDeFYsU0FBUyxhQUFhLGdCQUFnQixjQUFjLGdCQUFnQixXQUFXLFFBQVEsYUFBYSxpQkFBaUIsbUJBQW1CLFNBQVMsWUFBWSxZQUFZLE9BQU8sV0FBVyxTQUFTLGdCQUFnQixrQkFBa0IsV0FBVyxVQUFVLFVBQVUsS0FBSyxpQkFBaUIsaUJBQWlCLFlBQVksTUFBTSxPQUFPLE9BQU8sUUFBUSxTQUFTLFlBQVksYUFBYTtBQUN0WCxTQUFTLFVBQVUsWUFBWSxXQUFXLFdBQVcsU0FBUyxNQUFNLGVBQWUsUUFBUSxvQkFBb0IsSUFBSSxRQUFRLFFBQVEsS0FBSyxNQUFNLGdCQUFnQixnQkFBZ0IsZ0JBQWdCLGdCQUFnQixnQkFBZ0IsZUFBZSxpQkFBaUIsb0JBQW9CLHVCQUF1QixzQkFBc0Isc0JBQXNCLFVBQVUsVUFBVSxnQkFBZ0IsY0FBYyxVQUFVLFlBQVksVUFBVSxtQkFBbUIsV0FBVyxZQUFZLGVBQWUsaUJBQWlCLFlBQVksV0FBVyxXQUFXLFNBQVMsZ0JBQWdCO0FBQzVpQixTQUFTLFVBQVUsWUFBWSxnQkFBZ0IsZ0JBQWdCLGdCQUFnQixpQkFBaUIsb0JBQW9CO0FBRXBILE1BQU0sUUFBUSxDQUFDO0FBQ2YsU0FBUyxtQkFBbUIsT0FBTztDQUNqQyxNQUFNLEtBQUssS0FBSztBQUNsQjtBQUNBLFNBQVMsb0JBQW9CO0NBQzNCLE1BQU0sSUFBSTtBQUNaO0FBQ0EsSUFBSSxZQUFZO0FBQ2hCLFNBQVMsT0FBTyxLQUFLLEdBQUcsTUFBTTtDQUM1QixJQUFJLFdBQVc7Q0FDZixZQUFZO0NBQ1osY0FBYztDQUNkLE1BQU0sV0FBVyxNQUFNLFNBQVMsTUFBTSxNQUFNLFNBQVMsRUFBRSxDQUFDLFlBQVk7Q0FDcEUsTUFBTSxpQkFBaUIsWUFBWSxTQUFTLFdBQVcsT0FBTztDQUM5RCxNQUFNLFFBQVEsa0JBQWtCO0NBQ2hDLElBQUksZ0JBQWdCO0VBQ2xCLHNCQUNFLGdCQUNBLFVBQ0EsSUFDQTtHQUVFLE1BQU0sS0FBSyxLQUFLLE1BQU07SUFDcEIsSUFBSSxJQUFJO0lBQ1IsUUFBUSxNQUFNLEtBQUssRUFBRSxhQUFhLE9BQU8sS0FBSyxJQUFJLEdBQUcsS0FBSyxDQUFDLE1BQU0sT0FBTyxLQUFLLEtBQUssVUFBVSxDQUFDO0dBQy9GLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtHQUNWLFlBQVksU0FBUztHQUNyQixNQUFNLEtBQ0gsRUFBRSxZQUFZLE9BQU8sb0JBQW9CLFVBQVUsTUFBTSxJQUFJLEVBQUUsRUFDbEUsQ0FBQyxDQUFDLEtBQUssSUFBSTtHQUNYO0VBQ0YsQ0FDRjtDQUNGLE9BQU87RUFDTCxNQUFNLFdBQVcsQ0FBQyxlQUFlLE9BQU8sR0FBRyxJQUFJO0VBQy9DLElBQUksTUFBTSxVQUNWLE1BQU07R0FDSixTQUFTLEtBQUs7R0FDakIsR0FBRyxZQUFZLEtBQUssQ0FBQztFQUNwQjtFQUNBLFFBQVEsS0FBSyxHQUFHLFFBQVE7Q0FDMUI7Q0FDQSxjQUFjO0NBQ2QsWUFBWTtBQUNkO0FBQ0EsU0FBUyxvQkFBb0I7Q0FDM0IsSUFBSSxlQUFlLE1BQU0sTUFBTSxTQUFTO0NBQ3hDLElBQUksQ0FBQyxjQUFjO0VBQ2pCLE9BQU8sQ0FBQztDQUNWO0NBQ0EsTUFBTSxrQkFBa0IsQ0FBQztDQUN6QixPQUFPLGNBQWM7RUFDbkIsTUFBTSxPQUFPLGdCQUFnQjtFQUM3QixJQUFJLFFBQVEsS0FBSyxVQUFVLGNBQWM7R0FDdkMsS0FBSztFQUNQLE9BQU87R0FDTCxnQkFBZ0IsS0FBSztJQUNuQixPQUFPO0lBQ1AsY0FBYztHQUNoQixDQUFDO0VBQ0g7RUFDQSxNQUFNLGlCQUFpQixhQUFhLGFBQWEsYUFBYSxVQUFVO0VBQ3hFLGVBQWUsa0JBQWtCLGVBQWU7Q0FDbEQ7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLFlBQVksT0FBTztDQUMxQixNQUFNLE9BQU8sQ0FBQztDQUNkLE1BQU0sU0FBUyxPQUFPLE1BQU07RUFDMUIsS0FBSyxLQUFLLEdBQUcsTUFBTSxJQUFJLENBQUMsSUFBSSxDQUFDO0NBQ2hDLEdBQUcsR0FBRyxpQkFBaUIsS0FBSyxDQUFDO0NBQzVCLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGlCQUFpQixFQUFFLE9BQU8sZ0JBQWdCO0NBQ2pELE1BQU0sVUFBVSxlQUFlLElBQUksUUFBUSxhQUFhLHFCQUFxQjtDQUM3RSxNQUFNLFNBQVMsTUFBTSxZQUFZLE1BQU0sVUFBVSxVQUFVLE9BQU87Q0FDbEUsTUFBTSxPQUFPLFFBQVEsb0JBQ25CLE1BQU0sV0FDTixNQUFNLE1BQ04sTUFDRjtDQUNBLE1BQU0sUUFBUSxNQUFNO0NBQ3BCLE9BQU8sTUFBTSxRQUFRO0VBQUM7RUFBTSxHQUFHLFlBQVksTUFBTSxLQUFLO0VBQUc7Q0FBSyxJQUFJLENBQUMsT0FBTyxLQUFLO0FBQ2pGO0FBQ0EsU0FBUyxZQUFZLE9BQU87Q0FDMUIsTUFBTSxNQUFNLENBQUM7Q0FDYixNQUFNLE9BQU8sT0FBTyxLQUFLLEtBQUs7Q0FDOUIsS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxRQUFRO0VBQ2hDLElBQUksS0FBSyxHQUFHLFdBQVcsS0FBSyxNQUFNLElBQUksQ0FBQztDQUN6QyxDQUFDO0NBQ0QsSUFBSSxLQUFLLFNBQVMsR0FBRztFQUNuQixJQUFJLEtBQUssTUFBTTtDQUNqQjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsV0FBVyxLQUFLLE9BQU8sS0FBSztDQUNuQyxJQUFJLFNBQVMsS0FBSyxHQUFHO0VBQ25CLFFBQVEsS0FBSyxVQUFVLEtBQUs7RUFDNUIsT0FBTyxNQUFNLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBRyxPQUFPO0NBQ3pDLE9BQU8sSUFBSSxPQUFPLFVBQVUsWUFBWSxPQUFPLFVBQVUsYUFBYSxTQUFTLE1BQU07RUFDbkYsT0FBTyxNQUFNLFFBQVEsQ0FBQyxHQUFHLElBQUksR0FBRyxPQUFPO0NBQ3pDLE9BQU8sSUFBSSxNQUFNLEtBQUssR0FBRztFQUN2QixRQUFRLFdBQVcsS0FBSyxNQUFNLE1BQU0sS0FBSyxHQUFHLElBQUk7RUFDaEQsT0FBTyxNQUFNLFFBQVE7R0FBQyxHQUFHLElBQUk7R0FBUTtHQUFPO0VBQUc7Q0FDakQsT0FBTyxJQUFJLFdBQVcsS0FBSyxHQUFHO0VBQzVCLE9BQU8sQ0FBQyxHQUFHLElBQUksS0FBSyxNQUFNLE9BQU8sSUFBSSxNQUFNLEtBQUssS0FBSyxJQUFJO0NBQzNELE9BQU87RUFDTCxRQUFRLE1BQU0sS0FBSztFQUNuQixPQUFPLE1BQU0sUUFBUSxDQUFDLEdBQUcsSUFBSSxJQUFJLEtBQUs7Q0FDeEM7QUFDRjtBQUNBLFNBQVMsYUFBYSxLQUFLLE1BQU07Q0FDL0IsSUFBSSxDQUFDLENBQUMsb0JBQTJCLGVBQWU7Q0FDaEQsSUFBSSxRQUFRLEtBQUssR0FBRztFQUNsQjtDQUNGLE9BQU8sSUFBSSxPQUFPLFFBQVEsVUFBVTtFQUNsQyxPQUFPLEdBQUcsS0FBSywrQkFBK0IsS0FBSyxVQUFVLEdBQUcsRUFBRSxFQUFFO0NBQ3RFLE9BQU8sSUFBSSxNQUFNLEdBQUcsR0FBRztFQUNyQixPQUFPLEdBQUcsS0FBSyxzREFBc0Q7Q0FDdkU7QUFDRjtBQUVBLE1BQU0sYUFBYTtDQUNqQixrQkFBa0I7Q0FDbEIsS0FBSztDQUNMLG1CQUFtQjtDQUNuQixLQUFLO0NBQ0wsd0JBQXdCO0NBQ3hCLEtBQUs7Q0FDTCwyQkFBMkI7Q0FDM0IsS0FBSztDQUNMLGNBQWM7Q0FDZCxLQUFLO0NBQ0wsa0JBQWtCO0NBQ2xCLEtBQUs7Q0FDTCxtQkFBbUI7Q0FDbkIsS0FBSztDQUNMLHFCQUFxQjtDQUNyQixNQUFNO0NBQ04sb0JBQW9CO0NBQ3BCLE1BQU07Q0FDTixnQkFBZ0I7Q0FDaEIsTUFBTTtDQUNOLDBCQUEwQjtDQUMxQixNQUFNO0NBQ04sYUFBYTtDQUNiLE1BQU07Q0FDTixvQkFBb0I7Q0FDcEIsTUFBTTtDQUNOLHVCQUF1QjtDQUN2QixNQUFNO0FBQ1I7QUFDQSxNQUFNLHFCQUFxQjtFQUN4QixPQUFPO0VBQ1AsT0FBTztFQUNQLE1BQU07RUFDTixPQUFPO0VBQ1AsTUFBTTtFQUNOLE9BQU87RUFDUCxNQUFNO0VBQ04sUUFBUTtFQUNSLE9BQU87RUFDUCxNQUFNO0VBQ04sT0FBTztFQUNQLE9BQU87RUFDUCxRQUFRO0VBQ1IsUUFBUTtFQUNSLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7RUFDSixLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0FBQ1I7QUFDQSxTQUFTLHNCQUFzQixJQUFJLFVBQVUsTUFBTSxNQUFNO0NBQ3ZELElBQUk7RUFDRixPQUFPLE9BQU8sR0FBRyxHQUFHLElBQUksSUFBSSxHQUFHO0NBQ2pDLFNBQVMsS0FBSztFQUNaLFlBQVksS0FBSyxVQUFVLElBQUk7Q0FDakM7QUFDRjtBQUNBLFNBQVMsMkJBQTJCLElBQUksVUFBVSxNQUFNLE1BQU07Q0FDNUQsSUFBSSxXQUFXLEVBQUUsR0FBRztFQUNsQixNQUFNLE1BQU0sc0JBQXNCLElBQUksVUFBVSxNQUFNLElBQUk7RUFDMUQsSUFBSSxPQUFPLFVBQVUsR0FBRyxHQUFHO0dBQ3pCLElBQUksT0FBTyxRQUFRO0lBQ2pCLFlBQVksS0FBSyxVQUFVLElBQUk7R0FDakMsQ0FBQztFQUNIO0VBQ0EsT0FBTztDQUNUO0NBQ0EsSUFBSSxRQUFRLEVBQUUsR0FBRztFQUNmLE1BQU0sU0FBUyxDQUFDO0VBQ2hCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLFFBQVEsS0FBSztHQUNsQyxPQUFPLEtBQUssMkJBQTJCLEdBQUcsSUFBSSxVQUFVLE1BQU0sSUFBSSxDQUFDO0VBQ3JFO0VBQ0EsT0FBTztDQUNULE9BQU8sSUFBSSxDQUFDLG9CQUEyQixlQUFlO0VBQ3BELE9BQ0UsOERBQThELE9BQU8sSUFDdkU7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxZQUFZLEtBQUssVUFBVSxNQUFNLGFBQWEsTUFBTTtDQUMzRCxNQUFNLGVBQWUsV0FBVyxTQUFTLFFBQVE7Q0FDakQsTUFBTSxFQUFFLGNBQWMsb0NBQW9DLFlBQVksU0FBUyxXQUFXLFVBQVU7Q0FDcEcsSUFBSSxVQUFVO0VBQ1osSUFBSSxNQUFNLFNBQVM7RUFDbkIsTUFBTSxrQkFBa0IsU0FBUztFQUNqQyxNQUFNLFlBQVksQ0FBQyxvQkFBMkIsZ0JBQWdCLG1CQUFtQixRQUFRLDhDQUE4QztFQUN2SSxPQUFPLEtBQUs7R0FDVixNQUFNLHFCQUFxQixJQUFJO0dBQy9CLElBQUksb0JBQW9CO0lBQ3RCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxtQkFBbUIsUUFBUSxLQUFLO0tBQ2xELElBQUksbUJBQW1CLEVBQUUsQ0FBQyxLQUFLLGlCQUFpQixTQUFTLE1BQU0sT0FBTztNQUNwRTtLQUNGO0lBQ0Y7R0FDRjtHQUNBLE1BQU0sSUFBSTtFQUNaO0VBQ0EsSUFBSSxjQUFjO0dBQ2hCLGNBQWM7R0FDZCxzQkFBc0IsY0FBYyxNQUFNLElBQUk7SUFDNUM7SUFDQTtJQUNBO0dBQ0YsQ0FBQztHQUNELGNBQWM7R0FDZDtFQUNGO0NBQ0Y7Q0FDQSxTQUFTLEtBQUssTUFBTSxjQUFjLFlBQVksK0JBQStCO0FBQy9FO0FBQ0EsU0FBUyxTQUFTLEtBQUssTUFBTSxjQUFjLGFBQWEsTUFBTSxjQUFjLE9BQU87Q0FDakYsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0VBQzdDLE1BQU0sT0FBTyxtQkFBbUI7RUFDaEMsSUFBSSxjQUFjO0dBQ2hCLG1CQUFtQixZQUFZO0VBQ2pDO0VBQ0EsT0FBTyxrQkFBa0IsT0FBTyx3QkFBd0IsU0FBUyxJQUFJO0VBQ3JFLElBQUksY0FBYztHQUNoQixrQkFBa0I7RUFDcEI7RUFDQSxJQUFJLFlBQVk7R0FDZCxNQUFNO0VBQ1IsT0FBTztHQUNMLFFBQVEsTUFBTSxHQUFHO0VBQ25CO0NBQ0YsT0FBTyxJQUFJLGFBQWE7RUFDdEIsTUFBTTtDQUNSLE9BQU87RUFDTCxRQUFRLE1BQU0sR0FBRztDQUNuQjtBQUNGO0FBRUEsTUFBTSxRQUFRLENBQUM7QUFDZixJQUFJLGFBQWEsQ0FBQztBQUNsQixNQUFNLHNCQUFzQixDQUFDO0FBQzdCLElBQUkscUJBQXFCO0FBQ3pCLElBQUksaUJBQWlCO0FBQ3JCLE1BQU0sa0JBQWtDLHdCQUFRLFFBQVE7QUFDeEQsSUFBSSxzQkFBc0I7QUFDMUIsTUFBTSxrQkFBa0I7QUFDeEIsU0FBUyxTQUFTLElBQUk7Q0FDcEIsTUFBTSxJQUFJLHVCQUF1QjtDQUNqQyxPQUFPLEtBQUssRUFBRSxLQUFLLE9BQU8sR0FBRyxLQUFLLElBQUksSUFBSSxFQUFFLElBQUk7QUFDbEQ7QUFDQSxTQUFTLG1CQUFtQixJQUFJO0NBQzlCLElBQUksUUFBUSxhQUFhO0NBQ3pCLElBQUksTUFBTSxNQUFNO0NBQ2hCLE9BQU8sUUFBUSxLQUFLO0VBQ2xCLE1BQU0sU0FBUyxRQUFRLFFBQVE7RUFDL0IsTUFBTSxZQUFZLE1BQU07RUFDeEIsTUFBTSxjQUFjLE1BQU0sU0FBUztFQUNuQyxJQUFJLGNBQWMsTUFBTSxnQkFBZ0IsTUFBTSxVQUFVLFFBQVEsR0FBRztHQUNqRSxRQUFRLFNBQVM7RUFDbkIsT0FBTztHQUNMLE1BQU07RUFDUjtDQUNGO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxTQUFTLEtBQUs7Q0FDckIsSUFBSSxFQUFFLElBQUksUUFBUSxJQUFJO0VBQ3BCLE1BQU0sUUFBUSxNQUFNLEdBQUc7RUFDdkIsTUFBTSxVQUFVLE1BQU0sTUFBTSxTQUFTO0VBQ3JDLElBQUksQ0FBQyxXQUNMLEVBQUUsSUFBSSxRQUFRLE1BQU0sU0FBUyxNQUFNLE9BQU8sR0FBRztHQUMzQyxNQUFNLEtBQUssR0FBRztFQUNoQixPQUFPO0dBQ0wsTUFBTSxPQUFPLG1CQUFtQixLQUFLLEdBQUcsR0FBRyxHQUFHO0VBQ2hEO0VBQ0EsSUFBSSxTQUFTO0VBQ2IsV0FBVztDQUNiO0FBQ0Y7QUFDQSxTQUFTLGFBQWE7Q0FDcEIsSUFBSSxDQUFDLHFCQUFxQjtFQUN4QixzQkFBc0IsZ0JBQWdCLEtBQUssU0FBUztDQUN0RDtBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsSUFBSTtDQUM1QixJQUFJLENBQUMsUUFBUSxFQUFFLEdBQUc7RUFDaEIsSUFBSSxzQkFBc0IsR0FBRyxPQUFPLENBQUMsR0FBRztHQUN0QyxtQkFBbUIsT0FBTyxpQkFBaUIsR0FBRyxHQUFHLEVBQUU7RUFDckQsT0FBTyxJQUFJLEVBQUUsR0FBRyxRQUFRLElBQUk7R0FDMUIsb0JBQW9CLEtBQUssRUFBRTtHQUMzQixHQUFHLFNBQVM7RUFDZDtDQUNGLE9BQU87RUFDTCxvQkFBb0IsS0FBSyxHQUFHLEVBQUU7Q0FDaEM7Q0FDQSxXQUFXO0FBQ2I7QUFDQSxTQUFTLGlCQUFpQixVQUFVLE1BQU0sSUFBSSxhQUFhLEdBQUc7Q0FDNUQsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0VBQzdDLE9BQU8sd0JBQXdCLElBQUksSUFBSTtDQUN6QztDQUNBLE9BQU8sSUFBSSxNQUFNLFFBQVEsS0FBSztFQUM1QixNQUFNLEtBQUssTUFBTTtFQUNqQixJQUFJLE1BQU0sR0FBRyxRQUFRLEdBQUc7R0FDdEIsSUFBSSxZQUFZLEdBQUcsT0FBTyxTQUFTLEtBQUs7SUFDdEM7R0FDRjtHQUNBLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLHNCQUFzQixNQUFNLEVBQUUsR0FBRztJQUNoRjtHQUNGO0dBQ0EsTUFBTSxPQUFPLEdBQUcsQ0FBQztHQUNqQjtHQUNBLElBQUksR0FBRyxRQUFRLEdBQUc7SUFDaEIsR0FBRyxTQUFTLENBQUM7R0FDZjtHQUNBLEdBQUc7R0FDSCxJQUFJLEVBQUUsR0FBRyxRQUFRLElBQUk7SUFDbkIsR0FBRyxTQUFTLENBQUM7R0FDZjtFQUNGO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsa0JBQWtCLE1BQU07Q0FDL0IsSUFBSSxvQkFBb0IsUUFBUTtFQUM5QixNQUFNLFVBQVUsQ0FBQyxHQUFHLElBQUksSUFBSSxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsTUFDL0MsR0FBRyxNQUFNLE1BQU0sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxDQUM5QjtFQUNBLG9CQUFvQixTQUFTO0VBQzdCLElBQUksb0JBQW9CO0dBQ3RCLG1CQUFtQixLQUFLLEdBQUcsT0FBTztHQUNsQztFQUNGO0VBQ0EscUJBQXFCO0VBQ3JCLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtHQUM3QyxPQUFPLHdCQUF3QixJQUFJLElBQUk7RUFDekM7RUFDQSxLQUFLLGlCQUFpQixHQUFHLGlCQUFpQixtQkFBbUIsUUFBUSxrQkFBa0I7R0FDckYsTUFBTSxLQUFLLG1CQUFtQjtHQUM5QixJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixzQkFBc0IsTUFBTSxFQUFFLEdBQUc7SUFDaEY7R0FDRjtHQUNBLElBQUksR0FBRyxRQUFRLEdBQUc7SUFDaEIsR0FBRyxTQUFTLENBQUM7R0FDZjtHQUNBLElBQUksRUFBRSxHQUFHLFFBQVEsSUFBSSxHQUFHO0dBQ3hCLEdBQUcsU0FBUyxDQUFDO0VBQ2Y7RUFDQSxxQkFBcUI7RUFDckIsaUJBQWlCO0NBQ25CO0FBQ0Y7QUFDQSxNQUFNLFNBQVMsUUFBUSxJQUFJLE1BQU0sT0FBTyxJQUFJLFFBQVEsSUFBSSxDQUFDLElBQUksV0FBVyxJQUFJO0FBQzVFLFNBQVMsVUFBVSxNQUFNO0NBQ3ZCLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtFQUM3QyxPQUFPLHdCQUF3QixJQUFJLElBQUk7Q0FDekM7Q0FDQSxNQUFNLFFBQVEsQ0FBQyxvQkFBMkIsaUJBQWlCLFFBQVEsc0JBQXNCLE1BQU0sR0FBRyxJQUFJO0NBQ3RHLElBQUk7RUFDRixLQUFLLGFBQWEsR0FBRyxhQUFhLE1BQU0sUUFBUSxjQUFjO0dBQzVELE1BQU0sTUFBTSxNQUFNO0dBQ2xCLElBQUksT0FBTyxFQUFFLElBQUksUUFBUSxJQUFJO0lBQzNCLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLE1BQU0sR0FBRyxHQUFHO0tBQzNEO0lBQ0Y7SUFDQSxJQUFJLElBQUksUUFBUSxHQUFHO0tBQ2pCLElBQUksU0FBUyxDQUFDO0lBQ2hCO0lBQ0Esc0JBQ0UsS0FDQSxJQUFJLEdBQ0osSUFBSSxJQUFJLEtBQUssRUFDZjtJQUNBLElBQUksRUFBRSxJQUFJLFFBQVEsSUFBSTtLQUNwQixJQUFJLFNBQVMsQ0FBQztJQUNoQjtHQUNGO0VBQ0Y7Q0FDRixVQUFVO0VBQ1IsT0FBTyxhQUFhLE1BQU0sUUFBUSxjQUFjO0dBQzlDLE1BQU0sTUFBTSxNQUFNO0dBQ2xCLElBQUksS0FBSztJQUNQLElBQUksU0FBUyxDQUFDO0dBQ2hCO0VBQ0Y7RUFDQSxhQUFhLENBQUM7RUFDZCxNQUFNLFNBQVM7RUFDZixrQkFBa0IsSUFBSTtFQUN0QixzQkFBc0I7RUFDdEIsSUFBSSxNQUFNLFVBQVUsb0JBQW9CLFFBQVE7R0FDOUMsVUFBVSxJQUFJO0VBQ2hCO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsc0JBQXNCLE1BQU0sSUFBSTtDQUN2QyxNQUFNLFFBQVEsS0FBSyxJQUFJLEVBQUUsS0FBSztDQUM5QixJQUFJLFFBQVEsaUJBQWlCO0VBQzNCLE1BQU0sV0FBVyxHQUFHO0VBQ3BCLE1BQU0sZ0JBQWdCLFlBQVksaUJBQWlCLFNBQVMsSUFBSTtFQUNoRSxZQUNFLHFDQUFxQyxnQkFBZ0Isa0JBQWtCLGNBQWMsS0FBSyxHQUFHLCtOQUM3RixNQUNBLEVBQ0Y7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxLQUFLLElBQUksSUFBSSxRQUFRLENBQUM7Q0FDdEIsT0FBTztBQUNUO0FBRUEsSUFBSSxnQkFBZ0I7QUFDcEIsTUFBTSxrQkFBa0IsTUFBTTtDQUM1QixJQUFJO0VBQ0YsT0FBTztDQUNULFVBQVU7RUFDUixnQkFBZ0I7Q0FDbEI7QUFDRjtBQUNBLE1BQU0scUNBQXFDLElBQUksSUFBSTtBQUNuRCxJQUFJLENBQUMsb0JBQTJCLGVBQWU7Q0FDN0MsY0FBYyxDQUFDLENBQUMsc0JBQXNCO0VBQ3BDLGNBQWMsUUFBUSxZQUFZO0VBQ2xDLFVBQVUsUUFBUSxRQUFRO0VBQzFCLFFBQVEsUUFBUSxNQUFNO0NBQ3hCO0FBQ0Y7QUFDQSxNQUFNLHNCQUFzQixJQUFJLElBQUk7QUFDcEMsU0FBUyxZQUFZLFVBQVU7Q0FDN0IsTUFBTSxLQUFLLFNBQVMsS0FBSztDQUN6QixJQUFJLFNBQVMsSUFBSSxJQUFJLEVBQUU7Q0FDdkIsSUFBSSxDQUFDLFFBQVE7RUFDWCxhQUFhLElBQUksU0FBUyxJQUFJO0VBQzlCLFNBQVMsSUFBSSxJQUFJLEVBQUU7Q0FDckI7Q0FDQSxPQUFPLFVBQVUsSUFBSSxRQUFRO0FBQy9CO0FBQ0EsU0FBUyxjQUFjLFVBQVU7Q0FDL0IsSUFBSSxJQUFJLFNBQVMsS0FBSyxPQUFPLENBQUMsQ0FBQyxVQUFVLE9BQU8sUUFBUTtBQUMxRDtBQUNBLFNBQVMsYUFBYSxJQUFJLFlBQVk7Q0FDcEMsSUFBSSxJQUFJLElBQUksRUFBRSxHQUFHO0VBQ2YsT0FBTztDQUNUO0NBQ0EsSUFBSSxJQUFJLElBQUk7RUFDVixZQUFZLHdCQUF3QixVQUFVO0VBQzlDLDJCQUEyQixJQUFJLElBQUk7Q0FDckMsQ0FBQztDQUNELE9BQU87QUFDVDtBQUNBLFNBQVMsd0JBQXdCLFdBQVc7Q0FDMUMsT0FBTyxpQkFBaUIsU0FBUyxJQUFJLFVBQVUsWUFBWTtBQUM3RDtBQUNBLFNBQVMsU0FBUyxJQUFJLFdBQVc7Q0FDL0IsTUFBTSxTQUFTLElBQUksSUFBSSxFQUFFO0NBQ3pCLElBQUksQ0FBQyxRQUFRO0VBQ1g7Q0FDRjtDQUNBLE9BQU8sV0FBVyxTQUFTO0NBQzNCLENBQUMsR0FBRyxPQUFPLFNBQVMsQ0FBQyxDQUFDLFNBQVMsYUFBYTtFQUMxQyxJQUFJLFdBQVc7R0FDYixTQUFTLFNBQVM7R0FDbEIsd0JBQXdCLFNBQVMsSUFBSSxDQUFDLENBQUMsU0FBUztFQUNsRDtFQUNBLFNBQVMsY0FBYyxDQUFDO0VBQ3hCLGdCQUFnQjtFQUNoQixJQUFJLEVBQUUsU0FBUyxJQUFJLFFBQVEsSUFBSTtHQUM3QixTQUFTLE9BQU87RUFDbEI7RUFDQSxnQkFBZ0I7Q0FDbEIsQ0FBQztBQUNIO0FBQ0EsU0FBUyxPQUFPLElBQUksU0FBUztDQUMzQixNQUFNLFNBQVMsSUFBSSxJQUFJLEVBQUU7Q0FDekIsSUFBSSxDQUFDLFFBQVE7Q0FDYixVQUFVLHdCQUF3QixPQUFPO0NBQ3pDLG1CQUFtQixPQUFPLFlBQVksT0FBTztDQUM3QyxNQUFNLFlBQVksQ0FBQyxHQUFHLE9BQU8sU0FBUztDQUN0QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxRQUFRLEtBQUs7RUFDekMsTUFBTSxXQUFXLFVBQVU7RUFDM0IsTUFBTSxVQUFVLHdCQUF3QixTQUFTLElBQUk7RUFDckQsSUFBSSxpQkFBaUIsbUJBQW1CLElBQUksT0FBTztFQUNuRCxJQUFJLENBQUMsZ0JBQWdCO0dBQ25CLElBQUksWUFBWSxPQUFPLFlBQVk7SUFDakMsbUJBQW1CLFNBQVMsT0FBTztHQUNyQztHQUNBLG1CQUFtQixJQUFJLFNBQVMsaUNBQWlDLElBQUksSUFBSSxDQUFDO0VBQzVFO0VBQ0EsZUFBZSxJQUFJLFFBQVE7RUFDM0IsU0FBUyxXQUFXLFdBQVcsT0FBTyxTQUFTLElBQUk7RUFDbkQsU0FBUyxXQUFXLFdBQVcsT0FBTyxTQUFTLElBQUk7RUFDbkQsU0FBUyxXQUFXLGFBQWEsT0FBTyxTQUFTLElBQUk7RUFDckQsSUFBSSxTQUFTLFVBQVU7R0FDckIsZUFBZSxJQUFJLFFBQVE7R0FDM0IsU0FBUyxTQUFTLFFBQVEsTUFBTTtHQUNoQyxlQUFlLE9BQU8sUUFBUTtFQUNoQyxPQUFPLElBQUksU0FBUyxRQUFRO0dBQzFCLGVBQWU7SUFDYixJQUFJLEVBQUUsU0FBUyxJQUFJLFFBQVEsSUFBSTtLQUM3QixnQkFBZ0I7S0FDaEIsU0FBUyxPQUFPLE9BQU87S0FDdkIsZ0JBQWdCO0tBQ2hCLGVBQWUsT0FBTyxRQUFRO0lBQ2hDO0dBQ0YsQ0FBQztFQUNILE9BQU8sSUFBSSxTQUFTLFdBQVcsUUFBUTtHQUNyQyxTQUFTLFdBQVcsT0FBTztFQUM3QixPQUFPLElBQUksT0FBTyxXQUFXLGFBQWE7R0FDeEMsT0FBTyxTQUFTLE9BQU87RUFDekIsT0FBTztHQUNMLFFBQVEsS0FDTix5RUFDRjtFQUNGO0VBQ0EsSUFBSSxTQUFTLEtBQUssTUFBTSxhQUFhLFNBQVMsTUFBTTtHQUNsRCxTQUFTLEtBQUssR0FBRyxrQkFBa0IsT0FBTztFQUM1QztDQUNGO0NBQ0EsdUJBQXVCO0VBQ3JCLG1CQUFtQixNQUFNO0NBQzNCLENBQUM7QUFDSDtBQUNBLFNBQVMsbUJBQW1CLFNBQVMsU0FBUztDQUM1QyxPQUFPLFNBQVMsT0FBTztDQUN2QixLQUFLLE1BQU0sT0FBTyxTQUFTO0VBQ3pCLElBQUksUUFBUSxZQUFZLEVBQUUsT0FBTyxVQUFVO0dBQ3pDLE9BQU8sUUFBUTtFQUNqQjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLFFBQVEsSUFBSTtDQUNuQixRQUFRLElBQUksUUFBUTtFQUNsQixJQUFJO0dBQ0YsT0FBTyxHQUFHLElBQUksR0FBRztFQUNuQixTQUFTLEdBQUc7R0FDVixRQUFRLE1BQU0sQ0FBQztHQUNmLFFBQVEsS0FDTixtRkFDRjtFQUNGO0NBQ0Y7QUFDRjtBQUVBLElBQUk7QUFDSixJQUFJLFNBQVMsQ0FBQztBQUNkLElBQUksdUJBQXVCO0FBQzNCLFNBQVMsT0FBTyxPQUFPLEdBQUcsTUFBTTtDQUM5QixJQUFJLFlBQVk7RUFDZCxXQUFXLEtBQUssT0FBTyxHQUFHLElBQUk7Q0FDaEMsT0FBTyxJQUFJLENBQUMsc0JBQXNCO0VBQ2hDLE9BQU8sS0FBSztHQUFFO0dBQU87RUFBSyxDQUFDO0NBQzdCO0FBQ0Y7QUFDQSxTQUFTLGtCQUFrQixNQUFNLFFBQVE7Q0FDdkMsSUFBSSxJQUFJO0NBQ1IsYUFBYTtDQUNiLElBQUksWUFBWTtFQUNkLFdBQVcsVUFBVTtFQUNyQixPQUFPLFNBQVMsRUFBRSxPQUFPLFdBQVcsV0FBVyxLQUFLLE9BQU8sR0FBRyxJQUFJLENBQUM7RUFDbkUsU0FBUyxDQUFDO0NBQ1osT0FBTyxJQUlMLE9BQU8sV0FBVyxlQUNsQixPQUFPLGVBRVAsR0FBRyxNQUFNLEtBQUssT0FBTyxjQUFjLE9BQU8sS0FBSyxJQUFJLEdBQUcsY0FBYyxPQUFPLEtBQUssSUFBSSxHQUFHLFNBQVMsT0FBTyxJQUN2RztFQUNBLE1BQU0sU0FBUyxPQUFPLCtCQUErQixPQUFPLGdDQUFnQyxDQUFDO0VBQzdGLE9BQU8sTUFBTSxZQUFZO0dBQ3ZCLGtCQUFrQixTQUFTLE1BQU07RUFDbkMsQ0FBQztFQUNELGlCQUFpQjtHQUNmLElBQUksQ0FBQyxZQUFZO0lBQ2YsT0FBTywrQkFBK0I7SUFDdEMsdUJBQXVCO0lBQ3ZCLFNBQVMsQ0FBQztHQUNaO0VBQ0YsR0FBRyxHQUFHO0NBQ1IsT0FBTztFQUNMLHVCQUF1QjtFQUN2QixTQUFTLENBQUM7Q0FDWjtBQUNGO0FBQ0EsU0FBUyxnQkFBZ0IsS0FBSyxTQUFTO0NBQ3JDLE9BQU8sWUFBMkIsS0FBSyxTQUFTO0VBQzlDO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsQ0FBQztBQUNIO0FBQ0EsU0FBUyxtQkFBbUIsS0FBSztDQUMvQixPQUFPLGVBQWlDLEdBQUc7QUFDN0M7QUFDQSxNQUFNLHlCQUF5QztDQUE0Qjs7QUFBdUM7QUFDbEgsTUFBTSwyQkFBMkM7Q0FBNEI7O0FBQTJDO0FBQ3hILE1BQU0sNEJBQTRDLDRDQUNoRCxtQkFDRjtBQUNBLE1BQU0sNEJBQTRCLGNBQWM7Q0FDOUMsSUFBSSxjQUFjLE9BQU8sV0FBVyxrQkFBa0IsY0FDdEQsQ0FBQyxXQUFXLGNBQWMsU0FBUyxHQUFHO0VBQ3BDLDBCQUEwQixTQUFTO0NBQ3JDO0FBQ0Y7O0FBRUEsU0FBUyw0QkFBNEIsTUFBTTtDQUN6QyxRQUFRLGNBQWM7RUFDcEIsT0FDRSxNQUNBLFVBQVUsV0FBVyxLQUNyQixVQUFVLEtBQ1YsVUFBVSxTQUFTLFVBQVUsT0FBTyxNQUFNLEtBQUssR0FDL0MsU0FDRjtDQUNGO0FBQ0Y7QUFDQSxNQUFNLG9CQUFvQztDQUE4Qjs7QUFBb0M7QUFDNUcsTUFBTSxrQkFBa0M7Q0FBOEI7O0FBQWdDO0FBQ3RHLFNBQVMsOEJBQThCLE1BQU07Q0FDM0MsUUFBUSxXQUFXLE1BQU0sU0FBUztFQUNoQyxPQUFPLE1BQU0sVUFBVSxXQUFXLEtBQUssVUFBVSxLQUFLLFdBQVcsTUFBTSxJQUFJO0NBQzdFO0FBQ0Y7QUFDQSxTQUFTLHNCQUFzQixXQUFXLE9BQU8sUUFBUTtDQUN2RCxPQUNFLGtCQUNBLFVBQVUsV0FBVyxLQUNyQixXQUNBLE9BQ0EsTUFDRjtBQUNGO0FBRUEsSUFBSSwyQkFBMkI7QUFDL0IsSUFBSSxpQkFBaUI7QUFDckIsU0FBUyw0QkFBNEIsVUFBVTtDQUM3QyxNQUFNLE9BQU87Q0FDYiwyQkFBMkI7Q0FDM0IsaUJBQWlCLFlBQVksU0FBUyxLQUFLLGFBQWE7Q0FDeEQsT0FBTztBQUNUO0FBQ0EsU0FBUyxZQUFZLElBQUk7Q0FDdkIsaUJBQWlCO0FBQ25CO0FBQ0EsU0FBUyxhQUFhO0NBQ3BCLGlCQUFpQjtBQUNuQjtBQUNBLE1BQU0sZUFBZSxRQUFRO0FBQzdCLFNBQVMsUUFBUSxJQUFJLE1BQU0sMEJBQTBCLGlCQUFpQjtDQUNwRSxJQUFJLENBQUMsS0FBSyxPQUFPO0NBQ2pCLElBQUksR0FBRyxJQUFJO0VBQ1QsT0FBTztDQUNUO0NBQ0EsTUFBTSx1QkFBdUIsR0FBRyxTQUFTO0VBQ3ZDLElBQUksb0JBQW9CLElBQUk7R0FDMUIsaUJBQWlCLENBQUMsQ0FBQztFQUNyQjtFQUNBLE1BQU0sZUFBZSw0QkFBNEIsR0FBRztFQUNwRCxNQUFNLGdCQUFnQixXQUFXO0VBQ2pDLElBQUk7RUFDSixJQUFJO0dBQ0YsTUFBTSxHQUFHLEdBQUcsSUFBSTtFQUNsQixVQUFVO0dBQ1IsS0FBSyxJQUFJLElBQUksV0FBVyxRQUFRLElBQUksZUFBZSxLQUFLLFdBQVc7R0FDbkUsNEJBQTRCLFlBQVk7R0FDeEMsSUFBSSxvQkFBb0IsSUFBSTtJQUMxQixpQkFBaUIsQ0FBQztHQUNwQjtFQUNGO0VBQ0EsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsdUJBQXVCO0dBQ3RFLHlCQUF5QixHQUFHO0VBQzlCO0VBQ0EsT0FBTztDQUNUO0NBQ0Esb0JBQW9CLEtBQUs7Q0FDekIsb0JBQW9CLEtBQUs7Q0FDekIsb0JBQW9CLEtBQUs7Q0FDekIsT0FBTztBQUNUO0FBRUEsU0FBUyxzQkFBc0IsTUFBTTtDQUNuQyxJQUFJLG1CQUFtQixJQUFJLEdBQUc7RUFDNUIsT0FBTywrREFBK0QsSUFBSTtDQUM1RTtBQUNGO0FBQ0EsU0FBUyxlQUFlLE9BQU8sWUFBWTtDQUN6QyxJQUFJLDZCQUE2QixNQUFNO0VBQ3JDLENBQUMsb0JBQTJCLGlCQUFpQixPQUFPLDBEQUEwRDtFQUM5RyxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLFdBQVcsMkJBQTJCLHdCQUF3QjtDQUNwRSxNQUFNLFdBQVcsTUFBTSxTQUFTLE1BQU0sT0FBTyxDQUFDO0NBQzlDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxXQUFXLFFBQVEsS0FBSztFQUMxQyxJQUFJLENBQUMsS0FBSyxPQUFPLEtBQUssWUFBWSxhQUFhLFdBQVc7RUFDMUQsSUFBSSxLQUFLO0dBQ1AsSUFBSSxXQUFXLEdBQUcsR0FBRztJQUNuQixNQUFNO0tBQ0osU0FBUztLQUNULFNBQVM7SUFDWDtHQUNGO0dBQ0EsSUFBSSxJQUFJLE1BQU07SUFDWixTQUFTLEtBQUs7R0FDaEI7R0FDQSxTQUFTLEtBQUs7SUFDWjtJQUNBO0lBQ0E7SUFDQSxVQUFVLEtBQUs7SUFDZjtJQUNBO0dBQ0YsQ0FBQztFQUNIO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLG9CQUFvQixPQUFPLFdBQVcsVUFBVSxNQUFNO0NBQzdELE1BQU0sV0FBVyxNQUFNO0NBQ3ZCLE1BQU0sY0FBYyxhQUFhLFVBQVU7Q0FDM0MsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0VBQ3hDLE1BQU0sVUFBVSxTQUFTO0VBQ3pCLElBQUksYUFBYTtHQUNmLFFBQVEsV0FBVyxZQUFZLEVBQUUsQ0FBQztFQUNwQztFQUNBLElBQUksT0FBTyxRQUFRLElBQUk7RUFDdkIsSUFBSSxNQUFNO0dBQ1IsY0FBYztHQUNkLDJCQUEyQixNQUFNLFVBQVUsR0FBRztJQUM1QyxNQUFNO0lBQ047SUFDQTtJQUNBO0dBQ0YsQ0FBQztHQUNELGNBQWM7RUFDaEI7Q0FDRjtBQUNGO0FBRUEsU0FBUyxRQUFRLEtBQUssT0FBTztDQUMzQixJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDN0MsSUFBSSxDQUFDLG1CQUFtQixnQkFBZ0IsV0FBVztHQUNqRCxPQUFPLDRDQUE0QztFQUNyRDtDQUNGO0NBQ0EsSUFBSSxpQkFBaUI7RUFDbkIsSUFBSSxXQUFXLGdCQUFnQjtFQUMvQixNQUFNLGlCQUFpQixnQkFBZ0IsVUFBVSxnQkFBZ0IsT0FBTztFQUN4RSxJQUFJLG1CQUFtQixVQUFVO0dBQy9CLFdBQVcsZ0JBQWdCLFdBQVcsT0FBTyxPQUFPLGNBQWM7RUFDcEU7RUFDQSxTQUFTLE9BQU87Q0FDbEI7QUFDRjtBQUNBLFNBQVMsT0FBTyxLQUFLLGNBQWMsd0JBQXdCLE9BQU87Q0FDaEUsTUFBTSxXQUFXLG1CQUFtQjtDQUNwQyxJQUFJLFlBQVksWUFBWTtFQUMxQixJQUFJLFdBQVcsYUFBYSxXQUFXLFNBQVMsV0FBVyxXQUFXLFNBQVMsVUFBVSxRQUFRLFNBQVMsS0FBSyxTQUFTLE1BQU0sY0FBYyxTQUFTLE1BQU0sV0FBVyxXQUFXLFNBQVMsT0FBTyxXQUFXLEtBQUs7RUFDak4sSUFBSSxZQUFZLE9BQU8sVUFBVTtHQUMvQixPQUFPLFNBQVM7RUFDbEIsT0FBTyxJQUFJLFVBQVUsU0FBUyxHQUFHO0dBQy9CLE9BQU8seUJBQXlCLFdBQVcsWUFBWSxJQUFJLGFBQWEsS0FBSyxZQUFZLFNBQVMsS0FBSyxJQUFJO0VBQzdHLE9BQU8sSUFBSSxDQUFDLG9CQUEyQixlQUFlO0dBQ3BELE9BQU8sY0FBYyxPQUFPLEdBQUcsRUFBRSxhQUFhO0VBQ2hEO0NBQ0YsT0FBTyxJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDcEQsT0FBTyxvRUFBb0U7Q0FDN0U7QUFDRjtBQUNBLFNBQVMsc0JBQXNCO0NBQzdCLE9BQU8sQ0FBQyxFQUFFLG1CQUFtQixLQUFLO0FBQ3BDO0FBRUEsTUFBTSxnQkFBZ0MsdUJBQU8sSUFBSSxPQUFPO0FBQ3hELE1BQU0sc0JBQXNCO0NBQzFCO0VBQ0UsTUFBTSxNQUFNLE9BQU8sYUFBYTtFQUNoQyxJQUFJLENBQUMsS0FBSztHQUNSLENBQUMsb0JBQTJCLGlCQUFpQixPQUMzQyxrSEFDRjtFQUNGO0VBQ0EsT0FBTztDQUNUO0FBQ0Y7QUFFQSxTQUFTLFlBQVksUUFBUSxTQUFTO0NBQ3BDLE9BQU8sUUFBUSxRQUFRLE1BQU0sT0FBTztBQUN0QztBQUNBLFNBQVMsZ0JBQWdCLFFBQVEsU0FBUztDQUN4QyxPQUFPLFFBQ0wsUUFDQSxNQUNBLENBQUMsb0JBQTJCLGdCQUFnQixPQUFPLENBQUMsR0FBRyxTQUFTLEVBQUUsT0FBTyxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sT0FBTyxDQUN2RztBQUNGO0FBQ0EsU0FBUyxnQkFBZ0IsUUFBUSxTQUFTO0NBQ3hDLE9BQU8sUUFDTCxRQUNBLE1BQ0EsQ0FBQyxvQkFBMkIsZ0JBQWdCLE9BQU8sQ0FBQyxHQUFHLFNBQVMsRUFBRSxPQUFPLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxPQUFPLENBQ3ZHO0FBQ0Y7QUFDQSxTQUFTLE1BQU0sUUFBUSxJQUFJLFNBQVM7Q0FDbEMsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsQ0FBQyxXQUFXLEVBQUUsR0FBRztFQUNoRSxPQUNFLHFMQUNGO0NBQ0Y7Q0FDQSxPQUFPLFFBQVEsUUFBUSxJQUFJLE9BQU87QUFDcEM7QUFDQSxTQUFTLFFBQVEsUUFBUSxJQUFJLFVBQVUsV0FBVztDQUNoRCxNQUFNLEVBQUUsV0FBVyxNQUFNLE9BQU8sU0FBUztDQUN6QyxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixDQUFDLElBQUk7RUFDcEQsSUFBSSxjQUFjLEtBQUssR0FBRztHQUN4QixPQUNFLDBHQUNGO0VBQ0Y7RUFDQSxJQUFJLFNBQVMsS0FBSyxHQUFHO0dBQ25CLE9BQ0UscUdBQ0Y7RUFDRjtFQUNBLElBQUksU0FBUyxLQUFLLEdBQUc7R0FDbkIsT0FDRSxxR0FDRjtFQUNGO0NBQ0Y7Q0FDQSxNQUFNLG1CQUFtQixPQUFPLENBQUMsR0FBRyxPQUFPO0NBQzNDLElBQUksQ0FBQyxvQkFBMkIsZUFBZSxpQkFBaUIsU0FBUztDQUN6RSxNQUFNLGtCQUFrQixNQUFNLGFBQWEsQ0FBQyxNQUFNLFVBQVU7Q0FDNUQsSUFBSTtDQUNKLElBQUksdUJBQXVCO0VBQ3pCLElBQUksVUFBVSxRQUFRO0dBQ3BCLE1BQU0sTUFBTSxjQUFjO0dBQzFCLGFBQWEsSUFBSSxxQkFBcUIsSUFBSSxtQkFBbUIsQ0FBQztFQUNoRSxPQUFPLElBQUksQ0FBQyxpQkFBaUI7R0FDM0IsTUFBTSx3QkFBd0IsQ0FDOUI7R0FDQSxnQkFBZ0IsT0FBTztHQUN2QixnQkFBZ0IsU0FBUztHQUN6QixnQkFBZ0IsUUFBUTtHQUN4QixPQUFPO0VBQ1Q7Q0FDRjtDQUNBLE1BQU0sV0FBVztDQUNqQixpQkFBaUIsUUFBUSxJQUFJLE1BQU0sU0FBUywyQkFBMkIsSUFBSSxVQUFVLE1BQU0sSUFBSTtDQUMvRixJQUFJLFFBQVE7Q0FDWixJQUFJLFVBQVUsUUFBUTtFQUNwQixpQkFBaUIsYUFBYSxRQUFRO0dBQ3BDLHNCQUFzQixLQUFLLFlBQVksU0FBUyxRQUFRO0VBQzFEO0NBQ0YsT0FBTyxJQUFJLFVBQVUsUUFBUTtFQUMzQixRQUFRO0VBQ1IsaUJBQWlCLGFBQWEsS0FBSyxlQUFlO0dBQ2hELElBQUksWUFBWTtJQUNkLElBQUk7R0FDTixPQUFPO0lBQ0wsU0FBUyxHQUFHO0dBQ2Q7RUFDRjtDQUNGO0NBQ0EsaUJBQWlCLGNBQWMsUUFBUTtFQUNyQyxJQUFJLElBQUk7R0FDTixJQUFJLFNBQVM7RUFDZjtFQUNBLElBQUksT0FBTztHQUNULElBQUksU0FBUztHQUNiLElBQUksVUFBVTtJQUNaLElBQUksS0FBSyxTQUFTO0lBQ2xCLElBQUksSUFBSTtHQUNWO0VBQ0Y7Q0FDRjtDQUNBLE1BQU0sY0FBYyxRQUFRLFFBQVEsSUFBSSxnQkFBZ0I7Q0FDeEQsSUFBSSx1QkFBdUI7RUFDekIsSUFBSSxZQUFZO0dBQ2QsV0FBVyxLQUFLLFdBQVc7RUFDN0IsT0FBTyxJQUFJLGlCQUFpQjtHQUMxQixZQUFZO0VBQ2Q7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsY0FBYyxRQUFRLE9BQU8sU0FBUztDQUM3QyxNQUFNLGFBQWEsS0FBSztDQUN4QixNQUFNLFNBQVMsU0FBUyxNQUFNLElBQUksT0FBTyxTQUFTLEdBQUcsSUFBSSxpQkFBaUIsWUFBWSxNQUFNLFVBQVUsV0FBVyxVQUFVLE9BQU8sS0FBSyxZQUFZLFVBQVU7Q0FDN0osSUFBSTtDQUNKLElBQUksV0FBVyxLQUFLLEdBQUc7RUFDckIsS0FBSztDQUNQLE9BQU87RUFDTCxLQUFLLE1BQU07RUFDWCxVQUFVO0NBQ1o7Q0FDQSxNQUFNLFFBQVEsbUJBQW1CLElBQUk7Q0FDckMsTUFBTSxNQUFNLFFBQVEsUUFBUSxHQUFHLEtBQUssVUFBVSxHQUFHLE9BQU87Q0FDeEQsTUFBTTtDQUNOLE9BQU87QUFDVDtBQUNBLFNBQVMsaUJBQWlCLEtBQUssTUFBTTtDQUNuQyxNQUFNLFdBQVcsS0FBSyxNQUFNLEdBQUc7Q0FDL0IsYUFBYTtFQUNYLElBQUksTUFBTTtFQUNWLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFVBQVUsS0FBSyxLQUFLO0dBQy9DLE1BQU0sSUFBSSxTQUFTO0VBQ3JCO0VBQ0EsT0FBTztDQUNUO0FBQ0Y7QUFFQSxNQUFNLGdDQUFnQyxJQUFJLFFBQVE7QUFDbEQsTUFBTSxpQkFBaUMsdUJBQU8sTUFBTTtBQUNwRCxNQUFNLGNBQWMsU0FBUyxLQUFLO0FBQ2xDLE1BQU0sc0JBQXNCLFVBQVUsVUFBVSxNQUFNLFlBQVksTUFBTSxhQUFhO0FBQ3JGLE1BQU0sc0JBQXNCLFVBQVUsVUFBVSxNQUFNLFNBQVMsTUFBTSxVQUFVO0FBQy9FLE1BQU0sZUFBZSxXQUFXLE9BQU8sZUFBZSxlQUFlLGtCQUFrQjtBQUN2RixNQUFNLGtCQUFrQixXQUFXLE9BQU8sa0JBQWtCLGNBQWMsa0JBQWtCO0FBQzVGLE1BQU0saUJBQWlCLE9BQU8sV0FBVztDQUN2QyxNQUFNLGlCQUFpQixTQUFTLE1BQU07Q0FDdEMsSUFBSSxTQUFTLGNBQWMsR0FBRztFQUM1QixJQUFJLENBQUMsUUFBUTtHQUNYLENBQUMsb0JBQTJCLGlCQUFpQixPQUMzQyx3R0FDRjtHQUNBLE9BQU87RUFDVCxPQUFPO0dBQ0wsTUFBTSxTQUFTLE9BQU8sY0FBYztHQUNwQyxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxtQkFBbUIsS0FBSyxHQUFHO0lBQ3RGLE9BQ0UsbURBQW1ELGVBQWUsb01BQ3BFO0dBQ0Y7R0FDQSxPQUFPO0VBQ1Q7Q0FDRixPQUFPO0VBQ0wsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQyxtQkFBbUIsS0FBSyxHQUFHO0dBQzlGLE9BQU8sNEJBQTRCLGdCQUFnQjtFQUNyRDtFQUNBLE9BQU87Q0FDVDtBQUNGO0FBQ0EsTUFBTSxlQUFlO0NBQ25CLE1BQU07Q0FDTixjQUFjO0NBQ2QsUUFBUSxJQUFJLElBQUksV0FBVyxRQUFRLGlCQUFpQixnQkFBZ0IsV0FBVyxjQUFjLFdBQVcsV0FBVztFQUNqSCxNQUFNLEVBQ0osSUFBSSxlQUNKLElBQUksZUFDSixLQUFLLG9CQUNMLEdBQUcsRUFBRSxRQUFRLGVBQWUsWUFBWSxlQUFlLGlCQUNyRDtFQUNKLE1BQU0sV0FBVyxtQkFBbUIsR0FBRyxLQUFLO0VBQzVDLElBQUksRUFBRSxvQkFBb0I7RUFDMUIsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsZUFBZTtHQUM5RCxZQUFZO0dBQ1osa0JBQWtCO0VBQ3BCO0VBQ0EsTUFBTSxTQUFTLE9BQU8sWUFBWSxZQUFZO0dBQzVDLElBQUksTUFBTSxZQUFZLElBQUk7SUFDeEIsY0FDRSxNQUFNLFVBQ04sWUFDQSxTQUNBLGlCQUNBLGdCQUNBLFdBQ0EsY0FDQSxTQUNGO0dBQ0Y7RUFDRjtFQUNBLE1BQU0saUJBQWlCLFFBQVEsT0FBTztHQUNwQyxNQUFNLFlBQVksbUJBQW1CLE1BQU0sS0FBSztHQUNoRCxNQUFNLFNBQVMsTUFBTSxTQUFTLGNBQWMsTUFBTSxPQUFPLGFBQWE7R0FDdEUsTUFBTSxlQUFlLGNBQWMsUUFBUSxPQUFPLFlBQVksTUFBTTtHQUNwRSxJQUFJLFFBQVE7SUFDVixJQUFJLGNBQWMsU0FBUyxZQUFZLE1BQU0sR0FBRztLQUM5QyxZQUFZO0lBQ2QsT0FBTyxJQUFJLGNBQWMsWUFBWSxlQUFlLE1BQU0sR0FBRztLQUMzRCxZQUFZO0lBQ2Q7SUFDQSxJQUFJLG1CQUFtQixnQkFBZ0IsTUFBTTtLQUMzQyxDQUFDLGdCQUFnQixHQUFHLHFCQUFxQixnQkFBZ0IsR0FBRyxtQ0FBbUMsSUFBSSxJQUFJLEdBQUUsQ0FBRSxJQUFJLE1BQU07SUFDdkg7SUFDQSxJQUFJLENBQUMsV0FBVztLQUNkLE1BQU0sT0FBTyxRQUFRLFlBQVk7S0FDakMsY0FBYyxPQUFPLEtBQUs7SUFDNUI7R0FDRixPQUFPLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLENBQUMsV0FBVztJQUNsRSxPQUFPLHFDQUFxQyxRQUFRLElBQUksT0FBTyxPQUFPLEVBQUU7R0FDMUU7RUFDRjtFQUNBLE1BQU0scUJBQXFCLFVBQVU7R0FDbkMsTUFBTSxpQkFBaUI7SUFDckIsSUFBSSxjQUFjLElBQUksS0FBSyxNQUFNLFVBQVU7SUFDM0MsY0FBYyxPQUFPLEtBQUs7SUFDMUIsSUFBSSxtQkFBbUIsTUFBTSxLQUFLLEdBQUc7S0FDbkMsTUFBTSxpQkFBaUIsV0FBVyxNQUFNLEVBQUUsS0FBSztLQUMvQyxNQUFNLE9BQU8sZ0JBQWdCLE1BQU0sTUFBTTtLQUN6QyxjQUFjLE9BQU8sSUFBSTtJQUMzQjtJQUNBLGNBQWMsS0FBSztHQUNyQjtHQUNBLGNBQWMsSUFBSSxPQUFPLFFBQVE7R0FDakMsc0JBQXNCLFVBQVUsY0FBYztFQUNoRDtFQUNBLElBQUksTUFBTSxNQUFNO0dBQ2QsTUFBTSxjQUFjLEdBQUcsS0FBSyxDQUFDLG9CQUEyQixnQkFBZ0IsY0FBYyxnQkFBZ0IsSUFBSSxXQUFXLEVBQUU7R0FDdkgsTUFBTSxhQUFhLEdBQUcsU0FBUyxDQUFDLG9CQUEyQixnQkFBZ0IsY0FBYyxjQUFjLElBQUksV0FBVyxFQUFFO0dBQ3hILE9BQU8sYUFBYSxXQUFXLE1BQU07R0FDckMsT0FBTyxZQUFZLFdBQVcsTUFBTTtHQUNwQyxJQUFJLG1CQUFtQixHQUFHLEtBQUssS0FBSyxrQkFBa0IsZUFBZSxlQUFlO0lBQ2xGLGtCQUFrQixFQUFFO0lBQ3BCO0dBQ0Y7R0FDQSxJQUFJLFVBQVU7SUFDWixNQUFNLElBQUksV0FBVyxVQUFVO0lBQy9CLGNBQWMsSUFBSSxJQUFJO0dBQ3hCO0dBQ0EsY0FBYztFQUNoQixPQUFPO0dBQ0wsR0FBRyxLQUFLLEdBQUc7R0FDWCxNQUFNLGFBQWEsR0FBRyxTQUFTLEdBQUc7R0FDbEMsTUFBTSxlQUFlLGNBQWMsSUFBSSxFQUFFO0dBQ3pDLElBQUksY0FBYztJQUNoQixhQUFhLFNBQVM7SUFDdEIsY0FBYyxPQUFPLEVBQUU7SUFDdkIsa0JBQWtCLEVBQUU7SUFDcEI7R0FDRjtHQUNBLEdBQUcsY0FBYyxHQUFHO0dBQ3BCLE1BQU0sU0FBUyxHQUFHLFNBQVMsR0FBRztHQUM5QixNQUFNLGVBQWUsR0FBRyxlQUFlLEdBQUc7R0FDMUMsTUFBTSxjQUFjLG1CQUFtQixHQUFHLEtBQUs7R0FDL0MsTUFBTSxtQkFBbUIsY0FBYyxZQUFZO0dBQ25ELE1BQU0sZ0JBQWdCLGNBQWMsYUFBYTtHQUNqRCxJQUFJLGNBQWMsU0FBUyxZQUFZLE1BQU0sR0FBRztJQUM5QyxZQUFZO0dBQ2QsT0FBTyxJQUFJLGNBQWMsWUFBWSxlQUFlLE1BQU0sR0FBRztJQUMzRCxZQUFZO0dBQ2Q7R0FDQSxJQUFJLGlCQUFpQjtJQUNuQixtQkFDRSxHQUFHLGlCQUNILGlCQUNBLGtCQUNBLGlCQUNBLGdCQUNBLFdBQ0EsWUFDRjtJQUNBLHVCQUF1QixJQUFJLElBQUksQ0FBQyxDQUFDLG9CQUEyQixhQUFhO0dBQzNFLE9BQU8sSUFBSSxDQUFDLFdBQVc7SUFDckIsY0FDRSxJQUNBLElBQ0Esa0JBQ0EsZUFDQSxpQkFDQSxnQkFDQSxXQUNBLGNBQ0EsS0FDRjtHQUNGO0dBQ0EsSUFBSSxVQUFVO0lBQ1osSUFBSSxDQUFDLGFBQWE7S0FDaEIsYUFDRSxJQUNBLFdBQ0EsWUFDQSxXQUNBLENBQ0Y7SUFDRixPQUFPO0tBQ0wsSUFBSSxHQUFHLFNBQVMsR0FBRyxTQUFTLEdBQUcsTUFBTSxPQUFPLEdBQUcsTUFBTSxJQUFJO01BQ3ZELEdBQUcsTUFBTSxLQUFLLEdBQUcsTUFBTTtLQUN6QjtJQUNGO0dBQ0YsT0FBTztJQUNMLEtBQUssR0FBRyxTQUFTLEdBQUcsTUFBTSxTQUFTLEdBQUcsU0FBUyxHQUFHLE1BQU0sS0FBSztLQUMzRCxNQUFNLGFBQWEsY0FBYyxHQUFHLE9BQU8sYUFBYTtLQUN4RCxJQUFJLFlBQVk7TUFDZCxHQUFHLFNBQVM7TUFDWixhQUNFLElBQ0EsWUFDQSxNQUNBLFdBQ0EsQ0FDRjtLQUNGLE9BQU8sSUFBSSxDQUFDLG9CQUEyQixlQUFlO01BQ3BELE9BQ0Usc0NBQ0EsUUFDQSxJQUFJLE9BQU8sT0FBTyxFQUNwQjtLQUNGO0lBQ0YsT0FBTyxJQUFJLGFBQWE7S0FDdEIsYUFDRSxJQUNBLFFBQ0EsY0FDQSxXQUNBLENBQ0Y7SUFDRjtHQUNGO0dBQ0EsY0FBYyxJQUFJLFFBQVE7RUFDNUI7Q0FDRjtDQUNBLE9BQU8sT0FBTyxpQkFBaUIsZ0JBQWdCLEVBQUUsSUFBSSxTQUFTLEdBQUcsRUFBRSxRQUFRLGdCQUFnQixVQUFVO0VBQ25HLE1BQU0sRUFDSixXQUNBLFVBQ0EsUUFDQSxhQUNBLGNBQ0EsUUFDQSxVQUNFO0VBQ0osTUFBTSxXQUFXLG1CQUFtQixLQUFLO0VBQ3pDLE1BQU0sZUFBZSxZQUFZLENBQUM7RUFDbEMsTUFBTSxlQUFlLGNBQWMsSUFBSSxLQUFLO0VBQzVDLElBQUksY0FBYztHQUNoQixhQUFhLFNBQVM7R0FDdEIsY0FBYyxPQUFPLEtBQUs7RUFDNUI7RUFDQSxJQUFJLFFBQVE7R0FDVixXQUFXLFdBQVc7R0FDdEIsV0FBVyxZQUFZO0VBQ3pCO0VBQ0EsWUFBWSxXQUFXLE1BQU07RUFDN0IsSUFBSSxDQUFDLGlCQUFpQixZQUFZLFdBQVcsWUFBWSxJQUFJO0dBQzNELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztJQUN4QyxNQUFNLFFBQVEsU0FBUztJQUN2QixRQUNFLE9BQ0EsaUJBQ0EsZ0JBQ0EsY0FDQSxDQUFDLENBQUMsTUFBTSxlQUNWO0dBQ0Y7RUFDRjtDQUNGO0NBQ0EsTUFBTTtDQUNOLFNBQVM7QUFDWDtBQUNBLFNBQVMsYUFBYSxPQUFPLFdBQVcsY0FBYyxFQUFFLEdBQUcsRUFBRSxVQUFVLEdBQUcsUUFBUSxXQUFXLEdBQUc7Q0FDOUYsSUFBSSxhQUFhLEdBQUc7RUFDbEIsT0FBTyxNQUFNLGNBQWMsV0FBVyxZQUFZO0NBQ3BEO0NBQ0EsTUFBTSxFQUFFLElBQUksUUFBUSxXQUFXLFVBQVUsVUFBVTtDQUNuRCxNQUFNLFlBQVksYUFBYTtDQUMvQixJQUFJLFdBQVc7RUFDYixPQUFPLElBQUksV0FBVyxZQUFZO0NBQ3BDO0NBQ0EsSUFBSSxDQUFDLGNBQWMsSUFBSSxLQUFLLE1BQU0sQ0FBQyxhQUFhLG1CQUFtQixLQUFLLElBQUk7RUFDMUUsSUFBSSxZQUFZLElBQUk7R0FDbEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0lBQ3hDLEtBQ0UsU0FBUyxJQUNULFdBQ0EsY0FDQSxDQUNGO0dBQ0Y7RUFDRjtDQUNGO0NBQ0EsSUFBSSxXQUFXO0VBQ2IsT0FBTyxRQUFRLFdBQVcsWUFBWTtDQUN4QztBQUNGO0FBQ0EsU0FBUyxnQkFBZ0IsTUFBTSxPQUFPLGlCQUFpQixnQkFBZ0IsY0FBYyxXQUFXLEVBQzlGLEdBQUcsRUFBRSxhQUFhLFlBQVksZUFBZSxRQUFRLGdCQUNwRCxpQkFBaUI7Q0FDbEIsU0FBUyxjQUFjLFNBQVMsWUFBWTtFQUMxQyxJQUFJLGVBQWU7RUFDbkIsT0FBTyxjQUFjO0dBQ25CLElBQUksZ0JBQWdCLGFBQWEsYUFBYSxHQUFHO0lBQy9DLElBQUksYUFBYSxTQUFTLHlCQUF5QjtLQUNqRCxNQUFNLGNBQWM7SUFDdEIsT0FBTyxJQUFJLGFBQWEsU0FBUyxtQkFBbUI7S0FDbEQsTUFBTSxlQUFlO0tBQ3JCLFFBQVEsT0FBTyxNQUFNLGdCQUFnQixZQUFZLE1BQU0sWUFBWTtLQUNuRTtJQUNGO0dBQ0Y7R0FDQSxlQUFlLFlBQVksWUFBWTtFQUN6QztDQUNGO0NBQ0EsU0FBUyx3QkFBd0IsT0FBTyxRQUFRO0VBQzlDLE9BQU8sU0FBUyxnQkFDZCxZQUFZLEtBQUssR0FDakIsUUFDQSxXQUFXLEtBQUssR0FDaEIsaUJBQ0EsZ0JBQ0EsY0FDQSxTQUNGO0NBQ0Y7Q0FDQSxNQUFNLFNBQVMsTUFBTSxTQUFTLGNBQzVCLE1BQU0sT0FDTixhQUNGO0NBQ0EsTUFBTSxXQUFXLG1CQUFtQixNQUFNLEtBQUs7Q0FDL0MsSUFBSSxRQUFRO0VBQ1YsTUFBTSxhQUFhLE9BQU8sUUFBUSxPQUFPO0VBQ3pDLElBQUksTUFBTSxZQUFZLElBQUk7R0FDeEIsSUFBSSxVQUFVO0lBQ1osd0JBQXdCLE1BQU0sS0FBSztJQUNuQyxjQUFjLFFBQVEsVUFBVTtJQUNoQyxJQUFJLENBQUMsTUFBTSxjQUFjO0tBQ3ZCO01BQ0U7TUFDQTtNQUNBO01BQ0E7OztNQUdBLFdBQVcsSUFBSSxNQUFNLFNBQVMsT0FBTztLQUN2QztJQUNGO0dBQ0YsT0FBTztJQUNMLE1BQU0sU0FBUyxZQUFZLElBQUk7SUFDL0IsY0FBYyxRQUFRLFVBQVU7SUFDaEMsSUFBSSxDQUFDLE1BQU0sY0FBYztLQUN2QixjQUFjLFFBQVEsT0FBTyxZQUFZLE1BQU07SUFDakQ7SUFDQSxnQkFDRSxjQUFjLFlBQVksVUFBVSxHQUNwQyxPQUNBLFFBQ0EsaUJBQ0EsZ0JBQ0EsY0FDQSxTQUNGO0dBQ0Y7RUFDRjtFQUNBLGNBQWMsT0FBTyxRQUFRO0NBQy9CLE9BQU8sSUFBSSxVQUFVO0VBQ25CLElBQUksTUFBTSxZQUFZLElBQUk7R0FDeEIsd0JBQXdCLE1BQU0sS0FBSztHQUNuQyxNQUFNLGNBQWM7R0FDcEIsTUFBTSxlQUFlLFlBQVksSUFBSTtFQUN2QztDQUNGO0NBQ0EsT0FBTyxNQUFNLFVBQVUsWUFBWSxNQUFNLE1BQU07QUFDakQ7QUFDQSxNQUFNLFdBQVc7QUFDakIsU0FBUyxjQUFjLE9BQU8sWUFBWTtDQUN4QyxNQUFNLE1BQU0sTUFBTTtDQUNsQixJQUFJLE9BQU8sSUFBSSxJQUFJO0VBQ2pCLElBQUksTUFBTTtFQUNWLElBQUksWUFBWTtHQUNkLE9BQU8sTUFBTTtHQUNiLFNBQVMsTUFBTTtFQUNqQixPQUFPO0dBQ0wsT0FBTyxNQUFNO0dBQ2IsU0FBUyxNQUFNO0VBQ2pCO0VBQ0EsT0FBTyxRQUFRLFNBQVMsUUFBUTtHQUM5QixJQUFJLEtBQUssYUFBYSxHQUFHLEtBQUssYUFBYSxnQkFBZ0IsSUFBSSxHQUFHO0dBQ2xFLE9BQU8sS0FBSztFQUNkO0VBQ0EsSUFBSSxHQUFHO0NBQ1Q7QUFDRjtBQUNBLFNBQVMsY0FBYyxRQUFRLE9BQU8sWUFBWSxRQUFRLFNBQVMsTUFBTTtDQUN2RSxNQUFNLGNBQWMsTUFBTSxjQUFjLFdBQVcsRUFBRTtDQUNyRCxNQUFNLGVBQWUsTUFBTSxlQUFlLFdBQVcsRUFBRTtDQUN2RCxZQUFZLGtCQUFrQjtDQUM5QixJQUFJLFFBQVE7RUFDVixPQUFPLGFBQWEsUUFBUSxNQUFNO0VBQ2xDLE9BQU8sY0FBYyxRQUFRLE1BQU07Q0FDckM7Q0FDQSxPQUFPO0FBQ1Q7QUFFQSxNQUFNLGFBQTZCLHVCQUFPLFVBQVU7QUFDcEQsTUFBTSxhQUE2Qix1QkFBTyxVQUFVO0FBQ3BELFNBQVMscUJBQXFCO0NBQzVCLE1BQU0sUUFBUTtFQUNaLFdBQVc7RUFDWCxXQUFXO0VBQ1gsY0FBYztFQUNkLCtCQUErQixJQUFJLElBQUk7Q0FDekM7Q0FDQSxnQkFBZ0I7RUFDZCxNQUFNLFlBQVk7Q0FDcEIsQ0FBQztDQUNELHNCQUFzQjtFQUNwQixNQUFNLGVBQWU7Q0FDdkIsQ0FBQztDQUNELE9BQU87QUFDVDtBQUNBLE1BQU0sMEJBQTBCLENBQUMsVUFBVSxLQUFLO0FBQ2hELE1BQU0sZ0NBQWdDO0NBQ3BDLE1BQU07Q0FDTixRQUFRO0NBQ1IsV0FBVzs7Q0FFWCxlQUFlO0NBQ2YsU0FBUztDQUNULGNBQWM7Q0FDZCxrQkFBa0I7O0NBRWxCLGVBQWU7Q0FDZixTQUFTO0NBQ1QsY0FBYztDQUNkLGtCQUFrQjs7Q0FFbEIsZ0JBQWdCO0NBQ2hCLFVBQVU7Q0FDVixlQUFlO0NBQ2YsbUJBQW1CO0FBQ3JCO0FBQ0EsTUFBTSx1QkFBdUIsYUFBYTtDQUN4QyxNQUFNLFVBQVUsU0FBUztDQUN6QixPQUFPLFFBQVEsWUFBWSxvQkFBb0IsUUFBUSxTQUFTLElBQUk7QUFDdEU7QUFDQSxNQUFNLHFCQUFxQjtDQUN6QixNQUFNO0NBQ04sT0FBTztDQUNQLE1BQU0sT0FBTyxFQUFFLFNBQVM7RUFDdEIsTUFBTSxXQUFXLG1CQUFtQjtFQUNwQyxNQUFNLFFBQVEsbUJBQW1CO0VBQ2pDLGFBQWE7R0FDWCxNQUFNLFdBQVcsTUFBTSxXQUFXLHlCQUF5QixNQUFNLFFBQVEsR0FBRyxJQUFJO0dBQ2hGLE1BQU0sUUFBUSxZQUFZLFNBQVMsU0FBUyxvQkFBb0IsUUFBUTs7O0dBR3RFLFNBQVMsVUFBVSxtQkFBbUIsSUFBSSxLQUFLO0dBRWpELElBQUksQ0FBQyxPQUFPO0lBQ1Y7R0FDRjtHQUNBLE1BQU0sV0FBVyxNQUFNLEtBQUs7R0FDNUIsTUFBTSxFQUFFLFNBQVM7R0FDakIsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsUUFBUSxTQUFTLFlBQVksU0FBUyxZQUFZLFNBQVMsV0FBVztJQUNySCxPQUFPLDhCQUE4QixNQUFNO0dBQzdDO0dBQ0EsSUFBSSxNQUFNLFdBQVc7SUFDbkIsT0FBTyxpQkFBaUIsS0FBSztHQUMvQjtHQUNBLE1BQU0sYUFBYSxnQkFBZ0IsS0FBSztHQUN4QyxJQUFJLENBQUMsWUFBWTtJQUNmLE9BQU8saUJBQWlCLEtBQUs7R0FDL0I7R0FDQSxJQUFJLGFBQWE7SUFDZjtJQUNBO0lBQ0E7SUFDQTs7S0FFQyxVQUFVLGFBQWE7R0FDMUI7R0FDQSxJQUFJLFdBQVcsU0FBUyxTQUFTO0lBQy9CLG1CQUFtQixZQUFZLFVBQVU7R0FDM0M7R0FDQSxJQUFJLGdCQUFnQixTQUFTLFdBQVcsZ0JBQWdCLFNBQVMsT0FBTztHQUN4RSxJQUFJLGlCQUFpQixjQUFjLFNBQVMsV0FBVyxDQUFDLGdCQUFnQixlQUFlLFVBQVUsS0FBSyxvQkFBb0IsUUFBUSxDQUFDLENBQUMsU0FBUyxTQUFTO0lBQ3BKLElBQUksZUFBZSx1QkFDakIsZUFDQSxVQUNBLE9BQ0EsUUFDRjtJQUNBLG1CQUFtQixlQUFlLFlBQVk7SUFDOUMsSUFBSSxTQUFTLFlBQVksV0FBVyxTQUFTLFNBQVM7S0FDcEQsTUFBTSxZQUFZO0tBQ2xCLGFBQWEsbUJBQW1CO01BQzlCLE1BQU0sWUFBWTtNQUNsQixJQUFJLEVBQUUsU0FBUyxJQUFJLFFBQVEsSUFBSTtPQUM3QixTQUFTLE9BQU87TUFDbEI7TUFDQSxPQUFPLGFBQWE7TUFDcEIsZ0JBQWdCLEtBQUs7S0FDdkI7S0FDQSxPQUFPLGlCQUFpQixLQUFLO0lBQy9CLE9BQU8sSUFBSSxTQUFTLFlBQVksV0FBVyxTQUFTLFNBQVM7S0FDM0QsYUFBYSxjQUFjLElBQUksYUFBYSxpQkFBaUI7TUFDM0QsTUFBTSxxQkFBcUIsdUJBQ3pCLE9BQ0EsYUFDRjtNQUNBLG1CQUFtQixPQUFPLGNBQWMsR0FBRyxLQUFLO01BQ2hELEdBQUcsb0JBQW9CO09BQ3JCLFlBQVk7T0FDWixHQUFHLGNBQWMsS0FBSztPQUN0QixPQUFPLFdBQVc7T0FDbEIsZ0JBQWdCLEtBQUs7TUFDdkI7TUFDQSxXQUFXLHFCQUFxQjtPQUM5QixhQUFhO09BQ2IsT0FBTyxXQUFXO09BQ2xCLGdCQUFnQixLQUFLO01BQ3ZCO0tBQ0Y7SUFDRixPQUFPO0tBQ0wsZ0JBQWdCLEtBQUs7SUFDdkI7R0FDRixPQUFPLElBQUksZUFBZTtJQUN4QixnQkFBZ0IsS0FBSztHQUN2QjtHQUNBLE9BQU87RUFDVDtDQUNGO0FBQ0Y7QUFDQSxTQUFTLG9CQUFvQixVQUFVO0NBQ3JDLElBQUksUUFBUSxTQUFTO0NBQ3JCLElBQUksU0FBUyxTQUFTLEdBQUc7RUFDdkIsSUFBSSxXQUFXO0VBQ2YsS0FBSyxNQUFNLEtBQUssVUFBVTtHQUN4QixJQUFJLEVBQUUsU0FBUyxTQUFTO0lBQ3RCLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLFVBQVU7S0FDekQsT0FDRSxtR0FDRjtLQUNBO0lBQ0Y7SUFDQSxRQUFRO0lBQ1IsV0FBVztJQUNYLElBQUksQ0FBQyxDQUFDLG9CQUEyQixlQUFlO0dBQ2xEO0VBQ0Y7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBLE1BQU0saUJBQWlCO0FBQ3ZCLFNBQVMsdUJBQXVCLE9BQU8sT0FBTztDQUM1QyxNQUFNLEVBQUUsa0JBQWtCO0NBQzFCLElBQUkscUJBQXFCLGNBQWMsSUFBSSxNQUFNLElBQUk7Q0FDckQsSUFBSSxDQUFDLG9CQUFvQjtFQUN2QixxQkFBcUMsdUJBQU8sT0FBTyxJQUFJO0VBQ3ZELGNBQWMsSUFBSSxNQUFNLE1BQU0sa0JBQWtCO0NBQ2xEO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyx1QkFBdUIsT0FBTyxPQUFPLE9BQU8sVUFBVSxXQUFXO0NBQ3hFLE1BQU0sRUFDSixRQUNBLE1BQ0EsWUFBWSxPQUNaLGVBQ0EsU0FDQSxjQUNBLGtCQUNBLGVBQ0EsU0FDQSxjQUNBLGtCQUNBLGdCQUNBLFVBQ0EsZUFDQSxzQkFDRTtDQUNKLE1BQU0sTUFBTSxPQUFPLE1BQU0sR0FBRztDQUM1QixNQUFNLHFCQUFxQix1QkFBdUIsT0FBTyxLQUFLO0NBQzlELE1BQU0sWUFBWSxNQUFNLFNBQVM7RUFDL0IsUUFBUSwyQkFDTixNQUNBLFVBQ0EsR0FDQSxJQUNGO0NBQ0Y7Q0FDQSxNQUFNLGlCQUFpQixNQUFNLFNBQVM7RUFDcEMsTUFBTSxPQUFPLEtBQUs7RUFDbEIsU0FBUyxNQUFNLElBQUk7RUFDbkIsSUFBSSxRQUFRLElBQUksR0FBRztHQUNqQixJQUFJLEtBQUssT0FBTyxVQUFVLE1BQU0sVUFBVSxDQUFDLEdBQUcsS0FBSztFQUNyRCxPQUFPLElBQUksS0FBSyxVQUFVLEdBQUc7R0FDM0IsS0FBSztFQUNQO0NBQ0Y7Q0FDQSxNQUFNLFFBQVE7RUFDWjtFQUNBO0VBQ0EsWUFBWSxJQUFJO0dBQ2QsSUFBSSxPQUFPO0dBQ1gsSUFBSSxDQUFDLE1BQU0sV0FBVztJQUNwQixJQUFJLFFBQVE7S0FDVixPQUFPLGtCQUFrQjtJQUMzQixPQUFPO0tBQ0w7SUFDRjtHQUNGO0dBQ0EsSUFBSSxHQUFHLGFBQWE7SUFDbEIsR0FBRyxXQUFXO0tBQ1o7O0lBRUY7R0FDRjtHQUNBLE1BQU0sZUFBZSxtQkFBbUI7R0FDeEMsSUFBSSxnQkFBZ0IsZ0JBQWdCLE9BQU8sWUFBWSxLQUFLLGFBQWEsR0FBRyxhQUFhO0lBQ3ZGLGFBQWEsR0FBRyxXQUFXLENBQUM7R0FDOUI7R0FDQSxTQUFTLE1BQU0sQ0FBQyxFQUFFLENBQUM7RUFDckI7RUFDQSxNQUFNLElBQUk7R0FDUixJQUFJLENBQUMsaUJBQWlCLG1CQUFtQixTQUFTLE9BQU87R0FDekQsSUFBSSxPQUFPO0dBQ1gsSUFBSSxZQUFZO0dBQ2hCLElBQUksYUFBYTtHQUNqQixJQUFJLENBQUMsTUFBTSxXQUFXO0lBQ3BCLElBQUksUUFBUTtLQUNWLE9BQU8sWUFBWTtLQUNuQixZQUFZLGlCQUFpQjtLQUM3QixhQUFhLHFCQUFxQjtJQUNwQyxPQUFPO0tBQ0w7SUFDRjtHQUNGO0dBQ0EsSUFBSSxTQUFTO0dBQ2IsR0FBRyxlQUFlLGNBQWM7SUFDOUIsSUFBSSxRQUFRO0lBQ1osU0FBUztJQUNULElBQUksV0FBVztLQUNiLFNBQVMsWUFBWSxDQUFDLEVBQUUsQ0FBQztJQUMzQixPQUFPO0tBQ0wsU0FBUyxXQUFXLENBQUMsRUFBRSxDQUFDO0lBQzFCO0lBQ0EsSUFBSSxNQUFNLGNBQWM7S0FDdEIsTUFBTSxhQUFhO0lBQ3JCO0lBQ0EsR0FBRyxjQUFjLEtBQUs7R0FDeEI7R0FDQSxNQUFNLE9BQU8sR0FBRyxXQUFXLENBQUMsS0FBSyxNQUFNLEtBQUs7R0FDNUMsSUFBSSxNQUFNO0lBQ1IsY0FBYyxNQUFNLENBQUMsSUFBSSxJQUFJLENBQUM7R0FDaEMsT0FBTztJQUNMLEtBQUs7R0FDUDtFQUNGO0VBQ0EsTUFBTSxJQUFJLFFBQVE7R0FDaEIsTUFBTSxPQUFPLE9BQU8sTUFBTSxHQUFHO0dBQzdCLElBQUksR0FBRyxhQUFhO0lBQ2xCLEdBQUcsV0FBVztLQUNaOztJQUVGO0dBQ0Y7R0FDQSxJQUFJLE1BQU0sY0FBYztJQUN0QixPQUFPLE9BQU87R0FDaEI7R0FDQSxTQUFTLGVBQWUsQ0FBQyxFQUFFLENBQUM7R0FDNUIsSUFBSSxTQUFTO0dBQ2IsR0FBRyxlQUFlLGNBQWM7SUFDOUIsSUFBSSxRQUFRO0lBQ1osU0FBUztJQUNULE9BQU87SUFDUCxJQUFJLFdBQVc7S0FDYixTQUFTLGtCQUFrQixDQUFDLEVBQUUsQ0FBQztJQUNqQyxPQUFPO0tBQ0wsU0FBUyxjQUFjLENBQUMsRUFBRSxDQUFDO0lBQzdCO0lBQ0EsR0FBRyxjQUFjLEtBQUs7SUFDdEIsSUFBSSxtQkFBbUIsVUFBVSxPQUFPO0tBQ3RDLE9BQU8sbUJBQW1CO0lBQzVCO0dBQ0Y7R0FDQSxNQUFNLE9BQU8sR0FBRyxXQUFXLENBQUMsS0FBSyxNQUFNLEtBQUs7R0FDNUMsbUJBQW1CLFFBQVE7R0FDM0IsSUFBSSxTQUFTO0lBQ1gsY0FBYyxTQUFTLENBQUMsSUFBSSxJQUFJLENBQUM7R0FDbkMsT0FBTztJQUNMLEtBQUs7R0FDUDtFQUNGO0VBQ0EsTUFBTSxRQUFRO0dBQ1osTUFBTSxTQUFTLHVCQUNiLFFBQ0EsT0FDQSxPQUNBLFVBQ0EsU0FDRjtHQUNBLElBQUksV0FBVyxVQUFVLE1BQU07R0FDL0IsT0FBTztFQUNUO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGlCQUFpQixPQUFPO0NBQy9CLElBQUksWUFBWSxLQUFLLEdBQUc7RUFDdEIsUUFBUSxXQUFXLEtBQUs7RUFDeEIsTUFBTSxXQUFXO0VBQ2pCLE9BQU87Q0FDVDtBQUNGO0FBQ0EsU0FBUyxnQkFBZ0IsT0FBTztDQUM5QixJQUFJLENBQUMsWUFBWSxLQUFLLEdBQUc7RUFDdkIsSUFBSSxXQUFXLE1BQU0sSUFBSSxLQUFLLE1BQU0sVUFBVTtHQUM1QyxPQUFPLG9CQUFvQixNQUFNLFFBQVE7RUFDM0M7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLE1BQU0sV0FBVztFQUNuQixPQUFPLE1BQU0sVUFBVTtDQUN6QjtDQUNBLE1BQU0sRUFBRSxXQUFXLGFBQWE7Q0FDaEMsSUFBSSxVQUFVO0VBQ1osSUFBSSxZQUFZLElBQUk7R0FDbEIsT0FBTyxTQUFTO0VBQ2xCO0VBQ0EsSUFBSSxZQUFZLE1BQU0sV0FBVyxTQUFTLE9BQU8sR0FBRztHQUNsRCxPQUFPLFNBQVMsUUFBUTtFQUMxQjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLG1CQUFtQixPQUFPLE9BQU87Q0FDeEMsSUFBSSxNQUFNLFlBQVksS0FBSyxNQUFNLFdBQVc7RUFDMUMsTUFBTSxhQUFhO0VBQ25CLG1CQUFtQixNQUFNLFVBQVUsU0FBUyxLQUFLO0NBQ25ELE9BQU8sSUFBSSxNQUFNLFlBQVksS0FBSztFQUNoQyxNQUFNLFVBQVUsYUFBYSxNQUFNLE1BQU0sTUFBTSxTQUFTO0VBQ3hELE1BQU0sV0FBVyxhQUFhLE1BQU0sTUFBTSxNQUFNLFVBQVU7Q0FDNUQsT0FBTztFQUNMLE1BQU0sYUFBYTtDQUNyQjtBQUNGO0FBQ0EsU0FBUyx5QkFBeUIsVUFBVSxjQUFjLE9BQU8sV0FBVztDQUMxRSxJQUFJLE1BQU0sQ0FBQztDQUNYLElBQUkscUJBQXFCO0NBQ3pCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztFQUN4QyxJQUFJLFFBQVEsU0FBUztFQUNyQixNQUFNLE1BQU0sYUFBYSxPQUFPLE1BQU0sTUFBTSxPQUFPLFNBQVMsSUFBSSxPQUFPLE1BQU0sT0FBTyxPQUFPLE1BQU0sTUFBTSxDQUFDO0VBQ3hHLElBQUksTUFBTSxTQUFTLFVBQVU7R0FDM0IsSUFBSSxNQUFNLFlBQVksS0FBSztHQUMzQixNQUFNLElBQUksT0FDUix5QkFBeUIsTUFBTSxVQUFVLGFBQWEsR0FBRyxDQUMzRDtFQUNGLE9BQU8sSUFBSSxlQUFlLE1BQU0sU0FBUyxTQUFTO0dBQ2hELElBQUksS0FBSyxPQUFPLE9BQU8sV0FBVyxPQUFPLEVBQUUsSUFBSSxDQUFDLElBQUksS0FBSztFQUMzRDtDQUNGO0NBQ0EsSUFBSSxxQkFBcUIsR0FBRztFQUMxQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUs7R0FDbkMsSUFBSSxFQUFFLENBQUMsWUFBWSxDQUFDO0VBQ3RCO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7O0FBR0EsU0FBUyxnQkFBZ0IsU0FBUyxjQUFjO0NBQzlDLE9BQU8sV0FBVyxPQUFPLElBR1AsdUJBQU8sT0FBTyxFQUFFLE1BQU0sUUFBUSxLQUFLLEdBQUcsY0FBYyxFQUFFLE9BQU8sUUFBUSxDQUFDLEVBQUMsQ0FBRSxJQUN2RjtBQUNOO0FBRUEsU0FBUyxRQUFRO0NBQ2YsTUFBTSxJQUFJLG1CQUFtQjtDQUM3QixJQUFJLEdBQUc7RUFDTCxRQUFRLEVBQUUsV0FBVyxPQUFPLFlBQVksT0FBTyxNQUFNLEVBQUUsSUFBSSxLQUFLLEVBQUUsSUFBSSxFQUFFO0NBQzFFLE9BQU8sSUFBSSxDQUFDLG9CQUEyQixlQUFlO0VBQ3BELE9BQ0UscUZBQ0Y7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsa0JBQWtCLFVBQVU7Q0FDbkMsU0FBUyxNQUFNO0VBQUMsU0FBUyxJQUFJLEtBQUssU0FBUyxJQUFJLEVBQUUsS0FBSztFQUFLO0VBQUc7Q0FBQztBQUNqRTtBQUVBLE1BQU0sb0NBQW9DLElBQUksUUFBUTtBQUN0RCxTQUFTLGVBQWUsS0FBSztDQUMzQixNQUFNLElBQUksbUJBQW1CO0NBQzdCLE1BQU0sSUFBSSxXQUFXLElBQUk7Q0FDekIsSUFBSSxHQUFHO0VBQ0wsTUFBTSxPQUFPLEVBQUUsU0FBUyxZQUFZLEVBQUUsT0FBTyxDQUFDLElBQUksRUFBRTtFQUNwRCxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixpQkFBaUIsTUFBTSxHQUFHLEdBQUc7R0FDNUUsT0FBTyxtQkFBbUIsSUFBSSxtQkFBbUI7RUFDbkQsT0FBTztHQUNMLE9BQU8sZUFBZSxNQUFNLEtBQUs7SUFDL0IsWUFBWTtJQUNaLFdBQVcsRUFBRTtJQUNiLE1BQU0sUUFBUSxFQUFFLFFBQVE7R0FDMUIsQ0FBQztFQUNIO0NBQ0YsT0FBTyxJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDcEQsT0FDRSw4RkFDRjtDQUNGO0NBQ0EsTUFBTSxNQUFNLENBQUMsb0JBQTJCLGdCQUFnQixTQUFTLENBQUMsSUFBSTtDQUN0RSxJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDN0Msa0JBQWtCLElBQUksR0FBRztDQUMzQjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsaUJBQWlCLE1BQU0sS0FBSztDQUNuQyxJQUFJO0NBQ0osT0FBTyxDQUFDLEdBQUcsT0FBTyxPQUFPLHlCQUF5QixNQUFNLEdBQUcsTUFBTSxDQUFDLEtBQUs7QUFDekU7QUFFQSxNQUFNLG1DQUFtQyxJQUFJLFFBQVE7QUFDckQsU0FBUyxPQUFPLFFBQVEsV0FBVyxnQkFBZ0IsT0FBTyxZQUFZLE9BQU87Q0FDM0UsSUFBSSxRQUFRLE1BQU0sR0FBRztFQUNuQixPQUFPLFNBQ0osR0FBRyxNQUFNLE9BQ1IsR0FDQSxjQUFjLFFBQVEsU0FBUyxJQUFJLFVBQVUsS0FBSyxZQUNsRCxnQkFDQSxPQUNBLFNBQ0YsQ0FDRjtFQUNBO0NBQ0Y7Q0FDQSxJQUFJLGVBQWUsS0FBSyxLQUFLLENBQUMsV0FBVztFQUN2QyxJQUFJLE1BQU0sWUFBWSxPQUFPLE1BQU0sS0FBSyxtQkFBbUIsTUFBTSxVQUFVLFFBQVEsV0FBVztHQUM1RixPQUFPLFFBQVEsV0FBVyxnQkFBZ0IsTUFBTSxVQUFVLE9BQU87RUFDbkU7RUFDQTtDQUNGO0NBQ0EsTUFBTSxXQUFXLE1BQU0sWUFBWSxJQUFJLDJCQUEyQixNQUFNLFNBQVMsSUFBSSxNQUFNO0NBQzNGLE1BQU0sUUFBUSxZQUFZLE9BQU87Q0FDakMsTUFBTSxFQUFFLEdBQUcsT0FBTyxHQUFHLFFBQVE7Q0FDN0IsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsQ0FBQyxPQUFPO0VBQ3ZELE9BQ0UsK0hBQ0Y7RUFDQTtDQUNGO0NBQ0EsTUFBTSxTQUFTLGFBQWEsVUFBVTtDQUN0QyxNQUFNLE9BQU8sTUFBTSxTQUFTLFlBQVksTUFBTSxPQUFPLENBQUMsSUFBSSxNQUFNO0NBQ2hFLE1BQU0sYUFBYSxNQUFNO0NBQ3pCLE1BQU0sZ0JBQWdCLE1BQU0sVUFBVTtDQUN0QyxNQUFNLGlCQUFpQixlQUFlLFlBQVksTUFBTSxRQUFRO0VBQzlELElBQUksQ0FBQyxvQkFBMkIsZUFBZTtHQUM3QyxJQUFJLE9BQU8sZUFBZSxHQUFHLEtBQUssQ0FBQyxNQUFNLGNBQWMsSUFBSSxHQUFHO0lBQzVELE9BQ0UsaUJBQWlCLElBQUkscUVBQ3ZCO0dBQ0Y7R0FDQSxJQUFJLGtCQUFrQixJQUFJLGNBQWMsSUFBSSxHQUFHO0lBQzdDLE9BQU87R0FDVDtFQUNGO0VBQ0EsSUFBSSxpQkFBaUIsTUFBTSxHQUFHLEdBQUc7R0FDL0IsT0FBTztFQUNUO0VBQ0EsT0FBTyxPQUFPLGVBQWUsR0FBRztDQUNsQztDQUNBLE1BQU0sYUFBYSxNQUFNLFFBQVE7RUFDL0IsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsa0JBQWtCLElBQUksSUFBSSxHQUFHO0dBQzVFLE9BQU87RUFDVDtFQUNBLElBQUksT0FBTyxpQkFBaUIsTUFBTSxHQUFHLEdBQUc7R0FDdEMsT0FBTztFQUNUO0VBQ0EsT0FBTztDQUNUO0NBQ0EsSUFBSSxVQUFVLFFBQVEsV0FBVyxLQUFLO0VBQ3BDLHdCQUF3QixTQUFTO0VBQ2pDLElBQUksU0FBUyxNQUFNLEdBQUc7R0FDcEIsS0FBSyxVQUFVO0dBQ2YsSUFBSSxlQUFlLE1BQU0sR0FBRztJQUMxQixXQUFXLFVBQVU7R0FDdkI7RUFDRixPQUFPLElBQUksTUFBTSxNQUFNLEdBQUc7R0FDeEIsTUFBTSxnQkFBZ0I7R0FDdEIsSUFBSSxVQUFVLFFBQVEsY0FBYyxDQUFDLEdBQUc7SUFDdEMsT0FBTyxRQUFRO0dBQ2pCO0dBQ0EsSUFBSSxjQUFjLEdBQUcsS0FBSyxjQUFjLEtBQUs7RUFDL0M7Q0FDRjtDQUNBLElBQUksV0FBVyxHQUFHLEdBQUc7RUFDbkIsc0JBQXNCLEtBQUssT0FBTyxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUM7Q0FDckQsT0FBTztFQUNMLE1BQU0sWUFBWSxTQUFTLEdBQUc7RUFDOUIsTUFBTSxTQUFTLE1BQU0sR0FBRztFQUN4QixJQUFJLGFBQWEsUUFBUTtHQUN2QixNQUFNLGNBQWM7SUFDbEIsSUFBSSxPQUFPLEdBQUc7S0FDWixNQUFNLFdBQVcsWUFBWSxlQUFlLEdBQUcsSUFBSSxXQUFXLE9BQU8sS0FBSyxPQUFPLFVBQVUsR0FBRyxLQUFLLENBQUMsT0FBTyxJQUFJLElBQUksUUFBUSxLQUFLLE9BQU87S0FDdkksSUFBSSxXQUFXO01BQ2IsUUFBUSxRQUFRLEtBQUssT0FBTyxVQUFVLFFBQVE7S0FDaEQsT0FBTztNQUNMLElBQUksQ0FBQyxRQUFRLFFBQVEsR0FBRztPQUN0QixJQUFJLFdBQVc7UUFDYixLQUFLLE9BQU8sQ0FBQyxRQUFRO1FBQ3JCLElBQUksZUFBZSxHQUFHLEdBQUc7U0FDdkIsV0FBVyxPQUFPLEtBQUs7UUFDekI7T0FDRixPQUFPO1FBQ0wsTUFBTSxTQUFTLENBQUMsUUFBUTtRQUN4QixJQUFJLFVBQVUsS0FBSyxPQUFPLENBQUMsR0FBRztTQUM1QixJQUFJLFFBQVE7UUFDZDtRQUNBLElBQUksT0FBTyxHQUFHLEtBQUssT0FBTyxLQUFLO09BQ2pDO01BQ0YsT0FBTyxJQUFJLENBQUMsU0FBUyxTQUFTLFFBQVEsR0FBRztPQUN2QyxTQUFTLEtBQUssUUFBUTtNQUN4QjtLQUNGO0lBQ0YsT0FBTyxJQUFJLFdBQVc7S0FDcEIsS0FBSyxPQUFPO0tBQ1osSUFBSSxlQUFlLEdBQUcsR0FBRztNQUN2QixXQUFXLE9BQU87S0FDcEI7SUFDRixPQUFPLElBQUksUUFBUTtLQUNqQixJQUFJLFVBQVUsS0FBSyxPQUFPLENBQUMsR0FBRztNQUM1QixJQUFJLFFBQVE7S0FDZDtLQUNBLElBQUksT0FBTyxHQUFHLEtBQUssT0FBTyxLQUFLO0lBQ2pDLE9BQU8sSUFBSSxDQUFDLG9CQUEyQixlQUFlO0tBQ3BELE9BQU8sOEJBQThCLEtBQUssSUFBSSxPQUFPLElBQUksRUFBRTtJQUM3RDtHQUNGO0dBQ0EsSUFBSSxPQUFPO0lBQ1QsTUFBTSxZQUFZO0tBQ2hCLE1BQU07S0FDTixpQkFBaUIsT0FBTyxNQUFNO0lBQ2hDO0lBQ0EsSUFBSSxLQUFLLENBQUM7SUFDVixpQkFBaUIsSUFBSSxRQUFRLEdBQUc7SUFDaEMsc0JBQXNCLEtBQUssY0FBYztHQUMzQyxPQUFPO0lBQ0wsd0JBQXdCLE1BQU07SUFDOUIsTUFBTTtHQUNSO0VBQ0YsT0FBTyxJQUFJLENBQUMsb0JBQTJCLGVBQWU7R0FDcEQsT0FBTyw4QkFBOEIsS0FBSyxJQUFJLE9BQU8sSUFBSSxFQUFFO0VBQzdEO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsd0JBQXdCLFFBQVE7Q0FDdkMsTUFBTSxnQkFBZ0IsaUJBQWlCLElBQUksTUFBTTtDQUNqRCxJQUFJLGVBQWU7RUFDakIsY0FBYyxTQUFTO0VBQ3ZCLGlCQUFpQixPQUFPLE1BQU07Q0FDaEM7QUFDRjtBQUVBLElBQUkseUJBQXlCO0FBQzdCLE1BQU0seUJBQXlCO0NBQzdCLElBQUksd0JBQXdCO0VBQzFCO0NBQ0Y7Q0FDQSxRQUFRLE1BQU0sOENBQThDO0NBQzVELHlCQUF5QjtBQUMzQjtBQUNBLE1BQU0sa0JBQWtCLGNBQWMsVUFBVSxhQUFhLFNBQVMsS0FBSyxLQUFLLFVBQVUsWUFBWTtBQUN0RyxNQUFNLHFCQUFxQixjQUFjLFVBQVUsYUFBYSxTQUFTLFFBQVE7QUFDakYsTUFBTSxvQkFBb0IsY0FBYztDQUN0QyxJQUFJLFVBQVUsYUFBYSxHQUFHLE9BQU8sS0FBSztDQUMxQyxJQUFJLGVBQWUsU0FBUyxHQUFHLE9BQU87Q0FDdEMsSUFBSSxrQkFBa0IsU0FBUyxHQUFHLE9BQU87Q0FDekMsT0FBTyxLQUFLO0FBQ2Q7QUFDQSxNQUFNLGFBQWEsU0FBUyxLQUFLLGFBQWE7QUFDOUMsU0FBUyx5QkFBeUIsbUJBQW1CO0NBQ25ELE1BQU0sRUFDSixJQUFJLGdCQUNKLEdBQUcsT0FDSCxHQUFHLEVBQ0QsV0FDQSxZQUNBLGFBQ0EsWUFDQSxRQUNBLFFBQ0Esb0JBRUE7Q0FDSixNQUFNLFdBQVcsT0FBTyxjQUFjO0VBQ3BDLElBQUksQ0FBQyxVQUFVLGNBQWMsR0FBRztHQUM5QixDQUFDLENBQUMsb0JBQTJCLGlCQUFpQiw0Q0FBNEMsT0FDeEYsOEZBQ0Y7R0FDQSxNQUFNLE1BQU0sT0FBTyxTQUFTO0dBQzVCLGtCQUFrQjtHQUNsQixVQUFVLFNBQVM7R0FDbkI7RUFDRjtFQUNBLFlBQVksVUFBVSxZQUFZLE9BQU8sTUFBTSxNQUFNLElBQUk7RUFDekQsa0JBQWtCO0VBQ2xCLFVBQVUsU0FBUztDQUNyQjtDQUNBLE1BQU0sZUFBZSxNQUFNLE9BQU8saUJBQWlCLGdCQUFnQixjQUFjLFlBQVksVUFBVTtFQUNyRyxZQUFZLGFBQWEsQ0FBQyxDQUFDLE1BQU07RUFDakMsTUFBTSxrQkFBa0IsVUFBVSxJQUFJLEtBQUssS0FBSyxTQUFTO0VBQ3pELE1BQU0sbUJBQW1CLGVBQ3ZCLE1BQ0EsT0FDQSxpQkFDQSxnQkFDQSxjQUNBLGVBQ0Y7RUFDQSxNQUFNLEVBQUUsTUFBTSxLQUFLLFdBQVcsY0FBYztFQUM1QyxJQUFJLFVBQVUsS0FBSztFQUNuQixNQUFNLEtBQUs7RUFDWCxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQix1QkFBdUI7R0FDdEUsSUFBSSxNQUFNLFdBQVcsT0FBTyxJQUFJO0dBQ2hDLElBQUksTUFBTSx3QkFBd0IsaUJBQWlCLElBQUk7RUFDekQ7RUFDQSxJQUFJLGNBQWMsQ0FBQyxHQUFHO0dBQ3BCLFlBQVk7R0FDWixNQUFNLGtCQUFrQjtFQUMxQjtFQUNBLElBQUksV0FBVztFQUNmLFFBQVEsTUFBUjtHQUNFLEtBQUs7SUFDSCxJQUFJLFlBQVksR0FBRztLQUNqQixJQUFJLE1BQU0sYUFBYSxJQUFJO01BQ3pCLE9BQU8sTUFBTSxLQUFLLFdBQVcsRUFBRSxHQUFHLFdBQVcsSUFBSSxHQUFHLElBQUk7TUFDeEQsV0FBVztLQUNiLE9BQU87TUFDTCxXQUFXLFdBQVc7S0FDeEI7SUFDRixPQUFPO0tBQ0wsSUFBSSxLQUFLLFNBQVMsTUFBTSxVQUFVO01BQ2hDLENBQUMsQ0FBQyxvQkFBMkIsaUJBQWlCLDRDQUE0QyxPQUN4Riw4QkFDQSxLQUFLLFlBQ0w7MEJBQ1ksS0FBSyxVQUNmLEtBQUssSUFDUCxFQUFFOzBCQUNVLEtBQUssVUFBVSxNQUFNLFFBQVEsR0FDM0M7TUFDQSxpQkFBaUI7TUFDakIsS0FBSyxPQUFPLE1BQU07S0FDcEI7S0FDQSxXQUFXLFlBQVksSUFBSTtJQUM3QjtJQUNBO0dBQ0YsS0FBSztJQUNILElBQUksZUFBZSxJQUFJLEdBQUc7S0FDeEIsV0FBVyxZQUFZLElBQUk7S0FDM0IsWUFDRSxNQUFNLEtBQUssS0FBSyxRQUFRLFlBQ3hCLE1BQ0EsZUFDRjtJQUNGLE9BQU8sSUFBSSxZQUFZLEtBQUssaUJBQWlCO0tBQzNDLFdBQVcsV0FBVztJQUN4QixPQUFPO0tBQ0wsV0FBVyxZQUFZLElBQUk7SUFDN0I7SUFDQTtHQUNGLEtBQUs7SUFDSCxJQUFJLGlCQUFpQjtLQUNuQixPQUFPLFlBQVksSUFBSTtLQUN2QixVQUFVLEtBQUs7SUFDakI7SUFDQSxJQUFJLFlBQVksS0FBSyxZQUFZLEdBQUc7S0FDbEMsV0FBVztLQUNYLE1BQU0scUJBQXFCLENBQUMsTUFBTSxTQUFTO0tBQzNDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLGFBQWEsS0FBSztNQUMxQyxJQUFJLG9CQUNGLE1BQU0sWUFBWSxTQUFTLGFBQWEsSUFBSSxTQUFTLFlBQVksU0FBUztNQUM1RSxJQUFJLE1BQU0sTUFBTSxjQUFjLEdBQUc7T0FDL0IsTUFBTSxTQUFTO01BQ2pCO01BQ0EsV0FBVyxZQUFZLFFBQVE7S0FDakM7S0FDQSxPQUFPLGtCQUFrQixZQUFZLFFBQVEsSUFBSTtJQUNuRCxPQUFPO0tBQ0wsV0FBVztJQUNiO0lBQ0E7R0FDRixLQUFLO0lBQ0gsSUFBSSxDQUFDLGlCQUFpQjtLQUNwQixXQUFXLFdBQVc7SUFDeEIsT0FBTztLQUNMLFdBQVcsZ0JBQ1QsTUFDQSxPQUNBLGlCQUNBLGdCQUNBLGNBQ0EsU0FDRjtJQUNGO0lBQ0E7R0FDRixTQUNFLElBQUksWUFBWSxHQUFHO0lBQ2pCLEtBQUssWUFBWSxLQUFLLE1BQU0sS0FBSyxZQUFZLE1BQU0sS0FBSyxRQUFRLFlBQVksTUFBTSxDQUFDLGVBQWUsSUFBSSxHQUFHO0tBQ3ZHLFdBQVcsV0FBVztJQUN4QixPQUFPO0tBQ0wsV0FBVyxlQUNULE1BQ0EsT0FDQSxpQkFDQSxnQkFDQSxjQUNBLFNBQ0Y7SUFDRjtHQUNGLE9BQU8sSUFBSSxZQUFZLEdBQUc7SUFDeEIsTUFBTSxlQUFlO0lBQ3JCLE1BQU0sWUFBWSxXQUFXLElBQUk7SUFDakMsSUFBSSxpQkFBaUI7S0FDbkIsV0FBVyxvQkFBb0IsSUFBSTtJQUNyQyxPQUFPLElBQUksVUFBVSxJQUFJLEtBQUssS0FBSyxTQUFTLGtCQUFrQjtLQUM1RCxXQUFXLG9CQUFvQixNQUFNLEtBQUssTUFBTSxjQUFjO0lBQ2hFLE9BQU87S0FDTCxXQUFXLFlBQVksSUFBSTtJQUM3QjtJQUNBLGVBQ0UsT0FDQSxXQUNBLE1BQ0EsaUJBQ0EsZ0JBQ0EsaUJBQWlCLFNBQVMsR0FDMUIsU0FDRjtJQUNBLElBQUksZUFBZSxLQUFLLEtBQUssQ0FBQyxNQUFNLEtBQUssaUJBQWlCO0tBQ3hELElBQUk7S0FDSixJQUFJLGlCQUFpQjtNQUNuQixVQUFVLFlBQVksUUFBUTtNQUM5QixRQUFRLFNBQVMsV0FBVyxTQUFTLGtCQUFrQixVQUFVO0tBQ25FLE9BQU87TUFDTCxVQUFVLEtBQUssYUFBYSxJQUFJLGdCQUFnQixFQUFFLElBQUksWUFBWSxLQUFLO0tBQ3pFO0tBQ0EsUUFBUSxLQUFLO0tBQ2IsTUFBTSxVQUFVLFVBQVU7SUFDNUI7R0FDRixPQUFPLElBQUksWUFBWSxJQUFJO0lBQ3pCLElBQUksWUFBWSxHQUFHO0tBQ2pCLFdBQVcsV0FBVztJQUN4QixPQUFPO0tBQ0wsV0FBVyxNQUFNLEtBQUssUUFDcEIsTUFDQSxPQUNBLGlCQUNBLGdCQUNBLGNBQ0EsV0FDQSxtQkFDQSxlQUNGO0lBQ0Y7R0FDRixPQUFPLElBQUksWUFBWSxLQUFLO0lBQzFCLFdBQVcsTUFBTSxLQUFLLFFBQ3BCLE1BQ0EsT0FDQSxpQkFDQSxnQkFDQSxpQkFBaUIsV0FBVyxJQUFJLENBQUMsR0FDakMsY0FDQSxXQUNBLG1CQUNBLFdBQ0Y7R0FDRixPQUFPLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLHlDQUF5QztJQUMvRixPQUFPLDJCQUEyQixNQUFNLElBQUksT0FBTyxLQUFLLEVBQUU7R0FDNUQ7RUFDSjtFQUNBLElBQUksT0FBTyxNQUFNO0dBQ2YsT0FBTyxLQUFLLE1BQU0sZ0JBQWdCLEtBQUs7RUFDekM7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLGtCQUFrQixJQUFJLE9BQU8saUJBQWlCLGdCQUFnQixjQUFjLGNBQWM7RUFDOUYsWUFBWSxhQUFhLENBQUMsQ0FBQyxNQUFNO0VBQ2pDLE1BQU0sRUFDSixNQUNBLGNBQ0EsT0FDQSxXQUNBLFdBQ0EsTUFDQSxlQUNFO0VBQ0osTUFBTSxhQUFhLFNBQVMsV0FBVyxTQUFTO0VBQ2hELE1BQU0sa0JBQWtCLENBQUMsQ0FBQztFQUMxQixJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixjQUFjLG1CQUFtQixjQUFjLENBQUMsR0FBRztHQUNsRyxJQUFJLE1BQU07SUFDUixvQkFBb0IsT0FBTyxNQUFNLGlCQUFpQixTQUFTO0dBQzdEO0dBQ0EsSUFBSSwwQkFBMEI7R0FDOUIsSUFBSSxlQUFlLEVBQUUsR0FBRztJQUN0QiwwQkFBMEI7S0FDeEI7O0tBRUE7SUFDRixLQUFLLG1CQUFtQixnQkFBZ0IsTUFBTSxTQUFTLGdCQUFnQixNQUFNLE1BQU07SUFDbkYsTUFBTSxVQUFVLEdBQUcsUUFBUTtJQUMzQixJQUFJLHlCQUF5QjtLQUMzQixNQUFNLE1BQU0sUUFBUSxhQUFhLE9BQU87S0FDeEMsSUFBSSxLQUFLLFFBQVEsT0FBTztLQUN4QixXQUFXLFlBQVksT0FBTztJQUNoQztJQUNBLFlBQVksU0FBUyxJQUFJLGVBQWU7SUFDeEMsTUFBTSxLQUFLLEtBQUs7R0FDbEI7R0FDQSxJQUFJLFlBQVksTUFDaEIsRUFBRSxVQUFVLE1BQU0sYUFBYSxNQUFNLGVBQWU7SUFDbEQsSUFBSSxPQUFPLGdCQUNULEdBQUcsWUFDSCxPQUNBLElBQ0EsaUJBQ0EsZ0JBQ0EsY0FDQSxTQUNGO0lBQ0EsSUFBSSxRQUFRLENBQUM7S0FBa0I7S0FBSTs7SUFBZ0IsR0FBRztLQUNwRCxDQUFDLENBQUMsb0JBQTJCLGlCQUFpQiw0Q0FBNEMsT0FDeEYsa0NBQ0EsSUFDQTtvRUFFRjtLQUNBLGlCQUFpQjtJQUNuQjtJQUNBLE9BQU8sTUFBTTtLQUNYLE1BQU0sTUFBTTtLQUNaLE9BQU8sS0FBSztLQUNaLE9BQU8sR0FBRztJQUNaO0dBQ0YsT0FBTyxJQUFJLFlBQVksR0FBRztJQUN4QixJQUFJLGFBQWEsTUFBTTtJQUN2QixJQUFJLFdBQVcsT0FBTyxTQUFTLEdBQUcsWUFBWSxTQUFTLEdBQUcsWUFBWSxhQUFhO0tBQ2pGLGFBQWEsV0FBVyxNQUFNLENBQUM7SUFDakM7SUFDQSxNQUFNLEVBQUUsZ0JBQWdCO0lBQ3hCLElBQUksZ0JBQWdCLGNBQ3BCLGdCQUFnQixXQUFXLFFBQVEsWUFBWSxJQUFJLEdBQUc7S0FDcEQsSUFBSSxDQUFDO01BQWtCO01BQUk7O0tBQVksR0FBRztNQUN4QyxDQUFDLENBQUMsb0JBQTJCLGlCQUFpQiw0Q0FBNEMsT0FDeEYsc0NBQ0EsSUFDQTswQkFDWSxZQUFZOzBCQUNaLFlBQ2Q7TUFDQSxpQkFBaUI7S0FDbkI7S0FDQSxHQUFHLGNBQWMsTUFBTTtJQUN6QjtHQUNGO0dBQ0EsSUFBSSxPQUFPO0lBQ1QsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsMkNBQTJDLGNBQWMsbUJBQW1CLENBQUMsYUFBYSxhQUFhLEtBQUssS0FBSztLQUNoSyxNQUFNLGtCQUFrQixHQUFHLFFBQVEsU0FBUyxHQUFHO0tBQy9DLE1BQU0sWUFBWSxHQUFHLGFBQWEsU0FBUyxLQUFLLElBQUksUUFBUSxHQUFHLGFBQWEsU0FBUyxRQUFRLElBQUksV0FBVyxLQUFLO0tBQ2pILEtBQUssTUFBTSxPQUFPLE9BQU87TUFDdkIsS0FBSyxDQUFDLG9CQUEyQixpQkFBaUIsNENBRWxELEVBQUUsUUFBUSxLQUFLLE1BQU0sTUFBTSxFQUFFLElBQUksT0FBTyxNQUFNLGdCQUFnQixJQUFJLEtBQUssTUFBTSxNQUFNLE9BQU8sZUFBZSxHQUFHO09BQzFHLGlCQUFpQjtNQUNuQjtNQUNBLElBQUksZUFBZSxJQUFJLFNBQVMsT0FBTyxLQUFLLFFBQVEsb0JBQW9CLEtBQUssR0FBRyxLQUFLLENBQUMsZUFBZSxHQUFHLEtBQ3hHLElBQUksT0FBTyxPQUFPLG1CQUFtQixDQUFDLGVBQWUsR0FBRyxLQUFLLGdCQUFnQixhQUFhLFNBQVMsR0FBRyxHQUFHO09BQ3ZHLFVBQVUsSUFBSSxLQUFLLE1BQU0sTUFBTSxNQUFNLFdBQVcsZUFBZTtNQUNqRTtLQUNGO0lBQ0YsT0FBTyxJQUFJLE1BQU0sU0FBUztLQUN4QixVQUNFLElBQ0EsV0FDQSxNQUNBLE1BQU0sU0FDTixLQUFLLEdBQ0wsZUFDRjtJQUNGLE9BQU8sSUFBSSxZQUFZLEtBQUssV0FBVyxNQUFNLEtBQUssR0FBRztLQUNuRCxLQUFLLE1BQU0sT0FBTyxNQUFNLE9BQU8sTUFBTSxNQUFNO0lBQzdDO0dBQ0Y7R0FDQSxJQUFJO0dBQ0osSUFBSSxhQUFhLFNBQVMsTUFBTSxvQkFBb0I7SUFDbEQsZ0JBQWdCLFlBQVksaUJBQWlCLEtBQUs7R0FDcEQ7R0FDQSxJQUFJLE1BQU07SUFDUixvQkFBb0IsT0FBTyxNQUFNLGlCQUFpQixhQUFhO0dBQ2pFO0dBQ0EsS0FBSyxhQUFhLFNBQVMsTUFBTSxtQkFBbUIsUUFBUSx5QkFBeUI7SUFDbkYsOEJBQThCO0tBQzVCLGNBQWMsZ0JBQWdCLFlBQVksaUJBQWlCLEtBQUs7S0FDaEUsMkJBQTJCLFdBQVcsTUFBTSxFQUFFO0tBQzlDLFFBQVEsb0JBQW9CLE9BQU8sTUFBTSxpQkFBaUIsU0FBUztJQUNyRSxHQUFHLGNBQWM7R0FDbkI7RUFDRjtFQUNBLE9BQU8sR0FBRztDQUNaO0NBQ0EsTUFBTSxtQkFBbUIsTUFBTSxhQUFhLFdBQVcsaUJBQWlCLGdCQUFnQixjQUFjLGNBQWM7RUFDbEgsWUFBWSxhQUFhLENBQUMsQ0FBQyxZQUFZO0VBQ3ZDLE1BQU0sV0FBVyxZQUFZO0VBQzdCLE1BQU0sSUFBSSxTQUFTO0VBQ25CLElBQUkscUJBQXFCO0VBQ3pCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUs7R0FDMUIsTUFBTSxRQUFRLFlBQVksU0FBUyxLQUFLLFNBQVMsS0FBSyxlQUFlLFNBQVMsRUFBRTtHQUNoRixNQUFNLFNBQVMsTUFBTSxTQUFTO0dBQzlCLElBQUksTUFBTTtJQUNSLElBQUksVUFBVSxDQUFDLFdBQVc7S0FDeEIsSUFBSSxJQUFJLElBQUksS0FBSyxlQUFlLFNBQVMsSUFBSSxFQUFFLENBQUMsQ0FBQyxTQUFTLE1BQU07TUFDOUQsT0FDRSxXQUNFLEtBQUssS0FBSyxNQUFNLE1BQU0sU0FBUyxNQUFNLENBQ3ZDLEdBQ0EsV0FDQSxZQUFZLElBQUksQ0FDbEI7TUFDQSxLQUFLLE9BQU8sTUFBTTtLQUNwQjtJQUNGO0lBQ0EsT0FBTyxZQUNMLE1BQ0EsT0FDQSxpQkFDQSxnQkFDQSxjQUNBLFNBQ0Y7R0FDRixPQUFPLElBQUksVUFBVSxDQUFDLE1BQU0sVUFBVTtJQUNwQyxPQUFPLE1BQU0sS0FBSyxXQUFXLEVBQUUsR0FBRyxTQUFTO0dBQzdDLE9BQU87SUFDTCxJQUFJLENBQUMsb0JBQW9CO0tBQ3ZCLHFCQUFxQjtLQUNyQixJQUFJLENBQUM7TUFBa0I7TUFBVzs7S0FBZ0IsR0FBRztNQUNuRCxDQUFDLENBQUMsb0JBQTJCLGlCQUFpQiw0Q0FBNEMsT0FDeEYsa0NBQ0EsV0FDQTtxRUFFRjtNQUNBLGlCQUFpQjtLQUNuQjtJQUNGO0lBQ0EsTUFDRSxNQUNBLE9BQ0EsV0FDQSxNQUNBLGlCQUNBLGdCQUNBLGlCQUFpQixTQUFTLEdBQzFCLFlBQ0Y7R0FDRjtFQUNGO0VBQ0EsT0FBTztDQUNUO0NBQ0EsTUFBTSxtQkFBbUIsTUFBTSxPQUFPLGlCQUFpQixnQkFBZ0IsY0FBYyxjQUFjO0VBQ2pHLE1BQU0sRUFBRSxjQUFjLHlCQUF5QjtFQUMvQyxJQUFJLHNCQUFzQjtHQUN4QixlQUFlLGVBQWUsYUFBYSxPQUFPLG9CQUFvQixJQUFJO0VBQzVFO0VBQ0EsTUFBTSxZQUFZLFdBQVcsSUFBSTtFQUNqQyxNQUFNLE9BQU8sZ0JBQ1gsWUFBWSxJQUFJLEdBQ2hCLE9BQ0EsV0FDQSxpQkFDQSxnQkFDQSxjQUNBLFNBQ0Y7RUFDQSxJQUFJLFFBQVEsVUFBVSxJQUFJLEtBQUssS0FBSyxTQUFTLEtBQUs7R0FDaEQsT0FBTyxZQUFZLE1BQU0sU0FBUyxJQUFJO0VBQ3hDLE9BQU87R0FDTCxpQkFBaUI7R0FDakIsT0FBTyxNQUFNLFNBQVMsY0FBYyxHQUFHLEdBQUcsV0FBVyxJQUFJO0dBQ3pELE9BQU87RUFDVDtDQUNGO0NBQ0EsTUFBTSxrQkFBa0IsTUFBTSxPQUFPLGlCQUFpQixnQkFBZ0IsY0FBYyxlQUFlO0VBQ2pHLElBQUksQ0FBQyxzQkFBc0IsTUFBTSxLQUFLLEdBQUc7R0FDdkMsQ0FBQyxDQUFDLG9CQUEyQixpQkFBaUIsNENBQTRDLE9BQ3hGO3dCQUVBLE1BQ0EsS0FBSyxhQUFhLElBQUksV0FBVyxVQUFVLElBQUksS0FBSyxLQUFLLFNBQVMsTUFBTSx3QkFBd0IsSUFDaEc7d0JBRUEsTUFBTSxJQUNSO0dBQ0EsaUJBQWlCO0VBQ25CO0VBQ0EsTUFBTSxLQUFLO0VBQ1gsSUFBSSxZQUFZO0dBQ2QsTUFBTSxNQUFNLG9CQUFvQixJQUFJO0dBQ3BDLE9BQU8sTUFBTTtJQUNYLE1BQU0sUUFBUSxZQUFZLElBQUk7SUFDOUIsSUFBSSxTQUFTLFVBQVUsS0FBSztLQUMxQixPQUFPLEtBQUs7SUFDZCxPQUFPO0tBQ0w7SUFDRjtHQUNGO0VBQ0Y7RUFDQSxNQUFNLE9BQU8sWUFBWSxJQUFJO0VBQzdCLE1BQU0sWUFBWSxXQUFXLElBQUk7RUFDakMsT0FBTyxJQUFJO0VBQ1gsTUFDRSxNQUNBLE9BQ0EsV0FDQSxNQUNBLGlCQUNBLGdCQUNBLGlCQUFpQixTQUFTLEdBQzFCLFlBQ0Y7RUFDQSxJQUFJLGlCQUFpQjtHQUNuQixnQkFBZ0IsTUFBTSxLQUFLLE1BQU07R0FDakMsZ0JBQWdCLGlCQUFpQixNQUFNLEVBQUU7RUFDM0M7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLHVCQUF1QixNQUFNLE9BQU8sS0FBSyxRQUFRLFFBQVE7RUFDN0QsSUFBSSxRQUFRO0VBQ1osT0FBTyxNQUFNO0dBQ1gsT0FBTyxZQUFZLElBQUk7R0FDdkIsSUFBSSxRQUFRLFVBQVUsSUFBSSxHQUFHO0lBQzNCLElBQUksS0FBSyxTQUFTLE1BQU07SUFDeEIsSUFBSSxLQUFLLFNBQVMsT0FBTztLQUN2QixJQUFJLFVBQVUsR0FBRztNQUNmLE9BQU8sWUFBWSxJQUFJO0tBQ3pCLE9BQU87TUFDTDtLQUNGO0lBQ0Y7R0FDRjtFQUNGO0VBQ0EsT0FBTztDQUNUO0NBQ0EsTUFBTSxlQUFlLFNBQVMsU0FBUyxvQkFBb0I7RUFDekQsTUFBTSxjQUFjLFFBQVE7RUFDNUIsSUFBSSxhQUFhO0dBQ2YsWUFBWSxhQUFhLFNBQVMsT0FBTztFQUMzQztFQUNBLElBQUksU0FBUztFQUNiLE9BQU8sUUFBUTtHQUNiLElBQUksT0FBTyxNQUFNLE9BQU8sU0FBUztJQUMvQixPQUFPLE1BQU0sS0FBSyxPQUFPLFFBQVEsS0FBSztHQUN4QztHQUNBLFNBQVMsT0FBTztFQUNsQjtDQUNGO0NBQ0EsTUFBTSxrQkFBa0IsU0FBUztFQUMvQixPQUFPLEtBQUssYUFBYSxLQUFLLEtBQUssWUFBWTtDQUNqRDtDQUNBLE9BQU8sQ0FBQyxTQUFTLFdBQVc7QUFDOUI7QUFDQSxTQUFTLGdCQUFnQixJQUFJLEtBQUssYUFBYSxPQUFPLFVBQVU7Q0FDOUQsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUksUUFBUSxTQUFTO0VBQ25CLElBQUksR0FBRyxNQUFNO0dBQ1gsU0FBUyxHQUFHO0dBQ1osT0FBTyxHQUFHO0VBQ1osT0FBTztHQUNMLFNBQVMsR0FBRyxhQUFhLE9BQU87RUFDbEM7RUFDQSxXQUFXLGVBQWUsV0FBVztFQUNyQyxJQUFJLENBQUMsV0FBVyxXQUFXLFVBQVUsRUFBRSxHQUFHLFdBQVcsUUFBUSxDQUFDLEdBQUc7R0FDL0QsZUFBZTtHQUNmLGNBQWM7RUFDaEI7Q0FDRixPQUFPLElBQUksUUFBUSxTQUFTO0VBQzFCLFNBQVMsR0FBRyxhQUFhLE9BQU8sS0FBSztFQUNyQyxXQUFXLFNBQVMsV0FBVyxJQUFJLGNBQWMsZUFBZSxlQUFlLFdBQVcsQ0FBQztFQUMzRixNQUFNLFlBQVksV0FBVyxNQUFNO0VBQ25DLE1BQU0sY0FBYyxXQUFXLFFBQVE7RUFDdkMsSUFBSSxNQUFNLE1BQU07R0FDZCxLQUFLLE1BQU0sRUFBRSxLQUFLLFdBQVcsTUFBTSxNQUFNO0lBQ3ZDLElBQUksSUFBSSxTQUFTLFVBQVUsQ0FBQyxPQUFPO0tBQ2pDLFlBQVksSUFBSSxXQUFXLE1BQU07SUFDbkM7R0FDRjtFQUNGO0VBQ0EsSUFBSSxVQUFVO0dBQ1osZUFBZSxVQUFVLE9BQU8sV0FBVztFQUM3QztFQUNBLElBQUksQ0FBQyxXQUFXLFdBQVcsV0FBVyxHQUFHO0dBQ3ZDLGVBQWU7R0FDZixjQUFjO0VBQ2hCO0NBQ0YsT0FBTyxJQUFJLGNBQWMsY0FBYyxlQUFlLEdBQUcsS0FBSyxjQUFjLGdCQUFnQixjQUFjLEdBQUcsS0FBSyxnQkFBZ0IsR0FBRyxJQUFJO0VBQ3ZJLElBQUksY0FBYyxHQUFHLEdBQUc7R0FDdEIsU0FBUyxHQUFHLGFBQWEsR0FBRztHQUM1QixXQUFXLG1CQUFtQixXQUFXO0VBQzNDLE9BQU8sSUFBSSxlQUFlLE1BQU07R0FDOUIsU0FBUyxHQUFHLGFBQWEsR0FBRztHQUM1QixXQUFXO0VBQ2IsT0FBTztHQUNMLElBQUksR0FBRyxhQUFhLEdBQUcsR0FBRztJQUN4QixTQUFTLEdBQUcsYUFBYSxHQUFHO0dBQzlCLE9BQU8sSUFBSSxRQUFRLFdBQVcsR0FBRyxZQUFZLFlBQVk7SUFDdkQsU0FBUyxHQUFHO0dBQ2QsT0FBTztJQUNMLFNBQVM7R0FDWDtHQUNBLFdBQVcsc0JBQXNCLFdBQVcsSUFBSSxPQUFPLFdBQVcsSUFBSTtFQUN4RTtFQUNBLElBQUksV0FBVyxVQUFVO0dBQ3ZCLGVBQWU7R0FDZixjQUFjO0VBQ2hCO0NBQ0Y7Q0FDQSxJQUFJLGdCQUFnQixRQUFRLENBQUMsa0JBQWtCLElBQUksWUFBWSxHQUFHO0VBQ2hFLE1BQU0sVUFBVSxNQUFNLE1BQU0sUUFBUSxtQkFBbUIsR0FBRyxZQUFZLElBQUksRUFBRTtFQUM1RSxNQUFNLGFBQWEsYUFBYSxtQkFBbUIsY0FBYztFQUNqRSxNQUFNLGNBQWM7MEJBQ0UsT0FBTyxNQUFNLEVBQUU7MEJBQ2YsT0FBTyxRQUFRLEVBQUU7OztFQUd2QztHQUNFLE9BQU8sWUFBWSxJQUFJLFdBQVc7RUFDcEM7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLFdBQVcsS0FBSztDQUN2QixPQUFPLElBQUksSUFBSSxJQUFJLEtBQUssQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDO0FBQ3hDO0FBQ0EsU0FBUyxXQUFXLEdBQUcsR0FBRztDQUN4QixJQUFJLEVBQUUsU0FBUyxFQUFFLE1BQU07RUFDckIsT0FBTztDQUNUO0NBQ0EsS0FBSyxNQUFNLEtBQUssR0FBRztFQUNqQixJQUFJLENBQUMsRUFBRSxJQUFJLENBQUMsR0FBRztHQUNiLE9BQU87RUFDVDtDQUNGO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxXQUFXLEtBQUs7Q0FDdkIsTUFBTSwyQkFBMkIsSUFBSSxJQUFJO0NBQ3pDLEtBQUssTUFBTSxRQUFRLElBQUksTUFBTSxHQUFHLEdBQUc7RUFDakMsSUFBSSxDQUFDLEtBQUssU0FBUyxLQUFLLE1BQU0sR0FBRztFQUNqQyxNQUFNLElBQUksS0FBSztFQUNmLFFBQVEsU0FBUyxNQUFNLEtBQUs7RUFDNUIsSUFBSSxPQUFPLE9BQU87R0FDaEIsU0FBUyxJQUFJLEtBQUssS0FBSztFQUN6QjtDQUNGO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxXQUFXLEdBQUcsR0FBRztDQUN4QixJQUFJLEVBQUUsU0FBUyxFQUFFLE1BQU07RUFDckIsT0FBTztDQUNUO0NBQ0EsS0FBSyxNQUFNLENBQUMsS0FBSyxVQUFVLEdBQUc7RUFDNUIsSUFBSSxVQUFVLEVBQUUsSUFBSSxHQUFHLEdBQUc7R0FDeEIsT0FBTztFQUNUO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGVBQWUsVUFBVSxPQUFPLGFBQWE7Q0FDcEQsTUFBTSxPQUFPLFNBQVM7Q0FDdEIsSUFBSSxTQUFTLGVBQWUsVUFBVSxRQUFRLFFBQVEsS0FBSyxTQUFTLFlBQVksS0FBSyxTQUFTLFNBQVMsS0FBSyxJQUFJO0VBQzlHLE1BQU0sVUFBVSxTQUFTLFdBQVc7RUFDcEMsS0FBSyxNQUFNLE9BQU8sU0FBUztHQUN6QixNQUFNLFFBQVEscUJBQXFCLFFBQVEsSUFBSTtHQUMvQyxZQUFZLElBQUksS0FBSyxxQkFBcUIsS0FBSyxLQUFLLEtBQUssS0FBSztFQUNoRTtDQUNGO0NBQ0EsSUFBSSxVQUFVLFFBQVEsU0FBUyxRQUFRO0VBQ3JDLGVBQWUsU0FBUyxRQUFRLFNBQVMsT0FBTyxXQUFXO0NBQzdEO0FBQ0Y7QUFDQSxNQUFNLG9CQUFvQjtBQUMxQixNQUFNLHFCQUFxQjtFQUN4QixJQUFlO0VBQ2YsSUFBbUI7RUFDbkIsSUFBZ0I7RUFDaEIsSUFBZ0I7RUFDaEIsSUFBb0I7QUFDdkI7QUFDQSxTQUFTLGtCQUFrQixJQUFJLGFBQWE7Q0FDMUMsSUFBSSxnQkFBZ0IsS0FBZ0IsZ0JBQWdCLEdBQWtCO0VBQ3BFLE9BQU8sTUFBTSxDQUFDLEdBQUcsYUFBYSxpQkFBaUIsR0FBRztHQUNoRCxLQUFLLEdBQUc7RUFDVjtDQUNGO0NBQ0EsT0FBTyx3QkFDTCxNQUFNLEdBQUcsYUFBYSxpQkFBaUIsR0FDdkMsV0FDRjtBQUNGO0FBQ0EsU0FBUyx3QkFBd0IsYUFBYSxhQUFhO0NBQ3pELElBQUksZUFBZSxNQUFNO0VBQ3ZCLE9BQU87Q0FDVCxPQUFPLElBQUksZ0JBQWdCLElBQUk7RUFDN0IsT0FBTztDQUNULE9BQU87RUFDTCxNQUFNLE9BQU8sWUFBWSxNQUFNLEdBQUc7RUFDbEMsSUFBSSxnQkFBZ0IsS0FBZ0IsS0FBSyxTQUFTLFVBQVUsR0FBRztHQUM3RCxPQUFPO0VBQ1Q7RUFDQSxPQUFPLEtBQUssU0FBUyxtQkFBbUIsWUFBWTtDQUN0RDtBQUNGO0FBQ0EsU0FBUyxzQkFBc0IsTUFBTSxPQUFPO0NBQzFDLE9BQU87RUFBa0IsS0FBSztFQUFlOztDQUFnQixLQUFLLHdCQUF3QixJQUFJLEtBQUsseUJBQXlCLEtBQUs7QUFDbkk7QUFDQSxTQUFTLHdCQUF3QixNQUFNO0NBQ3JDLE9BQU8sS0FBSyxhQUFhLEtBQUssd0JBQzVCLEtBQUssYUFBYSxpQkFBaUIsR0FDbkMsQ0FDRjtBQUNGO0FBQ0EsU0FBUyx5QkFBeUIsRUFBRSxTQUFTO0NBQzNDLE1BQU0sY0FBYyxTQUFTLE1BQU07Q0FDbkMsT0FBTyxPQUFPLGdCQUFnQixZQUFZO0VBQXdCO0VBQWE7O0NBQWdCO0FBQ2pHO0FBRUEsTUFBTSxzQkFBc0IsY0FBYyxDQUFDLENBQUMseUJBQXlCLE9BQU8sV0FBVyxJQUFJLENBQUM7QUFDNUYsTUFBTSxxQkFBcUIsY0FBYyxDQUFDLENBQUMsd0JBQXdCLE9BQU8sYUFBYSxFQUFFO0FBQ3pGLE1BQU0saUJBQWlCLFVBQVUsU0FBUyxZQUFZO0NBQ3BELE1BQU0sS0FBSyxvQkFBb0IsU0FBUyxFQUFFLFFBQVEsQ0FBQztDQUNuRCxhQUFhLG1CQUFtQixFQUFFO0FBQ3BDO0FBQ0EsU0FBUywyQkFBMkIsSUFBSTtDQUN0QyxNQUFNLEVBQUUsS0FBSyxNQUFNLFFBQVEsVUFBVSxHQUFHLHNCQUFzQjtDQUM5RCxNQUFNLEVBQUUsYUFBYSxlQUFlO0NBQ3BDLFFBQVEsTUFBTSxLQUFLLE1BQU0sZUFBZSxTQUFTLEtBQUssU0FBUyxpQkFBaUIsT0FBTyxLQUFLLE9BQU8sY0FBYyxRQUFRLEtBQUssUUFBUTtBQUN4STtBQUNBLE1BQU0sb0JBQW9CLFVBQVUsU0FBUyxZQUFZO0NBQ3ZELE1BQU0sS0FBSyxJQUFJLHNCQUFzQixZQUFZO0VBQy9DLEtBQUssTUFBTSxLQUFLLFNBQVM7R0FDdkIsSUFBSSxDQUFDLEVBQUUsZ0JBQWdCO0dBQ3ZCLEdBQUcsV0FBVztHQUNkLFFBQVE7R0FDUjtFQUNGO0NBQ0YsR0FBRyxJQUFJO0NBQ1AsU0FBUyxPQUFPO0VBQ2QsSUFBSSxFQUFFLGNBQWMsVUFBVTtFQUM5QixJQUFJLDJCQUEyQixFQUFFLEdBQUc7R0FDbEMsUUFBUTtHQUNSLEdBQUcsV0FBVztHQUNkLE9BQU87RUFDVDtFQUNBLEdBQUcsUUFBUSxFQUFFO0NBQ2YsQ0FBQztDQUNELGFBQWEsR0FBRyxXQUFXO0FBQzdCO0FBQ0EsTUFBTSx1QkFBdUIsV0FBVyxZQUFZO0NBQ2xELElBQUksT0FBTztFQUNULE1BQU0sTUFBTSxXQUFXLEtBQUs7RUFDNUIsSUFBSSxJQUFJLFNBQVM7R0FDZixRQUFRO0VBQ1YsT0FBTztHQUNMLElBQUksaUJBQWlCLFVBQVUsU0FBUyxFQUFFLE1BQU0sS0FBSyxDQUFDO0dBQ3RELGFBQWEsSUFBSSxvQkFBb0IsVUFBVSxPQUFPO0VBQ3hEO0NBQ0Y7QUFDRjtBQUNBLE1BQU0sd0JBQXdCLGVBQWUsQ0FBQyxPQUFPLFNBQVMsWUFBWTtDQUN4RSxJQUFJLFNBQVMsWUFBWSxHQUFHLGVBQWUsQ0FBQyxZQUFZO0NBQ3hELElBQUksY0FBYztDQUNsQixNQUFNLGFBQWEsTUFBTTtFQUN2QixJQUFJLENBQUMsYUFBYTtHQUNoQixjQUFjO0dBQ2QsU0FBUztHQUNULFFBQVE7R0FDUixFQUFFLE9BQU8sY0FBYyxJQUFJLEVBQUUsWUFBWSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0VBQ3JEO0NBQ0Y7Q0FDQSxNQUFNLGlCQUFpQjtFQUNyQixTQUFTLE9BQU87R0FDZCxLQUFLLE1BQU0sS0FBSyxjQUFjO0lBQzVCLEdBQUcsb0JBQW9CLEdBQUcsU0FBUztHQUNyQztFQUNGLENBQUM7Q0FDSDtDQUNBLFNBQVMsT0FBTztFQUNkLEtBQUssTUFBTSxLQUFLLGNBQWM7R0FDNUIsR0FBRyxpQkFBaUIsR0FBRyxXQUFXLEVBQUUsTUFBTSxLQUFLLENBQUM7RUFDbEQ7Q0FDRixDQUFDO0NBQ0QsT0FBTztBQUNUO0FBQ0EsU0FBUyxlQUFlLE1BQU0sSUFBSTtDQUNoQyxJQUFJLFVBQVUsSUFBSSxLQUFLLEtBQUssU0FBUyxLQUFLO0VBQ3hDLElBQUksUUFBUTtFQUNaLElBQUksT0FBTyxLQUFLO0VBQ2hCLE9BQU8sTUFBTTtHQUNYLElBQUksS0FBSyxhQUFhLEdBQUc7SUFDdkIsTUFBTSxTQUFTLEdBQUcsSUFBSTtJQUN0QixJQUFJLFdBQVcsT0FBTztLQUNwQjtJQUNGO0dBQ0YsT0FBTyxJQUFJLFVBQVUsSUFBSSxHQUFHO0lBQzFCLElBQUksS0FBSyxTQUFTLEtBQUs7S0FDckIsSUFBSSxFQUFFLFVBQVUsR0FBRztJQUNyQixPQUFPLElBQUksS0FBSyxTQUFTLEtBQUs7S0FDNUI7SUFDRjtHQUNGO0dBQ0EsT0FBTyxLQUFLO0VBQ2Q7Q0FDRixPQUFPO0VBQ0wsR0FBRyxJQUFJO0NBQ1Q7QUFDRjtBQUVBLE1BQU0sa0JBQWtCLE1BQU0sQ0FBQyxDQUFDLEVBQUUsS0FBSzs7QUFFdkMsU0FBUyxxQkFBcUIsUUFBUTtDQUNwQyxJQUFJLFdBQVcsTUFBTSxHQUFHO0VBQ3RCLFNBQVMsRUFBRSxRQUFRLE9BQU87Q0FDNUI7Q0FDQSxNQUFNLEVBQ0osUUFDQSxrQkFDQSxnQkFDQSxRQUFRLEtBQ1IsU0FBUyxpQkFDVCxTQUVBLGNBQWMsTUFDZCxTQUFTLGdCQUNQO0NBQ0osSUFBSSxpQkFBaUI7Q0FDckIsSUFBSTtDQUNKLElBQUksVUFBVTtDQUNkLE1BQU0sY0FBYztFQUNsQjtFQUNBLGlCQUFpQjtFQUNqQixPQUFPLEtBQUs7Q0FDZDtDQUNBLE1BQU0sYUFBYTtFQUNqQixJQUFJO0VBQ0osT0FBTyxtQkFBbUIsY0FBYyxpQkFBaUIsT0FBTyxDQUFDLENBQUMsT0FBTyxRQUFRO0dBQy9FLE1BQU0sZUFBZSxRQUFRLE1BQU0sSUFBSSxNQUFNLE9BQU8sR0FBRyxDQUFDO0dBQ3hELElBQUksYUFBYTtJQUNmLE9BQU8sSUFBSSxTQUFTLFNBQVMsV0FBVztLQUN0QyxNQUFNLGtCQUFrQixRQUFRLE1BQU0sQ0FBQztLQUN2QyxNQUFNLGlCQUFpQixPQUFPLEdBQUc7S0FDakMsWUFBWSxLQUFLLFdBQVcsVUFBVSxVQUFVLENBQUM7SUFDbkQsQ0FBQztHQUNILE9BQU87SUFDTCxNQUFNO0dBQ1I7RUFDRixDQUFDLENBQUMsQ0FBQyxNQUFNLFNBQVM7R0FDaEIsSUFBSSxnQkFBZ0Isa0JBQWtCLGdCQUFnQjtJQUNwRCxPQUFPO0dBQ1Q7R0FDQSxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixDQUFDLE1BQU07SUFDdEQsT0FDRSwrR0FDRjtHQUNGO0dBQ0EsSUFBSSxTQUFTLEtBQUssY0FBYyxLQUFLLE9BQU8saUJBQWlCLFdBQVc7SUFDdEUsT0FBTyxLQUFLO0dBQ2Q7R0FDQSxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixRQUFRLENBQUMsU0FBUyxJQUFJLEtBQUssQ0FBQyxXQUFXLElBQUksR0FBRztJQUM3RixNQUFNLElBQUksTUFBTSx3Q0FBd0MsTUFBTTtHQUNoRTtHQUNBLGVBQWU7R0FDZixPQUFPO0VBQ1QsQ0FBQztDQUNIO0NBQ0EsT0FBTyxnQkFBZ0I7RUFDckIsTUFBTTtFQUNOLGVBQWU7RUFDZixlQUFlLElBQUksVUFBVSxTQUFTO0dBQ3BDLE1BQU0sZUFBZSxHQUFHO0dBQ3hCLElBQUksVUFBVTtHQUNkLENBQUMsU0FBUyxPQUFPLFNBQVMsS0FBSyxDQUFDLEdBQUUsQ0FBRSxXQUFXLFVBQVUsSUFBSTtHQUM3RCxNQUFNLHVCQUF1QjtJQUMzQixJQUFJLFNBQVM7S0FDWCxJQUFJLENBQUMsb0JBQTJCLGVBQWU7TUFDN0MsT0FDRSwwQ0FBMEMsaUJBQWlCLFlBQVksS0FBSyxhQUFhLE9BQU8sbURBQ2xHO0tBQ0Y7S0FDQTtJQUNGO0lBQ0EsSUFBSSxDQUFDLEdBQUcsY0FBYyxnQkFBZ0IsQ0FBQyxHQUFHLGFBQWE7SUFDdkQsUUFBUTtHQUNWO0dBQ0EsTUFBTSxZQUFZLHdCQUF3QjtJQUN4QyxNQUFNLFdBQVcsZ0JBQ2YsaUJBQ0MsT0FBTyxlQUFlLElBQUksRUFBRSxDQUMvQjtJQUNBLElBQUksVUFBVTtLQUNaLENBQUMsU0FBUyxRQUFRLFNBQVMsTUFBTSxDQUFDLEdBQUUsQ0FBRSxLQUFLLFFBQVE7SUFDckQ7R0FDRixJQUFJO0dBQ0osSUFBSSxjQUFjO0lBQ2hCLFVBQVU7R0FDWixPQUFPO0lBQ0wsS0FBSyxDQUFDLENBQUMsV0FBVyxDQUFDLFNBQVMsZUFBZSxVQUFVLENBQUM7R0FDeEQ7RUFDRjtFQUNBLElBQUksa0JBQWtCO0dBQ3BCLE9BQU87RUFDVDtFQUNBLFFBQVE7R0FDTixNQUFNLFdBQVc7R0FDakIsa0JBQWtCLFFBQVE7R0FDMUIsSUFBSSxjQUFjO0lBQ2hCLGFBQWEsZ0JBQWdCLGNBQWMsUUFBUTtHQUNyRDtHQUNBLE1BQU0sV0FBVyxRQUFRO0lBQ3ZCLGlCQUFpQjtJQUNqQixZQUNFLEtBQ0EsVUFDQSxJQUNBLENBQUMsY0FDSDtHQUNGO0dBQ0EsSUFBSSxlQUFlLFNBQVMsWUFBWSx1QkFBdUI7SUFDN0QsT0FBTyxLQUFLLENBQUMsQ0FBQyxNQUFNLFNBQVM7S0FDM0IsYUFBYSxnQkFBZ0IsTUFBTSxRQUFRO0lBQzdDLENBQUMsQ0FBQyxDQUFDLE9BQU8sUUFBUTtLQUNoQixRQUFRLEdBQUc7S0FDWCxhQUFhLGlCQUFpQixZQUFZLGdCQUFnQixFQUN4RCxPQUFPLElBQ1QsQ0FBQyxJQUFJO0lBQ1AsQ0FBQztHQUNIO0dBQ0EsTUFBTSxTQUFTLElBQUksS0FBSztHQUN4QixNQUFNLFFBQVEsSUFBSTtHQUNsQixNQUFNLFVBQVUsSUFBSSxDQUFDLENBQUMsS0FBSztHQUMzQixJQUFJO0dBQ0osSUFBSTtHQUNKLGtCQUFrQjtJQUNoQixJQUFJLGdCQUFnQixNQUFNLGFBQWEsWUFBWTtJQUNuRCxJQUFJLGNBQWMsTUFBTSxhQUFhLFVBQVU7R0FDakQsQ0FBQztHQUNELElBQUksT0FBTztJQUNULGFBQWEsaUJBQWlCO0tBQzVCLElBQUksU0FBUyxhQUFhO0tBQzFCLFFBQVEsUUFBUTtJQUNsQixHQUFHLEtBQUs7R0FDVjtHQUNBLElBQUksV0FBVyxNQUFNO0lBQ25CLGVBQWUsaUJBQWlCO0tBQzlCLElBQUksU0FBUyxhQUFhO0tBQzFCLElBQUksQ0FBQyxPQUFPLFNBQVMsQ0FBQyxNQUFNLE9BQU87TUFDakMsTUFBTSxNQUFNLElBQUksTUFDZCxtQ0FBbUMsUUFBUSxJQUM3QztNQUNBLFFBQVEsR0FBRztNQUNYLE1BQU0sUUFBUTtLQUNoQjtJQUNGLEdBQUcsT0FBTztHQUNaO0dBQ0EsS0FBSyxDQUFDLENBQUMsV0FBVztJQUNoQixJQUFJLFNBQVMsYUFBYTtJQUMxQixPQUFPLFFBQVE7SUFDZixJQUFJLFNBQVMsVUFBVSxZQUFZLFNBQVMsT0FBTyxLQUFLLEdBQUc7S0FDekQsU0FBUyxPQUFPLE9BQU87SUFDekI7R0FDRixDQUFDLENBQUMsQ0FBQyxPQUFPLFFBQVE7SUFDaEIsSUFBSSxTQUFTLGFBQWE7S0FDeEIsaUJBQWlCO0tBQ2pCO0lBQ0Y7SUFDQSxRQUFRLEdBQUc7SUFDWCxNQUFNLFFBQVE7R0FDaEIsQ0FBQztHQUNELGFBQWE7SUFDWCxJQUFJLE9BQU8sU0FBUyxjQUFjO0tBQ2hDLE9BQU8sZ0JBQWdCLGNBQWMsUUFBUTtJQUMvQyxPQUFPLElBQUksTUFBTSxTQUFTLGdCQUFnQjtLQUN4QyxPQUFPLFlBQVksZ0JBQWdCLEVBQ2pDLE9BQU8sTUFBTSxNQUNmLENBQUM7SUFDSCxPQUFPLElBQUksb0JBQW9CLENBQUMsUUFBUSxPQUFPO0tBQzdDLE9BQU8sZ0JBQ0wsa0JBQ0EsUUFDRjtJQUNGO0dBQ0Y7RUFDRjtDQUNGLENBQUM7QUFDSDtBQUNBLFNBQVMsZ0JBQWdCLE1BQU0sUUFBUTtDQUNyQyxNQUFNLEVBQUUsS0FBSyxNQUFNLE9BQU8sVUFBVSxPQUFPLE9BQU87Q0FDbEQsTUFBTSxRQUFRLFlBQVksTUFBTSxPQUFPLFFBQVE7Q0FDL0MsTUFBTSxNQUFNO0NBQ1osTUFBTSxLQUFLO0NBQ1gsT0FBTyxPQUFPLE1BQU07Q0FDcEIsT0FBTztBQUNUO0FBRUEsTUFBTSxlQUFlLFVBQVUsTUFBTSxLQUFLO0FBQzFDLE1BQU0sZ0JBQWdCO0NBQ3BCLE1BQU07Ozs7Q0FJTixlQUFlO0NBQ2YsT0FBTztFQUNMLFNBQVM7R0FBQztHQUFRO0dBQVE7RUFBSztFQUMvQixTQUFTO0dBQUM7R0FBUTtHQUFRO0VBQUs7RUFDL0IsS0FBSyxDQUFDLFFBQVEsTUFBTTtDQUN0QjtDQUNBLE1BQU0sT0FBTyxFQUFFLFNBQVM7RUFDdEIsTUFBTSxXQUFXLG1CQUFtQjtFQUNwQyxNQUFNLGdCQUFnQixTQUFTO0VBQy9CLElBQUksQ0FBQyxjQUFjLFVBQVU7R0FDM0IsYUFBYTtJQUNYLE1BQU0sV0FBVyxNQUFNLFdBQVcsTUFBTSxRQUFRO0lBQ2hELE9BQU8sWUFBWSxTQUFTLFdBQVcsSUFBSSxTQUFTLEtBQUs7R0FDM0Q7RUFDRjtFQUNBLE1BQU0sd0JBQXdCLElBQUksSUFBSTtFQUN0QyxNQUFNLHVCQUF1QixJQUFJLElBQUk7RUFDckMsSUFBSSxVQUFVO0VBQ2QsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsdUJBQXVCO0dBQ3RFLFNBQVMsWUFBWTtFQUN2QjtFQUNBLE1BQU0saUJBQWlCLFNBQVM7RUFDaEMsTUFBTSxFQUNKLFVBQVUsRUFDUixHQUFHLE9BQ0gsR0FBRyxNQUNILElBQUksVUFDSixHQUFHLEVBQUUsc0JBRUw7RUFDSixNQUFNLG1CQUFtQixjQUFjLEtBQUs7RUFDNUMsY0FBYyxZQUFZLE9BQU8sV0FBVyxRQUFRLFdBQVcsY0FBYztHQUMzRSxNQUFNLFlBQVksTUFBTTtHQUN4QixLQUFLLE9BQU8sV0FBVyxRQUFRLEdBQUcsY0FBYztHQUNoRCxNQUNFLFVBQVUsT0FDVixPQUNBLFdBQ0EsUUFDQSxXQUNBLGdCQUNBLFdBQ0EsTUFBTSxjQUNOLFNBQ0Y7R0FDQSw0QkFBNEI7SUFDMUIsVUFBVSxnQkFBZ0I7SUFDMUIsSUFBSSxVQUFVLEdBQUc7S0FDZixlQUFlLFVBQVUsQ0FBQztJQUM1QjtJQUNBLE1BQU0sWUFBWSxNQUFNLFNBQVMsTUFBTSxNQUFNO0lBQzdDLElBQUksV0FBVztLQUNiLGdCQUFnQixXQUFXLFVBQVUsUUFBUSxLQUFLO0lBQ3BEO0dBQ0YsR0FBRyxjQUFjO0dBQ2pCLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLHVCQUF1QjtJQUN0RSx1QkFBdUIsU0FBUztHQUNsQztFQUNGO0VBQ0EsY0FBYyxjQUFjLFVBQVU7R0FDcEMsTUFBTSxZQUFZLE1BQU07R0FDeEIsZ0JBQWdCLFVBQVUsQ0FBQztHQUMzQixnQkFBZ0IsVUFBVSxDQUFDO0dBQzNCLEtBQUssT0FBTyxrQkFBa0IsTUFBTSxHQUFHLGNBQWM7R0FDckQsNEJBQTRCO0lBQzFCLElBQUksVUFBVSxJQUFJO0tBQ2hCLGVBQWUsVUFBVSxFQUFFO0lBQzdCO0lBQ0EsTUFBTSxZQUFZLE1BQU0sU0FBUyxNQUFNLE1BQU07SUFDN0MsSUFBSSxXQUFXO0tBQ2IsZ0JBQWdCLFdBQVcsVUFBVSxRQUFRLEtBQUs7SUFDcEQ7SUFDQSxVQUFVLGdCQUFnQjtHQUM1QixHQUFHLGNBQWM7R0FDakIsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsdUJBQXVCO0lBQ3RFLHVCQUF1QixTQUFTO0dBQ2xDO0dBQ0EsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsTUFBTTtJQUNyRCxVQUFVLDhCQUE4QjtHQUMxQztFQUNGO0VBQ0EsU0FBUyxRQUFRLE9BQU87R0FDdEIsZUFBZSxLQUFLO0dBQ3BCLFNBQVMsT0FBTyxVQUFVLGdCQUFnQixJQUFJO0VBQ2hEO0VBQ0EsU0FBUyxXQUFXLFFBQVE7R0FDMUIsTUFBTSxTQUFTLE9BQU8sUUFBUTtJQUM1QixNQUFNLE9BQU8saUJBQ1gsZUFBZSxLQUFLLElBQUksTUFBTSxLQUFLLG1CQUFtQixDQUFDLElBQUksTUFBTSxJQUNuRTtJQUNBLElBQUksUUFBUSxDQUFDLE9BQU8sSUFBSSxHQUFHO0tBQ3pCLGdCQUFnQixHQUFHO0lBQ3JCO0dBQ0YsQ0FBQztFQUNIO0VBQ0EsU0FBUyxnQkFBZ0IsS0FBSztHQUM1QixNQUFNLFNBQVMsTUFBTSxJQUFJLEdBQUc7R0FDNUIsSUFBSSxXQUFXLENBQUMsV0FBVyxDQUFDLGdCQUFnQixRQUFRLE9BQU8sSUFBSTtJQUM3RCxRQUFRLE1BQU07R0FDaEIsT0FBTyxJQUFJLFNBQVM7SUFDbEIsZUFBZSxPQUFPO0dBQ3hCO0dBQ0EsTUFBTSxPQUFPLEdBQUc7R0FDaEIsS0FBSyxPQUFPLEdBQUc7RUFDakI7RUFDQTtTQUNRLENBQUMsTUFBTSxTQUFTLE1BQU0sT0FBTztJQUNsQyxDQUFDLFNBQVMsYUFBYTtJQUN0QixXQUFXLFlBQVksU0FBUyxRQUFRLFNBQVMsSUFBSSxDQUFDO0lBQ3RELFdBQVcsWUFBWSxTQUFTLENBQUMsUUFBUSxTQUFTLElBQUksQ0FBQztHQUN6RDs7R0FFQTtJQUFFLE9BQU87SUFBUSxNQUFNO0dBQUs7RUFDOUI7RUFDQSxJQUFJLGtCQUFrQjtFQUN0QixNQUFNLHFCQUFxQjtHQUN6QixJQUFJLG1CQUFtQixNQUFNO0lBQzNCLElBQUksV0FBVyxTQUFTLFFBQVEsSUFBSSxHQUFHO0tBQ3JDLDRCQUE0QjtNQUMxQixNQUFNLElBQUksaUJBQWlCLGNBQWMsU0FBUyxPQUFPLENBQUM7S0FDNUQsR0FBRyxTQUFTLFFBQVEsUUFBUTtJQUM5QixPQUFPO0tBQ0wsTUFBTSxJQUFJLGlCQUFpQixjQUFjLFNBQVMsT0FBTyxDQUFDO0lBQzVEO0dBQ0Y7RUFDRjtFQUNBLFVBQVUsWUFBWTtFQUN0QixVQUFVLFlBQVk7RUFDdEIsc0JBQXNCO0dBQ3BCLE1BQU0sU0FBUyxXQUFXO0lBQ3hCLE1BQU0sRUFBRSxTQUFTLGFBQWE7SUFDOUIsTUFBTSxRQUFRLGNBQWMsT0FBTztJQUNuQyxJQUFJLE9BQU8sU0FBUyxNQUFNLFFBQVEsT0FBTyxRQUFRLE1BQU0sS0FBSztLQUMxRCxlQUFlLEtBQUs7S0FDcEIsTUFBTSxLQUFLLE1BQU0sVUFBVTtLQUMzQixNQUFNLHNCQUFzQixJQUFJLFFBQVE7S0FDeEM7SUFDRjtJQUNBLFFBQVEsTUFBTTtHQUNoQixDQUFDO0VBQ0gsQ0FBQztFQUNELGFBQWE7R0FDWCxrQkFBa0I7R0FDbEIsSUFBSSxDQUFDLE1BQU0sU0FBUztJQUNsQixPQUFPLFVBQVU7R0FDbkI7R0FDQSxNQUFNLFdBQVcsTUFBTSxRQUFRO0dBQy9CLE1BQU0sV0FBVyxTQUFTO0dBQzFCLElBQUksU0FBUyxTQUFTLEdBQUc7SUFDdkIsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0tBQzdDLE9BQU8sdURBQXVEO0lBQ2hFO0lBQ0EsVUFBVTtJQUNWLE9BQU87R0FDVCxPQUFPLElBQUksQ0FBQyxRQUFRLFFBQVEsS0FBSyxFQUFFLFNBQVMsWUFBWSxNQUFNLEVBQUUsU0FBUyxZQUFZLE1BQU07SUFDekYsVUFBVTtJQUNWLE9BQU87R0FDVDtHQUNBLElBQUksUUFBUSxjQUFjLFFBQVE7R0FDbEMsSUFBSSxNQUFNLFNBQVMsU0FBUztJQUMxQixVQUFVO0lBQ1YsT0FBTztHQUNUO0dBQ0EsTUFBTSxPQUFPLE1BQU07R0FDbkIsTUFBTSxPQUFPLGlCQUNYLGVBQWUsS0FBSyxJQUFJLE1BQU0sS0FBSyxtQkFBbUIsQ0FBQyxJQUFJLElBQzdEO0dBQ0EsTUFBTSxFQUFFLFNBQVMsU0FBUyxRQUFRO0dBQ2xDLElBQUksWUFBWSxDQUFDLFFBQVEsQ0FBQyxRQUFRLFNBQVMsSUFBSSxNQUFNLFdBQVcsUUFBUSxRQUFRLFNBQVMsSUFBSSxHQUFHO0lBQzlGLE1BQU0sYUFBYSxDQUFDO0lBQ3BCLFVBQVU7SUFDVixPQUFPO0dBQ1Q7R0FDQSxNQUFNLE1BQU0sTUFBTSxPQUFPLE9BQU8sT0FBTyxNQUFNO0dBQzdDLE1BQU0sY0FBYyxNQUFNLElBQUksR0FBRztHQUNqQyxJQUFJLE1BQU0sSUFBSTtJQUNaLFFBQVEsV0FBVyxLQUFLO0lBQ3hCLElBQUksU0FBUyxZQUFZLEtBQUs7S0FDNUIsU0FBUyxZQUFZO0lBQ3ZCO0dBQ0Y7R0FDQSxrQkFBa0I7R0FDbEIsSUFBSSxhQUFhO0lBQ2YsTUFBTSxLQUFLLFlBQVk7SUFDdkIsTUFBTSxZQUFZLFlBQVk7SUFDOUIsSUFBSSxNQUFNLFlBQVk7S0FDcEIsbUJBQW1CLE9BQU8sTUFBTSxVQUFVO0lBQzVDO0lBQ0EsTUFBTSxhQUFhO0lBQ25CLEtBQUssT0FBTyxHQUFHO0lBQ2YsS0FBSyxJQUFJLEdBQUc7R0FDZCxPQUFPO0lBQ0wsS0FBSyxJQUFJLEdBQUc7SUFDWixJQUFJLE9BQU8sS0FBSyxPQUFPLFNBQVMsS0FBSyxFQUFFLEdBQUc7S0FDeEMsZ0JBQWdCLEtBQUssT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSztJQUM1QztHQUNGO0dBQ0EsTUFBTSxhQUFhO0dBQ25CLFVBQVU7R0FDVixPQUFPLFdBQVcsU0FBUyxJQUFJLElBQUksV0FBVztFQUNoRDtDQUNGO0FBQ0Y7QUFDQSxNQUFNLFlBQVk7QUFDbEIsU0FBUyxRQUFRLFNBQVMsTUFBTTtDQUM5QixJQUFJLFFBQVEsT0FBTyxHQUFHO0VBQ3BCLE9BQU8sUUFBUSxNQUFNLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQztDQUM3QyxPQUFPLElBQUksU0FBUyxPQUFPLEdBQUc7RUFDNUIsT0FBTyxRQUFRLE1BQU0sR0FBRyxDQUFDLENBQUMsU0FBUyxJQUFJO0NBQ3pDLE9BQU8sSUFBSSxTQUFTLE9BQU8sR0FBRztFQUM1QixRQUFRLFlBQVk7RUFDcEIsT0FBTyxRQUFRLEtBQUssSUFBSTtDQUMxQjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsWUFBWSxNQUFNLFFBQVE7Q0FDakMsc0JBQXNCLE1BQU0sS0FBSyxNQUFNO0FBQ3pDO0FBQ0EsU0FBUyxjQUFjLE1BQU0sUUFBUTtDQUNuQyxzQkFBc0IsTUFBTSxNQUFNLE1BQU07QUFDMUM7QUFDQSxTQUFTLHNCQUFzQixNQUFNLE1BQU0sU0FBUyxpQkFBaUI7Q0FDbkUsTUFBTSxjQUFjLEtBQUssVUFBVSxLQUFLLGNBQWM7RUFDcEQsSUFBSSxVQUFVO0VBQ2QsT0FBTyxTQUFTO0dBQ2QsSUFBSSxRQUFRLGVBQWU7SUFDekI7R0FDRjtHQUNBLFVBQVUsUUFBUTtFQUNwQjtFQUNBLE9BQU8sS0FBSztDQUNkO0NBQ0EsV0FBVyxNQUFNLGFBQWEsTUFBTTtDQUNwQyxJQUFJLFFBQVE7RUFDVixJQUFJLFVBQVUsT0FBTztFQUNyQixPQUFPLFdBQVcsUUFBUSxRQUFRO0dBQ2hDLElBQUksWUFBWSxRQUFRLE9BQU8sS0FBSyxHQUFHO0lBQ3JDLHNCQUFzQixhQUFhLE1BQU0sUUFBUSxPQUFPO0dBQzFEO0dBQ0EsVUFBVSxRQUFRO0VBQ3BCO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsc0JBQXNCLE1BQU0sTUFBTSxRQUFRLGVBQWU7Q0FDaEUsTUFBTSxXQUFXO0VBQ2Y7RUFDQTtFQUNBO0VBQ0E7O0NBRUY7Q0FDQSxrQkFBa0I7RUFDaEIsT0FBTyxjQUFjLE9BQU8sUUFBUTtDQUN0QyxHQUFHLE1BQU07QUFDWDtBQUNBLFNBQVMsZUFBZSxPQUFPO0NBQzdCLE1BQU0sYUFBYSxDQUFDO0NBQ3BCLE1BQU0sYUFBYSxDQUFDO0FBQ3RCO0FBQ0EsU0FBUyxjQUFjLE9BQU87Q0FDNUIsT0FBTyxNQUFNLFlBQVksTUFBTSxNQUFNLFlBQVk7QUFDbkQ7QUFFQSxTQUFTLFdBQVcsTUFBTSxNQUFNLFNBQVMsaUJBQWlCLFVBQVUsT0FBTztDQUN6RSxJQUFJLFFBQVE7RUFDVixNQUFNLFFBQVEsT0FBTyxVQUFVLE9BQU8sUUFBUSxDQUFDO0VBQy9DLE1BQU0sY0FBYyxLQUFLLFVBQVUsS0FBSyxTQUFTLEdBQUcsU0FBUztHQUMzRCxjQUFjO0dBQ2QsTUFBTSxRQUFRLG1CQUFtQixNQUFNO0dBQ3ZDLE1BQU0sTUFBTSwyQkFBMkIsTUFBTSxRQUFRLE1BQU0sSUFBSTtHQUMvRCxNQUFNO0dBQ04sY0FBYztHQUNkLE9BQU87RUFDVDtFQUNBLElBQUksU0FBUztHQUNYLE1BQU0sUUFBUSxXQUFXO0VBQzNCLE9BQU87R0FDTCxNQUFNLEtBQUssV0FBVztFQUN4QjtFQUNBLE9BQU87Q0FDVCxPQUFPLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtFQUNwRCxNQUFNLFVBQVUsYUFBYSxtQkFBbUIsS0FBSyxDQUFDLFFBQVEsVUFBVSxFQUFFLENBQUM7RUFDM0UsT0FDRSxHQUFHLFFBQVEsdUpBQXdKLDBHQUNySztDQUNGO0FBQ0Y7QUFDQSxNQUFNLGNBQWMsZUFBZSxNQUFNLFNBQVMsb0JBQW9CO0NBQ3BFLElBQUksQ0FBQyx5QkFBeUIsY0FBYyxNQUFNO0VBQ2hELFdBQVcsWUFBWSxHQUFHLFNBQVMsS0FBSyxHQUFHLElBQUksR0FBRyxNQUFNO0NBQzFEO0FBQ0Y7QUFDQSxNQUFNLGdCQUFnQixXQUFXLElBQUk7QUFDckMsTUFBTSxZQUFZLFdBQVcsR0FBRztBQUNoQyxNQUFNLGlCQUFpQixXQUNyQixJQUNGO0FBQ0EsTUFBTSxZQUFZLFdBQVcsR0FBRztBQUNoQyxNQUFNLGtCQUFrQixXQUN0QixLQUNGO0FBQ0EsTUFBTSxjQUFjLFdBQVcsSUFBSTtBQUNuQyxNQUFNLG1CQUFtQixXQUN2QixJQUNGO0FBQ0EsTUFBTSxvQkFBb0IsV0FBVyxLQUFLO0FBQzFDLE1BQU0sa0JBQWtCLFdBQVcsS0FBSztBQUN4QyxTQUFTLGdCQUFnQixNQUFNLFNBQVMsaUJBQWlCO0NBQ3ZELFdBQVcsTUFBTSxNQUFNLE1BQU07QUFDL0I7QUFFQSxNQUFNLGFBQWE7QUFDbkIsTUFBTSxhQUFhO0FBQ25CLFNBQVMsaUJBQWlCLE1BQU0sb0JBQW9CO0NBQ2xELE9BQU8sYUFBYSxZQUFZLE1BQU0sTUFBTSxrQkFBa0IsS0FBSztBQUNyRTtBQUNBLE1BQU0seUJBQXlDLHVCQUFPLElBQUksT0FBTztBQUNqRSxTQUFTLHdCQUF3QixXQUFXO0NBQzFDLElBQUksU0FBUyxTQUFTLEdBQUc7RUFDdkIsT0FBTyxhQUFhLFlBQVksV0FBVyxLQUFLLEtBQUs7Q0FDdkQsT0FBTztFQUNMLE9BQU8sYUFBYTtDQUN0QjtBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsTUFBTTtDQUM5QixPQUFPLGFBQWEsWUFBWSxJQUFJO0FBQ3RDO0FBQ0EsU0FBUyxhQUFhLE1BQU0sTUFBTSxjQUFjLE1BQU0scUJBQXFCLE9BQU87Q0FDaEYsTUFBTSxXQUFXLDRCQUE0QjtDQUM3QyxJQUFJLFVBQVU7RUFDWixNQUFNLFlBQVksU0FBUztFQUMzQixJQUFJLFNBQVMsWUFBWTtHQUN2QixNQUFNLFdBQVcsaUJBQ2YsV0FDQSxLQUNGO0dBQ0EsSUFBSSxhQUFhLGFBQWEsUUFBUSxhQUFhLFNBQVMsSUFBSSxLQUFLLGFBQWEsV0FBVyxTQUFTLElBQUksQ0FBQyxJQUFJO0lBQzdHLE9BQU87R0FDVDtFQUNGO0VBQ0EsTUFBTSxNQUdKLFFBQVEsU0FBUyxTQUFTLFVBQVUsT0FBTyxJQUFJLEtBQy9DLFFBQVEsU0FBUyxXQUFXLE9BQU8sSUFBSTtFQUV6QyxJQUFJLENBQUMsT0FBTyxvQkFBb0I7R0FDOUIsT0FBTztFQUNUO0VBQ0EsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsZUFBZSxDQUFDLEtBQUs7R0FDcEUsTUFBTSxRQUFRLFNBQVMsYUFBYTs4SEFDb0Y7R0FDeEgsT0FBTyxxQkFBcUIsS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxPQUFPLE9BQU87RUFDbEU7RUFDQSxPQUFPO0NBQ1QsT0FBTyxJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDcEQsT0FDRSxVQUFVLFdBQVcsS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSwwQ0FDMUM7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxRQUFRLFVBQVUsTUFBTTtDQUMvQixPQUFPLGFBQWEsU0FBUyxTQUFTLFNBQVMsU0FBUyxJQUFJLE1BQU0sU0FBUyxXQUFXLFNBQVMsSUFBSSxDQUFDO0FBQ3RHO0FBRUEsU0FBUyxXQUFXLFFBQVEsWUFBWSxPQUFPLE9BQU87Q0FDcEQsSUFBSTtDQUNKLE1BQU0sU0FBUyxTQUFTLE1BQU07Q0FDOUIsTUFBTSxnQkFBZ0IsUUFBUSxNQUFNO0NBQ3BDLElBQUksaUJBQWlCLFNBQVMsTUFBTSxHQUFHO0VBQ3JDLE1BQU0sd0JBQXdCLGlCQUFpQixXQUFXLE1BQU07RUFDaEUsSUFBSSxZQUFZO0VBQ2hCLElBQUksbUJBQW1CO0VBQ3ZCLElBQUksdUJBQXVCO0dBQ3pCLFlBQVksQ0FBQyxVQUFVLE1BQU07R0FDN0IsbUJBQW1CLFdBQVcsTUFBTTtHQUNwQyxTQUFTLGlCQUFpQixNQUFNO0VBQ2xDO0VBQ0EsTUFBTSxJQUFJLE1BQU0sT0FBTyxNQUFNO0VBQzdCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsSUFBSSxHQUFHLEtBQUs7R0FDN0MsSUFBSSxLQUFLLFdBQ1AsWUFBWSxtQkFBbUIsV0FBVyxXQUFXLE9BQU8sRUFBRSxDQUFDLElBQUksV0FBVyxPQUFPLEVBQUUsSUFBSSxPQUFPLElBQ2xHLEdBQ0EsS0FBSyxHQUNMLFVBQVUsT0FBTyxFQUNuQjtFQUNGO0NBQ0YsT0FBTyxJQUFJLE9BQU8sV0FBVyxVQUFVO0VBQ3JDLElBQUksQ0FBQyxvQkFBMkIsa0JBQWtCLENBQUMsT0FBTyxVQUFVLE1BQU0sS0FBSyxTQUFTLElBQUk7R0FDMUYsT0FDRSw0REFBNEQsT0FBTyxFQUNyRTtHQUNBLE1BQU0sQ0FBQztFQUNULE9BQU87R0FDTCxNQUFNLElBQUksTUFBTSxNQUFNO0dBQ3RCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLEtBQUs7SUFDL0IsSUFBSSxLQUFLLFdBQVcsSUFBSSxHQUFHLEdBQUcsS0FBSyxHQUFHLFVBQVUsT0FBTyxFQUFFO0dBQzNEO0VBQ0Y7Q0FDRixPQUFPLElBQUksU0FBUyxNQUFNLEdBQUc7RUFDM0IsSUFBSSxPQUFPLE9BQU8sV0FBVztHQUMzQixNQUFNLE1BQU0sS0FDVixTQUNDLE1BQU0sTUFBTSxXQUFXLE1BQU0sR0FBRyxLQUFLLEdBQUcsVUFBVSxPQUFPLEVBQUUsQ0FDOUQ7RUFDRixPQUFPO0dBQ0wsTUFBTSxPQUFPLE9BQU8sS0FBSyxNQUFNO0dBQy9CLE1BQU0sSUFBSSxNQUFNLEtBQUssTUFBTTtHQUMzQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLElBQUksR0FBRyxLQUFLO0lBQzNDLE1BQU0sTUFBTSxLQUFLO0lBQ2pCLElBQUksS0FBSyxXQUFXLE9BQU8sTUFBTSxLQUFLLEdBQUcsVUFBVSxPQUFPLEVBQUU7R0FDOUQ7RUFDRjtDQUNGLE9BQU87RUFDTCxNQUFNLENBQUM7Q0FDVDtDQUNBLElBQUksT0FBTztFQUNULE1BQU0sU0FBUztDQUNqQjtDQUNBLE9BQU87QUFDVDtBQUVBLFNBQVMsWUFBWSxPQUFPLGNBQWM7Q0FDeEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGFBQWEsUUFBUSxLQUFLO0VBQzVDLE1BQU0sT0FBTyxhQUFhO0VBQzFCLElBQUksUUFBUSxJQUFJLEdBQUc7R0FDakIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLO0lBQ3BDLE1BQU0sS0FBSyxFQUFFLENBQUMsUUFBUSxLQUFLLEVBQUUsQ0FBQztHQUNoQztFQUNGLE9BQU8sSUFBSSxNQUFNO0dBQ2YsTUFBTSxLQUFLLFFBQVEsS0FBSyxPQUFPLEdBQUcsU0FBUztJQUN6QyxNQUFNLE1BQU0sS0FBSyxHQUFHLEdBQUcsSUFBSTtJQUMzQixJQUFJLEtBQUssSUFBSSxNQUFNLEtBQUs7SUFDeEIsT0FBTztHQUNULElBQUksS0FBSztFQUNYO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFFQSxTQUFTLFdBQVcsT0FBTyxNQUFNLFFBQVEsQ0FBQyxHQUFHLFVBQVUsV0FBVyxXQUFXO0NBQzNFLElBQUkseUJBQXlCLE1BQU0seUJBQXlCLFVBQVUsZUFBZSx5QkFBeUIsTUFBTSxLQUFLLHlCQUF5QixPQUFPLElBQUk7RUFDM0osTUFBTSxZQUFZLGFBQWEsUUFBUSxNQUFNLE9BQU8sT0FBTyxPQUFPLENBQUMsR0FBRyxPQUFPLEVBQUUsS0FBSyxVQUFVLENBQUMsSUFBSTtFQUNuRyxNQUFNLFdBQVcsT0FBTyxLQUFLLFNBQVMsQ0FBQyxDQUFDLFNBQVM7RUFDakQsSUFBSSxTQUFTLFdBQVcsVUFBVSxPQUFPO0VBQ3pDLE9BQU8sVUFBVSxHQUFHLFlBQ2xCLFVBQ0EsTUFDQSxDQUFDLFlBQVksUUFBUSxXQUFXLFlBQVksU0FBUyxDQUFDLENBQUMsR0FDdkQsV0FBVyxDQUFDLElBQUksRUFDbEI7Q0FDRjtDQUNBLElBQUksT0FBTyxNQUFNO0NBQ2pCLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLFFBQVEsS0FBSyxTQUFTLEdBQUc7RUFDeEUsT0FDRSwwSkFDRjtFQUNBLGFBQWEsQ0FBQztDQUNoQjtDQUNBLElBQUksUUFBUSxLQUFLLElBQUk7RUFDbkIsS0FBSyxLQUFLO0NBQ1o7Q0FDQSxNQUFNLGdCQUFnQixXQUFXO0NBQ2pDLFVBQVU7Q0FDVixJQUFJO0NBQ0osSUFBSTtFQUNGLE1BQU0sbUJBQW1CLFFBQVEsaUJBQWlCLEtBQUssS0FBSyxDQUFDO0VBQzdELE1BQU0sVUFBVSxNQUFNLE9BQU8sYUFFN0Isb0JBQW9CLGlCQUFpQjtFQUNyQyxXQUFXLFlBQ1QsVUFDQSxFQUNFLE1BQU0sV0FBVyxDQUFDLFNBQVMsT0FBTyxJQUFJLFVBQVUsSUFBSSxXQUNuRCxDQUFDLG9CQUFvQixXQUFXLFFBQVEsSUFDM0MsR0FDQSxxQkFBcUIsV0FBVyxTQUFTLElBQUksQ0FBQyxJQUM5QyxvQkFBb0IsTUFBTSxNQUFNLElBQUksS0FBSyxDQUFDLENBQzVDO0NBQ0YsU0FBUyxLQUFLO0VBQ1osS0FBSyxJQUFJLElBQUksV0FBVyxRQUFRLElBQUksZUFBZSxLQUFLLFdBQVc7RUFDbkUsTUFBTTtDQUNSLFVBQVU7RUFDUixJQUFJLFFBQVEsS0FBSyxJQUFJO0dBQ25CLEtBQUssS0FBSztFQUNaO0NBQ0Y7Q0FDQSxJQUFJLENBQUMsYUFBYSxTQUFTLFNBQVM7RUFDbEMsU0FBUyxlQUFlLENBQUMsU0FBUyxVQUFVLElBQUk7Q0FDbEQ7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGlCQUFpQixRQUFRO0NBQ2hDLE9BQU8sT0FBTyxNQUFNLFVBQVU7RUFDNUIsSUFBSSxDQUFDLFFBQVEsS0FBSyxHQUFHLE9BQU87RUFDNUIsSUFBSSxNQUFNLFNBQVMsU0FBUyxPQUFPO0VBQ25DLElBQUksTUFBTSxTQUFTLFlBQVksQ0FBQyxpQkFBaUIsTUFBTSxRQUFRLEdBQzdELE9BQU87RUFDVCxPQUFPO0NBQ1QsQ0FBQyxJQUFJLFNBQVM7QUFDaEI7QUFFQSxTQUFTLFdBQVcsS0FBSyx5QkFBeUI7Q0FDaEQsTUFBTSxNQUFNLENBQUM7Q0FDYixJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixDQUFDLFNBQVMsR0FBRyxHQUFHO0VBQy9ELE9BQU8sZ0RBQWdEO0VBQ3ZELE9BQU87Q0FDVDtDQUNBLEtBQUssTUFBTSxPQUFPLEtBQUs7RUFDckIsSUFBSSwyQkFBMkIsUUFBUSxLQUFLLEdBQUcsSUFBSSxNQUFNLFFBQVEsYUFBYSxHQUFHLEtBQUssSUFBSTtDQUM1RjtDQUNBLE9BQU87QUFDVDtBQUVBLE1BQU0scUJBQXFCLE1BQU07Q0FDL0IsSUFBSSxDQUFDLEdBQUcsT0FBTztDQUNmLElBQUksb0JBQW9CLENBQUMsR0FBRyxPQUFPLDJCQUEyQixDQUFDO0NBQy9ELE9BQU8sa0JBQWtCLEVBQUUsTUFBTTtBQUNuQztBQUNBLE1BQU0sc0JBR1ksdUJBQXVCLHVCQUFPLE9BQU8sSUFBSSxHQUFHO0NBQzFELElBQUksTUFBTTtDQUNWLE1BQU0sTUFBTSxFQUFFLE1BQU07Q0FDcEIsUUFBUSxNQUFNLEVBQUU7Q0FDaEIsU0FBUyxNQUFNLENBQUMsb0JBQTJCLGdCQUFnQixnQkFBZ0IsRUFBRSxLQUFLLElBQUksRUFBRTtDQUN4RixTQUFTLE1BQU0sQ0FBQyxvQkFBMkIsZ0JBQWdCLGdCQUFnQixFQUFFLEtBQUssSUFBSSxFQUFFO0NBQ3hGLFNBQVMsTUFBTSxDQUFDLG9CQUEyQixnQkFBZ0IsZ0JBQWdCLEVBQUUsS0FBSyxJQUFJLEVBQUU7Q0FDeEYsUUFBUSxNQUFNLENBQUMsb0JBQTJCLGdCQUFnQixnQkFBZ0IsRUFBRSxJQUFJLElBQUksRUFBRTtDQUN0RixVQUFVLE1BQU0sa0JBQWtCLEVBQUUsTUFBTTtDQUMxQyxRQUFRLE1BQU0sa0JBQWtCLEVBQUUsSUFBSTtDQUN0QyxRQUFRLE1BQU0sRUFBRTtDQUNoQixRQUFRLE1BQU0sRUFBRTtDQUNoQixXQUFXLE1BQU0sc0JBQXNCLHFCQUFxQixDQUFDLElBQUksRUFBRTtDQUNuRSxlQUFlLE1BQU0sRUFBRSxNQUFNLEVBQUUsVUFBVTtFQUN2QyxTQUFTLEVBQUUsTUFBTTtDQUNuQjtDQUNBLFlBQVksTUFBTSxFQUFFLE1BQU0sRUFBRSxJQUFJLFNBQVMsS0FBSyxFQUFFLEtBQUs7Q0FDckQsU0FBUyxNQUFNLHNCQUFzQixjQUFjLEtBQUssQ0FBQyxJQUFJO0FBQy9ELENBQUM7QUFFSCxNQUFNLG9CQUFvQixRQUFRLFFBQVEsT0FBTyxRQUFRO0FBQ3pELE1BQU0sbUJBQW1CLE9BQU8sUUFBUSxVQUFVLGFBQWEsQ0FBQyxNQUFNLG1CQUFtQixPQUFPLE9BQU8sR0FBRztBQUMxRyxNQUFNLDhCQUE4QjtDQUNsQyxJQUFJLEVBQUUsR0FBRyxZQUFZLEtBQUs7RUFDeEIsSUFBSSxRQUFRLFlBQVk7R0FDdEIsT0FBTztFQUNUO0VBQ0EsTUFBTSxFQUFFLEtBQUssWUFBWSxNQUFNLE9BQU8sYUFBYSxNQUFNLGVBQWU7RUFDeEUsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsUUFBUSxXQUFXO0dBQ2xFLE9BQU87RUFDVDtFQUNBLElBQUksSUFBSSxPQUFPLEtBQUs7R0FDbEIsTUFBTSxJQUFJLFlBQVk7R0FDdEIsSUFBSSxNQUFNLEtBQUssR0FBRztJQUNoQixRQUFRLEdBQVI7S0FDRSxLQUFLLEdBQ0gsT0FBTyxXQUFXO0tBQ3BCLEtBQUssR0FDSCxPQUFPLEtBQUs7S0FDZCxLQUFLLEdBQ0gsT0FBTyxJQUFJO0tBQ2IsS0FBSyxHQUNILE9BQU8sTUFBTTtJQUNqQjtHQUNGLE9BQU8sSUFBSSxnQkFBZ0IsWUFBWSxHQUFHLEdBQUc7SUFDM0MsWUFBWSxPQUFPO0lBQ25CLE9BQU8sV0FBVztHQUNwQixPQUFPLElBQUksdUJBQXVCLFNBQVMsYUFBYSxPQUFPLE1BQU0sR0FBRyxHQUFHO0lBQ3pFLFlBQVksT0FBTztJQUNuQixPQUFPLEtBQUs7R0FDZCxPQUFPLElBQUksT0FBTyxPQUFPLEdBQUcsR0FBRztJQUM3QixZQUFZLE9BQU87SUFDbkIsT0FBTyxNQUFNO0dBQ2YsT0FBTyxJQUFJLFFBQVEsYUFBYSxPQUFPLEtBQUssR0FBRyxHQUFHO0lBQ2hELFlBQVksT0FBTztJQUNuQixPQUFPLElBQUk7R0FDYixPQUFPLElBQUksQ0FBQyx1QkFBdUIsbUJBQW1CO0lBQ3BELFlBQVksT0FBTztHQUNyQjtFQUNGO0VBQ0EsTUFBTSxlQUFlLG9CQUFvQjtFQUN6QyxJQUFJLFdBQVc7RUFDZixJQUFJLGNBQWM7R0FDaEIsSUFBSSxRQUFRLFVBQVU7SUFDcEIsTUFBTSxTQUFTLE9BQU8sT0FBTyxFQUFFO0lBQy9CLENBQUMsb0JBQTJCLGlCQUFpQixrQkFBa0I7R0FDakUsT0FBTyxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixRQUFRLFVBQVU7SUFDeEUsTUFBTSxVQUFVLE9BQU8sR0FBRztHQUM1QjtHQUNBLE9BQU8sYUFBYSxRQUFRO0VBQzlCLE9BQU8sS0FFSixZQUFZLEtBQUssa0JBQWtCLFlBQVksVUFBVSxPQUMxRDtHQUNBLE9BQU87RUFDVCxPQUFPLElBQUksUUFBUSxhQUFhLE9BQU8sS0FBSyxHQUFHLEdBQUc7R0FDaEQsWUFBWSxPQUFPO0dBQ25CLE9BQU8sSUFBSTtFQUNiLE9BQU8sSUFFTCxtQkFBbUIsV0FBVyxPQUFPLGtCQUFrQixPQUFPLGtCQUFrQixHQUFHLEdBQ25GO0dBQ0E7SUFDRSxPQUFPLGlCQUFpQjtHQUMxQjtFQUNGLE9BQU8sSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsNkJBQTZCLENBQUMsU0FBUyxHQUFHLEtBRWxHLElBQUksUUFBUSxLQUFLLE1BQU0sSUFBSTtHQUN6QixJQUFJLFNBQVMsYUFBYSxpQkFBaUIsSUFBSSxFQUFFLEtBQUssT0FBTyxNQUFNLEdBQUcsR0FBRztJQUN2RSxPQUNFLFlBQVksS0FBSyxVQUNmLEdBQ0YsRUFBRSwrSEFDSjtHQUNGLE9BQU8sSUFBSSxhQUFhLDBCQUEwQjtJQUNoRCxPQUNFLFlBQVksS0FBSyxVQUFVLEdBQUcsRUFBRSw0REFDbEM7R0FDRjtFQUNGO0NBQ0Y7Q0FDQSxJQUFJLEVBQUUsR0FBRyxZQUFZLEtBQUssT0FBTztFQUMvQixNQUFNLEVBQUUsTUFBTSxZQUFZLFFBQVE7RUFDbEMsSUFBSSxnQkFBZ0IsWUFBWSxHQUFHLEdBQUc7R0FDcEMsV0FBVyxPQUFPO0dBQ2xCLE9BQU87RUFDVCxPQUFPLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLFdBQVcsbUJBQW1CLE9BQU8sWUFBWSxHQUFHLEdBQUc7R0FDN0csT0FBTyx5Q0FBeUMsSUFBSSxvQkFBb0I7R0FDeEUsT0FBTztFQUNULE9BQU8sSUFBSSx1QkFBdUIsU0FBUyxhQUFhLE9BQU8sTUFBTSxHQUFHLEdBQUc7R0FDekUsS0FBSyxPQUFPO0dBQ1osT0FBTztFQUNULE9BQU8sSUFBSSxPQUFPLFNBQVMsT0FBTyxHQUFHLEdBQUc7R0FDdEMsQ0FBQyxvQkFBMkIsaUJBQWlCLE9BQU8sOEJBQThCLElBQUksdUJBQXVCO0dBQzdHLE9BQU87RUFDVDtFQUNBLElBQUksSUFBSSxPQUFPLE9BQU8sSUFBSSxNQUFNLENBQUMsS0FBSyxVQUFVO0dBQzlDLENBQUMsb0JBQTJCLGlCQUFpQixPQUMzQyx5Q0FBeUMsSUFBSSx5REFDL0M7R0FDQSxPQUFPO0VBQ1QsT0FBTztHQUNMLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLE9BQU8sU0FBUyxXQUFXLE9BQU8sa0JBQWtCO0lBQ25HLE9BQU8sZUFBZSxLQUFLLEtBQUs7S0FDOUIsWUFBWTtLQUNaLGNBQWM7S0FDZDtJQUNGLENBQUM7R0FDSCxPQUFPO0lBQ0wsSUFBSSxPQUFPO0dBQ2I7RUFDRjtFQUNBLE9BQU87Q0FDVDtDQUNBLElBQUksRUFDRixHQUFHLEVBQUUsTUFBTSxZQUFZLGFBQWEsS0FBSyxZQUFZLE9BQU8sVUFDM0QsS0FBSztFQUNOLElBQUk7RUFDSixPQUFPLENBQUMsRUFBRSxZQUFZLFFBQVEsdUJBQXVCLFNBQVMsYUFBYSxJQUFJLE9BQU8sT0FBTyxPQUFPLE1BQU0sR0FBRyxLQUFLLGdCQUFnQixZQUFZLEdBQUcsS0FBSyxPQUFPLE9BQU8sR0FBRyxLQUFLLE9BQU8sS0FBSyxHQUFHLEtBQUssT0FBTyxxQkFBcUIsR0FBRyxLQUFLLE9BQU8sV0FBVyxPQUFPLGtCQUFrQixHQUFHLE1BQU0sYUFBYSxLQUFLLGlCQUFpQixXQUFXO0NBQ3hVO0NBQ0EsZUFBZSxRQUFRLEtBQUssWUFBWTtFQUN0QyxJQUFJLFdBQVcsT0FBTyxNQUFNO0dBQzFCLE9BQU8sRUFBRSxZQUFZLE9BQU87RUFDOUIsT0FBTyxJQUFJLE9BQU8sWUFBWSxPQUFPLEdBQUc7R0FDdEMsS0FBSyxJQUFJLFFBQVEsS0FBSyxXQUFXLE9BQU8sSUFBSTtFQUM5QztFQUNBLE9BQU8sUUFBUSxlQUFlLFFBQVEsS0FBSyxVQUFVO0NBQ3ZEO0FBQ0Y7QUFDQSxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixNQUFNO0NBQ3JELDRCQUE0QixXQUFXLFdBQVc7RUFDaEQsT0FDRSxtSkFDRjtFQUNBLE9BQU8sUUFBUSxRQUFRLE1BQU07Q0FDL0I7QUFDRjtBQUNBLE1BQU0sNkNBQTZELHVCQUFPLENBQUMsR0FBRyw2QkFBNkI7Q0FDekcsSUFBSSxRQUFRLEtBQUs7RUFDZixJQUFJLFFBQVEsT0FBTyxhQUFhO0dBQzlCO0VBQ0Y7RUFDQSxPQUFPLDRCQUE0QixJQUFJLFFBQVEsS0FBSyxNQUFNO0NBQzVEO0NBQ0EsSUFBSSxHQUFHLEtBQUs7RUFDVixNQUFNLE1BQU0sSUFBSSxPQUFPLE9BQU8sQ0FBQyxrQkFBa0IsR0FBRztFQUNwRCxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixDQUFDLE9BQU8sNEJBQTRCLElBQUksR0FBRyxHQUFHLEdBQUc7R0FDaEcsT0FDRSxZQUFZLEtBQUssVUFDZixHQUNGLEVBQUUsdUVBQ0o7RUFDRjtFQUNBLE9BQU87Q0FDVDtBQUNGLENBQUM7QUFDRCxTQUFTLHVCQUF1QixVQUFVO0NBQ3hDLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLE9BQU8sZUFBZSxRQUFRLEtBQUs7RUFDakMsY0FBYztFQUNkLFlBQVk7RUFDWixXQUFXO0NBQ2IsQ0FBQztDQUNELE9BQU8sS0FBSyxtQkFBbUIsQ0FBQyxDQUFDLFNBQVMsUUFBUTtFQUNoRCxPQUFPLGVBQWUsUUFBUSxLQUFLO0dBQ2pDLGNBQWM7R0FDZCxZQUFZO0dBQ1osV0FBVyxvQkFBb0IsSUFBSSxDQUFDLFFBQVE7OztHQUc1QyxLQUFLO0VBQ1AsQ0FBQztDQUNILENBQUM7Q0FDRCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLDJCQUEyQixVQUFVO0NBQzVDLE1BQU0sRUFDSixLQUNBLGNBQWMsQ0FBQyxrQkFDYjtDQUNKLElBQUksY0FBYztFQUNoQixPQUFPLEtBQUssWUFBWSxDQUFDLENBQUMsU0FBUyxRQUFRO0dBQ3pDLE9BQU8sZUFBZSxLQUFLLEtBQUs7SUFDOUIsWUFBWTtJQUNaLGNBQWM7SUFDZCxXQUFXLFNBQVMsTUFBTTtJQUMxQixLQUFLO0dBQ1AsQ0FBQztFQUNILENBQUM7Q0FDSDtBQUNGO0FBQ0EsU0FBUyxnQ0FBZ0MsVUFBVTtDQUNqRCxNQUFNLEVBQUUsS0FBSyxlQUFlO0NBQzVCLE9BQU8sS0FBSyxNQUFNLFVBQVUsQ0FBQyxDQUFDLENBQUMsU0FBUyxRQUFRO0VBQzlDLElBQUksQ0FBQyxXQUFXLGlCQUFpQjtHQUMvQixJQUFJLGlCQUFpQixJQUFJLEVBQUUsR0FBRztJQUM1QixPQUNFLDJCQUEyQixLQUFLLFVBQzlCLEdBQ0YsRUFBRSxpRkFDSjtJQUNBO0dBQ0Y7R0FDQSxPQUFPLGVBQWUsS0FBSyxLQUFLO0lBQzlCLFlBQVk7SUFDWixjQUFjO0lBQ2QsV0FBVyxXQUFXO0lBQ3RCLEtBQUs7R0FDUCxDQUFDO0VBQ0g7Q0FDRixDQUFDO0FBQ0g7QUFFQSxNQUFNLG9CQUFvQixXQUFXLE9BQ25DLEdBQUcsT0FBTyxrTEFDWjtBQUNBLFNBQVMsY0FBYztDQUNyQixJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDN0MsaUJBQWlCLGFBQWE7Q0FDaEM7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGNBQWM7Q0FDckIsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0VBQzdDLGlCQUFpQixhQUFhO0NBQ2hDO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxhQUFhLFNBQVM7Q0FDN0IsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0VBQzdDLGlCQUFpQixjQUFjO0NBQ2pDO0FBQ0Y7QUFDQSxTQUFTLGNBQWMsU0FBUztDQUM5QixJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDN0MsaUJBQWlCLGVBQWU7Q0FDbEM7QUFDRjtBQUNBLFNBQVMsY0FBYztDQUNyQixJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDN0MsaUJBQWlCLGFBQWE7Q0FDaEM7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGNBQWM7Q0FDckIsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0VBQzdDLGlCQUFpQixhQUFhO0NBQ2hDO0FBQ0Y7QUFDQSxTQUFTLGFBQWEsT0FBTyxVQUFVO0NBQ3JDLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtFQUM3QyxpQkFBaUIsY0FBYztDQUNqQztDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsV0FBVztDQUNsQixPQUFPLFdBQVcsVUFBVSxDQUFDLENBQUM7QUFDaEM7QUFDQSxTQUFTLFdBQVc7Q0FDbEIsT0FBTyxXQUFXLFVBQVUsQ0FBQyxDQUFDO0FBQ2hDO0FBQ0EsU0FBUyxXQUFXLG9CQUFvQjtDQUN0QyxNQUFNLElBQUksbUJBQW1CO0NBQzdCLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLENBQUMsR0FBRztFQUNuRCxPQUFPLEdBQUcsbUJBQW1CLG1DQUFtQztDQUNsRTtDQUNBLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxlQUFlLG1CQUFtQixDQUFDO0FBQ2pFO0FBQ0EsU0FBUyxzQkFBc0IsT0FBTztDQUNwQyxPQUFPLFFBQVEsS0FBSyxJQUFJLE1BQU0sUUFDM0IsWUFBWSxPQUFPLFdBQVcsS0FBSyxNQUFNLGFBQzFDLENBQUMsQ0FDSCxJQUFJO0FBQ047QUFDQSxTQUFTLGNBQWMsS0FBSyxVQUFVO0NBQ3BDLE1BQU0sUUFBUSxzQkFBc0IsR0FBRztDQUN2QyxLQUFLLE1BQU0sT0FBTyxVQUFVO0VBQzFCLElBQUksSUFBSSxXQUFXLFFBQVEsR0FBRztFQUM5QixJQUFJLE1BQU0sTUFBTTtFQUNoQixJQUFJLEtBQUs7R0FDUCxJQUFJLFFBQVEsR0FBRyxLQUFLLFdBQVcsR0FBRyxHQUFHO0lBQ25DLE1BQU0sTUFBTSxPQUFPO0tBQUUsTUFBTTtLQUFLLFNBQVMsU0FBUztJQUFLO0dBQ3pELE9BQU87SUFDTCxJQUFJLFVBQVUsU0FBUztHQUN6QjtFQUNGLE9BQU8sSUFBSSxRQUFRLE1BQU07R0FDdkIsTUFBTSxNQUFNLE9BQU8sRUFBRSxTQUFTLFNBQVMsS0FBSztFQUM5QyxPQUFPLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtHQUNwRCxPQUFPLHNCQUFzQixJQUFJLG9DQUFvQztFQUN2RTtFQUNBLElBQUksT0FBTyxTQUFTLFVBQVUsUUFBUTtHQUNwQyxJQUFJLGNBQWM7RUFDcEI7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsWUFBWSxHQUFHLEdBQUc7Q0FDekIsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLE9BQU8sS0FBSztDQUMxQixJQUFJLFFBQVEsQ0FBQyxLQUFLLFFBQVEsQ0FBQyxHQUFHLE9BQU8sRUFBRSxPQUFPLENBQUM7Q0FDL0MsT0FBTyxPQUFPLENBQUMsR0FBRyxzQkFBc0IsQ0FBQyxHQUFHLHNCQUFzQixDQUFDLENBQUM7QUFDdEU7QUFDQSxTQUFTLHFCQUFxQixPQUFPLGNBQWM7Q0FDakQsTUFBTSxNQUFNLENBQUM7Q0FDYixLQUFLLE1BQU0sT0FBTyxPQUFPO0VBQ3ZCLElBQUksQ0FBQyxhQUFhLFNBQVMsR0FBRyxHQUFHO0dBQy9CLE9BQU8sZUFBZSxLQUFLLEtBQUs7SUFDOUIsWUFBWTtJQUNaLFdBQVcsTUFBTTtHQUNuQixDQUFDO0VBQ0g7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsaUJBQWlCLGNBQWM7Q0FDdEMsTUFBTSxNQUFNLG1CQUFtQjtDQUMvQixNQUFNLGFBQWE7Q0FDbkIsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsQ0FBQyxLQUFLO0VBQ3JELE9BQ0UsZ0ZBQ0Y7Q0FDRjtDQUNBLElBQUksWUFBWSxhQUFhO0NBQzdCLHFCQUFxQjtDQUNyQixJQUFJLFlBQVk7RUFDZCxtQkFBbUIsS0FBSztDQUMxQjtDQUNBLE1BQU0sZ0JBQWdCO0VBQ3BCLG1CQUFtQixHQUFHO0VBQ3RCLElBQUksWUFBWTtHQUNkLG1CQUFtQixJQUFJO0VBQ3pCO0NBQ0Y7Q0FDQSxNQUFNLGdCQUFnQjtFQUNwQixJQUFJLG1CQUFtQixNQUFNLEtBQUssSUFBSSxNQUFNLElBQUk7RUFDaEQscUJBQXFCO0VBQ3JCLElBQUksWUFBWTtHQUNkLG1CQUFtQixLQUFLO0VBQzFCO0NBQ0Y7Q0FDQSxJQUFJLFVBQVUsU0FBUyxHQUFHO0VBQ3hCLFlBQVksVUFBVSxPQUFPLE1BQU07R0FDakMsUUFBUTtHQUNSLFFBQVEsUUFBUSxDQUFDLENBQUMsV0FBVyxRQUFRLFFBQVEsQ0FBQyxDQUFDLEtBQUssT0FBTyxDQUFDO0dBQzVELE1BQU07RUFDUixDQUFDO0NBQ0g7Q0FDQSxPQUFPLENBQ0wsaUJBQ007RUFDSixRQUFRO0VBQ1IsUUFBUSxRQUFRLENBQUMsQ0FBQyxLQUFLLE9BQU87Q0FDaEMsQ0FDRjtBQUNGO0FBRUEsU0FBUyx5QkFBeUI7Q0FDaEMsTUFBTSxRQUF3Qix1QkFBTyxPQUFPLElBQUk7Q0FDaEQsUUFBUSxNQUFNLFFBQVE7RUFDcEIsSUFBSSxNQUFNLE1BQU07R0FDZCxPQUFPLEdBQUcsS0FBSyxhQUFhLElBQUksMEJBQTBCLE1BQU0sS0FBSyxFQUFFO0VBQ3pFLE9BQU87R0FDTCxNQUFNLE9BQU87RUFDZjtDQUNGO0FBQ0Y7QUFDQSxJQUFJLG9CQUFvQjtBQUN4QixTQUFTLGFBQWEsVUFBVTtDQUM5QixNQUFNLFVBQVUscUJBQXFCLFFBQVE7Q0FDN0MsTUFBTSxhQUFhLFNBQVM7Q0FDNUIsTUFBTSxNQUFNLFNBQVM7Q0FDckIsb0JBQW9CO0NBQ3BCLElBQUksUUFBUSxjQUFjO0VBQ3hCLFNBQVMsUUFBUSxjQUFjLFVBQVUsSUFBSTtDQUMvQztDQUNBLE1BQU0sRUFFSixNQUFNLGFBQ04sVUFBVSxpQkFDVixTQUNBLE9BQU8sY0FDUCxTQUFTLGdCQUNULFFBQVEsZUFFUixTQUNBLGFBQ0EsU0FDQSxjQUNBLFNBQ0EsV0FDQSxhQUNBLGVBQ0EsZUFDQSxXQUNBLFdBQ0EsUUFDQSxlQUNBLGlCQUNBLGVBQ0EsZ0JBRUEsUUFDQSxjQUVBLFlBQ0EsWUFDQSxZQUNFO0NBQ0osTUFBTSwyQkFBMkIsQ0FBQyxvQkFBMkIsZ0JBQWdCLHVCQUF1QixJQUFJO0NBQ3hHLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtFQUM3QyxNQUFNLENBQUMsZ0JBQWdCLFNBQVM7RUFDaEMsSUFBSSxjQUFjO0dBQ2hCLEtBQUssTUFBTSxPQUFPLGNBQWM7SUFDOUIseUJBQXlCLFNBQXFCLEdBQUc7R0FDbkQ7RUFDRjtDQUNGO0NBQ0EsSUFBSSxlQUFlO0VBQ2pCLGtCQUFrQixlQUFlLEtBQUssd0JBQXdCO0NBQ2hFO0NBQ0EsSUFBSSxTQUFTO0VBQ1gsS0FBSyxNQUFNLE9BQU8sU0FBUztHQUN6QixNQUFNLGdCQUFnQixRQUFRO0dBQzlCLElBQUksV0FBVyxhQUFhLEdBQUc7SUFDN0IsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0tBQzdDLE9BQU8sZUFBZSxLQUFLLEtBQUs7TUFDOUIsT0FBTyxjQUFjLEtBQUssVUFBVTtNQUNwQyxjQUFjO01BQ2QsWUFBWTtNQUNaLFVBQVU7S0FDWixDQUFDO0lBQ0gsT0FBTztLQUNMLElBQUksT0FBTyxjQUFjLEtBQUssVUFBVTtJQUMxQztJQUNBLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtLQUM3Qyx5QkFBeUIsV0FBeUIsR0FBRztJQUN2RDtHQUNGLE9BQU8sSUFBSSxDQUFDLG9CQUEyQixlQUFlO0lBQ3BELE9BQ0UsV0FBVyxJQUFJLGNBQWMsT0FBTyxjQUFjLHlFQUNwRDtHQUNGO0VBQ0Y7Q0FDRjtDQUNBLElBQUksYUFBYTtFQUNmLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLENBQUMsV0FBVyxXQUFXLEdBQUc7R0FDekUsT0FDRSxnRkFDRjtFQUNGO0VBQ0EsTUFBTSxPQUFPLFlBQVksS0FBSyxZQUFZLFVBQVU7RUFDcEQsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsVUFBVSxJQUFJLEdBQUc7R0FDaEUsT0FDRSwySkFDRjtFQUNGO0VBQ0EsSUFBSSxDQUFDLFNBQVMsSUFBSSxHQUFHO0dBQ25CLENBQUMsb0JBQTJCLGlCQUFpQixPQUFPLGlDQUFpQztFQUN2RixPQUFPO0dBQ0wsU0FBUyxPQUFPLFNBQVMsSUFBSTtHQUM3QixJQUFJLENBQUMsb0JBQTJCLGVBQWU7SUFDN0MsS0FBSyxNQUFNLE9BQU8sTUFBTTtLQUN0Qix5QkFBeUIsUUFBbUIsR0FBRztLQUMvQyxJQUFJLENBQUMsaUJBQWlCLElBQUksRUFBRSxHQUFHO01BQzdCLE9BQU8sZUFBZSxLQUFLLEtBQUs7T0FDOUIsY0FBYztPQUNkLFlBQVk7T0FDWixXQUFXLEtBQUs7T0FDaEIsS0FBSztNQUNQLENBQUM7S0FDSDtJQUNGO0dBQ0Y7RUFDRjtDQUNGO0NBQ0Esb0JBQW9CO0NBQ3BCLElBQUksaUJBQWlCO0VBQ25CLEtBQUssTUFBTSxPQUFPLGlCQUFpQjtHQUNqQyxNQUFNLE1BQU0sZ0JBQWdCO0dBQzVCLE1BQU0sTUFBTSxXQUFXLEdBQUcsSUFBSSxJQUFJLEtBQUssWUFBWSxVQUFVLElBQUksV0FBVyxJQUFJLEdBQUcsSUFBSSxJQUFJLElBQUksS0FBSyxZQUFZLFVBQVUsSUFBSTtHQUM5SCxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixRQUFRLE1BQU07SUFDN0QsT0FBTyxzQkFBc0IsSUFBSSxpQkFBaUI7R0FDcEQ7R0FDQSxNQUFNLE1BQU0sQ0FBQyxXQUFXLEdBQUcsS0FBSyxXQUFXLElBQUksR0FBRyxJQUFJLElBQUksSUFBSSxLQUFLLFVBQVUsSUFBSSxDQUFDLG9CQUEyQixzQkFBc0I7SUFDakksT0FDRSw4Q0FBOEMsSUFBSSxlQUNwRDtHQUNGLElBQUk7R0FDSixNQUFNLElBQUksU0FBUztJQUNqQjtJQUNBO0dBQ0YsQ0FBQztHQUNELE9BQU8sZUFBZSxLQUFLLEtBQUs7SUFDOUIsWUFBWTtJQUNaLGNBQWM7SUFDZCxXQUFXLEVBQUU7SUFDYixNQUFNLE1BQU0sRUFBRSxRQUFRO0dBQ3hCLENBQUM7R0FDRCxJQUFJLENBQUMsb0JBQTJCLGVBQWU7SUFDN0MseUJBQXlCLFlBQTJCLEdBQUc7R0FDekQ7RUFDRjtDQUNGO0NBQ0EsSUFBSSxjQUFjO0VBQ2hCLEtBQUssTUFBTSxPQUFPLGNBQWM7R0FDOUIsY0FBYyxhQUFhLE1BQU0sS0FBSyxZQUFZLEdBQUc7RUFDdkQ7Q0FDRjtDQUNBLElBQUksZ0JBQWdCO0VBQ2xCLE1BQU0sV0FBVyxXQUFXLGNBQWMsSUFBSSxlQUFlLEtBQUssVUFBVSxJQUFJO0VBQ2hGLFFBQVEsUUFBUSxRQUFRLENBQUMsQ0FBQyxTQUFTLFFBQVE7R0FDekMsUUFBUSxLQUFLLFNBQVMsSUFBSTtFQUM1QixDQUFDO0NBQ0g7Q0FDQSxJQUFJLFNBQVM7RUFDWCxTQUFTLFNBQVMsVUFBVSxHQUFHO0NBQ2pDO0NBQ0EsU0FBUyxzQkFBc0IsVUFBVSxNQUFNO0VBQzdDLElBQUksUUFBUSxJQUFJLEdBQUc7R0FDakIsS0FBSyxTQUFTLFVBQVUsU0FBUyxNQUFNLEtBQUssVUFBVSxDQUFDLENBQUM7RUFDMUQsT0FBTyxJQUFJLE1BQU07R0FDZixTQUFTLEtBQUssS0FBSyxVQUFVLENBQUM7RUFDaEM7Q0FDRjtDQUNBLHNCQUFzQixlQUFlLFdBQVc7Q0FDaEQsc0JBQXNCLFdBQVcsT0FBTztDQUN4QyxzQkFBc0IsZ0JBQWdCLFlBQVk7Q0FDbEQsc0JBQXNCLFdBQVcsT0FBTztDQUN4QyxzQkFBc0IsYUFBYSxTQUFTO0NBQzVDLHNCQUFzQixlQUFlLFdBQVc7Q0FDaEQsc0JBQXNCLGlCQUFpQixhQUFhO0NBQ3BELHNCQUFzQixpQkFBaUIsYUFBYTtDQUNwRCxzQkFBc0IsbUJBQW1CLGVBQWU7Q0FDeEQsc0JBQXNCLGlCQUFpQixhQUFhO0NBQ3BELHNCQUFzQixhQUFhLFNBQVM7Q0FDNUMsc0JBQXNCLGtCQUFrQixjQUFjO0NBQ3RELElBQUksUUFBUSxNQUFNLEdBQUc7RUFDbkIsSUFBSSxPQUFPLFFBQVE7R0FDakIsTUFBTSxVQUFVLFNBQVMsWUFBWSxTQUFTLFVBQVUsQ0FBQztHQUN6RCxPQUFPLFNBQVMsUUFBUTtJQUN0QixPQUFPLGVBQWUsU0FBUyxLQUFLO0tBQ2xDLFdBQVcsV0FBVztLQUN0QixNQUFNLFFBQVEsV0FBVyxPQUFPO0tBQ2hDLFlBQVk7SUFDZCxDQUFDO0dBQ0gsQ0FBQztFQUNILE9BQU8sSUFBSSxDQUFDLFNBQVMsU0FBUztHQUM1QixTQUFTLFVBQVUsQ0FBQztFQUN0QjtDQUNGO0NBQ0EsSUFBSSxVQUFVLFNBQVMsV0FBVyxNQUFNO0VBQ3RDLFNBQVMsU0FBUztDQUNwQjtDQUNBLElBQUksZ0JBQWdCLE1BQU07RUFDeEIsU0FBUyxlQUFlO0NBQzFCO0NBQ0EsSUFBSSxZQUFZLFNBQVMsYUFBYTtDQUN0QyxJQUFJLFlBQVksU0FBUyxhQUFhO0NBQ3RDLElBQUksZ0JBQWdCO0VBQ2xCLGtCQUFrQixRQUFRO0NBQzVCO0FBQ0Y7QUFDQSxTQUFTLGtCQUFrQixlQUFlLEtBQUssMkJBQTJCLE1BQU07Q0FDOUUsSUFBSSxRQUFRLGFBQWEsR0FBRztFQUMxQixnQkFBZ0IsZ0JBQWdCLGFBQWE7Q0FDL0M7Q0FDQSxLQUFLLE1BQU0sT0FBTyxlQUFlO0VBQy9CLE1BQU0sTUFBTSxjQUFjO0VBQzFCLElBQUk7RUFDSixJQUFJLFNBQVMsR0FBRyxHQUFHO0dBQ2pCLElBQUksYUFBYSxLQUFLO0lBQ3BCLFdBQVcsT0FDVCxJQUFJLFFBQVEsS0FDWixJQUFJLFNBQ0osSUFDRjtHQUNGLE9BQU87SUFDTCxXQUFXLE9BQU8sSUFBSSxRQUFRLEdBQUc7R0FDbkM7RUFDRixPQUFPO0dBQ0wsV0FBVyxPQUFPLEdBQUc7RUFDdkI7RUFDQSxJQUFJLE1BQU0sUUFBUSxHQUFHO0dBQ25CLE9BQU8sZUFBZSxLQUFLLEtBQUs7SUFDOUIsWUFBWTtJQUNaLGNBQWM7SUFDZCxXQUFXLFNBQVM7SUFDcEIsTUFBTSxNQUFNLFNBQVMsUUFBUTtHQUMvQixDQUFDO0VBQ0gsT0FBTztHQUNMLElBQUksT0FBTztFQUNiO0VBQ0EsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0dBQzdDLHlCQUF5QixVQUF1QixHQUFHO0VBQ3JEO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsU0FBUyxNQUFNLFVBQVUsTUFBTTtDQUN0QywyQkFDRSxRQUFRLElBQUksSUFBSSxLQUFLLEtBQUssTUFBTSxFQUFFLEtBQUssU0FBUyxLQUFLLENBQUMsSUFBSSxLQUFLLEtBQUssU0FBUyxLQUFLLEdBQ2xGLFVBQ0EsSUFDRjtBQUNGO0FBQ0EsU0FBUyxjQUFjLEtBQUssS0FBSyxZQUFZLEtBQUs7Q0FDaEQsSUFBSSxTQUFTLElBQUksU0FBUyxHQUFHLElBQUksaUJBQWlCLFlBQVksR0FBRyxVQUFVLFdBQVc7Q0FDdEYsSUFBSSxTQUFTLEdBQUcsR0FBRztFQUNqQixNQUFNLFVBQVUsSUFBSTtFQUNwQixJQUFJLFdBQVcsT0FBTyxHQUFHO0dBQ3ZCO0lBQ0UsTUFBTSxRQUFRLE9BQU87R0FDdkI7RUFDRixPQUFPLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtHQUNwRCxPQUFPLDJDQUEyQyxJQUFJLElBQUksT0FBTztFQUNuRTtDQUNGLE9BQU8sSUFBSSxXQUFXLEdBQUcsR0FBRztFQUMxQjtHQUNFLE1BQU0sUUFBUSxJQUFJLEtBQUssVUFBVSxDQUFDO0VBQ3BDO0NBQ0YsT0FBTyxJQUFJLFNBQVMsR0FBRyxHQUFHO0VBQ3hCLElBQUksUUFBUSxHQUFHLEdBQUc7R0FDaEIsSUFBSSxTQUFTLE1BQU0sY0FBYyxHQUFHLEtBQUssWUFBWSxHQUFHLENBQUM7RUFDM0QsT0FBTztHQUNMLE1BQU0sVUFBVSxXQUFXLElBQUksT0FBTyxJQUFJLElBQUksUUFBUSxLQUFLLFVBQVUsSUFBSSxJQUFJLElBQUk7R0FDakYsSUFBSSxXQUFXLE9BQU8sR0FBRztJQUN2QixNQUFNLFFBQVEsU0FBUyxHQUFHO0dBQzVCLE9BQU8sSUFBSSxDQUFDLG9CQUEyQixlQUFlO0lBQ3BELE9BQU8sMkNBQTJDLElBQUksUUFBUSxJQUFJLE9BQU87R0FDM0U7RUFDRjtDQUNGLE9BQU8sSUFBSSxDQUFDLG9CQUEyQixlQUFlO0VBQ3BELE9BQU8sMEJBQTBCLElBQUksSUFBSSxHQUFHO0NBQzlDO0FBQ0Y7QUFDQSxTQUFTLHFCQUFxQixVQUFVO0NBQ3RDLE1BQU0sT0FBTyxTQUFTO0NBQ3RCLE1BQU0sRUFBRSxRQUFRLFNBQVMsbUJBQW1CO0NBQzVDLE1BQU0sRUFDSixRQUFRLGNBQ1IsY0FBYyxPQUNkLFFBQVEsRUFBRSw0QkFDUixTQUFTO0NBQ2IsTUFBTSxTQUFTLE1BQU0sSUFBSSxJQUFJO0NBQzdCLElBQUk7Q0FDSixJQUFJLFFBQVE7RUFDVixXQUFXO0NBQ2IsT0FBTyxJQUFJLENBQUMsYUFBYSxVQUFVLENBQUMsVUFBVSxDQUFDLGdCQUFnQjtFQUM3RDtHQUNFLFdBQVc7RUFDYjtDQUNGLE9BQU87RUFDTCxXQUFXLENBQUM7RUFDWixJQUFJLGFBQWEsUUFBUTtHQUN2QixhQUFhLFNBQ1YsTUFBTSxhQUFhLFVBQVUsR0FBRyx1QkFBdUIsSUFBSSxDQUM5RDtFQUNGO0VBQ0EsYUFBYSxVQUFVLE1BQU0scUJBQXFCO0NBQ3BEO0NBQ0EsSUFBSSxTQUFTLElBQUksR0FBRztFQUNsQixNQUFNLElBQUksTUFBTSxRQUFRO0NBQzFCO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxhQUFhLElBQUksTUFBTSxRQUFRLFVBQVUsT0FBTztDQUN2RCxNQUFNLEVBQUUsUUFBUSxTQUFTLG1CQUFtQjtDQUM1QyxJQUFJLGdCQUFnQjtFQUNsQixhQUFhLElBQUksZ0JBQWdCLFFBQVEsSUFBSTtDQUMvQztDQUNBLElBQUksUUFBUTtFQUNWLE9BQU8sU0FDSixNQUFNLGFBQWEsSUFBSSxHQUFHLFFBQVEsSUFBSSxDQUN6QztDQUNGO0NBQ0EsS0FBSyxNQUFNLE9BQU8sTUFBTTtFQUN0QixJQUFJLFdBQVcsUUFBUSxVQUFVO0dBQy9CLENBQUMsb0JBQTJCLGlCQUFpQixPQUMzQyx5SEFDRjtFQUNGLE9BQU87R0FDTCxNQUFNLFFBQVEsMEJBQTBCLFFBQVEsVUFBVSxPQUFPO0dBQ2pFLEdBQUcsT0FBTyxRQUFRLE1BQU0sR0FBRyxNQUFNLEtBQUssSUFBSSxJQUFJLEtBQUs7RUFDckQ7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBLE1BQU0sNEJBQTRCO0NBQ2hDLE1BQU07Q0FDTixPQUFPO0NBQ1AsT0FBTzs7Q0FFUCxTQUFTO0NBQ1QsVUFBVTs7Q0FFVixjQUFjO0NBQ2QsU0FBUztDQUNULGFBQWE7Q0FDYixTQUFTO0NBQ1QsY0FBYztDQUNkLFNBQVM7Q0FDVCxlQUFlO0NBQ2YsZUFBZTtDQUNmLFdBQVc7Q0FDWCxXQUFXO0NBQ1gsV0FBVztDQUNYLGFBQWE7Q0FDYixlQUFlO0NBQ2YsZ0JBQWdCOztDQUVoQixZQUFZO0NBQ1osWUFBWTs7Q0FFWixPQUFPOztDQUVQLFNBQVM7Q0FDVCxRQUFRO0FBQ1Y7QUFDQSxTQUFTLFlBQVksSUFBSSxNQUFNO0NBQzdCLElBQUksQ0FBQyxNQUFNO0VBQ1QsT0FBTztDQUNUO0NBQ0EsSUFBSSxDQUFDLElBQUk7RUFDUCxPQUFPO0NBQ1Q7Q0FDQSxPQUFPLFNBQVMsZUFBZTtFQUM3QixPQUFRLE9BQ04sV0FBVyxFQUFFLElBQUksR0FBRyxLQUFLLE1BQU0sSUFBSSxJQUFJLElBQ3ZDLFdBQVcsSUFBSSxJQUFJLEtBQUssS0FBSyxNQUFNLElBQUksSUFBSSxJQUM3QztDQUNGO0FBQ0Y7QUFDQSxTQUFTLFlBQVksSUFBSSxNQUFNO0NBQzdCLE9BQU8sbUJBQW1CLGdCQUFnQixFQUFFLEdBQUcsZ0JBQWdCLElBQUksQ0FBQztBQUN0RTtBQUNBLFNBQVMsZ0JBQWdCLEtBQUs7Q0FDNUIsSUFBSSxRQUFRLEdBQUcsR0FBRztFQUNoQixNQUFNLE1BQU0sQ0FBQztFQUNiLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLFFBQVEsS0FBSztHQUNuQyxJQUFJLElBQUksTUFBTSxJQUFJO0VBQ3BCO0VBQ0EsT0FBTztDQUNUO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxhQUFhLElBQUksTUFBTTtDQUM5QixPQUFPLEtBQUssQ0FBQyxHQUFHLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsSUFBSTtBQUNsRDtBQUNBLFNBQVMsbUJBQW1CLElBQUksTUFBTTtDQUNwQyxPQUFPLEtBQUssT0FBdUIsdUJBQU8sT0FBTyxJQUFJLEdBQUcsSUFBSSxJQUFJLElBQUk7QUFDdEU7QUFDQSxTQUFTLHlCQUF5QixJQUFJLE1BQU07Q0FDMUMsSUFBSSxJQUFJO0VBQ04sSUFBSSxRQUFRLEVBQUUsS0FBSyxRQUFRLElBQUksR0FBRztHQUNoQyxPQUFPLENBQUMsbUJBQW1CLElBQUksSUFBSSxDQUFDLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDO0VBQ3REO0VBQ0EsT0FBTyxPQUNXLHVCQUFPLE9BQU8sSUFBSSxHQUNsQyxzQkFBc0IsRUFBRSxHQUN4QixzQkFBc0IsUUFBUSxPQUFPLE9BQU8sQ0FBQyxDQUFDLENBQ2hEO0NBQ0YsT0FBTztFQUNMLE9BQU87Q0FDVDtBQUNGO0FBQ0EsU0FBUyxrQkFBa0IsSUFBSSxNQUFNO0NBQ25DLElBQUksQ0FBQyxJQUFJLE9BQU87Q0FDaEIsSUFBSSxDQUFDLE1BQU0sT0FBTztDQUNsQixNQUFNLFNBQVMsT0FBdUIsdUJBQU8sT0FBTyxJQUFJLEdBQUcsRUFBRTtDQUM3RCxLQUFLLE1BQU0sT0FBTyxNQUFNO0VBQ3RCLE9BQU8sT0FBTyxhQUFhLEdBQUcsTUFBTSxLQUFLLElBQUk7Q0FDL0M7Q0FDQSxPQUFPO0FBQ1Q7QUFFQSxTQUFTLG1CQUFtQjtDQUMxQixPQUFPO0VBQ0wsS0FBSztFQUNMLFFBQVE7R0FDTixhQUFhO0dBQ2IsYUFBYTtHQUNiLGtCQUFrQixDQUFDO0dBQ25CLHVCQUF1QixDQUFDO0dBQ3hCLGNBQWMsS0FBSztHQUNuQixhQUFhLEtBQUs7R0FDbEIsaUJBQWlCLENBQUM7RUFDcEI7RUFDQSxRQUFRLENBQUM7RUFDVCxZQUFZLENBQUM7RUFDYixZQUFZLENBQUM7RUFDYixVQUEwQix1QkFBTyxPQUFPLElBQUk7RUFDNUMsOEJBQThCLElBQUksUUFBUTtFQUMxQyw0QkFBNEIsSUFBSSxRQUFRO0VBQ3hDLDRCQUE0QixJQUFJLFFBQVE7Q0FDMUM7QUFDRjtBQUNBLElBQUksUUFBUTtBQUNaLFNBQVMsYUFBYSxRQUFRLFNBQVM7Q0FDckMsT0FBTyxTQUFTLFVBQVUsZUFBZSxZQUFZLE1BQU07RUFDekQsSUFBSSxDQUFDLFdBQVcsYUFBYSxHQUFHO0dBQzlCLGdCQUFnQixPQUFPLENBQUMsR0FBRyxhQUFhO0VBQzFDO0VBQ0EsSUFBSSxhQUFhLFFBQVEsQ0FBQyxTQUFTLFNBQVMsR0FBRztHQUM3QyxDQUFDLG9CQUEyQixpQkFBaUIsT0FBTyxxREFBcUQ7R0FDekcsWUFBWTtFQUNkO0VBQ0EsTUFBTSxVQUFVLGlCQUFpQjtFQUNqQyxNQUFNLG1DQUFtQyxJQUFJLFFBQVE7RUFDckQsTUFBTSxtQkFBbUIsQ0FBQztFQUMxQixJQUFJLFlBQVk7RUFDaEIsTUFBTSxNQUFNLFFBQVEsTUFBTTtHQUN4QixNQUFNO0dBQ04sWUFBWTtHQUNaLFFBQVE7R0FDUixZQUFZO0dBQ1osVUFBVTtHQUNWLFdBQVc7R0FDWDtHQUNBLElBQUksU0FBUztJQUNYLE9BQU8sUUFBUTtHQUNqQjtHQUNBLElBQUksT0FBTyxHQUFHO0lBQ1osSUFBSSxDQUFDLG9CQUEyQixlQUFlO0tBQzdDLE9BQ0UsbUVBQ0Y7SUFDRjtHQUNGO0dBQ0EsSUFBSSxRQUFRLEdBQUcsU0FBUztJQUN0QixJQUFJLGlCQUFpQixJQUFJLE1BQU0sR0FBRztLQUNoQyxDQUFDLG9CQUEyQixpQkFBaUIsT0FBTyxnREFBZ0Q7SUFDdEcsT0FBTyxJQUFJLFVBQVUsV0FBVyxPQUFPLE9BQU8sR0FBRztLQUMvQyxpQkFBaUIsSUFBSSxNQUFNO0tBQzNCLE9BQU8sUUFBUSxLQUFLLEdBQUcsT0FBTztJQUNoQyxPQUFPLElBQUksV0FBVyxNQUFNLEdBQUc7S0FDN0IsaUJBQWlCLElBQUksTUFBTTtLQUMzQixPQUFPLEtBQUssR0FBRyxPQUFPO0lBQ3hCLE9BQU8sSUFBSSxDQUFDLG9CQUEyQixlQUFlO0tBQ3BELE9BQ0UsNkVBQ0Y7SUFDRjtJQUNBLE9BQU87R0FDVDtHQUNBLE1BQU0sT0FBTztJQUNYLElBQUkscUJBQXFCO0tBQ3ZCLElBQUksQ0FBQyxRQUFRLE9BQU8sU0FBUyxLQUFLLEdBQUc7TUFDbkMsUUFBUSxPQUFPLEtBQUssS0FBSztLQUMzQixPQUFPLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtNQUNwRCxPQUNFLGtEQUFrRCxNQUFNLE9BQU8sS0FBSyxNQUFNLFNBQVMsR0FDckY7S0FDRjtJQUNGLE9BQU8sSUFBSSxDQUFDLG9CQUEyQixlQUFlO0tBQ3BELE9BQU8sNERBQTREO0lBQ3JFO0lBQ0EsT0FBTztHQUNUO0dBQ0EsVUFBVSxNQUFNLFdBQVc7SUFDekIsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0tBQzdDLHNCQUFzQixNQUFNLFFBQVEsTUFBTTtJQUM1QztJQUNBLElBQUksQ0FBQyxXQUFXO0tBQ2QsT0FBTyxRQUFRLFdBQVc7SUFDNUI7SUFDQSxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixRQUFRLFdBQVcsT0FBTztLQUN6RSxPQUFPLGNBQWMsS0FBSyw2Q0FBNkM7SUFDekU7SUFDQSxRQUFRLFdBQVcsUUFBUTtJQUMzQixPQUFPO0dBQ1Q7R0FDQSxVQUFVLE1BQU0sV0FBVztJQUN6QixJQUFJLENBQUMsb0JBQTJCLGVBQWU7S0FDN0Msc0JBQXNCLElBQUk7SUFDNUI7SUFDQSxJQUFJLENBQUMsV0FBVztLQUNkLE9BQU8sUUFBUSxXQUFXO0lBQzVCO0lBQ0EsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsUUFBUSxXQUFXLE9BQU87S0FDekUsT0FBTyxjQUFjLEtBQUssNkNBQTZDO0lBQ3pFO0lBQ0EsUUFBUSxXQUFXLFFBQVE7SUFDM0IsT0FBTztHQUNUO0dBQ0EsTUFBTSxlQUFlLFdBQVcsV0FBVztJQUN6QyxJQUFJLENBQUMsV0FBVztLQUNkLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLGNBQWMsYUFBYTtNQUMxRSxPQUNFO3VJQUVGO0tBQ0Y7S0FDQSxNQUFNLFFBQVEsSUFBSSxZQUFZLFlBQVksZUFBZSxTQUFTO0tBQ2xFLE1BQU0sYUFBYTtLQUNuQixJQUFJLGNBQWMsTUFBTTtNQUN0QixZQUFZO0tBQ2QsT0FBTyxJQUFJLGNBQWMsT0FBTztNQUM5QixZQUFZLEtBQUs7S0FDbkI7S0FDQSxJQUFJLENBQUMsb0JBQTJCLGVBQWU7TUFDN0MsUUFBUSxlQUFlO09BQ3JCLE1BQU0sU0FBUyxXQUFXLEtBQUs7T0FDL0IsT0FBTyxLQUFLO09BQ1osT0FBTyxRQUFRLGVBQWUsU0FBUztNQUN6QztLQUNGO0tBQ0EsSUFBSSxhQUFhLFNBQVM7TUFDeEIsUUFBUSxPQUFPLGFBQWE7S0FDOUIsT0FBTztNQUNMLE9BQU8sT0FBTyxlQUFlLFNBQVM7S0FDeEM7S0FDQSxZQUFZO0tBQ1osSUFBSSxhQUFhO0tBQ2pCLGNBQWMsY0FBYztLQUM1QixJQUFJLENBQUMsb0JBQTJCLGlCQUFpQix1QkFBdUI7TUFDdEUsSUFBSSxZQUFZLE1BQU07TUFDdEIsZ0JBQWdCLEtBQUssT0FBTztLQUM5QjtLQUNBLE9BQU8sMkJBQTJCLE1BQU0sU0FBUztJQUNuRCxPQUFPLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtLQUNwRCxPQUNFOzRMQUVGO0lBQ0Y7R0FDRjtHQUNBLFVBQVUsV0FBVztJQUNuQixJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixPQUFPLGNBQWMsWUFBWTtLQUNoRixPQUNFLG1FQUFtRSxPQUFPLFdBQzVFO0lBQ0Y7SUFDQSxpQkFBaUIsS0FBSyxTQUFTO0dBQ2pDO0dBQ0EsVUFBVTtJQUNSLElBQUksV0FBVztLQUNiLDJCQUNFLGtCQUNBLElBQUksV0FDSixFQUNGO0tBQ0EsT0FBTyxNQUFNLElBQUksVUFBVTtLQUMzQixJQUFJLENBQUMsb0JBQTJCLGlCQUFpQix1QkFBdUI7TUFDdEUsSUFBSSxZQUFZO01BQ2hCLG1CQUFtQixHQUFHO0tBQ3hCO0tBQ0EsT0FBTyxJQUFJLFdBQVc7SUFDeEIsT0FBTyxJQUFJLENBQUMsb0JBQTJCLGVBQWU7S0FDcEQsT0FBTyw0Q0FBNEM7SUFDckQ7R0FDRjtHQUNBLFFBQVEsS0FBSyxPQUFPO0lBQ2xCLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLE9BQU8sUUFBUSxVQUFVO0tBQ3hFLElBQUksT0FBTyxRQUFRLFVBQVUsR0FBRyxHQUFHO01BQ2pDLE9BQ0UsMkNBQTJDLE9BQU8sR0FBRyxFQUFFLDhDQUN6RDtLQUNGLE9BQU87TUFDTCxPQUNFLDJDQUEyQyxPQUFPLEdBQUcsRUFBRSxnRkFDekQ7S0FDRjtJQUNGO0lBQ0EsUUFBUSxTQUFTLE9BQU87SUFDeEIsT0FBTztHQUNUO0dBQ0EsZUFBZSxJQUFJO0lBQ2pCLE1BQU0sVUFBVTtJQUNoQixhQUFhO0lBQ2IsSUFBSTtLQUNGLE9BQU8sR0FBRztJQUNaLFVBQVU7S0FDUixhQUFhO0lBQ2Y7R0FDRjtFQUNGO0VBQ0EsT0FBTztDQUNUO0FBQ0Y7QUFDQSxJQUFJLGFBQWE7QUFFakIsU0FBUyxTQUFTLE9BQU8sTUFBTSxVQUFVLFdBQVc7Q0FDbEQsTUFBTSxJQUFJLG1CQUFtQjtDQUM3QixJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixDQUFDLEdBQUc7RUFDbkQsT0FBTyw0Q0FBNEM7RUFDbkQsT0FBTyxJQUFJO0NBQ2I7Q0FDQSxNQUFNLGdCQUFnQixTQUFTLElBQUk7Q0FDbkMsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsQ0FBQyxFQUFFLGFBQWEsRUFBRSxDQUFDLGdCQUFnQjtFQUNsRixPQUFPLGdDQUFnQyxLQUFLLHlCQUF5QjtFQUNyRSxPQUFPLElBQUk7Q0FDYjtDQUNBLE1BQU0saUJBQWlCLFVBQVUsSUFBSTtDQUNyQyxNQUFNLFlBQVksa0JBQWtCLE9BQU8sYUFBYTtDQUN4RCxNQUFNLE1BQU0sV0FBVyxPQUFPLFlBQVk7RUFDeEMsSUFBSTtFQUNKLElBQUksZUFBZTtFQUNuQixJQUFJO0VBQ0osc0JBQXNCO0dBQ3BCLE1BQU0sWUFBWSxNQUFNO0dBQ3hCLElBQUksV0FBVyxZQUFZLFNBQVMsR0FBRztJQUNyQyxhQUFhO0lBQ2IsUUFBUTtHQUNWO0VBQ0YsQ0FBQztFQUNELE9BQU87R0FDTCxNQUFNO0lBQ0osTUFBTTtJQUNOLE9BQU8sUUFBUSxNQUFNLFFBQVEsSUFBSSxVQUFVLElBQUk7R0FDakQ7R0FDQSxJQUFJLE9BQU87SUFDVCxNQUFNLGVBQWUsUUFBUSxNQUFNLFFBQVEsSUFBSSxLQUFLLElBQUk7SUFDeEQsSUFBSSxDQUFDLFdBQVcsY0FBYyxVQUFVLEtBQUssRUFBRSxpQkFBaUIsYUFBYSxXQUFXLE9BQU8sWUFBWSxJQUFJO0tBQzdHO0lBQ0Y7SUFDQSxNQUFNLFdBQVcsRUFBRSxNQUFNO0lBQ3pCLE1BQU0sWUFBWSxDQUFDLEVBQUUsYUFDcEIsUUFBUSxZQUFZLGlCQUFpQixZQUFZLGtCQUFrQixjQUFjLFlBQVksVUFBVSxZQUFZLFlBQVksbUJBQW1CLFlBQVksWUFBWSxvQkFBb0I7SUFDL0wsSUFBSSxDQUFDLFdBQVc7S0FDZCxhQUFhO0tBQ2IsUUFBUTtJQUNWO0lBQ0EsRUFBRSxLQUFLLFVBQVUsUUFBUSxZQUFZO0lBQ3JDLElBQUksV0FBVyxPQUFPLFlBQVksTUFBTSxXQUFXLE9BQU8sWUFBWSxLQUFLLENBQUMsV0FBVyxjQUFjLGdCQUFnQixLQU1ySCxhQUFhLGlCQUFpQixhQUFhLENBQUMsV0FBVyxjQUFjLFVBQVUsSUFBSTtLQUNqRixRQUFRO0lBQ1Y7SUFDQSxlQUFlO0lBQ2YsbUJBQW1CO0dBQ3JCO0VBQ0Y7Q0FDRixDQUFDO0NBQ0QsSUFBSSxPQUFPLGtCQUFrQjtFQUMzQixJQUFJLEtBQUs7RUFDVCxPQUFPLEVBQ0wsT0FBTztHQUNMLElBQUksS0FBSyxHQUFHO0lBQ1YsT0FBTztLQUFFLE9BQU8sT0FBTyxhQUFhLFlBQVk7S0FBSyxNQUFNO0lBQU07R0FDbkUsT0FBTztJQUNMLE9BQU8sRUFBRSxNQUFNLEtBQUs7R0FDdEI7RUFDRixFQUNGO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxNQUFNLHFCQUFxQixPQUFPLGNBQWM7Q0FDOUMsT0FBTyxjQUFjLGdCQUFnQixjQUFjLGdCQUFnQixNQUFNLGlCQUFpQixNQUFNLEdBQUcsVUFBVSxlQUFlLE1BQU0sR0FBRyxTQUFTLFNBQVMsRUFBRSxlQUFlLE1BQU0sR0FBRyxVQUFVLFNBQVMsRUFBRTtBQUN4TTtBQUVBLFNBQVMsS0FBSyxVQUFVLE9BQU8sR0FBRyxTQUFTO0NBQ3pDLElBQUksU0FBUyxhQUFhO0NBQzFCLE1BQU0sUUFBUSxTQUFTLE1BQU0sU0FBUztDQUN0QyxJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDN0MsTUFBTSxFQUNKLGNBQ0EsY0FBYyxDQUFDLGtCQUNiO0VBQ0osSUFBSSxjQUFjO0dBQ2hCLElBQUksRUFBRSxTQUFTLGlCQUFpQixNQUFNO0lBQ3BDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxhQUFhLFNBQVMsS0FBSyxDQUFDLEtBQUssZUFBZTtLQUNyRSxPQUNFLDRCQUE0QixNQUFNLDhEQUE4RCxhQUFhLFNBQVMsS0FBSyxDQUFDLEVBQUUsUUFDaEk7SUFDRjtHQUNGLE9BQU87SUFDTCxNQUFNLFlBQVksYUFBYTtJQUMvQixJQUFJLFdBQVcsU0FBUyxHQUFHO0tBQ3pCLE1BQU0sVUFBVSxVQUFVLEdBQUcsT0FBTztLQUNwQyxJQUFJLENBQUMsU0FBUztNQUNaLE9BQ0UsK0RBQStELE1BQU0sR0FDdkU7S0FDRjtJQUNGO0dBQ0Y7RUFDRjtDQUNGO0NBQ0EsSUFBSSxPQUFPO0NBQ1gsTUFBTSxrQkFBa0IsTUFBTSxXQUFXLFNBQVM7Q0FDbEQsTUFBTSxZQUFZLG1CQUFtQixrQkFBa0IsT0FBTyxNQUFNLE1BQU0sQ0FBQyxDQUFDO0NBQzVFLElBQUksV0FBVztFQUNiLElBQUksVUFBVSxNQUFNO0dBQ2xCLE9BQU8sUUFBUSxLQUFLLE1BQU0sU0FBUyxDQUFDLElBQUksRUFBRSxLQUFLLElBQUksQ0FBQztFQUN0RDtFQUNBLElBQUksVUFBVSxRQUFRO0dBQ3BCLE9BQU8sUUFBUSxJQUFJLGFBQWE7RUFDbEM7Q0FDRjtDQUNBLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLHVCQUF1QjtFQUN0RSxzQkFBc0IsVUFBVSxPQUFPLElBQUk7Q0FDN0M7Q0FDQSxJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDN0MsTUFBTSxpQkFBaUIsTUFBTSxZQUFZO0VBQ3pDLElBQUksbUJBQW1CLFNBQVMsTUFBTSxhQUFhLGNBQWMsSUFBSTtHQUNuRSxPQUNFLFVBQVUsZUFBZSw0QkFBNEIsb0JBQ25ELFVBQ0EsU0FBUyxJQUNYLEVBQUUsc0NBQXNDLE1BQU0sZ0tBQWdLLFVBQzVNLEtBQ0YsRUFBRSxnQkFBZ0IsTUFBTSxHQUMxQjtFQUNGO0NBQ0Y7Q0FDQSxJQUFJO0NBQ0osSUFBSSxVQUFVLE1BQU0sY0FBYyxhQUFhLEtBQUssTUFDcEQsTUFBTSxjQUFjLGFBQWEsU0FBUyxLQUFLLENBQUM7Q0FDaEQsSUFBSSxDQUFDLFdBQVcsaUJBQWlCO0VBQy9CLFVBQVUsTUFBTSxjQUFjLGFBQWEsVUFBVSxLQUFLLENBQUM7Q0FDN0Q7Q0FDQSxJQUFJLFNBQVM7RUFDWCwyQkFDRSxTQUNBLFVBQ0EsR0FDQSxJQUNGO0NBQ0Y7Q0FDQSxNQUFNLGNBQWMsTUFBTSxjQUFjO0NBQ3hDLElBQUksYUFBYTtFQUNmLElBQUksQ0FBQyxTQUFTLFNBQVM7R0FDckIsU0FBUyxVQUFVLENBQUM7RUFDdEIsT0FBTyxJQUFJLFNBQVMsUUFBUSxjQUFjO0dBQ3hDO0VBQ0Y7RUFDQSxTQUFTLFFBQVEsZUFBZTtFQUNoQywyQkFDRSxhQUNBLFVBQ0EsR0FDQSxJQUNGO0NBQ0Y7QUFDRjtBQUNBLE1BQU0sa0NBQWtDLElBQUksUUFBUTtBQUNwRCxTQUFTLHNCQUFzQixNQUFNLFlBQVksVUFBVSxPQUFPO0NBQ2hFLE1BQU0sUUFBUSx1QkFBdUIsVUFBVSxrQkFBa0IsV0FBVztDQUM1RSxNQUFNLFNBQVMsTUFBTSxJQUFJLElBQUk7Q0FDN0IsSUFBSSxXQUFXLEtBQUssR0FBRztFQUNyQixPQUFPO0NBQ1Q7Q0FDQSxNQUFNLE1BQU0sS0FBSztDQUNqQixJQUFJLGFBQWEsQ0FBQztDQUNsQixJQUFJLGFBQWE7Q0FDakIsSUFBSSx1QkFBdUIsQ0FBQyxXQUFXLElBQUksR0FBRztFQUM1QyxNQUFNLGVBQWUsU0FBUztHQUM1QixNQUFNLHVCQUF1QixzQkFBc0IsTUFBTSxZQUFZLElBQUk7R0FDekUsSUFBSSxzQkFBc0I7SUFDeEIsYUFBYTtJQUNiLE9BQU8sWUFBWSxvQkFBb0I7R0FDekM7RUFDRjtFQUNBLElBQUksQ0FBQyxXQUFXLFdBQVcsT0FBTyxRQUFRO0dBQ3hDLFdBQVcsT0FBTyxRQUFRLFdBQVc7RUFDdkM7RUFDQSxJQUFJLEtBQUssU0FBUztHQUNoQixZQUFZLEtBQUssT0FBTztFQUMxQjtFQUNBLElBQUksS0FBSyxRQUFRO0dBQ2YsS0FBSyxPQUFPLFFBQVEsV0FBVztFQUNqQztDQUNGO0NBQ0EsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZO0VBQ3ZCLElBQUksU0FBUyxJQUFJLEdBQUc7R0FDbEIsTUFBTSxJQUFJLE1BQU0sSUFBSTtFQUN0QjtFQUNBLE9BQU87Q0FDVDtDQUNBLElBQUksUUFBUSxHQUFHLEdBQUc7RUFDaEIsSUFBSSxTQUFTLFFBQVEsV0FBVyxPQUFPLElBQUk7Q0FDN0MsT0FBTztFQUNMLE9BQU8sWUFBWSxHQUFHO0NBQ3hCO0NBQ0EsSUFBSSxTQUFTLElBQUksR0FBRztFQUNsQixNQUFNLElBQUksTUFBTSxVQUFVO0NBQzVCO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxlQUFlLFNBQVMsS0FBSztDQUNwQyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssR0FBRyxHQUFHO0VBQzFCLE9BQU87Q0FDVDtDQUNBLE1BQU0sSUFBSSxNQUFNLENBQUM7Q0FDakIsTUFBTSxRQUFRLFNBQVMsTUFBTSxJQUFJLFFBQVEsU0FBUyxFQUFFO0NBQ3BELE9BQU8sT0FBTyxTQUFTLElBQUksRUFBRSxDQUFDLFlBQVksSUFBSSxJQUFJLE1BQU0sQ0FBQyxDQUFDLEtBQUssT0FBTyxTQUFTLFVBQVUsR0FBRyxDQUFDLEtBQUssT0FBTyxTQUFTLEdBQUc7QUFDdkg7QUFFQSxJQUFJLGdCQUFnQjtBQUNwQixTQUFTLG9CQUFvQjtDQUMzQixnQkFBZ0I7QUFDbEI7QUFDQSxTQUFTLG9CQUFvQixVQUFVO0NBQ3JDLE1BQU0sRUFDSixNQUFNLFdBQ04sT0FDQSxPQUNBLFdBQ0EsY0FBYyxDQUFDLGVBQ2YsT0FDQSxPQUNBLE1BQ0EsUUFDQSxhQUNBLE9BQ0EsTUFDQSxZQUNBLEtBQ0EsaUJBQ0U7Q0FDSixNQUFNLE9BQU8sNEJBQTRCLFFBQVE7Q0FDakQsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDN0MsZ0JBQWdCO0NBQ2xCO0NBQ0EsSUFBSTtFQUNGLElBQUksTUFBTSxZQUFZLEdBQUc7R0FDdkIsTUFBTSxhQUFhLGFBQWE7R0FDaEMsTUFBTSxZQUFZLENBQUMsb0JBQTJCLGlCQUFpQixXQUFXLGtCQUFrQixJQUFJLE1BQU0sWUFBWSxFQUNoSCxJQUFJLFFBQVEsS0FBSyxVQUFVO0lBQ3pCLE9BQ0UsYUFBYSxPQUNYLEdBQ0YsRUFBRSw0REFDSjtJQUNBLE9BQU8sUUFBUSxJQUFJLFFBQVEsS0FBSyxRQUFRO0dBQzFDLEVBQ0YsQ0FBQyxJQUFJO0dBQ0wsU0FBUyxlQUNQLE9BQU8sS0FDTCxXQUNBLFlBQ0EsYUFDQSxDQUFDLG9CQUEyQixnQkFBZ0IsZ0JBQWdCLEtBQUssSUFBSSxPQUNyRSxZQUNBLE1BQ0EsR0FDRixDQUNGO0dBQ0EsbUJBQW1CO0VBQ3JCLE9BQU87R0FDTCxNQUFNLFVBQVU7R0FDaEIsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsVUFBVSxPQUFPO0lBQ2hFLGtCQUFrQjtHQUNwQjtHQUNBLFNBQVMsZUFDUCxRQUFRLFNBQVMsSUFBSSxRQUNuQixDQUFDLG9CQUEyQixnQkFBZ0IsZ0JBQWdCLEtBQUssSUFBSSxPQUNyRSxDQUFDLG9CQUEyQixnQkFBZ0I7SUFDMUMsSUFBSSxRQUFRO0tBQ1Ysa0JBQWtCO0tBQ2xCLE9BQU8sZ0JBQWdCLEtBQUs7SUFDOUI7SUFDQTtJQUNBO0dBQ0YsSUFBSTtJQUFFO0lBQU87SUFBTztHQUFLLENBQzNCLElBQUksUUFDRixDQUFDLG9CQUEyQixnQkFBZ0IsZ0JBQWdCLEtBQUssSUFBSSxPQUNyRSxJQUNGLENBQ0Y7R0FDQSxtQkFBbUIsVUFBVSxRQUFRLFFBQVEseUJBQXlCLEtBQUs7RUFDN0U7Q0FDRixTQUFTLEtBQUs7RUFDWixXQUFXLFNBQVM7RUFDcEIsWUFBWSxLQUFLLFVBQVUsQ0FBQztFQUM1QixTQUFTLFlBQVksT0FBTztDQUM5QjtDQUNBLElBQUksT0FBTztDQUNYLElBQUksVUFBVSxLQUFLO0NBQ25CLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLE9BQU8sWUFBWSxLQUFLLE9BQU8sWUFBWSxNQUFNO0VBQ2hHLENBQUMsTUFBTSxXQUFXLGFBQWEsTUFBTTtDQUN2QztDQUNBLElBQUksb0JBQW9CLGlCQUFpQixPQUFPO0VBQzlDLE1BQU0sT0FBTyxPQUFPLEtBQUssZ0JBQWdCO0VBQ3pDLE1BQU0sRUFBRSxjQUFjO0VBQ3RCLElBQUksS0FBSyxRQUFRO0dBQ2YsSUFBSSxhQUFhLElBQUksSUFBSTtJQUN2QixJQUFJLGdCQUFnQixLQUFLLEtBQUssZUFBZSxHQUFHO0tBQzlDLG1CQUFtQixxQkFDakIsa0JBQ0EsWUFDRjtJQUNGO0lBQ0EsT0FBTyxXQUFXLE1BQU0sa0JBQWtCLE9BQU8sSUFBSTtHQUN2RCxPQUFPLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLENBQUMsaUJBQWlCLEtBQUssU0FBUyxTQUFTO0lBQy9GLE1BQU0sV0FBVyxPQUFPLEtBQUssS0FBSztJQUNsQyxNQUFNLGFBQWEsQ0FBQztJQUNwQixNQUFNLGFBQWEsQ0FBQztJQUNwQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLElBQUksR0FBRyxLQUFLO0tBQy9DLE1BQU0sTUFBTSxTQUFTO0tBQ3JCLElBQUksS0FBSyxHQUFHLEdBQUc7TUFDYixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsR0FBRztPQUN6QixXQUFXLEtBQUssSUFBSSxFQUFFLENBQUMsWUFBWSxJQUFJLElBQUksTUFBTSxDQUFDLENBQUM7TUFDckQ7S0FDRixPQUFPO01BQ0wsV0FBVyxLQUFLLEdBQUc7S0FDckI7SUFDRjtJQUNBLElBQUksV0FBVyxRQUFRO0tBQ3JCLE9BQ0Usb0NBQW9DLFdBQVcsS0FBSyxJQUFJLEVBQUUsdUlBQzVEO0lBQ0Y7SUFDQSxJQUFJLFdBQVcsUUFBUTtLQUNyQixPQUNFLHlDQUF5QyxXQUFXLEtBQUssSUFBSSxFQUFFLDBPQUNqRTtJQUNGO0dBQ0Y7RUFDRjtDQUNGO0NBQ0EsSUFBSSxNQUFNLE1BQU07RUFDZCxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixDQUFDLGNBQWMsSUFBSSxHQUFHO0dBQ3JFLE9BQ0UsK0dBQ0Y7RUFDRjtFQUNBLE9BQU8sV0FBVyxNQUFNLE1BQU0sT0FBTyxJQUFJO0VBQ3pDLEtBQUssT0FBTyxLQUFLLE9BQU8sS0FBSyxLQUFLLE9BQU8sTUFBTSxJQUFJLElBQUksTUFBTTtDQUMvRDtDQUNBLElBQUksTUFBTSxZQUFZO0VBQ3BCLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLENBQUMsY0FBYyxJQUFJLEdBQUc7R0FDckUsT0FDRSxzRkFDRjtFQUNGO0VBQ0EsbUJBQW1CLE1BQU0sTUFBTSxVQUFVO0NBQzNDO0NBQ0EsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsU0FBUztFQUN4RCxRQUFRLElBQUk7Q0FDZCxPQUFPO0VBQ0wsU0FBUztDQUNYO0NBQ0EsNEJBQTRCLElBQUk7Q0FDaEMsT0FBTztBQUNUO0FBQ0EsTUFBTSxnQkFBZ0IsVUFBVTtDQUM5QixNQUFNLGNBQWMsTUFBTTtDQUMxQixNQUFNLGtCQUFrQixNQUFNO0NBQzlCLE1BQU0sWUFBWSxpQkFBaUIsYUFBYSxLQUFLO0NBQ3JELElBQUksQ0FBQyxXQUFXO0VBQ2QsT0FBTyxDQUFDLE9BQU8sS0FBSyxDQUFDO0NBQ3ZCLE9BQU8sSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsVUFBVSxZQUFZLEtBQUssVUFBVSxZQUFZLE1BQU07RUFDN0csT0FBTyxhQUFhLFNBQVM7Q0FDL0I7Q0FDQSxNQUFNLFFBQVEsWUFBWSxRQUFRLFNBQVM7Q0FDM0MsTUFBTSxlQUFlLGtCQUFrQixnQkFBZ0IsUUFBUSxTQUFTLElBQUksQ0FBQztDQUM3RSxNQUFNLFdBQVcsZ0JBQWdCO0VBQy9CLFlBQVksU0FBUztFQUNyQixJQUFJLGlCQUFpQjtHQUNuQixJQUFJLGVBQWUsQ0FBQyxHQUFHO0lBQ3JCLGdCQUFnQixnQkFBZ0I7R0FDbEMsT0FBTyxJQUFJLFlBQVksWUFBWSxHQUFHO0lBQ3BDLE1BQU0sa0JBQWtCLENBQUMsR0FBRyxpQkFBaUIsV0FBVztHQUMxRDtFQUNGO0NBQ0Y7Q0FDQSxPQUFPLENBQUMsZUFBZSxTQUFTLEdBQUcsT0FBTztBQUM1QztBQUNBLFNBQVMsaUJBQWlCLFVBQVUsVUFBVSxNQUFNO0NBQ2xELElBQUk7Q0FDSixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7RUFDeEMsTUFBTSxRQUFRLFNBQVM7RUFDdkIsSUFBSSxRQUFRLEtBQUssR0FBRztHQUNsQixJQUFJLE1BQU0sU0FBUyxXQUFXLE1BQU0sYUFBYSxRQUFRO0lBQ3ZELElBQUksWUFBWTtLQUNkO0lBQ0YsT0FBTztLQUNMLGFBQWE7S0FDYixJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixXQUFXLFdBQVcsWUFBWSxLQUFLLFdBQVcsWUFBWSxNQUFNO01BQ25ILE9BQU8saUJBQWlCLFdBQVcsUUFBUTtLQUM3QztJQUNGO0dBQ0Y7RUFDRixPQUFPO0dBQ0w7RUFDRjtDQUNGO0NBQ0EsT0FBTztBQUNUO0FBQ0EsTUFBTSw0QkFBNEIsVUFBVTtDQUMxQyxJQUFJO0NBQ0osS0FBSyxNQUFNLE9BQU8sT0FBTztFQUN2QixJQUFJLFFBQVEsV0FBVyxRQUFRLFdBQVcsS0FBSyxHQUFHLEdBQUc7R0FDbkQsQ0FBQyxRQUFRLE1BQU0sQ0FBQyxHQUFFLENBQUUsT0FBTyxNQUFNO0VBQ25DO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxNQUFNLHdCQUF3QixPQUFPLFVBQVU7Q0FDN0MsTUFBTSxNQUFNLENBQUM7Q0FDYixLQUFLLE1BQU0sT0FBTyxPQUFPO0VBQ3ZCLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxLQUFLLEVBQUUsSUFBSSxNQUFNLENBQUMsS0FBSyxRQUFRO0dBQ3JELElBQUksT0FBTyxNQUFNO0VBQ25CO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxNQUFNLGlCQUFpQixVQUFVO0NBQy9CLE9BQU8sTUFBTSxhQUFhLElBQUksTUFBTSxNQUFNLFNBQVM7QUFDckQ7QUFDQSxTQUFTLHNCQUFzQixXQUFXLFdBQVcsV0FBVztDQUM5RCxNQUFNLEVBQUUsT0FBTyxXQUFXLFVBQVUsY0FBYyxjQUFjO0NBQ2hFLE1BQU0sRUFBRSxPQUFPLFdBQVcsVUFBVSxjQUFjLGNBQWM7Q0FDaEUsTUFBTSxRQUFRLFVBQVU7Q0FDeEIsSUFBSSxDQUFDLG9CQUEyQixrQkFBa0IsZ0JBQWdCLGlCQUFpQixlQUFlO0VBQ2hHLE9BQU87Q0FDVDtDQUNBLElBQUksVUFBVSxRQUFRLFVBQVUsWUFBWTtFQUMxQyxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLGFBQWEsYUFBYSxHQUFHO0VBQy9CLElBQUksWUFBWSxNQUFNO0dBQ3BCLE9BQU87RUFDVDtFQUNBLElBQUksWUFBWSxJQUFJO0dBQ2xCLElBQUksQ0FBQyxXQUFXO0lBQ2QsT0FBTyxDQUFDLENBQUM7R0FDWDtHQUNBLE9BQU8sZ0JBQWdCLFdBQVcsV0FBVyxLQUFLO0VBQ3BELE9BQU8sSUFBSSxZQUFZLEdBQUc7R0FDeEIsTUFBTSxlQUFlLFVBQVU7R0FDL0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGFBQWEsUUFBUSxLQUFLO0lBQzVDLE1BQU0sTUFBTSxhQUFhO0lBQ3pCLElBQUksb0JBQW9CLFdBQVcsV0FBVyxHQUFHLEtBQUssQ0FBQyxlQUFlLE9BQU8sR0FBRyxHQUFHO0tBQ2pGLE9BQU87SUFDVDtHQUNGO0VBQ0Y7Q0FDRixPQUFPO0VBQ0wsSUFBSSxnQkFBZ0IsY0FBYztHQUNoQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxTQUFTO0lBQzFDLE9BQU87R0FDVDtFQUNGO0VBQ0EsSUFBSSxjQUFjLFdBQVc7R0FDM0IsT0FBTztFQUNUO0VBQ0EsSUFBSSxDQUFDLFdBQVc7R0FDZCxPQUFPLENBQUMsQ0FBQztFQUNYO0VBQ0EsSUFBSSxDQUFDLFdBQVc7R0FDZCxPQUFPO0VBQ1Q7RUFDQSxPQUFPLGdCQUFnQixXQUFXLFdBQVcsS0FBSztDQUNwRDtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsZ0JBQWdCLFdBQVcsV0FBVyxjQUFjO0NBQzNELE1BQU0sV0FBVyxPQUFPLEtBQUssU0FBUztDQUN0QyxJQUFJLFNBQVMsV0FBVyxPQUFPLEtBQUssU0FBUyxDQUFDLENBQUMsUUFBUTtFQUNyRCxPQUFPO0NBQ1Q7Q0FDQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7RUFDeEMsTUFBTSxNQUFNLFNBQVM7RUFDckIsSUFBSSxvQkFBb0IsV0FBVyxXQUFXLEdBQUcsS0FBSyxDQUFDLGVBQWUsY0FBYyxHQUFHLEdBQUc7R0FDeEYsT0FBTztFQUNUO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLG9CQUFvQixXQUFXLFdBQVcsS0FBSztDQUN0RCxNQUFNLFdBQVcsVUFBVTtDQUMzQixNQUFNLFdBQVcsVUFBVTtDQUMzQixJQUFJLFFBQVEsV0FBVyxTQUFTLFFBQVEsS0FBSyxTQUFTLFFBQVEsR0FBRztFQUMvRCxPQUFPLENBQUMsV0FBVyxVQUFVLFFBQVE7Q0FDdkM7Q0FDQSxPQUFPLGFBQWE7QUFDdEI7QUFDQSxTQUFTLGdCQUFnQixFQUFFLE9BQU8sUUFBUSxZQUFZLElBQUk7Q0FDeEQsT0FBTyxRQUFRO0VBQ2IsTUFBTSxPQUFPLE9BQU87RUFDcEIsSUFBSSxLQUFLLFlBQVksS0FBSyxTQUFTLGlCQUFpQixPQUFPO0dBQ3pELEtBQUssU0FBUyxNQUFNLEtBQUssS0FBSyxLQUFLO0dBQ25DLFFBQVE7RUFDVjtFQUNBLElBQUksU0FBUyxPQUFPO0dBQ2xCLENBQUMsUUFBUSxPQUFPLE1BQUssQ0FBRSxLQUFLO0dBQzVCLFNBQVMsT0FBTztFQUNsQixPQUFPO0dBQ0w7RUFDRjtDQUNGO0NBQ0EsSUFBSSxZQUFZLFNBQVMsaUJBQWlCLE9BQU87RUFDL0MsU0FBUyxNQUFNLEtBQUs7Q0FDdEI7QUFDRjtBQUVBLE1BQU0sc0JBQXNCLENBQUM7QUFDN0IsTUFBTSw2QkFBNkIsT0FBTyxPQUFPLG1CQUFtQjtBQUNwRSxNQUFNLG9CQUFvQixRQUFRLE9BQU8sZUFBZSxHQUFHLE1BQU07QUFFakUsU0FBUyxVQUFVLFVBQVUsVUFBVSxZQUFZLFFBQVEsT0FBTztDQUNoRSxNQUFNLFFBQVEsQ0FBQztDQUNmLE1BQU0sUUFBUSxxQkFBcUI7Q0FDbkMsU0FBUyxnQkFBZ0MsdUJBQU8sT0FBTyxJQUFJO0NBQzNELGFBQWEsVUFBVSxVQUFVLE9BQU8sS0FBSztDQUM3QyxLQUFLLE1BQU0sT0FBTyxTQUFTLGFBQWEsSUFBSTtFQUMxQyxJQUFJLEVBQUUsT0FBTyxRQUFRO0dBQ25CLE1BQU0sT0FBTyxLQUFLO0VBQ3BCO0NBQ0Y7Q0FDQSxJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDN0MsY0FBYyxZQUFZLENBQUMsR0FBRyxPQUFPLFFBQVE7Q0FDL0M7Q0FDQSxJQUFJLFlBQVk7RUFDZCxTQUFTLFFBQVEsUUFBUSxRQUFRLGdCQUFnQixLQUFLO0NBQ3hELE9BQU87RUFDTCxJQUFJLENBQUMsU0FBUyxLQUFLLE9BQU87R0FDeEIsU0FBUyxRQUFRO0VBQ25CLE9BQU87R0FDTCxTQUFTLFFBQVE7RUFDbkI7Q0FDRjtDQUNBLFNBQVMsUUFBUTtBQUNuQjtBQUNBLFNBQVMsZUFBZSxVQUFVO0NBQ2hDLE9BQU8sVUFBVTtFQUNmLElBQUksU0FBUyxLQUFLLFNBQVMsT0FBTztFQUNsQyxXQUFXLFNBQVM7Q0FDdEI7QUFDRjtBQUNBLFNBQVMsWUFBWSxVQUFVLFVBQVUsY0FBYyxXQUFXO0NBQ2hFLE1BQU0sRUFDSixPQUNBLE9BQ0EsT0FBTyxFQUFFLGdCQUNQO0NBQ0osTUFBTSxrQkFBa0IsTUFBTSxLQUFLO0NBQ25DLE1BQU0sQ0FBQyxXQUFXLFNBQVM7Q0FDM0IsSUFBSSxrQkFBa0I7Q0FDdEIsSUFJRSxFQUFFLENBQUMsb0JBQTJCLGlCQUFpQixlQUFlLFFBQVEsT0FBTyxhQUFhLFlBQVksTUFBTSxFQUFFLFlBQVksS0FDMUg7RUFDQSxJQUFJLFlBQVksR0FBRztHQUNqQixNQUFNLGdCQUFnQixTQUFTLE1BQU07R0FDckMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGNBQWMsUUFBUSxLQUFLO0lBQzdDLElBQUksTUFBTSxjQUFjO0lBQ3hCLElBQUksZUFBZSxTQUFTLGNBQWMsR0FBRyxHQUFHO0tBQzlDO0lBQ0Y7SUFDQSxNQUFNLFFBQVEsU0FBUztJQUN2QixJQUFJLFNBQVM7S0FDWCxJQUFJLE9BQU8sT0FBTyxHQUFHLEdBQUc7TUFDdEIsSUFBSSxVQUFVLE1BQU0sTUFBTTtPQUN4QixNQUFNLE9BQU87T0FDYixrQkFBa0I7TUFDcEI7S0FDRixPQUFPO01BQ0wsTUFBTSxlQUFlLFNBQVMsR0FBRztNQUNqQyxNQUFNLGdCQUFnQixpQkFDcEIsU0FDQSxpQkFDQSxjQUNBLE9BQ0EsVUFDQSxLQUNGO0tBQ0Y7SUFDRixPQUFPO0tBQ0wsSUFBSSxVQUFVLE1BQU0sTUFBTTtNQUN4QixNQUFNLE9BQU87TUFDYixrQkFBa0I7S0FDcEI7SUFDRjtHQUNGO0VBQ0Y7Q0FDRixPQUFPO0VBQ0wsSUFBSSxhQUFhLFVBQVUsVUFBVSxPQUFPLEtBQUssR0FBRztHQUNsRCxrQkFBa0I7RUFDcEI7RUFDQSxJQUFJO0VBQ0osS0FBSyxNQUFNLE9BQU8saUJBQWlCO0dBQ2pDLElBQUksQ0FBQyxZQUNMLENBQUMsT0FBTyxVQUFVLEdBQUcsT0FFbkIsV0FBVyxVQUFVLEdBQUcsT0FBTyxPQUFPLENBQUMsT0FBTyxVQUFVLFFBQVEsSUFBSTtJQUNwRSxJQUFJLFNBQVM7S0FDWCxJQUFJLGlCQUNILGFBQWEsU0FBUyxLQUFLLEtBQzVCLGFBQWEsY0FBYyxLQUFLLElBQUk7TUFDbEMsTUFBTSxPQUFPLGlCQUNYLFNBQ0EsaUJBQ0EsS0FDQSxLQUFLLEdBQ0wsVUFDQSxJQUNGO0tBQ0Y7SUFDRixPQUFPO0tBQ0wsT0FBTyxNQUFNO0lBQ2Y7R0FDRjtFQUNGO0VBQ0EsSUFBSSxVQUFVLGlCQUFpQjtHQUM3QixLQUFLLE1BQU0sT0FBTyxPQUFPO0lBQ3ZCLElBQUksQ0FBQyxZQUFZLENBQUMsT0FBTyxVQUFVLEdBQUcsS0FBSyxNQUFNO0tBQy9DLE9BQU8sTUFBTTtLQUNiLGtCQUFrQjtJQUNwQjtHQUNGO0VBQ0Y7Q0FDRjtDQUNBLElBQUksaUJBQWlCO0VBQ25CLFFBQVEsU0FBUyxPQUFPLE9BQU8sRUFBRTtDQUNuQztDQUNBLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtFQUM3QyxjQUFjLFlBQVksQ0FBQyxHQUFHLE9BQU8sUUFBUTtDQUMvQztBQUNGO0FBQ0EsU0FBUyxhQUFhLFVBQVUsVUFBVSxPQUFPLE9BQU87Q0FDdEQsTUFBTSxDQUFDLFNBQVMsZ0JBQWdCLFNBQVM7Q0FDekMsSUFBSSxrQkFBa0I7Q0FDdEIsSUFBSTtDQUNKLElBQUksVUFBVTtFQUNaLEtBQUssSUFBSSxPQUFPLFVBQVU7R0FDeEIsSUFBSSxlQUFlLEdBQUcsR0FBRztJQUN2QjtHQUNGO0dBQ0EsTUFBTSxRQUFRLFNBQVM7R0FDdkIsSUFBSTtHQUNKLElBQUksV0FBVyxPQUFPLFNBQVMsV0FBVyxTQUFTLEdBQUcsQ0FBQyxHQUFHO0lBQ3hELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLFNBQVMsUUFBUSxHQUFHO0tBQ3JELE1BQU0sWUFBWTtJQUNwQixPQUFPO0tBQ0wsQ0FBQyxrQkFBa0IsZ0JBQWdCLENBQUMsR0FBRSxDQUFFLFlBQVk7SUFDdEQ7R0FDRixPQUFPLElBQUksQ0FBQyxlQUFlLFNBQVMsY0FBYyxHQUFHLEdBQUc7SUFDdEQsSUFBSSxFQUFFLE9BQU8sVUFBVSxVQUFVLE1BQU0sTUFBTTtLQUMzQyxNQUFNLE9BQU87S0FDYixrQkFBa0I7SUFDcEI7R0FDRjtFQUNGO0NBQ0Y7Q0FDQSxJQUFJLGNBQWM7RUFDaEIsTUFBTSxrQkFBa0IsTUFBTSxLQUFLO0VBQ25DLE1BQU0sYUFBYSxpQkFBaUI7RUFDcEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGFBQWEsUUFBUSxLQUFLO0dBQzVDLE1BQU0sTUFBTSxhQUFhO0dBQ3pCLE1BQU0sT0FBTyxpQkFDWCxTQUNBLGlCQUNBLEtBQ0EsV0FBVyxNQUNYLFVBQ0EsQ0FBQyxPQUFPLFlBQVksR0FBRyxDQUN6QjtFQUNGO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGlCQUFpQixTQUFTLE9BQU8sS0FBSyxPQUFPLFVBQVUsVUFBVTtDQUN4RSxNQUFNLE1BQU0sUUFBUTtDQUNwQixJQUFJLE9BQU8sTUFBTTtFQUNmLE1BQU0sYUFBYSxPQUFPLEtBQUssU0FBUztFQUN4QyxJQUFJLGNBQWMsVUFBVSxLQUFLLEdBQUc7R0FDbEMsTUFBTSxlQUFlLElBQUk7R0FDekIsSUFBSSxJQUFJLFNBQVMsWUFBWSxDQUFDLElBQUksZUFBZSxXQUFXLFlBQVksR0FBRztJQUN6RSxNQUFNLEVBQUUsa0JBQWtCO0lBQzFCLElBQUksT0FBTyxlQUFlO0tBQ3hCLFFBQVEsY0FBYztJQUN4QixPQUFPO0tBQ0wsTUFBTSxRQUFRLG1CQUFtQixRQUFRO0tBQ3pDLFFBQVEsY0FBYyxPQUFPLGFBQWEsS0FDeEMsTUFDQSxLQUNGO0tBQ0EsTUFBTTtJQUNSO0dBQ0YsT0FBTztJQUNMLFFBQVE7R0FDVjtHQUNBLElBQUksU0FBUyxJQUFJO0lBQ2YsU0FBUyxHQUFHLFNBQVMsS0FBSyxLQUFLO0dBQ2pDO0VBQ0Y7RUFDQSxJQUFJLElBQUksSUFBcUI7R0FDM0IsSUFBSSxZQUFZLENBQUMsWUFBWTtJQUMzQixRQUFRO0dBQ1YsT0FBTyxJQUFJLElBQUksT0FBNEIsVUFBVSxNQUFNLFVBQVUsVUFBVSxHQUFHLElBQUk7SUFDcEYsUUFBUTtHQUNWO0VBQ0Y7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBLE1BQU0sa0NBQWtDLElBQUksUUFBUTtBQUNwRCxTQUFTLHNCQUFzQixNQUFNLFlBQVksVUFBVSxPQUFPO0NBQ2hFLE1BQU0sUUFBUSx1QkFBdUIsVUFBVSxrQkFBa0IsV0FBVztDQUM1RSxNQUFNLFNBQVMsTUFBTSxJQUFJLElBQUk7Q0FDN0IsSUFBSSxRQUFRO0VBQ1YsT0FBTztDQUNUO0NBQ0EsTUFBTSxNQUFNLEtBQUs7Q0FDakIsTUFBTSxhQUFhLENBQUM7Q0FDcEIsTUFBTSxlQUFlLENBQUM7Q0FDdEIsSUFBSSxhQUFhO0NBQ2pCLElBQUksdUJBQXVCLENBQUMsV0FBVyxJQUFJLEdBQUc7RUFDNUMsTUFBTSxlQUFlLFNBQVM7R0FDNUIsYUFBYTtHQUNiLE1BQU0sQ0FBQyxPQUFPLFFBQVEsc0JBQXNCLE1BQU0sWUFBWSxJQUFJO0dBQ2xFLE9BQU8sWUFBWSxLQUFLO0dBQ3hCLElBQUksTUFBTSxhQUFhLEtBQUssR0FBRyxJQUFJO0VBQ3JDO0VBQ0EsSUFBSSxDQUFDLFdBQVcsV0FBVyxPQUFPLFFBQVE7R0FDeEMsV0FBVyxPQUFPLFFBQVEsV0FBVztFQUN2QztFQUNBLElBQUksS0FBSyxTQUFTO0dBQ2hCLFlBQVksS0FBSyxPQUFPO0VBQzFCO0VBQ0EsSUFBSSxLQUFLLFFBQVE7R0FDZixLQUFLLE9BQU8sUUFBUSxXQUFXO0VBQ2pDO0NBQ0Y7Q0FDQSxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVk7RUFDdkIsSUFBSSxTQUFTLElBQUksR0FBRztHQUNsQixNQUFNLElBQUksTUFBTSxTQUFTO0VBQzNCO0VBQ0EsT0FBTztDQUNUO0NBQ0EsSUFBSSxRQUFRLEdBQUcsR0FBRztFQUNoQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUs7R0FDbkMsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsQ0FBQyxTQUFTLElBQUksRUFBRSxHQUFHO0lBQ2xFLE9BQU8sa0RBQWtELElBQUksRUFBRTtHQUNqRTtHQUNBLE1BQU0sZ0JBQWdCLFNBQVMsSUFBSSxFQUFFO0dBQ3JDLElBQUksaUJBQWlCLGFBQWEsR0FBRztJQUNuQyxXQUFXLGlCQUFpQjtHQUM5QjtFQUNGO0NBQ0YsT0FBTyxJQUFJLEtBQUs7RUFDZCxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixDQUFDLFNBQVMsR0FBRyxHQUFHO0dBQy9ELE9BQU8seUJBQXlCLEdBQUc7RUFDckM7RUFDQSxLQUFLLE1BQU0sT0FBTyxLQUFLO0dBQ3JCLE1BQU0sZ0JBQWdCLFNBQVMsR0FBRztHQUNsQyxJQUFJLGlCQUFpQixhQUFhLEdBQUc7SUFDbkMsTUFBTSxNQUFNLElBQUk7SUFDaEIsTUFBTSxPQUFPLFdBQVcsaUJBQWlCLFFBQVEsR0FBRyxLQUFLLFdBQVcsR0FBRyxJQUFJLEVBQUUsTUFBTSxJQUFJLElBQUksT0FBTyxDQUFDLEdBQUcsR0FBRztJQUN6RyxNQUFNLFdBQVcsS0FBSztJQUN0QixJQUFJLGFBQWE7SUFDakIsSUFBSSxpQkFBaUI7SUFDckIsSUFBSSxRQUFRLFFBQVEsR0FBRztLQUNyQixLQUFLLElBQUksUUFBUSxHQUFHLFFBQVEsU0FBUyxRQUFRLEVBQUUsT0FBTztNQUNwRCxNQUFNLE9BQU8sU0FBUztNQUN0QixNQUFNLFdBQVcsV0FBVyxJQUFJLEtBQUssS0FBSztNQUMxQyxJQUFJLGFBQWEsV0FBVztPQUMxQixhQUFhO09BQ2I7TUFDRixPQUFPLElBQUksYUFBYSxVQUFVO09BQ2hDLGlCQUFpQjtNQUNuQjtLQUNGO0lBQ0YsT0FBTztLQUNMLGFBQWEsV0FBVyxRQUFRLEtBQUssU0FBUyxTQUFTO0lBQ3pEO0lBQ0EsS0FBSyxLQUFzQjtJQUMzQixLQUFLLEtBQTBCO0lBQy9CLElBQUksY0FBYyxPQUFPLE1BQU0sU0FBUyxHQUFHO0tBQ3pDLGFBQWEsS0FBSyxhQUFhO0lBQ2pDO0dBQ0Y7RUFDRjtDQUNGO0NBQ0EsTUFBTSxNQUFNLENBQUMsWUFBWSxZQUFZO0NBQ3JDLElBQUksU0FBUyxJQUFJLEdBQUc7RUFDbEIsTUFBTSxJQUFJLE1BQU0sR0FBRztDQUNyQjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsaUJBQWlCLEtBQUs7Q0FDN0IsSUFBSSxJQUFJLE9BQU8sT0FBTyxDQUFDLGVBQWUsR0FBRyxHQUFHO0VBQzFDLE9BQU87Q0FDVCxPQUFPLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtFQUNwRCxPQUFPLHVCQUF1QixJQUFJLDBCQUEwQjtDQUM5RDtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsUUFBUSxNQUFNO0NBQ3JCLElBQUksU0FBUyxNQUFNO0VBQ2pCLE9BQU87Q0FDVDtDQUNBLElBQUksT0FBTyxTQUFTLFlBQVk7RUFDOUIsT0FBTyxLQUFLLFFBQVE7Q0FDdEIsT0FBTyxJQUFJLE9BQU8sU0FBUyxVQUFVO0VBQ25DLE1BQU0sT0FBTyxLQUFLLGVBQWUsS0FBSyxZQUFZO0VBQ2xELE9BQU8sUUFBUTtDQUNqQjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsY0FBYyxVQUFVLE9BQU8sVUFBVTtDQUNoRCxNQUFNLGlCQUFpQixNQUFNLEtBQUs7Q0FDbEMsTUFBTSxVQUFVLFNBQVMsYUFBYTtDQUN0QyxNQUFNLG1CQUFtQixPQUFPLEtBQUssUUFBUSxDQUFDLENBQUMsS0FBSyxRQUFRLFNBQVMsR0FBRyxDQUFDO0NBQ3pFLEtBQUssTUFBTSxPQUFPLFNBQVM7RUFDekIsSUFBSSxNQUFNLFFBQVE7RUFDbEIsSUFBSSxPQUFPLE1BQU07RUFDakIsYUFDRSxLQUNBLGVBQWUsTUFDZixLQUNBLENBQUMsb0JBQTJCLGdCQUFnQixnQkFBZ0IsY0FBYyxJQUFJLGdCQUM5RSxDQUFDLGlCQUFpQixTQUFTLEdBQUcsQ0FDaEM7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxhQUFhLE1BQU0sT0FBTyxNQUFNLE9BQU8sVUFBVTtDQUN4RCxNQUFNLEVBQUUsTUFBTSxVQUFVLFdBQVcsY0FBYztDQUNqRCxJQUFJLFlBQVksVUFBVTtFQUN4QixPQUFPLDhCQUE2QixPQUFPLElBQUc7RUFDOUM7Q0FDRjtDQUNBLElBQUksU0FBUyxRQUFRLENBQUMsVUFBVTtFQUM5QjtDQUNGO0NBQ0EsSUFBSSxRQUFRLFFBQVEsU0FBUyxRQUFRLENBQUMsV0FBVztFQUMvQyxJQUFJLFVBQVU7RUFDZCxNQUFNLFFBQVEsUUFBUSxJQUFJLElBQUksT0FBTyxDQUFDLElBQUk7RUFDMUMsTUFBTSxnQkFBZ0IsQ0FBQztFQUN2QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxVQUFVLENBQUMsU0FBUyxLQUFLO0dBQ2pELE1BQU0sRUFBRSxPQUFPLGlCQUFpQixXQUFXLE9BQU8sTUFBTSxFQUFFO0dBQzFELGNBQWMsS0FBSyxnQkFBZ0IsRUFBRTtHQUNyQyxVQUFVO0VBQ1o7RUFDQSxJQUFJLENBQUMsU0FBUztHQUNaLE9BQU8sc0JBQXNCLE1BQU0sT0FBTyxhQUFhLENBQUM7R0FDeEQ7RUFDRjtDQUNGO0NBQ0EsSUFBSSxhQUFhLENBQUMsVUFBVSxPQUFPLEtBQUssR0FBRztFQUN6QyxPQUFPLDREQUEyRCxPQUFPLEtBQUk7Q0FDL0U7QUFDRjtBQUNBLE1BQU0sZUFBK0Isd0JBQ25DLDhDQUNGO0FBQ0EsU0FBUyxXQUFXLE9BQU8sTUFBTTtDQUMvQixJQUFJO0NBQ0osTUFBTSxlQUFlLFFBQVEsSUFBSTtDQUNqQyxJQUFJLGlCQUFpQixRQUFRO0VBQzNCLFFBQVEsVUFBVTtDQUNwQixPQUFPLElBQUksYUFBYSxZQUFZLEdBQUc7RUFDckMsTUFBTSxJQUFJLE9BQU87RUFDakIsUUFBUSxNQUFNLGFBQWEsWUFBWTtFQUN2QyxJQUFJLENBQUMsU0FBUyxNQUFNLFVBQVU7R0FDNUIsUUFBUSxpQkFBaUI7RUFDM0I7Q0FDRixPQUFPLElBQUksaUJBQWlCLFVBQVU7RUFDcEMsUUFBUSxTQUFTLEtBQUs7Q0FDeEIsT0FBTyxJQUFJLGlCQUFpQixTQUFTO0VBQ25DLFFBQVEsUUFBUSxLQUFLO0NBQ3ZCLE9BQU87RUFDTCxRQUFRLGlCQUFpQjtDQUMzQjtDQUNBLE9BQU87RUFDTDtFQUNBO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsc0JBQXNCLE1BQU0sT0FBTyxlQUFlO0NBQ3pELElBQUksY0FBYyxXQUFXLEdBQUc7RUFDOUIsT0FBTywwQkFBMEIsS0FBSztDQUN4QztDQUNBLElBQUksVUFBVSw2Q0FBNkMsS0FBSyxjQUFjLGNBQWMsSUFBSSxVQUFVLENBQUMsQ0FBQyxLQUFLLEtBQUs7Q0FDdEgsTUFBTSxlQUFlLGNBQWM7Q0FDbkMsTUFBTSxlQUFlLFVBQVUsS0FBSztDQUNwQyxNQUFNLGdCQUFnQixXQUFXLE9BQU8sWUFBWTtDQUNwRCxNQUFNLGdCQUFnQixXQUFXLE9BQU8sWUFBWTtDQUNwRCxJQUFJLGNBQWMsV0FBVyxLQUFLLGFBQWEsWUFBWSxLQUFLLFlBQVksY0FBYyxZQUFZLEdBQUc7RUFDdkcsV0FBVyxlQUFlO0NBQzVCO0NBQ0EsV0FBVyxTQUFTLGFBQWE7Q0FDakMsSUFBSSxhQUFhLFlBQVksR0FBRztFQUM5QixXQUFXLGNBQWMsY0FBYztDQUN6QztDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsV0FBVyxPQUFPLE1BQU07Q0FDL0IsSUFBSSxTQUFTLEtBQUssR0FBRztFQUNuQixPQUFPLE1BQU0sU0FBUztDQUN4QixPQUFPLElBQUksU0FBUyxVQUFVO0VBQzVCLE9BQU8sSUFBSSxNQUFNO0NBQ25CLE9BQU8sSUFBSSxTQUFTLFVBQVU7RUFDNUIsT0FBTyxHQUFHLE9BQU8sS0FBSztDQUN4QixPQUFPO0VBQ0wsT0FBTyxHQUFHO0NBQ1o7QUFDRjtBQUNBLFNBQVMsYUFBYSxNQUFNO0NBQzFCLE1BQU0sZ0JBQWdCO0VBQUM7RUFBVTtFQUFVO0NBQVM7Q0FDcEQsT0FBTyxjQUFjLE1BQU0sU0FBUyxLQUFLLFlBQVksTUFBTSxJQUFJO0FBQ2pFO0FBQ0EsU0FBUyxZQUFZLEdBQUcsTUFBTTtDQUM1QixPQUFPLEtBQUssT0FBTyxTQUFTO0VBQzFCLE1BQU0sUUFBUSxLQUFLLFlBQVk7RUFDL0IsT0FBTyxVQUFVLGFBQWEsVUFBVTtDQUMxQyxDQUFDO0FBQ0g7QUFFQSxNQUFNLGlCQUFpQixRQUFRLFFBQVEsT0FBTyxRQUFRLFVBQVUsUUFBUTtBQUN4RSxNQUFNLHNCQUFzQixVQUFVLFFBQVEsS0FBSyxJQUFJLE1BQU0sSUFBSSxjQUFjLElBQUksQ0FBQyxlQUFlLEtBQUssQ0FBQztBQUN6RyxNQUFNLGlCQUFpQixLQUFLLFNBQVMsUUFBUTtDQUMzQyxJQUFJLFFBQVEsSUFBSTtFQUNkLE9BQU87Q0FDVDtDQUNBLE1BQU0sYUFBYSxTQUFTLEdBQUcsU0FBUztFQUN0QyxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixtQkFBbUIsRUFBRSxRQUFRLFFBQVEsNkJBQTZCLEVBQUUsT0FBTyxJQUFJLFNBQVMsZ0JBQWdCLE9BQU87R0FDOUosT0FDRSxTQUFTLElBQUksMEpBQ2Y7RUFDRjtFQUNBLE9BQU8sbUJBQW1CLFFBQVEsR0FBRyxJQUFJLENBQUM7Q0FDNUMsR0FBRyxHQUFHO0NBQ04sV0FBVyxLQUFLO0NBQ2hCLE9BQU87QUFDVDtBQUNBLE1BQU0sd0JBQXdCLFVBQVUsT0FBTyxhQUFhO0NBQzFELE1BQU0sTUFBTSxTQUFTO0NBQ3JCLEtBQUssTUFBTSxPQUFPLFVBQVU7RUFDMUIsSUFBSSxjQUFjLEdBQUcsR0FBRztFQUN4QixNQUFNLFFBQVEsU0FBUztFQUN2QixJQUFJLFdBQVcsS0FBSyxHQUFHO0dBQ3JCLE1BQU0sT0FBTyxjQUFjLEtBQUssT0FBTyxHQUFHO0VBQzVDLE9BQU8sSUFBSSxTQUFTLE1BQU07R0FDeEIsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsTUFBTTtJQUNyRCxPQUNFLDRDQUE0QyxJQUFJLGlEQUNsRDtHQUNGO0dBQ0EsTUFBTSxhQUFhLG1CQUFtQixLQUFLO0dBQzNDLE1BQU0sYUFBYTtFQUNyQjtDQUNGO0FBQ0Y7QUFDQSxNQUFNLHVCQUF1QixVQUFVLGFBQWE7Q0FDbEQsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsQ0FBQyxZQUFZLFNBQVMsS0FBSyxLQUFLLE1BQU07RUFDckYsT0FDRSxnR0FDRjtDQUNGO0NBQ0EsTUFBTSxhQUFhLG1CQUFtQixRQUFRO0NBQzlDLFNBQVMsTUFBTSxnQkFBZ0I7QUFDakM7QUFDQSxNQUFNLGVBQWUsT0FBTyxVQUFVLGNBQWM7Q0FDbEQsS0FBSyxNQUFNLE9BQU8sVUFBVTtFQUMxQixJQUFJLGFBQWEsQ0FBQyxjQUFjLEdBQUcsR0FBRztHQUNwQyxNQUFNLE9BQU8sU0FBUztFQUN4QjtDQUNGO0FBQ0Y7QUFDQSxNQUFNLGFBQWEsVUFBVSxVQUFVLGNBQWM7Q0FDbkQsTUFBTSxRQUFRLFNBQVMsUUFBUSxxQkFBcUI7Q0FDcEQsSUFBSSxTQUFTLE1BQU0sWUFBWSxJQUFJO0VBQ2pDLE1BQU0sT0FBTyxTQUFTO0VBQ3RCLElBQUksTUFBTTtHQUNSLFlBQVksT0FBTyxVQUFVLFNBQVM7R0FDdEMsSUFBSSxXQUFXO0lBQ2IsSUFBSSxPQUFPLEtBQUssTUFBTSxJQUFJO0dBQzVCO0VBQ0YsT0FBTztHQUNMLHFCQUFxQixVQUFVLEtBQUs7RUFDdEM7Q0FDRixPQUFPLElBQUksVUFBVTtFQUNuQixvQkFBb0IsVUFBVSxRQUFRO0NBQ3hDO0FBQ0Y7QUFDQSxNQUFNLGVBQWUsVUFBVSxVQUFVLGNBQWM7Q0FDckQsTUFBTSxFQUFFLE9BQU8sVUFBVTtDQUN6QixJQUFJLG9CQUFvQjtDQUN4QixJQUFJLDJCQUEyQjtDQUMvQixJQUFJLE1BQU0sWUFBWSxJQUFJO0VBQ3hCLE1BQU0sT0FBTyxTQUFTO0VBQ3RCLElBQUksTUFBTTtHQUNSLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLGVBQWU7SUFDOUQsWUFBWSxPQUFPLFVBQVUsU0FBUztJQUN0QyxRQUFRLFVBQVUsT0FBTyxRQUFRO0dBQ25DLE9BQU8sSUFBSSxhQUFhLFNBQVMsR0FBRztJQUNsQyxvQkFBb0I7R0FDdEIsT0FBTztJQUNMLFlBQVksT0FBTyxVQUFVLFNBQVM7R0FDeEM7RUFDRixPQUFPO0dBQ0wsb0JBQW9CLENBQUMsU0FBUztHQUM5QixxQkFBcUIsVUFBVSxLQUFLO0VBQ3RDO0VBQ0EsMkJBQTJCO0NBQzdCLE9BQU8sSUFBSSxVQUFVO0VBQ25CLG9CQUFvQixVQUFVLFFBQVE7RUFDdEMsMkJBQTJCLEVBQUUsU0FBUyxFQUFFO0NBQzFDO0NBQ0EsSUFBSSxtQkFBbUI7RUFDckIsS0FBSyxNQUFNLE9BQU8sT0FBTztHQUN2QixJQUFJLENBQUMsY0FBYyxHQUFHLEtBQUsseUJBQXlCLFFBQVEsTUFBTTtJQUNoRSxPQUFPLE1BQU07R0FDZjtFQUNGO0NBQ0Y7QUFDRjtBQUVBLElBQUk7QUFDSixJQUFJO0FBQ0osU0FBUyxhQUFhLFVBQVUsTUFBTTtDQUNwQyxJQUFJLFNBQVMsV0FBVyxPQUFPLGVBQWUsWUFBWSxHQUFHO0VBQzNELEtBQUssS0FBSyxPQUFPLEtBQUssR0FBRyxTQUFTLEtBQUs7Q0FDekM7Q0FDQSxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQix1QkFBdUI7RUFDdEUsa0JBQWtCLFVBQVUsTUFBTSxZQUFZLElBQUksS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLENBQUM7Q0FDM0U7QUFDRjtBQUNBLFNBQVMsV0FBVyxVQUFVLE1BQU07Q0FDbEMsSUFBSSxTQUFTLFdBQVcsT0FBTyxlQUFlLFlBQVksR0FBRztFQUMzRCxNQUFNLFdBQVcsT0FBTyxLQUFLLEdBQUcsU0FBUztFQUN6QyxNQUFNLFNBQVMsV0FBVztFQUMxQixNQUFNLGNBQWMsSUFBSSxvQkFBb0IsVUFBVSxTQUFTLElBQUksRUFBRSxJQUFJO0VBQ3pFLEtBQUssS0FBSyxNQUFNO0VBQ2hCLEtBQUssUUFBUSxhQUFhLFVBQVUsTUFBTTtFQUMxQyxLQUFLLGNBQWMsV0FBVztFQUM5QixLQUFLLFdBQVcsUUFBUTtFQUN4QixLQUFLLFdBQVcsTUFBTTtDQUN4QjtDQUNBLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLHVCQUF1QjtFQUN0RSxnQkFBZ0IsVUFBVSxNQUFNLFlBQVksSUFBSSxLQUFLLElBQUksSUFBSSxLQUFLLElBQUksQ0FBQztDQUN6RTtBQUNGO0FBQ0EsU0FBUyxjQUFjO0NBQ3JCLElBQUksY0FBYyxLQUFLLEdBQUc7RUFDeEIsT0FBTztDQUNUO0NBQ0EsSUFBSSxPQUFPLFdBQVcsZUFBZSxPQUFPLGFBQWE7RUFDdkQsWUFBWTtFQUNaLE9BQU8sT0FBTztDQUNoQixPQUFPO0VBQ0wsWUFBWTtDQUNkO0NBQ0EsT0FBTztBQUNUO0FBRUEsU0FBUyxtQkFBbUI7Q0FDMUIsTUFBTSxXQUFXLENBQUM7Q0FDbEIsSUFBSSxPQUFPLHdCQUF3QixXQUFXO0VBQzVDLENBQUMsb0JBQTJCLGlCQUFpQixTQUFTLEtBQUsscUJBQXFCO0VBQ2hGLGNBQWMsQ0FBQyxDQUFDLHNCQUFzQjtDQUN4QztDQUNBLElBQUksT0FBTywwQkFBMEIsV0FBVztFQUM5QyxDQUFDLG9CQUEyQixpQkFBaUIsU0FBUyxLQUFLLHVCQUF1QjtFQUNsRixjQUFjLENBQUMsQ0FBQyx3QkFBd0I7Q0FDMUM7Q0FDQSxJQUFJLE9BQU8sNENBQTRDLFdBQVc7RUFDaEUsQ0FBQyxvQkFBMkIsaUJBQWlCLFNBQVMsS0FBSyx5Q0FBeUM7RUFDcEcsY0FBYyxDQUFDLENBQUMsMENBQTBDO0NBQzVEO0NBQ0EsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsU0FBUyxRQUFRO0VBQ2hFLE1BQU0sUUFBUSxTQUFTLFNBQVM7RUFDaEMsUUFBUSxLQUNOLGVBQWUsUUFBUSxNQUFNLEdBQUcsR0FBRyxTQUFTLEtBQUssSUFBSSxFQUFFLEdBQUcsUUFBUSxRQUFRLEtBQUs7OzREQUdqRjtDQUNGO0FBQ0Y7QUFFQSxNQUFNLHdCQUF3QjtBQUM5QixTQUFTLGVBQWUsU0FBUztDQUMvQixPQUFPLG1CQUFtQixPQUFPO0FBQ25DO0FBQ0EsU0FBUyx3QkFBd0IsU0FBUztDQUN4QyxPQUFPLG1CQUFtQixTQUFTLHdCQUF3QjtBQUM3RDtBQUNBLFNBQVMsbUJBQW1CLFNBQVMsb0JBQW9CO0NBQ3ZEO0VBQ0UsaUJBQWlCO0NBQ25CO0NBQ0EsTUFBTSxTQUFTLGNBQWM7Q0FDN0IsT0FBTyxVQUFVO0NBQ2pCLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLHVCQUF1QjtFQUN0RSxrQkFBa0IsT0FBTyw4QkFBOEIsTUFBTTtDQUMvRDtDQUNBLE1BQU0sRUFDSixRQUFRLFlBQ1IsUUFBUSxZQUNSLFdBQVcsZUFDWCxlQUFlLG1CQUNmLFlBQVksZ0JBQ1osZUFBZSxtQkFDZixTQUFTLGFBQ1QsZ0JBQWdCLG9CQUNoQixZQUFZLGdCQUNaLGFBQWEsaUJBQ2IsWUFBWSxpQkFBaUIsTUFDN0IscUJBQXFCLDRCQUNuQjtDQUNKLE1BQU0sU0FBUyxJQUFJLElBQUksV0FBVyxTQUFTLE1BQU0sa0JBQWtCLE1BQU0saUJBQWlCLE1BQU0sWUFBWSxLQUFLLEdBQUcsZUFBZSxNQUFNLFlBQVksQ0FBQyxvQkFBMkIsaUJBQWlCLGdCQUFnQixRQUFRLENBQUMsQ0FBQyxHQUFHLG9CQUFvQjtFQUNqUCxJQUFJLE9BQU8sSUFBSTtHQUNiO0VBQ0Y7RUFDQSxJQUFJLE1BQU0sQ0FBQyxnQkFBZ0IsSUFBSSxFQUFFLEdBQUc7R0FDbEMsU0FBUyxnQkFBZ0IsRUFBRTtHQUMzQixRQUFRLElBQUksaUJBQWlCLGdCQUFnQixJQUFJO0dBQ2pELEtBQUs7RUFDUDtFQUNBLElBQUksR0FBRyxjQUFjLENBQUMsR0FBRztHQUN2QixZQUFZO0dBQ1osR0FBRyxrQkFBa0I7RUFDdkI7RUFDQSxNQUFNLEVBQUUsTUFBTSxLQUFLLGNBQWM7RUFDakMsUUFBUSxNQUFSO0dBQ0UsS0FBSztJQUNILFlBQVksSUFBSSxJQUFJLFdBQVcsTUFBTTtJQUNyQztHQUNGLEtBQUs7SUFDSCxtQkFBbUIsSUFBSSxJQUFJLFdBQVcsTUFBTTtJQUM1QztHQUNGLEtBQUs7SUFDSCxJQUFJLE1BQU0sTUFBTTtLQUNkLGdCQUFnQixJQUFJLFdBQVcsUUFBUSxTQUFTO0lBQ2xELE9BQU8sSUFBSSxDQUFDLG9CQUEyQixlQUFlO0tBQ3BELGdCQUFnQixJQUFJLElBQUksV0FBVyxTQUFTO0lBQzlDO0lBQ0E7R0FDRixLQUFLO0lBQ0gsZ0JBQ0UsSUFDQSxJQUNBLFdBQ0EsUUFDQSxpQkFDQSxnQkFDQSxXQUNBLGNBQ0EsU0FDRjtJQUNBO0dBQ0YsU0FDRSxJQUFJLFlBQVksR0FBRztJQUNqQixlQUNFLElBQ0EsSUFDQSxXQUNBLFFBQ0EsaUJBQ0EsZ0JBQ0EsV0FDQSxjQUNBLFNBQ0Y7R0FDRixPQUFPLElBQUksWUFBWSxHQUFHO0lBQ3hCLGlCQUNFLElBQ0EsSUFDQSxXQUNBLFFBQ0EsaUJBQ0EsZ0JBQ0EsV0FDQSxjQUNBLFNBQ0Y7R0FDRixPQUFPLElBQUksWUFBWSxJQUFJO0lBQ3pCLEtBQUssUUFDSCxJQUNBLElBQ0EsV0FDQSxRQUNBLGlCQUNBLGdCQUNBLFdBQ0EsY0FDQSxXQUNBLFNBQ0Y7R0FDRixPQUFPLElBQUksWUFBWSxLQUFLO0lBQzFCLEtBQUssUUFDSCxJQUNBLElBQ0EsV0FDQSxRQUNBLGlCQUNBLGdCQUNBLFdBQ0EsY0FDQSxXQUNBLFNBQ0Y7R0FDRixPQUFPLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtJQUNwRCxPQUFPLHVCQUF1QixNQUFNLElBQUksT0FBTyxLQUFLLEVBQUU7R0FDeEQ7RUFDSjtFQUNBLElBQUksT0FBTyxRQUFRLGlCQUFpQjtHQUNsQyxPQUFPLEtBQUssTUFBTSxHQUFHLEtBQUssZ0JBQWdCLE1BQU0sSUFBSSxDQUFDLEVBQUU7RUFDekQsT0FBTyxJQUFJLE9BQU8sUUFBUSxNQUFNLEdBQUcsT0FBTyxNQUFNO0dBQzlDLE9BQU8sR0FBRyxLQUFLLE1BQU0sZ0JBQWdCLElBQUksSUFBSTtFQUMvQztDQUNGO0NBQ0EsTUFBTSxlQUFlLElBQUksSUFBSSxXQUFXLFdBQVc7RUFDakQsSUFBSSxNQUFNLE1BQU07R0FDZCxXQUNFLEdBQUcsS0FBSyxlQUFlLEdBQUcsUUFBUSxHQUNsQyxXQUNBLE1BQ0Y7RUFDRixPQUFPO0dBQ0wsTUFBTSxLQUFLLEdBQUcsS0FBSyxHQUFHO0dBQ3RCLElBQUksR0FBRyxhQUFhLEdBQUcsVUFBVTtJQUMvQixZQUFZLElBQUksR0FBRyxRQUFRO0dBQzdCO0VBQ0Y7Q0FDRjtDQUNBLE1BQU0sc0JBQXNCLElBQUksSUFBSSxXQUFXLFdBQVc7RUFDeEQsSUFBSSxNQUFNLE1BQU07R0FDZCxXQUNFLEdBQUcsS0FBSyxrQkFBa0IsR0FBRyxZQUFZLEVBQUUsR0FDM0MsV0FDQSxNQUNGO0VBQ0YsT0FBTztHQUNMLEdBQUcsS0FBSyxHQUFHO0VBQ2I7Q0FDRjtDQUNBLE1BQU0sbUJBQW1CLElBQUksV0FBVyxRQUFRLGNBQWM7RUFDNUQsQ0FBQyxHQUFHLElBQUksR0FBRyxVQUFVLHdCQUNuQixHQUFHLFVBQ0gsV0FDQSxRQUNBLFdBQ0EsR0FBRyxJQUNILEdBQUcsTUFDTDtDQUNGO0NBQ0EsTUFBTSxtQkFBbUIsSUFBSSxJQUFJLFdBQVcsY0FBYztFQUN4RCxJQUFJLEdBQUcsYUFBYSxHQUFHLFVBQVU7R0FDL0IsTUFBTSxTQUFTLGdCQUFnQixHQUFHLE1BQU07R0FDeEMsaUJBQWlCLEVBQUU7R0FDbkIsQ0FBQyxHQUFHLElBQUksR0FBRyxVQUFVLHdCQUNuQixHQUFHLFVBQ0gsV0FDQSxRQUNBLFNBQ0Y7RUFDRixPQUFPO0dBQ0wsR0FBRyxLQUFLLEdBQUc7R0FDWCxHQUFHLFNBQVMsR0FBRztFQUNqQjtDQUNGO0NBQ0EsTUFBTSxrQkFBa0IsRUFBRSxJQUFJLFVBQVUsV0FBVyxnQkFBZ0I7RUFDakUsSUFBSTtFQUNKLE9BQU8sTUFBTSxPQUFPLFFBQVE7R0FDMUIsT0FBTyxnQkFBZ0IsRUFBRTtHQUN6QixXQUFXLElBQUksV0FBVyxXQUFXO0dBQ3JDLEtBQUs7RUFDUDtFQUNBLFdBQVcsUUFBUSxXQUFXLFdBQVc7Q0FDM0M7Q0FDQSxNQUFNLG9CQUFvQixFQUFFLElBQUksYUFBYTtFQUMzQyxJQUFJO0VBQ0osT0FBTyxNQUFNLE9BQU8sUUFBUTtHQUMxQixPQUFPLGdCQUFnQixFQUFFO0dBQ3pCLFdBQVcsRUFBRTtHQUNiLEtBQUs7RUFDUDtFQUNBLFdBQVcsTUFBTTtDQUNuQjtDQUNBLE1BQU0sa0JBQWtCLElBQUksSUFBSSxXQUFXLFFBQVEsaUJBQWlCLGdCQUFnQixXQUFXLGNBQWMsY0FBYztFQUN6SCxJQUFJLEdBQUcsU0FBUyxPQUFPO0dBQ3JCLFlBQVk7RUFDZCxPQUFPLElBQUksR0FBRyxTQUFTLFFBQVE7R0FDN0IsWUFBWTtFQUNkO0VBQ0EsSUFBSSxNQUFNLE1BQU07R0FDZCxhQUNFLElBQ0EsV0FDQSxRQUNBLGlCQUNBLGdCQUNBLFdBQ0EsY0FDQSxTQUNGO0VBQ0YsT0FBTztHQUNMLE1BQU0sZ0JBQWdCLEdBQUcsTUFBTSxHQUFHLEdBQUcsV0FBVyxHQUFHLEtBQUs7R0FDeEQsSUFBSTtJQUNGLElBQUksZUFBZTtLQUNqQixjQUFjLFlBQVk7SUFDNUI7SUFDQSxhQUNFLElBQ0EsSUFDQSxpQkFDQSxnQkFDQSxXQUNBLGNBQ0EsU0FDRjtHQUNGLFVBQVU7SUFDUixJQUFJLGVBQWU7S0FDakIsY0FBYyxVQUFVO0lBQzFCO0dBQ0Y7RUFDRjtDQUNGO0NBQ0EsTUFBTSxnQkFBZ0IsT0FBTyxXQUFXLFFBQVEsaUJBQWlCLGdCQUFnQixXQUFXLGNBQWMsY0FBYztFQUN0SCxJQUFJO0VBQ0osSUFBSTtFQUNKLE1BQU0sRUFBRSxPQUFPLFdBQVcsWUFBWSxTQUFTO0VBQy9DLEtBQUssTUFBTSxLQUFLLGtCQUNkLE1BQU0sTUFDTixXQUNBLFNBQVMsTUFBTSxJQUNmLEtBQ0Y7RUFDQSxJQUFJLFlBQVksR0FBRztHQUNqQixtQkFBbUIsSUFBSSxNQUFNLFFBQVE7RUFDdkMsT0FBTyxJQUFJLFlBQVksSUFBSTtHQUN6QixjQUNFLE1BQU0sVUFDTixJQUNBLE1BQ0EsaUJBQ0EsZ0JBQ0EseUJBQXlCLE9BQU8sU0FBUyxHQUN6QyxjQUNBLFNBQ0Y7RUFDRjtFQUNBLElBQUksTUFBTTtHQUNSLG9CQUFvQixPQUFPLE1BQU0saUJBQWlCLFNBQVM7RUFDN0Q7RUFDQSxXQUFXLElBQUksT0FBTyxNQUFNLFNBQVMsY0FBYyxlQUFlO0VBQ2xFLElBQUksT0FBTztHQUNULEtBQUssTUFBTSxPQUFPLE9BQU87SUFDdkIsSUFBSSxRQUFRLFdBQVcsQ0FBQyxlQUFlLEdBQUcsR0FBRztLQUMzQyxjQUFjLElBQUksS0FBSyxNQUFNLE1BQU0sTUFBTSxXQUFXLGVBQWU7SUFDckU7R0FDRjtHQUNBLElBQUksV0FBVyxPQUFPO0lBQ3BCLGNBQWMsSUFBSSxTQUFTLE1BQU0sTUFBTSxPQUFPLFNBQVM7R0FDekQ7R0FDQSxJQUFJLFlBQVksTUFBTSxvQkFBb0I7SUFDeEMsZ0JBQWdCLFdBQVcsaUJBQWlCLEtBQUs7R0FDbkQ7RUFDRjtFQUNBLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLHVCQUF1QjtHQUN0RSxJQUFJLElBQUksV0FBVyxPQUFPLElBQUk7R0FDOUIsSUFBSSxJQUFJLHdCQUF3QixpQkFBaUIsSUFBSTtFQUN2RDtFQUNBLElBQUksTUFBTTtHQUNSLG9CQUFvQixPQUFPLE1BQU0saUJBQWlCLGFBQWE7RUFDakU7RUFDQSxNQUFNLDBCQUEwQixlQUFlLGdCQUFnQixVQUFVO0VBQ3pFLElBQUkseUJBQXlCO0dBQzNCLFdBQVcsWUFBWSxFQUFFO0VBQzNCO0VBQ0EsV0FBVyxJQUFJLFdBQVcsTUFBTTtFQUNoQyxLQUFLLFlBQVksU0FBUyxNQUFNLG1CQUFtQiwyQkFBMkIsTUFBTTtHQUNsRixNQUFNLFFBQVEsQ0FBQyxvQkFBMkIsaUJBQWlCO0dBQzNELDRCQUE0QjtJQUMxQixJQUFJO0lBQ0osSUFBSSxDQUFDLG9CQUEyQixlQUFlLE9BQU8sZUFBZSxLQUFLO0lBQzFFLElBQUk7S0FDRixhQUFhLGdCQUFnQixXQUFXLGlCQUFpQixLQUFLO0tBQzlELDJCQUEyQixXQUFXLE1BQU0sRUFBRTtLQUM5QyxRQUFRLG9CQUFvQixPQUFPLE1BQU0saUJBQWlCLFNBQVM7SUFDckUsVUFBVTtLQUNSLElBQUksQ0FBQyxvQkFBMkIsZUFBZSxlQUFlLElBQUk7SUFDcEU7R0FDRixHQUFHLGNBQWM7RUFDbkI7Q0FDRjtDQUNBLE1BQU0sY0FBYyxJQUFJLE9BQU8sU0FBUyxjQUFjLG9CQUFvQjtFQUN4RSxJQUFJLFNBQVM7R0FDWCxlQUFlLElBQUksT0FBTztFQUM1QjtFQUNBLElBQUksY0FBYztHQUNoQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksYUFBYSxRQUFRLEtBQUs7SUFDNUMsZUFBZSxJQUFJLGFBQWEsRUFBRTtHQUNwQztFQUNGO0VBQ0EsSUFBSSxpQkFBaUI7R0FDbkIsSUFBSSxVQUFVLGdCQUFnQjtHQUM5QixJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixRQUFRLFlBQVksS0FBSyxRQUFRLFlBQVksTUFBTTtJQUNsRyxVQUFVLGlCQUFpQixRQUFRLFFBQVEsS0FBSztHQUNsRDtHQUNBLElBQUksVUFBVSxXQUFXLFdBQVcsUUFBUSxJQUFJLE1BQU0sUUFBUSxjQUFjLFNBQVMsUUFBUSxlQUFlLFFBQVE7SUFDbEgsTUFBTSxjQUFjLGdCQUFnQjtJQUNwQyxXQUNFLElBQ0EsYUFDQSxZQUFZLFNBQ1osWUFBWSxjQUNaLGdCQUFnQixNQUNsQjtHQUNGO0VBQ0Y7Q0FDRjtDQUNBLE1BQU0saUJBQWlCLFVBQVUsV0FBVyxRQUFRLGlCQUFpQixnQkFBZ0IsV0FBVyxjQUFjLFdBQVcsUUFBUSxNQUFNO0VBQ3JJLEtBQUssSUFBSSxJQUFJLE9BQU8sSUFBSSxTQUFTLFFBQVEsS0FBSztHQUM1QyxNQUFNLFFBQVEsU0FBUyxLQUFLLFlBQVksZUFBZSxTQUFTLEVBQUUsSUFBSSxlQUFlLFNBQVMsRUFBRTtHQUNoRyxNQUNFLE1BQ0EsT0FDQSxXQUNBLFFBQ0EsaUJBQ0EsZ0JBQ0EsV0FDQSxjQUNBLFNBQ0Y7RUFDRjtDQUNGO0NBQ0EsTUFBTSxnQkFBZ0IsSUFBSSxJQUFJLGlCQUFpQixnQkFBZ0IsV0FBVyxjQUFjLGNBQWM7RUFDcEcsTUFBTSxLQUFLLEdBQUcsS0FBSyxHQUFHO0VBQ3RCLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLHVCQUF1QjtHQUN0RSxHQUFHLFVBQVU7RUFDZjtFQUNBLElBQUksRUFBRSxXQUFXLGlCQUFpQixTQUFTO0VBQzNDLGFBQWEsR0FBRyxZQUFZO0VBQzVCLE1BQU0sV0FBVyxHQUFHLFNBQVM7RUFDN0IsTUFBTSxXQUFXLEdBQUcsU0FBUztFQUM3QixJQUFJO0VBQ0osbUJBQW1CLGNBQWMsaUJBQWlCLEtBQUs7RUFDdkQsSUFBSSxZQUFZLFNBQVMscUJBQXFCO0dBQzVDLGdCQUFnQixXQUFXLGlCQUFpQixJQUFJLEVBQUU7RUFDcEQ7RUFDQSxJQUFJLE1BQU07R0FDUixvQkFBb0IsSUFBSSxJQUFJLGlCQUFpQixjQUFjO0VBQzdEO0VBQ0EsbUJBQW1CLGNBQWMsaUJBQWlCLElBQUk7RUFDdEQsSUFFRSxDQUFDLG9CQUEyQixpQkFBaUIsaUJBRTdDLG9CQUFvQixDQUFDLEdBQUcsbUJBQW1CLEdBQUcsZ0JBQWdCLFdBQVcsZ0JBQWdCLFNBQ3pGO0dBQ0EsWUFBWTtHQUNaLFlBQVk7R0FDWixrQkFBa0I7RUFDcEI7RUFDQSxJQUFJLFNBQVMsYUFBYSxTQUFTLGFBQWEsUUFBUSxTQUFTLGVBQWUsU0FBUyxlQUFlLE1BQU07R0FDNUcsbUJBQW1CLElBQUksRUFBRTtFQUMzQjtFQUNBLElBQUksaUJBQWlCO0dBQ25CLG1CQUNFLEdBQUcsaUJBQ0gsaUJBQ0EsSUFDQSxpQkFDQSxnQkFDQSx5QkFBeUIsSUFBSSxTQUFTLEdBQ3RDLFlBQ0Y7R0FDQSxJQUFJLENBQUMsb0JBQTJCLGVBQWU7SUFDN0MsdUJBQXVCLElBQUksRUFBRTtHQUMvQjtFQUNGLE9BQU8sSUFBSSxDQUFDLFdBQVc7R0FDckIsY0FDRSxJQUNBLElBQ0EsSUFDQSxNQUNBLGlCQUNBLGdCQUNBLHlCQUF5QixJQUFJLFNBQVMsR0FDdEMsY0FDQSxLQUNGO0VBQ0Y7RUFDQSxJQUFJLFlBQVksR0FBRztHQUNqQixJQUFJLFlBQVksSUFBSTtJQUNsQixXQUFXLElBQUksVUFBVSxVQUFVLGlCQUFpQixTQUFTO0dBQy9ELE9BQU87SUFDTCxJQUFJLFlBQVksR0FBRztLQUNqQixJQUFJLFNBQVMsVUFBVSxTQUFTLE9BQU87TUFDckMsY0FBYyxJQUFJLFNBQVMsTUFBTSxTQUFTLE9BQU8sU0FBUztLQUM1RDtJQUNGO0lBQ0EsSUFBSSxZQUFZLEdBQUc7S0FDakIsY0FBYyxJQUFJLFNBQVMsU0FBUyxPQUFPLFNBQVMsT0FBTyxTQUFTO0lBQ3RFO0lBQ0EsSUFBSSxZQUFZLEdBQUc7S0FDakIsTUFBTSxnQkFBZ0IsR0FBRztLQUN6QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksY0FBYyxRQUFRLEtBQUs7TUFDN0MsTUFBTSxNQUFNLGNBQWM7TUFDMUIsTUFBTSxPQUFPLFNBQVM7TUFDdEIsTUFBTSxPQUFPLFNBQVM7TUFDdEIsSUFBSSxTQUFTLFFBQVEsUUFBUSxTQUFTO09BQ3BDLGNBQWMsSUFBSSxLQUFLLE1BQU0sTUFBTSxXQUFXLGVBQWU7TUFDL0Q7S0FDRjtJQUNGO0dBQ0Y7R0FDQSxJQUFJLFlBQVksR0FBRztJQUNqQixJQUFJLEdBQUcsYUFBYSxHQUFHLFVBQVU7S0FDL0IsbUJBQW1CLElBQUksR0FBRyxRQUFRO0lBQ3BDO0dBQ0Y7RUFDRixPQUFPLElBQUksQ0FBQyxhQUFhLG1CQUFtQixNQUFNO0dBQ2hELFdBQVcsSUFBSSxVQUFVLFVBQVUsaUJBQWlCLFNBQVM7RUFDL0Q7RUFDQSxLQUFLLFlBQVksU0FBUyxtQkFBbUIsTUFBTTtHQUNqRCw0QkFBNEI7SUFDMUIsYUFBYSxnQkFBZ0IsV0FBVyxpQkFBaUIsSUFBSSxFQUFFO0lBQy9ELFFBQVEsb0JBQW9CLElBQUksSUFBSSxpQkFBaUIsU0FBUztHQUNoRSxHQUFHLGNBQWM7RUFDbkI7Q0FDRjtDQUNBLE1BQU0sc0JBQXNCLGFBQWEsYUFBYSxtQkFBbUIsaUJBQWlCLGdCQUFnQixXQUFXLGlCQUFpQjtFQUNwSSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksWUFBWSxRQUFRLEtBQUs7R0FDM0MsTUFBTSxXQUFXLFlBQVk7R0FDN0IsTUFBTSxXQUFXLFlBQVk7R0FDN0IsTUFBTSxZQUdKLFNBQVMsT0FFUixTQUFTLFNBQVMsWUFFbkIsQ0FBQyxnQkFBZ0IsVUFBVSxRQUFRLEtBQ25DLFNBQVMsYUFBYSxJQUFJLEtBQUssUUFBUSxlQUFlLFNBQVMsRUFBRTs7O0dBRy9EO0dBR0osTUFDRSxVQUNBLFVBQ0EsV0FDQSxNQUNBLGlCQUNBLGdCQUNBLFdBQ0EsY0FDQSxJQUNGO0VBQ0Y7Q0FDRjtDQUNBLE1BQU0sY0FBYyxJQUFJLFVBQVUsVUFBVSxpQkFBaUIsY0FBYztFQUN6RSxJQUFJLGFBQWEsVUFBVTtHQUN6QixJQUFJLGFBQWEsV0FBVztJQUMxQixLQUFLLE1BQU0sT0FBTyxVQUFVO0tBQzFCLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxFQUFFLE9BQU8sV0FBVztNQUM5QyxjQUNFLElBQ0EsS0FDQSxTQUFTLE1BQ1QsTUFDQSxXQUNBLGVBQ0Y7S0FDRjtJQUNGO0dBQ0Y7R0FDQSxLQUFLLE1BQU0sT0FBTyxVQUFVO0lBQzFCLElBQUksZUFBZSxHQUFHLEdBQUc7SUFDekIsTUFBTSxPQUFPLFNBQVM7SUFDdEIsTUFBTSxPQUFPLFNBQVM7SUFDdEIsSUFBSSxTQUFTLFFBQVEsUUFBUSxTQUFTO0tBQ3BDLGNBQWMsSUFBSSxLQUFLLE1BQU0sTUFBTSxXQUFXLGVBQWU7SUFDL0Q7R0FDRjtHQUNBLElBQUksV0FBVyxVQUFVO0lBQ3ZCLGNBQWMsSUFBSSxTQUFTLFNBQVMsT0FBTyxTQUFTLE9BQU8sU0FBUztHQUN0RTtFQUNGO0NBQ0Y7Q0FDQSxNQUFNLG1CQUFtQixJQUFJLElBQUksV0FBVyxRQUFRLGlCQUFpQixnQkFBZ0IsV0FBVyxjQUFjLGNBQWM7RUFDMUgsTUFBTSxzQkFBc0IsR0FBRyxLQUFLLEtBQUssR0FBRyxLQUFLLGVBQWUsRUFBRTtFQUNsRSxNQUFNLG9CQUFvQixHQUFHLFNBQVMsS0FBSyxHQUFHLFNBQVMsZUFBZSxFQUFFO0VBQ3hFLElBQUksRUFBRSxXQUFXLGlCQUFpQixjQUFjLHlCQUF5QjtFQUN6RSxJQUFJLENBQUMsb0JBQTJCLGtCQUMvQixpQkFBaUIsWUFBWSxPQUFPO0dBQ25DLFlBQVk7R0FDWixZQUFZO0dBQ1osa0JBQWtCO0VBQ3BCO0VBQ0EsSUFBSSxzQkFBc0I7R0FDeEIsZUFBZSxlQUFlLGFBQWEsT0FBTyxvQkFBb0IsSUFBSTtFQUM1RTtFQUNBLElBQUksTUFBTSxNQUFNO0dBQ2QsV0FBVyxxQkFBcUIsV0FBVyxNQUFNO0dBQ2pELFdBQVcsbUJBQW1CLFdBQVcsTUFBTTtHQUMvQzs7Ozs7SUFLRSxHQUFHLFlBQVksQ0FBQztJQUNoQjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNGO0VBQ0YsT0FBTztHQUNMLElBQUksWUFBWSxLQUFLLFlBQVksTUFBTSxtQkFFdkMsR0FBRyxtQkFBbUIsR0FBRyxnQkFBZ0IsV0FBVyxnQkFBZ0IsUUFBUTtJQUMxRSxtQkFDRSxHQUFHLGlCQUNILGlCQUNBLFdBQ0EsaUJBQ0EsZ0JBQ0EsV0FDQSxZQUNGO0lBQ0EsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0tBQzdDLHVCQUF1QixJQUFJLEVBQUU7SUFDL0IsT0FBTyxJQUtMLEdBQUcsT0FBTyxRQUFRLG1CQUFtQixPQUFPLGdCQUFnQixTQUM1RDtLQUNBO01BQ0U7TUFDQTtNQUNBOztLQUVGO0lBQ0Y7R0FDRixPQUFPO0lBQ0wsY0FDRSxJQUNBLElBQ0EsV0FDQSxtQkFDQSxpQkFDQSxnQkFDQSxXQUNBLGNBQ0EsU0FDRjtHQUNGO0VBQ0Y7Q0FDRjtDQUNBLE1BQU0sb0JBQW9CLElBQUksSUFBSSxXQUFXLFFBQVEsaUJBQWlCLGdCQUFnQixXQUFXLGNBQWMsY0FBYztFQUMzSCxHQUFHLGVBQWU7RUFDbEIsSUFBSSxNQUFNLE1BQU07R0FDZCxJQUFJLEdBQUcsWUFBWSxLQUFLO0lBQ3RCLGdCQUFnQixJQUFJLFNBQ2xCLElBQ0EsV0FDQSxRQUNBLFdBQ0EsU0FDRjtHQUNGLE9BQU87SUFDTCxlQUNFLElBQ0EsV0FDQSxRQUNBLGlCQUNBLGdCQUNBLFdBQ0EsU0FDRjtHQUNGO0VBQ0YsT0FBTztHQUNMLGdCQUFnQixJQUFJLElBQUksU0FBUztFQUNuQztDQUNGO0NBQ0EsTUFBTSxrQkFBa0IsY0FBYyxXQUFXLFFBQVEsaUJBQWlCLGdCQUFnQixXQUFXLGNBQWM7RUFDakgsTUFBTSxXQUFZLGFBQWEsWUFBWSx3QkFDekMsY0FDQSxpQkFDQSxjQUNGO0VBQ0EsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsU0FBUyxLQUFLLFNBQVM7R0FDdEUsWUFBWSxRQUFRO0VBQ3RCO0VBQ0EsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0dBQzdDLG1CQUFtQixZQUFZO0dBQy9CLGFBQWEsVUFBVSxPQUFPO0VBQ2hDO0VBQ0EsSUFBSSxZQUFZLFlBQVksR0FBRztHQUM3QixTQUFTLElBQUksV0FBVztFQUMxQjtFQUNBO0dBQ0UsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0lBQzdDLGFBQWEsVUFBVSxNQUFNO0dBQy9CO0dBQ0EsZUFBZSxVQUFVLE9BQU8sU0FBUztHQUN6QyxJQUFJLENBQUMsb0JBQTJCLGVBQWU7SUFDN0MsV0FBVyxVQUFVLE1BQU07R0FDN0I7RUFDRjtFQUNBLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLGVBQWUsYUFBYSxLQUFLO0VBQ2xGLElBQUksU0FBUyxVQUFVO0dBQ3JCLGtCQUFrQixlQUFlLFlBQVksVUFBVSxtQkFBbUIsU0FBUztHQUNuRixJQUFJLENBQUMsYUFBYSxJQUFJO0lBQ3BCLE1BQU0sY0FBYyxTQUFTLFVBQVUsWUFBWSxPQUFPO0lBQzFELG1CQUFtQixNQUFNLGFBQWEsV0FBVyxNQUFNO0lBQ3ZELGFBQWEsY0FBYyxZQUFZO0dBQ3pDO0VBQ0YsT0FBTztHQUNMLGtCQUNFLFVBQ0EsY0FDQSxXQUNBLFFBQ0EsZ0JBQ0EsV0FDQSxTQUNGO0VBQ0Y7RUFDQSxJQUFJLENBQUMsb0JBQTJCLGVBQWU7R0FDN0Msa0JBQWtCO0dBQ2xCLFdBQVcsVUFBVSxPQUFPO0VBQzlCO0NBQ0Y7Q0FDQSxNQUFNLG1CQUFtQixJQUFJLElBQUksY0FBYztFQUM3QyxNQUFNLFdBQVcsR0FBRyxZQUFZLEdBQUc7RUFDbkMsSUFBSSxzQkFBc0IsSUFBSSxJQUFJLFNBQVMsR0FBRztHQUM1QyxJQUFJLFNBQVMsWUFBWSxDQUFDLFNBQVMsZUFBZTtJQUNoRCxJQUFJLENBQUMsb0JBQTJCLGVBQWU7S0FDN0MsbUJBQW1CLEVBQUU7SUFDdkI7SUFDQSx5QkFBeUIsVUFBVSxJQUFJLFNBQVM7SUFDaEQsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0tBQzdDLGtCQUFrQjtJQUNwQjtJQUNBO0dBQ0YsT0FBTztJQUNMLFNBQVMsT0FBTztJQUNoQixTQUFTLE9BQU87R0FDbEI7RUFDRixPQUFPO0dBQ0wsR0FBRyxLQUFLLEdBQUc7R0FDWCxTQUFTLFFBQVE7RUFDbkI7Q0FDRjtDQUNBLE1BQU0scUJBQXFCLFVBQVUsY0FBYyxXQUFXLFFBQVEsZ0JBQWdCLFdBQVcsY0FBYztFQUM3RyxNQUFNLDBCQUEwQjtHQUM5QixJQUFJLENBQUMsU0FBUyxXQUFXO0lBQ3ZCLElBQUk7SUFDSixNQUFNLEVBQUUsSUFBSSxVQUFVO0lBQ3RCLE1BQU0sRUFBRSxJQUFJLEdBQUcsUUFBUSxNQUFNLFNBQVM7SUFDdEMsTUFBTSxzQkFBc0IsZUFBZSxZQUFZO0lBQ3ZELGNBQWMsVUFBVSxLQUFLO0lBQzdCLElBQUksSUFBSTtLQUNOLGVBQWUsRUFBRTtJQUNuQjtJQUNBLElBQUksQ0FBQyx3QkFBd0IsWUFBWSxTQUFTLE1BQU0scUJBQXFCO0tBQzNFLGdCQUFnQixXQUFXLFFBQVEsWUFBWTtJQUNqRDtJQUNBLGNBQWMsVUFBVSxJQUFJO0lBQzVCLElBQUksTUFBTSxhQUFhO0tBQ3JCLE1BQU0sdUJBQXVCO01BQzNCLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtPQUM3QyxhQUFhLFVBQVUsUUFBUTtNQUNqQztNQUNBLFNBQVMsVUFBVSxvQkFBb0IsUUFBUTtNQUMvQyxJQUFJLENBQUMsb0JBQTJCLGVBQWU7T0FDN0MsV0FBVyxVQUFVLFFBQVE7TUFDL0I7TUFDQSxJQUFJLENBQUMsb0JBQTJCLGVBQWU7T0FDN0MsYUFBYSxVQUFVLFNBQVM7TUFDbEM7TUFDQSxZQUNFLElBQ0EsU0FBUyxTQUNULFVBQ0EsZ0JBQ0EsSUFDRjtNQUNBLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtPQUM3QyxXQUFXLFVBQVUsU0FBUztNQUNoQztLQUNGO0tBQ0EsSUFBSSx1QkFBdUIsS0FBSyxnQkFBZ0I7TUFDOUMsS0FBSyxlQUNILElBQ0EsVUFDQSxjQUNGO0tBQ0YsT0FBTztNQUNMLGVBQWU7S0FDakI7SUFDRixPQUFPO0tBQ0wsSUFBSSxLQUFLLE1BQU0sS0FBSyxHQUFHLGVBQWUsR0FBRztNQUN2QyxLQUFLLEdBQUcsa0JBQ04sTUFDQSxTQUFTLFNBQVMsU0FBUyxPQUFPLE9BQU8sS0FBSyxDQUNoRDtLQUNGO0tBQ0EsSUFBSSxDQUFDLG9CQUEyQixlQUFlO01BQzdDLGFBQWEsVUFBVSxRQUFRO0tBQ2pDO0tBQ0EsTUFBTSxVQUFVLFNBQVMsVUFBVSxvQkFBb0IsUUFBUTtLQUMvRCxJQUFJLENBQUMsb0JBQTJCLGVBQWU7TUFDN0MsV0FBVyxVQUFVLFFBQVE7S0FDL0I7S0FDQSxJQUFJLENBQUMsb0JBQTJCLGVBQWU7TUFDN0MsYUFBYSxVQUFVLE9BQU87S0FDaEM7S0FDQSxNQUNFLE1BQ0EsU0FDQSxXQUNBLFFBQ0EsVUFDQSxnQkFDQSxTQUNGO0tBQ0EsSUFBSSxDQUFDLG9CQUEyQixlQUFlO01BQzdDLFdBQVcsVUFBVSxPQUFPO0tBQzlCO0tBQ0EsYUFBYSxLQUFLLFFBQVE7SUFDNUI7SUFDQSxJQUFJLEdBQUc7S0FDTCxzQkFBc0IsR0FBRyxjQUFjO0lBQ3pDO0lBQ0EsSUFBSSxDQUFDLHdCQUF3QixZQUFZLFNBQVMsTUFBTSxpQkFBaUI7S0FDdkUsTUFBTSxxQkFBcUI7S0FDM0IsNEJBQ1EsZ0JBQWdCLFdBQVcsUUFBUSxrQkFBa0IsR0FDM0QsY0FDRjtJQUNGO0lBQ0EsSUFBSSxhQUFhLFlBQVksT0FBTyxVQUFVLGVBQWUsT0FBTyxLQUFLLEtBQUssT0FBTyxNQUFNLFlBQVksS0FBSztLQUMxRyxTQUFTLEtBQUssc0JBQXNCLFNBQVMsR0FBRyxjQUFjO0lBQ2hFO0lBQ0EsU0FBUyxZQUFZO0lBQ3JCLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLHVCQUF1QjtLQUN0RSx1QkFBdUIsUUFBUTtJQUNqQztJQUNBLGVBQWUsWUFBWSxTQUFTO0dBQ3RDLE9BQU87SUFDTCxJQUFJLEVBQUUsTUFBTSxJQUFJLEdBQUcsUUFBUSxVQUFVO0lBQ3JDO0tBQ0UsTUFBTSx1QkFBdUIsMkJBQTJCLFFBQVE7S0FDaEUsSUFBSSxzQkFBc0I7TUFDeEIsSUFBSSxNQUFNO09BQ1IsS0FBSyxLQUFLLE1BQU07T0FDaEIseUJBQXlCLFVBQVUsTUFBTSxTQUFTO01BQ3BEO01BQ0EscUJBQXFCLFNBQVMsV0FBVztPQUN2Qyw0QkFBNEI7UUFDMUIsSUFBSSxDQUFDLFNBQVMsYUFBYSxPQUFPO09BQ3BDLEdBQUcsY0FBYztNQUNuQixDQUFDO01BQ0Q7S0FDRjtJQUNGO0lBQ0EsSUFBSSxhQUFhO0lBQ2pCLElBQUk7SUFDSixJQUFJLENBQUMsb0JBQTJCLGVBQWU7S0FDN0MsbUJBQW1CLFFBQVEsU0FBUyxLQUFLO0lBQzNDO0lBQ0EsY0FBYyxVQUFVLEtBQUs7SUFDN0IsSUFBSSxNQUFNO0tBQ1IsS0FBSyxLQUFLLE1BQU07S0FDaEIseUJBQXlCLFVBQVUsTUFBTSxTQUFTO0lBQ3BELE9BQU87S0FDTCxPQUFPO0lBQ1Q7SUFDQSxJQUFJLElBQUk7S0FDTixlQUFlLEVBQUU7SUFDbkI7SUFDQSxJQUFJLFlBQVksS0FBSyxTQUFTLEtBQUssTUFBTSxxQkFBcUI7S0FDNUQsZ0JBQWdCLFdBQVcsUUFBUSxNQUFNLEtBQUs7SUFDaEQ7SUFDQSxjQUFjLFVBQVUsSUFBSTtJQUM1QixJQUFJLENBQUMsb0JBQTJCLGVBQWU7S0FDN0MsYUFBYSxVQUFVLFFBQVE7SUFDakM7SUFDQSxNQUFNLFdBQVcsb0JBQW9CLFFBQVE7SUFDN0MsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0tBQzdDLFdBQVcsVUFBVSxRQUFRO0lBQy9CO0lBQ0EsTUFBTSxXQUFXLFNBQVM7SUFDMUIsU0FBUyxVQUFVO0lBQ25CLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtLQUM3QyxhQUFhLFVBQVUsT0FBTztJQUNoQztJQUNBO0tBQ0U7S0FDQTs7S0FFQSxlQUFlLFNBQVMsRUFBRTs7S0FFMUIsZ0JBQWdCLFFBQVE7S0FDeEI7S0FDQTtLQUNBO0lBQ0Y7SUFDQSxJQUFJLENBQUMsb0JBQTJCLGVBQWU7S0FDN0MsV0FBVyxVQUFVLE9BQU87SUFDOUI7SUFDQSxLQUFLLEtBQUssU0FBUztJQUNuQixJQUFJLGVBQWUsTUFBTTtLQUN2QixnQkFBZ0IsVUFBVSxTQUFTLEVBQUU7SUFDdkM7SUFDQSxJQUFJLEdBQUc7S0FDTCxzQkFBc0IsR0FBRyxjQUFjO0lBQ3pDO0lBQ0EsSUFBSSxZQUFZLEtBQUssU0FBUyxLQUFLLE1BQU0sZ0JBQWdCO0tBQ3ZELDRCQUNRLGdCQUFnQixXQUFXLFFBQVEsTUFBTSxLQUFLLEdBQ3BELGNBQ0Y7SUFDRjtJQUNBLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLHVCQUF1QjtLQUN0RSx5QkFBeUIsUUFBUTtJQUNuQztJQUNBLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtLQUM3QyxrQkFBa0I7SUFDcEI7R0FDRjtFQUNGO0VBQ0EsU0FBUyxNQUFNLEdBQUc7RUFDbEIsTUFBTSxTQUFTLFNBQVMsU0FBUyxJQUFJLGVBQWUsaUJBQWlCO0VBQ3JFLFNBQVMsTUFBTSxJQUFJO0VBQ25CLE1BQU0sU0FBUyxTQUFTLFNBQVMsT0FBTyxJQUFJLEtBQUssTUFBTTtFQUN2RCxNQUFNLE1BQU0sU0FBUyxNQUFNLE9BQU8sV0FBVyxLQUFLLE1BQU07RUFDeEQsSUFBSSxJQUFJO0VBQ1IsSUFBSSxLQUFLLFNBQVM7RUFDbEIsT0FBTyxrQkFBa0IsU0FBUyxHQUFHO0VBQ3JDLGNBQWMsVUFBVSxJQUFJO0VBQzVCLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtHQUM3QyxPQUFPLFVBQVUsU0FBUyxPQUFPLE1BQU0sZUFBZSxTQUFTLEtBQUssQ0FBQyxJQUFJLEtBQUs7R0FDOUUsT0FBTyxZQUFZLFNBQVMsT0FBTyxNQUFNLGVBQWUsU0FBUyxLQUFLLENBQUMsSUFBSSxLQUFLO0VBQ2xGO0VBQ0EsT0FBTztDQUNUO0NBQ0EsTUFBTSw0QkFBNEIsVUFBVSxXQUFXLGNBQWM7RUFDbkUsVUFBVSxZQUFZO0VBQ3RCLE1BQU0sWUFBWSxTQUFTLE1BQU07RUFDakMsU0FBUyxRQUFRO0VBQ2pCLFNBQVMsT0FBTztFQUNoQixZQUFZLFVBQVUsVUFBVSxPQUFPLFdBQVcsU0FBUztFQUMzRCxZQUFZLFVBQVUsVUFBVSxVQUFVLFNBQVM7RUFDbkQsY0FBYztFQUNkLGlCQUFpQixRQUFRO0VBQ3pCLGNBQWM7Q0FDaEI7Q0FDQSxNQUFNLGlCQUFpQixJQUFJLElBQUksV0FBVyxRQUFRLGlCQUFpQixnQkFBZ0IsV0FBVyxjQUFjLFlBQVksVUFBVTtFQUNoSSxNQUFNLEtBQUssTUFBTSxHQUFHO0VBQ3BCLE1BQU0sZ0JBQWdCLEtBQUssR0FBRyxZQUFZO0VBQzFDLE1BQU0sS0FBSyxHQUFHO0VBQ2QsTUFBTSxFQUFFLFdBQVcsY0FBYztFQUNqQyxJQUFJLFlBQVksR0FBRztHQUNqQixJQUFJLFlBQVksS0FBSztJQUNuQixtQkFDRSxJQUNBLElBQ0EsV0FDQSxRQUNBLGlCQUNBLGdCQUNBLFdBQ0EsY0FDQSxTQUNGO0lBQ0E7R0FDRixPQUFPLElBQUksWUFBWSxLQUFLO0lBQzFCLHFCQUNFLElBQ0EsSUFDQSxXQUNBLFFBQ0EsaUJBQ0EsZ0JBQ0EsV0FDQSxjQUNBLFNBQ0Y7SUFDQTtHQUNGO0VBQ0Y7RUFDQSxJQUFJLFlBQVksR0FBRztHQUNqQixJQUFJLGdCQUFnQixJQUFJO0lBQ3RCLGdCQUFnQixJQUFJLGlCQUFpQixjQUFjO0dBQ3JEO0dBQ0EsSUFBSSxPQUFPLElBQUk7SUFDYixtQkFBbUIsV0FBVyxFQUFFO0dBQ2xDO0VBQ0YsT0FBTztHQUNMLElBQUksZ0JBQWdCLElBQUk7SUFDdEIsSUFBSSxZQUFZLElBQUk7S0FDbEIsbUJBQ0UsSUFDQSxJQUNBLFdBQ0EsUUFDQSxpQkFDQSxnQkFDQSxXQUNBLGNBQ0EsU0FDRjtJQUNGLE9BQU87S0FDTCxnQkFBZ0IsSUFBSSxpQkFBaUIsZ0JBQWdCLElBQUk7SUFDM0Q7R0FDRixPQUFPO0lBQ0wsSUFBSSxnQkFBZ0IsR0FBRztLQUNyQixtQkFBbUIsV0FBVyxFQUFFO0lBQ2xDO0lBQ0EsSUFBSSxZQUFZLElBQUk7S0FDbEIsY0FDRSxJQUNBLFdBQ0EsUUFDQSxpQkFDQSxnQkFDQSxXQUNBLGNBQ0EsU0FDRjtJQUNGO0dBQ0Y7RUFDRjtDQUNGO0NBQ0EsTUFBTSx3QkFBd0IsSUFBSSxJQUFJLFdBQVcsUUFBUSxpQkFBaUIsZ0JBQWdCLFdBQVcsY0FBYyxjQUFjO0VBQy9ILEtBQUssTUFBTTtFQUNYLEtBQUssTUFBTTtFQUNYLE1BQU0sWUFBWSxHQUFHO0VBQ3JCLE1BQU0sWUFBWSxHQUFHO0VBQ3JCLE1BQU0sZUFBZSxLQUFLLElBQUksV0FBVyxTQUFTO0VBQ2xELElBQUk7RUFDSixLQUFLLElBQUksR0FBRyxJQUFJLGNBQWMsS0FBSztHQUNqQyxNQUFNLFlBQVksR0FBRyxLQUFLLFlBQVksZUFBZSxHQUFHLEVBQUUsSUFBSSxlQUFlLEdBQUcsRUFBRTtHQUNsRixNQUNFLEdBQUcsSUFDSCxXQUNBLFdBQ0EsTUFDQSxpQkFDQSxnQkFDQSxXQUNBLGNBQ0EsU0FDRjtFQUNGO0VBQ0EsSUFBSSxZQUFZLFdBQVc7R0FDekIsZ0JBQ0UsSUFDQSxpQkFDQSxnQkFDQSxNQUNBLE9BQ0EsWUFDRjtFQUNGLE9BQU87R0FDTCxjQUNFLElBQ0EsV0FDQSxRQUNBLGlCQUNBLGdCQUNBLFdBQ0EsY0FDQSxXQUNBLFlBQ0Y7RUFDRjtDQUNGO0NBQ0EsTUFBTSxzQkFBc0IsSUFBSSxJQUFJLFdBQVcsY0FBYyxpQkFBaUIsZ0JBQWdCLFdBQVcsY0FBYyxjQUFjO0VBQ25JLElBQUksSUFBSTtFQUNSLE1BQU0sS0FBSyxHQUFHO0VBQ2QsSUFBSSxLQUFLLEdBQUcsU0FBUztFQUNyQixJQUFJLEtBQUssS0FBSztFQUNkLE9BQU8sS0FBSyxNQUFNLEtBQUssSUFBSTtHQUN6QixNQUFNLEtBQUssR0FBRztHQUNkLE1BQU0sS0FBSyxHQUFHLEtBQUssWUFBWSxlQUFlLEdBQUcsRUFBRSxJQUFJLGVBQWUsR0FBRyxFQUFFO0dBQzNFLElBQUksZ0JBQWdCLElBQUksRUFBRSxHQUFHO0lBQzNCLE1BQ0UsSUFDQSxJQUNBLFdBQ0EsTUFDQSxpQkFDQSxnQkFDQSxXQUNBLGNBQ0EsU0FDRjtHQUNGLE9BQU87SUFDTDtHQUNGO0dBQ0E7RUFDRjtFQUNBLE9BQU8sS0FBSyxNQUFNLEtBQUssSUFBSTtHQUN6QixNQUFNLEtBQUssR0FBRztHQUNkLE1BQU0sS0FBSyxHQUFHLE1BQU0sWUFBWSxlQUFlLEdBQUcsR0FBRyxJQUFJLGVBQWUsR0FBRyxHQUFHO0dBQzlFLElBQUksZ0JBQWdCLElBQUksRUFBRSxHQUFHO0lBQzNCLE1BQ0UsSUFDQSxJQUNBLFdBQ0EsTUFDQSxpQkFDQSxnQkFDQSxXQUNBLGNBQ0EsU0FDRjtHQUNGLE9BQU87SUFDTDtHQUNGO0dBQ0E7R0FDQTtFQUNGO0VBQ0EsSUFBSSxJQUFJLElBQUk7R0FDVixJQUFJLEtBQUssSUFBSTtJQUNYLE1BQU0sVUFBVSxLQUFLO0lBQ3JCLE1BQU0sU0FBUyxVQUFVLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSztJQUMvQyxPQUFPLEtBQUssSUFBSTtLQUNkLE1BQ0UsTUFDQSxHQUFHLEtBQUssWUFBWSxlQUFlLEdBQUcsRUFBRSxJQUFJLGVBQWUsR0FBRyxFQUFFLEdBQ2hFLFdBQ0EsUUFDQSxpQkFDQSxnQkFDQSxXQUNBLGNBQ0EsU0FDRjtLQUNBO0lBQ0Y7R0FDRjtFQUNGLE9BQU8sSUFBSSxJQUFJLElBQUk7R0FDakIsT0FBTyxLQUFLLElBQUk7SUFDZCxRQUFRLEdBQUcsSUFBSSxpQkFBaUIsZ0JBQWdCLElBQUk7SUFDcEQ7R0FDRjtFQUNGLE9BQU87R0FDTCxNQUFNLEtBQUs7R0FDWCxNQUFNLEtBQUs7R0FDWCxNQUFNLG1DQUFtQyxJQUFJLElBQUk7R0FDakQsS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLEtBQUs7SUFDekIsTUFBTSxZQUFZLEdBQUcsS0FBSyxZQUFZLGVBQWUsR0FBRyxFQUFFLElBQUksZUFBZSxHQUFHLEVBQUU7SUFDbEYsSUFBSSxVQUFVLE9BQU8sTUFBTTtLQUN6QixJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixpQkFBaUIsSUFBSSxVQUFVLEdBQUcsR0FBRztNQUNwRixPQUNFLHVDQUNBLEtBQUssVUFBVSxVQUFVLEdBQUcsR0FDNUIsNEJBQ0Y7S0FDRjtLQUNBLGlCQUFpQixJQUFJLFVBQVUsS0FBSyxDQUFDO0lBQ3ZDO0dBQ0Y7R0FDQSxJQUFJO0dBQ0osSUFBSSxVQUFVO0dBQ2QsTUFBTSxjQUFjLEtBQUssS0FBSztHQUM5QixJQUFJLFFBQVE7R0FDWixJQUFJLG1CQUFtQjtHQUN2QixNQUFNLHdCQUF3QixJQUFJLE1BQU0sV0FBVztHQUNuRCxLQUFLLElBQUksR0FBRyxJQUFJLGFBQWEsS0FBSyxzQkFBc0IsS0FBSztHQUM3RCxLQUFLLElBQUksSUFBSSxLQUFLLElBQUksS0FBSztJQUN6QixNQUFNLFlBQVksR0FBRztJQUNyQixJQUFJLFdBQVcsYUFBYTtLQUMxQixRQUFRLFdBQVcsaUJBQWlCLGdCQUFnQixJQUFJO0tBQ3hEO0lBQ0Y7SUFDQSxJQUFJO0lBQ0osSUFBSSxVQUFVLE9BQU8sTUFBTTtLQUN6QixXQUFXLGlCQUFpQixJQUFJLFVBQVUsR0FBRztJQUMvQyxPQUFPO0tBQ0wsS0FBSyxJQUFJLElBQUksS0FBSyxJQUFJLEtBQUs7TUFDekIsSUFBSSxzQkFBc0IsSUFBSSxRQUFRLEtBQUssZ0JBQWdCLFdBQVcsR0FBRyxFQUFFLEdBQUc7T0FDNUUsV0FBVztPQUNYO01BQ0Y7S0FDRjtJQUNGO0lBQ0EsSUFBSSxhQUFhLEtBQUssR0FBRztLQUN2QixRQUFRLFdBQVcsaUJBQWlCLGdCQUFnQixJQUFJO0lBQzFELE9BQU87S0FDTCxzQkFBc0IsV0FBVyxNQUFNLElBQUk7S0FDM0MsSUFBSSxZQUFZLGtCQUFrQjtNQUNoQyxtQkFBbUI7S0FDckIsT0FBTztNQUNMLFFBQVE7S0FDVjtLQUNBLE1BQ0UsV0FDQSxHQUFHLFdBQ0gsV0FDQSxNQUNBLGlCQUNBLGdCQUNBLFdBQ0EsY0FDQSxTQUNGO0tBQ0E7SUFDRjtHQUNGO0dBQ0EsTUFBTSw2QkFBNkIsUUFBUSxZQUFZLHFCQUFxQixJQUFJO0dBQ2hGLElBQUksMkJBQTJCLFNBQVM7R0FDeEMsS0FBSyxJQUFJLGNBQWMsR0FBRyxLQUFLLEdBQUcsS0FBSztJQUNyQyxNQUFNLFlBQVksS0FBSztJQUN2QixNQUFNLFlBQVksR0FBRztJQUNyQixNQUFNLGNBQWMsR0FBRyxZQUFZO0lBQ25DLE1BQU0sU0FBUyxZQUFZLElBQUksS0FFN0IsWUFBWSxNQUFNLGlDQUFpQyxXQUFXLElBQzVEO0lBQ0osSUFBSSxzQkFBc0IsT0FBTyxHQUFHO0tBQ2xDLE1BQ0UsTUFDQSxXQUNBLFdBQ0EsUUFDQSxpQkFDQSxnQkFDQSxXQUNBLGNBQ0EsU0FDRjtJQUNGLE9BQU8sSUFBSSxPQUFPO0tBQ2hCLElBQUksSUFBSSxLQUFLLE1BQU0sMkJBQTJCLElBQUk7TUFDaEQsS0FBSyxXQUFXLFdBQVcsUUFBUSxDQUFDO0tBQ3RDLE9BQU87TUFDTDtLQUNGO0lBQ0Y7R0FDRjtFQUNGO0NBQ0Y7Q0FDQSxNQUFNLFFBQVEsT0FBTyxXQUFXLFFBQVEsVUFBVSxpQkFBaUIsU0FBUztFQUMxRSxNQUFNLEVBQUUsSUFBSSxNQUFNLFlBQVksVUFBVSxjQUFjO0VBQ3RELElBQUksWUFBWSxHQUFHO0dBQ2pCLEtBQUssTUFBTSxVQUFVLFNBQVMsV0FBVyxRQUFRLFFBQVE7R0FDekQ7RUFDRjtFQUNBLElBQUksWUFBWSxLQUFLO0dBQ25CLE1BQU0sU0FBUyxLQUFLLFdBQVcsUUFBUSxRQUFRO0dBQy9DO0VBQ0Y7RUFDQSxJQUFJLFlBQVksSUFBSTtHQUNsQixLQUFLLEtBQUssT0FBTyxXQUFXLFFBQVEsU0FBUztHQUM3QztFQUNGO0VBQ0EsSUFBSSxTQUFTLFVBQVU7R0FDckIsV0FBVyxJQUFJLFdBQVcsTUFBTTtHQUNoQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7SUFDeEMsS0FBSyxTQUFTLElBQUksV0FBVyxRQUFRLFFBQVE7R0FDL0M7R0FDQSxXQUFXLE1BQU0sUUFBUSxXQUFXLE1BQU07R0FDMUM7RUFDRjtFQUNBLElBQUksU0FBUyxRQUFRO0dBQ25CLGVBQWUsT0FBTyxXQUFXLE1BQU07R0FDdkM7RUFDRjtFQUNBLE1BQU0sa0JBQWtCLGFBQWEsS0FBSyxZQUFZLEtBQUs7RUFDM0QsSUFBSSxpQkFBaUI7R0FDbkIsSUFBSSxhQUFhLEdBQUc7SUFDbEIsSUFBSSxXQUFXLGFBQWEsQ0FBQyxHQUFHLGFBQWE7S0FDM0MsV0FBVyxJQUFJLFdBQVcsTUFBTTtJQUNsQyxPQUFPO0tBQ0wsV0FBVyxZQUFZLEVBQUU7S0FDekIsV0FBVyxJQUFJLFdBQVcsTUFBTTtLQUNoQyw0QkFBNEIsV0FBVyxNQUFNLEVBQUUsR0FBRyxjQUFjO0lBQ2xFO0dBQ0YsT0FBTztJQUNMLE1BQU0sRUFBRSxPQUFPLFlBQVksZUFBZTtJQUMxQyxNQUFNLGdCQUFnQjtLQUNwQixJQUFJLE1BQU0sSUFBSSxhQUFhO01BQ3pCLFdBQVcsRUFBRTtLQUNmLE9BQU87TUFDTCxXQUFXLElBQUksV0FBVyxNQUFNO0tBQ2xDO0lBQ0Y7SUFDQSxNQUFNLHFCQUFxQjtLQUN6QixNQUFNLGFBQWEsR0FBRyxjQUFjLENBQUMsQ0FBQyxHQUFHO0tBQ3pDLElBQUksR0FBRyxZQUFZO01BQ2pCLEdBQUcsV0FBVztPQUNaOztNQUVGO0tBQ0Y7S0FDQSxJQUFJLFdBQVcsYUFBYSxDQUFDLFlBQVk7TUFDdkMsUUFBUTtLQUNWLE9BQU87TUFDTCxNQUFNLFVBQVU7T0FDZCxRQUFRO09BQ1IsY0FBYyxXQUFXO01BQzNCLENBQUM7S0FDSDtJQUNGO0lBQ0EsSUFBSSxZQUFZO0tBQ2QsV0FBVyxJQUFJLFNBQVMsWUFBWTtJQUN0QyxPQUFPO0tBQ0wsYUFBYTtJQUNmO0dBQ0Y7RUFDRixPQUFPO0dBQ0wsV0FBVyxJQUFJLFdBQVcsTUFBTTtFQUNsQztDQUNGO0NBQ0EsTUFBTSxXQUFXLE9BQU8saUJBQWlCLGdCQUFnQixXQUFXLE9BQU8sWUFBWSxVQUFVO0VBQy9GLE1BQU0sRUFDSixNQUNBLE9BQ0EsS0FDQSxVQUNBLGlCQUNBLFdBQ0EsV0FDQSxNQUNBLFlBQ0EsU0FDRTtFQUNKLElBQUksY0FBYyxDQUFDLEdBQUc7R0FDcEIsWUFBWTtFQUNkO0VBQ0EsSUFBSSxPQUFPLE1BQU07R0FDZixjQUFjO0dBQ2QsT0FBTyxLQUFLLE1BQU0sZ0JBQWdCLE9BQU8sSUFBSTtHQUM3QyxjQUFjO0VBQ2hCO0VBQ0EsSUFBSSxjQUFjLE1BQU07R0FDdEIsZ0JBQWdCLFlBQVksY0FBYyxLQUFLO0VBQ2pEO0VBQ0EsSUFBSSxZQUFZLEtBQUs7R0FDbkIsZ0JBQWdCLElBQUksV0FBVyxLQUFLO0dBQ3BDO0VBQ0Y7RUFDQSxNQUFNLG1CQUFtQixZQUFZLEtBQUs7RUFDMUMsTUFBTSx3QkFBd0IsQ0FBQyxlQUFlLEtBQUs7RUFDbkQsSUFBSTtFQUNKLElBQUksMEJBQTBCLFlBQVksU0FBUyxNQUFNLHVCQUF1QjtHQUM5RSxnQkFBZ0IsV0FBVyxpQkFBaUIsS0FBSztFQUNuRDtFQUNBLElBQUksWUFBWSxHQUFHO0dBQ2pCLGlCQUFpQixNQUFNLFdBQVcsZ0JBQWdCLFFBQVE7RUFDNUQsT0FBTztHQUNMLElBQUksWUFBWSxLQUFLO0lBQ25CLE1BQU0sU0FBUyxRQUFRLGdCQUFnQixRQUFRO0lBQy9DO0dBQ0Y7R0FDQSxJQUFJLGtCQUFrQjtJQUNwQixvQkFBb0IsT0FBTyxNQUFNLGlCQUFpQixlQUFlO0dBQ25FO0dBQ0EsSUFBSSxZQUFZLElBQUk7SUFDbEIsTUFBTSxLQUFLLE9BQ1QsT0FDQSxpQkFDQSxnQkFDQSxXQUNBLFFBQ0Y7R0FDRixPQUFPLElBQUksbUJBS1gsQ0FBQyxnQkFBZ0IsWUFDaEIsU0FBUyxZQUFZLFlBQVksS0FBSyxZQUFZLEtBQUs7SUFDdEQsZ0JBQ0UsaUJBQ0EsaUJBQ0EsZ0JBQ0EsT0FDQSxJQUNGO0dBQ0YsT0FBTyxJQUFJLFNBQVMsWUFBWSxhQUFhLE1BQU0sUUFBUSxDQUFDLGFBQWEsWUFBWSxJQUFJO0lBQ3ZGLGdCQUFnQixVQUFVLGlCQUFpQixjQUFjO0dBQzNEO0dBQ0EsSUFBSSxVQUFVO0lBQ1osT0FBTyxLQUFLO0dBQ2Q7RUFDRjtFQUNBLE1BQU0sdUJBQXVCLFFBQVEsUUFBUSxjQUFjO0VBQzNELElBQUksMEJBQTBCLFlBQVksU0FBUyxNQUFNLHFCQUFxQixvQkFBb0Isc0JBQXNCO0dBQ3RILDRCQUE0QjtJQUMxQixhQUFhLGdCQUFnQixXQUFXLGlCQUFpQixLQUFLO0lBQzlELG9CQUFvQixvQkFBb0IsT0FBTyxNQUFNLGlCQUFpQixXQUFXO0lBQ2pGLElBQUksc0JBQXNCO0tBQ3hCLE1BQU0sS0FBSztJQUNiO0dBQ0YsR0FBRyxjQUFjO0VBQ25CO0NBQ0Y7Q0FDQSxNQUFNLFVBQVUsVUFBVTtFQUN4QixNQUFNLEVBQUUsTUFBTSxJQUFJLFFBQVEsZUFBZTtFQUN6QyxJQUFJLFNBQVMsVUFBVTtHQUNyQixJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixNQUFNLFlBQVksS0FBSyxNQUFNLFlBQVksUUFBUSxjQUFjLENBQUMsV0FBVyxXQUFXO0lBQ3JJLE1BQU0sU0FBUyxTQUFTLFVBQVU7S0FDaEMsSUFBSSxNQUFNLFNBQVMsU0FBUztNQUMxQixXQUFXLE1BQU0sRUFBRTtLQUNyQixPQUFPO01BQ0wsT0FBTyxLQUFLO0tBQ2Q7SUFDRixDQUFDO0dBQ0gsT0FBTztJQUNMLGVBQWUsSUFBSSxNQUFNO0dBQzNCO0dBQ0E7RUFDRjtFQUNBLElBQUksU0FBUyxRQUFRO0dBQ25CLGlCQUFpQixLQUFLO0dBQ3RCO0VBQ0Y7RUFDQSxNQUFNLHNCQUFzQjtHQUMxQixXQUFXLEVBQUU7R0FDYixJQUFJLGNBQWMsQ0FBQyxXQUFXLGFBQWEsV0FBVyxZQUFZO0lBQ2hFLFdBQVcsV0FBVztHQUN4QjtFQUNGO0VBQ0EsSUFBSSxNQUFNLFlBQVksS0FBSyxjQUFjLENBQUMsV0FBVyxXQUFXO0dBQzlELE1BQU0sRUFBRSxPQUFPLGVBQWU7R0FDOUIsTUFBTSxxQkFBcUIsTUFBTSxJQUFJLGFBQWE7R0FDbEQsSUFBSSxZQUFZO0lBQ2QsV0FBVyxNQUFNLElBQUksZUFBZSxZQUFZO0dBQ2xELE9BQU87SUFDTCxhQUFhO0dBQ2Y7RUFDRixPQUFPO0dBQ0wsY0FBYztFQUNoQjtDQUNGO0NBQ0EsTUFBTSxrQkFBa0IsS0FBSyxRQUFRO0VBQ25DLElBQUk7RUFDSixPQUFPLFFBQVEsS0FBSztHQUNsQixPQUFPLGdCQUFnQixHQUFHO0dBQzFCLFdBQVcsR0FBRztHQUNkLE1BQU07RUFDUjtFQUNBLFdBQVcsR0FBRztDQUNoQjtDQUNBLE1BQU0sb0JBQW9CLFVBQVUsZ0JBQWdCLGFBQWE7RUFDL0QsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsU0FBUyxLQUFLLFNBQVM7R0FDdEUsY0FBYyxRQUFRO0VBQ3hCO0VBQ0EsTUFBTSxFQUFFLEtBQUssT0FBTyxLQUFLLFNBQVMsSUFBSSxHQUFHLE1BQU07RUFDL0MsZ0JBQWdCLENBQUM7RUFDakIsZ0JBQWdCLENBQUM7RUFDakIsSUFBSSxLQUFLO0dBQ1AsZUFBZSxHQUFHO0VBQ3BCO0VBQ0EsTUFBTSxLQUFLO0VBQ1gsSUFBSSxLQUFLO0dBQ1AsSUFBSSxTQUFTO0dBQ2IsUUFBUSxTQUFTLFVBQVUsZ0JBQWdCLFFBQVE7RUFDckQ7RUFDQSxJQUFJLElBQUk7R0FDTixzQkFBc0IsSUFBSSxjQUFjO0VBQzFDO0VBQ0EsNEJBQTRCO0dBQzFCLFNBQVMsY0FBYztFQUN6QixHQUFHLGNBQWM7RUFDakIsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsdUJBQXVCO0dBQ3RFLHlCQUF5QixRQUFRO0VBQ25DO0NBQ0Y7Q0FDQSxNQUFNLG1CQUFtQixVQUFVLGlCQUFpQixnQkFBZ0IsV0FBVyxPQUFPLFlBQVksT0FBTyxRQUFRLE1BQU07RUFDckgsS0FBSyxJQUFJLElBQUksT0FBTyxJQUFJLFNBQVMsUUFBUSxLQUFLO0dBQzVDLFFBQVEsU0FBUyxJQUFJLGlCQUFpQixnQkFBZ0IsVUFBVSxTQUFTO0VBQzNFO0NBQ0Y7Q0FDQSxNQUFNLG1CQUFtQixVQUFVO0VBQ2pDLElBQUksTUFBTSxZQUFZLEdBQUc7R0FDdkIsT0FBTyxnQkFBZ0IsTUFBTSxVQUFVLE9BQU87RUFDaEQ7RUFDQSxJQUFJLE1BQU0sWUFBWSxLQUFLO0dBQ3pCLE9BQU8sTUFBTSxTQUFTLEtBQUs7RUFDN0I7RUFDQSxNQUFNLEtBQUssZ0JBQWdCLE1BQU0sVUFBVSxNQUFNLEVBQUU7RUFDbkQsTUFBTSxjQUFjLE1BQU0sR0FBRztFQUM3QixPQUFPLGNBQWMsZ0JBQWdCLFdBQVcsSUFBSTtDQUN0RDtDQUNBLElBQUksYUFBYTtDQUNqQixNQUFNLFVBQVUsT0FBTyxXQUFXLGNBQWM7RUFDOUMsSUFBSTtFQUNKLElBQUksU0FBUyxNQUFNO0dBQ2pCLElBQUksVUFBVSxRQUFRO0lBQ3BCLFFBQVEsVUFBVSxRQUFRLE1BQU0sTUFBTSxJQUFJO0lBQzFDLFdBQVcsVUFBVSxPQUFPO0dBQzlCO0VBQ0YsT0FBTztHQUNMLE1BQ0UsVUFBVSxVQUFVLE1BQ3BCLE9BQ0EsV0FDQSxNQUNBLE1BQ0EsTUFDQSxTQUNGO0VBQ0Y7RUFDQSxVQUFVLFNBQVM7RUFDbkIsSUFBSSxDQUFDLFlBQVk7R0FDZixhQUFhO0dBQ2IsaUJBQWlCLFFBQVE7R0FDekIsa0JBQWtCO0dBQ2xCLGFBQWE7RUFDZjtDQUNGO0NBQ0EsTUFBTSxZQUFZO0VBQ2hCLEdBQUc7RUFDSCxJQUFJO0VBQ0osR0FBRztFQUNILEdBQUc7RUFDSCxJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7RUFDSixLQUFLO0VBQ0wsR0FBRztFQUNILEdBQUc7Q0FDTDtDQUNBLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSSxvQkFBb0I7RUFDdEIsQ0FBQyxTQUFTLGVBQWUsbUJBQ3ZCLFNBQ0Y7Q0FDRjtDQUNBLE9BQU87RUFDTDtFQUNBO0VBQ0EsV0FBVyxhQUFhLFFBQVEsT0FBTztDQUN6QztBQUNGO0FBQ0EsU0FBUyx5QkFBeUIsRUFBRSxNQUFNLFNBQVMsa0JBQWtCO0NBQ25FLE9BQU8scUJBQXFCLFNBQVMsU0FBUyxtQkFBbUIscUJBQXFCLFlBQVksU0FBUyxvQkFBb0IsU0FBUyxNQUFNLFlBQVksTUFBTSxTQUFTLFNBQVMsTUFBTSxJQUFJLEtBQUssSUFBSTtBQUN2TTtBQUNBLFNBQVMsY0FBYyxFQUFFLFFBQVEsT0FBTyxTQUFTO0NBQy9DLElBQUksU0FBUztFQUNYLE9BQU8sU0FBUztFQUNoQixJQUFJLFNBQVM7Q0FDZixPQUFPO0VBQ0wsT0FBTyxTQUFTLENBQUM7RUFDakIsSUFBSSxTQUFTLENBQUM7Q0FDaEI7QUFDRjtBQUNBLFNBQVMsZUFBZSxnQkFBZ0IsWUFBWTtDQUNsRCxRQUFRLENBQUMsa0JBQWtCLGtCQUFrQixDQUFDLGVBQWUsa0JBQWtCLGNBQWMsQ0FBQyxXQUFXO0FBQzNHO0FBQ0EsU0FBUyx1QkFBdUIsSUFBSSxJQUFJLFVBQVUsT0FBTztDQUN2RCxNQUFNLE1BQU0sR0FBRztDQUNmLE1BQU0sTUFBTSxHQUFHO0NBQ2YsSUFBSSxRQUFRLEdBQUcsS0FBSyxRQUFRLEdBQUcsR0FBRztFQUNoQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQUs7R0FDbkMsTUFBTSxLQUFLLElBQUk7R0FDZixJQUFJLEtBQUssSUFBSTtHQUNiLElBQUksR0FBRyxZQUFZLEtBQUssQ0FBQyxHQUFHLGlCQUFpQjtJQUMzQyxJQUFJLEdBQUcsYUFBYSxLQUFLLEdBQUcsY0FBYyxJQUFJO0tBQzVDLEtBQUssSUFBSSxLQUFLLGVBQWUsSUFBSSxFQUFFO0tBQ25DLEdBQUcsS0FBSyxHQUFHO0lBQ2I7SUFDQSxJQUFJLENBQUMsV0FBVyxHQUFHLGNBQWMsQ0FBQyxHQUNoQyx1QkFBdUIsSUFBSSxFQUFFO0dBQ2pDO0dBQ0EsSUFBSSxHQUFHLFNBQVMsTUFBTTtJQUNwQixJQUFJLEdBQUcsY0FBYyxDQUFDLEdBQUc7S0FDdkIsS0FBSyxJQUFJLEtBQUssZUFBZSxFQUFFO0lBQ2pDO0lBQ0EsR0FBRyxLQUFLLEdBQUc7R0FDYjtHQUNBLElBQUksR0FBRyxTQUFTLFdBQVcsQ0FBQyxHQUFHLElBQUk7SUFDakMsR0FBRyxLQUFLLEdBQUc7R0FDYjtHQUNBLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtJQUM3QyxHQUFHLE9BQU8sR0FBRyxHQUFHLFVBQVU7R0FDNUI7RUFDRjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLFlBQVksS0FBSztDQUN4QixNQUFNLElBQUksSUFBSSxNQUFNO0NBQ3BCLE1BQU0sU0FBUyxDQUFDLENBQUM7Q0FDakIsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHO0NBQ2hCLE1BQU0sTUFBTSxJQUFJO0NBQ2hCLEtBQUssSUFBSSxHQUFHLElBQUksS0FBSyxLQUFLO0VBQ3hCLE1BQU0sT0FBTyxJQUFJO0VBQ2pCLElBQUksU0FBUyxHQUFHO0dBQ2QsSUFBSSxPQUFPLE9BQU8sU0FBUztHQUMzQixJQUFJLElBQUksS0FBSyxNQUFNO0lBQ2pCLEVBQUUsS0FBSztJQUNQLE9BQU8sS0FBSyxDQUFDO0lBQ2I7R0FDRjtHQUNBLElBQUk7R0FDSixJQUFJLE9BQU8sU0FBUztHQUNwQixPQUFPLElBQUksR0FBRztJQUNaLElBQUksSUFBSSxLQUFLO0lBQ2IsSUFBSSxJQUFJLE9BQU8sTUFBTSxNQUFNO0tBQ3pCLElBQUksSUFBSTtJQUNWLE9BQU87S0FDTCxJQUFJO0lBQ047R0FDRjtHQUNBLElBQUksT0FBTyxJQUFJLE9BQU8sS0FBSztJQUN6QixJQUFJLElBQUksR0FBRztLQUNULEVBQUUsS0FBSyxPQUFPLElBQUk7SUFDcEI7SUFDQSxPQUFPLEtBQUs7R0FDZDtFQUNGO0NBQ0Y7Q0FDQSxJQUFJLE9BQU87Q0FDWCxJQUFJLE9BQU8sSUFBSTtDQUNmLE9BQU8sTUFBTSxHQUFHO0VBQ2QsT0FBTyxLQUFLO0VBQ1osSUFBSSxFQUFFO0NBQ1I7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLDJCQUEyQixVQUFVO0NBQzVDLE1BQU0sZUFBZSxTQUFTLFFBQVE7Q0FDdEMsSUFBSSxjQUFjO0VBQ2hCLElBQUksYUFBYSxZQUFZLENBQUMsYUFBYSxlQUFlO0dBQ3hELE9BQU87RUFDVCxPQUFPO0dBQ0wsT0FBTywyQkFBMkIsWUFBWTtFQUNoRDtDQUNGO0FBQ0Y7QUFDQSxTQUFTLGdCQUFnQixPQUFPO0NBQzlCLElBQUksT0FBTztFQUNULEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FDaEMsTUFBTSxFQUFFLENBQUMsU0FBUztDQUN0QjtBQUNGO0FBQ0EsU0FBUyxpQ0FBaUMsYUFBYTtDQUNyRCxJQUFJLFlBQVksYUFBYTtFQUMzQixPQUFPLFlBQVk7Q0FDckI7Q0FDQSxNQUFNLFdBQVcsWUFBWTtDQUM3QixJQUFJLFVBQVU7RUFDWixPQUFPLGlDQUFpQyxTQUFTLE9BQU87Q0FDMUQ7Q0FDQSxPQUFPO0FBQ1Q7QUFFQSxNQUFNLGNBQWMsU0FBUyxLQUFLO0FBQ2xDLElBQUksYUFBYTtBQUNqQixNQUFNLGVBQWU7Q0FDbkIsTUFBTTs7Ozs7Q0FLTixjQUFjO0NBQ2QsUUFBUSxJQUFJLElBQUksV0FBVyxRQUFRLGlCQUFpQixnQkFBZ0IsV0FBVyxjQUFjLFdBQVcsbUJBQW1CO0VBQ3pILElBQUksTUFBTSxNQUFNO0dBQ2QsY0FDRSxJQUNBLFdBQ0EsUUFDQSxpQkFDQSxnQkFDQSxXQUNBLGNBQ0EsV0FDQSxpQkFDRjtFQUNGLE9BQU87R0FDTCxJQUFJLGtCQUFrQixlQUFlLE9BQU8sS0FBSyxDQUFDLEdBQUcsU0FBUyxjQUFjO0lBQzFFLEdBQUcsV0FBVyxHQUFHO0lBQ2pCLEdBQUcsU0FBUyxRQUFRO0lBQ3BCLEdBQUcsS0FBSyxHQUFHO0lBQ1g7R0FDRjtHQUNBLGNBQ0UsSUFDQSxJQUNBLFdBQ0EsUUFDQSxpQkFDQSxXQUNBLGNBQ0EsV0FDQSxpQkFDRjtFQUNGO0NBQ0Y7Q0FDQSxTQUFTO0NBQ1QsV0FBVztBQUNiO0FBQ0EsTUFBTSxXQUFXO0FBQ2pCLFNBQVMsYUFBYSxPQUFPLE1BQU07Q0FDakMsTUFBTSxnQkFBZ0IsTUFBTSxTQUFTLE1BQU0sTUFBTTtDQUNqRCxJQUFJLFdBQVcsYUFBYSxHQUFHO0VBQzdCLGNBQWM7Q0FDaEI7QUFDRjtBQUNBLFNBQVMsY0FBYyxPQUFPLFdBQVcsUUFBUSxpQkFBaUIsZ0JBQWdCLFdBQVcsY0FBYyxXQUFXLG1CQUFtQjtDQUN2SSxNQUFNLEVBQ0osR0FBRyxPQUNILEdBQUcsRUFBRSxvQkFDSDtDQUNKLE1BQU0sa0JBQWtCLGNBQWMsS0FBSztDQUMzQyxNQUFNLFdBQVcsTUFBTSxXQUFXLHVCQUNoQyxPQUNBLGdCQUNBLGlCQUNBLFdBQ0EsaUJBQ0EsUUFDQSxXQUNBLGNBQ0EsV0FDQSxpQkFDRjtDQUNBLE1BQ0UsTUFDQSxTQUFTLGdCQUFnQixNQUFNLFdBQy9CLGlCQUNBLE1BQ0EsaUJBQ0EsVUFDQSxXQUNBLFlBQ0Y7Q0FDQSxJQUFJLFNBQVMsT0FBTyxHQUFHO0VBQ3JCLGFBQWEsT0FBTyxXQUFXO0VBQy9CLGFBQWEsT0FBTyxZQUFZO0VBQ2hDO0dBQ0U7R0FDQSxNQUFNO0dBQ047R0FDQTtHQUNBO0dBQ0E7O0dBRUE7R0FDQTtFQUNGO0VBQ0EsZ0JBQWdCLFVBQVUsTUFBTSxVQUFVO0NBQzVDLE9BQU87RUFDTCxTQUFTLFFBQVEsT0FBTyxJQUFJO0NBQzlCO0FBQ0Y7QUFDQSxTQUFTLGNBQWMsSUFBSSxJQUFJLFdBQVcsUUFBUSxpQkFBaUIsV0FBVyxjQUFjLFdBQVcsRUFBRSxHQUFHLE9BQU8sSUFBSSxTQUFTLEdBQUcsRUFBRSxtQkFBbUI7Q0FDdEosTUFBTSxXQUFXLEdBQUcsV0FBVyxHQUFHO0NBQ2xDLFNBQVMsUUFBUTtDQUNqQixHQUFHLEtBQUssR0FBRztDQUNYLE1BQU0sWUFBWSxHQUFHO0NBQ3JCLE1BQU0sY0FBYyxHQUFHO0NBQ3ZCLE1BQU0sRUFBRSxjQUFjLGVBQWUsY0FBYyxnQkFBZ0I7Q0FDbkUsSUFBSSxlQUFlO0VBQ2pCLFNBQVMsZ0JBQWdCO0VBQ3pCLElBQUksZ0JBQWdCLGVBQWUsU0FBUyxHQUFHO0dBQzdDLE1BQ0UsZUFDQSxXQUNBLFNBQVMsaUJBQ1QsTUFDQSxpQkFDQSxVQUNBLFdBQ0EsY0FDQSxTQUNGO0dBQ0EsSUFBSSxTQUFTLFFBQVEsR0FBRztJQUN0QixTQUFTLFFBQVE7R0FDbkIsT0FBTyxJQUFJLGNBQWM7SUFDdkIsSUFBSSxDQUFDLGFBQWE7S0FDaEI7TUFDRTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7O01BRUE7TUFDQTtNQUNBO0tBQ0Y7S0FDQSxnQkFBZ0IsVUFBVSxXQUFXO0lBQ3ZDO0dBQ0Y7RUFDRixPQUFPO0dBQ0wsU0FBUyxZQUFZO0dBQ3JCLElBQUksYUFBYTtJQUNmLFNBQVMsY0FBYztJQUN2QixTQUFTLGVBQWU7R0FDMUIsT0FBTztJQUNMLFFBQVEsZUFBZSxpQkFBaUIsUUFBUTtHQUNsRDtHQUNBLFNBQVMsT0FBTztHQUNoQixTQUFTLFFBQVEsU0FBUztHQUMxQixTQUFTLGtCQUFrQixjQUFjLEtBQUs7R0FDOUMsSUFBSSxjQUFjO0lBQ2hCLE1BQ0UsTUFDQSxXQUNBLFNBQVMsaUJBQ1QsTUFDQSxpQkFDQSxVQUNBLFdBQ0EsY0FDQSxTQUNGO0lBQ0EsSUFBSSxTQUFTLFFBQVEsR0FBRztLQUN0QixTQUFTLFFBQVE7SUFDbkIsT0FBTztLQUNMO01BQ0U7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBOztNQUVBO01BQ0E7TUFDQTtLQUNGO0tBQ0EsZ0JBQWdCLFVBQVUsV0FBVztJQUN2QztHQUNGLE9BQU8sSUFBSSxnQkFBZ0IsZ0JBQWdCLGNBQWMsU0FBUyxHQUFHO0lBQ25FLE1BQ0UsY0FDQSxXQUNBLFdBQ0EsUUFDQSxpQkFDQSxVQUNBLFdBQ0EsY0FDQSxTQUNGO0lBQ0EsU0FBUyxRQUFRLElBQUk7R0FDdkIsT0FBTztJQUNMLE1BQ0UsTUFDQSxXQUNBLFNBQVMsaUJBQ1QsTUFDQSxpQkFDQSxVQUNBLFdBQ0EsY0FDQSxTQUNGO0lBQ0EsSUFBSSxTQUFTLFFBQVEsR0FBRztLQUN0QixTQUFTLFFBQVE7SUFDbkI7R0FDRjtFQUNGO0NBQ0YsT0FBTztFQUNMLElBQUksZ0JBQWdCLGdCQUFnQixjQUFjLFNBQVMsR0FBRztHQUM1RCxNQUNFLGNBQ0EsV0FDQSxXQUNBLFFBQ0EsaUJBQ0EsVUFDQSxXQUNBLGNBQ0EsU0FDRjtHQUNBLGdCQUFnQixVQUFVLFNBQVM7RUFDckMsT0FBTztHQUNMLGFBQWEsSUFBSSxXQUFXO0dBQzVCLFNBQVMsZ0JBQWdCO0dBQ3pCLElBQUksVUFBVSxZQUFZLEtBQUs7SUFDN0IsU0FBUyxZQUFZLFVBQVUsVUFBVTtHQUMzQyxPQUFPO0lBQ0wsU0FBUyxZQUFZO0dBQ3ZCO0dBQ0EsTUFDRSxNQUNBLFdBQ0EsU0FBUyxpQkFDVCxNQUNBLGlCQUNBLFVBQ0EsV0FDQSxjQUNBLFNBQ0Y7R0FDQSxJQUFJLFNBQVMsUUFBUSxHQUFHO0lBQ3RCLFNBQVMsUUFBUTtHQUNuQixPQUFPO0lBQ0wsTUFBTSxFQUFFLFNBQVMsY0FBYztJQUMvQixJQUFJLFVBQVUsR0FBRztLQUNmLGlCQUFpQjtNQUNmLElBQUksU0FBUyxjQUFjLFdBQVc7T0FDcEMsU0FBUyxTQUFTLFdBQVc7TUFDL0I7S0FDRixHQUFHLE9BQU87SUFDWixPQUFPLElBQUksWUFBWSxHQUFHO0tBQ3hCLFNBQVMsU0FBUyxXQUFXO0lBQy9CO0dBQ0Y7RUFDRjtDQUNGO0FBQ0Y7QUFDQSxJQUFJLFlBQVk7QUFDaEIsU0FBUyx1QkFBdUIsT0FBTyxnQkFBZ0IsaUJBQWlCLFdBQVcsaUJBQWlCLFFBQVEsV0FBVyxjQUFjLFdBQVcsbUJBQW1CLGNBQWMsT0FBTztDQUN0TCxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixRQUFRLENBQUMsV0FBVztFQUNuRSxZQUFZO0VBQ1osUUFBUSxRQUFRLE9BQU8sU0FBUyxNQUFNLENBQ3BDLHVFQUNGO0NBQ0Y7Q0FDQSxNQUFNLEVBQ0osR0FBRyxPQUNILEdBQUcsTUFDSCxJQUFJLFNBQ0osR0FBRyxNQUNILEdBQUcsRUFBRSxZQUFZLGFBQ2Y7Q0FDSixJQUFJO0NBQ0osTUFBTSxnQkFBZ0IsbUJBQW1CLEtBQUs7Q0FDOUMsSUFBSSxlQUFlO0VBQ2pCLElBQUksa0JBQWtCLGVBQWUsZUFBZTtHQUNsRCxtQkFBbUIsZUFBZTtHQUNsQyxlQUFlO0VBQ2pCO0NBQ0Y7Q0FDQSxNQUFNLFVBQVUsTUFBTSxRQUFRLFNBQVMsTUFBTSxNQUFNLE9BQU8sSUFBSSxLQUFLO0NBQ25FLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtFQUM3QyxhQUFhLFNBQVMsa0JBQWtCO0NBQzFDO0NBQ0EsTUFBTSxnQkFBZ0I7Q0FDdEIsTUFBTSxXQUFXO0VBQ2Y7RUFDQSxRQUFRO0VBQ1I7RUFDQTtFQUNBO0VBQ0E7RUFDQSxNQUFNO0VBQ04sV0FBVztFQUNYLFNBQVMsT0FBTyxZQUFZLFdBQVcsVUFBVSxDQUFDO0VBQ2xELGNBQWM7RUFDZCx3QkFBd0I7RUFDeEIsZUFBZTtFQUNmLGNBQWMsQ0FBQztFQUNmO0VBQ0EsYUFBYTtFQUNiLFNBQVMsQ0FBQztFQUNWLFFBQVEsU0FBUyxPQUFPLE9BQU8sT0FBTztHQUNwQyxJQUFJLENBQUMsb0JBQTJCLGVBQWU7SUFDN0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLGVBQWU7S0FDdEMsTUFBTSxJQUFJLE1BQ1Isd0RBQ0Y7SUFDRjtJQUNBLElBQUksU0FBUyxhQUFhO0tBQ3hCLE1BQU0sSUFBSSxNQUNSLHlFQUNGO0lBQ0Y7R0FDRjtHQUNBLE1BQU0sRUFDSixPQUFPLFFBQ1AsY0FDQSxlQUNBLFdBQ0EsU0FDQSxpQkFBaUIsa0JBQ2pCLFdBQVcsWUFDWCxpQkFDRTtHQUNKLElBQUksYUFBYTtHQUNqQixJQUFJLFNBQVMsYUFBYTtJQUN4QixTQUFTLGNBQWM7R0FDekIsT0FBTyxJQUFJLENBQUMsUUFBUTtJQUNsQixhQUFhLGdCQUFnQixjQUFjLGNBQWMsY0FBYyxXQUFXLFNBQVM7SUFDM0YsSUFBSSxtQkFBbUI7SUFDdkIsSUFBSSxZQUFZO0tBQ2QsYUFBYSxXQUFXLG1CQUFtQjtNQUN6QyxJQUFJLGNBQWMsU0FBUyxXQUFXO09BQ3BDLEtBQ0UsZUFDQSxZQUNBLFdBQVcsaUJBQWlCLENBQUMsbUJBQW1CLEtBQUssWUFBWSxJQUFJLFFBQ3JFLENBQ0Y7T0FDQSxpQkFBaUIsT0FBTztPQUN4QixJQUFJLGdCQUFnQixPQUFPLFlBQVk7UUFDckMsT0FBTyxXQUFXLEtBQUs7T0FDekI7TUFDRjtLQUNGO0lBQ0Y7SUFDQSxJQUFJLGdCQUFnQixDQUFDLFNBQVMsd0JBQXdCO0tBQ3BELElBQUksV0FBVyxhQUFhLEVBQUUsTUFBTSxZQUFZO01BQzlDLFNBQVMsS0FBSyxZQUFZO01BQzFCLG1CQUFtQjtLQUNyQjtLQUNBLFFBQVEsY0FBYyxrQkFBa0IsVUFBVSxJQUFJO0tBQ3RELElBQUksQ0FBQyxjQUFjLGdCQUFnQixPQUFPLFlBQVk7TUFDcEQsNEJBQTRCLE9BQU8sV0FBVyxLQUFLLE1BQU0sUUFBUTtLQUNuRTtJQUNGO0lBQ0EsSUFBSSxDQUFDLFlBQVk7S0FDZixLQUFLLGVBQWUsWUFBWSxRQUFRLENBQUM7SUFDM0M7R0FDRjtHQUNBLFNBQVMseUJBQXlCO0dBQ2xDLGdCQUFnQixVQUFVLGFBQWE7R0FDdkMsU0FBUyxnQkFBZ0I7R0FDekIsU0FBUyxlQUFlO0dBQ3hCLElBQUksU0FBUyxTQUFTO0dBQ3RCLElBQUksd0JBQXdCO0dBQzVCLE9BQU8sUUFBUTtJQUNiLElBQUksT0FBTyxlQUFlO0tBQ3hCLE9BQU8sUUFBUSxLQUFLLEdBQUcsT0FBTztLQUM5Qix3QkFBd0I7S0FDeEI7SUFDRjtJQUNBLFNBQVMsT0FBTztHQUNsQjtHQUNBLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxZQUFZO0lBQ3pDLGlCQUFpQixPQUFPO0dBQzFCO0dBQ0EsU0FBUyxVQUFVLENBQUM7R0FDcEIsSUFBSSxlQUFlO0lBQ2pCLElBQUksa0JBQWtCLGVBQWUsaUJBQWlCLHFCQUFxQixlQUFlLFdBQVc7S0FDbkcsZUFBZTtLQUNmLElBQUksZUFBZSxTQUFTLEtBQUssQ0FBQyxNQUFNO01BQ3RDLGVBQWUsUUFBUTtLQUN6QjtJQUNGO0dBQ0Y7R0FDQSxhQUFhLFFBQVEsV0FBVztFQUNsQztFQUNBLFNBQVMsZUFBZTtHQUN0QixJQUFJLENBQUMsU0FBUyxlQUFlO0lBQzNCO0dBQ0Y7R0FDQSxNQUFNLEVBQUUsT0FBTyxRQUFRLGNBQWMsaUJBQWlCLGtCQUFrQixXQUFXLFlBQVksV0FBVyxlQUFlO0dBQ3pILGFBQWEsUUFBUSxZQUFZO0dBQ2pDLE1BQU0sVUFBVSxLQUFLLFlBQVk7R0FDakMsTUFBTSxzQkFBc0I7SUFDMUIsU0FBUyx5QkFBeUI7SUFDbEMsSUFBSSxDQUFDLFNBQVMsY0FBYztLQUMxQjtJQUNGO0lBQ0E7S0FDRTtLQUNBO0tBQ0E7S0FDQTtLQUNBO0tBQ0E7O0tBRUE7S0FDQTtLQUNBO0lBQ0Y7SUFDQSxnQkFBZ0IsVUFBVSxhQUFhO0dBQ3pDO0dBQ0EsTUFBTSxhQUFhLGNBQWMsY0FBYyxjQUFjLFdBQVcsU0FBUztHQUNqRixJQUFJLFlBQVk7SUFDZCxTQUFTLHlCQUF5QjtJQUNsQyxhQUFhLFdBQVcsYUFBYTtHQUN2QztHQUNBLFNBQVMsZUFBZTtHQUN4QjtJQUNFO0lBQ0E7SUFDQTs7SUFFQTs7R0FFRjtHQUNBLElBQUksQ0FBQyxZQUFZO0lBQ2YsY0FBYztHQUNoQjtFQUNGO0VBQ0EsS0FBSyxZQUFZLFNBQVMsTUFBTTtHQUM5QixTQUFTLGdCQUFnQixLQUFLLFNBQVMsY0FBYyxZQUFZLFNBQVMsSUFBSTtHQUM5RSxTQUFTLFlBQVk7RUFDdkI7RUFDQSxPQUFPO0dBQ0wsT0FBTyxTQUFTLGdCQUFnQixLQUFLLFNBQVMsWUFBWTtFQUM1RDtFQUNBLFlBQVksVUFBVSxtQkFBbUIsWUFBWTtHQUNuRCxNQUFNLHNCQUFzQixDQUFDLENBQUMsU0FBUztHQUN2QyxJQUFJLHFCQUFxQjtJQUN2QixTQUFTO0dBQ1g7R0FDQSxNQUFNLGFBQWEsU0FBUyxNQUFNO0dBQ2xDLFNBQVMsU0FBUyxPQUFPLFFBQVE7SUFDL0IsWUFBWSxLQUFLLFVBQVUsQ0FBQztHQUM5QixDQUFDLENBQUMsQ0FBQyxNQUFNLHFCQUFxQjtJQUM1QixJQUFJLFNBQVMsZUFBZSxTQUFTLGVBQWUsU0FBUyxjQUFjLFNBQVMsWUFBWTtLQUM5RjtJQUNGO0lBQ0EscUJBQXFCO0lBQ3JCLFNBQVMsZ0JBQWdCO0lBQ3pCLE1BQU0sRUFBRSxPQUFPLFdBQVc7SUFDMUIsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0tBQzdDLG1CQUFtQixNQUFNO0lBQzNCO0lBQ0Esa0JBQWtCLFVBQVUsa0JBQWtCLEtBQUs7SUFDbkQsSUFBSSxZQUFZO0tBQ2QsT0FBTyxLQUFLO0lBQ2Q7SUFDQSxNQUFNLGNBQWMsQ0FBQyxjQUFjLFNBQVMsUUFBUTtJQUNwRDtLQUNFO0tBQ0E7Ozs7S0FJQSxXQUFXLGNBQWMsU0FBUyxRQUFRLEVBQUU7OztLQUc1QyxhQUFhLE9BQU8sS0FBSyxTQUFTLE9BQU87S0FDekM7S0FDQTtLQUNBO0lBQ0Y7SUFDQSxJQUFJLGFBQWE7S0FDZixPQUFPLGNBQWM7S0FDckIsT0FBTyxXQUFXO0lBQ3BCO0lBQ0EsZ0JBQWdCLFVBQVUsT0FBTyxFQUFFO0lBQ25DLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtLQUM3QyxrQkFBa0I7SUFDcEI7SUFDQSxJQUFJLHVCQUF1QixFQUFFLFNBQVMsU0FBUyxHQUFHO0tBQ2hELFNBQVMsUUFBUTtJQUNuQjtHQUNGLENBQUM7RUFDSDtFQUNBLFFBQVEsaUJBQWlCLFVBQVU7R0FDakMsU0FBUyxjQUFjO0dBQ3ZCLElBQUksU0FBUyxjQUFjO0lBQ3pCLFFBQ0UsU0FBUyxjQUNULGlCQUNBLGlCQUNBLFFBQ0Y7R0FDRjtHQUNBLElBQUksU0FBUyxlQUFlO0lBQzFCLFFBQ0UsU0FBUyxlQUNULGlCQUNBLGlCQUNBLFFBQ0Y7R0FDRjtFQUNGO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGdCQUFnQixNQUFNLE9BQU8saUJBQWlCLGdCQUFnQixXQUFXLGNBQWMsV0FBVyxtQkFBbUIsYUFBYTtDQUN6SSxNQUFNLFdBQVcsTUFBTSxXQUFXO0VBQ2hDO0VBQ0E7RUFDQTtFQUNBLEtBQUs7O0VBRUwsU0FBUyxjQUFjLEtBQUs7RUFDNUI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7Q0FDQSxNQUFNLFNBQVMsWUFDYixNQUNBLFNBQVMsZ0JBQWdCLE1BQU0sV0FDL0IsaUJBQ0EsVUFDQSxjQUNBLFNBQ0Y7Q0FDQSxJQUFJLFNBQVMsU0FBUyxHQUFHO0VBQ3ZCLFNBQVMsUUFBUSxPQUFPLElBQUk7Q0FDOUI7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLDBCQUEwQixPQUFPO0NBQ3hDLE1BQU0sRUFBRSxXQUFXLGFBQWE7Q0FDaEMsTUFBTSxpQkFBaUIsWUFBWTtDQUNuQyxNQUFNLFlBQVksc0JBQ2hCLGlCQUFpQixTQUFTLFVBQVUsUUFDdEM7Q0FDQSxNQUFNLGFBQWEsaUJBQWlCLHNCQUFzQixTQUFTLFFBQVEsSUFBSSxZQUFZLE9BQU87QUFDcEc7QUFDQSxTQUFTLHNCQUFzQixHQUFHO0NBQ2hDLElBQUk7Q0FDSixJQUFJLFdBQVcsQ0FBQyxHQUFHO0VBQ2pCLE1BQU0sYUFBYSxzQkFBc0IsRUFBRTtFQUMzQyxJQUFJLFlBQVk7R0FDZCxFQUFFLEtBQUs7R0FDUCxVQUFVO0VBQ1o7RUFDQSxJQUFJLEVBQUU7RUFDTixJQUFJLFlBQVk7R0FDZCxFQUFFLEtBQUs7R0FDUCxRQUFRO0dBQ1IsV0FBVztFQUNiO0NBQ0Y7Q0FDQSxJQUFJLFFBQVEsQ0FBQyxHQUFHO0VBQ2QsTUFBTSxjQUFjLGlCQUFpQixDQUFDO0VBQ3RDLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLENBQUMsZUFBZSxFQUFFLFFBQVEsVUFBVSxVQUFVLHNCQUFzQixDQUFDLENBQUMsU0FBUyxHQUFHO0dBQ2pJLE9BQU8sNkNBQTZDO0VBQ3REO0VBQ0EsSUFBSTtDQUNOO0NBQ0EsSUFBSSxlQUFlLENBQUM7Q0FDcEIsSUFBSSxTQUFTLENBQUMsRUFBRSxpQkFBaUI7RUFDL0IsRUFBRSxrQkFBa0IsTUFBTSxRQUFRLE1BQU0sTUFBTSxDQUFDO0NBQ2pEO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyx3QkFBd0IsSUFBSSxVQUFVO0NBQzdDLElBQUksWUFBWSxTQUFTLGVBQWU7RUFDdEMsSUFBSSxRQUFRLEVBQUUsR0FBRztHQUNmLFNBQVMsUUFBUSxLQUFLLEdBQUcsRUFBRTtFQUM3QixPQUFPO0dBQ0wsU0FBUyxRQUFRLEtBQUssRUFBRTtFQUMxQjtDQUNGLE9BQU87RUFDTCxpQkFBaUIsRUFBRTtDQUNyQjtBQUNGO0FBQ0EsU0FBUyxnQkFBZ0IsVUFBVSxRQUFRO0NBQ3pDLFNBQVMsZUFBZTtDQUN4QixNQUFNLEVBQUUsT0FBTyxvQkFBb0I7Q0FDbkMsSUFBSSxLQUFLLE9BQU87Q0FDaEIsT0FBTyxDQUFDLE1BQU0sT0FBTyxXQUFXO0VBQzlCLFNBQVMsT0FBTyxVQUFVO0VBQzFCLEtBQUssT0FBTztDQUNkO0NBQ0EsTUFBTSxLQUFLO0NBQ1gsSUFBSSxtQkFBbUIsZ0JBQWdCLFlBQVksT0FBTztFQUN4RCxnQkFBZ0IsTUFBTSxLQUFLO0VBQzNCLGdCQUFnQixpQkFBaUIsRUFBRTtDQUNyQztBQUNGO0FBQ0EsU0FBUyxtQkFBbUIsT0FBTztDQUNqQyxNQUFNLGNBQWMsTUFBTSxTQUFTLE1BQU0sTUFBTTtDQUMvQyxPQUFPLGVBQWUsUUFBUSxnQkFBZ0I7QUFDaEQ7QUFFQSxNQUFNLFdBQTJCLHVCQUFPLElBQUksT0FBTztBQUNuRCxNQUFNLE9BQXVCLHVCQUFPLElBQUksT0FBTztBQUMvQyxNQUFNLFVBQTBCLHVCQUFPLElBQUksT0FBTztBQUNsRCxNQUFNLFNBQXlCLHVCQUFPLElBQUksT0FBTztBQUNqRCxNQUFNLGFBQWEsQ0FBQztBQUNwQixJQUFJLGVBQWU7QUFDbkIsU0FBUyxVQUFVLGtCQUFrQixPQUFPO0NBQzFDLFdBQVcsS0FBSyxlQUFlLGtCQUFrQixPQUFPLENBQUMsQ0FBQztBQUM1RDtBQUNBLFNBQVMsYUFBYTtDQUNwQixXQUFXLElBQUk7Q0FDZixlQUFlLFdBQVcsV0FBVyxTQUFTLE1BQU07QUFDdEQ7QUFDQSxJQUFJLHFCQUFxQjtBQUN6QixTQUFTLGlCQUFpQixPQUFPLFVBQVUsT0FBTztDQUNoRCxzQkFBc0I7Q0FDdEIsSUFBSSxRQUFRLEtBQUssZ0JBQWdCLFNBQVM7RUFDeEMsYUFBYSxVQUFVO0NBQ3pCO0FBQ0Y7QUFDQSxTQUFTLFdBQVcsT0FBTztDQUN6QixNQUFNLGtCQUFrQixxQkFBcUIsSUFBSSxnQkFBZ0IsWUFBWTtDQUM3RSxXQUFXO0NBQ1gsSUFBSSxxQkFBcUIsS0FBSyxjQUFjO0VBQzFDLGFBQWEsS0FBSyxLQUFLO0NBQ3pCO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxtQkFBbUIsTUFBTSxPQUFPLFVBQVUsV0FBVyxjQUFjLFdBQVc7Q0FDckYsT0FBTyxXQUNMLGdCQUNFLE1BQ0EsT0FDQSxVQUNBLFdBQ0EsY0FDQSxXQUNBLElBQ0YsQ0FDRjtBQUNGO0FBQ0EsU0FBUyxZQUFZLE1BQU0sT0FBTyxVQUFVLFdBQVcsY0FBYztDQUNuRSxPQUFPLFdBQ0wsWUFDRSxNQUNBLE9BQ0EsVUFDQSxXQUNBLGNBQ0EsSUFDRixDQUNGO0FBQ0Y7QUFDQSxTQUFTLFFBQVEsT0FBTztDQUN0QixPQUFPLFFBQVEsTUFBTSxnQkFBZ0IsT0FBTztBQUM5QztBQUNBLFNBQVMsZ0JBQWdCLElBQUksSUFBSTtDQUMvQixJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixHQUFHLFlBQVksS0FBSyxHQUFHLFdBQVc7RUFDakYsTUFBTSxpQkFBaUIsbUJBQW1CLElBQUksR0FBRyxJQUFJO0VBQ3JELElBQUksa0JBQWtCLGVBQWUsSUFBSSxHQUFHLFNBQVMsR0FBRztHQUN0RCxHQUFHLGFBQWEsQ0FBQztHQUNqQixHQUFHLGFBQWEsQ0FBQztHQUNqQixPQUFPO0VBQ1Q7Q0FDRjtDQUNBLE9BQU8sR0FBRyxTQUFTLEdBQUcsUUFBUSxHQUFHLFFBQVEsR0FBRztBQUM5QztBQUNBLElBQUk7QUFDSixTQUFTLG1CQUFtQixhQUFhO0NBQ3ZDLHVCQUF1QjtBQUN6QjtBQUNBLE1BQU0sZ0NBQWdDLEdBQUcsU0FBUztDQUNoRCxPQUFPLGFBQ0wsR0FBRyx1QkFBdUIscUJBQXFCLE1BQU0sd0JBQXdCLElBQUksSUFDbkY7QUFDRjtBQUNBLE1BQU0sZ0JBQWdCLEVBQUUsVUFBVSxPQUFPLE9BQU8sTUFBTTtBQUN0RCxNQUFNLGdCQUFnQixFQUNwQixLQUNBLFNBQ0EsY0FDSTtDQUNKLElBQUksT0FBTyxRQUFRLFVBQVU7RUFDM0IsTUFBTSxLQUFLO0NBQ2I7Q0FDQSxPQUFPLE9BQU8sT0FBTyxTQUFTLEdBQUcsS0FBSyxNQUFNLEdBQUcsS0FBSyxXQUFXLEdBQUcsSUFBSTtFQUFFLEdBQUc7RUFBMEIsR0FBRztFQUFLLEdBQUc7RUFBUyxHQUFHLENBQUMsQ0FBQztDQUFRLElBQUksTUFBTTtBQUNsSjtBQUNBLFNBQVMsZ0JBQWdCLE1BQU0sUUFBUSxNQUFNLFdBQVcsTUFBTSxZQUFZLEdBQUcsZUFBZSxNQUFNLFlBQVksU0FBUyxXQUFXLElBQUksR0FBRyxjQUFjLE9BQU8sZ0NBQWdDLE9BQU87Q0FDbk0sTUFBTSxRQUFRO0VBQ1osYUFBYTtFQUNiLFVBQVU7RUFDVjtFQUNBO0VBQ0EsS0FBSyxTQUFTLGFBQWEsS0FBSztFQUNoQyxLQUFLLFNBQVMsYUFBYSxLQUFLO0VBQ2hDLFNBQVM7RUFDVCxjQUFjO0VBQ2Q7RUFDQSxXQUFXO0VBQ1gsVUFBVTtFQUNWLFdBQVc7RUFDWCxZQUFZO0VBQ1osTUFBTTtFQUNOLFlBQVk7RUFDWixJQUFJO0VBQ0osUUFBUTtFQUNSLFFBQVE7RUFDUixhQUFhO0VBQ2IsY0FBYztFQUNkLGFBQWE7RUFDYjtFQUNBO0VBQ0E7RUFDQSxpQkFBaUI7RUFDakIsWUFBWTtFQUNaLEtBQUs7Q0FDUDtDQUNBLElBQUksK0JBQStCO0VBQ2pDLGtCQUFrQixPQUFPLFFBQVE7RUFDakMsSUFBSSxZQUFZLEtBQUs7R0FDbkIsS0FBSyxVQUFVLEtBQUs7RUFDdEI7Q0FDRixPQUFPLElBQUksVUFBVTtFQUNuQixNQUFNLGFBQWEsU0FBUyxRQUFRLElBQUksSUFBSTtDQUM5QztDQUNBLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLE1BQU0sUUFBUSxNQUFNLEtBQUs7RUFDeEUsT0FBTyxxREFBcUQsTUFBTSxJQUFJO0NBQ3hFO0NBQ0EsSUFBSSxxQkFBcUIsS0FDekIsQ0FBQyxlQUNELGlCQUlDLE1BQU0sWUFBWSxLQUFLLFlBQVksTUFFcEMsTUFBTSxjQUFjLElBQUk7RUFDdEIsYUFBYSxLQUFLLEtBQUs7Q0FDekI7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxNQUFNLGNBQWMsQ0FBQyxvQkFBMkIsZ0JBQWdCLCtCQUErQjtBQUMvRixTQUFTLGFBQWEsTUFBTSxRQUFRLE1BQU0sV0FBVyxNQUFNLFlBQVksR0FBRyxlQUFlLE1BQU0sY0FBYyxPQUFPO0NBQ2xILElBQUksQ0FBQyxRQUFRLFNBQVMsd0JBQXdCO0VBQzVDLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLENBQUMsTUFBTTtHQUN0RCxPQUFPLDJDQUEyQyxLQUFLLEVBQUU7RUFDM0Q7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLFFBQVEsSUFBSSxHQUFHO0VBQ2pCLE1BQU0sU0FBUztHQUNiO0dBQ0E7R0FDQTs7RUFFRjtFQUNBLElBQUksVUFBVTtHQUNaLGtCQUFrQixRQUFRLFFBQVE7RUFDcEM7RUFDQSxJQUFJLHFCQUFxQixLQUFLLENBQUMsZUFBZSxjQUFjO0dBQzFELElBQUksT0FBTyxZQUFZLEdBQUc7SUFDeEIsYUFBYSxhQUFhLFFBQVEsSUFBSSxLQUFLO0dBQzdDLE9BQU87SUFDTCxhQUFhLEtBQUssTUFBTTtHQUMxQjtFQUNGO0VBQ0EsT0FBTyxZQUFZLENBQUM7RUFDcEIsT0FBTztDQUNUO0NBQ0EsSUFBSSxpQkFBaUIsSUFBSSxHQUFHO0VBQzFCLE9BQU8sS0FBSztDQUNkO0NBQ0EsSUFBSSxPQUFPO0VBQ1QsUUFBUSxtQkFBbUIsS0FBSztFQUNoQyxJQUFJLEVBQUUsT0FBTyxPQUFPLFVBQVU7RUFDOUIsSUFBSSxTQUFTLENBQUMsU0FBUyxLQUFLLEdBQUc7R0FDN0IsTUFBTSxRQUFRLGVBQWUsS0FBSztFQUNwQztFQUNBLElBQUksU0FBUyxLQUFLLEdBQUc7R0FDbkIsSUFBSSxRQUFRLEtBQUssS0FBSyxDQUFDLFFBQVEsS0FBSyxHQUFHO0lBQ3JDLFFBQVEsT0FBTyxDQUFDLEdBQUcsS0FBSztHQUMxQjtHQUNBLE1BQU0sUUFBUSxlQUFlLEtBQUs7RUFDcEM7Q0FDRjtDQUNBLE1BQU0sWUFBWSxTQUFTLElBQUksSUFBSSxJQUFJLFdBQVcsSUFBSSxJQUFJLE1BQU0sV0FBVyxJQUFJLElBQUksS0FBSyxTQUFTLElBQUksSUFBSSxJQUFJLFdBQVcsSUFBSSxJQUFJLElBQUk7Q0FDcEksSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsWUFBWSxLQUFLLFFBQVEsSUFBSSxHQUFHO0VBQy9FLE9BQU8sTUFBTSxJQUFJO0VBQ2pCLE9BQ0UsMk5BQ0E7cUNBRUEsSUFDRjtDQUNGO0NBQ0EsT0FBTyxnQkFDTCxNQUNBLE9BQ0EsVUFDQSxXQUNBLGNBQ0EsV0FDQSxhQUNBLElBQ0Y7QUFDRjtBQUNBLFNBQVMsbUJBQW1CLE9BQU87Q0FDakMsSUFBSSxDQUFDLE9BQU8sT0FBTztDQUNuQixPQUFPLFFBQVEsS0FBSyxLQUFLLGlCQUFpQixLQUFLLElBQUksT0FBTyxDQUFDLEdBQUcsS0FBSyxJQUFJO0FBQ3pFO0FBQ0EsU0FBUyxXQUFXLE9BQU8sWUFBWSxXQUFXLE9BQU8sa0JBQWtCLE9BQU87Q0FDaEYsTUFBTSxFQUFFLE9BQU8sS0FBSyxXQUFXLFVBQVUsZUFBZTtDQUN4RCxNQUFNLGNBQWMsYUFBYSxXQUFXLFNBQVMsQ0FBQyxHQUFHLFVBQVUsSUFBSTtDQUN2RSxNQUFNLFNBQVM7RUFDYixhQUFhO0VBQ2IsVUFBVTtFQUNWLE1BQU0sTUFBTTtFQUNaLE9BQU87RUFDUCxLQUFLLGVBQWUsYUFBYSxXQUFXO0VBQzVDLEtBQUssY0FBYyxXQUFXLE1BSTVCLFlBQVksTUFBTSxRQUFRLEdBQUcsSUFBSSxJQUFJLE9BQU8sYUFBYSxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssYUFBYSxVQUFVLENBQUMsSUFBSSxhQUFhLFVBQVUsSUFDL0g7RUFDSixTQUFTLE1BQU07RUFDZixjQUFjLE1BQU07RUFDcEIsVUFBVSxDQUFDLG9CQUEyQixpQkFBaUIsY0FBYyxDQUFDLEtBQUssUUFBUSxRQUFRLElBQUksU0FBUyxJQUFJLGNBQWMsSUFBSTtFQUM5SCxRQUFRLE1BQU07RUFDZCxhQUFhLE1BQU07RUFDbkIsY0FBYyxNQUFNO0VBQ3BCLGFBQWEsTUFBTTtFQUNuQixXQUFXLE1BQU07Ozs7O0VBS2pCLFdBQVcsY0FBYyxNQUFNLFNBQVMsV0FBVyxjQUFjLENBQUMsSUFBSSxLQUFLLFlBQVksS0FBSztFQUM1RixjQUFjLE1BQU07RUFDcEIsaUJBQWlCLE1BQU07RUFDdkIsWUFBWSxNQUFNO0VBQ2xCLE1BQU0sTUFBTTtFQUNaOzs7OztFQUtBLFdBQVcsTUFBTTtFQUNqQixVQUFVLE1BQU07RUFDaEIsV0FBVyxNQUFNLGFBQWEsV0FBVyxNQUFNLFNBQVM7RUFDeEQsWUFBWSxNQUFNLGNBQWMsV0FBVyxNQUFNLFVBQVU7RUFDM0QsYUFBYSxNQUFNO0VBQ25CLElBQUksTUFBTTtFQUNWLFFBQVEsTUFBTTtFQUNkLEtBQUssTUFBTTtFQUNYLElBQUksTUFBTTtDQUNaO0NBQ0EsSUFBSSxjQUFjLGlCQUFpQjtFQUNqQyxtQkFDRSxRQUNBLFdBQVcsTUFBTSxNQUFNLENBQ3pCO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGVBQWUsT0FBTztDQUM3QixNQUFNLFNBQVMsV0FBVyxLQUFLO0NBQy9CLElBQUksUUFBUSxNQUFNLFFBQVEsR0FBRztFQUMzQixPQUFPLFdBQVcsTUFBTSxTQUFTLElBQUksY0FBYztDQUNyRDtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsZ0JBQWdCLE9BQU8sS0FBSyxPQUFPLEdBQUc7Q0FDN0MsT0FBTyxZQUFZLE1BQU0sTUFBTSxNQUFNLElBQUk7QUFDM0M7QUFDQSxTQUFTLGtCQUFrQixTQUFTLGVBQWU7Q0FDakQsTUFBTSxRQUFRLFlBQVksUUFBUSxNQUFNLE9BQU87Q0FDL0MsTUFBTSxjQUFjO0NBQ3BCLE9BQU87QUFDVDtBQUNBLFNBQVMsbUJBQW1CLE9BQU8sSUFBSSxVQUFVLE9BQU87Q0FDdEQsT0FBTyxXQUFXLFVBQVUsR0FBRyxZQUFZLFNBQVMsTUFBTSxJQUFJLEtBQUssWUFBWSxTQUFTLE1BQU0sSUFBSTtBQUNwRztBQUNBLFNBQVMsZUFBZSxPQUFPO0NBQzdCLElBQUksU0FBUyxRQUFRLE9BQU8sVUFBVSxXQUFXO0VBQy9DLE9BQU8sWUFBWSxPQUFPO0NBQzVCLE9BQU8sSUFBSSxRQUFRLEtBQUssR0FBRztFQUN6QixPQUFPO0dBQ0w7R0FDQTs7R0FFQSxNQUFNLE1BQU07RUFDZDtDQUNGLE9BQU8sSUFBSSxRQUFRLEtBQUssR0FBRztFQUN6QixPQUFPLGVBQWUsS0FBSztDQUM3QixPQUFPO0VBQ0wsT0FBTyxZQUFZLE1BQU0sTUFBTSxPQUFPLEtBQUssQ0FBQztDQUM5QztBQUNGO0FBQ0EsU0FBUyxlQUFlLE9BQU87Q0FDN0IsT0FBTyxNQUFNLE9BQU8sUUFBUSxNQUFNLGNBQWMsQ0FBQyxLQUFLLE1BQU0sT0FBTyxRQUFRLFdBQVcsS0FBSztBQUM3RjtBQUNBLFNBQVMsa0JBQWtCLE9BQU8sVUFBVTtDQUMxQyxJQUFJLE9BQU87Q0FDWCxNQUFNLEVBQUUsY0FBYztDQUN0QixJQUFJLFlBQVksTUFBTTtFQUNwQixXQUFXO0NBQ2IsT0FBTyxJQUFJLFFBQVEsUUFBUSxHQUFHO0VBQzVCLE9BQU87Q0FDVCxPQUFPLElBQUksT0FBTyxhQUFhLFVBQVU7RUFDdkMsSUFBSSxhQUFhLElBQUksS0FBSztHQUN4QixNQUFNLE9BQU8sU0FBUztHQUN0QixJQUFJLE1BQU07SUFDUixLQUFLLE9BQU8sS0FBSyxLQUFLO0lBQ3RCLGtCQUFrQixPQUFPLEtBQUssQ0FBQztJQUMvQixLQUFLLE9BQU8sS0FBSyxLQUFLO0dBQ3hCO0dBQ0E7RUFDRixPQUFPO0dBQ0wsT0FBTztHQUNQLE1BQU0sV0FBVyxTQUFTO0dBQzFCLElBQUksQ0FBQyxZQUFZLENBQUMsaUJBQWlCLFFBQVEsR0FBRztJQUM1QyxTQUFTLE9BQU87R0FDbEIsT0FBTyxJQUFJLGFBQWEsS0FBSywwQkFBMEI7SUFDckQsSUFBSSx5QkFBeUIsTUFBTSxNQUFNLEdBQUc7S0FDMUMsU0FBUyxJQUFJO0lBQ2YsT0FBTztLQUNMLFNBQVMsSUFBSTtLQUNiLE1BQU0sYUFBYTtJQUNyQjtHQUNGO0VBQ0Y7Q0FDRixPQUFPLElBQUksV0FBVyxRQUFRLEdBQUc7RUFDL0IsSUFBSSxhQUFhLElBQUksS0FBSztHQUN4QixrQkFBa0IsT0FBTyxFQUFFLFNBQVMsU0FBUyxDQUFDO0dBQzlDO0VBQ0Y7RUFDQSxXQUFXO0dBQUUsU0FBUztHQUFVLE1BQU07RUFBeUI7RUFDL0QsT0FBTztDQUNULE9BQU87RUFDTCxXQUFXLE9BQU8sUUFBUTtFQUMxQixJQUFJLFlBQVksSUFBSTtHQUNsQixPQUFPO0dBQ1AsV0FBVyxDQUFDLGdCQUFnQixRQUFRLENBQUM7RUFDdkMsT0FBTztHQUNMLE9BQU87RUFDVDtDQUNGO0NBQ0EsTUFBTSxXQUFXO0NBQ2pCLE1BQU0sYUFBYTtBQUNyQjtBQUNBLFNBQVMsV0FBVyxHQUFHLE1BQU07Q0FDM0IsTUFBTSxNQUFNLENBQUM7Q0FDYixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUs7RUFDcEMsTUFBTSxVQUFVLEtBQUs7RUFDckIsS0FBSyxNQUFNLE9BQU8sU0FBUztHQUN6QixJQUFJLFFBQVEsU0FBUztJQUNuQixJQUFJLElBQUksVUFBVSxRQUFRLE9BQU87S0FDL0IsSUFBSSxRQUFRLGVBQWUsQ0FBQyxJQUFJLE9BQU8sUUFBUSxLQUFLLENBQUM7SUFDdkQ7R0FDRixPQUFPLElBQUksUUFBUSxTQUFTO0lBQzFCLElBQUksUUFBUSxlQUFlLENBQUMsSUFBSSxPQUFPLFFBQVEsS0FBSyxDQUFDO0dBQ3ZELE9BQU8sSUFBSSxLQUFLLEdBQUcsR0FBRztJQUNwQixNQUFNLFdBQVcsSUFBSTtJQUNyQixNQUFNLFdBQVcsUUFBUTtJQUN6QixJQUFJLFlBQVksYUFBYSxZQUFZLEVBQUUsUUFBUSxRQUFRLEtBQUssU0FBUyxTQUFTLFFBQVEsSUFBSTtLQUM1RixJQUFJLE9BQU8sV0FBVyxDQUFDLENBQUMsQ0FBQyxPQUFPLFVBQVUsUUFBUSxJQUFJO0lBQ3hELE9BQU8sSUFBSSxZQUFZLFFBQVEsWUFBWSxRQUUzQyxDQUFDLGdCQUFnQixHQUFHLEdBQUc7S0FDckIsSUFBSSxPQUFPO0lBQ2I7R0FDRixPQUFPLElBQUksUUFBUSxJQUFJO0lBQ3JCLElBQUksT0FBTyxRQUFRO0dBQ3JCO0VBQ0Y7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsZ0JBQWdCLE1BQU0sVUFBVSxPQUFPLFlBQVksTUFBTTtDQUNoRSwyQkFBMkIsTUFBTSxVQUFVLEdBQUcsQ0FDNUMsT0FDQSxTQUNGLENBQUM7QUFDSDtBQUVBLE1BQU0sa0JBQWtCLGlCQUFpQjtBQUN6QyxJQUFJLE1BQU07QUFDVixTQUFTLHdCQUF3QixPQUFPLFFBQVEsVUFBVTtDQUN4RCxNQUFNLE9BQU8sTUFBTTtDQUNuQixNQUFNLGNBQWMsU0FBUyxPQUFPLGFBQWEsTUFBTSxlQUFlO0NBQ3RFLE1BQU0sV0FBVztFQUNmLEtBQUs7RUFDTDtFQUNBO0VBQ0E7RUFDQTtFQUNBLE1BQU07O0VBRU4sTUFBTTtFQUNOLFNBQVM7O0VBRVQsUUFBUTtFQUNSLFFBQVE7O0VBRVIsS0FBSztFQUNMLE9BQU8sSUFBSTtHQUNUOztFQUVGO0VBQ0EsUUFBUTtFQUNSLE9BQU87RUFDUCxTQUFTO0VBQ1QsYUFBYTtFQUNiLFdBQVc7RUFDWCxVQUFVLFNBQVMsT0FBTyxXQUFXLE9BQU8sT0FBTyxXQUFXLFFBQVE7RUFDdEUsS0FBSyxTQUFTLE9BQU8sTUFBTTtHQUFDO0dBQUk7R0FBRztFQUFDO0VBQ3BDLGFBQWE7RUFDYixhQUFhLENBQUM7O0VBRWQsWUFBWTtFQUNaLFlBQVk7O0VBRVosY0FBYyxzQkFBc0IsTUFBTSxVQUFVO0VBQ3BELGNBQWMsc0JBQXNCLE1BQU0sVUFBVTs7RUFFcEQsTUFBTTs7RUFFTixTQUFTOztFQUVULGVBQWU7O0VBRWYsY0FBYyxLQUFLOztFQUVuQixLQUFLO0VBQ0wsTUFBTTtFQUNOLE9BQU87RUFDUCxPQUFPO0VBQ1AsT0FBTztFQUNQLE1BQU07RUFDTixZQUFZO0VBQ1osY0FBYzs7RUFFZDtFQUNBLFlBQVksV0FBVyxTQUFTLFlBQVk7RUFDNUMsVUFBVTtFQUNWLGVBQWU7OztFQUdmLFdBQVc7RUFDWCxhQUFhO0VBQ2IsZUFBZTtFQUNmLElBQUk7RUFDSixHQUFHO0VBQ0gsSUFBSTtFQUNKLEdBQUc7RUFDSCxJQUFJO0VBQ0osR0FBRztFQUNILElBQUk7RUFDSixLQUFLO0VBQ0wsSUFBSTtFQUNKLEdBQUc7RUFDSCxLQUFLO0VBQ0wsS0FBSztFQUNMLElBQUk7RUFDSixJQUFJO0NBQ047Q0FDQSxJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDN0MsU0FBUyxNQUFNLHVCQUF1QixRQUFRO0NBQ2hELE9BQU87RUFDTCxTQUFTLE1BQU0sRUFBRSxHQUFHLFNBQVM7Q0FDL0I7Q0FDQSxTQUFTLE9BQU8sU0FBUyxPQUFPLE9BQU87Q0FDdkMsU0FBUyxPQUFPLEtBQUssS0FBSyxNQUFNLFFBQVE7Q0FDeEMsSUFBSSxNQUFNLElBQUk7RUFDWixNQUFNLEdBQUcsUUFBUTtDQUNuQjtDQUNBLE9BQU87QUFDVDtBQUNBLElBQUksa0JBQWtCO0FBQ3RCLE1BQU0sMkJBQTJCLG1CQUFtQjtBQUNwRCxJQUFJO0FBQ0osSUFBSTtBQUNKO0NBQ0UsTUFBTSxJQUFJLGNBQWM7Q0FDeEIsTUFBTSx3QkFBd0IsS0FBSyxXQUFXO0VBQzVDLElBQUk7RUFDSixJQUFJLEVBQUUsVUFBVSxFQUFFLE9BQU8sVUFBVSxFQUFFLE9BQU8sQ0FBQztFQUM3QyxRQUFRLEtBQUssTUFBTTtFQUNuQixRQUFRLE1BQU07R0FDWixJQUFJLFFBQVEsU0FBUyxHQUFHLFFBQVEsU0FBUyxRQUFRLElBQUksQ0FBQyxDQUFDO1FBQ2xELFFBQVEsRUFBRSxDQUFDLENBQUM7RUFDbkI7Q0FDRjtDQUNBLDZCQUE2QixxQkFDM0IsNkJBQ0MsTUFBTSxrQkFBa0IsQ0FDM0I7Q0FDQSxxQkFBcUIscUJBQ25CLHdCQUNDLE1BQU0sd0JBQXdCLENBQ2pDO0FBQ0Y7QUFDQSxNQUFNLHNCQUFzQixhQUFhO0NBQ3ZDLE1BQU0sT0FBTztDQUNiLDJCQUEyQixRQUFRO0NBQ25DLFNBQVMsTUFBTSxHQUFHO0NBQ2xCLGFBQWE7RUFDWCxTQUFTLE1BQU0sSUFBSTtFQUNuQiwyQkFBMkIsSUFBSTtDQUNqQztBQUNGO0FBQ0EsTUFBTSw2QkFBNkI7Q0FDakMsbUJBQW1CLGdCQUFnQixNQUFNLElBQUk7Q0FDN0MsMkJBQTJCLElBQUk7QUFDakM7QUFDQSxNQUFNLGVBQStCLHdCQUFRLGdCQUFnQjtBQUM3RCxTQUFTLHNCQUFzQixNQUFNLEVBQUUsZUFBZTtDQUNwRCxJQUFJLGFBQWEsSUFBSSxLQUFLLFlBQVksSUFBSSxHQUFHO0VBQzNDLE9BQ0Usb0VBQW9FLElBQ3RFO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsb0JBQW9CLFVBQVU7Q0FDckMsT0FBTyxTQUFTLE1BQU0sWUFBWTtBQUNwQztBQUNBLElBQUksd0JBQXdCO0FBQzVCLFNBQVMsZUFBZSxVQUFVLFFBQVEsT0FBTyxZQUFZLE9BQU87Q0FDbEUsU0FBUyxtQkFBbUIsS0FBSztDQUNqQyxNQUFNLEVBQUUsT0FBTyxhQUFhLFNBQVM7Q0FDckMsTUFBTSxhQUFhLG9CQUFvQixRQUFRO0NBQy9DLFVBQVUsVUFBVSxPQUFPLFlBQVksS0FBSztDQUM1QyxVQUFVLFVBQVUsVUFBVSxhQUFhLEtBQUs7Q0FDaEQsTUFBTSxjQUFjLGFBQWEsdUJBQXVCLFVBQVUsS0FBSyxJQUFJLEtBQUs7Q0FDaEYsU0FBUyxtQkFBbUIsS0FBSztDQUNqQyxPQUFPO0FBQ1Q7QUFDQSxTQUFTLHVCQUF1QixVQUFVLE9BQU87Q0FDL0MsTUFBTSxZQUFZLFNBQVM7Q0FDM0IsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0VBQzdDLElBQUksVUFBVSxNQUFNO0dBQ2xCLHNCQUFzQixVQUFVLE1BQU0sU0FBUyxXQUFXLE1BQU07RUFDbEU7RUFDQSxJQUFJLFVBQVUsWUFBWTtHQUN4QixNQUFNLFFBQVEsT0FBTyxLQUFLLFVBQVUsVUFBVTtHQUM5QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7SUFDckMsc0JBQXNCLE1BQU0sSUFBSSxTQUFTLFdBQVcsTUFBTTtHQUM1RDtFQUNGO0VBQ0EsSUFBSSxVQUFVLFlBQVk7R0FDeEIsTUFBTSxRQUFRLE9BQU8sS0FBSyxVQUFVLFVBQVU7R0FDOUMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0lBQ3JDLHNCQUFzQixNQUFNLEVBQUU7R0FDaEM7RUFDRjtFQUNBLElBQUksVUFBVSxtQkFBbUIsY0FBYyxHQUFHO0dBQ2hELE9BQ0UsOE1BQ0Y7RUFDRjtDQUNGO0NBQ0EsU0FBUyxjQUE4Qix1QkFBTyxPQUFPLElBQUk7Q0FDekQsU0FBUyxRQUFRLElBQUksTUFBTSxTQUFTLEtBQUssMkJBQTJCO0NBQ3BFLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtFQUM3QywyQkFBMkIsUUFBUTtDQUNyQztDQUNBLE1BQU0sRUFBRSxVQUFVO0NBQ2xCLElBQUksT0FBTztFQUNULGNBQWM7RUFDZCxNQUFNLGVBQWUsU0FBUyxlQUFlLE1BQU0sU0FBUyxJQUFJLG1CQUFtQixRQUFRLElBQUk7RUFDL0YsTUFBTSxRQUFRLG1CQUFtQixRQUFRO0VBQ3pDLE1BQU0sY0FBYyxzQkFDbEIsT0FDQSxVQUNBLEdBQ0EsQ0FDRSxDQUFDLG9CQUEyQixnQkFBZ0IsZ0JBQWdCLFNBQVMsS0FBSyxJQUFJLFNBQVMsT0FDdkYsWUFDRixDQUNGO0VBQ0EsTUFBTSxlQUFlLFVBQVUsV0FBVztFQUMxQyxjQUFjO0VBQ2QsTUFBTTtFQUNOLEtBQUssZ0JBQWdCLFNBQVMsT0FBTyxDQUFDLGVBQWUsUUFBUSxHQUFHO0dBQzlELGtCQUFrQixRQUFRO0VBQzVCO0VBQ0EsSUFBSSxjQUFjO0dBQ2hCLFlBQVksS0FBSyxzQkFBc0Isb0JBQW9CO0dBQzNELElBQUksT0FBTztJQUNULE9BQU8sWUFBWSxNQUFNLG1CQUFtQjtLQUMxQyxrQkFBa0IsVUFBVSxnQkFBZ0IsS0FBSztJQUNuRCxDQUFDLENBQUMsQ0FBQyxPQUFPLE1BQU07S0FDZCxZQUFZLEdBQUcsVUFBVSxDQUFDO0lBQzVCLENBQUM7R0FDSCxPQUFPO0lBQ0wsU0FBUyxXQUFXO0lBQ3BCLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLENBQUMsU0FBUyxVQUFVO0tBQ25FLE1BQU0sT0FBTyxvQkFBb0IsVUFBVSxTQUFTO0tBQ3BELE9BQ0UsY0FBYyxLQUFLLGdNQUNyQjtJQUNGO0dBQ0Y7RUFDRixPQUFPO0dBQ0wsa0JBQWtCLFVBQVUsYUFBYSxLQUFLO0VBQ2hEO0NBQ0YsT0FBTztFQUNMLHFCQUFxQixVQUFVLEtBQUs7Q0FDdEM7QUFDRjtBQUNBLFNBQVMsa0JBQWtCLFVBQVUsYUFBYSxPQUFPO0NBQ3ZELElBQUksV0FBVyxXQUFXLEdBQUc7RUFDM0IsSUFBSSxTQUFTLEtBQUssbUJBQW1CO0dBQ25DLFNBQVMsWUFBWTtFQUN2QixPQUFPO0dBQ0wsU0FBUyxTQUFTO0VBQ3BCO0NBQ0YsT0FBTyxJQUFJLFNBQVMsV0FBVyxHQUFHO0VBQ2hDLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLFFBQVEsV0FBVyxHQUFHO0dBQ3JFLE9BQ0UsK0VBQ0Y7RUFDRjtFQUNBLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLHVCQUF1QjtHQUN0RSxTQUFTLHdCQUF3QjtFQUNuQztFQUNBLFNBQVMsYUFBYSxVQUFVLFdBQVc7RUFDM0MsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0dBQzdDLGdDQUFnQyxRQUFRO0VBQzFDO0NBQ0YsT0FBTyxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixnQkFBZ0IsS0FBSyxHQUFHO0VBQzlFLE9BQ0UsOENBQThDLGdCQUFnQixPQUFPLFNBQVMsT0FBTyxhQUN2RjtDQUNGO0NBQ0EscUJBQXFCLFVBQVUsS0FBSztBQUN0QztBQUNBLElBQUk7QUFDSixJQUFJO0FBQ0osU0FBUyx3QkFBd0IsVUFBVTtDQUN6QyxVQUFVO0NBQ1Ysb0JBQW9CLE1BQU07RUFDeEIsSUFBSSxFQUFFLE9BQU8sS0FBSztHQUNoQixFQUFFLFlBQVksSUFBSSxNQUFNLEVBQUUsS0FBSywwQ0FBMEM7RUFDM0U7Q0FDRjtBQUNGO0FBQ0EsTUFBTSxzQkFBc0IsQ0FBQztBQUM3QixTQUFTLHFCQUFxQixVQUFVLE9BQU8sYUFBYTtDQUMxRCxNQUFNLFlBQVksU0FBUztDQUMzQixJQUFJLENBQUMsU0FBUyxRQUFRO0VBQ3BCLElBQUksQ0FBQyxTQUFTLFdBQVcsQ0FBQyxVQUFVLFFBQVE7R0FDMUMsTUFBTSxXQUFXLFVBQVUsWUFBWSx1QkFBdUIscUJBQXFCLFFBQVEsQ0FBQyxDQUFDO0dBQzdGLElBQUksVUFBVTtJQUNaLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtLQUM3QyxhQUFhLFVBQVUsU0FBUztJQUNsQztJQUNBLE1BQU0sRUFBRSxpQkFBaUIsb0JBQW9CLFNBQVMsV0FBVztJQUNqRSxNQUFNLEVBQUUsWUFBWSxpQkFBaUIsNkJBQTZCO0lBQ2xFLE1BQU0sdUJBQXVCLE9BQzNCLE9BQ0U7S0FDRTtLQUNBO0lBQ0YsR0FDQSxlQUNGLEdBQ0Esd0JBQ0Y7SUFDQSxVQUFVLFNBQVMsUUFBUSxVQUFVLG9CQUFvQjtJQUN6RCxJQUFJLENBQUMsb0JBQTJCLGVBQWU7S0FDN0MsV0FBVyxVQUFVLFNBQVM7SUFDaEM7R0FDRjtFQUNGO0VBQ0EsU0FBUyxTQUFTLFVBQVUsVUFBVTtFQUN0QyxJQUFJLGtCQUFrQjtHQUNwQixpQkFBaUIsUUFBUTtFQUMzQjtDQUNGO0NBQ0EsSUFBSSx1QkFBdUIsTUFBTTtFQUMvQixNQUFNLFFBQVEsbUJBQW1CLFFBQVE7RUFDekMsY0FBYztFQUNkLElBQUk7R0FDRixhQUFhLFFBQVE7RUFDdkIsVUFBVTtHQUNSLGNBQWM7R0FDZCxNQUFNO0VBQ1I7Q0FDRjtDQUNBLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLENBQUMsVUFBVSxVQUFVLFNBQVMsV0FBVyxRQUFRLENBQUMsT0FBTztFQUN4RyxJQUFJLENBQUMsV0FBVyxVQUFVLFVBQVU7R0FDbEMsT0FDRSxzR0FBdUcsMEVBQ3pHO0VBQ0YsT0FBTztHQUNMLE9BQU8sc0RBQXNELFNBQVM7RUFDeEU7Q0FDRjtBQUNGO0FBQ0EsTUFBTSxxQkFBcUIsQ0FBQyxvQkFBMkIsZ0JBQWdCO0NBQ3JFLElBQUksUUFBUSxLQUFLO0VBQ2Ysa0JBQWtCO0VBQ2xCLE1BQU0sUUFBUSxPQUFPLEVBQUU7RUFDdkIsT0FBTyxPQUFPO0NBQ2hCO0NBQ0EsTUFBTTtFQUNKLE9BQU8saUNBQWlDO0VBQ3hDLE9BQU87Q0FDVDtDQUNBLGlCQUFpQjtFQUNmLE9BQU8saUNBQWlDO0VBQ3hDLE9BQU87Q0FDVDtBQUNGLElBQUksRUFDRixJQUFJLFFBQVEsS0FBSztDQUNmLE1BQU0sUUFBUSxPQUFPLEVBQUU7Q0FDdkIsT0FBTyxPQUFPO0FBQ2hCLEVBQ0Y7QUFDQSxTQUFTLGNBQWMsVUFBVTtDQUMvQixPQUFPLElBQUksTUFBTSxTQUFTLE9BQU8sRUFDL0IsSUFBSSxRQUFRLEtBQUs7RUFDZixNQUFNLFVBQVUsT0FBTyxRQUFRO0VBQy9CLE9BQU8sT0FBTztDQUNoQixFQUNGLENBQUM7QUFDSDtBQUNBLFNBQVMsbUJBQW1CLFVBQVU7Q0FDcEMsTUFBTSxVQUFVLFlBQVk7RUFDMUIsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0dBQzdDLElBQUksU0FBUyxTQUFTO0lBQ3BCLE9BQU8sa0RBQWtEO0dBQzNEO0dBQ0EsSUFBSSxXQUFXLE1BQU07SUFDbkIsSUFBSSxjQUFjLE9BQU87SUFDekIsSUFBSSxnQkFBZ0IsVUFBVTtLQUM1QixJQUFJLFFBQVEsT0FBTyxHQUFHO01BQ3BCLGNBQWM7S0FDaEIsT0FBTyxJQUFJLE1BQU0sT0FBTyxHQUFHO01BQ3pCLGNBQWM7S0FDaEI7SUFDRjtJQUNBLElBQUksZ0JBQWdCLFVBQVU7S0FDNUIsT0FDRSxzREFBc0QsWUFBWSxFQUNwRTtJQUNGO0dBQ0Y7RUFDRjtFQUNBLFNBQVMsVUFBVSxXQUFXLENBQUM7Q0FDakM7Q0FDQSxJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDN0MsSUFBSTtFQUNKLElBQUk7RUFDSixPQUFPLE9BQU8sT0FBTztHQUNuQixJQUFJLFFBQVE7SUFDVixPQUFPLGVBQWUsYUFBYSxJQUFJLE1BQU0sU0FBUyxPQUFPLGtCQUFrQjtHQUNqRjtHQUNBLElBQUksUUFBUTtJQUNWLE9BQU8sZUFBZSxhQUFhLGNBQWMsUUFBUTtHQUMzRDtHQUNBLElBQUksT0FBTztJQUNULFFBQVEsT0FBTyxHQUFHLFNBQVMsU0FBUyxLQUFLLE9BQU8sR0FBRyxJQUFJO0dBQ3pEO0dBQ0E7RUFDRixDQUFDO0NBQ0gsT0FBTztFQUNMLE9BQU87R0FDTCxPQUFPLElBQUksTUFBTSxTQUFTLE9BQU8sa0JBQWtCO0dBQ25ELE9BQU8sU0FBUztHQUNoQixNQUFNLFNBQVM7R0FDZjtFQUNGO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsMkJBQTJCLFVBQVU7Q0FDNUMsSUFBSSxTQUFTLFNBQVM7RUFDcEIsT0FBTyxTQUFTLGdCQUFnQixTQUFTLGNBQWMsSUFBSSxNQUFNLFVBQVUsUUFBUSxTQUFTLE9BQU8sQ0FBQyxHQUFHO0dBQ3JHLElBQUksUUFBUSxLQUFLO0lBQ2YsSUFBSSxPQUFPLFFBQVE7S0FDakIsT0FBTyxPQUFPO0lBQ2hCLE9BQU8sSUFBSSxPQUFPLHFCQUFxQjtLQUNyQyxPQUFPLG9CQUFvQixJQUFJLENBQUMsUUFBUTtJQUMxQztHQUNGO0dBQ0EsSUFBSSxRQUFRLEtBQUs7SUFDZixPQUFPLE9BQU8sVUFBVSxPQUFPO0dBQ2pDO0VBQ0YsQ0FBQztDQUNILE9BQU87RUFDTCxPQUFPLFNBQVM7Q0FDbEI7QUFDRjtBQUNBLE1BQU0sYUFBYTtBQUNuQixNQUFNLFlBQVksUUFBUSxJQUFJLFFBQVEsYUFBYSxNQUFNLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQyxRQUFRLFNBQVMsRUFBRTtBQUM3RixTQUFTLGlCQUFpQixXQUFXLGtCQUFrQixNQUFNO0NBQzNELE9BQU8sV0FBVyxTQUFTLElBQUksVUFBVSxlQUFlLFVBQVUsT0FBTyxVQUFVLFFBQVEsbUJBQW1CLFVBQVU7QUFDMUg7QUFDQSxTQUFTLG9CQUFvQixVQUFVLFdBQVcsU0FBUyxPQUFPO0NBQ2hFLElBQUksT0FBTyxpQkFBaUIsU0FBUztDQUNyQyxJQUFJLENBQUMsUUFBUSxVQUFVLFFBQVE7RUFDN0IsTUFBTSxRQUFRLFVBQVUsT0FBTyxNQUFNLGlCQUFpQjtFQUN0RCxJQUFJLE9BQU87R0FDVCxPQUFPLE1BQU07RUFDZjtDQUNGO0NBQ0EsSUFBSSxDQUFDLFFBQVEsVUFBVTtFQUNyQixNQUFNLHFCQUFxQixhQUFhO0dBQ3RDLEtBQUssTUFBTSxPQUFPLFVBQVU7SUFDMUIsSUFBSSxTQUFTLFNBQVMsV0FBVztLQUMvQixPQUFPO0lBQ1Q7R0FDRjtFQUNGO0VBQ0EsT0FBTyxrQkFBa0IsU0FBUyxVQUFVLEtBQUssU0FBUyxVQUFVLGtCQUNsRSxTQUFTLE9BQU8sS0FBSyxVQUN2QixLQUFLLGtCQUFrQixTQUFTLFdBQVcsVUFBVTtDQUN2RDtDQUNBLE9BQU8sT0FBTyxTQUFTLElBQUksSUFBSSxTQUFTLFFBQVE7QUFDbEQ7QUFDQSxTQUFTLGlCQUFpQixPQUFPO0NBQy9CLE9BQU8sV0FBVyxLQUFLLEtBQUssZUFBZTtBQUM3QztBQUVBLE1BQU0sWUFBWSxpQkFBaUIsaUJBQWlCO0NBQ2xELE1BQU0sSUFBSSxXQUFXLGlCQUFpQixjQUFjLHFCQUFxQjtDQUN6RSxJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDN0MsTUFBTSxJQUFJLG1CQUFtQjtFQUM3QixJQUFJLEtBQUssRUFBRSxXQUFXLE9BQU8sdUJBQXVCO0dBQ2xELEVBQUUsaUJBQWlCO0VBQ3JCO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFFQSxTQUFTLEVBQUUsTUFBTSxpQkFBaUIsVUFBVTtDQUMxQyxJQUFJO0VBQ0YsaUJBQWlCLENBQUMsQ0FBQztFQUNuQixNQUFNLElBQUksVUFBVTtFQUNwQixJQUFJLE1BQU0sR0FBRztHQUNYLElBQUksU0FBUyxlQUFlLEtBQUssQ0FBQyxRQUFRLGVBQWUsR0FBRztJQUMxRCxJQUFJLFFBQVEsZUFBZSxHQUFHO0tBQzVCLE9BQU8sWUFBWSxNQUFNLE1BQU0sQ0FBQyxlQUFlLENBQUM7SUFDbEQ7SUFDQSxPQUFPLFlBQVksTUFBTSxlQUFlO0dBQzFDLE9BQU87SUFDTCxPQUFPLFlBQVksTUFBTSxNQUFNLGVBQWU7R0FDaEQ7RUFDRixPQUFPO0dBQ0wsSUFBSSxJQUFJLEdBQUc7SUFDVCxXQUFXLE1BQU0sVUFBVSxNQUFNLEtBQUssV0FBVyxDQUFDO0dBQ3BELE9BQU8sSUFBSSxNQUFNLEtBQUssUUFBUSxRQUFRLEdBQUc7SUFDdkMsV0FBVyxDQUFDLFFBQVE7R0FDdEI7R0FDQSxPQUFPLFlBQVksTUFBTSxpQkFBaUIsUUFBUTtFQUNwRDtDQUNGLFVBQVU7RUFDUixpQkFBaUIsQ0FBQztDQUNwQjtBQUNGO0FBRUEsU0FBUyxzQkFBc0I7Q0FDN0IsSUFBSSxDQUFDLENBQUMsb0JBQTJCLGlCQUFpQixPQUFPLFdBQVcsYUFBYTtFQUMvRTtDQUNGO0NBQ0EsTUFBTSxXQUFXLEVBQUUsT0FBTyxnQkFBZ0I7Q0FDMUMsTUFBTSxjQUFjLEVBQUUsT0FBTyxnQkFBZ0I7Q0FDN0MsTUFBTSxjQUFjLEVBQUUsT0FBTyxnQkFBZ0I7Q0FDN0MsTUFBTSxlQUFlLEVBQUUsT0FBTyxnQkFBZ0I7Q0FDOUMsTUFBTSxZQUFZO0VBQ2hCLHdCQUF3QjtFQUN4QixPQUFPLEtBQUs7R0FDVixJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUc7SUFDbEIsT0FBTztHQUNUO0dBQ0EsSUFBSSxJQUFJLFNBQVM7SUFDZixPQUFPO0tBQUM7S0FBTztLQUFVO0lBQWE7R0FDeEMsT0FBTyxJQUFJLE1BQU0sR0FBRyxHQUFHO0lBQ3JCLGNBQWM7SUFDZCxNQUFNLFFBQVEsSUFBSTtJQUNsQixjQUFjO0lBQ2QsT0FBTztLQUNMO0tBQ0EsQ0FBQztLQUNEO01BQUM7TUFBUTtNQUFVLFdBQVcsR0FBRztLQUFDO0tBQ2xDO0tBQ0EsWUFBWSxLQUFLO0tBQ2pCO0lBQ0Y7R0FDRixPQUFPLElBQUksV0FBVyxHQUFHLEdBQUc7SUFDMUIsT0FBTztLQUNMO0tBQ0EsQ0FBQztLQUNEO01BQUM7TUFBUTtNQUFVLFVBQVUsR0FBRyxJQUFJLG9CQUFvQjtLQUFVO0tBQ2xFO0tBQ0EsWUFBWSxHQUFHO0tBQ2YsSUFBSSxXQUFXLEdBQUcsSUFBSSxnQkFBZ0I7SUFDeEM7R0FDRixPQUFPLElBQUksV0FBVyxHQUFHLEdBQUc7SUFDMUIsT0FBTztLQUNMO0tBQ0EsQ0FBQztLQUNEO01BQUM7TUFBUTtNQUFVLFVBQVUsR0FBRyxJQUFJLG9CQUFvQjtLQUFVO0tBQ2xFO0tBQ0EsWUFBWSxHQUFHO0tBQ2Y7SUFDRjtHQUNGO0dBQ0EsT0FBTztFQUNUO0VBQ0EsUUFBUSxLQUFLO0dBQ1gsT0FBTyxPQUFPLElBQUk7RUFDcEI7RUFDQSxLQUFLLEtBQUs7R0FDUixJQUFJLE9BQU8sSUFBSSxTQUFTO0lBQ3RCLE9BQU87S0FDTDtLQUNBLENBQUM7S0FDRCxHQUFHLGVBQWUsSUFBSSxDQUFDO0lBQ3pCO0dBQ0Y7RUFDRjtDQUNGO0NBQ0EsU0FBUyxlQUFlLFVBQVU7RUFDaEMsTUFBTSxTQUFTLENBQUM7RUFDaEIsSUFBSSxTQUFTLEtBQUssU0FBUyxTQUFTLE9BQU87R0FDekMsT0FBTyxLQUFLLG9CQUFvQixTQUFTLE1BQU0sU0FBUyxLQUFLLENBQUMsQ0FBQztFQUNqRTtFQUNBLElBQUksU0FBUyxlQUFlLFdBQVc7R0FDckMsT0FBTyxLQUFLLG9CQUFvQixTQUFTLFNBQVMsVUFBVSxDQUFDO0VBQy9EO0VBQ0EsSUFBSSxTQUFTLFNBQVMsV0FBVztHQUMvQixPQUFPLEtBQUssb0JBQW9CLFFBQVEsTUFBTSxTQUFTLElBQUksQ0FBQyxDQUFDO0VBQy9EO0VBQ0EsTUFBTSxXQUFXLFlBQVksVUFBVSxVQUFVO0VBQ2pELElBQUksVUFBVTtHQUNaLE9BQU8sS0FBSyxvQkFBb0IsWUFBWSxRQUFRLENBQUM7RUFDdkQ7RUFDQSxNQUFNLFdBQVcsWUFBWSxVQUFVLFFBQVE7RUFDL0MsSUFBSSxVQUFVO0dBQ1osT0FBTyxLQUFLLG9CQUFvQixZQUFZLFFBQVEsQ0FBQztFQUN2RDtFQUNBLE9BQU8sS0FBSztHQUNWO0dBQ0EsQ0FBQztHQUNEO0lBQ0U7SUFDQSxFQUNFLE9BQU8sYUFBYSxRQUFRLGdCQUM5QjtJQUNBO0dBQ0Y7R0FDQSxDQUFDLFVBQVUsRUFBRSxRQUFRLFNBQVMsQ0FBQztFQUNqQyxDQUFDO0VBQ0QsT0FBTztDQUNUO0NBQ0EsU0FBUyxvQkFBb0IsTUFBTSxRQUFRO0VBQ3pDLFNBQVMsT0FBTyxDQUFDLEdBQUcsTUFBTTtFQUMxQixJQUFJLENBQUMsT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLFFBQVE7R0FDL0IsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0VBQ3BCO0VBQ0EsT0FBTztHQUNMO0dBQ0EsRUFBRSxPQUFPLHlDQUF5QztHQUNsRDtJQUNFO0lBQ0EsRUFDRSxPQUFPLGdCQUNUO0lBQ0E7R0FDRjtHQUNBO0lBQ0U7SUFDQSxFQUNFLE9BQU8sc0JBQ1Q7SUFDQSxHQUFHLE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBQyxLQUFLLFFBQVE7S0FDbEMsT0FBTztNQUNMO01BQ0EsQ0FBQztNQUNEO09BQUM7T0FBUTtPQUFjLE1BQU07TUFBSTtNQUNqQyxZQUFZLE9BQU8sTUFBTSxLQUFLO0tBQ2hDO0lBQ0YsQ0FBQztHQUNIO0VBQ0Y7Q0FDRjtDQUNBLFNBQVMsWUFBWSxHQUFHLFFBQVEsTUFBTTtFQUNwQyxJQUFJLE9BQU8sTUFBTSxVQUFVO0dBQ3pCLE9BQU87SUFBQztJQUFRO0lBQWE7R0FBQztFQUNoQyxPQUFPLElBQUksT0FBTyxNQUFNLFVBQVU7R0FDaEMsT0FBTztJQUFDO0lBQVE7SUFBYSxLQUFLLFVBQVUsQ0FBQztHQUFDO0VBQ2hELE9BQU8sSUFBSSxPQUFPLE1BQU0sV0FBVztHQUNqQyxPQUFPO0lBQUM7SUFBUTtJQUFjO0dBQUM7RUFDakMsT0FBTyxJQUFJLFNBQVMsQ0FBQyxHQUFHO0dBQ3RCLE9BQU8sQ0FBQyxVQUFVLEVBQUUsUUFBUSxRQUFRLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztFQUNwRCxPQUFPO0dBQ0wsT0FBTztJQUFDO0lBQVE7SUFBYSxPQUFPLENBQUM7R0FBQztFQUN4QztDQUNGO0NBQ0EsU0FBUyxZQUFZLFVBQVUsTUFBTTtFQUNuQyxNQUFNLE9BQU8sU0FBUztFQUN0QixJQUFJLFdBQVcsSUFBSSxHQUFHO0dBQ3BCO0VBQ0Y7RUFDQSxNQUFNLFlBQVksQ0FBQztFQUNuQixLQUFLLE1BQU0sT0FBTyxTQUFTLEtBQUs7R0FDOUIsSUFBSSxZQUFZLE1BQU0sS0FBSyxJQUFJLEdBQUc7SUFDaEMsVUFBVSxPQUFPLFNBQVMsSUFBSTtHQUNoQztFQUNGO0VBQ0EsT0FBTztDQUNUO0NBQ0EsU0FBUyxZQUFZLE1BQU0sS0FBSyxNQUFNO0VBQ3BDLE1BQU0sT0FBTyxLQUFLO0VBQ2xCLElBQUksUUFBUSxJQUFJLEtBQUssS0FBSyxTQUFTLEdBQUcsS0FBSyxTQUFTLElBQUksS0FBSyxPQUFPLE1BQU07R0FDeEUsT0FBTztFQUNUO0VBQ0EsSUFBSSxLQUFLLFdBQVcsWUFBWSxLQUFLLFNBQVMsS0FBSyxJQUFJLEdBQUc7R0FDeEQsT0FBTztFQUNUO0VBQ0EsSUFBSSxLQUFLLFVBQVUsS0FBSyxPQUFPLE1BQU0sTUFBTSxZQUFZLEdBQUcsS0FBSyxJQUFJLENBQUMsR0FBRztHQUNyRSxPQUFPO0VBQ1Q7Q0FDRjtDQUNBLFNBQVMsV0FBVyxHQUFHO0VBQ3JCLElBQUksVUFBVSxDQUFDLEdBQUc7R0FDaEIsT0FBTztFQUNUO0VBQ0EsSUFBSSxFQUFFLFFBQVE7R0FDWixPQUFPO0VBQ1Q7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLE9BQU8sb0JBQW9CO0VBQzdCLE9BQU8sbUJBQW1CLEtBQUssU0FBUztDQUMxQyxPQUFPO0VBQ0wsT0FBTyxxQkFBcUIsQ0FBQyxTQUFTO0NBQ3hDO0FBQ0Y7QUFFQSxTQUFTLFNBQVMsTUFBTSxRQUFRLE9BQU8sT0FBTztDQUM1QyxNQUFNLFNBQVMsTUFBTTtDQUNyQixJQUFJLFVBQVUsV0FBVyxRQUFRLElBQUksR0FBRztFQUN0QyxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLE1BQU0sT0FBTztDQUNuQixJQUFJLE9BQU8sS0FBSyxNQUFNO0NBQ3RCLElBQUksYUFBYTtDQUNqQixPQUFPLE1BQU0sU0FBUztBQUN4QjtBQUNBLFNBQVMsV0FBVyxRQUFRLE1BQU07Q0FDaEMsTUFBTSxPQUFPLE9BQU87Q0FDcEIsSUFBSSxLQUFLLFVBQVUsS0FBSyxRQUFRO0VBQzlCLE9BQU87Q0FDVDtDQUNBLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsS0FBSztFQUNwQyxJQUFJLFdBQVcsS0FBSyxJQUFJLEtBQUssRUFBRSxHQUFHO0dBQ2hDLE9BQU87RUFDVDtDQUNGO0NBQ0EsSUFBSSxxQkFBcUIsS0FBSyxjQUFjO0VBQzFDLGFBQWEsS0FBSyxNQUFNO0NBQzFCO0NBQ0EsT0FBTztBQUNUO0FBRUEsTUFBTSxVQUFVO0FBQ2hCLE1BQU0sT0FBTyxDQUFDLG9CQUEyQixnQkFBZ0IsU0FBUztBQUNsRSxNQUFNLG1CQUFtQjtBQUN6QixNQUFNLFdBQVcsQ0FBQyxvQkFBMkIsaUJBQWlCLE9BQU8sYUFBYSxLQUFLO0FBQ3ZGLE1BQU0sa0JBQWtCLENBQUMsb0JBQTJCLGlCQUFpQixPQUFPLG9CQUFvQjtBQUNoRyxNQUFNLFlBQVk7Q0FDaEI7Q0FDQTtDQUNBO0NBQ0E7Q0FDUztDQUNUO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDRjtBQUNBLE1BQU0sV0FBVztBQUNqQixNQUFNLGdCQUFnQjtBQUN0QixNQUFNLGNBQWM7QUFDcEIsTUFBTSxtQkFBbUI7QUFFekIsU0FBUyxnQkFBZ0IsK0JBQStCLFNBQVMsa0JBQWtCLFlBQVksa0JBQWtCLFVBQVUsV0FBVyxRQUFRLFVBQVUsVUFBVSxNQUFNLGNBQWMsNEJBQTRCLHVCQUF1QixZQUFZLGFBQWEsVUFBVSxhQUFhLG9CQUFvQixvQkFBb0IsbUJBQW1CLG9CQUFvQix5QkFBeUIsc0JBQXNCLGdCQUFnQixhQUFhLG1CQUFtQixpQkFBaUIsYUFBYSxzQkFBc0IsaUJBQWlCLGFBQWEsY0FBYyxhQUFhLGVBQWUsYUFBYSxhQUFhLFVBQVUsb0JBQW9CLDBCQUEwQixvQkFBb0IsR0FBRyxhQUFhLHFCQUFxQixlQUFlLHNCQUFzQixxQkFBcUIsa0JBQWtCLHFCQUFxQixRQUFRLFlBQVksZUFBZSxTQUFTLGVBQWUsYUFBYSxZQUFZLFVBQVUsYUFBYSxlQUFlLGlCQUFpQixnQkFBZ0IsZUFBZSxpQkFBaUIsV0FBVyxpQkFBaUIsbUJBQW1CLGtCQUFrQixhQUFhLFdBQVcsV0FBVyxZQUFZLFNBQVMsYUFBYSxrQkFBa0IseUJBQXlCLFlBQVksWUFBWSxrQkFBa0Isa0JBQWtCLHlCQUF5QixlQUFlLHdCQUF3QixrQkFBa0IsaUJBQWlCLG9CQUFvQixlQUFlLFVBQVUsWUFBWSxvQkFBb0IsVUFBVSxPQUFPLFVBQVUsZUFBZSxVQUFVLGdCQUFnQixvQkFBb0IsU0FBUyxNQUFNLE9BQU8sYUFBYSxpQkFBaUIsaUJBQWlCLGtCQUFrQixTQUFTLGNBQWMsZ0JBQWdCLFVBQVUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsicnVudGltZS1jb3JlLmVzbS1idW5kbGVyLmpzP3Y9N2U3M2FmYzIiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXG4qIEB2dWUvcnVudGltZS1jb3JlIHYzLjUuNDBcbiogKGMpIDIwMTgtcHJlc2VudCBZdXhpIChFdmFuKSBZb3UgYW5kIFZ1ZSBjb250cmlidXRvcnNcbiogQGxpY2Vuc2UgTUlUXG4qKi9cbmltcG9ydCB7IHBhdXNlVHJhY2tpbmcsIHJlc2V0VHJhY2tpbmcsIGlzUmVmLCB0b1JhdywgdHJhdmVyc2UsIHdhdGNoIGFzIHdhdGNoJDEsIHNoYWxsb3dSZWYsIHJlYWRvbmx5LCBpc1JlYWN0aXZlLCByZWYsIGlzU2hhbGxvdywgaXNSZWFkb25seSwgc2hhbGxvd1JlYWRBcnJheSwgdG9SZWFkb25seSwgdG9SZWFjdGl2ZSwgc2hhbGxvd1JlYWRvbmx5LCB0cmFjaywgcmVhY3RpdmUsIGN1c3RvbVJlZiwgc2hhbGxvd1JlYWN0aXZlLCB0cmlnZ2VyLCBSZWFjdGl2ZUVmZmVjdCwgaXNQcm94eSwgcHJveHlSZWZzLCBtYXJrUmF3LCBFZmZlY3RTY29wZSwgY29tcHV0ZWQgYXMgY29tcHV0ZWQkMSB9IGZyb20gJ0B2dWUvcmVhY3Rpdml0eSc7XG5leHBvcnQgeyBFZmZlY3RTY29wZSwgUmVhY3RpdmVFZmZlY3QsIFRyYWNrT3BUeXBlcywgVHJpZ2dlck9wVHlwZXMsIGN1c3RvbVJlZiwgZWZmZWN0LCBlZmZlY3RTY29wZSwgZ2V0Q3VycmVudFNjb3BlLCBnZXRDdXJyZW50V2F0Y2hlciwgaXNQcm94eSwgaXNSZWFjdGl2ZSwgaXNSZWFkb25seSwgaXNSZWYsIGlzU2hhbGxvdywgbWFya1Jhdywgb25TY29wZURpc3Bvc2UsIG9uV2F0Y2hlckNsZWFudXAsIHByb3h5UmVmcywgcmVhY3RpdmUsIHJlYWRvbmx5LCByZWYsIHNoYWxsb3dSZWFjdGl2ZSwgc2hhbGxvd1JlYWRvbmx5LCBzaGFsbG93UmVmLCBzdG9wLCB0b1JhdywgdG9SZWYsIHRvUmVmcywgdG9WYWx1ZSwgdHJpZ2dlclJlZiwgdW5yZWYgfSBmcm9tICdAdnVlL3JlYWN0aXZpdHknO1xuaW1wb3J0IHsgaXNTdHJpbmcsIGlzRnVuY3Rpb24sIEVNUFRZX09CSiwgaXNQcm9taXNlLCBpc0FycmF5LCBOT09QLCBnZXRHbG9iYWxUaGlzLCBleHRlbmQsIGlzQnVpbHRJbkRpcmVjdGl2ZSwgTk8sIGhhc093biwgcmVtb3ZlLCBkZWYsIGlzT24sIGlzUmVzZXJ2ZWRQcm9wLCBub3JtYWxpemVDbGFzcywgc3RyaW5naWZ5U3R5bGUsIG5vcm1hbGl6ZVN0eWxlLCBpc0tub3duU3ZnQXR0ciwgaXNCb29sZWFuQXR0ciwgaXNLbm93bkh0bWxBdHRyLCBpbmNsdWRlQm9vbGVhbkF0dHIsIGlzUmVuZGVyYWJsZUF0dHJWYWx1ZSwgbm9ybWFsaXplQ3NzVmFyVmFsdWUsIGdldEVzY2FwZWRDc3NWYXJOYW1lLCBpc09iamVjdCwgaXNSZWdFeHAsIGludm9rZUFycmF5Rm5zLCB0b0hhbmRsZXJLZXksIGNhbWVsaXplLCBjYXBpdGFsaXplLCBpc1N5bWJvbCwgaXNHbG9iYWxseUFsbG93ZWQsIGh5cGhlbmF0ZSwgaGFzQ2hhbmdlZCwgbG9vc2VUb051bWJlciwgaXNNb2RlbExpc3RlbmVyLCBsb29zZUVxdWFsLCBFTVBUWV9BUlIsIHRvUmF3VHlwZSwgbWFrZU1hcCwgdG9OdW1iZXIgfSBmcm9tICdAdnVlL3NoYXJlZCc7XG5leHBvcnQgeyBjYW1lbGl6ZSwgY2FwaXRhbGl6ZSwgbm9ybWFsaXplQ2xhc3MsIG5vcm1hbGl6ZVByb3BzLCBub3JtYWxpemVTdHlsZSwgdG9EaXNwbGF5U3RyaW5nLCB0b0hhbmRsZXJLZXkgfSBmcm9tICdAdnVlL3NoYXJlZCc7XG5cbmNvbnN0IHN0YWNrID0gW107XG5mdW5jdGlvbiBwdXNoV2FybmluZ0NvbnRleHQodm5vZGUpIHtcbiAgc3RhY2sucHVzaCh2bm9kZSk7XG59XG5mdW5jdGlvbiBwb3BXYXJuaW5nQ29udGV4dCgpIHtcbiAgc3RhY2sucG9wKCk7XG59XG5sZXQgaXNXYXJuaW5nID0gZmFsc2U7XG5mdW5jdGlvbiB3YXJuJDEobXNnLCAuLi5hcmdzKSB7XG4gIGlmIChpc1dhcm5pbmcpIHJldHVybjtcbiAgaXNXYXJuaW5nID0gdHJ1ZTtcbiAgcGF1c2VUcmFja2luZygpO1xuICBjb25zdCBpbnN0YW5jZSA9IHN0YWNrLmxlbmd0aCA/IHN0YWNrW3N0YWNrLmxlbmd0aCAtIDFdLmNvbXBvbmVudCA6IG51bGw7XG4gIGNvbnN0IGFwcFdhcm5IYW5kbGVyID0gaW5zdGFuY2UgJiYgaW5zdGFuY2UuYXBwQ29udGV4dC5jb25maWcud2FybkhhbmRsZXI7XG4gIGNvbnN0IHRyYWNlID0gZ2V0Q29tcG9uZW50VHJhY2UoKTtcbiAgaWYgKGFwcFdhcm5IYW5kbGVyKSB7XG4gICAgY2FsbFdpdGhFcnJvckhhbmRsaW5nKFxuICAgICAgYXBwV2FybkhhbmRsZXIsXG4gICAgICBpbnN0YW5jZSxcbiAgICAgIDExLFxuICAgICAgW1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcmVzdHJpY3RlZC1zeW50YXhcbiAgICAgICAgbXNnICsgYXJncy5tYXAoKGEpID0+IHtcbiAgICAgICAgICB2YXIgX2EsIF9iO1xuICAgICAgICAgIHJldHVybiAoX2IgPSAoX2EgPSBhLnRvU3RyaW5nKSA9PSBudWxsID8gdm9pZCAwIDogX2EuY2FsbChhKSkgIT0gbnVsbCA/IF9iIDogSlNPTi5zdHJpbmdpZnkoYSk7XG4gICAgICAgIH0pLmpvaW4oXCJcIiksXG4gICAgICAgIGluc3RhbmNlICYmIGluc3RhbmNlLnByb3h5LFxuICAgICAgICB0cmFjZS5tYXAoXG4gICAgICAgICAgKHsgdm5vZGUgfSkgPT4gYGF0IDwke2Zvcm1hdENvbXBvbmVudE5hbWUoaW5zdGFuY2UsIHZub2RlLnR5cGUpfT5gXG4gICAgICAgICkuam9pbihcIlxcblwiKSxcbiAgICAgICAgdHJhY2VcbiAgICAgIF1cbiAgICApO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IHdhcm5BcmdzID0gW2BbVnVlIHdhcm5dOiAke21zZ31gLCAuLi5hcmdzXTtcbiAgICBpZiAodHJhY2UubGVuZ3RoICYmIC8vIGF2b2lkIHNwYW1taW5nIGNvbnNvbGUgZHVyaW5nIHRlc3RzXG4gICAgdHJ1ZSkge1xuICAgICAgd2FybkFyZ3MucHVzaChgXG5gLCAuLi5mb3JtYXRUcmFjZSh0cmFjZSkpO1xuICAgIH1cbiAgICBjb25zb2xlLndhcm4oLi4ud2FybkFyZ3MpO1xuICB9XG4gIHJlc2V0VHJhY2tpbmcoKTtcbiAgaXNXYXJuaW5nID0gZmFsc2U7XG59XG5mdW5jdGlvbiBnZXRDb21wb25lbnRUcmFjZSgpIHtcbiAgbGV0IGN1cnJlbnRWTm9kZSA9IHN0YWNrW3N0YWNrLmxlbmd0aCAtIDFdO1xuICBpZiAoIWN1cnJlbnRWTm9kZSkge1xuICAgIHJldHVybiBbXTtcbiAgfVxuICBjb25zdCBub3JtYWxpemVkU3RhY2sgPSBbXTtcbiAgd2hpbGUgKGN1cnJlbnRWTm9kZSkge1xuICAgIGNvbnN0IGxhc3QgPSBub3JtYWxpemVkU3RhY2tbMF07XG4gICAgaWYgKGxhc3QgJiYgbGFzdC52bm9kZSA9PT0gY3VycmVudFZOb2RlKSB7XG4gICAgICBsYXN0LnJlY3Vyc2VDb3VudCsrO1xuICAgIH0gZWxzZSB7XG4gICAgICBub3JtYWxpemVkU3RhY2sucHVzaCh7XG4gICAgICAgIHZub2RlOiBjdXJyZW50Vk5vZGUsXG4gICAgICAgIHJlY3Vyc2VDb3VudDogMFxuICAgICAgfSk7XG4gICAgfVxuICAgIGNvbnN0IHBhcmVudEluc3RhbmNlID0gY3VycmVudFZOb2RlLmNvbXBvbmVudCAmJiBjdXJyZW50Vk5vZGUuY29tcG9uZW50LnBhcmVudDtcbiAgICBjdXJyZW50Vk5vZGUgPSBwYXJlbnRJbnN0YW5jZSAmJiBwYXJlbnRJbnN0YW5jZS52bm9kZTtcbiAgfVxuICByZXR1cm4gbm9ybWFsaXplZFN0YWNrO1xufVxuZnVuY3Rpb24gZm9ybWF0VHJhY2UodHJhY2UpIHtcbiAgY29uc3QgbG9ncyA9IFtdO1xuICB0cmFjZS5mb3JFYWNoKChlbnRyeSwgaSkgPT4ge1xuICAgIGxvZ3MucHVzaCguLi5pID09PSAwID8gW10gOiBbYFxuYF0sIC4uLmZvcm1hdFRyYWNlRW50cnkoZW50cnkpKTtcbiAgfSk7XG4gIHJldHVybiBsb2dzO1xufVxuZnVuY3Rpb24gZm9ybWF0VHJhY2VFbnRyeSh7IHZub2RlLCByZWN1cnNlQ291bnQgfSkge1xuICBjb25zdCBwb3N0Zml4ID0gcmVjdXJzZUNvdW50ID4gMCA/IGAuLi4gKCR7cmVjdXJzZUNvdW50fSByZWN1cnNpdmUgY2FsbHMpYCA6IGBgO1xuICBjb25zdCBpc1Jvb3QgPSB2bm9kZS5jb21wb25lbnQgPyB2bm9kZS5jb21wb25lbnQucGFyZW50ID09IG51bGwgOiBmYWxzZTtcbiAgY29uc3Qgb3BlbiA9IGAgYXQgPCR7Zm9ybWF0Q29tcG9uZW50TmFtZShcbiAgICB2bm9kZS5jb21wb25lbnQsXG4gICAgdm5vZGUudHlwZSxcbiAgICBpc1Jvb3RcbiAgKX1gO1xuICBjb25zdCBjbG9zZSA9IGA+YCArIHBvc3RmaXg7XG4gIHJldHVybiB2bm9kZS5wcm9wcyA/IFtvcGVuLCAuLi5mb3JtYXRQcm9wcyh2bm9kZS5wcm9wcyksIGNsb3NlXSA6IFtvcGVuICsgY2xvc2VdO1xufVxuZnVuY3Rpb24gZm9ybWF0UHJvcHMocHJvcHMpIHtcbiAgY29uc3QgcmVzID0gW107XG4gIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhwcm9wcyk7XG4gIGtleXMuc2xpY2UoMCwgMykuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgcmVzLnB1c2goLi4uZm9ybWF0UHJvcChrZXksIHByb3BzW2tleV0pKTtcbiAgfSk7XG4gIGlmIChrZXlzLmxlbmd0aCA+IDMpIHtcbiAgICByZXMucHVzaChgIC4uLmApO1xuICB9XG4gIHJldHVybiByZXM7XG59XG5mdW5jdGlvbiBmb3JtYXRQcm9wKGtleSwgdmFsdWUsIHJhdykge1xuICBpZiAoaXNTdHJpbmcodmFsdWUpKSB7XG4gICAgdmFsdWUgPSBKU09OLnN0cmluZ2lmeSh2YWx1ZSk7XG4gICAgcmV0dXJuIHJhdyA/IHZhbHVlIDogW2Ake2tleX09JHt2YWx1ZX1gXTtcbiAgfSBlbHNlIGlmICh0eXBlb2YgdmFsdWUgPT09IFwibnVtYmVyXCIgfHwgdHlwZW9mIHZhbHVlID09PSBcImJvb2xlYW5cIiB8fCB2YWx1ZSA9PSBudWxsKSB7XG4gICAgcmV0dXJuIHJhdyA/IHZhbHVlIDogW2Ake2tleX09JHt2YWx1ZX1gXTtcbiAgfSBlbHNlIGlmIChpc1JlZih2YWx1ZSkpIHtcbiAgICB2YWx1ZSA9IGZvcm1hdFByb3Aoa2V5LCB0b1Jhdyh2YWx1ZS52YWx1ZSksIHRydWUpO1xuICAgIHJldHVybiByYXcgPyB2YWx1ZSA6IFtgJHtrZXl9PVJlZjxgLCB2YWx1ZSwgYD5gXTtcbiAgfSBlbHNlIGlmIChpc0Z1bmN0aW9uKHZhbHVlKSkge1xuICAgIHJldHVybiBbYCR7a2V5fT1mbiR7dmFsdWUubmFtZSA/IGA8JHt2YWx1ZS5uYW1lfT5gIDogYGB9YF07XG4gIH0gZWxzZSB7XG4gICAgdmFsdWUgPSB0b1Jhdyh2YWx1ZSk7XG4gICAgcmV0dXJuIHJhdyA/IHZhbHVlIDogW2Ake2tleX09YCwgdmFsdWVdO1xuICB9XG59XG5mdW5jdGlvbiBhc3NlcnROdW1iZXIodmFsLCB0eXBlKSB7XG4gIGlmICghISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkgcmV0dXJuO1xuICBpZiAodmFsID09PSB2b2lkIDApIHtcbiAgICByZXR1cm47XG4gIH0gZWxzZSBpZiAodHlwZW9mIHZhbCAhPT0gXCJudW1iZXJcIikge1xuICAgIHdhcm4kMShgJHt0eXBlfSBpcyBub3QgYSB2YWxpZCBudW1iZXIgLSBnb3QgJHtKU09OLnN0cmluZ2lmeSh2YWwpfS5gKTtcbiAgfSBlbHNlIGlmIChpc05hTih2YWwpKSB7XG4gICAgd2FybiQxKGAke3R5cGV9IGlzIE5hTiAtIHRoZSBkdXJhdGlvbiBleHByZXNzaW9uIG1pZ2h0IGJlIGluY29ycmVjdC5gKTtcbiAgfVxufVxuXG5jb25zdCBFcnJvckNvZGVzID0ge1xuICBcIlNFVFVQX0ZVTkNUSU9OXCI6IDAsXG4gIFwiMFwiOiBcIlNFVFVQX0ZVTkNUSU9OXCIsXG4gIFwiUkVOREVSX0ZVTkNUSU9OXCI6IDEsXG4gIFwiMVwiOiBcIlJFTkRFUl9GVU5DVElPTlwiLFxuICBcIk5BVElWRV9FVkVOVF9IQU5ETEVSXCI6IDUsXG4gIFwiNVwiOiBcIk5BVElWRV9FVkVOVF9IQU5ETEVSXCIsXG4gIFwiQ09NUE9ORU5UX0VWRU5UX0hBTkRMRVJcIjogNixcbiAgXCI2XCI6IFwiQ09NUE9ORU5UX0VWRU5UX0hBTkRMRVJcIixcbiAgXCJWTk9ERV9IT09LXCI6IDcsXG4gIFwiN1wiOiBcIlZOT0RFX0hPT0tcIixcbiAgXCJESVJFQ1RJVkVfSE9PS1wiOiA4LFxuICBcIjhcIjogXCJESVJFQ1RJVkVfSE9PS1wiLFxuICBcIlRSQU5TSVRJT05fSE9PS1wiOiA5LFxuICBcIjlcIjogXCJUUkFOU0lUSU9OX0hPT0tcIixcbiAgXCJBUFBfRVJST1JfSEFORExFUlwiOiAxMCxcbiAgXCIxMFwiOiBcIkFQUF9FUlJPUl9IQU5ETEVSXCIsXG4gIFwiQVBQX1dBUk5fSEFORExFUlwiOiAxMSxcbiAgXCIxMVwiOiBcIkFQUF9XQVJOX0hBTkRMRVJcIixcbiAgXCJGVU5DVElPTl9SRUZcIjogMTIsXG4gIFwiMTJcIjogXCJGVU5DVElPTl9SRUZcIixcbiAgXCJBU1lOQ19DT01QT05FTlRfTE9BREVSXCI6IDEzLFxuICBcIjEzXCI6IFwiQVNZTkNfQ09NUE9ORU5UX0xPQURFUlwiLFxuICBcIlNDSEVEVUxFUlwiOiAxNCxcbiAgXCIxNFwiOiBcIlNDSEVEVUxFUlwiLFxuICBcIkNPTVBPTkVOVF9VUERBVEVcIjogMTUsXG4gIFwiMTVcIjogXCJDT01QT05FTlRfVVBEQVRFXCIsXG4gIFwiQVBQX1VOTU9VTlRfQ0xFQU5VUFwiOiAxNixcbiAgXCIxNlwiOiBcIkFQUF9VTk1PVU5UX0NMRUFOVVBcIlxufTtcbmNvbnN0IEVycm9yVHlwZVN0cmluZ3MkMSA9IHtcbiAgW1wic3BcIl06IFwic2VydmVyUHJlZmV0Y2ggaG9va1wiLFxuICBbXCJiY1wiXTogXCJiZWZvcmVDcmVhdGUgaG9va1wiLFxuICBbXCJjXCJdOiBcImNyZWF0ZWQgaG9va1wiLFxuICBbXCJibVwiXTogXCJiZWZvcmVNb3VudCBob29rXCIsXG4gIFtcIm1cIl06IFwibW91bnRlZCBob29rXCIsXG4gIFtcImJ1XCJdOiBcImJlZm9yZVVwZGF0ZSBob29rXCIsXG4gIFtcInVcIl06IFwidXBkYXRlZFwiLFxuICBbXCJidW1cIl06IFwiYmVmb3JlVW5tb3VudCBob29rXCIsXG4gIFtcInVtXCJdOiBcInVubW91bnRlZCBob29rXCIsXG4gIFtcImFcIl06IFwiYWN0aXZhdGVkIGhvb2tcIixcbiAgW1wiZGFcIl06IFwiZGVhY3RpdmF0ZWQgaG9va1wiLFxuICBbXCJlY1wiXTogXCJlcnJvckNhcHR1cmVkIGhvb2tcIixcbiAgW1wicnRjXCJdOiBcInJlbmRlclRyYWNrZWQgaG9va1wiLFxuICBbXCJydGdcIl06IFwicmVuZGVyVHJpZ2dlcmVkIGhvb2tcIixcbiAgWzBdOiBcInNldHVwIGZ1bmN0aW9uXCIsXG4gIFsxXTogXCJyZW5kZXIgZnVuY3Rpb25cIixcbiAgWzJdOiBcIndhdGNoZXIgZ2V0dGVyXCIsXG4gIFszXTogXCJ3YXRjaGVyIGNhbGxiYWNrXCIsXG4gIFs0XTogXCJ3YXRjaGVyIGNsZWFudXAgZnVuY3Rpb25cIixcbiAgWzVdOiBcIm5hdGl2ZSBldmVudCBoYW5kbGVyXCIsXG4gIFs2XTogXCJjb21wb25lbnQgZXZlbnQgaGFuZGxlclwiLFxuICBbN106IFwidm5vZGUgaG9va1wiLFxuICBbOF06IFwiZGlyZWN0aXZlIGhvb2tcIixcbiAgWzldOiBcInRyYW5zaXRpb24gaG9va1wiLFxuICBbMTBdOiBcImFwcCBlcnJvckhhbmRsZXJcIixcbiAgWzExXTogXCJhcHAgd2FybkhhbmRsZXJcIixcbiAgWzEyXTogXCJyZWYgZnVuY3Rpb25cIixcbiAgWzEzXTogXCJhc3luYyBjb21wb25lbnQgbG9hZGVyXCIsXG4gIFsxNF06IFwic2NoZWR1bGVyIGZsdXNoXCIsXG4gIFsxNV06IFwiY29tcG9uZW50IHVwZGF0ZVwiLFxuICBbMTZdOiBcImFwcCB1bm1vdW50IGNsZWFudXAgZnVuY3Rpb25cIlxufTtcbmZ1bmN0aW9uIGNhbGxXaXRoRXJyb3JIYW5kbGluZyhmbiwgaW5zdGFuY2UsIHR5cGUsIGFyZ3MpIHtcbiAgdHJ5IHtcbiAgICByZXR1cm4gYXJncyA/IGZuKC4uLmFyZ3MpIDogZm4oKTtcbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgaGFuZGxlRXJyb3IoZXJyLCBpbnN0YW5jZSwgdHlwZSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGNhbGxXaXRoQXN5bmNFcnJvckhhbmRsaW5nKGZuLCBpbnN0YW5jZSwgdHlwZSwgYXJncykge1xuICBpZiAoaXNGdW5jdGlvbihmbikpIHtcbiAgICBjb25zdCByZXMgPSBjYWxsV2l0aEVycm9ySGFuZGxpbmcoZm4sIGluc3RhbmNlLCB0eXBlLCBhcmdzKTtcbiAgICBpZiAocmVzICYmIGlzUHJvbWlzZShyZXMpKSB7XG4gICAgICByZXMuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICBoYW5kbGVFcnJvcihlcnIsIGluc3RhbmNlLCB0eXBlKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gcmVzO1xuICB9XG4gIGlmIChpc0FycmF5KGZuKSkge1xuICAgIGNvbnN0IHZhbHVlcyA9IFtdO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZm4ubGVuZ3RoOyBpKyspIHtcbiAgICAgIHZhbHVlcy5wdXNoKGNhbGxXaXRoQXN5bmNFcnJvckhhbmRsaW5nKGZuW2ldLCBpbnN0YW5jZSwgdHlwZSwgYXJncykpO1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWVzO1xuICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICB3YXJuJDEoXG4gICAgICBgSW52YWxpZCB2YWx1ZSB0eXBlIHBhc3NlZCB0byBjYWxsV2l0aEFzeW5jRXJyb3JIYW5kbGluZygpOiAke3R5cGVvZiBmbn1gXG4gICAgKTtcbiAgfVxufVxuZnVuY3Rpb24gaGFuZGxlRXJyb3IoZXJyLCBpbnN0YW5jZSwgdHlwZSwgdGhyb3dJbkRldiA9IHRydWUpIHtcbiAgY29uc3QgY29udGV4dFZOb2RlID0gaW5zdGFuY2UgPyBpbnN0YW5jZS52bm9kZSA6IG51bGw7XG4gIGNvbnN0IHsgZXJyb3JIYW5kbGVyLCB0aHJvd1VuaGFuZGxlZEVycm9ySW5Qcm9kdWN0aW9uIH0gPSBpbnN0YW5jZSAmJiBpbnN0YW5jZS5hcHBDb250ZXh0LmNvbmZpZyB8fCBFTVBUWV9PQko7XG4gIGlmIChpbnN0YW5jZSkge1xuICAgIGxldCBjdXIgPSBpbnN0YW5jZS5wYXJlbnQ7XG4gICAgY29uc3QgZXhwb3NlZEluc3RhbmNlID0gaW5zdGFuY2UucHJveHk7XG4gICAgY29uc3QgZXJyb3JJbmZvID0gISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IEVycm9yVHlwZVN0cmluZ3MkMVt0eXBlXSA6IGBodHRwczovL3Z1ZWpzLm9yZy9lcnJvci1yZWZlcmVuY2UvI3J1bnRpbWUtJHt0eXBlfWA7XG4gICAgd2hpbGUgKGN1cikge1xuICAgICAgY29uc3QgZXJyb3JDYXB0dXJlZEhvb2tzID0gY3VyLmVjO1xuICAgICAgaWYgKGVycm9yQ2FwdHVyZWRIb29rcykge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGVycm9yQ2FwdHVyZWRIb29rcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIGlmIChlcnJvckNhcHR1cmVkSG9va3NbaV0oZXJyLCBleHBvc2VkSW5zdGFuY2UsIGVycm9ySW5mbykgPT09IGZhbHNlKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBjdXIgPSBjdXIucGFyZW50O1xuICAgIH1cbiAgICBpZiAoZXJyb3JIYW5kbGVyKSB7XG4gICAgICBwYXVzZVRyYWNraW5nKCk7XG4gICAgICBjYWxsV2l0aEVycm9ySGFuZGxpbmcoZXJyb3JIYW5kbGVyLCBudWxsLCAxMCwgW1xuICAgICAgICBlcnIsXG4gICAgICAgIGV4cG9zZWRJbnN0YW5jZSxcbiAgICAgICAgZXJyb3JJbmZvXG4gICAgICBdKTtcbiAgICAgIHJlc2V0VHJhY2tpbmcoKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gIH1cbiAgbG9nRXJyb3IoZXJyLCB0eXBlLCBjb250ZXh0Vk5vZGUsIHRocm93SW5EZXYsIHRocm93VW5oYW5kbGVkRXJyb3JJblByb2R1Y3Rpb24pO1xufVxuZnVuY3Rpb24gbG9nRXJyb3IoZXJyLCB0eXBlLCBjb250ZXh0Vk5vZGUsIHRocm93SW5EZXYgPSB0cnVlLCB0aHJvd0luUHJvZCA9IGZhbHNlKSB7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgY29uc3QgaW5mbyA9IEVycm9yVHlwZVN0cmluZ3MkMVt0eXBlXTtcbiAgICBpZiAoY29udGV4dFZOb2RlKSB7XG4gICAgICBwdXNoV2FybmluZ0NvbnRleHQoY29udGV4dFZOb2RlKTtcbiAgICB9XG4gICAgd2FybiQxKGBVbmhhbmRsZWQgZXJyb3Ike2luZm8gPyBgIGR1cmluZyBleGVjdXRpb24gb2YgJHtpbmZvfWAgOiBgYH1gKTtcbiAgICBpZiAoY29udGV4dFZOb2RlKSB7XG4gICAgICBwb3BXYXJuaW5nQ29udGV4dCgpO1xuICAgIH1cbiAgICBpZiAodGhyb3dJbkRldikge1xuICAgICAgdGhyb3cgZXJyO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zb2xlLmVycm9yKGVycik7XG4gICAgfVxuICB9IGVsc2UgaWYgKHRocm93SW5Qcm9kKSB7XG4gICAgdGhyb3cgZXJyO1xuICB9IGVsc2Uge1xuICAgIGNvbnNvbGUuZXJyb3IoZXJyKTtcbiAgfVxufVxuXG5jb25zdCBxdWV1ZSA9IFtdO1xubGV0IGZsdXNoSW5kZXggPSAtMTtcbmNvbnN0IHBlbmRpbmdQb3N0Rmx1c2hDYnMgPSBbXTtcbmxldCBhY3RpdmVQb3N0Rmx1c2hDYnMgPSBudWxsO1xubGV0IHBvc3RGbHVzaEluZGV4ID0gMDtcbmNvbnN0IHJlc29sdmVkUHJvbWlzZSA9IC8qIEBfX1BVUkVfXyAqLyBQcm9taXNlLnJlc29sdmUoKTtcbmxldCBjdXJyZW50Rmx1c2hQcm9taXNlID0gbnVsbDtcbmNvbnN0IFJFQ1VSU0lPTl9MSU1JVCA9IDEwMDtcbmZ1bmN0aW9uIG5leHRUaWNrKGZuKSB7XG4gIGNvbnN0IHAgPSBjdXJyZW50Rmx1c2hQcm9taXNlIHx8IHJlc29sdmVkUHJvbWlzZTtcbiAgcmV0dXJuIGZuID8gcC50aGVuKHRoaXMgPyBmbi5iaW5kKHRoaXMpIDogZm4pIDogcDtcbn1cbmZ1bmN0aW9uIGZpbmRJbnNlcnRpb25JbmRleChpZCkge1xuICBsZXQgc3RhcnQgPSBmbHVzaEluZGV4ICsgMTtcbiAgbGV0IGVuZCA9IHF1ZXVlLmxlbmd0aDtcbiAgd2hpbGUgKHN0YXJ0IDwgZW5kKSB7XG4gICAgY29uc3QgbWlkZGxlID0gc3RhcnQgKyBlbmQgPj4+IDE7XG4gICAgY29uc3QgbWlkZGxlSm9iID0gcXVldWVbbWlkZGxlXTtcbiAgICBjb25zdCBtaWRkbGVKb2JJZCA9IGdldElkKG1pZGRsZUpvYik7XG4gICAgaWYgKG1pZGRsZUpvYklkIDwgaWQgfHwgbWlkZGxlSm9iSWQgPT09IGlkICYmIG1pZGRsZUpvYi5mbGFncyAmIDIpIHtcbiAgICAgIHN0YXJ0ID0gbWlkZGxlICsgMTtcbiAgICB9IGVsc2Uge1xuICAgICAgZW5kID0gbWlkZGxlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gc3RhcnQ7XG59XG5mdW5jdGlvbiBxdWV1ZUpvYihqb2IpIHtcbiAgaWYgKCEoam9iLmZsYWdzICYgMSkpIHtcbiAgICBjb25zdCBqb2JJZCA9IGdldElkKGpvYik7XG4gICAgY29uc3QgbGFzdEpvYiA9IHF1ZXVlW3F1ZXVlLmxlbmd0aCAtIDFdO1xuICAgIGlmICghbGFzdEpvYiB8fCAvLyBmYXN0IHBhdGggd2hlbiB0aGUgam9iIGlkIGlzIGxhcmdlciB0aGFuIHRoZSB0YWlsXG4gICAgIShqb2IuZmxhZ3MgJiAyKSAmJiBqb2JJZCA+PSBnZXRJZChsYXN0Sm9iKSkge1xuICAgICAgcXVldWUucHVzaChqb2IpO1xuICAgIH0gZWxzZSB7XG4gICAgICBxdWV1ZS5zcGxpY2UoZmluZEluc2VydGlvbkluZGV4KGpvYklkKSwgMCwgam9iKTtcbiAgICB9XG4gICAgam9iLmZsYWdzIHw9IDE7XG4gICAgcXVldWVGbHVzaCgpO1xuICB9XG59XG5mdW5jdGlvbiBxdWV1ZUZsdXNoKCkge1xuICBpZiAoIWN1cnJlbnRGbHVzaFByb21pc2UpIHtcbiAgICBjdXJyZW50Rmx1c2hQcm9taXNlID0gcmVzb2x2ZWRQcm9taXNlLnRoZW4oZmx1c2hKb2JzKTtcbiAgfVxufVxuZnVuY3Rpb24gcXVldWVQb3N0Rmx1c2hDYihjYikge1xuICBpZiAoIWlzQXJyYXkoY2IpKSB7XG4gICAgaWYgKGFjdGl2ZVBvc3RGbHVzaENicyAmJiBjYi5pZCA9PT0gLTEpIHtcbiAgICAgIGFjdGl2ZVBvc3RGbHVzaENicy5zcGxpY2UocG9zdEZsdXNoSW5kZXggKyAxLCAwLCBjYik7XG4gICAgfSBlbHNlIGlmICghKGNiLmZsYWdzICYgMSkpIHtcbiAgICAgIHBlbmRpbmdQb3N0Rmx1c2hDYnMucHVzaChjYik7XG4gICAgICBjYi5mbGFncyB8PSAxO1xuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBwZW5kaW5nUG9zdEZsdXNoQ2JzLnB1c2goLi4uY2IpO1xuICB9XG4gIHF1ZXVlRmx1c2goKTtcbn1cbmZ1bmN0aW9uIGZsdXNoUHJlRmx1c2hDYnMoaW5zdGFuY2UsIHNlZW4sIGkgPSBmbHVzaEluZGV4ICsgMSkge1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIHNlZW4gPSBzZWVuIHx8IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gIH1cbiAgZm9yICg7IGkgPCBxdWV1ZS5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGNiID0gcXVldWVbaV07XG4gICAgaWYgKGNiICYmIGNiLmZsYWdzICYgMikge1xuICAgICAgaWYgKGluc3RhbmNlICYmIGNiLmlkICE9PSBpbnN0YW5jZS51aWQpIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBjaGVja1JlY3Vyc2l2ZVVwZGF0ZXMoc2VlbiwgY2IpKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgcXVldWUuc3BsaWNlKGksIDEpO1xuICAgICAgaS0tO1xuICAgICAgaWYgKGNiLmZsYWdzICYgNCkge1xuICAgICAgICBjYi5mbGFncyAmPSAtMjtcbiAgICAgIH1cbiAgICAgIGNiKCk7XG4gICAgICBpZiAoIShjYi5mbGFncyAmIDQpKSB7XG4gICAgICAgIGNiLmZsYWdzICY9IC0yO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gZmx1c2hQb3N0Rmx1c2hDYnMoc2Vlbikge1xuICBpZiAocGVuZGluZ1Bvc3RGbHVzaENicy5sZW5ndGgpIHtcbiAgICBjb25zdCBkZWR1cGVkID0gWy4uLm5ldyBTZXQocGVuZGluZ1Bvc3RGbHVzaENicyldLnNvcnQoXG4gICAgICAoYSwgYikgPT4gZ2V0SWQoYSkgLSBnZXRJZChiKVxuICAgICk7XG4gICAgcGVuZGluZ1Bvc3RGbHVzaENicy5sZW5ndGggPSAwO1xuICAgIGlmIChhY3RpdmVQb3N0Rmx1c2hDYnMpIHtcbiAgICAgIGFjdGl2ZVBvc3RGbHVzaENicy5wdXNoKC4uLmRlZHVwZWQpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBhY3RpdmVQb3N0Rmx1c2hDYnMgPSBkZWR1cGVkO1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICBzZWVuID0gc2VlbiB8fCAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICAgIH1cbiAgICBmb3IgKHBvc3RGbHVzaEluZGV4ID0gMDsgcG9zdEZsdXNoSW5kZXggPCBhY3RpdmVQb3N0Rmx1c2hDYnMubGVuZ3RoOyBwb3N0Rmx1c2hJbmRleCsrKSB7XG4gICAgICBjb25zdCBjYiA9IGFjdGl2ZVBvc3RGbHVzaENic1twb3N0Rmx1c2hJbmRleF07XG4gICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBjaGVja1JlY3Vyc2l2ZVVwZGF0ZXMoc2VlbiwgY2IpKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgaWYgKGNiLmZsYWdzICYgNCkge1xuICAgICAgICBjYi5mbGFncyAmPSAtMjtcbiAgICAgIH1cbiAgICAgIGlmICghKGNiLmZsYWdzICYgOCkpIGNiKCk7XG4gICAgICBjYi5mbGFncyAmPSAtMjtcbiAgICB9XG4gICAgYWN0aXZlUG9zdEZsdXNoQ2JzID0gbnVsbDtcbiAgICBwb3N0Rmx1c2hJbmRleCA9IDA7XG4gIH1cbn1cbmNvbnN0IGdldElkID0gKGpvYikgPT4gam9iLmlkID09IG51bGwgPyBqb2IuZmxhZ3MgJiAyID8gLTEgOiBJbmZpbml0eSA6IGpvYi5pZDtcbmZ1bmN0aW9uIGZsdXNoSm9icyhzZWVuKSB7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgc2VlbiA9IHNlZW4gfHwgLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgfVxuICBjb25zdCBjaGVjayA9ICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyAoam9iKSA9PiBjaGVja1JlY3Vyc2l2ZVVwZGF0ZXMoc2Vlbiwgam9iKSA6IE5PT1A7XG4gIHRyeSB7XG4gICAgZm9yIChmbHVzaEluZGV4ID0gMDsgZmx1c2hJbmRleCA8IHF1ZXVlLmxlbmd0aDsgZmx1c2hJbmRleCsrKSB7XG4gICAgICBjb25zdCBqb2IgPSBxdWV1ZVtmbHVzaEluZGV4XTtcbiAgICAgIGlmIChqb2IgJiYgIShqb2IuZmxhZ3MgJiA4KSkge1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBjaGVjayhqb2IpKSB7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGpvYi5mbGFncyAmIDQpIHtcbiAgICAgICAgICBqb2IuZmxhZ3MgJj0gfjE7XG4gICAgICAgIH1cbiAgICAgICAgY2FsbFdpdGhFcnJvckhhbmRsaW5nKFxuICAgICAgICAgIGpvYixcbiAgICAgICAgICBqb2IuaSxcbiAgICAgICAgICBqb2IuaSA/IDE1IDogMTRcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKCEoam9iLmZsYWdzICYgNCkpIHtcbiAgICAgICAgICBqb2IuZmxhZ3MgJj0gfjE7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0gZmluYWxseSB7XG4gICAgZm9yICg7IGZsdXNoSW5kZXggPCBxdWV1ZS5sZW5ndGg7IGZsdXNoSW5kZXgrKykge1xuICAgICAgY29uc3Qgam9iID0gcXVldWVbZmx1c2hJbmRleF07XG4gICAgICBpZiAoam9iKSB7XG4gICAgICAgIGpvYi5mbGFncyAmPSAtMjtcbiAgICAgIH1cbiAgICB9XG4gICAgZmx1c2hJbmRleCA9IC0xO1xuICAgIHF1ZXVlLmxlbmd0aCA9IDA7XG4gICAgZmx1c2hQb3N0Rmx1c2hDYnMoc2Vlbik7XG4gICAgY3VycmVudEZsdXNoUHJvbWlzZSA9IG51bGw7XG4gICAgaWYgKHF1ZXVlLmxlbmd0aCB8fCBwZW5kaW5nUG9zdEZsdXNoQ2JzLmxlbmd0aCkge1xuICAgICAgZmx1c2hKb2JzKHNlZW4pO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gY2hlY2tSZWN1cnNpdmVVcGRhdGVzKHNlZW4sIGZuKSB7XG4gIGNvbnN0IGNvdW50ID0gc2Vlbi5nZXQoZm4pIHx8IDA7XG4gIGlmIChjb3VudCA+IFJFQ1VSU0lPTl9MSU1JVCkge1xuICAgIGNvbnN0IGluc3RhbmNlID0gZm4uaTtcbiAgICBjb25zdCBjb21wb25lbnROYW1lID0gaW5zdGFuY2UgJiYgZ2V0Q29tcG9uZW50TmFtZShpbnN0YW5jZS50eXBlKTtcbiAgICBoYW5kbGVFcnJvcihcbiAgICAgIGBNYXhpbXVtIHJlY3Vyc2l2ZSB1cGRhdGVzIGV4Y2VlZGVkJHtjb21wb25lbnROYW1lID8gYCBpbiBjb21wb25lbnQgPCR7Y29tcG9uZW50TmFtZX0+YCA6IGBgfS4gVGhpcyBtZWFucyB5b3UgaGF2ZSBhIHJlYWN0aXZlIGVmZmVjdCB0aGF0IGlzIG11dGF0aW5nIGl0cyBvd24gZGVwZW5kZW5jaWVzIGFuZCB0aHVzIHJlY3Vyc2l2ZWx5IHRyaWdnZXJpbmcgaXRzZWxmLiBQb3NzaWJsZSBzb3VyY2VzIGluY2x1ZGUgY29tcG9uZW50IHRlbXBsYXRlLCByZW5kZXIgZnVuY3Rpb24sIHVwZGF0ZWQgaG9vayBvciB3YXRjaGVyIHNvdXJjZSBmdW5jdGlvbi5gLFxuICAgICAgbnVsbCxcbiAgICAgIDEwXG4gICAgKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBzZWVuLnNldChmbiwgY291bnQgKyAxKTtcbiAgcmV0dXJuIGZhbHNlO1xufVxuXG5sZXQgaXNIbXJVcGRhdGluZyA9IGZhbHNlO1xuY29uc3Qgc2V0SG1yVXBkYXRpbmcgPSAodikgPT4ge1xuICB0cnkge1xuICAgIHJldHVybiBpc0htclVwZGF0aW5nO1xuICB9IGZpbmFsbHkge1xuICAgIGlzSG1yVXBkYXRpbmcgPSB2O1xuICB9XG59O1xuY29uc3QgaG1yRGlydHlDb21wb25lbnRzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbmlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gIGdldEdsb2JhbFRoaXMoKS5fX1ZVRV9ITVJfUlVOVElNRV9fID0ge1xuICAgIGNyZWF0ZVJlY29yZDogdHJ5V3JhcChjcmVhdGVSZWNvcmQpLFxuICAgIHJlcmVuZGVyOiB0cnlXcmFwKHJlcmVuZGVyKSxcbiAgICByZWxvYWQ6IHRyeVdyYXAocmVsb2FkKVxuICB9O1xufVxuY29uc3QgbWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbmZ1bmN0aW9uIHJlZ2lzdGVySE1SKGluc3RhbmNlKSB7XG4gIGNvbnN0IGlkID0gaW5zdGFuY2UudHlwZS5fX2htcklkO1xuICBsZXQgcmVjb3JkID0gbWFwLmdldChpZCk7XG4gIGlmICghcmVjb3JkKSB7XG4gICAgY3JlYXRlUmVjb3JkKGlkLCBpbnN0YW5jZS50eXBlKTtcbiAgICByZWNvcmQgPSBtYXAuZ2V0KGlkKTtcbiAgfVxuICByZWNvcmQuaW5zdGFuY2VzLmFkZChpbnN0YW5jZSk7XG59XG5mdW5jdGlvbiB1bnJlZ2lzdGVySE1SKGluc3RhbmNlKSB7XG4gIG1hcC5nZXQoaW5zdGFuY2UudHlwZS5fX2htcklkKS5pbnN0YW5jZXMuZGVsZXRlKGluc3RhbmNlKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVJlY29yZChpZCwgaW5pdGlhbERlZikge1xuICBpZiAobWFwLmhhcyhpZCkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgbWFwLnNldChpZCwge1xuICAgIGluaXRpYWxEZWY6IG5vcm1hbGl6ZUNsYXNzQ29tcG9uZW50KGluaXRpYWxEZWYpLFxuICAgIGluc3RhbmNlczogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKVxuICB9KTtcbiAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBub3JtYWxpemVDbGFzc0NvbXBvbmVudChjb21wb25lbnQpIHtcbiAgcmV0dXJuIGlzQ2xhc3NDb21wb25lbnQoY29tcG9uZW50KSA/IGNvbXBvbmVudC5fX3ZjY09wdHMgOiBjb21wb25lbnQ7XG59XG5mdW5jdGlvbiByZXJlbmRlcihpZCwgbmV3UmVuZGVyKSB7XG4gIGNvbnN0IHJlY29yZCA9IG1hcC5nZXQoaWQpO1xuICBpZiAoIXJlY29yZCkge1xuICAgIHJldHVybjtcbiAgfVxuICByZWNvcmQuaW5pdGlhbERlZi5yZW5kZXIgPSBuZXdSZW5kZXI7XG4gIFsuLi5yZWNvcmQuaW5zdGFuY2VzXS5mb3JFYWNoKChpbnN0YW5jZSkgPT4ge1xuICAgIGlmIChuZXdSZW5kZXIpIHtcbiAgICAgIGluc3RhbmNlLnJlbmRlciA9IG5ld1JlbmRlcjtcbiAgICAgIG5vcm1hbGl6ZUNsYXNzQ29tcG9uZW50KGluc3RhbmNlLnR5cGUpLnJlbmRlciA9IG5ld1JlbmRlcjtcbiAgICB9XG4gICAgaW5zdGFuY2UucmVuZGVyQ2FjaGUgPSBbXTtcbiAgICBpc0htclVwZGF0aW5nID0gdHJ1ZTtcbiAgICBpZiAoIShpbnN0YW5jZS5qb2IuZmxhZ3MgJiA4KSkge1xuICAgICAgaW5zdGFuY2UudXBkYXRlKCk7XG4gICAgfVxuICAgIGlzSG1yVXBkYXRpbmcgPSBmYWxzZTtcbiAgfSk7XG59XG5mdW5jdGlvbiByZWxvYWQoaWQsIG5ld0NvbXApIHtcbiAgY29uc3QgcmVjb3JkID0gbWFwLmdldChpZCk7XG4gIGlmICghcmVjb3JkKSByZXR1cm47XG4gIG5ld0NvbXAgPSBub3JtYWxpemVDbGFzc0NvbXBvbmVudChuZXdDb21wKTtcbiAgdXBkYXRlQ29tcG9uZW50RGVmKHJlY29yZC5pbml0aWFsRGVmLCBuZXdDb21wKTtcbiAgY29uc3QgaW5zdGFuY2VzID0gWy4uLnJlY29yZC5pbnN0YW5jZXNdO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGluc3RhbmNlcy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGluc3RhbmNlID0gaW5zdGFuY2VzW2ldO1xuICAgIGNvbnN0IG9sZENvbXAgPSBub3JtYWxpemVDbGFzc0NvbXBvbmVudChpbnN0YW5jZS50eXBlKTtcbiAgICBsZXQgZGlydHlJbnN0YW5jZXMgPSBobXJEaXJ0eUNvbXBvbmVudHMuZ2V0KG9sZENvbXApO1xuICAgIGlmICghZGlydHlJbnN0YW5jZXMpIHtcbiAgICAgIGlmIChvbGRDb21wICE9PSByZWNvcmQuaW5pdGlhbERlZikge1xuICAgICAgICB1cGRhdGVDb21wb25lbnREZWYob2xkQ29tcCwgbmV3Q29tcCk7XG4gICAgICB9XG4gICAgICBobXJEaXJ0eUNvbXBvbmVudHMuc2V0KG9sZENvbXAsIGRpcnR5SW5zdGFuY2VzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSk7XG4gICAgfVxuICAgIGRpcnR5SW5zdGFuY2VzLmFkZChpbnN0YW5jZSk7XG4gICAgaW5zdGFuY2UuYXBwQ29udGV4dC5wcm9wc0NhY2hlLmRlbGV0ZShpbnN0YW5jZS50eXBlKTtcbiAgICBpbnN0YW5jZS5hcHBDb250ZXh0LmVtaXRzQ2FjaGUuZGVsZXRlKGluc3RhbmNlLnR5cGUpO1xuICAgIGluc3RhbmNlLmFwcENvbnRleHQub3B0aW9uc0NhY2hlLmRlbGV0ZShpbnN0YW5jZS50eXBlKTtcbiAgICBpZiAoaW5zdGFuY2UuY2VSZWxvYWQpIHtcbiAgICAgIGRpcnR5SW5zdGFuY2VzLmFkZChpbnN0YW5jZSk7XG4gICAgICBpbnN0YW5jZS5jZVJlbG9hZChuZXdDb21wLnN0eWxlcyk7XG4gICAgICBkaXJ0eUluc3RhbmNlcy5kZWxldGUoaW5zdGFuY2UpO1xuICAgIH0gZWxzZSBpZiAoaW5zdGFuY2UucGFyZW50KSB7XG4gICAgICBxdWV1ZUpvYigoKSA9PiB7XG4gICAgICAgIGlmICghKGluc3RhbmNlLmpvYi5mbGFncyAmIDgpKSB7XG4gICAgICAgICAgaXNIbXJVcGRhdGluZyA9IHRydWU7XG4gICAgICAgICAgaW5zdGFuY2UucGFyZW50LnVwZGF0ZSgpO1xuICAgICAgICAgIGlzSG1yVXBkYXRpbmcgPSBmYWxzZTtcbiAgICAgICAgICBkaXJ0eUluc3RhbmNlcy5kZWxldGUoaW5zdGFuY2UpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKGluc3RhbmNlLmFwcENvbnRleHQucmVsb2FkKSB7XG4gICAgICBpbnN0YW5jZS5hcHBDb250ZXh0LnJlbG9hZCgpO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgIFwiW0hNUl0gUm9vdCBvciBtYW51YWxseSBtb3VudGVkIGluc3RhbmNlIG1vZGlmaWVkLiBGdWxsIHJlbG9hZCByZXF1aXJlZC5cIlxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKGluc3RhbmNlLnJvb3QuY2UgJiYgaW5zdGFuY2UgIT09IGluc3RhbmNlLnJvb3QpIHtcbiAgICAgIGluc3RhbmNlLnJvb3QuY2UuX3JlbW92ZUNoaWxkU3R5bGUob2xkQ29tcCk7XG4gICAgfVxuICB9XG4gIHF1ZXVlUG9zdEZsdXNoQ2IoKCkgPT4ge1xuICAgIGhtckRpcnR5Q29tcG9uZW50cy5jbGVhcigpO1xuICB9KTtcbn1cbmZ1bmN0aW9uIHVwZGF0ZUNvbXBvbmVudERlZihvbGRDb21wLCBuZXdDb21wKSB7XG4gIGV4dGVuZChvbGRDb21wLCBuZXdDb21wKTtcbiAgZm9yIChjb25zdCBrZXkgaW4gb2xkQ29tcCkge1xuICAgIGlmIChrZXkgIT09IFwiX19maWxlXCIgJiYgIShrZXkgaW4gbmV3Q29tcCkpIHtcbiAgICAgIGRlbGV0ZSBvbGRDb21wW2tleV07XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiB0cnlXcmFwKGZuKSB7XG4gIHJldHVybiAoaWQsIGFyZykgPT4ge1xuICAgIHRyeSB7XG4gICAgICByZXR1cm4gZm4oaWQsIGFyZyk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgY29uc29sZS5lcnJvcihlKTtcbiAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgYFtITVJdIFNvbWV0aGluZyB3ZW50IHdyb25nIGR1cmluZyBWdWUgY29tcG9uZW50IGhvdC1yZWxvYWQuIEZ1bGwgcmVsb2FkIHJlcXVpcmVkLmBcbiAgICAgICk7XG4gICAgfVxuICB9O1xufVxuXG5sZXQgZGV2dG9vbHMkMTtcbmxldCBidWZmZXIgPSBbXTtcbmxldCBkZXZ0b29sc05vdEluc3RhbGxlZCA9IGZhbHNlO1xuZnVuY3Rpb24gZW1pdCQxKGV2ZW50LCAuLi5hcmdzKSB7XG4gIGlmIChkZXZ0b29scyQxKSB7XG4gICAgZGV2dG9vbHMkMS5lbWl0KGV2ZW50LCAuLi5hcmdzKTtcbiAgfSBlbHNlIGlmICghZGV2dG9vbHNOb3RJbnN0YWxsZWQpIHtcbiAgICBidWZmZXIucHVzaCh7IGV2ZW50LCBhcmdzIH0pO1xuICB9XG59XG5mdW5jdGlvbiBzZXREZXZ0b29sc0hvb2skMShob29rLCB0YXJnZXQpIHtcbiAgdmFyIF9hLCBfYjtcbiAgZGV2dG9vbHMkMSA9IGhvb2s7XG4gIGlmIChkZXZ0b29scyQxKSB7XG4gICAgZGV2dG9vbHMkMS5lbmFibGVkID0gdHJ1ZTtcbiAgICBidWZmZXIuZm9yRWFjaCgoeyBldmVudCwgYXJncyB9KSA9PiBkZXZ0b29scyQxLmVtaXQoZXZlbnQsIC4uLmFyZ3MpKTtcbiAgICBidWZmZXIgPSBbXTtcbiAgfSBlbHNlIGlmIChcbiAgICAvLyBoYW5kbGUgbGF0ZSBkZXZ0b29scyBpbmplY3Rpb24gLSBvbmx5IGRvIHRoaXMgaWYgd2UgYXJlIGluIGFuIGFjdHVhbFxuICAgIC8vIGJyb3dzZXIgZW52aXJvbm1lbnQgdG8gYXZvaWQgdGhlIHRpbWVyIGhhbmRsZSBzdGFsbGluZyB0ZXN0IHJ1bm5lciBleGl0XG4gICAgLy8gKCM0ODE1KVxuICAgIHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgJiYgLy8gc29tZSBlbnZzIG1vY2sgd2luZG93IGJ1dCBub3QgZnVsbHlcbiAgICB3aW5kb3cuSFRNTEVsZW1lbnQgJiYgLy8gYWxzbyBleGNsdWRlIGpzZG9tXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXJlc3RyaWN0ZWQtc3ludGF4XG4gICAgISgoX2IgPSAoX2EgPSB3aW5kb3cubmF2aWdhdG9yKSA9PSBudWxsID8gdm9pZCAwIDogX2EudXNlckFnZW50KSA9PSBudWxsID8gdm9pZCAwIDogX2IuaW5jbHVkZXMoXCJqc2RvbVwiKSlcbiAgKSB7XG4gICAgY29uc3QgcmVwbGF5ID0gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0hPT0tfUkVQTEFZX18gPSB0YXJnZXQuX19WVUVfREVWVE9PTFNfSE9PS19SRVBMQVlfXyB8fCBbXTtcbiAgICByZXBsYXkucHVzaCgobmV3SG9vaykgPT4ge1xuICAgICAgc2V0RGV2dG9vbHNIb29rJDEobmV3SG9vaywgdGFyZ2V0KTtcbiAgICB9KTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIGlmICghZGV2dG9vbHMkMSkge1xuICAgICAgICB0YXJnZXQuX19WVUVfREVWVE9PTFNfSE9PS19SRVBMQVlfXyA9IG51bGw7XG4gICAgICAgIGRldnRvb2xzTm90SW5zdGFsbGVkID0gdHJ1ZTtcbiAgICAgICAgYnVmZmVyID0gW107XG4gICAgICB9XG4gICAgfSwgM2UzKTtcbiAgfSBlbHNlIHtcbiAgICBkZXZ0b29sc05vdEluc3RhbGxlZCA9IHRydWU7XG4gICAgYnVmZmVyID0gW107XG4gIH1cbn1cbmZ1bmN0aW9uIGRldnRvb2xzSW5pdEFwcChhcHAsIHZlcnNpb24pIHtcbiAgZW1pdCQxKFwiYXBwOmluaXRcIiAvKiBBUFBfSU5JVCAqLywgYXBwLCB2ZXJzaW9uLCB7XG4gICAgRnJhZ21lbnQsXG4gICAgVGV4dCxcbiAgICBDb21tZW50LFxuICAgIFN0YXRpY1xuICB9KTtcbn1cbmZ1bmN0aW9uIGRldnRvb2xzVW5tb3VudEFwcChhcHApIHtcbiAgZW1pdCQxKFwiYXBwOnVubW91bnRcIiAvKiBBUFBfVU5NT1VOVCAqLywgYXBwKTtcbn1cbmNvbnN0IGRldnRvb2xzQ29tcG9uZW50QWRkZWQgPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlRGV2dG9vbHNDb21wb25lbnRIb29rKFwiY29tcG9uZW50OmFkZGVkXCIgLyogQ09NUE9ORU5UX0FEREVEICovKTtcbmNvbnN0IGRldnRvb2xzQ29tcG9uZW50VXBkYXRlZCA9IC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVEZXZ0b29sc0NvbXBvbmVudEhvb2soXCJjb21wb25lbnQ6dXBkYXRlZFwiIC8qIENPTVBPTkVOVF9VUERBVEVEICovKTtcbmNvbnN0IF9kZXZ0b29sc0NvbXBvbmVudFJlbW92ZWQgPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlRGV2dG9vbHNDb21wb25lbnRIb29rKFxuICBcImNvbXBvbmVudDpyZW1vdmVkXCIgLyogQ09NUE9ORU5UX1JFTU9WRUQgKi9cbik7XG5jb25zdCBkZXZ0b29sc0NvbXBvbmVudFJlbW92ZWQgPSAoY29tcG9uZW50KSA9PiB7XG4gIGlmIChkZXZ0b29scyQxICYmIHR5cGVvZiBkZXZ0b29scyQxLmNsZWFudXBCdWZmZXIgPT09IFwiZnVuY3Rpb25cIiAmJiAvLyByZW1vdmUgdGhlIGNvbXBvbmVudCBpZiBpdCB3YXNuJ3QgYnVmZmVyZWRcbiAgIWRldnRvb2xzJDEuY2xlYW51cEJ1ZmZlcihjb21wb25lbnQpKSB7XG4gICAgX2RldnRvb2xzQ29tcG9uZW50UmVtb3ZlZChjb21wb25lbnQpO1xuICB9XG59O1xuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIGNyZWF0ZURldnRvb2xzQ29tcG9uZW50SG9vayhob29rKSB7XG4gIHJldHVybiAoY29tcG9uZW50KSA9PiB7XG4gICAgZW1pdCQxKFxuICAgICAgaG9vayxcbiAgICAgIGNvbXBvbmVudC5hcHBDb250ZXh0LmFwcCxcbiAgICAgIGNvbXBvbmVudC51aWQsXG4gICAgICBjb21wb25lbnQucGFyZW50ID8gY29tcG9uZW50LnBhcmVudC51aWQgOiB2b2lkIDAsXG4gICAgICBjb21wb25lbnRcbiAgICApO1xuICB9O1xufVxuY29uc3QgZGV2dG9vbHNQZXJmU3RhcnQgPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlRGV2dG9vbHNQZXJmb3JtYW5jZUhvb2soXCJwZXJmOnN0YXJ0XCIgLyogUEVSRk9STUFOQ0VfU1RBUlQgKi8pO1xuY29uc3QgZGV2dG9vbHNQZXJmRW5kID0gLyogQF9fUFVSRV9fICovIGNyZWF0ZURldnRvb2xzUGVyZm9ybWFuY2VIb29rKFwicGVyZjplbmRcIiAvKiBQRVJGT1JNQU5DRV9FTkQgKi8pO1xuZnVuY3Rpb24gY3JlYXRlRGV2dG9vbHNQZXJmb3JtYW5jZUhvb2soaG9vaykge1xuICByZXR1cm4gKGNvbXBvbmVudCwgdHlwZSwgdGltZSkgPT4ge1xuICAgIGVtaXQkMShob29rLCBjb21wb25lbnQuYXBwQ29udGV4dC5hcHAsIGNvbXBvbmVudC51aWQsIGNvbXBvbmVudCwgdHlwZSwgdGltZSk7XG4gIH07XG59XG5mdW5jdGlvbiBkZXZ0b29sc0NvbXBvbmVudEVtaXQoY29tcG9uZW50LCBldmVudCwgcGFyYW1zKSB7XG4gIGVtaXQkMShcbiAgICBcImNvbXBvbmVudDplbWl0XCIgLyogQ09NUE9ORU5UX0VNSVQgKi8sXG4gICAgY29tcG9uZW50LmFwcENvbnRleHQuYXBwLFxuICAgIGNvbXBvbmVudCxcbiAgICBldmVudCxcbiAgICBwYXJhbXNcbiAgKTtcbn1cblxubGV0IGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZSA9IG51bGw7XG5sZXQgY3VycmVudFNjb3BlSWQgPSBudWxsO1xuZnVuY3Rpb24gc2V0Q3VycmVudFJlbmRlcmluZ0luc3RhbmNlKGluc3RhbmNlKSB7XG4gIGNvbnN0IHByZXYgPSBjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2U7XG4gIGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZSA9IGluc3RhbmNlO1xuICBjdXJyZW50U2NvcGVJZCA9IGluc3RhbmNlICYmIGluc3RhbmNlLnR5cGUuX19zY29wZUlkIHx8IG51bGw7XG4gIHJldHVybiBwcmV2O1xufVxuZnVuY3Rpb24gcHVzaFNjb3BlSWQoaWQpIHtcbiAgY3VycmVudFNjb3BlSWQgPSBpZDtcbn1cbmZ1bmN0aW9uIHBvcFNjb3BlSWQoKSB7XG4gIGN1cnJlbnRTY29wZUlkID0gbnVsbDtcbn1cbmNvbnN0IHdpdGhTY29wZUlkID0gKF9pZCkgPT4gd2l0aEN0eDtcbmZ1bmN0aW9uIHdpdGhDdHgoZm4sIGN0eCA9IGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZSwgaXNOb25TY29wZWRTbG90KSB7XG4gIGlmICghY3R4KSByZXR1cm4gZm47XG4gIGlmIChmbi5fbikge1xuICAgIHJldHVybiBmbjtcbiAgfVxuICBjb25zdCByZW5kZXJGbldpdGhDb250ZXh0ID0gKC4uLmFyZ3MpID0+IHtcbiAgICBpZiAocmVuZGVyRm5XaXRoQ29udGV4dC5fZCkge1xuICAgICAgc2V0QmxvY2tUcmFja2luZygtMSk7XG4gICAgfVxuICAgIGNvbnN0IHByZXZJbnN0YW5jZSA9IHNldEN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZShjdHgpO1xuICAgIGNvbnN0IHByZXZTdGFja1NpemUgPSBibG9ja1N0YWNrLmxlbmd0aDtcbiAgICBsZXQgcmVzO1xuICAgIHRyeSB7XG4gICAgICByZXMgPSBmbiguLi5hcmdzKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgZm9yIChsZXQgaSA9IGJsb2NrU3RhY2subGVuZ3RoOyBpID4gcHJldlN0YWNrU2l6ZTsgaS0tKSBjbG9zZUJsb2NrKCk7XG4gICAgICBzZXRDdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UocHJldkluc3RhbmNlKTtcbiAgICAgIGlmIChyZW5kZXJGbldpdGhDb250ZXh0Ll9kKSB7XG4gICAgICAgIHNldEJsb2NrVHJhY2tpbmcoMSk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykge1xuICAgICAgZGV2dG9vbHNDb21wb25lbnRVcGRhdGVkKGN0eCk7XG4gICAgfVxuICAgIHJldHVybiByZXM7XG4gIH07XG4gIHJlbmRlckZuV2l0aENvbnRleHQuX24gPSB0cnVlO1xuICByZW5kZXJGbldpdGhDb250ZXh0Ll9jID0gdHJ1ZTtcbiAgcmVuZGVyRm5XaXRoQ29udGV4dC5fZCA9IHRydWU7XG4gIHJldHVybiByZW5kZXJGbldpdGhDb250ZXh0O1xufVxuXG5mdW5jdGlvbiB2YWxpZGF0ZURpcmVjdGl2ZU5hbWUobmFtZSkge1xuICBpZiAoaXNCdWlsdEluRGlyZWN0aXZlKG5hbWUpKSB7XG4gICAgd2FybiQxKFwiRG8gbm90IHVzZSBidWlsdC1pbiBkaXJlY3RpdmUgaWRzIGFzIGN1c3RvbSBkaXJlY3RpdmUgaWQ6IFwiICsgbmFtZSk7XG4gIH1cbn1cbmZ1bmN0aW9uIHdpdGhEaXJlY3RpdmVzKHZub2RlLCBkaXJlY3RpdmVzKSB7XG4gIGlmIChjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UgPT09IG51bGwpIHtcbiAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdhcm4kMShgd2l0aERpcmVjdGl2ZXMgY2FuIG9ubHkgYmUgdXNlZCBpbnNpZGUgcmVuZGVyIGZ1bmN0aW9ucy5gKTtcbiAgICByZXR1cm4gdm5vZGU7XG4gIH1cbiAgY29uc3QgaW5zdGFuY2UgPSBnZXRDb21wb25lbnRQdWJsaWNJbnN0YW5jZShjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UpO1xuICBjb25zdCBiaW5kaW5ncyA9IHZub2RlLmRpcnMgfHwgKHZub2RlLmRpcnMgPSBbXSk7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgZGlyZWN0aXZlcy5sZW5ndGg7IGkrKykge1xuICAgIGxldCBbZGlyLCB2YWx1ZSwgYXJnLCBtb2RpZmllcnMgPSBFTVBUWV9PQkpdID0gZGlyZWN0aXZlc1tpXTtcbiAgICBpZiAoZGlyKSB7XG4gICAgICBpZiAoaXNGdW5jdGlvbihkaXIpKSB7XG4gICAgICAgIGRpciA9IHtcbiAgICAgICAgICBtb3VudGVkOiBkaXIsXG4gICAgICAgICAgdXBkYXRlZDogZGlyXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBpZiAoZGlyLmRlZXApIHtcbiAgICAgICAgdHJhdmVyc2UodmFsdWUpO1xuICAgICAgfVxuICAgICAgYmluZGluZ3MucHVzaCh7XG4gICAgICAgIGRpcixcbiAgICAgICAgaW5zdGFuY2UsXG4gICAgICAgIHZhbHVlLFxuICAgICAgICBvbGRWYWx1ZTogdm9pZCAwLFxuICAgICAgICBhcmcsXG4gICAgICAgIG1vZGlmaWVyc1xuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIHJldHVybiB2bm9kZTtcbn1cbmZ1bmN0aW9uIGludm9rZURpcmVjdGl2ZUhvb2sodm5vZGUsIHByZXZWTm9kZSwgaW5zdGFuY2UsIG5hbWUpIHtcbiAgY29uc3QgYmluZGluZ3MgPSB2bm9kZS5kaXJzO1xuICBjb25zdCBvbGRCaW5kaW5ncyA9IHByZXZWTm9kZSAmJiBwcmV2Vk5vZGUuZGlycztcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBiaW5kaW5ncy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGJpbmRpbmcgPSBiaW5kaW5nc1tpXTtcbiAgICBpZiAob2xkQmluZGluZ3MpIHtcbiAgICAgIGJpbmRpbmcub2xkVmFsdWUgPSBvbGRCaW5kaW5nc1tpXS52YWx1ZTtcbiAgICB9XG4gICAgbGV0IGhvb2sgPSBiaW5kaW5nLmRpcltuYW1lXTtcbiAgICBpZiAoaG9vaykge1xuICAgICAgcGF1c2VUcmFja2luZygpO1xuICAgICAgY2FsbFdpdGhBc3luY0Vycm9ySGFuZGxpbmcoaG9vaywgaW5zdGFuY2UsIDgsIFtcbiAgICAgICAgdm5vZGUuZWwsXG4gICAgICAgIGJpbmRpbmcsXG4gICAgICAgIHZub2RlLFxuICAgICAgICBwcmV2Vk5vZGVcbiAgICAgIF0pO1xuICAgICAgcmVzZXRUcmFja2luZygpO1xuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiBwcm92aWRlKGtleSwgdmFsdWUpIHtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICBpZiAoIWN1cnJlbnRJbnN0YW5jZSB8fCBjdXJyZW50SW5zdGFuY2UuaXNNb3VudGVkKSB7XG4gICAgICB3YXJuJDEoYHByb3ZpZGUoKSBjYW4gb25seSBiZSB1c2VkIGluc2lkZSBzZXR1cCgpLmApO1xuICAgIH1cbiAgfVxuICBpZiAoY3VycmVudEluc3RhbmNlKSB7XG4gICAgbGV0IHByb3ZpZGVzID0gY3VycmVudEluc3RhbmNlLnByb3ZpZGVzO1xuICAgIGNvbnN0IHBhcmVudFByb3ZpZGVzID0gY3VycmVudEluc3RhbmNlLnBhcmVudCAmJiBjdXJyZW50SW5zdGFuY2UucGFyZW50LnByb3ZpZGVzO1xuICAgIGlmIChwYXJlbnRQcm92aWRlcyA9PT0gcHJvdmlkZXMpIHtcbiAgICAgIHByb3ZpZGVzID0gY3VycmVudEluc3RhbmNlLnByb3ZpZGVzID0gT2JqZWN0LmNyZWF0ZShwYXJlbnRQcm92aWRlcyk7XG4gICAgfVxuICAgIHByb3ZpZGVzW2tleV0gPSB2YWx1ZTtcbiAgfVxufVxuZnVuY3Rpb24gaW5qZWN0KGtleSwgZGVmYXVsdFZhbHVlLCB0cmVhdERlZmF1bHRBc0ZhY3RvcnkgPSBmYWxzZSkge1xuICBjb25zdCBpbnN0YW5jZSA9IGdldEN1cnJlbnRJbnN0YW5jZSgpO1xuICBpZiAoaW5zdGFuY2UgfHwgY3VycmVudEFwcCkge1xuICAgIGxldCBwcm92aWRlcyA9IGN1cnJlbnRBcHAgPyBjdXJyZW50QXBwLl9jb250ZXh0LnByb3ZpZGVzIDogaW5zdGFuY2UgPyBpbnN0YW5jZS5wYXJlbnQgPT0gbnVsbCB8fCBpbnN0YW5jZS5jZSA/IGluc3RhbmNlLnZub2RlLmFwcENvbnRleHQgJiYgaW5zdGFuY2Uudm5vZGUuYXBwQ29udGV4dC5wcm92aWRlcyA6IGluc3RhbmNlLnBhcmVudC5wcm92aWRlcyA6IHZvaWQgMDtcbiAgICBpZiAocHJvdmlkZXMgJiYga2V5IGluIHByb3ZpZGVzKSB7XG4gICAgICByZXR1cm4gcHJvdmlkZXNba2V5XTtcbiAgICB9IGVsc2UgaWYgKGFyZ3VtZW50cy5sZW5ndGggPiAxKSB7XG4gICAgICByZXR1cm4gdHJlYXREZWZhdWx0QXNGYWN0b3J5ICYmIGlzRnVuY3Rpb24oZGVmYXVsdFZhbHVlKSA/IGRlZmF1bHRWYWx1ZS5jYWxsKGluc3RhbmNlICYmIGluc3RhbmNlLnByb3h5KSA6IGRlZmF1bHRWYWx1ZTtcbiAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgIHdhcm4kMShgaW5qZWN0aW9uIFwiJHtTdHJpbmcoa2V5KX1cIiBub3QgZm91bmQuYCk7XG4gICAgfVxuICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICB3YXJuJDEoYGluamVjdCgpIGNhbiBvbmx5IGJlIHVzZWQgaW5zaWRlIHNldHVwKCkgb3IgZnVuY3Rpb25hbCBjb21wb25lbnRzLmApO1xuICB9XG59XG5mdW5jdGlvbiBoYXNJbmplY3Rpb25Db250ZXh0KCkge1xuICByZXR1cm4gISEoZ2V0Q3VycmVudEluc3RhbmNlKCkgfHwgY3VycmVudEFwcCk7XG59XG5cbmNvbnN0IHNzckNvbnRleHRLZXkgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sLmZvcihcInYtc2N4XCIpO1xuY29uc3QgdXNlU1NSQ29udGV4dCA9ICgpID0+IHtcbiAge1xuICAgIGNvbnN0IGN0eCA9IGluamVjdChzc3JDb250ZXh0S2V5KTtcbiAgICBpZiAoIWN0eCkge1xuICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB3YXJuJDEoXG4gICAgICAgIGBTZXJ2ZXIgcmVuZGVyaW5nIGNvbnRleHQgbm90IHByb3ZpZGVkLiBNYWtlIHN1cmUgdG8gb25seSBjYWxsIHVzZVNTUkNvbnRleHQoKSBjb25kaXRpb25hbGx5IGluIHRoZSBzZXJ2ZXIgYnVpbGQuYFxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIGN0eDtcbiAgfVxufTtcblxuZnVuY3Rpb24gd2F0Y2hFZmZlY3QoZWZmZWN0LCBvcHRpb25zKSB7XG4gIHJldHVybiBkb1dhdGNoKGVmZmVjdCwgbnVsbCwgb3B0aW9ucyk7XG59XG5mdW5jdGlvbiB3YXRjaFBvc3RFZmZlY3QoZWZmZWN0LCBvcHRpb25zKSB7XG4gIHJldHVybiBkb1dhdGNoKFxuICAgIGVmZmVjdCxcbiAgICBudWxsLFxuICAgICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyBleHRlbmQoe30sIG9wdGlvbnMsIHsgZmx1c2g6IFwicG9zdFwiIH0pIDogeyBmbHVzaDogXCJwb3N0XCIgfVxuICApO1xufVxuZnVuY3Rpb24gd2F0Y2hTeW5jRWZmZWN0KGVmZmVjdCwgb3B0aW9ucykge1xuICByZXR1cm4gZG9XYXRjaChcbiAgICBlZmZlY3QsXG4gICAgbnVsbCxcbiAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gZXh0ZW5kKHt9LCBvcHRpb25zLCB7IGZsdXNoOiBcInN5bmNcIiB9KSA6IHsgZmx1c2g6IFwic3luY1wiIH1cbiAgKTtcbn1cbmZ1bmN0aW9uIHdhdGNoKHNvdXJjZSwgY2IsIG9wdGlvbnMpIHtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWlzRnVuY3Rpb24oY2IpKSB7XG4gICAgd2FybiQxKFxuICAgICAgYFxcYHdhdGNoKGZuLCBvcHRpb25zPylcXGAgc2lnbmF0dXJlIGhhcyBiZWVuIG1vdmVkIHRvIGEgc2VwYXJhdGUgQVBJLiBVc2UgXFxgd2F0Y2hFZmZlY3QoZm4sIG9wdGlvbnM/KVxcYCBpbnN0ZWFkLiBcXGB3YXRjaFxcYCBub3cgb25seSBzdXBwb3J0cyBcXGB3YXRjaChzb3VyY2UsIGNiLCBvcHRpb25zPykgc2lnbmF0dXJlLmBcbiAgICApO1xuICB9XG4gIHJldHVybiBkb1dhdGNoKHNvdXJjZSwgY2IsIG9wdGlvbnMpO1xufVxuZnVuY3Rpb24gZG9XYXRjaChzb3VyY2UsIGNiLCBvcHRpb25zID0gRU1QVFlfT0JKKSB7XG4gIGNvbnN0IHsgaW1tZWRpYXRlLCBkZWVwLCBmbHVzaCwgb25jZSB9ID0gb3B0aW9ucztcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWNiKSB7XG4gICAgaWYgKGltbWVkaWF0ZSAhPT0gdm9pZCAwKSB7XG4gICAgICB3YXJuJDEoXG4gICAgICAgIGB3YXRjaCgpIFwiaW1tZWRpYXRlXCIgb3B0aW9uIGlzIG9ubHkgcmVzcGVjdGVkIHdoZW4gdXNpbmcgdGhlIHdhdGNoKHNvdXJjZSwgY2FsbGJhY2ssIG9wdGlvbnM/KSBzaWduYXR1cmUuYFxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKGRlZXAgIT09IHZvaWQgMCkge1xuICAgICAgd2FybiQxKFxuICAgICAgICBgd2F0Y2goKSBcImRlZXBcIiBvcHRpb24gaXMgb25seSByZXNwZWN0ZWQgd2hlbiB1c2luZyB0aGUgd2F0Y2goc291cmNlLCBjYWxsYmFjaywgb3B0aW9ucz8pIHNpZ25hdHVyZS5gXG4gICAgICApO1xuICAgIH1cbiAgICBpZiAob25jZSAhPT0gdm9pZCAwKSB7XG4gICAgICB3YXJuJDEoXG4gICAgICAgIGB3YXRjaCgpIFwib25jZVwiIG9wdGlvbiBpcyBvbmx5IHJlc3BlY3RlZCB3aGVuIHVzaW5nIHRoZSB3YXRjaChzb3VyY2UsIGNhbGxiYWNrLCBvcHRpb25zPykgc2lnbmF0dXJlLmBcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIGNvbnN0IGJhc2VXYXRjaE9wdGlvbnMgPSBleHRlbmQoe30sIG9wdGlvbnMpO1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkgYmFzZVdhdGNoT3B0aW9ucy5vbldhcm4gPSB3YXJuJDE7XG4gIGNvbnN0IHJ1bnNJbW1lZGlhdGVseSA9IGNiICYmIGltbWVkaWF0ZSB8fCAhY2IgJiYgZmx1c2ggIT09IFwicG9zdFwiO1xuICBsZXQgc3NyQ2xlYW51cDtcbiAgaWYgKGlzSW5TU1JDb21wb25lbnRTZXR1cCkge1xuICAgIGlmIChmbHVzaCA9PT0gXCJzeW5jXCIpIHtcbiAgICAgIGNvbnN0IGN0eCA9IHVzZVNTUkNvbnRleHQoKTtcbiAgICAgIHNzckNsZWFudXAgPSBjdHguX193YXRjaGVySGFuZGxlcyB8fCAoY3R4Ll9fd2F0Y2hlckhhbmRsZXMgPSBbXSk7XG4gICAgfSBlbHNlIGlmICghcnVuc0ltbWVkaWF0ZWx5KSB7XG4gICAgICBjb25zdCB3YXRjaFN0b3BIYW5kbGUgPSAoKSA9PiB7XG4gICAgICB9O1xuICAgICAgd2F0Y2hTdG9wSGFuZGxlLnN0b3AgPSBOT09QO1xuICAgICAgd2F0Y2hTdG9wSGFuZGxlLnJlc3VtZSA9IE5PT1A7XG4gICAgICB3YXRjaFN0b3BIYW5kbGUucGF1c2UgPSBOT09QO1xuICAgICAgcmV0dXJuIHdhdGNoU3RvcEhhbmRsZTtcbiAgICB9XG4gIH1cbiAgY29uc3QgaW5zdGFuY2UgPSBjdXJyZW50SW5zdGFuY2U7XG4gIGJhc2VXYXRjaE9wdGlvbnMuY2FsbCA9IChmbiwgdHlwZSwgYXJncykgPT4gY2FsbFdpdGhBc3luY0Vycm9ySGFuZGxpbmcoZm4sIGluc3RhbmNlLCB0eXBlLCBhcmdzKTtcbiAgbGV0IGlzUHJlID0gZmFsc2U7XG4gIGlmIChmbHVzaCA9PT0gXCJwb3N0XCIpIHtcbiAgICBiYXNlV2F0Y2hPcHRpb25zLnNjaGVkdWxlciA9IChqb2IpID0+IHtcbiAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdChqb2IsIGluc3RhbmNlICYmIGluc3RhbmNlLnN1c3BlbnNlKTtcbiAgICB9O1xuICB9IGVsc2UgaWYgKGZsdXNoICE9PSBcInN5bmNcIikge1xuICAgIGlzUHJlID0gdHJ1ZTtcbiAgICBiYXNlV2F0Y2hPcHRpb25zLnNjaGVkdWxlciA9IChqb2IsIGlzRmlyc3RSdW4pID0+IHtcbiAgICAgIGlmIChpc0ZpcnN0UnVuKSB7XG4gICAgICAgIGpvYigpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcXVldWVKb2Ioam9iKTtcbiAgICAgIH1cbiAgICB9O1xuICB9XG4gIGJhc2VXYXRjaE9wdGlvbnMuYXVnbWVudEpvYiA9IChqb2IpID0+IHtcbiAgICBpZiAoY2IpIHtcbiAgICAgIGpvYi5mbGFncyB8PSA0O1xuICAgIH1cbiAgICBpZiAoaXNQcmUpIHtcbiAgICAgIGpvYi5mbGFncyB8PSAyO1xuICAgICAgaWYgKGluc3RhbmNlKSB7XG4gICAgICAgIGpvYi5pZCA9IGluc3RhbmNlLnVpZDtcbiAgICAgICAgam9iLmkgPSBpbnN0YW5jZTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIGNvbnN0IHdhdGNoSGFuZGxlID0gd2F0Y2gkMShzb3VyY2UsIGNiLCBiYXNlV2F0Y2hPcHRpb25zKTtcbiAgaWYgKGlzSW5TU1JDb21wb25lbnRTZXR1cCkge1xuICAgIGlmIChzc3JDbGVhbnVwKSB7XG4gICAgICBzc3JDbGVhbnVwLnB1c2god2F0Y2hIYW5kbGUpO1xuICAgIH0gZWxzZSBpZiAocnVuc0ltbWVkaWF0ZWx5KSB7XG4gICAgICB3YXRjaEhhbmRsZSgpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gd2F0Y2hIYW5kbGU7XG59XG5mdW5jdGlvbiBpbnN0YW5jZVdhdGNoKHNvdXJjZSwgdmFsdWUsIG9wdGlvbnMpIHtcbiAgY29uc3QgcHVibGljVGhpcyA9IHRoaXMucHJveHk7XG4gIGNvbnN0IGdldHRlciA9IGlzU3RyaW5nKHNvdXJjZSkgPyBzb3VyY2UuaW5jbHVkZXMoXCIuXCIpID8gY3JlYXRlUGF0aEdldHRlcihwdWJsaWNUaGlzLCBzb3VyY2UpIDogKCkgPT4gcHVibGljVGhpc1tzb3VyY2VdIDogc291cmNlLmJpbmQocHVibGljVGhpcywgcHVibGljVGhpcyk7XG4gIGxldCBjYjtcbiAgaWYgKGlzRnVuY3Rpb24odmFsdWUpKSB7XG4gICAgY2IgPSB2YWx1ZTtcbiAgfSBlbHNlIHtcbiAgICBjYiA9IHZhbHVlLmhhbmRsZXI7XG4gICAgb3B0aW9ucyA9IHZhbHVlO1xuICB9XG4gIGNvbnN0IHJlc2V0ID0gc2V0Q3VycmVudEluc3RhbmNlKHRoaXMpO1xuICBjb25zdCByZXMgPSBkb1dhdGNoKGdldHRlciwgY2IuYmluZChwdWJsaWNUaGlzKSwgb3B0aW9ucyk7XG4gIHJlc2V0KCk7XG4gIHJldHVybiByZXM7XG59XG5mdW5jdGlvbiBjcmVhdGVQYXRoR2V0dGVyKGN0eCwgcGF0aCkge1xuICBjb25zdCBzZWdtZW50cyA9IHBhdGguc3BsaXQoXCIuXCIpO1xuICByZXR1cm4gKCkgPT4ge1xuICAgIGxldCBjdXIgPSBjdHg7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzZWdtZW50cy5sZW5ndGggJiYgY3VyOyBpKyspIHtcbiAgICAgIGN1ciA9IGN1cltzZWdtZW50c1tpXV07XG4gICAgfVxuICAgIHJldHVybiBjdXI7XG4gIH07XG59XG5cbmNvbnN0IHBlbmRpbmdNb3VudHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbmNvbnN0IFRlbGVwb3J0RW5kS2V5ID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcIl92dGVcIik7XG5jb25zdCBpc1RlbGVwb3J0ID0gKHR5cGUpID0+IHR5cGUuX19pc1RlbGVwb3J0O1xuY29uc3QgaXNUZWxlcG9ydERpc2FibGVkID0gKHByb3BzKSA9PiBwcm9wcyAmJiAocHJvcHMuZGlzYWJsZWQgfHwgcHJvcHMuZGlzYWJsZWQgPT09IFwiXCIpO1xuY29uc3QgaXNUZWxlcG9ydERlZmVycmVkID0gKHByb3BzKSA9PiBwcm9wcyAmJiAocHJvcHMuZGVmZXIgfHwgcHJvcHMuZGVmZXIgPT09IFwiXCIpO1xuY29uc3QgaXNUYXJnZXRTVkcgPSAodGFyZ2V0KSA9PiB0eXBlb2YgU1ZHRWxlbWVudCAhPT0gXCJ1bmRlZmluZWRcIiAmJiB0YXJnZXQgaW5zdGFuY2VvZiBTVkdFbGVtZW50O1xuY29uc3QgaXNUYXJnZXRNYXRoTUwgPSAodGFyZ2V0KSA9PiB0eXBlb2YgTWF0aE1MRWxlbWVudCA9PT0gXCJmdW5jdGlvblwiICYmIHRhcmdldCBpbnN0YW5jZW9mIE1hdGhNTEVsZW1lbnQ7XG5jb25zdCByZXNvbHZlVGFyZ2V0ID0gKHByb3BzLCBzZWxlY3QpID0+IHtcbiAgY29uc3QgdGFyZ2V0U2VsZWN0b3IgPSBwcm9wcyAmJiBwcm9wcy50bztcbiAgaWYgKGlzU3RyaW5nKHRhcmdldFNlbGVjdG9yKSkge1xuICAgIGlmICghc2VsZWN0KSB7XG4gICAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdhcm4kMShcbiAgICAgICAgYEN1cnJlbnQgcmVuZGVyZXIgZG9lcyBub3Qgc3VwcG9ydCBzdHJpbmcgdGFyZ2V0IGZvciBUZWxlcG9ydHMuIChtaXNzaW5nIHF1ZXJ5U2VsZWN0b3IgcmVuZGVyZXIgb3B0aW9uKWBcbiAgICAgICk7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gc2VsZWN0KHRhcmdldFNlbGVjdG9yKTtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICF0YXJnZXQgJiYgIWlzVGVsZXBvcnREaXNhYmxlZChwcm9wcykpIHtcbiAgICAgICAgd2FybiQxKFxuICAgICAgICAgIGBGYWlsZWQgdG8gbG9jYXRlIFRlbGVwb3J0IHRhcmdldCB3aXRoIHNlbGVjdG9yIFwiJHt0YXJnZXRTZWxlY3Rvcn1cIi4gTm90ZSB0aGUgdGFyZ2V0IGVsZW1lbnQgbXVzdCBleGlzdCBiZWZvcmUgdGhlIGNvbXBvbmVudCBpcyBtb3VudGVkIC0gaS5lLiB0aGUgdGFyZ2V0IGNhbm5vdCBiZSByZW5kZXJlZCBieSB0aGUgY29tcG9uZW50IGl0c2VsZiwgYW5kIGlkZWFsbHkgc2hvdWxkIGJlIG91dHNpZGUgb2YgdGhlIGVudGlyZSBWdWUgY29tcG9uZW50IHRyZWUuYFxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRhcmdldDtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIXRhcmdldFNlbGVjdG9yICYmICFpc1RlbGVwb3J0RGlzYWJsZWQocHJvcHMpKSB7XG4gICAgICB3YXJuJDEoYEludmFsaWQgVGVsZXBvcnQgdGFyZ2V0OiAke3RhcmdldFNlbGVjdG9yfWApO1xuICAgIH1cbiAgICByZXR1cm4gdGFyZ2V0U2VsZWN0b3I7XG4gIH1cbn07XG5jb25zdCBUZWxlcG9ydEltcGwgPSB7XG4gIG5hbWU6IFwiVGVsZXBvcnRcIixcbiAgX19pc1RlbGVwb3J0OiB0cnVlLFxuICBwcm9jZXNzKG4xLCBuMiwgY29udGFpbmVyLCBhbmNob3IsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIG5hbWVzcGFjZSwgc2xvdFNjb3BlSWRzLCBvcHRpbWl6ZWQsIGludGVybmFscykge1xuICAgIGNvbnN0IHtcbiAgICAgIG1jOiBtb3VudENoaWxkcmVuLFxuICAgICAgcGM6IHBhdGNoQ2hpbGRyZW4sXG4gICAgICBwYmM6IHBhdGNoQmxvY2tDaGlsZHJlbixcbiAgICAgIG86IHsgaW5zZXJ0LCBxdWVyeVNlbGVjdG9yLCBjcmVhdGVUZXh0LCBjcmVhdGVDb21tZW50LCBwYXJlbnROb2RlIH1cbiAgICB9ID0gaW50ZXJuYWxzO1xuICAgIGNvbnN0IGRpc2FibGVkID0gaXNUZWxlcG9ydERpc2FibGVkKG4yLnByb3BzKTtcbiAgICBsZXQgeyBkeW5hbWljQ2hpbGRyZW4gfSA9IG4yO1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGlzSG1yVXBkYXRpbmcpIHtcbiAgICAgIG9wdGltaXplZCA9IGZhbHNlO1xuICAgICAgZHluYW1pY0NoaWxkcmVuID0gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgbW91bnQgPSAodm5vZGUsIGNvbnRhaW5lcjIsIGFuY2hvcjIpID0+IHtcbiAgICAgIGlmICh2bm9kZS5zaGFwZUZsYWcgJiAxNikge1xuICAgICAgICBtb3VudENoaWxkcmVuKFxuICAgICAgICAgIHZub2RlLmNoaWxkcmVuLFxuICAgICAgICAgIGNvbnRhaW5lcjIsXG4gICAgICAgICAgYW5jaG9yMixcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IG1vdW50VG9UYXJnZXQgPSAodm5vZGUgPSBuMikgPT4ge1xuICAgICAgY29uc3QgZGlzYWJsZWQyID0gaXNUZWxlcG9ydERpc2FibGVkKHZub2RlLnByb3BzKTtcbiAgICAgIGNvbnN0IHRhcmdldCA9IHZub2RlLnRhcmdldCA9IHJlc29sdmVUYXJnZXQodm5vZGUucHJvcHMsIHF1ZXJ5U2VsZWN0b3IpO1xuICAgICAgY29uc3QgdGFyZ2V0QW5jaG9yID0gcHJlcGFyZUFuY2hvcih0YXJnZXQsIHZub2RlLCBjcmVhdGVUZXh0LCBpbnNlcnQpO1xuICAgICAgaWYgKHRhcmdldCkge1xuICAgICAgICBpZiAobmFtZXNwYWNlICE9PSBcInN2Z1wiICYmIGlzVGFyZ2V0U1ZHKHRhcmdldCkpIHtcbiAgICAgICAgICBuYW1lc3BhY2UgPSBcInN2Z1wiO1xuICAgICAgICB9IGVsc2UgaWYgKG5hbWVzcGFjZSAhPT0gXCJtYXRobWxcIiAmJiBpc1RhcmdldE1hdGhNTCh0YXJnZXQpKSB7XG4gICAgICAgICAgbmFtZXNwYWNlID0gXCJtYXRobWxcIjtcbiAgICAgICAgfVxuICAgICAgICBpZiAocGFyZW50Q29tcG9uZW50ICYmIHBhcmVudENvbXBvbmVudC5pc0NFKSB7XG4gICAgICAgICAgKHBhcmVudENvbXBvbmVudC5jZS5fdGVsZXBvcnRUYXJnZXRzIHx8IChwYXJlbnRDb21wb25lbnQuY2UuX3RlbGVwb3J0VGFyZ2V0cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCkpKS5hZGQodGFyZ2V0KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWRpc2FibGVkMikge1xuICAgICAgICAgIG1vdW50KHZub2RlLCB0YXJnZXQsIHRhcmdldEFuY2hvcik7XG4gICAgICAgICAgdXBkYXRlQ3NzVmFycyh2bm9kZSwgZmFsc2UpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWRpc2FibGVkMikge1xuICAgICAgICB3YXJuJDEoXCJJbnZhbGlkIFRlbGVwb3J0IHRhcmdldCBvbiBtb3VudDpcIiwgdGFyZ2V0LCBgKCR7dHlwZW9mIHRhcmdldH0pYCk7XG4gICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBxdWV1ZVBlbmRpbmdNb3VudCA9ICh2bm9kZSkgPT4ge1xuICAgICAgY29uc3QgbW91bnRKb2IgPSAoKSA9PiB7XG4gICAgICAgIGlmIChwZW5kaW5nTW91bnRzLmdldCh2bm9kZSkgIT09IG1vdW50Sm9iKSByZXR1cm47XG4gICAgICAgIHBlbmRpbmdNb3VudHMuZGVsZXRlKHZub2RlKTtcbiAgICAgICAgaWYgKGlzVGVsZXBvcnREaXNhYmxlZCh2bm9kZS5wcm9wcykpIHtcbiAgICAgICAgICBjb25zdCBtb3VudENvbnRhaW5lciA9IHBhcmVudE5vZGUodm5vZGUuZWwpIHx8IGNvbnRhaW5lcjtcbiAgICAgICAgICBtb3VudCh2bm9kZSwgbW91bnRDb250YWluZXIsIHZub2RlLmFuY2hvcik7XG4gICAgICAgICAgdXBkYXRlQ3NzVmFycyh2bm9kZSwgdHJ1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgbW91bnRUb1RhcmdldCh2bm9kZSk7XG4gICAgICB9O1xuICAgICAgcGVuZGluZ01vdW50cy5zZXQodm5vZGUsIG1vdW50Sm9iKTtcbiAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdChtb3VudEpvYiwgcGFyZW50U3VzcGVuc2UpO1xuICAgIH07XG4gICAgaWYgKG4xID09IG51bGwpIHtcbiAgICAgIGNvbnN0IHBsYWNlaG9sZGVyID0gbjIuZWwgPSAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gY3JlYXRlQ29tbWVudChcInRlbGVwb3J0IHN0YXJ0XCIpIDogY3JlYXRlVGV4dChcIlwiKTtcbiAgICAgIGNvbnN0IG1haW5BbmNob3IgPSBuMi5hbmNob3IgPSAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gY3JlYXRlQ29tbWVudChcInRlbGVwb3J0IGVuZFwiKSA6IGNyZWF0ZVRleHQoXCJcIik7XG4gICAgICBpbnNlcnQocGxhY2Vob2xkZXIsIGNvbnRhaW5lciwgYW5jaG9yKTtcbiAgICAgIGluc2VydChtYWluQW5jaG9yLCBjb250YWluZXIsIGFuY2hvcik7XG4gICAgICBpZiAoaXNUZWxlcG9ydERlZmVycmVkKG4yLnByb3BzKSB8fCBwYXJlbnRTdXNwZW5zZSAmJiBwYXJlbnRTdXNwZW5zZS5wZW5kaW5nQnJhbmNoKSB7XG4gICAgICAgIHF1ZXVlUGVuZGluZ01vdW50KG4yKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICAgIG1vdW50KG4yLCBjb250YWluZXIsIG1haW5BbmNob3IpO1xuICAgICAgICB1cGRhdGVDc3NWYXJzKG4yLCB0cnVlKTtcbiAgICAgIH1cbiAgICAgIG1vdW50VG9UYXJnZXQoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgbjIuZWwgPSBuMS5lbDtcbiAgICAgIGNvbnN0IG1haW5BbmNob3IgPSBuMi5hbmNob3IgPSBuMS5hbmNob3I7XG4gICAgICBjb25zdCBwZW5kaW5nTW91bnQgPSBwZW5kaW5nTW91bnRzLmdldChuMSk7XG4gICAgICBpZiAocGVuZGluZ01vdW50KSB7XG4gICAgICAgIHBlbmRpbmdNb3VudC5mbGFncyB8PSA4O1xuICAgICAgICBwZW5kaW5nTW91bnRzLmRlbGV0ZShuMSk7XG4gICAgICAgIHF1ZXVlUGVuZGluZ01vdW50KG4yKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgbjIudGFyZ2V0U3RhcnQgPSBuMS50YXJnZXRTdGFydDtcbiAgICAgIGNvbnN0IHRhcmdldCA9IG4yLnRhcmdldCA9IG4xLnRhcmdldDtcbiAgICAgIGNvbnN0IHRhcmdldEFuY2hvciA9IG4yLnRhcmdldEFuY2hvciA9IG4xLnRhcmdldEFuY2hvcjtcbiAgICAgIGNvbnN0IHdhc0Rpc2FibGVkID0gaXNUZWxlcG9ydERpc2FibGVkKG4xLnByb3BzKTtcbiAgICAgIGNvbnN0IGN1cnJlbnRDb250YWluZXIgPSB3YXNEaXNhYmxlZCA/IGNvbnRhaW5lciA6IHRhcmdldDtcbiAgICAgIGNvbnN0IGN1cnJlbnRBbmNob3IgPSB3YXNEaXNhYmxlZCA/IG1haW5BbmNob3IgOiB0YXJnZXRBbmNob3I7XG4gICAgICBpZiAobmFtZXNwYWNlID09PSBcInN2Z1wiIHx8IGlzVGFyZ2V0U1ZHKHRhcmdldCkpIHtcbiAgICAgICAgbmFtZXNwYWNlID0gXCJzdmdcIjtcbiAgICAgIH0gZWxzZSBpZiAobmFtZXNwYWNlID09PSBcIm1hdGhtbFwiIHx8IGlzVGFyZ2V0TWF0aE1MKHRhcmdldCkpIHtcbiAgICAgICAgbmFtZXNwYWNlID0gXCJtYXRobWxcIjtcbiAgICAgIH1cbiAgICAgIGlmIChkeW5hbWljQ2hpbGRyZW4pIHtcbiAgICAgICAgcGF0Y2hCbG9ja0NoaWxkcmVuKFxuICAgICAgICAgIG4xLmR5bmFtaWNDaGlsZHJlbixcbiAgICAgICAgICBkeW5hbWljQ2hpbGRyZW4sXG4gICAgICAgICAgY3VycmVudENvbnRhaW5lcixcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgIHNsb3RTY29wZUlkc1xuICAgICAgICApO1xuICAgICAgICB0cmF2ZXJzZVN0YXRpY0NoaWxkcmVuKG4xLCBuMiwgISEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpO1xuICAgICAgfSBlbHNlIGlmICghb3B0aW1pemVkKSB7XG4gICAgICAgIHBhdGNoQ2hpbGRyZW4oXG4gICAgICAgICAgbjEsXG4gICAgICAgICAgbjIsXG4gICAgICAgICAgY3VycmVudENvbnRhaW5lcixcbiAgICAgICAgICBjdXJyZW50QW5jaG9yLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgIGZhbHNlXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgaWYgKCF3YXNEaXNhYmxlZCkge1xuICAgICAgICAgIG1vdmVUZWxlcG9ydChcbiAgICAgICAgICAgIG4yLFxuICAgICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgICAgbWFpbkFuY2hvcixcbiAgICAgICAgICAgIGludGVybmFscyxcbiAgICAgICAgICAgIDFcbiAgICAgICAgICApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGlmIChuMi5wcm9wcyAmJiBuMS5wcm9wcyAmJiBuMi5wcm9wcy50byAhPT0gbjEucHJvcHMudG8pIHtcbiAgICAgICAgICAgIG4yLnByb3BzLnRvID0gbjEucHJvcHMudG87XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAoKG4yLnByb3BzICYmIG4yLnByb3BzLnRvKSAhPT0gKG4xLnByb3BzICYmIG4xLnByb3BzLnRvKSkge1xuICAgICAgICAgIGNvbnN0IG5leHRUYXJnZXQgPSByZXNvbHZlVGFyZ2V0KG4yLnByb3BzLCBxdWVyeVNlbGVjdG9yKTtcbiAgICAgICAgICBpZiAobmV4dFRhcmdldCkge1xuICAgICAgICAgICAgbjIudGFyZ2V0ID0gbmV4dFRhcmdldDtcbiAgICAgICAgICAgIG1vdmVUZWxlcG9ydChcbiAgICAgICAgICAgICAgbjIsXG4gICAgICAgICAgICAgIG5leHRUYXJnZXQsXG4gICAgICAgICAgICAgIG51bGwsXG4gICAgICAgICAgICAgIGludGVybmFscyxcbiAgICAgICAgICAgICAgMFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICAgIHdhcm4kMShcbiAgICAgICAgICAgICAgXCJJbnZhbGlkIFRlbGVwb3J0IHRhcmdldCBvbiB1cGRhdGU6XCIsXG4gICAgICAgICAgICAgIHRhcmdldCxcbiAgICAgICAgICAgICAgYCgke3R5cGVvZiB0YXJnZXR9KWBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKHdhc0Rpc2FibGVkKSB7XG4gICAgICAgICAgbW92ZVRlbGVwb3J0KFxuICAgICAgICAgICAgbjIsXG4gICAgICAgICAgICB0YXJnZXQsXG4gICAgICAgICAgICB0YXJnZXRBbmNob3IsXG4gICAgICAgICAgICBpbnRlcm5hbHMsXG4gICAgICAgICAgICAxXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgdXBkYXRlQ3NzVmFycyhuMiwgZGlzYWJsZWQpO1xuICAgIH1cbiAgfSxcbiAgcmVtb3ZlKHZub2RlLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCB7IHVtOiB1bm1vdW50LCBvOiB7IHJlbW92ZTogaG9zdFJlbW92ZSB9IH0sIGRvUmVtb3ZlKSB7XG4gICAgY29uc3Qge1xuICAgICAgc2hhcGVGbGFnLFxuICAgICAgY2hpbGRyZW4sXG4gICAgICBhbmNob3IsXG4gICAgICB0YXJnZXRTdGFydCxcbiAgICAgIHRhcmdldEFuY2hvcixcbiAgICAgIHRhcmdldCxcbiAgICAgIHByb3BzXG4gICAgfSA9IHZub2RlO1xuICAgIGNvbnN0IGRpc2FibGVkID0gaXNUZWxlcG9ydERpc2FibGVkKHByb3BzKTtcbiAgICBjb25zdCBzaG91bGRSZW1vdmUgPSBkb1JlbW92ZSB8fCAhZGlzYWJsZWQ7XG4gICAgY29uc3QgcGVuZGluZ01vdW50ID0gcGVuZGluZ01vdW50cy5nZXQodm5vZGUpO1xuICAgIGlmIChwZW5kaW5nTW91bnQpIHtcbiAgICAgIHBlbmRpbmdNb3VudC5mbGFncyB8PSA4O1xuICAgICAgcGVuZGluZ01vdW50cy5kZWxldGUodm5vZGUpO1xuICAgIH1cbiAgICBpZiAodGFyZ2V0KSB7XG4gICAgICBob3N0UmVtb3ZlKHRhcmdldFN0YXJ0KTtcbiAgICAgIGhvc3RSZW1vdmUodGFyZ2V0QW5jaG9yKTtcbiAgICB9XG4gICAgZG9SZW1vdmUgJiYgaG9zdFJlbW92ZShhbmNob3IpO1xuICAgIGlmICghcGVuZGluZ01vdW50ICYmIChkaXNhYmxlZCB8fCB0YXJnZXQpICYmIHNoYXBlRmxhZyAmIDE2KSB7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IGNoaWxkID0gY2hpbGRyZW5baV07XG4gICAgICAgIHVubW91bnQoXG4gICAgICAgICAgY2hpbGQsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgIHNob3VsZFJlbW92ZSxcbiAgICAgICAgICAhIWNoaWxkLmR5bmFtaWNDaGlsZHJlblxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfSxcbiAgbW92ZTogbW92ZVRlbGVwb3J0LFxuICBoeWRyYXRlOiBoeWRyYXRlVGVsZXBvcnRcbn07XG5mdW5jdGlvbiBtb3ZlVGVsZXBvcnQodm5vZGUsIGNvbnRhaW5lciwgcGFyZW50QW5jaG9yLCB7IG86IHsgaW5zZXJ0IH0sIG06IG1vdmUgfSwgbW92ZVR5cGUgPSAyKSB7XG4gIGlmIChtb3ZlVHlwZSA9PT0gMCkge1xuICAgIGluc2VydCh2bm9kZS50YXJnZXRBbmNob3IsIGNvbnRhaW5lciwgcGFyZW50QW5jaG9yKTtcbiAgfVxuICBjb25zdCB7IGVsLCBhbmNob3IsIHNoYXBlRmxhZywgY2hpbGRyZW4sIHByb3BzIH0gPSB2bm9kZTtcbiAgY29uc3QgaXNSZW9yZGVyID0gbW92ZVR5cGUgPT09IDI7XG4gIGlmIChpc1Jlb3JkZXIpIHtcbiAgICBpbnNlcnQoZWwsIGNvbnRhaW5lciwgcGFyZW50QW5jaG9yKTtcbiAgfVxuICBpZiAoIXBlbmRpbmdNb3VudHMuaGFzKHZub2RlKSAmJiAoIWlzUmVvcmRlciB8fCBpc1RlbGVwb3J0RGlzYWJsZWQocHJvcHMpKSkge1xuICAgIGlmIChzaGFwZUZsYWcgJiAxNikge1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgICAgICBtb3ZlKFxuICAgICAgICAgIGNoaWxkcmVuW2ldLFxuICAgICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgICBwYXJlbnRBbmNob3IsXG4gICAgICAgICAgMlxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBpZiAoaXNSZW9yZGVyKSB7XG4gICAgaW5zZXJ0KGFuY2hvciwgY29udGFpbmVyLCBwYXJlbnRBbmNob3IpO1xuICB9XG59XG5mdW5jdGlvbiBoeWRyYXRlVGVsZXBvcnQobm9kZSwgdm5vZGUsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIHNsb3RTY29wZUlkcywgb3B0aW1pemVkLCB7XG4gIG86IHsgbmV4dFNpYmxpbmcsIHBhcmVudE5vZGUsIHF1ZXJ5U2VsZWN0b3IsIGluc2VydCwgY3JlYXRlVGV4dCB9XG59LCBoeWRyYXRlQ2hpbGRyZW4pIHtcbiAgZnVuY3Rpb24gaHlkcmF0ZUFuY2hvcih0YXJnZXQyLCB0YXJnZXROb2RlKSB7XG4gICAgbGV0IHRhcmdldEFuY2hvciA9IHRhcmdldE5vZGU7XG4gICAgd2hpbGUgKHRhcmdldEFuY2hvcikge1xuICAgICAgaWYgKHRhcmdldEFuY2hvciAmJiB0YXJnZXRBbmNob3Iubm9kZVR5cGUgPT09IDgpIHtcbiAgICAgICAgaWYgKHRhcmdldEFuY2hvci5kYXRhID09PSBcInRlbGVwb3J0IHN0YXJ0IGFuY2hvclwiKSB7XG4gICAgICAgICAgdm5vZGUudGFyZ2V0U3RhcnQgPSB0YXJnZXRBbmNob3I7XG4gICAgICAgIH0gZWxzZSBpZiAodGFyZ2V0QW5jaG9yLmRhdGEgPT09IFwidGVsZXBvcnQgYW5jaG9yXCIpIHtcbiAgICAgICAgICB2bm9kZS50YXJnZXRBbmNob3IgPSB0YXJnZXRBbmNob3I7XG4gICAgICAgICAgdGFyZ2V0Mi5fbHBhID0gdm5vZGUudGFyZ2V0QW5jaG9yICYmIG5leHRTaWJsaW5nKHZub2RlLnRhcmdldEFuY2hvcik7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRhcmdldEFuY2hvciA9IG5leHRTaWJsaW5nKHRhcmdldEFuY2hvcik7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIGh5ZHJhdGVEaXNhYmxlZFRlbGVwb3J0KG5vZGUyLCB2bm9kZTIpIHtcbiAgICB2bm9kZTIuYW5jaG9yID0gaHlkcmF0ZUNoaWxkcmVuKFxuICAgICAgbmV4dFNpYmxpbmcobm9kZTIpLFxuICAgICAgdm5vZGUyLFxuICAgICAgcGFyZW50Tm9kZShub2RlMiksXG4gICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgIG9wdGltaXplZFxuICAgICk7XG4gIH1cbiAgY29uc3QgdGFyZ2V0ID0gdm5vZGUudGFyZ2V0ID0gcmVzb2x2ZVRhcmdldChcbiAgICB2bm9kZS5wcm9wcyxcbiAgICBxdWVyeVNlbGVjdG9yXG4gICk7XG4gIGNvbnN0IGRpc2FibGVkID0gaXNUZWxlcG9ydERpc2FibGVkKHZub2RlLnByb3BzKTtcbiAgaWYgKHRhcmdldCkge1xuICAgIGNvbnN0IHRhcmdldE5vZGUgPSB0YXJnZXQuX2xwYSB8fCB0YXJnZXQuZmlyc3RDaGlsZDtcbiAgICBpZiAodm5vZGUuc2hhcGVGbGFnICYgMTYpIHtcbiAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICBoeWRyYXRlRGlzYWJsZWRUZWxlcG9ydChub2RlLCB2bm9kZSk7XG4gICAgICAgIGh5ZHJhdGVBbmNob3IodGFyZ2V0LCB0YXJnZXROb2RlKTtcbiAgICAgICAgaWYgKCF2bm9kZS50YXJnZXRBbmNob3IpIHtcbiAgICAgICAgICBwcmVwYXJlQW5jaG9yKFxuICAgICAgICAgICAgdGFyZ2V0LFxuICAgICAgICAgICAgdm5vZGUsXG4gICAgICAgICAgICBjcmVhdGVUZXh0LFxuICAgICAgICAgICAgaW5zZXJ0LFxuICAgICAgICAgICAgLy8gaWYgdGFyZ2V0IGlzIHRoZSBzYW1lIGFzIHRoZSBtYWluIHZpZXcsIGluc2VydCBhbmNob3JzIGJlZm9yZSBjdXJyZW50IG5vZGVcbiAgICAgICAgICAgIC8vIHRvIGF2b2lkIGh5ZHJhdGluZyBtaXNtYXRjaFxuICAgICAgICAgICAgcGFyZW50Tm9kZShub2RlKSA9PT0gdGFyZ2V0ID8gbm9kZSA6IG51bGxcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2bm9kZS5hbmNob3IgPSBuZXh0U2libGluZyhub2RlKTtcbiAgICAgICAgaHlkcmF0ZUFuY2hvcih0YXJnZXQsIHRhcmdldE5vZGUpO1xuICAgICAgICBpZiAoIXZub2RlLnRhcmdldEFuY2hvcikge1xuICAgICAgICAgIHByZXBhcmVBbmNob3IodGFyZ2V0LCB2bm9kZSwgY3JlYXRlVGV4dCwgaW5zZXJ0KTtcbiAgICAgICAgfVxuICAgICAgICBoeWRyYXRlQ2hpbGRyZW4oXG4gICAgICAgICAgdGFyZ2V0Tm9kZSAmJiBuZXh0U2libGluZyh0YXJnZXROb2RlKSxcbiAgICAgICAgICB2bm9kZSxcbiAgICAgICAgICB0YXJnZXQsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdXBkYXRlQ3NzVmFycyh2bm9kZSwgZGlzYWJsZWQpO1xuICB9IGVsc2UgaWYgKGRpc2FibGVkKSB7XG4gICAgaWYgKHZub2RlLnNoYXBlRmxhZyAmIDE2KSB7XG4gICAgICBoeWRyYXRlRGlzYWJsZWRUZWxlcG9ydChub2RlLCB2bm9kZSk7XG4gICAgICB2bm9kZS50YXJnZXRTdGFydCA9IG5vZGU7XG4gICAgICB2bm9kZS50YXJnZXRBbmNob3IgPSBuZXh0U2libGluZyhub2RlKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHZub2RlLmFuY2hvciAmJiBuZXh0U2libGluZyh2bm9kZS5hbmNob3IpO1xufVxuY29uc3QgVGVsZXBvcnQgPSBUZWxlcG9ydEltcGw7XG5mdW5jdGlvbiB1cGRhdGVDc3NWYXJzKHZub2RlLCBpc0Rpc2FibGVkKSB7XG4gIGNvbnN0IGN0eCA9IHZub2RlLmN0eDtcbiAgaWYgKGN0eCAmJiBjdHgudXQpIHtcbiAgICBsZXQgbm9kZSwgYW5jaG9yO1xuICAgIGlmIChpc0Rpc2FibGVkKSB7XG4gICAgICBub2RlID0gdm5vZGUuZWw7XG4gICAgICBhbmNob3IgPSB2bm9kZS5hbmNob3I7XG4gICAgfSBlbHNlIHtcbiAgICAgIG5vZGUgPSB2bm9kZS50YXJnZXRTdGFydDtcbiAgICAgIGFuY2hvciA9IHZub2RlLnRhcmdldEFuY2hvcjtcbiAgICB9XG4gICAgd2hpbGUgKG5vZGUgJiYgbm9kZSAhPT0gYW5jaG9yKSB7XG4gICAgICBpZiAobm9kZS5ub2RlVHlwZSA9PT0gMSkgbm9kZS5zZXRBdHRyaWJ1dGUoXCJkYXRhLXYtb3duZXJcIiwgY3R4LnVpZCk7XG4gICAgICBub2RlID0gbm9kZS5uZXh0U2libGluZztcbiAgICB9XG4gICAgY3R4LnV0KCk7XG4gIH1cbn1cbmZ1bmN0aW9uIHByZXBhcmVBbmNob3IodGFyZ2V0LCB2bm9kZSwgY3JlYXRlVGV4dCwgaW5zZXJ0LCBhbmNob3IgPSBudWxsKSB7XG4gIGNvbnN0IHRhcmdldFN0YXJ0ID0gdm5vZGUudGFyZ2V0U3RhcnQgPSBjcmVhdGVUZXh0KFwiXCIpO1xuICBjb25zdCB0YXJnZXRBbmNob3IgPSB2bm9kZS50YXJnZXRBbmNob3IgPSBjcmVhdGVUZXh0KFwiXCIpO1xuICB0YXJnZXRTdGFydFtUZWxlcG9ydEVuZEtleV0gPSB0YXJnZXRBbmNob3I7XG4gIGlmICh0YXJnZXQpIHtcbiAgICBpbnNlcnQodGFyZ2V0U3RhcnQsIHRhcmdldCwgYW5jaG9yKTtcbiAgICBpbnNlcnQodGFyZ2V0QW5jaG9yLCB0YXJnZXQsIGFuY2hvcik7XG4gIH1cbiAgcmV0dXJuIHRhcmdldEFuY2hvcjtcbn1cblxuY29uc3QgbGVhdmVDYktleSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJfbGVhdmVDYlwiKTtcbmNvbnN0IGVudGVyQ2JLZXkgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sKFwiX2VudGVyQ2JcIik7XG5mdW5jdGlvbiB1c2VUcmFuc2l0aW9uU3RhdGUoKSB7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIGlzTW91bnRlZDogZmFsc2UsXG4gICAgaXNMZWF2aW5nOiBmYWxzZSxcbiAgICBpc1VubW91bnRpbmc6IGZhbHNlLFxuICAgIGxlYXZpbmdWTm9kZXM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKClcbiAgfTtcbiAgb25Nb3VudGVkKCgpID0+IHtcbiAgICBzdGF0ZS5pc01vdW50ZWQgPSB0cnVlO1xuICB9KTtcbiAgb25CZWZvcmVVbm1vdW50KCgpID0+IHtcbiAgICBzdGF0ZS5pc1VubW91bnRpbmcgPSB0cnVlO1xuICB9KTtcbiAgcmV0dXJuIHN0YXRlO1xufVxuY29uc3QgVHJhbnNpdGlvbkhvb2tWYWxpZGF0b3IgPSBbRnVuY3Rpb24sIEFycmF5XTtcbmNvbnN0IEJhc2VUcmFuc2l0aW9uUHJvcHNWYWxpZGF0b3JzID0ge1xuICBtb2RlOiBTdHJpbmcsXG4gIGFwcGVhcjogQm9vbGVhbixcbiAgcGVyc2lzdGVkOiBCb29sZWFuLFxuICAvLyBlbnRlclxuICBvbkJlZm9yZUVudGVyOiBUcmFuc2l0aW9uSG9va1ZhbGlkYXRvcixcbiAgb25FbnRlcjogVHJhbnNpdGlvbkhvb2tWYWxpZGF0b3IsXG4gIG9uQWZ0ZXJFbnRlcjogVHJhbnNpdGlvbkhvb2tWYWxpZGF0b3IsXG4gIG9uRW50ZXJDYW5jZWxsZWQ6IFRyYW5zaXRpb25Ib29rVmFsaWRhdG9yLFxuICAvLyBsZWF2ZVxuICBvbkJlZm9yZUxlYXZlOiBUcmFuc2l0aW9uSG9va1ZhbGlkYXRvcixcbiAgb25MZWF2ZTogVHJhbnNpdGlvbkhvb2tWYWxpZGF0b3IsXG4gIG9uQWZ0ZXJMZWF2ZTogVHJhbnNpdGlvbkhvb2tWYWxpZGF0b3IsXG4gIG9uTGVhdmVDYW5jZWxsZWQ6IFRyYW5zaXRpb25Ib29rVmFsaWRhdG9yLFxuICAvLyBhcHBlYXJcbiAgb25CZWZvcmVBcHBlYXI6IFRyYW5zaXRpb25Ib29rVmFsaWRhdG9yLFxuICBvbkFwcGVhcjogVHJhbnNpdGlvbkhvb2tWYWxpZGF0b3IsXG4gIG9uQWZ0ZXJBcHBlYXI6IFRyYW5zaXRpb25Ib29rVmFsaWRhdG9yLFxuICBvbkFwcGVhckNhbmNlbGxlZDogVHJhbnNpdGlvbkhvb2tWYWxpZGF0b3Jcbn07XG5jb25zdCByZWN1cnNpdmVHZXRTdWJ0cmVlID0gKGluc3RhbmNlKSA9PiB7XG4gIGNvbnN0IHN1YlRyZWUgPSBpbnN0YW5jZS5zdWJUcmVlO1xuICByZXR1cm4gc3ViVHJlZS5jb21wb25lbnQgPyByZWN1cnNpdmVHZXRTdWJ0cmVlKHN1YlRyZWUuY29tcG9uZW50KSA6IHN1YlRyZWU7XG59O1xuY29uc3QgQmFzZVRyYW5zaXRpb25JbXBsID0ge1xuICBuYW1lOiBgQmFzZVRyYW5zaXRpb25gLFxuICBwcm9wczogQmFzZVRyYW5zaXRpb25Qcm9wc1ZhbGlkYXRvcnMsXG4gIHNldHVwKHByb3BzLCB7IHNsb3RzIH0pIHtcbiAgICBjb25zdCBpbnN0YW5jZSA9IGdldEN1cnJlbnRJbnN0YW5jZSgpO1xuICAgIGNvbnN0IHN0YXRlID0gdXNlVHJhbnNpdGlvblN0YXRlKCk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGNvbnN0IGNoaWxkcmVuID0gc2xvdHMuZGVmYXVsdCAmJiBnZXRUcmFuc2l0aW9uUmF3Q2hpbGRyZW4oc2xvdHMuZGVmYXVsdCgpLCB0cnVlKTtcbiAgICAgIGNvbnN0IGNoaWxkID0gY2hpbGRyZW4gJiYgY2hpbGRyZW4ubGVuZ3RoID8gZmluZE5vbkNvbW1lbnRDaGlsZChjaGlsZHJlbikgOiAoXG4gICAgICAgIC8vIEtlZXAgZXhwbGljaXQgZGVmYXVsdC1zbG90IGNvbmRpdGlvbmFscyBvbiB0aGUgc2FtZSB0cmFuc2l0aW9uIHBhdGhcbiAgICAgICAgLy8gYXMgcmVndWxhciB2LWlmIGJyYW5jaGVzLCB3aGljaCByZW5kZXIgYSBjb21tZW50IHBsYWNlaG9sZGVyLlxuICAgICAgICBpbnN0YW5jZS5zdWJUcmVlID8gY3JlYXRlQ29tbWVudFZOb2RlKCkgOiB2b2lkIDBcbiAgICAgICk7XG4gICAgICBpZiAoIWNoaWxkKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHJhd1Byb3BzID0gdG9SYXcocHJvcHMpO1xuICAgICAgY29uc3QgeyBtb2RlIH0gPSByYXdQcm9wcztcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIG1vZGUgJiYgbW9kZSAhPT0gXCJpbi1vdXRcIiAmJiBtb2RlICE9PSBcIm91dC1pblwiICYmIG1vZGUgIT09IFwiZGVmYXVsdFwiKSB7XG4gICAgICAgIHdhcm4kMShgaW52YWxpZCA8dHJhbnNpdGlvbj4gbW9kZTogJHttb2RlfWApO1xuICAgICAgfVxuICAgICAgaWYgKHN0YXRlLmlzTGVhdmluZykge1xuICAgICAgICByZXR1cm4gZW1wdHlQbGFjZWhvbGRlcihjaGlsZCk7XG4gICAgICB9XG4gICAgICBjb25zdCBpbm5lckNoaWxkID0gZ2V0SW5uZXJDaGlsZCQxKGNoaWxkKTtcbiAgICAgIGlmICghaW5uZXJDaGlsZCkge1xuICAgICAgICByZXR1cm4gZW1wdHlQbGFjZWhvbGRlcihjaGlsZCk7XG4gICAgICB9XG4gICAgICBsZXQgZW50ZXJIb29rcyA9IHJlc29sdmVUcmFuc2l0aW9uSG9va3MoXG4gICAgICAgIGlubmVyQ2hpbGQsXG4gICAgICAgIHJhd1Byb3BzLFxuICAgICAgICBzdGF0ZSxcbiAgICAgICAgaW5zdGFuY2UsXG4gICAgICAgIC8vICMxMTA2MSwgZW5zdXJlIGVudGVySG9va3MgaXMgZnJlc2ggYWZ0ZXIgY2xvbmVcbiAgICAgICAgKGhvb2tzKSA9PiBlbnRlckhvb2tzID0gaG9va3NcbiAgICAgICk7XG4gICAgICBpZiAoaW5uZXJDaGlsZC50eXBlICE9PSBDb21tZW50KSB7XG4gICAgICAgIHNldFRyYW5zaXRpb25Ib29rcyhpbm5lckNoaWxkLCBlbnRlckhvb2tzKTtcbiAgICAgIH1cbiAgICAgIGxldCBvbGRJbm5lckNoaWxkID0gaW5zdGFuY2Uuc3ViVHJlZSAmJiBnZXRJbm5lckNoaWxkJDEoaW5zdGFuY2Uuc3ViVHJlZSk7XG4gICAgICBpZiAob2xkSW5uZXJDaGlsZCAmJiBvbGRJbm5lckNoaWxkLnR5cGUgIT09IENvbW1lbnQgJiYgIWlzU2FtZVZOb2RlVHlwZShvbGRJbm5lckNoaWxkLCBpbm5lckNoaWxkKSAmJiByZWN1cnNpdmVHZXRTdWJ0cmVlKGluc3RhbmNlKS50eXBlICE9PSBDb21tZW50KSB7XG4gICAgICAgIGxldCBsZWF2aW5nSG9va3MgPSByZXNvbHZlVHJhbnNpdGlvbkhvb2tzKFxuICAgICAgICAgIG9sZElubmVyQ2hpbGQsXG4gICAgICAgICAgcmF3UHJvcHMsXG4gICAgICAgICAgc3RhdGUsXG4gICAgICAgICAgaW5zdGFuY2VcbiAgICAgICAgKTtcbiAgICAgICAgc2V0VHJhbnNpdGlvbkhvb2tzKG9sZElubmVyQ2hpbGQsIGxlYXZpbmdIb29rcyk7XG4gICAgICAgIGlmIChtb2RlID09PSBcIm91dC1pblwiICYmIGlubmVyQ2hpbGQudHlwZSAhPT0gQ29tbWVudCkge1xuICAgICAgICAgIHN0YXRlLmlzTGVhdmluZyA9IHRydWU7XG4gICAgICAgICAgbGVhdmluZ0hvb2tzLmFmdGVyTGVhdmUgPSAoKSA9PiB7XG4gICAgICAgICAgICBzdGF0ZS5pc0xlYXZpbmcgPSBmYWxzZTtcbiAgICAgICAgICAgIGlmICghKGluc3RhbmNlLmpvYi5mbGFncyAmIDgpKSB7XG4gICAgICAgICAgICAgIGluc3RhbmNlLnVwZGF0ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZGVsZXRlIGxlYXZpbmdIb29rcy5hZnRlckxlYXZlO1xuICAgICAgICAgICAgb2xkSW5uZXJDaGlsZCA9IHZvaWQgMDtcbiAgICAgICAgICB9O1xuICAgICAgICAgIHJldHVybiBlbXB0eVBsYWNlaG9sZGVyKGNoaWxkKTtcbiAgICAgICAgfSBlbHNlIGlmIChtb2RlID09PSBcImluLW91dFwiICYmIGlubmVyQ2hpbGQudHlwZSAhPT0gQ29tbWVudCkge1xuICAgICAgICAgIGxlYXZpbmdIb29rcy5kZWxheUxlYXZlID0gKGVsLCBlYXJseVJlbW92ZSwgZGVsYXllZExlYXZlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBsZWF2aW5nVk5vZGVzQ2FjaGUgPSBnZXRMZWF2aW5nTm9kZXNGb3JUeXBlKFxuICAgICAgICAgICAgICBzdGF0ZSxcbiAgICAgICAgICAgICAgb2xkSW5uZXJDaGlsZFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGxlYXZpbmdWTm9kZXNDYWNoZVtTdHJpbmcob2xkSW5uZXJDaGlsZC5rZXkpXSA9IG9sZElubmVyQ2hpbGQ7XG4gICAgICAgICAgICBlbFtsZWF2ZUNiS2V5XSA9ICgpID0+IHtcbiAgICAgICAgICAgICAgZWFybHlSZW1vdmUoKTtcbiAgICAgICAgICAgICAgZWxbbGVhdmVDYktleV0gPSB2b2lkIDA7XG4gICAgICAgICAgICAgIGRlbGV0ZSBlbnRlckhvb2tzLmRlbGF5ZWRMZWF2ZTtcbiAgICAgICAgICAgICAgb2xkSW5uZXJDaGlsZCA9IHZvaWQgMDtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBlbnRlckhvb2tzLmRlbGF5ZWRMZWF2ZSA9ICgpID0+IHtcbiAgICAgICAgICAgICAgZGVsYXllZExlYXZlKCk7XG4gICAgICAgICAgICAgIGRlbGV0ZSBlbnRlckhvb2tzLmRlbGF5ZWRMZWF2ZTtcbiAgICAgICAgICAgICAgb2xkSW5uZXJDaGlsZCA9IHZvaWQgMDtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBvbGRJbm5lckNoaWxkID0gdm9pZCAwO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKG9sZElubmVyQ2hpbGQpIHtcbiAgICAgICAgb2xkSW5uZXJDaGlsZCA9IHZvaWQgMDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBjaGlsZDtcbiAgICB9O1xuICB9XG59O1xuZnVuY3Rpb24gZmluZE5vbkNvbW1lbnRDaGlsZChjaGlsZHJlbikge1xuICBsZXQgY2hpbGQgPSBjaGlsZHJlblswXTtcbiAgaWYgKGNoaWxkcmVuLmxlbmd0aCA+IDEpIHtcbiAgICBsZXQgaGFzRm91bmQgPSBmYWxzZTtcbiAgICBmb3IgKGNvbnN0IGMgb2YgY2hpbGRyZW4pIHtcbiAgICAgIGlmIChjLnR5cGUgIT09IENvbW1lbnQpIHtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgaGFzRm91bmQpIHtcbiAgICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgICBcIjx0cmFuc2l0aW9uPiBjYW4gb25seSBiZSB1c2VkIG9uIGEgc2luZ2xlIGVsZW1lbnQgb3IgY29tcG9uZW50LiBVc2UgPHRyYW5zaXRpb24tZ3JvdXA+IGZvciBsaXN0cy5cIlxuICAgICAgICAgICk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgY2hpbGQgPSBjO1xuICAgICAgICBoYXNGb3VuZCA9IHRydWU7XG4gICAgICAgIGlmICghISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBjaGlsZDtcbn1cbmNvbnN0IEJhc2VUcmFuc2l0aW9uID0gQmFzZVRyYW5zaXRpb25JbXBsO1xuZnVuY3Rpb24gZ2V0TGVhdmluZ05vZGVzRm9yVHlwZShzdGF0ZSwgdm5vZGUpIHtcbiAgY29uc3QgeyBsZWF2aW5nVk5vZGVzIH0gPSBzdGF0ZTtcbiAgbGV0IGxlYXZpbmdWTm9kZXNDYWNoZSA9IGxlYXZpbmdWTm9kZXMuZ2V0KHZub2RlLnR5cGUpO1xuICBpZiAoIWxlYXZpbmdWTm9kZXNDYWNoZSkge1xuICAgIGxlYXZpbmdWTm9kZXNDYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgIGxlYXZpbmdWTm9kZXMuc2V0KHZub2RlLnR5cGUsIGxlYXZpbmdWTm9kZXNDYWNoZSk7XG4gIH1cbiAgcmV0dXJuIGxlYXZpbmdWTm9kZXNDYWNoZTtcbn1cbmZ1bmN0aW9uIHJlc29sdmVUcmFuc2l0aW9uSG9va3Modm5vZGUsIHByb3BzLCBzdGF0ZSwgaW5zdGFuY2UsIHBvc3RDbG9uZSkge1xuICBjb25zdCB7XG4gICAgYXBwZWFyLFxuICAgIG1vZGUsXG4gICAgcGVyc2lzdGVkID0gZmFsc2UsXG4gICAgb25CZWZvcmVFbnRlcixcbiAgICBvbkVudGVyLFxuICAgIG9uQWZ0ZXJFbnRlcixcbiAgICBvbkVudGVyQ2FuY2VsbGVkLFxuICAgIG9uQmVmb3JlTGVhdmUsXG4gICAgb25MZWF2ZSxcbiAgICBvbkFmdGVyTGVhdmUsXG4gICAgb25MZWF2ZUNhbmNlbGxlZCxcbiAgICBvbkJlZm9yZUFwcGVhcixcbiAgICBvbkFwcGVhcixcbiAgICBvbkFmdGVyQXBwZWFyLFxuICAgIG9uQXBwZWFyQ2FuY2VsbGVkXG4gIH0gPSBwcm9wcztcbiAgY29uc3Qga2V5ID0gU3RyaW5nKHZub2RlLmtleSk7XG4gIGNvbnN0IGxlYXZpbmdWTm9kZXNDYWNoZSA9IGdldExlYXZpbmdOb2Rlc0ZvclR5cGUoc3RhdGUsIHZub2RlKTtcbiAgY29uc3QgY2FsbEhvb2sgPSAoaG9vaywgYXJncykgPT4ge1xuICAgIGhvb2sgJiYgY2FsbFdpdGhBc3luY0Vycm9ySGFuZGxpbmcoXG4gICAgICBob29rLFxuICAgICAgaW5zdGFuY2UsXG4gICAgICA5LFxuICAgICAgYXJnc1xuICAgICk7XG4gIH07XG4gIGNvbnN0IGNhbGxBc3luY0hvb2sgPSAoaG9vaywgYXJncykgPT4ge1xuICAgIGNvbnN0IGRvbmUgPSBhcmdzWzFdO1xuICAgIGNhbGxIb29rKGhvb2ssIGFyZ3MpO1xuICAgIGlmIChpc0FycmF5KGhvb2spKSB7XG4gICAgICBpZiAoaG9vay5ldmVyeSgoaG9vazIpID0+IGhvb2syLmxlbmd0aCA8PSAxKSkgZG9uZSgpO1xuICAgIH0gZWxzZSBpZiAoaG9vay5sZW5ndGggPD0gMSkge1xuICAgICAgZG9uZSgpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgaG9va3MgPSB7XG4gICAgbW9kZSxcbiAgICBwZXJzaXN0ZWQsXG4gICAgYmVmb3JlRW50ZXIoZWwpIHtcbiAgICAgIGxldCBob29rID0gb25CZWZvcmVFbnRlcjtcbiAgICAgIGlmICghc3RhdGUuaXNNb3VudGVkKSB7XG4gICAgICAgIGlmIChhcHBlYXIpIHtcbiAgICAgICAgICBob29rID0gb25CZWZvcmVBcHBlYXIgfHwgb25CZWZvcmVFbnRlcjtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChlbFtsZWF2ZUNiS2V5XSkge1xuICAgICAgICBlbFtsZWF2ZUNiS2V5XShcbiAgICAgICAgICB0cnVlXG4gICAgICAgICAgLyogY2FuY2VsbGVkICovXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBjb25zdCBsZWF2aW5nVk5vZGUgPSBsZWF2aW5nVk5vZGVzQ2FjaGVba2V5XTtcbiAgICAgIGlmIChsZWF2aW5nVk5vZGUgJiYgaXNTYW1lVk5vZGVUeXBlKHZub2RlLCBsZWF2aW5nVk5vZGUpICYmIGxlYXZpbmdWTm9kZS5lbFtsZWF2ZUNiS2V5XSkge1xuICAgICAgICBsZWF2aW5nVk5vZGUuZWxbbGVhdmVDYktleV0oKTtcbiAgICAgIH1cbiAgICAgIGNhbGxIb29rKGhvb2ssIFtlbF0pO1xuICAgIH0sXG4gICAgZW50ZXIoZWwpIHtcbiAgICAgIGlmICghaXNIbXJVcGRhdGluZyAmJiBsZWF2aW5nVk5vZGVzQ2FjaGVba2V5XSA9PT0gdm5vZGUpIHJldHVybjtcbiAgICAgIGxldCBob29rID0gb25FbnRlcjtcbiAgICAgIGxldCBhZnRlckhvb2sgPSBvbkFmdGVyRW50ZXI7XG4gICAgICBsZXQgY2FuY2VsSG9vayA9IG9uRW50ZXJDYW5jZWxsZWQ7XG4gICAgICBpZiAoIXN0YXRlLmlzTW91bnRlZCkge1xuICAgICAgICBpZiAoYXBwZWFyKSB7XG4gICAgICAgICAgaG9vayA9IG9uQXBwZWFyIHx8IG9uRW50ZXI7XG4gICAgICAgICAgYWZ0ZXJIb29rID0gb25BZnRlckFwcGVhciB8fCBvbkFmdGVyRW50ZXI7XG4gICAgICAgICAgY2FuY2VsSG9vayA9IG9uQXBwZWFyQ2FuY2VsbGVkIHx8IG9uRW50ZXJDYW5jZWxsZWQ7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBsZXQgY2FsbGVkID0gZmFsc2U7XG4gICAgICBlbFtlbnRlckNiS2V5XSA9IChjYW5jZWxsZWQpID0+IHtcbiAgICAgICAgaWYgKGNhbGxlZCkgcmV0dXJuO1xuICAgICAgICBjYWxsZWQgPSB0cnVlO1xuICAgICAgICBpZiAoY2FuY2VsbGVkKSB7XG4gICAgICAgICAgY2FsbEhvb2soY2FuY2VsSG9vaywgW2VsXSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY2FsbEhvb2soYWZ0ZXJIb29rLCBbZWxdKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaG9va3MuZGVsYXllZExlYXZlKSB7XG4gICAgICAgICAgaG9va3MuZGVsYXllZExlYXZlKCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxbZW50ZXJDYktleV0gPSB2b2lkIDA7XG4gICAgICB9O1xuICAgICAgY29uc3QgZG9uZSA9IGVsW2VudGVyQ2JLZXldLmJpbmQobnVsbCwgZmFsc2UpO1xuICAgICAgaWYgKGhvb2spIHtcbiAgICAgICAgY2FsbEFzeW5jSG9vayhob29rLCBbZWwsIGRvbmVdKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGRvbmUoKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIGxlYXZlKGVsLCByZW1vdmUpIHtcbiAgICAgIGNvbnN0IGtleTIgPSBTdHJpbmcodm5vZGUua2V5KTtcbiAgICAgIGlmIChlbFtlbnRlckNiS2V5XSkge1xuICAgICAgICBlbFtlbnRlckNiS2V5XShcbiAgICAgICAgICB0cnVlXG4gICAgICAgICAgLyogY2FuY2VsbGVkICovXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBpZiAoc3RhdGUuaXNVbm1vdW50aW5nKSB7XG4gICAgICAgIHJldHVybiByZW1vdmUoKTtcbiAgICAgIH1cbiAgICAgIGNhbGxIb29rKG9uQmVmb3JlTGVhdmUsIFtlbF0pO1xuICAgICAgbGV0IGNhbGxlZCA9IGZhbHNlO1xuICAgICAgZWxbbGVhdmVDYktleV0gPSAoY2FuY2VsbGVkKSA9PiB7XG4gICAgICAgIGlmIChjYWxsZWQpIHJldHVybjtcbiAgICAgICAgY2FsbGVkID0gdHJ1ZTtcbiAgICAgICAgcmVtb3ZlKCk7XG4gICAgICAgIGlmIChjYW5jZWxsZWQpIHtcbiAgICAgICAgICBjYWxsSG9vayhvbkxlYXZlQ2FuY2VsbGVkLCBbZWxdKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjYWxsSG9vayhvbkFmdGVyTGVhdmUsIFtlbF0pO1xuICAgICAgICB9XG4gICAgICAgIGVsW2xlYXZlQ2JLZXldID0gdm9pZCAwO1xuICAgICAgICBpZiAobGVhdmluZ1ZOb2Rlc0NhY2hlW2tleTJdID09PSB2bm9kZSkge1xuICAgICAgICAgIGRlbGV0ZSBsZWF2aW5nVk5vZGVzQ2FjaGVba2V5Ml07XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICBjb25zdCBkb25lID0gZWxbbGVhdmVDYktleV0uYmluZChudWxsLCBmYWxzZSk7XG4gICAgICBsZWF2aW5nVk5vZGVzQ2FjaGVba2V5Ml0gPSB2bm9kZTtcbiAgICAgIGlmIChvbkxlYXZlKSB7XG4gICAgICAgIGNhbGxBc3luY0hvb2sob25MZWF2ZSwgW2VsLCBkb25lXSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBkb25lKCk7XG4gICAgICB9XG4gICAgfSxcbiAgICBjbG9uZSh2bm9kZTIpIHtcbiAgICAgIGNvbnN0IGhvb2tzMiA9IHJlc29sdmVUcmFuc2l0aW9uSG9va3MoXG4gICAgICAgIHZub2RlMixcbiAgICAgICAgcHJvcHMsXG4gICAgICAgIHN0YXRlLFxuICAgICAgICBpbnN0YW5jZSxcbiAgICAgICAgcG9zdENsb25lXG4gICAgICApO1xuICAgICAgaWYgKHBvc3RDbG9uZSkgcG9zdENsb25lKGhvb2tzMik7XG4gICAgICByZXR1cm4gaG9va3MyO1xuICAgIH1cbiAgfTtcbiAgcmV0dXJuIGhvb2tzO1xufVxuZnVuY3Rpb24gZW1wdHlQbGFjZWhvbGRlcih2bm9kZSkge1xuICBpZiAoaXNLZWVwQWxpdmUodm5vZGUpKSB7XG4gICAgdm5vZGUgPSBjbG9uZVZOb2RlKHZub2RlKTtcbiAgICB2bm9kZS5jaGlsZHJlbiA9IG51bGw7XG4gICAgcmV0dXJuIHZub2RlO1xuICB9XG59XG5mdW5jdGlvbiBnZXRJbm5lckNoaWxkJDEodm5vZGUpIHtcbiAgaWYgKCFpc0tlZXBBbGl2ZSh2bm9kZSkpIHtcbiAgICBpZiAoaXNUZWxlcG9ydCh2bm9kZS50eXBlKSAmJiB2bm9kZS5jaGlsZHJlbikge1xuICAgICAgcmV0dXJuIGZpbmROb25Db21tZW50Q2hpbGQodm5vZGUuY2hpbGRyZW4pO1xuICAgIH1cbiAgICByZXR1cm4gdm5vZGU7XG4gIH1cbiAgaWYgKHZub2RlLmNvbXBvbmVudCkge1xuICAgIHJldHVybiB2bm9kZS5jb21wb25lbnQuc3ViVHJlZTtcbiAgfVxuICBjb25zdCB7IHNoYXBlRmxhZywgY2hpbGRyZW4gfSA9IHZub2RlO1xuICBpZiAoY2hpbGRyZW4pIHtcbiAgICBpZiAoc2hhcGVGbGFnICYgMTYpIHtcbiAgICAgIHJldHVybiBjaGlsZHJlblswXTtcbiAgICB9XG4gICAgaWYgKHNoYXBlRmxhZyAmIDMyICYmIGlzRnVuY3Rpb24oY2hpbGRyZW4uZGVmYXVsdCkpIHtcbiAgICAgIHJldHVybiBjaGlsZHJlbi5kZWZhdWx0KCk7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBzZXRUcmFuc2l0aW9uSG9va3Modm5vZGUsIGhvb2tzKSB7XG4gIGlmICh2bm9kZS5zaGFwZUZsYWcgJiA2ICYmIHZub2RlLmNvbXBvbmVudCkge1xuICAgIHZub2RlLnRyYW5zaXRpb24gPSBob29rcztcbiAgICBzZXRUcmFuc2l0aW9uSG9va3Modm5vZGUuY29tcG9uZW50LnN1YlRyZWUsIGhvb2tzKTtcbiAgfSBlbHNlIGlmICh2bm9kZS5zaGFwZUZsYWcgJiAxMjgpIHtcbiAgICB2bm9kZS5zc0NvbnRlbnQudHJhbnNpdGlvbiA9IGhvb2tzLmNsb25lKHZub2RlLnNzQ29udGVudCk7XG4gICAgdm5vZGUuc3NGYWxsYmFjay50cmFuc2l0aW9uID0gaG9va3MuY2xvbmUodm5vZGUuc3NGYWxsYmFjayk7XG4gIH0gZWxzZSB7XG4gICAgdm5vZGUudHJhbnNpdGlvbiA9IGhvb2tzO1xuICB9XG59XG5mdW5jdGlvbiBnZXRUcmFuc2l0aW9uUmF3Q2hpbGRyZW4oY2hpbGRyZW4sIGtlZXBDb21tZW50ID0gZmFsc2UsIHBhcmVudEtleSkge1xuICBsZXQgcmV0ID0gW107XG4gIGxldCBrZXllZEZyYWdtZW50Q291bnQgPSAwO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgbGV0IGNoaWxkID0gY2hpbGRyZW5baV07XG4gICAgY29uc3Qga2V5ID0gcGFyZW50S2V5ID09IG51bGwgPyBjaGlsZC5rZXkgOiBTdHJpbmcocGFyZW50S2V5KSArIFN0cmluZyhjaGlsZC5rZXkgIT0gbnVsbCA/IGNoaWxkLmtleSA6IGkpO1xuICAgIGlmIChjaGlsZC50eXBlID09PSBGcmFnbWVudCkge1xuICAgICAgaWYgKGNoaWxkLnBhdGNoRmxhZyAmIDEyOCkga2V5ZWRGcmFnbWVudENvdW50Kys7XG4gICAgICByZXQgPSByZXQuY29uY2F0KFxuICAgICAgICBnZXRUcmFuc2l0aW9uUmF3Q2hpbGRyZW4oY2hpbGQuY2hpbGRyZW4sIGtlZXBDb21tZW50LCBrZXkpXG4gICAgICApO1xuICAgIH0gZWxzZSBpZiAoa2VlcENvbW1lbnQgfHwgY2hpbGQudHlwZSAhPT0gQ29tbWVudCkge1xuICAgICAgcmV0LnB1c2goa2V5ICE9IG51bGwgPyBjbG9uZVZOb2RlKGNoaWxkLCB7IGtleSB9KSA6IGNoaWxkKTtcbiAgICB9XG4gIH1cbiAgaWYgKGtleWVkRnJhZ21lbnRDb3VudCA+IDEpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJldC5sZW5ndGg7IGkrKykge1xuICAgICAgcmV0W2ldLnBhdGNoRmxhZyA9IC0yO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcmV0O1xufVxuXG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gZGVmaW5lQ29tcG9uZW50KG9wdGlvbnMsIGV4dHJhT3B0aW9ucykge1xuICByZXR1cm4gaXNGdW5jdGlvbihvcHRpb25zKSA/IChcbiAgICAvLyAjODIzNjogZXh0ZW5kIGNhbGwgYW5kIG9wdGlvbnMubmFtZSBhY2Nlc3MgYXJlIGNvbnNpZGVyZWQgc2lkZS1lZmZlY3RzXG4gICAgLy8gYnkgUm9sbHVwLCBzbyB3ZSBoYXZlIHRvIHdyYXAgaXQgaW4gYSBwdXJlLWFubm90YXRlZCBJSUZFLlxuICAgIC8qIEBfX1BVUkVfXyAqLyAoKCkgPT4gZXh0ZW5kKHsgbmFtZTogb3B0aW9ucy5uYW1lIH0sIGV4dHJhT3B0aW9ucywgeyBzZXR1cDogb3B0aW9ucyB9KSkoKVxuICApIDogb3B0aW9ucztcbn1cblxuZnVuY3Rpb24gdXNlSWQoKSB7XG4gIGNvbnN0IGkgPSBnZXRDdXJyZW50SW5zdGFuY2UoKTtcbiAgaWYgKGkpIHtcbiAgICByZXR1cm4gKGkuYXBwQ29udGV4dC5jb25maWcuaWRQcmVmaXggfHwgXCJ2XCIpICsgXCItXCIgKyBpLmlkc1swXSArIGkuaWRzWzFdKys7XG4gIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIHdhcm4kMShcbiAgICAgIGB1c2VJZCgpIGlzIGNhbGxlZCB3aGVuIHRoZXJlIGlzIG5vIGFjdGl2ZSBjb21wb25lbnQgaW5zdGFuY2UgdG8gYmUgYXNzb2NpYXRlZCB3aXRoLmBcbiAgICApO1xuICB9XG4gIHJldHVybiBcIlwiO1xufVxuZnVuY3Rpb24gbWFya0FzeW5jQm91bmRhcnkoaW5zdGFuY2UpIHtcbiAgaW5zdGFuY2UuaWRzID0gW2luc3RhbmNlLmlkc1swXSArIGluc3RhbmNlLmlkc1syXSsrICsgXCItXCIsIDAsIDBdO1xufVxuXG5jb25zdCBrbm93blRlbXBsYXRlUmVmcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha1NldCgpO1xuZnVuY3Rpb24gdXNlVGVtcGxhdGVSZWYoa2V5KSB7XG4gIGNvbnN0IGkgPSBnZXRDdXJyZW50SW5zdGFuY2UoKTtcbiAgY29uc3QgciA9IHNoYWxsb3dSZWYobnVsbCk7XG4gIGlmIChpKSB7XG4gICAgY29uc3QgcmVmcyA9IGkucmVmcyA9PT0gRU1QVFlfT0JKID8gaS5yZWZzID0ge30gOiBpLnJlZnM7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgaXNUZW1wbGF0ZVJlZktleShyZWZzLCBrZXkpKSB7XG4gICAgICB3YXJuJDEoYHVzZVRlbXBsYXRlUmVmKCcke2tleX0nKSBhbHJlYWR5IGV4aXN0cy5gKTtcbiAgICB9IGVsc2Uge1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHJlZnMsIGtleSwge1xuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBnZXQ6ICgpID0+IHIudmFsdWUsXG4gICAgICAgIHNldDogKHZhbCkgPT4gci52YWx1ZSA9IHZhbFxuICAgICAgfSk7XG4gICAgfVxuICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICB3YXJuJDEoXG4gICAgICBgdXNlVGVtcGxhdGVSZWYoKSBpcyBjYWxsZWQgd2hlbiB0aGVyZSBpcyBubyBhY3RpdmUgY29tcG9uZW50IGluc3RhbmNlIHRvIGJlIGFzc29jaWF0ZWQgd2l0aC5gXG4gICAgKTtcbiAgfVxuICBjb25zdCByZXQgPSAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gcmVhZG9ubHkocikgOiByO1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIGtub3duVGVtcGxhdGVSZWZzLmFkZChyZXQpO1xuICB9XG4gIHJldHVybiByZXQ7XG59XG5mdW5jdGlvbiBpc1RlbXBsYXRlUmVmS2V5KHJlZnMsIGtleSkge1xuICBsZXQgZGVzYztcbiAgcmV0dXJuICEhKChkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihyZWZzLCBrZXkpKSAmJiAhZGVzYy5jb25maWd1cmFibGUpO1xufVxuXG5jb25zdCBwZW5kaW5nU2V0UmVmTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5mdW5jdGlvbiBzZXRSZWYocmF3UmVmLCBvbGRSYXdSZWYsIHBhcmVudFN1c3BlbnNlLCB2bm9kZSwgaXNVbm1vdW50ID0gZmFsc2UpIHtcbiAgaWYgKGlzQXJyYXkocmF3UmVmKSkge1xuICAgIHJhd1JlZi5mb3JFYWNoKFxuICAgICAgKHIsIGkpID0+IHNldFJlZihcbiAgICAgICAgcixcbiAgICAgICAgb2xkUmF3UmVmICYmIChpc0FycmF5KG9sZFJhd1JlZikgPyBvbGRSYXdSZWZbaV0gOiBvbGRSYXdSZWYpLFxuICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgdm5vZGUsXG4gICAgICAgIGlzVW5tb3VudFxuICAgICAgKVxuICAgICk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmIChpc0FzeW5jV3JhcHBlcih2bm9kZSkgJiYgIWlzVW5tb3VudCkge1xuICAgIGlmICh2bm9kZS5zaGFwZUZsYWcgJiA1MTIgJiYgdm5vZGUudHlwZS5fX2FzeW5jUmVzb2x2ZWQgJiYgdm5vZGUuY29tcG9uZW50LnN1YlRyZWUuY29tcG9uZW50KSB7XG4gICAgICBzZXRSZWYocmF3UmVmLCBvbGRSYXdSZWYsIHBhcmVudFN1c3BlbnNlLCB2bm9kZS5jb21wb25lbnQuc3ViVHJlZSk7XG4gICAgfVxuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCByZWZWYWx1ZSA9IHZub2RlLnNoYXBlRmxhZyAmIDQgPyBnZXRDb21wb25lbnRQdWJsaWNJbnN0YW5jZSh2bm9kZS5jb21wb25lbnQpIDogdm5vZGUuZWw7XG4gIGNvbnN0IHZhbHVlID0gaXNVbm1vdW50ID8gbnVsbCA6IHJlZlZhbHVlO1xuICBjb25zdCB7IGk6IG93bmVyLCByOiByZWYgfSA9IHJhd1JlZjtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIW93bmVyKSB7XG4gICAgd2FybiQxKFxuICAgICAgYE1pc3NpbmcgcmVmIG93bmVyIGNvbnRleHQuIHJlZiBjYW5ub3QgYmUgdXNlZCBvbiBob2lzdGVkIHZub2Rlcy4gQSB2bm9kZSB3aXRoIHJlZiBtdXN0IGJlIGNyZWF0ZWQgaW5zaWRlIHRoZSByZW5kZXIgZnVuY3Rpb24uYFxuICAgICk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IG9sZFJlZiA9IG9sZFJhd1JlZiAmJiBvbGRSYXdSZWYucjtcbiAgY29uc3QgcmVmcyA9IG93bmVyLnJlZnMgPT09IEVNUFRZX09CSiA/IG93bmVyLnJlZnMgPSB7fSA6IG93bmVyLnJlZnM7XG4gIGNvbnN0IHNldHVwU3RhdGUgPSBvd25lci5zZXR1cFN0YXRlO1xuICBjb25zdCByYXdTZXR1cFN0YXRlID0gdG9SYXcoc2V0dXBTdGF0ZSk7XG4gIGNvbnN0IGNhblNldFNldHVwUmVmID0gc2V0dXBTdGF0ZSA9PT0gRU1QVFlfT0JKID8gTk8gOiAoa2V5KSA9PiB7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgIGlmIChoYXNPd24ocmF3U2V0dXBTdGF0ZSwga2V5KSAmJiAhaXNSZWYocmF3U2V0dXBTdGF0ZVtrZXldKSkge1xuICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgYFRlbXBsYXRlIHJlZiBcIiR7a2V5fVwiIHVzZWQgb24gYSBub24tcmVmIHZhbHVlLiBJdCB3aWxsIG5vdCB3b3JrIGluIHRoZSBwcm9kdWN0aW9uIGJ1aWxkLmBcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGlmIChrbm93blRlbXBsYXRlUmVmcy5oYXMocmF3U2V0dXBTdGF0ZVtrZXldKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChpc1RlbXBsYXRlUmVmS2V5KHJlZnMsIGtleSkpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuIGhhc093bihyYXdTZXR1cFN0YXRlLCBrZXkpO1xuICB9O1xuICBjb25zdCBjYW5TZXRSZWYgPSAocmVmMiwga2V5KSA9PiB7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYga25vd25UZW1wbGF0ZVJlZnMuaGFzKHJlZjIpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmIChrZXkgJiYgaXNUZW1wbGF0ZVJlZktleShyZWZzLCBrZXkpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9O1xuICBpZiAob2xkUmVmICE9IG51bGwgJiYgb2xkUmVmICE9PSByZWYpIHtcbiAgICBpbnZhbGlkYXRlUGVuZGluZ1NldFJlZihvbGRSYXdSZWYpO1xuICAgIGlmIChpc1N0cmluZyhvbGRSZWYpKSB7XG4gICAgICByZWZzW29sZFJlZl0gPSBudWxsO1xuICAgICAgaWYgKGNhblNldFNldHVwUmVmKG9sZFJlZikpIHtcbiAgICAgICAgc2V0dXBTdGF0ZVtvbGRSZWZdID0gbnVsbDtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKGlzUmVmKG9sZFJlZikpIHtcbiAgICAgIGNvbnN0IG9sZFJhd1JlZkF0b20gPSBvbGRSYXdSZWY7XG4gICAgICBpZiAoY2FuU2V0UmVmKG9sZFJlZiwgb2xkUmF3UmVmQXRvbS5rKSkge1xuICAgICAgICBvbGRSZWYudmFsdWUgPSBudWxsO1xuICAgICAgfVxuICAgICAgaWYgKG9sZFJhd1JlZkF0b20uaykgcmVmc1tvbGRSYXdSZWZBdG9tLmtdID0gbnVsbDtcbiAgICB9XG4gIH1cbiAgaWYgKGlzRnVuY3Rpb24ocmVmKSkge1xuICAgIGNhbGxXaXRoRXJyb3JIYW5kbGluZyhyZWYsIG93bmVyLCAxMiwgW3ZhbHVlLCByZWZzXSk7XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgX2lzU3RyaW5nID0gaXNTdHJpbmcocmVmKTtcbiAgICBjb25zdCBfaXNSZWYgPSBpc1JlZihyZWYpO1xuICAgIGlmIChfaXNTdHJpbmcgfHwgX2lzUmVmKSB7XG4gICAgICBjb25zdCBkb1NldCA9ICgpID0+IHtcbiAgICAgICAgaWYgKHJhd1JlZi5mKSB7XG4gICAgICAgICAgY29uc3QgZXhpc3RpbmcgPSBfaXNTdHJpbmcgPyBjYW5TZXRTZXR1cFJlZihyZWYpID8gc2V0dXBTdGF0ZVtyZWZdIDogcmVmc1tyZWZdIDogY2FuU2V0UmVmKHJlZikgfHwgIXJhd1JlZi5rID8gcmVmLnZhbHVlIDogcmVmc1tyYXdSZWYua107XG4gICAgICAgICAgaWYgKGlzVW5tb3VudCkge1xuICAgICAgICAgICAgaXNBcnJheShleGlzdGluZykgJiYgcmVtb3ZlKGV4aXN0aW5nLCByZWZWYWx1ZSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGlmICghaXNBcnJheShleGlzdGluZykpIHtcbiAgICAgICAgICAgICAgaWYgKF9pc1N0cmluZykge1xuICAgICAgICAgICAgICAgIHJlZnNbcmVmXSA9IFtyZWZWYWx1ZV07XG4gICAgICAgICAgICAgICAgaWYgKGNhblNldFNldHVwUmVmKHJlZikpIHtcbiAgICAgICAgICAgICAgICAgIHNldHVwU3RhdGVbcmVmXSA9IHJlZnNbcmVmXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbmV3VmFsID0gW3JlZlZhbHVlXTtcbiAgICAgICAgICAgICAgICBpZiAoY2FuU2V0UmVmKHJlZiwgcmF3UmVmLmspKSB7XG4gICAgICAgICAgICAgICAgICByZWYudmFsdWUgPSBuZXdWYWw7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChyYXdSZWYuaykgcmVmc1tyYXdSZWYua10gPSBuZXdWYWw7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAoIWV4aXN0aW5nLmluY2x1ZGVzKHJlZlZhbHVlKSkge1xuICAgICAgICAgICAgICBleGlzdGluZy5wdXNoKHJlZlZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAoX2lzU3RyaW5nKSB7XG4gICAgICAgICAgcmVmc1tyZWZdID0gdmFsdWU7XG4gICAgICAgICAgaWYgKGNhblNldFNldHVwUmVmKHJlZikpIHtcbiAgICAgICAgICAgIHNldHVwU3RhdGVbcmVmXSA9IHZhbHVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmIChfaXNSZWYpIHtcbiAgICAgICAgICBpZiAoY2FuU2V0UmVmKHJlZiwgcmF3UmVmLmspKSB7XG4gICAgICAgICAgICByZWYudmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHJhd1JlZi5rKSByZWZzW3Jhd1JlZi5rXSA9IHZhbHVlO1xuICAgICAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICB3YXJuJDEoXCJJbnZhbGlkIHRlbXBsYXRlIHJlZiB0eXBlOlwiLCByZWYsIGAoJHt0eXBlb2YgcmVmfSlgKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICBjb25zdCBqb2IgPSAoKSA9PiB7XG4gICAgICAgICAgZG9TZXQoKTtcbiAgICAgICAgICBwZW5kaW5nU2V0UmVmTWFwLmRlbGV0ZShyYXdSZWYpO1xuICAgICAgICB9O1xuICAgICAgICBqb2IuaWQgPSAtMTtcbiAgICAgICAgcGVuZGluZ1NldFJlZk1hcC5zZXQocmF3UmVmLCBqb2IpO1xuICAgICAgICBxdWV1ZVBvc3RSZW5kZXJFZmZlY3Qoam9iLCBwYXJlbnRTdXNwZW5zZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpbnZhbGlkYXRlUGVuZGluZ1NldFJlZihyYXdSZWYpO1xuICAgICAgICBkb1NldCgpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgd2FybiQxKFwiSW52YWxpZCB0ZW1wbGF0ZSByZWYgdHlwZTpcIiwgcmVmLCBgKCR7dHlwZW9mIHJlZn0pYCk7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBpbnZhbGlkYXRlUGVuZGluZ1NldFJlZihyYXdSZWYpIHtcbiAgY29uc3QgcGVuZGluZ1NldFJlZiA9IHBlbmRpbmdTZXRSZWZNYXAuZ2V0KHJhd1JlZik7XG4gIGlmIChwZW5kaW5nU2V0UmVmKSB7XG4gICAgcGVuZGluZ1NldFJlZi5mbGFncyB8PSA4O1xuICAgIHBlbmRpbmdTZXRSZWZNYXAuZGVsZXRlKHJhd1JlZik7XG4gIH1cbn1cblxubGV0IGhhc0xvZ2dlZE1pc21hdGNoRXJyb3IgPSBmYWxzZTtcbmNvbnN0IGxvZ01pc21hdGNoRXJyb3IgPSAoKSA9PiB7XG4gIGlmIChoYXNMb2dnZWRNaXNtYXRjaEVycm9yKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnNvbGUuZXJyb3IoXCJIeWRyYXRpb24gY29tcGxldGVkIGJ1dCBjb250YWlucyBtaXNtYXRjaGVzLlwiKTtcbiAgaGFzTG9nZ2VkTWlzbWF0Y2hFcnJvciA9IHRydWU7XG59O1xuY29uc3QgaXNTVkdDb250YWluZXIgPSAoY29udGFpbmVyKSA9PiBjb250YWluZXIubmFtZXNwYWNlVVJJLmluY2x1ZGVzKFwic3ZnXCIpICYmIGNvbnRhaW5lci50YWdOYW1lICE9PSBcImZvcmVpZ25PYmplY3RcIjtcbmNvbnN0IGlzTWF0aE1MQ29udGFpbmVyID0gKGNvbnRhaW5lcikgPT4gY29udGFpbmVyLm5hbWVzcGFjZVVSSS5pbmNsdWRlcyhcIk1hdGhNTFwiKTtcbmNvbnN0IGdldENvbnRhaW5lclR5cGUgPSAoY29udGFpbmVyKSA9PiB7XG4gIGlmIChjb250YWluZXIubm9kZVR5cGUgIT09IDEpIHJldHVybiB2b2lkIDA7XG4gIGlmIChpc1NWR0NvbnRhaW5lcihjb250YWluZXIpKSByZXR1cm4gXCJzdmdcIjtcbiAgaWYgKGlzTWF0aE1MQ29udGFpbmVyKGNvbnRhaW5lcikpIHJldHVybiBcIm1hdGhtbFwiO1xuICByZXR1cm4gdm9pZCAwO1xufTtcbmNvbnN0IGlzQ29tbWVudCA9IChub2RlKSA9PiBub2RlLm5vZGVUeXBlID09PSA4O1xuZnVuY3Rpb24gY3JlYXRlSHlkcmF0aW9uRnVuY3Rpb25zKHJlbmRlcmVySW50ZXJuYWxzKSB7XG4gIGNvbnN0IHtcbiAgICBtdDogbW91bnRDb21wb25lbnQsXG4gICAgcDogcGF0Y2gsXG4gICAgbzoge1xuICAgICAgcGF0Y2hQcm9wLFxuICAgICAgY3JlYXRlVGV4dCxcbiAgICAgIG5leHRTaWJsaW5nLFxuICAgICAgcGFyZW50Tm9kZSxcbiAgICAgIHJlbW92ZSxcbiAgICAgIGluc2VydCxcbiAgICAgIGNyZWF0ZUNvbW1lbnRcbiAgICB9XG4gIH0gPSByZW5kZXJlckludGVybmFscztcbiAgY29uc3QgaHlkcmF0ZSA9ICh2bm9kZSwgY29udGFpbmVyKSA9PiB7XG4gICAgaWYgKCFjb250YWluZXIuaGFzQ2hpbGROb2RlcygpKSB7XG4gICAgICAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0hZRFJBVElPTl9NSVNNQVRDSF9ERVRBSUxTX18pICYmIHdhcm4kMShcbiAgICAgICAgYEF0dGVtcHRpbmcgdG8gaHlkcmF0ZSBleGlzdGluZyBtYXJrdXAgYnV0IGNvbnRhaW5lciBpcyBlbXB0eS4gUGVyZm9ybWluZyBmdWxsIG1vdW50IGluc3RlYWQuYFxuICAgICAgKTtcbiAgICAgIHBhdGNoKG51bGwsIHZub2RlLCBjb250YWluZXIpO1xuICAgICAgZmx1c2hQb3N0Rmx1c2hDYnMoKTtcbiAgICAgIGNvbnRhaW5lci5fdm5vZGUgPSB2bm9kZTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaHlkcmF0ZU5vZGUoY29udGFpbmVyLmZpcnN0Q2hpbGQsIHZub2RlLCBudWxsLCBudWxsLCBudWxsKTtcbiAgICBmbHVzaFBvc3RGbHVzaENicygpO1xuICAgIGNvbnRhaW5lci5fdm5vZGUgPSB2bm9kZTtcbiAgfTtcbiAgY29uc3QgaHlkcmF0ZU5vZGUgPSAobm9kZSwgdm5vZGUsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIHNsb3RTY29wZUlkcywgb3B0aW1pemVkID0gZmFsc2UpID0+IHtcbiAgICBvcHRpbWl6ZWQgPSBvcHRpbWl6ZWQgfHwgISF2bm9kZS5keW5hbWljQ2hpbGRyZW47XG4gICAgY29uc3QgaXNGcmFnbWVudFN0YXJ0ID0gaXNDb21tZW50KG5vZGUpICYmIG5vZGUuZGF0YSA9PT0gXCJbXCI7XG4gICAgY29uc3Qgb25NaXNtYXRjaCA9ICgpID0+IGhhbmRsZU1pc21hdGNoKFxuICAgICAgbm9kZSxcbiAgICAgIHZub2RlLFxuICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICBzbG90U2NvcGVJZHMsXG4gICAgICBpc0ZyYWdtZW50U3RhcnRcbiAgICApO1xuICAgIGNvbnN0IHsgdHlwZSwgcmVmLCBzaGFwZUZsYWcsIHBhdGNoRmxhZyB9ID0gdm5vZGU7XG4gICAgbGV0IGRvbVR5cGUgPSBub2RlLm5vZGVUeXBlO1xuICAgIHZub2RlLmVsID0gbm9kZTtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pIHtcbiAgICAgIGRlZihub2RlLCBcIl9fdm5vZGVcIiwgdm5vZGUsIHRydWUpO1xuICAgICAgZGVmKG5vZGUsIFwiX192dWVQYXJlbnRDb21wb25lbnRcIiwgcGFyZW50Q29tcG9uZW50LCB0cnVlKTtcbiAgICB9XG4gICAgaWYgKHBhdGNoRmxhZyA9PT0gLTIpIHtcbiAgICAgIG9wdGltaXplZCA9IGZhbHNlO1xuICAgICAgdm5vZGUuZHluYW1pY0NoaWxkcmVuID0gbnVsbDtcbiAgICB9XG4gICAgbGV0IG5leHROb2RlID0gbnVsbDtcbiAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgIGNhc2UgVGV4dDpcbiAgICAgICAgaWYgKGRvbVR5cGUgIT09IDMpIHtcbiAgICAgICAgICBpZiAodm5vZGUuY2hpbGRyZW4gPT09IFwiXCIpIHtcbiAgICAgICAgICAgIGluc2VydCh2bm9kZS5lbCA9IGNyZWF0ZVRleHQoXCJcIiksIHBhcmVudE5vZGUobm9kZSksIG5vZGUpO1xuICAgICAgICAgICAgbmV4dE5vZGUgPSBub2RlO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBuZXh0Tm9kZSA9IG9uTWlzbWF0Y2goKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKG5vZGUuZGF0YSAhPT0gdm5vZGUuY2hpbGRyZW4pIHtcbiAgICAgICAgICAgICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfSFlEUkFUSU9OX01JU01BVENIX0RFVEFJTFNfXykgJiYgd2FybiQxKFxuICAgICAgICAgICAgICBgSHlkcmF0aW9uIHRleHQgbWlzbWF0Y2ggaW5gLFxuICAgICAgICAgICAgICBub2RlLnBhcmVudE5vZGUsXG4gICAgICAgICAgICAgIGBcbiAgLSByZW5kZXJlZCBvbiBzZXJ2ZXI6ICR7SlNPTi5zdHJpbmdpZnkoXG4gICAgICAgICAgICAgICAgbm9kZS5kYXRhXG4gICAgICAgICAgICAgICl9XG4gIC0gZXhwZWN0ZWQgb24gY2xpZW50OiAke0pTT04uc3RyaW5naWZ5KHZub2RlLmNoaWxkcmVuKX1gXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgbG9nTWlzbWF0Y2hFcnJvcigpO1xuICAgICAgICAgICAgbm9kZS5kYXRhID0gdm5vZGUuY2hpbGRyZW47XG4gICAgICAgICAgfVxuICAgICAgICAgIG5leHROb2RlID0gbmV4dFNpYmxpbmcobm9kZSk7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlIENvbW1lbnQ6XG4gICAgICAgIGlmIChpc1RlbXBsYXRlTm9kZShub2RlKSkge1xuICAgICAgICAgIG5leHROb2RlID0gbmV4dFNpYmxpbmcobm9kZSk7XG4gICAgICAgICAgcmVwbGFjZU5vZGUoXG4gICAgICAgICAgICB2bm9kZS5lbCA9IG5vZGUuY29udGVudC5maXJzdENoaWxkLFxuICAgICAgICAgICAgbm9kZSxcbiAgICAgICAgICAgIHBhcmVudENvbXBvbmVudFxuICAgICAgICAgICk7XG4gICAgICAgIH0gZWxzZSBpZiAoZG9tVHlwZSAhPT0gOCB8fCBpc0ZyYWdtZW50U3RhcnQpIHtcbiAgICAgICAgICBuZXh0Tm9kZSA9IG9uTWlzbWF0Y2goKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBuZXh0Tm9kZSA9IG5leHRTaWJsaW5nKG5vZGUpO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBTdGF0aWM6XG4gICAgICAgIGlmIChpc0ZyYWdtZW50U3RhcnQpIHtcbiAgICAgICAgICBub2RlID0gbmV4dFNpYmxpbmcobm9kZSk7XG4gICAgICAgICAgZG9tVHlwZSA9IG5vZGUubm9kZVR5cGU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGRvbVR5cGUgPT09IDEgfHwgZG9tVHlwZSA9PT0gMykge1xuICAgICAgICAgIG5leHROb2RlID0gbm9kZTtcbiAgICAgICAgICBjb25zdCBuZWVkVG9BZG9wdENvbnRlbnQgPSAhdm5vZGUuY2hpbGRyZW4ubGVuZ3RoO1xuICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdm5vZGUuc3RhdGljQ291bnQ7IGkrKykge1xuICAgICAgICAgICAgaWYgKG5lZWRUb0Fkb3B0Q29udGVudClcbiAgICAgICAgICAgICAgdm5vZGUuY2hpbGRyZW4gKz0gbmV4dE5vZGUubm9kZVR5cGUgPT09IDEgPyBuZXh0Tm9kZS5vdXRlckhUTUwgOiBuZXh0Tm9kZS5kYXRhO1xuICAgICAgICAgICAgaWYgKGkgPT09IHZub2RlLnN0YXRpY0NvdW50IC0gMSkge1xuICAgICAgICAgICAgICB2bm9kZS5hbmNob3IgPSBuZXh0Tm9kZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG5leHROb2RlID0gbmV4dFNpYmxpbmcobmV4dE5vZGUpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gaXNGcmFnbWVudFN0YXJ0ID8gbmV4dFNpYmxpbmcobmV4dE5vZGUpIDogbmV4dE5vZGU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgb25NaXNtYXRjaCgpO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBGcmFnbWVudDpcbiAgICAgICAgaWYgKCFpc0ZyYWdtZW50U3RhcnQpIHtcbiAgICAgICAgICBuZXh0Tm9kZSA9IG9uTWlzbWF0Y2goKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBuZXh0Tm9kZSA9IGh5ZHJhdGVGcmFnbWVudChcbiAgICAgICAgICAgIG5vZGUsXG4gICAgICAgICAgICB2bm9kZSxcbiAgICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIGlmIChzaGFwZUZsYWcgJiAxKSB7XG4gICAgICAgICAgaWYgKChkb21UeXBlICE9PSAxIHx8IHZub2RlLnR5cGUudG9Mb3dlckNhc2UoKSAhPT0gbm9kZS50YWdOYW1lLnRvTG93ZXJDYXNlKCkpICYmICFpc1RlbXBsYXRlTm9kZShub2RlKSkge1xuICAgICAgICAgICAgbmV4dE5vZGUgPSBvbk1pc21hdGNoKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5leHROb2RlID0gaHlkcmF0ZUVsZW1lbnQoXG4gICAgICAgICAgICAgIG5vZGUsXG4gICAgICAgICAgICAgIHZub2RlLFxuICAgICAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAoc2hhcGVGbGFnICYgNikge1xuICAgICAgICAgIHZub2RlLnNsb3RTY29wZUlkcyA9IHNsb3RTY29wZUlkcztcbiAgICAgICAgICBjb25zdCBjb250YWluZXIgPSBwYXJlbnROb2RlKG5vZGUpO1xuICAgICAgICAgIGlmIChpc0ZyYWdtZW50U3RhcnQpIHtcbiAgICAgICAgICAgIG5leHROb2RlID0gbG9jYXRlQ2xvc2luZ0FuY2hvcihub2RlKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKGlzQ29tbWVudChub2RlKSAmJiBub2RlLmRhdGEgPT09IFwidGVsZXBvcnQgc3RhcnRcIikge1xuICAgICAgICAgICAgbmV4dE5vZGUgPSBsb2NhdGVDbG9zaW5nQW5jaG9yKG5vZGUsIG5vZGUuZGF0YSwgXCJ0ZWxlcG9ydCBlbmRcIik7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG5leHROb2RlID0gbmV4dFNpYmxpbmcobm9kZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIG1vdW50Q29tcG9uZW50KFxuICAgICAgICAgICAgdm5vZGUsXG4gICAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgICBudWxsLFxuICAgICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgICBnZXRDb250YWluZXJUeXBlKGNvbnRhaW5lciksXG4gICAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgICApO1xuICAgICAgICAgIGlmIChpc0FzeW5jV3JhcHBlcih2bm9kZSkgJiYgIXZub2RlLnR5cGUuX19hc3luY1Jlc29sdmVkKSB7XG4gICAgICAgICAgICBsZXQgc3ViVHJlZTtcbiAgICAgICAgICAgIGlmIChpc0ZyYWdtZW50U3RhcnQpIHtcbiAgICAgICAgICAgICAgc3ViVHJlZSA9IGNyZWF0ZVZOb2RlKEZyYWdtZW50KTtcbiAgICAgICAgICAgICAgc3ViVHJlZS5hbmNob3IgPSBuZXh0Tm9kZSA/IG5leHROb2RlLnByZXZpb3VzU2libGluZyA6IGNvbnRhaW5lci5sYXN0Q2hpbGQ7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBzdWJUcmVlID0gbm9kZS5ub2RlVHlwZSA9PT0gMyA/IGNyZWF0ZVRleHRWTm9kZShcIlwiKSA6IGNyZWF0ZVZOb2RlKFwiZGl2XCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc3ViVHJlZS5lbCA9IG5vZGU7XG4gICAgICAgICAgICB2bm9kZS5jb21wb25lbnQuc3ViVHJlZSA9IHN1YlRyZWU7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKHNoYXBlRmxhZyAmIDY0KSB7XG4gICAgICAgICAgaWYgKGRvbVR5cGUgIT09IDgpIHtcbiAgICAgICAgICAgIG5leHROb2RlID0gb25NaXNtYXRjaCgpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBuZXh0Tm9kZSA9IHZub2RlLnR5cGUuaHlkcmF0ZShcbiAgICAgICAgICAgICAgbm9kZSxcbiAgICAgICAgICAgICAgdm5vZGUsXG4gICAgICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICAgICAgb3B0aW1pemVkLFxuICAgICAgICAgICAgICByZW5kZXJlckludGVybmFscyxcbiAgICAgICAgICAgICAgaHlkcmF0ZUNoaWxkcmVuXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmIChzaGFwZUZsYWcgJiAxMjgpIHtcbiAgICAgICAgICBuZXh0Tm9kZSA9IHZub2RlLnR5cGUuaHlkcmF0ZShcbiAgICAgICAgICAgIG5vZGUsXG4gICAgICAgICAgICB2bm9kZSxcbiAgICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgICAgZ2V0Q29udGFpbmVyVHlwZShwYXJlbnROb2RlKG5vZGUpKSxcbiAgICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICAgIG9wdGltaXplZCxcbiAgICAgICAgICAgIHJlbmRlcmVySW50ZXJuYWxzLFxuICAgICAgICAgICAgaHlkcmF0ZU5vZGVcbiAgICAgICAgICApO1xuICAgICAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgX19WVUVfUFJPRF9IWURSQVRJT05fTUlTTUFUQ0hfREVUQUlMU19fKSB7XG4gICAgICAgICAgd2FybiQxKFwiSW52YWxpZCBIb3N0Vk5vZGUgdHlwZTpcIiwgdHlwZSwgYCgke3R5cGVvZiB0eXBlfSlgKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAocmVmICE9IG51bGwpIHtcbiAgICAgIHNldFJlZihyZWYsIG51bGwsIHBhcmVudFN1c3BlbnNlLCB2bm9kZSk7XG4gICAgfVxuICAgIHJldHVybiBuZXh0Tm9kZTtcbiAgfTtcbiAgY29uc3QgaHlkcmF0ZUVsZW1lbnQgPSAoZWwsIHZub2RlLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCBzbG90U2NvcGVJZHMsIG9wdGltaXplZCkgPT4ge1xuICAgIG9wdGltaXplZCA9IG9wdGltaXplZCB8fCAhIXZub2RlLmR5bmFtaWNDaGlsZHJlbjtcbiAgICBjb25zdCB7XG4gICAgICB0eXBlLFxuICAgICAgZHluYW1pY1Byb3BzLFxuICAgICAgcHJvcHMsXG4gICAgICBwYXRjaEZsYWcsXG4gICAgICBzaGFwZUZsYWcsXG4gICAgICBkaXJzLFxuICAgICAgdHJhbnNpdGlvblxuICAgIH0gPSB2bm9kZTtcbiAgICBjb25zdCBmb3JjZVBhdGNoID0gdHlwZSA9PT0gXCJpbnB1dFwiIHx8IHR5cGUgPT09IFwib3B0aW9uXCI7XG4gICAgY29uc3QgaGFzRHluYW1pY1Byb3BzID0gISFkeW5hbWljUHJvcHM7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgZm9yY2VQYXRjaCB8fCBoYXNEeW5hbWljUHJvcHMgfHwgcGF0Y2hGbGFnICE9PSAtMSkge1xuICAgICAgaWYgKGRpcnMpIHtcbiAgICAgICAgaW52b2tlRGlyZWN0aXZlSG9vayh2bm9kZSwgbnVsbCwgcGFyZW50Q29tcG9uZW50LCBcImNyZWF0ZWRcIik7XG4gICAgICB9XG4gICAgICBsZXQgbmVlZENhbGxUcmFuc2l0aW9uSG9va3MgPSBmYWxzZTtcbiAgICAgIGlmIChpc1RlbXBsYXRlTm9kZShlbCkpIHtcbiAgICAgICAgbmVlZENhbGxUcmFuc2l0aW9uSG9va3MgPSBuZWVkVHJhbnNpdGlvbihcbiAgICAgICAgICBudWxsLFxuICAgICAgICAgIC8vIG5vIG5lZWQgY2hlY2sgcGFyZW50U3VzcGVuc2UgaW4gaHlkcmF0aW9uXG4gICAgICAgICAgdHJhbnNpdGlvblxuICAgICAgICApICYmIHBhcmVudENvbXBvbmVudCAmJiBwYXJlbnRDb21wb25lbnQudm5vZGUucHJvcHMgJiYgcGFyZW50Q29tcG9uZW50LnZub2RlLnByb3BzLmFwcGVhcjtcbiAgICAgICAgY29uc3QgY29udGVudCA9IGVsLmNvbnRlbnQuZmlyc3RDaGlsZDtcbiAgICAgICAgaWYgKG5lZWRDYWxsVHJhbnNpdGlvbkhvb2tzKSB7XG4gICAgICAgICAgY29uc3QgY2xzID0gY29udGVudC5nZXRBdHRyaWJ1dGUoXCJjbGFzc1wiKTtcbiAgICAgICAgICBpZiAoY2xzKSBjb250ZW50LiRjbHMgPSBjbHM7XG4gICAgICAgICAgdHJhbnNpdGlvbi5iZWZvcmVFbnRlcihjb250ZW50KTtcbiAgICAgICAgfVxuICAgICAgICByZXBsYWNlTm9kZShjb250ZW50LCBlbCwgcGFyZW50Q29tcG9uZW50KTtcbiAgICAgICAgdm5vZGUuZWwgPSBlbCA9IGNvbnRlbnQ7XG4gICAgICB9XG4gICAgICBpZiAoc2hhcGVGbGFnICYgMTYgJiYgLy8gc2tpcCBpZiBlbGVtZW50IGhhcyBpbm5lckhUTUwgLyB0ZXh0Q29udGVudFxuICAgICAgIShwcm9wcyAmJiAocHJvcHMuaW5uZXJIVE1MIHx8IHByb3BzLnRleHRDb250ZW50KSkpIHtcbiAgICAgICAgbGV0IG5leHQgPSBoeWRyYXRlQ2hpbGRyZW4oXG4gICAgICAgICAgZWwuZmlyc3RDaGlsZCxcbiAgICAgICAgICB2bm9kZSxcbiAgICAgICAgICBlbCxcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICApO1xuICAgICAgICBpZiAobmV4dCAmJiAhaXNNaXNtYXRjaEFsbG93ZWQoZWwsIDEgLyogQ0hJTERSRU4gKi8pKSB7XG4gICAgICAgICAgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgX19WVUVfUFJPRF9IWURSQVRJT05fTUlTTUFUQ0hfREVUQUlMU19fKSAmJiB3YXJuJDEoXG4gICAgICAgICAgICBgSHlkcmF0aW9uIGNoaWxkcmVuIG1pc21hdGNoIG9uYCxcbiAgICAgICAgICAgIGVsLFxuICAgICAgICAgICAgYFxuU2VydmVyIHJlbmRlcmVkIGVsZW1lbnQgY29udGFpbnMgbW9yZSBjaGlsZCBub2RlcyB0aGFuIGNsaWVudCB2ZG9tLmBcbiAgICAgICAgICApO1xuICAgICAgICAgIGxvZ01pc21hdGNoRXJyb3IoKTtcbiAgICAgICAgfVxuICAgICAgICB3aGlsZSAobmV4dCkge1xuICAgICAgICAgIGNvbnN0IGN1ciA9IG5leHQ7XG4gICAgICAgICAgbmV4dCA9IG5leHQubmV4dFNpYmxpbmc7XG4gICAgICAgICAgcmVtb3ZlKGN1cik7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoc2hhcGVGbGFnICYgOCkge1xuICAgICAgICBsZXQgY2xpZW50VGV4dCA9IHZub2RlLmNoaWxkcmVuO1xuICAgICAgICBpZiAoY2xpZW50VGV4dFswXSA9PT0gXCJcXG5cIiAmJiAoZWwudGFnTmFtZSA9PT0gXCJQUkVcIiB8fCBlbC50YWdOYW1lID09PSBcIlRFWFRBUkVBXCIpKSB7XG4gICAgICAgICAgY2xpZW50VGV4dCA9IGNsaWVudFRleHQuc2xpY2UoMSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgeyB0ZXh0Q29udGVudCB9ID0gZWw7XG4gICAgICAgIGlmICh0ZXh0Q29udGVudCAhPT0gY2xpZW50VGV4dCAmJiAvLyBpbm5lckhUTUwgbm9ybWFsaXplIFxcclxcbiBvciBcXHIgaW50byBhIHNpbmdsZSBcXG4gaW4gdGhlIERPTVxuICAgICAgICB0ZXh0Q29udGVudCAhPT0gY2xpZW50VGV4dC5yZXBsYWNlKC9cXHJcXG58XFxyL2csIFwiXFxuXCIpKSB7XG4gICAgICAgICAgaWYgKCFpc01pc21hdGNoQWxsb3dlZChlbCwgMCAvKiBURVhUICovKSkge1xuICAgICAgICAgICAgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgX19WVUVfUFJPRF9IWURSQVRJT05fTUlTTUFUQ0hfREVUQUlMU19fKSAmJiB3YXJuJDEoXG4gICAgICAgICAgICAgIGBIeWRyYXRpb24gdGV4dCBjb250ZW50IG1pc21hdGNoIG9uYCxcbiAgICAgICAgICAgICAgZWwsXG4gICAgICAgICAgICAgIGBcbiAgLSByZW5kZXJlZCBvbiBzZXJ2ZXI6ICR7dGV4dENvbnRlbnR9XG4gIC0gZXhwZWN0ZWQgb24gY2xpZW50OiAke2NsaWVudFRleHR9YFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGxvZ01pc21hdGNoRXJyb3IoKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgZWwudGV4dENvbnRlbnQgPSB2bm9kZS5jaGlsZHJlbjtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKHByb3BzKSB7XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfSFlEUkFUSU9OX01JU01BVENIX0RFVEFJTFNfXyB8fCBmb3JjZVBhdGNoIHx8IGhhc0R5bmFtaWNQcm9wcyB8fCAhb3B0aW1pemVkIHx8IHBhdGNoRmxhZyAmICgxNiB8IDMyKSkge1xuICAgICAgICAgIGNvbnN0IGlzQ3VzdG9tRWxlbWVudCA9IGVsLnRhZ05hbWUuaW5jbHVkZXMoXCItXCIpO1xuICAgICAgICAgIGNvbnN0IG5hbWVzcGFjZSA9IGVsLm5hbWVzcGFjZVVSSS5pbmNsdWRlcyhcInN2Z1wiKSA/IFwic3ZnXCIgOiBlbC5uYW1lc3BhY2VVUkkuaW5jbHVkZXMoXCJNYXRoTUxcIikgPyBcIm1hdGhtbFwiIDogdm9pZCAwO1xuICAgICAgICAgIGZvciAoY29uc3Qga2V5IGluIHByb3BzKSB7XG4gICAgICAgICAgICBpZiAoKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgX19WVUVfUFJPRF9IWURSQVRJT05fTUlTTUFUQ0hfREVUQUlMU19fKSAmJiAvLyAjMTExODkgc2tpcCBpZiB0aGlzIG5vZGUgaGFzIGRpcmVjdGl2ZXMgdGhhdCBoYXZlIGNyZWF0ZWQgaG9va3NcbiAgICAgICAgICAgIC8vIGFzIGl0IGNvdWxkIGhhdmUgbXV0YXRlZCB0aGUgRE9NIGluIGFueSBwb3NzaWJsZSB3YXlcbiAgICAgICAgICAgICEoZGlycyAmJiBkaXJzLnNvbWUoKGQpID0+IGQuZGlyLmNyZWF0ZWQpKSAmJiBwcm9wSGFzTWlzbWF0Y2goZWwsIGtleSwgcHJvcHNba2V5XSwgdm5vZGUsIHBhcmVudENvbXBvbmVudCkpIHtcbiAgICAgICAgICAgICAgbG9nTWlzbWF0Y2hFcnJvcigpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGZvcmNlUGF0Y2ggJiYgKGtleS5lbmRzV2l0aChcInZhbHVlXCIpIHx8IGtleSA9PT0gXCJpbmRldGVybWluYXRlXCIpIHx8IGlzT24oa2V5KSAmJiAhaXNSZXNlcnZlZFByb3Aoa2V5KSB8fCAvLyBmb3JjZSBoeWRyYXRlIHYtYmluZCB3aXRoIC5wcm9wIG1vZGlmaWVyc1xuICAgICAgICAgICAga2V5WzBdID09PSBcIi5cIiB8fCBpc0N1c3RvbUVsZW1lbnQgJiYgIWlzUmVzZXJ2ZWRQcm9wKGtleSkgfHwgZHluYW1pY1Byb3BzICYmIGR5bmFtaWNQcm9wcy5pbmNsdWRlcyhrZXkpKSB7XG4gICAgICAgICAgICAgIHBhdGNoUHJvcChlbCwga2V5LCBudWxsLCBwcm9wc1trZXldLCBuYW1lc3BhY2UsIHBhcmVudENvbXBvbmVudCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKHByb3BzLm9uQ2xpY2spIHtcbiAgICAgICAgICBwYXRjaFByb3AoXG4gICAgICAgICAgICBlbCxcbiAgICAgICAgICAgIFwib25DbGlja1wiLFxuICAgICAgICAgICAgbnVsbCxcbiAgICAgICAgICAgIHByb3BzLm9uQ2xpY2ssXG4gICAgICAgICAgICB2b2lkIDAsXG4gICAgICAgICAgICBwYXJlbnRDb21wb25lbnRcbiAgICAgICAgICApO1xuICAgICAgICB9IGVsc2UgaWYgKHBhdGNoRmxhZyAmIDQgJiYgaXNSZWFjdGl2ZShwcm9wcy5zdHlsZSkpIHtcbiAgICAgICAgICBmb3IgKGNvbnN0IGtleSBpbiBwcm9wcy5zdHlsZSkgcHJvcHMuc3R5bGVba2V5XTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgbGV0IHZub2RlSG9va3M7XG4gICAgICBpZiAodm5vZGVIb29rcyA9IHByb3BzICYmIHByb3BzLm9uVm5vZGVCZWZvcmVNb3VudCkge1xuICAgICAgICBpbnZva2VWTm9kZUhvb2sodm5vZGVIb29rcywgcGFyZW50Q29tcG9uZW50LCB2bm9kZSk7XG4gICAgICB9XG4gICAgICBpZiAoZGlycykge1xuICAgICAgICBpbnZva2VEaXJlY3RpdmVIb29rKHZub2RlLCBudWxsLCBwYXJlbnRDb21wb25lbnQsIFwiYmVmb3JlTW91bnRcIik7XG4gICAgICB9XG4gICAgICBpZiAoKHZub2RlSG9va3MgPSBwcm9wcyAmJiBwcm9wcy5vblZub2RlTW91bnRlZCkgfHwgZGlycyB8fCBuZWVkQ2FsbFRyYW5zaXRpb25Ib29rcykge1xuICAgICAgICBxdWV1ZUVmZmVjdFdpdGhTdXNwZW5zZSgoKSA9PiB7XG4gICAgICAgICAgdm5vZGVIb29rcyAmJiBpbnZva2VWTm9kZUhvb2sodm5vZGVIb29rcywgcGFyZW50Q29tcG9uZW50LCB2bm9kZSk7XG4gICAgICAgICAgbmVlZENhbGxUcmFuc2l0aW9uSG9va3MgJiYgdHJhbnNpdGlvbi5lbnRlcihlbCk7XG4gICAgICAgICAgZGlycyAmJiBpbnZva2VEaXJlY3RpdmVIb29rKHZub2RlLCBudWxsLCBwYXJlbnRDb21wb25lbnQsIFwibW91bnRlZFwiKTtcbiAgICAgICAgfSwgcGFyZW50U3VzcGVuc2UpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZWwubmV4dFNpYmxpbmc7XG4gIH07XG4gIGNvbnN0IGh5ZHJhdGVDaGlsZHJlbiA9IChub2RlLCBwYXJlbnRWTm9kZSwgY29udGFpbmVyLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCBzbG90U2NvcGVJZHMsIG9wdGltaXplZCkgPT4ge1xuICAgIG9wdGltaXplZCA9IG9wdGltaXplZCB8fCAhIXBhcmVudFZOb2RlLmR5bmFtaWNDaGlsZHJlbjtcbiAgICBjb25zdCBjaGlsZHJlbiA9IHBhcmVudFZOb2RlLmNoaWxkcmVuO1xuICAgIGNvbnN0IGwgPSBjaGlsZHJlbi5sZW5ndGg7XG4gICAgbGV0IGhhc0NoZWNrZWRNaXNtYXRjaCA9IGZhbHNlO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbDsgaSsrKSB7XG4gICAgICBjb25zdCB2bm9kZSA9IG9wdGltaXplZCA/IGNoaWxkcmVuW2ldIDogY2hpbGRyZW5baV0gPSBub3JtYWxpemVWTm9kZShjaGlsZHJlbltpXSk7XG4gICAgICBjb25zdCBpc1RleHQgPSB2bm9kZS50eXBlID09PSBUZXh0O1xuICAgICAgaWYgKG5vZGUpIHtcbiAgICAgICAgaWYgKGlzVGV4dCAmJiAhb3B0aW1pemVkKSB7XG4gICAgICAgICAgaWYgKGkgKyAxIDwgbCAmJiBub3JtYWxpemVWTm9kZShjaGlsZHJlbltpICsgMV0pLnR5cGUgPT09IFRleHQpIHtcbiAgICAgICAgICAgIGluc2VydChcbiAgICAgICAgICAgICAgY3JlYXRlVGV4dChcbiAgICAgICAgICAgICAgICBub2RlLmRhdGEuc2xpY2Uodm5vZGUuY2hpbGRyZW4ubGVuZ3RoKVxuICAgICAgICAgICAgICApLFxuICAgICAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgICAgIG5leHRTaWJsaW5nKG5vZGUpXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgbm9kZS5kYXRhID0gdm5vZGUuY2hpbGRyZW47XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIG5vZGUgPSBoeWRyYXRlTm9kZShcbiAgICAgICAgICBub2RlLFxuICAgICAgICAgIHZub2RlLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICk7XG4gICAgICB9IGVsc2UgaWYgKGlzVGV4dCAmJiAhdm5vZGUuY2hpbGRyZW4pIHtcbiAgICAgICAgaW5zZXJ0KHZub2RlLmVsID0gY3JlYXRlVGV4dChcIlwiKSwgY29udGFpbmVyKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmICghaGFzQ2hlY2tlZE1pc21hdGNoKSB7XG4gICAgICAgICAgaGFzQ2hlY2tlZE1pc21hdGNoID0gdHJ1ZTtcbiAgICAgICAgICBpZiAoIWlzTWlzbWF0Y2hBbGxvd2VkKGNvbnRhaW5lciwgMSAvKiBDSElMRFJFTiAqLykpIHtcbiAgICAgICAgICAgICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfSFlEUkFUSU9OX01JU01BVENIX0RFVEFJTFNfXykgJiYgd2FybiQxKFxuICAgICAgICAgICAgICBgSHlkcmF0aW9uIGNoaWxkcmVuIG1pc21hdGNoIG9uYCxcbiAgICAgICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgICAgICBgXG5TZXJ2ZXIgcmVuZGVyZWQgZWxlbWVudCBjb250YWlucyBmZXdlciBjaGlsZCBub2RlcyB0aGFuIGNsaWVudCB2ZG9tLmBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBsb2dNaXNtYXRjaEVycm9yKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHBhdGNoKFxuICAgICAgICAgIG51bGwsXG4gICAgICAgICAgdm5vZGUsXG4gICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgIG51bGwsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgIGdldENvbnRhaW5lclR5cGUoY29udGFpbmVyKSxcbiAgICAgICAgICBzbG90U2NvcGVJZHNcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG5vZGU7XG4gIH07XG4gIGNvbnN0IGh5ZHJhdGVGcmFnbWVudCA9IChub2RlLCB2bm9kZSwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgc2xvdFNjb3BlSWRzLCBvcHRpbWl6ZWQpID0+IHtcbiAgICBjb25zdCB7IHNsb3RTY29wZUlkczogZnJhZ21lbnRTbG90U2NvcGVJZHMgfSA9IHZub2RlO1xuICAgIGlmIChmcmFnbWVudFNsb3RTY29wZUlkcykge1xuICAgICAgc2xvdFNjb3BlSWRzID0gc2xvdFNjb3BlSWRzID8gc2xvdFNjb3BlSWRzLmNvbmNhdChmcmFnbWVudFNsb3RTY29wZUlkcykgOiBmcmFnbWVudFNsb3RTY29wZUlkcztcbiAgICB9XG4gICAgY29uc3QgY29udGFpbmVyID0gcGFyZW50Tm9kZShub2RlKTtcbiAgICBjb25zdCBuZXh0ID0gaHlkcmF0ZUNoaWxkcmVuKFxuICAgICAgbmV4dFNpYmxpbmcobm9kZSksXG4gICAgICB2bm9kZSxcbiAgICAgIGNvbnRhaW5lcixcbiAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgb3B0aW1pemVkXG4gICAgKTtcbiAgICBpZiAobmV4dCAmJiBpc0NvbW1lbnQobmV4dCkgJiYgbmV4dC5kYXRhID09PSBcIl1cIikge1xuICAgICAgcmV0dXJuIG5leHRTaWJsaW5nKHZub2RlLmFuY2hvciA9IG5leHQpO1xuICAgIH0gZWxzZSB7XG4gICAgICBsb2dNaXNtYXRjaEVycm9yKCk7XG4gICAgICBpbnNlcnQodm5vZGUuYW5jaG9yID0gY3JlYXRlQ29tbWVudChgXWApLCBjb250YWluZXIsIG5leHQpO1xuICAgICAgcmV0dXJuIG5leHQ7XG4gICAgfVxuICB9O1xuICBjb25zdCBoYW5kbGVNaXNtYXRjaCA9IChub2RlLCB2bm9kZSwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgc2xvdFNjb3BlSWRzLCBpc0ZyYWdtZW50KSA9PiB7XG4gICAgaWYgKCFpc05vZGVNaXNtYXRjaEFsbG93ZWQobm9kZSwgdm5vZGUpKSB7XG4gICAgICAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0hZRFJBVElPTl9NSVNNQVRDSF9ERVRBSUxTX18pICYmIHdhcm4kMShcbiAgICAgICAgYEh5ZHJhdGlvbiBub2RlIG1pc21hdGNoOlxuLSByZW5kZXJlZCBvbiBzZXJ2ZXI6YCxcbiAgICAgICAgbm9kZSxcbiAgICAgICAgbm9kZS5ub2RlVHlwZSA9PT0gMyA/IGAodGV4dClgIDogaXNDb21tZW50KG5vZGUpICYmIG5vZGUuZGF0YSA9PT0gXCJbXCIgPyBgKHN0YXJ0IG9mIGZyYWdtZW50KWAgOiBgYCxcbiAgICAgICAgYFxuLSBleHBlY3RlZCBvbiBjbGllbnQ6YCxcbiAgICAgICAgdm5vZGUudHlwZVxuICAgICAgKTtcbiAgICAgIGxvZ01pc21hdGNoRXJyb3IoKTtcbiAgICB9XG4gICAgdm5vZGUuZWwgPSBudWxsO1xuICAgIGlmIChpc0ZyYWdtZW50KSB7XG4gICAgICBjb25zdCBlbmQgPSBsb2NhdGVDbG9zaW5nQW5jaG9yKG5vZGUpO1xuICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgY29uc3QgbmV4dDIgPSBuZXh0U2libGluZyhub2RlKTtcbiAgICAgICAgaWYgKG5leHQyICYmIG5leHQyICE9PSBlbmQpIHtcbiAgICAgICAgICByZW1vdmUobmV4dDIpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IG5leHQgPSBuZXh0U2libGluZyhub2RlKTtcbiAgICBjb25zdCBjb250YWluZXIgPSBwYXJlbnROb2RlKG5vZGUpO1xuICAgIHJlbW92ZShub2RlKTtcbiAgICBwYXRjaChcbiAgICAgIG51bGwsXG4gICAgICB2bm9kZSxcbiAgICAgIGNvbnRhaW5lcixcbiAgICAgIG5leHQsXG4gICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgIGdldENvbnRhaW5lclR5cGUoY29udGFpbmVyKSxcbiAgICAgIHNsb3RTY29wZUlkc1xuICAgICk7XG4gICAgaWYgKHBhcmVudENvbXBvbmVudCkge1xuICAgICAgcGFyZW50Q29tcG9uZW50LnZub2RlLmVsID0gdm5vZGUuZWw7XG4gICAgICB1cGRhdGVIT0NIb3N0RWwocGFyZW50Q29tcG9uZW50LCB2bm9kZS5lbCk7XG4gICAgfVxuICAgIHJldHVybiBuZXh0O1xuICB9O1xuICBjb25zdCBsb2NhdGVDbG9zaW5nQW5jaG9yID0gKG5vZGUsIG9wZW4gPSBcIltcIiwgY2xvc2UgPSBcIl1cIikgPT4ge1xuICAgIGxldCBtYXRjaCA9IDA7XG4gICAgd2hpbGUgKG5vZGUpIHtcbiAgICAgIG5vZGUgPSBuZXh0U2libGluZyhub2RlKTtcbiAgICAgIGlmIChub2RlICYmIGlzQ29tbWVudChub2RlKSkge1xuICAgICAgICBpZiAobm9kZS5kYXRhID09PSBvcGVuKSBtYXRjaCsrO1xuICAgICAgICBpZiAobm9kZS5kYXRhID09PSBjbG9zZSkge1xuICAgICAgICAgIGlmIChtYXRjaCA9PT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIG5leHRTaWJsaW5nKG5vZGUpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBtYXRjaC0tO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbm9kZTtcbiAgfTtcbiAgY29uc3QgcmVwbGFjZU5vZGUgPSAobmV3Tm9kZSwgb2xkTm9kZSwgcGFyZW50Q29tcG9uZW50KSA9PiB7XG4gICAgY29uc3QgcGFyZW50Tm9kZTIgPSBvbGROb2RlLnBhcmVudE5vZGU7XG4gICAgaWYgKHBhcmVudE5vZGUyKSB7XG4gICAgICBwYXJlbnROb2RlMi5yZXBsYWNlQ2hpbGQobmV3Tm9kZSwgb2xkTm9kZSk7XG4gICAgfVxuICAgIGxldCBwYXJlbnQgPSBwYXJlbnRDb21wb25lbnQ7XG4gICAgd2hpbGUgKHBhcmVudCkge1xuICAgICAgaWYgKHBhcmVudC52bm9kZS5lbCA9PT0gb2xkTm9kZSkge1xuICAgICAgICBwYXJlbnQudm5vZGUuZWwgPSBwYXJlbnQuc3ViVHJlZS5lbCA9IG5ld05vZGU7XG4gICAgICB9XG4gICAgICBwYXJlbnQgPSBwYXJlbnQucGFyZW50O1xuICAgIH1cbiAgfTtcbiAgY29uc3QgaXNUZW1wbGF0ZU5vZGUgPSAobm9kZSkgPT4ge1xuICAgIHJldHVybiBub2RlLm5vZGVUeXBlID09PSAxICYmIG5vZGUudGFnTmFtZSA9PT0gXCJURU1QTEFURVwiO1xuICB9O1xuICByZXR1cm4gW2h5ZHJhdGUsIGh5ZHJhdGVOb2RlXTtcbn1cbmZ1bmN0aW9uIHByb3BIYXNNaXNtYXRjaChlbCwga2V5LCBjbGllbnRWYWx1ZSwgdm5vZGUsIGluc3RhbmNlKSB7XG4gIGxldCBtaXNtYXRjaFR5cGU7XG4gIGxldCBtaXNtYXRjaEtleTtcbiAgbGV0IGFjdHVhbDtcbiAgbGV0IGV4cGVjdGVkO1xuICBpZiAoa2V5ID09PSBcImNsYXNzXCIpIHtcbiAgICBpZiAoZWwuJGNscykge1xuICAgICAgYWN0dWFsID0gZWwuJGNscztcbiAgICAgIGRlbGV0ZSBlbC4kY2xzO1xuICAgIH0gZWxzZSB7XG4gICAgICBhY3R1YWwgPSBlbC5nZXRBdHRyaWJ1dGUoXCJjbGFzc1wiKTtcbiAgICB9XG4gICAgZXhwZWN0ZWQgPSBub3JtYWxpemVDbGFzcyhjbGllbnRWYWx1ZSk7XG4gICAgaWYgKCFpc1NldEVxdWFsKHRvQ2xhc3NTZXQoYWN0dWFsIHx8IFwiXCIpLCB0b0NsYXNzU2V0KGV4cGVjdGVkKSkpIHtcbiAgICAgIG1pc21hdGNoVHlwZSA9IDIgLyogQ0xBU1MgKi87XG4gICAgICBtaXNtYXRjaEtleSA9IGBjbGFzc2A7XG4gICAgfVxuICB9IGVsc2UgaWYgKGtleSA9PT0gXCJzdHlsZVwiKSB7XG4gICAgYWN0dWFsID0gZWwuZ2V0QXR0cmlidXRlKFwic3R5bGVcIikgfHwgXCJcIjtcbiAgICBleHBlY3RlZCA9IGlzU3RyaW5nKGNsaWVudFZhbHVlKSA/IGNsaWVudFZhbHVlIDogc3RyaW5naWZ5U3R5bGUobm9ybWFsaXplU3R5bGUoY2xpZW50VmFsdWUpKTtcbiAgICBjb25zdCBhY3R1YWxNYXAgPSB0b1N0eWxlTWFwKGFjdHVhbCk7XG4gICAgY29uc3QgZXhwZWN0ZWRNYXAgPSB0b1N0eWxlTWFwKGV4cGVjdGVkKTtcbiAgICBpZiAodm5vZGUuZGlycykge1xuICAgICAgZm9yIChjb25zdCB7IGRpciwgdmFsdWUgfSBvZiB2bm9kZS5kaXJzKSB7XG4gICAgICAgIGlmIChkaXIubmFtZSA9PT0gXCJzaG93XCIgJiYgIXZhbHVlKSB7XG4gICAgICAgICAgZXhwZWN0ZWRNYXAuc2V0KFwiZGlzcGxheVwiLCBcIm5vbmVcIik7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGluc3RhbmNlKSB7XG4gICAgICByZXNvbHZlQ3NzVmFycyhpbnN0YW5jZSwgdm5vZGUsIGV4cGVjdGVkTWFwKTtcbiAgICB9XG4gICAgaWYgKCFpc01hcEVxdWFsKGFjdHVhbE1hcCwgZXhwZWN0ZWRNYXApKSB7XG4gICAgICBtaXNtYXRjaFR5cGUgPSAzIC8qIFNUWUxFICovO1xuICAgICAgbWlzbWF0Y2hLZXkgPSBcInN0eWxlXCI7XG4gICAgfVxuICB9IGVsc2UgaWYgKGVsIGluc3RhbmNlb2YgU1ZHRWxlbWVudCAmJiBpc0tub3duU3ZnQXR0cihrZXkpIHx8IGVsIGluc3RhbmNlb2YgSFRNTEVsZW1lbnQgJiYgKGlzQm9vbGVhbkF0dHIoa2V5KSB8fCBpc0tub3duSHRtbEF0dHIoa2V5KSkpIHtcbiAgICBpZiAoaXNCb29sZWFuQXR0cihrZXkpKSB7XG4gICAgICBhY3R1YWwgPSBlbC5oYXNBdHRyaWJ1dGUoa2V5KTtcbiAgICAgIGV4cGVjdGVkID0gaW5jbHVkZUJvb2xlYW5BdHRyKGNsaWVudFZhbHVlKTtcbiAgICB9IGVsc2UgaWYgKGNsaWVudFZhbHVlID09IG51bGwpIHtcbiAgICAgIGFjdHVhbCA9IGVsLmhhc0F0dHJpYnV0ZShrZXkpO1xuICAgICAgZXhwZWN0ZWQgPSBmYWxzZTtcbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKGVsLmhhc0F0dHJpYnV0ZShrZXkpKSB7XG4gICAgICAgIGFjdHVhbCA9IGVsLmdldEF0dHJpYnV0ZShrZXkpO1xuICAgICAgfSBlbHNlIGlmIChrZXkgPT09IFwidmFsdWVcIiAmJiBlbC50YWdOYW1lID09PSBcIlRFWFRBUkVBXCIpIHtcbiAgICAgICAgYWN0dWFsID0gZWwudmFsdWU7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhY3R1YWwgPSBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGV4cGVjdGVkID0gaXNSZW5kZXJhYmxlQXR0clZhbHVlKGNsaWVudFZhbHVlKSA/IFN0cmluZyhjbGllbnRWYWx1ZSkgOiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKGFjdHVhbCAhPT0gZXhwZWN0ZWQpIHtcbiAgICAgIG1pc21hdGNoVHlwZSA9IDQgLyogQVRUUklCVVRFICovO1xuICAgICAgbWlzbWF0Y2hLZXkgPSBrZXk7XG4gICAgfVxuICB9XG4gIGlmIChtaXNtYXRjaFR5cGUgIT0gbnVsbCAmJiAhaXNNaXNtYXRjaEFsbG93ZWQoZWwsIG1pc21hdGNoVHlwZSkpIHtcbiAgICBjb25zdCBmb3JtYXQgPSAodikgPT4gdiA9PT0gZmFsc2UgPyBgKG5vdCByZW5kZXJlZClgIDogYCR7bWlzbWF0Y2hLZXl9PVwiJHt2fVwiYDtcbiAgICBjb25zdCBwcmVTZWdtZW50ID0gYEh5ZHJhdGlvbiAke01pc21hdGNoVHlwZVN0cmluZ1ttaXNtYXRjaFR5cGVdfSBtaXNtYXRjaCBvbmA7XG4gICAgY29uc3QgcG9zdFNlZ21lbnQgPSBgXG4gIC0gcmVuZGVyZWQgb24gc2VydmVyOiAke2Zvcm1hdChhY3R1YWwpfVxuICAtIGV4cGVjdGVkIG9uIGNsaWVudDogJHtmb3JtYXQoZXhwZWN0ZWQpfVxuICBOb3RlOiB0aGlzIG1pc21hdGNoIGlzIGNoZWNrLW9ubHkuIFRoZSBET00gd2lsbCBub3QgYmUgcmVjdGlmaWVkIGluIHByb2R1Y3Rpb24gZHVlIHRvIHBlcmZvcm1hbmNlIG92ZXJoZWFkLlxuICBZb3Ugc2hvdWxkIGZpeCB0aGUgc291cmNlIG9mIHRoZSBtaXNtYXRjaC5gO1xuICAgIHtcbiAgICAgIHdhcm4kMShwcmVTZWdtZW50LCBlbCwgcG9zdFNlZ21lbnQpO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5mdW5jdGlvbiB0b0NsYXNzU2V0KHN0cikge1xuICByZXR1cm4gbmV3IFNldChzdHIudHJpbSgpLnNwbGl0KC9cXHMrLykpO1xufVxuZnVuY3Rpb24gaXNTZXRFcXVhbChhLCBiKSB7XG4gIGlmIChhLnNpemUgIT09IGIuc2l6ZSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBmb3IgKGNvbnN0IHMgb2YgYSkge1xuICAgIGlmICghYi5oYXMocykpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiB0b1N0eWxlTWFwKHN0cikge1xuICBjb25zdCBzdHlsZU1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gIGZvciAoY29uc3QgaXRlbSBvZiBzdHIuc3BsaXQoXCI7XCIpKSB7XG4gICAgbGV0IFtrZXksIHZhbHVlXSA9IGl0ZW0uc3BsaXQoXCI6XCIpO1xuICAgIGtleSA9IGtleS50cmltKCk7XG4gICAgdmFsdWUgPSB2YWx1ZSAmJiB2YWx1ZS50cmltKCk7XG4gICAgaWYgKGtleSAmJiB2YWx1ZSkge1xuICAgICAgc3R5bGVNYXAuc2V0KGtleSwgdmFsdWUpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gc3R5bGVNYXA7XG59XG5mdW5jdGlvbiBpc01hcEVxdWFsKGEsIGIpIHtcbiAgaWYgKGEuc2l6ZSAhPT0gYi5zaXplKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIGEpIHtcbiAgICBpZiAodmFsdWUgIT09IGIuZ2V0KGtleSkpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiByZXNvbHZlQ3NzVmFycyhpbnN0YW5jZSwgdm5vZGUsIGV4cGVjdGVkTWFwKSB7XG4gIGNvbnN0IHJvb3QgPSBpbnN0YW5jZS5zdWJUcmVlO1xuICBpZiAoaW5zdGFuY2UuZ2V0Q3NzVmFycyAmJiAodm5vZGUgPT09IHJvb3QgfHwgcm9vdCAmJiByb290LnR5cGUgPT09IEZyYWdtZW50ICYmIHJvb3QuY2hpbGRyZW4uaW5jbHVkZXModm5vZGUpKSkge1xuICAgIGNvbnN0IGNzc1ZhcnMgPSBpbnN0YW5jZS5nZXRDc3NWYXJzKCk7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gY3NzVmFycykge1xuICAgICAgY29uc3QgdmFsdWUgPSBub3JtYWxpemVDc3NWYXJWYWx1ZShjc3NWYXJzW2tleV0pO1xuICAgICAgZXhwZWN0ZWRNYXAuc2V0KGAtLSR7Z2V0RXNjYXBlZENzc1Zhck5hbWUoa2V5LCBmYWxzZSl9YCwgdmFsdWUpO1xuICAgIH1cbiAgfVxuICBpZiAodm5vZGUgPT09IHJvb3QgJiYgaW5zdGFuY2UucGFyZW50KSB7XG4gICAgcmVzb2x2ZUNzc1ZhcnMoaW5zdGFuY2UucGFyZW50LCBpbnN0YW5jZS52bm9kZSwgZXhwZWN0ZWRNYXApO1xuICB9XG59XG5jb25zdCBhbGxvd01pc21hdGNoQXR0ciA9IFwiZGF0YS1hbGxvdy1taXNtYXRjaFwiO1xuY29uc3QgTWlzbWF0Y2hUeXBlU3RyaW5nID0ge1xuICBbMCAvKiBURVhUICovXTogXCJ0ZXh0XCIsXG4gIFsxIC8qIENISUxEUkVOICovXTogXCJjaGlsZHJlblwiLFxuICBbMiAvKiBDTEFTUyAqL106IFwiY2xhc3NcIixcbiAgWzMgLyogU1RZTEUgKi9dOiBcInN0eWxlXCIsXG4gIFs0IC8qIEFUVFJJQlVURSAqL106IFwiYXR0cmlidXRlXCJcbn07XG5mdW5jdGlvbiBpc01pc21hdGNoQWxsb3dlZChlbCwgYWxsb3dlZFR5cGUpIHtcbiAgaWYgKGFsbG93ZWRUeXBlID09PSAwIC8qIFRFWFQgKi8gfHwgYWxsb3dlZFR5cGUgPT09IDEgLyogQ0hJTERSRU4gKi8pIHtcbiAgICB3aGlsZSAoZWwgJiYgIWVsLmhhc0F0dHJpYnV0ZShhbGxvd01pc21hdGNoQXR0cikpIHtcbiAgICAgIGVsID0gZWwucGFyZW50RWxlbWVudDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGlzTWlzbWF0Y2hBbGxvd2VkQnlBdHRyKFxuICAgIGVsICYmIGVsLmdldEF0dHJpYnV0ZShhbGxvd01pc21hdGNoQXR0ciksXG4gICAgYWxsb3dlZFR5cGVcbiAgKTtcbn1cbmZ1bmN0aW9uIGlzTWlzbWF0Y2hBbGxvd2VkQnlBdHRyKGFsbG93ZWRBdHRyLCBhbGxvd2VkVHlwZSkge1xuICBpZiAoYWxsb3dlZEF0dHIgPT0gbnVsbCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfSBlbHNlIGlmIChhbGxvd2VkQXR0ciA9PT0gXCJcIikge1xuICAgIHJldHVybiB0cnVlO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IGxpc3QgPSBhbGxvd2VkQXR0ci5zcGxpdChcIixcIik7XG4gICAgaWYgKGFsbG93ZWRUeXBlID09PSAwIC8qIFRFWFQgKi8gJiYgbGlzdC5pbmNsdWRlcyhcImNoaWxkcmVuXCIpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGxpc3QuaW5jbHVkZXMoTWlzbWF0Y2hUeXBlU3RyaW5nW2FsbG93ZWRUeXBlXSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGlzTm9kZU1pc21hdGNoQWxsb3dlZChub2RlLCB2bm9kZSkge1xuICByZXR1cm4gaXNNaXNtYXRjaEFsbG93ZWQobm9kZS5wYXJlbnRFbGVtZW50LCAxIC8qIENISUxEUkVOICovKSB8fCBpc01pc21hdGNoQWxsb3dlZEJ5Tm9kZShub2RlKSB8fCBpc01pc21hdGNoQWxsb3dlZEJ5Vk5vZGUodm5vZGUpO1xufVxuZnVuY3Rpb24gaXNNaXNtYXRjaEFsbG93ZWRCeU5vZGUobm9kZSkge1xuICByZXR1cm4gbm9kZS5ub2RlVHlwZSA9PT0gMSAmJiBpc01pc21hdGNoQWxsb3dlZEJ5QXR0cihcbiAgICBub2RlLmdldEF0dHJpYnV0ZShhbGxvd01pc21hdGNoQXR0ciksXG4gICAgMSAvKiBDSElMRFJFTiAqL1xuICApO1xufVxuZnVuY3Rpb24gaXNNaXNtYXRjaEFsbG93ZWRCeVZOb2RlKHsgcHJvcHMgfSkge1xuICBjb25zdCBhbGxvd2VkQXR0ciA9IHByb3BzICYmIHByb3BzW2FsbG93TWlzbWF0Y2hBdHRyXTtcbiAgcmV0dXJuIHR5cGVvZiBhbGxvd2VkQXR0ciA9PT0gXCJzdHJpbmdcIiAmJiBpc01pc21hdGNoQWxsb3dlZEJ5QXR0cihhbGxvd2VkQXR0ciwgMSAvKiBDSElMRFJFTiAqLyk7XG59XG5cbmNvbnN0IHJlcXVlc3RJZGxlQ2FsbGJhY2sgPSBnZXRHbG9iYWxUaGlzKCkucmVxdWVzdElkbGVDYWxsYmFjayB8fCAoKGNiKSA9PiBzZXRUaW1lb3V0KGNiLCAxKSk7XG5jb25zdCBjYW5jZWxJZGxlQ2FsbGJhY2sgPSBnZXRHbG9iYWxUaGlzKCkuY2FuY2VsSWRsZUNhbGxiYWNrIHx8ICgoaWQpID0+IGNsZWFyVGltZW91dChpZCkpO1xuY29uc3QgaHlkcmF0ZU9uSWRsZSA9ICh0aW1lb3V0ID0gMWU0KSA9PiAoaHlkcmF0ZSkgPT4ge1xuICBjb25zdCBpZCA9IHJlcXVlc3RJZGxlQ2FsbGJhY2soaHlkcmF0ZSwgeyB0aW1lb3V0IH0pO1xuICByZXR1cm4gKCkgPT4gY2FuY2VsSWRsZUNhbGxiYWNrKGlkKTtcbn07XG5mdW5jdGlvbiBlbGVtZW50SXNWaXNpYmxlSW5WaWV3cG9ydChlbCkge1xuICBjb25zdCB7IHRvcCwgbGVmdCwgYm90dG9tLCByaWdodCB9ID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIGNvbnN0IHsgaW5uZXJIZWlnaHQsIGlubmVyV2lkdGggfSA9IHdpbmRvdztcbiAgcmV0dXJuICh0b3AgPiAwICYmIHRvcCA8IGlubmVySGVpZ2h0IHx8IGJvdHRvbSA+IDAgJiYgYm90dG9tIDwgaW5uZXJIZWlnaHQpICYmIChsZWZ0ID4gMCAmJiBsZWZ0IDwgaW5uZXJXaWR0aCB8fCByaWdodCA+IDAgJiYgcmlnaHQgPCBpbm5lcldpZHRoKTtcbn1cbmNvbnN0IGh5ZHJhdGVPblZpc2libGUgPSAob3B0cykgPT4gKGh5ZHJhdGUsIGZvckVhY2gpID0+IHtcbiAgY29uc3Qgb2IgPSBuZXcgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIoKGVudHJpZXMpID0+IHtcbiAgICBmb3IgKGNvbnN0IGUgb2YgZW50cmllcykge1xuICAgICAgaWYgKCFlLmlzSW50ZXJzZWN0aW5nKSBjb250aW51ZTtcbiAgICAgIG9iLmRpc2Nvbm5lY3QoKTtcbiAgICAgIGh5ZHJhdGUoKTtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgfSwgb3B0cyk7XG4gIGZvckVhY2goKGVsKSA9PiB7XG4gICAgaWYgKCEoZWwgaW5zdGFuY2VvZiBFbGVtZW50KSkgcmV0dXJuO1xuICAgIGlmIChlbGVtZW50SXNWaXNpYmxlSW5WaWV3cG9ydChlbCkpIHtcbiAgICAgIGh5ZHJhdGUoKTtcbiAgICAgIG9iLmRpc2Nvbm5lY3QoKTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgb2Iub2JzZXJ2ZShlbCk7XG4gIH0pO1xuICByZXR1cm4gKCkgPT4gb2IuZGlzY29ubmVjdCgpO1xufTtcbmNvbnN0IGh5ZHJhdGVPbk1lZGlhUXVlcnkgPSAocXVlcnkpID0+IChoeWRyYXRlKSA9PiB7XG4gIGlmIChxdWVyeSkge1xuICAgIGNvbnN0IG1xbCA9IG1hdGNoTWVkaWEocXVlcnkpO1xuICAgIGlmIChtcWwubWF0Y2hlcykge1xuICAgICAgaHlkcmF0ZSgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBtcWwuYWRkRXZlbnRMaXN0ZW5lcihcImNoYW5nZVwiLCBoeWRyYXRlLCB7IG9uY2U6IHRydWUgfSk7XG4gICAgICByZXR1cm4gKCkgPT4gbXFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJjaGFuZ2VcIiwgaHlkcmF0ZSk7XG4gICAgfVxuICB9XG59O1xuY29uc3QgaHlkcmF0ZU9uSW50ZXJhY3Rpb24gPSAoaW50ZXJhY3Rpb25zID0gW10pID0+IChoeWRyYXRlLCBmb3JFYWNoKSA9PiB7XG4gIGlmIChpc1N0cmluZyhpbnRlcmFjdGlvbnMpKSBpbnRlcmFjdGlvbnMgPSBbaW50ZXJhY3Rpb25zXTtcbiAgbGV0IGhhc0h5ZHJhdGVkID0gZmFsc2U7XG4gIGNvbnN0IGRvSHlkcmF0ZSA9IChlKSA9PiB7XG4gICAgaWYgKCFoYXNIeWRyYXRlZCkge1xuICAgICAgaGFzSHlkcmF0ZWQgPSB0cnVlO1xuICAgICAgdGVhcmRvd24oKTtcbiAgICAgIGh5ZHJhdGUoKTtcbiAgICAgIGUudGFyZ2V0LmRpc3BhdGNoRXZlbnQobmV3IGUuY29uc3RydWN0b3IoZS50eXBlLCBlKSk7XG4gICAgfVxuICB9O1xuICBjb25zdCB0ZWFyZG93biA9ICgpID0+IHtcbiAgICBmb3JFYWNoKChlbCkgPT4ge1xuICAgICAgZm9yIChjb25zdCBpIG9mIGludGVyYWN0aW9ucykge1xuICAgICAgICBlbC5yZW1vdmVFdmVudExpc3RlbmVyKGksIGRvSHlkcmF0ZSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH07XG4gIGZvckVhY2goKGVsKSA9PiB7XG4gICAgZm9yIChjb25zdCBpIG9mIGludGVyYWN0aW9ucykge1xuICAgICAgZWwuYWRkRXZlbnRMaXN0ZW5lcihpLCBkb0h5ZHJhdGUsIHsgb25jZTogdHJ1ZSB9KTtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gdGVhcmRvd247XG59O1xuZnVuY3Rpb24gZm9yRWFjaEVsZW1lbnQobm9kZSwgY2IpIHtcbiAgaWYgKGlzQ29tbWVudChub2RlKSAmJiBub2RlLmRhdGEgPT09IFwiW1wiKSB7XG4gICAgbGV0IGRlcHRoID0gMTtcbiAgICBsZXQgbmV4dCA9IG5vZGUubmV4dFNpYmxpbmc7XG4gICAgd2hpbGUgKG5leHQpIHtcbiAgICAgIGlmIChuZXh0Lm5vZGVUeXBlID09PSAxKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGNiKG5leHQpO1xuICAgICAgICBpZiAocmVzdWx0ID09PSBmYWxzZSkge1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGlzQ29tbWVudChuZXh0KSkge1xuICAgICAgICBpZiAobmV4dC5kYXRhID09PSBcIl1cIikge1xuICAgICAgICAgIGlmICgtLWRlcHRoID09PSAwKSBicmVhaztcbiAgICAgICAgfSBlbHNlIGlmIChuZXh0LmRhdGEgPT09IFwiW1wiKSB7XG4gICAgICAgICAgZGVwdGgrKztcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgbmV4dCA9IG5leHQubmV4dFNpYmxpbmc7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGNiKG5vZGUpO1xuICB9XG59XG5cbmNvbnN0IGlzQXN5bmNXcmFwcGVyID0gKGkpID0+ICEhaS50eXBlLl9fYXN5bmNMb2FkZXI7XG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gZGVmaW5lQXN5bmNDb21wb25lbnQoc291cmNlKSB7XG4gIGlmIChpc0Z1bmN0aW9uKHNvdXJjZSkpIHtcbiAgICBzb3VyY2UgPSB7IGxvYWRlcjogc291cmNlIH07XG4gIH1cbiAgY29uc3Qge1xuICAgIGxvYWRlcixcbiAgICBsb2FkaW5nQ29tcG9uZW50LFxuICAgIGVycm9yQ29tcG9uZW50LFxuICAgIGRlbGF5ID0gMjAwLFxuICAgIGh5ZHJhdGU6IGh5ZHJhdGVTdHJhdGVneSxcbiAgICB0aW1lb3V0LFxuICAgIC8vIHVuZGVmaW5lZCA9IG5ldmVyIHRpbWVzIG91dFxuICAgIHN1c3BlbnNpYmxlID0gdHJ1ZSxcbiAgICBvbkVycm9yOiB1c2VyT25FcnJvclxuICB9ID0gc291cmNlO1xuICBsZXQgcGVuZGluZ1JlcXVlc3QgPSBudWxsO1xuICBsZXQgcmVzb2x2ZWRDb21wO1xuICBsZXQgcmV0cmllcyA9IDA7XG4gIGNvbnN0IHJldHJ5ID0gKCkgPT4ge1xuICAgIHJldHJpZXMrKztcbiAgICBwZW5kaW5nUmVxdWVzdCA9IG51bGw7XG4gICAgcmV0dXJuIGxvYWQoKTtcbiAgfTtcbiAgY29uc3QgbG9hZCA9ICgpID0+IHtcbiAgICBsZXQgdGhpc1JlcXVlc3Q7XG4gICAgcmV0dXJuIHBlbmRpbmdSZXF1ZXN0IHx8ICh0aGlzUmVxdWVzdCA9IHBlbmRpbmdSZXF1ZXN0ID0gbG9hZGVyKCkuY2F0Y2goKGVycikgPT4ge1xuICAgICAgZXJyID0gZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIgOiBuZXcgRXJyb3IoU3RyaW5nKGVycikpO1xuICAgICAgaWYgKHVzZXJPbkVycm9yKSB7XG4gICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgY29uc3QgdXNlclJldHJ5ID0gKCkgPT4gcmVzb2x2ZShyZXRyeSgpKTtcbiAgICAgICAgICBjb25zdCB1c2VyRmFpbCA9ICgpID0+IHJlamVjdChlcnIpO1xuICAgICAgICAgIHVzZXJPbkVycm9yKGVyciwgdXNlclJldHJ5LCB1c2VyRmFpbCwgcmV0cmllcyArIDEpO1xuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRocm93IGVycjtcbiAgICAgIH1cbiAgICB9KS50aGVuKChjb21wKSA9PiB7XG4gICAgICBpZiAodGhpc1JlcXVlc3QgIT09IHBlbmRpbmdSZXF1ZXN0ICYmIHBlbmRpbmdSZXF1ZXN0KSB7XG4gICAgICAgIHJldHVybiBwZW5kaW5nUmVxdWVzdDtcbiAgICAgIH1cbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICFjb21wKSB7XG4gICAgICAgIHdhcm4kMShcbiAgICAgICAgICBgQXN5bmMgY29tcG9uZW50IGxvYWRlciByZXNvbHZlZCB0byB1bmRlZmluZWQuIElmIHlvdSBhcmUgdXNpbmcgcmV0cnkoKSwgbWFrZSBzdXJlIHRvIHJldHVybiBpdHMgcmV0dXJuIHZhbHVlLmBcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGlmIChjb21wICYmIChjb21wLl9fZXNNb2R1bGUgfHwgY29tcFtTeW1ib2wudG9TdHJpbmdUYWddID09PSBcIk1vZHVsZVwiKSkge1xuICAgICAgICBjb21wID0gY29tcC5kZWZhdWx0O1xuICAgICAgfVxuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgY29tcCAmJiAhaXNPYmplY3QoY29tcCkgJiYgIWlzRnVuY3Rpb24oY29tcCkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBJbnZhbGlkIGFzeW5jIGNvbXBvbmVudCBsb2FkIHJlc3VsdDogJHtjb21wfWApO1xuICAgICAgfVxuICAgICAgcmVzb2x2ZWRDb21wID0gY29tcDtcbiAgICAgIHJldHVybiBjb21wO1xuICAgIH0pKTtcbiAgfTtcbiAgcmV0dXJuIGRlZmluZUNvbXBvbmVudCh7XG4gICAgbmFtZTogXCJBc3luY0NvbXBvbmVudFdyYXBwZXJcIixcbiAgICBfX2FzeW5jTG9hZGVyOiBsb2FkLFxuICAgIF9fYXN5bmNIeWRyYXRlKGVsLCBpbnN0YW5jZSwgaHlkcmF0ZSkge1xuICAgICAgY29uc3Qgd2FzQ29ubmVjdGVkID0gZWwuaXNDb25uZWN0ZWQ7XG4gICAgICBsZXQgcGF0Y2hlZCA9IGZhbHNlO1xuICAgICAgKGluc3RhbmNlLmJ1IHx8IChpbnN0YW5jZS5idSA9IFtdKSkucHVzaCgoKSA9PiBwYXRjaGVkID0gdHJ1ZSk7XG4gICAgICBjb25zdCBwZXJmb3JtSHlkcmF0ZSA9ICgpID0+IHtcbiAgICAgICAgaWYgKHBhdGNoZWQpIHtcbiAgICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgICAgd2FybiQxKFxuICAgICAgICAgICAgICBgU2tpcHBpbmcgbGF6eSBoeWRyYXRpb24gZm9yIGNvbXBvbmVudCAnJHtnZXRDb21wb25lbnROYW1lKHJlc29sdmVkQ29tcCkgfHwgcmVzb2x2ZWRDb21wLl9fZmlsZX0nOiBpdCB3YXMgdXBkYXRlZCBiZWZvcmUgbGF6eSBoeWRyYXRpb24gcGVyZm9ybWVkLmBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWVsLnBhcmVudE5vZGUgfHwgd2FzQ29ubmVjdGVkICYmICFlbC5pc0Nvbm5lY3RlZCkgcmV0dXJuO1xuICAgICAgICBoeWRyYXRlKCk7XG4gICAgICB9O1xuICAgICAgY29uc3QgZG9IeWRyYXRlID0gaHlkcmF0ZVN0cmF0ZWd5ID8gKCkgPT4ge1xuICAgICAgICBjb25zdCB0ZWFyZG93biA9IGh5ZHJhdGVTdHJhdGVneShcbiAgICAgICAgICBwZXJmb3JtSHlkcmF0ZSxcbiAgICAgICAgICAoY2IpID0+IGZvckVhY2hFbGVtZW50KGVsLCBjYilcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKHRlYXJkb3duKSB7XG4gICAgICAgICAgKGluc3RhbmNlLmJ1bSB8fCAoaW5zdGFuY2UuYnVtID0gW10pKS5wdXNoKHRlYXJkb3duKTtcbiAgICAgICAgfVxuICAgICAgfSA6IHBlcmZvcm1IeWRyYXRlO1xuICAgICAgaWYgKHJlc29sdmVkQ29tcCkge1xuICAgICAgICBkb0h5ZHJhdGUoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGxvYWQoKS50aGVuKCgpID0+ICFpbnN0YW5jZS5pc1VubW91bnRlZCAmJiBkb0h5ZHJhdGUoKSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBnZXQgX19hc3luY1Jlc29sdmVkKCkge1xuICAgICAgcmV0dXJuIHJlc29sdmVkQ29tcDtcbiAgICB9LFxuICAgIHNldHVwKCkge1xuICAgICAgY29uc3QgaW5zdGFuY2UgPSBjdXJyZW50SW5zdGFuY2U7XG4gICAgICBtYXJrQXN5bmNCb3VuZGFyeShpbnN0YW5jZSk7XG4gICAgICBpZiAocmVzb2x2ZWRDb21wKSB7XG4gICAgICAgIHJldHVybiAoKSA9PiBjcmVhdGVJbm5lckNvbXAocmVzb2x2ZWRDb21wLCBpbnN0YW5jZSk7XG4gICAgICB9XG4gICAgICBjb25zdCBvbkVycm9yID0gKGVycikgPT4ge1xuICAgICAgICBwZW5kaW5nUmVxdWVzdCA9IG51bGw7XG4gICAgICAgIGhhbmRsZUVycm9yKFxuICAgICAgICAgIGVycixcbiAgICAgICAgICBpbnN0YW5jZSxcbiAgICAgICAgICAxMyxcbiAgICAgICAgICAhZXJyb3JDb21wb25lbnRcbiAgICAgICAgKTtcbiAgICAgIH07XG4gICAgICBpZiAoc3VzcGVuc2libGUgJiYgaW5zdGFuY2Uuc3VzcGVuc2UgfHwgaXNJblNTUkNvbXBvbmVudFNldHVwKSB7XG4gICAgICAgIHJldHVybiBsb2FkKCkudGhlbigoY29tcCkgPT4ge1xuICAgICAgICAgIHJldHVybiAoKSA9PiBjcmVhdGVJbm5lckNvbXAoY29tcCwgaW5zdGFuY2UpO1xuICAgICAgICB9KS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgICAgb25FcnJvcihlcnIpO1xuICAgICAgICAgIHJldHVybiAoKSA9PiBlcnJvckNvbXBvbmVudCA/IGNyZWF0ZVZOb2RlKGVycm9yQ29tcG9uZW50LCB7XG4gICAgICAgICAgICBlcnJvcjogZXJyXG4gICAgICAgICAgfSkgOiBudWxsO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGxvYWRlZCA9IHJlZihmYWxzZSk7XG4gICAgICBjb25zdCBlcnJvciA9IHJlZigpO1xuICAgICAgY29uc3QgZGVsYXllZCA9IHJlZighIWRlbGF5KTtcbiAgICAgIGxldCB0aW1lb3V0VGltZXI7XG4gICAgICBsZXQgZGVsYXlUaW1lcjtcbiAgICAgIG9uVW5tb3VudGVkKCgpID0+IHtcbiAgICAgICAgaWYgKHRpbWVvdXRUaW1lciAhPSBudWxsKSBjbGVhclRpbWVvdXQodGltZW91dFRpbWVyKTtcbiAgICAgICAgaWYgKGRlbGF5VGltZXIgIT0gbnVsbCkgY2xlYXJUaW1lb3V0KGRlbGF5VGltZXIpO1xuICAgICAgfSk7XG4gICAgICBpZiAoZGVsYXkpIHtcbiAgICAgICAgZGVsYXlUaW1lciA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIGlmIChpbnN0YW5jZS5pc1VubW91bnRlZCkgcmV0dXJuO1xuICAgICAgICAgIGRlbGF5ZWQudmFsdWUgPSBmYWxzZTtcbiAgICAgICAgfSwgZGVsYXkpO1xuICAgICAgfVxuICAgICAgaWYgKHRpbWVvdXQgIT0gbnVsbCkge1xuICAgICAgICB0aW1lb3V0VGltZXIgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICBpZiAoaW5zdGFuY2UuaXNVbm1vdW50ZWQpIHJldHVybjtcbiAgICAgICAgICBpZiAoIWxvYWRlZC52YWx1ZSAmJiAhZXJyb3IudmFsdWUpIHtcbiAgICAgICAgICAgIGNvbnN0IGVyciA9IG5ldyBFcnJvcihcbiAgICAgICAgICAgICAgYEFzeW5jIGNvbXBvbmVudCB0aW1lZCBvdXQgYWZ0ZXIgJHt0aW1lb3V0fW1zLmBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBvbkVycm9yKGVycik7XG4gICAgICAgICAgICBlcnJvci52YWx1ZSA9IGVycjtcbiAgICAgICAgICB9XG4gICAgICAgIH0sIHRpbWVvdXQpO1xuICAgICAgfVxuICAgICAgbG9hZCgpLnRoZW4oKCkgPT4ge1xuICAgICAgICBpZiAoaW5zdGFuY2UuaXNVbm1vdW50ZWQpIHJldHVybjtcbiAgICAgICAgbG9hZGVkLnZhbHVlID0gdHJ1ZTtcbiAgICAgICAgaWYgKGluc3RhbmNlLnBhcmVudCAmJiBpc0tlZXBBbGl2ZShpbnN0YW5jZS5wYXJlbnQudm5vZGUpKSB7XG4gICAgICAgICAgaW5zdGFuY2UucGFyZW50LnVwZGF0ZSgpO1xuICAgICAgICB9XG4gICAgICB9KS5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgIGlmIChpbnN0YW5jZS5pc1VubW91bnRlZCkge1xuICAgICAgICAgIHBlbmRpbmdSZXF1ZXN0ID0gbnVsbDtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgb25FcnJvcihlcnIpO1xuICAgICAgICBlcnJvci52YWx1ZSA9IGVycjtcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgaWYgKGxvYWRlZC52YWx1ZSAmJiByZXNvbHZlZENvbXApIHtcbiAgICAgICAgICByZXR1cm4gY3JlYXRlSW5uZXJDb21wKHJlc29sdmVkQ29tcCwgaW5zdGFuY2UpO1xuICAgICAgICB9IGVsc2UgaWYgKGVycm9yLnZhbHVlICYmIGVycm9yQ29tcG9uZW50KSB7XG4gICAgICAgICAgcmV0dXJuIGNyZWF0ZVZOb2RlKGVycm9yQ29tcG9uZW50LCB7XG4gICAgICAgICAgICBlcnJvcjogZXJyb3IudmFsdWVcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIGlmIChsb2FkaW5nQ29tcG9uZW50ICYmICFkZWxheWVkLnZhbHVlKSB7XG4gICAgICAgICAgcmV0dXJuIGNyZWF0ZUlubmVyQ29tcChcbiAgICAgICAgICAgIGxvYWRpbmdDb21wb25lbnQsXG4gICAgICAgICAgICBpbnN0YW5jZVxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgfVxuICB9KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUlubmVyQ29tcChjb21wLCBwYXJlbnQpIHtcbiAgY29uc3QgeyByZWY6IHJlZjIsIHByb3BzLCBjaGlsZHJlbiwgY2UgfSA9IHBhcmVudC52bm9kZTtcbiAgY29uc3Qgdm5vZGUgPSBjcmVhdGVWTm9kZShjb21wLCBwcm9wcywgY2hpbGRyZW4pO1xuICB2bm9kZS5yZWYgPSByZWYyO1xuICB2bm9kZS5jZSA9IGNlO1xuICBkZWxldGUgcGFyZW50LnZub2RlLmNlO1xuICByZXR1cm4gdm5vZGU7XG59XG5cbmNvbnN0IGlzS2VlcEFsaXZlID0gKHZub2RlKSA9PiB2bm9kZS50eXBlLl9faXNLZWVwQWxpdmU7XG5jb25zdCBLZWVwQWxpdmVJbXBsID0ge1xuICBuYW1lOiBgS2VlcEFsaXZlYCxcbiAgLy8gTWFya2VyIGZvciBzcGVjaWFsIGhhbmRsaW5nIGluc2lkZSB0aGUgcmVuZGVyZXIuIFdlIGFyZSBub3QgdXNpbmcgYSA9PT1cbiAgLy8gY2hlY2sgZGlyZWN0bHkgb24gS2VlcEFsaXZlIGluIHRoZSByZW5kZXJlciwgYmVjYXVzZSBpbXBvcnRpbmcgaXQgZGlyZWN0bHlcbiAgLy8gd291bGQgcHJldmVudCBpdCBmcm9tIGJlaW5nIHRyZWUtc2hha2VuLlxuICBfX2lzS2VlcEFsaXZlOiB0cnVlLFxuICBwcm9wczoge1xuICAgIGluY2x1ZGU6IFtTdHJpbmcsIFJlZ0V4cCwgQXJyYXldLFxuICAgIGV4Y2x1ZGU6IFtTdHJpbmcsIFJlZ0V4cCwgQXJyYXldLFxuICAgIG1heDogW1N0cmluZywgTnVtYmVyXVxuICB9LFxuICBzZXR1cChwcm9wcywgeyBzbG90cyB9KSB7XG4gICAgY29uc3QgaW5zdGFuY2UgPSBnZXRDdXJyZW50SW5zdGFuY2UoKTtcbiAgICBjb25zdCBzaGFyZWRDb250ZXh0ID0gaW5zdGFuY2UuY3R4O1xuICAgIGlmICghc2hhcmVkQ29udGV4dC5yZW5kZXJlcikge1xuICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgY29uc3QgY2hpbGRyZW4gPSBzbG90cy5kZWZhdWx0ICYmIHNsb3RzLmRlZmF1bHQoKTtcbiAgICAgICAgcmV0dXJuIGNoaWxkcmVuICYmIGNoaWxkcmVuLmxlbmd0aCA9PT0gMSA/IGNoaWxkcmVuWzBdIDogY2hpbGRyZW47XG4gICAgICB9O1xuICAgIH1cbiAgICBjb25zdCBjYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gICAgY29uc3Qga2V5cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gICAgbGV0IGN1cnJlbnQgPSBudWxsO1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykge1xuICAgICAgaW5zdGFuY2UuX192X2NhY2hlID0gY2FjaGU7XG4gICAgfVxuICAgIGNvbnN0IHBhcmVudFN1c3BlbnNlID0gaW5zdGFuY2Uuc3VzcGVuc2U7XG4gICAgY29uc3Qge1xuICAgICAgcmVuZGVyZXI6IHtcbiAgICAgICAgcDogcGF0Y2gsXG4gICAgICAgIG06IG1vdmUsXG4gICAgICAgIHVtOiBfdW5tb3VudCxcbiAgICAgICAgbzogeyBjcmVhdGVFbGVtZW50IH1cbiAgICAgIH1cbiAgICB9ID0gc2hhcmVkQ29udGV4dDtcbiAgICBjb25zdCBzdG9yYWdlQ29udGFpbmVyID0gY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICBzaGFyZWRDb250ZXh0LmFjdGl2YXRlID0gKHZub2RlLCBjb250YWluZXIsIGFuY2hvciwgbmFtZXNwYWNlLCBvcHRpbWl6ZWQpID0+IHtcbiAgICAgIGNvbnN0IGluc3RhbmNlMiA9IHZub2RlLmNvbXBvbmVudDtcbiAgICAgIG1vdmUodm5vZGUsIGNvbnRhaW5lciwgYW5jaG9yLCAwLCBwYXJlbnRTdXNwZW5zZSk7XG4gICAgICBwYXRjaChcbiAgICAgICAgaW5zdGFuY2UyLnZub2RlLFxuICAgICAgICB2bm9kZSxcbiAgICAgICAgY29udGFpbmVyLFxuICAgICAgICBhbmNob3IsXG4gICAgICAgIGluc3RhbmNlMixcbiAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgdm5vZGUuc2xvdFNjb3BlSWRzLFxuICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICk7XG4gICAgICBxdWV1ZVBvc3RSZW5kZXJFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpbnN0YW5jZTIuaXNEZWFjdGl2YXRlZCA9IGZhbHNlO1xuICAgICAgICBpZiAoaW5zdGFuY2UyLmEpIHtcbiAgICAgICAgICBpbnZva2VBcnJheUZucyhpbnN0YW5jZTIuYSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgdm5vZGVIb29rID0gdm5vZGUucHJvcHMgJiYgdm5vZGUucHJvcHMub25Wbm9kZU1vdW50ZWQ7XG4gICAgICAgIGlmICh2bm9kZUhvb2spIHtcbiAgICAgICAgICBpbnZva2VWTm9kZUhvb2sodm5vZGVIb29rLCBpbnN0YW5jZTIucGFyZW50LCB2bm9kZSk7XG4gICAgICAgIH1cbiAgICAgIH0sIHBhcmVudFN1c3BlbnNlKTtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykge1xuICAgICAgICBkZXZ0b29sc0NvbXBvbmVudEFkZGVkKGluc3RhbmNlMik7XG4gICAgICB9XG4gICAgfTtcbiAgICBzaGFyZWRDb250ZXh0LmRlYWN0aXZhdGUgPSAodm5vZGUpID0+IHtcbiAgICAgIGNvbnN0IGluc3RhbmNlMiA9IHZub2RlLmNvbXBvbmVudDtcbiAgICAgIGludmFsaWRhdGVNb3VudChpbnN0YW5jZTIubSk7XG4gICAgICBpbnZhbGlkYXRlTW91bnQoaW5zdGFuY2UyLmEpO1xuICAgICAgbW92ZSh2bm9kZSwgc3RvcmFnZUNvbnRhaW5lciwgbnVsbCwgMSwgcGFyZW50U3VzcGVuc2UpO1xuICAgICAgcXVldWVQb3N0UmVuZGVyRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGluc3RhbmNlMi5kYSkge1xuICAgICAgICAgIGludm9rZUFycmF5Rm5zKGluc3RhbmNlMi5kYSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgdm5vZGVIb29rID0gdm5vZGUucHJvcHMgJiYgdm5vZGUucHJvcHMub25Wbm9kZVVubW91bnRlZDtcbiAgICAgICAgaWYgKHZub2RlSG9vaykge1xuICAgICAgICAgIGludm9rZVZOb2RlSG9vayh2bm9kZUhvb2ssIGluc3RhbmNlMi5wYXJlbnQsIHZub2RlKTtcbiAgICAgICAgfVxuICAgICAgICBpbnN0YW5jZTIuaXNEZWFjdGl2YXRlZCA9IHRydWU7XG4gICAgICB9LCBwYXJlbnRTdXNwZW5zZSk7XG4gICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pIHtcbiAgICAgICAgZGV2dG9vbHNDb21wb25lbnRBZGRlZChpbnN0YW5jZTIpO1xuICAgICAgfVxuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgdHJ1ZSkge1xuICAgICAgICBpbnN0YW5jZTIuX19rZWVwQWxpdmVTdG9yYWdlQ29udGFpbmVyID0gc3RvcmFnZUNvbnRhaW5lcjtcbiAgICAgIH1cbiAgICB9O1xuICAgIGZ1bmN0aW9uIHVubW91bnQodm5vZGUpIHtcbiAgICAgIHJlc2V0U2hhcGVGbGFnKHZub2RlKTtcbiAgICAgIF91bm1vdW50KHZub2RlLCBpbnN0YW5jZSwgcGFyZW50U3VzcGVuc2UsIHRydWUpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBwcnVuZUNhY2hlKGZpbHRlcikge1xuICAgICAgY2FjaGUuZm9yRWFjaCgodm5vZGUsIGtleSkgPT4ge1xuICAgICAgICBjb25zdCBuYW1lID0gZ2V0Q29tcG9uZW50TmFtZShcbiAgICAgICAgICBpc0FzeW5jV3JhcHBlcih2bm9kZSkgPyB2bm9kZS50eXBlLl9fYXN5bmNSZXNvbHZlZCB8fCB7fSA6IHZub2RlLnR5cGVcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKG5hbWUgJiYgIWZpbHRlcihuYW1lKSkge1xuICAgICAgICAgIHBydW5lQ2FjaGVFbnRyeShrZXkpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gICAgZnVuY3Rpb24gcHJ1bmVDYWNoZUVudHJ5KGtleSkge1xuICAgICAgY29uc3QgY2FjaGVkID0gY2FjaGUuZ2V0KGtleSk7XG4gICAgICBpZiAoY2FjaGVkICYmICghY3VycmVudCB8fCAhaXNTYW1lVk5vZGVUeXBlKGNhY2hlZCwgY3VycmVudCkpKSB7XG4gICAgICAgIHVubW91bnQoY2FjaGVkKTtcbiAgICAgIH0gZWxzZSBpZiAoY3VycmVudCkge1xuICAgICAgICByZXNldFNoYXBlRmxhZyhjdXJyZW50KTtcbiAgICAgIH1cbiAgICAgIGNhY2hlLmRlbGV0ZShrZXkpO1xuICAgICAga2V5cy5kZWxldGUoa2V5KTtcbiAgICB9XG4gICAgd2F0Y2goXG4gICAgICAoKSA9PiBbcHJvcHMuaW5jbHVkZSwgcHJvcHMuZXhjbHVkZV0sXG4gICAgICAoW2luY2x1ZGUsIGV4Y2x1ZGVdKSA9PiB7XG4gICAgICAgIGluY2x1ZGUgJiYgcHJ1bmVDYWNoZSgobmFtZSkgPT4gbWF0Y2hlcyhpbmNsdWRlLCBuYW1lKSk7XG4gICAgICAgIGV4Y2x1ZGUgJiYgcHJ1bmVDYWNoZSgobmFtZSkgPT4gIW1hdGNoZXMoZXhjbHVkZSwgbmFtZSkpO1xuICAgICAgfSxcbiAgICAgIC8vIHBydW5lIHBvc3QtcmVuZGVyIGFmdGVyIGBjdXJyZW50YCBoYXMgYmVlbiB1cGRhdGVkXG4gICAgICB7IGZsdXNoOiBcInBvc3RcIiwgZGVlcDogdHJ1ZSB9XG4gICAgKTtcbiAgICBsZXQgcGVuZGluZ0NhY2hlS2V5ID0gbnVsbDtcbiAgICBjb25zdCBjYWNoZVN1YnRyZWUgPSAoKSA9PiB7XG4gICAgICBpZiAocGVuZGluZ0NhY2hlS2V5ICE9IG51bGwpIHtcbiAgICAgICAgaWYgKGlzU3VzcGVuc2UoaW5zdGFuY2Uuc3ViVHJlZS50eXBlKSkge1xuICAgICAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdCgoKSA9PiB7XG4gICAgICAgICAgICBjYWNoZS5zZXQocGVuZGluZ0NhY2hlS2V5LCBnZXRJbm5lckNoaWxkKGluc3RhbmNlLnN1YlRyZWUpKTtcbiAgICAgICAgICB9LCBpbnN0YW5jZS5zdWJUcmVlLnN1c3BlbnNlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjYWNoZS5zZXQocGVuZGluZ0NhY2hlS2V5LCBnZXRJbm5lckNoaWxkKGluc3RhbmNlLnN1YlRyZWUpKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgb25Nb3VudGVkKGNhY2hlU3VidHJlZSk7XG4gICAgb25VcGRhdGVkKGNhY2hlU3VidHJlZSk7XG4gICAgb25CZWZvcmVVbm1vdW50KCgpID0+IHtcbiAgICAgIGNhY2hlLmZvckVhY2goKGNhY2hlZCkgPT4ge1xuICAgICAgICBjb25zdCB7IHN1YlRyZWUsIHN1c3BlbnNlIH0gPSBpbnN0YW5jZTtcbiAgICAgICAgY29uc3Qgdm5vZGUgPSBnZXRJbm5lckNoaWxkKHN1YlRyZWUpO1xuICAgICAgICBpZiAoY2FjaGVkLnR5cGUgPT09IHZub2RlLnR5cGUgJiYgY2FjaGVkLmtleSA9PT0gdm5vZGUua2V5KSB7XG4gICAgICAgICAgcmVzZXRTaGFwZUZsYWcodm5vZGUpO1xuICAgICAgICAgIGNvbnN0IGRhID0gdm5vZGUuY29tcG9uZW50LmRhO1xuICAgICAgICAgIGRhICYmIHF1ZXVlUG9zdFJlbmRlckVmZmVjdChkYSwgc3VzcGVuc2UpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB1bm1vdW50KGNhY2hlZCk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgcGVuZGluZ0NhY2hlS2V5ID0gbnVsbDtcbiAgICAgIGlmICghc2xvdHMuZGVmYXVsdCkge1xuICAgICAgICByZXR1cm4gY3VycmVudCA9IG51bGw7XG4gICAgICB9XG4gICAgICBjb25zdCBjaGlsZHJlbiA9IHNsb3RzLmRlZmF1bHQoKTtcbiAgICAgIGNvbnN0IHJhd1ZOb2RlID0gY2hpbGRyZW5bMF07XG4gICAgICBpZiAoY2hpbGRyZW4ubGVuZ3RoID4gMSkge1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIHdhcm4kMShgS2VlcEFsaXZlIHNob3VsZCBjb250YWluIGV4YWN0bHkgb25lIGNvbXBvbmVudCBjaGlsZC5gKTtcbiAgICAgICAgfVxuICAgICAgICBjdXJyZW50ID0gbnVsbDtcbiAgICAgICAgcmV0dXJuIGNoaWxkcmVuO1xuICAgICAgfSBlbHNlIGlmICghaXNWTm9kZShyYXdWTm9kZSkgfHwgIShyYXdWTm9kZS5zaGFwZUZsYWcgJiA0KSAmJiAhKHJhd1ZOb2RlLnNoYXBlRmxhZyAmIDEyOCkpIHtcbiAgICAgICAgY3VycmVudCA9IG51bGw7XG4gICAgICAgIHJldHVybiByYXdWTm9kZTtcbiAgICAgIH1cbiAgICAgIGxldCB2bm9kZSA9IGdldElubmVyQ2hpbGQocmF3Vk5vZGUpO1xuICAgICAgaWYgKHZub2RlLnR5cGUgPT09IENvbW1lbnQpIHtcbiAgICAgICAgY3VycmVudCA9IG51bGw7XG4gICAgICAgIHJldHVybiB2bm9kZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNvbXAgPSB2bm9kZS50eXBlO1xuICAgICAgY29uc3QgbmFtZSA9IGdldENvbXBvbmVudE5hbWUoXG4gICAgICAgIGlzQXN5bmNXcmFwcGVyKHZub2RlKSA/IHZub2RlLnR5cGUuX19hc3luY1Jlc29sdmVkIHx8IHt9IDogY29tcFxuICAgICAgKTtcbiAgICAgIGNvbnN0IHsgaW5jbHVkZSwgZXhjbHVkZSwgbWF4IH0gPSBwcm9wcztcbiAgICAgIGlmIChpbmNsdWRlICYmICghbmFtZSB8fCAhbWF0Y2hlcyhpbmNsdWRlLCBuYW1lKSkgfHwgZXhjbHVkZSAmJiBuYW1lICYmIG1hdGNoZXMoZXhjbHVkZSwgbmFtZSkpIHtcbiAgICAgICAgdm5vZGUuc2hhcGVGbGFnICY9IC0yNTc7XG4gICAgICAgIGN1cnJlbnQgPSB2bm9kZTtcbiAgICAgICAgcmV0dXJuIHJhd1ZOb2RlO1xuICAgICAgfVxuICAgICAgY29uc3Qga2V5ID0gdm5vZGUua2V5ID09IG51bGwgPyBjb21wIDogdm5vZGUua2V5O1xuICAgICAgY29uc3QgY2FjaGVkVk5vZGUgPSBjYWNoZS5nZXQoa2V5KTtcbiAgICAgIGlmICh2bm9kZS5lbCkge1xuICAgICAgICB2bm9kZSA9IGNsb25lVk5vZGUodm5vZGUpO1xuICAgICAgICBpZiAocmF3Vk5vZGUuc2hhcGVGbGFnICYgMTI4KSB7XG4gICAgICAgICAgcmF3Vk5vZGUuc3NDb250ZW50ID0gdm5vZGU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHBlbmRpbmdDYWNoZUtleSA9IGtleTtcbiAgICAgIGlmIChjYWNoZWRWTm9kZSkge1xuICAgICAgICB2bm9kZS5lbCA9IGNhY2hlZFZOb2RlLmVsO1xuICAgICAgICB2bm9kZS5jb21wb25lbnQgPSBjYWNoZWRWTm9kZS5jb21wb25lbnQ7XG4gICAgICAgIGlmICh2bm9kZS50cmFuc2l0aW9uKSB7XG4gICAgICAgICAgc2V0VHJhbnNpdGlvbkhvb2tzKHZub2RlLCB2bm9kZS50cmFuc2l0aW9uKTtcbiAgICAgICAgfVxuICAgICAgICB2bm9kZS5zaGFwZUZsYWcgfD0gNTEyO1xuICAgICAgICBrZXlzLmRlbGV0ZShrZXkpO1xuICAgICAgICBrZXlzLmFkZChrZXkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAga2V5cy5hZGQoa2V5KTtcbiAgICAgICAgaWYgKG1heCAmJiBrZXlzLnNpemUgPiBwYXJzZUludChtYXgsIDEwKSkge1xuICAgICAgICAgIHBydW5lQ2FjaGVFbnRyeShrZXlzLnZhbHVlcygpLm5leHQoKS52YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHZub2RlLnNoYXBlRmxhZyB8PSAyNTY7XG4gICAgICBjdXJyZW50ID0gdm5vZGU7XG4gICAgICByZXR1cm4gaXNTdXNwZW5zZShyYXdWTm9kZS50eXBlKSA/IHJhd1ZOb2RlIDogdm5vZGU7XG4gICAgfTtcbiAgfVxufTtcbmNvbnN0IEtlZXBBbGl2ZSA9IEtlZXBBbGl2ZUltcGw7XG5mdW5jdGlvbiBtYXRjaGVzKHBhdHRlcm4sIG5hbWUpIHtcbiAgaWYgKGlzQXJyYXkocGF0dGVybikpIHtcbiAgICByZXR1cm4gcGF0dGVybi5zb21lKChwKSA9PiBtYXRjaGVzKHAsIG5hbWUpKTtcbiAgfSBlbHNlIGlmIChpc1N0cmluZyhwYXR0ZXJuKSkge1xuICAgIHJldHVybiBwYXR0ZXJuLnNwbGl0KFwiLFwiKS5pbmNsdWRlcyhuYW1lKTtcbiAgfSBlbHNlIGlmIChpc1JlZ0V4cChwYXR0ZXJuKSkge1xuICAgIHBhdHRlcm4ubGFzdEluZGV4ID0gMDtcbiAgICByZXR1cm4gcGF0dGVybi50ZXN0KG5hbWUpO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIG9uQWN0aXZhdGVkKGhvb2ssIHRhcmdldCkge1xuICByZWdpc3RlcktlZXBBbGl2ZUhvb2soaG9vaywgXCJhXCIsIHRhcmdldCk7XG59XG5mdW5jdGlvbiBvbkRlYWN0aXZhdGVkKGhvb2ssIHRhcmdldCkge1xuICByZWdpc3RlcktlZXBBbGl2ZUhvb2soaG9vaywgXCJkYVwiLCB0YXJnZXQpO1xufVxuZnVuY3Rpb24gcmVnaXN0ZXJLZWVwQWxpdmVIb29rKGhvb2ssIHR5cGUsIHRhcmdldCA9IGN1cnJlbnRJbnN0YW5jZSkge1xuICBjb25zdCB3cmFwcGVkSG9vayA9IGhvb2suX193ZGMgfHwgKGhvb2suX193ZGMgPSAoKSA9PiB7XG4gICAgbGV0IGN1cnJlbnQgPSB0YXJnZXQ7XG4gICAgd2hpbGUgKGN1cnJlbnQpIHtcbiAgICAgIGlmIChjdXJyZW50LmlzRGVhY3RpdmF0ZWQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY3VycmVudCA9IGN1cnJlbnQucGFyZW50O1xuICAgIH1cbiAgICByZXR1cm4gaG9vaygpO1xuICB9KTtcbiAgaW5qZWN0SG9vayh0eXBlLCB3cmFwcGVkSG9vaywgdGFyZ2V0KTtcbiAgaWYgKHRhcmdldCkge1xuICAgIGxldCBjdXJyZW50ID0gdGFyZ2V0LnBhcmVudDtcbiAgICB3aGlsZSAoY3VycmVudCAmJiBjdXJyZW50LnBhcmVudCkge1xuICAgICAgaWYgKGlzS2VlcEFsaXZlKGN1cnJlbnQucGFyZW50LnZub2RlKSkge1xuICAgICAgICBpbmplY3RUb0tlZXBBbGl2ZVJvb3Qod3JhcHBlZEhvb2ssIHR5cGUsIHRhcmdldCwgY3VycmVudCk7XG4gICAgICB9XG4gICAgICBjdXJyZW50ID0gY3VycmVudC5wYXJlbnQ7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBpbmplY3RUb0tlZXBBbGl2ZVJvb3QoaG9vaywgdHlwZSwgdGFyZ2V0LCBrZWVwQWxpdmVSb290KSB7XG4gIGNvbnN0IGluamVjdGVkID0gaW5qZWN0SG9vayhcbiAgICB0eXBlLFxuICAgIGhvb2ssXG4gICAga2VlcEFsaXZlUm9vdCxcbiAgICB0cnVlXG4gICAgLyogcHJlcGVuZCAqL1xuICApO1xuICBvblVubW91bnRlZCgoKSA9PiB7XG4gICAgcmVtb3ZlKGtlZXBBbGl2ZVJvb3RbdHlwZV0sIGluamVjdGVkKTtcbiAgfSwgdGFyZ2V0KTtcbn1cbmZ1bmN0aW9uIHJlc2V0U2hhcGVGbGFnKHZub2RlKSB7XG4gIHZub2RlLnNoYXBlRmxhZyAmPSAtMjU3O1xuICB2bm9kZS5zaGFwZUZsYWcgJj0gLTUxMztcbn1cbmZ1bmN0aW9uIGdldElubmVyQ2hpbGQodm5vZGUpIHtcbiAgcmV0dXJuIHZub2RlLnNoYXBlRmxhZyAmIDEyOCA/IHZub2RlLnNzQ29udGVudCA6IHZub2RlO1xufVxuXG5mdW5jdGlvbiBpbmplY3RIb29rKHR5cGUsIGhvb2ssIHRhcmdldCA9IGN1cnJlbnRJbnN0YW5jZSwgcHJlcGVuZCA9IGZhbHNlKSB7XG4gIGlmICh0YXJnZXQpIHtcbiAgICBjb25zdCBob29rcyA9IHRhcmdldFt0eXBlXSB8fCAodGFyZ2V0W3R5cGVdID0gW10pO1xuICAgIGNvbnN0IHdyYXBwZWRIb29rID0gaG9vay5fX3dlaCB8fCAoaG9vay5fX3dlaCA9ICguLi5hcmdzKSA9PiB7XG4gICAgICBwYXVzZVRyYWNraW5nKCk7XG4gICAgICBjb25zdCByZXNldCA9IHNldEN1cnJlbnRJbnN0YW5jZSh0YXJnZXQpO1xuICAgICAgY29uc3QgcmVzID0gY2FsbFdpdGhBc3luY0Vycm9ySGFuZGxpbmcoaG9vaywgdGFyZ2V0LCB0eXBlLCBhcmdzKTtcbiAgICAgIHJlc2V0KCk7XG4gICAgICByZXNldFRyYWNraW5nKCk7XG4gICAgICByZXR1cm4gcmVzO1xuICAgIH0pO1xuICAgIGlmIChwcmVwZW5kKSB7XG4gICAgICBob29rcy51bnNoaWZ0KHdyYXBwZWRIb29rKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaG9va3MucHVzaCh3cmFwcGVkSG9vayk7XG4gICAgfVxuICAgIHJldHVybiB3cmFwcGVkSG9vaztcbiAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgY29uc3QgYXBpTmFtZSA9IHRvSGFuZGxlcktleShFcnJvclR5cGVTdHJpbmdzJDFbdHlwZV0ucmVwbGFjZSgvIGhvb2skLywgXCJcIikpO1xuICAgIHdhcm4kMShcbiAgICAgIGAke2FwaU5hbWV9IGlzIGNhbGxlZCB3aGVuIHRoZXJlIGlzIG5vIGFjdGl2ZSBjb21wb25lbnQgaW5zdGFuY2UgdG8gYmUgYXNzb2NpYXRlZCB3aXRoLiBMaWZlY3ljbGUgaW5qZWN0aW9uIEFQSXMgY2FuIG9ubHkgYmUgdXNlZCBkdXJpbmcgZXhlY3V0aW9uIG9mIHNldHVwKCkuYCArIChgIElmIHlvdSBhcmUgdXNpbmcgYXN5bmMgc2V0dXAoKSwgbWFrZSBzdXJlIHRvIHJlZ2lzdGVyIGxpZmVjeWNsZSBob29rcyBiZWZvcmUgdGhlIGZpcnN0IGF3YWl0IHN0YXRlbWVudC5gIClcbiAgICApO1xuICB9XG59XG5jb25zdCBjcmVhdGVIb29rID0gKGxpZmVjeWNsZSkgPT4gKGhvb2ssIHRhcmdldCA9IGN1cnJlbnRJbnN0YW5jZSkgPT4ge1xuICBpZiAoIWlzSW5TU1JDb21wb25lbnRTZXR1cCB8fCBsaWZlY3ljbGUgPT09IFwic3BcIikge1xuICAgIGluamVjdEhvb2sobGlmZWN5Y2xlLCAoLi4uYXJncykgPT4gaG9vayguLi5hcmdzKSwgdGFyZ2V0KTtcbiAgfVxufTtcbmNvbnN0IG9uQmVmb3JlTW91bnQgPSBjcmVhdGVIb29rKFwiYm1cIik7XG5jb25zdCBvbk1vdW50ZWQgPSBjcmVhdGVIb29rKFwibVwiKTtcbmNvbnN0IG9uQmVmb3JlVXBkYXRlID0gY3JlYXRlSG9vayhcbiAgXCJidVwiXG4pO1xuY29uc3Qgb25VcGRhdGVkID0gY3JlYXRlSG9vayhcInVcIik7XG5jb25zdCBvbkJlZm9yZVVubW91bnQgPSBjcmVhdGVIb29rKFxuICBcImJ1bVwiXG4pO1xuY29uc3Qgb25Vbm1vdW50ZWQgPSBjcmVhdGVIb29rKFwidW1cIik7XG5jb25zdCBvblNlcnZlclByZWZldGNoID0gY3JlYXRlSG9vayhcbiAgXCJzcFwiXG4pO1xuY29uc3Qgb25SZW5kZXJUcmlnZ2VyZWQgPSBjcmVhdGVIb29rKFwicnRnXCIpO1xuY29uc3Qgb25SZW5kZXJUcmFja2VkID0gY3JlYXRlSG9vayhcInJ0Y1wiKTtcbmZ1bmN0aW9uIG9uRXJyb3JDYXB0dXJlZChob29rLCB0YXJnZXQgPSBjdXJyZW50SW5zdGFuY2UpIHtcbiAgaW5qZWN0SG9vayhcImVjXCIsIGhvb2ssIHRhcmdldCk7XG59XG5cbmNvbnN0IENPTVBPTkVOVFMgPSBcImNvbXBvbmVudHNcIjtcbmNvbnN0IERJUkVDVElWRVMgPSBcImRpcmVjdGl2ZXNcIjtcbmZ1bmN0aW9uIHJlc29sdmVDb21wb25lbnQobmFtZSwgbWF5YmVTZWxmUmVmZXJlbmNlKSB7XG4gIHJldHVybiByZXNvbHZlQXNzZXQoQ09NUE9ORU5UUywgbmFtZSwgdHJ1ZSwgbWF5YmVTZWxmUmVmZXJlbmNlKSB8fCBuYW1lO1xufVxuY29uc3QgTlVMTF9EWU5BTUlDX0NPTVBPTkVOVCA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKFwidi1uZGNcIik7XG5mdW5jdGlvbiByZXNvbHZlRHluYW1pY0NvbXBvbmVudChjb21wb25lbnQpIHtcbiAgaWYgKGlzU3RyaW5nKGNvbXBvbmVudCkpIHtcbiAgICByZXR1cm4gcmVzb2x2ZUFzc2V0KENPTVBPTkVOVFMsIGNvbXBvbmVudCwgZmFsc2UpIHx8IGNvbXBvbmVudDtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gY29tcG9uZW50IHx8IE5VTExfRFlOQU1JQ19DT01QT05FTlQ7XG4gIH1cbn1cbmZ1bmN0aW9uIHJlc29sdmVEaXJlY3RpdmUobmFtZSkge1xuICByZXR1cm4gcmVzb2x2ZUFzc2V0KERJUkVDVElWRVMsIG5hbWUpO1xufVxuZnVuY3Rpb24gcmVzb2x2ZUFzc2V0KHR5cGUsIG5hbWUsIHdhcm5NaXNzaW5nID0gdHJ1ZSwgbWF5YmVTZWxmUmVmZXJlbmNlID0gZmFsc2UpIHtcbiAgY29uc3QgaW5zdGFuY2UgPSBjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UgfHwgY3VycmVudEluc3RhbmNlO1xuICBpZiAoaW5zdGFuY2UpIHtcbiAgICBjb25zdCBDb21wb25lbnQgPSBpbnN0YW5jZS50eXBlO1xuICAgIGlmICh0eXBlID09PSBDT01QT05FTlRTKSB7XG4gICAgICBjb25zdCBzZWxmTmFtZSA9IGdldENvbXBvbmVudE5hbWUoXG4gICAgICAgIENvbXBvbmVudCxcbiAgICAgICAgZmFsc2VcbiAgICAgICk7XG4gICAgICBpZiAoc2VsZk5hbWUgJiYgKHNlbGZOYW1lID09PSBuYW1lIHx8IHNlbGZOYW1lID09PSBjYW1lbGl6ZShuYW1lKSB8fCBzZWxmTmFtZSA9PT0gY2FwaXRhbGl6ZShjYW1lbGl6ZShuYW1lKSkpKSB7XG4gICAgICAgIHJldHVybiBDb21wb25lbnQ7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHJlcyA9IChcbiAgICAgIC8vIGxvY2FsIHJlZ2lzdHJhdGlvblxuICAgICAgLy8gY2hlY2sgaW5zdGFuY2VbdHlwZV0gZmlyc3Qgd2hpY2ggaXMgcmVzb2x2ZWQgZm9yIG9wdGlvbnMgQVBJXG4gICAgICByZXNvbHZlKGluc3RhbmNlW3R5cGVdIHx8IENvbXBvbmVudFt0eXBlXSwgbmFtZSkgfHwgLy8gZ2xvYmFsIHJlZ2lzdHJhdGlvblxuICAgICAgcmVzb2x2ZShpbnN0YW5jZS5hcHBDb250ZXh0W3R5cGVdLCBuYW1lKVxuICAgICk7XG4gICAgaWYgKCFyZXMgJiYgbWF5YmVTZWxmUmVmZXJlbmNlKSB7XG4gICAgICByZXR1cm4gQ29tcG9uZW50O1xuICAgIH1cbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB3YXJuTWlzc2luZyAmJiAhcmVzKSB7XG4gICAgICBjb25zdCBleHRyYSA9IHR5cGUgPT09IENPTVBPTkVOVFMgPyBgXG5JZiB0aGlzIGlzIGEgbmF0aXZlIGN1c3RvbSBlbGVtZW50LCBtYWtlIHN1cmUgdG8gZXhjbHVkZSBpdCBmcm9tIGNvbXBvbmVudCByZXNvbHV0aW9uIHZpYSBjb21waWxlck9wdGlvbnMuaXNDdXN0b21FbGVtZW50LmAgOiBgYDtcbiAgICAgIHdhcm4kMShgRmFpbGVkIHRvIHJlc29sdmUgJHt0eXBlLnNsaWNlKDAsIC0xKX06ICR7bmFtZX0ke2V4dHJhfWApO1xuICAgIH1cbiAgICByZXR1cm4gcmVzO1xuICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICB3YXJuJDEoXG4gICAgICBgcmVzb2x2ZSR7Y2FwaXRhbGl6ZSh0eXBlLnNsaWNlKDAsIC0xKSl9IGNhbiBvbmx5IGJlIHVzZWQgaW4gcmVuZGVyKCkgb3Igc2V0dXAoKS5gXG4gICAgKTtcbiAgfVxufVxuZnVuY3Rpb24gcmVzb2x2ZShyZWdpc3RyeSwgbmFtZSkge1xuICByZXR1cm4gcmVnaXN0cnkgJiYgKHJlZ2lzdHJ5W25hbWVdIHx8IHJlZ2lzdHJ5W2NhbWVsaXplKG5hbWUpXSB8fCByZWdpc3RyeVtjYXBpdGFsaXplKGNhbWVsaXplKG5hbWUpKV0pO1xufVxuXG5mdW5jdGlvbiByZW5kZXJMaXN0KHNvdXJjZSwgcmVuZGVySXRlbSwgY2FjaGUsIGluZGV4KSB7XG4gIGxldCByZXQ7XG4gIGNvbnN0IGNhY2hlZCA9IGNhY2hlICYmIGNhY2hlW2luZGV4XTtcbiAgY29uc3Qgc291cmNlSXNBcnJheSA9IGlzQXJyYXkoc291cmNlKTtcbiAgaWYgKHNvdXJjZUlzQXJyYXkgfHwgaXNTdHJpbmcoc291cmNlKSkge1xuICAgIGNvbnN0IHNvdXJjZUlzUmVhY3RpdmVBcnJheSA9IHNvdXJjZUlzQXJyYXkgJiYgaXNSZWFjdGl2ZShzb3VyY2UpO1xuICAgIGxldCBuZWVkc1dyYXAgPSBmYWxzZTtcbiAgICBsZXQgaXNSZWFkb25seVNvdXJjZSA9IGZhbHNlO1xuICAgIGlmIChzb3VyY2VJc1JlYWN0aXZlQXJyYXkpIHtcbiAgICAgIG5lZWRzV3JhcCA9ICFpc1NoYWxsb3coc291cmNlKTtcbiAgICAgIGlzUmVhZG9ubHlTb3VyY2UgPSBpc1JlYWRvbmx5KHNvdXJjZSk7XG4gICAgICBzb3VyY2UgPSBzaGFsbG93UmVhZEFycmF5KHNvdXJjZSk7XG4gICAgfVxuICAgIHJldCA9IG5ldyBBcnJheShzb3VyY2UubGVuZ3RoKTtcbiAgICBmb3IgKGxldCBpID0gMCwgbCA9IHNvdXJjZS5sZW5ndGg7IGkgPCBsOyBpKyspIHtcbiAgICAgIHJldFtpXSA9IHJlbmRlckl0ZW0oXG4gICAgICAgIG5lZWRzV3JhcCA/IGlzUmVhZG9ubHlTb3VyY2UgPyB0b1JlYWRvbmx5KHRvUmVhY3RpdmUoc291cmNlW2ldKSkgOiB0b1JlYWN0aXZlKHNvdXJjZVtpXSkgOiBzb3VyY2VbaV0sXG4gICAgICAgIGksXG4gICAgICAgIHZvaWQgMCxcbiAgICAgICAgY2FjaGVkICYmIGNhY2hlZFtpXVxuICAgICAgKTtcbiAgICB9XG4gIH0gZWxzZSBpZiAodHlwZW9mIHNvdXJjZSA9PT0gXCJudW1iZXJcIikge1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICghTnVtYmVyLmlzSW50ZWdlcihzb3VyY2UpIHx8IHNvdXJjZSA8IDApKSB7XG4gICAgICB3YXJuJDEoXG4gICAgICAgIGBUaGUgdi1mb3IgcmFuZ2UgZXhwZWN0cyBhIHBvc2l0aXZlIGludGVnZXIgdmFsdWUgYnV0IGdvdCAke3NvdXJjZX0uYFxuICAgICAgKTtcbiAgICAgIHJldCA9IFtdO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXQgPSBuZXcgQXJyYXkoc291cmNlKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgc291cmNlOyBpKyspIHtcbiAgICAgICAgcmV0W2ldID0gcmVuZGVySXRlbShpICsgMSwgaSwgdm9pZCAwLCBjYWNoZWQgJiYgY2FjaGVkW2ldKTtcbiAgICAgIH1cbiAgICB9XG4gIH0gZWxzZSBpZiAoaXNPYmplY3Qoc291cmNlKSkge1xuICAgIGlmIChzb3VyY2VbU3ltYm9sLml0ZXJhdG9yXSkge1xuICAgICAgcmV0ID0gQXJyYXkuZnJvbShcbiAgICAgICAgc291cmNlLFxuICAgICAgICAoaXRlbSwgaSkgPT4gcmVuZGVySXRlbShpdGVtLCBpLCB2b2lkIDAsIGNhY2hlZCAmJiBjYWNoZWRbaV0pXG4gICAgICApO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXMoc291cmNlKTtcbiAgICAgIHJldCA9IG5ldyBBcnJheShrZXlzLmxlbmd0aCk7XG4gICAgICBmb3IgKGxldCBpID0gMCwgbCA9IGtleXMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IGtleSA9IGtleXNbaV07XG4gICAgICAgIHJldFtpXSA9IHJlbmRlckl0ZW0oc291cmNlW2tleV0sIGtleSwgaSwgY2FjaGVkICYmIGNhY2hlZFtpXSk7XG4gICAgICB9XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHJldCA9IFtdO1xuICB9XG4gIGlmIChjYWNoZSkge1xuICAgIGNhY2hlW2luZGV4XSA9IHJldDtcbiAgfVxuICByZXR1cm4gcmV0O1xufVxuXG5mdW5jdGlvbiBjcmVhdGVTbG90cyhzbG90cywgZHluYW1pY1Nsb3RzKSB7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgZHluYW1pY1Nsb3RzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3Qgc2xvdCA9IGR5bmFtaWNTbG90c1tpXTtcbiAgICBpZiAoaXNBcnJheShzbG90KSkge1xuICAgICAgZm9yIChsZXQgaiA9IDA7IGogPCBzbG90Lmxlbmd0aDsgaisrKSB7XG4gICAgICAgIHNsb3RzW3Nsb3Rbal0ubmFtZV0gPSBzbG90W2pdLmZuO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoc2xvdCkge1xuICAgICAgc2xvdHNbc2xvdC5uYW1lXSA9IHNsb3Qua2V5ID8gKC4uLmFyZ3MpID0+IHtcbiAgICAgICAgY29uc3QgcmVzID0gc2xvdC5mbiguLi5hcmdzKTtcbiAgICAgICAgaWYgKHJlcykgcmVzLmtleSA9IHNsb3Qua2V5O1xuICAgICAgICByZXR1cm4gcmVzO1xuICAgICAgfSA6IHNsb3QuZm47XG4gICAgfVxuICB9XG4gIHJldHVybiBzbG90cztcbn1cblxuZnVuY3Rpb24gcmVuZGVyU2xvdChzbG90cywgbmFtZSwgcHJvcHMgPSB7fSwgZmFsbGJhY2ssIG5vU2xvdHRlZCwgYnJhbmNoS2V5KSB7XG4gIGlmIChjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UuY2UgfHwgY3VycmVudFJlbmRlcmluZ0luc3RhbmNlLnBhcmVudCAmJiBpc0FzeW5jV3JhcHBlcihjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UucGFyZW50KSAmJiBjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UucGFyZW50LmNlKSB7XG4gICAgY29uc3Qgc2xvdFByb3BzID0gYnJhbmNoS2V5ICE9IG51bGwgJiYgcHJvcHMua2V5ID09IG51bGwgPyBleHRlbmQoe30sIHByb3BzLCB7IGtleTogYnJhbmNoS2V5IH0pIDogcHJvcHM7XG4gICAgY29uc3QgaGFzUHJvcHMgPSBPYmplY3Qua2V5cyhzbG90UHJvcHMpLmxlbmd0aCA+IDA7XG4gICAgaWYgKG5hbWUgIT09IFwiZGVmYXVsdFwiKSBzbG90UHJvcHMubmFtZSA9IG5hbWU7XG4gICAgcmV0dXJuIG9wZW5CbG9jaygpLCBjcmVhdGVCbG9jayhcbiAgICAgIEZyYWdtZW50LFxuICAgICAgbnVsbCxcbiAgICAgIFtjcmVhdGVWTm9kZShcInNsb3RcIiwgc2xvdFByb3BzLCBmYWxsYmFjayAmJiBmYWxsYmFjaygpKV0sXG4gICAgICBoYXNQcm9wcyA/IC0yIDogNjRcbiAgICApO1xuICB9XG4gIGxldCBzbG90ID0gc2xvdHNbbmFtZV07XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHNsb3QgJiYgc2xvdC5sZW5ndGggPiAxKSB7XG4gICAgd2FybiQxKFxuICAgICAgYFNTUi1vcHRpbWl6ZWQgc2xvdCBmdW5jdGlvbiBkZXRlY3RlZCBpbiBhIG5vbi1TU1Itb3B0aW1pemVkIHJlbmRlciBmdW5jdGlvbi4gWW91IG5lZWQgdG8gbWFyayB0aGlzIGNvbXBvbmVudCB3aXRoICRkeW5hbWljLXNsb3RzIGluIHRoZSBwYXJlbnQgdGVtcGxhdGUuYFxuICAgICk7XG4gICAgc2xvdCA9ICgpID0+IFtdO1xuICB9XG4gIGlmIChzbG90ICYmIHNsb3QuX2MpIHtcbiAgICBzbG90Ll9kID0gZmFsc2U7XG4gIH1cbiAgY29uc3QgcHJldlN0YWNrU2l6ZSA9IGJsb2NrU3RhY2subGVuZ3RoO1xuICBvcGVuQmxvY2soKTtcbiAgbGV0IHJlbmRlcmVkO1xuICB0cnkge1xuICAgIGNvbnN0IHZhbGlkU2xvdENvbnRlbnQgPSBzbG90ICYmIGVuc3VyZVZhbGlkVk5vZGUoc2xvdChwcm9wcykpO1xuICAgIGNvbnN0IHNsb3RLZXkgPSBwcm9wcy5rZXkgfHwgYnJhbmNoS2V5IHx8IC8vIHNsb3QgY29udGVudCBhcnJheSBvZiBhIGR5bmFtaWMgY29uZGl0aW9uYWwgc2xvdCBtYXkgaGF2ZSBhIGJyYW5jaFxuICAgIC8vIGtleSBhdHRhY2hlZCBpbiB0aGUgYGNyZWF0ZVNsb3RzYCBoZWxwZXIsIHJlc3BlY3QgdGhhdFxuICAgIHZhbGlkU2xvdENvbnRlbnQgJiYgdmFsaWRTbG90Q29udGVudC5rZXk7XG4gICAgcmVuZGVyZWQgPSBjcmVhdGVCbG9jayhcbiAgICAgIEZyYWdtZW50LFxuICAgICAge1xuICAgICAgICBrZXk6IChzbG90S2V5ICYmICFpc1N5bWJvbChzbG90S2V5KSA/IHNsb3RLZXkgOiBgXyR7bmFtZX1gKSArIC8vICM3MjU2IGZvcmNlIGRpZmZlcmVudGlhdGUgZmFsbGJhY2sgY29udGVudCBmcm9tIGFjdHVhbCBjb250ZW50XG4gICAgICAgICghdmFsaWRTbG90Q29udGVudCAmJiBmYWxsYmFjayA/IFwiX2ZiXCIgOiBcIlwiKVxuICAgICAgfSxcbiAgICAgIHZhbGlkU2xvdENvbnRlbnQgfHwgKGZhbGxiYWNrID8gZmFsbGJhY2soKSA6IFtdKSxcbiAgICAgIHZhbGlkU2xvdENvbnRlbnQgJiYgc2xvdHMuXyA9PT0gMSA/IDY0IDogLTJcbiAgICApO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBmb3IgKGxldCBpID0gYmxvY2tTdGFjay5sZW5ndGg7IGkgPiBwcmV2U3RhY2tTaXplOyBpLS0pIGNsb3NlQmxvY2soKTtcbiAgICB0aHJvdyBlcnI7XG4gIH0gZmluYWxseSB7XG4gICAgaWYgKHNsb3QgJiYgc2xvdC5fYykge1xuICAgICAgc2xvdC5fZCA9IHRydWU7XG4gICAgfVxuICB9XG4gIGlmICghbm9TbG90dGVkICYmIHJlbmRlcmVkLnNjb3BlSWQpIHtcbiAgICByZW5kZXJlZC5zbG90U2NvcGVJZHMgPSBbcmVuZGVyZWQuc2NvcGVJZCArIFwiLXNcIl07XG4gIH1cbiAgcmV0dXJuIHJlbmRlcmVkO1xufVxuZnVuY3Rpb24gZW5zdXJlVmFsaWRWTm9kZSh2bm9kZXMpIHtcbiAgcmV0dXJuIHZub2Rlcy5zb21lKChjaGlsZCkgPT4ge1xuICAgIGlmICghaXNWTm9kZShjaGlsZCkpIHJldHVybiB0cnVlO1xuICAgIGlmIChjaGlsZC50eXBlID09PSBDb21tZW50KSByZXR1cm4gZmFsc2U7XG4gICAgaWYgKGNoaWxkLnR5cGUgPT09IEZyYWdtZW50ICYmICFlbnN1cmVWYWxpZFZOb2RlKGNoaWxkLmNoaWxkcmVuKSlcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSkgPyB2bm9kZXMgOiBudWxsO1xufVxuXG5mdW5jdGlvbiB0b0hhbmRsZXJzKG9iaiwgcHJlc2VydmVDYXNlSWZOZWNlc3NhcnkpIHtcbiAgY29uc3QgcmV0ID0ge307XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICFpc09iamVjdChvYmopKSB7XG4gICAgd2FybiQxKGB2LW9uIHdpdGggbm8gYXJndW1lbnQgZXhwZWN0cyBhbiBvYmplY3QgdmFsdWUuYCk7XG4gICAgcmV0dXJuIHJldDtcbiAgfVxuICBmb3IgKGNvbnN0IGtleSBpbiBvYmopIHtcbiAgICByZXRbcHJlc2VydmVDYXNlSWZOZWNlc3NhcnkgJiYgL1tBLVpdLy50ZXN0KGtleSkgPyBgb246JHtrZXl9YCA6IHRvSGFuZGxlcktleShrZXkpXSA9IG9ialtrZXldO1xuICB9XG4gIHJldHVybiByZXQ7XG59XG5cbmNvbnN0IGdldFB1YmxpY0luc3RhbmNlID0gKGkpID0+IHtcbiAgaWYgKCFpKSByZXR1cm4gbnVsbDtcbiAgaWYgKGlzU3RhdGVmdWxDb21wb25lbnQoaSkpIHJldHVybiBnZXRDb21wb25lbnRQdWJsaWNJbnN0YW5jZShpKTtcbiAgcmV0dXJuIGdldFB1YmxpY0luc3RhbmNlKGkucGFyZW50KTtcbn07XG5jb25zdCBwdWJsaWNQcm9wZXJ0aWVzTWFwID0gKFxuICAvLyBNb3ZlIFBVUkUgbWFya2VyIHRvIG5ldyBsaW5lIHRvIHdvcmthcm91bmQgY29tcGlsZXIgZGlzY2FyZGluZyBpdFxuICAvLyBkdWUgdG8gdHlwZSBhbm5vdGF0aW9uXG4gIC8qIEBfX1BVUkVfXyAqLyBleHRlbmQoLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCksIHtcbiAgICAkOiAoaSkgPT4gaSxcbiAgICAkZWw6IChpKSA9PiBpLnZub2RlLmVsLFxuICAgICRkYXRhOiAoaSkgPT4gaS5kYXRhLFxuICAgICRwcm9wczogKGkpID0+ICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyBzaGFsbG93UmVhZG9ubHkoaS5wcm9wcykgOiBpLnByb3BzLFxuICAgICRhdHRyczogKGkpID0+ICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyBzaGFsbG93UmVhZG9ubHkoaS5hdHRycykgOiBpLmF0dHJzLFxuICAgICRzbG90czogKGkpID0+ICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyBzaGFsbG93UmVhZG9ubHkoaS5zbG90cykgOiBpLnNsb3RzLFxuICAgICRyZWZzOiAoaSkgPT4gISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IHNoYWxsb3dSZWFkb25seShpLnJlZnMpIDogaS5yZWZzLFxuICAgICRwYXJlbnQ6IChpKSA9PiBnZXRQdWJsaWNJbnN0YW5jZShpLnBhcmVudCksXG4gICAgJHJvb3Q6IChpKSA9PiBnZXRQdWJsaWNJbnN0YW5jZShpLnJvb3QpLFxuICAgICRob3N0OiAoaSkgPT4gaS5jZSxcbiAgICAkZW1pdDogKGkpID0+IGkuZW1pdCxcbiAgICAkb3B0aW9uczogKGkpID0+IF9fVlVFX09QVElPTlNfQVBJX18gPyByZXNvbHZlTWVyZ2VkT3B0aW9ucyhpKSA6IGkudHlwZSxcbiAgICAkZm9yY2VVcGRhdGU6IChpKSA9PiBpLmYgfHwgKGkuZiA9ICgpID0+IHtcbiAgICAgIHF1ZXVlSm9iKGkudXBkYXRlKTtcbiAgICB9KSxcbiAgICAkbmV4dFRpY2s6IChpKSA9PiBpLm4gfHwgKGkubiA9IG5leHRUaWNrLmJpbmQoaS5wcm94eSkpLFxuICAgICR3YXRjaDogKGkpID0+IF9fVlVFX09QVElPTlNfQVBJX18gPyBpbnN0YW5jZVdhdGNoLmJpbmQoaSkgOiBOT09QXG4gIH0pXG4pO1xuY29uc3QgaXNSZXNlcnZlZFByZWZpeCA9IChrZXkpID0+IGtleSA9PT0gXCJfXCIgfHwga2V5ID09PSBcIiRcIjtcbmNvbnN0IGhhc1NldHVwQmluZGluZyA9IChzdGF0ZSwga2V5KSA9PiBzdGF0ZSAhPT0gRU1QVFlfT0JKICYmICFzdGF0ZS5fX2lzU2NyaXB0U2V0dXAgJiYgaGFzT3duKHN0YXRlLCBrZXkpO1xuY29uc3QgUHVibGljSW5zdGFuY2VQcm94eUhhbmRsZXJzID0ge1xuICBnZXQoeyBfOiBpbnN0YW5jZSB9LCBrZXkpIHtcbiAgICBpZiAoa2V5ID09PSBcIl9fdl9za2lwXCIpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBjb25zdCB7IGN0eCwgc2V0dXBTdGF0ZSwgZGF0YSwgcHJvcHMsIGFjY2Vzc0NhY2hlLCB0eXBlLCBhcHBDb250ZXh0IH0gPSBpbnN0YW5jZTtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBrZXkgPT09IFwiX19pc1Z1ZVwiKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKGtleVswXSAhPT0gXCIkXCIpIHtcbiAgICAgIGNvbnN0IG4gPSBhY2Nlc3NDYWNoZVtrZXldO1xuICAgICAgaWYgKG4gIT09IHZvaWQgMCkge1xuICAgICAgICBzd2l0Y2ggKG4pIHtcbiAgICAgICAgICBjYXNlIDEgLyogU0VUVVAgKi86XG4gICAgICAgICAgICByZXR1cm4gc2V0dXBTdGF0ZVtrZXldO1xuICAgICAgICAgIGNhc2UgMiAvKiBEQVRBICovOlxuICAgICAgICAgICAgcmV0dXJuIGRhdGFba2V5XTtcbiAgICAgICAgICBjYXNlIDQgLyogQ09OVEVYVCAqLzpcbiAgICAgICAgICAgIHJldHVybiBjdHhba2V5XTtcbiAgICAgICAgICBjYXNlIDMgLyogUFJPUFMgKi86XG4gICAgICAgICAgICByZXR1cm4gcHJvcHNba2V5XTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmIChoYXNTZXR1cEJpbmRpbmcoc2V0dXBTdGF0ZSwga2V5KSkge1xuICAgICAgICBhY2Nlc3NDYWNoZVtrZXldID0gMSAvKiBTRVRVUCAqLztcbiAgICAgICAgcmV0dXJuIHNldHVwU3RhdGVba2V5XTtcbiAgICAgIH0gZWxzZSBpZiAoX19WVUVfT1BUSU9OU19BUElfXyAmJiBkYXRhICE9PSBFTVBUWV9PQkogJiYgaGFzT3duKGRhdGEsIGtleSkpIHtcbiAgICAgICAgYWNjZXNzQ2FjaGVba2V5XSA9IDIgLyogREFUQSAqLztcbiAgICAgICAgcmV0dXJuIGRhdGFba2V5XTtcbiAgICAgIH0gZWxzZSBpZiAoaGFzT3duKHByb3BzLCBrZXkpKSB7XG4gICAgICAgIGFjY2Vzc0NhY2hlW2tleV0gPSAzIC8qIFBST1BTICovO1xuICAgICAgICByZXR1cm4gcHJvcHNba2V5XTtcbiAgICAgIH0gZWxzZSBpZiAoY3R4ICE9PSBFTVBUWV9PQkogJiYgaGFzT3duKGN0eCwga2V5KSkge1xuICAgICAgICBhY2Nlc3NDYWNoZVtrZXldID0gNCAvKiBDT05URVhUICovO1xuICAgICAgICByZXR1cm4gY3R4W2tleV07XG4gICAgICB9IGVsc2UgaWYgKCFfX1ZVRV9PUFRJT05TX0FQSV9fIHx8IHNob3VsZENhY2hlQWNjZXNzKSB7XG4gICAgICAgIGFjY2Vzc0NhY2hlW2tleV0gPSAwIC8qIE9USEVSICovO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBwdWJsaWNHZXR0ZXIgPSBwdWJsaWNQcm9wZXJ0aWVzTWFwW2tleV07XG4gICAgbGV0IGNzc01vZHVsZSwgZ2xvYmFsUHJvcGVydGllcztcbiAgICBpZiAocHVibGljR2V0dGVyKSB7XG4gICAgICBpZiAoa2V5ID09PSBcIiRhdHRyc1wiKSB7XG4gICAgICAgIHRyYWNrKGluc3RhbmNlLmF0dHJzLCBcImdldFwiLCBcIlwiKTtcbiAgICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBtYXJrQXR0cnNBY2Nlc3NlZCgpO1xuICAgICAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGtleSA9PT0gXCIkc2xvdHNcIikge1xuICAgICAgICB0cmFjayhpbnN0YW5jZSwgXCJnZXRcIiwga2V5KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBwdWJsaWNHZXR0ZXIoaW5zdGFuY2UpO1xuICAgIH0gZWxzZSBpZiAoXG4gICAgICAvLyBjc3MgbW9kdWxlIChpbmplY3RlZCBieSB2dWUtbG9hZGVyKVxuICAgICAgKGNzc01vZHVsZSA9IHR5cGUuX19jc3NNb2R1bGVzKSAmJiAoY3NzTW9kdWxlID0gY3NzTW9kdWxlW2tleV0pXG4gICAgKSB7XG4gICAgICByZXR1cm4gY3NzTW9kdWxlO1xuICAgIH0gZWxzZSBpZiAoY3R4ICE9PSBFTVBUWV9PQkogJiYgaGFzT3duKGN0eCwga2V5KSkge1xuICAgICAgYWNjZXNzQ2FjaGVba2V5XSA9IDQgLyogQ09OVEVYVCAqLztcbiAgICAgIHJldHVybiBjdHhba2V5XTtcbiAgICB9IGVsc2UgaWYgKFxuICAgICAgLy8gZ2xvYmFsIHByb3BlcnRpZXNcbiAgICAgIGdsb2JhbFByb3BlcnRpZXMgPSBhcHBDb250ZXh0LmNvbmZpZy5nbG9iYWxQcm9wZXJ0aWVzLCBoYXNPd24oZ2xvYmFsUHJvcGVydGllcywga2V5KVxuICAgICkge1xuICAgICAge1xuICAgICAgICByZXR1cm4gZ2xvYmFsUHJvcGVydGllc1trZXldO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UgJiYgKCFpc1N0cmluZyhrZXkpIHx8IC8vICMxMDkxIGF2b2lkIGludGVybmFsIGlzUmVmL2lzVk5vZGUgY2hlY2tzIG9uIGNvbXBvbmVudCBpbnN0YW5jZSBsZWFkaW5nXG4gICAgLy8gdG8gaW5maW5pdGUgd2FybmluZyBsb29wXG4gICAga2V5LmluZGV4T2YoXCJfX3ZcIikgIT09IDApKSB7XG4gICAgICBpZiAoZGF0YSAhPT0gRU1QVFlfT0JKICYmIGlzUmVzZXJ2ZWRQcmVmaXgoa2V5WzBdKSAmJiBoYXNPd24oZGF0YSwga2V5KSkge1xuICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgYFByb3BlcnR5ICR7SlNPTi5zdHJpbmdpZnkoXG4gICAgICAgICAgICBrZXlcbiAgICAgICAgICApfSBtdXN0IGJlIGFjY2Vzc2VkIHZpYSAkZGF0YSBiZWNhdXNlIGl0IHN0YXJ0cyB3aXRoIGEgcmVzZXJ2ZWQgY2hhcmFjdGVyIChcIiRcIiBvciBcIl9cIikgYW5kIGlzIG5vdCBwcm94aWVkIG9uIHRoZSByZW5kZXIgY29udGV4dC5gXG4gICAgICAgICk7XG4gICAgICB9IGVsc2UgaWYgKGluc3RhbmNlID09PSBjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UpIHtcbiAgICAgICAgd2FybiQxKFxuICAgICAgICAgIGBQcm9wZXJ0eSAke0pTT04uc3RyaW5naWZ5KGtleSl9IHdhcyBhY2Nlc3NlZCBkdXJpbmcgcmVuZGVyIGJ1dCBpcyBub3QgZGVmaW5lZCBvbiBpbnN0YW5jZS5gXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9LFxuICBzZXQoeyBfOiBpbnN0YW5jZSB9LCBrZXksIHZhbHVlKSB7XG4gICAgY29uc3QgeyBkYXRhLCBzZXR1cFN0YXRlLCBjdHggfSA9IGluc3RhbmNlO1xuICAgIGlmIChoYXNTZXR1cEJpbmRpbmcoc2V0dXBTdGF0ZSwga2V5KSkge1xuICAgICAgc2V0dXBTdGF0ZVtrZXldID0gdmFsdWU7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgc2V0dXBTdGF0ZS5fX2lzU2NyaXB0U2V0dXAgJiYgaGFzT3duKHNldHVwU3RhdGUsIGtleSkpIHtcbiAgICAgIHdhcm4kMShgQ2Fubm90IG11dGF0ZSA8c2NyaXB0IHNldHVwPiBiaW5kaW5nIFwiJHtrZXl9XCIgZnJvbSBPcHRpb25zIEFQSS5gKTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9IGVsc2UgaWYgKF9fVlVFX09QVElPTlNfQVBJX18gJiYgZGF0YSAhPT0gRU1QVFlfT0JKICYmIGhhc093bihkYXRhLCBrZXkpKSB7XG4gICAgICBkYXRhW2tleV0gPSB2YWx1ZTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gZWxzZSBpZiAoaGFzT3duKGluc3RhbmNlLnByb3BzLCBrZXkpKSB7XG4gICAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdhcm4kMShgQXR0ZW1wdGluZyB0byBtdXRhdGUgcHJvcCBcIiR7a2V5fVwiLiBQcm9wcyBhcmUgcmVhZG9ubHkuYCk7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmIChrZXlbMF0gPT09IFwiJFwiICYmIGtleS5zbGljZSgxKSBpbiBpbnN0YW5jZSkge1xuICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB3YXJuJDEoXG4gICAgICAgIGBBdHRlbXB0aW5nIHRvIG11dGF0ZSBwdWJsaWMgcHJvcGVydHkgXCIke2tleX1cIi4gUHJvcGVydGllcyBzdGFydGluZyB3aXRoICQgYXJlIHJlc2VydmVkIGFuZCByZWFkb25seS5gXG4gICAgICApO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBrZXkgaW4gaW5zdGFuY2UuYXBwQ29udGV4dC5jb25maWcuZ2xvYmFsUHJvcGVydGllcykge1xuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY3R4LCBrZXksIHtcbiAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgICB2YWx1ZVxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGN0eFtrZXldID0gdmFsdWU7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9LFxuICBoYXMoe1xuICAgIF86IHsgZGF0YSwgc2V0dXBTdGF0ZSwgYWNjZXNzQ2FjaGUsIGN0eCwgYXBwQ29udGV4dCwgcHJvcHMsIHR5cGUgfVxuICB9LCBrZXkpIHtcbiAgICBsZXQgY3NzTW9kdWxlcztcbiAgICByZXR1cm4gISEoYWNjZXNzQ2FjaGVba2V5XSB8fCBfX1ZVRV9PUFRJT05TX0FQSV9fICYmIGRhdGEgIT09IEVNUFRZX09CSiAmJiBrZXlbMF0gIT09IFwiJFwiICYmIGhhc093bihkYXRhLCBrZXkpIHx8IGhhc1NldHVwQmluZGluZyhzZXR1cFN0YXRlLCBrZXkpIHx8IGhhc093bihwcm9wcywga2V5KSB8fCBoYXNPd24oY3R4LCBrZXkpIHx8IGhhc093bihwdWJsaWNQcm9wZXJ0aWVzTWFwLCBrZXkpIHx8IGhhc093bihhcHBDb250ZXh0LmNvbmZpZy5nbG9iYWxQcm9wZXJ0aWVzLCBrZXkpIHx8IChjc3NNb2R1bGVzID0gdHlwZS5fX2Nzc01vZHVsZXMpICYmIGNzc01vZHVsZXNba2V5XSk7XG4gIH0sXG4gIGRlZmluZVByb3BlcnR5KHRhcmdldCwga2V5LCBkZXNjcmlwdG9yKSB7XG4gICAgaWYgKGRlc2NyaXB0b3IuZ2V0ICE9IG51bGwpIHtcbiAgICAgIHRhcmdldC5fLmFjY2Vzc0NhY2hlW2tleV0gPSAwO1xuICAgIH0gZWxzZSBpZiAoaGFzT3duKGRlc2NyaXB0b3IsIFwidmFsdWVcIikpIHtcbiAgICAgIHRoaXMuc2V0KHRhcmdldCwga2V5LCBkZXNjcmlwdG9yLnZhbHVlLCBudWxsKTtcbiAgICB9XG4gICAgcmV0dXJuIFJlZmxlY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIGRlc2NyaXB0b3IpO1xuICB9XG59O1xuaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgdHJ1ZSkge1xuICBQdWJsaWNJbnN0YW5jZVByb3h5SGFuZGxlcnMub3duS2V5cyA9ICh0YXJnZXQpID0+IHtcbiAgICB3YXJuJDEoXG4gICAgICBgQXZvaWQgYXBwIGxvZ2ljIHRoYXQgcmVsaWVzIG9uIGVudW1lcmF0aW5nIGtleXMgb24gYSBjb21wb25lbnQgaW5zdGFuY2UuIFRoZSBrZXlzIHdpbGwgYmUgZW1wdHkgaW4gcHJvZHVjdGlvbiBtb2RlIHRvIGF2b2lkIHBlcmZvcm1hbmNlIG92ZXJoZWFkLmBcbiAgICApO1xuICAgIHJldHVybiBSZWZsZWN0Lm93bktleXModGFyZ2V0KTtcbiAgfTtcbn1cbmNvbnN0IFJ1bnRpbWVDb21waWxlZFB1YmxpY0luc3RhbmNlUHJveHlIYW5kbGVycyA9IC8qIEBfX1BVUkVfXyAqLyBleHRlbmQoe30sIFB1YmxpY0luc3RhbmNlUHJveHlIYW5kbGVycywge1xuICBnZXQodGFyZ2V0LCBrZXkpIHtcbiAgICBpZiAoa2V5ID09PSBTeW1ib2wudW5zY29wYWJsZXMpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcmV0dXJuIFB1YmxpY0luc3RhbmNlUHJveHlIYW5kbGVycy5nZXQodGFyZ2V0LCBrZXksIHRhcmdldCk7XG4gIH0sXG4gIGhhcyhfLCBrZXkpIHtcbiAgICBjb25zdCBoYXMgPSBrZXlbMF0gIT09IFwiX1wiICYmICFpc0dsb2JhbGx5QWxsb3dlZChrZXkpO1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICFoYXMgJiYgUHVibGljSW5zdGFuY2VQcm94eUhhbmRsZXJzLmhhcyhfLCBrZXkpKSB7XG4gICAgICB3YXJuJDEoXG4gICAgICAgIGBQcm9wZXJ0eSAke0pTT04uc3RyaW5naWZ5KFxuICAgICAgICAgIGtleVxuICAgICAgICApfSBzaG91bGQgbm90IHN0YXJ0IHdpdGggXyB3aGljaCBpcyBhIHJlc2VydmVkIHByZWZpeCBmb3IgVnVlIGludGVybmFscy5gXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gaGFzO1xuICB9XG59KTtcbmZ1bmN0aW9uIGNyZWF0ZURldlJlbmRlckNvbnRleHQoaW5zdGFuY2UpIHtcbiAgY29uc3QgdGFyZ2V0ID0ge307XG4gIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIGBfYCwge1xuICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICBlbnVtZXJhYmxlOiBmYWxzZSxcbiAgICBnZXQ6ICgpID0+IGluc3RhbmNlXG4gIH0pO1xuICBPYmplY3Qua2V5cyhwdWJsaWNQcm9wZXJ0aWVzTWFwKS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBrZXksIHtcbiAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgZ2V0OiAoKSA9PiBwdWJsaWNQcm9wZXJ0aWVzTWFwW2tleV0oaW5zdGFuY2UpLFxuICAgICAgLy8gaW50ZXJjZXB0ZWQgYnkgdGhlIHByb3h5IHNvIG5vIG5lZWQgZm9yIGltcGxlbWVudGF0aW9uLFxuICAgICAgLy8gYnV0IG5lZWRlZCB0byBwcmV2ZW50IHNldCBlcnJvcnNcbiAgICAgIHNldDogTk9PUFxuICAgIH0pO1xuICB9KTtcbiAgcmV0dXJuIHRhcmdldDtcbn1cbmZ1bmN0aW9uIGV4cG9zZVByb3BzT25SZW5kZXJDb250ZXh0KGluc3RhbmNlKSB7XG4gIGNvbnN0IHtcbiAgICBjdHgsXG4gICAgcHJvcHNPcHRpb25zOiBbcHJvcHNPcHRpb25zXVxuICB9ID0gaW5zdGFuY2U7XG4gIGlmIChwcm9wc09wdGlvbnMpIHtcbiAgICBPYmplY3Qua2V5cyhwcm9wc09wdGlvbnMpLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGN0eCwga2V5LCB7XG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgZ2V0OiAoKSA9PiBpbnN0YW5jZS5wcm9wc1trZXldLFxuICAgICAgICBzZXQ6IE5PT1BcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG59XG5mdW5jdGlvbiBleHBvc2VTZXR1cFN0YXRlT25SZW5kZXJDb250ZXh0KGluc3RhbmNlKSB7XG4gIGNvbnN0IHsgY3R4LCBzZXR1cFN0YXRlIH0gPSBpbnN0YW5jZTtcbiAgT2JqZWN0LmtleXModG9SYXcoc2V0dXBTdGF0ZSkpLmZvckVhY2goKGtleSkgPT4ge1xuICAgIGlmICghc2V0dXBTdGF0ZS5fX2lzU2NyaXB0U2V0dXApIHtcbiAgICAgIGlmIChpc1Jlc2VydmVkUHJlZml4KGtleVswXSkpIHtcbiAgICAgICAgd2FybiQxKFxuICAgICAgICAgIGBzZXR1cCgpIHJldHVybiBwcm9wZXJ0eSAke0pTT04uc3RyaW5naWZ5KFxuICAgICAgICAgICAga2V5XG4gICAgICAgICAgKX0gc2hvdWxkIG5vdCBzdGFydCB3aXRoIFwiJFwiIG9yIFwiX1wiIHdoaWNoIGFyZSByZXNlcnZlZCBwcmVmaXhlcyBmb3IgVnVlIGludGVybmFscy5gXG4gICAgICAgICk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjdHgsIGtleSwge1xuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgIGdldDogKCkgPT4gc2V0dXBTdGF0ZVtrZXldLFxuICAgICAgICBzZXQ6IE5PT1BcbiAgICAgIH0pO1xuICAgIH1cbiAgfSk7XG59XG5cbmNvbnN0IHdhcm5SdW50aW1lVXNhZ2UgPSAobWV0aG9kKSA9PiB3YXJuJDEoXG4gIGAke21ldGhvZH0oKSBpcyBhIGNvbXBpbGVyLWhpbnQgaGVscGVyIHRoYXQgaXMgb25seSB1c2FibGUgaW5zaWRlIDxzY3JpcHQgc2V0dXA+IG9mIGEgc2luZ2xlIGZpbGUgY29tcG9uZW50LiBJdHMgYXJndW1lbnRzIHNob3VsZCBiZSBjb21waWxlZCBhd2F5IGFuZCBwYXNzaW5nIGl0IGF0IHJ1bnRpbWUgaGFzIG5vIGVmZmVjdC5gXG4pO1xuZnVuY3Rpb24gZGVmaW5lUHJvcHMoKSB7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgd2FyblJ1bnRpbWVVc2FnZShgZGVmaW5lUHJvcHNgKTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cbmZ1bmN0aW9uIGRlZmluZUVtaXRzKCkge1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIHdhcm5SdW50aW1lVXNhZ2UoYGRlZmluZUVtaXRzYCk7XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiBkZWZpbmVFeHBvc2UoZXhwb3NlZCkge1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIHdhcm5SdW50aW1lVXNhZ2UoYGRlZmluZUV4cG9zZWApO1xuICB9XG59XG5mdW5jdGlvbiBkZWZpbmVPcHRpb25zKG9wdGlvbnMpIHtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICB3YXJuUnVudGltZVVzYWdlKGBkZWZpbmVPcHRpb25zYCk7XG4gIH1cbn1cbmZ1bmN0aW9uIGRlZmluZVNsb3RzKCkge1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIHdhcm5SdW50aW1lVXNhZ2UoYGRlZmluZVNsb3RzYCk7XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiBkZWZpbmVNb2RlbCgpIHtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICB3YXJuUnVudGltZVVzYWdlKFwiZGVmaW5lTW9kZWxcIik7XG4gIH1cbn1cbmZ1bmN0aW9uIHdpdGhEZWZhdWx0cyhwcm9wcywgZGVmYXVsdHMpIHtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICB3YXJuUnVudGltZVVzYWdlKGB3aXRoRGVmYXVsdHNgKTtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn1cbmZ1bmN0aW9uIHVzZVNsb3RzKCkge1xuICByZXR1cm4gZ2V0Q29udGV4dChcInVzZVNsb3RzXCIpLnNsb3RzO1xufVxuZnVuY3Rpb24gdXNlQXR0cnMoKSB7XG4gIHJldHVybiBnZXRDb250ZXh0KFwidXNlQXR0cnNcIikuYXR0cnM7XG59XG5mdW5jdGlvbiBnZXRDb250ZXh0KGNhbGxlZEZ1bmN0aW9uTmFtZSkge1xuICBjb25zdCBpID0gZ2V0Q3VycmVudEluc3RhbmNlKCk7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICFpKSB7XG4gICAgd2FybiQxKGAke2NhbGxlZEZ1bmN0aW9uTmFtZX0oKSBjYWxsZWQgd2l0aG91dCBhY3RpdmUgaW5zdGFuY2UuYCk7XG4gIH1cbiAgcmV0dXJuIGkuc2V0dXBDb250ZXh0IHx8IChpLnNldHVwQ29udGV4dCA9IGNyZWF0ZVNldHVwQ29udGV4dChpKSk7XG59XG5mdW5jdGlvbiBub3JtYWxpemVQcm9wc09yRW1pdHMocHJvcHMpIHtcbiAgcmV0dXJuIGlzQXJyYXkocHJvcHMpID8gcHJvcHMucmVkdWNlKFxuICAgIChub3JtYWxpemVkLCBwKSA9PiAobm9ybWFsaXplZFtwXSA9IG51bGwsIG5vcm1hbGl6ZWQpLFxuICAgIHt9XG4gICkgOiBwcm9wcztcbn1cbmZ1bmN0aW9uIG1lcmdlRGVmYXVsdHMocmF3LCBkZWZhdWx0cykge1xuICBjb25zdCBwcm9wcyA9IG5vcm1hbGl6ZVByb3BzT3JFbWl0cyhyYXcpO1xuICBmb3IgKGNvbnN0IGtleSBpbiBkZWZhdWx0cykge1xuICAgIGlmIChrZXkuc3RhcnRzV2l0aChcIl9fc2tpcFwiKSkgY29udGludWU7XG4gICAgbGV0IG9wdCA9IHByb3BzW2tleV07XG4gICAgaWYgKG9wdCkge1xuICAgICAgaWYgKGlzQXJyYXkob3B0KSB8fCBpc0Z1bmN0aW9uKG9wdCkpIHtcbiAgICAgICAgb3B0ID0gcHJvcHNba2V5XSA9IHsgdHlwZTogb3B0LCBkZWZhdWx0OiBkZWZhdWx0c1trZXldIH07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBvcHQuZGVmYXVsdCA9IGRlZmF1bHRzW2tleV07XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChvcHQgPT09IG51bGwpIHtcbiAgICAgIG9wdCA9IHByb3BzW2tleV0gPSB7IGRlZmF1bHQ6IGRlZmF1bHRzW2tleV0gfTtcbiAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgIHdhcm4kMShgcHJvcHMgZGVmYXVsdCBrZXkgXCIke2tleX1cIiBoYXMgbm8gY29ycmVzcG9uZGluZyBkZWNsYXJhdGlvbi5gKTtcbiAgICB9XG4gICAgaWYgKG9wdCAmJiBkZWZhdWx0c1tgX19za2lwXyR7a2V5fWBdKSB7XG4gICAgICBvcHQuc2tpcEZhY3RvcnkgPSB0cnVlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcHJvcHM7XG59XG5mdW5jdGlvbiBtZXJnZU1vZGVscyhhLCBiKSB7XG4gIGlmICghYSB8fCAhYikgcmV0dXJuIGEgfHwgYjtcbiAgaWYgKGlzQXJyYXkoYSkgJiYgaXNBcnJheShiKSkgcmV0dXJuIGEuY29uY2F0KGIpO1xuICByZXR1cm4gZXh0ZW5kKHt9LCBub3JtYWxpemVQcm9wc09yRW1pdHMoYSksIG5vcm1hbGl6ZVByb3BzT3JFbWl0cyhiKSk7XG59XG5mdW5jdGlvbiBjcmVhdGVQcm9wc1Jlc3RQcm94eShwcm9wcywgZXhjbHVkZWRLZXlzKSB7XG4gIGNvbnN0IHJldCA9IHt9O1xuICBmb3IgKGNvbnN0IGtleSBpbiBwcm9wcykge1xuICAgIGlmICghZXhjbHVkZWRLZXlzLmluY2x1ZGVzKGtleSkpIHtcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShyZXQsIGtleSwge1xuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBnZXQ6ICgpID0+IHByb3BzW2tleV1cbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcmV0O1xufVxuZnVuY3Rpb24gd2l0aEFzeW5jQ29udGV4dChnZXRBd2FpdGFibGUpIHtcbiAgY29uc3QgY3R4ID0gZ2V0Q3VycmVudEluc3RhbmNlKCk7XG4gIGNvbnN0IGluU1NSU2V0dXAgPSBpc0luU1NSQ29tcG9uZW50U2V0dXA7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICFjdHgpIHtcbiAgICB3YXJuJDEoXG4gICAgICBgd2l0aEFzeW5jQ29udGV4dCBjYWxsZWQgd2l0aG91dCBhY3RpdmUgY3VycmVudCBpbnN0YW5jZS4gVGhpcyBpcyBsaWtlbHkgYSBidWcuYFxuICAgICk7XG4gIH1cbiAgbGV0IGF3YWl0YWJsZSA9IGdldEF3YWl0YWJsZSgpO1xuICB1bnNldEN1cnJlbnRJbnN0YW5jZSgpO1xuICBpZiAoaW5TU1JTZXR1cCkge1xuICAgIHNldEluU1NSU2V0dXBTdGF0ZShmYWxzZSk7XG4gIH1cbiAgY29uc3QgcmVzdG9yZSA9ICgpID0+IHtcbiAgICBzZXRDdXJyZW50SW5zdGFuY2UoY3R4KTtcbiAgICBpZiAoaW5TU1JTZXR1cCkge1xuICAgICAgc2V0SW5TU1JTZXR1cFN0YXRlKHRydWUpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgY2xlYW51cCA9ICgpID0+IHtcbiAgICBpZiAoZ2V0Q3VycmVudEluc3RhbmNlKCkgIT09IGN0eCkgY3R4LnNjb3BlLm9mZigpO1xuICAgIHVuc2V0Q3VycmVudEluc3RhbmNlKCk7XG4gICAgaWYgKGluU1NSU2V0dXApIHtcbiAgICAgIHNldEluU1NSU2V0dXBTdGF0ZShmYWxzZSk7XG4gICAgfVxuICB9O1xuICBpZiAoaXNQcm9taXNlKGF3YWl0YWJsZSkpIHtcbiAgICBhd2FpdGFibGUgPSBhd2FpdGFibGUuY2F0Y2goKGUpID0+IHtcbiAgICAgIHJlc3RvcmUoKTtcbiAgICAgIFByb21pc2UucmVzb2x2ZSgpLnRoZW4oKCkgPT4gUHJvbWlzZS5yZXNvbHZlKCkudGhlbihjbGVhbnVwKSk7XG4gICAgICB0aHJvdyBlO1xuICAgIH0pO1xuICB9XG4gIHJldHVybiBbXG4gICAgYXdhaXRhYmxlLFxuICAgICgpID0+IHtcbiAgICAgIHJlc3RvcmUoKTtcbiAgICAgIFByb21pc2UucmVzb2x2ZSgpLnRoZW4oY2xlYW51cCk7XG4gICAgfVxuICBdO1xufVxuXG5mdW5jdGlvbiBjcmVhdGVEdXBsaWNhdGVDaGVja2VyKCkge1xuICBjb25zdCBjYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICByZXR1cm4gKHR5cGUsIGtleSkgPT4ge1xuICAgIGlmIChjYWNoZVtrZXldKSB7XG4gICAgICB3YXJuJDEoYCR7dHlwZX0gcHJvcGVydHkgXCIke2tleX1cIiBpcyBhbHJlYWR5IGRlZmluZWQgaW4gJHtjYWNoZVtrZXldfS5gKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY2FjaGVba2V5XSA9IHR5cGU7XG4gICAgfVxuICB9O1xufVxubGV0IHNob3VsZENhY2hlQWNjZXNzID0gdHJ1ZTtcbmZ1bmN0aW9uIGFwcGx5T3B0aW9ucyhpbnN0YW5jZSkge1xuICBjb25zdCBvcHRpb25zID0gcmVzb2x2ZU1lcmdlZE9wdGlvbnMoaW5zdGFuY2UpO1xuICBjb25zdCBwdWJsaWNUaGlzID0gaW5zdGFuY2UucHJveHk7XG4gIGNvbnN0IGN0eCA9IGluc3RhbmNlLmN0eDtcbiAgc2hvdWxkQ2FjaGVBY2Nlc3MgPSBmYWxzZTtcbiAgaWYgKG9wdGlvbnMuYmVmb3JlQ3JlYXRlKSB7XG4gICAgY2FsbEhvb2sob3B0aW9ucy5iZWZvcmVDcmVhdGUsIGluc3RhbmNlLCBcImJjXCIpO1xuICB9XG4gIGNvbnN0IHtcbiAgICAvLyBzdGF0ZVxuICAgIGRhdGE6IGRhdGFPcHRpb25zLFxuICAgIGNvbXB1dGVkOiBjb21wdXRlZE9wdGlvbnMsXG4gICAgbWV0aG9kcyxcbiAgICB3YXRjaDogd2F0Y2hPcHRpb25zLFxuICAgIHByb3ZpZGU6IHByb3ZpZGVPcHRpb25zLFxuICAgIGluamVjdDogaW5qZWN0T3B0aW9ucyxcbiAgICAvLyBsaWZlY3ljbGVcbiAgICBjcmVhdGVkLFxuICAgIGJlZm9yZU1vdW50LFxuICAgIG1vdW50ZWQsXG4gICAgYmVmb3JlVXBkYXRlLFxuICAgIHVwZGF0ZWQsXG4gICAgYWN0aXZhdGVkLFxuICAgIGRlYWN0aXZhdGVkLFxuICAgIGJlZm9yZURlc3Ryb3ksXG4gICAgYmVmb3JlVW5tb3VudCxcbiAgICBkZXN0cm95ZWQsXG4gICAgdW5tb3VudGVkLFxuICAgIHJlbmRlcixcbiAgICByZW5kZXJUcmFja2VkLFxuICAgIHJlbmRlclRyaWdnZXJlZCxcbiAgICBlcnJvckNhcHR1cmVkLFxuICAgIHNlcnZlclByZWZldGNoLFxuICAgIC8vIHB1YmxpYyBBUElcbiAgICBleHBvc2UsXG4gICAgaW5oZXJpdEF0dHJzLFxuICAgIC8vIGFzc2V0c1xuICAgIGNvbXBvbmVudHMsXG4gICAgZGlyZWN0aXZlcyxcbiAgICBmaWx0ZXJzXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBjaGVja0R1cGxpY2F0ZVByb3BlcnRpZXMgPSAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gY3JlYXRlRHVwbGljYXRlQ2hlY2tlcigpIDogbnVsbDtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICBjb25zdCBbcHJvcHNPcHRpb25zXSA9IGluc3RhbmNlLnByb3BzT3B0aW9ucztcbiAgICBpZiAocHJvcHNPcHRpb25zKSB7XG4gICAgICBmb3IgKGNvbnN0IGtleSBpbiBwcm9wc09wdGlvbnMpIHtcbiAgICAgICAgY2hlY2tEdXBsaWNhdGVQcm9wZXJ0aWVzKFwiUHJvcHNcIiAvKiBQUk9QUyAqLywga2V5KTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgaWYgKGluamVjdE9wdGlvbnMpIHtcbiAgICByZXNvbHZlSW5qZWN0aW9ucyhpbmplY3RPcHRpb25zLCBjdHgsIGNoZWNrRHVwbGljYXRlUHJvcGVydGllcyk7XG4gIH1cbiAgaWYgKG1ldGhvZHMpIHtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBtZXRob2RzKSB7XG4gICAgICBjb25zdCBtZXRob2RIYW5kbGVyID0gbWV0aG9kc1trZXldO1xuICAgICAgaWYgKGlzRnVuY3Rpb24obWV0aG9kSGFuZGxlcikpIHtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY3R4LCBrZXksIHtcbiAgICAgICAgICAgIHZhbHVlOiBtZXRob2RIYW5kbGVyLmJpbmQocHVibGljVGhpcyksXG4gICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgd3JpdGFibGU6IHRydWVcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjdHhba2V5XSA9IG1ldGhvZEhhbmRsZXIuYmluZChwdWJsaWNUaGlzKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIGNoZWNrRHVwbGljYXRlUHJvcGVydGllcyhcIk1ldGhvZHNcIiAvKiBNRVRIT0RTICovLCBrZXkpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgd2FybiQxKFxuICAgICAgICAgIGBNZXRob2QgXCIke2tleX1cIiBoYXMgdHlwZSBcIiR7dHlwZW9mIG1ldGhvZEhhbmRsZXJ9XCIgaW4gdGhlIGNvbXBvbmVudCBkZWZpbml0aW9uLiBEaWQgeW91IHJlZmVyZW5jZSB0aGUgZnVuY3Rpb24gY29ycmVjdGx5P2BcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgaWYgKGRhdGFPcHRpb25zKSB7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWlzRnVuY3Rpb24oZGF0YU9wdGlvbnMpKSB7XG4gICAgICB3YXJuJDEoXG4gICAgICAgIGBUaGUgZGF0YSBvcHRpb24gbXVzdCBiZSBhIGZ1bmN0aW9uLiBQbGFpbiBvYmplY3QgdXNhZ2UgaXMgbm8gbG9uZ2VyIHN1cHBvcnRlZC5gXG4gICAgICApO1xuICAgIH1cbiAgICBjb25zdCBkYXRhID0gZGF0YU9wdGlvbnMuY2FsbChwdWJsaWNUaGlzLCBwdWJsaWNUaGlzKTtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBpc1Byb21pc2UoZGF0YSkpIHtcbiAgICAgIHdhcm4kMShcbiAgICAgICAgYGRhdGEoKSByZXR1cm5lZCBhIFByb21pc2UgLSBub3RlIGRhdGEoKSBjYW5ub3QgYmUgYXN5bmM7IElmIHlvdSBpbnRlbmQgdG8gcGVyZm9ybSBkYXRhIGZldGNoaW5nIGJlZm9yZSBjb21wb25lbnQgcmVuZGVycywgdXNlIGFzeW5jIHNldHVwKCkgKyA8U3VzcGVuc2U+LmBcbiAgICAgICk7XG4gICAgfVxuICAgIGlmICghaXNPYmplY3QoZGF0YSkpIHtcbiAgICAgICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgd2FybiQxKGBkYXRhKCkgc2hvdWxkIHJldHVybiBhbiBvYmplY3QuYCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGluc3RhbmNlLmRhdGEgPSByZWFjdGl2ZShkYXRhKTtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgIGZvciAoY29uc3Qga2V5IGluIGRhdGEpIHtcbiAgICAgICAgICBjaGVja0R1cGxpY2F0ZVByb3BlcnRpZXMoXCJEYXRhXCIgLyogREFUQSAqLywga2V5KTtcbiAgICAgICAgICBpZiAoIWlzUmVzZXJ2ZWRQcmVmaXgoa2V5WzBdKSkge1xuICAgICAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGN0eCwga2V5LCB7XG4gICAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgICAgZ2V0OiAoKSA9PiBkYXRhW2tleV0sXG4gICAgICAgICAgICAgIHNldDogTk9PUFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHNob3VsZENhY2hlQWNjZXNzID0gdHJ1ZTtcbiAgaWYgKGNvbXB1dGVkT3B0aW9ucykge1xuICAgIGZvciAoY29uc3Qga2V5IGluIGNvbXB1dGVkT3B0aW9ucykge1xuICAgICAgY29uc3Qgb3B0ID0gY29tcHV0ZWRPcHRpb25zW2tleV07XG4gICAgICBjb25zdCBnZXQgPSBpc0Z1bmN0aW9uKG9wdCkgPyBvcHQuYmluZChwdWJsaWNUaGlzLCBwdWJsaWNUaGlzKSA6IGlzRnVuY3Rpb24ob3B0LmdldCkgPyBvcHQuZ2V0LmJpbmQocHVibGljVGhpcywgcHVibGljVGhpcykgOiBOT09QO1xuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgZ2V0ID09PSBOT09QKSB7XG4gICAgICAgIHdhcm4kMShgQ29tcHV0ZWQgcHJvcGVydHkgXCIke2tleX1cIiBoYXMgbm8gZ2V0dGVyLmApO1xuICAgICAgfVxuICAgICAgY29uc3Qgc2V0ID0gIWlzRnVuY3Rpb24ob3B0KSAmJiBpc0Z1bmN0aW9uKG9wdC5zZXQpID8gb3B0LnNldC5iaW5kKHB1YmxpY1RoaXMpIDogISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/ICgpID0+IHtcbiAgICAgICAgd2FybiQxKFxuICAgICAgICAgIGBXcml0ZSBvcGVyYXRpb24gZmFpbGVkOiBjb21wdXRlZCBwcm9wZXJ0eSBcIiR7a2V5fVwiIGlzIHJlYWRvbmx5LmBcbiAgICAgICAgKTtcbiAgICAgIH0gOiBOT09QO1xuICAgICAgY29uc3QgYyA9IGNvbXB1dGVkKHtcbiAgICAgICAgZ2V0LFxuICAgICAgICBzZXRcbiAgICAgIH0pO1xuICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGN0eCwga2V5LCB7XG4gICAgICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgZ2V0OiAoKSA9PiBjLnZhbHVlLFxuICAgICAgICBzZXQ6ICh2KSA9PiBjLnZhbHVlID0gdlxuICAgICAgfSk7XG4gICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICBjaGVja0R1cGxpY2F0ZVByb3BlcnRpZXMoXCJDb21wdXRlZFwiIC8qIENPTVBVVEVEICovLCBrZXkpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBpZiAod2F0Y2hPcHRpb25zKSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gd2F0Y2hPcHRpb25zKSB7XG4gICAgICBjcmVhdGVXYXRjaGVyKHdhdGNoT3B0aW9uc1trZXldLCBjdHgsIHB1YmxpY1RoaXMsIGtleSk7XG4gICAgfVxuICB9XG4gIGlmIChwcm92aWRlT3B0aW9ucykge1xuICAgIGNvbnN0IHByb3ZpZGVzID0gaXNGdW5jdGlvbihwcm92aWRlT3B0aW9ucykgPyBwcm92aWRlT3B0aW9ucy5jYWxsKHB1YmxpY1RoaXMpIDogcHJvdmlkZU9wdGlvbnM7XG4gICAgUmVmbGVjdC5vd25LZXlzKHByb3ZpZGVzKS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgIHByb3ZpZGUoa2V5LCBwcm92aWRlc1trZXldKTtcbiAgICB9KTtcbiAgfVxuICBpZiAoY3JlYXRlZCkge1xuICAgIGNhbGxIb29rKGNyZWF0ZWQsIGluc3RhbmNlLCBcImNcIik7XG4gIH1cbiAgZnVuY3Rpb24gcmVnaXN0ZXJMaWZlY3ljbGVIb29rKHJlZ2lzdGVyLCBob29rKSB7XG4gICAgaWYgKGlzQXJyYXkoaG9vaykpIHtcbiAgICAgIGhvb2suZm9yRWFjaCgoX2hvb2spID0+IHJlZ2lzdGVyKF9ob29rLmJpbmQocHVibGljVGhpcykpKTtcbiAgICB9IGVsc2UgaWYgKGhvb2spIHtcbiAgICAgIHJlZ2lzdGVyKGhvb2suYmluZChwdWJsaWNUaGlzKSk7XG4gICAgfVxuICB9XG4gIHJlZ2lzdGVyTGlmZWN5Y2xlSG9vayhvbkJlZm9yZU1vdW50LCBiZWZvcmVNb3VudCk7XG4gIHJlZ2lzdGVyTGlmZWN5Y2xlSG9vayhvbk1vdW50ZWQsIG1vdW50ZWQpO1xuICByZWdpc3RlckxpZmVjeWNsZUhvb2sob25CZWZvcmVVcGRhdGUsIGJlZm9yZVVwZGF0ZSk7XG4gIHJlZ2lzdGVyTGlmZWN5Y2xlSG9vayhvblVwZGF0ZWQsIHVwZGF0ZWQpO1xuICByZWdpc3RlckxpZmVjeWNsZUhvb2sob25BY3RpdmF0ZWQsIGFjdGl2YXRlZCk7XG4gIHJlZ2lzdGVyTGlmZWN5Y2xlSG9vayhvbkRlYWN0aXZhdGVkLCBkZWFjdGl2YXRlZCk7XG4gIHJlZ2lzdGVyTGlmZWN5Y2xlSG9vayhvbkVycm9yQ2FwdHVyZWQsIGVycm9yQ2FwdHVyZWQpO1xuICByZWdpc3RlckxpZmVjeWNsZUhvb2sob25SZW5kZXJUcmFja2VkLCByZW5kZXJUcmFja2VkKTtcbiAgcmVnaXN0ZXJMaWZlY3ljbGVIb29rKG9uUmVuZGVyVHJpZ2dlcmVkLCByZW5kZXJUcmlnZ2VyZWQpO1xuICByZWdpc3RlckxpZmVjeWNsZUhvb2sob25CZWZvcmVVbm1vdW50LCBiZWZvcmVVbm1vdW50KTtcbiAgcmVnaXN0ZXJMaWZlY3ljbGVIb29rKG9uVW5tb3VudGVkLCB1bm1vdW50ZWQpO1xuICByZWdpc3RlckxpZmVjeWNsZUhvb2sob25TZXJ2ZXJQcmVmZXRjaCwgc2VydmVyUHJlZmV0Y2gpO1xuICBpZiAoaXNBcnJheShleHBvc2UpKSB7XG4gICAgaWYgKGV4cG9zZS5sZW5ndGgpIHtcbiAgICAgIGNvbnN0IGV4cG9zZWQgPSBpbnN0YW5jZS5leHBvc2VkIHx8IChpbnN0YW5jZS5leHBvc2VkID0ge30pO1xuICAgICAgZXhwb3NlLmZvckVhY2goKGtleSkgPT4ge1xuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3NlZCwga2V5LCB7XG4gICAgICAgICAgZ2V0OiAoKSA9PiBwdWJsaWNUaGlzW2tleV0sXG4gICAgICAgICAgc2V0OiAodmFsKSA9PiBwdWJsaWNUaGlzW2tleV0gPSB2YWwsXG4gICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZVxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAoIWluc3RhbmNlLmV4cG9zZWQpIHtcbiAgICAgIGluc3RhbmNlLmV4cG9zZWQgPSB7fTtcbiAgICB9XG4gIH1cbiAgaWYgKHJlbmRlciAmJiBpbnN0YW5jZS5yZW5kZXIgPT09IE5PT1ApIHtcbiAgICBpbnN0YW5jZS5yZW5kZXIgPSByZW5kZXI7XG4gIH1cbiAgaWYgKGluaGVyaXRBdHRycyAhPSBudWxsKSB7XG4gICAgaW5zdGFuY2UuaW5oZXJpdEF0dHJzID0gaW5oZXJpdEF0dHJzO1xuICB9XG4gIGlmIChjb21wb25lbnRzKSBpbnN0YW5jZS5jb21wb25lbnRzID0gY29tcG9uZW50cztcbiAgaWYgKGRpcmVjdGl2ZXMpIGluc3RhbmNlLmRpcmVjdGl2ZXMgPSBkaXJlY3RpdmVzO1xuICBpZiAoc2VydmVyUHJlZmV0Y2gpIHtcbiAgICBtYXJrQXN5bmNCb3VuZGFyeShpbnN0YW5jZSk7XG4gIH1cbn1cbmZ1bmN0aW9uIHJlc29sdmVJbmplY3Rpb25zKGluamVjdE9wdGlvbnMsIGN0eCwgY2hlY2tEdXBsaWNhdGVQcm9wZXJ0aWVzID0gTk9PUCkge1xuICBpZiAoaXNBcnJheShpbmplY3RPcHRpb25zKSkge1xuICAgIGluamVjdE9wdGlvbnMgPSBub3JtYWxpemVJbmplY3QoaW5qZWN0T3B0aW9ucyk7XG4gIH1cbiAgZm9yIChjb25zdCBrZXkgaW4gaW5qZWN0T3B0aW9ucykge1xuICAgIGNvbnN0IG9wdCA9IGluamVjdE9wdGlvbnNba2V5XTtcbiAgICBsZXQgaW5qZWN0ZWQ7XG4gICAgaWYgKGlzT2JqZWN0KG9wdCkpIHtcbiAgICAgIGlmIChcImRlZmF1bHRcIiBpbiBvcHQpIHtcbiAgICAgICAgaW5qZWN0ZWQgPSBpbmplY3QoXG4gICAgICAgICAgb3B0LmZyb20gfHwga2V5LFxuICAgICAgICAgIG9wdC5kZWZhdWx0LFxuICAgICAgICAgIHRydWVcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGluamVjdGVkID0gaW5qZWN0KG9wdC5mcm9tIHx8IGtleSk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGluamVjdGVkID0gaW5qZWN0KG9wdCk7XG4gICAgfVxuICAgIGlmIChpc1JlZihpbmplY3RlZCkpIHtcbiAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjdHgsIGtleSwge1xuICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgIGdldDogKCkgPT4gaW5qZWN0ZWQudmFsdWUsXG4gICAgICAgIHNldDogKHYpID0+IGluamVjdGVkLnZhbHVlID0gdlxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGN0eFtrZXldID0gaW5qZWN0ZWQ7XG4gICAgfVxuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICBjaGVja0R1cGxpY2F0ZVByb3BlcnRpZXMoXCJJbmplY3RcIiAvKiBJTkpFQ1QgKi8sIGtleSk7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBjYWxsSG9vayhob29rLCBpbnN0YW5jZSwgdHlwZSkge1xuICBjYWxsV2l0aEFzeW5jRXJyb3JIYW5kbGluZyhcbiAgICBpc0FycmF5KGhvb2spID8gaG9vay5tYXAoKGgpID0+IGguYmluZChpbnN0YW5jZS5wcm94eSkpIDogaG9vay5iaW5kKGluc3RhbmNlLnByb3h5KSxcbiAgICBpbnN0YW5jZSxcbiAgICB0eXBlXG4gICk7XG59XG5mdW5jdGlvbiBjcmVhdGVXYXRjaGVyKHJhdywgY3R4LCBwdWJsaWNUaGlzLCBrZXkpIHtcbiAgbGV0IGdldHRlciA9IGtleS5pbmNsdWRlcyhcIi5cIikgPyBjcmVhdGVQYXRoR2V0dGVyKHB1YmxpY1RoaXMsIGtleSkgOiAoKSA9PiBwdWJsaWNUaGlzW2tleV07XG4gIGlmIChpc1N0cmluZyhyYXcpKSB7XG4gICAgY29uc3QgaGFuZGxlciA9IGN0eFtyYXddO1xuICAgIGlmIChpc0Z1bmN0aW9uKGhhbmRsZXIpKSB7XG4gICAgICB7XG4gICAgICAgIHdhdGNoKGdldHRlciwgaGFuZGxlcik7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICB3YXJuJDEoYEludmFsaWQgd2F0Y2ggaGFuZGxlciBzcGVjaWZpZWQgYnkga2V5IFwiJHtyYXd9XCJgLCBoYW5kbGVyKTtcbiAgICB9XG4gIH0gZWxzZSBpZiAoaXNGdW5jdGlvbihyYXcpKSB7XG4gICAge1xuICAgICAgd2F0Y2goZ2V0dGVyLCByYXcuYmluZChwdWJsaWNUaGlzKSk7XG4gICAgfVxuICB9IGVsc2UgaWYgKGlzT2JqZWN0KHJhdykpIHtcbiAgICBpZiAoaXNBcnJheShyYXcpKSB7XG4gICAgICByYXcuZm9yRWFjaCgocikgPT4gY3JlYXRlV2F0Y2hlcihyLCBjdHgsIHB1YmxpY1RoaXMsIGtleSkpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBoYW5kbGVyID0gaXNGdW5jdGlvbihyYXcuaGFuZGxlcikgPyByYXcuaGFuZGxlci5iaW5kKHB1YmxpY1RoaXMpIDogY3R4W3Jhdy5oYW5kbGVyXTtcbiAgICAgIGlmIChpc0Z1bmN0aW9uKGhhbmRsZXIpKSB7XG4gICAgICAgIHdhdGNoKGdldHRlciwgaGFuZGxlciwgcmF3KTtcbiAgICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICB3YXJuJDEoYEludmFsaWQgd2F0Y2ggaGFuZGxlciBzcGVjaWZpZWQgYnkga2V5IFwiJHtyYXcuaGFuZGxlcn1cImAsIGhhbmRsZXIpO1xuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgd2FybiQxKGBJbnZhbGlkIHdhdGNoIG9wdGlvbjogXCIke2tleX1cImAsIHJhdyk7XG4gIH1cbn1cbmZ1bmN0aW9uIHJlc29sdmVNZXJnZWRPcHRpb25zKGluc3RhbmNlKSB7XG4gIGNvbnN0IGJhc2UgPSBpbnN0YW5jZS50eXBlO1xuICBjb25zdCB7IG1peGlucywgZXh0ZW5kczogZXh0ZW5kc09wdGlvbnMgfSA9IGJhc2U7XG4gIGNvbnN0IHtcbiAgICBtaXhpbnM6IGdsb2JhbE1peGlucyxcbiAgICBvcHRpb25zQ2FjaGU6IGNhY2hlLFxuICAgIGNvbmZpZzogeyBvcHRpb25NZXJnZVN0cmF0ZWdpZXMgfVxuICB9ID0gaW5zdGFuY2UuYXBwQ29udGV4dDtcbiAgY29uc3QgY2FjaGVkID0gY2FjaGUuZ2V0KGJhc2UpO1xuICBsZXQgcmVzb2x2ZWQ7XG4gIGlmIChjYWNoZWQpIHtcbiAgICByZXNvbHZlZCA9IGNhY2hlZDtcbiAgfSBlbHNlIGlmICghZ2xvYmFsTWl4aW5zLmxlbmd0aCAmJiAhbWl4aW5zICYmICFleHRlbmRzT3B0aW9ucykge1xuICAgIHtcbiAgICAgIHJlc29sdmVkID0gYmFzZTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgcmVzb2x2ZWQgPSB7fTtcbiAgICBpZiAoZ2xvYmFsTWl4aW5zLmxlbmd0aCkge1xuICAgICAgZ2xvYmFsTWl4aW5zLmZvckVhY2goXG4gICAgICAgIChtKSA9PiBtZXJnZU9wdGlvbnMocmVzb2x2ZWQsIG0sIG9wdGlvbk1lcmdlU3RyYXRlZ2llcywgdHJ1ZSlcbiAgICAgICk7XG4gICAgfVxuICAgIG1lcmdlT3B0aW9ucyhyZXNvbHZlZCwgYmFzZSwgb3B0aW9uTWVyZ2VTdHJhdGVnaWVzKTtcbiAgfVxuICBpZiAoaXNPYmplY3QoYmFzZSkpIHtcbiAgICBjYWNoZS5zZXQoYmFzZSwgcmVzb2x2ZWQpO1xuICB9XG4gIHJldHVybiByZXNvbHZlZDtcbn1cbmZ1bmN0aW9uIG1lcmdlT3B0aW9ucyh0bywgZnJvbSwgc3RyYXRzLCBhc01peGluID0gZmFsc2UpIHtcbiAgY29uc3QgeyBtaXhpbnMsIGV4dGVuZHM6IGV4dGVuZHNPcHRpb25zIH0gPSBmcm9tO1xuICBpZiAoZXh0ZW5kc09wdGlvbnMpIHtcbiAgICBtZXJnZU9wdGlvbnModG8sIGV4dGVuZHNPcHRpb25zLCBzdHJhdHMsIHRydWUpO1xuICB9XG4gIGlmIChtaXhpbnMpIHtcbiAgICBtaXhpbnMuZm9yRWFjaChcbiAgICAgIChtKSA9PiBtZXJnZU9wdGlvbnModG8sIG0sIHN0cmF0cywgdHJ1ZSlcbiAgICApO1xuICB9XG4gIGZvciAoY29uc3Qga2V5IGluIGZyb20pIHtcbiAgICBpZiAoYXNNaXhpbiAmJiBrZXkgPT09IFwiZXhwb3NlXCIpIHtcbiAgICAgICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgd2FybiQxKFxuICAgICAgICBgXCJleHBvc2VcIiBvcHRpb24gaXMgaWdub3JlZCB3aGVuIGRlY2xhcmVkIGluIG1peGlucyBvciBleHRlbmRzLiBJdCBzaG91bGQgb25seSBiZSBkZWNsYXJlZCBpbiB0aGUgYmFzZSBjb21wb25lbnQgaXRzZWxmLmBcbiAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHN0cmF0ID0gaW50ZXJuYWxPcHRpb25NZXJnZVN0cmF0c1trZXldIHx8IHN0cmF0cyAmJiBzdHJhdHNba2V5XTtcbiAgICAgIHRvW2tleV0gPSBzdHJhdCA/IHN0cmF0KHRvW2tleV0sIGZyb21ba2V5XSkgOiBmcm9tW2tleV07XG4gICAgfVxuICB9XG4gIHJldHVybiB0bztcbn1cbmNvbnN0IGludGVybmFsT3B0aW9uTWVyZ2VTdHJhdHMgPSB7XG4gIGRhdGE6IG1lcmdlRGF0YUZuLFxuICBwcm9wczogbWVyZ2VFbWl0c09yUHJvcHNPcHRpb25zLFxuICBlbWl0czogbWVyZ2VFbWl0c09yUHJvcHNPcHRpb25zLFxuICAvLyBvYmplY3RzXG4gIG1ldGhvZHM6IG1lcmdlT2JqZWN0T3B0aW9ucyxcbiAgY29tcHV0ZWQ6IG1lcmdlT2JqZWN0T3B0aW9ucyxcbiAgLy8gbGlmZWN5Y2xlXG4gIGJlZm9yZUNyZWF0ZTogbWVyZ2VBc0FycmF5LFxuICBjcmVhdGVkOiBtZXJnZUFzQXJyYXksXG4gIGJlZm9yZU1vdW50OiBtZXJnZUFzQXJyYXksXG4gIG1vdW50ZWQ6IG1lcmdlQXNBcnJheSxcbiAgYmVmb3JlVXBkYXRlOiBtZXJnZUFzQXJyYXksXG4gIHVwZGF0ZWQ6IG1lcmdlQXNBcnJheSxcbiAgYmVmb3JlRGVzdHJveTogbWVyZ2VBc0FycmF5LFxuICBiZWZvcmVVbm1vdW50OiBtZXJnZUFzQXJyYXksXG4gIGRlc3Ryb3llZDogbWVyZ2VBc0FycmF5LFxuICB1bm1vdW50ZWQ6IG1lcmdlQXNBcnJheSxcbiAgYWN0aXZhdGVkOiBtZXJnZUFzQXJyYXksXG4gIGRlYWN0aXZhdGVkOiBtZXJnZUFzQXJyYXksXG4gIGVycm9yQ2FwdHVyZWQ6IG1lcmdlQXNBcnJheSxcbiAgc2VydmVyUHJlZmV0Y2g6IG1lcmdlQXNBcnJheSxcbiAgLy8gYXNzZXRzXG4gIGNvbXBvbmVudHM6IG1lcmdlT2JqZWN0T3B0aW9ucyxcbiAgZGlyZWN0aXZlczogbWVyZ2VPYmplY3RPcHRpb25zLFxuICAvLyB3YXRjaFxuICB3YXRjaDogbWVyZ2VXYXRjaE9wdGlvbnMsXG4gIC8vIHByb3ZpZGUgLyBpbmplY3RcbiAgcHJvdmlkZTogbWVyZ2VEYXRhRm4sXG4gIGluamVjdDogbWVyZ2VJbmplY3Rcbn07XG5mdW5jdGlvbiBtZXJnZURhdGFGbih0bywgZnJvbSkge1xuICBpZiAoIWZyb20pIHtcbiAgICByZXR1cm4gdG87XG4gIH1cbiAgaWYgKCF0bykge1xuICAgIHJldHVybiBmcm9tO1xuICB9XG4gIHJldHVybiBmdW5jdGlvbiBtZXJnZWREYXRhRm4oKSB7XG4gICAgcmV0dXJuIChleHRlbmQpKFxuICAgICAgaXNGdW5jdGlvbih0bykgPyB0by5jYWxsKHRoaXMsIHRoaXMpIDogdG8sXG4gICAgICBpc0Z1bmN0aW9uKGZyb20pID8gZnJvbS5jYWxsKHRoaXMsIHRoaXMpIDogZnJvbVxuICAgICk7XG4gIH07XG59XG5mdW5jdGlvbiBtZXJnZUluamVjdCh0bywgZnJvbSkge1xuICByZXR1cm4gbWVyZ2VPYmplY3RPcHRpb25zKG5vcm1hbGl6ZUluamVjdCh0byksIG5vcm1hbGl6ZUluamVjdChmcm9tKSk7XG59XG5mdW5jdGlvbiBub3JtYWxpemVJbmplY3QocmF3KSB7XG4gIGlmIChpc0FycmF5KHJhdykpIHtcbiAgICBjb25zdCByZXMgPSB7fTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJhdy5sZW5ndGg7IGkrKykge1xuICAgICAgcmVzW3Jhd1tpXV0gPSByYXdbaV07XG4gICAgfVxuICAgIHJldHVybiByZXM7XG4gIH1cbiAgcmV0dXJuIHJhdztcbn1cbmZ1bmN0aW9uIG1lcmdlQXNBcnJheSh0bywgZnJvbSkge1xuICByZXR1cm4gdG8gPyBbLi4ubmV3IFNldChbXS5jb25jYXQodG8sIGZyb20pKV0gOiBmcm9tO1xufVxuZnVuY3Rpb24gbWVyZ2VPYmplY3RPcHRpb25zKHRvLCBmcm9tKSB7XG4gIHJldHVybiB0byA/IGV4dGVuZCgvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKSwgdG8sIGZyb20pIDogZnJvbTtcbn1cbmZ1bmN0aW9uIG1lcmdlRW1pdHNPclByb3BzT3B0aW9ucyh0bywgZnJvbSkge1xuICBpZiAodG8pIHtcbiAgICBpZiAoaXNBcnJheSh0bykgJiYgaXNBcnJheShmcm9tKSkge1xuICAgICAgcmV0dXJuIFsuLi4vKiBAX19QVVJFX18gKi8gbmV3IFNldChbLi4udG8sIC4uLmZyb21dKV07XG4gICAgfVxuICAgIHJldHVybiBleHRlbmQoXG4gICAgICAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmNyZWF0ZShudWxsKSxcbiAgICAgIG5vcm1hbGl6ZVByb3BzT3JFbWl0cyh0byksXG4gICAgICBub3JtYWxpemVQcm9wc09yRW1pdHMoZnJvbSAhPSBudWxsID8gZnJvbSA6IHt9KVxuICAgICk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIGZyb207XG4gIH1cbn1cbmZ1bmN0aW9uIG1lcmdlV2F0Y2hPcHRpb25zKHRvLCBmcm9tKSB7XG4gIGlmICghdG8pIHJldHVybiBmcm9tO1xuICBpZiAoIWZyb20pIHJldHVybiB0bztcbiAgY29uc3QgbWVyZ2VkID0gZXh0ZW5kKC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpLCB0byk7XG4gIGZvciAoY29uc3Qga2V5IGluIGZyb20pIHtcbiAgICBtZXJnZWRba2V5XSA9IG1lcmdlQXNBcnJheSh0b1trZXldLCBmcm9tW2tleV0pO1xuICB9XG4gIHJldHVybiBtZXJnZWQ7XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZUFwcENvbnRleHQoKSB7XG4gIHJldHVybiB7XG4gICAgYXBwOiBudWxsLFxuICAgIGNvbmZpZzoge1xuICAgICAgaXNOYXRpdmVUYWc6IE5PLFxuICAgICAgcGVyZm9ybWFuY2U6IGZhbHNlLFxuICAgICAgZ2xvYmFsUHJvcGVydGllczoge30sXG4gICAgICBvcHRpb25NZXJnZVN0cmF0ZWdpZXM6IHt9LFxuICAgICAgZXJyb3JIYW5kbGVyOiB2b2lkIDAsXG4gICAgICB3YXJuSGFuZGxlcjogdm9pZCAwLFxuICAgICAgY29tcGlsZXJPcHRpb25zOiB7fVxuICAgIH0sXG4gICAgbWl4aW5zOiBbXSxcbiAgICBjb21wb25lbnRzOiB7fSxcbiAgICBkaXJlY3RpdmVzOiB7fSxcbiAgICBwcm92aWRlczogLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCksXG4gICAgb3B0aW9uc0NhY2hlOiAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKSxcbiAgICBwcm9wc0NhY2hlOiAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKSxcbiAgICBlbWl0c0NhY2hlOiAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKVxuICB9O1xufVxubGV0IHVpZCQxID0gMDtcbmZ1bmN0aW9uIGNyZWF0ZUFwcEFQSShyZW5kZXIsIGh5ZHJhdGUpIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIGNyZWF0ZUFwcChyb290Q29tcG9uZW50LCByb290UHJvcHMgPSBudWxsKSB7XG4gICAgaWYgKCFpc0Z1bmN0aW9uKHJvb3RDb21wb25lbnQpKSB7XG4gICAgICByb290Q29tcG9uZW50ID0gZXh0ZW5kKHt9LCByb290Q29tcG9uZW50KTtcbiAgICB9XG4gICAgaWYgKHJvb3RQcm9wcyAhPSBudWxsICYmICFpc09iamVjdChyb290UHJvcHMpKSB7XG4gICAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdhcm4kMShgcm9vdCBwcm9wcyBwYXNzZWQgdG8gYXBwLm1vdW50KCkgbXVzdCBiZSBhbiBvYmplY3QuYCk7XG4gICAgICByb290UHJvcHMgPSBudWxsO1xuICAgIH1cbiAgICBjb25zdCBjb250ZXh0ID0gY3JlYXRlQXBwQ29udGV4dCgpO1xuICAgIGNvbnN0IGluc3RhbGxlZFBsdWdpbnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtTZXQoKTtcbiAgICBjb25zdCBwbHVnaW5DbGVhbnVwRm5zID0gW107XG4gICAgbGV0IGlzTW91bnRlZCA9IGZhbHNlO1xuICAgIGNvbnN0IGFwcCA9IGNvbnRleHQuYXBwID0ge1xuICAgICAgX3VpZDogdWlkJDErKyxcbiAgICAgIF9jb21wb25lbnQ6IHJvb3RDb21wb25lbnQsXG4gICAgICBfcHJvcHM6IHJvb3RQcm9wcyxcbiAgICAgIF9jb250YWluZXI6IG51bGwsXG4gICAgICBfY29udGV4dDogY29udGV4dCxcbiAgICAgIF9pbnN0YW5jZTogbnVsbCxcbiAgICAgIHZlcnNpb24sXG4gICAgICBnZXQgY29uZmlnKCkge1xuICAgICAgICByZXR1cm4gY29udGV4dC5jb25maWc7XG4gICAgICB9LFxuICAgICAgc2V0IGNvbmZpZyh2KSB7XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgd2FybiQxKFxuICAgICAgICAgICAgYGFwcC5jb25maWcgY2Fubm90IGJlIHJlcGxhY2VkLiBNb2RpZnkgaW5kaXZpZHVhbCBvcHRpb25zIGluc3RlYWQuYFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICB1c2UocGx1Z2luLCAuLi5vcHRpb25zKSB7XG4gICAgICAgIGlmIChpbnN0YWxsZWRQbHVnaW5zLmhhcyhwbHVnaW4pKSB7XG4gICAgICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB3YXJuJDEoYFBsdWdpbiBoYXMgYWxyZWFkeSBiZWVuIGFwcGxpZWQgdG8gdGFyZ2V0IGFwcC5gKTtcbiAgICAgICAgfSBlbHNlIGlmIChwbHVnaW4gJiYgaXNGdW5jdGlvbihwbHVnaW4uaW5zdGFsbCkpIHtcbiAgICAgICAgICBpbnN0YWxsZWRQbHVnaW5zLmFkZChwbHVnaW4pO1xuICAgICAgICAgIHBsdWdpbi5pbnN0YWxsKGFwcCwgLi4ub3B0aW9ucyk7XG4gICAgICAgIH0gZWxzZSBpZiAoaXNGdW5jdGlvbihwbHVnaW4pKSB7XG4gICAgICAgICAgaW5zdGFsbGVkUGx1Z2lucy5hZGQocGx1Z2luKTtcbiAgICAgICAgICBwbHVnaW4oYXBwLCAuLi5vcHRpb25zKTtcbiAgICAgICAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgd2FybiQxKFxuICAgICAgICAgICAgYEEgcGx1Z2luIG11c3QgZWl0aGVyIGJlIGEgZnVuY3Rpb24gb3IgYW4gb2JqZWN0IHdpdGggYW4gXCJpbnN0YWxsXCIgZnVuY3Rpb24uYFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGFwcDtcbiAgICAgIH0sXG4gICAgICBtaXhpbihtaXhpbikge1xuICAgICAgICBpZiAoX19WVUVfT1BUSU9OU19BUElfXykge1xuICAgICAgICAgIGlmICghY29udGV4dC5taXhpbnMuaW5jbHVkZXMobWl4aW4pKSB7XG4gICAgICAgICAgICBjb250ZXh0Lm1peGlucy5wdXNoKG1peGluKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICAgIHdhcm4kMShcbiAgICAgICAgICAgICAgXCJNaXhpbiBoYXMgYWxyZWFkeSBiZWVuIGFwcGxpZWQgdG8gdGFyZ2V0IGFwcFwiICsgKG1peGluLm5hbWUgPyBgOiAke21peGluLm5hbWV9YCA6IFwiXCIpXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgd2FybiQxKFwiTWl4aW5zIGFyZSBvbmx5IGF2YWlsYWJsZSBpbiBidWlsZHMgc3VwcG9ydGluZyBPcHRpb25zIEFQSVwiKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYXBwO1xuICAgICAgfSxcbiAgICAgIGNvbXBvbmVudChuYW1lLCBjb21wb25lbnQpIHtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICB2YWxpZGF0ZUNvbXBvbmVudE5hbWUobmFtZSwgY29udGV4dC5jb25maWcpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghY29tcG9uZW50KSB7XG4gICAgICAgICAgcmV0dXJuIGNvbnRleHQuY29tcG9uZW50c1tuYW1lXTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBjb250ZXh0LmNvbXBvbmVudHNbbmFtZV0pIHtcbiAgICAgICAgICB3YXJuJDEoYENvbXBvbmVudCBcIiR7bmFtZX1cIiBoYXMgYWxyZWFkeSBiZWVuIHJlZ2lzdGVyZWQgaW4gdGFyZ2V0IGFwcC5gKTtcbiAgICAgICAgfVxuICAgICAgICBjb250ZXh0LmNvbXBvbmVudHNbbmFtZV0gPSBjb21wb25lbnQ7XG4gICAgICAgIHJldHVybiBhcHA7XG4gICAgICB9LFxuICAgICAgZGlyZWN0aXZlKG5hbWUsIGRpcmVjdGl2ZSkge1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIHZhbGlkYXRlRGlyZWN0aXZlTmFtZShuYW1lKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWRpcmVjdGl2ZSkge1xuICAgICAgICAgIHJldHVybiBjb250ZXh0LmRpcmVjdGl2ZXNbbmFtZV07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgY29udGV4dC5kaXJlY3RpdmVzW25hbWVdKSB7XG4gICAgICAgICAgd2FybiQxKGBEaXJlY3RpdmUgXCIke25hbWV9XCIgaGFzIGFscmVhZHkgYmVlbiByZWdpc3RlcmVkIGluIHRhcmdldCBhcHAuYCk7XG4gICAgICAgIH1cbiAgICAgICAgY29udGV4dC5kaXJlY3RpdmVzW25hbWVdID0gZGlyZWN0aXZlO1xuICAgICAgICByZXR1cm4gYXBwO1xuICAgICAgfSxcbiAgICAgIG1vdW50KHJvb3RDb250YWluZXIsIGlzSHlkcmF0ZSwgbmFtZXNwYWNlKSB7XG4gICAgICAgIGlmICghaXNNb3VudGVkKSB7XG4gICAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgcm9vdENvbnRhaW5lci5fX3Z1ZV9hcHBfXykge1xuICAgICAgICAgICAgd2FybiQxKFxuICAgICAgICAgICAgICBgVGhlcmUgaXMgYWxyZWFkeSBhbiBhcHAgaW5zdGFuY2UgbW91bnRlZCBvbiB0aGUgaG9zdCBjb250YWluZXIuXG4gSWYgeW91IHdhbnQgdG8gbW91bnQgYW5vdGhlciBhcHAgb24gdGhlIHNhbWUgaG9zdCBjb250YWluZXIsIHlvdSBuZWVkIHRvIHVubW91bnQgdGhlIHByZXZpb3VzIGFwcCBieSBjYWxsaW5nIFxcYGFwcC51bm1vdW50KClcXGAgZmlyc3QuYFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3Qgdm5vZGUgPSBhcHAuX2NlVk5vZGUgfHwgY3JlYXRlVk5vZGUocm9vdENvbXBvbmVudCwgcm9vdFByb3BzKTtcbiAgICAgICAgICB2bm9kZS5hcHBDb250ZXh0ID0gY29udGV4dDtcbiAgICAgICAgICBpZiAobmFtZXNwYWNlID09PSB0cnVlKSB7XG4gICAgICAgICAgICBuYW1lc3BhY2UgPSBcInN2Z1wiO1xuICAgICAgICAgIH0gZWxzZSBpZiAobmFtZXNwYWNlID09PSBmYWxzZSkge1xuICAgICAgICAgICAgbmFtZXNwYWNlID0gdm9pZCAwO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgICAgY29udGV4dC5yZWxvYWQgPSAoKSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGNsb25lZCA9IGNsb25lVk5vZGUodm5vZGUpO1xuICAgICAgICAgICAgICBjbG9uZWQuZWwgPSBudWxsO1xuICAgICAgICAgICAgICByZW5kZXIoY2xvbmVkLCByb290Q29udGFpbmVyLCBuYW1lc3BhY2UpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKGlzSHlkcmF0ZSAmJiBoeWRyYXRlKSB7XG4gICAgICAgICAgICBoeWRyYXRlKHZub2RlLCByb290Q29udGFpbmVyKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVuZGVyKHZub2RlLCByb290Q29udGFpbmVyLCBuYW1lc3BhY2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpc01vdW50ZWQgPSB0cnVlO1xuICAgICAgICAgIGFwcC5fY29udGFpbmVyID0gcm9vdENvbnRhaW5lcjtcbiAgICAgICAgICByb290Q29udGFpbmVyLl9fdnVlX2FwcF9fID0gYXBwO1xuICAgICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykge1xuICAgICAgICAgICAgYXBwLl9pbnN0YW5jZSA9IHZub2RlLmNvbXBvbmVudDtcbiAgICAgICAgICAgIGRldnRvb2xzSW5pdEFwcChhcHAsIHZlcnNpb24pO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gZ2V0Q29tcG9uZW50UHVibGljSW5zdGFuY2Uodm5vZGUuY29tcG9uZW50KTtcbiAgICAgICAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgd2FybiQxKFxuICAgICAgICAgICAgYEFwcCBoYXMgYWxyZWFkeSBiZWVuIG1vdW50ZWQuXG5JZiB5b3Ugd2FudCB0byByZW1vdW50IHRoZSBzYW1lIGFwcCwgbW92ZSB5b3VyIGFwcCBjcmVhdGlvbiBsb2dpYyBpbnRvIGEgZmFjdG9yeSBmdW5jdGlvbiBhbmQgY3JlYXRlIGZyZXNoIGFwcCBpbnN0YW5jZXMgZm9yIGVhY2ggbW91bnQgLSBlLmcuIFxcYGNvbnN0IGNyZWF0ZU15QXBwID0gKCkgPT4gY3JlYXRlQXBwKEFwcClcXGBgXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIG9uVW5tb3VudChjbGVhbnVwRm4pIHtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgdHlwZW9mIGNsZWFudXBGbiAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgd2FybiQxKFxuICAgICAgICAgICAgYEV4cGVjdGVkIGZ1bmN0aW9uIGFzIGZpcnN0IGFyZ3VtZW50IHRvIGFwcC5vblVubW91bnQoKSwgYnV0IGdvdCAke3R5cGVvZiBjbGVhbnVwRm59YFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgICAgcGx1Z2luQ2xlYW51cEZucy5wdXNoKGNsZWFudXBGbik7XG4gICAgICB9LFxuICAgICAgdW5tb3VudCgpIHtcbiAgICAgICAgaWYgKGlzTW91bnRlZCkge1xuICAgICAgICAgIGNhbGxXaXRoQXN5bmNFcnJvckhhbmRsaW5nKFxuICAgICAgICAgICAgcGx1Z2luQ2xlYW51cEZucyxcbiAgICAgICAgICAgIGFwcC5faW5zdGFuY2UsXG4gICAgICAgICAgICAxNlxuICAgICAgICAgICk7XG4gICAgICAgICAgcmVuZGVyKG51bGwsIGFwcC5fY29udGFpbmVyKTtcbiAgICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pIHtcbiAgICAgICAgICAgIGFwcC5faW5zdGFuY2UgPSBudWxsO1xuICAgICAgICAgICAgZGV2dG9vbHNVbm1vdW50QXBwKGFwcCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGRlbGV0ZSBhcHAuX2NvbnRhaW5lci5fX3Z1ZV9hcHBfXztcbiAgICAgICAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgd2FybiQxKGBDYW5ub3QgdW5tb3VudCBhbiBhcHAgdGhhdCBpcyBub3QgbW91bnRlZC5gKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHByb3ZpZGUoa2V5LCB2YWx1ZSkge1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBrZXkgaW4gY29udGV4dC5wcm92aWRlcykge1xuICAgICAgICAgIGlmIChoYXNPd24oY29udGV4dC5wcm92aWRlcywga2V5KSkge1xuICAgICAgICAgICAgd2FybiQxKFxuICAgICAgICAgICAgICBgQXBwIGFscmVhZHkgcHJvdmlkZXMgcHJvcGVydHkgd2l0aCBrZXkgXCIke1N0cmluZyhrZXkpfVwiLiBJdCB3aWxsIGJlIG92ZXJ3cml0dGVuIHdpdGggdGhlIG5ldyB2YWx1ZS5gXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgICAgIGBBcHAgYWxyZWFkeSBwcm92aWRlcyBwcm9wZXJ0eSB3aXRoIGtleSBcIiR7U3RyaW5nKGtleSl9XCIgaW5oZXJpdGVkIGZyb20gaXRzIHBhcmVudCBlbGVtZW50LiBJdCB3aWxsIGJlIG92ZXJ3cml0dGVuIHdpdGggdGhlIG5ldyB2YWx1ZS5gXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb250ZXh0LnByb3ZpZGVzW2tleV0gPSB2YWx1ZTtcbiAgICAgICAgcmV0dXJuIGFwcDtcbiAgICAgIH0sXG4gICAgICBydW5XaXRoQ29udGV4dChmbikge1xuICAgICAgICBjb25zdCBsYXN0QXBwID0gY3VycmVudEFwcDtcbiAgICAgICAgY3VycmVudEFwcCA9IGFwcDtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXR1cm4gZm4oKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICBjdXJyZW50QXBwID0gbGFzdEFwcDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgcmV0dXJuIGFwcDtcbiAgfTtcbn1cbmxldCBjdXJyZW50QXBwID0gbnVsbDtcblxuZnVuY3Rpb24gdXNlTW9kZWwocHJvcHMsIG5hbWUsIG9wdGlvbnMgPSBFTVBUWV9PQkopIHtcbiAgY29uc3QgaSA9IGdldEN1cnJlbnRJbnN0YW5jZSgpO1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiAhaSkge1xuICAgIHdhcm4kMShgdXNlTW9kZWwoKSBjYWxsZWQgd2l0aG91dCBhY3RpdmUgaW5zdGFuY2UuYCk7XG4gICAgcmV0dXJuIHJlZigpO1xuICB9XG4gIGNvbnN0IGNhbWVsaXplZE5hbWUgPSBjYW1lbGl6ZShuYW1lKTtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWkucHJvcHNPcHRpb25zWzBdW2NhbWVsaXplZE5hbWVdKSB7XG4gICAgd2FybiQxKGB1c2VNb2RlbCgpIGNhbGxlZCB3aXRoIHByb3AgXCIke25hbWV9XCIgd2hpY2ggaXMgbm90IGRlY2xhcmVkLmApO1xuICAgIHJldHVybiByZWYoKTtcbiAgfVxuICBjb25zdCBoeXBoZW5hdGVkTmFtZSA9IGh5cGhlbmF0ZShuYW1lKTtcbiAgY29uc3QgbW9kaWZpZXJzID0gZ2V0TW9kZWxNb2RpZmllcnMocHJvcHMsIGNhbWVsaXplZE5hbWUpO1xuICBjb25zdCByZXMgPSBjdXN0b21SZWYoKHRyYWNrLCB0cmlnZ2VyKSA9PiB7XG4gICAgbGV0IGxvY2FsVmFsdWU7XG4gICAgbGV0IHByZXZTZXRWYWx1ZSA9IEVNUFRZX09CSjtcbiAgICBsZXQgcHJldkVtaXR0ZWRWYWx1ZTtcbiAgICB3YXRjaFN5bmNFZmZlY3QoKCkgPT4ge1xuICAgICAgY29uc3QgcHJvcFZhbHVlID0gcHJvcHNbY2FtZWxpemVkTmFtZV07XG4gICAgICBpZiAoaGFzQ2hhbmdlZChsb2NhbFZhbHVlLCBwcm9wVmFsdWUpKSB7XG4gICAgICAgIGxvY2FsVmFsdWUgPSBwcm9wVmFsdWU7XG4gICAgICAgIHRyaWdnZXIoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4ge1xuICAgICAgZ2V0KCkge1xuICAgICAgICB0cmFjaygpO1xuICAgICAgICByZXR1cm4gb3B0aW9ucy5nZXQgPyBvcHRpb25zLmdldChsb2NhbFZhbHVlKSA6IGxvY2FsVmFsdWU7XG4gICAgICB9LFxuICAgICAgc2V0KHZhbHVlKSB7XG4gICAgICAgIGNvbnN0IGVtaXR0ZWRWYWx1ZSA9IG9wdGlvbnMuc2V0ID8gb3B0aW9ucy5zZXQodmFsdWUpIDogdmFsdWU7XG4gICAgICAgIGlmICghaGFzQ2hhbmdlZChlbWl0dGVkVmFsdWUsIGxvY2FsVmFsdWUpICYmICEocHJldlNldFZhbHVlICE9PSBFTVBUWV9PQkogJiYgaGFzQ2hhbmdlZCh2YWx1ZSwgcHJldlNldFZhbHVlKSkpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmF3UHJvcHMgPSBpLnZub2RlLnByb3BzO1xuICAgICAgICBjb25zdCBoYXNWTW9kZWwgPSAhIShyYXdQcm9wcyAmJiAvLyBjaGVjayBpZiBwYXJlbnQgaGFzIHBhc3NlZCB2LW1vZGVsXG4gICAgICAgIChuYW1lIGluIHJhd1Byb3BzIHx8IGNhbWVsaXplZE5hbWUgaW4gcmF3UHJvcHMgfHwgaHlwaGVuYXRlZE5hbWUgaW4gcmF3UHJvcHMpICYmIChgb25VcGRhdGU6JHtuYW1lfWAgaW4gcmF3UHJvcHMgfHwgYG9uVXBkYXRlOiR7Y2FtZWxpemVkTmFtZX1gIGluIHJhd1Byb3BzIHx8IGBvblVwZGF0ZToke2h5cGhlbmF0ZWROYW1lfWAgaW4gcmF3UHJvcHMpKTtcbiAgICAgICAgaWYgKCFoYXNWTW9kZWwpIHtcbiAgICAgICAgICBsb2NhbFZhbHVlID0gdmFsdWU7XG4gICAgICAgICAgdHJpZ2dlcigpO1xuICAgICAgICB9XG4gICAgICAgIGkuZW1pdChgdXBkYXRlOiR7bmFtZX1gLCBlbWl0dGVkVmFsdWUpO1xuICAgICAgICBpZiAoaGFzQ2hhbmdlZCh2YWx1ZSwgcHJldlNldFZhbHVlKSAmJiAoaGFzQ2hhbmdlZCh2YWx1ZSwgZW1pdHRlZFZhbHVlKSAmJiAhaGFzQ2hhbmdlZChlbWl0dGVkVmFsdWUsIHByZXZFbWl0dGVkVmFsdWUpIHx8IC8vICMxMzUyNDogYnJvd3NlcnMgZGlmZmVyIGluIHdoZW4gdGhleSBmbHVzaCBtaWNyb3Rhc2tzIGJldHdlZW5cbiAgICAgICAgLy8gZXZlbnQgbGlzdGVuZXJzLiBJZiBhIHYtbW9kZWwgbGlzdGVuZXIgZW1pdHMgYW4gaW50ZXJtZWRpYXRlIHZhbHVlXG4gICAgICAgIC8vIGFuZCBhIGZvbGxvd2luZyBsaXN0ZW5lciByZXN0b3JlcyB0aGUgbW9kZWwgdG8gaXRzIHByZXZpb3VzIHByb3BcbiAgICAgICAgLy8gdmFsdWUgYmVmb3JlIHBhcmVudCB1cGRhdGVzIGFyZSBmbHVzaGVkLCB0aGUgcGFyZW50IHJlbmRlciBjYW4gYmVcbiAgICAgICAgLy8gZGVkdXBlZCBhcyBoYXZpbmcgbm8gcHJvcCBjaGFuZ2UuIEZvcmNlIGEgbG9jYWwgdXBkYXRlIHNvIERPTSBzdGF0ZVxuICAgICAgICAvLyBzdWNoIGFzIGFuIGlucHV0J3MgdmFsdWUgaXMgc3luY2hyb25pemVkIGJhY2sgdG8gdGhlIGN1cnJlbnQgbW9kZWwuXG4gICAgICAgIGhhc1ZNb2RlbCAmJiBwcmV2U2V0VmFsdWUgIT09IEVNUFRZX09CSiAmJiAhaGFzQ2hhbmdlZChlbWl0dGVkVmFsdWUsIGxvY2FsVmFsdWUpKSkge1xuICAgICAgICAgIHRyaWdnZXIoKTtcbiAgICAgICAgfVxuICAgICAgICBwcmV2U2V0VmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgcHJldkVtaXR0ZWRWYWx1ZSA9IGVtaXR0ZWRWYWx1ZTtcbiAgICAgIH1cbiAgICB9O1xuICB9KTtcbiAgcmVzW1N5bWJvbC5pdGVyYXRvcl0gPSAoKSA9PiB7XG4gICAgbGV0IGkyID0gMDtcbiAgICByZXR1cm4ge1xuICAgICAgbmV4dCgpIHtcbiAgICAgICAgaWYgKGkyIDwgMikge1xuICAgICAgICAgIHJldHVybiB7IHZhbHVlOiBpMisrID8gbW9kaWZpZXJzIHx8IEVNUFRZX09CSiA6IHJlcywgZG9uZTogZmFsc2UgfTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXR1cm4geyBkb25lOiB0cnVlIH07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9O1xuICB9O1xuICByZXR1cm4gcmVzO1xufVxuY29uc3QgZ2V0TW9kZWxNb2RpZmllcnMgPSAocHJvcHMsIG1vZGVsTmFtZSkgPT4ge1xuICByZXR1cm4gbW9kZWxOYW1lID09PSBcIm1vZGVsVmFsdWVcIiB8fCBtb2RlbE5hbWUgPT09IFwibW9kZWwtdmFsdWVcIiA/IHByb3BzLm1vZGVsTW9kaWZpZXJzIDogcHJvcHNbYCR7bW9kZWxOYW1lfU1vZGlmaWVyc2BdIHx8IHByb3BzW2Ake2NhbWVsaXplKG1vZGVsTmFtZSl9TW9kaWZpZXJzYF0gfHwgcHJvcHNbYCR7aHlwaGVuYXRlKG1vZGVsTmFtZSl9TW9kaWZpZXJzYF07XG59O1xuXG5mdW5jdGlvbiBlbWl0KGluc3RhbmNlLCBldmVudCwgLi4ucmF3QXJncykge1xuICBpZiAoaW5zdGFuY2UuaXNVbm1vdW50ZWQpIHJldHVybjtcbiAgY29uc3QgcHJvcHMgPSBpbnN0YW5jZS52bm9kZS5wcm9wcyB8fCBFTVBUWV9PQko7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgY29uc3Qge1xuICAgICAgZW1pdHNPcHRpb25zLFxuICAgICAgcHJvcHNPcHRpb25zOiBbcHJvcHNPcHRpb25zXVxuICAgIH0gPSBpbnN0YW5jZTtcbiAgICBpZiAoZW1pdHNPcHRpb25zKSB7XG4gICAgICBpZiAoIShldmVudCBpbiBlbWl0c09wdGlvbnMpICYmIHRydWUpIHtcbiAgICAgICAgaWYgKCFwcm9wc09wdGlvbnMgfHwgISh0b0hhbmRsZXJLZXkoY2FtZWxpemUoZXZlbnQpKSBpbiBwcm9wc09wdGlvbnMpKSB7XG4gICAgICAgICAgd2FybiQxKFxuICAgICAgICAgICAgYENvbXBvbmVudCBlbWl0dGVkIGV2ZW50IFwiJHtldmVudH1cIiBidXQgaXQgaXMgbmVpdGhlciBkZWNsYXJlZCBpbiB0aGUgZW1pdHMgb3B0aW9uIG5vciBhcyBhbiBcIiR7dG9IYW5kbGVyS2V5KGNhbWVsaXplKGV2ZW50KSl9XCIgcHJvcC5gXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgdmFsaWRhdG9yID0gZW1pdHNPcHRpb25zW2V2ZW50XTtcbiAgICAgICAgaWYgKGlzRnVuY3Rpb24odmFsaWRhdG9yKSkge1xuICAgICAgICAgIGNvbnN0IGlzVmFsaWQgPSB2YWxpZGF0b3IoLi4ucmF3QXJncyk7XG4gICAgICAgICAgaWYgKCFpc1ZhbGlkKSB7XG4gICAgICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgICAgIGBJbnZhbGlkIGV2ZW50IGFyZ3VtZW50czogZXZlbnQgdmFsaWRhdGlvbiBmYWlsZWQgZm9yIGV2ZW50IFwiJHtldmVudH1cIi5gXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuICBsZXQgYXJncyA9IHJhd0FyZ3M7XG4gIGNvbnN0IGlzTW9kZWxMaXN0ZW5lciA9IGV2ZW50LnN0YXJ0c1dpdGgoXCJ1cGRhdGU6XCIpO1xuICBjb25zdCBtb2RpZmllcnMgPSBpc01vZGVsTGlzdGVuZXIgJiYgZ2V0TW9kZWxNb2RpZmllcnMocHJvcHMsIGV2ZW50LnNsaWNlKDcpKTtcbiAgaWYgKG1vZGlmaWVycykge1xuICAgIGlmIChtb2RpZmllcnMudHJpbSkge1xuICAgICAgYXJncyA9IHJhd0FyZ3MubWFwKChhKSA9PiBpc1N0cmluZyhhKSA/IGEudHJpbSgpIDogYSk7XG4gICAgfVxuICAgIGlmIChtb2RpZmllcnMubnVtYmVyKSB7XG4gICAgICBhcmdzID0gcmF3QXJncy5tYXAobG9vc2VUb051bWJlcik7XG4gICAgfVxuICB9XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykge1xuICAgIGRldnRvb2xzQ29tcG9uZW50RW1pdChpbnN0YW5jZSwgZXZlbnQsIGFyZ3MpO1xuICB9XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgY29uc3QgbG93ZXJDYXNlRXZlbnQgPSBldmVudC50b0xvd2VyQ2FzZSgpO1xuICAgIGlmIChsb3dlckNhc2VFdmVudCAhPT0gZXZlbnQgJiYgcHJvcHNbdG9IYW5kbGVyS2V5KGxvd2VyQ2FzZUV2ZW50KV0pIHtcbiAgICAgIHdhcm4kMShcbiAgICAgICAgYEV2ZW50IFwiJHtsb3dlckNhc2VFdmVudH1cIiBpcyBlbWl0dGVkIGluIGNvbXBvbmVudCAke2Zvcm1hdENvbXBvbmVudE5hbWUoXG4gICAgICAgICAgaW5zdGFuY2UsXG4gICAgICAgICAgaW5zdGFuY2UudHlwZVxuICAgICAgICApfSBidXQgdGhlIGhhbmRsZXIgaXMgcmVnaXN0ZXJlZCBmb3IgXCIke2V2ZW50fVwiLiBOb3RlIHRoYXQgSFRNTCBhdHRyaWJ1dGVzIGFyZSBjYXNlLWluc2Vuc2l0aXZlIGFuZCB5b3UgY2Fubm90IHVzZSB2LW9uIHRvIGxpc3RlbiB0byBjYW1lbENhc2UgZXZlbnRzIHdoZW4gdXNpbmcgaW4tRE9NIHRlbXBsYXRlcy4gWW91IHNob3VsZCBwcm9iYWJseSB1c2UgXCIke2h5cGhlbmF0ZShcbiAgICAgICAgICBldmVudFxuICAgICAgICApfVwiIGluc3RlYWQgb2YgXCIke2V2ZW50fVwiLmBcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIGxldCBoYW5kbGVyTmFtZTtcbiAgbGV0IGhhbmRsZXIgPSBwcm9wc1toYW5kbGVyTmFtZSA9IHRvSGFuZGxlcktleShldmVudCldIHx8IC8vIGFsc28gdHJ5IGNhbWVsQ2FzZSBldmVudCBoYW5kbGVyICgjMjI0OSlcbiAgcHJvcHNbaGFuZGxlck5hbWUgPSB0b0hhbmRsZXJLZXkoY2FtZWxpemUoZXZlbnQpKV07XG4gIGlmICghaGFuZGxlciAmJiBpc01vZGVsTGlzdGVuZXIpIHtcbiAgICBoYW5kbGVyID0gcHJvcHNbaGFuZGxlck5hbWUgPSB0b0hhbmRsZXJLZXkoaHlwaGVuYXRlKGV2ZW50KSldO1xuICB9XG4gIGlmIChoYW5kbGVyKSB7XG4gICAgY2FsbFdpdGhBc3luY0Vycm9ySGFuZGxpbmcoXG4gICAgICBoYW5kbGVyLFxuICAgICAgaW5zdGFuY2UsXG4gICAgICA2LFxuICAgICAgYXJnc1xuICAgICk7XG4gIH1cbiAgY29uc3Qgb25jZUhhbmRsZXIgPSBwcm9wc1toYW5kbGVyTmFtZSArIGBPbmNlYF07XG4gIGlmIChvbmNlSGFuZGxlcikge1xuICAgIGlmICghaW5zdGFuY2UuZW1pdHRlZCkge1xuICAgICAgaW5zdGFuY2UuZW1pdHRlZCA9IHt9O1xuICAgIH0gZWxzZSBpZiAoaW5zdGFuY2UuZW1pdHRlZFtoYW5kbGVyTmFtZV0pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaW5zdGFuY2UuZW1pdHRlZFtoYW5kbGVyTmFtZV0gPSB0cnVlO1xuICAgIGNhbGxXaXRoQXN5bmNFcnJvckhhbmRsaW5nKFxuICAgICAgb25jZUhhbmRsZXIsXG4gICAgICBpbnN0YW5jZSxcbiAgICAgIDYsXG4gICAgICBhcmdzXG4gICAgKTtcbiAgfVxufVxuY29uc3QgbWl4aW5FbWl0c0NhY2hlID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5mdW5jdGlvbiBub3JtYWxpemVFbWl0c09wdGlvbnMoY29tcCwgYXBwQ29udGV4dCwgYXNNaXhpbiA9IGZhbHNlKSB7XG4gIGNvbnN0IGNhY2hlID0gX19WVUVfT1BUSU9OU19BUElfXyAmJiBhc01peGluID8gbWl4aW5FbWl0c0NhY2hlIDogYXBwQ29udGV4dC5lbWl0c0NhY2hlO1xuICBjb25zdCBjYWNoZWQgPSBjYWNoZS5nZXQoY29tcCk7XG4gIGlmIChjYWNoZWQgIT09IHZvaWQgMCkge1xuICAgIHJldHVybiBjYWNoZWQ7XG4gIH1cbiAgY29uc3QgcmF3ID0gY29tcC5lbWl0cztcbiAgbGV0IG5vcm1hbGl6ZWQgPSB7fTtcbiAgbGV0IGhhc0V4dGVuZHMgPSBmYWxzZTtcbiAgaWYgKF9fVlVFX09QVElPTlNfQVBJX18gJiYgIWlzRnVuY3Rpb24oY29tcCkpIHtcbiAgICBjb25zdCBleHRlbmRFbWl0cyA9IChyYXcyKSA9PiB7XG4gICAgICBjb25zdCBub3JtYWxpemVkRnJvbUV4dGVuZCA9IG5vcm1hbGl6ZUVtaXRzT3B0aW9ucyhyYXcyLCBhcHBDb250ZXh0LCB0cnVlKTtcbiAgICAgIGlmIChub3JtYWxpemVkRnJvbUV4dGVuZCkge1xuICAgICAgICBoYXNFeHRlbmRzID0gdHJ1ZTtcbiAgICAgICAgZXh0ZW5kKG5vcm1hbGl6ZWQsIG5vcm1hbGl6ZWRGcm9tRXh0ZW5kKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIGlmICghYXNNaXhpbiAmJiBhcHBDb250ZXh0Lm1peGlucy5sZW5ndGgpIHtcbiAgICAgIGFwcENvbnRleHQubWl4aW5zLmZvckVhY2goZXh0ZW5kRW1pdHMpO1xuICAgIH1cbiAgICBpZiAoY29tcC5leHRlbmRzKSB7XG4gICAgICBleHRlbmRFbWl0cyhjb21wLmV4dGVuZHMpO1xuICAgIH1cbiAgICBpZiAoY29tcC5taXhpbnMpIHtcbiAgICAgIGNvbXAubWl4aW5zLmZvckVhY2goZXh0ZW5kRW1pdHMpO1xuICAgIH1cbiAgfVxuICBpZiAoIXJhdyAmJiAhaGFzRXh0ZW5kcykge1xuICAgIGlmIChpc09iamVjdChjb21wKSkge1xuICAgICAgY2FjaGUuc2V0KGNvbXAsIG51bGwpO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBpZiAoaXNBcnJheShyYXcpKSB7XG4gICAgcmF3LmZvckVhY2goKGtleSkgPT4gbm9ybWFsaXplZFtrZXldID0gbnVsbCk7XG4gIH0gZWxzZSB7XG4gICAgZXh0ZW5kKG5vcm1hbGl6ZWQsIHJhdyk7XG4gIH1cbiAgaWYgKGlzT2JqZWN0KGNvbXApKSB7XG4gICAgY2FjaGUuc2V0KGNvbXAsIG5vcm1hbGl6ZWQpO1xuICB9XG4gIHJldHVybiBub3JtYWxpemVkO1xufVxuZnVuY3Rpb24gaXNFbWl0TGlzdGVuZXIob3B0aW9ucywga2V5KSB7XG4gIGlmICghb3B0aW9ucyB8fCAhaXNPbihrZXkpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGtleSA9IGtleS5zbGljZSgyKTtcbiAga2V5ID0ga2V5ID09PSBcIk9uY2VcIiA/IGtleSA6IGtleS5yZXBsYWNlKC9PbmNlJC8sIFwiXCIpO1xuICByZXR1cm4gaGFzT3duKG9wdGlvbnMsIGtleVswXS50b0xvd2VyQ2FzZSgpICsga2V5LnNsaWNlKDEpKSB8fCBoYXNPd24ob3B0aW9ucywgaHlwaGVuYXRlKGtleSkpIHx8IGhhc093bihvcHRpb25zLCBrZXkpO1xufVxuXG5sZXQgYWNjZXNzZWRBdHRycyA9IGZhbHNlO1xuZnVuY3Rpb24gbWFya0F0dHJzQWNjZXNzZWQoKSB7XG4gIGFjY2Vzc2VkQXR0cnMgPSB0cnVlO1xufVxuZnVuY3Rpb24gcmVuZGVyQ29tcG9uZW50Um9vdChpbnN0YW5jZSkge1xuICBjb25zdCB7XG4gICAgdHlwZTogQ29tcG9uZW50LFxuICAgIHZub2RlLFxuICAgIHByb3h5LFxuICAgIHdpdGhQcm94eSxcbiAgICBwcm9wc09wdGlvbnM6IFtwcm9wc09wdGlvbnNdLFxuICAgIHNsb3RzLFxuICAgIGF0dHJzLFxuICAgIGVtaXQsXG4gICAgcmVuZGVyLFxuICAgIHJlbmRlckNhY2hlLFxuICAgIHByb3BzLFxuICAgIGRhdGEsXG4gICAgc2V0dXBTdGF0ZSxcbiAgICBjdHgsXG4gICAgaW5oZXJpdEF0dHJzXG4gIH0gPSBpbnN0YW5jZTtcbiAgY29uc3QgcHJldiA9IHNldEN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZShpbnN0YW5jZSk7XG4gIGxldCByZXN1bHQ7XG4gIGxldCBmYWxsdGhyb3VnaEF0dHJzO1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIGFjY2Vzc2VkQXR0cnMgPSBmYWxzZTtcbiAgfVxuICB0cnkge1xuICAgIGlmICh2bm9kZS5zaGFwZUZsYWcgJiA0KSB7XG4gICAgICBjb25zdCBwcm94eVRvVXNlID0gd2l0aFByb3h5IHx8IHByb3h5O1xuICAgICAgY29uc3QgdGhpc1Byb3h5ID0gISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBzZXR1cFN0YXRlLl9faXNTY3JpcHRTZXR1cCA/IG5ldyBQcm94eShwcm94eVRvVXNlLCB7XG4gICAgICAgIGdldCh0YXJnZXQsIGtleSwgcmVjZWl2ZXIpIHtcbiAgICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgICBgUHJvcGVydHkgJyR7U3RyaW5nKFxuICAgICAgICAgICAgICBrZXlcbiAgICAgICAgICAgICl9JyB3YXMgYWNjZXNzZWQgdmlhICd0aGlzJy4gQXZvaWQgdXNpbmcgJ3RoaXMnIGluIHRlbXBsYXRlcy5gXG4gICAgICAgICAgKTtcbiAgICAgICAgICByZXR1cm4gUmVmbGVjdC5nZXQodGFyZ2V0LCBrZXksIHJlY2VpdmVyKTtcbiAgICAgICAgfVxuICAgICAgfSkgOiBwcm94eVRvVXNlO1xuICAgICAgcmVzdWx0ID0gbm9ybWFsaXplVk5vZGUoXG4gICAgICAgIHJlbmRlci5jYWxsKFxuICAgICAgICAgIHRoaXNQcm94eSxcbiAgICAgICAgICBwcm94eVRvVXNlLFxuICAgICAgICAgIHJlbmRlckNhY2hlLFxuICAgICAgICAgICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyBzaGFsbG93UmVhZG9ubHkocHJvcHMpIDogcHJvcHMsXG4gICAgICAgICAgc2V0dXBTdGF0ZSxcbiAgICAgICAgICBkYXRhLFxuICAgICAgICAgIGN0eFxuICAgICAgICApXG4gICAgICApO1xuICAgICAgZmFsbHRocm91Z2hBdHRycyA9IGF0dHJzO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCByZW5kZXIyID0gQ29tcG9uZW50O1xuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgYXR0cnMgPT09IHByb3BzKSB7XG4gICAgICAgIG1hcmtBdHRyc0FjY2Vzc2VkKCk7XG4gICAgICB9XG4gICAgICByZXN1bHQgPSBub3JtYWxpemVWTm9kZShcbiAgICAgICAgcmVuZGVyMi5sZW5ndGggPiAxID8gcmVuZGVyMihcbiAgICAgICAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gc2hhbGxvd1JlYWRvbmx5KHByb3BzKSA6IHByb3BzLFxuICAgICAgICAgICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyB7XG4gICAgICAgICAgICBnZXQgYXR0cnMoKSB7XG4gICAgICAgICAgICAgIG1hcmtBdHRyc0FjY2Vzc2VkKCk7XG4gICAgICAgICAgICAgIHJldHVybiBzaGFsbG93UmVhZG9ubHkoYXR0cnMpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNsb3RzLFxuICAgICAgICAgICAgZW1pdFxuICAgICAgICAgIH0gOiB7IGF0dHJzLCBzbG90cywgZW1pdCB9XG4gICAgICAgICkgOiByZW5kZXIyKFxuICAgICAgICAgICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyBzaGFsbG93UmVhZG9ubHkocHJvcHMpIDogcHJvcHMsXG4gICAgICAgICAgbnVsbFxuICAgICAgICApXG4gICAgICApO1xuICAgICAgZmFsbHRocm91Z2hBdHRycyA9IENvbXBvbmVudC5wcm9wcyA/IGF0dHJzIDogZ2V0RnVuY3Rpb25hbEZhbGx0aHJvdWdoKGF0dHJzKTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIGJsb2NrU3RhY2subGVuZ3RoID0gMDtcbiAgICBoYW5kbGVFcnJvcihlcnIsIGluc3RhbmNlLCAxKTtcbiAgICByZXN1bHQgPSBjcmVhdGVWTm9kZShDb21tZW50KTtcbiAgfVxuICBsZXQgcm9vdCA9IHJlc3VsdDtcbiAgbGV0IHNldFJvb3QgPSB2b2lkIDA7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHJlc3VsdC5wYXRjaEZsYWcgPiAwICYmIHJlc3VsdC5wYXRjaEZsYWcgJiAyMDQ4KSB7XG4gICAgW3Jvb3QsIHNldFJvb3RdID0gZ2V0Q2hpbGRSb290KHJlc3VsdCk7XG4gIH1cbiAgaWYgKGZhbGx0aHJvdWdoQXR0cnMgJiYgaW5oZXJpdEF0dHJzICE9PSBmYWxzZSkge1xuICAgIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhmYWxsdGhyb3VnaEF0dHJzKTtcbiAgICBjb25zdCB7IHNoYXBlRmxhZyB9ID0gcm9vdDtcbiAgICBpZiAoa2V5cy5sZW5ndGgpIHtcbiAgICAgIGlmIChzaGFwZUZsYWcgJiAoMSB8IDYpKSB7XG4gICAgICAgIGlmIChwcm9wc09wdGlvbnMgJiYga2V5cy5zb21lKGlzTW9kZWxMaXN0ZW5lcikpIHtcbiAgICAgICAgICBmYWxsdGhyb3VnaEF0dHJzID0gZmlsdGVyTW9kZWxMaXN0ZW5lcnMoXG4gICAgICAgICAgICBmYWxsdGhyb3VnaEF0dHJzLFxuICAgICAgICAgICAgcHJvcHNPcHRpb25zXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICByb290ID0gY2xvbmVWTm9kZShyb290LCBmYWxsdGhyb3VnaEF0dHJzLCBmYWxzZSwgdHJ1ZSk7XG4gICAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWFjY2Vzc2VkQXR0cnMgJiYgcm9vdC50eXBlICE9PSBDb21tZW50KSB7XG4gICAgICAgIGNvbnN0IGFsbEF0dHJzID0gT2JqZWN0LmtleXMoYXR0cnMpO1xuICAgICAgICBjb25zdCBldmVudEF0dHJzID0gW107XG4gICAgICAgIGNvbnN0IGV4dHJhQXR0cnMgPSBbXTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIGwgPSBhbGxBdHRycy5sZW5ndGg7IGkgPCBsOyBpKyspIHtcbiAgICAgICAgICBjb25zdCBrZXkgPSBhbGxBdHRyc1tpXTtcbiAgICAgICAgICBpZiAoaXNPbihrZXkpKSB7XG4gICAgICAgICAgICBpZiAoIWlzTW9kZWxMaXN0ZW5lcihrZXkpKSB7XG4gICAgICAgICAgICAgIGV2ZW50QXR0cnMucHVzaChrZXlbMl0udG9Mb3dlckNhc2UoKSArIGtleS5zbGljZSgzKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGV4dHJhQXR0cnMucHVzaChrZXkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoZXh0cmFBdHRycy5sZW5ndGgpIHtcbiAgICAgICAgICB3YXJuJDEoXG4gICAgICAgICAgICBgRXh0cmFuZW91cyBub24tcHJvcHMgYXR0cmlidXRlcyAoJHtleHRyYUF0dHJzLmpvaW4oXCIsIFwiKX0pIHdlcmUgcGFzc2VkIHRvIGNvbXBvbmVudCBidXQgY291bGQgbm90IGJlIGF1dG9tYXRpY2FsbHkgaW5oZXJpdGVkIGJlY2F1c2UgY29tcG9uZW50IHJlbmRlcnMgZnJhZ21lbnQgb3IgdGV4dCBvciB0ZWxlcG9ydCByb290IG5vZGVzLmBcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChldmVudEF0dHJzLmxlbmd0aCkge1xuICAgICAgICAgIHdhcm4kMShcbiAgICAgICAgICAgIGBFeHRyYW5lb3VzIG5vbi1lbWl0cyBldmVudCBsaXN0ZW5lcnMgKCR7ZXZlbnRBdHRycy5qb2luKFwiLCBcIil9KSB3ZXJlIHBhc3NlZCB0byBjb21wb25lbnQgYnV0IGNvdWxkIG5vdCBiZSBhdXRvbWF0aWNhbGx5IGluaGVyaXRlZCBiZWNhdXNlIGNvbXBvbmVudCByZW5kZXJzIGZyYWdtZW50IG9yIHRleHQgcm9vdCBub2Rlcy4gSWYgdGhlIGxpc3RlbmVyIGlzIGludGVuZGVkIHRvIGJlIGEgY29tcG9uZW50IGN1c3RvbSBldmVudCBsaXN0ZW5lciBvbmx5LCBkZWNsYXJlIGl0IHVzaW5nIHRoZSBcImVtaXRzXCIgb3B0aW9uLmBcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGlmICh2bm9kZS5kaXJzKSB7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWlzRWxlbWVudFJvb3Qocm9vdCkpIHtcbiAgICAgIHdhcm4kMShcbiAgICAgICAgYFJ1bnRpbWUgZGlyZWN0aXZlIHVzZWQgb24gY29tcG9uZW50IHdpdGggbm9uLWVsZW1lbnQgcm9vdCBub2RlLiBUaGUgZGlyZWN0aXZlcyB3aWxsIG5vdCBmdW5jdGlvbiBhcyBpbnRlbmRlZC5gXG4gICAgICApO1xuICAgIH1cbiAgICByb290ID0gY2xvbmVWTm9kZShyb290LCBudWxsLCBmYWxzZSwgdHJ1ZSk7XG4gICAgcm9vdC5kaXJzID0gcm9vdC5kaXJzID8gcm9vdC5kaXJzLmNvbmNhdCh2bm9kZS5kaXJzKSA6IHZub2RlLmRpcnM7XG4gIH1cbiAgaWYgKHZub2RlLnRyYW5zaXRpb24pIHtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiAhaXNFbGVtZW50Um9vdChyb290KSkge1xuICAgICAgd2FybiQxKFxuICAgICAgICBgQ29tcG9uZW50IGluc2lkZSA8VHJhbnNpdGlvbj4gcmVuZGVycyBub24tZWxlbWVudCByb290IG5vZGUgdGhhdCBjYW5ub3QgYmUgYW5pbWF0ZWQuYFxuICAgICAgKTtcbiAgICB9XG4gICAgc2V0VHJhbnNpdGlvbkhvb2tzKHJvb3QsIHZub2RlLnRyYW5zaXRpb24pO1xuICB9XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHNldFJvb3QpIHtcbiAgICBzZXRSb290KHJvb3QpO1xuICB9IGVsc2Uge1xuICAgIHJlc3VsdCA9IHJvb3Q7XG4gIH1cbiAgc2V0Q3VycmVudFJlbmRlcmluZ0luc3RhbmNlKHByZXYpO1xuICByZXR1cm4gcmVzdWx0O1xufVxuY29uc3QgZ2V0Q2hpbGRSb290ID0gKHZub2RlKSA9PiB7XG4gIGNvbnN0IHJhd0NoaWxkcmVuID0gdm5vZGUuY2hpbGRyZW47XG4gIGNvbnN0IGR5bmFtaWNDaGlsZHJlbiA9IHZub2RlLmR5bmFtaWNDaGlsZHJlbjtcbiAgY29uc3QgY2hpbGRSb290ID0gZmlsdGVyU2luZ2xlUm9vdChyYXdDaGlsZHJlbiwgZmFsc2UpO1xuICBpZiAoIWNoaWxkUm9vdCkge1xuICAgIHJldHVybiBbdm5vZGUsIHZvaWQgMF07XG4gIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBjaGlsZFJvb3QucGF0Y2hGbGFnID4gMCAmJiBjaGlsZFJvb3QucGF0Y2hGbGFnICYgMjA0OCkge1xuICAgIHJldHVybiBnZXRDaGlsZFJvb3QoY2hpbGRSb290KTtcbiAgfVxuICBjb25zdCBpbmRleCA9IHJhd0NoaWxkcmVuLmluZGV4T2YoY2hpbGRSb290KTtcbiAgY29uc3QgZHluYW1pY0luZGV4ID0gZHluYW1pY0NoaWxkcmVuID8gZHluYW1pY0NoaWxkcmVuLmluZGV4T2YoY2hpbGRSb290KSA6IC0xO1xuICBjb25zdCBzZXRSb290ID0gKHVwZGF0ZWRSb290KSA9PiB7XG4gICAgcmF3Q2hpbGRyZW5baW5kZXhdID0gdXBkYXRlZFJvb3Q7XG4gICAgaWYgKGR5bmFtaWNDaGlsZHJlbikge1xuICAgICAgaWYgKGR5bmFtaWNJbmRleCA+IC0xKSB7XG4gICAgICAgIGR5bmFtaWNDaGlsZHJlbltkeW5hbWljSW5kZXhdID0gdXBkYXRlZFJvb3Q7XG4gICAgICB9IGVsc2UgaWYgKHVwZGF0ZWRSb290LnBhdGNoRmxhZyA+IDApIHtcbiAgICAgICAgdm5vZGUuZHluYW1pY0NoaWxkcmVuID0gWy4uLmR5bmFtaWNDaGlsZHJlbiwgdXBkYXRlZFJvb3RdO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbiAgcmV0dXJuIFtub3JtYWxpemVWTm9kZShjaGlsZFJvb3QpLCBzZXRSb290XTtcbn07XG5mdW5jdGlvbiBmaWx0ZXJTaW5nbGVSb290KGNoaWxkcmVuLCByZWN1cnNlID0gdHJ1ZSkge1xuICBsZXQgc2luZ2xlUm9vdDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGNoaWxkID0gY2hpbGRyZW5baV07XG4gICAgaWYgKGlzVk5vZGUoY2hpbGQpKSB7XG4gICAgICBpZiAoY2hpbGQudHlwZSAhPT0gQ29tbWVudCB8fCBjaGlsZC5jaGlsZHJlbiA9PT0gXCJ2LWlmXCIpIHtcbiAgICAgICAgaWYgKHNpbmdsZVJvb3QpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc2luZ2xlUm9vdCA9IGNoaWxkO1xuICAgICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHJlY3Vyc2UgJiYgc2luZ2xlUm9vdC5wYXRjaEZsYWcgPiAwICYmIHNpbmdsZVJvb3QucGF0Y2hGbGFnICYgMjA0OCkge1xuICAgICAgICAgICAgcmV0dXJuIGZpbHRlclNpbmdsZVJvb3Qoc2luZ2xlUm9vdC5jaGlsZHJlbik7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHNpbmdsZVJvb3Q7XG59XG5jb25zdCBnZXRGdW5jdGlvbmFsRmFsbHRocm91Z2ggPSAoYXR0cnMpID0+IHtcbiAgbGV0IHJlcztcbiAgZm9yIChjb25zdCBrZXkgaW4gYXR0cnMpIHtcbiAgICBpZiAoa2V5ID09PSBcImNsYXNzXCIgfHwga2V5ID09PSBcInN0eWxlXCIgfHwgaXNPbihrZXkpKSB7XG4gICAgICAocmVzIHx8IChyZXMgPSB7fSkpW2tleV0gPSBhdHRyc1trZXldO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcmVzO1xufTtcbmNvbnN0IGZpbHRlck1vZGVsTGlzdGVuZXJzID0gKGF0dHJzLCBwcm9wcykgPT4ge1xuICBjb25zdCByZXMgPSB7fTtcbiAgZm9yIChjb25zdCBrZXkgaW4gYXR0cnMpIHtcbiAgICBpZiAoIWlzTW9kZWxMaXN0ZW5lcihrZXkpIHx8ICEoa2V5LnNsaWNlKDkpIGluIHByb3BzKSkge1xuICAgICAgcmVzW2tleV0gPSBhdHRyc1trZXldO1xuICAgIH1cbiAgfVxuICByZXR1cm4gcmVzO1xufTtcbmNvbnN0IGlzRWxlbWVudFJvb3QgPSAodm5vZGUpID0+IHtcbiAgcmV0dXJuIHZub2RlLnNoYXBlRmxhZyAmICg2IHwgMSkgfHwgdm5vZGUudHlwZSA9PT0gQ29tbWVudDtcbn07XG5mdW5jdGlvbiBzaG91bGRVcGRhdGVDb21wb25lbnQocHJldlZOb2RlLCBuZXh0Vk5vZGUsIG9wdGltaXplZCkge1xuICBjb25zdCB7IHByb3BzOiBwcmV2UHJvcHMsIGNoaWxkcmVuOiBwcmV2Q2hpbGRyZW4sIGNvbXBvbmVudCB9ID0gcHJldlZOb2RlO1xuICBjb25zdCB7IHByb3BzOiBuZXh0UHJvcHMsIGNoaWxkcmVuOiBuZXh0Q2hpbGRyZW4sIHBhdGNoRmxhZyB9ID0gbmV4dFZOb2RlO1xuICBjb25zdCBlbWl0cyA9IGNvbXBvbmVudC5lbWl0c09wdGlvbnM7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIChwcmV2Q2hpbGRyZW4gfHwgbmV4dENoaWxkcmVuKSAmJiBpc0htclVwZGF0aW5nKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgaWYgKG5leHRWTm9kZS5kaXJzIHx8IG5leHRWTm9kZS50cmFuc2l0aW9uKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgaWYgKG9wdGltaXplZCAmJiBwYXRjaEZsYWcgPj0gMCkge1xuICAgIGlmIChwYXRjaEZsYWcgJiAxMDI0KSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKHBhdGNoRmxhZyAmIDE2KSB7XG4gICAgICBpZiAoIXByZXZQcm9wcykge1xuICAgICAgICByZXR1cm4gISFuZXh0UHJvcHM7XG4gICAgICB9XG4gICAgICByZXR1cm4gaGFzUHJvcHNDaGFuZ2VkKHByZXZQcm9wcywgbmV4dFByb3BzLCBlbWl0cyk7XG4gICAgfSBlbHNlIGlmIChwYXRjaEZsYWcgJiA4KSB7XG4gICAgICBjb25zdCBkeW5hbWljUHJvcHMgPSBuZXh0Vk5vZGUuZHluYW1pY1Byb3BzO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkeW5hbWljUHJvcHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3Qga2V5ID0gZHluYW1pY1Byb3BzW2ldO1xuICAgICAgICBpZiAoaGFzUHJvcFZhbHVlQ2hhbmdlZChuZXh0UHJvcHMsIHByZXZQcm9wcywga2V5KSAmJiAhaXNFbWl0TGlzdGVuZXIoZW1pdHMsIGtleSkpIHtcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBpZiAocHJldkNoaWxkcmVuIHx8IG5leHRDaGlsZHJlbikge1xuICAgICAgaWYgKCFuZXh0Q2hpbGRyZW4gfHwgIW5leHRDaGlsZHJlbi4kc3RhYmxlKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAocHJldlByb3BzID09PSBuZXh0UHJvcHMpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKCFwcmV2UHJvcHMpIHtcbiAgICAgIHJldHVybiAhIW5leHRQcm9wcztcbiAgICB9XG4gICAgaWYgKCFuZXh0UHJvcHMpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gaGFzUHJvcHNDaGFuZ2VkKHByZXZQcm9wcywgbmV4dFByb3BzLCBlbWl0cyk7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuZnVuY3Rpb24gaGFzUHJvcHNDaGFuZ2VkKHByZXZQcm9wcywgbmV4dFByb3BzLCBlbWl0c09wdGlvbnMpIHtcbiAgY29uc3QgbmV4dEtleXMgPSBPYmplY3Qua2V5cyhuZXh0UHJvcHMpO1xuICBpZiAobmV4dEtleXMubGVuZ3RoICE9PSBPYmplY3Qua2V5cyhwcmV2UHJvcHMpLmxlbmd0aCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbmV4dEtleXMubGVuZ3RoOyBpKyspIHtcbiAgICBjb25zdCBrZXkgPSBuZXh0S2V5c1tpXTtcbiAgICBpZiAoaGFzUHJvcFZhbHVlQ2hhbmdlZChuZXh0UHJvcHMsIHByZXZQcm9wcywga2V5KSAmJiAhaXNFbWl0TGlzdGVuZXIoZW1pdHNPcHRpb25zLCBrZXkpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuZnVuY3Rpb24gaGFzUHJvcFZhbHVlQ2hhbmdlZChuZXh0UHJvcHMsIHByZXZQcm9wcywga2V5KSB7XG4gIGNvbnN0IG5leHRQcm9wID0gbmV4dFByb3BzW2tleV07XG4gIGNvbnN0IHByZXZQcm9wID0gcHJldlByb3BzW2tleV07XG4gIGlmIChrZXkgPT09IFwic3R5bGVcIiAmJiBpc09iamVjdChuZXh0UHJvcCkgJiYgaXNPYmplY3QocHJldlByb3ApKSB7XG4gICAgcmV0dXJuICFsb29zZUVxdWFsKG5leHRQcm9wLCBwcmV2UHJvcCk7XG4gIH1cbiAgcmV0dXJuIG5leHRQcm9wICE9PSBwcmV2UHJvcDtcbn1cbmZ1bmN0aW9uIHVwZGF0ZUhPQ0hvc3RFbCh7IHZub2RlLCBwYXJlbnQsIHN1c3BlbnNlIH0sIGVsKSB7XG4gIHdoaWxlIChwYXJlbnQpIHtcbiAgICBjb25zdCByb290ID0gcGFyZW50LnN1YlRyZWU7XG4gICAgaWYgKHJvb3Quc3VzcGVuc2UgJiYgcm9vdC5zdXNwZW5zZS5hY3RpdmVCcmFuY2ggPT09IHZub2RlKSB7XG4gICAgICByb290LnN1c3BlbnNlLnZub2RlLmVsID0gcm9vdC5lbCA9IGVsO1xuICAgICAgdm5vZGUgPSByb290O1xuICAgIH1cbiAgICBpZiAocm9vdCA9PT0gdm5vZGUpIHtcbiAgICAgICh2bm9kZSA9IHBhcmVudC52bm9kZSkuZWwgPSBlbDtcbiAgICAgIHBhcmVudCA9IHBhcmVudC5wYXJlbnQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuICBpZiAoc3VzcGVuc2UgJiYgc3VzcGVuc2UuYWN0aXZlQnJhbmNoID09PSB2bm9kZSkge1xuICAgIHN1c3BlbnNlLnZub2RlLmVsID0gZWw7XG4gIH1cbn1cblxuY29uc3QgaW50ZXJuYWxPYmplY3RQcm90byA9IHt9O1xuY29uc3QgY3JlYXRlSW50ZXJuYWxPYmplY3QgPSAoKSA9PiBPYmplY3QuY3JlYXRlKGludGVybmFsT2JqZWN0UHJvdG8pO1xuY29uc3QgaXNJbnRlcm5hbE9iamVjdCA9IChvYmopID0+IE9iamVjdC5nZXRQcm90b3R5cGVPZihvYmopID09PSBpbnRlcm5hbE9iamVjdFByb3RvO1xuXG5mdW5jdGlvbiBpbml0UHJvcHMoaW5zdGFuY2UsIHJhd1Byb3BzLCBpc1N0YXRlZnVsLCBpc1NTUiA9IGZhbHNlKSB7XG4gIGNvbnN0IHByb3BzID0ge307XG4gIGNvbnN0IGF0dHJzID0gY3JlYXRlSW50ZXJuYWxPYmplY3QoKTtcbiAgaW5zdGFuY2UucHJvcHNEZWZhdWx0cyA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBzZXRGdWxsUHJvcHMoaW5zdGFuY2UsIHJhd1Byb3BzLCBwcm9wcywgYXR0cnMpO1xuICBmb3IgKGNvbnN0IGtleSBpbiBpbnN0YW5jZS5wcm9wc09wdGlvbnNbMF0pIHtcbiAgICBpZiAoIShrZXkgaW4gcHJvcHMpKSB7XG4gICAgICBwcm9wc1trZXldID0gdm9pZCAwO1xuICAgIH1cbiAgfVxuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIHZhbGlkYXRlUHJvcHMocmF3UHJvcHMgfHwge30sIHByb3BzLCBpbnN0YW5jZSk7XG4gIH1cbiAgaWYgKGlzU3RhdGVmdWwpIHtcbiAgICBpbnN0YW5jZS5wcm9wcyA9IGlzU1NSID8gcHJvcHMgOiBzaGFsbG93UmVhY3RpdmUocHJvcHMpO1xuICB9IGVsc2Uge1xuICAgIGlmICghaW5zdGFuY2UudHlwZS5wcm9wcykge1xuICAgICAgaW5zdGFuY2UucHJvcHMgPSBhdHRycztcbiAgICB9IGVsc2Uge1xuICAgICAgaW5zdGFuY2UucHJvcHMgPSBwcm9wcztcbiAgICB9XG4gIH1cbiAgaW5zdGFuY2UuYXR0cnMgPSBhdHRycztcbn1cbmZ1bmN0aW9uIGlzSW5IbXJDb250ZXh0KGluc3RhbmNlKSB7XG4gIHdoaWxlIChpbnN0YW5jZSkge1xuICAgIGlmIChpbnN0YW5jZS50eXBlLl9faG1ySWQpIHJldHVybiB0cnVlO1xuICAgIGluc3RhbmNlID0gaW5zdGFuY2UucGFyZW50O1xuICB9XG59XG5mdW5jdGlvbiB1cGRhdGVQcm9wcyhpbnN0YW5jZSwgcmF3UHJvcHMsIHJhd1ByZXZQcm9wcywgb3B0aW1pemVkKSB7XG4gIGNvbnN0IHtcbiAgICBwcm9wcyxcbiAgICBhdHRycyxcbiAgICB2bm9kZTogeyBwYXRjaEZsYWcgfVxuICB9ID0gaW5zdGFuY2U7XG4gIGNvbnN0IHJhd0N1cnJlbnRQcm9wcyA9IHRvUmF3KHByb3BzKTtcbiAgY29uc3QgW29wdGlvbnNdID0gaW5zdGFuY2UucHJvcHNPcHRpb25zO1xuICBsZXQgaGFzQXR0cnNDaGFuZ2VkID0gZmFsc2U7XG4gIGlmIChcbiAgICAvLyBhbHdheXMgZm9yY2UgZnVsbCBkaWZmIGluIGRldlxuICAgIC8vIC0gIzE5NDIgaWYgaG1yIGlzIGVuYWJsZWQgd2l0aCBzZmMgY29tcG9uZW50XG4gICAgLy8gLSB2aXRlIzg3MiBub24tc2ZjIGNvbXBvbmVudCB1c2VkIGJ5IHNmYyBjb21wb25lbnRcbiAgICAhKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgaXNJbkhtckNvbnRleHQoaW5zdGFuY2UpKSAmJiAob3B0aW1pemVkIHx8IHBhdGNoRmxhZyA+IDApICYmICEocGF0Y2hGbGFnICYgMTYpXG4gICkge1xuICAgIGlmIChwYXRjaEZsYWcgJiA4KSB7XG4gICAgICBjb25zdCBwcm9wc1RvVXBkYXRlID0gaW5zdGFuY2Uudm5vZGUuZHluYW1pY1Byb3BzO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwcm9wc1RvVXBkYXRlLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGxldCBrZXkgPSBwcm9wc1RvVXBkYXRlW2ldO1xuICAgICAgICBpZiAoaXNFbWl0TGlzdGVuZXIoaW5zdGFuY2UuZW1pdHNPcHRpb25zLCBrZXkpKSB7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdmFsdWUgPSByYXdQcm9wc1trZXldO1xuICAgICAgICBpZiAob3B0aW9ucykge1xuICAgICAgICAgIGlmIChoYXNPd24oYXR0cnMsIGtleSkpIHtcbiAgICAgICAgICAgIGlmICh2YWx1ZSAhPT0gYXR0cnNba2V5XSkge1xuICAgICAgICAgICAgICBhdHRyc1trZXldID0gdmFsdWU7XG4gICAgICAgICAgICAgIGhhc0F0dHJzQ2hhbmdlZCA9IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGNhbWVsaXplZEtleSA9IGNhbWVsaXplKGtleSk7XG4gICAgICAgICAgICBwcm9wc1tjYW1lbGl6ZWRLZXldID0gcmVzb2x2ZVByb3BWYWx1ZShcbiAgICAgICAgICAgICAgb3B0aW9ucyxcbiAgICAgICAgICAgICAgcmF3Q3VycmVudFByb3BzLFxuICAgICAgICAgICAgICBjYW1lbGl6ZWRLZXksXG4gICAgICAgICAgICAgIHZhbHVlLFxuICAgICAgICAgICAgICBpbnN0YW5jZSxcbiAgICAgICAgICAgICAgZmFsc2VcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGlmICh2YWx1ZSAhPT0gYXR0cnNba2V5XSkge1xuICAgICAgICAgICAgYXR0cnNba2V5XSA9IHZhbHVlO1xuICAgICAgICAgICAgaGFzQXR0cnNDaGFuZ2VkID0gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgaWYgKHNldEZ1bGxQcm9wcyhpbnN0YW5jZSwgcmF3UHJvcHMsIHByb3BzLCBhdHRycykpIHtcbiAgICAgIGhhc0F0dHJzQ2hhbmdlZCA9IHRydWU7XG4gICAgfVxuICAgIGxldCBrZWJhYktleTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiByYXdDdXJyZW50UHJvcHMpIHtcbiAgICAgIGlmICghcmF3UHJvcHMgfHwgLy8gZm9yIGNhbWVsQ2FzZVxuICAgICAgIWhhc093bihyYXdQcm9wcywga2V5KSAmJiAvLyBpdCdzIHBvc3NpYmxlIHRoZSBvcmlnaW5hbCBwcm9wcyB3YXMgcGFzc2VkIGluIGFzIGtlYmFiLWNhc2VcbiAgICAgIC8vIGFuZCBjb252ZXJ0ZWQgdG8gY2FtZWxDYXNlICgjOTU1KVxuICAgICAgKChrZWJhYktleSA9IGh5cGhlbmF0ZShrZXkpKSA9PT0ga2V5IHx8ICFoYXNPd24ocmF3UHJvcHMsIGtlYmFiS2V5KSkpIHtcbiAgICAgICAgaWYgKG9wdGlvbnMpIHtcbiAgICAgICAgICBpZiAocmF3UHJldlByb3BzICYmIC8vIGZvciBjYW1lbENhc2VcbiAgICAgICAgICAocmF3UHJldlByb3BzW2tleV0gIT09IHZvaWQgMCB8fCAvLyBmb3Iga2ViYWItY2FzZVxuICAgICAgICAgIHJhd1ByZXZQcm9wc1trZWJhYktleV0gIT09IHZvaWQgMCkpIHtcbiAgICAgICAgICAgIHByb3BzW2tleV0gPSByZXNvbHZlUHJvcFZhbHVlKFxuICAgICAgICAgICAgICBvcHRpb25zLFxuICAgICAgICAgICAgICByYXdDdXJyZW50UHJvcHMsXG4gICAgICAgICAgICAgIGtleSxcbiAgICAgICAgICAgICAgdm9pZCAwLFxuICAgICAgICAgICAgICBpbnN0YW5jZSxcbiAgICAgICAgICAgICAgdHJ1ZVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZGVsZXRlIHByb3BzW2tleV07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGF0dHJzICE9PSByYXdDdXJyZW50UHJvcHMpIHtcbiAgICAgIGZvciAoY29uc3Qga2V5IGluIGF0dHJzKSB7XG4gICAgICAgIGlmICghcmF3UHJvcHMgfHwgIWhhc093bihyYXdQcm9wcywga2V5KSAmJiB0cnVlKSB7XG4gICAgICAgICAgZGVsZXRlIGF0dHJzW2tleV07XG4gICAgICAgICAgaGFzQXR0cnNDaGFuZ2VkID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuICBpZiAoaGFzQXR0cnNDaGFuZ2VkKSB7XG4gICAgdHJpZ2dlcihpbnN0YW5jZS5hdHRycywgXCJzZXRcIiwgXCJcIik7XG4gIH1cbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICB2YWxpZGF0ZVByb3BzKHJhd1Byb3BzIHx8IHt9LCBwcm9wcywgaW5zdGFuY2UpO1xuICB9XG59XG5mdW5jdGlvbiBzZXRGdWxsUHJvcHMoaW5zdGFuY2UsIHJhd1Byb3BzLCBwcm9wcywgYXR0cnMpIHtcbiAgY29uc3QgW29wdGlvbnMsIG5lZWRDYXN0S2V5c10gPSBpbnN0YW5jZS5wcm9wc09wdGlvbnM7XG4gIGxldCBoYXNBdHRyc0NoYW5nZWQgPSBmYWxzZTtcbiAgbGV0IHJhd0Nhc3RWYWx1ZXM7XG4gIGlmIChyYXdQcm9wcykge1xuICAgIGZvciAobGV0IGtleSBpbiByYXdQcm9wcykge1xuICAgICAgaWYgKGlzUmVzZXJ2ZWRQcm9wKGtleSkpIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBjb25zdCB2YWx1ZSA9IHJhd1Byb3BzW2tleV07XG4gICAgICBsZXQgY2FtZWxLZXk7XG4gICAgICBpZiAob3B0aW9ucyAmJiBoYXNPd24ob3B0aW9ucywgY2FtZWxLZXkgPSBjYW1lbGl6ZShrZXkpKSkge1xuICAgICAgICBpZiAoIW5lZWRDYXN0S2V5cyB8fCAhbmVlZENhc3RLZXlzLmluY2x1ZGVzKGNhbWVsS2V5KSkge1xuICAgICAgICAgIHByb3BzW2NhbWVsS2V5XSA9IHZhbHVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIChyYXdDYXN0VmFsdWVzIHx8IChyYXdDYXN0VmFsdWVzID0ge30pKVtjYW1lbEtleV0gPSB2YWx1ZTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIGlmICghaXNFbWl0TGlzdGVuZXIoaW5zdGFuY2UuZW1pdHNPcHRpb25zLCBrZXkpKSB7XG4gICAgICAgIGlmICghKGtleSBpbiBhdHRycykgfHwgdmFsdWUgIT09IGF0dHJzW2tleV0pIHtcbiAgICAgICAgICBhdHRyc1trZXldID0gdmFsdWU7XG4gICAgICAgICAgaGFzQXR0cnNDaGFuZ2VkID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuICBpZiAobmVlZENhc3RLZXlzKSB7XG4gICAgY29uc3QgcmF3Q3VycmVudFByb3BzID0gdG9SYXcocHJvcHMpO1xuICAgIGNvbnN0IGNhc3RWYWx1ZXMgPSByYXdDYXN0VmFsdWVzIHx8IEVNUFRZX09CSjtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IG5lZWRDYXN0S2V5cy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3Qga2V5ID0gbmVlZENhc3RLZXlzW2ldO1xuICAgICAgcHJvcHNba2V5XSA9IHJlc29sdmVQcm9wVmFsdWUoXG4gICAgICAgIG9wdGlvbnMsXG4gICAgICAgIHJhd0N1cnJlbnRQcm9wcyxcbiAgICAgICAga2V5LFxuICAgICAgICBjYXN0VmFsdWVzW2tleV0sXG4gICAgICAgIGluc3RhbmNlLFxuICAgICAgICAhaGFzT3duKGNhc3RWYWx1ZXMsIGtleSlcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIHJldHVybiBoYXNBdHRyc0NoYW5nZWQ7XG59XG5mdW5jdGlvbiByZXNvbHZlUHJvcFZhbHVlKG9wdGlvbnMsIHByb3BzLCBrZXksIHZhbHVlLCBpbnN0YW5jZSwgaXNBYnNlbnQpIHtcbiAgY29uc3Qgb3B0ID0gb3B0aW9uc1trZXldO1xuICBpZiAob3B0ICE9IG51bGwpIHtcbiAgICBjb25zdCBoYXNEZWZhdWx0ID0gaGFzT3duKG9wdCwgXCJkZWZhdWx0XCIpO1xuICAgIGlmIChoYXNEZWZhdWx0ICYmIHZhbHVlID09PSB2b2lkIDApIHtcbiAgICAgIGNvbnN0IGRlZmF1bHRWYWx1ZSA9IG9wdC5kZWZhdWx0O1xuICAgICAgaWYgKG9wdC50eXBlICE9PSBGdW5jdGlvbiAmJiAhb3B0LnNraXBGYWN0b3J5ICYmIGlzRnVuY3Rpb24oZGVmYXVsdFZhbHVlKSkge1xuICAgICAgICBjb25zdCB7IHByb3BzRGVmYXVsdHMgfSA9IGluc3RhbmNlO1xuICAgICAgICBpZiAoa2V5IGluIHByb3BzRGVmYXVsdHMpIHtcbiAgICAgICAgICB2YWx1ZSA9IHByb3BzRGVmYXVsdHNba2V5XTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBjb25zdCByZXNldCA9IHNldEN1cnJlbnRJbnN0YW5jZShpbnN0YW5jZSk7XG4gICAgICAgICAgdmFsdWUgPSBwcm9wc0RlZmF1bHRzW2tleV0gPSBkZWZhdWx0VmFsdWUuY2FsbChcbiAgICAgICAgICAgIG51bGwsXG4gICAgICAgICAgICBwcm9wc1xuICAgICAgICAgICk7XG4gICAgICAgICAgcmVzZXQoKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdmFsdWUgPSBkZWZhdWx0VmFsdWU7XG4gICAgICB9XG4gICAgICBpZiAoaW5zdGFuY2UuY2UpIHtcbiAgICAgICAgaW5zdGFuY2UuY2UuX3NldFByb3Aoa2V5LCB2YWx1ZSk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChvcHRbMCAvKiBzaG91bGRDYXN0ICovXSkge1xuICAgICAgaWYgKGlzQWJzZW50ICYmICFoYXNEZWZhdWx0KSB7XG4gICAgICAgIHZhbHVlID0gZmFsc2U7XG4gICAgICB9IGVsc2UgaWYgKG9wdFsxIC8qIHNob3VsZENhc3RUcnVlICovXSAmJiAodmFsdWUgPT09IFwiXCIgfHwgdmFsdWUgPT09IGh5cGhlbmF0ZShrZXkpKSkge1xuICAgICAgICB2YWx1ZSA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiB2YWx1ZTtcbn1cbmNvbnN0IG1peGluUHJvcHNDYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuZnVuY3Rpb24gbm9ybWFsaXplUHJvcHNPcHRpb25zKGNvbXAsIGFwcENvbnRleHQsIGFzTWl4aW4gPSBmYWxzZSkge1xuICBjb25zdCBjYWNoZSA9IF9fVlVFX09QVElPTlNfQVBJX18gJiYgYXNNaXhpbiA/IG1peGluUHJvcHNDYWNoZSA6IGFwcENvbnRleHQucHJvcHNDYWNoZTtcbiAgY29uc3QgY2FjaGVkID0gY2FjaGUuZ2V0KGNvbXApO1xuICBpZiAoY2FjaGVkKSB7XG4gICAgcmV0dXJuIGNhY2hlZDtcbiAgfVxuICBjb25zdCByYXcgPSBjb21wLnByb3BzO1xuICBjb25zdCBub3JtYWxpemVkID0ge307XG4gIGNvbnN0IG5lZWRDYXN0S2V5cyA9IFtdO1xuICBsZXQgaGFzRXh0ZW5kcyA9IGZhbHNlO1xuICBpZiAoX19WVUVfT1BUSU9OU19BUElfXyAmJiAhaXNGdW5jdGlvbihjb21wKSkge1xuICAgIGNvbnN0IGV4dGVuZFByb3BzID0gKHJhdzIpID0+IHtcbiAgICAgIGhhc0V4dGVuZHMgPSB0cnVlO1xuICAgICAgY29uc3QgW3Byb3BzLCBrZXlzXSA9IG5vcm1hbGl6ZVByb3BzT3B0aW9ucyhyYXcyLCBhcHBDb250ZXh0LCB0cnVlKTtcbiAgICAgIGV4dGVuZChub3JtYWxpemVkLCBwcm9wcyk7XG4gICAgICBpZiAoa2V5cykgbmVlZENhc3RLZXlzLnB1c2goLi4ua2V5cyk7XG4gICAgfTtcbiAgICBpZiAoIWFzTWl4aW4gJiYgYXBwQ29udGV4dC5taXhpbnMubGVuZ3RoKSB7XG4gICAgICBhcHBDb250ZXh0Lm1peGlucy5mb3JFYWNoKGV4dGVuZFByb3BzKTtcbiAgICB9XG4gICAgaWYgKGNvbXAuZXh0ZW5kcykge1xuICAgICAgZXh0ZW5kUHJvcHMoY29tcC5leHRlbmRzKTtcbiAgICB9XG4gICAgaWYgKGNvbXAubWl4aW5zKSB7XG4gICAgICBjb21wLm1peGlucy5mb3JFYWNoKGV4dGVuZFByb3BzKTtcbiAgICB9XG4gIH1cbiAgaWYgKCFyYXcgJiYgIWhhc0V4dGVuZHMpIHtcbiAgICBpZiAoaXNPYmplY3QoY29tcCkpIHtcbiAgICAgIGNhY2hlLnNldChjb21wLCBFTVBUWV9BUlIpO1xuICAgIH1cbiAgICByZXR1cm4gRU1QVFlfQVJSO1xuICB9XG4gIGlmIChpc0FycmF5KHJhdykpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJhdy5sZW5ndGg7IGkrKykge1xuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWlzU3RyaW5nKHJhd1tpXSkpIHtcbiAgICAgICAgd2FybiQxKGBwcm9wcyBtdXN0IGJlIHN0cmluZ3Mgd2hlbiB1c2luZyBhcnJheSBzeW50YXguYCwgcmF3W2ldKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG5vcm1hbGl6ZWRLZXkgPSBjYW1lbGl6ZShyYXdbaV0pO1xuICAgICAgaWYgKHZhbGlkYXRlUHJvcE5hbWUobm9ybWFsaXplZEtleSkpIHtcbiAgICAgICAgbm9ybWFsaXplZFtub3JtYWxpemVkS2V5XSA9IEVNUFRZX09CSjtcbiAgICAgIH1cbiAgICB9XG4gIH0gZWxzZSBpZiAocmF3KSB7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWlzT2JqZWN0KHJhdykpIHtcbiAgICAgIHdhcm4kMShgaW52YWxpZCBwcm9wcyBvcHRpb25zYCwgcmF3KTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBrZXkgaW4gcmF3KSB7XG4gICAgICBjb25zdCBub3JtYWxpemVkS2V5ID0gY2FtZWxpemUoa2V5KTtcbiAgICAgIGlmICh2YWxpZGF0ZVByb3BOYW1lKG5vcm1hbGl6ZWRLZXkpKSB7XG4gICAgICAgIGNvbnN0IG9wdCA9IHJhd1trZXldO1xuICAgICAgICBjb25zdCBwcm9wID0gbm9ybWFsaXplZFtub3JtYWxpemVkS2V5XSA9IGlzQXJyYXkob3B0KSB8fCBpc0Z1bmN0aW9uKG9wdCkgPyB7IHR5cGU6IG9wdCB9IDogZXh0ZW5kKHt9LCBvcHQpO1xuICAgICAgICBjb25zdCBwcm9wVHlwZSA9IHByb3AudHlwZTtcbiAgICAgICAgbGV0IHNob3VsZENhc3QgPSBmYWxzZTtcbiAgICAgICAgbGV0IHNob3VsZENhc3RUcnVlID0gdHJ1ZTtcbiAgICAgICAgaWYgKGlzQXJyYXkocHJvcFR5cGUpKSB7XG4gICAgICAgICAgZm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IHByb3BUeXBlLmxlbmd0aDsgKytpbmRleCkge1xuICAgICAgICAgICAgY29uc3QgdHlwZSA9IHByb3BUeXBlW2luZGV4XTtcbiAgICAgICAgICAgIGNvbnN0IHR5cGVOYW1lID0gaXNGdW5jdGlvbih0eXBlKSAmJiB0eXBlLm5hbWU7XG4gICAgICAgICAgICBpZiAodHlwZU5hbWUgPT09IFwiQm9vbGVhblwiKSB7XG4gICAgICAgICAgICAgIHNob3VsZENhc3QgPSB0cnVlO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZU5hbWUgPT09IFwiU3RyaW5nXCIpIHtcbiAgICAgICAgICAgICAgc2hvdWxkQ2FzdFRydWUgPSBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc2hvdWxkQ2FzdCA9IGlzRnVuY3Rpb24ocHJvcFR5cGUpICYmIHByb3BUeXBlLm5hbWUgPT09IFwiQm9vbGVhblwiO1xuICAgICAgICB9XG4gICAgICAgIHByb3BbMCAvKiBzaG91bGRDYXN0ICovXSA9IHNob3VsZENhc3Q7XG4gICAgICAgIHByb3BbMSAvKiBzaG91bGRDYXN0VHJ1ZSAqL10gPSBzaG91bGRDYXN0VHJ1ZTtcbiAgICAgICAgaWYgKHNob3VsZENhc3QgfHwgaGFzT3duKHByb3AsIFwiZGVmYXVsdFwiKSkge1xuICAgICAgICAgIG5lZWRDYXN0S2V5cy5wdXNoKG5vcm1hbGl6ZWRLZXkpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG4gIGNvbnN0IHJlcyA9IFtub3JtYWxpemVkLCBuZWVkQ2FzdEtleXNdO1xuICBpZiAoaXNPYmplY3QoY29tcCkpIHtcbiAgICBjYWNoZS5zZXQoY29tcCwgcmVzKTtcbiAgfVxuICByZXR1cm4gcmVzO1xufVxuZnVuY3Rpb24gdmFsaWRhdGVQcm9wTmFtZShrZXkpIHtcbiAgaWYgKGtleVswXSAhPT0gXCIkXCIgJiYgIWlzUmVzZXJ2ZWRQcm9wKGtleSkpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgd2FybiQxKGBJbnZhbGlkIHByb3AgbmFtZTogXCIke2tleX1cIiBpcyBhIHJlc2VydmVkIHByb3BlcnR5LmApO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIGdldFR5cGUoY3Rvcikge1xuICBpZiAoY3RvciA9PT0gbnVsbCkge1xuICAgIHJldHVybiBcIm51bGxcIjtcbiAgfVxuICBpZiAodHlwZW9mIGN0b3IgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIHJldHVybiBjdG9yLm5hbWUgfHwgXCJcIjtcbiAgfSBlbHNlIGlmICh0eXBlb2YgY3RvciA9PT0gXCJvYmplY3RcIikge1xuICAgIGNvbnN0IG5hbWUgPSBjdG9yLmNvbnN0cnVjdG9yICYmIGN0b3IuY29uc3RydWN0b3IubmFtZTtcbiAgICByZXR1cm4gbmFtZSB8fCBcIlwiO1xuICB9XG4gIHJldHVybiBcIlwiO1xufVxuZnVuY3Rpb24gdmFsaWRhdGVQcm9wcyhyYXdQcm9wcywgcHJvcHMsIGluc3RhbmNlKSB7XG4gIGNvbnN0IHJlc29sdmVkVmFsdWVzID0gdG9SYXcocHJvcHMpO1xuICBjb25zdCBvcHRpb25zID0gaW5zdGFuY2UucHJvcHNPcHRpb25zWzBdO1xuICBjb25zdCBjYW1lbGl6ZVByb3BzS2V5ID0gT2JqZWN0LmtleXMocmF3UHJvcHMpLm1hcCgoa2V5KSA9PiBjYW1lbGl6ZShrZXkpKTtcbiAgZm9yIChjb25zdCBrZXkgaW4gb3B0aW9ucykge1xuICAgIGxldCBvcHQgPSBvcHRpb25zW2tleV07XG4gICAgaWYgKG9wdCA9PSBudWxsKSBjb250aW51ZTtcbiAgICB2YWxpZGF0ZVByb3AoXG4gICAgICBrZXksXG4gICAgICByZXNvbHZlZFZhbHVlc1trZXldLFxuICAgICAgb3B0LFxuICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IHNoYWxsb3dSZWFkb25seShyZXNvbHZlZFZhbHVlcykgOiByZXNvbHZlZFZhbHVlcyxcbiAgICAgICFjYW1lbGl6ZVByb3BzS2V5LmluY2x1ZGVzKGtleSlcbiAgICApO1xuICB9XG59XG5mdW5jdGlvbiB2YWxpZGF0ZVByb3AobmFtZSwgdmFsdWUsIHByb3AsIHByb3BzLCBpc0Fic2VudCkge1xuICBjb25zdCB7IHR5cGUsIHJlcXVpcmVkLCB2YWxpZGF0b3IsIHNraXBDaGVjayB9ID0gcHJvcDtcbiAgaWYgKHJlcXVpcmVkICYmIGlzQWJzZW50KSB7XG4gICAgd2FybiQxKCdNaXNzaW5nIHJlcXVpcmVkIHByb3A6IFwiJyArIG5hbWUgKyAnXCInKTtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKHZhbHVlID09IG51bGwgJiYgIXJlcXVpcmVkKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGlmICh0eXBlICE9IG51bGwgJiYgdHlwZSAhPT0gdHJ1ZSAmJiAhc2tpcENoZWNrKSB7XG4gICAgbGV0IGlzVmFsaWQgPSBmYWxzZTtcbiAgICBjb25zdCB0eXBlcyA9IGlzQXJyYXkodHlwZSkgPyB0eXBlIDogW3R5cGVdO1xuICAgIGNvbnN0IGV4cGVjdGVkVHlwZXMgPSBbXTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHR5cGVzLmxlbmd0aCAmJiAhaXNWYWxpZDsgaSsrKSB7XG4gICAgICBjb25zdCB7IHZhbGlkLCBleHBlY3RlZFR5cGUgfSA9IGFzc2VydFR5cGUodmFsdWUsIHR5cGVzW2ldKTtcbiAgICAgIGV4cGVjdGVkVHlwZXMucHVzaChleHBlY3RlZFR5cGUgfHwgXCJcIik7XG4gICAgICBpc1ZhbGlkID0gdmFsaWQ7XG4gICAgfVxuICAgIGlmICghaXNWYWxpZCkge1xuICAgICAgd2FybiQxKGdldEludmFsaWRUeXBlTWVzc2FnZShuYW1lLCB2YWx1ZSwgZXhwZWN0ZWRUeXBlcykpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgfVxuICBpZiAodmFsaWRhdG9yICYmICF2YWxpZGF0b3IodmFsdWUsIHByb3BzKSkge1xuICAgIHdhcm4kMSgnSW52YWxpZCBwcm9wOiBjdXN0b20gdmFsaWRhdG9yIGNoZWNrIGZhaWxlZCBmb3IgcHJvcCBcIicgKyBuYW1lICsgJ1wiLicpO1xuICB9XG59XG5jb25zdCBpc1NpbXBsZVR5cGUgPSAvKiBAX19QVVJFX18gKi8gbWFrZU1hcChcbiAgXCJTdHJpbmcsTnVtYmVyLEJvb2xlYW4sRnVuY3Rpb24sU3ltYm9sLEJpZ0ludFwiXG4pO1xuZnVuY3Rpb24gYXNzZXJ0VHlwZSh2YWx1ZSwgdHlwZSkge1xuICBsZXQgdmFsaWQ7XG4gIGNvbnN0IGV4cGVjdGVkVHlwZSA9IGdldFR5cGUodHlwZSk7XG4gIGlmIChleHBlY3RlZFR5cGUgPT09IFwibnVsbFwiKSB7XG4gICAgdmFsaWQgPSB2YWx1ZSA9PT0gbnVsbDtcbiAgfSBlbHNlIGlmIChpc1NpbXBsZVR5cGUoZXhwZWN0ZWRUeXBlKSkge1xuICAgIGNvbnN0IHQgPSB0eXBlb2YgdmFsdWU7XG4gICAgdmFsaWQgPSB0ID09PSBleHBlY3RlZFR5cGUudG9Mb3dlckNhc2UoKTtcbiAgICBpZiAoIXZhbGlkICYmIHQgPT09IFwib2JqZWN0XCIpIHtcbiAgICAgIHZhbGlkID0gdmFsdWUgaW5zdGFuY2VvZiB0eXBlO1xuICAgIH1cbiAgfSBlbHNlIGlmIChleHBlY3RlZFR5cGUgPT09IFwiT2JqZWN0XCIpIHtcbiAgICB2YWxpZCA9IGlzT2JqZWN0KHZhbHVlKTtcbiAgfSBlbHNlIGlmIChleHBlY3RlZFR5cGUgPT09IFwiQXJyYXlcIikge1xuICAgIHZhbGlkID0gaXNBcnJheSh2YWx1ZSk7XG4gIH0gZWxzZSB7XG4gICAgdmFsaWQgPSB2YWx1ZSBpbnN0YW5jZW9mIHR5cGU7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB2YWxpZCxcbiAgICBleHBlY3RlZFR5cGVcbiAgfTtcbn1cbmZ1bmN0aW9uIGdldEludmFsaWRUeXBlTWVzc2FnZShuYW1lLCB2YWx1ZSwgZXhwZWN0ZWRUeXBlcykge1xuICBpZiAoZXhwZWN0ZWRUeXBlcy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gYFByb3AgdHlwZSBbXSBmb3IgcHJvcCBcIiR7bmFtZX1cIiB3b24ndCBtYXRjaCBhbnl0aGluZy4gRGlkIHlvdSBtZWFuIHRvIHVzZSB0eXBlIEFycmF5IGluc3RlYWQ/YDtcbiAgfVxuICBsZXQgbWVzc2FnZSA9IGBJbnZhbGlkIHByb3A6IHR5cGUgY2hlY2sgZmFpbGVkIGZvciBwcm9wIFwiJHtuYW1lfVwiLiBFeHBlY3RlZCAke2V4cGVjdGVkVHlwZXMubWFwKGNhcGl0YWxpemUpLmpvaW4oXCIgfCBcIil9YDtcbiAgY29uc3QgZXhwZWN0ZWRUeXBlID0gZXhwZWN0ZWRUeXBlc1swXTtcbiAgY29uc3QgcmVjZWl2ZWRUeXBlID0gdG9SYXdUeXBlKHZhbHVlKTtcbiAgY29uc3QgZXhwZWN0ZWRWYWx1ZSA9IHN0eWxlVmFsdWUodmFsdWUsIGV4cGVjdGVkVHlwZSk7XG4gIGNvbnN0IHJlY2VpdmVkVmFsdWUgPSBzdHlsZVZhbHVlKHZhbHVlLCByZWNlaXZlZFR5cGUpO1xuICBpZiAoZXhwZWN0ZWRUeXBlcy5sZW5ndGggPT09IDEgJiYgaXNFeHBsaWNhYmxlKGV4cGVjdGVkVHlwZSkgJiYgaXNDb2VyY2libGUoZXhwZWN0ZWRUeXBlLCByZWNlaXZlZFR5cGUpKSB7XG4gICAgbWVzc2FnZSArPSBgIHdpdGggdmFsdWUgJHtleHBlY3RlZFZhbHVlfWA7XG4gIH1cbiAgbWVzc2FnZSArPSBgLCBnb3QgJHtyZWNlaXZlZFR5cGV9IGA7XG4gIGlmIChpc0V4cGxpY2FibGUocmVjZWl2ZWRUeXBlKSkge1xuICAgIG1lc3NhZ2UgKz0gYHdpdGggdmFsdWUgJHtyZWNlaXZlZFZhbHVlfS5gO1xuICB9XG4gIHJldHVybiBtZXNzYWdlO1xufVxuZnVuY3Rpb24gc3R5bGVWYWx1ZSh2YWx1ZSwgdHlwZSkge1xuICBpZiAoaXNTeW1ib2wodmFsdWUpKSB7XG4gICAgcmV0dXJuIHZhbHVlLnRvU3RyaW5nKCk7XG4gIH0gZWxzZSBpZiAodHlwZSA9PT0gXCJTdHJpbmdcIikge1xuICAgIHJldHVybiBgXCIke3ZhbHVlfVwiYDtcbiAgfSBlbHNlIGlmICh0eXBlID09PSBcIk51bWJlclwiKSB7XG4gICAgcmV0dXJuIGAke051bWJlcih2YWx1ZSl9YDtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gYCR7dmFsdWV9YDtcbiAgfVxufVxuZnVuY3Rpb24gaXNFeHBsaWNhYmxlKHR5cGUpIHtcbiAgY29uc3QgZXhwbGljaXRUeXBlcyA9IFtcInN0cmluZ1wiLCBcIm51bWJlclwiLCBcImJvb2xlYW5cIl07XG4gIHJldHVybiBleHBsaWNpdFR5cGVzLnNvbWUoKGVsZW0pID0+IHR5cGUudG9Mb3dlckNhc2UoKSA9PT0gZWxlbSk7XG59XG5mdW5jdGlvbiBpc0NvZXJjaWJsZSguLi5hcmdzKSB7XG4gIHJldHVybiBhcmdzLmV2ZXJ5KChlbGVtKSA9PiB7XG4gICAgY29uc3QgdmFsdWUgPSBlbGVtLnRvTG93ZXJDYXNlKCk7XG4gICAgcmV0dXJuIHZhbHVlICE9PSBcImJvb2xlYW5cIiAmJiB2YWx1ZSAhPT0gXCJzeW1ib2xcIjtcbiAgfSk7XG59XG5cbmNvbnN0IGlzSW50ZXJuYWxLZXkgPSAoa2V5KSA9PiBrZXkgPT09IFwiX1wiIHx8IGtleSA9PT0gXCJfY3R4XCIgfHwga2V5ID09PSBcIiRzdGFibGVcIjtcbmNvbnN0IG5vcm1hbGl6ZVNsb3RWYWx1ZSA9ICh2YWx1ZSkgPT4gaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZS5tYXAobm9ybWFsaXplVk5vZGUpIDogW25vcm1hbGl6ZVZOb2RlKHZhbHVlKV07XG5jb25zdCBub3JtYWxpemVTbG90ID0gKGtleSwgcmF3U2xvdCwgY3R4KSA9PiB7XG4gIGlmIChyYXdTbG90Ll9uKSB7XG4gICAgcmV0dXJuIHJhd1Nsb3Q7XG4gIH1cbiAgY29uc3Qgbm9ybWFsaXplZCA9IHdpdGhDdHgoKC4uLmFyZ3MpID0+IHtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBjdXJyZW50SW5zdGFuY2UgJiYgIShjdHggPT09IG51bGwgJiYgY3VycmVudFJlbmRlcmluZ0luc3RhbmNlKSAmJiAhKGN0eCAmJiBjdHgucm9vdCAhPT0gY3VycmVudEluc3RhbmNlLnJvb3QpKSB7XG4gICAgICB3YXJuJDEoXG4gICAgICAgIGBTbG90IFwiJHtrZXl9XCIgaW52b2tlZCBvdXRzaWRlIG9mIHRoZSByZW5kZXIgZnVuY3Rpb246IHRoaXMgd2lsbCBub3QgdHJhY2sgZGVwZW5kZW5jaWVzIHVzZWQgaW4gdGhlIHNsb3QuIEludm9rZSB0aGUgc2xvdCBmdW5jdGlvbiBpbnNpZGUgdGhlIHJlbmRlciBmdW5jdGlvbiBpbnN0ZWFkLmBcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBub3JtYWxpemVTbG90VmFsdWUocmF3U2xvdCguLi5hcmdzKSk7XG4gIH0sIGN0eCk7XG4gIG5vcm1hbGl6ZWQuX2MgPSBmYWxzZTtcbiAgcmV0dXJuIG5vcm1hbGl6ZWQ7XG59O1xuY29uc3Qgbm9ybWFsaXplT2JqZWN0U2xvdHMgPSAocmF3U2xvdHMsIHNsb3RzLCBpbnN0YW5jZSkgPT4ge1xuICBjb25zdCBjdHggPSByYXdTbG90cy5fY3R4O1xuICBmb3IgKGNvbnN0IGtleSBpbiByYXdTbG90cykge1xuICAgIGlmIChpc0ludGVybmFsS2V5KGtleSkpIGNvbnRpbnVlO1xuICAgIGNvbnN0IHZhbHVlID0gcmF3U2xvdHNba2V5XTtcbiAgICBpZiAoaXNGdW5jdGlvbih2YWx1ZSkpIHtcbiAgICAgIHNsb3RzW2tleV0gPSBub3JtYWxpemVTbG90KGtleSwgdmFsdWUsIGN0eCk7XG4gICAgfSBlbHNlIGlmICh2YWx1ZSAhPSBudWxsKSB7XG4gICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB0cnVlKSB7XG4gICAgICAgIHdhcm4kMShcbiAgICAgICAgICBgTm9uLWZ1bmN0aW9uIHZhbHVlIGVuY291bnRlcmVkIGZvciBzbG90IFwiJHtrZXl9XCIuIFByZWZlciBmdW5jdGlvbiBzbG90cyBmb3IgYmV0dGVyIHBlcmZvcm1hbmNlLmBcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG5vcm1hbGl6ZWQgPSBub3JtYWxpemVTbG90VmFsdWUodmFsdWUpO1xuICAgICAgc2xvdHNba2V5XSA9ICgpID0+IG5vcm1hbGl6ZWQ7XG4gICAgfVxuICB9XG59O1xuY29uc3Qgbm9ybWFsaXplVk5vZGVTbG90cyA9IChpbnN0YW5jZSwgY2hpbGRyZW4pID0+IHtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWlzS2VlcEFsaXZlKGluc3RhbmNlLnZub2RlKSAmJiB0cnVlKSB7XG4gICAgd2FybiQxKFxuICAgICAgYE5vbi1mdW5jdGlvbiB2YWx1ZSBlbmNvdW50ZXJlZCBmb3IgZGVmYXVsdCBzbG90LiBQcmVmZXIgZnVuY3Rpb24gc2xvdHMgZm9yIGJldHRlciBwZXJmb3JtYW5jZS5gXG4gICAgKTtcbiAgfVxuICBjb25zdCBub3JtYWxpemVkID0gbm9ybWFsaXplU2xvdFZhbHVlKGNoaWxkcmVuKTtcbiAgaW5zdGFuY2Uuc2xvdHMuZGVmYXVsdCA9ICgpID0+IG5vcm1hbGl6ZWQ7XG59O1xuY29uc3QgYXNzaWduU2xvdHMgPSAoc2xvdHMsIGNoaWxkcmVuLCBvcHRpbWl6ZWQpID0+IHtcbiAgZm9yIChjb25zdCBrZXkgaW4gY2hpbGRyZW4pIHtcbiAgICBpZiAob3B0aW1pemVkIHx8ICFpc0ludGVybmFsS2V5KGtleSkpIHtcbiAgICAgIHNsb3RzW2tleV0gPSBjaGlsZHJlbltrZXldO1xuICAgIH1cbiAgfVxufTtcbmNvbnN0IGluaXRTbG90cyA9IChpbnN0YW5jZSwgY2hpbGRyZW4sIG9wdGltaXplZCkgPT4ge1xuICBjb25zdCBzbG90cyA9IGluc3RhbmNlLnNsb3RzID0gY3JlYXRlSW50ZXJuYWxPYmplY3QoKTtcbiAgaWYgKGluc3RhbmNlLnZub2RlLnNoYXBlRmxhZyAmIDMyKSB7XG4gICAgY29uc3QgdHlwZSA9IGNoaWxkcmVuLl87XG4gICAgaWYgKHR5cGUpIHtcbiAgICAgIGFzc2lnblNsb3RzKHNsb3RzLCBjaGlsZHJlbiwgb3B0aW1pemVkKTtcbiAgICAgIGlmIChvcHRpbWl6ZWQpIHtcbiAgICAgICAgZGVmKHNsb3RzLCBcIl9cIiwgdHlwZSwgdHJ1ZSk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIG5vcm1hbGl6ZU9iamVjdFNsb3RzKGNoaWxkcmVuLCBzbG90cyk7XG4gICAgfVxuICB9IGVsc2UgaWYgKGNoaWxkcmVuKSB7XG4gICAgbm9ybWFsaXplVk5vZGVTbG90cyhpbnN0YW5jZSwgY2hpbGRyZW4pO1xuICB9XG59O1xuY29uc3QgdXBkYXRlU2xvdHMgPSAoaW5zdGFuY2UsIGNoaWxkcmVuLCBvcHRpbWl6ZWQpID0+IHtcbiAgY29uc3QgeyB2bm9kZSwgc2xvdHMgfSA9IGluc3RhbmNlO1xuICBsZXQgbmVlZERlbGV0aW9uQ2hlY2sgPSB0cnVlO1xuICBsZXQgZGVsZXRpb25Db21wYXJpc29uVGFyZ2V0ID0gRU1QVFlfT0JKO1xuICBpZiAodm5vZGUuc2hhcGVGbGFnICYgMzIpIHtcbiAgICBjb25zdCB0eXBlID0gY2hpbGRyZW4uXztcbiAgICBpZiAodHlwZSkge1xuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgaXNIbXJVcGRhdGluZykge1xuICAgICAgICBhc3NpZ25TbG90cyhzbG90cywgY2hpbGRyZW4sIG9wdGltaXplZCk7XG4gICAgICAgIHRyaWdnZXIoaW5zdGFuY2UsIFwic2V0XCIsIFwiJHNsb3RzXCIpO1xuICAgICAgfSBlbHNlIGlmIChvcHRpbWl6ZWQgJiYgdHlwZSA9PT0gMSkge1xuICAgICAgICBuZWVkRGVsZXRpb25DaGVjayA9IGZhbHNlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXNzaWduU2xvdHMoc2xvdHMsIGNoaWxkcmVuLCBvcHRpbWl6ZWQpO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBuZWVkRGVsZXRpb25DaGVjayA9ICFjaGlsZHJlbi4kc3RhYmxlO1xuICAgICAgbm9ybWFsaXplT2JqZWN0U2xvdHMoY2hpbGRyZW4sIHNsb3RzKTtcbiAgICB9XG4gICAgZGVsZXRpb25Db21wYXJpc29uVGFyZ2V0ID0gY2hpbGRyZW47XG4gIH0gZWxzZSBpZiAoY2hpbGRyZW4pIHtcbiAgICBub3JtYWxpemVWTm9kZVNsb3RzKGluc3RhbmNlLCBjaGlsZHJlbik7XG4gICAgZGVsZXRpb25Db21wYXJpc29uVGFyZ2V0ID0geyBkZWZhdWx0OiAxIH07XG4gIH1cbiAgaWYgKG5lZWREZWxldGlvbkNoZWNrKSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gc2xvdHMpIHtcbiAgICAgIGlmICghaXNJbnRlcm5hbEtleShrZXkpICYmIGRlbGV0aW9uQ29tcGFyaXNvblRhcmdldFtrZXldID09IG51bGwpIHtcbiAgICAgICAgZGVsZXRlIHNsb3RzW2tleV07XG4gICAgICB9XG4gICAgfVxuICB9XG59O1xuXG5sZXQgc3VwcG9ydGVkO1xubGV0IHBlcmY7XG5mdW5jdGlvbiBzdGFydE1lYXN1cmUoaW5zdGFuY2UsIHR5cGUpIHtcbiAgaWYgKGluc3RhbmNlLmFwcENvbnRleHQuY29uZmlnLnBlcmZvcm1hbmNlICYmIGlzU3VwcG9ydGVkKCkpIHtcbiAgICBwZXJmLm1hcmsoYHZ1ZS0ke3R5cGV9LSR7aW5zdGFuY2UudWlkfWApO1xuICB9XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykge1xuICAgIGRldnRvb2xzUGVyZlN0YXJ0KGluc3RhbmNlLCB0eXBlLCBpc1N1cHBvcnRlZCgpID8gcGVyZi5ub3coKSA6IERhdGUubm93KCkpO1xuICB9XG59XG5mdW5jdGlvbiBlbmRNZWFzdXJlKGluc3RhbmNlLCB0eXBlKSB7XG4gIGlmIChpbnN0YW5jZS5hcHBDb250ZXh0LmNvbmZpZy5wZXJmb3JtYW5jZSAmJiBpc1N1cHBvcnRlZCgpKSB7XG4gICAgY29uc3Qgc3RhcnRUYWcgPSBgdnVlLSR7dHlwZX0tJHtpbnN0YW5jZS51aWR9YDtcbiAgICBjb25zdCBlbmRUYWcgPSBzdGFydFRhZyArIGA6ZW5kYDtcbiAgICBjb25zdCBtZWFzdXJlTmFtZSA9IGA8JHtmb3JtYXRDb21wb25lbnROYW1lKGluc3RhbmNlLCBpbnN0YW5jZS50eXBlKX0+ICR7dHlwZX1gO1xuICAgIHBlcmYubWFyayhlbmRUYWcpO1xuICAgIHBlcmYubWVhc3VyZShtZWFzdXJlTmFtZSwgc3RhcnRUYWcsIGVuZFRhZyk7XG4gICAgcGVyZi5jbGVhck1lYXN1cmVzKG1lYXN1cmVOYW1lKTtcbiAgICBwZXJmLmNsZWFyTWFya3Moc3RhcnRUYWcpO1xuICAgIHBlcmYuY2xlYXJNYXJrcyhlbmRUYWcpO1xuICB9XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykge1xuICAgIGRldnRvb2xzUGVyZkVuZChpbnN0YW5jZSwgdHlwZSwgaXNTdXBwb3J0ZWQoKSA/IHBlcmYubm93KCkgOiBEYXRlLm5vdygpKTtcbiAgfVxufVxuZnVuY3Rpb24gaXNTdXBwb3J0ZWQoKSB7XG4gIGlmIChzdXBwb3J0ZWQgIT09IHZvaWQgMCkge1xuICAgIHJldHVybiBzdXBwb3J0ZWQ7XG4gIH1cbiAgaWYgKHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgJiYgd2luZG93LnBlcmZvcm1hbmNlKSB7XG4gICAgc3VwcG9ydGVkID0gdHJ1ZTtcbiAgICBwZXJmID0gd2luZG93LnBlcmZvcm1hbmNlO1xuICB9IGVsc2Uge1xuICAgIHN1cHBvcnRlZCA9IGZhbHNlO1xuICB9XG4gIHJldHVybiBzdXBwb3J0ZWQ7XG59XG5cbmZ1bmN0aW9uIGluaXRGZWF0dXJlRmxhZ3MoKSB7XG4gIGNvbnN0IG5lZWRXYXJuID0gW107XG4gIGlmICh0eXBlb2YgX19WVUVfT1BUSU9OU19BUElfXyAhPT0gXCJib29sZWFuXCIpIHtcbiAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIG5lZWRXYXJuLnB1c2goYF9fVlVFX09QVElPTlNfQVBJX19gKTtcbiAgICBnZXRHbG9iYWxUaGlzKCkuX19WVUVfT1BUSU9OU19BUElfXyA9IHRydWU7XG4gIH1cbiAgaWYgKHR5cGVvZiBfX1ZVRV9QUk9EX0RFVlRPT0xTX18gIT09IFwiYm9vbGVhblwiKSB7XG4gICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBuZWVkV2Fybi5wdXNoKGBfX1ZVRV9QUk9EX0RFVlRPT0xTX19gKTtcbiAgICBnZXRHbG9iYWxUaGlzKCkuX19WVUVfUFJPRF9ERVZUT09MU19fID0gZmFsc2U7XG4gIH1cbiAgaWYgKHR5cGVvZiBfX1ZVRV9QUk9EX0hZRFJBVElPTl9NSVNNQVRDSF9ERVRBSUxTX18gIT09IFwiYm9vbGVhblwiKSB7XG4gICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBuZWVkV2Fybi5wdXNoKGBfX1ZVRV9QUk9EX0hZRFJBVElPTl9NSVNNQVRDSF9ERVRBSUxTX19gKTtcbiAgICBnZXRHbG9iYWxUaGlzKCkuX19WVUVfUFJPRF9IWURSQVRJT05fTUlTTUFUQ0hfREVUQUlMU19fID0gZmFsc2U7XG4gIH1cbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgbmVlZFdhcm4ubGVuZ3RoKSB7XG4gICAgY29uc3QgbXVsdGkgPSBuZWVkV2Fybi5sZW5ndGggPiAxO1xuICAgIGNvbnNvbGUud2FybihcbiAgICAgIGBGZWF0dXJlIGZsYWcke211bHRpID8gYHNgIDogYGB9ICR7bmVlZFdhcm4uam9pbihcIiwgXCIpfSAke211bHRpID8gYGFyZWAgOiBgaXNgfSBub3QgZXhwbGljaXRseSBkZWZpbmVkLiBZb3UgYXJlIHJ1bm5pbmcgdGhlIGVzbS1idW5kbGVyIGJ1aWxkIG9mIFZ1ZSwgd2hpY2ggZXhwZWN0cyB0aGVzZSBjb21waWxlLXRpbWUgZmVhdHVyZSBmbGFncyB0byBiZSBnbG9iYWxseSBpbmplY3RlZCB2aWEgdGhlIGJ1bmRsZXIgY29uZmlnIGluIG9yZGVyIHRvIGdldCBiZXR0ZXIgdHJlZS1zaGFraW5nIGluIHRoZSBwcm9kdWN0aW9uIGJ1bmRsZS5cblxuRm9yIG1vcmUgZGV0YWlscywgc2VlIGh0dHBzOi8vbGluay52dWVqcy5vcmcvZmVhdHVyZS1mbGFncy5gXG4gICAgKTtcbiAgfVxufVxuXG5jb25zdCBxdWV1ZVBvc3RSZW5kZXJFZmZlY3QgPSBxdWV1ZUVmZmVjdFdpdGhTdXNwZW5zZSA7XG5mdW5jdGlvbiBjcmVhdGVSZW5kZXJlcihvcHRpb25zKSB7XG4gIHJldHVybiBiYXNlQ3JlYXRlUmVuZGVyZXIob3B0aW9ucyk7XG59XG5mdW5jdGlvbiBjcmVhdGVIeWRyYXRpb25SZW5kZXJlcihvcHRpb25zKSB7XG4gIHJldHVybiBiYXNlQ3JlYXRlUmVuZGVyZXIob3B0aW9ucywgY3JlYXRlSHlkcmF0aW9uRnVuY3Rpb25zKTtcbn1cbmZ1bmN0aW9uIGJhc2VDcmVhdGVSZW5kZXJlcihvcHRpb25zLCBjcmVhdGVIeWRyYXRpb25GbnMpIHtcbiAge1xuICAgIGluaXRGZWF0dXJlRmxhZ3MoKTtcbiAgfVxuICBjb25zdCB0YXJnZXQgPSBnZXRHbG9iYWxUaGlzKCk7XG4gIHRhcmdldC5fX1ZVRV9fID0gdHJ1ZTtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgX19WVUVfUFJPRF9ERVZUT09MU19fKSB7XG4gICAgc2V0RGV2dG9vbHNIb29rJDEodGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0dMT0JBTF9IT09LX18sIHRhcmdldCk7XG4gIH1cbiAgY29uc3Qge1xuICAgIGluc2VydDogaG9zdEluc2VydCxcbiAgICByZW1vdmU6IGhvc3RSZW1vdmUsXG4gICAgcGF0Y2hQcm9wOiBob3N0UGF0Y2hQcm9wLFxuICAgIGNyZWF0ZUVsZW1lbnQ6IGhvc3RDcmVhdGVFbGVtZW50LFxuICAgIGNyZWF0ZVRleHQ6IGhvc3RDcmVhdGVUZXh0LFxuICAgIGNyZWF0ZUNvbW1lbnQ6IGhvc3RDcmVhdGVDb21tZW50LFxuICAgIHNldFRleHQ6IGhvc3RTZXRUZXh0LFxuICAgIHNldEVsZW1lbnRUZXh0OiBob3N0U2V0RWxlbWVudFRleHQsXG4gICAgcGFyZW50Tm9kZTogaG9zdFBhcmVudE5vZGUsXG4gICAgbmV4dFNpYmxpbmc6IGhvc3ROZXh0U2libGluZyxcbiAgICBzZXRTY29wZUlkOiBob3N0U2V0U2NvcGVJZCA9IE5PT1AsXG4gICAgaW5zZXJ0U3RhdGljQ29udGVudDogaG9zdEluc2VydFN0YXRpY0NvbnRlbnRcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IHBhdGNoID0gKG4xLCBuMiwgY29udGFpbmVyLCBhbmNob3IgPSBudWxsLCBwYXJlbnRDb21wb25lbnQgPSBudWxsLCBwYXJlbnRTdXNwZW5zZSA9IG51bGwsIG5hbWVzcGFjZSA9IHZvaWQgMCwgc2xvdFNjb3BlSWRzID0gbnVsbCwgb3B0aW1pemVkID0gISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBpc0htclVwZGF0aW5nID8gZmFsc2UgOiAhIW4yLmR5bmFtaWNDaGlsZHJlbikgPT4ge1xuICAgIGlmIChuMSA9PT0gbjIpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKG4xICYmICFpc1NhbWVWTm9kZVR5cGUobjEsIG4yKSkge1xuICAgICAgYW5jaG9yID0gZ2V0TmV4dEhvc3ROb2RlKG4xKTtcbiAgICAgIHVubW91bnQobjEsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIHRydWUpO1xuICAgICAgbjEgPSBudWxsO1xuICAgIH1cbiAgICBpZiAobjIucGF0Y2hGbGFnID09PSAtMikge1xuICAgICAgb3B0aW1pemVkID0gZmFsc2U7XG4gICAgICBuMi5keW5hbWljQ2hpbGRyZW4gPSBudWxsO1xuICAgIH1cbiAgICBjb25zdCB7IHR5cGUsIHJlZiwgc2hhcGVGbGFnIH0gPSBuMjtcbiAgICBzd2l0Y2ggKHR5cGUpIHtcbiAgICAgIGNhc2UgVGV4dDpcbiAgICAgICAgcHJvY2Vzc1RleHQobjEsIG4yLCBjb250YWluZXIsIGFuY2hvcik7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBDb21tZW50OlxuICAgICAgICBwcm9jZXNzQ29tbWVudE5vZGUobjEsIG4yLCBjb250YWluZXIsIGFuY2hvcik7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBTdGF0aWM6XG4gICAgICAgIGlmIChuMSA9PSBudWxsKSB7XG4gICAgICAgICAgbW91bnRTdGF0aWNOb2RlKG4yLCBjb250YWluZXIsIGFuY2hvciwgbmFtZXNwYWNlKTtcbiAgICAgICAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgcGF0Y2hTdGF0aWNOb2RlKG4xLCBuMiwgY29udGFpbmVyLCBuYW1lc3BhY2UpO1xuICAgICAgICB9XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSBGcmFnbWVudDpcbiAgICAgICAgcHJvY2Vzc0ZyYWdtZW50KFxuICAgICAgICAgIG4xLFxuICAgICAgICAgIG4yLFxuICAgICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgICBhbmNob3IsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgaWYgKHNoYXBlRmxhZyAmIDEpIHtcbiAgICAgICAgICBwcm9jZXNzRWxlbWVudChcbiAgICAgICAgICAgIG4xLFxuICAgICAgICAgICAgbjIsXG4gICAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgICBhbmNob3IsXG4gICAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICAgICk7XG4gICAgICAgIH0gZWxzZSBpZiAoc2hhcGVGbGFnICYgNikge1xuICAgICAgICAgIHByb2Nlc3NDb21wb25lbnQoXG4gICAgICAgICAgICBuMSxcbiAgICAgICAgICAgIG4yLFxuICAgICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgICAgYW5jaG9yLFxuICAgICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgICApO1xuICAgICAgICB9IGVsc2UgaWYgKHNoYXBlRmxhZyAmIDY0KSB7XG4gICAgICAgICAgdHlwZS5wcm9jZXNzKFxuICAgICAgICAgICAgbjEsXG4gICAgICAgICAgICBuMixcbiAgICAgICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgICAgIGFuY2hvcixcbiAgICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgICAgb3B0aW1pemVkLFxuICAgICAgICAgICAgaW50ZXJuYWxzXG4gICAgICAgICAgKTtcbiAgICAgICAgfSBlbHNlIGlmIChzaGFwZUZsYWcgJiAxMjgpIHtcbiAgICAgICAgICB0eXBlLnByb2Nlc3MoXG4gICAgICAgICAgICBuMSxcbiAgICAgICAgICAgIG4yLFxuICAgICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgICAgYW5jaG9yLFxuICAgICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgICBvcHRpbWl6ZWQsXG4gICAgICAgICAgICBpbnRlcm5hbHNcbiAgICAgICAgICApO1xuICAgICAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICB3YXJuJDEoXCJJbnZhbGlkIFZOb2RlIHR5cGU6XCIsIHR5cGUsIGAoJHt0eXBlb2YgdHlwZX0pYCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKHJlZiAhPSBudWxsICYmIHBhcmVudENvbXBvbmVudCkge1xuICAgICAgc2V0UmVmKHJlZiwgbjEgJiYgbjEucmVmLCBwYXJlbnRTdXNwZW5zZSwgbjIgfHwgbjEsICFuMik7XG4gICAgfSBlbHNlIGlmIChyZWYgPT0gbnVsbCAmJiBuMSAmJiBuMS5yZWYgIT0gbnVsbCkge1xuICAgICAgc2V0UmVmKG4xLnJlZiwgbnVsbCwgcGFyZW50U3VzcGVuc2UsIG4xLCB0cnVlKTtcbiAgICB9XG4gIH07XG4gIGNvbnN0IHByb2Nlc3NUZXh0ID0gKG4xLCBuMiwgY29udGFpbmVyLCBhbmNob3IpID0+IHtcbiAgICBpZiAobjEgPT0gbnVsbCkge1xuICAgICAgaG9zdEluc2VydChcbiAgICAgICAgbjIuZWwgPSBob3N0Q3JlYXRlVGV4dChuMi5jaGlsZHJlbiksXG4gICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgYW5jaG9yXG4gICAgICApO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBlbCA9IG4yLmVsID0gbjEuZWw7XG4gICAgICBpZiAobjIuY2hpbGRyZW4gIT09IG4xLmNoaWxkcmVuKSB7XG4gICAgICAgIGhvc3RTZXRUZXh0KGVsLCBuMi5jaGlsZHJlbik7XG4gICAgICB9XG4gICAgfVxuICB9O1xuICBjb25zdCBwcm9jZXNzQ29tbWVudE5vZGUgPSAobjEsIG4yLCBjb250YWluZXIsIGFuY2hvcikgPT4ge1xuICAgIGlmIChuMSA9PSBudWxsKSB7XG4gICAgICBob3N0SW5zZXJ0KFxuICAgICAgICBuMi5lbCA9IGhvc3RDcmVhdGVDb21tZW50KG4yLmNoaWxkcmVuIHx8IFwiXCIpLFxuICAgICAgICBjb250YWluZXIsXG4gICAgICAgIGFuY2hvclxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgbjIuZWwgPSBuMS5lbDtcbiAgICB9XG4gIH07XG4gIGNvbnN0IG1vdW50U3RhdGljTm9kZSA9IChuMiwgY29udGFpbmVyLCBhbmNob3IsIG5hbWVzcGFjZSkgPT4ge1xuICAgIFtuMi5lbCwgbjIuYW5jaG9yXSA9IGhvc3RJbnNlcnRTdGF0aWNDb250ZW50KFxuICAgICAgbjIuY2hpbGRyZW4sXG4gICAgICBjb250YWluZXIsXG4gICAgICBhbmNob3IsXG4gICAgICBuYW1lc3BhY2UsXG4gICAgICBuMi5lbCxcbiAgICAgIG4yLmFuY2hvclxuICAgICk7XG4gIH07XG4gIGNvbnN0IHBhdGNoU3RhdGljTm9kZSA9IChuMSwgbjIsIGNvbnRhaW5lciwgbmFtZXNwYWNlKSA9PiB7XG4gICAgaWYgKG4yLmNoaWxkcmVuICE9PSBuMS5jaGlsZHJlbikge1xuICAgICAgY29uc3QgYW5jaG9yID0gaG9zdE5leHRTaWJsaW5nKG4xLmFuY2hvcik7XG4gICAgICByZW1vdmVTdGF0aWNOb2RlKG4xKTtcbiAgICAgIFtuMi5lbCwgbjIuYW5jaG9yXSA9IGhvc3RJbnNlcnRTdGF0aWNDb250ZW50KFxuICAgICAgICBuMi5jaGlsZHJlbixcbiAgICAgICAgY29udGFpbmVyLFxuICAgICAgICBhbmNob3IsXG4gICAgICAgIG5hbWVzcGFjZVxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgbjIuZWwgPSBuMS5lbDtcbiAgICAgIG4yLmFuY2hvciA9IG4xLmFuY2hvcjtcbiAgICB9XG4gIH07XG4gIGNvbnN0IG1vdmVTdGF0aWNOb2RlID0gKHsgZWwsIGFuY2hvciB9LCBjb250YWluZXIsIG5leHRTaWJsaW5nKSA9PiB7XG4gICAgbGV0IG5leHQ7XG4gICAgd2hpbGUgKGVsICYmIGVsICE9PSBhbmNob3IpIHtcbiAgICAgIG5leHQgPSBob3N0TmV4dFNpYmxpbmcoZWwpO1xuICAgICAgaG9zdEluc2VydChlbCwgY29udGFpbmVyLCBuZXh0U2libGluZyk7XG4gICAgICBlbCA9IG5leHQ7XG4gICAgfVxuICAgIGhvc3RJbnNlcnQoYW5jaG9yLCBjb250YWluZXIsIG5leHRTaWJsaW5nKTtcbiAgfTtcbiAgY29uc3QgcmVtb3ZlU3RhdGljTm9kZSA9ICh7IGVsLCBhbmNob3IgfSkgPT4ge1xuICAgIGxldCBuZXh0O1xuICAgIHdoaWxlIChlbCAmJiBlbCAhPT0gYW5jaG9yKSB7XG4gICAgICBuZXh0ID0gaG9zdE5leHRTaWJsaW5nKGVsKTtcbiAgICAgIGhvc3RSZW1vdmUoZWwpO1xuICAgICAgZWwgPSBuZXh0O1xuICAgIH1cbiAgICBob3N0UmVtb3ZlKGFuY2hvcik7XG4gIH07XG4gIGNvbnN0IHByb2Nlc3NFbGVtZW50ID0gKG4xLCBuMiwgY29udGFpbmVyLCBhbmNob3IsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIG5hbWVzcGFjZSwgc2xvdFNjb3BlSWRzLCBvcHRpbWl6ZWQpID0+IHtcbiAgICBpZiAobjIudHlwZSA9PT0gXCJzdmdcIikge1xuICAgICAgbmFtZXNwYWNlID0gXCJzdmdcIjtcbiAgICB9IGVsc2UgaWYgKG4yLnR5cGUgPT09IFwibWF0aFwiKSB7XG4gICAgICBuYW1lc3BhY2UgPSBcIm1hdGhtbFwiO1xuICAgIH1cbiAgICBpZiAobjEgPT0gbnVsbCkge1xuICAgICAgbW91bnRFbGVtZW50KFxuICAgICAgICBuMixcbiAgICAgICAgY29udGFpbmVyLFxuICAgICAgICBhbmNob3IsXG4gICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGN1c3RvbUVsZW1lbnQgPSBuMS5lbCAmJiBuMS5lbC5faXNWdWVDRSA/IG4xLmVsIDogbnVsbDtcbiAgICAgIHRyeSB7XG4gICAgICAgIGlmIChjdXN0b21FbGVtZW50KSB7XG4gICAgICAgICAgY3VzdG9tRWxlbWVudC5fYmVnaW5QYXRjaCgpO1xuICAgICAgICB9XG4gICAgICAgIHBhdGNoRWxlbWVudChcbiAgICAgICAgICBuMSxcbiAgICAgICAgICBuMixcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgKTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIGlmIChjdXN0b21FbGVtZW50KSB7XG4gICAgICAgICAgY3VzdG9tRWxlbWVudC5fZW5kUGF0Y2goKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfTtcbiAgY29uc3QgbW91bnRFbGVtZW50ID0gKHZub2RlLCBjb250YWluZXIsIGFuY2hvciwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgbmFtZXNwYWNlLCBzbG90U2NvcGVJZHMsIG9wdGltaXplZCkgPT4ge1xuICAgIGxldCBlbDtcbiAgICBsZXQgdm5vZGVIb29rO1xuICAgIGNvbnN0IHsgcHJvcHMsIHNoYXBlRmxhZywgdHJhbnNpdGlvbiwgZGlycyB9ID0gdm5vZGU7XG4gICAgZWwgPSB2bm9kZS5lbCA9IGhvc3RDcmVhdGVFbGVtZW50KFxuICAgICAgdm5vZGUudHlwZSxcbiAgICAgIG5hbWVzcGFjZSxcbiAgICAgIHByb3BzICYmIHByb3BzLmlzLFxuICAgICAgcHJvcHNcbiAgICApO1xuICAgIGlmIChzaGFwZUZsYWcgJiA4KSB7XG4gICAgICBob3N0U2V0RWxlbWVudFRleHQoZWwsIHZub2RlLmNoaWxkcmVuKTtcbiAgICB9IGVsc2UgaWYgKHNoYXBlRmxhZyAmIDE2KSB7XG4gICAgICBtb3VudENoaWxkcmVuKFxuICAgICAgICB2bm9kZS5jaGlsZHJlbixcbiAgICAgICAgZWwsXG4gICAgICAgIG51bGwsXG4gICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgIHJlc29sdmVDaGlsZHJlbk5hbWVzcGFjZSh2bm9kZSwgbmFtZXNwYWNlKSxcbiAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICk7XG4gICAgfVxuICAgIGlmIChkaXJzKSB7XG4gICAgICBpbnZva2VEaXJlY3RpdmVIb29rKHZub2RlLCBudWxsLCBwYXJlbnRDb21wb25lbnQsIFwiY3JlYXRlZFwiKTtcbiAgICB9XG4gICAgc2V0U2NvcGVJZChlbCwgdm5vZGUsIHZub2RlLnNjb3BlSWQsIHNsb3RTY29wZUlkcywgcGFyZW50Q29tcG9uZW50KTtcbiAgICBpZiAocHJvcHMpIHtcbiAgICAgIGZvciAoY29uc3Qga2V5IGluIHByb3BzKSB7XG4gICAgICAgIGlmIChrZXkgIT09IFwidmFsdWVcIiAmJiAhaXNSZXNlcnZlZFByb3Aoa2V5KSkge1xuICAgICAgICAgIGhvc3RQYXRjaFByb3AoZWwsIGtleSwgbnVsbCwgcHJvcHNba2V5XSwgbmFtZXNwYWNlLCBwYXJlbnRDb21wb25lbnQpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoXCJ2YWx1ZVwiIGluIHByb3BzKSB7XG4gICAgICAgIGhvc3RQYXRjaFByb3AoZWwsIFwidmFsdWVcIiwgbnVsbCwgcHJvcHMudmFsdWUsIG5hbWVzcGFjZSk7XG4gICAgICB9XG4gICAgICBpZiAodm5vZGVIb29rID0gcHJvcHMub25Wbm9kZUJlZm9yZU1vdW50KSB7XG4gICAgICAgIGludm9rZVZOb2RlSG9vayh2bm9kZUhvb2ssIHBhcmVudENvbXBvbmVudCwgdm5vZGUpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pIHtcbiAgICAgIGRlZihlbCwgXCJfX3Zub2RlXCIsIHZub2RlLCB0cnVlKTtcbiAgICAgIGRlZihlbCwgXCJfX3Z1ZVBhcmVudENvbXBvbmVudFwiLCBwYXJlbnRDb21wb25lbnQsIHRydWUpO1xuICAgIH1cbiAgICBpZiAoZGlycykge1xuICAgICAgaW52b2tlRGlyZWN0aXZlSG9vayh2bm9kZSwgbnVsbCwgcGFyZW50Q29tcG9uZW50LCBcImJlZm9yZU1vdW50XCIpO1xuICAgIH1cbiAgICBjb25zdCBuZWVkQ2FsbFRyYW5zaXRpb25Ib29rcyA9IG5lZWRUcmFuc2l0aW9uKHBhcmVudFN1c3BlbnNlLCB0cmFuc2l0aW9uKTtcbiAgICBpZiAobmVlZENhbGxUcmFuc2l0aW9uSG9va3MpIHtcbiAgICAgIHRyYW5zaXRpb24uYmVmb3JlRW50ZXIoZWwpO1xuICAgIH1cbiAgICBob3N0SW5zZXJ0KGVsLCBjb250YWluZXIsIGFuY2hvcik7XG4gICAgaWYgKCh2bm9kZUhvb2sgPSBwcm9wcyAmJiBwcm9wcy5vblZub2RlTW91bnRlZCkgfHwgbmVlZENhbGxUcmFuc2l0aW9uSG9va3MgfHwgZGlycykge1xuICAgICAgY29uc3QgaXNIbXIgPSAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGlzSG1yVXBkYXRpbmc7XG4gICAgICBxdWV1ZVBvc3RSZW5kZXJFZmZlY3QoKCkgPT4ge1xuICAgICAgICBsZXQgcHJldjtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHByZXYgPSBzZXRIbXJVcGRhdGluZyhpc0htcik7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgdm5vZGVIb29rICYmIGludm9rZVZOb2RlSG9vayh2bm9kZUhvb2ssIHBhcmVudENvbXBvbmVudCwgdm5vZGUpO1xuICAgICAgICAgIG5lZWRDYWxsVHJhbnNpdGlvbkhvb2tzICYmIHRyYW5zaXRpb24uZW50ZXIoZWwpO1xuICAgICAgICAgIGRpcnMgJiYgaW52b2tlRGlyZWN0aXZlSG9vayh2bm9kZSwgbnVsbCwgcGFyZW50Q29tcG9uZW50LCBcIm1vdW50ZWRcIik7XG4gICAgICAgIH0gZmluYWxseSB7XG4gICAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHNldEhtclVwZGF0aW5nKHByZXYpO1xuICAgICAgICB9XG4gICAgICB9LCBwYXJlbnRTdXNwZW5zZSk7XG4gICAgfVxuICB9O1xuICBjb25zdCBzZXRTY29wZUlkID0gKGVsLCB2bm9kZSwgc2NvcGVJZCwgc2xvdFNjb3BlSWRzLCBwYXJlbnRDb21wb25lbnQpID0+IHtcbiAgICBpZiAoc2NvcGVJZCkge1xuICAgICAgaG9zdFNldFNjb3BlSWQoZWwsIHNjb3BlSWQpO1xuICAgIH1cbiAgICBpZiAoc2xvdFNjb3BlSWRzKSB7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNsb3RTY29wZUlkcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBob3N0U2V0U2NvcGVJZChlbCwgc2xvdFNjb3BlSWRzW2ldKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHBhcmVudENvbXBvbmVudCkge1xuICAgICAgbGV0IHN1YlRyZWUgPSBwYXJlbnRDb21wb25lbnQuc3ViVHJlZTtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHN1YlRyZWUucGF0Y2hGbGFnID4gMCAmJiBzdWJUcmVlLnBhdGNoRmxhZyAmIDIwNDgpIHtcbiAgICAgICAgc3ViVHJlZSA9IGZpbHRlclNpbmdsZVJvb3Qoc3ViVHJlZS5jaGlsZHJlbikgfHwgc3ViVHJlZTtcbiAgICAgIH1cbiAgICAgIGlmICh2bm9kZSA9PT0gc3ViVHJlZSB8fCBpc1N1c3BlbnNlKHN1YlRyZWUudHlwZSkgJiYgKHN1YlRyZWUuc3NDb250ZW50ID09PSB2bm9kZSB8fCBzdWJUcmVlLnNzRmFsbGJhY2sgPT09IHZub2RlKSkge1xuICAgICAgICBjb25zdCBwYXJlbnRWTm9kZSA9IHBhcmVudENvbXBvbmVudC52bm9kZTtcbiAgICAgICAgc2V0U2NvcGVJZChcbiAgICAgICAgICBlbCxcbiAgICAgICAgICBwYXJlbnRWTm9kZSxcbiAgICAgICAgICBwYXJlbnRWTm9kZS5zY29wZUlkLFxuICAgICAgICAgIHBhcmVudFZOb2RlLnNsb3RTY29wZUlkcyxcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQucGFyZW50XG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuICBjb25zdCBtb3VudENoaWxkcmVuID0gKGNoaWxkcmVuLCBjb250YWluZXIsIGFuY2hvciwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgbmFtZXNwYWNlLCBzbG90U2NvcGVJZHMsIG9wdGltaXplZCwgc3RhcnQgPSAwKSA9PiB7XG4gICAgZm9yIChsZXQgaSA9IHN0YXJ0OyBpIDwgY2hpbGRyZW4ubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGNoaWxkID0gY2hpbGRyZW5baV0gPSBvcHRpbWl6ZWQgPyBjbG9uZUlmTW91bnRlZChjaGlsZHJlbltpXSkgOiBub3JtYWxpemVWTm9kZShjaGlsZHJlbltpXSk7XG4gICAgICBwYXRjaChcbiAgICAgICAgbnVsbCxcbiAgICAgICAgY2hpbGQsXG4gICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgYW5jaG9yLFxuICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgb3B0aW1pemVkXG4gICAgICApO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgcGF0Y2hFbGVtZW50ID0gKG4xLCBuMiwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgbmFtZXNwYWNlLCBzbG90U2NvcGVJZHMsIG9wdGltaXplZCkgPT4ge1xuICAgIGNvbnN0IGVsID0gbjIuZWwgPSBuMS5lbDtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pIHtcbiAgICAgIGVsLl9fdm5vZGUgPSBuMjtcbiAgICB9XG4gICAgbGV0IHsgcGF0Y2hGbGFnLCBkeW5hbWljQ2hpbGRyZW4sIGRpcnMgfSA9IG4yO1xuICAgIHBhdGNoRmxhZyB8PSBuMS5wYXRjaEZsYWcgJiAxNjtcbiAgICBjb25zdCBvbGRQcm9wcyA9IG4xLnByb3BzIHx8IEVNUFRZX09CSjtcbiAgICBjb25zdCBuZXdQcm9wcyA9IG4yLnByb3BzIHx8IEVNUFRZX09CSjtcbiAgICBsZXQgdm5vZGVIb29rO1xuICAgIHBhcmVudENvbXBvbmVudCAmJiB0b2dnbGVSZWN1cnNlKHBhcmVudENvbXBvbmVudCwgZmFsc2UpO1xuICAgIGlmICh2bm9kZUhvb2sgPSBuZXdQcm9wcy5vblZub2RlQmVmb3JlVXBkYXRlKSB7XG4gICAgICBpbnZva2VWTm9kZUhvb2sodm5vZGVIb29rLCBwYXJlbnRDb21wb25lbnQsIG4yLCBuMSk7XG4gICAgfVxuICAgIGlmIChkaXJzKSB7XG4gICAgICBpbnZva2VEaXJlY3RpdmVIb29rKG4yLCBuMSwgcGFyZW50Q29tcG9uZW50LCBcImJlZm9yZVVwZGF0ZVwiKTtcbiAgICB9XG4gICAgcGFyZW50Q29tcG9uZW50ICYmIHRvZ2dsZVJlY3Vyc2UocGFyZW50Q29tcG9uZW50LCB0cnVlKTtcbiAgICBpZiAoXG4gICAgICAvLyBITVIgdXBkYXRlZCwgZm9yY2UgZnVsbCBkaWZmXG4gICAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGlzSG1yVXBkYXRpbmcgfHwgLy8gIzYzODUgdGhlIG9sZCB2bm9kZSBtYXkgYmUgYSB1c2VyLXdyYXBwZWQgbm9uLWlzb21vcnBoaWMgYmxvY2tcbiAgICAgIC8vIEZvcmNlIGZ1bGwgZGlmZiB3aGVuIGJsb2NrIG1ldGFkYXRhIGlzIHVuc3RhYmxlLlxuICAgICAgZHluYW1pY0NoaWxkcmVuICYmICghbjEuZHluYW1pY0NoaWxkcmVuIHx8IG4xLmR5bmFtaWNDaGlsZHJlbi5sZW5ndGggIT09IGR5bmFtaWNDaGlsZHJlbi5sZW5ndGgpXG4gICAgKSB7XG4gICAgICBwYXRjaEZsYWcgPSAwO1xuICAgICAgb3B0aW1pemVkID0gZmFsc2U7XG4gICAgICBkeW5hbWljQ2hpbGRyZW4gPSBudWxsO1xuICAgIH1cbiAgICBpZiAob2xkUHJvcHMuaW5uZXJIVE1MICYmIG5ld1Byb3BzLmlubmVySFRNTCA9PSBudWxsIHx8IG9sZFByb3BzLnRleHRDb250ZW50ICYmIG5ld1Byb3BzLnRleHRDb250ZW50ID09IG51bGwpIHtcbiAgICAgIGhvc3RTZXRFbGVtZW50VGV4dChlbCwgXCJcIik7XG4gICAgfVxuICAgIGlmIChkeW5hbWljQ2hpbGRyZW4pIHtcbiAgICAgIHBhdGNoQmxvY2tDaGlsZHJlbihcbiAgICAgICAgbjEuZHluYW1pY0NoaWxkcmVuLFxuICAgICAgICBkeW5hbWljQ2hpbGRyZW4sXG4gICAgICAgIGVsLFxuICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICByZXNvbHZlQ2hpbGRyZW5OYW1lc3BhY2UobjIsIG5hbWVzcGFjZSksXG4gICAgICAgIHNsb3RTY29wZUlkc1xuICAgICAgKTtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgIHRyYXZlcnNlU3RhdGljQ2hpbGRyZW4objEsIG4yKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKCFvcHRpbWl6ZWQpIHtcbiAgICAgIHBhdGNoQ2hpbGRyZW4oXG4gICAgICAgIG4xLFxuICAgICAgICBuMixcbiAgICAgICAgZWwsXG4gICAgICAgIG51bGwsXG4gICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgIHJlc29sdmVDaGlsZHJlbk5hbWVzcGFjZShuMiwgbmFtZXNwYWNlKSxcbiAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICBmYWxzZVxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKHBhdGNoRmxhZyA+IDApIHtcbiAgICAgIGlmIChwYXRjaEZsYWcgJiAxNikge1xuICAgICAgICBwYXRjaFByb3BzKGVsLCBvbGRQcm9wcywgbmV3UHJvcHMsIHBhcmVudENvbXBvbmVudCwgbmFtZXNwYWNlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChwYXRjaEZsYWcgJiAyKSB7XG4gICAgICAgICAgaWYgKG9sZFByb3BzLmNsYXNzICE9PSBuZXdQcm9wcy5jbGFzcykge1xuICAgICAgICAgICAgaG9zdFBhdGNoUHJvcChlbCwgXCJjbGFzc1wiLCBudWxsLCBuZXdQcm9wcy5jbGFzcywgbmFtZXNwYWNlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHBhdGNoRmxhZyAmIDQpIHtcbiAgICAgICAgICBob3N0UGF0Y2hQcm9wKGVsLCBcInN0eWxlXCIsIG9sZFByb3BzLnN0eWxlLCBuZXdQcm9wcy5zdHlsZSwgbmFtZXNwYWNlKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocGF0Y2hGbGFnICYgOCkge1xuICAgICAgICAgIGNvbnN0IHByb3BzVG9VcGRhdGUgPSBuMi5keW5hbWljUHJvcHM7XG4gICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwcm9wc1RvVXBkYXRlLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBrZXkgPSBwcm9wc1RvVXBkYXRlW2ldO1xuICAgICAgICAgICAgY29uc3QgcHJldiA9IG9sZFByb3BzW2tleV07XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gbmV3UHJvcHNba2V5XTtcbiAgICAgICAgICAgIGlmIChuZXh0ICE9PSBwcmV2IHx8IGtleSA9PT0gXCJ2YWx1ZVwiKSB7XG4gICAgICAgICAgICAgIGhvc3RQYXRjaFByb3AoZWwsIGtleSwgcHJldiwgbmV4dCwgbmFtZXNwYWNlLCBwYXJlbnRDb21wb25lbnQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKHBhdGNoRmxhZyAmIDEpIHtcbiAgICAgICAgaWYgKG4xLmNoaWxkcmVuICE9PSBuMi5jaGlsZHJlbikge1xuICAgICAgICAgIGhvc3RTZXRFbGVtZW50VGV4dChlbCwgbjIuY2hpbGRyZW4pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBlbHNlIGlmICghb3B0aW1pemVkICYmIGR5bmFtaWNDaGlsZHJlbiA9PSBudWxsKSB7XG4gICAgICBwYXRjaFByb3BzKGVsLCBvbGRQcm9wcywgbmV3UHJvcHMsIHBhcmVudENvbXBvbmVudCwgbmFtZXNwYWNlKTtcbiAgICB9XG4gICAgaWYgKCh2bm9kZUhvb2sgPSBuZXdQcm9wcy5vblZub2RlVXBkYXRlZCkgfHwgZGlycykge1xuICAgICAgcXVldWVQb3N0UmVuZGVyRWZmZWN0KCgpID0+IHtcbiAgICAgICAgdm5vZGVIb29rICYmIGludm9rZVZOb2RlSG9vayh2bm9kZUhvb2ssIHBhcmVudENvbXBvbmVudCwgbjIsIG4xKTtcbiAgICAgICAgZGlycyAmJiBpbnZva2VEaXJlY3RpdmVIb29rKG4yLCBuMSwgcGFyZW50Q29tcG9uZW50LCBcInVwZGF0ZWRcIik7XG4gICAgICB9LCBwYXJlbnRTdXNwZW5zZSk7XG4gICAgfVxuICB9O1xuICBjb25zdCBwYXRjaEJsb2NrQ2hpbGRyZW4gPSAob2xkQ2hpbGRyZW4sIG5ld0NoaWxkcmVuLCBmYWxsYmFja0NvbnRhaW5lciwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgbmFtZXNwYWNlLCBzbG90U2NvcGVJZHMpID0+IHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IG5ld0NoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBvbGRWTm9kZSA9IG9sZENoaWxkcmVuW2ldO1xuICAgICAgY29uc3QgbmV3Vk5vZGUgPSBuZXdDaGlsZHJlbltpXTtcbiAgICAgIGNvbnN0IGNvbnRhaW5lciA9IChcbiAgICAgICAgLy8gb2xkVk5vZGUgbWF5IGJlIGFuIGVycm9yZWQgYXN5bmMgc2V0dXAoKSBjb21wb25lbnQgaW5zaWRlIFN1c3BlbnNlXG4gICAgICAgIC8vIHdoaWNoIHdpbGwgbm90IGhhdmUgYSBtb3VudGVkIGVsZW1lbnRcbiAgICAgICAgb2xkVk5vZGUuZWwgJiYgLy8gLSBJbiB0aGUgY2FzZSBvZiBhIEZyYWdtZW50LCB3ZSBuZWVkIHRvIHByb3ZpZGUgdGhlIGFjdHVhbCBwYXJlbnRcbiAgICAgICAgLy8gb2YgdGhlIEZyYWdtZW50IGl0c2VsZiBzbyBpdCBjYW4gbW92ZSBpdHMgY2hpbGRyZW4uXG4gICAgICAgIChvbGRWTm9kZS50eXBlID09PSBGcmFnbWVudCB8fCAvLyAtIEluIHRoZSBjYXNlIG9mIGRpZmZlcmVudCBub2RlcywgdGhlcmUgaXMgZ29pbmcgdG8gYmUgYSByZXBsYWNlbWVudFxuICAgICAgICAvLyB3aGljaCBhbHNvIHJlcXVpcmVzIHRoZSBjb3JyZWN0IHBhcmVudCBjb250YWluZXJcbiAgICAgICAgIWlzU2FtZVZOb2RlVHlwZShvbGRWTm9kZSwgbmV3Vk5vZGUpIHx8IC8vIC0gSW4gdGhlIGNhc2Ugb2YgYSBjb21wb25lbnQsIGl0IGNvdWxkIGNvbnRhaW4gYW55dGhpbmcuXG4gICAgICAgIG9sZFZOb2RlLnNoYXBlRmxhZyAmICg2IHwgNjQgfCAxMjgpKSA/IGhvc3RQYXJlbnROb2RlKG9sZFZOb2RlLmVsKSA6IChcbiAgICAgICAgICAvLyBJbiBvdGhlciBjYXNlcywgdGhlIHBhcmVudCBjb250YWluZXIgaXMgbm90IGFjdHVhbGx5IHVzZWQgc28gd2VcbiAgICAgICAgICAvLyBqdXN0IHBhc3MgdGhlIGJsb2NrIGVsZW1lbnQgaGVyZSB0byBhdm9pZCBhIERPTSBwYXJlbnROb2RlIGNhbGwuXG4gICAgICAgICAgZmFsbGJhY2tDb250YWluZXJcbiAgICAgICAgKVxuICAgICAgKTtcbiAgICAgIHBhdGNoKFxuICAgICAgICBvbGRWTm9kZSxcbiAgICAgICAgbmV3Vk5vZGUsXG4gICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgbnVsbCxcbiAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgIHRydWVcbiAgICAgICk7XG4gICAgfVxuICB9O1xuICBjb25zdCBwYXRjaFByb3BzID0gKGVsLCBvbGRQcm9wcywgbmV3UHJvcHMsIHBhcmVudENvbXBvbmVudCwgbmFtZXNwYWNlKSA9PiB7XG4gICAgaWYgKG9sZFByb3BzICE9PSBuZXdQcm9wcykge1xuICAgICAgaWYgKG9sZFByb3BzICE9PSBFTVBUWV9PQkopIHtcbiAgICAgICAgZm9yIChjb25zdCBrZXkgaW4gb2xkUHJvcHMpIHtcbiAgICAgICAgICBpZiAoIWlzUmVzZXJ2ZWRQcm9wKGtleSkgJiYgIShrZXkgaW4gbmV3UHJvcHMpKSB7XG4gICAgICAgICAgICBob3N0UGF0Y2hQcm9wKFxuICAgICAgICAgICAgICBlbCxcbiAgICAgICAgICAgICAga2V5LFxuICAgICAgICAgICAgICBvbGRQcm9wc1trZXldLFxuICAgICAgICAgICAgICBudWxsLFxuICAgICAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgICAgIHBhcmVudENvbXBvbmVudFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGZvciAoY29uc3Qga2V5IGluIG5ld1Byb3BzKSB7XG4gICAgICAgIGlmIChpc1Jlc2VydmVkUHJvcChrZXkpKSBjb250aW51ZTtcbiAgICAgICAgY29uc3QgbmV4dCA9IG5ld1Byb3BzW2tleV07XG4gICAgICAgIGNvbnN0IHByZXYgPSBvbGRQcm9wc1trZXldO1xuICAgICAgICBpZiAobmV4dCAhPT0gcHJldiAmJiBrZXkgIT09IFwidmFsdWVcIikge1xuICAgICAgICAgIGhvc3RQYXRjaFByb3AoZWwsIGtleSwgcHJldiwgbmV4dCwgbmFtZXNwYWNlLCBwYXJlbnRDb21wb25lbnQpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoXCJ2YWx1ZVwiIGluIG5ld1Byb3BzKSB7XG4gICAgICAgIGhvc3RQYXRjaFByb3AoZWwsIFwidmFsdWVcIiwgb2xkUHJvcHMudmFsdWUsIG5ld1Byb3BzLnZhbHVlLCBuYW1lc3BhY2UpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbiAgY29uc3QgcHJvY2Vzc0ZyYWdtZW50ID0gKG4xLCBuMiwgY29udGFpbmVyLCBhbmNob3IsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIG5hbWVzcGFjZSwgc2xvdFNjb3BlSWRzLCBvcHRpbWl6ZWQpID0+IHtcbiAgICBjb25zdCBmcmFnbWVudFN0YXJ0QW5jaG9yID0gbjIuZWwgPSBuMSA/IG4xLmVsIDogaG9zdENyZWF0ZVRleHQoXCJcIik7XG4gICAgY29uc3QgZnJhZ21lbnRFbmRBbmNob3IgPSBuMi5hbmNob3IgPSBuMSA/IG4xLmFuY2hvciA6IGhvc3RDcmVhdGVUZXh0KFwiXCIpO1xuICAgIGxldCB7IHBhdGNoRmxhZywgZHluYW1pY0NoaWxkcmVuLCBzbG90U2NvcGVJZHM6IGZyYWdtZW50U2xvdFNjb3BlSWRzIH0gPSBuMjtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiAvLyAjNTUyMyBkZXYgcm9vdCBmcmFnbWVudCBtYXkgaW5oZXJpdCBkaXJlY3RpdmVzXG4gICAgKGlzSG1yVXBkYXRpbmcgfHwgcGF0Y2hGbGFnICYgMjA0OCkpIHtcbiAgICAgIHBhdGNoRmxhZyA9IDA7XG4gICAgICBvcHRpbWl6ZWQgPSBmYWxzZTtcbiAgICAgIGR5bmFtaWNDaGlsZHJlbiA9IG51bGw7XG4gICAgfVxuICAgIGlmIChmcmFnbWVudFNsb3RTY29wZUlkcykge1xuICAgICAgc2xvdFNjb3BlSWRzID0gc2xvdFNjb3BlSWRzID8gc2xvdFNjb3BlSWRzLmNvbmNhdChmcmFnbWVudFNsb3RTY29wZUlkcykgOiBmcmFnbWVudFNsb3RTY29wZUlkcztcbiAgICB9XG4gICAgaWYgKG4xID09IG51bGwpIHtcbiAgICAgIGhvc3RJbnNlcnQoZnJhZ21lbnRTdGFydEFuY2hvciwgY29udGFpbmVyLCBhbmNob3IpO1xuICAgICAgaG9zdEluc2VydChmcmFnbWVudEVuZEFuY2hvciwgY29udGFpbmVyLCBhbmNob3IpO1xuICAgICAgbW91bnRDaGlsZHJlbihcbiAgICAgICAgLy8gIzEwMDA3XG4gICAgICAgIC8vIHN1Y2ggZnJhZ21lbnQgbGlrZSBgPD48Lz5gIHdpbGwgYmUgY29tcGlsZWQgaW50b1xuICAgICAgICAvLyBhIGZyYWdtZW50IHdoaWNoIGRvZXNuJ3QgaGF2ZSBhIGNoaWxkcmVuLlxuICAgICAgICAvLyBJbiB0aGlzIGNhc2UgZmFsbGJhY2sgdG8gYW4gZW1wdHkgYXJyYXlcbiAgICAgICAgbjIuY2hpbGRyZW4gfHwgW10sXG4gICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgZnJhZ21lbnRFbmRBbmNob3IsXG4gICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChwYXRjaEZsYWcgPiAwICYmIHBhdGNoRmxhZyAmIDY0ICYmIGR5bmFtaWNDaGlsZHJlbiAmJiAvLyAjMjcxNSB0aGUgcHJldmlvdXMgZnJhZ21lbnQgY291bGQndmUgYmVlbiBhIEJBSUxlZCBvbmUgYXMgYSByZXN1bHRcbiAgICAgIC8vIG9mIHJlbmRlclNsb3QoKSB3aXRoIG5vIHZhbGlkIGNoaWxkcmVuXG4gICAgICBuMS5keW5hbWljQ2hpbGRyZW4gJiYgbjEuZHluYW1pY0NoaWxkcmVuLmxlbmd0aCA9PT0gZHluYW1pY0NoaWxkcmVuLmxlbmd0aCkge1xuICAgICAgICBwYXRjaEJsb2NrQ2hpbGRyZW4oXG4gICAgICAgICAgbjEuZHluYW1pY0NoaWxkcmVuLFxuICAgICAgICAgIGR5bmFtaWNDaGlsZHJlbixcbiAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgICBzbG90U2NvcGVJZHNcbiAgICAgICAgKTtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICB0cmF2ZXJzZVN0YXRpY0NoaWxkcmVuKG4xLCBuMik7XG4gICAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgICAgLy8gIzIwODAgaWYgdGhlIHN0YWJsZSBmcmFnbWVudCBoYXMgYSBrZXksIGl0J3MgYSA8dGVtcGxhdGUgdi1mb3I+IHRoYXQgbWF5XG4gICAgICAgICAgLy8gIGdldCBtb3ZlZCBhcm91bmQuIE1ha2Ugc3VyZSBhbGwgcm9vdCBsZXZlbCB2bm9kZXMgaW5oZXJpdCBlbC5cbiAgICAgICAgICAvLyAjMjEzNCBvciBpZiBpdCdzIGEgY29tcG9uZW50IHJvb3QsIGl0IG1heSBhbHNvIGdldCBtb3ZlZCBhcm91bmRcbiAgICAgICAgICAvLyBhcyB0aGUgY29tcG9uZW50IGlzIGJlaW5nIG1vdmVkLlxuICAgICAgICAgIG4yLmtleSAhPSBudWxsIHx8IHBhcmVudENvbXBvbmVudCAmJiBuMiA9PT0gcGFyZW50Q29tcG9uZW50LnN1YlRyZWVcbiAgICAgICAgKSB7XG4gICAgICAgICAgdHJhdmVyc2VTdGF0aWNDaGlsZHJlbihcbiAgICAgICAgICAgIG4xLFxuICAgICAgICAgICAgbjIsXG4gICAgICAgICAgICB0cnVlXG4gICAgICAgICAgICAvKiBzaGFsbG93ICovXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcGF0Y2hDaGlsZHJlbihcbiAgICAgICAgICBuMSxcbiAgICAgICAgICBuMixcbiAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgZnJhZ21lbnRFbmRBbmNob3IsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuICBjb25zdCBwcm9jZXNzQ29tcG9uZW50ID0gKG4xLCBuMiwgY29udGFpbmVyLCBhbmNob3IsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIG5hbWVzcGFjZSwgc2xvdFNjb3BlSWRzLCBvcHRpbWl6ZWQpID0+IHtcbiAgICBuMi5zbG90U2NvcGVJZHMgPSBzbG90U2NvcGVJZHM7XG4gICAgaWYgKG4xID09IG51bGwpIHtcbiAgICAgIGlmIChuMi5zaGFwZUZsYWcgJiA1MTIpIHtcbiAgICAgICAgcGFyZW50Q29tcG9uZW50LmN0eC5hY3RpdmF0ZShcbiAgICAgICAgICBuMixcbiAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgYW5jaG9yLFxuICAgICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG1vdW50Q29tcG9uZW50KFxuICAgICAgICAgIG4yLFxuICAgICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgICBhbmNob3IsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgdXBkYXRlQ29tcG9uZW50KG4xLCBuMiwgb3B0aW1pemVkKTtcbiAgICB9XG4gIH07XG4gIGNvbnN0IG1vdW50Q29tcG9uZW50ID0gKGluaXRpYWxWTm9kZSwgY29udGFpbmVyLCBhbmNob3IsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIG5hbWVzcGFjZSwgb3B0aW1pemVkKSA9PiB7XG4gICAgY29uc3QgaW5zdGFuY2UgPSAoaW5pdGlhbFZOb2RlLmNvbXBvbmVudCA9IGNyZWF0ZUNvbXBvbmVudEluc3RhbmNlKFxuICAgICAgaW5pdGlhbFZOb2RlLFxuICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgcGFyZW50U3VzcGVuc2VcbiAgICApKTtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBpbnN0YW5jZS50eXBlLl9faG1ySWQpIHtcbiAgICAgIHJlZ2lzdGVySE1SKGluc3RhbmNlKTtcbiAgICB9XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgIHB1c2hXYXJuaW5nQ29udGV4dChpbml0aWFsVk5vZGUpO1xuICAgICAgc3RhcnRNZWFzdXJlKGluc3RhbmNlLCBgbW91bnRgKTtcbiAgICB9XG4gICAgaWYgKGlzS2VlcEFsaXZlKGluaXRpYWxWTm9kZSkpIHtcbiAgICAgIGluc3RhbmNlLmN0eC5yZW5kZXJlciA9IGludGVybmFscztcbiAgICB9XG4gICAge1xuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgc3RhcnRNZWFzdXJlKGluc3RhbmNlLCBgaW5pdGApO1xuICAgICAgfVxuICAgICAgc2V0dXBDb21wb25lbnQoaW5zdGFuY2UsIGZhbHNlLCBvcHRpbWl6ZWQpO1xuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgZW5kTWVhc3VyZShpbnN0YW5jZSwgYGluaXRgKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgaXNIbXJVcGRhdGluZykgaW5pdGlhbFZOb2RlLmVsID0gbnVsbDtcbiAgICBpZiAoaW5zdGFuY2UuYXN5bmNEZXApIHtcbiAgICAgIHBhcmVudFN1c3BlbnNlICYmIHBhcmVudFN1c3BlbnNlLnJlZ2lzdGVyRGVwKGluc3RhbmNlLCBzZXR1cFJlbmRlckVmZmVjdCwgb3B0aW1pemVkKTtcbiAgICAgIGlmICghaW5pdGlhbFZOb2RlLmVsKSB7XG4gICAgICAgIGNvbnN0IHBsYWNlaG9sZGVyID0gaW5zdGFuY2Uuc3ViVHJlZSA9IGNyZWF0ZVZOb2RlKENvbW1lbnQpO1xuICAgICAgICBwcm9jZXNzQ29tbWVudE5vZGUobnVsbCwgcGxhY2Vob2xkZXIsIGNvbnRhaW5lciwgYW5jaG9yKTtcbiAgICAgICAgaW5pdGlhbFZOb2RlLnBsYWNlaG9sZGVyID0gcGxhY2Vob2xkZXIuZWw7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldHVwUmVuZGVyRWZmZWN0KFxuICAgICAgICBpbnN0YW5jZSxcbiAgICAgICAgaW5pdGlhbFZOb2RlLFxuICAgICAgICBjb250YWluZXIsXG4gICAgICAgIGFuY2hvcixcbiAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgb3B0aW1pemVkXG4gICAgICApO1xuICAgIH1cbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgcG9wV2FybmluZ0NvbnRleHQoKTtcbiAgICAgIGVuZE1lYXN1cmUoaW5zdGFuY2UsIGBtb3VudGApO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgdXBkYXRlQ29tcG9uZW50ID0gKG4xLCBuMiwgb3B0aW1pemVkKSA9PiB7XG4gICAgY29uc3QgaW5zdGFuY2UgPSBuMi5jb21wb25lbnQgPSBuMS5jb21wb25lbnQ7XG4gICAgaWYgKHNob3VsZFVwZGF0ZUNvbXBvbmVudChuMSwgbjIsIG9wdGltaXplZCkpIHtcbiAgICAgIGlmIChpbnN0YW5jZS5hc3luY0RlcCAmJiAhaW5zdGFuY2UuYXN5bmNSZXNvbHZlZCkge1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIHB1c2hXYXJuaW5nQ29udGV4dChuMik7XG4gICAgICAgIH1cbiAgICAgICAgdXBkYXRlQ29tcG9uZW50UHJlUmVuZGVyKGluc3RhbmNlLCBuMiwgb3B0aW1pemVkKTtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICBwb3BXYXJuaW5nQ29udGV4dCgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybjtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGluc3RhbmNlLm5leHQgPSBuMjtcbiAgICAgICAgaW5zdGFuY2UudXBkYXRlKCk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIG4yLmVsID0gbjEuZWw7XG4gICAgICBpbnN0YW5jZS52bm9kZSA9IG4yO1xuICAgIH1cbiAgfTtcbiAgY29uc3Qgc2V0dXBSZW5kZXJFZmZlY3QgPSAoaW5zdGFuY2UsIGluaXRpYWxWTm9kZSwgY29udGFpbmVyLCBhbmNob3IsIHBhcmVudFN1c3BlbnNlLCBuYW1lc3BhY2UsIG9wdGltaXplZCkgPT4ge1xuICAgIGNvbnN0IGNvbXBvbmVudFVwZGF0ZUZuID0gKCkgPT4ge1xuICAgICAgaWYgKCFpbnN0YW5jZS5pc01vdW50ZWQpIHtcbiAgICAgICAgbGV0IHZub2RlSG9vaztcbiAgICAgICAgY29uc3QgeyBlbCwgcHJvcHMgfSA9IGluaXRpYWxWTm9kZTtcbiAgICAgICAgY29uc3QgeyBibSwgbSwgcGFyZW50LCByb290LCB0eXBlIH0gPSBpbnN0YW5jZTtcbiAgICAgICAgY29uc3QgaXNBc3luY1dyYXBwZXJWTm9kZSA9IGlzQXN5bmNXcmFwcGVyKGluaXRpYWxWTm9kZSk7XG4gICAgICAgIHRvZ2dsZVJlY3Vyc2UoaW5zdGFuY2UsIGZhbHNlKTtcbiAgICAgICAgaWYgKGJtKSB7XG4gICAgICAgICAgaW52b2tlQXJyYXlGbnMoYm0pO1xuICAgICAgICB9XG4gICAgICAgIGlmICghaXNBc3luY1dyYXBwZXJWTm9kZSAmJiAodm5vZGVIb29rID0gcHJvcHMgJiYgcHJvcHMub25Wbm9kZUJlZm9yZU1vdW50KSkge1xuICAgICAgICAgIGludm9rZVZOb2RlSG9vayh2bm9kZUhvb2ssIHBhcmVudCwgaW5pdGlhbFZOb2RlKTtcbiAgICAgICAgfVxuICAgICAgICB0b2dnbGVSZWN1cnNlKGluc3RhbmNlLCB0cnVlKTtcbiAgICAgICAgaWYgKGVsICYmIGh5ZHJhdGVOb2RlKSB7XG4gICAgICAgICAgY29uc3QgaHlkcmF0ZVN1YlRyZWUgPSAoKSA9PiB7XG4gICAgICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgICAgICBzdGFydE1lYXN1cmUoaW5zdGFuY2UsIGByZW5kZXJgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGluc3RhbmNlLnN1YlRyZWUgPSByZW5kZXJDb21wb25lbnRSb290KGluc3RhbmNlKTtcbiAgICAgICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgICAgIGVuZE1lYXN1cmUoaW5zdGFuY2UsIGByZW5kZXJgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgICAgIHN0YXJ0TWVhc3VyZShpbnN0YW5jZSwgYGh5ZHJhdGVgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGh5ZHJhdGVOb2RlKFxuICAgICAgICAgICAgICBlbCxcbiAgICAgICAgICAgICAgaW5zdGFuY2Uuc3ViVHJlZSxcbiAgICAgICAgICAgICAgaW5zdGFuY2UsXG4gICAgICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgICAgICBudWxsXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICAgICAgZW5kTWVhc3VyZShpbnN0YW5jZSwgYGh5ZHJhdGVgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9O1xuICAgICAgICAgIGlmIChpc0FzeW5jV3JhcHBlclZOb2RlICYmIHR5cGUuX19hc3luY0h5ZHJhdGUpIHtcbiAgICAgICAgICAgIHR5cGUuX19hc3luY0h5ZHJhdGUoXG4gICAgICAgICAgICAgIGVsLFxuICAgICAgICAgICAgICBpbnN0YW5jZSxcbiAgICAgICAgICAgICAgaHlkcmF0ZVN1YlRyZWVcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGh5ZHJhdGVTdWJUcmVlKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGlmIChyb290LmNlICYmIHJvb3QuY2UuX2hhc1NoYWRvd1Jvb3QoKSkge1xuICAgICAgICAgICAgcm9vdC5jZS5faW5qZWN0Q2hpbGRTdHlsZShcbiAgICAgICAgICAgICAgdHlwZSxcbiAgICAgICAgICAgICAgaW5zdGFuY2UucGFyZW50ID8gaW5zdGFuY2UucGFyZW50LnR5cGUgOiB2b2lkIDBcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgICBzdGFydE1lYXN1cmUoaW5zdGFuY2UsIGByZW5kZXJgKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3Qgc3ViVHJlZSA9IGluc3RhbmNlLnN1YlRyZWUgPSByZW5kZXJDb21wb25lbnRSb290KGluc3RhbmNlKTtcbiAgICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgICAgZW5kTWVhc3VyZShpbnN0YW5jZSwgYHJlbmRlcmApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgICAgc3RhcnRNZWFzdXJlKGluc3RhbmNlLCBgcGF0Y2hgKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcGF0Y2goXG4gICAgICAgICAgICBudWxsLFxuICAgICAgICAgICAgc3ViVHJlZSxcbiAgICAgICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgICAgIGFuY2hvcixcbiAgICAgICAgICAgIGluc3RhbmNlLFxuICAgICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgICBuYW1lc3BhY2VcbiAgICAgICAgICApO1xuICAgICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgICBlbmRNZWFzdXJlKGluc3RhbmNlLCBgcGF0Y2hgKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaW5pdGlhbFZOb2RlLmVsID0gc3ViVHJlZS5lbDtcbiAgICAgICAgfVxuICAgICAgICBpZiAobSkge1xuICAgICAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdChtLCBwYXJlbnRTdXNwZW5zZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFpc0FzeW5jV3JhcHBlclZOb2RlICYmICh2bm9kZUhvb2sgPSBwcm9wcyAmJiBwcm9wcy5vblZub2RlTW91bnRlZCkpIHtcbiAgICAgICAgICBjb25zdCBzY29wZWRJbml0aWFsVk5vZGUgPSBpbml0aWFsVk5vZGU7XG4gICAgICAgICAgcXVldWVQb3N0UmVuZGVyRWZmZWN0KFxuICAgICAgICAgICAgKCkgPT4gaW52b2tlVk5vZGVIb29rKHZub2RlSG9vaywgcGFyZW50LCBzY29wZWRJbml0aWFsVk5vZGUpLFxuICAgICAgICAgICAgcGFyZW50U3VzcGVuc2VcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpbml0aWFsVk5vZGUuc2hhcGVGbGFnICYgMjU2IHx8IHBhcmVudCAmJiBpc0FzeW5jV3JhcHBlcihwYXJlbnQudm5vZGUpICYmIHBhcmVudC52bm9kZS5zaGFwZUZsYWcgJiAyNTYpIHtcbiAgICAgICAgICBpbnN0YW5jZS5hICYmIHF1ZXVlUG9zdFJlbmRlckVmZmVjdChpbnN0YW5jZS5hLCBwYXJlbnRTdXNwZW5zZSk7XG4gICAgICAgIH1cbiAgICAgICAgaW5zdGFuY2UuaXNNb3VudGVkID0gdHJ1ZTtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgX19WVUVfUFJPRF9ERVZUT09MU19fKSB7XG4gICAgICAgICAgZGV2dG9vbHNDb21wb25lbnRBZGRlZChpbnN0YW5jZSk7XG4gICAgICAgIH1cbiAgICAgICAgaW5pdGlhbFZOb2RlID0gY29udGFpbmVyID0gYW5jaG9yID0gbnVsbDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGxldCB7IG5leHQsIGJ1LCB1LCBwYXJlbnQsIHZub2RlIH0gPSBpbnN0YW5jZTtcbiAgICAgICAge1xuICAgICAgICAgIGNvbnN0IG5vbkh5ZHJhdGVkQXN5bmNSb290ID0gbG9jYXRlTm9uSHlkcmF0ZWRBc3luY1Jvb3QoaW5zdGFuY2UpO1xuICAgICAgICAgIGlmIChub25IeWRyYXRlZEFzeW5jUm9vdCkge1xuICAgICAgICAgICAgaWYgKG5leHQpIHtcbiAgICAgICAgICAgICAgbmV4dC5lbCA9IHZub2RlLmVsO1xuICAgICAgICAgICAgICB1cGRhdGVDb21wb25lbnRQcmVSZW5kZXIoaW5zdGFuY2UsIG5leHQsIG9wdGltaXplZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBub25IeWRyYXRlZEFzeW5jUm9vdC5hc3luY0RlcC50aGVuKCgpID0+IHtcbiAgICAgICAgICAgICAgcXVldWVQb3N0UmVuZGVyRWZmZWN0KCgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoIWluc3RhbmNlLmlzVW5tb3VudGVkKSB1cGRhdGUoKTtcbiAgICAgICAgICAgICAgfSwgcGFyZW50U3VzcGVuc2UpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGxldCBvcmlnaW5OZXh0ID0gbmV4dDtcbiAgICAgICAgbGV0IHZub2RlSG9vaztcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICBwdXNoV2FybmluZ0NvbnRleHQobmV4dCB8fCBpbnN0YW5jZS52bm9kZSk7XG4gICAgICAgIH1cbiAgICAgICAgdG9nZ2xlUmVjdXJzZShpbnN0YW5jZSwgZmFsc2UpO1xuICAgICAgICBpZiAobmV4dCkge1xuICAgICAgICAgIG5leHQuZWwgPSB2bm9kZS5lbDtcbiAgICAgICAgICB1cGRhdGVDb21wb25lbnRQcmVSZW5kZXIoaW5zdGFuY2UsIG5leHQsIG9wdGltaXplZCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgbmV4dCA9IHZub2RlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChidSkge1xuICAgICAgICAgIGludm9rZUFycmF5Rm5zKGJ1KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodm5vZGVIb29rID0gbmV4dC5wcm9wcyAmJiBuZXh0LnByb3BzLm9uVm5vZGVCZWZvcmVVcGRhdGUpIHtcbiAgICAgICAgICBpbnZva2VWTm9kZUhvb2sodm5vZGVIb29rLCBwYXJlbnQsIG5leHQsIHZub2RlKTtcbiAgICAgICAgfVxuICAgICAgICB0b2dnbGVSZWN1cnNlKGluc3RhbmNlLCB0cnVlKTtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICBzdGFydE1lYXN1cmUoaW5zdGFuY2UsIGByZW5kZXJgKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBuZXh0VHJlZSA9IHJlbmRlckNvbXBvbmVudFJvb3QoaW5zdGFuY2UpO1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIGVuZE1lYXN1cmUoaW5zdGFuY2UsIGByZW5kZXJgKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwcmV2VHJlZSA9IGluc3RhbmNlLnN1YlRyZWU7XG4gICAgICAgIGluc3RhbmNlLnN1YlRyZWUgPSBuZXh0VHJlZTtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICBzdGFydE1lYXN1cmUoaW5zdGFuY2UsIGBwYXRjaGApO1xuICAgICAgICB9XG4gICAgICAgIHBhdGNoKFxuICAgICAgICAgIHByZXZUcmVlLFxuICAgICAgICAgIG5leHRUcmVlLFxuICAgICAgICAgIC8vIHBhcmVudCBtYXkgaGF2ZSBjaGFuZ2VkIGlmIGl0J3MgaW4gYSB0ZWxlcG9ydFxuICAgICAgICAgIGhvc3RQYXJlbnROb2RlKHByZXZUcmVlLmVsKSxcbiAgICAgICAgICAvLyBhbmNob3IgbWF5IGhhdmUgY2hhbmdlZCBpZiBpdCdzIGluIGEgZnJhZ21lbnRcbiAgICAgICAgICBnZXROZXh0SG9zdE5vZGUocHJldlRyZWUpLFxuICAgICAgICAgIGluc3RhbmNlLFxuICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgIG5hbWVzcGFjZVxuICAgICAgICApO1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIGVuZE1lYXN1cmUoaW5zdGFuY2UsIGBwYXRjaGApO1xuICAgICAgICB9XG4gICAgICAgIG5leHQuZWwgPSBuZXh0VHJlZS5lbDtcbiAgICAgICAgaWYgKG9yaWdpbk5leHQgPT09IG51bGwpIHtcbiAgICAgICAgICB1cGRhdGVIT0NIb3N0RWwoaW5zdGFuY2UsIG5leHRUcmVlLmVsKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodSkge1xuICAgICAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdCh1LCBwYXJlbnRTdXNwZW5zZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHZub2RlSG9vayA9IG5leHQucHJvcHMgJiYgbmV4dC5wcm9wcy5vblZub2RlVXBkYXRlZCkge1xuICAgICAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdChcbiAgICAgICAgICAgICgpID0+IGludm9rZVZOb2RlSG9vayh2bm9kZUhvb2ssIHBhcmVudCwgbmV4dCwgdm5vZGUpLFxuICAgICAgICAgICAgcGFyZW50U3VzcGVuc2VcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykge1xuICAgICAgICAgIGRldnRvb2xzQ29tcG9uZW50VXBkYXRlZChpbnN0YW5jZSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICBwb3BXYXJuaW5nQ29udGV4dCgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcbiAgICBpbnN0YW5jZS5zY29wZS5vbigpO1xuICAgIGNvbnN0IGVmZmVjdCA9IGluc3RhbmNlLmVmZmVjdCA9IG5ldyBSZWFjdGl2ZUVmZmVjdChjb21wb25lbnRVcGRhdGVGbik7XG4gICAgaW5zdGFuY2Uuc2NvcGUub2ZmKCk7XG4gICAgY29uc3QgdXBkYXRlID0gaW5zdGFuY2UudXBkYXRlID0gZWZmZWN0LnJ1bi5iaW5kKGVmZmVjdCk7XG4gICAgY29uc3Qgam9iID0gaW5zdGFuY2Uuam9iID0gZWZmZWN0LnJ1bklmRGlydHkuYmluZChlZmZlY3QpO1xuICAgIGpvYi5pID0gaW5zdGFuY2U7XG4gICAgam9iLmlkID0gaW5zdGFuY2UudWlkO1xuICAgIGVmZmVjdC5zY2hlZHVsZXIgPSAoKSA9PiBxdWV1ZUpvYihqb2IpO1xuICAgIHRvZ2dsZVJlY3Vyc2UoaW5zdGFuY2UsIHRydWUpO1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICBlZmZlY3Qub25UcmFjayA9IGluc3RhbmNlLnJ0YyA/IChlKSA9PiBpbnZva2VBcnJheUZucyhpbnN0YW5jZS5ydGMsIGUpIDogdm9pZCAwO1xuICAgICAgZWZmZWN0Lm9uVHJpZ2dlciA9IGluc3RhbmNlLnJ0ZyA/IChlKSA9PiBpbnZva2VBcnJheUZucyhpbnN0YW5jZS5ydGcsIGUpIDogdm9pZCAwO1xuICAgIH1cbiAgICB1cGRhdGUoKTtcbiAgfTtcbiAgY29uc3QgdXBkYXRlQ29tcG9uZW50UHJlUmVuZGVyID0gKGluc3RhbmNlLCBuZXh0Vk5vZGUsIG9wdGltaXplZCkgPT4ge1xuICAgIG5leHRWTm9kZS5jb21wb25lbnQgPSBpbnN0YW5jZTtcbiAgICBjb25zdCBwcmV2UHJvcHMgPSBpbnN0YW5jZS52bm9kZS5wcm9wcztcbiAgICBpbnN0YW5jZS52bm9kZSA9IG5leHRWTm9kZTtcbiAgICBpbnN0YW5jZS5uZXh0ID0gbnVsbDtcbiAgICB1cGRhdGVQcm9wcyhpbnN0YW5jZSwgbmV4dFZOb2RlLnByb3BzLCBwcmV2UHJvcHMsIG9wdGltaXplZCk7XG4gICAgdXBkYXRlU2xvdHMoaW5zdGFuY2UsIG5leHRWTm9kZS5jaGlsZHJlbiwgb3B0aW1pemVkKTtcbiAgICBwYXVzZVRyYWNraW5nKCk7XG4gICAgZmx1c2hQcmVGbHVzaENicyhpbnN0YW5jZSk7XG4gICAgcmVzZXRUcmFja2luZygpO1xuICB9O1xuICBjb25zdCBwYXRjaENoaWxkcmVuID0gKG4xLCBuMiwgY29udGFpbmVyLCBhbmNob3IsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIG5hbWVzcGFjZSwgc2xvdFNjb3BlSWRzLCBvcHRpbWl6ZWQgPSBmYWxzZSkgPT4ge1xuICAgIGNvbnN0IGMxID0gbjEgJiYgbjEuY2hpbGRyZW47XG4gICAgY29uc3QgcHJldlNoYXBlRmxhZyA9IG4xID8gbjEuc2hhcGVGbGFnIDogMDtcbiAgICBjb25zdCBjMiA9IG4yLmNoaWxkcmVuO1xuICAgIGNvbnN0IHsgcGF0Y2hGbGFnLCBzaGFwZUZsYWcgfSA9IG4yO1xuICAgIGlmIChwYXRjaEZsYWcgPiAwKSB7XG4gICAgICBpZiAocGF0Y2hGbGFnICYgMTI4KSB7XG4gICAgICAgIHBhdGNoS2V5ZWRDaGlsZHJlbihcbiAgICAgICAgICBjMSxcbiAgICAgICAgICBjMixcbiAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgYW5jaG9yLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICApO1xuICAgICAgICByZXR1cm47XG4gICAgICB9IGVsc2UgaWYgKHBhdGNoRmxhZyAmIDI1Nikge1xuICAgICAgICBwYXRjaFVua2V5ZWRDaGlsZHJlbihcbiAgICAgICAgICBjMSxcbiAgICAgICAgICBjMixcbiAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgYW5jaG9yLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICApO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChzaGFwZUZsYWcgJiA4KSB7XG4gICAgICBpZiAocHJldlNoYXBlRmxhZyAmIDE2KSB7XG4gICAgICAgIHVubW91bnRDaGlsZHJlbihjMSwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSk7XG4gICAgICB9XG4gICAgICBpZiAoYzIgIT09IGMxKSB7XG4gICAgICAgIGhvc3RTZXRFbGVtZW50VGV4dChjb250YWluZXIsIGMyKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKHByZXZTaGFwZUZsYWcgJiAxNikge1xuICAgICAgICBpZiAoc2hhcGVGbGFnICYgMTYpIHtcbiAgICAgICAgICBwYXRjaEtleWVkQ2hpbGRyZW4oXG4gICAgICAgICAgICBjMSxcbiAgICAgICAgICAgIGMyLFxuICAgICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgICAgYW5jaG9yLFxuICAgICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgICApO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHVubW91bnRDaGlsZHJlbihjMSwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgdHJ1ZSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlmIChwcmV2U2hhcGVGbGFnICYgOCkge1xuICAgICAgICAgIGhvc3RTZXRFbGVtZW50VGV4dChjb250YWluZXIsIFwiXCIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzaGFwZUZsYWcgJiAxNikge1xuICAgICAgICAgIG1vdW50Q2hpbGRyZW4oXG4gICAgICAgICAgICBjMixcbiAgICAgICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgICAgIGFuY2hvcixcbiAgICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfTtcbiAgY29uc3QgcGF0Y2hVbmtleWVkQ2hpbGRyZW4gPSAoYzEsIGMyLCBjb250YWluZXIsIGFuY2hvciwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgbmFtZXNwYWNlLCBzbG90U2NvcGVJZHMsIG9wdGltaXplZCkgPT4ge1xuICAgIGMxID0gYzEgfHwgRU1QVFlfQVJSO1xuICAgIGMyID0gYzIgfHwgRU1QVFlfQVJSO1xuICAgIGNvbnN0IG9sZExlbmd0aCA9IGMxLmxlbmd0aDtcbiAgICBjb25zdCBuZXdMZW5ndGggPSBjMi5sZW5ndGg7XG4gICAgY29uc3QgY29tbW9uTGVuZ3RoID0gTWF0aC5taW4ob2xkTGVuZ3RoLCBuZXdMZW5ndGgpO1xuICAgIGxldCBpO1xuICAgIGZvciAoaSA9IDA7IGkgPCBjb21tb25MZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgbmV4dENoaWxkID0gYzJbaV0gPSBvcHRpbWl6ZWQgPyBjbG9uZUlmTW91bnRlZChjMltpXSkgOiBub3JtYWxpemVWTm9kZShjMltpXSk7XG4gICAgICBwYXRjaChcbiAgICAgICAgYzFbaV0sXG4gICAgICAgIG5leHRDaGlsZCxcbiAgICAgICAgY29udGFpbmVyLFxuICAgICAgICBudWxsLFxuICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgb3B0aW1pemVkXG4gICAgICApO1xuICAgIH1cbiAgICBpZiAob2xkTGVuZ3RoID4gbmV3TGVuZ3RoKSB7XG4gICAgICB1bm1vdW50Q2hpbGRyZW4oXG4gICAgICAgIGMxLFxuICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgIHBhcmVudFN1c3BlbnNlLFxuICAgICAgICB0cnVlLFxuICAgICAgICBmYWxzZSxcbiAgICAgICAgY29tbW9uTGVuZ3RoXG4gICAgICApO1xuICAgIH0gZWxzZSB7XG4gICAgICBtb3VudENoaWxkcmVuKFxuICAgICAgICBjMixcbiAgICAgICAgY29udGFpbmVyLFxuICAgICAgICBhbmNob3IsXG4gICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICBvcHRpbWl6ZWQsXG4gICAgICAgIGNvbW1vbkxlbmd0aFxuICAgICAgKTtcbiAgICB9XG4gIH07XG4gIGNvbnN0IHBhdGNoS2V5ZWRDaGlsZHJlbiA9IChjMSwgYzIsIGNvbnRhaW5lciwgcGFyZW50QW5jaG9yLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCBuYW1lc3BhY2UsIHNsb3RTY29wZUlkcywgb3B0aW1pemVkKSA9PiB7XG4gICAgbGV0IGkgPSAwO1xuICAgIGNvbnN0IGwyID0gYzIubGVuZ3RoO1xuICAgIGxldCBlMSA9IGMxLmxlbmd0aCAtIDE7XG4gICAgbGV0IGUyID0gbDIgLSAxO1xuICAgIHdoaWxlIChpIDw9IGUxICYmIGkgPD0gZTIpIHtcbiAgICAgIGNvbnN0IG4xID0gYzFbaV07XG4gICAgICBjb25zdCBuMiA9IGMyW2ldID0gb3B0aW1pemVkID8gY2xvbmVJZk1vdW50ZWQoYzJbaV0pIDogbm9ybWFsaXplVk5vZGUoYzJbaV0pO1xuICAgICAgaWYgKGlzU2FtZVZOb2RlVHlwZShuMSwgbjIpKSB7XG4gICAgICAgIHBhdGNoKFxuICAgICAgICAgIG4xLFxuICAgICAgICAgIG4yLFxuICAgICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgICBudWxsLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBpKys7XG4gICAgfVxuICAgIHdoaWxlIChpIDw9IGUxICYmIGkgPD0gZTIpIHtcbiAgICAgIGNvbnN0IG4xID0gYzFbZTFdO1xuICAgICAgY29uc3QgbjIgPSBjMltlMl0gPSBvcHRpbWl6ZWQgPyBjbG9uZUlmTW91bnRlZChjMltlMl0pIDogbm9ybWFsaXplVk5vZGUoYzJbZTJdKTtcbiAgICAgIGlmIChpc1NhbWVWTm9kZVR5cGUobjEsIG4yKSkge1xuICAgICAgICBwYXRjaChcbiAgICAgICAgICBuMSxcbiAgICAgICAgICBuMixcbiAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgbnVsbCxcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgZTEtLTtcbiAgICAgIGUyLS07XG4gICAgfVxuICAgIGlmIChpID4gZTEpIHtcbiAgICAgIGlmIChpIDw9IGUyKSB7XG4gICAgICAgIGNvbnN0IG5leHRQb3MgPSBlMiArIDE7XG4gICAgICAgIGNvbnN0IGFuY2hvciA9IG5leHRQb3MgPCBsMiA/IGMyW25leHRQb3NdLmVsIDogcGFyZW50QW5jaG9yO1xuICAgICAgICB3aGlsZSAoaSA8PSBlMikge1xuICAgICAgICAgIHBhdGNoKFxuICAgICAgICAgICAgbnVsbCxcbiAgICAgICAgICAgIGMyW2ldID0gb3B0aW1pemVkID8gY2xvbmVJZk1vdW50ZWQoYzJbaV0pIDogbm9ybWFsaXplVk5vZGUoYzJbaV0pLFxuICAgICAgICAgICAgY29udGFpbmVyLFxuICAgICAgICAgICAgYW5jaG9yLFxuICAgICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgICApO1xuICAgICAgICAgIGkrKztcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoaSA+IGUyKSB7XG4gICAgICB3aGlsZSAoaSA8PSBlMSkge1xuICAgICAgICB1bm1vdW50KGMxW2ldLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCB0cnVlKTtcbiAgICAgICAgaSsrO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBzMSA9IGk7XG4gICAgICBjb25zdCBzMiA9IGk7XG4gICAgICBjb25zdCBrZXlUb05ld0luZGV4TWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgICAgIGZvciAoaSA9IHMyOyBpIDw9IGUyOyBpKyspIHtcbiAgICAgICAgY29uc3QgbmV4dENoaWxkID0gYzJbaV0gPSBvcHRpbWl6ZWQgPyBjbG9uZUlmTW91bnRlZChjMltpXSkgOiBub3JtYWxpemVWTm9kZShjMltpXSk7XG4gICAgICAgIGlmIChuZXh0Q2hpbGQua2V5ICE9IG51bGwpIHtcbiAgICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBrZXlUb05ld0luZGV4TWFwLmhhcyhuZXh0Q2hpbGQua2V5KSkge1xuICAgICAgICAgICAgd2FybiQxKFxuICAgICAgICAgICAgICBgRHVwbGljYXRlIGtleXMgZm91bmQgZHVyaW5nIHVwZGF0ZTpgLFxuICAgICAgICAgICAgICBKU09OLnN0cmluZ2lmeShuZXh0Q2hpbGQua2V5KSxcbiAgICAgICAgICAgICAgYE1ha2Ugc3VyZSBrZXlzIGFyZSB1bmlxdWUuYFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgICAga2V5VG9OZXdJbmRleE1hcC5zZXQobmV4dENoaWxkLmtleSwgaSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGxldCBqO1xuICAgICAgbGV0IHBhdGNoZWQgPSAwO1xuICAgICAgY29uc3QgdG9CZVBhdGNoZWQgPSBlMiAtIHMyICsgMTtcbiAgICAgIGxldCBtb3ZlZCA9IGZhbHNlO1xuICAgICAgbGV0IG1heE5ld0luZGV4U29GYXIgPSAwO1xuICAgICAgY29uc3QgbmV3SW5kZXhUb09sZEluZGV4TWFwID0gbmV3IEFycmF5KHRvQmVQYXRjaGVkKTtcbiAgICAgIGZvciAoaSA9IDA7IGkgPCB0b0JlUGF0Y2hlZDsgaSsrKSBuZXdJbmRleFRvT2xkSW5kZXhNYXBbaV0gPSAwO1xuICAgICAgZm9yIChpID0gczE7IGkgPD0gZTE7IGkrKykge1xuICAgICAgICBjb25zdCBwcmV2Q2hpbGQgPSBjMVtpXTtcbiAgICAgICAgaWYgKHBhdGNoZWQgPj0gdG9CZVBhdGNoZWQpIHtcbiAgICAgICAgICB1bm1vdW50KHByZXZDaGlsZCwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgdHJ1ZSk7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IG5ld0luZGV4O1xuICAgICAgICBpZiAocHJldkNoaWxkLmtleSAhPSBudWxsKSB7XG4gICAgICAgICAgbmV3SW5kZXggPSBrZXlUb05ld0luZGV4TWFwLmdldChwcmV2Q2hpbGQua2V5KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBmb3IgKGogPSBzMjsgaiA8PSBlMjsgaisrKSB7XG4gICAgICAgICAgICBpZiAobmV3SW5kZXhUb09sZEluZGV4TWFwW2ogLSBzMl0gPT09IDAgJiYgaXNTYW1lVk5vZGVUeXBlKHByZXZDaGlsZCwgYzJbal0pKSB7XG4gICAgICAgICAgICAgIG5ld0luZGV4ID0gajtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChuZXdJbmRleCA9PT0gdm9pZCAwKSB7XG4gICAgICAgICAgdW5tb3VudChwcmV2Q2hpbGQsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIHRydWUpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG5ld0luZGV4VG9PbGRJbmRleE1hcFtuZXdJbmRleCAtIHMyXSA9IGkgKyAxO1xuICAgICAgICAgIGlmIChuZXdJbmRleCA+PSBtYXhOZXdJbmRleFNvRmFyKSB7XG4gICAgICAgICAgICBtYXhOZXdJbmRleFNvRmFyID0gbmV3SW5kZXg7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG1vdmVkID0gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcGF0Y2goXG4gICAgICAgICAgICBwcmV2Q2hpbGQsXG4gICAgICAgICAgICBjMltuZXdJbmRleF0sXG4gICAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgICBudWxsLFxuICAgICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgICBvcHRpbWl6ZWRcbiAgICAgICAgICApO1xuICAgICAgICAgIHBhdGNoZWQrKztcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgY29uc3QgaW5jcmVhc2luZ05ld0luZGV4U2VxdWVuY2UgPSBtb3ZlZCA/IGdldFNlcXVlbmNlKG5ld0luZGV4VG9PbGRJbmRleE1hcCkgOiBFTVBUWV9BUlI7XG4gICAgICBqID0gaW5jcmVhc2luZ05ld0luZGV4U2VxdWVuY2UubGVuZ3RoIC0gMTtcbiAgICAgIGZvciAoaSA9IHRvQmVQYXRjaGVkIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgICAgY29uc3QgbmV4dEluZGV4ID0gczIgKyBpO1xuICAgICAgICBjb25zdCBuZXh0Q2hpbGQgPSBjMltuZXh0SW5kZXhdO1xuICAgICAgICBjb25zdCBhbmNob3JWTm9kZSA9IGMyW25leHRJbmRleCArIDFdO1xuICAgICAgICBjb25zdCBhbmNob3IgPSBuZXh0SW5kZXggKyAxIDwgbDIgPyAoXG4gICAgICAgICAgLy8gIzEzNTU5LCAjMTQxNzMgZmFsbGJhY2sgdG8gZWwgcGxhY2Vob2xkZXIgZm9yIHVucmVzb2x2ZWQgYXN5bmMgY29tcG9uZW50XG4gICAgICAgICAgYW5jaG9yVk5vZGUuZWwgfHwgcmVzb2x2ZUFzeW5jQ29tcG9uZW50UGxhY2Vob2xkZXIoYW5jaG9yVk5vZGUpXG4gICAgICAgICkgOiBwYXJlbnRBbmNob3I7XG4gICAgICAgIGlmIChuZXdJbmRleFRvT2xkSW5kZXhNYXBbaV0gPT09IDApIHtcbiAgICAgICAgICBwYXRjaChcbiAgICAgICAgICAgIG51bGwsXG4gICAgICAgICAgICBuZXh0Q2hpbGQsXG4gICAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgICBhbmNob3IsXG4gICAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICAgICk7XG4gICAgICAgIH0gZWxzZSBpZiAobW92ZWQpIHtcbiAgICAgICAgICBpZiAoaiA8IDAgfHwgaSAhPT0gaW5jcmVhc2luZ05ld0luZGV4U2VxdWVuY2Vbal0pIHtcbiAgICAgICAgICAgIG1vdmUobmV4dENoaWxkLCBjb250YWluZXIsIGFuY2hvciwgMik7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGotLTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH07XG4gIGNvbnN0IG1vdmUgPSAodm5vZGUsIGNvbnRhaW5lciwgYW5jaG9yLCBtb3ZlVHlwZSwgcGFyZW50U3VzcGVuc2UgPSBudWxsKSA9PiB7XG4gICAgY29uc3QgeyBlbCwgdHlwZSwgdHJhbnNpdGlvbiwgY2hpbGRyZW4sIHNoYXBlRmxhZyB9ID0gdm5vZGU7XG4gICAgaWYgKHNoYXBlRmxhZyAmIDYpIHtcbiAgICAgIG1vdmUodm5vZGUuY29tcG9uZW50LnN1YlRyZWUsIGNvbnRhaW5lciwgYW5jaG9yLCBtb3ZlVHlwZSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChzaGFwZUZsYWcgJiAxMjgpIHtcbiAgICAgIHZub2RlLnN1c3BlbnNlLm1vdmUoY29udGFpbmVyLCBhbmNob3IsIG1vdmVUeXBlKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHNoYXBlRmxhZyAmIDY0KSB7XG4gICAgICB0eXBlLm1vdmUodm5vZGUsIGNvbnRhaW5lciwgYW5jaG9yLCBpbnRlcm5hbHMpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAodHlwZSA9PT0gRnJhZ21lbnQpIHtcbiAgICAgIGhvc3RJbnNlcnQoZWwsIGNvbnRhaW5lciwgYW5jaG9yKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY2hpbGRyZW4ubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgbW92ZShjaGlsZHJlbltpXSwgY29udGFpbmVyLCBhbmNob3IsIG1vdmVUeXBlKTtcbiAgICAgIH1cbiAgICAgIGhvc3RJbnNlcnQodm5vZGUuYW5jaG9yLCBjb250YWluZXIsIGFuY2hvcik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICh0eXBlID09PSBTdGF0aWMpIHtcbiAgICAgIG1vdmVTdGF0aWNOb2RlKHZub2RlLCBjb250YWluZXIsIGFuY2hvcik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IG5lZWRUcmFuc2l0aW9uMiA9IG1vdmVUeXBlICE9PSAyICYmIHNoYXBlRmxhZyAmIDEgJiYgdHJhbnNpdGlvbjtcbiAgICBpZiAobmVlZFRyYW5zaXRpb24yKSB7XG4gICAgICBpZiAobW92ZVR5cGUgPT09IDApIHtcbiAgICAgICAgaWYgKHRyYW5zaXRpb24ucGVyc2lzdGVkICYmICFlbFtsZWF2ZUNiS2V5XSkge1xuICAgICAgICAgIGhvc3RJbnNlcnQoZWwsIGNvbnRhaW5lciwgYW5jaG9yKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0cmFuc2l0aW9uLmJlZm9yZUVudGVyKGVsKTtcbiAgICAgICAgICBob3N0SW5zZXJ0KGVsLCBjb250YWluZXIsIGFuY2hvcik7XG4gICAgICAgICAgcXVldWVQb3N0UmVuZGVyRWZmZWN0KCgpID0+IHRyYW5zaXRpb24uZW50ZXIoZWwpLCBwYXJlbnRTdXNwZW5zZSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnN0IHsgbGVhdmUsIGRlbGF5TGVhdmUsIGFmdGVyTGVhdmUgfSA9IHRyYW5zaXRpb247XG4gICAgICAgIGNvbnN0IHJlbW92ZTIgPSAoKSA9PiB7XG4gICAgICAgICAgaWYgKHZub2RlLmN0eC5pc1VubW91bnRlZCkge1xuICAgICAgICAgICAgaG9zdFJlbW92ZShlbCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGhvc3RJbnNlcnQoZWwsIGNvbnRhaW5lciwgYW5jaG9yKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGNvbnN0IHBlcmZvcm1MZWF2ZSA9ICgpID0+IHtcbiAgICAgICAgICBjb25zdCB3YXNMZWF2aW5nID0gZWwuX2lzTGVhdmluZyB8fCAhIWVsW2xlYXZlQ2JLZXldO1xuICAgICAgICAgIGlmIChlbC5faXNMZWF2aW5nKSB7XG4gICAgICAgICAgICBlbFtsZWF2ZUNiS2V5XShcbiAgICAgICAgICAgICAgdHJ1ZVxuICAgICAgICAgICAgICAvKiBjYW5jZWxsZWQgKi9cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmICh0cmFuc2l0aW9uLnBlcnNpc3RlZCAmJiAhd2FzTGVhdmluZykge1xuICAgICAgICAgICAgcmVtb3ZlMigpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBsZWF2ZShlbCwgKCkgPT4ge1xuICAgICAgICAgICAgICByZW1vdmUyKCk7XG4gICAgICAgICAgICAgIGFmdGVyTGVhdmUgJiYgYWZ0ZXJMZWF2ZSgpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBpZiAoZGVsYXlMZWF2ZSkge1xuICAgICAgICAgIGRlbGF5TGVhdmUoZWwsIHJlbW92ZTIsIHBlcmZvcm1MZWF2ZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcGVyZm9ybUxlYXZlKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgaG9zdEluc2VydChlbCwgY29udGFpbmVyLCBhbmNob3IpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgdW5tb3VudCA9ICh2bm9kZSwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgZG9SZW1vdmUgPSBmYWxzZSwgb3B0aW1pemVkID0gZmFsc2UpID0+IHtcbiAgICBjb25zdCB7XG4gICAgICB0eXBlLFxuICAgICAgcHJvcHMsXG4gICAgICByZWYsXG4gICAgICBjaGlsZHJlbixcbiAgICAgIGR5bmFtaWNDaGlsZHJlbixcbiAgICAgIHNoYXBlRmxhZyxcbiAgICAgIHBhdGNoRmxhZyxcbiAgICAgIGRpcnMsXG4gICAgICBjYWNoZUluZGV4LFxuICAgICAgbWVtb1xuICAgIH0gPSB2bm9kZTtcbiAgICBpZiAocGF0Y2hGbGFnID09PSAtMikge1xuICAgICAgb3B0aW1pemVkID0gZmFsc2U7XG4gICAgfVxuICAgIGlmIChyZWYgIT0gbnVsbCkge1xuICAgICAgcGF1c2VUcmFja2luZygpO1xuICAgICAgc2V0UmVmKHJlZiwgbnVsbCwgcGFyZW50U3VzcGVuc2UsIHZub2RlLCB0cnVlKTtcbiAgICAgIHJlc2V0VHJhY2tpbmcoKTtcbiAgICB9XG4gICAgaWYgKGNhY2hlSW5kZXggIT0gbnVsbCkge1xuICAgICAgcGFyZW50Q29tcG9uZW50LnJlbmRlckNhY2hlW2NhY2hlSW5kZXhdID0gdm9pZCAwO1xuICAgIH1cbiAgICBpZiAoc2hhcGVGbGFnICYgMjU2KSB7XG4gICAgICBwYXJlbnRDb21wb25lbnQuY3R4LmRlYWN0aXZhdGUodm5vZGUpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBzaG91bGRJbnZva2VEaXJzID0gc2hhcGVGbGFnICYgMSAmJiBkaXJzO1xuICAgIGNvbnN0IHNob3VsZEludm9rZVZub2RlSG9vayA9ICFpc0FzeW5jV3JhcHBlcih2bm9kZSk7XG4gICAgbGV0IHZub2RlSG9vaztcbiAgICBpZiAoc2hvdWxkSW52b2tlVm5vZGVIb29rICYmICh2bm9kZUhvb2sgPSBwcm9wcyAmJiBwcm9wcy5vblZub2RlQmVmb3JlVW5tb3VudCkpIHtcbiAgICAgIGludm9rZVZOb2RlSG9vayh2bm9kZUhvb2ssIHBhcmVudENvbXBvbmVudCwgdm5vZGUpO1xuICAgIH1cbiAgICBpZiAoc2hhcGVGbGFnICYgNikge1xuICAgICAgdW5tb3VudENvbXBvbmVudCh2bm9kZS5jb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCBkb1JlbW92ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChzaGFwZUZsYWcgJiAxMjgpIHtcbiAgICAgICAgdm5vZGUuc3VzcGVuc2UudW5tb3VudChwYXJlbnRTdXNwZW5zZSwgZG9SZW1vdmUpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoc2hvdWxkSW52b2tlRGlycykge1xuICAgICAgICBpbnZva2VEaXJlY3RpdmVIb29rKHZub2RlLCBudWxsLCBwYXJlbnRDb21wb25lbnQsIFwiYmVmb3JlVW5tb3VudFwiKTtcbiAgICAgIH1cbiAgICAgIGlmIChzaGFwZUZsYWcgJiA2NCkge1xuICAgICAgICB2bm9kZS50eXBlLnJlbW92ZShcbiAgICAgICAgICB2bm9kZSxcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgcGFyZW50U3VzcGVuc2UsXG4gICAgICAgICAgaW50ZXJuYWxzLFxuICAgICAgICAgIGRvUmVtb3ZlXG4gICAgICAgICk7XG4gICAgICB9IGVsc2UgaWYgKGR5bmFtaWNDaGlsZHJlbiAmJiAvLyAjNTE1NFxuICAgICAgLy8gd2hlbiB2LW9uY2UgaXMgdXNlZCBpbnNpZGUgYSBibG9jaywgc2V0QmxvY2tUcmFja2luZygtMSkgbWFya3MgdGhlXG4gICAgICAvLyBwYXJlbnQgYmxvY2sgd2l0aCBoYXNPbmNlOiB0cnVlXG4gICAgICAvLyBzbyB0aGF0IGl0IGRvZXNuJ3QgdGFrZSB0aGUgZmFzdCBwYXRoIGR1cmluZyB1bm1vdW50IC0gb3RoZXJ3aXNlXG4gICAgICAvLyBjb21wb25lbnRzIG5lc3RlZCBpbiB2LW9uY2UgYXJlIG5ldmVyIHVubW91bnRlZC5cbiAgICAgICFkeW5hbWljQ2hpbGRyZW4uaGFzT25jZSAmJiAvLyAjMTE1MzogZmFzdCBwYXRoIHNob3VsZCBub3QgYmUgdGFrZW4gZm9yIG5vbi1zdGFibGUgKHYtZm9yKSBmcmFnbWVudHNcbiAgICAgICh0eXBlICE9PSBGcmFnbWVudCB8fCBwYXRjaEZsYWcgPiAwICYmIHBhdGNoRmxhZyAmIDY0KSkge1xuICAgICAgICB1bm1vdW50Q2hpbGRyZW4oXG4gICAgICAgICAgZHluYW1pY0NoaWxkcmVuLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgICBmYWxzZSxcbiAgICAgICAgICB0cnVlXG4gICAgICAgICk7XG4gICAgICB9IGVsc2UgaWYgKHR5cGUgPT09IEZyYWdtZW50ICYmIHBhdGNoRmxhZyAmICgxMjggfCAyNTYpIHx8ICFvcHRpbWl6ZWQgJiYgc2hhcGVGbGFnICYgMTYpIHtcbiAgICAgICAgdW5tb3VudENoaWxkcmVuKGNoaWxkcmVuLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlKTtcbiAgICAgIH1cbiAgICAgIGlmIChkb1JlbW92ZSkge1xuICAgICAgICByZW1vdmUodm5vZGUpO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBzaG91bGRJbnZhbGlkYXRlTWVtbyA9IG1lbW8gIT0gbnVsbCAmJiBjYWNoZUluZGV4ID09IG51bGw7XG4gICAgaWYgKHNob3VsZEludm9rZVZub2RlSG9vayAmJiAodm5vZGVIb29rID0gcHJvcHMgJiYgcHJvcHMub25Wbm9kZVVubW91bnRlZCkgfHwgc2hvdWxkSW52b2tlRGlycyB8fCBzaG91bGRJbnZhbGlkYXRlTWVtbykge1xuICAgICAgcXVldWVQb3N0UmVuZGVyRWZmZWN0KCgpID0+IHtcbiAgICAgICAgdm5vZGVIb29rICYmIGludm9rZVZOb2RlSG9vayh2bm9kZUhvb2ssIHBhcmVudENvbXBvbmVudCwgdm5vZGUpO1xuICAgICAgICBzaG91bGRJbnZva2VEaXJzICYmIGludm9rZURpcmVjdGl2ZUhvb2sodm5vZGUsIG51bGwsIHBhcmVudENvbXBvbmVudCwgXCJ1bm1vdW50ZWRcIik7XG4gICAgICAgIGlmIChzaG91bGRJbnZhbGlkYXRlTWVtbykge1xuICAgICAgICAgIHZub2RlLmVsID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgfSwgcGFyZW50U3VzcGVuc2UpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgcmVtb3ZlID0gKHZub2RlKSA9PiB7XG4gICAgY29uc3QgeyB0eXBlLCBlbCwgYW5jaG9yLCB0cmFuc2l0aW9uIH0gPSB2bm9kZTtcbiAgICBpZiAodHlwZSA9PT0gRnJhZ21lbnQpIHtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHZub2RlLnBhdGNoRmxhZyA+IDAgJiYgdm5vZGUucGF0Y2hGbGFnICYgMjA0OCAmJiB0cmFuc2l0aW9uICYmICF0cmFuc2l0aW9uLnBlcnNpc3RlZCkge1xuICAgICAgICB2bm9kZS5jaGlsZHJlbi5mb3JFYWNoKChjaGlsZCkgPT4ge1xuICAgICAgICAgIGlmIChjaGlsZC50eXBlID09PSBDb21tZW50KSB7XG4gICAgICAgICAgICBob3N0UmVtb3ZlKGNoaWxkLmVsKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVtb3ZlKGNoaWxkKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVtb3ZlRnJhZ21lbnQoZWwsIGFuY2hvcik7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICh0eXBlID09PSBTdGF0aWMpIHtcbiAgICAgIHJlbW92ZVN0YXRpY05vZGUodm5vZGUpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBwZXJmb3JtUmVtb3ZlID0gKCkgPT4ge1xuICAgICAgaG9zdFJlbW92ZShlbCk7XG4gICAgICBpZiAodHJhbnNpdGlvbiAmJiAhdHJhbnNpdGlvbi5wZXJzaXN0ZWQgJiYgdHJhbnNpdGlvbi5hZnRlckxlYXZlKSB7XG4gICAgICAgIHRyYW5zaXRpb24uYWZ0ZXJMZWF2ZSgpO1xuICAgICAgfVxuICAgIH07XG4gICAgaWYgKHZub2RlLnNoYXBlRmxhZyAmIDEgJiYgdHJhbnNpdGlvbiAmJiAhdHJhbnNpdGlvbi5wZXJzaXN0ZWQpIHtcbiAgICAgIGNvbnN0IHsgbGVhdmUsIGRlbGF5TGVhdmUgfSA9IHRyYW5zaXRpb247XG4gICAgICBjb25zdCBwZXJmb3JtTGVhdmUgPSAoKSA9PiBsZWF2ZShlbCwgcGVyZm9ybVJlbW92ZSk7XG4gICAgICBpZiAoZGVsYXlMZWF2ZSkge1xuICAgICAgICBkZWxheUxlYXZlKHZub2RlLmVsLCBwZXJmb3JtUmVtb3ZlLCBwZXJmb3JtTGVhdmUpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcGVyZm9ybUxlYXZlKCk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHBlcmZvcm1SZW1vdmUoKTtcbiAgICB9XG4gIH07XG4gIGNvbnN0IHJlbW92ZUZyYWdtZW50ID0gKGN1ciwgZW5kKSA9PiB7XG4gICAgbGV0IG5leHQ7XG4gICAgd2hpbGUgKGN1ciAhPT0gZW5kKSB7XG4gICAgICBuZXh0ID0gaG9zdE5leHRTaWJsaW5nKGN1cik7XG4gICAgICBob3N0UmVtb3ZlKGN1cik7XG4gICAgICBjdXIgPSBuZXh0O1xuICAgIH1cbiAgICBob3N0UmVtb3ZlKGVuZCk7XG4gIH07XG4gIGNvbnN0IHVubW91bnRDb21wb25lbnQgPSAoaW5zdGFuY2UsIHBhcmVudFN1c3BlbnNlLCBkb1JlbW92ZSkgPT4ge1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGluc3RhbmNlLnR5cGUuX19obXJJZCkge1xuICAgICAgdW5yZWdpc3RlckhNUihpbnN0YW5jZSk7XG4gICAgfVxuICAgIGNvbnN0IHsgYnVtLCBzY29wZSwgam9iLCBzdWJUcmVlLCB1bSwgbSwgYSB9ID0gaW5zdGFuY2U7XG4gICAgaW52YWxpZGF0ZU1vdW50KG0pO1xuICAgIGludmFsaWRhdGVNb3VudChhKTtcbiAgICBpZiAoYnVtKSB7XG4gICAgICBpbnZva2VBcnJheUZucyhidW0pO1xuICAgIH1cbiAgICBzY29wZS5zdG9wKCk7XG4gICAgaWYgKGpvYikge1xuICAgICAgam9iLmZsYWdzIHw9IDg7XG4gICAgICB1bm1vdW50KHN1YlRyZWUsIGluc3RhbmNlLCBwYXJlbnRTdXNwZW5zZSwgZG9SZW1vdmUpO1xuICAgIH1cbiAgICBpZiAodW0pIHtcbiAgICAgIHF1ZXVlUG9zdFJlbmRlckVmZmVjdCh1bSwgcGFyZW50U3VzcGVuc2UpO1xuICAgIH1cbiAgICBxdWV1ZVBvc3RSZW5kZXJFZmZlY3QoKCkgPT4ge1xuICAgICAgaW5zdGFuY2UuaXNVbm1vdW50ZWQgPSB0cnVlO1xuICAgIH0sIHBhcmVudFN1c3BlbnNlKTtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCBfX1ZVRV9QUk9EX0RFVlRPT0xTX18pIHtcbiAgICAgIGRldnRvb2xzQ29tcG9uZW50UmVtb3ZlZChpbnN0YW5jZSk7XG4gICAgfVxuICB9O1xuICBjb25zdCB1bm1vdW50Q2hpbGRyZW4gPSAoY2hpbGRyZW4sIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIGRvUmVtb3ZlID0gZmFsc2UsIG9wdGltaXplZCA9IGZhbHNlLCBzdGFydCA9IDApID0+IHtcbiAgICBmb3IgKGxldCBpID0gc3RhcnQ7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgICAgdW5tb3VudChjaGlsZHJlbltpXSwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgZG9SZW1vdmUsIG9wdGltaXplZCk7XG4gICAgfVxuICB9O1xuICBjb25zdCBnZXROZXh0SG9zdE5vZGUgPSAodm5vZGUpID0+IHtcbiAgICBpZiAodm5vZGUuc2hhcGVGbGFnICYgNikge1xuICAgICAgcmV0dXJuIGdldE5leHRIb3N0Tm9kZSh2bm9kZS5jb21wb25lbnQuc3ViVHJlZSk7XG4gICAgfVxuICAgIGlmICh2bm9kZS5zaGFwZUZsYWcgJiAxMjgpIHtcbiAgICAgIHJldHVybiB2bm9kZS5zdXNwZW5zZS5uZXh0KCk7XG4gICAgfVxuICAgIGNvbnN0IGVsID0gaG9zdE5leHRTaWJsaW5nKHZub2RlLmFuY2hvciB8fCB2bm9kZS5lbCk7XG4gICAgY29uc3QgdGVsZXBvcnRFbmQgPSBlbCAmJiBlbFtUZWxlcG9ydEVuZEtleV07XG4gICAgcmV0dXJuIHRlbGVwb3J0RW5kID8gaG9zdE5leHRTaWJsaW5nKHRlbGVwb3J0RW5kKSA6IGVsO1xuICB9O1xuICBsZXQgaXNGbHVzaGluZyA9IGZhbHNlO1xuICBjb25zdCByZW5kZXIgPSAodm5vZGUsIGNvbnRhaW5lciwgbmFtZXNwYWNlKSA9PiB7XG4gICAgbGV0IGluc3RhbmNlO1xuICAgIGlmICh2bm9kZSA9PSBudWxsKSB7XG4gICAgICBpZiAoY29udGFpbmVyLl92bm9kZSkge1xuICAgICAgICB1bm1vdW50KGNvbnRhaW5lci5fdm5vZGUsIG51bGwsIG51bGwsIHRydWUpO1xuICAgICAgICBpbnN0YW5jZSA9IGNvbnRhaW5lci5fdm5vZGUuY29tcG9uZW50O1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBwYXRjaChcbiAgICAgICAgY29udGFpbmVyLl92bm9kZSB8fCBudWxsLFxuICAgICAgICB2bm9kZSxcbiAgICAgICAgY29udGFpbmVyLFxuICAgICAgICBudWxsLFxuICAgICAgICBudWxsLFxuICAgICAgICBudWxsLFxuICAgICAgICBuYW1lc3BhY2VcbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnRhaW5lci5fdm5vZGUgPSB2bm9kZTtcbiAgICBpZiAoIWlzRmx1c2hpbmcpIHtcbiAgICAgIGlzRmx1c2hpbmcgPSB0cnVlO1xuICAgICAgZmx1c2hQcmVGbHVzaENicyhpbnN0YW5jZSk7XG4gICAgICBmbHVzaFBvc3RGbHVzaENicygpO1xuICAgICAgaXNGbHVzaGluZyA9IGZhbHNlO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgaW50ZXJuYWxzID0ge1xuICAgIHA6IHBhdGNoLFxuICAgIHVtOiB1bm1vdW50LFxuICAgIG06IG1vdmUsXG4gICAgcjogcmVtb3ZlLFxuICAgIG10OiBtb3VudENvbXBvbmVudCxcbiAgICBtYzogbW91bnRDaGlsZHJlbixcbiAgICBwYzogcGF0Y2hDaGlsZHJlbixcbiAgICBwYmM6IHBhdGNoQmxvY2tDaGlsZHJlbixcbiAgICBuOiBnZXROZXh0SG9zdE5vZGUsXG4gICAgbzogb3B0aW9uc1xuICB9O1xuICBsZXQgaHlkcmF0ZTtcbiAgbGV0IGh5ZHJhdGVOb2RlO1xuICBpZiAoY3JlYXRlSHlkcmF0aW9uRm5zKSB7XG4gICAgW2h5ZHJhdGUsIGh5ZHJhdGVOb2RlXSA9IGNyZWF0ZUh5ZHJhdGlvbkZucyhcbiAgICAgIGludGVybmFsc1xuICAgICk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICByZW5kZXIsXG4gICAgaHlkcmF0ZSxcbiAgICBjcmVhdGVBcHA6IGNyZWF0ZUFwcEFQSShyZW5kZXIsIGh5ZHJhdGUpXG4gIH07XG59XG5mdW5jdGlvbiByZXNvbHZlQ2hpbGRyZW5OYW1lc3BhY2UoeyB0eXBlLCBwcm9wcyB9LCBjdXJyZW50TmFtZXNwYWNlKSB7XG4gIHJldHVybiBjdXJyZW50TmFtZXNwYWNlID09PSBcInN2Z1wiICYmIHR5cGUgPT09IFwiZm9yZWlnbk9iamVjdFwiIHx8IGN1cnJlbnROYW1lc3BhY2UgPT09IFwibWF0aG1sXCIgJiYgdHlwZSA9PT0gXCJhbm5vdGF0aW9uLXhtbFwiICYmIHByb3BzICYmIHByb3BzLmVuY29kaW5nICYmIHByb3BzLmVuY29kaW5nLmluY2x1ZGVzKFwiaHRtbFwiKSA/IHZvaWQgMCA6IGN1cnJlbnROYW1lc3BhY2U7XG59XG5mdW5jdGlvbiB0b2dnbGVSZWN1cnNlKHsgZWZmZWN0LCBqb2IgfSwgYWxsb3dlZCkge1xuICBpZiAoYWxsb3dlZCkge1xuICAgIGVmZmVjdC5mbGFncyB8PSAzMjtcbiAgICBqb2IuZmxhZ3MgfD0gNDtcbiAgfSBlbHNlIHtcbiAgICBlZmZlY3QuZmxhZ3MgJj0gLTMzO1xuICAgIGpvYi5mbGFncyAmPSAtNTtcbiAgfVxufVxuZnVuY3Rpb24gbmVlZFRyYW5zaXRpb24ocGFyZW50U3VzcGVuc2UsIHRyYW5zaXRpb24pIHtcbiAgcmV0dXJuICghcGFyZW50U3VzcGVuc2UgfHwgcGFyZW50U3VzcGVuc2UgJiYgIXBhcmVudFN1c3BlbnNlLnBlbmRpbmdCcmFuY2gpICYmIHRyYW5zaXRpb24gJiYgIXRyYW5zaXRpb24ucGVyc2lzdGVkO1xufVxuZnVuY3Rpb24gdHJhdmVyc2VTdGF0aWNDaGlsZHJlbihuMSwgbjIsIHNoYWxsb3cgPSBmYWxzZSkge1xuICBjb25zdCBjaDEgPSBuMS5jaGlsZHJlbjtcbiAgY29uc3QgY2gyID0gbjIuY2hpbGRyZW47XG4gIGlmIChpc0FycmF5KGNoMSkgJiYgaXNBcnJheShjaDIpKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjaDEubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGMxID0gY2gxW2ldO1xuICAgICAgbGV0IGMyID0gY2gyW2ldO1xuICAgICAgaWYgKGMyLnNoYXBlRmxhZyAmIDEgJiYgIWMyLmR5bmFtaWNDaGlsZHJlbikge1xuICAgICAgICBpZiAoYzIucGF0Y2hGbGFnIDw9IDAgfHwgYzIucGF0Y2hGbGFnID09PSAzMikge1xuICAgICAgICAgIGMyID0gY2gyW2ldID0gY2xvbmVJZk1vdW50ZWQoY2gyW2ldKTtcbiAgICAgICAgICBjMi5lbCA9IGMxLmVsO1xuICAgICAgICB9XG4gICAgICAgIGlmICghc2hhbGxvdyAmJiBjMi5wYXRjaEZsYWcgIT09IC0yKVxuICAgICAgICAgIHRyYXZlcnNlU3RhdGljQ2hpbGRyZW4oYzEsIGMyKTtcbiAgICAgIH1cbiAgICAgIGlmIChjMi50eXBlID09PSBUZXh0KSB7XG4gICAgICAgIGlmIChjMi5wYXRjaEZsYWcgPT09IC0xKSB7XG4gICAgICAgICAgYzIgPSBjaDJbaV0gPSBjbG9uZUlmTW91bnRlZChjMik7XG4gICAgICAgIH1cbiAgICAgICAgYzIuZWwgPSBjMS5lbDtcbiAgICAgIH1cbiAgICAgIGlmIChjMi50eXBlID09PSBDb21tZW50ICYmICFjMi5lbCkge1xuICAgICAgICBjMi5lbCA9IGMxLmVsO1xuICAgICAgfVxuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgYzIuZWwgJiYgKGMyLmVsLl9fdm5vZGUgPSBjMik7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBnZXRTZXF1ZW5jZShhcnIpIHtcbiAgY29uc3QgcCA9IGFyci5zbGljZSgpO1xuICBjb25zdCByZXN1bHQgPSBbMF07XG4gIGxldCBpLCBqLCB1LCB2LCBjO1xuICBjb25zdCBsZW4gPSBhcnIubGVuZ3RoO1xuICBmb3IgKGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICBjb25zdCBhcnJJID0gYXJyW2ldO1xuICAgIGlmIChhcnJJICE9PSAwKSB7XG4gICAgICBqID0gcmVzdWx0W3Jlc3VsdC5sZW5ndGggLSAxXTtcbiAgICAgIGlmIChhcnJbal0gPCBhcnJJKSB7XG4gICAgICAgIHBbaV0gPSBqO1xuICAgICAgICByZXN1bHQucHVzaChpKTtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICB1ID0gMDtcbiAgICAgIHYgPSByZXN1bHQubGVuZ3RoIC0gMTtcbiAgICAgIHdoaWxlICh1IDwgdikge1xuICAgICAgICBjID0gdSArIHYgPj4gMTtcbiAgICAgICAgaWYgKGFycltyZXN1bHRbY11dIDwgYXJySSkge1xuICAgICAgICAgIHUgPSBjICsgMTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB2ID0gYztcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKGFyckkgPCBhcnJbcmVzdWx0W3VdXSkge1xuICAgICAgICBpZiAodSA+IDApIHtcbiAgICAgICAgICBwW2ldID0gcmVzdWx0W3UgLSAxXTtcbiAgICAgICAgfVxuICAgICAgICByZXN1bHRbdV0gPSBpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICB1ID0gcmVzdWx0Lmxlbmd0aDtcbiAgdiA9IHJlc3VsdFt1IC0gMV07XG4gIHdoaWxlICh1LS0gPiAwKSB7XG4gICAgcmVzdWx0W3VdID0gdjtcbiAgICB2ID0gcFt2XTtcbiAgfVxuICByZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gbG9jYXRlTm9uSHlkcmF0ZWRBc3luY1Jvb3QoaW5zdGFuY2UpIHtcbiAgY29uc3Qgc3ViQ29tcG9uZW50ID0gaW5zdGFuY2Uuc3ViVHJlZS5jb21wb25lbnQ7XG4gIGlmIChzdWJDb21wb25lbnQpIHtcbiAgICBpZiAoc3ViQ29tcG9uZW50LmFzeW5jRGVwICYmICFzdWJDb21wb25lbnQuYXN5bmNSZXNvbHZlZCkge1xuICAgICAgcmV0dXJuIHN1YkNvbXBvbmVudDtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIGxvY2F0ZU5vbkh5ZHJhdGVkQXN5bmNSb290KHN1YkNvbXBvbmVudCk7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiBpbnZhbGlkYXRlTW91bnQoaG9va3MpIHtcbiAgaWYgKGhvb2tzKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBob29rcy5sZW5ndGg7IGkrKylcbiAgICAgIGhvb2tzW2ldLmZsYWdzIHw9IDg7XG4gIH1cbn1cbmZ1bmN0aW9uIHJlc29sdmVBc3luY0NvbXBvbmVudFBsYWNlaG9sZGVyKGFuY2hvclZub2RlKSB7XG4gIGlmIChhbmNob3JWbm9kZS5wbGFjZWhvbGRlcikge1xuICAgIHJldHVybiBhbmNob3JWbm9kZS5wbGFjZWhvbGRlcjtcbiAgfVxuICBjb25zdCBpbnN0YW5jZSA9IGFuY2hvclZub2RlLmNvbXBvbmVudDtcbiAgaWYgKGluc3RhbmNlKSB7XG4gICAgcmV0dXJuIHJlc29sdmVBc3luY0NvbXBvbmVudFBsYWNlaG9sZGVyKGluc3RhbmNlLnN1YlRyZWUpO1xuICB9XG4gIHJldHVybiBudWxsO1xufVxuXG5jb25zdCBpc1N1c3BlbnNlID0gKHR5cGUpID0+IHR5cGUuX19pc1N1c3BlbnNlO1xubGV0IHN1c3BlbnNlSWQgPSAwO1xuY29uc3QgU3VzcGVuc2VJbXBsID0ge1xuICBuYW1lOiBcIlN1c3BlbnNlXCIsXG4gIC8vIEluIG9yZGVyIHRvIG1ha2UgU3VzcGVuc2UgdHJlZS1zaGFrYWJsZSwgd2UgbmVlZCB0byBhdm9pZCBpbXBvcnRpbmcgaXRcbiAgLy8gZGlyZWN0bHkgaW4gdGhlIHJlbmRlcmVyLiBUaGUgcmVuZGVyZXIgY2hlY2tzIGZvciB0aGUgX19pc1N1c3BlbnNlIGZsYWdcbiAgLy8gb24gYSB2bm9kZSdzIHR5cGUgYW5kIGNhbGxzIHRoZSBgcHJvY2Vzc2AgbWV0aG9kLCBwYXNzaW5nIGluIHJlbmRlcmVyXG4gIC8vIGludGVybmFscy5cbiAgX19pc1N1c3BlbnNlOiB0cnVlLFxuICBwcm9jZXNzKG4xLCBuMiwgY29udGFpbmVyLCBhbmNob3IsIHBhcmVudENvbXBvbmVudCwgcGFyZW50U3VzcGVuc2UsIG5hbWVzcGFjZSwgc2xvdFNjb3BlSWRzLCBvcHRpbWl6ZWQsIHJlbmRlcmVySW50ZXJuYWxzKSB7XG4gICAgaWYgKG4xID09IG51bGwpIHtcbiAgICAgIG1vdW50U3VzcGVuc2UoXG4gICAgICAgIG4yLFxuICAgICAgICBjb250YWluZXIsXG4gICAgICAgIGFuY2hvcixcbiAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICBwYXJlbnRTdXNwZW5zZSxcbiAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgIG9wdGltaXplZCxcbiAgICAgICAgcmVuZGVyZXJJbnRlcm5hbHNcbiAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChwYXJlbnRTdXNwZW5zZSAmJiBwYXJlbnRTdXNwZW5zZS5kZXBzID4gMCAmJiAhbjEuc3VzcGVuc2UuaXNJbkZhbGxiYWNrKSB7XG4gICAgICAgIG4yLnN1c3BlbnNlID0gbjEuc3VzcGVuc2U7XG4gICAgICAgIG4yLnN1c3BlbnNlLnZub2RlID0gbjI7XG4gICAgICAgIG4yLmVsID0gbjEuZWw7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHBhdGNoU3VzcGVuc2UoXG4gICAgICAgIG4xLFxuICAgICAgICBuMixcbiAgICAgICAgY29udGFpbmVyLFxuICAgICAgICBhbmNob3IsXG4gICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgIG9wdGltaXplZCxcbiAgICAgICAgcmVuZGVyZXJJbnRlcm5hbHNcbiAgICAgICk7XG4gICAgfVxuICB9LFxuICBoeWRyYXRlOiBoeWRyYXRlU3VzcGVuc2UsXG4gIG5vcm1hbGl6ZTogbm9ybWFsaXplU3VzcGVuc2VDaGlsZHJlblxufTtcbmNvbnN0IFN1c3BlbnNlID0gU3VzcGVuc2VJbXBsIDtcbmZ1bmN0aW9uIHRyaWdnZXJFdmVudCh2bm9kZSwgbmFtZSkge1xuICBjb25zdCBldmVudExpc3RlbmVyID0gdm5vZGUucHJvcHMgJiYgdm5vZGUucHJvcHNbbmFtZV07XG4gIGlmIChpc0Z1bmN0aW9uKGV2ZW50TGlzdGVuZXIpKSB7XG4gICAgZXZlbnRMaXN0ZW5lcigpO1xuICB9XG59XG5mdW5jdGlvbiBtb3VudFN1c3BlbnNlKHZub2RlLCBjb250YWluZXIsIGFuY2hvciwgcGFyZW50Q29tcG9uZW50LCBwYXJlbnRTdXNwZW5zZSwgbmFtZXNwYWNlLCBzbG90U2NvcGVJZHMsIG9wdGltaXplZCwgcmVuZGVyZXJJbnRlcm5hbHMpIHtcbiAgY29uc3Qge1xuICAgIHA6IHBhdGNoLFxuICAgIG86IHsgY3JlYXRlRWxlbWVudCB9XG4gIH0gPSByZW5kZXJlckludGVybmFscztcbiAgY29uc3QgaGlkZGVuQ29udGFpbmVyID0gY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgY29uc3Qgc3VzcGVuc2UgPSB2bm9kZS5zdXNwZW5zZSA9IGNyZWF0ZVN1c3BlbnNlQm91bmRhcnkoXG4gICAgdm5vZGUsXG4gICAgcGFyZW50U3VzcGVuc2UsXG4gICAgcGFyZW50Q29tcG9uZW50LFxuICAgIGNvbnRhaW5lcixcbiAgICBoaWRkZW5Db250YWluZXIsXG4gICAgYW5jaG9yLFxuICAgIG5hbWVzcGFjZSxcbiAgICBzbG90U2NvcGVJZHMsXG4gICAgb3B0aW1pemVkLFxuICAgIHJlbmRlcmVySW50ZXJuYWxzXG4gICk7XG4gIHBhdGNoKFxuICAgIG51bGwsXG4gICAgc3VzcGVuc2UucGVuZGluZ0JyYW5jaCA9IHZub2RlLnNzQ29udGVudCxcbiAgICBoaWRkZW5Db250YWluZXIsXG4gICAgbnVsbCxcbiAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgc3VzcGVuc2UsXG4gICAgbmFtZXNwYWNlLFxuICAgIHNsb3RTY29wZUlkc1xuICApO1xuICBpZiAoc3VzcGVuc2UuZGVwcyA+IDApIHtcbiAgICB0cmlnZ2VyRXZlbnQodm5vZGUsIFwib25QZW5kaW5nXCIpO1xuICAgIHRyaWdnZXJFdmVudCh2bm9kZSwgXCJvbkZhbGxiYWNrXCIpO1xuICAgIHBhdGNoKFxuICAgICAgbnVsbCxcbiAgICAgIHZub2RlLnNzRmFsbGJhY2ssXG4gICAgICBjb250YWluZXIsXG4gICAgICBhbmNob3IsXG4gICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICBudWxsLFxuICAgICAgLy8gZmFsbGJhY2sgdHJlZSB3aWxsIG5vdCBoYXZlIHN1c3BlbnNlIGNvbnRleHRcbiAgICAgIG5hbWVzcGFjZSxcbiAgICAgIHNsb3RTY29wZUlkc1xuICAgICk7XG4gICAgc2V0QWN0aXZlQnJhbmNoKHN1c3BlbnNlLCB2bm9kZS5zc0ZhbGxiYWNrKTtcbiAgfSBlbHNlIHtcbiAgICBzdXNwZW5zZS5yZXNvbHZlKGZhbHNlLCB0cnVlKTtcbiAgfVxufVxuZnVuY3Rpb24gcGF0Y2hTdXNwZW5zZShuMSwgbjIsIGNvbnRhaW5lciwgYW5jaG9yLCBwYXJlbnRDb21wb25lbnQsIG5hbWVzcGFjZSwgc2xvdFNjb3BlSWRzLCBvcHRpbWl6ZWQsIHsgcDogcGF0Y2gsIHVtOiB1bm1vdW50LCBvOiB7IGNyZWF0ZUVsZW1lbnQgfSB9KSB7XG4gIGNvbnN0IHN1c3BlbnNlID0gbjIuc3VzcGVuc2UgPSBuMS5zdXNwZW5zZTtcbiAgc3VzcGVuc2Uudm5vZGUgPSBuMjtcbiAgbjIuZWwgPSBuMS5lbDtcbiAgY29uc3QgbmV3QnJhbmNoID0gbjIuc3NDb250ZW50O1xuICBjb25zdCBuZXdGYWxsYmFjayA9IG4yLnNzRmFsbGJhY2s7XG4gIGNvbnN0IHsgYWN0aXZlQnJhbmNoLCBwZW5kaW5nQnJhbmNoLCBpc0luRmFsbGJhY2ssIGlzSHlkcmF0aW5nIH0gPSBzdXNwZW5zZTtcbiAgaWYgKHBlbmRpbmdCcmFuY2gpIHtcbiAgICBzdXNwZW5zZS5wZW5kaW5nQnJhbmNoID0gbmV3QnJhbmNoO1xuICAgIGlmIChpc1NhbWVWTm9kZVR5cGUocGVuZGluZ0JyYW5jaCwgbmV3QnJhbmNoKSkge1xuICAgICAgcGF0Y2goXG4gICAgICAgIHBlbmRpbmdCcmFuY2gsXG4gICAgICAgIG5ld0JyYW5jaCxcbiAgICAgICAgc3VzcGVuc2UuaGlkZGVuQ29udGFpbmVyLFxuICAgICAgICBudWxsLFxuICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgIHN1c3BlbnNlLFxuICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgb3B0aW1pemVkXG4gICAgICApO1xuICAgICAgaWYgKHN1c3BlbnNlLmRlcHMgPD0gMCkge1xuICAgICAgICBzdXNwZW5zZS5yZXNvbHZlKCk7XG4gICAgICB9IGVsc2UgaWYgKGlzSW5GYWxsYmFjaykge1xuICAgICAgICBpZiAoIWlzSHlkcmF0aW5nKSB7XG4gICAgICAgICAgcGF0Y2goXG4gICAgICAgICAgICBhY3RpdmVCcmFuY2gsXG4gICAgICAgICAgICBuZXdGYWxsYmFjayxcbiAgICAgICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgICAgIGFuY2hvcixcbiAgICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICAgIG51bGwsXG4gICAgICAgICAgICAvLyBmYWxsYmFjayB0cmVlIHdpbGwgbm90IGhhdmUgc3VzcGVuc2UgY29udGV4dFxuICAgICAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICAgKTtcbiAgICAgICAgICBzZXRBY3RpdmVCcmFuY2goc3VzcGVuc2UsIG5ld0ZhbGxiYWNrKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBzdXNwZW5zZS5wZW5kaW5nSWQgPSBzdXNwZW5zZUlkKys7XG4gICAgICBpZiAoaXNIeWRyYXRpbmcpIHtcbiAgICAgICAgc3VzcGVuc2UuaXNIeWRyYXRpbmcgPSBmYWxzZTtcbiAgICAgICAgc3VzcGVuc2UuYWN0aXZlQnJhbmNoID0gcGVuZGluZ0JyYW5jaDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHVubW91bnQocGVuZGluZ0JyYW5jaCwgcGFyZW50Q29tcG9uZW50LCBzdXNwZW5zZSk7XG4gICAgICB9XG4gICAgICBzdXNwZW5zZS5kZXBzID0gMDtcbiAgICAgIHN1c3BlbnNlLmVmZmVjdHMubGVuZ3RoID0gMDtcbiAgICAgIHN1c3BlbnNlLmhpZGRlbkNvbnRhaW5lciA9IGNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICBpZiAoaXNJbkZhbGxiYWNrKSB7XG4gICAgICAgIHBhdGNoKFxuICAgICAgICAgIG51bGwsXG4gICAgICAgICAgbmV3QnJhbmNoLFxuICAgICAgICAgIHN1c3BlbnNlLmhpZGRlbkNvbnRhaW5lcixcbiAgICAgICAgICBudWxsLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICBzdXNwZW5zZSxcbiAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICApO1xuICAgICAgICBpZiAoc3VzcGVuc2UuZGVwcyA8PSAwKSB7XG4gICAgICAgICAgc3VzcGVuc2UucmVzb2x2ZSgpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHBhdGNoKFxuICAgICAgICAgICAgYWN0aXZlQnJhbmNoLFxuICAgICAgICAgICAgbmV3RmFsbGJhY2ssXG4gICAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgICBhbmNob3IsXG4gICAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgICBudWxsLFxuICAgICAgICAgICAgLy8gZmFsbGJhY2sgdHJlZSB3aWxsIG5vdCBoYXZlIHN1c3BlbnNlIGNvbnRleHRcbiAgICAgICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICAgICk7XG4gICAgICAgICAgc2V0QWN0aXZlQnJhbmNoKHN1c3BlbnNlLCBuZXdGYWxsYmFjayk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoYWN0aXZlQnJhbmNoICYmIGlzU2FtZVZOb2RlVHlwZShhY3RpdmVCcmFuY2gsIG5ld0JyYW5jaCkpIHtcbiAgICAgICAgcGF0Y2goXG4gICAgICAgICAgYWN0aXZlQnJhbmNoLFxuICAgICAgICAgIG5ld0JyYW5jaCxcbiAgICAgICAgICBjb250YWluZXIsXG4gICAgICAgICAgYW5jaG9yLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudCxcbiAgICAgICAgICBzdXNwZW5zZSxcbiAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICApO1xuICAgICAgICBzdXNwZW5zZS5yZXNvbHZlKHRydWUpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcGF0Y2goXG4gICAgICAgICAgbnVsbCxcbiAgICAgICAgICBuZXdCcmFuY2gsXG4gICAgICAgICAgc3VzcGVuc2UuaGlkZGVuQ29udGFpbmVyLFxuICAgICAgICAgIG51bGwsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgIHN1c3BlbnNlLFxuICAgICAgICAgIG5hbWVzcGFjZSxcbiAgICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgICAgb3B0aW1pemVkXG4gICAgICAgICk7XG4gICAgICAgIGlmIChzdXNwZW5zZS5kZXBzIDw9IDApIHtcbiAgICAgICAgICBzdXNwZW5zZS5yZXNvbHZlKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgaWYgKGFjdGl2ZUJyYW5jaCAmJiBpc1NhbWVWTm9kZVR5cGUoYWN0aXZlQnJhbmNoLCBuZXdCcmFuY2gpKSB7XG4gICAgICBwYXRjaChcbiAgICAgICAgYWN0aXZlQnJhbmNoLFxuICAgICAgICBuZXdCcmFuY2gsXG4gICAgICAgIGNvbnRhaW5lcixcbiAgICAgICAgYW5jaG9yLFxuICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgIHN1c3BlbnNlLFxuICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgIHNsb3RTY29wZUlkcyxcbiAgICAgICAgb3B0aW1pemVkXG4gICAgICApO1xuICAgICAgc2V0QWN0aXZlQnJhbmNoKHN1c3BlbnNlLCBuZXdCcmFuY2gpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0cmlnZ2VyRXZlbnQobjIsIFwib25QZW5kaW5nXCIpO1xuICAgICAgc3VzcGVuc2UucGVuZGluZ0JyYW5jaCA9IG5ld0JyYW5jaDtcbiAgICAgIGlmIChuZXdCcmFuY2guc2hhcGVGbGFnICYgNTEyKSB7XG4gICAgICAgIHN1c3BlbnNlLnBlbmRpbmdJZCA9IG5ld0JyYW5jaC5jb21wb25lbnQuc3VzcGVuc2VJZDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHN1c3BlbnNlLnBlbmRpbmdJZCA9IHN1c3BlbnNlSWQrKztcbiAgICAgIH1cbiAgICAgIHBhdGNoKFxuICAgICAgICBudWxsLFxuICAgICAgICBuZXdCcmFuY2gsXG4gICAgICAgIHN1c3BlbnNlLmhpZGRlbkNvbnRhaW5lcixcbiAgICAgICAgbnVsbCxcbiAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICBzdXNwZW5zZSxcbiAgICAgICAgbmFtZXNwYWNlLFxuICAgICAgICBzbG90U2NvcGVJZHMsXG4gICAgICAgIG9wdGltaXplZFxuICAgICAgKTtcbiAgICAgIGlmIChzdXNwZW5zZS5kZXBzIDw9IDApIHtcbiAgICAgICAgc3VzcGVuc2UucmVzb2x2ZSgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgeyB0aW1lb3V0LCBwZW5kaW5nSWQgfSA9IHN1c3BlbnNlO1xuICAgICAgICBpZiAodGltZW91dCA+IDApIHtcbiAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIGlmIChzdXNwZW5zZS5wZW5kaW5nSWQgPT09IHBlbmRpbmdJZCkge1xuICAgICAgICAgICAgICBzdXNwZW5zZS5mYWxsYmFjayhuZXdGYWxsYmFjayk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSwgdGltZW91dCk7XG4gICAgICAgIH0gZWxzZSBpZiAodGltZW91dCA9PT0gMCkge1xuICAgICAgICAgIHN1c3BlbnNlLmZhbGxiYWNrKG5ld0ZhbGxiYWNrKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxufVxubGV0IGhhc1dhcm5lZCA9IGZhbHNlO1xuZnVuY3Rpb24gY3JlYXRlU3VzcGVuc2VCb3VuZGFyeSh2bm9kZSwgcGFyZW50U3VzcGVuc2UsIHBhcmVudENvbXBvbmVudCwgY29udGFpbmVyLCBoaWRkZW5Db250YWluZXIsIGFuY2hvciwgbmFtZXNwYWNlLCBzbG90U2NvcGVJZHMsIG9wdGltaXplZCwgcmVuZGVyZXJJbnRlcm5hbHMsIGlzSHlkcmF0aW5nID0gZmFsc2UpIHtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgdHJ1ZSAmJiAhaGFzV2FybmVkKSB7XG4gICAgaGFzV2FybmVkID0gdHJ1ZTtcbiAgICBjb25zb2xlW2NvbnNvbGUuaW5mbyA/IFwiaW5mb1wiIDogXCJsb2dcIl0oXG4gICAgICBgPFN1c3BlbnNlPiBpcyBhbiBleHBlcmltZW50YWwgZmVhdHVyZSBhbmQgaXRzIEFQSSB3aWxsIGxpa2VseSBjaGFuZ2UuYFxuICAgICk7XG4gIH1cbiAgY29uc3Qge1xuICAgIHA6IHBhdGNoLFxuICAgIG06IG1vdmUsXG4gICAgdW06IHVubW91bnQsXG4gICAgbjogbmV4dCxcbiAgICBvOiB7IHBhcmVudE5vZGUsIHJlbW92ZSB9XG4gIH0gPSByZW5kZXJlckludGVybmFscztcbiAgbGV0IHBhcmVudFN1c3BlbnNlSWQ7XG4gIGNvbnN0IGlzU3VzcGVuc2libGUgPSBpc1ZOb2RlU3VzcGVuc2libGUodm5vZGUpO1xuICBpZiAoaXNTdXNwZW5zaWJsZSkge1xuICAgIGlmIChwYXJlbnRTdXNwZW5zZSAmJiBwYXJlbnRTdXNwZW5zZS5wZW5kaW5nQnJhbmNoKSB7XG4gICAgICBwYXJlbnRTdXNwZW5zZUlkID0gcGFyZW50U3VzcGVuc2UucGVuZGluZ0lkO1xuICAgICAgcGFyZW50U3VzcGVuc2UuZGVwcysrO1xuICAgIH1cbiAgfVxuICBjb25zdCB0aW1lb3V0ID0gdm5vZGUucHJvcHMgPyB0b051bWJlcih2bm9kZS5wcm9wcy50aW1lb3V0KSA6IHZvaWQgMDtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICBhc3NlcnROdW1iZXIodGltZW91dCwgYFN1c3BlbnNlIHRpbWVvdXRgKTtcbiAgfVxuICBjb25zdCBpbml0aWFsQW5jaG9yID0gYW5jaG9yO1xuICBjb25zdCBzdXNwZW5zZSA9IHtcbiAgICB2bm9kZSxcbiAgICBwYXJlbnQ6IHBhcmVudFN1c3BlbnNlLFxuICAgIHBhcmVudENvbXBvbmVudCxcbiAgICBuYW1lc3BhY2UsXG4gICAgY29udGFpbmVyLFxuICAgIGhpZGRlbkNvbnRhaW5lcixcbiAgICBkZXBzOiAwLFxuICAgIHBlbmRpbmdJZDogc3VzcGVuc2VJZCsrLFxuICAgIHRpbWVvdXQ6IHR5cGVvZiB0aW1lb3V0ID09PSBcIm51bWJlclwiID8gdGltZW91dCA6IC0xLFxuICAgIGFjdGl2ZUJyYW5jaDogbnVsbCxcbiAgICBpc0ZhbGxiYWNrTW91bnRQZW5kaW5nOiBmYWxzZSxcbiAgICBwZW5kaW5nQnJhbmNoOiBudWxsLFxuICAgIGlzSW5GYWxsYmFjazogIWlzSHlkcmF0aW5nLFxuICAgIGlzSHlkcmF0aW5nLFxuICAgIGlzVW5tb3VudGVkOiBmYWxzZSxcbiAgICBlZmZlY3RzOiBbXSxcbiAgICByZXNvbHZlKHJlc3VtZSA9IGZhbHNlLCBzeW5jID0gZmFsc2UpIHtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgIGlmICghcmVzdW1lICYmICFzdXNwZW5zZS5wZW5kaW5nQnJhbmNoKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgYHN1c3BlbnNlLnJlc29sdmUoKSBpcyBjYWxsZWQgd2l0aG91dCBhIHBlbmRpbmcgYnJhbmNoLmBcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzdXNwZW5zZS5pc1VubW91bnRlZCkge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgIGBzdXNwZW5zZS5yZXNvbHZlKCkgaXMgY2FsbGVkIG9uIGFuIGFscmVhZHkgdW5tb3VudGVkIHN1c3BlbnNlIGJvdW5kYXJ5LmBcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBjb25zdCB7XG4gICAgICAgIHZub2RlOiB2bm9kZTIsXG4gICAgICAgIGFjdGl2ZUJyYW5jaCxcbiAgICAgICAgcGVuZGluZ0JyYW5jaCxcbiAgICAgICAgcGVuZGluZ0lkLFxuICAgICAgICBlZmZlY3RzLFxuICAgICAgICBwYXJlbnRDb21wb25lbnQ6IHBhcmVudENvbXBvbmVudDIsXG4gICAgICAgIGNvbnRhaW5lcjogY29udGFpbmVyMixcbiAgICAgICAgaXNJbkZhbGxiYWNrXG4gICAgICB9ID0gc3VzcGVuc2U7XG4gICAgICBsZXQgZGVsYXlFbnRlciA9IGZhbHNlO1xuICAgICAgaWYgKHN1c3BlbnNlLmlzSHlkcmF0aW5nKSB7XG4gICAgICAgIHN1c3BlbnNlLmlzSHlkcmF0aW5nID0gZmFsc2U7XG4gICAgICB9IGVsc2UgaWYgKCFyZXN1bWUpIHtcbiAgICAgICAgZGVsYXlFbnRlciA9IGFjdGl2ZUJyYW5jaCAmJiBwZW5kaW5nQnJhbmNoLnRyYW5zaXRpb24gJiYgcGVuZGluZ0JyYW5jaC50cmFuc2l0aW9uLm1vZGUgPT09IFwib3V0LWluXCI7XG4gICAgICAgIGxldCBoYXNVcGRhdGVkQW5jaG9yID0gZmFsc2U7XG4gICAgICAgIGlmIChkZWxheUVudGVyKSB7XG4gICAgICAgICAgYWN0aXZlQnJhbmNoLnRyYW5zaXRpb24uYWZ0ZXJMZWF2ZSA9ICgpID0+IHtcbiAgICAgICAgICAgIGlmIChwZW5kaW5nSWQgPT09IHN1c3BlbnNlLnBlbmRpbmdJZCkge1xuICAgICAgICAgICAgICBtb3ZlKFxuICAgICAgICAgICAgICAgIHBlbmRpbmdCcmFuY2gsXG4gICAgICAgICAgICAgICAgY29udGFpbmVyMixcbiAgICAgICAgICAgICAgICBhbmNob3IgPT09IGluaXRpYWxBbmNob3IgJiYgIWhhc1VwZGF0ZWRBbmNob3IgPyBuZXh0KGFjdGl2ZUJyYW5jaCkgOiBhbmNob3IsXG4gICAgICAgICAgICAgICAgMFxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICBxdWV1ZVBvc3RGbHVzaENiKGVmZmVjdHMpO1xuICAgICAgICAgICAgICBpZiAoaXNJbkZhbGxiYWNrICYmIHZub2RlMi5zc0ZhbGxiYWNrKSB7XG4gICAgICAgICAgICAgICAgdm5vZGUyLnNzRmFsbGJhY2suZWwgPSBudWxsO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoYWN0aXZlQnJhbmNoICYmICFzdXNwZW5zZS5pc0ZhbGxiYWNrTW91bnRQZW5kaW5nKSB7XG4gICAgICAgICAgaWYgKHBhcmVudE5vZGUoYWN0aXZlQnJhbmNoLmVsKSA9PT0gY29udGFpbmVyMikge1xuICAgICAgICAgICAgYW5jaG9yID0gbmV4dChhY3RpdmVCcmFuY2gpO1xuICAgICAgICAgICAgaGFzVXBkYXRlZEFuY2hvciA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIHVubW91bnQoYWN0aXZlQnJhbmNoLCBwYXJlbnRDb21wb25lbnQyLCBzdXNwZW5zZSwgdHJ1ZSk7XG4gICAgICAgICAgaWYgKCFkZWxheUVudGVyICYmIGlzSW5GYWxsYmFjayAmJiB2bm9kZTIuc3NGYWxsYmFjaykge1xuICAgICAgICAgICAgcXVldWVQb3N0UmVuZGVyRWZmZWN0KCgpID0+IHZub2RlMi5zc0ZhbGxiYWNrLmVsID0gbnVsbCwgc3VzcGVuc2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIWRlbGF5RW50ZXIpIHtcbiAgICAgICAgICBtb3ZlKHBlbmRpbmdCcmFuY2gsIGNvbnRhaW5lcjIsIGFuY2hvciwgMCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHN1c3BlbnNlLmlzRmFsbGJhY2tNb3VudFBlbmRpbmcgPSBmYWxzZTtcbiAgICAgIHNldEFjdGl2ZUJyYW5jaChzdXNwZW5zZSwgcGVuZGluZ0JyYW5jaCk7XG4gICAgICBzdXNwZW5zZS5wZW5kaW5nQnJhbmNoID0gbnVsbDtcbiAgICAgIHN1c3BlbnNlLmlzSW5GYWxsYmFjayA9IGZhbHNlO1xuICAgICAgbGV0IHBhcmVudCA9IHN1c3BlbnNlLnBhcmVudDtcbiAgICAgIGxldCBoYXNVbnJlc29sdmVkQW5jZXN0b3IgPSBmYWxzZTtcbiAgICAgIHdoaWxlIChwYXJlbnQpIHtcbiAgICAgICAgaWYgKHBhcmVudC5wZW5kaW5nQnJhbmNoKSB7XG4gICAgICAgICAgcGFyZW50LmVmZmVjdHMucHVzaCguLi5lZmZlY3RzKTtcbiAgICAgICAgICBoYXNVbnJlc29sdmVkQW5jZXN0b3IgPSB0cnVlO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIHBhcmVudCA9IHBhcmVudC5wYXJlbnQ7XG4gICAgICB9XG4gICAgICBpZiAoIWhhc1VucmVzb2x2ZWRBbmNlc3RvciAmJiAhZGVsYXlFbnRlcikge1xuICAgICAgICBxdWV1ZVBvc3RGbHVzaENiKGVmZmVjdHMpO1xuICAgICAgfVxuICAgICAgc3VzcGVuc2UuZWZmZWN0cyA9IFtdO1xuICAgICAgaWYgKGlzU3VzcGVuc2libGUpIHtcbiAgICAgICAgaWYgKHBhcmVudFN1c3BlbnNlICYmIHBhcmVudFN1c3BlbnNlLnBlbmRpbmdCcmFuY2ggJiYgcGFyZW50U3VzcGVuc2VJZCA9PT0gcGFyZW50U3VzcGVuc2UucGVuZGluZ0lkKSB7XG4gICAgICAgICAgcGFyZW50U3VzcGVuc2UuZGVwcy0tO1xuICAgICAgICAgIGlmIChwYXJlbnRTdXNwZW5zZS5kZXBzID09PSAwICYmICFzeW5jKSB7XG4gICAgICAgICAgICBwYXJlbnRTdXNwZW5zZS5yZXNvbHZlKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICB0cmlnZ2VyRXZlbnQodm5vZGUyLCBcIm9uUmVzb2x2ZVwiKTtcbiAgICB9LFxuICAgIGZhbGxiYWNrKGZhbGxiYWNrVk5vZGUpIHtcbiAgICAgIGlmICghc3VzcGVuc2UucGVuZGluZ0JyYW5jaCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCB7IHZub2RlOiB2bm9kZTIsIGFjdGl2ZUJyYW5jaCwgcGFyZW50Q29tcG9uZW50OiBwYXJlbnRDb21wb25lbnQyLCBjb250YWluZXI6IGNvbnRhaW5lcjIsIG5hbWVzcGFjZTogbmFtZXNwYWNlMiB9ID0gc3VzcGVuc2U7XG4gICAgICB0cmlnZ2VyRXZlbnQodm5vZGUyLCBcIm9uRmFsbGJhY2tcIik7XG4gICAgICBjb25zdCBhbmNob3IyID0gbmV4dChhY3RpdmVCcmFuY2gpO1xuICAgICAgY29uc3QgbW91bnRGYWxsYmFjayA9ICgpID0+IHtcbiAgICAgICAgc3VzcGVuc2UuaXNGYWxsYmFja01vdW50UGVuZGluZyA9IGZhbHNlO1xuICAgICAgICBpZiAoIXN1c3BlbnNlLmlzSW5GYWxsYmFjaykge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBwYXRjaChcbiAgICAgICAgICBudWxsLFxuICAgICAgICAgIGZhbGxiYWNrVk5vZGUsXG4gICAgICAgICAgY29udGFpbmVyMixcbiAgICAgICAgICBhbmNob3IyLFxuICAgICAgICAgIHBhcmVudENvbXBvbmVudDIsXG4gICAgICAgICAgbnVsbCxcbiAgICAgICAgICAvLyBmYWxsYmFjayB0cmVlIHdpbGwgbm90IGhhdmUgc3VzcGVuc2UgY29udGV4dFxuICAgICAgICAgIG5hbWVzcGFjZTIsXG4gICAgICAgICAgc2xvdFNjb3BlSWRzLFxuICAgICAgICAgIG9wdGltaXplZFxuICAgICAgICApO1xuICAgICAgICBzZXRBY3RpdmVCcmFuY2goc3VzcGVuc2UsIGZhbGxiYWNrVk5vZGUpO1xuICAgICAgfTtcbiAgICAgIGNvbnN0IGRlbGF5RW50ZXIgPSBmYWxsYmFja1ZOb2RlLnRyYW5zaXRpb24gJiYgZmFsbGJhY2tWTm9kZS50cmFuc2l0aW9uLm1vZGUgPT09IFwib3V0LWluXCI7XG4gICAgICBpZiAoZGVsYXlFbnRlcikge1xuICAgICAgICBzdXNwZW5zZS5pc0ZhbGxiYWNrTW91bnRQZW5kaW5nID0gdHJ1ZTtcbiAgICAgICAgYWN0aXZlQnJhbmNoLnRyYW5zaXRpb24uYWZ0ZXJMZWF2ZSA9IG1vdW50RmFsbGJhY2s7XG4gICAgICB9XG4gICAgICBzdXNwZW5zZS5pc0luRmFsbGJhY2sgPSB0cnVlO1xuICAgICAgdW5tb3VudChcbiAgICAgICAgYWN0aXZlQnJhbmNoLFxuICAgICAgICBwYXJlbnRDb21wb25lbnQyLFxuICAgICAgICBudWxsLFxuICAgICAgICAvLyBubyBzdXNwZW5zZSBzbyB1bm1vdW50IGhvb2tzIGZpcmUgbm93XG4gICAgICAgIHRydWVcbiAgICAgICAgLy8gc2hvdWxkUmVtb3ZlXG4gICAgICApO1xuICAgICAgaWYgKCFkZWxheUVudGVyKSB7XG4gICAgICAgIG1vdW50RmFsbGJhY2soKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIG1vdmUoY29udGFpbmVyMiwgYW5jaG9yMiwgdHlwZSkge1xuICAgICAgc3VzcGVuc2UuYWN0aXZlQnJhbmNoICYmIG1vdmUoc3VzcGVuc2UuYWN0aXZlQnJhbmNoLCBjb250YWluZXIyLCBhbmNob3IyLCB0eXBlKTtcbiAgICAgIHN1c3BlbnNlLmNvbnRhaW5lciA9IGNvbnRhaW5lcjI7XG4gICAgfSxcbiAgICBuZXh0KCkge1xuICAgICAgcmV0dXJuIHN1c3BlbnNlLmFjdGl2ZUJyYW5jaCAmJiBuZXh0KHN1c3BlbnNlLmFjdGl2ZUJyYW5jaCk7XG4gICAgfSxcbiAgICByZWdpc3RlckRlcChpbnN0YW5jZSwgc2V0dXBSZW5kZXJFZmZlY3QsIG9wdGltaXplZDIpIHtcbiAgICAgIGNvbnN0IGlzSW5QZW5kaW5nU3VzcGVuc2UgPSAhIXN1c3BlbnNlLnBlbmRpbmdCcmFuY2g7XG4gICAgICBpZiAoaXNJblBlbmRpbmdTdXNwZW5zZSkge1xuICAgICAgICBzdXNwZW5zZS5kZXBzKys7XG4gICAgICB9XG4gICAgICBjb25zdCBoeWRyYXRlZEVsID0gaW5zdGFuY2Uudm5vZGUuZWw7XG4gICAgICBpbnN0YW5jZS5hc3luY0RlcC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgIGhhbmRsZUVycm9yKGVyciwgaW5zdGFuY2UsIDApO1xuICAgICAgfSkudGhlbigoYXN5bmNTZXR1cFJlc3VsdCkgPT4ge1xuICAgICAgICBpZiAoaW5zdGFuY2UuaXNVbm1vdW50ZWQgfHwgc3VzcGVuc2UuaXNVbm1vdW50ZWQgfHwgc3VzcGVuc2UucGVuZGluZ0lkICE9PSBpbnN0YW5jZS5zdXNwZW5zZUlkKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHVuc2V0Q3VycmVudEluc3RhbmNlKCk7XG4gICAgICAgIGluc3RhbmNlLmFzeW5jUmVzb2x2ZWQgPSB0cnVlO1xuICAgICAgICBjb25zdCB7IHZub2RlOiB2bm9kZTIgfSA9IGluc3RhbmNlO1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIHB1c2hXYXJuaW5nQ29udGV4dCh2bm9kZTIpO1xuICAgICAgICB9XG4gICAgICAgIGhhbmRsZVNldHVwUmVzdWx0KGluc3RhbmNlLCBhc3luY1NldHVwUmVzdWx0LCBmYWxzZSk7XG4gICAgICAgIGlmIChoeWRyYXRlZEVsKSB7XG4gICAgICAgICAgdm5vZGUyLmVsID0gaHlkcmF0ZWRFbDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwbGFjZWhvbGRlciA9ICFoeWRyYXRlZEVsICYmIGluc3RhbmNlLnN1YlRyZWUuZWw7XG4gICAgICAgIHNldHVwUmVuZGVyRWZmZWN0KFxuICAgICAgICAgIGluc3RhbmNlLFxuICAgICAgICAgIHZub2RlMixcbiAgICAgICAgICAvLyBjb21wb25lbnQgbWF5IGhhdmUgYmVlbiBtb3ZlZCBiZWZvcmUgcmVzb2x2ZS5cbiAgICAgICAgICAvLyBpZiB0aGlzIGlzIG5vdCBhIGh5ZHJhdGlvbiwgaW5zdGFuY2Uuc3ViVHJlZSB3aWxsIGJlIHRoZSBjb21tZW50XG4gICAgICAgICAgLy8gcGxhY2Vob2xkZXIuXG4gICAgICAgICAgcGFyZW50Tm9kZShoeWRyYXRlZEVsIHx8IGluc3RhbmNlLnN1YlRyZWUuZWwpLFxuICAgICAgICAgIC8vIGFuY2hvciB3aWxsIG5vdCBiZSB1c2VkIGlmIHRoaXMgaXMgaHlkcmF0aW9uLCBzbyBvbmx5IG5lZWQgdG9cbiAgICAgICAgICAvLyBjb25zaWRlciB0aGUgY29tbWVudCBwbGFjZWhvbGRlciBjYXNlLlxuICAgICAgICAgIGh5ZHJhdGVkRWwgPyBudWxsIDogbmV4dChpbnN0YW5jZS5zdWJUcmVlKSxcbiAgICAgICAgICBzdXNwZW5zZSxcbiAgICAgICAgICBuYW1lc3BhY2UsXG4gICAgICAgICAgb3B0aW1pemVkMlxuICAgICAgICApO1xuICAgICAgICBpZiAocGxhY2Vob2xkZXIpIHtcbiAgICAgICAgICB2bm9kZTIucGxhY2Vob2xkZXIgPSBudWxsO1xuICAgICAgICAgIHJlbW92ZShwbGFjZWhvbGRlcik7XG4gICAgICAgIH1cbiAgICAgICAgdXBkYXRlSE9DSG9zdEVsKGluc3RhbmNlLCB2bm9kZTIuZWwpO1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIHBvcFdhcm5pbmdDb250ZXh0KCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzSW5QZW5kaW5nU3VzcGVuc2UgJiYgLS1zdXNwZW5zZS5kZXBzID09PSAwKSB7XG4gICAgICAgICAgc3VzcGVuc2UucmVzb2x2ZSgpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9LFxuICAgIHVubW91bnQocGFyZW50U3VzcGVuc2UyLCBkb1JlbW92ZSkge1xuICAgICAgc3VzcGVuc2UuaXNVbm1vdW50ZWQgPSB0cnVlO1xuICAgICAgaWYgKHN1c3BlbnNlLmFjdGl2ZUJyYW5jaCkge1xuICAgICAgICB1bm1vdW50KFxuICAgICAgICAgIHN1c3BlbnNlLmFjdGl2ZUJyYW5jaCxcbiAgICAgICAgICBwYXJlbnRDb21wb25lbnQsXG4gICAgICAgICAgcGFyZW50U3VzcGVuc2UyLFxuICAgICAgICAgIGRvUmVtb3ZlXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBpZiAoc3VzcGVuc2UucGVuZGluZ0JyYW5jaCkge1xuICAgICAgICB1bm1vdW50KFxuICAgICAgICAgIHN1c3BlbnNlLnBlbmRpbmdCcmFuY2gsXG4gICAgICAgICAgcGFyZW50Q29tcG9uZW50LFxuICAgICAgICAgIHBhcmVudFN1c3BlbnNlMixcbiAgICAgICAgICBkb1JlbW92ZVxuICAgICAgICApO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbiAgcmV0dXJuIHN1c3BlbnNlO1xufVxuZnVuY3Rpb24gaHlkcmF0ZVN1c3BlbnNlKG5vZGUsIHZub2RlLCBwYXJlbnRDb21wb25lbnQsIHBhcmVudFN1c3BlbnNlLCBuYW1lc3BhY2UsIHNsb3RTY29wZUlkcywgb3B0aW1pemVkLCByZW5kZXJlckludGVybmFscywgaHlkcmF0ZU5vZGUpIHtcbiAgY29uc3Qgc3VzcGVuc2UgPSB2bm9kZS5zdXNwZW5zZSA9IGNyZWF0ZVN1c3BlbnNlQm91bmRhcnkoXG4gICAgdm5vZGUsXG4gICAgcGFyZW50U3VzcGVuc2UsXG4gICAgcGFyZW50Q29tcG9uZW50LFxuICAgIG5vZGUucGFyZW50Tm9kZSxcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcmVzdHJpY3RlZC1nbG9iYWxzXG4gICAgZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKSxcbiAgICBudWxsLFxuICAgIG5hbWVzcGFjZSxcbiAgICBzbG90U2NvcGVJZHMsXG4gICAgb3B0aW1pemVkLFxuICAgIHJlbmRlcmVySW50ZXJuYWxzLFxuICAgIHRydWVcbiAgKTtcbiAgY29uc3QgcmVzdWx0ID0gaHlkcmF0ZU5vZGUoXG4gICAgbm9kZSxcbiAgICBzdXNwZW5zZS5wZW5kaW5nQnJhbmNoID0gdm5vZGUuc3NDb250ZW50LFxuICAgIHBhcmVudENvbXBvbmVudCxcbiAgICBzdXNwZW5zZSxcbiAgICBzbG90U2NvcGVJZHMsXG4gICAgb3B0aW1pemVkXG4gICk7XG4gIGlmIChzdXNwZW5zZS5kZXBzID09PSAwKSB7XG4gICAgc3VzcGVuc2UucmVzb2x2ZShmYWxzZSwgdHJ1ZSk7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZVN1c3BlbnNlQ2hpbGRyZW4odm5vZGUpIHtcbiAgY29uc3QgeyBzaGFwZUZsYWcsIGNoaWxkcmVuIH0gPSB2bm9kZTtcbiAgY29uc3QgaXNTbG90Q2hpbGRyZW4gPSBzaGFwZUZsYWcgJiAzMjtcbiAgdm5vZGUuc3NDb250ZW50ID0gbm9ybWFsaXplU3VzcGVuc2VTbG90KFxuICAgIGlzU2xvdENoaWxkcmVuID8gY2hpbGRyZW4uZGVmYXVsdCA6IGNoaWxkcmVuXG4gICk7XG4gIHZub2RlLnNzRmFsbGJhY2sgPSBpc1Nsb3RDaGlsZHJlbiA/IG5vcm1hbGl6ZVN1c3BlbnNlU2xvdChjaGlsZHJlbi5mYWxsYmFjaykgOiBjcmVhdGVWTm9kZShDb21tZW50KTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZVN1c3BlbnNlU2xvdChzKSB7XG4gIGxldCBibG9jaztcbiAgaWYgKGlzRnVuY3Rpb24ocykpIHtcbiAgICBjb25zdCB0cmFja0Jsb2NrID0gaXNCbG9ja1RyZWVFbmFibGVkICYmIHMuX2M7XG4gICAgaWYgKHRyYWNrQmxvY2spIHtcbiAgICAgIHMuX2QgPSBmYWxzZTtcbiAgICAgIG9wZW5CbG9jaygpO1xuICAgIH1cbiAgICBzID0gcygpO1xuICAgIGlmICh0cmFja0Jsb2NrKSB7XG4gICAgICBzLl9kID0gdHJ1ZTtcbiAgICAgIGJsb2NrID0gY3VycmVudEJsb2NrO1xuICAgICAgY2xvc2VCbG9jaygpO1xuICAgIH1cbiAgfVxuICBpZiAoaXNBcnJheShzKSkge1xuICAgIGNvbnN0IHNpbmdsZUNoaWxkID0gZmlsdGVyU2luZ2xlUm9vdChzKTtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiAhc2luZ2xlQ2hpbGQgJiYgcy5maWx0ZXIoKGNoaWxkKSA9PiBjaGlsZCAhPT0gTlVMTF9EWU5BTUlDX0NPTVBPTkVOVCkubGVuZ3RoID4gMCkge1xuICAgICAgd2FybiQxKGA8U3VzcGVuc2U+IHNsb3RzIGV4cGVjdCBhIHNpbmdsZSByb290IG5vZGUuYCk7XG4gICAgfVxuICAgIHMgPSBzaW5nbGVDaGlsZDtcbiAgfVxuICBzID0gbm9ybWFsaXplVk5vZGUocyk7XG4gIGlmIChibG9jayAmJiAhcy5keW5hbWljQ2hpbGRyZW4pIHtcbiAgICBzLmR5bmFtaWNDaGlsZHJlbiA9IGJsb2NrLmZpbHRlcigoYykgPT4gYyAhPT0gcyk7XG4gIH1cbiAgcmV0dXJuIHM7XG59XG5mdW5jdGlvbiBxdWV1ZUVmZmVjdFdpdGhTdXNwZW5zZShmbiwgc3VzcGVuc2UpIHtcbiAgaWYgKHN1c3BlbnNlICYmIHN1c3BlbnNlLnBlbmRpbmdCcmFuY2gpIHtcbiAgICBpZiAoaXNBcnJheShmbikpIHtcbiAgICAgIHN1c3BlbnNlLmVmZmVjdHMucHVzaCguLi5mbik7XG4gICAgfSBlbHNlIHtcbiAgICAgIHN1c3BlbnNlLmVmZmVjdHMucHVzaChmbik7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHF1ZXVlUG9zdEZsdXNoQ2IoZm4pO1xuICB9XG59XG5mdW5jdGlvbiBzZXRBY3RpdmVCcmFuY2goc3VzcGVuc2UsIGJyYW5jaCkge1xuICBzdXNwZW5zZS5hY3RpdmVCcmFuY2ggPSBicmFuY2g7XG4gIGNvbnN0IHsgdm5vZGUsIHBhcmVudENvbXBvbmVudCB9ID0gc3VzcGVuc2U7XG4gIGxldCBlbCA9IGJyYW5jaC5lbDtcbiAgd2hpbGUgKCFlbCAmJiBicmFuY2guY29tcG9uZW50KSB7XG4gICAgYnJhbmNoID0gYnJhbmNoLmNvbXBvbmVudC5zdWJUcmVlO1xuICAgIGVsID0gYnJhbmNoLmVsO1xuICB9XG4gIHZub2RlLmVsID0gZWw7XG4gIGlmIChwYXJlbnRDb21wb25lbnQgJiYgcGFyZW50Q29tcG9uZW50LnN1YlRyZWUgPT09IHZub2RlKSB7XG4gICAgcGFyZW50Q29tcG9uZW50LnZub2RlLmVsID0gZWw7XG4gICAgdXBkYXRlSE9DSG9zdEVsKHBhcmVudENvbXBvbmVudCwgZWwpO1xuICB9XG59XG5mdW5jdGlvbiBpc1ZOb2RlU3VzcGVuc2libGUodm5vZGUpIHtcbiAgY29uc3Qgc3VzcGVuc2libGUgPSB2bm9kZS5wcm9wcyAmJiB2bm9kZS5wcm9wcy5zdXNwZW5zaWJsZTtcbiAgcmV0dXJuIHN1c3BlbnNpYmxlICE9IG51bGwgJiYgc3VzcGVuc2libGUgIT09IGZhbHNlO1xufVxuXG5jb25zdCBGcmFnbWVudCA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKFwidi1mZ3RcIik7XG5jb25zdCBUZXh0ID0gLyogQF9fUFVSRV9fICovIFN5bWJvbC5mb3IoXCJ2LXR4dFwiKTtcbmNvbnN0IENvbW1lbnQgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sLmZvcihcInYtY210XCIpO1xuY29uc3QgU3RhdGljID0gLyogQF9fUFVSRV9fICovIFN5bWJvbC5mb3IoXCJ2LXN0Y1wiKTtcbmNvbnN0IGJsb2NrU3RhY2sgPSBbXTtcbmxldCBjdXJyZW50QmxvY2sgPSBudWxsO1xuZnVuY3Rpb24gb3BlbkJsb2NrKGRpc2FibGVUcmFja2luZyA9IGZhbHNlKSB7XG4gIGJsb2NrU3RhY2sucHVzaChjdXJyZW50QmxvY2sgPSBkaXNhYmxlVHJhY2tpbmcgPyBudWxsIDogW10pO1xufVxuZnVuY3Rpb24gY2xvc2VCbG9jaygpIHtcbiAgYmxvY2tTdGFjay5wb3AoKTtcbiAgY3VycmVudEJsb2NrID0gYmxvY2tTdGFja1tibG9ja1N0YWNrLmxlbmd0aCAtIDFdIHx8IG51bGw7XG59XG5sZXQgaXNCbG9ja1RyZWVFbmFibGVkID0gMTtcbmZ1bmN0aW9uIHNldEJsb2NrVHJhY2tpbmcodmFsdWUsIGluVk9uY2UgPSBmYWxzZSkge1xuICBpc0Jsb2NrVHJlZUVuYWJsZWQgKz0gdmFsdWU7XG4gIGlmICh2YWx1ZSA8IDAgJiYgY3VycmVudEJsb2NrICYmIGluVk9uY2UpIHtcbiAgICBjdXJyZW50QmxvY2suaGFzT25jZSA9IHRydWU7XG4gIH1cbn1cbmZ1bmN0aW9uIHNldHVwQmxvY2sodm5vZGUpIHtcbiAgdm5vZGUuZHluYW1pY0NoaWxkcmVuID0gaXNCbG9ja1RyZWVFbmFibGVkID4gMCA/IGN1cnJlbnRCbG9jayB8fCBFTVBUWV9BUlIgOiBudWxsO1xuICBjbG9zZUJsb2NrKCk7XG4gIGlmIChpc0Jsb2NrVHJlZUVuYWJsZWQgPiAwICYmIGN1cnJlbnRCbG9jaykge1xuICAgIGN1cnJlbnRCbG9jay5wdXNoKHZub2RlKTtcbiAgfVxuICByZXR1cm4gdm5vZGU7XG59XG5mdW5jdGlvbiBjcmVhdGVFbGVtZW50QmxvY2sodHlwZSwgcHJvcHMsIGNoaWxkcmVuLCBwYXRjaEZsYWcsIGR5bmFtaWNQcm9wcywgc2hhcGVGbGFnKSB7XG4gIHJldHVybiBzZXR1cEJsb2NrKFxuICAgIGNyZWF0ZUJhc2VWTm9kZShcbiAgICAgIHR5cGUsXG4gICAgICBwcm9wcyxcbiAgICAgIGNoaWxkcmVuLFxuICAgICAgcGF0Y2hGbGFnLFxuICAgICAgZHluYW1pY1Byb3BzLFxuICAgICAgc2hhcGVGbGFnLFxuICAgICAgdHJ1ZVxuICAgIClcbiAgKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUJsb2NrKHR5cGUsIHByb3BzLCBjaGlsZHJlbiwgcGF0Y2hGbGFnLCBkeW5hbWljUHJvcHMpIHtcbiAgcmV0dXJuIHNldHVwQmxvY2soXG4gICAgY3JlYXRlVk5vZGUoXG4gICAgICB0eXBlLFxuICAgICAgcHJvcHMsXG4gICAgICBjaGlsZHJlbixcbiAgICAgIHBhdGNoRmxhZyxcbiAgICAgIGR5bmFtaWNQcm9wcyxcbiAgICAgIHRydWVcbiAgICApXG4gICk7XG59XG5mdW5jdGlvbiBpc1ZOb2RlKHZhbHVlKSB7XG4gIHJldHVybiB2YWx1ZSA/IHZhbHVlLl9fdl9pc1ZOb2RlID09PSB0cnVlIDogZmFsc2U7XG59XG5mdW5jdGlvbiBpc1NhbWVWTm9kZVR5cGUobjEsIG4yKSB7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIG4yLnNoYXBlRmxhZyAmIDYgJiYgbjEuY29tcG9uZW50KSB7XG4gICAgY29uc3QgZGlydHlJbnN0YW5jZXMgPSBobXJEaXJ0eUNvbXBvbmVudHMuZ2V0KG4yLnR5cGUpO1xuICAgIGlmIChkaXJ0eUluc3RhbmNlcyAmJiBkaXJ0eUluc3RhbmNlcy5oYXMobjEuY29tcG9uZW50KSkge1xuICAgICAgbjEuc2hhcGVGbGFnICY9IC0yNTc7XG4gICAgICBuMi5zaGFwZUZsYWcgJj0gLTUxMztcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG4xLnR5cGUgPT09IG4yLnR5cGUgJiYgbjEua2V5ID09PSBuMi5rZXk7XG59XG5sZXQgdm5vZGVBcmdzVHJhbnNmb3JtZXI7XG5mdW5jdGlvbiB0cmFuc2Zvcm1WTm9kZUFyZ3ModHJhbnNmb3JtZXIpIHtcbiAgdm5vZGVBcmdzVHJhbnNmb3JtZXIgPSB0cmFuc2Zvcm1lcjtcbn1cbmNvbnN0IGNyZWF0ZVZOb2RlV2l0aEFyZ3NUcmFuc2Zvcm0gPSAoLi4uYXJncykgPT4ge1xuICByZXR1cm4gX2NyZWF0ZVZOb2RlKFxuICAgIC4uLnZub2RlQXJnc1RyYW5zZm9ybWVyID8gdm5vZGVBcmdzVHJhbnNmb3JtZXIoYXJncywgY3VycmVudFJlbmRlcmluZ0luc3RhbmNlKSA6IGFyZ3NcbiAgKTtcbn07XG5jb25zdCBub3JtYWxpemVLZXkgPSAoeyBrZXkgfSkgPT4ga2V5ICE9IG51bGwgPyBrZXkgOiBudWxsO1xuY29uc3Qgbm9ybWFsaXplUmVmID0gKHtcbiAgcmVmLFxuICByZWZfa2V5LFxuICByZWZfZm9yXG59KSA9PiB7XG4gIGlmICh0eXBlb2YgcmVmID09PSBcIm51bWJlclwiKSB7XG4gICAgcmVmID0gXCJcIiArIHJlZjtcbiAgfVxuICByZXR1cm4gcmVmICE9IG51bGwgPyBpc1N0cmluZyhyZWYpIHx8IGlzUmVmKHJlZikgfHwgaXNGdW5jdGlvbihyZWYpID8geyBpOiBjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UsIHI6IHJlZiwgazogcmVmX2tleSwgZjogISFyZWZfZm9yIH0gOiByZWYgOiBudWxsO1xufTtcbmZ1bmN0aW9uIGNyZWF0ZUJhc2VWTm9kZSh0eXBlLCBwcm9wcyA9IG51bGwsIGNoaWxkcmVuID0gbnVsbCwgcGF0Y2hGbGFnID0gMCwgZHluYW1pY1Byb3BzID0gbnVsbCwgc2hhcGVGbGFnID0gdHlwZSA9PT0gRnJhZ21lbnQgPyAwIDogMSwgaXNCbG9ja05vZGUgPSBmYWxzZSwgbmVlZEZ1bGxDaGlsZHJlbk5vcm1hbGl6YXRpb24gPSBmYWxzZSkge1xuICBjb25zdCB2bm9kZSA9IHtcbiAgICBfX3ZfaXNWTm9kZTogdHJ1ZSxcbiAgICBfX3Zfc2tpcDogdHJ1ZSxcbiAgICB0eXBlLFxuICAgIHByb3BzLFxuICAgIGtleTogcHJvcHMgJiYgbm9ybWFsaXplS2V5KHByb3BzKSxcbiAgICByZWY6IHByb3BzICYmIG5vcm1hbGl6ZVJlZihwcm9wcyksXG4gICAgc2NvcGVJZDogY3VycmVudFNjb3BlSWQsXG4gICAgc2xvdFNjb3BlSWRzOiBudWxsLFxuICAgIGNoaWxkcmVuLFxuICAgIGNvbXBvbmVudDogbnVsbCxcbiAgICBzdXNwZW5zZTogbnVsbCxcbiAgICBzc0NvbnRlbnQ6IG51bGwsXG4gICAgc3NGYWxsYmFjazogbnVsbCxcbiAgICBkaXJzOiBudWxsLFxuICAgIHRyYW5zaXRpb246IG51bGwsXG4gICAgZWw6IG51bGwsXG4gICAgYW5jaG9yOiBudWxsLFxuICAgIHRhcmdldDogbnVsbCxcbiAgICB0YXJnZXRTdGFydDogbnVsbCxcbiAgICB0YXJnZXRBbmNob3I6IG51bGwsXG4gICAgc3RhdGljQ291bnQ6IDAsXG4gICAgc2hhcGVGbGFnLFxuICAgIHBhdGNoRmxhZyxcbiAgICBkeW5hbWljUHJvcHMsXG4gICAgZHluYW1pY0NoaWxkcmVuOiBudWxsLFxuICAgIGFwcENvbnRleHQ6IG51bGwsXG4gICAgY3R4OiBjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2VcbiAgfTtcbiAgaWYgKG5lZWRGdWxsQ2hpbGRyZW5Ob3JtYWxpemF0aW9uKSB7XG4gICAgbm9ybWFsaXplQ2hpbGRyZW4odm5vZGUsIGNoaWxkcmVuKTtcbiAgICBpZiAoc2hhcGVGbGFnICYgMTI4KSB7XG4gICAgICB0eXBlLm5vcm1hbGl6ZSh2bm9kZSk7XG4gICAgfVxuICB9IGVsc2UgaWYgKGNoaWxkcmVuKSB7XG4gICAgdm5vZGUuc2hhcGVGbGFnIHw9IGlzU3RyaW5nKGNoaWxkcmVuKSA/IDggOiAxNjtcbiAgfVxuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB2bm9kZS5rZXkgIT09IHZub2RlLmtleSkge1xuICAgIHdhcm4kMShgVk5vZGUgY3JlYXRlZCB3aXRoIGludmFsaWQga2V5IChOYU4pLiBWTm9kZSB0eXBlOmAsIHZub2RlLnR5cGUpO1xuICB9XG4gIGlmIChpc0Jsb2NrVHJlZUVuYWJsZWQgPiAwICYmIC8vIGF2b2lkIGEgYmxvY2sgbm9kZSBmcm9tIHRyYWNraW5nIGl0c2VsZlxuICAhaXNCbG9ja05vZGUgJiYgLy8gaGFzIGN1cnJlbnQgcGFyZW50IGJsb2NrXG4gIGN1cnJlbnRCbG9jayAmJiAvLyBwcmVzZW5jZSBvZiBhIHBhdGNoIGZsYWcgaW5kaWNhdGVzIHRoaXMgbm9kZSBuZWVkcyBwYXRjaGluZyBvbiB1cGRhdGVzLlxuICAvLyBjb21wb25lbnQgbm9kZXMgYWxzbyBzaG91bGQgYWx3YXlzIGJlIHBhdGNoZWQsIGJlY2F1c2UgZXZlbiBpZiB0aGVcbiAgLy8gY29tcG9uZW50IGRvZXNuJ3QgbmVlZCB0byB1cGRhdGUsIGl0IG5lZWRzIHRvIHBlcnNpc3QgdGhlIGluc3RhbmNlIG9uIHRvXG4gIC8vIHRoZSBuZXh0IHZub2RlIHNvIHRoYXQgaXQgY2FuIGJlIHByb3Blcmx5IHVubW91bnRlZCBsYXRlci5cbiAgKHZub2RlLnBhdGNoRmxhZyA+IDAgfHwgc2hhcGVGbGFnICYgNikgJiYgLy8gdGhlIEVWRU5UUyBmbGFnIGlzIG9ubHkgZm9yIGh5ZHJhdGlvbiBhbmQgaWYgaXQgaXMgdGhlIG9ubHkgZmxhZywgdGhlXG4gIC8vIHZub2RlIHNob3VsZCBub3QgYmUgY29uc2lkZXJlZCBkeW5hbWljIGR1ZSB0byBoYW5kbGVyIGNhY2hpbmcuXG4gIHZub2RlLnBhdGNoRmxhZyAhPT0gMzIpIHtcbiAgICBjdXJyZW50QmxvY2sucHVzaCh2bm9kZSk7XG4gIH1cbiAgcmV0dXJuIHZub2RlO1xufVxuY29uc3QgY3JlYXRlVk5vZGUgPSAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gY3JlYXRlVk5vZGVXaXRoQXJnc1RyYW5zZm9ybSA6IF9jcmVhdGVWTm9kZTtcbmZ1bmN0aW9uIF9jcmVhdGVWTm9kZSh0eXBlLCBwcm9wcyA9IG51bGwsIGNoaWxkcmVuID0gbnVsbCwgcGF0Y2hGbGFnID0gMCwgZHluYW1pY1Byb3BzID0gbnVsbCwgaXNCbG9ja05vZGUgPSBmYWxzZSkge1xuICBpZiAoIXR5cGUgfHwgdHlwZSA9PT0gTlVMTF9EWU5BTUlDX0NPTVBPTkVOVCkge1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICF0eXBlKSB7XG4gICAgICB3YXJuJDEoYEludmFsaWQgdm5vZGUgdHlwZSB3aGVuIGNyZWF0aW5nIHZub2RlOiAke3R5cGV9LmApO1xuICAgIH1cbiAgICB0eXBlID0gQ29tbWVudDtcbiAgfVxuICBpZiAoaXNWTm9kZSh0eXBlKSkge1xuICAgIGNvbnN0IGNsb25lZCA9IGNsb25lVk5vZGUoXG4gICAgICB0eXBlLFxuICAgICAgcHJvcHMsXG4gICAgICB0cnVlXG4gICAgICAvKiBtZXJnZVJlZjogdHJ1ZSAqL1xuICAgICk7XG4gICAgaWYgKGNoaWxkcmVuKSB7XG4gICAgICBub3JtYWxpemVDaGlsZHJlbihjbG9uZWQsIGNoaWxkcmVuKTtcbiAgICB9XG4gICAgaWYgKGlzQmxvY2tUcmVlRW5hYmxlZCA+IDAgJiYgIWlzQmxvY2tOb2RlICYmIGN1cnJlbnRCbG9jaykge1xuICAgICAgaWYgKGNsb25lZC5zaGFwZUZsYWcgJiA2KSB7XG4gICAgICAgIGN1cnJlbnRCbG9ja1tjdXJyZW50QmxvY2suaW5kZXhPZih0eXBlKV0gPSBjbG9uZWQ7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjdXJyZW50QmxvY2sucHVzaChjbG9uZWQpO1xuICAgICAgfVxuICAgIH1cbiAgICBjbG9uZWQucGF0Y2hGbGFnID0gLTI7XG4gICAgcmV0dXJuIGNsb25lZDtcbiAgfVxuICBpZiAoaXNDbGFzc0NvbXBvbmVudCh0eXBlKSkge1xuICAgIHR5cGUgPSB0eXBlLl9fdmNjT3B0cztcbiAgfVxuICBpZiAocHJvcHMpIHtcbiAgICBwcm9wcyA9IGd1YXJkUmVhY3RpdmVQcm9wcyhwcm9wcyk7XG4gICAgbGV0IHsgY2xhc3M6IGtsYXNzLCBzdHlsZSB9ID0gcHJvcHM7XG4gICAgaWYgKGtsYXNzICYmICFpc1N0cmluZyhrbGFzcykpIHtcbiAgICAgIHByb3BzLmNsYXNzID0gbm9ybWFsaXplQ2xhc3Moa2xhc3MpO1xuICAgIH1cbiAgICBpZiAoaXNPYmplY3Qoc3R5bGUpKSB7XG4gICAgICBpZiAoaXNQcm94eShzdHlsZSkgJiYgIWlzQXJyYXkoc3R5bGUpKSB7XG4gICAgICAgIHN0eWxlID0gZXh0ZW5kKHt9LCBzdHlsZSk7XG4gICAgICB9XG4gICAgICBwcm9wcy5zdHlsZSA9IG5vcm1hbGl6ZVN0eWxlKHN0eWxlKTtcbiAgICB9XG4gIH1cbiAgY29uc3Qgc2hhcGVGbGFnID0gaXNTdHJpbmcodHlwZSkgPyAxIDogaXNTdXNwZW5zZSh0eXBlKSA/IDEyOCA6IGlzVGVsZXBvcnQodHlwZSkgPyA2NCA6IGlzT2JqZWN0KHR5cGUpID8gNCA6IGlzRnVuY3Rpb24odHlwZSkgPyAyIDogMDtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgc2hhcGVGbGFnICYgNCAmJiBpc1Byb3h5KHR5cGUpKSB7XG4gICAgdHlwZSA9IHRvUmF3KHR5cGUpO1xuICAgIHdhcm4kMShcbiAgICAgIGBWdWUgcmVjZWl2ZWQgYSBDb21wb25lbnQgdGhhdCB3YXMgbWFkZSBhIHJlYWN0aXZlIG9iamVjdC4gVGhpcyBjYW4gbGVhZCB0byB1bm5lY2Vzc2FyeSBwZXJmb3JtYW5jZSBvdmVyaGVhZCBhbmQgc2hvdWxkIGJlIGF2b2lkZWQgYnkgbWFya2luZyB0aGUgY29tcG9uZW50IHdpdGggXFxgbWFya1Jhd1xcYCBvciB1c2luZyBcXGBzaGFsbG93UmVmXFxgIGluc3RlYWQgb2YgXFxgcmVmXFxgLmAsXG4gICAgICBgXG5Db21wb25lbnQgdGhhdCB3YXMgbWFkZSByZWFjdGl2ZTogYCxcbiAgICAgIHR5cGVcbiAgICApO1xuICB9XG4gIHJldHVybiBjcmVhdGVCYXNlVk5vZGUoXG4gICAgdHlwZSxcbiAgICBwcm9wcyxcbiAgICBjaGlsZHJlbixcbiAgICBwYXRjaEZsYWcsXG4gICAgZHluYW1pY1Byb3BzLFxuICAgIHNoYXBlRmxhZyxcbiAgICBpc0Jsb2NrTm9kZSxcbiAgICB0cnVlXG4gICk7XG59XG5mdW5jdGlvbiBndWFyZFJlYWN0aXZlUHJvcHMocHJvcHMpIHtcbiAgaWYgKCFwcm9wcykgcmV0dXJuIG51bGw7XG4gIHJldHVybiBpc1Byb3h5KHByb3BzKSB8fCBpc0ludGVybmFsT2JqZWN0KHByb3BzKSA/IGV4dGVuZCh7fSwgcHJvcHMpIDogcHJvcHM7XG59XG5mdW5jdGlvbiBjbG9uZVZOb2RlKHZub2RlLCBleHRyYVByb3BzLCBtZXJnZVJlZiA9IGZhbHNlLCBjbG9uZVRyYW5zaXRpb24gPSBmYWxzZSkge1xuICBjb25zdCB7IHByb3BzLCByZWYsIHBhdGNoRmxhZywgY2hpbGRyZW4sIHRyYW5zaXRpb24gfSA9IHZub2RlO1xuICBjb25zdCBtZXJnZWRQcm9wcyA9IGV4dHJhUHJvcHMgPyBtZXJnZVByb3BzKHByb3BzIHx8IHt9LCBleHRyYVByb3BzKSA6IHByb3BzO1xuICBjb25zdCBjbG9uZWQgPSB7XG4gICAgX192X2lzVk5vZGU6IHRydWUsXG4gICAgX192X3NraXA6IHRydWUsXG4gICAgdHlwZTogdm5vZGUudHlwZSxcbiAgICBwcm9wczogbWVyZ2VkUHJvcHMsXG4gICAga2V5OiBtZXJnZWRQcm9wcyAmJiBub3JtYWxpemVLZXkobWVyZ2VkUHJvcHMpLFxuICAgIHJlZjogZXh0cmFQcm9wcyAmJiBleHRyYVByb3BzLnJlZiA/IChcbiAgICAgIC8vICMyMDc4IGluIHRoZSBjYXNlIG9mIDxjb21wb25lbnQgOmlzPVwidm5vZGVcIiByZWY9XCJleHRyYVwiLz5cbiAgICAgIC8vIGlmIHRoZSB2bm9kZSBpdHNlbGYgYWxyZWFkeSBoYXMgYSByZWYsIGNsb25lVk5vZGUgd2lsbCBuZWVkIHRvIG1lcmdlXG4gICAgICAvLyB0aGUgcmVmcyBzbyB0aGUgc2luZ2xlIHZub2RlIGNhbiBiZSBzZXQgb24gbXVsdGlwbGUgcmVmc1xuICAgICAgbWVyZ2VSZWYgJiYgcmVmID8gaXNBcnJheShyZWYpID8gcmVmLmNvbmNhdChub3JtYWxpemVSZWYoZXh0cmFQcm9wcykpIDogW3JlZiwgbm9ybWFsaXplUmVmKGV4dHJhUHJvcHMpXSA6IG5vcm1hbGl6ZVJlZihleHRyYVByb3BzKVxuICAgICkgOiByZWYsXG4gICAgc2NvcGVJZDogdm5vZGUuc2NvcGVJZCxcbiAgICBzbG90U2NvcGVJZHM6IHZub2RlLnNsb3RTY29wZUlkcyxcbiAgICBjaGlsZHJlbjogISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBwYXRjaEZsYWcgPT09IC0xICYmIGlzQXJyYXkoY2hpbGRyZW4pID8gY2hpbGRyZW4ubWFwKGRlZXBDbG9uZVZOb2RlKSA6IGNoaWxkcmVuLFxuICAgIHRhcmdldDogdm5vZGUudGFyZ2V0LFxuICAgIHRhcmdldFN0YXJ0OiB2bm9kZS50YXJnZXRTdGFydCxcbiAgICB0YXJnZXRBbmNob3I6IHZub2RlLnRhcmdldEFuY2hvcixcbiAgICBzdGF0aWNDb3VudDogdm5vZGUuc3RhdGljQ291bnQsXG4gICAgc2hhcGVGbGFnOiB2bm9kZS5zaGFwZUZsYWcsXG4gICAgLy8gaWYgdGhlIHZub2RlIGlzIGNsb25lZCB3aXRoIGV4dHJhIHByb3BzLCB3ZSBjYW4gbm8gbG9uZ2VyIGFzc3VtZSBpdHNcbiAgICAvLyBleGlzdGluZyBwYXRjaCBmbGFnIHRvIGJlIHJlbGlhYmxlIGFuZCBuZWVkIHRvIGFkZCB0aGUgRlVMTF9QUk9QUyBmbGFnLlxuICAgIC8vIG5vdGU6IHByZXNlcnZlIGZsYWcgZm9yIGZyYWdtZW50cyBzaW5jZSB0aGV5IHVzZSB0aGUgZmxhZyBmb3IgY2hpbGRyZW5cbiAgICAvLyBmYXN0IHBhdGhzIG9ubHkuXG4gICAgcGF0Y2hGbGFnOiBleHRyYVByb3BzICYmIHZub2RlLnR5cGUgIT09IEZyYWdtZW50ID8gcGF0Y2hGbGFnID09PSAtMSA/IDE2IDogcGF0Y2hGbGFnIHwgMTYgOiBwYXRjaEZsYWcsXG4gICAgZHluYW1pY1Byb3BzOiB2bm9kZS5keW5hbWljUHJvcHMsXG4gICAgZHluYW1pY0NoaWxkcmVuOiB2bm9kZS5keW5hbWljQ2hpbGRyZW4sXG4gICAgYXBwQ29udGV4dDogdm5vZGUuYXBwQ29udGV4dCxcbiAgICBkaXJzOiB2bm9kZS5kaXJzLFxuICAgIHRyYW5zaXRpb24sXG4gICAgLy8gVGhlc2Ugc2hvdWxkIHRlY2huaWNhbGx5IG9ubHkgYmUgbm9uLW51bGwgb24gbW91bnRlZCBWTm9kZXMuIEhvd2V2ZXIsXG4gICAgLy8gdGhleSAqc2hvdWxkKiBiZSBjb3BpZWQgZm9yIGtlcHQtYWxpdmUgdm5vZGVzLiBTbyB3ZSBqdXN0IGFsd2F5cyBjb3B5XG4gICAgLy8gdGhlbSBzaW5jZSB0aGVtIGJlaW5nIG5vbi1udWxsIGR1cmluZyBhIG1vdW50IGRvZXNuJ3QgYWZmZWN0IHRoZSBsb2dpYyBhc1xuICAgIC8vIHRoZXkgd2lsbCBzaW1wbHkgYmUgb3ZlcndyaXR0ZW4uXG4gICAgY29tcG9uZW50OiB2bm9kZS5jb21wb25lbnQsXG4gICAgc3VzcGVuc2U6IHZub2RlLnN1c3BlbnNlLFxuICAgIHNzQ29udGVudDogdm5vZGUuc3NDb250ZW50ICYmIGNsb25lVk5vZGUodm5vZGUuc3NDb250ZW50KSxcbiAgICBzc0ZhbGxiYWNrOiB2bm9kZS5zc0ZhbGxiYWNrICYmIGNsb25lVk5vZGUodm5vZGUuc3NGYWxsYmFjayksXG4gICAgcGxhY2Vob2xkZXI6IHZub2RlLnBsYWNlaG9sZGVyLFxuICAgIGVsOiB2bm9kZS5lbCxcbiAgICBhbmNob3I6IHZub2RlLmFuY2hvcixcbiAgICBjdHg6IHZub2RlLmN0eCxcbiAgICBjZTogdm5vZGUuY2VcbiAgfTtcbiAgaWYgKHRyYW5zaXRpb24gJiYgY2xvbmVUcmFuc2l0aW9uKSB7XG4gICAgc2V0VHJhbnNpdGlvbkhvb2tzKFxuICAgICAgY2xvbmVkLFxuICAgICAgdHJhbnNpdGlvbi5jbG9uZShjbG9uZWQpXG4gICAgKTtcbiAgfVxuICByZXR1cm4gY2xvbmVkO1xufVxuZnVuY3Rpb24gZGVlcENsb25lVk5vZGUodm5vZGUpIHtcbiAgY29uc3QgY2xvbmVkID0gY2xvbmVWTm9kZSh2bm9kZSk7XG4gIGlmIChpc0FycmF5KHZub2RlLmNoaWxkcmVuKSkge1xuICAgIGNsb25lZC5jaGlsZHJlbiA9IHZub2RlLmNoaWxkcmVuLm1hcChkZWVwQ2xvbmVWTm9kZSk7XG4gIH1cbiAgcmV0dXJuIGNsb25lZDtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVRleHRWTm9kZSh0ZXh0ID0gXCIgXCIsIGZsYWcgPSAwKSB7XG4gIHJldHVybiBjcmVhdGVWTm9kZShUZXh0LCBudWxsLCB0ZXh0LCBmbGFnKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVN0YXRpY1ZOb2RlKGNvbnRlbnQsIG51bWJlck9mTm9kZXMpIHtcbiAgY29uc3Qgdm5vZGUgPSBjcmVhdGVWTm9kZShTdGF0aWMsIG51bGwsIGNvbnRlbnQpO1xuICB2bm9kZS5zdGF0aWNDb3VudCA9IG51bWJlck9mTm9kZXM7XG4gIHJldHVybiB2bm9kZTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUNvbW1lbnRWTm9kZSh0ZXh0ID0gXCJcIiwgYXNCbG9jayA9IGZhbHNlKSB7XG4gIHJldHVybiBhc0Jsb2NrID8gKG9wZW5CbG9jaygpLCBjcmVhdGVCbG9jayhDb21tZW50LCBudWxsLCB0ZXh0KSkgOiBjcmVhdGVWTm9kZShDb21tZW50LCBudWxsLCB0ZXh0KTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZVZOb2RlKGNoaWxkKSB7XG4gIGlmIChjaGlsZCA9PSBudWxsIHx8IHR5cGVvZiBjaGlsZCA9PT0gXCJib29sZWFuXCIpIHtcbiAgICByZXR1cm4gY3JlYXRlVk5vZGUoQ29tbWVudCk7XG4gIH0gZWxzZSBpZiAoaXNBcnJheShjaGlsZCkpIHtcbiAgICByZXR1cm4gY3JlYXRlVk5vZGUoXG4gICAgICBGcmFnbWVudCxcbiAgICAgIG51bGwsXG4gICAgICAvLyAjMzY2NiwgYXZvaWQgcmVmZXJlbmNlIHBvbGx1dGlvbiB3aGVuIHJldXNpbmcgdm5vZGVcbiAgICAgIGNoaWxkLnNsaWNlKClcbiAgICApO1xuICB9IGVsc2UgaWYgKGlzVk5vZGUoY2hpbGQpKSB7XG4gICAgcmV0dXJuIGNsb25lSWZNb3VudGVkKGNoaWxkKTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gY3JlYXRlVk5vZGUoVGV4dCwgbnVsbCwgU3RyaW5nKGNoaWxkKSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGNsb25lSWZNb3VudGVkKGNoaWxkKSB7XG4gIHJldHVybiBjaGlsZC5lbCA9PT0gbnVsbCAmJiBjaGlsZC5wYXRjaEZsYWcgIT09IC0xIHx8IGNoaWxkLm1lbW8gPyBjaGlsZCA6IGNsb25lVk5vZGUoY2hpbGQpO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplQ2hpbGRyZW4odm5vZGUsIGNoaWxkcmVuKSB7XG4gIGxldCB0eXBlID0gMDtcbiAgY29uc3QgeyBzaGFwZUZsYWcgfSA9IHZub2RlO1xuICBpZiAoY2hpbGRyZW4gPT0gbnVsbCkge1xuICAgIGNoaWxkcmVuID0gbnVsbDtcbiAgfSBlbHNlIGlmIChpc0FycmF5KGNoaWxkcmVuKSkge1xuICAgIHR5cGUgPSAxNjtcbiAgfSBlbHNlIGlmICh0eXBlb2YgY2hpbGRyZW4gPT09IFwib2JqZWN0XCIpIHtcbiAgICBpZiAoc2hhcGVGbGFnICYgKDEgfCA2NCkpIHtcbiAgICAgIGNvbnN0IHNsb3QgPSBjaGlsZHJlbi5kZWZhdWx0O1xuICAgICAgaWYgKHNsb3QpIHtcbiAgICAgICAgc2xvdC5fYyAmJiAoc2xvdC5fZCA9IGZhbHNlKTtcbiAgICAgICAgbm9ybWFsaXplQ2hpbGRyZW4odm5vZGUsIHNsb3QoKSk7XG4gICAgICAgIHNsb3QuX2MgJiYgKHNsb3QuX2QgPSB0cnVlKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9IGVsc2Uge1xuICAgICAgdHlwZSA9IDMyO1xuICAgICAgY29uc3Qgc2xvdEZsYWcgPSBjaGlsZHJlbi5fO1xuICAgICAgaWYgKCFzbG90RmxhZyAmJiAhaXNJbnRlcm5hbE9iamVjdChjaGlsZHJlbikpIHtcbiAgICAgICAgY2hpbGRyZW4uX2N0eCA9IGN1cnJlbnRSZW5kZXJpbmdJbnN0YW5jZTtcbiAgICAgIH0gZWxzZSBpZiAoc2xvdEZsYWcgPT09IDMgJiYgY3VycmVudFJlbmRlcmluZ0luc3RhbmNlKSB7XG4gICAgICAgIGlmIChjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2Uuc2xvdHMuXyA9PT0gMSkge1xuICAgICAgICAgIGNoaWxkcmVuLl8gPSAxO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNoaWxkcmVuLl8gPSAyO1xuICAgICAgICAgIHZub2RlLnBhdGNoRmxhZyB8PSAxMDI0O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9IGVsc2UgaWYgKGlzRnVuY3Rpb24oY2hpbGRyZW4pKSB7XG4gICAgaWYgKHNoYXBlRmxhZyAmICgxIHwgNjQpKSB7XG4gICAgICBub3JtYWxpemVDaGlsZHJlbih2bm9kZSwgeyBkZWZhdWx0OiBjaGlsZHJlbiB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY2hpbGRyZW4gPSB7IGRlZmF1bHQ6IGNoaWxkcmVuLCBfY3R4OiBjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UgfTtcbiAgICB0eXBlID0gMzI7XG4gIH0gZWxzZSB7XG4gICAgY2hpbGRyZW4gPSBTdHJpbmcoY2hpbGRyZW4pO1xuICAgIGlmIChzaGFwZUZsYWcgJiA2NCkge1xuICAgICAgdHlwZSA9IDE2O1xuICAgICAgY2hpbGRyZW4gPSBbY3JlYXRlVGV4dFZOb2RlKGNoaWxkcmVuKV07XG4gICAgfSBlbHNlIHtcbiAgICAgIHR5cGUgPSA4O1xuICAgIH1cbiAgfVxuICB2bm9kZS5jaGlsZHJlbiA9IGNoaWxkcmVuO1xuICB2bm9kZS5zaGFwZUZsYWcgfD0gdHlwZTtcbn1cbmZ1bmN0aW9uIG1lcmdlUHJvcHMoLi4uYXJncykge1xuICBjb25zdCByZXQgPSB7fTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBhcmdzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgdG9NZXJnZSA9IGFyZ3NbaV07XG4gICAgZm9yIChjb25zdCBrZXkgaW4gdG9NZXJnZSkge1xuICAgICAgaWYgKGtleSA9PT0gXCJjbGFzc1wiKSB7XG4gICAgICAgIGlmIChyZXQuY2xhc3MgIT09IHRvTWVyZ2UuY2xhc3MpIHtcbiAgICAgICAgICByZXQuY2xhc3MgPSBub3JtYWxpemVDbGFzcyhbcmV0LmNsYXNzLCB0b01lcmdlLmNsYXNzXSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoa2V5ID09PSBcInN0eWxlXCIpIHtcbiAgICAgICAgcmV0LnN0eWxlID0gbm9ybWFsaXplU3R5bGUoW3JldC5zdHlsZSwgdG9NZXJnZS5zdHlsZV0pO1xuICAgICAgfSBlbHNlIGlmIChpc09uKGtleSkpIHtcbiAgICAgICAgY29uc3QgZXhpc3RpbmcgPSByZXRba2V5XTtcbiAgICAgICAgY29uc3QgaW5jb21pbmcgPSB0b01lcmdlW2tleV07XG4gICAgICAgIGlmIChpbmNvbWluZyAmJiBleGlzdGluZyAhPT0gaW5jb21pbmcgJiYgIShpc0FycmF5KGV4aXN0aW5nKSAmJiBleGlzdGluZy5pbmNsdWRlcyhpbmNvbWluZykpKSB7XG4gICAgICAgICAgcmV0W2tleV0gPSBleGlzdGluZyA/IFtdLmNvbmNhdChleGlzdGluZywgaW5jb21pbmcpIDogaW5jb21pbmc7XG4gICAgICAgIH0gZWxzZSBpZiAoaW5jb21pbmcgPT0gbnVsbCAmJiBleGlzdGluZyA9PSBudWxsICYmIC8vIG1lcmdlUHJvcHMoeyAnb25VcGRhdGU6bW9kZWxWYWx1ZSc6IHVuZGVmaW5lZCB9KSBzaG91bGQgbm90IHJldGFpblxuICAgICAgICAvLyB0aGUgbW9kZWwgbGlzdGVuZXIuXG4gICAgICAgICFpc01vZGVsTGlzdGVuZXIoa2V5KSkge1xuICAgICAgICAgIHJldFtrZXldID0gaW5jb21pbmc7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoa2V5ICE9PSBcIlwiKSB7XG4gICAgICAgIHJldFtrZXldID0gdG9NZXJnZVtrZXldO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gcmV0O1xufVxuZnVuY3Rpb24gaW52b2tlVk5vZGVIb29rKGhvb2ssIGluc3RhbmNlLCB2bm9kZSwgcHJldlZOb2RlID0gbnVsbCkge1xuICBjYWxsV2l0aEFzeW5jRXJyb3JIYW5kbGluZyhob29rLCBpbnN0YW5jZSwgNywgW1xuICAgIHZub2RlLFxuICAgIHByZXZWTm9kZVxuICBdKTtcbn1cblxuY29uc3QgZW1wdHlBcHBDb250ZXh0ID0gY3JlYXRlQXBwQ29udGV4dCgpO1xubGV0IHVpZCA9IDA7XG5mdW5jdGlvbiBjcmVhdGVDb21wb25lbnRJbnN0YW5jZSh2bm9kZSwgcGFyZW50LCBzdXNwZW5zZSkge1xuICBjb25zdCB0eXBlID0gdm5vZGUudHlwZTtcbiAgY29uc3QgYXBwQ29udGV4dCA9IChwYXJlbnQgPyBwYXJlbnQuYXBwQ29udGV4dCA6IHZub2RlLmFwcENvbnRleHQpIHx8IGVtcHR5QXBwQ29udGV4dDtcbiAgY29uc3QgaW5zdGFuY2UgPSB7XG4gICAgdWlkOiB1aWQrKyxcbiAgICB2bm9kZSxcbiAgICB0eXBlLFxuICAgIHBhcmVudCxcbiAgICBhcHBDb250ZXh0LFxuICAgIHJvb3Q6IG51bGwsXG4gICAgLy8gdG8gYmUgaW1tZWRpYXRlbHkgc2V0XG4gICAgbmV4dDogbnVsbCxcbiAgICBzdWJUcmVlOiBudWxsLFxuICAgIC8vIHdpbGwgYmUgc2V0IHN5bmNocm9ub3VzbHkgcmlnaHQgYWZ0ZXIgY3JlYXRpb25cbiAgICBlZmZlY3Q6IG51bGwsXG4gICAgdXBkYXRlOiBudWxsLFxuICAgIC8vIHdpbGwgYmUgc2V0IHN5bmNocm9ub3VzbHkgcmlnaHQgYWZ0ZXIgY3JlYXRpb25cbiAgICBqb2I6IG51bGwsXG4gICAgc2NvcGU6IG5ldyBFZmZlY3RTY29wZShcbiAgICAgIHRydWVcbiAgICAgIC8qIGRldGFjaGVkICovXG4gICAgKSxcbiAgICByZW5kZXI6IG51bGwsXG4gICAgcHJveHk6IG51bGwsXG4gICAgZXhwb3NlZDogbnVsbCxcbiAgICBleHBvc2VQcm94eTogbnVsbCxcbiAgICB3aXRoUHJveHk6IG51bGwsXG4gICAgcHJvdmlkZXM6IHBhcmVudCA/IHBhcmVudC5wcm92aWRlcyA6IE9iamVjdC5jcmVhdGUoYXBwQ29udGV4dC5wcm92aWRlcyksXG4gICAgaWRzOiBwYXJlbnQgPyBwYXJlbnQuaWRzIDogW1wiXCIsIDAsIDBdLFxuICAgIGFjY2Vzc0NhY2hlOiBudWxsLFxuICAgIHJlbmRlckNhY2hlOiBbXSxcbiAgICAvLyBsb2NhbCByZXNvbHZlZCBhc3NldHNcbiAgICBjb21wb25lbnRzOiBudWxsLFxuICAgIGRpcmVjdGl2ZXM6IG51bGwsXG4gICAgLy8gcmVzb2x2ZWQgcHJvcHMgYW5kIGVtaXRzIG9wdGlvbnNcbiAgICBwcm9wc09wdGlvbnM6IG5vcm1hbGl6ZVByb3BzT3B0aW9ucyh0eXBlLCBhcHBDb250ZXh0KSxcbiAgICBlbWl0c09wdGlvbnM6IG5vcm1hbGl6ZUVtaXRzT3B0aW9ucyh0eXBlLCBhcHBDb250ZXh0KSxcbiAgICAvLyBlbWl0XG4gICAgZW1pdDogbnVsbCxcbiAgICAvLyB0byBiZSBzZXQgaW1tZWRpYXRlbHlcbiAgICBlbWl0dGVkOiBudWxsLFxuICAgIC8vIHByb3BzIGRlZmF1bHQgdmFsdWVcbiAgICBwcm9wc0RlZmF1bHRzOiBFTVBUWV9PQkosXG4gICAgLy8gaW5oZXJpdEF0dHJzXG4gICAgaW5oZXJpdEF0dHJzOiB0eXBlLmluaGVyaXRBdHRycyxcbiAgICAvLyBzdGF0ZVxuICAgIGN0eDogRU1QVFlfT0JKLFxuICAgIGRhdGE6IEVNUFRZX09CSixcbiAgICBwcm9wczogRU1QVFlfT0JKLFxuICAgIGF0dHJzOiBFTVBUWV9PQkosXG4gICAgc2xvdHM6IEVNUFRZX09CSixcbiAgICByZWZzOiBFTVBUWV9PQkosXG4gICAgc2V0dXBTdGF0ZTogRU1QVFlfT0JKLFxuICAgIHNldHVwQ29udGV4dDogbnVsbCxcbiAgICAvLyBzdXNwZW5zZSByZWxhdGVkXG4gICAgc3VzcGVuc2UsXG4gICAgc3VzcGVuc2VJZDogc3VzcGVuc2UgPyBzdXNwZW5zZS5wZW5kaW5nSWQgOiAwLFxuICAgIGFzeW5jRGVwOiBudWxsLFxuICAgIGFzeW5jUmVzb2x2ZWQ6IGZhbHNlLFxuICAgIC8vIGxpZmVjeWNsZSBob29rc1xuICAgIC8vIG5vdCB1c2luZyBlbnVtcyBoZXJlIGJlY2F1c2UgaXQgcmVzdWx0cyBpbiBjb21wdXRlZCBwcm9wZXJ0aWVzXG4gICAgaXNNb3VudGVkOiBmYWxzZSxcbiAgICBpc1VubW91bnRlZDogZmFsc2UsXG4gICAgaXNEZWFjdGl2YXRlZDogZmFsc2UsXG4gICAgYmM6IG51bGwsXG4gICAgYzogbnVsbCxcbiAgICBibTogbnVsbCxcbiAgICBtOiBudWxsLFxuICAgIGJ1OiBudWxsLFxuICAgIHU6IG51bGwsXG4gICAgdW06IG51bGwsXG4gICAgYnVtOiBudWxsLFxuICAgIGRhOiBudWxsLFxuICAgIGE6IG51bGwsXG4gICAgcnRnOiBudWxsLFxuICAgIHJ0YzogbnVsbCxcbiAgICBlYzogbnVsbCxcbiAgICBzcDogbnVsbFxuICB9O1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIGluc3RhbmNlLmN0eCA9IGNyZWF0ZURldlJlbmRlckNvbnRleHQoaW5zdGFuY2UpO1xuICB9IGVsc2Uge1xuICAgIGluc3RhbmNlLmN0eCA9IHsgXzogaW5zdGFuY2UgfTtcbiAgfVxuICBpbnN0YW5jZS5yb290ID0gcGFyZW50ID8gcGFyZW50LnJvb3QgOiBpbnN0YW5jZTtcbiAgaW5zdGFuY2UuZW1pdCA9IGVtaXQuYmluZChudWxsLCBpbnN0YW5jZSk7XG4gIGlmICh2bm9kZS5jZSkge1xuICAgIHZub2RlLmNlKGluc3RhbmNlKTtcbiAgfVxuICByZXR1cm4gaW5zdGFuY2U7XG59XG5sZXQgY3VycmVudEluc3RhbmNlID0gbnVsbDtcbmNvbnN0IGdldEN1cnJlbnRJbnN0YW5jZSA9ICgpID0+IGN1cnJlbnRJbnN0YW5jZSB8fCBjdXJyZW50UmVuZGVyaW5nSW5zdGFuY2U7XG5sZXQgaW50ZXJuYWxTZXRDdXJyZW50SW5zdGFuY2U7XG5sZXQgc2V0SW5TU1JTZXR1cFN0YXRlO1xue1xuICBjb25zdCBnID0gZ2V0R2xvYmFsVGhpcygpO1xuICBjb25zdCByZWdpc3Rlckdsb2JhbFNldHRlciA9IChrZXksIHNldHRlcikgPT4ge1xuICAgIGxldCBzZXR0ZXJzO1xuICAgIGlmICghKHNldHRlcnMgPSBnW2tleV0pKSBzZXR0ZXJzID0gZ1trZXldID0gW107XG4gICAgc2V0dGVycy5wdXNoKHNldHRlcik7XG4gICAgcmV0dXJuICh2KSA9PiB7XG4gICAgICBpZiAoc2V0dGVycy5sZW5ndGggPiAxKSBzZXR0ZXJzLmZvckVhY2goKHNldCkgPT4gc2V0KHYpKTtcbiAgICAgIGVsc2Ugc2V0dGVyc1swXSh2KTtcbiAgICB9O1xuICB9O1xuICBpbnRlcm5hbFNldEN1cnJlbnRJbnN0YW5jZSA9IHJlZ2lzdGVyR2xvYmFsU2V0dGVyKFxuICAgIGBfX1ZVRV9JTlNUQU5DRV9TRVRURVJTX19gLFxuICAgICh2KSA9PiBjdXJyZW50SW5zdGFuY2UgPSB2XG4gICk7XG4gIHNldEluU1NSU2V0dXBTdGF0ZSA9IHJlZ2lzdGVyR2xvYmFsU2V0dGVyKFxuICAgIGBfX1ZVRV9TU1JfU0VUVEVSU19fYCxcbiAgICAodikgPT4gaXNJblNTUkNvbXBvbmVudFNldHVwID0gdlxuICApO1xufVxuY29uc3Qgc2V0Q3VycmVudEluc3RhbmNlID0gKGluc3RhbmNlKSA9PiB7XG4gIGNvbnN0IHByZXYgPSBjdXJyZW50SW5zdGFuY2U7XG4gIGludGVybmFsU2V0Q3VycmVudEluc3RhbmNlKGluc3RhbmNlKTtcbiAgaW5zdGFuY2Uuc2NvcGUub24oKTtcbiAgcmV0dXJuICgpID0+IHtcbiAgICBpbnN0YW5jZS5zY29wZS5vZmYoKTtcbiAgICBpbnRlcm5hbFNldEN1cnJlbnRJbnN0YW5jZShwcmV2KTtcbiAgfTtcbn07XG5jb25zdCB1bnNldEN1cnJlbnRJbnN0YW5jZSA9ICgpID0+IHtcbiAgY3VycmVudEluc3RhbmNlICYmIGN1cnJlbnRJbnN0YW5jZS5zY29wZS5vZmYoKTtcbiAgaW50ZXJuYWxTZXRDdXJyZW50SW5zdGFuY2UobnVsbCk7XG59O1xuY29uc3QgaXNCdWlsdEluVGFnID0gLyogQF9fUFVSRV9fICovIG1ha2VNYXAoXCJzbG90LGNvbXBvbmVudFwiKTtcbmZ1bmN0aW9uIHZhbGlkYXRlQ29tcG9uZW50TmFtZShuYW1lLCB7IGlzTmF0aXZlVGFnIH0pIHtcbiAgaWYgKGlzQnVpbHRJblRhZyhuYW1lKSB8fCBpc05hdGl2ZVRhZyhuYW1lKSkge1xuICAgIHdhcm4kMShcbiAgICAgIFwiRG8gbm90IHVzZSBidWlsdC1pbiBvciByZXNlcnZlZCBIVE1MIGVsZW1lbnRzIGFzIGNvbXBvbmVudCBpZDogXCIgKyBuYW1lXG4gICAgKTtcbiAgfVxufVxuZnVuY3Rpb24gaXNTdGF0ZWZ1bENvbXBvbmVudChpbnN0YW5jZSkge1xuICByZXR1cm4gaW5zdGFuY2Uudm5vZGUuc2hhcGVGbGFnICYgNDtcbn1cbmxldCBpc0luU1NSQ29tcG9uZW50U2V0dXAgPSBmYWxzZTtcbmZ1bmN0aW9uIHNldHVwQ29tcG9uZW50KGluc3RhbmNlLCBpc1NTUiA9IGZhbHNlLCBvcHRpbWl6ZWQgPSBmYWxzZSkge1xuICBpc1NTUiAmJiBzZXRJblNTUlNldHVwU3RhdGUoaXNTU1IpO1xuICBjb25zdCB7IHByb3BzLCBjaGlsZHJlbiB9ID0gaW5zdGFuY2Uudm5vZGU7XG4gIGNvbnN0IGlzU3RhdGVmdWwgPSBpc1N0YXRlZnVsQ29tcG9uZW50KGluc3RhbmNlKTtcbiAgaW5pdFByb3BzKGluc3RhbmNlLCBwcm9wcywgaXNTdGF0ZWZ1bCwgaXNTU1IpO1xuICBpbml0U2xvdHMoaW5zdGFuY2UsIGNoaWxkcmVuLCBvcHRpbWl6ZWQgfHwgaXNTU1IpO1xuICBjb25zdCBzZXR1cFJlc3VsdCA9IGlzU3RhdGVmdWwgPyBzZXR1cFN0YXRlZnVsQ29tcG9uZW50KGluc3RhbmNlLCBpc1NTUikgOiB2b2lkIDA7XG4gIGlzU1NSICYmIHNldEluU1NSU2V0dXBTdGF0ZShmYWxzZSk7XG4gIHJldHVybiBzZXR1cFJlc3VsdDtcbn1cbmZ1bmN0aW9uIHNldHVwU3RhdGVmdWxDb21wb25lbnQoaW5zdGFuY2UsIGlzU1NSKSB7XG4gIGNvbnN0IENvbXBvbmVudCA9IGluc3RhbmNlLnR5cGU7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgaWYgKENvbXBvbmVudC5uYW1lKSB7XG4gICAgICB2YWxpZGF0ZUNvbXBvbmVudE5hbWUoQ29tcG9uZW50Lm5hbWUsIGluc3RhbmNlLmFwcENvbnRleHQuY29uZmlnKTtcbiAgICB9XG4gICAgaWYgKENvbXBvbmVudC5jb21wb25lbnRzKSB7XG4gICAgICBjb25zdCBuYW1lcyA9IE9iamVjdC5rZXlzKENvbXBvbmVudC5jb21wb25lbnRzKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbmFtZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgdmFsaWRhdGVDb21wb25lbnROYW1lKG5hbWVzW2ldLCBpbnN0YW5jZS5hcHBDb250ZXh0LmNvbmZpZyk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChDb21wb25lbnQuZGlyZWN0aXZlcykge1xuICAgICAgY29uc3QgbmFtZXMgPSBPYmplY3Qua2V5cyhDb21wb25lbnQuZGlyZWN0aXZlcyk7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG5hbWVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHZhbGlkYXRlRGlyZWN0aXZlTmFtZShuYW1lc1tpXSk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChDb21wb25lbnQuY29tcGlsZXJPcHRpb25zICYmIGlzUnVudGltZU9ubHkoKSkge1xuICAgICAgd2FybiQxKFxuICAgICAgICBgXCJjb21waWxlck9wdGlvbnNcIiBpcyBvbmx5IHN1cHBvcnRlZCB3aGVuIHVzaW5nIGEgYnVpbGQgb2YgVnVlIHRoYXQgaW5jbHVkZXMgdGhlIHJ1bnRpbWUgY29tcGlsZXIuIFNpbmNlIHlvdSBhcmUgdXNpbmcgYSBydW50aW1lLW9ubHkgYnVpbGQsIHRoZSBvcHRpb25zIHNob3VsZCBiZSBwYXNzZWQgdmlhIHlvdXIgYnVpbGQgdG9vbCBjb25maWcgaW5zdGVhZC5gXG4gICAgICApO1xuICAgIH1cbiAgfVxuICBpbnN0YW5jZS5hY2Nlc3NDYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBpbnN0YW5jZS5wcm94eSA9IG5ldyBQcm94eShpbnN0YW5jZS5jdHgsIFB1YmxpY0luc3RhbmNlUHJveHlIYW5kbGVycyk7XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgZXhwb3NlUHJvcHNPblJlbmRlckNvbnRleHQoaW5zdGFuY2UpO1xuICB9XG4gIGNvbnN0IHsgc2V0dXAgfSA9IENvbXBvbmVudDtcbiAgaWYgKHNldHVwKSB7XG4gICAgcGF1c2VUcmFja2luZygpO1xuICAgIGNvbnN0IHNldHVwQ29udGV4dCA9IGluc3RhbmNlLnNldHVwQ29udGV4dCA9IHNldHVwLmxlbmd0aCA+IDEgPyBjcmVhdGVTZXR1cENvbnRleHQoaW5zdGFuY2UpIDogbnVsbDtcbiAgICBjb25zdCByZXNldCA9IHNldEN1cnJlbnRJbnN0YW5jZShpbnN0YW5jZSk7XG4gICAgY29uc3Qgc2V0dXBSZXN1bHQgPSBjYWxsV2l0aEVycm9ySGFuZGxpbmcoXG4gICAgICBzZXR1cCxcbiAgICAgIGluc3RhbmNlLFxuICAgICAgMCxcbiAgICAgIFtcbiAgICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IHNoYWxsb3dSZWFkb25seShpbnN0YW5jZS5wcm9wcykgOiBpbnN0YW5jZS5wcm9wcyxcbiAgICAgICAgc2V0dXBDb250ZXh0XG4gICAgICBdXG4gICAgKTtcbiAgICBjb25zdCBpc0FzeW5jU2V0dXAgPSBpc1Byb21pc2Uoc2V0dXBSZXN1bHQpO1xuICAgIHJlc2V0VHJhY2tpbmcoKTtcbiAgICByZXNldCgpO1xuICAgIGlmICgoaXNBc3luY1NldHVwIHx8IGluc3RhbmNlLnNwKSAmJiAhaXNBc3luY1dyYXBwZXIoaW5zdGFuY2UpKSB7XG4gICAgICBtYXJrQXN5bmNCb3VuZGFyeShpbnN0YW5jZSk7XG4gICAgfVxuICAgIGlmIChpc0FzeW5jU2V0dXApIHtcbiAgICAgIHNldHVwUmVzdWx0LnRoZW4odW5zZXRDdXJyZW50SW5zdGFuY2UsIHVuc2V0Q3VycmVudEluc3RhbmNlKTtcbiAgICAgIGlmIChpc1NTUikge1xuICAgICAgICByZXR1cm4gc2V0dXBSZXN1bHQudGhlbigocmVzb2x2ZWRSZXN1bHQpID0+IHtcbiAgICAgICAgICBoYW5kbGVTZXR1cFJlc3VsdChpbnN0YW5jZSwgcmVzb2x2ZWRSZXN1bHQsIGlzU1NSKTtcbiAgICAgICAgfSkuY2F0Y2goKGUpID0+IHtcbiAgICAgICAgICBoYW5kbGVFcnJvcihlLCBpbnN0YW5jZSwgMCk7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaW5zdGFuY2UuYXN5bmNEZXAgPSBzZXR1cFJlc3VsdDtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWluc3RhbmNlLnN1c3BlbnNlKSB7XG4gICAgICAgICAgY29uc3QgbmFtZSA9IGZvcm1hdENvbXBvbmVudE5hbWUoaW5zdGFuY2UsIENvbXBvbmVudCk7XG4gICAgICAgICAgd2FybiQxKFxuICAgICAgICAgICAgYENvbXBvbmVudCA8JHtuYW1lfT46IHNldHVwIGZ1bmN0aW9uIHJldHVybmVkIGEgcHJvbWlzZSwgYnV0IG5vIDxTdXNwZW5zZT4gYm91bmRhcnkgd2FzIGZvdW5kIGluIHRoZSBwYXJlbnQgY29tcG9uZW50IHRyZWUuIEEgY29tcG9uZW50IHdpdGggYXN5bmMgc2V0dXAoKSBtdXN0IGJlIG5lc3RlZCBpbiBhIDxTdXNwZW5zZT4gaW4gb3JkZXIgdG8gYmUgcmVuZGVyZWQuYFxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgaGFuZGxlU2V0dXBSZXN1bHQoaW5zdGFuY2UsIHNldHVwUmVzdWx0LCBpc1NTUik7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIGZpbmlzaENvbXBvbmVudFNldHVwKGluc3RhbmNlLCBpc1NTUik7XG4gIH1cbn1cbmZ1bmN0aW9uIGhhbmRsZVNldHVwUmVzdWx0KGluc3RhbmNlLCBzZXR1cFJlc3VsdCwgaXNTU1IpIHtcbiAgaWYgKGlzRnVuY3Rpb24oc2V0dXBSZXN1bHQpKSB7XG4gICAgaWYgKGluc3RhbmNlLnR5cGUuX19zc3JJbmxpbmVSZW5kZXIpIHtcbiAgICAgIGluc3RhbmNlLnNzclJlbmRlciA9IHNldHVwUmVzdWx0O1xuICAgIH0gZWxzZSB7XG4gICAgICBpbnN0YW5jZS5yZW5kZXIgPSBzZXR1cFJlc3VsdDtcbiAgICB9XG4gIH0gZWxzZSBpZiAoaXNPYmplY3Qoc2V0dXBSZXN1bHQpKSB7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgaXNWTm9kZShzZXR1cFJlc3VsdCkpIHtcbiAgICAgIHdhcm4kMShcbiAgICAgICAgYHNldHVwKCkgc2hvdWxkIG5vdCByZXR1cm4gVk5vZGVzIGRpcmVjdGx5IC0gcmV0dXJuIGEgcmVuZGVyIGZ1bmN0aW9uIGluc3RlYWQuYFxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgX19WVUVfUFJPRF9ERVZUT09MU19fKSB7XG4gICAgICBpbnN0YW5jZS5kZXZ0b29sc1Jhd1NldHVwU3RhdGUgPSBzZXR1cFJlc3VsdDtcbiAgICB9XG4gICAgaW5zdGFuY2Uuc2V0dXBTdGF0ZSA9IHByb3h5UmVmcyhzZXR1cFJlc3VsdCk7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgIGV4cG9zZVNldHVwU3RhdGVPblJlbmRlckNvbnRleHQoaW5zdGFuY2UpO1xuICAgIH1cbiAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHNldHVwUmVzdWx0ICE9PSB2b2lkIDApIHtcbiAgICB3YXJuJDEoXG4gICAgICBgc2V0dXAoKSBzaG91bGQgcmV0dXJuIGFuIG9iamVjdC4gUmVjZWl2ZWQ6ICR7c2V0dXBSZXN1bHQgPT09IG51bGwgPyBcIm51bGxcIiA6IHR5cGVvZiBzZXR1cFJlc3VsdH1gXG4gICAgKTtcbiAgfVxuICBmaW5pc2hDb21wb25lbnRTZXR1cChpbnN0YW5jZSwgaXNTU1IpO1xufVxubGV0IGNvbXBpbGU7XG5sZXQgaW5zdGFsbFdpdGhQcm94eTtcbmZ1bmN0aW9uIHJlZ2lzdGVyUnVudGltZUNvbXBpbGVyKF9jb21waWxlKSB7XG4gIGNvbXBpbGUgPSBfY29tcGlsZTtcbiAgaW5zdGFsbFdpdGhQcm94eSA9IChpKSA9PiB7XG4gICAgaWYgKGkucmVuZGVyLl9yYykge1xuICAgICAgaS53aXRoUHJveHkgPSBuZXcgUHJveHkoaS5jdHgsIFJ1bnRpbWVDb21waWxlZFB1YmxpY0luc3RhbmNlUHJveHlIYW5kbGVycyk7XG4gICAgfVxuICB9O1xufVxuY29uc3QgaXNSdW50aW1lT25seSA9ICgpID0+ICFjb21waWxlO1xuZnVuY3Rpb24gZmluaXNoQ29tcG9uZW50U2V0dXAoaW5zdGFuY2UsIGlzU1NSLCBza2lwT3B0aW9ucykge1xuICBjb25zdCBDb21wb25lbnQgPSBpbnN0YW5jZS50eXBlO1xuICBpZiAoIWluc3RhbmNlLnJlbmRlcikge1xuICAgIGlmICghaXNTU1IgJiYgY29tcGlsZSAmJiAhQ29tcG9uZW50LnJlbmRlcikge1xuICAgICAgY29uc3QgdGVtcGxhdGUgPSBDb21wb25lbnQudGVtcGxhdGUgfHwgX19WVUVfT1BUSU9OU19BUElfXyAmJiByZXNvbHZlTWVyZ2VkT3B0aW9ucyhpbnN0YW5jZSkudGVtcGxhdGU7XG4gICAgICBpZiAodGVtcGxhdGUpIHtcbiAgICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgICBzdGFydE1lYXN1cmUoaW5zdGFuY2UsIGBjb21waWxlYCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgeyBpc0N1c3RvbUVsZW1lbnQsIGNvbXBpbGVyT3B0aW9ucyB9ID0gaW5zdGFuY2UuYXBwQ29udGV4dC5jb25maWc7XG4gICAgICAgIGNvbnN0IHsgZGVsaW1pdGVycywgY29tcGlsZXJPcHRpb25zOiBjb21wb25lbnRDb21waWxlck9wdGlvbnMgfSA9IENvbXBvbmVudDtcbiAgICAgICAgY29uc3QgZmluYWxDb21waWxlck9wdGlvbnMgPSBleHRlbmQoXG4gICAgICAgICAgZXh0ZW5kKFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBpc0N1c3RvbUVsZW1lbnQsXG4gICAgICAgICAgICAgIGRlbGltaXRlcnNcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBjb21waWxlck9wdGlvbnNcbiAgICAgICAgICApLFxuICAgICAgICAgIGNvbXBvbmVudENvbXBpbGVyT3B0aW9uc1xuICAgICAgICApO1xuICAgICAgICBDb21wb25lbnQucmVuZGVyID0gY29tcGlsZSh0ZW1wbGF0ZSwgZmluYWxDb21waWxlck9wdGlvbnMpO1xuICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIGVuZE1lYXN1cmUoaW5zdGFuY2UsIGBjb21waWxlYCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaW5zdGFuY2UucmVuZGVyID0gQ29tcG9uZW50LnJlbmRlciB8fCBOT09QO1xuICAgIGlmIChpbnN0YWxsV2l0aFByb3h5KSB7XG4gICAgICBpbnN0YWxsV2l0aFByb3h5KGluc3RhbmNlKTtcbiAgICB9XG4gIH1cbiAgaWYgKF9fVlVFX09QVElPTlNfQVBJX18gJiYgdHJ1ZSkge1xuICAgIGNvbnN0IHJlc2V0ID0gc2V0Q3VycmVudEluc3RhbmNlKGluc3RhbmNlKTtcbiAgICBwYXVzZVRyYWNraW5nKCk7XG4gICAgdHJ5IHtcbiAgICAgIGFwcGx5T3B0aW9ucyhpbnN0YW5jZSk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHJlc2V0VHJhY2tpbmcoKTtcbiAgICAgIHJlc2V0KCk7XG4gICAgfVxuICB9XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmICFDb21wb25lbnQucmVuZGVyICYmIGluc3RhbmNlLnJlbmRlciA9PT0gTk9PUCAmJiAhaXNTU1IpIHtcbiAgICBpZiAoIWNvbXBpbGUgJiYgQ29tcG9uZW50LnRlbXBsYXRlKSB7XG4gICAgICB3YXJuJDEoXG4gICAgICAgIGBDb21wb25lbnQgcHJvdmlkZWQgdGVtcGxhdGUgb3B0aW9uIGJ1dCBydW50aW1lIGNvbXBpbGF0aW9uIGlzIG5vdCBzdXBwb3J0ZWQgaW4gdGhpcyBidWlsZCBvZiBWdWUuYCArIChgIENvbmZpZ3VyZSB5b3VyIGJ1bmRsZXIgdG8gYWxpYXMgXCJ2dWVcIiB0byBcInZ1ZS9kaXN0L3Z1ZS5lc20tYnVuZGxlci5qc1wiLmAgKVxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgd2FybiQxKGBDb21wb25lbnQgaXMgbWlzc2luZyB0ZW1wbGF0ZSBvciByZW5kZXIgZnVuY3Rpb246IGAsIENvbXBvbmVudCk7XG4gICAgfVxuICB9XG59XG5jb25zdCBhdHRyc1Byb3h5SGFuZGxlcnMgPSAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8ge1xuICBnZXQodGFyZ2V0LCBrZXkpIHtcbiAgICBtYXJrQXR0cnNBY2Nlc3NlZCgpO1xuICAgIHRyYWNrKHRhcmdldCwgXCJnZXRcIiwgXCJcIik7XG4gICAgcmV0dXJuIHRhcmdldFtrZXldO1xuICB9LFxuICBzZXQoKSB7XG4gICAgd2FybiQxKGBzZXR1cENvbnRleHQuYXR0cnMgaXMgcmVhZG9ubHkuYCk7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9LFxuICBkZWxldGVQcm9wZXJ0eSgpIHtcbiAgICB3YXJuJDEoYHNldHVwQ29udGV4dC5hdHRycyBpcyByZWFkb25seS5gKTtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn0gOiB7XG4gIGdldCh0YXJnZXQsIGtleSkge1xuICAgIHRyYWNrKHRhcmdldCwgXCJnZXRcIiwgXCJcIik7XG4gICAgcmV0dXJuIHRhcmdldFtrZXldO1xuICB9XG59O1xuZnVuY3Rpb24gZ2V0U2xvdHNQcm94eShpbnN0YW5jZSkge1xuICByZXR1cm4gbmV3IFByb3h5KGluc3RhbmNlLnNsb3RzLCB7XG4gICAgZ2V0KHRhcmdldCwga2V5KSB7XG4gICAgICB0cmFjayhpbnN0YW5jZSwgXCJnZXRcIiwgXCIkc2xvdHNcIik7XG4gICAgICByZXR1cm4gdGFyZ2V0W2tleV07XG4gICAgfVxuICB9KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVNldHVwQ29udGV4dChpbnN0YW5jZSkge1xuICBjb25zdCBleHBvc2UgPSAoZXhwb3NlZCkgPT4ge1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICBpZiAoaW5zdGFuY2UuZXhwb3NlZCkge1xuICAgICAgICB3YXJuJDEoYGV4cG9zZSgpIHNob3VsZCBiZSBjYWxsZWQgb25seSBvbmNlIHBlciBzZXR1cCgpLmApO1xuICAgICAgfVxuICAgICAgaWYgKGV4cG9zZWQgIT0gbnVsbCkge1xuICAgICAgICBsZXQgZXhwb3NlZFR5cGUgPSB0eXBlb2YgZXhwb3NlZDtcbiAgICAgICAgaWYgKGV4cG9zZWRUeXBlID09PSBcIm9iamVjdFwiKSB7XG4gICAgICAgICAgaWYgKGlzQXJyYXkoZXhwb3NlZCkpIHtcbiAgICAgICAgICAgIGV4cG9zZWRUeXBlID0gXCJhcnJheVwiO1xuICAgICAgICAgIH0gZWxzZSBpZiAoaXNSZWYoZXhwb3NlZCkpIHtcbiAgICAgICAgICAgIGV4cG9zZWRUeXBlID0gXCJyZWZcIjtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGV4cG9zZWRUeXBlICE9PSBcIm9iamVjdFwiKSB7XG4gICAgICAgICAgd2FybiQxKFxuICAgICAgICAgICAgYGV4cG9zZSgpIHNob3VsZCBiZSBwYXNzZWQgYSBwbGFpbiBvYmplY3QsIHJlY2VpdmVkICR7ZXhwb3NlZFR5cGV9LmBcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGluc3RhbmNlLmV4cG9zZWQgPSBleHBvc2VkIHx8IHt9O1xuICB9O1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIGxldCBhdHRyc1Byb3h5O1xuICAgIGxldCBzbG90c1Byb3h5O1xuICAgIHJldHVybiBPYmplY3QuZnJlZXplKHtcbiAgICAgIGdldCBhdHRycygpIHtcbiAgICAgICAgcmV0dXJuIGF0dHJzUHJveHkgfHwgKGF0dHJzUHJveHkgPSBuZXcgUHJveHkoaW5zdGFuY2UuYXR0cnMsIGF0dHJzUHJveHlIYW5kbGVycykpO1xuICAgICAgfSxcbiAgICAgIGdldCBzbG90cygpIHtcbiAgICAgICAgcmV0dXJuIHNsb3RzUHJveHkgfHwgKHNsb3RzUHJveHkgPSBnZXRTbG90c1Byb3h5KGluc3RhbmNlKSk7XG4gICAgICB9LFxuICAgICAgZ2V0IGVtaXQoKSB7XG4gICAgICAgIHJldHVybiAoZXZlbnQsIC4uLmFyZ3MpID0+IGluc3RhbmNlLmVtaXQoZXZlbnQsIC4uLmFyZ3MpO1xuICAgICAgfSxcbiAgICAgIGV4cG9zZVxuICAgIH0pO1xuICB9IGVsc2Uge1xuICAgIHJldHVybiB7XG4gICAgICBhdHRyczogbmV3IFByb3h5KGluc3RhbmNlLmF0dHJzLCBhdHRyc1Byb3h5SGFuZGxlcnMpLFxuICAgICAgc2xvdHM6IGluc3RhbmNlLnNsb3RzLFxuICAgICAgZW1pdDogaW5zdGFuY2UuZW1pdCxcbiAgICAgIGV4cG9zZVxuICAgIH07XG4gIH1cbn1cbmZ1bmN0aW9uIGdldENvbXBvbmVudFB1YmxpY0luc3RhbmNlKGluc3RhbmNlKSB7XG4gIGlmIChpbnN0YW5jZS5leHBvc2VkKSB7XG4gICAgcmV0dXJuIGluc3RhbmNlLmV4cG9zZVByb3h5IHx8IChpbnN0YW5jZS5leHBvc2VQcm94eSA9IG5ldyBQcm94eShwcm94eVJlZnMobWFya1JhdyhpbnN0YW5jZS5leHBvc2VkKSksIHtcbiAgICAgIGdldCh0YXJnZXQsIGtleSkge1xuICAgICAgICBpZiAoa2V5IGluIHRhcmdldCkge1xuICAgICAgICAgIHJldHVybiB0YXJnZXRba2V5XTtcbiAgICAgICAgfSBlbHNlIGlmIChrZXkgaW4gcHVibGljUHJvcGVydGllc01hcCkge1xuICAgICAgICAgIHJldHVybiBwdWJsaWNQcm9wZXJ0aWVzTWFwW2tleV0oaW5zdGFuY2UpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgaGFzKHRhcmdldCwga2V5KSB7XG4gICAgICAgIHJldHVybiBrZXkgaW4gdGFyZ2V0IHx8IGtleSBpbiBwdWJsaWNQcm9wZXJ0aWVzTWFwO1xuICAgICAgfVxuICAgIH0pKTtcbiAgfSBlbHNlIHtcbiAgICByZXR1cm4gaW5zdGFuY2UucHJveHk7XG4gIH1cbn1cbmNvbnN0IGNsYXNzaWZ5UkUgPSAvKD86XnxbLV9dKVxcdy9nO1xuY29uc3QgY2xhc3NpZnkgPSAoc3RyKSA9PiBzdHIucmVwbGFjZShjbGFzc2lmeVJFLCAoYykgPT4gYy50b1VwcGVyQ2FzZSgpKS5yZXBsYWNlKC9bLV9dL2csIFwiXCIpO1xuZnVuY3Rpb24gZ2V0Q29tcG9uZW50TmFtZShDb21wb25lbnQsIGluY2x1ZGVJbmZlcnJlZCA9IHRydWUpIHtcbiAgcmV0dXJuIGlzRnVuY3Rpb24oQ29tcG9uZW50KSA/IENvbXBvbmVudC5kaXNwbGF5TmFtZSB8fCBDb21wb25lbnQubmFtZSA6IENvbXBvbmVudC5uYW1lIHx8IGluY2x1ZGVJbmZlcnJlZCAmJiBDb21wb25lbnQuX19uYW1lO1xufVxuZnVuY3Rpb24gZm9ybWF0Q29tcG9uZW50TmFtZShpbnN0YW5jZSwgQ29tcG9uZW50LCBpc1Jvb3QgPSBmYWxzZSkge1xuICBsZXQgbmFtZSA9IGdldENvbXBvbmVudE5hbWUoQ29tcG9uZW50KTtcbiAgaWYgKCFuYW1lICYmIENvbXBvbmVudC5fX2ZpbGUpIHtcbiAgICBjb25zdCBtYXRjaCA9IENvbXBvbmVudC5fX2ZpbGUubWF0Y2goLyhbXi9cXFxcXSspXFwuXFx3KyQvKTtcbiAgICBpZiAobWF0Y2gpIHtcbiAgICAgIG5hbWUgPSBtYXRjaFsxXTtcbiAgICB9XG4gIH1cbiAgaWYgKCFuYW1lICYmIGluc3RhbmNlKSB7XG4gICAgY29uc3QgaW5mZXJGcm9tUmVnaXN0cnkgPSAocmVnaXN0cnkpID0+IHtcbiAgICAgIGZvciAoY29uc3Qga2V5IGluIHJlZ2lzdHJ5KSB7XG4gICAgICAgIGlmIChyZWdpc3RyeVtrZXldID09PSBDb21wb25lbnQpIHtcbiAgICAgICAgICByZXR1cm4ga2V5O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcbiAgICBuYW1lID0gaW5mZXJGcm9tUmVnaXN0cnkoaW5zdGFuY2UuY29tcG9uZW50cykgfHwgaW5zdGFuY2UucGFyZW50ICYmIGluZmVyRnJvbVJlZ2lzdHJ5KFxuICAgICAgaW5zdGFuY2UucGFyZW50LnR5cGUuY29tcG9uZW50c1xuICAgICkgfHwgaW5mZXJGcm9tUmVnaXN0cnkoaW5zdGFuY2UuYXBwQ29udGV4dC5jb21wb25lbnRzKTtcbiAgfVxuICByZXR1cm4gbmFtZSA/IGNsYXNzaWZ5KG5hbWUpIDogaXNSb290ID8gYEFwcGAgOiBgQW5vbnltb3VzYDtcbn1cbmZ1bmN0aW9uIGlzQ2xhc3NDb21wb25lbnQodmFsdWUpIHtcbiAgcmV0dXJuIGlzRnVuY3Rpb24odmFsdWUpICYmIFwiX192Y2NPcHRzXCIgaW4gdmFsdWU7XG59XG5cbmNvbnN0IGNvbXB1dGVkID0gKGdldHRlck9yT3B0aW9ucywgZGVidWdPcHRpb25zKSA9PiB7XG4gIGNvbnN0IGMgPSBjb21wdXRlZCQxKGdldHRlck9yT3B0aW9ucywgZGVidWdPcHRpb25zLCBpc0luU1NSQ29tcG9uZW50U2V0dXApO1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIGNvbnN0IGkgPSBnZXRDdXJyZW50SW5zdGFuY2UoKTtcbiAgICBpZiAoaSAmJiBpLmFwcENvbnRleHQuY29uZmlnLndhcm5SZWN1cnNpdmVDb21wdXRlZCkge1xuICAgICAgYy5fd2FyblJlY3Vyc2l2ZSA9IHRydWU7XG4gICAgfVxuICB9XG4gIHJldHVybiBjO1xufTtcblxuZnVuY3Rpb24gaCh0eXBlLCBwcm9wc09yQ2hpbGRyZW4sIGNoaWxkcmVuKSB7XG4gIHRyeSB7XG4gICAgc2V0QmxvY2tUcmFja2luZygtMSk7XG4gICAgY29uc3QgbCA9IGFyZ3VtZW50cy5sZW5ndGg7XG4gICAgaWYgKGwgPT09IDIpIHtcbiAgICAgIGlmIChpc09iamVjdChwcm9wc09yQ2hpbGRyZW4pICYmICFpc0FycmF5KHByb3BzT3JDaGlsZHJlbikpIHtcbiAgICAgICAgaWYgKGlzVk5vZGUocHJvcHNPckNoaWxkcmVuKSkge1xuICAgICAgICAgIHJldHVybiBjcmVhdGVWTm9kZSh0eXBlLCBudWxsLCBbcHJvcHNPckNoaWxkcmVuXSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNyZWF0ZVZOb2RlKHR5cGUsIHByb3BzT3JDaGlsZHJlbik7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gY3JlYXRlVk5vZGUodHlwZSwgbnVsbCwgcHJvcHNPckNoaWxkcmVuKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKGwgPiAzKSB7XG4gICAgICAgIGNoaWxkcmVuID0gQXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoYXJndW1lbnRzLCAyKTtcbiAgICAgIH0gZWxzZSBpZiAobCA9PT0gMyAmJiBpc1ZOb2RlKGNoaWxkcmVuKSkge1xuICAgICAgICBjaGlsZHJlbiA9IFtjaGlsZHJlbl07XG4gICAgICB9XG4gICAgICByZXR1cm4gY3JlYXRlVk5vZGUodHlwZSwgcHJvcHNPckNoaWxkcmVuLCBjaGlsZHJlbik7XG4gICAgfVxuICB9IGZpbmFsbHkge1xuICAgIHNldEJsb2NrVHJhY2tpbmcoMSk7XG4gIH1cbn1cblxuZnVuY3Rpb24gaW5pdEN1c3RvbUZvcm1hdHRlcigpIHtcbiAgaWYgKCEhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgdnVlU3R5bGUgPSB7IHN0eWxlOiBcImNvbG9yOiMzYmE3NzZcIiB9O1xuICBjb25zdCBudW1iZXJTdHlsZSA9IHsgc3R5bGU6IFwiY29sb3I6IzE2NzdmZlwiIH07XG4gIGNvbnN0IHN0cmluZ1N0eWxlID0geyBzdHlsZTogXCJjb2xvcjojZjUyMjJkXCIgfTtcbiAgY29uc3Qga2V5d29yZFN0eWxlID0geyBzdHlsZTogXCJjb2xvcjojZWIyZjk2XCIgfTtcbiAgY29uc3QgZm9ybWF0dGVyID0ge1xuICAgIF9fdnVlX2N1c3RvbV9mb3JtYXR0ZXI6IHRydWUsXG4gICAgaGVhZGVyKG9iaikge1xuICAgICAgaWYgKCFpc09iamVjdChvYmopKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgaWYgKG9iai5fX2lzVnVlKSB7XG4gICAgICAgIHJldHVybiBbXCJkaXZcIiwgdnVlU3R5bGUsIGBWdWVJbnN0YW5jZWBdO1xuICAgICAgfSBlbHNlIGlmIChpc1JlZihvYmopKSB7XG4gICAgICAgIHBhdXNlVHJhY2tpbmcoKTtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBvYmoudmFsdWU7XG4gICAgICAgIHJlc2V0VHJhY2tpbmcoKTtcbiAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICBcImRpdlwiLFxuICAgICAgICAgIHt9LFxuICAgICAgICAgIFtcInNwYW5cIiwgdnVlU3R5bGUsIGdlblJlZkZsYWcob2JqKV0sXG4gICAgICAgICAgXCI8XCIsXG4gICAgICAgICAgZm9ybWF0VmFsdWUodmFsdWUpLFxuICAgICAgICAgIGA+YFxuICAgICAgICBdO1xuICAgICAgfSBlbHNlIGlmIChpc1JlYWN0aXZlKG9iaikpIHtcbiAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICBcImRpdlwiLFxuICAgICAgICAgIHt9LFxuICAgICAgICAgIFtcInNwYW5cIiwgdnVlU3R5bGUsIGlzU2hhbGxvdyhvYmopID8gXCJTaGFsbG93UmVhY3RpdmVcIiA6IFwiUmVhY3RpdmVcIl0sXG4gICAgICAgICAgXCI8XCIsXG4gICAgICAgICAgZm9ybWF0VmFsdWUob2JqKSxcbiAgICAgICAgICBgPiR7aXNSZWFkb25seShvYmopID8gYCAocmVhZG9ubHkpYCA6IGBgfWBcbiAgICAgICAgXTtcbiAgICAgIH0gZWxzZSBpZiAoaXNSZWFkb25seShvYmopKSB7XG4gICAgICAgIHJldHVybiBbXG4gICAgICAgICAgXCJkaXZcIixcbiAgICAgICAgICB7fSxcbiAgICAgICAgICBbXCJzcGFuXCIsIHZ1ZVN0eWxlLCBpc1NoYWxsb3cob2JqKSA/IFwiU2hhbGxvd1JlYWRvbmx5XCIgOiBcIlJlYWRvbmx5XCJdLFxuICAgICAgICAgIFwiPFwiLFxuICAgICAgICAgIGZvcm1hdFZhbHVlKG9iaiksXG4gICAgICAgICAgXCI+XCJcbiAgICAgICAgXTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBudWxsO1xuICAgIH0sXG4gICAgaGFzQm9keShvYmopIHtcbiAgICAgIHJldHVybiBvYmogJiYgb2JqLl9faXNWdWU7XG4gICAgfSxcbiAgICBib2R5KG9iaikge1xuICAgICAgaWYgKG9iaiAmJiBvYmouX19pc1Z1ZSkge1xuICAgICAgICByZXR1cm4gW1xuICAgICAgICAgIFwiZGl2XCIsXG4gICAgICAgICAge30sXG4gICAgICAgICAgLi4uZm9ybWF0SW5zdGFuY2Uob2JqLiQpXG4gICAgICAgIF07XG4gICAgICB9XG4gICAgfVxuICB9O1xuICBmdW5jdGlvbiBmb3JtYXRJbnN0YW5jZShpbnN0YW5jZSkge1xuICAgIGNvbnN0IGJsb2NrcyA9IFtdO1xuICAgIGlmIChpbnN0YW5jZS50eXBlLnByb3BzICYmIGluc3RhbmNlLnByb3BzKSB7XG4gICAgICBibG9ja3MucHVzaChjcmVhdGVJbnN0YW5jZUJsb2NrKFwicHJvcHNcIiwgdG9SYXcoaW5zdGFuY2UucHJvcHMpKSk7XG4gICAgfVxuICAgIGlmIChpbnN0YW5jZS5zZXR1cFN0YXRlICE9PSBFTVBUWV9PQkopIHtcbiAgICAgIGJsb2Nrcy5wdXNoKGNyZWF0ZUluc3RhbmNlQmxvY2soXCJzZXR1cFwiLCBpbnN0YW5jZS5zZXR1cFN0YXRlKSk7XG4gICAgfVxuICAgIGlmIChpbnN0YW5jZS5kYXRhICE9PSBFTVBUWV9PQkopIHtcbiAgICAgIGJsb2Nrcy5wdXNoKGNyZWF0ZUluc3RhbmNlQmxvY2soXCJkYXRhXCIsIHRvUmF3KGluc3RhbmNlLmRhdGEpKSk7XG4gICAgfVxuICAgIGNvbnN0IGNvbXB1dGVkID0gZXh0cmFjdEtleXMoaW5zdGFuY2UsIFwiY29tcHV0ZWRcIik7XG4gICAgaWYgKGNvbXB1dGVkKSB7XG4gICAgICBibG9ja3MucHVzaChjcmVhdGVJbnN0YW5jZUJsb2NrKFwiY29tcHV0ZWRcIiwgY29tcHV0ZWQpKTtcbiAgICB9XG4gICAgY29uc3QgaW5qZWN0ZWQgPSBleHRyYWN0S2V5cyhpbnN0YW5jZSwgXCJpbmplY3RcIik7XG4gICAgaWYgKGluamVjdGVkKSB7XG4gICAgICBibG9ja3MucHVzaChjcmVhdGVJbnN0YW5jZUJsb2NrKFwiaW5qZWN0ZWRcIiwgaW5qZWN0ZWQpKTtcbiAgICB9XG4gICAgYmxvY2tzLnB1c2goW1xuICAgICAgXCJkaXZcIixcbiAgICAgIHt9LFxuICAgICAgW1xuICAgICAgICBcInNwYW5cIixcbiAgICAgICAge1xuICAgICAgICAgIHN0eWxlOiBrZXl3b3JkU3R5bGUuc3R5bGUgKyBcIjtvcGFjaXR5OjAuNjZcIlxuICAgICAgICB9LFxuICAgICAgICBcIiQgKGludGVybmFsKTogXCJcbiAgICAgIF0sXG4gICAgICBbXCJvYmplY3RcIiwgeyBvYmplY3Q6IGluc3RhbmNlIH1dXG4gICAgXSk7XG4gICAgcmV0dXJuIGJsb2NrcztcbiAgfVxuICBmdW5jdGlvbiBjcmVhdGVJbnN0YW5jZUJsb2NrKHR5cGUsIHRhcmdldCkge1xuICAgIHRhcmdldCA9IGV4dGVuZCh7fSwgdGFyZ2V0KTtcbiAgICBpZiAoIU9iamVjdC5rZXlzKHRhcmdldCkubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gW1wic3BhblwiLCB7fV07XG4gICAgfVxuICAgIHJldHVybiBbXG4gICAgICBcImRpdlwiLFxuICAgICAgeyBzdHlsZTogXCJsaW5lLWhlaWdodDoxLjI1ZW07bWFyZ2luLWJvdHRvbTowLjZlbVwiIH0sXG4gICAgICBbXG4gICAgICAgIFwiZGl2XCIsXG4gICAgICAgIHtcbiAgICAgICAgICBzdHlsZTogXCJjb2xvcjojNDc2NTgyXCJcbiAgICAgICAgfSxcbiAgICAgICAgdHlwZVxuICAgICAgXSxcbiAgICAgIFtcbiAgICAgICAgXCJkaXZcIixcbiAgICAgICAge1xuICAgICAgICAgIHN0eWxlOiBcInBhZGRpbmctbGVmdDoxLjI1ZW1cIlxuICAgICAgICB9LFxuICAgICAgICAuLi5PYmplY3Qua2V5cyh0YXJnZXQpLm1hcCgoa2V5KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIFtcbiAgICAgICAgICAgIFwiZGl2XCIsXG4gICAgICAgICAgICB7fSxcbiAgICAgICAgICAgIFtcInNwYW5cIiwga2V5d29yZFN0eWxlLCBrZXkgKyBcIjogXCJdLFxuICAgICAgICAgICAgZm9ybWF0VmFsdWUodGFyZ2V0W2tleV0sIGZhbHNlKVxuICAgICAgICAgIF07XG4gICAgICAgIH0pXG4gICAgICBdXG4gICAgXTtcbiAgfVxuICBmdW5jdGlvbiBmb3JtYXRWYWx1ZSh2LCBhc1JhdyA9IHRydWUpIHtcbiAgICBpZiAodHlwZW9mIHYgPT09IFwibnVtYmVyXCIpIHtcbiAgICAgIHJldHVybiBbXCJzcGFuXCIsIG51bWJlclN0eWxlLCB2XTtcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiB2ID09PSBcInN0cmluZ1wiKSB7XG4gICAgICByZXR1cm4gW1wic3BhblwiLCBzdHJpbmdTdHlsZSwgSlNPTi5zdHJpbmdpZnkodildO1xuICAgIH0gZWxzZSBpZiAodHlwZW9mIHYgPT09IFwiYm9vbGVhblwiKSB7XG4gICAgICByZXR1cm4gW1wic3BhblwiLCBrZXl3b3JkU3R5bGUsIHZdO1xuICAgIH0gZWxzZSBpZiAoaXNPYmplY3QodikpIHtcbiAgICAgIHJldHVybiBbXCJvYmplY3RcIiwgeyBvYmplY3Q6IGFzUmF3ID8gdG9SYXcodikgOiB2IH1dO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gW1wic3BhblwiLCBzdHJpbmdTdHlsZSwgU3RyaW5nKHYpXTtcbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gZXh0cmFjdEtleXMoaW5zdGFuY2UsIHR5cGUpIHtcbiAgICBjb25zdCBDb21wID0gaW5zdGFuY2UudHlwZTtcbiAgICBpZiAoaXNGdW5jdGlvbihDb21wKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBleHRyYWN0ZWQgPSB7fTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBpbnN0YW5jZS5jdHgpIHtcbiAgICAgIGlmIChpc0tleU9mVHlwZShDb21wLCBrZXksIHR5cGUpKSB7XG4gICAgICAgIGV4dHJhY3RlZFtrZXldID0gaW5zdGFuY2UuY3R4W2tleV07XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBleHRyYWN0ZWQ7XG4gIH1cbiAgZnVuY3Rpb24gaXNLZXlPZlR5cGUoQ29tcCwga2V5LCB0eXBlKSB7XG4gICAgY29uc3Qgb3B0cyA9IENvbXBbdHlwZV07XG4gICAgaWYgKGlzQXJyYXkob3B0cykgJiYgb3B0cy5pbmNsdWRlcyhrZXkpIHx8IGlzT2JqZWN0KG9wdHMpICYmIGtleSBpbiBvcHRzKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKENvbXAuZXh0ZW5kcyAmJiBpc0tleU9mVHlwZShDb21wLmV4dGVuZHMsIGtleSwgdHlwZSkpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoQ29tcC5taXhpbnMgJiYgQ29tcC5taXhpbnMuc29tZSgobSkgPT4gaXNLZXlPZlR5cGUobSwga2V5LCB0eXBlKSkpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBnZW5SZWZGbGFnKHYpIHtcbiAgICBpZiAoaXNTaGFsbG93KHYpKSB7XG4gICAgICByZXR1cm4gYFNoYWxsb3dSZWZgO1xuICAgIH1cbiAgICBpZiAodi5lZmZlY3QpIHtcbiAgICAgIHJldHVybiBgQ29tcHV0ZWRSZWZgO1xuICAgIH1cbiAgICByZXR1cm4gYFJlZmA7XG4gIH1cbiAgaWYgKHdpbmRvdy5kZXZ0b29sc0Zvcm1hdHRlcnMpIHtcbiAgICB3aW5kb3cuZGV2dG9vbHNGb3JtYXR0ZXJzLnB1c2goZm9ybWF0dGVyKTtcbiAgfSBlbHNlIHtcbiAgICB3aW5kb3cuZGV2dG9vbHNGb3JtYXR0ZXJzID0gW2Zvcm1hdHRlcl07XG4gIH1cbn1cblxuZnVuY3Rpb24gd2l0aE1lbW8obWVtbywgcmVuZGVyLCBjYWNoZSwgaW5kZXgpIHtcbiAgY29uc3QgY2FjaGVkID0gY2FjaGVbaW5kZXhdO1xuICBpZiAoY2FjaGVkICYmIGlzTWVtb1NhbWUoY2FjaGVkLCBtZW1vKSkge1xuICAgIHJldHVybiBjYWNoZWQ7XG4gIH1cbiAgY29uc3QgcmV0ID0gcmVuZGVyKCk7XG4gIHJldC5tZW1vID0gbWVtby5zbGljZSgpO1xuICByZXQuY2FjaGVJbmRleCA9IGluZGV4O1xuICByZXR1cm4gY2FjaGVbaW5kZXhdID0gcmV0O1xufVxuZnVuY3Rpb24gaXNNZW1vU2FtZShjYWNoZWQsIG1lbW8pIHtcbiAgY29uc3QgcHJldiA9IGNhY2hlZC5tZW1vO1xuICBpZiAocHJldi5sZW5ndGggIT0gbWVtby5sZW5ndGgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBwcmV2Lmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKGhhc0NoYW5nZWQocHJldltpXSwgbWVtb1tpXSkpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgaWYgKGlzQmxvY2tUcmVlRW5hYmxlZCA+IDAgJiYgY3VycmVudEJsb2NrKSB7XG4gICAgY3VycmVudEJsb2NrLnB1c2goY2FjaGVkKTtcbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn1cblxuY29uc3QgdmVyc2lvbiA9IFwiMy41LjQwXCI7XG5jb25zdCB3YXJuID0gISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IHdhcm4kMSA6IE5PT1A7XG5jb25zdCBFcnJvclR5cGVTdHJpbmdzID0gRXJyb3JUeXBlU3RyaW5ncyQxIDtcbmNvbnN0IGRldnRvb2xzID0gISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB8fCB0cnVlID8gZGV2dG9vbHMkMSA6IHZvaWQgMDtcbmNvbnN0IHNldERldnRvb2xzSG9vayA9ICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgfHwgdHJ1ZSA/IHNldERldnRvb2xzSG9vayQxIDogTk9PUDtcbmNvbnN0IF9zc3JVdGlscyA9IHtcbiAgY3JlYXRlQ29tcG9uZW50SW5zdGFuY2UsXG4gIHNldHVwQ29tcG9uZW50LFxuICByZW5kZXJDb21wb25lbnRSb290LFxuICBzZXRDdXJyZW50UmVuZGVyaW5nSW5zdGFuY2UsXG4gIGlzVk5vZGU6IGlzVk5vZGUsXG4gIG5vcm1hbGl6ZVZOb2RlLFxuICBnZXRDb21wb25lbnRQdWJsaWNJbnN0YW5jZSxcbiAgZW5zdXJlVmFsaWRWTm9kZSxcbiAgcHVzaFdhcm5pbmdDb250ZXh0LFxuICBwb3BXYXJuaW5nQ29udGV4dFxufTtcbmNvbnN0IHNzclV0aWxzID0gX3NzclV0aWxzIDtcbmNvbnN0IHJlc29sdmVGaWx0ZXIgPSBudWxsO1xuY29uc3QgY29tcGF0VXRpbHMgPSBudWxsO1xuY29uc3QgRGVwcmVjYXRpb25UeXBlcyA9IG51bGw7XG5cbmV4cG9ydCB7IEJhc2VUcmFuc2l0aW9uLCBCYXNlVHJhbnNpdGlvblByb3BzVmFsaWRhdG9ycywgQ29tbWVudCwgRGVwcmVjYXRpb25UeXBlcywgRXJyb3JDb2RlcywgRXJyb3JUeXBlU3RyaW5ncywgRnJhZ21lbnQsIEtlZXBBbGl2ZSwgU3RhdGljLCBTdXNwZW5zZSwgVGVsZXBvcnQsIFRleHQsIGFzc2VydE51bWJlciwgY2FsbFdpdGhBc3luY0Vycm9ySGFuZGxpbmcsIGNhbGxXaXRoRXJyb3JIYW5kbGluZywgY2xvbmVWTm9kZSwgY29tcGF0VXRpbHMsIGNvbXB1dGVkLCBjcmVhdGVCbG9jaywgY3JlYXRlQ29tbWVudFZOb2RlLCBjcmVhdGVFbGVtZW50QmxvY2ssIGNyZWF0ZUJhc2VWTm9kZSBhcyBjcmVhdGVFbGVtZW50Vk5vZGUsIGNyZWF0ZUh5ZHJhdGlvblJlbmRlcmVyLCBjcmVhdGVQcm9wc1Jlc3RQcm94eSwgY3JlYXRlUmVuZGVyZXIsIGNyZWF0ZVNsb3RzLCBjcmVhdGVTdGF0aWNWTm9kZSwgY3JlYXRlVGV4dFZOb2RlLCBjcmVhdGVWTm9kZSwgZGVmaW5lQXN5bmNDb21wb25lbnQsIGRlZmluZUNvbXBvbmVudCwgZGVmaW5lRW1pdHMsIGRlZmluZUV4cG9zZSwgZGVmaW5lTW9kZWwsIGRlZmluZU9wdGlvbnMsIGRlZmluZVByb3BzLCBkZWZpbmVTbG90cywgZGV2dG9vbHMsIGdldEN1cnJlbnRJbnN0YW5jZSwgZ2V0VHJhbnNpdGlvblJhd0NoaWxkcmVuLCBndWFyZFJlYWN0aXZlUHJvcHMsIGgsIGhhbmRsZUVycm9yLCBoYXNJbmplY3Rpb25Db250ZXh0LCBoeWRyYXRlT25JZGxlLCBoeWRyYXRlT25JbnRlcmFjdGlvbiwgaHlkcmF0ZU9uTWVkaWFRdWVyeSwgaHlkcmF0ZU9uVmlzaWJsZSwgaW5pdEN1c3RvbUZvcm1hdHRlciwgaW5qZWN0LCBpc01lbW9TYW1lLCBpc1J1bnRpbWVPbmx5LCBpc1ZOb2RlLCBtZXJnZURlZmF1bHRzLCBtZXJnZU1vZGVscywgbWVyZ2VQcm9wcywgbmV4dFRpY2ssIG9uQWN0aXZhdGVkLCBvbkJlZm9yZU1vdW50LCBvbkJlZm9yZVVubW91bnQsIG9uQmVmb3JlVXBkYXRlLCBvbkRlYWN0aXZhdGVkLCBvbkVycm9yQ2FwdHVyZWQsIG9uTW91bnRlZCwgb25SZW5kZXJUcmFja2VkLCBvblJlbmRlclRyaWdnZXJlZCwgb25TZXJ2ZXJQcmVmZXRjaCwgb25Vbm1vdW50ZWQsIG9uVXBkYXRlZCwgb3BlbkJsb2NrLCBwb3BTY29wZUlkLCBwcm92aWRlLCBwdXNoU2NvcGVJZCwgcXVldWVQb3N0Rmx1c2hDYiwgcmVnaXN0ZXJSdW50aW1lQ29tcGlsZXIsIHJlbmRlckxpc3QsIHJlbmRlclNsb3QsIHJlc29sdmVDb21wb25lbnQsIHJlc29sdmVEaXJlY3RpdmUsIHJlc29sdmVEeW5hbWljQ29tcG9uZW50LCByZXNvbHZlRmlsdGVyLCByZXNvbHZlVHJhbnNpdGlvbkhvb2tzLCBzZXRCbG9ja1RyYWNraW5nLCBzZXREZXZ0b29sc0hvb2ssIHNldFRyYW5zaXRpb25Ib29rcywgc3NyQ29udGV4dEtleSwgc3NyVXRpbHMsIHRvSGFuZGxlcnMsIHRyYW5zZm9ybVZOb2RlQXJncywgdXNlQXR0cnMsIHVzZUlkLCB1c2VNb2RlbCwgdXNlU1NSQ29udGV4dCwgdXNlU2xvdHMsIHVzZVRlbXBsYXRlUmVmLCB1c2VUcmFuc2l0aW9uU3RhdGUsIHZlcnNpb24sIHdhcm4sIHdhdGNoLCB3YXRjaEVmZmVjdCwgd2F0Y2hQb3N0RWZmZWN0LCB3YXRjaFN5bmNFZmZlY3QsIHdpdGhBc3luY0NvbnRleHQsIHdpdGhDdHgsIHdpdGhEZWZhdWx0cywgd2l0aERpcmVjdGl2ZXMsIHdpdGhNZW1vLCB3aXRoU2NvcGVJZCB9O1xuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=