import { A as Q, i as S, n as BaseStyle, r as R, t as showInvalidLicenseBanner } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.cache/vite/client/deps/licenseBanner-BJm6_Mu3.js?v=7e73afc2";
import { t as PrimeVueService } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.cache/vite/client/deps/service-DHO3JZnA.js?v=7e73afc2";
import { inject, reactive, readonly, ref, watch } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
/*! noble-ed25519 - MIT License (c) 2019 Paul Miller (paulmillr.com) */
var { p: P, n: N, Gx, Gy, a: _a, d: _d } = {
	p: 57896044618658097711785492504343953926634992332820282019728792003956564819949n,
	n: 7237005577332262213973186563042994240857116359379907606001950938285454250989n,
	h: 8n,
	a: 57896044618658097711785492504343953926634992332820282019728792003956564819948n,
	d: 37095705934669439343138083508754565189542113879843219016388785533085940283555n,
	Gx: 15112221349535400772501151409588531511454012693041857206046113283949847762202n,
	Gy: 46316835694926478169428394003475163141307993866256225615783033603165251855960n
};
var h$2 = 8n;
var L = 32;
var L2 = 64;
var err = (m = "") => {
	throw new Error(m);
};
var isBig = (n) => typeof n === "bigint";
var isStr = (s) => typeof s === "string";
var isBytes$1 = (a) => a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
/** assert is Uint8Array (of specific length) */
var abytes$1 = (a, l) => !isBytes$1(a) || typeof l === "number" && l > 0 && a.length !== l ? err("Uint8Array expected") : a;
/** create Uint8Array */
var u8n = (len) => new Uint8Array(len);
var u8fr = (buf) => Uint8Array.from(buf);
var padh = (n, pad) => n.toString(16).padStart(pad, "0");
var bytesToHex = (b) => Array.from(abytes$1(b)).map((e) => padh(e, 2)).join("");
var C = {
	_0: 48,
	_9: 57,
	A: 65,
	F: 70,
	a: 97,
	f: 102
};
var _ch = (ch) => {
	if (ch >= C._0 && ch <= C._9) return ch - C._0;
	if (ch >= C.A && ch <= C.F) return ch - (C.A - 10);
	if (ch >= C.a && ch <= C.f) return ch - (C.a - 10);
};
var hexToBytes = (hex) => {
	const e = "hex invalid";
	if (!isStr(hex)) return err(e);
	const hl = hex.length;
	const al = hl / 2;
	if (hl % 2) return err(e);
	const array = u8n(al);
	for (let ai = 0, hi = 0; ai < al; ai++, hi += 2) {
		const n1 = _ch(hex.charCodeAt(hi));
		const n2 = _ch(hex.charCodeAt(hi + 1));
		if (n1 === void 0 || n2 === void 0) return err(e);
		array[ai] = n1 * 16 + n2;
	}
	return array;
};
/** normalize hex or ui8a to ui8a */
var toU8 = (a, len) => abytes$1(isStr(a) ? hexToBytes(a) : u8fr(abytes$1(a)), len);
var cr = () => globalThis?.crypto;
var subtle = () => cr()?.subtle ?? err("crypto.subtle must be defined");
var concatBytes = (...arrs) => {
	const r = u8n(arrs.reduce((sum, a) => sum + abytes$1(a).length, 0));
	let pad = 0;
	arrs.forEach((a) => {
		r.set(a, pad);
		pad += a.length;
	});
	return r;
};
/** WebCrypto OS-level CSPRNG (random number generator). Will throw when not available. */
var randomBytes = (len = L) => {
	return cr().getRandomValues(u8n(len));
};
var big = BigInt;
var arange = (n, min, max, msg = "bad number: out of range") => isBig(n) && min <= n && n < max ? n : err(msg);
/** modular division */
var M = (a, b = P) => {
	const r = a % b;
	return r >= 0n ? r : b + r;
};
var modN = (a) => M(a, N);
/** Modular inversion using eucledian GCD (non-CT). No negative exponent for now. */
var invert = (num, md) => {
	if (num === 0n || md <= 0n) err("no inverse n=" + num + " mod=" + md);
	let a = M(num, md), b = md, x = 0n, y = 1n, u = 1n, v = 0n;
	while (a !== 0n) {
		const q = b / a, r = b % a;
		const m = x - u * q, n = y - v * q;
		b = a, a = r, x = u, y = v, u = m, v = n;
	}
	return b === 1n ? M(x, md) : err("no inverse");
};
var callHash = (name) => {
	const fn = etc[name];
	if (typeof fn !== "function") err("hashes." + name + " not set");
	return fn;
};
var apoint = (p) => p instanceof Point ? p : err("Point expected");
var B256 = 2n ** 256n;
/** Point in XYZT extended coordinates. */
var Point = class Point {
	static BASE;
	static ZERO;
	ex;
	ey;
	ez;
	et;
	constructor(ex, ey, ez, et) {
		const max = B256;
		this.ex = arange(ex, 0n, max);
		this.ey = arange(ey, 0n, max);
		this.ez = arange(ez, 1n, max);
		this.et = arange(et, 0n, max);
		Object.freeze(this);
	}
	static fromAffine(p) {
		return new Point(p.x, p.y, 1n, M(p.x * p.y));
	}
	/** RFC8032 5.1.3: Uint8Array to Point. */
	static fromBytes(hex, zip215 = false) {
		const d = _d;
		const normed = u8fr(abytes$1(hex, L));
		const lastByte = hex[31];
		normed[31] = lastByte & -129;
		const y = bytesToNumLE(normed);
		arange(y, 0n, zip215 ? B256 : P);
		const y2 = M(y * y);
		let { isValid, value: x } = uvRatio(M(y2 - 1n), M(d * y2 + 1n));
		if (!isValid) err("bad point: y not sqrt");
		const isXOdd = (x & 1n) === 1n;
		const isLastByteOdd = (lastByte & 128) !== 0;
		if (!zip215 && x === 0n && isLastByteOdd) err("bad point: x==0, isLastByteOdd");
		if (isLastByteOdd !== isXOdd) x = M(-x);
		return new Point(x, y, 1n, M(x * y));
	}
	/** Checks if the point is valid and on-curve. */
	assertValidity() {
		const a = _a;
		const d = _d;
		const p = this;
		if (p.is0()) throw new Error("bad point: ZERO");
		const { ex: X, ey: Y, ez: Z, et: T } = p;
		const X2 = M(X * X);
		const Y2 = M(Y * Y);
		const Z2 = M(Z * Z);
		const Z4 = M(Z2 * Z2);
		if (M(Z2 * M(M(X2 * a) + Y2)) !== M(Z4 + M(d * M(X2 * Y2)))) throw new Error("bad point: equation left != right (1)");
		if (M(X * Y) !== M(Z * T)) throw new Error("bad point: equation left != right (2)");
		return this;
	}
	/** Equality check: compare points P&Q. */
	equals(other) {
		const { ex: X1, ey: Y1, ez: Z1 } = this;
		const { ex: X2, ey: Y2, ez: Z2 } = apoint(other);
		const X1Z2 = M(X1 * Z2);
		const X2Z1 = M(X2 * Z1);
		const Y1Z2 = M(Y1 * Z2);
		const Y2Z1 = M(Y2 * Z1);
		return X1Z2 === X2Z1 && Y1Z2 === Y2Z1;
	}
	is0() {
		return this.equals(I);
	}
	/** Flip point over y coordinate. */
	negate() {
		return new Point(M(-this.ex), this.ey, this.ez, M(-this.et));
	}
	/** Point doubling. Complete formula. Cost: `4M + 4S + 1*a + 6add + 1*2`. */
	double() {
		const { ex: X1, ey: Y1, ez: Z1 } = this;
		const a = _a;
		const A = M(X1 * X1);
		const B = M(Y1 * Y1);
		const C = M(2n * M(Z1 * Z1));
		const D = M(a * A);
		const x1y1 = X1 + Y1;
		const E = M(M(x1y1 * x1y1) - A - B);
		const G = D + B;
		const F = G - C;
		const H = D - B;
		const X3 = M(E * F);
		const Y3 = M(G * H);
		const T3 = M(E * H);
		const Z3 = M(F * G);
		return new Point(X3, Y3, Z3, T3);
	}
	/** Point addition. Complete formula. Cost: `8M + 1*k + 8add + 1*2`. */
	add(other) {
		const { ex: X1, ey: Y1, ez: Z1, et: T1 } = this;
		const { ex: X2, ey: Y2, ez: Z2, et: T2 } = apoint(other);
		const a = _a;
		const d = _d;
		const A = M(X1 * X2);
		const B = M(Y1 * Y2);
		const C = M(T1 * d * T2);
		const D = M(Z1 * Z2);
		const E = M((X1 + Y1) * (X2 + Y2) - A - B);
		const F = M(D - C);
		const G = M(D + C);
		const H = M(B - a * A);
		const X3 = M(E * F);
		const Y3 = M(G * H);
		const T3 = M(E * H);
		const Z3 = M(F * G);
		return new Point(X3, Y3, Z3, T3);
	}
	/**
	* Point-by-scalar multiplication. Scalar must be in range 1 <= n < CURVE.n.
	* Uses {@link wNAF} for base point.
	* Uses fake point to mitigate side-channel leakage.
	* @param n scalar by which point is multiplied
	* @param safe safe mode guards against timing attacks; unsafe mode is faster
	*/
	multiply(n, safe = true) {
		if (!safe && (n === 0n || this.is0())) return I;
		arange(n, 1n, N);
		if (n === 1n) return this;
		if (this.equals(G)) return wNAF(n).p;
		let p = I;
		let f = G;
		for (let d = this; n > 0n; d = d.double(), n >>= 1n) if (n & 1n) p = p.add(d);
		else if (safe) f = f.add(d);
		return p;
	}
	/** Convert point to 2d xy affine point. (X, Y, Z) ∋ (x=X/Z, y=Y/Z) */
	toAffine() {
		const { ex: x, ey: y, ez: z } = this;
		if (this.equals(I)) return {
			x: 0n,
			y: 1n
		};
		const iz = invert(z, P);
		if (M(z * iz) !== 1n) err("invalid inverse");
		return {
			x: M(x * iz),
			y: M(y * iz)
		};
	}
	toBytes() {
		const { x, y } = this.assertValidity().toAffine();
		const b = numTo32bLE(y);
		b[31] |= x & 1n ? 128 : 0;
		return b;
	}
	toHex() {
		return bytesToHex(this.toBytes());
	}
	clearCofactor() {
		return this.multiply(big(h$2), false);
	}
	isSmallOrder() {
		return this.clearCofactor().is0();
	}
	isTorsionFree() {
		let p = this.multiply(N / 2n, false).double();
		if (N % 2n) p = p.add(this);
		return p.is0();
	}
	static fromHex(hex, zip215) {
		return Point.fromBytes(toU8(hex), zip215);
	}
	get x() {
		return this.toAffine().x;
	}
	get y() {
		return this.toAffine().y;
	}
	toRawBytes() {
		return this.toBytes();
	}
};
/** Generator / base point */
var G = new Point(Gx, Gy, 1n, M(Gx * Gy));
/** Identity / zero point */
var I = new Point(0n, 1n, 1n, 0n);
Point.BASE = G;
Point.ZERO = I;
var numTo32bLE = (num) => hexToBytes(padh(arange(num, 0n, B256), L2)).reverse();
var bytesToNumLE = (b) => big("0x" + bytesToHex(u8fr(abytes$1(b)).reverse()));
var pow2 = (x, power) => {
	let r = x;
	while (power-- > 0n) {
		r *= r;
		r %= P;
	}
	return r;
};
var pow_2_252_3 = (x) => {
	const b2 = x * x % P * x % P;
	const b5 = pow2(pow2(b2, 2n) * b2 % P, 1n) * x % P;
	const b10 = pow2(b5, 5n) * b5 % P;
	const b20 = pow2(b10, 10n) * b10 % P;
	const b40 = pow2(b20, 20n) * b20 % P;
	const b80 = pow2(b40, 40n) * b40 % P;
	return {
		pow_p_5_8: pow2(pow2(pow2(pow2(b80, 80n) * b80 % P, 80n) * b80 % P, 10n) * b10 % P, 2n) * x % P,
		b2
	};
};
var RM1 = 19681161376707505956807079304988542015446066515923890162744021073123829784752n;
var uvRatio = (u, v) => {
	const v3 = M(v * v * v);
	const pow = pow_2_252_3(u * M(v3 * v3 * v)).pow_p_5_8;
	let x = M(u * v3 * pow);
	const vx2 = M(v * x * x);
	const root1 = x;
	const root2 = M(x * RM1);
	const useRoot1 = vx2 === u;
	const useRoot2 = vx2 === M(-u);
	const noRoot = vx2 === M(-u * RM1);
	if (useRoot1) x = root1;
	if (useRoot2 || noRoot) x = root2;
	if ((M(x) & 1n) === 1n) x = M(-x);
	return {
		isValid: useRoot1 || useRoot2,
		value: x
	};
};
var modL_LE = (hash) => modN(bytesToNumLE(hash));
var sha512s = (...m) => callHash("sha512Sync")(...m);
var hashFinishS = (res) => res.finish(sha512s(res.hashable));
var veriOpts = { zip215: true };
var _verify = (sig, msg, pub, opts = veriOpts) => {
	sig = toU8(sig, L2);
	msg = toU8(msg);
	pub = toU8(pub, L);
	const { zip215 } = opts;
	let A;
	let R;
	let s;
	let SB;
	let hashable = Uint8Array.of();
	try {
		A = Point.fromHex(pub, zip215);
		R = Point.fromHex(sig.slice(0, L), zip215);
		s = bytesToNumLE(sig.slice(L, L2));
		SB = G.multiply(s, false);
		hashable = concatBytes(R.toBytes(), A.toBytes(), msg);
	} catch (error) {}
	const finish = (hashed) => {
		if (SB == null) return false;
		if (!zip215 && A.isSmallOrder()) return false;
		const k = modL_LE(hashed);
		return R.add(A.multiply(k, false)).add(SB.negate()).clearCofactor().is0();
	};
	return {
		hashable,
		finish
	};
};
/** Verifies signature on message and public key. To use, set `hashes.sha512` first. Follows RFC8032 5.1.7. */
var verify = (s, m, p, opts = veriOpts) => hashFinishS(_verify(s, m, p, opts));
/** Math, hex, byte helpers. Not in `utils` because utils share API with noble-curves. */
var etc = {
	sha512Async: async (...messages) => {
		const s = subtle();
		const m = concatBytes(...messages);
		return u8n(await s.digest("SHA-512", m.buffer));
	},
	sha512Sync: void 0,
	bytesToHex,
	hexToBytes,
	concatBytes,
	mod: M,
	invert,
	randomBytes
};
var W = 8;
var pwindows = Math.ceil(256 / W) + 1;
var pwindowSize = 2 ** 7;
var precompute = () => {
	const points = [];
	let p = G;
	let b = p;
	for (let w = 0; w < pwindows; w++) {
		b = p;
		points.push(b);
		for (let i = 1; i < pwindowSize; i++) {
			b = b.add(p);
			points.push(b);
		}
		p = b.double();
	}
	return points;
};
var Gpows = void 0;
var ctneg = (cnd, p) => {
	const n = p.negate();
	return cnd ? n : p;
};
/**
* Precomputes give 12x faster getPublicKey(), 10x sign(), 2x verify() by
* caching multiples of G (base point). Cache is stored in 32MB of RAM.
* Any time `G.multiply` is done, precomputes are used.
* Not used for getSharedSecret, which instead multiplies random pubkey `P.multiply`.
*
* w-ary non-adjacent form (wNAF) precomputation method is 10% slower than windowed method,
* but takes 2x less RAM. RAM reduction is possible by utilizing `.subtract`.
*
* !! Precomputes can be disabled by commenting-out call of the wNAF() inside Point#multiply().
*/
var wNAF = (n) => {
	const comp = Gpows || (Gpows = precompute());
	let p = I;
	let f = G;
	const maxNum = 2 ** W;
	const mask = big(255);
	const shiftBy = big(W);
	for (let w = 0; w < pwindows; w++) {
		let wbits = Number(n & mask);
		n >>= shiftBy;
		if (wbits > pwindowSize) {
			wbits -= maxNum;
			n += 1n;
		}
		const off = w * pwindowSize;
		const offF = off;
		const offP = off + Math.abs(wbits) - 1;
		const isEven = w % 2 !== 0;
		const isNeg = wbits < 0;
		if (wbits === 0) f = f.add(ctneg(isEven, comp[offF]));
		else p = p.add(ctneg(isNeg, comp[offP]));
	}
	return {
		p,
		f
	};
};
//#endregion
//#region node_modules/.pnpm/@noble+hashes@2.2.0/node_modules/@noble/hashes/utils.js
/**
* Checks if something is Uint8Array. Be careful: nodejs Buffer will return true.
* @param a - value to test
* @returns `true` when the value is a Uint8Array-compatible view.
* @example
* Check whether a value is a Uint8Array-compatible view.
* ```ts
* isBytes(new Uint8Array([1, 2, 3]));
* ```
*/
function isBytes(a) {
	return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in a && a.BYTES_PER_ELEMENT === 1;
}
/**
* Asserts something is Uint8Array.
* @param value - value to validate
* @param length - optional exact length constraint
* @param title - label included in thrown errors
* @returns The validated byte array.
* @throws On wrong argument types. {@link TypeError}
* @throws On wrong argument ranges or values. {@link RangeError}
* @example
* Validate that a value is a byte array.
* ```ts
* abytes(new Uint8Array([1, 2, 3]));
* ```
*/
function abytes(value, length, title = "") {
	const bytes = isBytes(value);
	const len = value?.length;
	const needsLen = length !== void 0;
	if (!bytes || needsLen && len !== length) {
		const prefix = title && `"${title}" `;
		const ofLen = needsLen ? ` of length ${length}` : "";
		const got = bytes ? `length=${len}` : `type=${typeof value}`;
		const message = prefix + "expected Uint8Array" + ofLen + ", got " + got;
		if (!bytes) throw new TypeError(message);
		throw new RangeError(message);
	}
	return value;
}
/**
* Asserts a hash instance has not been destroyed or finished.
* @param instance - hash instance to validate
* @param checkFinished - whether to reject finalized instances
* @throws If the hash instance has already been destroyed or finalized. {@link Error}
* @example
* Validate that a hash instance is still usable.
* ```ts
* import { aexists } from '@noble/hashes/utils.js';
* import { sha256 } from '@noble/hashes/sha2.js';
* const hash = sha256.create();
* aexists(hash);
* ```
*/
function aexists(instance, checkFinished = true) {
	if (instance.destroyed) throw new Error("Hash instance has been destroyed");
	if (checkFinished && instance.finished) throw new Error("Hash#digest() has already been called");
}
/**
* Asserts output is a sufficiently-sized byte array.
* @param out - destination buffer
* @param instance - hash instance providing output length
* Oversized buffers are allowed; downstream code only promises to fill the first `outputLen` bytes.
* @throws On wrong argument types. {@link TypeError}
* @throws On wrong argument ranges or values. {@link RangeError}
* @example
* Validate a caller-provided digest buffer.
* ```ts
* import { aoutput } from '@noble/hashes/utils.js';
* import { sha256 } from '@noble/hashes/sha2.js';
* const hash = sha256.create();
* aoutput(new Uint8Array(hash.outputLen), hash);
* ```
*/
function aoutput(out, instance) {
	abytes(out, void 0, "digestInto() output");
	const min = instance.outputLen;
	if (out.length < min) throw new RangeError("\"digestInto() output\" expected to be of length >=" + min);
}
/**
* Zeroizes typed arrays in place. Warning: JS provides no guarantees.
* @param arrays - arrays to overwrite with zeros
* @example
* Zeroize sensitive buffers in place.
* ```ts
* clean(new Uint8Array([1, 2, 3]));
* ```
*/
function clean(...arrays) {
	for (let i = 0; i < arrays.length; i++) arrays[i].fill(0);
}
/**
* Creates a DataView for byte-level manipulation.
* @param arr - source typed array
* @returns DataView over the same buffer region.
* @example
* Create a DataView over an existing buffer.
* ```ts
* createView(new Uint8Array(4));
* ```
*/
function createView(arr) {
	return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
/**
* Creates a callable hash function from a stateful class constructor.
* @param hashCons - hash constructor or factory
* @param info - optional metadata such as DER OID
* @returns Frozen callable hash wrapper with `.create()`.
*   Wrapper construction eagerly calls `hashCons(undefined)` once to read
*   `outputLen` / `blockLen`, so constructor side effects happen at module
*   init time.
* @example
* Wrap a stateful hash constructor into a callable helper.
* ```ts
* import { createHasher } from '@noble/hashes/utils.js';
* import { sha256 } from '@noble/hashes/sha2.js';
* const wrapped = createHasher(sha256.create, { oid: sha256.oid });
* wrapped(new Uint8Array([1]));
* ```
*/
function createHasher(hashCons, info = {}) {
	const hashC = (msg, opts) => hashCons(opts).update(msg).digest();
	const tmp = hashCons(void 0);
	hashC.outputLen = tmp.outputLen;
	hashC.blockLen = tmp.blockLen;
	hashC.canXOF = tmp.canXOF;
	hashC.create = (opts) => hashCons(opts);
	Object.assign(hashC, info);
	return Object.freeze(hashC);
}
/**
* Creates OID metadata for NIST hashes with prefix `06 09 60 86 48 01 65 03 04 02`.
* @param suffix - final OID byte for the selected hash.
*   The helper accepts any byte even though only the documented NIST hash
*   suffixes are meaningful downstream.
* @returns Object containing the DER-encoded OID.
* @example
* Build OID metadata for a NIST hash.
* ```ts
* oidNist(0x01);
* ```
*/
var oidNist = (suffix) => ({ oid: Uint8Array.from([
	6,
	9,
	96,
	134,
	72,
	1,
	101,
	3,
	4,
	2,
	suffix
]) });
//#endregion
//#region node_modules/.pnpm/@noble+hashes@2.2.0/node_modules/@noble/hashes/_md.js
/**
* Internal Merkle-Damgard hash utils.
* @module
*/
/**
* Merkle-Damgard hash construction base class.
* Could be used to create MD5, RIPEMD, SHA1, SHA2.
* Accepts only byte-aligned `Uint8Array` input, even when the underlying spec describes bit
* strings with partial-byte tails.
* @param blockLen - internal block size in bytes
* @param outputLen - digest size in bytes
* @param padOffset - trailing length field size in bytes
* @param isLE - whether length and state words are encoded in little-endian
* @example
* Use a concrete subclass to get the shared Merkle-Damgard update/digest flow.
* ```ts
* import { _SHA1 } from '@noble/hashes/legacy.js';
* const hash = new _SHA1();
* hash.update(new Uint8Array([97, 98, 99]));
* hash.digest();
* ```
*/
var HashMD = class {
	blockLen;
	outputLen;
	canXOF = false;
	padOffset;
	isLE;
	buffer;
	view;
	finished = false;
	length = 0;
	pos = 0;
	destroyed = false;
	constructor(blockLen, outputLen, padOffset, isLE) {
		this.blockLen = blockLen;
		this.outputLen = outputLen;
		this.padOffset = padOffset;
		this.isLE = isLE;
		this.buffer = new Uint8Array(blockLen);
		this.view = createView(this.buffer);
	}
	update(data) {
		aexists(this);
		abytes(data);
		const { view, buffer, blockLen } = this;
		const len = data.length;
		for (let pos = 0; pos < len;) {
			const take = Math.min(blockLen - this.pos, len - pos);
			if (take === blockLen) {
				const dataView = createView(data);
				for (; blockLen <= len - pos; pos += blockLen) this.process(dataView, pos);
				continue;
			}
			buffer.set(data.subarray(pos, pos + take), this.pos);
			this.pos += take;
			pos += take;
			if (this.pos === blockLen) {
				this.process(view, 0);
				this.pos = 0;
			}
		}
		this.length += data.length;
		this.roundClean();
		return this;
	}
	digestInto(out) {
		aexists(this);
		aoutput(out, this);
		this.finished = true;
		const { buffer, view, blockLen, isLE } = this;
		let { pos } = this;
		buffer[pos++] = 128;
		clean(this.buffer.subarray(pos));
		if (this.padOffset > blockLen - pos) {
			this.process(view, 0);
			pos = 0;
		}
		for (let i = pos; i < blockLen; i++) buffer[i] = 0;
		view.setBigUint64(blockLen - 8, BigInt(this.length * 8), isLE);
		this.process(view, 0);
		const oview = createView(out);
		const len = this.outputLen;
		if (len % 4) throw new Error("_sha2: outputLen must be aligned to 32bit");
		const outLen = len / 4;
		const state = this.get();
		if (outLen > state.length) throw new Error("_sha2: outputLen bigger than state");
		for (let i = 0; i < outLen; i++) oview.setUint32(4 * i, state[i], isLE);
	}
	digest() {
		const { buffer, outputLen } = this;
		this.digestInto(buffer);
		const res = buffer.slice(0, outputLen);
		this.destroy();
		return res;
	}
	_cloneInto(to) {
		to ||= new this.constructor();
		to.set(...this.get());
		const { blockLen, buffer, length, finished, destroyed, pos } = this;
		to.destroyed = destroyed;
		to.finished = finished;
		to.length = length;
		to.pos = pos;
		if (length % blockLen) to.buffer.set(buffer);
		return to;
	}
	clone() {
		return this._cloneInto();
	}
};
/** Initial SHA512 state from RFC 6234 §6.3: eight RFC 64-bit `H(0)` words stored as sixteen
* big-endian 32-bit halves. Derived from the fractional parts of the square roots of the first
* eight prime numbers. Exported as a shared table; callers must treat it as read-only because
* constructors copy halves from it by index. */
var SHA512_IV = /* @__PURE__ */ Uint32Array.from([
	1779033703,
	4089235720,
	3144134277,
	2227873595,
	1013904242,
	4271175723,
	2773480762,
	1595750129,
	1359893119,
	2917565137,
	2600822924,
	725511199,
	528734635,
	4215389547,
	1541459225,
	327033209
]);
//#endregion
//#region node_modules/.pnpm/@noble+hashes@2.2.0/node_modules/@noble/hashes/_u64.js
var U32_MASK64 = /* @__PURE__ */ BigInt(2 ** 32 - 1);
var _32n = /* @__PURE__ */ BigInt(32);
function fromBig(n, le = false) {
	if (le) return {
		h: Number(n & U32_MASK64),
		l: Number(n >> _32n & U32_MASK64)
	};
	return {
		h: Number(n >> _32n & U32_MASK64) | 0,
		l: Number(n & U32_MASK64) | 0
	};
}
function split(lst, le = false) {
	const len = lst.length;
	let Ah = new Uint32Array(len);
	let Al = new Uint32Array(len);
	for (let i = 0; i < len; i++) {
		const { h, l } = fromBig(lst[i], le);
		[Ah[i], Al[i]] = [h, l];
	}
	return [Ah, Al];
}
var shrSH = (h, _l, s) => h >>> s;
var shrSL = (h, l, s) => h << 32 - s | l >>> s;
var rotrSH = (h, l, s) => h >>> s | l << 32 - s;
var rotrSL = (h, l, s) => h << 32 - s | l >>> s;
var rotrBH = (h, l, s) => h << 64 - s | l >>> s - 32;
var rotrBL = (h, l, s) => h >>> s - 32 | l << 64 - s;
function add(Ah, Al, Bh, Bl) {
	const l = (Al >>> 0) + (Bl >>> 0);
	return {
		h: Ah + Bh + (l / 2 ** 32 | 0) | 0,
		l: l | 0
	};
}
var add3L = (Al, Bl, Cl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0);
var add3H = (low, Ah, Bh, Ch) => Ah + Bh + Ch + (low / 2 ** 32 | 0) | 0;
var add4L = (Al, Bl, Cl, Dl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0);
var add4H = (low, Ah, Bh, Ch, Dh) => Ah + Bh + Ch + Dh + (low / 2 ** 32 | 0) | 0;
var add5L = (Al, Bl, Cl, Dl, El) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0) + (El >>> 0);
var add5H = (low, Ah, Bh, Ch, Dh, Eh) => Ah + Bh + Ch + Dh + Eh + (low / 2 ** 32 | 0) | 0;
//#endregion
//#region node_modules/.pnpm/@noble+hashes@2.2.0/node_modules/@noble/hashes/sha2.js
/**
* SHA2 hash function. A.k.a. sha256, sha384, sha512, sha512_224, sha512_256.
* SHA256 is the fastest hash implementable in JS, even faster than Blake3.
* Check out {@link https://www.rfc-editor.org/rfc/rfc4634 | RFC 4634} and
* {@link https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.180-4.pdf | FIPS 180-4}.
* @module
*/
var K512 = /* @__PURE__ */ (() => split([
	"0x428a2f98d728ae22",
	"0x7137449123ef65cd",
	"0xb5c0fbcfec4d3b2f",
	"0xe9b5dba58189dbbc",
	"0x3956c25bf348b538",
	"0x59f111f1b605d019",
	"0x923f82a4af194f9b",
	"0xab1c5ed5da6d8118",
	"0xd807aa98a3030242",
	"0x12835b0145706fbe",
	"0x243185be4ee4b28c",
	"0x550c7dc3d5ffb4e2",
	"0x72be5d74f27b896f",
	"0x80deb1fe3b1696b1",
	"0x9bdc06a725c71235",
	"0xc19bf174cf692694",
	"0xe49b69c19ef14ad2",
	"0xefbe4786384f25e3",
	"0x0fc19dc68b8cd5b5",
	"0x240ca1cc77ac9c65",
	"0x2de92c6f592b0275",
	"0x4a7484aa6ea6e483",
	"0x5cb0a9dcbd41fbd4",
	"0x76f988da831153b5",
	"0x983e5152ee66dfab",
	"0xa831c66d2db43210",
	"0xb00327c898fb213f",
	"0xbf597fc7beef0ee4",
	"0xc6e00bf33da88fc2",
	"0xd5a79147930aa725",
	"0x06ca6351e003826f",
	"0x142929670a0e6e70",
	"0x27b70a8546d22ffc",
	"0x2e1b21385c26c926",
	"0x4d2c6dfc5ac42aed",
	"0x53380d139d95b3df",
	"0x650a73548baf63de",
	"0x766a0abb3c77b2a8",
	"0x81c2c92e47edaee6",
	"0x92722c851482353b",
	"0xa2bfe8a14cf10364",
	"0xa81a664bbc423001",
	"0xc24b8b70d0f89791",
	"0xc76c51a30654be30",
	"0xd192e819d6ef5218",
	"0xd69906245565a910",
	"0xf40e35855771202a",
	"0x106aa07032bbd1b8",
	"0x19a4c116b8d2d0c8",
	"0x1e376c085141ab53",
	"0x2748774cdf8eeb99",
	"0x34b0bcb5e19b48a8",
	"0x391c0cb3c5c95a63",
	"0x4ed8aa4ae3418acb",
	"0x5b9cca4f7763e373",
	"0x682e6ff3d6b2b8a3",
	"0x748f82ee5defb2fc",
	"0x78a5636f43172f60",
	"0x84c87814a1f0ab72",
	"0x8cc702081a6439ec",
	"0x90befffa23631e28",
	"0xa4506cebde82bde9",
	"0xbef9a3f7b2c67915",
	"0xc67178f2e372532b",
	"0xca273eceea26619c",
	"0xd186b8c721c0c207",
	"0xeada7dd6cde0eb1e",
	"0xf57d4f7fee6ed178",
	"0x06f067aa72176fba",
	"0x0a637dc5a2c898a6",
	"0x113f9804bef90dae",
	"0x1b710b35131c471b",
	"0x28db77f523047d84",
	"0x32caab7b40c72493",
	"0x3c9ebe0a15c9bebc",
	"0x431d67c49c100d4c",
	"0x4cc5d4becb3e42b6",
	"0x597f299cfc657e2a",
	"0x5fcb6fab3ad6faec",
	"0x6c44198c4a475817"
].map((n) => BigInt(n))))();
var SHA512_Kh = /* @__PURE__ */ (() => K512[0])();
var SHA512_Kl = /* @__PURE__ */ (() => K512[1])();
var SHA512_W_H = /* @__PURE__ */ new Uint32Array(80);
var SHA512_W_L = /* @__PURE__ */ new Uint32Array(80);
/** Internal SHA-384 / SHA-512 compression engine from RFC 6234 §6.4. */
var SHA2_64B = class extends HashMD {
	constructor(outputLen) {
		super(128, outputLen, 16, false);
	}
	get() {
		const { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
		return [
			Ah,
			Al,
			Bh,
			Bl,
			Ch,
			Cl,
			Dh,
			Dl,
			Eh,
			El,
			Fh,
			Fl,
			Gh,
			Gl,
			Hh,
			Hl
		];
	}
	set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl) {
		this.Ah = Ah | 0;
		this.Al = Al | 0;
		this.Bh = Bh | 0;
		this.Bl = Bl | 0;
		this.Ch = Ch | 0;
		this.Cl = Cl | 0;
		this.Dh = Dh | 0;
		this.Dl = Dl | 0;
		this.Eh = Eh | 0;
		this.El = El | 0;
		this.Fh = Fh | 0;
		this.Fl = Fl | 0;
		this.Gh = Gh | 0;
		this.Gl = Gl | 0;
		this.Hh = Hh | 0;
		this.Hl = Hl | 0;
	}
	process(view, offset) {
		for (let i = 0; i < 16; i++, offset += 4) {
			SHA512_W_H[i] = view.getUint32(offset);
			SHA512_W_L[i] = view.getUint32(offset += 4);
		}
		for (let i = 16; i < 80; i++) {
			const W15h = SHA512_W_H[i - 15] | 0;
			const W15l = SHA512_W_L[i - 15] | 0;
			const s0h = rotrSH(W15h, W15l, 1) ^ rotrSH(W15h, W15l, 8) ^ shrSH(W15h, W15l, 7);
			const s0l = rotrSL(W15h, W15l, 1) ^ rotrSL(W15h, W15l, 8) ^ shrSL(W15h, W15l, 7);
			const W2h = SHA512_W_H[i - 2] | 0;
			const W2l = SHA512_W_L[i - 2] | 0;
			const s1h = rotrSH(W2h, W2l, 19) ^ rotrBH(W2h, W2l, 61) ^ shrSH(W2h, W2l, 6);
			const SUMl = add4L(s0l, rotrSL(W2h, W2l, 19) ^ rotrBL(W2h, W2l, 61) ^ shrSL(W2h, W2l, 6), SHA512_W_L[i - 7], SHA512_W_L[i - 16]);
			const SUMh = add4H(SUMl, s0h, s1h, SHA512_W_H[i - 7], SHA512_W_H[i - 16]);
			SHA512_W_H[i] = SUMh | 0;
			SHA512_W_L[i] = SUMl | 0;
		}
		let { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
		for (let i = 0; i < 80; i++) {
			const sigma1h = rotrSH(Eh, El, 14) ^ rotrSH(Eh, El, 18) ^ rotrBH(Eh, El, 41);
			const sigma1l = rotrSL(Eh, El, 14) ^ rotrSL(Eh, El, 18) ^ rotrBL(Eh, El, 41);
			const CHIh = Eh & Fh ^ ~Eh & Gh;
			const CHIl = El & Fl ^ ~El & Gl;
			const T1ll = add5L(Hl, sigma1l, CHIl, SHA512_Kl[i], SHA512_W_L[i]);
			const T1h = add5H(T1ll, Hh, sigma1h, CHIh, SHA512_Kh[i], SHA512_W_H[i]);
			const T1l = T1ll | 0;
			const sigma0h = rotrSH(Ah, Al, 28) ^ rotrBH(Ah, Al, 34) ^ rotrBH(Ah, Al, 39);
			const sigma0l = rotrSL(Ah, Al, 28) ^ rotrBL(Ah, Al, 34) ^ rotrBL(Ah, Al, 39);
			const MAJh = Ah & Bh ^ Ah & Ch ^ Bh & Ch;
			const MAJl = Al & Bl ^ Al & Cl ^ Bl & Cl;
			Hh = Gh | 0;
			Hl = Gl | 0;
			Gh = Fh | 0;
			Gl = Fl | 0;
			Fh = Eh | 0;
			Fl = El | 0;
			({h: Eh, l: El} = add(Dh | 0, Dl | 0, T1h | 0, T1l | 0));
			Dh = Ch | 0;
			Dl = Cl | 0;
			Ch = Bh | 0;
			Cl = Bl | 0;
			Bh = Ah | 0;
			Bl = Al | 0;
			const All = add3L(T1l, sigma0l, MAJl);
			Ah = add3H(All, T1h, sigma0h, MAJh);
			Al = All | 0;
		}
		({h: Ah, l: Al} = add(this.Ah | 0, this.Al | 0, Ah | 0, Al | 0));
		({h: Bh, l: Bl} = add(this.Bh | 0, this.Bl | 0, Bh | 0, Bl | 0));
		({h: Ch, l: Cl} = add(this.Ch | 0, this.Cl | 0, Ch | 0, Cl | 0));
		({h: Dh, l: Dl} = add(this.Dh | 0, this.Dl | 0, Dh | 0, Dl | 0));
		({h: Eh, l: El} = add(this.Eh | 0, this.El | 0, Eh | 0, El | 0));
		({h: Fh, l: Fl} = add(this.Fh | 0, this.Fl | 0, Fh | 0, Fl | 0));
		({h: Gh, l: Gl} = add(this.Gh | 0, this.Gl | 0, Gh | 0, Gl | 0));
		({h: Hh, l: Hl} = add(this.Hh | 0, this.Hl | 0, Hh | 0, Hl | 0));
		this.set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl);
	}
	roundClean() {
		clean(SHA512_W_H, SHA512_W_L);
	}
	destroy() {
		this.destroyed = true;
		clean(this.buffer);
		this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	}
};
/** Internal SHA-512 hash class grounded in RFC 6234 §6.3 and §6.4. */
var _SHA512 = class extends SHA2_64B {
	Ah = SHA512_IV[0] | 0;
	Al = SHA512_IV[1] | 0;
	Bh = SHA512_IV[2] | 0;
	Bl = SHA512_IV[3] | 0;
	Ch = SHA512_IV[4] | 0;
	Cl = SHA512_IV[5] | 0;
	Dh = SHA512_IV[6] | 0;
	Dl = SHA512_IV[7] | 0;
	Eh = SHA512_IV[8] | 0;
	El = SHA512_IV[9] | 0;
	Fh = SHA512_IV[10] | 0;
	Fl = SHA512_IV[11] | 0;
	Gh = SHA512_IV[12] | 0;
	Gl = SHA512_IV[13] | 0;
	Hh = SHA512_IV[14] | 0;
	Hl = SHA512_IV[15] | 0;
	constructor() {
		super(64);
	}
};
/**
* SHA2-512 hash function from RFC 4634.
* @param msg - message bytes to hash
* @returns Digest bytes.
* @example
* Hash a message with SHA2-512.
* ```ts
* sha512(new Uint8Array([97, 98, 99]));
* ```
*/
var sha512 = /* @__PURE__ */ createHasher(() => new _SHA512(), /* @__PURE__ */ oidNist(3));
//#endregion
//#region node_modules/.pnpm/@primeui+license-manager@1.0.0/node_modules/@primeui/license-manager/dist/index.mjs
var t = Object.defineProperty;
var i = Object.getOwnPropertySymbols;
var n = Object.prototype.hasOwnProperty;
var a = Object.prototype.propertyIsEnumerable;
var o = (e, r, i) => r in e ? t(e, r, {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: i
}) : e[r] = i;
var u = (e, r, t) => new Promise((i, n) => {
	var a = (e) => {
		try {
			u(t.next(e));
		} catch (e) {
			n(e);
		}
	}, o = (e) => {
		try {
			u(t.throw(e));
		} catch (e) {
			n(e);
		}
	}, u = (e) => e.done ? i(e.value) : Promise.resolve(e.value).then(a, o);
	u((t = t.apply(e, r)).next());
});
function c(e) {
	const r = {};
	for (let e = 0; e < 64; e++) r["ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"[e]] = e;
	const t = e.replace(/=+$/, ""), i = Math.floor(6 * t.length / 8), n = new Uint8Array(i);
	let a = 0, o = 0, u = 0;
	for (let e = 0; e < t.length; e++) {
		const i = r[t[e]];
		if (void 0 === i) throw new Error("Invalid base64url character");
		a = a << 6 | i, o += 6, o >= 8 && (o -= 8, n[u++] = a >> o & 255);
	}
	return n;
}
var p = {
	primeui: "primeui",
	scheduler: "primeui-pro:scheduler",
	texteditor: "primeui-pro:text-editor",
	charts: "primeui-pro:charts",
	diagram: "primeui-pro:diagram",
	pdfviewer: "primeui-pro:pdf-viewer",
	taskboard: "primeui-pro:task-board",
	datagrid: "primeui-pro:datagrid",
	ganttchart: "primeui-pro:gantt-chart",
	filemanager: "primeui-pro:file-manager"
};
var f = {
	primeui: "PrimeUI",
	scheduler: "Scheduler",
	texteditor: "TextEditor",
	charts: "Charts",
	diagram: "Diagram",
	pdfviewer: "PDF Viewer",
	taskboard: "Task Board",
	datagrid: "DataGrid",
	ganttchart: "Gantt",
	filemanager: "File Manager"
};
function m(e, r = "PrimeUI") {
	switch (e) {
		case "active": return `${r} license is active.`;
		case "grace": return `${r} license is in its grace period. Renew soon to keep using this version.`;
		case "expired": return `${r} license does not cover this version. Renew at primeui.store, or downgrade to a version released within your updates window.`;
		case "tampered": return `${r} license signature is invalid.`;
		case "wrong-product": return `License does not cover ${r}.`;
		case "missing": return `No license key configured for ${r}.`;
		case "invalid": return `${r} license is malformed.`;
		case "unconfigured": return `${r} license is not configured.`;
		default: return `${r} license status unknown.`;
	}
}
var y = 864e5;
function g(e, r, t = {}) {
	return ((e, r) => {
		for (var t in r || (r = {})) n.call(r, t) && o(e, t, r[t]);
		if (i) for (var t of i(r)) a.call(r, t) && o(e, t, r[t]);
		return e;
	})({
		valid: "active" === e || "grace" === e,
		status: e,
		message: m(e, r)
	}, t);
}
function v(t, i) {
	return u(this, null, function* () {
		var n, a;
		const o = i.productLabel;
		if ("string" != typeof t || !t.includes(".")) return g("invalid", o);
		const u = t.split(".");
		if (2 !== u.length) return g("invalid", o);
		const [s, p] = u;
		let f, m, v;
		try {
			f = function(e) {
				const r = c(e), t = new TextDecoder().decode(r);
				return JSON.parse(t);
			}(s);
		} catch (e) {
			return g("invalid", o);
		}
		if (!f || "object" != typeof f || "string" != typeof f.product || "string" != typeof f.type || "number" != typeof f.exp || "number" != typeof f.iat || "string" != typeof f.id) return g("invalid", o);
		try {
			m = c(p), v = new TextEncoder().encode(s);
		} catch (e) {
			return g("invalid", o);
		}
		const h = null != (n = i.publicKeyOverride) ? n : "dae75e66b9f59bebf87d4bb29ca6494f37deccfcc2b132b98ee159ee7505373b";
		let b;
		try {
			b = function(e) {
				if (e.length % 2 != 0) throw new Error("Invalid hex length");
				const r = new Uint8Array(e.length / 2);
				for (let t = 0; t < r.length; t++) r[t] = parseInt(e.substr(2 * t, 2), 16);
				return r;
			}(h);
		} catch (e) {
			return g("invalid", o);
		}
		let w = !1;
		try {
			etc.sha512Sync || (etc.sha512Sync = (...t) => sha512(etc.concatBytes(...t))), w = verify(m, v, b);
		} catch (e) {
			return g("tampered", o, { payload: f });
		}
		if (!w) return g("tampered", o, { payload: f });
		if (!function(e, r) {
			return e.product === r || !(!r.startsWith("primeui-pro:") || e.product !== "primeui" || "commercial" !== e.tier);
		}(f, i.product)) return g("wrong-product", o, { payload: f });
		const x = 1e3 * f.exp, D = Date.now(), O = Math.floor((x - D) / y), P = function(e) {
			if (void 0 === e) return null;
			if ("number" == typeof e) return 1e3 * e;
			const r = Date.parse(e);
			return Number.isNaN(r) ? null : r;
		}(i.releaseDate);
		if (null !== P && P > x) return g("expired", o, {
			daysUntilExpiry: O,
			payload: f
		});
		if (function(e) {
			return "community" === e.tier;
		}(f)) {
			if (D > x + (null != (a = i.graceDays) ? a : 30) * y) return g("expired", o, {
				daysUntilExpiry: O,
				payload: f
			});
			if (D > x) return g("grace", o, {
				daysUntilExpiry: O,
				payload: f
			});
		}
		return g("active", o, {
			daysUntilExpiry: O,
			payload: f
		});
	});
}
function h$1(e, r) {
	return {
		valid: !1,
		status: e,
		message: m(e, r)
	};
}
function b(e, r) {
	const t = null == r ? void 0 : r.graceDays, i = null == r ? void 0 : r.publicKeyOverride;
	return {
		verify(r, n) {
			return u(this, null, function* () {
				var a;
				const o = p[r], u = null != (a = f[r]) ? a : "PrimeUI", c = null == n ? void 0 : n.releaseDate;
				if (!o) return h$1("invalid", u);
				const s = e[r], l = e.primeui;
				if (s) {
					const e = yield v(s, {
						product: o,
						productLabel: u,
						releaseDate: c,
						graceDays: t,
						publicKeyOverride: i
					});
					if (e.valid) return e;
					if ("wrong-product" !== e.status) return e;
				}
				return l && "primeui" !== r && o.startsWith("primeui-pro:") ? v(l, {
					product: o,
					productLabel: u,
					releaseDate: c,
					graceDays: t,
					publicKeyOverride: i
				}) : h$1(s ? "wrong-product" : "missing", u);
			});
		},
		has(r) {
			const t = p[r];
			return !!t && (!!e[r] || "primeui" !== r && t.startsWith("primeui-pro:") && !!e.primeui);
		}
	};
}
var w = null;
function x(e, r) {
	if (!e) throw new Error("[@primeui/license-manager] registerLicense: keys argument is required.");
	return w = b(e, r);
}
function O(e, r) {
	var t;
	if (!w) {
		const r = null != (t = f[e]) ? t : "PrimeUI";
		return Promise.resolve({
			valid: !1,
			status: "unconfigured",
			message: m("unconfigured", r)
		});
	}
	return w.verify(e, r);
}
//#endregion
//#region node_modules/.pnpm/@primevue+core@5.0.0_vue@3.5.40_typescript@6.0.3_/node_modules/@primevue/core/api/index.mjs
var FilterMatchMode = {
	STARTS_WITH: "startsWith",
	CONTAINS: "contains",
	NOT_CONTAINS: "notContains",
	ENDS_WITH: "endsWith",
	EQUALS: "equals",
	NOT_EQUALS: "notEquals",
	IN: "in",
	LESS_THAN: "lt",
	LESS_THAN_OR_EQUAL_TO: "lte",
	GREATER_THAN: "gt",
	GREATER_THAN_OR_EQUAL_TO: "gte",
	BETWEEN: "between",
	DATE_IS: "dateIs",
	DATE_IS_NOT: "dateIsNot",
	DATE_BEFORE: "dateBefore",
	DATE_AFTER: "dateAfter"
};
//#endregion
//#region node_modules/.pnpm/@primevue+core@5.0.0_vue@3.5.40_typescript@6.0.3_/node_modules/@primevue/core/config/index.mjs
function _typeof(o) {
	"@babel/helpers - typeof";
	return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof(o);
}
function ownKeys(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys(Object(t), true).forEach(function(r) {
			_defineProperty(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty(e, r, t) {
	return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey(t) {
	var i = _toPrimitive(t, "string");
	return "symbol" == _typeof(i) ? i : i + "";
}
function _toPrimitive(t, r) {
	if ("object" != _typeof(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var RELEASE_DATE = "2026-07-15";
var defaultOptions = {
	ripple: false,
	inputVariant: null,
	license: null,
	locale: {
		startsWith: "Starts with",
		contains: "Contains",
		notContains: "Not contains",
		endsWith: "Ends with",
		equals: "Equals",
		notEquals: "Not equals",
		noFilter: "No Filter",
		lt: "Less than",
		lte: "Less than or equal to",
		gt: "Greater than",
		gte: "Greater than or equal to",
		dateIs: "Date is",
		dateIsNot: "Date is not",
		dateBefore: "Date is before",
		dateAfter: "Date is after",
		clear: "Clear",
		apply: "Apply",
		matchAll: "Match All",
		matchAny: "Match Any",
		addRule: "Add Rule",
		removeRule: "Remove Rule",
		accept: "Yes",
		reject: "No",
		choose: "Choose",
		upload: "Upload",
		cancel: "Cancel",
		completed: "Completed",
		pending: "Pending",
		fileSizeTypes: [
			"B",
			"KB",
			"MB",
			"GB",
			"TB",
			"PB",
			"EB",
			"ZB",
			"YB"
		],
		dayNames: [
			"Sunday",
			"Monday",
			"Tuesday",
			"Wednesday",
			"Thursday",
			"Friday",
			"Saturday"
		],
		dayNamesShort: [
			"Sun",
			"Mon",
			"Tue",
			"Wed",
			"Thu",
			"Fri",
			"Sat"
		],
		dayNamesMin: [
			"Su",
			"Mo",
			"Tu",
			"We",
			"Th",
			"Fr",
			"Sa"
		],
		monthNames: [
			"January",
			"February",
			"March",
			"April",
			"May",
			"June",
			"July",
			"August",
			"September",
			"October",
			"November",
			"December"
		],
		monthNamesShort: [
			"Jan",
			"Feb",
			"Mar",
			"Apr",
			"May",
			"Jun",
			"Jul",
			"Aug",
			"Sep",
			"Oct",
			"Nov",
			"Dec"
		],
		chooseYear: "Choose Year",
		chooseMonth: "Choose Month",
		chooseDate: "Choose Date",
		prevDecade: "Previous Decade",
		nextDecade: "Next Decade",
		prevYear: "Previous Year",
		nextYear: "Next Year",
		prevMonth: "Previous Month",
		nextMonth: "Next Month",
		prevHour: "Previous Hour",
		nextHour: "Next Hour",
		prevMinute: "Previous Minute",
		nextMinute: "Next Minute",
		prevSecond: "Previous Second",
		nextSecond: "Next Second",
		am: "am",
		pm: "pm",
		today: "Today",
		weekHeader: "Wk",
		firstDayOfWeek: 0,
		showMonthAfterYear: false,
		dateFormat: "mm/dd/yy",
		weak: "Weak",
		medium: "Medium",
		strong: "Strong",
		passwordPrompt: "Enter a password",
		emptyFilterMessage: "No results found",
		searchMessage: "{0} results are available",
		selectionMessage: "{0} items selected",
		emptySelectionMessage: "No selected item",
		emptySearchMessage: "No results found",
		fileChosenMessage: "{0} files",
		noFileChosenMessage: "No file chosen",
		emptyMessage: "No available options",
		aria: {
			trueLabel: "True",
			falseLabel: "False",
			nullLabel: "Not Selected",
			star: "1 star",
			stars: "{star} stars",
			selectAll: "All items selected",
			unselectAll: "All items unselected",
			close: "Close",
			previous: "Previous",
			next: "Next",
			navigation: "Navigation",
			scrollTop: "Scroll Top",
			moveTop: "Move Top",
			moveUp: "Move Up",
			moveDown: "Move Down",
			moveBottom: "Move Bottom",
			moveToTarget: "Move to Target",
			moveToSource: "Move to Source",
			moveAllToTarget: "Move All to Target",
			moveAllToSource: "Move All to Source",
			pageLabel: "Page {page}",
			firstPageLabel: "First Page",
			lastPageLabel: "Last Page",
			nextPageLabel: "Next Page",
			prevPageLabel: "Previous Page",
			rowsPerPageLabel: "Rows per page",
			jumpToPageDropdownLabel: "Jump to Page Dropdown",
			jumpToPageInputLabel: "Jump to Page Input",
			selectRow: "Row Selected",
			unselectRow: "Row Unselected",
			expandRow: "Row Expanded",
			collapseRow: "Row Collapsed",
			showFilterMenu: "Show Filter Menu",
			hideFilterMenu: "Hide Filter Menu",
			filterOperator: "Filter Operator",
			filterConstraint: "Filter Constraint",
			editRow: "Row Edit",
			saveEdit: "Save Edit",
			cancelEdit: "Cancel Edit",
			listView: "List View",
			gridView: "Grid View",
			slide: "Slide",
			slideNumber: "{slideNumber}",
			zoomImage: "Zoom Image",
			zoomIn: "Zoom In",
			zoomOut: "Zoom Out",
			rotateRight: "Rotate Right",
			rotateLeft: "Rotate Left",
			listLabel: "Option List"
		}
	},
	filterMatchModeOptions: {
		text: [
			FilterMatchMode.STARTS_WITH,
			FilterMatchMode.CONTAINS,
			FilterMatchMode.NOT_CONTAINS,
			FilterMatchMode.ENDS_WITH,
			FilterMatchMode.EQUALS,
			FilterMatchMode.NOT_EQUALS
		],
		numeric: [
			FilterMatchMode.EQUALS,
			FilterMatchMode.NOT_EQUALS,
			FilterMatchMode.LESS_THAN,
			FilterMatchMode.LESS_THAN_OR_EQUAL_TO,
			FilterMatchMode.GREATER_THAN,
			FilterMatchMode.GREATER_THAN_OR_EQUAL_TO
		],
		date: [
			FilterMatchMode.DATE_IS,
			FilterMatchMode.DATE_IS_NOT,
			FilterMatchMode.DATE_BEFORE,
			FilterMatchMode.DATE_AFTER
		]
	},
	zIndex: {
		modal: 1100,
		overlay: 1e3,
		menu: 1e3,
		tooltip: 1100
	},
	theme: void 0,
	unstyled: false,
	pt: void 0,
	ptOptions: {
		mergeSections: true,
		mergeProps: false
	},
	csp: { nonce: void 0 }
};
var PrimeVueSymbol = Symbol();
function usePrimeVue() {
	var PrimeVue = inject(PrimeVueSymbol);
	if (!PrimeVue) throw new Error("PrimeVue is not installed!");
	return PrimeVue;
}
function setup(app, options) {
	var _verified = ref(null);
	if (options.license) x({ primeui: options.license });
	O("primeui", { releaseDate: RELEASE_DATE }).then(function(result) {
		_verified.value = result.valid;
		if (!result.valid) {
			console.warn("[PrimeUI] ".concat(result.message));
			showInvalidLicenseBanner();
		}
	});
	var PrimeVue = {
		config: reactive(options),
		verified: readonly(_verified)
	};
	app.config.globalProperties.$primevue = PrimeVue;
	app.provide(PrimeVueSymbol, PrimeVue);
	clearConfig();
	setupConfig(app, PrimeVue);
	return PrimeVue;
}
var stopWatchers = [];
function clearConfig() {
	R.clear();
	stopWatchers.forEach(function(fn) {
		return fn === null || fn === void 0 ? void 0 : fn();
	});
	stopWatchers = [];
}
function setupConfig(app, PrimeVue) {
	var isThemeChanged = ref(false);
	/*** Methods and Services ***/
	var loadCommonTheme = function loadCommonTheme() {
		var _PrimeVue$config;
		if (((_PrimeVue$config = PrimeVue.config) === null || _PrimeVue$config === void 0 ? void 0 : _PrimeVue$config.theme) === "none") return;
		if (!S.isStyleNameLoaded("common")) {
			var _BaseStyle$getCommonT, _PrimeVue$config2;
			var _ref = ((_BaseStyle$getCommonT = BaseStyle.getCommonTheme) === null || _BaseStyle$getCommonT === void 0 ? void 0 : _BaseStyle$getCommonT.call(BaseStyle)) || {}, primitive = _ref.primitive, semantic = _ref.semantic, global = _ref.global, style = _ref.style;
			var styleOptions = { nonce: (_PrimeVue$config2 = PrimeVue.config) === null || _PrimeVue$config2 === void 0 || (_PrimeVue$config2 = _PrimeVue$config2.csp) === null || _PrimeVue$config2 === void 0 ? void 0 : _PrimeVue$config2.nonce };
			BaseStyle.load(primitive === null || primitive === void 0 ? void 0 : primitive.css, _objectSpread({ name: "primitive-variables" }, styleOptions));
			BaseStyle.load(semantic === null || semantic === void 0 ? void 0 : semantic.css, _objectSpread({ name: "semantic-variables" }, styleOptions));
			BaseStyle.load(global === null || global === void 0 ? void 0 : global.css, _objectSpread({ name: "global-variables" }, styleOptions));
			BaseStyle.loadStyle(_objectSpread({ name: "global-style" }, styleOptions), style);
			S.setLoadedStyleName("common");
		}
	};
	R.on("theme:change", function(newTheme) {
		if (!isThemeChanged.value) {
			app.config.globalProperties.$primevue.config.theme = newTheme;
			isThemeChanged.value = true;
		}
	});
	/*** Watchers ***/
	var stopConfigWatcher = watch(PrimeVue.config, function(newValue, oldValue) {
		PrimeVueService.emit("config:change", {
			newValue,
			oldValue
		});
	}, {
		immediate: true,
		deep: true
	});
	var stopRippleWatcher = watch(function() {
		return PrimeVue.config.ripple;
	}, function(newValue, oldValue) {
		PrimeVueService.emit("config:ripple:change", {
			newValue,
			oldValue
		});
	}, {
		immediate: true,
		deep: true
	});
	var stopThemeWatcher = watch(function() {
		return PrimeVue.config.theme;
	}, function(newValue, oldValue) {
		if (!isThemeChanged.value) S.setTheme(newValue);
		if (!PrimeVue.config.unstyled) loadCommonTheme();
		isThemeChanged.value = false;
		PrimeVueService.emit("config:theme:change", {
			newValue,
			oldValue
		});
	}, {
		immediate: true,
		deep: false
	});
	var stopUnstyledWatcher = watch(function() {
		return PrimeVue.config.unstyled;
	}, function(newValue, oldValue) {
		if (!newValue && PrimeVue.config.theme) loadCommonTheme();
		PrimeVueService.emit("config:unstyled:change", {
			newValue,
			oldValue
		});
	}, {
		immediate: true,
		deep: true
	});
	stopWatchers.push(stopConfigWatcher);
	stopWatchers.push(stopRippleWatcher);
	stopWatchers.push(stopThemeWatcher);
	stopWatchers.push(stopUnstyledWatcher);
}
var PrimeVue = { install: function install(app, options) {
	setup(app, Q(defaultOptions, options));
} };
//#endregion
export { clearConfig, PrimeVue as default, defaultOptions, setup, setupConfig, usePrimeVue };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJpbWV2dWVfY29uZmlnLmpzIiwibmFtZXMiOlsiaCIsImlzQnl0ZXMiLCJhYnl0ZXMiLCJ1NjQuc3BsaXQiLCJ1NjQucm90clNIIiwidTY0LnNoclNIIiwidTY0LnJvdHJTTCIsInU2NC5zaHJTTCIsInU2NC5yb3RyQkgiLCJ1NjQucm90ckJMIiwidTY0LmFkZDRMIiwidTY0LmFkZDRIIiwidTY0LmFkZDVMIiwidTY0LmFkZDVIIiwidTY0LmFkZCIsInU2NC5hZGQzTCIsInU2NC5hZGQzSCIsInIiLCJlLnZlcmlmeSIsImgiLCJUaGVtZSIsIm1lcmdlS2V5cyJdLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy5wbnBtL0Bub2JsZStlZDI1NTE5QDIuMy4wL25vZGVfbW9kdWxlcy9Abm9ibGUvZWQyNTUxOS9pbmRleC5qcyIsIi4uLy4uLy4uLy4uLy5wbnBtL0Bub2JsZStoYXNoZXNAMi4yLjAvbm9kZV9tb2R1bGVzL0Bub2JsZS9oYXNoZXMvdXRpbHMuanMiLCIuLi8uLi8uLi8uLi8ucG5wbS9Abm9ibGUraGFzaGVzQDIuMi4wL25vZGVfbW9kdWxlcy9Abm9ibGUvaGFzaGVzL19tZC5qcyIsIi4uLy4uLy4uLy4uLy5wbnBtL0Bub2JsZStoYXNoZXNAMi4yLjAvbm9kZV9tb2R1bGVzL0Bub2JsZS9oYXNoZXMvX3U2NC5qcyIsIi4uLy4uLy4uLy4uLy5wbnBtL0Bub2JsZStoYXNoZXNAMi4yLjAvbm9kZV9tb2R1bGVzL0Bub2JsZS9oYXNoZXMvc2hhMi5qcyIsIi4uLy4uLy4uLy4uLy5wbnBtL0BwcmltZXVpK2xpY2Vuc2UtbWFuYWdlckAxLjAuMC9ub2RlX21vZHVsZXMvQHByaW1ldWkvbGljZW5zZS1tYW5hZ2VyL2Rpc3QvaW5kZXgubWpzIiwiLi4vLi4vLi4vLi4vLnBucG0vQHByaW1ldnVlK2NvcmVANS4wLjBfdnVlQDMuNS40MF90eXBlc2NyaXB0QDYuMC4zXy9ub2RlX21vZHVsZXMvQHByaW1ldnVlL2NvcmUvYXBpL2luZGV4Lm1qcyIsIi4uLy4uLy4uLy4uLy5wbnBtL0BwcmltZXZ1ZStjb3JlQDUuMC4wX3Z1ZUAzLjUuNDBfdHlwZXNjcmlwdEA2LjAuM18vbm9kZV9tb2R1bGVzL0BwcmltZXZ1ZS9jb3JlL2NvbmZpZy9pbmRleC5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiLyohIG5vYmxlLWVkMjU1MTkgLSBNSVQgTGljZW5zZSAoYykgMjAxOSBQYXVsIE1pbGxlciAocGF1bG1pbGxyLmNvbSkgKi9cbi8qKlxuICogNEtCIEpTIGltcGxlbWVudGF0aW9uIG9mIGVkMjU1MTkgRWREU0Egc2lnbmF0dXJlcy5cbiAqIENvbXBsaWFudCB3aXRoIFJGQzgwMzIsIEZJUFMgMTg2LTUgJiBaSVAyMTUuXG4gKiBAbW9kdWxlXG4gKiBAZXhhbXBsZVxuICogYGBganNcbmltcG9ydCAqIGFzIGVkIGZyb20gJ0Bub2JsZS9lZDI1NTE5Jztcbihhc3luYyAoKSA9PiB7XG4gIGNvbnN0IHByaXZLZXkgPSBlZC51dGlscy5yYW5kb21Qcml2YXRlS2V5KCk7XG4gIGNvbnN0IG1lc3NhZ2UgPSBVaW50OEFycmF5LmZyb20oWzB4YWIsIDB4YmMsIDB4Y2QsIDB4ZGVdKTtcbiAgY29uc3QgcHViS2V5ID0gYXdhaXQgZWQuZ2V0UHVibGljS2V5QXN5bmMocHJpdktleSk7IC8vIFN5bmMgbWV0aG9kcyBhcmUgYWxzbyBwcmVzZW50XG4gIGNvbnN0IHNpZ25hdHVyZSA9IGF3YWl0IGVkLnNpZ25Bc3luYyhtZXNzYWdlLCBwcml2S2V5KTtcbiAgY29uc3QgaXNWYWxpZCA9IGF3YWl0IGVkLnZlcmlmeUFzeW5jKHNpZ25hdHVyZSwgbWVzc2FnZSwgcHViS2V5KTtcbn0pKCk7XG5gYGBcbiAqL1xuLyoqXG4gKiBDdXJ2ZSBwYXJhbXMuIGVkMjU1MTkgaXMgdHdpc3RlZCBlZHdhcmRzIGN1cnZlLiBFcXVhdGlvbiBpcyDiiJJ4wrIgKyB5wrIgPSAtYSArIGR4wrJ5wrIuXG4gKiAqIFAgPSBgMm4qKjI1NW4gLSAxOW5gIC8vIGZpZWxkIG92ZXIgd2hpY2ggY2FsY3VsYXRpb25zIGFyZSBkb25lXG4gKiAqIE4gPSBgMm4qKjI1Mm4gKyAyNzc0MjMxNzc3NzM3MjM1MzUzNTg1MTkzNzc5MDg4MzY0ODQ5M25gIC8vIGdyb3VwIG9yZGVyLCBhbW91bnQgb2YgY3VydmUgcG9pbnRzXG4gKiAqIGggPSA4IC8vIGNvZmFjdG9yXG4gKiAqIGEgPSBgRnAuY3JlYXRlKEJpZ0ludCgtMSkpYCAvLyBlcXVhdGlvbiBwYXJhbVxuICogKiBkID0gLTEyMTY2NS8xMjE2NjYgYS5rLmEuIGBGcC5uZWcoMTIxNjY1ICogRnAuaW52KDEyMTY2NikpYCAvLyBlcXVhdGlvbiBwYXJhbVxuICogKiBHeCwgR3kgYXJlIGNvb3JkaW5hdGVzIG9mIEdlbmVyYXRvciAvIGJhc2UgcG9pbnRcbiAqL1xuY29uc3QgZWQyNTUxOV9DVVJWRSA9IHtcbiAgICBwOiAweDdmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZWRuLFxuICAgIG46IDB4MTAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAxNGRlZjlkZWEyZjc5Y2Q2NTgxMjYzMWE1Y2Y1ZDNlZG4sXG4gICAgaDogOG4sXG4gICAgYTogMHg3ZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmZmVjbixcbiAgICBkOiAweDUyMDM2Y2VlMmI2ZmZlNzM4Y2M3NDA3OTc3NzllODk4MDA3MDBhNGQ0MTQxZDhhYjc1ZWI0ZGNhMTM1OTc4YTNuLFxuICAgIEd4OiAweDIxNjkzNmQzY2Q2ZTUzZmVjMGE0ZTIzMWZkZDZkYzVjNjkyY2M3NjA5NTI1YTdiMmM5NTYyZDYwOGYyNWQ1MWFuLFxuICAgIEd5OiAweDY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NThuLFxufTtcbmNvbnN0IHsgcDogUCwgbjogTiwgR3gsIEd5LCBhOiBfYSwgZDogX2QgfSA9IGVkMjU1MTlfQ1VSVkU7XG5jb25zdCBoID0gOG47IC8vIGNvZmFjdG9yXG5jb25zdCBMID0gMzI7IC8vIGZpZWxkIC8gZ3JvdXAgYnl0ZSBsZW5ndGhcbmNvbnN0IEwyID0gNjQ7XG4vLyBIZWxwZXJzIGFuZCBQcmVjb21wdXRlcyBzZWN0aW9ucyBhcmUgcmV1c2VkIGJldHdlZW4gbGlicmFyaWVzXG4vLyAjIyBIZWxwZXJzXG4vLyAtLS0tLS0tLS0tXG4vLyBlcnJvciBoZWxwZXIsIG1lc3Nlcy11cCBzdGFjayB0cmFjZVxuY29uc3QgZXJyID0gKG0gPSAnJykgPT4ge1xuICAgIHRocm93IG5ldyBFcnJvcihtKTtcbn07XG5jb25zdCBpc0JpZyA9IChuKSA9PiB0eXBlb2YgbiA9PT0gJ2JpZ2ludCc7IC8vIGlzIGJpZyBpbnRlZ2VyXG5jb25zdCBpc1N0ciA9IChzKSA9PiB0eXBlb2YgcyA9PT0gJ3N0cmluZyc7IC8vIGlzIHN0cmluZ1xuY29uc3QgaXNCeXRlcyA9IChhKSA9PiBhIGluc3RhbmNlb2YgVWludDhBcnJheSB8fCAoQXJyYXlCdWZmZXIuaXNWaWV3KGEpICYmIGEuY29uc3RydWN0b3IubmFtZSA9PT0gJ1VpbnQ4QXJyYXknKTtcbi8qKiBhc3NlcnQgaXMgVWludDhBcnJheSAob2Ygc3BlY2lmaWMgbGVuZ3RoKSAqL1xuY29uc3QgYWJ5dGVzID0gKGEsIGwpID0+ICFpc0J5dGVzKGEpIHx8ICh0eXBlb2YgbCA9PT0gJ251bWJlcicgJiYgbCA+IDAgJiYgYS5sZW5ndGggIT09IGwpXG4gICAgPyBlcnIoJ1VpbnQ4QXJyYXkgZXhwZWN0ZWQnKVxuICAgIDogYTtcbi8qKiBjcmVhdGUgVWludDhBcnJheSAqL1xuY29uc3QgdThuID0gKGxlbikgPT4gbmV3IFVpbnQ4QXJyYXkobGVuKTtcbmNvbnN0IHU4ZnIgPSAoYnVmKSA9PiBVaW50OEFycmF5LmZyb20oYnVmKTtcbmNvbnN0IHBhZGggPSAobiwgcGFkKSA9PiBuLnRvU3RyaW5nKDE2KS5wYWRTdGFydChwYWQsICcwJyk7XG5jb25zdCBieXRlc1RvSGV4ID0gKGIpID0+IEFycmF5LmZyb20oYWJ5dGVzKGIpKVxuICAgIC5tYXAoKGUpID0+IHBhZGgoZSwgMikpXG4gICAgLmpvaW4oJycpO1xuY29uc3QgQyA9IHsgXzA6IDQ4LCBfOTogNTcsIEE6IDY1LCBGOiA3MCwgYTogOTcsIGY6IDEwMiB9OyAvLyBBU0NJSSBjaGFyYWN0ZXJzXG5jb25zdCBfY2ggPSAoY2gpID0+IHtcbiAgICBpZiAoY2ggPj0gQy5fMCAmJiBjaCA8PSBDLl85KVxuICAgICAgICByZXR1cm4gY2ggLSBDLl8wOyAvLyAnMicgPT4gNTAtNDhcbiAgICBpZiAoY2ggPj0gQy5BICYmIGNoIDw9IEMuRilcbiAgICAgICAgcmV0dXJuIGNoIC0gKEMuQSAtIDEwKTsgLy8gJ0InID0+IDY2LSg2NS0xMClcbiAgICBpZiAoY2ggPj0gQy5hICYmIGNoIDw9IEMuZilcbiAgICAgICAgcmV0dXJuIGNoIC0gKEMuYSAtIDEwKTsgLy8gJ2InID0+IDk4LSg5Ny0xMClcbiAgICByZXR1cm47XG59O1xuY29uc3QgaGV4VG9CeXRlcyA9IChoZXgpID0+IHtcbiAgICBjb25zdCBlID0gJ2hleCBpbnZhbGlkJztcbiAgICBpZiAoIWlzU3RyKGhleCkpXG4gICAgICAgIHJldHVybiBlcnIoZSk7XG4gICAgY29uc3QgaGwgPSBoZXgubGVuZ3RoO1xuICAgIGNvbnN0IGFsID0gaGwgLyAyO1xuICAgIGlmIChobCAlIDIpXG4gICAgICAgIHJldHVybiBlcnIoZSk7XG4gICAgY29uc3QgYXJyYXkgPSB1OG4oYWwpO1xuICAgIGZvciAobGV0IGFpID0gMCwgaGkgPSAwOyBhaSA8IGFsOyBhaSsrLCBoaSArPSAyKSB7XG4gICAgICAgIC8vIHRyZWF0IGVhY2ggY2hhciBhcyBBU0NJSVxuICAgICAgICBjb25zdCBuMSA9IF9jaChoZXguY2hhckNvZGVBdChoaSkpOyAvLyBwYXJzZSBmaXJzdCBjaGFyLCBtdWx0aXBseSBpdCBieSAxNlxuICAgICAgICBjb25zdCBuMiA9IF9jaChoZXguY2hhckNvZGVBdChoaSArIDEpKTsgLy8gcGFyc2Ugc2Vjb25kIGNoYXJcbiAgICAgICAgaWYgKG4xID09PSB1bmRlZmluZWQgfHwgbjIgPT09IHVuZGVmaW5lZClcbiAgICAgICAgICAgIHJldHVybiBlcnIoZSk7XG4gICAgICAgIGFycmF5W2FpXSA9IG4xICogMTYgKyBuMjsgLy8gZXhhbXBsZTogJ0E5JyA9PiAxMCoxNiArIDlcbiAgICB9XG4gICAgcmV0dXJuIGFycmF5O1xufTtcbi8qKiBub3JtYWxpemUgaGV4IG9yIHVpOGEgdG8gdWk4YSAqL1xuY29uc3QgdG9VOCA9IChhLCBsZW4pID0+IGFieXRlcyhpc1N0cihhKSA/IGhleFRvQnl0ZXMoYSkgOiB1OGZyKGFieXRlcyhhKSksIGxlbik7XG5jb25zdCBjciA9ICgpID0+IGdsb2JhbFRoaXM/LmNyeXB0bzsgLy8gV2ViQ3J5cHRvIGlzIGF2YWlsYWJsZSBpbiBhbGwgbW9kZXJuIGVudmlyb25tZW50c1xuY29uc3Qgc3VidGxlID0gKCkgPT4gY3IoKT8uc3VidGxlID8/IGVycignY3J5cHRvLnN1YnRsZSBtdXN0IGJlIGRlZmluZWQnKTtcbi8vIHByZXR0aWVyLWlnbm9yZVxuY29uc3QgY29uY2F0Qnl0ZXMgPSAoLi4uYXJycykgPT4ge1xuICAgIGNvbnN0IHIgPSB1OG4oYXJycy5yZWR1Y2UoKHN1bSwgYSkgPT4gc3VtICsgYWJ5dGVzKGEpLmxlbmd0aCwgMCkpOyAvLyBjcmVhdGUgdThhIG9mIHN1bW1lZCBsZW5ndGhcbiAgICBsZXQgcGFkID0gMDsgLy8gd2FsayB0aHJvdWdoIGVhY2ggYXJyYXksXG4gICAgYXJycy5mb3JFYWNoKGEgPT4geyByLnNldChhLCBwYWQpOyBwYWQgKz0gYS5sZW5ndGg7IH0pOyAvLyBlbnN1cmUgdGhleSBoYXZlIHByb3BlciB0eXBlXG4gICAgcmV0dXJuIHI7XG59O1xuLyoqIFdlYkNyeXB0byBPUy1sZXZlbCBDU1BSTkcgKHJhbmRvbSBudW1iZXIgZ2VuZXJhdG9yKS4gV2lsbCB0aHJvdyB3aGVuIG5vdCBhdmFpbGFibGUuICovXG5jb25zdCByYW5kb21CeXRlcyA9IChsZW4gPSBMKSA9PiB7XG4gICAgY29uc3QgYyA9IGNyKCk7XG4gICAgcmV0dXJuIGMuZ2V0UmFuZG9tVmFsdWVzKHU4bihsZW4pKTtcbn07XG5jb25zdCBiaWcgPSBCaWdJbnQ7XG5jb25zdCBhcmFuZ2UgPSAobiwgbWluLCBtYXgsIG1zZyA9ICdiYWQgbnVtYmVyOiBvdXQgb2YgcmFuZ2UnKSA9PiBpc0JpZyhuKSAmJiBtaW4gPD0gbiAmJiBuIDwgbWF4ID8gbiA6IGVycihtc2cpO1xuLyoqIG1vZHVsYXIgZGl2aXNpb24gKi9cbmNvbnN0IE0gPSAoYSwgYiA9IFApID0+IHtcbiAgICBjb25zdCByID0gYSAlIGI7XG4gICAgcmV0dXJuIHIgPj0gMG4gPyByIDogYiArIHI7XG59O1xuY29uc3QgbW9kTiA9IChhKSA9PiBNKGEsIE4pO1xuLyoqIE1vZHVsYXIgaW52ZXJzaW9uIHVzaW5nIGV1Y2xlZGlhbiBHQ0QgKG5vbi1DVCkuIE5vIG5lZ2F0aXZlIGV4cG9uZW50IGZvciBub3cuICovXG4vLyBwcmV0dGllci1pZ25vcmVcbmNvbnN0IGludmVydCA9IChudW0sIG1kKSA9PiB7XG4gICAgaWYgKG51bSA9PT0gMG4gfHwgbWQgPD0gMG4pXG4gICAgICAgIGVycignbm8gaW52ZXJzZSBuPScgKyBudW0gKyAnIG1vZD0nICsgbWQpO1xuICAgIGxldCBhID0gTShudW0sIG1kKSwgYiA9IG1kLCB4ID0gMG4sIHkgPSAxbiwgdSA9IDFuLCB2ID0gMG47XG4gICAgd2hpbGUgKGEgIT09IDBuKSB7XG4gICAgICAgIGNvbnN0IHEgPSBiIC8gYSwgciA9IGIgJSBhO1xuICAgICAgICBjb25zdCBtID0geCAtIHUgKiBxLCBuID0geSAtIHYgKiBxO1xuICAgICAgICBiID0gYSwgYSA9IHIsIHggPSB1LCB5ID0gdiwgdSA9IG0sIHYgPSBuO1xuICAgIH1cbiAgICByZXR1cm4gYiA9PT0gMW4gPyBNKHgsIG1kKSA6IGVycignbm8gaW52ZXJzZScpOyAvLyBiIGlzIGdjZCBhdCB0aGlzIHBvaW50XG59O1xuY29uc3QgY2FsbEhhc2ggPSAobmFtZSkgPT4ge1xuICAgIC8vIEB0cy1pZ25vcmVcbiAgICBjb25zdCBmbiA9IGV0Y1tuYW1lXTtcbiAgICBpZiAodHlwZW9mIGZuICE9PSAnZnVuY3Rpb24nKVxuICAgICAgICBlcnIoJ2hhc2hlcy4nICsgbmFtZSArICcgbm90IHNldCcpO1xuICAgIHJldHVybiBmbjtcbn07XG5jb25zdCBhcG9pbnQgPSAocCkgPT4gKHAgaW5zdGFuY2VvZiBQb2ludCA/IHAgOiBlcnIoJ1BvaW50IGV4cGVjdGVkJykpO1xuLy8gIyMgRW5kIG9mIEhlbHBlcnNcbi8vIC0tLS0tLS0tLS0tLS0tLS0tXG5jb25zdCBCMjU2ID0gMm4gKiogMjU2bjtcbi8qKiBQb2ludCBpbiBYWVpUIGV4dGVuZGVkIGNvb3JkaW5hdGVzLiAqL1xuY2xhc3MgUG9pbnQge1xuICAgIHN0YXRpYyBCQVNFO1xuICAgIHN0YXRpYyBaRVJPO1xuICAgIGV4O1xuICAgIGV5O1xuICAgIGV6O1xuICAgIGV0O1xuICAgIGNvbnN0cnVjdG9yKGV4LCBleSwgZXosIGV0KSB7XG4gICAgICAgIGNvbnN0IG1heCA9IEIyNTY7XG4gICAgICAgIHRoaXMuZXggPSBhcmFuZ2UoZXgsIDBuLCBtYXgpO1xuICAgICAgICB0aGlzLmV5ID0gYXJhbmdlKGV5LCAwbiwgbWF4KTtcbiAgICAgICAgdGhpcy5leiA9IGFyYW5nZShleiwgMW4sIG1heCk7XG4gICAgICAgIHRoaXMuZXQgPSBhcmFuZ2UoZXQsIDBuLCBtYXgpO1xuICAgICAgICBPYmplY3QuZnJlZXplKHRoaXMpO1xuICAgIH1cbiAgICBzdGF0aWMgZnJvbUFmZmluZShwKSB7XG4gICAgICAgIHJldHVybiBuZXcgUG9pbnQocC54LCBwLnksIDFuLCBNKHAueCAqIHAueSkpO1xuICAgIH1cbiAgICAvKiogUkZDODAzMiA1LjEuMzogVWludDhBcnJheSB0byBQb2ludC4gKi9cbiAgICBzdGF0aWMgZnJvbUJ5dGVzKGhleCwgemlwMjE1ID0gZmFsc2UpIHtcbiAgICAgICAgY29uc3QgZCA9IF9kO1xuICAgICAgICAvLyBDb3B5IGFycmF5IHRvIG5vdCBtZXNzIGl0IHVwLlxuICAgICAgICBjb25zdCBub3JtZWQgPSB1OGZyKGFieXRlcyhoZXgsIEwpKTtcbiAgICAgICAgLy8gYWRqdXN0IGZpcnN0IExFIGJ5dGUgPSBsYXN0IEJFIGJ5dGVcbiAgICAgICAgY29uc3QgbGFzdEJ5dGUgPSBoZXhbMzFdO1xuICAgICAgICBub3JtZWRbMzFdID0gbGFzdEJ5dGUgJiB+MHg4MDtcbiAgICAgICAgY29uc3QgeSA9IGJ5dGVzVG9OdW1MRShub3JtZWQpO1xuICAgICAgICAvLyB6aXAyMTU9dHJ1ZTogICAgICAgICAgIDAgPD0geSA8IDJeMjU2XG4gICAgICAgIC8vIHppcDIxNT1mYWxzZSwgUkZDODAzMjogMCA8PSB5IDwgMl4yNTUtMTlcbiAgICAgICAgY29uc3QgbWF4ID0gemlwMjE1ID8gQjI1NiA6IFA7XG4gICAgICAgIGFyYW5nZSh5LCAwbiwgbWF4KTtcbiAgICAgICAgY29uc3QgeTIgPSBNKHkgKiB5KTsgLy8gecKyXG4gICAgICAgIGNvbnN0IHUgPSBNKHkyIC0gMW4pOyAvLyB1PXnCsi0xXG4gICAgICAgIGNvbnN0IHYgPSBNKGQgKiB5MiArIDFuKTsgLy8gdj1kecKyKzFcbiAgICAgICAgbGV0IHsgaXNWYWxpZCwgdmFsdWU6IHggfSA9IHV2UmF0aW8odSwgdik7IC8vICh1dsKzKSh1duKBtyleKHAtNSkvODsgc3F1YXJlIHJvb3RcbiAgICAgICAgaWYgKCFpc1ZhbGlkKVxuICAgICAgICAgICAgZXJyKCdiYWQgcG9pbnQ6IHkgbm90IHNxcnQnKTsgLy8gbm90IHNxdWFyZSByb290OiBiYWQgcG9pbnRcbiAgICAgICAgY29uc3QgaXNYT2RkID0gKHggJiAxbikgPT09IDFuOyAvLyBhZGp1c3Qgc2lnbiBvZiB4IGNvb3JkaW5hdGVcbiAgICAgICAgY29uc3QgaXNMYXN0Qnl0ZU9kZCA9IChsYXN0Qnl0ZSAmIDB4ODApICE9PSAwOyAvLyB4XzAsIGxhc3QgYml0XG4gICAgICAgIGlmICghemlwMjE1ICYmIHggPT09IDBuICYmIGlzTGFzdEJ5dGVPZGQpXG4gICAgICAgICAgICBlcnIoJ2JhZCBwb2ludDogeD09MCwgaXNMYXN0Qnl0ZU9kZCcpOyAvLyB4PTAsIHhfMD0xXG4gICAgICAgIGlmIChpc0xhc3RCeXRlT2RkICE9PSBpc1hPZGQpXG4gICAgICAgICAgICB4ID0gTSgteCk7XG4gICAgICAgIHJldHVybiBuZXcgUG9pbnQoeCwgeSwgMW4sIE0oeCAqIHkpKTsgLy8gWj0xLCBUPXh5XG4gICAgfVxuICAgIC8qKiBDaGVja3MgaWYgdGhlIHBvaW50IGlzIHZhbGlkIGFuZCBvbi1jdXJ2ZS4gKi9cbiAgICBhc3NlcnRWYWxpZGl0eSgpIHtcbiAgICAgICAgY29uc3QgYSA9IF9hO1xuICAgICAgICBjb25zdCBkID0gX2Q7XG4gICAgICAgIGNvbnN0IHAgPSB0aGlzO1xuICAgICAgICBpZiAocC5pczAoKSlcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignYmFkIHBvaW50OiBaRVJPJyk7IC8vIFRPRE86IG9wdGltaXplLCB3aXRoIHZhcnMgYmVsb3c/XG4gICAgICAgIC8vIEVxdWF0aW9uIGluIGFmZmluZSBjb29yZGluYXRlczogYXjCsiArIHnCsiA9IDEgKyBkeMKyecKyXG4gICAgICAgIC8vIEVxdWF0aW9uIGluIHByb2plY3RpdmUgY29vcmRpbmF0ZXMgKFgvWiwgWS9aLCBaKTogIChhWMKyICsgWcKyKVrCsiA9IFrigbQgKyBkWMKyWcKyXG4gICAgICAgIGNvbnN0IHsgZXg6IFgsIGV5OiBZLCBlejogWiwgZXQ6IFQgfSA9IHA7XG4gICAgICAgIGNvbnN0IFgyID0gTShYICogWCk7IC8vIFjCslxuICAgICAgICBjb25zdCBZMiA9IE0oWSAqIFkpOyAvLyBZwrJcbiAgICAgICAgY29uc3QgWjIgPSBNKFogKiBaKTsgLy8gWsKyXG4gICAgICAgIGNvbnN0IFo0ID0gTShaMiAqIFoyKTsgLy8gWuKBtFxuICAgICAgICBjb25zdCBhWDIgPSBNKFgyICogYSk7IC8vIGFYwrJcbiAgICAgICAgY29uc3QgbGVmdCA9IE0oWjIgKiBNKGFYMiArIFkyKSk7IC8vIChhWMKyICsgWcKyKVrCslxuICAgICAgICBjb25zdCByaWdodCA9IE0oWjQgKyBNKGQgKiBNKFgyICogWTIpKSk7IC8vIFrigbQgKyBkWMKyWcKyXG4gICAgICAgIGlmIChsZWZ0ICE9PSByaWdodClcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignYmFkIHBvaW50OiBlcXVhdGlvbiBsZWZ0ICE9IHJpZ2h0ICgxKScpO1xuICAgICAgICAvLyBJbiBFeHRlbmRlZCBjb29yZGluYXRlcyB3ZSBhbHNvIGhhdmUgVCwgd2hpY2ggaXMgeCp5PVQvWjogY2hlY2sgWCpZID09IFoqVFxuICAgICAgICBjb25zdCBYWSA9IE0oWCAqIFkpO1xuICAgICAgICBjb25zdCBaVCA9IE0oWiAqIFQpO1xuICAgICAgICBpZiAoWFkgIT09IFpUKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdiYWQgcG9pbnQ6IGVxdWF0aW9uIGxlZnQgIT0gcmlnaHQgKDIpJyk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICAvKiogRXF1YWxpdHkgY2hlY2s6IGNvbXBhcmUgcG9pbnRzIFAmUS4gKi9cbiAgICBlcXVhbHMob3RoZXIpIHtcbiAgICAgICAgY29uc3QgeyBleDogWDEsIGV5OiBZMSwgZXo6IFoxIH0gPSB0aGlzO1xuICAgICAgICBjb25zdCB7IGV4OiBYMiwgZXk6IFkyLCBlejogWjIgfSA9IGFwb2ludChvdGhlcik7IC8vIGNoZWNrcyBjbGFzcyBlcXVhbGl0eVxuICAgICAgICBjb25zdCBYMVoyID0gTShYMSAqIFoyKTtcbiAgICAgICAgY29uc3QgWDJaMSA9IE0oWDIgKiBaMSk7XG4gICAgICAgIGNvbnN0IFkxWjIgPSBNKFkxICogWjIpO1xuICAgICAgICBjb25zdCBZMloxID0gTShZMiAqIFoxKTtcbiAgICAgICAgcmV0dXJuIFgxWjIgPT09IFgyWjEgJiYgWTFaMiA9PT0gWTJaMTtcbiAgICB9XG4gICAgaXMwKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5lcXVhbHMoSSk7XG4gICAgfVxuICAgIC8qKiBGbGlwIHBvaW50IG92ZXIgeSBjb29yZGluYXRlLiAqL1xuICAgIG5lZ2F0ZSgpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBQb2ludChNKC10aGlzLmV4KSwgdGhpcy5leSwgdGhpcy5leiwgTSgtdGhpcy5ldCkpO1xuICAgIH1cbiAgICAvKiogUG9pbnQgZG91YmxpbmcuIENvbXBsZXRlIGZvcm11bGEuIENvc3Q6IGA0TSArIDRTICsgMSphICsgNmFkZCArIDEqMmAuICovXG4gICAgZG91YmxlKCkge1xuICAgICAgICBjb25zdCB7IGV4OiBYMSwgZXk6IFkxLCBlejogWjEgfSA9IHRoaXM7XG4gICAgICAgIGNvbnN0IGEgPSBfYTtcbiAgICAgICAgLy8gaHR0cHM6Ly9oeXBlcmVsbGlwdGljLm9yZy9FRkQvZzFwL2F1dG8tdHdpc3RlZC1leHRlbmRlZC5odG1sI2RvdWJsaW5nLWRibC0yMDA4LWh3Y2RcbiAgICAgICAgY29uc3QgQSA9IE0oWDEgKiBYMSk7XG4gICAgICAgIGNvbnN0IEIgPSBNKFkxICogWTEpO1xuICAgICAgICBjb25zdCBDID0gTSgybiAqIE0oWjEgKiBaMSkpO1xuICAgICAgICBjb25zdCBEID0gTShhICogQSk7XG4gICAgICAgIGNvbnN0IHgxeTEgPSBYMSArIFkxO1xuICAgICAgICBjb25zdCBFID0gTShNKHgxeTEgKiB4MXkxKSAtIEEgLSBCKTtcbiAgICAgICAgY29uc3QgRyA9IEQgKyBCO1xuICAgICAgICBjb25zdCBGID0gRyAtIEM7XG4gICAgICAgIGNvbnN0IEggPSBEIC0gQjtcbiAgICAgICAgY29uc3QgWDMgPSBNKEUgKiBGKTtcbiAgICAgICAgY29uc3QgWTMgPSBNKEcgKiBIKTtcbiAgICAgICAgY29uc3QgVDMgPSBNKEUgKiBIKTtcbiAgICAgICAgY29uc3QgWjMgPSBNKEYgKiBHKTtcbiAgICAgICAgcmV0dXJuIG5ldyBQb2ludChYMywgWTMsIFozLCBUMyk7XG4gICAgfVxuICAgIC8qKiBQb2ludCBhZGRpdGlvbi4gQ29tcGxldGUgZm9ybXVsYS4gQ29zdDogYDhNICsgMSprICsgOGFkZCArIDEqMmAuICovXG4gICAgYWRkKG90aGVyKSB7XG4gICAgICAgIGNvbnN0IHsgZXg6IFgxLCBleTogWTEsIGV6OiBaMSwgZXQ6IFQxIH0gPSB0aGlzO1xuICAgICAgICBjb25zdCB7IGV4OiBYMiwgZXk6IFkyLCBlejogWjIsIGV0OiBUMiB9ID0gYXBvaW50KG90aGVyKTsgLy8gZG9lc24ndCBjaGVjayBpZiBvdGhlciBvbi1jdXJ2ZVxuICAgICAgICBjb25zdCBhID0gX2E7XG4gICAgICAgIGNvbnN0IGQgPSBfZDtcbiAgICAgICAgLy8gaHR0cHM6Ly9oeXBlcmVsbGlwdGljLm9yZy9FRkQvZzFwL2F1dG8tdHdpc3RlZC1leHRlbmRlZC0xLmh0bWwjYWRkaXRpb24tYWRkLTIwMDgtaHdjZC0zXG4gICAgICAgIGNvbnN0IEEgPSBNKFgxICogWDIpO1xuICAgICAgICBjb25zdCBCID0gTShZMSAqIFkyKTtcbiAgICAgICAgY29uc3QgQyA9IE0oVDEgKiBkICogVDIpO1xuICAgICAgICBjb25zdCBEID0gTShaMSAqIFoyKTtcbiAgICAgICAgY29uc3QgRSA9IE0oKFgxICsgWTEpICogKFgyICsgWTIpIC0gQSAtIEIpO1xuICAgICAgICBjb25zdCBGID0gTShEIC0gQyk7XG4gICAgICAgIGNvbnN0IEcgPSBNKEQgKyBDKTtcbiAgICAgICAgY29uc3QgSCA9IE0oQiAtIGEgKiBBKTtcbiAgICAgICAgY29uc3QgWDMgPSBNKEUgKiBGKTtcbiAgICAgICAgY29uc3QgWTMgPSBNKEcgKiBIKTtcbiAgICAgICAgY29uc3QgVDMgPSBNKEUgKiBIKTtcbiAgICAgICAgY29uc3QgWjMgPSBNKEYgKiBHKTtcbiAgICAgICAgcmV0dXJuIG5ldyBQb2ludChYMywgWTMsIFozLCBUMyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFBvaW50LWJ5LXNjYWxhciBtdWx0aXBsaWNhdGlvbi4gU2NhbGFyIG11c3QgYmUgaW4gcmFuZ2UgMSA8PSBuIDwgQ1VSVkUubi5cbiAgICAgKiBVc2VzIHtAbGluayB3TkFGfSBmb3IgYmFzZSBwb2ludC5cbiAgICAgKiBVc2VzIGZha2UgcG9pbnQgdG8gbWl0aWdhdGUgc2lkZS1jaGFubmVsIGxlYWthZ2UuXG4gICAgICogQHBhcmFtIG4gc2NhbGFyIGJ5IHdoaWNoIHBvaW50IGlzIG11bHRpcGxpZWRcbiAgICAgKiBAcGFyYW0gc2FmZSBzYWZlIG1vZGUgZ3VhcmRzIGFnYWluc3QgdGltaW5nIGF0dGFja3M7IHVuc2FmZSBtb2RlIGlzIGZhc3RlclxuICAgICAqL1xuICAgIG11bHRpcGx5KG4sIHNhZmUgPSB0cnVlKSB7XG4gICAgICAgIGlmICghc2FmZSAmJiAobiA9PT0gMG4gfHwgdGhpcy5pczAoKSkpXG4gICAgICAgICAgICByZXR1cm4gSTtcbiAgICAgICAgYXJhbmdlKG4sIDFuLCBOKTtcbiAgICAgICAgaWYgKG4gPT09IDFuKVxuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIGlmICh0aGlzLmVxdWFscyhHKSlcbiAgICAgICAgICAgIHJldHVybiB3TkFGKG4pLnA7XG4gICAgICAgIC8vIGluaXQgcmVzdWx0IHBvaW50ICYgZmFrZSBwb2ludFxuICAgICAgICBsZXQgcCA9IEk7XG4gICAgICAgIGxldCBmID0gRztcbiAgICAgICAgZm9yIChsZXQgZCA9IHRoaXM7IG4gPiAwbjsgZCA9IGQuZG91YmxlKCksIG4gPj49IDFuKSB7XG4gICAgICAgICAgICAvLyBpZiBiaXQgaXMgcHJlc2VudCwgYWRkIHRvIHBvaW50XG4gICAgICAgICAgICAvLyBpZiBub3QgcHJlc2VudCwgYWRkIHRvIGZha2UsIGZvciB0aW1pbmcgc2FmZXR5XG4gICAgICAgICAgICBpZiAobiAmIDFuKVxuICAgICAgICAgICAgICAgIHAgPSBwLmFkZChkKTtcbiAgICAgICAgICAgIGVsc2UgaWYgKHNhZmUpXG4gICAgICAgICAgICAgICAgZiA9IGYuYWRkKGQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBwO1xuICAgIH1cbiAgICAvKiogQ29udmVydCBwb2ludCB0byAyZCB4eSBhZmZpbmUgcG9pbnQuIChYLCBZLCBaKSDiiIsgKHg9WC9aLCB5PVkvWikgKi9cbiAgICB0b0FmZmluZSgpIHtcbiAgICAgICAgY29uc3QgeyBleDogeCwgZXk6IHksIGV6OiB6IH0gPSB0aGlzO1xuICAgICAgICAvLyBmYXN0LXBhdGhzIGZvciBaRVJPIHBvaW50IE9SIFo9MVxuICAgICAgICBpZiAodGhpcy5lcXVhbHMoSSkpXG4gICAgICAgICAgICByZXR1cm4geyB4OiAwbiwgeTogMW4gfTtcbiAgICAgICAgY29uc3QgaXogPSBpbnZlcnQoeiwgUCk7XG4gICAgICAgIC8vIChaICogWl4tMSkgbXVzdCBiZSAxLCBvdGhlcndpc2UgYmFkIG1hdGhcbiAgICAgICAgaWYgKE0oeiAqIGl6KSAhPT0gMW4pXG4gICAgICAgICAgICBlcnIoJ2ludmFsaWQgaW52ZXJzZScpO1xuICAgICAgICAvLyB4ID0gWCpaXi0xOyB5ID0gWSpaXi0xXG4gICAgICAgIHJldHVybiB7IHg6IE0oeCAqIGl6KSwgeTogTSh5ICogaXopIH07XG4gICAgfVxuICAgIHRvQnl0ZXMoKSB7XG4gICAgICAgIGNvbnN0IHsgeCwgeSB9ID0gdGhpcy5hc3NlcnRWYWxpZGl0eSgpLnRvQWZmaW5lKCk7XG4gICAgICAgIGNvbnN0IGIgPSBudW1UbzMyYkxFKHkpO1xuICAgICAgICAvLyBzdG9yZSBzaWduIGluIGZpcnN0IExFIGJ5dGVcbiAgICAgICAgYlszMV0gfD0geCAmIDFuID8gMHg4MCA6IDA7XG4gICAgICAgIHJldHVybiBiO1xuICAgIH1cbiAgICB0b0hleCgpIHtcbiAgICAgICAgcmV0dXJuIGJ5dGVzVG9IZXgodGhpcy50b0J5dGVzKCkpO1xuICAgIH0gLy8gZW5jb2RlIHRvIGhleCBzdHJpbmdcbiAgICBjbGVhckNvZmFjdG9yKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5tdWx0aXBseShiaWcoaCksIGZhbHNlKTtcbiAgICB9XG4gICAgaXNTbWFsbE9yZGVyKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5jbGVhckNvZmFjdG9yKCkuaXMwKCk7XG4gICAgfVxuICAgIGlzVG9yc2lvbkZyZWUoKSB7XG4gICAgICAgIC8vIG11bHRpcGx5IGJ5IGJpZyBudW1iZXIgQ1VSVkUublxuICAgICAgICBsZXQgcCA9IHRoaXMubXVsdGlwbHkoTiAvIDJuLCBmYWxzZSkuZG91YmxlKCk7IC8vIGVuc3VyZXMgdGhlIHBvaW50IGlzIG5vdCBcImJhZFwiLlxuICAgICAgICBpZiAoTiAlIDJuKVxuICAgICAgICAgICAgcCA9IHAuYWRkKHRoaXMpOyAvLyBQXihOKzEpIC8vIFAqTiA9PSAoUCooTi8yKSkqMitQXG4gICAgICAgIHJldHVybiBwLmlzMCgpO1xuICAgIH1cbiAgICBzdGF0aWMgZnJvbUhleChoZXgsIHppcDIxNSkge1xuICAgICAgICByZXR1cm4gUG9pbnQuZnJvbUJ5dGVzKHRvVTgoaGV4KSwgemlwMjE1KTtcbiAgICB9XG4gICAgZ2V0IHgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnRvQWZmaW5lKCkueDtcbiAgICB9XG4gICAgZ2V0IHkoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnRvQWZmaW5lKCkueTtcbiAgICB9XG4gICAgdG9SYXdCeXRlcygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudG9CeXRlcygpO1xuICAgIH1cbn1cbi8qKiBHZW5lcmF0b3IgLyBiYXNlIHBvaW50ICovXG5jb25zdCBHID0gbmV3IFBvaW50KEd4LCBHeSwgMW4sIE0oR3ggKiBHeSkpO1xuLyoqIElkZW50aXR5IC8gemVybyBwb2ludCAqL1xuY29uc3QgSSA9IG5ldyBQb2ludCgwbiwgMW4sIDFuLCAwbik7XG4vLyBTdGF0aWMgYWxpYXNlc1xuUG9pbnQuQkFTRSA9IEc7XG5Qb2ludC5aRVJPID0gSTtcbmNvbnN0IG51bVRvMzJiTEUgPSAobnVtKSA9PiBoZXhUb0J5dGVzKHBhZGgoYXJhbmdlKG51bSwgMG4sIEIyNTYpLCBMMikpLnJldmVyc2UoKTtcbmNvbnN0IGJ5dGVzVG9OdW1MRSA9IChiKSA9PiBiaWcoJzB4JyArIGJ5dGVzVG9IZXgodThmcihhYnl0ZXMoYikpLnJldmVyc2UoKSkpO1xuY29uc3QgcG93MiA9ICh4LCBwb3dlcikgPT4ge1xuICAgIC8vIHBvdzIoeCwgNCkgPT0geF4oMl40KVxuICAgIGxldCByID0geDtcbiAgICB3aGlsZSAocG93ZXItLSA+IDBuKSB7XG4gICAgICAgIHIgKj0gcjtcbiAgICAgICAgciAlPSBQO1xuICAgIH1cbiAgICByZXR1cm4gcjtcbn07XG4vLyBwcmV0dGllci1pZ25vcmVcbmNvbnN0IHBvd18yXzI1Ml8zID0gKHgpID0+IHtcbiAgICBjb25zdCB4MiA9ICh4ICogeCkgJSBQOyAvLyB4XjIsICAgICAgIGJpdHMgMVxuICAgIGNvbnN0IGIyID0gKHgyICogeCkgJSBQOyAvLyB4XjMsICAgICAgIGJpdHMgMTFcbiAgICBjb25zdCBiNCA9IChwb3cyKGIyLCAybikgKiBiMikgJSBQOyAvLyB4XigyXjQtMSksIGJpdHMgMTExMVxuICAgIGNvbnN0IGI1ID0gKHBvdzIoYjQsIDFuKSAqIHgpICUgUDsgLy8geF4oMl41LTEpLCBiaXRzIDExMTExXG4gICAgY29uc3QgYjEwID0gKHBvdzIoYjUsIDVuKSAqIGI1KSAlIFA7IC8vIHheKDJeMTApXG4gICAgY29uc3QgYjIwID0gKHBvdzIoYjEwLCAxMG4pICogYjEwKSAlIFA7IC8vIHheKDJeMjApXG4gICAgY29uc3QgYjQwID0gKHBvdzIoYjIwLCAyMG4pICogYjIwKSAlIFA7IC8vIHheKDJeNDApXG4gICAgY29uc3QgYjgwID0gKHBvdzIoYjQwLCA0MG4pICogYjQwKSAlIFA7IC8vIHheKDJeODApXG4gICAgY29uc3QgYjE2MCA9IChwb3cyKGI4MCwgODBuKSAqIGI4MCkgJSBQOyAvLyB4XigyXjE2MClcbiAgICBjb25zdCBiMjQwID0gKHBvdzIoYjE2MCwgODBuKSAqIGI4MCkgJSBQOyAvLyB4XigyXjI0MClcbiAgICBjb25zdCBiMjUwID0gKHBvdzIoYjI0MCwgMTBuKSAqIGIxMCkgJSBQOyAvLyB4XigyXjI1MClcbiAgICBjb25zdCBwb3dfcF81XzggPSAocG93MihiMjUwLCAybikgKiB4KSAlIFA7IC8vIDwgVG8gcG93IHRvIChwKzMpLzgsIG11bHRpcGx5IGl0IGJ5IHguXG4gICAgcmV0dXJuIHsgcG93X3BfNV84LCBiMiB9O1xufTtcbmNvbnN0IFJNMSA9IDB4MmI4MzI0ODA0ZmMxZGYwYjJiNGQwMDk5M2RmYmQ3YTcyZjQzMTgwNmFkMmZlNDc4YzRlZTFiMjc0YTBlYTBiMG47IC8vIOKImi0xXG4vLyBmb3Igc3FydCBjb21wXG4vLyBwcmV0dGllci1pZ25vcmVcbmNvbnN0IHV2UmF0aW8gPSAodSwgdikgPT4ge1xuICAgIGNvbnN0IHYzID0gTSh2ICogdiAqIHYpOyAvLyB2wrNcbiAgICBjb25zdCB2NyA9IE0odjMgKiB2MyAqIHYpOyAvLyB24oG3XG4gICAgY29uc3QgcG93ID0gcG93XzJfMjUyXzModSAqIHY3KS5wb3dfcF81Xzg7IC8vICh1duKBtyleKHAtNSkvOFxuICAgIGxldCB4ID0gTSh1ICogdjMgKiBwb3cpOyAvLyAodXbCsykodXbigbcpXihwLTUpLzhcbiAgICBjb25zdCB2eDIgPSBNKHYgKiB4ICogeCk7IC8vIHZ4wrJcbiAgICBjb25zdCByb290MSA9IHg7IC8vIEZpcnN0IHJvb3QgY2FuZGlkYXRlXG4gICAgY29uc3Qgcm9vdDIgPSBNKHggKiBSTTEpOyAvLyBTZWNvbmQgcm9vdCBjYW5kaWRhdGU7IFJNMSBpcyDiiJotMVxuICAgIGNvbnN0IHVzZVJvb3QxID0gdngyID09PSB1OyAvLyBJZiB2eMKyID0gdSAobW9kIHApLCB4IGlzIGEgc3F1YXJlIHJvb3RcbiAgICBjb25zdCB1c2VSb290MiA9IHZ4MiA9PT0gTSgtdSk7IC8vIElmIHZ4wrIgPSAtdSwgc2V0IHggPC0tIHggKiAyXigocC0xKS80KVxuICAgIGNvbnN0IG5vUm9vdCA9IHZ4MiA9PT0gTSgtdSAqIFJNMSk7IC8vIFRoZXJlIGlzIG5vIHZhbGlkIHJvb3QsIHZ4wrIgPSAtdeKImi0xXG4gICAgaWYgKHVzZVJvb3QxKVxuICAgICAgICB4ID0gcm9vdDE7XG4gICAgaWYgKHVzZVJvb3QyIHx8IG5vUm9vdClcbiAgICAgICAgeCA9IHJvb3QyOyAvLyBXZSByZXR1cm4gcm9vdDIgYW55d2F5LCBmb3IgY29uc3QtdGltZVxuICAgIGlmICgoTSh4KSAmIDFuKSA9PT0gMW4pXG4gICAgICAgIHggPSBNKC14KTsgLy8gZWRJc05lZ2F0aXZlXG4gICAgcmV0dXJuIHsgaXNWYWxpZDogdXNlUm9vdDEgfHwgdXNlUm9vdDIsIHZhbHVlOiB4IH07XG59O1xuLy8gTiA9PSBMLCBqdXN0IHdlaXJkIG5hbWluZ1xuY29uc3QgbW9kTF9MRSA9IChoYXNoKSA9PiBtb2ROKGJ5dGVzVG9OdW1MRShoYXNoKSk7IC8vIG1vZHVsbyBMOyBidXQgbGl0dGxlLWVuZGlhblxuY29uc3Qgc2hhNTEyYSA9ICguLi5tKSA9PiBldGMuc2hhNTEyQXN5bmMoLi4ubSk7IC8vIEFzeW5jIFNIQTUxMlxuY29uc3Qgc2hhNTEycyA9ICguLi5tKSA9PiBjYWxsSGFzaCgnc2hhNTEyU3luYycpKC4uLm0pO1xuLy8gUkZDODAzMiA1LjEuNVxuY29uc3QgaGFzaDJleHRLID0gKGhhc2hlZCkgPT4ge1xuICAgIC8vIHNsaWNlIGNyZWF0ZXMgYSBjb3B5LCB1bmxpa2Ugc3ViYXJyYXlcbiAgICBjb25zdCBoZWFkID0gaGFzaGVkLnNsaWNlKDAsIEwpO1xuICAgIGhlYWRbMF0gJj0gMjQ4OyAvLyBDbGFtcCBiaXRzOiAwYjExMTFfMTAwMFxuICAgIGhlYWRbMzFdICY9IDEyNzsgLy8gMGIwMTExXzExMTFcbiAgICBoZWFkWzMxXSB8PSA2NDsgLy8gMGIwMTAwXzAwMDBcbiAgICBjb25zdCBwcmVmaXggPSBoYXNoZWQuc2xpY2UoTCwgTDIpOyAvLyBwcml2YXRlIGtleSBcInByZWZpeFwiXG4gICAgY29uc3Qgc2NhbGFyID0gbW9kTF9MRShoZWFkKTsgLy8gbW9kdWxhciBkaXZpc2lvbiBvdmVyIGN1cnZlIG9yZGVyXG4gICAgY29uc3QgcG9pbnQgPSBHLm11bHRpcGx5KHNjYWxhcik7IC8vIHB1YmxpYyBrZXkgcG9pbnRcbiAgICBjb25zdCBwb2ludEJ5dGVzID0gcG9pbnQudG9CeXRlcygpOyAvLyBwb2ludCBzZXJpYWxpemVkIHRvIFVpbnQ4QXJyYXlcbiAgICByZXR1cm4geyBoZWFkLCBwcmVmaXgsIHNjYWxhciwgcG9pbnQsIHBvaW50Qnl0ZXMgfTtcbn07XG4vLyBSRkM4MDMyIDUuMS41OyBnZXRQdWJsaWNLZXkgYXN5bmMsIHN5bmMuIEhhc2ggcHJpdiBrZXkgYW5kIGV4dHJhY3QgcG9pbnQuXG5jb25zdCBnZXRFeHRlbmRlZFB1YmxpY0tleUFzeW5jID0gKHByaXYpID0+IHNoYTUxMmEodG9VOChwcml2LCBMKSkudGhlbihoYXNoMmV4dEspO1xuY29uc3QgZ2V0RXh0ZW5kZWRQdWJsaWNLZXkgPSAocHJpdikgPT4gaGFzaDJleHRLKHNoYTUxMnModG9VOChwcml2LCBMKSkpO1xuLyoqIENyZWF0ZXMgMzItYnl0ZSBlZDI1NTE5IHB1YmxpYyBrZXkgZnJvbSAzMi1ieXRlIHByaXZhdGUga2V5LiBBc3luYy4gKi9cbmNvbnN0IGdldFB1YmxpY0tleUFzeW5jID0gKHByaXYpID0+IGdldEV4dGVuZGVkUHVibGljS2V5QXN5bmMocHJpdikudGhlbigocCkgPT4gcC5wb2ludEJ5dGVzKTtcbi8qKiBDcmVhdGVzIDMyLWJ5dGUgZWQyNTUxOSBwdWJsaWMga2V5IGZyb20gMzItYnl0ZSBwcml2YXRlIGtleS4gVG8gdXNlLCBzZXQgYGV0Yy5zaGE1MTJTeW5jYCBmaXJzdC4gKi9cbmNvbnN0IGdldFB1YmxpY0tleSA9IChwcml2KSA9PiBnZXRFeHRlbmRlZFB1YmxpY0tleShwcml2KS5wb2ludEJ5dGVzO1xuY29uc3QgaGFzaEZpbmlzaEEgPSAocmVzKSA9PiBzaGE1MTJhKHJlcy5oYXNoYWJsZSkudGhlbihyZXMuZmluaXNoKTtcbmNvbnN0IGhhc2hGaW5pc2hTID0gKHJlcykgPT4gcmVzLmZpbmlzaChzaGE1MTJzKHJlcy5oYXNoYWJsZSkpO1xuY29uc3QgX3NpZ24gPSAoZSwgckJ5dGVzLCBtc2cpID0+IHtcbiAgICAvLyBzaWduKCkgc2hhcmVkIGNvZGVcbiAgICBjb25zdCB7IHBvaW50Qnl0ZXM6IFAsIHNjYWxhcjogcyB9ID0gZTtcbiAgICBjb25zdCByID0gbW9kTF9MRShyQnl0ZXMpOyAvLyByIHdhcyBjcmVhdGVkIG91dHNpZGUsIHJlZHVjZSBpdCBtb2R1bG8gTFxuICAgIGNvbnN0IFIgPSBHLm11bHRpcGx5KHIpLnRvQnl0ZXMoKTsgLy8gUiA9IFtyXUJcbiAgICBjb25zdCBoYXNoYWJsZSA9IGNvbmNhdEJ5dGVzKFIsIFAsIG1zZyk7IC8vIGRvbTIoRiwgQykgfHwgUiB8fCBBIHx8IFBIKE0pXG4gICAgY29uc3QgZmluaXNoID0gKGhhc2hlZCkgPT4ge1xuICAgICAgICAvLyBrID0gU0hBNTEyKGRvbTIoRiwgQykgfHwgUiB8fCBBIHx8IFBIKE0pKVxuICAgICAgICBjb25zdCBTID0gbW9kTihyICsgbW9kTF9MRShoYXNoZWQpICogcyk7IC8vIFMgPSAociArIGsgKiBzKSBtb2QgTDsgMCA8PSBzIDwgbFxuICAgICAgICByZXR1cm4gYWJ5dGVzKGNvbmNhdEJ5dGVzKFIsIG51bVRvMzJiTEUoUykpLCBMMik7IC8vIDY0LWJ5dGUgc2lnOiAzMmIgUi54ICsgMzJiIExFKFMpXG4gICAgfTtcbiAgICByZXR1cm4geyBoYXNoYWJsZSwgZmluaXNoIH07XG59O1xuLyoqXG4gKiBTaWducyBtZXNzYWdlIChOT1QgbWVzc2FnZSBoYXNoKSB1c2luZyBwcml2YXRlIGtleS4gQXN5bmMuXG4gKiBGb2xsb3dzIFJGQzgwMzIgNS4xLjYuXG4gKi9cbmNvbnN0IHNpZ25Bc3luYyA9IGFzeW5jIChtc2csIHByaXZLZXkpID0+IHtcbiAgICBjb25zdCBtID0gdG9VOChtc2cpO1xuICAgIGNvbnN0IGUgPSBhd2FpdCBnZXRFeHRlbmRlZFB1YmxpY0tleUFzeW5jKHByaXZLZXkpO1xuICAgIGNvbnN0IHJCeXRlcyA9IGF3YWl0IHNoYTUxMmEoZS5wcmVmaXgsIG0pOyAvLyByID0gU0hBNTEyKGRvbTIoRiwgQykgfHwgcHJlZml4IHx8IFBIKE0pKVxuICAgIHJldHVybiBoYXNoRmluaXNoQShfc2lnbihlLCByQnl0ZXMsIG0pKTsgLy8gZ2VuIFIsIGssIFMsIHRoZW4gNjQtYnl0ZSBzaWduYXR1cmVcbn07XG4vKipcbiAqIFNpZ25zIG1lc3NhZ2UgKE5PVCBtZXNzYWdlIGhhc2gpIHVzaW5nIHByaXZhdGUga2V5LiBUbyB1c2UsIHNldCBgaGFzaGVzLnNoYTUxMmAgZmlyc3QuXG4gKiBGb2xsb3dzIFJGQzgwMzIgNS4xLjYuXG4gKi9cbmNvbnN0IHNpZ24gPSAobXNnLCBwcml2S2V5KSA9PiB7XG4gICAgY29uc3QgbSA9IHRvVTgobXNnKTtcbiAgICBjb25zdCBlID0gZ2V0RXh0ZW5kZWRQdWJsaWNLZXkocHJpdktleSk7XG4gICAgY29uc3QgckJ5dGVzID0gc2hhNTEycyhlLnByZWZpeCwgbSk7IC8vIHIgPSBTSEE1MTIoZG9tMihGLCBDKSB8fCBwcmVmaXggfHwgUEgoTSkpXG4gICAgcmV0dXJuIGhhc2hGaW5pc2hTKF9zaWduKGUsIHJCeXRlcywgbSkpOyAvLyBnZW4gUiwgaywgUywgdGhlbiA2NC1ieXRlIHNpZ25hdHVyZVxufTtcbmNvbnN0IHZlcmlPcHRzID0geyB6aXAyMTU6IHRydWUgfTtcbmNvbnN0IF92ZXJpZnkgPSAoc2lnLCBtc2csIHB1Yiwgb3B0cyA9IHZlcmlPcHRzKSA9PiB7XG4gICAgc2lnID0gdG9VOChzaWcsIEwyKTsgLy8gU2lnbmF0dXJlIGhleCBzdHIvQnl0ZXMsIG11c3QgYmUgNjQgYnl0ZXNcbiAgICBtc2cgPSB0b1U4KG1zZyk7IC8vIE1lc3NhZ2UgaGV4IHN0ci9CeXRlc1xuICAgIHB1YiA9IHRvVTgocHViLCBMKTtcbiAgICBjb25zdCB7IHppcDIxNSB9ID0gb3B0czsgLy8gc3dpdGNoIGJldHdlZW4gemlwMjE1IGFuZCByZmM4MDMyIHZlcmlmXG4gICAgbGV0IEE7XG4gICAgbGV0IFI7XG4gICAgbGV0IHM7XG4gICAgbGV0IFNCO1xuICAgIGxldCBoYXNoYWJsZSA9IFVpbnQ4QXJyYXkub2YoKTtcbiAgICB0cnkge1xuICAgICAgICBBID0gUG9pbnQuZnJvbUhleChwdWIsIHppcDIxNSk7IC8vIHB1YmxpYyBrZXkgQSBkZWNvZGVkXG4gICAgICAgIFIgPSBQb2ludC5mcm9tSGV4KHNpZy5zbGljZSgwLCBMKSwgemlwMjE1KTsgLy8gMCA8PSBSIDwgMl4yNTY6IFpJUDIxNSBSIGNhbiBiZSA+PSBQXG4gICAgICAgIHMgPSBieXRlc1RvTnVtTEUoc2lnLnNsaWNlKEwsIEwyKSk7IC8vIERlY29kZSBzZWNvbmQgaGFsZiBhcyBhbiBpbnRlZ2VyIFNcbiAgICAgICAgU0IgPSBHLm11bHRpcGx5KHMsIGZhbHNlKTsgLy8gaW4gdGhlIHJhbmdlIDAgPD0gcyA8IExcbiAgICAgICAgaGFzaGFibGUgPSBjb25jYXRCeXRlcyhSLnRvQnl0ZXMoKSwgQS50b0J5dGVzKCksIG1zZyk7IC8vIGRvbTIoRiwgQykgfHwgUiB8fCBBIHx8IFBIKE0pXG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikgeyB9XG4gICAgY29uc3QgZmluaXNoID0gKGhhc2hlZCkgPT4ge1xuICAgICAgICAvLyBrID0gU0hBNTEyKGRvbTIoRiwgQykgfHwgUiB8fCBBIHx8IFBIKE0pKVxuICAgICAgICBpZiAoU0IgPT0gbnVsbClcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTsgLy8gZmFsc2UgaWYgdHJ5LWNhdGNoIGNhdGNoZWQgYW4gZXJyb3JcbiAgICAgICAgaWYgKCF6aXAyMTUgJiYgQS5pc1NtYWxsT3JkZXIoKSlcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTsgLy8gZmFsc2UgZm9yIFNCUzogU3Ryb25nbHkgQmluZGluZyBTaWduYXR1cmVcbiAgICAgICAgY29uc3QgayA9IG1vZExfTEUoaGFzaGVkKTsgLy8gZGVjb2RlIGluIGxpdHRsZS1lbmRpYW4sIG1vZHVsbyBMXG4gICAgICAgIGNvbnN0IFJrQSA9IFIuYWRkKEEubXVsdGlwbHkoaywgZmFsc2UpKTsgLy8gWzhdUiArIFs4XVtrXUEnXG4gICAgICAgIHJldHVybiBSa0EuYWRkKFNCLm5lZ2F0ZSgpKS5jbGVhckNvZmFjdG9yKCkuaXMwKCk7IC8vIFs4XVtTXUIgPSBbOF1SICsgWzhdW2tdQSdcbiAgICB9O1xuICAgIHJldHVybiB7IGhhc2hhYmxlLCBmaW5pc2ggfTtcbn07XG4vKiogVmVyaWZpZXMgc2lnbmF0dXJlIG9uIG1lc3NhZ2UgYW5kIHB1YmxpYyBrZXkuIEFzeW5jLiBGb2xsb3dzIFJGQzgwMzIgNS4xLjcuICovXG5jb25zdCB2ZXJpZnlBc3luYyA9IGFzeW5jIChzLCBtLCBwLCBvcHRzID0gdmVyaU9wdHMpID0+IGhhc2hGaW5pc2hBKF92ZXJpZnkocywgbSwgcCwgb3B0cykpO1xuLyoqIFZlcmlmaWVzIHNpZ25hdHVyZSBvbiBtZXNzYWdlIGFuZCBwdWJsaWMga2V5LiBUbyB1c2UsIHNldCBgaGFzaGVzLnNoYTUxMmAgZmlyc3QuIEZvbGxvd3MgUkZDODAzMiA1LjEuNy4gKi9cbmNvbnN0IHZlcmlmeSA9IChzLCBtLCBwLCBvcHRzID0gdmVyaU9wdHMpID0+IGhhc2hGaW5pc2hTKF92ZXJpZnkocywgbSwgcCwgb3B0cykpO1xuLyoqIE1hdGgsIGhleCwgYnl0ZSBoZWxwZXJzLiBOb3QgaW4gYHV0aWxzYCBiZWNhdXNlIHV0aWxzIHNoYXJlIEFQSSB3aXRoIG5vYmxlLWN1cnZlcy4gKi9cbmNvbnN0IGV0YyA9IHtcbiAgICBzaGE1MTJBc3luYzogYXN5bmMgKC4uLm1lc3NhZ2VzKSA9PiB7XG4gICAgICAgIGNvbnN0IHMgPSBzdWJ0bGUoKTtcbiAgICAgICAgY29uc3QgbSA9IGNvbmNhdEJ5dGVzKC4uLm1lc3NhZ2VzKTtcbiAgICAgICAgcmV0dXJuIHU4bihhd2FpdCBzLmRpZ2VzdCgnU0hBLTUxMicsIG0uYnVmZmVyKSk7XG4gICAgfSxcbiAgICBzaGE1MTJTeW5jOiB1bmRlZmluZWQsXG4gICAgYnl0ZXNUb0hleDogYnl0ZXNUb0hleCxcbiAgICBoZXhUb0J5dGVzOiBoZXhUb0J5dGVzLFxuICAgIGNvbmNhdEJ5dGVzOiBjb25jYXRCeXRlcyxcbiAgICBtb2Q6IE0sXG4gICAgaW52ZXJ0OiBpbnZlcnQsXG4gICAgcmFuZG9tQnl0ZXM6IHJhbmRvbUJ5dGVzLFxufTtcbi8qKiBlZDI1NTE5LXNwZWNpZmljIGtleSB1dGlsaXRpZXMuICovXG5jb25zdCB1dGlscyA9IHtcbiAgICBnZXRFeHRlbmRlZFB1YmxpY0tleUFzeW5jOiBnZXRFeHRlbmRlZFB1YmxpY0tleUFzeW5jLFxuICAgIGdldEV4dGVuZGVkUHVibGljS2V5OiBnZXRFeHRlbmRlZFB1YmxpY0tleSxcbiAgICByYW5kb21Qcml2YXRlS2V5OiAoKSA9PiByYW5kb21CeXRlcyhMKSxcbiAgICBwcmVjb21wdXRlOiAodyA9IDgsIHAgPSBHKSA9PiB7XG4gICAgICAgIHAubXVsdGlwbHkoM24pO1xuICAgICAgICB3O1xuICAgICAgICByZXR1cm4gcDtcbiAgICB9LCAvLyBuby1vcFxufTtcbi8vICMjIFByZWNvbXB1dGVzXG4vLyAtLS0tLS0tLS0tLS0tLVxuY29uc3QgVyA9IDg7IC8vIFcgaXMgd2luZG93IHNpemVcbmNvbnN0IHNjYWxhckJpdHMgPSAyNTY7XG5jb25zdCBwd2luZG93cyA9IE1hdGguY2VpbChzY2FsYXJCaXRzIC8gVykgKyAxOyAvLyAzMyBmb3IgVz04XG5jb25zdCBwd2luZG93U2l6ZSA9IDIgKiogKFcgLSAxKTsgLy8gMTI4IGZvciBXPThcbmNvbnN0IHByZWNvbXB1dGUgPSAoKSA9PiB7XG4gICAgY29uc3QgcG9pbnRzID0gW107XG4gICAgbGV0IHAgPSBHO1xuICAgIGxldCBiID0gcDtcbiAgICBmb3IgKGxldCB3ID0gMDsgdyA8IHB3aW5kb3dzOyB3KyspIHtcbiAgICAgICAgYiA9IHA7XG4gICAgICAgIHBvaW50cy5wdXNoKGIpO1xuICAgICAgICBmb3IgKGxldCBpID0gMTsgaSA8IHB3aW5kb3dTaXplOyBpKyspIHtcbiAgICAgICAgICAgIGIgPSBiLmFkZChwKTtcbiAgICAgICAgICAgIHBvaW50cy5wdXNoKGIpO1xuICAgICAgICB9IC8vIGk9MSwgYmMgd2Ugc2tpcCAwXG4gICAgICAgIHAgPSBiLmRvdWJsZSgpO1xuICAgIH1cbiAgICByZXR1cm4gcG9pbnRzO1xufTtcbmxldCBHcG93cyA9IHVuZGVmaW5lZDsgLy8gcHJlY29tcHV0ZXMgZm9yIGJhc2UgcG9pbnQgR1xuLy8gY29uc3QtdGltZSBuZWdhdGVcbmNvbnN0IGN0bmVnID0gKGNuZCwgcCkgPT4ge1xuICAgIGNvbnN0IG4gPSBwLm5lZ2F0ZSgpO1xuICAgIHJldHVybiBjbmQgPyBuIDogcDtcbn07XG4vKipcbiAqIFByZWNvbXB1dGVzIGdpdmUgMTJ4IGZhc3RlciBnZXRQdWJsaWNLZXkoKSwgMTB4IHNpZ24oKSwgMnggdmVyaWZ5KCkgYnlcbiAqIGNhY2hpbmcgbXVsdGlwbGVzIG9mIEcgKGJhc2UgcG9pbnQpLiBDYWNoZSBpcyBzdG9yZWQgaW4gMzJNQiBvZiBSQU0uXG4gKiBBbnkgdGltZSBgRy5tdWx0aXBseWAgaXMgZG9uZSwgcHJlY29tcHV0ZXMgYXJlIHVzZWQuXG4gKiBOb3QgdXNlZCBmb3IgZ2V0U2hhcmVkU2VjcmV0LCB3aGljaCBpbnN0ZWFkIG11bHRpcGxpZXMgcmFuZG9tIHB1YmtleSBgUC5tdWx0aXBseWAuXG4gKlxuICogdy1hcnkgbm9uLWFkamFjZW50IGZvcm0gKHdOQUYpIHByZWNvbXB1dGF0aW9uIG1ldGhvZCBpcyAxMCUgc2xvd2VyIHRoYW4gd2luZG93ZWQgbWV0aG9kLFxuICogYnV0IHRha2VzIDJ4IGxlc3MgUkFNLiBSQU0gcmVkdWN0aW9uIGlzIHBvc3NpYmxlIGJ5IHV0aWxpemluZyBgLnN1YnRyYWN0YC5cbiAqXG4gKiAhISBQcmVjb21wdXRlcyBjYW4gYmUgZGlzYWJsZWQgYnkgY29tbWVudGluZy1vdXQgY2FsbCBvZiB0aGUgd05BRigpIGluc2lkZSBQb2ludCNtdWx0aXBseSgpLlxuICovXG5jb25zdCB3TkFGID0gKG4pID0+IHtcbiAgICBjb25zdCBjb21wID0gR3Bvd3MgfHwgKEdwb3dzID0gcHJlY29tcHV0ZSgpKTtcbiAgICBsZXQgcCA9IEk7XG4gICAgbGV0IGYgPSBHOyAvLyBmIG11c3QgYmUgRywgb3IgY291bGQgYmVjb21lIEkgaW4gdGhlIGVuZFxuICAgIGNvbnN0IHBvd18yX3cgPSAyICoqIFc7IC8vIDI1NiBmb3IgVz04XG4gICAgY29uc3QgbWF4TnVtID0gcG93XzJfdzsgLy8gMjU2IGZvciBXPThcbiAgICBjb25zdCBtYXNrID0gYmlnKHBvd18yX3cgLSAxKTsgLy8gMjU1IGZvciBXPTggPT0gbWFzayAwYjExMTExMTExXG4gICAgY29uc3Qgc2hpZnRCeSA9IGJpZyhXKTsgLy8gOCBmb3IgVz04XG4gICAgZm9yIChsZXQgdyA9IDA7IHcgPCBwd2luZG93czsgdysrKSB7XG4gICAgICAgIGxldCB3Yml0cyA9IE51bWJlcihuICYgbWFzayk7IC8vIGV4dHJhY3QgVyBiaXRzLlxuICAgICAgICBuID4+PSBzaGlmdEJ5OyAvLyBzaGlmdCBudW1iZXIgYnkgVyBiaXRzLlxuICAgICAgICBpZiAod2JpdHMgPiBwd2luZG93U2l6ZSkge1xuICAgICAgICAgICAgd2JpdHMgLT0gbWF4TnVtO1xuICAgICAgICAgICAgbiArPSAxbjtcbiAgICAgICAgfSAvLyBzcGxpdCBpZiBiaXRzID4gbWF4OiArMjI0ID0+IDI1Ni0zMlxuICAgICAgICBjb25zdCBvZmYgPSB3ICogcHdpbmRvd1NpemU7XG4gICAgICAgIGNvbnN0IG9mZkYgPSBvZmY7IC8vIG9mZnNldHMsIGV2YWx1YXRlIGJvdGhcbiAgICAgICAgY29uc3Qgb2ZmUCA9IG9mZiArIE1hdGguYWJzKHdiaXRzKSAtIDE7XG4gICAgICAgIGNvbnN0IGlzRXZlbiA9IHcgJSAyICE9PSAwOyAvLyBjb25kaXRpb25zLCBldmFsdWF0ZSBib3RoXG4gICAgICAgIGNvbnN0IGlzTmVnID0gd2JpdHMgPCAwO1xuICAgICAgICBpZiAod2JpdHMgPT09IDApIHtcbiAgICAgICAgICAgIC8vIG9mZiA9PSBJOiBjYW4ndCBhZGQgaXQuIEFkZGluZyByYW5kb20gb2ZmRiBpbnN0ZWFkLlxuICAgICAgICAgICAgZiA9IGYuYWRkKGN0bmVnKGlzRXZlbiwgY29tcFtvZmZGXSkpOyAvLyBiaXRzIGFyZSAwOiBhZGQgZ2FyYmFnZSB0byBmYWtlIHBvaW50XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBwID0gcC5hZGQoY3RuZWcoaXNOZWcsIGNvbXBbb2ZmUF0pKTsgLy8gYml0cyBhcmUgMTogYWRkIHRvIHJlc3VsdCBwb2ludFxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7IHAsIGYgfTsgLy8gcmV0dXJuIGJvdGggcmVhbCBhbmQgZmFrZSBwb2ludHMgZm9yIEpJVFxufTtcbi8vICEhIFJlbW92ZSB0aGUgZXhwb3J0IHRvIGVhc2lseSB1c2UgaW4gUkVQTCAvIGJyb3dzZXIgY29uc29sZVxuZXhwb3J0IHsgZWQyNTUxOV9DVVJWRSBhcyBDVVJWRSwgZXRjLCBQb2ludCBhcyBFeHRlbmRlZFBvaW50LCBnZXRQdWJsaWNLZXksIGdldFB1YmxpY0tleUFzeW5jLCBQb2ludCwgc2lnbiwgc2lnbkFzeW5jLCB1dGlscywgdmVyaWZ5LCB2ZXJpZnlBc3luYywgfTtcbiIsIi8qKlxuICogQ2hlY2tzIGlmIHNvbWV0aGluZyBpcyBVaW50OEFycmF5LiBCZSBjYXJlZnVsOiBub2RlanMgQnVmZmVyIHdpbGwgcmV0dXJuIHRydWUuXG4gKiBAcGFyYW0gYSAtIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm5zIGB0cnVlYCB3aGVuIHRoZSB2YWx1ZSBpcyBhIFVpbnQ4QXJyYXktY29tcGF0aWJsZSB2aWV3LlxuICogQGV4YW1wbGVcbiAqIENoZWNrIHdoZXRoZXIgYSB2YWx1ZSBpcyBhIFVpbnQ4QXJyYXktY29tcGF0aWJsZSB2aWV3LlxuICogYGBgdHNcbiAqIGlzQnl0ZXMobmV3IFVpbnQ4QXJyYXkoWzEsIDIsIDNdKSk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzQnl0ZXMoYSkge1xuICAgIC8vIFBsYWluIGBpbnN0YW5jZW9mIFVpbnQ4QXJyYXlgIGlzIHRvbyBzdHJpY3QgZm9yIHNvbWUgQnVmZmVyIC8gcHJveHkgLyBjcm9zcy1yZWFsbSBjYXNlcy5cbiAgICAvLyBUaGUgZmFsbGJhY2sgc3RpbGwgcmVxdWlyZXMgYSByZWFsIEFycmF5QnVmZmVyIHZpZXcsIHNvIHBsYWluXG4gICAgLy8gSlNPTi1kZXNlcmlhbGl6ZWQgYHsgY29uc3RydWN0b3I6IC4uLiB9YCBzcG9vZmluZyBpcyByZWplY3RlZCwgYW5kXG4gICAgLy8gYEJZVEVTX1BFUl9FTEVNRU5UID09PSAxYCBrZWVwcyB0aGUgZmFsbGJhY2sgb24gYnl0ZS1vcmllbnRlZCB2aWV3cy5cbiAgICByZXR1cm4gKGEgaW5zdGFuY2VvZiBVaW50OEFycmF5IHx8XG4gICAgICAgIChBcnJheUJ1ZmZlci5pc1ZpZXcoYSkgJiZcbiAgICAgICAgICAgIGEuY29uc3RydWN0b3IubmFtZSA9PT0gJ1VpbnQ4QXJyYXknICYmXG4gICAgICAgICAgICAnQllURVNfUEVSX0VMRU1FTlQnIGluIGEgJiZcbiAgICAgICAgICAgIGEuQllURVNfUEVSX0VMRU1FTlQgPT09IDEpKTtcbn1cbi8qKlxuICogQXNzZXJ0cyBzb21ldGhpbmcgaXMgYSBub24tbmVnYXRpdmUgaW50ZWdlci5cbiAqIEBwYXJhbSBuIC0gbnVtYmVyIHRvIHZhbGlkYXRlXG4gKiBAcGFyYW0gdGl0bGUgLSBsYWJlbCBpbmNsdWRlZCBpbiB0aHJvd24gZXJyb3JzXG4gKiBAdGhyb3dzIE9uIHdyb25nIGFyZ3VtZW50IHR5cGVzLiB7QGxpbmsgVHlwZUVycm9yfVxuICogQHRocm93cyBPbiB3cm9uZyBhcmd1bWVudCByYW5nZXMgb3IgdmFsdWVzLiB7QGxpbmsgUmFuZ2VFcnJvcn1cbiAqIEBleGFtcGxlXG4gKiBWYWxpZGF0ZSBhIG5vbi1uZWdhdGl2ZSBpbnRlZ2VyIG9wdGlvbi5cbiAqIGBgYHRzXG4gKiBhbnVtYmVyKDMyLCAnbGVuZ3RoJyk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFudW1iZXIobiwgdGl0bGUgPSAnJykge1xuICAgIGlmICh0eXBlb2YgbiAhPT0gJ251bWJlcicpIHtcbiAgICAgICAgY29uc3QgcHJlZml4ID0gdGl0bGUgJiYgYFwiJHt0aXRsZX1cIiBgO1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGAke3ByZWZpeH1leHBlY3RlZCBudW1iZXIsIGdvdCAke3R5cGVvZiBufWApO1xuICAgIH1cbiAgICBpZiAoIU51bWJlci5pc1NhZmVJbnRlZ2VyKG4pIHx8IG4gPCAwKSB7XG4gICAgICAgIGNvbnN0IHByZWZpeCA9IHRpdGxlICYmIGBcIiR7dGl0bGV9XCIgYDtcbiAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoYCR7cHJlZml4fWV4cGVjdGVkIGludGVnZXIgPj0gMCwgZ290ICR7bn1gKTtcbiAgICB9XG59XG4vKipcbiAqIEFzc2VydHMgc29tZXRoaW5nIGlzIFVpbnQ4QXJyYXkuXG4gKiBAcGFyYW0gdmFsdWUgLSB2YWx1ZSB0byB2YWxpZGF0ZVxuICogQHBhcmFtIGxlbmd0aCAtIG9wdGlvbmFsIGV4YWN0IGxlbmd0aCBjb25zdHJhaW50XG4gKiBAcGFyYW0gdGl0bGUgLSBsYWJlbCBpbmNsdWRlZCBpbiB0aHJvd24gZXJyb3JzXG4gKiBAcmV0dXJucyBUaGUgdmFsaWRhdGVkIGJ5dGUgYXJyYXkuXG4gKiBAdGhyb3dzIE9uIHdyb25nIGFyZ3VtZW50IHR5cGVzLiB7QGxpbmsgVHlwZUVycm9yfVxuICogQHRocm93cyBPbiB3cm9uZyBhcmd1bWVudCByYW5nZXMgb3IgdmFsdWVzLiB7QGxpbmsgUmFuZ2VFcnJvcn1cbiAqIEBleGFtcGxlXG4gKiBWYWxpZGF0ZSB0aGF0IGEgdmFsdWUgaXMgYSBieXRlIGFycmF5LlxuICogYGBgdHNcbiAqIGFieXRlcyhuZXcgVWludDhBcnJheShbMSwgMiwgM10pKTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gYWJ5dGVzKHZhbHVlLCBsZW5ndGgsIHRpdGxlID0gJycpIHtcbiAgICBjb25zdCBieXRlcyA9IGlzQnl0ZXModmFsdWUpO1xuICAgIGNvbnN0IGxlbiA9IHZhbHVlPy5sZW5ndGg7XG4gICAgY29uc3QgbmVlZHNMZW4gPSBsZW5ndGggIT09IHVuZGVmaW5lZDtcbiAgICBpZiAoIWJ5dGVzIHx8IChuZWVkc0xlbiAmJiBsZW4gIT09IGxlbmd0aCkpIHtcbiAgICAgICAgY29uc3QgcHJlZml4ID0gdGl0bGUgJiYgYFwiJHt0aXRsZX1cIiBgO1xuICAgICAgICBjb25zdCBvZkxlbiA9IG5lZWRzTGVuID8gYCBvZiBsZW5ndGggJHtsZW5ndGh9YCA6ICcnO1xuICAgICAgICBjb25zdCBnb3QgPSBieXRlcyA/IGBsZW5ndGg9JHtsZW59YCA6IGB0eXBlPSR7dHlwZW9mIHZhbHVlfWA7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBwcmVmaXggKyAnZXhwZWN0ZWQgVWludDhBcnJheScgKyBvZkxlbiArICcsIGdvdCAnICsgZ290O1xuICAgICAgICBpZiAoIWJ5dGVzKVxuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihtZXNzYWdlKTtcbiAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IobWVzc2FnZSk7XG4gICAgfVxuICAgIHJldHVybiB2YWx1ZTtcbn1cbi8qKlxuICogQ29waWVzIGJ5dGVzIGludG8gYSBmcmVzaCBVaW50OEFycmF5LlxuICogQnVmZmVyLXN0eWxlIHNsaWNlcyBjYW4gYWxpYXMgdGhlIHNhbWUgYmFja2luZyBzdG9yZSwgc28gY2FsbGVycyB0aGF0IG5lZWQgb3duZXJzaGlwIHNob3VsZCBjb3B5LlxuICogQHBhcmFtIGJ5dGVzIC0gc291cmNlIGJ5dGVzIHRvIGNsb25lXG4gKiBAcmV0dXJucyBGcmVzaGx5IGFsbG9jYXRlZCBjb3B5IG9mIGBieXRlc2AuXG4gKiBAdGhyb3dzIE9uIHdyb25nIGFyZ3VtZW50IHR5cGVzLiB7QGxpbmsgVHlwZUVycm9yfVxuICogQGV4YW1wbGVcbiAqIENsb25lIGEgYnl0ZSBhcnJheSBiZWZvcmUgbXV0YXRpbmcgaXQuXG4gKiBgYGB0c1xuICogY29uc3QgY29weSA9IGNvcHlCeXRlcyhuZXcgVWludDhBcnJheShbMSwgMiwgM10pKTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gY29weUJ5dGVzKGJ5dGVzKSB7XG4gICAgLy8gYFVpbnQ4QXJyYXkuZnJvbSguLi4pYCB3b3VsZCBhbHNvIGFjY2VwdCBhcnJheXMgLyBvdGhlciB0eXBlZCBhcnJheXMuIEtlZXAgdGhpcyBoZWxwZXIgc3RyaWN0XG4gICAgLy8gYmVjYXVzZSBjYWxsZXJzIHVzZSBpdCBhdCBieXRlLXZhbGlkYXRpb24gYm91bmRhcmllcyBiZWZvcmUgbXV0YXRpbmcgdGhlIGRldGFjaGVkIGNvcHkuXG4gICAgcmV0dXJuIFVpbnQ4QXJyYXkuZnJvbShhYnl0ZXMoYnl0ZXMpKTtcbn1cbi8qKlxuICogQXNzZXJ0cyBzb21ldGhpbmcgaXMgYSB3cmFwcGVkIGhhc2ggY29uc3RydWN0b3IuXG4gKiBAcGFyYW0gaCAtIGhhc2ggY29uc3RydWN0b3IgdG8gdmFsaWRhdGVcbiAqIEB0aHJvd3MgT24gd3JvbmcgYXJndW1lbnQgdHlwZXMgb3IgaW52YWxpZCBoYXNoIHdyYXBwZXIgc2hhcGUuIHtAbGluayBUeXBlRXJyb3J9XG4gKiBAdGhyb3dzIE9uIGludmFsaWQgaGFzaCBtZXRhZGF0YSByYW5nZXMgb3IgdmFsdWVzLiB7QGxpbmsgUmFuZ2VFcnJvcn1cbiAqIEB0aHJvd3MgSWYgdGhlIGhhc2ggbWV0YWRhdGEgYWxsb3dzIGVtcHR5IG91dHB1dHMgb3IgYmxvY2sgc2l6ZXMuIHtAbGluayBFcnJvcn1cbiAqIEBleGFtcGxlXG4gKiBWYWxpZGF0ZSBhIGNhbGxhYmxlIGhhc2ggd3JhcHBlci5cbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBhaGFzaCB9IGZyb20gJ0Bub2JsZS9oYXNoZXMvdXRpbHMuanMnO1xuICogaW1wb3J0IHsgc2hhMjU2IH0gZnJvbSAnQG5vYmxlL2hhc2hlcy9zaGEyLmpzJztcbiAqIGFoYXNoKHNoYTI1Nik7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGFoYXNoKGgpIHtcbiAgICBpZiAodHlwZW9mIGggIT09ICdmdW5jdGlvbicgfHwgdHlwZW9mIGguY3JlYXRlICE9PSAnZnVuY3Rpb24nKVxuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdIYXNoIG11c3Qgd3JhcHBlZCBieSB1dGlscy5jcmVhdGVIYXNoZXInKTtcbiAgICBhbnVtYmVyKGgub3V0cHV0TGVuKTtcbiAgICBhbnVtYmVyKGguYmxvY2tMZW4pO1xuICAgIC8vIEhNQUMgYW5kIEtERiBjYWxsZXJzIHRyZWF0IHRoZXNlIGFzIHJlYWwgYnl0ZSBsZW5ndGhzOyBhbGxvd2luZyB6ZXJvIGxldHMgZmFrZSB3cmFwcGVycyBwYXNzXG4gICAgLy8gdmFsaWRhdGlvbiBhbmQgY2FuIHByb2R1Y2UgZW1wdHkgb3V0cHV0cyBpbnN0ZWFkIG9mIGZhaWxpbmcgZmFzdC5cbiAgICBpZiAoaC5vdXRwdXRMZW4gPCAxKVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1wib3V0cHV0TGVuXCIgbXVzdCBiZSA+PSAxJyk7XG4gICAgaWYgKGguYmxvY2tMZW4gPCAxKVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1wiYmxvY2tMZW5cIiBtdXN0IGJlID49IDEnKTtcbn1cbi8qKlxuICogQXNzZXJ0cyBhIGhhc2ggaW5zdGFuY2UgaGFzIG5vdCBiZWVuIGRlc3Ryb3llZCBvciBmaW5pc2hlZC5cbiAqIEBwYXJhbSBpbnN0YW5jZSAtIGhhc2ggaW5zdGFuY2UgdG8gdmFsaWRhdGVcbiAqIEBwYXJhbSBjaGVja0ZpbmlzaGVkIC0gd2hldGhlciB0byByZWplY3QgZmluYWxpemVkIGluc3RhbmNlc1xuICogQHRocm93cyBJZiB0aGUgaGFzaCBpbnN0YW5jZSBoYXMgYWxyZWFkeSBiZWVuIGRlc3Ryb3llZCBvciBmaW5hbGl6ZWQuIHtAbGluayBFcnJvcn1cbiAqIEBleGFtcGxlXG4gKiBWYWxpZGF0ZSB0aGF0IGEgaGFzaCBpbnN0YW5jZSBpcyBzdGlsbCB1c2FibGUuXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgYWV4aXN0cyB9IGZyb20gJ0Bub2JsZS9oYXNoZXMvdXRpbHMuanMnO1xuICogaW1wb3J0IHsgc2hhMjU2IH0gZnJvbSAnQG5vYmxlL2hhc2hlcy9zaGEyLmpzJztcbiAqIGNvbnN0IGhhc2ggPSBzaGEyNTYuY3JlYXRlKCk7XG4gKiBhZXhpc3RzKGhhc2gpO1xuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhZXhpc3RzKGluc3RhbmNlLCBjaGVja0ZpbmlzaGVkID0gdHJ1ZSkge1xuICAgIGlmIChpbnN0YW5jZS5kZXN0cm95ZWQpXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignSGFzaCBpbnN0YW5jZSBoYXMgYmVlbiBkZXN0cm95ZWQnKTtcbiAgICBpZiAoY2hlY2tGaW5pc2hlZCAmJiBpbnN0YW5jZS5maW5pc2hlZClcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdIYXNoI2RpZ2VzdCgpIGhhcyBhbHJlYWR5IGJlZW4gY2FsbGVkJyk7XG59XG4vKipcbiAqIEFzc2VydHMgb3V0cHV0IGlzIGEgc3VmZmljaWVudGx5LXNpemVkIGJ5dGUgYXJyYXkuXG4gKiBAcGFyYW0gb3V0IC0gZGVzdGluYXRpb24gYnVmZmVyXG4gKiBAcGFyYW0gaW5zdGFuY2UgLSBoYXNoIGluc3RhbmNlIHByb3ZpZGluZyBvdXRwdXQgbGVuZ3RoXG4gKiBPdmVyc2l6ZWQgYnVmZmVycyBhcmUgYWxsb3dlZDsgZG93bnN0cmVhbSBjb2RlIG9ubHkgcHJvbWlzZXMgdG8gZmlsbCB0aGUgZmlyc3QgYG91dHB1dExlbmAgYnl0ZXMuXG4gKiBAdGhyb3dzIE9uIHdyb25nIGFyZ3VtZW50IHR5cGVzLiB7QGxpbmsgVHlwZUVycm9yfVxuICogQHRocm93cyBPbiB3cm9uZyBhcmd1bWVudCByYW5nZXMgb3IgdmFsdWVzLiB7QGxpbmsgUmFuZ2VFcnJvcn1cbiAqIEBleGFtcGxlXG4gKiBWYWxpZGF0ZSBhIGNhbGxlci1wcm92aWRlZCBkaWdlc3QgYnVmZmVyLlxuICogYGBgdHNcbiAqIGltcG9ydCB7IGFvdXRwdXQgfSBmcm9tICdAbm9ibGUvaGFzaGVzL3V0aWxzLmpzJztcbiAqIGltcG9ydCB7IHNoYTI1NiB9IGZyb20gJ0Bub2JsZS9oYXNoZXMvc2hhMi5qcyc7XG4gKiBjb25zdCBoYXNoID0gc2hhMjU2LmNyZWF0ZSgpO1xuICogYW91dHB1dChuZXcgVWludDhBcnJheShoYXNoLm91dHB1dExlbiksIGhhc2gpO1xuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhb3V0cHV0KG91dCwgaW5zdGFuY2UpIHtcbiAgICBhYnl0ZXMob3V0LCB1bmRlZmluZWQsICdkaWdlc3RJbnRvKCkgb3V0cHV0Jyk7XG4gICAgY29uc3QgbWluID0gaW5zdGFuY2Uub3V0cHV0TGVuO1xuICAgIGlmIChvdXQubGVuZ3RoIDwgbWluKSB7XG4gICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdcImRpZ2VzdEludG8oKSBvdXRwdXRcIiBleHBlY3RlZCB0byBiZSBvZiBsZW5ndGggPj0nICsgbWluKTtcbiAgICB9XG59XG4vKipcbiAqIENhc3RzIGEgdHlwZWQgYXJyYXkgdmlldyB0byBVaW50OEFycmF5LlxuICogQHBhcmFtIGFyciAtIHNvdXJjZSB0eXBlZCBhcnJheVxuICogQHJldHVybnMgVWludDhBcnJheSB2aWV3IG92ZXIgdGhlIHNhbWUgYnVmZmVyLlxuICogQGV4YW1wbGVcbiAqIFJlaW50ZXJwcmV0IGEgdHlwZWQgYXJyYXkgYXMgYnl0ZXMuXG4gKiBgYGB0c1xuICogdTgobmV3IFVpbnQzMkFycmF5KFsxLCAyXSkpO1xuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1OChhcnIpIHtcbiAgICByZXR1cm4gbmV3IFVpbnQ4QXJyYXkoYXJyLmJ1ZmZlciwgYXJyLmJ5dGVPZmZzZXQsIGFyci5ieXRlTGVuZ3RoKTtcbn1cbi8qKlxuICogQ2FzdHMgYSB0eXBlZCBhcnJheSB2aWV3IHRvIFVpbnQzMkFycmF5LlxuICogYGFyci5ieXRlT2Zmc2V0YCBtdXN0IGFscmVhZHkgYmUgNC1ieXRlIGFsaWduZWQgb3IgdGhlIHBsYXRmb3JtXG4gKiBVaW50MzJBcnJheSBjb25zdHJ1Y3RvciB3aWxsIHRocm93LlxuICogQHBhcmFtIGFyciAtIHNvdXJjZSB0eXBlZCBhcnJheVxuICogQHJldHVybnMgVWludDMyQXJyYXkgdmlldyBvdmVyIHRoZSBzYW1lIGJ1ZmZlci5cbiAqIEBleGFtcGxlXG4gKiBSZWludGVycHJldCBhIGJ5dGUgYXJyYXkgYXMgMzItYml0IHdvcmRzLlxuICogYGBgdHNcbiAqIHUzMihuZXcgVWludDhBcnJheSg4KSk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHUzMihhcnIpIHtcbiAgICByZXR1cm4gbmV3IFVpbnQzMkFycmF5KGFyci5idWZmZXIsIGFyci5ieXRlT2Zmc2V0LCBNYXRoLmZsb29yKGFyci5ieXRlTGVuZ3RoIC8gNCkpO1xufVxuLyoqXG4gKiBaZXJvaXplcyB0eXBlZCBhcnJheXMgaW4gcGxhY2UuIFdhcm5pbmc6IEpTIHByb3ZpZGVzIG5vIGd1YXJhbnRlZXMuXG4gKiBAcGFyYW0gYXJyYXlzIC0gYXJyYXlzIHRvIG92ZXJ3cml0ZSB3aXRoIHplcm9zXG4gKiBAZXhhbXBsZVxuICogWmVyb2l6ZSBzZW5zaXRpdmUgYnVmZmVycyBpbiBwbGFjZS5cbiAqIGBgYHRzXG4gKiBjbGVhbihuZXcgVWludDhBcnJheShbMSwgMiwgM10pKTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gY2xlYW4oLi4uYXJyYXlzKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBhcnJheXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgYXJyYXlzW2ldLmZpbGwoMCk7XG4gICAgfVxufVxuLyoqXG4gKiBDcmVhdGVzIGEgRGF0YVZpZXcgZm9yIGJ5dGUtbGV2ZWwgbWFuaXB1bGF0aW9uLlxuICogQHBhcmFtIGFyciAtIHNvdXJjZSB0eXBlZCBhcnJheVxuICogQHJldHVybnMgRGF0YVZpZXcgb3ZlciB0aGUgc2FtZSBidWZmZXIgcmVnaW9uLlxuICogQGV4YW1wbGVcbiAqIENyZWF0ZSBhIERhdGFWaWV3IG92ZXIgYW4gZXhpc3RpbmcgYnVmZmVyLlxuICogYGBgdHNcbiAqIGNyZWF0ZVZpZXcobmV3IFVpbnQ4QXJyYXkoNCkpO1xuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVWaWV3KGFycikge1xuICAgIHJldHVybiBuZXcgRGF0YVZpZXcoYXJyLmJ1ZmZlciwgYXJyLmJ5dGVPZmZzZXQsIGFyci5ieXRlTGVuZ3RoKTtcbn1cbi8qKlxuICogUm90YXRlLXJpZ2h0IG9wZXJhdGlvbiBmb3IgdWludDMyIHZhbHVlcy5cbiAqIEBwYXJhbSB3b3JkIC0gc291cmNlIHdvcmRcbiAqIEBwYXJhbSBzaGlmdCAtIHNoaWZ0IGFtb3VudCBpbiBiaXRzXG4gKiBAcmV0dXJucyBSb3RhdGVkIHdvcmQuXG4gKiBAZXhhbXBsZVxuICogUm90YXRlIGEgMzItYml0IHdvcmQgdG8gdGhlIHJpZ2h0LlxuICogYGBgdHNcbiAqIHJvdHIoMHgxMjM0NTY3OCwgOCk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJvdHIod29yZCwgc2hpZnQpIHtcbiAgICByZXR1cm4gKHdvcmQgPDwgKDMyIC0gc2hpZnQpKSB8ICh3b3JkID4+PiBzaGlmdCk7XG59XG4vKipcbiAqIFJvdGF0ZS1sZWZ0IG9wZXJhdGlvbiBmb3IgdWludDMyIHZhbHVlcy5cbiAqIEBwYXJhbSB3b3JkIC0gc291cmNlIHdvcmRcbiAqIEBwYXJhbSBzaGlmdCAtIHNoaWZ0IGFtb3VudCBpbiBiaXRzXG4gKiBAcmV0dXJucyBSb3RhdGVkIHdvcmQuXG4gKiBAZXhhbXBsZVxuICogUm90YXRlIGEgMzItYml0IHdvcmQgdG8gdGhlIGxlZnQuXG4gKiBgYGB0c1xuICogcm90bCgweDEyMzQ1Njc4LCA4KTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gcm90bCh3b3JkLCBzaGlmdCkge1xuICAgIHJldHVybiAod29yZCA8PCBzaGlmdCkgfCAoKHdvcmQgPj4+ICgzMiAtIHNoaWZ0KSkgPj4+IDApO1xufVxuLyoqIFdoZXRoZXIgdGhlIGN1cnJlbnQgcGxhdGZvcm0gaXMgbGl0dGxlLWVuZGlhbi4gKi9cbmV4cG9ydCBjb25zdCBpc0xFID0gLyogQF9fUFVSRV9fICovICgoKSA9PiBuZXcgVWludDhBcnJheShuZXcgVWludDMyQXJyYXkoWzB4MTEyMjMzNDRdKS5idWZmZXIpWzBdID09PSAweDQ0KSgpO1xuLyoqXG4gKiBCeXRlLXN3YXAgb3BlcmF0aW9uIGZvciB1aW50MzIgdmFsdWVzLlxuICogQHBhcmFtIHdvcmQgLSBzb3VyY2Ugd29yZFxuICogQHJldHVybnMgV29yZCB3aXRoIHJldmVyc2VkIGJ5dGUgb3JkZXIuXG4gKiBAZXhhbXBsZVxuICogUmV2ZXJzZSB0aGUgYnl0ZSBvcmRlciBvZiBhIDMyLWJpdCB3b3JkLlxuICogYGBgdHNcbiAqIGJ5dGVTd2FwKDB4MTEyMjMzNDQpO1xuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBieXRlU3dhcCh3b3JkKSB7XG4gICAgcmV0dXJuICgoKHdvcmQgPDwgMjQpICYgMHhmZjAwMDAwMCkgfFxuICAgICAgICAoKHdvcmQgPDwgOCkgJiAweGZmMDAwMCkgfFxuICAgICAgICAoKHdvcmQgPj4+IDgpICYgMHhmZjAwKSB8XG4gICAgICAgICgod29yZCA+Pj4gMjQpICYgMHhmZikpO1xufVxuLyoqXG4gKiBDb25kaXRpb25hbGx5IGJ5dGUtc3dhcHMgb25lIDMyLWJpdCB3b3JkIG9uIGJpZy1lbmRpYW4gcGxhdGZvcm1zLlxuICogQHBhcmFtIG4gLSBzb3VyY2Ugd29yZFxuICogQHJldHVybnMgT3JpZ2luYWwgb3IgYnl0ZS1zd2FwcGVkIHdvcmQgZGVwZW5kaW5nIG9uIHBsYXRmb3JtIGVuZGlhbm5lc3MuXG4gKiBAZXhhbXBsZVxuICogTm9ybWFsaXplIGEgMzItYml0IHdvcmQgZm9yIGhvc3QgZW5kaWFubmVzcy5cbiAqIGBgYHRzXG4gKiBzd2FwOElmQkUoMHgxMTIyMzM0NCk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGNvbnN0IHN3YXA4SWZCRSA9IGlzTEVcbiAgICA/IChuKSA9PiBuXG4gICAgOiAobikgPT4gYnl0ZVN3YXAobikgPj4+IDA7XG4vKipcbiAqIEJ5dGUtc3dhcHMgZXZlcnkgd29yZCBvZiBhIFVpbnQzMkFycmF5IGluIHBsYWNlLlxuICogQHBhcmFtIGFyciAtIGFycmF5IHRvIG11dGF0ZVxuICogQHJldHVybnMgVGhlIHNhbWUgYXJyYXkgYWZ0ZXIgbXV0YXRpb247IGNhbGxlcnMgcGFzcyBsaXZlIHN0YXRlIGFycmF5cyBoZXJlLlxuICogQGV4YW1wbGVcbiAqIFJldmVyc2UgdGhlIGJ5dGUgb3JkZXIgb2YgZXZlcnkgd29yZCBpbiBwbGFjZS5cbiAqIGBgYHRzXG4gKiBieXRlU3dhcDMyKG5ldyBVaW50MzJBcnJheShbMHgxMTIyMzM0NF0pKTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gYnl0ZVN3YXAzMihhcnIpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGFyci5sZW5ndGg7IGkrKykge1xuICAgICAgICBhcnJbaV0gPSBieXRlU3dhcChhcnJbaV0pO1xuICAgIH1cbiAgICByZXR1cm4gYXJyO1xufVxuLyoqXG4gKiBDb25kaXRpb25hbGx5IGJ5dGUtc3dhcHMgYSBVaW50MzJBcnJheSBvbiBiaWctZW5kaWFuIHBsYXRmb3Jtcy5cbiAqIEBwYXJhbSB1IC0gYXJyYXkgdG8gbm9ybWFsaXplIGZvciBob3N0IGVuZGlhbm5lc3NcbiAqIEByZXR1cm5zIE9yaWdpbmFsIG9yIGJ5dGUtc3dhcHBlZCBhcnJheSBkZXBlbmRpbmcgb24gcGxhdGZvcm0gZW5kaWFubmVzcy5cbiAqICAgT24gYmlnLWVuZGlhbiBydW50aW1lcyB0aGlzIG11dGF0ZXMgYHVgIGluIHBsYWNlIHZpYSBgYnl0ZVN3YXAzMiguLi4pYC5cbiAqIEBleGFtcGxlXG4gKiBOb3JtYWxpemUgYSB3b3JkIGFycmF5IGZvciBob3N0IGVuZGlhbm5lc3MuXG4gKiBgYGB0c1xuICogc3dhcDMySWZCRShuZXcgVWludDMyQXJyYXkoWzB4MTEyMjMzNDRdKSk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGNvbnN0IHN3YXAzMklmQkUgPSBpc0xFXG4gICAgPyAodSkgPT4gdVxuICAgIDogYnl0ZVN3YXAzMjtcbi8vIEJ1aWx0LWluIGhleCBjb252ZXJzaW9uIGh0dHBzOi8vY2FuaXVzZS5jb20vbWRuLWphdmFzY3JpcHRfYnVpbHRpbnNfdWludDhhcnJheV9mcm9taGV4XG5jb25zdCBoYXNIZXhCdWlsdGluID0gLyogQF9fUFVSRV9fICovICgoKSA9PiBcbi8vIEB0cy1pZ25vcmVcbnR5cGVvZiBVaW50OEFycmF5LmZyb20oW10pLnRvSGV4ID09PSAnZnVuY3Rpb24nICYmIHR5cGVvZiBVaW50OEFycmF5LmZyb21IZXggPT09ICdmdW5jdGlvbicpKCk7XG4vLyBBcnJheSB3aGVyZSBpbmRleCAweGYwICgyNDApIGlzIG1hcHBlZCB0byBzdHJpbmcgJ2YwJ1xuY29uc3QgaGV4ZXMgPSAvKiBAX19QVVJFX18gKi8gQXJyYXkuZnJvbSh7IGxlbmd0aDogMjU2IH0sIChfLCBpKSA9PiBpLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCAnMCcpKTtcbi8qKlxuICogQ29udmVydCBieXRlIGFycmF5IHRvIGhleCBzdHJpbmcuXG4gKiBVc2VzIHRoZSBidWlsdC1pbiBmdW5jdGlvbiB3aGVuIGF2YWlsYWJsZSBhbmQgYXNzdW1lcyBpdCBtYXRjaGVzIHRoZSB0ZXN0ZWRcbiAqIGZhbGxiYWNrIHNlbWFudGljcy5cbiAqIEBwYXJhbSBieXRlcyAtIGJ5dGVzIHRvIGVuY29kZVxuICogQHJldHVybnMgTG93ZXJjYXNlIGhleGFkZWNpbWFsIHN0cmluZy5cbiAqIEB0aHJvd3MgT24gd3JvbmcgYXJndW1lbnQgdHlwZXMuIHtAbGluayBUeXBlRXJyb3J9XG4gKiBAZXhhbXBsZVxuICogQ29udmVydCBieXRlcyB0byBsb3dlcmNhc2UgaGV4YWRlY2ltYWwuXG4gKiBgYGB0c1xuICogYnl0ZXNUb0hleChVaW50OEFycmF5LmZyb20oWzB4Y2EsIDB4ZmUsIDB4MDEsIDB4MjNdKSk7IC8vICdjYWZlMDEyMydcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gYnl0ZXNUb0hleChieXRlcykge1xuICAgIGFieXRlcyhieXRlcyk7XG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIGlmIChoYXNIZXhCdWlsdGluKVxuICAgICAgICByZXR1cm4gYnl0ZXMudG9IZXgoKTtcbiAgICAvLyBwcmUtY2FjaGluZyBpbXByb3ZlcyB0aGUgc3BlZWQgNnhcbiAgICBsZXQgaGV4ID0gJyc7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBieXRlcy5sZW5ndGg7IGkrKykge1xuICAgICAgICBoZXggKz0gaGV4ZXNbYnl0ZXNbaV1dO1xuICAgIH1cbiAgICByZXR1cm4gaGV4O1xufVxuLy8gV2UgdXNlIG9wdGltaXplZCB0ZWNobmlxdWUgdG8gY29udmVydCBoZXggc3RyaW5nIHRvIGJ5dGUgYXJyYXlcbmNvbnN0IGFzY2lpcyA9IHsgXzA6IDQ4LCBfOTogNTcsIEE6IDY1LCBGOiA3MCwgYTogOTcsIGY6IDEwMiB9O1xuZnVuY3Rpb24gYXNjaWlUb0Jhc2UxNihjaCkge1xuICAgIGlmIChjaCA+PSBhc2NpaXMuXzAgJiYgY2ggPD0gYXNjaWlzLl85KVxuICAgICAgICByZXR1cm4gY2ggLSBhc2NpaXMuXzA7IC8vICcyJyA9PiA1MC00OFxuICAgIGlmIChjaCA+PSBhc2NpaXMuQSAmJiBjaCA8PSBhc2NpaXMuRilcbiAgICAgICAgcmV0dXJuIGNoIC0gKGFzY2lpcy5BIC0gMTApOyAvLyAnQicgPT4gNjYtKDY1LTEwKVxuICAgIGlmIChjaCA+PSBhc2NpaXMuYSAmJiBjaCA8PSBhc2NpaXMuZilcbiAgICAgICAgcmV0dXJuIGNoIC0gKGFzY2lpcy5hIC0gMTApOyAvLyAnYicgPT4gOTgtKDk3LTEwKVxuICAgIHJldHVybjtcbn1cbi8qKlxuICogQ29udmVydCBoZXggc3RyaW5nIHRvIGJ5dGUgYXJyYXkuIFVzZXMgYnVpbHQtaW4gZnVuY3Rpb24sIHdoZW4gYXZhaWxhYmxlLlxuICogQHBhcmFtIGhleCAtIGhleGFkZWNpbWFsIHN0cmluZyB0byBkZWNvZGVcbiAqIEByZXR1cm5zIERlY29kZWQgYnl0ZXMuXG4gKiBAdGhyb3dzIE9uIHdyb25nIGFyZ3VtZW50IHR5cGVzLiB7QGxpbmsgVHlwZUVycm9yfVxuICogQHRocm93cyBPbiB3cm9uZyBhcmd1bWVudCByYW5nZXMgb3IgdmFsdWVzLiB7QGxpbmsgUmFuZ2VFcnJvcn1cbiAqIEBleGFtcGxlXG4gKiBEZWNvZGUgbG93ZXJjYXNlIGhleGFkZWNpbWFsIGludG8gYnl0ZXMuXG4gKiBgYGB0c1xuICogaGV4VG9CeXRlcygnY2FmZTAxMjMnKTsgLy8gVWludDhBcnJheS5mcm9tKFsweGNhLCAweGZlLCAweDAxLCAweDIzXSlcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gaGV4VG9CeXRlcyhoZXgpIHtcbiAgICBpZiAodHlwZW9mIGhleCAhPT0gJ3N0cmluZycpXG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ2hleCBzdHJpbmcgZXhwZWN0ZWQsIGdvdCAnICsgdHlwZW9mIGhleCk7XG4gICAgaWYgKGhhc0hleEJ1aWx0aW4pIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJldHVybiBVaW50OEFycmF5LmZyb21IZXgoaGV4KTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIFN5bnRheEVycm9yKVxuICAgICAgICAgICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKGVycm9yLm1lc3NhZ2UpO1xuICAgICAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgaGwgPSBoZXgubGVuZ3RoO1xuICAgIGNvbnN0IGFsID0gaGwgLyAyO1xuICAgIGlmIChobCAlIDIpXG4gICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdoZXggc3RyaW5nIGV4cGVjdGVkLCBnb3QgdW5wYWRkZWQgaGV4IG9mIGxlbmd0aCAnICsgaGwpO1xuICAgIGNvbnN0IGFycmF5ID0gbmV3IFVpbnQ4QXJyYXkoYWwpO1xuICAgIGZvciAobGV0IGFpID0gMCwgaGkgPSAwOyBhaSA8IGFsOyBhaSsrLCBoaSArPSAyKSB7XG4gICAgICAgIGNvbnN0IG4xID0gYXNjaWlUb0Jhc2UxNihoZXguY2hhckNvZGVBdChoaSkpO1xuICAgICAgICBjb25zdCBuMiA9IGFzY2lpVG9CYXNlMTYoaGV4LmNoYXJDb2RlQXQoaGkgKyAxKSk7XG4gICAgICAgIGlmIChuMSA9PT0gdW5kZWZpbmVkIHx8IG4yID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGNvbnN0IGNoYXIgPSBoZXhbaGldICsgaGV4W2hpICsgMV07XG4gICAgICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcignaGV4IHN0cmluZyBleHBlY3RlZCwgZ290IG5vbi1oZXggY2hhcmFjdGVyIFwiJyArIGNoYXIgKyAnXCIgYXQgaW5kZXggJyArIGhpKTtcbiAgICAgICAgfVxuICAgICAgICBhcnJheVthaV0gPSBuMSAqIDE2ICsgbjI7IC8vIG11bHRpcGx5IGZpcnN0IG9jdGV0LCBlLmcuICdhMycgPT4gMTAqMTYrMyA9PiAxNjAgKyAzID0+IDE2M1xuICAgIH1cbiAgICByZXR1cm4gYXJyYXk7XG59XG4vKipcbiAqIFRoZXJlIGlzIG5vIHNldEltbWVkaWF0ZSBpbiBicm93c2VyIGFuZCBzZXRUaW1lb3V0IGlzIHNsb3cuXG4gKiBUaGlzIHlpZWxkcyB0byB0aGUgUHJvbWlzZS9taWNyb3Rhc2sgc2NoZWR1bGVyIHF1ZXVlLCBub3QgdG8gdGltZXJzIG9yIHRoZVxuICogZnVsbCBtYWNyb3Rhc2sgZXZlbnQgbG9vcC5cbiAqIEBleGFtcGxlXG4gKiBZaWVsZCB0byB0aGUgbmV4dCBzY2hlZHVsZXIgdGljay5cbiAqIGBgYHRzXG4gKiBhd2FpdCBuZXh0VGljaygpO1xuICogYGBgXG4gKi9cbmV4cG9ydCBjb25zdCBuZXh0VGljayA9IGFzeW5jICgpID0+IHsgfTtcbi8qKlxuICogUmV0dXJucyBjb250cm9sIHRvIHRoZSBQcm9taXNlL21pY3JvdGFzayBzY2hlZHVsZXIgZXZlcnkgYHRpY2tgXG4gKiBtaWxsaXNlY29uZHMgdG8gYXZvaWQgYmxvY2tpbmcgbG9uZyBsb29wcy5cbiAqIEBwYXJhbSBpdGVycyAtIG51bWJlciBvZiBsb29wIGl0ZXJhdGlvbnMgdG8gcnVuXG4gKiBAcGFyYW0gdGljayAtIG1heGltdW0gdGltZSBzbGljZSBpbiBtaWxsaXNlY29uZHNcbiAqIEBwYXJhbSBjYiAtIGNhbGxiYWNrIGV4ZWN1dGVkIG9uIGVhY2ggaXRlcmF0aW9uXG4gKiBAZXhhbXBsZVxuICogUnVuIGEgbG9vcCB0aGF0IHBlcmlvZGljYWxseSB5aWVsZHMgYmFjayB0byB0aGUgZXZlbnQgbG9vcC5cbiAqIGBgYHRzXG4gKiBhd2FpdCBhc3luY0xvb3AoMiwgMCwgKCkgPT4ge30pO1xuICogYGBgXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhc3luY0xvb3AoaXRlcnMsIHRpY2ssIGNiKSB7XG4gICAgbGV0IHRzID0gRGF0ZS5ub3coKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGl0ZXJzOyBpKyspIHtcbiAgICAgICAgY2IoaSk7XG4gICAgICAgIC8vIERhdGUubm93KCkgaXMgbm90IG1vbm90b25pYywgc28gaW4gY2FzZSBpZiBjbG9jayBnb2VzIGJhY2t3YXJkcyB3ZSByZXR1cm4gcmV0dXJuIGNvbnRyb2wgdG9vXG4gICAgICAgIGNvbnN0IGRpZmYgPSBEYXRlLm5vdygpIC0gdHM7XG4gICAgICAgIGlmIChkaWZmID49IDAgJiYgZGlmZiA8IHRpY2spXG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgYXdhaXQgbmV4dFRpY2soKTtcbiAgICAgICAgdHMgKz0gZGlmZjtcbiAgICB9XG59XG4vKipcbiAqIENvbnZlcnRzIHN0cmluZyB0byBieXRlcyB1c2luZyBVVEY4IGVuY29kaW5nLlxuICogQnVpbHQtaW4gZG9lc24ndCB2YWxpZGF0ZSBpbnB1dCB0byBiZSBzdHJpbmc6IHdlIGRvIHRoZSBjaGVjay5cbiAqIE5vbi1BU0NJSSBkZXRhaWxzIGFyZSBkZWxlZ2F0ZWQgdG8gdGhlIHBsYXRmb3JtIGBUZXh0RW5jb2RlcmAuXG4gKiBAcGFyYW0gc3RyIC0gc3RyaW5nIHRvIGVuY29kZVxuICogQHJldHVybnMgVVRGLTggZW5jb2RlZCBieXRlcy5cbiAqIEB0aHJvd3MgT24gd3JvbmcgYXJndW1lbnQgdHlwZXMuIHtAbGluayBUeXBlRXJyb3J9XG4gKiBAZXhhbXBsZVxuICogRW5jb2RlIGEgc3RyaW5nIGFzIFVURi04IGJ5dGVzLlxuICogYGBgdHNcbiAqIHV0ZjhUb0J5dGVzKCdhYmMnKTsgLy8gVWludDhBcnJheS5mcm9tKFs5NywgOTgsIDk5XSlcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gdXRmOFRvQnl0ZXMoc3RyKSB7XG4gICAgaWYgKHR5cGVvZiBzdHIgIT09ICdzdHJpbmcnKVxuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdzdHJpbmcgZXhwZWN0ZWQnKTtcbiAgICByZXR1cm4gbmV3IFVpbnQ4QXJyYXkobmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHN0cikpOyAvLyBodHRwczovL2J1Z3ppbC5sYS8xNjgxODA5XG59XG4vKipcbiAqIEhlbHBlciBmb3IgS0RGczogY29uc3VtZXMgVWludDhBcnJheSBvciBzdHJpbmcuXG4gKiBTdHJpbmcgaW5wdXRzIGFyZSBVVEYtOCBlbmNvZGVkOyBieXRlLWFycmF5IGlucHV0cyBzdGF5IGFsaWFzZWQgdG8gdGhlIGNhbGxlciBidWZmZXIuXG4gKiBAcGFyYW0gZGF0YSAtIHVzZXItcHJvdmlkZWQgS0RGIGlucHV0XG4gKiBAcGFyYW0gZXJyb3JUaXRsZSAtIGxhYmVsIGluY2x1ZGVkIGluIHRocm93biBlcnJvcnNcbiAqIEByZXR1cm5zIEJ5dGUgcmVwcmVzZW50YXRpb24gb2YgdGhlIGlucHV0LlxuICogQHRocm93cyBPbiB3cm9uZyBhcmd1bWVudCB0eXBlcy4ge0BsaW5rIFR5cGVFcnJvcn1cbiAqIEBleGFtcGxlXG4gKiBOb3JtYWxpemUgS0RGIGlucHV0IHRvIGJ5dGVzLlxuICogYGBgdHNcbiAqIGtkZklucHV0VG9CeXRlcygncGFzc3dvcmQnKTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24ga2RmSW5wdXRUb0J5dGVzKGRhdGEsIGVycm9yVGl0bGUgPSAnJykge1xuICAgIGlmICh0eXBlb2YgZGF0YSA9PT0gJ3N0cmluZycpXG4gICAgICAgIHJldHVybiB1dGY4VG9CeXRlcyhkYXRhKTtcbiAgICByZXR1cm4gYWJ5dGVzKGRhdGEsIHVuZGVmaW5lZCwgZXJyb3JUaXRsZSk7XG59XG4vKipcbiAqIENvcGllcyBzZXZlcmFsIFVpbnQ4QXJyYXlzIGludG8gb25lLlxuICogQHBhcmFtIGFycmF5cyAtIGFycmF5cyB0byBjb25jYXRlbmF0ZVxuICogQHJldHVybnMgQ29uY2F0ZW5hdGVkIGJ5dGUgYXJyYXkuXG4gKiBAdGhyb3dzIE9uIHdyb25nIGFyZ3VtZW50IHR5cGVzLiB7QGxpbmsgVHlwZUVycm9yfVxuICogQGV4YW1wbGVcbiAqIENvbmNhdGVuYXRlIG11bHRpcGxlIGJ5dGUgYXJyYXlzLlxuICogYGBgdHNcbiAqIGNvbmNhdEJ5dGVzKG5ldyBVaW50OEFycmF5KFsxXSksIG5ldyBVaW50OEFycmF5KFsyXSkpO1xuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb25jYXRCeXRlcyguLi5hcnJheXMpIHtcbiAgICBsZXQgc3VtID0gMDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGFycmF5cy5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBhID0gYXJyYXlzW2ldO1xuICAgICAgICBhYnl0ZXMoYSk7XG4gICAgICAgIHN1bSArPSBhLmxlbmd0aDtcbiAgICB9XG4gICAgY29uc3QgcmVzID0gbmV3IFVpbnQ4QXJyYXkoc3VtKTtcbiAgICBmb3IgKGxldCBpID0gMCwgcGFkID0gMDsgaSA8IGFycmF5cy5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBhID0gYXJyYXlzW2ldO1xuICAgICAgICByZXMuc2V0KGEsIHBhZCk7XG4gICAgICAgIHBhZCArPSBhLmxlbmd0aDtcbiAgICB9XG4gICAgcmV0dXJuIHJlcztcbn1cbi8qKlxuICogTWVyZ2VzIGRlZmF1bHQgb3B0aW9ucyBhbmQgcGFzc2VkIG9wdGlvbnMuXG4gKiBAcGFyYW0gZGVmYXVsdHMgLSBiYXNlIG9wdGlvbiBvYmplY3RcbiAqIEBwYXJhbSBvcHRzIC0gdXNlciBvdmVycmlkZXNcbiAqIEByZXR1cm5zIE1lcmdlZCBvcHRpb24gb2JqZWN0LiBUaGUgbWVyZ2UgbXV0YXRlcyBgZGVmYXVsdHNgIGluIHBsYWNlLlxuICogQHRocm93cyBPbiB3cm9uZyBhcmd1bWVudCB0eXBlcy4ge0BsaW5rIFR5cGVFcnJvcn1cbiAqIEBleGFtcGxlXG4gKiBNZXJnZSB1c2VyIG92ZXJyaWRlcyBvbnRvIGRlZmF1bHQgb3B0aW9ucy5cbiAqIGBgYHRzXG4gKiBjaGVja09wdHMoeyBka0xlbjogMzIgfSwgeyBhc3luY1RpY2s6IDEwIH0pO1xuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjaGVja09wdHMoZGVmYXVsdHMsIG9wdHMpIHtcbiAgICBpZiAob3B0cyAhPT0gdW5kZWZpbmVkICYmIHt9LnRvU3RyaW5nLmNhbGwob3B0cykgIT09ICdbb2JqZWN0IE9iamVjdF0nKVxuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdvcHRpb25zIG11c3QgYmUgb2JqZWN0IG9yIHVuZGVmaW5lZCcpO1xuICAgIGNvbnN0IG1lcmdlZCA9IE9iamVjdC5hc3NpZ24oZGVmYXVsdHMsIG9wdHMpO1xuICAgIHJldHVybiBtZXJnZWQ7XG59XG4vKipcbiAqIENyZWF0ZXMgYSBjYWxsYWJsZSBoYXNoIGZ1bmN0aW9uIGZyb20gYSBzdGF0ZWZ1bCBjbGFzcyBjb25zdHJ1Y3Rvci5cbiAqIEBwYXJhbSBoYXNoQ29ucyAtIGhhc2ggY29uc3RydWN0b3Igb3IgZmFjdG9yeVxuICogQHBhcmFtIGluZm8gLSBvcHRpb25hbCBtZXRhZGF0YSBzdWNoIGFzIERFUiBPSURcbiAqIEByZXR1cm5zIEZyb3plbiBjYWxsYWJsZSBoYXNoIHdyYXBwZXIgd2l0aCBgLmNyZWF0ZSgpYC5cbiAqICAgV3JhcHBlciBjb25zdHJ1Y3Rpb24gZWFnZXJseSBjYWxscyBgaGFzaENvbnModW5kZWZpbmVkKWAgb25jZSB0byByZWFkXG4gKiAgIGBvdXRwdXRMZW5gIC8gYGJsb2NrTGVuYCwgc28gY29uc3RydWN0b3Igc2lkZSBlZmZlY3RzIGhhcHBlbiBhdCBtb2R1bGVcbiAqICAgaW5pdCB0aW1lLlxuICogQGV4YW1wbGVcbiAqIFdyYXAgYSBzdGF0ZWZ1bCBoYXNoIGNvbnN0cnVjdG9yIGludG8gYSBjYWxsYWJsZSBoZWxwZXIuXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgY3JlYXRlSGFzaGVyIH0gZnJvbSAnQG5vYmxlL2hhc2hlcy91dGlscy5qcyc7XG4gKiBpbXBvcnQgeyBzaGEyNTYgfSBmcm9tICdAbm9ibGUvaGFzaGVzL3NoYTIuanMnO1xuICogY29uc3Qgd3JhcHBlZCA9IGNyZWF0ZUhhc2hlcihzaGEyNTYuY3JlYXRlLCB7IG9pZDogc2hhMjU2Lm9pZCB9KTtcbiAqIHdyYXBwZWQobmV3IFVpbnQ4QXJyYXkoWzFdKSk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUhhc2hlcihoYXNoQ29ucywgaW5mbyA9IHt9KSB7XG4gICAgY29uc3QgaGFzaEMgPSAobXNnLCBvcHRzKSA9PiBoYXNoQ29ucyhvcHRzKVxuICAgICAgICAudXBkYXRlKG1zZylcbiAgICAgICAgLmRpZ2VzdCgpO1xuICAgIGNvbnN0IHRtcCA9IGhhc2hDb25zKHVuZGVmaW5lZCk7XG4gICAgaGFzaEMub3V0cHV0TGVuID0gdG1wLm91dHB1dExlbjtcbiAgICBoYXNoQy5ibG9ja0xlbiA9IHRtcC5ibG9ja0xlbjtcbiAgICBoYXNoQy5jYW5YT0YgPSB0bXAuY2FuWE9GO1xuICAgIGhhc2hDLmNyZWF0ZSA9IChvcHRzKSA9PiBoYXNoQ29ucyhvcHRzKTtcbiAgICBPYmplY3QuYXNzaWduKGhhc2hDLCBpbmZvKTtcbiAgICByZXR1cm4gT2JqZWN0LmZyZWV6ZShoYXNoQyk7XG59XG4vKipcbiAqIENyeXB0b2dyYXBoaWNhbGx5IHNlY3VyZSBQUk5HIGJhY2tlZCBieSBgY3J5cHRvLmdldFJhbmRvbVZhbHVlc2AuXG4gKiBAcGFyYW0gYnl0ZXNMZW5ndGggLSBudW1iZXIgb2YgcmFuZG9tIGJ5dGVzIHRvIGdlbmVyYXRlXG4gKiBAcmV0dXJucyBSYW5kb20gYnl0ZXMuXG4gKiBUaGUgcGxhdGZvcm0gYGdldFJhbmRvbVZhbHVlcygpYCBpbXBsZW1lbnRhdGlvbiBzdGlsbCBkZWZpbmVzIGFueVxuICogc2luZ2xlLWNhbGwgbGVuZ3RoIGNhcCwgYW5kIHRoaXMgaGVscGVyIHJlamVjdHMgb3ZlcnNpemUgcmVxdWVzdHNcbiAqIHdpdGggYSBzdGFibGUgbGlicmFyeSBgUmFuZ2VFcnJvcmAgaW5zdGVhZCBvZiBob3N0LXNwZWNpZmljIGVycm9ycy5cbiAqIEB0aHJvd3MgT24gd3JvbmcgYXJndW1lbnQgdHlwZXMuIHtAbGluayBUeXBlRXJyb3J9XG4gKiBAdGhyb3dzIE9uIHdyb25nIGFyZ3VtZW50IHJhbmdlcyBvciB2YWx1ZXMuIHtAbGluayBSYW5nZUVycm9yfVxuICogQHRocm93cyBJZiB0aGUgY3VycmVudCBydW50aW1lIGRvZXMgbm90IHByb3ZpZGUgYGNyeXB0by5nZXRSYW5kb21WYWx1ZXNgLiB7QGxpbmsgRXJyb3J9XG4gKiBAZXhhbXBsZVxuICogR2VuZXJhdGUgYSBmcmVzaCByYW5kb20ga2V5IG9yIG5vbmNlLlxuICogYGBgdHNcbiAqIGNvbnN0IGtleSA9IHJhbmRvbUJ5dGVzKDE2KTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gcmFuZG9tQnl0ZXMoYnl0ZXNMZW5ndGggPSAzMikge1xuICAgIC8vIE1hdGNoIHRoZSByZXBvJ3Mgb3RoZXIgbGVuZ3RoLXRha2luZyBoZWxwZXJzIGluc3RlYWQgb2YgcmVseWluZyBvbiBVaW50OEFycmF5IGNvZXJjaW9uLlxuICAgIGFudW1iZXIoYnl0ZXNMZW5ndGgsICdieXRlc0xlbmd0aCcpO1xuICAgIGNvbnN0IGNyID0gdHlwZW9mIGdsb2JhbFRoaXMgPT09ICdvYmplY3QnID8gZ2xvYmFsVGhpcy5jcnlwdG8gOiBudWxsO1xuICAgIGlmICh0eXBlb2YgY3I/LmdldFJhbmRvbVZhbHVlcyAhPT0gJ2Z1bmN0aW9uJylcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzIG11c3QgYmUgZGVmaW5lZCcpO1xuICAgIC8vIFdlYiBDcnlwdG9ncmFwaHkgQVBJIExldmVsIDIgwqcxMC4xLjE6XG4gICAgLy8gaWYgYGJ5dGVMZW5ndGggPiA2NTUzNmAsIHRocm93IGBRdW90YUV4Y2VlZGVkRXJyb3JgLlxuICAgIC8vIEtlZXAgdGhlIGd1YXJkIGV4cGxpY2l0IHNvIGNhbGxlcnMgY2FuIHNlZSB0aGUgcXVvdGEgaW4gY29kZVxuICAgIC8vIGluc3RlYWQgb2YgZGlzY292ZXJpbmcgaXQgYnkgcmVhZGluZyB0aGUgc3BlYyBvciBob3N0IGVycm9ycy5cbiAgICAvLyBUaGlzIHdyYXBwZXIgc3VyZmFjZXMgdGhlIHNhbWUgcXVvdGEgYXMgYSBzdGFibGUgbGlicmFyeSBSYW5nZUVycm9yLlxuICAgIGlmIChieXRlc0xlbmd0aCA+IDY1NTM2KVxuICAgICAgICB0aHJvdyBuZXcgUmFuZ2VFcnJvcihgXCJieXRlc0xlbmd0aFwiIGV4cGVjdGVkIDw9IDY1NTM2LCBnb3QgJHtieXRlc0xlbmd0aH1gKTtcbiAgICByZXR1cm4gY3IuZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KGJ5dGVzTGVuZ3RoKSk7XG59XG4vKipcbiAqIENyZWF0ZXMgT0lEIG1ldGFkYXRhIGZvciBOSVNUIGhhc2hlcyB3aXRoIHByZWZpeCBgMDYgMDkgNjAgODYgNDggMDEgNjUgMDMgMDQgMDJgLlxuICogQHBhcmFtIHN1ZmZpeCAtIGZpbmFsIE9JRCBieXRlIGZvciB0aGUgc2VsZWN0ZWQgaGFzaC5cbiAqICAgVGhlIGhlbHBlciBhY2NlcHRzIGFueSBieXRlIGV2ZW4gdGhvdWdoIG9ubHkgdGhlIGRvY3VtZW50ZWQgTklTVCBoYXNoXG4gKiAgIHN1ZmZpeGVzIGFyZSBtZWFuaW5nZnVsIGRvd25zdHJlYW0uXG4gKiBAcmV0dXJucyBPYmplY3QgY29udGFpbmluZyB0aGUgREVSLWVuY29kZWQgT0lELlxuICogQGV4YW1wbGVcbiAqIEJ1aWxkIE9JRCBtZXRhZGF0YSBmb3IgYSBOSVNUIGhhc2guXG4gKiBgYGB0c1xuICogb2lkTmlzdCgweDAxKTtcbiAqIGBgYFxuICovXG5leHBvcnQgY29uc3Qgb2lkTmlzdCA9IChzdWZmaXgpID0+ICh7XG4gICAgLy8gQ3VycmVudCBOSVNUIGhhc2hBbGdzIHN1ZmZpeGVzIHVzZWQgaGVyZSBmaXQgaW4gb25lIERFUiBzdWJpZGVudGlmaWVyIG9jdGV0LlxuICAgIC8vIExhcmdlciBzdWZmaXggdmFsdWVzIHdvdWxkIG5lZWQgYmFzZS0xMjggT0lEIGVuY29kaW5nIGFuZCBhIGRpZmZlcmVudCBsZW5ndGggYnl0ZS5cbiAgICBvaWQ6IFVpbnQ4QXJyYXkuZnJvbShbMHgwNiwgMHgwOSwgMHg2MCwgMHg4NiwgMHg0OCwgMHgwMSwgMHg2NSwgMHgwMywgMHgwNCwgMHgwMiwgc3VmZml4XSksXG59KTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXV0aWxzLmpzLm1hcCIsIi8qKlxuICogSW50ZXJuYWwgTWVya2xlLURhbWdhcmQgaGFzaCB1dGlscy5cbiAqIEBtb2R1bGVcbiAqL1xuaW1wb3J0IHsgYWJ5dGVzLCBhZXhpc3RzLCBhb3V0cHV0LCBjbGVhbiwgY3JlYXRlVmlldywgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuLyoqXG4gKiBTaGFyZWQgMzItYml0IGNvbmRpdGlvbmFsIGJvb2xlYW4gcHJpbWl0aXZlIHJldXNlZCBieSBTSEEtMjU2LCBTSEEtMSwgYW5kIE1ENSBgRmAuXG4gKiBSZXR1cm5zIGJpdHMgZnJvbSBgYmAgd2hlbiBgYWAgaXMgc2V0LCBvdGhlcndpc2UgZnJvbSBgY2AuXG4gKiBUaGUgWE9SIGZvcm0gaXMgZXF1aXZhbGVudCB0byBNRDUncyBgRihYLFksWikgPSBYWSB2IG5vdChYKVpgIGJlY2F1c2UgdGhlIG1hc2tlZCB0ZXJtcyBuZXZlclxuICogc2V0IHRoZSBzYW1lIGJpdC5cbiAqIEBwYXJhbSBhIC0gc2VsZWN0b3Igd29yZFxuICogQHBhcmFtIGIgLSB3b3JkIGNob3NlbiB3aGVuIHNlbGVjdG9yIGJpdCBpcyBzZXRcbiAqIEBwYXJhbSBjIC0gd29yZCBjaG9zZW4gd2hlbiBzZWxlY3RvciBiaXQgaXMgY2xlYXJcbiAqIEByZXR1cm5zIE1peGVkIDMyLWJpdCB3b3JkLlxuICogQGV4YW1wbGVcbiAqIENvbWJpbmUgdGhyZWUgd29yZHMgd2l0aCB0aGUgc2hhcmVkIDMyLWJpdCBjaG9pY2UgcHJpbWl0aXZlLlxuICogYGBgdHNcbiAqIENoaSgweGZmZmZmZmZmLCAweDEyMzQ1Njc4LCAweDg3NjU0MzIxKTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gQ2hpKGEsIGIsIGMpIHtcbiAgICByZXR1cm4gKGEgJiBiKSBeICh+YSAmIGMpO1xufVxuLyoqXG4gKiBTaGFyZWQgMzItYml0IG1ham9yaXR5IHByaW1pdGl2ZSByZXVzZWQgYnkgU0hBLTI1NiBhbmQgU0hBLTEuXG4gKiBSZXR1cm5zIGJpdHMgc2hhcmVkIGJ5IGF0IGxlYXN0IHR3byBpbnB1dHMuXG4gKiBAcGFyYW0gYSAtIGZpcnN0IGlucHV0IHdvcmRcbiAqIEBwYXJhbSBiIC0gc2Vjb25kIGlucHV0IHdvcmRcbiAqIEBwYXJhbSBjIC0gdGhpcmQgaW5wdXQgd29yZFxuICogQHJldHVybnMgTWl4ZWQgMzItYml0IHdvcmQuXG4gKiBAZXhhbXBsZVxuICogQ29tYmluZSB0aHJlZSB3b3JkcyB3aXRoIHRoZSBzaGFyZWQgMzItYml0IG1ham9yaXR5IHByaW1pdGl2ZS5cbiAqIGBgYHRzXG4gKiBNYWooMHhmZmZmZmZmZiwgMHgxMjM0NTY3OCwgMHg4NzY1NDMyMSk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIE1haihhLCBiLCBjKSB7XG4gICAgcmV0dXJuIChhICYgYikgXiAoYSAmIGMpIF4gKGIgJiBjKTtcbn1cbi8qKlxuICogTWVya2xlLURhbWdhcmQgaGFzaCBjb25zdHJ1Y3Rpb24gYmFzZSBjbGFzcy5cbiAqIENvdWxkIGJlIHVzZWQgdG8gY3JlYXRlIE1ENSwgUklQRU1ELCBTSEExLCBTSEEyLlxuICogQWNjZXB0cyBvbmx5IGJ5dGUtYWxpZ25lZCBgVWludDhBcnJheWAgaW5wdXQsIGV2ZW4gd2hlbiB0aGUgdW5kZXJseWluZyBzcGVjIGRlc2NyaWJlcyBiaXRcbiAqIHN0cmluZ3Mgd2l0aCBwYXJ0aWFsLWJ5dGUgdGFpbHMuXG4gKiBAcGFyYW0gYmxvY2tMZW4gLSBpbnRlcm5hbCBibG9jayBzaXplIGluIGJ5dGVzXG4gKiBAcGFyYW0gb3V0cHV0TGVuIC0gZGlnZXN0IHNpemUgaW4gYnl0ZXNcbiAqIEBwYXJhbSBwYWRPZmZzZXQgLSB0cmFpbGluZyBsZW5ndGggZmllbGQgc2l6ZSBpbiBieXRlc1xuICogQHBhcmFtIGlzTEUgLSB3aGV0aGVyIGxlbmd0aCBhbmQgc3RhdGUgd29yZHMgYXJlIGVuY29kZWQgaW4gbGl0dGxlLWVuZGlhblxuICogQGV4YW1wbGVcbiAqIFVzZSBhIGNvbmNyZXRlIHN1YmNsYXNzIHRvIGdldCB0aGUgc2hhcmVkIE1lcmtsZS1EYW1nYXJkIHVwZGF0ZS9kaWdlc3QgZmxvdy5cbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBfU0hBMSB9IGZyb20gJ0Bub2JsZS9oYXNoZXMvbGVnYWN5LmpzJztcbiAqIGNvbnN0IGhhc2ggPSBuZXcgX1NIQTEoKTtcbiAqIGhhc2gudXBkYXRlKG5ldyBVaW50OEFycmF5KFs5NywgOTgsIDk5XSkpO1xuICogaGFzaC5kaWdlc3QoKTtcbiAqIGBgYFxuICovXG5leHBvcnQgY2xhc3MgSGFzaE1EIHtcbiAgICBibG9ja0xlbjtcbiAgICBvdXRwdXRMZW47XG4gICAgY2FuWE9GID0gZmFsc2U7XG4gICAgcGFkT2Zmc2V0O1xuICAgIGlzTEU7XG4gICAgLy8gRm9yIHBhcnRpYWwgdXBkYXRlcyBsZXNzIHRoYW4gYmxvY2sgc2l6ZVxuICAgIGJ1ZmZlcjtcbiAgICB2aWV3O1xuICAgIGZpbmlzaGVkID0gZmFsc2U7XG4gICAgbGVuZ3RoID0gMDtcbiAgICBwb3MgPSAwO1xuICAgIGRlc3Ryb3llZCA9IGZhbHNlO1xuICAgIGNvbnN0cnVjdG9yKGJsb2NrTGVuLCBvdXRwdXRMZW4sIHBhZE9mZnNldCwgaXNMRSkge1xuICAgICAgICB0aGlzLmJsb2NrTGVuID0gYmxvY2tMZW47XG4gICAgICAgIHRoaXMub3V0cHV0TGVuID0gb3V0cHV0TGVuO1xuICAgICAgICB0aGlzLnBhZE9mZnNldCA9IHBhZE9mZnNldDtcbiAgICAgICAgdGhpcy5pc0xFID0gaXNMRTtcbiAgICAgICAgdGhpcy5idWZmZXIgPSBuZXcgVWludDhBcnJheShibG9ja0xlbik7XG4gICAgICAgIHRoaXMudmlldyA9IGNyZWF0ZVZpZXcodGhpcy5idWZmZXIpO1xuICAgIH1cbiAgICB1cGRhdGUoZGF0YSkge1xuICAgICAgICBhZXhpc3RzKHRoaXMpO1xuICAgICAgICBhYnl0ZXMoZGF0YSk7XG4gICAgICAgIGNvbnN0IHsgdmlldywgYnVmZmVyLCBibG9ja0xlbiB9ID0gdGhpcztcbiAgICAgICAgY29uc3QgbGVuID0gZGF0YS5sZW5ndGg7XG4gICAgICAgIGZvciAobGV0IHBvcyA9IDA7IHBvcyA8IGxlbjspIHtcbiAgICAgICAgICAgIGNvbnN0IHRha2UgPSBNYXRoLm1pbihibG9ja0xlbiAtIHRoaXMucG9zLCBsZW4gLSBwb3MpO1xuICAgICAgICAgICAgLy8gRmFzdCBwYXRoIG9ubHkgd2hlbiB0aGVyZSBpcyBubyBidWZmZXJlZCBwYXJ0aWFsIGJsb2NrOiBgdGFrZSA9PT0gYmxvY2tMZW5gIGltcGxpZXNcbiAgICAgICAgICAgIC8vIGB0aGlzLnBvcyA9PT0gMGAsIHNvIHdlIGNhbiBwcm9jZXNzIGZ1bGwgYmxvY2tzIGRpcmVjdGx5IGZyb20gdGhlIGlucHV0IHZpZXcuXG4gICAgICAgICAgICBpZiAodGFrZSA9PT0gYmxvY2tMZW4pIHtcbiAgICAgICAgICAgICAgICBjb25zdCBkYXRhVmlldyA9IGNyZWF0ZVZpZXcoZGF0YSk7XG4gICAgICAgICAgICAgICAgZm9yICg7IGJsb2NrTGVuIDw9IGxlbiAtIHBvczsgcG9zICs9IGJsb2NrTGVuKVxuICAgICAgICAgICAgICAgICAgICB0aGlzLnByb2Nlc3MoZGF0YVZpZXcsIHBvcyk7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBidWZmZXIuc2V0KGRhdGEuc3ViYXJyYXkocG9zLCBwb3MgKyB0YWtlKSwgdGhpcy5wb3MpO1xuICAgICAgICAgICAgdGhpcy5wb3MgKz0gdGFrZTtcbiAgICAgICAgICAgIHBvcyArPSB0YWtlO1xuICAgICAgICAgICAgaWYgKHRoaXMucG9zID09PSBibG9ja0xlbikge1xuICAgICAgICAgICAgICAgIHRoaXMucHJvY2Vzcyh2aWV3LCAwKTtcbiAgICAgICAgICAgICAgICB0aGlzLnBvcyA9IDA7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5sZW5ndGggKz0gZGF0YS5sZW5ndGg7XG4gICAgICAgIHRoaXMucm91bmRDbGVhbigpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgZGlnZXN0SW50byhvdXQpIHtcbiAgICAgICAgYWV4aXN0cyh0aGlzKTtcbiAgICAgICAgYW91dHB1dChvdXQsIHRoaXMpO1xuICAgICAgICB0aGlzLmZpbmlzaGVkID0gdHJ1ZTtcbiAgICAgICAgLy8gUGFkZGluZ1xuICAgICAgICAvLyBXZSBjYW4gYXZvaWQgYWxsb2NhdGlvbiBvZiBidWZmZXIgZm9yIHBhZGRpbmcgY29tcGxldGVseSBpZiBpdFxuICAgICAgICAvLyB3YXMgcHJldmlvdXNseSBub3QgYWxsb2NhdGVkIGhlcmUuIEJ1dCBpdCB3b24ndCBjaGFuZ2UgcGVyZm9ybWFuY2UuXG4gICAgICAgIGNvbnN0IHsgYnVmZmVyLCB2aWV3LCBibG9ja0xlbiwgaXNMRSB9ID0gdGhpcztcbiAgICAgICAgbGV0IHsgcG9zIH0gPSB0aGlzO1xuICAgICAgICAvLyBhcHBlbmQgdGhlIGJpdCAnMScgdG8gdGhlIG1lc3NhZ2VcbiAgICAgICAgYnVmZmVyW3BvcysrXSA9IDBiMTAwMDAwMDA7XG4gICAgICAgIGNsZWFuKHRoaXMuYnVmZmVyLnN1YmFycmF5KHBvcykpO1xuICAgICAgICAvLyB3ZSBoYXZlIGxlc3MgdGhhbiBwYWRPZmZzZXQgbGVmdCBpbiBidWZmZXIsIHNvIHdlIGNhbm5vdCBwdXQgbGVuZ3RoIGluXG4gICAgICAgIC8vIGN1cnJlbnQgYmxvY2ssIG5lZWQgcHJvY2VzcyBpdCBhbmQgcGFkIGFnYWluXG4gICAgICAgIGlmICh0aGlzLnBhZE9mZnNldCA+IGJsb2NrTGVuIC0gcG9zKSB7XG4gICAgICAgICAgICB0aGlzLnByb2Nlc3ModmlldywgMCk7XG4gICAgICAgICAgICBwb3MgPSAwO1xuICAgICAgICB9XG4gICAgICAgIC8vIFBhZCB1bnRpbCBmdWxsIGJsb2NrIGJ5dGUgd2l0aCB6ZXJvc1xuICAgICAgICBmb3IgKGxldCBpID0gcG9zOyBpIDwgYmxvY2tMZW47IGkrKylcbiAgICAgICAgICAgIGJ1ZmZlcltpXSA9IDA7XG4gICAgICAgIC8vIGBwYWRPZmZzZXRgIHJlc2VydmVzIHRoZSB3aG9sZSBsZW5ndGggZmllbGQuIEZvciBTSEEtMzg0LzUxMiB0aGUgaGlnaCA2NCBiaXRzIHN0YXkgemVybyBmcm9tXG4gICAgICAgIC8vIHRoZSBwYWRkaW5nIGZpbGwgYWJvdmUsIGFuZCBKUyB3aWxsIG92ZXJmbG93IGJlZm9yZSB1c2VyIGlucHV0IGNhbiBtYWtlIHRoYXQgaGFsZiBub24temVyby5cbiAgICAgICAgLy8gU28gd2Ugb25seSBuZWVkIHRvIHdyaXRlIHRoZSBsb3cgNjQgYml0cyBoZXJlLlxuICAgICAgICB2aWV3LnNldEJpZ1VpbnQ2NChibG9ja0xlbiAtIDgsIEJpZ0ludCh0aGlzLmxlbmd0aCAqIDgpLCBpc0xFKTtcbiAgICAgICAgdGhpcy5wcm9jZXNzKHZpZXcsIDApO1xuICAgICAgICBjb25zdCBvdmlldyA9IGNyZWF0ZVZpZXcob3V0KTtcbiAgICAgICAgY29uc3QgbGVuID0gdGhpcy5vdXRwdXRMZW47XG4gICAgICAgIC8vIE5PVEU6IHdlIGRvIGRpdmlzaW9uIGJ5IDQgbGF0ZXIsIHdoaWNoIG11c3QgYmUgZnVzZWQgaW4gc2luZ2xlIG9wIHdpdGggbW9kdWxvIGJ5IEpJVFxuICAgICAgICBpZiAobGVuICUgNClcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignX3NoYTI6IG91dHB1dExlbiBtdXN0IGJlIGFsaWduZWQgdG8gMzJiaXQnKTtcbiAgICAgICAgY29uc3Qgb3V0TGVuID0gbGVuIC8gNDtcbiAgICAgICAgY29uc3Qgc3RhdGUgPSB0aGlzLmdldCgpO1xuICAgICAgICBpZiAob3V0TGVuID4gc3RhdGUubGVuZ3RoKVxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdfc2hhMjogb3V0cHV0TGVuIGJpZ2dlciB0aGFuIHN0YXRlJyk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgb3V0TGVuOyBpKyspXG4gICAgICAgICAgICBvdmlldy5zZXRVaW50MzIoNCAqIGksIHN0YXRlW2ldLCBpc0xFKTtcbiAgICB9XG4gICAgZGlnZXN0KCkge1xuICAgICAgICBjb25zdCB7IGJ1ZmZlciwgb3V0cHV0TGVuIH0gPSB0aGlzO1xuICAgICAgICB0aGlzLmRpZ2VzdEludG8oYnVmZmVyKTtcbiAgICAgICAgLy8gQ29weSBiZWZvcmUgZGVzdHJveSgpOiBzdWJjbGFzc2VzIHdpcGUgYGJ1ZmZlcmAgZHVyaW5nIGNsZWFudXAsIGJ1dCBgZGlnZXN0KClgIG11c3QgcmV0dXJuXG4gICAgICAgIC8vIGZyZXNoIGJ5dGVzIHRvIHRoZSBjYWxsZXIuXG4gICAgICAgIGNvbnN0IHJlcyA9IGJ1ZmZlci5zbGljZSgwLCBvdXRwdXRMZW4pO1xuICAgICAgICB0aGlzLmRlc3Ryb3koKTtcbiAgICAgICAgcmV0dXJuIHJlcztcbiAgICB9XG4gICAgX2Nsb25lSW50byh0bykge1xuICAgICAgICB0byB8fD0gbmV3IHRoaXMuY29uc3RydWN0b3IoKTtcbiAgICAgICAgdG8uc2V0KC4uLnRoaXMuZ2V0KCkpO1xuICAgICAgICBjb25zdCB7IGJsb2NrTGVuLCBidWZmZXIsIGxlbmd0aCwgZmluaXNoZWQsIGRlc3Ryb3llZCwgcG9zIH0gPSB0aGlzO1xuICAgICAgICB0by5kZXN0cm95ZWQgPSBkZXN0cm95ZWQ7XG4gICAgICAgIHRvLmZpbmlzaGVkID0gZmluaXNoZWQ7XG4gICAgICAgIHRvLmxlbmd0aCA9IGxlbmd0aDtcbiAgICAgICAgdG8ucG9zID0gcG9zO1xuICAgICAgICAvLyBPbmx5IHBhcnRpYWwtYmxvY2sgYnl0ZXMgbmVlZCBjb3B5aW5nOiB3aGVuIGBsZW5ndGggJSBibG9ja0xlbiA9PT0gMGAsIGBwb3MgPT09IDBgIGFuZFxuICAgICAgICAvLyBsYXRlciBgdXBkYXRlKClgIC8gYGRpZ2VzdEludG8oKWAgb3ZlcndyaXRlIGB0by5idWZmZXJgIGZyb20gdGhlIHN0YXJ0IGJlZm9yZSByZWFkaW5nIGl0LlxuICAgICAgICBpZiAobGVuZ3RoICUgYmxvY2tMZW4pXG4gICAgICAgICAgICB0by5idWZmZXIuc2V0KGJ1ZmZlcik7XG4gICAgICAgIHJldHVybiB0bztcbiAgICB9XG4gICAgY2xvbmUoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jbG9uZUludG8oKTtcbiAgICB9XG59XG4vKipcbiAqIEluaXRpYWwgU0hBLTIgc3RhdGU6IGZyYWN0aW9uYWwgcGFydHMgb2Ygc3F1YXJlIHJvb3RzIG9mIGZpcnN0IDE2IHByaW1lcyAyLi41My5cbiAqIENoZWNrIG91dCBgdGVzdC9taXNjL3NoYTItZ2VuLWl2LmpzYCBmb3IgcmVjb21wdXRhdGlvbiBndWlkZS5cbiAqL1xuLyoqIEluaXRpYWwgU0hBMjU2IHN0YXRlIGZyb20gUkZDIDYyMzQgwqc2LjE6IHRoZSBmaXJzdCAzMiBiaXRzIG9mIHRoZSBmcmFjdGlvbmFsIHBhcnRzIG9mIHRoZVxuICogc3F1YXJlIHJvb3RzIG9mIHRoZSBmaXJzdCBlaWdodCBwcmltZSBudW1iZXJzLiBFeHBvcnRlZCBhcyBhIHNoYXJlZCB0YWJsZTsgY2FsbGVycyBtdXN0IHRyZWF0XG4gKiBpdCBhcyByZWFkLW9ubHkgYmVjYXVzZSBjb25zdHJ1Y3RvcnMgY29weSB3b3JkcyBmcm9tIGl0IGJ5IGluZGV4LiAqL1xuZXhwb3J0IGNvbnN0IFNIQTI1Nl9JViA9IC8qIEBfX1BVUkVfXyAqLyBVaW50MzJBcnJheS5mcm9tKFtcbiAgICAweDZhMDllNjY3LCAweGJiNjdhZTg1LCAweDNjNmVmMzcyLCAweGE1NGZmNTNhLCAweDUxMGU1MjdmLCAweDliMDU2ODhjLCAweDFmODNkOWFiLCAweDViZTBjZDE5LFxuXSk7XG4vKiogSW5pdGlhbCBTSEEyMjQgc3RhdGUgYEgoMClgIGZyb20gUkZDIDYyMzQgwqc2LjEuIEV4cG9ydGVkIGFzIGEgc2hhcmVkIHRhYmxlOyBjYWxsZXJzIG11c3RcbiAqIHRyZWF0IGl0IGFzIHJlYWQtb25seSBiZWNhdXNlIGNvbnN0cnVjdG9ycyBjb3B5IHdvcmRzIGZyb20gaXQgYnkgaW5kZXguICovXG5leHBvcnQgY29uc3QgU0hBMjI0X0lWID0gLyogQF9fUFVSRV9fICovIFVpbnQzMkFycmF5LmZyb20oW1xuICAgIDB4YzEwNTllZDgsIDB4MzY3Y2Q1MDcsIDB4MzA3MGRkMTcsIDB4ZjcwZTU5MzksIDB4ZmZjMDBiMzEsIDB4Njg1ODE1MTEsIDB4NjRmOThmYTcsIDB4YmVmYTRmYTQsXG5dKTtcbi8qKiBJbml0aWFsIFNIQTM4NCBzdGF0ZSBmcm9tIFJGQyA2MjM0IMKnNi4zOiBlaWdodCBSRkMgNjQtYml0IGBIKDApYCB3b3JkcyBzdG9yZWQgYXMgc2l4dGVlblxuICogYmlnLWVuZGlhbiAzMi1iaXQgaGFsdmVzLiBEZXJpdmVkIGZyb20gdGhlIGZyYWN0aW9uYWwgcGFydHMgb2YgdGhlIHNxdWFyZSByb290cyBvZiB0aGUgbmludGhcbiAqIHRocm91Z2ggc2l4dGVlbnRoIHByaW1lIG51bWJlcnMuIEV4cG9ydGVkIGFzIGEgc2hhcmVkIHRhYmxlOyBjYWxsZXJzIG11c3QgdHJlYXQgaXQgYXMgcmVhZC1vbmx5XG4gKiBiZWNhdXNlIGNvbnN0cnVjdG9ycyBjb3B5IGhhbHZlcyBmcm9tIGl0IGJ5IGluZGV4LiAqL1xuZXhwb3J0IGNvbnN0IFNIQTM4NF9JViA9IC8qIEBfX1BVUkVfXyAqLyBVaW50MzJBcnJheS5mcm9tKFtcbiAgICAweGNiYmI5ZDVkLCAweGMxMDU5ZWQ4LCAweDYyOWEyOTJhLCAweDM2N2NkNTA3LCAweDkxNTkwMTVhLCAweDMwNzBkZDE3LCAweDE1MmZlY2Q4LCAweGY3MGU1OTM5LFxuICAgIDB4NjczMzI2NjcsIDB4ZmZjMDBiMzEsIDB4OGViNDRhODcsIDB4Njg1ODE1MTEsIDB4ZGIwYzJlMGQsIDB4NjRmOThmYTcsIDB4NDdiNTQ4MWQsIDB4YmVmYTRmYTQsXG5dKTtcbi8qKiBJbml0aWFsIFNIQTUxMiBzdGF0ZSBmcm9tIFJGQyA2MjM0IMKnNi4zOiBlaWdodCBSRkMgNjQtYml0IGBIKDApYCB3b3JkcyBzdG9yZWQgYXMgc2l4dGVlblxuICogYmlnLWVuZGlhbiAzMi1iaXQgaGFsdmVzLiBEZXJpdmVkIGZyb20gdGhlIGZyYWN0aW9uYWwgcGFydHMgb2YgdGhlIHNxdWFyZSByb290cyBvZiB0aGUgZmlyc3RcbiAqIGVpZ2h0IHByaW1lIG51bWJlcnMuIEV4cG9ydGVkIGFzIGEgc2hhcmVkIHRhYmxlOyBjYWxsZXJzIG11c3QgdHJlYXQgaXQgYXMgcmVhZC1vbmx5IGJlY2F1c2VcbiAqIGNvbnN0cnVjdG9ycyBjb3B5IGhhbHZlcyBmcm9tIGl0IGJ5IGluZGV4LiAqL1xuZXhwb3J0IGNvbnN0IFNIQTUxMl9JViA9IC8qIEBfX1BVUkVfXyAqLyBVaW50MzJBcnJheS5mcm9tKFtcbiAgICAweDZhMDllNjY3LCAweGYzYmNjOTA4LCAweGJiNjdhZTg1LCAweDg0Y2FhNzNiLCAweDNjNmVmMzcyLCAweGZlOTRmODJiLCAweGE1NGZmNTNhLCAweDVmMWQzNmYxLFxuICAgIDB4NTEwZTUyN2YsIDB4YWRlNjgyZDEsIDB4OWIwNTY4OGMsIDB4MmIzZTZjMWYsIDB4MWY4M2Q5YWIsIDB4ZmI0MWJkNmIsIDB4NWJlMGNkMTksIDB4MTM3ZTIxNzksXG5dKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPV9tZC5qcy5tYXAiLCJjb25zdCBVMzJfTUFTSzY0ID0gLyogQF9fUFVSRV9fICovIEJpZ0ludCgyICoqIDMyIC0gMSk7XG5jb25zdCBfMzJuID0gLyogQF9fUFVSRV9fICovIEJpZ0ludCgzMik7XG4vLyBTcGxpdCBiaWdpbnQgaW50byB0d28gMzItYml0IGhhbHZlcy4gV2l0aCBgbGU9dHJ1ZWAsIHJldHVybmVkIGZpZWxkcyBiZWNvbWUgYHsgaDogbG93LCBsOiBoaWdoXG4vLyB9YCB0byBtYXRjaCBsaXR0bGUtZW5kaWFuIHdvcmQgb3JkZXIgcmF0aGVyIHRoYW4gdGhlIHByb3BlcnR5IG5hbWVzLlxuZnVuY3Rpb24gZnJvbUJpZyhuLCBsZSA9IGZhbHNlKSB7XG4gICAgaWYgKGxlKVxuICAgICAgICByZXR1cm4geyBoOiBOdW1iZXIobiAmIFUzMl9NQVNLNjQpLCBsOiBOdW1iZXIoKG4gPj4gXzMybikgJiBVMzJfTUFTSzY0KSB9O1xuICAgIHJldHVybiB7IGg6IE51bWJlcigobiA+PiBfMzJuKSAmIFUzMl9NQVNLNjQpIHwgMCwgbDogTnVtYmVyKG4gJiBVMzJfTUFTSzY0KSB8IDAgfTtcbn1cbi8vIFNwbGl0IGJpZ2ludCBsaXN0IGludG8gYFtoaWdoV29yZHMsIGxvd1dvcmRzXWAgd2hlbiBgbGU9ZmFsc2VgOyB3aXRoIGBsZT10cnVlYCwgdGhlIGZpcnN0IGFycmF5XG4vLyBob2xkcyB0aGUgbG93IGhhbHZlcyBiZWNhdXNlIGBmcm9tQmlnKC4uLilgIHN3YXBzIHRoZSBzZW1hbnRpYyBtZWFuaW5nIG9mIGBoYCBhbmQgYGxgLlxuZnVuY3Rpb24gc3BsaXQobHN0LCBsZSA9IGZhbHNlKSB7XG4gICAgY29uc3QgbGVuID0gbHN0Lmxlbmd0aDtcbiAgICBsZXQgQWggPSBuZXcgVWludDMyQXJyYXkobGVuKTtcbiAgICBsZXQgQWwgPSBuZXcgVWludDMyQXJyYXkobGVuKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgIGNvbnN0IHsgaCwgbCB9ID0gZnJvbUJpZyhsc3RbaV0sIGxlKTtcbiAgICAgICAgW0FoW2ldLCBBbFtpXV0gPSBbaCwgbF07XG4gICAgfVxuICAgIHJldHVybiBbQWgsIEFsXTtcbn1cbi8vIENvbWJpbmUgZXhwbGljaXQgYChoaWdoLCBsb3cpYCAzMi1iaXQgaGFsdmVzIGludG8gYSBiaWdpbnQ7IGA+Pj4gMGAgbm9ybWFsaXplcyBzaWduZWQgSlNcbi8vIGJpdHdpc2UgcmVzdWx0cyBiYWNrIHRvIHVpbnQzMiBmaXJzdCwgYW5kIGxpdHRsZS1lbmRpYW4gY2FsbGVycyBtdXN0IHN3YXAuXG5jb25zdCB0b0JpZyA9IChoLCBsKSA9PiAoQmlnSW50KGggPj4+IDApIDw8IF8zMm4pIHwgQmlnSW50KGwgPj4+IDApO1xuLy8gSGlnaCAzMi1iaXQgaGFsZiBvZiBhIDY0LWJpdCBsb2dpY2FsIHJpZ2h0IHNoaWZ0IGZvciBgc2AgaW4gYDAuLjMxYC5cbmNvbnN0IHNoclNIID0gKGgsIF9sLCBzKSA9PiBoID4+PiBzO1xuLy8gTG93IDMyLWJpdCBoYWxmIG9mIGEgNjQtYml0IGxvZ2ljYWwgcmlnaHQgc2hpZnQsIHZhbGlkIGZvciBgc2AgaW4gYDEuLjMxYC5cbmNvbnN0IHNoclNMID0gKGgsIGwsIHMpID0+IChoIDw8ICgzMiAtIHMpKSB8IChsID4+PiBzKTtcbi8vIEhpZ2ggMzItYml0IGhhbGYgb2YgYSA2NC1iaXQgcmlnaHQgcm90YXRlLCB2YWxpZCBmb3IgYHNgIGluIGAxLi4zMWAuXG5jb25zdCByb3RyU0ggPSAoaCwgbCwgcykgPT4gKGggPj4+IHMpIHwgKGwgPDwgKDMyIC0gcykpO1xuLy8gTG93IDMyLWJpdCBoYWxmIG9mIGEgNjQtYml0IHJpZ2h0IHJvdGF0ZSwgdmFsaWQgZm9yIGBzYCBpbiBgMS4uMzFgLlxuY29uc3Qgcm90clNMID0gKGgsIGwsIHMpID0+IChoIDw8ICgzMiAtIHMpKSB8IChsID4+PiBzKTtcbi8vIEhpZ2ggMzItYml0IGhhbGYgb2YgYSA2NC1iaXQgcmlnaHQgcm90YXRlLCB2YWxpZCBmb3IgYHNgIGluIGAzMy4uNjNgOyBgMzJgIHVzZXMgYHJvdHIzMipgLlxuY29uc3Qgcm90ckJIID0gKGgsIGwsIHMpID0+IChoIDw8ICg2NCAtIHMpKSB8IChsID4+PiAocyAtIDMyKSk7XG4vLyBMb3cgMzItYml0IGhhbGYgb2YgYSA2NC1iaXQgcmlnaHQgcm90YXRlLCB2YWxpZCBmb3IgYHNgIGluIGAzMy4uNjNgOyBgMzJgIHVzZXMgYHJvdHIzMipgLlxuY29uc3Qgcm90ckJMID0gKGgsIGwsIHMpID0+IChoID4+PiAocyAtIDMyKSkgfCAobCA8PCAoNjQgLSBzKSk7XG4vLyBIaWdoIDMyLWJpdCBoYWxmIG9mIGEgNjQtYml0IHJpZ2h0IHJvdGF0ZSBmb3IgYHMgPT09IDMyYDsgdGhpcyBpcyBqdXN0IHRoZSBzd2FwcGVkIGxvdyBoYWxmLlxuY29uc3Qgcm90cjMySCA9IChfaCwgbCkgPT4gbDtcbi8vIExvdyAzMi1iaXQgaGFsZiBvZiBhIDY0LWJpdCByaWdodCByb3RhdGUgZm9yIGBzID09PSAzMmA7IHRoaXMgaXMganVzdCB0aGUgc3dhcHBlZCBoaWdoIGhhbGYuXG5jb25zdCByb3RyMzJMID0gKGgsIF9sKSA9PiBoO1xuLy8gSGlnaCAzMi1iaXQgaGFsZiBvZiBhIDY0LWJpdCBsZWZ0IHJvdGF0ZSwgdmFsaWQgZm9yIGBzYCBpbiBgMS4uMzFgLlxuY29uc3Qgcm90bFNIID0gKGgsIGwsIHMpID0+IChoIDw8IHMpIHwgKGwgPj4+ICgzMiAtIHMpKTtcbi8vIExvdyAzMi1iaXQgaGFsZiBvZiBhIDY0LWJpdCBsZWZ0IHJvdGF0ZSwgdmFsaWQgZm9yIGBzYCBpbiBgMS4uMzFgLlxuY29uc3Qgcm90bFNMID0gKGgsIGwsIHMpID0+IChsIDw8IHMpIHwgKGggPj4+ICgzMiAtIHMpKTtcbi8vIEhpZ2ggMzItYml0IGhhbGYgb2YgYSA2NC1iaXQgbGVmdCByb3RhdGUsIHZhbGlkIGZvciBgc2AgaW4gYDMzLi42M2A7IGAzMmAgdXNlcyBgcm90cjMyKmAuXG5jb25zdCByb3RsQkggPSAoaCwgbCwgcykgPT4gKGwgPDwgKHMgLSAzMikpIHwgKGggPj4+ICg2NCAtIHMpKTtcbi8vIExvdyAzMi1iaXQgaGFsZiBvZiBhIDY0LWJpdCBsZWZ0IHJvdGF0ZSwgdmFsaWQgZm9yIGBzYCBpbiBgMzMuLjYzYDsgYDMyYCB1c2VzIGByb3RyMzIqYC5cbmNvbnN0IHJvdGxCTCA9IChoLCBsLCBzKSA9PiAoaCA8PCAocyAtIDMyKSkgfCAobCA+Pj4gKDY0IC0gcykpO1xuLy8gQWRkIHR3byBzcGxpdCA2NC1iaXQgd29yZHMgYW5kIHJldHVybiB0aGUgc3BsaXQgYHsgaCwgbCB9YCBzdW0uXG4vLyBKUyB1c2VzIDMyLWJpdCBzaWduZWQgaW50ZWdlcnMgZm9yIGJpdHdpc2Ugb3BlcmF0aW9ucywgc28gd2UgY2Fubm90IHNpbXBseSBzaGlmdCB0aGUgY2Fycnkgb3V0XG4vLyBvZiB0aGUgbG93IHN1bSBhbmQgaW5zdGVhZCB1c2UgZGl2aXNpb24uXG5mdW5jdGlvbiBhZGQoQWgsIEFsLCBCaCwgQmwpIHtcbiAgICBjb25zdCBsID0gKEFsID4+PiAwKSArIChCbCA+Pj4gMCk7XG4gICAgcmV0dXJuIHsgaDogKEFoICsgQmggKyAoKGwgLyAyICoqIDMyKSB8IDApKSB8IDAsIGw6IGwgfCAwIH07XG59XG4vLyBBZGRpdGlvbiB3aXRoIG1vcmUgdGhhbiAyIGVsZW1lbnRzXG4vLyBVbm1hc2tlZCBsb3ctd29yZCBhY2N1bXVsYXRvciBmb3IgMy13YXkgYWRkaXRpb247IHBhc3MgdGhlIHJhdyByZXN1bHQgaW50byBgYWRkM0goLi4uKWAuXG5jb25zdCBhZGQzTCA9IChBbCwgQmwsIENsKSA9PiAoQWwgPj4+IDApICsgKEJsID4+PiAwKSArIChDbCA+Pj4gMCk7XG4vLyBIaWdoLXdvcmQgZmluYWxpemUgc3RlcCBmb3IgMy13YXkgYWRkaXRpb247IGBsb3dgIG11c3QgYmUgdGhlIHVudHJ1bmNhdGVkIG91dHB1dCBvZiBgYWRkM0woLi4uKWAuXG5jb25zdCBhZGQzSCA9IChsb3csIEFoLCBCaCwgQ2gpID0+IChBaCArIEJoICsgQ2ggKyAoKGxvdyAvIDIgKiogMzIpIHwgMCkpIHwgMDtcbi8vIFVubWFza2VkIGxvdy13b3JkIGFjY3VtdWxhdG9yIGZvciA0LXdheSBhZGRpdGlvbjsgcGFzcyB0aGUgcmF3IHJlc3VsdCBpbnRvIGBhZGQ0SCguLi4pYC5cbmNvbnN0IGFkZDRMID0gKEFsLCBCbCwgQ2wsIERsKSA9PiAoQWwgPj4+IDApICsgKEJsID4+PiAwKSArIChDbCA+Pj4gMCkgKyAoRGwgPj4+IDApO1xuLy8gSGlnaC13b3JkIGZpbmFsaXplIHN0ZXAgZm9yIDQtd2F5IGFkZGl0aW9uOyBgbG93YCBtdXN0IGJlIHRoZSB1bnRydW5jYXRlZCBvdXRwdXQgb2YgYGFkZDRMKC4uLilgLlxuY29uc3QgYWRkNEggPSAobG93LCBBaCwgQmgsIENoLCBEaCkgPT4gKEFoICsgQmggKyBDaCArIERoICsgKChsb3cgLyAyICoqIDMyKSB8IDApKSB8IDA7XG4vLyBVbm1hc2tlZCBsb3ctd29yZCBhY2N1bXVsYXRvciBmb3IgNS13YXkgYWRkaXRpb247IHBhc3MgdGhlIHJhdyByZXN1bHQgaW50byBgYWRkNUgoLi4uKWAuXG5jb25zdCBhZGQ1TCA9IChBbCwgQmwsIENsLCBEbCwgRWwpID0+IChBbCA+Pj4gMCkgKyAoQmwgPj4+IDApICsgKENsID4+PiAwKSArIChEbCA+Pj4gMCkgKyAoRWwgPj4+IDApO1xuLy8gSGlnaC13b3JkIGZpbmFsaXplIHN0ZXAgZm9yIDUtd2F5IGFkZGl0aW9uOyBgbG93YCBtdXN0IGJlIHRoZSB1bnRydW5jYXRlZCBvdXRwdXQgb2YgYGFkZDVMKC4uLilgLlxuY29uc3QgYWRkNUggPSAobG93LCBBaCwgQmgsIENoLCBEaCwgRWgpID0+IChBaCArIEJoICsgQ2ggKyBEaCArIEVoICsgKChsb3cgLyAyICoqIDMyKSB8IDApKSB8IDA7XG4vLyBwcmV0dGllci1pZ25vcmVcbmV4cG9ydCB7IGFkZCwgYWRkM0gsIGFkZDNMLCBhZGQ0SCwgYWRkNEwsIGFkZDVILCBhZGQ1TCwgZnJvbUJpZywgcm90bEJILCByb3RsQkwsIHJvdGxTSCwgcm90bFNMLCByb3RyMzJILCByb3RyMzJMLCByb3RyQkgsIHJvdHJCTCwgcm90clNILCByb3RyU0wsIHNoclNILCBzaHJTTCwgc3BsaXQsIHRvQmlnIH07XG4vLyBDYW5vbmljYWwgZ3JvdXBlZCBuYW1lc3BhY2UgZm9yIGNhbGxlcnMgdGhhdCBwcmVmZXIgb25lIG9iamVjdC5cbi8vIE5hbWVkIGV4cG9ydHMgc3RheSBmb3IgZGlyZWN0IGltcG9ydHMuXG4vLyBwcmV0dGllci1pZ25vcmVcbmNvbnN0IHU2NCA9IHtcbiAgICBmcm9tQmlnLCBzcGxpdCwgdG9CaWcsXG4gICAgc2hyU0gsIHNoclNMLFxuICAgIHJvdHJTSCwgcm90clNMLCByb3RyQkgsIHJvdHJCTCxcbiAgICByb3RyMzJILCByb3RyMzJMLFxuICAgIHJvdGxTSCwgcm90bFNMLCByb3RsQkgsIHJvdGxCTCxcbiAgICBhZGQsIGFkZDNMLCBhZGQzSCwgYWRkNEwsIGFkZDRILCBhZGQ1SCwgYWRkNUwsXG59O1xuLy8gRGVmYXVsdCBleHBvcnQgbWlycm9ycyBuYW1lZCBgdTY0YCBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG9iamVjdC1zdHlsZSBpbXBvcnRzLlxuZXhwb3J0IGRlZmF1bHQgdTY0O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9X3U2NC5qcy5tYXAiLCIvKipcbiAqIFNIQTIgaGFzaCBmdW5jdGlvbi4gQS5rLmEuIHNoYTI1Niwgc2hhMzg0LCBzaGE1MTIsIHNoYTUxMl8yMjQsIHNoYTUxMl8yNTYuXG4gKiBTSEEyNTYgaXMgdGhlIGZhc3Rlc3QgaGFzaCBpbXBsZW1lbnRhYmxlIGluIEpTLCBldmVuIGZhc3RlciB0aGFuIEJsYWtlMy5cbiAqIENoZWNrIG91dCB7QGxpbmsgaHR0cHM6Ly93d3cucmZjLWVkaXRvci5vcmcvcmZjL3JmYzQ2MzQgfCBSRkMgNDYzNH0gYW5kXG4gKiB7QGxpbmsgaHR0cHM6Ly9udmxwdWJzLm5pc3QuZ292L25pc3RwdWJzL0ZJUFMvTklTVC5GSVBTLjE4MC00LnBkZiB8IEZJUFMgMTgwLTR9LlxuICogQG1vZHVsZVxuICovXG5pbXBvcnQgeyBDaGksIEhhc2hNRCwgTWFqLCBTSEEyMjRfSVYsIFNIQTI1Nl9JViwgU0hBMzg0X0lWLCBTSEE1MTJfSVYgfSBmcm9tIFwiLi9fbWQuanNcIjtcbmltcG9ydCAqIGFzIHU2NCBmcm9tIFwiLi9fdTY0LmpzXCI7XG5pbXBvcnQgeyBjbGVhbiwgY3JlYXRlSGFzaGVyLCBvaWROaXN0LCByb3RyIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbi8qKlxuICogU0hBLTIyNCAvIFNIQS0yNTYgcm91bmQgY29uc3RhbnRzIGZyb20gUkZDIDYyMzQgwqc1LjE6IHRoZSBmaXJzdCAzMiBiaXRzXG4gKiBvZiB0aGUgY3ViZSByb290cyBvZiB0aGUgZmlyc3QgNjQgcHJpbWVzICgyLi4zMTEpLlxuICovXG4vLyBwcmV0dGllci1pZ25vcmVcbmNvbnN0IFNIQTI1Nl9LID0gLyogQF9fUFVSRV9fICovIFVpbnQzMkFycmF5LmZyb20oW1xuICAgIDB4NDI4YTJmOTgsIDB4NzEzNzQ0OTEsIDB4YjVjMGZiY2YsIDB4ZTliNWRiYTUsIDB4Mzk1NmMyNWIsIDB4NTlmMTExZjEsIDB4OTIzZjgyYTQsIDB4YWIxYzVlZDUsXG4gICAgMHhkODA3YWE5OCwgMHgxMjgzNWIwMSwgMHgyNDMxODViZSwgMHg1NTBjN2RjMywgMHg3MmJlNWQ3NCwgMHg4MGRlYjFmZSwgMHg5YmRjMDZhNywgMHhjMTliZjE3NCxcbiAgICAweGU0OWI2OWMxLCAweGVmYmU0Nzg2LCAweDBmYzE5ZGM2LCAweDI0MGNhMWNjLCAweDJkZTkyYzZmLCAweDRhNzQ4NGFhLCAweDVjYjBhOWRjLCAweDc2Zjk4OGRhLFxuICAgIDB4OTgzZTUxNTIsIDB4YTgzMWM2NmQsIDB4YjAwMzI3YzgsIDB4YmY1OTdmYzcsIDB4YzZlMDBiZjMsIDB4ZDVhNzkxNDcsIDB4MDZjYTYzNTEsIDB4MTQyOTI5NjcsXG4gICAgMHgyN2I3MGE4NSwgMHgyZTFiMjEzOCwgMHg0ZDJjNmRmYywgMHg1MzM4MGQxMywgMHg2NTBhNzM1NCwgMHg3NjZhMGFiYiwgMHg4MWMyYzkyZSwgMHg5MjcyMmM4NSxcbiAgICAweGEyYmZlOGExLCAweGE4MWE2NjRiLCAweGMyNGI4YjcwLCAweGM3NmM1MWEzLCAweGQxOTJlODE5LCAweGQ2OTkwNjI0LCAweGY0MGUzNTg1LCAweDEwNmFhMDcwLFxuICAgIDB4MTlhNGMxMTYsIDB4MWUzNzZjMDgsIDB4Mjc0ODc3NGMsIDB4MzRiMGJjYjUsIDB4MzkxYzBjYjMsIDB4NGVkOGFhNGEsIDB4NWI5Y2NhNGYsIDB4NjgyZTZmZjMsXG4gICAgMHg3NDhmODJlZSwgMHg3OGE1NjM2ZiwgMHg4NGM4NzgxNCwgMHg4Y2M3MDIwOCwgMHg5MGJlZmZmYSwgMHhhNDUwNmNlYiwgMHhiZWY5YTNmNywgMHhjNjcxNzhmMlxuXSk7XG4vKiogUmV1c2FibGUgU0hBLTIyNCAvIFNIQS0yNTYgbWVzc2FnZSBzY2hlZHVsZSBidWZmZXIgYFdfdGAgZnJvbSBSRkMgNjIzNCDCpzYuMiBzdGVwIDEuICovXG5jb25zdCBTSEEyNTZfVyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgVWludDMyQXJyYXkoNjQpO1xuLyoqIEludGVybmFsIFNIQS0yMjQgLyBTSEEtMjU2IGNvbXByZXNzaW9uIGVuZ2luZSBmcm9tIFJGQyA2MjM0IMKnNi4yLiAqL1xuY2xhc3MgU0hBMl8zMkIgZXh0ZW5kcyBIYXNoTUQge1xuICAgIGNvbnN0cnVjdG9yKG91dHB1dExlbikge1xuICAgICAgICBzdXBlcig2NCwgb3V0cHV0TGVuLCA4LCBmYWxzZSk7XG4gICAgfVxuICAgIGdldCgpIHtcbiAgICAgICAgY29uc3QgeyBBLCBCLCBDLCBELCBFLCBGLCBHLCBIIH0gPSB0aGlzO1xuICAgICAgICByZXR1cm4gW0EsIEIsIEMsIEQsIEUsIEYsIEcsIEhdO1xuICAgIH1cbiAgICAvLyBwcmV0dGllci1pZ25vcmVcbiAgICBzZXQoQSwgQiwgQywgRCwgRSwgRiwgRywgSCkge1xuICAgICAgICB0aGlzLkEgPSBBIHwgMDtcbiAgICAgICAgdGhpcy5CID0gQiB8IDA7XG4gICAgICAgIHRoaXMuQyA9IEMgfCAwO1xuICAgICAgICB0aGlzLkQgPSBEIHwgMDtcbiAgICAgICAgdGhpcy5FID0gRSB8IDA7XG4gICAgICAgIHRoaXMuRiA9IEYgfCAwO1xuICAgICAgICB0aGlzLkcgPSBHIHwgMDtcbiAgICAgICAgdGhpcy5IID0gSCB8IDA7XG4gICAgfVxuICAgIHByb2Nlc3Modmlldywgb2Zmc2V0KSB7XG4gICAgICAgIC8vIEV4dGVuZCB0aGUgZmlyc3QgMTYgd29yZHMgaW50byB0aGUgcmVtYWluaW5nIDQ4IHdvcmRzIHdbMTYuLjYzXSBvZiB0aGUgbWVzc2FnZSBzY2hlZHVsZSBhcnJheVxuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IDE2OyBpKyssIG9mZnNldCArPSA0KVxuICAgICAgICAgICAgU0hBMjU2X1dbaV0gPSB2aWV3LmdldFVpbnQzMihvZmZzZXQsIGZhbHNlKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDE2OyBpIDwgNjQ7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgVzE1ID0gU0hBMjU2X1dbaSAtIDE1XTtcbiAgICAgICAgICAgIGNvbnN0IFcyID0gU0hBMjU2X1dbaSAtIDJdO1xuICAgICAgICAgICAgY29uc3QgczAgPSByb3RyKFcxNSwgNykgXiByb3RyKFcxNSwgMTgpIF4gKFcxNSA+Pj4gMyk7XG4gICAgICAgICAgICBjb25zdCBzMSA9IHJvdHIoVzIsIDE3KSBeIHJvdHIoVzIsIDE5KSBeIChXMiA+Pj4gMTApO1xuICAgICAgICAgICAgU0hBMjU2X1dbaV0gPSAoczEgKyBTSEEyNTZfV1tpIC0gN10gKyBzMCArIFNIQTI1Nl9XW2kgLSAxNl0pIHwgMDtcbiAgICAgICAgfVxuICAgICAgICAvLyBDb21wcmVzc2lvbiBmdW5jdGlvbiBtYWluIGxvb3AsIDY0IHJvdW5kc1xuICAgICAgICBsZXQgeyBBLCBCLCBDLCBELCBFLCBGLCBHLCBIIH0gPSB0aGlzO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IDY0OyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHNpZ21hMSA9IHJvdHIoRSwgNikgXiByb3RyKEUsIDExKSBeIHJvdHIoRSwgMjUpO1xuICAgICAgICAgICAgY29uc3QgVDEgPSAoSCArIHNpZ21hMSArIENoaShFLCBGLCBHKSArIFNIQTI1Nl9LW2ldICsgU0hBMjU2X1dbaV0pIHwgMDtcbiAgICAgICAgICAgIGNvbnN0IHNpZ21hMCA9IHJvdHIoQSwgMikgXiByb3RyKEEsIDEzKSBeIHJvdHIoQSwgMjIpO1xuICAgICAgICAgICAgY29uc3QgVDIgPSAoc2lnbWEwICsgTWFqKEEsIEIsIEMpKSB8IDA7XG4gICAgICAgICAgICBIID0gRztcbiAgICAgICAgICAgIEcgPSBGO1xuICAgICAgICAgICAgRiA9IEU7XG4gICAgICAgICAgICBFID0gKEQgKyBUMSkgfCAwO1xuICAgICAgICAgICAgRCA9IEM7XG4gICAgICAgICAgICBDID0gQjtcbiAgICAgICAgICAgIEIgPSBBO1xuICAgICAgICAgICAgQSA9IChUMSArIFQyKSB8IDA7XG4gICAgICAgIH1cbiAgICAgICAgLy8gQWRkIHRoZSBjb21wcmVzc2VkIGNodW5rIHRvIHRoZSBjdXJyZW50IGhhc2ggdmFsdWVcbiAgICAgICAgQSA9IChBICsgdGhpcy5BKSB8IDA7XG4gICAgICAgIEIgPSAoQiArIHRoaXMuQikgfCAwO1xuICAgICAgICBDID0gKEMgKyB0aGlzLkMpIHwgMDtcbiAgICAgICAgRCA9IChEICsgdGhpcy5EKSB8IDA7XG4gICAgICAgIEUgPSAoRSArIHRoaXMuRSkgfCAwO1xuICAgICAgICBGID0gKEYgKyB0aGlzLkYpIHwgMDtcbiAgICAgICAgRyA9IChHICsgdGhpcy5HKSB8IDA7XG4gICAgICAgIEggPSAoSCArIHRoaXMuSCkgfCAwO1xuICAgICAgICB0aGlzLnNldChBLCBCLCBDLCBELCBFLCBGLCBHLCBIKTtcbiAgICB9XG4gICAgcm91bmRDbGVhbigpIHtcbiAgICAgICAgY2xlYW4oU0hBMjU2X1cpO1xuICAgIH1cbiAgICBkZXN0cm95KCkge1xuICAgICAgICAvLyBIYXNoTUQgY2FsbGVycyByb3V0ZSBwb3N0LWRlc3Ryb3kgdXNhYmlsaXR5IHRocm91Z2ggYGRlc3Ryb3llZGA7IHplcm9pemluZyBhbG9uZSBzdGlsbCBsZWF2ZXNcbiAgICAgICAgLy8gdXBkYXRlKCkvZGlnZXN0KCkgY2FsbGFibGUgb24gcmV1c2VkIGluc3RhbmNlcy5cbiAgICAgICAgdGhpcy5kZXN0cm95ZWQgPSB0cnVlO1xuICAgICAgICB0aGlzLnNldCgwLCAwLCAwLCAwLCAwLCAwLCAwLCAwKTtcbiAgICAgICAgY2xlYW4odGhpcy5idWZmZXIpO1xuICAgIH1cbn1cbi8qKiBJbnRlcm5hbCBTSEEtMjU2IGhhc2ggY2xhc3MgZ3JvdW5kZWQgaW4gUkZDIDYyMzQgwqc2LjIuICovXG5leHBvcnQgY2xhc3MgX1NIQTI1NiBleHRlbmRzIFNIQTJfMzJCIHtcbiAgICAvLyBXZSBjYW5ub3QgdXNlIGFycmF5IGhlcmUgc2luY2UgYXJyYXkgYWxsb3dzIGluZGV4aW5nIGJ5IHZhcmlhYmxlXG4gICAgLy8gd2hpY2ggbWVhbnMgb3B0aW1pemVyL2NvbXBpbGVyIGNhbm5vdCB1c2UgcmVnaXN0ZXJzLlxuICAgIEEgPSBTSEEyNTZfSVZbMF0gfCAwO1xuICAgIEIgPSBTSEEyNTZfSVZbMV0gfCAwO1xuICAgIEMgPSBTSEEyNTZfSVZbMl0gfCAwO1xuICAgIEQgPSBTSEEyNTZfSVZbM10gfCAwO1xuICAgIEUgPSBTSEEyNTZfSVZbNF0gfCAwO1xuICAgIEYgPSBTSEEyNTZfSVZbNV0gfCAwO1xuICAgIEcgPSBTSEEyNTZfSVZbNl0gfCAwO1xuICAgIEggPSBTSEEyNTZfSVZbN10gfCAwO1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcigzMik7XG4gICAgfVxufVxuLyoqIEludGVybmFsIFNIQS0yMjQgaGFzaCBjbGFzcyBncm91bmRlZCBpbiBSRkMgNjIzNCDCpzYuMiBhbmQgwqc4LjUuICovXG5leHBvcnQgY2xhc3MgX1NIQTIyNCBleHRlbmRzIFNIQTJfMzJCIHtcbiAgICBBID0gU0hBMjI0X0lWWzBdIHwgMDtcbiAgICBCID0gU0hBMjI0X0lWWzFdIHwgMDtcbiAgICBDID0gU0hBMjI0X0lWWzJdIHwgMDtcbiAgICBEID0gU0hBMjI0X0lWWzNdIHwgMDtcbiAgICBFID0gU0hBMjI0X0lWWzRdIHwgMDtcbiAgICBGID0gU0hBMjI0X0lWWzVdIHwgMDtcbiAgICBHID0gU0hBMjI0X0lWWzZdIHwgMDtcbiAgICBIID0gU0hBMjI0X0lWWzddIHwgMDtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoMjgpO1xuICAgIH1cbn1cbi8vIFNIQTItNTEyIGlzIHNsb3dlciB0aGFuIHNoYTI1NiBpbiBqcyBiZWNhdXNlIHU2NCBvcGVyYXRpb25zIGFyZSBzbG93LlxuLy8gU0hBLTM4NCAvIFNIQS01MTIgcm91bmQgY29uc3RhbnRzIGZyb20gUkZDIDYyMzQgwqc1LjI6XG4vLyA4MCBmdWxsIDY0LWJpdCB3b3JkcyBzcGxpdCBpbnRvIGhpZ2gvbG93IGhhbHZlcy5cbi8vIHByZXR0aWVyLWlnbm9yZVxuY29uc3QgSzUxMiA9IC8qIEBfX1BVUkVfXyAqLyAoKCkgPT4gdTY0LnNwbGl0KFtcbiAgICAnMHg0MjhhMmY5OGQ3MjhhZTIyJywgJzB4NzEzNzQ0OTEyM2VmNjVjZCcsICcweGI1YzBmYmNmZWM0ZDNiMmYnLCAnMHhlOWI1ZGJhNTgxODlkYmJjJyxcbiAgICAnMHgzOTU2YzI1YmYzNDhiNTM4JywgJzB4NTlmMTExZjFiNjA1ZDAxOScsICcweDkyM2Y4MmE0YWYxOTRmOWInLCAnMHhhYjFjNWVkNWRhNmQ4MTE4JyxcbiAgICAnMHhkODA3YWE5OGEzMDMwMjQyJywgJzB4MTI4MzViMDE0NTcwNmZiZScsICcweDI0MzE4NWJlNGVlNGIyOGMnLCAnMHg1NTBjN2RjM2Q1ZmZiNGUyJyxcbiAgICAnMHg3MmJlNWQ3NGYyN2I4OTZmJywgJzB4ODBkZWIxZmUzYjE2OTZiMScsICcweDliZGMwNmE3MjVjNzEyMzUnLCAnMHhjMTliZjE3NGNmNjkyNjk0JyxcbiAgICAnMHhlNDliNjljMTllZjE0YWQyJywgJzB4ZWZiZTQ3ODYzODRmMjVlMycsICcweDBmYzE5ZGM2OGI4Y2Q1YjUnLCAnMHgyNDBjYTFjYzc3YWM5YzY1JyxcbiAgICAnMHgyZGU5MmM2ZjU5MmIwMjc1JywgJzB4NGE3NDg0YWE2ZWE2ZTQ4MycsICcweDVjYjBhOWRjYmQ0MWZiZDQnLCAnMHg3NmY5ODhkYTgzMTE1M2I1JyxcbiAgICAnMHg5ODNlNTE1MmVlNjZkZmFiJywgJzB4YTgzMWM2NmQyZGI0MzIxMCcsICcweGIwMDMyN2M4OThmYjIxM2YnLCAnMHhiZjU5N2ZjN2JlZWYwZWU0JyxcbiAgICAnMHhjNmUwMGJmMzNkYTg4ZmMyJywgJzB4ZDVhNzkxNDc5MzBhYTcyNScsICcweDA2Y2E2MzUxZTAwMzgyNmYnLCAnMHgxNDI5Mjk2NzBhMGU2ZTcwJyxcbiAgICAnMHgyN2I3MGE4NTQ2ZDIyZmZjJywgJzB4MmUxYjIxMzg1YzI2YzkyNicsICcweDRkMmM2ZGZjNWFjNDJhZWQnLCAnMHg1MzM4MGQxMzlkOTViM2RmJyxcbiAgICAnMHg2NTBhNzM1NDhiYWY2M2RlJywgJzB4NzY2YTBhYmIzYzc3YjJhOCcsICcweDgxYzJjOTJlNDdlZGFlZTYnLCAnMHg5MjcyMmM4NTE0ODIzNTNiJyxcbiAgICAnMHhhMmJmZThhMTRjZjEwMzY0JywgJzB4YTgxYTY2NGJiYzQyMzAwMScsICcweGMyNGI4YjcwZDBmODk3OTEnLCAnMHhjNzZjNTFhMzA2NTRiZTMwJyxcbiAgICAnMHhkMTkyZTgxOWQ2ZWY1MjE4JywgJzB4ZDY5OTA2MjQ1NTY1YTkxMCcsICcweGY0MGUzNTg1NTc3MTIwMmEnLCAnMHgxMDZhYTA3MDMyYmJkMWI4JyxcbiAgICAnMHgxOWE0YzExNmI4ZDJkMGM4JywgJzB4MWUzNzZjMDg1MTQxYWI1MycsICcweDI3NDg3NzRjZGY4ZWViOTknLCAnMHgzNGIwYmNiNWUxOWI0OGE4JyxcbiAgICAnMHgzOTFjMGNiM2M1Yzk1YTYzJywgJzB4NGVkOGFhNGFlMzQxOGFjYicsICcweDViOWNjYTRmNzc2M2UzNzMnLCAnMHg2ODJlNmZmM2Q2YjJiOGEzJyxcbiAgICAnMHg3NDhmODJlZTVkZWZiMmZjJywgJzB4NzhhNTYzNmY0MzE3MmY2MCcsICcweDg0Yzg3ODE0YTFmMGFiNzInLCAnMHg4Y2M3MDIwODFhNjQzOWVjJyxcbiAgICAnMHg5MGJlZmZmYTIzNjMxZTI4JywgJzB4YTQ1MDZjZWJkZTgyYmRlOScsICcweGJlZjlhM2Y3YjJjNjc5MTUnLCAnMHhjNjcxNzhmMmUzNzI1MzJiJyxcbiAgICAnMHhjYTI3M2VjZWVhMjY2MTljJywgJzB4ZDE4NmI4YzcyMWMwYzIwNycsICcweGVhZGE3ZGQ2Y2RlMGViMWUnLCAnMHhmNTdkNGY3ZmVlNmVkMTc4JyxcbiAgICAnMHgwNmYwNjdhYTcyMTc2ZmJhJywgJzB4MGE2MzdkYzVhMmM4OThhNicsICcweDExM2Y5ODA0YmVmOTBkYWUnLCAnMHgxYjcxMGIzNTEzMWM0NzFiJyxcbiAgICAnMHgyOGRiNzdmNTIzMDQ3ZDg0JywgJzB4MzJjYWFiN2I0MGM3MjQ5MycsICcweDNjOWViZTBhMTVjOWJlYmMnLCAnMHg0MzFkNjdjNDljMTAwZDRjJyxcbiAgICAnMHg0Y2M1ZDRiZWNiM2U0MmI2JywgJzB4NTk3ZjI5OWNmYzY1N2UyYScsICcweDVmY2I2ZmFiM2FkNmZhZWMnLCAnMHg2YzQ0MTk4YzRhNDc1ODE3J1xuXS5tYXAobiA9PiBCaWdJbnQobikpKSkoKTtcbmNvbnN0IFNIQTUxMl9LaCA9IC8qIEBfX1BVUkVfXyAqLyAoKCkgPT4gSzUxMlswXSkoKTtcbmNvbnN0IFNIQTUxMl9LbCA9IC8qIEBfX1BVUkVfXyAqLyAoKCkgPT4gSzUxMlsxXSkoKTtcbi8vIFJldXNhYmxlIGhpZ2gtaGFsZiBzY2hlZHVsZSBidWZmZXIgZm9yIHRoZSBSRkMgNjIzNCDCpzYuNCA2NC1iaXQgYFdfdGAgd29yZHMuXG5jb25zdCBTSEE1MTJfV19IID0gLyogQF9fUFVSRV9fICovIG5ldyBVaW50MzJBcnJheSg4MCk7XG4vLyBSZXVzYWJsZSBsb3ctaGFsZiBzY2hlZHVsZSBidWZmZXIgZm9yIHRoZSBSRkMgNjIzNCDCpzYuNCA2NC1iaXQgYFdfdGAgd29yZHMuXG5jb25zdCBTSEE1MTJfV19MID0gLyogQF9fUFVSRV9fICovIG5ldyBVaW50MzJBcnJheSg4MCk7XG4vKiogSW50ZXJuYWwgU0hBLTM4NCAvIFNIQS01MTIgY29tcHJlc3Npb24gZW5naW5lIGZyb20gUkZDIDYyMzQgwqc2LjQuICovXG5jbGFzcyBTSEEyXzY0QiBleHRlbmRzIEhhc2hNRCB7XG4gICAgY29uc3RydWN0b3Iob3V0cHV0TGVuKSB7XG4gICAgICAgIHN1cGVyKDEyOCwgb3V0cHV0TGVuLCAxNiwgZmFsc2UpO1xuICAgIH1cbiAgICAvLyBwcmV0dGllci1pZ25vcmVcbiAgICBnZXQoKSB7XG4gICAgICAgIGNvbnN0IHsgQWgsIEFsLCBCaCwgQmwsIENoLCBDbCwgRGgsIERsLCBFaCwgRWwsIEZoLCBGbCwgR2gsIEdsLCBIaCwgSGwgfSA9IHRoaXM7XG4gICAgICAgIHJldHVybiBbQWgsIEFsLCBCaCwgQmwsIENoLCBDbCwgRGgsIERsLCBFaCwgRWwsIEZoLCBGbCwgR2gsIEdsLCBIaCwgSGxdO1xuICAgIH1cbiAgICAvLyBwcmV0dGllci1pZ25vcmVcbiAgICBzZXQoQWgsIEFsLCBCaCwgQmwsIENoLCBDbCwgRGgsIERsLCBFaCwgRWwsIEZoLCBGbCwgR2gsIEdsLCBIaCwgSGwpIHtcbiAgICAgICAgdGhpcy5BaCA9IEFoIHwgMDtcbiAgICAgICAgdGhpcy5BbCA9IEFsIHwgMDtcbiAgICAgICAgdGhpcy5CaCA9IEJoIHwgMDtcbiAgICAgICAgdGhpcy5CbCA9IEJsIHwgMDtcbiAgICAgICAgdGhpcy5DaCA9IENoIHwgMDtcbiAgICAgICAgdGhpcy5DbCA9IENsIHwgMDtcbiAgICAgICAgdGhpcy5EaCA9IERoIHwgMDtcbiAgICAgICAgdGhpcy5EbCA9IERsIHwgMDtcbiAgICAgICAgdGhpcy5FaCA9IEVoIHwgMDtcbiAgICAgICAgdGhpcy5FbCA9IEVsIHwgMDtcbiAgICAgICAgdGhpcy5GaCA9IEZoIHwgMDtcbiAgICAgICAgdGhpcy5GbCA9IEZsIHwgMDtcbiAgICAgICAgdGhpcy5HaCA9IEdoIHwgMDtcbiAgICAgICAgdGhpcy5HbCA9IEdsIHwgMDtcbiAgICAgICAgdGhpcy5IaCA9IEhoIHwgMDtcbiAgICAgICAgdGhpcy5IbCA9IEhsIHwgMDtcbiAgICB9XG4gICAgcHJvY2Vzcyh2aWV3LCBvZmZzZXQpIHtcbiAgICAgICAgLy8gRXh0ZW5kIHRoZSBmaXJzdCAxNiB3b3JkcyBpbnRvIHRoZSByZW1haW5pbmcgNjQgd29yZHMgd1sxNi4uNzldIG9mIHRoZSBtZXNzYWdlIHNjaGVkdWxlIGFycmF5XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgMTY7IGkrKywgb2Zmc2V0ICs9IDQpIHtcbiAgICAgICAgICAgIFNIQTUxMl9XX0hbaV0gPSB2aWV3LmdldFVpbnQzMihvZmZzZXQpO1xuICAgICAgICAgICAgU0hBNTEyX1dfTFtpXSA9IHZpZXcuZ2V0VWludDMyKChvZmZzZXQgKz0gNCkpO1xuICAgICAgICB9XG4gICAgICAgIGZvciAobGV0IGkgPSAxNjsgaSA8IDgwOyBpKyspIHtcbiAgICAgICAgICAgIC8vIHMwIDo9ICh3W2ktMTVdIHJpZ2h0cm90YXRlIDEpIHhvciAod1tpLTE1XSByaWdodHJvdGF0ZSA4KSB4b3IgKHdbaS0xNV0gcmlnaHRzaGlmdCA3KVxuICAgICAgICAgICAgY29uc3QgVzE1aCA9IFNIQTUxMl9XX0hbaSAtIDE1XSB8IDA7XG4gICAgICAgICAgICBjb25zdCBXMTVsID0gU0hBNTEyX1dfTFtpIC0gMTVdIHwgMDtcbiAgICAgICAgICAgIGNvbnN0IHMwaCA9IHU2NC5yb3RyU0goVzE1aCwgVzE1bCwgMSkgXiB1NjQucm90clNIKFcxNWgsIFcxNWwsIDgpIF4gdTY0LnNoclNIKFcxNWgsIFcxNWwsIDcpO1xuICAgICAgICAgICAgY29uc3QgczBsID0gdTY0LnJvdHJTTChXMTVoLCBXMTVsLCAxKSBeIHU2NC5yb3RyU0woVzE1aCwgVzE1bCwgOCkgXiB1NjQuc2hyU0woVzE1aCwgVzE1bCwgNyk7XG4gICAgICAgICAgICAvLyBzMSA6PSAod1tpLTJdIHJpZ2h0cm90YXRlIDE5KSB4b3IgKHdbaS0yXSByaWdodHJvdGF0ZSA2MSkgeG9yICh3W2ktMl0gcmlnaHRzaGlmdCA2KVxuICAgICAgICAgICAgY29uc3QgVzJoID0gU0hBNTEyX1dfSFtpIC0gMl0gfCAwO1xuICAgICAgICAgICAgY29uc3QgVzJsID0gU0hBNTEyX1dfTFtpIC0gMl0gfCAwO1xuICAgICAgICAgICAgY29uc3QgczFoID0gdTY0LnJvdHJTSChXMmgsIFcybCwgMTkpIF4gdTY0LnJvdHJCSChXMmgsIFcybCwgNjEpIF4gdTY0LnNoclNIKFcyaCwgVzJsLCA2KTtcbiAgICAgICAgICAgIGNvbnN0IHMxbCA9IHU2NC5yb3RyU0woVzJoLCBXMmwsIDE5KSBeIHU2NC5yb3RyQkwoVzJoLCBXMmwsIDYxKSBeIHU2NC5zaHJTTChXMmgsIFcybCwgNik7XG4gICAgICAgICAgICAvLyBTSEE1MTJfV1tpXSA9IHMwICsgczEgKyBTSEE1MTJfV1tpIC0gN10gKyBTSEE1MTJfV1tpIC0gMTZdO1xuICAgICAgICAgICAgY29uc3QgU1VNbCA9IHU2NC5hZGQ0TChzMGwsIHMxbCwgU0hBNTEyX1dfTFtpIC0gN10sIFNIQTUxMl9XX0xbaSAtIDE2XSk7XG4gICAgICAgICAgICBjb25zdCBTVU1oID0gdTY0LmFkZDRIKFNVTWwsIHMwaCwgczFoLCBTSEE1MTJfV19IW2kgLSA3XSwgU0hBNTEyX1dfSFtpIC0gMTZdKTtcbiAgICAgICAgICAgIFNIQTUxMl9XX0hbaV0gPSBTVU1oIHwgMDtcbiAgICAgICAgICAgIFNIQTUxMl9XX0xbaV0gPSBTVU1sIHwgMDtcbiAgICAgICAgfVxuICAgICAgICBsZXQgeyBBaCwgQWwsIEJoLCBCbCwgQ2gsIENsLCBEaCwgRGwsIEVoLCBFbCwgRmgsIEZsLCBHaCwgR2wsIEhoLCBIbCB9ID0gdGhpcztcbiAgICAgICAgLy8gQ29tcHJlc3Npb24gZnVuY3Rpb24gbWFpbiBsb29wLCA4MCByb3VuZHNcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCA4MDsgaSsrKSB7XG4gICAgICAgICAgICAvLyBTMSA6PSAoZSByaWdodHJvdGF0ZSAxNCkgeG9yIChlIHJpZ2h0cm90YXRlIDE4KSB4b3IgKGUgcmlnaHRyb3RhdGUgNDEpXG4gICAgICAgICAgICBjb25zdCBzaWdtYTFoID0gdTY0LnJvdHJTSChFaCwgRWwsIDE0KSBeIHU2NC5yb3RyU0goRWgsIEVsLCAxOCkgXiB1NjQucm90ckJIKEVoLCBFbCwgNDEpO1xuICAgICAgICAgICAgY29uc3Qgc2lnbWExbCA9IHU2NC5yb3RyU0woRWgsIEVsLCAxNCkgXiB1NjQucm90clNMKEVoLCBFbCwgMTgpIF4gdTY0LnJvdHJCTChFaCwgRWwsIDQxKTtcbiAgICAgICAgICAgIC8vY29uc3QgVDEgPSAoSCArIHNpZ21hMSArIENoaShFLCBGLCBHKSArIFNIQTI1Nl9LW2ldICsgU0hBMjU2X1dbaV0pIHwgMDtcbiAgICAgICAgICAgIGNvbnN0IENISWggPSAoRWggJiBGaCkgXiAofkVoICYgR2gpO1xuICAgICAgICAgICAgY29uc3QgQ0hJbCA9IChFbCAmIEZsKSBeICh+RWwgJiBHbCk7XG4gICAgICAgICAgICAvLyBUMSA9IEggKyBzaWdtYTEgKyBDaGkoRSwgRiwgRykgKyBTSEE1MTJfS1tpXSArIFNIQTUxMl9XW2ldXG4gICAgICAgICAgICAvLyBwcmV0dGllci1pZ25vcmVcbiAgICAgICAgICAgIGNvbnN0IFQxbGwgPSB1NjQuYWRkNUwoSGwsIHNpZ21hMWwsIENISWwsIFNIQTUxMl9LbFtpXSwgU0hBNTEyX1dfTFtpXSk7XG4gICAgICAgICAgICBjb25zdCBUMWggPSB1NjQuYWRkNUgoVDFsbCwgSGgsIHNpZ21hMWgsIENISWgsIFNIQTUxMl9LaFtpXSwgU0hBNTEyX1dfSFtpXSk7XG4gICAgICAgICAgICBjb25zdCBUMWwgPSBUMWxsIHwgMDtcbiAgICAgICAgICAgIC8vIFMwIDo9IChhIHJpZ2h0cm90YXRlIDI4KSB4b3IgKGEgcmlnaHRyb3RhdGUgMzQpIHhvciAoYSByaWdodHJvdGF0ZSAzOSlcbiAgICAgICAgICAgIGNvbnN0IHNpZ21hMGggPSB1NjQucm90clNIKEFoLCBBbCwgMjgpIF4gdTY0LnJvdHJCSChBaCwgQWwsIDM0KSBeIHU2NC5yb3RyQkgoQWgsIEFsLCAzOSk7XG4gICAgICAgICAgICBjb25zdCBzaWdtYTBsID0gdTY0LnJvdHJTTChBaCwgQWwsIDI4KSBeIHU2NC5yb3RyQkwoQWgsIEFsLCAzNCkgXiB1NjQucm90ckJMKEFoLCBBbCwgMzkpO1xuICAgICAgICAgICAgY29uc3QgTUFKaCA9IChBaCAmIEJoKSBeIChBaCAmIENoKSBeIChCaCAmIENoKTtcbiAgICAgICAgICAgIGNvbnN0IE1BSmwgPSAoQWwgJiBCbCkgXiAoQWwgJiBDbCkgXiAoQmwgJiBDbCk7XG4gICAgICAgICAgICBIaCA9IEdoIHwgMDtcbiAgICAgICAgICAgIEhsID0gR2wgfCAwO1xuICAgICAgICAgICAgR2ggPSBGaCB8IDA7XG4gICAgICAgICAgICBHbCA9IEZsIHwgMDtcbiAgICAgICAgICAgIEZoID0gRWggfCAwO1xuICAgICAgICAgICAgRmwgPSBFbCB8IDA7XG4gICAgICAgICAgICAoeyBoOiBFaCwgbDogRWwgfSA9IHU2NC5hZGQoRGggfCAwLCBEbCB8IDAsIFQxaCB8IDAsIFQxbCB8IDApKTtcbiAgICAgICAgICAgIERoID0gQ2ggfCAwO1xuICAgICAgICAgICAgRGwgPSBDbCB8IDA7XG4gICAgICAgICAgICBDaCA9IEJoIHwgMDtcbiAgICAgICAgICAgIENsID0gQmwgfCAwO1xuICAgICAgICAgICAgQmggPSBBaCB8IDA7XG4gICAgICAgICAgICBCbCA9IEFsIHwgMDtcbiAgICAgICAgICAgIGNvbnN0IEFsbCA9IHU2NC5hZGQzTChUMWwsIHNpZ21hMGwsIE1BSmwpO1xuICAgICAgICAgICAgQWggPSB1NjQuYWRkM0goQWxsLCBUMWgsIHNpZ21hMGgsIE1BSmgpO1xuICAgICAgICAgICAgQWwgPSBBbGwgfCAwO1xuICAgICAgICB9XG4gICAgICAgIC8vIEFkZCB0aGUgY29tcHJlc3NlZCBjaHVuayB0byB0aGUgY3VycmVudCBoYXNoIHZhbHVlXG4gICAgICAgICh7IGg6IEFoLCBsOiBBbCB9ID0gdTY0LmFkZCh0aGlzLkFoIHwgMCwgdGhpcy5BbCB8IDAsIEFoIHwgMCwgQWwgfCAwKSk7XG4gICAgICAgICh7IGg6IEJoLCBsOiBCbCB9ID0gdTY0LmFkZCh0aGlzLkJoIHwgMCwgdGhpcy5CbCB8IDAsIEJoIHwgMCwgQmwgfCAwKSk7XG4gICAgICAgICh7IGg6IENoLCBsOiBDbCB9ID0gdTY0LmFkZCh0aGlzLkNoIHwgMCwgdGhpcy5DbCB8IDAsIENoIHwgMCwgQ2wgfCAwKSk7XG4gICAgICAgICh7IGg6IERoLCBsOiBEbCB9ID0gdTY0LmFkZCh0aGlzLkRoIHwgMCwgdGhpcy5EbCB8IDAsIERoIHwgMCwgRGwgfCAwKSk7XG4gICAgICAgICh7IGg6IEVoLCBsOiBFbCB9ID0gdTY0LmFkZCh0aGlzLkVoIHwgMCwgdGhpcy5FbCB8IDAsIEVoIHwgMCwgRWwgfCAwKSk7XG4gICAgICAgICh7IGg6IEZoLCBsOiBGbCB9ID0gdTY0LmFkZCh0aGlzLkZoIHwgMCwgdGhpcy5GbCB8IDAsIEZoIHwgMCwgRmwgfCAwKSk7XG4gICAgICAgICh7IGg6IEdoLCBsOiBHbCB9ID0gdTY0LmFkZCh0aGlzLkdoIHwgMCwgdGhpcy5HbCB8IDAsIEdoIHwgMCwgR2wgfCAwKSk7XG4gICAgICAgICh7IGg6IEhoLCBsOiBIbCB9ID0gdTY0LmFkZCh0aGlzLkhoIHwgMCwgdGhpcy5IbCB8IDAsIEhoIHwgMCwgSGwgfCAwKSk7XG4gICAgICAgIHRoaXMuc2V0KEFoLCBBbCwgQmgsIEJsLCBDaCwgQ2wsIERoLCBEbCwgRWgsIEVsLCBGaCwgRmwsIEdoLCBHbCwgSGgsIEhsKTtcbiAgICB9XG4gICAgcm91bmRDbGVhbigpIHtcbiAgICAgICAgY2xlYW4oU0hBNTEyX1dfSCwgU0hBNTEyX1dfTCk7XG4gICAgfVxuICAgIGRlc3Ryb3koKSB7XG4gICAgICAgIC8vIEhhc2hNRCBjYWxsZXJzIHJvdXRlIHBvc3QtZGVzdHJveSB1c2FiaWxpdHkgdGhyb3VnaCBgZGVzdHJveWVkYDsgemVyb2l6aW5nIGFsb25lIHN0aWxsIGxlYXZlc1xuICAgICAgICAvLyB1cGRhdGUoKS9kaWdlc3QoKSBjYWxsYWJsZSBvbiByZXVzZWQgaW5zdGFuY2VzLlxuICAgICAgICB0aGlzLmRlc3Ryb3llZCA9IHRydWU7XG4gICAgICAgIGNsZWFuKHRoaXMuYnVmZmVyKTtcbiAgICAgICAgdGhpcy5zZXQoMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCwgMCk7XG4gICAgfVxufVxuLyoqIEludGVybmFsIFNIQS01MTIgaGFzaCBjbGFzcyBncm91bmRlZCBpbiBSRkMgNjIzNCDCpzYuMyBhbmQgwqc2LjQuICovXG5leHBvcnQgY2xhc3MgX1NIQTUxMiBleHRlbmRzIFNIQTJfNjRCIHtcbiAgICBBaCA9IFNIQTUxMl9JVlswXSB8IDA7XG4gICAgQWwgPSBTSEE1MTJfSVZbMV0gfCAwO1xuICAgIEJoID0gU0hBNTEyX0lWWzJdIHwgMDtcbiAgICBCbCA9IFNIQTUxMl9JVlszXSB8IDA7XG4gICAgQ2ggPSBTSEE1MTJfSVZbNF0gfCAwO1xuICAgIENsID0gU0hBNTEyX0lWWzVdIHwgMDtcbiAgICBEaCA9IFNIQTUxMl9JVls2XSB8IDA7XG4gICAgRGwgPSBTSEE1MTJfSVZbN10gfCAwO1xuICAgIEVoID0gU0hBNTEyX0lWWzhdIHwgMDtcbiAgICBFbCA9IFNIQTUxMl9JVls5XSB8IDA7XG4gICAgRmggPSBTSEE1MTJfSVZbMTBdIHwgMDtcbiAgICBGbCA9IFNIQTUxMl9JVlsxMV0gfCAwO1xuICAgIEdoID0gU0hBNTEyX0lWWzEyXSB8IDA7XG4gICAgR2wgPSBTSEE1MTJfSVZbMTNdIHwgMDtcbiAgICBIaCA9IFNIQTUxMl9JVlsxNF0gfCAwO1xuICAgIEhsID0gU0hBNTEyX0lWWzE1XSB8IDA7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKDY0KTtcbiAgICB9XG59XG4vKiogSW50ZXJuYWwgU0hBLTM4NCBoYXNoIGNsYXNzIGdyb3VuZGVkIGluIFJGQyA2MjM0IMKnNi4zIGFuZCDCpzYuNC4gKi9cbmV4cG9ydCBjbGFzcyBfU0hBMzg0IGV4dGVuZHMgU0hBMl82NEIge1xuICAgIEFoID0gU0hBMzg0X0lWWzBdIHwgMDtcbiAgICBBbCA9IFNIQTM4NF9JVlsxXSB8IDA7XG4gICAgQmggPSBTSEEzODRfSVZbMl0gfCAwO1xuICAgIEJsID0gU0hBMzg0X0lWWzNdIHwgMDtcbiAgICBDaCA9IFNIQTM4NF9JVls0XSB8IDA7XG4gICAgQ2wgPSBTSEEzODRfSVZbNV0gfCAwO1xuICAgIERoID0gU0hBMzg0X0lWWzZdIHwgMDtcbiAgICBEbCA9IFNIQTM4NF9JVls3XSB8IDA7XG4gICAgRWggPSBTSEEzODRfSVZbOF0gfCAwO1xuICAgIEVsID0gU0hBMzg0X0lWWzldIHwgMDtcbiAgICBGaCA9IFNIQTM4NF9JVlsxMF0gfCAwO1xuICAgIEZsID0gU0hBMzg0X0lWWzExXSB8IDA7XG4gICAgR2ggPSBTSEEzODRfSVZbMTJdIHwgMDtcbiAgICBHbCA9IFNIQTM4NF9JVlsxM10gfCAwO1xuICAgIEhoID0gU0hBMzg0X0lWWzE0XSB8IDA7XG4gICAgSGwgPSBTSEEzODRfSVZbMTVdIHwgMDtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoNDgpO1xuICAgIH1cbn1cbi8qKlxuICogVHJ1bmNhdGVkIFNIQTUxMi8yNTYgYW5kIFNIQTUxMi8yMjQuXG4gKiBTSEE1MTJfSVYgaXMgWE9SZWQgd2l0aCAweGE1YTVhNWE1YTVhNWE1YTUsIHRoZW4gdXNlZCBhcyBcImludGVybWVkaWFyeVwiIElWIG9mIFNIQTUxMi90LlxuICogVGhlbiB0IGhhc2hlcyBzdHJpbmcgdG8gcHJvZHVjZSByZXN1bHQgSVYuXG4gKiBTZWUgdGhlIHJlcG8tc2lkZSBkZXJpdmF0aW9uIHJlY2lwZSBpbiBgdGVzdC9taXNjL3NoYTItZ2VuLWl2LmpzYC5cbiAqIFRoZXNlIElWIGxpdGVyYWxzIGFyZSBjaGVja2VkIGFnYWluc3QgdGhhdCBzY3JpcHQgcmF0aGVyIHRoYW4gYSBkZWRpY2F0ZWRcbiAqIGxvY2FsIFJGQyBzZWN0aW9uLlxuICovXG4vKiogU0hBLTUxMi8yMjQgSVYgZGVyaXZlZCBieSB0aGUgU0hBLTUxMi90IHJlY2lwZSBpbiBgdGVzdC9taXNjL3NoYTItZ2VuLWl2LmpzYCBhbmRcbiAqIHN0b3JlZCBhcyBzaXh0ZWVuIGJpZy1lbmRpYW4gMzItYml0IGhhbHZlcy4gKi9cbmNvbnN0IFQyMjRfSVYgPSAvKiBAX19QVVJFX18gKi8gVWludDMyQXJyYXkuZnJvbShbXG4gICAgMHg4YzNkMzdjOCwgMHgxOTU0NGRhMiwgMHg3M2UxOTk2NiwgMHg4OWRjZDRkNiwgMHgxZGZhYjdhZSwgMHgzMmZmOWM4MiwgMHg2NzlkZDUxNCwgMHg1ODJmOWZjZixcbiAgICAweDBmNmQyYjY5LCAweDdiZDQ0ZGE4LCAweDc3ZTM2ZjczLCAweDA0YzQ4OTQyLCAweDNmOWQ4NWE4LCAweDZhMWQzNmM4LCAweDExMTJlNmFkLCAweDkxZDY5MmExLFxuXSk7XG4vKiogU0hBLTUxMi8yNTYgSVYgZGVyaXZlZCBieSB0aGUgU0hBLTUxMi90IHJlY2lwZSBpbiBgdGVzdC9taXNjL3NoYTItZ2VuLWl2LmpzYCBhbmRcbiAqIHN0b3JlZCBhcyBzaXh0ZWVuIGJpZy1lbmRpYW4gMzItYml0IGhhbHZlcy4gKi9cbmNvbnN0IFQyNTZfSVYgPSAvKiBAX19QVVJFX18gKi8gVWludDMyQXJyYXkuZnJvbShbXG4gICAgMHgyMjMxMjE5NCwgMHhmYzJiZjcyYywgMHg5ZjU1NWZhMywgMHhjODRjNjRjMiwgMHgyMzkzYjg2YiwgMHg2ZjUzYjE1MSwgMHg5NjM4NzcxOSwgMHg1OTQwZWFiZCxcbiAgICAweDk2MjgzZWUyLCAweGE4OGVmZmUzLCAweGJlNWUxZTI1LCAweDUzODYzOTkyLCAweDJiMDE5OWZjLCAweDJjODViOGFhLCAweDBlYjcyZGRjLCAweDgxYzUyY2EyLFxuXSk7XG4vKiogSW50ZXJuYWwgU0hBLTUxMi8yMjQgaGFzaCBjbGFzcyB1c2luZyB0aGUgZGVyaXZlZCBgVDIyNF9JVmAgYW5kIHRoZSBzaGFyZWRcbiAqIFJGQyA2MjM0IMKnNi40IGNvbXByZXNzaW9uIGVuZ2luZS4gKi9cbmV4cG9ydCBjbGFzcyBfU0hBNTEyXzIyNCBleHRlbmRzIFNIQTJfNjRCIHtcbiAgICBBaCA9IFQyMjRfSVZbMF0gfCAwO1xuICAgIEFsID0gVDIyNF9JVlsxXSB8IDA7XG4gICAgQmggPSBUMjI0X0lWWzJdIHwgMDtcbiAgICBCbCA9IFQyMjRfSVZbM10gfCAwO1xuICAgIENoID0gVDIyNF9JVls0XSB8IDA7XG4gICAgQ2wgPSBUMjI0X0lWWzVdIHwgMDtcbiAgICBEaCA9IFQyMjRfSVZbNl0gfCAwO1xuICAgIERsID0gVDIyNF9JVls3XSB8IDA7XG4gICAgRWggPSBUMjI0X0lWWzhdIHwgMDtcbiAgICBFbCA9IFQyMjRfSVZbOV0gfCAwO1xuICAgIEZoID0gVDIyNF9JVlsxMF0gfCAwO1xuICAgIEZsID0gVDIyNF9JVlsxMV0gfCAwO1xuICAgIEdoID0gVDIyNF9JVlsxMl0gfCAwO1xuICAgIEdsID0gVDIyNF9JVlsxM10gfCAwO1xuICAgIEhoID0gVDIyNF9JVlsxNF0gfCAwO1xuICAgIEhsID0gVDIyNF9JVlsxNV0gfCAwO1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlcigyOCk7XG4gICAgfVxufVxuLyoqIEludGVybmFsIFNIQS01MTIvMjU2IGhhc2ggY2xhc3MgdXNpbmcgdGhlIGRlcml2ZWQgYFQyNTZfSVZgIGFuZCB0aGUgc2hhcmVkXG4gKiBSRkMgNjIzNCDCpzYuNCBjb21wcmVzc2lvbiBlbmdpbmUuICovXG5leHBvcnQgY2xhc3MgX1NIQTUxMl8yNTYgZXh0ZW5kcyBTSEEyXzY0QiB7XG4gICAgQWggPSBUMjU2X0lWWzBdIHwgMDtcbiAgICBBbCA9IFQyNTZfSVZbMV0gfCAwO1xuICAgIEJoID0gVDI1Nl9JVlsyXSB8IDA7XG4gICAgQmwgPSBUMjU2X0lWWzNdIHwgMDtcbiAgICBDaCA9IFQyNTZfSVZbNF0gfCAwO1xuICAgIENsID0gVDI1Nl9JVls1XSB8IDA7XG4gICAgRGggPSBUMjU2X0lWWzZdIHwgMDtcbiAgICBEbCA9IFQyNTZfSVZbN10gfCAwO1xuICAgIEVoID0gVDI1Nl9JVls4XSB8IDA7XG4gICAgRWwgPSBUMjU2X0lWWzldIHwgMDtcbiAgICBGaCA9IFQyNTZfSVZbMTBdIHwgMDtcbiAgICBGbCA9IFQyNTZfSVZbMTFdIHwgMDtcbiAgICBHaCA9IFQyNTZfSVZbMTJdIHwgMDtcbiAgICBHbCA9IFQyNTZfSVZbMTNdIHwgMDtcbiAgICBIaCA9IFQyNTZfSVZbMTRdIHwgMDtcbiAgICBIbCA9IFQyNTZfSVZbMTVdIHwgMDtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoMzIpO1xuICAgIH1cbn1cbi8qKlxuICogU0hBMi0yNTYgaGFzaCBmdW5jdGlvbiBmcm9tIFJGQyA0NjM0LiBJbiBKUyBpdCdzIHRoZSBmYXN0ZXN0OiBldmVuIGZhc3RlciB0aGFuIEJsYWtlMy4gU29tZSBpbmZvOlxuICpcbiAqIC0gVHJ5aW5nIDJeMTI4IGhhc2hlcyB3b3VsZCBnZXQgNTAlIGNoYW5jZSBvZiBjb2xsaXNpb24sIHVzaW5nIGJpcnRoZGF5IGF0dGFjay5cbiAqIC0gQlRDIG5ldHdvcmsgaXMgZG9pbmcgMl43MCBoYXNoZXMvc2VjICgyXjk1IGhhc2hlcy95ZWFyKSBhcyBwZXIgMjAyNS5cbiAqIC0gRWFjaCBzaGEyNTYgaGFzaCBpcyBleGVjdXRpbmcgMl4xOCBiaXQgb3BlcmF0aW9ucy5cbiAqIC0gR29vZCAyMDI0IEFTSUNzIGNhbiBkbyAyMDBUaC9zZWMgd2l0aCAzNTAwIHdhdHRzIG9mIHBvd2VyLCBjb3JyZXNwb25kaW5nIHRvIDJeMzYgaGFzaGVzL2pvdWxlLlxuICogQHBhcmFtIG1zZyAtIG1lc3NhZ2UgYnl0ZXMgdG8gaGFzaFxuICogQHJldHVybnMgRGlnZXN0IGJ5dGVzLlxuICogQGV4YW1wbGVcbiAqIEhhc2ggYSBtZXNzYWdlIHdpdGggU0hBMi0yNTYuXG4gKiBgYGB0c1xuICogc2hhMjU2KG5ldyBVaW50OEFycmF5KFs5NywgOTgsIDk5XSkpO1xuICogYGBgXG4gKi9cbmV4cG9ydCBjb25zdCBzaGEyNTYgPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlSGFzaGVyKCgpID0+IG5ldyBfU0hBMjU2KCksIFxuLyogQF9fUFVSRV9fICovIG9pZE5pc3QoMHgwMSkpO1xuLyoqXG4gKiBTSEEyLTIyNCBoYXNoIGZ1bmN0aW9uIGZyb20gUkZDIDQ2MzQuXG4gKiBAcGFyYW0gbXNnIC0gbWVzc2FnZSBieXRlcyB0byBoYXNoXG4gKiBAcmV0dXJucyBEaWdlc3QgYnl0ZXMuXG4gKiBAZXhhbXBsZVxuICogSGFzaCBhIG1lc3NhZ2Ugd2l0aCBTSEEyLTIyNC5cbiAqIGBgYHRzXG4gKiBzaGEyMjQobmV3IFVpbnQ4QXJyYXkoWzk3LCA5OCwgOTldKSk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGNvbnN0IHNoYTIyNCA9IC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVIYXNoZXIoKCkgPT4gbmV3IF9TSEEyMjQoKSwgXG4vKiBAX19QVVJFX18gKi8gb2lkTmlzdCgweDA0KSk7XG4vKipcbiAqIFNIQTItNTEyIGhhc2ggZnVuY3Rpb24gZnJvbSBSRkMgNDYzNC5cbiAqIEBwYXJhbSBtc2cgLSBtZXNzYWdlIGJ5dGVzIHRvIGhhc2hcbiAqIEByZXR1cm5zIERpZ2VzdCBieXRlcy5cbiAqIEBleGFtcGxlXG4gKiBIYXNoIGEgbWVzc2FnZSB3aXRoIFNIQTItNTEyLlxuICogYGBgdHNcbiAqIHNoYTUxMihuZXcgVWludDhBcnJheShbOTcsIDk4LCA5OV0pKTtcbiAqIGBgYFxuICovXG5leHBvcnQgY29uc3Qgc2hhNTEyID0gLyogQF9fUFVSRV9fICovIGNyZWF0ZUhhc2hlcigoKSA9PiBuZXcgX1NIQTUxMigpLCBcbi8qIEBfX1BVUkVfXyAqLyBvaWROaXN0KDB4MDMpKTtcbi8qKlxuICogU0hBMi0zODQgaGFzaCBmdW5jdGlvbiBmcm9tIFJGQyA0NjM0LlxuICogQHBhcmFtIG1zZyAtIG1lc3NhZ2UgYnl0ZXMgdG8gaGFzaFxuICogQHJldHVybnMgRGlnZXN0IGJ5dGVzLlxuICogQGV4YW1wbGVcbiAqIEhhc2ggYSBtZXNzYWdlIHdpdGggU0hBMi0zODQuXG4gKiBgYGB0c1xuICogc2hhMzg0KG5ldyBVaW50OEFycmF5KFs5NywgOTgsIDk5XSkpO1xuICogYGBgXG4gKi9cbmV4cG9ydCBjb25zdCBzaGEzODQgPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlSGFzaGVyKCgpID0+IG5ldyBfU0hBMzg0KCksIFxuLyogQF9fUFVSRV9fICovIG9pZE5pc3QoMHgwMikpO1xuLyoqXG4gKiBTSEEyLTUxMi8yNTYgXCJ0cnVuY2F0ZWRcIiBoYXNoIGZ1bmN0aW9uLCB3aXRoIGltcHJvdmVkIHJlc2lzdGFuY2UgdG8gbGVuZ3RoIGV4dGVuc2lvbiBhdHRhY2tzLlxuICogU2VlIHRoZSBwYXBlciBvbiB7QGxpbmsgaHR0cHM6Ly9lcHJpbnQuaWFjci5vcmcvMjAxMC81NDgucGRmIHwgdHJ1bmNhdGVkIFNIQTUxMn0uXG4gKiBAcGFyYW0gbXNnIC0gbWVzc2FnZSBieXRlcyB0byBoYXNoXG4gKiBAcmV0dXJucyBEaWdlc3QgYnl0ZXMuXG4gKiBAZXhhbXBsZVxuICogSGFzaCBhIG1lc3NhZ2Ugd2l0aCBTSEEyLTUxMi8yNTYuXG4gKiBgYGB0c1xuICogc2hhNTEyXzI1NihuZXcgVWludDhBcnJheShbOTcsIDk4LCA5OV0pKTtcbiAqIGBgYFxuICovXG5leHBvcnQgY29uc3Qgc2hhNTEyXzI1NiA9IC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVIYXNoZXIoKCkgPT4gbmV3IF9TSEE1MTJfMjU2KCksIFxuLyogQF9fUFVSRV9fICovIG9pZE5pc3QoMHgwNikpO1xuLyoqXG4gKiBTSEEyLTUxMi8yMjQgXCJ0cnVuY2F0ZWRcIiBoYXNoIGZ1bmN0aW9uLCB3aXRoIGltcHJvdmVkIHJlc2lzdGFuY2UgdG8gbGVuZ3RoIGV4dGVuc2lvbiBhdHRhY2tzLlxuICogU2VlIHRoZSBwYXBlciBvbiB7QGxpbmsgaHR0cHM6Ly9lcHJpbnQuaWFjci5vcmcvMjAxMC81NDgucGRmIHwgdHJ1bmNhdGVkIFNIQTUxMn0uXG4gKiBAcGFyYW0gbXNnIC0gbWVzc2FnZSBieXRlcyB0byBoYXNoXG4gKiBAcmV0dXJucyBEaWdlc3QgYnl0ZXMuXG4gKiBAZXhhbXBsZVxuICogSGFzaCBhIG1lc3NhZ2Ugd2l0aCBTSEEyLTUxMi8yMjQuXG4gKiBgYGB0c1xuICogc2hhNTEyXzIyNChuZXcgVWludDhBcnJheShbOTcsIDk4LCA5OV0pKTtcbiAqIGBgYFxuICovXG5leHBvcnQgY29uc3Qgc2hhNTEyXzIyNCA9IC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVIYXNoZXIoKCkgPT4gbmV3IF9TSEE1MTJfMjI0KCksIFxuLyogQF9fUFVSRV9fICovIG9pZE5pc3QoMHgwNSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c2hhMi5qcy5tYXAiLCJpbXBvcnQqYXMgZSBmcm9tXCJAbm9ibGUvZWQyNTUxOVwiO2ltcG9ydHtzaGE1MTIgYXMgcn1mcm9tXCJAbm9ibGUvaGFzaGVzL3NoYTIuanNcIjt2YXIgdD1PYmplY3QuZGVmaW5lUHJvcGVydHksaT1PYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzLG49T2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eSxhPU9iamVjdC5wcm90b3R5cGUucHJvcGVydHlJc0VudW1lcmFibGUsbz0oZSxyLGkpPT5yIGluIGU/dChlLHIse2VudW1lcmFibGU6ITAsY29uZmlndXJhYmxlOiEwLHdyaXRhYmxlOiEwLHZhbHVlOml9KTplW3JdPWksdT0oZSxyLHQpPT5uZXcgUHJvbWlzZSgoaSxuKT0+e3ZhciBhPWU9Pnt0cnl7dSh0Lm5leHQoZSkpfWNhdGNoKGUpe24oZSl9fSxvPWU9Pnt0cnl7dSh0LnRocm93KGUpKX1jYXRjaChlKXtuKGUpfX0sdT1lPT5lLmRvbmU/aShlLnZhbHVlKTpQcm9taXNlLnJlc29sdmUoZS52YWx1ZSkudGhlbihhLG8pO3UoKHQ9dC5hcHBseShlLHIpKS5uZXh0KCkpfSk7ZnVuY3Rpb24gYyhlKXtjb25zdCByPXt9O2ZvcihsZXQgZT0wO2U8NjQ7ZSsrKXJbXCJBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OS1fXCJbZV1dPWU7Y29uc3QgdD1lLnJlcGxhY2UoLz0rJC8sXCJcIiksaT1NYXRoLmZsb29yKDYqdC5sZW5ndGgvOCksbj1uZXcgVWludDhBcnJheShpKTtsZXQgYT0wLG89MCx1PTA7Zm9yKGxldCBlPTA7ZTx0Lmxlbmd0aDtlKyspe2NvbnN0IGk9clt0W2VdXTtpZih2b2lkIDA9PT1pKXRocm93IG5ldyBFcnJvcihcIkludmFsaWQgYmFzZTY0dXJsIGNoYXJhY3RlclwiKTthPWE8PDZ8aSxvKz02LG8+PTgmJihvLT04LG5bdSsrXT1hPj5vJjI1NSl9cmV0dXJuIG59dmFyIHM9MzAsbD1cInByaW1ldWlcIixkPVwicHJpbWV1aS1wcm86XCIscD17cHJpbWV1aTpcInByaW1ldWlcIixzY2hlZHVsZXI6XCJwcmltZXVpLXBybzpzY2hlZHVsZXJcIix0ZXh0ZWRpdG9yOlwicHJpbWV1aS1wcm86dGV4dC1lZGl0b3JcIixjaGFydHM6XCJwcmltZXVpLXBybzpjaGFydHNcIixkaWFncmFtOlwicHJpbWV1aS1wcm86ZGlhZ3JhbVwiLHBkZnZpZXdlcjpcInByaW1ldWktcHJvOnBkZi12aWV3ZXJcIix0YXNrYm9hcmQ6XCJwcmltZXVpLXBybzp0YXNrLWJvYXJkXCIsZGF0YWdyaWQ6XCJwcmltZXVpLXBybzpkYXRhZ3JpZFwiLGdhbnR0Y2hhcnQ6XCJwcmltZXVpLXBybzpnYW50dC1jaGFydFwiLGZpbGVtYW5hZ2VyOlwicHJpbWV1aS1wcm86ZmlsZS1tYW5hZ2VyXCJ9LGY9e3ByaW1ldWk6XCJQcmltZVVJXCIsc2NoZWR1bGVyOlwiU2NoZWR1bGVyXCIsdGV4dGVkaXRvcjpcIlRleHRFZGl0b3JcIixjaGFydHM6XCJDaGFydHNcIixkaWFncmFtOlwiRGlhZ3JhbVwiLHBkZnZpZXdlcjpcIlBERiBWaWV3ZXJcIix0YXNrYm9hcmQ6XCJUYXNrIEJvYXJkXCIsZGF0YWdyaWQ6XCJEYXRhR3JpZFwiLGdhbnR0Y2hhcnQ6XCJHYW50dFwiLGZpbGVtYW5hZ2VyOlwiRmlsZSBNYW5hZ2VyXCJ9O2Z1bmN0aW9uIG0oZSxyPVwiUHJpbWVVSVwiKXtzd2l0Y2goZSl7Y2FzZVwiYWN0aXZlXCI6cmV0dXJuYCR7cn0gbGljZW5zZSBpcyBhY3RpdmUuYDtjYXNlXCJncmFjZVwiOnJldHVybmAke3J9IGxpY2Vuc2UgaXMgaW4gaXRzIGdyYWNlIHBlcmlvZC4gUmVuZXcgc29vbiB0byBrZWVwIHVzaW5nIHRoaXMgdmVyc2lvbi5gO2Nhc2VcImV4cGlyZWRcIjpyZXR1cm5gJHtyfSBsaWNlbnNlIGRvZXMgbm90IGNvdmVyIHRoaXMgdmVyc2lvbi4gUmVuZXcgYXQgcHJpbWV1aS5zdG9yZSwgb3IgZG93bmdyYWRlIHRvIGEgdmVyc2lvbiByZWxlYXNlZCB3aXRoaW4geW91ciB1cGRhdGVzIHdpbmRvdy5gO2Nhc2VcInRhbXBlcmVkXCI6cmV0dXJuYCR7cn0gbGljZW5zZSBzaWduYXR1cmUgaXMgaW52YWxpZC5gO2Nhc2VcIndyb25nLXByb2R1Y3RcIjpyZXR1cm5gTGljZW5zZSBkb2VzIG5vdCBjb3ZlciAke3J9LmA7Y2FzZVwibWlzc2luZ1wiOnJldHVybmBObyBsaWNlbnNlIGtleSBjb25maWd1cmVkIGZvciAke3J9LmA7Y2FzZVwiaW52YWxpZFwiOnJldHVybmAke3J9IGxpY2Vuc2UgaXMgbWFsZm9ybWVkLmA7Y2FzZVwidW5jb25maWd1cmVkXCI6cmV0dXJuYCR7cn0gbGljZW5zZSBpcyBub3QgY29uZmlndXJlZC5gO2RlZmF1bHQ6cmV0dXJuYCR7cn0gbGljZW5zZSBzdGF0dXMgdW5rbm93bi5gfX12YXIgeT04NjRlNTtmdW5jdGlvbiBnKGUscix0PXt9KXtyZXR1cm4oKGUscik9Pntmb3IodmFyIHQgaW4gcnx8KHI9e30pKW4uY2FsbChyLHQpJiZvKGUsdCxyW3RdKTtpZihpKWZvcih2YXIgdCBvZiBpKHIpKWEuY2FsbChyLHQpJiZvKGUsdCxyW3RdKTtyZXR1cm4gZX0pKHt2YWxpZDpcImFjdGl2ZVwiPT09ZXx8XCJncmFjZVwiPT09ZSxzdGF0dXM6ZSxtZXNzYWdlOm0oZSxyKX0sdCl9ZnVuY3Rpb24gdih0LGkpe3JldHVybiB1KHRoaXMsbnVsbCxmdW5jdGlvbiooKXt2YXIgbixhO2NvbnN0IG89aS5wcm9kdWN0TGFiZWw7aWYoXCJzdHJpbmdcIiE9dHlwZW9mIHR8fCF0LmluY2x1ZGVzKFwiLlwiKSlyZXR1cm4gZyhcImludmFsaWRcIixvKTtjb25zdCB1PXQuc3BsaXQoXCIuXCIpO2lmKDIhPT11Lmxlbmd0aClyZXR1cm4gZyhcImludmFsaWRcIixvKTtjb25zdFtzLHBdPXU7bGV0IGYsbSx2O3RyeXtmPWZ1bmN0aW9uKGUpe2NvbnN0IHI9YyhlKSx0PShuZXcgVGV4dERlY29kZXIpLmRlY29kZShyKTtyZXR1cm4gSlNPTi5wYXJzZSh0KX0ocyl9Y2F0Y2goZSl7cmV0dXJuIGcoXCJpbnZhbGlkXCIsbyl9aWYoIWZ8fFwib2JqZWN0XCIhPXR5cGVvZiBmfHxcInN0cmluZ1wiIT10eXBlb2YgZi5wcm9kdWN0fHxcInN0cmluZ1wiIT10eXBlb2YgZi50eXBlfHxcIm51bWJlclwiIT10eXBlb2YgZi5leHB8fFwibnVtYmVyXCIhPXR5cGVvZiBmLmlhdHx8XCJzdHJpbmdcIiE9dHlwZW9mIGYuaWQpcmV0dXJuIGcoXCJpbnZhbGlkXCIsbyk7dHJ5e209YyhwKSx2PShuZXcgVGV4dEVuY29kZXIpLmVuY29kZShzKX1jYXRjaChlKXtyZXR1cm4gZyhcImludmFsaWRcIixvKX1jb25zdCBoPW51bGwhPShuPWkucHVibGljS2V5T3ZlcnJpZGUpP246XCJkYWU3NWU2NmI5ZjU5YmViZjg3ZDRiYjI5Y2E2NDk0ZjM3ZGVjY2ZjYzJiMTMyYjk4ZWUxNTllZTc1MDUzNzNiXCI7bGV0IGI7dHJ5e2I9ZnVuY3Rpb24oZSl7aWYoZS5sZW5ndGglMiE9MCl0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIGhleCBsZW5ndGhcIik7Y29uc3Qgcj1uZXcgVWludDhBcnJheShlLmxlbmd0aC8yKTtmb3IobGV0IHQ9MDt0PHIubGVuZ3RoO3QrKylyW3RdPXBhcnNlSW50KGUuc3Vic3RyKDIqdCwyKSwxNik7cmV0dXJuIHJ9KGgpfWNhdGNoKGUpe3JldHVybiBnKFwiaW52YWxpZFwiLG8pfWxldCB3PSExO3RyeXtlLmV0Yy5zaGE1MTJTeW5jfHwoZS5ldGMuc2hhNTEyU3luYz0oLi4udCk9PnIoZS5ldGMuY29uY2F0Qnl0ZXMoLi4udCkpKSx3PWUudmVyaWZ5KG0sdixiKX1jYXRjaChlKXtyZXR1cm4gZyhcInRhbXBlcmVkXCIsbyx7cGF5bG9hZDpmfSl9aWYoIXcpcmV0dXJuIGcoXCJ0YW1wZXJlZFwiLG8se3BheWxvYWQ6Zn0pO2lmKCFmdW5jdGlvbihlLHIpe3JldHVybiBlLnByb2R1Y3Q9PT1yfHwhKCFyLnN0YXJ0c1dpdGgoZCl8fGUucHJvZHVjdCE9PWx8fFwiY29tbWVyY2lhbFwiIT09ZS50aWVyKX0oZixpLnByb2R1Y3QpKXJldHVybiBnKFwid3JvbmctcHJvZHVjdFwiLG8se3BheWxvYWQ6Zn0pO2NvbnN0IHg9MWUzKmYuZXhwLEQ9RGF0ZS5ub3coKSxPPU1hdGguZmxvb3IoKHgtRCkveSksUD1mdW5jdGlvbihlKXtpZih2b2lkIDA9PT1lKXJldHVybiBudWxsO2lmKFwibnVtYmVyXCI9PXR5cGVvZiBlKXJldHVybiAxZTMqZTtjb25zdCByPURhdGUucGFyc2UoZSk7cmV0dXJuIE51bWJlci5pc05hTihyKT9udWxsOnJ9KGkucmVsZWFzZURhdGUpO2lmKG51bGwhPT1QJiZQPngpcmV0dXJuIGcoXCJleHBpcmVkXCIsbyx7ZGF5c1VudGlsRXhwaXJ5Ok8scGF5bG9hZDpmfSk7aWYoZnVuY3Rpb24oZSl7cmV0dXJuXCJjb21tdW5pdHlcIj09PWUudGllcn0oZikpe2lmKEQ+eCsobnVsbCE9KGE9aS5ncmFjZURheXMpP2E6MzApKnkpcmV0dXJuIGcoXCJleHBpcmVkXCIsbyx7ZGF5c1VudGlsRXhwaXJ5Ok8scGF5bG9hZDpmfSk7aWYoRD54KXJldHVybiBnKFwiZ3JhY2VcIixvLHtkYXlzVW50aWxFeHBpcnk6TyxwYXlsb2FkOmZ9KX1yZXR1cm4gZyhcImFjdGl2ZVwiLG8se2RheXNVbnRpbEV4cGlyeTpPLHBheWxvYWQ6Zn0pfSl9ZnVuY3Rpb24gaChlLHIpe3JldHVybnt2YWxpZDohMSxzdGF0dXM6ZSxtZXNzYWdlOm0oZSxyKX19ZnVuY3Rpb24gYihlLHIpe2NvbnN0IHQ9bnVsbD09cj92b2lkIDA6ci5ncmFjZURheXMsaT1udWxsPT1yP3ZvaWQgMDpyLnB1YmxpY0tleU92ZXJyaWRlO3JldHVybnt2ZXJpZnkocixuKXtyZXR1cm4gdSh0aGlzLG51bGwsZnVuY3Rpb24qKCl7dmFyIGE7Y29uc3Qgbz1wW3JdLHU9bnVsbCE9KGE9ZltyXSk/YTpcIlByaW1lVUlcIixjPW51bGw9PW4/dm9pZCAwOm4ucmVsZWFzZURhdGU7aWYoIW8pcmV0dXJuIGgoXCJpbnZhbGlkXCIsdSk7Y29uc3Qgcz1lW3JdLGw9ZS5wcmltZXVpO2lmKHMpe2NvbnN0IGU9eWllbGQgdihzLHtwcm9kdWN0Om8scHJvZHVjdExhYmVsOnUscmVsZWFzZURhdGU6YyxncmFjZURheXM6dCxwdWJsaWNLZXlPdmVycmlkZTppfSk7aWYoZS52YWxpZClyZXR1cm4gZTtpZihcIndyb25nLXByb2R1Y3RcIiE9PWUuc3RhdHVzKXJldHVybiBlfXJldHVybiBsJiZcInByaW1ldWlcIiE9PXImJm8uc3RhcnRzV2l0aChkKT92KGwse3Byb2R1Y3Q6byxwcm9kdWN0TGFiZWw6dSxyZWxlYXNlRGF0ZTpjLGdyYWNlRGF5czp0LHB1YmxpY0tleU92ZXJyaWRlOml9KTpoKHM/XCJ3cm9uZy1wcm9kdWN0XCI6XCJtaXNzaW5nXCIsdSl9KX0saGFzKHIpe2NvbnN0IHQ9cFtyXTtyZXR1cm4hIXQmJighIWVbcl18fFwicHJpbWV1aVwiIT09ciYmdC5zdGFydHNXaXRoKGQpJiYhIWUucHJpbWV1aSl9fX12YXIgdz1udWxsO2Z1bmN0aW9uIHgoZSxyKXtpZighZSl0aHJvdyBuZXcgRXJyb3IoXCJbQHByaW1ldWkvbGljZW5zZS1tYW5hZ2VyXSByZWdpc3RlckxpY2Vuc2U6IGtleXMgYXJndW1lbnQgaXMgcmVxdWlyZWQuXCIpO3JldHVybiB3PWIoZSxyKX1mdW5jdGlvbiBEKCl7cmV0dXJuIHd9ZnVuY3Rpb24gTyhlLHIpe3ZhciB0O2lmKCF3KXtjb25zdCByPW51bGwhPSh0PWZbZV0pP3Q6XCJQcmltZVVJXCI7cmV0dXJuIFByb21pc2UucmVzb2x2ZSh7dmFsaWQ6ITEsc3RhdHVzOlwidW5jb25maWd1cmVkXCIsbWVzc2FnZTptKFwidW5jb25maWd1cmVkXCIscil9KX1yZXR1cm4gdy52ZXJpZnkoZSxyKX1leHBvcnR7cyBhcyBHUkFDRV9EQVlTLGwgYXMgUFJJTUVVSV9QUk9EVUNULGQgYXMgUFJJTUVVSV9QUk9fUFJFRklYLHAgYXMgUFJPRFVDVF9NQVAsZiBhcyBTSE9SVF9OQU1FX0xBQkVMUyxiIGFzIGNyZWF0ZUxpY2Vuc2VTZXJ2aWNlLG0gYXMgZm9ybWF0TGljZW5zZU1lc3NhZ2UsRCBhcyBnZXRMaWNlbnNlU2VydmljZSx4IGFzIHJlZ2lzdGVyTGljZW5zZSx2IGFzIHZlcmlmeSxPIGFzIHZlcmlmeUxpY2Vuc2V9OyIsImltcG9ydCB7IGVxdWFscywgcmVtb3ZlQWNjZW50cywgcmVzb2x2ZUZpZWxkRGF0YSB9IGZyb20gJ0BwcmltZXVpeC91dGlscy9vYmplY3QnO1xuXG52YXIgRmlsdGVyTWF0Y2hNb2RlID0ge1xuICBTVEFSVFNfV0lUSDogJ3N0YXJ0c1dpdGgnLFxuICBDT05UQUlOUzogJ2NvbnRhaW5zJyxcbiAgTk9UX0NPTlRBSU5TOiAnbm90Q29udGFpbnMnLFxuICBFTkRTX1dJVEg6ICdlbmRzV2l0aCcsXG4gIEVRVUFMUzogJ2VxdWFscycsXG4gIE5PVF9FUVVBTFM6ICdub3RFcXVhbHMnLFxuICBJTjogJ2luJyxcbiAgTEVTU19USEFOOiAnbHQnLFxuICBMRVNTX1RIQU5fT1JfRVFVQUxfVE86ICdsdGUnLFxuICBHUkVBVEVSX1RIQU46ICdndCcsXG4gIEdSRUFURVJfVEhBTl9PUl9FUVVBTF9UTzogJ2d0ZScsXG4gIEJFVFdFRU46ICdiZXR3ZWVuJyxcbiAgREFURV9JUzogJ2RhdGVJcycsXG4gIERBVEVfSVNfTk9UOiAnZGF0ZUlzTm90JyxcbiAgREFURV9CRUZPUkU6ICdkYXRlQmVmb3JlJyxcbiAgREFURV9BRlRFUjogJ2RhdGVBZnRlcidcbn07XG5cbnZhciBGaWx0ZXJPcGVyYXRvciA9IHtcbiAgQU5EOiAnYW5kJyxcbiAgT1I6ICdvcidcbn07XG5cbmZ1bmN0aW9uIF9jcmVhdGVGb3JPZkl0ZXJhdG9ySGVscGVyKHIsIGUpIHsgdmFyIHQgPSBcInVuZGVmaW5lZFwiICE9IHR5cGVvZiBTeW1ib2wgJiYgcltTeW1ib2wuaXRlcmF0b3JdIHx8IHJbXCJAQGl0ZXJhdG9yXCJdOyBpZiAoIXQpIHsgaWYgKEFycmF5LmlzQXJyYXkocikgfHwgKHQgPSBfdW5zdXBwb3J0ZWRJdGVyYWJsZVRvQXJyYXkocikpIHx8IGUpIHsgdCAmJiAociA9IHQpOyB2YXIgX24gPSAwLCBGID0gZnVuY3Rpb24gRigpIHt9OyByZXR1cm4geyBzOiBGLCBuOiBmdW5jdGlvbiBuKCkgeyByZXR1cm4gX24gPj0gci5sZW5ndGggPyB7IGRvbmU6IHRydWUgfSA6IHsgZG9uZTogZmFsc2UsIHZhbHVlOiByW19uKytdIH07IH0sIGU6IGZ1bmN0aW9uIGUocikgeyB0aHJvdyByOyB9LCBmOiBGIH07IH0gdGhyb3cgbmV3IFR5cGVFcnJvcihcIkludmFsaWQgYXR0ZW1wdCB0byBpdGVyYXRlIG5vbi1pdGVyYWJsZSBpbnN0YW5jZS5cXG5JbiBvcmRlciB0byBiZSBpdGVyYWJsZSwgbm9uLWFycmF5IG9iamVjdHMgbXVzdCBoYXZlIGEgW1N5bWJvbC5pdGVyYXRvcl0oKSBtZXRob2QuXCIpOyB9IHZhciBvLCBhID0gdHJ1ZSwgdSA9IGZhbHNlOyByZXR1cm4geyBzOiBmdW5jdGlvbiBzKCkgeyB0ID0gdC5jYWxsKHIpOyB9LCBuOiBmdW5jdGlvbiBuKCkgeyB2YXIgciA9IHQubmV4dCgpOyByZXR1cm4gYSA9IHIuZG9uZSwgcjsgfSwgZTogZnVuY3Rpb24gZShyKSB7IHUgPSB0cnVlLCBvID0gcjsgfSwgZjogZnVuY3Rpb24gZigpIHsgdHJ5IHsgYSB8fCBudWxsID09IHRbXCJyZXR1cm5cIl0gfHwgdFtcInJldHVyblwiXSgpOyB9IGZpbmFsbHkgeyBpZiAodSkgdGhyb3cgbzsgfSB9IH07IH1cbmZ1bmN0aW9uIF91bnN1cHBvcnRlZEl0ZXJhYmxlVG9BcnJheShyLCBhKSB7IGlmIChyKSB7IGlmIChcInN0cmluZ1wiID09IHR5cGVvZiByKSByZXR1cm4gX2FycmF5TGlrZVRvQXJyYXkociwgYSk7IHZhciB0ID0ge30udG9TdHJpbmcuY2FsbChyKS5zbGljZSg4LCAtMSk7IHJldHVybiBcIk9iamVjdFwiID09PSB0ICYmIHIuY29uc3RydWN0b3IgJiYgKHQgPSByLmNvbnN0cnVjdG9yLm5hbWUpLCBcIk1hcFwiID09PSB0IHx8IFwiU2V0XCIgPT09IHQgPyBBcnJheS5mcm9tKHIpIDogXCJBcmd1bWVudHNcIiA9PT0gdCB8fCAvXig/OlVpfEkpbnQoPzo4fDE2fDMyKSg/OkNsYW1wZWQpP0FycmF5JC8udGVzdCh0KSA/IF9hcnJheUxpa2VUb0FycmF5KHIsIGEpIDogdm9pZCAwOyB9IH1cbmZ1bmN0aW9uIF9hcnJheUxpa2VUb0FycmF5KHIsIGEpIHsgKG51bGwgPT0gYSB8fCBhID4gci5sZW5ndGgpICYmIChhID0gci5sZW5ndGgpOyBmb3IgKHZhciBlID0gMCwgbiA9IEFycmF5KGEpOyBlIDwgYTsgZSsrKSBuW2VdID0gcltlXTsgcmV0dXJuIG47IH1cbnZhciBGaWx0ZXJTZXJ2aWNlID0ge1xuICBmaWx0ZXI6IGZ1bmN0aW9uIGZpbHRlcih2YWx1ZSwgZmllbGRzLCBmaWx0ZXJWYWx1ZSwgZmlsdGVyTWF0Y2hNb2RlLCBmaWx0ZXJMb2NhbGUpIHtcbiAgICB2YXIgZmlsdGVyZWRJdGVtcyA9IFtdO1xuICAgIGlmICghdmFsdWUpIHtcbiAgICAgIHJldHVybiBmaWx0ZXJlZEl0ZW1zO1xuICAgIH1cbiAgICB2YXIgX2l0ZXJhdG9yID0gX2NyZWF0ZUZvck9mSXRlcmF0b3JIZWxwZXIodmFsdWUpLFxuICAgICAgX3N0ZXA7XG4gICAgdHJ5IHtcbiAgICAgIGZvciAoX2l0ZXJhdG9yLnMoKTsgIShfc3RlcCA9IF9pdGVyYXRvci5uKCkpLmRvbmU7KSB7XG4gICAgICAgIHZhciBpdGVtID0gX3N0ZXAudmFsdWU7XG4gICAgICAgIGlmICh0eXBlb2YgaXRlbSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICBpZiAodGhpcy5maWx0ZXJzW2ZpbHRlck1hdGNoTW9kZV0oaXRlbSwgZmlsdGVyVmFsdWUsIGZpbHRlckxvY2FsZSkpIHtcbiAgICAgICAgICAgIGZpbHRlcmVkSXRlbXMucHVzaChpdGVtKTtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB2YXIgX2l0ZXJhdG9yMiA9IF9jcmVhdGVGb3JPZkl0ZXJhdG9ySGVscGVyKGZpZWxkcyksXG4gICAgICAgICAgICBfc3RlcDI7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGZvciAoX2l0ZXJhdG9yMi5zKCk7ICEoX3N0ZXAyID0gX2l0ZXJhdG9yMi5uKCkpLmRvbmU7KSB7XG4gICAgICAgICAgICAgIHZhciBmaWVsZCA9IF9zdGVwMi52YWx1ZTtcbiAgICAgICAgICAgICAgdmFyIGZpZWxkVmFsdWUgPSByZXNvbHZlRmllbGREYXRhKGl0ZW0sIGZpZWxkKTtcbiAgICAgICAgICAgICAgaWYgKHRoaXMuZmlsdGVyc1tmaWx0ZXJNYXRjaE1vZGVdKGZpZWxkVmFsdWUsIGZpbHRlclZhbHVlLCBmaWx0ZXJMb2NhbGUpKSB7XG4gICAgICAgICAgICAgICAgZmlsdGVyZWRJdGVtcy5wdXNoKGl0ZW0pO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICBfaXRlcmF0b3IyLmUoZXJyKTtcbiAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgX2l0ZXJhdG9yMi5mKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBfaXRlcmF0b3IuZShlcnIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBfaXRlcmF0b3IuZigpO1xuICAgIH1cbiAgICByZXR1cm4gZmlsdGVyZWRJdGVtcztcbiAgfSxcbiAgZmlsdGVyczoge1xuICAgIHN0YXJ0c1dpdGg6IGZ1bmN0aW9uIHN0YXJ0c1dpdGgodmFsdWUsIGZpbHRlciwgZmlsdGVyTG9jYWxlKSB7XG4gICAgICBpZiAoZmlsdGVyID09PSB1bmRlZmluZWQgfHwgZmlsdGVyID09PSBudWxsIHx8IGZpbHRlciA9PT0gJycpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCB8fCB2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICB2YXIgZmlsdGVyVmFsdWUgPSByZW1vdmVBY2NlbnRzKGZpbHRlci50b1N0cmluZygpKS50b0xvY2FsZUxvd2VyQ2FzZShmaWx0ZXJMb2NhbGUpO1xuICAgICAgdmFyIHN0cmluZ1ZhbHVlID0gcmVtb3ZlQWNjZW50cyh2YWx1ZS50b1N0cmluZygpKS50b0xvY2FsZUxvd2VyQ2FzZShmaWx0ZXJMb2NhbGUpO1xuICAgICAgcmV0dXJuIHN0cmluZ1ZhbHVlLnNsaWNlKDAsIGZpbHRlclZhbHVlLmxlbmd0aCkgPT09IGZpbHRlclZhbHVlO1xuICAgIH0sXG4gICAgY29udGFpbnM6IGZ1bmN0aW9uIGNvbnRhaW5zKHZhbHVlLCBmaWx0ZXIsIGZpbHRlckxvY2FsZSkge1xuICAgICAgaWYgKGZpbHRlciA9PT0gdW5kZWZpbmVkIHx8IGZpbHRlciA9PT0gbnVsbCB8fCBmaWx0ZXIgPT09ICcnKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQgfHwgdmFsdWUgPT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgdmFyIGZpbHRlclZhbHVlID0gcmVtb3ZlQWNjZW50cyhmaWx0ZXIudG9TdHJpbmcoKSkudG9Mb2NhbGVMb3dlckNhc2UoZmlsdGVyTG9jYWxlKTtcbiAgICAgIHZhciBzdHJpbmdWYWx1ZSA9IHJlbW92ZUFjY2VudHModmFsdWUudG9TdHJpbmcoKSkudG9Mb2NhbGVMb3dlckNhc2UoZmlsdGVyTG9jYWxlKTtcbiAgICAgIHJldHVybiBzdHJpbmdWYWx1ZS5pbmRleE9mKGZpbHRlclZhbHVlKSAhPT0gLTE7XG4gICAgfSxcbiAgICBub3RDb250YWluczogZnVuY3Rpb24gbm90Q29udGFpbnModmFsdWUsIGZpbHRlciwgZmlsdGVyTG9jYWxlKSB7XG4gICAgICBpZiAoZmlsdGVyID09PSB1bmRlZmluZWQgfHwgZmlsdGVyID09PSBudWxsIHx8IGZpbHRlciA9PT0gJycpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCB8fCB2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICB2YXIgZmlsdGVyVmFsdWUgPSByZW1vdmVBY2NlbnRzKGZpbHRlci50b1N0cmluZygpKS50b0xvY2FsZUxvd2VyQ2FzZShmaWx0ZXJMb2NhbGUpO1xuICAgICAgdmFyIHN0cmluZ1ZhbHVlID0gcmVtb3ZlQWNjZW50cyh2YWx1ZS50b1N0cmluZygpKS50b0xvY2FsZUxvd2VyQ2FzZShmaWx0ZXJMb2NhbGUpO1xuICAgICAgcmV0dXJuIHN0cmluZ1ZhbHVlLmluZGV4T2YoZmlsdGVyVmFsdWUpID09PSAtMTtcbiAgICB9LFxuICAgIGVuZHNXaXRoOiBmdW5jdGlvbiBlbmRzV2l0aCh2YWx1ZSwgZmlsdGVyLCBmaWx0ZXJMb2NhbGUpIHtcbiAgICAgIGlmIChmaWx0ZXIgPT09IHVuZGVmaW5lZCB8fCBmaWx0ZXIgPT09IG51bGwgfHwgZmlsdGVyID09PSAnJykge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHZhbHVlID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIHZhciBmaWx0ZXJWYWx1ZSA9IHJlbW92ZUFjY2VudHMoZmlsdGVyLnRvU3RyaW5nKCkpLnRvTG9jYWxlTG93ZXJDYXNlKGZpbHRlckxvY2FsZSk7XG4gICAgICB2YXIgc3RyaW5nVmFsdWUgPSByZW1vdmVBY2NlbnRzKHZhbHVlLnRvU3RyaW5nKCkpLnRvTG9jYWxlTG93ZXJDYXNlKGZpbHRlckxvY2FsZSk7XG4gICAgICByZXR1cm4gc3RyaW5nVmFsdWUuaW5kZXhPZihmaWx0ZXJWYWx1ZSwgc3RyaW5nVmFsdWUubGVuZ3RoIC0gZmlsdGVyVmFsdWUubGVuZ3RoKSAhPT0gLTE7XG4gICAgfSxcbiAgICBlcXVhbHM6IGZ1bmN0aW9uIGVxdWFscyh2YWx1ZSwgZmlsdGVyLCBmaWx0ZXJMb2NhbGUpIHtcbiAgICAgIGlmIChmaWx0ZXIgPT09IHVuZGVmaW5lZCB8fCBmaWx0ZXIgPT09IG51bGwgfHwgZmlsdGVyID09PSAnJykge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHZhbHVlID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGlmICh2YWx1ZS5nZXRUaW1lICYmIGZpbHRlci5nZXRUaW1lKSByZXR1cm4gdmFsdWUuZ2V0VGltZSgpID09PSBmaWx0ZXIuZ2V0VGltZSgpO2Vsc2UgcmV0dXJuIHJlbW92ZUFjY2VudHModmFsdWUudG9TdHJpbmcoKSkudG9Mb2NhbGVMb3dlckNhc2UoZmlsdGVyTG9jYWxlKSA9PSByZW1vdmVBY2NlbnRzKGZpbHRlci50b1N0cmluZygpKS50b0xvY2FsZUxvd2VyQ2FzZShmaWx0ZXJMb2NhbGUpO1xuICAgIH0sXG4gICAgbm90RXF1YWxzOiBmdW5jdGlvbiBub3RFcXVhbHModmFsdWUsIGZpbHRlciwgZmlsdGVyTG9jYWxlKSB7XG4gICAgICBpZiAoZmlsdGVyID09PSB1bmRlZmluZWQgfHwgZmlsdGVyID09PSBudWxsIHx8IGZpbHRlciA9PT0gJycpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQgfHwgdmFsdWUgPT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBpZiAodmFsdWUuZ2V0VGltZSAmJiBmaWx0ZXIuZ2V0VGltZSkgcmV0dXJuIHZhbHVlLmdldFRpbWUoKSAhPT0gZmlsdGVyLmdldFRpbWUoKTtlbHNlIHJldHVybiByZW1vdmVBY2NlbnRzKHZhbHVlLnRvU3RyaW5nKCkpLnRvTG9jYWxlTG93ZXJDYXNlKGZpbHRlckxvY2FsZSkgIT0gcmVtb3ZlQWNjZW50cyhmaWx0ZXIudG9TdHJpbmcoKSkudG9Mb2NhbGVMb3dlckNhc2UoZmlsdGVyTG9jYWxlKTtcbiAgICB9LFxuICAgIFwiaW5cIjogZnVuY3Rpb24gX2luKHZhbHVlLCBmaWx0ZXIpIHtcbiAgICAgIGlmIChmaWx0ZXIgPT09IHVuZGVmaW5lZCB8fCBmaWx0ZXIgPT09IG51bGwgfHwgZmlsdGVyLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZmlsdGVyLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGlmIChlcXVhbHModmFsdWUsIGZpbHRlcltpXSkpIHtcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG4gICAgYmV0d2VlbjogZnVuY3Rpb24gYmV0d2Vlbih2YWx1ZSwgZmlsdGVyKSB7XG4gICAgICBpZiAoZmlsdGVyID09IG51bGwgfHwgZmlsdGVyWzBdID09IG51bGwgfHwgZmlsdGVyWzFdID09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCB8fCB2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBpZiAodmFsdWUuZ2V0VGltZSkgcmV0dXJuIGZpbHRlclswXS5nZXRUaW1lKCkgPD0gdmFsdWUuZ2V0VGltZSgpICYmIHZhbHVlLmdldFRpbWUoKSA8PSBmaWx0ZXJbMV0uZ2V0VGltZSgpO2Vsc2UgcmV0dXJuIGZpbHRlclswXSA8PSB2YWx1ZSAmJiB2YWx1ZSA8PSBmaWx0ZXJbMV07XG4gICAgfSxcbiAgICBsdDogZnVuY3Rpb24gbHQodmFsdWUsIGZpbHRlcikge1xuICAgICAgaWYgKGZpbHRlciA9PT0gdW5kZWZpbmVkIHx8IGZpbHRlciA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHZhbHVlID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGlmICh2YWx1ZS5nZXRUaW1lICYmIGZpbHRlci5nZXRUaW1lKSByZXR1cm4gdmFsdWUuZ2V0VGltZSgpIDwgZmlsdGVyLmdldFRpbWUoKTtlbHNlIHJldHVybiB2YWx1ZSA8IGZpbHRlcjtcbiAgICB9LFxuICAgIGx0ZTogZnVuY3Rpb24gbHRlKHZhbHVlLCBmaWx0ZXIpIHtcbiAgICAgIGlmIChmaWx0ZXIgPT09IHVuZGVmaW5lZCB8fCBmaWx0ZXIgPT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCB8fCB2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBpZiAodmFsdWUuZ2V0VGltZSAmJiBmaWx0ZXIuZ2V0VGltZSkgcmV0dXJuIHZhbHVlLmdldFRpbWUoKSA8PSBmaWx0ZXIuZ2V0VGltZSgpO2Vsc2UgcmV0dXJuIHZhbHVlIDw9IGZpbHRlcjtcbiAgICB9LFxuICAgIGd0OiBmdW5jdGlvbiBndCh2YWx1ZSwgZmlsdGVyKSB7XG4gICAgICBpZiAoZmlsdGVyID09PSB1bmRlZmluZWQgfHwgZmlsdGVyID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQgfHwgdmFsdWUgPT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgaWYgKHZhbHVlLmdldFRpbWUgJiYgZmlsdGVyLmdldFRpbWUpIHJldHVybiB2YWx1ZS5nZXRUaW1lKCkgPiBmaWx0ZXIuZ2V0VGltZSgpO2Vsc2UgcmV0dXJuIHZhbHVlID4gZmlsdGVyO1xuICAgIH0sXG4gICAgZ3RlOiBmdW5jdGlvbiBndGUodmFsdWUsIGZpbHRlcikge1xuICAgICAgaWYgKGZpbHRlciA9PT0gdW5kZWZpbmVkIHx8IGZpbHRlciA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHZhbHVlID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGlmICh2YWx1ZS5nZXRUaW1lICYmIGZpbHRlci5nZXRUaW1lKSByZXR1cm4gdmFsdWUuZ2V0VGltZSgpID49IGZpbHRlci5nZXRUaW1lKCk7ZWxzZSByZXR1cm4gdmFsdWUgPj0gZmlsdGVyO1xuICAgIH0sXG4gICAgZGF0ZUlzOiBmdW5jdGlvbiBkYXRlSXModmFsdWUsIGZpbHRlcikge1xuICAgICAgaWYgKGZpbHRlciA9PT0gdW5kZWZpbmVkIHx8IGZpbHRlciA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHZhbHVlID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIHZhbHVlID0gbmV3IERhdGUodmFsdWUpO1xuICAgICAgfVxuICAgICAgaWYgKHR5cGVvZiBmaWx0ZXIgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIGZpbHRlciA9IG5ldyBEYXRlKGZpbHRlcik7XG4gICAgICB9XG4gICAgICByZXR1cm4gdmFsdWUudG9EYXRlU3RyaW5nKCkgPT09IGZpbHRlci50b0RhdGVTdHJpbmcoKTtcbiAgICB9LFxuICAgIGRhdGVJc05vdDogZnVuY3Rpb24gZGF0ZUlzTm90KHZhbHVlLCBmaWx0ZXIpIHtcbiAgICAgIGlmIChmaWx0ZXIgPT09IHVuZGVmaW5lZCB8fCBmaWx0ZXIgPT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCB8fCB2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykge1xuICAgICAgICB2YWx1ZSA9IG5ldyBEYXRlKHZhbHVlKTtcbiAgICAgIH1cbiAgICAgIGlmICh0eXBlb2YgZmlsdGVyID09PSAnc3RyaW5nJykge1xuICAgICAgICBmaWx0ZXIgPSBuZXcgRGF0ZShmaWx0ZXIpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHZhbHVlLnRvRGF0ZVN0cmluZygpICE9PSBmaWx0ZXIudG9EYXRlU3RyaW5nKCk7XG4gICAgfSxcbiAgICBkYXRlQmVmb3JlOiBmdW5jdGlvbiBkYXRlQmVmb3JlKHZhbHVlLCBmaWx0ZXIpIHtcbiAgICAgIGlmIChmaWx0ZXIgPT09IHVuZGVmaW5lZCB8fCBmaWx0ZXIgPT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCB8fCB2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykge1xuICAgICAgICB2YWx1ZSA9IG5ldyBEYXRlKHZhbHVlKTtcbiAgICAgIH1cbiAgICAgIGlmICh0eXBlb2YgZmlsdGVyID09PSAnc3RyaW5nJykge1xuICAgICAgICBmaWx0ZXIgPSBuZXcgRGF0ZShmaWx0ZXIpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHZhbHVlLmdldFRpbWUoKSA8IGZpbHRlci5nZXRUaW1lKCk7XG4gICAgfSxcbiAgICBkYXRlQWZ0ZXI6IGZ1bmN0aW9uIGRhdGVBZnRlcih2YWx1ZSwgZmlsdGVyKSB7XG4gICAgICBpZiAoZmlsdGVyID09PSB1bmRlZmluZWQgfHwgZmlsdGVyID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgICAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQgfHwgdmFsdWUgPT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgdmFsdWUgPSBuZXcgRGF0ZSh2YWx1ZSk7XG4gICAgICB9XG4gICAgICBpZiAodHlwZW9mIGZpbHRlciA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgZmlsdGVyID0gbmV3IERhdGUoZmlsdGVyKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB2YWx1ZS5nZXRUaW1lKCkgPiBmaWx0ZXIuZ2V0VGltZSgpO1xuICAgIH1cbiAgfSxcbiAgcmVnaXN0ZXI6IGZ1bmN0aW9uIHJlZ2lzdGVyKHJ1bGUsIGZuKSB7XG4gICAgdGhpcy5maWx0ZXJzW3J1bGVdID0gZm47XG4gIH1cbn07XG5cbnZhciBQcmltZUljb25zID0ge1xuICBBRERSRVNTX0JPT0s6ICdwaSBwaS1hZGRyZXNzLWJvb2snLFxuICBBTElHTl9DRU5URVI6ICdwaSBwaS1hbGlnbi1jZW50ZXInLFxuICBBTElHTl9KVVNUSUZZOiAncGkgcGktYWxpZ24tanVzdGlmeScsXG4gIEFMSUdOX0xFRlQ6ICdwaSBwaS1hbGlnbi1sZWZ0JyxcbiAgQUxJR05fUklHSFQ6ICdwaSBwaS1hbGlnbi1yaWdodCcsXG4gIEFNQVpPTjogJ3BpIHBpLWFtYXpvbicsXG4gIEFORFJPSUQ6ICdwaSBwaS1hbmRyb2lkJyxcbiAgQU5HTEVfRE9VQkxFX0RPV046ICdwaSBwaS1hbmdsZS1kb3VibGUtZG93bicsXG4gIEFOR0xFX0RPVUJMRV9MRUZUOiAncGkgcGktYW5nbGUtZG91YmxlLWxlZnQnLFxuICBBTkdMRV9ET1VCTEVfUklHSFQ6ICdwaSBwaS1hbmdsZS1kb3VibGUtcmlnaHQnLFxuICBBTkdMRV9ET1VCTEVfVVA6ICdwaSBwaS1hbmdsZS1kb3VibGUtdXAnLFxuICBBTkdMRV9ET1dOOiAncGkgcGktYW5nbGUtZG93bicsXG4gIEFOR0xFX0xFRlQ6ICdwaSBwaS1hbmdsZS1sZWZ0JyxcbiAgQU5HTEVfUklHSFQ6ICdwaSBwaS1hbmdsZS1yaWdodCcsXG4gIEFOR0xFX1VQOiAncGkgcGktYW5nbGUtdXAnLFxuICBBUFBMRTogJ3BpIHBpLWFwcGxlJyxcbiAgQVJST1dfQ0lSQ0xFX0RPV046ICdwaSBwaS1hcnJvdy1jaXJjbGUtZG93bicsXG4gIEFSUk9XX0NJUkNMRV9MRUZUOiAncGkgcGktYXJyb3ctY2lyY2xlLWxlZnQnLFxuICBBUlJPV19DSVJDTEVfUklHSFQ6ICdwaSBwaS1hcnJvdy1jaXJjbGUtcmlnaHQnLFxuICBBUlJPV19DSVJDTEVfVVA6ICdwaSBwaS1hcnJvdy1jaXJjbGUtdXAnLFxuICBBUlJPV19ET1dOOiAncGkgcGktYXJyb3ctZG93bicsXG4gIEFSUk9XX0RPV05fTEVGVDogJ3BpIHBpLWFycm93LWRvd24tbGVmdCcsXG4gIEFSUk9XX0RPV05fTEVGVF9BTkRfQVJST1dfVVBfUklHSFRfVE9fQ0VOVEVSOiAncGkgcGktYXJyb3ctZG93bi1sZWZ0LWFuZC1hcnJvdy11cC1yaWdodC10by1jZW50ZXInLFxuICBBUlJPV19ET1dOX1JJR0hUOiAncGkgcGktYXJyb3ctZG93bi1yaWdodCcsXG4gIEFSUk9XX0xFRlQ6ICdwaSBwaS1hcnJvdy1sZWZ0JyxcbiAgQVJST1dfUklHSFQ6ICdwaSBwaS1hcnJvdy1yaWdodCcsXG4gIEFSUk9XX1JJR0hUX0FSUk9XX0xFRlQ6ICdwaSBwaS1hcnJvdy1yaWdodC1hcnJvdy1sZWZ0JyxcbiAgQVJST1dfVVA6ICdwaSBwaS1hcnJvdy11cCcsXG4gIEFSUk9XX1VQX0xFRlQ6ICdwaSBwaS1hcnJvdy11cC1sZWZ0JyxcbiAgQVJST1dfVVBfUklHSFQ6ICdwaSBwaS1hcnJvdy11cC1yaWdodCcsXG4gIEFSUk9XX1VQX1JJR0hUX0FORF9BUlJPV19ET1dOX0xFRlRfRlJPTV9DRU5URVI6ICdwaSBwaS1hcnJvdy11cC1yaWdodC1hbmQtYXJyb3ctZG93bi1sZWZ0LWZyb20tY2VudGVyJyxcbiAgQVJST1dTX0g6ICdwaSBwaS1hcnJvd3MtaCcsXG4gIEFSUk9XU19WOiAncGkgcGktYXJyb3dzLXYnLFxuICBBUlJPV1NfQUxUOiAncGkgcGktYXJyb3dzLWFsdCcsXG4gIEFTVEVSSVNLOiAncGkgcGktYXN0ZXJpc2snLFxuICBBVDogJ3BpIHBpLWF0JyxcbiAgQkFDS1dBUkQ6ICdwaSBwaS1iYWNrd2FyZCcsXG4gIEJBTjogJ3BpIHBpLWJhbicsXG4gIEJBUlM6ICdwaSBwaS1iYXJzJyxcbiAgQkVMTDogJ3BpIHBpLWJlbGwnLFxuICBCRUxMX1NMQVNIOiAncGkgcGktYmVsbC1zbGFzaCcsXG4gIEJJVENPSU46ICdwaSBwaS1iaXRjb2luJyxcbiAgQk9MVDogJ3BpIHBpLWJvbHQnLFxuICBCT09LOiAncGkgcGktYm9vaycsXG4gIEJPT0tNQVJLOiAncGkgcGktYm9va21hcmsnLFxuICBCT09LTUFSS19GSUxMOiAncGkgcGktYm9va21hcmstZmlsbCcsXG4gIEJPWDogJ3BpIHBpLWJveCcsXG4gIEJSSUVGQ0FTRTogJ3BpIHBpLWJyaWVmY2FzZScsXG4gIEJVSUxESU5HOiAncGkgcGktYnVpbGRpbmcnLFxuICBCVUlMRElOR19DT0xVTU5TOiAncGkgcGktYnVpbGRpbmctY29sdW1ucycsXG4gIEJVTExTRVlFOiAncGkgcGktYnVsbHNleWUnLFxuICBDQUxFTkRBUjogJ3BpIHBpLWNhbGVuZGFyJyxcbiAgQ0FMRU5EQVJfQ0xPQ0s6ICdwaSBwaS1jYWxlbmRhci1jbG9jaycsXG4gIENBTEVOREFSX01JTlVTOiAncGkgcGktY2FsZW5kYXItbWludXMnLFxuICBDQUxFTkRBUl9QTFVTOiAncGkgcGktY2FsZW5kYXItcGx1cycsXG4gIENBTEVOREFSX1RJTUVTOiAncGkgcGktY2FsZW5kYXItdGltZXMnLFxuICBDQUxDVUxBVE9SOiAncGkgcGktY2FsY3VsYXRvcicsXG4gIENBTUVSQTogJ3BpIHBpLWNhbWVyYScsXG4gIENBUjogJ3BpIHBpLWNhcicsXG4gIENBUkVUX0RPV046ICdwaSBwaS1jYXJldC1kb3duJyxcbiAgQ0FSRVRfTEVGVDogJ3BpIHBpLWNhcmV0LWxlZnQnLFxuICBDQVJFVF9SSUdIVDogJ3BpIHBpLWNhcmV0LXJpZ2h0JyxcbiAgQ0FSRVRfVVA6ICdwaSBwaS1jYXJldC11cCcsXG4gIENBUlRfQVJST1dfRE9XTjogJ3BpIHBpLWNhcnQtYXJyb3ctZG93bicsXG4gIENBUlRfTUlOVVM6ICdwaSBwaS1jYXJ0LW1pbnVzJyxcbiAgQ0FSVF9QTFVTOiAncGkgcGktY2FydC1wbHVzJyxcbiAgQ0hBUlRfQkFSOiAncGkgcGktY2hhcnQtYmFyJyxcbiAgQ0hBUlRfTElORTogJ3BpIHBpLWNoYXJ0LWxpbmUnLFxuICBDSEFSVF9QSUU6ICdwaSBwaS1jaGFydC1waWUnLFxuICBDSEFSVF9TQ0FUVEVSOiAncGkgcGktY2hhcnQtc2NhdHRlcicsXG4gIENIRUNLOiAncGkgcGktY2hlY2snLFxuICBDSEVDS19DSVJDTEU6ICdwaSBwaS1jaGVjay1jaXJjbGUnLFxuICBDSEVDS19TUVVBUkU6ICdwaSBwaS1jaGVjay1zcXVhcmUnLFxuICBDSEVWUk9OX0NJUkNMRV9ET1dOOiAncGkgcGktY2hldnJvbi1jaXJjbGUtZG93bicsXG4gIENIRVZST05fQ0lSQ0xFX0xFRlQ6ICdwaSBwaS1jaGV2cm9uLWNpcmNsZS1sZWZ0JyxcbiAgQ0hFVlJPTl9DSVJDTEVfUklHSFQ6ICdwaSBwaS1jaGV2cm9uLWNpcmNsZS1yaWdodCcsXG4gIENIRVZST05fQ0lSQ0xFX1VQOiAncGkgcGktY2hldnJvbi1jaXJjbGUtdXAnLFxuICBDSEVWUk9OX0RPV046ICdwaSBwaS1jaGV2cm9uLWRvd24nLFxuICBDSEVWUk9OX0xFRlQ6ICdwaSBwaS1jaGV2cm9uLWxlZnQnLFxuICBDSEVWUk9OX1JJR0hUOiAncGkgcGktY2hldnJvbi1yaWdodCcsXG4gIENIRVZST05fVVA6ICdwaSBwaS1jaGV2cm9uLXVwJyxcbiAgQ0lSQ0xFOiAncGkgcGktY2lyY2xlJyxcbiAgQ0lSQ0xFX0ZJTEw6ICdwaSBwaS1jaXJjbGUtZmlsbCcsXG4gIENMSVBCT0FSRDogJ3BpIHBpLWNsaXBib2FyZCcsXG4gIENMT0NLOiAncGkgcGktY2xvY2snLFxuICBDTE9ORTogJ3BpIHBpLWNsb25lJyxcbiAgQ0xPVUQ6ICdwaSBwaS1jbG91ZCcsXG4gIENMT1VEX0RPV05MT0FEOiAncGkgcGktY2xvdWQtZG93bmxvYWQnLFxuICBDTE9VRF9VUExPQUQ6ICdwaSBwaS1jbG91ZC11cGxvYWQnLFxuICBDT0RFOiAncGkgcGktY29kZScsXG4gIENPRzogJ3BpIHBpLWNvZycsXG4gIENPTU1FTlQ6ICdwaSBwaS1jb21tZW50JyxcbiAgQ09NTUVOVFM6ICdwaSBwaS1jb21tZW50cycsXG4gIENPTVBBU1M6ICdwaSBwaS1jb21wYXNzJyxcbiAgQ09QWTogJ3BpIHBpLWNvcHknLFxuICBDUkVESVRfQ0FSRDogJ3BpIHBpLWNyZWRpdC1jYXJkJyxcbiAgQ1JPV046ICdwaSBwaS1jcm93bicsXG4gIERBVEFCQVNFOiAncGkgcGktZGF0YWJhc2UnLFxuICBERUxFVEVMRUZUOiAncGkgcGktZGVsZXRlLWxlZnQnLFxuICBERVNLVE9QOiAncGkgcGktZGVza3RvcCcsXG4gIERJUkVDVElPTlM6ICdwaSBwaS1kaXJlY3Rpb25zJyxcbiAgRElSRUNUSU9OU19BTFQ6ICdwaSBwaS1kaXJlY3Rpb25zLWFsdCcsXG4gIERJU0NPUkQ6ICdwaSBwaS1kaXNjb3JkJyxcbiAgRE9MTEFSOiAncGkgcGktZG9sbGFyJyxcbiAgRE9XTkxPQUQ6ICdwaSBwaS1kb3dubG9hZCcsXG4gIEVKRUNUOiAncGkgcGktZWplY3QnLFxuICBFTExJUFNJU19IOiAncGkgcGktZWxsaXBzaXMtaCcsXG4gIEVMTElQU0lTX1Y6ICdwaSBwaS1lbGxpcHNpcy12JyxcbiAgRU5WRUxPUEU6ICdwaSBwaS1lbnZlbG9wZScsXG4gIEVRVUFMUzogJ3BpIHBpLWVxdWFscycsXG4gIEVSQVNFUjogJ3BpIHBpLWVyYXNlcicsXG4gIEVUSEVSRVVNOiAncGkgcGktZXRoZXJldW0nLFxuICBFVVJPOiAncGkgcGktZXVybycsXG4gIEVYQ0xBTUFUSU9OX0NJUkNMRTogJ3BpIHBpLWV4Y2xhbWF0aW9uLWNpcmNsZScsXG4gIEVYQ0xBTUFUSU9OX1RSSUFOR0xFOiAncGkgcGktZXhjbGFtYXRpb24tdHJpYW5nbGUnLFxuICBFWFBBTkQ6ICdwaSBwaS1leHBhbmQnLFxuICBFWFRFUk5BTF9MSU5LOiAncGkgcGktZXh0ZXJuYWwtbGluaycsXG4gIEVZRTogJ3BpIHBpLWV5ZScsXG4gIEVZRV9TTEFTSDogJ3BpIHBpLWV5ZS1zbGFzaCcsXG4gIEZBQ0VfU01JTEU6ICdwaSBwaS1mYWNlLXNtaWxlJyxcbiAgRkFDRUJPT0s6ICdwaSBwaS1mYWNlYm9vaycsXG4gIEZBU1RfQkFDS1dBUkQ6ICdwaSBwaS1mYXN0LWJhY2t3YXJkJyxcbiAgRkFTVF9GT1JXQVJEOiAncGkgcGktZmFzdC1mb3J3YXJkJyxcbiAgRklMRTogJ3BpIHBpLWZpbGUnLFxuICBGSUxFX0FSUk9XX1VQOiAncGkgcGktZmlsZS1hcnJvdy11cCcsXG4gIEZJTEVfQ0hFQ0s6ICdwaSBwaS1maWxlLWNoZWNrJyxcbiAgRklMRV9FRElUOiAncGkgcGktZmlsZS1lZGl0JyxcbiAgRklMRV9FWENFTDogJ3BpIHBpLWZpbGUtZXhjZWwnLFxuICBGSUxFX0VYUE9SVDogJ3BpIHBpLWZpbGUtZXhwb3J0JyxcbiAgRklMRV9JTVBPUlQ6ICdwaSBwaS1maWxlLWltcG9ydCcsXG4gIEZJTEVfUERGOiAncGkgcGktZmlsZS1wZGYnLFxuICBGSUxFX1BMVVM6ICdwaSBwaS1maWxlLXBsdXMnLFxuICBGSUxFX1dPUkQ6ICdwaSBwaS1maWxlLXdvcmQnLFxuICBGSUxURVI6ICdwaSBwaS1maWx0ZXInLFxuICBGSUxURVJfRklMTDogJ3BpIHBpLWZpbHRlci1maWxsJyxcbiAgRklMVEVSX1NMQVNIOiAncGkgcGktZmlsdGVyLXNsYXNoJyxcbiAgRkxBRzogJ3BpIHBpLWZsYWcnLFxuICBGTEFHX0ZJTEw6ICdwaSBwaS1mbGFnLWZpbGwnLFxuICBGT0xERVI6ICdwaSBwaS1mb2xkZXInLFxuICBGT0xERVJfT1BFTjogJ3BpIHBpLWZvbGRlci1vcGVuJyxcbiAgRk9SV0FSRDogJ3BpIHBpLWZvcndhcmQnLFxuICBHQVVHRTogJ3BpIHBpLWdhdWdlJyxcbiAgR0lGVDogJ3BpIHBpLWdpZnQnLFxuICBHSVRIVUI6ICdwaSBwaS1naXRodWInLFxuICBHTE9CRTogJ3BpIHBpLWdsb2JlJyxcbiAgR09PR0xFOiAncGkgcGktZ29vZ2xlJyxcbiAgR1JBRFVBVElPTl9DQVA6ICdwaSBwaS1ncmFkdWF0aW9uLWNhcCcsXG4gIEhBTU1FUjogJ3BpIHBpLWhhbW1lcicsXG4gIEhBU0hUQUc6ICdwaSBwaS1oYXNodGFnJyxcbiAgSEVBRFBIT05FUzogJ3BpIHBpLWhlYWRwaG9uZXMnLFxuICBIRUFSVDogJ3BpIHBpLWhlYXJ0JyxcbiAgSEVBUlRfRklMTDogJ3BpIHBpLWhlYXJ0LWZpbGwnLFxuICBISVNUT1JZOiAncGkgcGktaGlzdG9yeScsXG4gIEhPVVJHTEFTUzogJ3BpIHBpLWhvdXJnbGFzcycsXG4gIEhPTUU6ICdwaSBwaS1ob21lJyxcbiAgSURfQ0FSRDogJ3BpIHBpLWlkLWNhcmQnLFxuICBJTUFHRTogJ3BpIHBpLWltYWdlJyxcbiAgSU1BR0VTOiAncGkgcGktaW1hZ2VzJyxcbiAgSU5CT1g6ICdwaSBwaS1pbmJveCcsXG4gIElORElBTl9SVVBFRTogJ3BpIHBpLWluZGlhbi1ydXBlZScsXG4gIElORk86ICdwaSBwaS1pbmZvJyxcbiAgSU5GT19DSVJDTEU6ICdwaSBwaS1pbmZvLWNpcmNsZScsXG4gIElOU1RBR1JBTTogJ3BpIHBpLWluc3RhZ3JhbScsXG4gIEtFWTogJ3BpIHBpLWtleScsXG4gIExBTkdVQUdFOiAncGkgcGktbGFuZ3VhZ2UnLFxuICBMSUdIVEJVTEI6ICdwaSBwaS1saWdodGJ1bGInLFxuICBMSU5LOiAncGkgcGktbGluaycsXG4gIExJTktFRElOOiAncGkgcGktbGlua2VkaW4nLFxuICBMSVNUOiAncGkgcGktbGlzdCcsXG4gIExJU1RfQ0hFQ0s6ICdwaSBwaS1saXN0LWNoZWNrJyxcbiAgTE9DSzogJ3BpIHBpLWxvY2snLFxuICBMT0NLX09QRU46ICdwaSBwaS1sb2NrLW9wZW4nLFxuICBNQVA6ICdwaSBwaS1tYXAnLFxuICBNQVBfTUFSS0VSOiAncGkgcGktbWFwLW1hcmtlcicsXG4gIE1BUlM6ICdwaSBwaS1tYXJzJyxcbiAgTUVHQVBIT05FOiAncGkgcGktbWVnYXBob25lJyxcbiAgTUlDUk9DSElQOiAncGkgcGktbWljcm9jaGlwJyxcbiAgTUlDUk9DSElQX0FJOiAncGkgcGktbWljcm9jaGlwLWFpJyxcbiAgTUlDUk9QSE9ORTogJ3BpIHBpLW1pY3JvcGhvbmUnLFxuICBNSUNST1NPRlQ6ICdwaSBwaS1taWNyb3NvZnQnLFxuICBNSU5VUzogJ3BpIHBpLW1pbnVzJyxcbiAgTUlOVVNfQ0lSQ0xFOiAncGkgcGktbWludXMtY2lyY2xlJyxcbiAgTU9CSUxFOiAncGkgcGktbW9iaWxlJyxcbiAgTU9ORVlfQklMTDogJ3BpIHBpLW1vbmV5LWJpbGwnLFxuICBNT09OOiAncGkgcGktbW9vbicsXG4gIE9CSkVDVFNfQ09MVU1OOiAncGkgcGktb2JqZWN0cy1jb2x1bW4nLFxuICBQQUxFVFRFOiAncGkgcGktcGFsZXR0ZScsXG4gIFBBUEVSQ0xJUDogJ3BpIHBpLXBhcGVyY2xpcCcsXG4gIFBBVVNFOiAncGkgcGktcGF1c2UnLFxuICBQQVlQQUw6ICdwaSBwaS1wYXlwYWwnLFxuICBQRU5fVE9fU1FVQVJFOiAncGkgcGktcGVuLXRvLXNxdWFyZScsXG4gIFBFTkNJTDogJ3BpIHBpLXBlbmNpbCcsXG4gIFBFUkNFTlRBR0U6ICdwaSBwaS1wZXJjZW50YWdlJyxcbiAgUEhPTkU6ICdwaSBwaS1waG9uZScsXG4gIFBJTlRFUkVTVDogJ3BpIHBpLXBpbnRlcmVzdCcsXG4gIFBMQVk6ICdwaSBwaS1wbGF5JyxcbiAgUExBWV9DSVJDTEU6ICdwaSBwaS1wbGF5LWNpcmNsZScsXG4gIFBMVVM6ICdwaSBwaS1wbHVzJyxcbiAgUExVU19DSVJDTEU6ICdwaSBwaS1wbHVzLWNpcmNsZScsXG4gIFBPVU5EOiAncGkgcGktcG91bmQnLFxuICBQT1dFUl9PRkY6ICdwaSBwaS1wb3dlci1vZmYnLFxuICBQUklNRTogJ3BpIHBpLXByaW1lJyxcbiAgUFJJTlQ6ICdwaSBwaS1wcmludCcsXG4gIFFSQ09ERTogJ3BpIHBpLXFyY29kZScsXG4gIFFVRVNUSU9OOiAncGkgcGktcXVlc3Rpb24nLFxuICBRVUVTVElPTl9DSVJDTEU6ICdwaSBwaS1xdWVzdGlvbi1jaXJjbGUnLFxuICBSRUNFSVBUOiAncGkgcGktcmVjZWlwdCcsXG4gIFJFRERJVDogJ3BpIHBpLXJlZGRpdCcsXG4gIFJFRlJFU0g6ICdwaSBwaS1yZWZyZXNoJyxcbiAgUkVQTEFZOiAncGkgcGktcmVwbGF5JyxcbiAgUkVQTFk6ICdwaSBwaS1yZXBseScsXG4gIFNBVkU6ICdwaSBwaS1zYXZlJyxcbiAgU0VBUkNIOiAncGkgcGktc2VhcmNoJyxcbiAgU0VBUkNIX01JTlVTOiAncGkgcGktc2VhcmNoLW1pbnVzJyxcbiAgU0VBUkNIX1BMVVM6ICdwaSBwaS1zZWFyY2gtcGx1cycsXG4gIFNFTkQ6ICdwaSBwaS1zZW5kJyxcbiAgU0VSVkVSOiAncGkgcGktc2VydmVyJyxcbiAgU0hBUkVfQUxUOiAncGkgcGktc2hhcmUtYWx0JyxcbiAgU0hJRUxEOiAncGkgcGktc2hpZWxkJyxcbiAgU0hPUDogJ3BpIHBpLXNob3AnLFxuICBTSE9QUElOR19CQUc6ICdwaSBwaS1zaG9wcGluZy1iYWcnLFxuICBTSE9QUElOR19DQVJUOiAncGkgcGktc2hvcHBpbmctY2FydCcsXG4gIFNJR05fSU46ICdwaSBwaS1zaWduLWluJyxcbiAgU0lHTl9PVVQ6ICdwaSBwaS1zaWduLW91dCcsXG4gIFNJVEVNQVA6ICdwaSBwaS1zaXRlbWFwJyxcbiAgU0xBQ0s6ICdwaSBwaS1zbGFjaycsXG4gIFNMSURFUlNfSDogJ3BpIHBpLXNsaWRlcnMtaCcsXG4gIFNMSURFUlNfVjogJ3BpIHBpLXNsaWRlcnMtdicsXG4gIFNPUlQ6ICdwaSBwaS1zb3J0JyxcbiAgU09SVF9BTFBIQV9ET1dOOiAncGkgcGktc29ydC1hbHBoYS1kb3duJyxcbiAgU09SVF9BTFBIQV9ET1dOX0FMVDogJ3BpIHBpLXNvcnQtYWxwaGEtZG93bi1hbHQnLFxuICBTT1JUX0FMUEhBX1VQOiAncGkgcGktc29ydC1hbHBoYS11cCcsXG4gIFNPUlRfQUxQSEFfVVBfQUxUOiAncGkgcGktc29ydC1hbHBoYS11cC1hbHQnLFxuICBTT1JUX0FMVDogJ3BpIHBpLXNvcnQtYWx0JyxcbiAgU09SVF9BTFRfU0xBU0g6ICdwaSBwaS1zb3J0LWFsdC1zbGFzaCcsXG4gIFNPUlRfQU1PVU5UX0RPV046ICdwaSBwaS1zb3J0LWFtb3VudC1kb3duJyxcbiAgU09SVF9BTU9VTlRfRE9XTl9BTFQ6ICdwaSBwaS1zb3J0LWFtb3VudC1kb3duLWFsdCcsXG4gIFNPUlRfQU1PVU5UX1VQOiAncGkgcGktc29ydC1hbW91bnQtdXAnLFxuICBTT1JUX0FNT1VOVF9VUF9BTFQ6ICdwaSBwaS1zb3J0LWFtb3VudC11cC1hbHQnLFxuICBTT1JUX0RPV046ICdwaSBwaS1zb3J0LWRvd24nLFxuICBTT1JUX05VTUVSSUNfRE9XTjogJ3BpIHBpLXNvcnQtbnVtZXJpYy1kb3duJyxcbiAgU09SVF9OVU1FUklDX0RPV05fQUxUOiAncGkgcGktc29ydC1udW1lcmljLWRvd24tYWx0JyxcbiAgU09SVF9OVU1FUklDX1VQOiAncGkgcGktc29ydC1udW1lcmljLXVwJyxcbiAgU09SVF9OVU1FUklDX1VQX0FMVDogJ3BpIHBpLXNvcnQtbnVtZXJpYy11cC1hbHQnLFxuICBTT1JUX1VQOiAncGkgcGktc29ydC11cCcsXG4gIFNQQVJLTEVTOiAncGkgcGktc3BhcmtsZXMnLFxuICBTUElOTkVSOiAncGkgcGktc3Bpbm5lcicsXG4gIFNQSU5ORVJfRE9UVEVEOiAncGkgcGktc3Bpbm5lci1kb3R0ZWQnLFxuICBTVEFSOiAncGkgcGktc3RhcicsXG4gIFNUQVJfRklMTDogJ3BpIHBpLXN0YXItZmlsbCcsXG4gIFNUQVJfSEFMRjogJ3BpIHBpLXN0YXItaGFsZicsXG4gIFNUQVJfSEFMRl9GSUxMOiAncGkgcGktc3Rhci1oYWxmLWZpbGwnLFxuICBTVEVQX0JBQ0tXQVJEOiAncGkgcGktc3RlcC1iYWNrd2FyZCcsXG4gIFNURVBfQkFDS1dBUkRfQUxUOiAncGkgcGktc3RlcC1iYWNrd2FyZC1hbHQnLFxuICBTVEVQX0ZPUldBUkQ6ICdwaSBwaS1zdGVwLWZvcndhcmQnLFxuICBTVEVQX0ZPUldBUkRfQUxUOiAncGkgcGktc3RlcC1mb3J3YXJkLWFsdCcsXG4gIFNUT1A6ICdwaSBwaS1zdG9wJyxcbiAgU1RPUFdBVENIOiAncGkgcGktc3RvcHdhdGNoJyxcbiAgU1RPUF9DSVJDTEU6ICdwaSBwaS1zdG9wLWNpcmNsZScsXG4gIFNVTjogJ3BpIHBpLXN1bicsXG4gIFNZTkM6ICdwaSBwaS1zeW5jJyxcbiAgVEFCTEU6ICdwaSBwaS10YWJsZScsXG4gIFRBQkxFVDogJ3BpIHBpLXRhYmxldCcsXG4gIFRBRzogJ3BpIHBpLXRhZycsXG4gIFRBR1M6ICdwaSBwaS10YWdzJyxcbiAgVEVMRUdSQU06ICdwaSBwaS10ZWxlZ3JhbScsXG4gIFRIX0xBUkdFOiAncGkgcGktdGgtbGFyZ2UnLFxuICBUSFVNQlNfRE9XTjogJ3BpIHBpLXRodW1icy1kb3duJyxcbiAgVEhVTUJTX0RPV05fRklMTDogJ3BpIHBpLXRodW1icy1kb3duLWZpbGwnLFxuICBUSFVNQlNfVVA6ICdwaSBwaS10aHVtYnMtdXAnLFxuICBUSFVNQlNfVVBfRklMTDogJ3BpIHBpLXRodW1icy11cC1maWxsJyxcbiAgVEhVTUJUQUNLOiAncGkgcGktdGh1bWJ0YWNrJyxcbiAgVElDS0VUOiAncGkgcGktdGlja2V0JyxcbiAgVElLVE9LOiAncGkgcGktdGlrdG9rJyxcbiAgVElNRVM6ICdwaSBwaS10aW1lcycsXG4gIFRJTUVTX0NJUkNMRTogJ3BpIHBpLXRpbWVzLWNpcmNsZScsXG4gIFRSQVNIOiAncGkgcGktdHJhc2gnLFxuICBUUk9QSFk6ICdwaSBwaS10cm9waHknLFxuICBUUlVDSzogJ3BpIHBpLXRydWNrJyxcbiAgVFVSS0lTSF9MSVJBOiAncGkgcGktdHVya2lzaC1saXJhJyxcbiAgVFdJVENIOiAncGkgcGktdHdpdGNoJyxcbiAgVFdJVFRFUjogJ3BpIHBpLXR3aXR0ZXInLFxuICBVTkRPOiAncGkgcGktdW5kbycsXG4gIFVOTE9DSzogJ3BpIHBpLXVubG9jaycsXG4gIFVQTE9BRDogJ3BpIHBpLXVwbG9hZCcsXG4gIFVTRVI6ICdwaSBwaS11c2VyJyxcbiAgVVNFUl9FRElUOiAncGkgcGktdXNlci1lZGl0JyxcbiAgVVNFUl9NSU5VUzogJ3BpIHBpLXVzZXItbWludXMnLFxuICBVU0VSX1BMVVM6ICdwaSBwaS11c2VyLXBsdXMnLFxuICBVU0VSUzogJ3BpIHBpLXVzZXJzJyxcbiAgVkVOVVM6ICdwaSBwaS12ZW51cycsXG4gIFZFUklGSUVEOiAncGkgcGktdmVyaWZpZWQnLFxuICBWSURFTzogJ3BpIHBpLXZpZGVvJyxcbiAgVklNRU86ICdwaSBwaS12aW1lbycsXG4gIFZPTFVNRV9ET1dOOiAncGkgcGktdm9sdW1lLWRvd24nLFxuICBWT0xVTUVfT0ZGOiAncGkgcGktdm9sdW1lLW9mZicsXG4gIFZPTFVNRV9VUDogJ3BpIHBpLXZvbHVtZS11cCcsXG4gIFdBTExFVDogJ3BpIHBpLXdhbGxldCcsXG4gIFdBUkVIT1VTRTogJ3BpIHBpLXdhcmVob3VzZScsXG4gIFdBVkVfUFVMU0U6ICdwaSBwaS13YXZlLXB1bHNlJyxcbiAgV0hBVFNBUFA6ICdwaSBwaS13aGF0c2FwcCcsXG4gIFdJRkk6ICdwaSBwaS13aWZpJyxcbiAgV0lORE9XX01BWElNSVpFOiAncGkgcGktd2luZG93LW1heGltaXplJyxcbiAgV0lORE9XX01JTklNSVpFOiAncGkgcGktd2luZG93LW1pbmltaXplJyxcbiAgV1JFTkNIOiAncGkgcGktd3JlbmNoJyxcbiAgWU9VVFVCRTogJ3BpIHBpLXlvdXR1YmUnXG59O1xuXG52YXIgVG9hc3RTZXZlcml0aWVzID0ge1xuICBJTkZPOiAnaW5mbycsXG4gIFdBUk46ICd3YXJuJyxcbiAgRVJST1I6ICdlcnJvcicsXG4gIFNVQ0NFU1M6ICdzdWNjZXNzJ1xufTtcblxuZXhwb3J0IHsgRmlsdGVyTWF0Y2hNb2RlLCBGaWx0ZXJPcGVyYXRvciwgRmlsdGVyU2VydmljZSwgUHJpbWVJY29ucywgVG9hc3RTZXZlcml0aWVzIGFzIFRvYXN0U2V2ZXJpdHkgfTtcbiIsImltcG9ydCB7IHJlZ2lzdGVyTGljZW5zZSwgdmVyaWZ5TGljZW5zZSB9IGZyb20gJ0BwcmltZXVpL2xpY2Vuc2UtbWFuYWdlcic7XG5pbXBvcnQgeyBUaGVtZVNlcnZpY2UsIFRoZW1lIH0gZnJvbSAnQHByaW1ldWl4L3N0eWxlZCc7XG5pbXBvcnQgeyBtZXJnZUtleXMgfSBmcm9tICdAcHJpbWV1aXgvdXRpbHMnO1xuaW1wb3J0IHsgRmlsdGVyTWF0Y2hNb2RlIH0gZnJvbSAnQHByaW1ldnVlL2NvcmUvYXBpJztcbmltcG9ydCBCYXNlU3R5bGUgZnJvbSAnQHByaW1ldnVlL2NvcmUvYmFzZS9zdHlsZSc7XG5pbXBvcnQgeyBzaG93SW52YWxpZExpY2Vuc2VCYW5uZXIgfSBmcm9tICdAcHJpbWV2dWUvY29yZS9saWNlbnNlL2xpY2Vuc2VCYW5uZXInO1xuaW1wb3J0IFByaW1lVnVlU2VydmljZSBmcm9tICdAcHJpbWV2dWUvY29yZS9zZXJ2aWNlJztcbmltcG9ydCB7IGluamVjdCwgcmVmLCByZWFkb25seSwgcmVhY3RpdmUsIHdhdGNoIH0gZnJvbSAndnVlJztcblxuZnVuY3Rpb24gX3R5cGVvZihvKSB7IFwiQGJhYmVsL2hlbHBlcnMgLSB0eXBlb2ZcIjsgcmV0dXJuIF90eXBlb2YgPSBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIFN5bWJvbCAmJiBcInN5bWJvbFwiID09IHR5cGVvZiBTeW1ib2wuaXRlcmF0b3IgPyBmdW5jdGlvbiAobykgeyByZXR1cm4gdHlwZW9mIG87IH0gOiBmdW5jdGlvbiAobykgeyByZXR1cm4gbyAmJiBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIFN5bWJvbCAmJiBvLmNvbnN0cnVjdG9yID09PSBTeW1ib2wgJiYgbyAhPT0gU3ltYm9sLnByb3RvdHlwZSA/IFwic3ltYm9sXCIgOiB0eXBlb2YgbzsgfSwgX3R5cGVvZihvKTsgfVxuZnVuY3Rpb24gb3duS2V5cyhlLCByKSB7IHZhciB0ID0gT2JqZWN0LmtleXMoZSk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBvID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgciAmJiAobyA9IG8uZmlsdGVyKGZ1bmN0aW9uIChyKSB7IHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGUsIHIpLmVudW1lcmFibGU7IH0pKSwgdC5wdXNoLmFwcGx5KHQsIG8pOyB9IHJldHVybiB0OyB9XG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKGUpIHsgZm9yICh2YXIgciA9IDE7IHIgPCBhcmd1bWVudHMubGVuZ3RoOyByKyspIHsgdmFyIHQgPSBudWxsICE9IGFyZ3VtZW50c1tyXSA/IGFyZ3VtZW50c1tyXSA6IHt9OyByICUgMiA/IG93bktleXMoT2JqZWN0KHQpLCB0cnVlKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0W3JdKTsgfSkgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGUsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHQpKSA6IG93bktleXMoT2JqZWN0KHQpKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIHIpKTsgfSk7IH0gcmV0dXJuIGU7IH1cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0KSB7IHJldHVybiAociA9IF90b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHsgdmFsdWU6IHQsIGVudW1lcmFibGU6IHRydWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSwgd3JpdGFibGU6IHRydWUgfSkgOiBlW3JdID0gdCwgZTsgfVxuZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkgeyB2YXIgaSA9IF90b1ByaW1pdGl2ZSh0LCBcInN0cmluZ1wiKTsgcmV0dXJuIFwic3ltYm9sXCIgPT0gX3R5cGVvZihpKSA/IGkgOiBpICsgXCJcIjsgfVxuZnVuY3Rpb24gX3RvUHJpbWl0aXZlKHQsIHIpIHsgaWYgKFwib2JqZWN0XCIgIT0gX3R5cGVvZih0KSB8fCAhdCkgcmV0dXJuIHQ7IHZhciBlID0gdFtTeW1ib2wudG9QcmltaXRpdmVdOyBpZiAodm9pZCAwICE9PSBlKSB7IHZhciBpID0gZS5jYWxsKHQsIHIpOyBpZiAoXCJvYmplY3RcIiAhPSBfdHlwZW9mKGkpKSByZXR1cm4gaTsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuXCIpOyB9IHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7IH1cbnZhciBSRUxFQVNFX0RBVEUgPSAnMjAyNi0wNy0xNSc7XG52YXIgZGVmYXVsdE9wdGlvbnMgPSB7XG4gIHJpcHBsZTogZmFsc2UsXG4gIGlucHV0VmFyaWFudDogbnVsbCxcbiAgbGljZW5zZTogbnVsbCxcbiAgbG9jYWxlOiB7XG4gICAgc3RhcnRzV2l0aDogJ1N0YXJ0cyB3aXRoJyxcbiAgICBjb250YWluczogJ0NvbnRhaW5zJyxcbiAgICBub3RDb250YWluczogJ05vdCBjb250YWlucycsXG4gICAgZW5kc1dpdGg6ICdFbmRzIHdpdGgnLFxuICAgIGVxdWFsczogJ0VxdWFscycsXG4gICAgbm90RXF1YWxzOiAnTm90IGVxdWFscycsXG4gICAgbm9GaWx0ZXI6ICdObyBGaWx0ZXInLFxuICAgIGx0OiAnTGVzcyB0aGFuJyxcbiAgICBsdGU6ICdMZXNzIHRoYW4gb3IgZXF1YWwgdG8nLFxuICAgIGd0OiAnR3JlYXRlciB0aGFuJyxcbiAgICBndGU6ICdHcmVhdGVyIHRoYW4gb3IgZXF1YWwgdG8nLFxuICAgIGRhdGVJczogJ0RhdGUgaXMnLFxuICAgIGRhdGVJc05vdDogJ0RhdGUgaXMgbm90JyxcbiAgICBkYXRlQmVmb3JlOiAnRGF0ZSBpcyBiZWZvcmUnLFxuICAgIGRhdGVBZnRlcjogJ0RhdGUgaXMgYWZ0ZXInLFxuICAgIGNsZWFyOiAnQ2xlYXInLFxuICAgIGFwcGx5OiAnQXBwbHknLFxuICAgIG1hdGNoQWxsOiAnTWF0Y2ggQWxsJyxcbiAgICBtYXRjaEFueTogJ01hdGNoIEFueScsXG4gICAgYWRkUnVsZTogJ0FkZCBSdWxlJyxcbiAgICByZW1vdmVSdWxlOiAnUmVtb3ZlIFJ1bGUnLFxuICAgIGFjY2VwdDogJ1llcycsXG4gICAgcmVqZWN0OiAnTm8nLFxuICAgIGNob29zZTogJ0Nob29zZScsXG4gICAgdXBsb2FkOiAnVXBsb2FkJyxcbiAgICBjYW5jZWw6ICdDYW5jZWwnLFxuICAgIGNvbXBsZXRlZDogJ0NvbXBsZXRlZCcsXG4gICAgcGVuZGluZzogJ1BlbmRpbmcnLFxuICAgIGZpbGVTaXplVHlwZXM6IFsnQicsICdLQicsICdNQicsICdHQicsICdUQicsICdQQicsICdFQicsICdaQicsICdZQiddLFxuICAgIGRheU5hbWVzOiBbJ1N1bmRheScsICdNb25kYXknLCAnVHVlc2RheScsICdXZWRuZXNkYXknLCAnVGh1cnNkYXknLCAnRnJpZGF5JywgJ1NhdHVyZGF5J10sXG4gICAgZGF5TmFtZXNTaG9ydDogWydTdW4nLCAnTW9uJywgJ1R1ZScsICdXZWQnLCAnVGh1JywgJ0ZyaScsICdTYXQnXSxcbiAgICBkYXlOYW1lc01pbjogWydTdScsICdNbycsICdUdScsICdXZScsICdUaCcsICdGcicsICdTYSddLFxuICAgIG1vbnRoTmFtZXM6IFsnSmFudWFyeScsICdGZWJydWFyeScsICdNYXJjaCcsICdBcHJpbCcsICdNYXknLCAnSnVuZScsICdKdWx5JywgJ0F1Z3VzdCcsICdTZXB0ZW1iZXInLCAnT2N0b2JlcicsICdOb3ZlbWJlcicsICdEZWNlbWJlciddLFxuICAgIG1vbnRoTmFtZXNTaG9ydDogWydKYW4nLCAnRmViJywgJ01hcicsICdBcHInLCAnTWF5JywgJ0p1bicsICdKdWwnLCAnQXVnJywgJ1NlcCcsICdPY3QnLCAnTm92JywgJ0RlYyddLFxuICAgIGNob29zZVllYXI6ICdDaG9vc2UgWWVhcicsXG4gICAgY2hvb3NlTW9udGg6ICdDaG9vc2UgTW9udGgnLFxuICAgIGNob29zZURhdGU6ICdDaG9vc2UgRGF0ZScsXG4gICAgcHJldkRlY2FkZTogJ1ByZXZpb3VzIERlY2FkZScsXG4gICAgbmV4dERlY2FkZTogJ05leHQgRGVjYWRlJyxcbiAgICBwcmV2WWVhcjogJ1ByZXZpb3VzIFllYXInLFxuICAgIG5leHRZZWFyOiAnTmV4dCBZZWFyJyxcbiAgICBwcmV2TW9udGg6ICdQcmV2aW91cyBNb250aCcsXG4gICAgbmV4dE1vbnRoOiAnTmV4dCBNb250aCcsXG4gICAgcHJldkhvdXI6ICdQcmV2aW91cyBIb3VyJyxcbiAgICBuZXh0SG91cjogJ05leHQgSG91cicsXG4gICAgcHJldk1pbnV0ZTogJ1ByZXZpb3VzIE1pbnV0ZScsXG4gICAgbmV4dE1pbnV0ZTogJ05leHQgTWludXRlJyxcbiAgICBwcmV2U2Vjb25kOiAnUHJldmlvdXMgU2Vjb25kJyxcbiAgICBuZXh0U2Vjb25kOiAnTmV4dCBTZWNvbmQnLFxuICAgIGFtOiAnYW0nLFxuICAgIHBtOiAncG0nLFxuICAgIHRvZGF5OiAnVG9kYXknLFxuICAgIHdlZWtIZWFkZXI6ICdXaycsXG4gICAgZmlyc3REYXlPZldlZWs6IDAsXG4gICAgc2hvd01vbnRoQWZ0ZXJZZWFyOiBmYWxzZSxcbiAgICBkYXRlRm9ybWF0OiAnbW0vZGQveXknLFxuICAgIHdlYWs6ICdXZWFrJyxcbiAgICBtZWRpdW06ICdNZWRpdW0nLFxuICAgIHN0cm9uZzogJ1N0cm9uZycsXG4gICAgcGFzc3dvcmRQcm9tcHQ6ICdFbnRlciBhIHBhc3N3b3JkJyxcbiAgICBlbXB0eUZpbHRlck1lc3NhZ2U6ICdObyByZXN1bHRzIGZvdW5kJyxcbiAgICBzZWFyY2hNZXNzYWdlOiAnezB9IHJlc3VsdHMgYXJlIGF2YWlsYWJsZScsXG4gICAgc2VsZWN0aW9uTWVzc2FnZTogJ3swfSBpdGVtcyBzZWxlY3RlZCcsXG4gICAgZW1wdHlTZWxlY3Rpb25NZXNzYWdlOiAnTm8gc2VsZWN0ZWQgaXRlbScsXG4gICAgZW1wdHlTZWFyY2hNZXNzYWdlOiAnTm8gcmVzdWx0cyBmb3VuZCcsXG4gICAgZmlsZUNob3Nlbk1lc3NhZ2U6ICd7MH0gZmlsZXMnLFxuICAgIG5vRmlsZUNob3Nlbk1lc3NhZ2U6ICdObyBmaWxlIGNob3NlbicsXG4gICAgZW1wdHlNZXNzYWdlOiAnTm8gYXZhaWxhYmxlIG9wdGlvbnMnLFxuICAgIGFyaWE6IHtcbiAgICAgIHRydWVMYWJlbDogJ1RydWUnLFxuICAgICAgZmFsc2VMYWJlbDogJ0ZhbHNlJyxcbiAgICAgIG51bGxMYWJlbDogJ05vdCBTZWxlY3RlZCcsXG4gICAgICBzdGFyOiAnMSBzdGFyJyxcbiAgICAgIHN0YXJzOiAne3N0YXJ9IHN0YXJzJyxcbiAgICAgIHNlbGVjdEFsbDogJ0FsbCBpdGVtcyBzZWxlY3RlZCcsXG4gICAgICB1bnNlbGVjdEFsbDogJ0FsbCBpdGVtcyB1bnNlbGVjdGVkJyxcbiAgICAgIGNsb3NlOiAnQ2xvc2UnLFxuICAgICAgcHJldmlvdXM6ICdQcmV2aW91cycsXG4gICAgICBuZXh0OiAnTmV4dCcsXG4gICAgICBuYXZpZ2F0aW9uOiAnTmF2aWdhdGlvbicsXG4gICAgICBzY3JvbGxUb3A6ICdTY3JvbGwgVG9wJyxcbiAgICAgIG1vdmVUb3A6ICdNb3ZlIFRvcCcsXG4gICAgICBtb3ZlVXA6ICdNb3ZlIFVwJyxcbiAgICAgIG1vdmVEb3duOiAnTW92ZSBEb3duJyxcbiAgICAgIG1vdmVCb3R0b206ICdNb3ZlIEJvdHRvbScsXG4gICAgICBtb3ZlVG9UYXJnZXQ6ICdNb3ZlIHRvIFRhcmdldCcsXG4gICAgICBtb3ZlVG9Tb3VyY2U6ICdNb3ZlIHRvIFNvdXJjZScsXG4gICAgICBtb3ZlQWxsVG9UYXJnZXQ6ICdNb3ZlIEFsbCB0byBUYXJnZXQnLFxuICAgICAgbW92ZUFsbFRvU291cmNlOiAnTW92ZSBBbGwgdG8gU291cmNlJyxcbiAgICAgIHBhZ2VMYWJlbDogJ1BhZ2Uge3BhZ2V9JyxcbiAgICAgIGZpcnN0UGFnZUxhYmVsOiAnRmlyc3QgUGFnZScsXG4gICAgICBsYXN0UGFnZUxhYmVsOiAnTGFzdCBQYWdlJyxcbiAgICAgIG5leHRQYWdlTGFiZWw6ICdOZXh0IFBhZ2UnLFxuICAgICAgcHJldlBhZ2VMYWJlbDogJ1ByZXZpb3VzIFBhZ2UnLFxuICAgICAgcm93c1BlclBhZ2VMYWJlbDogJ1Jvd3MgcGVyIHBhZ2UnLFxuICAgICAganVtcFRvUGFnZURyb3Bkb3duTGFiZWw6ICdKdW1wIHRvIFBhZ2UgRHJvcGRvd24nLFxuICAgICAganVtcFRvUGFnZUlucHV0TGFiZWw6ICdKdW1wIHRvIFBhZ2UgSW5wdXQnLFxuICAgICAgc2VsZWN0Um93OiAnUm93IFNlbGVjdGVkJyxcbiAgICAgIHVuc2VsZWN0Um93OiAnUm93IFVuc2VsZWN0ZWQnLFxuICAgICAgZXhwYW5kUm93OiAnUm93IEV4cGFuZGVkJyxcbiAgICAgIGNvbGxhcHNlUm93OiAnUm93IENvbGxhcHNlZCcsXG4gICAgICBzaG93RmlsdGVyTWVudTogJ1Nob3cgRmlsdGVyIE1lbnUnLFxuICAgICAgaGlkZUZpbHRlck1lbnU6ICdIaWRlIEZpbHRlciBNZW51JyxcbiAgICAgIGZpbHRlck9wZXJhdG9yOiAnRmlsdGVyIE9wZXJhdG9yJyxcbiAgICAgIGZpbHRlckNvbnN0cmFpbnQ6ICdGaWx0ZXIgQ29uc3RyYWludCcsXG4gICAgICBlZGl0Um93OiAnUm93IEVkaXQnLFxuICAgICAgc2F2ZUVkaXQ6ICdTYXZlIEVkaXQnLFxuICAgICAgY2FuY2VsRWRpdDogJ0NhbmNlbCBFZGl0JyxcbiAgICAgIGxpc3RWaWV3OiAnTGlzdCBWaWV3JyxcbiAgICAgIGdyaWRWaWV3OiAnR3JpZCBWaWV3JyxcbiAgICAgIHNsaWRlOiAnU2xpZGUnLFxuICAgICAgc2xpZGVOdW1iZXI6ICd7c2xpZGVOdW1iZXJ9JyxcbiAgICAgIHpvb21JbWFnZTogJ1pvb20gSW1hZ2UnLFxuICAgICAgem9vbUluOiAnWm9vbSBJbicsXG4gICAgICB6b29tT3V0OiAnWm9vbSBPdXQnLFxuICAgICAgcm90YXRlUmlnaHQ6ICdSb3RhdGUgUmlnaHQnLFxuICAgICAgcm90YXRlTGVmdDogJ1JvdGF0ZSBMZWZ0JyxcbiAgICAgIGxpc3RMYWJlbDogJ09wdGlvbiBMaXN0J1xuICAgIH1cbiAgfSxcbiAgZmlsdGVyTWF0Y2hNb2RlT3B0aW9uczoge1xuICAgIHRleHQ6IFtGaWx0ZXJNYXRjaE1vZGUuU1RBUlRTX1dJVEgsIEZpbHRlck1hdGNoTW9kZS5DT05UQUlOUywgRmlsdGVyTWF0Y2hNb2RlLk5PVF9DT05UQUlOUywgRmlsdGVyTWF0Y2hNb2RlLkVORFNfV0lUSCwgRmlsdGVyTWF0Y2hNb2RlLkVRVUFMUywgRmlsdGVyTWF0Y2hNb2RlLk5PVF9FUVVBTFNdLFxuICAgIG51bWVyaWM6IFtGaWx0ZXJNYXRjaE1vZGUuRVFVQUxTLCBGaWx0ZXJNYXRjaE1vZGUuTk9UX0VRVUFMUywgRmlsdGVyTWF0Y2hNb2RlLkxFU1NfVEhBTiwgRmlsdGVyTWF0Y2hNb2RlLkxFU1NfVEhBTl9PUl9FUVVBTF9UTywgRmlsdGVyTWF0Y2hNb2RlLkdSRUFURVJfVEhBTiwgRmlsdGVyTWF0Y2hNb2RlLkdSRUFURVJfVEhBTl9PUl9FUVVBTF9UT10sXG4gICAgZGF0ZTogW0ZpbHRlck1hdGNoTW9kZS5EQVRFX0lTLCBGaWx0ZXJNYXRjaE1vZGUuREFURV9JU19OT1QsIEZpbHRlck1hdGNoTW9kZS5EQVRFX0JFRk9SRSwgRmlsdGVyTWF0Y2hNb2RlLkRBVEVfQUZURVJdXG4gIH0sXG4gIHpJbmRleDoge1xuICAgIG1vZGFsOiAxMTAwLFxuICAgIG92ZXJsYXk6IDEwMDAsXG4gICAgbWVudTogMTAwMCxcbiAgICB0b29sdGlwOiAxMTAwXG4gIH0sXG4gIHRoZW1lOiB1bmRlZmluZWQsXG4gIHVuc3R5bGVkOiBmYWxzZSxcbiAgcHQ6IHVuZGVmaW5lZCxcbiAgcHRPcHRpb25zOiB7XG4gICAgbWVyZ2VTZWN0aW9uczogdHJ1ZSxcbiAgICBtZXJnZVByb3BzOiBmYWxzZVxuICB9LFxuICBjc3A6IHtcbiAgICBub25jZTogdW5kZWZpbmVkXG4gIH1cbn07XG52YXIgUHJpbWVWdWVTeW1ib2wgPSBTeW1ib2woKTtcbmZ1bmN0aW9uIHVzZVByaW1lVnVlKCkge1xuICB2YXIgUHJpbWVWdWUgPSBpbmplY3QoUHJpbWVWdWVTeW1ib2wpO1xuICBpZiAoIVByaW1lVnVlKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKCdQcmltZVZ1ZSBpcyBub3QgaW5zdGFsbGVkIScpO1xuICB9XG4gIHJldHVybiBQcmltZVZ1ZTtcbn1cbmZ1bmN0aW9uIHNldHVwKGFwcCwgb3B0aW9ucykge1xuICB2YXIgX3ZlcmlmaWVkID0gcmVmKG51bGwpO1xuICBpZiAob3B0aW9ucy5saWNlbnNlKSB7XG4gICAgcmVnaXN0ZXJMaWNlbnNlKHtcbiAgICAgIHByaW1ldWk6IG9wdGlvbnMubGljZW5zZVxuICAgIH0pO1xuICB9XG4gIHZlcmlmeUxpY2Vuc2UoJ3ByaW1ldWknLCB7XG4gICAgcmVsZWFzZURhdGU6IFJFTEVBU0VfREFURVxuICB9KS50aGVuKGZ1bmN0aW9uIChyZXN1bHQpIHtcbiAgICBfdmVyaWZpZWQudmFsdWUgPSByZXN1bHQudmFsaWQ7XG4gICAgaWYgKCFyZXN1bHQudmFsaWQpIHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1jb25zb2xlXG4gICAgICBjb25zb2xlLndhcm4oXCJbUHJpbWVVSV0gXCIuY29uY2F0KHJlc3VsdC5tZXNzYWdlKSk7XG4gICAgICBzaG93SW52YWxpZExpY2Vuc2VCYW5uZXIoKTtcbiAgICB9XG4gIH0pO1xuICB2YXIgUHJpbWVWdWUgPSB7XG4gICAgY29uZmlnOiByZWFjdGl2ZShvcHRpb25zKSxcbiAgICB2ZXJpZmllZDogcmVhZG9ubHkoX3ZlcmlmaWVkKVxuICB9O1xuICBhcHAuY29uZmlnLmdsb2JhbFByb3BlcnRpZXMuJHByaW1ldnVlID0gUHJpbWVWdWU7XG4gIGFwcC5wcm92aWRlKFByaW1lVnVlU3ltYm9sLCBQcmltZVZ1ZSk7XG4gIGNsZWFyQ29uZmlnKCk7XG4gIHNldHVwQ29uZmlnKGFwcCwgUHJpbWVWdWUpO1xuICByZXR1cm4gUHJpbWVWdWU7XG59XG52YXIgc3RvcFdhdGNoZXJzID0gW107XG5mdW5jdGlvbiBjbGVhckNvbmZpZygpIHtcbiAgVGhlbWVTZXJ2aWNlLmNsZWFyKCk7XG4gIHN0b3BXYXRjaGVycy5mb3JFYWNoKGZ1bmN0aW9uIChmbikge1xuICAgIHJldHVybiBmbiA9PT0gbnVsbCB8fCBmbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogZm4oKTtcbiAgfSk7XG4gIHN0b3BXYXRjaGVycyA9IFtdO1xufVxuZnVuY3Rpb24gc2V0dXBDb25maWcoYXBwLCBQcmltZVZ1ZSkge1xuICB2YXIgaXNUaGVtZUNoYW5nZWQgPSByZWYoZmFsc2UpO1xuXG4gIC8qKiogTWV0aG9kcyBhbmQgU2VydmljZXMgKioqL1xuICB2YXIgbG9hZENvbW1vblRoZW1lID0gZnVuY3Rpb24gbG9hZENvbW1vblRoZW1lKCkge1xuICAgIHZhciBfUHJpbWVWdWUkY29uZmlnO1xuICAgIGlmICgoKF9QcmltZVZ1ZSRjb25maWcgPSBQcmltZVZ1ZS5jb25maWcpID09PSBudWxsIHx8IF9QcmltZVZ1ZSRjb25maWcgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9QcmltZVZ1ZSRjb25maWcudGhlbWUpID09PSAnbm9uZScpIHJldHVybjtcblxuICAgIC8vIGNvbW1vblxuICAgIGlmICghVGhlbWUuaXNTdHlsZU5hbWVMb2FkZWQoJ2NvbW1vbicpKSB7XG4gICAgICB2YXIgX0Jhc2VTdHlsZSRnZXRDb21tb25ULCBfUHJpbWVWdWUkY29uZmlnMjtcbiAgICAgIHZhciBfcmVmID0gKChfQmFzZVN0eWxlJGdldENvbW1vblQgPSBCYXNlU3R5bGUuZ2V0Q29tbW9uVGhlbWUpID09PSBudWxsIHx8IF9CYXNlU3R5bGUkZ2V0Q29tbW9uVCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX0Jhc2VTdHlsZSRnZXRDb21tb25ULmNhbGwoQmFzZVN0eWxlKSkgfHwge30sXG4gICAgICAgIHByaW1pdGl2ZSA9IF9yZWYucHJpbWl0aXZlLFxuICAgICAgICBzZW1hbnRpYyA9IF9yZWYuc2VtYW50aWMsXG4gICAgICAgIGdsb2JhbCA9IF9yZWYuZ2xvYmFsLFxuICAgICAgICBzdHlsZSA9IF9yZWYuc3R5bGU7XG4gICAgICB2YXIgc3R5bGVPcHRpb25zID0ge1xuICAgICAgICBub25jZTogKF9QcmltZVZ1ZSRjb25maWcyID0gUHJpbWVWdWUuY29uZmlnKSA9PT0gbnVsbCB8fCBfUHJpbWVWdWUkY29uZmlnMiA9PT0gdm9pZCAwIHx8IChfUHJpbWVWdWUkY29uZmlnMiA9IF9QcmltZVZ1ZSRjb25maWcyLmNzcCkgPT09IG51bGwgfHwgX1ByaW1lVnVlJGNvbmZpZzIgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9QcmltZVZ1ZSRjb25maWcyLm5vbmNlXG4gICAgICB9O1xuICAgICAgQmFzZVN0eWxlLmxvYWQocHJpbWl0aXZlID09PSBudWxsIHx8IHByaW1pdGl2ZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogcHJpbWl0aXZlLmNzcywgX29iamVjdFNwcmVhZCh7XG4gICAgICAgIG5hbWU6ICdwcmltaXRpdmUtdmFyaWFibGVzJ1xuICAgICAgfSwgc3R5bGVPcHRpb25zKSk7XG4gICAgICBCYXNlU3R5bGUubG9hZChzZW1hbnRpYyA9PT0gbnVsbCB8fCBzZW1hbnRpYyA9PT0gdm9pZCAwID8gdm9pZCAwIDogc2VtYW50aWMuY3NzLCBfb2JqZWN0U3ByZWFkKHtcbiAgICAgICAgbmFtZTogJ3NlbWFudGljLXZhcmlhYmxlcydcbiAgICAgIH0sIHN0eWxlT3B0aW9ucykpO1xuICAgICAgQmFzZVN0eWxlLmxvYWQoZ2xvYmFsID09PSBudWxsIHx8IGdsb2JhbCA9PT0gdm9pZCAwID8gdm9pZCAwIDogZ2xvYmFsLmNzcywgX29iamVjdFNwcmVhZCh7XG4gICAgICAgIG5hbWU6ICdnbG9iYWwtdmFyaWFibGVzJ1xuICAgICAgfSwgc3R5bGVPcHRpb25zKSk7XG4gICAgICBCYXNlU3R5bGUubG9hZFN0eWxlKF9vYmplY3RTcHJlYWQoe1xuICAgICAgICBuYW1lOiAnZ2xvYmFsLXN0eWxlJ1xuICAgICAgfSwgc3R5bGVPcHRpb25zKSwgc3R5bGUpO1xuICAgICAgVGhlbWUuc2V0TG9hZGVkU3R5bGVOYW1lKCdjb21tb24nKTtcbiAgICB9XG4gIH07XG4gIFRoZW1lU2VydmljZS5vbigndGhlbWU6Y2hhbmdlJywgZnVuY3Rpb24gKG5ld1RoZW1lKSB7XG4gICAgaWYgKCFpc1RoZW1lQ2hhbmdlZC52YWx1ZSkge1xuICAgICAgYXBwLmNvbmZpZy5nbG9iYWxQcm9wZXJ0aWVzLiRwcmltZXZ1ZS5jb25maWcudGhlbWUgPSBuZXdUaGVtZTtcbiAgICAgIGlzVGhlbWVDaGFuZ2VkLnZhbHVlID0gdHJ1ZTtcbiAgICB9XG4gIH0pO1xuXG4gIC8qKiogV2F0Y2hlcnMgKioqL1xuICB2YXIgc3RvcENvbmZpZ1dhdGNoZXIgPSB3YXRjaChQcmltZVZ1ZS5jb25maWcsIGZ1bmN0aW9uIChuZXdWYWx1ZSwgb2xkVmFsdWUpIHtcbiAgICBQcmltZVZ1ZVNlcnZpY2UuZW1pdCgnY29uZmlnOmNoYW5nZScsIHtcbiAgICAgIG5ld1ZhbHVlOiBuZXdWYWx1ZSxcbiAgICAgIG9sZFZhbHVlOiBvbGRWYWx1ZVxuICAgIH0pO1xuICB9LCB7XG4gICAgaW1tZWRpYXRlOiB0cnVlLFxuICAgIGRlZXA6IHRydWVcbiAgfSk7XG4gIHZhciBzdG9wUmlwcGxlV2F0Y2hlciA9IHdhdGNoKGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gUHJpbWVWdWUuY29uZmlnLnJpcHBsZTtcbiAgfSwgZnVuY3Rpb24gKG5ld1ZhbHVlLCBvbGRWYWx1ZSkge1xuICAgIFByaW1lVnVlU2VydmljZS5lbWl0KCdjb25maWc6cmlwcGxlOmNoYW5nZScsIHtcbiAgICAgIG5ld1ZhbHVlOiBuZXdWYWx1ZSxcbiAgICAgIG9sZFZhbHVlOiBvbGRWYWx1ZVxuICAgIH0pO1xuICB9LCB7XG4gICAgaW1tZWRpYXRlOiB0cnVlLFxuICAgIGRlZXA6IHRydWVcbiAgfSk7XG4gIHZhciBzdG9wVGhlbWVXYXRjaGVyID0gd2F0Y2goZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBQcmltZVZ1ZS5jb25maWcudGhlbWU7XG4gIH0sIGZ1bmN0aW9uIChuZXdWYWx1ZSwgb2xkVmFsdWUpIHtcbiAgICBpZiAoIWlzVGhlbWVDaGFuZ2VkLnZhbHVlKSB7XG4gICAgICBUaGVtZS5zZXRUaGVtZShuZXdWYWx1ZSk7XG4gICAgfVxuICAgIGlmICghUHJpbWVWdWUuY29uZmlnLnVuc3R5bGVkKSB7XG4gICAgICBsb2FkQ29tbW9uVGhlbWUoKTtcbiAgICB9XG4gICAgaXNUaGVtZUNoYW5nZWQudmFsdWUgPSBmYWxzZTtcbiAgICBQcmltZVZ1ZVNlcnZpY2UuZW1pdCgnY29uZmlnOnRoZW1lOmNoYW5nZScsIHtcbiAgICAgIG5ld1ZhbHVlOiBuZXdWYWx1ZSxcbiAgICAgIG9sZFZhbHVlOiBvbGRWYWx1ZVxuICAgIH0pO1xuICB9LCB7XG4gICAgaW1tZWRpYXRlOiB0cnVlLFxuICAgIGRlZXA6IGZhbHNlXG4gIH0pO1xuICB2YXIgc3RvcFVuc3R5bGVkV2F0Y2hlciA9IHdhdGNoKGZ1bmN0aW9uICgpIHtcbiAgICByZXR1cm4gUHJpbWVWdWUuY29uZmlnLnVuc3R5bGVkO1xuICB9LCBmdW5jdGlvbiAobmV3VmFsdWUsIG9sZFZhbHVlKSB7XG4gICAgaWYgKCFuZXdWYWx1ZSAmJiBQcmltZVZ1ZS5jb25maWcudGhlbWUpIHtcbiAgICAgIGxvYWRDb21tb25UaGVtZSgpO1xuICAgIH1cbiAgICBQcmltZVZ1ZVNlcnZpY2UuZW1pdCgnY29uZmlnOnVuc3R5bGVkOmNoYW5nZScsIHtcbiAgICAgIG5ld1ZhbHVlOiBuZXdWYWx1ZSxcbiAgICAgIG9sZFZhbHVlOiBvbGRWYWx1ZVxuICAgIH0pO1xuICB9LCB7XG4gICAgaW1tZWRpYXRlOiB0cnVlLFxuICAgIGRlZXA6IHRydWVcbiAgfSk7XG4gIHN0b3BXYXRjaGVycy5wdXNoKHN0b3BDb25maWdXYXRjaGVyKTtcbiAgc3RvcFdhdGNoZXJzLnB1c2goc3RvcFJpcHBsZVdhdGNoZXIpO1xuICBzdG9wV2F0Y2hlcnMucHVzaChzdG9wVGhlbWVXYXRjaGVyKTtcbiAgc3RvcFdhdGNoZXJzLnB1c2goc3RvcFVuc3R5bGVkV2F0Y2hlcik7XG59XG52YXIgUHJpbWVWdWUgPSB7XG4gIGluc3RhbGw6IGZ1bmN0aW9uIGluc3RhbGwoYXBwLCBvcHRpb25zKSB7XG4gICAgdmFyIGNvbmZpZ09wdGlvbnMgPSBtZXJnZUtleXMoZGVmYXVsdE9wdGlvbnMsIG9wdGlvbnMpO1xuICAgIHNldHVwKGFwcCwgY29uZmlnT3B0aW9ucyk7XG4gIH1cbn07XG5cbmV4cG9ydCB7IGNsZWFyQ29uZmlnLCBQcmltZVZ1ZSBhcyBkZWZhdWx0LCBkZWZhdWx0T3B0aW9ucywgc2V0dXAsIHNldHVwQ29uZmlnLCB1c2VQcmltZVZ1ZSB9O1xuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDddLCJtYXBwaW5ncyI6Ijs7OztBQW1DQSxJQUFNLEVBQUUsR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLElBQUksR0FBRyxJQUFJLEdBQUcsT0FBTztDQVJ6QyxHQUFHO0NBQ0gsR0FBRztDQUNILEdBQUc7Q0FDSCxHQUFHO0NBQ0gsR0FBRztDQUNILElBQUk7Q0FDSixJQUFJO0FBRXFDO0FBQzdDLElBQU1BLE1BQUk7QUFDVixJQUFNLElBQUk7QUFDVixJQUFNLEtBQUs7QUFLWCxJQUFNLE9BQU8sSUFBSSxPQUFPO0NBQ3BCLE1BQU0sSUFBSSxNQUFNLENBQUM7QUFDckI7QUFDQSxJQUFNLFNBQVMsTUFBTSxPQUFPLE1BQU07QUFDbEMsSUFBTSxTQUFTLE1BQU0sT0FBTyxNQUFNO0FBQ2xDLElBQU1DLGFBQVcsTUFBTSxhQUFhLGNBQWUsWUFBWSxPQUFPLENBQUMsS0FBSyxFQUFFLFlBQVksU0FBUzs7QUFFbkcsSUFBTUMsWUFBVSxHQUFHLE1BQU0sQ0FBQ0QsVUFBUSxDQUFDLEtBQU0sT0FBTyxNQUFNLFlBQVksSUFBSSxLQUFLLEVBQUUsV0FBVyxJQUNsRixJQUFJLHFCQUFxQixJQUN6Qjs7QUFFTixJQUFNLE9BQU8sUUFBUSxJQUFJLFdBQVcsR0FBRztBQUN2QyxJQUFNLFFBQVEsUUFBUSxXQUFXLEtBQUssR0FBRztBQUN6QyxJQUFNLFFBQVEsR0FBRyxRQUFRLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBQyxTQUFTLEtBQUssR0FBRztBQUN6RCxJQUFNLGNBQWMsTUFBTSxNQUFNLEtBQUtDLFNBQU8sQ0FBQyxDQUFDLENBQUMsQ0FDMUMsS0FBSyxNQUFNLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUN0QixLQUFLLEVBQUU7QUFDWixJQUFNLElBQUk7Q0FBRSxJQUFJO0NBQUksSUFBSTtDQUFJLEdBQUc7Q0FBSSxHQUFHO0NBQUksR0FBRztDQUFJLEdBQUc7QUFBSTtBQUN4RCxJQUFNLE9BQU8sT0FBTztDQUNoQixJQUFJLE1BQU0sRUFBRSxNQUFNLE1BQU0sRUFBRSxJQUN0QixPQUFPLEtBQUssRUFBRTtDQUNsQixJQUFJLE1BQU0sRUFBRSxLQUFLLE1BQU0sRUFBRSxHQUNyQixPQUFPLE1BQU0sRUFBRSxJQUFJO0NBQ3ZCLElBQUksTUFBTSxFQUFFLEtBQUssTUFBTSxFQUFFLEdBQ3JCLE9BQU8sTUFBTSxFQUFFLElBQUk7QUFFM0I7QUFDQSxJQUFNLGNBQWMsUUFBUTtDQUN4QixNQUFNLElBQUk7Q0FDVixJQUFJLENBQUMsTUFBTSxHQUFHLEdBQ1YsT0FBTyxJQUFJLENBQUM7Q0FDaEIsTUFBTSxLQUFLLElBQUk7Q0FDZixNQUFNLEtBQUssS0FBSztDQUNoQixJQUFJLEtBQUssR0FDTCxPQUFPLElBQUksQ0FBQztDQUNoQixNQUFNLFFBQVEsSUFBSSxFQUFFO0NBQ3BCLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssSUFBSSxNQUFNLE1BQU0sR0FBRztFQUU3QyxNQUFNLEtBQUssSUFBSSxJQUFJLFdBQVcsRUFBRSxDQUFDO0VBQ2pDLE1BQU0sS0FBSyxJQUFJLElBQUksV0FBVyxLQUFLLENBQUMsQ0FBQztFQUNyQyxJQUFJLE9BQU8sS0FBQSxLQUFhLE9BQU8sS0FBQSxHQUMzQixPQUFPLElBQUksQ0FBQztFQUNoQixNQUFNLE1BQU0sS0FBSyxLQUFLO0NBQzFCO0NBQ0EsT0FBTztBQUNYOztBQUVBLElBQU0sUUFBUSxHQUFHLFFBQVFBLFNBQU8sTUFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksS0FBS0EsU0FBTyxDQUFDLENBQUMsR0FBRyxHQUFHO0FBQy9FLElBQU0sV0FBVyxZQUFZO0FBQzdCLElBQU0sZUFBZSxHQUFHLENBQUMsRUFBRSxVQUFVLElBQUksK0JBQStCO0FBRXhFLElBQU0sZUFBZSxHQUFHLFNBQVM7Q0FDN0IsTUFBTSxJQUFJLElBQUksS0FBSyxRQUFRLEtBQUssTUFBTSxNQUFNQSxTQUFPLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0NBQ2hFLElBQUksTUFBTTtDQUNWLEtBQUssU0FBUSxNQUFLO0VBQUUsRUFBRSxJQUFJLEdBQUcsR0FBRztFQUFHLE9BQU8sRUFBRTtDQUFRLENBQUM7Q0FDckQsT0FBTztBQUNYOztBQUVBLElBQU0sZUFBZSxNQUFNLE1BQU07Q0FFN0IsT0FEVSxHQUNILENBQUMsQ0FBQyxnQkFBZ0IsSUFBSSxHQUFHLENBQUM7QUFDckM7QUFDQSxJQUFNLE1BQU07QUFDWixJQUFNLFVBQVUsR0FBRyxLQUFLLEtBQUssTUFBTSwrQkFBK0IsTUFBTSxDQUFDLEtBQUssT0FBTyxLQUFLLElBQUksTUFBTSxJQUFJLElBQUksR0FBRzs7QUFFL0csSUFBTSxLQUFLLEdBQUcsSUFBSSxNQUFNO0NBQ3BCLE1BQU0sSUFBSSxJQUFJO0NBQ2QsT0FBTyxLQUFLLEtBQUssSUFBSSxJQUFJO0FBQzdCO0FBQ0EsSUFBTSxRQUFRLE1BQU0sRUFBRSxHQUFHLENBQUM7O0FBRzFCLElBQU0sVUFBVSxLQUFLLE9BQU87Q0FDeEIsSUFBSSxRQUFRLE1BQU0sTUFBTSxJQUNwQixJQUFJLGtCQUFrQixNQUFNLFVBQVUsRUFBRTtDQUM1QyxJQUFJLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSTtDQUN4RCxPQUFPLE1BQU0sSUFBSTtFQUNiLE1BQU0sSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJO0VBQ3pCLE1BQU0sSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksSUFBSTtFQUNqQyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUk7Q0FDM0M7Q0FDQSxPQUFPLE1BQU0sS0FBSyxFQUFFLEdBQUcsRUFBRSxJQUFJLElBQUksWUFBWTtBQUNqRDtBQUNBLElBQU0sWUFBWSxTQUFTO0NBRXZCLE1BQU0sS0FBSyxJQUFJO0NBQ2YsSUFBSSxPQUFPLE9BQU8sWUFDZCxJQUFJLFlBQVksT0FBTyxVQUFVO0NBQ3JDLE9BQU87QUFDWDtBQUNBLElBQU0sVUFBVSxNQUFPLGFBQWEsUUFBUSxJQUFJLElBQUksZ0JBQWdCO0FBR3BFLElBQU0sT0FBTyxNQUFNOztBQUVuQixJQUFNLFFBQU4sTUFBTSxNQUFNO0NBQ1IsT0FBTztDQUNQLE9BQU87Q0FDUDtDQUNBO0NBQ0E7Q0FDQTtDQUNBLFlBQVksSUFBSSxJQUFJLElBQUksSUFBSTtFQUN4QixNQUFNLE1BQU07RUFDWixLQUFLLEtBQUssT0FBTyxJQUFJLElBQUksR0FBRztFQUM1QixLQUFLLEtBQUssT0FBTyxJQUFJLElBQUksR0FBRztFQUM1QixLQUFLLEtBQUssT0FBTyxJQUFJLElBQUksR0FBRztFQUM1QixLQUFLLEtBQUssT0FBTyxJQUFJLElBQUksR0FBRztFQUM1QixPQUFPLE9BQU8sSUFBSTtDQUN0QjtDQUNBLE9BQU8sV0FBVyxHQUFHO0VBQ2pCLE9BQU8sSUFBSSxNQUFNLEVBQUUsR0FBRyxFQUFFLEdBQUcsSUFBSSxFQUFFLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQztDQUMvQzs7Q0FFQSxPQUFPLFVBQVUsS0FBSyxTQUFTLE9BQU87RUFDbEMsTUFBTSxJQUFJO0VBRVYsTUFBTSxTQUFTLEtBQUtBLFNBQU8sS0FBSyxDQUFDLENBQUM7RUFFbEMsTUFBTSxXQUFXLElBQUk7RUFDckIsT0FBTyxNQUFNLFdBQVc7RUFDeEIsTUFBTSxJQUFJLGFBQWEsTUFBTTtFQUk3QixPQUFPLEdBQUcsSUFERSxTQUFTLE9BQU8sQ0FDWDtFQUNqQixNQUFNLEtBQUssRUFBRSxJQUFJLENBQUM7RUFHbEIsSUFBSSxFQUFFLFNBQVMsT0FBTyxNQUFNLFFBRmxCLEVBQUUsS0FBSyxFQUVtQixHQUQxQixFQUFFLElBQUksS0FBSyxFQUNrQixDQUFDO0VBQ3hDLElBQUksQ0FBQyxTQUNELElBQUksdUJBQXVCO0VBQy9CLE1BQU0sVUFBVSxJQUFJLFFBQVE7RUFDNUIsTUFBTSxpQkFBaUIsV0FBVyxTQUFVO0VBQzVDLElBQUksQ0FBQyxVQUFVLE1BQU0sTUFBTSxlQUN2QixJQUFJLGdDQUFnQztFQUN4QyxJQUFJLGtCQUFrQixRQUNsQixJQUFJLEVBQUUsQ0FBQyxDQUFDO0VBQ1osT0FBTyxJQUFJLE1BQU0sR0FBRyxHQUFHLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztDQUN2Qzs7Q0FFQSxpQkFBaUI7RUFDYixNQUFNLElBQUk7RUFDVixNQUFNLElBQUk7RUFDVixNQUFNLElBQUk7RUFDVixJQUFJLEVBQUUsSUFBSSxHQUNOLE1BQU0sSUFBSSxNQUFNLGlCQUFpQjtFQUdyQyxNQUFNLEVBQUUsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxNQUFNO0VBQ3ZDLE1BQU0sS0FBSyxFQUFFLElBQUksQ0FBQztFQUNsQixNQUFNLEtBQUssRUFBRSxJQUFJLENBQUM7RUFDbEIsTUFBTSxLQUFLLEVBQUUsSUFBSSxDQUFDO0VBQ2xCLE1BQU0sS0FBSyxFQUFFLEtBQUssRUFBRTtFQUlwQixJQUZhLEVBQUUsS0FBSyxFQURSLEVBQUUsS0FBSyxDQUNHLElBQU0sRUFBRSxDQUV2QixNQURPLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQyxDQUNwQixHQUNiLE1BQU0sSUFBSSxNQUFNLHVDQUF1QztFQUkzRCxJQUZXLEVBQUUsSUFBSSxDQUVaLE1BRE0sRUFBRSxJQUFJLENBQ0wsR0FDUixNQUFNLElBQUksTUFBTSx1Q0FBdUM7RUFDM0QsT0FBTztDQUNYOztDQUVBLE9BQU8sT0FBTztFQUNWLE1BQU0sRUFBRSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksT0FBTztFQUNuQyxNQUFNLEVBQUUsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLE9BQU8sT0FBTyxLQUFLO0VBQy9DLE1BQU0sT0FBTyxFQUFFLEtBQUssRUFBRTtFQUN0QixNQUFNLE9BQU8sRUFBRSxLQUFLLEVBQUU7RUFDdEIsTUFBTSxPQUFPLEVBQUUsS0FBSyxFQUFFO0VBQ3RCLE1BQU0sT0FBTyxFQUFFLEtBQUssRUFBRTtFQUN0QixPQUFPLFNBQVMsUUFBUSxTQUFTO0NBQ3JDO0NBQ0EsTUFBTTtFQUNGLE9BQU8sS0FBSyxPQUFPLENBQUM7Q0FDeEI7O0NBRUEsU0FBUztFQUNMLE9BQU8sSUFBSSxNQUFNLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxLQUFLLElBQUksS0FBSyxJQUFJLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQztDQUMvRDs7Q0FFQSxTQUFTO0VBQ0wsTUFBTSxFQUFFLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxPQUFPO0VBQ25DLE1BQU0sSUFBSTtFQUVWLE1BQU0sSUFBSSxFQUFFLEtBQUssRUFBRTtFQUNuQixNQUFNLElBQUksRUFBRSxLQUFLLEVBQUU7RUFDbkIsTUFBTSxJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxDQUFDO0VBQzNCLE1BQU0sSUFBSSxFQUFFLElBQUksQ0FBQztFQUNqQixNQUFNLE9BQU8sS0FBSztFQUNsQixNQUFNLElBQUksRUFBRSxFQUFFLE9BQU8sSUFBSSxJQUFJLElBQUksQ0FBQztFQUNsQyxNQUFNLElBQUksSUFBSTtFQUNkLE1BQU0sSUFBSSxJQUFJO0VBQ2QsTUFBTSxJQUFJLElBQUk7RUFDZCxNQUFNLEtBQUssRUFBRSxJQUFJLENBQUM7RUFDbEIsTUFBTSxLQUFLLEVBQUUsSUFBSSxDQUFDO0VBQ2xCLE1BQU0sS0FBSyxFQUFFLElBQUksQ0FBQztFQUNsQixNQUFNLEtBQUssRUFBRSxJQUFJLENBQUM7RUFDbEIsT0FBTyxJQUFJLE1BQU0sSUFBSSxJQUFJLElBQUksRUFBRTtDQUNuQzs7Q0FFQSxJQUFJLE9BQU87RUFDUCxNQUFNLEVBQUUsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxPQUFPO0VBQzNDLE1BQU0sRUFBRSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLE9BQU8sT0FBTyxLQUFLO0VBQ3ZELE1BQU0sSUFBSTtFQUNWLE1BQU0sSUFBSTtFQUVWLE1BQU0sSUFBSSxFQUFFLEtBQUssRUFBRTtFQUNuQixNQUFNLElBQUksRUFBRSxLQUFLLEVBQUU7RUFDbkIsTUFBTSxJQUFJLEVBQUUsS0FBSyxJQUFJLEVBQUU7RUFDdkIsTUFBTSxJQUFJLEVBQUUsS0FBSyxFQUFFO0VBQ25CLE1BQU0sSUFBSSxHQUFHLEtBQUssT0FBTyxLQUFLLE1BQU0sSUFBSSxDQUFDO0VBQ3pDLE1BQU0sSUFBSSxFQUFFLElBQUksQ0FBQztFQUNqQixNQUFNLElBQUksRUFBRSxJQUFJLENBQUM7RUFDakIsTUFBTSxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUM7RUFDckIsTUFBTSxLQUFLLEVBQUUsSUFBSSxDQUFDO0VBQ2xCLE1BQU0sS0FBSyxFQUFFLElBQUksQ0FBQztFQUNsQixNQUFNLEtBQUssRUFBRSxJQUFJLENBQUM7RUFDbEIsTUFBTSxLQUFLLEVBQUUsSUFBSSxDQUFDO0VBQ2xCLE9BQU8sSUFBSSxNQUFNLElBQUksSUFBSSxJQUFJLEVBQUU7Q0FDbkM7Ozs7Ozs7O0NBUUEsU0FBUyxHQUFHLE9BQU8sTUFBTTtFQUNyQixJQUFJLENBQUMsU0FBUyxNQUFNLE1BQU0sS0FBSyxJQUFJLElBQy9CLE9BQU87RUFDWCxPQUFPLEdBQUcsSUFBSSxDQUFDO0VBQ2YsSUFBSSxNQUFNLElBQ04sT0FBTztFQUNYLElBQUksS0FBSyxPQUFPLENBQUMsR0FDYixPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUM7RUFFbkIsSUFBSSxJQUFJO0VBQ1IsSUFBSSxJQUFJO0VBQ1IsS0FBSyxJQUFJLElBQUksTUFBTSxJQUFJLElBQUksSUFBSSxFQUFFLE9BQU8sR0FBRyxNQUFNLElBRzdDLElBQUksSUFBSSxJQUNKLElBQUksRUFBRSxJQUFJLENBQUM7T0FDVixJQUFJLE1BQ0wsSUFBSSxFQUFFLElBQUksQ0FBQztFQUVuQixPQUFPO0NBQ1g7O0NBRUEsV0FBVztFQUNQLE1BQU0sRUFBRSxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksTUFBTTtFQUVoQyxJQUFJLEtBQUssT0FBTyxDQUFDLEdBQ2IsT0FBTztHQUFFLEdBQUc7R0FBSSxHQUFHO0VBQUc7RUFDMUIsTUFBTSxLQUFLLE9BQU8sR0FBRyxDQUFDO0VBRXRCLElBQUksRUFBRSxJQUFJLEVBQUUsTUFBTSxJQUNkLElBQUksaUJBQWlCO0VBRXpCLE9BQU87R0FBRSxHQUFHLEVBQUUsSUFBSSxFQUFFO0dBQUcsR0FBRyxFQUFFLElBQUksRUFBRTtFQUFFO0NBQ3hDO0NBQ0EsVUFBVTtFQUNOLE1BQU0sRUFBRSxHQUFHLE1BQU0sS0FBSyxlQUFlLENBQUMsQ0FBQyxTQUFTO0VBQ2hELE1BQU0sSUFBSSxXQUFXLENBQUM7RUFFdEIsRUFBRSxPQUFPLElBQUksS0FBSyxNQUFPO0VBQ3pCLE9BQU87Q0FDWDtDQUNBLFFBQVE7RUFDSixPQUFPLFdBQVcsS0FBSyxRQUFRLENBQUM7Q0FDcEM7Q0FDQSxnQkFBZ0I7RUFDWixPQUFPLEtBQUssU0FBUyxJQUFJRixHQUFDLEdBQUcsS0FBSztDQUN0QztDQUNBLGVBQWU7RUFDWCxPQUFPLEtBQUssY0FBYyxDQUFDLENBQUMsSUFBSTtDQUNwQztDQUNBLGdCQUFnQjtFQUVaLElBQUksSUFBSSxLQUFLLFNBQVMsSUFBSSxJQUFJLEtBQUssQ0FBQyxDQUFDLE9BQU87RUFDNUMsSUFBSSxJQUFJLElBQ0osSUFBSSxFQUFFLElBQUksSUFBSTtFQUNsQixPQUFPLEVBQUUsSUFBSTtDQUNqQjtDQUNBLE9BQU8sUUFBUSxLQUFLLFFBQVE7RUFDeEIsT0FBTyxNQUFNLFVBQVUsS0FBSyxHQUFHLEdBQUcsTUFBTTtDQUM1QztDQUNBLElBQUksSUFBSTtFQUNKLE9BQU8sS0FBSyxTQUFTLENBQUMsQ0FBQztDQUMzQjtDQUNBLElBQUksSUFBSTtFQUNKLE9BQU8sS0FBSyxTQUFTLENBQUMsQ0FBQztDQUMzQjtDQUNBLGFBQWE7RUFDVCxPQUFPLEtBQUssUUFBUTtDQUN4QjtBQUNKOztBQUVBLElBQU0sSUFBSSxJQUFJLE1BQU0sSUFBSSxJQUFJLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQzs7QUFFMUMsSUFBTSxJQUFJLElBQUksTUFBTSxJQUFJLElBQUksSUFBSSxFQUFFO0FBRWxDLE1BQU0sT0FBTztBQUNiLE1BQU0sT0FBTztBQUNiLElBQU0sY0FBYyxRQUFRLFdBQVcsS0FBSyxPQUFPLEtBQUssSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2hGLElBQU0sZ0JBQWdCLE1BQU0sSUFBSSxPQUFPLFdBQVcsS0FBS0UsU0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVFLElBQU0sUUFBUSxHQUFHLFVBQVU7Q0FFdkIsSUFBSSxJQUFJO0NBQ1IsT0FBTyxVQUFVLElBQUk7RUFDakIsS0FBSztFQUNMLEtBQUs7Q0FDVDtDQUNBLE9BQU87QUFDWDtBQUVBLElBQU0sZUFBZSxNQUFNO0NBRXZCLE1BQU0sS0FETSxJQUFJLElBQUssSUFDSixJQUFLO0NBRXRCLE1BQU0sS0FBTSxLQURBLEtBQUssSUFBSSxFQUFFLElBQUksS0FBTSxHQUNaLEVBQUUsSUFBSSxJQUFLO0NBQ2hDLE1BQU0sTUFBTyxLQUFLLElBQUksRUFBRSxJQUFJLEtBQU07Q0FDbEMsTUFBTSxNQUFPLEtBQUssS0FBSyxHQUFHLElBQUksTUFBTztDQUNyQyxNQUFNLE1BQU8sS0FBSyxLQUFLLEdBQUcsSUFBSSxNQUFPO0NBQ3JDLE1BQU0sTUFBTyxLQUFLLEtBQUssR0FBRyxJQUFJLE1BQU87Q0FLckMsT0FBTztFQUFFLFdBRFUsS0FETCxLQURBLEtBREEsS0FBSyxLQUFLLEdBQUcsSUFBSSxNQUFPLEdBQ2IsR0FBRyxJQUFJLE1BQU8sR0FDZCxHQUFHLElBQUksTUFBTyxHQUNULEVBQUUsSUFBSSxJQUFLO0VBQ3JCO0NBQUc7QUFDM0I7QUFDQSxJQUFNLE1BQU07QUFHWixJQUFNLFdBQVcsR0FBRyxNQUFNO0NBQ3RCLE1BQU0sS0FBSyxFQUFFLElBQUksSUFBSSxDQUFDO0NBRXRCLE1BQU0sTUFBTSxZQUFZLElBRGIsRUFBRSxLQUFLLEtBQUssQ0FDSyxDQUFFLENBQUMsQ0FBQztDQUNoQyxJQUFJLElBQUksRUFBRSxJQUFJLEtBQUssR0FBRztDQUN0QixNQUFNLE1BQU0sRUFBRSxJQUFJLElBQUksQ0FBQztDQUN2QixNQUFNLFFBQVE7Q0FDZCxNQUFNLFFBQVEsRUFBRSxJQUFJLEdBQUc7Q0FDdkIsTUFBTSxXQUFXLFFBQVE7Q0FDekIsTUFBTSxXQUFXLFFBQVEsRUFBRSxDQUFDLENBQUM7Q0FDN0IsTUFBTSxTQUFTLFFBQVEsRUFBRSxDQUFDLElBQUksR0FBRztDQUNqQyxJQUFJLFVBQ0EsSUFBSTtDQUNSLElBQUksWUFBWSxRQUNaLElBQUk7Q0FDUixLQUFLLEVBQUUsQ0FBQyxJQUFJLFFBQVEsSUFDaEIsSUFBSSxFQUFFLENBQUMsQ0FBQztDQUNaLE9BQU87RUFBRSxTQUFTLFlBQVk7RUFBVSxPQUFPO0NBQUU7QUFDckQ7QUFFQSxJQUFNLFdBQVcsU0FBUyxLQUFLLGFBQWEsSUFBSSxDQUFDO0FBRWpELElBQU0sV0FBVyxHQUFHLE1BQU0sU0FBUyxZQUFZLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFzQnJELElBQU0sZUFBZSxRQUFRLElBQUksT0FBTyxRQUFRLElBQUksUUFBUSxDQUFDO0FBa0M3RCxJQUFNLFdBQVcsRUFBRSxRQUFRLEtBQUs7QUFDaEMsSUFBTSxXQUFXLEtBQUssS0FBSyxLQUFLLE9BQU8sYUFBYTtDQUNoRCxNQUFNLEtBQUssS0FBSyxFQUFFO0NBQ2xCLE1BQU0sS0FBSyxHQUFHO0NBQ2QsTUFBTSxLQUFLLEtBQUssQ0FBQztDQUNqQixNQUFNLEVBQUUsV0FBVztDQUNuQixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSSxXQUFXLFdBQVcsR0FBRztDQUM3QixJQUFJO0VBQ0EsSUFBSSxNQUFNLFFBQVEsS0FBSyxNQUFNO0VBQzdCLElBQUksTUFBTSxRQUFRLElBQUksTUFBTSxHQUFHLENBQUMsR0FBRyxNQUFNO0VBQ3pDLElBQUksYUFBYSxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7RUFDakMsS0FBSyxFQUFFLFNBQVMsR0FBRyxLQUFLO0VBQ3hCLFdBQVcsWUFBWSxFQUFFLFFBQVEsR0FBRyxFQUFFLFFBQVEsR0FBRyxHQUFHO0NBQ3hELFNBQ08sT0FBTyxDQUFFO0NBQ2hCLE1BQU0sVUFBVSxXQUFXO0VBRXZCLElBQUksTUFBTSxNQUNOLE9BQU87RUFDWCxJQUFJLENBQUMsVUFBVSxFQUFFLGFBQWEsR0FDMUIsT0FBTztFQUNYLE1BQU0sSUFBSSxRQUFRLE1BQU07RUFFeEIsT0FEWSxFQUFFLElBQUksRUFBRSxTQUFTLEdBQUcsS0FBSyxDQUM1QixDQUFDLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSTtDQUNwRDtDQUNBLE9BQU87RUFBRTtFQUFVO0NBQU87QUFDOUI7O0FBSUEsSUFBTSxVQUFVLEdBQUcsR0FBRyxHQUFHLE9BQU8sYUFBYSxZQUFZLFFBQVEsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDOztBQUUvRSxJQUFNLE1BQU07Q0FDUixhQUFhLE9BQU8sR0FBRyxhQUFhO0VBQ2hDLE1BQU0sSUFBSSxPQUFPO0VBQ2pCLE1BQU0sSUFBSSxZQUFZLEdBQUcsUUFBUTtFQUNqQyxPQUFPLElBQUksTUFBTSxFQUFFLE9BQU8sV0FBVyxFQUFFLE1BQU0sQ0FBQztDQUNsRDtDQUNBLFlBQVksS0FBQTtDQUNBO0NBQ0E7Q0FDQztDQUNiLEtBQUs7Q0FDRztDQUNLO0FBQ2pCO0FBY0EsSUFBTSxJQUFJO0FBRVYsSUFBTSxXQUFXLEtBQUssS0FBSyxNQUFhLENBQUMsSUFBSTtBQUM3QyxJQUFNLGNBQWMsS0FBTTtBQUMxQixJQUFNLG1CQUFtQjtDQUNyQixNQUFNLFNBQVMsQ0FBQztDQUNoQixJQUFJLElBQUk7Q0FDUixJQUFJLElBQUk7Q0FDUixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxLQUFLO0VBQy9CLElBQUk7RUFDSixPQUFPLEtBQUssQ0FBQztFQUNiLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxhQUFhLEtBQUs7R0FDbEMsSUFBSSxFQUFFLElBQUksQ0FBQztHQUNYLE9BQU8sS0FBSyxDQUFDO0VBQ2pCO0VBQ0EsSUFBSSxFQUFFLE9BQU87Q0FDakI7Q0FDQSxPQUFPO0FBQ1g7QUFDQSxJQUFJLFFBQVEsS0FBQTtBQUVaLElBQU0sU0FBUyxLQUFLLE1BQU07Q0FDdEIsTUFBTSxJQUFJLEVBQUUsT0FBTztDQUNuQixPQUFPLE1BQU0sSUFBSTtBQUNyQjs7Ozs7Ozs7Ozs7O0FBWUEsSUFBTSxRQUFRLE1BQU07Q0FDaEIsTUFBTSxPQUFPLFVBQVUsUUFBUSxXQUFXO0NBQzFDLElBQUksSUFBSTtDQUNSLElBQUksSUFBSTtDQUVSLE1BQU0sU0FEVSxLQUFLO0NBRXJCLE1BQU0sT0FBTyxJQUFJLEdBQVc7Q0FDNUIsTUFBTSxVQUFVLElBQUksQ0FBQztDQUNyQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxLQUFLO0VBQy9CLElBQUksUUFBUSxPQUFPLElBQUksSUFBSTtFQUMzQixNQUFNO0VBQ04sSUFBSSxRQUFRLGFBQWE7R0FDckIsU0FBUztHQUNULEtBQUs7RUFDVDtFQUNBLE1BQU0sTUFBTSxJQUFJO0VBQ2hCLE1BQU0sT0FBTztFQUNiLE1BQU0sT0FBTyxNQUFNLEtBQUssSUFBSSxLQUFLLElBQUk7RUFDckMsTUFBTSxTQUFTLElBQUksTUFBTTtFQUN6QixNQUFNLFFBQVEsUUFBUTtFQUN0QixJQUFJLFVBQVUsR0FFVixJQUFJLEVBQUUsSUFBSSxNQUFNLFFBQVEsS0FBSyxLQUFLLENBQUM7T0FHbkMsSUFBSSxFQUFFLElBQUksTUFBTSxPQUFPLEtBQUssS0FBSyxDQUFDO0NBRTFDO0NBQ0EsT0FBTztFQUFFO0VBQUc7Q0FBRTtBQUNsQjs7Ozs7Ozs7Ozs7OztBQ2prQkEsU0FBZ0IsUUFBUSxHQUFHO0NBS3ZCLE9BQVEsYUFBYSxjQUNoQixZQUFZLE9BQU8sQ0FBQyxLQUNqQixFQUFFLFlBQVksU0FBUyxnQkFDdkIsdUJBQXVCLEtBQ3ZCLEVBQUUsc0JBQXNCO0FBQ3BDOzs7Ozs7Ozs7Ozs7Ozs7QUFxQ0EsU0FBZ0IsT0FBTyxPQUFPLFFBQVEsUUFBUSxJQUFJO0NBQzlDLE1BQU0sUUFBUSxRQUFRLEtBQUs7Q0FDM0IsTUFBTSxNQUFNLE9BQU87Q0FDbkIsTUFBTSxXQUFXLFdBQVcsS0FBQTtDQUM1QixJQUFJLENBQUMsU0FBVSxZQUFZLFFBQVEsUUFBUztFQUN4QyxNQUFNLFNBQVMsU0FBUyxJQUFJLE1BQU07RUFDbEMsTUFBTSxRQUFRLFdBQVcsY0FBYyxXQUFXO0VBQ2xELE1BQU0sTUFBTSxRQUFRLFVBQVUsUUFBUSxRQUFRLE9BQU87RUFDckQsTUFBTSxVQUFVLFNBQVMsd0JBQXdCLFFBQVEsV0FBVztFQUNwRSxJQUFJLENBQUMsT0FDRCxNQUFNLElBQUksVUFBVSxPQUFPO0VBQy9CLE1BQU0sSUFBSSxXQUFXLE9BQU87Q0FDaEM7Q0FDQSxPQUFPO0FBQ1g7Ozs7Ozs7Ozs7Ozs7OztBQTBEQSxTQUFnQixRQUFRLFVBQVUsZ0JBQWdCLE1BQU07Q0FDcEQsSUFBSSxTQUFTLFdBQ1QsTUFBTSxJQUFJLE1BQU0sa0NBQWtDO0NBQ3RELElBQUksaUJBQWlCLFNBQVMsVUFDMUIsTUFBTSxJQUFJLE1BQU0sdUNBQXVDO0FBQy9EOzs7Ozs7Ozs7Ozs7Ozs7OztBQWlCQSxTQUFnQixRQUFRLEtBQUssVUFBVTtDQUNuQyxPQUFPLEtBQUssS0FBQSxHQUFXLHFCQUFxQjtDQUM1QyxNQUFNLE1BQU0sU0FBUztDQUNyQixJQUFJLElBQUksU0FBUyxLQUNiLE1BQU0sSUFBSSxXQUFXLHdEQUFzRCxHQUFHO0FBRXRGOzs7Ozs7Ozs7O0FBc0NBLFNBQWdCLE1BQU0sR0FBRyxRQUFRO0NBQzdCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsS0FDL0IsT0FBTyxFQUFFLENBQUMsS0FBSyxDQUFDO0FBRXhCOzs7Ozs7Ozs7OztBQVdBLFNBQWdCLFdBQVcsS0FBSztDQUM1QixPQUFPLElBQUksU0FBUyxJQUFJLFFBQVEsSUFBSSxZQUFZLElBQUksVUFBVTtBQUNsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBaVRBLFNBQWdCLGFBQWEsVUFBVSxPQUFPLENBQUMsR0FBRztDQUM5QyxNQUFNLFNBQVMsS0FBSyxTQUFTLFNBQVMsSUFBSSxDQUFDLENBQ3RDLE9BQU8sR0FBRyxDQUFDLENBQ1gsT0FBTztDQUNaLE1BQU0sTUFBTSxTQUFTLEtBQUEsQ0FBUztDQUM5QixNQUFNLFlBQVksSUFBSTtDQUN0QixNQUFNLFdBQVcsSUFBSTtDQUNyQixNQUFNLFNBQVMsSUFBSTtDQUNuQixNQUFNLFVBQVUsU0FBUyxTQUFTLElBQUk7Q0FDdEMsT0FBTyxPQUFPLE9BQU8sSUFBSTtDQUN6QixPQUFPLE9BQU8sT0FBTyxLQUFLO0FBQzlCOzs7Ozs7Ozs7Ozs7O0FBNENBLElBQWEsV0FBVyxZQUFZLEVBR2hDLEtBQUssV0FBVyxLQUFLO0NBQUM7Q0FBTTtDQUFNO0NBQU07Q0FBTTtDQUFNO0NBQU07Q0FBTTtDQUFNO0NBQU07Q0FBTTtBQUFNLENBQUMsRUFDN0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2Z0JBLElBQWEsU0FBYixNQUFvQjtDQUNoQjtDQUNBO0NBQ0EsU0FBUztDQUNUO0NBQ0E7Q0FFQTtDQUNBO0NBQ0EsV0FBVztDQUNYLFNBQVM7Q0FDVCxNQUFNO0NBQ04sWUFBWTtDQUNaLFlBQVksVUFBVSxXQUFXLFdBQVcsTUFBTTtFQUM5QyxLQUFLLFdBQVc7RUFDaEIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssWUFBWTtFQUNqQixLQUFLLE9BQU87RUFDWixLQUFLLFNBQVMsSUFBSSxXQUFXLFFBQVE7RUFDckMsS0FBSyxPQUFPLFdBQVcsS0FBSyxNQUFNO0NBQ3RDO0NBQ0EsT0FBTyxNQUFNO0VBQ1QsUUFBUSxJQUFJO0VBQ1osT0FBTyxJQUFJO0VBQ1gsTUFBTSxFQUFFLE1BQU0sUUFBUSxhQUFhO0VBQ25DLE1BQU0sTUFBTSxLQUFLO0VBQ2pCLEtBQUssSUFBSSxNQUFNLEdBQUcsTUFBTSxNQUFNO0dBQzFCLE1BQU0sT0FBTyxLQUFLLElBQUksV0FBVyxLQUFLLEtBQUssTUFBTSxHQUFHO0dBR3BELElBQUksU0FBUyxVQUFVO0lBQ25CLE1BQU0sV0FBVyxXQUFXLElBQUk7SUFDaEMsT0FBTyxZQUFZLE1BQU0sS0FBSyxPQUFPLFVBQ2pDLEtBQUssUUFBUSxVQUFVLEdBQUc7SUFDOUI7R0FDSjtHQUNBLE9BQU8sSUFBSSxLQUFLLFNBQVMsS0FBSyxNQUFNLElBQUksR0FBRyxLQUFLLEdBQUc7R0FDbkQsS0FBSyxPQUFPO0dBQ1osT0FBTztHQUNQLElBQUksS0FBSyxRQUFRLFVBQVU7SUFDdkIsS0FBSyxRQUFRLE1BQU0sQ0FBQztJQUNwQixLQUFLLE1BQU07R0FDZjtFQUNKO0VBQ0EsS0FBSyxVQUFVLEtBQUs7RUFDcEIsS0FBSyxXQUFXO0VBQ2hCLE9BQU87Q0FDWDtDQUNBLFdBQVcsS0FBSztFQUNaLFFBQVEsSUFBSTtFQUNaLFFBQVEsS0FBSyxJQUFJO0VBQ2pCLEtBQUssV0FBVztFQUloQixNQUFNLEVBQUUsUUFBUSxNQUFNLFVBQVUsU0FBUztFQUN6QyxJQUFJLEVBQUUsUUFBUTtFQUVkLE9BQU8sU0FBUztFQUNoQixNQUFNLEtBQUssT0FBTyxTQUFTLEdBQUcsQ0FBQztFQUcvQixJQUFJLEtBQUssWUFBWSxXQUFXLEtBQUs7R0FDakMsS0FBSyxRQUFRLE1BQU0sQ0FBQztHQUNwQixNQUFNO0VBQ1Y7RUFFQSxLQUFLLElBQUksSUFBSSxLQUFLLElBQUksVUFBVSxLQUM1QixPQUFPLEtBQUs7RUFJaEIsS0FBSyxhQUFhLFdBQVcsR0FBRyxPQUFPLEtBQUssU0FBUyxDQUFDLEdBQUcsSUFBSTtFQUM3RCxLQUFLLFFBQVEsTUFBTSxDQUFDO0VBQ3BCLE1BQU0sUUFBUSxXQUFXLEdBQUc7RUFDNUIsTUFBTSxNQUFNLEtBQUs7RUFFakIsSUFBSSxNQUFNLEdBQ04sTUFBTSxJQUFJLE1BQU0sMkNBQTJDO0VBQy9ELE1BQU0sU0FBUyxNQUFNO0VBQ3JCLE1BQU0sUUFBUSxLQUFLLElBQUk7RUFDdkIsSUFBSSxTQUFTLE1BQU0sUUFDZixNQUFNLElBQUksTUFBTSxvQ0FBb0M7RUFDeEQsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FDeEIsTUFBTSxVQUFVLElBQUksR0FBRyxNQUFNLElBQUksSUFBSTtDQUM3QztDQUNBLFNBQVM7RUFDTCxNQUFNLEVBQUUsUUFBUSxjQUFjO0VBQzlCLEtBQUssV0FBVyxNQUFNO0VBR3RCLE1BQU0sTUFBTSxPQUFPLE1BQU0sR0FBRyxTQUFTO0VBQ3JDLEtBQUssUUFBUTtFQUNiLE9BQU87Q0FDWDtDQUNBLFdBQVcsSUFBSTtFQUNYLE9BQU8sSUFBSSxLQUFLLFlBQVk7RUFDNUIsR0FBRyxJQUFJLEdBQUcsS0FBSyxJQUFJLENBQUM7RUFDcEIsTUFBTSxFQUFFLFVBQVUsUUFBUSxRQUFRLFVBQVUsV0FBVyxRQUFRO0VBQy9ELEdBQUcsWUFBWTtFQUNmLEdBQUcsV0FBVztFQUNkLEdBQUcsU0FBUztFQUNaLEdBQUcsTUFBTTtFQUdULElBQUksU0FBUyxVQUNULEdBQUcsT0FBTyxJQUFJLE1BQU07RUFDeEIsT0FBTztDQUNYO0NBQ0EsUUFBUTtFQUNKLE9BQU8sS0FBSyxXQUFXO0NBQzNCO0FBQ0o7Ozs7O0FBNEJBLElBQWEsWUFBNEIsNEJBQVksS0FBSztDQUN0RDtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQ3BGO0NBQVk7Q0FBWTtDQUFZO0NBQVk7Q0FBWTtDQUFZO0NBQVk7QUFDeEYsQ0FBQzs7O0FDeE1ELElBQU0sYUFBNkIsdUJBQU8sS0FBSyxLQUFLLENBQUM7QUFDckQsSUFBTSxPQUF1Qix1QkFBTyxFQUFFO0FBR3RDLFNBQVMsUUFBUSxHQUFHLEtBQUssT0FBTztDQUM1QixJQUFJLElBQ0EsT0FBTztFQUFFLEdBQUcsT0FBTyxJQUFJLFVBQVU7RUFBRyxHQUFHLE9BQVEsS0FBSyxPQUFRLFVBQVU7Q0FBRTtDQUM1RSxPQUFPO0VBQUUsR0FBRyxPQUFRLEtBQUssT0FBUSxVQUFVLElBQUk7RUFBRyxHQUFHLE9BQU8sSUFBSSxVQUFVLElBQUk7Q0FBRTtBQUNwRjtBQUdBLFNBQVMsTUFBTSxLQUFLLEtBQUssT0FBTztDQUM1QixNQUFNLE1BQU0sSUFBSTtDQUNoQixJQUFJLEtBQUssSUFBSSxZQUFZLEdBQUc7Q0FDNUIsSUFBSSxLQUFLLElBQUksWUFBWSxHQUFHO0NBQzVCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUs7RUFDMUIsTUFBTSxFQUFFLEdBQUcsTUFBTSxRQUFRLElBQUksSUFBSSxFQUFFO0VBQ25DLENBQUMsR0FBRyxJQUFJLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQztDQUMxQjtDQUNBLE9BQU8sQ0FBQyxJQUFJLEVBQUU7QUFDbEI7QUFLQSxJQUFNLFNBQVMsR0FBRyxJQUFJLE1BQU0sTUFBTTtBQUVsQyxJQUFNLFNBQVMsR0FBRyxHQUFHLE1BQU8sS0FBTSxLQUFLLElBQU8sTUFBTTtBQUVwRCxJQUFNLFVBQVUsR0FBRyxHQUFHLE1BQU8sTUFBTSxJQUFNLEtBQU0sS0FBSztBQUVwRCxJQUFNLFVBQVUsR0FBRyxHQUFHLE1BQU8sS0FBTSxLQUFLLElBQU8sTUFBTTtBQUVyRCxJQUFNLFVBQVUsR0FBRyxHQUFHLE1BQU8sS0FBTSxLQUFLLElBQU8sTUFBTyxJQUFJO0FBRTFELElBQU0sVUFBVSxHQUFHLEdBQUcsTUFBTyxNQUFPLElBQUksS0FBUSxLQUFNLEtBQUs7QUFnQjNELFNBQVMsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJO0NBQ3pCLE1BQU0sS0FBSyxPQUFPLE1BQU0sT0FBTztDQUMvQixPQUFPO0VBQUUsR0FBSSxLQUFLLE1BQU8sSUFBSSxLQUFLLEtBQU0sS0FBTTtFQUFHLEdBQUcsSUFBSTtDQUFFO0FBQzlEO0FBR0EsSUFBTSxTQUFTLElBQUksSUFBSSxRQUFRLE9BQU8sTUFBTSxPQUFPLE1BQU0sT0FBTztBQUVoRSxJQUFNLFNBQVMsS0FBSyxJQUFJLElBQUksT0FBUSxLQUFLLEtBQUssTUFBTyxNQUFNLEtBQUssS0FBTSxLQUFNO0FBRTVFLElBQU0sU0FBUyxJQUFJLElBQUksSUFBSSxRQUFRLE9BQU8sTUFBTSxPQUFPLE1BQU0sT0FBTyxNQUFNLE9BQU87QUFFakYsSUFBTSxTQUFTLEtBQUssSUFBSSxJQUFJLElBQUksT0FBUSxLQUFLLEtBQUssS0FBSyxNQUFPLE1BQU0sS0FBSyxLQUFNLEtBQU07QUFFckYsSUFBTSxTQUFTLElBQUksSUFBSSxJQUFJLElBQUksUUFBUSxPQUFPLE1BQU0sT0FBTyxNQUFNLE9BQU8sTUFBTSxPQUFPLE1BQU0sT0FBTztBQUVsRyxJQUFNLFNBQVMsS0FBSyxJQUFJLElBQUksSUFBSSxJQUFJLE9BQVEsS0FBSyxLQUFLLEtBQUssS0FBSyxNQUFPLE1BQU0sS0FBSyxLQUFNLEtBQU07Ozs7Ozs7Ozs7QUMrRDlGLElBQU0sT0FBdUIsdUJBQU9DLE1BQVU7Q0FDMUM7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7Q0FDbEU7Q0FBc0I7Q0FBc0I7Q0FBc0I7QUFDdEUsQ0FBQyxDQUFDLEtBQUksTUFBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUEsQ0FBRztBQUN4QixJQUFNLFlBQTRCLHVCQUFPLEtBQUssR0FBQSxDQUFJO0FBQ2xELElBQU0sWUFBNEIsdUJBQU8sS0FBSyxHQUFBLENBQUk7QUFFbEQsSUFBTSw2QkFBNkIsSUFBSSxZQUFZLEVBQUU7QUFFckQsSUFBTSw2QkFBNkIsSUFBSSxZQUFZLEVBQUU7O0FBRXJELElBQU0sV0FBTixjQUF1QixPQUFPO0NBQzFCLFlBQVksV0FBVztFQUNuQixNQUFNLEtBQUssV0FBVyxJQUFJLEtBQUs7Q0FDbkM7Q0FFQSxNQUFNO0VBQ0YsTUFBTSxFQUFFLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLE9BQU87RUFDM0UsT0FBTztHQUFDO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0dBQUk7R0FBSTtHQUFJO0VBQUU7Q0FDMUU7Q0FFQSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUk7RUFDaEUsS0FBSyxLQUFLLEtBQUs7RUFDZixLQUFLLEtBQUssS0FBSztFQUNmLEtBQUssS0FBSyxLQUFLO0VBQ2YsS0FBSyxLQUFLLEtBQUs7RUFDZixLQUFLLEtBQUssS0FBSztFQUNmLEtBQUssS0FBSyxLQUFLO0VBQ2YsS0FBSyxLQUFLLEtBQUs7RUFDZixLQUFLLEtBQUssS0FBSztFQUNmLEtBQUssS0FBSyxLQUFLO0VBQ2YsS0FBSyxLQUFLLEtBQUs7RUFDZixLQUFLLEtBQUssS0FBSztFQUNmLEtBQUssS0FBSyxLQUFLO0VBQ2YsS0FBSyxLQUFLLEtBQUs7RUFDZixLQUFLLEtBQUssS0FBSztFQUNmLEtBQUssS0FBSyxLQUFLO0VBQ2YsS0FBSyxLQUFLLEtBQUs7Q0FDbkI7Q0FDQSxRQUFRLE1BQU0sUUFBUTtFQUVsQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLLFVBQVUsR0FBRztHQUN0QyxXQUFXLEtBQUssS0FBSyxVQUFVLE1BQU07R0FDckMsV0FBVyxLQUFLLEtBQUssVUFBVyxVQUFVLENBQUU7RUFDaEQ7RUFDQSxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxLQUFLO0dBRTFCLE1BQU0sT0FBTyxXQUFXLElBQUksTUFBTTtHQUNsQyxNQUFNLE9BQU8sV0FBVyxJQUFJLE1BQU07R0FDbEMsTUFBTSxNQUFNQyxPQUFXLE1BQU0sTUFBTSxDQUFDLElBQUlBLE9BQVcsTUFBTSxNQUFNLENBQUMsSUFBSUMsTUFBVSxNQUFNLE1BQU0sQ0FBQztHQUMzRixNQUFNLE1BQU1DLE9BQVcsTUFBTSxNQUFNLENBQUMsSUFBSUEsT0FBVyxNQUFNLE1BQU0sQ0FBQyxJQUFJQyxNQUFVLE1BQU0sTUFBTSxDQUFDO0dBRTNGLE1BQU0sTUFBTSxXQUFXLElBQUksS0FBSztHQUNoQyxNQUFNLE1BQU0sV0FBVyxJQUFJLEtBQUs7R0FDaEMsTUFBTSxNQUFNSCxPQUFXLEtBQUssS0FBSyxFQUFFLElBQUlJLE9BQVcsS0FBSyxLQUFLLEVBQUUsSUFBSUgsTUFBVSxLQUFLLEtBQUssQ0FBQztHQUd2RixNQUFNLE9BQU9LLE1BQVUsS0FGWEosT0FBVyxLQUFLLEtBQUssRUFBRSxJQUFJRyxPQUFXLEtBQUssS0FBSyxFQUFFLElBQUlGLE1BQVUsS0FBSyxLQUFLLENBQUMsR0FFdEQsV0FBVyxJQUFJLElBQUksV0FBVyxJQUFJLEdBQUc7R0FDdEUsTUFBTSxPQUFPSSxNQUFVLE1BQU0sS0FBSyxLQUFLLFdBQVcsSUFBSSxJQUFJLFdBQVcsSUFBSSxHQUFHO0dBQzVFLFdBQVcsS0FBSyxPQUFPO0dBQ3ZCLFdBQVcsS0FBSyxPQUFPO0VBQzNCO0VBQ0EsSUFBSSxFQUFFLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLE9BQU87RUFFekUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksS0FBSztHQUV6QixNQUFNLFVBQVVQLE9BQVcsSUFBSSxJQUFJLEVBQUUsSUFBSUEsT0FBVyxJQUFJLElBQUksRUFBRSxJQUFJSSxPQUFXLElBQUksSUFBSSxFQUFFO0dBQ3ZGLE1BQU0sVUFBVUYsT0FBVyxJQUFJLElBQUksRUFBRSxJQUFJQSxPQUFXLElBQUksSUFBSSxFQUFFLElBQUlHLE9BQVcsSUFBSSxJQUFJLEVBQUU7R0FFdkYsTUFBTSxPQUFRLEtBQUssS0FBTyxDQUFDLEtBQUs7R0FDaEMsTUFBTSxPQUFRLEtBQUssS0FBTyxDQUFDLEtBQUs7R0FHaEMsTUFBTSxPQUFPRyxNQUFVLElBQUksU0FBUyxNQUFNLFVBQVUsSUFBSSxXQUFXLEVBQUU7R0FDckUsTUFBTSxNQUFNQyxNQUFVLE1BQU0sSUFBSSxTQUFTLE1BQU0sVUFBVSxJQUFJLFdBQVcsRUFBRTtHQUMxRSxNQUFNLE1BQU0sT0FBTztHQUVuQixNQUFNLFVBQVVULE9BQVcsSUFBSSxJQUFJLEVBQUUsSUFBSUksT0FBVyxJQUFJLElBQUksRUFBRSxJQUFJQSxPQUFXLElBQUksSUFBSSxFQUFFO0dBQ3ZGLE1BQU0sVUFBVUYsT0FBVyxJQUFJLElBQUksRUFBRSxJQUFJRyxPQUFXLElBQUksSUFBSSxFQUFFLElBQUlBLE9BQVcsSUFBSSxJQUFJLEVBQUU7R0FDdkYsTUFBTSxPQUFRLEtBQUssS0FBTyxLQUFLLEtBQU8sS0FBSztHQUMzQyxNQUFNLE9BQVEsS0FBSyxLQUFPLEtBQUssS0FBTyxLQUFLO0dBQzNDLEtBQUssS0FBSztHQUNWLEtBQUssS0FBSztHQUNWLEtBQUssS0FBSztHQUNWLEtBQUssS0FBSztHQUNWLEtBQUssS0FBSztHQUNWLEtBQUssS0FBSztHQUNWLENBQUMsQ0FBRSxHQUFHLElBQUksR0FBRyxNQUFPSyxJQUFRLEtBQUssR0FBRyxLQUFLLEdBQUcsTUFBTSxHQUFHLE1BQU0sQ0FBQztHQUM1RCxLQUFLLEtBQUs7R0FDVixLQUFLLEtBQUs7R0FDVixLQUFLLEtBQUs7R0FDVixLQUFLLEtBQUs7R0FDVixLQUFLLEtBQUs7R0FDVixLQUFLLEtBQUs7R0FDVixNQUFNLE1BQU1DLE1BQVUsS0FBSyxTQUFTLElBQUk7R0FDeEMsS0FBS0MsTUFBVSxLQUFLLEtBQUssU0FBUyxJQUFJO0dBQ3RDLEtBQUssTUFBTTtFQUNmO0VBRUEsQ0FBQyxDQUFFLEdBQUcsSUFBSSxHQUFHLE1BQU9GLElBQVEsS0FBSyxLQUFLLEdBQUcsS0FBSyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQztFQUNwRSxDQUFDLENBQUUsR0FBRyxJQUFJLEdBQUcsTUFBT0EsSUFBUSxLQUFLLEtBQUssR0FBRyxLQUFLLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDO0VBQ3BFLENBQUMsQ0FBRSxHQUFHLElBQUksR0FBRyxNQUFPQSxJQUFRLEtBQUssS0FBSyxHQUFHLEtBQUssS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUM7RUFDcEUsQ0FBQyxDQUFFLEdBQUcsSUFBSSxHQUFHLE1BQU9BLElBQVEsS0FBSyxLQUFLLEdBQUcsS0FBSyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQztFQUNwRSxDQUFDLENBQUUsR0FBRyxJQUFJLEdBQUcsTUFBT0EsSUFBUSxLQUFLLEtBQUssR0FBRyxLQUFLLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDO0VBQ3BFLENBQUMsQ0FBRSxHQUFHLElBQUksR0FBRyxNQUFPQSxJQUFRLEtBQUssS0FBSyxHQUFHLEtBQUssS0FBSyxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUM7RUFDcEUsQ0FBQyxDQUFFLEdBQUcsSUFBSSxHQUFHLE1BQU9BLElBQVEsS0FBSyxLQUFLLEdBQUcsS0FBSyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQztFQUNwRSxDQUFDLENBQUUsR0FBRyxJQUFJLEdBQUcsTUFBT0EsSUFBUSxLQUFLLEtBQUssR0FBRyxLQUFLLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDO0VBQ3BFLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFO0NBQzNFO0NBQ0EsYUFBYTtFQUNULE1BQU0sWUFBWSxVQUFVO0NBQ2hDO0NBQ0EsVUFBVTtFQUdOLEtBQUssWUFBWTtFQUNqQixNQUFNLEtBQUssTUFBTTtFQUNqQixLQUFLLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztDQUMzRDtBQUNKOztBQUVBLElBQWEsVUFBYixjQUE2QixTQUFTO0NBQ2xDLEtBQUssVUFBVSxLQUFLO0NBQ3BCLEtBQUssVUFBVSxLQUFLO0NBQ3BCLEtBQUssVUFBVSxLQUFLO0NBQ3BCLEtBQUssVUFBVSxLQUFLO0NBQ3BCLEtBQUssVUFBVSxLQUFLO0NBQ3BCLEtBQUssVUFBVSxLQUFLO0NBQ3BCLEtBQUssVUFBVSxLQUFLO0NBQ3BCLEtBQUssVUFBVSxLQUFLO0NBQ3BCLEtBQUssVUFBVSxLQUFLO0NBQ3BCLEtBQUssVUFBVSxLQUFLO0NBQ3BCLEtBQUssVUFBVSxNQUFNO0NBQ3JCLEtBQUssVUFBVSxNQUFNO0NBQ3JCLEtBQUssVUFBVSxNQUFNO0NBQ3JCLEtBQUssVUFBVSxNQUFNO0NBQ3JCLEtBQUssVUFBVSxNQUFNO0NBQ3JCLEtBQUssVUFBVSxNQUFNO0NBQ3JCLGNBQWM7RUFDVixNQUFNLEVBQUU7Q0FDWjtBQUNKOzs7Ozs7Ozs7OztBQWdJQSxJQUFhLFNBQXlCLG1DQUFtQixJQUFJLFFBQVEsR0FDckQsd0JBQVEsQ0FBSSxDQUFDOzs7QUNsYW1ELElBQUksSUFBRSxPQUFPO0FBQWUsSUFBQSxJQUFFLE9BQU87QUFBc0IsSUFBQSxJQUFFLE9BQU8sVUFBVTtBQUFlLElBQUEsSUFBRSxPQUFPLFVBQVU7QUFBcUIsSUFBQSxLQUFHLEdBQUUsR0FBRSxNQUFJLEtBQUssSUFBRSxFQUFFLEdBQUUsR0FBRTtDQUFDLFlBQVcsQ0FBQztDQUFFLGNBQWEsQ0FBQztDQUFFLFVBQVMsQ0FBQztDQUFFLE9BQU07QUFBQyxDQUFDLElBQUUsRUFBRSxLQUFHO0FBQUUsSUFBQSxLQUFHLEdBQUUsR0FBRSxNQUFJLElBQUksU0FBUyxHQUFFLE1BQUk7Q0FBQyxJQUFJLEtBQUUsTUFBRztFQUFDLElBQUc7R0FBQyxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7RUFBQyxTQUFPLEdBQUU7R0FBQyxFQUFFLENBQUM7RUFBQztDQUFDLEdBQUUsS0FBRSxNQUFHO0VBQUMsSUFBRztHQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQztFQUFDLFNBQU8sR0FBRTtHQUFDLEVBQUUsQ0FBQztFQUFDO0NBQUMsR0FBRSxLQUFFLE1BQUcsRUFBRSxPQUFLLEVBQUUsRUFBRSxLQUFLLElBQUUsUUFBUSxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUMsS0FBSyxHQUFFLENBQUM7Q0FBRSxHQUFHLElBQUUsRUFBRSxNQUFNLEdBQUUsQ0FBQyxFQUFBLENBQUcsS0FBSyxDQUFDO0FBQUMsQ0FBQztBQUFFLFNBQVMsRUFBRSxHQUFFO0NBQUMsTUFBTSxJQUFFLENBQUM7Q0FBRSxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsSUFBRyxLQUFJLEVBQUUsbUVBQW1FLE1BQUk7Q0FBRSxNQUFNLElBQUUsRUFBRSxRQUFRLE9BQU0sRUFBRSxHQUFFLElBQUUsS0FBSyxNQUFNLElBQUUsRUFBRSxTQUFPLENBQUMsR0FBRSxJQUFFLElBQUksV0FBVyxDQUFDO0NBQUUsSUFBSSxJQUFFLEdBQUUsSUFBRSxHQUFFLElBQUU7Q0FBRSxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsRUFBRSxRQUFPLEtBQUk7RUFBQyxNQUFNLElBQUUsRUFBRSxFQUFFO0VBQUksSUFBRyxLQUFLLE1BQUksR0FBRSxNQUFNLElBQUksTUFBTSw2QkFBNkI7RUFBRSxJQUFFLEtBQUcsSUFBRSxHQUFFLEtBQUcsR0FBRSxLQUFHLE1BQUksS0FBRyxHQUFFLEVBQUUsT0FBSyxLQUFHLElBQUU7Q0FBSTtDQUFDLE9BQU87QUFBQztBQUF1QyxJQUFBLElBQUU7Q0FBQyxTQUFRO0NBQVUsV0FBVTtDQUF3QixZQUFXO0NBQTBCLFFBQU87Q0FBcUIsU0FBUTtDQUFzQixXQUFVO0NBQXlCLFdBQVU7Q0FBeUIsVUFBUztDQUF1QixZQUFXO0NBQTBCLGFBQVk7QUFBMEI7QUFBRSxJQUFBLElBQUU7Q0FBQyxTQUFRO0NBQVUsV0FBVTtDQUFZLFlBQVc7Q0FBYSxRQUFPO0NBQVMsU0FBUTtDQUFVLFdBQVU7Q0FBYSxXQUFVO0NBQWEsVUFBUztDQUFXLFlBQVc7Q0FBUSxhQUFZO0FBQWM7QUFBRSxTQUFTLEVBQUUsR0FBRSxJQUFFLFdBQVU7Q0FBQyxRQUFPLEdBQVA7RUFBVSxLQUFJLFVBQVMsT0FBTSxHQUFHLEVBQUU7RUFBcUIsS0FBSSxTQUFRLE9BQU0sR0FBRyxFQUFFO0VBQXlFLEtBQUksV0FBVSxPQUFNLEdBQUcsRUFBRTtFQUE4SCxLQUFJLFlBQVcsT0FBTSxHQUFHLEVBQUU7RUFBZ0MsS0FBSSxpQkFBZ0IsT0FBTSwwQkFBMEIsRUFBRTtFQUFHLEtBQUksV0FBVSxPQUFNLGlDQUFpQyxFQUFFO0VBQUcsS0FBSSxXQUFVLE9BQU0sR0FBRyxFQUFFO0VBQXdCLEtBQUksZ0JBQWUsT0FBTSxHQUFHLEVBQUU7RUFBNkIsU0FBUSxPQUFNLEdBQUcsRUFBRTtDQUF5QjtBQUFDO0FBQUMsSUFBSSxJQUFFO0FBQU0sU0FBUyxFQUFFLEdBQUUsR0FBRSxJQUFFLENBQUMsR0FBRTtDQUFDLFNBQVEsR0FBRSxNQUFJO0VBQUMsS0FBSSxJQUFJLEtBQUssTUFBSSxJQUFFLENBQUMsSUFBRyxFQUFFLEtBQUssR0FBRSxDQUFDLEtBQUcsRUFBRSxHQUFFLEdBQUUsRUFBRSxFQUFFO0VBQUUsSUFBRyxHQUFFLEtBQUksSUFBSSxLQUFLLEVBQUUsQ0FBQyxHQUFFLEVBQUUsS0FBSyxHQUFFLENBQUMsS0FBRyxFQUFFLEdBQUUsR0FBRSxFQUFFLEVBQUU7RUFBRSxPQUFPO0NBQUMsRUFBQSxDQUFHO0VBQUMsT0FBTSxhQUFXLEtBQUcsWUFBVTtFQUFFLFFBQU87RUFBRSxTQUFRLEVBQUUsR0FBRSxDQUFDO0NBQUMsR0FBRSxDQUFDO0FBQUM7QUFBQyxTQUFTLEVBQUUsR0FBRSxHQUFFO0NBQUMsT0FBTyxFQUFFLE1BQUssTUFBSyxhQUFXO0VBQUMsSUFBSSxHQUFFO0VBQUUsTUFBTSxJQUFFLEVBQUU7RUFBYSxJQUFHLFlBQVUsT0FBTyxLQUFHLENBQUMsRUFBRSxTQUFTLEdBQUcsR0FBRSxPQUFPLEVBQUUsV0FBVSxDQUFDO0VBQUUsTUFBTSxJQUFFLEVBQUUsTUFBTSxHQUFHO0VBQUUsSUFBRyxNQUFJLEVBQUUsUUFBTyxPQUFPLEVBQUUsV0FBVSxDQUFDO0VBQUUsTUFBSyxDQUFDLEdBQUUsS0FBRztFQUFFLElBQUksR0FBRSxHQUFFO0VBQUUsSUFBRztHQUFDLElBQUUsU0FBUyxHQUFFO0lBQUMsTUFBTSxJQUFFLEVBQUUsQ0FBQyxHQUFFLElBQUcsSUFBSSxZQUFVLENBQUMsQ0FBRSxPQUFPLENBQUM7SUFBRSxPQUFPLEtBQUssTUFBTSxDQUFDO0dBQUMsRUFBRSxDQUFDO0VBQUMsU0FBTyxHQUFFO0dBQUMsT0FBTyxFQUFFLFdBQVUsQ0FBQztFQUFDO0VBQUMsSUFBRyxDQUFDLEtBQUcsWUFBVSxPQUFPLEtBQUcsWUFBVSxPQUFPLEVBQUUsV0FBUyxZQUFVLE9BQU8sRUFBRSxRQUFNLFlBQVUsT0FBTyxFQUFFLE9BQUssWUFBVSxPQUFPLEVBQUUsT0FBSyxZQUFVLE9BQU8sRUFBRSxJQUFHLE9BQU8sRUFBRSxXQUFVLENBQUM7RUFBRSxJQUFHO0dBQUMsSUFBRSxFQUFFLENBQUMsR0FBRSxJQUFHLElBQUksWUFBVSxDQUFDLENBQUUsT0FBTyxDQUFDO0VBQUMsU0FBTyxHQUFFO0dBQUMsT0FBTyxFQUFFLFdBQVUsQ0FBQztFQUFDO0VBQUMsTUFBTSxJQUFFLFNBQU8sSUFBRSxFQUFFLHFCQUFtQixJQUFFO0VBQW1FLElBQUk7RUFBRSxJQUFHO0dBQUMsSUFBRSxTQUFTLEdBQUU7SUFBQyxJQUFHLEVBQUUsU0FBTyxLQUFHLEdBQUUsTUFBTSxJQUFJLE1BQU0sb0JBQW9CO0lBQUUsTUFBTSxJQUFFLElBQUksV0FBVyxFQUFFLFNBQU8sQ0FBQztJQUFFLEtBQUksSUFBSSxJQUFFLEdBQUUsSUFBRSxFQUFFLFFBQU8sS0FBSSxFQUFFLEtBQUcsU0FBUyxFQUFFLE9BQU8sSUFBRSxHQUFFLENBQUMsR0FBRSxFQUFFO0lBQUUsT0FBTztHQUFDLEVBQUUsQ0FBQztFQUFDLFNBQU8sR0FBRTtHQUFDLE9BQU8sRUFBRSxXQUFVLENBQUM7RUFBQztFQUFDLElBQUksSUFBRSxDQUFDO0VBQUUsSUFBRztHQUFDLElBQU0sZUFBYSxJQUFNLGNBQVksR0FBRyxNQUFJRyxPQUFBQSxJQUFRLFlBQVksR0FBRyxDQUFDLENBQUMsSUFBRyxJQUFFQyxPQUFTLEdBQUUsR0FBRSxDQUFDO0VBQUMsU0FBTyxHQUFFO0dBQUMsT0FBTyxFQUFFLFlBQVcsR0FBRSxFQUFDLFNBQVEsRUFBQyxDQUFDO0VBQUM7RUFBQyxJQUFHLENBQUMsR0FBRSxPQUFPLEVBQUUsWUFBVyxHQUFFLEVBQUMsU0FBUSxFQUFDLENBQUM7RUFBRSxJQUFHLENBQUMsU0FBUyxHQUFFLEdBQUU7R0FBQyxPQUFPLEVBQUUsWUFBVSxLQUFHLEVBQUUsQ0FBQyxFQUFFLFdBQUEsY0FBWSxLQUFHLEVBQUUsWUFBQSxhQUFhLGlCQUFlLEVBQUU7RUFBSyxFQUFFLEdBQUUsRUFBRSxPQUFPLEdBQUUsT0FBTyxFQUFFLGlCQUFnQixHQUFFLEVBQUMsU0FBUSxFQUFDLENBQUM7RUFBRSxNQUFNLElBQUUsTUFBSSxFQUFFLEtBQUksSUFBRSxLQUFLLElBQUksR0FBRSxJQUFFLEtBQUssT0FBTyxJQUFFLEtBQUcsQ0FBQyxHQUFFLElBQUUsU0FBUyxHQUFFO0dBQUMsSUFBRyxLQUFLLE1BQUksR0FBRSxPQUFPO0dBQUssSUFBRyxZQUFVLE9BQU8sR0FBRSxPQUFPLE1BQUk7R0FBRSxNQUFNLElBQUUsS0FBSyxNQUFNLENBQUM7R0FBRSxPQUFPLE9BQU8sTUFBTSxDQUFDLElBQUUsT0FBSztFQUFDLEVBQUUsRUFBRSxXQUFXO0VBQUUsSUFBRyxTQUFPLEtBQUcsSUFBRSxHQUFFLE9BQU8sRUFBRSxXQUFVLEdBQUU7R0FBQyxpQkFBZ0I7R0FBRSxTQUFRO0VBQUMsQ0FBQztFQUFFLElBQUcsU0FBUyxHQUFFO0dBQUMsT0FBTSxnQkFBYyxFQUFFO0VBQUksRUFBRSxDQUFDLEdBQUU7R0FBQyxJQUFHLElBQUUsS0FBRyxTQUFPLElBQUUsRUFBRSxhQUFXLElBQUUsTUFBSSxHQUFFLE9BQU8sRUFBRSxXQUFVLEdBQUU7SUFBQyxpQkFBZ0I7SUFBRSxTQUFRO0dBQUMsQ0FBQztHQUFFLElBQUcsSUFBRSxHQUFFLE9BQU8sRUFBRSxTQUFRLEdBQUU7SUFBQyxpQkFBZ0I7SUFBRSxTQUFRO0dBQUMsQ0FBQztFQUFDO0VBQUMsT0FBTyxFQUFFLFVBQVMsR0FBRTtHQUFDLGlCQUFnQjtHQUFFLFNBQVE7RUFBQyxDQUFDO0NBQUMsQ0FBQztBQUFDO0FBQUMsU0FBU0MsSUFBRSxHQUFFLEdBQUU7Q0FBQyxPQUFNO0VBQUMsT0FBTSxDQUFDO0VBQUUsUUFBTztFQUFFLFNBQVEsRUFBRSxHQUFFLENBQUM7Q0FBQztBQUFDO0FBQUMsU0FBUyxFQUFFLEdBQUUsR0FBRTtDQUFDLE1BQU0sSUFBRSxRQUFNLElBQUUsS0FBSyxJQUFFLEVBQUUsV0FBVSxJQUFFLFFBQU0sSUFBRSxLQUFLLElBQUUsRUFBRTtDQUFrQixPQUFNO0VBQUMsT0FBTyxHQUFFLEdBQUU7R0FBQyxPQUFPLEVBQUUsTUFBSyxNQUFLLGFBQVc7SUFBQyxJQUFJO0lBQUUsTUFBTSxJQUFFLEVBQUUsSUFBRyxJQUFFLFNBQU8sSUFBRSxFQUFFLE1BQUksSUFBRSxXQUFVLElBQUUsUUFBTSxJQUFFLEtBQUssSUFBRSxFQUFFO0lBQVksSUFBRyxDQUFDLEdBQUUsT0FBT0EsSUFBRSxXQUFVLENBQUM7SUFBRSxNQUFNLElBQUUsRUFBRSxJQUFHLElBQUUsRUFBRTtJQUFRLElBQUcsR0FBRTtLQUFDLE1BQU0sSUFBRSxNQUFNLEVBQUUsR0FBRTtNQUFDLFNBQVE7TUFBRSxjQUFhO01BQUUsYUFBWTtNQUFFLFdBQVU7TUFBRSxtQkFBa0I7S0FBQyxDQUFDO0tBQUUsSUFBRyxFQUFFLE9BQU0sT0FBTztLQUFFLElBQUcsb0JBQWtCLEVBQUUsUUFBTyxPQUFPO0lBQUM7SUFBQyxPQUFPLEtBQUcsY0FBWSxLQUFHLEVBQUUsV0FBQSxjQUFZLElBQUUsRUFBRSxHQUFFO0tBQUMsU0FBUTtLQUFFLGNBQWE7S0FBRSxhQUFZO0tBQUUsV0FBVTtLQUFFLG1CQUFrQjtJQUFDLENBQUMsSUFBRUEsSUFBRSxJQUFFLGtCQUFnQixXQUFVLENBQUM7R0FBQyxDQUFDO0VBQUM7RUFBRSxJQUFJLEdBQUU7R0FBQyxNQUFNLElBQUUsRUFBRTtHQUFHLE9BQU0sQ0FBQyxDQUFDLE1BQUksQ0FBQyxDQUFDLEVBQUUsTUFBSSxjQUFZLEtBQUcsRUFBRSxXQUFBLGNBQVksS0FBRyxDQUFDLENBQUMsRUFBRTtFQUFRO0NBQUM7QUFBQztBQUFDLElBQUksSUFBRTtBQUFLLFNBQVMsRUFBRSxHQUFFLEdBQUU7Q0FBQyxJQUFHLENBQUMsR0FBRSxNQUFNLElBQUksTUFBTSx3RUFBd0U7Q0FBRSxPQUFPLElBQUUsRUFBRSxHQUFFLENBQUM7QUFBQztBQUF1QixTQUFTLEVBQUUsR0FBRSxHQUFFO0NBQUMsSUFBSTtDQUFFLElBQUcsQ0FBQyxHQUFFO0VBQUMsTUFBTSxJQUFFLFNBQU8sSUFBRSxFQUFFLE1BQUksSUFBRTtFQUFVLE9BQU8sUUFBUSxRQUFRO0dBQUMsT0FBTSxDQUFDO0dBQUUsUUFBTztHQUFlLFNBQVEsRUFBRSxnQkFBZSxDQUFDO0VBQUMsQ0FBQztDQUFDO0NBQUMsT0FBTyxFQUFFLE9BQU8sR0FBRSxDQUFDO0FBQUM7OztBQ0VoaEssSUFBSSxrQkFBa0I7Q0FDcEIsYUFBYTtDQUNiLFVBQVU7Q0FDVixjQUFjO0NBQ2QsV0FBVztDQUNYLFFBQVE7Q0FDUixZQUFZO0NBQ1osSUFBSTtDQUNKLFdBQVc7Q0FDWCx1QkFBdUI7Q0FDdkIsY0FBYztDQUNkLDBCQUEwQjtDQUMxQixTQUFTO0NBQ1QsU0FBUztDQUNULGFBQWE7Q0FDYixhQUFhO0NBQ2IsWUFBWTtBQUNkOzs7QUNWQSxTQUFTLFFBQVEsR0FBRztDQUFFO0NBQTJCLE9BQU8sVUFBVSxjQUFjLE9BQU8sVUFBVSxZQUFZLE9BQU8sT0FBTyxXQUFXLFNBQVUsR0FBRztFQUFFLE9BQU8sT0FBTztDQUFHLElBQUksU0FBVSxHQUFHO0VBQUUsT0FBTyxLQUFLLGNBQWMsT0FBTyxVQUFVLEVBQUUsZ0JBQWdCLFVBQVUsTUFBTSxPQUFPLFlBQVksV0FBVyxPQUFPO0NBQUcsR0FBRyxRQUFRLENBQUM7QUFBRztBQUM3VCxTQUFTLFFBQVEsR0FBRyxHQUFHO0NBQUUsSUFBSSxJQUFJLE9BQU8sS0FBSyxDQUFDO0NBQUcsSUFBSSxPQUFPLHVCQUF1QjtFQUFFLElBQUksSUFBSSxPQUFPLHNCQUFzQixDQUFDO0VBQUcsTUFBTSxJQUFJLEVBQUUsT0FBTyxTQUFVLEdBQUc7R0FBRSxPQUFPLE9BQU8seUJBQXlCLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFBWSxDQUFDLElBQUksRUFBRSxLQUFLLE1BQU0sR0FBRyxDQUFDO0NBQUc7Q0FBRSxPQUFPO0FBQUc7QUFDOVAsU0FBUyxjQUFjLEdBQUc7Q0FBRSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxRQUFRLEtBQUs7RUFBRSxJQUFJLElBQUksUUFBUSxVQUFVLEtBQUssVUFBVSxLQUFLLENBQUM7RUFBRyxJQUFJLElBQUksUUFBUSxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxRQUFRLFNBQVUsR0FBRztHQUFFLGdCQUFnQixHQUFHLEdBQUcsRUFBRSxFQUFFO0VBQUcsQ0FBQyxJQUFJLE9BQU8sNEJBQTRCLE9BQU8saUJBQWlCLEdBQUcsT0FBTywwQkFBMEIsQ0FBQyxDQUFDLElBQUksUUFBUSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxTQUFVLEdBQUc7R0FBRSxPQUFPLGVBQWUsR0FBRyxHQUFHLE9BQU8seUJBQXlCLEdBQUcsQ0FBQyxDQUFDO0VBQUcsQ0FBQztDQUFHO0NBQUUsT0FBTztBQUFHO0FBQ3hiLFNBQVMsZ0JBQWdCLEdBQUcsR0FBRyxHQUFHO0NBQUUsUUFBUSxJQUFJLGVBQWUsQ0FBQyxNQUFNLElBQUksT0FBTyxlQUFlLEdBQUcsR0FBRztFQUFFLE9BQU87RUFBRyxZQUFZO0VBQU0sY0FBYztFQUFNLFVBQVU7Q0FBSyxDQUFDLElBQUksRUFBRSxLQUFLLEdBQUc7QUFBRztBQUN6TCxTQUFTLGVBQWUsR0FBRztDQUFFLElBQUksSUFBSSxhQUFhLEdBQUcsUUFBUTtDQUFHLE9BQU8sWUFBWSxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUk7QUFBSTtBQUM1RyxTQUFTLGFBQWEsR0FBRyxHQUFHO0NBQUUsSUFBSSxZQUFZLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxPQUFPO0NBQUcsSUFBSSxJQUFJLEVBQUUsT0FBTztDQUFjLElBQUksS0FBSyxNQUFNLEdBQUc7RUFBRSxJQUFJLElBQUksRUFBRSxLQUFLLEdBQUcsQ0FBQztFQUFHLElBQUksWUFBWSxRQUFRLENBQUMsR0FBRyxPQUFPO0VBQUcsTUFBTSxJQUFJLFVBQVUsOENBQThDO0NBQUc7Q0FBRSxRQUFRLGFBQWEsSUFBSSxTQUFTLE9BQUEsQ0FBUSxDQUFDO0FBQUc7QUFDOVMsSUFBSSxlQUFlO0FBQ25CLElBQUksaUJBQWlCO0NBQ25CLFFBQVE7Q0FDUixjQUFjO0NBQ2QsU0FBUztDQUNULFFBQVE7RUFDTixZQUFZO0VBQ1osVUFBVTtFQUNWLGFBQWE7RUFDYixVQUFVO0VBQ1YsUUFBUTtFQUNSLFdBQVc7RUFDWCxVQUFVO0VBQ1YsSUFBSTtFQUNKLEtBQUs7RUFDTCxJQUFJO0VBQ0osS0FBSztFQUNMLFFBQVE7RUFDUixXQUFXO0VBQ1gsWUFBWTtFQUNaLFdBQVc7RUFDWCxPQUFPO0VBQ1AsT0FBTztFQUNQLFVBQVU7RUFDVixVQUFVO0VBQ1YsU0FBUztFQUNULFlBQVk7RUFDWixRQUFRO0VBQ1IsUUFBUTtFQUNSLFFBQVE7RUFDUixRQUFRO0VBQ1IsUUFBUTtFQUNSLFdBQVc7RUFDWCxTQUFTO0VBQ1QsZUFBZTtHQUFDO0dBQUs7R0FBTTtHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtFQUFJO0VBQ25FLFVBQVU7R0FBQztHQUFVO0dBQVU7R0FBVztHQUFhO0dBQVk7R0FBVTtFQUFVO0VBQ3ZGLGVBQWU7R0FBQztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztFQUFLO0VBQy9ELGFBQWE7R0FBQztHQUFNO0dBQU07R0FBTTtHQUFNO0dBQU07R0FBTTtFQUFJO0VBQ3RELFlBQVk7R0FBQztHQUFXO0dBQVk7R0FBUztHQUFTO0dBQU87R0FBUTtHQUFRO0dBQVU7R0FBYTtHQUFXO0dBQVk7RUFBVTtFQUNySSxpQkFBaUI7R0FBQztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87RUFBSztFQUNwRyxZQUFZO0VBQ1osYUFBYTtFQUNiLFlBQVk7RUFDWixZQUFZO0VBQ1osWUFBWTtFQUNaLFVBQVU7RUFDVixVQUFVO0VBQ1YsV0FBVztFQUNYLFdBQVc7RUFDWCxVQUFVO0VBQ1YsVUFBVTtFQUNWLFlBQVk7RUFDWixZQUFZO0VBQ1osWUFBWTtFQUNaLFlBQVk7RUFDWixJQUFJO0VBQ0osSUFBSTtFQUNKLE9BQU87RUFDUCxZQUFZO0VBQ1osZ0JBQWdCO0VBQ2hCLG9CQUFvQjtFQUNwQixZQUFZO0VBQ1osTUFBTTtFQUNOLFFBQVE7RUFDUixRQUFRO0VBQ1IsZ0JBQWdCO0VBQ2hCLG9CQUFvQjtFQUNwQixlQUFlO0VBQ2Ysa0JBQWtCO0VBQ2xCLHVCQUF1QjtFQUN2QixvQkFBb0I7RUFDcEIsbUJBQW1CO0VBQ25CLHFCQUFxQjtFQUNyQixjQUFjO0VBQ2QsTUFBTTtHQUNKLFdBQVc7R0FDWCxZQUFZO0dBQ1osV0FBVztHQUNYLE1BQU07R0FDTixPQUFPO0dBQ1AsV0FBVztHQUNYLGFBQWE7R0FDYixPQUFPO0dBQ1AsVUFBVTtHQUNWLE1BQU07R0FDTixZQUFZO0dBQ1osV0FBVztHQUNYLFNBQVM7R0FDVCxRQUFRO0dBQ1IsVUFBVTtHQUNWLFlBQVk7R0FDWixjQUFjO0dBQ2QsY0FBYztHQUNkLGlCQUFpQjtHQUNqQixpQkFBaUI7R0FDakIsV0FBVztHQUNYLGdCQUFnQjtHQUNoQixlQUFlO0dBQ2YsZUFBZTtHQUNmLGVBQWU7R0FDZixrQkFBa0I7R0FDbEIseUJBQXlCO0dBQ3pCLHNCQUFzQjtHQUN0QixXQUFXO0dBQ1gsYUFBYTtHQUNiLFdBQVc7R0FDWCxhQUFhO0dBQ2IsZ0JBQWdCO0dBQ2hCLGdCQUFnQjtHQUNoQixnQkFBZ0I7R0FDaEIsa0JBQWtCO0dBQ2xCLFNBQVM7R0FDVCxVQUFVO0dBQ1YsWUFBWTtHQUNaLFVBQVU7R0FDVixVQUFVO0dBQ1YsT0FBTztHQUNQLGFBQWE7R0FDYixXQUFXO0dBQ1gsUUFBUTtHQUNSLFNBQVM7R0FDVCxhQUFhO0dBQ2IsWUFBWTtHQUNaLFdBQVc7RUFDYjtDQUNGO0NBQ0Esd0JBQXdCO0VBQ3RCLE1BQU07R0FBQyxnQkFBZ0I7R0FBYSxnQkFBZ0I7R0FBVSxnQkFBZ0I7R0FBYyxnQkFBZ0I7R0FBVyxnQkFBZ0I7R0FBUSxnQkFBZ0I7RUFBVTtFQUN6SyxTQUFTO0dBQUMsZ0JBQWdCO0dBQVEsZ0JBQWdCO0dBQVksZ0JBQWdCO0dBQVcsZ0JBQWdCO0dBQXVCLGdCQUFnQjtHQUFjLGdCQUFnQjtFQUF3QjtFQUN0TSxNQUFNO0dBQUMsZ0JBQWdCO0dBQVMsZ0JBQWdCO0dBQWEsZ0JBQWdCO0dBQWEsZ0JBQWdCO0VBQVU7Q0FDdEg7Q0FDQSxRQUFRO0VBQ04sT0FBTztFQUNQLFNBQVM7RUFDVCxNQUFNO0VBQ04sU0FBUztDQUNYO0NBQ0EsT0FBTyxLQUFBO0NBQ1AsVUFBVTtDQUNWLElBQUksS0FBQTtDQUNKLFdBQVc7RUFDVCxlQUFlO0VBQ2YsWUFBWTtDQUNkO0NBQ0EsS0FBSyxFQUNILE9BQU8sS0FBQSxFQUNUO0FBQ0Y7QUFDQSxJQUFJLGlCQUFpQixPQUFPO0FBQzVCLFNBQVMsY0FBYztDQUNyQixJQUFJLFdBQVcsT0FBTyxjQUFjO0NBQ3BDLElBQUksQ0FBQyxVQUNILE1BQU0sSUFBSSxNQUFNLDRCQUE0QjtDQUU5QyxPQUFPO0FBQ1Q7QUFDQSxTQUFTLE1BQU0sS0FBSyxTQUFTO0NBQzNCLElBQUksWUFBWSxJQUFJLElBQUk7Q0FDeEIsSUFBSSxRQUFRLFNBQ1YsRUFBZ0IsRUFDZCxTQUFTLFFBQVEsUUFDbkIsQ0FBQztDQUVILEVBQWMsV0FBVyxFQUN2QixhQUFhLGFBQ2YsQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFVLFFBQVE7RUFDeEIsVUFBVSxRQUFRLE9BQU87RUFDekIsSUFBSSxDQUFDLE9BQU8sT0FBTztHQUVqQixRQUFRLEtBQUssYUFBYSxPQUFPLE9BQU8sT0FBTyxDQUFDO0dBQ2hELHlCQUF5QjtFQUMzQjtDQUNGLENBQUM7Q0FDRCxJQUFJLFdBQVc7RUFDYixRQUFRLFNBQVMsT0FBTztFQUN4QixVQUFVLFNBQVMsU0FBUztDQUM5QjtDQUNBLElBQUksT0FBTyxpQkFBaUIsWUFBWTtDQUN4QyxJQUFJLFFBQVEsZ0JBQWdCLFFBQVE7Q0FDcEMsWUFBWTtDQUNaLFlBQVksS0FBSyxRQUFRO0NBQ3pCLE9BQU87QUFDVDtBQUNBLElBQUksZUFBZSxDQUFDO0FBQ3BCLFNBQVMsY0FBYztDQUNyQixFQUFhLE1BQU07Q0FDbkIsYUFBYSxRQUFRLFNBQVUsSUFBSTtFQUNqQyxPQUFPLE9BQU8sUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRztDQUNwRCxDQUFDO0NBQ0QsZUFBZSxDQUFDO0FBQ2xCO0FBQ0EsU0FBUyxZQUFZLEtBQUssVUFBVTtDQUNsQyxJQUFJLGlCQUFpQixJQUFJLEtBQUs7O0NBRzlCLElBQUksa0JBQWtCLFNBQVMsa0JBQWtCO0VBQy9DLElBQUk7RUFDSixNQUFNLG1CQUFtQixTQUFTLFlBQVksUUFBUSxxQkFBcUIsS0FBSyxJQUFJLEtBQUssSUFBSSxpQkFBaUIsV0FBVyxRQUFRO0VBR2pJLElBQUksQ0FBQ0MsRUFBTSxrQkFBa0IsUUFBUSxHQUFHO0dBQ3RDLElBQUksdUJBQXVCO0dBQzNCLElBQUksU0FBUyx3QkFBd0IsVUFBVSxvQkFBb0IsUUFBUSwwQkFBMEIsS0FBSyxJQUFJLEtBQUssSUFBSSxzQkFBc0IsS0FBSyxTQUFTLE1BQU0sQ0FBQyxHQUNoSyxZQUFZLEtBQUssV0FDakIsV0FBVyxLQUFLLFVBQ2hCLFNBQVMsS0FBSyxRQUNkLFFBQVEsS0FBSztHQUNmLElBQUksZUFBZSxFQUNqQixRQUFRLG9CQUFvQixTQUFTLFlBQVksUUFBUSxzQkFBc0IsS0FBSyxNQUFNLG9CQUFvQixrQkFBa0IsU0FBUyxRQUFRLHNCQUFzQixLQUFLLElBQUksS0FBSyxJQUFJLGtCQUFrQixNQUM3TTtHQUNBLFVBQVUsS0FBSyxjQUFjLFFBQVEsY0FBYyxLQUFLLElBQUksS0FBSyxJQUFJLFVBQVUsS0FBSyxjQUFjLEVBQ2hHLE1BQU0sc0JBQ1IsR0FBRyxZQUFZLENBQUM7R0FDaEIsVUFBVSxLQUFLLGFBQWEsUUFBUSxhQUFhLEtBQUssSUFBSSxLQUFLLElBQUksU0FBUyxLQUFLLGNBQWMsRUFDN0YsTUFBTSxxQkFDUixHQUFHLFlBQVksQ0FBQztHQUNoQixVQUFVLEtBQUssV0FBVyxRQUFRLFdBQVcsS0FBSyxJQUFJLEtBQUssSUFBSSxPQUFPLEtBQUssY0FBYyxFQUN2RixNQUFNLG1CQUNSLEdBQUcsWUFBWSxDQUFDO0dBQ2hCLFVBQVUsVUFBVSxjQUFjLEVBQ2hDLE1BQU0sZUFDUixHQUFHLFlBQVksR0FBRyxLQUFLO0dBQ3ZCLEVBQU0sbUJBQW1CLFFBQVE7RUFDbkM7Q0FDRjtDQUNBLEVBQWEsR0FBRyxnQkFBZ0IsU0FBVSxVQUFVO0VBQ2xELElBQUksQ0FBQyxlQUFlLE9BQU87R0FDekIsSUFBSSxPQUFPLGlCQUFpQixVQUFVLE9BQU8sUUFBUTtHQUNyRCxlQUFlLFFBQVE7RUFDekI7Q0FDRixDQUFDOztDQUdELElBQUksb0JBQW9CLE1BQU0sU0FBUyxRQUFRLFNBQVUsVUFBVSxVQUFVO0VBQzNFLGdCQUFnQixLQUFLLGlCQUFpQjtHQUMxQjtHQUNBO0VBQ1osQ0FBQztDQUNILEdBQUc7RUFDRCxXQUFXO0VBQ1gsTUFBTTtDQUNSLENBQUM7Q0FDRCxJQUFJLG9CQUFvQixNQUFNLFdBQVk7RUFDeEMsT0FBTyxTQUFTLE9BQU87Q0FDekIsR0FBRyxTQUFVLFVBQVUsVUFBVTtFQUMvQixnQkFBZ0IsS0FBSyx3QkFBd0I7R0FDakM7R0FDQTtFQUNaLENBQUM7Q0FDSCxHQUFHO0VBQ0QsV0FBVztFQUNYLE1BQU07Q0FDUixDQUFDO0NBQ0QsSUFBSSxtQkFBbUIsTUFBTSxXQUFZO0VBQ3ZDLE9BQU8sU0FBUyxPQUFPO0NBQ3pCLEdBQUcsU0FBVSxVQUFVLFVBQVU7RUFDL0IsSUFBSSxDQUFDLGVBQWUsT0FDbEIsRUFBTSxTQUFTLFFBQVE7RUFFekIsSUFBSSxDQUFDLFNBQVMsT0FBTyxVQUNuQixnQkFBZ0I7RUFFbEIsZUFBZSxRQUFRO0VBQ3ZCLGdCQUFnQixLQUFLLHVCQUF1QjtHQUNoQztHQUNBO0VBQ1osQ0FBQztDQUNILEdBQUc7RUFDRCxXQUFXO0VBQ1gsTUFBTTtDQUNSLENBQUM7Q0FDRCxJQUFJLHNCQUFzQixNQUFNLFdBQVk7RUFDMUMsT0FBTyxTQUFTLE9BQU87Q0FDekIsR0FBRyxTQUFVLFVBQVUsVUFBVTtFQUMvQixJQUFJLENBQUMsWUFBWSxTQUFTLE9BQU8sT0FDL0IsZ0JBQWdCO0VBRWxCLGdCQUFnQixLQUFLLDBCQUEwQjtHQUNuQztHQUNBO0VBQ1osQ0FBQztDQUNILEdBQUc7RUFDRCxXQUFXO0VBQ1gsTUFBTTtDQUNSLENBQUM7Q0FDRCxhQUFhLEtBQUssaUJBQWlCO0NBQ25DLGFBQWEsS0FBSyxpQkFBaUI7Q0FDbkMsYUFBYSxLQUFLLGdCQUFnQjtDQUNsQyxhQUFhLEtBQUssbUJBQW1CO0FBQ3ZDO0FBQ0EsSUFBSSxXQUFXLEVBQ2IsU0FBUyxTQUFTLFFBQVEsS0FBSyxTQUFTO0NBRXRDLE1BQU0sS0FEY0MsRUFBVSxnQkFBZ0IsT0FDdkIsQ0FBQztBQUMxQixFQUNGIn0=