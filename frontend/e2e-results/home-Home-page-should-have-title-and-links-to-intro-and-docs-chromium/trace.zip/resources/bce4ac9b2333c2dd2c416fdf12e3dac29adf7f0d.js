import { D as A, F as m, O as C, P as l, R as x, i as S, j as c, k as K, n as BaseStyle, r as R, t as showInvalidLicenseBanner } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.cache/vite/client/deps/licenseBanner-BJm6_Mu3.js?v=7e73afc2";
import { mergeProps, useId } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
//#region node_modules/.pnpm/@primevue+core@5.0.0_vue@3.5.40_typescript@6.0.3_/node_modules/@primevue/core/base/index.mjs
var Base = {
	_loadedStyleNames: /* @__PURE__ */ new Set(),
	getLoadedStyleNames: function getLoadedStyleNames() {
		return this._loadedStyleNames;
	},
	isStyleNameLoaded: function isStyleNameLoaded(name) {
		return this._loadedStyleNames.has(name);
	},
	setLoadedStyleName: function setLoadedStyleName(name) {
		this._loadedStyleNames.add(name);
	},
	deleteLoadedStyleName: function deleteLoadedStyleName(name) {
		this._loadedStyleNames["delete"](name);
	},
	clearLoadedStyleNames: function clearLoadedStyleNames() {
		this._loadedStyleNames.clear();
	}
};
//#endregion
//#region node_modules/.pnpm/@primevue+core@5.0.0_vue@3.5.40_typescript@6.0.3_/node_modules/@primevue/core/useattrselector/index.mjs
function useAttrSelector() {
	var prefix = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "pc";
	var idx = useId();
	return "".concat(prefix).concat(idx.replace("v-", "").replaceAll("-", "_"));
}
//#endregion
//#region node_modules/.pnpm/@primevue+core@5.0.0_vue@3.5.40_typescript@6.0.3_/node_modules/@primevue/core/basecomponent/index.mjs
var BaseComponentStyle = BaseStyle.extend({ name: "common" });
function _typeof(o) {
	"@babel/helpers - typeof";
	return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof(o);
}
function _toArray(r) {
	return _arrayWithHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableRest();
}
function _iterableToArray(r) {
	if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
}
function _slicedToArray(r, e) {
	return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
}
function _nonIterableRest() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
	}
}
function _arrayLikeToArray(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function _iterableToArrayLimit(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = true, o = false;
		try {
			if (i = (t = t.call(r)).next, 0 === l) {
				if (Object(t) !== t) return;
				f = !1;
			} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = true, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles(r) {
	if (Array.isArray(r)) return r;
}
function ownKeys(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys(Object(t), true).forEach(function(r) {
			_defineProperty(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty(e, r, t) {
	return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey(t) {
	var i = _toPrimitive(t, "string");
	return "symbol" == _typeof(i) ? i : i + "";
}
function _toPrimitive(t, r) {
	if ("object" != _typeof(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
var script = {
	name: "BaseComponent",
	props: {
		pt: {
			type: Object,
			"default": void 0
		},
		ptOptions: {
			type: Object,
			"default": void 0
		},
		unstyled: {
			type: Boolean,
			"default": void 0
		},
		dt: {
			type: Object,
			"default": void 0
		}
	},
	inject: { $parentInstance: { "default": void 0 } },
	watch: {
		isUnstyled: {
			immediate: true,
			handler: function handler(newValue) {
				R.off("theme:change", this._loadCoreStyles);
				if (!newValue) {
					this._loadCoreStyles();
					this._themeChangeListener(this._loadCoreStyles);
				}
			}
		},
		dt: {
			immediate: true,
			handler: function handler(newValue, oldValue) {
				var _this = this;
				R.off("theme:change", this._themeScopedListener);
				if (newValue) {
					this._loadScopedThemeStyles(newValue);
					this._themeScopedListener = function() {
						return _this._loadScopedThemeStyles(newValue);
					};
					this._themeChangeListener(this._themeScopedListener);
				} else this._unloadScopedThemeStyles();
			}
		}
	},
	scopedStyleEl: void 0,
	uid: void 0,
	$attrSelector: void 0,
	beforeCreate: function beforeCreate() {
		var _this$pt, _this$pt2, _this$pt3, _ref, _ref$onBeforeCreate, _this$$primevueConfig, _this$$primevue, _this$$primevue2, _this$$primevue3, _ref2, _ref2$onBeforeCreate;
		var _usept = (_this$pt = this.pt) === null || _this$pt === void 0 ? void 0 : _this$pt["_usept"];
		var originalValue = _usept ? (_this$pt2 = this.pt) === null || _this$pt2 === void 0 || (_this$pt2 = _this$pt2.originalValue) === null || _this$pt2 === void 0 ? void 0 : _this$pt2[this.$.type.name] : void 0;
		(_ref = (_usept ? (_this$pt3 = this.pt) === null || _this$pt3 === void 0 || (_this$pt3 = _this$pt3.value) === null || _this$pt3 === void 0 ? void 0 : _this$pt3[this.$.type.name] : this.pt) || originalValue) === null || _ref === void 0 || (_ref = _ref.hooks) === null || _ref === void 0 || (_ref$onBeforeCreate = _ref["onBeforeCreate"]) === null || _ref$onBeforeCreate === void 0 || _ref$onBeforeCreate.call(_ref);
		var _useptInConfig = (_this$$primevueConfig = this.$primevueConfig) === null || _this$$primevueConfig === void 0 || (_this$$primevueConfig = _this$$primevueConfig.pt) === null || _this$$primevueConfig === void 0 ? void 0 : _this$$primevueConfig["_usept"];
		var originalValueInConfig = _useptInConfig ? (_this$$primevue = this.$primevue) === null || _this$$primevue === void 0 || (_this$$primevue = _this$$primevue.config) === null || _this$$primevue === void 0 || (_this$$primevue = _this$$primevue.pt) === null || _this$$primevue === void 0 ? void 0 : _this$$primevue.originalValue : void 0;
		(_ref2 = (_useptInConfig ? (_this$$primevue2 = this.$primevue) === null || _this$$primevue2 === void 0 || (_this$$primevue2 = _this$$primevue2.config) === null || _this$$primevue2 === void 0 || (_this$$primevue2 = _this$$primevue2.pt) === null || _this$$primevue2 === void 0 ? void 0 : _this$$primevue2.value : (_this$$primevue3 = this.$primevue) === null || _this$$primevue3 === void 0 || (_this$$primevue3 = _this$$primevue3.config) === null || _this$$primevue3 === void 0 ? void 0 : _this$$primevue3.pt) || originalValueInConfig) === null || _ref2 === void 0 || (_ref2 = _ref2[this.$.type.name]) === null || _ref2 === void 0 || (_ref2 = _ref2.hooks) === null || _ref2 === void 0 || (_ref2$onBeforeCreate = _ref2["onBeforeCreate"]) === null || _ref2$onBeforeCreate === void 0 || _ref2$onBeforeCreate.call(_ref2);
		this.$attrSelector = useAttrSelector();
		this.uid = this.$attrs.id || this.$attrSelector.replace("pc", "pv_id_");
	},
	created: function created() {
		this._hook("onCreated");
	},
	beforeMount: function beforeMount() {
		this._loadStyles();
		this._hook("onBeforeMount");
	},
	mounted: function mounted() {
		var _this$$primevue$verif;
		this._hook("onMounted");
		if (!this.$primevue || ((_this$$primevue$verif = this.$primevue.verified) === null || _this$$primevue$verif === void 0 ? void 0 : _this$$primevue$verif.value) === false) showInvalidLicenseBanner();
	},
	beforeUpdate: function beforeUpdate() {
		this._hook("onBeforeUpdate");
	},
	updated: function updated() {
		this._hook("onUpdated");
	},
	beforeUnmount: function beforeUnmount() {
		this._hook("onBeforeUnmount");
	},
	unmounted: function unmounted() {
		this._removeThemeListeners();
		this._unloadScopedThemeStyles();
		this._hook("onUnmounted");
	},
	methods: {
		_hook: function _hook(hookName) {
			if (!this.$options.hostName) {
				var selfHook = this._usePT(this._getPT(this.pt, this.$.type.name), this._getOptionValue, "hooks.".concat(hookName));
				var defaultHook = this._useDefaultPT(this._getOptionValue, "hooks.".concat(hookName));
				selfHook === null || selfHook === void 0 || selfHook();
				defaultHook === null || defaultHook === void 0 || defaultHook();
			}
		},
		_mergeProps: function _mergeProps(fn) {
			for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key2 = 1; _key2 < _len; _key2++) args[_key2 - 1] = arguments[_key2];
			return m(fn) ? fn.apply(void 0, args) : mergeProps.apply(void 0, args);
		},
		_load: function _load() {
			if (!Base.isStyleNameLoaded("base")) {
				BaseStyle.loadCSS(this.$styleOptions);
				this._loadGlobalStyles();
				Base.setLoadedStyleName("base");
			}
			this._loadThemeStyles();
		},
		_loadStyles: function _loadStyles() {
			this._load();
			this._themeChangeListener(this._load);
		},
		_loadCoreStyles: function _loadCoreStyles() {
			var _this$$style, _this$$style2;
			if (!Base.isStyleNameLoaded((_this$$style = this.$style) === null || _this$$style === void 0 ? void 0 : _this$$style.name) && (_this$$style2 = this.$style) !== null && _this$$style2 !== void 0 && _this$$style2.name) {
				BaseComponentStyle.loadCSS(this.$styleOptions);
				this.$options.style && this.$style.loadCSS(this.$styleOptions);
				Base.setLoadedStyleName(this.$style.name);
			}
		},
		_loadGlobalStyles: function _loadGlobalStyles() {
			var globalCSS = this._useGlobalPT(this._getOptionValue, "global.css", this.$params);
			l(globalCSS) && BaseStyle.load(globalCSS, _objectSpread({ name: "global" }, this.$styleOptions));
		},
		_loadThemeStyles: function _loadThemeStyles() {
			var _this$$style4, _this$$style5;
			if (this.isUnstyled || this.$theme === "none") return;
			if (!S.isStyleNameLoaded("common")) {
				var _this$$style3, _this$$style3$getComm;
				var _ref3 = ((_this$$style3 = this.$style) === null || _this$$style3 === void 0 || (_this$$style3$getComm = _this$$style3.getCommonTheme) === null || _this$$style3$getComm === void 0 ? void 0 : _this$$style3$getComm.call(_this$$style3)) || {}, primitive = _ref3.primitive, semantic = _ref3.semantic, global = _ref3.global, style = _ref3.style;
				BaseStyle.load(primitive === null || primitive === void 0 ? void 0 : primitive.css, _objectSpread({ name: "primitive-variables" }, this.$styleOptions));
				BaseStyle.load(semantic === null || semantic === void 0 ? void 0 : semantic.css, _objectSpread({ name: "semantic-variables" }, this.$styleOptions));
				BaseStyle.load(global === null || global === void 0 ? void 0 : global.css, _objectSpread({ name: "global-variables" }, this.$styleOptions));
				BaseStyle.loadStyle(_objectSpread({ name: "global-style" }, this.$styleOptions), style);
				S.setLoadedStyleName("common");
			}
			if (!S.isStyleNameLoaded((_this$$style4 = this.$style) === null || _this$$style4 === void 0 ? void 0 : _this$$style4.name) && (_this$$style5 = this.$style) !== null && _this$$style5 !== void 0 && _this$$style5.name) {
				var _this$$style6, _this$$style6$getComp, _this$$style7, _this$$style8;
				var _ref4 = ((_this$$style6 = this.$style) === null || _this$$style6 === void 0 || (_this$$style6$getComp = _this$$style6.getComponentTheme) === null || _this$$style6$getComp === void 0 ? void 0 : _this$$style6$getComp.call(_this$$style6)) || {}, css = _ref4.css, _style = _ref4.style;
				(_this$$style7 = this.$style) === null || _this$$style7 === void 0 || _this$$style7.load(css, _objectSpread({ name: "".concat(this.$style.name, "-variables") }, this.$styleOptions));
				(_this$$style8 = this.$style) === null || _this$$style8 === void 0 || _this$$style8.loadStyle(_objectSpread({ name: "".concat(this.$style.name, "-style") }, this.$styleOptions), _style);
				S.setLoadedStyleName(this.$style.name);
			}
			if (!S.isStyleNameLoaded("layer-order")) {
				var _this$$style9, _this$$style9$getLaye;
				var layerOrder = (_this$$style9 = this.$style) === null || _this$$style9 === void 0 || (_this$$style9$getLaye = _this$$style9.getLayerOrderThemeCSS) === null || _this$$style9$getLaye === void 0 ? void 0 : _this$$style9$getLaye.call(_this$$style9);
				BaseStyle.load(layerOrder, _objectSpread({
					name: "layer-order",
					first: true
				}, this.$styleOptions));
				S.setLoadedStyleName("layer-order");
			}
		},
		_loadScopedThemeStyles: function _loadScopedThemeStyles(preset) {
			var _this$$theme, _this$$style0, _this$$style1, _this$$style1$getPres, _this$$style10;
			if (((_this$$theme = this.$theme) === null || _this$$theme === void 0 || (_this$$theme = _this$$theme.options) === null || _this$$theme === void 0 ? void 0 : _this$$theme.cssVariables) === false && (_this$$style0 = this.$style) !== null && _this$$style0 !== void 0 && _this$$style0.name) {
				if (S.addScopedToken(_defineProperty({}, this.$style.name, preset))) {
					S.deleteLoadedStyleName(this.$style.name);
					this._loadThemeStyles();
				}
			}
			var css = (((_this$$style1 = this.$style) === null || _this$$style1 === void 0 || (_this$$style1$getPres = _this$$style1.getPresetTheme) === null || _this$$style1$getPres === void 0 ? void 0 : _this$$style1$getPres.call(_this$$style1, preset, "[".concat(this.$attrSelector, "]"))) || {}).css;
			var scopedStyle = (_this$$style10 = this.$style) === null || _this$$style10 === void 0 ? void 0 : _this$$style10.load(css, _objectSpread({ name: "".concat(this.$attrSelector, "-").concat(this.$style.name) }, this.$styleOptions));
			this.scopedStyleEl = scopedStyle === null || scopedStyle === void 0 ? void 0 : scopedStyle.el;
		},
		_unloadScopedThemeStyles: function _unloadScopedThemeStyles() {
			var _this$scopedStyleEl;
			(_this$scopedStyleEl = this.scopedStyleEl) === null || _this$scopedStyleEl === void 0 || (_this$scopedStyleEl = _this$scopedStyleEl.value) === null || _this$scopedStyleEl === void 0 || _this$scopedStyleEl.remove();
		},
		_themeChangeListener: function _themeChangeListener() {
			var callback = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : function() {};
			Base.clearLoadedStyleNames();
			R.on("theme:change", callback);
		},
		_removeThemeListeners: function _removeThemeListeners() {
			R.off("theme:change", this._loadCoreStyles);
			R.off("theme:change", this._load);
			R.off("theme:change", this._themeScopedListener);
		},
		_getHostInstance: function _getHostInstance(instance) {
			return instance ? this.$options.hostName ? instance.$.type.name === this.$options.hostName ? instance : this._getHostInstance(instance.$parentInstance) : instance.$parentInstance : void 0;
		},
		_getPropValue: function _getPropValue(name) {
			var _this$_getHostInstanc;
			return this[name] || ((_this$_getHostInstanc = this._getHostInstance(this)) === null || _this$_getHostInstanc === void 0 ? void 0 : _this$_getHostInstanc[name]);
		},
		_getOptionValue: function _getOptionValue(options) {
			var key = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
			var params = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
			return K(options, key, params);
		},
		_getPTValue: function _getPTValue() {
			var _this$$primevueConfig2;
			var obj = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
			var key = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
			var params = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
			var searchInDefaultPT = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : true;
			var searchOut = /./g.test(key) && !!params[key.split(".")[0]];
			var _ref6 = this._getPropValue("ptOptions") || ((_this$$primevueConfig2 = this.$primevueConfig) === null || _this$$primevueConfig2 === void 0 ? void 0 : _this$$primevueConfig2.ptOptions) || {}, _ref6$mergeSections = _ref6.mergeSections, mergeSections = _ref6$mergeSections === void 0 ? true : _ref6$mergeSections, _ref6$mergeProps = _ref6.mergeProps, useMergeProps = _ref6$mergeProps === void 0 ? false : _ref6$mergeProps;
			var global = searchInDefaultPT ? searchOut ? this._useGlobalPT(this._getPTClassValue, key, params) : this._useDefaultPT(this._getPTClassValue, key, params) : void 0;
			var self = searchOut ? void 0 : this._getPTSelf(obj, this._getPTClassValue, key, _objectSpread(_objectSpread({}, params), {}, { global: global || {} }));
			var datasets = this._getPTDatasets(key);
			return mergeSections || !mergeSections && self ? useMergeProps ? this._mergeProps(useMergeProps, global, self, datasets) : _objectSpread(_objectSpread(_objectSpread({}, global), self), datasets) : _objectSpread(_objectSpread({}, self), datasets);
		},
		_getPTSelf: function _getPTSelf() {
			var obj = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
			for (var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key3 = 1; _key3 < _len2; _key3++) args[_key3 - 1] = arguments[_key3];
			return mergeProps(this._usePT.apply(this, [this._getPT(obj, this.$name)].concat(args)), this._usePT.apply(this, [this.$_attrsPT].concat(args)));
		},
		_getPTDatasets: function _getPTDatasets() {
			var _this$pt4, _this$pt5;
			var key = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
			var datasetPrefix = "data-pc-";
			var isExtended = key === "root" && l((_this$pt4 = this.pt) === null || _this$pt4 === void 0 ? void 0 : _this$pt4["data-pc-section"]);
			return key !== "transition" && _objectSpread(_objectSpread({}, key === "root" && _objectSpread(_objectSpread(_defineProperty({}, "".concat(datasetPrefix, "name"), C(isExtended ? (_this$pt5 = this.pt) === null || _this$pt5 === void 0 ? void 0 : _this$pt5["data-pc-section"] : this.$.type.name)), isExtended && _defineProperty({}, "".concat(datasetPrefix, "extend"), C(this.$.type.name))), {}, _defineProperty({}, "".concat(this.$attrSelector), ""))), {}, _defineProperty({}, "".concat(datasetPrefix, "section"), C(key)));
		},
		_getPTClassValue: function _getPTClassValue() {
			var value = this._getOptionValue.apply(this, arguments);
			return c(value) || A(value) ? { "class": value } : value;
		},
		_getPT: function _getPT(pt) {
			var _this2 = this;
			var key = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
			var callback = arguments.length > 2 ? arguments[2] : void 0;
			var getValue = function getValue(value) {
				var _ref8;
				var checkSameKey = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
				var computedValue = callback ? callback(value) : value;
				var _key = C(key);
				var _cKey = C(_this2.$name);
				return (_ref8 = checkSameKey ? _key !== _cKey ? computedValue === null || computedValue === void 0 ? void 0 : computedValue[_key] : void 0 : computedValue === null || computedValue === void 0 ? void 0 : computedValue[_key]) !== null && _ref8 !== void 0 ? _ref8 : computedValue;
			};
			return pt !== null && pt !== void 0 && pt.hasOwnProperty("_usept") ? {
				_usept: pt["_usept"],
				originalValue: getValue(pt.originalValue),
				value: getValue(pt.value)
			} : getValue(pt, true);
		},
		_usePT: function _usePT(pt, callback, key, params) {
			var fn = function fn(value) {
				return callback(value, key, params);
			};
			if (pt !== null && pt !== void 0 && pt.hasOwnProperty("_usept")) {
				var _this$$primevueConfig3;
				var _ref9 = pt["_usept"] || ((_this$$primevueConfig3 = this.$primevueConfig) === null || _this$$primevueConfig3 === void 0 ? void 0 : _this$$primevueConfig3.ptOptions) || {}, _ref9$mergeSections = _ref9.mergeSections, mergeSections = _ref9$mergeSections === void 0 ? true : _ref9$mergeSections, _ref9$mergeProps = _ref9.mergeProps, useMergeProps = _ref9$mergeProps === void 0 ? false : _ref9$mergeProps;
				var originalValue = fn(pt.originalValue);
				var value = fn(pt.value);
				if (originalValue === void 0 && value === void 0) return void 0;
				else if (c(value)) return value;
				else if (c(originalValue)) return originalValue;
				return mergeSections || !mergeSections && value ? useMergeProps ? this._mergeProps(useMergeProps, originalValue, value) : _objectSpread(_objectSpread({}, originalValue), value) : value;
			}
			return fn(pt);
		},
		_useGlobalPT: function _useGlobalPT(callback, key, params) {
			return this._usePT(this.globalPT, callback, key, params);
		},
		_useDefaultPT: function _useDefaultPT(callback, key, params) {
			return this._usePT(this.defaultPT, callback, key, params);
		},
		ptm: function ptm() {
			var key = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
			var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
			return this._getPTValue(this.pt, key, _objectSpread(_objectSpread({}, this.$params), params));
		},
		ptmi: function ptmi() {
			var _attrs$id;
			var key = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
			var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
			var attrs = mergeProps(this.$_attrsWithoutPT, this.ptm(key, params));
			attrs !== null && attrs !== void 0 && attrs.hasOwnProperty("id") && ((_attrs$id = attrs.id) !== null && _attrs$id !== void 0 || (attrs.id = this.$id));
			return attrs;
		},
		ptmo: function ptmo() {
			var obj = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
			var key = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
			var params = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
			return this._getPTValue(obj, key, _objectSpread({ instance: this }, params), false);
		},
		cx: function cx() {
			var key = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
			var params = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
			return !this.isUnstyled ? this._getOptionValue(this.$style.classes, key, _objectSpread(_objectSpread({}, this.$params), params)) : void 0;
		},
		sx: function sx() {
			var key = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
			var when = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : true;
			var params = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
			if (when) {
				var self = this._getOptionValue(this.$style.inlineStyles, key, _objectSpread(_objectSpread({}, this.$params), params));
				return [this._getOptionValue(BaseComponentStyle.inlineStyles, key, _objectSpread(_objectSpread({}, this.$params), params)), self];
			}
		}
	},
	computed: {
		globalPT: function globalPT() {
			var _this$$primevueConfig4, _this3 = this;
			return this._getPT((_this$$primevueConfig4 = this.$primevueConfig) === null || _this$$primevueConfig4 === void 0 ? void 0 : _this$$primevueConfig4.pt, void 0, function(value) {
				return x(value, { instance: _this3 });
			});
		},
		defaultPT: function defaultPT() {
			var _this$$primevueConfig5, _this4 = this;
			return this._getPT((_this$$primevueConfig5 = this.$primevueConfig) === null || _this$$primevueConfig5 === void 0 ? void 0 : _this$$primevueConfig5.pt, void 0, function(value) {
				return _this4._getOptionValue(value, _this4.$name, _objectSpread({}, _this4.$params)) || x(value, _objectSpread({}, _this4.$params));
			});
		},
		isUnstyled: function isUnstyled() {
			var _this$$primevueConfig6;
			return this.unstyled !== void 0 ? this.unstyled : (_this$$primevueConfig6 = this.$primevueConfig) === null || _this$$primevueConfig6 === void 0 ? void 0 : _this$$primevueConfig6.unstyled;
		},
		$id: function $id() {
			return this.$attrs.id || this.uid;
		},
		$inProps: function $inProps() {
			var _this$$$vnode;
			var nodePropKeys = Object.keys(((_this$$$vnode = this.$.vnode) === null || _this$$$vnode === void 0 ? void 0 : _this$$$vnode.props) || {});
			return Object.fromEntries(Object.entries(this.$props).filter(function(_ref0) {
				var k = _slicedToArray(_ref0, 1)[0];
				return nodePropKeys === null || nodePropKeys === void 0 ? void 0 : nodePropKeys.includes(k);
			}));
		},
		$theme: function $theme() {
			var _this$$primevueConfig7;
			return (_this$$primevueConfig7 = this.$primevueConfig) === null || _this$$primevueConfig7 === void 0 ? void 0 : _this$$primevueConfig7.theme;
		},
		$style: function $style() {
			return _objectSpread(_objectSpread({
				classes: void 0,
				inlineStyles: void 0,
				load: function load() {},
				loadCSS: function loadCSS() {},
				loadStyle: function loadStyle() {}
			}, (this._getHostInstance(this) || {}).$style), this.$options.style);
		},
		$styleOptions: function $styleOptions() {
			var _this$$primevueConfig8;
			return { nonce: (_this$$primevueConfig8 = this.$primevueConfig) === null || _this$$primevueConfig8 === void 0 || (_this$$primevueConfig8 = _this$$primevueConfig8.csp) === null || _this$$primevueConfig8 === void 0 ? void 0 : _this$$primevueConfig8.nonce };
		},
		$primevueConfig: function $primevueConfig() {
			var _this$$primevue4;
			return (_this$$primevue4 = this.$primevue) === null || _this$$primevue4 === void 0 ? void 0 : _this$$primevue4.config;
		},
		$name: function $name() {
			return this.$options.hostName || this.$.type.name;
		},
		$params: function $params() {
			var parentInstance = this._getHostInstance(this) || this.$parent;
			return {
				instance: this,
				props: this.$props,
				state: this.$data,
				attrs: this.$attrs,
				parent: {
					instance: parentInstance,
					props: parentInstance === null || parentInstance === void 0 ? void 0 : parentInstance.$props,
					state: parentInstance === null || parentInstance === void 0 ? void 0 : parentInstance.$data,
					attrs: parentInstance === null || parentInstance === void 0 ? void 0 : parentInstance.$attrs
				}
			};
		},
		$_attrsPT: function $_attrsPT() {
			return Object.entries(this.$attrs || {}).filter(function(_ref10) {
				var key = _slicedToArray(_ref10, 1)[0];
				return key === null || key === void 0 ? void 0 : key.startsWith("pt:");
			}).reduce(function(result, _ref12) {
				var _ref13 = _slicedToArray(_ref12, 2), key = _ref13[0], value = _ref13[1];
				var rest = _arrayLikeToArray(_toArray(key.split(":"))).slice(1);
				rest === null || rest === void 0 || rest.reduce(function(currentObj, nestedKey, index, array) {
					!currentObj[nestedKey] && (currentObj[nestedKey] = index === array.length - 1 ? value : {});
					return currentObj[nestedKey];
				}, result);
				return result;
			}, {});
		},
		$_attrsWithoutPT: function $_attrsWithoutPT() {
			return Object.entries(this.$attrs || {}).filter(function(_ref14) {
				var key = _slicedToArray(_ref14, 1)[0];
				return !(key !== null && key !== void 0 && key.startsWith("pt:"));
			}).reduce(function(acc, _ref16) {
				var _ref17 = _slicedToArray(_ref16, 2), key = _ref17[0];
				acc[key] = _ref17[1];
				return acc;
			}, {});
		}
	}
};
//#endregion
export { Base as n, script as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZWNvbXBvbmVudC1sWmdfaHM2Yy5qcyIsIm5hbWVzIjpbImlzRnVuY3Rpb24iLCJUaGVtZSIsImdldEtleVZhbHVlIiwiaXNOb3RFbXB0eSIsInRvRmxhdENhc2UiLCJpc1N0cmluZyIsImlzQXJyYXkiLCJyZXNvbHZlIl0sInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLnBucG0vQHByaW1ldnVlK2NvcmVANS4wLjBfdnVlQDMuNS40MF90eXBlc2NyaXB0QDYuMC4zXy9ub2RlX21vZHVsZXMvQHByaW1ldnVlL2NvcmUvYmFzZS9pbmRleC5tanMiLCIuLi8uLi8uLi8uLi8ucG5wbS9AcHJpbWV2dWUrY29yZUA1LjAuMF92dWVAMy41LjQwX3R5cGVzY3JpcHRANi4wLjNfL25vZGVfbW9kdWxlcy9AcHJpbWV2dWUvY29yZS91c2VhdHRyc2VsZWN0b3IvaW5kZXgubWpzIiwiLi4vLi4vLi4vLi4vLnBucG0vQHByaW1ldnVlK2NvcmVANS4wLjBfdnVlQDMuNS40MF90eXBlc2NyaXB0QDYuMC4zXy9ub2RlX21vZHVsZXMvQHByaW1ldnVlL2NvcmUvYmFzZWNvbXBvbmVudC9pbmRleC5tanMiXSwic291cmNlc0NvbnRlbnQiOlsidmFyIEJhc2UgPSB7XG4gIF9sb2FkZWRTdHlsZU5hbWVzOiBuZXcgU2V0KCksXG4gIGdldExvYWRlZFN0eWxlTmFtZXM6IGZ1bmN0aW9uIGdldExvYWRlZFN0eWxlTmFtZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvYWRlZFN0eWxlTmFtZXM7XG4gIH0sXG4gIGlzU3R5bGVOYW1lTG9hZGVkOiBmdW5jdGlvbiBpc1N0eWxlTmFtZUxvYWRlZChuYW1lKSB7XG4gICAgcmV0dXJuIHRoaXMuX2xvYWRlZFN0eWxlTmFtZXMuaGFzKG5hbWUpO1xuICB9LFxuICBzZXRMb2FkZWRTdHlsZU5hbWU6IGZ1bmN0aW9uIHNldExvYWRlZFN0eWxlTmFtZShuYW1lKSB7XG4gICAgdGhpcy5fbG9hZGVkU3R5bGVOYW1lcy5hZGQobmFtZSk7XG4gIH0sXG4gIGRlbGV0ZUxvYWRlZFN0eWxlTmFtZTogZnVuY3Rpb24gZGVsZXRlTG9hZGVkU3R5bGVOYW1lKG5hbWUpIHtcbiAgICB0aGlzLl9sb2FkZWRTdHlsZU5hbWVzW1wiZGVsZXRlXCJdKG5hbWUpO1xuICB9LFxuICBjbGVhckxvYWRlZFN0eWxlTmFtZXM6IGZ1bmN0aW9uIGNsZWFyTG9hZGVkU3R5bGVOYW1lcygpIHtcbiAgICB0aGlzLl9sb2FkZWRTdHlsZU5hbWVzLmNsZWFyKCk7XG4gIH1cbn07XG5cbmV4cG9ydCB7IEJhc2UgYXMgZGVmYXVsdCB9O1xuIiwiaW1wb3J0IHsgdXNlSWQgfSBmcm9tICd2dWUnO1xuXG5mdW5jdGlvbiB1c2VBdHRyU2VsZWN0b3IoKSB7XG4gIHZhciBwcmVmaXggPSBhcmd1bWVudHMubGVuZ3RoID4gMCAmJiBhcmd1bWVudHNbMF0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1swXSA6ICdwYyc7XG4gIHZhciBpZHggPSB1c2VJZCgpO1xuICByZXR1cm4gXCJcIi5jb25jYXQocHJlZml4KS5jb25jYXQoaWR4LnJlcGxhY2UoJ3YtJywgJycpLnJlcGxhY2VBbGwoJy0nLCAnXycpKTtcbn1cblxuZXhwb3J0IHsgdXNlQXR0clNlbGVjdG9yIH07XG4iLCJpbXBvcnQgeyBUaGVtZVNlcnZpY2UsIFRoZW1lIH0gZnJvbSAnQHByaW1ldWl4L3N0eWxlZCc7XG5pbXBvcnQgeyByZXNvbHZlLCBpc1N0cmluZywgaXNBcnJheSwgaXNOb3RFbXB0eSwgdG9GbGF0Q2FzZSwgZ2V0S2V5VmFsdWUsIGlzRnVuY3Rpb24gfSBmcm9tICdAcHJpbWV1aXgvdXRpbHMvb2JqZWN0JztcbmltcG9ydCBCYXNlIGZyb20gJ0BwcmltZXZ1ZS9jb3JlL2Jhc2UnO1xuaW1wb3J0IEJhc2VTdHlsZSBmcm9tICdAcHJpbWV2dWUvY29yZS9iYXNlL3N0eWxlJztcbmltcG9ydCB7IHNob3dJbnZhbGlkTGljZW5zZUJhbm5lciB9IGZyb20gJ0BwcmltZXZ1ZS9jb3JlL2xpY2Vuc2UvbGljZW5zZUJhbm5lcic7XG5pbXBvcnQgeyB1c2VBdHRyU2VsZWN0b3IgfSBmcm9tICdAcHJpbWV2dWUvY29yZS91c2VhdHRyc2VsZWN0b3InO1xuaW1wb3J0IHsgbWVyZ2VQcm9wcyB9IGZyb20gJ3Z1ZSc7XG5cbnZhciBCYXNlQ29tcG9uZW50U3R5bGUgPSBCYXNlU3R5bGUuZXh0ZW5kKHtcbiAgbmFtZTogJ2NvbW1vbidcbn0pO1xuXG5mdW5jdGlvbiBfdHlwZW9mKG8pIHsgXCJAYmFiZWwvaGVscGVycyAtIHR5cGVvZlwiOyByZXR1cm4gX3R5cGVvZiA9IFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgU3ltYm9sICYmIFwic3ltYm9sXCIgPT0gdHlwZW9mIFN5bWJvbC5pdGVyYXRvciA/IGZ1bmN0aW9uIChvKSB7IHJldHVybiB0eXBlb2YgbzsgfSA6IGZ1bmN0aW9uIChvKSB7IHJldHVybiBvICYmIFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgU3ltYm9sICYmIG8uY29uc3RydWN0b3IgPT09IFN5bWJvbCAmJiBvICE9PSBTeW1ib2wucHJvdG90eXBlID8gXCJzeW1ib2xcIiA6IHR5cGVvZiBvOyB9LCBfdHlwZW9mKG8pOyB9XG5mdW5jdGlvbiBfdG9BcnJheShyKSB7IHJldHVybiBfYXJyYXlXaXRoSG9sZXMocikgfHwgX2l0ZXJhYmxlVG9BcnJheShyKSB8fCBfdW5zdXBwb3J0ZWRJdGVyYWJsZVRvQXJyYXkocikgfHwgX25vbkl0ZXJhYmxlUmVzdCgpOyB9XG5mdW5jdGlvbiBfaXRlcmFibGVUb0FycmF5KHIpIHsgaWYgKFwidW5kZWZpbmVkXCIgIT0gdHlwZW9mIFN5bWJvbCAmJiBudWxsICE9IHJbU3ltYm9sLml0ZXJhdG9yXSB8fCBudWxsICE9IHJbXCJAQGl0ZXJhdG9yXCJdKSByZXR1cm4gQXJyYXkuZnJvbShyKTsgfVxuZnVuY3Rpb24gX3NsaWNlZFRvQXJyYXkociwgZSkgeyByZXR1cm4gX2FycmF5V2l0aEhvbGVzKHIpIHx8IF9pdGVyYWJsZVRvQXJyYXlMaW1pdChyLCBlKSB8fCBfdW5zdXBwb3J0ZWRJdGVyYWJsZVRvQXJyYXkociwgZSkgfHwgX25vbkl0ZXJhYmxlUmVzdCgpOyB9XG5mdW5jdGlvbiBfbm9uSXRlcmFibGVSZXN0KCkgeyB0aHJvdyBuZXcgVHlwZUVycm9yKFwiSW52YWxpZCBhdHRlbXB0IHRvIGRlc3RydWN0dXJlIG5vbi1pdGVyYWJsZSBpbnN0YW5jZS5cXG5JbiBvcmRlciB0byBiZSBpdGVyYWJsZSwgbm9uLWFycmF5IG9iamVjdHMgbXVzdCBoYXZlIGEgW1N5bWJvbC5pdGVyYXRvcl0oKSBtZXRob2QuXCIpOyB9XG5mdW5jdGlvbiBfdW5zdXBwb3J0ZWRJdGVyYWJsZVRvQXJyYXkociwgYSkgeyBpZiAocikgeyBpZiAoXCJzdHJpbmdcIiA9PSB0eXBlb2YgcikgcmV0dXJuIF9hcnJheUxpa2VUb0FycmF5KHIsIGEpOyB2YXIgdCA9IHt9LnRvU3RyaW5nLmNhbGwocikuc2xpY2UoOCwgLTEpOyByZXR1cm4gXCJPYmplY3RcIiA9PT0gdCAmJiByLmNvbnN0cnVjdG9yICYmICh0ID0gci5jb25zdHJ1Y3Rvci5uYW1lKSwgXCJNYXBcIiA9PT0gdCB8fCBcIlNldFwiID09PSB0ID8gQXJyYXkuZnJvbShyKSA6IFwiQXJndW1lbnRzXCIgPT09IHQgfHwgL14oPzpVaXxJKW50KD86OHwxNnwzMikoPzpDbGFtcGVkKT9BcnJheSQvLnRlc3QodCkgPyBfYXJyYXlMaWtlVG9BcnJheShyLCBhKSA6IHZvaWQgMDsgfSB9XG5mdW5jdGlvbiBfYXJyYXlMaWtlVG9BcnJheShyLCBhKSB7IChudWxsID09IGEgfHwgYSA+IHIubGVuZ3RoKSAmJiAoYSA9IHIubGVuZ3RoKTsgZm9yICh2YXIgZSA9IDAsIG4gPSBBcnJheShhKTsgZSA8IGE7IGUrKykgbltlXSA9IHJbZV07IHJldHVybiBuOyB9XG5mdW5jdGlvbiBfaXRlcmFibGVUb0FycmF5TGltaXQociwgbCkgeyB2YXIgdCA9IG51bGwgPT0gciA/IG51bGwgOiBcInVuZGVmaW5lZFwiICE9IHR5cGVvZiBTeW1ib2wgJiYgcltTeW1ib2wuaXRlcmF0b3JdIHx8IHJbXCJAQGl0ZXJhdG9yXCJdOyBpZiAobnVsbCAhPSB0KSB7IHZhciBlLCBuLCBpLCB1LCBhID0gW10sIGYgPSB0cnVlLCBvID0gZmFsc2U7IHRyeSB7IGlmIChpID0gKHQgPSB0LmNhbGwocikpLm5leHQsIDAgPT09IGwpIHsgaWYgKE9iamVjdCh0KSAhPT0gdCkgcmV0dXJuOyBmID0gITE7IH0gZWxzZSBmb3IgKDsgIShmID0gKGUgPSBpLmNhbGwodCkpLmRvbmUpICYmIChhLnB1c2goZS52YWx1ZSksIGEubGVuZ3RoICE9PSBsKTsgZiA9ICEwKTsgfSBjYXRjaCAocikgeyBvID0gdHJ1ZSwgbiA9IHI7IH0gZmluYWxseSB7IHRyeSB7IGlmICghZiAmJiBudWxsICE9IHRbXCJyZXR1cm5cIl0gJiYgKHUgPSB0W1wicmV0dXJuXCJdKCksIE9iamVjdCh1KSAhPT0gdSkpIHJldHVybjsgfSBmaW5hbGx5IHsgaWYgKG8pIHRocm93IG47IH0gfSByZXR1cm4gYTsgfSB9XG5mdW5jdGlvbiBfYXJyYXlXaXRoSG9sZXMocikgeyBpZiAoQXJyYXkuaXNBcnJheShyKSkgcmV0dXJuIHI7IH1cbmZ1bmN0aW9uIG93bktleXMoZSwgcikgeyB2YXIgdCA9IE9iamVjdC5rZXlzKGUpOyBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykgeyB2YXIgbyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoZSk7IHIgJiYgKG8gPSBvLmZpbHRlcihmdW5jdGlvbiAocikgeyByZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihlLCByKS5lbnVtZXJhYmxlOyB9KSksIHQucHVzaC5hcHBseSh0LCBvKTsgfSByZXR1cm4gdDsgfVxuZnVuY3Rpb24gX29iamVjdFNwcmVhZChlKSB7IGZvciAodmFyIHIgPSAxOyByIDwgYXJndW1lbnRzLmxlbmd0aDsgcisrKSB7IHZhciB0ID0gbnVsbCAhPSBhcmd1bWVudHNbcl0gPyBhcmd1bWVudHNbcl0gOiB7fTsgciAlIDIgPyBvd25LZXlzKE9iamVjdCh0KSwgdHJ1ZSkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBfZGVmaW5lUHJvcGVydHkoZSwgciwgdFtyXSk7IH0pIDogT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnMgPyBPYmplY3QuZGVmaW5lUHJvcGVydGllcyhlLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyh0KSkgOiBvd25LZXlzKE9iamVjdCh0KSkuZm9yRWFjaChmdW5jdGlvbiAocikgeyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcih0LCByKSk7IH0pOyB9IHJldHVybiBlOyB9XG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkoZSwgciwgdCkgeyByZXR1cm4gKHIgPSBfdG9Qcm9wZXJ0eUtleShyKSkgaW4gZSA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCB7IHZhbHVlOiB0LCBlbnVtZXJhYmxlOiB0cnVlLCBjb25maWd1cmFibGU6IHRydWUsIHdyaXRhYmxlOiB0cnVlIH0pIDogZVtyXSA9IHQsIGU7IH1cbmZ1bmN0aW9uIF90b1Byb3BlcnR5S2V5KHQpIHsgdmFyIGkgPSBfdG9QcmltaXRpdmUodCwgXCJzdHJpbmdcIik7IHJldHVybiBcInN5bWJvbFwiID09IF90eXBlb2YoaSkgPyBpIDogaSArIFwiXCI7IH1cbmZ1bmN0aW9uIF90b1ByaW1pdGl2ZSh0LCByKSB7IGlmIChcIm9iamVjdFwiICE9IF90eXBlb2YodCkgfHwgIXQpIHJldHVybiB0OyB2YXIgZSA9IHRbU3ltYm9sLnRvUHJpbWl0aXZlXTsgaWYgKHZvaWQgMCAhPT0gZSkgeyB2YXIgaSA9IGUuY2FsbCh0LCByKTsgaWYgKFwib2JqZWN0XCIgIT0gX3R5cGVvZihpKSkgcmV0dXJuIGk7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJAQHRvUHJpbWl0aXZlIG11c3QgcmV0dXJuIGEgcHJpbWl0aXZlIHZhbHVlLlwiKTsgfSByZXR1cm4gKFwic3RyaW5nXCIgPT09IHIgPyBTdHJpbmcgOiBOdW1iZXIpKHQpOyB9XG52YXIgc2NyaXB0ID0ge1xuICBuYW1lOiAnQmFzZUNvbXBvbmVudCcsXG4gIHByb3BzOiB7XG4gICAgcHQ6IHtcbiAgICAgIHR5cGU6IE9iamVjdCxcbiAgICAgIFwiZGVmYXVsdFwiOiB1bmRlZmluZWRcbiAgICB9LFxuICAgIHB0T3B0aW9uczoge1xuICAgICAgdHlwZTogT2JqZWN0LFxuICAgICAgXCJkZWZhdWx0XCI6IHVuZGVmaW5lZFxuICAgIH0sXG4gICAgdW5zdHlsZWQ6IHtcbiAgICAgIHR5cGU6IEJvb2xlYW4sXG4gICAgICBcImRlZmF1bHRcIjogdW5kZWZpbmVkXG4gICAgfSxcbiAgICBkdDoge1xuICAgICAgdHlwZTogT2JqZWN0LFxuICAgICAgXCJkZWZhdWx0XCI6IHVuZGVmaW5lZFxuICAgIH1cbiAgfSxcbiAgaW5qZWN0OiB7XG4gICAgJHBhcmVudEluc3RhbmNlOiB7XG4gICAgICBcImRlZmF1bHRcIjogdW5kZWZpbmVkXG4gICAgfVxuICB9LFxuICB3YXRjaDoge1xuICAgIGlzVW5zdHlsZWQ6IHtcbiAgICAgIGltbWVkaWF0ZTogdHJ1ZSxcbiAgICAgIGhhbmRsZXI6IGZ1bmN0aW9uIGhhbmRsZXIobmV3VmFsdWUpIHtcbiAgICAgICAgVGhlbWVTZXJ2aWNlLm9mZigndGhlbWU6Y2hhbmdlJywgdGhpcy5fbG9hZENvcmVTdHlsZXMpO1xuICAgICAgICBpZiAoIW5ld1ZhbHVlKSB7XG4gICAgICAgICAgdGhpcy5fbG9hZENvcmVTdHlsZXMoKTtcbiAgICAgICAgICB0aGlzLl90aGVtZUNoYW5nZUxpc3RlbmVyKHRoaXMuX2xvYWRDb3JlU3R5bGVzKTsgLy8gdXBkYXRlIHN0eWxlcyB3aXRoIHRoZW1lIHNldHRpbmdzXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIGR0OiB7XG4gICAgICBpbW1lZGlhdGU6IHRydWUsXG4gICAgICBoYW5kbGVyOiBmdW5jdGlvbiBoYW5kbGVyKG5ld1ZhbHVlLCBvbGRWYWx1ZSkge1xuICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuICAgICAgICBUaGVtZVNlcnZpY2Uub2ZmKCd0aGVtZTpjaGFuZ2UnLCB0aGlzLl90aGVtZVNjb3BlZExpc3RlbmVyKTtcbiAgICAgICAgaWYgKG5ld1ZhbHVlKSB7XG4gICAgICAgICAgdGhpcy5fbG9hZFNjb3BlZFRoZW1lU3R5bGVzKG5ld1ZhbHVlKTtcbiAgICAgICAgICB0aGlzLl90aGVtZVNjb3BlZExpc3RlbmVyID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgcmV0dXJuIF90aGlzLl9sb2FkU2NvcGVkVGhlbWVTdHlsZXMobmV3VmFsdWUpO1xuICAgICAgICAgIH07XG4gICAgICAgICAgdGhpcy5fdGhlbWVDaGFuZ2VMaXN0ZW5lcih0aGlzLl90aGVtZVNjb3BlZExpc3RlbmVyKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aGlzLl91bmxvYWRTY29wZWRUaGVtZVN0eWxlcygpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9LFxuICBzY29wZWRTdHlsZUVsOiB1bmRlZmluZWQsXG4gIHVpZDogdW5kZWZpbmVkLFxuICAkYXR0clNlbGVjdG9yOiB1bmRlZmluZWQsXG4gIGJlZm9yZUNyZWF0ZTogZnVuY3Rpb24gYmVmb3JlQ3JlYXRlKCkge1xuICAgIHZhciBfdGhpcyRwdCwgX3RoaXMkcHQyLCBfdGhpcyRwdDMsIF9yZWYsIF9yZWYkb25CZWZvcmVDcmVhdGUsIF90aGlzJCRwcmltZXZ1ZUNvbmZpZywgX3RoaXMkJHByaW1ldnVlLCBfdGhpcyQkcHJpbWV2dWUyLCBfdGhpcyQkcHJpbWV2dWUzLCBfcmVmMiwgX3JlZjIkb25CZWZvcmVDcmVhdGU7XG4gICAgdmFyIF91c2VwdCA9IChfdGhpcyRwdCA9IHRoaXMucHQpID09PSBudWxsIHx8IF90aGlzJHB0ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfdGhpcyRwdFsnX3VzZXB0J107XG4gICAgdmFyIG9yaWdpbmFsVmFsdWUgPSBfdXNlcHQgPyAoX3RoaXMkcHQyID0gdGhpcy5wdCkgPT09IG51bGwgfHwgX3RoaXMkcHQyID09PSB2b2lkIDAgfHwgKF90aGlzJHB0MiA9IF90aGlzJHB0Mi5vcmlnaW5hbFZhbHVlKSA9PT0gbnVsbCB8fCBfdGhpcyRwdDIgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF90aGlzJHB0Mlt0aGlzLiQudHlwZS5uYW1lXSA6IHVuZGVmaW5lZDtcbiAgICB2YXIgdmFsdWUgPSBfdXNlcHQgPyAoX3RoaXMkcHQzID0gdGhpcy5wdCkgPT09IG51bGwgfHwgX3RoaXMkcHQzID09PSB2b2lkIDAgfHwgKF90aGlzJHB0MyA9IF90aGlzJHB0My52YWx1ZSkgPT09IG51bGwgfHwgX3RoaXMkcHQzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfdGhpcyRwdDNbdGhpcy4kLnR5cGUubmFtZV0gOiB0aGlzLnB0O1xuICAgIChfcmVmID0gdmFsdWUgfHwgb3JpZ2luYWxWYWx1ZSkgPT09IG51bGwgfHwgX3JlZiA9PT0gdm9pZCAwIHx8IChfcmVmID0gX3JlZi5ob29rcykgPT09IG51bGwgfHwgX3JlZiA9PT0gdm9pZCAwIHx8IChfcmVmJG9uQmVmb3JlQ3JlYXRlID0gX3JlZlsnb25CZWZvcmVDcmVhdGUnXSkgPT09IG51bGwgfHwgX3JlZiRvbkJlZm9yZUNyZWF0ZSA9PT0gdm9pZCAwIHx8IF9yZWYkb25CZWZvcmVDcmVhdGUuY2FsbChfcmVmKTtcbiAgICB2YXIgX3VzZXB0SW5Db25maWcgPSAoX3RoaXMkJHByaW1ldnVlQ29uZmlnID0gdGhpcy4kcHJpbWV2dWVDb25maWcpID09PSBudWxsIHx8IF90aGlzJCRwcmltZXZ1ZUNvbmZpZyA9PT0gdm9pZCAwIHx8IChfdGhpcyQkcHJpbWV2dWVDb25maWcgPSBfdGhpcyQkcHJpbWV2dWVDb25maWcucHQpID09PSBudWxsIHx8IF90aGlzJCRwcmltZXZ1ZUNvbmZpZyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX3RoaXMkJHByaW1ldnVlQ29uZmlnWydfdXNlcHQnXTtcbiAgICB2YXIgb3JpZ2luYWxWYWx1ZUluQ29uZmlnID0gX3VzZXB0SW5Db25maWcgPyAoX3RoaXMkJHByaW1ldnVlID0gdGhpcy4kcHJpbWV2dWUpID09PSBudWxsIHx8IF90aGlzJCRwcmltZXZ1ZSA9PT0gdm9pZCAwIHx8IChfdGhpcyQkcHJpbWV2dWUgPSBfdGhpcyQkcHJpbWV2dWUuY29uZmlnKSA9PT0gbnVsbCB8fCBfdGhpcyQkcHJpbWV2dWUgPT09IHZvaWQgMCB8fCAoX3RoaXMkJHByaW1ldnVlID0gX3RoaXMkJHByaW1ldnVlLnB0KSA9PT0gbnVsbCB8fCBfdGhpcyQkcHJpbWV2dWUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF90aGlzJCRwcmltZXZ1ZS5vcmlnaW5hbFZhbHVlIDogdW5kZWZpbmVkO1xuICAgIHZhciB2YWx1ZUluQ29uZmlnID0gX3VzZXB0SW5Db25maWcgPyAoX3RoaXMkJHByaW1ldnVlMiA9IHRoaXMuJHByaW1ldnVlKSA9PT0gbnVsbCB8fCBfdGhpcyQkcHJpbWV2dWUyID09PSB2b2lkIDAgfHwgKF90aGlzJCRwcmltZXZ1ZTIgPSBfdGhpcyQkcHJpbWV2dWUyLmNvbmZpZykgPT09IG51bGwgfHwgX3RoaXMkJHByaW1ldnVlMiA9PT0gdm9pZCAwIHx8IChfdGhpcyQkcHJpbWV2dWUyID0gX3RoaXMkJHByaW1ldnVlMi5wdCkgPT09IG51bGwgfHwgX3RoaXMkJHByaW1ldnVlMiA9PT0gdm9pZCAwID8gdm9pZCAwIDogX3RoaXMkJHByaW1ldnVlMi52YWx1ZSA6IChfdGhpcyQkcHJpbWV2dWUzID0gdGhpcy4kcHJpbWV2dWUpID09PSBudWxsIHx8IF90aGlzJCRwcmltZXZ1ZTMgPT09IHZvaWQgMCB8fCAoX3RoaXMkJHByaW1ldnVlMyA9IF90aGlzJCRwcmltZXZ1ZTMuY29uZmlnKSA9PT0gbnVsbCB8fCBfdGhpcyQkcHJpbWV2dWUzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfdGhpcyQkcHJpbWV2dWUzLnB0O1xuICAgIChfcmVmMiA9IHZhbHVlSW5Db25maWcgfHwgb3JpZ2luYWxWYWx1ZUluQ29uZmlnKSA9PT0gbnVsbCB8fCBfcmVmMiA9PT0gdm9pZCAwIHx8IChfcmVmMiA9IF9yZWYyW3RoaXMuJC50eXBlLm5hbWVdKSA9PT0gbnVsbCB8fCBfcmVmMiA9PT0gdm9pZCAwIHx8IChfcmVmMiA9IF9yZWYyLmhvb2tzKSA9PT0gbnVsbCB8fCBfcmVmMiA9PT0gdm9pZCAwIHx8IChfcmVmMiRvbkJlZm9yZUNyZWF0ZSA9IF9yZWYyWydvbkJlZm9yZUNyZWF0ZSddKSA9PT0gbnVsbCB8fCBfcmVmMiRvbkJlZm9yZUNyZWF0ZSA9PT0gdm9pZCAwIHx8IF9yZWYyJG9uQmVmb3JlQ3JlYXRlLmNhbGwoX3JlZjIpO1xuICAgIHRoaXMuJGF0dHJTZWxlY3RvciA9IHVzZUF0dHJTZWxlY3RvcigpO1xuICAgIHRoaXMudWlkID0gdGhpcy4kYXR0cnMuaWQgfHwgdGhpcy4kYXR0clNlbGVjdG9yLnJlcGxhY2UoJ3BjJywgJ3B2X2lkXycpO1xuICB9LFxuICBjcmVhdGVkOiBmdW5jdGlvbiBjcmVhdGVkKCkge1xuICAgIHRoaXMuX2hvb2soJ29uQ3JlYXRlZCcpO1xuICB9LFxuICBiZWZvcmVNb3VudDogZnVuY3Rpb24gYmVmb3JlTW91bnQoKSB7XG4gICAgdGhpcy5fbG9hZFN0eWxlcygpO1xuICAgIHRoaXMuX2hvb2soJ29uQmVmb3JlTW91bnQnKTtcbiAgfSxcbiAgbW91bnRlZDogZnVuY3Rpb24gbW91bnRlZCgpIHtcbiAgICB2YXIgX3RoaXMkJHByaW1ldnVlJHZlcmlmO1xuICAgIHRoaXMuX2hvb2soJ29uTW91bnRlZCcpO1xuICAgIGlmICghdGhpcy4kcHJpbWV2dWUgfHwgKChfdGhpcyQkcHJpbWV2dWUkdmVyaWYgPSB0aGlzLiRwcmltZXZ1ZS52ZXJpZmllZCkgPT09IG51bGwgfHwgX3RoaXMkJHByaW1ldnVlJHZlcmlmID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfdGhpcyQkcHJpbWV2dWUkdmVyaWYudmFsdWUpID09PSBmYWxzZSkge1xuICAgICAgc2hvd0ludmFsaWRMaWNlbnNlQmFubmVyKCk7XG4gICAgfVxuICB9LFxuICBiZWZvcmVVcGRhdGU6IGZ1bmN0aW9uIGJlZm9yZVVwZGF0ZSgpIHtcbiAgICB0aGlzLl9ob29rKCdvbkJlZm9yZVVwZGF0ZScpO1xuICB9LFxuICB1cGRhdGVkOiBmdW5jdGlvbiB1cGRhdGVkKCkge1xuICAgIHRoaXMuX2hvb2soJ29uVXBkYXRlZCcpO1xuICB9LFxuICBiZWZvcmVVbm1vdW50OiBmdW5jdGlvbiBiZWZvcmVVbm1vdW50KCkge1xuICAgIHRoaXMuX2hvb2soJ29uQmVmb3JlVW5tb3VudCcpO1xuICB9LFxuICB1bm1vdW50ZWQ6IGZ1bmN0aW9uIHVubW91bnRlZCgpIHtcbiAgICB0aGlzLl9yZW1vdmVUaGVtZUxpc3RlbmVycygpO1xuICAgIHRoaXMuX3VubG9hZFNjb3BlZFRoZW1lU3R5bGVzKCk7XG4gICAgdGhpcy5faG9vaygnb25Vbm1vdW50ZWQnKTtcbiAgfSxcbiAgbWV0aG9kczoge1xuICAgIF9ob29rOiBmdW5jdGlvbiBfaG9vayhob29rTmFtZSkge1xuICAgICAgaWYgKCF0aGlzLiRvcHRpb25zLmhvc3ROYW1lKSB7XG4gICAgICAgIHZhciBzZWxmSG9vayA9IHRoaXMuX3VzZVBUKHRoaXMuX2dldFBUKHRoaXMucHQsIHRoaXMuJC50eXBlLm5hbWUpLCB0aGlzLl9nZXRPcHRpb25WYWx1ZSwgXCJob29rcy5cIi5jb25jYXQoaG9va05hbWUpKTtcbiAgICAgICAgdmFyIGRlZmF1bHRIb29rID0gdGhpcy5fdXNlRGVmYXVsdFBUKHRoaXMuX2dldE9wdGlvblZhbHVlLCBcImhvb2tzLlwiLmNvbmNhdChob29rTmFtZSkpO1xuICAgICAgICBzZWxmSG9vayA9PT0gbnVsbCB8fCBzZWxmSG9vayA9PT0gdm9pZCAwIHx8IHNlbGZIb29rKCk7XG4gICAgICAgIGRlZmF1bHRIb29rID09PSBudWxsIHx8IGRlZmF1bHRIb29rID09PSB2b2lkIDAgfHwgZGVmYXVsdEhvb2soKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIF9tZXJnZVByb3BzOiBmdW5jdGlvbiBfbWVyZ2VQcm9wcyhmbikge1xuICAgICAgZm9yICh2YXIgX2xlbiA9IGFyZ3VtZW50cy5sZW5ndGgsIGFyZ3MgPSBuZXcgQXJyYXkoX2xlbiA+IDEgPyBfbGVuIC0gMSA6IDApLCBfa2V5MiA9IDE7IF9rZXkyIDwgX2xlbjsgX2tleTIrKykge1xuICAgICAgICBhcmdzW19rZXkyIC0gMV0gPSBhcmd1bWVudHNbX2tleTJdO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGlzRnVuY3Rpb24oZm4pID8gZm4uYXBwbHkodm9pZCAwLCBhcmdzKSA6IG1lcmdlUHJvcHMuYXBwbHkodm9pZCAwLCBhcmdzKTtcbiAgICB9LFxuICAgIF9sb2FkOiBmdW5jdGlvbiBfbG9hZCgpIHtcbiAgICAgIC8vIEB0b2RvXG4gICAgICBpZiAoIUJhc2UuaXNTdHlsZU5hbWVMb2FkZWQoJ2Jhc2UnKSkge1xuICAgICAgICBCYXNlU3R5bGUubG9hZENTUyh0aGlzLiRzdHlsZU9wdGlvbnMpO1xuICAgICAgICB0aGlzLl9sb2FkR2xvYmFsU3R5bGVzKCk7XG4gICAgICAgIEJhc2Uuc2V0TG9hZGVkU3R5bGVOYW1lKCdiYXNlJyk7XG4gICAgICB9XG4gICAgICB0aGlzLl9sb2FkVGhlbWVTdHlsZXMoKTtcbiAgICB9LFxuICAgIF9sb2FkU3R5bGVzOiBmdW5jdGlvbiBfbG9hZFN0eWxlcygpIHtcbiAgICAgIHRoaXMuX2xvYWQoKTtcbiAgICAgIHRoaXMuX3RoZW1lQ2hhbmdlTGlzdGVuZXIodGhpcy5fbG9hZCk7XG4gICAgfSxcbiAgICBfbG9hZENvcmVTdHlsZXM6IGZ1bmN0aW9uIF9sb2FkQ29yZVN0eWxlcygpIHtcbiAgICAgIHZhciBfdGhpcyQkc3R5bGUsIF90aGlzJCRzdHlsZTI7XG4gICAgICBpZiAoIUJhc2UuaXNTdHlsZU5hbWVMb2FkZWQoKF90aGlzJCRzdHlsZSA9IHRoaXMuJHN0eWxlKSA9PT0gbnVsbCB8fCBfdGhpcyQkc3R5bGUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF90aGlzJCRzdHlsZS5uYW1lKSAmJiAoX3RoaXMkJHN0eWxlMiA9IHRoaXMuJHN0eWxlKSAhPT0gbnVsbCAmJiBfdGhpcyQkc3R5bGUyICE9PSB2b2lkIDAgJiYgX3RoaXMkJHN0eWxlMi5uYW1lKSB7XG4gICAgICAgIEJhc2VDb21wb25lbnRTdHlsZS5sb2FkQ1NTKHRoaXMuJHN0eWxlT3B0aW9ucyk7XG4gICAgICAgIHRoaXMuJG9wdGlvbnMuc3R5bGUgJiYgdGhpcy4kc3R5bGUubG9hZENTUyh0aGlzLiRzdHlsZU9wdGlvbnMpO1xuICAgICAgICBCYXNlLnNldExvYWRlZFN0eWxlTmFtZSh0aGlzLiRzdHlsZS5uYW1lKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIF9sb2FkR2xvYmFsU3R5bGVzOiBmdW5jdGlvbiBfbG9hZEdsb2JhbFN0eWxlcygpIHtcbiAgICAgIC8qXG4gICAgICAgKiBAdG9kbyBBZGQgc2VsZiBjdXN0b20gY3NzIHN1cHBvcnQ7XG4gICAgICAgKiA8UGFuZWwgOnB0PVwieyBjc3M6IGAuLi5gIH1cIiAuLi4vPlxuICAgICAgICpcbiAgICAgICAqIGNvbnN0IHNlbGZDU1MgPSB0aGlzLl9nZXRQVENsYXNzVmFsdWUodGhpcy5wdCwgJ2NzcycsIHRoaXMuJHBhcmFtcyk7XG4gICAgICAgKiBjb25zdCBkZWZhdWx0Q1NTID0gdGhpcy5fZ2V0UFRDbGFzc1ZhbHVlKHRoaXMuZGVmYXVsdFBULCAnY3NzJywgdGhpcy4kcGFyYW1zKTtcbiAgICAgICAqIGNvbnN0IG1lcmdlZENTUyA9IG1lcmdlUHJvcHMoc2VsZkNTUywgZGVmYXVsdENTUyk7XG4gICAgICAgKiBpc05vdEVtcHR5KG1lcmdlZENTUz8uY2xhc3MpICYmIHRoaXMuJGNzcy5sb2FkQ3VzdG9tU3R5bGUobWVyZ2VkQ1NTPy5jbGFzcyk7XG4gICAgICAgKi9cblxuICAgICAgdmFyIGdsb2JhbENTUyA9IHRoaXMuX3VzZUdsb2JhbFBUKHRoaXMuX2dldE9wdGlvblZhbHVlLCAnZ2xvYmFsLmNzcycsIHRoaXMuJHBhcmFtcyk7XG4gICAgICBpc05vdEVtcHR5KGdsb2JhbENTUykgJiYgQmFzZVN0eWxlLmxvYWQoZ2xvYmFsQ1NTLCBfb2JqZWN0U3ByZWFkKHtcbiAgICAgICAgbmFtZTogJ2dsb2JhbCdcbiAgICAgIH0sIHRoaXMuJHN0eWxlT3B0aW9ucykpO1xuICAgIH0sXG4gICAgX2xvYWRUaGVtZVN0eWxlczogZnVuY3Rpb24gX2xvYWRUaGVtZVN0eWxlcygpIHtcbiAgICAgIHZhciBfdGhpcyQkc3R5bGU0LCBfdGhpcyQkc3R5bGU1O1xuICAgICAgaWYgKHRoaXMuaXNVbnN0eWxlZCB8fCB0aGlzLiR0aGVtZSA9PT0gJ25vbmUnKSByZXR1cm47XG5cbiAgICAgIC8vIGNvbW1vblxuICAgICAgaWYgKCFUaGVtZS5pc1N0eWxlTmFtZUxvYWRlZCgnY29tbW9uJykpIHtcbiAgICAgICAgdmFyIF90aGlzJCRzdHlsZTMsIF90aGlzJCRzdHlsZTMkZ2V0Q29tbTtcbiAgICAgICAgdmFyIF9yZWYzID0gKChfdGhpcyQkc3R5bGUzID0gdGhpcy4kc3R5bGUpID09PSBudWxsIHx8IF90aGlzJCRzdHlsZTMgPT09IHZvaWQgMCB8fCAoX3RoaXMkJHN0eWxlMyRnZXRDb21tID0gX3RoaXMkJHN0eWxlMy5nZXRDb21tb25UaGVtZSkgPT09IG51bGwgfHwgX3RoaXMkJHN0eWxlMyRnZXRDb21tID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfdGhpcyQkc3R5bGUzJGdldENvbW0uY2FsbChfdGhpcyQkc3R5bGUzKSkgfHwge30sXG4gICAgICAgICAgcHJpbWl0aXZlID0gX3JlZjMucHJpbWl0aXZlLFxuICAgICAgICAgIHNlbWFudGljID0gX3JlZjMuc2VtYW50aWMsXG4gICAgICAgICAgZ2xvYmFsID0gX3JlZjMuZ2xvYmFsLFxuICAgICAgICAgIHN0eWxlID0gX3JlZjMuc3R5bGU7XG4gICAgICAgIEJhc2VTdHlsZS5sb2FkKHByaW1pdGl2ZSA9PT0gbnVsbCB8fCBwcmltaXRpdmUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHByaW1pdGl2ZS5jc3MsIF9vYmplY3RTcHJlYWQoe1xuICAgICAgICAgIG5hbWU6ICdwcmltaXRpdmUtdmFyaWFibGVzJ1xuICAgICAgICB9LCB0aGlzLiRzdHlsZU9wdGlvbnMpKTtcbiAgICAgICAgQmFzZVN0eWxlLmxvYWQoc2VtYW50aWMgPT09IG51bGwgfHwgc2VtYW50aWMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHNlbWFudGljLmNzcywgX29iamVjdFNwcmVhZCh7XG4gICAgICAgICAgbmFtZTogJ3NlbWFudGljLXZhcmlhYmxlcydcbiAgICAgICAgfSwgdGhpcy4kc3R5bGVPcHRpb25zKSk7XG4gICAgICAgIEJhc2VTdHlsZS5sb2FkKGdsb2JhbCA9PT0gbnVsbCB8fCBnbG9iYWwgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGdsb2JhbC5jc3MsIF9vYmplY3RTcHJlYWQoe1xuICAgICAgICAgIG5hbWU6ICdnbG9iYWwtdmFyaWFibGVzJ1xuICAgICAgICB9LCB0aGlzLiRzdHlsZU9wdGlvbnMpKTtcbiAgICAgICAgQmFzZVN0eWxlLmxvYWRTdHlsZShfb2JqZWN0U3ByZWFkKHtcbiAgICAgICAgICBuYW1lOiAnZ2xvYmFsLXN0eWxlJ1xuICAgICAgICB9LCB0aGlzLiRzdHlsZU9wdGlvbnMpLCBzdHlsZSk7XG4gICAgICAgIFRoZW1lLnNldExvYWRlZFN0eWxlTmFtZSgnY29tbW9uJyk7XG4gICAgICB9XG5cbiAgICAgIC8vIGNvbXBvbmVudFxuICAgICAgaWYgKCFUaGVtZS5pc1N0eWxlTmFtZUxvYWRlZCgoX3RoaXMkJHN0eWxlNCA9IHRoaXMuJHN0eWxlKSA9PT0gbnVsbCB8fCBfdGhpcyQkc3R5bGU0ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfdGhpcyQkc3R5bGU0Lm5hbWUpICYmIChfdGhpcyQkc3R5bGU1ID0gdGhpcy4kc3R5bGUpICE9PSBudWxsICYmIF90aGlzJCRzdHlsZTUgIT09IHZvaWQgMCAmJiBfdGhpcyQkc3R5bGU1Lm5hbWUpIHtcbiAgICAgICAgdmFyIF90aGlzJCRzdHlsZTYsIF90aGlzJCRzdHlsZTYkZ2V0Q29tcCwgX3RoaXMkJHN0eWxlNywgX3RoaXMkJHN0eWxlODtcbiAgICAgICAgdmFyIF9yZWY0ID0gKChfdGhpcyQkc3R5bGU2ID0gdGhpcy4kc3R5bGUpID09PSBudWxsIHx8IF90aGlzJCRzdHlsZTYgPT09IHZvaWQgMCB8fCAoX3RoaXMkJHN0eWxlNiRnZXRDb21wID0gX3RoaXMkJHN0eWxlNi5nZXRDb21wb25lbnRUaGVtZSkgPT09IG51bGwgfHwgX3RoaXMkJHN0eWxlNiRnZXRDb21wID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfdGhpcyQkc3R5bGU2JGdldENvbXAuY2FsbChfdGhpcyQkc3R5bGU2KSkgfHwge30sXG4gICAgICAgICAgY3NzID0gX3JlZjQuY3NzLFxuICAgICAgICAgIF9zdHlsZSA9IF9yZWY0LnN0eWxlO1xuICAgICAgICAoX3RoaXMkJHN0eWxlNyA9IHRoaXMuJHN0eWxlKSA9PT0gbnVsbCB8fCBfdGhpcyQkc3R5bGU3ID09PSB2b2lkIDAgfHwgX3RoaXMkJHN0eWxlNy5sb2FkKGNzcywgX29iamVjdFNwcmVhZCh7XG4gICAgICAgICAgbmFtZTogXCJcIi5jb25jYXQodGhpcy4kc3R5bGUubmFtZSwgXCItdmFyaWFibGVzXCIpXG4gICAgICAgIH0sIHRoaXMuJHN0eWxlT3B0aW9ucykpO1xuICAgICAgICAoX3RoaXMkJHN0eWxlOCA9IHRoaXMuJHN0eWxlKSA9PT0gbnVsbCB8fCBfdGhpcyQkc3R5bGU4ID09PSB2b2lkIDAgfHwgX3RoaXMkJHN0eWxlOC5sb2FkU3R5bGUoX29iamVjdFNwcmVhZCh7XG4gICAgICAgICAgbmFtZTogXCJcIi5jb25jYXQodGhpcy4kc3R5bGUubmFtZSwgXCItc3R5bGVcIilcbiAgICAgICAgfSwgdGhpcy4kc3R5bGVPcHRpb25zKSwgX3N0eWxlKTtcbiAgICAgICAgVGhlbWUuc2V0TG9hZGVkU3R5bGVOYW1lKHRoaXMuJHN0eWxlLm5hbWUpO1xuICAgICAgfVxuXG4gICAgICAvLyBsYXllciBvcmRlclxuICAgICAgaWYgKCFUaGVtZS5pc1N0eWxlTmFtZUxvYWRlZCgnbGF5ZXItb3JkZXInKSkge1xuICAgICAgICB2YXIgX3RoaXMkJHN0eWxlOSwgX3RoaXMkJHN0eWxlOSRnZXRMYXllO1xuICAgICAgICB2YXIgbGF5ZXJPcmRlciA9IChfdGhpcyQkc3R5bGU5ID0gdGhpcy4kc3R5bGUpID09PSBudWxsIHx8IF90aGlzJCRzdHlsZTkgPT09IHZvaWQgMCB8fCAoX3RoaXMkJHN0eWxlOSRnZXRMYXllID0gX3RoaXMkJHN0eWxlOS5nZXRMYXllck9yZGVyVGhlbWVDU1MpID09PSBudWxsIHx8IF90aGlzJCRzdHlsZTkkZ2V0TGF5ZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogX3RoaXMkJHN0eWxlOSRnZXRMYXllLmNhbGwoX3RoaXMkJHN0eWxlOSk7XG4gICAgICAgIEJhc2VTdHlsZS5sb2FkKGxheWVyT3JkZXIsIF9vYmplY3RTcHJlYWQoe1xuICAgICAgICAgIG5hbWU6ICdsYXllci1vcmRlcicsXG4gICAgICAgICAgZmlyc3Q6IHRydWVcbiAgICAgICAgfSwgdGhpcy4kc3R5bGVPcHRpb25zKSk7XG4gICAgICAgIFRoZW1lLnNldExvYWRlZFN0eWxlTmFtZSgnbGF5ZXItb3JkZXInKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIF9sb2FkU2NvcGVkVGhlbWVTdHlsZXM6IGZ1bmN0aW9uIF9sb2FkU2NvcGVkVGhlbWVTdHlsZXMocHJlc2V0KSB7XG4gICAgICB2YXIgX3RoaXMkJHRoZW1lLCBfdGhpcyQkc3R5bGUwLCBfdGhpcyQkc3R5bGUxLCBfdGhpcyQkc3R5bGUxJGdldFByZXMsIF90aGlzJCRzdHlsZTEwO1xuICAgICAgaWYgKCgoX3RoaXMkJHRoZW1lID0gdGhpcy4kdGhlbWUpID09PSBudWxsIHx8IF90aGlzJCR0aGVtZSA9PT0gdm9pZCAwIHx8IChfdGhpcyQkdGhlbWUgPSBfdGhpcyQkdGhlbWUub3B0aW9ucykgPT09IG51bGwgfHwgX3RoaXMkJHRoZW1lID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfdGhpcyQkdGhlbWUuY3NzVmFyaWFibGVzKSA9PT0gZmFsc2UgJiYgKF90aGlzJCRzdHlsZTAgPSB0aGlzLiRzdHlsZSkgIT09IG51bGwgJiYgX3RoaXMkJHN0eWxlMCAhPT0gdm9pZCAwICYmIF90aGlzJCRzdHlsZTAubmFtZSkge1xuICAgICAgICB2YXIgYWRkZWQgPSBUaGVtZS5hZGRTY29wZWRUb2tlbihfZGVmaW5lUHJvcGVydHkoe30sIHRoaXMuJHN0eWxlLm5hbWUsIHByZXNldCkpO1xuICAgICAgICBpZiAoYWRkZWQpIHtcbiAgICAgICAgICBUaGVtZS5kZWxldGVMb2FkZWRTdHlsZU5hbWUodGhpcy4kc3R5bGUubmFtZSk7XG4gICAgICAgICAgdGhpcy5fbG9hZFRoZW1lU3R5bGVzKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHZhciBfcmVmNSA9ICgoX3RoaXMkJHN0eWxlMSA9IHRoaXMuJHN0eWxlKSA9PT0gbnVsbCB8fCBfdGhpcyQkc3R5bGUxID09PSB2b2lkIDAgfHwgKF90aGlzJCRzdHlsZTEkZ2V0UHJlcyA9IF90aGlzJCRzdHlsZTEuZ2V0UHJlc2V0VGhlbWUpID09PSBudWxsIHx8IF90aGlzJCRzdHlsZTEkZ2V0UHJlcyA9PT0gdm9pZCAwID8gdm9pZCAwIDogX3RoaXMkJHN0eWxlMSRnZXRQcmVzLmNhbGwoX3RoaXMkJHN0eWxlMSwgcHJlc2V0LCBcIltcIi5jb25jYXQodGhpcy4kYXR0clNlbGVjdG9yLCBcIl1cIikpKSB8fCB7fSxcbiAgICAgICAgY3NzID0gX3JlZjUuY3NzO1xuICAgICAgdmFyIHNjb3BlZFN0eWxlID0gKF90aGlzJCRzdHlsZTEwID0gdGhpcy4kc3R5bGUpID09PSBudWxsIHx8IF90aGlzJCRzdHlsZTEwID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfdGhpcyQkc3R5bGUxMC5sb2FkKGNzcywgX29iamVjdFNwcmVhZCh7XG4gICAgICAgIG5hbWU6IFwiXCIuY29uY2F0KHRoaXMuJGF0dHJTZWxlY3RvciwgXCItXCIpLmNvbmNhdCh0aGlzLiRzdHlsZS5uYW1lKVxuICAgICAgfSwgdGhpcy4kc3R5bGVPcHRpb25zKSk7XG4gICAgICB0aGlzLnNjb3BlZFN0eWxlRWwgPSBzY29wZWRTdHlsZSA9PT0gbnVsbCB8fCBzY29wZWRTdHlsZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogc2NvcGVkU3R5bGUuZWw7XG4gICAgfSxcbiAgICBfdW5sb2FkU2NvcGVkVGhlbWVTdHlsZXM6IGZ1bmN0aW9uIF91bmxvYWRTY29wZWRUaGVtZVN0eWxlcygpIHtcbiAgICAgIHZhciBfdGhpcyRzY29wZWRTdHlsZUVsO1xuICAgICAgKF90aGlzJHNjb3BlZFN0eWxlRWwgPSB0aGlzLnNjb3BlZFN0eWxlRWwpID09PSBudWxsIHx8IF90aGlzJHNjb3BlZFN0eWxlRWwgPT09IHZvaWQgMCB8fCAoX3RoaXMkc2NvcGVkU3R5bGVFbCA9IF90aGlzJHNjb3BlZFN0eWxlRWwudmFsdWUpID09PSBudWxsIHx8IF90aGlzJHNjb3BlZFN0eWxlRWwgPT09IHZvaWQgMCB8fCBfdGhpcyRzY29wZWRTdHlsZUVsLnJlbW92ZSgpO1xuICAgIH0sXG4gICAgX3RoZW1lQ2hhbmdlTGlzdGVuZXI6IGZ1bmN0aW9uIF90aGVtZUNoYW5nZUxpc3RlbmVyKCkge1xuICAgICAgdmFyIGNhbGxiYWNrID0gYXJndW1lbnRzLmxlbmd0aCA+IDAgJiYgYXJndW1lbnRzWzBdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMF0gOiBmdW5jdGlvbiAoKSB7fTtcbiAgICAgIEJhc2UuY2xlYXJMb2FkZWRTdHlsZU5hbWVzKCk7XG4gICAgICBUaGVtZVNlcnZpY2Uub24oJ3RoZW1lOmNoYW5nZScsIGNhbGxiYWNrKTtcbiAgICB9LFxuICAgIF9yZW1vdmVUaGVtZUxpc3RlbmVyczogZnVuY3Rpb24gX3JlbW92ZVRoZW1lTGlzdGVuZXJzKCkge1xuICAgICAgVGhlbWVTZXJ2aWNlLm9mZigndGhlbWU6Y2hhbmdlJywgdGhpcy5fbG9hZENvcmVTdHlsZXMpO1xuICAgICAgVGhlbWVTZXJ2aWNlLm9mZigndGhlbWU6Y2hhbmdlJywgdGhpcy5fbG9hZCk7XG4gICAgICBUaGVtZVNlcnZpY2Uub2ZmKCd0aGVtZTpjaGFuZ2UnLCB0aGlzLl90aGVtZVNjb3BlZExpc3RlbmVyKTtcbiAgICB9LFxuICAgIF9nZXRIb3N0SW5zdGFuY2U6IGZ1bmN0aW9uIF9nZXRIb3N0SW5zdGFuY2UoaW5zdGFuY2UpIHtcbiAgICAgIHJldHVybiBpbnN0YW5jZSA/IHRoaXMuJG9wdGlvbnMuaG9zdE5hbWUgPyBpbnN0YW5jZS4kLnR5cGUubmFtZSA9PT0gdGhpcy4kb3B0aW9ucy5ob3N0TmFtZSA/IGluc3RhbmNlIDogdGhpcy5fZ2V0SG9zdEluc3RhbmNlKGluc3RhbmNlLiRwYXJlbnRJbnN0YW5jZSkgOiBpbnN0YW5jZS4kcGFyZW50SW5zdGFuY2UgOiB1bmRlZmluZWQ7XG4gICAgfSxcbiAgICBfZ2V0UHJvcFZhbHVlOiBmdW5jdGlvbiBfZ2V0UHJvcFZhbHVlKG5hbWUpIHtcbiAgICAgIHZhciBfdGhpcyRfZ2V0SG9zdEluc3RhbmM7XG4gICAgICByZXR1cm4gdGhpc1tuYW1lXSB8fCAoKF90aGlzJF9nZXRIb3N0SW5zdGFuYyA9IHRoaXMuX2dldEhvc3RJbnN0YW5jZSh0aGlzKSkgPT09IG51bGwgfHwgX3RoaXMkX2dldEhvc3RJbnN0YW5jID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfdGhpcyRfZ2V0SG9zdEluc3RhbmNbbmFtZV0pO1xuICAgIH0sXG4gICAgX2dldE9wdGlvblZhbHVlOiBmdW5jdGlvbiBfZ2V0T3B0aW9uVmFsdWUob3B0aW9ucykge1xuICAgICAgdmFyIGtleSA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDogJyc7XG4gICAgICB2YXIgcGFyYW1zID0gYXJndW1lbnRzLmxlbmd0aCA+IDIgJiYgYXJndW1lbnRzWzJdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMl0gOiB7fTtcbiAgICAgIHJldHVybiBnZXRLZXlWYWx1ZShvcHRpb25zLCBrZXksIHBhcmFtcyk7XG4gICAgfSxcbiAgICBfZ2V0UFRWYWx1ZTogZnVuY3Rpb24gX2dldFBUVmFsdWUoKSB7XG4gICAgICB2YXIgX3RoaXMkJHByaW1ldnVlQ29uZmlnMjtcbiAgICAgIHZhciBvYmogPSBhcmd1bWVudHMubGVuZ3RoID4gMCAmJiBhcmd1bWVudHNbMF0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1swXSA6IHt9O1xuICAgICAgdmFyIGtleSA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDogJyc7XG4gICAgICB2YXIgcGFyYW1zID0gYXJndW1lbnRzLmxlbmd0aCA+IDIgJiYgYXJndW1lbnRzWzJdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMl0gOiB7fTtcbiAgICAgIHZhciBzZWFyY2hJbkRlZmF1bHRQVCA9IGFyZ3VtZW50cy5sZW5ndGggPiAzICYmIGFyZ3VtZW50c1szXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzNdIDogdHJ1ZTtcbiAgICAgIHZhciBzZWFyY2hPdXQgPSAvLi9nLnRlc3Qoa2V5KSAmJiAhIXBhcmFtc1trZXkuc3BsaXQoJy4nKVswXV07XG4gICAgICB2YXIgX3JlZjYgPSB0aGlzLl9nZXRQcm9wVmFsdWUoJ3B0T3B0aW9ucycpIHx8ICgoX3RoaXMkJHByaW1ldnVlQ29uZmlnMiA9IHRoaXMuJHByaW1ldnVlQ29uZmlnKSA9PT0gbnVsbCB8fCBfdGhpcyQkcHJpbWV2dWVDb25maWcyID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfdGhpcyQkcHJpbWV2dWVDb25maWcyLnB0T3B0aW9ucykgfHwge30sXG4gICAgICAgIF9yZWY2JG1lcmdlU2VjdGlvbnMgPSBfcmVmNi5tZXJnZVNlY3Rpb25zLFxuICAgICAgICBtZXJnZVNlY3Rpb25zID0gX3JlZjYkbWVyZ2VTZWN0aW9ucyA9PT0gdm9pZCAwID8gdHJ1ZSA6IF9yZWY2JG1lcmdlU2VjdGlvbnMsXG4gICAgICAgIF9yZWY2JG1lcmdlUHJvcHMgPSBfcmVmNi5tZXJnZVByb3BzLFxuICAgICAgICB1c2VNZXJnZVByb3BzID0gX3JlZjYkbWVyZ2VQcm9wcyA9PT0gdm9pZCAwID8gZmFsc2UgOiBfcmVmNiRtZXJnZVByb3BzO1xuICAgICAgdmFyIGdsb2JhbCA9IHNlYXJjaEluRGVmYXVsdFBUID8gc2VhcmNoT3V0ID8gdGhpcy5fdXNlR2xvYmFsUFQodGhpcy5fZ2V0UFRDbGFzc1ZhbHVlLCBrZXksIHBhcmFtcykgOiB0aGlzLl91c2VEZWZhdWx0UFQodGhpcy5fZ2V0UFRDbGFzc1ZhbHVlLCBrZXksIHBhcmFtcykgOiB1bmRlZmluZWQ7XG4gICAgICB2YXIgc2VsZiA9IHNlYXJjaE91dCA/IHVuZGVmaW5lZCA6IHRoaXMuX2dldFBUU2VsZihvYmosIHRoaXMuX2dldFBUQ2xhc3NWYWx1ZSwga2V5LCBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe30sIHBhcmFtcyksIHt9LCB7XG4gICAgICAgIGdsb2JhbDogZ2xvYmFsIHx8IHt9XG4gICAgICB9KSk7XG4gICAgICB2YXIgZGF0YXNldHMgPSB0aGlzLl9nZXRQVERhdGFzZXRzKGtleSk7XG4gICAgICByZXR1cm4gbWVyZ2VTZWN0aW9ucyB8fCAhbWVyZ2VTZWN0aW9ucyAmJiBzZWxmID8gdXNlTWVyZ2VQcm9wcyA/IHRoaXMuX21lcmdlUHJvcHModXNlTWVyZ2VQcm9wcywgZ2xvYmFsLCBzZWxmLCBkYXRhc2V0cykgOiBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgZ2xvYmFsKSwgc2VsZiksIGRhdGFzZXRzKSA6IF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgc2VsZiksIGRhdGFzZXRzKTtcbiAgICB9LFxuICAgIF9nZXRQVFNlbGY6IGZ1bmN0aW9uIF9nZXRQVFNlbGYoKSB7XG4gICAgICB2YXIgb2JqID0gYXJndW1lbnRzLmxlbmd0aCA+IDAgJiYgYXJndW1lbnRzWzBdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMF0gOiB7fTtcbiAgICAgIGZvciAodmFyIF9sZW4yID0gYXJndW1lbnRzLmxlbmd0aCwgYXJncyA9IG5ldyBBcnJheShfbGVuMiA+IDEgPyBfbGVuMiAtIDEgOiAwKSwgX2tleTMgPSAxOyBfa2V5MyA8IF9sZW4yOyBfa2V5MysrKSB7XG4gICAgICAgIGFyZ3NbX2tleTMgLSAxXSA9IGFyZ3VtZW50c1tfa2V5M107XG4gICAgICB9XG4gICAgICByZXR1cm4gbWVyZ2VQcm9wcyh0aGlzLl91c2VQVC5hcHBseSh0aGlzLCBbdGhpcy5fZ2V0UFQob2JqLCB0aGlzLiRuYW1lKV0uY29uY2F0KGFyZ3MpKSxcbiAgICAgIC8vIEV4cDsgPGNvbXBvbmVudCA6cHQ9XCJ7fVwiXG4gICAgICB0aGlzLl91c2VQVC5hcHBseSh0aGlzLCBbdGhpcy4kX2F0dHJzUFRdLmNvbmNhdChhcmdzKSkgLy8gRXhwOyA8Y29tcG9uZW50IDpwdDpbcGFzc3Rocm91Z2hfa2V5XTpbYXR0cmlidXRlXT1cInt2YWx1ZX1cIiBvciA8Y29tcG9uZW50IDpwdDpbcGFzc3Rocm91Z2hfa2V5XT1cIigpID0+e3ZhbHVlfVwiXG4gICAgICApO1xuICAgIH0sXG4gICAgX2dldFBURGF0YXNldHM6IGZ1bmN0aW9uIF9nZXRQVERhdGFzZXRzKCkge1xuICAgICAgdmFyIF90aGlzJHB0NCwgX3RoaXMkcHQ1O1xuICAgICAgdmFyIGtleSA9IGFyZ3VtZW50cy5sZW5ndGggPiAwICYmIGFyZ3VtZW50c1swXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzBdIDogJyc7XG4gICAgICB2YXIgZGF0YXNldFByZWZpeCA9ICdkYXRhLXBjLSc7XG4gICAgICB2YXIgaXNFeHRlbmRlZCA9IGtleSA9PT0gJ3Jvb3QnICYmIGlzTm90RW1wdHkoKF90aGlzJHB0NCA9IHRoaXMucHQpID09PSBudWxsIHx8IF90aGlzJHB0NCA9PT0gdm9pZCAwID8gdm9pZCAwIDogX3RoaXMkcHQ0WydkYXRhLXBjLXNlY3Rpb24nXSk7XG4gICAgICByZXR1cm4ga2V5ICE9PSAndHJhbnNpdGlvbicgJiYgX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKHt9LCBrZXkgPT09ICdyb290JyAmJiBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoX2RlZmluZVByb3BlcnR5KHt9LCBcIlwiLmNvbmNhdChkYXRhc2V0UHJlZml4LCBcIm5hbWVcIiksIHRvRmxhdENhc2UoaXNFeHRlbmRlZCA/IChfdGhpcyRwdDUgPSB0aGlzLnB0KSA9PT0gbnVsbCB8fCBfdGhpcyRwdDUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF90aGlzJHB0NVsnZGF0YS1wYy1zZWN0aW9uJ10gOiB0aGlzLiQudHlwZS5uYW1lKSksIGlzRXh0ZW5kZWQgJiYgX2RlZmluZVByb3BlcnR5KHt9LCBcIlwiLmNvbmNhdChkYXRhc2V0UHJlZml4LCBcImV4dGVuZFwiKSwgdG9GbGF0Q2FzZSh0aGlzLiQudHlwZS5uYW1lKSkpLCB7fSwgX2RlZmluZVByb3BlcnR5KHt9LCBcIlwiLmNvbmNhdCh0aGlzLiRhdHRyU2VsZWN0b3IpLCAnJykpKSwge30sIF9kZWZpbmVQcm9wZXJ0eSh7fSwgXCJcIi5jb25jYXQoZGF0YXNldFByZWZpeCwgXCJzZWN0aW9uXCIpLCB0b0ZsYXRDYXNlKGtleSkpKTtcbiAgICB9LFxuICAgIF9nZXRQVENsYXNzVmFsdWU6IGZ1bmN0aW9uIF9nZXRQVENsYXNzVmFsdWUoKSB7XG4gICAgICB2YXIgdmFsdWUgPSB0aGlzLl9nZXRPcHRpb25WYWx1ZS5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgcmV0dXJuIGlzU3RyaW5nKHZhbHVlKSB8fCBpc0FycmF5KHZhbHVlKSA/IHtcbiAgICAgICAgXCJjbGFzc1wiOiB2YWx1ZVxuICAgICAgfSA6IHZhbHVlO1xuICAgIH0sXG4gICAgX2dldFBUOiBmdW5jdGlvbiBfZ2V0UFQocHQpIHtcbiAgICAgIHZhciBfdGhpczIgPSB0aGlzO1xuICAgICAgdmFyIGtleSA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDogJyc7XG4gICAgICB2YXIgY2FsbGJhY2sgPSBhcmd1bWVudHMubGVuZ3RoID4gMiA/IGFyZ3VtZW50c1syXSA6IHVuZGVmaW5lZDtcbiAgICAgIHZhciBnZXRWYWx1ZSA9IGZ1bmN0aW9uIGdldFZhbHVlKHZhbHVlKSB7XG4gICAgICAgIHZhciBfcmVmODtcbiAgICAgICAgdmFyIGNoZWNrU2FtZUtleSA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDogZmFsc2U7XG4gICAgICAgIHZhciBjb21wdXRlZFZhbHVlID0gY2FsbGJhY2sgPyBjYWxsYmFjayh2YWx1ZSkgOiB2YWx1ZTtcbiAgICAgICAgdmFyIF9rZXkgPSB0b0ZsYXRDYXNlKGtleSk7XG4gICAgICAgIHZhciBfY0tleSA9IHRvRmxhdENhc2UoX3RoaXMyLiRuYW1lKTtcbiAgICAgICAgcmV0dXJuIChfcmVmOCA9IGNoZWNrU2FtZUtleSA/IF9rZXkgIT09IF9jS2V5ID8gY29tcHV0ZWRWYWx1ZSA9PT0gbnVsbCB8fCBjb21wdXRlZFZhbHVlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBjb21wdXRlZFZhbHVlW19rZXldIDogdW5kZWZpbmVkIDogY29tcHV0ZWRWYWx1ZSA9PT0gbnVsbCB8fCBjb21wdXRlZFZhbHVlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBjb21wdXRlZFZhbHVlW19rZXldKSAhPT0gbnVsbCAmJiBfcmVmOCAhPT0gdm9pZCAwID8gX3JlZjggOiBjb21wdXRlZFZhbHVlO1xuICAgICAgfTtcbiAgICAgIHJldHVybiBwdCAhPT0gbnVsbCAmJiBwdCAhPT0gdm9pZCAwICYmIHB0Lmhhc093blByb3BlcnR5KCdfdXNlcHQnKSA/IHtcbiAgICAgICAgX3VzZXB0OiBwdFsnX3VzZXB0J10sXG4gICAgICAgIG9yaWdpbmFsVmFsdWU6IGdldFZhbHVlKHB0Lm9yaWdpbmFsVmFsdWUpLFxuICAgICAgICB2YWx1ZTogZ2V0VmFsdWUocHQudmFsdWUpXG4gICAgICB9IDogZ2V0VmFsdWUocHQsIHRydWUpO1xuICAgIH0sXG4gICAgX3VzZVBUOiBmdW5jdGlvbiBfdXNlUFQocHQsIGNhbGxiYWNrLCBrZXksIHBhcmFtcykge1xuICAgICAgdmFyIGZuID0gZnVuY3Rpb24gZm4odmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIGNhbGxiYWNrKHZhbHVlLCBrZXksIHBhcmFtcyk7XG4gICAgICB9O1xuICAgICAgaWYgKHB0ICE9PSBudWxsICYmIHB0ICE9PSB2b2lkIDAgJiYgcHQuaGFzT3duUHJvcGVydHkoJ191c2VwdCcpKSB7XG4gICAgICAgIHZhciBfdGhpcyQkcHJpbWV2dWVDb25maWczO1xuICAgICAgICB2YXIgX3JlZjkgPSBwdFsnX3VzZXB0J10gfHwgKChfdGhpcyQkcHJpbWV2dWVDb25maWczID0gdGhpcy4kcHJpbWV2dWVDb25maWcpID09PSBudWxsIHx8IF90aGlzJCRwcmltZXZ1ZUNvbmZpZzMgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF90aGlzJCRwcmltZXZ1ZUNvbmZpZzMucHRPcHRpb25zKSB8fCB7fSxcbiAgICAgICAgICBfcmVmOSRtZXJnZVNlY3Rpb25zID0gX3JlZjkubWVyZ2VTZWN0aW9ucyxcbiAgICAgICAgICBtZXJnZVNlY3Rpb25zID0gX3JlZjkkbWVyZ2VTZWN0aW9ucyA9PT0gdm9pZCAwID8gdHJ1ZSA6IF9yZWY5JG1lcmdlU2VjdGlvbnMsXG4gICAgICAgICAgX3JlZjkkbWVyZ2VQcm9wcyA9IF9yZWY5Lm1lcmdlUHJvcHMsXG4gICAgICAgICAgdXNlTWVyZ2VQcm9wcyA9IF9yZWY5JG1lcmdlUHJvcHMgPT09IHZvaWQgMCA/IGZhbHNlIDogX3JlZjkkbWVyZ2VQcm9wcztcbiAgICAgICAgdmFyIG9yaWdpbmFsVmFsdWUgPSBmbihwdC5vcmlnaW5hbFZhbHVlKTtcbiAgICAgICAgdmFyIHZhbHVlID0gZm4ocHQudmFsdWUpO1xuICAgICAgICBpZiAob3JpZ2luYWxWYWx1ZSA9PT0gdW5kZWZpbmVkICYmIHZhbHVlID09PSB1bmRlZmluZWQpIHJldHVybiB1bmRlZmluZWQ7ZWxzZSBpZiAoaXNTdHJpbmcodmFsdWUpKSByZXR1cm4gdmFsdWU7ZWxzZSBpZiAoaXNTdHJpbmcob3JpZ2luYWxWYWx1ZSkpIHJldHVybiBvcmlnaW5hbFZhbHVlO1xuICAgICAgICByZXR1cm4gbWVyZ2VTZWN0aW9ucyB8fCAhbWVyZ2VTZWN0aW9ucyAmJiB2YWx1ZSA/IHVzZU1lcmdlUHJvcHMgPyB0aGlzLl9tZXJnZVByb3BzKHVzZU1lcmdlUHJvcHMsIG9yaWdpbmFsVmFsdWUsIHZhbHVlKSA6IF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgb3JpZ2luYWxWYWx1ZSksIHZhbHVlKSA6IHZhbHVlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZuKHB0KTtcbiAgICB9LFxuICAgIF91c2VHbG9iYWxQVDogZnVuY3Rpb24gX3VzZUdsb2JhbFBUKGNhbGxiYWNrLCBrZXksIHBhcmFtcykge1xuICAgICAgcmV0dXJuIHRoaXMuX3VzZVBUKHRoaXMuZ2xvYmFsUFQsIGNhbGxiYWNrLCBrZXksIHBhcmFtcyk7XG4gICAgfSxcbiAgICBfdXNlRGVmYXVsdFBUOiBmdW5jdGlvbiBfdXNlRGVmYXVsdFBUKGNhbGxiYWNrLCBrZXksIHBhcmFtcykge1xuICAgICAgcmV0dXJuIHRoaXMuX3VzZVBUKHRoaXMuZGVmYXVsdFBULCBjYWxsYmFjaywga2V5LCBwYXJhbXMpO1xuICAgIH0sXG4gICAgcHRtOiBmdW5jdGlvbiBwdG0oKSB7XG4gICAgICB2YXIga2V5ID0gYXJndW1lbnRzLmxlbmd0aCA+IDAgJiYgYXJndW1lbnRzWzBdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMF0gOiAnJztcbiAgICAgIHZhciBwYXJhbXMgPSBhcmd1bWVudHMubGVuZ3RoID4gMSAmJiBhcmd1bWVudHNbMV0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1sxXSA6IHt9O1xuICAgICAgcmV0dXJuIHRoaXMuX2dldFBUVmFsdWUodGhpcy5wdCwga2V5LCBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe30sIHRoaXMuJHBhcmFtcyksIHBhcmFtcykpO1xuICAgIH0sXG4gICAgcHRtaTogZnVuY3Rpb24gcHRtaSgpIHtcbiAgICAgIHZhciBfYXR0cnMkaWQ7XG4gICAgICB2YXIga2V5ID0gYXJndW1lbnRzLmxlbmd0aCA+IDAgJiYgYXJndW1lbnRzWzBdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMF0gOiAnJztcbiAgICAgIHZhciBwYXJhbXMgPSBhcmd1bWVudHMubGVuZ3RoID4gMSAmJiBhcmd1bWVudHNbMV0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1sxXSA6IHt9O1xuICAgICAgLy8gaW5oZXJpdEF0dHJzOnRydWVcbiAgICAgIHZhciBhdHRycyA9IG1lcmdlUHJvcHModGhpcy4kX2F0dHJzV2l0aG91dFBULCB0aGlzLnB0bShrZXksIHBhcmFtcykpO1xuICAgICAgKGF0dHJzID09PSBudWxsIHx8IGF0dHJzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBhdHRycy5oYXNPd25Qcm9wZXJ0eSgnaWQnKSkgJiYgKChfYXR0cnMkaWQgPSBhdHRycy5pZCkgIT09IG51bGwgJiYgX2F0dHJzJGlkICE9PSB2b2lkIDAgPyBfYXR0cnMkaWQgOiBhdHRycy5pZCA9IHRoaXMuJGlkKTtcbiAgICAgIHJldHVybiBhdHRycztcbiAgICB9LFxuICAgIHB0bW86IGZ1bmN0aW9uIHB0bW8oKSB7XG4gICAgICB2YXIgb2JqID0gYXJndW1lbnRzLmxlbmd0aCA+IDAgJiYgYXJndW1lbnRzWzBdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMF0gOiB7fTtcbiAgICAgIHZhciBrZXkgPSBhcmd1bWVudHMubGVuZ3RoID4gMSAmJiBhcmd1bWVudHNbMV0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1sxXSA6ICcnO1xuICAgICAgdmFyIHBhcmFtcyA9IGFyZ3VtZW50cy5sZW5ndGggPiAyICYmIGFyZ3VtZW50c1syXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzJdIDoge307XG4gICAgICByZXR1cm4gdGhpcy5fZ2V0UFRWYWx1ZShvYmosIGtleSwgX29iamVjdFNwcmVhZCh7XG4gICAgICAgIGluc3RhbmNlOiB0aGlzXG4gICAgICB9LCBwYXJhbXMpLCBmYWxzZSk7XG4gICAgfSxcbiAgICBjeDogZnVuY3Rpb24gY3goKSB7XG4gICAgICB2YXIga2V5ID0gYXJndW1lbnRzLmxlbmd0aCA+IDAgJiYgYXJndW1lbnRzWzBdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMF0gOiAnJztcbiAgICAgIHZhciBwYXJhbXMgPSBhcmd1bWVudHMubGVuZ3RoID4gMSAmJiBhcmd1bWVudHNbMV0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1sxXSA6IHt9O1xuICAgICAgcmV0dXJuICF0aGlzLmlzVW5zdHlsZWQgPyB0aGlzLl9nZXRPcHRpb25WYWx1ZSh0aGlzLiRzdHlsZS5jbGFzc2VzLCBrZXksIF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgdGhpcy4kcGFyYW1zKSwgcGFyYW1zKSkgOiB1bmRlZmluZWQ7XG4gICAgfSxcbiAgICBzeDogZnVuY3Rpb24gc3goKSB7XG4gICAgICB2YXIga2V5ID0gYXJndW1lbnRzLmxlbmd0aCA+IDAgJiYgYXJndW1lbnRzWzBdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMF0gOiAnJztcbiAgICAgIHZhciB3aGVuID0gYXJndW1lbnRzLmxlbmd0aCA+IDEgJiYgYXJndW1lbnRzWzFdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMV0gOiB0cnVlO1xuICAgICAgdmFyIHBhcmFtcyA9IGFyZ3VtZW50cy5sZW5ndGggPiAyICYmIGFyZ3VtZW50c1syXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzJdIDoge307XG4gICAgICBpZiAod2hlbikge1xuICAgICAgICB2YXIgc2VsZiA9IHRoaXMuX2dldE9wdGlvblZhbHVlKHRoaXMuJHN0eWxlLmlubGluZVN0eWxlcywga2V5LCBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe30sIHRoaXMuJHBhcmFtcyksIHBhcmFtcykpO1xuICAgICAgICB2YXIgYmFzZSA9IHRoaXMuX2dldE9wdGlvblZhbHVlKEJhc2VDb21wb25lbnRTdHlsZS5pbmxpbmVTdHlsZXMsIGtleSwgX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKHt9LCB0aGlzLiRwYXJhbXMpLCBwYXJhbXMpKTtcbiAgICAgICAgcmV0dXJuIFtiYXNlLCBzZWxmXTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICB9LFxuICBjb21wdXRlZDoge1xuICAgIGdsb2JhbFBUOiBmdW5jdGlvbiBnbG9iYWxQVCgpIHtcbiAgICAgIHZhciBfdGhpcyQkcHJpbWV2dWVDb25maWc0LFxuICAgICAgICBfdGhpczMgPSB0aGlzO1xuICAgICAgcmV0dXJuIHRoaXMuX2dldFBUKChfdGhpcyQkcHJpbWV2dWVDb25maWc0ID0gdGhpcy4kcHJpbWV2dWVDb25maWcpID09PSBudWxsIHx8IF90aGlzJCRwcmltZXZ1ZUNvbmZpZzQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF90aGlzJCRwcmltZXZ1ZUNvbmZpZzQucHQsIHVuZGVmaW5lZCwgZnVuY3Rpb24gKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiByZXNvbHZlKHZhbHVlLCB7XG4gICAgICAgICAgaW5zdGFuY2U6IF90aGlzM1xuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH0sXG4gICAgZGVmYXVsdFBUOiBmdW5jdGlvbiBkZWZhdWx0UFQoKSB7XG4gICAgICB2YXIgX3RoaXMkJHByaW1ldnVlQ29uZmlnNSxcbiAgICAgICAgX3RoaXM0ID0gdGhpcztcbiAgICAgIHJldHVybiB0aGlzLl9nZXRQVCgoX3RoaXMkJHByaW1ldnVlQ29uZmlnNSA9IHRoaXMuJHByaW1ldnVlQ29uZmlnKSA9PT0gbnVsbCB8fCBfdGhpcyQkcHJpbWV2dWVDb25maWc1ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfdGhpcyQkcHJpbWV2dWVDb25maWc1LnB0LCB1bmRlZmluZWQsIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gX3RoaXM0Ll9nZXRPcHRpb25WYWx1ZSh2YWx1ZSwgX3RoaXM0LiRuYW1lLCBfb2JqZWN0U3ByZWFkKHt9LCBfdGhpczQuJHBhcmFtcykpIHx8IHJlc29sdmUodmFsdWUsIF9vYmplY3RTcHJlYWQoe30sIF90aGlzNC4kcGFyYW1zKSk7XG4gICAgICB9KTtcbiAgICB9LFxuICAgIGlzVW5zdHlsZWQ6IGZ1bmN0aW9uIGlzVW5zdHlsZWQoKSB7XG4gICAgICB2YXIgX3RoaXMkJHByaW1ldnVlQ29uZmlnNjtcbiAgICAgIHJldHVybiB0aGlzLnVuc3R5bGVkICE9PSB1bmRlZmluZWQgPyB0aGlzLnVuc3R5bGVkIDogKF90aGlzJCRwcmltZXZ1ZUNvbmZpZzYgPSB0aGlzLiRwcmltZXZ1ZUNvbmZpZykgPT09IG51bGwgfHwgX3RoaXMkJHByaW1ldnVlQ29uZmlnNiA9PT0gdm9pZCAwID8gdm9pZCAwIDogX3RoaXMkJHByaW1ldnVlQ29uZmlnNi51bnN0eWxlZDtcbiAgICB9LFxuICAgICRpZDogZnVuY3Rpb24gJGlkKCkge1xuICAgICAgcmV0dXJuIHRoaXMuJGF0dHJzLmlkIHx8IHRoaXMudWlkO1xuICAgIH0sXG4gICAgJGluUHJvcHM6IGZ1bmN0aW9uICRpblByb3BzKCkge1xuICAgICAgdmFyIF90aGlzJCQkdm5vZGU7XG4gICAgICB2YXIgbm9kZVByb3BLZXlzID0gT2JqZWN0LmtleXMoKChfdGhpcyQkJHZub2RlID0gdGhpcy4kLnZub2RlKSA9PT0gbnVsbCB8fCBfdGhpcyQkJHZub2RlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfdGhpcyQkJHZub2RlLnByb3BzKSB8fCB7fSk7XG4gICAgICByZXR1cm4gT2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5lbnRyaWVzKHRoaXMuJHByb3BzKS5maWx0ZXIoZnVuY3Rpb24gKF9yZWYwKSB7XG4gICAgICAgIHZhciBfcmVmMSA9IF9zbGljZWRUb0FycmF5KF9yZWYwLCAxKSxcbiAgICAgICAgICBrID0gX3JlZjFbMF07XG4gICAgICAgIHJldHVybiBub2RlUHJvcEtleXMgPT09IG51bGwgfHwgbm9kZVByb3BLZXlzID09PSB2b2lkIDAgPyB2b2lkIDAgOiBub2RlUHJvcEtleXMuaW5jbHVkZXMoayk7XG4gICAgICB9KSk7XG4gICAgfSxcbiAgICAkdGhlbWU6IGZ1bmN0aW9uICR0aGVtZSgpIHtcbiAgICAgIHZhciBfdGhpcyQkcHJpbWV2dWVDb25maWc3O1xuICAgICAgcmV0dXJuIChfdGhpcyQkcHJpbWV2dWVDb25maWc3ID0gdGhpcy4kcHJpbWV2dWVDb25maWcpID09PSBudWxsIHx8IF90aGlzJCRwcmltZXZ1ZUNvbmZpZzcgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF90aGlzJCRwcmltZXZ1ZUNvbmZpZzcudGhlbWU7XG4gICAgfSxcbiAgICAkc3R5bGU6IGZ1bmN0aW9uICRzdHlsZSgpIHtcbiAgICAgIHJldHVybiBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe1xuICAgICAgICBjbGFzc2VzOiB1bmRlZmluZWQsXG4gICAgICAgIGlubGluZVN0eWxlczogdW5kZWZpbmVkLFxuICAgICAgICBsb2FkOiBmdW5jdGlvbiBsb2FkKCkge30sXG4gICAgICAgIGxvYWRDU1M6IGZ1bmN0aW9uIGxvYWRDU1MoKSB7fSxcbiAgICAgICAgbG9hZFN0eWxlOiBmdW5jdGlvbiBsb2FkU3R5bGUoKSB7fVxuICAgICAgfSwgKHRoaXMuX2dldEhvc3RJbnN0YW5jZSh0aGlzKSB8fCB7fSkuJHN0eWxlKSwgdGhpcy4kb3B0aW9ucy5zdHlsZSk7XG4gICAgfSxcbiAgICAkc3R5bGVPcHRpb25zOiBmdW5jdGlvbiAkc3R5bGVPcHRpb25zKCkge1xuICAgICAgdmFyIF90aGlzJCRwcmltZXZ1ZUNvbmZpZzg7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBub25jZTogKF90aGlzJCRwcmltZXZ1ZUNvbmZpZzggPSB0aGlzLiRwcmltZXZ1ZUNvbmZpZykgPT09IG51bGwgfHwgX3RoaXMkJHByaW1ldnVlQ29uZmlnOCA9PT0gdm9pZCAwIHx8IChfdGhpcyQkcHJpbWV2dWVDb25maWc4ID0gX3RoaXMkJHByaW1ldnVlQ29uZmlnOC5jc3ApID09PSBudWxsIHx8IF90aGlzJCRwcmltZXZ1ZUNvbmZpZzggPT09IHZvaWQgMCA/IHZvaWQgMCA6IF90aGlzJCRwcmltZXZ1ZUNvbmZpZzgubm9uY2VcbiAgICAgIH07XG4gICAgfSxcbiAgICAkcHJpbWV2dWVDb25maWc6IGZ1bmN0aW9uICRwcmltZXZ1ZUNvbmZpZygpIHtcbiAgICAgIHZhciBfdGhpcyQkcHJpbWV2dWU0O1xuICAgICAgcmV0dXJuIChfdGhpcyQkcHJpbWV2dWU0ID0gdGhpcy4kcHJpbWV2dWUpID09PSBudWxsIHx8IF90aGlzJCRwcmltZXZ1ZTQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF90aGlzJCRwcmltZXZ1ZTQuY29uZmlnO1xuICAgIH0sXG4gICAgJG5hbWU6IGZ1bmN0aW9uICRuYW1lKCkge1xuICAgICAgcmV0dXJuIHRoaXMuJG9wdGlvbnMuaG9zdE5hbWUgfHwgdGhpcy4kLnR5cGUubmFtZTtcbiAgICB9LFxuICAgICRwYXJhbXM6IGZ1bmN0aW9uICRwYXJhbXMoKSB7XG4gICAgICB2YXIgcGFyZW50SW5zdGFuY2UgPSB0aGlzLl9nZXRIb3N0SW5zdGFuY2UodGhpcykgfHwgdGhpcy4kcGFyZW50O1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgaW5zdGFuY2U6IHRoaXMsXG4gICAgICAgIHByb3BzOiB0aGlzLiRwcm9wcyxcbiAgICAgICAgc3RhdGU6IHRoaXMuJGRhdGEsXG4gICAgICAgIGF0dHJzOiB0aGlzLiRhdHRycyxcbiAgICAgICAgcGFyZW50OiB7XG4gICAgICAgICAgaW5zdGFuY2U6IHBhcmVudEluc3RhbmNlLFxuICAgICAgICAgIHByb3BzOiBwYXJlbnRJbnN0YW5jZSA9PT0gbnVsbCB8fCBwYXJlbnRJbnN0YW5jZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogcGFyZW50SW5zdGFuY2UuJHByb3BzLFxuICAgICAgICAgIHN0YXRlOiBwYXJlbnRJbnN0YW5jZSA9PT0gbnVsbCB8fCBwYXJlbnRJbnN0YW5jZSA9PT0gdm9pZCAwID8gdm9pZCAwIDogcGFyZW50SW5zdGFuY2UuJGRhdGEsXG4gICAgICAgICAgYXR0cnM6IHBhcmVudEluc3RhbmNlID09PSBudWxsIHx8IHBhcmVudEluc3RhbmNlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBwYXJlbnRJbnN0YW5jZS4kYXR0cnNcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9LFxuICAgICRfYXR0cnNQVDogZnVuY3Rpb24gJF9hdHRyc1BUKCkge1xuICAgICAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHRoaXMuJGF0dHJzIHx8IHt9KS5maWx0ZXIoZnVuY3Rpb24gKF9yZWYxMCkge1xuICAgICAgICB2YXIgX3JlZjExID0gX3NsaWNlZFRvQXJyYXkoX3JlZjEwLCAxKSxcbiAgICAgICAgICBrZXkgPSBfcmVmMTFbMF07XG4gICAgICAgIHJldHVybiBrZXkgPT09IG51bGwgfHwga2V5ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBrZXkuc3RhcnRzV2l0aCgncHQ6Jyk7XG4gICAgICB9KS5yZWR1Y2UoZnVuY3Rpb24gKHJlc3VsdCwgX3JlZjEyKSB7XG4gICAgICAgIHZhciBfcmVmMTMgPSBfc2xpY2VkVG9BcnJheShfcmVmMTIsIDIpLFxuICAgICAgICAgIGtleSA9IF9yZWYxM1swXSxcbiAgICAgICAgICB2YWx1ZSA9IF9yZWYxM1sxXTtcbiAgICAgICAgdmFyIF9rZXkkc3BsaXQgPSBrZXkuc3BsaXQoJzonKSxcbiAgICAgICAgICBfa2V5JHNwbGl0MiA9IF90b0FycmF5KF9rZXkkc3BsaXQpLFxuICAgICAgICAgIHJlc3QgPSBfYXJyYXlMaWtlVG9BcnJheShfa2V5JHNwbGl0Mikuc2xpY2UoMSk7XG4gICAgICAgIHJlc3QgPT09IG51bGwgfHwgcmVzdCA9PT0gdm9pZCAwIHx8IHJlc3QucmVkdWNlKGZ1bmN0aW9uIChjdXJyZW50T2JqLCBuZXN0ZWRLZXksIGluZGV4LCBhcnJheSkge1xuICAgICAgICAgICFjdXJyZW50T2JqW25lc3RlZEtleV0gJiYgKGN1cnJlbnRPYmpbbmVzdGVkS2V5XSA9IGluZGV4ID09PSBhcnJheS5sZW5ndGggLSAxID8gdmFsdWUgOiB7fSk7XG4gICAgICAgICAgcmV0dXJuIGN1cnJlbnRPYmpbbmVzdGVkS2V5XTtcbiAgICAgICAgfSwgcmVzdWx0KTtcbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgIH0sIHt9KTtcbiAgICB9LFxuICAgICRfYXR0cnNXaXRob3V0UFQ6IGZ1bmN0aW9uICRfYXR0cnNXaXRob3V0UFQoKSB7XG4gICAgICByZXR1cm4gT2JqZWN0LmVudHJpZXModGhpcy4kYXR0cnMgfHwge30pLmZpbHRlcihmdW5jdGlvbiAoX3JlZjE0KSB7XG4gICAgICAgIHZhciBfcmVmMTUgPSBfc2xpY2VkVG9BcnJheShfcmVmMTQsIDEpLFxuICAgICAgICAgIGtleSA9IF9yZWYxNVswXTtcbiAgICAgICAgcmV0dXJuICEoa2V5ICE9PSBudWxsICYmIGtleSAhPT0gdm9pZCAwICYmIGtleS5zdGFydHNXaXRoKCdwdDonKSk7XG4gICAgICB9KS5yZWR1Y2UoZnVuY3Rpb24gKGFjYywgX3JlZjE2KSB7XG4gICAgICAgIHZhciBfcmVmMTcgPSBfc2xpY2VkVG9BcnJheShfcmVmMTYsIDIpLFxuICAgICAgICAgIGtleSA9IF9yZWYxN1swXSxcbiAgICAgICAgICB2YWx1ZSA9IF9yZWYxN1sxXTtcbiAgICAgICAgYWNjW2tleV0gPSB2YWx1ZTtcbiAgICAgICAgcmV0dXJuIGFjYztcbiAgICAgIH0sIHt9KTtcbiAgICB9XG4gIH1cbn07XG5cbmV4cG9ydCB7IHNjcmlwdCBhcyBkZWZhdWx0IH07XG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyXSwibWFwcGluZ3MiOiI7OztBQUFBLElBQUksT0FBTztDQUNULG1DQUFtQixJQUFJLElBQUk7Q0FDM0IscUJBQXFCLFNBQVMsc0JBQXNCO0VBQ2xELE9BQU8sS0FBSztDQUNkO0NBQ0EsbUJBQW1CLFNBQVMsa0JBQWtCLE1BQU07RUFDbEQsT0FBTyxLQUFLLGtCQUFrQixJQUFJLElBQUk7Q0FDeEM7Q0FDQSxvQkFBb0IsU0FBUyxtQkFBbUIsTUFBTTtFQUNwRCxLQUFLLGtCQUFrQixJQUFJLElBQUk7Q0FDakM7Q0FDQSx1QkFBdUIsU0FBUyxzQkFBc0IsTUFBTTtFQUMxRCxLQUFLLGtCQUFrQixTQUFTLENBQUMsSUFBSTtDQUN2QztDQUNBLHVCQUF1QixTQUFTLHdCQUF3QjtFQUN0RCxLQUFLLGtCQUFrQixNQUFNO0NBQy9CO0FBQ0Y7OztBQ2ZBLFNBQVMsa0JBQWtCO0NBQ3pCLElBQUksU0FBUyxVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sS0FBQSxJQUFZLFVBQVUsS0FBSztDQUNqRixJQUFJLE1BQU0sTUFBTTtDQUNoQixPQUFPLEdBQUcsT0FBTyxNQUFNLENBQUMsQ0FBQyxPQUFPLElBQUksUUFBUSxNQUFNLEVBQUUsQ0FBQyxDQUFDLFdBQVcsS0FBSyxHQUFHLENBQUM7QUFDNUU7OztBQ0VBLElBQUkscUJBQXFCLFVBQVUsT0FBTyxFQUN4QyxNQUFNLFNBQ1IsQ0FBQztBQUVELFNBQVMsUUFBUSxHQUFHO0NBQUU7Q0FBMkIsT0FBTyxVQUFVLGNBQWMsT0FBTyxVQUFVLFlBQVksT0FBTyxPQUFPLFdBQVcsU0FBVSxHQUFHO0VBQUUsT0FBTyxPQUFPO0NBQUcsSUFBSSxTQUFVLEdBQUc7RUFBRSxPQUFPLEtBQUssY0FBYyxPQUFPLFVBQVUsRUFBRSxnQkFBZ0IsVUFBVSxNQUFNLE9BQU8sWUFBWSxXQUFXLE9BQU87Q0FBRyxHQUFHLFFBQVEsQ0FBQztBQUFHO0FBQzdULFNBQVMsU0FBUyxHQUFHO0NBQUUsT0FBTyxnQkFBZ0IsQ0FBQyxLQUFLLGlCQUFpQixDQUFDLEtBQUssNEJBQTRCLENBQUMsS0FBSyxpQkFBaUI7QUFBRztBQUNqSSxTQUFTLGlCQUFpQixHQUFHO0NBQUUsSUFBSSxlQUFlLE9BQU8sVUFBVSxRQUFRLEVBQUUsT0FBTyxhQUFhLFFBQVEsRUFBRSxlQUFlLE9BQU8sTUFBTSxLQUFLLENBQUM7QUFBRztBQUNoSixTQUFTLGVBQWUsR0FBRyxHQUFHO0NBQUUsT0FBTyxnQkFBZ0IsQ0FBQyxLQUFLLHNCQUFzQixHQUFHLENBQUMsS0FBSyw0QkFBNEIsR0FBRyxDQUFDLEtBQUssaUJBQWlCO0FBQUc7QUFDckosU0FBUyxtQkFBbUI7Q0FBRSxNQUFNLElBQUksVUFBVSwySUFBMkk7QUFBRztBQUNoTSxTQUFTLDRCQUE0QixHQUFHLEdBQUc7Q0FBRSxJQUFJLEdBQUc7RUFBRSxJQUFJLFlBQVksT0FBTyxHQUFHLE9BQU8sa0JBQWtCLEdBQUcsQ0FBQztFQUFHLElBQUksSUFBSSxDQUFDLEVBQUUsU0FBUyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxFQUFFO0VBQUcsT0FBTyxhQUFhLEtBQUssRUFBRSxnQkFBZ0IsSUFBSSxFQUFFLFlBQVksT0FBTyxVQUFVLEtBQUssVUFBVSxJQUFJLE1BQU0sS0FBSyxDQUFDLElBQUksZ0JBQWdCLEtBQUssMkNBQTJDLEtBQUssQ0FBQyxJQUFJLGtCQUFrQixHQUFHLENBQUMsSUFBSSxLQUFLO0NBQUc7QUFBRTtBQUN6WCxTQUFTLGtCQUFrQixHQUFHLEdBQUc7Q0FBRSxDQUFDLFFBQVEsS0FBSyxJQUFJLEVBQUUsWUFBWSxJQUFJLEVBQUU7Q0FBUyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxDQUFDLEdBQUcsSUFBSSxHQUFHLEtBQUssRUFBRSxLQUFLLEVBQUU7Q0FBSSxPQUFPO0FBQUc7QUFDbkosU0FBUyxzQkFBc0IsR0FBRyxHQUFHO0NBQUUsSUFBSSxJQUFJLFFBQVEsSUFBSSxPQUFPLGVBQWUsT0FBTyxVQUFVLEVBQUUsT0FBTyxhQUFhLEVBQUU7Q0FBZSxJQUFJLFFBQVEsR0FBRztFQUFFLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxJQUFJLE1BQU0sSUFBSTtFQUFPLElBQUk7R0FBRSxJQUFJLEtBQUssSUFBSSxFQUFFLEtBQUssQ0FBQyxFQUFBLENBQUcsTUFBTSxNQUFNLEdBQUc7SUFBRSxJQUFJLE9BQU8sQ0FBQyxNQUFNLEdBQUc7SUFBUSxJQUFJLENBQUM7R0FBRyxPQUFPLE9BQU8sRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLENBQUMsRUFBQSxDQUFHLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxHQUFHLEVBQUUsV0FBVyxJQUFJLElBQUksQ0FBQztFQUFJLFNBQVMsR0FBRztHQUFFLElBQUksTUFBTSxJQUFJO0VBQUcsVUFBVTtHQUFFLElBQUk7SUFBRSxJQUFJLENBQUMsS0FBSyxRQUFRLEVBQUUsY0FBYyxJQUFJLEVBQUUsU0FBUyxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU0sSUFBSTtHQUFRLFVBQVU7SUFBRSxJQUFJLEdBQUcsTUFBTTtHQUFHO0VBQUU7RUFBRSxPQUFPO0NBQUc7QUFBRTtBQUNoaUIsU0FBUyxnQkFBZ0IsR0FBRztDQUFFLElBQUksTUFBTSxRQUFRLENBQUMsR0FBRyxPQUFPO0FBQUc7QUFDOUQsU0FBUyxRQUFRLEdBQUcsR0FBRztDQUFFLElBQUksSUFBSSxPQUFPLEtBQUssQ0FBQztDQUFHLElBQUksT0FBTyx1QkFBdUI7RUFBRSxJQUFJLElBQUksT0FBTyxzQkFBc0IsQ0FBQztFQUFHLE1BQU0sSUFBSSxFQUFFLE9BQU8sU0FBVSxHQUFHO0dBQUUsT0FBTyxPQUFPLHlCQUF5QixHQUFHLENBQUMsQ0FBQyxDQUFDO0VBQVksQ0FBQyxJQUFJLEVBQUUsS0FBSyxNQUFNLEdBQUcsQ0FBQztDQUFHO0NBQUUsT0FBTztBQUFHO0FBQzlQLFNBQVMsY0FBYyxHQUFHO0NBQUUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUFLO0VBQUUsSUFBSSxJQUFJLFFBQVEsVUFBVSxLQUFLLFVBQVUsS0FBSyxDQUFDO0VBQUcsSUFBSSxJQUFJLFFBQVEsT0FBTyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsUUFBUSxTQUFVLEdBQUc7R0FBRSxnQkFBZ0IsR0FBRyxHQUFHLEVBQUUsRUFBRTtFQUFHLENBQUMsSUFBSSxPQUFPLDRCQUE0QixPQUFPLGlCQUFpQixHQUFHLE9BQU8sMEJBQTBCLENBQUMsQ0FBQyxJQUFJLFFBQVEsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsU0FBVSxHQUFHO0dBQUUsT0FBTyxlQUFlLEdBQUcsR0FBRyxPQUFPLHlCQUF5QixHQUFHLENBQUMsQ0FBQztFQUFHLENBQUM7Q0FBRztDQUFFLE9BQU87QUFBRztBQUN4YixTQUFTLGdCQUFnQixHQUFHLEdBQUcsR0FBRztDQUFFLFFBQVEsSUFBSSxlQUFlLENBQUMsTUFBTSxJQUFJLE9BQU8sZUFBZSxHQUFHLEdBQUc7RUFBRSxPQUFPO0VBQUcsWUFBWTtFQUFNLGNBQWM7RUFBTSxVQUFVO0NBQUssQ0FBQyxJQUFJLEVBQUUsS0FBSyxHQUFHO0FBQUc7QUFDekwsU0FBUyxlQUFlLEdBQUc7Q0FBRSxJQUFJLElBQUksYUFBYSxHQUFHLFFBQVE7Q0FBRyxPQUFPLFlBQVksUUFBUSxDQUFDLElBQUksSUFBSSxJQUFJO0FBQUk7QUFDNUcsU0FBUyxhQUFhLEdBQUcsR0FBRztDQUFFLElBQUksWUFBWSxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsT0FBTztDQUFHLElBQUksSUFBSSxFQUFFLE9BQU87Q0FBYyxJQUFJLEtBQUssTUFBTSxHQUFHO0VBQUUsSUFBSSxJQUFJLEVBQUUsS0FBSyxHQUFHLENBQUM7RUFBRyxJQUFJLFlBQVksUUFBUSxDQUFDLEdBQUcsT0FBTztFQUFHLE1BQU0sSUFBSSxVQUFVLDhDQUE4QztDQUFHO0NBQUUsUUFBUSxhQUFhLElBQUksU0FBUyxPQUFBLENBQVEsQ0FBQztBQUFHO0FBQzlTLElBQUksU0FBUztDQUNYLE1BQU07Q0FDTixPQUFPO0VBQ0wsSUFBSTtHQUNGLE1BQU07R0FDTixXQUFXLEtBQUE7RUFDYjtFQUNBLFdBQVc7R0FDVCxNQUFNO0dBQ04sV0FBVyxLQUFBO0VBQ2I7RUFDQSxVQUFVO0dBQ1IsTUFBTTtHQUNOLFdBQVcsS0FBQTtFQUNiO0VBQ0EsSUFBSTtHQUNGLE1BQU07R0FDTixXQUFXLEtBQUE7RUFDYjtDQUNGO0NBQ0EsUUFBUSxFQUNOLGlCQUFpQixFQUNmLFdBQVcsS0FBQSxFQUNiLEVBQ0Y7Q0FDQSxPQUFPO0VBQ0wsWUFBWTtHQUNWLFdBQVc7R0FDWCxTQUFTLFNBQVMsUUFBUSxVQUFVO0lBQ2xDLEVBQWEsSUFBSSxnQkFBZ0IsS0FBSyxlQUFlO0lBQ3JELElBQUksQ0FBQyxVQUFVO0tBQ2IsS0FBSyxnQkFBZ0I7S0FDckIsS0FBSyxxQkFBcUIsS0FBSyxlQUFlO0lBQ2hEO0dBQ0Y7RUFDRjtFQUNBLElBQUk7R0FDRixXQUFXO0dBQ1gsU0FBUyxTQUFTLFFBQVEsVUFBVSxVQUFVO0lBQzVDLElBQUksUUFBUTtJQUNaLEVBQWEsSUFBSSxnQkFBZ0IsS0FBSyxvQkFBb0I7SUFDMUQsSUFBSSxVQUFVO0tBQ1osS0FBSyx1QkFBdUIsUUFBUTtLQUNwQyxLQUFLLHVCQUF1QixXQUFZO01BQ3RDLE9BQU8sTUFBTSx1QkFBdUIsUUFBUTtLQUM5QztLQUNBLEtBQUsscUJBQXFCLEtBQUssb0JBQW9CO0lBQ3JELE9BQ0UsS0FBSyx5QkFBeUI7R0FFbEM7RUFDRjtDQUNGO0NBQ0EsZUFBZSxLQUFBO0NBQ2YsS0FBSyxLQUFBO0NBQ0wsZUFBZSxLQUFBO0NBQ2YsY0FBYyxTQUFTLGVBQWU7RUFDcEMsSUFBSSxVQUFVLFdBQVcsV0FBVyxNQUFNLHFCQUFxQix1QkFBdUIsaUJBQWlCLGtCQUFrQixrQkFBa0IsT0FBTztFQUNsSixJQUFJLFVBQVUsV0FBVyxLQUFLLFFBQVEsUUFBUSxhQUFhLEtBQUssSUFBSSxLQUFLLElBQUksU0FBUztFQUN0RixJQUFJLGdCQUFnQixVQUFVLFlBQVksS0FBSyxRQUFRLFFBQVEsY0FBYyxLQUFLLE1BQU0sWUFBWSxVQUFVLG1CQUFtQixRQUFRLGNBQWMsS0FBSyxJQUFJLEtBQUssSUFBSSxVQUFVLEtBQUssRUFBRSxLQUFLLFFBQVEsS0FBQTtFQUV2TSxDQUFDLFFBRFcsVUFBVSxZQUFZLEtBQUssUUFBUSxRQUFRLGNBQWMsS0FBSyxNQUFNLFlBQVksVUFBVSxXQUFXLFFBQVEsY0FBYyxLQUFLLElBQUksS0FBSyxJQUFJLFVBQVUsS0FBSyxFQUFFLEtBQUssUUFBUSxLQUFLLE9BQzNLLG1CQUFtQixRQUFRLFNBQVMsS0FBSyxNQUFNLE9BQU8sS0FBSyxXQUFXLFFBQVEsU0FBUyxLQUFLLE1BQU0sc0JBQXNCLEtBQUssdUJBQXVCLFFBQVEsd0JBQXdCLEtBQUssS0FBSyxvQkFBb0IsS0FBSyxJQUFJO0VBQzVPLElBQUksa0JBQWtCLHdCQUF3QixLQUFLLHFCQUFxQixRQUFRLDBCQUEwQixLQUFLLE1BQU0sd0JBQXdCLHNCQUFzQixRQUFRLFFBQVEsMEJBQTBCLEtBQUssSUFBSSxLQUFLLElBQUksc0JBQXNCO0VBQ3JQLElBQUksd0JBQXdCLGtCQUFrQixrQkFBa0IsS0FBSyxlQUFlLFFBQVEsb0JBQW9CLEtBQUssTUFBTSxrQkFBa0IsZ0JBQWdCLFlBQVksUUFBUSxvQkFBb0IsS0FBSyxNQUFNLGtCQUFrQixnQkFBZ0IsUUFBUSxRQUFRLG9CQUFvQixLQUFLLElBQUksS0FBSyxJQUFJLGdCQUFnQixnQkFBZ0IsS0FBQTtFQUV4VSxDQUFDLFNBRG1CLGtCQUFrQixtQkFBbUIsS0FBSyxlQUFlLFFBQVEscUJBQXFCLEtBQUssTUFBTSxtQkFBbUIsaUJBQWlCLFlBQVksUUFBUSxxQkFBcUIsS0FBSyxNQUFNLG1CQUFtQixpQkFBaUIsUUFBUSxRQUFRLHFCQUFxQixLQUFLLElBQUksS0FBSyxJQUFJLGlCQUFpQixTQUFTLG1CQUFtQixLQUFLLGVBQWUsUUFBUSxxQkFBcUIsS0FBSyxNQUFNLG1CQUFtQixpQkFBaUIsWUFBWSxRQUFRLHFCQUFxQixLQUFLLElBQUksS0FBSyxJQUFJLGlCQUFpQixPQUN2ZSwyQkFBMkIsUUFBUSxVQUFVLEtBQUssTUFBTSxRQUFRLE1BQU0sS0FBSyxFQUFFLEtBQUssV0FBVyxRQUFRLFVBQVUsS0FBSyxNQUFNLFFBQVEsTUFBTSxXQUFXLFFBQVEsVUFBVSxLQUFLLE1BQU0sdUJBQXVCLE1BQU0sdUJBQXVCLFFBQVEseUJBQXlCLEtBQUssS0FBSyxxQkFBcUIsS0FBSyxLQUFLO0VBQ3hVLEtBQUssZ0JBQWdCLGdCQUFnQjtFQUNyQyxLQUFLLE1BQU0sS0FBSyxPQUFPLE1BQU0sS0FBSyxjQUFjLFFBQVEsTUFBTSxRQUFRO0NBQ3hFO0NBQ0EsU0FBUyxTQUFTLFVBQVU7RUFDMUIsS0FBSyxNQUFNLFdBQVc7Q0FDeEI7Q0FDQSxhQUFhLFNBQVMsY0FBYztFQUNsQyxLQUFLLFlBQVk7RUFDakIsS0FBSyxNQUFNLGVBQWU7Q0FDNUI7Q0FDQSxTQUFTLFNBQVMsVUFBVTtFQUMxQixJQUFJO0VBQ0osS0FBSyxNQUFNLFdBQVc7RUFDdEIsSUFBSSxDQUFDLEtBQUssZUFBZSx3QkFBd0IsS0FBSyxVQUFVLGNBQWMsUUFBUSwwQkFBMEIsS0FBSyxJQUFJLEtBQUssSUFBSSxzQkFBc0IsV0FBVyxPQUNqSyx5QkFBeUI7Q0FFN0I7Q0FDQSxjQUFjLFNBQVMsZUFBZTtFQUNwQyxLQUFLLE1BQU0sZ0JBQWdCO0NBQzdCO0NBQ0EsU0FBUyxTQUFTLFVBQVU7RUFDMUIsS0FBSyxNQUFNLFdBQVc7Q0FDeEI7Q0FDQSxlQUFlLFNBQVMsZ0JBQWdCO0VBQ3RDLEtBQUssTUFBTSxpQkFBaUI7Q0FDOUI7Q0FDQSxXQUFXLFNBQVMsWUFBWTtFQUM5QixLQUFLLHNCQUFzQjtFQUMzQixLQUFLLHlCQUF5QjtFQUM5QixLQUFLLE1BQU0sYUFBYTtDQUMxQjtDQUNBLFNBQVM7RUFDUCxPQUFPLFNBQVMsTUFBTSxVQUFVO0dBQzlCLElBQUksQ0FBQyxLQUFLLFNBQVMsVUFBVTtJQUMzQixJQUFJLFdBQVcsS0FBSyxPQUFPLEtBQUssT0FBTyxLQUFLLElBQUksS0FBSyxFQUFFLEtBQUssSUFBSSxHQUFHLEtBQUssaUJBQWlCLFNBQVMsT0FBTyxRQUFRLENBQUM7SUFDbEgsSUFBSSxjQUFjLEtBQUssY0FBYyxLQUFLLGlCQUFpQixTQUFTLE9BQU8sUUFBUSxDQUFDO0lBQ3BGLGFBQWEsUUFBUSxhQUFhLEtBQUssS0FBSyxTQUFTO0lBQ3JELGdCQUFnQixRQUFRLGdCQUFnQixLQUFLLEtBQUssWUFBWTtHQUNoRTtFQUNGO0VBQ0EsYUFBYSxTQUFTLFlBQVksSUFBSTtHQUNwQyxLQUFLLElBQUksT0FBTyxVQUFVLFFBQVEsT0FBTyxJQUFJLE1BQU0sT0FBTyxJQUFJLE9BQU8sSUFBSSxDQUFDLEdBQUcsUUFBUSxHQUFHLFFBQVEsTUFBTSxTQUNwRyxLQUFLLFFBQVEsS0FBSyxVQUFVO0dBRTlCLE9BQU9BLEVBQVcsRUFBRSxJQUFJLEdBQUcsTUFBTSxLQUFLLEdBQUcsSUFBSSxJQUFJLFdBQVcsTUFBTSxLQUFLLEdBQUcsSUFBSTtFQUNoRjtFQUNBLE9BQU8sU0FBUyxRQUFRO0dBRXRCLElBQUksQ0FBQyxLQUFLLGtCQUFrQixNQUFNLEdBQUc7SUFDbkMsVUFBVSxRQUFRLEtBQUssYUFBYTtJQUNwQyxLQUFLLGtCQUFrQjtJQUN2QixLQUFLLG1CQUFtQixNQUFNO0dBQ2hDO0dBQ0EsS0FBSyxpQkFBaUI7RUFDeEI7RUFDQSxhQUFhLFNBQVMsY0FBYztHQUNsQyxLQUFLLE1BQU07R0FDWCxLQUFLLHFCQUFxQixLQUFLLEtBQUs7RUFDdEM7RUFDQSxpQkFBaUIsU0FBUyxrQkFBa0I7R0FDMUMsSUFBSSxjQUFjO0dBQ2xCLElBQUksQ0FBQyxLQUFLLG1CQUFtQixlQUFlLEtBQUssWUFBWSxRQUFRLGlCQUFpQixLQUFLLElBQUksS0FBSyxJQUFJLGFBQWEsSUFBSSxNQUFNLGdCQUFnQixLQUFLLFlBQVksUUFBUSxrQkFBa0IsS0FBSyxLQUFLLGNBQWMsTUFBTTtJQUN0TixtQkFBbUIsUUFBUSxLQUFLLGFBQWE7SUFDN0MsS0FBSyxTQUFTLFNBQVMsS0FBSyxPQUFPLFFBQVEsS0FBSyxhQUFhO0lBQzdELEtBQUssbUJBQW1CLEtBQUssT0FBTyxJQUFJO0dBQzFDO0VBQ0Y7RUFDQSxtQkFBbUIsU0FBUyxvQkFBb0I7R0FXOUMsSUFBSSxZQUFZLEtBQUssYUFBYSxLQUFLLGlCQUFpQixjQUFjLEtBQUssT0FBTztHQUNsRixFQUFXLFNBQVMsS0FBSyxVQUFVLEtBQUssV0FBVyxjQUFjLEVBQy9ELE1BQU0sU0FDUixHQUFHLEtBQUssYUFBYSxDQUFDO0VBQ3hCO0VBQ0Esa0JBQWtCLFNBQVMsbUJBQW1CO0dBQzVDLElBQUksZUFBZTtHQUNuQixJQUFJLEtBQUssY0FBYyxLQUFLLFdBQVcsUUFBUTtHQUcvQyxJQUFJLENBQUNDLEVBQU0sa0JBQWtCLFFBQVEsR0FBRztJQUN0QyxJQUFJLGVBQWU7SUFDbkIsSUFBSSxVQUFVLGdCQUFnQixLQUFLLFlBQVksUUFBUSxrQkFBa0IsS0FBSyxNQUFNLHdCQUF3QixjQUFjLG9CQUFvQixRQUFRLDBCQUEwQixLQUFLLElBQUksS0FBSyxJQUFJLHNCQUFzQixLQUFLLGFBQWEsTUFBTSxDQUFDLEdBQy9PLFlBQVksTUFBTSxXQUNsQixXQUFXLE1BQU0sVUFDakIsU0FBUyxNQUFNLFFBQ2YsUUFBUSxNQUFNO0lBQ2hCLFVBQVUsS0FBSyxjQUFjLFFBQVEsY0FBYyxLQUFLLElBQUksS0FBSyxJQUFJLFVBQVUsS0FBSyxjQUFjLEVBQ2hHLE1BQU0sc0JBQ1IsR0FBRyxLQUFLLGFBQWEsQ0FBQztJQUN0QixVQUFVLEtBQUssYUFBYSxRQUFRLGFBQWEsS0FBSyxJQUFJLEtBQUssSUFBSSxTQUFTLEtBQUssY0FBYyxFQUM3RixNQUFNLHFCQUNSLEdBQUcsS0FBSyxhQUFhLENBQUM7SUFDdEIsVUFBVSxLQUFLLFdBQVcsUUFBUSxXQUFXLEtBQUssSUFBSSxLQUFLLElBQUksT0FBTyxLQUFLLGNBQWMsRUFDdkYsTUFBTSxtQkFDUixHQUFHLEtBQUssYUFBYSxDQUFDO0lBQ3RCLFVBQVUsVUFBVSxjQUFjLEVBQ2hDLE1BQU0sZUFDUixHQUFHLEtBQUssYUFBYSxHQUFHLEtBQUs7SUFDN0IsRUFBTSxtQkFBbUIsUUFBUTtHQUNuQztHQUdBLElBQUksQ0FBQ0EsRUFBTSxtQkFBbUIsZ0JBQWdCLEtBQUssWUFBWSxRQUFRLGtCQUFrQixLQUFLLElBQUksS0FBSyxJQUFJLGNBQWMsSUFBSSxNQUFNLGdCQUFnQixLQUFLLFlBQVksUUFBUSxrQkFBa0IsS0FBSyxLQUFLLGNBQWMsTUFBTTtJQUMxTixJQUFJLGVBQWUsdUJBQXVCLGVBQWU7SUFDekQsSUFBSSxVQUFVLGdCQUFnQixLQUFLLFlBQVksUUFBUSxrQkFBa0IsS0FBSyxNQUFNLHdCQUF3QixjQUFjLHVCQUF1QixRQUFRLDBCQUEwQixLQUFLLElBQUksS0FBSyxJQUFJLHNCQUFzQixLQUFLLGFBQWEsTUFBTSxDQUFDLEdBQ2xQLE1BQU0sTUFBTSxLQUNaLFNBQVMsTUFBTTtJQUNqQixDQUFDLGdCQUFnQixLQUFLLFlBQVksUUFBUSxrQkFBa0IsS0FBSyxLQUFLLGNBQWMsS0FBSyxLQUFLLGNBQWMsRUFDMUcsTUFBTSxHQUFHLE9BQU8sS0FBSyxPQUFPLE1BQU0sWUFBWSxFQUNoRCxHQUFHLEtBQUssYUFBYSxDQUFDO0lBQ3RCLENBQUMsZ0JBQWdCLEtBQUssWUFBWSxRQUFRLGtCQUFrQixLQUFLLEtBQUssY0FBYyxVQUFVLGNBQWMsRUFDMUcsTUFBTSxHQUFHLE9BQU8sS0FBSyxPQUFPLE1BQU0sUUFBUSxFQUM1QyxHQUFHLEtBQUssYUFBYSxHQUFHLE1BQU07SUFDOUIsRUFBTSxtQkFBbUIsS0FBSyxPQUFPLElBQUk7R0FDM0M7R0FHQSxJQUFJLENBQUNBLEVBQU0sa0JBQWtCLGFBQWEsR0FBRztJQUMzQyxJQUFJLGVBQWU7SUFDbkIsSUFBSSxjQUFjLGdCQUFnQixLQUFLLFlBQVksUUFBUSxrQkFBa0IsS0FBSyxNQUFNLHdCQUF3QixjQUFjLDJCQUEyQixRQUFRLDBCQUEwQixLQUFLLElBQUksS0FBSyxJQUFJLHNCQUFzQixLQUFLLGFBQWE7SUFDclAsVUFBVSxLQUFLLFlBQVksY0FBYztLQUN2QyxNQUFNO0tBQ04sT0FBTztJQUNULEdBQUcsS0FBSyxhQUFhLENBQUM7SUFDdEIsRUFBTSxtQkFBbUIsYUFBYTtHQUN4QztFQUNGO0VBQ0Esd0JBQXdCLFNBQVMsdUJBQXVCLFFBQVE7R0FDOUQsSUFBSSxjQUFjLGVBQWUsZUFBZSx1QkFBdUI7R0FDdkUsTUFBTSxlQUFlLEtBQUssWUFBWSxRQUFRLGlCQUFpQixLQUFLLE1BQU0sZUFBZSxhQUFhLGFBQWEsUUFBUSxpQkFBaUIsS0FBSyxJQUFJLEtBQUssSUFBSSxhQUFhLGtCQUFrQixVQUFVLGdCQUFnQixLQUFLLFlBQVksUUFBUSxrQkFBa0IsS0FBSyxLQUFLLGNBQWMsTUFDNVFBO1FBQUFBLEVBQU0sZUFBZSxnQkFBZ0IsQ0FBQyxHQUFHLEtBQUssT0FBTyxNQUFNLE1BQU0sQ0FDckUsR0FBRztLQUNULEVBQU0sc0JBQXNCLEtBQUssT0FBTyxJQUFJO0tBQzVDLEtBQUssaUJBQWlCO0lBQ3hCOztHQUVGLElBQ0UsU0FEWSxnQkFBZ0IsS0FBSyxZQUFZLFFBQVEsa0JBQWtCLEtBQUssTUFBTSx3QkFBd0IsY0FBYyxvQkFBb0IsUUFBUSwwQkFBMEIsS0FBSyxJQUFJLEtBQUssSUFBSSxzQkFBc0IsS0FBSyxlQUFlLFFBQVEsSUFBSSxPQUFPLEtBQUssZUFBZSxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUEsQ0FDaFI7R0FDZCxJQUFJLGVBQWUsaUJBQWlCLEtBQUssWUFBWSxRQUFRLG1CQUFtQixLQUFLLElBQUksS0FBSyxJQUFJLGVBQWUsS0FBSyxLQUFLLGNBQWMsRUFDdkksTUFBTSxHQUFHLE9BQU8sS0FBSyxlQUFlLEdBQUcsQ0FBQyxDQUFDLE9BQU8sS0FBSyxPQUFPLElBQUksRUFDbEUsR0FBRyxLQUFLLGFBQWEsQ0FBQztHQUN0QixLQUFLLGdCQUFnQixnQkFBZ0IsUUFBUSxnQkFBZ0IsS0FBSyxJQUFJLEtBQUssSUFBSSxZQUFZO0VBQzdGO0VBQ0EsMEJBQTBCLFNBQVMsMkJBQTJCO0dBQzVELElBQUk7R0FDSixDQUFDLHNCQUFzQixLQUFLLG1CQUFtQixRQUFRLHdCQUF3QixLQUFLLE1BQU0sc0JBQXNCLG9CQUFvQixXQUFXLFFBQVEsd0JBQXdCLEtBQUssS0FBSyxvQkFBb0IsT0FBTztFQUN0TjtFQUNBLHNCQUFzQixTQUFTLHVCQUF1QjtHQUNwRCxJQUFJLFdBQVcsVUFBVSxTQUFTLEtBQUssVUFBVSxPQUFPLEtBQUEsSUFBWSxVQUFVLEtBQUssV0FBWSxDQUFDO0dBQ2hHLEtBQUssc0JBQXNCO0dBQzNCLEVBQWEsR0FBRyxnQkFBZ0IsUUFBUTtFQUMxQztFQUNBLHVCQUF1QixTQUFTLHdCQUF3QjtHQUN0RCxFQUFhLElBQUksZ0JBQWdCLEtBQUssZUFBZTtHQUNyRCxFQUFhLElBQUksZ0JBQWdCLEtBQUssS0FBSztHQUMzQyxFQUFhLElBQUksZ0JBQWdCLEtBQUssb0JBQW9CO0VBQzVEO0VBQ0Esa0JBQWtCLFNBQVMsaUJBQWlCLFVBQVU7R0FDcEQsT0FBTyxXQUFXLEtBQUssU0FBUyxXQUFXLFNBQVMsRUFBRSxLQUFLLFNBQVMsS0FBSyxTQUFTLFdBQVcsV0FBVyxLQUFLLGlCQUFpQixTQUFTLGVBQWUsSUFBSSxTQUFTLGtCQUFrQixLQUFBO0VBQ3ZMO0VBQ0EsZUFBZSxTQUFTLGNBQWMsTUFBTTtHQUMxQyxJQUFJO0dBQ0osT0FBTyxLQUFLLFdBQVcsd0JBQXdCLEtBQUssaUJBQWlCLElBQUksT0FBTyxRQUFRLDBCQUEwQixLQUFLLElBQUksS0FBSyxJQUFJLHNCQUFzQjtFQUM1SjtFQUNBLGlCQUFpQixTQUFTLGdCQUFnQixTQUFTO0dBQ2pELElBQUksTUFBTSxVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sS0FBQSxJQUFZLFVBQVUsS0FBSztHQUM5RSxJQUFJLFNBQVMsVUFBVSxTQUFTLEtBQUssVUFBVSxPQUFPLEtBQUEsSUFBWSxVQUFVLEtBQUssQ0FBQztHQUNsRixPQUFPQyxFQUFZLFNBQVMsS0FBSyxNQUFNO0VBQ3pDO0VBQ0EsYUFBYSxTQUFTLGNBQWM7R0FDbEMsSUFBSTtHQUNKLElBQUksTUFBTSxVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sS0FBQSxJQUFZLFVBQVUsS0FBSyxDQUFDO0dBQy9FLElBQUksTUFBTSxVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sS0FBQSxJQUFZLFVBQVUsS0FBSztHQUM5RSxJQUFJLFNBQVMsVUFBVSxTQUFTLEtBQUssVUFBVSxPQUFPLEtBQUEsSUFBWSxVQUFVLEtBQUssQ0FBQztHQUNsRixJQUFJLG9CQUFvQixVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sS0FBQSxJQUFZLFVBQVUsS0FBSztHQUM1RixJQUFJLFlBQVksS0FBSyxLQUFLLEdBQUcsS0FBSyxDQUFDLENBQUMsT0FBTyxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUM7R0FDMUQsSUFBSSxRQUFRLEtBQUssY0FBYyxXQUFXLE9BQU8seUJBQXlCLEtBQUsscUJBQXFCLFFBQVEsMkJBQTJCLEtBQUssSUFBSSxLQUFLLElBQUksdUJBQXVCLGNBQWMsQ0FBQyxHQUM3TCxzQkFBc0IsTUFBTSxlQUM1QixnQkFBZ0Isd0JBQXdCLEtBQUssSUFBSSxPQUFPLHFCQUN4RCxtQkFBbUIsTUFBTSxZQUN6QixnQkFBZ0IscUJBQXFCLEtBQUssSUFBSSxRQUFRO0dBQ3hELElBQUksU0FBUyxvQkFBb0IsWUFBWSxLQUFLLGFBQWEsS0FBSyxrQkFBa0IsS0FBSyxNQUFNLElBQUksS0FBSyxjQUFjLEtBQUssa0JBQWtCLEtBQUssTUFBTSxJQUFJLEtBQUE7R0FDOUosSUFBSSxPQUFPLFlBQVksS0FBQSxJQUFZLEtBQUssV0FBVyxLQUFLLEtBQUssa0JBQWtCLEtBQUssY0FBYyxjQUFjLENBQUMsR0FBRyxNQUFNLEdBQUcsQ0FBQyxHQUFHLEVBQy9ILFFBQVEsVUFBVSxDQUFDLEVBQ3JCLENBQUMsQ0FBQztHQUNGLElBQUksV0FBVyxLQUFLLGVBQWUsR0FBRztHQUN0QyxPQUFPLGlCQUFpQixDQUFDLGlCQUFpQixPQUFPLGdCQUFnQixLQUFLLFlBQVksZUFBZSxRQUFRLE1BQU0sUUFBUSxJQUFJLGNBQWMsY0FBYyxjQUFjLENBQUMsR0FBRyxNQUFNLEdBQUcsSUFBSSxHQUFHLFFBQVEsSUFBSSxjQUFjLGNBQWMsQ0FBQyxHQUFHLElBQUksR0FBRyxRQUFRO0VBQ3RQO0VBQ0EsWUFBWSxTQUFTLGFBQWE7R0FDaEMsSUFBSSxNQUFNLFVBQVUsU0FBUyxLQUFLLFVBQVUsT0FBTyxLQUFBLElBQVksVUFBVSxLQUFLLENBQUM7R0FDL0UsS0FBSyxJQUFJLFFBQVEsVUFBVSxRQUFRLE9BQU8sSUFBSSxNQUFNLFFBQVEsSUFBSSxRQUFRLElBQUksQ0FBQyxHQUFHLFFBQVEsR0FBRyxRQUFRLE9BQU8sU0FDeEcsS0FBSyxRQUFRLEtBQUssVUFBVTtHQUU5QixPQUFPLFdBQVcsS0FBSyxPQUFPLE1BQU0sTUFBTSxDQUFDLEtBQUssT0FBTyxLQUFLLEtBQUssS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLElBQUksQ0FBQyxHQUVyRixLQUFLLE9BQU8sTUFBTSxNQUFNLENBQUMsS0FBSyxTQUFTLENBQUMsQ0FBQyxPQUFPLElBQUksQ0FBQyxDQUNyRDtFQUNGO0VBQ0EsZ0JBQWdCLFNBQVMsaUJBQWlCO0dBQ3hDLElBQUksV0FBVztHQUNmLElBQUksTUFBTSxVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sS0FBQSxJQUFZLFVBQVUsS0FBSztHQUM5RSxJQUFJLGdCQUFnQjtHQUNwQixJQUFJLGFBQWEsUUFBUSxVQUFVQyxHQUFZLFlBQVksS0FBSyxRQUFRLFFBQVEsY0FBYyxLQUFLLElBQUksS0FBSyxJQUFJLFVBQVUsa0JBQWtCO0dBQzVJLE9BQU8sUUFBUSxnQkFBZ0IsY0FBYyxjQUFjLENBQUMsR0FBRyxRQUFRLFVBQVUsY0FBYyxjQUFjLGdCQUFnQixDQUFDLEdBQUcsR0FBRyxPQUFPLGVBQWUsTUFBTSxHQUFHQyxFQUFXLGNBQWMsWUFBWSxLQUFLLFFBQVEsUUFBUSxjQUFjLEtBQUssSUFBSSxLQUFLLElBQUksVUFBVSxxQkFBcUIsS0FBSyxFQUFFLEtBQUssSUFBSSxDQUFDLEdBQUcsY0FBYyxnQkFBZ0IsQ0FBQyxHQUFHLEdBQUcsT0FBTyxlQUFlLFFBQVEsR0FBR0EsRUFBVyxLQUFLLEVBQUUsS0FBSyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQyxHQUFHLEdBQUcsT0FBTyxLQUFLLGFBQWEsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQyxHQUFHLEdBQUcsT0FBTyxlQUFlLFNBQVMsR0FBR0EsRUFBVyxHQUFHLENBQUMsQ0FBQztFQUNuaUI7RUFDQSxrQkFBa0IsU0FBUyxtQkFBbUI7R0FDNUMsSUFBSSxRQUFRLEtBQUssZ0JBQWdCLE1BQU0sTUFBTSxTQUFTO0dBQ3RELE9BQU9DLEVBQVMsS0FBSyxLQUFLQyxFQUFRLEtBQUssSUFBSSxFQUN6QyxTQUFTLE1BQ1gsSUFBSTtFQUNOO0VBQ0EsUUFBUSxTQUFTLE9BQU8sSUFBSTtHQUMxQixJQUFJLFNBQVM7R0FDYixJQUFJLE1BQU0sVUFBVSxTQUFTLEtBQUssVUFBVSxPQUFPLEtBQUEsSUFBWSxVQUFVLEtBQUs7R0FDOUUsSUFBSSxXQUFXLFVBQVUsU0FBUyxJQUFJLFVBQVUsS0FBSyxLQUFBO0dBQ3JELElBQUksV0FBVyxTQUFTLFNBQVMsT0FBTztJQUN0QyxJQUFJO0lBQ0osSUFBSSxlQUFlLFVBQVUsU0FBUyxLQUFLLFVBQVUsT0FBTyxLQUFBLElBQVksVUFBVSxLQUFLO0lBQ3ZGLElBQUksZ0JBQWdCLFdBQVcsU0FBUyxLQUFLLElBQUk7SUFDakQsSUFBSSxPQUFPRixFQUFXLEdBQUc7SUFDekIsSUFBSSxRQUFRQSxFQUFXLE9BQU8sS0FBSztJQUNuQyxRQUFRLFFBQVEsZUFBZSxTQUFTLFFBQVEsa0JBQWtCLFFBQVEsa0JBQWtCLEtBQUssSUFBSSxLQUFLLElBQUksY0FBYyxRQUFRLEtBQUEsSUFBWSxrQkFBa0IsUUFBUSxrQkFBa0IsS0FBSyxJQUFJLEtBQUssSUFBSSxjQUFjLFdBQVcsUUFBUSxVQUFVLEtBQUssSUFBSSxRQUFRO0dBQzVRO0dBQ0EsT0FBTyxPQUFPLFFBQVEsT0FBTyxLQUFLLEtBQUssR0FBRyxlQUFlLFFBQVEsSUFBSTtJQUNuRSxRQUFRLEdBQUc7SUFDWCxlQUFlLFNBQVMsR0FBRyxhQUFhO0lBQ3hDLE9BQU8sU0FBUyxHQUFHLEtBQUs7R0FDMUIsSUFBSSxTQUFTLElBQUksSUFBSTtFQUN2QjtFQUNBLFFBQVEsU0FBUyxPQUFPLElBQUksVUFBVSxLQUFLLFFBQVE7R0FDakQsSUFBSSxLQUFLLFNBQVMsR0FBRyxPQUFPO0lBQzFCLE9BQU8sU0FBUyxPQUFPLEtBQUssTUFBTTtHQUNwQztHQUNBLElBQUksT0FBTyxRQUFRLE9BQU8sS0FBSyxLQUFLLEdBQUcsZUFBZSxRQUFRLEdBQUc7SUFDL0QsSUFBSTtJQUNKLElBQUksUUFBUSxHQUFHLGVBQWUseUJBQXlCLEtBQUsscUJBQXFCLFFBQVEsMkJBQTJCLEtBQUssSUFBSSxLQUFLLElBQUksdUJBQXVCLGNBQWMsQ0FBQyxHQUMxSyxzQkFBc0IsTUFBTSxlQUM1QixnQkFBZ0Isd0JBQXdCLEtBQUssSUFBSSxPQUFPLHFCQUN4RCxtQkFBbUIsTUFBTSxZQUN6QixnQkFBZ0IscUJBQXFCLEtBQUssSUFBSSxRQUFRO0lBQ3hELElBQUksZ0JBQWdCLEdBQUcsR0FBRyxhQUFhO0lBQ3ZDLElBQUksUUFBUSxHQUFHLEdBQUcsS0FBSztJQUN2QixJQUFJLGtCQUFrQixLQUFBLEtBQWEsVUFBVSxLQUFBLEdBQVcsT0FBTyxLQUFBO1NBQWUsSUFBSUMsRUFBUyxLQUFLLEdBQUcsT0FBTztTQUFXLElBQUlBLEVBQVMsYUFBYSxHQUFHLE9BQU87SUFDekosT0FBTyxpQkFBaUIsQ0FBQyxpQkFBaUIsUUFBUSxnQkFBZ0IsS0FBSyxZQUFZLGVBQWUsZUFBZSxLQUFLLElBQUksY0FBYyxjQUFjLENBQUMsR0FBRyxhQUFhLEdBQUcsS0FBSyxJQUFJO0dBQ3JMO0dBQ0EsT0FBTyxHQUFHLEVBQUU7RUFDZDtFQUNBLGNBQWMsU0FBUyxhQUFhLFVBQVUsS0FBSyxRQUFRO0dBQ3pELE9BQU8sS0FBSyxPQUFPLEtBQUssVUFBVSxVQUFVLEtBQUssTUFBTTtFQUN6RDtFQUNBLGVBQWUsU0FBUyxjQUFjLFVBQVUsS0FBSyxRQUFRO0dBQzNELE9BQU8sS0FBSyxPQUFPLEtBQUssV0FBVyxVQUFVLEtBQUssTUFBTTtFQUMxRDtFQUNBLEtBQUssU0FBUyxNQUFNO0dBQ2xCLElBQUksTUFBTSxVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sS0FBQSxJQUFZLFVBQVUsS0FBSztHQUM5RSxJQUFJLFNBQVMsVUFBVSxTQUFTLEtBQUssVUFBVSxPQUFPLEtBQUEsSUFBWSxVQUFVLEtBQUssQ0FBQztHQUNsRixPQUFPLEtBQUssWUFBWSxLQUFLLElBQUksS0FBSyxjQUFjLGNBQWMsQ0FBQyxHQUFHLEtBQUssT0FBTyxHQUFHLE1BQU0sQ0FBQztFQUM5RjtFQUNBLE1BQU0sU0FBUyxPQUFPO0dBQ3BCLElBQUk7R0FDSixJQUFJLE1BQU0sVUFBVSxTQUFTLEtBQUssVUFBVSxPQUFPLEtBQUEsSUFBWSxVQUFVLEtBQUs7R0FDOUUsSUFBSSxTQUFTLFVBQVUsU0FBUyxLQUFLLFVBQVUsT0FBTyxLQUFBLElBQVksVUFBVSxLQUFLLENBQUM7R0FFbEYsSUFBSSxRQUFRLFdBQVcsS0FBSyxrQkFBa0IsS0FBSyxJQUFJLEtBQUssTUFBTSxDQUFDO0dBQ25FLFVBQVcsUUFBUSxVQUFVLEtBQUssS0FBYSxNQUFNLGVBQWUsSUFBSSxPQUFRLFlBQVksTUFBTSxRQUFRLFFBQVEsY0FBYyxLQUFLLE1BQWdCLE1BQU0sS0FBSyxLQUFLO0dBQ3JLLE9BQU87RUFDVDtFQUNBLE1BQU0sU0FBUyxPQUFPO0dBQ3BCLElBQUksTUFBTSxVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sS0FBQSxJQUFZLFVBQVUsS0FBSyxDQUFDO0dBQy9FLElBQUksTUFBTSxVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sS0FBQSxJQUFZLFVBQVUsS0FBSztHQUM5RSxJQUFJLFNBQVMsVUFBVSxTQUFTLEtBQUssVUFBVSxPQUFPLEtBQUEsSUFBWSxVQUFVLEtBQUssQ0FBQztHQUNsRixPQUFPLEtBQUssWUFBWSxLQUFLLEtBQUssY0FBYyxFQUM5QyxVQUFVLEtBQ1osR0FBRyxNQUFNLEdBQUcsS0FBSztFQUNuQjtFQUNBLElBQUksU0FBUyxLQUFLO0dBQ2hCLElBQUksTUFBTSxVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sS0FBQSxJQUFZLFVBQVUsS0FBSztHQUM5RSxJQUFJLFNBQVMsVUFBVSxTQUFTLEtBQUssVUFBVSxPQUFPLEtBQUEsSUFBWSxVQUFVLEtBQUssQ0FBQztHQUNsRixPQUFPLENBQUMsS0FBSyxhQUFhLEtBQUssZ0JBQWdCLEtBQUssT0FBTyxTQUFTLEtBQUssY0FBYyxjQUFjLENBQUMsR0FBRyxLQUFLLE9BQU8sR0FBRyxNQUFNLENBQUMsSUFBSSxLQUFBO0VBQ3JJO0VBQ0EsSUFBSSxTQUFTLEtBQUs7R0FDaEIsSUFBSSxNQUFNLFVBQVUsU0FBUyxLQUFLLFVBQVUsT0FBTyxLQUFBLElBQVksVUFBVSxLQUFLO0dBQzlFLElBQUksT0FBTyxVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sS0FBQSxJQUFZLFVBQVUsS0FBSztHQUMvRSxJQUFJLFNBQVMsVUFBVSxTQUFTLEtBQUssVUFBVSxPQUFPLEtBQUEsSUFBWSxVQUFVLEtBQUssQ0FBQztHQUNsRixJQUFJLE1BQU07SUFDUixJQUFJLE9BQU8sS0FBSyxnQkFBZ0IsS0FBSyxPQUFPLGNBQWMsS0FBSyxjQUFjLGNBQWMsQ0FBQyxHQUFHLEtBQUssT0FBTyxHQUFHLE1BQU0sQ0FBQztJQUVySCxPQUFPLENBREksS0FBSyxnQkFBZ0IsbUJBQW1CLGNBQWMsS0FBSyxjQUFjLGNBQWMsQ0FBQyxHQUFHLEtBQUssT0FBTyxHQUFHLE1BQU0sQ0FDaEgsR0FBRyxJQUFJO0dBQ3BCO0VBRUY7Q0FDRjtDQUNBLFVBQVU7RUFDUixVQUFVLFNBQVMsV0FBVztHQUM1QixJQUFJLHdCQUNGLFNBQVM7R0FDWCxPQUFPLEtBQUssUUFBUSx5QkFBeUIsS0FBSyxxQkFBcUIsUUFBUSwyQkFBMkIsS0FBSyxJQUFJLEtBQUssSUFBSSx1QkFBdUIsSUFBSSxLQUFBLEdBQVcsU0FBVSxPQUFPO0lBQ2pMLE9BQU9FLEVBQVEsT0FBTyxFQUNwQixVQUFVLE9BQ1osQ0FBQztHQUNILENBQUM7RUFDSDtFQUNBLFdBQVcsU0FBUyxZQUFZO0dBQzlCLElBQUksd0JBQ0YsU0FBUztHQUNYLE9BQU8sS0FBSyxRQUFRLHlCQUF5QixLQUFLLHFCQUFxQixRQUFRLDJCQUEyQixLQUFLLElBQUksS0FBSyxJQUFJLHVCQUF1QixJQUFJLEtBQUEsR0FBVyxTQUFVLE9BQU87SUFDakwsT0FBTyxPQUFPLGdCQUFnQixPQUFPLE9BQU8sT0FBTyxjQUFjLENBQUMsR0FBRyxPQUFPLE9BQU8sQ0FBQyxLQUFLQSxFQUFRLE9BQU8sY0FBYyxDQUFDLEdBQUcsT0FBTyxPQUFPLENBQUM7R0FDM0ksQ0FBQztFQUNIO0VBQ0EsWUFBWSxTQUFTLGFBQWE7R0FDaEMsSUFBSTtHQUNKLE9BQU8sS0FBSyxhQUFhLEtBQUEsSUFBWSxLQUFLLFlBQVkseUJBQXlCLEtBQUsscUJBQXFCLFFBQVEsMkJBQTJCLEtBQUssSUFBSSxLQUFLLElBQUksdUJBQXVCO0VBQ3ZMO0VBQ0EsS0FBSyxTQUFTLE1BQU07R0FDbEIsT0FBTyxLQUFLLE9BQU8sTUFBTSxLQUFLO0VBQ2hDO0VBQ0EsVUFBVSxTQUFTLFdBQVc7R0FDNUIsSUFBSTtHQUNKLElBQUksZUFBZSxPQUFPLE9BQU8sZ0JBQWdCLEtBQUssRUFBRSxXQUFXLFFBQVEsa0JBQWtCLEtBQUssSUFBSSxLQUFLLElBQUksY0FBYyxVQUFVLENBQUMsQ0FBQztHQUN6SSxPQUFPLE9BQU8sWUFBWSxPQUFPLFFBQVEsS0FBSyxNQUFNLENBQUMsQ0FBQyxPQUFPLFNBQVUsT0FBTztJQUM1RSxJQUNFLElBRFUsZUFBZSxPQUFPLENBQ3hCLENBQUMsQ0FBQztJQUNaLE9BQU8saUJBQWlCLFFBQVEsaUJBQWlCLEtBQUssSUFBSSxLQUFLLElBQUksYUFBYSxTQUFTLENBQUM7R0FDNUYsQ0FBQyxDQUFDO0VBQ0o7RUFDQSxRQUFRLFNBQVMsU0FBUztHQUN4QixJQUFJO0dBQ0osUUFBUSx5QkFBeUIsS0FBSyxxQkFBcUIsUUFBUSwyQkFBMkIsS0FBSyxJQUFJLEtBQUssSUFBSSx1QkFBdUI7RUFDekk7RUFDQSxRQUFRLFNBQVMsU0FBUztHQUN4QixPQUFPLGNBQWMsY0FBYztJQUNqQyxTQUFTLEtBQUE7SUFDVCxjQUFjLEtBQUE7SUFDZCxNQUFNLFNBQVMsT0FBTyxDQUFDO0lBQ3ZCLFNBQVMsU0FBUyxVQUFVLENBQUM7SUFDN0IsV0FBVyxTQUFTLFlBQVksQ0FBQztHQUNuQyxJQUFJLEtBQUssaUJBQWlCLElBQUksS0FBSyxDQUFDLEVBQUEsQ0FBRyxNQUFNLEdBQUcsS0FBSyxTQUFTLEtBQUs7RUFDckU7RUFDQSxlQUFlLFNBQVMsZ0JBQWdCO0dBQ3RDLElBQUk7R0FDSixPQUFPLEVBQ0wsUUFBUSx5QkFBeUIsS0FBSyxxQkFBcUIsUUFBUSwyQkFBMkIsS0FBSyxNQUFNLHlCQUF5Qix1QkFBdUIsU0FBUyxRQUFRLDJCQUEyQixLQUFLLElBQUksS0FBSyxJQUFJLHVCQUF1QixNQUNoUDtFQUNGO0VBQ0EsaUJBQWlCLFNBQVMsa0JBQWtCO0dBQzFDLElBQUk7R0FDSixRQUFRLG1CQUFtQixLQUFLLGVBQWUsUUFBUSxxQkFBcUIsS0FBSyxJQUFJLEtBQUssSUFBSSxpQkFBaUI7RUFDakg7RUFDQSxPQUFPLFNBQVMsUUFBUTtHQUN0QixPQUFPLEtBQUssU0FBUyxZQUFZLEtBQUssRUFBRSxLQUFLO0VBQy9DO0VBQ0EsU0FBUyxTQUFTLFVBQVU7R0FDMUIsSUFBSSxpQkFBaUIsS0FBSyxpQkFBaUIsSUFBSSxLQUFLLEtBQUs7R0FDekQsT0FBTztJQUNMLFVBQVU7SUFDVixPQUFPLEtBQUs7SUFDWixPQUFPLEtBQUs7SUFDWixPQUFPLEtBQUs7SUFDWixRQUFRO0tBQ04sVUFBVTtLQUNWLE9BQU8sbUJBQW1CLFFBQVEsbUJBQW1CLEtBQUssSUFBSSxLQUFLLElBQUksZUFBZTtLQUN0RixPQUFPLG1CQUFtQixRQUFRLG1CQUFtQixLQUFLLElBQUksS0FBSyxJQUFJLGVBQWU7S0FDdEYsT0FBTyxtQkFBbUIsUUFBUSxtQkFBbUIsS0FBSyxJQUFJLEtBQUssSUFBSSxlQUFlO0lBQ3hGO0dBQ0Y7RUFDRjtFQUNBLFdBQVcsU0FBUyxZQUFZO0dBQzlCLE9BQU8sT0FBTyxRQUFRLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sU0FBVSxRQUFRO0lBQ2hFLElBQ0UsTUFEVyxlQUFlLFFBQVEsQ0FDdkIsQ0FBQyxDQUFDO0lBQ2YsT0FBTyxRQUFRLFFBQVEsUUFBUSxLQUFLLElBQUksS0FBSyxJQUFJLElBQUksV0FBVyxLQUFLO0dBQ3ZFLENBQUMsQ0FBQyxDQUFDLE9BQU8sU0FBVSxRQUFRLFFBQVE7SUFDbEMsSUFBSSxTQUFTLGVBQWUsUUFBUSxDQUFDLEdBQ25DLE1BQU0sT0FBTyxJQUNiLFFBQVEsT0FBTztJQUNqQixJQUVFLE9BQU8sa0JBRE8sU0FEQyxJQUFJLE1BQU0sR0FDTyxDQUNHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztJQUMvQyxTQUFTLFFBQVEsU0FBUyxLQUFLLEtBQUssS0FBSyxPQUFPLFNBQVUsWUFBWSxXQUFXLE9BQU8sT0FBTztLQUM3RixDQUFDLFdBQVcsZUFBZSxXQUFXLGFBQWEsVUFBVSxNQUFNLFNBQVMsSUFBSSxRQUFRLENBQUM7S0FDekYsT0FBTyxXQUFXO0lBQ3BCLEdBQUcsTUFBTTtJQUNULE9BQU87R0FDVCxHQUFHLENBQUMsQ0FBQztFQUNQO0VBQ0Esa0JBQWtCLFNBQVMsbUJBQW1CO0dBQzVDLE9BQU8sT0FBTyxRQUFRLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sU0FBVSxRQUFRO0lBQ2hFLElBQ0UsTUFEVyxlQUFlLFFBQVEsQ0FDdkIsQ0FBQyxDQUFDO0lBQ2YsT0FBTyxFQUFFLFFBQVEsUUFBUSxRQUFRLEtBQUssS0FBSyxJQUFJLFdBQVcsS0FBSztHQUNqRSxDQUFDLENBQUMsQ0FBQyxPQUFPLFNBQVUsS0FBSyxRQUFRO0lBQy9CLElBQUksU0FBUyxlQUFlLFFBQVEsQ0FBQyxHQUNuQyxNQUFNLE9BQU87SUFFZixJQUFJLE9BRE0sT0FBTztJQUVqQixPQUFPO0dBQ1QsR0FBRyxDQUFDLENBQUM7RUFDUDtDQUNGO0FBQ0YifQ==