import { reactify, isDefined } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vueuse+core@14.4.0_vue@3.5.40_typescript@6.0.3_/node_modules/@vueuse/core/dist/index.js?v=7e73afc2";
import { computed } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
import { useRuntimeConfig } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/nuxt.js?v=7e73afc2";
export const businessDetails = {
	name: "La beauté d'Inéïah",
	legalName: "La beauté d'Inéïah",
	alternateName: [
		"La beauté d'Ineiah",
		"Inéïah",
		"Ineiah",
		"Ineiah Coiffure"
	],
	siren: "790 849 574",
	siret: "790 849 574 00039",
	numberoTVA: "FR29790849574",
	creationDate: "2024-12-14",
	description: "Salon de coiffure multiculturel spécialisé dans tous types de cheveux : crépus, bouclés, lisses. Soins, coupes et styles sur-mesure",
	logo: "/logos/ineiah-dark-small.png",
	sameAs: [
		"https://fr.pinterest.com/labeautedineiah",
		"https://facebook.com/labeautedineiah",
		"https://www.instagram.com/ineiah"
	],
	image: [
		"/images/natachamorel/natacha-morel-coiffure.jpg",
		"/logos/ineiah-dark-small.png",
		"/logos/ineiah-light-small.png",
		"/images/kira/photoshoot46-small.webp",
		"/images/gallery/customer41-small.webp"
	],
	rcs: "",
	address: {
		street: "13 Place Nouvelle Aventure",
		postalCode: "59000",
		city: "Lille",
		lat: 50.626999404132064,
		lng: 3.0499777837365993
	},
	priceRange: "$$",
	foundingDate: "2024-12-14",
	foundingLocation: "Lille, France",
	founderImage: "/images/natachamorel/natacha-morel-coiffure.jpg",
	shareCapital: null,
	founder: "Natacha Morel",
	founderDescription: "Natacha Morel est une coiffeuse certifiée et experte en bien-être avec plus de 20 ans d'expérience dans l'industrie de la beauté.",
	founderKnowsAbout: [
		"Cheveux crépus",
		"Cheveux bouclés",
		"Coiffure homme",
		"Coiffure femme",
		"Coiffure multiculturelle",
		"Coloration cheveux crépus",
		"Hair Contouring",
		"Soins capillaires",
		"Coiffure Artistique",
		"Coiffure sur-mesure",
		"Bien-être",
		"Formation capillaire"
	],
	webContentManager: "Natacha Morel",
	publishingDirector: "Natacha Morel",
	editorInChief: "Natacha Morel",
	websiteProvider: {
		legalName: "Gency313",
		url: "https://johnpm-consulting.fr/"
	},
	cloudProvider: {
		legalName: "SAS OVH",
		url: "http://www.ovhcloud.com/fr/",
		description: "OVH SAS est une filiale de la société OVH Groupe SA, société immatriculée au RCS de Lille",
		address: "2 rue Kellermann - 59100 Roubaix - France",
		rcs: "424 761 419 00045"
	},
	contact: {
		telephone: "+33 07 86 20 94 59",
		email: "labeautedineiah@gmail.com",
		address: "13 Place Nouvelle Aventure, 59000 Lille"
	},
	socials: {
		instagram: {
			url: "https://www.instagram.com/ineiah",
			handle: "@ineiah"
		},
		facebook: {
			url: "https://www.facebook.com/labeautedineiah",
			handle: "labeautedineiah"
		},
		pinterest: {
			url: "https://fr.pinterest.com/labeautedineiah",
			handle: "labeautedineiah"
		}
	}
};
/**
* A composable to access business details throughout the application. It provides a `get` function
* to retrieve specific details by key, ensuring type safety and consistency across the app.
*/
export function useBusinessDetails() {
	function get(key) {
		return businessDetails[key];
	}
	const reactiveGet = reactify(get);
	const activeSocials = computed(() => Object.keys(get("socials")));
	function getSocial(platform) {
		const socials = get("socials");
		return socials[platform] || null;
	}
	function getSocialIcon(platform) {
		const icons = {
			instagram: "lucide:instagram",
			facebook: "lucide:facebook",
			pinterest: "fa7-brands:pinterest",
			twitter: "lucide:twitter",
			linkedin: "lucide:linkedin",
			tiktok: "lucide:tiktok",
			youtube: "lucide:youtube"
		};
		return icons[platform];
	}
	const address = computed(() => {
		const address = get("address");
		return `${address.street}, ${address.postalCode} ${address.city}`;
	});
	const geoLocation = computed(() => {
		const address = get("address");
		if (isDefined(address.lat) && isDefined(address.lng)) {
			return `${address.lat.toString()},${address.lng.toString()}`;
		} else {
			return "0,0";
		}
	});
	function suffixLegalName(name, separator = " - ") {
		const legalName = get("legalName");
		return `${name ?? ""}${separator}${legalName}`;
	}
	function _buildPath(path) {
		if (!isDefined(path)) {
			return null;
		} else {
			const rootUrl = useRuntimeConfig().public.siteUrl;
			return new URL(path, rootUrl).toString();
		}
	}
	const founderImage = computed(() => {
		return _buildPath(get("founderImage"));
	});
	const organizationLogo = computed(() => {
		return _buildPath(get("logo"));
	});
	const organizationImages = computed(() => {
		return get("image").map((image) => _buildPath(image));
	});
	return {
		/**
		* The business details object containing all relevant information about the business,
		* including contact details, social media links, and more.
		*/
		businessDetails,
		/**
		* A computed property that returns an array of active social media
		* platforms based on the provided socials in the business details.
		*/
		activeSocials,
		/**
		* A computed property that returns the full address of the business
		* as a formatted string, combining the street, postal code, and city.
		*/
		address,
		/**
		* A computed property that returns the geographical location of the business
		* in the format "latitude,longitude". If latitude or longitude is not defined.
		* @default
		* "0,0"
		*/
		geoLocation,
		/**
		* A computed property that returns the full URL of the founder's 
		* image, constructed from the base site URL and the relative path provided in the business details.
		*/
		founderImage,
		/**
		* A computed property that returns the full URL of the organization's logo,
		* constructed from the base site URL and the relative path provided in the business details.
		*/
		organizationLogo,
		/**
		* A computed property that returns an array of full URLs for the organization's images,
		* constructed from the base site URL and the relative paths provided in the business details.
		*/
		organizationImages,
		/**
		* A function that appends the legal name of the business to a given name,
		* separated by a specified separator (default is ' - ').
		*/
		suffixLegalName,
		/**
		* A function to retrieve specific business details by key, ensuring type safety.
		* @param key - The key of the business detail to retrieve.
		*/
		get,
		/**
		* A reactive version of the `get` function, useful for reactive contexts.
		* @param key - The key of the business detail to retrieve reactively.
		*/
		reactiveGet,
		/**
		* A function to retrieve social media details for a specific platform.
		* @param platform - The social media platform to retrieve details for (e.g., 'instagram', 'facebook').
		*/
		getSocial,
		/**
		* A function to retrieve the icon name for a specific social media platform.
		* @param platform - The social media platform to retrieve the icon for (e.g., 'instagram', 'facebook').
		*/
		getSocialIcon
	};
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7O0FBRUEsT0FBTyxNQUFNLGtCQUFtQztDQUM5QyxNQUFNO0NBQ04sV0FBVztDQUNYLGVBQWU7RUFDYjtFQUNBO0VBQ0E7RUFDQTtDQUNGO0NBQ0EsT0FBTztDQUNQLE9BQU87Q0FDUCxZQUFZO0NBQ1osY0FBYztDQUNkLGFBQWE7Q0FDYixNQUFNO0NBQ04sUUFBUTtFQUNOO0VBQ0E7RUFDQTtDQUNGO0NBQ0EsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtDQUNBLEtBQUs7Q0FDTCxTQUFTO0VBQ1AsUUFBUTtFQUNSLFlBQVk7RUFDWixNQUFNO0VBQ04sS0FBSztFQUNMLEtBQUs7Q0FDUDtDQUNBLFlBQVk7Q0FDWixjQUFjO0NBQ2Qsa0JBQWtCO0NBQ2xCLGNBQWM7Q0FDZCxjQUFjO0NBQ2QsU0FBUztDQUNULG9CQUFvQjtDQUNwQixtQkFBbUI7RUFDakI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7Q0FDQSxtQkFBbUI7Q0FDbkIsb0JBQW9CO0NBQ3BCLGVBQWU7Q0FDZixpQkFBaUI7RUFDZixXQUFXO0VBQ1gsS0FBSztDQUNQO0NBQ0EsZUFBZTtFQUNiLFdBQVc7RUFDWCxLQUFLO0VBQ0wsYUFBYTtFQUNiLFNBQVM7RUFDVCxLQUFLO0NBQ1A7Q0FDQSxTQUFTO0VBQ1AsV0FBVztFQUNYLE9BQU87RUFDUCxTQUFTO0NBQ1g7Q0FDQSxTQUFTO0VBQ1AsV0FBVztHQUNULEtBQUs7R0FDTCxRQUFRO0VBQ1Y7RUFDQSxVQUFVO0dBQ1IsS0FBSztHQUNMLFFBQVE7RUFDVjtFQUNBLFdBQVc7R0FDVCxLQUFLO0dBQ0wsUUFBUTtFQUNWO0NBQ0Y7QUFDRjs7Ozs7QUFNQSxPQUFPLFNBQVMscUJBQXFCO0NBQ25DLFNBQVMsSUFBbUMsS0FBb0M7RUFDOUUsT0FBTyxnQkFBZ0I7Q0FDekI7Q0FFQSxNQUFNLGNBQWMsU0FBUyxHQUFHO0NBQ2hDLE1BQU0sZ0JBQWdCLGVBQWUsT0FBTyxLQUFLLElBQUksU0FBUyxDQUFDLENBQXFCO0NBRXBGLFNBQVMsVUFBVSxVQUF5QztFQUMxRCxNQUFNLFVBQVUsSUFBSSxTQUFTO0VBQzdCLE9BQU8sUUFBUSxhQUFhO0NBQzlCO0NBRUEsU0FBUyxjQUFjLFVBQWtDO0VBQ3ZELE1BQU0sUUFBd0M7R0FDNUMsV0FBVztHQUNYLFVBQVU7R0FDVixXQUFXO0dBQ1gsU0FBUztHQUNULFVBQVU7R0FDVixRQUFRO0dBQ1IsU0FBUztFQUNYO0VBQ0EsT0FBTyxNQUFNO0NBQ2Y7Q0FFQSxNQUFNLFVBQVUsZUFBZTtFQUM3QixNQUFNLFVBQVUsSUFBSSxTQUFTO0VBQzdCLE9BQU8sR0FBRyxRQUFRLE9BQU8sSUFBSSxRQUFRLFdBQVcsR0FBRyxRQUFRO0NBQzdELENBQUM7Q0FFRCxNQUFNLGNBQWMsZUFBZTtFQUNqQyxNQUFNLFVBQVUsSUFBSSxTQUFTO0VBQzdCLElBQUksVUFBVSxRQUFRLEdBQUcsS0FBSyxVQUFVLFFBQVEsR0FBRyxHQUFHO0dBQ3BELE9BQU8sR0FBRyxRQUFRLElBQUksU0FBUyxFQUFFLEdBQUcsUUFBUSxJQUFJLFNBQVM7RUFDM0QsT0FBTztHQUNMLE9BQU87RUFDVDtDQUNGLENBQUM7Q0FFRCxTQUFTLGdCQUFnQixNQUF3QixZQUFvQixPQUFlO0VBQ2xGLE1BQU0sWUFBWSxJQUFJLFdBQVc7RUFDakMsT0FBTyxHQUFHLFFBQVEsS0FBSyxZQUFZO0NBQ3JDO0NBRUEsU0FBUyxXQUFXLE1BQTBDO0VBQzVELElBQUksQ0FBQyxVQUFVLElBQUksR0FBRztHQUNwQixPQUFPO0VBQ1QsT0FBTztHQUNMLE1BQU0sVUFBVSxpQkFBaUIsQ0FBQyxDQUFDLE9BQU87R0FDMUMsT0FBTyxJQUFJLElBQUksTUFBTSxPQUFPLENBQUMsQ0FBQyxTQUFTO0VBQ3pDO0NBQ0Y7Q0FFQSxNQUFNLGVBQWUsZUFBZTtFQUNsQyxPQUFPLFdBQVcsSUFBSSxjQUFjLENBQUM7Q0FDdkMsQ0FBQztDQUVELE1BQU0sbUJBQW1CLGVBQWU7RUFDdEMsT0FBTyxXQUFXLElBQUksTUFBTSxDQUFDO0NBQy9CLENBQUM7Q0FFRCxNQUFNLHFCQUFxQixlQUFlO0VBQ3hDLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxLQUFLLFVBQWtCLFdBQVcsS0FBSyxDQUFDO0NBQzlELENBQUM7Q0FFRCxPQUFPOzs7OztFQUtMOzs7OztFQUtBOzs7OztFQUtBOzs7Ozs7O0VBT0E7Ozs7O0VBS0E7Ozs7O0VBS0E7Ozs7O0VBS0E7Ozs7O0VBS0E7Ozs7O0VBS0E7Ozs7O0VBS0E7Ozs7O0VBS0E7Ozs7O0VBS0E7Q0FDRjtBQUNGIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJiYXNlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgTnVsbGFibGUgfSBmcm9tICd+L3R5cGVzJ1xuXG5leHBvcnQgY29uc3QgYnVzaW5lc3NEZXRhaWxzOiBCdXNpbmVzc0RldGFpbHMgPSB7XG4gIG5hbWU6ICdMYSBiZWF1dMOpIGRcXCdJbsOpw69haCcsXG4gIGxlZ2FsTmFtZTogJ0xhIGJlYXV0w6kgZFxcJ0luw6nDr2FoJyxcbiAgYWx0ZXJuYXRlTmFtZTogW1xuICAgICdMYSBiZWF1dMOpIGRcXCdJbmVpYWgnLFxuICAgICdJbsOpw69haCcsXG4gICAgJ0luZWlhaCcsXG4gICAgJ0luZWlhaCBDb2lmZnVyZSdcbiAgXSxcbiAgc2lyZW46ICc3OTAgODQ5IDU3NCcsXG4gIHNpcmV0OiAnNzkwIDg0OSA1NzQgMDAwMzknLFxuICBudW1iZXJvVFZBOiAnRlIyOTc5MDg0OTU3NCcsXG4gIGNyZWF0aW9uRGF0ZTogJzIwMjQtMTItMTQnLFxuICBkZXNjcmlwdGlvbjogJ1NhbG9uIGRlIGNvaWZmdXJlIG11bHRpY3VsdHVyZWwgc3DDqWNpYWxpc8OpIGRhbnMgdG91cyB0eXBlcyBkZSBjaGV2ZXV4IDogY3LDqXB1cywgYm91Y2zDqXMsIGxpc3Nlcy4gU29pbnMsIGNvdXBlcyBldCBzdHlsZXMgc3VyLW1lc3VyZScsXG4gIGxvZ286ICcvbG9nb3MvaW5laWFoLWRhcmstc21hbGwucG5nJyxcbiAgc2FtZUFzOiBbXG4gICAgJ2h0dHBzOi8vZnIucGludGVyZXN0LmNvbS9sYWJlYXV0ZWRpbmVpYWgnLFxuICAgICdodHRwczovL2ZhY2Vib29rLmNvbS9sYWJlYXV0ZWRpbmVpYWgnLFxuICAgICdodHRwczovL3d3dy5pbnN0YWdyYW0uY29tL2luZWlhaCdcbiAgXSxcbiAgaW1hZ2U6IFtcbiAgICAnL2ltYWdlcy9uYXRhY2hhbW9yZWwvbmF0YWNoYS1tb3JlbC1jb2lmZnVyZS5qcGcnLFxuICAgICcvbG9nb3MvaW5laWFoLWRhcmstc21hbGwucG5nJyxcbiAgICAnL2xvZ29zL2luZWlhaC1saWdodC1zbWFsbC5wbmcnLFxuICAgICcvaW1hZ2VzL2tpcmEvcGhvdG9zaG9vdDQ2LXNtYWxsLndlYnAnLFxuICAgICcvaW1hZ2VzL2dhbGxlcnkvY3VzdG9tZXI0MS1zbWFsbC53ZWJwJ1xuICBdLFxuICByY3M6ICcnLFxuICBhZGRyZXNzOiB7XG4gICAgc3RyZWV0OiAnMTMgUGxhY2UgTm91dmVsbGUgQXZlbnR1cmUnLFxuICAgIHBvc3RhbENvZGU6ICc1OTAwMCcsXG4gICAgY2l0eTogJ0xpbGxlJyxcbiAgICBsYXQ6IDUwLjYyNjk5OTQwNDEzMjA2NCxcbiAgICBsbmc6IDMuMDQ5OTc3NzgzNzM2NTk5M1xuICB9LFxuICBwcmljZVJhbmdlOiAnJCQnLFxuICBmb3VuZGluZ0RhdGU6ICcyMDI0LTEyLTE0JyxcbiAgZm91bmRpbmdMb2NhdGlvbjogJ0xpbGxlLCBGcmFuY2UnLFxuICBmb3VuZGVySW1hZ2U6ICcvaW1hZ2VzL25hdGFjaGFtb3JlbC9uYXRhY2hhLW1vcmVsLWNvaWZmdXJlLmpwZycsXG4gIHNoYXJlQ2FwaXRhbDogbnVsbCxcbiAgZm91bmRlcjogJ05hdGFjaGEgTW9yZWwnLFxuICBmb3VuZGVyRGVzY3JpcHRpb246ICdOYXRhY2hhIE1vcmVsIGVzdCB1bmUgY29pZmZldXNlIGNlcnRpZmnDqWUgZXQgZXhwZXJ0ZSBlbiBiaWVuLcOqdHJlIGF2ZWMgcGx1cyBkZSAyMCBhbnMgZFxcJ2V4cMOpcmllbmNlIGRhbnMgbFxcJ2luZHVzdHJpZSBkZSBsYSBiZWF1dMOpLicsXG4gIGZvdW5kZXJLbm93c0Fib3V0OiBbXG4gICAgJ0NoZXZldXggY3LDqXB1cycsXG4gICAgJ0NoZXZldXggYm91Y2zDqXMnLFxuICAgICdDb2lmZnVyZSBob21tZScsXG4gICAgJ0NvaWZmdXJlIGZlbW1lJyxcbiAgICAnQ29pZmZ1cmUgbXVsdGljdWx0dXJlbGxlJyxcbiAgICAnQ29sb3JhdGlvbiBjaGV2ZXV4IGNyw6lwdXMnLFxuICAgICdIYWlyIENvbnRvdXJpbmcnLFxuICAgICdTb2lucyBjYXBpbGxhaXJlcycsXG4gICAgJ0NvaWZmdXJlIEFydGlzdGlxdWUnLFxuICAgICdDb2lmZnVyZSBzdXItbWVzdXJlJyxcbiAgICAnQmllbi3DqnRyZScsXG4gICAgJ0Zvcm1hdGlvbiBjYXBpbGxhaXJlJ1xuICBdLFxuICB3ZWJDb250ZW50TWFuYWdlcjogJ05hdGFjaGEgTW9yZWwnLFxuICBwdWJsaXNoaW5nRGlyZWN0b3I6ICdOYXRhY2hhIE1vcmVsJyxcbiAgZWRpdG9ySW5DaGllZjogJ05hdGFjaGEgTW9yZWwnLFxuICB3ZWJzaXRlUHJvdmlkZXI6IHtcbiAgICBsZWdhbE5hbWU6ICdHZW5jeTMxMycsXG4gICAgdXJsOiAnaHR0cHM6Ly9qb2hucG0tY29uc3VsdGluZy5mci8nXG4gIH0sXG4gIGNsb3VkUHJvdmlkZXI6IHtcbiAgICBsZWdhbE5hbWU6ICdTQVMgT1ZIJyxcbiAgICB1cmw6ICdodHRwOi8vd3d3Lm92aGNsb3VkLmNvbS9mci8nLFxuICAgIGRlc2NyaXB0aW9uOiAnT1ZIIFNBUyBlc3QgdW5lIGZpbGlhbGUgZGUgbGEgc29jacOpdMOpIE9WSCBHcm91cGUgU0EsIHNvY2nDqXTDqSBpbW1hdHJpY3Vsw6llIGF1IFJDUyBkZSBMaWxsZScsXG4gICAgYWRkcmVzczogJzIgcnVlIEtlbGxlcm1hbm4gLSA1OTEwMCBSb3ViYWl4IC0gRnJhbmNlJyxcbiAgICByY3M6ICc0MjQgNzYxIDQxOSAwMDA0NSdcbiAgfSxcbiAgY29udGFjdDoge1xuICAgIHRlbGVwaG9uZTogJyszMyAwNyA4NiAyMCA5NCA1OScsXG4gICAgZW1haWw6ICdsYWJlYXV0ZWRpbmVpYWhAZ21haWwuY29tJyxcbiAgICBhZGRyZXNzOiAnMTMgUGxhY2UgTm91dmVsbGUgQXZlbnR1cmUsIDU5MDAwIExpbGxlJ1xuICB9LFxuICBzb2NpYWxzOiB7XG4gICAgaW5zdGFncmFtOiB7XG4gICAgICB1cmw6ICdodHRwczovL3d3dy5pbnN0YWdyYW0uY29tL2luZWlhaCcsXG4gICAgICBoYW5kbGU6ICdAaW5laWFoJ1xuICAgIH0sXG4gICAgZmFjZWJvb2s6IHtcbiAgICAgIHVybDogJ2h0dHBzOi8vd3d3LmZhY2Vib29rLmNvbS9sYWJlYXV0ZWRpbmVpYWgnLFxuICAgICAgaGFuZGxlOiAnbGFiZWF1dGVkaW5laWFoJ1xuICAgIH0sXG4gICAgcGludGVyZXN0OiB7XG4gICAgICB1cmw6ICdodHRwczovL2ZyLnBpbnRlcmVzdC5jb20vbGFiZWF1dGVkaW5laWFoJyxcbiAgICAgIGhhbmRsZTogJ2xhYmVhdXRlZGluZWlhaCdcbiAgICB9XG4gIH1cbn1cblxuLyoqXG4gKiBBIGNvbXBvc2FibGUgdG8gYWNjZXNzIGJ1c2luZXNzIGRldGFpbHMgdGhyb3VnaG91dCB0aGUgYXBwbGljYXRpb24uIEl0IHByb3ZpZGVzIGEgYGdldGAgZnVuY3Rpb25cbiAqIHRvIHJldHJpZXZlIHNwZWNpZmljIGRldGFpbHMgYnkga2V5LCBlbnN1cmluZyB0eXBlIHNhZmV0eSBhbmQgY29uc2lzdGVuY3kgYWNyb3NzIHRoZSBhcHAuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VCdXNpbmVzc0RldGFpbHMoKSB7XG4gIGZ1bmN0aW9uIGdldDxLIGV4dGVuZHMgQnVzaW5lc3NEZXRhaWxzS2V5cz4oa2V5OiBLKTogQnVzaW5lc3NEZXRhaWxzS2V5VmFsdWVbS10ge1xuICAgIHJldHVybiBidXNpbmVzc0RldGFpbHNba2V5XVxuICB9XG5cbiAgY29uc3QgcmVhY3RpdmVHZXQgPSByZWFjdGlmeShnZXQpXG4gIGNvbnN0IGFjdGl2ZVNvY2lhbHMgPSBjb21wdXRlZCgoKSA9PiBPYmplY3Qua2V5cyhnZXQoJ3NvY2lhbHMnKSkgYXMgU29jaWFsUGxhdGZvcm1bXSlcblxuICBmdW5jdGlvbiBnZXRTb2NpYWwocGxhdGZvcm06IFNvY2lhbFBsYXRmb3JtKTogU29jaWFsIHwgbnVsbCB7XG4gICAgY29uc3Qgc29jaWFscyA9IGdldCgnc29jaWFscycpXG4gICAgcmV0dXJuIHNvY2lhbHNbcGxhdGZvcm1dIHx8IG51bGxcbiAgfVxuXG4gIGZ1bmN0aW9uIGdldFNvY2lhbEljb24ocGxhdGZvcm06IFNvY2lhbFBsYXRmb3JtKTogc3RyaW5nIHtcbiAgICBjb25zdCBpY29uczogUmVjb3JkPFNvY2lhbFBsYXRmb3JtLCBzdHJpbmc+ID0ge1xuICAgICAgaW5zdGFncmFtOiAnbHVjaWRlOmluc3RhZ3JhbScsXG4gICAgICBmYWNlYm9vazogJ2x1Y2lkZTpmYWNlYm9vaycsXG4gICAgICBwaW50ZXJlc3Q6ICdmYTctYnJhbmRzOnBpbnRlcmVzdCcsXG4gICAgICB0d2l0dGVyOiAnbHVjaWRlOnR3aXR0ZXInLFxuICAgICAgbGlua2VkaW46ICdsdWNpZGU6bGlua2VkaW4nLFxuICAgICAgdGlrdG9rOiAnbHVjaWRlOnRpa3RvaycsXG4gICAgICB5b3V0dWJlOiAnbHVjaWRlOnlvdXR1YmUnXG4gICAgfVxuICAgIHJldHVybiBpY29uc1twbGF0Zm9ybV1cbiAgfVxuXG4gIGNvbnN0IGFkZHJlc3MgPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgY29uc3QgYWRkcmVzcyA9IGdldCgnYWRkcmVzcycpXG4gICAgcmV0dXJuIGAke2FkZHJlc3Muc3RyZWV0fSwgJHthZGRyZXNzLnBvc3RhbENvZGV9ICR7YWRkcmVzcy5jaXR5fWBcbiAgfSlcblxuICBjb25zdCBnZW9Mb2NhdGlvbiA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICBjb25zdCBhZGRyZXNzID0gZ2V0KCdhZGRyZXNzJylcbiAgICBpZiAoaXNEZWZpbmVkKGFkZHJlc3MubGF0KSAmJiBpc0RlZmluZWQoYWRkcmVzcy5sbmcpKSB7XG4gICAgICByZXR1cm4gYCR7YWRkcmVzcy5sYXQudG9TdHJpbmcoKX0sJHthZGRyZXNzLmxuZy50b1N0cmluZygpfWBcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuICcwLDAnXG4gICAgfVxuICB9KVxuXG4gIGZ1bmN0aW9uIHN1ZmZpeExlZ2FsTmFtZShuYW1lOiBOdWxsYWJsZTxzdHJpbmc+LCBzZXBhcmF0b3I6IHN0cmluZyA9ICcgLSAnKTogc3RyaW5nIHtcbiAgICBjb25zdCBsZWdhbE5hbWUgPSBnZXQoJ2xlZ2FsTmFtZScpXG4gICAgcmV0dXJuIGAke25hbWUgPz8gJyd9JHtzZXBhcmF0b3J9JHtsZWdhbE5hbWV9YFxuICB9XG5cbiAgZnVuY3Rpb24gX2J1aWxkUGF0aChwYXRoOiBOdWxsYWJsZTxzdHJpbmc+KTogTnVsbGFibGU8c3RyaW5nPiB7XG4gICAgaWYgKCFpc0RlZmluZWQocGF0aCkpIHtcbiAgICAgIHJldHVybiBudWxsXG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IHJvb3RVcmwgPSB1c2VSdW50aW1lQ29uZmlnKCkucHVibGljLnNpdGVVcmxcbiAgICAgIHJldHVybiBuZXcgVVJMKHBhdGgsIHJvb3RVcmwpLnRvU3RyaW5nKClcbiAgICB9XG4gIH1cblxuICBjb25zdCBmb3VuZGVySW1hZ2UgPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgcmV0dXJuIF9idWlsZFBhdGgoZ2V0KCdmb3VuZGVySW1hZ2UnKSlcbiAgfSlcblxuICBjb25zdCBvcmdhbml6YXRpb25Mb2dvID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIHJldHVybiBfYnVpbGRQYXRoKGdldCgnbG9nbycpKVxuICB9KVxuXG4gIGNvbnN0IG9yZ2FuaXphdGlvbkltYWdlcyA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICByZXR1cm4gZ2V0KCdpbWFnZScpLm1hcCgoaW1hZ2U6IHN0cmluZykgPT4gX2J1aWxkUGF0aChpbWFnZSkpXG4gIH0pXG5cbiAgcmV0dXJuIHtcbiAgICAvKipcbiAgICAgKiBUaGUgYnVzaW5lc3MgZGV0YWlscyBvYmplY3QgY29udGFpbmluZyBhbGwgcmVsZXZhbnQgaW5mb3JtYXRpb24gYWJvdXQgdGhlIGJ1c2luZXNzLFxuICAgICAqIGluY2x1ZGluZyBjb250YWN0IGRldGFpbHMsIHNvY2lhbCBtZWRpYSBsaW5rcywgYW5kIG1vcmUuXG4gICAgICovXG4gICAgYnVzaW5lc3NEZXRhaWxzLFxuICAgIC8qKlxuICAgICAqIEEgY29tcHV0ZWQgcHJvcGVydHkgdGhhdCByZXR1cm5zIGFuIGFycmF5IG9mIGFjdGl2ZSBzb2NpYWwgbWVkaWFcbiAgICAgKiBwbGF0Zm9ybXMgYmFzZWQgb24gdGhlIHByb3ZpZGVkIHNvY2lhbHMgaW4gdGhlIGJ1c2luZXNzIGRldGFpbHMuXG4gICAgICovXG4gICAgYWN0aXZlU29jaWFscyxcbiAgICAvKipcbiAgICAgKiBBIGNvbXB1dGVkIHByb3BlcnR5IHRoYXQgcmV0dXJucyB0aGUgZnVsbCBhZGRyZXNzIG9mIHRoZSBidXNpbmVzc1xuICAgICAqIGFzIGEgZm9ybWF0dGVkIHN0cmluZywgY29tYmluaW5nIHRoZSBzdHJlZXQsIHBvc3RhbCBjb2RlLCBhbmQgY2l0eS5cbiAgICAgKi9cbiAgICBhZGRyZXNzLFxuICAgIC8qKlxuICAgICAqIEEgY29tcHV0ZWQgcHJvcGVydHkgdGhhdCByZXR1cm5zIHRoZSBnZW9ncmFwaGljYWwgbG9jYXRpb24gb2YgdGhlIGJ1c2luZXNzXG4gICAgICogaW4gdGhlIGZvcm1hdCBcImxhdGl0dWRlLGxvbmdpdHVkZVwiLiBJZiBsYXRpdHVkZSBvciBsb25naXR1ZGUgaXMgbm90IGRlZmluZWQuXG4gICAgICogQGRlZmF1bHRcbiAgICAgKiBcIjAsMFwiXG4gICAgICovXG4gICAgZ2VvTG9jYXRpb24sXG4gICAgLyoqXG4gICAgICogQSBjb21wdXRlZCBwcm9wZXJ0eSB0aGF0IHJldHVybnMgdGhlIGZ1bGwgVVJMIG9mIHRoZSBmb3VuZGVyJ3MgXG4gICAgICogaW1hZ2UsIGNvbnN0cnVjdGVkIGZyb20gdGhlIGJhc2Ugc2l0ZSBVUkwgYW5kIHRoZSByZWxhdGl2ZSBwYXRoIHByb3ZpZGVkIGluIHRoZSBidXNpbmVzcyBkZXRhaWxzLlxuICAgICAqL1xuICAgIGZvdW5kZXJJbWFnZSxcbiAgICAvKipcbiAgICAgKiBBIGNvbXB1dGVkIHByb3BlcnR5IHRoYXQgcmV0dXJucyB0aGUgZnVsbCBVUkwgb2YgdGhlIG9yZ2FuaXphdGlvbidzIGxvZ28sXG4gICAgICogY29uc3RydWN0ZWQgZnJvbSB0aGUgYmFzZSBzaXRlIFVSTCBhbmQgdGhlIHJlbGF0aXZlIHBhdGggcHJvdmlkZWQgaW4gdGhlIGJ1c2luZXNzIGRldGFpbHMuXG4gICAgICovXG4gICAgb3JnYW5pemF0aW9uTG9nbyxcbiAgICAvKipcbiAgICAgKiBBIGNvbXB1dGVkIHByb3BlcnR5IHRoYXQgcmV0dXJucyBhbiBhcnJheSBvZiBmdWxsIFVSTHMgZm9yIHRoZSBvcmdhbml6YXRpb24ncyBpbWFnZXMsXG4gICAgICogY29uc3RydWN0ZWQgZnJvbSB0aGUgYmFzZSBzaXRlIFVSTCBhbmQgdGhlIHJlbGF0aXZlIHBhdGhzIHByb3ZpZGVkIGluIHRoZSBidXNpbmVzcyBkZXRhaWxzLlxuICAgICAqL1xuICAgIG9yZ2FuaXphdGlvbkltYWdlcyxcbiAgICAvKipcbiAgICAgKiBBIGZ1bmN0aW9uIHRoYXQgYXBwZW5kcyB0aGUgbGVnYWwgbmFtZSBvZiB0aGUgYnVzaW5lc3MgdG8gYSBnaXZlbiBuYW1lLFxuICAgICAqIHNlcGFyYXRlZCBieSBhIHNwZWNpZmllZCBzZXBhcmF0b3IgKGRlZmF1bHQgaXMgJyAtICcpLlxuICAgICAqL1xuICAgIHN1ZmZpeExlZ2FsTmFtZSxcbiAgICAvKipcbiAgICAgKiBBIGZ1bmN0aW9uIHRvIHJldHJpZXZlIHNwZWNpZmljIGJ1c2luZXNzIGRldGFpbHMgYnkga2V5LCBlbnN1cmluZyB0eXBlIHNhZmV0eS5cbiAgICAgKiBAcGFyYW0ga2V5IC0gVGhlIGtleSBvZiB0aGUgYnVzaW5lc3MgZGV0YWlsIHRvIHJldHJpZXZlLlxuICAgICAqL1xuICAgIGdldCxcbiAgICAvKipcbiAgICAgKiBBIHJlYWN0aXZlIHZlcnNpb24gb2YgdGhlIGBnZXRgIGZ1bmN0aW9uLCB1c2VmdWwgZm9yIHJlYWN0aXZlIGNvbnRleHRzLlxuICAgICAqIEBwYXJhbSBrZXkgLSBUaGUga2V5IG9mIHRoZSBidXNpbmVzcyBkZXRhaWwgdG8gcmV0cmlldmUgcmVhY3RpdmVseS5cbiAgICAgKi9cbiAgICByZWFjdGl2ZUdldCxcbiAgICAvKipcbiAgICAgKiBBIGZ1bmN0aW9uIHRvIHJldHJpZXZlIHNvY2lhbCBtZWRpYSBkZXRhaWxzIGZvciBhIHNwZWNpZmljIHBsYXRmb3JtLlxuICAgICAqIEBwYXJhbSBwbGF0Zm9ybSAtIFRoZSBzb2NpYWwgbWVkaWEgcGxhdGZvcm0gdG8gcmV0cmlldmUgZGV0YWlscyBmb3IgKGUuZy4sICdpbnN0YWdyYW0nLCAnZmFjZWJvb2snKS5cbiAgICAgKi9cbiAgICBnZXRTb2NpYWwsXG4gICAgLyoqXG4gICAgICogQSBmdW5jdGlvbiB0byByZXRyaWV2ZSB0aGUgaWNvbiBuYW1lIGZvciBhIHNwZWNpZmljIHNvY2lhbCBtZWRpYSBwbGF0Zm9ybS5cbiAgICAgKiBAcGFyYW0gcGxhdGZvcm0gLSBUaGUgc29jaWFsIG1lZGlhIHBsYXRmb3JtIHRvIHJldHJpZXZlIHRoZSBpY29uIGZvciAoZS5nLiwgJ2luc3RhZ3JhbScsICdmYWNlYm9vaycpLlxuICAgICAqL1xuICAgIGdldFNvY2lhbEljb25cbiAgfVxufVxuIl0sImZpbGUiOiIvVm9sdW1lcy9Db2RpbmcvUHJvamVjdHMvV2Vic2l0ZXMvaW5laWFoL2Zyb250ZW5kL2FwcC9jb21wb3NhYmxlcy9idXNpbmVzcy9iYXNlLnRzIn0=