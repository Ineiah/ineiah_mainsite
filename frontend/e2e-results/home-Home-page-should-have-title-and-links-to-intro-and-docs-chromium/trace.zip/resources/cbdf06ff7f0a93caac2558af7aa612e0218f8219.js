import { createHotContext as __vite__createHotContext } from "/_nuxt/@vite/client";import.meta.hot = __vite__createHotContext("/pages/index.vue");import.meta.env = {"BASE_URL": "/_nuxt/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false};import { default as __nuxt_component_0 } from "/_nuxt/components/hero/BottomCta.vue";
import { createLazyVisibleComponent } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/components/runtime/lazy-hydrated-component.js?v=7e73afc2";
const __nuxt_component_1_lazy_visible = createLazyVisibleComponent("components/hero/TopVideo.vue", () => import("/_nuxt/components/hero/TopVideo.vue").then(c => c.default || c))
import { default as __nuxt_component_2 } from "/_nuxt/components/hero/SectionImage.vue";
import { default as __nuxt_component_3 } from "/_nuxt/components/hero/SectionColor.vue";
import { createLazyIdleComponent } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/components/runtime/lazy-hydrated-component.js?v=7e73afc2";
const __nuxt_component_4_lazy_idle = createLazyIdleComponent("components/hero/SectionBrands.vue", () => import("/_nuxt/components/hero/SectionBrands.vue").then(c => c.default || c))
const __nuxt_component_5_lazy_idle = createLazyIdleComponent("components/hero/SectionPhotocall.vue", () => import("/_nuxt/components/hero/SectionPhotocall.vue").then(c => c.default || c))
const __nuxt_component_6_lazy_visible = createLazyVisibleComponent("components/hero/SectionProducts.vue", () => import("/_nuxt/components/hero/SectionProducts.vue").then(c => c.default || c))
import { default as __nuxt_component_7 } from "/_nuxt/components/hero/SectionReviews.vue";
import { default as __nuxt_component_8 } from "/_nuxt/components/hero/SectionVideoCall.vue";
import { default as __nuxt_component_9 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/components/client-only.js?v=7e73afc2";
import { default as __nuxt_component_10 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/components/dev-only.js?v=7e73afc2";
import { default as __nuxt_component_11 } from "/_nuxt/components/volt/ToggleSwitch.vue";
import { default as __nuxt_component_12 } from "/_nuxt/components/volt/Label.vue";
import { definePageMeta } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/composables/pages.js?v=7e73afc2";
import { useBusinessDetails as _$__useBusinessDetails } from "/_nuxt/composables/business/base.ts";
import { useDevComposable as _$__useDevComposable } from "/_nuxt/composables/index.ts";
import { useI18n } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue-i18n@11.4.8_vue@3.5.40_typescript@6.0.3_/node_modules/vue-i18n/dist/vue-i18n.esm-bundler.js";
import { useDarkModeComposable as _$__useDarkModeComposable } from "/_nuxt/composables/dark_mode.ts";
import { useRequestURL as _$__useRequestURL } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/composables/url.js?v=7e73afc2";
import { useHead as _$__useHead } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt@4.5.1_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typ_9646942090660c5b98f47c1ce9aee5a2/node_modules/nuxt/dist/app/composables/head.js?v=7e73afc2";
import { defineOgImage } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/nuxt-og-image@6.7.6_c87f148809c46ac7d1a9c5ee9a1b0239/node_modules/nuxt-og-image/dist/runtime/app/composables/defineOgImage.js?v=7e73afc2";;import { __nuxtTimelineWrap } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@nuxt+devtools@3.4.1_db0@0.3.4_better-sqlite3@13.0.2_drizzle-orm@0.45.2_@opentelemetry+_0e55243a794e05cb19a29a0506aae086/node_modules/@nuxt/devtools/dist/runtime/function-metrics-helpers.js?v=7e73afc2";const useBusinessDetails = __nuxtTimelineWrap("useBusinessDetails", _$__useBusinessDetails);const useDevComposable = __nuxtTimelineWrap("useDevComposable", _$__useDevComposable);const useDarkModeComposable = __nuxtTimelineWrap("useDarkModeComposable", _$__useDarkModeComposable);const useRequestURL = __nuxtTimelineWrap("useRequestURL", _$__useRequestURL);const useHead = __nuxtTimelineWrap("useHead", _$__useHead);
import { defineComponent as _defineComponent } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _sfc_main = /*@__PURE__*/ _defineComponent({
	__name: "index",
	setup(__props, { expose: __expose }) {
		__expose();
		definePageMeta({ label: "Home" });
		/**
		* Socials
		*/
		const { get } = useBusinessDetails();
		/**
		* Utils
		*/
		// const { instagram } = useSocialLinks()
		/**
		* Template settings
		*/
		const { showImage, showVideo, showVideoBlock } = useDevComposable();
		const i18n = useI18n();
		/**
		* Dark mode
		*/
		const { darkMode } = useDarkModeComposable(false);
		/**
		* SEO
		*/
		const titles = {
			fr: "Coupe et coiffures tout type de cheveux",
			en: "Haircuts and hairstyles for all hair types"
		};
		const descriptions = {
			fr: "Salon de coiffure multiculturel spécialisé dans tous types de cheveux : crépus, bouclés, lisses. Soins, coupes et styles sur-mesure",
			en: "Multicultural hair salon specializing in all hair types: kinky, curly, straight. Custom care, cuts and styles"
		};
		const url = useRequestURL();
		useHead({
  title: titles[i18n.locale.value],
  meta: [
    { name: 'description', content: descriptions[i18n.locale.value] },
    { name: 'author', content: get("legalName") },
    { name: 'twitter:description', content: descriptions[i18n.locale.value] },
    { name: 'twitter:card', content: "summary_large_image" },
    { property: 'og:title', content: titles[i18n.locale.value] },
    { property: 'og:description', content: descriptions[i18n.locale.value] },
    { property: 'og:url', content: url.href },
  ]
});
		if (import.meta.env.NODE_ENV !== "test") {
			defineOgImage("NuxtSeoTakumi", {
				title: titles[i18n.locale.value],
				description: descriptions[i18n.locale.value]
			});
		}
		const __returned__ = {
			get,
			showImage,
			showVideo,
			showVideoBlock,
			i18n,
			darkMode,
			titles,
			descriptions,
			url
		};
		Object.defineProperty(__returned__, "__isScriptSetup", {
			enumerable: false,
			value: true
		});
		return __returned__;
	}
});
import { createCommentVNode as _createCommentVNode, resolveComponent as _resolveComponent, openBlock as _openBlock, createBlock as _createBlock, createVNode as _createVNode, vShow as _vShow, withDirectives as _withDirectives, withCtx as _withCtx, createElementVNode as _createElementVNode, createElementBlock as _createElementBlock } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
const _hoisted_1 = {
	id: "hero",
	class: "has-[p]:space-y-5 has-[p]:leading-8 has-[h2]:leading-15 relative"
};
const _hoisted_2 = { class: "fixed p-5 right-0 top-2/12 md:top-6/12 z-50 rounded-md bg-primary-50 dark:bg-primary-500 text-surface-900 dark:text-surface-50 m-3 shadow-md space-y-2" };
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
	const _component_hero_bottom_cta = __nuxt_component_0;
	const _component_LazyVisibleHeroTopVideo = __nuxt_component_1_lazy_visible;
	const _component_hero_section_image = __nuxt_component_2;
	const _component_hero_section_color = __nuxt_component_3;
	const _component_LazyIdleHeroSectionBrands = __nuxt_component_4_lazy_idle;
	const _component_LazyIdleHeroSectionPhotocall = __nuxt_component_5_lazy_idle;
	const _component_LazyVisibleHeroSectionProducts = __nuxt_component_6_lazy_visible;
	const _component_hero_section_reviews = __nuxt_component_7;
	const _component_hero_section_video_call = __nuxt_component_8;
	const _component_client_only = __nuxt_component_9;
	const _component_dev_only = __nuxt_component_10;
	const _component_volt_toggle_switch = __nuxt_component_11;
	const _component_volt_label = __nuxt_component_12;
	return _openBlock(), _createElementBlock("section", _hoisted_1, [
		_createCommentVNode(" Hero "),
		$setup.showImage ? (_openBlock(), _createBlock(_component_hero_bottom_cta, {
			key: 0,
			image: `/images/hero/customer18-small.webp`
		})) : $setup.showVideo ? (_openBlock(), _createBlock(_component_LazyVisibleHeroTopVideo, {
			key: 1,
			"hydrate-on-visible": ""
		})) : _createCommentVNode("v-if", true),
		_createCommentVNode(" Intermediate-1 "),
		_createVNode(_component_hero_section_image),
		_createCommentVNode(" Intermediate-2 "),
		_createVNode(_component_hero_section_color),
		_createCommentVNode(" Brands "),
		_createVNode(_component_LazyIdleHeroSectionBrands, { "hydrate-on-idle": "" }),
		_createCommentVNode(" Photocall "),
		_createVNode(_component_LazyIdleHeroSectionPhotocall, { "hydrate-on-idle": "" }),
		_createCommentVNode(" Product Recommendations "),
		_createVNode(_component_LazyVisibleHeroSectionProducts, { "hydrate-on-visible": "" }),
		_createCommentVNode(" Reviews "),
		_createVNode(_component_hero_section_reviews),
		_createVNode(_component_dev_only, null, {
			default: _withCtx(() => [_createCommentVNode(" VideoCall "), _createVNode(_component_client_only, null, {
				default: _withCtx(() => [_withDirectives(_createVNode(
					_component_hero_section_video_call,
					null,
					null,
					512
					/* NEED_PATCH */
				), [[_vShow, $setup.showVideoBlock]])]),
				_: 1
			})]),
			_: 1
		}),
		_createVNode(_component_dev_only, null, {
			default: _withCtx(() => [_createCommentVNode(" Template Settings "), _createElementVNode("div", _hoisted_2, [
				_cache[4] || (_cache[4] = _createElementVNode(
					"p",
					{ class: "font-bold mb-4" },
					" Template settings ",
					-1
					/* CACHED */
				)),
				_createVNode(_component_volt_label, {
					"label-for": "dark-mode",
					label: "Dark mode"
				}, {
					default: _withCtx(() => [_createVNode(_component_client_only, null, {
						default: _withCtx(() => [_createVNode(_component_volt_toggle_switch, {
							id: "dark-mode",
							modelValue: $setup.darkMode,
							"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => $setup.darkMode = $event)
						}, null, 8, ["modelValue"])]),
						_: 1
					})]),
					_: 1
				}),
				_createVNode(_component_volt_label, {
					"label-for": "show-image",
					label: "Show Image"
				}, {
					default: _withCtx(() => [_createVNode(_component_client_only, null, {
						default: _withCtx(() => [_createVNode(_component_volt_toggle_switch, {
							id: "show-image",
							modelValue: $setup.showImage,
							"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => $setup.showImage = $event)
						}, null, 8, ["modelValue"])]),
						_: 1
					})]),
					_: 1
				}),
				_createVNode(_component_volt_label, {
					"label-for": "show-video",
					label: "Show Video"
				}, {
					default: _withCtx(() => [_createVNode(_component_client_only, null, {
						default: _withCtx(() => [_createVNode(_component_volt_toggle_switch, {
							id: "show-video",
							modelValue: $setup.showVideo,
							"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => $setup.showVideo = $event)
						}, null, 8, ["modelValue"])]),
						_: 1
					})]),
					_: 1
				}),
				_createVNode(_component_volt_label, {
					"label-for": "show-video-call",
					label: "Show video call"
				}, {
					default: _withCtx(() => [_createVNode(_component_client_only, null, {
						default: _withCtx(() => [_createVNode(_component_volt_toggle_switch, {
							id: "show-video-call",
							modelValue: $setup.showVideoBlock,
							"onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => $setup.showVideoBlock = $event)
						}, null, 8, ["modelValue"])]),
						_: 1
					})]),
					_: 1
				})
			])]),
			_: 1
		})
	]);
}
_sfc_main.__hmrId = "02281a80";
typeof __VUE_HMR_RUNTIME__ !== "undefined" && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main);
import.meta.hot.on("file-changed", ({ file }) => {
	__VUE_HMR_RUNTIME__.CHANGED_FILE = file;
});
import.meta.hot.accept((mod) => {
	if (!mod) return;
	const { default: updated, _rerender_only } = mod;
	if (_rerender_only) {
		__VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render);
	} else {
		__VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated);
	}
});
import _export_sfc from "/_nuxt/@id/__x00__plugin-vue:export-helper";
export default /*#__PURE__*/ _export_sfc(_sfc_main, [["render", _sfc_render], ["__file", "/Volumes/Coding/Projects/Websites/ineiah/frontend/app/pages/index.vue"]]);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztFQW1IQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFTQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBM0ZVIiwibmFtZXMiOltdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJpbmRleC52dWUiXSwic291cmNlc0NvbnRlbnQiOlsiPHRlbXBsYXRlPlxuICA8c2VjdGlvbiBpZD1cImhlcm9cIiBjbGFzcz1cImhhcy1bcF06c3BhY2UteS01IGhhcy1bcF06bGVhZGluZy04IGhhcy1baDJdOmxlYWRpbmctMTUgcmVsYXRpdmVcIj5cbiAgICA8IS0tIEhlcm8gLS0+XG4gICAgPGhlcm8tYm90dG9tLWN0YSB2LWlmPVwic2hvd0ltYWdlXCIgOmltYWdlPVwiYC9pbWFnZXMvaGVyby9jdXN0b21lcjE4LXNtYWxsLndlYnBgXCIgLz5cbiAgICA8bGF6eS1oZXJvLXRvcC12aWRlbyB2LWVsc2UtaWY9XCJzaG93VmlkZW9cIiBoeWRyYXRlLW9uLXZpc2libGUgLz5cblxuICAgIDwhLS0gSW50ZXJtZWRpYXRlLTEgLS0+XG4gICAgPGhlcm8tc2VjdGlvbi1pbWFnZSAvPlxuXG4gICAgPCEtLSBJbnRlcm1lZGlhdGUtMiAtLT5cbiAgICA8aGVyby1zZWN0aW9uLWNvbG9yIC8+XG5cbiAgICA8IS0tIEJyYW5kcyAtLT5cbiAgICA8bGF6eS1oZXJvLXNlY3Rpb24tYnJhbmRzIGh5ZHJhdGUtb24taWRsZSAvPlxuXG4gICAgPCEtLSBQaG90b2NhbGwgLS0+XG4gICAgPGxhenktaGVyby1zZWN0aW9uLXBob3RvY2FsbCBoeWRyYXRlLW9uLWlkbGUgLz5cblxuICAgIDwhLS0gUHJvZHVjdCBSZWNvbW1lbmRhdGlvbnMgLS0+XG4gICAgPGxhenktaGVyby1zZWN0aW9uLXByb2R1Y3RzIGh5ZHJhdGUtb24tdmlzaWJsZSAvPlxuXG4gICAgPCEtLSBSZXZpZXdzIC0tPlxuICAgIDxoZXJvLXNlY3Rpb24tcmV2aWV3cyAvPlxuXG4gICAgPGRldi1vbmx5PlxuICAgICAgPCEtLSBWaWRlb0NhbGwgLS0+XG4gICAgICA8Y2xpZW50LW9ubHk+XG4gICAgICAgIDxoZXJvLXNlY3Rpb24tdmlkZW8tY2FsbCB2LXNob3c9XCJzaG93VmlkZW9CbG9ja1wiIC8+XG4gICAgICA8L2NsaWVudC1vbmx5PlxuICAgIDwvZGV2LW9ubHk+XG5cbiAgICA8ZGV2LW9ubHk+XG4gICAgICA8IS0tIFRlbXBsYXRlIFNldHRpbmdzIC0tPlxuICAgICAgPGRpdiBjbGFzcz1cImZpeGVkIHAtNSByaWdodC0wIHRvcC0yLzEyIG1kOnRvcC02LzEyIHotNTAgcm91bmRlZC1tZCBiZy1wcmltYXJ5LTUwIGRhcms6YmctcHJpbWFyeS01MDAgdGV4dC1zdXJmYWNlLTkwMCBkYXJrOnRleHQtc3VyZmFjZS01MCBtLTMgc2hhZG93LW1kIHNwYWNlLXktMlwiPlxuICAgICAgICA8cCBjbGFzcz1cImZvbnQtYm9sZCBtYi00XCI+XG4gICAgICAgICAgVGVtcGxhdGUgc2V0dGluZ3NcbiAgICAgICAgPC9wPlxuXG4gICAgICAgIDx2b2x0LWxhYmVsIGxhYmVsLWZvcj1cImRhcmstbW9kZVwiIGxhYmVsPVwiRGFyayBtb2RlXCI+XG4gICAgICAgICAgPGNsaWVudC1vbmx5PlxuICAgICAgICAgICAgPHZvbHQtdG9nZ2xlLXN3aXRjaCBpZD1cImRhcmstbW9kZVwiIHYtbW9kZWw9XCJkYXJrTW9kZVwiIC8+XG4gICAgICAgICAgPC9jbGllbnQtb25seT5cbiAgICAgICAgPC92b2x0LWxhYmVsPlxuXG4gICAgICAgIDx2b2x0LWxhYmVsIGxhYmVsLWZvcj1cInNob3ctaW1hZ2VcIiBsYWJlbD1cIlNob3cgSW1hZ2VcIj5cbiAgICAgICAgICA8Y2xpZW50LW9ubHk+XG4gICAgICAgICAgICA8dm9sdC10b2dnbGUtc3dpdGNoIGlkPVwic2hvdy1pbWFnZVwiIHYtbW9kZWw9XCJzaG93SW1hZ2VcIiAvPlxuICAgICAgICAgIDwvY2xpZW50LW9ubHk+XG4gICAgICAgIDwvdm9sdC1sYWJlbD5cblxuICAgICAgICA8dm9sdC1sYWJlbCBsYWJlbC1mb3I9XCJzaG93LXZpZGVvXCIgbGFiZWw9XCJTaG93IFZpZGVvXCI+XG4gICAgICAgICAgPGNsaWVudC1vbmx5PlxuICAgICAgICAgICAgPHZvbHQtdG9nZ2xlLXN3aXRjaCBpZD1cInNob3ctdmlkZW9cIiB2LW1vZGVsPVwic2hvd1ZpZGVvXCIgLz5cbiAgICAgICAgICA8L2NsaWVudC1vbmx5PlxuICAgICAgICA8L3ZvbHQtbGFiZWw+XG5cbiAgICAgICAgPHZvbHQtbGFiZWwgbGFiZWwtZm9yPVwic2hvdy12aWRlby1jYWxsXCIgbGFiZWw9XCJTaG93IHZpZGVvIGNhbGxcIj5cbiAgICAgICAgICA8Y2xpZW50LW9ubHk+XG4gICAgICAgICAgICA8dm9sdC10b2dnbGUtc3dpdGNoIGlkPVwic2hvdy12aWRlby1jYWxsXCIgdi1tb2RlbD1cInNob3dWaWRlb0Jsb2NrXCIgLz5cbiAgICAgICAgICA8L2NsaWVudC1vbmx5PlxuICAgICAgICA8L3ZvbHQtbGFiZWw+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rldi1vbmx5PlxuICA8L3NlY3Rpb24+XG48L3RlbXBsYXRlPlxuXG48c2NyaXB0IHNldHVwIGxhbmc9XCJ0c1wiPlxuaW1wb3J0IHR5cGUgeyBQYWdlVGl0bGVPckRlc2NyaXB0aW9uIH0gZnJvbSAnfi90eXBlcydcblxuZGVmaW5lUGFnZU1ldGEoe1xuICBsYWJlbDogJ0hvbWUnXG59KVxuXG4vKipcbiAqIFNvY2lhbHNcbiAqL1xuXG5jb25zdCB7IGdldCB9ID0gdXNlQnVzaW5lc3NEZXRhaWxzKClcblxuLyoqXG4gKiBVdGlsc1xuICovXG5cbi8vIGNvbnN0IHsgaW5zdGFncmFtIH0gPSB1c2VTb2NpYWxMaW5rcygpXG5cbi8qKlxuICogVGVtcGxhdGUgc2V0dGluZ3NcbiAqL1xuXG5jb25zdCB7IHNob3dJbWFnZSwgc2hvd1ZpZGVvLCBzaG93VmlkZW9CbG9jayB9ID0gdXNlRGV2Q29tcG9zYWJsZSgpXG5cbmNvbnN0IGkxOG4gPSB1c2VJMThuKClcblxuLyoqXG4gKiBEYXJrIG1vZGVcbiAqL1xuXG5jb25zdCB7IGRhcmtNb2RlIH0gPSB1c2VEYXJrTW9kZUNvbXBvc2FibGUoZmFsc2UpXG5cbi8qKlxuICogU0VPXG4gKi9cblxuY29uc3QgdGl0bGVzOiBQYWdlVGl0bGVPckRlc2NyaXB0aW9uPHR5cGVvZiBpMThuLmxvY2FsZS52YWx1ZT4gPSB7XG4gIGZyOiAnQ291cGUgZXQgY29pZmZ1cmVzIHRvdXQgdHlwZSBkZSBjaGV2ZXV4JyxcbiAgZW46ICdIYWlyY3V0cyBhbmQgaGFpcnN0eWxlcyBmb3IgYWxsIGhhaXIgdHlwZXMnXG59XG5cbmNvbnN0IGRlc2NyaXB0aW9uczogUGFnZVRpdGxlT3JEZXNjcmlwdGlvbjx0eXBlb2YgaTE4bi5sb2NhbGUudmFsdWU+ID0ge1xuICBmcjogJ1NhbG9uIGRlIGNvaWZmdXJlIG11bHRpY3VsdHVyZWwgc3DDqWNpYWxpc8OpIGRhbnMgdG91cyB0eXBlcyBkZSBjaGV2ZXV4IDogY3LDqXB1cywgYm91Y2zDqXMsIGxpc3Nlcy4gU29pbnMsIGNvdXBlcyBldCBzdHlsZXMgc3VyLW1lc3VyZScsXG4gIGVuOiAnTXVsdGljdWx0dXJhbCBoYWlyIHNhbG9uIHNwZWNpYWxpemluZyBpbiBhbGwgaGFpciB0eXBlczoga2lua3ksIGN1cmx5LCBzdHJhaWdodC4gQ3VzdG9tIGNhcmUsIGN1dHMgYW5kIHN0eWxlcydcbn1cblxuY29uc3QgdXJsID0gdXNlUmVxdWVzdFVSTCgpXG5cbnVzZVNlb01ldGEoe1xuICB0aXRsZTogdGl0bGVzW2kxOG4ubG9jYWxlLnZhbHVlXSxcbiAgZGVzY3JpcHRpb246IGRlc2NyaXB0aW9uc1tpMThuLmxvY2FsZS52YWx1ZV0sXG4gIGF1dGhvcjogZ2V0KCdsZWdhbE5hbWUnKSxcbiAgdHdpdHRlckRlc2NyaXB0aW9uOiBkZXNjcmlwdGlvbnNbaTE4bi5sb2NhbGUudmFsdWVdLFxuICB0d2l0dGVyQ2FyZDogJ3N1bW1hcnlfbGFyZ2VfaW1hZ2UnLFxuICBvZ1RpdGxlOiB0aXRsZXNbaTE4bi5sb2NhbGUudmFsdWVdLFxuICBvZ0Rlc2NyaXB0aW9uOiBkZXNjcmlwdGlvbnNbaTE4bi5sb2NhbGUudmFsdWVdLFxuICBvZ1VybDogdXJsLmhyZWZcbn0pXG5cbmlmIChpbXBvcnQubWV0YS5lbnYuTk9ERV9FTlYgIT09ICd0ZXN0Jykge1xuICBkZWZpbmVPZ0ltYWdlKCdOdXh0U2VvVGFrdW1pJywge1xuICAgIHRpdGxlOiB0aXRsZXNbaTE4bi5sb2NhbGUudmFsdWVdLFxuICAgIGRlc2NyaXB0aW9uOiBkZXNjcmlwdGlvbnNbaTE4bi5sb2NhbGUudmFsdWVdXG4gIH0pXG59XG48L3NjcmlwdD5cbiJdLCJmaWxlIjoiL1ZvbHVtZXMvQ29kaW5nL1Byb2plY3RzL1dlYnNpdGVzL2luZWlhaC9mcm9udGVuZC9hcHAvcGFnZXMvaW5kZXgudnVlIn0=