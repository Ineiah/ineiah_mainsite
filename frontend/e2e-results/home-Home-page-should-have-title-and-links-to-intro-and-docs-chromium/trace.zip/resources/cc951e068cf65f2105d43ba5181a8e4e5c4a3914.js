import { n as BaseStyle } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.cache/vite/client/deps/licenseBanner-BJm6_Mu3.js?v=7e73afc2";
import { t as c } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.cache/vite/client/deps/classnames-BTO5Q6w1.js?v=7e73afc2";
import { t as script$1 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.cache/vite/client/deps/baseeditableholder-ChfOjmxs.js?v=7e73afc2";
import { createElementBlock, createElementVNode, mergeProps, openBlock, renderSlot } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
//#endregion
//#region node_modules/.pnpm/primevue@5.0.0_vue@3.5.40_typescript@6.0.3_/node_modules/primevue/toggleswitch/style/index.mjs
var ToggleSwitchStyle = BaseStyle.extend({
	name: "toggleswitch",
	style: "\n    .p-toggleswitch {\n        display: inline-block;\n        width: dt('toggleswitch.width');\n        height: dt('toggleswitch.height');\n    }\n\n    .p-toggleswitch-input {\n        cursor: pointer;\n        appearance: none;\n        position: absolute;\n        top: 0;\n        inset-inline-start: 0;\n        width: 100%;\n        height: 100%;\n        padding: 0;\n        margin: 0;\n        opacity: 0;\n        z-index: 1;\n        outline: 0 none;\n        border-radius: dt('toggleswitch.border.radius');\n    }\n\n    .p-toggleswitch-slider {\n        cursor: pointer;\n        width: 100%;\n        height: 100%;\n        border-width: dt('toggleswitch.border.width');\n        border-style: solid;\n        border-color: dt('toggleswitch.border.color');\n        background: dt('toggleswitch.background');\n        transition:\n            background dt('toggleswitch.transition.duration'),\n            color dt('toggleswitch.transition.duration'),\n            border-color dt('toggleswitch.transition.duration'),\n            outline-color dt('toggleswitch.transition.duration'),\n            box-shadow dt('toggleswitch.transition.duration');\n        border-radius: dt('toggleswitch.border.radius');\n        outline-color: transparent;\n        box-shadow: dt('toggleswitch.shadow');\n    }\n\n    .p-toggleswitch-handle {\n        position: absolute;\n        top: 50%;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        background: dt('toggleswitch.handle.background');\n        color: dt('toggleswitch.handle.color');\n        width: dt('toggleswitch.handle.size');\n        height: dt('toggleswitch.handle.size');\n        inset-inline-start: dt('toggleswitch.gap');\n        margin-block-start: calc(-1 * calc(dt('toggleswitch.handle.size') / 2));\n        border-radius: dt('toggleswitch.handle.border.radius');\n        transition:\n            background dt('toggleswitch.transition.duration'),\n            color dt('toggleswitch.transition.duration'),\n            inset-inline-start dt('toggleswitch.slide.duration'),\n            box-shadow dt('toggleswitch.slide.duration');\n    }\n\n    .p-toggleswitch.p-toggleswitch-checked .p-toggleswitch-slider {\n        background: dt('toggleswitch.checked.background');\n        border-color: dt('toggleswitch.checked.border.color');\n    }\n\n    .p-toggleswitch.p-toggleswitch-checked .p-toggleswitch-handle {\n        background: dt('toggleswitch.handle.checked.background');\n        color: dt('toggleswitch.handle.checked.color');\n        inset-inline-start: calc(dt('toggleswitch.width') - calc(dt('toggleswitch.handle.size') + dt('toggleswitch.gap')));\n    }\n\n    .p-toggleswitch:not(.p-disabled):has(.p-toggleswitch-input:hover) .p-toggleswitch-slider {\n        background: dt('toggleswitch.hover.background');\n        border-color: dt('toggleswitch.hover.border.color');\n    }\n\n    .p-toggleswitch:not(.p-disabled):has(.p-toggleswitch-input:hover) .p-toggleswitch-handle {\n        background: dt('toggleswitch.handle.hover.background');\n        color: dt('toggleswitch.handle.hover.color');\n    }\n\n    .p-toggleswitch:not(.p-disabled):has(.p-toggleswitch-input:hover).p-toggleswitch-checked .p-toggleswitch-slider {\n        background: dt('toggleswitch.checked.hover.background');\n        border-color: dt('toggleswitch.checked.hover.border.color');\n    }\n\n    .p-toggleswitch:not(.p-disabled):has(.p-toggleswitch-input:hover).p-toggleswitch-checked .p-toggleswitch-handle {\n        background: dt('toggleswitch.handle.checked.hover.background');\n        color: dt('toggleswitch.handle.checked.hover.color');\n    }\n\n    .p-toggleswitch:not(.p-disabled):has(.p-toggleswitch-input:focus-visible) .p-toggleswitch-slider {\n        box-shadow: dt('toggleswitch.focus.ring.shadow');\n        outline: dt('toggleswitch.focus.ring.width') dt('toggleswitch.focus.ring.style') dt('toggleswitch.focus.ring.color');\n        outline-offset: dt('toggleswitch.focus.ring.offset');\n    }\n\n    .p-toggleswitch.p-invalid > .p-toggleswitch-slider {\n        border-color: dt('toggleswitch.invalid.border.color');\n    }\n\n    .p-toggleswitch.p-disabled {\n        opacity: 1;\n    }\n\n    .p-toggleswitch.p-disabled .p-toggleswitch-slider {\n        background: dt('toggleswitch.disabled.background');\n    }\n\n    .p-toggleswitch.p-disabled .p-toggleswitch-handle {\n        background: dt('toggleswitch.handle.disabled.background');\n    }\n",
	classes: {
		root: function root(_ref) {
			var instance = _ref.instance, props = _ref.props;
			return ["p-toggleswitch p-component", {
				"p-toggleswitch-checked": instance.checked,
				"p-disabled": props.disabled,
				"p-invalid": instance.$invalid
			}];
		},
		input: "p-toggleswitch-input",
		slider: "p-toggleswitch-slider",
		handle: "p-toggleswitch-handle"
	},
	inlineStyles: { root: { position: "relative" } }
});
//#endregion
//#region node_modules/.pnpm/primevue@5.0.0_vue@3.5.40_typescript@6.0.3_/node_modules/primevue/toggleswitch/index.mjs
var script = {
	name: "ToggleSwitch",
	"extends": {
		name: "BaseToggleSwitch",
		"extends": script$1,
		props: {
			trueValue: {
				type: null,
				"default": true
			},
			falseValue: {
				type: null,
				"default": false
			},
			readonly: {
				type: Boolean,
				"default": false
			},
			tabindex: {
				type: Number,
				"default": null
			},
			inputId: {
				type: String,
				"default": null
			},
			inputClass: {
				type: [String, Object],
				"default": null
			},
			inputStyle: {
				type: Object,
				"default": null
			},
			ariaLabelledby: {
				type: String,
				"default": null
			},
			ariaLabel: {
				type: String,
				"default": null
			}
		},
		style: ToggleSwitchStyle,
		provide: function provide() {
			return {
				$pcToggleSwitch: this,
				$parentInstance: this
			};
		}
	},
	inheritAttrs: false,
	emits: [
		"change",
		"focus",
		"blur"
	],
	methods: {
		getPTOptions: function getPTOptions(key) {
			return (key === "root" ? this.ptmi : this.ptm)(key, { context: {
				checked: this.checked,
				disabled: this.disabled
			} });
		},
		onChange: function onChange(event) {
			if (!this.disabled && !this.readonly) {
				var newValue = this.checked ? this.falseValue : this.trueValue;
				this.writeValue(newValue, event);
				this.$emit("change", event);
			}
		},
		onFocus: function onFocus(event) {
			this.$emit("focus", event);
		},
		onBlur: function onBlur(event) {
			var _this$formField$onBlu, _this$formField;
			this.$emit("blur", event);
			(_this$formField$onBlu = (_this$formField = this.formField).onBlur) === null || _this$formField$onBlu === void 0 || _this$formField$onBlu.call(_this$formField, event);
		}
	},
	computed: {
		checked: function checked() {
			return this.d_value === this.trueValue;
		},
		dataP: function dataP() {
			return c({
				checked: this.checked,
				disabled: this.disabled,
				invalid: this.$invalid
			});
		}
	}
};
var _hoisted_1 = [
	"data-p-checked",
	"data-p-disabled",
	"data-p"
];
var _hoisted_2 = [
	"id",
	"checked",
	"tabindex",
	"disabled",
	"readonly",
	"aria-checked",
	"aria-labelledby",
	"aria-label",
	"aria-invalid"
];
var _hoisted_3 = ["data-p"];
var _hoisted_4 = ["data-p"];
function render(_ctx, _cache, $props, $setup, $data, $options) {
	return openBlock(), createElementBlock("div", mergeProps({
		"class": _ctx.cx("root"),
		style: _ctx.sx("root")
	}, $options.getPTOptions("root"), {
		"data-p-checked": $options.checked,
		"data-p-disabled": _ctx.disabled,
		"data-p": $options.dataP
	}), [createElementVNode("input", mergeProps({
		id: _ctx.inputId,
		type: "checkbox",
		role: "switch",
		"class": [_ctx.cx("input"), _ctx.inputClass],
		style: _ctx.inputStyle,
		checked: $options.checked,
		tabindex: _ctx.tabindex,
		disabled: _ctx.disabled,
		readonly: _ctx.readonly,
		"aria-checked": $options.checked,
		"aria-labelledby": _ctx.ariaLabelledby,
		"aria-label": _ctx.ariaLabel,
		"aria-invalid": _ctx.invalid || void 0,
		onFocus: _cache[0] || (_cache[0] = function() {
			return $options.onFocus && $options.onFocus.apply($options, arguments);
		}),
		onBlur: _cache[1] || (_cache[1] = function() {
			return $options.onBlur && $options.onBlur.apply($options, arguments);
		}),
		onChange: _cache[2] || (_cache[2] = function() {
			return $options.onChange && $options.onChange.apply($options, arguments);
		})
	}, $options.getPTOptions("input")), null, 16, _hoisted_2), createElementVNode("div", mergeProps({ "class": _ctx.cx("slider") }, $options.getPTOptions("slider"), { "data-p": $options.dataP }), [createElementVNode("div", mergeProps({ "class": _ctx.cx("handle") }, $options.getPTOptions("handle"), { "data-p": $options.dataP }), [renderSlot(_ctx.$slots, "handle", { checked: $options.checked })], 16, _hoisted_4)], 16, _hoisted_3)], 16, _hoisted_1);
}
script.render = render;
//#endregion
export { script as default };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJpbWV2dWVfdG9nZ2xlc3dpdGNoLmpzIiwibmFtZXMiOlsiQmFzZUVkaXRhYmxlSG9sZGVyIiwiY24iXSwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8ucG5wbS9AcHJpbWV1aXgrc3R5bGVzQDMuMC4wL25vZGVfbW9kdWxlcy9AcHJpbWV1aXgvc3R5bGVzL2Rpc3QvdG9nZ2xlc3dpdGNoL2luZGV4Lm1qcyIsIi4uLy4uLy4uLy4uLy5wbnBtL3ByaW1ldnVlQDUuMC4wX3Z1ZUAzLjUuNDBfdHlwZXNjcmlwdEA2LjAuM18vbm9kZV9tb2R1bGVzL3ByaW1ldnVlL3RvZ2dsZXN3aXRjaC9zdHlsZS9pbmRleC5tanMiLCIuLi8uLi8uLi8uLi8ucG5wbS9wcmltZXZ1ZUA1LjAuMF92dWVAMy41LjQwX3R5cGVzY3JpcHRANi4wLjNfL25vZGVfbW9kdWxlcy9wcmltZXZ1ZS90b2dnbGVzd2l0Y2gvaW5kZXgubWpzIl0sInNvdXJjZXNDb250ZW50IjpbInZhciBzdHlsZT1cIlxcbiAgICAucC10b2dnbGVzd2l0Y2gge1xcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xcbiAgICAgICAgd2lkdGg6IGR0KCd0b2dnbGVzd2l0Y2gud2lkdGgnKTtcXG4gICAgICAgIGhlaWdodDogZHQoJ3RvZ2dsZXN3aXRjaC5oZWlnaHQnKTtcXG4gICAgfVxcblxcbiAgICAucC10b2dnbGVzd2l0Y2gtaW5wdXQge1xcbiAgICAgICAgY3Vyc29yOiBwb2ludGVyO1xcbiAgICAgICAgYXBwZWFyYW5jZTogbm9uZTtcXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gICAgICAgIHRvcDogMDtcXG4gICAgICAgIGluc2V0LWlubGluZS1zdGFydDogMDtcXG4gICAgICAgIHdpZHRoOiAxMDAlO1xcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xcbiAgICAgICAgcGFkZGluZzogMDtcXG4gICAgICAgIG1hcmdpbjogMDtcXG4gICAgICAgIG9wYWNpdHk6IDA7XFxuICAgICAgICB6LWluZGV4OiAxO1xcbiAgICAgICAgb3V0bGluZTogMCBub25lO1xcbiAgICAgICAgYm9yZGVyLXJhZGl1czogZHQoJ3RvZ2dsZXN3aXRjaC5ib3JkZXIucmFkaXVzJyk7XFxuICAgIH1cXG5cXG4gICAgLnAtdG9nZ2xlc3dpdGNoLXNsaWRlciB7XFxuICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XFxuICAgICAgICB3aWR0aDogMTAwJTtcXG4gICAgICAgIGhlaWdodDogMTAwJTtcXG4gICAgICAgIGJvcmRlci13aWR0aDogZHQoJ3RvZ2dsZXN3aXRjaC5ib3JkZXIud2lkdGgnKTtcXG4gICAgICAgIGJvcmRlci1zdHlsZTogc29saWQ7XFxuICAgICAgICBib3JkZXItY29sb3I6IGR0KCd0b2dnbGVzd2l0Y2guYm9yZGVyLmNvbG9yJyk7XFxuICAgICAgICBiYWNrZ3JvdW5kOiBkdCgndG9nZ2xlc3dpdGNoLmJhY2tncm91bmQnKTtcXG4gICAgICAgIHRyYW5zaXRpb246XFxuICAgICAgICAgICAgYmFja2dyb3VuZCBkdCgndG9nZ2xlc3dpdGNoLnRyYW5zaXRpb24uZHVyYXRpb24nKSxcXG4gICAgICAgICAgICBjb2xvciBkdCgndG9nZ2xlc3dpdGNoLnRyYW5zaXRpb24uZHVyYXRpb24nKSxcXG4gICAgICAgICAgICBib3JkZXItY29sb3IgZHQoJ3RvZ2dsZXN3aXRjaC50cmFuc2l0aW9uLmR1cmF0aW9uJyksXFxuICAgICAgICAgICAgb3V0bGluZS1jb2xvciBkdCgndG9nZ2xlc3dpdGNoLnRyYW5zaXRpb24uZHVyYXRpb24nKSxcXG4gICAgICAgICAgICBib3gtc2hhZG93IGR0KCd0b2dnbGVzd2l0Y2gudHJhbnNpdGlvbi5kdXJhdGlvbicpO1xcbiAgICAgICAgYm9yZGVyLXJhZGl1czogZHQoJ3RvZ2dsZXN3aXRjaC5ib3JkZXIucmFkaXVzJyk7XFxuICAgICAgICBvdXRsaW5lLWNvbG9yOiB0cmFuc3BhcmVudDtcXG4gICAgICAgIGJveC1zaGFkb3c6IGR0KCd0b2dnbGVzd2l0Y2guc2hhZG93Jyk7XFxuICAgIH1cXG5cXG4gICAgLnAtdG9nZ2xlc3dpdGNoLWhhbmRsZSB7XFxuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XFxuICAgICAgICB0b3A6IDUwJTtcXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XFxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XFxuICAgICAgICBiYWNrZ3JvdW5kOiBkdCgndG9nZ2xlc3dpdGNoLmhhbmRsZS5iYWNrZ3JvdW5kJyk7XFxuICAgICAgICBjb2xvcjogZHQoJ3RvZ2dsZXN3aXRjaC5oYW5kbGUuY29sb3InKTtcXG4gICAgICAgIHdpZHRoOiBkdCgndG9nZ2xlc3dpdGNoLmhhbmRsZS5zaXplJyk7XFxuICAgICAgICBoZWlnaHQ6IGR0KCd0b2dnbGVzd2l0Y2guaGFuZGxlLnNpemUnKTtcXG4gICAgICAgIGluc2V0LWlubGluZS1zdGFydDogZHQoJ3RvZ2dsZXN3aXRjaC5nYXAnKTtcXG4gICAgICAgIG1hcmdpbi1ibG9jay1zdGFydDogY2FsYygtMSAqIGNhbGMoZHQoJ3RvZ2dsZXN3aXRjaC5oYW5kbGUuc2l6ZScpIC8gMikpO1xcbiAgICAgICAgYm9yZGVyLXJhZGl1czogZHQoJ3RvZ2dsZXN3aXRjaC5oYW5kbGUuYm9yZGVyLnJhZGl1cycpO1xcbiAgICAgICAgdHJhbnNpdGlvbjpcXG4gICAgICAgICAgICBiYWNrZ3JvdW5kIGR0KCd0b2dnbGVzd2l0Y2gudHJhbnNpdGlvbi5kdXJhdGlvbicpLFxcbiAgICAgICAgICAgIGNvbG9yIGR0KCd0b2dnbGVzd2l0Y2gudHJhbnNpdGlvbi5kdXJhdGlvbicpLFxcbiAgICAgICAgICAgIGluc2V0LWlubGluZS1zdGFydCBkdCgndG9nZ2xlc3dpdGNoLnNsaWRlLmR1cmF0aW9uJyksXFxuICAgICAgICAgICAgYm94LXNoYWRvdyBkdCgndG9nZ2xlc3dpdGNoLnNsaWRlLmR1cmF0aW9uJyk7XFxuICAgIH1cXG5cXG4gICAgLnAtdG9nZ2xlc3dpdGNoLnAtdG9nZ2xlc3dpdGNoLWNoZWNrZWQgLnAtdG9nZ2xlc3dpdGNoLXNsaWRlciB7XFxuICAgICAgICBiYWNrZ3JvdW5kOiBkdCgndG9nZ2xlc3dpdGNoLmNoZWNrZWQuYmFja2dyb3VuZCcpO1xcbiAgICAgICAgYm9yZGVyLWNvbG9yOiBkdCgndG9nZ2xlc3dpdGNoLmNoZWNrZWQuYm9yZGVyLmNvbG9yJyk7XFxuICAgIH1cXG5cXG4gICAgLnAtdG9nZ2xlc3dpdGNoLnAtdG9nZ2xlc3dpdGNoLWNoZWNrZWQgLnAtdG9nZ2xlc3dpdGNoLWhhbmRsZSB7XFxuICAgICAgICBiYWNrZ3JvdW5kOiBkdCgndG9nZ2xlc3dpdGNoLmhhbmRsZS5jaGVja2VkLmJhY2tncm91bmQnKTtcXG4gICAgICAgIGNvbG9yOiBkdCgndG9nZ2xlc3dpdGNoLmhhbmRsZS5jaGVja2VkLmNvbG9yJyk7XFxuICAgICAgICBpbnNldC1pbmxpbmUtc3RhcnQ6IGNhbGMoZHQoJ3RvZ2dsZXN3aXRjaC53aWR0aCcpIC0gY2FsYyhkdCgndG9nZ2xlc3dpdGNoLmhhbmRsZS5zaXplJykgKyBkdCgndG9nZ2xlc3dpdGNoLmdhcCcpKSk7XFxuICAgIH1cXG5cXG4gICAgLnAtdG9nZ2xlc3dpdGNoOm5vdCgucC1kaXNhYmxlZCk6aGFzKC5wLXRvZ2dsZXN3aXRjaC1pbnB1dDpob3ZlcikgLnAtdG9nZ2xlc3dpdGNoLXNsaWRlciB7XFxuICAgICAgICBiYWNrZ3JvdW5kOiBkdCgndG9nZ2xlc3dpdGNoLmhvdmVyLmJhY2tncm91bmQnKTtcXG4gICAgICAgIGJvcmRlci1jb2xvcjogZHQoJ3RvZ2dsZXN3aXRjaC5ob3Zlci5ib3JkZXIuY29sb3InKTtcXG4gICAgfVxcblxcbiAgICAucC10b2dnbGVzd2l0Y2g6bm90KC5wLWRpc2FibGVkKTpoYXMoLnAtdG9nZ2xlc3dpdGNoLWlucHV0OmhvdmVyKSAucC10b2dnbGVzd2l0Y2gtaGFuZGxlIHtcXG4gICAgICAgIGJhY2tncm91bmQ6IGR0KCd0b2dnbGVzd2l0Y2guaGFuZGxlLmhvdmVyLmJhY2tncm91bmQnKTtcXG4gICAgICAgIGNvbG9yOiBkdCgndG9nZ2xlc3dpdGNoLmhhbmRsZS5ob3Zlci5jb2xvcicpO1xcbiAgICB9XFxuXFxuICAgIC5wLXRvZ2dsZXN3aXRjaDpub3QoLnAtZGlzYWJsZWQpOmhhcygucC10b2dnbGVzd2l0Y2gtaW5wdXQ6aG92ZXIpLnAtdG9nZ2xlc3dpdGNoLWNoZWNrZWQgLnAtdG9nZ2xlc3dpdGNoLXNsaWRlciB7XFxuICAgICAgICBiYWNrZ3JvdW5kOiBkdCgndG9nZ2xlc3dpdGNoLmNoZWNrZWQuaG92ZXIuYmFja2dyb3VuZCcpO1xcbiAgICAgICAgYm9yZGVyLWNvbG9yOiBkdCgndG9nZ2xlc3dpdGNoLmNoZWNrZWQuaG92ZXIuYm9yZGVyLmNvbG9yJyk7XFxuICAgIH1cXG5cXG4gICAgLnAtdG9nZ2xlc3dpdGNoOm5vdCgucC1kaXNhYmxlZCk6aGFzKC5wLXRvZ2dsZXN3aXRjaC1pbnB1dDpob3ZlcikucC10b2dnbGVzd2l0Y2gtY2hlY2tlZCAucC10b2dnbGVzd2l0Y2gtaGFuZGxlIHtcXG4gICAgICAgIGJhY2tncm91bmQ6IGR0KCd0b2dnbGVzd2l0Y2guaGFuZGxlLmNoZWNrZWQuaG92ZXIuYmFja2dyb3VuZCcpO1xcbiAgICAgICAgY29sb3I6IGR0KCd0b2dnbGVzd2l0Y2guaGFuZGxlLmNoZWNrZWQuaG92ZXIuY29sb3InKTtcXG4gICAgfVxcblxcbiAgICAucC10b2dnbGVzd2l0Y2g6bm90KC5wLWRpc2FibGVkKTpoYXMoLnAtdG9nZ2xlc3dpdGNoLWlucHV0OmZvY3VzLXZpc2libGUpIC5wLXRvZ2dsZXN3aXRjaC1zbGlkZXIge1xcbiAgICAgICAgYm94LXNoYWRvdzogZHQoJ3RvZ2dsZXN3aXRjaC5mb2N1cy5yaW5nLnNoYWRvdycpO1xcbiAgICAgICAgb3V0bGluZTogZHQoJ3RvZ2dsZXN3aXRjaC5mb2N1cy5yaW5nLndpZHRoJykgZHQoJ3RvZ2dsZXN3aXRjaC5mb2N1cy5yaW5nLnN0eWxlJykgZHQoJ3RvZ2dsZXN3aXRjaC5mb2N1cy5yaW5nLmNvbG9yJyk7XFxuICAgICAgICBvdXRsaW5lLW9mZnNldDogZHQoJ3RvZ2dsZXN3aXRjaC5mb2N1cy5yaW5nLm9mZnNldCcpO1xcbiAgICB9XFxuXFxuICAgIC5wLXRvZ2dsZXN3aXRjaC5wLWludmFsaWQgPiAucC10b2dnbGVzd2l0Y2gtc2xpZGVyIHtcXG4gICAgICAgIGJvcmRlci1jb2xvcjogZHQoJ3RvZ2dsZXN3aXRjaC5pbnZhbGlkLmJvcmRlci5jb2xvcicpO1xcbiAgICB9XFxuXFxuICAgIC5wLXRvZ2dsZXN3aXRjaC5wLWRpc2FibGVkIHtcXG4gICAgICAgIG9wYWNpdHk6IDE7XFxuICAgIH1cXG5cXG4gICAgLnAtdG9nZ2xlc3dpdGNoLnAtZGlzYWJsZWQgLnAtdG9nZ2xlc3dpdGNoLXNsaWRlciB7XFxuICAgICAgICBiYWNrZ3JvdW5kOiBkdCgndG9nZ2xlc3dpdGNoLmRpc2FibGVkLmJhY2tncm91bmQnKTtcXG4gICAgfVxcblxcbiAgICAucC10b2dnbGVzd2l0Y2gucC1kaXNhYmxlZCAucC10b2dnbGVzd2l0Y2gtaGFuZGxlIHtcXG4gICAgICAgIGJhY2tncm91bmQ6IGR0KCd0b2dnbGVzd2l0Y2guaGFuZGxlLmRpc2FibGVkLmJhY2tncm91bmQnKTtcXG4gICAgfVxcblwiO2V4cG9ydHtzdHlsZX07IiwiaW1wb3J0IHsgc3R5bGUgfSBmcm9tICdAcHJpbWV1aXgvc3R5bGVzL3RvZ2dsZXN3aXRjaCc7XG5pbXBvcnQgQmFzZVN0eWxlIGZyb20gJ0BwcmltZXZ1ZS9jb3JlL2Jhc2Uvc3R5bGUnO1xuXG52YXIgaW5saW5lU3R5bGVzID0ge1xuICByb290OiB7XG4gICAgcG9zaXRpb246ICdyZWxhdGl2ZSdcbiAgfVxufTtcbnZhciBjbGFzc2VzID0ge1xuICByb290OiBmdW5jdGlvbiByb290KF9yZWYpIHtcbiAgICB2YXIgaW5zdGFuY2UgPSBfcmVmLmluc3RhbmNlLFxuICAgICAgcHJvcHMgPSBfcmVmLnByb3BzO1xuICAgIHJldHVybiBbJ3AtdG9nZ2xlc3dpdGNoIHAtY29tcG9uZW50Jywge1xuICAgICAgJ3AtdG9nZ2xlc3dpdGNoLWNoZWNrZWQnOiBpbnN0YW5jZS5jaGVja2VkLFxuICAgICAgJ3AtZGlzYWJsZWQnOiBwcm9wcy5kaXNhYmxlZCxcbiAgICAgICdwLWludmFsaWQnOiBpbnN0YW5jZS4kaW52YWxpZFxuICAgIH1dO1xuICB9LFxuICBpbnB1dDogJ3AtdG9nZ2xlc3dpdGNoLWlucHV0JyxcbiAgc2xpZGVyOiAncC10b2dnbGVzd2l0Y2gtc2xpZGVyJyxcbiAgaGFuZGxlOiAncC10b2dnbGVzd2l0Y2gtaGFuZGxlJ1xufTtcbnZhciBUb2dnbGVTd2l0Y2hTdHlsZSA9IEJhc2VTdHlsZS5leHRlbmQoe1xuICBuYW1lOiAndG9nZ2xlc3dpdGNoJyxcbiAgc3R5bGU6IHN0eWxlLFxuICBjbGFzc2VzOiBjbGFzc2VzLFxuICBpbmxpbmVTdHlsZXM6IGlubGluZVN0eWxlc1xufSk7XG5cbmV4cG9ydCB7IFRvZ2dsZVN3aXRjaFN0eWxlIGFzIGRlZmF1bHQgfTtcbiIsImltcG9ydCB7IGNuIH0gZnJvbSAnQHByaW1ldWl4L3V0aWxzJztcbmltcG9ydCBCYXNlRWRpdGFibGVIb2xkZXIgZnJvbSAnQHByaW1ldnVlL2NvcmUvYmFzZWVkaXRhYmxlaG9sZGVyJztcbmltcG9ydCBUb2dnbGVTd2l0Y2hTdHlsZSBmcm9tICdwcmltZXZ1ZS90b2dnbGVzd2l0Y2gvc3R5bGUnO1xuaW1wb3J0IHsgb3BlbkJsb2NrLCBjcmVhdGVFbGVtZW50QmxvY2ssIG1lcmdlUHJvcHMsIGNyZWF0ZUVsZW1lbnRWTm9kZSwgcmVuZGVyU2xvdCB9IGZyb20gJ3Z1ZSc7XG5cbnZhciBzY3JpcHQkMSA9IHtcbiAgbmFtZTogJ0Jhc2VUb2dnbGVTd2l0Y2gnLFxuICBcImV4dGVuZHNcIjogQmFzZUVkaXRhYmxlSG9sZGVyLFxuICBwcm9wczoge1xuICAgIHRydWVWYWx1ZToge1xuICAgICAgdHlwZTogbnVsbCxcbiAgICAgIFwiZGVmYXVsdFwiOiB0cnVlXG4gICAgfSxcbiAgICBmYWxzZVZhbHVlOiB7XG4gICAgICB0eXBlOiBudWxsLFxuICAgICAgXCJkZWZhdWx0XCI6IGZhbHNlXG4gICAgfSxcbiAgICByZWFkb25seToge1xuICAgICAgdHlwZTogQm9vbGVhbixcbiAgICAgIFwiZGVmYXVsdFwiOiBmYWxzZVxuICAgIH0sXG4gICAgdGFiaW5kZXg6IHtcbiAgICAgIHR5cGU6IE51bWJlcixcbiAgICAgIFwiZGVmYXVsdFwiOiBudWxsXG4gICAgfSxcbiAgICBpbnB1dElkOiB7XG4gICAgICB0eXBlOiBTdHJpbmcsXG4gICAgICBcImRlZmF1bHRcIjogbnVsbFxuICAgIH0sXG4gICAgaW5wdXRDbGFzczoge1xuICAgICAgdHlwZTogW1N0cmluZywgT2JqZWN0XSxcbiAgICAgIFwiZGVmYXVsdFwiOiBudWxsXG4gICAgfSxcbiAgICBpbnB1dFN0eWxlOiB7XG4gICAgICB0eXBlOiBPYmplY3QsXG4gICAgICBcImRlZmF1bHRcIjogbnVsbFxuICAgIH0sXG4gICAgYXJpYUxhYmVsbGVkYnk6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIFwiZGVmYXVsdFwiOiBudWxsXG4gICAgfSxcbiAgICBhcmlhTGFiZWw6IHtcbiAgICAgIHR5cGU6IFN0cmluZyxcbiAgICAgIFwiZGVmYXVsdFwiOiBudWxsXG4gICAgfVxuICB9LFxuICBzdHlsZTogVG9nZ2xlU3dpdGNoU3R5bGUsXG4gIHByb3ZpZGU6IGZ1bmN0aW9uIHByb3ZpZGUoKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICRwY1RvZ2dsZVN3aXRjaDogdGhpcyxcbiAgICAgICRwYXJlbnRJbnN0YW5jZTogdGhpc1xuICAgIH07XG4gIH1cbn07XG5cbnZhciBzY3JpcHQgPSB7XG4gIG5hbWU6ICdUb2dnbGVTd2l0Y2gnLFxuICBcImV4dGVuZHNcIjogc2NyaXB0JDEsXG4gIGluaGVyaXRBdHRyczogZmFsc2UsXG4gIGVtaXRzOiBbJ2NoYW5nZScsICdmb2N1cycsICdibHVyJ10sXG4gIG1ldGhvZHM6IHtcbiAgICBnZXRQVE9wdGlvbnM6IGZ1bmN0aW9uIGdldFBUT3B0aW9ucyhrZXkpIHtcbiAgICAgIHZhciBfcHRtID0ga2V5ID09PSAncm9vdCcgPyB0aGlzLnB0bWkgOiB0aGlzLnB0bTtcbiAgICAgIHJldHVybiBfcHRtKGtleSwge1xuICAgICAgICBjb250ZXh0OiB7XG4gICAgICAgICAgY2hlY2tlZDogdGhpcy5jaGVja2VkLFxuICAgICAgICAgIGRpc2FibGVkOiB0aGlzLmRpc2FibGVkXG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0sXG4gICAgb25DaGFuZ2U6IGZ1bmN0aW9uIG9uQ2hhbmdlKGV2ZW50KSB7XG4gICAgICBpZiAoIXRoaXMuZGlzYWJsZWQgJiYgIXRoaXMucmVhZG9ubHkpIHtcbiAgICAgICAgdmFyIG5ld1ZhbHVlID0gdGhpcy5jaGVja2VkID8gdGhpcy5mYWxzZVZhbHVlIDogdGhpcy50cnVlVmFsdWU7XG4gICAgICAgIHRoaXMud3JpdGVWYWx1ZShuZXdWYWx1ZSwgZXZlbnQpO1xuICAgICAgICB0aGlzLiRlbWl0KCdjaGFuZ2UnLCBldmVudCk7XG4gICAgICB9XG4gICAgfSxcbiAgICBvbkZvY3VzOiBmdW5jdGlvbiBvbkZvY3VzKGV2ZW50KSB7XG4gICAgICB0aGlzLiRlbWl0KCdmb2N1cycsIGV2ZW50KTtcbiAgICB9LFxuICAgIG9uQmx1cjogZnVuY3Rpb24gb25CbHVyKGV2ZW50KSB7XG4gICAgICB2YXIgX3RoaXMkZm9ybUZpZWxkJG9uQmx1LCBfdGhpcyRmb3JtRmllbGQ7XG4gICAgICB0aGlzLiRlbWl0KCdibHVyJywgZXZlbnQpO1xuICAgICAgKF90aGlzJGZvcm1GaWVsZCRvbkJsdSA9IChfdGhpcyRmb3JtRmllbGQgPSB0aGlzLmZvcm1GaWVsZCkub25CbHVyKSA9PT0gbnVsbCB8fCBfdGhpcyRmb3JtRmllbGQkb25CbHUgPT09IHZvaWQgMCB8fCBfdGhpcyRmb3JtRmllbGQkb25CbHUuY2FsbChfdGhpcyRmb3JtRmllbGQsIGV2ZW50KTtcbiAgICB9XG4gIH0sXG4gIGNvbXB1dGVkOiB7XG4gICAgY2hlY2tlZDogZnVuY3Rpb24gY2hlY2tlZCgpIHtcbiAgICAgIHJldHVybiB0aGlzLmRfdmFsdWUgPT09IHRoaXMudHJ1ZVZhbHVlO1xuICAgIH0sXG4gICAgZGF0YVA6IGZ1bmN0aW9uIGRhdGFQKCkge1xuICAgICAgcmV0dXJuIGNuKHtcbiAgICAgICAgY2hlY2tlZDogdGhpcy5jaGVja2VkLFxuICAgICAgICBkaXNhYmxlZDogdGhpcy5kaXNhYmxlZCxcbiAgICAgICAgaW52YWxpZDogdGhpcy4kaW52YWxpZFxuICAgICAgfSk7XG4gICAgfVxuICB9XG59O1xuXG52YXIgX2hvaXN0ZWRfMSA9IFtcImRhdGEtcC1jaGVja2VkXCIsIFwiZGF0YS1wLWRpc2FibGVkXCIsIFwiZGF0YS1wXCJdO1xudmFyIF9ob2lzdGVkXzIgPSBbXCJpZFwiLCBcImNoZWNrZWRcIiwgXCJ0YWJpbmRleFwiLCBcImRpc2FibGVkXCIsIFwicmVhZG9ubHlcIiwgXCJhcmlhLWNoZWNrZWRcIiwgXCJhcmlhLWxhYmVsbGVkYnlcIiwgXCJhcmlhLWxhYmVsXCIsIFwiYXJpYS1pbnZhbGlkXCJdO1xudmFyIF9ob2lzdGVkXzMgPSBbXCJkYXRhLXBcIl07XG52YXIgX2hvaXN0ZWRfNCA9IFtcImRhdGEtcFwiXTtcbmZ1bmN0aW9uIHJlbmRlcihfY3R4LCBfY2FjaGUsICRwcm9wcywgJHNldHVwLCAkZGF0YSwgJG9wdGlvbnMpIHtcbiAgcmV0dXJuIG9wZW5CbG9jaygpLCBjcmVhdGVFbGVtZW50QmxvY2soXCJkaXZcIiwgbWVyZ2VQcm9wcyh7XG4gICAgXCJjbGFzc1wiOiBfY3R4LmN4KCdyb290JyksXG4gICAgc3R5bGU6IF9jdHguc3goJ3Jvb3QnKVxuICB9LCAkb3B0aW9ucy5nZXRQVE9wdGlvbnMoJ3Jvb3QnKSwge1xuICAgIFwiZGF0YS1wLWNoZWNrZWRcIjogJG9wdGlvbnMuY2hlY2tlZCxcbiAgICBcImRhdGEtcC1kaXNhYmxlZFwiOiBfY3R4LmRpc2FibGVkLFxuICAgIFwiZGF0YS1wXCI6ICRvcHRpb25zLmRhdGFQXG4gIH0pLCBbY3JlYXRlRWxlbWVudFZOb2RlKFwiaW5wdXRcIiwgbWVyZ2VQcm9wcyh7XG4gICAgaWQ6IF9jdHguaW5wdXRJZCxcbiAgICB0eXBlOiBcImNoZWNrYm94XCIsXG4gICAgcm9sZTogXCJzd2l0Y2hcIixcbiAgICBcImNsYXNzXCI6IFtfY3R4LmN4KCdpbnB1dCcpLCBfY3R4LmlucHV0Q2xhc3NdLFxuICAgIHN0eWxlOiBfY3R4LmlucHV0U3R5bGUsXG4gICAgY2hlY2tlZDogJG9wdGlvbnMuY2hlY2tlZCxcbiAgICB0YWJpbmRleDogX2N0eC50YWJpbmRleCxcbiAgICBkaXNhYmxlZDogX2N0eC5kaXNhYmxlZCxcbiAgICByZWFkb25seTogX2N0eC5yZWFkb25seSxcbiAgICBcImFyaWEtY2hlY2tlZFwiOiAkb3B0aW9ucy5jaGVja2VkLFxuICAgIFwiYXJpYS1sYWJlbGxlZGJ5XCI6IF9jdHguYXJpYUxhYmVsbGVkYnksXG4gICAgXCJhcmlhLWxhYmVsXCI6IF9jdHguYXJpYUxhYmVsLFxuICAgIFwiYXJpYS1pbnZhbGlkXCI6IF9jdHguaW52YWxpZCB8fCB1bmRlZmluZWQsXG4gICAgb25Gb2N1czogX2NhY2hlWzBdIHx8IChfY2FjaGVbMF0gPSBmdW5jdGlvbiAoKSB7XG4gICAgICByZXR1cm4gJG9wdGlvbnMub25Gb2N1cyAmJiAkb3B0aW9ucy5vbkZvY3VzLmFwcGx5KCRvcHRpb25zLCBhcmd1bWVudHMpO1xuICAgIH0pLFxuICAgIG9uQmx1cjogX2NhY2hlWzFdIHx8IChfY2FjaGVbMV0gPSBmdW5jdGlvbiAoKSB7XG4gICAgICByZXR1cm4gJG9wdGlvbnMub25CbHVyICYmICRvcHRpb25zLm9uQmx1ci5hcHBseSgkb3B0aW9ucywgYXJndW1lbnRzKTtcbiAgICB9KSxcbiAgICBvbkNoYW5nZTogX2NhY2hlWzJdIHx8IChfY2FjaGVbMl0gPSBmdW5jdGlvbiAoKSB7XG4gICAgICByZXR1cm4gJG9wdGlvbnMub25DaGFuZ2UgJiYgJG9wdGlvbnMub25DaGFuZ2UuYXBwbHkoJG9wdGlvbnMsIGFyZ3VtZW50cyk7XG4gICAgfSlcbiAgfSwgJG9wdGlvbnMuZ2V0UFRPcHRpb25zKCdpbnB1dCcpKSwgbnVsbCwgMTYsIF9ob2lzdGVkXzIpLCBjcmVhdGVFbGVtZW50Vk5vZGUoXCJkaXZcIiwgbWVyZ2VQcm9wcyh7XG4gICAgXCJjbGFzc1wiOiBfY3R4LmN4KCdzbGlkZXInKVxuICB9LCAkb3B0aW9ucy5nZXRQVE9wdGlvbnMoJ3NsaWRlcicpLCB7XG4gICAgXCJkYXRhLXBcIjogJG9wdGlvbnMuZGF0YVBcbiAgfSksIFtjcmVhdGVFbGVtZW50Vk5vZGUoXCJkaXZcIiwgbWVyZ2VQcm9wcyh7XG4gICAgXCJjbGFzc1wiOiBfY3R4LmN4KCdoYW5kbGUnKVxuICB9LCAkb3B0aW9ucy5nZXRQVE9wdGlvbnMoJ2hhbmRsZScpLCB7XG4gICAgXCJkYXRhLXBcIjogJG9wdGlvbnMuZGF0YVBcbiAgfSksIFtyZW5kZXJTbG90KF9jdHguJHNsb3RzLCBcImhhbmRsZVwiLCB7XG4gICAgY2hlY2tlZDogJG9wdGlvbnMuY2hlY2tlZFxuICB9KV0sIDE2LCBfaG9pc3RlZF80KV0sIDE2LCBfaG9pc3RlZF8zKV0sIDE2LCBfaG9pc3RlZF8xKTtcbn1cblxuc2NyaXB0LnJlbmRlciA9IHJlbmRlcjtcblxuZXhwb3J0IHsgc2NyaXB0IGFzIGRlZmF1bHQgfTtcbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDJdLCJtYXBwaW5ncyI6Ijs7Ozs7O0FDc0JBLElBQUksb0JBQW9CLFVBQVUsT0FBTztDQUN2QyxNQUFNO0NBQ0M7Q0FDUCxTQUFTO0VBaEJULE1BQU0sU0FBUyxLQUFLLE1BQU07R0FDeEIsSUFBSSxXQUFXLEtBQUssVUFDbEIsUUFBUSxLQUFLO0dBQ2YsT0FBTyxDQUFDLDhCQUE4QjtJQUNwQywwQkFBMEIsU0FBUztJQUNuQyxjQUFjLE1BQU07SUFDcEIsYUFBYSxTQUFTO0dBQ3hCLENBQUM7RUFDSDtFQUNBLE9BQU87RUFDUCxRQUFRO0VBQ1IsUUFBUTtDQUtPO0NBQ2YsY0FBYyxFQXRCZCxNQUFNLEVBQ0osVUFBVSxXQUNaLEVBb0J5QjtBQUMzQixDQUFDOzs7QUM0QkQsSUFBSSxTQUFTO0NBQ1gsTUFBTTtDQUNOLFdBQVc7RUFuRFgsTUFBTTtFQUNOLFdBQVdBO0VBQ1gsT0FBTztHQUNMLFdBQVc7SUFDVCxNQUFNO0lBQ04sV0FBVztHQUNiO0dBQ0EsWUFBWTtJQUNWLE1BQU07SUFDTixXQUFXO0dBQ2I7R0FDQSxVQUFVO0lBQ1IsTUFBTTtJQUNOLFdBQVc7R0FDYjtHQUNBLFVBQVU7SUFDUixNQUFNO0lBQ04sV0FBVztHQUNiO0dBQ0EsU0FBUztJQUNQLE1BQU07SUFDTixXQUFXO0dBQ2I7R0FDQSxZQUFZO0lBQ1YsTUFBTSxDQUFDLFFBQVEsTUFBTTtJQUNyQixXQUFXO0dBQ2I7R0FDQSxZQUFZO0lBQ1YsTUFBTTtJQUNOLFdBQVc7R0FDYjtHQUNBLGdCQUFnQjtJQUNkLE1BQU07SUFDTixXQUFXO0dBQ2I7R0FDQSxXQUFXO0lBQ1QsTUFBTTtJQUNOLFdBQVc7R0FDYjtFQUNGO0VBQ0EsT0FBTztFQUNQLFNBQVMsU0FBUyxVQUFVO0dBQzFCLE9BQU87SUFDTCxpQkFBaUI7SUFDakIsaUJBQWlCO0dBQ25CO0VBQ0Y7Q0FLa0I7Q0FDbEIsY0FBYztDQUNkLE9BQU87RUFBQztFQUFVO0VBQVM7Q0FBTTtDQUNqQyxTQUFTO0VBQ1AsY0FBYyxTQUFTLGFBQWEsS0FBSztHQUV2QyxRQURXLFFBQVEsU0FBUyxLQUFLLE9BQU8sS0FBSyxJQUFBLENBQ2pDLEtBQUssRUFDZixTQUFTO0lBQ1AsU0FBUyxLQUFLO0lBQ2QsVUFBVSxLQUFLO0dBQ2pCLEVBQ0YsQ0FBQztFQUNIO0VBQ0EsVUFBVSxTQUFTLFNBQVMsT0FBTztHQUNqQyxJQUFJLENBQUMsS0FBSyxZQUFZLENBQUMsS0FBSyxVQUFVO0lBQ3BDLElBQUksV0FBVyxLQUFLLFVBQVUsS0FBSyxhQUFhLEtBQUs7SUFDckQsS0FBSyxXQUFXLFVBQVUsS0FBSztJQUMvQixLQUFLLE1BQU0sVUFBVSxLQUFLO0dBQzVCO0VBQ0Y7RUFDQSxTQUFTLFNBQVMsUUFBUSxPQUFPO0dBQy9CLEtBQUssTUFBTSxTQUFTLEtBQUs7RUFDM0I7RUFDQSxRQUFRLFNBQVMsT0FBTyxPQUFPO0dBQzdCLElBQUksdUJBQXVCO0dBQzNCLEtBQUssTUFBTSxRQUFRLEtBQUs7R0FDeEIsQ0FBQyx5QkFBeUIsa0JBQWtCLEtBQUssVUFBQSxDQUFXLFlBQVksUUFBUSwwQkFBMEIsS0FBSyxLQUFLLHNCQUFzQixLQUFLLGlCQUFpQixLQUFLO0VBQ3ZLO0NBQ0Y7Q0FDQSxVQUFVO0VBQ1IsU0FBUyxTQUFTLFVBQVU7R0FDMUIsT0FBTyxLQUFLLFlBQVksS0FBSztFQUMvQjtFQUNBLE9BQU8sU0FBUyxRQUFRO0dBQ3RCLE9BQU9DLEVBQUc7SUFDUixTQUFTLEtBQUs7SUFDZCxVQUFVLEtBQUs7SUFDZixTQUFTLEtBQUs7R0FDaEIsQ0FBQztFQUNIO0NBQ0Y7QUFDRjtBQUVBLElBQUksYUFBYTtDQUFDO0NBQWtCO0NBQW1CO0FBQVE7QUFDL0QsSUFBSSxhQUFhO0NBQUM7Q0FBTTtDQUFXO0NBQVk7Q0FBWTtDQUFZO0NBQWdCO0NBQW1CO0NBQWM7QUFBYztBQUN0SSxJQUFJLGFBQWEsQ0FBQyxRQUFRO0FBQzFCLElBQUksYUFBYSxDQUFDLFFBQVE7QUFDMUIsU0FBUyxPQUFPLE1BQU0sUUFBUSxRQUFRLFFBQVEsT0FBTyxVQUFVO0NBQzdELE9BQU8sVUFBVSxHQUFHLG1CQUFtQixPQUFPLFdBQVc7RUFDdkQsU0FBUyxLQUFLLEdBQUcsTUFBTTtFQUN2QixPQUFPLEtBQUssR0FBRyxNQUFNO0NBQ3ZCLEdBQUcsU0FBUyxhQUFhLE1BQU0sR0FBRztFQUNoQyxrQkFBa0IsU0FBUztFQUMzQixtQkFBbUIsS0FBSztFQUN4QixVQUFVLFNBQVM7Q0FDckIsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLFNBQVMsV0FBVztFQUMxQyxJQUFJLEtBQUs7RUFDVCxNQUFNO0VBQ04sTUFBTTtFQUNOLFNBQVMsQ0FBQyxLQUFLLEdBQUcsT0FBTyxHQUFHLEtBQUssVUFBVTtFQUMzQyxPQUFPLEtBQUs7RUFDWixTQUFTLFNBQVM7RUFDbEIsVUFBVSxLQUFLO0VBQ2YsVUFBVSxLQUFLO0VBQ2YsVUFBVSxLQUFLO0VBQ2YsZ0JBQWdCLFNBQVM7RUFDekIsbUJBQW1CLEtBQUs7RUFDeEIsY0FBYyxLQUFLO0VBQ25CLGdCQUFnQixLQUFLLFdBQVcsS0FBQTtFQUNoQyxTQUFTLE9BQU8sT0FBTyxPQUFPLEtBQUssV0FBWTtHQUM3QyxPQUFPLFNBQVMsV0FBVyxTQUFTLFFBQVEsTUFBTSxVQUFVLFNBQVM7RUFDdkU7RUFDQSxRQUFRLE9BQU8sT0FBTyxPQUFPLEtBQUssV0FBWTtHQUM1QyxPQUFPLFNBQVMsVUFBVSxTQUFTLE9BQU8sTUFBTSxVQUFVLFNBQVM7RUFDckU7RUFDQSxVQUFVLE9BQU8sT0FBTyxPQUFPLEtBQUssV0FBWTtHQUM5QyxPQUFPLFNBQVMsWUFBWSxTQUFTLFNBQVMsTUFBTSxVQUFVLFNBQVM7RUFDekU7Q0FDRixHQUFHLFNBQVMsYUFBYSxPQUFPLENBQUMsR0FBRyxNQUFNLElBQUksVUFBVSxHQUFHLG1CQUFtQixPQUFPLFdBQVcsRUFDOUYsU0FBUyxLQUFLLEdBQUcsUUFBUSxFQUMzQixHQUFHLFNBQVMsYUFBYSxRQUFRLEdBQUcsRUFDbEMsVUFBVSxTQUFTLE1BQ3JCLENBQUMsR0FBRyxDQUFDLG1CQUFtQixPQUFPLFdBQVcsRUFDeEMsU0FBUyxLQUFLLEdBQUcsUUFBUSxFQUMzQixHQUFHLFNBQVMsYUFBYSxRQUFRLEdBQUcsRUFDbEMsVUFBVSxTQUFTLE1BQ3JCLENBQUMsR0FBRyxDQUFDLFdBQVcsS0FBSyxRQUFRLFVBQVUsRUFDckMsU0FBUyxTQUFTLFFBQ3BCLENBQUMsQ0FBQyxHQUFHLElBQUksVUFBVSxDQUFDLEdBQUcsSUFBSSxVQUFVLENBQUMsR0FBRyxJQUFJLFVBQVU7QUFDekQ7QUFFQSxPQUFPLFNBQVMifQ==