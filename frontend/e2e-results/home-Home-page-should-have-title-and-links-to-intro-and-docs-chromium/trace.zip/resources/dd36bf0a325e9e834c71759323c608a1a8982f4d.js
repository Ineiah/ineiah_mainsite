/**
* @vue/runtime-dom v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
import { warn, BaseTransitionPropsValidators, h, BaseTransition, assertNumber, getCurrentInstance, onBeforeUpdate, queuePostFlushCb, onMounted, watch, onUnmounted, Fragment, Static, camelize, callWithAsyncErrorHandling, nextTick, unref, createVNode, defineComponent, useTransitionState, onUpdated, toRaw, getTransitionRawChildren, setTransitionHooks, resolveTransitionHooks, Text, createRenderer, isRuntimeOnly, createHydrationRenderer } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vue+runtime-core@3.5.40/node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js?v=7e73afc2";
export * from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vue+runtime-core@3.5.40/node_modules/@vue/runtime-core/dist/runtime-core.esm-bundler.js?v=7e73afc2";
import { extend, isObject, toNumber, isArray, NOOP, normalizeCssVarValue, isString, hyphenate, capitalize, includeBooleanAttr, isSymbol, isSpecialBooleanAttr, isFunction, isOn, isModelListener, camelize as camelize$1, hasOwn, isPlainObject, EMPTY_OBJ, looseIndexOf, isSet, looseEqual, looseToNumber, invokeArrayFns, isHTMLTag, isSVGTag, isMathMLTag } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vue+shared@3.5.40/node_modules/@vue/shared/dist/shared.esm-bundler.js?v=7e73afc2";
let policy = void 0;
const tt = typeof window !== "undefined" && window.trustedTypes;
if (tt) {
	try {
		policy = /* @__PURE__ */ tt.createPolicy("vue", { createHTML: (val) => val });
	} catch (e) {
		!!("development" !== "production") && warn(`Error creating trusted types policy: ${e}`);
	}
}
const unsafeToTrustedHTML = policy ? (val) => policy.createHTML(val) : (val) => val;
const svgNS = "http://www.w3.org/2000/svg";
const mathmlNS = "http://www.w3.org/1998/Math/MathML";
const doc = typeof document !== "undefined" ? document : null;
const templateContainer = doc && /* @__PURE__ */ doc.createElement("template");
const nodeOps = {
	insert: (child, parent, anchor) => {
		parent.insertBefore(child, anchor || null);
	},
	remove: (child) => {
		const parent = child.parentNode;
		if (parent) {
			parent.removeChild(child);
		}
	},
	createElement: (tag, namespace, is, props) => {
		const el = namespace === "svg" ? doc.createElementNS(svgNS, tag) : namespace === "mathml" ? doc.createElementNS(mathmlNS, tag) : is ? doc.createElement(tag, { is }) : doc.createElement(tag);
		if (tag === "select" && props && props.multiple != null) {
			el.setAttribute("multiple", props.multiple);
		}
		return el;
	},
	createText: (text) => doc.createTextNode(text),
	createComment: (text) => doc.createComment(text),
	setText: (node, text) => {
		node.nodeValue = text;
	},
	setElementText: (el, text) => {
		el.textContent = text;
	},
	parentNode: (node) => node.parentNode,
	nextSibling: (node) => node.nextSibling,
	querySelector: (selector) => doc.querySelector(selector),
	setScopeId(el, id) {
		el.setAttribute(id, "");
	},
	// __UNSAFE__
	// Reason: innerHTML.
	// Static content here can only come from compiled templates.
	// As long as the user only uses trusted templates, this is safe.
	insertStaticContent(content, parent, anchor, namespace, start, end) {
		const before = anchor ? anchor.previousSibling : parent.lastChild;
		if (start && (start === end || start.nextSibling)) {
			while (true) {
				parent.insertBefore(start.cloneNode(true), anchor);
				if (start === end || !(start = start.nextSibling)) break;
			}
		} else {
			templateContainer.innerHTML = unsafeToTrustedHTML(namespace === "svg" ? `<svg>${content}</svg>` : namespace === "mathml" ? `<math>${content}</math>` : content);
			const template = templateContainer.content;
			if (namespace === "svg" || namespace === "mathml") {
				const wrapper = template.firstChild;
				while (wrapper.firstChild) {
					template.appendChild(wrapper.firstChild);
				}
				template.removeChild(wrapper);
			}
			parent.insertBefore(template, anchor);
		}
		return [before ? before.nextSibling : parent.firstChild, anchor ? anchor.previousSibling : parent.lastChild];
	}
};
const TRANSITION = "transition";
const ANIMATION = "animation";
const vtcKey = /* @__PURE__ */ Symbol("_vtc");
const DOMTransitionPropsValidators = {
	name: String,
	type: String,
	css: {
		type: Boolean,
		default: true
	},
	duration: [
		String,
		Number,
		Object
	],
	enterFromClass: String,
	enterActiveClass: String,
	enterToClass: String,
	appearFromClass: String,
	appearActiveClass: String,
	appearToClass: String,
	leaveFromClass: String,
	leaveActiveClass: String,
	leaveToClass: String
};
const TransitionPropsValidators = /* @__PURE__ */ extend({}, BaseTransitionPropsValidators, DOMTransitionPropsValidators);
const decorate$1 = (t) => {
	t.displayName = "Transition";
	t.props = TransitionPropsValidators;
	return t;
};
const Transition = /* @__PURE__ */ decorate$1((props, { slots }) => h(BaseTransition, resolveTransitionProps(props), slots));
const callHook = (hook, args = []) => {
	if (isArray(hook)) {
		hook.forEach((h2) => h2(...args));
	} else if (hook) {
		hook(...args);
	}
};
const hasExplicitCallback = (hook) => {
	return hook ? isArray(hook) ? hook.some((h2) => h2.length > 1) : hook.length > 1 : false;
};
function resolveTransitionProps(rawProps) {
	const baseProps = {};
	for (const key in rawProps) {
		if (!(key in DOMTransitionPropsValidators)) {
			baseProps[key] = rawProps[key];
		}
	}
	if (rawProps.css === false) {
		return baseProps;
	}
	const { name = "v", type, duration, enterFromClass = `${name}-enter-from`, enterActiveClass = `${name}-enter-active`, enterToClass = `${name}-enter-to`, appearFromClass = enterFromClass, appearActiveClass = enterActiveClass, appearToClass = enterToClass, leaveFromClass = `${name}-leave-from`, leaveActiveClass = `${name}-leave-active`, leaveToClass = `${name}-leave-to` } = rawProps;
	const durations = normalizeDuration(duration);
	const enterDuration = durations && durations[0];
	const leaveDuration = durations && durations[1];
	const { onBeforeEnter, onEnter, onEnterCancelled, onLeave, onLeaveCancelled, onBeforeAppear = onBeforeEnter, onAppear = onEnter, onAppearCancelled = onEnterCancelled } = baseProps;
	const finishEnter = (el, isAppear, done, isCancelled) => {
		el._enterCancelled = isCancelled;
		removeTransitionClass(el, isAppear ? appearToClass : enterToClass);
		removeTransitionClass(el, isAppear ? appearActiveClass : enterActiveClass);
		done && done();
	};
	const finishLeave = (el, done) => {
		el._isLeaving = false;
		removeTransitionClass(el, leaveFromClass);
		removeTransitionClass(el, leaveToClass);
		removeTransitionClass(el, leaveActiveClass);
		done && done();
	};
	const makeEnterHook = (isAppear) => {
		return (el, done) => {
			const hook = isAppear ? onAppear : onEnter;
			const resolve = () => finishEnter(el, isAppear, done);
			callHook(hook, [el, resolve]);
			nextFrame(() => {
				removeTransitionClass(el, isAppear ? appearFromClass : enterFromClass);
				addTransitionClass(el, isAppear ? appearToClass : enterToClass);
				if (!hasExplicitCallback(hook)) {
					whenTransitionEnds(el, type, enterDuration, resolve);
				}
			});
		};
	};
	return extend(baseProps, {
		onBeforeEnter(el) {
			callHook(onBeforeEnter, [el]);
			addTransitionClass(el, enterFromClass);
			addTransitionClass(el, enterActiveClass);
		},
		onBeforeAppear(el) {
			callHook(onBeforeAppear, [el]);
			addTransitionClass(el, appearFromClass);
			addTransitionClass(el, appearActiveClass);
		},
		onEnter: makeEnterHook(false),
		onAppear: makeEnterHook(true),
		onLeave(el, done) {
			el._isLeaving = true;
			const resolve = () => finishLeave(el, done);
			addTransitionClass(el, leaveFromClass);
			if (!el._enterCancelled) {
				forceReflow(el);
				addTransitionClass(el, leaveActiveClass);
			} else {
				addTransitionClass(el, leaveActiveClass);
				forceReflow(el);
			}
			nextFrame(() => {
				if (!el._isLeaving) {
					return;
				}
				removeTransitionClass(el, leaveFromClass);
				addTransitionClass(el, leaveToClass);
				if (!hasExplicitCallback(onLeave)) {
					whenTransitionEnds(el, type, leaveDuration, resolve);
				}
			});
			callHook(onLeave, [el, resolve]);
		},
		onEnterCancelled(el) {
			finishEnter(el, false, void 0, true);
			callHook(onEnterCancelled, [el]);
		},
		onAppearCancelled(el) {
			finishEnter(el, true, void 0, true);
			callHook(onAppearCancelled, [el]);
		},
		onLeaveCancelled(el) {
			finishLeave(el);
			callHook(onLeaveCancelled, [el]);
		}
	});
}
function normalizeDuration(duration) {
	if (duration == null) {
		return null;
	} else if (isObject(duration)) {
		return [NumberOf(duration.enter), NumberOf(duration.leave)];
	} else {
		const n = NumberOf(duration);
		return [n, n];
	}
}
function NumberOf(val) {
	const res = toNumber(val);
	if (!!("development" !== "production")) {
		assertNumber(res, "<transition> explicit duration");
	}
	return res;
}
function addTransitionClass(el, cls) {
	cls.split(/\s+/).forEach((c) => c && el.classList.add(c));
	(el[vtcKey] || (el[vtcKey] = /* @__PURE__ */ new Set())).add(cls);
}
function removeTransitionClass(el, cls) {
	cls.split(/\s+/).forEach((c) => c && el.classList.remove(c));
	const _vtc = el[vtcKey];
	if (_vtc) {
		_vtc.delete(cls);
		if (!_vtc.size) {
			el[vtcKey] = void 0;
		}
	}
}
function nextFrame(cb) {
	requestAnimationFrame(() => {
		requestAnimationFrame(cb);
	});
}
let endId = 0;
function whenTransitionEnds(el, expectedType, explicitTimeout, resolve) {
	const id = el._endId = ++endId;
	const resolveIfNotStale = () => {
		if (id === el._endId) {
			resolve();
		}
	};
	if (explicitTimeout != null) {
		return setTimeout(resolveIfNotStale, explicitTimeout);
	}
	const { type, timeout, propCount } = getTransitionInfo(el, expectedType);
	if (!type) {
		return resolve();
	}
	const endEvent = type + "end";
	let ended = 0;
	const end = () => {
		el.removeEventListener(endEvent, onEnd);
		resolveIfNotStale();
	};
	const onEnd = (e) => {
		if (e.target === el && ++ended >= propCount) {
			end();
		}
	};
	setTimeout(() => {
		if (ended < propCount) {
			end();
		}
	}, timeout + 1);
	el.addEventListener(endEvent, onEnd);
}
function getTransitionInfo(el, expectedType) {
	const styles = window.getComputedStyle(el);
	const getStyleProperties = (key) => (styles[key] || "").split(", ");
	const transitionDelays = getStyleProperties(`${TRANSITION}Delay`);
	const transitionDurations = getStyleProperties(`${TRANSITION}Duration`);
	const transitionTimeout = getTimeout(transitionDelays, transitionDurations);
	const animationDelays = getStyleProperties(`${ANIMATION}Delay`);
	const animationDurations = getStyleProperties(`${ANIMATION}Duration`);
	const animationTimeout = getTimeout(animationDelays, animationDurations);
	let type = null;
	let timeout = 0;
	let propCount = 0;
	if (expectedType === TRANSITION) {
		if (transitionTimeout > 0) {
			type = TRANSITION;
			timeout = transitionTimeout;
			propCount = transitionDurations.length;
		}
	} else if (expectedType === ANIMATION) {
		if (animationTimeout > 0) {
			type = ANIMATION;
			timeout = animationTimeout;
			propCount = animationDurations.length;
		}
	} else {
		timeout = Math.max(transitionTimeout, animationTimeout);
		type = timeout > 0 ? transitionTimeout > animationTimeout ? TRANSITION : ANIMATION : null;
		propCount = type ? type === TRANSITION ? transitionDurations.length : animationDurations.length : 0;
	}
	const hasTransform = type === TRANSITION && /\b(?:transform|all)(?:,|$)/.test(getStyleProperties(`${TRANSITION}Property`).toString());
	return {
		type,
		timeout,
		propCount,
		hasTransform
	};
}
function getTimeout(delays, durations) {
	while (delays.length < durations.length) {
		delays = delays.concat(delays);
	}
	return Math.max(...durations.map((d, i) => toMs(d) + toMs(delays[i])));
}
function toMs(s) {
	if (s === "auto") return 0;
	return Number(s.slice(0, -1).replace(",", ".")) * 1e3;
}
function forceReflow(el) {
	const targetDocument = el ? el.ownerDocument : document;
	return targetDocument.body.offsetHeight;
}
function patchClass(el, value, isSVG) {
	const transitionClasses = el[vtcKey];
	if (transitionClasses) {
		value = (value ? [value, ...transitionClasses] : [...transitionClasses]).join(" ");
	}
	if (value == null) {
		el.removeAttribute("class");
	} else if (isSVG) {
		el.setAttribute("class", value);
	} else {
		el.className = value;
	}
}
const vShowOriginalDisplay = /* @__PURE__ */ Symbol("_vod");
const vShowHidden = /* @__PURE__ */ Symbol("_vsh");
const vShow = {
	// used for prop mismatch check during hydration
	name: "show",
	beforeMount(el, { value }, { transition }) {
		el[vShowOriginalDisplay] = el.style.display === "none" ? "" : el.style.display;
		if (transition && value) {
			transition.beforeEnter(el);
		} else {
			setDisplay(el, value);
		}
	},
	mounted(el, { value }, { transition }) {
		if (transition && value) {
			transition.enter(el);
		}
	},
	updated(el, { value, oldValue }, { transition }) {
		if (!value === !oldValue) return;
		if (transition) {
			if (value) {
				transition.beforeEnter(el);
				setDisplay(el, true);
				transition.enter(el);
			} else {
				transition.leave(el, () => {
					setDisplay(el, false);
				});
			}
		} else {
			setDisplay(el, value);
		}
	},
	beforeUnmount(el, { value }) {
		setDisplay(el, value);
	}
};
function setDisplay(el, value) {
	el.style.display = value ? el[vShowOriginalDisplay] : "none";
	el[vShowHidden] = !value;
}
function initVShowForSSR() {
	vShow.getSSRProps = ({ value }) => {
		if (!value) {
			return { style: { display: "none" } };
		}
	};
}
const CSS_VAR_TEXT = /* @__PURE__ */ Symbol(!!("development" !== "production") ? "CSS_VAR_TEXT" : "");
function useCssVars(getter) {
	const instance = getCurrentInstance();
	if (!instance) {
		!!("development" !== "production") && warn(`useCssVars is called without current active component instance.`);
		return;
	}
	const updateTeleports = instance.ut = (vars = getter(instance.proxy)) => {
		Array.from(document.querySelectorAll(`[data-v-owner="${instance.uid}"]`)).forEach((node) => setVarsOnNode(node, vars));
	};
	if (!!("development" !== "production")) {
		instance.getCssVars = () => getter(instance.proxy);
	}
	const setVars = () => {
		const vars = getter(instance.proxy);
		if (instance.ce) {
			setVarsOnNode(instance.ce, vars);
		} else {
			setVarsOnVNode(instance.subTree, vars);
		}
		updateTeleports(vars);
	};
	onBeforeUpdate(() => {
		queuePostFlushCb(setVars);
	});
	onMounted(() => {
		watch(setVars, NOOP, { flush: "post" });
		const ob = new MutationObserver(setVars);
		ob.observe(instance.subTree.el.parentNode, { childList: true });
		onUnmounted(() => ob.disconnect());
	});
}
function setVarsOnVNode(vnode, vars) {
	if (vnode.shapeFlag & 128) {
		const suspense = vnode.suspense;
		vnode = suspense.activeBranch;
		if (suspense.pendingBranch && !suspense.isHydrating) {
			suspense.effects.push(() => {
				setVarsOnVNode(suspense.activeBranch, vars);
			});
		}
	}
	while (vnode.component) {
		vnode = vnode.component.subTree;
	}
	if (vnode.shapeFlag & 1 && vnode.el) {
		setVarsOnNode(vnode.el, vars);
	} else if (vnode.type === Fragment) {
		vnode.children.forEach((c) => setVarsOnVNode(c, vars));
	} else if (vnode.type === Static) {
		let { el, anchor } = vnode;
		while (el) {
			setVarsOnNode(el, vars);
			if (el === anchor) break;
			el = el.nextSibling;
		}
	}
}
function setVarsOnNode(el, vars) {
	if (el.nodeType === 1) {
		const style = el.style;
		let cssText = "";
		for (const key in vars) {
			const value = normalizeCssVarValue(vars[key]);
			style.setProperty(`--${key}`, value);
			cssText += `--${key}: ${value};`;
		}
		style[CSS_VAR_TEXT] = cssText;
	}
}
const displayRE = /(?:^|;)\s*display\s*:/;
function patchStyle(el, prev, next) {
	const style = el.style;
	const isCssString = isString(next);
	let hasControlledDisplay = false;
	if (next && !isCssString) {
		if (prev) {
			if (!isString(prev)) {
				for (const key in prev) {
					if (next[key] == null) {
						setStyle(style, key, "");
					}
				}
			} else {
				for (const prevStyle of prev.split(";")) {
					const key = prevStyle.slice(0, prevStyle.indexOf(":")).trim();
					if (next[key] == null) {
						setStyle(style, key, "");
					}
				}
			}
		}
		for (const key in next) {
			if (key === "display") {
				hasControlledDisplay = true;
			}
			const value = next[key];
			if (value != null) {
				if (!shouldPreserveTextareaResizeStyle(el, key, !isString(prev) && prev ? prev[key] : void 0, value)) {
					setStyle(style, key, value);
				}
			} else {
				setStyle(style, key, "");
			}
		}
	} else {
		if (isCssString) {
			if (prev !== next) {
				const cssVarText = style[CSS_VAR_TEXT];
				if (cssVarText) {
					next += ";" + cssVarText;
				}
				style.cssText = next;
				hasControlledDisplay = displayRE.test(next);
			}
		} else if (prev) {
			el.removeAttribute("style");
		}
	}
	if (vShowOriginalDisplay in el) {
		el[vShowOriginalDisplay] = hasControlledDisplay ? style.display : "";
		if (el[vShowHidden]) {
			style.display = "none";
		}
	}
}
const semicolonRE = /[^\\];\s*$/;
const importantRE = /\s*!important$/;
function setStyle(style, name, val) {
	if (isArray(val)) {
		val.forEach((v) => setStyle(style, name, v));
	} else {
		if (val == null) val = "";
		if (!!("development" !== "production")) {
			if (semicolonRE.test(val)) {
				warn(`Unexpected semicolon at the end of '${name}' style value: '${val}'`);
			}
		}
		if (name.startsWith("--")) {
			style.setProperty(name, val);
		} else {
			const prefixed = autoPrefix(style, name);
			if (importantRE.test(val)) {
				style.setProperty(hyphenate(prefixed), val.replace(importantRE, ""), "important");
			} else {
				style[prefixed] = val;
			}
		}
	}
}
const prefixes = [
	"Webkit",
	"Moz",
	"ms"
];
const prefixCache = {};
function autoPrefix(style, rawName) {
	const cached = prefixCache[rawName];
	if (cached) {
		return cached;
	}
	let name = camelize(rawName);
	if (name !== "filter" && name in style) {
		return prefixCache[rawName] = name;
	}
	name = capitalize(name);
	for (let i = 0; i < prefixes.length; i++) {
		const prefixed = prefixes[i] + name;
		if (prefixed in style) {
			return prefixCache[rawName] = prefixed;
		}
	}
	return rawName;
}
function shouldPreserveTextareaResizeStyle(el, key, prev, next) {
	return el.tagName === "TEXTAREA" && (key === "width" || key === "height") && isString(next) && prev === next;
}
const xlinkNS = "http://www.w3.org/1999/xlink";
function patchAttr(el, key, value, isSVG, instance, isBoolean = isSpecialBooleanAttr(key)) {
	if (isSVG && key.startsWith("xlink:")) {
		if (value == null) {
			el.removeAttributeNS(xlinkNS, key.slice(6, key.length));
		} else {
			el.setAttributeNS(xlinkNS, key, value);
		}
	} else {
		if (value == null || isBoolean && !includeBooleanAttr(value)) {
			el.removeAttribute(key);
		} else {
			el.setAttribute(key, isBoolean ? "" : isSymbol(value) ? String(value) : value);
		}
	}
}
function patchDOMProp(el, key, value, parentComponent, attrName) {
	if (key === "innerHTML" || key === "textContent") {
		if (value != null) {
			el[key] = key === "innerHTML" ? unsafeToTrustedHTML(value) : value;
		}
		return;
	}
	const tag = el.tagName;
	if (key === "value" && tag !== "PROGRESS" && !tag.includes("-")) {
		const oldValue = tag === "OPTION" ? el.getAttribute("value") || "" : el.value;
		const newValue = value == null ? el.type === "checkbox" ? "on" : "" : String(value);
		if (oldValue !== newValue || !("_value" in el)) {
			el.value = newValue;
		}
		if (value == null) {
			el.removeAttribute(key);
		}
		el._value = value;
		return;
	}
	let needRemove = false;
	if (value === "" || value == null) {
		const type = typeof el[key];
		if (type === "boolean") {
			value = includeBooleanAttr(value);
		} else if (value == null && type === "string") {
			value = "";
			needRemove = true;
		} else if (type === "number") {
			value = 0;
			needRemove = true;
		}
	}
	try {
		el[key] = value;
	} catch (e) {
		if (!!("development" !== "production") && !needRemove) {
			warn(`Failed setting prop "${key}" on <${tag.toLowerCase()}>: value ${value} is invalid.`, e);
		}
	}
	needRemove && el.removeAttribute(attrName || key);
}
function addEventListener(el, event, handler, options) {
	el.addEventListener(event, handler, options);
}
function removeEventListener(el, event, handler, options) {
	el.removeEventListener(event, handler, options);
}
const veiKey = /* @__PURE__ */ Symbol("_vei");
function patchEvent(el, rawName, prevValue, nextValue, instance = null) {
	const invokers = el[veiKey] || (el[veiKey] = {});
	const existingInvoker = invokers[rawName];
	if (nextValue && existingInvoker) {
		existingInvoker.value = !!("development" !== "production") ? sanitizeEventValue(nextValue, rawName) : nextValue;
	} else {
		const [name, options] = parseName(rawName);
		if (nextValue) {
			const invoker = invokers[rawName] = createInvoker(!!("development" !== "production") ? sanitizeEventValue(nextValue, rawName) : nextValue, instance);
			addEventListener(el, name, invoker, options);
		} else if (existingInvoker) {
			removeEventListener(el, name, existingInvoker, options);
			invokers[rawName] = void 0;
		}
	}
}
const optionsModifierRE = /(Once|Passive|Capture)$/;
const optionsModifierEventRE = /^on:?(?:Once|Passive|Capture)$/;
function parseName(name) {
	let options;
	let m;
	while ((m = name.match(optionsModifierRE)) && !optionsModifierEventRE.test(name)) {
		if (!options) options = {};
		name = name.slice(0, name.length - m[1].length);
		options[m[1].toLowerCase()] = true;
	}
	const event = name[2] === ":" ? name.slice(3) : hyphenate(name.slice(2));
	return [event, options];
}
let cachedNow = 0;
const p = /* @__PURE__ */ Promise.resolve();
const getNow = () => cachedNow || (p.then(() => cachedNow = 0), cachedNow = Date.now());
function createInvoker(initialValue, instance) {
	const invoker = (e) => {
		if (!e._vts) {
			e._vts = Date.now();
		} else if (e._vts <= invoker.attached) {
			return;
		}
		const value = invoker.value;
		if (isArray(value)) {
			const originalStop = e.stopImmediatePropagation;
			e.stopImmediatePropagation = () => {
				originalStop.call(e);
				e._stopped = true;
			};
			const handlers = value.slice();
			const args = [e];
			for (let i = 0; i < handlers.length; i++) {
				if (e._stopped) {
					break;
				}
				const handler = handlers[i];
				if (handler) {
					callWithAsyncErrorHandling(handler, instance, 5, args);
				}
			}
		} else {
			callWithAsyncErrorHandling(value, instance, 5, [e]);
		}
	};
	invoker.value = initialValue;
	invoker.attached = getNow();
	return invoker;
}
function sanitizeEventValue(value, propName) {
	if (isFunction(value) || isArray(value)) {
		return value;
	}
	warn(`Wrong type passed as event handler to ${propName} - did you forget @ or : in front of your prop?
Expected function or array of functions, received type ${typeof value}.`);
	return NOOP;
}
const isNativeOn = (key) => key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && key.charCodeAt(2) > 96 && key.charCodeAt(2) < 123;
const patchProp = (el, key, prevValue, nextValue, namespace, parentComponent) => {
	const isSVG = namespace === "svg";
	if (key === "class") {
		patchClass(el, nextValue, isSVG);
	} else if (key === "style") {
		patchStyle(el, prevValue, nextValue);
	} else if (isOn(key)) {
		if (!isModelListener(key)) {
			patchEvent(el, key, prevValue, nextValue, parentComponent);
		}
	} else if (key[0] === "." ? (key = key.slice(1), true) : key[0] === "^" ? (key = key.slice(1), false) : shouldSetAsProp(el, key, nextValue, isSVG)) {
		patchDOMProp(el, key, nextValue);
		if (!el.tagName.includes("-") && (key === "value" || key === "checked" || key === "selected")) {
			patchAttr(el, key, nextValue, isSVG, parentComponent, key !== "value");
		}
	} else if (el._isVueCE && (shouldSetAsPropForVueCE(el, key) || el._def.__asyncLoader && (/[A-Z]/.test(key) || !isString(nextValue)))) {
		patchDOMProp(el, camelize$1(key), nextValue, parentComponent, key);
	} else {
		if (key === "true-value") {
			el._trueValue = nextValue;
		} else if (key === "false-value") {
			el._falseValue = nextValue;
		}
		patchAttr(el, key, nextValue, isSVG);
	}
};
function shouldSetAsProp(el, key, value, isSVG) {
	if (isSVG) {
		if (key === "innerHTML" || key === "textContent") {
			return true;
		}
		if (key in el && isNativeOn(key) && isFunction(value)) {
			return true;
		}
		return false;
	}
	if (key === "spellcheck" || key === "draggable" || key === "translate" || key === "autocorrect") {
		return false;
	}
	if (key === "sandbox" && el.tagName === "IFRAME") {
		return false;
	}
	if (key === "form") {
		return false;
	}
	if (key === "list" && el.tagName === "INPUT") {
		return false;
	}
	if (key === "type" && el.tagName === "TEXTAREA") {
		return false;
	}
	if (key === "width" || key === "height") {
		const tag = el.tagName;
		if (tag === "IMG" || tag === "VIDEO" || tag === "CANVAS" || tag === "SOURCE") {
			return false;
		}
	}
	if (isNativeOn(key) && isString(value)) {
		return false;
	}
	return key in el;
}
function shouldSetAsPropForVueCE(el, key) {
	const props = el._def.props;
	if (!props) {
		return false;
	}
	const camelKey = camelize$1(key);
	return Array.isArray(props) ? props.some((prop) => camelize$1(prop) === camelKey) : Object.keys(props).some((prop) => camelize$1(prop) === camelKey);
}
const REMOVAL = {};
// @__NO_SIDE_EFFECTS__
function defineCustomElement(options, extraOptions, _createApp) {
	let Comp = defineComponent(options, extraOptions);
	if (isPlainObject(Comp)) Comp = extend({}, Comp, extraOptions);
	class VueCustomElement extends VueElement {
		constructor(initialProps) {
			super(Comp, initialProps, _createApp);
		}
	}
	VueCustomElement.def = Comp;
	return VueCustomElement;
}
const defineSSRCustomElement = /* @__NO_SIDE_EFFECTS__ */ ((options, extraOptions) => {
	return /* @__PURE__ */ defineCustomElement(options, extraOptions, createSSRApp);
});
const BaseClass = typeof HTMLElement !== "undefined" ? HTMLElement : class {};
class VueElement extends BaseClass {
	constructor(_def, _props = {}, _createApp = createApp) {
		super();
		this._def = _def;
		this._props = _props;
		this._createApp = _createApp;
		this._isVueCE = true;
		/**
		* @internal
		*/
		this._instance = null;
		/**
		* @internal
		*/
		this._app = null;
		/**
		* @internal
		*/
		this._nonce = this._def.nonce;
		this._connected = false;
		this._resolved = false;
		this._patching = false;
		this._dirty = false;
		this._numberProps = null;
		this._styleChildren = /* @__PURE__ */ new WeakSet();
		this._styleAnchors = /* @__PURE__ */ new WeakMap();
		this._ob = null;
		if (this.shadowRoot && _createApp !== createApp) {
			this._root = this.shadowRoot;
		} else {
			if (!!("development" !== "production") && this.shadowRoot) {
				warn(`Custom element has pre-rendered declarative shadow root but is not defined as hydratable. Use \`defineSSRCustomElement\`.`);
			}
			if (_def.shadowRoot !== false) {
				this.attachShadow(extend({}, _def.shadowRootOptions, { mode: "open" }));
				this._root = this.shadowRoot;
			} else {
				this._root = this;
			}
		}
	}
	connectedCallback() {
		if (!this.isConnected) return;
		if (!this.shadowRoot && !this._resolved) {
			this._parseSlots();
		}
		this._connected = true;
		let parent = this;
		while (parent = parent && (parent.assignedSlot || parent.parentNode || parent.host)) {
			if (parent instanceof VueElement) {
				this._parent = parent;
				break;
			}
		}
		if (!this._instance) {
			if (this._resolved) {
				this._mount(this._def);
			} else {
				if (parent && parent._pendingResolve) {
					this._pendingResolve = parent._pendingResolve.then(() => {
						this._pendingResolve = void 0;
						this._resolveDef();
					});
				} else {
					this._resolveDef();
				}
			}
		}
	}
	_setParent(parent = this._parent) {
		if (parent) {
			this._instance.parent = parent._instance;
			this._inheritParentContext(parent);
		}
	}
	_inheritParentContext(parent = this._parent) {
		if (parent && this._app) {
			Object.setPrototypeOf(this._app._context.provides, parent._instance.provides);
		}
	}
	disconnectedCallback() {
		this._connected = false;
		nextTick(() => {
			if (!this._connected) {
				if (this._ob) {
					this._ob.disconnect();
					this._ob = null;
				}
				this._app && this._app.unmount();
				if (this._instance) this._instance.ce = void 0;
				this._app = this._instance = null;
				if (this._teleportTargets) {
					this._teleportTargets.clear();
					this._teleportTargets = void 0;
				}
			}
		});
	}
	_processMutations(mutations) {
		for (const m of mutations) {
			this._setAttr(m.attributeName);
		}
	}
	/**
	* resolve inner component definition (handle possible async component)
	*/
	_resolveDef() {
		if (this._pendingResolve) {
			return;
		}
		for (let i = 0; i < this.attributes.length; i++) {
			this._setAttr(this.attributes[i].name);
		}
		this._ob = new MutationObserver(this._processMutations.bind(this));
		this._ob.observe(this, { attributes: true });
		const resolve = (def, isAsync = false) => {
			this._resolved = true;
			this._pendingResolve = void 0;
			const { props, styles } = def;
			let numberProps;
			if (props && !isArray(props)) {
				for (const key in props) {
					const opt = props[key];
					if (opt === Number || opt && opt.type === Number) {
						if (key in this._props) {
							this._props[key] = toNumber(this._props[key]);
						}
						(numberProps || (numberProps = /* @__PURE__ */ Object.create(null)))[camelize$1(key)] = true;
					}
				}
			}
			this._numberProps = numberProps;
			this._resolveProps(def);
			if (this.shadowRoot) {
				this._applyStyles(styles);
			} else if (!!("development" !== "production") && styles) {
				warn("Custom element style injection is not supported when using shadowRoot: false");
			}
			this._mount(def);
		};
		const asyncDef = this._def.__asyncLoader;
		if (asyncDef) {
			this._pendingResolve = asyncDef().then((def) => {
				def.configureApp = this._def.configureApp;
				resolve(this._def = def, true);
			});
		} else {
			resolve(this._def);
		}
	}
	_mount(def) {
		if ((!!("development" !== "production") || __VUE_PROD_DEVTOOLS__) && !def.name) {
			def.name = "VueElement";
		}
		this._app = this._createApp(def);
		this._inheritParentContext();
		if (def.configureApp) {
			def.configureApp(this._app);
		}
		this._app._ceVNode = this._createVNode();
		this._app.mount(this._root);
		const exposed = this._instance && this._instance.exposed;
		if (!exposed) return;
		for (const key in exposed) {
			if (!hasOwn(this, key)) {
				Object.defineProperty(this, key, { 
				// unwrap ref to be consistent with public instance behavior
get: () => unref(exposed[key]) });
			} else if (!!("development" !== "production")) {
				warn(`Exposed property "${key}" already exists on custom element.`);
			}
		}
	}
	_resolveProps(def) {
		const { props } = def;
		const declaredPropKeys = isArray(props) ? props : Object.keys(props || {});
		for (const key of Object.keys(this)) {
			if (key[0] !== "_" && declaredPropKeys.includes(key)) {
				this._setProp(key, this[key]);
			}
		}
		for (const key of declaredPropKeys.map(camelize$1)) {
			Object.defineProperty(this, key, {
				get() {
					return this._getProp(key);
				},
				set(val) {
					this._setProp(key, val, true, !this._patching);
				}
			});
		}
	}
	_setAttr(key) {
		if (key.startsWith("data-v-")) return;
		const has = this.hasAttribute(key);
		let value = has ? this.getAttribute(key) : REMOVAL;
		const camelKey = camelize$1(key);
		if (has && this._numberProps && this._numberProps[camelKey]) {
			value = toNumber(value);
		}
		this._setProp(camelKey, value, false, true);
	}
	/**
	* @internal
	*/
	_getProp(key) {
		return this._props[key];
	}
	/**
	* @internal
	*/
	_setProp(key, val, shouldReflect = true, shouldUpdate = false) {
		if (val !== this._props[key]) {
			this._dirty = true;
			if (val === REMOVAL) {
				delete this._props[key];
			} else {
				this._props[key] = val;
				if (key === "key" && this._app) {
					this._app._ceVNode.key = val;
				}
			}
			if (shouldUpdate && this._instance) {
				this._update();
			}
			if (shouldReflect) {
				const ob = this._ob;
				if (ob) {
					this._processMutations(ob.takeRecords());
					ob.disconnect();
				}
				if (val === true) {
					this.setAttribute(hyphenate(key), "");
				} else if (typeof val === "string" || typeof val === "number") {
					this.setAttribute(hyphenate(key), val + "");
				} else if (!val) {
					this.removeAttribute(hyphenate(key));
				}
				ob && ob.observe(this, { attributes: true });
			}
		}
	}
	_update() {
		const vnode = this._createVNode();
		if (this._app) vnode.appContext = this._app._context;
		render(vnode, this._root);
	}
	_createVNode() {
		const baseProps = {};
		if (!this.shadowRoot) {
			baseProps.onVnodeMounted = baseProps.onVnodeUpdated = this._renderSlots.bind(this);
		}
		const vnode = createVNode(this._def, extend(baseProps, this._props));
		if (!this._instance) {
			vnode.ce = (instance) => {
				this._instance = instance;
				instance.ce = this;
				instance.isCE = true;
				if (!!("development" !== "production")) {
					instance.ceReload = (newStyles) => {
						if (this._styles) {
							this._styles.forEach((s) => this._root.removeChild(s));
							this._styles.length = 0;
						}
						this._styleAnchors.delete(this._def);
						this._applyStyles(newStyles);
						this._instance = null;
						this._update();
					};
				}
				const dispatch = (event, args) => {
					this.dispatchEvent(new CustomEvent(event, isPlainObject(args[0]) ? extend({ detail: args }, args[0]) : { detail: args }));
				};
				instance.emit = (event, ...args) => {
					dispatch(event, args);
					if (hyphenate(event) !== event) {
						dispatch(hyphenate(event), args);
					}
				};
				this._setParent();
			};
		}
		return vnode;
	}
	_applyStyles(styles, owner, parentComp) {
		if (!styles) return;
		if (owner) {
			if (owner === this._def || this._styleChildren.has(owner)) {
				return;
			}
			this._styleChildren.add(owner);
		}
		const nonce = this._nonce;
		const root = this.shadowRoot;
		const insertionAnchor = parentComp ? this._getStyleAnchor(parentComp) || this._getStyleAnchor(this._def) : this._getRootStyleInsertionAnchor(root);
		let last = null;
		for (let i = styles.length - 1; i >= 0; i--) {
			const s = document.createElement("style");
			if (nonce) s.setAttribute("nonce", nonce);
			s.textContent = styles[i];
			root.insertBefore(s, last || insertionAnchor);
			last = s;
			if (i === 0) {
				if (!parentComp) this._styleAnchors.set(this._def, s);
				if (owner) this._styleAnchors.set(owner, s);
			}
			if (!!("development" !== "production")) {
				if (owner) {
					if (owner.__hmrId) {
						if (!this._childStyles) this._childStyles = /* @__PURE__ */ new Map();
						let entry = this._childStyles.get(owner.__hmrId);
						if (!entry) {
							this._childStyles.set(owner.__hmrId, entry = []);
						}
						entry.push(s);
					}
				} else {
					(this._styles || (this._styles = [])).push(s);
				}
			}
		}
	}
	_getStyleAnchor(comp) {
		if (!comp) {
			return null;
		}
		const anchor = this._styleAnchors.get(comp);
		if (anchor && anchor.parentNode === this.shadowRoot) {
			return anchor;
		}
		if (anchor) {
			this._styleAnchors.delete(comp);
		}
		return null;
	}
	_getRootStyleInsertionAnchor(root) {
		for (let i = 0; i < root.childNodes.length; i++) {
			const node = root.childNodes[i];
			if (!(node instanceof HTMLStyleElement)) {
				return node;
			}
		}
		return null;
	}
	/**
	* Only called when shadowRoot is false
	*/
	_parseSlots() {
		const slots = this._slots = {};
		let n;
		while (n = this.firstChild) {
			const slotName = n.nodeType === 1 && n.getAttribute("slot") || "default";
			(slots[slotName] || (slots[slotName] = [])).push(n);
			this.removeChild(n);
		}
	}
	/**
	* Only called when shadowRoot is false
	*/
	_renderSlots() {
		const outlets = this._getSlots();
		const scopeId = this._instance.type.__scopeId;
		for (let i = 0; i < outlets.length; i++) {
			const o = outlets[i];
			const slotName = o.getAttribute("name") || "default";
			const content = this._slots[slotName];
			const parent = o.parentNode;
			if (content) {
				for (const n of content) {
					if (scopeId && n.nodeType === 1) {
						const id = scopeId + "-s";
						const walker = document.createTreeWalker(n, 1);
						n.setAttribute(id, "");
						let child;
						while (child = walker.nextNode()) {
							child.setAttribute(id, "");
						}
					}
					parent.insertBefore(n, o);
				}
			} else {
				while (o.firstChild) parent.insertBefore(o.firstChild, o);
			}
			parent.removeChild(o);
		}
	}
	/**
	* @internal
	*/
	_getSlots() {
		const roots = [this];
		if (this._teleportTargets) {
			roots.push(...this._teleportTargets);
		}
		const slots = /* @__PURE__ */ new Set();
		for (const root of roots) {
			const found = root.querySelectorAll("slot");
			for (let i = 0; i < found.length; i++) {
				slots.add(found[i]);
			}
		}
		return Array.from(slots);
	}
	/**
	* @internal
	*/
	_injectChildStyle(comp, parentComp) {
		this._applyStyles(comp.styles, comp, parentComp);
	}
	/**
	* @internal
	*/
	_beginPatch() {
		this._patching = true;
		this._dirty = false;
	}
	/**
	* @internal
	*/
	_endPatch() {
		this._patching = false;
		if (this._dirty && this._instance) {
			this._update();
		}
	}
	/**
	* @internal
	*/
	_hasShadowRoot() {
		return this._def.shadowRoot !== false;
	}
	/**
	* @internal
	*/
	_removeChildStyle(comp) {
		if (!!("development" !== "production")) {
			this._styleChildren.delete(comp);
			this._styleAnchors.delete(comp);
			if (this._childStyles && comp.__hmrId) {
				const oldStyles = this._childStyles.get(comp.__hmrId);
				if (oldStyles) {
					oldStyles.forEach((s) => this._root.removeChild(s));
					oldStyles.length = 0;
				}
			}
		}
	}
}
function useHost(caller) {
	const instance = getCurrentInstance();
	const el = instance && instance.ce;
	if (el) {
		return el;
	} else if (!!("development" !== "production")) {
		if (!instance) {
			warn(`${caller || "useHost"} called without an active component instance.`);
		} else {
			warn(`${caller || "useHost"} can only be used in components defined via defineCustomElement.`);
		}
	}
	return null;
}
function useShadowRoot() {
	const el = !!("development" !== "production") ? useHost("useShadowRoot") : useHost();
	return el && el.shadowRoot;
}
function useCssModule(name = "$style") {
	{
		const instance = getCurrentInstance();
		if (!instance) {
			!!("development" !== "production") && warn(`useCssModule must be called inside setup()`);
			return EMPTY_OBJ;
		}
		const modules = instance.type.__cssModules;
		if (!modules) {
			!!("development" !== "production") && warn(`Current instance does not have CSS modules injected.`);
			return EMPTY_OBJ;
		}
		const mod = modules[name];
		if (!mod) {
			!!("development" !== "production") && warn(`Current instance does not have CSS module named "${name}".`);
			return EMPTY_OBJ;
		}
		return mod;
	}
}
const positionMap = /* @__PURE__ */ new WeakMap();
const newPositionMap = /* @__PURE__ */ new WeakMap();
const moveCbKey = /* @__PURE__ */ Symbol("_moveCb");
const enterCbKey = /* @__PURE__ */ Symbol("_enterCb");
const decorate = (t) => {
	delete t.props.mode;
	return t;
};
const TransitionGroupImpl = /* @__PURE__ */ decorate({
	name: "TransitionGroup",
	props: /* @__PURE__ */ extend({}, TransitionPropsValidators, {
		tag: String,
		moveClass: String
	}),
	setup(props, { slots }) {
		const instance = getCurrentInstance();
		const state = useTransitionState();
		let prevChildren;
		let children;
		onUpdated(() => {
			if (!prevChildren.length) {
				return;
			}
			const moveClass = props.moveClass || `${props.name || "v"}-move`;
			if (!hasCSSTransform(prevChildren[0].el, instance.vnode.el, moveClass)) {
				prevChildren = [];
				return;
			}
			prevChildren.forEach(callPendingCbs);
			prevChildren.forEach(recordPosition);
			const movedChildren = prevChildren.filter(applyTranslation);
			forceReflow(instance.vnode.el);
			movedChildren.forEach((c) => {
				const el = c.el;
				const style = el.style;
				addTransitionClass(el, moveClass);
				style.transform = style.webkitTransform = style.transitionDuration = "";
				const cb = el[moveCbKey] = (e) => {
					if (e && e.target !== el) {
						return;
					}
					if (!e || e.propertyName.endsWith("transform")) {
						el.removeEventListener("transitionend", cb);
						el[moveCbKey] = null;
						removeTransitionClass(el, moveClass);
					}
				};
				el.addEventListener("transitionend", cb);
			});
			prevChildren = [];
		});
		return () => {
			const rawProps = toRaw(props);
			const cssTransitionProps = resolveTransitionProps(rawProps);
			let tag = rawProps.tag || Fragment;
			prevChildren = [];
			if (children) {
				for (let i = 0; i < children.length; i++) {
					const child = children[i];
					if (child.el && child.el instanceof Element && !child.el[vShowHidden]) {
						prevChildren.push(child);
						setTransitionHooks(child, resolveTransitionHooks(child, cssTransitionProps, state, instance));
						positionMap.set(child, getPosition(child.el));
					}
				}
			}
			children = slots.default ? getTransitionRawChildren(slots.default()) : [];
			for (let i = 0; i < children.length; i++) {
				const child = children[i];
				if (child.key != null) {
					setTransitionHooks(child, resolveTransitionHooks(child, cssTransitionProps, state, instance));
				} else if (!!("development" !== "production") && child.type !== Text) {
					warn(`<TransitionGroup> children must be keyed.`);
				}
			}
			return createVNode(tag, null, children);
		};
	}
});
const TransitionGroup = TransitionGroupImpl;
function callPendingCbs(c) {
	const el = c.el;
	if (el[moveCbKey]) {
		el[moveCbKey]();
	}
	if (el[enterCbKey]) {
		el[enterCbKey]();
	}
}
function recordPosition(c) {
	newPositionMap.set(c, getPosition(c.el));
}
function applyTranslation(c) {
	const oldPos = positionMap.get(c);
	const newPos = newPositionMap.get(c);
	const dx = oldPos.left - newPos.left;
	const dy = oldPos.top - newPos.top;
	if (dx || dy) {
		const el = c.el;
		const s = el.style;
		const rect = el.getBoundingClientRect();
		let scaleX = 1;
		let scaleY = 1;
		if (el.offsetWidth) scaleX = rect.width / el.offsetWidth;
		if (el.offsetHeight) scaleY = rect.height / el.offsetHeight;
		if (!Number.isFinite(scaleX) || scaleX === 0) scaleX = 1;
		if (!Number.isFinite(scaleY) || scaleY === 0) scaleY = 1;
		if (Math.abs(scaleX - 1) < .01) scaleX = 1;
		if (Math.abs(scaleY - 1) < .01) scaleY = 1;
		s.transform = s.webkitTransform = `translate(${dx / scaleX}px,${dy / scaleY}px)`;
		s.transitionDuration = "0s";
		return c;
	}
}
function getPosition(el) {
	const rect = el.getBoundingClientRect();
	return {
		left: rect.left,
		top: rect.top
	};
}
function hasCSSTransform(el, root, moveClass) {
	const clone = el.cloneNode();
	const _vtc = el[vtcKey];
	if (_vtc) {
		_vtc.forEach((cls) => {
			cls.split(/\s+/).forEach((c) => c && clone.classList.remove(c));
		});
	}
	moveClass.split(/\s+/).forEach((c) => c && clone.classList.add(c));
	clone.style.display = "none";
	const container = root.nodeType === 1 ? root : root.parentNode;
	container.appendChild(clone);
	const { hasTransform } = getTransitionInfo(clone);
	container.removeChild(clone);
	return hasTransform;
}
const getModelAssigner = (vnode) => {
	const fn = vnode.props["onUpdate:modelValue"] || false;
	return isArray(fn) ? (value) => invokeArrayFns(fn, value) : fn;
};
function onCompositionStart(e) {
	e.target.composing = true;
}
function onCompositionEnd(e) {
	const target = e.target;
	if (target.composing) {
		target.composing = false;
		target.dispatchEvent(new Event("input"));
	}
}
const assignKey = /* @__PURE__ */ Symbol("_assign");
function castValue(value, trim, number) {
	if (trim) value = value.trim();
	if (number) value = looseToNumber(value);
	return value;
}
const vModelText = {
	created(el, { modifiers: { lazy, trim, number } }, vnode) {
		el[assignKey] = getModelAssigner(vnode);
		const castToNumber = number || vnode.props && vnode.props.type === "number";
		addEventListener(el, lazy ? "change" : "input", (e) => {
			if (e.target.composing) return;
			el[assignKey](castValue(el.value, trim, castToNumber));
		});
		if (trim || castToNumber) {
			addEventListener(el, "change", () => {
				el.value = castValue(el.value, trim, castToNumber);
			});
		}
		if (!lazy) {
			addEventListener(el, "compositionstart", onCompositionStart);
			addEventListener(el, "compositionend", onCompositionEnd);
			addEventListener(el, "change", onCompositionEnd);
		}
	},
	// set value on mounted so it's after min/max for type="range"
	mounted(el, { value }) {
		el.value = value == null ? "" : value;
	},
	beforeUpdate(el, { value, oldValue, modifiers: { lazy, trim, number } }, vnode) {
		el[assignKey] = getModelAssigner(vnode);
		if (el.composing) return;
		const elValue = (number || el.type === "number") && !/^0\d/.test(el.value) ? looseToNumber(el.value) : el.value;
		const newValue = value == null ? "" : value;
		if (elValue === newValue) {
			return;
		}
		const rootNode = el.getRootNode();
		if ((rootNode instanceof Document || rootNode instanceof ShadowRoot) && rootNode.activeElement === el && el.type !== "range") {
			if (lazy && value === oldValue) {
				return;
			}
			if (trim && el.value.trim() === newValue) {
				return;
			}
		}
		el.value = newValue;
	}
};
const vModelCheckbox = {
	// #4096 array checkboxes need to be deep traversed
	deep: true,
	created(el, _, vnode) {
		el[assignKey] = getModelAssigner(vnode);
		addEventListener(el, "change", () => {
			const modelValue = el._modelValue;
			const elementValue = getValue(el);
			const checked = el.checked;
			const assign = el[assignKey];
			if (isArray(modelValue)) {
				const index = looseIndexOf(modelValue, elementValue);
				const found = index !== -1;
				if (checked && !found) {
					assign(modelValue.concat(elementValue));
				} else if (!checked && found) {
					const filtered = [...modelValue];
					filtered.splice(index, 1);
					assign(filtered);
				}
			} else if (isSet(modelValue)) {
				const cloned = new Set(modelValue);
				if (checked) {
					cloned.add(elementValue);
				} else {
					cloned.delete(elementValue);
				}
				assign(cloned);
			} else {
				assign(getCheckboxValue(el, checked));
			}
		});
	},
	// set initial checked on mount to wait for true-value/false-value
	mounted: setChecked,
	beforeUpdate(el, binding, vnode) {
		el[assignKey] = getModelAssigner(vnode);
		setChecked(el, binding, vnode);
	}
};
function setChecked(el, { value, oldValue }, vnode) {
	el._modelValue = value;
	let checked;
	if (isArray(value)) {
		checked = looseIndexOf(value, vnode.props.value) > -1;
	} else if (isSet(value)) {
		checked = value.has(vnode.props.value);
	} else {
		if (value === oldValue) return;
		checked = looseEqual(value, getCheckboxValue(el, true));
	}
	if (el.checked !== checked) {
		el.checked = checked;
	}
}
const vModelRadio = {
	created(el, { value }, vnode) {
		el.checked = looseEqual(value, vnode.props.value);
		el[assignKey] = getModelAssigner(vnode);
		addEventListener(el, "change", () => {
			el[assignKey](getValue(el));
		});
	},
	beforeUpdate(el, { value, oldValue }, vnode) {
		el[assignKey] = getModelAssigner(vnode);
		if (value !== oldValue) {
			el.checked = looseEqual(value, vnode.props.value);
		}
	}
};
const vModelSelect = {
	// <select multiple> value need to be deep traversed
	deep: true,
	created(el, { value, modifiers: { number } }, vnode) {
		el._modelValue = value;
		addEventListener(el, "change", () => {
			const selectedVal = Array.prototype.filter.call(el.options, (o) => o.selected).map((o) => number ? looseToNumber(getValue(o)) : getValue(o));
			el[assignKey](el.multiple ? isSet(el._modelValue) ? new Set(selectedVal) : selectedVal : selectedVal[0]);
			el._assigning = true;
			nextTick(() => {
				el._assigning = false;
			});
		});
		el[assignKey] = getModelAssigner(vnode);
	},
	// set value in mounted & updated because <select> relies on its children
	// <option>s.
	mounted(el, { value }) {
		setSelected(el, value);
	},
	beforeUpdate(el, { value }, vnode) {
		el._modelValue = value;
		el[assignKey] = getModelAssigner(vnode);
	},
	updated(el, { value }) {
		if (!el._assigning) {
			setSelected(el, value);
		}
	}
};
function setSelected(el, value) {
	const isMultiple = el.multiple;
	const isArrayValue = isArray(value);
	if (isMultiple && !isArrayValue && !isSet(value)) {
		!!("development" !== "production") && warn(`<select multiple v-model> expects an Array or Set value for its binding, but got ${Object.prototype.toString.call(value).slice(8, -1)}.`);
		return;
	}
	for (let i = 0, l = el.options.length; i < l; i++) {
		const option = el.options[i];
		const optionValue = getValue(option);
		if (isMultiple) {
			if (isArrayValue) {
				const optionType = typeof optionValue;
				if (optionType === "string" || optionType === "number") {
					option.selected = value.some((v) => String(v) === String(optionValue));
				} else {
					option.selected = looseIndexOf(value, optionValue) > -1;
				}
			} else {
				option.selected = value.has(optionValue);
			}
		} else if (looseEqual(getValue(option), value)) {
			if (el.selectedIndex !== i) el.selectedIndex = i;
			return;
		}
	}
	if (!isMultiple && el.selectedIndex !== -1) {
		el.selectedIndex = -1;
	}
}
function getValue(el) {
	return "_value" in el ? el._value : el.value;
}
function getCheckboxValue(el, checked) {
	const key = checked ? "_trueValue" : "_falseValue";
	return key in el ? el[key] : checked;
}
const vModelDynamic = {
	created(el, binding, vnode) {
		callModelHook(el, binding, vnode, null, "created");
	},
	mounted(el, binding, vnode) {
		callModelHook(el, binding, vnode, null, "mounted");
	},
	beforeUpdate(el, binding, vnode, prevVNode) {
		callModelHook(el, binding, vnode, prevVNode, "beforeUpdate");
	},
	updated(el, binding, vnode, prevVNode) {
		callModelHook(el, binding, vnode, prevVNode, "updated");
	}
};
function resolveDynamicModel(tagName, type) {
	switch (tagName) {
		case "SELECT": return vModelSelect;
		case "TEXTAREA": return vModelText;
		default: switch (type) {
			case "checkbox": return vModelCheckbox;
			case "radio": return vModelRadio;
			default: return vModelText;
		}
	}
}
function callModelHook(el, binding, vnode, prevVNode, hook) {
	const modelToUse = resolveDynamicModel(el.tagName, vnode.props && vnode.props.type);
	const fn = modelToUse[hook];
	fn && fn(el, binding, vnode, prevVNode);
}
function initVModelForSSR() {
	vModelText.getSSRProps = ({ value }) => ({ value });
	vModelRadio.getSSRProps = ({ value }, vnode) => {
		if (vnode.props && looseEqual(vnode.props.value, value)) {
			return { checked: true };
		}
	};
	vModelCheckbox.getSSRProps = ({ value }, vnode) => {
		if (isArray(value)) {
			if (vnode.props && looseIndexOf(value, vnode.props.value) > -1) {
				return { checked: true };
			}
		} else if (isSet(value)) {
			if (vnode.props && value.has(vnode.props.value)) {
				return { checked: true };
			}
		} else if (value) {
			return { checked: true };
		}
	};
	vModelDynamic.getSSRProps = (binding, vnode) => {
		if (typeof vnode.type !== "string") {
			return;
		}
		const modelToUse = resolveDynamicModel(
			// resolveDynamicModel expects an uppercase tag name, but vnode.type is lowercase
			vnode.type.toUpperCase(),
			vnode.props && vnode.props.type
		);
		if (modelToUse.getSSRProps) {
			return modelToUse.getSSRProps(binding, vnode);
		}
	};
}
const systemModifiers = [
	"ctrl",
	"shift",
	"alt",
	"meta"
];
const modifierGuards = {
	stop: (e) => e.stopPropagation(),
	prevent: (e) => e.preventDefault(),
	self: (e) => e.target !== e.currentTarget,
	ctrl: (e) => !e.ctrlKey,
	shift: (e) => !e.shiftKey,
	alt: (e) => !e.altKey,
	meta: (e) => !e.metaKey,
	left: (e) => "button" in e && e.button !== 0,
	middle: (e) => "button" in e && e.button !== 1,
	right: (e) => "button" in e && e.button !== 2,
	exact: (e, modifiers) => systemModifiers.some((m) => e[`${m}Key`] && !modifiers.includes(m))
};
const withModifiers = (fn, modifiers) => {
	if (!fn) return fn;
	const cache = fn._withMods || (fn._withMods = {});
	const cacheKey = modifiers.join(".");
	return cache[cacheKey] || (cache[cacheKey] = ((event, ...args) => {
		for (let i = 0; i < modifiers.length; i++) {
			const guard = modifierGuards[modifiers[i]];
			if (guard && guard(event, modifiers)) return;
		}
		return fn(event, ...args);
	}));
};
const keyNames = {
	esc: "escape",
	space: " ",
	up: "arrow-up",
	left: "arrow-left",
	right: "arrow-right",
	down: "arrow-down",
	delete: "backspace"
};
const withKeys = (fn, modifiers) => {
	const cache = fn._withKeys || (fn._withKeys = {});
	const cacheKey = modifiers.join(".");
	return cache[cacheKey] || (cache[cacheKey] = ((event) => {
		if (!("key" in event)) {
			return;
		}
		const eventKey = hyphenate(event.key);
		if (modifiers.some((k) => k === eventKey || keyNames[k] === eventKey)) {
			return fn(event);
		}
	}));
};
const rendererOptions = /* @__PURE__ */ extend({ patchProp }, nodeOps);
let renderer;
let enabledHydration = false;
function ensureRenderer() {
	return renderer || (renderer = createRenderer(rendererOptions));
}
function ensureHydrationRenderer() {
	renderer = enabledHydration ? renderer : createHydrationRenderer(rendererOptions);
	enabledHydration = true;
	return renderer;
}
const render = ((...args) => {
	ensureRenderer().render(...args);
});
const hydrate = ((...args) => {
	ensureHydrationRenderer().hydrate(...args);
});
const createApp = ((...args) => {
	const app = ensureRenderer().createApp(...args);
	if (!!("development" !== "production")) {
		injectNativeTagCheck(app);
		injectCompilerOptionsCheck(app);
	}
	const { mount } = app;
	app.mount = (containerOrSelector) => {
		const container = normalizeContainer(containerOrSelector);
		if (!container) return;
		const component = app._component;
		if (!isFunction(component) && !component.render && !component.template) {
			component.template = container.innerHTML;
		}
		if (container.nodeType === 1) {
			container.textContent = "";
		}
		const proxy = mount(container, false, resolveRootNamespace(container));
		if (container instanceof Element) {
			container.removeAttribute("v-cloak");
			container.setAttribute("data-v-app", "");
		}
		return proxy;
	};
	return app;
});
const createSSRApp = ((...args) => {
	const app = ensureHydrationRenderer().createApp(...args);
	if (!!("development" !== "production")) {
		injectNativeTagCheck(app);
		injectCompilerOptionsCheck(app);
	}
	const { mount } = app;
	app.mount = (containerOrSelector) => {
		const container = normalizeContainer(containerOrSelector);
		if (container) {
			return mount(container, true, resolveRootNamespace(container));
		}
	};
	return app;
});
function resolveRootNamespace(container) {
	if (container instanceof SVGElement) {
		return "svg";
	}
	if (typeof MathMLElement === "function" && container instanceof MathMLElement) {
		return "mathml";
	}
}
function injectNativeTagCheck(app) {
	Object.defineProperty(app.config, "isNativeTag", {
		value: (tag) => isHTMLTag(tag) || isSVGTag(tag) || isMathMLTag(tag),
		writable: false
	});
}
function injectCompilerOptionsCheck(app) {
	if (isRuntimeOnly()) {
		const isCustomElement = app.config.isCustomElement;
		Object.defineProperty(app.config, "isCustomElement", {
			get() {
				return isCustomElement;
			},
			set() {
				warn(`The \`isCustomElement\` config option is deprecated. Use \`compilerOptions.isCustomElement\` instead.`);
			}
		});
		const compilerOptions = app.config.compilerOptions;
		const msg = `The \`compilerOptions\` config option is only respected when using a build of Vue.js that includes the runtime compiler (aka "full build"). Since you are using the runtime-only build, \`compilerOptions\` must be passed to \`@vue/compiler-dom\` in the build setup instead.
- For vue-loader: pass it via vue-loader's \`compilerOptions\` loader option.
- For vue-cli: see https://cli.vuejs.org/guide/webpack.html#modifying-options-of-a-loader
- For vite: pass it via @vitejs/plugin-vue options. See https://github.com/vitejs/vite-plugin-vue/tree/main/packages/plugin-vue#example-for-passing-options-to-vuecompiler-sfc`;
		Object.defineProperty(app.config, "compilerOptions", {
			get() {
				warn(msg);
				return compilerOptions;
			},
			set() {
				warn(msg);
			}
		});
	}
}
function normalizeContainer(container) {
	if (isString(container)) {
		const res = document.querySelector(container);
		if (!!("development" !== "production") && !res) {
			warn(`Failed to mount app: mount target selector "${container}" returned null.`);
		}
		return res;
	}
	if (!!("development" !== "production") && window.ShadowRoot && container instanceof window.ShadowRoot && container.mode === "closed") {
		warn(`mounting on a ShadowRoot with \`{mode: "closed"}\` may lead to unpredictable bugs`);
	}
	return container;
}
let ssrDirectiveInitialized = false;
const initDirectivesForSSR = () => {
	if (!ssrDirectiveInitialized) {
		ssrDirectiveInitialized = true;
		initVModelForSSR();
		initVShowForSSR();
	}
};
export { Transition, TransitionGroup, VueElement, createApp, createSSRApp, defineCustomElement, defineSSRCustomElement, hydrate, initDirectivesForSSR, nodeOps, patchProp, render, useCssModule, useCssVars, useHost, useShadowRoot, vModelCheckbox, vModelDynamic, vModelRadio, vModelSelect, vModelText, vShow, withKeys, withModifiers };

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFLQSxTQUFTLE1BQU0sK0JBQStCLEdBQUcsZ0JBQWdCLGNBQWMsb0JBQW9CLGdCQUFnQixrQkFBa0IsV0FBVyxPQUFPLGFBQWEsVUFBVSxRQUFRLFVBQVUsNEJBQTRCLFVBQVUsT0FBTyxhQUFhLGlCQUFpQixvQkFBb0IsV0FBVyxPQUFPLDBCQUEwQixvQkFBb0Isd0JBQXdCLE1BQU0sZ0JBQWdCLGVBQWUsK0JBQStCO0FBQzNiLGNBQWM7QUFDZCxTQUFTLFFBQVEsVUFBVSxVQUFVLFNBQVMsTUFBTSxzQkFBc0IsVUFBVSxXQUFXLFlBQVksb0JBQW9CLFVBQVUsc0JBQXNCLFlBQVksTUFBTSxpQkFBaUIsWUFBWSxZQUFZLFFBQVEsZUFBZSxXQUFXLGNBQWMsT0FBTyxZQUFZLGVBQWUsZ0JBQWdCLFdBQVcsVUFBVSxtQkFBbUI7QUFFcFcsSUFBSSxTQUFTLEtBQUs7QUFDbEIsTUFBTSxLQUFLLE9BQU8sV0FBVyxlQUFlLE9BQU87QUFDbkQsSUFBSSxJQUFJO0NBQ04sSUFBSTtFQUNGLFNBQXlCLG1CQUFHLGFBQWEsT0FBTyxFQUM5QyxhQUFhLFFBQVEsSUFDdkIsQ0FBQztDQUNILFNBQVMsR0FBRztFQUNWLENBQUMsb0JBQTJCLGlCQUFpQixLQUFLLHdDQUF3QyxHQUFHO0NBQy9GO0FBQ0Y7QUFDQSxNQUFNLHNCQUFzQixVQUFVLFFBQVEsT0FBTyxXQUFXLEdBQUcsS0FBSyxRQUFRO0FBQ2hGLE1BQU0sUUFBUTtBQUNkLE1BQU0sV0FBVztBQUNqQixNQUFNLE1BQU0sT0FBTyxhQUFhLGNBQWMsV0FBVztBQUN6RCxNQUFNLG9CQUFvQixPQUF1QixvQkFBSSxjQUFjLFVBQVU7QUFDN0UsTUFBTSxVQUFVO0NBQ2QsU0FBUyxPQUFPLFFBQVEsV0FBVztFQUNqQyxPQUFPLGFBQWEsT0FBTyxVQUFVLElBQUk7Q0FDM0M7Q0FDQSxTQUFTLFVBQVU7RUFDakIsTUFBTSxTQUFTLE1BQU07RUFDckIsSUFBSSxRQUFRO0dBQ1YsT0FBTyxZQUFZLEtBQUs7RUFDMUI7Q0FDRjtDQUNBLGdCQUFnQixLQUFLLFdBQVcsSUFBSSxVQUFVO0VBQzVDLE1BQU0sS0FBSyxjQUFjLFFBQVEsSUFBSSxnQkFBZ0IsT0FBTyxHQUFHLElBQUksY0FBYyxXQUFXLElBQUksZ0JBQWdCLFVBQVUsR0FBRyxJQUFJLEtBQUssSUFBSSxjQUFjLEtBQUssRUFBRSxHQUFHLENBQUMsSUFBSSxJQUFJLGNBQWMsR0FBRztFQUM1TCxJQUFJLFFBQVEsWUFBWSxTQUFTLE1BQU0sWUFBWSxNQUFNO0dBQ3ZELEdBQUcsYUFBYSxZQUFZLE1BQU0sUUFBUTtFQUM1QztFQUNBLE9BQU87Q0FDVDtDQUNBLGFBQWEsU0FBUyxJQUFJLGVBQWUsSUFBSTtDQUM3QyxnQkFBZ0IsU0FBUyxJQUFJLGNBQWMsSUFBSTtDQUMvQyxVQUFVLE1BQU0sU0FBUztFQUN2QixLQUFLLFlBQVk7Q0FDbkI7Q0FDQSxpQkFBaUIsSUFBSSxTQUFTO0VBQzVCLEdBQUcsY0FBYztDQUNuQjtDQUNBLGFBQWEsU0FBUyxLQUFLO0NBQzNCLGNBQWMsU0FBUyxLQUFLO0NBQzVCLGdCQUFnQixhQUFhLElBQUksY0FBYyxRQUFRO0NBQ3ZELFdBQVcsSUFBSSxJQUFJO0VBQ2pCLEdBQUcsYUFBYSxJQUFJLEVBQUU7Q0FDeEI7Ozs7O0NBS0Esb0JBQW9CLFNBQVMsUUFBUSxRQUFRLFdBQVcsT0FBTyxLQUFLO0VBQ2xFLE1BQU0sU0FBUyxTQUFTLE9BQU8sa0JBQWtCLE9BQU87RUFDeEQsSUFBSSxVQUFVLFVBQVUsT0FBTyxNQUFNLGNBQWM7R0FDakQsT0FBTyxNQUFNO0lBQ1gsT0FBTyxhQUFhLE1BQU0sVUFBVSxJQUFJLEdBQUcsTUFBTTtJQUNqRCxJQUFJLFVBQVUsT0FBTyxFQUFFLFFBQVEsTUFBTSxjQUFjO0dBQ3JEO0VBQ0YsT0FBTztHQUNMLGtCQUFrQixZQUFZLG9CQUM1QixjQUFjLFFBQVEsUUFBUSxRQUFRLFVBQVUsY0FBYyxXQUFXLFNBQVMsUUFBUSxXQUFXLE9BQ3ZHO0dBQ0EsTUFBTSxXQUFXLGtCQUFrQjtHQUNuQyxJQUFJLGNBQWMsU0FBUyxjQUFjLFVBQVU7SUFDakQsTUFBTSxVQUFVLFNBQVM7SUFDekIsT0FBTyxRQUFRLFlBQVk7S0FDekIsU0FBUyxZQUFZLFFBQVEsVUFBVTtJQUN6QztJQUNBLFNBQVMsWUFBWSxPQUFPO0dBQzlCO0dBQ0EsT0FBTyxhQUFhLFVBQVUsTUFBTTtFQUN0QztFQUNBLE9BQU8sQ0FFTCxTQUFTLE9BQU8sY0FBYyxPQUFPLFlBRXJDLFNBQVMsT0FBTyxrQkFBa0IsT0FBTyxTQUMzQztDQUNGO0FBQ0Y7QUFFQSxNQUFNLGFBQWE7QUFDbkIsTUFBTSxZQUFZO0FBQ2xCLE1BQU0sU0FBeUIsdUJBQU8sTUFBTTtBQUM1QyxNQUFNLCtCQUErQjtDQUNuQyxNQUFNO0NBQ04sTUFBTTtDQUNOLEtBQUs7RUFDSCxNQUFNO0VBQ04sU0FBUztDQUNYO0NBQ0EsVUFBVTtFQUFDO0VBQVE7RUFBUTtDQUFNO0NBQ2pDLGdCQUFnQjtDQUNoQixrQkFBa0I7Q0FDbEIsY0FBYztDQUNkLGlCQUFpQjtDQUNqQixtQkFBbUI7Q0FDbkIsZUFBZTtDQUNmLGdCQUFnQjtDQUNoQixrQkFBa0I7Q0FDbEIsY0FBYztBQUNoQjtBQUNBLE1BQU0sNEJBQTRDLHVCQUNoRCxDQUFDLEdBQ0QsK0JBQ0EsNEJBQ0Y7QUFDQSxNQUFNLGNBQWMsTUFBTTtDQUN4QixFQUFFLGNBQWM7Q0FDaEIsRUFBRSxRQUFRO0NBQ1YsT0FBTztBQUNUO0FBQ0EsTUFBTSxhQUE2Qiw0QkFDaEMsT0FBTyxFQUFFLFlBQVksRUFBRSxnQkFBZ0IsdUJBQXVCLEtBQUssR0FBRyxLQUFLLENBQzlFO0FBQ0EsTUFBTSxZQUFZLE1BQU0sT0FBTyxDQUFDLE1BQU07Q0FDcEMsSUFBSSxRQUFRLElBQUksR0FBRztFQUNqQixLQUFLLFNBQVMsT0FBTyxHQUFHLEdBQUcsSUFBSSxDQUFDO0NBQ2xDLE9BQU8sSUFBSSxNQUFNO0VBQ2YsS0FBSyxHQUFHLElBQUk7Q0FDZDtBQUNGO0FBQ0EsTUFBTSx1QkFBdUIsU0FBUztDQUNwQyxPQUFPLE9BQU8sUUFBUSxJQUFJLElBQUksS0FBSyxNQUFNLE9BQU8sR0FBRyxTQUFTLENBQUMsSUFBSSxLQUFLLFNBQVMsSUFBSTtBQUNyRjtBQUNBLFNBQVMsdUJBQXVCLFVBQVU7Q0FDeEMsTUFBTSxZQUFZLENBQUM7Q0FDbkIsS0FBSyxNQUFNLE9BQU8sVUFBVTtFQUMxQixJQUFJLEVBQUUsT0FBTywrQkFBK0I7R0FDMUMsVUFBVSxPQUFPLFNBQVM7RUFDNUI7Q0FDRjtDQUNBLElBQUksU0FBUyxRQUFRLE9BQU87RUFDMUIsT0FBTztDQUNUO0NBQ0EsTUFBTSxFQUNKLE9BQU8sS0FDUCxNQUNBLFVBQ0EsaUJBQWlCLEdBQUcsS0FBSyxjQUN6QixtQkFBbUIsR0FBRyxLQUFLLGdCQUMzQixlQUFlLEdBQUcsS0FBSyxZQUN2QixrQkFBa0IsZ0JBQ2xCLG9CQUFvQixrQkFDcEIsZ0JBQWdCLGNBQ2hCLGlCQUFpQixHQUFHLEtBQUssY0FDekIsbUJBQW1CLEdBQUcsS0FBSyxnQkFDM0IsZUFBZSxHQUFHLEtBQUssZUFDckI7Q0FDSixNQUFNLFlBQVksa0JBQWtCLFFBQVE7Q0FDNUMsTUFBTSxnQkFBZ0IsYUFBYSxVQUFVO0NBQzdDLE1BQU0sZ0JBQWdCLGFBQWEsVUFBVTtDQUM3QyxNQUFNLEVBQ0osZUFDQSxTQUNBLGtCQUNBLFNBQ0Esa0JBQ0EsaUJBQWlCLGVBQ2pCLFdBQVcsU0FDWCxvQkFBb0IscUJBQ2xCO0NBQ0osTUFBTSxlQUFlLElBQUksVUFBVSxNQUFNLGdCQUFnQjtFQUN2RCxHQUFHLGtCQUFrQjtFQUNyQixzQkFBc0IsSUFBSSxXQUFXLGdCQUFnQixZQUFZO0VBQ2pFLHNCQUFzQixJQUFJLFdBQVcsb0JBQW9CLGdCQUFnQjtFQUN6RSxRQUFRLEtBQUs7Q0FDZjtDQUNBLE1BQU0sZUFBZSxJQUFJLFNBQVM7RUFDaEMsR0FBRyxhQUFhO0VBQ2hCLHNCQUFzQixJQUFJLGNBQWM7RUFDeEMsc0JBQXNCLElBQUksWUFBWTtFQUN0QyxzQkFBc0IsSUFBSSxnQkFBZ0I7RUFDMUMsUUFBUSxLQUFLO0NBQ2Y7Q0FDQSxNQUFNLGlCQUFpQixhQUFhO0VBQ2xDLFFBQVEsSUFBSSxTQUFTO0dBQ25CLE1BQU0sT0FBTyxXQUFXLFdBQVc7R0FDbkMsTUFBTSxnQkFBZ0IsWUFBWSxJQUFJLFVBQVUsSUFBSTtHQUNwRCxTQUFTLE1BQU0sQ0FBQyxJQUFJLE9BQU8sQ0FBQztHQUM1QixnQkFBZ0I7SUFDZCxzQkFBc0IsSUFBSSxXQUFXLGtCQUFrQixjQUFjO0lBQ3JFLG1CQUFtQixJQUFJLFdBQVcsZ0JBQWdCLFlBQVk7SUFDOUQsSUFBSSxDQUFDLG9CQUFvQixJQUFJLEdBQUc7S0FDOUIsbUJBQW1CLElBQUksTUFBTSxlQUFlLE9BQU87SUFDckQ7R0FDRixDQUFDO0VBQ0g7Q0FDRjtDQUNBLE9BQU8sT0FBTyxXQUFXO0VBQ3ZCLGNBQWMsSUFBSTtHQUNoQixTQUFTLGVBQWUsQ0FBQyxFQUFFLENBQUM7R0FDNUIsbUJBQW1CLElBQUksY0FBYztHQUNyQyxtQkFBbUIsSUFBSSxnQkFBZ0I7RUFDekM7RUFDQSxlQUFlLElBQUk7R0FDakIsU0FBUyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUM7R0FDN0IsbUJBQW1CLElBQUksZUFBZTtHQUN0QyxtQkFBbUIsSUFBSSxpQkFBaUI7RUFDMUM7RUFDQSxTQUFTLGNBQWMsS0FBSztFQUM1QixVQUFVLGNBQWMsSUFBSTtFQUM1QixRQUFRLElBQUksTUFBTTtHQUNoQixHQUFHLGFBQWE7R0FDaEIsTUFBTSxnQkFBZ0IsWUFBWSxJQUFJLElBQUk7R0FDMUMsbUJBQW1CLElBQUksY0FBYztHQUNyQyxJQUFJLENBQUMsR0FBRyxpQkFBaUI7SUFDdkIsWUFBWSxFQUFFO0lBQ2QsbUJBQW1CLElBQUksZ0JBQWdCO0dBQ3pDLE9BQU87SUFDTCxtQkFBbUIsSUFBSSxnQkFBZ0I7SUFDdkMsWUFBWSxFQUFFO0dBQ2hCO0dBQ0EsZ0JBQWdCO0lBQ2QsSUFBSSxDQUFDLEdBQUcsWUFBWTtLQUNsQjtJQUNGO0lBQ0Esc0JBQXNCLElBQUksY0FBYztJQUN4QyxtQkFBbUIsSUFBSSxZQUFZO0lBQ25DLElBQUksQ0FBQyxvQkFBb0IsT0FBTyxHQUFHO0tBQ2pDLG1CQUFtQixJQUFJLE1BQU0sZUFBZSxPQUFPO0lBQ3JEO0dBQ0YsQ0FBQztHQUNELFNBQVMsU0FBUyxDQUFDLElBQUksT0FBTyxDQUFDO0VBQ2pDO0VBQ0EsaUJBQWlCLElBQUk7R0FDbkIsWUFBWSxJQUFJLE9BQU8sS0FBSyxHQUFHLElBQUk7R0FDbkMsU0FBUyxrQkFBa0IsQ0FBQyxFQUFFLENBQUM7RUFDakM7RUFDQSxrQkFBa0IsSUFBSTtHQUNwQixZQUFZLElBQUksTUFBTSxLQUFLLEdBQUcsSUFBSTtHQUNsQyxTQUFTLG1CQUFtQixDQUFDLEVBQUUsQ0FBQztFQUNsQztFQUNBLGlCQUFpQixJQUFJO0dBQ25CLFlBQVksRUFBRTtHQUNkLFNBQVMsa0JBQWtCLENBQUMsRUFBRSxDQUFDO0VBQ2pDO0NBQ0YsQ0FBQztBQUNIO0FBQ0EsU0FBUyxrQkFBa0IsVUFBVTtDQUNuQyxJQUFJLFlBQVksTUFBTTtFQUNwQixPQUFPO0NBQ1QsT0FBTyxJQUFJLFNBQVMsUUFBUSxHQUFHO0VBQzdCLE9BQU8sQ0FBQyxTQUFTLFNBQVMsS0FBSyxHQUFHLFNBQVMsU0FBUyxLQUFLLENBQUM7Q0FDNUQsT0FBTztFQUNMLE1BQU0sSUFBSSxTQUFTLFFBQVE7RUFDM0IsT0FBTyxDQUFDLEdBQUcsQ0FBQztDQUNkO0FBQ0Y7QUFDQSxTQUFTLFNBQVMsS0FBSztDQUNyQixNQUFNLE1BQU0sU0FBUyxHQUFHO0NBQ3hCLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtFQUM3QyxhQUFhLEtBQUssZ0NBQWdDO0NBQ3BEO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyxtQkFBbUIsSUFBSSxLQUFLO0NBQ25DLElBQUksTUFBTSxLQUFLLENBQUMsQ0FBQyxTQUFTLE1BQU0sS0FBSyxHQUFHLFVBQVUsSUFBSSxDQUFDLENBQUM7Q0FDeEQsQ0FBQyxHQUFHLFlBQVksR0FBRywwQkFBMEIsSUFBSSxJQUFJLEdBQUUsQ0FBRSxJQUFJLEdBQUc7QUFDbEU7QUFDQSxTQUFTLHNCQUFzQixJQUFJLEtBQUs7Q0FDdEMsSUFBSSxNQUFNLEtBQUssQ0FBQyxDQUFDLFNBQVMsTUFBTSxLQUFLLEdBQUcsVUFBVSxPQUFPLENBQUMsQ0FBQztDQUMzRCxNQUFNLE9BQU8sR0FBRztDQUNoQixJQUFJLE1BQU07RUFDUixLQUFLLE9BQU8sR0FBRztFQUNmLElBQUksQ0FBQyxLQUFLLE1BQU07R0FDZCxHQUFHLFVBQVUsS0FBSztFQUNwQjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLFVBQVUsSUFBSTtDQUNyQiw0QkFBNEI7RUFDMUIsc0JBQXNCLEVBQUU7Q0FDMUIsQ0FBQztBQUNIO0FBQ0EsSUFBSSxRQUFRO0FBQ1osU0FBUyxtQkFBbUIsSUFBSSxjQUFjLGlCQUFpQixTQUFTO0NBQ3RFLE1BQU0sS0FBSyxHQUFHLFNBQVMsRUFBRTtDQUN6QixNQUFNLDBCQUEwQjtFQUM5QixJQUFJLE9BQU8sR0FBRyxRQUFRO0dBQ3BCLFFBQVE7RUFDVjtDQUNGO0NBQ0EsSUFBSSxtQkFBbUIsTUFBTTtFQUMzQixPQUFPLFdBQVcsbUJBQW1CLGVBQWU7Q0FDdEQ7Q0FDQSxNQUFNLEVBQUUsTUFBTSxTQUFTLGNBQWMsa0JBQWtCLElBQUksWUFBWTtDQUN2RSxJQUFJLENBQUMsTUFBTTtFQUNULE9BQU8sUUFBUTtDQUNqQjtDQUNBLE1BQU0sV0FBVyxPQUFPO0NBQ3hCLElBQUksUUFBUTtDQUNaLE1BQU0sWUFBWTtFQUNoQixHQUFHLG9CQUFvQixVQUFVLEtBQUs7RUFDdEMsa0JBQWtCO0NBQ3BCO0NBQ0EsTUFBTSxTQUFTLE1BQU07RUFDbkIsSUFBSSxFQUFFLFdBQVcsTUFBTSxFQUFFLFNBQVMsV0FBVztHQUMzQyxJQUFJO0VBQ047Q0FDRjtDQUNBLGlCQUFpQjtFQUNmLElBQUksUUFBUSxXQUFXO0dBQ3JCLElBQUk7RUFDTjtDQUNGLEdBQUcsVUFBVSxDQUFDO0NBQ2QsR0FBRyxpQkFBaUIsVUFBVSxLQUFLO0FBQ3JDO0FBQ0EsU0FBUyxrQkFBa0IsSUFBSSxjQUFjO0NBQzNDLE1BQU0sU0FBUyxPQUFPLGlCQUFpQixFQUFFO0NBQ3pDLE1BQU0sc0JBQXNCLFNBQVMsT0FBTyxRQUFRLEdBQUUsQ0FBRSxNQUFNLElBQUk7Q0FDbEUsTUFBTSxtQkFBbUIsbUJBQW1CLEdBQUcsV0FBVyxNQUFNO0NBQ2hFLE1BQU0sc0JBQXNCLG1CQUFtQixHQUFHLFdBQVcsU0FBUztDQUN0RSxNQUFNLG9CQUFvQixXQUFXLGtCQUFrQixtQkFBbUI7Q0FDMUUsTUFBTSxrQkFBa0IsbUJBQW1CLEdBQUcsVUFBVSxNQUFNO0NBQzlELE1BQU0scUJBQXFCLG1CQUFtQixHQUFHLFVBQVUsU0FBUztDQUNwRSxNQUFNLG1CQUFtQixXQUFXLGlCQUFpQixrQkFBa0I7Q0FDdkUsSUFBSSxPQUFPO0NBQ1gsSUFBSSxVQUFVO0NBQ2QsSUFBSSxZQUFZO0NBQ2hCLElBQUksaUJBQWlCLFlBQVk7RUFDL0IsSUFBSSxvQkFBb0IsR0FBRztHQUN6QixPQUFPO0dBQ1AsVUFBVTtHQUNWLFlBQVksb0JBQW9CO0VBQ2xDO0NBQ0YsT0FBTyxJQUFJLGlCQUFpQixXQUFXO0VBQ3JDLElBQUksbUJBQW1CLEdBQUc7R0FDeEIsT0FBTztHQUNQLFVBQVU7R0FDVixZQUFZLG1CQUFtQjtFQUNqQztDQUNGLE9BQU87RUFDTCxVQUFVLEtBQUssSUFBSSxtQkFBbUIsZ0JBQWdCO0VBQ3RELE9BQU8sVUFBVSxJQUFJLG9CQUFvQixtQkFBbUIsYUFBYSxZQUFZO0VBQ3JGLFlBQVksT0FBTyxTQUFTLGFBQWEsb0JBQW9CLFNBQVMsbUJBQW1CLFNBQVM7Q0FDcEc7Q0FDQSxNQUFNLGVBQWUsU0FBUyxjQUFjLDZCQUE2QixLQUN2RSxtQkFBbUIsR0FBRyxXQUFXLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FDdkQ7Q0FDQSxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxXQUFXLFFBQVEsV0FBVztDQUNyQyxPQUFPLE9BQU8sU0FBUyxVQUFVLFFBQVE7RUFDdkMsU0FBUyxPQUFPLE9BQU8sTUFBTTtDQUMvQjtDQUNBLE9BQU8sS0FBSyxJQUFJLEdBQUcsVUFBVSxLQUFLLEdBQUcsTUFBTSxLQUFLLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRSxDQUFDLENBQUM7QUFDdkU7QUFDQSxTQUFTLEtBQUssR0FBRztDQUNmLElBQUksTUFBTSxRQUFRLE9BQU87Q0FDekIsT0FBTyxPQUFPLEVBQUUsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxLQUFLLEdBQUcsQ0FBQyxJQUFJO0FBQ3BEO0FBQ0EsU0FBUyxZQUFZLElBQUk7Q0FDdkIsTUFBTSxpQkFBaUIsS0FBSyxHQUFHLGdCQUFnQjtDQUMvQyxPQUFPLGVBQWUsS0FBSztBQUM3QjtBQUVBLFNBQVMsV0FBVyxJQUFJLE9BQU8sT0FBTztDQUNwQyxNQUFNLG9CQUFvQixHQUFHO0NBQzdCLElBQUksbUJBQW1CO0VBQ3JCLFNBQVMsUUFBUSxDQUFDLE9BQU8sR0FBRyxpQkFBaUIsSUFBSSxDQUFDLEdBQUcsaUJBQWlCLEVBQUMsQ0FBRSxLQUFLLEdBQUc7Q0FDbkY7Q0FDQSxJQUFJLFNBQVMsTUFBTTtFQUNqQixHQUFHLGdCQUFnQixPQUFPO0NBQzVCLE9BQU8sSUFBSSxPQUFPO0VBQ2hCLEdBQUcsYUFBYSxTQUFTLEtBQUs7Q0FDaEMsT0FBTztFQUNMLEdBQUcsWUFBWTtDQUNqQjtBQUNGO0FBRUEsTUFBTSx1QkFBdUMsdUJBQU8sTUFBTTtBQUMxRCxNQUFNLGNBQThCLHVCQUFPLE1BQU07QUFDakQsTUFBTSxRQUFROztDQUVaLE1BQU07Q0FDTixZQUFZLElBQUksRUFBRSxTQUFTLEVBQUUsY0FBYztFQUN6QyxHQUFHLHdCQUF3QixHQUFHLE1BQU0sWUFBWSxTQUFTLEtBQUssR0FBRyxNQUFNO0VBQ3ZFLElBQUksY0FBYyxPQUFPO0dBQ3ZCLFdBQVcsWUFBWSxFQUFFO0VBQzNCLE9BQU87R0FDTCxXQUFXLElBQUksS0FBSztFQUN0QjtDQUNGO0NBQ0EsUUFBUSxJQUFJLEVBQUUsU0FBUyxFQUFFLGNBQWM7RUFDckMsSUFBSSxjQUFjLE9BQU87R0FDdkIsV0FBVyxNQUFNLEVBQUU7RUFDckI7Q0FDRjtDQUNBLFFBQVEsSUFBSSxFQUFFLE9BQU8sWUFBWSxFQUFFLGNBQWM7RUFDL0MsSUFBSSxDQUFDLFVBQVUsQ0FBQyxVQUFVO0VBQzFCLElBQUksWUFBWTtHQUNkLElBQUksT0FBTztJQUNULFdBQVcsWUFBWSxFQUFFO0lBQ3pCLFdBQVcsSUFBSSxJQUFJO0lBQ25CLFdBQVcsTUFBTSxFQUFFO0dBQ3JCLE9BQU87SUFDTCxXQUFXLE1BQU0sVUFBVTtLQUN6QixXQUFXLElBQUksS0FBSztJQUN0QixDQUFDO0dBQ0g7RUFDRixPQUFPO0dBQ0wsV0FBVyxJQUFJLEtBQUs7RUFDdEI7Q0FDRjtDQUNBLGNBQWMsSUFBSSxFQUFFLFNBQVM7RUFDM0IsV0FBVyxJQUFJLEtBQUs7Q0FDdEI7QUFDRjtBQUNBLFNBQVMsV0FBVyxJQUFJLE9BQU87Q0FDN0IsR0FBRyxNQUFNLFVBQVUsUUFBUSxHQUFHLHdCQUF3QjtDQUN0RCxHQUFHLGVBQWUsQ0FBQztBQUNyQjtBQUNBLFNBQVMsa0JBQWtCO0NBQ3pCLE1BQU0sZUFBZSxFQUFFLFlBQVk7RUFDakMsSUFBSSxDQUFDLE9BQU87R0FDVixPQUFPLEVBQUUsT0FBTyxFQUFFLFNBQVMsT0FBTyxFQUFFO0VBQ3RDO0NBQ0Y7QUFDRjtBQUVBLE1BQU0sZUFBK0IsdUJBQU8sQ0FBQyxvQkFBMkIsZ0JBQWdCLGlCQUFpQixFQUFFO0FBQzNHLFNBQVMsV0FBVyxRQUFRO0NBQzFCLE1BQU0sV0FBVyxtQkFBbUI7Q0FDcEMsSUFBSSxDQUFDLFVBQVU7RUFDYixDQUFDLG9CQUEyQixpQkFBaUIsS0FBSyxpRUFBaUU7RUFDbkg7Q0FDRjtDQUNBLE1BQU0sa0JBQWtCLFNBQVMsTUFBTSxPQUFPLE9BQU8sU0FBUyxLQUFLLE1BQU07RUFDdkUsTUFBTSxLQUNKLFNBQVMsaUJBQWlCLGtCQUFrQixTQUFTLElBQUksR0FBRyxDQUM5RCxDQUFDLENBQUMsU0FBUyxTQUFTLGNBQWMsTUFBTSxJQUFJLENBQUM7Q0FDL0M7Q0FDQSxJQUFJLENBQUMsb0JBQTJCLGVBQWU7RUFDN0MsU0FBUyxtQkFBbUIsT0FBTyxTQUFTLEtBQUs7Q0FDbkQ7Q0FDQSxNQUFNLGdCQUFnQjtFQUNwQixNQUFNLE9BQU8sT0FBTyxTQUFTLEtBQUs7RUFDbEMsSUFBSSxTQUFTLElBQUk7R0FDZixjQUFjLFNBQVMsSUFBSSxJQUFJO0VBQ2pDLE9BQU87R0FDTCxlQUFlLFNBQVMsU0FBUyxJQUFJO0VBQ3ZDO0VBQ0EsZ0JBQWdCLElBQUk7Q0FDdEI7Q0FDQSxxQkFBcUI7RUFDbkIsaUJBQWlCLE9BQU87Q0FDMUIsQ0FBQztDQUNELGdCQUFnQjtFQUNkLE1BQU0sU0FBUyxNQUFNLEVBQUUsT0FBTyxPQUFPLENBQUM7RUFDdEMsTUFBTSxLQUFLLElBQUksaUJBQWlCLE9BQU87RUFDdkMsR0FBRyxRQUFRLFNBQVMsUUFBUSxHQUFHLFlBQVksRUFBRSxXQUFXLEtBQUssQ0FBQztFQUM5RCxrQkFBa0IsR0FBRyxXQUFXLENBQUM7Q0FDbkMsQ0FBQztBQUNIO0FBQ0EsU0FBUyxlQUFlLE9BQU8sTUFBTTtDQUNuQyxJQUFJLE1BQU0sWUFBWSxLQUFLO0VBQ3pCLE1BQU0sV0FBVyxNQUFNO0VBQ3ZCLFFBQVEsU0FBUztFQUNqQixJQUFJLFNBQVMsaUJBQWlCLENBQUMsU0FBUyxhQUFhO0dBQ25ELFNBQVMsUUFBUSxXQUFXO0lBQzFCLGVBQWUsU0FBUyxjQUFjLElBQUk7R0FDNUMsQ0FBQztFQUNIO0NBQ0Y7Q0FDQSxPQUFPLE1BQU0sV0FBVztFQUN0QixRQUFRLE1BQU0sVUFBVTtDQUMxQjtDQUNBLElBQUksTUFBTSxZQUFZLEtBQUssTUFBTSxJQUFJO0VBQ25DLGNBQWMsTUFBTSxJQUFJLElBQUk7Q0FDOUIsT0FBTyxJQUFJLE1BQU0sU0FBUyxVQUFVO0VBQ2xDLE1BQU0sU0FBUyxTQUFTLE1BQU0sZUFBZSxHQUFHLElBQUksQ0FBQztDQUN2RCxPQUFPLElBQUksTUFBTSxTQUFTLFFBQVE7RUFDaEMsSUFBSSxFQUFFLElBQUksV0FBVztFQUNyQixPQUFPLElBQUk7R0FDVCxjQUFjLElBQUksSUFBSTtHQUN0QixJQUFJLE9BQU8sUUFBUTtHQUNuQixLQUFLLEdBQUc7RUFDVjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLGNBQWMsSUFBSSxNQUFNO0NBQy9CLElBQUksR0FBRyxhQUFhLEdBQUc7RUFDckIsTUFBTSxRQUFRLEdBQUc7RUFDakIsSUFBSSxVQUFVO0VBQ2QsS0FBSyxNQUFNLE9BQU8sTUFBTTtHQUN0QixNQUFNLFFBQVEscUJBQXFCLEtBQUssSUFBSTtHQUM1QyxNQUFNLFlBQVksS0FBSyxPQUFPLEtBQUs7R0FDbkMsV0FBVyxLQUFLLElBQUksSUFBSSxNQUFNO0VBQ2hDO0VBQ0EsTUFBTSxnQkFBZ0I7Q0FDeEI7QUFDRjtBQUVBLE1BQU0sWUFBWTtBQUNsQixTQUFTLFdBQVcsSUFBSSxNQUFNLE1BQU07Q0FDbEMsTUFBTSxRQUFRLEdBQUc7Q0FDakIsTUFBTSxjQUFjLFNBQVMsSUFBSTtDQUNqQyxJQUFJLHVCQUF1QjtDQUMzQixJQUFJLFFBQVEsQ0FBQyxhQUFhO0VBQ3hCLElBQUksTUFBTTtHQUNSLElBQUksQ0FBQyxTQUFTLElBQUksR0FBRztJQUNuQixLQUFLLE1BQU0sT0FBTyxNQUFNO0tBQ3RCLElBQUksS0FBSyxRQUFRLE1BQU07TUFDckIsU0FBUyxPQUFPLEtBQUssRUFBRTtLQUN6QjtJQUNGO0dBQ0YsT0FBTztJQUNMLEtBQUssTUFBTSxhQUFhLEtBQUssTUFBTSxHQUFHLEdBQUc7S0FDdkMsTUFBTSxNQUFNLFVBQVUsTUFBTSxHQUFHLFVBQVUsUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUs7S0FDNUQsSUFBSSxLQUFLLFFBQVEsTUFBTTtNQUNyQixTQUFTLE9BQU8sS0FBSyxFQUFFO0tBQ3pCO0lBQ0Y7R0FDRjtFQUNGO0VBQ0EsS0FBSyxNQUFNLE9BQU8sTUFBTTtHQUN0QixJQUFJLFFBQVEsV0FBVztJQUNyQix1QkFBdUI7R0FDekI7R0FDQSxNQUFNLFFBQVEsS0FBSztHQUNuQixJQUFJLFNBQVMsTUFBTTtJQUNqQixJQUFJLENBQUMsa0NBQ0gsSUFDQSxLQUNBLENBQUMsU0FBUyxJQUFJLEtBQUssT0FBTyxLQUFLLE9BQU8sS0FBSyxHQUMzQyxLQUNGLEdBQUc7S0FDRCxTQUFTLE9BQU8sS0FBSyxLQUFLO0lBQzVCO0dBQ0YsT0FBTztJQUNMLFNBQVMsT0FBTyxLQUFLLEVBQUU7R0FDekI7RUFDRjtDQUNGLE9BQU87RUFDTCxJQUFJLGFBQWE7R0FDZixJQUFJLFNBQVMsTUFBTTtJQUNqQixNQUFNLGFBQWEsTUFBTTtJQUN6QixJQUFJLFlBQVk7S0FDZCxRQUFRLE1BQU07SUFDaEI7SUFDQSxNQUFNLFVBQVU7SUFDaEIsdUJBQXVCLFVBQVUsS0FBSyxJQUFJO0dBQzVDO0VBQ0YsT0FBTyxJQUFJLE1BQU07R0FDZixHQUFHLGdCQUFnQixPQUFPO0VBQzVCO0NBQ0Y7Q0FDQSxJQUFJLHdCQUF3QixJQUFJO0VBQzlCLEdBQUcsd0JBQXdCLHVCQUF1QixNQUFNLFVBQVU7RUFDbEUsSUFBSSxHQUFHLGNBQWM7R0FDbkIsTUFBTSxVQUFVO0VBQ2xCO0NBQ0Y7QUFDRjtBQUNBLE1BQU0sY0FBYztBQUNwQixNQUFNLGNBQWM7QUFDcEIsU0FBUyxTQUFTLE9BQU8sTUFBTSxLQUFLO0NBQ2xDLElBQUksUUFBUSxHQUFHLEdBQUc7RUFDaEIsSUFBSSxTQUFTLE1BQU0sU0FBUyxPQUFPLE1BQU0sQ0FBQyxDQUFDO0NBQzdDLE9BQU87RUFDTCxJQUFJLE9BQU8sTUFBTSxNQUFNO0VBQ3ZCLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtHQUM3QyxJQUFJLFlBQVksS0FBSyxHQUFHLEdBQUc7SUFDekIsS0FDRSx1Q0FBdUMsS0FBSyxrQkFBa0IsSUFBSSxFQUNwRTtHQUNGO0VBQ0Y7RUFDQSxJQUFJLEtBQUssV0FBVyxJQUFJLEdBQUc7R0FDekIsTUFBTSxZQUFZLE1BQU0sR0FBRztFQUM3QixPQUFPO0dBQ0wsTUFBTSxXQUFXLFdBQVcsT0FBTyxJQUFJO0dBQ3ZDLElBQUksWUFBWSxLQUFLLEdBQUcsR0FBRztJQUN6QixNQUFNLFlBQ0osVUFBVSxRQUFRLEdBQ2xCLElBQUksUUFBUSxhQUFhLEVBQUUsR0FDM0IsV0FDRjtHQUNGLE9BQU87SUFDTCxNQUFNLFlBQVk7R0FDcEI7RUFDRjtDQUNGO0FBQ0Y7QUFDQSxNQUFNLFdBQVc7Q0FBQztDQUFVO0NBQU87QUFBSTtBQUN2QyxNQUFNLGNBQWMsQ0FBQztBQUNyQixTQUFTLFdBQVcsT0FBTyxTQUFTO0NBQ2xDLE1BQU0sU0FBUyxZQUFZO0NBQzNCLElBQUksUUFBUTtFQUNWLE9BQU87Q0FDVDtDQUNBLElBQUksT0FBTyxTQUFTLE9BQU87Q0FDM0IsSUFBSSxTQUFTLFlBQVksUUFBUSxPQUFPO0VBQ3RDLE9BQU8sWUFBWSxXQUFXO0NBQ2hDO0NBQ0EsT0FBTyxXQUFXLElBQUk7Q0FDdEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0VBQ3hDLE1BQU0sV0FBVyxTQUFTLEtBQUs7RUFDL0IsSUFBSSxZQUFZLE9BQU87R0FDckIsT0FBTyxZQUFZLFdBQVc7RUFDaEM7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsa0NBQWtDLElBQUksS0FBSyxNQUFNLE1BQU07Q0FDOUQsT0FBTyxHQUFHLFlBQVksZUFBZSxRQUFRLFdBQVcsUUFBUSxhQUFhLFNBQVMsSUFBSSxLQUFLLFNBQVM7QUFDMUc7QUFFQSxNQUFNLFVBQVU7QUFDaEIsU0FBUyxVQUFVLElBQUksS0FBSyxPQUFPLE9BQU8sVUFBVSxZQUFZLHFCQUFxQixHQUFHLEdBQUc7Q0FDekYsSUFBSSxTQUFTLElBQUksV0FBVyxRQUFRLEdBQUc7RUFDckMsSUFBSSxTQUFTLE1BQU07R0FDakIsR0FBRyxrQkFBa0IsU0FBUyxJQUFJLE1BQU0sR0FBRyxJQUFJLE1BQU0sQ0FBQztFQUN4RCxPQUFPO0dBQ0wsR0FBRyxlQUFlLFNBQVMsS0FBSyxLQUFLO0VBQ3ZDO0NBQ0YsT0FBTztFQUNMLElBQUksU0FBUyxRQUFRLGFBQWEsQ0FBQyxtQkFBbUIsS0FBSyxHQUFHO0dBQzVELEdBQUcsZ0JBQWdCLEdBQUc7RUFDeEIsT0FBTztHQUNMLEdBQUcsYUFDRCxLQUNBLFlBQVksS0FBSyxTQUFTLEtBQUssSUFBSSxPQUFPLEtBQUssSUFBSSxLQUNyRDtFQUNGO0NBQ0Y7QUFDRjtBQUVBLFNBQVMsYUFBYSxJQUFJLEtBQUssT0FBTyxpQkFBaUIsVUFBVTtDQUMvRCxJQUFJLFFBQVEsZUFBZSxRQUFRLGVBQWU7RUFDaEQsSUFBSSxTQUFTLE1BQU07R0FDakIsR0FBRyxPQUFPLFFBQVEsY0FBYyxvQkFBb0IsS0FBSyxJQUFJO0VBQy9EO0VBQ0E7Q0FDRjtDQUNBLE1BQU0sTUFBTSxHQUFHO0NBQ2YsSUFBSSxRQUFRLFdBQVcsUUFBUSxjQUMvQixDQUFDLElBQUksU0FBUyxHQUFHLEdBQUc7RUFDbEIsTUFBTSxXQUFXLFFBQVEsV0FBVyxHQUFHLGFBQWEsT0FBTyxLQUFLLEtBQUssR0FBRztFQUN4RSxNQUFNLFdBQVcsU0FBUyxPQUd4QixHQUFHLFNBQVMsYUFBYSxPQUFPLEtBQzlCLE9BQU8sS0FBSztFQUNoQixJQUFJLGFBQWEsWUFBWSxFQUFFLFlBQVksS0FBSztHQUM5QyxHQUFHLFFBQVE7RUFDYjtFQUNBLElBQUksU0FBUyxNQUFNO0dBQ2pCLEdBQUcsZ0JBQWdCLEdBQUc7RUFDeEI7RUFDQSxHQUFHLFNBQVM7RUFDWjtDQUNGO0NBQ0EsSUFBSSxhQUFhO0NBQ2pCLElBQUksVUFBVSxNQUFNLFNBQVMsTUFBTTtFQUNqQyxNQUFNLE9BQU8sT0FBTyxHQUFHO0VBQ3ZCLElBQUksU0FBUyxXQUFXO0dBQ3RCLFFBQVEsbUJBQW1CLEtBQUs7RUFDbEMsT0FBTyxJQUFJLFNBQVMsUUFBUSxTQUFTLFVBQVU7R0FDN0MsUUFBUTtHQUNSLGFBQWE7RUFDZixPQUFPLElBQUksU0FBUyxVQUFVO0dBQzVCLFFBQVE7R0FDUixhQUFhO0VBQ2Y7Q0FDRjtDQUNBLElBQUk7RUFDRixHQUFHLE9BQU87Q0FDWixTQUFTLEdBQUc7RUFDVixJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixDQUFDLFlBQVk7R0FDNUQsS0FDRSx3QkFBd0IsSUFBSSxRQUFRLElBQUksWUFBWSxFQUFFLFdBQVcsTUFBTSxlQUN2RSxDQUNGO0VBQ0Y7Q0FDRjtDQUNBLGNBQWMsR0FBRyxnQkFBZ0IsWUFBWSxHQUFHO0FBQ2xEO0FBRUEsU0FBUyxpQkFBaUIsSUFBSSxPQUFPLFNBQVMsU0FBUztDQUNyRCxHQUFHLGlCQUFpQixPQUFPLFNBQVMsT0FBTztBQUM3QztBQUNBLFNBQVMsb0JBQW9CLElBQUksT0FBTyxTQUFTLFNBQVM7Q0FDeEQsR0FBRyxvQkFBb0IsT0FBTyxTQUFTLE9BQU87QUFDaEQ7QUFDQSxNQUFNLFNBQXlCLHVCQUFPLE1BQU07QUFDNUMsU0FBUyxXQUFXLElBQUksU0FBUyxXQUFXLFdBQVcsV0FBVyxNQUFNO0NBQ3RFLE1BQU0sV0FBVyxHQUFHLFlBQVksR0FBRyxVQUFVLENBQUM7Q0FDOUMsTUFBTSxrQkFBa0IsU0FBUztDQUNqQyxJQUFJLGFBQWEsaUJBQWlCO0VBQ2hDLGdCQUFnQixRQUFRLENBQUMsb0JBQTJCLGdCQUFnQixtQkFBbUIsV0FBVyxPQUFPLElBQUk7Q0FDL0csT0FBTztFQUNMLE1BQU0sQ0FBQyxNQUFNLFdBQVcsVUFBVSxPQUFPO0VBQ3pDLElBQUksV0FBVztHQUNiLE1BQU0sVUFBVSxTQUFTLFdBQVcsY0FDbEMsQ0FBQyxvQkFBMkIsZ0JBQWdCLG1CQUFtQixXQUFXLE9BQU8sSUFBSSxXQUNyRixRQUNGO0dBQ0EsaUJBQWlCLElBQUksTUFBTSxTQUFTLE9BQU87RUFDN0MsT0FBTyxJQUFJLGlCQUFpQjtHQUMxQixvQkFBb0IsSUFBSSxNQUFNLGlCQUFpQixPQUFPO0dBQ3RELFNBQVMsV0FBVyxLQUFLO0VBQzNCO0NBQ0Y7QUFDRjtBQUNBLE1BQU0sb0JBQW9CO0FBQzFCLE1BQU0seUJBQXlCO0FBQy9CLFNBQVMsVUFBVSxNQUFNO0NBQ3ZCLElBQUk7Q0FDSixJQUFJO0NBQ0osUUFBUSxJQUFJLEtBQUssTUFBTSxpQkFBaUIsTUFBTSxDQUFDLHVCQUF1QixLQUFLLElBQUksR0FBRztFQUNoRixJQUFJLENBQUMsU0FBUyxVQUFVLENBQUM7RUFDekIsT0FBTyxLQUFLLE1BQU0sR0FBRyxLQUFLLFNBQVMsRUFBRSxFQUFFLENBQUMsTUFBTTtFQUM5QyxRQUFRLEVBQUUsRUFBRSxDQUFDLFlBQVksS0FBSztDQUNoQztDQUNBLE1BQU0sUUFBUSxLQUFLLE9BQU8sTUFBTSxLQUFLLE1BQU0sQ0FBQyxJQUFJLFVBQVUsS0FBSyxNQUFNLENBQUMsQ0FBQztDQUN2RSxPQUFPLENBQUMsT0FBTyxPQUFPO0FBQ3hCO0FBQ0EsSUFBSSxZQUFZO0FBQ2hCLE1BQU0sSUFBb0Isd0JBQVEsUUFBUTtBQUMxQyxNQUFNLGVBQWUsY0FBYyxFQUFFLFdBQVcsWUFBWSxDQUFDLEdBQUcsWUFBWSxLQUFLLElBQUk7QUFDckYsU0FBUyxjQUFjLGNBQWMsVUFBVTtDQUM3QyxNQUFNLFdBQVcsTUFBTTtFQUNyQixJQUFJLENBQUMsRUFBRSxNQUFNO0dBQ1gsRUFBRSxPQUFPLEtBQUssSUFBSTtFQUNwQixPQUFPLElBQUksRUFBRSxRQUFRLFFBQVEsVUFBVTtHQUNyQztFQUNGO0VBQ0EsTUFBTSxRQUFRLFFBQVE7RUFDdEIsSUFBSSxRQUFRLEtBQUssR0FBRztHQUNsQixNQUFNLGVBQWUsRUFBRTtHQUN2QixFQUFFLGlDQUFpQztJQUNqQyxhQUFhLEtBQUssQ0FBQztJQUNuQixFQUFFLFdBQVc7R0FDZjtHQUNBLE1BQU0sV0FBVyxNQUFNLE1BQU07R0FDN0IsTUFBTSxPQUFPLENBQUMsQ0FBQztHQUNmLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztJQUN4QyxJQUFJLEVBQUUsVUFBVTtLQUNkO0lBQ0Y7SUFDQSxNQUFNLFVBQVUsU0FBUztJQUN6QixJQUFJLFNBQVM7S0FDWCwyQkFDRSxTQUNBLFVBQ0EsR0FDQSxJQUNGO0lBQ0Y7R0FDRjtFQUNGLE9BQU87R0FDTCwyQkFDRSxPQUNBLFVBQ0EsR0FDQSxDQUFDLENBQUMsQ0FDSjtFQUNGO0NBQ0Y7Q0FDQSxRQUFRLFFBQVE7Q0FDaEIsUUFBUSxXQUFXLE9BQU87Q0FDMUIsT0FBTztBQUNUO0FBQ0EsU0FBUyxtQkFBbUIsT0FBTyxVQUFVO0NBQzNDLElBQUksV0FBVyxLQUFLLEtBQUssUUFBUSxLQUFLLEdBQUc7RUFDdkMsT0FBTztDQUNUO0NBQ0EsS0FDRSx5Q0FBeUMsU0FBUzt5REFDRyxPQUFPLE1BQU0sRUFDcEU7Q0FDQSxPQUFPO0FBQ1Q7QUFFQSxNQUFNLGNBQWMsUUFBUSxJQUFJLFdBQVcsQ0FBQyxNQUFNLE9BQU8sSUFBSSxXQUFXLENBQUMsTUFBTSxPQUMvRSxJQUFJLFdBQVcsQ0FBQyxJQUFJLE1BQU0sSUFBSSxXQUFXLENBQUMsSUFBSTtBQUM5QyxNQUFNLGFBQWEsSUFBSSxLQUFLLFdBQVcsV0FBVyxXQUFXLG9CQUFvQjtDQUMvRSxNQUFNLFFBQVEsY0FBYztDQUM1QixJQUFJLFFBQVEsU0FBUztFQUNuQixXQUFXLElBQUksV0FBVyxLQUFLO0NBQ2pDLE9BQU8sSUFBSSxRQUFRLFNBQVM7RUFDMUIsV0FBVyxJQUFJLFdBQVcsU0FBUztDQUNyQyxPQUFPLElBQUksS0FBSyxHQUFHLEdBQUc7RUFDcEIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEdBQUc7R0FDekIsV0FBVyxJQUFJLEtBQUssV0FBVyxXQUFXLGVBQWU7RUFDM0Q7Q0FDRixPQUFPLElBQUksSUFBSSxPQUFPLE9BQU8sTUFBTSxJQUFJLE1BQU0sQ0FBQyxHQUFHLFFBQVEsSUFBSSxPQUFPLE9BQU8sTUFBTSxJQUFJLE1BQU0sQ0FBQyxHQUFHLFNBQVMsZ0JBQWdCLElBQUksS0FBSyxXQUFXLEtBQUssR0FBRztFQUNsSixhQUFhLElBQUksS0FBSyxTQUFTO0VBQy9CLElBQUksQ0FBQyxHQUFHLFFBQVEsU0FBUyxHQUFHLE1BQU0sUUFBUSxXQUFXLFFBQVEsYUFBYSxRQUFRLGFBQWE7R0FDN0YsVUFBVSxJQUFJLEtBQUssV0FBVyxPQUFPLGlCQUFpQixRQUFRLE9BQU87RUFDdkU7Q0FDRixPQUFPLElBRUwsR0FBRyxhQUNGLHdCQUF3QixJQUFJLEdBQUcsS0FDaEMsR0FBRyxLQUFLLGtCQUFrQixRQUFRLEtBQUssR0FBRyxLQUFLLENBQUMsU0FBUyxTQUFTLEtBQ2xFO0VBQ0EsYUFBYSxJQUFJLFdBQVcsR0FBRyxHQUFHLFdBQVcsaUJBQWlCLEdBQUc7Q0FDbkUsT0FBTztFQUNMLElBQUksUUFBUSxjQUFjO0dBQ3hCLEdBQUcsYUFBYTtFQUNsQixPQUFPLElBQUksUUFBUSxlQUFlO0dBQ2hDLEdBQUcsY0FBYztFQUNuQjtFQUNBLFVBQVUsSUFBSSxLQUFLLFdBQVcsS0FBSztDQUNyQztBQUNGO0FBQ0EsU0FBUyxnQkFBZ0IsSUFBSSxLQUFLLE9BQU8sT0FBTztDQUM5QyxJQUFJLE9BQU87RUFDVCxJQUFJLFFBQVEsZUFBZSxRQUFRLGVBQWU7R0FDaEQsT0FBTztFQUNUO0VBQ0EsSUFBSSxPQUFPLE1BQU0sV0FBVyxHQUFHLEtBQUssV0FBVyxLQUFLLEdBQUc7R0FDckQsT0FBTztFQUNUO0VBQ0EsT0FBTztDQUNUO0NBQ0EsSUFBSSxRQUFRLGdCQUFnQixRQUFRLGVBQWUsUUFBUSxlQUFlLFFBQVEsZUFBZTtFQUMvRixPQUFPO0NBQ1Q7Q0FDQSxJQUFJLFFBQVEsYUFBYSxHQUFHLFlBQVksVUFBVTtFQUNoRCxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLFFBQVEsUUFBUTtFQUNsQixPQUFPO0NBQ1Q7Q0FDQSxJQUFJLFFBQVEsVUFBVSxHQUFHLFlBQVksU0FBUztFQUM1QyxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLFFBQVEsVUFBVSxHQUFHLFlBQVksWUFBWTtFQUMvQyxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLFFBQVEsV0FBVyxRQUFRLFVBQVU7RUFDdkMsTUFBTSxNQUFNLEdBQUc7RUFDZixJQUFJLFFBQVEsU0FBUyxRQUFRLFdBQVcsUUFBUSxZQUFZLFFBQVEsVUFBVTtHQUM1RSxPQUFPO0VBQ1Q7Q0FDRjtDQUNBLElBQUksV0FBVyxHQUFHLEtBQUssU0FBUyxLQUFLLEdBQUc7RUFDdEMsT0FBTztDQUNUO0NBQ0EsT0FBTyxPQUFPO0FBQ2hCO0FBQ0EsU0FBUyx3QkFBd0IsSUFBSSxLQUFLO0NBQ3hDLE1BQU0sUUFFSixHQUFHLEtBQUs7Q0FFVixJQUFJLENBQUMsT0FBTztFQUNWLE9BQU87Q0FDVDtDQUNBLE1BQU0sV0FBVyxXQUFXLEdBQUc7Q0FDL0IsT0FBTyxNQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sTUFBTSxTQUFTLFdBQVcsSUFBSSxNQUFNLFFBQVEsSUFBSSxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsTUFBTSxTQUFTLFdBQVcsSUFBSSxNQUFNLFFBQVE7QUFDcko7QUFFQSxNQUFNLFVBQVUsQ0FBQzs7QUFFakIsU0FBUyxvQkFBb0IsU0FBUyxjQUFjLFlBQVk7Q0FDOUQsSUFBSSxPQUFPLGdCQUFnQixTQUFTLFlBQVk7Q0FDaEQsSUFBSSxjQUFjLElBQUksR0FBRyxPQUFPLE9BQU8sQ0FBQyxHQUFHLE1BQU0sWUFBWTtDQUM3RCxNQUFNLHlCQUF5QixXQUFXO0VBQ3hDLFlBQVksY0FBYztHQUN4QixNQUFNLE1BQU0sY0FBYyxVQUFVO0VBQ3RDO0NBQ0Y7Q0FDQSxpQkFBaUIsTUFBTTtDQUN2QixPQUFPO0FBQ1Q7QUFDQSxNQUFNLHNEQUFzRCxTQUFTLGlCQUFpQjtDQUNwRixPQUF1QixvQ0FBb0IsU0FBUyxjQUFjLFlBQVk7QUFDaEY7QUFDQSxNQUFNLFlBQVksT0FBTyxnQkFBZ0IsY0FBYyxjQUFjLE1BQU0sQ0FDM0U7QUFDQSxNQUFNLG1CQUFtQixVQUFVO0NBQ2pDLFlBQVksTUFBTSxTQUFTLENBQUMsR0FBRyxhQUFhLFdBQVc7RUFDckQsTUFBTTtFQUNOLEtBQUssT0FBTztFQUNaLEtBQUssU0FBUztFQUNkLEtBQUssYUFBYTtFQUNsQixLQUFLLFdBQVc7Ozs7RUFJaEIsS0FBSyxZQUFZOzs7O0VBSWpCLEtBQUssT0FBTzs7OztFQUlaLEtBQUssU0FBUyxLQUFLLEtBQUs7RUFDeEIsS0FBSyxhQUFhO0VBQ2xCLEtBQUssWUFBWTtFQUNqQixLQUFLLFlBQVk7RUFDakIsS0FBSyxTQUFTO0VBQ2QsS0FBSyxlQUFlO0VBQ3BCLEtBQUssaUNBQWlDLElBQUksUUFBUTtFQUNsRCxLQUFLLGdDQUFnQyxJQUFJLFFBQVE7RUFDakQsS0FBSyxNQUFNO0VBQ1gsSUFBSSxLQUFLLGNBQWMsZUFBZSxXQUFXO0dBQy9DLEtBQUssUUFBUSxLQUFLO0VBQ3BCLE9BQU87R0FDTCxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixLQUFLLFlBQVk7SUFDaEUsS0FDRSwySEFDRjtHQUNGO0dBQ0EsSUFBSSxLQUFLLGVBQWUsT0FBTztJQUM3QixLQUFLLGFBQ0gsT0FBTyxDQUFDLEdBQUcsS0FBSyxtQkFBbUIsRUFDakMsTUFBTSxPQUNSLENBQUMsQ0FDSDtJQUNBLEtBQUssUUFBUSxLQUFLO0dBQ3BCLE9BQU87SUFDTCxLQUFLLFFBQVE7R0FDZjtFQUNGO0NBQ0Y7Q0FDQSxvQkFBb0I7RUFDbEIsSUFBSSxDQUFDLEtBQUssYUFBYTtFQUN2QixJQUFJLENBQUMsS0FBSyxjQUFjLENBQUMsS0FBSyxXQUFXO0dBQ3ZDLEtBQUssWUFBWTtFQUNuQjtFQUNBLEtBQUssYUFBYTtFQUNsQixJQUFJLFNBQVM7RUFDYixPQUFPLFNBQVMsV0FDZixPQUFPLGdCQUFnQixPQUFPLGNBQWMsT0FBTyxPQUFPO0dBQ3pELElBQUksa0JBQWtCLFlBQVk7SUFDaEMsS0FBSyxVQUFVO0lBQ2Y7R0FDRjtFQUNGO0VBQ0EsSUFBSSxDQUFDLEtBQUssV0FBVztHQUNuQixJQUFJLEtBQUssV0FBVztJQUNsQixLQUFLLE9BQU8sS0FBSyxJQUFJO0dBQ3ZCLE9BQU87SUFDTCxJQUFJLFVBQVUsT0FBTyxpQkFBaUI7S0FDcEMsS0FBSyxrQkFBa0IsT0FBTyxnQkFBZ0IsV0FBVztNQUN2RCxLQUFLLGtCQUFrQixLQUFLO01BQzVCLEtBQUssWUFBWTtLQUNuQixDQUFDO0lBQ0gsT0FBTztLQUNMLEtBQUssWUFBWTtJQUNuQjtHQUNGO0VBQ0Y7Q0FDRjtDQUNBLFdBQVcsU0FBUyxLQUFLLFNBQVM7RUFDaEMsSUFBSSxRQUFRO0dBQ1YsS0FBSyxVQUFVLFNBQVMsT0FBTztHQUMvQixLQUFLLHNCQUFzQixNQUFNO0VBQ25DO0NBQ0Y7Q0FDQSxzQkFBc0IsU0FBUyxLQUFLLFNBQVM7RUFDM0MsSUFBSSxVQUFVLEtBQUssTUFBTTtHQUN2QixPQUFPLGVBQ0wsS0FBSyxLQUFLLFNBQVMsVUFDbkIsT0FBTyxVQUFVLFFBQ25CO0VBQ0Y7Q0FDRjtDQUNBLHVCQUF1QjtFQUNyQixLQUFLLGFBQWE7RUFDbEIsZUFBZTtHQUNiLElBQUksQ0FBQyxLQUFLLFlBQVk7SUFDcEIsSUFBSSxLQUFLLEtBQUs7S0FDWixLQUFLLElBQUksV0FBVztLQUNwQixLQUFLLE1BQU07SUFDYjtJQUNBLEtBQUssUUFBUSxLQUFLLEtBQUssUUFBUTtJQUMvQixJQUFJLEtBQUssV0FBVyxLQUFLLFVBQVUsS0FBSyxLQUFLO0lBQzdDLEtBQUssT0FBTyxLQUFLLFlBQVk7SUFDN0IsSUFBSSxLQUFLLGtCQUFrQjtLQUN6QixLQUFLLGlCQUFpQixNQUFNO0tBQzVCLEtBQUssbUJBQW1CLEtBQUs7SUFDL0I7R0FDRjtFQUNGLENBQUM7Q0FDSDtDQUNBLGtCQUFrQixXQUFXO0VBQzNCLEtBQUssTUFBTSxLQUFLLFdBQVc7R0FDekIsS0FBSyxTQUFTLEVBQUUsYUFBYTtFQUMvQjtDQUNGOzs7O0NBSUEsY0FBYztFQUNaLElBQUksS0FBSyxpQkFBaUI7R0FDeEI7RUFDRjtFQUNBLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLFdBQVcsUUFBUSxLQUFLO0dBQy9DLEtBQUssU0FBUyxLQUFLLFdBQVcsRUFBRSxDQUFDLElBQUk7RUFDdkM7RUFDQSxLQUFLLE1BQU0sSUFBSSxpQkFBaUIsS0FBSyxrQkFBa0IsS0FBSyxJQUFJLENBQUM7RUFDakUsS0FBSyxJQUFJLFFBQVEsTUFBTSxFQUFFLFlBQVksS0FBSyxDQUFDO0VBQzNDLE1BQU0sV0FBVyxLQUFLLFVBQVUsVUFBVTtHQUN4QyxLQUFLLFlBQVk7R0FDakIsS0FBSyxrQkFBa0IsS0FBSztHQUM1QixNQUFNLEVBQUUsT0FBTyxXQUFXO0dBQzFCLElBQUk7R0FDSixJQUFJLFNBQVMsQ0FBQyxRQUFRLEtBQUssR0FBRztJQUM1QixLQUFLLE1BQU0sT0FBTyxPQUFPO0tBQ3ZCLE1BQU0sTUFBTSxNQUFNO0tBQ2xCLElBQUksUUFBUSxVQUFVLE9BQU8sSUFBSSxTQUFTLFFBQVE7TUFDaEQsSUFBSSxPQUFPLEtBQUssUUFBUTtPQUN0QixLQUFLLE9BQU8sT0FBTyxTQUFTLEtBQUssT0FBTyxJQUFJO01BQzlDO01BQ0EsQ0FBQyxnQkFBZ0IsY0FBOEIsdUJBQU8sT0FBTyxJQUFJLEdBQUUsQ0FBRSxXQUFXLEdBQUcsS0FBSztLQUMxRjtJQUNGO0dBQ0Y7R0FDQSxLQUFLLGVBQWU7R0FDcEIsS0FBSyxjQUFjLEdBQUc7R0FDdEIsSUFBSSxLQUFLLFlBQVk7SUFDbkIsS0FBSyxhQUFhLE1BQU07R0FDMUIsT0FBTyxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixRQUFRO0lBQzlELEtBQ0UsOEVBQ0Y7R0FDRjtHQUNBLEtBQUssT0FBTyxHQUFHO0VBQ2pCO0VBQ0EsTUFBTSxXQUFXLEtBQUssS0FBSztFQUMzQixJQUFJLFVBQVU7R0FDWixLQUFLLGtCQUFrQixTQUFTLENBQUMsQ0FBQyxNQUFNLFFBQVE7SUFDOUMsSUFBSSxlQUFlLEtBQUssS0FBSztJQUM3QixRQUFRLEtBQUssT0FBTyxLQUFLLElBQUk7R0FDL0IsQ0FBQztFQUNILE9BQU87R0FDTCxRQUFRLEtBQUssSUFBSTtFQUNuQjtDQUNGO0NBQ0EsT0FBTyxLQUFLO0VBQ1YsS0FBSyxDQUFDLG9CQUEyQixpQkFBaUIsMEJBQTBCLENBQUMsSUFBSSxNQUFNO0dBQ3JGLElBQUksT0FBTztFQUNiO0VBQ0EsS0FBSyxPQUFPLEtBQUssV0FBVyxHQUFHO0VBQy9CLEtBQUssc0JBQXNCO0VBQzNCLElBQUksSUFBSSxjQUFjO0dBQ3BCLElBQUksYUFBYSxLQUFLLElBQUk7RUFDNUI7RUFDQSxLQUFLLEtBQUssV0FBVyxLQUFLLGFBQWE7RUFDdkMsS0FBSyxLQUFLLE1BQU0sS0FBSyxLQUFLO0VBQzFCLE1BQU0sVUFBVSxLQUFLLGFBQWEsS0FBSyxVQUFVO0VBQ2pELElBQUksQ0FBQyxTQUFTO0VBQ2QsS0FBSyxNQUFNLE9BQU8sU0FBUztHQUN6QixJQUFJLENBQUMsT0FBTyxNQUFNLEdBQUcsR0FBRztJQUN0QixPQUFPLGVBQWUsTUFBTSxLQUFLOztBQUUvQixXQUFXLE1BQU0sUUFBUSxJQUFJLEVBQy9CLENBQUM7R0FDSCxPQUFPLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtJQUNwRCxLQUFLLHFCQUFxQixJQUFJLG9DQUFvQztHQUNwRTtFQUNGO0NBQ0Y7Q0FDQSxjQUFjLEtBQUs7RUFDakIsTUFBTSxFQUFFLFVBQVU7RUFDbEIsTUFBTSxtQkFBbUIsUUFBUSxLQUFLLElBQUksUUFBUSxPQUFPLEtBQUssU0FBUyxDQUFDLENBQUM7RUFDekUsS0FBSyxNQUFNLE9BQU8sT0FBTyxLQUFLLElBQUksR0FBRztHQUNuQyxJQUFJLElBQUksT0FBTyxPQUFPLGlCQUFpQixTQUFTLEdBQUcsR0FBRztJQUNwRCxLQUFLLFNBQVMsS0FBSyxLQUFLLElBQUk7R0FDOUI7RUFDRjtFQUNBLEtBQUssTUFBTSxPQUFPLGlCQUFpQixJQUFJLFVBQVUsR0FBRztHQUNsRCxPQUFPLGVBQWUsTUFBTSxLQUFLO0lBQy9CLE1BQU07S0FDSixPQUFPLEtBQUssU0FBUyxHQUFHO0lBQzFCO0lBQ0EsSUFBSSxLQUFLO0tBQ1AsS0FBSyxTQUFTLEtBQUssS0FBSyxNQUFNLENBQUMsS0FBSyxTQUFTO0lBQy9DO0dBQ0YsQ0FBQztFQUNIO0NBQ0Y7Q0FDQSxTQUFTLEtBQUs7RUFDWixJQUFJLElBQUksV0FBVyxTQUFTLEdBQUc7RUFDL0IsTUFBTSxNQUFNLEtBQUssYUFBYSxHQUFHO0VBQ2pDLElBQUksUUFBUSxNQUFNLEtBQUssYUFBYSxHQUFHLElBQUk7RUFDM0MsTUFBTSxXQUFXLFdBQVcsR0FBRztFQUMvQixJQUFJLE9BQU8sS0FBSyxnQkFBZ0IsS0FBSyxhQUFhLFdBQVc7R0FDM0QsUUFBUSxTQUFTLEtBQUs7RUFDeEI7RUFDQSxLQUFLLFNBQVMsVUFBVSxPQUFPLE9BQU8sSUFBSTtDQUM1Qzs7OztDQUlBLFNBQVMsS0FBSztFQUNaLE9BQU8sS0FBSyxPQUFPO0NBQ3JCOzs7O0NBSUEsU0FBUyxLQUFLLEtBQUssZ0JBQWdCLE1BQU0sZUFBZSxPQUFPO0VBQzdELElBQUksUUFBUSxLQUFLLE9BQU8sTUFBTTtHQUM1QixLQUFLLFNBQVM7R0FDZCxJQUFJLFFBQVEsU0FBUztJQUNuQixPQUFPLEtBQUssT0FBTztHQUNyQixPQUFPO0lBQ0wsS0FBSyxPQUFPLE9BQU87SUFDbkIsSUFBSSxRQUFRLFNBQVMsS0FBSyxNQUFNO0tBQzlCLEtBQUssS0FBSyxTQUFTLE1BQU07SUFDM0I7R0FDRjtHQUNBLElBQUksZ0JBQWdCLEtBQUssV0FBVztJQUNsQyxLQUFLLFFBQVE7R0FDZjtHQUNBLElBQUksZUFBZTtJQUNqQixNQUFNLEtBQUssS0FBSztJQUNoQixJQUFJLElBQUk7S0FDTixLQUFLLGtCQUFrQixHQUFHLFlBQVksQ0FBQztLQUN2QyxHQUFHLFdBQVc7SUFDaEI7SUFDQSxJQUFJLFFBQVEsTUFBTTtLQUNoQixLQUFLLGFBQWEsVUFBVSxHQUFHLEdBQUcsRUFBRTtJQUN0QyxPQUFPLElBQUksT0FBTyxRQUFRLFlBQVksT0FBTyxRQUFRLFVBQVU7S0FDN0QsS0FBSyxhQUFhLFVBQVUsR0FBRyxHQUFHLE1BQU0sRUFBRTtJQUM1QyxPQUFPLElBQUksQ0FBQyxLQUFLO0tBQ2YsS0FBSyxnQkFBZ0IsVUFBVSxHQUFHLENBQUM7SUFDckM7SUFDQSxNQUFNLEdBQUcsUUFBUSxNQUFNLEVBQUUsWUFBWSxLQUFLLENBQUM7R0FDN0M7RUFDRjtDQUNGO0NBQ0EsVUFBVTtFQUNSLE1BQU0sUUFBUSxLQUFLLGFBQWE7RUFDaEMsSUFBSSxLQUFLLE1BQU0sTUFBTSxhQUFhLEtBQUssS0FBSztFQUM1QyxPQUFPLE9BQU8sS0FBSyxLQUFLO0NBQzFCO0NBQ0EsZUFBZTtFQUNiLE1BQU0sWUFBWSxDQUFDO0VBQ25CLElBQUksQ0FBQyxLQUFLLFlBQVk7R0FDcEIsVUFBVSxpQkFBaUIsVUFBVSxpQkFBaUIsS0FBSyxhQUFhLEtBQUssSUFBSTtFQUNuRjtFQUNBLE1BQU0sUUFBUSxZQUFZLEtBQUssTUFBTSxPQUFPLFdBQVcsS0FBSyxNQUFNLENBQUM7RUFDbkUsSUFBSSxDQUFDLEtBQUssV0FBVztHQUNuQixNQUFNLE1BQU0sYUFBYTtJQUN2QixLQUFLLFlBQVk7SUFDakIsU0FBUyxLQUFLO0lBQ2QsU0FBUyxPQUFPO0lBQ2hCLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtLQUM3QyxTQUFTLFlBQVksY0FBYztNQUNqQyxJQUFJLEtBQUssU0FBUztPQUNoQixLQUFLLFFBQVEsU0FBUyxNQUFNLEtBQUssTUFBTSxZQUFZLENBQUMsQ0FBQztPQUNyRCxLQUFLLFFBQVEsU0FBUztNQUN4QjtNQUNBLEtBQUssY0FBYyxPQUFPLEtBQUssSUFBSTtNQUNuQyxLQUFLLGFBQWEsU0FBUztNQUMzQixLQUFLLFlBQVk7TUFDakIsS0FBSyxRQUFRO0tBQ2Y7SUFDRjtJQUNBLE1BQU0sWUFBWSxPQUFPLFNBQVM7S0FDaEMsS0FBSyxjQUNILElBQUksWUFDRixPQUNBLGNBQWMsS0FBSyxFQUFFLElBQUksT0FBTyxFQUFFLFFBQVEsS0FBSyxHQUFHLEtBQUssRUFBRSxJQUFJLEVBQUUsUUFBUSxLQUFLLENBQzlFLENBQ0Y7SUFDRjtJQUNBLFNBQVMsUUFBUSxPQUFPLEdBQUcsU0FBUztLQUNsQyxTQUFTLE9BQU8sSUFBSTtLQUNwQixJQUFJLFVBQVUsS0FBSyxNQUFNLE9BQU87TUFDOUIsU0FBUyxVQUFVLEtBQUssR0FBRyxJQUFJO0tBQ2pDO0lBQ0Y7SUFDQSxLQUFLLFdBQVc7R0FDbEI7RUFDRjtFQUNBLE9BQU87Q0FDVDtDQUNBLGFBQWEsUUFBUSxPQUFPLFlBQVk7RUFDdEMsSUFBSSxDQUFDLFFBQVE7RUFDYixJQUFJLE9BQU87R0FDVCxJQUFJLFVBQVUsS0FBSyxRQUFRLEtBQUssZUFBZSxJQUFJLEtBQUssR0FBRztJQUN6RDtHQUNGO0dBQ0EsS0FBSyxlQUFlLElBQUksS0FBSztFQUMvQjtFQUNBLE1BQU0sUUFBUSxLQUFLO0VBQ25CLE1BQU0sT0FBTyxLQUFLO0VBQ2xCLE1BQU0sa0JBQWtCLGFBQWEsS0FBSyxnQkFBZ0IsVUFBVSxLQUFLLEtBQUssZ0JBQWdCLEtBQUssSUFBSSxJQUFJLEtBQUssNkJBQTZCLElBQUk7RUFDakosSUFBSSxPQUFPO0VBQ1gsS0FBSyxJQUFJLElBQUksT0FBTyxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7R0FDM0MsTUFBTSxJQUFJLFNBQVMsY0FBYyxPQUFPO0dBQ3hDLElBQUksT0FBTyxFQUFFLGFBQWEsU0FBUyxLQUFLO0dBQ3hDLEVBQUUsY0FBYyxPQUFPO0dBQ3ZCLEtBQUssYUFBYSxHQUFHLFFBQVEsZUFBZTtHQUM1QyxPQUFPO0dBQ1AsSUFBSSxNQUFNLEdBQUc7SUFDWCxJQUFJLENBQUMsWUFBWSxLQUFLLGNBQWMsSUFBSSxLQUFLLE1BQU0sQ0FBQztJQUNwRCxJQUFJLE9BQU8sS0FBSyxjQUFjLElBQUksT0FBTyxDQUFDO0dBQzVDO0dBQ0EsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0lBQzdDLElBQUksT0FBTztLQUNULElBQUksTUFBTSxTQUFTO01BQ2pCLElBQUksQ0FBQyxLQUFLLGNBQWMsS0FBSywrQkFBK0IsSUFBSSxJQUFJO01BQ3BFLElBQUksUUFBUSxLQUFLLGFBQWEsSUFBSSxNQUFNLE9BQU87TUFDL0MsSUFBSSxDQUFDLE9BQU87T0FDVixLQUFLLGFBQWEsSUFBSSxNQUFNLFNBQVMsUUFBUSxDQUFDLENBQUM7TUFDakQ7TUFDQSxNQUFNLEtBQUssQ0FBQztLQUNkO0lBQ0YsT0FBTztLQUNMLENBQUMsS0FBSyxZQUFZLEtBQUssVUFBVSxDQUFDLEdBQUUsQ0FBRSxLQUFLLENBQUM7SUFDOUM7R0FDRjtFQUNGO0NBQ0Y7Q0FDQSxnQkFBZ0IsTUFBTTtFQUNwQixJQUFJLENBQUMsTUFBTTtHQUNULE9BQU87RUFDVDtFQUNBLE1BQU0sU0FBUyxLQUFLLGNBQWMsSUFBSSxJQUFJO0VBQzFDLElBQUksVUFBVSxPQUFPLGVBQWUsS0FBSyxZQUFZO0dBQ25ELE9BQU87RUFDVDtFQUNBLElBQUksUUFBUTtHQUNWLEtBQUssY0FBYyxPQUFPLElBQUk7RUFDaEM7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSw2QkFBNkIsTUFBTTtFQUNqQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxXQUFXLFFBQVEsS0FBSztHQUMvQyxNQUFNLE9BQU8sS0FBSyxXQUFXO0dBQzdCLElBQUksRUFBRSxnQkFBZ0IsbUJBQW1CO0lBQ3ZDLE9BQU87R0FDVDtFQUNGO0VBQ0EsT0FBTztDQUNUOzs7O0NBSUEsY0FBYztFQUNaLE1BQU0sUUFBUSxLQUFLLFNBQVMsQ0FBQztFQUM3QixJQUFJO0VBQ0osT0FBTyxJQUFJLEtBQUssWUFBWTtHQUMxQixNQUFNLFdBQVcsRUFBRSxhQUFhLEtBQUssRUFBRSxhQUFhLE1BQU0sS0FBSztHQUMvRCxDQUFDLE1BQU0sY0FBYyxNQUFNLFlBQVksQ0FBQyxHQUFFLENBQUUsS0FBSyxDQUFDO0dBQ2xELEtBQUssWUFBWSxDQUFDO0VBQ3BCO0NBQ0Y7Ozs7Q0FJQSxlQUFlO0VBQ2IsTUFBTSxVQUFVLEtBQUssVUFBVTtFQUMvQixNQUFNLFVBQVUsS0FBSyxVQUFVLEtBQUs7RUFDcEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUFLO0dBQ3ZDLE1BQU0sSUFBSSxRQUFRO0dBQ2xCLE1BQU0sV0FBVyxFQUFFLGFBQWEsTUFBTSxLQUFLO0dBQzNDLE1BQU0sVUFBVSxLQUFLLE9BQU87R0FDNUIsTUFBTSxTQUFTLEVBQUU7R0FDakIsSUFBSSxTQUFTO0lBQ1gsS0FBSyxNQUFNLEtBQUssU0FBUztLQUN2QixJQUFJLFdBQVcsRUFBRSxhQUFhLEdBQUc7TUFDL0IsTUFBTSxLQUFLLFVBQVU7TUFDckIsTUFBTSxTQUFTLFNBQVMsaUJBQWlCLEdBQUcsQ0FBQztNQUM3QyxFQUFFLGFBQWEsSUFBSSxFQUFFO01BQ3JCLElBQUk7TUFDSixPQUFPLFFBQVEsT0FBTyxTQUFTLEdBQUc7T0FDaEMsTUFBTSxhQUFhLElBQUksRUFBRTtNQUMzQjtLQUNGO0tBQ0EsT0FBTyxhQUFhLEdBQUcsQ0FBQztJQUMxQjtHQUNGLE9BQU87SUFDTCxPQUFPLEVBQUUsWUFBWSxPQUFPLGFBQWEsRUFBRSxZQUFZLENBQUM7R0FDMUQ7R0FDQSxPQUFPLFlBQVksQ0FBQztFQUN0QjtDQUNGOzs7O0NBSUEsWUFBWTtFQUNWLE1BQU0sUUFBUSxDQUFDLElBQUk7RUFDbkIsSUFBSSxLQUFLLGtCQUFrQjtHQUN6QixNQUFNLEtBQUssR0FBRyxLQUFLLGdCQUFnQjtFQUNyQztFQUNBLE1BQU0sd0JBQXdCLElBQUksSUFBSTtFQUN0QyxLQUFLLE1BQU0sUUFBUSxPQUFPO0dBQ3hCLE1BQU0sUUFBUSxLQUFLLGlCQUFpQixNQUFNO0dBQzFDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztJQUNyQyxNQUFNLElBQUksTUFBTSxFQUFFO0dBQ3BCO0VBQ0Y7RUFDQSxPQUFPLE1BQU0sS0FBSyxLQUFLO0NBQ3pCOzs7O0NBSUEsa0JBQWtCLE1BQU0sWUFBWTtFQUNsQyxLQUFLLGFBQWEsS0FBSyxRQUFRLE1BQU0sVUFBVTtDQUNqRDs7OztDQUlBLGNBQWM7RUFDWixLQUFLLFlBQVk7RUFDakIsS0FBSyxTQUFTO0NBQ2hCOzs7O0NBSUEsWUFBWTtFQUNWLEtBQUssWUFBWTtFQUNqQixJQUFJLEtBQUssVUFBVSxLQUFLLFdBQVc7R0FDakMsS0FBSyxRQUFRO0VBQ2Y7Q0FDRjs7OztDQUlBLGlCQUFpQjtFQUNmLE9BQU8sS0FBSyxLQUFLLGVBQWU7Q0FDbEM7Ozs7Q0FJQSxrQkFBa0IsTUFBTTtFQUN0QixJQUFJLENBQUMsb0JBQTJCLGVBQWU7R0FDN0MsS0FBSyxlQUFlLE9BQU8sSUFBSTtHQUMvQixLQUFLLGNBQWMsT0FBTyxJQUFJO0dBQzlCLElBQUksS0FBSyxnQkFBZ0IsS0FBSyxTQUFTO0lBQ3JDLE1BQU0sWUFBWSxLQUFLLGFBQWEsSUFBSSxLQUFLLE9BQU87SUFDcEQsSUFBSSxXQUFXO0tBQ2IsVUFBVSxTQUFTLE1BQU0sS0FBSyxNQUFNLFlBQVksQ0FBQyxDQUFDO0tBQ2xELFVBQVUsU0FBUztJQUNyQjtHQUNGO0VBQ0Y7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxRQUFRLFFBQVE7Q0FDdkIsTUFBTSxXQUFXLG1CQUFtQjtDQUNwQyxNQUFNLEtBQUssWUFBWSxTQUFTO0NBQ2hDLElBQUksSUFBSTtFQUNOLE9BQU87Q0FDVCxPQUFPLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtFQUNwRCxJQUFJLENBQUMsVUFBVTtHQUNiLEtBQ0UsR0FBRyxVQUFVLFVBQVUsOENBQ3pCO0VBQ0YsT0FBTztHQUNMLEtBQ0UsR0FBRyxVQUFVLFVBQVUsaUVBQ3pCO0VBQ0Y7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsZ0JBQWdCO0NBQ3ZCLE1BQU0sS0FBSyxDQUFDLG9CQUEyQixnQkFBZ0IsUUFBUSxlQUFlLElBQUksUUFBUTtDQUMxRixPQUFPLE1BQU0sR0FBRztBQUNsQjtBQUVBLFNBQVMsYUFBYSxPQUFPLFVBQVU7Q0FDckM7RUFDRSxNQUFNLFdBQVcsbUJBQW1CO0VBQ3BDLElBQUksQ0FBQyxVQUFVO0dBQ2IsQ0FBQyxvQkFBMkIsaUJBQWlCLEtBQUssNENBQTRDO0dBQzlGLE9BQU87RUFDVDtFQUNBLE1BQU0sVUFBVSxTQUFTLEtBQUs7RUFDOUIsSUFBSSxDQUFDLFNBQVM7R0FDWixDQUFDLG9CQUEyQixpQkFBaUIsS0FBSyxzREFBc0Q7R0FDeEcsT0FBTztFQUNUO0VBQ0EsTUFBTSxNQUFNLFFBQVE7RUFDcEIsSUFBSSxDQUFDLEtBQUs7R0FDUixDQUFDLG9CQUEyQixpQkFBaUIsS0FBSyxvREFBb0QsS0FBSyxHQUFHO0dBQzlHLE9BQU87RUFDVDtFQUNBLE9BQU87Q0FDVDtBQUNGO0FBRUEsTUFBTSw4QkFBOEIsSUFBSSxRQUFRO0FBQ2hELE1BQU0saUNBQWlDLElBQUksUUFBUTtBQUNuRCxNQUFNLFlBQTRCLHVCQUFPLFNBQVM7QUFDbEQsTUFBTSxhQUE2Qix1QkFBTyxVQUFVO0FBQ3BELE1BQU0sWUFBWSxNQUFNO0NBQ3RCLE9BQU8sRUFBRSxNQUFNO0NBQ2YsT0FBTztBQUNUO0FBQ0EsTUFBTSxzQkFBc0MseUJBQVM7Q0FDbkQsTUFBTTtDQUNOLE9BQXVCLHVCQUFPLENBQUMsR0FBRywyQkFBMkI7RUFDM0QsS0FBSztFQUNMLFdBQVc7Q0FDYixDQUFDO0NBQ0QsTUFBTSxPQUFPLEVBQUUsU0FBUztFQUN0QixNQUFNLFdBQVcsbUJBQW1CO0VBQ3BDLE1BQU0sUUFBUSxtQkFBbUI7RUFDakMsSUFBSTtFQUNKLElBQUk7RUFDSixnQkFBZ0I7R0FDZCxJQUFJLENBQUMsYUFBYSxRQUFRO0lBQ3hCO0dBQ0Y7R0FDQSxNQUFNLFlBQVksTUFBTSxhQUFhLEdBQUcsTUFBTSxRQUFRLElBQUk7R0FDMUQsSUFBSSxDQUFDLGdCQUNILGFBQWEsRUFBRSxDQUFDLElBQ2hCLFNBQVMsTUFBTSxJQUNmLFNBQ0YsR0FBRztJQUNELGVBQWUsQ0FBQztJQUNoQjtHQUNGO0dBQ0EsYUFBYSxRQUFRLGNBQWM7R0FDbkMsYUFBYSxRQUFRLGNBQWM7R0FDbkMsTUFBTSxnQkFBZ0IsYUFBYSxPQUFPLGdCQUFnQjtHQUMxRCxZQUFZLFNBQVMsTUFBTSxFQUFFO0dBQzdCLGNBQWMsU0FBUyxNQUFNO0lBQzNCLE1BQU0sS0FBSyxFQUFFO0lBQ2IsTUFBTSxRQUFRLEdBQUc7SUFDakIsbUJBQW1CLElBQUksU0FBUztJQUNoQyxNQUFNLFlBQVksTUFBTSxrQkFBa0IsTUFBTSxxQkFBcUI7SUFDckUsTUFBTSxLQUFLLEdBQUcsY0FBYyxNQUFNO0tBQ2hDLElBQUksS0FBSyxFQUFFLFdBQVcsSUFBSTtNQUN4QjtLQUNGO0tBQ0EsSUFBSSxDQUFDLEtBQUssRUFBRSxhQUFhLFNBQVMsV0FBVyxHQUFHO01BQzlDLEdBQUcsb0JBQW9CLGlCQUFpQixFQUFFO01BQzFDLEdBQUcsYUFBYTtNQUNoQixzQkFBc0IsSUFBSSxTQUFTO0tBQ3JDO0lBQ0Y7SUFDQSxHQUFHLGlCQUFpQixpQkFBaUIsRUFBRTtHQUN6QyxDQUFDO0dBQ0QsZUFBZSxDQUFDO0VBQ2xCLENBQUM7RUFDRCxhQUFhO0dBQ1gsTUFBTSxXQUFXLE1BQU0sS0FBSztHQUM1QixNQUFNLHFCQUFxQix1QkFBdUIsUUFBUTtHQUMxRCxJQUFJLE1BQU0sU0FBUyxPQUFPO0dBQzFCLGVBQWUsQ0FBQztHQUNoQixJQUFJLFVBQVU7SUFDWixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7S0FDeEMsTUFBTSxRQUFRLFNBQVM7S0FDdkIsSUFBSSxNQUFNLE1BQU0sTUFBTSxjQUFjLFdBQ3BDLENBQUMsTUFBTSxHQUFHLGNBQWM7TUFDdEIsYUFBYSxLQUFLLEtBQUs7TUFDdkIsbUJBQ0UsT0FDQSx1QkFDRSxPQUNBLG9CQUNBLE9BQ0EsUUFDRixDQUNGO01BQ0EsWUFBWSxJQUFJLE9BQU8sWUFBWSxNQUFNLEVBQUUsQ0FBQztLQUM5QztJQUNGO0dBQ0Y7R0FDQSxXQUFXLE1BQU0sVUFBVSx5QkFBeUIsTUFBTSxRQUFRLENBQUMsSUFBSSxDQUFDO0dBQ3hFLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSztJQUN4QyxNQUFNLFFBQVEsU0FBUztJQUN2QixJQUFJLE1BQU0sT0FBTyxNQUFNO0tBQ3JCLG1CQUNFLE9BQ0EsdUJBQXVCLE9BQU8sb0JBQW9CLE9BQU8sUUFBUSxDQUNuRTtJQUNGLE9BQU8sSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsTUFBTSxTQUFTLE1BQU07S0FDM0UsS0FBSywyQ0FBMkM7SUFDbEQ7R0FDRjtHQUNBLE9BQU8sWUFBWSxLQUFLLE1BQU0sUUFBUTtFQUN4QztDQUNGO0FBQ0YsQ0FBQztBQUNELE1BQU0sa0JBQWtCO0FBQ3hCLFNBQVMsZUFBZSxHQUFHO0NBQ3pCLE1BQU0sS0FBSyxFQUFFO0NBQ2IsSUFBSSxHQUFHLFlBQVk7RUFDakIsR0FBRyxVQUFVLENBQUM7Q0FDaEI7Q0FDQSxJQUFJLEdBQUcsYUFBYTtFQUNsQixHQUFHLFdBQVcsQ0FBQztDQUNqQjtBQUNGO0FBQ0EsU0FBUyxlQUFlLEdBQUc7Q0FDekIsZUFBZSxJQUFJLEdBQUcsWUFBWSxFQUFFLEVBQUUsQ0FBQztBQUN6QztBQUNBLFNBQVMsaUJBQWlCLEdBQUc7Q0FDM0IsTUFBTSxTQUFTLFlBQVksSUFBSSxDQUFDO0NBQ2hDLE1BQU0sU0FBUyxlQUFlLElBQUksQ0FBQztDQUNuQyxNQUFNLEtBQUssT0FBTyxPQUFPLE9BQU87Q0FDaEMsTUFBTSxLQUFLLE9BQU8sTUFBTSxPQUFPO0NBQy9CLElBQUksTUFBTSxJQUFJO0VBQ1osTUFBTSxLQUFLLEVBQUU7RUFDYixNQUFNLElBQUksR0FBRztFQUNiLE1BQU0sT0FBTyxHQUFHLHNCQUFzQjtFQUN0QyxJQUFJLFNBQVM7RUFDYixJQUFJLFNBQVM7RUFDYixJQUFJLEdBQUcsYUFBYSxTQUFTLEtBQUssUUFBUSxHQUFHO0VBQzdDLElBQUksR0FBRyxjQUFjLFNBQVMsS0FBSyxTQUFTLEdBQUc7RUFDL0MsSUFBSSxDQUFDLE9BQU8sU0FBUyxNQUFNLEtBQUssV0FBVyxHQUFHLFNBQVM7RUFDdkQsSUFBSSxDQUFDLE9BQU8sU0FBUyxNQUFNLEtBQUssV0FBVyxHQUFHLFNBQVM7RUFDdkQsSUFBSSxLQUFLLElBQUksU0FBUyxDQUFDLElBQUksS0FBTSxTQUFTO0VBQzFDLElBQUksS0FBSyxJQUFJLFNBQVMsQ0FBQyxJQUFJLEtBQU0sU0FBUztFQUMxQyxFQUFFLFlBQVksRUFBRSxrQkFBa0IsYUFBYSxLQUFLLE9BQU8sS0FBSyxLQUFLLE9BQU87RUFDNUUsRUFBRSxxQkFBcUI7RUFDdkIsT0FBTztDQUNUO0FBQ0Y7QUFDQSxTQUFTLFlBQVksSUFBSTtDQUN2QixNQUFNLE9BQU8sR0FBRyxzQkFBc0I7Q0FDdEMsT0FBTztFQUNMLE1BQU0sS0FBSztFQUNYLEtBQUssS0FBSztDQUNaO0FBQ0Y7QUFDQSxTQUFTLGdCQUFnQixJQUFJLE1BQU0sV0FBVztDQUM1QyxNQUFNLFFBQVEsR0FBRyxVQUFVO0NBQzNCLE1BQU0sT0FBTyxHQUFHO0NBQ2hCLElBQUksTUFBTTtFQUNSLEtBQUssU0FBUyxRQUFRO0dBQ3BCLElBQUksTUFBTSxLQUFLLENBQUMsQ0FBQyxTQUFTLE1BQU0sS0FBSyxNQUFNLFVBQVUsT0FBTyxDQUFDLENBQUM7RUFDaEUsQ0FBQztDQUNIO0NBQ0EsVUFBVSxNQUFNLEtBQUssQ0FBQyxDQUFDLFNBQVMsTUFBTSxLQUFLLE1BQU0sVUFBVSxJQUFJLENBQUMsQ0FBQztDQUNqRSxNQUFNLE1BQU0sVUFBVTtDQUN0QixNQUFNLFlBQVksS0FBSyxhQUFhLElBQUksT0FBTyxLQUFLO0NBQ3BELFVBQVUsWUFBWSxLQUFLO0NBQzNCLE1BQU0sRUFBRSxpQkFBaUIsa0JBQWtCLEtBQUs7Q0FDaEQsVUFBVSxZQUFZLEtBQUs7Q0FDM0IsT0FBTztBQUNUO0FBRUEsTUFBTSxvQkFBb0IsVUFBVTtDQUNsQyxNQUFNLEtBQUssTUFBTSxNQUFNLDBCQUEwQjtDQUNqRCxPQUFPLFFBQVEsRUFBRSxLQUFLLFVBQVUsZUFBZSxJQUFJLEtBQUssSUFBSTtBQUM5RDtBQUNBLFNBQVMsbUJBQW1CLEdBQUc7Q0FDN0IsRUFBRSxPQUFPLFlBQVk7QUFDdkI7QUFDQSxTQUFTLGlCQUFpQixHQUFHO0NBQzNCLE1BQU0sU0FBUyxFQUFFO0NBQ2pCLElBQUksT0FBTyxXQUFXO0VBQ3BCLE9BQU8sWUFBWTtFQUNuQixPQUFPLGNBQWMsSUFBSSxNQUFNLE9BQU8sQ0FBQztDQUN6QztBQUNGO0FBQ0EsTUFBTSxZQUE0Qix1QkFBTyxTQUFTO0FBQ2xELFNBQVMsVUFBVSxPQUFPLE1BQU0sUUFBUTtDQUN0QyxJQUFJLE1BQU0sUUFBUSxNQUFNLEtBQUs7Q0FDN0IsSUFBSSxRQUFRLFFBQVEsY0FBYyxLQUFLO0NBQ3ZDLE9BQU87QUFDVDtBQUNBLE1BQU0sYUFBYTtDQUNqQixRQUFRLElBQUksRUFBRSxXQUFXLEVBQUUsTUFBTSxNQUFNLFlBQVksT0FBTztFQUN4RCxHQUFHLGFBQWEsaUJBQWlCLEtBQUs7RUFDdEMsTUFBTSxlQUFlLFVBQVUsTUFBTSxTQUFTLE1BQU0sTUFBTSxTQUFTO0VBQ25FLGlCQUFpQixJQUFJLE9BQU8sV0FBVyxVQUFVLE1BQU07R0FDckQsSUFBSSxFQUFFLE9BQU8sV0FBVztHQUN4QixHQUFHLFVBQVUsQ0FBQyxVQUFVLEdBQUcsT0FBTyxNQUFNLFlBQVksQ0FBQztFQUN2RCxDQUFDO0VBQ0QsSUFBSSxRQUFRLGNBQWM7R0FDeEIsaUJBQWlCLElBQUksZ0JBQWdCO0lBQ25DLEdBQUcsUUFBUSxVQUFVLEdBQUcsT0FBTyxNQUFNLFlBQVk7R0FDbkQsQ0FBQztFQUNIO0VBQ0EsSUFBSSxDQUFDLE1BQU07R0FDVCxpQkFBaUIsSUFBSSxvQkFBb0Isa0JBQWtCO0dBQzNELGlCQUFpQixJQUFJLGtCQUFrQixnQkFBZ0I7R0FDdkQsaUJBQWlCLElBQUksVUFBVSxnQkFBZ0I7RUFDakQ7Q0FDRjs7Q0FFQSxRQUFRLElBQUksRUFBRSxTQUFTO0VBQ3JCLEdBQUcsUUFBUSxTQUFTLE9BQU8sS0FBSztDQUNsQztDQUNBLGFBQWEsSUFBSSxFQUFFLE9BQU8sVUFBVSxXQUFXLEVBQUUsTUFBTSxNQUFNLFlBQVksT0FBTztFQUM5RSxHQUFHLGFBQWEsaUJBQWlCLEtBQUs7RUFDdEMsSUFBSSxHQUFHLFdBQVc7RUFDbEIsTUFBTSxXQUFXLFVBQVUsR0FBRyxTQUFTLGFBQWEsQ0FBQyxPQUFPLEtBQUssR0FBRyxLQUFLLElBQUksY0FBYyxHQUFHLEtBQUssSUFBSSxHQUFHO0VBQzFHLE1BQU0sV0FBVyxTQUFTLE9BQU8sS0FBSztFQUN0QyxJQUFJLFlBQVksVUFBVTtHQUN4QjtFQUNGO0VBQ0EsTUFBTSxXQUFXLEdBQUcsWUFBWTtFQUNoQyxLQUFLLG9CQUFvQixZQUFZLG9CQUFvQixlQUFlLFNBQVMsa0JBQWtCLE1BQU0sR0FBRyxTQUFTLFNBQVM7R0FDNUgsSUFBSSxRQUFRLFVBQVUsVUFBVTtJQUM5QjtHQUNGO0dBQ0EsSUFBSSxRQUFRLEdBQUcsTUFBTSxLQUFLLE1BQU0sVUFBVTtJQUN4QztHQUNGO0VBQ0Y7RUFDQSxHQUFHLFFBQVE7Q0FDYjtBQUNGO0FBQ0EsTUFBTSxpQkFBaUI7O0NBRXJCLE1BQU07Q0FDTixRQUFRLElBQUksR0FBRyxPQUFPO0VBQ3BCLEdBQUcsYUFBYSxpQkFBaUIsS0FBSztFQUN0QyxpQkFBaUIsSUFBSSxnQkFBZ0I7R0FDbkMsTUFBTSxhQUFhLEdBQUc7R0FDdEIsTUFBTSxlQUFlLFNBQVMsRUFBRTtHQUNoQyxNQUFNLFVBQVUsR0FBRztHQUNuQixNQUFNLFNBQVMsR0FBRztHQUNsQixJQUFJLFFBQVEsVUFBVSxHQUFHO0lBQ3ZCLE1BQU0sUUFBUSxhQUFhLFlBQVksWUFBWTtJQUNuRCxNQUFNLFFBQVEsVUFBVSxDQUFDO0lBQ3pCLElBQUksV0FBVyxDQUFDLE9BQU87S0FDckIsT0FBTyxXQUFXLE9BQU8sWUFBWSxDQUFDO0lBQ3hDLE9BQU8sSUFBSSxDQUFDLFdBQVcsT0FBTztLQUM1QixNQUFNLFdBQVcsQ0FBQyxHQUFHLFVBQVU7S0FDL0IsU0FBUyxPQUFPLE9BQU8sQ0FBQztLQUN4QixPQUFPLFFBQVE7SUFDakI7R0FDRixPQUFPLElBQUksTUFBTSxVQUFVLEdBQUc7SUFDNUIsTUFBTSxTQUFTLElBQUksSUFBSSxVQUFVO0lBQ2pDLElBQUksU0FBUztLQUNYLE9BQU8sSUFBSSxZQUFZO0lBQ3pCLE9BQU87S0FDTCxPQUFPLE9BQU8sWUFBWTtJQUM1QjtJQUNBLE9BQU8sTUFBTTtHQUNmLE9BQU87SUFDTCxPQUFPLGlCQUFpQixJQUFJLE9BQU8sQ0FBQztHQUN0QztFQUNGLENBQUM7Q0FDSDs7Q0FFQSxTQUFTO0NBQ1QsYUFBYSxJQUFJLFNBQVMsT0FBTztFQUMvQixHQUFHLGFBQWEsaUJBQWlCLEtBQUs7RUFDdEMsV0FBVyxJQUFJLFNBQVMsS0FBSztDQUMvQjtBQUNGO0FBQ0EsU0FBUyxXQUFXLElBQUksRUFBRSxPQUFPLFlBQVksT0FBTztDQUNsRCxHQUFHLGNBQWM7Q0FDakIsSUFBSTtDQUNKLElBQUksUUFBUSxLQUFLLEdBQUc7RUFDbEIsVUFBVSxhQUFhLE9BQU8sTUFBTSxNQUFNLEtBQUssSUFBSSxDQUFDO0NBQ3RELE9BQU8sSUFBSSxNQUFNLEtBQUssR0FBRztFQUN2QixVQUFVLE1BQU0sSUFBSSxNQUFNLE1BQU0sS0FBSztDQUN2QyxPQUFPO0VBQ0wsSUFBSSxVQUFVLFVBQVU7RUFDeEIsVUFBVSxXQUFXLE9BQU8saUJBQWlCLElBQUksSUFBSSxDQUFDO0NBQ3hEO0NBQ0EsSUFBSSxHQUFHLFlBQVksU0FBUztFQUMxQixHQUFHLFVBQVU7Q0FDZjtBQUNGO0FBQ0EsTUFBTSxjQUFjO0NBQ2xCLFFBQVEsSUFBSSxFQUFFLFNBQVMsT0FBTztFQUM1QixHQUFHLFVBQVUsV0FBVyxPQUFPLE1BQU0sTUFBTSxLQUFLO0VBQ2hELEdBQUcsYUFBYSxpQkFBaUIsS0FBSztFQUN0QyxpQkFBaUIsSUFBSSxnQkFBZ0I7R0FDbkMsR0FBRyxVQUFVLENBQUMsU0FBUyxFQUFFLENBQUM7RUFDNUIsQ0FBQztDQUNIO0NBQ0EsYUFBYSxJQUFJLEVBQUUsT0FBTyxZQUFZLE9BQU87RUFDM0MsR0FBRyxhQUFhLGlCQUFpQixLQUFLO0VBQ3RDLElBQUksVUFBVSxVQUFVO0dBQ3RCLEdBQUcsVUFBVSxXQUFXLE9BQU8sTUFBTSxNQUFNLEtBQUs7RUFDbEQ7Q0FDRjtBQUNGO0FBQ0EsTUFBTSxlQUFlOztDQUVuQixNQUFNO0NBQ04sUUFBUSxJQUFJLEVBQUUsT0FBTyxXQUFXLEVBQUUsWUFBWSxPQUFPO0VBQ25ELEdBQUcsY0FBYztFQUNqQixpQkFBaUIsSUFBSSxnQkFBZ0I7R0FDbkMsTUFBTSxjQUFjLE1BQU0sVUFBVSxPQUFPLEtBQUssR0FBRyxVQUFVLE1BQU0sRUFBRSxRQUFRLENBQUMsQ0FBQyxLQUM1RSxNQUFNLFNBQVMsY0FBYyxTQUFTLENBQUMsQ0FBQyxJQUFJLFNBQVMsQ0FBQyxDQUN6RDtHQUNBLEdBQUcsVUFBVSxDQUNYLEdBQUcsV0FBVyxNQUFNLEdBQUcsV0FBVyxJQUFJLElBQUksSUFBSSxXQUFXLElBQUksY0FBYyxZQUFZLEVBQ3pGO0dBQ0EsR0FBRyxhQUFhO0dBQ2hCLGVBQWU7SUFDYixHQUFHLGFBQWE7R0FDbEIsQ0FBQztFQUNILENBQUM7RUFDRCxHQUFHLGFBQWEsaUJBQWlCLEtBQUs7Q0FDeEM7OztDQUdBLFFBQVEsSUFBSSxFQUFFLFNBQVM7RUFDckIsWUFBWSxJQUFJLEtBQUs7Q0FDdkI7Q0FDQSxhQUFhLElBQUksRUFBRSxTQUFTLE9BQU87RUFDakMsR0FBRyxjQUFjO0VBQ2pCLEdBQUcsYUFBYSxpQkFBaUIsS0FBSztDQUN4QztDQUNBLFFBQVEsSUFBSSxFQUFFLFNBQVM7RUFDckIsSUFBSSxDQUFDLEdBQUcsWUFBWTtHQUNsQixZQUFZLElBQUksS0FBSztFQUN2QjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLFlBQVksSUFBSSxPQUFPO0NBQzlCLE1BQU0sYUFBYSxHQUFHO0NBQ3RCLE1BQU0sZUFBZSxRQUFRLEtBQUs7Q0FDbEMsSUFBSSxjQUFjLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxLQUFLLEdBQUc7RUFDaEQsQ0FBQyxvQkFBMkIsaUJBQWlCLEtBQzNDLG9GQUFvRixPQUFPLFVBQVUsU0FBUyxLQUFLLEtBQUssQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsRUFBRSxFQUN6STtFQUNBO0NBQ0Y7Q0FDQSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksR0FBRyxRQUFRLFFBQVEsSUFBSSxHQUFHLEtBQUs7RUFDakQsTUFBTSxTQUFTLEdBQUcsUUFBUTtFQUMxQixNQUFNLGNBQWMsU0FBUyxNQUFNO0VBQ25DLElBQUksWUFBWTtHQUNkLElBQUksY0FBYztJQUNoQixNQUFNLGFBQWEsT0FBTztJQUMxQixJQUFJLGVBQWUsWUFBWSxlQUFlLFVBQVU7S0FDdEQsT0FBTyxXQUFXLE1BQU0sTUFBTSxNQUFNLE9BQU8sQ0FBQyxNQUFNLE9BQU8sV0FBVyxDQUFDO0lBQ3ZFLE9BQU87S0FDTCxPQUFPLFdBQVcsYUFBYSxPQUFPLFdBQVcsSUFBSSxDQUFDO0lBQ3hEO0dBQ0YsT0FBTztJQUNMLE9BQU8sV0FBVyxNQUFNLElBQUksV0FBVztHQUN6QztFQUNGLE9BQU8sSUFBSSxXQUFXLFNBQVMsTUFBTSxHQUFHLEtBQUssR0FBRztHQUM5QyxJQUFJLEdBQUcsa0JBQWtCLEdBQUcsR0FBRyxnQkFBZ0I7R0FDL0M7RUFDRjtDQUNGO0NBQ0EsSUFBSSxDQUFDLGNBQWMsR0FBRyxrQkFBa0IsQ0FBQyxHQUFHO0VBQzFDLEdBQUcsZ0JBQWdCLENBQUM7Q0FDdEI7QUFDRjtBQUNBLFNBQVMsU0FBUyxJQUFJO0NBQ3BCLE9BQU8sWUFBWSxLQUFLLEdBQUcsU0FBUyxHQUFHO0FBQ3pDO0FBQ0EsU0FBUyxpQkFBaUIsSUFBSSxTQUFTO0NBQ3JDLE1BQU0sTUFBTSxVQUFVLGVBQWU7Q0FDckMsT0FBTyxPQUFPLEtBQUssR0FBRyxPQUFPO0FBQy9CO0FBQ0EsTUFBTSxnQkFBZ0I7Q0FDcEIsUUFBUSxJQUFJLFNBQVMsT0FBTztFQUMxQixjQUFjLElBQUksU0FBUyxPQUFPLE1BQU0sU0FBUztDQUNuRDtDQUNBLFFBQVEsSUFBSSxTQUFTLE9BQU87RUFDMUIsY0FBYyxJQUFJLFNBQVMsT0FBTyxNQUFNLFNBQVM7Q0FDbkQ7Q0FDQSxhQUFhLElBQUksU0FBUyxPQUFPLFdBQVc7RUFDMUMsY0FBYyxJQUFJLFNBQVMsT0FBTyxXQUFXLGNBQWM7Q0FDN0Q7Q0FDQSxRQUFRLElBQUksU0FBUyxPQUFPLFdBQVc7RUFDckMsY0FBYyxJQUFJLFNBQVMsT0FBTyxXQUFXLFNBQVM7Q0FDeEQ7QUFDRjtBQUNBLFNBQVMsb0JBQW9CLFNBQVMsTUFBTTtDQUMxQyxRQUFRLFNBQVI7RUFDRSxLQUFLLFVBQ0gsT0FBTztFQUNULEtBQUssWUFDSCxPQUFPO0VBQ1QsU0FDRSxRQUFRLE1BQVI7R0FDRSxLQUFLLFlBQ0gsT0FBTztHQUNULEtBQUssU0FDSCxPQUFPO0dBQ1QsU0FDRSxPQUFPO0VBQ1g7Q0FDSjtBQUNGO0FBQ0EsU0FBUyxjQUFjLElBQUksU0FBUyxPQUFPLFdBQVcsTUFBTTtDQUMxRCxNQUFNLGFBQWEsb0JBQ2pCLEdBQUcsU0FDSCxNQUFNLFNBQVMsTUFBTSxNQUFNLElBQzdCO0NBQ0EsTUFBTSxLQUFLLFdBQVc7Q0FDdEIsTUFBTSxHQUFHLElBQUksU0FBUyxPQUFPLFNBQVM7QUFDeEM7QUFDQSxTQUFTLG1CQUFtQjtDQUMxQixXQUFXLGVBQWUsRUFBRSxhQUFhLEVBQUUsTUFBTTtDQUNqRCxZQUFZLGVBQWUsRUFBRSxTQUFTLFVBQVU7RUFDOUMsSUFBSSxNQUFNLFNBQVMsV0FBVyxNQUFNLE1BQU0sT0FBTyxLQUFLLEdBQUc7R0FDdkQsT0FBTyxFQUFFLFNBQVMsS0FBSztFQUN6QjtDQUNGO0NBQ0EsZUFBZSxlQUFlLEVBQUUsU0FBUyxVQUFVO0VBQ2pELElBQUksUUFBUSxLQUFLLEdBQUc7R0FDbEIsSUFBSSxNQUFNLFNBQVMsYUFBYSxPQUFPLE1BQU0sTUFBTSxLQUFLLElBQUksQ0FBQyxHQUFHO0lBQzlELE9BQU8sRUFBRSxTQUFTLEtBQUs7R0FDekI7RUFDRixPQUFPLElBQUksTUFBTSxLQUFLLEdBQUc7R0FDdkIsSUFBSSxNQUFNLFNBQVMsTUFBTSxJQUFJLE1BQU0sTUFBTSxLQUFLLEdBQUc7SUFDL0MsT0FBTyxFQUFFLFNBQVMsS0FBSztHQUN6QjtFQUNGLE9BQU8sSUFBSSxPQUFPO0dBQ2hCLE9BQU8sRUFBRSxTQUFTLEtBQUs7RUFDekI7Q0FDRjtDQUNBLGNBQWMsZUFBZSxTQUFTLFVBQVU7RUFDOUMsSUFBSSxPQUFPLE1BQU0sU0FBUyxVQUFVO0dBQ2xDO0VBQ0Y7RUFDQSxNQUFNLGFBQWE7O0dBRWpCLE1BQU0sS0FBSyxZQUFZO0dBQ3ZCLE1BQU0sU0FBUyxNQUFNLE1BQU07RUFDN0I7RUFDQSxJQUFJLFdBQVcsYUFBYTtHQUMxQixPQUFPLFdBQVcsWUFBWSxTQUFTLEtBQUs7RUFDOUM7Q0FDRjtBQUNGO0FBRUEsTUFBTSxrQkFBa0I7Q0FBQztDQUFRO0NBQVM7Q0FBTztBQUFNO0FBQ3ZELE1BQU0saUJBQWlCO0NBQ3JCLE9BQU8sTUFBTSxFQUFFLGdCQUFnQjtDQUMvQixVQUFVLE1BQU0sRUFBRSxlQUFlO0NBQ2pDLE9BQU8sTUFBTSxFQUFFLFdBQVcsRUFBRTtDQUM1QixPQUFPLE1BQU0sQ0FBQyxFQUFFO0NBQ2hCLFFBQVEsTUFBTSxDQUFDLEVBQUU7Q0FDakIsTUFBTSxNQUFNLENBQUMsRUFBRTtDQUNmLE9BQU8sTUFBTSxDQUFDLEVBQUU7Q0FDaEIsT0FBTyxNQUFNLFlBQVksS0FBSyxFQUFFLFdBQVc7Q0FDM0MsU0FBUyxNQUFNLFlBQVksS0FBSyxFQUFFLFdBQVc7Q0FDN0MsUUFBUSxNQUFNLFlBQVksS0FBSyxFQUFFLFdBQVc7Q0FDNUMsUUFBUSxHQUFHLGNBQWMsZ0JBQWdCLE1BQU0sTUFBTSxFQUFFLEdBQUcsRUFBRSxTQUFTLENBQUMsVUFBVSxTQUFTLENBQUMsQ0FBQztBQUM3RjtBQUNBLE1BQU0saUJBQWlCLElBQUksY0FBYztDQUN2QyxJQUFJLENBQUMsSUFBSSxPQUFPO0NBQ2hCLE1BQU0sUUFBUSxHQUFHLGNBQWMsR0FBRyxZQUFZLENBQUM7Q0FDL0MsTUFBTSxXQUFXLFVBQVUsS0FBSyxHQUFHO0NBQ25DLE9BQU8sTUFBTSxjQUFjLE1BQU0sY0FBYyxPQUFPLEdBQUcsU0FBUztFQUNoRSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxRQUFRLEtBQUs7R0FDekMsTUFBTSxRQUFRLGVBQWUsVUFBVTtHQUN2QyxJQUFJLFNBQVMsTUFBTSxPQUFPLFNBQVMsR0FBRztFQUN4QztFQUNBLE9BQU8sR0FBRyxPQUFPLEdBQUcsSUFBSTtDQUMxQjtBQUNGO0FBQ0EsTUFBTSxXQUFXO0NBQ2YsS0FBSztDQUNMLE9BQU87Q0FDUCxJQUFJO0NBQ0osTUFBTTtDQUNOLE9BQU87Q0FDUCxNQUFNO0NBQ04sUUFBUTtBQUNWO0FBQ0EsTUFBTSxZQUFZLElBQUksY0FBYztDQUNsQyxNQUFNLFFBQVEsR0FBRyxjQUFjLEdBQUcsWUFBWSxDQUFDO0NBQy9DLE1BQU0sV0FBVyxVQUFVLEtBQUssR0FBRztDQUNuQyxPQUFPLE1BQU0sY0FBYyxNQUFNLGNBQWMsVUFBVTtFQUN2RCxJQUFJLEVBQUUsU0FBUyxRQUFRO0dBQ3JCO0VBQ0Y7RUFDQSxNQUFNLFdBQVcsVUFBVSxNQUFNLEdBQUc7RUFDcEMsSUFBSSxVQUFVLE1BQ1gsTUFBTSxNQUFNLFlBQVksU0FBUyxPQUFPLFFBQzNDLEdBQUc7R0FDRCxPQUFPLEdBQUcsS0FBSztFQUNqQjtDQUNGO0FBQ0Y7QUFFQSxNQUFNLGtCQUFrQyx1QkFBTyxFQUFFLFVBQVUsR0FBRyxPQUFPO0FBQ3JFLElBQUk7QUFDSixJQUFJLG1CQUFtQjtBQUN2QixTQUFTLGlCQUFpQjtDQUN4QixPQUFPLGFBQWEsV0FBVyxlQUFlLGVBQWU7QUFDL0Q7QUFDQSxTQUFTLDBCQUEwQjtDQUNqQyxXQUFXLG1CQUFtQixXQUFXLHdCQUF3QixlQUFlO0NBQ2hGLG1CQUFtQjtDQUNuQixPQUFPO0FBQ1Q7QUFDQSxNQUFNLFdBQVcsR0FBRyxTQUFTO0NBQzNCLGVBQWUsQ0FBQyxDQUFDLE9BQU8sR0FBRyxJQUFJO0FBQ2pDO0FBQ0EsTUFBTSxZQUFZLEdBQUcsU0FBUztDQUM1Qix3QkFBd0IsQ0FBQyxDQUFDLFFBQVEsR0FBRyxJQUFJO0FBQzNDO0FBQ0EsTUFBTSxjQUFjLEdBQUcsU0FBUztDQUM5QixNQUFNLE1BQU0sZUFBZSxDQUFDLENBQUMsVUFBVSxHQUFHLElBQUk7Q0FDOUMsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0VBQzdDLHFCQUFxQixHQUFHO0VBQ3hCLDJCQUEyQixHQUFHO0NBQ2hDO0NBQ0EsTUFBTSxFQUFFLFVBQVU7Q0FDbEIsSUFBSSxTQUFTLHdCQUF3QjtFQUNuQyxNQUFNLFlBQVksbUJBQW1CLG1CQUFtQjtFQUN4RCxJQUFJLENBQUMsV0FBVztFQUNoQixNQUFNLFlBQVksSUFBSTtFQUN0QixJQUFJLENBQUMsV0FBVyxTQUFTLEtBQUssQ0FBQyxVQUFVLFVBQVUsQ0FBQyxVQUFVLFVBQVU7R0FDdEUsVUFBVSxXQUFXLFVBQVU7RUFDakM7RUFDQSxJQUFJLFVBQVUsYUFBYSxHQUFHO0dBQzVCLFVBQVUsY0FBYztFQUMxQjtFQUNBLE1BQU0sUUFBUSxNQUFNLFdBQVcsT0FBTyxxQkFBcUIsU0FBUyxDQUFDO0VBQ3JFLElBQUkscUJBQXFCLFNBQVM7R0FDaEMsVUFBVSxnQkFBZ0IsU0FBUztHQUNuQyxVQUFVLGFBQWEsY0FBYyxFQUFFO0VBQ3pDO0VBQ0EsT0FBTztDQUNUO0NBQ0EsT0FBTztBQUNUO0FBQ0EsTUFBTSxpQkFBaUIsR0FBRyxTQUFTO0NBQ2pDLE1BQU0sTUFBTSx3QkFBd0IsQ0FBQyxDQUFDLFVBQVUsR0FBRyxJQUFJO0NBQ3ZELElBQUksQ0FBQyxvQkFBMkIsZUFBZTtFQUM3QyxxQkFBcUIsR0FBRztFQUN4QiwyQkFBMkIsR0FBRztDQUNoQztDQUNBLE1BQU0sRUFBRSxVQUFVO0NBQ2xCLElBQUksU0FBUyx3QkFBd0I7RUFDbkMsTUFBTSxZQUFZLG1CQUFtQixtQkFBbUI7RUFDeEQsSUFBSSxXQUFXO0dBQ2IsT0FBTyxNQUFNLFdBQVcsTUFBTSxxQkFBcUIsU0FBUyxDQUFDO0VBQy9EO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLHFCQUFxQixXQUFXO0NBQ3ZDLElBQUkscUJBQXFCLFlBQVk7RUFDbkMsT0FBTztDQUNUO0NBQ0EsSUFBSSxPQUFPLGtCQUFrQixjQUFjLHFCQUFxQixlQUFlO0VBQzdFLE9BQU87Q0FDVDtBQUNGO0FBQ0EsU0FBUyxxQkFBcUIsS0FBSztDQUNqQyxPQUFPLGVBQWUsSUFBSSxRQUFRLGVBQWU7RUFDL0MsUUFBUSxRQUFRLFVBQVUsR0FBRyxLQUFLLFNBQVMsR0FBRyxLQUFLLFlBQVksR0FBRztFQUNsRSxVQUFVO0NBQ1osQ0FBQztBQUNIO0FBQ0EsU0FBUywyQkFBMkIsS0FBSztDQUN2QyxJQUFJLGNBQWMsR0FBRztFQUNuQixNQUFNLGtCQUFrQixJQUFJLE9BQU87RUFDbkMsT0FBTyxlQUFlLElBQUksUUFBUSxtQkFBbUI7R0FDbkQsTUFBTTtJQUNKLE9BQU87R0FDVDtHQUNBLE1BQU07SUFDSixLQUNFLHVHQUNGO0dBQ0Y7RUFDRixDQUFDO0VBQ0QsTUFBTSxrQkFBa0IsSUFBSSxPQUFPO0VBQ25DLE1BQU0sTUFBTTs7OztFQUlaLE9BQU8sZUFBZSxJQUFJLFFBQVEsbUJBQW1CO0dBQ25ELE1BQU07SUFDSixLQUFLLEdBQUc7SUFDUixPQUFPO0dBQ1Q7R0FDQSxNQUFNO0lBQ0osS0FBSyxHQUFHO0dBQ1Y7RUFDRixDQUFDO0NBQ0g7QUFDRjtBQUNBLFNBQVMsbUJBQW1CLFdBQVc7Q0FDckMsSUFBSSxTQUFTLFNBQVMsR0FBRztFQUN2QixNQUFNLE1BQU0sU0FBUyxjQUFjLFNBQVM7RUFDNUMsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsQ0FBQyxLQUFLO0dBQ3JELEtBQ0UsK0NBQStDLFVBQVUsaUJBQzNEO0VBQ0Y7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixPQUFPLGNBQWMscUJBQXFCLE9BQU8sY0FBYyxVQUFVLFNBQVMsVUFBVTtFQUMzSSxLQUNFLG1GQUNGO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxJQUFJLDBCQUEwQjtBQUM5QixNQUFNLDZCQUE2QjtDQUNqQyxJQUFJLENBQUMseUJBQXlCO0VBQzVCLDBCQUEwQjtFQUMxQixpQkFBaUI7RUFDakIsZ0JBQWdCO0NBQ2xCO0FBQ0Y7QUFFQSxTQUFTLFlBQVksaUJBQWlCLFlBQVksV0FBVyxjQUFjLHFCQUFxQix3QkFBd0IsU0FBUyxzQkFBc0IsU0FBUyxXQUFXLFFBQVEsY0FBYyxZQUFZLFNBQVMsZUFBZSxnQkFBZ0IsZUFBZSxhQUFhLGNBQWMsWUFBWSxPQUFPLFVBQVUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsicnVudGltZS1kb20uZXNtLWJ1bmRsZXIuanM/dj03ZTczYWZjMiJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiogQHZ1ZS9ydW50aW1lLWRvbSB2My41LjQwXG4qIChjKSAyMDE4LXByZXNlbnQgWXV4aSAoRXZhbikgWW91IGFuZCBWdWUgY29udHJpYnV0b3JzXG4qIEBsaWNlbnNlIE1JVFxuKiovXG5pbXBvcnQgeyB3YXJuLCBCYXNlVHJhbnNpdGlvblByb3BzVmFsaWRhdG9ycywgaCwgQmFzZVRyYW5zaXRpb24sIGFzc2VydE51bWJlciwgZ2V0Q3VycmVudEluc3RhbmNlLCBvbkJlZm9yZVVwZGF0ZSwgcXVldWVQb3N0Rmx1c2hDYiwgb25Nb3VudGVkLCB3YXRjaCwgb25Vbm1vdW50ZWQsIEZyYWdtZW50LCBTdGF0aWMsIGNhbWVsaXplLCBjYWxsV2l0aEFzeW5jRXJyb3JIYW5kbGluZywgbmV4dFRpY2ssIHVucmVmLCBjcmVhdGVWTm9kZSwgZGVmaW5lQ29tcG9uZW50LCB1c2VUcmFuc2l0aW9uU3RhdGUsIG9uVXBkYXRlZCwgdG9SYXcsIGdldFRyYW5zaXRpb25SYXdDaGlsZHJlbiwgc2V0VHJhbnNpdGlvbkhvb2tzLCByZXNvbHZlVHJhbnNpdGlvbkhvb2tzLCBUZXh0LCBjcmVhdGVSZW5kZXJlciwgaXNSdW50aW1lT25seSwgY3JlYXRlSHlkcmF0aW9uUmVuZGVyZXIgfSBmcm9tICdAdnVlL3J1bnRpbWUtY29yZSc7XG5leHBvcnQgKiBmcm9tICdAdnVlL3J1bnRpbWUtY29yZSc7XG5pbXBvcnQgeyBleHRlbmQsIGlzT2JqZWN0LCB0b051bWJlciwgaXNBcnJheSwgTk9PUCwgbm9ybWFsaXplQ3NzVmFyVmFsdWUsIGlzU3RyaW5nLCBoeXBoZW5hdGUsIGNhcGl0YWxpemUsIGluY2x1ZGVCb29sZWFuQXR0ciwgaXNTeW1ib2wsIGlzU3BlY2lhbEJvb2xlYW5BdHRyLCBpc0Z1bmN0aW9uLCBpc09uLCBpc01vZGVsTGlzdGVuZXIsIGNhbWVsaXplIGFzIGNhbWVsaXplJDEsIGhhc093biwgaXNQbGFpbk9iamVjdCwgRU1QVFlfT0JKLCBsb29zZUluZGV4T2YsIGlzU2V0LCBsb29zZUVxdWFsLCBsb29zZVRvTnVtYmVyLCBpbnZva2VBcnJheUZucywgaXNIVE1MVGFnLCBpc1NWR1RhZywgaXNNYXRoTUxUYWcgfSBmcm9tICdAdnVlL3NoYXJlZCc7XG5cbmxldCBwb2xpY3kgPSB2b2lkIDA7XG5jb25zdCB0dCA9IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgJiYgd2luZG93LnRydXN0ZWRUeXBlcztcbmlmICh0dCkge1xuICB0cnkge1xuICAgIHBvbGljeSA9IC8qIEBfX1BVUkVfXyAqLyB0dC5jcmVhdGVQb2xpY3koXCJ2dWVcIiwge1xuICAgICAgY3JlYXRlSFRNTDogKHZhbCkgPT4gdmFsXG4gICAgfSk7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdhcm4oYEVycm9yIGNyZWF0aW5nIHRydXN0ZWQgdHlwZXMgcG9saWN5OiAke2V9YCk7XG4gIH1cbn1cbmNvbnN0IHVuc2FmZVRvVHJ1c3RlZEhUTUwgPSBwb2xpY3kgPyAodmFsKSA9PiBwb2xpY3kuY3JlYXRlSFRNTCh2YWwpIDogKHZhbCkgPT4gdmFsO1xuY29uc3Qgc3ZnTlMgPSBcImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCI7XG5jb25zdCBtYXRobWxOUyA9IFwiaHR0cDovL3d3dy53My5vcmcvMTk5OC9NYXRoL01hdGhNTFwiO1xuY29uc3QgZG9jID0gdHlwZW9mIGRvY3VtZW50ICE9PSBcInVuZGVmaW5lZFwiID8gZG9jdW1lbnQgOiBudWxsO1xuY29uc3QgdGVtcGxhdGVDb250YWluZXIgPSBkb2MgJiYgLyogQF9fUFVSRV9fICovIGRvYy5jcmVhdGVFbGVtZW50KFwidGVtcGxhdGVcIik7XG5jb25zdCBub2RlT3BzID0ge1xuICBpbnNlcnQ6IChjaGlsZCwgcGFyZW50LCBhbmNob3IpID0+IHtcbiAgICBwYXJlbnQuaW5zZXJ0QmVmb3JlKGNoaWxkLCBhbmNob3IgfHwgbnVsbCk7XG4gIH0sXG4gIHJlbW92ZTogKGNoaWxkKSA9PiB7XG4gICAgY29uc3QgcGFyZW50ID0gY2hpbGQucGFyZW50Tm9kZTtcbiAgICBpZiAocGFyZW50KSB7XG4gICAgICBwYXJlbnQucmVtb3ZlQ2hpbGQoY2hpbGQpO1xuICAgIH1cbiAgfSxcbiAgY3JlYXRlRWxlbWVudDogKHRhZywgbmFtZXNwYWNlLCBpcywgcHJvcHMpID0+IHtcbiAgICBjb25zdCBlbCA9IG5hbWVzcGFjZSA9PT0gXCJzdmdcIiA/IGRvYy5jcmVhdGVFbGVtZW50TlMoc3ZnTlMsIHRhZykgOiBuYW1lc3BhY2UgPT09IFwibWF0aG1sXCIgPyBkb2MuY3JlYXRlRWxlbWVudE5TKG1hdGhtbE5TLCB0YWcpIDogaXMgPyBkb2MuY3JlYXRlRWxlbWVudCh0YWcsIHsgaXMgfSkgOiBkb2MuY3JlYXRlRWxlbWVudCh0YWcpO1xuICAgIGlmICh0YWcgPT09IFwic2VsZWN0XCIgJiYgcHJvcHMgJiYgcHJvcHMubXVsdGlwbGUgIT0gbnVsbCkge1xuICAgICAgZWwuc2V0QXR0cmlidXRlKFwibXVsdGlwbGVcIiwgcHJvcHMubXVsdGlwbGUpO1xuICAgIH1cbiAgICByZXR1cm4gZWw7XG4gIH0sXG4gIGNyZWF0ZVRleHQ6ICh0ZXh0KSA9PiBkb2MuY3JlYXRlVGV4dE5vZGUodGV4dCksXG4gIGNyZWF0ZUNvbW1lbnQ6ICh0ZXh0KSA9PiBkb2MuY3JlYXRlQ29tbWVudCh0ZXh0KSxcbiAgc2V0VGV4dDogKG5vZGUsIHRleHQpID0+IHtcbiAgICBub2RlLm5vZGVWYWx1ZSA9IHRleHQ7XG4gIH0sXG4gIHNldEVsZW1lbnRUZXh0OiAoZWwsIHRleHQpID0+IHtcbiAgICBlbC50ZXh0Q29udGVudCA9IHRleHQ7XG4gIH0sXG4gIHBhcmVudE5vZGU6IChub2RlKSA9PiBub2RlLnBhcmVudE5vZGUsXG4gIG5leHRTaWJsaW5nOiAobm9kZSkgPT4gbm9kZS5uZXh0U2libGluZyxcbiAgcXVlcnlTZWxlY3RvcjogKHNlbGVjdG9yKSA9PiBkb2MucXVlcnlTZWxlY3RvcihzZWxlY3RvciksXG4gIHNldFNjb3BlSWQoZWwsIGlkKSB7XG4gICAgZWwuc2V0QXR0cmlidXRlKGlkLCBcIlwiKTtcbiAgfSxcbiAgLy8gX19VTlNBRkVfX1xuICAvLyBSZWFzb246IGlubmVySFRNTC5cbiAgLy8gU3RhdGljIGNvbnRlbnQgaGVyZSBjYW4gb25seSBjb21lIGZyb20gY29tcGlsZWQgdGVtcGxhdGVzLlxuICAvLyBBcyBsb25nIGFzIHRoZSB1c2VyIG9ubHkgdXNlcyB0cnVzdGVkIHRlbXBsYXRlcywgdGhpcyBpcyBzYWZlLlxuICBpbnNlcnRTdGF0aWNDb250ZW50KGNvbnRlbnQsIHBhcmVudCwgYW5jaG9yLCBuYW1lc3BhY2UsIHN0YXJ0LCBlbmQpIHtcbiAgICBjb25zdCBiZWZvcmUgPSBhbmNob3IgPyBhbmNob3IucHJldmlvdXNTaWJsaW5nIDogcGFyZW50Lmxhc3RDaGlsZDtcbiAgICBpZiAoc3RhcnQgJiYgKHN0YXJ0ID09PSBlbmQgfHwgc3RhcnQubmV4dFNpYmxpbmcpKSB7XG4gICAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgICBwYXJlbnQuaW5zZXJ0QmVmb3JlKHN0YXJ0LmNsb25lTm9kZSh0cnVlKSwgYW5jaG9yKTtcbiAgICAgICAgaWYgKHN0YXJ0ID09PSBlbmQgfHwgIShzdGFydCA9IHN0YXJ0Lm5leHRTaWJsaW5nKSkgYnJlYWs7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHRlbXBsYXRlQ29udGFpbmVyLmlubmVySFRNTCA9IHVuc2FmZVRvVHJ1c3RlZEhUTUwoXG4gICAgICAgIG5hbWVzcGFjZSA9PT0gXCJzdmdcIiA/IGA8c3ZnPiR7Y29udGVudH08L3N2Zz5gIDogbmFtZXNwYWNlID09PSBcIm1hdGhtbFwiID8gYDxtYXRoPiR7Y29udGVudH08L21hdGg+YCA6IGNvbnRlbnRcbiAgICAgICk7XG4gICAgICBjb25zdCB0ZW1wbGF0ZSA9IHRlbXBsYXRlQ29udGFpbmVyLmNvbnRlbnQ7XG4gICAgICBpZiAobmFtZXNwYWNlID09PSBcInN2Z1wiIHx8IG5hbWVzcGFjZSA9PT0gXCJtYXRobWxcIikge1xuICAgICAgICBjb25zdCB3cmFwcGVyID0gdGVtcGxhdGUuZmlyc3RDaGlsZDtcbiAgICAgICAgd2hpbGUgKHdyYXBwZXIuZmlyc3RDaGlsZCkge1xuICAgICAgICAgIHRlbXBsYXRlLmFwcGVuZENoaWxkKHdyYXBwZXIuZmlyc3RDaGlsZCk7XG4gICAgICAgIH1cbiAgICAgICAgdGVtcGxhdGUucmVtb3ZlQ2hpbGQod3JhcHBlcik7XG4gICAgICB9XG4gICAgICBwYXJlbnQuaW5zZXJ0QmVmb3JlKHRlbXBsYXRlLCBhbmNob3IpO1xuICAgIH1cbiAgICByZXR1cm4gW1xuICAgICAgLy8gZmlyc3RcbiAgICAgIGJlZm9yZSA/IGJlZm9yZS5uZXh0U2libGluZyA6IHBhcmVudC5maXJzdENoaWxkLFxuICAgICAgLy8gbGFzdFxuICAgICAgYW5jaG9yID8gYW5jaG9yLnByZXZpb3VzU2libGluZyA6IHBhcmVudC5sYXN0Q2hpbGRcbiAgICBdO1xuICB9XG59O1xuXG5jb25zdCBUUkFOU0lUSU9OID0gXCJ0cmFuc2l0aW9uXCI7XG5jb25zdCBBTklNQVRJT04gPSBcImFuaW1hdGlvblwiO1xuY29uc3QgdnRjS2V5ID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcIl92dGNcIik7XG5jb25zdCBET01UcmFuc2l0aW9uUHJvcHNWYWxpZGF0b3JzID0ge1xuICBuYW1lOiBTdHJpbmcsXG4gIHR5cGU6IFN0cmluZyxcbiAgY3NzOiB7XG4gICAgdHlwZTogQm9vbGVhbixcbiAgICBkZWZhdWx0OiB0cnVlXG4gIH0sXG4gIGR1cmF0aW9uOiBbU3RyaW5nLCBOdW1iZXIsIE9iamVjdF0sXG4gIGVudGVyRnJvbUNsYXNzOiBTdHJpbmcsXG4gIGVudGVyQWN0aXZlQ2xhc3M6IFN0cmluZyxcbiAgZW50ZXJUb0NsYXNzOiBTdHJpbmcsXG4gIGFwcGVhckZyb21DbGFzczogU3RyaW5nLFxuICBhcHBlYXJBY3RpdmVDbGFzczogU3RyaW5nLFxuICBhcHBlYXJUb0NsYXNzOiBTdHJpbmcsXG4gIGxlYXZlRnJvbUNsYXNzOiBTdHJpbmcsXG4gIGxlYXZlQWN0aXZlQ2xhc3M6IFN0cmluZyxcbiAgbGVhdmVUb0NsYXNzOiBTdHJpbmdcbn07XG5jb25zdCBUcmFuc2l0aW9uUHJvcHNWYWxpZGF0b3JzID0gLyogQF9fUFVSRV9fICovIGV4dGVuZChcbiAge30sXG4gIEJhc2VUcmFuc2l0aW9uUHJvcHNWYWxpZGF0b3JzLFxuICBET01UcmFuc2l0aW9uUHJvcHNWYWxpZGF0b3JzXG4pO1xuY29uc3QgZGVjb3JhdGUkMSA9ICh0KSA9PiB7XG4gIHQuZGlzcGxheU5hbWUgPSBcIlRyYW5zaXRpb25cIjtcbiAgdC5wcm9wcyA9IFRyYW5zaXRpb25Qcm9wc1ZhbGlkYXRvcnM7XG4gIHJldHVybiB0O1xufTtcbmNvbnN0IFRyYW5zaXRpb24gPSAvKiBAX19QVVJFX18gKi8gZGVjb3JhdGUkMShcbiAgKHByb3BzLCB7IHNsb3RzIH0pID0+IGgoQmFzZVRyYW5zaXRpb24sIHJlc29sdmVUcmFuc2l0aW9uUHJvcHMocHJvcHMpLCBzbG90cylcbik7XG5jb25zdCBjYWxsSG9vayA9IChob29rLCBhcmdzID0gW10pID0+IHtcbiAgaWYgKGlzQXJyYXkoaG9vaykpIHtcbiAgICBob29rLmZvckVhY2goKGgyKSA9PiBoMiguLi5hcmdzKSk7XG4gIH0gZWxzZSBpZiAoaG9vaykge1xuICAgIGhvb2soLi4uYXJncyk7XG4gIH1cbn07XG5jb25zdCBoYXNFeHBsaWNpdENhbGxiYWNrID0gKGhvb2spID0+IHtcbiAgcmV0dXJuIGhvb2sgPyBpc0FycmF5KGhvb2spID8gaG9vay5zb21lKChoMikgPT4gaDIubGVuZ3RoID4gMSkgOiBob29rLmxlbmd0aCA+IDEgOiBmYWxzZTtcbn07XG5mdW5jdGlvbiByZXNvbHZlVHJhbnNpdGlvblByb3BzKHJhd1Byb3BzKSB7XG4gIGNvbnN0IGJhc2VQcm9wcyA9IHt9O1xuICBmb3IgKGNvbnN0IGtleSBpbiByYXdQcm9wcykge1xuICAgIGlmICghKGtleSBpbiBET01UcmFuc2l0aW9uUHJvcHNWYWxpZGF0b3JzKSkge1xuICAgICAgYmFzZVByb3BzW2tleV0gPSByYXdQcm9wc1trZXldO1xuICAgIH1cbiAgfVxuICBpZiAocmF3UHJvcHMuY3NzID09PSBmYWxzZSkge1xuICAgIHJldHVybiBiYXNlUHJvcHM7XG4gIH1cbiAgY29uc3Qge1xuICAgIG5hbWUgPSBcInZcIixcbiAgICB0eXBlLFxuICAgIGR1cmF0aW9uLFxuICAgIGVudGVyRnJvbUNsYXNzID0gYCR7bmFtZX0tZW50ZXItZnJvbWAsXG4gICAgZW50ZXJBY3RpdmVDbGFzcyA9IGAke25hbWV9LWVudGVyLWFjdGl2ZWAsXG4gICAgZW50ZXJUb0NsYXNzID0gYCR7bmFtZX0tZW50ZXItdG9gLFxuICAgIGFwcGVhckZyb21DbGFzcyA9IGVudGVyRnJvbUNsYXNzLFxuICAgIGFwcGVhckFjdGl2ZUNsYXNzID0gZW50ZXJBY3RpdmVDbGFzcyxcbiAgICBhcHBlYXJUb0NsYXNzID0gZW50ZXJUb0NsYXNzLFxuICAgIGxlYXZlRnJvbUNsYXNzID0gYCR7bmFtZX0tbGVhdmUtZnJvbWAsXG4gICAgbGVhdmVBY3RpdmVDbGFzcyA9IGAke25hbWV9LWxlYXZlLWFjdGl2ZWAsXG4gICAgbGVhdmVUb0NsYXNzID0gYCR7bmFtZX0tbGVhdmUtdG9gXG4gIH0gPSByYXdQcm9wcztcbiAgY29uc3QgZHVyYXRpb25zID0gbm9ybWFsaXplRHVyYXRpb24oZHVyYXRpb24pO1xuICBjb25zdCBlbnRlckR1cmF0aW9uID0gZHVyYXRpb25zICYmIGR1cmF0aW9uc1swXTtcbiAgY29uc3QgbGVhdmVEdXJhdGlvbiA9IGR1cmF0aW9ucyAmJiBkdXJhdGlvbnNbMV07XG4gIGNvbnN0IHtcbiAgICBvbkJlZm9yZUVudGVyLFxuICAgIG9uRW50ZXIsXG4gICAgb25FbnRlckNhbmNlbGxlZCxcbiAgICBvbkxlYXZlLFxuICAgIG9uTGVhdmVDYW5jZWxsZWQsXG4gICAgb25CZWZvcmVBcHBlYXIgPSBvbkJlZm9yZUVudGVyLFxuICAgIG9uQXBwZWFyID0gb25FbnRlcixcbiAgICBvbkFwcGVhckNhbmNlbGxlZCA9IG9uRW50ZXJDYW5jZWxsZWRcbiAgfSA9IGJhc2VQcm9wcztcbiAgY29uc3QgZmluaXNoRW50ZXIgPSAoZWwsIGlzQXBwZWFyLCBkb25lLCBpc0NhbmNlbGxlZCkgPT4ge1xuICAgIGVsLl9lbnRlckNhbmNlbGxlZCA9IGlzQ2FuY2VsbGVkO1xuICAgIHJlbW92ZVRyYW5zaXRpb25DbGFzcyhlbCwgaXNBcHBlYXIgPyBhcHBlYXJUb0NsYXNzIDogZW50ZXJUb0NsYXNzKTtcbiAgICByZW1vdmVUcmFuc2l0aW9uQ2xhc3MoZWwsIGlzQXBwZWFyID8gYXBwZWFyQWN0aXZlQ2xhc3MgOiBlbnRlckFjdGl2ZUNsYXNzKTtcbiAgICBkb25lICYmIGRvbmUoKTtcbiAgfTtcbiAgY29uc3QgZmluaXNoTGVhdmUgPSAoZWwsIGRvbmUpID0+IHtcbiAgICBlbC5faXNMZWF2aW5nID0gZmFsc2U7XG4gICAgcmVtb3ZlVHJhbnNpdGlvbkNsYXNzKGVsLCBsZWF2ZUZyb21DbGFzcyk7XG4gICAgcmVtb3ZlVHJhbnNpdGlvbkNsYXNzKGVsLCBsZWF2ZVRvQ2xhc3MpO1xuICAgIHJlbW92ZVRyYW5zaXRpb25DbGFzcyhlbCwgbGVhdmVBY3RpdmVDbGFzcyk7XG4gICAgZG9uZSAmJiBkb25lKCk7XG4gIH07XG4gIGNvbnN0IG1ha2VFbnRlckhvb2sgPSAoaXNBcHBlYXIpID0+IHtcbiAgICByZXR1cm4gKGVsLCBkb25lKSA9PiB7XG4gICAgICBjb25zdCBob29rID0gaXNBcHBlYXIgPyBvbkFwcGVhciA6IG9uRW50ZXI7XG4gICAgICBjb25zdCByZXNvbHZlID0gKCkgPT4gZmluaXNoRW50ZXIoZWwsIGlzQXBwZWFyLCBkb25lKTtcbiAgICAgIGNhbGxIb29rKGhvb2ssIFtlbCwgcmVzb2x2ZV0pO1xuICAgICAgbmV4dEZyYW1lKCgpID0+IHtcbiAgICAgICAgcmVtb3ZlVHJhbnNpdGlvbkNsYXNzKGVsLCBpc0FwcGVhciA/IGFwcGVhckZyb21DbGFzcyA6IGVudGVyRnJvbUNsYXNzKTtcbiAgICAgICAgYWRkVHJhbnNpdGlvbkNsYXNzKGVsLCBpc0FwcGVhciA/IGFwcGVhclRvQ2xhc3MgOiBlbnRlclRvQ2xhc3MpO1xuICAgICAgICBpZiAoIWhhc0V4cGxpY2l0Q2FsbGJhY2soaG9vaykpIHtcbiAgICAgICAgICB3aGVuVHJhbnNpdGlvbkVuZHMoZWwsIHR5cGUsIGVudGVyRHVyYXRpb24sIHJlc29sdmUpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9O1xuICB9O1xuICByZXR1cm4gZXh0ZW5kKGJhc2VQcm9wcywge1xuICAgIG9uQmVmb3JlRW50ZXIoZWwpIHtcbiAgICAgIGNhbGxIb29rKG9uQmVmb3JlRW50ZXIsIFtlbF0pO1xuICAgICAgYWRkVHJhbnNpdGlvbkNsYXNzKGVsLCBlbnRlckZyb21DbGFzcyk7XG4gICAgICBhZGRUcmFuc2l0aW9uQ2xhc3MoZWwsIGVudGVyQWN0aXZlQ2xhc3MpO1xuICAgIH0sXG4gICAgb25CZWZvcmVBcHBlYXIoZWwpIHtcbiAgICAgIGNhbGxIb29rKG9uQmVmb3JlQXBwZWFyLCBbZWxdKTtcbiAgICAgIGFkZFRyYW5zaXRpb25DbGFzcyhlbCwgYXBwZWFyRnJvbUNsYXNzKTtcbiAgICAgIGFkZFRyYW5zaXRpb25DbGFzcyhlbCwgYXBwZWFyQWN0aXZlQ2xhc3MpO1xuICAgIH0sXG4gICAgb25FbnRlcjogbWFrZUVudGVySG9vayhmYWxzZSksXG4gICAgb25BcHBlYXI6IG1ha2VFbnRlckhvb2sodHJ1ZSksXG4gICAgb25MZWF2ZShlbCwgZG9uZSkge1xuICAgICAgZWwuX2lzTGVhdmluZyA9IHRydWU7XG4gICAgICBjb25zdCByZXNvbHZlID0gKCkgPT4gZmluaXNoTGVhdmUoZWwsIGRvbmUpO1xuICAgICAgYWRkVHJhbnNpdGlvbkNsYXNzKGVsLCBsZWF2ZUZyb21DbGFzcyk7XG4gICAgICBpZiAoIWVsLl9lbnRlckNhbmNlbGxlZCkge1xuICAgICAgICBmb3JjZVJlZmxvdyhlbCk7XG4gICAgICAgIGFkZFRyYW5zaXRpb25DbGFzcyhlbCwgbGVhdmVBY3RpdmVDbGFzcyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhZGRUcmFuc2l0aW9uQ2xhc3MoZWwsIGxlYXZlQWN0aXZlQ2xhc3MpO1xuICAgICAgICBmb3JjZVJlZmxvdyhlbCk7XG4gICAgICB9XG4gICAgICBuZXh0RnJhbWUoKCkgPT4ge1xuICAgICAgICBpZiAoIWVsLl9pc0xlYXZpbmcpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgcmVtb3ZlVHJhbnNpdGlvbkNsYXNzKGVsLCBsZWF2ZUZyb21DbGFzcyk7XG4gICAgICAgIGFkZFRyYW5zaXRpb25DbGFzcyhlbCwgbGVhdmVUb0NsYXNzKTtcbiAgICAgICAgaWYgKCFoYXNFeHBsaWNpdENhbGxiYWNrKG9uTGVhdmUpKSB7XG4gICAgICAgICAgd2hlblRyYW5zaXRpb25FbmRzKGVsLCB0eXBlLCBsZWF2ZUR1cmF0aW9uLCByZXNvbHZlKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBjYWxsSG9vayhvbkxlYXZlLCBbZWwsIHJlc29sdmVdKTtcbiAgICB9LFxuICAgIG9uRW50ZXJDYW5jZWxsZWQoZWwpIHtcbiAgICAgIGZpbmlzaEVudGVyKGVsLCBmYWxzZSwgdm9pZCAwLCB0cnVlKTtcbiAgICAgIGNhbGxIb29rKG9uRW50ZXJDYW5jZWxsZWQsIFtlbF0pO1xuICAgIH0sXG4gICAgb25BcHBlYXJDYW5jZWxsZWQoZWwpIHtcbiAgICAgIGZpbmlzaEVudGVyKGVsLCB0cnVlLCB2b2lkIDAsIHRydWUpO1xuICAgICAgY2FsbEhvb2sob25BcHBlYXJDYW5jZWxsZWQsIFtlbF0pO1xuICAgIH0sXG4gICAgb25MZWF2ZUNhbmNlbGxlZChlbCkge1xuICAgICAgZmluaXNoTGVhdmUoZWwpO1xuICAgICAgY2FsbEhvb2sob25MZWF2ZUNhbmNlbGxlZCwgW2VsXSk7XG4gICAgfVxuICB9KTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZUR1cmF0aW9uKGR1cmF0aW9uKSB7XG4gIGlmIChkdXJhdGlvbiA9PSBudWxsKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH0gZWxzZSBpZiAoaXNPYmplY3QoZHVyYXRpb24pKSB7XG4gICAgcmV0dXJuIFtOdW1iZXJPZihkdXJhdGlvbi5lbnRlciksIE51bWJlck9mKGR1cmF0aW9uLmxlYXZlKV07XG4gIH0gZWxzZSB7XG4gICAgY29uc3QgbiA9IE51bWJlck9mKGR1cmF0aW9uKTtcbiAgICByZXR1cm4gW24sIG5dO1xuICB9XG59XG5mdW5jdGlvbiBOdW1iZXJPZih2YWwpIHtcbiAgY29uc3QgcmVzID0gdG9OdW1iZXIodmFsKTtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICBhc3NlcnROdW1iZXIocmVzLCBcIjx0cmFuc2l0aW9uPiBleHBsaWNpdCBkdXJhdGlvblwiKTtcbiAgfVxuICByZXR1cm4gcmVzO1xufVxuZnVuY3Rpb24gYWRkVHJhbnNpdGlvbkNsYXNzKGVsLCBjbHMpIHtcbiAgY2xzLnNwbGl0KC9cXHMrLykuZm9yRWFjaCgoYykgPT4gYyAmJiBlbC5jbGFzc0xpc3QuYWRkKGMpKTtcbiAgKGVsW3Z0Y0tleV0gfHwgKGVsW3Z0Y0tleV0gPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpKSkuYWRkKGNscyk7XG59XG5mdW5jdGlvbiByZW1vdmVUcmFuc2l0aW9uQ2xhc3MoZWwsIGNscykge1xuICBjbHMuc3BsaXQoL1xccysvKS5mb3JFYWNoKChjKSA9PiBjICYmIGVsLmNsYXNzTGlzdC5yZW1vdmUoYykpO1xuICBjb25zdCBfdnRjID0gZWxbdnRjS2V5XTtcbiAgaWYgKF92dGMpIHtcbiAgICBfdnRjLmRlbGV0ZShjbHMpO1xuICAgIGlmICghX3Z0Yy5zaXplKSB7XG4gICAgICBlbFt2dGNLZXldID0gdm9pZCAwO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gbmV4dEZyYW1lKGNiKSB7XG4gIHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgcmVxdWVzdEFuaW1hdGlvbkZyYW1lKGNiKTtcbiAgfSk7XG59XG5sZXQgZW5kSWQgPSAwO1xuZnVuY3Rpb24gd2hlblRyYW5zaXRpb25FbmRzKGVsLCBleHBlY3RlZFR5cGUsIGV4cGxpY2l0VGltZW91dCwgcmVzb2x2ZSkge1xuICBjb25zdCBpZCA9IGVsLl9lbmRJZCA9ICsrZW5kSWQ7XG4gIGNvbnN0IHJlc29sdmVJZk5vdFN0YWxlID0gKCkgPT4ge1xuICAgIGlmIChpZCA9PT0gZWwuX2VuZElkKSB7XG4gICAgICByZXNvbHZlKCk7XG4gICAgfVxuICB9O1xuICBpZiAoZXhwbGljaXRUaW1lb3V0ICE9IG51bGwpIHtcbiAgICByZXR1cm4gc2V0VGltZW91dChyZXNvbHZlSWZOb3RTdGFsZSwgZXhwbGljaXRUaW1lb3V0KTtcbiAgfVxuICBjb25zdCB7IHR5cGUsIHRpbWVvdXQsIHByb3BDb3VudCB9ID0gZ2V0VHJhbnNpdGlvbkluZm8oZWwsIGV4cGVjdGVkVHlwZSk7XG4gIGlmICghdHlwZSkge1xuICAgIHJldHVybiByZXNvbHZlKCk7XG4gIH1cbiAgY29uc3QgZW5kRXZlbnQgPSB0eXBlICsgXCJlbmRcIjtcbiAgbGV0IGVuZGVkID0gMDtcbiAgY29uc3QgZW5kID0gKCkgPT4ge1xuICAgIGVsLnJlbW92ZUV2ZW50TGlzdGVuZXIoZW5kRXZlbnQsIG9uRW5kKTtcbiAgICByZXNvbHZlSWZOb3RTdGFsZSgpO1xuICB9O1xuICBjb25zdCBvbkVuZCA9IChlKSA9PiB7XG4gICAgaWYgKGUudGFyZ2V0ID09PSBlbCAmJiArK2VuZGVkID49IHByb3BDb3VudCkge1xuICAgICAgZW5kKCk7XG4gICAgfVxuICB9O1xuICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICBpZiAoZW5kZWQgPCBwcm9wQ291bnQpIHtcbiAgICAgIGVuZCgpO1xuICAgIH1cbiAgfSwgdGltZW91dCArIDEpO1xuICBlbC5hZGRFdmVudExpc3RlbmVyKGVuZEV2ZW50LCBvbkVuZCk7XG59XG5mdW5jdGlvbiBnZXRUcmFuc2l0aW9uSW5mbyhlbCwgZXhwZWN0ZWRUeXBlKSB7XG4gIGNvbnN0IHN0eWxlcyA9IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGVsKTtcbiAgY29uc3QgZ2V0U3R5bGVQcm9wZXJ0aWVzID0gKGtleSkgPT4gKHN0eWxlc1trZXldIHx8IFwiXCIpLnNwbGl0KFwiLCBcIik7XG4gIGNvbnN0IHRyYW5zaXRpb25EZWxheXMgPSBnZXRTdHlsZVByb3BlcnRpZXMoYCR7VFJBTlNJVElPTn1EZWxheWApO1xuICBjb25zdCB0cmFuc2l0aW9uRHVyYXRpb25zID0gZ2V0U3R5bGVQcm9wZXJ0aWVzKGAke1RSQU5TSVRJT059RHVyYXRpb25gKTtcbiAgY29uc3QgdHJhbnNpdGlvblRpbWVvdXQgPSBnZXRUaW1lb3V0KHRyYW5zaXRpb25EZWxheXMsIHRyYW5zaXRpb25EdXJhdGlvbnMpO1xuICBjb25zdCBhbmltYXRpb25EZWxheXMgPSBnZXRTdHlsZVByb3BlcnRpZXMoYCR7QU5JTUFUSU9OfURlbGF5YCk7XG4gIGNvbnN0IGFuaW1hdGlvbkR1cmF0aW9ucyA9IGdldFN0eWxlUHJvcGVydGllcyhgJHtBTklNQVRJT059RHVyYXRpb25gKTtcbiAgY29uc3QgYW5pbWF0aW9uVGltZW91dCA9IGdldFRpbWVvdXQoYW5pbWF0aW9uRGVsYXlzLCBhbmltYXRpb25EdXJhdGlvbnMpO1xuICBsZXQgdHlwZSA9IG51bGw7XG4gIGxldCB0aW1lb3V0ID0gMDtcbiAgbGV0IHByb3BDb3VudCA9IDA7XG4gIGlmIChleHBlY3RlZFR5cGUgPT09IFRSQU5TSVRJT04pIHtcbiAgICBpZiAodHJhbnNpdGlvblRpbWVvdXQgPiAwKSB7XG4gICAgICB0eXBlID0gVFJBTlNJVElPTjtcbiAgICAgIHRpbWVvdXQgPSB0cmFuc2l0aW9uVGltZW91dDtcbiAgICAgIHByb3BDb3VudCA9IHRyYW5zaXRpb25EdXJhdGlvbnMubGVuZ3RoO1xuICAgIH1cbiAgfSBlbHNlIGlmIChleHBlY3RlZFR5cGUgPT09IEFOSU1BVElPTikge1xuICAgIGlmIChhbmltYXRpb25UaW1lb3V0ID4gMCkge1xuICAgICAgdHlwZSA9IEFOSU1BVElPTjtcbiAgICAgIHRpbWVvdXQgPSBhbmltYXRpb25UaW1lb3V0O1xuICAgICAgcHJvcENvdW50ID0gYW5pbWF0aW9uRHVyYXRpb25zLmxlbmd0aDtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgdGltZW91dCA9IE1hdGgubWF4KHRyYW5zaXRpb25UaW1lb3V0LCBhbmltYXRpb25UaW1lb3V0KTtcbiAgICB0eXBlID0gdGltZW91dCA+IDAgPyB0cmFuc2l0aW9uVGltZW91dCA+IGFuaW1hdGlvblRpbWVvdXQgPyBUUkFOU0lUSU9OIDogQU5JTUFUSU9OIDogbnVsbDtcbiAgICBwcm9wQ291bnQgPSB0eXBlID8gdHlwZSA9PT0gVFJBTlNJVElPTiA/IHRyYW5zaXRpb25EdXJhdGlvbnMubGVuZ3RoIDogYW5pbWF0aW9uRHVyYXRpb25zLmxlbmd0aCA6IDA7XG4gIH1cbiAgY29uc3QgaGFzVHJhbnNmb3JtID0gdHlwZSA9PT0gVFJBTlNJVElPTiAmJiAvXFxiKD86dHJhbnNmb3JtfGFsbCkoPzosfCQpLy50ZXN0KFxuICAgIGdldFN0eWxlUHJvcGVydGllcyhgJHtUUkFOU0lUSU9OfVByb3BlcnR5YCkudG9TdHJpbmcoKVxuICApO1xuICByZXR1cm4ge1xuICAgIHR5cGUsXG4gICAgdGltZW91dCxcbiAgICBwcm9wQ291bnQsXG4gICAgaGFzVHJhbnNmb3JtXG4gIH07XG59XG5mdW5jdGlvbiBnZXRUaW1lb3V0KGRlbGF5cywgZHVyYXRpb25zKSB7XG4gIHdoaWxlIChkZWxheXMubGVuZ3RoIDwgZHVyYXRpb25zLmxlbmd0aCkge1xuICAgIGRlbGF5cyA9IGRlbGF5cy5jb25jYXQoZGVsYXlzKTtcbiAgfVxuICByZXR1cm4gTWF0aC5tYXgoLi4uZHVyYXRpb25zLm1hcCgoZCwgaSkgPT4gdG9NcyhkKSArIHRvTXMoZGVsYXlzW2ldKSkpO1xufVxuZnVuY3Rpb24gdG9NcyhzKSB7XG4gIGlmIChzID09PSBcImF1dG9cIikgcmV0dXJuIDA7XG4gIHJldHVybiBOdW1iZXIocy5zbGljZSgwLCAtMSkucmVwbGFjZShcIixcIiwgXCIuXCIpKSAqIDFlMztcbn1cbmZ1bmN0aW9uIGZvcmNlUmVmbG93KGVsKSB7XG4gIGNvbnN0IHRhcmdldERvY3VtZW50ID0gZWwgPyBlbC5vd25lckRvY3VtZW50IDogZG9jdW1lbnQ7XG4gIHJldHVybiB0YXJnZXREb2N1bWVudC5ib2R5Lm9mZnNldEhlaWdodDtcbn1cblxuZnVuY3Rpb24gcGF0Y2hDbGFzcyhlbCwgdmFsdWUsIGlzU1ZHKSB7XG4gIGNvbnN0IHRyYW5zaXRpb25DbGFzc2VzID0gZWxbdnRjS2V5XTtcbiAgaWYgKHRyYW5zaXRpb25DbGFzc2VzKSB7XG4gICAgdmFsdWUgPSAodmFsdWUgPyBbdmFsdWUsIC4uLnRyYW5zaXRpb25DbGFzc2VzXSA6IFsuLi50cmFuc2l0aW9uQ2xhc3Nlc10pLmpvaW4oXCIgXCIpO1xuICB9XG4gIGlmICh2YWx1ZSA9PSBudWxsKSB7XG4gICAgZWwucmVtb3ZlQXR0cmlidXRlKFwiY2xhc3NcIik7XG4gIH0gZWxzZSBpZiAoaXNTVkcpIHtcbiAgICBlbC5zZXRBdHRyaWJ1dGUoXCJjbGFzc1wiLCB2YWx1ZSk7XG4gIH0gZWxzZSB7XG4gICAgZWwuY2xhc3NOYW1lID0gdmFsdWU7XG4gIH1cbn1cblxuY29uc3QgdlNob3dPcmlnaW5hbERpc3BsYXkgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sKFwiX3ZvZFwiKTtcbmNvbnN0IHZTaG93SGlkZGVuID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcIl92c2hcIik7XG5jb25zdCB2U2hvdyA9IHtcbiAgLy8gdXNlZCBmb3IgcHJvcCBtaXNtYXRjaCBjaGVjayBkdXJpbmcgaHlkcmF0aW9uXG4gIG5hbWU6IFwic2hvd1wiLFxuICBiZWZvcmVNb3VudChlbCwgeyB2YWx1ZSB9LCB7IHRyYW5zaXRpb24gfSkge1xuICAgIGVsW3ZTaG93T3JpZ2luYWxEaXNwbGF5XSA9IGVsLnN0eWxlLmRpc3BsYXkgPT09IFwibm9uZVwiID8gXCJcIiA6IGVsLnN0eWxlLmRpc3BsYXk7XG4gICAgaWYgKHRyYW5zaXRpb24gJiYgdmFsdWUpIHtcbiAgICAgIHRyYW5zaXRpb24uYmVmb3JlRW50ZXIoZWwpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXREaXNwbGF5KGVsLCB2YWx1ZSk7XG4gICAgfVxuICB9LFxuICBtb3VudGVkKGVsLCB7IHZhbHVlIH0sIHsgdHJhbnNpdGlvbiB9KSB7XG4gICAgaWYgKHRyYW5zaXRpb24gJiYgdmFsdWUpIHtcbiAgICAgIHRyYW5zaXRpb24uZW50ZXIoZWwpO1xuICAgIH1cbiAgfSxcbiAgdXBkYXRlZChlbCwgeyB2YWx1ZSwgb2xkVmFsdWUgfSwgeyB0cmFuc2l0aW9uIH0pIHtcbiAgICBpZiAoIXZhbHVlID09PSAhb2xkVmFsdWUpIHJldHVybjtcbiAgICBpZiAodHJhbnNpdGlvbikge1xuICAgICAgaWYgKHZhbHVlKSB7XG4gICAgICAgIHRyYW5zaXRpb24uYmVmb3JlRW50ZXIoZWwpO1xuICAgICAgICBzZXREaXNwbGF5KGVsLCB0cnVlKTtcbiAgICAgICAgdHJhbnNpdGlvbi5lbnRlcihlbCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0cmFuc2l0aW9uLmxlYXZlKGVsLCAoKSA9PiB7XG4gICAgICAgICAgc2V0RGlzcGxheShlbCwgZmFsc2UpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgc2V0RGlzcGxheShlbCwgdmFsdWUpO1xuICAgIH1cbiAgfSxcbiAgYmVmb3JlVW5tb3VudChlbCwgeyB2YWx1ZSB9KSB7XG4gICAgc2V0RGlzcGxheShlbCwgdmFsdWUpO1xuICB9XG59O1xuZnVuY3Rpb24gc2V0RGlzcGxheShlbCwgdmFsdWUpIHtcbiAgZWwuc3R5bGUuZGlzcGxheSA9IHZhbHVlID8gZWxbdlNob3dPcmlnaW5hbERpc3BsYXldIDogXCJub25lXCI7XG4gIGVsW3ZTaG93SGlkZGVuXSA9ICF2YWx1ZTtcbn1cbmZ1bmN0aW9uIGluaXRWU2hvd0ZvclNTUigpIHtcbiAgdlNob3cuZ2V0U1NSUHJvcHMgPSAoeyB2YWx1ZSB9KSA9PiB7XG4gICAgaWYgKCF2YWx1ZSkge1xuICAgICAgcmV0dXJuIHsgc3R5bGU6IHsgZGlzcGxheTogXCJub25lXCIgfSB9O1xuICAgIH1cbiAgfTtcbn1cblxuY29uc3QgQ1NTX1ZBUl9URVhUID0gLyogQF9fUFVSRV9fICovIFN5bWJvbCghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gXCJDU1NfVkFSX1RFWFRcIiA6IFwiXCIpO1xuZnVuY3Rpb24gdXNlQ3NzVmFycyhnZXR0ZXIpIHtcbiAgY29uc3QgaW5zdGFuY2UgPSBnZXRDdXJyZW50SW5zdGFuY2UoKTtcbiAgaWYgKCFpbnN0YW5jZSkge1xuICAgICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgd2FybihgdXNlQ3NzVmFycyBpcyBjYWxsZWQgd2l0aG91dCBjdXJyZW50IGFjdGl2ZSBjb21wb25lbnQgaW5zdGFuY2UuYCk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHVwZGF0ZVRlbGVwb3J0cyA9IGluc3RhbmNlLnV0ID0gKHZhcnMgPSBnZXR0ZXIoaW5zdGFuY2UucHJveHkpKSA9PiB7XG4gICAgQXJyYXkuZnJvbShcbiAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoYFtkYXRhLXYtb3duZXI9XCIke2luc3RhbmNlLnVpZH1cIl1gKVxuICAgICkuZm9yRWFjaCgobm9kZSkgPT4gc2V0VmFyc09uTm9kZShub2RlLCB2YXJzKSk7XG4gIH07XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgaW5zdGFuY2UuZ2V0Q3NzVmFycyA9ICgpID0+IGdldHRlcihpbnN0YW5jZS5wcm94eSk7XG4gIH1cbiAgY29uc3Qgc2V0VmFycyA9ICgpID0+IHtcbiAgICBjb25zdCB2YXJzID0gZ2V0dGVyKGluc3RhbmNlLnByb3h5KTtcbiAgICBpZiAoaW5zdGFuY2UuY2UpIHtcbiAgICAgIHNldFZhcnNPbk5vZGUoaW5zdGFuY2UuY2UsIHZhcnMpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRWYXJzT25WTm9kZShpbnN0YW5jZS5zdWJUcmVlLCB2YXJzKTtcbiAgICB9XG4gICAgdXBkYXRlVGVsZXBvcnRzKHZhcnMpO1xuICB9O1xuICBvbkJlZm9yZVVwZGF0ZSgoKSA9PiB7XG4gICAgcXVldWVQb3N0Rmx1c2hDYihzZXRWYXJzKTtcbiAgfSk7XG4gIG9uTW91bnRlZCgoKSA9PiB7XG4gICAgd2F0Y2goc2V0VmFycywgTk9PUCwgeyBmbHVzaDogXCJwb3N0XCIgfSk7XG4gICAgY29uc3Qgb2IgPSBuZXcgTXV0YXRpb25PYnNlcnZlcihzZXRWYXJzKTtcbiAgICBvYi5vYnNlcnZlKGluc3RhbmNlLnN1YlRyZWUuZWwucGFyZW50Tm9kZSwgeyBjaGlsZExpc3Q6IHRydWUgfSk7XG4gICAgb25Vbm1vdW50ZWQoKCkgPT4gb2IuZGlzY29ubmVjdCgpKTtcbiAgfSk7XG59XG5mdW5jdGlvbiBzZXRWYXJzT25WTm9kZSh2bm9kZSwgdmFycykge1xuICBpZiAodm5vZGUuc2hhcGVGbGFnICYgMTI4KSB7XG4gICAgY29uc3Qgc3VzcGVuc2UgPSB2bm9kZS5zdXNwZW5zZTtcbiAgICB2bm9kZSA9IHN1c3BlbnNlLmFjdGl2ZUJyYW5jaDtcbiAgICBpZiAoc3VzcGVuc2UucGVuZGluZ0JyYW5jaCAmJiAhc3VzcGVuc2UuaXNIeWRyYXRpbmcpIHtcbiAgICAgIHN1c3BlbnNlLmVmZmVjdHMucHVzaCgoKSA9PiB7XG4gICAgICAgIHNldFZhcnNPblZOb2RlKHN1c3BlbnNlLmFjdGl2ZUJyYW5jaCwgdmFycyk7XG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgd2hpbGUgKHZub2RlLmNvbXBvbmVudCkge1xuICAgIHZub2RlID0gdm5vZGUuY29tcG9uZW50LnN1YlRyZWU7XG4gIH1cbiAgaWYgKHZub2RlLnNoYXBlRmxhZyAmIDEgJiYgdm5vZGUuZWwpIHtcbiAgICBzZXRWYXJzT25Ob2RlKHZub2RlLmVsLCB2YXJzKTtcbiAgfSBlbHNlIGlmICh2bm9kZS50eXBlID09PSBGcmFnbWVudCkge1xuICAgIHZub2RlLmNoaWxkcmVuLmZvckVhY2goKGMpID0+IHNldFZhcnNPblZOb2RlKGMsIHZhcnMpKTtcbiAgfSBlbHNlIGlmICh2bm9kZS50eXBlID09PSBTdGF0aWMpIHtcbiAgICBsZXQgeyBlbCwgYW5jaG9yIH0gPSB2bm9kZTtcbiAgICB3aGlsZSAoZWwpIHtcbiAgICAgIHNldFZhcnNPbk5vZGUoZWwsIHZhcnMpO1xuICAgICAgaWYgKGVsID09PSBhbmNob3IpIGJyZWFrO1xuICAgICAgZWwgPSBlbC5uZXh0U2libGluZztcbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIHNldFZhcnNPbk5vZGUoZWwsIHZhcnMpIHtcbiAgaWYgKGVsLm5vZGVUeXBlID09PSAxKSB7XG4gICAgY29uc3Qgc3R5bGUgPSBlbC5zdHlsZTtcbiAgICBsZXQgY3NzVGV4dCA9IFwiXCI7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gdmFycykge1xuICAgICAgY29uc3QgdmFsdWUgPSBub3JtYWxpemVDc3NWYXJWYWx1ZSh2YXJzW2tleV0pO1xuICAgICAgc3R5bGUuc2V0UHJvcGVydHkoYC0tJHtrZXl9YCwgdmFsdWUpO1xuICAgICAgY3NzVGV4dCArPSBgLS0ke2tleX06ICR7dmFsdWV9O2A7XG4gICAgfVxuICAgIHN0eWxlW0NTU19WQVJfVEVYVF0gPSBjc3NUZXh0O1xuICB9XG59XG5cbmNvbnN0IGRpc3BsYXlSRSA9IC8oPzpefDspXFxzKmRpc3BsYXlcXHMqOi87XG5mdW5jdGlvbiBwYXRjaFN0eWxlKGVsLCBwcmV2LCBuZXh0KSB7XG4gIGNvbnN0IHN0eWxlID0gZWwuc3R5bGU7XG4gIGNvbnN0IGlzQ3NzU3RyaW5nID0gaXNTdHJpbmcobmV4dCk7XG4gIGxldCBoYXNDb250cm9sbGVkRGlzcGxheSA9IGZhbHNlO1xuICBpZiAobmV4dCAmJiAhaXNDc3NTdHJpbmcpIHtcbiAgICBpZiAocHJldikge1xuICAgICAgaWYgKCFpc1N0cmluZyhwcmV2KSkge1xuICAgICAgICBmb3IgKGNvbnN0IGtleSBpbiBwcmV2KSB7XG4gICAgICAgICAgaWYgKG5leHRba2V5XSA9PSBudWxsKSB7XG4gICAgICAgICAgICBzZXRTdHlsZShzdHlsZSwga2V5LCBcIlwiKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGZvciAoY29uc3QgcHJldlN0eWxlIG9mIHByZXYuc3BsaXQoXCI7XCIpKSB7XG4gICAgICAgICAgY29uc3Qga2V5ID0gcHJldlN0eWxlLnNsaWNlKDAsIHByZXZTdHlsZS5pbmRleE9mKFwiOlwiKSkudHJpbSgpO1xuICAgICAgICAgIGlmIChuZXh0W2tleV0gPT0gbnVsbCkge1xuICAgICAgICAgICAgc2V0U3R5bGUoc3R5bGUsIGtleSwgXCJcIik7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGZvciAoY29uc3Qga2V5IGluIG5leHQpIHtcbiAgICAgIGlmIChrZXkgPT09IFwiZGlzcGxheVwiKSB7XG4gICAgICAgIGhhc0NvbnRyb2xsZWREaXNwbGF5ID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHZhbHVlID0gbmV4dFtrZXldO1xuICAgICAgaWYgKHZhbHVlICE9IG51bGwpIHtcbiAgICAgICAgaWYgKCFzaG91bGRQcmVzZXJ2ZVRleHRhcmVhUmVzaXplU3R5bGUoXG4gICAgICAgICAgZWwsXG4gICAgICAgICAga2V5LFxuICAgICAgICAgICFpc1N0cmluZyhwcmV2KSAmJiBwcmV2ID8gcHJldltrZXldIDogdm9pZCAwLFxuICAgICAgICAgIHZhbHVlXG4gICAgICAgICkpIHtcbiAgICAgICAgICBzZXRTdHlsZShzdHlsZSwga2V5LCB2YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNldFN0eWxlKHN0eWxlLCBrZXksIFwiXCIpO1xuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBpZiAoaXNDc3NTdHJpbmcpIHtcbiAgICAgIGlmIChwcmV2ICE9PSBuZXh0KSB7XG4gICAgICAgIGNvbnN0IGNzc1ZhclRleHQgPSBzdHlsZVtDU1NfVkFSX1RFWFRdO1xuICAgICAgICBpZiAoY3NzVmFyVGV4dCkge1xuICAgICAgICAgIG5leHQgKz0gXCI7XCIgKyBjc3NWYXJUZXh0O1xuICAgICAgICB9XG4gICAgICAgIHN0eWxlLmNzc1RleHQgPSBuZXh0O1xuICAgICAgICBoYXNDb250cm9sbGVkRGlzcGxheSA9IGRpc3BsYXlSRS50ZXN0KG5leHQpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAocHJldikge1xuICAgICAgZWwucmVtb3ZlQXR0cmlidXRlKFwic3R5bGVcIik7XG4gICAgfVxuICB9XG4gIGlmICh2U2hvd09yaWdpbmFsRGlzcGxheSBpbiBlbCkge1xuICAgIGVsW3ZTaG93T3JpZ2luYWxEaXNwbGF5XSA9IGhhc0NvbnRyb2xsZWREaXNwbGF5ID8gc3R5bGUuZGlzcGxheSA6IFwiXCI7XG4gICAgaWYgKGVsW3ZTaG93SGlkZGVuXSkge1xuICAgICAgc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgIH1cbiAgfVxufVxuY29uc3Qgc2VtaWNvbG9uUkUgPSAvW15cXFxcXTtcXHMqJC87XG5jb25zdCBpbXBvcnRhbnRSRSA9IC9cXHMqIWltcG9ydGFudCQvO1xuZnVuY3Rpb24gc2V0U3R5bGUoc3R5bGUsIG5hbWUsIHZhbCkge1xuICBpZiAoaXNBcnJheSh2YWwpKSB7XG4gICAgdmFsLmZvckVhY2goKHYpID0+IHNldFN0eWxlKHN0eWxlLCBuYW1lLCB2KSk7XG4gIH0gZWxzZSB7XG4gICAgaWYgKHZhbCA9PSBudWxsKSB2YWwgPSBcIlwiO1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICBpZiAoc2VtaWNvbG9uUkUudGVzdCh2YWwpKSB7XG4gICAgICAgIHdhcm4oXG4gICAgICAgICAgYFVuZXhwZWN0ZWQgc2VtaWNvbG9uIGF0IHRoZSBlbmQgb2YgJyR7bmFtZX0nIHN0eWxlIHZhbHVlOiAnJHt2YWx9J2BcbiAgICAgICAgKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKG5hbWUuc3RhcnRzV2l0aChcIi0tXCIpKSB7XG4gICAgICBzdHlsZS5zZXRQcm9wZXJ0eShuYW1lLCB2YWwpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBwcmVmaXhlZCA9IGF1dG9QcmVmaXgoc3R5bGUsIG5hbWUpO1xuICAgICAgaWYgKGltcG9ydGFudFJFLnRlc3QodmFsKSkge1xuICAgICAgICBzdHlsZS5zZXRQcm9wZXJ0eShcbiAgICAgICAgICBoeXBoZW5hdGUocHJlZml4ZWQpLFxuICAgICAgICAgIHZhbC5yZXBsYWNlKGltcG9ydGFudFJFLCBcIlwiKSxcbiAgICAgICAgICBcImltcG9ydGFudFwiXG4gICAgICAgICk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBzdHlsZVtwcmVmaXhlZF0gPSB2YWw7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5jb25zdCBwcmVmaXhlcyA9IFtcIldlYmtpdFwiLCBcIk1velwiLCBcIm1zXCJdO1xuY29uc3QgcHJlZml4Q2FjaGUgPSB7fTtcbmZ1bmN0aW9uIGF1dG9QcmVmaXgoc3R5bGUsIHJhd05hbWUpIHtcbiAgY29uc3QgY2FjaGVkID0gcHJlZml4Q2FjaGVbcmF3TmFtZV07XG4gIGlmIChjYWNoZWQpIHtcbiAgICByZXR1cm4gY2FjaGVkO1xuICB9XG4gIGxldCBuYW1lID0gY2FtZWxpemUocmF3TmFtZSk7XG4gIGlmIChuYW1lICE9PSBcImZpbHRlclwiICYmIG5hbWUgaW4gc3R5bGUpIHtcbiAgICByZXR1cm4gcHJlZml4Q2FjaGVbcmF3TmFtZV0gPSBuYW1lO1xuICB9XG4gIG5hbWUgPSBjYXBpdGFsaXplKG5hbWUpO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IHByZWZpeGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgcHJlZml4ZWQgPSBwcmVmaXhlc1tpXSArIG5hbWU7XG4gICAgaWYgKHByZWZpeGVkIGluIHN0eWxlKSB7XG4gICAgICByZXR1cm4gcHJlZml4Q2FjaGVbcmF3TmFtZV0gPSBwcmVmaXhlZDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJhd05hbWU7XG59XG5mdW5jdGlvbiBzaG91bGRQcmVzZXJ2ZVRleHRhcmVhUmVzaXplU3R5bGUoZWwsIGtleSwgcHJldiwgbmV4dCkge1xuICByZXR1cm4gZWwudGFnTmFtZSA9PT0gXCJURVhUQVJFQVwiICYmIChrZXkgPT09IFwid2lkdGhcIiB8fCBrZXkgPT09IFwiaGVpZ2h0XCIpICYmIGlzU3RyaW5nKG5leHQpICYmIHByZXYgPT09IG5leHQ7XG59XG5cbmNvbnN0IHhsaW5rTlMgPSBcImh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmtcIjtcbmZ1bmN0aW9uIHBhdGNoQXR0cihlbCwga2V5LCB2YWx1ZSwgaXNTVkcsIGluc3RhbmNlLCBpc0Jvb2xlYW4gPSBpc1NwZWNpYWxCb29sZWFuQXR0cihrZXkpKSB7XG4gIGlmIChpc1NWRyAmJiBrZXkuc3RhcnRzV2l0aChcInhsaW5rOlwiKSkge1xuICAgIGlmICh2YWx1ZSA9PSBudWxsKSB7XG4gICAgICBlbC5yZW1vdmVBdHRyaWJ1dGVOUyh4bGlua05TLCBrZXkuc2xpY2UoNiwga2V5Lmxlbmd0aCkpO1xuICAgIH0gZWxzZSB7XG4gICAgICBlbC5zZXRBdHRyaWJ1dGVOUyh4bGlua05TLCBrZXksIHZhbHVlKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgaWYgKHZhbHVlID09IG51bGwgfHwgaXNCb29sZWFuICYmICFpbmNsdWRlQm9vbGVhbkF0dHIodmFsdWUpKSB7XG4gICAgICBlbC5yZW1vdmVBdHRyaWJ1dGUoa2V5KTtcbiAgICB9IGVsc2Uge1xuICAgICAgZWwuc2V0QXR0cmlidXRlKFxuICAgICAgICBrZXksXG4gICAgICAgIGlzQm9vbGVhbiA/IFwiXCIgOiBpc1N5bWJvbCh2YWx1ZSkgPyBTdHJpbmcodmFsdWUpIDogdmFsdWVcbiAgICAgICk7XG4gICAgfVxuICB9XG59XG5cbmZ1bmN0aW9uIHBhdGNoRE9NUHJvcChlbCwga2V5LCB2YWx1ZSwgcGFyZW50Q29tcG9uZW50LCBhdHRyTmFtZSkge1xuICBpZiAoa2V5ID09PSBcImlubmVySFRNTFwiIHx8IGtleSA9PT0gXCJ0ZXh0Q29udGVudFwiKSB7XG4gICAgaWYgKHZhbHVlICE9IG51bGwpIHtcbiAgICAgIGVsW2tleV0gPSBrZXkgPT09IFwiaW5uZXJIVE1MXCIgPyB1bnNhZmVUb1RydXN0ZWRIVE1MKHZhbHVlKSA6IHZhbHVlO1xuICAgIH1cbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgdGFnID0gZWwudGFnTmFtZTtcbiAgaWYgKGtleSA9PT0gXCJ2YWx1ZVwiICYmIHRhZyAhPT0gXCJQUk9HUkVTU1wiICYmIC8vIGN1c3RvbSBlbGVtZW50cyBtYXkgdXNlIF92YWx1ZSBpbnRlcm5hbGx5XG4gICF0YWcuaW5jbHVkZXMoXCItXCIpKSB7XG4gICAgY29uc3Qgb2xkVmFsdWUgPSB0YWcgPT09IFwiT1BUSU9OXCIgPyBlbC5nZXRBdHRyaWJ1dGUoXCJ2YWx1ZVwiKSB8fCBcIlwiIDogZWwudmFsdWU7XG4gICAgY29uc3QgbmV3VmFsdWUgPSB2YWx1ZSA9PSBudWxsID8gKFxuICAgICAgLy8gIzExNjQ3OiB2YWx1ZSBzaG91bGQgYmUgc2V0IGFzIGVtcHR5IHN0cmluZyBmb3IgbnVsbCBhbmQgdW5kZWZpbmVkLFxuICAgICAgLy8gYnV0IDxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIj4gc2hvdWxkIGJlIHNldCBhcyAnb24nLlxuICAgICAgZWwudHlwZSA9PT0gXCJjaGVja2JveFwiID8gXCJvblwiIDogXCJcIlxuICAgICkgOiBTdHJpbmcodmFsdWUpO1xuICAgIGlmIChvbGRWYWx1ZSAhPT0gbmV3VmFsdWUgfHwgIShcIl92YWx1ZVwiIGluIGVsKSkge1xuICAgICAgZWwudmFsdWUgPSBuZXdWYWx1ZTtcbiAgICB9XG4gICAgaWYgKHZhbHVlID09IG51bGwpIHtcbiAgICAgIGVsLnJlbW92ZUF0dHJpYnV0ZShrZXkpO1xuICAgIH1cbiAgICBlbC5fdmFsdWUgPSB2YWx1ZTtcbiAgICByZXR1cm47XG4gIH1cbiAgbGV0IG5lZWRSZW1vdmUgPSBmYWxzZTtcbiAgaWYgKHZhbHVlID09PSBcIlwiIHx8IHZhbHVlID09IG51bGwpIHtcbiAgICBjb25zdCB0eXBlID0gdHlwZW9mIGVsW2tleV07XG4gICAgaWYgKHR5cGUgPT09IFwiYm9vbGVhblwiKSB7XG4gICAgICB2YWx1ZSA9IGluY2x1ZGVCb29sZWFuQXR0cih2YWx1ZSk7XG4gICAgfSBlbHNlIGlmICh2YWx1ZSA9PSBudWxsICYmIHR5cGUgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHZhbHVlID0gXCJcIjtcbiAgICAgIG5lZWRSZW1vdmUgPSB0cnVlO1xuICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gXCJudW1iZXJcIikge1xuICAgICAgdmFsdWUgPSAwO1xuICAgICAgbmVlZFJlbW92ZSA9IHRydWU7XG4gICAgfVxuICB9XG4gIHRyeSB7XG4gICAgZWxba2V5XSA9IHZhbHVlO1xuICB9IGNhdGNoIChlKSB7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIW5lZWRSZW1vdmUpIHtcbiAgICAgIHdhcm4oXG4gICAgICAgIGBGYWlsZWQgc2V0dGluZyBwcm9wIFwiJHtrZXl9XCIgb24gPCR7dGFnLnRvTG93ZXJDYXNlKCl9PjogdmFsdWUgJHt2YWx1ZX0gaXMgaW52YWxpZC5gLFxuICAgICAgICBlXG4gICAgICApO1xuICAgIH1cbiAgfVxuICBuZWVkUmVtb3ZlICYmIGVsLnJlbW92ZUF0dHJpYnV0ZShhdHRyTmFtZSB8fCBrZXkpO1xufVxuXG5mdW5jdGlvbiBhZGRFdmVudExpc3RlbmVyKGVsLCBldmVudCwgaGFuZGxlciwgb3B0aW9ucykge1xuICBlbC5hZGRFdmVudExpc3RlbmVyKGV2ZW50LCBoYW5kbGVyLCBvcHRpb25zKTtcbn1cbmZ1bmN0aW9uIHJlbW92ZUV2ZW50TGlzdGVuZXIoZWwsIGV2ZW50LCBoYW5kbGVyLCBvcHRpb25zKSB7XG4gIGVsLnJlbW92ZUV2ZW50TGlzdGVuZXIoZXZlbnQsIGhhbmRsZXIsIG9wdGlvbnMpO1xufVxuY29uc3QgdmVpS2V5ID0gLyogQF9fUFVSRV9fICovIFN5bWJvbChcIl92ZWlcIik7XG5mdW5jdGlvbiBwYXRjaEV2ZW50KGVsLCByYXdOYW1lLCBwcmV2VmFsdWUsIG5leHRWYWx1ZSwgaW5zdGFuY2UgPSBudWxsKSB7XG4gIGNvbnN0IGludm9rZXJzID0gZWxbdmVpS2V5XSB8fCAoZWxbdmVpS2V5XSA9IHt9KTtcbiAgY29uc3QgZXhpc3RpbmdJbnZva2VyID0gaW52b2tlcnNbcmF3TmFtZV07XG4gIGlmIChuZXh0VmFsdWUgJiYgZXhpc3RpbmdJbnZva2VyKSB7XG4gICAgZXhpc3RpbmdJbnZva2VyLnZhbHVlID0gISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IHNhbml0aXplRXZlbnRWYWx1ZShuZXh0VmFsdWUsIHJhd05hbWUpIDogbmV4dFZhbHVlO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IFtuYW1lLCBvcHRpb25zXSA9IHBhcnNlTmFtZShyYXdOYW1lKTtcbiAgICBpZiAobmV4dFZhbHVlKSB7XG4gICAgICBjb25zdCBpbnZva2VyID0gaW52b2tlcnNbcmF3TmFtZV0gPSBjcmVhdGVJbnZva2VyKFxuICAgICAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gc2FuaXRpemVFdmVudFZhbHVlKG5leHRWYWx1ZSwgcmF3TmFtZSkgOiBuZXh0VmFsdWUsXG4gICAgICAgIGluc3RhbmNlXG4gICAgICApO1xuICAgICAgYWRkRXZlbnRMaXN0ZW5lcihlbCwgbmFtZSwgaW52b2tlciwgb3B0aW9ucyk7XG4gICAgfSBlbHNlIGlmIChleGlzdGluZ0ludm9rZXIpIHtcbiAgICAgIHJlbW92ZUV2ZW50TGlzdGVuZXIoZWwsIG5hbWUsIGV4aXN0aW5nSW52b2tlciwgb3B0aW9ucyk7XG4gICAgICBpbnZva2Vyc1tyYXdOYW1lXSA9IHZvaWQgMDtcbiAgICB9XG4gIH1cbn1cbmNvbnN0IG9wdGlvbnNNb2RpZmllclJFID0gLyhPbmNlfFBhc3NpdmV8Q2FwdHVyZSkkLztcbmNvbnN0IG9wdGlvbnNNb2RpZmllckV2ZW50UkUgPSAvXm9uOj8oPzpPbmNlfFBhc3NpdmV8Q2FwdHVyZSkkLztcbmZ1bmN0aW9uIHBhcnNlTmFtZShuYW1lKSB7XG4gIGxldCBvcHRpb25zO1xuICBsZXQgbTtcbiAgd2hpbGUgKChtID0gbmFtZS5tYXRjaChvcHRpb25zTW9kaWZpZXJSRSkpICYmICFvcHRpb25zTW9kaWZpZXJFdmVudFJFLnRlc3QobmFtZSkpIHtcbiAgICBpZiAoIW9wdGlvbnMpIG9wdGlvbnMgPSB7fTtcbiAgICBuYW1lID0gbmFtZS5zbGljZSgwLCBuYW1lLmxlbmd0aCAtIG1bMV0ubGVuZ3RoKTtcbiAgICBvcHRpb25zW21bMV0udG9Mb3dlckNhc2UoKV0gPSB0cnVlO1xuICB9XG4gIGNvbnN0IGV2ZW50ID0gbmFtZVsyXSA9PT0gXCI6XCIgPyBuYW1lLnNsaWNlKDMpIDogaHlwaGVuYXRlKG5hbWUuc2xpY2UoMikpO1xuICByZXR1cm4gW2V2ZW50LCBvcHRpb25zXTtcbn1cbmxldCBjYWNoZWROb3cgPSAwO1xuY29uc3QgcCA9IC8qIEBfX1BVUkVfXyAqLyBQcm9taXNlLnJlc29sdmUoKTtcbmNvbnN0IGdldE5vdyA9ICgpID0+IGNhY2hlZE5vdyB8fCAocC50aGVuKCgpID0+IGNhY2hlZE5vdyA9IDApLCBjYWNoZWROb3cgPSBEYXRlLm5vdygpKTtcbmZ1bmN0aW9uIGNyZWF0ZUludm9rZXIoaW5pdGlhbFZhbHVlLCBpbnN0YW5jZSkge1xuICBjb25zdCBpbnZva2VyID0gKGUpID0+IHtcbiAgICBpZiAoIWUuX3Z0cykge1xuICAgICAgZS5fdnRzID0gRGF0ZS5ub3coKTtcbiAgICB9IGVsc2UgaWYgKGUuX3Z0cyA8PSBpbnZva2VyLmF0dGFjaGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHZhbHVlID0gaW52b2tlci52YWx1ZTtcbiAgICBpZiAoaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgIGNvbnN0IG9yaWdpbmFsU3RvcCA9IGUuc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uO1xuICAgICAgZS5zdG9wSW1tZWRpYXRlUHJvcGFnYXRpb24gPSAoKSA9PiB7XG4gICAgICAgIG9yaWdpbmFsU3RvcC5jYWxsKGUpO1xuICAgICAgICBlLl9zdG9wcGVkID0gdHJ1ZTtcbiAgICAgIH07XG4gICAgICBjb25zdCBoYW5kbGVycyA9IHZhbHVlLnNsaWNlKCk7XG4gICAgICBjb25zdCBhcmdzID0gW2VdO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBoYW5kbGVycy5sZW5ndGg7IGkrKykge1xuICAgICAgICBpZiAoZS5fc3RvcHBlZCkge1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGhhbmRsZXIgPSBoYW5kbGVyc1tpXTtcbiAgICAgICAgaWYgKGhhbmRsZXIpIHtcbiAgICAgICAgICBjYWxsV2l0aEFzeW5jRXJyb3JIYW5kbGluZyhcbiAgICAgICAgICAgIGhhbmRsZXIsXG4gICAgICAgICAgICBpbnN0YW5jZSxcbiAgICAgICAgICAgIDUsXG4gICAgICAgICAgICBhcmdzXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBjYWxsV2l0aEFzeW5jRXJyb3JIYW5kbGluZyhcbiAgICAgICAgdmFsdWUsXG4gICAgICAgIGluc3RhbmNlLFxuICAgICAgICA1LFxuICAgICAgICBbZV1cbiAgICAgICk7XG4gICAgfVxuICB9O1xuICBpbnZva2VyLnZhbHVlID0gaW5pdGlhbFZhbHVlO1xuICBpbnZva2VyLmF0dGFjaGVkID0gZ2V0Tm93KCk7XG4gIHJldHVybiBpbnZva2VyO1xufVxuZnVuY3Rpb24gc2FuaXRpemVFdmVudFZhbHVlKHZhbHVlLCBwcm9wTmFtZSkge1xuICBpZiAoaXNGdW5jdGlvbih2YWx1ZSkgfHwgaXNBcnJheSh2YWx1ZSkpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cbiAgd2FybihcbiAgICBgV3JvbmcgdHlwZSBwYXNzZWQgYXMgZXZlbnQgaGFuZGxlciB0byAke3Byb3BOYW1lfSAtIGRpZCB5b3UgZm9yZ2V0IEAgb3IgOiBpbiBmcm9udCBvZiB5b3VyIHByb3A/XG5FeHBlY3RlZCBmdW5jdGlvbiBvciBhcnJheSBvZiBmdW5jdGlvbnMsIHJlY2VpdmVkIHR5cGUgJHt0eXBlb2YgdmFsdWV9LmBcbiAgKTtcbiAgcmV0dXJuIE5PT1A7XG59XG5cbmNvbnN0IGlzTmF0aXZlT24gPSAoa2V5KSA9PiBrZXkuY2hhckNvZGVBdCgwKSA9PT0gMTExICYmIGtleS5jaGFyQ29kZUF0KDEpID09PSAxMTAgJiYgLy8gbG93ZXJjYXNlIGxldHRlclxua2V5LmNoYXJDb2RlQXQoMikgPiA5NiAmJiBrZXkuY2hhckNvZGVBdCgyKSA8IDEyMztcbmNvbnN0IHBhdGNoUHJvcCA9IChlbCwga2V5LCBwcmV2VmFsdWUsIG5leHRWYWx1ZSwgbmFtZXNwYWNlLCBwYXJlbnRDb21wb25lbnQpID0+IHtcbiAgY29uc3QgaXNTVkcgPSBuYW1lc3BhY2UgPT09IFwic3ZnXCI7XG4gIGlmIChrZXkgPT09IFwiY2xhc3NcIikge1xuICAgIHBhdGNoQ2xhc3MoZWwsIG5leHRWYWx1ZSwgaXNTVkcpO1xuICB9IGVsc2UgaWYgKGtleSA9PT0gXCJzdHlsZVwiKSB7XG4gICAgcGF0Y2hTdHlsZShlbCwgcHJldlZhbHVlLCBuZXh0VmFsdWUpO1xuICB9IGVsc2UgaWYgKGlzT24oa2V5KSkge1xuICAgIGlmICghaXNNb2RlbExpc3RlbmVyKGtleSkpIHtcbiAgICAgIHBhdGNoRXZlbnQoZWwsIGtleSwgcHJldlZhbHVlLCBuZXh0VmFsdWUsIHBhcmVudENvbXBvbmVudCk7XG4gICAgfVxuICB9IGVsc2UgaWYgKGtleVswXSA9PT0gXCIuXCIgPyAoa2V5ID0ga2V5LnNsaWNlKDEpLCB0cnVlKSA6IGtleVswXSA9PT0gXCJeXCIgPyAoa2V5ID0ga2V5LnNsaWNlKDEpLCBmYWxzZSkgOiBzaG91bGRTZXRBc1Byb3AoZWwsIGtleSwgbmV4dFZhbHVlLCBpc1NWRykpIHtcbiAgICBwYXRjaERPTVByb3AoZWwsIGtleSwgbmV4dFZhbHVlKTtcbiAgICBpZiAoIWVsLnRhZ05hbWUuaW5jbHVkZXMoXCItXCIpICYmIChrZXkgPT09IFwidmFsdWVcIiB8fCBrZXkgPT09IFwiY2hlY2tlZFwiIHx8IGtleSA9PT0gXCJzZWxlY3RlZFwiKSkge1xuICAgICAgcGF0Y2hBdHRyKGVsLCBrZXksIG5leHRWYWx1ZSwgaXNTVkcsIHBhcmVudENvbXBvbmVudCwga2V5ICE9PSBcInZhbHVlXCIpO1xuICAgIH1cbiAgfSBlbHNlIGlmIChcbiAgICAvLyAjMTEwODEgZm9yY2Ugc2V0IHByb3BzIGZvciBwb3NzaWJsZSBhc3luYyBjdXN0b20gZWxlbWVudFxuICAgIGVsLl9pc1Z1ZUNFICYmIC8vICMxMjQwOCBjaGVjayBpZiBpdCdzIGRlY2xhcmVkIHByb3Agb3IgaXQncyBhc3luYyBjdXN0b20gZWxlbWVudFxuICAgIChzaG91bGRTZXRBc1Byb3BGb3JWdWVDRShlbCwga2V5KSB8fCAvLyBAdHMtZXhwZWN0LWVycm9yIF9kZWYgaXMgcHJpdmF0ZVxuICAgIGVsLl9kZWYuX19hc3luY0xvYWRlciAmJiAoL1tBLVpdLy50ZXN0KGtleSkgfHwgIWlzU3RyaW5nKG5leHRWYWx1ZSkpKVxuICApIHtcbiAgICBwYXRjaERPTVByb3AoZWwsIGNhbWVsaXplJDEoa2V5KSwgbmV4dFZhbHVlLCBwYXJlbnRDb21wb25lbnQsIGtleSk7XG4gIH0gZWxzZSB7XG4gICAgaWYgKGtleSA9PT0gXCJ0cnVlLXZhbHVlXCIpIHtcbiAgICAgIGVsLl90cnVlVmFsdWUgPSBuZXh0VmFsdWU7XG4gICAgfSBlbHNlIGlmIChrZXkgPT09IFwiZmFsc2UtdmFsdWVcIikge1xuICAgICAgZWwuX2ZhbHNlVmFsdWUgPSBuZXh0VmFsdWU7XG4gICAgfVxuICAgIHBhdGNoQXR0cihlbCwga2V5LCBuZXh0VmFsdWUsIGlzU1ZHKTtcbiAgfVxufTtcbmZ1bmN0aW9uIHNob3VsZFNldEFzUHJvcChlbCwga2V5LCB2YWx1ZSwgaXNTVkcpIHtcbiAgaWYgKGlzU1ZHKSB7XG4gICAgaWYgKGtleSA9PT0gXCJpbm5lckhUTUxcIiB8fCBrZXkgPT09IFwidGV4dENvbnRlbnRcIikge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmIChrZXkgaW4gZWwgJiYgaXNOYXRpdmVPbihrZXkpICYmIGlzRnVuY3Rpb24odmFsdWUpKSB7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmIChrZXkgPT09IFwic3BlbGxjaGVja1wiIHx8IGtleSA9PT0gXCJkcmFnZ2FibGVcIiB8fCBrZXkgPT09IFwidHJhbnNsYXRlXCIgfHwga2V5ID09PSBcImF1dG9jb3JyZWN0XCIpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKGtleSA9PT0gXCJzYW5kYm94XCIgJiYgZWwudGFnTmFtZSA9PT0gXCJJRlJBTUVcIikge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoa2V5ID09PSBcImZvcm1cIikge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoa2V5ID09PSBcImxpc3RcIiAmJiBlbC50YWdOYW1lID09PSBcIklOUFVUXCIpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgaWYgKGtleSA9PT0gXCJ0eXBlXCIgJiYgZWwudGFnTmFtZSA9PT0gXCJURVhUQVJFQVwiKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmIChrZXkgPT09IFwid2lkdGhcIiB8fCBrZXkgPT09IFwiaGVpZ2h0XCIpIHtcbiAgICBjb25zdCB0YWcgPSBlbC50YWdOYW1lO1xuICAgIGlmICh0YWcgPT09IFwiSU1HXCIgfHwgdGFnID09PSBcIlZJREVPXCIgfHwgdGFnID09PSBcIkNBTlZBU1wiIHx8IHRhZyA9PT0gXCJTT1VSQ0VcIikge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuICBpZiAoaXNOYXRpdmVPbihrZXkpICYmIGlzU3RyaW5nKHZhbHVlKSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4ga2V5IGluIGVsO1xufVxuZnVuY3Rpb24gc2hvdWxkU2V0QXNQcm9wRm9yVnVlQ0UoZWwsIGtleSkge1xuICBjb25zdCBwcm9wcyA9IChcbiAgICAvLyBAdHMtZXhwZWN0LWVycm9yIF9kZWYgaXMgcHJpdmF0ZVxuICAgIGVsLl9kZWYucHJvcHNcbiAgKTtcbiAgaWYgKCFwcm9wcykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBjb25zdCBjYW1lbEtleSA9IGNhbWVsaXplJDEoa2V5KTtcbiAgcmV0dXJuIEFycmF5LmlzQXJyYXkocHJvcHMpID8gcHJvcHMuc29tZSgocHJvcCkgPT4gY2FtZWxpemUkMShwcm9wKSA9PT0gY2FtZWxLZXkpIDogT2JqZWN0LmtleXMocHJvcHMpLnNvbWUoKHByb3ApID0+IGNhbWVsaXplJDEocHJvcCkgPT09IGNhbWVsS2V5KTtcbn1cblxuY29uc3QgUkVNT1ZBTCA9IHt9O1xuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIGRlZmluZUN1c3RvbUVsZW1lbnQob3B0aW9ucywgZXh0cmFPcHRpb25zLCBfY3JlYXRlQXBwKSB7XG4gIGxldCBDb21wID0gZGVmaW5lQ29tcG9uZW50KG9wdGlvbnMsIGV4dHJhT3B0aW9ucyk7XG4gIGlmIChpc1BsYWluT2JqZWN0KENvbXApKSBDb21wID0gZXh0ZW5kKHt9LCBDb21wLCBleHRyYU9wdGlvbnMpO1xuICBjbGFzcyBWdWVDdXN0b21FbGVtZW50IGV4dGVuZHMgVnVlRWxlbWVudCB7XG4gICAgY29uc3RydWN0b3IoaW5pdGlhbFByb3BzKSB7XG4gICAgICBzdXBlcihDb21wLCBpbml0aWFsUHJvcHMsIF9jcmVhdGVBcHApO1xuICAgIH1cbiAgfVxuICBWdWVDdXN0b21FbGVtZW50LmRlZiA9IENvbXA7XG4gIHJldHVybiBWdWVDdXN0b21FbGVtZW50O1xufVxuY29uc3QgZGVmaW5lU1NSQ3VzdG9tRWxlbWVudCA9ICgvKiBAX19OT19TSURFX0VGRkVDVFNfXyAqLyAob3B0aW9ucywgZXh0cmFPcHRpb25zKSA9PiB7XG4gIHJldHVybiAvKiBAX19QVVJFX18gKi8gZGVmaW5lQ3VzdG9tRWxlbWVudChvcHRpb25zLCBleHRyYU9wdGlvbnMsIGNyZWF0ZVNTUkFwcCk7XG59KTtcbmNvbnN0IEJhc2VDbGFzcyA9IHR5cGVvZiBIVE1MRWxlbWVudCAhPT0gXCJ1bmRlZmluZWRcIiA/IEhUTUxFbGVtZW50IDogY2xhc3Mge1xufTtcbmNsYXNzIFZ1ZUVsZW1lbnQgZXh0ZW5kcyBCYXNlQ2xhc3Mge1xuICBjb25zdHJ1Y3RvcihfZGVmLCBfcHJvcHMgPSB7fSwgX2NyZWF0ZUFwcCA9IGNyZWF0ZUFwcCkge1xuICAgIHN1cGVyKCk7XG4gICAgdGhpcy5fZGVmID0gX2RlZjtcbiAgICB0aGlzLl9wcm9wcyA9IF9wcm9wcztcbiAgICB0aGlzLl9jcmVhdGVBcHAgPSBfY3JlYXRlQXBwO1xuICAgIHRoaXMuX2lzVnVlQ0UgPSB0cnVlO1xuICAgIC8qKlxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMuX2luc3RhbmNlID0gbnVsbDtcbiAgICAvKipcbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLl9hcHAgPSBudWxsO1xuICAgIC8qKlxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMuX25vbmNlID0gdGhpcy5fZGVmLm5vbmNlO1xuICAgIHRoaXMuX2Nvbm5lY3RlZCA9IGZhbHNlO1xuICAgIHRoaXMuX3Jlc29sdmVkID0gZmFsc2U7XG4gICAgdGhpcy5fcGF0Y2hpbmcgPSBmYWxzZTtcbiAgICB0aGlzLl9kaXJ0eSA9IGZhbHNlO1xuICAgIHRoaXMuX251bWJlclByb3BzID0gbnVsbDtcbiAgICB0aGlzLl9zdHlsZUNoaWxkcmVuID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrU2V0KCk7XG4gICAgdGhpcy5fc3R5bGVBbmNob3JzID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG4gICAgdGhpcy5fb2IgPSBudWxsO1xuICAgIGlmICh0aGlzLnNoYWRvd1Jvb3QgJiYgX2NyZWF0ZUFwcCAhPT0gY3JlYXRlQXBwKSB7XG4gICAgICB0aGlzLl9yb290ID0gdGhpcy5zaGFkb3dSb290O1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB0aGlzLnNoYWRvd1Jvb3QpIHtcbiAgICAgICAgd2FybihcbiAgICAgICAgICBgQ3VzdG9tIGVsZW1lbnQgaGFzIHByZS1yZW5kZXJlZCBkZWNsYXJhdGl2ZSBzaGFkb3cgcm9vdCBidXQgaXMgbm90IGRlZmluZWQgYXMgaHlkcmF0YWJsZS4gVXNlIFxcYGRlZmluZVNTUkN1c3RvbUVsZW1lbnRcXGAuYFxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgaWYgKF9kZWYuc2hhZG93Um9vdCAhPT0gZmFsc2UpIHtcbiAgICAgICAgdGhpcy5hdHRhY2hTaGFkb3coXG4gICAgICAgICAgZXh0ZW5kKHt9LCBfZGVmLnNoYWRvd1Jvb3RPcHRpb25zLCB7XG4gICAgICAgICAgICBtb2RlOiBcIm9wZW5cIlxuICAgICAgICAgIH0pXG4gICAgICAgICk7XG4gICAgICAgIHRoaXMuX3Jvb3QgPSB0aGlzLnNoYWRvd1Jvb3Q7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLl9yb290ID0gdGhpcztcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgY29ubmVjdGVkQ2FsbGJhY2soKSB7XG4gICAgaWYgKCF0aGlzLmlzQ29ubmVjdGVkKSByZXR1cm47XG4gICAgaWYgKCF0aGlzLnNoYWRvd1Jvb3QgJiYgIXRoaXMuX3Jlc29sdmVkKSB7XG4gICAgICB0aGlzLl9wYXJzZVNsb3RzKCk7XG4gICAgfVxuICAgIHRoaXMuX2Nvbm5lY3RlZCA9IHRydWU7XG4gICAgbGV0IHBhcmVudCA9IHRoaXM7XG4gICAgd2hpbGUgKHBhcmVudCA9IHBhcmVudCAmJiAvLyAjMTI0Nzkgc2hvdWxkIGNoZWNrIGFzc2lnbmVkU2xvdCBmaXJzdCB0byBnZXQgY29ycmVjdCBwYXJlbnRcbiAgICAocGFyZW50LmFzc2lnbmVkU2xvdCB8fCBwYXJlbnQucGFyZW50Tm9kZSB8fCBwYXJlbnQuaG9zdCkpIHtcbiAgICAgIGlmIChwYXJlbnQgaW5zdGFuY2VvZiBWdWVFbGVtZW50KSB7XG4gICAgICAgIHRoaXMuX3BhcmVudCA9IHBhcmVudDtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghdGhpcy5faW5zdGFuY2UpIHtcbiAgICAgIGlmICh0aGlzLl9yZXNvbHZlZCkge1xuICAgICAgICB0aGlzLl9tb3VudCh0aGlzLl9kZWYpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKHBhcmVudCAmJiBwYXJlbnQuX3BlbmRpbmdSZXNvbHZlKSB7XG4gICAgICAgICAgdGhpcy5fcGVuZGluZ1Jlc29sdmUgPSBwYXJlbnQuX3BlbmRpbmdSZXNvbHZlLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5fcGVuZGluZ1Jlc29sdmUgPSB2b2lkIDA7XG4gICAgICAgICAgICB0aGlzLl9yZXNvbHZlRGVmKCk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpcy5fcmVzb2x2ZURlZigpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG4gIF9zZXRQYXJlbnQocGFyZW50ID0gdGhpcy5fcGFyZW50KSB7XG4gICAgaWYgKHBhcmVudCkge1xuICAgICAgdGhpcy5faW5zdGFuY2UucGFyZW50ID0gcGFyZW50Ll9pbnN0YW5jZTtcbiAgICAgIHRoaXMuX2luaGVyaXRQYXJlbnRDb250ZXh0KHBhcmVudCk7XG4gICAgfVxuICB9XG4gIF9pbmhlcml0UGFyZW50Q29udGV4dChwYXJlbnQgPSB0aGlzLl9wYXJlbnQpIHtcbiAgICBpZiAocGFyZW50ICYmIHRoaXMuX2FwcCkge1xuICAgICAgT2JqZWN0LnNldFByb3RvdHlwZU9mKFxuICAgICAgICB0aGlzLl9hcHAuX2NvbnRleHQucHJvdmlkZXMsXG4gICAgICAgIHBhcmVudC5faW5zdGFuY2UucHJvdmlkZXNcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIGRpc2Nvbm5lY3RlZENhbGxiYWNrKCkge1xuICAgIHRoaXMuX2Nvbm5lY3RlZCA9IGZhbHNlO1xuICAgIG5leHRUaWNrKCgpID0+IHtcbiAgICAgIGlmICghdGhpcy5fY29ubmVjdGVkKSB7XG4gICAgICAgIGlmICh0aGlzLl9vYikge1xuICAgICAgICAgIHRoaXMuX29iLmRpc2Nvbm5lY3QoKTtcbiAgICAgICAgICB0aGlzLl9vYiA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5fYXBwICYmIHRoaXMuX2FwcC51bm1vdW50KCk7XG4gICAgICAgIGlmICh0aGlzLl9pbnN0YW5jZSkgdGhpcy5faW5zdGFuY2UuY2UgPSB2b2lkIDA7XG4gICAgICAgIHRoaXMuX2FwcCA9IHRoaXMuX2luc3RhbmNlID0gbnVsbDtcbiAgICAgICAgaWYgKHRoaXMuX3RlbGVwb3J0VGFyZ2V0cykge1xuICAgICAgICAgIHRoaXMuX3RlbGVwb3J0VGFyZ2V0cy5jbGVhcigpO1xuICAgICAgICAgIHRoaXMuX3RlbGVwb3J0VGFyZ2V0cyA9IHZvaWQgMDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIF9wcm9jZXNzTXV0YXRpb25zKG11dGF0aW9ucykge1xuICAgIGZvciAoY29uc3QgbSBvZiBtdXRhdGlvbnMpIHtcbiAgICAgIHRoaXMuX3NldEF0dHIobS5hdHRyaWJ1dGVOYW1lKTtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIHJlc29sdmUgaW5uZXIgY29tcG9uZW50IGRlZmluaXRpb24gKGhhbmRsZSBwb3NzaWJsZSBhc3luYyBjb21wb25lbnQpXG4gICAqL1xuICBfcmVzb2x2ZURlZigpIHtcbiAgICBpZiAodGhpcy5fcGVuZGluZ1Jlc29sdmUpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0aGlzLmF0dHJpYnV0ZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIHRoaXMuX3NldEF0dHIodGhpcy5hdHRyaWJ1dGVzW2ldLm5hbWUpO1xuICAgIH1cbiAgICB0aGlzLl9vYiA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKHRoaXMuX3Byb2Nlc3NNdXRhdGlvbnMuYmluZCh0aGlzKSk7XG4gICAgdGhpcy5fb2Iub2JzZXJ2ZSh0aGlzLCB7IGF0dHJpYnV0ZXM6IHRydWUgfSk7XG4gICAgY29uc3QgcmVzb2x2ZSA9IChkZWYsIGlzQXN5bmMgPSBmYWxzZSkgPT4ge1xuICAgICAgdGhpcy5fcmVzb2x2ZWQgPSB0cnVlO1xuICAgICAgdGhpcy5fcGVuZGluZ1Jlc29sdmUgPSB2b2lkIDA7XG4gICAgICBjb25zdCB7IHByb3BzLCBzdHlsZXMgfSA9IGRlZjtcbiAgICAgIGxldCBudW1iZXJQcm9wcztcbiAgICAgIGlmIChwcm9wcyAmJiAhaXNBcnJheShwcm9wcykpIHtcbiAgICAgICAgZm9yIChjb25zdCBrZXkgaW4gcHJvcHMpIHtcbiAgICAgICAgICBjb25zdCBvcHQgPSBwcm9wc1trZXldO1xuICAgICAgICAgIGlmIChvcHQgPT09IE51bWJlciB8fCBvcHQgJiYgb3B0LnR5cGUgPT09IE51bWJlcikge1xuICAgICAgICAgICAgaWYgKGtleSBpbiB0aGlzLl9wcm9wcykge1xuICAgICAgICAgICAgICB0aGlzLl9wcm9wc1trZXldID0gdG9OdW1iZXIodGhpcy5fcHJvcHNba2V5XSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAobnVtYmVyUHJvcHMgfHwgKG51bWJlclByb3BzID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCkpKVtjYW1lbGl6ZSQxKGtleSldID0gdHJ1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRoaXMuX251bWJlclByb3BzID0gbnVtYmVyUHJvcHM7XG4gICAgICB0aGlzLl9yZXNvbHZlUHJvcHMoZGVmKTtcbiAgICAgIGlmICh0aGlzLnNoYWRvd1Jvb3QpIHtcbiAgICAgICAgdGhpcy5fYXBwbHlTdHlsZXMoc3R5bGVzKTtcbiAgICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBzdHlsZXMpIHtcbiAgICAgICAgd2FybihcbiAgICAgICAgICBcIkN1c3RvbSBlbGVtZW50IHN0eWxlIGluamVjdGlvbiBpcyBub3Qgc3VwcG9ydGVkIHdoZW4gdXNpbmcgc2hhZG93Um9vdDogZmFsc2VcIlxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgdGhpcy5fbW91bnQoZGVmKTtcbiAgICB9O1xuICAgIGNvbnN0IGFzeW5jRGVmID0gdGhpcy5fZGVmLl9fYXN5bmNMb2FkZXI7XG4gICAgaWYgKGFzeW5jRGVmKSB7XG4gICAgICB0aGlzLl9wZW5kaW5nUmVzb2x2ZSA9IGFzeW5jRGVmKCkudGhlbigoZGVmKSA9PiB7XG4gICAgICAgIGRlZi5jb25maWd1cmVBcHAgPSB0aGlzLl9kZWYuY29uZmlndXJlQXBwO1xuICAgICAgICByZXNvbHZlKHRoaXMuX2RlZiA9IGRlZiwgdHJ1ZSk7XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmVzb2x2ZSh0aGlzLl9kZWYpO1xuICAgIH1cbiAgfVxuICBfbW91bnQoZGVmKSB7XG4gICAgaWYgKCghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHx8IF9fVlVFX1BST0RfREVWVE9PTFNfXykgJiYgIWRlZi5uYW1lKSB7XG4gICAgICBkZWYubmFtZSA9IFwiVnVlRWxlbWVudFwiO1xuICAgIH1cbiAgICB0aGlzLl9hcHAgPSB0aGlzLl9jcmVhdGVBcHAoZGVmKTtcbiAgICB0aGlzLl9pbmhlcml0UGFyZW50Q29udGV4dCgpO1xuICAgIGlmIChkZWYuY29uZmlndXJlQXBwKSB7XG4gICAgICBkZWYuY29uZmlndXJlQXBwKHRoaXMuX2FwcCk7XG4gICAgfVxuICAgIHRoaXMuX2FwcC5fY2VWTm9kZSA9IHRoaXMuX2NyZWF0ZVZOb2RlKCk7XG4gICAgdGhpcy5fYXBwLm1vdW50KHRoaXMuX3Jvb3QpO1xuICAgIGNvbnN0IGV4cG9zZWQgPSB0aGlzLl9pbnN0YW5jZSAmJiB0aGlzLl9pbnN0YW5jZS5leHBvc2VkO1xuICAgIGlmICghZXhwb3NlZCkgcmV0dXJuO1xuICAgIGZvciAoY29uc3Qga2V5IGluIGV4cG9zZWQpIHtcbiAgICAgIGlmICghaGFzT3duKHRoaXMsIGtleSkpIHtcbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIGtleSwge1xuICAgICAgICAgIC8vIHVud3JhcCByZWYgdG8gYmUgY29uc2lzdGVudCB3aXRoIHB1YmxpYyBpbnN0YW5jZSBiZWhhdmlvclxuICAgICAgICAgIGdldDogKCkgPT4gdW5yZWYoZXhwb3NlZFtrZXldKVxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICB3YXJuKGBFeHBvc2VkIHByb3BlcnR5IFwiJHtrZXl9XCIgYWxyZWFkeSBleGlzdHMgb24gY3VzdG9tIGVsZW1lbnQuYCk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIF9yZXNvbHZlUHJvcHMoZGVmKSB7XG4gICAgY29uc3QgeyBwcm9wcyB9ID0gZGVmO1xuICAgIGNvbnN0IGRlY2xhcmVkUHJvcEtleXMgPSBpc0FycmF5KHByb3BzKSA/IHByb3BzIDogT2JqZWN0LmtleXMocHJvcHMgfHwge30pO1xuICAgIGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKHRoaXMpKSB7XG4gICAgICBpZiAoa2V5WzBdICE9PSBcIl9cIiAmJiBkZWNsYXJlZFByb3BLZXlzLmluY2x1ZGVzKGtleSkpIHtcbiAgICAgICAgdGhpcy5fc2V0UHJvcChrZXksIHRoaXNba2V5XSk7XG4gICAgICB9XG4gICAgfVxuICAgIGZvciAoY29uc3Qga2V5IG9mIGRlY2xhcmVkUHJvcEtleXMubWFwKGNhbWVsaXplJDEpKSB7XG4gICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkodGhpcywga2V5LCB7XG4gICAgICAgIGdldCgpIHtcbiAgICAgICAgICByZXR1cm4gdGhpcy5fZ2V0UHJvcChrZXkpO1xuICAgICAgICB9LFxuICAgICAgICBzZXQodmFsKSB7XG4gICAgICAgICAgdGhpcy5fc2V0UHJvcChrZXksIHZhbCwgdHJ1ZSwgIXRoaXMuX3BhdGNoaW5nKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIF9zZXRBdHRyKGtleSkge1xuICAgIGlmIChrZXkuc3RhcnRzV2l0aChcImRhdGEtdi1cIikpIHJldHVybjtcbiAgICBjb25zdCBoYXMgPSB0aGlzLmhhc0F0dHJpYnV0ZShrZXkpO1xuICAgIGxldCB2YWx1ZSA9IGhhcyA/IHRoaXMuZ2V0QXR0cmlidXRlKGtleSkgOiBSRU1PVkFMO1xuICAgIGNvbnN0IGNhbWVsS2V5ID0gY2FtZWxpemUkMShrZXkpO1xuICAgIGlmIChoYXMgJiYgdGhpcy5fbnVtYmVyUHJvcHMgJiYgdGhpcy5fbnVtYmVyUHJvcHNbY2FtZWxLZXldKSB7XG4gICAgICB2YWx1ZSA9IHRvTnVtYmVyKHZhbHVlKTtcbiAgICB9XG4gICAgdGhpcy5fc2V0UHJvcChjYW1lbEtleSwgdmFsdWUsIGZhbHNlLCB0cnVlKTtcbiAgfVxuICAvKipcbiAgICogQGludGVybmFsXG4gICAqL1xuICBfZ2V0UHJvcChrZXkpIHtcbiAgICByZXR1cm4gdGhpcy5fcHJvcHNba2V5XTtcbiAgfVxuICAvKipcbiAgICogQGludGVybmFsXG4gICAqL1xuICBfc2V0UHJvcChrZXksIHZhbCwgc2hvdWxkUmVmbGVjdCA9IHRydWUsIHNob3VsZFVwZGF0ZSA9IGZhbHNlKSB7XG4gICAgaWYgKHZhbCAhPT0gdGhpcy5fcHJvcHNba2V5XSkge1xuICAgICAgdGhpcy5fZGlydHkgPSB0cnVlO1xuICAgICAgaWYgKHZhbCA9PT0gUkVNT1ZBTCkge1xuICAgICAgICBkZWxldGUgdGhpcy5fcHJvcHNba2V5XTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuX3Byb3BzW2tleV0gPSB2YWw7XG4gICAgICAgIGlmIChrZXkgPT09IFwia2V5XCIgJiYgdGhpcy5fYXBwKSB7XG4gICAgICAgICAgdGhpcy5fYXBwLl9jZVZOb2RlLmtleSA9IHZhbDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKHNob3VsZFVwZGF0ZSAmJiB0aGlzLl9pbnN0YW5jZSkge1xuICAgICAgICB0aGlzLl91cGRhdGUoKTtcbiAgICAgIH1cbiAgICAgIGlmIChzaG91bGRSZWZsZWN0KSB7XG4gICAgICAgIGNvbnN0IG9iID0gdGhpcy5fb2I7XG4gICAgICAgIGlmIChvYikge1xuICAgICAgICAgIHRoaXMuX3Byb2Nlc3NNdXRhdGlvbnMob2IudGFrZVJlY29yZHMoKSk7XG4gICAgICAgICAgb2IuZGlzY29ubmVjdCgpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh2YWwgPT09IHRydWUpIHtcbiAgICAgICAgICB0aGlzLnNldEF0dHJpYnV0ZShoeXBoZW5hdGUoa2V5KSwgXCJcIik7XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHZhbCA9PT0gXCJzdHJpbmdcIiB8fCB0eXBlb2YgdmFsID09PSBcIm51bWJlclwiKSB7XG4gICAgICAgICAgdGhpcy5zZXRBdHRyaWJ1dGUoaHlwaGVuYXRlKGtleSksIHZhbCArIFwiXCIpO1xuICAgICAgICB9IGVsc2UgaWYgKCF2YWwpIHtcbiAgICAgICAgICB0aGlzLnJlbW92ZUF0dHJpYnV0ZShoeXBoZW5hdGUoa2V5KSk7XG4gICAgICAgIH1cbiAgICAgICAgb2IgJiYgb2Iub2JzZXJ2ZSh0aGlzLCB7IGF0dHJpYnV0ZXM6IHRydWUgfSk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIF91cGRhdGUoKSB7XG4gICAgY29uc3Qgdm5vZGUgPSB0aGlzLl9jcmVhdGVWTm9kZSgpO1xuICAgIGlmICh0aGlzLl9hcHApIHZub2RlLmFwcENvbnRleHQgPSB0aGlzLl9hcHAuX2NvbnRleHQ7XG4gICAgcmVuZGVyKHZub2RlLCB0aGlzLl9yb290KTtcbiAgfVxuICBfY3JlYXRlVk5vZGUoKSB7XG4gICAgY29uc3QgYmFzZVByb3BzID0ge307XG4gICAgaWYgKCF0aGlzLnNoYWRvd1Jvb3QpIHtcbiAgICAgIGJhc2VQcm9wcy5vblZub2RlTW91bnRlZCA9IGJhc2VQcm9wcy5vblZub2RlVXBkYXRlZCA9IHRoaXMuX3JlbmRlclNsb3RzLmJpbmQodGhpcyk7XG4gICAgfVxuICAgIGNvbnN0IHZub2RlID0gY3JlYXRlVk5vZGUodGhpcy5fZGVmLCBleHRlbmQoYmFzZVByb3BzLCB0aGlzLl9wcm9wcykpO1xuICAgIGlmICghdGhpcy5faW5zdGFuY2UpIHtcbiAgICAgIHZub2RlLmNlID0gKGluc3RhbmNlKSA9PiB7XG4gICAgICAgIHRoaXMuX2luc3RhbmNlID0gaW5zdGFuY2U7XG4gICAgICAgIGluc3RhbmNlLmNlID0gdGhpcztcbiAgICAgICAgaW5zdGFuY2UuaXNDRSA9IHRydWU7XG4gICAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgICAgaW5zdGFuY2UuY2VSZWxvYWQgPSAobmV3U3R5bGVzKSA9PiB7XG4gICAgICAgICAgICBpZiAodGhpcy5fc3R5bGVzKSB7XG4gICAgICAgICAgICAgIHRoaXMuX3N0eWxlcy5mb3JFYWNoKChzKSA9PiB0aGlzLl9yb290LnJlbW92ZUNoaWxkKHMpKTtcbiAgICAgICAgICAgICAgdGhpcy5fc3R5bGVzLmxlbmd0aCA9IDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLl9zdHlsZUFuY2hvcnMuZGVsZXRlKHRoaXMuX2RlZik7XG4gICAgICAgICAgICB0aGlzLl9hcHBseVN0eWxlcyhuZXdTdHlsZXMpO1xuICAgICAgICAgICAgdGhpcy5faW5zdGFuY2UgPSBudWxsO1xuICAgICAgICAgICAgdGhpcy5fdXBkYXRlKCk7XG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBkaXNwYXRjaCA9IChldmVudCwgYXJncykgPT4ge1xuICAgICAgICAgIHRoaXMuZGlzcGF0Y2hFdmVudChcbiAgICAgICAgICAgIG5ldyBDdXN0b21FdmVudChcbiAgICAgICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgICAgIGlzUGxhaW5PYmplY3QoYXJnc1swXSkgPyBleHRlbmQoeyBkZXRhaWw6IGFyZ3MgfSwgYXJnc1swXSkgOiB7IGRldGFpbDogYXJncyB9XG4gICAgICAgICAgICApXG4gICAgICAgICAgKTtcbiAgICAgICAgfTtcbiAgICAgICAgaW5zdGFuY2UuZW1pdCA9IChldmVudCwgLi4uYXJncykgPT4ge1xuICAgICAgICAgIGRpc3BhdGNoKGV2ZW50LCBhcmdzKTtcbiAgICAgICAgICBpZiAoaHlwaGVuYXRlKGV2ZW50KSAhPT0gZXZlbnQpIHtcbiAgICAgICAgICAgIGRpc3BhdGNoKGh5cGhlbmF0ZShldmVudCksIGFyZ3MpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5fc2V0UGFyZW50KCk7XG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gdm5vZGU7XG4gIH1cbiAgX2FwcGx5U3R5bGVzKHN0eWxlcywgb3duZXIsIHBhcmVudENvbXApIHtcbiAgICBpZiAoIXN0eWxlcykgcmV0dXJuO1xuICAgIGlmIChvd25lcikge1xuICAgICAgaWYgKG93bmVyID09PSB0aGlzLl9kZWYgfHwgdGhpcy5fc3R5bGVDaGlsZHJlbi5oYXMob3duZXIpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHRoaXMuX3N0eWxlQ2hpbGRyZW4uYWRkKG93bmVyKTtcbiAgICB9XG4gICAgY29uc3Qgbm9uY2UgPSB0aGlzLl9ub25jZTtcbiAgICBjb25zdCByb290ID0gdGhpcy5zaGFkb3dSb290O1xuICAgIGNvbnN0IGluc2VydGlvbkFuY2hvciA9IHBhcmVudENvbXAgPyB0aGlzLl9nZXRTdHlsZUFuY2hvcihwYXJlbnRDb21wKSB8fCB0aGlzLl9nZXRTdHlsZUFuY2hvcih0aGlzLl9kZWYpIDogdGhpcy5fZ2V0Um9vdFN0eWxlSW5zZXJ0aW9uQW5jaG9yKHJvb3QpO1xuICAgIGxldCBsYXN0ID0gbnVsbDtcbiAgICBmb3IgKGxldCBpID0gc3R5bGVzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICBjb25zdCBzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInN0eWxlXCIpO1xuICAgICAgaWYgKG5vbmNlKSBzLnNldEF0dHJpYnV0ZShcIm5vbmNlXCIsIG5vbmNlKTtcbiAgICAgIHMudGV4dENvbnRlbnQgPSBzdHlsZXNbaV07XG4gICAgICByb290Lmluc2VydEJlZm9yZShzLCBsYXN0IHx8IGluc2VydGlvbkFuY2hvcik7XG4gICAgICBsYXN0ID0gcztcbiAgICAgIGlmIChpID09PSAwKSB7XG4gICAgICAgIGlmICghcGFyZW50Q29tcCkgdGhpcy5fc3R5bGVBbmNob3JzLnNldCh0aGlzLl9kZWYsIHMpO1xuICAgICAgICBpZiAob3duZXIpIHRoaXMuX3N0eWxlQW5jaG9ycy5zZXQob3duZXIsIHMpO1xuICAgICAgfVxuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgaWYgKG93bmVyKSB7XG4gICAgICAgICAgaWYgKG93bmVyLl9faG1ySWQpIHtcbiAgICAgICAgICAgIGlmICghdGhpcy5fY2hpbGRTdHlsZXMpIHRoaXMuX2NoaWxkU3R5bGVzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbiAgICAgICAgICAgIGxldCBlbnRyeSA9IHRoaXMuX2NoaWxkU3R5bGVzLmdldChvd25lci5fX2htcklkKTtcbiAgICAgICAgICAgIGlmICghZW50cnkpIHtcbiAgICAgICAgICAgICAgdGhpcy5fY2hpbGRTdHlsZXMuc2V0KG93bmVyLl9faG1ySWQsIGVudHJ5ID0gW10pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZW50cnkucHVzaChzKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgKHRoaXMuX3N0eWxlcyB8fCAodGhpcy5fc3R5bGVzID0gW10pKS5wdXNoKHMpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG4gIF9nZXRTdHlsZUFuY2hvcihjb21wKSB7XG4gICAgaWYgKCFjb21wKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgYW5jaG9yID0gdGhpcy5fc3R5bGVBbmNob3JzLmdldChjb21wKTtcbiAgICBpZiAoYW5jaG9yICYmIGFuY2hvci5wYXJlbnROb2RlID09PSB0aGlzLnNoYWRvd1Jvb3QpIHtcbiAgICAgIHJldHVybiBhbmNob3I7XG4gICAgfVxuICAgIGlmIChhbmNob3IpIHtcbiAgICAgIHRoaXMuX3N0eWxlQW5jaG9ycy5kZWxldGUoY29tcCk7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG4gIF9nZXRSb290U3R5bGVJbnNlcnRpb25BbmNob3Iocm9vdCkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcm9vdC5jaGlsZE5vZGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBub2RlID0gcm9vdC5jaGlsZE5vZGVzW2ldO1xuICAgICAgaWYgKCEobm9kZSBpbnN0YW5jZW9mIEhUTUxTdHlsZUVsZW1lbnQpKSB7XG4gICAgICAgIHJldHVybiBub2RlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICAvKipcbiAgICogT25seSBjYWxsZWQgd2hlbiBzaGFkb3dSb290IGlzIGZhbHNlXG4gICAqL1xuICBfcGFyc2VTbG90cygpIHtcbiAgICBjb25zdCBzbG90cyA9IHRoaXMuX3Nsb3RzID0ge307XG4gICAgbGV0IG47XG4gICAgd2hpbGUgKG4gPSB0aGlzLmZpcnN0Q2hpbGQpIHtcbiAgICAgIGNvbnN0IHNsb3ROYW1lID0gbi5ub2RlVHlwZSA9PT0gMSAmJiBuLmdldEF0dHJpYnV0ZShcInNsb3RcIikgfHwgXCJkZWZhdWx0XCI7XG4gICAgICAoc2xvdHNbc2xvdE5hbWVdIHx8IChzbG90c1tzbG90TmFtZV0gPSBbXSkpLnB1c2gobik7XG4gICAgICB0aGlzLnJlbW92ZUNoaWxkKG4pO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogT25seSBjYWxsZWQgd2hlbiBzaGFkb3dSb290IGlzIGZhbHNlXG4gICAqL1xuICBfcmVuZGVyU2xvdHMoKSB7XG4gICAgY29uc3Qgb3V0bGV0cyA9IHRoaXMuX2dldFNsb3RzKCk7XG4gICAgY29uc3Qgc2NvcGVJZCA9IHRoaXMuX2luc3RhbmNlLnR5cGUuX19zY29wZUlkO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgb3V0bGV0cy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgbyA9IG91dGxldHNbaV07XG4gICAgICBjb25zdCBzbG90TmFtZSA9IG8uZ2V0QXR0cmlidXRlKFwibmFtZVwiKSB8fCBcImRlZmF1bHRcIjtcbiAgICAgIGNvbnN0IGNvbnRlbnQgPSB0aGlzLl9zbG90c1tzbG90TmFtZV07XG4gICAgICBjb25zdCBwYXJlbnQgPSBvLnBhcmVudE5vZGU7XG4gICAgICBpZiAoY29udGVudCkge1xuICAgICAgICBmb3IgKGNvbnN0IG4gb2YgY29udGVudCkge1xuICAgICAgICAgIGlmIChzY29wZUlkICYmIG4ubm9kZVR5cGUgPT09IDEpIHtcbiAgICAgICAgICAgIGNvbnN0IGlkID0gc2NvcGVJZCArIFwiLXNcIjtcbiAgICAgICAgICAgIGNvbnN0IHdhbGtlciA9IGRvY3VtZW50LmNyZWF0ZVRyZWVXYWxrZXIobiwgMSk7XG4gICAgICAgICAgICBuLnNldEF0dHJpYnV0ZShpZCwgXCJcIik7XG4gICAgICAgICAgICBsZXQgY2hpbGQ7XG4gICAgICAgICAgICB3aGlsZSAoY2hpbGQgPSB3YWxrZXIubmV4dE5vZGUoKSkge1xuICAgICAgICAgICAgICBjaGlsZC5zZXRBdHRyaWJ1dGUoaWQsIFwiXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBwYXJlbnQuaW5zZXJ0QmVmb3JlKG4sIG8pO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB3aGlsZSAoby5maXJzdENoaWxkKSBwYXJlbnQuaW5zZXJ0QmVmb3JlKG8uZmlyc3RDaGlsZCwgbyk7XG4gICAgICB9XG4gICAgICBwYXJlbnQucmVtb3ZlQ2hpbGQobyk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIF9nZXRTbG90cygpIHtcbiAgICBjb25zdCByb290cyA9IFt0aGlzXTtcbiAgICBpZiAodGhpcy5fdGVsZXBvcnRUYXJnZXRzKSB7XG4gICAgICByb290cy5wdXNoKC4uLnRoaXMuX3RlbGVwb3J0VGFyZ2V0cyk7XG4gICAgfVxuICAgIGNvbnN0IHNsb3RzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcbiAgICBmb3IgKGNvbnN0IHJvb3Qgb2Ygcm9vdHMpIHtcbiAgICAgIGNvbnN0IGZvdW5kID0gcm9vdC5xdWVyeVNlbGVjdG9yQWxsKFwic2xvdFwiKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZm91bmQubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgc2xvdHMuYWRkKGZvdW5kW2ldKTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIEFycmF5LmZyb20oc2xvdHMpO1xuICB9XG4gIC8qKlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIF9pbmplY3RDaGlsZFN0eWxlKGNvbXAsIHBhcmVudENvbXApIHtcbiAgICB0aGlzLl9hcHBseVN0eWxlcyhjb21wLnN0eWxlcywgY29tcCwgcGFyZW50Q29tcCk7XG4gIH1cbiAgLyoqXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgX2JlZ2luUGF0Y2goKSB7XG4gICAgdGhpcy5fcGF0Y2hpbmcgPSB0cnVlO1xuICAgIHRoaXMuX2RpcnR5ID0gZmFsc2U7XG4gIH1cbiAgLyoqXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgX2VuZFBhdGNoKCkge1xuICAgIHRoaXMuX3BhdGNoaW5nID0gZmFsc2U7XG4gICAgaWYgKHRoaXMuX2RpcnR5ICYmIHRoaXMuX2luc3RhbmNlKSB7XG4gICAgICB0aGlzLl91cGRhdGUoKTtcbiAgICB9XG4gIH1cbiAgLyoqXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgX2hhc1NoYWRvd1Jvb3QoKSB7XG4gICAgcmV0dXJuIHRoaXMuX2RlZi5zaGFkb3dSb290ICE9PSBmYWxzZTtcbiAgfVxuICAvKipcbiAgICogQGludGVybmFsXG4gICAqL1xuICBfcmVtb3ZlQ2hpbGRTdHlsZShjb21wKSB7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgIHRoaXMuX3N0eWxlQ2hpbGRyZW4uZGVsZXRlKGNvbXApO1xuICAgICAgdGhpcy5fc3R5bGVBbmNob3JzLmRlbGV0ZShjb21wKTtcbiAgICAgIGlmICh0aGlzLl9jaGlsZFN0eWxlcyAmJiBjb21wLl9faG1ySWQpIHtcbiAgICAgICAgY29uc3Qgb2xkU3R5bGVzID0gdGhpcy5fY2hpbGRTdHlsZXMuZ2V0KGNvbXAuX19obXJJZCk7XG4gICAgICAgIGlmIChvbGRTdHlsZXMpIHtcbiAgICAgICAgICBvbGRTdHlsZXMuZm9yRWFjaCgocykgPT4gdGhpcy5fcm9vdC5yZW1vdmVDaGlsZChzKSk7XG4gICAgICAgICAgb2xkU3R5bGVzLmxlbmd0aCA9IDA7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIHVzZUhvc3QoY2FsbGVyKSB7XG4gIGNvbnN0IGluc3RhbmNlID0gZ2V0Q3VycmVudEluc3RhbmNlKCk7XG4gIGNvbnN0IGVsID0gaW5zdGFuY2UgJiYgaW5zdGFuY2UuY2U7XG4gIGlmIChlbCkge1xuICAgIHJldHVybiBlbDtcbiAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgaWYgKCFpbnN0YW5jZSkge1xuICAgICAgd2FybihcbiAgICAgICAgYCR7Y2FsbGVyIHx8IFwidXNlSG9zdFwifSBjYWxsZWQgd2l0aG91dCBhbiBhY3RpdmUgY29tcG9uZW50IGluc3RhbmNlLmBcbiAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHdhcm4oXG4gICAgICAgIGAke2NhbGxlciB8fCBcInVzZUhvc3RcIn0gY2FuIG9ubHkgYmUgdXNlZCBpbiBjb21wb25lbnRzIGRlZmluZWQgdmlhIGRlZmluZUN1c3RvbUVsZW1lbnQuYFxuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiB1c2VTaGFkb3dSb290KCkge1xuICBjb25zdCBlbCA9ICEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgPyB1c2VIb3N0KFwidXNlU2hhZG93Um9vdFwiKSA6IHVzZUhvc3QoKTtcbiAgcmV0dXJuIGVsICYmIGVsLnNoYWRvd1Jvb3Q7XG59XG5cbmZ1bmN0aW9uIHVzZUNzc01vZHVsZShuYW1lID0gXCIkc3R5bGVcIikge1xuICB7XG4gICAgY29uc3QgaW5zdGFuY2UgPSBnZXRDdXJyZW50SW5zdGFuY2UoKTtcbiAgICBpZiAoIWluc3RhbmNlKSB7XG4gICAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdhcm4oYHVzZUNzc01vZHVsZSBtdXN0IGJlIGNhbGxlZCBpbnNpZGUgc2V0dXAoKWApO1xuICAgICAgcmV0dXJuIEVNUFRZX09CSjtcbiAgICB9XG4gICAgY29uc3QgbW9kdWxlcyA9IGluc3RhbmNlLnR5cGUuX19jc3NNb2R1bGVzO1xuICAgIGlmICghbW9kdWxlcykge1xuICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB3YXJuKGBDdXJyZW50IGluc3RhbmNlIGRvZXMgbm90IGhhdmUgQ1NTIG1vZHVsZXMgaW5qZWN0ZWQuYCk7XG4gICAgICByZXR1cm4gRU1QVFlfT0JKO1xuICAgIH1cbiAgICBjb25zdCBtb2QgPSBtb2R1bGVzW25hbWVdO1xuICAgIGlmICghbW9kKSB7XG4gICAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdhcm4oYEN1cnJlbnQgaW5zdGFuY2UgZG9lcyBub3QgaGF2ZSBDU1MgbW9kdWxlIG5hbWVkIFwiJHtuYW1lfVwiLmApO1xuICAgICAgcmV0dXJuIEVNUFRZX09CSjtcbiAgICB9XG4gICAgcmV0dXJuIG1vZDtcbiAgfVxufVxuXG5jb25zdCBwb3NpdGlvbk1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuY29uc3QgbmV3UG9zaXRpb25NYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbmNvbnN0IG1vdmVDYktleSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJfbW92ZUNiXCIpO1xuY29uc3QgZW50ZXJDYktleSA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJfZW50ZXJDYlwiKTtcbmNvbnN0IGRlY29yYXRlID0gKHQpID0+IHtcbiAgZGVsZXRlIHQucHJvcHMubW9kZTtcbiAgcmV0dXJuIHQ7XG59O1xuY29uc3QgVHJhbnNpdGlvbkdyb3VwSW1wbCA9IC8qIEBfX1BVUkVfXyAqLyBkZWNvcmF0ZSh7XG4gIG5hbWU6IFwiVHJhbnNpdGlvbkdyb3VwXCIsXG4gIHByb3BzOiAvKiBAX19QVVJFX18gKi8gZXh0ZW5kKHt9LCBUcmFuc2l0aW9uUHJvcHNWYWxpZGF0b3JzLCB7XG4gICAgdGFnOiBTdHJpbmcsXG4gICAgbW92ZUNsYXNzOiBTdHJpbmdcbiAgfSksXG4gIHNldHVwKHByb3BzLCB7IHNsb3RzIH0pIHtcbiAgICBjb25zdCBpbnN0YW5jZSA9IGdldEN1cnJlbnRJbnN0YW5jZSgpO1xuICAgIGNvbnN0IHN0YXRlID0gdXNlVHJhbnNpdGlvblN0YXRlKCk7XG4gICAgbGV0IHByZXZDaGlsZHJlbjtcbiAgICBsZXQgY2hpbGRyZW47XG4gICAgb25VcGRhdGVkKCgpID0+IHtcbiAgICAgIGlmICghcHJldkNoaWxkcmVuLmxlbmd0aCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBtb3ZlQ2xhc3MgPSBwcm9wcy5tb3ZlQ2xhc3MgfHwgYCR7cHJvcHMubmFtZSB8fCBcInZcIn0tbW92ZWA7XG4gICAgICBpZiAoIWhhc0NTU1RyYW5zZm9ybShcbiAgICAgICAgcHJldkNoaWxkcmVuWzBdLmVsLFxuICAgICAgICBpbnN0YW5jZS52bm9kZS5lbCxcbiAgICAgICAgbW92ZUNsYXNzXG4gICAgICApKSB7XG4gICAgICAgIHByZXZDaGlsZHJlbiA9IFtdO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBwcmV2Q2hpbGRyZW4uZm9yRWFjaChjYWxsUGVuZGluZ0Nicyk7XG4gICAgICBwcmV2Q2hpbGRyZW4uZm9yRWFjaChyZWNvcmRQb3NpdGlvbik7XG4gICAgICBjb25zdCBtb3ZlZENoaWxkcmVuID0gcHJldkNoaWxkcmVuLmZpbHRlcihhcHBseVRyYW5zbGF0aW9uKTtcbiAgICAgIGZvcmNlUmVmbG93KGluc3RhbmNlLnZub2RlLmVsKTtcbiAgICAgIG1vdmVkQ2hpbGRyZW4uZm9yRWFjaCgoYykgPT4ge1xuICAgICAgICBjb25zdCBlbCA9IGMuZWw7XG4gICAgICAgIGNvbnN0IHN0eWxlID0gZWwuc3R5bGU7XG4gICAgICAgIGFkZFRyYW5zaXRpb25DbGFzcyhlbCwgbW92ZUNsYXNzKTtcbiAgICAgICAgc3R5bGUudHJhbnNmb3JtID0gc3R5bGUud2Via2l0VHJhbnNmb3JtID0gc3R5bGUudHJhbnNpdGlvbkR1cmF0aW9uID0gXCJcIjtcbiAgICAgICAgY29uc3QgY2IgPSBlbFttb3ZlQ2JLZXldID0gKGUpID0+IHtcbiAgICAgICAgICBpZiAoZSAmJiBlLnRhcmdldCAhPT0gZWwpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKCFlIHx8IGUucHJvcGVydHlOYW1lLmVuZHNXaXRoKFwidHJhbnNmb3JtXCIpKSB7XG4gICAgICAgICAgICBlbC5yZW1vdmVFdmVudExpc3RlbmVyKFwidHJhbnNpdGlvbmVuZFwiLCBjYik7XG4gICAgICAgICAgICBlbFttb3ZlQ2JLZXldID0gbnVsbDtcbiAgICAgICAgICAgIHJlbW92ZVRyYW5zaXRpb25DbGFzcyhlbCwgbW92ZUNsYXNzKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICAgIGVsLmFkZEV2ZW50TGlzdGVuZXIoXCJ0cmFuc2l0aW9uZW5kXCIsIGNiKTtcbiAgICAgIH0pO1xuICAgICAgcHJldkNoaWxkcmVuID0gW107XG4gICAgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGNvbnN0IHJhd1Byb3BzID0gdG9SYXcocHJvcHMpO1xuICAgICAgY29uc3QgY3NzVHJhbnNpdGlvblByb3BzID0gcmVzb2x2ZVRyYW5zaXRpb25Qcm9wcyhyYXdQcm9wcyk7XG4gICAgICBsZXQgdGFnID0gcmF3UHJvcHMudGFnIHx8IEZyYWdtZW50O1xuICAgICAgcHJldkNoaWxkcmVuID0gW107XG4gICAgICBpZiAoY2hpbGRyZW4pIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjaGlsZHJlbi5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIGNvbnN0IGNoaWxkID0gY2hpbGRyZW5baV07XG4gICAgICAgICAgaWYgKGNoaWxkLmVsICYmIGNoaWxkLmVsIGluc3RhbmNlb2YgRWxlbWVudCAmJiAvLyBIaWRkZW4gdi1zaG93IG5vZGVzIGhhdmUgbm8gcHJldmlvdXMgbGF5b3V0IGJveCB0byBhbmltYXRlIGZyb20uXG4gICAgICAgICAgIWNoaWxkLmVsW3ZTaG93SGlkZGVuXSkge1xuICAgICAgICAgICAgcHJldkNoaWxkcmVuLnB1c2goY2hpbGQpO1xuICAgICAgICAgICAgc2V0VHJhbnNpdGlvbkhvb2tzKFxuICAgICAgICAgICAgICBjaGlsZCxcbiAgICAgICAgICAgICAgcmVzb2x2ZVRyYW5zaXRpb25Ib29rcyhcbiAgICAgICAgICAgICAgICBjaGlsZCxcbiAgICAgICAgICAgICAgICBjc3NUcmFuc2l0aW9uUHJvcHMsXG4gICAgICAgICAgICAgICAgc3RhdGUsXG4gICAgICAgICAgICAgICAgaW5zdGFuY2VcbiAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIHBvc2l0aW9uTWFwLnNldChjaGlsZCwgZ2V0UG9zaXRpb24oY2hpbGQuZWwpKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGNoaWxkcmVuID0gc2xvdHMuZGVmYXVsdCA/IGdldFRyYW5zaXRpb25SYXdDaGlsZHJlbihzbG90cy5kZWZhdWx0KCkpIDogW107XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGNoaWxkcmVuLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNvbnN0IGNoaWxkID0gY2hpbGRyZW5baV07XG4gICAgICAgIGlmIChjaGlsZC5rZXkgIT0gbnVsbCkge1xuICAgICAgICAgIHNldFRyYW5zaXRpb25Ib29rcyhcbiAgICAgICAgICAgIGNoaWxkLFxuICAgICAgICAgICAgcmVzb2x2ZVRyYW5zaXRpb25Ib29rcyhjaGlsZCwgY3NzVHJhbnNpdGlvblByb3BzLCBzdGF0ZSwgaW5zdGFuY2UpXG4gICAgICAgICAgKTtcbiAgICAgICAgfSBlbHNlIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGNoaWxkLnR5cGUgIT09IFRleHQpIHtcbiAgICAgICAgICB3YXJuKGA8VHJhbnNpdGlvbkdyb3VwPiBjaGlsZHJlbiBtdXN0IGJlIGtleWVkLmApO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gY3JlYXRlVk5vZGUodGFnLCBudWxsLCBjaGlsZHJlbik7XG4gICAgfTtcbiAgfVxufSk7XG5jb25zdCBUcmFuc2l0aW9uR3JvdXAgPSBUcmFuc2l0aW9uR3JvdXBJbXBsO1xuZnVuY3Rpb24gY2FsbFBlbmRpbmdDYnMoYykge1xuICBjb25zdCBlbCA9IGMuZWw7XG4gIGlmIChlbFttb3ZlQ2JLZXldKSB7XG4gICAgZWxbbW92ZUNiS2V5XSgpO1xuICB9XG4gIGlmIChlbFtlbnRlckNiS2V5XSkge1xuICAgIGVsW2VudGVyQ2JLZXldKCk7XG4gIH1cbn1cbmZ1bmN0aW9uIHJlY29yZFBvc2l0aW9uKGMpIHtcbiAgbmV3UG9zaXRpb25NYXAuc2V0KGMsIGdldFBvc2l0aW9uKGMuZWwpKTtcbn1cbmZ1bmN0aW9uIGFwcGx5VHJhbnNsYXRpb24oYykge1xuICBjb25zdCBvbGRQb3MgPSBwb3NpdGlvbk1hcC5nZXQoYyk7XG4gIGNvbnN0IG5ld1BvcyA9IG5ld1Bvc2l0aW9uTWFwLmdldChjKTtcbiAgY29uc3QgZHggPSBvbGRQb3MubGVmdCAtIG5ld1Bvcy5sZWZ0O1xuICBjb25zdCBkeSA9IG9sZFBvcy50b3AgLSBuZXdQb3MudG9wO1xuICBpZiAoZHggfHwgZHkpIHtcbiAgICBjb25zdCBlbCA9IGMuZWw7XG4gICAgY29uc3QgcyA9IGVsLnN0eWxlO1xuICAgIGNvbnN0IHJlY3QgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBsZXQgc2NhbGVYID0gMTtcbiAgICBsZXQgc2NhbGVZID0gMTtcbiAgICBpZiAoZWwub2Zmc2V0V2lkdGgpIHNjYWxlWCA9IHJlY3Qud2lkdGggLyBlbC5vZmZzZXRXaWR0aDtcbiAgICBpZiAoZWwub2Zmc2V0SGVpZ2h0KSBzY2FsZVkgPSByZWN0LmhlaWdodCAvIGVsLm9mZnNldEhlaWdodDtcbiAgICBpZiAoIU51bWJlci5pc0Zpbml0ZShzY2FsZVgpIHx8IHNjYWxlWCA9PT0gMCkgc2NhbGVYID0gMTtcbiAgICBpZiAoIU51bWJlci5pc0Zpbml0ZShzY2FsZVkpIHx8IHNjYWxlWSA9PT0gMCkgc2NhbGVZID0gMTtcbiAgICBpZiAoTWF0aC5hYnMoc2NhbGVYIC0gMSkgPCAwLjAxKSBzY2FsZVggPSAxO1xuICAgIGlmIChNYXRoLmFicyhzY2FsZVkgLSAxKSA8IDAuMDEpIHNjYWxlWSA9IDE7XG4gICAgcy50cmFuc2Zvcm0gPSBzLndlYmtpdFRyYW5zZm9ybSA9IGB0cmFuc2xhdGUoJHtkeCAvIHNjYWxlWH1weCwke2R5IC8gc2NhbGVZfXB4KWA7XG4gICAgcy50cmFuc2l0aW9uRHVyYXRpb24gPSBcIjBzXCI7XG4gICAgcmV0dXJuIGM7XG4gIH1cbn1cbmZ1bmN0aW9uIGdldFBvc2l0aW9uKGVsKSB7XG4gIGNvbnN0IHJlY3QgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgcmV0dXJuIHtcbiAgICBsZWZ0OiByZWN0LmxlZnQsXG4gICAgdG9wOiByZWN0LnRvcFxuICB9O1xufVxuZnVuY3Rpb24gaGFzQ1NTVHJhbnNmb3JtKGVsLCByb290LCBtb3ZlQ2xhc3MpIHtcbiAgY29uc3QgY2xvbmUgPSBlbC5jbG9uZU5vZGUoKTtcbiAgY29uc3QgX3Z0YyA9IGVsW3Z0Y0tleV07XG4gIGlmIChfdnRjKSB7XG4gICAgX3Z0Yy5mb3JFYWNoKChjbHMpID0+IHtcbiAgICAgIGNscy5zcGxpdCgvXFxzKy8pLmZvckVhY2goKGMpID0+IGMgJiYgY2xvbmUuY2xhc3NMaXN0LnJlbW92ZShjKSk7XG4gICAgfSk7XG4gIH1cbiAgbW92ZUNsYXNzLnNwbGl0KC9cXHMrLykuZm9yRWFjaCgoYykgPT4gYyAmJiBjbG9uZS5jbGFzc0xpc3QuYWRkKGMpKTtcbiAgY2xvbmUuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICBjb25zdCBjb250YWluZXIgPSByb290Lm5vZGVUeXBlID09PSAxID8gcm9vdCA6IHJvb3QucGFyZW50Tm9kZTtcbiAgY29udGFpbmVyLmFwcGVuZENoaWxkKGNsb25lKTtcbiAgY29uc3QgeyBoYXNUcmFuc2Zvcm0gfSA9IGdldFRyYW5zaXRpb25JbmZvKGNsb25lKTtcbiAgY29udGFpbmVyLnJlbW92ZUNoaWxkKGNsb25lKTtcbiAgcmV0dXJuIGhhc1RyYW5zZm9ybTtcbn1cblxuY29uc3QgZ2V0TW9kZWxBc3NpZ25lciA9ICh2bm9kZSkgPT4ge1xuICBjb25zdCBmbiA9IHZub2RlLnByb3BzW1wib25VcGRhdGU6bW9kZWxWYWx1ZVwiXSB8fCBmYWxzZTtcbiAgcmV0dXJuIGlzQXJyYXkoZm4pID8gKHZhbHVlKSA9PiBpbnZva2VBcnJheUZucyhmbiwgdmFsdWUpIDogZm47XG59O1xuZnVuY3Rpb24gb25Db21wb3NpdGlvblN0YXJ0KGUpIHtcbiAgZS50YXJnZXQuY29tcG9zaW5nID0gdHJ1ZTtcbn1cbmZ1bmN0aW9uIG9uQ29tcG9zaXRpb25FbmQoZSkge1xuICBjb25zdCB0YXJnZXQgPSBlLnRhcmdldDtcbiAgaWYgKHRhcmdldC5jb21wb3NpbmcpIHtcbiAgICB0YXJnZXQuY29tcG9zaW5nID0gZmFsc2U7XG4gICAgdGFyZ2V0LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiaW5wdXRcIikpO1xuICB9XG59XG5jb25zdCBhc3NpZ25LZXkgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sKFwiX2Fzc2lnblwiKTtcbmZ1bmN0aW9uIGNhc3RWYWx1ZSh2YWx1ZSwgdHJpbSwgbnVtYmVyKSB7XG4gIGlmICh0cmltKSB2YWx1ZSA9IHZhbHVlLnRyaW0oKTtcbiAgaWYgKG51bWJlcikgdmFsdWUgPSBsb29zZVRvTnVtYmVyKHZhbHVlKTtcbiAgcmV0dXJuIHZhbHVlO1xufVxuY29uc3Qgdk1vZGVsVGV4dCA9IHtcbiAgY3JlYXRlZChlbCwgeyBtb2RpZmllcnM6IHsgbGF6eSwgdHJpbSwgbnVtYmVyIH0gfSwgdm5vZGUpIHtcbiAgICBlbFthc3NpZ25LZXldID0gZ2V0TW9kZWxBc3NpZ25lcih2bm9kZSk7XG4gICAgY29uc3QgY2FzdFRvTnVtYmVyID0gbnVtYmVyIHx8IHZub2RlLnByb3BzICYmIHZub2RlLnByb3BzLnR5cGUgPT09IFwibnVtYmVyXCI7XG4gICAgYWRkRXZlbnRMaXN0ZW5lcihlbCwgbGF6eSA/IFwiY2hhbmdlXCIgOiBcImlucHV0XCIsIChlKSA9PiB7XG4gICAgICBpZiAoZS50YXJnZXQuY29tcG9zaW5nKSByZXR1cm47XG4gICAgICBlbFthc3NpZ25LZXldKGNhc3RWYWx1ZShlbC52YWx1ZSwgdHJpbSwgY2FzdFRvTnVtYmVyKSk7XG4gICAgfSk7XG4gICAgaWYgKHRyaW0gfHwgY2FzdFRvTnVtYmVyKSB7XG4gICAgICBhZGRFdmVudExpc3RlbmVyKGVsLCBcImNoYW5nZVwiLCAoKSA9PiB7XG4gICAgICAgIGVsLnZhbHVlID0gY2FzdFZhbHVlKGVsLnZhbHVlLCB0cmltLCBjYXN0VG9OdW1iZXIpO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGlmICghbGF6eSkge1xuICAgICAgYWRkRXZlbnRMaXN0ZW5lcihlbCwgXCJjb21wb3NpdGlvbnN0YXJ0XCIsIG9uQ29tcG9zaXRpb25TdGFydCk7XG4gICAgICBhZGRFdmVudExpc3RlbmVyKGVsLCBcImNvbXBvc2l0aW9uZW5kXCIsIG9uQ29tcG9zaXRpb25FbmQpO1xuICAgICAgYWRkRXZlbnRMaXN0ZW5lcihlbCwgXCJjaGFuZ2VcIiwgb25Db21wb3NpdGlvbkVuZCk7XG4gICAgfVxuICB9LFxuICAvLyBzZXQgdmFsdWUgb24gbW91bnRlZCBzbyBpdCdzIGFmdGVyIG1pbi9tYXggZm9yIHR5cGU9XCJyYW5nZVwiXG4gIG1vdW50ZWQoZWwsIHsgdmFsdWUgfSkge1xuICAgIGVsLnZhbHVlID0gdmFsdWUgPT0gbnVsbCA/IFwiXCIgOiB2YWx1ZTtcbiAgfSxcbiAgYmVmb3JlVXBkYXRlKGVsLCB7IHZhbHVlLCBvbGRWYWx1ZSwgbW9kaWZpZXJzOiB7IGxhenksIHRyaW0sIG51bWJlciB9IH0sIHZub2RlKSB7XG4gICAgZWxbYXNzaWduS2V5XSA9IGdldE1vZGVsQXNzaWduZXIodm5vZGUpO1xuICAgIGlmIChlbC5jb21wb3NpbmcpIHJldHVybjtcbiAgICBjb25zdCBlbFZhbHVlID0gKG51bWJlciB8fCBlbC50eXBlID09PSBcIm51bWJlclwiKSAmJiAhL14wXFxkLy50ZXN0KGVsLnZhbHVlKSA/IGxvb3NlVG9OdW1iZXIoZWwudmFsdWUpIDogZWwudmFsdWU7XG4gICAgY29uc3QgbmV3VmFsdWUgPSB2YWx1ZSA9PSBudWxsID8gXCJcIiA6IHZhbHVlO1xuICAgIGlmIChlbFZhbHVlID09PSBuZXdWYWx1ZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCByb290Tm9kZSA9IGVsLmdldFJvb3ROb2RlKCk7XG4gICAgaWYgKChyb290Tm9kZSBpbnN0YW5jZW9mIERvY3VtZW50IHx8IHJvb3ROb2RlIGluc3RhbmNlb2YgU2hhZG93Um9vdCkgJiYgcm9vdE5vZGUuYWN0aXZlRWxlbWVudCA9PT0gZWwgJiYgZWwudHlwZSAhPT0gXCJyYW5nZVwiKSB7XG4gICAgICBpZiAobGF6eSAmJiB2YWx1ZSA9PT0gb2xkVmFsdWUpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKHRyaW0gJiYgZWwudmFsdWUudHJpbSgpID09PSBuZXdWYWx1ZSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfVxuICAgIGVsLnZhbHVlID0gbmV3VmFsdWU7XG4gIH1cbn07XG5jb25zdCB2TW9kZWxDaGVja2JveCA9IHtcbiAgLy8gIzQwOTYgYXJyYXkgY2hlY2tib3hlcyBuZWVkIHRvIGJlIGRlZXAgdHJhdmVyc2VkXG4gIGRlZXA6IHRydWUsXG4gIGNyZWF0ZWQoZWwsIF8sIHZub2RlKSB7XG4gICAgZWxbYXNzaWduS2V5XSA9IGdldE1vZGVsQXNzaWduZXIodm5vZGUpO1xuICAgIGFkZEV2ZW50TGlzdGVuZXIoZWwsIFwiY2hhbmdlXCIsICgpID0+IHtcbiAgICAgIGNvbnN0IG1vZGVsVmFsdWUgPSBlbC5fbW9kZWxWYWx1ZTtcbiAgICAgIGNvbnN0IGVsZW1lbnRWYWx1ZSA9IGdldFZhbHVlKGVsKTtcbiAgICAgIGNvbnN0IGNoZWNrZWQgPSBlbC5jaGVja2VkO1xuICAgICAgY29uc3QgYXNzaWduID0gZWxbYXNzaWduS2V5XTtcbiAgICAgIGlmIChpc0FycmF5KG1vZGVsVmFsdWUpKSB7XG4gICAgICAgIGNvbnN0IGluZGV4ID0gbG9vc2VJbmRleE9mKG1vZGVsVmFsdWUsIGVsZW1lbnRWYWx1ZSk7XG4gICAgICAgIGNvbnN0IGZvdW5kID0gaW5kZXggIT09IC0xO1xuICAgICAgICBpZiAoY2hlY2tlZCAmJiAhZm91bmQpIHtcbiAgICAgICAgICBhc3NpZ24obW9kZWxWYWx1ZS5jb25jYXQoZWxlbWVudFZhbHVlKSk7XG4gICAgICAgIH0gZWxzZSBpZiAoIWNoZWNrZWQgJiYgZm91bmQpIHtcbiAgICAgICAgICBjb25zdCBmaWx0ZXJlZCA9IFsuLi5tb2RlbFZhbHVlXTtcbiAgICAgICAgICBmaWx0ZXJlZC5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgICAgIGFzc2lnbihmaWx0ZXJlZCk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSBpZiAoaXNTZXQobW9kZWxWYWx1ZSkpIHtcbiAgICAgICAgY29uc3QgY2xvbmVkID0gbmV3IFNldChtb2RlbFZhbHVlKTtcbiAgICAgICAgaWYgKGNoZWNrZWQpIHtcbiAgICAgICAgICBjbG9uZWQuYWRkKGVsZW1lbnRWYWx1ZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY2xvbmVkLmRlbGV0ZShlbGVtZW50VmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIGFzc2lnbihjbG9uZWQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYXNzaWduKGdldENoZWNrYm94VmFsdWUoZWwsIGNoZWNrZWQpKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSxcbiAgLy8gc2V0IGluaXRpYWwgY2hlY2tlZCBvbiBtb3VudCB0byB3YWl0IGZvciB0cnVlLXZhbHVlL2ZhbHNlLXZhbHVlXG4gIG1vdW50ZWQ6IHNldENoZWNrZWQsXG4gIGJlZm9yZVVwZGF0ZShlbCwgYmluZGluZywgdm5vZGUpIHtcbiAgICBlbFthc3NpZ25LZXldID0gZ2V0TW9kZWxBc3NpZ25lcih2bm9kZSk7XG4gICAgc2V0Q2hlY2tlZChlbCwgYmluZGluZywgdm5vZGUpO1xuICB9XG59O1xuZnVuY3Rpb24gc2V0Q2hlY2tlZChlbCwgeyB2YWx1ZSwgb2xkVmFsdWUgfSwgdm5vZGUpIHtcbiAgZWwuX21vZGVsVmFsdWUgPSB2YWx1ZTtcbiAgbGV0IGNoZWNrZWQ7XG4gIGlmIChpc0FycmF5KHZhbHVlKSkge1xuICAgIGNoZWNrZWQgPSBsb29zZUluZGV4T2YodmFsdWUsIHZub2RlLnByb3BzLnZhbHVlKSA+IC0xO1xuICB9IGVsc2UgaWYgKGlzU2V0KHZhbHVlKSkge1xuICAgIGNoZWNrZWQgPSB2YWx1ZS5oYXModm5vZGUucHJvcHMudmFsdWUpO1xuICB9IGVsc2Uge1xuICAgIGlmICh2YWx1ZSA9PT0gb2xkVmFsdWUpIHJldHVybjtcbiAgICBjaGVja2VkID0gbG9vc2VFcXVhbCh2YWx1ZSwgZ2V0Q2hlY2tib3hWYWx1ZShlbCwgdHJ1ZSkpO1xuICB9XG4gIGlmIChlbC5jaGVja2VkICE9PSBjaGVja2VkKSB7XG4gICAgZWwuY2hlY2tlZCA9IGNoZWNrZWQ7XG4gIH1cbn1cbmNvbnN0IHZNb2RlbFJhZGlvID0ge1xuICBjcmVhdGVkKGVsLCB7IHZhbHVlIH0sIHZub2RlKSB7XG4gICAgZWwuY2hlY2tlZCA9IGxvb3NlRXF1YWwodmFsdWUsIHZub2RlLnByb3BzLnZhbHVlKTtcbiAgICBlbFthc3NpZ25LZXldID0gZ2V0TW9kZWxBc3NpZ25lcih2bm9kZSk7XG4gICAgYWRkRXZlbnRMaXN0ZW5lcihlbCwgXCJjaGFuZ2VcIiwgKCkgPT4ge1xuICAgICAgZWxbYXNzaWduS2V5XShnZXRWYWx1ZShlbCkpO1xuICAgIH0pO1xuICB9LFxuICBiZWZvcmVVcGRhdGUoZWwsIHsgdmFsdWUsIG9sZFZhbHVlIH0sIHZub2RlKSB7XG4gICAgZWxbYXNzaWduS2V5XSA9IGdldE1vZGVsQXNzaWduZXIodm5vZGUpO1xuICAgIGlmICh2YWx1ZSAhPT0gb2xkVmFsdWUpIHtcbiAgICAgIGVsLmNoZWNrZWQgPSBsb29zZUVxdWFsKHZhbHVlLCB2bm9kZS5wcm9wcy52YWx1ZSk7XG4gICAgfVxuICB9XG59O1xuY29uc3Qgdk1vZGVsU2VsZWN0ID0ge1xuICAvLyA8c2VsZWN0IG11bHRpcGxlPiB2YWx1ZSBuZWVkIHRvIGJlIGRlZXAgdHJhdmVyc2VkXG4gIGRlZXA6IHRydWUsXG4gIGNyZWF0ZWQoZWwsIHsgdmFsdWUsIG1vZGlmaWVyczogeyBudW1iZXIgfSB9LCB2bm9kZSkge1xuICAgIGVsLl9tb2RlbFZhbHVlID0gdmFsdWU7XG4gICAgYWRkRXZlbnRMaXN0ZW5lcihlbCwgXCJjaGFuZ2VcIiwgKCkgPT4ge1xuICAgICAgY29uc3Qgc2VsZWN0ZWRWYWwgPSBBcnJheS5wcm90b3R5cGUuZmlsdGVyLmNhbGwoZWwub3B0aW9ucywgKG8pID0+IG8uc2VsZWN0ZWQpLm1hcChcbiAgICAgICAgKG8pID0+IG51bWJlciA/IGxvb3NlVG9OdW1iZXIoZ2V0VmFsdWUobykpIDogZ2V0VmFsdWUobylcbiAgICAgICk7XG4gICAgICBlbFthc3NpZ25LZXldKFxuICAgICAgICBlbC5tdWx0aXBsZSA/IGlzU2V0KGVsLl9tb2RlbFZhbHVlKSA/IG5ldyBTZXQoc2VsZWN0ZWRWYWwpIDogc2VsZWN0ZWRWYWwgOiBzZWxlY3RlZFZhbFswXVxuICAgICAgKTtcbiAgICAgIGVsLl9hc3NpZ25pbmcgPSB0cnVlO1xuICAgICAgbmV4dFRpY2soKCkgPT4ge1xuICAgICAgICBlbC5fYXNzaWduaW5nID0gZmFsc2U7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgICBlbFthc3NpZ25LZXldID0gZ2V0TW9kZWxBc3NpZ25lcih2bm9kZSk7XG4gIH0sXG4gIC8vIHNldCB2YWx1ZSBpbiBtb3VudGVkICYgdXBkYXRlZCBiZWNhdXNlIDxzZWxlY3Q+IHJlbGllcyBvbiBpdHMgY2hpbGRyZW5cbiAgLy8gPG9wdGlvbj5zLlxuICBtb3VudGVkKGVsLCB7IHZhbHVlIH0pIHtcbiAgICBzZXRTZWxlY3RlZChlbCwgdmFsdWUpO1xuICB9LFxuICBiZWZvcmVVcGRhdGUoZWwsIHsgdmFsdWUgfSwgdm5vZGUpIHtcbiAgICBlbC5fbW9kZWxWYWx1ZSA9IHZhbHVlO1xuICAgIGVsW2Fzc2lnbktleV0gPSBnZXRNb2RlbEFzc2lnbmVyKHZub2RlKTtcbiAgfSxcbiAgdXBkYXRlZChlbCwgeyB2YWx1ZSB9KSB7XG4gICAgaWYgKCFlbC5fYXNzaWduaW5nKSB7XG4gICAgICBzZXRTZWxlY3RlZChlbCwgdmFsdWUpO1xuICAgIH1cbiAgfVxufTtcbmZ1bmN0aW9uIHNldFNlbGVjdGVkKGVsLCB2YWx1ZSkge1xuICBjb25zdCBpc011bHRpcGxlID0gZWwubXVsdGlwbGU7XG4gIGNvbnN0IGlzQXJyYXlWYWx1ZSA9IGlzQXJyYXkodmFsdWUpO1xuICBpZiAoaXNNdWx0aXBsZSAmJiAhaXNBcnJheVZhbHVlICYmICFpc1NldCh2YWx1ZSkpIHtcbiAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdhcm4oXG4gICAgICBgPHNlbGVjdCBtdWx0aXBsZSB2LW1vZGVsPiBleHBlY3RzIGFuIEFycmF5IG9yIFNldCB2YWx1ZSBmb3IgaXRzIGJpbmRpbmcsIGJ1dCBnb3QgJHtPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsdWUpLnNsaWNlKDgsIC0xKX0uYFxuICAgICk7XG4gICAgcmV0dXJuO1xuICB9XG4gIGZvciAobGV0IGkgPSAwLCBsID0gZWwub3B0aW9ucy5sZW5ndGg7IGkgPCBsOyBpKyspIHtcbiAgICBjb25zdCBvcHRpb24gPSBlbC5vcHRpb25zW2ldO1xuICAgIGNvbnN0IG9wdGlvblZhbHVlID0gZ2V0VmFsdWUob3B0aW9uKTtcbiAgICBpZiAoaXNNdWx0aXBsZSkge1xuICAgICAgaWYgKGlzQXJyYXlWYWx1ZSkge1xuICAgICAgICBjb25zdCBvcHRpb25UeXBlID0gdHlwZW9mIG9wdGlvblZhbHVlO1xuICAgICAgICBpZiAob3B0aW9uVHlwZSA9PT0gXCJzdHJpbmdcIiB8fCBvcHRpb25UeXBlID09PSBcIm51bWJlclwiKSB7XG4gICAgICAgICAgb3B0aW9uLnNlbGVjdGVkID0gdmFsdWUuc29tZSgodikgPT4gU3RyaW5nKHYpID09PSBTdHJpbmcob3B0aW9uVmFsdWUpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBvcHRpb24uc2VsZWN0ZWQgPSBsb29zZUluZGV4T2YodmFsdWUsIG9wdGlvblZhbHVlKSA+IC0xO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBvcHRpb24uc2VsZWN0ZWQgPSB2YWx1ZS5oYXMob3B0aW9uVmFsdWUpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAobG9vc2VFcXVhbChnZXRWYWx1ZShvcHRpb24pLCB2YWx1ZSkpIHtcbiAgICAgIGlmIChlbC5zZWxlY3RlZEluZGV4ICE9PSBpKSBlbC5zZWxlY3RlZEluZGV4ID0gaTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gIH1cbiAgaWYgKCFpc011bHRpcGxlICYmIGVsLnNlbGVjdGVkSW5kZXggIT09IC0xKSB7XG4gICAgZWwuc2VsZWN0ZWRJbmRleCA9IC0xO1xuICB9XG59XG5mdW5jdGlvbiBnZXRWYWx1ZShlbCkge1xuICByZXR1cm4gXCJfdmFsdWVcIiBpbiBlbCA/IGVsLl92YWx1ZSA6IGVsLnZhbHVlO1xufVxuZnVuY3Rpb24gZ2V0Q2hlY2tib3hWYWx1ZShlbCwgY2hlY2tlZCkge1xuICBjb25zdCBrZXkgPSBjaGVja2VkID8gXCJfdHJ1ZVZhbHVlXCIgOiBcIl9mYWxzZVZhbHVlXCI7XG4gIHJldHVybiBrZXkgaW4gZWwgPyBlbFtrZXldIDogY2hlY2tlZDtcbn1cbmNvbnN0IHZNb2RlbER5bmFtaWMgPSB7XG4gIGNyZWF0ZWQoZWwsIGJpbmRpbmcsIHZub2RlKSB7XG4gICAgY2FsbE1vZGVsSG9vayhlbCwgYmluZGluZywgdm5vZGUsIG51bGwsIFwiY3JlYXRlZFwiKTtcbiAgfSxcbiAgbW91bnRlZChlbCwgYmluZGluZywgdm5vZGUpIHtcbiAgICBjYWxsTW9kZWxIb29rKGVsLCBiaW5kaW5nLCB2bm9kZSwgbnVsbCwgXCJtb3VudGVkXCIpO1xuICB9LFxuICBiZWZvcmVVcGRhdGUoZWwsIGJpbmRpbmcsIHZub2RlLCBwcmV2Vk5vZGUpIHtcbiAgICBjYWxsTW9kZWxIb29rKGVsLCBiaW5kaW5nLCB2bm9kZSwgcHJldlZOb2RlLCBcImJlZm9yZVVwZGF0ZVwiKTtcbiAgfSxcbiAgdXBkYXRlZChlbCwgYmluZGluZywgdm5vZGUsIHByZXZWTm9kZSkge1xuICAgIGNhbGxNb2RlbEhvb2soZWwsIGJpbmRpbmcsIHZub2RlLCBwcmV2Vk5vZGUsIFwidXBkYXRlZFwiKTtcbiAgfVxufTtcbmZ1bmN0aW9uIHJlc29sdmVEeW5hbWljTW9kZWwodGFnTmFtZSwgdHlwZSkge1xuICBzd2l0Y2ggKHRhZ05hbWUpIHtcbiAgICBjYXNlIFwiU0VMRUNUXCI6XG4gICAgICByZXR1cm4gdk1vZGVsU2VsZWN0O1xuICAgIGNhc2UgXCJURVhUQVJFQVwiOlxuICAgICAgcmV0dXJuIHZNb2RlbFRleHQ7XG4gICAgZGVmYXVsdDpcbiAgICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgICBjYXNlIFwiY2hlY2tib3hcIjpcbiAgICAgICAgICByZXR1cm4gdk1vZGVsQ2hlY2tib3g7XG4gICAgICAgIGNhc2UgXCJyYWRpb1wiOlxuICAgICAgICAgIHJldHVybiB2TW9kZWxSYWRpbztcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICByZXR1cm4gdk1vZGVsVGV4dDtcbiAgICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gY2FsbE1vZGVsSG9vayhlbCwgYmluZGluZywgdm5vZGUsIHByZXZWTm9kZSwgaG9vaykge1xuICBjb25zdCBtb2RlbFRvVXNlID0gcmVzb2x2ZUR5bmFtaWNNb2RlbChcbiAgICBlbC50YWdOYW1lLFxuICAgIHZub2RlLnByb3BzICYmIHZub2RlLnByb3BzLnR5cGVcbiAgKTtcbiAgY29uc3QgZm4gPSBtb2RlbFRvVXNlW2hvb2tdO1xuICBmbiAmJiBmbihlbCwgYmluZGluZywgdm5vZGUsIHByZXZWTm9kZSk7XG59XG5mdW5jdGlvbiBpbml0Vk1vZGVsRm9yU1NSKCkge1xuICB2TW9kZWxUZXh0LmdldFNTUlByb3BzID0gKHsgdmFsdWUgfSkgPT4gKHsgdmFsdWUgfSk7XG4gIHZNb2RlbFJhZGlvLmdldFNTUlByb3BzID0gKHsgdmFsdWUgfSwgdm5vZGUpID0+IHtcbiAgICBpZiAodm5vZGUucHJvcHMgJiYgbG9vc2VFcXVhbCh2bm9kZS5wcm9wcy52YWx1ZSwgdmFsdWUpKSB7XG4gICAgICByZXR1cm4geyBjaGVja2VkOiB0cnVlIH07XG4gICAgfVxuICB9O1xuICB2TW9kZWxDaGVja2JveC5nZXRTU1JQcm9wcyA9ICh7IHZhbHVlIH0sIHZub2RlKSA9PiB7XG4gICAgaWYgKGlzQXJyYXkodmFsdWUpKSB7XG4gICAgICBpZiAodm5vZGUucHJvcHMgJiYgbG9vc2VJbmRleE9mKHZhbHVlLCB2bm9kZS5wcm9wcy52YWx1ZSkgPiAtMSkge1xuICAgICAgICByZXR1cm4geyBjaGVja2VkOiB0cnVlIH07XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChpc1NldCh2YWx1ZSkpIHtcbiAgICAgIGlmICh2bm9kZS5wcm9wcyAmJiB2YWx1ZS5oYXModm5vZGUucHJvcHMudmFsdWUpKSB7XG4gICAgICAgIHJldHVybiB7IGNoZWNrZWQ6IHRydWUgfTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHZhbHVlKSB7XG4gICAgICByZXR1cm4geyBjaGVja2VkOiB0cnVlIH07XG4gICAgfVxuICB9O1xuICB2TW9kZWxEeW5hbWljLmdldFNTUlByb3BzID0gKGJpbmRpbmcsIHZub2RlKSA9PiB7XG4gICAgaWYgKHR5cGVvZiB2bm9kZS50eXBlICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IG1vZGVsVG9Vc2UgPSByZXNvbHZlRHluYW1pY01vZGVsKFxuICAgICAgLy8gcmVzb2x2ZUR5bmFtaWNNb2RlbCBleHBlY3RzIGFuIHVwcGVyY2FzZSB0YWcgbmFtZSwgYnV0IHZub2RlLnR5cGUgaXMgbG93ZXJjYXNlXG4gICAgICB2bm9kZS50eXBlLnRvVXBwZXJDYXNlKCksXG4gICAgICB2bm9kZS5wcm9wcyAmJiB2bm9kZS5wcm9wcy50eXBlXG4gICAgKTtcbiAgICBpZiAobW9kZWxUb1VzZS5nZXRTU1JQcm9wcykge1xuICAgICAgcmV0dXJuIG1vZGVsVG9Vc2UuZ2V0U1NSUHJvcHMoYmluZGluZywgdm5vZGUpO1xuICAgIH1cbiAgfTtcbn1cblxuY29uc3Qgc3lzdGVtTW9kaWZpZXJzID0gW1wiY3RybFwiLCBcInNoaWZ0XCIsIFwiYWx0XCIsIFwibWV0YVwiXTtcbmNvbnN0IG1vZGlmaWVyR3VhcmRzID0ge1xuICBzdG9wOiAoZSkgPT4gZS5zdG9wUHJvcGFnYXRpb24oKSxcbiAgcHJldmVudDogKGUpID0+IGUucHJldmVudERlZmF1bHQoKSxcbiAgc2VsZjogKGUpID0+IGUudGFyZ2V0ICE9PSBlLmN1cnJlbnRUYXJnZXQsXG4gIGN0cmw6IChlKSA9PiAhZS5jdHJsS2V5LFxuICBzaGlmdDogKGUpID0+ICFlLnNoaWZ0S2V5LFxuICBhbHQ6IChlKSA9PiAhZS5hbHRLZXksXG4gIG1ldGE6IChlKSA9PiAhZS5tZXRhS2V5LFxuICBsZWZ0OiAoZSkgPT4gXCJidXR0b25cIiBpbiBlICYmIGUuYnV0dG9uICE9PSAwLFxuICBtaWRkbGU6IChlKSA9PiBcImJ1dHRvblwiIGluIGUgJiYgZS5idXR0b24gIT09IDEsXG4gIHJpZ2h0OiAoZSkgPT4gXCJidXR0b25cIiBpbiBlICYmIGUuYnV0dG9uICE9PSAyLFxuICBleGFjdDogKGUsIG1vZGlmaWVycykgPT4gc3lzdGVtTW9kaWZpZXJzLnNvbWUoKG0pID0+IGVbYCR7bX1LZXlgXSAmJiAhbW9kaWZpZXJzLmluY2x1ZGVzKG0pKVxufTtcbmNvbnN0IHdpdGhNb2RpZmllcnMgPSAoZm4sIG1vZGlmaWVycykgPT4ge1xuICBpZiAoIWZuKSByZXR1cm4gZm47XG4gIGNvbnN0IGNhY2hlID0gZm4uX3dpdGhNb2RzIHx8IChmbi5fd2l0aE1vZHMgPSB7fSk7XG4gIGNvbnN0IGNhY2hlS2V5ID0gbW9kaWZpZXJzLmpvaW4oXCIuXCIpO1xuICByZXR1cm4gY2FjaGVbY2FjaGVLZXldIHx8IChjYWNoZVtjYWNoZUtleV0gPSAoKGV2ZW50LCAuLi5hcmdzKSA9PiB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtb2RpZmllcnMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGd1YXJkID0gbW9kaWZpZXJHdWFyZHNbbW9kaWZpZXJzW2ldXTtcbiAgICAgIGlmIChndWFyZCAmJiBndWFyZChldmVudCwgbW9kaWZpZXJzKSkgcmV0dXJuO1xuICAgIH1cbiAgICByZXR1cm4gZm4oZXZlbnQsIC4uLmFyZ3MpO1xuICB9KSk7XG59O1xuY29uc3Qga2V5TmFtZXMgPSB7XG4gIGVzYzogXCJlc2NhcGVcIixcbiAgc3BhY2U6IFwiIFwiLFxuICB1cDogXCJhcnJvdy11cFwiLFxuICBsZWZ0OiBcImFycm93LWxlZnRcIixcbiAgcmlnaHQ6IFwiYXJyb3ctcmlnaHRcIixcbiAgZG93bjogXCJhcnJvdy1kb3duXCIsXG4gIGRlbGV0ZTogXCJiYWNrc3BhY2VcIlxufTtcbmNvbnN0IHdpdGhLZXlzID0gKGZuLCBtb2RpZmllcnMpID0+IHtcbiAgY29uc3QgY2FjaGUgPSBmbi5fd2l0aEtleXMgfHwgKGZuLl93aXRoS2V5cyA9IHt9KTtcbiAgY29uc3QgY2FjaGVLZXkgPSBtb2RpZmllcnMuam9pbihcIi5cIik7XG4gIHJldHVybiBjYWNoZVtjYWNoZUtleV0gfHwgKGNhY2hlW2NhY2hlS2V5XSA9ICgoZXZlbnQpID0+IHtcbiAgICBpZiAoIShcImtleVwiIGluIGV2ZW50KSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBldmVudEtleSA9IGh5cGhlbmF0ZShldmVudC5rZXkpO1xuICAgIGlmIChtb2RpZmllcnMuc29tZShcbiAgICAgIChrKSA9PiBrID09PSBldmVudEtleSB8fCBrZXlOYW1lc1trXSA9PT0gZXZlbnRLZXlcbiAgICApKSB7XG4gICAgICByZXR1cm4gZm4oZXZlbnQpO1xuICAgIH1cbiAgfSkpO1xufTtcblxuY29uc3QgcmVuZGVyZXJPcHRpb25zID0gLyogQF9fUFVSRV9fICovIGV4dGVuZCh7IHBhdGNoUHJvcCB9LCBub2RlT3BzKTtcbmxldCByZW5kZXJlcjtcbmxldCBlbmFibGVkSHlkcmF0aW9uID0gZmFsc2U7XG5mdW5jdGlvbiBlbnN1cmVSZW5kZXJlcigpIHtcbiAgcmV0dXJuIHJlbmRlcmVyIHx8IChyZW5kZXJlciA9IGNyZWF0ZVJlbmRlcmVyKHJlbmRlcmVyT3B0aW9ucykpO1xufVxuZnVuY3Rpb24gZW5zdXJlSHlkcmF0aW9uUmVuZGVyZXIoKSB7XG4gIHJlbmRlcmVyID0gZW5hYmxlZEh5ZHJhdGlvbiA/IHJlbmRlcmVyIDogY3JlYXRlSHlkcmF0aW9uUmVuZGVyZXIocmVuZGVyZXJPcHRpb25zKTtcbiAgZW5hYmxlZEh5ZHJhdGlvbiA9IHRydWU7XG4gIHJldHVybiByZW5kZXJlcjtcbn1cbmNvbnN0IHJlbmRlciA9ICgoLi4uYXJncykgPT4ge1xuICBlbnN1cmVSZW5kZXJlcigpLnJlbmRlciguLi5hcmdzKTtcbn0pO1xuY29uc3QgaHlkcmF0ZSA9ICgoLi4uYXJncykgPT4ge1xuICBlbnN1cmVIeWRyYXRpb25SZW5kZXJlcigpLmh5ZHJhdGUoLi4uYXJncyk7XG59KTtcbmNvbnN0IGNyZWF0ZUFwcCA9ICgoLi4uYXJncykgPT4ge1xuICBjb25zdCBhcHAgPSBlbnN1cmVSZW5kZXJlcigpLmNyZWF0ZUFwcCguLi5hcmdzKTtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICBpbmplY3ROYXRpdmVUYWdDaGVjayhhcHApO1xuICAgIGluamVjdENvbXBpbGVyT3B0aW9uc0NoZWNrKGFwcCk7XG4gIH1cbiAgY29uc3QgeyBtb3VudCB9ID0gYXBwO1xuICBhcHAubW91bnQgPSAoY29udGFpbmVyT3JTZWxlY3RvcikgPT4ge1xuICAgIGNvbnN0IGNvbnRhaW5lciA9IG5vcm1hbGl6ZUNvbnRhaW5lcihjb250YWluZXJPclNlbGVjdG9yKTtcbiAgICBpZiAoIWNvbnRhaW5lcikgcmV0dXJuO1xuICAgIGNvbnN0IGNvbXBvbmVudCA9IGFwcC5fY29tcG9uZW50O1xuICAgIGlmICghaXNGdW5jdGlvbihjb21wb25lbnQpICYmICFjb21wb25lbnQucmVuZGVyICYmICFjb21wb25lbnQudGVtcGxhdGUpIHtcbiAgICAgIGNvbXBvbmVudC50ZW1wbGF0ZSA9IGNvbnRhaW5lci5pbm5lckhUTUw7XG4gICAgfVxuICAgIGlmIChjb250YWluZXIubm9kZVR5cGUgPT09IDEpIHtcbiAgICAgIGNvbnRhaW5lci50ZXh0Q29udGVudCA9IFwiXCI7XG4gICAgfVxuICAgIGNvbnN0IHByb3h5ID0gbW91bnQoY29udGFpbmVyLCBmYWxzZSwgcmVzb2x2ZVJvb3ROYW1lc3BhY2UoY29udGFpbmVyKSk7XG4gICAgaWYgKGNvbnRhaW5lciBpbnN0YW5jZW9mIEVsZW1lbnQpIHtcbiAgICAgIGNvbnRhaW5lci5yZW1vdmVBdHRyaWJ1dGUoXCJ2LWNsb2FrXCIpO1xuICAgICAgY29udGFpbmVyLnNldEF0dHJpYnV0ZShcImRhdGEtdi1hcHBcIiwgXCJcIik7XG4gICAgfVxuICAgIHJldHVybiBwcm94eTtcbiAgfTtcbiAgcmV0dXJuIGFwcDtcbn0pO1xuY29uc3QgY3JlYXRlU1NSQXBwID0gKCguLi5hcmdzKSA9PiB7XG4gIGNvbnN0IGFwcCA9IGVuc3VyZUh5ZHJhdGlvblJlbmRlcmVyKCkuY3JlYXRlQXBwKC4uLmFyZ3MpO1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIGluamVjdE5hdGl2ZVRhZ0NoZWNrKGFwcCk7XG4gICAgaW5qZWN0Q29tcGlsZXJPcHRpb25zQ2hlY2soYXBwKTtcbiAgfVxuICBjb25zdCB7IG1vdW50IH0gPSBhcHA7XG4gIGFwcC5tb3VudCA9IChjb250YWluZXJPclNlbGVjdG9yKSA9PiB7XG4gICAgY29uc3QgY29udGFpbmVyID0gbm9ybWFsaXplQ29udGFpbmVyKGNvbnRhaW5lck9yU2VsZWN0b3IpO1xuICAgIGlmIChjb250YWluZXIpIHtcbiAgICAgIHJldHVybiBtb3VudChjb250YWluZXIsIHRydWUsIHJlc29sdmVSb290TmFtZXNwYWNlKGNvbnRhaW5lcikpO1xuICAgIH1cbiAgfTtcbiAgcmV0dXJuIGFwcDtcbn0pO1xuZnVuY3Rpb24gcmVzb2x2ZVJvb3ROYW1lc3BhY2UoY29udGFpbmVyKSB7XG4gIGlmIChjb250YWluZXIgaW5zdGFuY2VvZiBTVkdFbGVtZW50KSB7XG4gICAgcmV0dXJuIFwic3ZnXCI7XG4gIH1cbiAgaWYgKHR5cGVvZiBNYXRoTUxFbGVtZW50ID09PSBcImZ1bmN0aW9uXCIgJiYgY29udGFpbmVyIGluc3RhbmNlb2YgTWF0aE1MRWxlbWVudCkge1xuICAgIHJldHVybiBcIm1hdGhtbFwiO1xuICB9XG59XG5mdW5jdGlvbiBpbmplY3ROYXRpdmVUYWdDaGVjayhhcHApIHtcbiAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGFwcC5jb25maWcsIFwiaXNOYXRpdmVUYWdcIiwge1xuICAgIHZhbHVlOiAodGFnKSA9PiBpc0hUTUxUYWcodGFnKSB8fCBpc1NWR1RhZyh0YWcpIHx8IGlzTWF0aE1MVGFnKHRhZyksXG4gICAgd3JpdGFibGU6IGZhbHNlXG4gIH0pO1xufVxuZnVuY3Rpb24gaW5qZWN0Q29tcGlsZXJPcHRpb25zQ2hlY2soYXBwKSB7XG4gIGlmIChpc1J1bnRpbWVPbmx5KCkpIHtcbiAgICBjb25zdCBpc0N1c3RvbUVsZW1lbnQgPSBhcHAuY29uZmlnLmlzQ3VzdG9tRWxlbWVudDtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoYXBwLmNvbmZpZywgXCJpc0N1c3RvbUVsZW1lbnRcIiwge1xuICAgICAgZ2V0KCkge1xuICAgICAgICByZXR1cm4gaXNDdXN0b21FbGVtZW50O1xuICAgICAgfSxcbiAgICAgIHNldCgpIHtcbiAgICAgICAgd2FybihcbiAgICAgICAgICBgVGhlIFxcYGlzQ3VzdG9tRWxlbWVudFxcYCBjb25maWcgb3B0aW9uIGlzIGRlcHJlY2F0ZWQuIFVzZSBcXGBjb21waWxlck9wdGlvbnMuaXNDdXN0b21FbGVtZW50XFxgIGluc3RlYWQuYFxuICAgICAgICApO1xuICAgICAgfVxuICAgIH0pO1xuICAgIGNvbnN0IGNvbXBpbGVyT3B0aW9ucyA9IGFwcC5jb25maWcuY29tcGlsZXJPcHRpb25zO1xuICAgIGNvbnN0IG1zZyA9IGBUaGUgXFxgY29tcGlsZXJPcHRpb25zXFxgIGNvbmZpZyBvcHRpb24gaXMgb25seSByZXNwZWN0ZWQgd2hlbiB1c2luZyBhIGJ1aWxkIG9mIFZ1ZS5qcyB0aGF0IGluY2x1ZGVzIHRoZSBydW50aW1lIGNvbXBpbGVyIChha2EgXCJmdWxsIGJ1aWxkXCIpLiBTaW5jZSB5b3UgYXJlIHVzaW5nIHRoZSBydW50aW1lLW9ubHkgYnVpbGQsIFxcYGNvbXBpbGVyT3B0aW9uc1xcYCBtdXN0IGJlIHBhc3NlZCB0byBcXGBAdnVlL2NvbXBpbGVyLWRvbVxcYCBpbiB0aGUgYnVpbGQgc2V0dXAgaW5zdGVhZC5cbi0gRm9yIHZ1ZS1sb2FkZXI6IHBhc3MgaXQgdmlhIHZ1ZS1sb2FkZXIncyBcXGBjb21waWxlck9wdGlvbnNcXGAgbG9hZGVyIG9wdGlvbi5cbi0gRm9yIHZ1ZS1jbGk6IHNlZSBodHRwczovL2NsaS52dWVqcy5vcmcvZ3VpZGUvd2VicGFjay5odG1sI21vZGlmeWluZy1vcHRpb25zLW9mLWEtbG9hZGVyXG4tIEZvciB2aXRlOiBwYXNzIGl0IHZpYSBAdml0ZWpzL3BsdWdpbi12dWUgb3B0aW9ucy4gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS92aXRlanMvdml0ZS1wbHVnaW4tdnVlL3RyZWUvbWFpbi9wYWNrYWdlcy9wbHVnaW4tdnVlI2V4YW1wbGUtZm9yLXBhc3Npbmctb3B0aW9ucy10by12dWVjb21waWxlci1zZmNgO1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShhcHAuY29uZmlnLCBcImNvbXBpbGVyT3B0aW9uc1wiLCB7XG4gICAgICBnZXQoKSB7XG4gICAgICAgIHdhcm4obXNnKTtcbiAgICAgICAgcmV0dXJuIGNvbXBpbGVyT3B0aW9ucztcbiAgICAgIH0sXG4gICAgICBzZXQoKSB7XG4gICAgICAgIHdhcm4obXNnKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxufVxuZnVuY3Rpb24gbm9ybWFsaXplQ29udGFpbmVyKGNvbnRhaW5lcikge1xuICBpZiAoaXNTdHJpbmcoY29udGFpbmVyKSkge1xuICAgIGNvbnN0IHJlcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoY29udGFpbmVyKTtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiAhcmVzKSB7XG4gICAgICB3YXJuKFxuICAgICAgICBgRmFpbGVkIHRvIG1vdW50IGFwcDogbW91bnQgdGFyZ2V0IHNlbGVjdG9yIFwiJHtjb250YWluZXJ9XCIgcmV0dXJuZWQgbnVsbC5gXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gcmVzO1xuICB9XG4gIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdpbmRvdy5TaGFkb3dSb290ICYmIGNvbnRhaW5lciBpbnN0YW5jZW9mIHdpbmRvdy5TaGFkb3dSb290ICYmIGNvbnRhaW5lci5tb2RlID09PSBcImNsb3NlZFwiKSB7XG4gICAgd2FybihcbiAgICAgIGBtb3VudGluZyBvbiBhIFNoYWRvd1Jvb3Qgd2l0aCBcXGB7bW9kZTogXCJjbG9zZWRcIn1cXGAgbWF5IGxlYWQgdG8gdW5wcmVkaWN0YWJsZSBidWdzYFxuICAgICk7XG4gIH1cbiAgcmV0dXJuIGNvbnRhaW5lcjtcbn1cbmxldCBzc3JEaXJlY3RpdmVJbml0aWFsaXplZCA9IGZhbHNlO1xuY29uc3QgaW5pdERpcmVjdGl2ZXNGb3JTU1IgPSAoKSA9PiB7XG4gIGlmICghc3NyRGlyZWN0aXZlSW5pdGlhbGl6ZWQpIHtcbiAgICBzc3JEaXJlY3RpdmVJbml0aWFsaXplZCA9IHRydWU7XG4gICAgaW5pdFZNb2RlbEZvclNTUigpO1xuICAgIGluaXRWU2hvd0ZvclNTUigpO1xuICB9XG59IDtcblxuZXhwb3J0IHsgVHJhbnNpdGlvbiwgVHJhbnNpdGlvbkdyb3VwLCBWdWVFbGVtZW50LCBjcmVhdGVBcHAsIGNyZWF0ZVNTUkFwcCwgZGVmaW5lQ3VzdG9tRWxlbWVudCwgZGVmaW5lU1NSQ3VzdG9tRWxlbWVudCwgaHlkcmF0ZSwgaW5pdERpcmVjdGl2ZXNGb3JTU1IsIG5vZGVPcHMsIHBhdGNoUHJvcCwgcmVuZGVyLCB1c2VDc3NNb2R1bGUsIHVzZUNzc1ZhcnMsIHVzZUhvc3QsIHVzZVNoYWRvd1Jvb3QsIHZNb2RlbENoZWNrYm94LCB2TW9kZWxEeW5hbWljLCB2TW9kZWxSYWRpbywgdk1vZGVsU2VsZWN0LCB2TW9kZWxUZXh0LCB2U2hvdywgd2l0aEtleXMsIHdpdGhNb2RpZmllcnMgfTtcbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19