import { t as __commonJSMin } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.cache/vite/client/deps/rolldown-runtime-BvCyGRYZ.js?v=7e73afc2";
//#region node_modules/.pnpm/dayjs@1.11.21/node_modules/dayjs/plugin/relativeTime.js
var require_relativeTime = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(r, e) {
		"object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (r = "undefined" != typeof globalThis ? globalThis : r || self).dayjs_plugin_relativeTime = e();
	})(exports, (function() {
		"use strict";
		return function(r, e, t) {
			r = r || {};
			var n = e.prototype, o = {
				future: "in %s",
				past: "%s ago",
				s: "a few seconds",
				m: "a minute",
				mm: "%d minutes",
				h: "an hour",
				hh: "%d hours",
				d: "a day",
				dd: "%d days",
				M: "a month",
				MM: "%d months",
				y: "a year",
				yy: "%d years"
			};
			function i(r, e, t, o) {
				return n.fromToBase(r, e, t, o);
			}
			t.en.relativeTime = o, n.fromToBase = function(e, n, i, d, u) {
				for (var f, a, s, l = i.$locale().relativeTime || o, h = r.thresholds || [
					{
						l: "s",
						r: 44,
						d: "second"
					},
					{
						l: "m",
						r: 89
					},
					{
						l: "mm",
						r: 44,
						d: "minute"
					},
					{
						l: "h",
						r: 89
					},
					{
						l: "hh",
						r: 21,
						d: "hour"
					},
					{
						l: "d",
						r: 35
					},
					{
						l: "dd",
						r: 25,
						d: "day"
					},
					{
						l: "M",
						r: 45
					},
					{
						l: "MM",
						r: 10,
						d: "month"
					},
					{
						l: "y",
						r: 17
					},
					{
						l: "yy",
						d: "year"
					}
				], m = h.length, c = 0; c < m; c += 1) {
					var y = h[c];
					y.d && (f = d ? t(e).diff(i, y.d, !0) : i.diff(e, y.d, !0));
					var p = (r.rounding || Math.round)(Math.abs(f));
					if (s = f > 0, p <= y.r || !y.r) {
						p <= 1 && c > 0 && (y = h[c - 1]);
						var v = l[y.l];
						u && (p = u("" + p)), a = "string" == typeof v ? v.replace("%d", p) : v(p, n, y.l, s);
						break;
					}
				}
				if (n) return a;
				var M = s ? l.future : l.past;
				return "function" == typeof M ? M(a) : M.replace("%s", a);
			}, n.to = function(r, e) {
				return i(r, e, this, !0);
			}, n.from = function(r, e) {
				return i(r, e, this);
			};
			var d = function(r) {
				return r.$u ? t.utc() : t();
			};
			n.toNow = function(r) {
				return this.to(d(this), r);
			}, n.fromNow = function(r) {
				return this.from(d(this), r);
			};
		};
	}));
}));
//#endregion
export default require_relativeTime();

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF5anNfcGx1Z2luX3JlbGF0aXZlVGltZS5qcyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8ucG5wbS9kYXlqc0AxLjExLjIxL25vZGVfbW9kdWxlcy9kYXlqcy9wbHVnaW4vcmVsYXRpdmVUaW1lLmpzIl0sInNvdXJjZXNDb250ZW50IjpbIiFmdW5jdGlvbihyLGUpe1wib2JqZWN0XCI9PXR5cGVvZiBleHBvcnRzJiZcInVuZGVmaW5lZFwiIT10eXBlb2YgbW9kdWxlP21vZHVsZS5leHBvcnRzPWUoKTpcImZ1bmN0aW9uXCI9PXR5cGVvZiBkZWZpbmUmJmRlZmluZS5hbWQ/ZGVmaW5lKGUpOihyPVwidW5kZWZpbmVkXCIhPXR5cGVvZiBnbG9iYWxUaGlzP2dsb2JhbFRoaXM6cnx8c2VsZikuZGF5anNfcGx1Z2luX3JlbGF0aXZlVGltZT1lKCl9KHRoaXMsKGZ1bmN0aW9uKCl7XCJ1c2Ugc3RyaWN0XCI7cmV0dXJuIGZ1bmN0aW9uKHIsZSx0KXtyPXJ8fHt9O3ZhciBuPWUucHJvdG90eXBlLG89e2Z1dHVyZTpcImluICVzXCIscGFzdDpcIiVzIGFnb1wiLHM6XCJhIGZldyBzZWNvbmRzXCIsbTpcImEgbWludXRlXCIsbW06XCIlZCBtaW51dGVzXCIsaDpcImFuIGhvdXJcIixoaDpcIiVkIGhvdXJzXCIsZDpcImEgZGF5XCIsZGQ6XCIlZCBkYXlzXCIsTTpcImEgbW9udGhcIixNTTpcIiVkIG1vbnRoc1wiLHk6XCJhIHllYXJcIix5eTpcIiVkIHllYXJzXCJ9O2Z1bmN0aW9uIGkocixlLHQsbyl7cmV0dXJuIG4uZnJvbVRvQmFzZShyLGUsdCxvKX10LmVuLnJlbGF0aXZlVGltZT1vLG4uZnJvbVRvQmFzZT1mdW5jdGlvbihlLG4saSxkLHUpe2Zvcih2YXIgZixhLHMsbD1pLiRsb2NhbGUoKS5yZWxhdGl2ZVRpbWV8fG8saD1yLnRocmVzaG9sZHN8fFt7bDpcInNcIixyOjQ0LGQ6XCJzZWNvbmRcIn0se2w6XCJtXCIscjo4OX0se2w6XCJtbVwiLHI6NDQsZDpcIm1pbnV0ZVwifSx7bDpcImhcIixyOjg5fSx7bDpcImhoXCIscjoyMSxkOlwiaG91clwifSx7bDpcImRcIixyOjM1fSx7bDpcImRkXCIscjoyNSxkOlwiZGF5XCJ9LHtsOlwiTVwiLHI6NDV9LHtsOlwiTU1cIixyOjEwLGQ6XCJtb250aFwifSx7bDpcInlcIixyOjE3fSx7bDpcInl5XCIsZDpcInllYXJcIn1dLG09aC5sZW5ndGgsYz0wO2M8bTtjKz0xKXt2YXIgeT1oW2NdO3kuZCYmKGY9ZD90KGUpLmRpZmYoaSx5LmQsITApOmkuZGlmZihlLHkuZCwhMCkpO3ZhciBwPShyLnJvdW5kaW5nfHxNYXRoLnJvdW5kKShNYXRoLmFicyhmKSk7aWYocz1mPjAscDw9eS5yfHwheS5yKXtwPD0xJiZjPjAmJih5PWhbYy0xXSk7dmFyIHY9bFt5LmxdO3UmJihwPXUoXCJcIitwKSksYT1cInN0cmluZ1wiPT10eXBlb2Ygdj92LnJlcGxhY2UoXCIlZFwiLHApOnYocCxuLHkubCxzKTticmVha319aWYobilyZXR1cm4gYTt2YXIgTT1zP2wuZnV0dXJlOmwucGFzdDtyZXR1cm5cImZ1bmN0aW9uXCI9PXR5cGVvZiBNP00oYSk6TS5yZXBsYWNlKFwiJXNcIixhKX0sbi50bz1mdW5jdGlvbihyLGUpe3JldHVybiBpKHIsZSx0aGlzLCEwKX0sbi5mcm9tPWZ1bmN0aW9uKHIsZSl7cmV0dXJuIGkocixlLHRoaXMpfTt2YXIgZD1mdW5jdGlvbihyKXtyZXR1cm4gci4kdT90LnV0YygpOnQoKX07bi50b05vdz1mdW5jdGlvbihyKXtyZXR1cm4gdGhpcy50byhkKHRoaXMpLHIpfSxuLmZyb21Ob3c9ZnVuY3Rpb24ocil7cmV0dXJuIHRoaXMuZnJvbShkKHRoaXMpLHIpfX19KSk7Il0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXSwibWFwcGluZ3MiOiI7OztDQUFBLENBQUMsU0FBUyxHQUFFLEdBQUU7RUFBQyxZQUFVLE9BQU8sV0FBUyxlQUFhLE9BQU8sU0FBTyxPQUFPLFVBQVEsRUFBRSxJQUFFLGNBQVksT0FBTyxVQUFRLE9BQU8sTUFBSSxPQUFPLENBQUMsSUFBRSxDQUFDLElBQUUsZUFBYSxPQUFPLGFBQVcsYUFBVyxLQUFHLEtBQUEsQ0FBTSw0QkFBMEIsRUFBRTtDQUFDLEVBQUEsQ0FBQyxVQUFPLFdBQVU7RUFBQztFQUFhLE9BQU8sU0FBUyxHQUFFLEdBQUUsR0FBRTtHQUFDLElBQUUsS0FBRyxDQUFDO0dBQUUsSUFBSSxJQUFFLEVBQUUsV0FBVSxJQUFFO0lBQUMsUUFBTztJQUFRLE1BQUs7SUFBUyxHQUFFO0lBQWdCLEdBQUU7SUFBVyxJQUFHO0lBQWEsR0FBRTtJQUFVLElBQUc7SUFBVyxHQUFFO0lBQVEsSUFBRztJQUFVLEdBQUU7SUFBVSxJQUFHO0lBQVksR0FBRTtJQUFTLElBQUc7R0FBVTtHQUFFLFNBQVMsRUFBRSxHQUFFLEdBQUUsR0FBRSxHQUFFO0lBQUMsT0FBTyxFQUFFLFdBQVcsR0FBRSxHQUFFLEdBQUUsQ0FBQztHQUFDO0dBQUMsRUFBRSxHQUFHLGVBQWEsR0FBRSxFQUFFLGFBQVcsU0FBUyxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUU7SUFBQyxLQUFJLElBQUksR0FBRSxHQUFFLEdBQUUsSUFBRSxFQUFFLFFBQVEsQ0FBQyxDQUFDLGdCQUFjLEdBQUUsSUFBRSxFQUFFLGNBQVk7S0FBQztNQUFDLEdBQUU7TUFBSSxHQUFFO01BQUcsR0FBRTtLQUFRO0tBQUU7TUFBQyxHQUFFO01BQUksR0FBRTtLQUFFO0tBQUU7TUFBQyxHQUFFO01BQUssR0FBRTtNQUFHLEdBQUU7S0FBUTtLQUFFO01BQUMsR0FBRTtNQUFJLEdBQUU7S0FBRTtLQUFFO01BQUMsR0FBRTtNQUFLLEdBQUU7TUFBRyxHQUFFO0tBQU07S0FBRTtNQUFDLEdBQUU7TUFBSSxHQUFFO0tBQUU7S0FBRTtNQUFDLEdBQUU7TUFBSyxHQUFFO01BQUcsR0FBRTtLQUFLO0tBQUU7TUFBQyxHQUFFO01BQUksR0FBRTtLQUFFO0tBQUU7TUFBQyxHQUFFO01BQUssR0FBRTtNQUFHLEdBQUU7S0FBTztLQUFFO01BQUMsR0FBRTtNQUFJLEdBQUU7S0FBRTtLQUFFO01BQUMsR0FBRTtNQUFLLEdBQUU7S0FBTTtJQUFDLEdBQUUsSUFBRSxFQUFFLFFBQU8sSUFBRSxHQUFFLElBQUUsR0FBRSxLQUFHLEdBQUU7S0FBQyxJQUFJLElBQUUsRUFBRTtLQUFHLEVBQUUsTUFBSSxJQUFFLElBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUUsRUFBRSxHQUFFLENBQUMsQ0FBQyxJQUFFLEVBQUUsS0FBSyxHQUFFLEVBQUUsR0FBRSxDQUFDLENBQUM7S0FBRyxJQUFJLEtBQUcsRUFBRSxZQUFVLEtBQUssTUFBQSxDQUFPLEtBQUssSUFBSSxDQUFDLENBQUM7S0FBRSxJQUFHLElBQUUsSUFBRSxHQUFFLEtBQUcsRUFBRSxLQUFHLENBQUMsRUFBRSxHQUFFO01BQUMsS0FBRyxLQUFHLElBQUUsTUFBSSxJQUFFLEVBQUUsSUFBRTtNQUFJLElBQUksSUFBRSxFQUFFLEVBQUU7TUFBRyxNQUFJLElBQUUsRUFBRSxLQUFHLENBQUMsSUFBRyxJQUFFLFlBQVUsT0FBTyxJQUFFLEVBQUUsUUFBUSxNQUFLLENBQUMsSUFBRSxFQUFFLEdBQUUsR0FBRSxFQUFFLEdBQUUsQ0FBQztNQUFFO0tBQUs7SUFBQztJQUFDLElBQUcsR0FBRSxPQUFPO0lBQUUsSUFBSSxJQUFFLElBQUUsRUFBRSxTQUFPLEVBQUU7SUFBSyxPQUFNLGNBQVksT0FBTyxJQUFFLEVBQUUsQ0FBQyxJQUFFLEVBQUUsUUFBUSxNQUFLLENBQUM7R0FBQyxHQUFFLEVBQUUsS0FBRyxTQUFTLEdBQUUsR0FBRTtJQUFDLE9BQU8sRUFBRSxHQUFFLEdBQUUsTUFBSyxDQUFDLENBQUM7R0FBQyxHQUFFLEVBQUUsT0FBSyxTQUFTLEdBQUUsR0FBRTtJQUFDLE9BQU8sRUFBRSxHQUFFLEdBQUUsSUFBSTtHQUFDO0dBQUUsSUFBSSxJQUFFLFNBQVMsR0FBRTtJQUFDLE9BQU8sRUFBRSxLQUFHLEVBQUUsSUFBSSxJQUFFLEVBQUU7R0FBQztHQUFFLEVBQUUsUUFBTSxTQUFTLEdBQUU7SUFBQyxPQUFPLEtBQUssR0FBRyxFQUFFLElBQUksR0FBRSxDQUFDO0dBQUMsR0FBRSxFQUFFLFVBQVEsU0FBUyxHQUFFO0lBQUMsT0FBTyxLQUFLLEtBQUssRUFBRSxJQUFJLEdBQUUsQ0FBQztHQUFDO0VBQUM7Q0FBQyxFQUFFIn0=