const URL_META_KEYS = /* @__PURE__ */ new Set([
  "og:url",
  "og:image",
  "og:image:url",
  "og:image:secure_url",
  "og:video",
  "og:video:url",
  "og:video:secure_url",
  "og:audio",
  "og:audio:url",
  "og:audio:secure_url",
  "twitter:image",
  "twitter:image:src",
  "twitter:player",
  "twitter:player:stream",
  "payment:success_url"
]);
const KNOWN_META_PROPERTIES = /* @__PURE__ */ new Set([
  "article:author",
  "article:expiration_time",
  "article:modified_time",
  "article:published_time",
  "article:section",
  "article:tag",
  "book:author",
  "book:isbn",
  "book:release_date",
  "book:tag",
  "fb:app_id",
  "og:audio",
  "og:audio:secure_url",
  "og:audio:type",
  "og:audio:url",
  "og:description",
  "og:determiner",
  "og:image",
  "og:image:alt",
  "og:image:height",
  "og:image:secure_url",
  "og:image:type",
  "og:image:url",
  "og:image:width",
  "og:locale",
  "og:locale:alternate",
  "og:site_name",
  "og:title",
  "og:type",
  "og:url",
  "og:video",
  "og:video:alt",
  "og:video:duration",
  "og:video:height",
  "og:video:secure_url",
  "og:video:type",
  "og:video:url",
  "og:video:width",
  "payment:amount",
  "payment:currency",
  "payment:description",
  "payment:expires_at",
  "payment:id",
  "payment:status",
  "payment:success_url",
  "profile:first_name",
  "profile:gender",
  "profile:last_name",
  "profile:username"
]);
const KNOWN_META_NAMES = /* @__PURE__ */ new Set([
  "apple-itunes-app",
  "apple-mobile-web-app-capable",
  "apple-mobile-web-app-status-bar-style",
  "apple-mobile-web-app-title",
  "application-name",
  "author",
  "color-scheme",
  "creator",
  "description",
  "fb:app_id",
  "fediverse:creator",
  "format-detection",
  "generator",
  "google-site-verification",
  "google",
  "googlebot",
  "keywords",
  "mobile-web-app-capable",
  "msapplication-config",
  "msapplication-tilecolor",
  "msapplication-tileimage",
  "publisher",
  "rating",
  "referrer",
  "robots",
  "theme-color",
  "viewport",
  "twitter:app:id:googleplay",
  "twitter:app:id:ipad",
  "twitter:app:id:iphone",
  "twitter:app:name:googleplay",
  "twitter:app:name:ipad",
  "twitter:app:name:iphone",
  "twitter:app:url:googleplay",
  "twitter:app:url:ipad",
  "twitter:app:url:iphone",
  "twitter:card",
  "twitter:creator",
  "twitter:creator:id",
  "twitter:data:1",
  "twitter:data:2",
  "twitter:description",
  "twitter:image",
  "twitter:image:alt",
  "twitter:label:1",
  "twitter:label:2",
  "twitter:player",
  "twitter:player:height",
  "twitter:player:stream",
  "twitter:player:width",
  "twitter:site",
  "twitter:site:id",
  "twitter:title"
]);
const TAG_PRIORITY_ALIASES = ["critical", "high", "low"];
const DEPRECATED_PROPS = {
  children: { replacement: "innerHTML", ruleId: "deprecated-prop-children" },
  hid: { replacement: "key", ruleId: "deprecated-prop-hid-vmid" },
  vmid: { replacement: "key", ruleId: "deprecated-prop-hid-vmid" },
  body: { replacement: "tagPosition: 'bodyClose'", ruleId: "deprecated-prop-body" }
};

function levenshtein(a, b) {
  const m = a.length;
  const n = b.length;
  const d = Array.from({ length: n + 1 }, (_, i) => i);
  for (let i = 1; i <= m; i++) {
    let prev = i - 1;
    d[0] = i;
    for (let j = 1; j <= n; j++) {
      const tmp = d[j];
      d[j] = a[i - 1] === b[j - 1] ? prev : 1 + Math.min(prev, d[j], d[j - 1]);
      prev = tmp;
    }
  }
  return d[n];
}
function findClosestMatch(value, knownSet) {
  const threshold = value.length <= 8 ? 2 : 3;
  let best;
  let bestDist = threshold + 1;
  for (const known of knownSet) {
    if (Math.abs(known.length - value.length) > threshold)
      continue;
    const dist = levenshtein(value, known);
    if (dist < bestDist) {
      bestDist = dist;
      best = known;
    }
  }
  return best;
}

const emptyMetaContent = (tag) => {
  if (tag.tagType !== "meta")
    return [];
  if (!tag.keys.has("content"))
    return [];
  if (tag.props.content !== "")
    return [];
  const key = typeof tag.props.name === "string" && tag.props.name || typeof tag.props.property === "string" && tag.props.property || "meta";
  const diag = {
    ruleId: "empty-meta-content",
    message: `Meta tag "${key}" has empty content.`,
    at: { kind: "prop", key: "content" }
  };
  return [diag];
};

const RESOLVABLE_OBJECT = ["boolean", "function", "null", "object"];
const RESOLVABLE_TAG_LIST = ["array", "boolean", "function", "null"];
const RESOLVABLE_TITLE = ["boolean", "function", "null", "number", "object", "string"];
const ATTRIBUTE_SCALAR = ["boolean", "function", "null", "number", "string"];
const ATTRIBUTE_STRUCTURED = ["array", "boolean", "function", "null", "number", "object", "string"];
const INPUT_SHAPE_FIELDS = {
  base: {
    canonical: "base",
    contexts: { head: RESOLVABLE_OBJECT }
  },
  bodyattrs: {
    canonical: "bodyAttrs",
    contexts: { head: RESOLVABLE_OBJECT }
  },
  class: {
    canonical: "class",
    contexts: {
      bodyAttrs: ATTRIBUTE_STRUCTURED,
      htmlAttrs: ATTRIBUTE_STRUCTURED
    }
  },
  htmlattrs: {
    canonical: "htmlAttrs",
    contexts: { head: RESOLVABLE_OBJECT }
  },
  link: {
    canonical: "link",
    contexts: { head: RESOLVABLE_TAG_LIST }
  },
  meta: {
    canonical: "meta",
    contexts: { head: RESOLVABLE_TAG_LIST }
  },
  noscript: {
    canonical: "noscript",
    contexts: { head: RESOLVABLE_TAG_LIST }
  },
  script: {
    canonical: "script",
    contexts: { head: RESOLVABLE_TAG_LIST }
  },
  style: {
    canonical: "style",
    contexts: {
      bodyAttrs: ATTRIBUTE_STRUCTURED,
      head: RESOLVABLE_TAG_LIST,
      htmlAttrs: ATTRIBUTE_STRUCTURED
    }
  },
  templateparams: {
    canonical: "templateParams",
    contexts: { head: ["object"] }
  },
  title: {
    canonical: "title",
    contexts: {
      bodyAttrs: ATTRIBUTE_SCALAR,
      head: RESOLVABLE_TITLE,
      htmlAttrs: ATTRIBUTE_SCALAR,
      seoMeta: RESOLVABLE_TITLE
    }
  },
  titletemplate: {
    canonical: "titleTemplate",
    contexts: {
      head: ["function", "null", "object", "string"],
      seoMeta: ["function", "null", "object", "string"]
    }
  }
};
function includes(kinds, kind) {
  return kinds?.includes(kind) === true;
}
function formatKinds(kinds) {
  return kinds.join(", ");
}
function invalidKnownHeadField(input, key, shape, kind) {
  const expected = shape.contexts[input.context];
  if (includes(expected, kind))
    return void 0;
  if ((input.context === "htmlAttrs" || input.context === "bodyAttrs") && kind === "null")
    return void 0;
  if (input.context === "head") {
    return {
      ruleId: "invalid-input-shape",
      message: `"${shape.canonical}" in a head input must be one of: ${formatKinds(expected || [])}. Received ${kind}.`,
      at: { kind: "prop-value", key }
    };
  }
  if (includes(shape.contexts.head, kind)) {
    return {
      ruleId: "invalid-input-shape",
      message: `"${shape.canonical}" has a head input shape but appears in ${input.context}. Move it to the top-level head input.`,
      at: { kind: "prop-value", key }
    };
  }
}
function invalidAttributeField(input, key, kind) {
  if (includes(ATTRIBUTE_SCALAR, kind))
    return void 0;
  return {
    ruleId: "invalid-input-shape",
    message: `"${key}" in ${input.context} must resolve to a scalar attribute value. Received ${kind}.`,
    at: { kind: "prop-value", key }
  };
}
function validateInputShape(input) {
  const diagnostics = [];
  const isAttributes = input.context === "htmlAttrs" || input.context === "bodyAttrs";
  for (const key of input.keys) {
    const kind = input.valueKinds.get(key) ?? "unknown";
    if (kind === "unknown")
      continue;
    const shape = INPUT_SHAPE_FIELDS[key.toLowerCase()];
    const knownDiagnostic = shape ? invalidKnownHeadField(input, key, shape, kind) : void 0;
    if (knownDiagnostic) {
      diagnostics.push(knownDiagnostic);
      continue;
    }
    if (isAttributes && !shape?.contexts[input.context]) {
      const attributeDiagnostic = invalidAttributeField(input, key, kind);
      if (attributeDiagnostic)
        diagnostics.push(attributeDiagnostic);
    }
  }
  return diagnostics;
}

const noDeprecatedProps = (tag) => {
  const out = [];
  for (const key of tag.keys) {
    if (!(key in DEPRECATED_PROPS))
      continue;
    const { replacement } = DEPRECATED_PROPS[key];
    if (key === "body") {
      if (tag.props.body !== true)
        continue;
      const fix2 = tag.keys.has("tagPosition") ? void 0 : { type: "replace-prop", key: "body", newSource: `tagPosition: 'bodyClose'` };
      out.push({
        ruleId: "deprecated-prop-body",
        message: `"body" was removed in v3 of unhead. Use "${replacement}" instead.`,
        at: { kind: "prop", key },
        fix: fix2
      });
      continue;
    }
    const newKey = key === "children" ? "innerHTML" : "key";
    const fix = tag.keys.has(newKey) ? void 0 : { type: "rename-prop", key, newKey };
    out.push({
      ruleId: key === "children" ? "deprecated-prop-children" : "deprecated-prop-hid-vmid",
      message: `"${key}" was removed in v3 of unhead. Use "${replacement}" instead.`,
      at: { kind: "prop", key },
      fix
    });
  }
  return out;
};

const HTML_CHARS_RE = /[<>]/;
const noHtmlInTitle = (input) => {
  const title = input.props.title;
  if (typeof title !== "string" || !HTML_CHARS_RE.test(title))
    return [];
  const diag = {
    ruleId: "html-in-title",
    message: `Title contains HTML characters which will be escaped, not rendered: "${title}".`,
    at: { kind: "prop-value", key: "title" }
  };
  return [diag];
};

const OG_PREFIX_RE = /^(?:og|article|book|profile|fb):/;
const noUnknownMeta = (tag) => {
  if (tag.tagType !== "meta")
    return [];
  const out = [];
  const property = tag.props.property;
  if (typeof property === "string" && !KNOWN_META_PROPERTIES.has(property) && OG_PREFIX_RE.test(property)) {
    const suggestion = findClosestMatch(property, KNOWN_META_PROPERTIES);
    if (suggestion) {
      out.push({
        ruleId: "possible-typo",
        message: `Unknown meta property "${property}". Did you mean "${suggestion}"?`,
        at: { kind: "prop-value", key: "property" },
        fix: { type: "replace-prop-value", key: "property", newSource: `'${suggestion}'` }
      });
    }
  }
  const name = tag.props.name;
  if (typeof name === "string") {
    const lower = name.toLowerCase();
    if (!KNOWN_META_NAMES.has(lower) && (lower.startsWith("twitter:") || lower.startsWith("fediverse:") || !lower.includes(":"))) {
      const suggestion = findClosestMatch(lower, KNOWN_META_NAMES);
      if (suggestion) {
        out.push({
          ruleId: "possible-typo",
          message: `Unknown meta name "${name}". Did you mean "${suggestion}"?`,
          at: { kind: "prop-value", key: "name" },
          fix: { type: "replace-prop-value", key: "name", newSource: `'${suggestion}'` }
        });
      }
    }
  }
  return out;
};

function isAbsolute(url) {
  return url.startsWith("http://") || url.startsWith("https://");
}
const nonAbsoluteCanonical = (tag) => {
  if (tag.tagType !== "link")
    return [];
  if (tag.props.rel !== "canonical")
    return [];
  const href = tag.props.href;
  if (typeof href !== "string")
    return [];
  if (isAbsolute(href))
    return [];
  const diag = {
    ruleId: "non-absolute-canonical",
    message: `Canonical URL should be absolute, received "${href}".`,
    at: { kind: "prop-value", key: "href" }
  };
  return [diag];
};

const ALIASES = ["critical", "high", "low"];
const numericTagPriority = (tag) => {
  const value = tag.props.tagPriority;
  if (typeof value !== "number")
    return [];
  const diag = {
    ruleId: "numeric-tag-priority",
    message: `Numeric tagPriority (${value}) is brittle. Prefer an alias ('critical' | 'high' | 'low') or 'before:<key>' / 'after:<key>'.`,
    at: { kind: "prop-value", key: "tagPriority" },
    suggestions: ALIASES.map((alias) => ({
      message: `Replace with '${alias}'`,
      fix: { type: "replace-prop-value", key: "tagPriority", newSource: `'${alias}'` }
    }))
  };
  return [diag];
};

const TAG_TO_HELPER = {
  link: "defineLink",
  script: "defineScript"
};
const preferDefineHelpers = (tag, ctx) => {
  if (!tag.inArray)
    return [];
  const helper = TAG_TO_HELPER[tag.tagType];
  if (!helper)
    return [];
  const localName = ctx?.importedHelpers?.get(helper);
  const imported = localName !== void 0;
  const fix = { type: "wrap-tag", wrapWith: localName ?? helper };
  const diag = {
    ruleId: "prefer-define-helpers",
    message: `Wrap this ${tag.tagType} entry in \`${helper}()\` so unhead can narrow its type.`,
    fix: imported ? fix : void 0,
    suggestions: imported ? void 0 : [{ message: `Wrap in \`${helper}()\` (you may need to import it).`, fix: { type: "wrap-tag", wrapWith: helper } }]
  };
  return [diag];
};

const preloadMissingAs = (tag) => {
  if (tag.tagType !== "link")
    return [];
  if (tag.props.rel !== "preload")
    return [];
  if (tag.keys.has("as"))
    return [];
  const diag = {
    ruleId: "preload-missing-as",
    message: 'Preload link is missing the required "as" attribute.'
  };
  return [diag];
};
const preloadFontCrossorigin = (tag) => {
  if (tag.tagType !== "link")
    return [];
  if (tag.props.rel !== "preload")
    return [];
  if (tag.props.as !== "font")
    return [];
  if (tag.keys.has("crossorigin"))
    return [];
  const diag = {
    ruleId: "preload-font-crossorigin",
    message: 'Font preload requires "crossorigin" \u2014 without it the font will be fetched twice.',
    fix: { type: "insert-after-prop", afterKey: "as", insert: `, crossorigin: 'anonymous'` }
  };
  return [diag];
};

const robotsConflict = (tag) => {
  if (tag.tagType !== "meta")
    return [];
  if (tag.props.name !== "robots")
    return [];
  const content = tag.props.content;
  if (typeof content !== "string")
    return [];
  const directives = content.toLowerCase().split(",").map((d) => d.trim());
  const out = [];
  if (directives.includes("index") && directives.includes("noindex")) {
    out.push({
      ruleId: "robots-conflict",
      message: 'Robots meta has conflicting "index" and "noindex" directives.'
    });
  }
  if (directives.includes("follow") && directives.includes("nofollow")) {
    out.push({
      ruleId: "robots-conflict",
      message: 'Robots meta has conflicting "follow" and "nofollow" directives.'
    });
  }
  return out;
};

const deferOnModuleScript = (tag) => {
  if (tag.tagType !== "script")
    return [];
  if (tag.props.type !== "module")
    return [];
  if (tag.props.defer !== true)
    return [];
  const diag = {
    ruleId: "defer-on-module-script",
    message: '"defer" is redundant on module scripts. Modules are deferred by default.',
    at: { kind: "prop", key: "defer" },
    fix: { type: "remove-prop", key: "defer" }
  };
  return [diag];
};
const scriptSrcWithContent = (tag) => {
  if (tag.tagType !== "script")
    return [];
  if (typeof tag.props.src !== "string")
    return [];
  const hasInner = tag.keys.has("innerHTML") && tag.props.innerHTML !== "" || tag.keys.has("textContent") && tag.props.textContent !== "";
  if (!hasInner)
    return [];
  const diag = {
    ruleId: "script-src-with-content",
    message: 'Script has both "src" and inline content. The browser will ignore the inline content.'
  };
  return [diag];
};

const NUMERIC_RE = /^\d+$/;
const twitterHandleMissingAt = (tag) => {
  if (tag.tagType !== "meta")
    return [];
  const name = tag.props.name;
  if (name !== "twitter:site" && name !== "twitter:creator")
    return [];
  const content = tag.props.content;
  if (typeof content !== "string")
    return [];
  if (content.startsWith("@") || NUMERIC_RE.test(content))
    return [];
  const fixedSource = JSON.stringify(`@${content}`);
  const diag = {
    ruleId: "twitter-handle-missing-at",
    message: `${name} should start with "@", received "${content}".`,
    at: { kind: "prop-value", key: "content" },
    fix: { type: "replace-prop-value", key: "content", newSource: fixedSource }
  };
  return [diag];
};

const USER_SCALABLE_NO_RE = /user-scalable\s*=\s*(?:no|0|false)(?:[\s,;]|$)/i;
const MAX_SCALE_RE = /maximum-scale\s*=\s*1(?:\.\d+)?(?:[\s,;]|$)/i;
const viewportUserScalable = (tag) => {
  if (tag.tagType !== "meta")
    return [];
  if (tag.props.name !== "viewport")
    return [];
  const content = tag.props.content;
  if (typeof content !== "string")
    return [];
  const out = [];
  if (USER_SCALABLE_NO_RE.test(content)) {
    out.push({
      ruleId: "viewport-user-scalable",
      message: 'viewport "user-scalable=no" prevents zooming and harms accessibility.'
    });
  }
  if (MAX_SCALE_RE.test(content)) {
    out.push({
      ruleId: "viewport-user-scalable",
      message: 'viewport "maximum-scale=1" limits zooming and may harm accessibility.'
    });
  }
  return out;
};

const TAG_TYPES = /* @__PURE__ */ new Set(["meta", "link", "script", "noscript", "style"]);
function valueKind(value) {
  if (value === null)
    return "null";
  if (Array.isArray(value))
    return "array";
  const kind = typeof value;
  if (kind === "boolean" || kind === "function" || kind === "number" || kind === "object" || kind === "string")
    return kind;
  return "unknown";
}
function inputShapeFromRuntime(context, input) {
  const keys = /* @__PURE__ */ new Set();
  const valueKinds = /* @__PURE__ */ new Map();
  for (const [key, value] of Object.entries(input)) {
    keys.add(key);
    valueKinds.set(key, valueKind(value));
  }
  return { context, keys, valueKinds };
}
function tagInputFromRuntime(tag) {
  if (!TAG_TYPES.has(tag.tag))
    return void 0;
  const props = {};
  const keys = /* @__PURE__ */ new Set();
  for (const [k, v] of Object.entries(tag.props)) {
    keys.add(k);
    if (v == null) {
      if (tag.tag === "meta" && k === "content")
        props[k] = "";
      continue;
    }
    if (typeof v === "string" || typeof v === "number" || typeof v === "boolean") {
      if (tag.tag === "meta" && k === "name" && typeof v === "string")
        props[k] = v.toLowerCase();
      else
        props[k] = v;
    } else {
      props[k] = String(v);
    }
  }
  if (tag.tag === "script" || tag.tag === "style" || tag.tag === "noscript") {
    if (tag.innerHTML != null && tag.innerHTML !== "") {
      keys.add("innerHTML");
    }
    if (tag.textContent != null && tag.textContent !== "") {
      keys.add("textContent");
    }
  }
  if (tag.tagPriority != null) {
    keys.add("tagPriority");
    if (typeof tag.tagPriority === "string" || typeof tag.tagPriority === "number")
      props.tagPriority = tag.tagPriority;
  }
  return {
    tagType: tag.tag,
    props,
    keys
  };
}
function titleInputFromRuntime(titleTag) {
  if (titleTag.tag !== "title")
    return void 0;
  const text = titleTag.textContent ?? titleTag.innerHTML ?? "";
  return {
    callee: "runtime",
    props: { title: text },
    keys: /* @__PURE__ */ new Set(["title"])
  };
}

const tagPredicates = {
  "defer-on-module-script": deferOnModuleScript,
  "empty-meta-content": emptyMetaContent,
  "no-deprecated-props": noDeprecatedProps,
  "no-unknown-meta": noUnknownMeta,
  "non-absolute-canonical": nonAbsoluteCanonical,
  "numeric-tag-priority": numericTagPriority,
  "preload-font-crossorigin": preloadFontCrossorigin,
  "preload-missing-as": preloadMissingAs,
  "robots-conflict": robotsConflict,
  "script-src-with-content": scriptSrcWithContent,
  "twitter-handle-missing-at": twitterHandleMissingAt,
  "viewport-user-scalable": viewportUserScalable
};
const inputShapePredicates = {
  "invalid-input-shape": validateInputShape
};
const migrationTagPredicates = {
  "prefer-define-helpers": preferDefineHelpers
};
const headInputPredicates = {
  "no-html-in-title": noHtmlInTitle
};

export { DEPRECATED_PROPS as D, INPUT_SHAPE_FIELDS as I, KNOWN_META_NAMES as K, TAG_PRIORITY_ALIASES as T, URL_META_KEYS as U, KNOWN_META_PROPERTIES as a, inputShapePredicates as b, noHtmlInTitle as c, deferOnModuleScript as d, emptyMetaContent as e, findClosestMatch as f, noUnknownMeta as g, headInputPredicates as h, inputShapeFromRuntime as i, nonAbsoluteCanonical as j, numericTagPriority as k, levenshtein as l, migrationTagPredicates as m, noDeprecatedProps as n, preloadFontCrossorigin as o, preferDefineHelpers as p, preloadMissingAs as q, robotsConflict as r, scriptSrcWithContent as s, tagInputFromRuntime as t, tagPredicates as u, titleInputFromRuntime as v, twitterHandleMissingAt as w, validateInputShape as x, viewportUserScalable as y };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVuaGVhZC5CRW1WTWtlQS5tanM/dj03ZTczYWZjMiJdLCJzb3VyY2VzQ29udGVudCI6WyJjb25zdCBVUkxfTUVUQV9LRVlTID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoW1xuICBcIm9nOnVybFwiLFxuICBcIm9nOmltYWdlXCIsXG4gIFwib2c6aW1hZ2U6dXJsXCIsXG4gIFwib2c6aW1hZ2U6c2VjdXJlX3VybFwiLFxuICBcIm9nOnZpZGVvXCIsXG4gIFwib2c6dmlkZW86dXJsXCIsXG4gIFwib2c6dmlkZW86c2VjdXJlX3VybFwiLFxuICBcIm9nOmF1ZGlvXCIsXG4gIFwib2c6YXVkaW86dXJsXCIsXG4gIFwib2c6YXVkaW86c2VjdXJlX3VybFwiLFxuICBcInR3aXR0ZXI6aW1hZ2VcIixcbiAgXCJ0d2l0dGVyOmltYWdlOnNyY1wiLFxuICBcInR3aXR0ZXI6cGxheWVyXCIsXG4gIFwidHdpdHRlcjpwbGF5ZXI6c3RyZWFtXCIsXG4gIFwicGF5bWVudDpzdWNjZXNzX3VybFwiXG5dKTtcbmNvbnN0IEtOT1dOX01FVEFfUFJPUEVSVElFUyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KFtcbiAgXCJhcnRpY2xlOmF1dGhvclwiLFxuICBcImFydGljbGU6ZXhwaXJhdGlvbl90aW1lXCIsXG4gIFwiYXJ0aWNsZTptb2RpZmllZF90aW1lXCIsXG4gIFwiYXJ0aWNsZTpwdWJsaXNoZWRfdGltZVwiLFxuICBcImFydGljbGU6c2VjdGlvblwiLFxuICBcImFydGljbGU6dGFnXCIsXG4gIFwiYm9vazphdXRob3JcIixcbiAgXCJib29rOmlzYm5cIixcbiAgXCJib29rOnJlbGVhc2VfZGF0ZVwiLFxuICBcImJvb2s6dGFnXCIsXG4gIFwiZmI6YXBwX2lkXCIsXG4gIFwib2c6YXVkaW9cIixcbiAgXCJvZzphdWRpbzpzZWN1cmVfdXJsXCIsXG4gIFwib2c6YXVkaW86dHlwZVwiLFxuICBcIm9nOmF1ZGlvOnVybFwiLFxuICBcIm9nOmRlc2NyaXB0aW9uXCIsXG4gIFwib2c6ZGV0ZXJtaW5lclwiLFxuICBcIm9nOmltYWdlXCIsXG4gIFwib2c6aW1hZ2U6YWx0XCIsXG4gIFwib2c6aW1hZ2U6aGVpZ2h0XCIsXG4gIFwib2c6aW1hZ2U6c2VjdXJlX3VybFwiLFxuICBcIm9nOmltYWdlOnR5cGVcIixcbiAgXCJvZzppbWFnZTp1cmxcIixcbiAgXCJvZzppbWFnZTp3aWR0aFwiLFxuICBcIm9nOmxvY2FsZVwiLFxuICBcIm9nOmxvY2FsZTphbHRlcm5hdGVcIixcbiAgXCJvZzpzaXRlX25hbWVcIixcbiAgXCJvZzp0aXRsZVwiLFxuICBcIm9nOnR5cGVcIixcbiAgXCJvZzp1cmxcIixcbiAgXCJvZzp2aWRlb1wiLFxuICBcIm9nOnZpZGVvOmFsdFwiLFxuICBcIm9nOnZpZGVvOmR1cmF0aW9uXCIsXG4gIFwib2c6dmlkZW86aGVpZ2h0XCIsXG4gIFwib2c6dmlkZW86c2VjdXJlX3VybFwiLFxuICBcIm9nOnZpZGVvOnR5cGVcIixcbiAgXCJvZzp2aWRlbzp1cmxcIixcbiAgXCJvZzp2aWRlbzp3aWR0aFwiLFxuICBcInBheW1lbnQ6YW1vdW50XCIsXG4gIFwicGF5bWVudDpjdXJyZW5jeVwiLFxuICBcInBheW1lbnQ6ZGVzY3JpcHRpb25cIixcbiAgXCJwYXltZW50OmV4cGlyZXNfYXRcIixcbiAgXCJwYXltZW50OmlkXCIsXG4gIFwicGF5bWVudDpzdGF0dXNcIixcbiAgXCJwYXltZW50OnN1Y2Nlc3NfdXJsXCIsXG4gIFwicHJvZmlsZTpmaXJzdF9uYW1lXCIsXG4gIFwicHJvZmlsZTpnZW5kZXJcIixcbiAgXCJwcm9maWxlOmxhc3RfbmFtZVwiLFxuICBcInByb2ZpbGU6dXNlcm5hbWVcIlxuXSk7XG5jb25zdCBLTk9XTl9NRVRBX05BTUVTID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoW1xuICBcImFwcGxlLWl0dW5lcy1hcHBcIixcbiAgXCJhcHBsZS1tb2JpbGUtd2ViLWFwcC1jYXBhYmxlXCIsXG4gIFwiYXBwbGUtbW9iaWxlLXdlYi1hcHAtc3RhdHVzLWJhci1zdHlsZVwiLFxuICBcImFwcGxlLW1vYmlsZS13ZWItYXBwLXRpdGxlXCIsXG4gIFwiYXBwbGljYXRpb24tbmFtZVwiLFxuICBcImF1dGhvclwiLFxuICBcImNvbG9yLXNjaGVtZVwiLFxuICBcImNyZWF0b3JcIixcbiAgXCJkZXNjcmlwdGlvblwiLFxuICBcImZiOmFwcF9pZFwiLFxuICBcImZlZGl2ZXJzZTpjcmVhdG9yXCIsXG4gIFwiZm9ybWF0LWRldGVjdGlvblwiLFxuICBcImdlbmVyYXRvclwiLFxuICBcImdvb2dsZS1zaXRlLXZlcmlmaWNhdGlvblwiLFxuICBcImdvb2dsZVwiLFxuICBcImdvb2dsZWJvdFwiLFxuICBcImtleXdvcmRzXCIsXG4gIFwibW9iaWxlLXdlYi1hcHAtY2FwYWJsZVwiLFxuICBcIm1zYXBwbGljYXRpb24tY29uZmlnXCIsXG4gIFwibXNhcHBsaWNhdGlvbi10aWxlY29sb3JcIixcbiAgXCJtc2FwcGxpY2F0aW9uLXRpbGVpbWFnZVwiLFxuICBcInB1Ymxpc2hlclwiLFxuICBcInJhdGluZ1wiLFxuICBcInJlZmVycmVyXCIsXG4gIFwicm9ib3RzXCIsXG4gIFwidGhlbWUtY29sb3JcIixcbiAgXCJ2aWV3cG9ydFwiLFxuICBcInR3aXR0ZXI6YXBwOmlkOmdvb2dsZXBsYXlcIixcbiAgXCJ0d2l0dGVyOmFwcDppZDppcGFkXCIsXG4gIFwidHdpdHRlcjphcHA6aWQ6aXBob25lXCIsXG4gIFwidHdpdHRlcjphcHA6bmFtZTpnb29nbGVwbGF5XCIsXG4gIFwidHdpdHRlcjphcHA6bmFtZTppcGFkXCIsXG4gIFwidHdpdHRlcjphcHA6bmFtZTppcGhvbmVcIixcbiAgXCJ0d2l0dGVyOmFwcDp1cmw6Z29vZ2xlcGxheVwiLFxuICBcInR3aXR0ZXI6YXBwOnVybDppcGFkXCIsXG4gIFwidHdpdHRlcjphcHA6dXJsOmlwaG9uZVwiLFxuICBcInR3aXR0ZXI6Y2FyZFwiLFxuICBcInR3aXR0ZXI6Y3JlYXRvclwiLFxuICBcInR3aXR0ZXI6Y3JlYXRvcjppZFwiLFxuICBcInR3aXR0ZXI6ZGF0YToxXCIsXG4gIFwidHdpdHRlcjpkYXRhOjJcIixcbiAgXCJ0d2l0dGVyOmRlc2NyaXB0aW9uXCIsXG4gIFwidHdpdHRlcjppbWFnZVwiLFxuICBcInR3aXR0ZXI6aW1hZ2U6YWx0XCIsXG4gIFwidHdpdHRlcjpsYWJlbDoxXCIsXG4gIFwidHdpdHRlcjpsYWJlbDoyXCIsXG4gIFwidHdpdHRlcjpwbGF5ZXJcIixcbiAgXCJ0d2l0dGVyOnBsYXllcjpoZWlnaHRcIixcbiAgXCJ0d2l0dGVyOnBsYXllcjpzdHJlYW1cIixcbiAgXCJ0d2l0dGVyOnBsYXllcjp3aWR0aFwiLFxuICBcInR3aXR0ZXI6c2l0ZVwiLFxuICBcInR3aXR0ZXI6c2l0ZTppZFwiLFxuICBcInR3aXR0ZXI6dGl0bGVcIlxuXSk7XG5jb25zdCBUQUdfUFJJT1JJVFlfQUxJQVNFUyA9IFtcImNyaXRpY2FsXCIsIFwiaGlnaFwiLCBcImxvd1wiXTtcbmNvbnN0IERFUFJFQ0FURURfUFJPUFMgPSB7XG4gIGNoaWxkcmVuOiB7IHJlcGxhY2VtZW50OiBcImlubmVySFRNTFwiLCBydWxlSWQ6IFwiZGVwcmVjYXRlZC1wcm9wLWNoaWxkcmVuXCIgfSxcbiAgaGlkOiB7IHJlcGxhY2VtZW50OiBcImtleVwiLCBydWxlSWQ6IFwiZGVwcmVjYXRlZC1wcm9wLWhpZC12bWlkXCIgfSxcbiAgdm1pZDogeyByZXBsYWNlbWVudDogXCJrZXlcIiwgcnVsZUlkOiBcImRlcHJlY2F0ZWQtcHJvcC1oaWQtdm1pZFwiIH0sXG4gIGJvZHk6IHsgcmVwbGFjZW1lbnQ6IFwidGFnUG9zaXRpb246ICdib2R5Q2xvc2UnXCIsIHJ1bGVJZDogXCJkZXByZWNhdGVkLXByb3AtYm9keVwiIH1cbn07XG5cbmZ1bmN0aW9uIGxldmVuc2h0ZWluKGEsIGIpIHtcbiAgY29uc3QgbSA9IGEubGVuZ3RoO1xuICBjb25zdCBuID0gYi5sZW5ndGg7XG4gIGNvbnN0IGQgPSBBcnJheS5mcm9tKHsgbGVuZ3RoOiBuICsgMSB9LCAoXywgaSkgPT4gaSk7XG4gIGZvciAobGV0IGkgPSAxOyBpIDw9IG07IGkrKykge1xuICAgIGxldCBwcmV2ID0gaSAtIDE7XG4gICAgZFswXSA9IGk7XG4gICAgZm9yIChsZXQgaiA9IDE7IGogPD0gbjsgaisrKSB7XG4gICAgICBjb25zdCB0bXAgPSBkW2pdO1xuICAgICAgZFtqXSA9IGFbaSAtIDFdID09PSBiW2ogLSAxXSA/IHByZXYgOiAxICsgTWF0aC5taW4ocHJldiwgZFtqXSwgZFtqIC0gMV0pO1xuICAgICAgcHJldiA9IHRtcDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGRbbl07XG59XG5mdW5jdGlvbiBmaW5kQ2xvc2VzdE1hdGNoKHZhbHVlLCBrbm93blNldCkge1xuICBjb25zdCB0aHJlc2hvbGQgPSB2YWx1ZS5sZW5ndGggPD0gOCA/IDIgOiAzO1xuICBsZXQgYmVzdDtcbiAgbGV0IGJlc3REaXN0ID0gdGhyZXNob2xkICsgMTtcbiAgZm9yIChjb25zdCBrbm93biBvZiBrbm93blNldCkge1xuICAgIGlmIChNYXRoLmFicyhrbm93bi5sZW5ndGggLSB2YWx1ZS5sZW5ndGgpID4gdGhyZXNob2xkKVxuICAgICAgY29udGludWU7XG4gICAgY29uc3QgZGlzdCA9IGxldmVuc2h0ZWluKHZhbHVlLCBrbm93bik7XG4gICAgaWYgKGRpc3QgPCBiZXN0RGlzdCkge1xuICAgICAgYmVzdERpc3QgPSBkaXN0O1xuICAgICAgYmVzdCA9IGtub3duO1xuICAgIH1cbiAgfVxuICByZXR1cm4gYmVzdDtcbn1cblxuY29uc3QgZW1wdHlNZXRhQ29udGVudCA9ICh0YWcpID0+IHtcbiAgaWYgKHRhZy50YWdUeXBlICE9PSBcIm1ldGFcIilcbiAgICByZXR1cm4gW107XG4gIGlmICghdGFnLmtleXMuaGFzKFwiY29udGVudFwiKSlcbiAgICByZXR1cm4gW107XG4gIGlmICh0YWcucHJvcHMuY29udGVudCAhPT0gXCJcIilcbiAgICByZXR1cm4gW107XG4gIGNvbnN0IGtleSA9IHR5cGVvZiB0YWcucHJvcHMubmFtZSA9PT0gXCJzdHJpbmdcIiAmJiB0YWcucHJvcHMubmFtZSB8fCB0eXBlb2YgdGFnLnByb3BzLnByb3BlcnR5ID09PSBcInN0cmluZ1wiICYmIHRhZy5wcm9wcy5wcm9wZXJ0eSB8fCBcIm1ldGFcIjtcbiAgY29uc3QgZGlhZyA9IHtcbiAgICBydWxlSWQ6IFwiZW1wdHktbWV0YS1jb250ZW50XCIsXG4gICAgbWVzc2FnZTogYE1ldGEgdGFnIFwiJHtrZXl9XCIgaGFzIGVtcHR5IGNvbnRlbnQuYCxcbiAgICBhdDogeyBraW5kOiBcInByb3BcIiwga2V5OiBcImNvbnRlbnRcIiB9XG4gIH07XG4gIHJldHVybiBbZGlhZ107XG59O1xuXG5jb25zdCBSRVNPTFZBQkxFX09CSkVDVCA9IFtcImJvb2xlYW5cIiwgXCJmdW5jdGlvblwiLCBcIm51bGxcIiwgXCJvYmplY3RcIl07XG5jb25zdCBSRVNPTFZBQkxFX1RBR19MSVNUID0gW1wiYXJyYXlcIiwgXCJib29sZWFuXCIsIFwiZnVuY3Rpb25cIiwgXCJudWxsXCJdO1xuY29uc3QgUkVTT0xWQUJMRV9USVRMRSA9IFtcImJvb2xlYW5cIiwgXCJmdW5jdGlvblwiLCBcIm51bGxcIiwgXCJudW1iZXJcIiwgXCJvYmplY3RcIiwgXCJzdHJpbmdcIl07XG5jb25zdCBBVFRSSUJVVEVfU0NBTEFSID0gW1wiYm9vbGVhblwiLCBcImZ1bmN0aW9uXCIsIFwibnVsbFwiLCBcIm51bWJlclwiLCBcInN0cmluZ1wiXTtcbmNvbnN0IEFUVFJJQlVURV9TVFJVQ1RVUkVEID0gW1wiYXJyYXlcIiwgXCJib29sZWFuXCIsIFwiZnVuY3Rpb25cIiwgXCJudWxsXCIsIFwibnVtYmVyXCIsIFwib2JqZWN0XCIsIFwic3RyaW5nXCJdO1xuY29uc3QgSU5QVVRfU0hBUEVfRklFTERTID0ge1xuICBiYXNlOiB7XG4gICAgY2Fub25pY2FsOiBcImJhc2VcIixcbiAgICBjb250ZXh0czogeyBoZWFkOiBSRVNPTFZBQkxFX09CSkVDVCB9XG4gIH0sXG4gIGJvZHlhdHRyczoge1xuICAgIGNhbm9uaWNhbDogXCJib2R5QXR0cnNcIixcbiAgICBjb250ZXh0czogeyBoZWFkOiBSRVNPTFZBQkxFX09CSkVDVCB9XG4gIH0sXG4gIGNsYXNzOiB7XG4gICAgY2Fub25pY2FsOiBcImNsYXNzXCIsXG4gICAgY29udGV4dHM6IHtcbiAgICAgIGJvZHlBdHRyczogQVRUUklCVVRFX1NUUlVDVFVSRUQsXG4gICAgICBodG1sQXR0cnM6IEFUVFJJQlVURV9TVFJVQ1RVUkVEXG4gICAgfVxuICB9LFxuICBodG1sYXR0cnM6IHtcbiAgICBjYW5vbmljYWw6IFwiaHRtbEF0dHJzXCIsXG4gICAgY29udGV4dHM6IHsgaGVhZDogUkVTT0xWQUJMRV9PQkpFQ1QgfVxuICB9LFxuICBsaW5rOiB7XG4gICAgY2Fub25pY2FsOiBcImxpbmtcIixcbiAgICBjb250ZXh0czogeyBoZWFkOiBSRVNPTFZBQkxFX1RBR19MSVNUIH1cbiAgfSxcbiAgbWV0YToge1xuICAgIGNhbm9uaWNhbDogXCJtZXRhXCIsXG4gICAgY29udGV4dHM6IHsgaGVhZDogUkVTT0xWQUJMRV9UQUdfTElTVCB9XG4gIH0sXG4gIG5vc2NyaXB0OiB7XG4gICAgY2Fub25pY2FsOiBcIm5vc2NyaXB0XCIsXG4gICAgY29udGV4dHM6IHsgaGVhZDogUkVTT0xWQUJMRV9UQUdfTElTVCB9XG4gIH0sXG4gIHNjcmlwdDoge1xuICAgIGNhbm9uaWNhbDogXCJzY3JpcHRcIixcbiAgICBjb250ZXh0czogeyBoZWFkOiBSRVNPTFZBQkxFX1RBR19MSVNUIH1cbiAgfSxcbiAgc3R5bGU6IHtcbiAgICBjYW5vbmljYWw6IFwic3R5bGVcIixcbiAgICBjb250ZXh0czoge1xuICAgICAgYm9keUF0dHJzOiBBVFRSSUJVVEVfU1RSVUNUVVJFRCxcbiAgICAgIGhlYWQ6IFJFU09MVkFCTEVfVEFHX0xJU1QsXG4gICAgICBodG1sQXR0cnM6IEFUVFJJQlVURV9TVFJVQ1RVUkVEXG4gICAgfVxuICB9LFxuICB0ZW1wbGF0ZXBhcmFtczoge1xuICAgIGNhbm9uaWNhbDogXCJ0ZW1wbGF0ZVBhcmFtc1wiLFxuICAgIGNvbnRleHRzOiB7IGhlYWQ6IFtcIm9iamVjdFwiXSB9XG4gIH0sXG4gIHRpdGxlOiB7XG4gICAgY2Fub25pY2FsOiBcInRpdGxlXCIsXG4gICAgY29udGV4dHM6IHtcbiAgICAgIGJvZHlBdHRyczogQVRUUklCVVRFX1NDQUxBUixcbiAgICAgIGhlYWQ6IFJFU09MVkFCTEVfVElUTEUsXG4gICAgICBodG1sQXR0cnM6IEFUVFJJQlVURV9TQ0FMQVIsXG4gICAgICBzZW9NZXRhOiBSRVNPTFZBQkxFX1RJVExFXG4gICAgfVxuICB9LFxuICB0aXRsZXRlbXBsYXRlOiB7XG4gICAgY2Fub25pY2FsOiBcInRpdGxlVGVtcGxhdGVcIixcbiAgICBjb250ZXh0czoge1xuICAgICAgaGVhZDogW1wiZnVuY3Rpb25cIiwgXCJudWxsXCIsIFwib2JqZWN0XCIsIFwic3RyaW5nXCJdLFxuICAgICAgc2VvTWV0YTogW1wiZnVuY3Rpb25cIiwgXCJudWxsXCIsIFwib2JqZWN0XCIsIFwic3RyaW5nXCJdXG4gICAgfVxuICB9XG59O1xuZnVuY3Rpb24gaW5jbHVkZXMoa2luZHMsIGtpbmQpIHtcbiAgcmV0dXJuIGtpbmRzPy5pbmNsdWRlcyhraW5kKSA9PT0gdHJ1ZTtcbn1cbmZ1bmN0aW9uIGZvcm1hdEtpbmRzKGtpbmRzKSB7XG4gIHJldHVybiBraW5kcy5qb2luKFwiLCBcIik7XG59XG5mdW5jdGlvbiBpbnZhbGlkS25vd25IZWFkRmllbGQoaW5wdXQsIGtleSwgc2hhcGUsIGtpbmQpIHtcbiAgY29uc3QgZXhwZWN0ZWQgPSBzaGFwZS5jb250ZXh0c1tpbnB1dC5jb250ZXh0XTtcbiAgaWYgKGluY2x1ZGVzKGV4cGVjdGVkLCBraW5kKSlcbiAgICByZXR1cm4gdm9pZCAwO1xuICBpZiAoKGlucHV0LmNvbnRleHQgPT09IFwiaHRtbEF0dHJzXCIgfHwgaW5wdXQuY29udGV4dCA9PT0gXCJib2R5QXR0cnNcIikgJiYga2luZCA9PT0gXCJudWxsXCIpXG4gICAgcmV0dXJuIHZvaWQgMDtcbiAgaWYgKGlucHV0LmNvbnRleHQgPT09IFwiaGVhZFwiKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHJ1bGVJZDogXCJpbnZhbGlkLWlucHV0LXNoYXBlXCIsXG4gICAgICBtZXNzYWdlOiBgXCIke3NoYXBlLmNhbm9uaWNhbH1cIiBpbiBhIGhlYWQgaW5wdXQgbXVzdCBiZSBvbmUgb2Y6ICR7Zm9ybWF0S2luZHMoZXhwZWN0ZWQgfHwgW10pfS4gUmVjZWl2ZWQgJHtraW5kfS5gLFxuICAgICAgYXQ6IHsga2luZDogXCJwcm9wLXZhbHVlXCIsIGtleSB9XG4gICAgfTtcbiAgfVxuICBpZiAoaW5jbHVkZXMoc2hhcGUuY29udGV4dHMuaGVhZCwga2luZCkpIHtcbiAgICByZXR1cm4ge1xuICAgICAgcnVsZUlkOiBcImludmFsaWQtaW5wdXQtc2hhcGVcIixcbiAgICAgIG1lc3NhZ2U6IGBcIiR7c2hhcGUuY2Fub25pY2FsfVwiIGhhcyBhIGhlYWQgaW5wdXQgc2hhcGUgYnV0IGFwcGVhcnMgaW4gJHtpbnB1dC5jb250ZXh0fS4gTW92ZSBpdCB0byB0aGUgdG9wLWxldmVsIGhlYWQgaW5wdXQuYCxcbiAgICAgIGF0OiB7IGtpbmQ6IFwicHJvcC12YWx1ZVwiLCBrZXkgfVxuICAgIH07XG4gIH1cbn1cbmZ1bmN0aW9uIGludmFsaWRBdHRyaWJ1dGVGaWVsZChpbnB1dCwga2V5LCBraW5kKSB7XG4gIGlmIChpbmNsdWRlcyhBVFRSSUJVVEVfU0NBTEFSLCBraW5kKSlcbiAgICByZXR1cm4gdm9pZCAwO1xuICByZXR1cm4ge1xuICAgIHJ1bGVJZDogXCJpbnZhbGlkLWlucHV0LXNoYXBlXCIsXG4gICAgbWVzc2FnZTogYFwiJHtrZXl9XCIgaW4gJHtpbnB1dC5jb250ZXh0fSBtdXN0IHJlc29sdmUgdG8gYSBzY2FsYXIgYXR0cmlidXRlIHZhbHVlLiBSZWNlaXZlZCAke2tpbmR9LmAsXG4gICAgYXQ6IHsga2luZDogXCJwcm9wLXZhbHVlXCIsIGtleSB9XG4gIH07XG59XG5mdW5jdGlvbiB2YWxpZGF0ZUlucHV0U2hhcGUoaW5wdXQpIHtcbiAgY29uc3QgZGlhZ25vc3RpY3MgPSBbXTtcbiAgY29uc3QgaXNBdHRyaWJ1dGVzID0gaW5wdXQuY29udGV4dCA9PT0gXCJodG1sQXR0cnNcIiB8fCBpbnB1dC5jb250ZXh0ID09PSBcImJvZHlBdHRyc1wiO1xuICBmb3IgKGNvbnN0IGtleSBvZiBpbnB1dC5rZXlzKSB7XG4gICAgY29uc3Qga2luZCA9IGlucHV0LnZhbHVlS2luZHMuZ2V0KGtleSkgPz8gXCJ1bmtub3duXCI7XG4gICAgaWYgKGtpbmQgPT09IFwidW5rbm93blwiKVxuICAgICAgY29udGludWU7XG4gICAgY29uc3Qgc2hhcGUgPSBJTlBVVF9TSEFQRV9GSUVMRFNba2V5LnRvTG93ZXJDYXNlKCldO1xuICAgIGNvbnN0IGtub3duRGlhZ25vc3RpYyA9IHNoYXBlID8gaW52YWxpZEtub3duSGVhZEZpZWxkKGlucHV0LCBrZXksIHNoYXBlLCBraW5kKSA6IHZvaWQgMDtcbiAgICBpZiAoa25vd25EaWFnbm9zdGljKSB7XG4gICAgICBkaWFnbm9zdGljcy5wdXNoKGtub3duRGlhZ25vc3RpYyk7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKGlzQXR0cmlidXRlcyAmJiAhc2hhcGU/LmNvbnRleHRzW2lucHV0LmNvbnRleHRdKSB7XG4gICAgICBjb25zdCBhdHRyaWJ1dGVEaWFnbm9zdGljID0gaW52YWxpZEF0dHJpYnV0ZUZpZWxkKGlucHV0LCBrZXksIGtpbmQpO1xuICAgICAgaWYgKGF0dHJpYnV0ZURpYWdub3N0aWMpXG4gICAgICAgIGRpYWdub3N0aWNzLnB1c2goYXR0cmlidXRlRGlhZ25vc3RpYyk7XG4gICAgfVxuICB9XG4gIHJldHVybiBkaWFnbm9zdGljcztcbn1cblxuY29uc3Qgbm9EZXByZWNhdGVkUHJvcHMgPSAodGFnKSA9PiB7XG4gIGNvbnN0IG91dCA9IFtdO1xuICBmb3IgKGNvbnN0IGtleSBvZiB0YWcua2V5cykge1xuICAgIGlmICghKGtleSBpbiBERVBSRUNBVEVEX1BST1BTKSlcbiAgICAgIGNvbnRpbnVlO1xuICAgIGNvbnN0IHsgcmVwbGFjZW1lbnQgfSA9IERFUFJFQ0FURURfUFJPUFNba2V5XTtcbiAgICBpZiAoa2V5ID09PSBcImJvZHlcIikge1xuICAgICAgaWYgKHRhZy5wcm9wcy5ib2R5ICE9PSB0cnVlKVxuICAgICAgICBjb250aW51ZTtcbiAgICAgIGNvbnN0IGZpeDIgPSB0YWcua2V5cy5oYXMoXCJ0YWdQb3NpdGlvblwiKSA/IHZvaWQgMCA6IHsgdHlwZTogXCJyZXBsYWNlLXByb3BcIiwga2V5OiBcImJvZHlcIiwgbmV3U291cmNlOiBgdGFnUG9zaXRpb246ICdib2R5Q2xvc2UnYCB9O1xuICAgICAgb3V0LnB1c2goe1xuICAgICAgICBydWxlSWQ6IFwiZGVwcmVjYXRlZC1wcm9wLWJvZHlcIixcbiAgICAgICAgbWVzc2FnZTogYFwiYm9keVwiIHdhcyByZW1vdmVkIGluIHYzIG9mIHVuaGVhZC4gVXNlIFwiJHtyZXBsYWNlbWVudH1cIiBpbnN0ZWFkLmAsXG4gICAgICAgIGF0OiB7IGtpbmQ6IFwicHJvcFwiLCBrZXkgfSxcbiAgICAgICAgZml4OiBmaXgyXG4gICAgICB9KTtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCBuZXdLZXkgPSBrZXkgPT09IFwiY2hpbGRyZW5cIiA/IFwiaW5uZXJIVE1MXCIgOiBcImtleVwiO1xuICAgIGNvbnN0IGZpeCA9IHRhZy5rZXlzLmhhcyhuZXdLZXkpID8gdm9pZCAwIDogeyB0eXBlOiBcInJlbmFtZS1wcm9wXCIsIGtleSwgbmV3S2V5IH07XG4gICAgb3V0LnB1c2goe1xuICAgICAgcnVsZUlkOiBrZXkgPT09IFwiY2hpbGRyZW5cIiA/IFwiZGVwcmVjYXRlZC1wcm9wLWNoaWxkcmVuXCIgOiBcImRlcHJlY2F0ZWQtcHJvcC1oaWQtdm1pZFwiLFxuICAgICAgbWVzc2FnZTogYFwiJHtrZXl9XCIgd2FzIHJlbW92ZWQgaW4gdjMgb2YgdW5oZWFkLiBVc2UgXCIke3JlcGxhY2VtZW50fVwiIGluc3RlYWQuYCxcbiAgICAgIGF0OiB7IGtpbmQ6IFwicHJvcFwiLCBrZXkgfSxcbiAgICAgIGZpeFxuICAgIH0pO1xuICB9XG4gIHJldHVybiBvdXQ7XG59O1xuXG5jb25zdCBIVE1MX0NIQVJTX1JFID0gL1s8Pl0vO1xuY29uc3Qgbm9IdG1sSW5UaXRsZSA9IChpbnB1dCkgPT4ge1xuICBjb25zdCB0aXRsZSA9IGlucHV0LnByb3BzLnRpdGxlO1xuICBpZiAodHlwZW9mIHRpdGxlICE9PSBcInN0cmluZ1wiIHx8ICFIVE1MX0NIQVJTX1JFLnRlc3QodGl0bGUpKVxuICAgIHJldHVybiBbXTtcbiAgY29uc3QgZGlhZyA9IHtcbiAgICBydWxlSWQ6IFwiaHRtbC1pbi10aXRsZVwiLFxuICAgIG1lc3NhZ2U6IGBUaXRsZSBjb250YWlucyBIVE1MIGNoYXJhY3RlcnMgd2hpY2ggd2lsbCBiZSBlc2NhcGVkLCBub3QgcmVuZGVyZWQ6IFwiJHt0aXRsZX1cIi5gLFxuICAgIGF0OiB7IGtpbmQ6IFwicHJvcC12YWx1ZVwiLCBrZXk6IFwidGl0bGVcIiB9XG4gIH07XG4gIHJldHVybiBbZGlhZ107XG59O1xuXG5jb25zdCBPR19QUkVGSVhfUkUgPSAvXig/Om9nfGFydGljbGV8Ym9va3xwcm9maWxlfGZiKTovO1xuY29uc3Qgbm9Vbmtub3duTWV0YSA9ICh0YWcpID0+IHtcbiAgaWYgKHRhZy50YWdUeXBlICE9PSBcIm1ldGFcIilcbiAgICByZXR1cm4gW107XG4gIGNvbnN0IG91dCA9IFtdO1xuICBjb25zdCBwcm9wZXJ0eSA9IHRhZy5wcm9wcy5wcm9wZXJ0eTtcbiAgaWYgKHR5cGVvZiBwcm9wZXJ0eSA9PT0gXCJzdHJpbmdcIiAmJiAhS05PV05fTUVUQV9QUk9QRVJUSUVTLmhhcyhwcm9wZXJ0eSkgJiYgT0dfUFJFRklYX1JFLnRlc3QocHJvcGVydHkpKSB7XG4gICAgY29uc3Qgc3VnZ2VzdGlvbiA9IGZpbmRDbG9zZXN0TWF0Y2gocHJvcGVydHksIEtOT1dOX01FVEFfUFJPUEVSVElFUyk7XG4gICAgaWYgKHN1Z2dlc3Rpb24pIHtcbiAgICAgIG91dC5wdXNoKHtcbiAgICAgICAgcnVsZUlkOiBcInBvc3NpYmxlLXR5cG9cIixcbiAgICAgICAgbWVzc2FnZTogYFVua25vd24gbWV0YSBwcm9wZXJ0eSBcIiR7cHJvcGVydHl9XCIuIERpZCB5b3UgbWVhbiBcIiR7c3VnZ2VzdGlvbn1cIj9gLFxuICAgICAgICBhdDogeyBraW5kOiBcInByb3AtdmFsdWVcIiwga2V5OiBcInByb3BlcnR5XCIgfSxcbiAgICAgICAgZml4OiB7IHR5cGU6IFwicmVwbGFjZS1wcm9wLXZhbHVlXCIsIGtleTogXCJwcm9wZXJ0eVwiLCBuZXdTb3VyY2U6IGAnJHtzdWdnZXN0aW9ufSdgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBjb25zdCBuYW1lID0gdGFnLnByb3BzLm5hbWU7XG4gIGlmICh0eXBlb2YgbmFtZSA9PT0gXCJzdHJpbmdcIikge1xuICAgIGNvbnN0IGxvd2VyID0gbmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgIGlmICghS05PV05fTUVUQV9OQU1FUy5oYXMobG93ZXIpICYmIChsb3dlci5zdGFydHNXaXRoKFwidHdpdHRlcjpcIikgfHwgbG93ZXIuc3RhcnRzV2l0aChcImZlZGl2ZXJzZTpcIikgfHwgIWxvd2VyLmluY2x1ZGVzKFwiOlwiKSkpIHtcbiAgICAgIGNvbnN0IHN1Z2dlc3Rpb24gPSBmaW5kQ2xvc2VzdE1hdGNoKGxvd2VyLCBLTk9XTl9NRVRBX05BTUVTKTtcbiAgICAgIGlmIChzdWdnZXN0aW9uKSB7XG4gICAgICAgIG91dC5wdXNoKHtcbiAgICAgICAgICBydWxlSWQ6IFwicG9zc2libGUtdHlwb1wiLFxuICAgICAgICAgIG1lc3NhZ2U6IGBVbmtub3duIG1ldGEgbmFtZSBcIiR7bmFtZX1cIi4gRGlkIHlvdSBtZWFuIFwiJHtzdWdnZXN0aW9ufVwiP2AsXG4gICAgICAgICAgYXQ6IHsga2luZDogXCJwcm9wLXZhbHVlXCIsIGtleTogXCJuYW1lXCIgfSxcbiAgICAgICAgICBmaXg6IHsgdHlwZTogXCJyZXBsYWNlLXByb3AtdmFsdWVcIiwga2V5OiBcIm5hbWVcIiwgbmV3U291cmNlOiBgJyR7c3VnZ2VzdGlvbn0nYCB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gb3V0O1xufTtcblxuZnVuY3Rpb24gaXNBYnNvbHV0ZSh1cmwpIHtcbiAgcmV0dXJuIHVybC5zdGFydHNXaXRoKFwiaHR0cDovL1wiKSB8fCB1cmwuc3RhcnRzV2l0aChcImh0dHBzOi8vXCIpO1xufVxuY29uc3Qgbm9uQWJzb2x1dGVDYW5vbmljYWwgPSAodGFnKSA9PiB7XG4gIGlmICh0YWcudGFnVHlwZSAhPT0gXCJsaW5rXCIpXG4gICAgcmV0dXJuIFtdO1xuICBpZiAodGFnLnByb3BzLnJlbCAhPT0gXCJjYW5vbmljYWxcIilcbiAgICByZXR1cm4gW107XG4gIGNvbnN0IGhyZWYgPSB0YWcucHJvcHMuaHJlZjtcbiAgaWYgKHR5cGVvZiBocmVmICE9PSBcInN0cmluZ1wiKVxuICAgIHJldHVybiBbXTtcbiAgaWYgKGlzQWJzb2x1dGUoaHJlZikpXG4gICAgcmV0dXJuIFtdO1xuICBjb25zdCBkaWFnID0ge1xuICAgIHJ1bGVJZDogXCJub24tYWJzb2x1dGUtY2Fub25pY2FsXCIsXG4gICAgbWVzc2FnZTogYENhbm9uaWNhbCBVUkwgc2hvdWxkIGJlIGFic29sdXRlLCByZWNlaXZlZCBcIiR7aHJlZn1cIi5gLFxuICAgIGF0OiB7IGtpbmQ6IFwicHJvcC12YWx1ZVwiLCBrZXk6IFwiaHJlZlwiIH1cbiAgfTtcbiAgcmV0dXJuIFtkaWFnXTtcbn07XG5cbmNvbnN0IEFMSUFTRVMgPSBbXCJjcml0aWNhbFwiLCBcImhpZ2hcIiwgXCJsb3dcIl07XG5jb25zdCBudW1lcmljVGFnUHJpb3JpdHkgPSAodGFnKSA9PiB7XG4gIGNvbnN0IHZhbHVlID0gdGFnLnByb3BzLnRhZ1ByaW9yaXR5O1xuICBpZiAodHlwZW9mIHZhbHVlICE9PSBcIm51bWJlclwiKVxuICAgIHJldHVybiBbXTtcbiAgY29uc3QgZGlhZyA9IHtcbiAgICBydWxlSWQ6IFwibnVtZXJpYy10YWctcHJpb3JpdHlcIixcbiAgICBtZXNzYWdlOiBgTnVtZXJpYyB0YWdQcmlvcml0eSAoJHt2YWx1ZX0pIGlzIGJyaXR0bGUuIFByZWZlciBhbiBhbGlhcyAoJ2NyaXRpY2FsJyB8ICdoaWdoJyB8ICdsb3cnKSBvciAnYmVmb3JlOjxrZXk+JyAvICdhZnRlcjo8a2V5PicuYCxcbiAgICBhdDogeyBraW5kOiBcInByb3AtdmFsdWVcIiwga2V5OiBcInRhZ1ByaW9yaXR5XCIgfSxcbiAgICBzdWdnZXN0aW9uczogQUxJQVNFUy5tYXAoKGFsaWFzKSA9PiAoe1xuICAgICAgbWVzc2FnZTogYFJlcGxhY2Ugd2l0aCAnJHthbGlhc30nYCxcbiAgICAgIGZpeDogeyB0eXBlOiBcInJlcGxhY2UtcHJvcC12YWx1ZVwiLCBrZXk6IFwidGFnUHJpb3JpdHlcIiwgbmV3U291cmNlOiBgJyR7YWxpYXN9J2AgfVxuICAgIH0pKVxuICB9O1xuICByZXR1cm4gW2RpYWddO1xufTtcblxuY29uc3QgVEFHX1RPX0hFTFBFUiA9IHtcbiAgbGluazogXCJkZWZpbmVMaW5rXCIsXG4gIHNjcmlwdDogXCJkZWZpbmVTY3JpcHRcIlxufTtcbmNvbnN0IHByZWZlckRlZmluZUhlbHBlcnMgPSAodGFnLCBjdHgpID0+IHtcbiAgaWYgKCF0YWcuaW5BcnJheSlcbiAgICByZXR1cm4gW107XG4gIGNvbnN0IGhlbHBlciA9IFRBR19UT19IRUxQRVJbdGFnLnRhZ1R5cGVdO1xuICBpZiAoIWhlbHBlcilcbiAgICByZXR1cm4gW107XG4gIGNvbnN0IGxvY2FsTmFtZSA9IGN0eD8uaW1wb3J0ZWRIZWxwZXJzPy5nZXQoaGVscGVyKTtcbiAgY29uc3QgaW1wb3J0ZWQgPSBsb2NhbE5hbWUgIT09IHZvaWQgMDtcbiAgY29uc3QgZml4ID0geyB0eXBlOiBcIndyYXAtdGFnXCIsIHdyYXBXaXRoOiBsb2NhbE5hbWUgPz8gaGVscGVyIH07XG4gIGNvbnN0IGRpYWcgPSB7XG4gICAgcnVsZUlkOiBcInByZWZlci1kZWZpbmUtaGVscGVyc1wiLFxuICAgIG1lc3NhZ2U6IGBXcmFwIHRoaXMgJHt0YWcudGFnVHlwZX0gZW50cnkgaW4gXFxgJHtoZWxwZXJ9KClcXGAgc28gdW5oZWFkIGNhbiBuYXJyb3cgaXRzIHR5cGUuYCxcbiAgICBmaXg6IGltcG9ydGVkID8gZml4IDogdm9pZCAwLFxuICAgIHN1Z2dlc3Rpb25zOiBpbXBvcnRlZCA/IHZvaWQgMCA6IFt7IG1lc3NhZ2U6IGBXcmFwIGluIFxcYCR7aGVscGVyfSgpXFxgICh5b3UgbWF5IG5lZWQgdG8gaW1wb3J0IGl0KS5gLCBmaXg6IHsgdHlwZTogXCJ3cmFwLXRhZ1wiLCB3cmFwV2l0aDogaGVscGVyIH0gfV1cbiAgfTtcbiAgcmV0dXJuIFtkaWFnXTtcbn07XG5cbmNvbnN0IHByZWxvYWRNaXNzaW5nQXMgPSAodGFnKSA9PiB7XG4gIGlmICh0YWcudGFnVHlwZSAhPT0gXCJsaW5rXCIpXG4gICAgcmV0dXJuIFtdO1xuICBpZiAodGFnLnByb3BzLnJlbCAhPT0gXCJwcmVsb2FkXCIpXG4gICAgcmV0dXJuIFtdO1xuICBpZiAodGFnLmtleXMuaGFzKFwiYXNcIikpXG4gICAgcmV0dXJuIFtdO1xuICBjb25zdCBkaWFnID0ge1xuICAgIHJ1bGVJZDogXCJwcmVsb2FkLW1pc3NpbmctYXNcIixcbiAgICBtZXNzYWdlOiAnUHJlbG9hZCBsaW5rIGlzIG1pc3NpbmcgdGhlIHJlcXVpcmVkIFwiYXNcIiBhdHRyaWJ1dGUuJ1xuICB9O1xuICByZXR1cm4gW2RpYWddO1xufTtcbmNvbnN0IHByZWxvYWRGb250Q3Jvc3NvcmlnaW4gPSAodGFnKSA9PiB7XG4gIGlmICh0YWcudGFnVHlwZSAhPT0gXCJsaW5rXCIpXG4gICAgcmV0dXJuIFtdO1xuICBpZiAodGFnLnByb3BzLnJlbCAhPT0gXCJwcmVsb2FkXCIpXG4gICAgcmV0dXJuIFtdO1xuICBpZiAodGFnLnByb3BzLmFzICE9PSBcImZvbnRcIilcbiAgICByZXR1cm4gW107XG4gIGlmICh0YWcua2V5cy5oYXMoXCJjcm9zc29yaWdpblwiKSlcbiAgICByZXR1cm4gW107XG4gIGNvbnN0IGRpYWcgPSB7XG4gICAgcnVsZUlkOiBcInByZWxvYWQtZm9udC1jcm9zc29yaWdpblwiLFxuICAgIG1lc3NhZ2U6ICdGb250IHByZWxvYWQgcmVxdWlyZXMgXCJjcm9zc29yaWdpblwiIFxcdTIwMTQgd2l0aG91dCBpdCB0aGUgZm9udCB3aWxsIGJlIGZldGNoZWQgdHdpY2UuJyxcbiAgICBmaXg6IHsgdHlwZTogXCJpbnNlcnQtYWZ0ZXItcHJvcFwiLCBhZnRlcktleTogXCJhc1wiLCBpbnNlcnQ6IGAsIGNyb3Nzb3JpZ2luOiAnYW5vbnltb3VzJ2AgfVxuICB9O1xuICByZXR1cm4gW2RpYWddO1xufTtcblxuY29uc3Qgcm9ib3RzQ29uZmxpY3QgPSAodGFnKSA9PiB7XG4gIGlmICh0YWcudGFnVHlwZSAhPT0gXCJtZXRhXCIpXG4gICAgcmV0dXJuIFtdO1xuICBpZiAodGFnLnByb3BzLm5hbWUgIT09IFwicm9ib3RzXCIpXG4gICAgcmV0dXJuIFtdO1xuICBjb25zdCBjb250ZW50ID0gdGFnLnByb3BzLmNvbnRlbnQ7XG4gIGlmICh0eXBlb2YgY29udGVudCAhPT0gXCJzdHJpbmdcIilcbiAgICByZXR1cm4gW107XG4gIGNvbnN0IGRpcmVjdGl2ZXMgPSBjb250ZW50LnRvTG93ZXJDYXNlKCkuc3BsaXQoXCIsXCIpLm1hcCgoZCkgPT4gZC50cmltKCkpO1xuICBjb25zdCBvdXQgPSBbXTtcbiAgaWYgKGRpcmVjdGl2ZXMuaW5jbHVkZXMoXCJpbmRleFwiKSAmJiBkaXJlY3RpdmVzLmluY2x1ZGVzKFwibm9pbmRleFwiKSkge1xuICAgIG91dC5wdXNoKHtcbiAgICAgIHJ1bGVJZDogXCJyb2JvdHMtY29uZmxpY3RcIixcbiAgICAgIG1lc3NhZ2U6ICdSb2JvdHMgbWV0YSBoYXMgY29uZmxpY3RpbmcgXCJpbmRleFwiIGFuZCBcIm5vaW5kZXhcIiBkaXJlY3RpdmVzLidcbiAgICB9KTtcbiAgfVxuICBpZiAoZGlyZWN0aXZlcy5pbmNsdWRlcyhcImZvbGxvd1wiKSAmJiBkaXJlY3RpdmVzLmluY2x1ZGVzKFwibm9mb2xsb3dcIikpIHtcbiAgICBvdXQucHVzaCh7XG4gICAgICBydWxlSWQ6IFwicm9ib3RzLWNvbmZsaWN0XCIsXG4gICAgICBtZXNzYWdlOiAnUm9ib3RzIG1ldGEgaGFzIGNvbmZsaWN0aW5nIFwiZm9sbG93XCIgYW5kIFwibm9mb2xsb3dcIiBkaXJlY3RpdmVzLidcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gb3V0O1xufTtcblxuY29uc3QgZGVmZXJPbk1vZHVsZVNjcmlwdCA9ICh0YWcpID0+IHtcbiAgaWYgKHRhZy50YWdUeXBlICE9PSBcInNjcmlwdFwiKVxuICAgIHJldHVybiBbXTtcbiAgaWYgKHRhZy5wcm9wcy50eXBlICE9PSBcIm1vZHVsZVwiKVxuICAgIHJldHVybiBbXTtcbiAgaWYgKHRhZy5wcm9wcy5kZWZlciAhPT0gdHJ1ZSlcbiAgICByZXR1cm4gW107XG4gIGNvbnN0IGRpYWcgPSB7XG4gICAgcnVsZUlkOiBcImRlZmVyLW9uLW1vZHVsZS1zY3JpcHRcIixcbiAgICBtZXNzYWdlOiAnXCJkZWZlclwiIGlzIHJlZHVuZGFudCBvbiBtb2R1bGUgc2NyaXB0cy4gTW9kdWxlcyBhcmUgZGVmZXJyZWQgYnkgZGVmYXVsdC4nLFxuICAgIGF0OiB7IGtpbmQ6IFwicHJvcFwiLCBrZXk6IFwiZGVmZXJcIiB9LFxuICAgIGZpeDogeyB0eXBlOiBcInJlbW92ZS1wcm9wXCIsIGtleTogXCJkZWZlclwiIH1cbiAgfTtcbiAgcmV0dXJuIFtkaWFnXTtcbn07XG5jb25zdCBzY3JpcHRTcmNXaXRoQ29udGVudCA9ICh0YWcpID0+IHtcbiAgaWYgKHRhZy50YWdUeXBlICE9PSBcInNjcmlwdFwiKVxuICAgIHJldHVybiBbXTtcbiAgaWYgKHR5cGVvZiB0YWcucHJvcHMuc3JjICE9PSBcInN0cmluZ1wiKVxuICAgIHJldHVybiBbXTtcbiAgY29uc3QgaGFzSW5uZXIgPSB0YWcua2V5cy5oYXMoXCJpbm5lckhUTUxcIikgJiYgdGFnLnByb3BzLmlubmVySFRNTCAhPT0gXCJcIiB8fCB0YWcua2V5cy5oYXMoXCJ0ZXh0Q29udGVudFwiKSAmJiB0YWcucHJvcHMudGV4dENvbnRlbnQgIT09IFwiXCI7XG4gIGlmICghaGFzSW5uZXIpXG4gICAgcmV0dXJuIFtdO1xuICBjb25zdCBkaWFnID0ge1xuICAgIHJ1bGVJZDogXCJzY3JpcHQtc3JjLXdpdGgtY29udGVudFwiLFxuICAgIG1lc3NhZ2U6ICdTY3JpcHQgaGFzIGJvdGggXCJzcmNcIiBhbmQgaW5saW5lIGNvbnRlbnQuIFRoZSBicm93c2VyIHdpbGwgaWdub3JlIHRoZSBpbmxpbmUgY29udGVudC4nXG4gIH07XG4gIHJldHVybiBbZGlhZ107XG59O1xuXG5jb25zdCBOVU1FUklDX1JFID0gL15cXGQrJC87XG5jb25zdCB0d2l0dGVySGFuZGxlTWlzc2luZ0F0ID0gKHRhZykgPT4ge1xuICBpZiAodGFnLnRhZ1R5cGUgIT09IFwibWV0YVwiKVxuICAgIHJldHVybiBbXTtcbiAgY29uc3QgbmFtZSA9IHRhZy5wcm9wcy5uYW1lO1xuICBpZiAobmFtZSAhPT0gXCJ0d2l0dGVyOnNpdGVcIiAmJiBuYW1lICE9PSBcInR3aXR0ZXI6Y3JlYXRvclwiKVxuICAgIHJldHVybiBbXTtcbiAgY29uc3QgY29udGVudCA9IHRhZy5wcm9wcy5jb250ZW50O1xuICBpZiAodHlwZW9mIGNvbnRlbnQgIT09IFwic3RyaW5nXCIpXG4gICAgcmV0dXJuIFtdO1xuICBpZiAoY29udGVudC5zdGFydHNXaXRoKFwiQFwiKSB8fCBOVU1FUklDX1JFLnRlc3QoY29udGVudCkpXG4gICAgcmV0dXJuIFtdO1xuICBjb25zdCBmaXhlZFNvdXJjZSA9IEpTT04uc3RyaW5naWZ5KGBAJHtjb250ZW50fWApO1xuICBjb25zdCBkaWFnID0ge1xuICAgIHJ1bGVJZDogXCJ0d2l0dGVyLWhhbmRsZS1taXNzaW5nLWF0XCIsXG4gICAgbWVzc2FnZTogYCR7bmFtZX0gc2hvdWxkIHN0YXJ0IHdpdGggXCJAXCIsIHJlY2VpdmVkIFwiJHtjb250ZW50fVwiLmAsXG4gICAgYXQ6IHsga2luZDogXCJwcm9wLXZhbHVlXCIsIGtleTogXCJjb250ZW50XCIgfSxcbiAgICBmaXg6IHsgdHlwZTogXCJyZXBsYWNlLXByb3AtdmFsdWVcIiwga2V5OiBcImNvbnRlbnRcIiwgbmV3U291cmNlOiBmaXhlZFNvdXJjZSB9XG4gIH07XG4gIHJldHVybiBbZGlhZ107XG59O1xuXG5jb25zdCBVU0VSX1NDQUxBQkxFX05PX1JFID0gL3VzZXItc2NhbGFibGVcXHMqPVxccyooPzpub3wwfGZhbHNlKSg/OltcXHMsO118JCkvaTtcbmNvbnN0IE1BWF9TQ0FMRV9SRSA9IC9tYXhpbXVtLXNjYWxlXFxzKj1cXHMqMSg/OlxcLlxcZCspPyg/OltcXHMsO118JCkvaTtcbmNvbnN0IHZpZXdwb3J0VXNlclNjYWxhYmxlID0gKHRhZykgPT4ge1xuICBpZiAodGFnLnRhZ1R5cGUgIT09IFwibWV0YVwiKVxuICAgIHJldHVybiBbXTtcbiAgaWYgKHRhZy5wcm9wcy5uYW1lICE9PSBcInZpZXdwb3J0XCIpXG4gICAgcmV0dXJuIFtdO1xuICBjb25zdCBjb250ZW50ID0gdGFnLnByb3BzLmNvbnRlbnQ7XG4gIGlmICh0eXBlb2YgY29udGVudCAhPT0gXCJzdHJpbmdcIilcbiAgICByZXR1cm4gW107XG4gIGNvbnN0IG91dCA9IFtdO1xuICBpZiAoVVNFUl9TQ0FMQUJMRV9OT19SRS50ZXN0KGNvbnRlbnQpKSB7XG4gICAgb3V0LnB1c2goe1xuICAgICAgcnVsZUlkOiBcInZpZXdwb3J0LXVzZXItc2NhbGFibGVcIixcbiAgICAgIG1lc3NhZ2U6ICd2aWV3cG9ydCBcInVzZXItc2NhbGFibGU9bm9cIiBwcmV2ZW50cyB6b29taW5nIGFuZCBoYXJtcyBhY2Nlc3NpYmlsaXR5LidcbiAgICB9KTtcbiAgfVxuICBpZiAoTUFYX1NDQUxFX1JFLnRlc3QoY29udGVudCkpIHtcbiAgICBvdXQucHVzaCh7XG4gICAgICBydWxlSWQ6IFwidmlld3BvcnQtdXNlci1zY2FsYWJsZVwiLFxuICAgICAgbWVzc2FnZTogJ3ZpZXdwb3J0IFwibWF4aW11bS1zY2FsZT0xXCIgbGltaXRzIHpvb21pbmcgYW5kIG1heSBoYXJtIGFjY2Vzc2liaWxpdHkuJ1xuICAgIH0pO1xuICB9XG4gIHJldHVybiBvdXQ7XG59O1xuXG5jb25zdCBUQUdfVFlQRVMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldChbXCJtZXRhXCIsIFwibGlua1wiLCBcInNjcmlwdFwiLCBcIm5vc2NyaXB0XCIsIFwic3R5bGVcIl0pO1xuZnVuY3Rpb24gdmFsdWVLaW5kKHZhbHVlKSB7XG4gIGlmICh2YWx1ZSA9PT0gbnVsbClcbiAgICByZXR1cm4gXCJudWxsXCI7XG4gIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSlcbiAgICByZXR1cm4gXCJhcnJheVwiO1xuICBjb25zdCBraW5kID0gdHlwZW9mIHZhbHVlO1xuICBpZiAoa2luZCA9PT0gXCJib29sZWFuXCIgfHwga2luZCA9PT0gXCJmdW5jdGlvblwiIHx8IGtpbmQgPT09IFwibnVtYmVyXCIgfHwga2luZCA9PT0gXCJvYmplY3RcIiB8fCBraW5kID09PSBcInN0cmluZ1wiKVxuICAgIHJldHVybiBraW5kO1xuICByZXR1cm4gXCJ1bmtub3duXCI7XG59XG5mdW5jdGlvbiBpbnB1dFNoYXBlRnJvbVJ1bnRpbWUoY29udGV4dCwgaW5wdXQpIHtcbiAgY29uc3Qga2V5cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gIGNvbnN0IHZhbHVlS2luZHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBPYmplY3QuZW50cmllcyhpbnB1dCkpIHtcbiAgICBrZXlzLmFkZChrZXkpO1xuICAgIHZhbHVlS2luZHMuc2V0KGtleSwgdmFsdWVLaW5kKHZhbHVlKSk7XG4gIH1cbiAgcmV0dXJuIHsgY29udGV4dCwga2V5cywgdmFsdWVLaW5kcyB9O1xufVxuZnVuY3Rpb24gdGFnSW5wdXRGcm9tUnVudGltZSh0YWcpIHtcbiAgaWYgKCFUQUdfVFlQRVMuaGFzKHRhZy50YWcpKVxuICAgIHJldHVybiB2b2lkIDA7XG4gIGNvbnN0IHByb3BzID0ge307XG4gIGNvbnN0IGtleXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBPYmplY3QuZW50cmllcyh0YWcucHJvcHMpKSB7XG4gICAga2V5cy5hZGQoayk7XG4gICAgaWYgKHYgPT0gbnVsbCkge1xuICAgICAgaWYgKHRhZy50YWcgPT09IFwibWV0YVwiICYmIGsgPT09IFwiY29udGVudFwiKVxuICAgICAgICBwcm9wc1trXSA9IFwiXCI7XG4gICAgICBjb250aW51ZTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiB2ID09PSBcInN0cmluZ1wiIHx8IHR5cGVvZiB2ID09PSBcIm51bWJlclwiIHx8IHR5cGVvZiB2ID09PSBcImJvb2xlYW5cIikge1xuICAgICAgaWYgKHRhZy50YWcgPT09IFwibWV0YVwiICYmIGsgPT09IFwibmFtZVwiICYmIHR5cGVvZiB2ID09PSBcInN0cmluZ1wiKVxuICAgICAgICBwcm9wc1trXSA9IHYudG9Mb3dlckNhc2UoKTtcbiAgICAgIGVsc2VcbiAgICAgICAgcHJvcHNba10gPSB2O1xuICAgIH0gZWxzZSB7XG4gICAgICBwcm9wc1trXSA9IFN0cmluZyh2KTtcbiAgICB9XG4gIH1cbiAgaWYgKHRhZy50YWcgPT09IFwic2NyaXB0XCIgfHwgdGFnLnRhZyA9PT0gXCJzdHlsZVwiIHx8IHRhZy50YWcgPT09IFwibm9zY3JpcHRcIikge1xuICAgIGlmICh0YWcuaW5uZXJIVE1MICE9IG51bGwgJiYgdGFnLmlubmVySFRNTCAhPT0gXCJcIikge1xuICAgICAga2V5cy5hZGQoXCJpbm5lckhUTUxcIik7XG4gICAgfVxuICAgIGlmICh0YWcudGV4dENvbnRlbnQgIT0gbnVsbCAmJiB0YWcudGV4dENvbnRlbnQgIT09IFwiXCIpIHtcbiAgICAgIGtleXMuYWRkKFwidGV4dENvbnRlbnRcIik7XG4gICAgfVxuICB9XG4gIGlmICh0YWcudGFnUHJpb3JpdHkgIT0gbnVsbCkge1xuICAgIGtleXMuYWRkKFwidGFnUHJpb3JpdHlcIik7XG4gICAgaWYgKHR5cGVvZiB0YWcudGFnUHJpb3JpdHkgPT09IFwic3RyaW5nXCIgfHwgdHlwZW9mIHRhZy50YWdQcmlvcml0eSA9PT0gXCJudW1iZXJcIilcbiAgICAgIHByb3BzLnRhZ1ByaW9yaXR5ID0gdGFnLnRhZ1ByaW9yaXR5O1xuICB9XG4gIHJldHVybiB7XG4gICAgdGFnVHlwZTogdGFnLnRhZyxcbiAgICBwcm9wcyxcbiAgICBrZXlzXG4gIH07XG59XG5mdW5jdGlvbiB0aXRsZUlucHV0RnJvbVJ1bnRpbWUodGl0bGVUYWcpIHtcbiAgaWYgKHRpdGxlVGFnLnRhZyAhPT0gXCJ0aXRsZVwiKVxuICAgIHJldHVybiB2b2lkIDA7XG4gIGNvbnN0IHRleHQgPSB0aXRsZVRhZy50ZXh0Q29udGVudCA/PyB0aXRsZVRhZy5pbm5lckhUTUwgPz8gXCJcIjtcbiAgcmV0dXJuIHtcbiAgICBjYWxsZWU6IFwicnVudGltZVwiLFxuICAgIHByb3BzOiB7IHRpdGxlOiB0ZXh0IH0sXG4gICAga2V5czogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoW1widGl0bGVcIl0pXG4gIH07XG59XG5cbmNvbnN0IHRhZ1ByZWRpY2F0ZXMgPSB7XG4gIFwiZGVmZXItb24tbW9kdWxlLXNjcmlwdFwiOiBkZWZlck9uTW9kdWxlU2NyaXB0LFxuICBcImVtcHR5LW1ldGEtY29udGVudFwiOiBlbXB0eU1ldGFDb250ZW50LFxuICBcIm5vLWRlcHJlY2F0ZWQtcHJvcHNcIjogbm9EZXByZWNhdGVkUHJvcHMsXG4gIFwibm8tdW5rbm93bi1tZXRhXCI6IG5vVW5rbm93bk1ldGEsXG4gIFwibm9uLWFic29sdXRlLWNhbm9uaWNhbFwiOiBub25BYnNvbHV0ZUNhbm9uaWNhbCxcbiAgXCJudW1lcmljLXRhZy1wcmlvcml0eVwiOiBudW1lcmljVGFnUHJpb3JpdHksXG4gIFwicHJlbG9hZC1mb250LWNyb3Nzb3JpZ2luXCI6IHByZWxvYWRGb250Q3Jvc3NvcmlnaW4sXG4gIFwicHJlbG9hZC1taXNzaW5nLWFzXCI6IHByZWxvYWRNaXNzaW5nQXMsXG4gIFwicm9ib3RzLWNvbmZsaWN0XCI6IHJvYm90c0NvbmZsaWN0LFxuICBcInNjcmlwdC1zcmMtd2l0aC1jb250ZW50XCI6IHNjcmlwdFNyY1dpdGhDb250ZW50LFxuICBcInR3aXR0ZXItaGFuZGxlLW1pc3NpbmctYXRcIjogdHdpdHRlckhhbmRsZU1pc3NpbmdBdCxcbiAgXCJ2aWV3cG9ydC11c2VyLXNjYWxhYmxlXCI6IHZpZXdwb3J0VXNlclNjYWxhYmxlXG59O1xuY29uc3QgaW5wdXRTaGFwZVByZWRpY2F0ZXMgPSB7XG4gIFwiaW52YWxpZC1pbnB1dC1zaGFwZVwiOiB2YWxpZGF0ZUlucHV0U2hhcGVcbn07XG5jb25zdCBtaWdyYXRpb25UYWdQcmVkaWNhdGVzID0ge1xuICBcInByZWZlci1kZWZpbmUtaGVscGVyc1wiOiBwcmVmZXJEZWZpbmVIZWxwZXJzXG59O1xuY29uc3QgaGVhZElucHV0UHJlZGljYXRlcyA9IHtcbiAgXCJuby1odG1sLWluLXRpdGxlXCI6IG5vSHRtbEluVGl0bGVcbn07XG5cbmV4cG9ydCB7IERFUFJFQ0FURURfUFJPUFMgYXMgRCwgSU5QVVRfU0hBUEVfRklFTERTIGFzIEksIEtOT1dOX01FVEFfTkFNRVMgYXMgSywgVEFHX1BSSU9SSVRZX0FMSUFTRVMgYXMgVCwgVVJMX01FVEFfS0VZUyBhcyBVLCBLTk9XTl9NRVRBX1BST1BFUlRJRVMgYXMgYSwgaW5wdXRTaGFwZVByZWRpY2F0ZXMgYXMgYiwgbm9IdG1sSW5UaXRsZSBhcyBjLCBkZWZlck9uTW9kdWxlU2NyaXB0IGFzIGQsIGVtcHR5TWV0YUNvbnRlbnQgYXMgZSwgZmluZENsb3Nlc3RNYXRjaCBhcyBmLCBub1Vua25vd25NZXRhIGFzIGcsIGhlYWRJbnB1dFByZWRpY2F0ZXMgYXMgaCwgaW5wdXRTaGFwZUZyb21SdW50aW1lIGFzIGksIG5vbkFic29sdXRlQ2Fub25pY2FsIGFzIGosIG51bWVyaWNUYWdQcmlvcml0eSBhcyBrLCBsZXZlbnNodGVpbiBhcyBsLCBtaWdyYXRpb25UYWdQcmVkaWNhdGVzIGFzIG0sIG5vRGVwcmVjYXRlZFByb3BzIGFzIG4sIHByZWxvYWRGb250Q3Jvc3NvcmlnaW4gYXMgbywgcHJlZmVyRGVmaW5lSGVscGVycyBhcyBwLCBwcmVsb2FkTWlzc2luZ0FzIGFzIHEsIHJvYm90c0NvbmZsaWN0IGFzIHIsIHNjcmlwdFNyY1dpdGhDb250ZW50IGFzIHMsIHRhZ0lucHV0RnJvbVJ1bnRpbWUgYXMgdCwgdGFnUHJlZGljYXRlcyBhcyB1LCB0aXRsZUlucHV0RnJvbVJ1bnRpbWUgYXMgdiwgdHdpdHRlckhhbmRsZU1pc3NpbmdBdCBhcyB3LCB2YWxpZGF0ZUlucHV0U2hhcGUgYXMgeCwgdmlld3BvcnRVc2VyU2NhbGFibGUgYXMgeSB9O1xuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDOUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVztBQUN0QixDQUFDLENBQUM7QUFDRixLQUFLLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDdEQsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRO0FBQ25CLENBQUMsQ0FBQztBQUNGLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUNqRCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDO0FBQzdCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUs7QUFDaEIsQ0FBQyxDQUFDO0FBQ0YsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN4RCxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQzVFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNqRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDbEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsRixDQUFDOztBQUVELFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ3BCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNwQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEQsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2I7QUFDQSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJO0FBQ1YsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUztBQUN6RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDYjs7QUFFQSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzVJLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2YsQ0FBQzs7QUFFRCxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNuRSxLQUFLLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNwRSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3RGLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM1RSxLQUFLLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNuRyxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsaUJBQWlCLENBQUM7QUFDeEMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGlCQUFpQixDQUFDO0FBQ3hDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsb0JBQW9CO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsaUJBQWlCLENBQUM7QUFDeEMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLG1CQUFtQixDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsbUJBQW1CLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLG1CQUFtQixDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsb0JBQW9CO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLG1CQUFtQjtBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLGdCQUFnQjtBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxnQkFBZ0I7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsZ0JBQWdCO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ3RELENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0QsUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDdkM7QUFDQSxRQUFRLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekI7QUFDQSxRQUFRLENBQUMscUJBQXFCLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDeEQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUNoRCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3pGLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDdkgsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNsSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxRQUFRLENBQUMscUJBQXFCLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUN2RyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsUUFBUSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNyRixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDdkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUN2RCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzNGLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUN6RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUN6RSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxtQkFBbUI7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVztBQUNwQjs7QUFFQSxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsZ0JBQWdCLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUM7QUFDakQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNwRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDM0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDcEYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztBQUMxRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNwRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUc7QUFDWixDQUFDOztBQUVELEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsS0FBSztBQUNqQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUM3RCxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlGLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMzQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDOztBQUVELEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUN2RCxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxRQUFRO0FBQ3JDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDM0csQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQztBQUN4RSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6RixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSTtBQUM3QixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDLGdCQUFnQixDQUFDO0FBQ2xFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9FLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2RixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHO0FBQ1osQ0FBQzs7QUFFRCxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hFO0FBQ0EsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSTtBQUM3QixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUM7O0FBRUQsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDM0MsS0FBSyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVc7QUFDckMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDbEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2YsQ0FBQzs7QUFFRCxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUM7QUFDcEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsWUFBWTtBQUN2QixDQUFDO0FBQ0QsS0FBSyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQztBQUMzQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7QUFDckQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDakUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMvRixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RKLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUM7O0FBRUQsS0FBSyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNsRSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDO0FBQ0QsS0FBSyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNwRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQzNGLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUM7O0FBRUQsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU87QUFDbkMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUMxRSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RFLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUM3RSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hFLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUMvRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRztBQUNaLENBQUM7O0FBRUQsS0FBSyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDdkYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2YsQ0FBQztBQUNELEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pJLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQ25HLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUM7O0FBRUQsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQixLQUFLLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJO0FBQzdCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7QUFDM0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTztBQUNuQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztBQUN6RCxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLENBQUM7QUFDOUUsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2YsQ0FBQzs7QUFFRCxLQUFLLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0UsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkUsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsT0FBTztBQUNuQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7QUFDdEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUM7QUFDckYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7QUFDdEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDO0FBQ3JGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHO0FBQ1osQ0FBQzs7QUFFRCxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUMxRixRQUFRLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNsQixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDM0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDOUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUNmLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDbEI7QUFDQSxRQUFRLENBQUMscUJBQXFCLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN0QztBQUNBLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNsRCxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ2xGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ3JFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUM3RSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDbEYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVc7QUFDekMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUc7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxRQUFRLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvRCxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDO0FBQ0g7O0FBRUEsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxtQkFBbUI7QUFDL0MsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGdCQUFnQjtBQUN4QyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsaUJBQWlCO0FBQzFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxhQUFhO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxvQkFBb0I7QUFDaEQsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLGtCQUFrQjtBQUM1QyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsc0JBQXNCO0FBQ3BELENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0I7QUFDeEMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsY0FBYztBQUNuQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLG9CQUFvQjtBQUNqRCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLHNCQUFzQjtBQUNyRCxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQztBQUNELEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUM7QUFDRCxLQUFLLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUMzQixDQUFDO0FBQ0QsS0FBSyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUM7O0FBRUQsTUFBTSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMscUJBQXFCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzsifQ==