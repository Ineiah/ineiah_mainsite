/**
* @vue/reactivity v3.5.40
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
import { extend, hasChanged, isArray, isIntegerKey, isSymbol, isMap, hasOwn, isObject, makeMap, capitalize, toRawType, def, isFunction, EMPTY_OBJ, isSet, isPlainObject, remove, NOOP } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vue+shared@3.5.40/node_modules/@vue/shared/dist/shared.esm-bundler.js?v=7e73afc2";
function warn(msg, ...args) {
	console.warn(`[Vue warn] ${msg}`, ...args);
}
let activeEffectScope;
class EffectScope {
	// TODO isolatedDeclarations "__v_skip"
	constructor(detached = false) {
		this.detached = detached;
		/**
		* @internal
		*/
		this._active = true;
		/**
		* @internal track `on` calls, allow `on` call multiple times
		*/
		this._on = 0;
		/**
		* @internal
		*/
		this.effects = [];
		/**
		* @internal
		*/
		this.cleanups = [];
		this._isPaused = false;
		this._warnOnRun = true;
		this.__v_skip = true;
		if (!detached && activeEffectScope) {
			if (activeEffectScope.active) {
				this.parent = activeEffectScope;
				this.index = (activeEffectScope.scopes || (activeEffectScope.scopes = [])).push(this) - 1;
			} else {
				this._active = false;
				this._warnOnRun = false;
			}
		}
	}
	get active() {
		return this._active;
	}
	pause() {
		if (this._active) {
			this._isPaused = true;
			let i, l;
			if (this.scopes) {
				const scopes = this.scopes.slice();
				for (i = 0, l = scopes.length; i < l; i++) {
					scopes[i].pause();
				}
			}
			for (i = 0, l = this.effects.length; i < l; i++) {
				this.effects[i].pause();
			}
		}
	}
	/**
	* Resumes the effect scope, including all child scopes and effects.
	*/
	resume() {
		if (this._active) {
			if (this._isPaused) {
				this._isPaused = false;
				let i, l;
				if (this.scopes) {
					const scopes = this.scopes.slice();
					for (i = 0, l = scopes.length; i < l; i++) {
						scopes[i].resume();
					}
				}
				const effects = this.effects.slice();
				for (i = 0, l = effects.length; i < l; i++) {
					effects[i].resume();
				}
			}
		}
	}
	run(fn) {
		if (this._active) {
			const currentEffectScope = activeEffectScope;
			try {
				activeEffectScope = this;
				return fn();
			} finally {
				activeEffectScope = currentEffectScope;
			}
		} else if (!!("development" !== "production") && this._warnOnRun) {
			warn(`cannot run an inactive effect scope.`);
		}
	}
	/**
	* This should only be called on non-detached scopes
	* @internal
	*/
	on() {
		if (++this._on === 1) {
			this.prevScope = activeEffectScope;
			activeEffectScope = this;
		}
	}
	/**
	* This should only be called on non-detached scopes
	* @internal
	*/
	off() {
		if (this._on > 0 && --this._on === 0) {
			if (activeEffectScope === this) {
				activeEffectScope = this.prevScope;
			} else {
				let current = activeEffectScope;
				while (current) {
					if (current.prevScope === this) {
						current.prevScope = this.prevScope;
						break;
					}
					current = current.prevScope;
				}
			}
			this.prevScope = void 0;
		}
	}
	stop(fromParent) {
		if (this._active) {
			this._active = false;
			let i, l;
			for (i = 0, l = this.effects.length; i < l; i++) {
				this.effects[i].stop();
			}
			this.effects.length = 0;
			for (i = 0, l = this.cleanups.length; i < l; i++) {
				this.cleanups[i]();
			}
			this.cleanups.length = 0;
			if (this.scopes) {
				const scopes = this.scopes.slice();
				for (i = 0, l = scopes.length; i < l; i++) {
					scopes[i].stop(true);
				}
				this.scopes.length = 0;
			}
			if (!this.detached && this.parent && !fromParent) {
				const last = this.parent.scopes.pop();
				if (last && last !== this) {
					this.parent.scopes[this.index] = last;
					last.index = this.index;
				}
			}
			this.parent = void 0;
		}
	}
}
function effectScope(detached) {
	return new EffectScope(detached);
}
function getCurrentScope() {
	return activeEffectScope;
}
function onScopeDispose(fn, failSilently = false) {
	if (activeEffectScope) {
		activeEffectScope.cleanups.push(fn);
	} else if (!!("development" !== "production") && !failSilently) {
		warn(`onScopeDispose() is called when there is no active effect scope to be associated with.`);
	}
}
let activeSub;
const EffectFlags = {
	"ACTIVE": 1,
	"1": "ACTIVE",
	"RUNNING": 2,
	"2": "RUNNING",
	"TRACKING": 4,
	"4": "TRACKING",
	"NOTIFIED": 8,
	"8": "NOTIFIED",
	"DIRTY": 16,
	"16": "DIRTY",
	"ALLOW_RECURSE": 32,
	"32": "ALLOW_RECURSE",
	"PAUSED": 64,
	"64": "PAUSED",
	"EVALUATED": 128,
	"128": "EVALUATED"
};
const pausedQueueEffects = /* @__PURE__ */ new WeakSet();
class ReactiveEffect {
	constructor(fn) {
		this.fn = fn;
		/**
		* @internal
		*/
		this.deps = void 0;
		/**
		* @internal
		*/
		this.depsTail = void 0;
		/**
		* @internal
		*/
		this.flags = 1 | 4;
		/**
		* @internal
		*/
		this.next = void 0;
		/**
		* @internal
		*/
		this.cleanup = void 0;
		this.scheduler = void 0;
		if (activeEffectScope) {
			if (activeEffectScope.active) {
				activeEffectScope.effects.push(this);
			} else {
				this.flags &= -2;
			}
		}
	}
	pause() {
		this.flags |= 64;
	}
	resume() {
		if (this.flags & 64) {
			this.flags &= -65;
			if (pausedQueueEffects.has(this)) {
				pausedQueueEffects.delete(this);
				this.trigger();
			}
		}
	}
	/**
	* @internal
	*/
	notify() {
		if (this.flags & 2 && !(this.flags & 32)) {
			return;
		}
		if (!(this.flags & 8)) {
			batch(this);
		}
	}
	run() {
		if (!(this.flags & 1)) {
			return this.fn();
		}
		this.flags |= 2;
		cleanupEffect(this);
		prepareDeps(this);
		const prevEffect = activeSub;
		const prevShouldTrack = shouldTrack;
		activeSub = this;
		shouldTrack = true;
		try {
			return this.fn();
		} finally {
			if (!!("development" !== "production") && activeSub !== this) {
				warn("Active effect was not restored correctly - this is likely a Vue internal bug.");
			}
			cleanupDeps(this);
			activeSub = prevEffect;
			shouldTrack = prevShouldTrack;
			this.flags &= -3;
		}
	}
	stop() {
		if (this.flags & 1) {
			for (let link = this.deps; link; link = link.nextDep) {
				removeSub(link);
			}
			this.deps = this.depsTail = void 0;
			cleanupEffect(this);
			this.onStop && this.onStop();
			this.flags &= -2;
		}
	}
	trigger() {
		if (this.flags & 64) {
			pausedQueueEffects.add(this);
		} else if (this.scheduler) {
			this.scheduler();
		} else {
			this.runIfDirty();
		}
	}
	/**
	* @internal
	*/
	runIfDirty() {
		if (isDirty(this)) {
			this.run();
		}
	}
	get dirty() {
		return isDirty(this);
	}
}
let batchDepth = 0;
let batchedSub;
let batchedComputed;
function batch(sub, isComputed = false) {
	sub.flags |= 8;
	if (isComputed) {
		sub.next = batchedComputed;
		batchedComputed = sub;
		return;
	}
	sub.next = batchedSub;
	batchedSub = sub;
}
function startBatch() {
	batchDepth++;
}
function endBatch() {
	if (--batchDepth > 0) {
		return;
	}
	if (batchedComputed) {
		let e = batchedComputed;
		batchedComputed = void 0;
		while (e) {
			const next = e.next;
			e.next = void 0;
			e.flags &= -9;
			e = next;
		}
	}
	let error;
	while (batchedSub) {
		let e = batchedSub;
		batchedSub = void 0;
		while (e) {
			const next = e.next;
			e.next = void 0;
			e.flags &= -9;
			if (e.flags & 1) {
				try {
					;
					e.trigger();
				} catch (err) {
					if (!error) error = err;
				}
			}
			e = next;
		}
	}
	if (error) throw error;
}
function prepareDeps(sub) {
	for (let link = sub.deps; link; link = link.nextDep) {
		link.version = -1;
		link.prevActiveLink = link.dep.activeLink;
		link.dep.activeLink = link;
	}
}
function cleanupDeps(sub) {
	let head;
	let tail = sub.depsTail;
	let link = tail;
	while (link) {
		const prev = link.prevDep;
		if (link.version === -1) {
			if (link === tail) tail = prev;
			removeSub(link);
			removeDep(link);
		} else {
			head = link;
		}
		link.dep.activeLink = link.prevActiveLink;
		link.prevActiveLink = void 0;
		link = prev;
	}
	sub.deps = head;
	sub.depsTail = tail;
}
function isDirty(sub) {
	for (let link = sub.deps; link; link = link.nextDep) {
		if (link.dep.version !== link.version || link.dep.computed && (refreshComputed(link.dep.computed) || link.dep.version !== link.version)) {
			return true;
		}
	}
	if (sub._dirty) {
		return true;
	}
	return false;
}
function refreshComputed(computed) {
	if (computed.flags & 4 && !(computed.flags & 16)) {
		return;
	}
	computed.flags &= -17;
	if (computed.globalVersion === globalVersion) {
		return;
	}
	computed.globalVersion = globalVersion;
	if (!computed.isSSR && computed.flags & 128 && (!computed.deps && !computed._dirty || !isDirty(computed))) {
		return;
	}
	computed.flags |= 2;
	const dep = computed.dep;
	const prevSub = activeSub;
	const prevShouldTrack = shouldTrack;
	activeSub = computed;
	shouldTrack = true;
	try {
		prepareDeps(computed);
		const value = computed.fn(computed._value);
		if (dep.version === 0 || hasChanged(value, computed._value)) {
			computed.flags |= 128;
			computed._value = value;
			dep.version++;
		}
	} catch (err) {
		dep.version++;
		throw err;
	} finally {
		activeSub = prevSub;
		shouldTrack = prevShouldTrack;
		cleanupDeps(computed);
		computed.flags &= -3;
	}
}
function removeSub(link, soft = false) {
	const { dep, prevSub, nextSub } = link;
	if (prevSub) {
		prevSub.nextSub = nextSub;
		link.prevSub = void 0;
	}
	if (nextSub) {
		nextSub.prevSub = prevSub;
		link.nextSub = void 0;
	}
	if (!!("development" !== "production") && dep.subsHead === link) {
		dep.subsHead = nextSub;
	}
	if (dep.subs === link) {
		dep.subs = prevSub;
		if (!prevSub && dep.computed) {
			dep.computed.flags &= -5;
			for (let l = dep.computed.deps; l; l = l.nextDep) {
				removeSub(l, true);
			}
		}
	}
	if (!soft && !--dep.sc && dep.map) {
		dep.map.delete(dep.key);
	}
}
function removeDep(link) {
	const { prevDep, nextDep } = link;
	if (prevDep) {
		prevDep.nextDep = nextDep;
		link.prevDep = void 0;
	}
	if (nextDep) {
		nextDep.prevDep = prevDep;
		link.nextDep = void 0;
	}
}
function effect(fn, options) {
	if (fn.effect instanceof ReactiveEffect) {
		fn = fn.effect.fn;
	}
	const e = new ReactiveEffect(fn);
	if (options) {
		extend(e, options);
	}
	try {
		e.run();
	} catch (err) {
		e.stop();
		throw err;
	}
	const runner = e.run.bind(e);
	runner.effect = e;
	return runner;
}
function stop(runner) {
	runner.effect.stop();
}
let shouldTrack = true;
const trackStack = [];
function pauseTracking() {
	trackStack.push(shouldTrack);
	shouldTrack = false;
}
function enableTracking() {
	trackStack.push(shouldTrack);
	shouldTrack = true;
}
function resetTracking() {
	const last = trackStack.pop();
	shouldTrack = last === void 0 ? true : last;
}
function onEffectCleanup(fn, failSilently = false) {
	if (activeSub instanceof ReactiveEffect) {
		activeSub.cleanup = fn;
	} else if (!!("development" !== "production") && !failSilently) {
		warn(`onEffectCleanup() was called when there was no active effect to associate with.`);
	}
}
function cleanupEffect(e) {
	const { cleanup } = e;
	e.cleanup = void 0;
	if (cleanup) {
		const prevSub = activeSub;
		activeSub = void 0;
		try {
			cleanup();
		} finally {
			activeSub = prevSub;
		}
	}
}
let globalVersion = 0;
class Link {
	constructor(sub, dep) {
		this.sub = sub;
		this.dep = dep;
		this.version = dep.version;
		this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
	}
}
class Dep {
	// TODO isolatedDeclarations "__v_skip"
	constructor(computed) {
		this.computed = computed;
		this.version = 0;
		/**
		* Link between this dep and the current active effect
		*/
		this.activeLink = void 0;
		/**
		* Doubly linked list representing the subscribing effects (tail)
		*/
		this.subs = void 0;
		/**
		* For object property deps cleanup
		*/
		this.map = void 0;
		this.key = void 0;
		/**
		* Subscriber counter
		*/
		this.sc = 0;
		/**
		* @internal
		*/
		this.__v_skip = true;
		if (!!("development" !== "production")) {
			this.subsHead = void 0;
		}
	}
	track(debugInfo) {
		if (!activeSub || !shouldTrack || activeSub === this.computed) {
			return;
		}
		let link = this.activeLink;
		if (link === void 0 || link.sub !== activeSub) {
			link = this.activeLink = new Link(activeSub, this);
			if (!activeSub.deps) {
				activeSub.deps = activeSub.depsTail = link;
			} else {
				link.prevDep = activeSub.depsTail;
				activeSub.depsTail.nextDep = link;
				activeSub.depsTail = link;
			}
			addSub(link);
		} else if (link.version === -1) {
			link.version = this.version;
			if (link.nextDep) {
				const next = link.nextDep;
				next.prevDep = link.prevDep;
				if (link.prevDep) {
					link.prevDep.nextDep = next;
				}
				link.prevDep = activeSub.depsTail;
				link.nextDep = void 0;
				activeSub.depsTail.nextDep = link;
				activeSub.depsTail = link;
				if (activeSub.deps === link) {
					activeSub.deps = next;
				}
			}
		}
		if (!!("development" !== "production") && activeSub.onTrack) {
			activeSub.onTrack(extend({ effect: activeSub }, debugInfo));
		}
		return link;
	}
	trigger(debugInfo) {
		this.version++;
		globalVersion++;
		this.notify(debugInfo);
	}
	notify(debugInfo) {
		startBatch();
		try {
			if (!!("development" !== "production")) {
				for (let head = this.subsHead; head; head = head.nextSub) {
					if (head.sub.onTrigger && !(head.sub.flags & 8)) {
						head.sub.onTrigger(extend({ effect: head.sub }, debugInfo));
					}
				}
			}
			for (let link = this.subs; link; link = link.prevSub) {
				if (link.sub.notify()) {
					;
					link.sub.dep.notify();
				}
			}
		} finally {
			endBatch();
		}
	}
}
function addSub(link) {
	link.dep.sc++;
	if (link.sub.flags & 4) {
		const computed = link.dep.computed;
		if (computed && !link.dep.subs) {
			computed.flags |= 4 | 16;
			for (let l = computed.deps; l; l = l.nextDep) {
				addSub(l);
			}
		}
		const currentTail = link.dep.subs;
		if (currentTail !== link) {
			link.prevSub = currentTail;
			if (currentTail) currentTail.nextSub = link;
		}
		if (!!("development" !== "production") && link.dep.subsHead === void 0) {
			link.dep.subsHead = link;
		}
		link.dep.subs = link;
	}
}
const targetMap = /* @__PURE__ */ new WeakMap();
const ITERATE_KEY = /* @__PURE__ */ Symbol(!!("development" !== "production") ? "Object iterate" : "");
const MAP_KEY_ITERATE_KEY = /* @__PURE__ */ Symbol(!!("development" !== "production") ? "Map keys iterate" : "");
const ARRAY_ITERATE_KEY = /* @__PURE__ */ Symbol(!!("development" !== "production") ? "Array iterate" : "");
function track(target, type, key) {
	if (shouldTrack && activeSub) {
		let depsMap = targetMap.get(target);
		if (!depsMap) {
			targetMap.set(target, depsMap = /* @__PURE__ */ new Map());
		}
		let dep = depsMap.get(key);
		if (!dep) {
			depsMap.set(key, dep = new Dep());
			dep.map = depsMap;
			dep.key = key;
		}
		if (!!("development" !== "production")) {
			dep.track({
				target,
				type,
				key
			});
		} else {
			dep.track();
		}
	}
}
function trigger(target, type, key, newValue, oldValue, oldTarget) {
	const depsMap = targetMap.get(target);
	if (!depsMap) {
		globalVersion++;
		return;
	}
	const run = (dep) => {
		if (dep) {
			if (!!("development" !== "production")) {
				dep.trigger({
					target,
					type,
					key,
					newValue,
					oldValue,
					oldTarget
				});
			} else {
				dep.trigger();
			}
		}
	};
	startBatch();
	if (type === "clear") {
		depsMap.forEach(run);
	} else {
		const targetIsArray = isArray(target);
		const isArrayIndex = targetIsArray && isIntegerKey(key);
		if (targetIsArray && key === "length") {
			const newLength = Number(newValue);
			depsMap.forEach((dep, key2) => {
				if (key2 === "length" || key2 === ARRAY_ITERATE_KEY || !isSymbol(key2) && key2 >= newLength) {
					run(dep);
				}
			});
		} else {
			if (key !== void 0 || depsMap.has(void 0)) {
				run(depsMap.get(key));
			}
			if (isArrayIndex) {
				run(depsMap.get(ARRAY_ITERATE_KEY));
			}
			switch (type) {
				case "add":
					if (!targetIsArray) {
						run(depsMap.get(ITERATE_KEY));
						if (isMap(target)) {
							run(depsMap.get(MAP_KEY_ITERATE_KEY));
						}
					} else if (isArrayIndex) {
						run(depsMap.get("length"));
					}
					break;
				case "delete":
					if (!targetIsArray) {
						run(depsMap.get(ITERATE_KEY));
						if (isMap(target)) {
							run(depsMap.get(MAP_KEY_ITERATE_KEY));
						}
					}
					break;
				case "set":
					if (isMap(target)) {
						run(depsMap.get(ITERATE_KEY));
					}
					break;
			}
		}
	}
	endBatch();
}
function getDepFromReactive(object, key) {
	const depMap = targetMap.get(object);
	return depMap && depMap.get(key);
}
function reactiveReadArray(array) {
	const raw = toRaw(array);
	if (raw === array) return raw;
	track(raw, "iterate", ARRAY_ITERATE_KEY);
	return isShallow(array) ? raw : raw.map(toReactive);
}
function shallowReadArray(arr) {
	track(arr = toRaw(arr), "iterate", ARRAY_ITERATE_KEY);
	return arr;
}
function toWrapped(target, item) {
	if (isReadonly(target)) {
		return isReactive(target) ? toReadonly(toReactive(item)) : toReadonly(item);
	}
	return toReactive(item);
}
const arrayInstrumentations = {
	__proto__: null,
	[Symbol.iterator]() {
		return iterator(this, Symbol.iterator, (item) => toWrapped(this, item));
	},
	concat(...args) {
		return reactiveReadArray(this).concat(...args.map((x) => isArray(x) ? reactiveReadArray(x) : x));
	},
	entries() {
		return iterator(this, "entries", (value) => {
			value[1] = toWrapped(this, value[1]);
			return value;
		});
	},
	every(fn, thisArg) {
		return apply(this, "every", fn, thisArg, void 0, arguments);
	},
	filter(fn, thisArg) {
		return apply(this, "filter", fn, thisArg, (v) => v.map((item) => toWrapped(this, item)), arguments);
	},
	find(fn, thisArg) {
		return apply(this, "find", fn, thisArg, (item) => toWrapped(this, item), arguments);
	},
	findIndex(fn, thisArg) {
		return apply(this, "findIndex", fn, thisArg, void 0, arguments);
	},
	findLast(fn, thisArg) {
		return apply(this, "findLast", fn, thisArg, (item) => toWrapped(this, item), arguments);
	},
	findLastIndex(fn, thisArg) {
		return apply(this, "findLastIndex", fn, thisArg, void 0, arguments);
	},
	// flat, flatMap could benefit from ARRAY_ITERATE but are not straight-forward to implement
	forEach(fn, thisArg) {
		return apply(this, "forEach", fn, thisArg, void 0, arguments);
	},
	includes(...args) {
		return searchProxy(this, "includes", args);
	},
	indexOf(...args) {
		return searchProxy(this, "indexOf", args);
	},
	join(separator) {
		return reactiveReadArray(this).join(separator);
	},
	// keys() iterator only reads `length`, no optimization required
	lastIndexOf(...args) {
		return searchProxy(this, "lastIndexOf", args);
	},
	map(fn, thisArg) {
		return apply(this, "map", fn, thisArg, void 0, arguments);
	},
	pop() {
		return noTracking(this, "pop");
	},
	push(...args) {
		return noTracking(this, "push", args);
	},
	reduce(fn, ...args) {
		return reduce(this, "reduce", fn, args);
	},
	reduceRight(fn, ...args) {
		return reduce(this, "reduceRight", fn, args);
	},
	shift() {
		return noTracking(this, "shift");
	},
	// slice could use ARRAY_ITERATE but also seems to beg for range tracking
	some(fn, thisArg) {
		return apply(this, "some", fn, thisArg, void 0, arguments);
	},
	splice(...args) {
		return noTracking(this, "splice", args);
	},
	toReversed() {
		return reactiveReadArray(this).toReversed();
	},
	toSorted(comparer) {
		return reactiveReadArray(this).toSorted(comparer);
	},
	toSpliced(...args) {
		return reactiveReadArray(this).toSpliced(...args);
	},
	unshift(...args) {
		return noTracking(this, "unshift", args);
	},
	values() {
		return iterator(this, "values", (item) => toWrapped(this, item));
	}
};
function iterator(self, method, wrapValue) {
	const arr = shallowReadArray(self);
	const iter = arr[method]();
	if (arr !== self && !isShallow(self)) {
		iter._next = iter.next;
		iter.next = () => {
			const result = iter._next();
			if (!result.done) {
				result.value = wrapValue(result.value);
			}
			return result;
		};
	}
	return iter;
}
const arrayProto = Array.prototype;
function apply(self, method, fn, thisArg, wrappedRetFn, args) {
	const arr = shallowReadArray(self);
	const needsWrap = arr !== self && !isShallow(self);
	const methodFn = arr[method];
	if (methodFn !== arrayProto[method]) {
		const result2 = methodFn.apply(self, args);
		return needsWrap ? toReactive(result2) : result2;
	}
	let wrappedFn = fn;
	if (arr !== self) {
		if (needsWrap) {
			wrappedFn = function(item, index) {
				return fn.call(this, toWrapped(self, item), index, self);
			};
		} else if (fn.length > 2) {
			wrappedFn = function(item, index) {
				return fn.call(this, item, index, self);
			};
		}
	}
	const result = methodFn.call(arr, wrappedFn, thisArg);
	return needsWrap && wrappedRetFn ? wrappedRetFn(result) : result;
}
function reduce(self, method, fn, args) {
	const arr = shallowReadArray(self);
	const needsWrap = arr !== self && !isShallow(self);
	let wrappedFn = fn;
	let wrapInitialAccumulator = false;
	if (arr !== self) {
		if (needsWrap) {
			wrapInitialAccumulator = args.length === 0;
			wrappedFn = function(acc, item, index) {
				if (wrapInitialAccumulator) {
					wrapInitialAccumulator = false;
					acc = toWrapped(self, acc);
				}
				return fn.call(this, acc, toWrapped(self, item), index, self);
			};
		} else if (fn.length > 3) {
			wrappedFn = function(acc, item, index) {
				return fn.call(this, acc, item, index, self);
			};
		}
	}
	const result = arr[method](wrappedFn, ...args);
	return wrapInitialAccumulator ? toWrapped(self, result) : result;
}
function searchProxy(self, method, args) {
	const arr = toRaw(self);
	track(arr, "iterate", ARRAY_ITERATE_KEY);
	const res = arr[method](...args);
	if ((res === -1 || res === false) && isProxy(args[0])) {
		args[0] = toRaw(args[0]);
		return arr[method](...args);
	}
	return res;
}
function noTracking(self, method, args = []) {
	pauseTracking();
	startBatch();
	const res = toRaw(self)[method].apply(self, args);
	endBatch();
	resetTracking();
	return res;
}
const isNonTrackableKeys = /* @__PURE__ */ makeMap(`__proto__,__v_isRef,__isVue`);
const builtInSymbols = new Set(/* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((key) => key !== "arguments" && key !== "caller").map((key) => Symbol[key]).filter(isSymbol));
function hasOwnProperty(key) {
	if (!isSymbol(key)) key = String(key);
	const obj = toRaw(this);
	track(obj, "has", key);
	return obj.hasOwnProperty(key);
}
class BaseReactiveHandler {
	constructor(_isReadonly = false, _isShallow = false) {
		this._isReadonly = _isReadonly;
		this._isShallow = _isShallow;
	}
	get(target, key, receiver) {
		if (key === "__v_skip") return target["__v_skip"];
		const isReadonly2 = this._isReadonly, isShallow2 = this._isShallow;
		if (key === "__v_isReactive") {
			return !isReadonly2;
		} else if (key === "__v_isReadonly") {
			return isReadonly2;
		} else if (key === "__v_isShallow") {
			return isShallow2;
		} else if (key === "__v_raw") {
			if (receiver === (isReadonly2 ? isShallow2 ? shallowReadonlyMap : readonlyMap : isShallow2 ? shallowReactiveMap : reactiveMap).get(target) || Object.getPrototypeOf(target) === Object.getPrototypeOf(receiver)) {
				return target;
			}
			return;
		}
		const targetIsArray = isArray(target);
		if (!isReadonly2) {
			let fn;
			if (targetIsArray && (fn = arrayInstrumentations[key])) {
				return fn;
			}
			if (key === "hasOwnProperty") {
				return hasOwnProperty;
			}
		}
		const res = Reflect.get(
			target,
			key,
			// if this is a proxy wrapping a ref, return methods using the raw ref
			// as receiver so that we don't have to call `toRaw` on the ref in all
			// its class methods
			isRef(target) ? target : receiver
		);
		if (isSymbol(key) ? builtInSymbols.has(key) : isNonTrackableKeys(key)) {
			return res;
		}
		if (!isReadonly2) {
			track(target, "get", key);
		}
		if (isShallow2) {
			return res;
		}
		if (isRef(res)) {
			const value = targetIsArray && isIntegerKey(key) ? res : res.value;
			return isReadonly2 && isObject(value) ? readonly(value) : value;
		}
		if (isObject(res)) {
			return isReadonly2 ? readonly(res) : reactive(res);
		}
		return res;
	}
}
class MutableReactiveHandler extends BaseReactiveHandler {
	constructor(isShallow2 = false) {
		super(false, isShallow2);
	}
	set(target, key, value, receiver) {
		let oldValue = target[key];
		const isArrayWithIntegerKey = isArray(target) && isIntegerKey(key);
		if (!this._isShallow) {
			const isOldValueReadonly = isReadonly(oldValue);
			if (!isShallow(value) && !isReadonly(value)) {
				oldValue = toRaw(oldValue);
				value = toRaw(value);
			}
			if (!isArrayWithIntegerKey && isRef(oldValue) && !isRef(value)) {
				if (isOldValueReadonly) {
					if (!!("development" !== "production")) {
						warn(`Set operation on key "${String(key)}" failed: target is readonly.`, target[key]);
					}
					return true;
				} else {
					oldValue.value = value;
					return true;
				}
			}
		}
		const hadKey = isArrayWithIntegerKey ? Number(key) < target.length : hasOwn(target, key);
		const result = Reflect.set(target, key, value, isRef(target) ? target : receiver);
		if (target === toRaw(receiver) && result) {
			if (!hadKey) {
				trigger(target, "add", key, value);
			} else if (hasChanged(value, oldValue)) {
				trigger(target, "set", key, value, oldValue);
			}
		}
		return result;
	}
	deleteProperty(target, key) {
		const hadKey = hasOwn(target, key);
		const oldValue = target[key];
		const result = Reflect.deleteProperty(target, key);
		if (result && hadKey) {
			trigger(target, "delete", key, void 0, oldValue);
		}
		return result;
	}
	has(target, key) {
		const result = Reflect.has(target, key);
		if (!isSymbol(key) || !builtInSymbols.has(key)) {
			track(target, "has", key);
		}
		return result;
	}
	ownKeys(target) {
		track(target, "iterate", isArray(target) ? "length" : ITERATE_KEY);
		return Reflect.ownKeys(target);
	}
}
class ReadonlyReactiveHandler extends BaseReactiveHandler {
	constructor(isShallow2 = false) {
		super(true, isShallow2);
	}
	set(target, key) {
		if (!!("development" !== "production")) {
			warn(`Set operation on key "${String(key)}" failed: target is readonly.`, target);
		}
		return true;
	}
	deleteProperty(target, key) {
		if (!!("development" !== "production")) {
			warn(`Delete operation on key "${String(key)}" failed: target is readonly.`, target);
		}
		return true;
	}
}
const mutableHandlers = /* @__PURE__ */ new MutableReactiveHandler();
const readonlyHandlers = /* @__PURE__ */ new ReadonlyReactiveHandler();
const shallowReactiveHandlers = /* @__PURE__ */ new MutableReactiveHandler(true);
const shallowReadonlyHandlers = /* @__PURE__ */ new ReadonlyReactiveHandler(true);
const toShallow = (value) => value;
const getProto = (v) => Reflect.getPrototypeOf(v);
function createIterableMethod(method, isReadonly2, isShallow2) {
	return function(...args) {
		const target = this["__v_raw"];
		const rawTarget = toRaw(target);
		const targetIsMap = isMap(rawTarget);
		const isPair = method === "entries" || method === Symbol.iterator && targetIsMap;
		const isKeyOnly = method === "keys" && targetIsMap;
		const innerIterator = target[method](...args);
		const wrap = isShallow2 ? toShallow : isReadonly2 ? toReadonly : toReactive;
		!isReadonly2 && track(rawTarget, "iterate", isKeyOnly ? MAP_KEY_ITERATE_KEY : ITERATE_KEY);
		return extend(
			// inheriting all iterator properties
			Object.create(innerIterator),
			{ 
			// iterator protocol
next() {
				const { value, done } = innerIterator.next();
				return done ? {
					value,
					done
				} : {
					value: isPair ? [wrap(value[0]), wrap(value[1])] : wrap(value),
					done
				};
			} }
		);
	};
}
function createReadonlyMethod(type) {
	return function(...args) {
		if (!!("development" !== "production")) {
			const key = args[0] ? `on key "${args[0]}" ` : ``;
			warn(`${capitalize(type)} operation ${key}failed: target is readonly.`, toRaw(this));
		}
		return type === "delete" ? false : type === "clear" ? void 0 : this;
	};
}
function createInstrumentations(readonly, shallow) {
	const instrumentations = {
		get(key) {
			const target = this["__v_raw"];
			const rawTarget = toRaw(target);
			const rawKey = toRaw(key);
			if (!readonly) {
				if (hasChanged(key, rawKey)) {
					track(rawTarget, "get", key);
				}
				track(rawTarget, "get", rawKey);
			}
			const { has } = getProto(rawTarget);
			const wrap = shallow ? toShallow : readonly ? toReadonly : toReactive;
			if (has.call(rawTarget, key)) {
				return wrap(target.get(key));
			} else if (has.call(rawTarget, rawKey)) {
				return wrap(target.get(rawKey));
			} else if (target !== rawTarget) {
				target.get(key);
			}
		},
		get size() {
			const target = this["__v_raw"];
			!readonly && track(toRaw(target), "iterate", ITERATE_KEY);
			return target.size;
		},
		has(key) {
			const target = this["__v_raw"];
			const rawTarget = toRaw(target);
			const rawKey = toRaw(key);
			if (!readonly) {
				if (hasChanged(key, rawKey)) {
					track(rawTarget, "has", key);
				}
				track(rawTarget, "has", rawKey);
			}
			return key === rawKey ? target.has(key) : target.has(key) || target.has(rawKey);
		},
		forEach(callback, thisArg) {
			const observed = this;
			const target = observed["__v_raw"];
			const rawTarget = toRaw(target);
			const wrap = shallow ? toShallow : readonly ? toReadonly : toReactive;
			!readonly && track(rawTarget, "iterate", ITERATE_KEY);
			return target.forEach((value, key) => {
				return callback.call(thisArg, wrap(value), wrap(key), observed);
			});
		}
	};
	extend(instrumentations, readonly ? {
		add: createReadonlyMethod("add"),
		set: createReadonlyMethod("set"),
		delete: createReadonlyMethod("delete"),
		clear: createReadonlyMethod("clear")
	} : {
		add(value) {
			const target = toRaw(this);
			const proto = getProto(target);
			const rawValue = toRaw(value);
			const valueToAdd = !shallow && !isShallow(value) && !isReadonly(value) ? rawValue : value;
			const hadKey = proto.has.call(target, valueToAdd) || hasChanged(value, valueToAdd) && proto.has.call(target, value) || hasChanged(rawValue, valueToAdd) && proto.has.call(target, rawValue);
			if (!hadKey) {
				target.add(valueToAdd);
				trigger(target, "add", valueToAdd, valueToAdd);
			}
			return this;
		},
		set(key, value) {
			if (!shallow && !isShallow(value) && !isReadonly(value)) {
				value = toRaw(value);
			}
			const target = toRaw(this);
			const { has, get } = getProto(target);
			let hadKey = has.call(target, key);
			if (!hadKey) {
				key = toRaw(key);
				hadKey = has.call(target, key);
			} else if (!!("development" !== "production")) {
				checkIdentityKeys(target, has, key);
			}
			const oldValue = get.call(target, key);
			target.set(key, value);
			if (!hadKey) {
				trigger(target, "add", key, value);
			} else if (hasChanged(value, oldValue)) {
				trigger(target, "set", key, value, oldValue);
			}
			return this;
		},
		delete(key) {
			const target = toRaw(this);
			const { has, get } = getProto(target);
			let hadKey = has.call(target, key);
			if (!hadKey) {
				key = toRaw(key);
				hadKey = has.call(target, key);
			} else if (!!("development" !== "production")) {
				checkIdentityKeys(target, has, key);
			}
			const oldValue = get ? get.call(target, key) : void 0;
			const result = target.delete(key);
			if (hadKey) {
				trigger(target, "delete", key, void 0, oldValue);
			}
			return result;
		},
		clear() {
			const target = toRaw(this);
			const hadItems = target.size !== 0;
			const oldTarget = !!("development" !== "production") ? isMap(target) ? new Map(target) : new Set(target) : void 0;
			const result = target.clear();
			if (hadItems) {
				trigger(target, "clear", void 0, void 0, oldTarget);
			}
			return result;
		}
	});
	const iteratorMethods = [
		"keys",
		"values",
		"entries",
		Symbol.iterator
	];
	iteratorMethods.forEach((method) => {
		instrumentations[method] = createIterableMethod(method, readonly, shallow);
	});
	return instrumentations;
}
function createInstrumentationGetter(isReadonly2, shallow) {
	const instrumentations = createInstrumentations(isReadonly2, shallow);
	return (target, key, receiver) => {
		if (key === "__v_isReactive") {
			return !isReadonly2;
		} else if (key === "__v_isReadonly") {
			return isReadonly2;
		} else if (key === "__v_raw") {
			return target;
		}
		return Reflect.get(hasOwn(instrumentations, key) && key in target ? instrumentations : target, key, receiver);
	};
}
const mutableCollectionHandlers = { get: /* @__PURE__ */ createInstrumentationGetter(false, false) };
const shallowCollectionHandlers = { get: /* @__PURE__ */ createInstrumentationGetter(false, true) };
const readonlyCollectionHandlers = { get: /* @__PURE__ */ createInstrumentationGetter(true, false) };
const shallowReadonlyCollectionHandlers = { get: /* @__PURE__ */ createInstrumentationGetter(true, true) };
function checkIdentityKeys(target, has, key) {
	const rawKey = toRaw(key);
	if (rawKey !== key && has.call(target, rawKey)) {
		const type = toRawType(target);
		warn(`Reactive ${type} contains both the raw and reactive versions of the same object${type === `Map` ? ` as keys` : ``}, which can lead to inconsistencies. Avoid differentiating between the raw and reactive versions of an object and only use the reactive version if possible.`);
	}
}
const reactiveMap = /* @__PURE__ */ new WeakMap();
const shallowReactiveMap = /* @__PURE__ */ new WeakMap();
const readonlyMap = /* @__PURE__ */ new WeakMap();
const shallowReadonlyMap = /* @__PURE__ */ new WeakMap();
function targetTypeMap(rawType) {
	switch (rawType) {
		case "Object":
		case "Array": return 1;
		case "Map":
		case "Set":
		case "WeakMap":
		case "WeakSet": return 2;
		default: return 0;
	}
}
// @__NO_SIDE_EFFECTS__
function reactive(target) {
	if (/* @__PURE__ */ isReadonly(target)) {
		return target;
	}
	return createReactiveObject(target, false, mutableHandlers, mutableCollectionHandlers, reactiveMap);
}
// @__NO_SIDE_EFFECTS__
function shallowReactive(target) {
	return createReactiveObject(target, false, shallowReactiveHandlers, shallowCollectionHandlers, shallowReactiveMap);
}
// @__NO_SIDE_EFFECTS__
function readonly(target) {
	return createReactiveObject(target, true, readonlyHandlers, readonlyCollectionHandlers, readonlyMap);
}
// @__NO_SIDE_EFFECTS__
function shallowReadonly(target) {
	return createReactiveObject(target, true, shallowReadonlyHandlers, shallowReadonlyCollectionHandlers, shallowReadonlyMap);
}
function createReactiveObject(target, isReadonly2, baseHandlers, collectionHandlers, proxyMap) {
	if (!isObject(target)) {
		if (!!("development" !== "production")) {
			warn(`value cannot be made ${isReadonly2 ? "readonly" : "reactive"}: ${String(target)}`);
		}
		return target;
	}
	if (target["__v_raw"] && !(isReadonly2 && target["__v_isReactive"])) {
		return target;
	}
	if (target["__v_skip"] || !Object.isExtensible(target)) {
		return target;
	}
	const existingProxy = proxyMap.get(target);
	if (existingProxy) {
		return existingProxy;
	}
	const targetType = targetTypeMap(toRawType(target));
	if (targetType === 0) {
		return target;
	}
	const proxy = new Proxy(target, targetType === 2 ? collectionHandlers : baseHandlers);
	proxyMap.set(target, proxy);
	return proxy;
}
// @__NO_SIDE_EFFECTS__
function isReactive(value) {
	if (/* @__PURE__ */ isReadonly(value)) {
		return /* @__PURE__ */ isReactive(value["__v_raw"]);
	}
	return !!(value && value["__v_isReactive"]);
}
// @__NO_SIDE_EFFECTS__
function isReadonly(value) {
	return !!(value && value["__v_isReadonly"]);
}
// @__NO_SIDE_EFFECTS__
function isShallow(value) {
	return !!(value && value["__v_isShallow"]);
}
// @__NO_SIDE_EFFECTS__
function isProxy(value) {
	return value ? !!value["__v_raw"] : false;
}
// @__NO_SIDE_EFFECTS__
function toRaw(observed) {
	const raw = observed && observed["__v_raw"];
	return raw ? /* @__PURE__ */ toRaw(raw) : observed;
}
function markRaw(value) {
	if (!hasOwn(value, "__v_skip") && Object.isExtensible(value)) {
		def(value, "__v_skip", true);
	}
	return value;
}
const toReactive = (value) => isObject(value) ? /* @__PURE__ */ reactive(value) : value;
const toReadonly = (value) => isObject(value) ? /* @__PURE__ */ readonly(value) : value;
// @__NO_SIDE_EFFECTS__
function isRef(r) {
	return r ? r["__v_isRef"] === true : false;
}
// @__NO_SIDE_EFFECTS__
function ref(value) {
	return createRef(value, false);
}
// @__NO_SIDE_EFFECTS__
function shallowRef(value) {
	return createRef(value, true);
}
function createRef(rawValue, shallow) {
	if (/* @__PURE__ */ isRef(rawValue)) {
		return rawValue;
	}
	return new RefImpl(rawValue, shallow);
}
class RefImpl {
	constructor(value, isShallow2) {
		this.dep = new Dep();
		this["__v_isRef"] = true;
		this["__v_isShallow"] = false;
		this._rawValue = isShallow2 ? value : toRaw(value);
		this._value = isShallow2 ? value : toReactive(value);
		this["__v_isShallow"] = isShallow2;
	}
	get value() {
		if (!!("development" !== "production")) {
			this.dep.track({
				target: this,
				type: "get",
				key: "value"
			});
		} else {
			this.dep.track();
		}
		return this._value;
	}
	set value(newValue) {
		const oldValue = this._rawValue;
		const useDirectValue = this["__v_isShallow"] || isShallow(newValue) || isReadonly(newValue);
		newValue = useDirectValue ? newValue : toRaw(newValue);
		if (hasChanged(newValue, oldValue)) {
			this._rawValue = newValue;
			this._value = useDirectValue ? newValue : toReactive(newValue);
			if (!!("development" !== "production")) {
				this.dep.trigger({
					target: this,
					type: "set",
					key: "value",
					newValue,
					oldValue
				});
			} else {
				this.dep.trigger();
			}
		}
	}
}
function triggerRef(ref2) {
	if (ref2.dep) {
		if (!!("development" !== "production")) {
			ref2.dep.trigger({
				target: ref2,
				type: "set",
				key: "value",
				newValue: ref2._value
			});
		} else {
			ref2.dep.trigger();
		}
	}
}
function unref(ref2) {
	return /* @__PURE__ */ isRef(ref2) ? ref2.value : ref2;
}
function toValue(source) {
	return isFunction(source) ? source() : unref(source);
}
const shallowUnwrapHandlers = {
	get: (target, key, receiver) => key === "__v_raw" ? target : unref(Reflect.get(target, key, receiver)),
	set: (target, key, value, receiver) => {
		const oldValue = target[key];
		if (/* @__PURE__ */ isRef(oldValue) && !/* @__PURE__ */ isRef(value)) {
			oldValue.value = value;
			return true;
		} else {
			return Reflect.set(target, key, value, receiver);
		}
	}
};
function proxyRefs(objectWithRefs) {
	return isReactive(objectWithRefs) ? objectWithRefs : new Proxy(objectWithRefs, shallowUnwrapHandlers);
}
class CustomRefImpl {
	constructor(factory) {
		this["__v_isRef"] = true;
		this._value = void 0;
		const dep = this.dep = new Dep();
		const { get, set } = factory(dep.track.bind(dep), dep.trigger.bind(dep));
		this._get = get;
		this._set = set;
	}
	get value() {
		return this._value = this._get();
	}
	set value(newVal) {
		this._set(newVal);
	}
}
function customRef(factory) {
	return new CustomRefImpl(factory);
}
// @__NO_SIDE_EFFECTS__
function toRefs(object) {
	if (!!("development" !== "production") && !isProxy(object)) {
		warn(`toRefs() expects a reactive object but received a plain one.`);
	}
	const ret = isArray(object) ? new Array(object.length) : {};
	for (const key in object) {
		ret[key] = propertyToRef(object, key);
	}
	return ret;
}
class ObjectRefImpl {
	constructor(_object, key, _defaultValue) {
		this._object = _object;
		this._defaultValue = _defaultValue;
		this["__v_isRef"] = true;
		this._value = void 0;
		this._key = isSymbol(key) ? key : String(key);
		this._raw = toRaw(_object);
		let shallow = true;
		let obj = _object;
		if (!isArray(_object) || isSymbol(this._key) || !isIntegerKey(this._key)) {
			do {
				shallow = !isProxy(obj) || isShallow(obj);
			} while (shallow && (obj = obj["__v_raw"]));
		}
		this._shallow = shallow;
	}
	get value() {
		let val = this._object[this._key];
		if (this._shallow) {
			val = unref(val);
		}
		return this._value = val === void 0 ? this._defaultValue : val;
	}
	set value(newVal) {
		if (this._shallow && /* @__PURE__ */ isRef(this._raw[this._key])) {
			const nestedRef = this._object[this._key];
			if (/* @__PURE__ */ isRef(nestedRef)) {
				nestedRef.value = newVal;
				return;
			}
		}
		this._object[this._key] = newVal;
	}
	get dep() {
		return getDepFromReactive(this._raw, this._key);
	}
}
class GetterRefImpl {
	constructor(_getter) {
		this._getter = _getter;
		this["__v_isRef"] = true;
		this["__v_isReadonly"] = true;
		this._value = void 0;
	}
	get value() {
		return this._value = this._getter();
	}
}
// @__NO_SIDE_EFFECTS__
function toRef(source, key, defaultValue) {
	if (/* @__PURE__ */ isRef(source)) {
		return source;
	} else if (isFunction(source)) {
		return new GetterRefImpl(source);
	} else if (isObject(source) && arguments.length > 1) {
		return propertyToRef(source, key, defaultValue);
	} else {
		return /* @__PURE__ */ ref(source);
	}
}
function propertyToRef(source, key, defaultValue) {
	return new ObjectRefImpl(source, key, defaultValue);
}
class ComputedRefImpl {
	constructor(fn, setter, isSSR) {
		this.fn = fn;
		this.setter = setter;
		/**
		* @internal
		*/
		this._value = void 0;
		/**
		* @internal
		*/
		this.dep = new Dep(this);
		/**
		* @internal
		*/
		this.__v_isRef = true;
		// TODO isolatedDeclarations "__v_isReadonly"
		// A computed is also a subscriber that tracks other deps
		/**
		* @internal
		*/
		this.deps = void 0;
		/**
		* @internal
		*/
		this.depsTail = void 0;
		/**
		* @internal
		*/
		this.flags = 16;
		/**
		* @internal
		*/
		this.globalVersion = globalVersion - 1;
		/**
		* @internal
		*/
		this.next = void 0;
		// for backwards compat
		this.effect = this;
		this["__v_isReadonly"] = !setter;
		this.isSSR = isSSR;
	}
	/**
	* @internal
	*/
	notify() {
		this.flags |= 16;
		if (!(this.flags & 8) && activeSub !== this) {
			batch(this, true);
			return true;
		} else if (!!("development" !== "production"));
	}
	get value() {
		const link = !!("development" !== "production") ? this.dep.track({
			target: this,
			type: "get",
			key: "value"
		}) : this.dep.track();
		refreshComputed(this);
		if (link) {
			link.version = this.dep.version;
		}
		return this._value;
	}
	set value(newValue) {
		if (this.setter) {
			this.setter(newValue);
		} else if (!!("development" !== "production")) {
			warn("Write operation failed: computed value is readonly");
		}
	}
}
// @__NO_SIDE_EFFECTS__
function computed(getterOrOptions, debugOptions, isSSR = false) {
	let getter;
	let setter;
	if (isFunction(getterOrOptions)) {
		getter = getterOrOptions;
	} else {
		getter = getterOrOptions.get;
		setter = getterOrOptions.set;
	}
	const cRef = new ComputedRefImpl(getter, setter, isSSR);
	if (!!("development" !== "production") && debugOptions && !isSSR) {
		cRef.onTrack = debugOptions.onTrack;
		cRef.onTrigger = debugOptions.onTrigger;
	}
	return cRef;
}
const TrackOpTypes = {
	"GET": "get",
	"HAS": "has",
	"ITERATE": "iterate"
};
const TriggerOpTypes = {
	"SET": "set",
	"ADD": "add",
	"DELETE": "delete",
	"CLEAR": "clear"
};
const ReactiveFlags = {
	"SKIP": "__v_skip",
	"IS_REACTIVE": "__v_isReactive",
	"IS_READONLY": "__v_isReadonly",
	"IS_SHALLOW": "__v_isShallow",
	"RAW": "__v_raw",
	"IS_REF": "__v_isRef"
};
const WatchErrorCodes = {
	"WATCH_GETTER": 2,
	"2": "WATCH_GETTER",
	"WATCH_CALLBACK": 3,
	"3": "WATCH_CALLBACK",
	"WATCH_CLEANUP": 4,
	"4": "WATCH_CLEANUP"
};
const INITIAL_WATCHER_VALUE = {};
const cleanupMap = /* @__PURE__ */ new WeakMap();
let activeWatcher = void 0;
function getCurrentWatcher() {
	return activeWatcher;
}
function onWatcherCleanup(cleanupFn, failSilently = false, owner = activeWatcher) {
	if (owner) {
		let cleanups = cleanupMap.get(owner);
		if (!cleanups) cleanupMap.set(owner, cleanups = []);
		cleanups.push(cleanupFn);
	} else if (!!("development" !== "production") && !failSilently) {
		warn(`onWatcherCleanup() was called when there was no active watcher to associate with.`);
	}
}
function watch(source, cb, options = EMPTY_OBJ) {
	const { immediate, deep, once, scheduler, augmentJob, call } = options;
	const warnInvalidSource = (s) => {
		(options.onWarn || warn)(`Invalid watch source: `, s, `A watch source can only be a getter/effect function, a ref, a reactive object, or an array of these types.`);
	};
	const reactiveGetter = (source2) => {
		if (deep) return source2;
		if (isShallow(source2) || deep === false || deep === 0) return traverse(source2, 1);
		return traverse(source2);
	};
	let effect;
	let getter;
	let cleanup;
	let boundCleanup;
	let forceTrigger = false;
	let isMultiSource = false;
	if (isRef(source)) {
		getter = () => source.value;
		forceTrigger = isShallow(source);
	} else if (isReactive(source)) {
		getter = () => reactiveGetter(source);
		forceTrigger = true;
	} else if (isArray(source)) {
		isMultiSource = true;
		forceTrigger = source.some((s) => isReactive(s) || isShallow(s));
		getter = () => source.map((s) => {
			if (isRef(s)) {
				return s.value;
			} else if (isReactive(s)) {
				return reactiveGetter(s);
			} else if (isFunction(s)) {
				return call ? call(s, 2) : s();
			} else {
				!!("development" !== "production") && warnInvalidSource(s);
			}
		});
	} else if (isFunction(source)) {
		if (cb) {
			getter = call ? () => call(source, 2) : source;
		} else {
			getter = () => {
				if (cleanup) {
					pauseTracking();
					try {
						cleanup();
					} finally {
						resetTracking();
					}
				}
				const currentEffect = activeWatcher;
				activeWatcher = effect;
				try {
					return call ? call(source, 3, [boundCleanup]) : source(boundCleanup);
				} finally {
					activeWatcher = currentEffect;
				}
			};
		}
	} else {
		getter = NOOP;
		!!("development" !== "production") && warnInvalidSource(source);
	}
	if (cb && deep) {
		const baseGetter = getter;
		const depth = deep === true ? Infinity : deep;
		getter = () => traverse(baseGetter(), depth);
	}
	const scope = getCurrentScope();
	const watchHandle = () => {
		effect.stop();
		if (scope && scope.active) {
			remove(scope.effects, effect);
		}
	};
	if (once && cb) {
		const _cb = cb;
		cb = (...args) => {
			const res = _cb(...args);
			watchHandle();
			return res;
		};
	}
	let oldValue = isMultiSource ? new Array(source.length).fill(INITIAL_WATCHER_VALUE) : INITIAL_WATCHER_VALUE;
	const job = (immediateFirstRun) => {
		if (!(effect.flags & 1) || !effect.dirty && !immediateFirstRun) {
			return;
		}
		if (cb) {
			const newValue = effect.run();
			if (immediateFirstRun || deep || forceTrigger || (isMultiSource ? newValue.some((v, i) => hasChanged(v, oldValue[i])) : hasChanged(newValue, oldValue))) {
				if (cleanup) {
					cleanup();
				}
				const currentWatcher = activeWatcher;
				activeWatcher = effect;
				try {
					const args = [
						newValue,
						oldValue === INITIAL_WATCHER_VALUE ? void 0 : isMultiSource && oldValue[0] === INITIAL_WATCHER_VALUE ? [] : oldValue,
						boundCleanup
					];
					oldValue = newValue;
					call ? call(cb, 3, args) : 
					// @ts-expect-error
					cb(...args);
				} finally {
					activeWatcher = currentWatcher;
				}
			}
		} else {
			effect.run();
		}
	};
	if (augmentJob) {
		augmentJob(job);
	}
	effect = new ReactiveEffect(getter);
	effect.scheduler = scheduler ? () => scheduler(job, false) : job;
	boundCleanup = (fn) => onWatcherCleanup(fn, false, effect);
	cleanup = effect.onStop = () => {
		const cleanups = cleanupMap.get(effect);
		if (cleanups) {
			if (call) {
				call(cleanups, 4);
			} else {
				for (const cleanup2 of cleanups) cleanup2();
			}
			cleanupMap.delete(effect);
		}
	};
	if (!!("development" !== "production")) {
		effect.onTrack = options.onTrack;
		effect.onTrigger = options.onTrigger;
	}
	if (cb) {
		if (immediate) {
			job(true);
		} else {
			oldValue = effect.run();
		}
	} else if (scheduler) {
		scheduler(job.bind(null, true), true);
	} else {
		effect.run();
	}
	watchHandle.pause = effect.pause.bind(effect);
	watchHandle.resume = effect.resume.bind(effect);
	watchHandle.stop = watchHandle;
	return watchHandle;
}
function traverse(value, depth = Infinity, seen) {
	if (depth <= 0 || !isObject(value) || value["__v_skip"]) {
		return value;
	}
	seen = seen || /* @__PURE__ */ new Map();
	if ((seen.get(value) || 0) >= depth) {
		return value;
	}
	seen.set(value, depth);
	depth--;
	if (isRef(value)) {
		traverse(value.value, depth, seen);
	} else if (isArray(value)) {
		for (let i = 0; i < value.length; i++) {
			traverse(value[i], depth, seen);
		}
	} else if (isSet(value) || isMap(value)) {
		value.forEach((v) => {
			traverse(v, depth, seen);
		});
	} else if (isPlainObject(value)) {
		for (const key in value) {
			traverse(value[key], depth, seen);
		}
		for (const key of Object.getOwnPropertySymbols(value)) {
			if (Object.prototype.propertyIsEnumerable.call(value, key)) {
				traverse(value[key], depth, seen);
			}
		}
	}
	return value;
}
export { ARRAY_ITERATE_KEY, EffectFlags, EffectScope, ITERATE_KEY, MAP_KEY_ITERATE_KEY, ReactiveEffect, ReactiveFlags, TrackOpTypes, TriggerOpTypes, WatchErrorCodes, computed, customRef, effect, effectScope, enableTracking, getCurrentScope, getCurrentWatcher, isProxy, isReactive, isReadonly, isRef, isShallow, markRaw, onEffectCleanup, onScopeDispose, onWatcherCleanup, pauseTracking, proxyRefs, reactive, reactiveReadArray, readonly, ref, resetTracking, shallowReactive, shallowReadArray, shallowReadonly, shallowRef, stop, toRaw, toReactive, toReadonly, toRef, toRefs, toValue, track, traverse, trigger, triggerRef, unref, watch };

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFLQSxTQUFTLFFBQVEsWUFBWSxTQUFTLGNBQWMsVUFBVSxPQUFPLFFBQVEsVUFBVSxTQUFTLFlBQVksV0FBVyxLQUFLLFlBQVksV0FBVyxPQUFPLGVBQWUsUUFBUSxZQUFZO0FBRTdMLFNBQVMsS0FBSyxLQUFLLEdBQUcsTUFBTTtDQUMxQixRQUFRLEtBQUssY0FBYyxPQUFPLEdBQUcsSUFBSTtBQUMzQztBQUVBLElBQUk7QUFDSixNQUFNLFlBQVk7O0NBRWhCLFlBQVksV0FBVyxPQUFPO0VBQzVCLEtBQUssV0FBVzs7OztFQUloQixLQUFLLFVBQVU7Ozs7RUFJZixLQUFLLE1BQU07Ozs7RUFJWCxLQUFLLFVBQVUsQ0FBQzs7OztFQUloQixLQUFLLFdBQVcsQ0FBQztFQUNqQixLQUFLLFlBQVk7RUFDakIsS0FBSyxhQUFhO0VBQ2xCLEtBQUssV0FBVztFQUNoQixJQUFJLENBQUMsWUFBWSxtQkFBbUI7R0FDbEMsSUFBSSxrQkFBa0IsUUFBUTtJQUM1QixLQUFLLFNBQVM7SUFDZCxLQUFLLFNBQVMsa0JBQWtCLFdBQVcsa0JBQWtCLFNBQVMsQ0FBQyxHQUFFLENBQUUsS0FDekUsSUFDRixJQUFJO0dBQ04sT0FBTztJQUNMLEtBQUssVUFBVTtJQUNmLEtBQUssYUFBYTtHQUNwQjtFQUNGO0NBQ0Y7Q0FDQSxJQUFJLFNBQVM7RUFDWCxPQUFPLEtBQUs7Q0FDZDtDQUNBLFFBQVE7RUFDTixJQUFJLEtBQUssU0FBUztHQUNoQixLQUFLLFlBQVk7R0FDakIsSUFBSSxHQUFHO0dBQ1AsSUFBSSxLQUFLLFFBQVE7SUFDZixNQUFNLFNBQVMsS0FBSyxPQUFPLE1BQU07SUFDakMsS0FBSyxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsSUFBSSxHQUFHLEtBQUs7S0FDekMsT0FBTyxFQUFFLENBQUMsTUFBTTtJQUNsQjtHQUNGO0dBQ0EsS0FBSyxJQUFJLEdBQUcsSUFBSSxLQUFLLFFBQVEsUUFBUSxJQUFJLEdBQUcsS0FBSztJQUMvQyxLQUFLLFFBQVEsRUFBRSxDQUFDLE1BQU07R0FDeEI7RUFDRjtDQUNGOzs7O0NBSUEsU0FBUztFQUNQLElBQUksS0FBSyxTQUFTO0dBQ2hCLElBQUksS0FBSyxXQUFXO0lBQ2xCLEtBQUssWUFBWTtJQUNqQixJQUFJLEdBQUc7SUFDUCxJQUFJLEtBQUssUUFBUTtLQUNmLE1BQU0sU0FBUyxLQUFLLE9BQU8sTUFBTTtLQUNqQyxLQUFLLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxJQUFJLEdBQUcsS0FBSztNQUN6QyxPQUFPLEVBQUUsQ0FBQyxPQUFPO0tBQ25CO0lBQ0Y7SUFDQSxNQUFNLFVBQVUsS0FBSyxRQUFRLE1BQU07SUFDbkMsS0FBSyxJQUFJLEdBQUcsSUFBSSxRQUFRLFFBQVEsSUFBSSxHQUFHLEtBQUs7S0FDMUMsUUFBUSxFQUFFLENBQUMsT0FBTztJQUNwQjtHQUNGO0VBQ0Y7Q0FDRjtDQUNBLElBQUksSUFBSTtFQUNOLElBQUksS0FBSyxTQUFTO0dBQ2hCLE1BQU0scUJBQXFCO0dBQzNCLElBQUk7SUFDRixvQkFBb0I7SUFDcEIsT0FBTyxHQUFHO0dBQ1osVUFBVTtJQUNSLG9CQUFvQjtHQUN0QjtFQUNGLE9BQU8sSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsS0FBSyxZQUFZO0dBQ3ZFLEtBQUssc0NBQXNDO0VBQzdDO0NBQ0Y7Ozs7O0NBS0EsS0FBSztFQUNILElBQUksRUFBRSxLQUFLLFFBQVEsR0FBRztHQUNwQixLQUFLLFlBQVk7R0FDakIsb0JBQW9CO0VBQ3RCO0NBQ0Y7Ozs7O0NBS0EsTUFBTTtFQUNKLElBQUksS0FBSyxNQUFNLEtBQUssRUFBRSxLQUFLLFFBQVEsR0FBRztHQUNwQyxJQUFJLHNCQUFzQixNQUFNO0lBQzlCLG9CQUFvQixLQUFLO0dBQzNCLE9BQU87SUFDTCxJQUFJLFVBQVU7SUFDZCxPQUFPLFNBQVM7S0FDZCxJQUFJLFFBQVEsY0FBYyxNQUFNO01BQzlCLFFBQVEsWUFBWSxLQUFLO01BQ3pCO0tBQ0Y7S0FDQSxVQUFVLFFBQVE7SUFDcEI7R0FDRjtHQUNBLEtBQUssWUFBWSxLQUFLO0VBQ3hCO0NBQ0Y7Q0FDQSxLQUFLLFlBQVk7RUFDZixJQUFJLEtBQUssU0FBUztHQUNoQixLQUFLLFVBQVU7R0FDZixJQUFJLEdBQUc7R0FDUCxLQUFLLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxRQUFRLElBQUksR0FBRyxLQUFLO0lBQy9DLEtBQUssUUFBUSxFQUFFLENBQUMsS0FBSztHQUN2QjtHQUNBLEtBQUssUUFBUSxTQUFTO0dBQ3RCLEtBQUssSUFBSSxHQUFHLElBQUksS0FBSyxTQUFTLFFBQVEsSUFBSSxHQUFHLEtBQUs7SUFDaEQsS0FBSyxTQUFTLEVBQUUsQ0FBQztHQUNuQjtHQUNBLEtBQUssU0FBUyxTQUFTO0dBQ3ZCLElBQUksS0FBSyxRQUFRO0lBQ2YsTUFBTSxTQUFTLEtBQUssT0FBTyxNQUFNO0lBQ2pDLEtBQUssSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLElBQUksR0FBRyxLQUFLO0tBQ3pDLE9BQU8sRUFBRSxDQUFDLEtBQUssSUFBSTtJQUNyQjtJQUNBLEtBQUssT0FBTyxTQUFTO0dBQ3ZCO0dBQ0EsSUFBSSxDQUFDLEtBQUssWUFBWSxLQUFLLFVBQVUsQ0FBQyxZQUFZO0lBQ2hELE1BQU0sT0FBTyxLQUFLLE9BQU8sT0FBTyxJQUFJO0lBQ3BDLElBQUksUUFBUSxTQUFTLE1BQU07S0FDekIsS0FBSyxPQUFPLE9BQU8sS0FBSyxTQUFTO0tBQ2pDLEtBQUssUUFBUSxLQUFLO0lBQ3BCO0dBQ0Y7R0FDQSxLQUFLLFNBQVMsS0FBSztFQUNyQjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLFlBQVksVUFBVTtDQUM3QixPQUFPLElBQUksWUFBWSxRQUFRO0FBQ2pDO0FBQ0EsU0FBUyxrQkFBa0I7Q0FDekIsT0FBTztBQUNUO0FBQ0EsU0FBUyxlQUFlLElBQUksZUFBZSxPQUFPO0NBQ2hELElBQUksbUJBQW1CO0VBQ3JCLGtCQUFrQixTQUFTLEtBQUssRUFBRTtDQUNwQyxPQUFPLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLENBQUMsY0FBYztFQUNyRSxLQUNFLHdGQUNGO0NBQ0Y7QUFDRjtBQUVBLElBQUk7QUFDSixNQUFNLGNBQWM7Q0FDbEIsVUFBVTtDQUNWLEtBQUs7Q0FDTCxXQUFXO0NBQ1gsS0FBSztDQUNMLFlBQVk7Q0FDWixLQUFLO0NBQ0wsWUFBWTtDQUNaLEtBQUs7Q0FDTCxTQUFTO0NBQ1QsTUFBTTtDQUNOLGlCQUFpQjtDQUNqQixNQUFNO0NBQ04sVUFBVTtDQUNWLE1BQU07Q0FDTixhQUFhO0NBQ2IsT0FBTztBQUNUO0FBQ0EsTUFBTSxxQ0FBcUMsSUFBSSxRQUFRO0FBQ3ZELE1BQU0sZUFBZTtDQUNuQixZQUFZLElBQUk7RUFDZCxLQUFLLEtBQUs7Ozs7RUFJVixLQUFLLE9BQU8sS0FBSzs7OztFQUlqQixLQUFLLFdBQVcsS0FBSzs7OztFQUlyQixLQUFLLFFBQVEsSUFBSTs7OztFQUlqQixLQUFLLE9BQU8sS0FBSzs7OztFQUlqQixLQUFLLFVBQVUsS0FBSztFQUNwQixLQUFLLFlBQVksS0FBSztFQUN0QixJQUFJLG1CQUFtQjtHQUNyQixJQUFJLGtCQUFrQixRQUFRO0lBQzVCLGtCQUFrQixRQUFRLEtBQUssSUFBSTtHQUNyQyxPQUFPO0lBQ0wsS0FBSyxTQUFTLENBQUM7R0FDakI7RUFDRjtDQUNGO0NBQ0EsUUFBUTtFQUNOLEtBQUssU0FBUztDQUNoQjtDQUNBLFNBQVM7RUFDUCxJQUFJLEtBQUssUUFBUSxJQUFJO0dBQ25CLEtBQUssU0FBUyxDQUFDO0dBQ2YsSUFBSSxtQkFBbUIsSUFBSSxJQUFJLEdBQUc7SUFDaEMsbUJBQW1CLE9BQU8sSUFBSTtJQUM5QixLQUFLLFFBQVE7R0FDZjtFQUNGO0NBQ0Y7Ozs7Q0FJQSxTQUFTO0VBQ1AsSUFBSSxLQUFLLFFBQVEsS0FBSyxFQUFFLEtBQUssUUFBUSxLQUFLO0dBQ3hDO0VBQ0Y7RUFDQSxJQUFJLEVBQUUsS0FBSyxRQUFRLElBQUk7R0FDckIsTUFBTSxJQUFJO0VBQ1o7Q0FDRjtDQUNBLE1BQU07RUFDSixJQUFJLEVBQUUsS0FBSyxRQUFRLElBQUk7R0FDckIsT0FBTyxLQUFLLEdBQUc7RUFDakI7RUFDQSxLQUFLLFNBQVM7RUFDZCxjQUFjLElBQUk7RUFDbEIsWUFBWSxJQUFJO0VBQ2hCLE1BQU0sYUFBYTtFQUNuQixNQUFNLGtCQUFrQjtFQUN4QixZQUFZO0VBQ1osY0FBYztFQUNkLElBQUk7R0FDRixPQUFPLEtBQUssR0FBRztFQUNqQixVQUFVO0dBQ1IsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsY0FBYyxNQUFNO0lBQ25FLEtBQ0UsK0VBQ0Y7R0FDRjtHQUNBLFlBQVksSUFBSTtHQUNoQixZQUFZO0dBQ1osY0FBYztHQUNkLEtBQUssU0FBUyxDQUFDO0VBQ2pCO0NBQ0Y7Q0FDQSxPQUFPO0VBQ0wsSUFBSSxLQUFLLFFBQVEsR0FBRztHQUNsQixLQUFLLElBQUksT0FBTyxLQUFLLE1BQU0sTUFBTSxPQUFPLEtBQUssU0FBUztJQUNwRCxVQUFVLElBQUk7R0FDaEI7R0FDQSxLQUFLLE9BQU8sS0FBSyxXQUFXLEtBQUs7R0FDakMsY0FBYyxJQUFJO0dBQ2xCLEtBQUssVUFBVSxLQUFLLE9BQU87R0FDM0IsS0FBSyxTQUFTLENBQUM7RUFDakI7Q0FDRjtDQUNBLFVBQVU7RUFDUixJQUFJLEtBQUssUUFBUSxJQUFJO0dBQ25CLG1CQUFtQixJQUFJLElBQUk7RUFDN0IsT0FBTyxJQUFJLEtBQUssV0FBVztHQUN6QixLQUFLLFVBQVU7RUFDakIsT0FBTztHQUNMLEtBQUssV0FBVztFQUNsQjtDQUNGOzs7O0NBSUEsYUFBYTtFQUNYLElBQUksUUFBUSxJQUFJLEdBQUc7R0FDakIsS0FBSyxJQUFJO0VBQ1g7Q0FDRjtDQUNBLElBQUksUUFBUTtFQUNWLE9BQU8sUUFBUSxJQUFJO0NBQ3JCO0FBQ0Y7QUFDQSxJQUFJLGFBQWE7QUFDakIsSUFBSTtBQUNKLElBQUk7QUFDSixTQUFTLE1BQU0sS0FBSyxhQUFhLE9BQU87Q0FDdEMsSUFBSSxTQUFTO0NBQ2IsSUFBSSxZQUFZO0VBQ2QsSUFBSSxPQUFPO0VBQ1gsa0JBQWtCO0VBQ2xCO0NBQ0Y7Q0FDQSxJQUFJLE9BQU87Q0FDWCxhQUFhO0FBQ2Y7QUFDQSxTQUFTLGFBQWE7Q0FDcEI7QUFDRjtBQUNBLFNBQVMsV0FBVztDQUNsQixJQUFJLEVBQUUsYUFBYSxHQUFHO0VBQ3BCO0NBQ0Y7Q0FDQSxJQUFJLGlCQUFpQjtFQUNuQixJQUFJLElBQUk7RUFDUixrQkFBa0IsS0FBSztFQUN2QixPQUFPLEdBQUc7R0FDUixNQUFNLE9BQU8sRUFBRTtHQUNmLEVBQUUsT0FBTyxLQUFLO0dBQ2QsRUFBRSxTQUFTLENBQUM7R0FDWixJQUFJO0VBQ047Q0FDRjtDQUNBLElBQUk7Q0FDSixPQUFPLFlBQVk7RUFDakIsSUFBSSxJQUFJO0VBQ1IsYUFBYSxLQUFLO0VBQ2xCLE9BQU8sR0FBRztHQUNSLE1BQU0sT0FBTyxFQUFFO0dBQ2YsRUFBRSxPQUFPLEtBQUs7R0FDZCxFQUFFLFNBQVMsQ0FBQztHQUNaLElBQUksRUFBRSxRQUFRLEdBQUc7SUFDZixJQUFJO0tBQ0Y7S0FDQSxFQUFFLFFBQVE7SUFDWixTQUFTLEtBQUs7S0FDWixJQUFJLENBQUMsT0FBTyxRQUFRO0lBQ3RCO0dBQ0Y7R0FDQSxJQUFJO0VBQ047Q0FDRjtDQUNBLElBQUksT0FBTyxNQUFNO0FBQ25CO0FBQ0EsU0FBUyxZQUFZLEtBQUs7Q0FDeEIsS0FBSyxJQUFJLE9BQU8sSUFBSSxNQUFNLE1BQU0sT0FBTyxLQUFLLFNBQVM7RUFDbkQsS0FBSyxVQUFVLENBQUM7RUFDaEIsS0FBSyxpQkFBaUIsS0FBSyxJQUFJO0VBQy9CLEtBQUssSUFBSSxhQUFhO0NBQ3hCO0FBQ0Y7QUFDQSxTQUFTLFlBQVksS0FBSztDQUN4QixJQUFJO0NBQ0osSUFBSSxPQUFPLElBQUk7Q0FDZixJQUFJLE9BQU87Q0FDWCxPQUFPLE1BQU07RUFDWCxNQUFNLE9BQU8sS0FBSztFQUNsQixJQUFJLEtBQUssWUFBWSxDQUFDLEdBQUc7R0FDdkIsSUFBSSxTQUFTLE1BQU0sT0FBTztHQUMxQixVQUFVLElBQUk7R0FDZCxVQUFVLElBQUk7RUFDaEIsT0FBTztHQUNMLE9BQU87RUFDVDtFQUNBLEtBQUssSUFBSSxhQUFhLEtBQUs7RUFDM0IsS0FBSyxpQkFBaUIsS0FBSztFQUMzQixPQUFPO0NBQ1Q7Q0FDQSxJQUFJLE9BQU87Q0FDWCxJQUFJLFdBQVc7QUFDakI7QUFDQSxTQUFTLFFBQVEsS0FBSztDQUNwQixLQUFLLElBQUksT0FBTyxJQUFJLE1BQU0sTUFBTSxPQUFPLEtBQUssU0FBUztFQUNuRCxJQUFJLEtBQUssSUFBSSxZQUFZLEtBQUssV0FBVyxLQUFLLElBQUksYUFBYSxnQkFBZ0IsS0FBSyxJQUFJLFFBQVEsS0FBSyxLQUFLLElBQUksWUFBWSxLQUFLLFVBQVU7R0FDdkksT0FBTztFQUNUO0NBQ0Y7Q0FDQSxJQUFJLElBQUksUUFBUTtFQUNkLE9BQU87Q0FDVDtDQUNBLE9BQU87QUFDVDtBQUNBLFNBQVMsZ0JBQWdCLFVBQVU7Q0FDakMsSUFBSSxTQUFTLFFBQVEsS0FBSyxFQUFFLFNBQVMsUUFBUSxLQUFLO0VBQ2hEO0NBQ0Y7Q0FDQSxTQUFTLFNBQVMsQ0FBQztDQUNuQixJQUFJLFNBQVMsa0JBQWtCLGVBQWU7RUFDNUM7Q0FDRjtDQUNBLFNBQVMsZ0JBQWdCO0NBQ3pCLElBQUksQ0FBQyxTQUFTLFNBQVMsU0FBUyxRQUFRLFFBQVEsQ0FBQyxTQUFTLFFBQVEsQ0FBQyxTQUFTLFVBQVUsQ0FBQyxRQUFRLFFBQVEsSUFBSTtFQUN6RztDQUNGO0NBQ0EsU0FBUyxTQUFTO0NBQ2xCLE1BQU0sTUFBTSxTQUFTO0NBQ3JCLE1BQU0sVUFBVTtDQUNoQixNQUFNLGtCQUFrQjtDQUN4QixZQUFZO0NBQ1osY0FBYztDQUNkLElBQUk7RUFDRixZQUFZLFFBQVE7RUFDcEIsTUFBTSxRQUFRLFNBQVMsR0FBRyxTQUFTLE1BQU07RUFDekMsSUFBSSxJQUFJLFlBQVksS0FBSyxXQUFXLE9BQU8sU0FBUyxNQUFNLEdBQUc7R0FDM0QsU0FBUyxTQUFTO0dBQ2xCLFNBQVMsU0FBUztHQUNsQixJQUFJO0VBQ047Q0FDRixTQUFTLEtBQUs7RUFDWixJQUFJO0VBQ0osTUFBTTtDQUNSLFVBQVU7RUFDUixZQUFZO0VBQ1osY0FBYztFQUNkLFlBQVksUUFBUTtFQUNwQixTQUFTLFNBQVMsQ0FBQztDQUNyQjtBQUNGO0FBQ0EsU0FBUyxVQUFVLE1BQU0sT0FBTyxPQUFPO0NBQ3JDLE1BQU0sRUFBRSxLQUFLLFNBQVMsWUFBWTtDQUNsQyxJQUFJLFNBQVM7RUFDWCxRQUFRLFVBQVU7RUFDbEIsS0FBSyxVQUFVLEtBQUs7Q0FDdEI7Q0FDQSxJQUFJLFNBQVM7RUFDWCxRQUFRLFVBQVU7RUFDbEIsS0FBSyxVQUFVLEtBQUs7Q0FDdEI7Q0FDQSxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixJQUFJLGFBQWEsTUFBTTtFQUN0RSxJQUFJLFdBQVc7Q0FDakI7Q0FDQSxJQUFJLElBQUksU0FBUyxNQUFNO0VBQ3JCLElBQUksT0FBTztFQUNYLElBQUksQ0FBQyxXQUFXLElBQUksVUFBVTtHQUM1QixJQUFJLFNBQVMsU0FBUyxDQUFDO0dBQ3ZCLEtBQUssSUFBSSxJQUFJLElBQUksU0FBUyxNQUFNLEdBQUcsSUFBSSxFQUFFLFNBQVM7SUFDaEQsVUFBVSxHQUFHLElBQUk7R0FDbkI7RUFDRjtDQUNGO0NBQ0EsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLElBQUksTUFBTSxJQUFJLEtBQUs7RUFDakMsSUFBSSxJQUFJLE9BQU8sSUFBSSxHQUFHO0NBQ3hCO0FBQ0Y7QUFDQSxTQUFTLFVBQVUsTUFBTTtDQUN2QixNQUFNLEVBQUUsU0FBUyxZQUFZO0NBQzdCLElBQUksU0FBUztFQUNYLFFBQVEsVUFBVTtFQUNsQixLQUFLLFVBQVUsS0FBSztDQUN0QjtDQUNBLElBQUksU0FBUztFQUNYLFFBQVEsVUFBVTtFQUNsQixLQUFLLFVBQVUsS0FBSztDQUN0QjtBQUNGO0FBQ0EsU0FBUyxPQUFPLElBQUksU0FBUztDQUMzQixJQUFJLEdBQUcsa0JBQWtCLGdCQUFnQjtFQUN2QyxLQUFLLEdBQUcsT0FBTztDQUNqQjtDQUNBLE1BQU0sSUFBSSxJQUFJLGVBQWUsRUFBRTtDQUMvQixJQUFJLFNBQVM7RUFDWCxPQUFPLEdBQUcsT0FBTztDQUNuQjtDQUNBLElBQUk7RUFDRixFQUFFLElBQUk7Q0FDUixTQUFTLEtBQUs7RUFDWixFQUFFLEtBQUs7RUFDUCxNQUFNO0NBQ1I7Q0FDQSxNQUFNLFNBQVMsRUFBRSxJQUFJLEtBQUssQ0FBQztDQUMzQixPQUFPLFNBQVM7Q0FDaEIsT0FBTztBQUNUO0FBQ0EsU0FBUyxLQUFLLFFBQVE7Q0FDcEIsT0FBTyxPQUFPLEtBQUs7QUFDckI7QUFDQSxJQUFJLGNBQWM7QUFDbEIsTUFBTSxhQUFhLENBQUM7QUFDcEIsU0FBUyxnQkFBZ0I7Q0FDdkIsV0FBVyxLQUFLLFdBQVc7Q0FDM0IsY0FBYztBQUNoQjtBQUNBLFNBQVMsaUJBQWlCO0NBQ3hCLFdBQVcsS0FBSyxXQUFXO0NBQzNCLGNBQWM7QUFDaEI7QUFDQSxTQUFTLGdCQUFnQjtDQUN2QixNQUFNLE9BQU8sV0FBVyxJQUFJO0NBQzVCLGNBQWMsU0FBUyxLQUFLLElBQUksT0FBTztBQUN6QztBQUNBLFNBQVMsZ0JBQWdCLElBQUksZUFBZSxPQUFPO0NBQ2pELElBQUkscUJBQXFCLGdCQUFnQjtFQUN2QyxVQUFVLFVBQVU7Q0FDdEIsT0FBTyxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixDQUFDLGNBQWM7RUFDckUsS0FDRSxpRkFDRjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLGNBQWMsR0FBRztDQUN4QixNQUFNLEVBQUUsWUFBWTtDQUNwQixFQUFFLFVBQVUsS0FBSztDQUNqQixJQUFJLFNBQVM7RUFDWCxNQUFNLFVBQVU7RUFDaEIsWUFBWSxLQUFLO0VBQ2pCLElBQUk7R0FDRixRQUFRO0VBQ1YsVUFBVTtHQUNSLFlBQVk7RUFDZDtDQUNGO0FBQ0Y7QUFFQSxJQUFJLGdCQUFnQjtBQUNwQixNQUFNLEtBQUs7Q0FDVCxZQUFZLEtBQUssS0FBSztFQUNwQixLQUFLLE1BQU07RUFDWCxLQUFLLE1BQU07RUFDWCxLQUFLLFVBQVUsSUFBSTtFQUNuQixLQUFLLFVBQVUsS0FBSyxVQUFVLEtBQUssVUFBVSxLQUFLLFVBQVUsS0FBSyxpQkFBaUIsS0FBSztDQUN6RjtBQUNGO0FBQ0EsTUFBTSxJQUFJOztDQUVSLFlBQVksVUFBVTtFQUNwQixLQUFLLFdBQVc7RUFDaEIsS0FBSyxVQUFVOzs7O0VBSWYsS0FBSyxhQUFhLEtBQUs7Ozs7RUFJdkIsS0FBSyxPQUFPLEtBQUs7Ozs7RUFJakIsS0FBSyxNQUFNLEtBQUs7RUFDaEIsS0FBSyxNQUFNLEtBQUs7Ozs7RUFJaEIsS0FBSyxLQUFLOzs7O0VBSVYsS0FBSyxXQUFXO0VBQ2hCLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtHQUM3QyxLQUFLLFdBQVcsS0FBSztFQUN2QjtDQUNGO0NBQ0EsTUFBTSxXQUFXO0VBQ2YsSUFBSSxDQUFDLGFBQWEsQ0FBQyxlQUFlLGNBQWMsS0FBSyxVQUFVO0dBQzdEO0VBQ0Y7RUFDQSxJQUFJLE9BQU8sS0FBSztFQUNoQixJQUFJLFNBQVMsS0FBSyxLQUFLLEtBQUssUUFBUSxXQUFXO0dBQzdDLE9BQU8sS0FBSyxhQUFhLElBQUksS0FBSyxXQUFXLElBQUk7R0FDakQsSUFBSSxDQUFDLFVBQVUsTUFBTTtJQUNuQixVQUFVLE9BQU8sVUFBVSxXQUFXO0dBQ3hDLE9BQU87SUFDTCxLQUFLLFVBQVUsVUFBVTtJQUN6QixVQUFVLFNBQVMsVUFBVTtJQUM3QixVQUFVLFdBQVc7R0FDdkI7R0FDQSxPQUFPLElBQUk7RUFDYixPQUFPLElBQUksS0FBSyxZQUFZLENBQUMsR0FBRztHQUM5QixLQUFLLFVBQVUsS0FBSztHQUNwQixJQUFJLEtBQUssU0FBUztJQUNoQixNQUFNLE9BQU8sS0FBSztJQUNsQixLQUFLLFVBQVUsS0FBSztJQUNwQixJQUFJLEtBQUssU0FBUztLQUNoQixLQUFLLFFBQVEsVUFBVTtJQUN6QjtJQUNBLEtBQUssVUFBVSxVQUFVO0lBQ3pCLEtBQUssVUFBVSxLQUFLO0lBQ3BCLFVBQVUsU0FBUyxVQUFVO0lBQzdCLFVBQVUsV0FBVztJQUNyQixJQUFJLFVBQVUsU0FBUyxNQUFNO0tBQzNCLFVBQVUsT0FBTztJQUNuQjtHQUNGO0VBQ0Y7RUFDQSxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixVQUFVLFNBQVM7R0FDbEUsVUFBVSxRQUNSLE9BQ0UsRUFDRSxRQUFRLFVBQ1YsR0FDQSxTQUNGLENBQ0Y7RUFDRjtFQUNBLE9BQU87Q0FDVDtDQUNBLFFBQVEsV0FBVztFQUNqQixLQUFLO0VBQ0w7RUFDQSxLQUFLLE9BQU8sU0FBUztDQUN2QjtDQUNBLE9BQU8sV0FBVztFQUNoQixXQUFXO0VBQ1gsSUFBSTtHQUNGLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtJQUM3QyxLQUFLLElBQUksT0FBTyxLQUFLLFVBQVUsTUFBTSxPQUFPLEtBQUssU0FBUztLQUN4RCxJQUFJLEtBQUssSUFBSSxhQUFhLEVBQUUsS0FBSyxJQUFJLFFBQVEsSUFBSTtNQUMvQyxLQUFLLElBQUksVUFDUCxPQUNFLEVBQ0UsUUFBUSxLQUFLLElBQ2YsR0FDQSxTQUNGLENBQ0Y7S0FDRjtJQUNGO0dBQ0Y7R0FDQSxLQUFLLElBQUksT0FBTyxLQUFLLE1BQU0sTUFBTSxPQUFPLEtBQUssU0FBUztJQUNwRCxJQUFJLEtBQUssSUFBSSxPQUFPLEdBQUc7S0FDckI7S0FDQSxLQUFLLElBQUksSUFBSSxPQUFPO0lBQ3RCO0dBQ0Y7RUFDRixVQUFVO0dBQ1IsU0FBUztFQUNYO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsT0FBTyxNQUFNO0NBQ3BCLEtBQUssSUFBSTtDQUNULElBQUksS0FBSyxJQUFJLFFBQVEsR0FBRztFQUN0QixNQUFNLFdBQVcsS0FBSyxJQUFJO0VBQzFCLElBQUksWUFBWSxDQUFDLEtBQUssSUFBSSxNQUFNO0dBQzlCLFNBQVMsU0FBUyxJQUFJO0dBQ3RCLEtBQUssSUFBSSxJQUFJLFNBQVMsTUFBTSxHQUFHLElBQUksRUFBRSxTQUFTO0lBQzVDLE9BQU8sQ0FBQztHQUNWO0VBQ0Y7RUFDQSxNQUFNLGNBQWMsS0FBSyxJQUFJO0VBQzdCLElBQUksZ0JBQWdCLE1BQU07R0FDeEIsS0FBSyxVQUFVO0dBQ2YsSUFBSSxhQUFhLFlBQVksVUFBVTtFQUN6QztFQUNBLElBQUksQ0FBQyxvQkFBMkIsaUJBQWlCLEtBQUssSUFBSSxhQUFhLEtBQUssR0FBRztHQUM3RSxLQUFLLElBQUksV0FBVztFQUN0QjtFQUNBLEtBQUssSUFBSSxPQUFPO0NBQ2xCO0FBQ0Y7QUFDQSxNQUFNLDRCQUE0QixJQUFJLFFBQVE7QUFDOUMsTUFBTSxjQUE4Qix1QkFDbEMsQ0FBQyxvQkFBMkIsZ0JBQWdCLG1CQUFtQixFQUNqRTtBQUNBLE1BQU0sc0JBQXNDLHVCQUMxQyxDQUFDLG9CQUEyQixnQkFBZ0IscUJBQXFCLEVBQ25FO0FBQ0EsTUFBTSxvQkFBb0MsdUJBQ3hDLENBQUMsb0JBQTJCLGdCQUFnQixrQkFBa0IsRUFDaEU7QUFDQSxTQUFTLE1BQU0sUUFBUSxNQUFNLEtBQUs7Q0FDaEMsSUFBSSxlQUFlLFdBQVc7RUFDNUIsSUFBSSxVQUFVLFVBQVUsSUFBSSxNQUFNO0VBQ2xDLElBQUksQ0FBQyxTQUFTO0dBQ1osVUFBVSxJQUFJLFFBQVEsMEJBQTBCLElBQUksSUFBSSxDQUFDO0VBQzNEO0VBQ0EsSUFBSSxNQUFNLFFBQVEsSUFBSSxHQUFHO0VBQ3pCLElBQUksQ0FBQyxLQUFLO0dBQ1IsUUFBUSxJQUFJLEtBQUssTUFBTSxJQUFJLElBQUksQ0FBQztHQUNoQyxJQUFJLE1BQU07R0FDVixJQUFJLE1BQU07RUFDWjtFQUNBLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtHQUM3QyxJQUFJLE1BQU07SUFDUjtJQUNBO0lBQ0E7R0FDRixDQUFDO0VBQ0gsT0FBTztHQUNMLElBQUksTUFBTTtFQUNaO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsUUFBUSxRQUFRLE1BQU0sS0FBSyxVQUFVLFVBQVUsV0FBVztDQUNqRSxNQUFNLFVBQVUsVUFBVSxJQUFJLE1BQU07Q0FDcEMsSUFBSSxDQUFDLFNBQVM7RUFDWjtFQUNBO0NBQ0Y7Q0FDQSxNQUFNLE9BQU8sUUFBUTtFQUNuQixJQUFJLEtBQUs7R0FDUCxJQUFJLENBQUMsb0JBQTJCLGVBQWU7SUFDN0MsSUFBSSxRQUFRO0tBQ1Y7S0FDQTtLQUNBO0tBQ0E7S0FDQTtLQUNBO0lBQ0YsQ0FBQztHQUNILE9BQU87SUFDTCxJQUFJLFFBQVE7R0FDZDtFQUNGO0NBQ0Y7Q0FDQSxXQUFXO0NBQ1gsSUFBSSxTQUFTLFNBQVM7RUFDcEIsUUFBUSxRQUFRLEdBQUc7Q0FDckIsT0FBTztFQUNMLE1BQU0sZ0JBQWdCLFFBQVEsTUFBTTtFQUNwQyxNQUFNLGVBQWUsaUJBQWlCLGFBQWEsR0FBRztFQUN0RCxJQUFJLGlCQUFpQixRQUFRLFVBQVU7R0FDckMsTUFBTSxZQUFZLE9BQU8sUUFBUTtHQUNqQyxRQUFRLFNBQVMsS0FBSyxTQUFTO0lBQzdCLElBQUksU0FBUyxZQUFZLFNBQVMscUJBQXFCLENBQUMsU0FBUyxJQUFJLEtBQUssUUFBUSxXQUFXO0tBQzNGLElBQUksR0FBRztJQUNUO0dBQ0YsQ0FBQztFQUNILE9BQU87R0FDTCxJQUFJLFFBQVEsS0FBSyxLQUFLLFFBQVEsSUFBSSxLQUFLLENBQUMsR0FBRztJQUN6QyxJQUFJLFFBQVEsSUFBSSxHQUFHLENBQUM7R0FDdEI7R0FDQSxJQUFJLGNBQWM7SUFDaEIsSUFBSSxRQUFRLElBQUksaUJBQWlCLENBQUM7R0FDcEM7R0FDQSxRQUFRLE1BQVI7SUFDRSxLQUFLO0tBQ0gsSUFBSSxDQUFDLGVBQWU7TUFDbEIsSUFBSSxRQUFRLElBQUksV0FBVyxDQUFDO01BQzVCLElBQUksTUFBTSxNQUFNLEdBQUc7T0FDakIsSUFBSSxRQUFRLElBQUksbUJBQW1CLENBQUM7TUFDdEM7S0FDRixPQUFPLElBQUksY0FBYztNQUN2QixJQUFJLFFBQVEsSUFBSSxRQUFRLENBQUM7S0FDM0I7S0FDQTtJQUNGLEtBQUs7S0FDSCxJQUFJLENBQUMsZUFBZTtNQUNsQixJQUFJLFFBQVEsSUFBSSxXQUFXLENBQUM7TUFDNUIsSUFBSSxNQUFNLE1BQU0sR0FBRztPQUNqQixJQUFJLFFBQVEsSUFBSSxtQkFBbUIsQ0FBQztNQUN0QztLQUNGO0tBQ0E7SUFDRixLQUFLO0tBQ0gsSUFBSSxNQUFNLE1BQU0sR0FBRztNQUNqQixJQUFJLFFBQVEsSUFBSSxXQUFXLENBQUM7S0FDOUI7S0FDQTtHQUNKO0VBQ0Y7Q0FDRjtDQUNBLFNBQVM7QUFDWDtBQUNBLFNBQVMsbUJBQW1CLFFBQVEsS0FBSztDQUN2QyxNQUFNLFNBQVMsVUFBVSxJQUFJLE1BQU07Q0FDbkMsT0FBTyxVQUFVLE9BQU8sSUFBSSxHQUFHO0FBQ2pDO0FBRUEsU0FBUyxrQkFBa0IsT0FBTztDQUNoQyxNQUFNLE1BQU0sTUFBTSxLQUFLO0NBQ3ZCLElBQUksUUFBUSxPQUFPLE9BQU87Q0FDMUIsTUFBTSxLQUFLLFdBQVcsaUJBQWlCO0NBQ3ZDLE9BQU8sVUFBVSxLQUFLLElBQUksTUFBTSxJQUFJLElBQUksVUFBVTtBQUNwRDtBQUNBLFNBQVMsaUJBQWlCLEtBQUs7Q0FDN0IsTUFBTSxNQUFNLE1BQU0sR0FBRyxHQUFHLFdBQVcsaUJBQWlCO0NBQ3BELE9BQU87QUFDVDtBQUNBLFNBQVMsVUFBVSxRQUFRLE1BQU07Q0FDL0IsSUFBSSxXQUFXLE1BQU0sR0FBRztFQUN0QixPQUFPLFdBQVcsTUFBTSxJQUFJLFdBQVcsV0FBVyxJQUFJLENBQUMsSUFBSSxXQUFXLElBQUk7Q0FDNUU7Q0FDQSxPQUFPLFdBQVcsSUFBSTtBQUN4QjtBQUNBLE1BQU0sd0JBQXdCO0NBQzVCLFdBQVc7Q0FDWCxDQUFDLE9BQU8sWUFBWTtFQUNsQixPQUFPLFNBQVMsTUFBTSxPQUFPLFdBQVcsU0FBUyxVQUFVLE1BQU0sSUFBSSxDQUFDO0NBQ3hFO0NBQ0EsT0FBTyxHQUFHLE1BQU07RUFDZCxPQUFPLGtCQUFrQixJQUFJLENBQUMsQ0FBQyxPQUM3QixHQUFHLEtBQUssS0FBSyxNQUFNLFFBQVEsQ0FBQyxJQUFJLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUMxRDtDQUNGO0NBQ0EsVUFBVTtFQUNSLE9BQU8sU0FBUyxNQUFNLFlBQVksVUFBVTtHQUMxQyxNQUFNLEtBQUssVUFBVSxNQUFNLE1BQU0sRUFBRTtHQUNuQyxPQUFPO0VBQ1QsQ0FBQztDQUNIO0NBQ0EsTUFBTSxJQUFJLFNBQVM7RUFDakIsT0FBTyxNQUFNLE1BQU0sU0FBUyxJQUFJLFNBQVMsS0FBSyxHQUFHLFNBQVM7Q0FDNUQ7Q0FDQSxPQUFPLElBQUksU0FBUztFQUNsQixPQUFPLE1BQ0wsTUFDQSxVQUNBLElBQ0EsVUFDQyxNQUFNLEVBQUUsS0FBSyxTQUFTLFVBQVUsTUFBTSxJQUFJLENBQUMsR0FDNUMsU0FDRjtDQUNGO0NBQ0EsS0FBSyxJQUFJLFNBQVM7RUFDaEIsT0FBTyxNQUNMLE1BQ0EsUUFDQSxJQUNBLFVBQ0MsU0FBUyxVQUFVLE1BQU0sSUFBSSxHQUM5QixTQUNGO0NBQ0Y7Q0FDQSxVQUFVLElBQUksU0FBUztFQUNyQixPQUFPLE1BQU0sTUFBTSxhQUFhLElBQUksU0FBUyxLQUFLLEdBQUcsU0FBUztDQUNoRTtDQUNBLFNBQVMsSUFBSSxTQUFTO0VBQ3BCLE9BQU8sTUFDTCxNQUNBLFlBQ0EsSUFDQSxVQUNDLFNBQVMsVUFBVSxNQUFNLElBQUksR0FDOUIsU0FDRjtDQUNGO0NBQ0EsY0FBYyxJQUFJLFNBQVM7RUFDekIsT0FBTyxNQUFNLE1BQU0saUJBQWlCLElBQUksU0FBUyxLQUFLLEdBQUcsU0FBUztDQUNwRTs7Q0FFQSxRQUFRLElBQUksU0FBUztFQUNuQixPQUFPLE1BQU0sTUFBTSxXQUFXLElBQUksU0FBUyxLQUFLLEdBQUcsU0FBUztDQUM5RDtDQUNBLFNBQVMsR0FBRyxNQUFNO0VBQ2hCLE9BQU8sWUFBWSxNQUFNLFlBQVksSUFBSTtDQUMzQztDQUNBLFFBQVEsR0FBRyxNQUFNO0VBQ2YsT0FBTyxZQUFZLE1BQU0sV0FBVyxJQUFJO0NBQzFDO0NBQ0EsS0FBSyxXQUFXO0VBQ2QsT0FBTyxrQkFBa0IsSUFBSSxDQUFDLENBQUMsS0FBSyxTQUFTO0NBQy9DOztDQUVBLFlBQVksR0FBRyxNQUFNO0VBQ25CLE9BQU8sWUFBWSxNQUFNLGVBQWUsSUFBSTtDQUM5QztDQUNBLElBQUksSUFBSSxTQUFTO0VBQ2YsT0FBTyxNQUFNLE1BQU0sT0FBTyxJQUFJLFNBQVMsS0FBSyxHQUFHLFNBQVM7Q0FDMUQ7Q0FDQSxNQUFNO0VBQ0osT0FBTyxXQUFXLE1BQU0sS0FBSztDQUMvQjtDQUNBLEtBQUssR0FBRyxNQUFNO0VBQ1osT0FBTyxXQUFXLE1BQU0sUUFBUSxJQUFJO0NBQ3RDO0NBQ0EsT0FBTyxJQUFJLEdBQUcsTUFBTTtFQUNsQixPQUFPLE9BQU8sTUFBTSxVQUFVLElBQUksSUFBSTtDQUN4QztDQUNBLFlBQVksSUFBSSxHQUFHLE1BQU07RUFDdkIsT0FBTyxPQUFPLE1BQU0sZUFBZSxJQUFJLElBQUk7Q0FDN0M7Q0FDQSxRQUFRO0VBQ04sT0FBTyxXQUFXLE1BQU0sT0FBTztDQUNqQzs7Q0FFQSxLQUFLLElBQUksU0FBUztFQUNoQixPQUFPLE1BQU0sTUFBTSxRQUFRLElBQUksU0FBUyxLQUFLLEdBQUcsU0FBUztDQUMzRDtDQUNBLE9BQU8sR0FBRyxNQUFNO0VBQ2QsT0FBTyxXQUFXLE1BQU0sVUFBVSxJQUFJO0NBQ3hDO0NBQ0EsYUFBYTtFQUNYLE9BQU8sa0JBQWtCLElBQUksQ0FBQyxDQUFDLFdBQVc7Q0FDNUM7Q0FDQSxTQUFTLFVBQVU7RUFDakIsT0FBTyxrQkFBa0IsSUFBSSxDQUFDLENBQUMsU0FBUyxRQUFRO0NBQ2xEO0NBQ0EsVUFBVSxHQUFHLE1BQU07RUFDakIsT0FBTyxrQkFBa0IsSUFBSSxDQUFDLENBQUMsVUFBVSxHQUFHLElBQUk7Q0FDbEQ7Q0FDQSxRQUFRLEdBQUcsTUFBTTtFQUNmLE9BQU8sV0FBVyxNQUFNLFdBQVcsSUFBSTtDQUN6QztDQUNBLFNBQVM7RUFDUCxPQUFPLFNBQVMsTUFBTSxXQUFXLFNBQVMsVUFBVSxNQUFNLElBQUksQ0FBQztDQUNqRTtBQUNGO0FBQ0EsU0FBUyxTQUFTLE1BQU0sUUFBUSxXQUFXO0NBQ3pDLE1BQU0sTUFBTSxpQkFBaUIsSUFBSTtDQUNqQyxNQUFNLE9BQU8sSUFBSSxPQUFPLENBQUM7Q0FDekIsSUFBSSxRQUFRLFFBQVEsQ0FBQyxVQUFVLElBQUksR0FBRztFQUNwQyxLQUFLLFFBQVEsS0FBSztFQUNsQixLQUFLLGFBQWE7R0FDaEIsTUFBTSxTQUFTLEtBQUssTUFBTTtHQUMxQixJQUFJLENBQUMsT0FBTyxNQUFNO0lBQ2hCLE9BQU8sUUFBUSxVQUFVLE9BQU8sS0FBSztHQUN2QztHQUNBLE9BQU87RUFDVDtDQUNGO0NBQ0EsT0FBTztBQUNUO0FBQ0EsTUFBTSxhQUFhLE1BQU07QUFDekIsU0FBUyxNQUFNLE1BQU0sUUFBUSxJQUFJLFNBQVMsY0FBYyxNQUFNO0NBQzVELE1BQU0sTUFBTSxpQkFBaUIsSUFBSTtDQUNqQyxNQUFNLFlBQVksUUFBUSxRQUFRLENBQUMsVUFBVSxJQUFJO0NBQ2pELE1BQU0sV0FBVyxJQUFJO0NBQ3JCLElBQUksYUFBYSxXQUFXLFNBQVM7RUFDbkMsTUFBTSxVQUFVLFNBQVMsTUFBTSxNQUFNLElBQUk7RUFDekMsT0FBTyxZQUFZLFdBQVcsT0FBTyxJQUFJO0NBQzNDO0NBQ0EsSUFBSSxZQUFZO0NBQ2hCLElBQUksUUFBUSxNQUFNO0VBQ2hCLElBQUksV0FBVztHQUNiLFlBQVksU0FBUyxNQUFNLE9BQU87SUFDaEMsT0FBTyxHQUFHLEtBQUssTUFBTSxVQUFVLE1BQU0sSUFBSSxHQUFHLE9BQU8sSUFBSTtHQUN6RDtFQUNGLE9BQU8sSUFBSSxHQUFHLFNBQVMsR0FBRztHQUN4QixZQUFZLFNBQVMsTUFBTSxPQUFPO0lBQ2hDLE9BQU8sR0FBRyxLQUFLLE1BQU0sTUFBTSxPQUFPLElBQUk7R0FDeEM7RUFDRjtDQUNGO0NBQ0EsTUFBTSxTQUFTLFNBQVMsS0FBSyxLQUFLLFdBQVcsT0FBTztDQUNwRCxPQUFPLGFBQWEsZUFBZSxhQUFhLE1BQU0sSUFBSTtBQUM1RDtBQUNBLFNBQVMsT0FBTyxNQUFNLFFBQVEsSUFBSSxNQUFNO0NBQ3RDLE1BQU0sTUFBTSxpQkFBaUIsSUFBSTtDQUNqQyxNQUFNLFlBQVksUUFBUSxRQUFRLENBQUMsVUFBVSxJQUFJO0NBQ2pELElBQUksWUFBWTtDQUNoQixJQUFJLHlCQUF5QjtDQUM3QixJQUFJLFFBQVEsTUFBTTtFQUNoQixJQUFJLFdBQVc7R0FDYix5QkFBeUIsS0FBSyxXQUFXO0dBQ3pDLFlBQVksU0FBUyxLQUFLLE1BQU0sT0FBTztJQUNyQyxJQUFJLHdCQUF3QjtLQUMxQix5QkFBeUI7S0FDekIsTUFBTSxVQUFVLE1BQU0sR0FBRztJQUMzQjtJQUNBLE9BQU8sR0FBRyxLQUFLLE1BQU0sS0FBSyxVQUFVLE1BQU0sSUFBSSxHQUFHLE9BQU8sSUFBSTtHQUM5RDtFQUNGLE9BQU8sSUFBSSxHQUFHLFNBQVMsR0FBRztHQUN4QixZQUFZLFNBQVMsS0FBSyxNQUFNLE9BQU87SUFDckMsT0FBTyxHQUFHLEtBQUssTUFBTSxLQUFLLE1BQU0sT0FBTyxJQUFJO0dBQzdDO0VBQ0Y7Q0FDRjtDQUNBLE1BQU0sU0FBUyxJQUFJLE9BQU8sQ0FBQyxXQUFXLEdBQUcsSUFBSTtDQUM3QyxPQUFPLHlCQUF5QixVQUFVLE1BQU0sTUFBTSxJQUFJO0FBQzVEO0FBQ0EsU0FBUyxZQUFZLE1BQU0sUUFBUSxNQUFNO0NBQ3ZDLE1BQU0sTUFBTSxNQUFNLElBQUk7Q0FDdEIsTUFBTSxLQUFLLFdBQVcsaUJBQWlCO0NBQ3ZDLE1BQU0sTUFBTSxJQUFJLE9BQU8sQ0FBQyxHQUFHLElBQUk7Q0FDL0IsS0FBSyxRQUFRLENBQUMsS0FBSyxRQUFRLFVBQVUsUUFBUSxLQUFLLEVBQUUsR0FBRztFQUNyRCxLQUFLLEtBQUssTUFBTSxLQUFLLEVBQUU7RUFDdkIsT0FBTyxJQUFJLE9BQU8sQ0FBQyxHQUFHLElBQUk7Q0FDNUI7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLFdBQVcsTUFBTSxRQUFRLE9BQU8sQ0FBQyxHQUFHO0NBQzNDLGNBQWM7Q0FDZCxXQUFXO0NBQ1gsTUFBTSxNQUFNLE1BQU0sSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sTUFBTSxJQUFJO0NBQ2hELFNBQVM7Q0FDVCxjQUFjO0NBQ2QsT0FBTztBQUNUO0FBRUEsTUFBTSxxQkFBcUMsd0JBQVEsNkJBQTZCO0FBQ2hGLE1BQU0saUJBQWlCLElBQUksSUFDVCx1QkFBTyxvQkFBb0IsTUFBTSxDQUFDLENBQUMsUUFBUSxRQUFRLFFBQVEsZUFBZSxRQUFRLFFBQVEsQ0FBQyxDQUFDLEtBQUssUUFBUSxPQUFPLElBQUksQ0FBQyxDQUFDLE9BQU8sUUFBUSxDQUN2SjtBQUNBLFNBQVMsZUFBZSxLQUFLO0NBQzNCLElBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxNQUFNLE9BQU8sR0FBRztDQUNwQyxNQUFNLE1BQU0sTUFBTSxJQUFJO0NBQ3RCLE1BQU0sS0FBSyxPQUFPLEdBQUc7Q0FDckIsT0FBTyxJQUFJLGVBQWUsR0FBRztBQUMvQjtBQUNBLE1BQU0sb0JBQW9CO0NBQ3hCLFlBQVksY0FBYyxPQUFPLGFBQWEsT0FBTztFQUNuRCxLQUFLLGNBQWM7RUFDbkIsS0FBSyxhQUFhO0NBQ3BCO0NBQ0EsSUFBSSxRQUFRLEtBQUssVUFBVTtFQUN6QixJQUFJLFFBQVEsWUFBWSxPQUFPLE9BQU87RUFDdEMsTUFBTSxjQUFjLEtBQUssYUFBYSxhQUFhLEtBQUs7RUFDeEQsSUFBSSxRQUFRLGtCQUFrQjtHQUM1QixPQUFPLENBQUM7RUFDVixPQUFPLElBQUksUUFBUSxrQkFBa0I7R0FDbkMsT0FBTztFQUNULE9BQU8sSUFBSSxRQUFRLGlCQUFpQjtHQUNsQyxPQUFPO0VBQ1QsT0FBTyxJQUFJLFFBQVEsV0FBVztHQUM1QixJQUFJLGNBQWMsY0FBYyxhQUFhLHFCQUFxQixjQUFjLGFBQWEscUJBQXFCLFlBQVcsQ0FBRSxJQUFJLE1BQU0sS0FFekksT0FBTyxlQUFlLE1BQU0sTUFBTSxPQUFPLGVBQWUsUUFBUSxHQUFHO0lBQ2pFLE9BQU87R0FDVDtHQUNBO0VBQ0Y7RUFDQSxNQUFNLGdCQUFnQixRQUFRLE1BQU07RUFDcEMsSUFBSSxDQUFDLGFBQWE7R0FDaEIsSUFBSTtHQUNKLElBQUksa0JBQWtCLEtBQUssc0JBQXNCLE9BQU87SUFDdEQsT0FBTztHQUNUO0dBQ0EsSUFBSSxRQUFRLGtCQUFrQjtJQUM1QixPQUFPO0dBQ1Q7RUFDRjtFQUNBLE1BQU0sTUFBTSxRQUFRO0dBQ2xCO0dBQ0E7Ozs7R0FJQSxNQUFNLE1BQU0sSUFBSSxTQUFTO0VBQzNCO0VBQ0EsSUFBSSxTQUFTLEdBQUcsSUFBSSxlQUFlLElBQUksR0FBRyxJQUFJLG1CQUFtQixHQUFHLEdBQUc7R0FDckUsT0FBTztFQUNUO0VBQ0EsSUFBSSxDQUFDLGFBQWE7R0FDaEIsTUFBTSxRQUFRLE9BQU8sR0FBRztFQUMxQjtFQUNBLElBQUksWUFBWTtHQUNkLE9BQU87RUFDVDtFQUNBLElBQUksTUFBTSxHQUFHLEdBQUc7R0FDZCxNQUFNLFFBQVEsaUJBQWlCLGFBQWEsR0FBRyxJQUFJLE1BQU0sSUFBSTtHQUM3RCxPQUFPLGVBQWUsU0FBUyxLQUFLLElBQUksU0FBUyxLQUFLLElBQUk7RUFDNUQ7RUFDQSxJQUFJLFNBQVMsR0FBRyxHQUFHO0dBQ2pCLE9BQU8sY0FBYyxTQUFTLEdBQUcsSUFBSSxTQUFTLEdBQUc7RUFDbkQ7RUFDQSxPQUFPO0NBQ1Q7QUFDRjtBQUNBLE1BQU0sK0JBQStCLG9CQUFvQjtDQUN2RCxZQUFZLGFBQWEsT0FBTztFQUM5QixNQUFNLE9BQU8sVUFBVTtDQUN6QjtDQUNBLElBQUksUUFBUSxLQUFLLE9BQU8sVUFBVTtFQUNoQyxJQUFJLFdBQVcsT0FBTztFQUN0QixNQUFNLHdCQUF3QixRQUFRLE1BQU0sS0FBSyxhQUFhLEdBQUc7RUFDakUsSUFBSSxDQUFDLEtBQUssWUFBWTtHQUNwQixNQUFNLHFCQUFxQixXQUFXLFFBQVE7R0FDOUMsSUFBSSxDQUFDLFVBQVUsS0FBSyxLQUFLLENBQUMsV0FBVyxLQUFLLEdBQUc7SUFDM0MsV0FBVyxNQUFNLFFBQVE7SUFDekIsUUFBUSxNQUFNLEtBQUs7R0FDckI7R0FDQSxJQUFJLENBQUMseUJBQXlCLE1BQU0sUUFBUSxLQUFLLENBQUMsTUFBTSxLQUFLLEdBQUc7SUFDOUQsSUFBSSxvQkFBb0I7S0FDdEIsSUFBSSxDQUFDLG9CQUEyQixlQUFlO01BQzdDLEtBQ0UseUJBQXlCLE9BQU8sR0FBRyxFQUFFLGdDQUNyQyxPQUFPLElBQ1Q7S0FDRjtLQUNBLE9BQU87SUFDVCxPQUFPO0tBQ0wsU0FBUyxRQUFRO0tBQ2pCLE9BQU87SUFDVDtHQUNGO0VBQ0Y7RUFDQSxNQUFNLFNBQVMsd0JBQXdCLE9BQU8sR0FBRyxJQUFJLE9BQU8sU0FBUyxPQUFPLFFBQVEsR0FBRztFQUN2RixNQUFNLFNBQVMsUUFBUSxJQUNyQixRQUNBLEtBQ0EsT0FDQSxNQUFNLE1BQU0sSUFBSSxTQUFTLFFBQzNCO0VBQ0EsSUFBSSxXQUFXLE1BQU0sUUFBUSxLQUFLLFFBQVE7R0FDeEMsSUFBSSxDQUFDLFFBQVE7SUFDWCxRQUFRLFFBQVEsT0FBTyxLQUFLLEtBQUs7R0FDbkMsT0FBTyxJQUFJLFdBQVcsT0FBTyxRQUFRLEdBQUc7SUFDdEMsUUFBUSxRQUFRLE9BQU8sS0FBSyxPQUFPLFFBQVE7R0FDN0M7RUFDRjtFQUNBLE9BQU87Q0FDVDtDQUNBLGVBQWUsUUFBUSxLQUFLO0VBQzFCLE1BQU0sU0FBUyxPQUFPLFFBQVEsR0FBRztFQUNqQyxNQUFNLFdBQVcsT0FBTztFQUN4QixNQUFNLFNBQVMsUUFBUSxlQUFlLFFBQVEsR0FBRztFQUNqRCxJQUFJLFVBQVUsUUFBUTtHQUNwQixRQUFRLFFBQVEsVUFBVSxLQUFLLEtBQUssR0FBRyxRQUFRO0VBQ2pEO0VBQ0EsT0FBTztDQUNUO0NBQ0EsSUFBSSxRQUFRLEtBQUs7RUFDZixNQUFNLFNBQVMsUUFBUSxJQUFJLFFBQVEsR0FBRztFQUN0QyxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxlQUFlLElBQUksR0FBRyxHQUFHO0dBQzlDLE1BQU0sUUFBUSxPQUFPLEdBQUc7RUFDMUI7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxRQUFRLFFBQVE7RUFDZCxNQUNFLFFBQ0EsV0FDQSxRQUFRLE1BQU0sSUFBSSxXQUFXLFdBQy9CO0VBQ0EsT0FBTyxRQUFRLFFBQVEsTUFBTTtDQUMvQjtBQUNGO0FBQ0EsTUFBTSxnQ0FBZ0Msb0JBQW9CO0NBQ3hELFlBQVksYUFBYSxPQUFPO0VBQzlCLE1BQU0sTUFBTSxVQUFVO0NBQ3hCO0NBQ0EsSUFBSSxRQUFRLEtBQUs7RUFDZixJQUFJLENBQUMsb0JBQTJCLGVBQWU7R0FDN0MsS0FDRSx5QkFBeUIsT0FBTyxHQUFHLEVBQUUsZ0NBQ3JDLE1BQ0Y7RUFDRjtFQUNBLE9BQU87Q0FDVDtDQUNBLGVBQWUsUUFBUSxLQUFLO0VBQzFCLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtHQUM3QyxLQUNFLDRCQUE0QixPQUFPLEdBQUcsRUFBRSxnQ0FDeEMsTUFDRjtFQUNGO0VBQ0EsT0FBTztDQUNUO0FBQ0Y7QUFDQSxNQUFNLGtDQUFrQyxJQUFJLHVCQUF1QjtBQUNuRSxNQUFNLG1DQUFtQyxJQUFJLHdCQUF3QjtBQUNyRSxNQUFNLDBDQUEwQyxJQUFJLHVCQUF1QixJQUFJO0FBQy9FLE1BQU0sMENBQTBDLElBQUksd0JBQXdCLElBQUk7QUFFaEYsTUFBTSxhQUFhLFVBQVU7QUFDN0IsTUFBTSxZQUFZLE1BQU0sUUFBUSxlQUFlLENBQUM7QUFDaEQsU0FBUyxxQkFBcUIsUUFBUSxhQUFhLFlBQVk7Q0FDN0QsT0FBTyxTQUFTLEdBQUcsTUFBTTtFQUN2QixNQUFNLFNBQVMsS0FBSztFQUNwQixNQUFNLFlBQVksTUFBTSxNQUFNO0VBQzlCLE1BQU0sY0FBYyxNQUFNLFNBQVM7RUFDbkMsTUFBTSxTQUFTLFdBQVcsYUFBYSxXQUFXLE9BQU8sWUFBWTtFQUNyRSxNQUFNLFlBQVksV0FBVyxVQUFVO0VBQ3ZDLE1BQU0sZ0JBQWdCLE9BQU8sT0FBTyxDQUFDLEdBQUcsSUFBSTtFQUM1QyxNQUFNLE9BQU8sYUFBYSxZQUFZLGNBQWMsYUFBYTtFQUNqRSxDQUFDLGVBQWUsTUFDZCxXQUNBLFdBQ0EsWUFBWSxzQkFBc0IsV0FDcEM7RUFDQSxPQUFPOztHQUVMLE9BQU8sT0FBTyxhQUFhO0dBQzNCOztBQUVFLE9BQU87SUFDTCxNQUFNLEVBQUUsT0FBTyxTQUFTLGNBQWMsS0FBSztJQUMzQyxPQUFPLE9BQU87S0FBRTtLQUFPO0lBQUssSUFBSTtLQUM5QixPQUFPLFNBQVMsQ0FBQyxLQUFLLE1BQU0sRUFBRSxHQUFHLEtBQUssTUFBTSxFQUFFLENBQUMsSUFBSSxLQUFLLEtBQUs7S0FDN0Q7SUFDRjtHQUNGLEVBQ0Y7RUFDRjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLHFCQUFxQixNQUFNO0NBQ2xDLE9BQU8sU0FBUyxHQUFHLE1BQU07RUFDdkIsSUFBSSxDQUFDLG9CQUEyQixlQUFlO0dBQzdDLE1BQU0sTUFBTSxLQUFLLEtBQUssV0FBVyxLQUFLLEdBQUcsTUFBTTtHQUMvQyxLQUNFLEdBQUcsV0FBVyxJQUFJLEVBQUUsYUFBYSxJQUFJLDhCQUNyQyxNQUFNLElBQUksQ0FDWjtFQUNGO0VBQ0EsT0FBTyxTQUFTLFdBQVcsUUFBUSxTQUFTLFVBQVUsS0FBSyxJQUFJO0NBQ2pFO0FBQ0Y7QUFDQSxTQUFTLHVCQUF1QixVQUFVLFNBQVM7Q0FDakQsTUFBTSxtQkFBbUI7RUFDdkIsSUFBSSxLQUFLO0dBQ1AsTUFBTSxTQUFTLEtBQUs7R0FDcEIsTUFBTSxZQUFZLE1BQU0sTUFBTTtHQUM5QixNQUFNLFNBQVMsTUFBTSxHQUFHO0dBQ3hCLElBQUksQ0FBQyxVQUFVO0lBQ2IsSUFBSSxXQUFXLEtBQUssTUFBTSxHQUFHO0tBQzNCLE1BQU0sV0FBVyxPQUFPLEdBQUc7SUFDN0I7SUFDQSxNQUFNLFdBQVcsT0FBTyxNQUFNO0dBQ2hDO0dBQ0EsTUFBTSxFQUFFLFFBQVEsU0FBUyxTQUFTO0dBQ2xDLE1BQU0sT0FBTyxVQUFVLFlBQVksV0FBVyxhQUFhO0dBQzNELElBQUksSUFBSSxLQUFLLFdBQVcsR0FBRyxHQUFHO0lBQzVCLE9BQU8sS0FBSyxPQUFPLElBQUksR0FBRyxDQUFDO0dBQzdCLE9BQU8sSUFBSSxJQUFJLEtBQUssV0FBVyxNQUFNLEdBQUc7SUFDdEMsT0FBTyxLQUFLLE9BQU8sSUFBSSxNQUFNLENBQUM7R0FDaEMsT0FBTyxJQUFJLFdBQVcsV0FBVztJQUMvQixPQUFPLElBQUksR0FBRztHQUNoQjtFQUNGO0VBQ0EsSUFBSSxPQUFPO0dBQ1QsTUFBTSxTQUFTLEtBQUs7R0FDcEIsQ0FBQyxZQUFZLE1BQU0sTUFBTSxNQUFNLEdBQUcsV0FBVyxXQUFXO0dBQ3hELE9BQU8sT0FBTztFQUNoQjtFQUNBLElBQUksS0FBSztHQUNQLE1BQU0sU0FBUyxLQUFLO0dBQ3BCLE1BQU0sWUFBWSxNQUFNLE1BQU07R0FDOUIsTUFBTSxTQUFTLE1BQU0sR0FBRztHQUN4QixJQUFJLENBQUMsVUFBVTtJQUNiLElBQUksV0FBVyxLQUFLLE1BQU0sR0FBRztLQUMzQixNQUFNLFdBQVcsT0FBTyxHQUFHO0lBQzdCO0lBQ0EsTUFBTSxXQUFXLE9BQU8sTUFBTTtHQUNoQztHQUNBLE9BQU8sUUFBUSxTQUFTLE9BQU8sSUFBSSxHQUFHLElBQUksT0FBTyxJQUFJLEdBQUcsS0FBSyxPQUFPLElBQUksTUFBTTtFQUNoRjtFQUNBLFFBQVEsVUFBVSxTQUFTO0dBQ3pCLE1BQU0sV0FBVztHQUNqQixNQUFNLFNBQVMsU0FBUztHQUN4QixNQUFNLFlBQVksTUFBTSxNQUFNO0dBQzlCLE1BQU0sT0FBTyxVQUFVLFlBQVksV0FBVyxhQUFhO0dBQzNELENBQUMsWUFBWSxNQUFNLFdBQVcsV0FBVyxXQUFXO0dBQ3BELE9BQU8sT0FBTyxTQUFTLE9BQU8sUUFBUTtJQUNwQyxPQUFPLFNBQVMsS0FBSyxTQUFTLEtBQUssS0FBSyxHQUFHLEtBQUssR0FBRyxHQUFHLFFBQVE7R0FDaEUsQ0FBQztFQUNIO0NBQ0Y7Q0FDQSxPQUNFLGtCQUNBLFdBQVc7RUFDVCxLQUFLLHFCQUFxQixLQUFLO0VBQy9CLEtBQUsscUJBQXFCLEtBQUs7RUFDL0IsUUFBUSxxQkFBcUIsUUFBUTtFQUNyQyxPQUFPLHFCQUFxQixPQUFPO0NBQ3JDLElBQUk7RUFDRixJQUFJLE9BQU87R0FDVCxNQUFNLFNBQVMsTUFBTSxJQUFJO0dBQ3pCLE1BQU0sUUFBUSxTQUFTLE1BQU07R0FDN0IsTUFBTSxXQUFXLE1BQU0sS0FBSztHQUM1QixNQUFNLGFBQWEsQ0FBQyxXQUFXLENBQUMsVUFBVSxLQUFLLEtBQUssQ0FBQyxXQUFXLEtBQUssSUFBSSxXQUFXO0dBQ3BGLE1BQU0sU0FBUyxNQUFNLElBQUksS0FBSyxRQUFRLFVBQVUsS0FBSyxXQUFXLE9BQU8sVUFBVSxLQUFLLE1BQU0sSUFBSSxLQUFLLFFBQVEsS0FBSyxLQUFLLFdBQVcsVUFBVSxVQUFVLEtBQUssTUFBTSxJQUFJLEtBQUssUUFBUSxRQUFRO0dBQzFMLElBQUksQ0FBQyxRQUFRO0lBQ1gsT0FBTyxJQUFJLFVBQVU7SUFDckIsUUFBUSxRQUFRLE9BQU8sWUFBWSxVQUFVO0dBQy9DO0dBQ0EsT0FBTztFQUNUO0VBQ0EsSUFBSSxLQUFLLE9BQU87R0FDZCxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsS0FBSyxLQUFLLENBQUMsV0FBVyxLQUFLLEdBQUc7SUFDdkQsUUFBUSxNQUFNLEtBQUs7R0FDckI7R0FDQSxNQUFNLFNBQVMsTUFBTSxJQUFJO0dBQ3pCLE1BQU0sRUFBRSxLQUFLLFFBQVEsU0FBUyxNQUFNO0dBQ3BDLElBQUksU0FBUyxJQUFJLEtBQUssUUFBUSxHQUFHO0dBQ2pDLElBQUksQ0FBQyxRQUFRO0lBQ1gsTUFBTSxNQUFNLEdBQUc7SUFDZixTQUFTLElBQUksS0FBSyxRQUFRLEdBQUc7R0FDL0IsT0FBTyxJQUFJLENBQUMsb0JBQTJCLGVBQWU7SUFDcEQsa0JBQWtCLFFBQVEsS0FBSyxHQUFHO0dBQ3BDO0dBQ0EsTUFBTSxXQUFXLElBQUksS0FBSyxRQUFRLEdBQUc7R0FDckMsT0FBTyxJQUFJLEtBQUssS0FBSztHQUNyQixJQUFJLENBQUMsUUFBUTtJQUNYLFFBQVEsUUFBUSxPQUFPLEtBQUssS0FBSztHQUNuQyxPQUFPLElBQUksV0FBVyxPQUFPLFFBQVEsR0FBRztJQUN0QyxRQUFRLFFBQVEsT0FBTyxLQUFLLE9BQU8sUUFBUTtHQUM3QztHQUNBLE9BQU87RUFDVDtFQUNBLE9BQU8sS0FBSztHQUNWLE1BQU0sU0FBUyxNQUFNLElBQUk7R0FDekIsTUFBTSxFQUFFLEtBQUssUUFBUSxTQUFTLE1BQU07R0FDcEMsSUFBSSxTQUFTLElBQUksS0FBSyxRQUFRLEdBQUc7R0FDakMsSUFBSSxDQUFDLFFBQVE7SUFDWCxNQUFNLE1BQU0sR0FBRztJQUNmLFNBQVMsSUFBSSxLQUFLLFFBQVEsR0FBRztHQUMvQixPQUFPLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtJQUNwRCxrQkFBa0IsUUFBUSxLQUFLLEdBQUc7R0FDcEM7R0FDQSxNQUFNLFdBQVcsTUFBTSxJQUFJLEtBQUssUUFBUSxHQUFHLElBQUksS0FBSztHQUNwRCxNQUFNLFNBQVMsT0FBTyxPQUFPLEdBQUc7R0FDaEMsSUFBSSxRQUFRO0lBQ1YsUUFBUSxRQUFRLFVBQVUsS0FBSyxLQUFLLEdBQUcsUUFBUTtHQUNqRDtHQUNBLE9BQU87RUFDVDtFQUNBLFFBQVE7R0FDTixNQUFNLFNBQVMsTUFBTSxJQUFJO0dBQ3pCLE1BQU0sV0FBVyxPQUFPLFNBQVM7R0FDakMsTUFBTSxZQUFZLENBQUMsb0JBQTJCLGdCQUFnQixNQUFNLE1BQU0sSUFBSSxJQUFJLElBQUksTUFBTSxJQUFJLElBQUksSUFBSSxNQUFNLElBQUksS0FBSztHQUN2SCxNQUFNLFNBQVMsT0FBTyxNQUFNO0dBQzVCLElBQUksVUFBVTtJQUNaLFFBQ0UsUUFDQSxTQUNBLEtBQUssR0FDTCxLQUFLLEdBQ0wsU0FDRjtHQUNGO0dBQ0EsT0FBTztFQUNUO0NBQ0YsQ0FDRjtDQUNBLE1BQU0sa0JBQWtCO0VBQ3RCO0VBQ0E7RUFDQTtFQUNBLE9BQU87Q0FDVDtDQUNBLGdCQUFnQixTQUFTLFdBQVc7RUFDbEMsaUJBQWlCLFVBQVUscUJBQXFCLFFBQVEsVUFBVSxPQUFPO0NBQzNFLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLDRCQUE0QixhQUFhLFNBQVM7Q0FDekQsTUFBTSxtQkFBbUIsdUJBQXVCLGFBQWEsT0FBTztDQUNwRSxRQUFRLFFBQVEsS0FBSyxhQUFhO0VBQ2hDLElBQUksUUFBUSxrQkFBa0I7R0FDNUIsT0FBTyxDQUFDO0VBQ1YsT0FBTyxJQUFJLFFBQVEsa0JBQWtCO0dBQ25DLE9BQU87RUFDVCxPQUFPLElBQUksUUFBUSxXQUFXO0dBQzVCLE9BQU87RUFDVDtFQUNBLE9BQU8sUUFBUSxJQUNiLE9BQU8sa0JBQWtCLEdBQUcsS0FBSyxPQUFPLFNBQVMsbUJBQW1CLFFBQ3BFLEtBQ0EsUUFDRjtDQUNGO0FBQ0Y7QUFDQSxNQUFNLDRCQUE0QixFQUNoQyxLQUFxQiw0Q0FBNEIsT0FBTyxLQUFLLEVBQy9EO0FBQ0EsTUFBTSw0QkFBNEIsRUFDaEMsS0FBcUIsNENBQTRCLE9BQU8sSUFBSSxFQUM5RDtBQUNBLE1BQU0sNkJBQTZCLEVBQ2pDLEtBQXFCLDRDQUE0QixNQUFNLEtBQUssRUFDOUQ7QUFDQSxNQUFNLG9DQUFvQyxFQUN4QyxLQUFxQiw0Q0FBNEIsTUFBTSxJQUFJLEVBQzdEO0FBQ0EsU0FBUyxrQkFBa0IsUUFBUSxLQUFLLEtBQUs7Q0FDM0MsTUFBTSxTQUFTLE1BQU0sR0FBRztDQUN4QixJQUFJLFdBQVcsT0FBTyxJQUFJLEtBQUssUUFBUSxNQUFNLEdBQUc7RUFDOUMsTUFBTSxPQUFPLFVBQVUsTUFBTTtFQUM3QixLQUNFLFlBQVksS0FBSyxpRUFBaUUsU0FBUyxRQUFRLGFBQWEsR0FBRyw2SkFDckg7Q0FDRjtBQUNGO0FBRUEsTUFBTSw4QkFBOEIsSUFBSSxRQUFRO0FBQ2hELE1BQU0scUNBQXFDLElBQUksUUFBUTtBQUN2RCxNQUFNLDhCQUE4QixJQUFJLFFBQVE7QUFDaEQsTUFBTSxxQ0FBcUMsSUFBSSxRQUFRO0FBQ3ZELFNBQVMsY0FBYyxTQUFTO0NBQzlCLFFBQVEsU0FBUjtFQUNFLEtBQUs7RUFDTCxLQUFLLFNBQ0gsT0FBTztFQUNULEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUssV0FDSCxPQUFPO0VBQ1QsU0FDRSxPQUFPO0NBQ1g7QUFDRjs7QUFFQSxTQUFTLFNBQVMsUUFBUTtDQUN4QixJQUFvQiwyQkFBVyxNQUFNLEdBQUc7RUFDdEMsT0FBTztDQUNUO0NBQ0EsT0FBTyxxQkFDTCxRQUNBLE9BQ0EsaUJBQ0EsMkJBQ0EsV0FDRjtBQUNGOztBQUVBLFNBQVMsZ0JBQWdCLFFBQVE7Q0FDL0IsT0FBTyxxQkFDTCxRQUNBLE9BQ0EseUJBQ0EsMkJBQ0Esa0JBQ0Y7QUFDRjs7QUFFQSxTQUFTLFNBQVMsUUFBUTtDQUN4QixPQUFPLHFCQUNMLFFBQ0EsTUFDQSxrQkFDQSw0QkFDQSxXQUNGO0FBQ0Y7O0FBRUEsU0FBUyxnQkFBZ0IsUUFBUTtDQUMvQixPQUFPLHFCQUNMLFFBQ0EsTUFDQSx5QkFDQSxtQ0FDQSxrQkFDRjtBQUNGO0FBQ0EsU0FBUyxxQkFBcUIsUUFBUSxhQUFhLGNBQWMsb0JBQW9CLFVBQVU7Q0FDN0YsSUFBSSxDQUFDLFNBQVMsTUFBTSxHQUFHO0VBQ3JCLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtHQUM3QyxLQUNFLHdCQUF3QixjQUFjLGFBQWEsV0FBVyxJQUFJLE9BQ2hFLE1BQ0YsR0FDRjtFQUNGO0VBQ0EsT0FBTztDQUNUO0NBQ0EsSUFBSSxPQUFPLGNBQWMsRUFBRSxlQUFlLE9BQU8sb0JBQW9CO0VBQ25FLE9BQU87Q0FDVDtDQUNBLElBQUksT0FBTyxlQUFlLENBQUMsT0FBTyxhQUFhLE1BQU0sR0FBRztFQUN0RCxPQUFPO0NBQ1Q7Q0FDQSxNQUFNLGdCQUFnQixTQUFTLElBQUksTUFBTTtDQUN6QyxJQUFJLGVBQWU7RUFDakIsT0FBTztDQUNUO0NBQ0EsTUFBTSxhQUFhLGNBQWMsVUFBVSxNQUFNLENBQUM7Q0FDbEQsSUFBSSxlQUFlLEdBQWlCO0VBQ2xDLE9BQU87Q0FDVDtDQUNBLE1BQU0sUUFBUSxJQUFJLE1BQ2hCLFFBQ0EsZUFBZSxJQUFxQixxQkFBcUIsWUFDM0Q7Q0FDQSxTQUFTLElBQUksUUFBUSxLQUFLO0NBQzFCLE9BQU87QUFDVDs7QUFFQSxTQUFTLFdBQVcsT0FBTztDQUN6QixJQUFvQiwyQkFBVyxLQUFLLEdBQUc7RUFDckMsT0FBdUIsMkJBQVcsTUFBTSxVQUFVO0NBQ3BEO0NBQ0EsT0FBTyxDQUFDLEVBQUUsU0FBUyxNQUFNO0FBQzNCOztBQUVBLFNBQVMsV0FBVyxPQUFPO0NBQ3pCLE9BQU8sQ0FBQyxFQUFFLFNBQVMsTUFBTTtBQUMzQjs7QUFFQSxTQUFTLFVBQVUsT0FBTztDQUN4QixPQUFPLENBQUMsRUFBRSxTQUFTLE1BQU07QUFDM0I7O0FBRUEsU0FBUyxRQUFRLE9BQU87Q0FDdEIsT0FBTyxRQUFRLENBQUMsQ0FBQyxNQUFNLGFBQWE7QUFDdEM7O0FBRUEsU0FBUyxNQUFNLFVBQVU7Q0FDdkIsTUFBTSxNQUFNLFlBQVksU0FBUztDQUNqQyxPQUFPLE1BQXNCLHNCQUFNLEdBQUcsSUFBSTtBQUM1QztBQUNBLFNBQVMsUUFBUSxPQUFPO0NBQ3RCLElBQUksQ0FBQyxPQUFPLE9BQU8sVUFBVSxLQUFLLE9BQU8sYUFBYSxLQUFLLEdBQUc7RUFDNUQsSUFBSSxPQUFPLFlBQVksSUFBSTtDQUM3QjtDQUNBLE9BQU87QUFDVDtBQUNBLE1BQU0sY0FBYyxVQUFVLFNBQVMsS0FBSyxJQUFvQix5QkFBUyxLQUFLLElBQUk7QUFDbEYsTUFBTSxjQUFjLFVBQVUsU0FBUyxLQUFLLElBQW9CLHlCQUFTLEtBQUssSUFBSTs7QUFHbEYsU0FBUyxNQUFNLEdBQUc7Q0FDaEIsT0FBTyxJQUFJLEVBQUUsaUJBQWlCLE9BQU87QUFDdkM7O0FBRUEsU0FBUyxJQUFJLE9BQU87Q0FDbEIsT0FBTyxVQUFVLE9BQU8sS0FBSztBQUMvQjs7QUFFQSxTQUFTLFdBQVcsT0FBTztDQUN6QixPQUFPLFVBQVUsT0FBTyxJQUFJO0FBQzlCO0FBQ0EsU0FBUyxVQUFVLFVBQVUsU0FBUztDQUNwQyxJQUFvQixzQkFBTSxRQUFRLEdBQUc7RUFDbkMsT0FBTztDQUNUO0NBQ0EsT0FBTyxJQUFJLFFBQVEsVUFBVSxPQUFPO0FBQ3RDO0FBQ0EsTUFBTSxRQUFRO0NBQ1osWUFBWSxPQUFPLFlBQVk7RUFDN0IsS0FBSyxNQUFNLElBQUksSUFBSTtFQUNuQixLQUFLLGVBQWU7RUFDcEIsS0FBSyxtQkFBbUI7RUFDeEIsS0FBSyxZQUFZLGFBQWEsUUFBUSxNQUFNLEtBQUs7RUFDakQsS0FBSyxTQUFTLGFBQWEsUUFBUSxXQUFXLEtBQUs7RUFDbkQsS0FBSyxtQkFBbUI7Q0FDMUI7Q0FDQSxJQUFJLFFBQVE7RUFDVixJQUFJLENBQUMsb0JBQTJCLGVBQWU7R0FDN0MsS0FBSyxJQUFJLE1BQU07SUFDYixRQUFRO0lBQ1IsTUFBTTtJQUNOLEtBQUs7R0FDUCxDQUFDO0VBQ0gsT0FBTztHQUNMLEtBQUssSUFBSSxNQUFNO0VBQ2pCO0VBQ0EsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxJQUFJLE1BQU0sVUFBVTtFQUNsQixNQUFNLFdBQVcsS0FBSztFQUN0QixNQUFNLGlCQUFpQixLQUFLLG9CQUFvQixVQUFVLFFBQVEsS0FBSyxXQUFXLFFBQVE7RUFDMUYsV0FBVyxpQkFBaUIsV0FBVyxNQUFNLFFBQVE7RUFDckQsSUFBSSxXQUFXLFVBQVUsUUFBUSxHQUFHO0dBQ2xDLEtBQUssWUFBWTtHQUNqQixLQUFLLFNBQVMsaUJBQWlCLFdBQVcsV0FBVyxRQUFRO0dBQzdELElBQUksQ0FBQyxvQkFBMkIsZUFBZTtJQUM3QyxLQUFLLElBQUksUUFBUTtLQUNmLFFBQVE7S0FDUixNQUFNO0tBQ04sS0FBSztLQUNMO0tBQ0E7SUFDRixDQUFDO0dBQ0gsT0FBTztJQUNMLEtBQUssSUFBSSxRQUFRO0dBQ25CO0VBQ0Y7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxXQUFXLE1BQU07Q0FDeEIsSUFBSSxLQUFLLEtBQUs7RUFDWixJQUFJLENBQUMsb0JBQTJCLGVBQWU7R0FDN0MsS0FBSyxJQUFJLFFBQVE7SUFDZixRQUFRO0lBQ1IsTUFBTTtJQUNOLEtBQUs7SUFDTCxVQUFVLEtBQUs7R0FDakIsQ0FBQztFQUNILE9BQU87R0FDTCxLQUFLLElBQUksUUFBUTtFQUNuQjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLE1BQU0sTUFBTTtDQUNuQixPQUF1QixzQkFBTSxJQUFJLElBQUksS0FBSyxRQUFRO0FBQ3BEO0FBQ0EsU0FBUyxRQUFRLFFBQVE7Q0FDdkIsT0FBTyxXQUFXLE1BQU0sSUFBSSxPQUFPLElBQUksTUFBTSxNQUFNO0FBQ3JEO0FBQ0EsTUFBTSx3QkFBd0I7Q0FDNUIsTUFBTSxRQUFRLEtBQUssYUFBYSxRQUFRLFlBQVksU0FBUyxNQUFNLFFBQVEsSUFBSSxRQUFRLEtBQUssUUFBUSxDQUFDO0NBQ3JHLE1BQU0sUUFBUSxLQUFLLE9BQU8sYUFBYTtFQUNyQyxNQUFNLFdBQVcsT0FBTztFQUN4QixJQUFvQixzQkFBTSxRQUFRLEtBQUssQ0FBaUIsc0JBQU0sS0FBSyxHQUFHO0dBQ3BFLFNBQVMsUUFBUTtHQUNqQixPQUFPO0VBQ1QsT0FBTztHQUNMLE9BQU8sUUFBUSxJQUFJLFFBQVEsS0FBSyxPQUFPLFFBQVE7RUFDakQ7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxVQUFVLGdCQUFnQjtDQUNqQyxPQUFPLFdBQVcsY0FBYyxJQUFJLGlCQUFpQixJQUFJLE1BQU0sZ0JBQWdCLHFCQUFxQjtBQUN0RztBQUNBLE1BQU0sY0FBYztDQUNsQixZQUFZLFNBQVM7RUFDbkIsS0FBSyxlQUFlO0VBQ3BCLEtBQUssU0FBUyxLQUFLO0VBQ25CLE1BQU0sTUFBTSxLQUFLLE1BQU0sSUFBSSxJQUFJO0VBQy9CLE1BQU0sRUFBRSxLQUFLLFFBQVEsUUFBUSxJQUFJLE1BQU0sS0FBSyxHQUFHLEdBQUcsSUFBSSxRQUFRLEtBQUssR0FBRyxDQUFDO0VBQ3ZFLEtBQUssT0FBTztFQUNaLEtBQUssT0FBTztDQUNkO0NBQ0EsSUFBSSxRQUFRO0VBQ1YsT0FBTyxLQUFLLFNBQVMsS0FBSyxLQUFLO0NBQ2pDO0NBQ0EsSUFBSSxNQUFNLFFBQVE7RUFDaEIsS0FBSyxLQUFLLE1BQU07Q0FDbEI7QUFDRjtBQUNBLFNBQVMsVUFBVSxTQUFTO0NBQzFCLE9BQU8sSUFBSSxjQUFjLE9BQU87QUFDbEM7O0FBRUEsU0FBUyxPQUFPLFFBQVE7Q0FDdEIsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsQ0FBQyxRQUFRLE1BQU0sR0FBRztFQUNqRSxLQUFLLDhEQUE4RDtDQUNyRTtDQUNBLE1BQU0sTUFBTSxRQUFRLE1BQU0sSUFBSSxJQUFJLE1BQU0sT0FBTyxNQUFNLElBQUksQ0FBQztDQUMxRCxLQUFLLE1BQU0sT0FBTyxRQUFRO0VBQ3hCLElBQUksT0FBTyxjQUFjLFFBQVEsR0FBRztDQUN0QztDQUNBLE9BQU87QUFDVDtBQUNBLE1BQU0sY0FBYztDQUNsQixZQUFZLFNBQVMsS0FBSyxlQUFlO0VBQ3ZDLEtBQUssVUFBVTtFQUNmLEtBQUssZ0JBQWdCO0VBQ3JCLEtBQUssZUFBZTtFQUNwQixLQUFLLFNBQVMsS0FBSztFQUNuQixLQUFLLE9BQU8sU0FBUyxHQUFHLElBQUksTUFBTSxPQUFPLEdBQUc7RUFDNUMsS0FBSyxPQUFPLE1BQU0sT0FBTztFQUN6QixJQUFJLFVBQVU7RUFDZCxJQUFJLE1BQU07RUFDVixJQUFJLENBQUMsUUFBUSxPQUFPLEtBQUssU0FBUyxLQUFLLElBQUksS0FBSyxDQUFDLGFBQWEsS0FBSyxJQUFJLEdBQUc7R0FDeEUsR0FBRztJQUNELFVBQVUsQ0FBQyxRQUFRLEdBQUcsS0FBSyxVQUFVLEdBQUc7R0FDMUMsU0FBUyxZQUFZLE1BQU0sSUFBSTtFQUNqQztFQUNBLEtBQUssV0FBVztDQUNsQjtDQUNBLElBQUksUUFBUTtFQUNWLElBQUksTUFBTSxLQUFLLFFBQVEsS0FBSztFQUM1QixJQUFJLEtBQUssVUFBVTtHQUNqQixNQUFNLE1BQU0sR0FBRztFQUNqQjtFQUNBLE9BQU8sS0FBSyxTQUFTLFFBQVEsS0FBSyxJQUFJLEtBQUssZ0JBQWdCO0NBQzdEO0NBQ0EsSUFBSSxNQUFNLFFBQVE7RUFDaEIsSUFBSSxLQUFLLFlBQTRCLHNCQUFNLEtBQUssS0FBSyxLQUFLLEtBQUssR0FBRztHQUNoRSxNQUFNLFlBQVksS0FBSyxRQUFRLEtBQUs7R0FDcEMsSUFBb0Isc0JBQU0sU0FBUyxHQUFHO0lBQ3BDLFVBQVUsUUFBUTtJQUNsQjtHQUNGO0VBQ0Y7RUFDQSxLQUFLLFFBQVEsS0FBSyxRQUFRO0NBQzVCO0NBQ0EsSUFBSSxNQUFNO0VBQ1IsT0FBTyxtQkFBbUIsS0FBSyxNQUFNLEtBQUssSUFBSTtDQUNoRDtBQUNGO0FBQ0EsTUFBTSxjQUFjO0NBQ2xCLFlBQVksU0FBUztFQUNuQixLQUFLLFVBQVU7RUFDZixLQUFLLGVBQWU7RUFDcEIsS0FBSyxvQkFBb0I7RUFDekIsS0FBSyxTQUFTLEtBQUs7Q0FDckI7Q0FDQSxJQUFJLFFBQVE7RUFDVixPQUFPLEtBQUssU0FBUyxLQUFLLFFBQVE7Q0FDcEM7QUFDRjs7QUFFQSxTQUFTLE1BQU0sUUFBUSxLQUFLLGNBQWM7Q0FDeEMsSUFBb0Isc0JBQU0sTUFBTSxHQUFHO0VBQ2pDLE9BQU87Q0FDVCxPQUFPLElBQUksV0FBVyxNQUFNLEdBQUc7RUFDN0IsT0FBTyxJQUFJLGNBQWMsTUFBTTtDQUNqQyxPQUFPLElBQUksU0FBUyxNQUFNLEtBQUssVUFBVSxTQUFTLEdBQUc7RUFDbkQsT0FBTyxjQUFjLFFBQVEsS0FBSyxZQUFZO0NBQ2hELE9BQU87RUFDTCxPQUF1QixvQkFBSSxNQUFNO0NBQ25DO0FBQ0Y7QUFDQSxTQUFTLGNBQWMsUUFBUSxLQUFLLGNBQWM7Q0FDaEQsT0FBTyxJQUFJLGNBQWMsUUFBUSxLQUFLLFlBQVk7QUFDcEQ7QUFFQSxNQUFNLGdCQUFnQjtDQUNwQixZQUFZLElBQUksUUFBUSxPQUFPO0VBQzdCLEtBQUssS0FBSztFQUNWLEtBQUssU0FBUzs7OztFQUlkLEtBQUssU0FBUyxLQUFLOzs7O0VBSW5CLEtBQUssTUFBTSxJQUFJLElBQUksSUFBSTs7OztFQUl2QixLQUFLLFlBQVk7Ozs7OztFQU1qQixLQUFLLE9BQU8sS0FBSzs7OztFQUlqQixLQUFLLFdBQVcsS0FBSzs7OztFQUlyQixLQUFLLFFBQVE7Ozs7RUFJYixLQUFLLGdCQUFnQixnQkFBZ0I7Ozs7RUFJckMsS0FBSyxPQUFPLEtBQUs7O0VBRWpCLEtBQUssU0FBUztFQUNkLEtBQUssb0JBQW9CLENBQUM7RUFDMUIsS0FBSyxRQUFRO0NBQ2Y7Ozs7Q0FJQSxTQUFTO0VBQ1AsS0FBSyxTQUFTO0VBQ2QsSUFBSSxFQUFFLEtBQUssUUFBUSxNQUNuQixjQUFjLE1BQU07R0FDbEIsTUFBTSxNQUFNLElBQUk7R0FDaEIsT0FBTztFQUNULE9BQU8sSUFBSSxDQUFDLG9CQUEyQjtDQUN6QztDQUNBLElBQUksUUFBUTtFQUNWLE1BQU0sT0FBTyxDQUFDLG9CQUEyQixnQkFBZ0IsS0FBSyxJQUFJLE1BQU07R0FDdEUsUUFBUTtHQUNSLE1BQU07R0FDTixLQUFLO0VBQ1AsQ0FBQyxJQUFJLEtBQUssSUFBSSxNQUFNO0VBQ3BCLGdCQUFnQixJQUFJO0VBQ3BCLElBQUksTUFBTTtHQUNSLEtBQUssVUFBVSxLQUFLLElBQUk7RUFDMUI7RUFDQSxPQUFPLEtBQUs7Q0FDZDtDQUNBLElBQUksTUFBTSxVQUFVO0VBQ2xCLElBQUksS0FBSyxRQUFRO0dBQ2YsS0FBSyxPQUFPLFFBQVE7RUFDdEIsT0FBTyxJQUFJLENBQUMsb0JBQTJCLGVBQWU7R0FDcEQsS0FBSyxvREFBb0Q7RUFDM0Q7Q0FDRjtBQUNGOztBQUVBLFNBQVMsU0FBUyxpQkFBaUIsY0FBYyxRQUFRLE9BQU87Q0FDOUQsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJLFdBQVcsZUFBZSxHQUFHO0VBQy9CLFNBQVM7Q0FDWCxPQUFPO0VBQ0wsU0FBUyxnQkFBZ0I7RUFDekIsU0FBUyxnQkFBZ0I7Q0FDM0I7Q0FDQSxNQUFNLE9BQU8sSUFBSSxnQkFBZ0IsUUFBUSxRQUFRLEtBQUs7Q0FDdEQsSUFBSSxDQUFDLG9CQUEyQixpQkFBaUIsZ0JBQWdCLENBQUMsT0FBTztFQUN2RSxLQUFLLFVBQVUsYUFBYTtFQUM1QixLQUFLLFlBQVksYUFBYTtDQUNoQztDQUNBLE9BQU87QUFDVDtBQUVBLE1BQU0sZUFBZTtDQUNuQixPQUFPO0NBQ1AsT0FBTztDQUNQLFdBQVc7QUFDYjtBQUNBLE1BQU0saUJBQWlCO0NBQ3JCLE9BQU87Q0FDUCxPQUFPO0NBQ1AsVUFBVTtDQUNWLFNBQVM7QUFDWDtBQUNBLE1BQU0sZ0JBQWdCO0NBQ3BCLFFBQVE7Q0FDUixlQUFlO0NBQ2YsZUFBZTtDQUNmLGNBQWM7Q0FDZCxPQUFPO0NBQ1AsVUFBVTtBQUNaO0FBRUEsTUFBTSxrQkFBa0I7Q0FDdEIsZ0JBQWdCO0NBQ2hCLEtBQUs7Q0FDTCxrQkFBa0I7Q0FDbEIsS0FBSztDQUNMLGlCQUFpQjtDQUNqQixLQUFLO0FBQ1A7QUFDQSxNQUFNLHdCQUF3QixDQUFDO0FBQy9CLE1BQU0sNkJBQTZCLElBQUksUUFBUTtBQUMvQyxJQUFJLGdCQUFnQixLQUFLO0FBQ3pCLFNBQVMsb0JBQW9CO0NBQzNCLE9BQU87QUFDVDtBQUNBLFNBQVMsaUJBQWlCLFdBQVcsZUFBZSxPQUFPLFFBQVEsZUFBZTtDQUNoRixJQUFJLE9BQU87RUFDVCxJQUFJLFdBQVcsV0FBVyxJQUFJLEtBQUs7RUFDbkMsSUFBSSxDQUFDLFVBQVUsV0FBVyxJQUFJLE9BQU8sV0FBVyxDQUFDLENBQUM7RUFDbEQsU0FBUyxLQUFLLFNBQVM7Q0FDekIsT0FBTyxJQUFJLENBQUMsb0JBQTJCLGlCQUFpQixDQUFDLGNBQWM7RUFDckUsS0FDRSxtRkFDRjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLE1BQU0sUUFBUSxJQUFJLFVBQVUsV0FBVztDQUM5QyxNQUFNLEVBQUUsV0FBVyxNQUFNLE1BQU0sV0FBVyxZQUFZLFNBQVM7Q0FDL0QsTUFBTSxxQkFBcUIsTUFBTTtFQUMvQixDQUFDLFFBQVEsVUFBVSxLQUFJLENBQ3JCLDBCQUNBLEdBQ0EsNEdBQ0Y7Q0FDRjtDQUNBLE1BQU0sa0JBQWtCLFlBQVk7RUFDbEMsSUFBSSxNQUFNLE9BQU87RUFDakIsSUFBSSxVQUFVLE9BQU8sS0FBSyxTQUFTLFNBQVMsU0FBUyxHQUNuRCxPQUFPLFNBQVMsU0FBUyxDQUFDO0VBQzVCLE9BQU8sU0FBUyxPQUFPO0NBQ3pCO0NBQ0EsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUksZUFBZTtDQUNuQixJQUFJLGdCQUFnQjtDQUNwQixJQUFJLE1BQU0sTUFBTSxHQUFHO0VBQ2pCLGVBQWUsT0FBTztFQUN0QixlQUFlLFVBQVUsTUFBTTtDQUNqQyxPQUFPLElBQUksV0FBVyxNQUFNLEdBQUc7RUFDN0IsZUFBZSxlQUFlLE1BQU07RUFDcEMsZUFBZTtDQUNqQixPQUFPLElBQUksUUFBUSxNQUFNLEdBQUc7RUFDMUIsZ0JBQWdCO0VBQ2hCLGVBQWUsT0FBTyxNQUFNLE1BQU0sV0FBVyxDQUFDLEtBQUssVUFBVSxDQUFDLENBQUM7RUFDL0QsZUFBZSxPQUFPLEtBQUssTUFBTTtHQUMvQixJQUFJLE1BQU0sQ0FBQyxHQUFHO0lBQ1osT0FBTyxFQUFFO0dBQ1gsT0FBTyxJQUFJLFdBQVcsQ0FBQyxHQUFHO0lBQ3hCLE9BQU8sZUFBZSxDQUFDO0dBQ3pCLE9BQU8sSUFBSSxXQUFXLENBQUMsR0FBRztJQUN4QixPQUFPLE9BQU8sS0FBSyxHQUFHLENBQUMsSUFBSSxFQUFFO0dBQy9CLE9BQU87SUFDTCxDQUFDLG9CQUEyQixpQkFBaUIsa0JBQWtCLENBQUM7R0FDbEU7RUFDRixDQUFDO0NBQ0gsT0FBTyxJQUFJLFdBQVcsTUFBTSxHQUFHO0VBQzdCLElBQUksSUFBSTtHQUNOLFNBQVMsYUFBYSxLQUFLLFFBQVEsQ0FBQyxJQUFJO0VBQzFDLE9BQU87R0FDTCxlQUFlO0lBQ2IsSUFBSSxTQUFTO0tBQ1gsY0FBYztLQUNkLElBQUk7TUFDRixRQUFRO0tBQ1YsVUFBVTtNQUNSLGNBQWM7S0FDaEI7SUFDRjtJQUNBLE1BQU0sZ0JBQWdCO0lBQ3RCLGdCQUFnQjtJQUNoQixJQUFJO0tBQ0YsT0FBTyxPQUFPLEtBQUssUUFBUSxHQUFHLENBQUMsWUFBWSxDQUFDLElBQUksT0FBTyxZQUFZO0lBQ3JFLFVBQVU7S0FDUixnQkFBZ0I7SUFDbEI7R0FDRjtFQUNGO0NBQ0YsT0FBTztFQUNMLFNBQVM7RUFDVCxDQUFDLG9CQUEyQixpQkFBaUIsa0JBQWtCLE1BQU07Q0FDdkU7Q0FDQSxJQUFJLE1BQU0sTUFBTTtFQUNkLE1BQU0sYUFBYTtFQUNuQixNQUFNLFFBQVEsU0FBUyxPQUFPLFdBQVc7RUFDekMsZUFBZSxTQUFTLFdBQVcsR0FBRyxLQUFLO0NBQzdDO0NBQ0EsTUFBTSxRQUFRLGdCQUFnQjtDQUM5QixNQUFNLG9CQUFvQjtFQUN4QixPQUFPLEtBQUs7RUFDWixJQUFJLFNBQVMsTUFBTSxRQUFRO0dBQ3pCLE9BQU8sTUFBTSxTQUFTLE1BQU07RUFDOUI7Q0FDRjtDQUNBLElBQUksUUFBUSxJQUFJO0VBQ2QsTUFBTSxNQUFNO0VBQ1osTUFBTSxHQUFHLFNBQVM7R0FDaEIsTUFBTSxNQUFNLElBQUksR0FBRyxJQUFJO0dBQ3ZCLFlBQVk7R0FDWixPQUFPO0VBQ1Q7Q0FDRjtDQUNBLElBQUksV0FBVyxnQkFBZ0IsSUFBSSxNQUFNLE9BQU8sTUFBTSxDQUFDLENBQUMsS0FBSyxxQkFBcUIsSUFBSTtDQUN0RixNQUFNLE9BQU8sc0JBQXNCO0VBQ2pDLElBQUksRUFBRSxPQUFPLFFBQVEsTUFBTSxDQUFDLE9BQU8sU0FBUyxDQUFDLG1CQUFtQjtHQUM5RDtFQUNGO0VBQ0EsSUFBSSxJQUFJO0dBQ04sTUFBTSxXQUFXLE9BQU8sSUFBSTtHQUM1QixJQUFJLHFCQUFxQixRQUFRLGlCQUFpQixnQkFBZ0IsU0FBUyxNQUFNLEdBQUcsTUFBTSxXQUFXLEdBQUcsU0FBUyxFQUFFLENBQUMsSUFBSSxXQUFXLFVBQVUsUUFBUSxJQUFJO0lBQ3ZKLElBQUksU0FBUztLQUNYLFFBQVE7SUFDVjtJQUNBLE1BQU0saUJBQWlCO0lBQ3ZCLGdCQUFnQjtJQUNoQixJQUFJO0tBQ0YsTUFBTSxPQUFPO01BQ1g7TUFFQSxhQUFhLHdCQUF3QixLQUFLLElBQUksaUJBQWlCLFNBQVMsT0FBTyx3QkFBd0IsQ0FBQyxJQUFJO01BQzVHO0tBQ0Y7S0FDQSxXQUFXO0tBQ1gsT0FBTyxLQUFLLElBQUksR0FBRyxJQUFJOztLQUVyQixHQUFHLEdBQUcsSUFBSTtJQUVkLFVBQVU7S0FDUixnQkFBZ0I7SUFDbEI7R0FDRjtFQUNGLE9BQU87R0FDTCxPQUFPLElBQUk7RUFDYjtDQUNGO0NBQ0EsSUFBSSxZQUFZO0VBQ2QsV0FBVyxHQUFHO0NBQ2hCO0NBQ0EsU0FBUyxJQUFJLGVBQWUsTUFBTTtDQUNsQyxPQUFPLFlBQVksa0JBQWtCLFVBQVUsS0FBSyxLQUFLLElBQUk7Q0FDN0QsZ0JBQWdCLE9BQU8saUJBQWlCLElBQUksT0FBTyxNQUFNO0NBQ3pELFVBQVUsT0FBTyxlQUFlO0VBQzlCLE1BQU0sV0FBVyxXQUFXLElBQUksTUFBTTtFQUN0QyxJQUFJLFVBQVU7R0FDWixJQUFJLE1BQU07SUFDUixLQUFLLFVBQVUsQ0FBQztHQUNsQixPQUFPO0lBQ0wsS0FBSyxNQUFNLFlBQVksVUFBVSxTQUFTO0dBQzVDO0dBQ0EsV0FBVyxPQUFPLE1BQU07RUFDMUI7Q0FDRjtDQUNBLElBQUksQ0FBQyxvQkFBMkIsZUFBZTtFQUM3QyxPQUFPLFVBQVUsUUFBUTtFQUN6QixPQUFPLFlBQVksUUFBUTtDQUM3QjtDQUNBLElBQUksSUFBSTtFQUNOLElBQUksV0FBVztHQUNiLElBQUksSUFBSTtFQUNWLE9BQU87R0FDTCxXQUFXLE9BQU8sSUFBSTtFQUN4QjtDQUNGLE9BQU8sSUFBSSxXQUFXO0VBQ3BCLFVBQVUsSUFBSSxLQUFLLE1BQU0sSUFBSSxHQUFHLElBQUk7Q0FDdEMsT0FBTztFQUNMLE9BQU8sSUFBSTtDQUNiO0NBQ0EsWUFBWSxRQUFRLE9BQU8sTUFBTSxLQUFLLE1BQU07Q0FDNUMsWUFBWSxTQUFTLE9BQU8sT0FBTyxLQUFLLE1BQU07Q0FDOUMsWUFBWSxPQUFPO0NBQ25CLE9BQU87QUFDVDtBQUNBLFNBQVMsU0FBUyxPQUFPLFFBQVEsVUFBVSxNQUFNO0NBQy9DLElBQUksU0FBUyxLQUFLLENBQUMsU0FBUyxLQUFLLEtBQUssTUFBTSxhQUFhO0VBQ3ZELE9BQU87Q0FDVDtDQUNBLE9BQU8sd0JBQXdCLElBQUksSUFBSTtDQUN2QyxLQUFLLEtBQUssSUFBSSxLQUFLLEtBQUssTUFBTSxPQUFPO0VBQ25DLE9BQU87Q0FDVDtDQUNBLEtBQUssSUFBSSxPQUFPLEtBQUs7Q0FDckI7Q0FDQSxJQUFJLE1BQU0sS0FBSyxHQUFHO0VBQ2hCLFNBQVMsTUFBTSxPQUFPLE9BQU8sSUFBSTtDQUNuQyxPQUFPLElBQUksUUFBUSxLQUFLLEdBQUc7RUFDekIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLO0dBQ3JDLFNBQVMsTUFBTSxJQUFJLE9BQU8sSUFBSTtFQUNoQztDQUNGLE9BQU8sSUFBSSxNQUFNLEtBQUssS0FBSyxNQUFNLEtBQUssR0FBRztFQUN2QyxNQUFNLFNBQVMsTUFBTTtHQUNuQixTQUFTLEdBQUcsT0FBTyxJQUFJO0VBQ3pCLENBQUM7Q0FDSCxPQUFPLElBQUksY0FBYyxLQUFLLEdBQUc7RUFDL0IsS0FBSyxNQUFNLE9BQU8sT0FBTztHQUN2QixTQUFTLE1BQU0sTUFBTSxPQUFPLElBQUk7RUFDbEM7RUFDQSxLQUFLLE1BQU0sT0FBTyxPQUFPLHNCQUFzQixLQUFLLEdBQUc7R0FDckQsSUFBSSxPQUFPLFVBQVUscUJBQXFCLEtBQUssT0FBTyxHQUFHLEdBQUc7SUFDMUQsU0FBUyxNQUFNLE1BQU0sT0FBTyxJQUFJO0dBQ2xDO0VBQ0Y7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUVBLFNBQVMsbUJBQW1CLGFBQWEsYUFBYSxhQUFhLHFCQUFxQixnQkFBZ0IsZUFBZSxjQUFjLGdCQUFnQixpQkFBaUIsVUFBVSxXQUFXLFFBQVEsYUFBYSxnQkFBZ0IsaUJBQWlCLG1CQUFtQixTQUFTLFlBQVksWUFBWSxPQUFPLFdBQVcsU0FBUyxpQkFBaUIsZ0JBQWdCLGtCQUFrQixlQUFlLFdBQVcsVUFBVSxtQkFBbUIsVUFBVSxLQUFLLGVBQWUsaUJBQWlCLGtCQUFrQixpQkFBaUIsWUFBWSxNQUFNLE9BQU8sWUFBWSxZQUFZLE9BQU8sUUFBUSxTQUFTLE9BQU8sVUFBVSxTQUFTLFlBQVksT0FBTyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJyZWFjdGl2aXR5LmVzbS1idW5kbGVyLmpzP3Y9N2U3M2FmYzIiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyoqXG4qIEB2dWUvcmVhY3Rpdml0eSB2My41LjQwXG4qIChjKSAyMDE4LXByZXNlbnQgWXV4aSAoRXZhbikgWW91IGFuZCBWdWUgY29udHJpYnV0b3JzXG4qIEBsaWNlbnNlIE1JVFxuKiovXG5pbXBvcnQgeyBleHRlbmQsIGhhc0NoYW5nZWQsIGlzQXJyYXksIGlzSW50ZWdlcktleSwgaXNTeW1ib2wsIGlzTWFwLCBoYXNPd24sIGlzT2JqZWN0LCBtYWtlTWFwLCBjYXBpdGFsaXplLCB0b1Jhd1R5cGUsIGRlZiwgaXNGdW5jdGlvbiwgRU1QVFlfT0JKLCBpc1NldCwgaXNQbGFpbk9iamVjdCwgcmVtb3ZlLCBOT09QIH0gZnJvbSAnQHZ1ZS9zaGFyZWQnO1xuXG5mdW5jdGlvbiB3YXJuKG1zZywgLi4uYXJncykge1xuICBjb25zb2xlLndhcm4oYFtWdWUgd2Fybl0gJHttc2d9YCwgLi4uYXJncyk7XG59XG5cbmxldCBhY3RpdmVFZmZlY3RTY29wZTtcbmNsYXNzIEVmZmVjdFNjb3BlIHtcbiAgLy8gVE9ETyBpc29sYXRlZERlY2xhcmF0aW9ucyBcIl9fdl9za2lwXCJcbiAgY29uc3RydWN0b3IoZGV0YWNoZWQgPSBmYWxzZSkge1xuICAgIHRoaXMuZGV0YWNoZWQgPSBkZXRhY2hlZDtcbiAgICAvKipcbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLl9hY3RpdmUgPSB0cnVlO1xuICAgIC8qKlxuICAgICAqIEBpbnRlcm5hbCB0cmFjayBgb25gIGNhbGxzLCBhbGxvdyBgb25gIGNhbGwgbXVsdGlwbGUgdGltZXNcbiAgICAgKi9cbiAgICB0aGlzLl9vbiA9IDA7XG4gICAgLyoqXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5lZmZlY3RzID0gW107XG4gICAgLyoqXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5jbGVhbnVwcyA9IFtdO1xuICAgIHRoaXMuX2lzUGF1c2VkID0gZmFsc2U7XG4gICAgdGhpcy5fd2Fybk9uUnVuID0gdHJ1ZTtcbiAgICB0aGlzLl9fdl9za2lwID0gdHJ1ZTtcbiAgICBpZiAoIWRldGFjaGVkICYmIGFjdGl2ZUVmZmVjdFNjb3BlKSB7XG4gICAgICBpZiAoYWN0aXZlRWZmZWN0U2NvcGUuYWN0aXZlKSB7XG4gICAgICAgIHRoaXMucGFyZW50ID0gYWN0aXZlRWZmZWN0U2NvcGU7XG4gICAgICAgIHRoaXMuaW5kZXggPSAoYWN0aXZlRWZmZWN0U2NvcGUuc2NvcGVzIHx8IChhY3RpdmVFZmZlY3RTY29wZS5zY29wZXMgPSBbXSkpLnB1c2goXG4gICAgICAgICAgdGhpc1xuICAgICAgICApIC0gMTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuX2FjdGl2ZSA9IGZhbHNlO1xuICAgICAgICB0aGlzLl93YXJuT25SdW4gPSBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgZ2V0IGFjdGl2ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5fYWN0aXZlO1xuICB9XG4gIHBhdXNlKCkge1xuICAgIGlmICh0aGlzLl9hY3RpdmUpIHtcbiAgICAgIHRoaXMuX2lzUGF1c2VkID0gdHJ1ZTtcbiAgICAgIGxldCBpLCBsO1xuICAgICAgaWYgKHRoaXMuc2NvcGVzKSB7XG4gICAgICAgIGNvbnN0IHNjb3BlcyA9IHRoaXMuc2NvcGVzLnNsaWNlKCk7XG4gICAgICAgIGZvciAoaSA9IDAsIGwgPSBzY29wZXMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgICAgICAgc2NvcGVzW2ldLnBhdXNlKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGZvciAoaSA9IDAsIGwgPSB0aGlzLmVmZmVjdHMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgICAgIHRoaXMuZWZmZWN0c1tpXS5wYXVzZSgpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICAvKipcbiAgICogUmVzdW1lcyB0aGUgZWZmZWN0IHNjb3BlLCBpbmNsdWRpbmcgYWxsIGNoaWxkIHNjb3BlcyBhbmQgZWZmZWN0cy5cbiAgICovXG4gIHJlc3VtZSgpIHtcbiAgICBpZiAodGhpcy5fYWN0aXZlKSB7XG4gICAgICBpZiAodGhpcy5faXNQYXVzZWQpIHtcbiAgICAgICAgdGhpcy5faXNQYXVzZWQgPSBmYWxzZTtcbiAgICAgICAgbGV0IGksIGw7XG4gICAgICAgIGlmICh0aGlzLnNjb3Blcykge1xuICAgICAgICAgIGNvbnN0IHNjb3BlcyA9IHRoaXMuc2NvcGVzLnNsaWNlKCk7XG4gICAgICAgICAgZm9yIChpID0gMCwgbCA9IHNjb3Blcy5sZW5ndGg7IGkgPCBsOyBpKyspIHtcbiAgICAgICAgICAgIHNjb3Blc1tpXS5yZXN1bWUoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZWZmZWN0cyA9IHRoaXMuZWZmZWN0cy5zbGljZSgpO1xuICAgICAgICBmb3IgKGkgPSAwLCBsID0gZWZmZWN0cy5sZW5ndGg7IGkgPCBsOyBpKyspIHtcbiAgICAgICAgICBlZmZlY3RzW2ldLnJlc3VtZSgpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJ1bihmbikge1xuICAgIGlmICh0aGlzLl9hY3RpdmUpIHtcbiAgICAgIGNvbnN0IGN1cnJlbnRFZmZlY3RTY29wZSA9IGFjdGl2ZUVmZmVjdFNjb3BlO1xuICAgICAgdHJ5IHtcbiAgICAgICAgYWN0aXZlRWZmZWN0U2NvcGUgPSB0aGlzO1xuICAgICAgICByZXR1cm4gZm4oKTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIGFjdGl2ZUVmZmVjdFNjb3BlID0gY3VycmVudEVmZmVjdFNjb3BlO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB0aGlzLl93YXJuT25SdW4pIHtcbiAgICAgIHdhcm4oYGNhbm5vdCBydW4gYW4gaW5hY3RpdmUgZWZmZWN0IHNjb3BlLmApO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogVGhpcyBzaG91bGQgb25seSBiZSBjYWxsZWQgb24gbm9uLWRldGFjaGVkIHNjb3Blc1xuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIG9uKCkge1xuICAgIGlmICgrK3RoaXMuX29uID09PSAxKSB7XG4gICAgICB0aGlzLnByZXZTY29wZSA9IGFjdGl2ZUVmZmVjdFNjb3BlO1xuICAgICAgYWN0aXZlRWZmZWN0U2NvcGUgPSB0aGlzO1xuICAgIH1cbiAgfVxuICAvKipcbiAgICogVGhpcyBzaG91bGQgb25seSBiZSBjYWxsZWQgb24gbm9uLWRldGFjaGVkIHNjb3Blc1xuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIG9mZigpIHtcbiAgICBpZiAodGhpcy5fb24gPiAwICYmIC0tdGhpcy5fb24gPT09IDApIHtcbiAgICAgIGlmIChhY3RpdmVFZmZlY3RTY29wZSA9PT0gdGhpcykge1xuICAgICAgICBhY3RpdmVFZmZlY3RTY29wZSA9IHRoaXMucHJldlNjb3BlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbGV0IGN1cnJlbnQgPSBhY3RpdmVFZmZlY3RTY29wZTtcbiAgICAgICAgd2hpbGUgKGN1cnJlbnQpIHtcbiAgICAgICAgICBpZiAoY3VycmVudC5wcmV2U2NvcGUgPT09IHRoaXMpIHtcbiAgICAgICAgICAgIGN1cnJlbnQucHJldlNjb3BlID0gdGhpcy5wcmV2U2NvcGU7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgICAgY3VycmVudCA9IGN1cnJlbnQucHJldlNjb3BlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLnByZXZTY29wZSA9IHZvaWQgMDtcbiAgICB9XG4gIH1cbiAgc3RvcChmcm9tUGFyZW50KSB7XG4gICAgaWYgKHRoaXMuX2FjdGl2ZSkge1xuICAgICAgdGhpcy5fYWN0aXZlID0gZmFsc2U7XG4gICAgICBsZXQgaSwgbDtcbiAgICAgIGZvciAoaSA9IDAsIGwgPSB0aGlzLmVmZmVjdHMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG4gICAgICAgIHRoaXMuZWZmZWN0c1tpXS5zdG9wKCk7XG4gICAgICB9XG4gICAgICB0aGlzLmVmZmVjdHMubGVuZ3RoID0gMDtcbiAgICAgIGZvciAoaSA9IDAsIGwgPSB0aGlzLmNsZWFudXBzLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgICAgICB0aGlzLmNsZWFudXBzW2ldKCk7XG4gICAgICB9XG4gICAgICB0aGlzLmNsZWFudXBzLmxlbmd0aCA9IDA7XG4gICAgICBpZiAodGhpcy5zY29wZXMpIHtcbiAgICAgICAgY29uc3Qgc2NvcGVzID0gdGhpcy5zY29wZXMuc2xpY2UoKTtcbiAgICAgICAgZm9yIChpID0gMCwgbCA9IHNjb3Blcy5sZW5ndGg7IGkgPCBsOyBpKyspIHtcbiAgICAgICAgICBzY29wZXNbaV0uc3RvcCh0cnVlKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnNjb3Blcy5sZW5ndGggPSAwO1xuICAgICAgfVxuICAgICAgaWYgKCF0aGlzLmRldGFjaGVkICYmIHRoaXMucGFyZW50ICYmICFmcm9tUGFyZW50KSB7XG4gICAgICAgIGNvbnN0IGxhc3QgPSB0aGlzLnBhcmVudC5zY29wZXMucG9wKCk7XG4gICAgICAgIGlmIChsYXN0ICYmIGxhc3QgIT09IHRoaXMpIHtcbiAgICAgICAgICB0aGlzLnBhcmVudC5zY29wZXNbdGhpcy5pbmRleF0gPSBsYXN0O1xuICAgICAgICAgIGxhc3QuaW5kZXggPSB0aGlzLmluZGV4O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLnBhcmVudCA9IHZvaWQgMDtcbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIGVmZmVjdFNjb3BlKGRldGFjaGVkKSB7XG4gIHJldHVybiBuZXcgRWZmZWN0U2NvcGUoZGV0YWNoZWQpO1xufVxuZnVuY3Rpb24gZ2V0Q3VycmVudFNjb3BlKCkge1xuICByZXR1cm4gYWN0aXZlRWZmZWN0U2NvcGU7XG59XG5mdW5jdGlvbiBvblNjb3BlRGlzcG9zZShmbiwgZmFpbFNpbGVudGx5ID0gZmFsc2UpIHtcbiAgaWYgKGFjdGl2ZUVmZmVjdFNjb3BlKSB7XG4gICAgYWN0aXZlRWZmZWN0U2NvcGUuY2xlYW51cHMucHVzaChmbik7XG4gIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiAhZmFpbFNpbGVudGx5KSB7XG4gICAgd2FybihcbiAgICAgIGBvblNjb3BlRGlzcG9zZSgpIGlzIGNhbGxlZCB3aGVuIHRoZXJlIGlzIG5vIGFjdGl2ZSBlZmZlY3Qgc2NvcGUgdG8gYmUgYXNzb2NpYXRlZCB3aXRoLmBcbiAgICApO1xuICB9XG59XG5cbmxldCBhY3RpdmVTdWI7XG5jb25zdCBFZmZlY3RGbGFncyA9IHtcbiAgXCJBQ1RJVkVcIjogMSxcbiAgXCIxXCI6IFwiQUNUSVZFXCIsXG4gIFwiUlVOTklOR1wiOiAyLFxuICBcIjJcIjogXCJSVU5OSU5HXCIsXG4gIFwiVFJBQ0tJTkdcIjogNCxcbiAgXCI0XCI6IFwiVFJBQ0tJTkdcIixcbiAgXCJOT1RJRklFRFwiOiA4LFxuICBcIjhcIjogXCJOT1RJRklFRFwiLFxuICBcIkRJUlRZXCI6IDE2LFxuICBcIjE2XCI6IFwiRElSVFlcIixcbiAgXCJBTExPV19SRUNVUlNFXCI6IDMyLFxuICBcIjMyXCI6IFwiQUxMT1dfUkVDVVJTRVwiLFxuICBcIlBBVVNFRFwiOiA2NCxcbiAgXCI2NFwiOiBcIlBBVVNFRFwiLFxuICBcIkVWQUxVQVRFRFwiOiAxMjgsXG4gIFwiMTI4XCI6IFwiRVZBTFVBVEVEXCJcbn07XG5jb25zdCBwYXVzZWRRdWV1ZUVmZmVjdHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtTZXQoKTtcbmNsYXNzIFJlYWN0aXZlRWZmZWN0IHtcbiAgY29uc3RydWN0b3IoZm4pIHtcbiAgICB0aGlzLmZuID0gZm47XG4gICAgLyoqXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5kZXBzID0gdm9pZCAwO1xuICAgIC8qKlxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMuZGVwc1RhaWwgPSB2b2lkIDA7XG4gICAgLyoqXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5mbGFncyA9IDEgfCA0O1xuICAgIC8qKlxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMubmV4dCA9IHZvaWQgMDtcbiAgICAvKipcbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLmNsZWFudXAgPSB2b2lkIDA7XG4gICAgdGhpcy5zY2hlZHVsZXIgPSB2b2lkIDA7XG4gICAgaWYgKGFjdGl2ZUVmZmVjdFNjb3BlKSB7XG4gICAgICBpZiAoYWN0aXZlRWZmZWN0U2NvcGUuYWN0aXZlKSB7XG4gICAgICAgIGFjdGl2ZUVmZmVjdFNjb3BlLmVmZmVjdHMucHVzaCh0aGlzKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuZmxhZ3MgJj0gLTI7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHBhdXNlKCkge1xuICAgIHRoaXMuZmxhZ3MgfD0gNjQ7XG4gIH1cbiAgcmVzdW1lKCkge1xuICAgIGlmICh0aGlzLmZsYWdzICYgNjQpIHtcbiAgICAgIHRoaXMuZmxhZ3MgJj0gLTY1O1xuICAgICAgaWYgKHBhdXNlZFF1ZXVlRWZmZWN0cy5oYXModGhpcykpIHtcbiAgICAgICAgcGF1c2VkUXVldWVFZmZlY3RzLmRlbGV0ZSh0aGlzKTtcbiAgICAgICAgdGhpcy50cmlnZ2VyKCk7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIG5vdGlmeSgpIHtcbiAgICBpZiAodGhpcy5mbGFncyAmIDIgJiYgISh0aGlzLmZsYWdzICYgMzIpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICghKHRoaXMuZmxhZ3MgJiA4KSkge1xuICAgICAgYmF0Y2godGhpcyk7XG4gICAgfVxuICB9XG4gIHJ1bigpIHtcbiAgICBpZiAoISh0aGlzLmZsYWdzICYgMSkpIHtcbiAgICAgIHJldHVybiB0aGlzLmZuKCk7XG4gICAgfVxuICAgIHRoaXMuZmxhZ3MgfD0gMjtcbiAgICBjbGVhbnVwRWZmZWN0KHRoaXMpO1xuICAgIHByZXBhcmVEZXBzKHRoaXMpO1xuICAgIGNvbnN0IHByZXZFZmZlY3QgPSBhY3RpdmVTdWI7XG4gICAgY29uc3QgcHJldlNob3VsZFRyYWNrID0gc2hvdWxkVHJhY2s7XG4gICAgYWN0aXZlU3ViID0gdGhpcztcbiAgICBzaG91bGRUcmFjayA9IHRydWU7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiB0aGlzLmZuKCk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGFjdGl2ZVN1YiAhPT0gdGhpcykge1xuICAgICAgICB3YXJuKFxuICAgICAgICAgIFwiQWN0aXZlIGVmZmVjdCB3YXMgbm90IHJlc3RvcmVkIGNvcnJlY3RseSAtIHRoaXMgaXMgbGlrZWx5IGEgVnVlIGludGVybmFsIGJ1Zy5cIlxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgY2xlYW51cERlcHModGhpcyk7XG4gICAgICBhY3RpdmVTdWIgPSBwcmV2RWZmZWN0O1xuICAgICAgc2hvdWxkVHJhY2sgPSBwcmV2U2hvdWxkVHJhY2s7XG4gICAgICB0aGlzLmZsYWdzICY9IC0zO1xuICAgIH1cbiAgfVxuICBzdG9wKCkge1xuICAgIGlmICh0aGlzLmZsYWdzICYgMSkge1xuICAgICAgZm9yIChsZXQgbGluayA9IHRoaXMuZGVwczsgbGluazsgbGluayA9IGxpbmsubmV4dERlcCkge1xuICAgICAgICByZW1vdmVTdWIobGluayk7XG4gICAgICB9XG4gICAgICB0aGlzLmRlcHMgPSB0aGlzLmRlcHNUYWlsID0gdm9pZCAwO1xuICAgICAgY2xlYW51cEVmZmVjdCh0aGlzKTtcbiAgICAgIHRoaXMub25TdG9wICYmIHRoaXMub25TdG9wKCk7XG4gICAgICB0aGlzLmZsYWdzICY9IC0yO1xuICAgIH1cbiAgfVxuICB0cmlnZ2VyKCkge1xuICAgIGlmICh0aGlzLmZsYWdzICYgNjQpIHtcbiAgICAgIHBhdXNlZFF1ZXVlRWZmZWN0cy5hZGQodGhpcyk7XG4gICAgfSBlbHNlIGlmICh0aGlzLnNjaGVkdWxlcikge1xuICAgICAgdGhpcy5zY2hlZHVsZXIoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5ydW5JZkRpcnR5KCk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBAaW50ZXJuYWxcbiAgICovXG4gIHJ1bklmRGlydHkoKSB7XG4gICAgaWYgKGlzRGlydHkodGhpcykpIHtcbiAgICAgIHRoaXMucnVuKCk7XG4gICAgfVxuICB9XG4gIGdldCBkaXJ0eSgpIHtcbiAgICByZXR1cm4gaXNEaXJ0eSh0aGlzKTtcbiAgfVxufVxubGV0IGJhdGNoRGVwdGggPSAwO1xubGV0IGJhdGNoZWRTdWI7XG5sZXQgYmF0Y2hlZENvbXB1dGVkO1xuZnVuY3Rpb24gYmF0Y2goc3ViLCBpc0NvbXB1dGVkID0gZmFsc2UpIHtcbiAgc3ViLmZsYWdzIHw9IDg7XG4gIGlmIChpc0NvbXB1dGVkKSB7XG4gICAgc3ViLm5leHQgPSBiYXRjaGVkQ29tcHV0ZWQ7XG4gICAgYmF0Y2hlZENvbXB1dGVkID0gc3ViO1xuICAgIHJldHVybjtcbiAgfVxuICBzdWIubmV4dCA9IGJhdGNoZWRTdWI7XG4gIGJhdGNoZWRTdWIgPSBzdWI7XG59XG5mdW5jdGlvbiBzdGFydEJhdGNoKCkge1xuICBiYXRjaERlcHRoKys7XG59XG5mdW5jdGlvbiBlbmRCYXRjaCgpIHtcbiAgaWYgKC0tYmF0Y2hEZXB0aCA+IDApIHtcbiAgICByZXR1cm47XG4gIH1cbiAgaWYgKGJhdGNoZWRDb21wdXRlZCkge1xuICAgIGxldCBlID0gYmF0Y2hlZENvbXB1dGVkO1xuICAgIGJhdGNoZWRDb21wdXRlZCA9IHZvaWQgMDtcbiAgICB3aGlsZSAoZSkge1xuICAgICAgY29uc3QgbmV4dCA9IGUubmV4dDtcbiAgICAgIGUubmV4dCA9IHZvaWQgMDtcbiAgICAgIGUuZmxhZ3MgJj0gLTk7XG4gICAgICBlID0gbmV4dDtcbiAgICB9XG4gIH1cbiAgbGV0IGVycm9yO1xuICB3aGlsZSAoYmF0Y2hlZFN1Yikge1xuICAgIGxldCBlID0gYmF0Y2hlZFN1YjtcbiAgICBiYXRjaGVkU3ViID0gdm9pZCAwO1xuICAgIHdoaWxlIChlKSB7XG4gICAgICBjb25zdCBuZXh0ID0gZS5uZXh0O1xuICAgICAgZS5uZXh0ID0gdm9pZCAwO1xuICAgICAgZS5mbGFncyAmPSAtOTtcbiAgICAgIGlmIChlLmZsYWdzICYgMSkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIDtcbiAgICAgICAgICBlLnRyaWdnZXIoKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgaWYgKCFlcnJvcikgZXJyb3IgPSBlcnI7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGUgPSBuZXh0O1xuICAgIH1cbiAgfVxuICBpZiAoZXJyb3IpIHRocm93IGVycm9yO1xufVxuZnVuY3Rpb24gcHJlcGFyZURlcHMoc3ViKSB7XG4gIGZvciAobGV0IGxpbmsgPSBzdWIuZGVwczsgbGluazsgbGluayA9IGxpbmsubmV4dERlcCkge1xuICAgIGxpbmsudmVyc2lvbiA9IC0xO1xuICAgIGxpbmsucHJldkFjdGl2ZUxpbmsgPSBsaW5rLmRlcC5hY3RpdmVMaW5rO1xuICAgIGxpbmsuZGVwLmFjdGl2ZUxpbmsgPSBsaW5rO1xuICB9XG59XG5mdW5jdGlvbiBjbGVhbnVwRGVwcyhzdWIpIHtcbiAgbGV0IGhlYWQ7XG4gIGxldCB0YWlsID0gc3ViLmRlcHNUYWlsO1xuICBsZXQgbGluayA9IHRhaWw7XG4gIHdoaWxlIChsaW5rKSB7XG4gICAgY29uc3QgcHJldiA9IGxpbmsucHJldkRlcDtcbiAgICBpZiAobGluay52ZXJzaW9uID09PSAtMSkge1xuICAgICAgaWYgKGxpbmsgPT09IHRhaWwpIHRhaWwgPSBwcmV2O1xuICAgICAgcmVtb3ZlU3ViKGxpbmspO1xuICAgICAgcmVtb3ZlRGVwKGxpbmspO1xuICAgIH0gZWxzZSB7XG4gICAgICBoZWFkID0gbGluaztcbiAgICB9XG4gICAgbGluay5kZXAuYWN0aXZlTGluayA9IGxpbmsucHJldkFjdGl2ZUxpbms7XG4gICAgbGluay5wcmV2QWN0aXZlTGluayA9IHZvaWQgMDtcbiAgICBsaW5rID0gcHJldjtcbiAgfVxuICBzdWIuZGVwcyA9IGhlYWQ7XG4gIHN1Yi5kZXBzVGFpbCA9IHRhaWw7XG59XG5mdW5jdGlvbiBpc0RpcnR5KHN1Yikge1xuICBmb3IgKGxldCBsaW5rID0gc3ViLmRlcHM7IGxpbms7IGxpbmsgPSBsaW5rLm5leHREZXApIHtcbiAgICBpZiAobGluay5kZXAudmVyc2lvbiAhPT0gbGluay52ZXJzaW9uIHx8IGxpbmsuZGVwLmNvbXB1dGVkICYmIChyZWZyZXNoQ29tcHV0ZWQobGluay5kZXAuY29tcHV0ZWQpIHx8IGxpbmsuZGVwLnZlcnNpb24gIT09IGxpbmsudmVyc2lvbikpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgfVxuICBpZiAoc3ViLl9kaXJ0eSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIHJlZnJlc2hDb21wdXRlZChjb21wdXRlZCkge1xuICBpZiAoY29tcHV0ZWQuZmxhZ3MgJiA0ICYmICEoY29tcHV0ZWQuZmxhZ3MgJiAxNikpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29tcHV0ZWQuZmxhZ3MgJj0gLTE3O1xuICBpZiAoY29tcHV0ZWQuZ2xvYmFsVmVyc2lvbiA9PT0gZ2xvYmFsVmVyc2lvbikge1xuICAgIHJldHVybjtcbiAgfVxuICBjb21wdXRlZC5nbG9iYWxWZXJzaW9uID0gZ2xvYmFsVmVyc2lvbjtcbiAgaWYgKCFjb21wdXRlZC5pc1NTUiAmJiBjb21wdXRlZC5mbGFncyAmIDEyOCAmJiAoIWNvbXB1dGVkLmRlcHMgJiYgIWNvbXB1dGVkLl9kaXJ0eSB8fCAhaXNEaXJ0eShjb21wdXRlZCkpKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbXB1dGVkLmZsYWdzIHw9IDI7XG4gIGNvbnN0IGRlcCA9IGNvbXB1dGVkLmRlcDtcbiAgY29uc3QgcHJldlN1YiA9IGFjdGl2ZVN1YjtcbiAgY29uc3QgcHJldlNob3VsZFRyYWNrID0gc2hvdWxkVHJhY2s7XG4gIGFjdGl2ZVN1YiA9IGNvbXB1dGVkO1xuICBzaG91bGRUcmFjayA9IHRydWU7XG4gIHRyeSB7XG4gICAgcHJlcGFyZURlcHMoY29tcHV0ZWQpO1xuICAgIGNvbnN0IHZhbHVlID0gY29tcHV0ZWQuZm4oY29tcHV0ZWQuX3ZhbHVlKTtcbiAgICBpZiAoZGVwLnZlcnNpb24gPT09IDAgfHwgaGFzQ2hhbmdlZCh2YWx1ZSwgY29tcHV0ZWQuX3ZhbHVlKSkge1xuICAgICAgY29tcHV0ZWQuZmxhZ3MgfD0gMTI4O1xuICAgICAgY29tcHV0ZWQuX3ZhbHVlID0gdmFsdWU7XG4gICAgICBkZXAudmVyc2lvbisrO1xuICAgIH1cbiAgfSBjYXRjaCAoZXJyKSB7XG4gICAgZGVwLnZlcnNpb24rKztcbiAgICB0aHJvdyBlcnI7XG4gIH0gZmluYWxseSB7XG4gICAgYWN0aXZlU3ViID0gcHJldlN1YjtcbiAgICBzaG91bGRUcmFjayA9IHByZXZTaG91bGRUcmFjaztcbiAgICBjbGVhbnVwRGVwcyhjb21wdXRlZCk7XG4gICAgY29tcHV0ZWQuZmxhZ3MgJj0gLTM7XG4gIH1cbn1cbmZ1bmN0aW9uIHJlbW92ZVN1YihsaW5rLCBzb2Z0ID0gZmFsc2UpIHtcbiAgY29uc3QgeyBkZXAsIHByZXZTdWIsIG5leHRTdWIgfSA9IGxpbms7XG4gIGlmIChwcmV2U3ViKSB7XG4gICAgcHJldlN1Yi5uZXh0U3ViID0gbmV4dFN1YjtcbiAgICBsaW5rLnByZXZTdWIgPSB2b2lkIDA7XG4gIH1cbiAgaWYgKG5leHRTdWIpIHtcbiAgICBuZXh0U3ViLnByZXZTdWIgPSBwcmV2U3ViO1xuICAgIGxpbmsubmV4dFN1YiA9IHZvaWQgMDtcbiAgfVxuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBkZXAuc3Vic0hlYWQgPT09IGxpbmspIHtcbiAgICBkZXAuc3Vic0hlYWQgPSBuZXh0U3ViO1xuICB9XG4gIGlmIChkZXAuc3VicyA9PT0gbGluaykge1xuICAgIGRlcC5zdWJzID0gcHJldlN1YjtcbiAgICBpZiAoIXByZXZTdWIgJiYgZGVwLmNvbXB1dGVkKSB7XG4gICAgICBkZXAuY29tcHV0ZWQuZmxhZ3MgJj0gLTU7XG4gICAgICBmb3IgKGxldCBsID0gZGVwLmNvbXB1dGVkLmRlcHM7IGw7IGwgPSBsLm5leHREZXApIHtcbiAgICAgICAgcmVtb3ZlU3ViKGwsIHRydWUpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBpZiAoIXNvZnQgJiYgIS0tZGVwLnNjICYmIGRlcC5tYXApIHtcbiAgICBkZXAubWFwLmRlbGV0ZShkZXAua2V5KTtcbiAgfVxufVxuZnVuY3Rpb24gcmVtb3ZlRGVwKGxpbmspIHtcbiAgY29uc3QgeyBwcmV2RGVwLCBuZXh0RGVwIH0gPSBsaW5rO1xuICBpZiAocHJldkRlcCkge1xuICAgIHByZXZEZXAubmV4dERlcCA9IG5leHREZXA7XG4gICAgbGluay5wcmV2RGVwID0gdm9pZCAwO1xuICB9XG4gIGlmIChuZXh0RGVwKSB7XG4gICAgbmV4dERlcC5wcmV2RGVwID0gcHJldkRlcDtcbiAgICBsaW5rLm5leHREZXAgPSB2b2lkIDA7XG4gIH1cbn1cbmZ1bmN0aW9uIGVmZmVjdChmbiwgb3B0aW9ucykge1xuICBpZiAoZm4uZWZmZWN0IGluc3RhbmNlb2YgUmVhY3RpdmVFZmZlY3QpIHtcbiAgICBmbiA9IGZuLmVmZmVjdC5mbjtcbiAgfVxuICBjb25zdCBlID0gbmV3IFJlYWN0aXZlRWZmZWN0KGZuKTtcbiAgaWYgKG9wdGlvbnMpIHtcbiAgICBleHRlbmQoZSwgb3B0aW9ucyk7XG4gIH1cbiAgdHJ5IHtcbiAgICBlLnJ1bigpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICBlLnN0b3AoKTtcbiAgICB0aHJvdyBlcnI7XG4gIH1cbiAgY29uc3QgcnVubmVyID0gZS5ydW4uYmluZChlKTtcbiAgcnVubmVyLmVmZmVjdCA9IGU7XG4gIHJldHVybiBydW5uZXI7XG59XG5mdW5jdGlvbiBzdG9wKHJ1bm5lcikge1xuICBydW5uZXIuZWZmZWN0LnN0b3AoKTtcbn1cbmxldCBzaG91bGRUcmFjayA9IHRydWU7XG5jb25zdCB0cmFja1N0YWNrID0gW107XG5mdW5jdGlvbiBwYXVzZVRyYWNraW5nKCkge1xuICB0cmFja1N0YWNrLnB1c2goc2hvdWxkVHJhY2spO1xuICBzaG91bGRUcmFjayA9IGZhbHNlO1xufVxuZnVuY3Rpb24gZW5hYmxlVHJhY2tpbmcoKSB7XG4gIHRyYWNrU3RhY2sucHVzaChzaG91bGRUcmFjayk7XG4gIHNob3VsZFRyYWNrID0gdHJ1ZTtcbn1cbmZ1bmN0aW9uIHJlc2V0VHJhY2tpbmcoKSB7XG4gIGNvbnN0IGxhc3QgPSB0cmFja1N0YWNrLnBvcCgpO1xuICBzaG91bGRUcmFjayA9IGxhc3QgPT09IHZvaWQgMCA/IHRydWUgOiBsYXN0O1xufVxuZnVuY3Rpb24gb25FZmZlY3RDbGVhbnVwKGZuLCBmYWlsU2lsZW50bHkgPSBmYWxzZSkge1xuICBpZiAoYWN0aXZlU3ViIGluc3RhbmNlb2YgUmVhY3RpdmVFZmZlY3QpIHtcbiAgICBhY3RpdmVTdWIuY2xlYW51cCA9IGZuO1xuICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWZhaWxTaWxlbnRseSkge1xuICAgIHdhcm4oXG4gICAgICBgb25FZmZlY3RDbGVhbnVwKCkgd2FzIGNhbGxlZCB3aGVuIHRoZXJlIHdhcyBubyBhY3RpdmUgZWZmZWN0IHRvIGFzc29jaWF0ZSB3aXRoLmBcbiAgICApO1xuICB9XG59XG5mdW5jdGlvbiBjbGVhbnVwRWZmZWN0KGUpIHtcbiAgY29uc3QgeyBjbGVhbnVwIH0gPSBlO1xuICBlLmNsZWFudXAgPSB2b2lkIDA7XG4gIGlmIChjbGVhbnVwKSB7XG4gICAgY29uc3QgcHJldlN1YiA9IGFjdGl2ZVN1YjtcbiAgICBhY3RpdmVTdWIgPSB2b2lkIDA7XG4gICAgdHJ5IHtcbiAgICAgIGNsZWFudXAoKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgYWN0aXZlU3ViID0gcHJldlN1YjtcbiAgICB9XG4gIH1cbn1cblxubGV0IGdsb2JhbFZlcnNpb24gPSAwO1xuY2xhc3MgTGluayB7XG4gIGNvbnN0cnVjdG9yKHN1YiwgZGVwKSB7XG4gICAgdGhpcy5zdWIgPSBzdWI7XG4gICAgdGhpcy5kZXAgPSBkZXA7XG4gICAgdGhpcy52ZXJzaW9uID0gZGVwLnZlcnNpb247XG4gICAgdGhpcy5uZXh0RGVwID0gdGhpcy5wcmV2RGVwID0gdGhpcy5uZXh0U3ViID0gdGhpcy5wcmV2U3ViID0gdGhpcy5wcmV2QWN0aXZlTGluayA9IHZvaWQgMDtcbiAgfVxufVxuY2xhc3MgRGVwIHtcbiAgLy8gVE9ETyBpc29sYXRlZERlY2xhcmF0aW9ucyBcIl9fdl9za2lwXCJcbiAgY29uc3RydWN0b3IoY29tcHV0ZWQpIHtcbiAgICB0aGlzLmNvbXB1dGVkID0gY29tcHV0ZWQ7XG4gICAgdGhpcy52ZXJzaW9uID0gMDtcbiAgICAvKipcbiAgICAgKiBMaW5rIGJldHdlZW4gdGhpcyBkZXAgYW5kIHRoZSBjdXJyZW50IGFjdGl2ZSBlZmZlY3RcbiAgICAgKi9cbiAgICB0aGlzLmFjdGl2ZUxpbmsgPSB2b2lkIDA7XG4gICAgLyoqXG4gICAgICogRG91Ymx5IGxpbmtlZCBsaXN0IHJlcHJlc2VudGluZyB0aGUgc3Vic2NyaWJpbmcgZWZmZWN0cyAodGFpbClcbiAgICAgKi9cbiAgICB0aGlzLnN1YnMgPSB2b2lkIDA7XG4gICAgLyoqXG4gICAgICogRm9yIG9iamVjdCBwcm9wZXJ0eSBkZXBzIGNsZWFudXBcbiAgICAgKi9cbiAgICB0aGlzLm1hcCA9IHZvaWQgMDtcbiAgICB0aGlzLmtleSA9IHZvaWQgMDtcbiAgICAvKipcbiAgICAgKiBTdWJzY3JpYmVyIGNvdW50ZXJcbiAgICAgKi9cbiAgICB0aGlzLnNjID0gMDtcbiAgICAvKipcbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLl9fdl9za2lwID0gdHJ1ZTtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgdGhpcy5zdWJzSGVhZCA9IHZvaWQgMDtcbiAgICB9XG4gIH1cbiAgdHJhY2soZGVidWdJbmZvKSB7XG4gICAgaWYgKCFhY3RpdmVTdWIgfHwgIXNob3VsZFRyYWNrIHx8IGFjdGl2ZVN1YiA9PT0gdGhpcy5jb21wdXRlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBsZXQgbGluayA9IHRoaXMuYWN0aXZlTGluaztcbiAgICBpZiAobGluayA9PT0gdm9pZCAwIHx8IGxpbmsuc3ViICE9PSBhY3RpdmVTdWIpIHtcbiAgICAgIGxpbmsgPSB0aGlzLmFjdGl2ZUxpbmsgPSBuZXcgTGluayhhY3RpdmVTdWIsIHRoaXMpO1xuICAgICAgaWYgKCFhY3RpdmVTdWIuZGVwcykge1xuICAgICAgICBhY3RpdmVTdWIuZGVwcyA9IGFjdGl2ZVN1Yi5kZXBzVGFpbCA9IGxpbms7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBsaW5rLnByZXZEZXAgPSBhY3RpdmVTdWIuZGVwc1RhaWw7XG4gICAgICAgIGFjdGl2ZVN1Yi5kZXBzVGFpbC5uZXh0RGVwID0gbGluaztcbiAgICAgICAgYWN0aXZlU3ViLmRlcHNUYWlsID0gbGluaztcbiAgICAgIH1cbiAgICAgIGFkZFN1YihsaW5rKTtcbiAgICB9IGVsc2UgaWYgKGxpbmsudmVyc2lvbiA9PT0gLTEpIHtcbiAgICAgIGxpbmsudmVyc2lvbiA9IHRoaXMudmVyc2lvbjtcbiAgICAgIGlmIChsaW5rLm5leHREZXApIHtcbiAgICAgICAgY29uc3QgbmV4dCA9IGxpbmsubmV4dERlcDtcbiAgICAgICAgbmV4dC5wcmV2RGVwID0gbGluay5wcmV2RGVwO1xuICAgICAgICBpZiAobGluay5wcmV2RGVwKSB7XG4gICAgICAgICAgbGluay5wcmV2RGVwLm5leHREZXAgPSBuZXh0O1xuICAgICAgICB9XG4gICAgICAgIGxpbmsucHJldkRlcCA9IGFjdGl2ZVN1Yi5kZXBzVGFpbDtcbiAgICAgICAgbGluay5uZXh0RGVwID0gdm9pZCAwO1xuICAgICAgICBhY3RpdmVTdWIuZGVwc1RhaWwubmV4dERlcCA9IGxpbms7XG4gICAgICAgIGFjdGl2ZVN1Yi5kZXBzVGFpbCA9IGxpbms7XG4gICAgICAgIGlmIChhY3RpdmVTdWIuZGVwcyA9PT0gbGluaykge1xuICAgICAgICAgIGFjdGl2ZVN1Yi5kZXBzID0gbmV4dDtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBhY3RpdmVTdWIub25UcmFjaykge1xuICAgICAgYWN0aXZlU3ViLm9uVHJhY2soXG4gICAgICAgIGV4dGVuZChcbiAgICAgICAgICB7XG4gICAgICAgICAgICBlZmZlY3Q6IGFjdGl2ZVN1YlxuICAgICAgICAgIH0sXG4gICAgICAgICAgZGVidWdJbmZvXG4gICAgICAgIClcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBsaW5rO1xuICB9XG4gIHRyaWdnZXIoZGVidWdJbmZvKSB7XG4gICAgdGhpcy52ZXJzaW9uKys7XG4gICAgZ2xvYmFsVmVyc2lvbisrO1xuICAgIHRoaXMubm90aWZ5KGRlYnVnSW5mbyk7XG4gIH1cbiAgbm90aWZ5KGRlYnVnSW5mbykge1xuICAgIHN0YXJ0QmF0Y2goKTtcbiAgICB0cnkge1xuICAgICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgICAgZm9yIChsZXQgaGVhZCA9IHRoaXMuc3Vic0hlYWQ7IGhlYWQ7IGhlYWQgPSBoZWFkLm5leHRTdWIpIHtcbiAgICAgICAgICBpZiAoaGVhZC5zdWIub25UcmlnZ2VyICYmICEoaGVhZC5zdWIuZmxhZ3MgJiA4KSkge1xuICAgICAgICAgICAgaGVhZC5zdWIub25UcmlnZ2VyKFxuICAgICAgICAgICAgICBleHRlbmQoXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgZWZmZWN0OiBoZWFkLnN1YlxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgZGVidWdJbmZvXG4gICAgICAgICAgICAgIClcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBmb3IgKGxldCBsaW5rID0gdGhpcy5zdWJzOyBsaW5rOyBsaW5rID0gbGluay5wcmV2U3ViKSB7XG4gICAgICAgIGlmIChsaW5rLnN1Yi5ub3RpZnkoKSkge1xuICAgICAgICAgIDtcbiAgICAgICAgICBsaW5rLnN1Yi5kZXAubm90aWZ5KCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGZpbmFsbHkge1xuICAgICAgZW5kQmF0Y2goKTtcbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIGFkZFN1YihsaW5rKSB7XG4gIGxpbmsuZGVwLnNjKys7XG4gIGlmIChsaW5rLnN1Yi5mbGFncyAmIDQpIHtcbiAgICBjb25zdCBjb21wdXRlZCA9IGxpbmsuZGVwLmNvbXB1dGVkO1xuICAgIGlmIChjb21wdXRlZCAmJiAhbGluay5kZXAuc3Vicykge1xuICAgICAgY29tcHV0ZWQuZmxhZ3MgfD0gNCB8IDE2O1xuICAgICAgZm9yIChsZXQgbCA9IGNvbXB1dGVkLmRlcHM7IGw7IGwgPSBsLm5leHREZXApIHtcbiAgICAgICAgYWRkU3ViKGwpO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBjdXJyZW50VGFpbCA9IGxpbmsuZGVwLnN1YnM7XG4gICAgaWYgKGN1cnJlbnRUYWlsICE9PSBsaW5rKSB7XG4gICAgICBsaW5rLnByZXZTdWIgPSBjdXJyZW50VGFpbDtcbiAgICAgIGlmIChjdXJyZW50VGFpbCkgY3VycmVudFRhaWwubmV4dFN1YiA9IGxpbms7XG4gICAgfVxuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIGxpbmsuZGVwLnN1YnNIZWFkID09PSB2b2lkIDApIHtcbiAgICAgIGxpbmsuZGVwLnN1YnNIZWFkID0gbGluaztcbiAgICB9XG4gICAgbGluay5kZXAuc3VicyA9IGxpbms7XG4gIH1cbn1cbmNvbnN0IHRhcmdldE1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuY29uc3QgSVRFUkFURV9LRVkgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sKFxuICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gXCJPYmplY3QgaXRlcmF0ZVwiIDogXCJcIlxuKTtcbmNvbnN0IE1BUF9LRVlfSVRFUkFURV9LRVkgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sKFxuICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gXCJNYXAga2V5cyBpdGVyYXRlXCIgOiBcIlwiXG4pO1xuY29uc3QgQVJSQVlfSVRFUkFURV9LRVkgPSAvKiBAX19QVVJFX18gKi8gU3ltYm9sKFxuICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpID8gXCJBcnJheSBpdGVyYXRlXCIgOiBcIlwiXG4pO1xuZnVuY3Rpb24gdHJhY2sodGFyZ2V0LCB0eXBlLCBrZXkpIHtcbiAgaWYgKHNob3VsZFRyYWNrICYmIGFjdGl2ZVN1Yikge1xuICAgIGxldCBkZXBzTWFwID0gdGFyZ2V0TWFwLmdldCh0YXJnZXQpO1xuICAgIGlmICghZGVwc01hcCkge1xuICAgICAgdGFyZ2V0TWFwLnNldCh0YXJnZXQsIGRlcHNNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpKTtcbiAgICB9XG4gICAgbGV0IGRlcCA9IGRlcHNNYXAuZ2V0KGtleSk7XG4gICAgaWYgKCFkZXApIHtcbiAgICAgIGRlcHNNYXAuc2V0KGtleSwgZGVwID0gbmV3IERlcCgpKTtcbiAgICAgIGRlcC5tYXAgPSBkZXBzTWFwO1xuICAgICAgZGVwLmtleSA9IGtleTtcbiAgICB9XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgIGRlcC50cmFjayh7XG4gICAgICAgIHRhcmdldCxcbiAgICAgICAgdHlwZSxcbiAgICAgICAga2V5XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgZGVwLnRyYWNrKCk7XG4gICAgfVxuICB9XG59XG5mdW5jdGlvbiB0cmlnZ2VyKHRhcmdldCwgdHlwZSwga2V5LCBuZXdWYWx1ZSwgb2xkVmFsdWUsIG9sZFRhcmdldCkge1xuICBjb25zdCBkZXBzTWFwID0gdGFyZ2V0TWFwLmdldCh0YXJnZXQpO1xuICBpZiAoIWRlcHNNYXApIHtcbiAgICBnbG9iYWxWZXJzaW9uKys7XG4gICAgcmV0dXJuO1xuICB9XG4gIGNvbnN0IHJ1biA9IChkZXApID0+IHtcbiAgICBpZiAoZGVwKSB7XG4gICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICBkZXAudHJpZ2dlcih7XG4gICAgICAgICAgdGFyZ2V0LFxuICAgICAgICAgIHR5cGUsXG4gICAgICAgICAga2V5LFxuICAgICAgICAgIG5ld1ZhbHVlLFxuICAgICAgICAgIG9sZFZhbHVlLFxuICAgICAgICAgIG9sZFRhcmdldFxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGRlcC50cmlnZ2VyKCk7XG4gICAgICB9XG4gICAgfVxuICB9O1xuICBzdGFydEJhdGNoKCk7XG4gIGlmICh0eXBlID09PSBcImNsZWFyXCIpIHtcbiAgICBkZXBzTWFwLmZvckVhY2gocnVuKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCB0YXJnZXRJc0FycmF5ID0gaXNBcnJheSh0YXJnZXQpO1xuICAgIGNvbnN0IGlzQXJyYXlJbmRleCA9IHRhcmdldElzQXJyYXkgJiYgaXNJbnRlZ2VyS2V5KGtleSk7XG4gICAgaWYgKHRhcmdldElzQXJyYXkgJiYga2V5ID09PSBcImxlbmd0aFwiKSB7XG4gICAgICBjb25zdCBuZXdMZW5ndGggPSBOdW1iZXIobmV3VmFsdWUpO1xuICAgICAgZGVwc01hcC5mb3JFYWNoKChkZXAsIGtleTIpID0+IHtcbiAgICAgICAgaWYgKGtleTIgPT09IFwibGVuZ3RoXCIgfHwga2V5MiA9PT0gQVJSQVlfSVRFUkFURV9LRVkgfHwgIWlzU3ltYm9sKGtleTIpICYmIGtleTIgPj0gbmV3TGVuZ3RoKSB7XG4gICAgICAgICAgcnVuKGRlcCk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBpZiAoa2V5ICE9PSB2b2lkIDAgfHwgZGVwc01hcC5oYXModm9pZCAwKSkge1xuICAgICAgICBydW4oZGVwc01hcC5nZXQoa2V5KSk7XG4gICAgICB9XG4gICAgICBpZiAoaXNBcnJheUluZGV4KSB7XG4gICAgICAgIHJ1bihkZXBzTWFwLmdldChBUlJBWV9JVEVSQVRFX0tFWSkpO1xuICAgICAgfVxuICAgICAgc3dpdGNoICh0eXBlKSB7XG4gICAgICAgIGNhc2UgXCJhZGRcIjpcbiAgICAgICAgICBpZiAoIXRhcmdldElzQXJyYXkpIHtcbiAgICAgICAgICAgIHJ1bihkZXBzTWFwLmdldChJVEVSQVRFX0tFWSkpO1xuICAgICAgICAgICAgaWYgKGlzTWFwKHRhcmdldCkpIHtcbiAgICAgICAgICAgICAgcnVuKGRlcHNNYXAuZ2V0KE1BUF9LRVlfSVRFUkFURV9LRVkpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2UgaWYgKGlzQXJyYXlJbmRleCkge1xuICAgICAgICAgICAgcnVuKGRlcHNNYXAuZ2V0KFwibGVuZ3RoXCIpKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJkZWxldGVcIjpcbiAgICAgICAgICBpZiAoIXRhcmdldElzQXJyYXkpIHtcbiAgICAgICAgICAgIHJ1bihkZXBzTWFwLmdldChJVEVSQVRFX0tFWSkpO1xuICAgICAgICAgICAgaWYgKGlzTWFwKHRhcmdldCkpIHtcbiAgICAgICAgICAgICAgcnVuKGRlcHNNYXAuZ2V0KE1BUF9LRVlfSVRFUkFURV9LRVkpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJzZXRcIjpcbiAgICAgICAgICBpZiAoaXNNYXAodGFyZ2V0KSkge1xuICAgICAgICAgICAgcnVuKGRlcHNNYXAuZ2V0KElURVJBVEVfS0VZKSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBlbmRCYXRjaCgpO1xufVxuZnVuY3Rpb24gZ2V0RGVwRnJvbVJlYWN0aXZlKG9iamVjdCwga2V5KSB7XG4gIGNvbnN0IGRlcE1hcCA9IHRhcmdldE1hcC5nZXQob2JqZWN0KTtcbiAgcmV0dXJuIGRlcE1hcCAmJiBkZXBNYXAuZ2V0KGtleSk7XG59XG5cbmZ1bmN0aW9uIHJlYWN0aXZlUmVhZEFycmF5KGFycmF5KSB7XG4gIGNvbnN0IHJhdyA9IHRvUmF3KGFycmF5KTtcbiAgaWYgKHJhdyA9PT0gYXJyYXkpIHJldHVybiByYXc7XG4gIHRyYWNrKHJhdywgXCJpdGVyYXRlXCIsIEFSUkFZX0lURVJBVEVfS0VZKTtcbiAgcmV0dXJuIGlzU2hhbGxvdyhhcnJheSkgPyByYXcgOiByYXcubWFwKHRvUmVhY3RpdmUpO1xufVxuZnVuY3Rpb24gc2hhbGxvd1JlYWRBcnJheShhcnIpIHtcbiAgdHJhY2soYXJyID0gdG9SYXcoYXJyKSwgXCJpdGVyYXRlXCIsIEFSUkFZX0lURVJBVEVfS0VZKTtcbiAgcmV0dXJuIGFycjtcbn1cbmZ1bmN0aW9uIHRvV3JhcHBlZCh0YXJnZXQsIGl0ZW0pIHtcbiAgaWYgKGlzUmVhZG9ubHkodGFyZ2V0KSkge1xuICAgIHJldHVybiBpc1JlYWN0aXZlKHRhcmdldCkgPyB0b1JlYWRvbmx5KHRvUmVhY3RpdmUoaXRlbSkpIDogdG9SZWFkb25seShpdGVtKTtcbiAgfVxuICByZXR1cm4gdG9SZWFjdGl2ZShpdGVtKTtcbn1cbmNvbnN0IGFycmF5SW5zdHJ1bWVudGF0aW9ucyA9IHtcbiAgX19wcm90b19fOiBudWxsLFxuICBbU3ltYm9sLml0ZXJhdG9yXSgpIHtcbiAgICByZXR1cm4gaXRlcmF0b3IodGhpcywgU3ltYm9sLml0ZXJhdG9yLCAoaXRlbSkgPT4gdG9XcmFwcGVkKHRoaXMsIGl0ZW0pKTtcbiAgfSxcbiAgY29uY2F0KC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gcmVhY3RpdmVSZWFkQXJyYXkodGhpcykuY29uY2F0KFxuICAgICAgLi4uYXJncy5tYXAoKHgpID0+IGlzQXJyYXkoeCkgPyByZWFjdGl2ZVJlYWRBcnJheSh4KSA6IHgpXG4gICAgKTtcbiAgfSxcbiAgZW50cmllcygpIHtcbiAgICByZXR1cm4gaXRlcmF0b3IodGhpcywgXCJlbnRyaWVzXCIsICh2YWx1ZSkgPT4ge1xuICAgICAgdmFsdWVbMV0gPSB0b1dyYXBwZWQodGhpcywgdmFsdWVbMV0pO1xuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH0pO1xuICB9LFxuICBldmVyeShmbiwgdGhpc0FyZykge1xuICAgIHJldHVybiBhcHBseSh0aGlzLCBcImV2ZXJ5XCIsIGZuLCB0aGlzQXJnLCB2b2lkIDAsIGFyZ3VtZW50cyk7XG4gIH0sXG4gIGZpbHRlcihmbiwgdGhpc0FyZykge1xuICAgIHJldHVybiBhcHBseShcbiAgICAgIHRoaXMsXG4gICAgICBcImZpbHRlclwiLFxuICAgICAgZm4sXG4gICAgICB0aGlzQXJnLFxuICAgICAgKHYpID0+IHYubWFwKChpdGVtKSA9PiB0b1dyYXBwZWQodGhpcywgaXRlbSkpLFxuICAgICAgYXJndW1lbnRzXG4gICAgKTtcbiAgfSxcbiAgZmluZChmbiwgdGhpc0FyZykge1xuICAgIHJldHVybiBhcHBseShcbiAgICAgIHRoaXMsXG4gICAgICBcImZpbmRcIixcbiAgICAgIGZuLFxuICAgICAgdGhpc0FyZyxcbiAgICAgIChpdGVtKSA9PiB0b1dyYXBwZWQodGhpcywgaXRlbSksXG4gICAgICBhcmd1bWVudHNcbiAgICApO1xuICB9LFxuICBmaW5kSW5kZXgoZm4sIHRoaXNBcmcpIHtcbiAgICByZXR1cm4gYXBwbHkodGhpcywgXCJmaW5kSW5kZXhcIiwgZm4sIHRoaXNBcmcsIHZvaWQgMCwgYXJndW1lbnRzKTtcbiAgfSxcbiAgZmluZExhc3QoZm4sIHRoaXNBcmcpIHtcbiAgICByZXR1cm4gYXBwbHkoXG4gICAgICB0aGlzLFxuICAgICAgXCJmaW5kTGFzdFwiLFxuICAgICAgZm4sXG4gICAgICB0aGlzQXJnLFxuICAgICAgKGl0ZW0pID0+IHRvV3JhcHBlZCh0aGlzLCBpdGVtKSxcbiAgICAgIGFyZ3VtZW50c1xuICAgICk7XG4gIH0sXG4gIGZpbmRMYXN0SW5kZXgoZm4sIHRoaXNBcmcpIHtcbiAgICByZXR1cm4gYXBwbHkodGhpcywgXCJmaW5kTGFzdEluZGV4XCIsIGZuLCB0aGlzQXJnLCB2b2lkIDAsIGFyZ3VtZW50cyk7XG4gIH0sXG4gIC8vIGZsYXQsIGZsYXRNYXAgY291bGQgYmVuZWZpdCBmcm9tIEFSUkFZX0lURVJBVEUgYnV0IGFyZSBub3Qgc3RyYWlnaHQtZm9yd2FyZCB0byBpbXBsZW1lbnRcbiAgZm9yRWFjaChmbiwgdGhpc0FyZykge1xuICAgIHJldHVybiBhcHBseSh0aGlzLCBcImZvckVhY2hcIiwgZm4sIHRoaXNBcmcsIHZvaWQgMCwgYXJndW1lbnRzKTtcbiAgfSxcbiAgaW5jbHVkZXMoLi4uYXJncykge1xuICAgIHJldHVybiBzZWFyY2hQcm94eSh0aGlzLCBcImluY2x1ZGVzXCIsIGFyZ3MpO1xuICB9LFxuICBpbmRleE9mKC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gc2VhcmNoUHJveHkodGhpcywgXCJpbmRleE9mXCIsIGFyZ3MpO1xuICB9LFxuICBqb2luKHNlcGFyYXRvcikge1xuICAgIHJldHVybiByZWFjdGl2ZVJlYWRBcnJheSh0aGlzKS5qb2luKHNlcGFyYXRvcik7XG4gIH0sXG4gIC8vIGtleXMoKSBpdGVyYXRvciBvbmx5IHJlYWRzIGBsZW5ndGhgLCBubyBvcHRpbWl6YXRpb24gcmVxdWlyZWRcbiAgbGFzdEluZGV4T2YoLi4uYXJncykge1xuICAgIHJldHVybiBzZWFyY2hQcm94eSh0aGlzLCBcImxhc3RJbmRleE9mXCIsIGFyZ3MpO1xuICB9LFxuICBtYXAoZm4sIHRoaXNBcmcpIHtcbiAgICByZXR1cm4gYXBwbHkodGhpcywgXCJtYXBcIiwgZm4sIHRoaXNBcmcsIHZvaWQgMCwgYXJndW1lbnRzKTtcbiAgfSxcbiAgcG9wKCkge1xuICAgIHJldHVybiBub1RyYWNraW5nKHRoaXMsIFwicG9wXCIpO1xuICB9LFxuICBwdXNoKC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gbm9UcmFja2luZyh0aGlzLCBcInB1c2hcIiwgYXJncyk7XG4gIH0sXG4gIHJlZHVjZShmbiwgLi4uYXJncykge1xuICAgIHJldHVybiByZWR1Y2UodGhpcywgXCJyZWR1Y2VcIiwgZm4sIGFyZ3MpO1xuICB9LFxuICByZWR1Y2VSaWdodChmbiwgLi4uYXJncykge1xuICAgIHJldHVybiByZWR1Y2UodGhpcywgXCJyZWR1Y2VSaWdodFwiLCBmbiwgYXJncyk7XG4gIH0sXG4gIHNoaWZ0KCkge1xuICAgIHJldHVybiBub1RyYWNraW5nKHRoaXMsIFwic2hpZnRcIik7XG4gIH0sXG4gIC8vIHNsaWNlIGNvdWxkIHVzZSBBUlJBWV9JVEVSQVRFIGJ1dCBhbHNvIHNlZW1zIHRvIGJlZyBmb3IgcmFuZ2UgdHJhY2tpbmdcbiAgc29tZShmbiwgdGhpc0FyZykge1xuICAgIHJldHVybiBhcHBseSh0aGlzLCBcInNvbWVcIiwgZm4sIHRoaXNBcmcsIHZvaWQgMCwgYXJndW1lbnRzKTtcbiAgfSxcbiAgc3BsaWNlKC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gbm9UcmFja2luZyh0aGlzLCBcInNwbGljZVwiLCBhcmdzKTtcbiAgfSxcbiAgdG9SZXZlcnNlZCgpIHtcbiAgICByZXR1cm4gcmVhY3RpdmVSZWFkQXJyYXkodGhpcykudG9SZXZlcnNlZCgpO1xuICB9LFxuICB0b1NvcnRlZChjb21wYXJlcikge1xuICAgIHJldHVybiByZWFjdGl2ZVJlYWRBcnJheSh0aGlzKS50b1NvcnRlZChjb21wYXJlcik7XG4gIH0sXG4gIHRvU3BsaWNlZCguLi5hcmdzKSB7XG4gICAgcmV0dXJuIHJlYWN0aXZlUmVhZEFycmF5KHRoaXMpLnRvU3BsaWNlZCguLi5hcmdzKTtcbiAgfSxcbiAgdW5zaGlmdCguLi5hcmdzKSB7XG4gICAgcmV0dXJuIG5vVHJhY2tpbmcodGhpcywgXCJ1bnNoaWZ0XCIsIGFyZ3MpO1xuICB9LFxuICB2YWx1ZXMoKSB7XG4gICAgcmV0dXJuIGl0ZXJhdG9yKHRoaXMsIFwidmFsdWVzXCIsIChpdGVtKSA9PiB0b1dyYXBwZWQodGhpcywgaXRlbSkpO1xuICB9XG59O1xuZnVuY3Rpb24gaXRlcmF0b3Ioc2VsZiwgbWV0aG9kLCB3cmFwVmFsdWUpIHtcbiAgY29uc3QgYXJyID0gc2hhbGxvd1JlYWRBcnJheShzZWxmKTtcbiAgY29uc3QgaXRlciA9IGFyclttZXRob2RdKCk7XG4gIGlmIChhcnIgIT09IHNlbGYgJiYgIWlzU2hhbGxvdyhzZWxmKSkge1xuICAgIGl0ZXIuX25leHQgPSBpdGVyLm5leHQ7XG4gICAgaXRlci5uZXh0ID0gKCkgPT4ge1xuICAgICAgY29uc3QgcmVzdWx0ID0gaXRlci5fbmV4dCgpO1xuICAgICAgaWYgKCFyZXN1bHQuZG9uZSkge1xuICAgICAgICByZXN1bHQudmFsdWUgPSB3cmFwVmFsdWUocmVzdWx0LnZhbHVlKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfTtcbiAgfVxuICByZXR1cm4gaXRlcjtcbn1cbmNvbnN0IGFycmF5UHJvdG8gPSBBcnJheS5wcm90b3R5cGU7XG5mdW5jdGlvbiBhcHBseShzZWxmLCBtZXRob2QsIGZuLCB0aGlzQXJnLCB3cmFwcGVkUmV0Rm4sIGFyZ3MpIHtcbiAgY29uc3QgYXJyID0gc2hhbGxvd1JlYWRBcnJheShzZWxmKTtcbiAgY29uc3QgbmVlZHNXcmFwID0gYXJyICE9PSBzZWxmICYmICFpc1NoYWxsb3coc2VsZik7XG4gIGNvbnN0IG1ldGhvZEZuID0gYXJyW21ldGhvZF07XG4gIGlmIChtZXRob2RGbiAhPT0gYXJyYXlQcm90b1ttZXRob2RdKSB7XG4gICAgY29uc3QgcmVzdWx0MiA9IG1ldGhvZEZuLmFwcGx5KHNlbGYsIGFyZ3MpO1xuICAgIHJldHVybiBuZWVkc1dyYXAgPyB0b1JlYWN0aXZlKHJlc3VsdDIpIDogcmVzdWx0MjtcbiAgfVxuICBsZXQgd3JhcHBlZEZuID0gZm47XG4gIGlmIChhcnIgIT09IHNlbGYpIHtcbiAgICBpZiAobmVlZHNXcmFwKSB7XG4gICAgICB3cmFwcGVkRm4gPSBmdW5jdGlvbihpdGVtLCBpbmRleCkge1xuICAgICAgICByZXR1cm4gZm4uY2FsbCh0aGlzLCB0b1dyYXBwZWQoc2VsZiwgaXRlbSksIGluZGV4LCBzZWxmKTtcbiAgICAgIH07XG4gICAgfSBlbHNlIGlmIChmbi5sZW5ndGggPiAyKSB7XG4gICAgICB3cmFwcGVkRm4gPSBmdW5jdGlvbihpdGVtLCBpbmRleCkge1xuICAgICAgICByZXR1cm4gZm4uY2FsbCh0aGlzLCBpdGVtLCBpbmRleCwgc2VsZik7XG4gICAgICB9O1xuICAgIH1cbiAgfVxuICBjb25zdCByZXN1bHQgPSBtZXRob2RGbi5jYWxsKGFyciwgd3JhcHBlZEZuLCB0aGlzQXJnKTtcbiAgcmV0dXJuIG5lZWRzV3JhcCAmJiB3cmFwcGVkUmV0Rm4gPyB3cmFwcGVkUmV0Rm4ocmVzdWx0KSA6IHJlc3VsdDtcbn1cbmZ1bmN0aW9uIHJlZHVjZShzZWxmLCBtZXRob2QsIGZuLCBhcmdzKSB7XG4gIGNvbnN0IGFyciA9IHNoYWxsb3dSZWFkQXJyYXkoc2VsZik7XG4gIGNvbnN0IG5lZWRzV3JhcCA9IGFyciAhPT0gc2VsZiAmJiAhaXNTaGFsbG93KHNlbGYpO1xuICBsZXQgd3JhcHBlZEZuID0gZm47XG4gIGxldCB3cmFwSW5pdGlhbEFjY3VtdWxhdG9yID0gZmFsc2U7XG4gIGlmIChhcnIgIT09IHNlbGYpIHtcbiAgICBpZiAobmVlZHNXcmFwKSB7XG4gICAgICB3cmFwSW5pdGlhbEFjY3VtdWxhdG9yID0gYXJncy5sZW5ndGggPT09IDA7XG4gICAgICB3cmFwcGVkRm4gPSBmdW5jdGlvbihhY2MsIGl0ZW0sIGluZGV4KSB7XG4gICAgICAgIGlmICh3cmFwSW5pdGlhbEFjY3VtdWxhdG9yKSB7XG4gICAgICAgICAgd3JhcEluaXRpYWxBY2N1bXVsYXRvciA9IGZhbHNlO1xuICAgICAgICAgIGFjYyA9IHRvV3JhcHBlZChzZWxmLCBhY2MpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmbi5jYWxsKHRoaXMsIGFjYywgdG9XcmFwcGVkKHNlbGYsIGl0ZW0pLCBpbmRleCwgc2VsZik7XG4gICAgICB9O1xuICAgIH0gZWxzZSBpZiAoZm4ubGVuZ3RoID4gMykge1xuICAgICAgd3JhcHBlZEZuID0gZnVuY3Rpb24oYWNjLCBpdGVtLCBpbmRleCkge1xuICAgICAgICByZXR1cm4gZm4uY2FsbCh0aGlzLCBhY2MsIGl0ZW0sIGluZGV4LCBzZWxmKTtcbiAgICAgIH07XG4gICAgfVxuICB9XG4gIGNvbnN0IHJlc3VsdCA9IGFyclttZXRob2RdKHdyYXBwZWRGbiwgLi4uYXJncyk7XG4gIHJldHVybiB3cmFwSW5pdGlhbEFjY3VtdWxhdG9yID8gdG9XcmFwcGVkKHNlbGYsIHJlc3VsdCkgOiByZXN1bHQ7XG59XG5mdW5jdGlvbiBzZWFyY2hQcm94eShzZWxmLCBtZXRob2QsIGFyZ3MpIHtcbiAgY29uc3QgYXJyID0gdG9SYXcoc2VsZik7XG4gIHRyYWNrKGFyciwgXCJpdGVyYXRlXCIsIEFSUkFZX0lURVJBVEVfS0VZKTtcbiAgY29uc3QgcmVzID0gYXJyW21ldGhvZF0oLi4uYXJncyk7XG4gIGlmICgocmVzID09PSAtMSB8fCByZXMgPT09IGZhbHNlKSAmJiBpc1Byb3h5KGFyZ3NbMF0pKSB7XG4gICAgYXJnc1swXSA9IHRvUmF3KGFyZ3NbMF0pO1xuICAgIHJldHVybiBhcnJbbWV0aG9kXSguLi5hcmdzKTtcbiAgfVxuICByZXR1cm4gcmVzO1xufVxuZnVuY3Rpb24gbm9UcmFja2luZyhzZWxmLCBtZXRob2QsIGFyZ3MgPSBbXSkge1xuICBwYXVzZVRyYWNraW5nKCk7XG4gIHN0YXJ0QmF0Y2goKTtcbiAgY29uc3QgcmVzID0gdG9SYXcoc2VsZilbbWV0aG9kXS5hcHBseShzZWxmLCBhcmdzKTtcbiAgZW5kQmF0Y2goKTtcbiAgcmVzZXRUcmFja2luZygpO1xuICByZXR1cm4gcmVzO1xufVxuXG5jb25zdCBpc05vblRyYWNrYWJsZUtleXMgPSAvKiBAX19QVVJFX18gKi8gbWFrZU1hcChgX19wcm90b19fLF9fdl9pc1JlZixfX2lzVnVlYCk7XG5jb25zdCBidWlsdEluU3ltYm9scyA9IG5ldyBTZXQoXG4gIC8qIEBfX1BVUkVfXyAqLyBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhTeW1ib2wpLmZpbHRlcigoa2V5KSA9PiBrZXkgIT09IFwiYXJndW1lbnRzXCIgJiYga2V5ICE9PSBcImNhbGxlclwiKS5tYXAoKGtleSkgPT4gU3ltYm9sW2tleV0pLmZpbHRlcihpc1N5bWJvbClcbik7XG5mdW5jdGlvbiBoYXNPd25Qcm9wZXJ0eShrZXkpIHtcbiAgaWYgKCFpc1N5bWJvbChrZXkpKSBrZXkgPSBTdHJpbmcoa2V5KTtcbiAgY29uc3Qgb2JqID0gdG9SYXcodGhpcyk7XG4gIHRyYWNrKG9iaiwgXCJoYXNcIiwga2V5KTtcbiAgcmV0dXJuIG9iai5oYXNPd25Qcm9wZXJ0eShrZXkpO1xufVxuY2xhc3MgQmFzZVJlYWN0aXZlSGFuZGxlciB7XG4gIGNvbnN0cnVjdG9yKF9pc1JlYWRvbmx5ID0gZmFsc2UsIF9pc1NoYWxsb3cgPSBmYWxzZSkge1xuICAgIHRoaXMuX2lzUmVhZG9ubHkgPSBfaXNSZWFkb25seTtcbiAgICB0aGlzLl9pc1NoYWxsb3cgPSBfaXNTaGFsbG93O1xuICB9XG4gIGdldCh0YXJnZXQsIGtleSwgcmVjZWl2ZXIpIHtcbiAgICBpZiAoa2V5ID09PSBcIl9fdl9za2lwXCIpIHJldHVybiB0YXJnZXRbXCJfX3Zfc2tpcFwiXTtcbiAgICBjb25zdCBpc1JlYWRvbmx5MiA9IHRoaXMuX2lzUmVhZG9ubHksIGlzU2hhbGxvdzIgPSB0aGlzLl9pc1NoYWxsb3c7XG4gICAgaWYgKGtleSA9PT0gXCJfX3ZfaXNSZWFjdGl2ZVwiKSB7XG4gICAgICByZXR1cm4gIWlzUmVhZG9ubHkyO1xuICAgIH0gZWxzZSBpZiAoa2V5ID09PSBcIl9fdl9pc1JlYWRvbmx5XCIpIHtcbiAgICAgIHJldHVybiBpc1JlYWRvbmx5MjtcbiAgICB9IGVsc2UgaWYgKGtleSA9PT0gXCJfX3ZfaXNTaGFsbG93XCIpIHtcbiAgICAgIHJldHVybiBpc1NoYWxsb3cyO1xuICAgIH0gZWxzZSBpZiAoa2V5ID09PSBcIl9fdl9yYXdcIikge1xuICAgICAgaWYgKHJlY2VpdmVyID09PSAoaXNSZWFkb25seTIgPyBpc1NoYWxsb3cyID8gc2hhbGxvd1JlYWRvbmx5TWFwIDogcmVhZG9ubHlNYXAgOiBpc1NoYWxsb3cyID8gc2hhbGxvd1JlYWN0aXZlTWFwIDogcmVhY3RpdmVNYXApLmdldCh0YXJnZXQpIHx8IC8vIHJlY2VpdmVyIGlzIG5vdCB0aGUgcmVhY3RpdmUgcHJveHksIGJ1dCBoYXMgdGhlIHNhbWUgcHJvdG90eXBlXG4gICAgICAvLyB0aGlzIG1lYW5zIHRoZSByZWNlaXZlciBpcyBhIHVzZXIgcHJveHkgb2YgdGhlIHJlYWN0aXZlIHByb3h5XG4gICAgICBPYmplY3QuZ2V0UHJvdG90eXBlT2YodGFyZ2V0KSA9PT0gT2JqZWN0LmdldFByb3RvdHlwZU9mKHJlY2VpdmVyKSkge1xuICAgICAgICByZXR1cm4gdGFyZ2V0O1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCB0YXJnZXRJc0FycmF5ID0gaXNBcnJheSh0YXJnZXQpO1xuICAgIGlmICghaXNSZWFkb25seTIpIHtcbiAgICAgIGxldCBmbjtcbiAgICAgIGlmICh0YXJnZXRJc0FycmF5ICYmIChmbiA9IGFycmF5SW5zdHJ1bWVudGF0aW9uc1trZXldKSkge1xuICAgICAgICByZXR1cm4gZm47XG4gICAgICB9XG4gICAgICBpZiAoa2V5ID09PSBcImhhc093blByb3BlcnR5XCIpIHtcbiAgICAgICAgcmV0dXJuIGhhc093blByb3BlcnR5O1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCByZXMgPSBSZWZsZWN0LmdldChcbiAgICAgIHRhcmdldCxcbiAgICAgIGtleSxcbiAgICAgIC8vIGlmIHRoaXMgaXMgYSBwcm94eSB3cmFwcGluZyBhIHJlZiwgcmV0dXJuIG1ldGhvZHMgdXNpbmcgdGhlIHJhdyByZWZcbiAgICAgIC8vIGFzIHJlY2VpdmVyIHNvIHRoYXQgd2UgZG9uJ3QgaGF2ZSB0byBjYWxsIGB0b1Jhd2Agb24gdGhlIHJlZiBpbiBhbGxcbiAgICAgIC8vIGl0cyBjbGFzcyBtZXRob2RzXG4gICAgICBpc1JlZih0YXJnZXQpID8gdGFyZ2V0IDogcmVjZWl2ZXJcbiAgICApO1xuICAgIGlmIChpc1N5bWJvbChrZXkpID8gYnVpbHRJblN5bWJvbHMuaGFzKGtleSkgOiBpc05vblRyYWNrYWJsZUtleXMoa2V5KSkge1xuICAgICAgcmV0dXJuIHJlcztcbiAgICB9XG4gICAgaWYgKCFpc1JlYWRvbmx5Mikge1xuICAgICAgdHJhY2sodGFyZ2V0LCBcImdldFwiLCBrZXkpO1xuICAgIH1cbiAgICBpZiAoaXNTaGFsbG93Mikge1xuICAgICAgcmV0dXJuIHJlcztcbiAgICB9XG4gICAgaWYgKGlzUmVmKHJlcykpIHtcbiAgICAgIGNvbnN0IHZhbHVlID0gdGFyZ2V0SXNBcnJheSAmJiBpc0ludGVnZXJLZXkoa2V5KSA/IHJlcyA6IHJlcy52YWx1ZTtcbiAgICAgIHJldHVybiBpc1JlYWRvbmx5MiAmJiBpc09iamVjdCh2YWx1ZSkgPyByZWFkb25seSh2YWx1ZSkgOiB2YWx1ZTtcbiAgICB9XG4gICAgaWYgKGlzT2JqZWN0KHJlcykpIHtcbiAgICAgIHJldHVybiBpc1JlYWRvbmx5MiA/IHJlYWRvbmx5KHJlcykgOiByZWFjdGl2ZShyZXMpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzO1xuICB9XG59XG5jbGFzcyBNdXRhYmxlUmVhY3RpdmVIYW5kbGVyIGV4dGVuZHMgQmFzZVJlYWN0aXZlSGFuZGxlciB7XG4gIGNvbnN0cnVjdG9yKGlzU2hhbGxvdzIgPSBmYWxzZSkge1xuICAgIHN1cGVyKGZhbHNlLCBpc1NoYWxsb3cyKTtcbiAgfVxuICBzZXQodGFyZ2V0LCBrZXksIHZhbHVlLCByZWNlaXZlcikge1xuICAgIGxldCBvbGRWYWx1ZSA9IHRhcmdldFtrZXldO1xuICAgIGNvbnN0IGlzQXJyYXlXaXRoSW50ZWdlcktleSA9IGlzQXJyYXkodGFyZ2V0KSAmJiBpc0ludGVnZXJLZXkoa2V5KTtcbiAgICBpZiAoIXRoaXMuX2lzU2hhbGxvdykge1xuICAgICAgY29uc3QgaXNPbGRWYWx1ZVJlYWRvbmx5ID0gaXNSZWFkb25seShvbGRWYWx1ZSk7XG4gICAgICBpZiAoIWlzU2hhbGxvdyh2YWx1ZSkgJiYgIWlzUmVhZG9ubHkodmFsdWUpKSB7XG4gICAgICAgIG9sZFZhbHVlID0gdG9SYXcob2xkVmFsdWUpO1xuICAgICAgICB2YWx1ZSA9IHRvUmF3KHZhbHVlKTtcbiAgICAgIH1cbiAgICAgIGlmICghaXNBcnJheVdpdGhJbnRlZ2VyS2V5ICYmIGlzUmVmKG9sZFZhbHVlKSAmJiAhaXNSZWYodmFsdWUpKSB7XG4gICAgICAgIGlmIChpc09sZFZhbHVlUmVhZG9ubHkpIHtcbiAgICAgICAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgICAgd2FybihcbiAgICAgICAgICAgICAgYFNldCBvcGVyYXRpb24gb24ga2V5IFwiJHtTdHJpbmcoa2V5KX1cIiBmYWlsZWQ6IHRhcmdldCBpcyByZWFkb25seS5gLFxuICAgICAgICAgICAgICB0YXJnZXRba2V5XVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgb2xkVmFsdWUudmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBoYWRLZXkgPSBpc0FycmF5V2l0aEludGVnZXJLZXkgPyBOdW1iZXIoa2V5KSA8IHRhcmdldC5sZW5ndGggOiBoYXNPd24odGFyZ2V0LCBrZXkpO1xuICAgIGNvbnN0IHJlc3VsdCA9IFJlZmxlY3Quc2V0KFxuICAgICAgdGFyZ2V0LFxuICAgICAga2V5LFxuICAgICAgdmFsdWUsXG4gICAgICBpc1JlZih0YXJnZXQpID8gdGFyZ2V0IDogcmVjZWl2ZXJcbiAgICApO1xuICAgIGlmICh0YXJnZXQgPT09IHRvUmF3KHJlY2VpdmVyKSAmJiByZXN1bHQpIHtcbiAgICAgIGlmICghaGFkS2V5KSB7XG4gICAgICAgIHRyaWdnZXIodGFyZ2V0LCBcImFkZFwiLCBrZXksIHZhbHVlKTtcbiAgICAgIH0gZWxzZSBpZiAoaGFzQ2hhbmdlZCh2YWx1ZSwgb2xkVmFsdWUpKSB7XG4gICAgICAgIHRyaWdnZXIodGFyZ2V0LCBcInNldFwiLCBrZXksIHZhbHVlLCBvbGRWYWx1ZSk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbiAgZGVsZXRlUHJvcGVydHkodGFyZ2V0LCBrZXkpIHtcbiAgICBjb25zdCBoYWRLZXkgPSBoYXNPd24odGFyZ2V0LCBrZXkpO1xuICAgIGNvbnN0IG9sZFZhbHVlID0gdGFyZ2V0W2tleV07XG4gICAgY29uc3QgcmVzdWx0ID0gUmVmbGVjdC5kZWxldGVQcm9wZXJ0eSh0YXJnZXQsIGtleSk7XG4gICAgaWYgKHJlc3VsdCAmJiBoYWRLZXkpIHtcbiAgICAgIHRyaWdnZXIodGFyZ2V0LCBcImRlbGV0ZVwiLCBrZXksIHZvaWQgMCwgb2xkVmFsdWUpO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG4gIGhhcyh0YXJnZXQsIGtleSkge1xuICAgIGNvbnN0IHJlc3VsdCA9IFJlZmxlY3QuaGFzKHRhcmdldCwga2V5KTtcbiAgICBpZiAoIWlzU3ltYm9sKGtleSkgfHwgIWJ1aWx0SW5TeW1ib2xzLmhhcyhrZXkpKSB7XG4gICAgICB0cmFjayh0YXJnZXQsIFwiaGFzXCIsIGtleSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbiAgb3duS2V5cyh0YXJnZXQpIHtcbiAgICB0cmFjayhcbiAgICAgIHRhcmdldCxcbiAgICAgIFwiaXRlcmF0ZVwiLFxuICAgICAgaXNBcnJheSh0YXJnZXQpID8gXCJsZW5ndGhcIiA6IElURVJBVEVfS0VZXG4gICAgKTtcbiAgICByZXR1cm4gUmVmbGVjdC5vd25LZXlzKHRhcmdldCk7XG4gIH1cbn1cbmNsYXNzIFJlYWRvbmx5UmVhY3RpdmVIYW5kbGVyIGV4dGVuZHMgQmFzZVJlYWN0aXZlSGFuZGxlciB7XG4gIGNvbnN0cnVjdG9yKGlzU2hhbGxvdzIgPSBmYWxzZSkge1xuICAgIHN1cGVyKHRydWUsIGlzU2hhbGxvdzIpO1xuICB9XG4gIHNldCh0YXJnZXQsIGtleSkge1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICB3YXJuKFxuICAgICAgICBgU2V0IG9wZXJhdGlvbiBvbiBrZXkgXCIke1N0cmluZyhrZXkpfVwiIGZhaWxlZDogdGFyZ2V0IGlzIHJlYWRvbmx5LmAsXG4gICAgICAgIHRhcmdldFxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgZGVsZXRlUHJvcGVydHkodGFyZ2V0LCBrZXkpIHtcbiAgICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgd2FybihcbiAgICAgICAgYERlbGV0ZSBvcGVyYXRpb24gb24ga2V5IFwiJHtTdHJpbmcoa2V5KX1cIiBmYWlsZWQ6IHRhcmdldCBpcyByZWFkb25seS5gLFxuICAgICAgICB0YXJnZXRcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9XG59XG5jb25zdCBtdXRhYmxlSGFuZGxlcnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE11dGFibGVSZWFjdGl2ZUhhbmRsZXIoKTtcbmNvbnN0IHJlYWRvbmx5SGFuZGxlcnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFJlYWRvbmx5UmVhY3RpdmVIYW5kbGVyKCk7XG5jb25zdCBzaGFsbG93UmVhY3RpdmVIYW5kbGVycyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTXV0YWJsZVJlYWN0aXZlSGFuZGxlcih0cnVlKTtcbmNvbnN0IHNoYWxsb3dSZWFkb25seUhhbmRsZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBSZWFkb25seVJlYWN0aXZlSGFuZGxlcih0cnVlKTtcblxuY29uc3QgdG9TaGFsbG93ID0gKHZhbHVlKSA9PiB2YWx1ZTtcbmNvbnN0IGdldFByb3RvID0gKHYpID0+IFJlZmxlY3QuZ2V0UHJvdG90eXBlT2Yodik7XG5mdW5jdGlvbiBjcmVhdGVJdGVyYWJsZU1ldGhvZChtZXRob2QsIGlzUmVhZG9ubHkyLCBpc1NoYWxsb3cyKSB7XG4gIHJldHVybiBmdW5jdGlvbiguLi5hcmdzKSB7XG4gICAgY29uc3QgdGFyZ2V0ID0gdGhpc1tcIl9fdl9yYXdcIl07XG4gICAgY29uc3QgcmF3VGFyZ2V0ID0gdG9SYXcodGFyZ2V0KTtcbiAgICBjb25zdCB0YXJnZXRJc01hcCA9IGlzTWFwKHJhd1RhcmdldCk7XG4gICAgY29uc3QgaXNQYWlyID0gbWV0aG9kID09PSBcImVudHJpZXNcIiB8fCBtZXRob2QgPT09IFN5bWJvbC5pdGVyYXRvciAmJiB0YXJnZXRJc01hcDtcbiAgICBjb25zdCBpc0tleU9ubHkgPSBtZXRob2QgPT09IFwia2V5c1wiICYmIHRhcmdldElzTWFwO1xuICAgIGNvbnN0IGlubmVySXRlcmF0b3IgPSB0YXJnZXRbbWV0aG9kXSguLi5hcmdzKTtcbiAgICBjb25zdCB3cmFwID0gaXNTaGFsbG93MiA/IHRvU2hhbGxvdyA6IGlzUmVhZG9ubHkyID8gdG9SZWFkb25seSA6IHRvUmVhY3RpdmU7XG4gICAgIWlzUmVhZG9ubHkyICYmIHRyYWNrKFxuICAgICAgcmF3VGFyZ2V0LFxuICAgICAgXCJpdGVyYXRlXCIsXG4gICAgICBpc0tleU9ubHkgPyBNQVBfS0VZX0lURVJBVEVfS0VZIDogSVRFUkFURV9LRVlcbiAgICApO1xuICAgIHJldHVybiBleHRlbmQoXG4gICAgICAvLyBpbmhlcml0aW5nIGFsbCBpdGVyYXRvciBwcm9wZXJ0aWVzXG4gICAgICBPYmplY3QuY3JlYXRlKGlubmVySXRlcmF0b3IpLFxuICAgICAge1xuICAgICAgICAvLyBpdGVyYXRvciBwcm90b2NvbFxuICAgICAgICBuZXh0KCkge1xuICAgICAgICAgIGNvbnN0IHsgdmFsdWUsIGRvbmUgfSA9IGlubmVySXRlcmF0b3IubmV4dCgpO1xuICAgICAgICAgIHJldHVybiBkb25lID8geyB2YWx1ZSwgZG9uZSB9IDoge1xuICAgICAgICAgICAgdmFsdWU6IGlzUGFpciA/IFt3cmFwKHZhbHVlWzBdKSwgd3JhcCh2YWx1ZVsxXSldIDogd3JhcCh2YWx1ZSksXG4gICAgICAgICAgICBkb25lXG4gICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICk7XG4gIH07XG59XG5mdW5jdGlvbiBjcmVhdGVSZWFkb25seU1ldGhvZCh0eXBlKSB7XG4gIHJldHVybiBmdW5jdGlvbiguLi5hcmdzKSB7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgIGNvbnN0IGtleSA9IGFyZ3NbMF0gPyBgb24ga2V5IFwiJHthcmdzWzBdfVwiIGAgOiBgYDtcbiAgICAgIHdhcm4oXG4gICAgICAgIGAke2NhcGl0YWxpemUodHlwZSl9IG9wZXJhdGlvbiAke2tleX1mYWlsZWQ6IHRhcmdldCBpcyByZWFkb25seS5gLFxuICAgICAgICB0b1Jhdyh0aGlzKVxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIHR5cGUgPT09IFwiZGVsZXRlXCIgPyBmYWxzZSA6IHR5cGUgPT09IFwiY2xlYXJcIiA/IHZvaWQgMCA6IHRoaXM7XG4gIH07XG59XG5mdW5jdGlvbiBjcmVhdGVJbnN0cnVtZW50YXRpb25zKHJlYWRvbmx5LCBzaGFsbG93KSB7XG4gIGNvbnN0IGluc3RydW1lbnRhdGlvbnMgPSB7XG4gICAgZ2V0KGtleSkge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gdGhpc1tcIl9fdl9yYXdcIl07XG4gICAgICBjb25zdCByYXdUYXJnZXQgPSB0b1Jhdyh0YXJnZXQpO1xuICAgICAgY29uc3QgcmF3S2V5ID0gdG9SYXcoa2V5KTtcbiAgICAgIGlmICghcmVhZG9ubHkpIHtcbiAgICAgICAgaWYgKGhhc0NoYW5nZWQoa2V5LCByYXdLZXkpKSB7XG4gICAgICAgICAgdHJhY2socmF3VGFyZ2V0LCBcImdldFwiLCBrZXkpO1xuICAgICAgICB9XG4gICAgICAgIHRyYWNrKHJhd1RhcmdldCwgXCJnZXRcIiwgcmF3S2V5KTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHsgaGFzIH0gPSBnZXRQcm90byhyYXdUYXJnZXQpO1xuICAgICAgY29uc3Qgd3JhcCA9IHNoYWxsb3cgPyB0b1NoYWxsb3cgOiByZWFkb25seSA/IHRvUmVhZG9ubHkgOiB0b1JlYWN0aXZlO1xuICAgICAgaWYgKGhhcy5jYWxsKHJhd1RhcmdldCwga2V5KSkge1xuICAgICAgICByZXR1cm4gd3JhcCh0YXJnZXQuZ2V0KGtleSkpO1xuICAgICAgfSBlbHNlIGlmIChoYXMuY2FsbChyYXdUYXJnZXQsIHJhd0tleSkpIHtcbiAgICAgICAgcmV0dXJuIHdyYXAodGFyZ2V0LmdldChyYXdLZXkpKTtcbiAgICAgIH0gZWxzZSBpZiAodGFyZ2V0ICE9PSByYXdUYXJnZXQpIHtcbiAgICAgICAgdGFyZ2V0LmdldChrZXkpO1xuICAgICAgfVxuICAgIH0sXG4gICAgZ2V0IHNpemUoKSB7XG4gICAgICBjb25zdCB0YXJnZXQgPSB0aGlzW1wiX192X3Jhd1wiXTtcbiAgICAgICFyZWFkb25seSAmJiB0cmFjayh0b1Jhdyh0YXJnZXQpLCBcIml0ZXJhdGVcIiwgSVRFUkFURV9LRVkpO1xuICAgICAgcmV0dXJuIHRhcmdldC5zaXplO1xuICAgIH0sXG4gICAgaGFzKGtleSkge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gdGhpc1tcIl9fdl9yYXdcIl07XG4gICAgICBjb25zdCByYXdUYXJnZXQgPSB0b1Jhdyh0YXJnZXQpO1xuICAgICAgY29uc3QgcmF3S2V5ID0gdG9SYXcoa2V5KTtcbiAgICAgIGlmICghcmVhZG9ubHkpIHtcbiAgICAgICAgaWYgKGhhc0NoYW5nZWQoa2V5LCByYXdLZXkpKSB7XG4gICAgICAgICAgdHJhY2socmF3VGFyZ2V0LCBcImhhc1wiLCBrZXkpO1xuICAgICAgICB9XG4gICAgICAgIHRyYWNrKHJhd1RhcmdldCwgXCJoYXNcIiwgcmF3S2V5KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBrZXkgPT09IHJhd0tleSA/IHRhcmdldC5oYXMoa2V5KSA6IHRhcmdldC5oYXMoa2V5KSB8fCB0YXJnZXQuaGFzKHJhd0tleSk7XG4gICAgfSxcbiAgICBmb3JFYWNoKGNhbGxiYWNrLCB0aGlzQXJnKSB7XG4gICAgICBjb25zdCBvYnNlcnZlZCA9IHRoaXM7XG4gICAgICBjb25zdCB0YXJnZXQgPSBvYnNlcnZlZFtcIl9fdl9yYXdcIl07XG4gICAgICBjb25zdCByYXdUYXJnZXQgPSB0b1Jhdyh0YXJnZXQpO1xuICAgICAgY29uc3Qgd3JhcCA9IHNoYWxsb3cgPyB0b1NoYWxsb3cgOiByZWFkb25seSA/IHRvUmVhZG9ubHkgOiB0b1JlYWN0aXZlO1xuICAgICAgIXJlYWRvbmx5ICYmIHRyYWNrKHJhd1RhcmdldCwgXCJpdGVyYXRlXCIsIElURVJBVEVfS0VZKTtcbiAgICAgIHJldHVybiB0YXJnZXQuZm9yRWFjaCgodmFsdWUsIGtleSkgPT4ge1xuICAgICAgICByZXR1cm4gY2FsbGJhY2suY2FsbCh0aGlzQXJnLCB3cmFwKHZhbHVlKSwgd3JhcChrZXkpLCBvYnNlcnZlZCk7XG4gICAgICB9KTtcbiAgICB9XG4gIH07XG4gIGV4dGVuZChcbiAgICBpbnN0cnVtZW50YXRpb25zLFxuICAgIHJlYWRvbmx5ID8ge1xuICAgICAgYWRkOiBjcmVhdGVSZWFkb25seU1ldGhvZChcImFkZFwiKSxcbiAgICAgIHNldDogY3JlYXRlUmVhZG9ubHlNZXRob2QoXCJzZXRcIiksXG4gICAgICBkZWxldGU6IGNyZWF0ZVJlYWRvbmx5TWV0aG9kKFwiZGVsZXRlXCIpLFxuICAgICAgY2xlYXI6IGNyZWF0ZVJlYWRvbmx5TWV0aG9kKFwiY2xlYXJcIilcbiAgICB9IDoge1xuICAgICAgYWRkKHZhbHVlKSB7XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IHRvUmF3KHRoaXMpO1xuICAgICAgICBjb25zdCBwcm90byA9IGdldFByb3RvKHRhcmdldCk7XG4gICAgICAgIGNvbnN0IHJhd1ZhbHVlID0gdG9SYXcodmFsdWUpO1xuICAgICAgICBjb25zdCB2YWx1ZVRvQWRkID0gIXNoYWxsb3cgJiYgIWlzU2hhbGxvdyh2YWx1ZSkgJiYgIWlzUmVhZG9ubHkodmFsdWUpID8gcmF3VmFsdWUgOiB2YWx1ZTtcbiAgICAgICAgY29uc3QgaGFkS2V5ID0gcHJvdG8uaGFzLmNhbGwodGFyZ2V0LCB2YWx1ZVRvQWRkKSB8fCBoYXNDaGFuZ2VkKHZhbHVlLCB2YWx1ZVRvQWRkKSAmJiBwcm90by5oYXMuY2FsbCh0YXJnZXQsIHZhbHVlKSB8fCBoYXNDaGFuZ2VkKHJhd1ZhbHVlLCB2YWx1ZVRvQWRkKSAmJiBwcm90by5oYXMuY2FsbCh0YXJnZXQsIHJhd1ZhbHVlKTtcbiAgICAgICAgaWYgKCFoYWRLZXkpIHtcbiAgICAgICAgICB0YXJnZXQuYWRkKHZhbHVlVG9BZGQpO1xuICAgICAgICAgIHRyaWdnZXIodGFyZ2V0LCBcImFkZFwiLCB2YWx1ZVRvQWRkLCB2YWx1ZVRvQWRkKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgIH0sXG4gICAgICBzZXQoa2V5LCB2YWx1ZSkge1xuICAgICAgICBpZiAoIXNoYWxsb3cgJiYgIWlzU2hhbGxvdyh2YWx1ZSkgJiYgIWlzUmVhZG9ubHkodmFsdWUpKSB7XG4gICAgICAgICAgdmFsdWUgPSB0b1Jhdyh2YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gdG9SYXcodGhpcyk7XG4gICAgICAgIGNvbnN0IHsgaGFzLCBnZXQgfSA9IGdldFByb3RvKHRhcmdldCk7XG4gICAgICAgIGxldCBoYWRLZXkgPSBoYXMuY2FsbCh0YXJnZXQsIGtleSk7XG4gICAgICAgIGlmICghaGFkS2V5KSB7XG4gICAgICAgICAga2V5ID0gdG9SYXcoa2V5KTtcbiAgICAgICAgICBoYWRLZXkgPSBoYXMuY2FsbCh0YXJnZXQsIGtleSk7XG4gICAgICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIGNoZWNrSWRlbnRpdHlLZXlzKHRhcmdldCwgaGFzLCBrZXkpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG9sZFZhbHVlID0gZ2V0LmNhbGwodGFyZ2V0LCBrZXkpO1xuICAgICAgICB0YXJnZXQuc2V0KGtleSwgdmFsdWUpO1xuICAgICAgICBpZiAoIWhhZEtleSkge1xuICAgICAgICAgIHRyaWdnZXIodGFyZ2V0LCBcImFkZFwiLCBrZXksIHZhbHVlKTtcbiAgICAgICAgfSBlbHNlIGlmIChoYXNDaGFuZ2VkKHZhbHVlLCBvbGRWYWx1ZSkpIHtcbiAgICAgICAgICB0cmlnZ2VyKHRhcmdldCwgXCJzZXRcIiwga2V5LCB2YWx1ZSwgb2xkVmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgfSxcbiAgICAgIGRlbGV0ZShrZXkpIHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gdG9SYXcodGhpcyk7XG4gICAgICAgIGNvbnN0IHsgaGFzLCBnZXQgfSA9IGdldFByb3RvKHRhcmdldCk7XG4gICAgICAgIGxldCBoYWRLZXkgPSBoYXMuY2FsbCh0YXJnZXQsIGtleSk7XG4gICAgICAgIGlmICghaGFkS2V5KSB7XG4gICAgICAgICAga2V5ID0gdG9SYXcoa2V5KTtcbiAgICAgICAgICBoYWRLZXkgPSBoYXMuY2FsbCh0YXJnZXQsIGtleSk7XG4gICAgICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgICAgICAgIGNoZWNrSWRlbnRpdHlLZXlzKHRhcmdldCwgaGFzLCBrZXkpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG9sZFZhbHVlID0gZ2V0ID8gZ2V0LmNhbGwodGFyZ2V0LCBrZXkpIDogdm9pZCAwO1xuICAgICAgICBjb25zdCByZXN1bHQgPSB0YXJnZXQuZGVsZXRlKGtleSk7XG4gICAgICAgIGlmIChoYWRLZXkpIHtcbiAgICAgICAgICB0cmlnZ2VyKHRhcmdldCwgXCJkZWxldGVcIiwga2V5LCB2b2lkIDAsIG9sZFZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgfSxcbiAgICAgIGNsZWFyKCkge1xuICAgICAgICBjb25zdCB0YXJnZXQgPSB0b1Jhdyh0aGlzKTtcbiAgICAgICAgY29uc3QgaGFkSXRlbXMgPSB0YXJnZXQuc2l6ZSAhPT0gMDtcbiAgICAgICAgY29uc3Qgb2xkVGFyZ2V0ID0gISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IGlzTWFwKHRhcmdldCkgPyBuZXcgTWFwKHRhcmdldCkgOiBuZXcgU2V0KHRhcmdldCkgOiB2b2lkIDA7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IHRhcmdldC5jbGVhcigpO1xuICAgICAgICBpZiAoaGFkSXRlbXMpIHtcbiAgICAgICAgICB0cmlnZ2VyKFxuICAgICAgICAgICAgdGFyZ2V0LFxuICAgICAgICAgICAgXCJjbGVhclwiLFxuICAgICAgICAgICAgdm9pZCAwLFxuICAgICAgICAgICAgdm9pZCAwLFxuICAgICAgICAgICAgb2xkVGFyZ2V0XG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgfVxuICAgIH1cbiAgKTtcbiAgY29uc3QgaXRlcmF0b3JNZXRob2RzID0gW1xuICAgIFwia2V5c1wiLFxuICAgIFwidmFsdWVzXCIsXG4gICAgXCJlbnRyaWVzXCIsXG4gICAgU3ltYm9sLml0ZXJhdG9yXG4gIF07XG4gIGl0ZXJhdG9yTWV0aG9kcy5mb3JFYWNoKChtZXRob2QpID0+IHtcbiAgICBpbnN0cnVtZW50YXRpb25zW21ldGhvZF0gPSBjcmVhdGVJdGVyYWJsZU1ldGhvZChtZXRob2QsIHJlYWRvbmx5LCBzaGFsbG93KTtcbiAgfSk7XG4gIHJldHVybiBpbnN0cnVtZW50YXRpb25zO1xufVxuZnVuY3Rpb24gY3JlYXRlSW5zdHJ1bWVudGF0aW9uR2V0dGVyKGlzUmVhZG9ubHkyLCBzaGFsbG93KSB7XG4gIGNvbnN0IGluc3RydW1lbnRhdGlvbnMgPSBjcmVhdGVJbnN0cnVtZW50YXRpb25zKGlzUmVhZG9ubHkyLCBzaGFsbG93KTtcbiAgcmV0dXJuICh0YXJnZXQsIGtleSwgcmVjZWl2ZXIpID0+IHtcbiAgICBpZiAoa2V5ID09PSBcIl9fdl9pc1JlYWN0aXZlXCIpIHtcbiAgICAgIHJldHVybiAhaXNSZWFkb25seTI7XG4gICAgfSBlbHNlIGlmIChrZXkgPT09IFwiX192X2lzUmVhZG9ubHlcIikge1xuICAgICAgcmV0dXJuIGlzUmVhZG9ubHkyO1xuICAgIH0gZWxzZSBpZiAoa2V5ID09PSBcIl9fdl9yYXdcIikge1xuICAgICAgcmV0dXJuIHRhcmdldDtcbiAgICB9XG4gICAgcmV0dXJuIFJlZmxlY3QuZ2V0KFxuICAgICAgaGFzT3duKGluc3RydW1lbnRhdGlvbnMsIGtleSkgJiYga2V5IGluIHRhcmdldCA/IGluc3RydW1lbnRhdGlvbnMgOiB0YXJnZXQsXG4gICAgICBrZXksXG4gICAgICByZWNlaXZlclxuICAgICk7XG4gIH07XG59XG5jb25zdCBtdXRhYmxlQ29sbGVjdGlvbkhhbmRsZXJzID0ge1xuICBnZXQ6IC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVJbnN0cnVtZW50YXRpb25HZXR0ZXIoZmFsc2UsIGZhbHNlKVxufTtcbmNvbnN0IHNoYWxsb3dDb2xsZWN0aW9uSGFuZGxlcnMgPSB7XG4gIGdldDogLyogQF9fUFVSRV9fICovIGNyZWF0ZUluc3RydW1lbnRhdGlvbkdldHRlcihmYWxzZSwgdHJ1ZSlcbn07XG5jb25zdCByZWFkb25seUNvbGxlY3Rpb25IYW5kbGVycyA9IHtcbiAgZ2V0OiAvKiBAX19QVVJFX18gKi8gY3JlYXRlSW5zdHJ1bWVudGF0aW9uR2V0dGVyKHRydWUsIGZhbHNlKVxufTtcbmNvbnN0IHNoYWxsb3dSZWFkb25seUNvbGxlY3Rpb25IYW5kbGVycyA9IHtcbiAgZ2V0OiAvKiBAX19QVVJFX18gKi8gY3JlYXRlSW5zdHJ1bWVudGF0aW9uR2V0dGVyKHRydWUsIHRydWUpXG59O1xuZnVuY3Rpb24gY2hlY2tJZGVudGl0eUtleXModGFyZ2V0LCBoYXMsIGtleSkge1xuICBjb25zdCByYXdLZXkgPSB0b1JhdyhrZXkpO1xuICBpZiAocmF3S2V5ICE9PSBrZXkgJiYgaGFzLmNhbGwodGFyZ2V0LCByYXdLZXkpKSB7XG4gICAgY29uc3QgdHlwZSA9IHRvUmF3VHlwZSh0YXJnZXQpO1xuICAgIHdhcm4oXG4gICAgICBgUmVhY3RpdmUgJHt0eXBlfSBjb250YWlucyBib3RoIHRoZSByYXcgYW5kIHJlYWN0aXZlIHZlcnNpb25zIG9mIHRoZSBzYW1lIG9iamVjdCR7dHlwZSA9PT0gYE1hcGAgPyBgIGFzIGtleXNgIDogYGB9LCB3aGljaCBjYW4gbGVhZCB0byBpbmNvbnNpc3RlbmNpZXMuIEF2b2lkIGRpZmZlcmVudGlhdGluZyBiZXR3ZWVuIHRoZSByYXcgYW5kIHJlYWN0aXZlIHZlcnNpb25zIG9mIGFuIG9iamVjdCBhbmQgb25seSB1c2UgdGhlIHJlYWN0aXZlIHZlcnNpb24gaWYgcG9zc2libGUuYFxuICAgICk7XG4gIH1cbn1cblxuY29uc3QgcmVhY3RpdmVNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbmNvbnN0IHNoYWxsb3dSZWFjdGl2ZU1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuY29uc3QgcmVhZG9ubHlNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcbmNvbnN0IHNoYWxsb3dSZWFkb25seU1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuZnVuY3Rpb24gdGFyZ2V0VHlwZU1hcChyYXdUeXBlKSB7XG4gIHN3aXRjaCAocmF3VHlwZSkge1xuICAgIGNhc2UgXCJPYmplY3RcIjpcbiAgICBjYXNlIFwiQXJyYXlcIjpcbiAgICAgIHJldHVybiAxIC8qIENPTU1PTiAqLztcbiAgICBjYXNlIFwiTWFwXCI6XG4gICAgY2FzZSBcIlNldFwiOlxuICAgIGNhc2UgXCJXZWFrTWFwXCI6XG4gICAgY2FzZSBcIldlYWtTZXRcIjpcbiAgICAgIHJldHVybiAyIC8qIENPTExFQ1RJT04gKi87XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiAwIC8qIElOVkFMSUQgKi87XG4gIH1cbn1cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiByZWFjdGl2ZSh0YXJnZXQpIHtcbiAgaWYgKC8qIEBfX1BVUkVfXyAqLyBpc1JlYWRvbmx5KHRhcmdldCkpIHtcbiAgICByZXR1cm4gdGFyZ2V0O1xuICB9XG4gIHJldHVybiBjcmVhdGVSZWFjdGl2ZU9iamVjdChcbiAgICB0YXJnZXQsXG4gICAgZmFsc2UsXG4gICAgbXV0YWJsZUhhbmRsZXJzLFxuICAgIG11dGFibGVDb2xsZWN0aW9uSGFuZGxlcnMsXG4gICAgcmVhY3RpdmVNYXBcbiAgKTtcbn1cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiBzaGFsbG93UmVhY3RpdmUodGFyZ2V0KSB7XG4gIHJldHVybiBjcmVhdGVSZWFjdGl2ZU9iamVjdChcbiAgICB0YXJnZXQsXG4gICAgZmFsc2UsXG4gICAgc2hhbGxvd1JlYWN0aXZlSGFuZGxlcnMsXG4gICAgc2hhbGxvd0NvbGxlY3Rpb25IYW5kbGVycyxcbiAgICBzaGFsbG93UmVhY3RpdmVNYXBcbiAgKTtcbn1cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiByZWFkb25seSh0YXJnZXQpIHtcbiAgcmV0dXJuIGNyZWF0ZVJlYWN0aXZlT2JqZWN0KFxuICAgIHRhcmdldCxcbiAgICB0cnVlLFxuICAgIHJlYWRvbmx5SGFuZGxlcnMsXG4gICAgcmVhZG9ubHlDb2xsZWN0aW9uSGFuZGxlcnMsXG4gICAgcmVhZG9ubHlNYXBcbiAgKTtcbn1cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiBzaGFsbG93UmVhZG9ubHkodGFyZ2V0KSB7XG4gIHJldHVybiBjcmVhdGVSZWFjdGl2ZU9iamVjdChcbiAgICB0YXJnZXQsXG4gICAgdHJ1ZSxcbiAgICBzaGFsbG93UmVhZG9ubHlIYW5kbGVycyxcbiAgICBzaGFsbG93UmVhZG9ubHlDb2xsZWN0aW9uSGFuZGxlcnMsXG4gICAgc2hhbGxvd1JlYWRvbmx5TWFwXG4gICk7XG59XG5mdW5jdGlvbiBjcmVhdGVSZWFjdGl2ZU9iamVjdCh0YXJnZXQsIGlzUmVhZG9ubHkyLCBiYXNlSGFuZGxlcnMsIGNvbGxlY3Rpb25IYW5kbGVycywgcHJveHlNYXApIHtcbiAgaWYgKCFpc09iamVjdCh0YXJnZXQpKSB7XG4gICAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgIHdhcm4oXG4gICAgICAgIGB2YWx1ZSBjYW5ub3QgYmUgbWFkZSAke2lzUmVhZG9ubHkyID8gXCJyZWFkb25seVwiIDogXCJyZWFjdGl2ZVwifTogJHtTdHJpbmcoXG4gICAgICAgICAgdGFyZ2V0XG4gICAgICAgICl9YFxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIHRhcmdldDtcbiAgfVxuICBpZiAodGFyZ2V0W1wiX192X3Jhd1wiXSAmJiAhKGlzUmVhZG9ubHkyICYmIHRhcmdldFtcIl9fdl9pc1JlYWN0aXZlXCJdKSkge1xuICAgIHJldHVybiB0YXJnZXQ7XG4gIH1cbiAgaWYgKHRhcmdldFtcIl9fdl9za2lwXCJdIHx8ICFPYmplY3QuaXNFeHRlbnNpYmxlKHRhcmdldCkpIHtcbiAgICByZXR1cm4gdGFyZ2V0O1xuICB9XG4gIGNvbnN0IGV4aXN0aW5nUHJveHkgPSBwcm94eU1hcC5nZXQodGFyZ2V0KTtcbiAgaWYgKGV4aXN0aW5nUHJveHkpIHtcbiAgICByZXR1cm4gZXhpc3RpbmdQcm94eTtcbiAgfVxuICBjb25zdCB0YXJnZXRUeXBlID0gdGFyZ2V0VHlwZU1hcCh0b1Jhd1R5cGUodGFyZ2V0KSk7XG4gIGlmICh0YXJnZXRUeXBlID09PSAwIC8qIElOVkFMSUQgKi8pIHtcbiAgICByZXR1cm4gdGFyZ2V0O1xuICB9XG4gIGNvbnN0IHByb3h5ID0gbmV3IFByb3h5KFxuICAgIHRhcmdldCxcbiAgICB0YXJnZXRUeXBlID09PSAyIC8qIENPTExFQ1RJT04gKi8gPyBjb2xsZWN0aW9uSGFuZGxlcnMgOiBiYXNlSGFuZGxlcnNcbiAgKTtcbiAgcHJveHlNYXAuc2V0KHRhcmdldCwgcHJveHkpO1xuICByZXR1cm4gcHJveHk7XG59XG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gaXNSZWFjdGl2ZSh2YWx1ZSkge1xuICBpZiAoLyogQF9fUFVSRV9fICovIGlzUmVhZG9ubHkodmFsdWUpKSB7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBpc1JlYWN0aXZlKHZhbHVlW1wiX192X3Jhd1wiXSk7XG4gIH1cbiAgcmV0dXJuICEhKHZhbHVlICYmIHZhbHVlW1wiX192X2lzUmVhY3RpdmVcIl0pO1xufVxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIGlzUmVhZG9ubHkodmFsdWUpIHtcbiAgcmV0dXJuICEhKHZhbHVlICYmIHZhbHVlW1wiX192X2lzUmVhZG9ubHlcIl0pO1xufVxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIGlzU2hhbGxvdyh2YWx1ZSkge1xuICByZXR1cm4gISEodmFsdWUgJiYgdmFsdWVbXCJfX3ZfaXNTaGFsbG93XCJdKTtcbn1cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiBpc1Byb3h5KHZhbHVlKSB7XG4gIHJldHVybiB2YWx1ZSA/ICEhdmFsdWVbXCJfX3ZfcmF3XCJdIDogZmFsc2U7XG59XG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gdG9SYXcob2JzZXJ2ZWQpIHtcbiAgY29uc3QgcmF3ID0gb2JzZXJ2ZWQgJiYgb2JzZXJ2ZWRbXCJfX3ZfcmF3XCJdO1xuICByZXR1cm4gcmF3ID8gLyogQF9fUFVSRV9fICovIHRvUmF3KHJhdykgOiBvYnNlcnZlZDtcbn1cbmZ1bmN0aW9uIG1hcmtSYXcodmFsdWUpIHtcbiAgaWYgKCFoYXNPd24odmFsdWUsIFwiX192X3NraXBcIikgJiYgT2JqZWN0LmlzRXh0ZW5zaWJsZSh2YWx1ZSkpIHtcbiAgICBkZWYodmFsdWUsIFwiX192X3NraXBcIiwgdHJ1ZSk7XG4gIH1cbiAgcmV0dXJuIHZhbHVlO1xufVxuY29uc3QgdG9SZWFjdGl2ZSA9ICh2YWx1ZSkgPT4gaXNPYmplY3QodmFsdWUpID8gLyogQF9fUFVSRV9fICovIHJlYWN0aXZlKHZhbHVlKSA6IHZhbHVlO1xuY29uc3QgdG9SZWFkb25seSA9ICh2YWx1ZSkgPT4gaXNPYmplY3QodmFsdWUpID8gLyogQF9fUFVSRV9fICovIHJlYWRvbmx5KHZhbHVlKSA6IHZhbHVlO1xuXG4vLyBAX19OT19TSURFX0VGRkVDVFNfX1xuZnVuY3Rpb24gaXNSZWYocikge1xuICByZXR1cm4gciA/IHJbXCJfX3ZfaXNSZWZcIl0gPT09IHRydWUgOiBmYWxzZTtcbn1cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiByZWYodmFsdWUpIHtcbiAgcmV0dXJuIGNyZWF0ZVJlZih2YWx1ZSwgZmFsc2UpO1xufVxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHNoYWxsb3dSZWYodmFsdWUpIHtcbiAgcmV0dXJuIGNyZWF0ZVJlZih2YWx1ZSwgdHJ1ZSk7XG59XG5mdW5jdGlvbiBjcmVhdGVSZWYocmF3VmFsdWUsIHNoYWxsb3cpIHtcbiAgaWYgKC8qIEBfX1BVUkVfXyAqLyBpc1JlZihyYXdWYWx1ZSkpIHtcbiAgICByZXR1cm4gcmF3VmFsdWU7XG4gIH1cbiAgcmV0dXJuIG5ldyBSZWZJbXBsKHJhd1ZhbHVlLCBzaGFsbG93KTtcbn1cbmNsYXNzIFJlZkltcGwge1xuICBjb25zdHJ1Y3Rvcih2YWx1ZSwgaXNTaGFsbG93Mikge1xuICAgIHRoaXMuZGVwID0gbmV3IERlcCgpO1xuICAgIHRoaXNbXCJfX3ZfaXNSZWZcIl0gPSB0cnVlO1xuICAgIHRoaXNbXCJfX3ZfaXNTaGFsbG93XCJdID0gZmFsc2U7XG4gICAgdGhpcy5fcmF3VmFsdWUgPSBpc1NoYWxsb3cyID8gdmFsdWUgOiB0b1Jhdyh2YWx1ZSk7XG4gICAgdGhpcy5fdmFsdWUgPSBpc1NoYWxsb3cyID8gdmFsdWUgOiB0b1JlYWN0aXZlKHZhbHVlKTtcbiAgICB0aGlzW1wiX192X2lzU2hhbGxvd1wiXSA9IGlzU2hhbGxvdzI7XG4gIH1cbiAgZ2V0IHZhbHVlKCkge1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICB0aGlzLmRlcC50cmFjayh7XG4gICAgICAgIHRhcmdldDogdGhpcyxcbiAgICAgICAgdHlwZTogXCJnZXRcIixcbiAgICAgICAga2V5OiBcInZhbHVlXCJcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmRlcC50cmFjaygpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fdmFsdWU7XG4gIH1cbiAgc2V0IHZhbHVlKG5ld1ZhbHVlKSB7XG4gICAgY29uc3Qgb2xkVmFsdWUgPSB0aGlzLl9yYXdWYWx1ZTtcbiAgICBjb25zdCB1c2VEaXJlY3RWYWx1ZSA9IHRoaXNbXCJfX3ZfaXNTaGFsbG93XCJdIHx8IGlzU2hhbGxvdyhuZXdWYWx1ZSkgfHwgaXNSZWFkb25seShuZXdWYWx1ZSk7XG4gICAgbmV3VmFsdWUgPSB1c2VEaXJlY3RWYWx1ZSA/IG5ld1ZhbHVlIDogdG9SYXcobmV3VmFsdWUpO1xuICAgIGlmIChoYXNDaGFuZ2VkKG5ld1ZhbHVlLCBvbGRWYWx1ZSkpIHtcbiAgICAgIHRoaXMuX3Jhd1ZhbHVlID0gbmV3VmFsdWU7XG4gICAgICB0aGlzLl92YWx1ZSA9IHVzZURpcmVjdFZhbHVlID8gbmV3VmFsdWUgOiB0b1JlYWN0aXZlKG5ld1ZhbHVlKTtcbiAgICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICAgIHRoaXMuZGVwLnRyaWdnZXIoe1xuICAgICAgICAgIHRhcmdldDogdGhpcyxcbiAgICAgICAgICB0eXBlOiBcInNldFwiLFxuICAgICAgICAgIGtleTogXCJ2YWx1ZVwiLFxuICAgICAgICAgIG5ld1ZhbHVlLFxuICAgICAgICAgIG9sZFZhbHVlXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5kZXAudHJpZ2dlcigpO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gdHJpZ2dlclJlZihyZWYyKSB7XG4gIGlmIChyZWYyLmRlcCkge1xuICAgIGlmICghIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpKSB7XG4gICAgICByZWYyLmRlcC50cmlnZ2VyKHtcbiAgICAgICAgdGFyZ2V0OiByZWYyLFxuICAgICAgICB0eXBlOiBcInNldFwiLFxuICAgICAgICBrZXk6IFwidmFsdWVcIixcbiAgICAgICAgbmV3VmFsdWU6IHJlZjIuX3ZhbHVlXG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmVmMi5kZXAudHJpZ2dlcigpO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gdW5yZWYocmVmMikge1xuICByZXR1cm4gLyogQF9fUFVSRV9fICovIGlzUmVmKHJlZjIpID8gcmVmMi52YWx1ZSA6IHJlZjI7XG59XG5mdW5jdGlvbiB0b1ZhbHVlKHNvdXJjZSkge1xuICByZXR1cm4gaXNGdW5jdGlvbihzb3VyY2UpID8gc291cmNlKCkgOiB1bnJlZihzb3VyY2UpO1xufVxuY29uc3Qgc2hhbGxvd1Vud3JhcEhhbmRsZXJzID0ge1xuICBnZXQ6ICh0YXJnZXQsIGtleSwgcmVjZWl2ZXIpID0+IGtleSA9PT0gXCJfX3ZfcmF3XCIgPyB0YXJnZXQgOiB1bnJlZihSZWZsZWN0LmdldCh0YXJnZXQsIGtleSwgcmVjZWl2ZXIpKSxcbiAgc2V0OiAodGFyZ2V0LCBrZXksIHZhbHVlLCByZWNlaXZlcikgPT4ge1xuICAgIGNvbnN0IG9sZFZhbHVlID0gdGFyZ2V0W2tleV07XG4gICAgaWYgKC8qIEBfX1BVUkVfXyAqLyBpc1JlZihvbGRWYWx1ZSkgJiYgIS8qIEBfX1BVUkVfXyAqLyBpc1JlZih2YWx1ZSkpIHtcbiAgICAgIG9sZFZhbHVlLnZhbHVlID0gdmFsdWU7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIFJlZmxlY3Quc2V0KHRhcmdldCwga2V5LCB2YWx1ZSwgcmVjZWl2ZXIpO1xuICAgIH1cbiAgfVxufTtcbmZ1bmN0aW9uIHByb3h5UmVmcyhvYmplY3RXaXRoUmVmcykge1xuICByZXR1cm4gaXNSZWFjdGl2ZShvYmplY3RXaXRoUmVmcykgPyBvYmplY3RXaXRoUmVmcyA6IG5ldyBQcm94eShvYmplY3RXaXRoUmVmcywgc2hhbGxvd1Vud3JhcEhhbmRsZXJzKTtcbn1cbmNsYXNzIEN1c3RvbVJlZkltcGwge1xuICBjb25zdHJ1Y3RvcihmYWN0b3J5KSB7XG4gICAgdGhpc1tcIl9fdl9pc1JlZlwiXSA9IHRydWU7XG4gICAgdGhpcy5fdmFsdWUgPSB2b2lkIDA7XG4gICAgY29uc3QgZGVwID0gdGhpcy5kZXAgPSBuZXcgRGVwKCk7XG4gICAgY29uc3QgeyBnZXQsIHNldCB9ID0gZmFjdG9yeShkZXAudHJhY2suYmluZChkZXApLCBkZXAudHJpZ2dlci5iaW5kKGRlcCkpO1xuICAgIHRoaXMuX2dldCA9IGdldDtcbiAgICB0aGlzLl9zZXQgPSBzZXQ7XG4gIH1cbiAgZ2V0IHZhbHVlKCkge1xuICAgIHJldHVybiB0aGlzLl92YWx1ZSA9IHRoaXMuX2dldCgpO1xuICB9XG4gIHNldCB2YWx1ZShuZXdWYWwpIHtcbiAgICB0aGlzLl9zZXQobmV3VmFsKTtcbiAgfVxufVxuZnVuY3Rpb24gY3VzdG9tUmVmKGZhY3RvcnkpIHtcbiAgcmV0dXJuIG5ldyBDdXN0b21SZWZJbXBsKGZhY3RvcnkpO1xufVxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHRvUmVmcyhvYmplY3QpIHtcbiAgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWlzUHJveHkob2JqZWN0KSkge1xuICAgIHdhcm4oYHRvUmVmcygpIGV4cGVjdHMgYSByZWFjdGl2ZSBvYmplY3QgYnV0IHJlY2VpdmVkIGEgcGxhaW4gb25lLmApO1xuICB9XG4gIGNvbnN0IHJldCA9IGlzQXJyYXkob2JqZWN0KSA/IG5ldyBBcnJheShvYmplY3QubGVuZ3RoKSA6IHt9O1xuICBmb3IgKGNvbnN0IGtleSBpbiBvYmplY3QpIHtcbiAgICByZXRba2V5XSA9IHByb3BlcnR5VG9SZWYob2JqZWN0LCBrZXkpO1xuICB9XG4gIHJldHVybiByZXQ7XG59XG5jbGFzcyBPYmplY3RSZWZJbXBsIHtcbiAgY29uc3RydWN0b3IoX29iamVjdCwga2V5LCBfZGVmYXVsdFZhbHVlKSB7XG4gICAgdGhpcy5fb2JqZWN0ID0gX29iamVjdDtcbiAgICB0aGlzLl9kZWZhdWx0VmFsdWUgPSBfZGVmYXVsdFZhbHVlO1xuICAgIHRoaXNbXCJfX3ZfaXNSZWZcIl0gPSB0cnVlO1xuICAgIHRoaXMuX3ZhbHVlID0gdm9pZCAwO1xuICAgIHRoaXMuX2tleSA9IGlzU3ltYm9sKGtleSkgPyBrZXkgOiBTdHJpbmcoa2V5KTtcbiAgICB0aGlzLl9yYXcgPSB0b1Jhdyhfb2JqZWN0KTtcbiAgICBsZXQgc2hhbGxvdyA9IHRydWU7XG4gICAgbGV0IG9iaiA9IF9vYmplY3Q7XG4gICAgaWYgKCFpc0FycmF5KF9vYmplY3QpIHx8IGlzU3ltYm9sKHRoaXMuX2tleSkgfHwgIWlzSW50ZWdlcktleSh0aGlzLl9rZXkpKSB7XG4gICAgICBkbyB7XG4gICAgICAgIHNoYWxsb3cgPSAhaXNQcm94eShvYmopIHx8IGlzU2hhbGxvdyhvYmopO1xuICAgICAgfSB3aGlsZSAoc2hhbGxvdyAmJiAob2JqID0gb2JqW1wiX192X3Jhd1wiXSkpO1xuICAgIH1cbiAgICB0aGlzLl9zaGFsbG93ID0gc2hhbGxvdztcbiAgfVxuICBnZXQgdmFsdWUoKSB7XG4gICAgbGV0IHZhbCA9IHRoaXMuX29iamVjdFt0aGlzLl9rZXldO1xuICAgIGlmICh0aGlzLl9zaGFsbG93KSB7XG4gICAgICB2YWwgPSB1bnJlZih2YWwpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fdmFsdWUgPSB2YWwgPT09IHZvaWQgMCA/IHRoaXMuX2RlZmF1bHRWYWx1ZSA6IHZhbDtcbiAgfVxuICBzZXQgdmFsdWUobmV3VmFsKSB7XG4gICAgaWYgKHRoaXMuX3NoYWxsb3cgJiYgLyogQF9fUFVSRV9fICovIGlzUmVmKHRoaXMuX3Jhd1t0aGlzLl9rZXldKSkge1xuICAgICAgY29uc3QgbmVzdGVkUmVmID0gdGhpcy5fb2JqZWN0W3RoaXMuX2tleV07XG4gICAgICBpZiAoLyogQF9fUFVSRV9fICovIGlzUmVmKG5lc3RlZFJlZikpIHtcbiAgICAgICAgbmVzdGVkUmVmLnZhbHVlID0gbmV3VmFsO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfVxuICAgIHRoaXMuX29iamVjdFt0aGlzLl9rZXldID0gbmV3VmFsO1xuICB9XG4gIGdldCBkZXAoKSB7XG4gICAgcmV0dXJuIGdldERlcEZyb21SZWFjdGl2ZSh0aGlzLl9yYXcsIHRoaXMuX2tleSk7XG4gIH1cbn1cbmNsYXNzIEdldHRlclJlZkltcGwge1xuICBjb25zdHJ1Y3RvcihfZ2V0dGVyKSB7XG4gICAgdGhpcy5fZ2V0dGVyID0gX2dldHRlcjtcbiAgICB0aGlzW1wiX192X2lzUmVmXCJdID0gdHJ1ZTtcbiAgICB0aGlzW1wiX192X2lzUmVhZG9ubHlcIl0gPSB0cnVlO1xuICAgIHRoaXMuX3ZhbHVlID0gdm9pZCAwO1xuICB9XG4gIGdldCB2YWx1ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5fdmFsdWUgPSB0aGlzLl9nZXR0ZXIoKTtcbiAgfVxufVxuLy8gQF9fTk9fU0lERV9FRkZFQ1RTX19cbmZ1bmN0aW9uIHRvUmVmKHNvdXJjZSwga2V5LCBkZWZhdWx0VmFsdWUpIHtcbiAgaWYgKC8qIEBfX1BVUkVfXyAqLyBpc1JlZihzb3VyY2UpKSB7XG4gICAgcmV0dXJuIHNvdXJjZTtcbiAgfSBlbHNlIGlmIChpc0Z1bmN0aW9uKHNvdXJjZSkpIHtcbiAgICByZXR1cm4gbmV3IEdldHRlclJlZkltcGwoc291cmNlKTtcbiAgfSBlbHNlIGlmIChpc09iamVjdChzb3VyY2UpICYmIGFyZ3VtZW50cy5sZW5ndGggPiAxKSB7XG4gICAgcmV0dXJuIHByb3BlcnR5VG9SZWYoc291cmNlLCBrZXksIGRlZmF1bHRWYWx1ZSk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyByZWYoc291cmNlKTtcbiAgfVxufVxuZnVuY3Rpb24gcHJvcGVydHlUb1JlZihzb3VyY2UsIGtleSwgZGVmYXVsdFZhbHVlKSB7XG4gIHJldHVybiBuZXcgT2JqZWN0UmVmSW1wbChzb3VyY2UsIGtleSwgZGVmYXVsdFZhbHVlKTtcbn1cblxuY2xhc3MgQ29tcHV0ZWRSZWZJbXBsIHtcbiAgY29uc3RydWN0b3IoZm4sIHNldHRlciwgaXNTU1IpIHtcbiAgICB0aGlzLmZuID0gZm47XG4gICAgdGhpcy5zZXR0ZXIgPSBzZXR0ZXI7XG4gICAgLyoqXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5fdmFsdWUgPSB2b2lkIDA7XG4gICAgLyoqXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgdGhpcy5kZXAgPSBuZXcgRGVwKHRoaXMpO1xuICAgIC8qKlxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMuX192X2lzUmVmID0gdHJ1ZTtcbiAgICAvLyBUT0RPIGlzb2xhdGVkRGVjbGFyYXRpb25zIFwiX192X2lzUmVhZG9ubHlcIlxuICAgIC8vIEEgY29tcHV0ZWQgaXMgYWxzbyBhIHN1YnNjcmliZXIgdGhhdCB0cmFja3Mgb3RoZXIgZGVwc1xuICAgIC8qKlxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMuZGVwcyA9IHZvaWQgMDtcbiAgICAvKipcbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLmRlcHNUYWlsID0gdm9pZCAwO1xuICAgIC8qKlxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIHRoaXMuZmxhZ3MgPSAxNjtcbiAgICAvKipcbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLmdsb2JhbFZlcnNpb24gPSBnbG9iYWxWZXJzaW9uIC0gMTtcbiAgICAvKipcbiAgICAgKiBAaW50ZXJuYWxcbiAgICAgKi9cbiAgICB0aGlzLm5leHQgPSB2b2lkIDA7XG4gICAgLy8gZm9yIGJhY2t3YXJkcyBjb21wYXRcbiAgICB0aGlzLmVmZmVjdCA9IHRoaXM7XG4gICAgdGhpc1tcIl9fdl9pc1JlYWRvbmx5XCJdID0gIXNldHRlcjtcbiAgICB0aGlzLmlzU1NSID0gaXNTU1I7XG4gIH1cbiAgLyoqXG4gICAqIEBpbnRlcm5hbFxuICAgKi9cbiAgbm90aWZ5KCkge1xuICAgIHRoaXMuZmxhZ3MgfD0gMTY7XG4gICAgaWYgKCEodGhpcy5mbGFncyAmIDgpICYmIC8vIGF2b2lkIGluZmluaXRlIHNlbGYgcmVjdXJzaW9uXG4gICAgYWN0aXZlU3ViICE9PSB0aGlzKSB7XG4gICAgICBiYXRjaCh0aGlzLCB0cnVlKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH0gZWxzZSBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkgO1xuICB9XG4gIGdldCB2YWx1ZSgpIHtcbiAgICBjb25zdCBsaW5rID0gISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSA/IHRoaXMuZGVwLnRyYWNrKHtcbiAgICAgIHRhcmdldDogdGhpcyxcbiAgICAgIHR5cGU6IFwiZ2V0XCIsXG4gICAgICBrZXk6IFwidmFsdWVcIlxuICAgIH0pIDogdGhpcy5kZXAudHJhY2soKTtcbiAgICByZWZyZXNoQ29tcHV0ZWQodGhpcyk7XG4gICAgaWYgKGxpbmspIHtcbiAgICAgIGxpbmsudmVyc2lvbiA9IHRoaXMuZGVwLnZlcnNpb247XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl92YWx1ZTtcbiAgfVxuICBzZXQgdmFsdWUobmV3VmFsdWUpIHtcbiAgICBpZiAodGhpcy5zZXR0ZXIpIHtcbiAgICAgIHRoaXMuc2V0dGVyKG5ld1ZhbHVlKTtcbiAgICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikpIHtcbiAgICAgIHdhcm4oXCJXcml0ZSBvcGVyYXRpb24gZmFpbGVkOiBjb21wdXRlZCB2YWx1ZSBpcyByZWFkb25seVwiKTtcbiAgICB9XG4gIH1cbn1cbi8vIEBfX05PX1NJREVfRUZGRUNUU19fXG5mdW5jdGlvbiBjb21wdXRlZChnZXR0ZXJPck9wdGlvbnMsIGRlYnVnT3B0aW9ucywgaXNTU1IgPSBmYWxzZSkge1xuICBsZXQgZ2V0dGVyO1xuICBsZXQgc2V0dGVyO1xuICBpZiAoaXNGdW5jdGlvbihnZXR0ZXJPck9wdGlvbnMpKSB7XG4gICAgZ2V0dGVyID0gZ2V0dGVyT3JPcHRpb25zO1xuICB9IGVsc2Uge1xuICAgIGdldHRlciA9IGdldHRlck9yT3B0aW9ucy5nZXQ7XG4gICAgc2V0dGVyID0gZ2V0dGVyT3JPcHRpb25zLnNldDtcbiAgfVxuICBjb25zdCBjUmVmID0gbmV3IENvbXB1dGVkUmVmSW1wbChnZXR0ZXIsIHNldHRlciwgaXNTU1IpO1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiBkZWJ1Z09wdGlvbnMgJiYgIWlzU1NSKSB7XG4gICAgY1JlZi5vblRyYWNrID0gZGVidWdPcHRpb25zLm9uVHJhY2s7XG4gICAgY1JlZi5vblRyaWdnZXIgPSBkZWJ1Z09wdGlvbnMub25UcmlnZ2VyO1xuICB9XG4gIHJldHVybiBjUmVmO1xufVxuXG5jb25zdCBUcmFja09wVHlwZXMgPSB7XG4gIFwiR0VUXCI6IFwiZ2V0XCIsXG4gIFwiSEFTXCI6IFwiaGFzXCIsXG4gIFwiSVRFUkFURVwiOiBcIml0ZXJhdGVcIlxufTtcbmNvbnN0IFRyaWdnZXJPcFR5cGVzID0ge1xuICBcIlNFVFwiOiBcInNldFwiLFxuICBcIkFERFwiOiBcImFkZFwiLFxuICBcIkRFTEVURVwiOiBcImRlbGV0ZVwiLFxuICBcIkNMRUFSXCI6IFwiY2xlYXJcIlxufTtcbmNvbnN0IFJlYWN0aXZlRmxhZ3MgPSB7XG4gIFwiU0tJUFwiOiBcIl9fdl9za2lwXCIsXG4gIFwiSVNfUkVBQ1RJVkVcIjogXCJfX3ZfaXNSZWFjdGl2ZVwiLFxuICBcIklTX1JFQURPTkxZXCI6IFwiX192X2lzUmVhZG9ubHlcIixcbiAgXCJJU19TSEFMTE9XXCI6IFwiX192X2lzU2hhbGxvd1wiLFxuICBcIlJBV1wiOiBcIl9fdl9yYXdcIixcbiAgXCJJU19SRUZcIjogXCJfX3ZfaXNSZWZcIlxufTtcblxuY29uc3QgV2F0Y2hFcnJvckNvZGVzID0ge1xuICBcIldBVENIX0dFVFRFUlwiOiAyLFxuICBcIjJcIjogXCJXQVRDSF9HRVRURVJcIixcbiAgXCJXQVRDSF9DQUxMQkFDS1wiOiAzLFxuICBcIjNcIjogXCJXQVRDSF9DQUxMQkFDS1wiLFxuICBcIldBVENIX0NMRUFOVVBcIjogNCxcbiAgXCI0XCI6IFwiV0FUQ0hfQ0xFQU5VUFwiXG59O1xuY29uc3QgSU5JVElBTF9XQVRDSEVSX1ZBTFVFID0ge307XG5jb25zdCBjbGVhbnVwTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5sZXQgYWN0aXZlV2F0Y2hlciA9IHZvaWQgMDtcbmZ1bmN0aW9uIGdldEN1cnJlbnRXYXRjaGVyKCkge1xuICByZXR1cm4gYWN0aXZlV2F0Y2hlcjtcbn1cbmZ1bmN0aW9uIG9uV2F0Y2hlckNsZWFudXAoY2xlYW51cEZuLCBmYWlsU2lsZW50bHkgPSBmYWxzZSwgb3duZXIgPSBhY3RpdmVXYXRjaGVyKSB7XG4gIGlmIChvd25lcikge1xuICAgIGxldCBjbGVhbnVwcyA9IGNsZWFudXBNYXAuZ2V0KG93bmVyKTtcbiAgICBpZiAoIWNsZWFudXBzKSBjbGVhbnVwTWFwLnNldChvd25lciwgY2xlYW51cHMgPSBbXSk7XG4gICAgY2xlYW51cHMucHVzaChjbGVhbnVwRm4pO1xuICB9IGVsc2UgaWYgKCEhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgJiYgIWZhaWxTaWxlbnRseSkge1xuICAgIHdhcm4oXG4gICAgICBgb25XYXRjaGVyQ2xlYW51cCgpIHdhcyBjYWxsZWQgd2hlbiB0aGVyZSB3YXMgbm8gYWN0aXZlIHdhdGNoZXIgdG8gYXNzb2NpYXRlIHdpdGguYFxuICAgICk7XG4gIH1cbn1cbmZ1bmN0aW9uIHdhdGNoKHNvdXJjZSwgY2IsIG9wdGlvbnMgPSBFTVBUWV9PQkopIHtcbiAgY29uc3QgeyBpbW1lZGlhdGUsIGRlZXAsIG9uY2UsIHNjaGVkdWxlciwgYXVnbWVudEpvYiwgY2FsbCB9ID0gb3B0aW9ucztcbiAgY29uc3Qgd2FybkludmFsaWRTb3VyY2UgPSAocykgPT4ge1xuICAgIChvcHRpb25zLm9uV2FybiB8fCB3YXJuKShcbiAgICAgIGBJbnZhbGlkIHdhdGNoIHNvdXJjZTogYCxcbiAgICAgIHMsXG4gICAgICBgQSB3YXRjaCBzb3VyY2UgY2FuIG9ubHkgYmUgYSBnZXR0ZXIvZWZmZWN0IGZ1bmN0aW9uLCBhIHJlZiwgYSByZWFjdGl2ZSBvYmplY3QsIG9yIGFuIGFycmF5IG9mIHRoZXNlIHR5cGVzLmBcbiAgICApO1xuICB9O1xuICBjb25zdCByZWFjdGl2ZUdldHRlciA9IChzb3VyY2UyKSA9PiB7XG4gICAgaWYgKGRlZXApIHJldHVybiBzb3VyY2UyO1xuICAgIGlmIChpc1NoYWxsb3coc291cmNlMikgfHwgZGVlcCA9PT0gZmFsc2UgfHwgZGVlcCA9PT0gMClcbiAgICAgIHJldHVybiB0cmF2ZXJzZShzb3VyY2UyLCAxKTtcbiAgICByZXR1cm4gdHJhdmVyc2Uoc291cmNlMik7XG4gIH07XG4gIGxldCBlZmZlY3Q7XG4gIGxldCBnZXR0ZXI7XG4gIGxldCBjbGVhbnVwO1xuICBsZXQgYm91bmRDbGVhbnVwO1xuICBsZXQgZm9yY2VUcmlnZ2VyID0gZmFsc2U7XG4gIGxldCBpc011bHRpU291cmNlID0gZmFsc2U7XG4gIGlmIChpc1JlZihzb3VyY2UpKSB7XG4gICAgZ2V0dGVyID0gKCkgPT4gc291cmNlLnZhbHVlO1xuICAgIGZvcmNlVHJpZ2dlciA9IGlzU2hhbGxvdyhzb3VyY2UpO1xuICB9IGVsc2UgaWYgKGlzUmVhY3RpdmUoc291cmNlKSkge1xuICAgIGdldHRlciA9ICgpID0+IHJlYWN0aXZlR2V0dGVyKHNvdXJjZSk7XG4gICAgZm9yY2VUcmlnZ2VyID0gdHJ1ZTtcbiAgfSBlbHNlIGlmIChpc0FycmF5KHNvdXJjZSkpIHtcbiAgICBpc011bHRpU291cmNlID0gdHJ1ZTtcbiAgICBmb3JjZVRyaWdnZXIgPSBzb3VyY2Uuc29tZSgocykgPT4gaXNSZWFjdGl2ZShzKSB8fCBpc1NoYWxsb3cocykpO1xuICAgIGdldHRlciA9ICgpID0+IHNvdXJjZS5tYXAoKHMpID0+IHtcbiAgICAgIGlmIChpc1JlZihzKSkge1xuICAgICAgICByZXR1cm4gcy52YWx1ZTtcbiAgICAgIH0gZWxzZSBpZiAoaXNSZWFjdGl2ZShzKSkge1xuICAgICAgICByZXR1cm4gcmVhY3RpdmVHZXR0ZXIocyk7XG4gICAgICB9IGVsc2UgaWYgKGlzRnVuY3Rpb24ocykpIHtcbiAgICAgICAgcmV0dXJuIGNhbGwgPyBjYWxsKHMsIDIpIDogcygpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSAmJiB3YXJuSW52YWxpZFNvdXJjZShzKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSBlbHNlIGlmIChpc0Z1bmN0aW9uKHNvdXJjZSkpIHtcbiAgICBpZiAoY2IpIHtcbiAgICAgIGdldHRlciA9IGNhbGwgPyAoKSA9PiBjYWxsKHNvdXJjZSwgMikgOiBzb3VyY2U7XG4gICAgfSBlbHNlIHtcbiAgICAgIGdldHRlciA9ICgpID0+IHtcbiAgICAgICAgaWYgKGNsZWFudXApIHtcbiAgICAgICAgICBwYXVzZVRyYWNraW5nKCk7XG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNsZWFudXAoKTtcbiAgICAgICAgICB9IGZpbmFsbHkge1xuICAgICAgICAgICAgcmVzZXRUcmFja2luZygpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjdXJyZW50RWZmZWN0ID0gYWN0aXZlV2F0Y2hlcjtcbiAgICAgICAgYWN0aXZlV2F0Y2hlciA9IGVmZmVjdDtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICByZXR1cm4gY2FsbCA/IGNhbGwoc291cmNlLCAzLCBbYm91bmRDbGVhbnVwXSkgOiBzb3VyY2UoYm91bmRDbGVhbnVwKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICBhY3RpdmVXYXRjaGVyID0gY3VycmVudEVmZmVjdDtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgZ2V0dGVyID0gTk9PUDtcbiAgICAhIShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpICYmIHdhcm5JbnZhbGlkU291cmNlKHNvdXJjZSk7XG4gIH1cbiAgaWYgKGNiICYmIGRlZXApIHtcbiAgICBjb25zdCBiYXNlR2V0dGVyID0gZ2V0dGVyO1xuICAgIGNvbnN0IGRlcHRoID0gZGVlcCA9PT0gdHJ1ZSA/IEluZmluaXR5IDogZGVlcDtcbiAgICBnZXR0ZXIgPSAoKSA9PiB0cmF2ZXJzZShiYXNlR2V0dGVyKCksIGRlcHRoKTtcbiAgfVxuICBjb25zdCBzY29wZSA9IGdldEN1cnJlbnRTY29wZSgpO1xuICBjb25zdCB3YXRjaEhhbmRsZSA9ICgpID0+IHtcbiAgICBlZmZlY3Quc3RvcCgpO1xuICAgIGlmIChzY29wZSAmJiBzY29wZS5hY3RpdmUpIHtcbiAgICAgIHJlbW92ZShzY29wZS5lZmZlY3RzLCBlZmZlY3QpO1xuICAgIH1cbiAgfTtcbiAgaWYgKG9uY2UgJiYgY2IpIHtcbiAgICBjb25zdCBfY2IgPSBjYjtcbiAgICBjYiA9ICguLi5hcmdzKSA9PiB7XG4gICAgICBjb25zdCByZXMgPSBfY2IoLi4uYXJncyk7XG4gICAgICB3YXRjaEhhbmRsZSgpO1xuICAgICAgcmV0dXJuIHJlcztcbiAgICB9O1xuICB9XG4gIGxldCBvbGRWYWx1ZSA9IGlzTXVsdGlTb3VyY2UgPyBuZXcgQXJyYXkoc291cmNlLmxlbmd0aCkuZmlsbChJTklUSUFMX1dBVENIRVJfVkFMVUUpIDogSU5JVElBTF9XQVRDSEVSX1ZBTFVFO1xuICBjb25zdCBqb2IgPSAoaW1tZWRpYXRlRmlyc3RSdW4pID0+IHtcbiAgICBpZiAoIShlZmZlY3QuZmxhZ3MgJiAxKSB8fCAhZWZmZWN0LmRpcnR5ICYmICFpbW1lZGlhdGVGaXJzdFJ1bikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoY2IpIHtcbiAgICAgIGNvbnN0IG5ld1ZhbHVlID0gZWZmZWN0LnJ1bigpO1xuICAgICAgaWYgKGltbWVkaWF0ZUZpcnN0UnVuIHx8IGRlZXAgfHwgZm9yY2VUcmlnZ2VyIHx8IChpc011bHRpU291cmNlID8gbmV3VmFsdWUuc29tZSgodiwgaSkgPT4gaGFzQ2hhbmdlZCh2LCBvbGRWYWx1ZVtpXSkpIDogaGFzQ2hhbmdlZChuZXdWYWx1ZSwgb2xkVmFsdWUpKSkge1xuICAgICAgICBpZiAoY2xlYW51cCkge1xuICAgICAgICAgIGNsZWFudXAoKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjdXJyZW50V2F0Y2hlciA9IGFjdGl2ZVdhdGNoZXI7XG4gICAgICAgIGFjdGl2ZVdhdGNoZXIgPSBlZmZlY3Q7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgYXJncyA9IFtcbiAgICAgICAgICAgIG5ld1ZhbHVlLFxuICAgICAgICAgICAgLy8gcGFzcyB1bmRlZmluZWQgYXMgdGhlIG9sZCB2YWx1ZSB3aGVuIGl0J3MgY2hhbmdlZCBmb3IgdGhlIGZpcnN0IHRpbWVcbiAgICAgICAgICAgIG9sZFZhbHVlID09PSBJTklUSUFMX1dBVENIRVJfVkFMVUUgPyB2b2lkIDAgOiBpc011bHRpU291cmNlICYmIG9sZFZhbHVlWzBdID09PSBJTklUSUFMX1dBVENIRVJfVkFMVUUgPyBbXSA6IG9sZFZhbHVlLFxuICAgICAgICAgICAgYm91bmRDbGVhbnVwXG4gICAgICAgICAgXTtcbiAgICAgICAgICBvbGRWYWx1ZSA9IG5ld1ZhbHVlO1xuICAgICAgICAgIGNhbGwgPyBjYWxsKGNiLCAzLCBhcmdzKSA6IChcbiAgICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgICAgIGNiKC4uLmFyZ3MpXG4gICAgICAgICAgKTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICBhY3RpdmVXYXRjaGVyID0gY3VycmVudFdhdGNoZXI7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgZWZmZWN0LnJ1bigpO1xuICAgIH1cbiAgfTtcbiAgaWYgKGF1Z21lbnRKb2IpIHtcbiAgICBhdWdtZW50Sm9iKGpvYik7XG4gIH1cbiAgZWZmZWN0ID0gbmV3IFJlYWN0aXZlRWZmZWN0KGdldHRlcik7XG4gIGVmZmVjdC5zY2hlZHVsZXIgPSBzY2hlZHVsZXIgPyAoKSA9PiBzY2hlZHVsZXIoam9iLCBmYWxzZSkgOiBqb2I7XG4gIGJvdW5kQ2xlYW51cCA9IChmbikgPT4gb25XYXRjaGVyQ2xlYW51cChmbiwgZmFsc2UsIGVmZmVjdCk7XG4gIGNsZWFudXAgPSBlZmZlY3Qub25TdG9wID0gKCkgPT4ge1xuICAgIGNvbnN0IGNsZWFudXBzID0gY2xlYW51cE1hcC5nZXQoZWZmZWN0KTtcbiAgICBpZiAoY2xlYW51cHMpIHtcbiAgICAgIGlmIChjYWxsKSB7XG4gICAgICAgIGNhbGwoY2xlYW51cHMsIDQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZm9yIChjb25zdCBjbGVhbnVwMiBvZiBjbGVhbnVwcykgY2xlYW51cDIoKTtcbiAgICAgIH1cbiAgICAgIGNsZWFudXBNYXAuZGVsZXRlKGVmZmVjdCk7XG4gICAgfVxuICB9O1xuICBpZiAoISEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSkge1xuICAgIGVmZmVjdC5vblRyYWNrID0gb3B0aW9ucy5vblRyYWNrO1xuICAgIGVmZmVjdC5vblRyaWdnZXIgPSBvcHRpb25zLm9uVHJpZ2dlcjtcbiAgfVxuICBpZiAoY2IpIHtcbiAgICBpZiAoaW1tZWRpYXRlKSB7XG4gICAgICBqb2IodHJ1ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIG9sZFZhbHVlID0gZWZmZWN0LnJ1bigpO1xuICAgIH1cbiAgfSBlbHNlIGlmIChzY2hlZHVsZXIpIHtcbiAgICBzY2hlZHVsZXIoam9iLmJpbmQobnVsbCwgdHJ1ZSksIHRydWUpO1xuICB9IGVsc2Uge1xuICAgIGVmZmVjdC5ydW4oKTtcbiAgfVxuICB3YXRjaEhhbmRsZS5wYXVzZSA9IGVmZmVjdC5wYXVzZS5iaW5kKGVmZmVjdCk7XG4gIHdhdGNoSGFuZGxlLnJlc3VtZSA9IGVmZmVjdC5yZXN1bWUuYmluZChlZmZlY3QpO1xuICB3YXRjaEhhbmRsZS5zdG9wID0gd2F0Y2hIYW5kbGU7XG4gIHJldHVybiB3YXRjaEhhbmRsZTtcbn1cbmZ1bmN0aW9uIHRyYXZlcnNlKHZhbHVlLCBkZXB0aCA9IEluZmluaXR5LCBzZWVuKSB7XG4gIGlmIChkZXB0aCA8PSAwIHx8ICFpc09iamVjdCh2YWx1ZSkgfHwgdmFsdWVbXCJfX3Zfc2tpcFwiXSkge1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfVxuICBzZWVuID0gc2VlbiB8fCAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICBpZiAoKHNlZW4uZ2V0KHZhbHVlKSB8fCAwKSA+PSBkZXB0aCkge1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfVxuICBzZWVuLnNldCh2YWx1ZSwgZGVwdGgpO1xuICBkZXB0aC0tO1xuICBpZiAoaXNSZWYodmFsdWUpKSB7XG4gICAgdHJhdmVyc2UodmFsdWUudmFsdWUsIGRlcHRoLCBzZWVuKTtcbiAgfSBlbHNlIGlmIChpc0FycmF5KHZhbHVlKSkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdmFsdWUubGVuZ3RoOyBpKyspIHtcbiAgICAgIHRyYXZlcnNlKHZhbHVlW2ldLCBkZXB0aCwgc2Vlbik7XG4gICAgfVxuICB9IGVsc2UgaWYgKGlzU2V0KHZhbHVlKSB8fCBpc01hcCh2YWx1ZSkpIHtcbiAgICB2YWx1ZS5mb3JFYWNoKCh2KSA9PiB7XG4gICAgICB0cmF2ZXJzZSh2LCBkZXB0aCwgc2Vlbik7XG4gICAgfSk7XG4gIH0gZWxzZSBpZiAoaXNQbGFpbk9iamVjdCh2YWx1ZSkpIHtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiB2YWx1ZSkge1xuICAgICAgdHJhdmVyc2UodmFsdWVba2V5XSwgZGVwdGgsIHNlZW4pO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHZhbHVlKSkge1xuICAgICAgaWYgKE9iamVjdC5wcm90b3R5cGUucHJvcGVydHlJc0VudW1lcmFibGUuY2FsbCh2YWx1ZSwga2V5KSkge1xuICAgICAgICB0cmF2ZXJzZSh2YWx1ZVtrZXldLCBkZXB0aCwgc2Vlbik7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiB2YWx1ZTtcbn1cblxuZXhwb3J0IHsgQVJSQVlfSVRFUkFURV9LRVksIEVmZmVjdEZsYWdzLCBFZmZlY3RTY29wZSwgSVRFUkFURV9LRVksIE1BUF9LRVlfSVRFUkFURV9LRVksIFJlYWN0aXZlRWZmZWN0LCBSZWFjdGl2ZUZsYWdzLCBUcmFja09wVHlwZXMsIFRyaWdnZXJPcFR5cGVzLCBXYXRjaEVycm9yQ29kZXMsIGNvbXB1dGVkLCBjdXN0b21SZWYsIGVmZmVjdCwgZWZmZWN0U2NvcGUsIGVuYWJsZVRyYWNraW5nLCBnZXRDdXJyZW50U2NvcGUsIGdldEN1cnJlbnRXYXRjaGVyLCBpc1Byb3h5LCBpc1JlYWN0aXZlLCBpc1JlYWRvbmx5LCBpc1JlZiwgaXNTaGFsbG93LCBtYXJrUmF3LCBvbkVmZmVjdENsZWFudXAsIG9uU2NvcGVEaXNwb3NlLCBvbldhdGNoZXJDbGVhbnVwLCBwYXVzZVRyYWNraW5nLCBwcm94eVJlZnMsIHJlYWN0aXZlLCByZWFjdGl2ZVJlYWRBcnJheSwgcmVhZG9ubHksIHJlZiwgcmVzZXRUcmFja2luZywgc2hhbGxvd1JlYWN0aXZlLCBzaGFsbG93UmVhZEFycmF5LCBzaGFsbG93UmVhZG9ubHksIHNoYWxsb3dSZWYsIHN0b3AsIHRvUmF3LCB0b1JlYWN0aXZlLCB0b1JlYWRvbmx5LCB0b1JlZiwgdG9SZWZzLCB0b1ZhbHVlLCB0cmFjaywgdHJhdmVyc2UsIHRyaWdnZXIsIHRyaWdnZXJSZWYsIHVucmVmLCB3YXRjaCB9O1xuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=