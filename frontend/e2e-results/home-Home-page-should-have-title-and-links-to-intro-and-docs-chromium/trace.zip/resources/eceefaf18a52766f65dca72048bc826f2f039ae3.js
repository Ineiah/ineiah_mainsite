/*!
* core-base v11.4.8
* (c) 2026 kazuya kawaguchi
* Released under the MIT License.
*/
import { getGlobalThis, isObject, hasOwn, isNumber, create, isString, isBoolean, warn, format as format$1, isArray, isPlainObject, isFunction, isPromise, assign, isRegExp, warnOnce, isEmptyObject, isDate, toDisplayString, join, sanitizeTranslatedHtml, escapeHtml, inBrowser, mark, measure, generateFormatCacheKey, generateCodeFrame } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@intlify+shared@11.4.8/node_modules/@intlify/shared/dist/shared.mjs?v=7e73afc2";
import { detectHtmlTag, defaultOnError, baseCompile as baseCompile$1, COMPILE_ERROR_CODES_EXTEND_POINT, createCompileError } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@intlify+message-compiler@11.4.8/node_modules/@intlify/message-compiler/dist/message-compiler.mjs?v=7e73afc2";
export { CompileErrorCodes, createCompileError } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@intlify+message-compiler@11.4.8/node_modules/@intlify/message-compiler/dist/message-compiler.mjs?v=7e73afc2";
/**
* This is only called in esm-bundler builds.
* istanbul-ignore-next
*/
function initFeatureFlags() {
	if (typeof __INTLIFY_PROD_DEVTOOLS__ !== "boolean") {
		getGlobalThis().__INTLIFY_PROD_DEVTOOLS__ = false;
	}
	if (typeof __INTLIFY_DROP_MESSAGE_COMPILER__ !== "boolean") {
		getGlobalThis().__INTLIFY_DROP_MESSAGE_COMPILER__ = false;
	}
}
function isMessageAST(val) {
	return isObject(val) && resolveType(val) === 0 && (hasOwn(val, "b") || hasOwn(val, "body"));
}
const PROPS_BODY = ["b", "body"];
function resolveBody(node) {
	return resolveProps(node, PROPS_BODY);
}
const PROPS_CASES = ["c", "cases"];
function resolveCases(node) {
	return resolveProps(node, PROPS_CASES, []);
}
const PROPS_STATIC = ["s", "static"];
function resolveStatic(node) {
	return resolveProps(node, PROPS_STATIC);
}
const PROPS_ITEMS = ["i", "items"];
function resolveItems(node) {
	return resolveProps(node, PROPS_ITEMS, []);
}
const PROPS_TYPE = ["t", "type"];
function resolveType(node) {
	return resolveProps(node, PROPS_TYPE);
}
const PROPS_VALUE = ["v", "value"];
function resolveValue$1(node, type) {
	const resolved = resolveProps(node, PROPS_VALUE);
	if (resolved != null) {
		return resolved;
	} else {
		throw createUnhandleNodeError(type);
	}
}
const PROPS_MODIFIER = ["m", "modifier"];
function resolveLinkedModifier(node) {
	return resolveProps(node, PROPS_MODIFIER);
}
const PROPS_KEY = ["k", "key"];
function resolveLinkedKey(node) {
	const resolved = resolveProps(node, PROPS_KEY);
	if (resolved) {
		return resolved;
	} else {
		throw createUnhandleNodeError(
			6
			/* NodeTypes.Linked */
		);
	}
}
function resolveProps(node, props, defaultValue) {
	for (let i = 0; i < props.length; i++) {
		const prop = props[i];
		// eslint-disable-next-line @typescript-eslint/no-explicit-any
		if (hasOwn(node, prop) && node[prop] != null) {
			// eslint-disable-next-line @typescript-eslint/no-explicit-any
			return node[prop];
		}
	}
	return defaultValue;
}
const AST_NODE_PROPS_KEYS = [
	...PROPS_BODY,
	...PROPS_CASES,
	...PROPS_STATIC,
	...PROPS_ITEMS,
	...PROPS_KEY,
	...PROPS_MODIFIER,
	...PROPS_VALUE,
	...PROPS_TYPE
];
function createUnhandleNodeError(type) {
	return new Error(`unhandled node type: ${type}`);
}
function format(ast) {
	const msg = (ctx) => formatParts(ctx, ast);
	return msg;
}
function formatParts(ctx, ast) {
	const body = resolveBody(ast);
	if (body == null) {
		throw createUnhandleNodeError(
			0
			/* NodeTypes.Resource */
		);
	}
	const type = resolveType(body);
	if (type === 1) {
		const plural = body;
		const cases = resolveCases(plural);
		return ctx.plural(cases.reduce((messages, c) => [...messages, formatMessageParts(ctx, c)], []));
	} else {
		return formatMessageParts(ctx, body);
	}
}
function formatMessageParts(ctx, node) {
	const static_ = resolveStatic(node);
	if (static_ != null) {
		return ctx.type === "text" ? static_ : ctx.normalize([static_]);
	} else {
		const messages = resolveItems(node).reduce((acm, c) => [...acm, formatMessagePart(ctx, c)], []);
		return ctx.normalize(messages);
	}
}
function formatMessagePart(ctx, node) {
	const type = resolveType(node);
	switch (type) {
		case 3: {
			return resolveValue$1(node, type);
		}
		case 9: {
			return resolveValue$1(node, type);
		}
		case 4: {
			const named = node;
			if (hasOwn(named, "k") && named.k) {
				return ctx.interpolate(ctx.named(named.k));
			}
			if (hasOwn(named, "key") && named.key) {
				return ctx.interpolate(ctx.named(named.key));
			}
			throw createUnhandleNodeError(type);
		}
		case 5: {
			const list = node;
			if (hasOwn(list, "i") && isNumber(list.i)) {
				return ctx.interpolate(ctx.list(list.i));
			}
			if (hasOwn(list, "index") && isNumber(list.index)) {
				return ctx.interpolate(ctx.list(list.index));
			}
			throw createUnhandleNodeError(type);
		}
		case 6: {
			const linked = node;
			const modifier = resolveLinkedModifier(linked);
			const key = resolveLinkedKey(linked);
			return ctx.linked(formatMessagePart(ctx, key), modifier ? formatMessagePart(ctx, modifier) : undefined, ctx.type);
		}
		case 7: {
			return resolveValue$1(node, type);
		}
		case 8: {
			return resolveValue$1(node, type);
		}
		default: throw new Error(`unhandled node on format message part: ${type}`);
	}
}
const WARN_MESSAGE = `Detected HTML in '{source}' message. Recommend not using HTML messages to avoid XSS.`;
function checkHtmlMessage(source, warnHtmlMessage) {
	if (warnHtmlMessage && detectHtmlTag(source)) {
		warn(format$1(WARN_MESSAGE, { source }));
	}
}
const defaultOnCacheKey = (message) => message;
let compileCache = create();
function clearCompileCache() {
	compileCache = create();
}
function baseCompile(message, options = {}) {
	// error detecting on compile
	let detectError = false;
	const onError = options.onError || defaultOnError;
	options.onError = (err) => {
		detectError = true;
		onError(err);
	};
	// compile with mesasge-compiler
	return {
		...baseCompile$1(message, options),
		detectError
	};
}
/* #__NO_SIDE_EFFECTS__ */
function compile(message, context) {
	if (!__INTLIFY_DROP_MESSAGE_COMPILER__ && isString(message)) {
		// check HTML message
		const warnHtmlMessage = isBoolean(context.warnHtmlMessage) ? context.warnHtmlMessage : true;
		"development" !== "production" && checkHtmlMessage(message, warnHtmlMessage);
		// check caches
		const onCacheKey = context.onCacheKey || defaultOnCacheKey;
		const cacheKey = onCacheKey(message);
		const cached = compileCache[cacheKey];
		if (cached) {
			return cached;
		}
		// compile with JIT mode
		const { ast, detectError } = baseCompile(message, {
			...context,
			location: "development" !== "production",
			jit: true
		});
		// compose message function from AST
		const msg = format(ast);
		// if occurred compile error, don't cache
		return !detectError ? compileCache[cacheKey] = msg : msg;
	} else {
		if ("development" !== "production" && !isMessageAST(message)) {
			warn(`the message that is resolve with key '${context.key}' is not supported for jit compilation`);
			return (() => message);
		}
		// AST case (passed from bundler)
		const cacheKey = message.cacheKey;
		if (cacheKey) {
			const cached = compileCache[cacheKey];
			if (cached) {
				return cached;
			}
			// compose message function from message (AST)
			return compileCache[cacheKey] = format(message);
		} else {
			return format(message);
		}
	}
}
let devtools = null;
function setDevToolsHook(hook) {
	devtools = hook;
}
function getDevToolsHook() {
	return devtools;
}
function initI18nDevTools(i18n, version, meta) {
	// TODO: queue if devtools is undefined
	devtools && devtools.emit("i18n:init", {
		timestamp: Date.now(),
		i18n,
		version,
		meta
	});
}
const translateDevTools = /* #__PURE__*/ createDevToolsHook("function:translate");
function createDevToolsHook(hook) {
	return (payloads) => devtools && devtools.emit(hook, payloads);
}
const CoreErrorCodes = {
	INVALID_ARGUMENT: COMPILE_ERROR_CODES_EXTEND_POINT,
	INVALID_DATE_ARGUMENT: 18,
	INVALID_ISO_DATE_ARGUMENT: 19,
	NOT_SUPPORT_NON_STRING_MESSAGE: 20,
	NOT_SUPPORT_LOCALE_PROMISE_VALUE: 21,
	NOT_SUPPORT_LOCALE_ASYNC_FUNCTION: 22,
	NOT_SUPPORT_LOCALE_TYPE: 23
};
const CORE_ERROR_CODES_EXTEND_POINT = 24;
function createCoreError(code) {
	return createCompileError(code, null, "development" !== "production" ? { messages: errorMessages } : undefined);
}
/** @internal */
const errorMessages = {
	[CoreErrorCodes.INVALID_ARGUMENT]: "Invalid arguments",
	[CoreErrorCodes.INVALID_DATE_ARGUMENT]: "The date provided is an invalid Date object." + "Make sure your Date represents a valid date.",
	[CoreErrorCodes.INVALID_ISO_DATE_ARGUMENT]: "The argument provided is not a valid ISO date string",
	[CoreErrorCodes.NOT_SUPPORT_NON_STRING_MESSAGE]: "Not support non-string message",
	[CoreErrorCodes.NOT_SUPPORT_LOCALE_PROMISE_VALUE]: "cannot support promise value",
	[CoreErrorCodes.NOT_SUPPORT_LOCALE_ASYNC_FUNCTION]: "cannot support async function",
	[CoreErrorCodes.NOT_SUPPORT_LOCALE_TYPE]: "cannot support locale type"
};
/** @internal */
function getLocale(context, options) {
	return options.locale != null ? resolveLocale(options.locale) : resolveLocale(context.locale);
}
let _resolveLocale;
/** @internal */
function resolveLocale(locale) {
	if (isString(locale)) {
		return locale;
	} else {
		if (isFunction(locale)) {
			if (locale.resolvedOnce && _resolveLocale != null) {
				return _resolveLocale;
			} else if (locale.constructor.name === "Function") {
				const resolve = locale();
				if (isPromise(resolve)) {
					throw createCoreError(CoreErrorCodes.NOT_SUPPORT_LOCALE_PROMISE_VALUE);
				}
				return _resolveLocale = resolve;
			} else {
				throw createCoreError(CoreErrorCodes.NOT_SUPPORT_LOCALE_ASYNC_FUNCTION);
			}
		} else {
			throw createCoreError(CoreErrorCodes.NOT_SUPPORT_LOCALE_TYPE);
		}
	}
}
/**
* Fallback with simple implemenation
*
* @remarks
* A fallback locale function implemented with a simple fallback algorithm.
*
* Basically, it returns the value as specified in the `fallbackLocale` props, and is processed with the fallback inside intlify.
*
* @param ctx - A {@link CoreContext | context}
* @param fallback - A {@link FallbackLocale | fallback locale}
* @param start - A starting {@link Locale | locale}
*
* @returns Fallback locales
*
* @VueI18nGeneral
*/
function fallbackWithSimple(ctx, fallback, start) {
	// prettier-ignore
	return [...new Set([start, ...isArray(fallback) ? fallback : isObject(fallback) ? Object.keys(fallback) : isString(fallback) ? [fallback] : [start]])];
}
/**
* Fallback with locale chain
*
* @remarks
* A fallback locale function implemented with a fallback chain algorithm. It's used in VueI18n as default.
*
* @param ctx - A {@link CoreContext | context}
* @param fallback - A {@link FallbackLocale | fallback locale}
* @param start - A starting {@link Locale | locale}
*
* @returns Fallback locales
*
* @VueI18nSee [Fallbacking](../guide/essentials/fallback)
*
* @VueI18nGeneral
*/
function fallbackWithLocaleChain(ctx, fallback, start) {
	const startLocale = isString(start) ? start : DEFAULT_LOCALE;
	const context = ctx;
	if (!context.__localeChainCache) {
		context.__localeChainCache = new Map();
	}
	let chain = context.__localeChainCache.get(startLocale);
	if (!chain) {
		chain = [];
		// first block defined by start
		let block = [start];
		// while any intervening block found
		while (isArray(block)) {
			block = appendBlockToChain(chain, block, fallback);
		}
		// prettier-ignore
		// last block defined by default
		const defaults = isArray(fallback) || !isPlainObject(fallback) ? fallback : fallback["default"] ? fallback["default"] : null;
		// convert defaults to array
		block = isString(defaults) ? [defaults] : defaults;
		if (isArray(block)) {
			appendBlockToChain(chain, block, false);
		}
		context.__localeChainCache.set(startLocale, chain);
	}
	return chain;
}
function appendBlockToChain(chain, block, blocks) {
	let follow = true;
	for (let i = 0; i < block.length && isBoolean(follow); i++) {
		const locale = block[i];
		if (isString(locale)) {
			follow = appendLocaleToChain(chain, block[i], blocks);
		}
	}
	return follow;
}
function appendLocaleToChain(chain, locale, blocks) {
	let follow;
	const tokens = locale.split("-");
	do {
		const target = tokens.join("-");
		follow = appendItemToChain(chain, target, blocks);
		tokens.splice(-1, 1);
	} while (tokens.length && follow === true);
	return follow;
}
function appendItemToChain(chain, target, blocks) {
	let follow = false;
	if (!chain.includes(target)) {
		follow = true;
		if (target) {
			follow = target[target.length - 1] !== "!";
			const locale = target.replace(/!/g, "");
			chain.push(locale);
			if ((isArray(blocks) || isPlainObject(blocks)) && blocks[locale]) {
				// eslint-disable-next-line @typescript-eslint/no-explicit-any
				follow = blocks[locale];
			}
		}
	}
	return follow;
}
const pathStateMachine = [];
pathStateMachine[0] = {
	["w"]: [0],
	["i"]: [3, 0],
	["["]: [4],
	["o"]: [7]
};
pathStateMachine[1] = {
	["w"]: [1],
	["."]: [2],
	["["]: [4],
	["o"]: [7]
};
pathStateMachine[2] = {
	["w"]: [2],
	["i"]: [3, 0],
	["0"]: [3, 0]
};
pathStateMachine[3] = {
	["i"]: [3, 0],
	["0"]: [3, 0],
	["w"]: [1, 1],
	["."]: [2, 1],
	["["]: [4, 1],
	["o"]: [7, 1]
};
pathStateMachine[4] = {
	["'"]: [5, 0],
	["\""]: [6, 0],
	["["]: [4, 2],
	["]"]: [1, 3],
	["o"]: 8,
	["l"]: [4, 0]
};
pathStateMachine[5] = {
	["'"]: [4, 0],
	["o"]: 8,
	["l"]: [5, 0]
};
pathStateMachine[6] = {
	["\""]: [4, 0],
	["o"]: 8,
	["l"]: [6, 0]
};
/**
* Check if an expression is a literal value.
*/
const literalValueRE = /^\s?(?:true|false|-?[\d.]+|'[^']*'|"[^"]*")\s?$/;
function isLiteral(exp) {
	return literalValueRE.test(exp);
}
/**
* Strip quotes from a string
*/
function stripQuotes(str) {
	const a = str.charCodeAt(0);
	const b = str.charCodeAt(str.length - 1);
	return a === b && (a === 34 || a === 39) ? str.slice(1, -1) : str;
}
/**
* Determine the type of a character in a keypath.
*/
function getPathCharType(ch) {
	if (ch === undefined || ch === null) {
		return "o";
	}
	const code = ch.charCodeAt(0);
	switch (code) {
		case 91:
		// [
		case 93:
		// ]
		case 46:
		// .
		case 34:
		// "
		case 39: // '
		return ch;
		case 95:
		// _
		case 36:
		// $
		case 45: // -
		return "i";
		case 9:
		// Tab (HT)
		case 10:
		// Newline (LF)
		case 13:
		// Return (CR)
		case 160:
		// No-break space (NBSP)
		case 65279:
		// Byte Order Mark (BOM)
		case 8232:
		// Line Separator (LS)
		case 8233: // Paragraph Separator (PS)
		return "w";
	}
	return "i";
}
/**
* Format a subPath, return its plain form if it is
* a literal string or number. Otherwise prepend the
* dynamic indicator (*).
*/
function formatSubPath(path) {
	const trimmed = path.trim();
	// invalid leading 0
	if (path.charAt(0) === "0" && isNaN(parseInt(path))) {
		return false;
	}
	return isLiteral(trimmed) ? stripQuotes(trimmed) : "*" + trimmed;
}
/**
* Parse a string path into an array of segments
*/
function parse(path) {
	const keys = [];
	let index = -1;
	let mode = 0;
	let subPathDepth = 0;
	let c;
	let key;
	let newChar;
	let type;
	let transition;
	let action;
	let typeMap;
	const actions = [];
	actions[0] = () => {
		if (key === undefined) {
			key = newChar;
		} else {
			key += newChar;
		}
	};
	actions[1] = () => {
		if (key !== undefined) {
			keys.push(key);
			key = undefined;
		}
	};
	actions[2] = () => {
		actions[0]();
		subPathDepth++;
	};
	actions[3] = () => {
		if (subPathDepth > 0) {
			subPathDepth--;
			mode = 4;
			actions[0]();
		} else {
			subPathDepth = 0;
			if (key === undefined) {
				return false;
			}
			key = formatSubPath(key);
			if (key === false) {
				return false;
			} else {
				actions[1]();
			}
		}
	};
	function maybeUnescapeQuote() {
		const nextChar = path[index + 1];
		if (mode === 5 && nextChar === "'" || mode === 6 && nextChar === "\"") {
			index++;
			newChar = "\\" + nextChar;
			actions[0]();
			return true;
		}
	}
	while (mode !== null) {
		index++;
		c = path[index];
		if (c === "\\" && maybeUnescapeQuote()) {
			continue;
		}
		type = getPathCharType(c);
		typeMap = pathStateMachine[mode];
		transition = typeMap[type] || typeMap["l"] || 8;
		// check parse error
		if (transition === 8) {
			return;
		}
		mode = transition[0];
		if (transition[1] !== undefined) {
			action = actions[transition[1]];
			if (action) {
				newChar = c;
				if (action() === false) {
					return;
				}
			}
		}
		// check parse finish
		if (mode === 7) {
			return keys;
		}
	}
}
// path token cache
const cache = new Map();
/**
* key-value message resolver
*
* @remarks
* Resolves messages with the key-value structure. Note that messages with a hierarchical structure such as objects cannot be resolved
*
* @param obj - A target object to be resolved with path
* @param path - A {@link Path | path} to resolve the value of message
*
* @returns A resolved {@link PathValue | path value}
*
* @VueI18nGeneral
*/
function resolveWithKeyValue(obj, path) {
	return isObject(obj) ? obj[path] : null;
}
/**
* message resolver
*
* @remarks
* Resolves messages. messages with a hierarchical structure such as objects can be resolved. This resolver is used in VueI18n as default.
*
* @param obj - A target object to be resolved with path
* @param path - A {@link Path | path} to resolve the value of message
*
* @returns A resolved {@link PathValue | path value}
*
* @VueI18nGeneral
*/
function resolveValue(obj, path) {
	// check object
	if (!isObject(obj)) {
		return null;
	}
	// parse path
	let hit = cache.get(path);
	if (!hit) {
		hit = parse(path);
		if (hit) {
			cache.set(path, hit);
		}
	}
	// check hit
	if (!hit) {
		return null;
	}
	// resolve path value
	const len = hit.length;
	// eslint-disable-next-line @typescript-eslint/no-explicit-any -- for generic object
	let last = obj;
	let i = 0;
	while (i < len) {
		const key = hit[i];
		/**
		* NOTE:
		* if `key` is intlify message format AST node key and `last` is intlify message format AST, skip it.
		* because the AST node is not a key-value structure.
		*/
		if (AST_NODE_PROPS_KEYS.includes(key) && isMessageAST(last)) {
			return null;
		}
		if (!isObject(last)) {
			return null;
		}
		if (!hasOwn(last, key)) {
			return null;
		}
		const val = last[key];
		if (val === undefined) {
			return null;
		}
		if (isFunction(last)) {
			return null;
		}
		last = val;
		i++;
	}
	return last;
}
const CoreWarnCodes = {
	NOT_FOUND_KEY: 1,
	FALLBACK_TO_TRANSLATE: 2,
	CANNOT_FORMAT_NUMBER: 3,
	FALLBACK_TO_NUMBER_FORMAT: 4,
	CANNOT_FORMAT_DATE: 5,
	FALLBACK_TO_DATE_FORMAT: 6,
	EXPERIMENTAL_CUSTOM_MESSAGE_COMPILER: 7,
	INVALID_NUMBER_ARGUMENT: 8,
	INVALID_DATE_ARGUMENT: 9
};
const CORE_WARN_CODES_EXTEND_POINT = 10;
/** @internal */
const warnMessages = {
	[CoreWarnCodes.NOT_FOUND_KEY]: `Not found '{key}' key in '{locale}' locale messages.`,
	[CoreWarnCodes.FALLBACK_TO_TRANSLATE]: `Fall back to translate '{key}' key with '{target}' locale.`,
	[CoreWarnCodes.CANNOT_FORMAT_NUMBER]: `Cannot format a number value due to not supported Intl.NumberFormat.`,
	[CoreWarnCodes.FALLBACK_TO_NUMBER_FORMAT]: `Fall back to number format '{key}' key with '{target}' locale.`,
	[CoreWarnCodes.CANNOT_FORMAT_DATE]: `Cannot format a date value due to not supported Intl.DateTimeFormat.`,
	[CoreWarnCodes.FALLBACK_TO_DATE_FORMAT]: `Fall back to datetime format '{key}' key with '{target}' locale.`,
	[CoreWarnCodes.EXPERIMENTAL_CUSTOM_MESSAGE_COMPILER]: `This project is using Custom Message Compiler, which is an experimental feature. It may receive breaking changes or be removed in the future.`,
	[CoreWarnCodes.INVALID_NUMBER_ARGUMENT]: `Invalid argument for number formatting: expected a number but received '{value}'.`,
	[CoreWarnCodes.INVALID_DATE_ARGUMENT]: `Invalid argument for datetime formatting: expected a Date, number, or ISO string but received '{value}'.`
};
function getWarnMessage(code, ...args) {
	return format$1(warnMessages[code], ...args);
}
/* eslint-disable @typescript-eslint/no-explicit-any */
/**
* Intlify core-base version
* @internal
*/
const VERSION = "11.4.8";
const NOT_REOSLVED = -1;
const DEFAULT_LOCALE = "en-US";
const MISSING_RESOLVE_VALUE = "";
const capitalize = (str) => `${str.charAt(0).toLocaleUpperCase()}${str.substr(1)}`;
function getDefaultLinkedModifiers() {
	return {
		upper: (val, type) => {
			// prettier-ignore
			return type === "text" && isString(val) ? val.toUpperCase() : type === "vnode" && isObject(val) && "__v_isVNode" in val ? val.children.toUpperCase() : val;
		},
		lower: (val, type) => {
			// prettier-ignore
			return type === "text" && isString(val) ? val.toLowerCase() : type === "vnode" && isObject(val) && "__v_isVNode" in val ? val.children.toLowerCase() : val;
		},
		capitalize: (val, type) => {
			// prettier-ignore
			return type === "text" && isString(val) ? capitalize(val) : type === "vnode" && isObject(val) && "__v_isVNode" in val ? capitalize(val.children) : val;
		}
	};
}
let _compiler;
function registerMessageCompiler(compiler) {
	_compiler = compiler;
}
let _resolver;
/**
* Register the message resolver
*
* @param resolver - A {@link MessageResolver} function
*
* @VueI18nGeneral
*/
function registerMessageResolver(resolver) {
	_resolver = resolver;
}
let _fallbacker;
/**
* Register the locale fallbacker
*
* @param fallbacker - A {@link LocaleFallbacker} function
*
* @VueI18nGeneral
*/
function registerLocaleFallbacker(fallbacker) {
	_fallbacker = fallbacker;
}
// Additional Meta for Intlify DevTools
let _additionalMeta = null;
const setAdditionalMeta = /* @__NO_SIDE_EFFECTS__ */ (meta) => {
	_additionalMeta = meta;
};
const getAdditionalMeta = /* @__NO_SIDE_EFFECTS__ */ () => _additionalMeta;
let _fallbackContext = null;
const setFallbackContext = (context) => {
	_fallbackContext = context;
};
const getFallbackContext = () => _fallbackContext;
// ID for CoreContext
let _cid = 0;
function createCoreContext(options = {}) {
	// setup options
	const onWarn = isFunction(options.onWarn) ? options.onWarn : warn;
	const version = isString(options.version) ? options.version : VERSION;
	const locale = isString(options.locale) || isFunction(options.locale) ? options.locale : DEFAULT_LOCALE;
	const _locale = isFunction(locale) ? DEFAULT_LOCALE : locale;
	const fallbackLocale = isArray(options.fallbackLocale) || isPlainObject(options.fallbackLocale) || isString(options.fallbackLocale) || options.fallbackLocale === false ? options.fallbackLocale : _locale;
	const messages = isPlainObject(options.messages) ? options.messages : createResources(_locale);
	const datetimeFormats = isPlainObject(options.datetimeFormats) ? options.datetimeFormats : createResources(_locale);
	const numberFormats = isPlainObject(options.numberFormats) ? options.numberFormats : createResources(_locale);
	const modifiers = assign(create(), options.modifiers, getDefaultLinkedModifiers());
	const pluralRules = options.pluralRules || create();
	const missing = isFunction(options.missing) ? options.missing : null;
	const missingWarn = isBoolean(options.missingWarn) || isRegExp(options.missingWarn) ? options.missingWarn : true;
	const fallbackWarn = isBoolean(options.fallbackWarn) || isRegExp(options.fallbackWarn) ? options.fallbackWarn : true;
	const fallbackFormat = !!options.fallbackFormat;
	const unresolving = !!options.unresolving;
	const postTranslation = isFunction(options.postTranslation) ? options.postTranslation : null;
	const processor = isPlainObject(options.processor) ? options.processor : null;
	const warnHtmlMessage = isBoolean(options.warnHtmlMessage) ? options.warnHtmlMessage : true;
	const escapeParameter = !!options.escapeParameter;
	const messageCompiler = isFunction(options.messageCompiler) ? options.messageCompiler : _compiler;
	if ("development" !== "production" && true && true && isFunction(options.messageCompiler)) {
		warnOnce(getWarnMessage(CoreWarnCodes.EXPERIMENTAL_CUSTOM_MESSAGE_COMPILER));
	}
	const messageResolver = isFunction(options.messageResolver) ? options.messageResolver : _resolver || resolveWithKeyValue;
	const localeFallbacker = isFunction(options.localeFallbacker) ? options.localeFallbacker : _fallbacker || fallbackWithSimple;
	const fallbackContext = isObject(options.fallbackContext) ? options.fallbackContext : undefined;
	// setup internal options
	const internalOptions = options;
	const __datetimeFormatters = isObject(internalOptions.__datetimeFormatters) ? internalOptions.__datetimeFormatters : new Map();
	const __numberFormatters = isObject(internalOptions.__numberFormatters) ? internalOptions.__numberFormatters : new Map();
	const __meta = isObject(internalOptions.__meta) ? internalOptions.__meta : {};
	_cid++;
	const context = {
		version,
		cid: _cid,
		locale,
		fallbackLocale,
		messages,
		modifiers,
		pluralRules,
		missing,
		missingWarn,
		fallbackWarn,
		fallbackFormat,
		unresolving,
		postTranslation,
		processor,
		warnHtmlMessage,
		escapeParameter,
		messageCompiler,
		messageResolver,
		localeFallbacker,
		fallbackContext,
		onWarn,
		__meta
	};
	{
		context.datetimeFormats = datetimeFormats;
		context.numberFormats = numberFormats;
		context.__datetimeFormatters = __datetimeFormatters;
		context.__numberFormatters = __numberFormatters;
	}
	// for vue-devtools timeline event
	if ("development" !== "production") {
		context.__v_emitter = internalOptions.__v_emitter != null ? internalOptions.__v_emitter : undefined;
	}
	// NOTE: experimental !!
	if ("development" !== "production" || __INTLIFY_PROD_DEVTOOLS__) {
		initI18nDevTools(context, version, __meta);
	}
	return context;
}
const createResources = (locale) => ({ [locale]: create() });
/** @internal */
function isTranslateFallbackWarn(fallback, key) {
	return fallback instanceof RegExp ? fallback.test(key) : fallback;
}
/** @internal */
function isTranslateMissingWarn(missing, key) {
	return missing instanceof RegExp ? missing.test(key) : missing;
}
/** @internal */
function handleMissing(context, key, locale, missingWarn, type) {
	const { missing, onWarn } = context;
	// for vue-devtools timeline event
	if ("development" !== "production") {
		const emitter = context.__v_emitter;
		if (emitter) {
			emitter.emit("missing", {
				locale,
				key,
				type,
				groupId: `${type}:${key}`
			});
		}
	}
	if (missing !== null) {
		const ret = missing(context, locale, key, type);
		return isString(ret) ? ret : key;
	} else {
		if ("development" !== "production" && isTranslateMissingWarn(missingWarn, key)) {
			onWarn(getWarnMessage(CoreWarnCodes.NOT_FOUND_KEY, {
				key,
				locale
			}));
		}
		return key;
	}
}
/** @internal */
function updateFallbackLocale(ctx, locale, fallback) {
	const context = ctx;
	context.__localeChainCache = new Map();
	ctx.localeFallbacker(ctx, fallback, locale);
}
/** @internal */
function isAlmostSameLocale(locale, compareLocale) {
	if (locale === compareLocale) return false;
	return locale.split("-")[0] === compareLocale.split("-")[0];
}
/** @internal */
function isImplicitFallback(targetLocale, locales) {
	const index = locales.indexOf(targetLocale);
	if (index === -1) {
		return false;
	}
	for (let i = index + 1; i < locales.length; i++) {
		if (isAlmostSameLocale(targetLocale, locales[i])) {
			return true;
		}
	}
	return false;
}
/* eslint-enable @typescript-eslint/no-explicit-any */
function resolveFormatLocale(context, key, locale, formats, missingWarn, fallbackWarn, type) {
	const { fallbackLocale, localeFallbacker, onWarn } = context;
	const locales = localeFallbacker(context, fallbackLocale, locale);
	let from = locale;
	for (let i = 0; i < locales.length; i++) {
		const targetLocale = locales[i];
		if ("development" !== "production" && locale !== targetLocale && isTranslateFallbackWarn(fallbackWarn, key)) {
			onWarn(getWarnMessage(type === "datetime format" ? CoreWarnCodes.FALLBACK_TO_DATE_FORMAT : CoreWarnCodes.FALLBACK_TO_NUMBER_FORMAT, {
				key,
				target: targetLocale
			}));
		}
		if ("development" !== "production" && locale !== targetLocale) {
			const emitter = context.__v_emitter;
			if (emitter) {
				emitter.emit("fallback", {
					type,
					key,
					from,
					to: targetLocale,
					groupId: `${type}:${key}`
				});
			}
		}
		const format = (formats[targetLocale] || {})[key];
		if (isPlainObject(format) && isString(targetLocale)) {
			return targetLocale;
		}
		handleMissing(context, key, targetLocale, missingWarn, type);
		from = targetLocale;
	}
	return null;
}
function getFormatterCacheKey(locale, key, overrides) {
	let id = `${locale}__${key}`;
	if (isPlainObject(overrides) && !isEmptyObject(overrides)) {
		id = `${id}__${JSON.stringify(overrides)}`;
	}
	return id;
}
function clearFormatCache(formatters, locale, format) {
	for (const key in format) {
		const prefix = `${locale}__${key}`;
		for (const id of formatters.keys()) {
			if (id === prefix || id.startsWith(`${prefix}__`)) {
				formatters.delete(id);
			}
		}
	}
}
function parseFormatArgs(args, options, initialOverrides, optionsKeys) {
	const [, arg2, arg3, arg4] = args;
	let overrides = initialOverrides;
	if (isString(arg2)) {
		options.key = arg2;
	} else if (isPlainObject(arg2)) {
		Object.keys(arg2).forEach((key) => {
			if (optionsKeys.includes(key)) {
				overrides[key] = arg2[key];
			} else {
				options[key] = arg2[key];
			}
		});
	}
	if (isString(arg3)) {
		options.locale = arg3;
	} else if (isPlainObject(arg3)) {
		overrides = arg3;
	}
	if (isPlainObject(arg4)) {
		overrides = arg4;
	}
	return overrides;
}
const intlDefined = typeof Intl !== "undefined";
const Availabilities = {
	dateTimeFormat: intlDefined && typeof Intl.DateTimeFormat !== "undefined",
	numberFormat: intlDefined && typeof Intl.NumberFormat !== "undefined"
};
// implementation of `datetime` function
function datetime(context, ...args) {
	const { datetimeFormats, unresolving, onWarn } = context;
	const { __datetimeFormatters } = context;
	if ("development" !== "production" && !Availabilities.dateTimeFormat) {
		onWarn(getWarnMessage(CoreWarnCodes.CANNOT_FORMAT_DATE));
		return MISSING_RESOLVE_VALUE;
	}
	if (!isString(args[0]) && !isDate(args[0]) && !isNumber(args[0])) {
		if ("development" !== "production") {
			onWarn(getWarnMessage(CoreWarnCodes.INVALID_DATE_ARGUMENT, { value: String(args[0]) }));
		}
		return MISSING_RESOLVE_VALUE;
	}
	const [key, value, options, overrides] = parseDateTimeArgs(...args);
	const missingWarn = isBoolean(options.missingWarn) ? options.missingWarn : context.missingWarn;
	const fallbackWarn = isBoolean(options.fallbackWarn) ? options.fallbackWarn : context.fallbackWarn;
	const part = !!options.part;
	const locale = getLocale(context, options);
	if (!isString(key) || key === "") {
		const formatter = new Intl.DateTimeFormat(locale.replace(/!/g, ""), overrides);
		return !part ? formatter.format(value) : formatter.formatToParts(value);
	}
	const targetLocale = resolveFormatLocale(context, key, locale, datetimeFormats, missingWarn, fallbackWarn, "datetime format");
	if (!isString(targetLocale)) {
		return unresolving ? NOT_REOSLVED : key;
	}
	const format = datetimeFormats[targetLocale][key];
	const id = getFormatterCacheKey(targetLocale, key, overrides);
	let formatter = __datetimeFormatters.get(id);
	if (!formatter) {
		formatter = new Intl.DateTimeFormat(targetLocale, assign({}, format, overrides));
		__datetimeFormatters.set(id, formatter);
	}
	return !part ? formatter.format(value) : formatter.formatToParts(value);
}
/** @internal */
const DATETIME_FORMAT_OPTIONS_KEYS = [
	"localeMatcher",
	"weekday",
	"era",
	"year",
	"month",
	"day",
	"hour",
	"minute",
	"second",
	"timeZoneName",
	"formatMatcher",
	"hour12",
	"timeZone",
	"dateStyle",
	"timeStyle",
	"calendar",
	"dayPeriod",
	"numberingSystem",
	"hourCycle",
	"fractionalSecondDigits"
];
/** @internal */
function parseDateTimeArgs(...args) {
	const [arg1] = args;
	const options = create();
	const initialOverrides = create();
	let value;
	if (isString(arg1)) {
		// Only allow ISO strings - other date formats are often supported,
		// but may cause different results in different browsers.
		const matches = arg1.match(/(\d{4}-\d{2}-\d{2})(T|\s)?(.*)/);
		if (!matches) {
			throw createCoreError(CoreErrorCodes.INVALID_ISO_DATE_ARGUMENT);
		}
		// Some browsers can not parse the iso datetime separated by space,
		// this is a compromise solution by replace the 'T'/' ' with 'T'
		const dateTime = matches[3] ? matches[3].trim().startsWith("T") ? `${matches[1].trim()}${matches[3].trim()}` : `${matches[1].trim()}T${matches[3].trim()}` : matches[1].trim();
		value = new Date(dateTime);
		try {
			// This will fail if the date is not valid
			value.toISOString();
		} catch {
			throw createCoreError(CoreErrorCodes.INVALID_ISO_DATE_ARGUMENT);
		}
	} else if (isDate(arg1)) {
		if (isNaN(arg1.getTime())) {
			throw createCoreError(CoreErrorCodes.INVALID_DATE_ARGUMENT);
		}
		value = arg1;
	} else if (isNumber(arg1)) {
		value = arg1;
	} else {
		throw createCoreError(CoreErrorCodes.INVALID_ARGUMENT);
	}
	const overrides = parseFormatArgs(args, options, initialOverrides, DATETIME_FORMAT_OPTIONS_KEYS);
	return [
		options.key || "",
		value,
		options,
		overrides
	];
}
/** @internal */
function clearDateTimeFormat(ctx, locale, format) {
	const context = ctx;
	clearFormatCache(context.__datetimeFormatters, locale, format);
}
// implementation of `number` function
function number(context, ...args) {
	const { numberFormats, unresolving, onWarn } = context;
	const { __numberFormatters } = context;
	if ("development" !== "production" && !Availabilities.numberFormat) {
		onWarn(getWarnMessage(CoreWarnCodes.CANNOT_FORMAT_NUMBER));
		return MISSING_RESOLVE_VALUE;
	}
	if (!isNumber(args[0])) {
		if ("development" !== "production") {
			onWarn(getWarnMessage(CoreWarnCodes.INVALID_NUMBER_ARGUMENT, { value: String(args[0]) }));
		}
		return MISSING_RESOLVE_VALUE;
	}
	const [key, value, options, overrides] = parseNumberArgs(...args);
	const missingWarn = isBoolean(options.missingWarn) ? options.missingWarn : context.missingWarn;
	const fallbackWarn = isBoolean(options.fallbackWarn) ? options.fallbackWarn : context.fallbackWarn;
	const part = !!options.part;
	const locale = getLocale(context, options);
	if (!isString(key) || key === "") {
		const formatter = new Intl.NumberFormat(locale.replace(/!/g, ""), overrides);
		return !part ? formatter.format(value) : formatter.formatToParts(value);
	}
	const targetLocale = resolveFormatLocale(context, key, locale, numberFormats, missingWarn, fallbackWarn, "number format");
	if (!isString(targetLocale)) {
		return unresolving ? NOT_REOSLVED : key;
	}
	const format = numberFormats[targetLocale][key];
	const id = getFormatterCacheKey(targetLocale, key, overrides);
	let formatter = __numberFormatters.get(id);
	if (!formatter) {
		formatter = new Intl.NumberFormat(targetLocale, assign({}, format, overrides));
		__numberFormatters.set(id, formatter);
	}
	return !part ? formatter.format(value) : formatter.formatToParts(value);
}
/** @internal */
const NUMBER_FORMAT_OPTIONS_KEYS = [
	"localeMatcher",
	"style",
	"currency",
	"currencyDisplay",
	"currencySign",
	"useGrouping",
	"minimumIntegerDigits",
	"minimumFractionDigits",
	"maximumFractionDigits",
	"minimumSignificantDigits",
	"maximumSignificantDigits",
	"compactDisplay",
	"notation",
	"signDisplay",
	"unit",
	"unitDisplay",
	"roundingMode",
	"roundingPriority",
	"roundingIncrement",
	"trailingZeroDisplay"
];
/** @internal */
function parseNumberArgs(...args) {
	const [arg1] = args;
	const options = create();
	const initialOverrides = create();
	if (!isNumber(arg1)) {
		throw createCoreError(CoreErrorCodes.INVALID_ARGUMENT);
	}
	const value = arg1;
	const overrides = parseFormatArgs(args, options, initialOverrides, NUMBER_FORMAT_OPTIONS_KEYS);
	return [
		options.key || "",
		value,
		options,
		overrides
	];
}
/** @internal */
function clearNumberFormat(ctx, locale, format) {
	const context = ctx;
	clearFormatCache(context.__numberFormatters, locale, format);
}
const DEFAULT_MODIFIER = (str) => str;
const DEFAULT_MESSAGE = (ctx) => "";
const DEFAULT_MESSAGE_DATA_TYPE = "text";
const DEFAULT_NORMALIZE = (values) => values.length === 0 ? "" : join(values);
const DEFAULT_INTERPOLATE = toDisplayString;
function pluralDefault(choice, choicesLength) {
	choice = Math.abs(choice);
	// singular (0) | plural (1)
	if (choicesLength === 2) {
		// prettier-ignore
		return choice === 1 ? 0 : 1;
	}
	// zero (0) | singular (1) | plural (2)
	return Math.min(choice, 2);
}
function getPluralIndex(options) {
	// prettier-ignore
	const index = isNumber(options.pluralIndex) ? options.pluralIndex : -1;
	return isNumber(options.named?.count) ? options.named.count : isNumber(options.named?.n) ? options.named.n : index;
}
function createMessageContext(options = {}) {
	const locale = options.locale;
	const pluralIndex = getPluralIndex(options);
	const pluralRule = isString(locale) && isFunction(options.pluralRules?.[locale]) ? options.pluralRules[locale] : pluralDefault;
	const orgPluralRule = pluralRule === pluralDefault ? undefined : pluralDefault;
	const plural = (messages) => messages[pluralRule(pluralIndex, messages.length, orgPluralRule)];
	const _list = options.list || [];
	const list = (index) => _list[index];
	const _named = options.named || create();
	// normalize named
	if (isNumber(options.pluralIndex)) {
		_named.count ||= options.pluralIndex;
		_named.n ||= options.pluralIndex;
	}
	const named = (key) => _named[key];
	function message(key, useLinked) {
		// prettier-ignore
		const msg = isFunction(options.messages) ? options.messages(key, !!useLinked) : isObject(options.messages) ? options.messages[key] : false;
		return !msg ? options.parent ? options.parent.message(key) : DEFAULT_MESSAGE : msg;
	}
	const _modifier = (name) => options.modifiers ? options.modifiers[name] : DEFAULT_MODIFIER;
	const normalize = isFunction(options.processor?.normalize) ? options.processor.normalize : DEFAULT_NORMALIZE;
	const interpolate = isFunction(options.processor?.interpolate) ? options.processor.interpolate : DEFAULT_INTERPOLATE;
	const type = isString(options.processor?.type) ? options.processor.type : DEFAULT_MESSAGE_DATA_TYPE;
	const linked = (key, ...args) => {
		const [arg1, arg2] = args;
		let type = "text";
		let modifier = "";
		if (args.length === 1) {
			if (isObject(arg1)) {
				modifier = arg1.modifier || modifier;
				type = arg1.type || type;
			} else if (isString(arg1)) {
				modifier = arg1 || modifier;
			}
		} else if (args.length === 2) {
			if (isString(arg1)) {
				modifier = arg1 || modifier;
			}
			if (isString(arg2)) {
				type = arg2 || type;
			}
		}
		const ret = message(key, true)(ctx);
		// If the linked message is not resolved (empty string), fall back to the key itself
		const resolved = ret === "" || ret === undefined ? key : ret;
		const msg = type === "vnode" && isArray(resolved) && modifier ? resolved[0] : resolved;
		return modifier ? _modifier(modifier)(msg, type) : msg;
	};
	const ctx = {
		["list"]: list,
		["named"]: named,
		["plural"]: plural,
		["linked"]: linked,
		["message"]: message,
		["type"]: type,
		["interpolate"]: interpolate,
		["normalize"]: normalize,
		["values"]: assign(create(), _list, _named)
	};
	return ctx;
}
const NOOP_MESSAGE_FUNCTION = () => "";
const isMessageFunction = (val) => isFunction(val);
// implementation of `translate` function
function translate(context, ...args) {
	const { fallbackFormat, postTranslation, unresolving, messageCompiler, fallbackLocale, messages } = context;
	const [key, options] = parseTranslateArgs(...args);
	const missingWarn = isBoolean(options.missingWarn) ? options.missingWarn : context.missingWarn;
	const fallbackWarn = isBoolean(options.fallbackWarn) ? options.fallbackWarn : context.fallbackWarn;
	const escapeParameter = isBoolean(options.escapeParameter) ? options.escapeParameter : context.escapeParameter;
	const resolvedMessage = !!options.resolvedMessage;
	// prettier-ignore
	const defaultMsgOrKey = isString(options.default) || isBoolean(options.default) ? !isBoolean(options.default) ? options.default : !messageCompiler ? () => key : key : fallbackFormat ? !messageCompiler ? () => key : key : null;
	const enableDefaultMsg = fallbackFormat || defaultMsgOrKey != null && (isString(defaultMsgOrKey) || isFunction(defaultMsgOrKey));
	const locale = getLocale(context, options);
	// escape params
	escapeParameter && escapeParams(options);
	// resolve message format
	// eslint-disable-next-line prefer-const
	let [formatScope, targetLocale, message] = !resolvedMessage ? resolveMessageFormat(context, key, locale, fallbackLocale, fallbackWarn, missingWarn) : [
		key,
		locale,
		messages[locale] || create()
	];
	// NOTE:
	//  Fix to work around `ssrTransfrom` bug in Vite.
	//  https://github.com/vitejs/vite/issues/4306
	//  To get around this, use temporary variables.
	//  https://github.com/nuxt/framework/issues/1461#issuecomment-954606243
	let format = formatScope;
	// if you use default message, set it as message format!
	let cacheBaseKey = key;
	if (!resolvedMessage && !(isString(format) || isMessageAST(format) || isMessageFunction(format))) {
		if (enableDefaultMsg) {
			format = defaultMsgOrKey;
			cacheBaseKey = format;
		}
	}
	// checking message format and target locale
	if (!resolvedMessage && (!(isString(format) || isMessageAST(format) || isMessageFunction(format)) || !isString(targetLocale))) {
		return unresolving ? NOT_REOSLVED : key;
	}
	// TODO: refactor
	if ("development" !== "production" && isString(format) && context.messageCompiler == null) {
		warn(`The message format compilation is not supported in this build. ` + `Because message compiler isn't included. ` + `You need to pre-compilation all message format. ` + `So translate function return '${key}'.`);
		return key;
	}
	// setup compile error detecting
	let occurred = false;
	const onError = () => {
		occurred = true;
	};
	// compile message format
	const msg = !isMessageFunction(format) ? compileMessageFormat(context, key, targetLocale, format, cacheBaseKey, onError) : format;
	// if occurred compile error, return the message format
	if (occurred) {
		return format;
	}
	// evaluate message with context
	const ctxOptions = getMessageContextOptions(context, targetLocale, message, options);
	const msgContext = createMessageContext(ctxOptions);
	const messaged = evaluateMessage(context, msg, msgContext);
	// if use post translation option, proceed it with handler
	let ret = postTranslation ? postTranslation(messaged, key) : messaged;
	// apply HTML sanitization for security
	if (escapeParameter && isString(ret)) {
		ret = sanitizeTranslatedHtml(ret);
	}
	// NOTE: experimental !!
	if ("development" !== "production" || __INTLIFY_PROD_DEVTOOLS__) {
		// prettier-ignore
		const payloads = {
			timestamp: Date.now(),
			key: isString(key) ? key : isMessageFunction(format) ? format.key : "",
			locale: targetLocale || (isMessageFunction(format) ? format.locale : ""),
			format: isString(format) ? format : isMessageFunction(format) ? format.source : "",
			message: ret
		};
		payloads.meta = assign({}, context.__meta, getAdditionalMeta() || {});
		translateDevTools(payloads);
	}
	return ret;
}
function escapeParams(options) {
	if (isArray(options.list)) {
		options.list = options.list.map((item) => isString(item) ? escapeHtml(item) : item);
	} else if (isObject(options.named)) {
		Object.keys(options.named).forEach((key) => {
			if (isString(options.named[key])) {
				options.named[key] = escapeHtml(options.named[key]);
			}
		});
	}
}
function resolveMessageFormat(context, key, locale, fallbackLocale, fallbackWarn, missingWarn) {
	const { messages, onWarn, messageResolver: resolveValue, localeFallbacker } = context;
	const locales = localeFallbacker(context, fallbackLocale, locale);
	let message = create();
	let targetLocale;
	let format = null;
	let from = locale;
	let to = null;
	const type = "translate";
	for (let i = 0; i < locales.length; i++) {
		targetLocale = to = locales[i];
		if ("development" !== "production" && locale !== targetLocale && !isAlmostSameLocale(locale, targetLocale) && isTranslateFallbackWarn(fallbackWarn, key)) {
			onWarn(getWarnMessage(CoreWarnCodes.FALLBACK_TO_TRANSLATE, {
				key,
				target: targetLocale
			}));
		}
		const emitter = "development" !== "production" ? context.__v_emitter : undefined;
		// for vue-devtools timeline event
		if ("development" !== "production" && locale !== targetLocale) {
			if (emitter) {
				emitter.emit("fallback", {
					type,
					key,
					from,
					to,
					groupId: `${type}:${key}`
				});
			}
		}
		message = messages[targetLocale] || create();
		// for vue-devtools timeline event
		let start = null;
		let startTag;
		let endTag;
		if ("development" !== "production" && inBrowser && emitter) {
			start = window.performance.now();
			startTag = "intlify-message-resolve-start";
			endTag = "intlify-message-resolve-end";
			mark && mark(startTag);
		}
		if ((format = resolveValue(message, key)) === null) {
			// if null, resolve with object key path
			format = message[key];
		}
		// for vue-devtools timeline event
		if ("development" !== "production" && inBrowser && emitter) {
			const end = window.performance.now();
			if (emitter && start && format) {
				emitter.emit("message-resolve", {
					type: "message-resolve",
					key,
					message: format,
					time: end - start,
					groupId: `${type}:${key}`
				});
			}
			if (startTag && endTag && mark && measure) {
				mark(endTag);
				measure("intlify message resolve", startTag, endTag);
			}
		}
		if (isString(format) || isMessageAST(format) || isMessageFunction(format)) {
			break;
		}
		if (!isImplicitFallback(targetLocale, locales)) {
			const missingRet = handleMissing(context, key, targetLocale, missingWarn, type);
			if (missingRet !== key) {
				format = missingRet;
			}
		}
		from = to;
	}
	return [
		format,
		targetLocale,
		message
	];
}
function compileMessageFormat(context, key, targetLocale, format, cacheBaseKey, onError) {
	const { messageCompiler, warnHtmlMessage } = context;
	if (isMessageFunction(format)) {
		const msg = format;
		msg.locale = msg.locale || targetLocale;
		msg.key = msg.key || key;
		return msg;
	}
	if (messageCompiler == null) {
		const msg = (() => format);
		msg.locale = targetLocale;
		msg.key = key;
		return msg;
	}
	// for vue-devtools timeline event
	const emitter = "development" !== "production" ? context.__v_emitter : undefined;
	let start = null;
	let startTag;
	let endTag;
	if ("development" !== "production" && inBrowser && emitter) {
		start = window.performance.now();
		startTag = "intlify-message-compilation-start";
		endTag = "intlify-message-compilation-end";
		mark && mark(startTag);
	}
	const msg = messageCompiler(format, getCompileContext(context, targetLocale, cacheBaseKey, format, warnHtmlMessage, onError));
	// for vue-devtools timeline event
	if ("development" !== "production" && inBrowser && emitter) {
		const end = window.performance.now();
		if (emitter && start) {
			emitter.emit("message-compilation", {
				type: "message-compilation",
				message: format,
				time: end - start,
				groupId: `${"translate"}:${key}`
			});
		}
		if (startTag && endTag && mark && measure) {
			mark(endTag);
			measure("intlify message compilation", startTag, endTag);
		}
	}
	msg.locale = targetLocale;
	msg.key = key;
	msg.source = format;
	return msg;
}
function evaluateMessage(context, msg, msgCtx) {
	// for vue-devtools timeline event
	const emitter = "development" !== "production" ? context.__v_emitter : undefined;
	let start = null;
	let startTag;
	let endTag;
	if ("development" !== "production" && inBrowser && emitter) {
		start = window.performance.now();
		startTag = "intlify-message-evaluation-start";
		endTag = "intlify-message-evaluation-end";
		mark && mark(startTag);
	}
	const messaged = msg(msgCtx);
	// for vue-devtools timeline event
	if ("development" !== "production" && inBrowser && emitter) {
		const end = window.performance.now();
		if (emitter && start) {
			emitter.emit("message-evaluation", {
				type: "message-evaluation",
				value: messaged,
				time: end - start,
				groupId: `${"translate"}:${msg.key}`
			});
		}
		if (startTag && endTag && mark && measure) {
			mark(endTag);
			measure("intlify message evaluation", startTag, endTag);
		}
	}
	return messaged;
}
/** @internal */
function parseTranslateArgs(...args) {
	const [arg1, arg2, arg3] = args;
	const options = create();
	if (!isString(arg1) && !isNumber(arg1) && !isMessageFunction(arg1) && !isMessageAST(arg1)) {
		throw createCoreError(CoreErrorCodes.INVALID_ARGUMENT);
	}
	// prettier-ignore
	const key = isNumber(arg1) ? String(arg1) : isMessageFunction(arg1) ? arg1 : arg1;
	if (isNumber(arg2)) {
		options.plural = arg2;
	} else if (isString(arg2)) {
		options.default = arg2;
	} else if (isPlainObject(arg2) && !isEmptyObject(arg2)) {
		options.named = arg2;
	} else if (isArray(arg2)) {
		options.list = arg2;
	}
	if (isNumber(arg3)) {
		options.plural = arg3;
	} else if (isString(arg3)) {
		options.default = arg3;
	} else if (isPlainObject(arg3)) {
		assign(options, arg3);
	}
	return [key, options];
}
function getCompileContext(context, locale, key, source, warnHtmlMessage, onError) {
	return {
		locale,
		key,
		warnHtmlMessage,
		onError: (err) => {
			onError && onError(err);
			if ("development" !== "production") {
				const _source = getSourceForCodeFrame(source);
				const codeFrame = err.location && _source && generateCodeFrame(_source, err.location.start.offset, err.location.end.offset);
				const emitter = context.__v_emitter;
				if (emitter && _source) {
					emitter.emit("compile-error", {
						message: _source,
						error: err.message,
						start: err.location && err.location.start.offset,
						end: err.location && err.location.end.offset,
						groupId: `${"translate"}:${key}`
					});
				}
				const message = `Message compilation error: ${err.message}`;
				throw new SyntaxError(codeFrame ? `${message}\n${codeFrame}` : message);
			}
			throw err;
		},
		onCacheKey: (source) => generateFormatCacheKey(locale, key, source)
	};
}
function getSourceForCodeFrame(source) {
	if (isString(source)) {
		return source;
	} else {
		if (source.loc && source.loc.source) {
			return source.loc.source;
		}
	}
}
function getMessageContextOptions(context, locale, message, options) {
	const { modifiers, pluralRules, messageResolver: resolveValue, fallbackLocale, fallbackWarn, missingWarn, fallbackContext } = context;
	const resolveMessage = (key, useLinked) => {
		let val = resolveValue(message, key);
		// fallback
		if (val == null && (fallbackContext || useLinked)) {
			const [format, , message] = resolveMessageFormat(fallbackContext || context, key, locale, fallbackLocale, fallbackWarn, missingWarn);
			val = format ?? resolveValue(message, key);
		}
		if (isString(val) || isMessageAST(val)) {
			let occurred = false;
			const onError = () => {
				occurred = true;
			};
			const msg = compileMessageFormat(context, key, locale, val, key, onError);
			return !occurred ? msg : NOOP_MESSAGE_FUNCTION;
		} else if (isMessageFunction(val)) {
			return val;
		} else {
			// TODO: should be implemented warning message
			return NOOP_MESSAGE_FUNCTION;
		}
	};
	const ctxOptions = {
		locale,
		modifiers,
		pluralRules,
		messages: resolveMessage
	};
	if (context.processor) {
		ctxOptions.processor = context.processor;
	}
	if (options.list) {
		ctxOptions.list = options.list;
	}
	if (options.named) {
		ctxOptions.named = options.named;
	}
	if (isNumber(options.plural)) {
		ctxOptions.pluralIndex = options.plural;
	}
	return ctxOptions;
}
{
	initFeatureFlags();
}
export { AST_NODE_PROPS_KEYS, CORE_ERROR_CODES_EXTEND_POINT, CORE_WARN_CODES_EXTEND_POINT, CoreErrorCodes, CoreWarnCodes, DATETIME_FORMAT_OPTIONS_KEYS, DEFAULT_LOCALE, DEFAULT_MESSAGE_DATA_TYPE, MISSING_RESOLVE_VALUE, NOT_REOSLVED, NUMBER_FORMAT_OPTIONS_KEYS, VERSION, clearCompileCache, clearDateTimeFormat, clearNumberFormat, compile, createCoreContext, createCoreError, createMessageContext, datetime, fallbackWithLocaleChain, fallbackWithSimple, getAdditionalMeta, getDevToolsHook, getFallbackContext, getLocale, getWarnMessage, handleMissing, initI18nDevTools, isAlmostSameLocale, isImplicitFallback, isMessageAST, isMessageFunction, isTranslateFallbackWarn, isTranslateMissingWarn, number, parse, parseDateTimeArgs, parseNumberArgs, parseTranslateArgs, registerLocaleFallbacker, registerMessageCompiler, registerMessageResolver, resolveLocale, resolveValue, resolveWithKeyValue, setAdditionalMeta, setDevToolsHook, setFallbackContext, translate, translateDevTools, updateFallbackLocale };

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFLQSxTQUFTLGVBQWUsVUFBVSxRQUFRLFVBQVUsUUFBUSxVQUFVLFdBQVcsTUFBTSxVQUFVLFVBQVUsU0FBUyxlQUFlLFlBQVksV0FBVyxRQUFRLFVBQVUsVUFBVSxlQUFlLFFBQVEsaUJBQWlCLE1BQU0sd0JBQXdCLFlBQVksV0FBVyxNQUFNLFNBQVMsd0JBQXdCLHlCQUF5QjtBQUNuVixTQUFTLGVBQWUsZ0JBQWdCLGVBQWUsZUFBZSxrQ0FBa0MsMEJBQTBCO0FBQ2xJLFNBQVMsbUJBQW1CLDBCQUEwQjs7Ozs7QUFNdEQsU0FBUyxtQkFBbUI7Q0FDeEIsSUFBSSxPQUFPLDhCQUE4QixXQUFXO0VBQ2hELGNBQWMsQ0FBQyxDQUFDLDRCQUE0QjtDQUNoRDtDQUNBLElBQUksT0FBTyxzQ0FBc0MsV0FBVztFQUN4RCxjQUFjLENBQUMsQ0FBQyxvQ0FBb0M7Q0FDeEQ7QUFDSjtBQUVBLFNBQVMsYUFBYSxLQUFLO0NBQ3ZCLE9BQVEsU0FBUyxHQUFHLEtBQ2hCLFlBQVksR0FBRyxNQUFNLE1BQ3BCLE9BQU8sS0FBSyxHQUFHLEtBQUssT0FBTyxLQUFLLE1BQU07QUFDL0M7QUFDQSxNQUFNLGFBQWEsQ0FBQyxLQUFLLE1BQU07QUFDL0IsU0FBUyxZQUFZLE1BQU07Q0FDdkIsT0FBTyxhQUFhLE1BQU0sVUFBVTtBQUN4QztBQUNBLE1BQU0sY0FBYyxDQUFDLEtBQUssT0FBTztBQUNqQyxTQUFTLGFBQWEsTUFBTTtDQUN4QixPQUFPLGFBQWEsTUFBTSxhQUFhLENBQUMsQ0FBQztBQUM3QztBQUNBLE1BQU0sZUFBZSxDQUFDLEtBQUssUUFBUTtBQUNuQyxTQUFTLGNBQWMsTUFBTTtDQUN6QixPQUFPLGFBQWEsTUFBTSxZQUFZO0FBQzFDO0FBQ0EsTUFBTSxjQUFjLENBQUMsS0FBSyxPQUFPO0FBQ2pDLFNBQVMsYUFBYSxNQUFNO0NBQ3hCLE9BQU8sYUFBYSxNQUFNLGFBQWEsQ0FBQyxDQUFDO0FBQzdDO0FBQ0EsTUFBTSxhQUFhLENBQUMsS0FBSyxNQUFNO0FBQy9CLFNBQVMsWUFBWSxNQUFNO0NBQ3ZCLE9BQU8sYUFBYSxNQUFNLFVBQVU7QUFDeEM7QUFDQSxNQUFNLGNBQWMsQ0FBQyxLQUFLLE9BQU87QUFDakMsU0FBUyxlQUFlLE1BQU0sTUFBTTtDQUNoQyxNQUFNLFdBQVcsYUFBYSxNQUFNLFdBQVc7Q0FDL0MsSUFBSSxZQUFZLE1BQU07RUFDbEIsT0FBTztDQUNYLE9BQ0s7RUFDRCxNQUFNLHdCQUF3QixJQUFJO0NBQ3RDO0FBQ0o7QUFDQSxNQUFNLGlCQUFpQixDQUFDLEtBQUssVUFBVTtBQUN2QyxTQUFTLHNCQUFzQixNQUFNO0NBQ2pDLE9BQU8sYUFBYSxNQUFNLGNBQWM7QUFDNUM7QUFDQSxNQUFNLFlBQVksQ0FBQyxLQUFLLEtBQUs7QUFDN0IsU0FBUyxpQkFBaUIsTUFBTTtDQUM1QixNQUFNLFdBQVcsYUFBYSxNQUFNLFNBQVM7Q0FDN0MsSUFBSSxVQUFVO0VBQ1YsT0FBTztDQUNYLE9BQ0s7RUFDRCxNQUFNO0dBQXdCOztFQUF3QjtDQUMxRDtBQUNKO0FBQ0EsU0FBUyxhQUFhLE1BQU0sT0FBTyxjQUFjO0NBQzdDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztFQUNuQyxNQUFNLE9BQU8sTUFBTTs7RUFFbkIsSUFBSSxPQUFPLE1BQU0sSUFBSSxLQUFLLEtBQUssU0FBUyxNQUFNOztHQUUxQyxPQUFPLEtBQUs7RUFDaEI7Q0FDSjtDQUNBLE9BQU87QUFDWDtBQUNBLE1BQU0sc0JBQXNCO0NBQ3hCLEdBQUc7Q0FDSCxHQUFHO0NBQ0gsR0FBRztDQUNILEdBQUc7Q0FDSCxHQUFHO0NBQ0gsR0FBRztDQUNILEdBQUc7Q0FDSCxHQUFHO0FBQ1A7QUFDQSxTQUFTLHdCQUF3QixNQUFNO0NBQ25DLE9BQU8sSUFBSSxNQUFNLHdCQUF3QixNQUFNO0FBQ25EO0FBRUEsU0FBUyxPQUFPLEtBQUs7Q0FDakIsTUFBTSxPQUFPLFFBQVEsWUFBWSxLQUFLLEdBQUc7Q0FDekMsT0FBTztBQUNYO0FBQ0EsU0FBUyxZQUFZLEtBQUssS0FBSztDQUMzQixNQUFNLE9BQU8sWUFBWSxHQUFHO0NBQzVCLElBQUksUUFBUSxNQUFNO0VBQ2QsTUFBTTtHQUF3Qjs7RUFBMEI7Q0FDNUQ7Q0FDQSxNQUFNLE9BQU8sWUFBWSxJQUFJO0NBQzdCLElBQUksU0FBUyxHQUEwQjtFQUNuQyxNQUFNLFNBQVM7RUFDZixNQUFNLFFBQVEsYUFBYSxNQUFNO0VBQ2pDLE9BQU8sSUFBSSxPQUFPLE1BQU0sUUFBUSxVQUFVLE1BQU0sQ0FDNUMsR0FBRyxVQUNILG1CQUFtQixLQUFLLENBQUMsQ0FDN0IsR0FBRyxDQUFDLENBQUMsQ0FBQztDQUNWLE9BQ0s7RUFDRCxPQUFPLG1CQUFtQixLQUFLLElBQUk7Q0FDdkM7QUFDSjtBQUNBLFNBQVMsbUJBQW1CLEtBQUssTUFBTTtDQUNuQyxNQUFNLFVBQVUsY0FBYyxJQUFJO0NBQ2xDLElBQUksV0FBVyxNQUFNO0VBQ2pCLE9BQU8sSUFBSSxTQUFTLFNBQ2QsVUFDQSxJQUFJLFVBQVUsQ0FBQyxPQUFPLENBQUM7Q0FDakMsT0FDSztFQUNELE1BQU0sV0FBVyxhQUFhLElBQUksQ0FBQyxDQUFDLFFBQVEsS0FBSyxNQUFNLENBQUMsR0FBRyxLQUFLLGtCQUFrQixLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUM5RixPQUFPLElBQUksVUFBVSxRQUFRO0NBQ2pDO0FBQ0o7QUFDQSxTQUFTLGtCQUFrQixLQUFLLE1BQU07Q0FDbEMsTUFBTSxPQUFPLFlBQVksSUFBSTtDQUM3QixRQUFRLE1BQVI7RUFDSSxLQUFLLEdBQXdCO0dBQ3pCLE9BQU8sZUFBZSxNQUFNLElBQUk7RUFDcEM7RUFDQSxLQUFLLEdBQTJCO0dBQzVCLE9BQU8sZUFBZSxNQUFNLElBQUk7RUFDcEM7RUFDQSxLQUFLLEdBQXlCO0dBQzFCLE1BQU0sUUFBUTtHQUNkLElBQUksT0FBTyxPQUFPLEdBQUcsS0FBSyxNQUFNLEdBQUc7SUFDL0IsT0FBTyxJQUFJLFlBQVksSUFBSSxNQUFNLE1BQU0sQ0FBQyxDQUFDO0dBQzdDO0dBQ0EsSUFBSSxPQUFPLE9BQU8sS0FBSyxLQUFLLE1BQU0sS0FBSztJQUNuQyxPQUFPLElBQUksWUFBWSxJQUFJLE1BQU0sTUFBTSxHQUFHLENBQUM7R0FDL0M7R0FDQSxNQUFNLHdCQUF3QixJQUFJO0VBQ3RDO0VBQ0EsS0FBSyxHQUF3QjtHQUN6QixNQUFNLE9BQU87R0FDYixJQUFJLE9BQU8sTUFBTSxHQUFHLEtBQUssU0FBUyxLQUFLLENBQUMsR0FBRztJQUN2QyxPQUFPLElBQUksWUFBWSxJQUFJLEtBQUssS0FBSyxDQUFDLENBQUM7R0FDM0M7R0FDQSxJQUFJLE9BQU8sTUFBTSxPQUFPLEtBQUssU0FBUyxLQUFLLEtBQUssR0FBRztJQUMvQyxPQUFPLElBQUksWUFBWSxJQUFJLEtBQUssS0FBSyxLQUFLLENBQUM7R0FDL0M7R0FDQSxNQUFNLHdCQUF3QixJQUFJO0VBQ3RDO0VBQ0EsS0FBSyxHQUEwQjtHQUMzQixNQUFNLFNBQVM7R0FDZixNQUFNLFdBQVcsc0JBQXNCLE1BQU07R0FDN0MsTUFBTSxNQUFNLGlCQUFpQixNQUFNO0dBQ25DLE9BQU8sSUFBSSxPQUFPLGtCQUFrQixLQUFLLEdBQUcsR0FBRyxXQUFXLGtCQUFrQixLQUFLLFFBQVEsSUFBSSxXQUFXLElBQUksSUFBSTtFQUNwSDtFQUNBLEtBQUssR0FBNkI7R0FDOUIsT0FBTyxlQUFlLE1BQU0sSUFBSTtFQUNwQztFQUNBLEtBQUssR0FBa0M7R0FDbkMsT0FBTyxlQUFlLE1BQU0sSUFBSTtFQUNwQztFQUNBLFNBQ0ksTUFBTSxJQUFJLE1BQU0sMENBQTBDLE1BQU07Q0FDeEU7QUFDSjtBQUVBLE1BQU0sZUFBZTtBQUNyQixTQUFTLGlCQUFpQixRQUFRLGlCQUFpQjtDQUMvQyxJQUFJLG1CQUFtQixjQUFjLE1BQU0sR0FBRztFQUMxQyxLQUFLLFNBQVMsY0FBYyxFQUFFLE9BQU8sQ0FBQyxDQUFDO0NBQzNDO0FBQ0o7QUFDQSxNQUFNLHFCQUFxQixZQUFZO0FBQ3ZDLElBQUksZUFBZSxPQUFPO0FBQzFCLFNBQVMsb0JBQW9CO0NBQ3pCLGVBQWUsT0FBTztBQUMxQjtBQUNBLFNBQVMsWUFBWSxTQUFTLFVBQVUsQ0FBQyxHQUFHOztDQUV4QyxJQUFJLGNBQWM7Q0FDbEIsTUFBTSxVQUFVLFFBQVEsV0FBVztDQUNuQyxRQUFRLFdBQVcsUUFBUTtFQUN2QixjQUFjO0VBQ2QsUUFBUSxHQUFHO0NBQ2Y7O0NBRUEsT0FBTztFQUFFLEdBQUcsY0FBYyxTQUFTLE9BQU87RUFBRztDQUFZO0FBQzdEOztBQUVBLFNBQVMsUUFBUSxTQUFTLFNBQVM7Q0FDL0IsSUFBSyxDQUFDLHFDQUNGLFNBQVMsT0FBTyxHQUFHOztFQUVuQixNQUFNLGtCQUFrQixVQUFVLFFBQVEsZUFBZSxJQUNuRCxRQUFRLGtCQUNSO0VBQ04sa0JBQTBCLGdCQUFpQixpQkFBaUIsU0FBUyxlQUFlOztFQUVwRixNQUFNLGFBQWEsUUFBUSxjQUFjO0VBQ3pDLE1BQU0sV0FBVyxXQUFXLE9BQU87RUFDbkMsTUFBTSxTQUFTLGFBQWE7RUFDNUIsSUFBSSxRQUFRO0dBQ1IsT0FBTztFQUNYOztFQUVBLE1BQU0sRUFBRSxLQUFLLGdCQUFnQixZQUFZLFNBQVM7R0FDOUMsR0FBRztHQUNILDRCQUFvQztHQUNwQyxLQUFLO0VBQ1QsQ0FBQzs7RUFFRCxNQUFNLE1BQU0sT0FBTyxHQUFHOztFQUV0QixPQUFPLENBQUMsY0FDRCxhQUFhLFlBQVksTUFDMUI7Q0FDVixPQUNLO0VBQ0Qsc0JBQThCLGdCQUFpQixDQUFDLGFBQWEsT0FBTyxHQUFHO0dBQ25FLEtBQUsseUNBQXlDLFFBQVEsSUFBSSx1Q0FBdUM7R0FDakcsY0FBYztFQUNsQjs7RUFFQSxNQUFNLFdBQVcsUUFBUTtFQUN6QixJQUFJLFVBQVU7R0FDVixNQUFNLFNBQVMsYUFBYTtHQUM1QixJQUFJLFFBQVE7SUFDUixPQUFPO0dBQ1g7O0dBRUEsT0FBUSxhQUFhLFlBQ2pCLE9BQU8sT0FBTztFQUN0QixPQUNLO0dBQ0QsT0FBTyxPQUFPLE9BQU87RUFDekI7Q0FDSjtBQUNKO0FBRUEsSUFBSSxXQUFXO0FBQ2YsU0FBUyxnQkFBZ0IsTUFBTTtDQUMzQixXQUFXO0FBQ2Y7QUFDQSxTQUFTLGtCQUFrQjtDQUN2QixPQUFPO0FBQ1g7QUFDQSxTQUFTLGlCQUFpQixNQUFNLFNBQVMsTUFBTTs7Q0FFM0MsWUFDSSxTQUFTLEtBQUssYUFBYTtFQUN2QixXQUFXLEtBQUssSUFBSTtFQUNwQjtFQUNBO0VBQ0E7Q0FDSixDQUFDO0FBQ1Q7QUFDQSxNQUFNLG9CQUNTLGtDQUFtQixvQkFBb0I7QUFDdEQsU0FBUyxtQkFBbUIsTUFBTTtDQUM5QixRQUFRLGFBQWEsWUFBWSxTQUFTLEtBQUssTUFBTSxRQUFRO0FBQ2pFO0FBRUEsTUFBTSxpQkFBaUI7Q0FDbkIsa0JBQWtCO0NBQ2xCLHVCQUF1QjtDQUN2QiwyQkFBMkI7Q0FDM0IsZ0NBQWdDO0NBQ2hDLGtDQUFrQztDQUNsQyxtQ0FBbUM7Q0FDbkMseUJBQXlCO0FBQzdCO0FBQ0EsTUFBTSxnQ0FBZ0M7QUFDdEMsU0FBUyxnQkFBZ0IsTUFBTTtDQUMzQixPQUFPLG1CQUFtQixNQUFNLHdCQUFnQyxlQUFnQixFQUFFLFVBQVUsY0FBYyxJQUFJLFNBQVM7QUFDM0g7O0FBRUEsTUFBTSxnQkFBZ0I7RUFDakIsZUFBZSxtQkFBbUI7RUFDbEMsZUFBZSx3QkFBd0IsaURBQ3BDO0VBQ0gsZUFBZSw0QkFBNEI7RUFDM0MsZUFBZSxpQ0FBaUM7RUFDaEQsZUFBZSxtQ0FBbUM7RUFDbEQsZUFBZSxvQ0FBb0M7RUFDbkQsZUFBZSwwQkFBMEI7QUFDOUM7O0FBR0EsU0FBUyxVQUFVLFNBQVMsU0FBUztDQUNqQyxPQUFPLFFBQVEsVUFBVSxPQUNuQixjQUFjLFFBQVEsTUFBTSxJQUM1QixjQUFjLFFBQVEsTUFBTTtBQUN0QztBQUNBLElBQUk7O0FBRUosU0FBUyxjQUFjLFFBQVE7Q0FDM0IsSUFBSSxTQUFTLE1BQU0sR0FBRztFQUNsQixPQUFPO0NBQ1gsT0FDSztFQUNELElBQUksV0FBVyxNQUFNLEdBQUc7R0FDcEIsSUFBSSxPQUFPLGdCQUFnQixrQkFBa0IsTUFBTTtJQUMvQyxPQUFPO0dBQ1gsT0FDSyxJQUFJLE9BQU8sWUFBWSxTQUFTLFlBQVk7SUFDN0MsTUFBTSxVQUFVLE9BQU87SUFDdkIsSUFBSSxVQUFVLE9BQU8sR0FBRztLQUNwQixNQUFNLGdCQUFnQixlQUFlLGdDQUFnQztJQUN6RTtJQUNBLE9BQVEsaUJBQWlCO0dBQzdCLE9BQ0s7SUFDRCxNQUFNLGdCQUFnQixlQUFlLGlDQUFpQztHQUMxRTtFQUNKLE9BQ0s7R0FDRCxNQUFNLGdCQUFnQixlQUFlLHVCQUF1QjtFQUNoRTtDQUNKO0FBQ0o7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBaUJBLFNBQVMsbUJBQW1CLEtBQUssVUFBVSxPQUFPOztDQUU5QyxPQUFPLENBQUMsR0FBRyxJQUFJLElBQUksQ0FDWCxPQUNBLEdBQUksUUFBUSxRQUFRLElBQ2QsV0FDQSxTQUFTLFFBQVEsSUFDYixPQUFPLEtBQUssUUFBUSxJQUNwQixTQUFTLFFBQVEsSUFDYixDQUFDLFFBQVEsSUFDVCxDQUFDLEtBQUssQ0FDeEIsQ0FBQyxDQUFDO0FBQ1Y7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBaUJBLFNBQVMsd0JBQXdCLEtBQUssVUFBVSxPQUFPO0NBQ25ELE1BQU0sY0FBYyxTQUFTLEtBQUssSUFBSSxRQUFRO0NBQzlDLE1BQU0sVUFBVTtDQUNoQixJQUFJLENBQUMsUUFBUSxvQkFBb0I7RUFDN0IsUUFBUSxxQkFBcUIsSUFBSSxJQUFJO0NBQ3pDO0NBQ0EsSUFBSSxRQUFRLFFBQVEsbUJBQW1CLElBQUksV0FBVztDQUN0RCxJQUFJLENBQUMsT0FBTztFQUNSLFFBQVEsQ0FBQzs7RUFFVCxJQUFJLFFBQVEsQ0FBQyxLQUFLOztFQUVsQixPQUFPLFFBQVEsS0FBSyxHQUFHO0dBQ25CLFFBQVEsbUJBQW1CLE9BQU8sT0FBTyxRQUFRO0VBQ3JEOzs7RUFHQSxNQUFNLFdBQVcsUUFBUSxRQUFRLEtBQUssQ0FBQyxjQUFjLFFBQVEsSUFDdkQsV0FDQSxTQUFTLGFBQ0wsU0FBUyxhQUNUOztFQUVWLFFBQVEsU0FBUyxRQUFRLElBQUksQ0FBQyxRQUFRLElBQUk7RUFDMUMsSUFBSSxRQUFRLEtBQUssR0FBRztHQUNoQixtQkFBbUIsT0FBTyxPQUFPLEtBQUs7RUFDMUM7RUFDQSxRQUFRLG1CQUFtQixJQUFJLGFBQWEsS0FBSztDQUNyRDtDQUNBLE9BQU87QUFDWDtBQUNBLFNBQVMsbUJBQW1CLE9BQU8sT0FBTyxRQUFRO0NBQzlDLElBQUksU0FBUztDQUNiLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFVBQVUsVUFBVSxNQUFNLEdBQUcsS0FBSztFQUN4RCxNQUFNLFNBQVMsTUFBTTtFQUNyQixJQUFJLFNBQVMsTUFBTSxHQUFHO0dBQ2xCLFNBQVMsb0JBQW9CLE9BQU8sTUFBTSxJQUFJLE1BQU07RUFDeEQ7Q0FDSjtDQUNBLE9BQU87QUFDWDtBQUNBLFNBQVMsb0JBQW9CLE9BQU8sUUFBUSxRQUFRO0NBQ2hELElBQUk7Q0FDSixNQUFNLFNBQVMsT0FBTyxNQUFNLEdBQUc7Q0FDL0IsR0FBRztFQUNDLE1BQU0sU0FBUyxPQUFPLEtBQUssR0FBRztFQUM5QixTQUFTLGtCQUFrQixPQUFPLFFBQVEsTUFBTTtFQUNoRCxPQUFPLE9BQU8sQ0FBQyxHQUFHLENBQUM7Q0FDdkIsU0FBUyxPQUFPLFVBQVUsV0FBVztDQUNyQyxPQUFPO0FBQ1g7QUFDQSxTQUFTLGtCQUFrQixPQUFPLFFBQVEsUUFBUTtDQUM5QyxJQUFJLFNBQVM7Q0FDYixJQUFJLENBQUMsTUFBTSxTQUFTLE1BQU0sR0FBRztFQUN6QixTQUFTO0VBQ1QsSUFBSSxRQUFRO0dBQ1IsU0FBUyxPQUFPLE9BQU8sU0FBUyxPQUFPO0dBQ3ZDLE1BQU0sU0FBUyxPQUFPLFFBQVEsTUFBTSxFQUFFO0dBQ3RDLE1BQU0sS0FBSyxNQUFNO0dBQ2pCLEtBQUssUUFBUSxNQUFNLEtBQUssY0FBYyxNQUFNLE1BQ3hDLE9BQU8sU0FDVDs7SUFFRSxTQUFTLE9BQU87R0FDcEI7RUFDSjtDQUNKO0NBQ0EsT0FBTztBQUNYO0FBRUEsTUFBTSxtQkFBbUIsQ0FBQztBQUMxQixpQkFBaUIsS0FBOEI7RUFDMUMsTUFBb0MsQ0FBQyxDQUEwQjtFQUMvRCxNQUFnQyxDQUFDLEdBQXlCLENBQXNCO0VBQ2hGLE1BQXVDLENBQUMsQ0FBMEI7RUFDbEUsTUFBc0MsQ0FBQyxDQUF5QjtBQUNyRTtBQUNBLGlCQUFpQixLQUEwQjtFQUN0QyxNQUFvQyxDQUFDLENBQXNCO0VBQzNELE1BQThCLENBQUMsQ0FBMkI7RUFDMUQsTUFBdUMsQ0FBQyxDQUEwQjtFQUNsRSxNQUFzQyxDQUFDLENBQXlCO0FBQ3JFO0FBQ0EsaUJBQWlCLEtBQStCO0VBQzNDLE1BQW9DLENBQUMsQ0FBMkI7RUFDaEUsTUFBZ0MsQ0FBQyxHQUF5QixDQUFzQjtFQUNoRixNQUErQixDQUFDLEdBQXlCLENBQXNCO0FBQ3BGO0FBQ0EsaUJBQWlCLEtBQTJCO0VBQ3ZDLE1BQWdDLENBQUMsR0FBeUIsQ0FBc0I7RUFDaEYsTUFBK0IsQ0FBQyxHQUF5QixDQUFzQjtFQUMvRSxNQUFvQyxDQUFDLEdBQXdCLENBQW9CO0VBQ2pGLE1BQThCLENBQUMsR0FBNkIsQ0FBb0I7RUFDaEYsTUFBdUMsQ0FBQyxHQUE0QixDQUFvQjtFQUN4RixNQUFzQyxDQUFDLEdBQTJCLENBQW9CO0FBQzNGO0FBQ0EsaUJBQWlCLEtBQThCO0VBQzFDLE1BQXVDLENBQUMsR0FBZ0MsQ0FBc0I7RUFDOUYsT0FBd0MsQ0FBQyxHQUFnQyxDQUFzQjtFQUMvRixNQUF1QyxDQUNwQyxHQUNBLENBQ0o7RUFDQyxNQUF3QyxDQUFDLEdBQXdCLENBQTZCO0VBQzlGLE1BQXNDO0VBQ3RDLE1BQStCLENBQUMsR0FBNEIsQ0FBc0I7QUFDdkY7QUFDQSxpQkFBaUIsS0FBa0M7RUFDOUMsTUFBdUMsQ0FBQyxHQUE0QixDQUFzQjtFQUMxRixNQUFzQztFQUN0QyxNQUErQixDQUFDLEdBQWdDLENBQXNCO0FBQzNGO0FBQ0EsaUJBQWlCLEtBQWtDO0VBQzlDLE9BQXdDLENBQUMsR0FBNEIsQ0FBc0I7RUFDM0YsTUFBc0M7RUFDdEMsTUFBK0IsQ0FBQyxHQUFnQyxDQUFzQjtBQUMzRjs7OztBQUlBLE1BQU0saUJBQWlCO0FBQ3ZCLFNBQVMsVUFBVSxLQUFLO0NBQ3BCLE9BQU8sZUFBZSxLQUFLLEdBQUc7QUFDbEM7Ozs7QUFJQSxTQUFTLFlBQVksS0FBSztDQUN0QixNQUFNLElBQUksSUFBSSxXQUFXLENBQUM7Q0FDMUIsTUFBTSxJQUFJLElBQUksV0FBVyxJQUFJLFNBQVMsQ0FBQztDQUN2QyxPQUFPLE1BQU0sTUFBTSxNQUFNLE1BQVEsTUFBTSxNQUFRLElBQUksTUFBTSxHQUFHLENBQUMsQ0FBQyxJQUFJO0FBQ3RFOzs7O0FBSUEsU0FBUyxnQkFBZ0IsSUFBSTtDQUN6QixJQUFJLE9BQU8sYUFBYSxPQUFPLE1BQU07RUFDakMsT0FBTztDQUNYO0NBQ0EsTUFBTSxPQUFPLEdBQUcsV0FBVyxDQUFDO0NBQzVCLFFBQVEsTUFBUjtFQUNJLEtBQUs7O0VBQ0wsS0FBSzs7RUFDTCxLQUFLOztFQUNMLEtBQUs7O0VBQ0wsS0FBSztFQUNELE9BQU87RUFDWCxLQUFLOztFQUNMLEtBQUs7O0VBQ0wsS0FBSztFQUNELE9BQU87RUFDWCxLQUFLOztFQUNMLEtBQUs7O0VBQ0wsS0FBSzs7RUFDTCxLQUFLOztFQUNMLEtBQUs7O0VBQ0wsS0FBSzs7RUFDTCxLQUFLO0VBQ0QsT0FBTztDQUNmO0NBQ0EsT0FBTztBQUNYOzs7Ozs7QUFNQSxTQUFTLGNBQWMsTUFBTTtDQUN6QixNQUFNLFVBQVUsS0FBSyxLQUFLOztDQUUxQixJQUFJLEtBQUssT0FBTyxDQUFDLE1BQU0sT0FBTyxNQUFNLFNBQVMsSUFBSSxDQUFDLEdBQUc7RUFDakQsT0FBTztDQUNYO0NBQ0EsT0FBTyxVQUFVLE9BQU8sSUFDbEIsWUFBWSxPQUFPLElBQ25CLE1BQW1DO0FBQzdDOzs7O0FBSUEsU0FBUyxNQUFNLE1BQU07Q0FDakIsTUFBTSxPQUFPLENBQUM7Q0FDZCxJQUFJLFFBQVEsQ0FBQztDQUNiLElBQUksT0FBTztDQUNYLElBQUksZUFBZTtDQUNuQixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osTUFBTSxVQUFVLENBQUM7Q0FDakIsUUFBUSxXQUFnQztFQUNwQyxJQUFJLFFBQVEsV0FBVztHQUNuQixNQUFNO0VBQ1YsT0FDSztHQUNELE9BQU87RUFDWDtDQUNKO0NBQ0EsUUFBUSxXQUE4QjtFQUNsQyxJQUFJLFFBQVEsV0FBVztHQUNuQixLQUFLLEtBQUssR0FBRztHQUNiLE1BQU07RUFDVjtDQUNKO0NBQ0EsUUFBUSxXQUE0QztFQUNoRCxRQUFRLEVBQXVCLENBQUM7RUFDaEM7Q0FDSjtDQUNBLFFBQVEsV0FBdUM7RUFDM0MsSUFBSSxlQUFlLEdBQUc7R0FDbEI7R0FDQSxPQUFPO0dBQ1AsUUFBUSxFQUF1QixDQUFDO0VBQ3BDLE9BQ0s7R0FDRCxlQUFlO0dBQ2YsSUFBSSxRQUFRLFdBQVc7SUFDbkIsT0FBTztHQUNYO0dBQ0EsTUFBTSxjQUFjLEdBQUc7R0FDdkIsSUFBSSxRQUFRLE9BQU87SUFDZixPQUFPO0dBQ1gsT0FDSztJQUNELFFBQVEsRUFBcUIsQ0FBQztHQUNsQztFQUNKO0NBQ0o7Q0FDQSxTQUFTLHFCQUFxQjtFQUMxQixNQUFNLFdBQVcsS0FBSyxRQUFRO0VBQzlCLElBQUssU0FBUyxLQUNWLGFBQWEsT0FDWixTQUFTLEtBQ04sYUFBYSxNQUF3QztHQUN6RDtHQUNBLFVBQVUsT0FBTztHQUNqQixRQUFRLEVBQXVCLENBQUM7R0FDaEMsT0FBTztFQUNYO0NBQ0o7Q0FDQSxPQUFPLFNBQVMsTUFBTTtFQUNsQjtFQUNBLElBQUksS0FBSztFQUNULElBQUksTUFBTSxRQUFRLG1CQUFtQixHQUFHO0dBQ3BDO0VBQ0o7RUFDQSxPQUFPLGdCQUFnQixDQUFDO0VBQ3hCLFVBQVUsaUJBQWlCO0VBQzNCLGFBQWEsUUFBUSxTQUFTLFFBQVEsUUFBaUM7O0VBRXZFLElBQUksZUFBZSxHQUFzQjtHQUNyQztFQUNKO0VBQ0EsT0FBTyxXQUFXO0VBQ2xCLElBQUksV0FBVyxPQUFPLFdBQVc7R0FDN0IsU0FBUyxRQUFRLFdBQVc7R0FDNUIsSUFBSSxRQUFRO0lBQ1IsVUFBVTtJQUNWLElBQUksT0FBTyxNQUFNLE9BQU87S0FDcEI7SUFDSjtHQUNKO0VBQ0o7O0VBRUEsSUFBSSxTQUFTLEdBQTJCO0dBQ3BDLE9BQU87RUFDWDtDQUNKO0FBQ0o7O0FBRUEsTUFBTSxRQUFRLElBQUksSUFBSTs7Ozs7Ozs7Ozs7Ozs7QUFjdEIsU0FBUyxvQkFBb0IsS0FBSyxNQUFNO0NBQ3BDLE9BQU8sU0FBUyxHQUFHLElBQUksSUFBSSxRQUFRO0FBQ3ZDOzs7Ozs7Ozs7Ozs7OztBQWNBLFNBQVMsYUFBYSxLQUFLLE1BQU07O0NBRTdCLElBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRztFQUNoQixPQUFPO0NBQ1g7O0NBRUEsSUFBSSxNQUFNLE1BQU0sSUFBSSxJQUFJO0NBQ3hCLElBQUksQ0FBQyxLQUFLO0VBQ04sTUFBTSxNQUFNLElBQUk7RUFDaEIsSUFBSSxLQUFLO0dBQ0wsTUFBTSxJQUFJLE1BQU0sR0FBRztFQUN2QjtDQUNKOztDQUVBLElBQUksQ0FBQyxLQUFLO0VBQ04sT0FBTztDQUNYOztDQUVBLE1BQU0sTUFBTSxJQUFJOztDQUVoQixJQUFJLE9BQU87Q0FDWCxJQUFJLElBQUk7Q0FDUixPQUFPLElBQUksS0FBSztFQUNaLE1BQU0sTUFBTSxJQUFJOzs7Ozs7RUFNaEIsSUFBSSxvQkFBb0IsU0FBUyxHQUFHLEtBQUssYUFBYSxJQUFJLEdBQUc7R0FDekQsT0FBTztFQUNYO0VBQ0EsSUFBSSxDQUFDLFNBQVMsSUFBSSxHQUFHO0dBQ2pCLE9BQU87RUFDWDtFQUNBLElBQUksQ0FBQyxPQUFPLE1BQU0sR0FBRyxHQUFHO0dBQ3BCLE9BQU87RUFDWDtFQUNBLE1BQU0sTUFBTSxLQUFLO0VBQ2pCLElBQUksUUFBUSxXQUFXO0dBQ25CLE9BQU87RUFDWDtFQUNBLElBQUksV0FBVyxJQUFJLEdBQUc7R0FDbEIsT0FBTztFQUNYO0VBQ0EsT0FBTztFQUNQO0NBQ0o7Q0FDQSxPQUFPO0FBQ1g7QUFFQSxNQUFNLGdCQUFnQjtDQUNsQixlQUFlO0NBQ2YsdUJBQXVCO0NBQ3ZCLHNCQUFzQjtDQUN0QiwyQkFBMkI7Q0FDM0Isb0JBQW9CO0NBQ3BCLHlCQUF5QjtDQUN6QixzQ0FBc0M7Q0FDdEMseUJBQXlCO0NBQ3pCLHVCQUF1QjtBQUMzQjtBQUNBLE1BQU0sK0JBQStCOztBQUVyQyxNQUFNLGVBQWU7RUFDaEIsY0FBYyxnQkFBZ0I7RUFDOUIsY0FBYyx3QkFBd0I7RUFDdEMsY0FBYyx1QkFBdUI7RUFDckMsY0FBYyw0QkFBNEI7RUFDMUMsY0FBYyxxQkFBcUI7RUFDbkMsY0FBYywwQkFBMEI7RUFDeEMsY0FBYyx1Q0FBdUM7RUFDckQsY0FBYywwQkFBMEI7RUFDeEMsY0FBYyx3QkFBd0I7QUFDM0M7QUFDQSxTQUFTLGVBQWUsTUFBTSxHQUFHLE1BQU07Q0FDbkMsT0FBTyxTQUFTLGFBQWEsT0FBTyxHQUFHLElBQUk7QUFDL0M7Ozs7OztBQU9BLE1BQU0sVUFBVTtBQUNoQixNQUFNLGVBQWUsQ0FBQztBQUN0QixNQUFNLGlCQUFpQjtBQUN2QixNQUFNLHdCQUF3QjtBQUM5QixNQUFNLGNBQWMsUUFBUSxHQUFHLElBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsSUFBSSxJQUFJLE9BQU8sQ0FBQztBQUMvRSxTQUFTLDRCQUE0QjtDQUNqQyxPQUFPO0VBQ0gsUUFBUSxLQUFLLFNBQVM7O0dBRWxCLE9BQU8sU0FBUyxVQUFVLFNBQVMsR0FBRyxJQUNoQyxJQUFJLFlBQVksSUFDaEIsU0FBUyxXQUFXLFNBQVMsR0FBRyxLQUFLLGlCQUFpQixNQUNsRCxJQUFJLFNBQVMsWUFBWSxJQUN6QjtFQUNkO0VBQ0EsUUFBUSxLQUFLLFNBQVM7O0dBRWxCLE9BQU8sU0FBUyxVQUFVLFNBQVMsR0FBRyxJQUNoQyxJQUFJLFlBQVksSUFDaEIsU0FBUyxXQUFXLFNBQVMsR0FBRyxLQUFLLGlCQUFpQixNQUNsRCxJQUFJLFNBQVMsWUFBWSxJQUN6QjtFQUNkO0VBQ0EsYUFBYSxLQUFLLFNBQVM7O0dBRXZCLE9BQVEsU0FBUyxVQUFVLFNBQVMsR0FBRyxJQUNqQyxXQUFXLEdBQUcsSUFDZCxTQUFTLFdBQVcsU0FBUyxHQUFHLEtBQUssaUJBQWlCLE1BQ2xELFdBQVcsSUFBSSxRQUFRLElBQ3ZCO0VBQ2Q7Q0FDSjtBQUNKO0FBQ0EsSUFBSTtBQUNKLFNBQVMsd0JBQXdCLFVBQVU7Q0FDdkMsWUFBWTtBQUNoQjtBQUNBLElBQUk7Ozs7Ozs7O0FBUUosU0FBUyx3QkFBd0IsVUFBVTtDQUN2QyxZQUFZO0FBQ2hCO0FBQ0EsSUFBSTs7Ozs7Ozs7QUFRSixTQUFTLHlCQUF5QixZQUFZO0NBQzFDLGNBQWM7QUFDbEI7O0FBRUEsSUFBSSxrQkFBa0I7QUFFdEIsTUFBTSxnREFBcUIsU0FBUztDQUNoQyxrQkFBa0I7QUFDdEI7QUFFQSxNQUFNLHFEQUEwQjtBQUNoQyxJQUFJLG1CQUFtQjtBQUN2QixNQUFNLHNCQUFzQixZQUFZO0NBQ3BDLG1CQUFtQjtBQUN2QjtBQUNBLE1BQU0sMkJBQTJCOztBQUVqQyxJQUFJLE9BQU87QUFDWCxTQUFTLGtCQUFrQixVQUFVLENBQUMsR0FBRzs7Q0FFckMsTUFBTSxTQUFTLFdBQVcsUUFBUSxNQUFNLElBQUksUUFBUSxTQUFTO0NBQzdELE1BQU0sVUFBVSxTQUFTLFFBQVEsT0FBTyxJQUFJLFFBQVEsVUFBVTtDQUM5RCxNQUFNLFNBQVMsU0FBUyxRQUFRLE1BQU0sS0FBSyxXQUFXLFFBQVEsTUFBTSxJQUM5RCxRQUFRLFNBQ1I7Q0FDTixNQUFNLFVBQVUsV0FBVyxNQUFNLElBQUksaUJBQWlCO0NBQ3RELE1BQU0saUJBQWlCLFFBQVEsUUFBUSxjQUFjLEtBQ2pELGNBQWMsUUFBUSxjQUFjLEtBQ3BDLFNBQVMsUUFBUSxjQUFjLEtBQy9CLFFBQVEsbUJBQW1CLFFBQ3pCLFFBQVEsaUJBQ1I7Q0FDTixNQUFNLFdBQVcsY0FBYyxRQUFRLFFBQVEsSUFDekMsUUFBUSxXQUNSLGdCQUFnQixPQUFPO0NBQzdCLE1BQU0sa0JBQWtCLGNBQWMsUUFBUSxlQUFlLElBQ25ELFFBQVEsa0JBQ1IsZ0JBQWdCLE9BQU87Q0FFakMsTUFBTSxnQkFBZ0IsY0FBYyxRQUFRLGFBQWEsSUFDL0MsUUFBUSxnQkFDUixnQkFBZ0IsT0FBTztDQUVqQyxNQUFNLFlBQVksT0FBTyxPQUFPLEdBQUcsUUFBUSxXQUFXLDBCQUEwQixDQUFDO0NBQ2pGLE1BQU0sY0FBYyxRQUFRLGVBQWUsT0FBTztDQUNsRCxNQUFNLFVBQVUsV0FBVyxRQUFRLE9BQU8sSUFBSSxRQUFRLFVBQVU7Q0FDaEUsTUFBTSxjQUFjLFVBQVUsUUFBUSxXQUFXLEtBQUssU0FBUyxRQUFRLFdBQVcsSUFDNUUsUUFBUSxjQUNSO0NBQ04sTUFBTSxlQUFlLFVBQVUsUUFBUSxZQUFZLEtBQUssU0FBUyxRQUFRLFlBQVksSUFDL0UsUUFBUSxlQUNSO0NBQ04sTUFBTSxpQkFBaUIsQ0FBQyxDQUFDLFFBQVE7Q0FDakMsTUFBTSxjQUFjLENBQUMsQ0FBQyxRQUFRO0NBQzlCLE1BQU0sa0JBQWtCLFdBQVcsUUFBUSxlQUFlLElBQ3BELFFBQVEsa0JBQ1I7Q0FDTixNQUFNLFlBQVksY0FBYyxRQUFRLFNBQVMsSUFBSSxRQUFRLFlBQVk7Q0FDekUsTUFBTSxrQkFBa0IsVUFBVSxRQUFRLGVBQWUsSUFDbkQsUUFBUSxrQkFDUjtDQUNOLE1BQU0sa0JBQWtCLENBQUMsQ0FBQyxRQUFRO0NBQ2xDLE1BQU0sa0JBQWtCLFdBQVcsUUFBUSxlQUFlLElBQ3BELFFBQVEsa0JBQ1I7Q0FDTixzQkFBOEIsZ0JBQzFCLFFBQ0EsUUFDQSxXQUFXLFFBQVEsZUFBZSxHQUFHO0VBQ3JDLFNBQVMsZUFBZSxjQUFjLG9DQUFvQyxDQUFDO0NBQy9FO0NBQ0EsTUFBTSxrQkFBa0IsV0FBVyxRQUFRLGVBQWUsSUFDcEQsUUFBUSxrQkFDUixhQUFhO0NBQ25CLE1BQU0sbUJBQW1CLFdBQVcsUUFBUSxnQkFBZ0IsSUFDdEQsUUFBUSxtQkFDUixlQUFlO0NBQ3JCLE1BQU0sa0JBQWtCLFNBQVMsUUFBUSxlQUFlLElBQ2xELFFBQVEsa0JBQ1I7O0NBRU4sTUFBTSxrQkFBa0I7Q0FDeEIsTUFBTSx1QkFBdUIsU0FBUyxnQkFBZ0Isb0JBQW9CLElBQ2hFLGdCQUFnQix1QkFDaEIsSUFBSSxJQUFJO0NBRWxCLE1BQU0scUJBQXFCLFNBQVMsZ0JBQWdCLGtCQUFrQixJQUM1RCxnQkFBZ0IscUJBQ2hCLElBQUksSUFBSTtDQUVsQixNQUFNLFNBQVMsU0FBUyxnQkFBZ0IsTUFBTSxJQUFJLGdCQUFnQixTQUFTLENBQUM7Q0FDNUU7Q0FDQSxNQUFNLFVBQVU7RUFDWjtFQUNBLEtBQUs7RUFDTDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0o7Q0FDQTtFQUNJLFFBQVEsa0JBQWtCO0VBQzFCLFFBQVEsZ0JBQWdCO0VBQ3hCLFFBQVEsdUJBQXVCO0VBQy9CLFFBQVEscUJBQXFCO0NBQ2pDOztDQUVBLHNCQUE4QixjQUFlO0VBQ3pDLFFBQVEsY0FDSixnQkFBZ0IsZUFBZSxPQUN6QixnQkFBZ0IsY0FDaEI7Q0FDZDs7Q0FFQSxzQkFBOEIsZ0JBQWlCLDJCQUEyQjtFQUN0RSxpQkFBaUIsU0FBUyxTQUFTLE1BQU07Q0FDN0M7Q0FDQSxPQUFPO0FBQ1g7QUFDQSxNQUFNLG1CQUFtQixZQUFZLEdBQUcsU0FBUyxPQUFPLEVBQUU7O0FBRTFELFNBQVMsd0JBQXdCLFVBQVUsS0FBSztDQUM1QyxPQUFPLG9CQUFvQixTQUFTLFNBQVMsS0FBSyxHQUFHLElBQUk7QUFDN0Q7O0FBRUEsU0FBUyx1QkFBdUIsU0FBUyxLQUFLO0NBQzFDLE9BQU8sbUJBQW1CLFNBQVMsUUFBUSxLQUFLLEdBQUcsSUFBSTtBQUMzRDs7QUFFQSxTQUFTLGNBQWMsU0FBUyxLQUFLLFFBQVEsYUFBYSxNQUFNO0NBQzVELE1BQU0sRUFBRSxTQUFTLFdBQVc7O0NBRTVCLHNCQUE4QixjQUFlO0VBQ3pDLE1BQU0sVUFBVSxRQUFRO0VBQ3hCLElBQUksU0FBUztHQUNULFFBQVEsS0FBSyxXQUFXO0lBQ3BCO0lBQ0E7SUFDQTtJQUNBLFNBQVMsR0FBRyxLQUFLLEdBQUc7R0FDeEIsQ0FBQztFQUNMO0NBQ0o7Q0FDQSxJQUFJLFlBQVksTUFBTTtFQUNsQixNQUFNLE1BQU0sUUFBUSxTQUFTLFFBQVEsS0FBSyxJQUFJO0VBQzlDLE9BQU8sU0FBUyxHQUFHLElBQUksTUFBTTtDQUNqQyxPQUNLO0VBQ0Qsc0JBQThCLGdCQUFpQix1QkFBdUIsYUFBYSxHQUFHLEdBQUc7R0FDckYsT0FBTyxlQUFlLGNBQWMsZUFBZTtJQUFFO0lBQUs7R0FBTyxDQUFDLENBQUM7RUFDdkU7RUFDQSxPQUFPO0NBQ1g7QUFDSjs7QUFFQSxTQUFTLHFCQUFxQixLQUFLLFFBQVEsVUFBVTtDQUNqRCxNQUFNLFVBQVU7Q0FDaEIsUUFBUSxxQkFBcUIsSUFBSSxJQUFJO0NBQ3JDLElBQUksaUJBQWlCLEtBQUssVUFBVSxNQUFNO0FBQzlDOztBQUVBLFNBQVMsbUJBQW1CLFFBQVEsZUFBZTtDQUMvQyxJQUFJLFdBQVcsZUFDWCxPQUFPO0NBQ1gsT0FBTyxPQUFPLE1BQU0sR0FBRyxDQUFDLENBQUMsT0FBTyxjQUFjLE1BQU0sR0FBRyxDQUFDLENBQUM7QUFDN0Q7O0FBRUEsU0FBUyxtQkFBbUIsY0FBYyxTQUFTO0NBQy9DLE1BQU0sUUFBUSxRQUFRLFFBQVEsWUFBWTtDQUMxQyxJQUFJLFVBQVUsQ0FBQyxHQUFHO0VBQ2QsT0FBTztDQUNYO0NBQ0EsS0FBSyxJQUFJLElBQUksUUFBUSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUs7RUFDN0MsSUFBSSxtQkFBbUIsY0FBYyxRQUFRLEVBQUUsR0FBRztHQUM5QyxPQUFPO0VBQ1g7Q0FDSjtDQUNBLE9BQU87QUFDWDs7QUFHQSxTQUFTLG9CQUFvQixTQUFTLEtBQUssUUFBUSxTQUFTLGFBQWEsY0FBYyxNQUFNO0NBQ3pGLE1BQU0sRUFBRSxnQkFBZ0Isa0JBQWtCLFdBQVc7Q0FDckQsTUFBTSxVQUFVLGlCQUFpQixTQUNqQyxnQkFBZ0IsTUFBTTtDQUN0QixJQUFJLE9BQU87Q0FDWCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxRQUFRLEtBQUs7RUFDckMsTUFBTSxlQUFlLFFBQVE7RUFDN0Isc0JBQThCLGdCQUMxQixXQUFXLGdCQUNYLHdCQUF3QixjQUFjLEdBQUcsR0FBRztHQUM1QyxPQUFPLGVBQWUsU0FBUyxvQkFDekIsY0FBYywwQkFDZCxjQUFjLDJCQUEyQjtJQUMzQztJQUNBLFFBQVE7R0FDWixDQUFDLENBQUM7RUFDTjtFQUNBLHNCQUE4QixnQkFBaUIsV0FBVyxjQUFjO0dBQ3BFLE1BQU0sVUFBVSxRQUFRO0dBQ3hCLElBQUksU0FBUztJQUNULFFBQVEsS0FBSyxZQUFZO0tBQ3JCO0tBQ0E7S0FDQTtLQUNBLElBQUk7S0FDSixTQUFTLEdBQUcsS0FBSyxHQUFHO0lBQ3hCLENBQUM7R0FDTDtFQUNKO0VBQ0EsTUFBTSxVQUFVLFFBQVEsaUJBQWlCLENBQUMsRUFBQyxDQUFFO0VBQzdDLElBQUksY0FBYyxNQUFNLEtBQUssU0FBUyxZQUFZLEdBQUc7R0FDakQsT0FBTztFQUNYO0VBQ0EsY0FBYyxTQUFTLEtBQUssY0FBYyxhQUFhLElBQUk7RUFDM0QsT0FBTztDQUNYO0NBQ0EsT0FBTztBQUNYO0FBQ0EsU0FBUyxxQkFBcUIsUUFBUSxLQUFLLFdBQVc7Q0FDbEQsSUFBSSxLQUFLLEdBQUcsT0FBTyxJQUFJO0NBQ3ZCLElBQUksY0FBYyxTQUFTLEtBQUssQ0FBQyxjQUFjLFNBQVMsR0FBRztFQUN2RCxLQUFLLEdBQUcsR0FBRyxJQUFJLEtBQUssVUFBVSxTQUFTO0NBQzNDO0NBQ0EsT0FBTztBQUNYO0FBQ0EsU0FBUyxpQkFBaUIsWUFBWSxRQUFRLFFBQVE7Q0FDbEQsS0FBSyxNQUFNLE9BQU8sUUFBUTtFQUN0QixNQUFNLFNBQVMsR0FBRyxPQUFPLElBQUk7RUFDN0IsS0FBSyxNQUFNLE1BQU0sV0FBVyxLQUFLLEdBQUc7R0FDaEMsSUFBSSxPQUFPLFVBQVUsR0FBRyxXQUFXLEdBQUcsT0FBTyxHQUFHLEdBQUc7SUFDL0MsV0FBVyxPQUFPLEVBQUU7R0FDeEI7RUFDSjtDQUNKO0FBQ0o7QUFDQSxTQUFTLGdCQUFnQixNQUFNLFNBQVMsa0JBQWtCLGFBQWE7Q0FDbkUsTUFBTSxHQUFHLE1BQU0sTUFBTSxRQUFRO0NBQzdCLElBQUksWUFBWTtDQUNoQixJQUFJLFNBQVMsSUFBSSxHQUFHO0VBQ2hCLFFBQVEsTUFBTTtDQUNsQixPQUNLLElBQUksY0FBYyxJQUFJLEdBQUc7RUFDMUIsT0FBTyxLQUFLLElBQUksQ0FBQyxDQUFDLFNBQVEsUUFBTztHQUM3QixJQUFJLFlBQVksU0FBUyxHQUFHLEdBQUc7SUFDM0IsVUFBVSxPQUFPLEtBQUs7R0FDMUIsT0FDSztJQUNELFFBQVEsT0FBTyxLQUFLO0dBQ3hCO0VBQ0osQ0FBQztDQUNMO0NBQ0EsSUFBSSxTQUFTLElBQUksR0FBRztFQUNoQixRQUFRLFNBQVM7Q0FDckIsT0FDSyxJQUFJLGNBQWMsSUFBSSxHQUFHO0VBQzFCLFlBQVk7Q0FDaEI7Q0FDQSxJQUFJLGNBQWMsSUFBSSxHQUFHO0VBQ3JCLFlBQVk7Q0FDaEI7Q0FDQSxPQUFPO0FBQ1g7QUFFQSxNQUFNLGNBQWMsT0FBTyxTQUFTO0FBQ3BDLE1BQU0saUJBQWlCO0NBQ25CLGdCQUFnQixlQUFlLE9BQU8sS0FBSyxtQkFBbUI7Q0FDOUQsY0FBYyxlQUFlLE9BQU8sS0FBSyxpQkFBaUI7QUFDOUQ7O0FBR0EsU0FBUyxTQUFTLFNBQVMsR0FBRyxNQUFNO0NBQ2hDLE1BQU0sRUFBRSxpQkFBaUIsYUFBYSxXQUFXO0NBQ2pELE1BQU0sRUFBRSx5QkFBeUI7Q0FDakMsc0JBQThCLGdCQUFpQixDQUFDLGVBQWUsZ0JBQWdCO0VBQzNFLE9BQU8sZUFBZSxjQUFjLGtCQUFrQixDQUFDO0VBQ3ZELE9BQU87Q0FDWDtDQUNBLElBQUksQ0FBQyxTQUFTLEtBQUssRUFBRSxLQUFLLENBQUMsT0FBTyxLQUFLLEVBQUUsS0FBSyxDQUFDLFNBQVMsS0FBSyxFQUFFLEdBQUc7RUFDOUQsc0JBQThCLGNBQWU7R0FDekMsT0FBTyxlQUFlLGNBQWMsdUJBQXVCLEVBQ3ZELE9BQU8sT0FBTyxLQUFLLEVBQUUsRUFDekIsQ0FBQyxDQUFDO0VBQ047RUFDQSxPQUFPO0NBQ1g7Q0FDQSxNQUFNLENBQUMsS0FBSyxPQUFPLFNBQVMsYUFBYSxrQkFBa0IsR0FBRyxJQUFJO0NBQ2xFLE1BQU0sY0FBYyxVQUFVLFFBQVEsV0FBVyxJQUMzQyxRQUFRLGNBQ1IsUUFBUTtDQUNkLE1BQU0sZUFBZSxVQUFVLFFBQVEsWUFBWSxJQUM3QyxRQUFRLGVBQ1IsUUFBUTtDQUNkLE1BQU0sT0FBTyxDQUFDLENBQUMsUUFBUTtDQUN2QixNQUFNLFNBQVMsVUFBVSxTQUFTLE9BQU87Q0FDekMsSUFBSSxDQUFDLFNBQVMsR0FBRyxLQUFLLFFBQVEsSUFBSTtFQUM5QixNQUFNLFlBQVksSUFBSSxLQUFLLGVBQWUsT0FBTyxRQUFRLE1BQU0sRUFBRSxHQUFHLFNBQVM7RUFDN0UsT0FBTyxDQUFDLE9BQU8sVUFBVSxPQUFPLEtBQUssSUFBSSxVQUFVLGNBQWMsS0FBSztDQUMxRTtDQUNBLE1BQU0sZUFBZSxvQkFBb0IsU0FBUyxLQUFLLFFBQVEsaUJBQWlCLGFBQWEsY0FBYyxpQkFBaUI7Q0FDNUgsSUFBSSxDQUFDLFNBQVMsWUFBWSxHQUFHO0VBQ3pCLE9BQU8sY0FBYyxlQUFlO0NBQ3hDO0NBQ0EsTUFBTSxTQUFTLGdCQUFnQixhQUFhLENBQUM7Q0FDN0MsTUFBTSxLQUFLLHFCQUFxQixjQUFjLEtBQUssU0FBUztDQUM1RCxJQUFJLFlBQVkscUJBQXFCLElBQUksRUFBRTtDQUMzQyxJQUFJLENBQUMsV0FBVztFQUNaLFlBQVksSUFBSSxLQUFLLGVBQWUsY0FBYyxPQUFPLENBQUMsR0FBRyxRQUFRLFNBQVMsQ0FBQztFQUMvRSxxQkFBcUIsSUFBSSxJQUFJLFNBQVM7Q0FDMUM7Q0FDQSxPQUFPLENBQUMsT0FBTyxVQUFVLE9BQU8sS0FBSyxJQUFJLFVBQVUsY0FBYyxLQUFLO0FBQzFFOztBQUVBLE1BQU0sK0JBQStCO0NBQ2pDO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDSjs7QUFFQSxTQUFTLGtCQUFrQixHQUFHLE1BQU07Q0FDaEMsTUFBTSxDQUFDLFFBQVE7Q0FDZixNQUFNLFVBQVUsT0FBTztDQUN2QixNQUFNLG1CQUFtQixPQUFPO0NBQ2hDLElBQUk7Q0FDSixJQUFJLFNBQVMsSUFBSSxHQUFHOzs7RUFHaEIsTUFBTSxVQUFVLEtBQUssTUFBTSxnQ0FBZ0M7RUFDM0QsSUFBSSxDQUFDLFNBQVM7R0FDVixNQUFNLGdCQUFnQixlQUFlLHlCQUF5QjtFQUNsRTs7O0VBR0EsTUFBTSxXQUFXLFFBQVEsS0FDbkIsUUFBUSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxHQUFHLElBQzVCLEdBQUcsUUFBUSxFQUFFLENBQUMsS0FBSyxJQUFJLFFBQVEsRUFBRSxDQUFDLEtBQUssTUFDdkMsR0FBRyxRQUFRLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxRQUFRLEVBQUUsQ0FBQyxLQUFLLE1BQzVDLFFBQVEsRUFBRSxDQUFDLEtBQUs7RUFDdEIsUUFBUSxJQUFJLEtBQUssUUFBUTtFQUN6QixJQUFJOztHQUVBLE1BQU0sWUFBWTtFQUN0QixRQUNNO0dBQ0YsTUFBTSxnQkFBZ0IsZUFBZSx5QkFBeUI7RUFDbEU7Q0FDSixPQUNLLElBQUksT0FBTyxJQUFJLEdBQUc7RUFDbkIsSUFBSSxNQUFNLEtBQUssUUFBUSxDQUFDLEdBQUc7R0FDdkIsTUFBTSxnQkFBZ0IsZUFBZSxxQkFBcUI7RUFDOUQ7RUFDQSxRQUFRO0NBQ1osT0FDSyxJQUFJLFNBQVMsSUFBSSxHQUFHO0VBQ3JCLFFBQVE7Q0FDWixPQUNLO0VBQ0QsTUFBTSxnQkFBZ0IsZUFBZSxnQkFBZ0I7Q0FDekQ7Q0FDQSxNQUFNLFlBQVksZ0JBQWdCLE1BQU0sU0FBUyxrQkFBa0IsNEJBQTRCO0NBQy9GLE9BQU87RUFBQyxRQUFRLE9BQU87RUFBSTtFQUFPO0VBQVM7Q0FBUztBQUN4RDs7QUFFQSxTQUFTLG9CQUFvQixLQUFLLFFBQVEsUUFBUTtDQUM5QyxNQUFNLFVBQVU7Q0FDaEIsaUJBQWlCLFFBQVEsc0JBQXNCLFFBQVEsTUFBTTtBQUNqRTs7QUFHQSxTQUFTLE9BQU8sU0FBUyxHQUFHLE1BQU07Q0FDOUIsTUFBTSxFQUFFLGVBQWUsYUFBYSxXQUFXO0NBQy9DLE1BQU0sRUFBRSx1QkFBdUI7Q0FDL0Isc0JBQThCLGdCQUFpQixDQUFDLGVBQWUsY0FBYztFQUN6RSxPQUFPLGVBQWUsY0FBYyxvQkFBb0IsQ0FBQztFQUN6RCxPQUFPO0NBQ1g7Q0FDQSxJQUFJLENBQUMsU0FBUyxLQUFLLEVBQUUsR0FBRztFQUNwQixzQkFBOEIsY0FBZTtHQUN6QyxPQUFPLGVBQWUsY0FBYyx5QkFBeUIsRUFDekQsT0FBTyxPQUFPLEtBQUssRUFBRSxFQUN6QixDQUFDLENBQUM7RUFDTjtFQUNBLE9BQU87Q0FDWDtDQUNBLE1BQU0sQ0FBQyxLQUFLLE9BQU8sU0FBUyxhQUFhLGdCQUFnQixHQUFHLElBQUk7Q0FDaEUsTUFBTSxjQUFjLFVBQVUsUUFBUSxXQUFXLElBQzNDLFFBQVEsY0FDUixRQUFRO0NBQ2QsTUFBTSxlQUFlLFVBQVUsUUFBUSxZQUFZLElBQzdDLFFBQVEsZUFDUixRQUFRO0NBQ2QsTUFBTSxPQUFPLENBQUMsQ0FBQyxRQUFRO0NBQ3ZCLE1BQU0sU0FBUyxVQUFVLFNBQVMsT0FBTztDQUN6QyxJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssUUFBUSxJQUFJO0VBQzlCLE1BQU0sWUFBWSxJQUFJLEtBQUssYUFBYSxPQUFPLFFBQVEsTUFBTSxFQUFFLEdBQUcsU0FBUztFQUMzRSxPQUFPLENBQUMsT0FBTyxVQUFVLE9BQU8sS0FBSyxJQUFJLFVBQVUsY0FBYyxLQUFLO0NBQzFFO0NBQ0EsTUFBTSxlQUFlLG9CQUFvQixTQUFTLEtBQUssUUFBUSxlQUFlLGFBQWEsY0FBYyxlQUFlO0NBQ3hILElBQUksQ0FBQyxTQUFTLFlBQVksR0FBRztFQUN6QixPQUFPLGNBQWMsZUFBZTtDQUN4QztDQUNBLE1BQU0sU0FBUyxjQUFjLGFBQWEsQ0FBQztDQUMzQyxNQUFNLEtBQUsscUJBQXFCLGNBQWMsS0FBSyxTQUFTO0NBQzVELElBQUksWUFBWSxtQkFBbUIsSUFBSSxFQUFFO0NBQ3pDLElBQUksQ0FBQyxXQUFXO0VBQ1osWUFBWSxJQUFJLEtBQUssYUFBYSxjQUFjLE9BQU8sQ0FBQyxHQUFHLFFBQVEsU0FBUyxDQUFDO0VBQzdFLG1CQUFtQixJQUFJLElBQUksU0FBUztDQUN4QztDQUNBLE9BQU8sQ0FBQyxPQUFPLFVBQVUsT0FBTyxLQUFLLElBQUksVUFBVSxjQUFjLEtBQUs7QUFDMUU7O0FBRUEsTUFBTSw2QkFBNkI7Q0FDL0I7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNKOztBQUVBLFNBQVMsZ0JBQWdCLEdBQUcsTUFBTTtDQUM5QixNQUFNLENBQUMsUUFBUTtDQUNmLE1BQU0sVUFBVSxPQUFPO0NBQ3ZCLE1BQU0sbUJBQW1CLE9BQU87Q0FDaEMsSUFBSSxDQUFDLFNBQVMsSUFBSSxHQUFHO0VBQ2pCLE1BQU0sZ0JBQWdCLGVBQWUsZ0JBQWdCO0NBQ3pEO0NBQ0EsTUFBTSxRQUFRO0NBQ2QsTUFBTSxZQUFZLGdCQUFnQixNQUFNLFNBQVMsa0JBQWtCLDBCQUEwQjtDQUM3RixPQUFPO0VBQUMsUUFBUSxPQUFPO0VBQUk7RUFBTztFQUFTO0NBQVM7QUFDeEQ7O0FBRUEsU0FBUyxrQkFBa0IsS0FBSyxRQUFRLFFBQVE7Q0FDNUMsTUFBTSxVQUFVO0NBQ2hCLGlCQUFpQixRQUFRLG9CQUFvQixRQUFRLE1BQU07QUFDL0Q7QUFFQSxNQUFNLG9CQUFvQixRQUFRO0FBQ2xDLE1BQU0sbUJBQW1CLFFBQVE7QUFDakMsTUFBTSw0QkFBNEI7QUFDbEMsTUFBTSxxQkFBcUIsV0FBVyxPQUFPLFdBQVcsSUFBSSxLQUFLLEtBQUssTUFBTTtBQUM1RSxNQUFNLHNCQUFzQjtBQUM1QixTQUFTLGNBQWMsUUFBUSxlQUFlO0NBQzFDLFNBQVMsS0FBSyxJQUFJLE1BQU07O0NBRXhCLElBQUksa0JBQWtCLEdBQUc7O0VBRXJCLE9BQU8sV0FBVyxJQUNaLElBQ0E7Q0FDVjs7Q0FFQSxPQUFPLEtBQUssSUFBSSxRQUFRLENBQUM7QUFDN0I7QUFDQSxTQUFTLGVBQWUsU0FBUzs7Q0FFN0IsTUFBTSxRQUFRLFNBQVMsUUFBUSxXQUFXLElBQ3BDLFFBQVEsY0FDUixDQUFDO0NBQ1AsT0FBTyxTQUFTLFFBQVEsT0FBTyxLQUFLLElBQzlCLFFBQVEsTUFBTSxRQUNkLFNBQVMsUUFBUSxPQUFPLENBQUMsSUFDckIsUUFBUSxNQUFNLElBQ2Q7QUFDZDtBQUNBLFNBQVMscUJBQXFCLFVBQVUsQ0FBQyxHQUFHO0NBQ3hDLE1BQU0sU0FBUyxRQUFRO0NBQ3ZCLE1BQU0sY0FBYyxlQUFlLE9BQU87Q0FDMUMsTUFBTSxhQUFhLFNBQVMsTUFBTSxLQUFLLFdBQVcsUUFBUSxjQUFjLE9BQU8sSUFDekUsUUFBUSxZQUFZLFVBQ3BCO0NBQ04sTUFBTSxnQkFBZ0IsZUFBZSxnQkFBZ0IsWUFBWTtDQUNqRSxNQUFNLFVBQVUsYUFBYSxTQUFTLFdBQVcsYUFBYSxTQUFTLFFBQVEsYUFBYTtDQUM1RixNQUFNLFFBQVEsUUFBUSxRQUFRLENBQUM7Q0FDL0IsTUFBTSxRQUFRLFVBQVUsTUFBTTtDQUM5QixNQUFNLFNBQVMsUUFBUSxTQUFTLE9BQU87O0NBRXZDLElBQUksU0FBUyxRQUFRLFdBQVcsR0FBRztFQUMvQixPQUFPLFVBQVUsUUFBUTtFQUN6QixPQUFPLE1BQU0sUUFBUTtDQUN6QjtDQUNBLE1BQU0sU0FBUyxRQUFRLE9BQU87Q0FDOUIsU0FBUyxRQUFRLEtBQUssV0FBVzs7RUFFN0IsTUFBTSxNQUFNLFdBQVcsUUFBUSxRQUFRLElBQ2pDLFFBQVEsU0FBUyxLQUFLLENBQUMsQ0FBQyxTQUFTLElBQ2pDLFNBQVMsUUFBUSxRQUFRLElBQ3JCLFFBQVEsU0FBUyxPQUNqQjtFQUNWLE9BQU8sQ0FBQyxNQUNGLFFBQVEsU0FDSixRQUFRLE9BQU8sUUFBUSxHQUFHLElBQzFCLGtCQUNKO0NBQ1Y7Q0FDQSxNQUFNLGFBQWEsU0FBUyxRQUFRLFlBQzlCLFFBQVEsVUFBVSxRQUNsQjtDQUNOLE1BQU0sWUFBWSxXQUFXLFFBQVEsV0FBVyxTQUFTLElBQ25ELFFBQVEsVUFBVSxZQUNsQjtDQUNOLE1BQU0sY0FBYyxXQUFXLFFBQVEsV0FBVyxXQUFXLElBQ3ZELFFBQVEsVUFBVSxjQUNsQjtDQUNOLE1BQU0sT0FBTyxTQUFTLFFBQVEsV0FBVyxJQUFJLElBQ3ZDLFFBQVEsVUFBVSxPQUNsQjtDQUNOLE1BQU0sVUFBVSxLQUFLLEdBQUcsU0FBUztFQUM3QixNQUFNLENBQUMsTUFBTSxRQUFRO0VBQ3JCLElBQUksT0FBTztFQUNYLElBQUksV0FBVztFQUNmLElBQUksS0FBSyxXQUFXLEdBQUc7R0FDbkIsSUFBSSxTQUFTLElBQUksR0FBRztJQUNoQixXQUFXLEtBQUssWUFBWTtJQUM1QixPQUFPLEtBQUssUUFBUTtHQUN4QixPQUNLLElBQUksU0FBUyxJQUFJLEdBQUc7SUFDckIsV0FBVyxRQUFRO0dBQ3ZCO0VBQ0osT0FDSyxJQUFJLEtBQUssV0FBVyxHQUFHO0dBQ3hCLElBQUksU0FBUyxJQUFJLEdBQUc7SUFDaEIsV0FBVyxRQUFRO0dBQ3ZCO0dBQ0EsSUFBSSxTQUFTLElBQUksR0FBRztJQUNoQixPQUFPLFFBQVE7R0FDbkI7RUFDSjtFQUNBLE1BQU0sTUFBTSxRQUFRLEtBQUssSUFBSSxDQUFDLENBQUMsR0FBRzs7RUFFbEMsTUFBTSxXQUFXLFFBQVEsTUFBTSxRQUFRLFlBQVksTUFBTTtFQUN6RCxNQUFNLE1BRU4sU0FBUyxXQUFXLFFBQVEsUUFBUSxLQUFLLFdBQ25DLFNBQVMsS0FDVDtFQUNOLE9BQU8sV0FBVyxVQUFVLFFBQVEsQ0FBQyxDQUFDLEtBQUssSUFBSSxJQUFJO0NBQ3ZEO0NBQ0EsTUFBTSxNQUFNO0dBQ1AsU0FBa0M7R0FDbEMsVUFBb0M7R0FDcEMsV0FBc0M7R0FDdEMsV0FBc0M7R0FDdEMsWUFBd0M7R0FDeEMsU0FBa0M7R0FDbEMsZ0JBQWdEO0dBQ2hELGNBQTRDO0dBQzVDLFdBQXNDLE9BQU8sT0FBTyxHQUFHLE9BQU8sTUFBTTtDQUN6RTtDQUNBLE9BQU87QUFDWDtBQUVBLE1BQU0sOEJBQThCO0FBQ3BDLE1BQU0scUJBQXFCLFFBQVEsV0FBVyxHQUFHOztBQUVqRCxTQUFTLFVBQVUsU0FBUyxHQUFHLE1BQU07Q0FDakMsTUFBTSxFQUFFLGdCQUFnQixpQkFBaUIsYUFBYSxpQkFBaUIsZ0JBQWdCLGFBQWE7Q0FDcEcsTUFBTSxDQUFDLEtBQUssV0FBVyxtQkFBbUIsR0FBRyxJQUFJO0NBQ2pELE1BQU0sY0FBYyxVQUFVLFFBQVEsV0FBVyxJQUMzQyxRQUFRLGNBQ1IsUUFBUTtDQUNkLE1BQU0sZUFBZSxVQUFVLFFBQVEsWUFBWSxJQUM3QyxRQUFRLGVBQ1IsUUFBUTtDQUNkLE1BQU0sa0JBQWtCLFVBQVUsUUFBUSxlQUFlLElBQ25ELFFBQVEsa0JBQ1IsUUFBUTtDQUNkLE1BQU0sa0JBQWtCLENBQUMsQ0FBQyxRQUFROztDQUVsQyxNQUFNLGtCQUFrQixTQUFTLFFBQVEsT0FBTyxLQUFLLFVBQVUsUUFBUSxPQUFPLElBQ3hFLENBQUMsVUFBVSxRQUFRLE9BQU8sSUFDdEIsUUFBUSxVQUNQLENBQUMsd0JBQXdCLE1BQU0sTUFDcEMsaUJBQ0ssQ0FBQyx3QkFBd0IsTUFBTSxNQUNoQztDQUNWLE1BQU0sbUJBQW1CLGtCQUNwQixtQkFBbUIsU0FDZixTQUFTLGVBQWUsS0FBSyxXQUFXLGVBQWU7Q0FDaEUsTUFBTSxTQUFTLFVBQVUsU0FBUyxPQUFPOztDQUV6QyxtQkFBbUIsYUFBYSxPQUFPOzs7Q0FHdkMsSUFBSSxDQUFDLGFBQWEsY0FBYyxXQUFXLENBQUMsa0JBQ3RDLHFCQUFxQixTQUFTLEtBQUssUUFBUSxnQkFBZ0IsY0FBYyxXQUFXLElBQ3BGO0VBQ0U7RUFDQTtFQUNBLFNBQVMsV0FBVyxPQUFPO0NBQy9COzs7Ozs7Q0FNSixJQUFJLFNBQVM7O0NBRWIsSUFBSSxlQUFlO0NBQ25CLElBQUksQ0FBQyxtQkFDRCxFQUFFLFNBQVMsTUFBTSxLQUNiLGFBQWEsTUFBTSxLQUNuQixrQkFBa0IsTUFBTSxJQUFJO0VBQ2hDLElBQUksa0JBQWtCO0dBQ2xCLFNBQVM7R0FDVCxlQUFlO0VBQ25CO0NBQ0o7O0NBRUEsSUFBSSxDQUFDLG9CQUNBLEVBQUUsU0FBUyxNQUFNLEtBQ2QsYUFBYSxNQUFNLEtBQ25CLGtCQUFrQixNQUFNLE1BQ3hCLENBQUMsU0FBUyxZQUFZLElBQUk7RUFDOUIsT0FBTyxjQUFjLGVBQWU7Q0FDeEM7O0NBRUEsc0JBQThCLGdCQUFpQixTQUFTLE1BQU0sS0FBSyxRQUFRLG1CQUFtQixNQUFNO0VBQ2hHLEtBQUssb0VBQ0QsOENBQ0EscURBQ0EsaUNBQWlDLElBQUksR0FBRztFQUM1QyxPQUFPO0NBQ1g7O0NBRUEsSUFBSSxXQUFXO0NBQ2YsTUFBTSxnQkFBZ0I7RUFDbEIsV0FBVztDQUNmOztDQUVBLE1BQU0sTUFBTSxDQUFDLGtCQUFrQixNQUFNLElBQy9CLHFCQUFxQixTQUFTLEtBQUssY0FBYyxRQUFRLGNBQWMsT0FBTyxJQUM5RTs7Q0FFTixJQUFJLFVBQVU7RUFDVixPQUFPO0NBQ1g7O0NBRUEsTUFBTSxhQUFhLHlCQUF5QixTQUFTLGNBQWMsU0FBUyxPQUFPO0NBQ25GLE1BQU0sYUFBYSxxQkFBcUIsVUFBVTtDQUNsRCxNQUFNLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSyxVQUFVOztDQUV6RCxJQUFJLE1BQU0sa0JBQ0osZ0JBQWdCLFVBQVUsR0FBRyxJQUM3Qjs7Q0FFTixJQUFJLG1CQUFtQixTQUFTLEdBQUcsR0FBRztFQUNsQyxNQUFNLHVCQUF1QixHQUFHO0NBQ3BDOztDQUVBLHNCQUE4QixnQkFBaUIsMkJBQTJCOztFQUV0RSxNQUFNLFdBQVc7R0FDYixXQUFXLEtBQUssSUFBSTtHQUNwQixLQUFLLFNBQVMsR0FBRyxJQUNYLE1BQ0Esa0JBQWtCLE1BQU0sSUFDcEIsT0FBTyxNQUNQO0dBQ1YsUUFBUSxpQkFBaUIsa0JBQWtCLE1BQU0sSUFDM0MsT0FBTyxTQUNQO0dBQ04sUUFBUSxTQUFTLE1BQU0sSUFDakIsU0FDQSxrQkFBa0IsTUFBTSxJQUNwQixPQUFPLFNBQ1A7R0FDVixTQUFTO0VBQ2I7RUFDQSxTQUFTLE9BQU8sT0FBTyxDQUFDLEdBQUcsUUFBUSxRQUFRLGtCQUFrQixLQUFLLENBQUMsQ0FBQztFQUNwRSxrQkFBa0IsUUFBUTtDQUM5QjtDQUNBLE9BQU87QUFDWDtBQUNBLFNBQVMsYUFBYSxTQUFTO0NBQzNCLElBQUksUUFBUSxRQUFRLElBQUksR0FBRztFQUN2QixRQUFRLE9BQU8sUUFBUSxLQUFLLEtBQUksU0FBUSxTQUFTLElBQUksSUFBSSxXQUFXLElBQUksSUFBSSxJQUFJO0NBQ3BGLE9BQ0ssSUFBSSxTQUFTLFFBQVEsS0FBSyxHQUFHO0VBQzlCLE9BQU8sS0FBSyxRQUFRLEtBQUssQ0FBQyxDQUFDLFNBQVEsUUFBTztHQUN0QyxJQUFJLFNBQVMsUUFBUSxNQUFNLElBQUksR0FBRztJQUM5QixRQUFRLE1BQU0sT0FBTyxXQUFXLFFBQVEsTUFBTSxJQUFJO0dBQ3REO0VBQ0osQ0FBQztDQUNMO0FBQ0o7QUFDQSxTQUFTLHFCQUFxQixTQUFTLEtBQUssUUFBUSxnQkFBZ0IsY0FBYyxhQUFhO0NBQzNGLE1BQU0sRUFBRSxVQUFVLFFBQVEsaUJBQWlCLGNBQWMscUJBQXFCO0NBQzlFLE1BQU0sVUFBVSxpQkFBaUIsU0FBUyxnQkFBZ0IsTUFBTTtDQUNoRSxJQUFJLFVBQVUsT0FBTztDQUNyQixJQUFJO0NBQ0osSUFBSSxTQUFTO0NBQ2IsSUFBSSxPQUFPO0NBQ1gsSUFBSSxLQUFLO0NBQ1QsTUFBTSxPQUFPO0NBQ2IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsUUFBUSxLQUFLO0VBQ3JDLGVBQWUsS0FBSyxRQUFRO0VBQzVCLHNCQUE4QixnQkFDMUIsV0FBVyxnQkFDWCxDQUFDLG1CQUFtQixRQUFRLFlBQVksS0FDeEMsd0JBQXdCLGNBQWMsR0FBRyxHQUFHO0dBQzVDLE9BQU8sZUFBZSxjQUFjLHVCQUF1QjtJQUN2RDtJQUNBLFFBQVE7R0FDWixDQUFDLENBQUM7RUFDTjtFQUNBLE1BQU0sNEJBQW9DLGVBQ3BDLFFBQVEsY0FDUjs7RUFFTixzQkFBOEIsZ0JBQWlCLFdBQVcsY0FBYztHQUNwRSxJQUFJLFNBQVM7SUFDVCxRQUFRLEtBQUssWUFBWTtLQUNyQjtLQUNBO0tBQ0E7S0FDQTtLQUNBLFNBQVMsR0FBRyxLQUFLLEdBQUc7SUFDeEIsQ0FBQztHQUNMO0VBQ0o7RUFDQSxVQUNJLFNBQVMsaUJBQWlCLE9BQU87O0VBRXJDLElBQUksUUFBUTtFQUNaLElBQUk7RUFDSixJQUFJO0VBQ0osc0JBQThCLGdCQUFpQixhQUFhLFNBQVM7R0FDakUsUUFBUSxPQUFPLFlBQVksSUFBSTtHQUMvQixXQUFXO0dBQ1gsU0FBUztHQUNULFFBQVEsS0FBSyxRQUFRO0VBQ3pCO0VBQ0EsS0FBSyxTQUFTLGFBQWEsU0FBUyxHQUFHLE9BQU8sTUFBTTs7R0FFaEQsU0FBUyxRQUFRO0VBQ3JCOztFQUVBLHNCQUE4QixnQkFBaUIsYUFBYSxTQUFTO0dBQ2pFLE1BQU0sTUFBTSxPQUFPLFlBQVksSUFBSTtHQUNuQyxJQUFJLFdBQVcsU0FBUyxRQUFRO0lBQzVCLFFBQVEsS0FBSyxtQkFBbUI7S0FDNUIsTUFBTTtLQUNOO0tBQ0EsU0FBUztLQUNULE1BQU0sTUFBTTtLQUNaLFNBQVMsR0FBRyxLQUFLLEdBQUc7SUFDeEIsQ0FBQztHQUNMO0dBQ0EsSUFBSSxZQUFZLFVBQVUsUUFBUSxTQUFTO0lBQ3ZDLEtBQUssTUFBTTtJQUNYLFFBQVEsMkJBQTJCLFVBQVUsTUFBTTtHQUN2RDtFQUNKO0VBQ0EsSUFBSSxTQUFTLE1BQU0sS0FBSyxhQUFhLE1BQU0sS0FBSyxrQkFBa0IsTUFBTSxHQUFHO0dBQ3ZFO0VBQ0o7RUFDQSxJQUFJLENBQUMsbUJBQW1CLGNBQWMsT0FBTyxHQUFHO0dBQzVDLE1BQU0sYUFBYSxjQUFjLFNBQ2pDLEtBQUssY0FBYyxhQUFhLElBQUk7R0FDcEMsSUFBSSxlQUFlLEtBQUs7SUFDcEIsU0FBUztHQUNiO0VBQ0o7RUFDQSxPQUFPO0NBQ1g7Q0FDQSxPQUFPO0VBQUM7RUFBUTtFQUFjO0NBQU87QUFDekM7QUFDQSxTQUFTLHFCQUFxQixTQUFTLEtBQUssY0FBYyxRQUFRLGNBQWMsU0FBUztDQUNyRixNQUFNLEVBQUUsaUJBQWlCLG9CQUFvQjtDQUM3QyxJQUFJLGtCQUFrQixNQUFNLEdBQUc7RUFDM0IsTUFBTSxNQUFNO0VBQ1osSUFBSSxTQUFTLElBQUksVUFBVTtFQUMzQixJQUFJLE1BQU0sSUFBSSxPQUFPO0VBQ3JCLE9BQU87Q0FDWDtDQUNBLElBQUksbUJBQW1CLE1BQU07RUFDekIsTUFBTSxhQUFhO0VBQ25CLElBQUksU0FBUztFQUNiLElBQUksTUFBTTtFQUNWLE9BQU87Q0FDWDs7Q0FFQSxNQUFNLDRCQUFvQyxlQUNwQyxRQUFRLGNBQ1I7Q0FDTixJQUFJLFFBQVE7Q0FDWixJQUFJO0NBQ0osSUFBSTtDQUNKLHNCQUE4QixnQkFBaUIsYUFBYSxTQUFTO0VBQ2pFLFFBQVEsT0FBTyxZQUFZLElBQUk7RUFDL0IsV0FBVztFQUNYLFNBQVM7RUFDVCxRQUFRLEtBQUssUUFBUTtDQUN6QjtDQUNBLE1BQU0sTUFBTSxnQkFBZ0IsUUFBUSxrQkFBa0IsU0FBUyxjQUFjLGNBQWMsUUFBUSxpQkFBaUIsT0FBTyxDQUFDOztDQUU1SCxzQkFBOEIsZ0JBQWlCLGFBQWEsU0FBUztFQUNqRSxNQUFNLE1BQU0sT0FBTyxZQUFZLElBQUk7RUFDbkMsSUFBSSxXQUFXLE9BQU87R0FDbEIsUUFBUSxLQUFLLHVCQUF1QjtJQUNoQyxNQUFNO0lBQ04sU0FBUztJQUNULE1BQU0sTUFBTTtJQUNaLFNBQVMsR0FBRyxZQUFZLEdBQUc7R0FDL0IsQ0FBQztFQUNMO0VBQ0EsSUFBSSxZQUFZLFVBQVUsUUFBUSxTQUFTO0dBQ3ZDLEtBQUssTUFBTTtHQUNYLFFBQVEsK0JBQStCLFVBQVUsTUFBTTtFQUMzRDtDQUNKO0NBQ0EsSUFBSSxTQUFTO0NBQ2IsSUFBSSxNQUFNO0NBQ1YsSUFBSSxTQUFTO0NBQ2IsT0FBTztBQUNYO0FBQ0EsU0FBUyxnQkFBZ0IsU0FBUyxLQUFLLFFBQVE7O0NBRTNDLE1BQU0sNEJBQW9DLGVBQ3BDLFFBQVEsY0FDUjtDQUNOLElBQUksUUFBUTtDQUNaLElBQUk7Q0FDSixJQUFJO0NBQ0osc0JBQThCLGdCQUFpQixhQUFhLFNBQVM7RUFDakUsUUFBUSxPQUFPLFlBQVksSUFBSTtFQUMvQixXQUFXO0VBQ1gsU0FBUztFQUNULFFBQVEsS0FBSyxRQUFRO0NBQ3pCO0NBQ0EsTUFBTSxXQUFXLElBQUksTUFBTTs7Q0FFM0Isc0JBQThCLGdCQUFpQixhQUFhLFNBQVM7RUFDakUsTUFBTSxNQUFNLE9BQU8sWUFBWSxJQUFJO0VBQ25DLElBQUksV0FBVyxPQUFPO0dBQ2xCLFFBQVEsS0FBSyxzQkFBc0I7SUFDL0IsTUFBTTtJQUNOLE9BQU87SUFDUCxNQUFNLE1BQU07SUFDWixTQUFTLEdBQUcsWUFBWSxHQUFHLElBQUk7R0FDbkMsQ0FBQztFQUNMO0VBQ0EsSUFBSSxZQUFZLFVBQVUsUUFBUSxTQUFTO0dBQ3ZDLEtBQUssTUFBTTtHQUNYLFFBQVEsOEJBQThCLFVBQVUsTUFBTTtFQUMxRDtDQUNKO0NBQ0EsT0FBTztBQUNYOztBQUVBLFNBQVMsbUJBQW1CLEdBQUcsTUFBTTtDQUNqQyxNQUFNLENBQUMsTUFBTSxNQUFNLFFBQVE7Q0FDM0IsTUFBTSxVQUFVLE9BQU87Q0FDdkIsSUFBSSxDQUFDLFNBQVMsSUFBSSxLQUNkLENBQUMsU0FBUyxJQUFJLEtBQ2QsQ0FBQyxrQkFBa0IsSUFBSSxLQUN2QixDQUFDLGFBQWEsSUFBSSxHQUFHO0VBQ3JCLE1BQU0sZ0JBQWdCLGVBQWUsZ0JBQWdCO0NBQ3pEOztDQUVBLE1BQU0sTUFBTSxTQUFTLElBQUksSUFDbkIsT0FBTyxJQUFJLElBQ1gsa0JBQWtCLElBQUksSUFDbEIsT0FDQTtDQUNWLElBQUksU0FBUyxJQUFJLEdBQUc7RUFDaEIsUUFBUSxTQUFTO0NBQ3JCLE9BQ0ssSUFBSSxTQUFTLElBQUksR0FBRztFQUNyQixRQUFRLFVBQVU7Q0FDdEIsT0FDSyxJQUFJLGNBQWMsSUFBSSxLQUFLLENBQUMsY0FBYyxJQUFJLEdBQUc7RUFDbEQsUUFBUSxRQUFRO0NBQ3BCLE9BQ0ssSUFBSSxRQUFRLElBQUksR0FBRztFQUNwQixRQUFRLE9BQU87Q0FDbkI7Q0FDQSxJQUFJLFNBQVMsSUFBSSxHQUFHO0VBQ2hCLFFBQVEsU0FBUztDQUNyQixPQUNLLElBQUksU0FBUyxJQUFJLEdBQUc7RUFDckIsUUFBUSxVQUFVO0NBQ3RCLE9BQ0ssSUFBSSxjQUFjLElBQUksR0FBRztFQUMxQixPQUFPLFNBQVMsSUFBSTtDQUN4QjtDQUNBLE9BQU8sQ0FBQyxLQUFLLE9BQU87QUFDeEI7QUFDQSxTQUFTLGtCQUFrQixTQUFTLFFBQVEsS0FBSyxRQUFRLGlCQUFpQixTQUFTO0NBQy9FLE9BQU87RUFDSDtFQUNBO0VBQ0E7RUFDQSxVQUFVLFFBQVE7R0FDZCxXQUFXLFFBQVEsR0FBRztHQUN0QixzQkFBOEIsY0FBZTtJQUN6QyxNQUFNLFVBQVUsc0JBQXNCLE1BQU07SUFDNUMsTUFBTSxZQUFZLElBQUksWUFDbEIsV0FDQSxrQkFBa0IsU0FBUyxJQUFJLFNBQVMsTUFBTSxRQUFRLElBQUksU0FBUyxJQUFJLE1BQU07SUFDakYsTUFBTSxVQUFVLFFBQVE7SUFDeEIsSUFBSSxXQUFXLFNBQVM7S0FDcEIsUUFBUSxLQUFLLGlCQUFpQjtNQUMxQixTQUFTO01BQ1QsT0FBTyxJQUFJO01BQ1gsT0FBTyxJQUFJLFlBQVksSUFBSSxTQUFTLE1BQU07TUFDMUMsS0FBSyxJQUFJLFlBQVksSUFBSSxTQUFTLElBQUk7TUFDdEMsU0FBUyxHQUFHLFlBQVksR0FBRztLQUMvQixDQUFDO0lBQ0w7SUFDQSxNQUFNLFVBQVUsOEJBQThCLElBQUk7SUFDbEQsTUFBTSxJQUFJLFlBQVksWUFBWSxHQUFHLFFBQVEsSUFBSSxjQUFjLE9BQU87R0FDMUU7R0FDQSxNQUFNO0VBQ1Y7RUFDQSxhQUFhLFdBQVcsdUJBQXVCLFFBQVEsS0FBSyxNQUFNO0NBQ3RFO0FBQ0o7QUFDQSxTQUFTLHNCQUFzQixRQUFRO0NBQ25DLElBQUksU0FBUyxNQUFNLEdBQUc7RUFDbEIsT0FBTztDQUNYLE9BQ0s7RUFDRCxJQUFJLE9BQU8sT0FBTyxPQUFPLElBQUksUUFBUTtHQUNqQyxPQUFPLE9BQU8sSUFBSTtFQUN0QjtDQUNKO0FBQ0o7QUFDQSxTQUFTLHlCQUF5QixTQUFTLFFBQVEsU0FBUyxTQUFTO0NBQ2pFLE1BQU0sRUFBRSxXQUFXLGFBQWEsaUJBQWlCLGNBQWMsZ0JBQWdCLGNBQWMsYUFBYSxvQkFBb0I7Q0FDOUgsTUFBTSxrQkFBa0IsS0FBSyxjQUFjO0VBQ3ZDLElBQUksTUFBTSxhQUFhLFNBQVMsR0FBRzs7RUFFbkMsSUFBSSxPQUFPLFNBQVMsbUJBQW1CLFlBQVk7R0FDL0MsTUFBTSxDQUFDLFVBQVUsV0FBVyxxQkFBcUIsbUJBQW1CLFNBQ3BFLEtBQUssUUFBUSxnQkFBZ0IsY0FBYyxXQUFXO0dBQ3RELE1BQU0sVUFBVSxhQUFhLFNBQVMsR0FBRztFQUM3QztFQUNBLElBQUksU0FBUyxHQUFHLEtBQUssYUFBYSxHQUFHLEdBQUc7R0FDcEMsSUFBSSxXQUFXO0dBQ2YsTUFBTSxnQkFBZ0I7SUFDbEIsV0FBVztHQUNmO0dBQ0EsTUFBTSxNQUFNLHFCQUFxQixTQUFTLEtBQUssUUFBUSxLQUFLLEtBQUssT0FBTztHQUN4RSxPQUFPLENBQUMsV0FDRixNQUNBO0VBQ1YsT0FDSyxJQUFJLGtCQUFrQixHQUFHLEdBQUc7R0FDN0IsT0FBTztFQUNYLE9BQ0s7O0dBRUQsT0FBTztFQUNYO0NBQ0o7Q0FDQSxNQUFNLGFBQWE7RUFDZjtFQUNBO0VBQ0E7RUFDQSxVQUFVO0NBQ2Q7Q0FDQSxJQUFJLFFBQVEsV0FBVztFQUNuQixXQUFXLFlBQVksUUFBUTtDQUNuQztDQUNBLElBQUksUUFBUSxNQUFNO0VBQ2QsV0FBVyxPQUFPLFFBQVE7Q0FDOUI7Q0FDQSxJQUFJLFFBQVEsT0FBTztFQUNmLFdBQVcsUUFBUSxRQUFRO0NBQy9CO0NBQ0EsSUFBSSxTQUFTLFFBQVEsTUFBTSxHQUFHO0VBQzFCLFdBQVcsY0FBYyxRQUFRO0NBQ3JDO0NBQ0EsT0FBTztBQUNYO0FBRUE7Q0FDSSxpQkFBaUI7QUFDckI7QUFFQSxTQUFTLHFCQUFxQiwrQkFBK0IsOEJBQThCLGdCQUFnQixlQUFlLDhCQUE4QixnQkFBZ0IsMkJBQTJCLHVCQUF1QixjQUFjLDRCQUE0QixTQUFTLG1CQUFtQixxQkFBcUIsbUJBQW1CLFNBQVMsbUJBQW1CLGlCQUFpQixzQkFBc0IsVUFBVSx5QkFBeUIsb0JBQW9CLG1CQUFtQixpQkFBaUIsb0JBQW9CLFdBQVcsZ0JBQWdCLGVBQWUsa0JBQWtCLG9CQUFvQixvQkFBb0IsY0FBYyxtQkFBbUIseUJBQXlCLHdCQUF3QixRQUFRLE9BQU8sbUJBQW1CLGlCQUFpQixvQkFBb0IsMEJBQTBCLHlCQUF5Qix5QkFBeUIsZUFBZSxjQUFjLHFCQUFxQixtQkFBbUIsaUJBQWlCLG9CQUFvQixXQUFXLG1CQUFtQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJjb3JlLWJhc2UubWpzP3Y9N2U3M2FmYzIiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyohXG4gICogY29yZS1iYXNlIHYxMS40LjhcbiAgKiAoYykgMjAyNiBrYXp1eWEga2F3YWd1Y2hpXG4gICogUmVsZWFzZWQgdW5kZXIgdGhlIE1JVCBMaWNlbnNlLlxuICAqL1xuaW1wb3J0IHsgZ2V0R2xvYmFsVGhpcywgaXNPYmplY3QsIGhhc093biwgaXNOdW1iZXIsIGNyZWF0ZSwgaXNTdHJpbmcsIGlzQm9vbGVhbiwgd2FybiwgZm9ybWF0IGFzIGZvcm1hdCQxLCBpc0FycmF5LCBpc1BsYWluT2JqZWN0LCBpc0Z1bmN0aW9uLCBpc1Byb21pc2UsIGFzc2lnbiwgaXNSZWdFeHAsIHdhcm5PbmNlLCBpc0VtcHR5T2JqZWN0LCBpc0RhdGUsIHRvRGlzcGxheVN0cmluZywgam9pbiwgc2FuaXRpemVUcmFuc2xhdGVkSHRtbCwgZXNjYXBlSHRtbCwgaW5Ccm93c2VyLCBtYXJrLCBtZWFzdXJlLCBnZW5lcmF0ZUZvcm1hdENhY2hlS2V5LCBnZW5lcmF0ZUNvZGVGcmFtZSB9IGZyb20gJ0BpbnRsaWZ5L3NoYXJlZCc7XG5pbXBvcnQgeyBkZXRlY3RIdG1sVGFnLCBkZWZhdWx0T25FcnJvciwgYmFzZUNvbXBpbGUgYXMgYmFzZUNvbXBpbGUkMSwgQ09NUElMRV9FUlJPUl9DT0RFU19FWFRFTkRfUE9JTlQsIGNyZWF0ZUNvbXBpbGVFcnJvciB9IGZyb20gJ0BpbnRsaWZ5L21lc3NhZ2UtY29tcGlsZXInO1xuZXhwb3J0IHsgQ29tcGlsZUVycm9yQ29kZXMsIGNyZWF0ZUNvbXBpbGVFcnJvciB9IGZyb20gJ0BpbnRsaWZ5L21lc3NhZ2UtY29tcGlsZXInO1xuXG4vKipcbiAqIFRoaXMgaXMgb25seSBjYWxsZWQgaW4gZXNtLWJ1bmRsZXIgYnVpbGRzLlxuICogaXN0YW5idWwtaWdub3JlLW5leHRcbiAqL1xuZnVuY3Rpb24gaW5pdEZlYXR1cmVGbGFncygpIHtcbiAgICBpZiAodHlwZW9mIF9fSU5UTElGWV9QUk9EX0RFVlRPT0xTX18gIT09ICdib29sZWFuJykge1xuICAgICAgICBnZXRHbG9iYWxUaGlzKCkuX19JTlRMSUZZX1BST0RfREVWVE9PTFNfXyA9IGZhbHNlO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIF9fSU5UTElGWV9EUk9QX01FU1NBR0VfQ09NUElMRVJfXyAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIGdldEdsb2JhbFRoaXMoKS5fX0lOVExJRllfRFJPUF9NRVNTQUdFX0NPTVBJTEVSX18gPSBmYWxzZTtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIGlzTWVzc2FnZUFTVCh2YWwpIHtcbiAgICByZXR1cm4gKGlzT2JqZWN0KHZhbCkgJiZcbiAgICAgICAgcmVzb2x2ZVR5cGUodmFsKSA9PT0gMCAmJlxuICAgICAgICAoaGFzT3duKHZhbCwgJ2InKSB8fCBoYXNPd24odmFsLCAnYm9keScpKSk7XG59XG5jb25zdCBQUk9QU19CT0RZID0gWydiJywgJ2JvZHknXTtcbmZ1bmN0aW9uIHJlc29sdmVCb2R5KG5vZGUpIHtcbiAgICByZXR1cm4gcmVzb2x2ZVByb3BzKG5vZGUsIFBST1BTX0JPRFkpO1xufVxuY29uc3QgUFJPUFNfQ0FTRVMgPSBbJ2MnLCAnY2FzZXMnXTtcbmZ1bmN0aW9uIHJlc29sdmVDYXNlcyhub2RlKSB7XG4gICAgcmV0dXJuIHJlc29sdmVQcm9wcyhub2RlLCBQUk9QU19DQVNFUywgW10pO1xufVxuY29uc3QgUFJPUFNfU1RBVElDID0gWydzJywgJ3N0YXRpYyddO1xuZnVuY3Rpb24gcmVzb2x2ZVN0YXRpYyhub2RlKSB7XG4gICAgcmV0dXJuIHJlc29sdmVQcm9wcyhub2RlLCBQUk9QU19TVEFUSUMpO1xufVxuY29uc3QgUFJPUFNfSVRFTVMgPSBbJ2knLCAnaXRlbXMnXTtcbmZ1bmN0aW9uIHJlc29sdmVJdGVtcyhub2RlKSB7XG4gICAgcmV0dXJuIHJlc29sdmVQcm9wcyhub2RlLCBQUk9QU19JVEVNUywgW10pO1xufVxuY29uc3QgUFJPUFNfVFlQRSA9IFsndCcsICd0eXBlJ107XG5mdW5jdGlvbiByZXNvbHZlVHlwZShub2RlKSB7XG4gICAgcmV0dXJuIHJlc29sdmVQcm9wcyhub2RlLCBQUk9QU19UWVBFKTtcbn1cbmNvbnN0IFBST1BTX1ZBTFVFID0gWyd2JywgJ3ZhbHVlJ107XG5mdW5jdGlvbiByZXNvbHZlVmFsdWUkMShub2RlLCB0eXBlKSB7XG4gICAgY29uc3QgcmVzb2x2ZWQgPSByZXNvbHZlUHJvcHMobm9kZSwgUFJPUFNfVkFMVUUpO1xuICAgIGlmIChyZXNvbHZlZCAhPSBudWxsKSB7XG4gICAgICAgIHJldHVybiByZXNvbHZlZDtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHRocm93IGNyZWF0ZVVuaGFuZGxlTm9kZUVycm9yKHR5cGUpO1xuICAgIH1cbn1cbmNvbnN0IFBST1BTX01PRElGSUVSID0gWydtJywgJ21vZGlmaWVyJ107XG5mdW5jdGlvbiByZXNvbHZlTGlua2VkTW9kaWZpZXIobm9kZSkge1xuICAgIHJldHVybiByZXNvbHZlUHJvcHMobm9kZSwgUFJPUFNfTU9ESUZJRVIpO1xufVxuY29uc3QgUFJPUFNfS0VZID0gWydrJywgJ2tleSddO1xuZnVuY3Rpb24gcmVzb2x2ZUxpbmtlZEtleShub2RlKSB7XG4gICAgY29uc3QgcmVzb2x2ZWQgPSByZXNvbHZlUHJvcHMobm9kZSwgUFJPUFNfS0VZKTtcbiAgICBpZiAocmVzb2x2ZWQpIHtcbiAgICAgICAgcmV0dXJuIHJlc29sdmVkO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgdGhyb3cgY3JlYXRlVW5oYW5kbGVOb2RlRXJyb3IoNiAvKiBOb2RlVHlwZXMuTGlua2VkICovKTtcbiAgICB9XG59XG5mdW5jdGlvbiByZXNvbHZlUHJvcHMobm9kZSwgcHJvcHMsIGRlZmF1bHRWYWx1ZSkge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcHJvcHMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3QgcHJvcCA9IHByb3BzW2ldO1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgICAgICBpZiAoaGFzT3duKG5vZGUsIHByb3ApICYmIG5vZGVbcHJvcF0gIT0gbnVsbCkge1xuICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbiAgICAgICAgICAgIHJldHVybiBub2RlW3Byb3BdO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBkZWZhdWx0VmFsdWU7XG59XG5jb25zdCBBU1RfTk9ERV9QUk9QU19LRVlTID0gW1xuICAgIC4uLlBST1BTX0JPRFksXG4gICAgLi4uUFJPUFNfQ0FTRVMsXG4gICAgLi4uUFJPUFNfU1RBVElDLFxuICAgIC4uLlBST1BTX0lURU1TLFxuICAgIC4uLlBST1BTX0tFWSxcbiAgICAuLi5QUk9QU19NT0RJRklFUixcbiAgICAuLi5QUk9QU19WQUxVRSxcbiAgICAuLi5QUk9QU19UWVBFXG5dO1xuZnVuY3Rpb24gY3JlYXRlVW5oYW5kbGVOb2RlRXJyb3IodHlwZSkge1xuICAgIHJldHVybiBuZXcgRXJyb3IoYHVuaGFuZGxlZCBub2RlIHR5cGU6ICR7dHlwZX1gKTtcbn1cblxuZnVuY3Rpb24gZm9ybWF0KGFzdCkge1xuICAgIGNvbnN0IG1zZyA9IChjdHgpID0+IGZvcm1hdFBhcnRzKGN0eCwgYXN0KTtcbiAgICByZXR1cm4gbXNnO1xufVxuZnVuY3Rpb24gZm9ybWF0UGFydHMoY3R4LCBhc3QpIHtcbiAgICBjb25zdCBib2R5ID0gcmVzb2x2ZUJvZHkoYXN0KTtcbiAgICBpZiAoYm9keSA9PSBudWxsKSB7XG4gICAgICAgIHRocm93IGNyZWF0ZVVuaGFuZGxlTm9kZUVycm9yKDAgLyogTm9kZVR5cGVzLlJlc291cmNlICovKTtcbiAgICB9XG4gICAgY29uc3QgdHlwZSA9IHJlc29sdmVUeXBlKGJvZHkpO1xuICAgIGlmICh0eXBlID09PSAxIC8qIE5vZGVUeXBlcy5QbHVyYWwgKi8pIHtcbiAgICAgICAgY29uc3QgcGx1cmFsID0gYm9keTtcbiAgICAgICAgY29uc3QgY2FzZXMgPSByZXNvbHZlQ2FzZXMocGx1cmFsKTtcbiAgICAgICAgcmV0dXJuIGN0eC5wbHVyYWwoY2FzZXMucmVkdWNlKChtZXNzYWdlcywgYykgPT4gW1xuICAgICAgICAgICAgLi4ubWVzc2FnZXMsXG4gICAgICAgICAgICBmb3JtYXRNZXNzYWdlUGFydHMoY3R4LCBjKVxuICAgICAgICBdLCBbXSkpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgcmV0dXJuIGZvcm1hdE1lc3NhZ2VQYXJ0cyhjdHgsIGJvZHkpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGZvcm1hdE1lc3NhZ2VQYXJ0cyhjdHgsIG5vZGUpIHtcbiAgICBjb25zdCBzdGF0aWNfID0gcmVzb2x2ZVN0YXRpYyhub2RlKTtcbiAgICBpZiAoc3RhdGljXyAhPSBudWxsKSB7XG4gICAgICAgIHJldHVybiBjdHgudHlwZSA9PT0gJ3RleHQnXG4gICAgICAgICAgICA/IHN0YXRpY19cbiAgICAgICAgICAgIDogY3R4Lm5vcm1hbGl6ZShbc3RhdGljX10pO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY29uc3QgbWVzc2FnZXMgPSByZXNvbHZlSXRlbXMobm9kZSkucmVkdWNlKChhY20sIGMpID0+IFsuLi5hY20sIGZvcm1hdE1lc3NhZ2VQYXJ0KGN0eCwgYyldLCBbXSk7XG4gICAgICAgIHJldHVybiBjdHgubm9ybWFsaXplKG1lc3NhZ2VzKTtcbiAgICB9XG59XG5mdW5jdGlvbiBmb3JtYXRNZXNzYWdlUGFydChjdHgsIG5vZGUpIHtcbiAgICBjb25zdCB0eXBlID0gcmVzb2x2ZVR5cGUobm9kZSk7XG4gICAgc3dpdGNoICh0eXBlKSB7XG4gICAgICAgIGNhc2UgMyAvKiBOb2RlVHlwZXMuVGV4dCAqLzoge1xuICAgICAgICAgICAgcmV0dXJuIHJlc29sdmVWYWx1ZSQxKG5vZGUsIHR5cGUpO1xuICAgICAgICB9XG4gICAgICAgIGNhc2UgOSAvKiBOb2RlVHlwZXMuTGl0ZXJhbCAqLzoge1xuICAgICAgICAgICAgcmV0dXJuIHJlc29sdmVWYWx1ZSQxKG5vZGUsIHR5cGUpO1xuICAgICAgICB9XG4gICAgICAgIGNhc2UgNCAvKiBOb2RlVHlwZXMuTmFtZWQgKi86IHtcbiAgICAgICAgICAgIGNvbnN0IG5hbWVkID0gbm9kZTtcbiAgICAgICAgICAgIGlmIChoYXNPd24obmFtZWQsICdrJykgJiYgbmFtZWQuaykge1xuICAgICAgICAgICAgICAgIHJldHVybiBjdHguaW50ZXJwb2xhdGUoY3R4Lm5hbWVkKG5hbWVkLmspKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChoYXNPd24obmFtZWQsICdrZXknKSAmJiBuYW1lZC5rZXkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gY3R4LmludGVycG9sYXRlKGN0eC5uYW1lZChuYW1lZC5rZXkpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IGNyZWF0ZVVuaGFuZGxlTm9kZUVycm9yKHR5cGUpO1xuICAgICAgICB9XG4gICAgICAgIGNhc2UgNSAvKiBOb2RlVHlwZXMuTGlzdCAqLzoge1xuICAgICAgICAgICAgY29uc3QgbGlzdCA9IG5vZGU7XG4gICAgICAgICAgICBpZiAoaGFzT3duKGxpc3QsICdpJykgJiYgaXNOdW1iZXIobGlzdC5pKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBjdHguaW50ZXJwb2xhdGUoY3R4Lmxpc3QobGlzdC5pKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaGFzT3duKGxpc3QsICdpbmRleCcpICYmIGlzTnVtYmVyKGxpc3QuaW5kZXgpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGN0eC5pbnRlcnBvbGF0ZShjdHgubGlzdChsaXN0LmluZGV4KSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aHJvdyBjcmVhdGVVbmhhbmRsZU5vZGVFcnJvcih0eXBlKTtcbiAgICAgICAgfVxuICAgICAgICBjYXNlIDYgLyogTm9kZVR5cGVzLkxpbmtlZCAqLzoge1xuICAgICAgICAgICAgY29uc3QgbGlua2VkID0gbm9kZTtcbiAgICAgICAgICAgIGNvbnN0IG1vZGlmaWVyID0gcmVzb2x2ZUxpbmtlZE1vZGlmaWVyKGxpbmtlZCk7XG4gICAgICAgICAgICBjb25zdCBrZXkgPSByZXNvbHZlTGlua2VkS2V5KGxpbmtlZCk7XG4gICAgICAgICAgICByZXR1cm4gY3R4LmxpbmtlZChmb3JtYXRNZXNzYWdlUGFydChjdHgsIGtleSksIG1vZGlmaWVyID8gZm9ybWF0TWVzc2FnZVBhcnQoY3R4LCBtb2RpZmllcikgOiB1bmRlZmluZWQsIGN0eC50eXBlKTtcbiAgICAgICAgfVxuICAgICAgICBjYXNlIDcgLyogTm9kZVR5cGVzLkxpbmtlZEtleSAqLzoge1xuICAgICAgICAgICAgcmV0dXJuIHJlc29sdmVWYWx1ZSQxKG5vZGUsIHR5cGUpO1xuICAgICAgICB9XG4gICAgICAgIGNhc2UgOCAvKiBOb2RlVHlwZXMuTGlua2VkTW9kaWZpZXIgKi86IHtcbiAgICAgICAgICAgIHJldHVybiByZXNvbHZlVmFsdWUkMShub2RlLCB0eXBlKTtcbiAgICAgICAgfVxuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGB1bmhhbmRsZWQgbm9kZSBvbiBmb3JtYXQgbWVzc2FnZSBwYXJ0OiAke3R5cGV9YCk7XG4gICAgfVxufVxuXG5jb25zdCBXQVJOX01FU1NBR0UgPSBgRGV0ZWN0ZWQgSFRNTCBpbiAne3NvdXJjZX0nIG1lc3NhZ2UuIFJlY29tbWVuZCBub3QgdXNpbmcgSFRNTCBtZXNzYWdlcyB0byBhdm9pZCBYU1MuYDtcbmZ1bmN0aW9uIGNoZWNrSHRtbE1lc3NhZ2Uoc291cmNlLCB3YXJuSHRtbE1lc3NhZ2UpIHtcbiAgICBpZiAod2Fybkh0bWxNZXNzYWdlICYmIGRldGVjdEh0bWxUYWcoc291cmNlKSkge1xuICAgICAgICB3YXJuKGZvcm1hdCQxKFdBUk5fTUVTU0FHRSwgeyBzb3VyY2UgfSkpO1xuICAgIH1cbn1cbmNvbnN0IGRlZmF1bHRPbkNhY2hlS2V5ID0gKG1lc3NhZ2UpID0+IG1lc3NhZ2U7XG5sZXQgY29tcGlsZUNhY2hlID0gY3JlYXRlKCk7XG5mdW5jdGlvbiBjbGVhckNvbXBpbGVDYWNoZSgpIHtcbiAgICBjb21waWxlQ2FjaGUgPSBjcmVhdGUoKTtcbn1cbmZ1bmN0aW9uIGJhc2VDb21waWxlKG1lc3NhZ2UsIG9wdGlvbnMgPSB7fSkge1xuICAgIC8vIGVycm9yIGRldGVjdGluZyBvbiBjb21waWxlXG4gICAgbGV0IGRldGVjdEVycm9yID0gZmFsc2U7XG4gICAgY29uc3Qgb25FcnJvciA9IG9wdGlvbnMub25FcnJvciB8fCBkZWZhdWx0T25FcnJvcjtcbiAgICBvcHRpb25zLm9uRXJyb3IgPSAoZXJyKSA9PiB7XG4gICAgICAgIGRldGVjdEVycm9yID0gdHJ1ZTtcbiAgICAgICAgb25FcnJvcihlcnIpO1xuICAgIH07XG4gICAgLy8gY29tcGlsZSB3aXRoIG1lc2FzZ2UtY29tcGlsZXJcbiAgICByZXR1cm4geyAuLi5iYXNlQ29tcGlsZSQxKG1lc3NhZ2UsIG9wdGlvbnMpLCBkZXRlY3RFcnJvciB9O1xufVxuLyogI19fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmZ1bmN0aW9uIGNvbXBpbGUobWVzc2FnZSwgY29udGV4dCkge1xuICAgIGlmICgoIV9fSU5UTElGWV9EUk9QX01FU1NBR0VfQ09NUElMRVJfXykgJiZcbiAgICAgICAgaXNTdHJpbmcobWVzc2FnZSkpIHtcbiAgICAgICAgLy8gY2hlY2sgSFRNTCBtZXNzYWdlXG4gICAgICAgIGNvbnN0IHdhcm5IdG1sTWVzc2FnZSA9IGlzQm9vbGVhbihjb250ZXh0Lndhcm5IdG1sTWVzc2FnZSlcbiAgICAgICAgICAgID8gY29udGV4dC53YXJuSHRtbE1lc3NhZ2VcbiAgICAgICAgICAgIDogdHJ1ZTtcbiAgICAgICAgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpICYmIGNoZWNrSHRtbE1lc3NhZ2UobWVzc2FnZSwgd2Fybkh0bWxNZXNzYWdlKTtcbiAgICAgICAgLy8gY2hlY2sgY2FjaGVzXG4gICAgICAgIGNvbnN0IG9uQ2FjaGVLZXkgPSBjb250ZXh0Lm9uQ2FjaGVLZXkgfHwgZGVmYXVsdE9uQ2FjaGVLZXk7XG4gICAgICAgIGNvbnN0IGNhY2hlS2V5ID0gb25DYWNoZUtleShtZXNzYWdlKTtcbiAgICAgICAgY29uc3QgY2FjaGVkID0gY29tcGlsZUNhY2hlW2NhY2hlS2V5XTtcbiAgICAgICAgaWYgKGNhY2hlZCkge1xuICAgICAgICAgICAgcmV0dXJuIGNhY2hlZDtcbiAgICAgICAgfVxuICAgICAgICAvLyBjb21waWxlIHdpdGggSklUIG1vZGVcbiAgICAgICAgY29uc3QgeyBhc3QsIGRldGVjdEVycm9yIH0gPSBiYXNlQ29tcGlsZShtZXNzYWdlLCB7XG4gICAgICAgICAgICAuLi5jb250ZXh0LFxuICAgICAgICAgICAgbG9jYXRpb246IChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSxcbiAgICAgICAgICAgIGppdDogdHJ1ZVxuICAgICAgICB9KTtcbiAgICAgICAgLy8gY29tcG9zZSBtZXNzYWdlIGZ1bmN0aW9uIGZyb20gQVNUXG4gICAgICAgIGNvbnN0IG1zZyA9IGZvcm1hdChhc3QpO1xuICAgICAgICAvLyBpZiBvY2N1cnJlZCBjb21waWxlIGVycm9yLCBkb24ndCBjYWNoZVxuICAgICAgICByZXR1cm4gIWRldGVjdEVycm9yXG4gICAgICAgICAgICA/IChjb21waWxlQ2FjaGVbY2FjaGVLZXldID0gbXNnKVxuICAgICAgICAgICAgOiBtc2c7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBpZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpICYmICFpc01lc3NhZ2VBU1QobWVzc2FnZSkpIHtcbiAgICAgICAgICAgIHdhcm4oYHRoZSBtZXNzYWdlIHRoYXQgaXMgcmVzb2x2ZSB3aXRoIGtleSAnJHtjb250ZXh0LmtleX0nIGlzIG5vdCBzdXBwb3J0ZWQgZm9yIGppdCBjb21waWxhdGlvbmApO1xuICAgICAgICAgICAgcmV0dXJuICgoKSA9PiBtZXNzYWdlKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBBU1QgY2FzZSAocGFzc2VkIGZyb20gYnVuZGxlcilcbiAgICAgICAgY29uc3QgY2FjaGVLZXkgPSBtZXNzYWdlLmNhY2hlS2V5O1xuICAgICAgICBpZiAoY2FjaGVLZXkpIHtcbiAgICAgICAgICAgIGNvbnN0IGNhY2hlZCA9IGNvbXBpbGVDYWNoZVtjYWNoZUtleV07XG4gICAgICAgICAgICBpZiAoY2FjaGVkKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGNhY2hlZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIGNvbXBvc2UgbWVzc2FnZSBmdW5jdGlvbiBmcm9tIG1lc3NhZ2UgKEFTVClcbiAgICAgICAgICAgIHJldHVybiAoY29tcGlsZUNhY2hlW2NhY2hlS2V5XSA9XG4gICAgICAgICAgICAgICAgZm9ybWF0KG1lc3NhZ2UpKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJldHVybiBmb3JtYXQobWVzc2FnZSk7XG4gICAgICAgIH1cbiAgICB9XG59XG5cbmxldCBkZXZ0b29scyA9IG51bGw7XG5mdW5jdGlvbiBzZXREZXZUb29sc0hvb2soaG9vaykge1xuICAgIGRldnRvb2xzID0gaG9vaztcbn1cbmZ1bmN0aW9uIGdldERldlRvb2xzSG9vaygpIHtcbiAgICByZXR1cm4gZGV2dG9vbHM7XG59XG5mdW5jdGlvbiBpbml0STE4bkRldlRvb2xzKGkxOG4sIHZlcnNpb24sIG1ldGEpIHtcbiAgICAvLyBUT0RPOiBxdWV1ZSBpZiBkZXZ0b29scyBpcyB1bmRlZmluZWRcbiAgICBkZXZ0b29scyAmJlxuICAgICAgICBkZXZ0b29scy5lbWl0KCdpMThuOmluaXQnLCB7XG4gICAgICAgICAgICB0aW1lc3RhbXA6IERhdGUubm93KCksXG4gICAgICAgICAgICBpMThuLFxuICAgICAgICAgICAgdmVyc2lvbixcbiAgICAgICAgICAgIG1ldGFcbiAgICAgICAgfSk7XG59XG5jb25zdCB0cmFuc2xhdGVEZXZUb29scyA9IFxuLyogI19fUFVSRV9fKi8gY3JlYXRlRGV2VG9vbHNIb29rKCdmdW5jdGlvbjp0cmFuc2xhdGUnKTtcbmZ1bmN0aW9uIGNyZWF0ZURldlRvb2xzSG9vayhob29rKSB7XG4gICAgcmV0dXJuIChwYXlsb2FkcykgPT4gZGV2dG9vbHMgJiYgZGV2dG9vbHMuZW1pdChob29rLCBwYXlsb2Fkcyk7XG59XG5cbmNvbnN0IENvcmVFcnJvckNvZGVzID0ge1xuICAgIElOVkFMSURfQVJHVU1FTlQ6IENPTVBJTEVfRVJST1JfQ09ERVNfRVhURU5EX1BPSU5ULCAvLyAxN1xuICAgIElOVkFMSURfREFURV9BUkdVTUVOVDogMTgsXG4gICAgSU5WQUxJRF9JU09fREFURV9BUkdVTUVOVDogMTksXG4gICAgTk9UX1NVUFBPUlRfTk9OX1NUUklOR19NRVNTQUdFOiAyMCxcbiAgICBOT1RfU1VQUE9SVF9MT0NBTEVfUFJPTUlTRV9WQUxVRTogMjEsXG4gICAgTk9UX1NVUFBPUlRfTE9DQUxFX0FTWU5DX0ZVTkNUSU9OOiAyMixcbiAgICBOT1RfU1VQUE9SVF9MT0NBTEVfVFlQRTogMjNcbn07XG5jb25zdCBDT1JFX0VSUk9SX0NPREVTX0VYVEVORF9QT0lOVCA9IDI0O1xuZnVuY3Rpb24gY3JlYXRlQ29yZUVycm9yKGNvZGUpIHtcbiAgICByZXR1cm4gY3JlYXRlQ29tcGlsZUVycm9yKGNvZGUsIG51bGwsIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSA/IHsgbWVzc2FnZXM6IGVycm9yTWVzc2FnZXMgfSA6IHVuZGVmaW5lZCk7XG59XG4vKiogQGludGVybmFsICovXG5jb25zdCBlcnJvck1lc3NhZ2VzID0ge1xuICAgIFtDb3JlRXJyb3JDb2Rlcy5JTlZBTElEX0FSR1VNRU5UXTogJ0ludmFsaWQgYXJndW1lbnRzJyxcbiAgICBbQ29yZUVycm9yQ29kZXMuSU5WQUxJRF9EQVRFX0FSR1VNRU5UXTogJ1RoZSBkYXRlIHByb3ZpZGVkIGlzIGFuIGludmFsaWQgRGF0ZSBvYmplY3QuJyArXG4gICAgICAgICdNYWtlIHN1cmUgeW91ciBEYXRlIHJlcHJlc2VudHMgYSB2YWxpZCBkYXRlLicsXG4gICAgW0NvcmVFcnJvckNvZGVzLklOVkFMSURfSVNPX0RBVEVfQVJHVU1FTlRdOiAnVGhlIGFyZ3VtZW50IHByb3ZpZGVkIGlzIG5vdCBhIHZhbGlkIElTTyBkYXRlIHN0cmluZycsXG4gICAgW0NvcmVFcnJvckNvZGVzLk5PVF9TVVBQT1JUX05PTl9TVFJJTkdfTUVTU0FHRV06ICdOb3Qgc3VwcG9ydCBub24tc3RyaW5nIG1lc3NhZ2UnLFxuICAgIFtDb3JlRXJyb3JDb2Rlcy5OT1RfU1VQUE9SVF9MT0NBTEVfUFJPTUlTRV9WQUxVRV06ICdjYW5ub3Qgc3VwcG9ydCBwcm9taXNlIHZhbHVlJyxcbiAgICBbQ29yZUVycm9yQ29kZXMuTk9UX1NVUFBPUlRfTE9DQUxFX0FTWU5DX0ZVTkNUSU9OXTogJ2Nhbm5vdCBzdXBwb3J0IGFzeW5jIGZ1bmN0aW9uJyxcbiAgICBbQ29yZUVycm9yQ29kZXMuTk9UX1NVUFBPUlRfTE9DQUxFX1RZUEVdOiAnY2Fubm90IHN1cHBvcnQgbG9jYWxlIHR5cGUnXG59O1xuXG4vKiogQGludGVybmFsICovXG5mdW5jdGlvbiBnZXRMb2NhbGUoY29udGV4dCwgb3B0aW9ucykge1xuICAgIHJldHVybiBvcHRpb25zLmxvY2FsZSAhPSBudWxsXG4gICAgICAgID8gcmVzb2x2ZUxvY2FsZShvcHRpb25zLmxvY2FsZSlcbiAgICAgICAgOiByZXNvbHZlTG9jYWxlKGNvbnRleHQubG9jYWxlKTtcbn1cbmxldCBfcmVzb2x2ZUxvY2FsZTtcbi8qKiBAaW50ZXJuYWwgKi9cbmZ1bmN0aW9uIHJlc29sdmVMb2NhbGUobG9jYWxlKSB7XG4gICAgaWYgKGlzU3RyaW5nKGxvY2FsZSkpIHtcbiAgICAgICAgcmV0dXJuIGxvY2FsZTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGlmIChpc0Z1bmN0aW9uKGxvY2FsZSkpIHtcbiAgICAgICAgICAgIGlmIChsb2NhbGUucmVzb2x2ZWRPbmNlICYmIF9yZXNvbHZlTG9jYWxlICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX3Jlc29sdmVMb2NhbGU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChsb2NhbGUuY29uc3RydWN0b3IubmFtZSA9PT0gJ0Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlc29sdmUgPSBsb2NhbGUoKTtcbiAgICAgICAgICAgICAgICBpZiAoaXNQcm9taXNlKHJlc29sdmUpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IGNyZWF0ZUNvcmVFcnJvcihDb3JlRXJyb3JDb2Rlcy5OT1RfU1VQUE9SVF9MT0NBTEVfUFJPTUlTRV9WQUxVRSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiAoX3Jlc29sdmVMb2NhbGUgPSByZXNvbHZlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHRocm93IGNyZWF0ZUNvcmVFcnJvcihDb3JlRXJyb3JDb2Rlcy5OT1RfU1VQUE9SVF9MT0NBTEVfQVNZTkNfRlVOQ1RJT04pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdGhyb3cgY3JlYXRlQ29yZUVycm9yKENvcmVFcnJvckNvZGVzLk5PVF9TVVBQT1JUX0xPQ0FMRV9UWVBFKTtcbiAgICAgICAgfVxuICAgIH1cbn1cbi8qKlxuICogRmFsbGJhY2sgd2l0aCBzaW1wbGUgaW1wbGVtZW5hdGlvblxuICpcbiAqIEByZW1hcmtzXG4gKiBBIGZhbGxiYWNrIGxvY2FsZSBmdW5jdGlvbiBpbXBsZW1lbnRlZCB3aXRoIGEgc2ltcGxlIGZhbGxiYWNrIGFsZ29yaXRobS5cbiAqXG4gKiBCYXNpY2FsbHksIGl0IHJldHVybnMgdGhlIHZhbHVlIGFzIHNwZWNpZmllZCBpbiB0aGUgYGZhbGxiYWNrTG9jYWxlYCBwcm9wcywgYW5kIGlzIHByb2Nlc3NlZCB3aXRoIHRoZSBmYWxsYmFjayBpbnNpZGUgaW50bGlmeS5cbiAqXG4gKiBAcGFyYW0gY3R4IC0gQSB7QGxpbmsgQ29yZUNvbnRleHQgfCBjb250ZXh0fVxuICogQHBhcmFtIGZhbGxiYWNrIC0gQSB7QGxpbmsgRmFsbGJhY2tMb2NhbGUgfCBmYWxsYmFjayBsb2NhbGV9XG4gKiBAcGFyYW0gc3RhcnQgLSBBIHN0YXJ0aW5nIHtAbGluayBMb2NhbGUgfCBsb2NhbGV9XG4gKlxuICogQHJldHVybnMgRmFsbGJhY2sgbG9jYWxlc1xuICpcbiAqIEBWdWVJMThuR2VuZXJhbFxuICovXG5mdW5jdGlvbiBmYWxsYmFja1dpdGhTaW1wbGUoY3R4LCBmYWxsYmFjaywgc3RhcnQpIHtcbiAgICAvLyBwcmV0dGllci1pZ25vcmVcbiAgICByZXR1cm4gWy4uLm5ldyBTZXQoW1xuICAgICAgICAgICAgc3RhcnQsXG4gICAgICAgICAgICAuLi4oaXNBcnJheShmYWxsYmFjaylcbiAgICAgICAgICAgICAgICA/IGZhbGxiYWNrXG4gICAgICAgICAgICAgICAgOiBpc09iamVjdChmYWxsYmFjaylcbiAgICAgICAgICAgICAgICAgICAgPyBPYmplY3Qua2V5cyhmYWxsYmFjaylcbiAgICAgICAgICAgICAgICAgICAgOiBpc1N0cmluZyhmYWxsYmFjaylcbiAgICAgICAgICAgICAgICAgICAgICAgID8gW2ZhbGxiYWNrXVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBbc3RhcnRdKVxuICAgICAgICBdKV07XG59XG4vKipcbiAqIEZhbGxiYWNrIHdpdGggbG9jYWxlIGNoYWluXG4gKlxuICogQHJlbWFya3NcbiAqIEEgZmFsbGJhY2sgbG9jYWxlIGZ1bmN0aW9uIGltcGxlbWVudGVkIHdpdGggYSBmYWxsYmFjayBjaGFpbiBhbGdvcml0aG0uIEl0J3MgdXNlZCBpbiBWdWVJMThuIGFzIGRlZmF1bHQuXG4gKlxuICogQHBhcmFtIGN0eCAtIEEge0BsaW5rIENvcmVDb250ZXh0IHwgY29udGV4dH1cbiAqIEBwYXJhbSBmYWxsYmFjayAtIEEge0BsaW5rIEZhbGxiYWNrTG9jYWxlIHwgZmFsbGJhY2sgbG9jYWxlfVxuICogQHBhcmFtIHN0YXJ0IC0gQSBzdGFydGluZyB7QGxpbmsgTG9jYWxlIHwgbG9jYWxlfVxuICpcbiAqIEByZXR1cm5zIEZhbGxiYWNrIGxvY2FsZXNcbiAqXG4gKiBAVnVlSTE4blNlZSBbRmFsbGJhY2tpbmddKC4uL2d1aWRlL2Vzc2VudGlhbHMvZmFsbGJhY2spXG4gKlxuICogQFZ1ZUkxOG5HZW5lcmFsXG4gKi9cbmZ1bmN0aW9uIGZhbGxiYWNrV2l0aExvY2FsZUNoYWluKGN0eCwgZmFsbGJhY2ssIHN0YXJ0KSB7XG4gICAgY29uc3Qgc3RhcnRMb2NhbGUgPSBpc1N0cmluZyhzdGFydCkgPyBzdGFydCA6IERFRkFVTFRfTE9DQUxFO1xuICAgIGNvbnN0IGNvbnRleHQgPSBjdHg7XG4gICAgaWYgKCFjb250ZXh0Ll9fbG9jYWxlQ2hhaW5DYWNoZSkge1xuICAgICAgICBjb250ZXh0Ll9fbG9jYWxlQ2hhaW5DYWNoZSA9IG5ldyBNYXAoKTtcbiAgICB9XG4gICAgbGV0IGNoYWluID0gY29udGV4dC5fX2xvY2FsZUNoYWluQ2FjaGUuZ2V0KHN0YXJ0TG9jYWxlKTtcbiAgICBpZiAoIWNoYWluKSB7XG4gICAgICAgIGNoYWluID0gW107XG4gICAgICAgIC8vIGZpcnN0IGJsb2NrIGRlZmluZWQgYnkgc3RhcnRcbiAgICAgICAgbGV0IGJsb2NrID0gW3N0YXJ0XTtcbiAgICAgICAgLy8gd2hpbGUgYW55IGludGVydmVuaW5nIGJsb2NrIGZvdW5kXG4gICAgICAgIHdoaWxlIChpc0FycmF5KGJsb2NrKSkge1xuICAgICAgICAgICAgYmxvY2sgPSBhcHBlbmRCbG9ja1RvQ2hhaW4oY2hhaW4sIGJsb2NrLCBmYWxsYmFjayk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgICAgIC8vIGxhc3QgYmxvY2sgZGVmaW5lZCBieSBkZWZhdWx0XG4gICAgICAgIGNvbnN0IGRlZmF1bHRzID0gaXNBcnJheShmYWxsYmFjaykgfHwgIWlzUGxhaW5PYmplY3QoZmFsbGJhY2spXG4gICAgICAgICAgICA/IGZhbGxiYWNrXG4gICAgICAgICAgICA6IGZhbGxiYWNrWydkZWZhdWx0J11cbiAgICAgICAgICAgICAgICA/IGZhbGxiYWNrWydkZWZhdWx0J11cbiAgICAgICAgICAgICAgICA6IG51bGw7XG4gICAgICAgIC8vIGNvbnZlcnQgZGVmYXVsdHMgdG8gYXJyYXlcbiAgICAgICAgYmxvY2sgPSBpc1N0cmluZyhkZWZhdWx0cykgPyBbZGVmYXVsdHNdIDogZGVmYXVsdHM7XG4gICAgICAgIGlmIChpc0FycmF5KGJsb2NrKSkge1xuICAgICAgICAgICAgYXBwZW5kQmxvY2tUb0NoYWluKGNoYWluLCBibG9jaywgZmFsc2UpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnRleHQuX19sb2NhbGVDaGFpbkNhY2hlLnNldChzdGFydExvY2FsZSwgY2hhaW4pO1xuICAgIH1cbiAgICByZXR1cm4gY2hhaW47XG59XG5mdW5jdGlvbiBhcHBlbmRCbG9ja1RvQ2hhaW4oY2hhaW4sIGJsb2NrLCBibG9ja3MpIHtcbiAgICBsZXQgZm9sbG93ID0gdHJ1ZTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGJsb2NrLmxlbmd0aCAmJiBpc0Jvb2xlYW4oZm9sbG93KTsgaSsrKSB7XG4gICAgICAgIGNvbnN0IGxvY2FsZSA9IGJsb2NrW2ldO1xuICAgICAgICBpZiAoaXNTdHJpbmcobG9jYWxlKSkge1xuICAgICAgICAgICAgZm9sbG93ID0gYXBwZW5kTG9jYWxlVG9DaGFpbihjaGFpbiwgYmxvY2tbaV0sIGJsb2Nrcyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZvbGxvdztcbn1cbmZ1bmN0aW9uIGFwcGVuZExvY2FsZVRvQ2hhaW4oY2hhaW4sIGxvY2FsZSwgYmxvY2tzKSB7XG4gICAgbGV0IGZvbGxvdztcbiAgICBjb25zdCB0b2tlbnMgPSBsb2NhbGUuc3BsaXQoJy0nKTtcbiAgICBkbyB7XG4gICAgICAgIGNvbnN0IHRhcmdldCA9IHRva2Vucy5qb2luKCctJyk7XG4gICAgICAgIGZvbGxvdyA9IGFwcGVuZEl0ZW1Ub0NoYWluKGNoYWluLCB0YXJnZXQsIGJsb2Nrcyk7XG4gICAgICAgIHRva2Vucy5zcGxpY2UoLTEsIDEpO1xuICAgIH0gd2hpbGUgKHRva2Vucy5sZW5ndGggJiYgZm9sbG93ID09PSB0cnVlKTtcbiAgICByZXR1cm4gZm9sbG93O1xufVxuZnVuY3Rpb24gYXBwZW5kSXRlbVRvQ2hhaW4oY2hhaW4sIHRhcmdldCwgYmxvY2tzKSB7XG4gICAgbGV0IGZvbGxvdyA9IGZhbHNlO1xuICAgIGlmICghY2hhaW4uaW5jbHVkZXModGFyZ2V0KSkge1xuICAgICAgICBmb2xsb3cgPSB0cnVlO1xuICAgICAgICBpZiAodGFyZ2V0KSB7XG4gICAgICAgICAgICBmb2xsb3cgPSB0YXJnZXRbdGFyZ2V0Lmxlbmd0aCAtIDFdICE9PSAnISc7XG4gICAgICAgICAgICBjb25zdCBsb2NhbGUgPSB0YXJnZXQucmVwbGFjZSgvIS9nLCAnJyk7XG4gICAgICAgICAgICBjaGFpbi5wdXNoKGxvY2FsZSk7XG4gICAgICAgICAgICBpZiAoKGlzQXJyYXkoYmxvY2tzKSB8fCBpc1BsYWluT2JqZWN0KGJsb2NrcykpICYmXG4gICAgICAgICAgICAgICAgYmxvY2tzW2xvY2FsZV0gLy8gZXNsaW50LWRpc2FibGUtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgICAgICAgICAgICAgIGZvbGxvdyA9IGJsb2Nrc1tsb2NhbGVdO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmb2xsb3c7XG59XG5cbmNvbnN0IHBhdGhTdGF0ZU1hY2hpbmUgPSBbXTtcbnBhdGhTdGF0ZU1hY2hpbmVbMCAvKiBTdGF0ZXMuQkVGT1JFX1BBVEggKi9dID0ge1xuICAgIFtcIndcIiAvKiBQYXRoQ2hhclR5cGVzLldPUktTUEFDRSAqL106IFswIC8qIFN0YXRlcy5CRUZPUkVfUEFUSCAqL10sXG4gICAgW1wiaVwiIC8qIFBhdGhDaGFyVHlwZXMuSURFTlQgKi9dOiBbMyAvKiBTdGF0ZXMuSU5fSURFTlQgKi8sIDAgLyogQWN0aW9ucy5BUFBFTkQgKi9dLFxuICAgIFtcIltcIiAvKiBQYXRoQ2hhclR5cGVzLkxFRlRfQlJBQ0tFVCAqL106IFs0IC8qIFN0YXRlcy5JTl9TVUJfUEFUSCAqL10sXG4gICAgW1wib1wiIC8qIFBhdGhDaGFyVHlwZXMuRU5EX09GX0ZBSUwgKi9dOiBbNyAvKiBTdGF0ZXMuQUZURVJfUEFUSCAqL11cbn07XG5wYXRoU3RhdGVNYWNoaW5lWzEgLyogU3RhdGVzLklOX1BBVEggKi9dID0ge1xuICAgIFtcIndcIiAvKiBQYXRoQ2hhclR5cGVzLldPUktTUEFDRSAqL106IFsxIC8qIFN0YXRlcy5JTl9QQVRIICovXSxcbiAgICBbXCIuXCIgLyogUGF0aENoYXJUeXBlcy5ET1QgKi9dOiBbMiAvKiBTdGF0ZXMuQkVGT1JFX0lERU5UICovXSxcbiAgICBbXCJbXCIgLyogUGF0aENoYXJUeXBlcy5MRUZUX0JSQUNLRVQgKi9dOiBbNCAvKiBTdGF0ZXMuSU5fU1VCX1BBVEggKi9dLFxuICAgIFtcIm9cIiAvKiBQYXRoQ2hhclR5cGVzLkVORF9PRl9GQUlMICovXTogWzcgLyogU3RhdGVzLkFGVEVSX1BBVEggKi9dXG59O1xucGF0aFN0YXRlTWFjaGluZVsyIC8qIFN0YXRlcy5CRUZPUkVfSURFTlQgKi9dID0ge1xuICAgIFtcIndcIiAvKiBQYXRoQ2hhclR5cGVzLldPUktTUEFDRSAqL106IFsyIC8qIFN0YXRlcy5CRUZPUkVfSURFTlQgKi9dLFxuICAgIFtcImlcIiAvKiBQYXRoQ2hhclR5cGVzLklERU5UICovXTogWzMgLyogU3RhdGVzLklOX0lERU5UICovLCAwIC8qIEFjdGlvbnMuQVBQRU5EICovXSxcbiAgICBbXCIwXCIgLyogUGF0aENoYXJUeXBlcy5aRVJPICovXTogWzMgLyogU3RhdGVzLklOX0lERU5UICovLCAwIC8qIEFjdGlvbnMuQVBQRU5EICovXVxufTtcbnBhdGhTdGF0ZU1hY2hpbmVbMyAvKiBTdGF0ZXMuSU5fSURFTlQgKi9dID0ge1xuICAgIFtcImlcIiAvKiBQYXRoQ2hhclR5cGVzLklERU5UICovXTogWzMgLyogU3RhdGVzLklOX0lERU5UICovLCAwIC8qIEFjdGlvbnMuQVBQRU5EICovXSxcbiAgICBbXCIwXCIgLyogUGF0aENoYXJUeXBlcy5aRVJPICovXTogWzMgLyogU3RhdGVzLklOX0lERU5UICovLCAwIC8qIEFjdGlvbnMuQVBQRU5EICovXSxcbiAgICBbXCJ3XCIgLyogUGF0aENoYXJUeXBlcy5XT1JLU1BBQ0UgKi9dOiBbMSAvKiBTdGF0ZXMuSU5fUEFUSCAqLywgMSAvKiBBY3Rpb25zLlBVU0ggKi9dLFxuICAgIFtcIi5cIiAvKiBQYXRoQ2hhclR5cGVzLkRPVCAqL106IFsyIC8qIFN0YXRlcy5CRUZPUkVfSURFTlQgKi8sIDEgLyogQWN0aW9ucy5QVVNIICovXSxcbiAgICBbXCJbXCIgLyogUGF0aENoYXJUeXBlcy5MRUZUX0JSQUNLRVQgKi9dOiBbNCAvKiBTdGF0ZXMuSU5fU1VCX1BBVEggKi8sIDEgLyogQWN0aW9ucy5QVVNIICovXSxcbiAgICBbXCJvXCIgLyogUGF0aENoYXJUeXBlcy5FTkRfT0ZfRkFJTCAqL106IFs3IC8qIFN0YXRlcy5BRlRFUl9QQVRIICovLCAxIC8qIEFjdGlvbnMuUFVTSCAqL11cbn07XG5wYXRoU3RhdGVNYWNoaW5lWzQgLyogU3RhdGVzLklOX1NVQl9QQVRIICovXSA9IHtcbiAgICBbXCInXCIgLyogUGF0aENoYXJUeXBlcy5TSU5HTEVfUVVPVEUgKi9dOiBbNSAvKiBTdGF0ZXMuSU5fU0lOR0xFX1FVT1RFICovLCAwIC8qIEFjdGlvbnMuQVBQRU5EICovXSxcbiAgICBbXCJcXFwiXCIgLyogUGF0aENoYXJUeXBlcy5ET1VCTEVfUVVPVEUgKi9dOiBbNiAvKiBTdGF0ZXMuSU5fRE9VQkxFX1FVT1RFICovLCAwIC8qIEFjdGlvbnMuQVBQRU5EICovXSxcbiAgICBbXCJbXCIgLyogUGF0aENoYXJUeXBlcy5MRUZUX0JSQUNLRVQgKi9dOiBbXG4gICAgICAgIDQgLyogU3RhdGVzLklOX1NVQl9QQVRIICovLFxuICAgICAgICAyIC8qIEFjdGlvbnMuSU5DX1NVQl9QQVRIX0RFUFRIICovXG4gICAgXSxcbiAgICBbXCJdXCIgLyogUGF0aENoYXJUeXBlcy5SSUdIVF9CUkFDS0VUICovXTogWzEgLyogU3RhdGVzLklOX1BBVEggKi8sIDMgLyogQWN0aW9ucy5QVVNIX1NVQl9QQVRIICovXSxcbiAgICBbXCJvXCIgLyogUGF0aENoYXJUeXBlcy5FTkRfT0ZfRkFJTCAqL106IDggLyogU3RhdGVzLkVSUk9SICovLFxuICAgIFtcImxcIiAvKiBQYXRoQ2hhclR5cGVzLkVMU0UgKi9dOiBbNCAvKiBTdGF0ZXMuSU5fU1VCX1BBVEggKi8sIDAgLyogQWN0aW9ucy5BUFBFTkQgKi9dXG59O1xucGF0aFN0YXRlTWFjaGluZVs1IC8qIFN0YXRlcy5JTl9TSU5HTEVfUVVPVEUgKi9dID0ge1xuICAgIFtcIidcIiAvKiBQYXRoQ2hhclR5cGVzLlNJTkdMRV9RVU9URSAqL106IFs0IC8qIFN0YXRlcy5JTl9TVUJfUEFUSCAqLywgMCAvKiBBY3Rpb25zLkFQUEVORCAqL10sXG4gICAgW1wib1wiIC8qIFBhdGhDaGFyVHlwZXMuRU5EX09GX0ZBSUwgKi9dOiA4IC8qIFN0YXRlcy5FUlJPUiAqLyxcbiAgICBbXCJsXCIgLyogUGF0aENoYXJUeXBlcy5FTFNFICovXTogWzUgLyogU3RhdGVzLklOX1NJTkdMRV9RVU9URSAqLywgMCAvKiBBY3Rpb25zLkFQUEVORCAqL11cbn07XG5wYXRoU3RhdGVNYWNoaW5lWzYgLyogU3RhdGVzLklOX0RPVUJMRV9RVU9URSAqL10gPSB7XG4gICAgW1wiXFxcIlwiIC8qIFBhdGhDaGFyVHlwZXMuRE9VQkxFX1FVT1RFICovXTogWzQgLyogU3RhdGVzLklOX1NVQl9QQVRIICovLCAwIC8qIEFjdGlvbnMuQVBQRU5EICovXSxcbiAgICBbXCJvXCIgLyogUGF0aENoYXJUeXBlcy5FTkRfT0ZfRkFJTCAqL106IDggLyogU3RhdGVzLkVSUk9SICovLFxuICAgIFtcImxcIiAvKiBQYXRoQ2hhclR5cGVzLkVMU0UgKi9dOiBbNiAvKiBTdGF0ZXMuSU5fRE9VQkxFX1FVT1RFICovLCAwIC8qIEFjdGlvbnMuQVBQRU5EICovXVxufTtcbi8qKlxuICogQ2hlY2sgaWYgYW4gZXhwcmVzc2lvbiBpcyBhIGxpdGVyYWwgdmFsdWUuXG4gKi9cbmNvbnN0IGxpdGVyYWxWYWx1ZVJFID0gL15cXHM/KD86dHJ1ZXxmYWxzZXwtP1tcXGQuXSt8J1teJ10qJ3xcIlteXCJdKlwiKVxccz8kLztcbmZ1bmN0aW9uIGlzTGl0ZXJhbChleHApIHtcbiAgICByZXR1cm4gbGl0ZXJhbFZhbHVlUkUudGVzdChleHApO1xufVxuLyoqXG4gKiBTdHJpcCBxdW90ZXMgZnJvbSBhIHN0cmluZ1xuICovXG5mdW5jdGlvbiBzdHJpcFF1b3RlcyhzdHIpIHtcbiAgICBjb25zdCBhID0gc3RyLmNoYXJDb2RlQXQoMCk7XG4gICAgY29uc3QgYiA9IHN0ci5jaGFyQ29kZUF0KHN0ci5sZW5ndGggLSAxKTtcbiAgICByZXR1cm4gYSA9PT0gYiAmJiAoYSA9PT0gMHgyMiB8fCBhID09PSAweDI3KSA/IHN0ci5zbGljZSgxLCAtMSkgOiBzdHI7XG59XG4vKipcbiAqIERldGVybWluZSB0aGUgdHlwZSBvZiBhIGNoYXJhY3RlciBpbiBhIGtleXBhdGguXG4gKi9cbmZ1bmN0aW9uIGdldFBhdGhDaGFyVHlwZShjaCkge1xuICAgIGlmIChjaCA9PT0gdW5kZWZpbmVkIHx8IGNoID09PSBudWxsKSB7XG4gICAgICAgIHJldHVybiBcIm9cIiAvKiBQYXRoQ2hhclR5cGVzLkVORF9PRl9GQUlMICovO1xuICAgIH1cbiAgICBjb25zdCBjb2RlID0gY2guY2hhckNvZGVBdCgwKTtcbiAgICBzd2l0Y2ggKGNvZGUpIHtcbiAgICAgICAgY2FzZSAweDViOiAvLyBbXG4gICAgICAgIGNhc2UgMHg1ZDogLy8gXVxuICAgICAgICBjYXNlIDB4MmU6IC8vIC5cbiAgICAgICAgY2FzZSAweDIyOiAvLyBcIlxuICAgICAgICBjYXNlIDB4Mjc6IC8vICdcbiAgICAgICAgICAgIHJldHVybiBjaDtcbiAgICAgICAgY2FzZSAweDVmOiAvLyBfXG4gICAgICAgIGNhc2UgMHgyNDogLy8gJFxuICAgICAgICBjYXNlIDB4MmQ6IC8vIC1cbiAgICAgICAgICAgIHJldHVybiBcImlcIiAvKiBQYXRoQ2hhclR5cGVzLklERU5UICovO1xuICAgICAgICBjYXNlIDB4MDk6IC8vIFRhYiAoSFQpXG4gICAgICAgIGNhc2UgMHgwYTogLy8gTmV3bGluZSAoTEYpXG4gICAgICAgIGNhc2UgMHgwZDogLy8gUmV0dXJuIChDUilcbiAgICAgICAgY2FzZSAweGEwOiAvLyBOby1icmVhayBzcGFjZSAoTkJTUClcbiAgICAgICAgY2FzZSAweGZlZmY6IC8vIEJ5dGUgT3JkZXIgTWFyayAoQk9NKVxuICAgICAgICBjYXNlIDB4MjAyODogLy8gTGluZSBTZXBhcmF0b3IgKExTKVxuICAgICAgICBjYXNlIDB4MjAyOTogLy8gUGFyYWdyYXBoIFNlcGFyYXRvciAoUFMpXG4gICAgICAgICAgICByZXR1cm4gXCJ3XCIgLyogUGF0aENoYXJUeXBlcy5XT1JLU1BBQ0UgKi87XG4gICAgfVxuICAgIHJldHVybiBcImlcIiAvKiBQYXRoQ2hhclR5cGVzLklERU5UICovO1xufVxuLyoqXG4gKiBGb3JtYXQgYSBzdWJQYXRoLCByZXR1cm4gaXRzIHBsYWluIGZvcm0gaWYgaXQgaXNcbiAqIGEgbGl0ZXJhbCBzdHJpbmcgb3IgbnVtYmVyLiBPdGhlcndpc2UgcHJlcGVuZCB0aGVcbiAqIGR5bmFtaWMgaW5kaWNhdG9yICgqKS5cbiAqL1xuZnVuY3Rpb24gZm9ybWF0U3ViUGF0aChwYXRoKSB7XG4gICAgY29uc3QgdHJpbW1lZCA9IHBhdGgudHJpbSgpO1xuICAgIC8vIGludmFsaWQgbGVhZGluZyAwXG4gICAgaWYgKHBhdGguY2hhckF0KDApID09PSAnMCcgJiYgaXNOYU4ocGFyc2VJbnQocGF0aCkpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuIGlzTGl0ZXJhbCh0cmltbWVkKVxuICAgICAgICA/IHN0cmlwUXVvdGVzKHRyaW1tZWQpXG4gICAgICAgIDogXCIqXCIgLyogUGF0aENoYXJUeXBlcy5BU1RBUklTSyAqLyArIHRyaW1tZWQ7XG59XG4vKipcbiAqIFBhcnNlIGEgc3RyaW5nIHBhdGggaW50byBhbiBhcnJheSBvZiBzZWdtZW50c1xuICovXG5mdW5jdGlvbiBwYXJzZShwYXRoKSB7XG4gICAgY29uc3Qga2V5cyA9IFtdO1xuICAgIGxldCBpbmRleCA9IC0xO1xuICAgIGxldCBtb2RlID0gMCAvKiBTdGF0ZXMuQkVGT1JFX1BBVEggKi87XG4gICAgbGV0IHN1YlBhdGhEZXB0aCA9IDA7XG4gICAgbGV0IGM7XG4gICAgbGV0IGtleTsgLy8gZXNsaW50LWRpc2FibGUtbGluZVxuICAgIGxldCBuZXdDaGFyO1xuICAgIGxldCB0eXBlO1xuICAgIGxldCB0cmFuc2l0aW9uO1xuICAgIGxldCBhY3Rpb247XG4gICAgbGV0IHR5cGVNYXA7XG4gICAgY29uc3QgYWN0aW9ucyA9IFtdO1xuICAgIGFjdGlvbnNbMCAvKiBBY3Rpb25zLkFQUEVORCAqL10gPSAoKSA9PiB7XG4gICAgICAgIGlmIChrZXkgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAga2V5ID0gbmV3Q2hhcjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGtleSArPSBuZXdDaGFyO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBhY3Rpb25zWzEgLyogQWN0aW9ucy5QVVNIICovXSA9ICgpID0+IHtcbiAgICAgICAgaWYgKGtleSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBrZXlzLnB1c2goa2V5KTtcbiAgICAgICAgICAgIGtleSA9IHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgIH07XG4gICAgYWN0aW9uc1syIC8qIEFjdGlvbnMuSU5DX1NVQl9QQVRIX0RFUFRIICovXSA9ICgpID0+IHtcbiAgICAgICAgYWN0aW9uc1swIC8qIEFjdGlvbnMuQVBQRU5EICovXSgpO1xuICAgICAgICBzdWJQYXRoRGVwdGgrKztcbiAgICB9O1xuICAgIGFjdGlvbnNbMyAvKiBBY3Rpb25zLlBVU0hfU1VCX1BBVEggKi9dID0gKCkgPT4ge1xuICAgICAgICBpZiAoc3ViUGF0aERlcHRoID4gMCkge1xuICAgICAgICAgICAgc3ViUGF0aERlcHRoLS07XG4gICAgICAgICAgICBtb2RlID0gNCAvKiBTdGF0ZXMuSU5fU1VCX1BBVEggKi87XG4gICAgICAgICAgICBhY3Rpb25zWzAgLyogQWN0aW9ucy5BUFBFTkQgKi9dKCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBzdWJQYXRoRGVwdGggPSAwO1xuICAgICAgICAgICAgaWYgKGtleSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAga2V5ID0gZm9ybWF0U3ViUGF0aChrZXkpO1xuICAgICAgICAgICAgaWYgKGtleSA9PT0gZmFsc2UpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBhY3Rpb25zWzEgLyogQWN0aW9ucy5QVVNIICovXSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBmdW5jdGlvbiBtYXliZVVuZXNjYXBlUXVvdGUoKSB7XG4gICAgICAgIGNvbnN0IG5leHRDaGFyID0gcGF0aFtpbmRleCArIDFdO1xuICAgICAgICBpZiAoKG1vZGUgPT09IDUgLyogU3RhdGVzLklOX1NJTkdMRV9RVU9URSAqLyAmJlxuICAgICAgICAgICAgbmV4dENoYXIgPT09IFwiJ1wiIC8qIFBhdGhDaGFyVHlwZXMuU0lOR0xFX1FVT1RFICovKSB8fFxuICAgICAgICAgICAgKG1vZGUgPT09IDYgLyogU3RhdGVzLklOX0RPVUJMRV9RVU9URSAqLyAmJlxuICAgICAgICAgICAgICAgIG5leHRDaGFyID09PSBcIlxcXCJcIiAvKiBQYXRoQ2hhclR5cGVzLkRPVUJMRV9RVU9URSAqLykpIHtcbiAgICAgICAgICAgIGluZGV4Kys7XG4gICAgICAgICAgICBuZXdDaGFyID0gJ1xcXFwnICsgbmV4dENoYXI7XG4gICAgICAgICAgICBhY3Rpb25zWzAgLyogQWN0aW9ucy5BUFBFTkQgKi9dKCk7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICB3aGlsZSAobW9kZSAhPT0gbnVsbCkge1xuICAgICAgICBpbmRleCsrO1xuICAgICAgICBjID0gcGF0aFtpbmRleF07XG4gICAgICAgIGlmIChjID09PSAnXFxcXCcgJiYgbWF5YmVVbmVzY2FwZVF1b3RlKCkpIHtcbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIHR5cGUgPSBnZXRQYXRoQ2hhclR5cGUoYyk7XG4gICAgICAgIHR5cGVNYXAgPSBwYXRoU3RhdGVNYWNoaW5lW21vZGVdO1xuICAgICAgICB0cmFuc2l0aW9uID0gdHlwZU1hcFt0eXBlXSB8fCB0eXBlTWFwW1wibFwiIC8qIFBhdGhDaGFyVHlwZXMuRUxTRSAqL10gfHwgOCAvKiBTdGF0ZXMuRVJST1IgKi87XG4gICAgICAgIC8vIGNoZWNrIHBhcnNlIGVycm9yXG4gICAgICAgIGlmICh0cmFuc2l0aW9uID09PSA4IC8qIFN0YXRlcy5FUlJPUiAqLykge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIG1vZGUgPSB0cmFuc2l0aW9uWzBdO1xuICAgICAgICBpZiAodHJhbnNpdGlvblsxXSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBhY3Rpb24gPSBhY3Rpb25zW3RyYW5zaXRpb25bMV1dO1xuICAgICAgICAgICAgaWYgKGFjdGlvbikge1xuICAgICAgICAgICAgICAgIG5ld0NoYXIgPSBjO1xuICAgICAgICAgICAgICAgIGlmIChhY3Rpb24oKSA9PT0gZmFsc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBjaGVjayBwYXJzZSBmaW5pc2hcbiAgICAgICAgaWYgKG1vZGUgPT09IDcgLyogU3RhdGVzLkFGVEVSX1BBVEggKi8pIHtcbiAgICAgICAgICAgIHJldHVybiBrZXlzO1xuICAgICAgICB9XG4gICAgfVxufVxuLy8gcGF0aCB0b2tlbiBjYWNoZVxuY29uc3QgY2FjaGUgPSBuZXcgTWFwKCk7XG4vKipcbiAqIGtleS12YWx1ZSBtZXNzYWdlIHJlc29sdmVyXG4gKlxuICogQHJlbWFya3NcbiAqIFJlc29sdmVzIG1lc3NhZ2VzIHdpdGggdGhlIGtleS12YWx1ZSBzdHJ1Y3R1cmUuIE5vdGUgdGhhdCBtZXNzYWdlcyB3aXRoIGEgaGllcmFyY2hpY2FsIHN0cnVjdHVyZSBzdWNoIGFzIG9iamVjdHMgY2Fubm90IGJlIHJlc29sdmVkXG4gKlxuICogQHBhcmFtIG9iaiAtIEEgdGFyZ2V0IG9iamVjdCB0byBiZSByZXNvbHZlZCB3aXRoIHBhdGhcbiAqIEBwYXJhbSBwYXRoIC0gQSB7QGxpbmsgUGF0aCB8IHBhdGh9IHRvIHJlc29sdmUgdGhlIHZhbHVlIG9mIG1lc3NhZ2VcbiAqXG4gKiBAcmV0dXJucyBBIHJlc29sdmVkIHtAbGluayBQYXRoVmFsdWUgfCBwYXRoIHZhbHVlfVxuICpcbiAqIEBWdWVJMThuR2VuZXJhbFxuICovXG5mdW5jdGlvbiByZXNvbHZlV2l0aEtleVZhbHVlKG9iaiwgcGF0aCkge1xuICAgIHJldHVybiBpc09iamVjdChvYmopID8gb2JqW3BhdGhdIDogbnVsbDtcbn1cbi8qKlxuICogbWVzc2FnZSByZXNvbHZlclxuICpcbiAqIEByZW1hcmtzXG4gKiBSZXNvbHZlcyBtZXNzYWdlcy4gbWVzc2FnZXMgd2l0aCBhIGhpZXJhcmNoaWNhbCBzdHJ1Y3R1cmUgc3VjaCBhcyBvYmplY3RzIGNhbiBiZSByZXNvbHZlZC4gVGhpcyByZXNvbHZlciBpcyB1c2VkIGluIFZ1ZUkxOG4gYXMgZGVmYXVsdC5cbiAqXG4gKiBAcGFyYW0gb2JqIC0gQSB0YXJnZXQgb2JqZWN0IHRvIGJlIHJlc29sdmVkIHdpdGggcGF0aFxuICogQHBhcmFtIHBhdGggLSBBIHtAbGluayBQYXRoIHwgcGF0aH0gdG8gcmVzb2x2ZSB0aGUgdmFsdWUgb2YgbWVzc2FnZVxuICpcbiAqIEByZXR1cm5zIEEgcmVzb2x2ZWQge0BsaW5rIFBhdGhWYWx1ZSB8IHBhdGggdmFsdWV9XG4gKlxuICogQFZ1ZUkxOG5HZW5lcmFsXG4gKi9cbmZ1bmN0aW9uIHJlc29sdmVWYWx1ZShvYmosIHBhdGgpIHtcbiAgICAvLyBjaGVjayBvYmplY3RcbiAgICBpZiAoIWlzT2JqZWN0KG9iaikpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIC8vIHBhcnNlIHBhdGhcbiAgICBsZXQgaGl0ID0gY2FjaGUuZ2V0KHBhdGgpO1xuICAgIGlmICghaGl0KSB7XG4gICAgICAgIGhpdCA9IHBhcnNlKHBhdGgpO1xuICAgICAgICBpZiAoaGl0KSB7XG4gICAgICAgICAgICBjYWNoZS5zZXQocGF0aCwgaGl0KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvLyBjaGVjayBoaXRcbiAgICBpZiAoIWhpdCkge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgLy8gcmVzb2x2ZSBwYXRoIHZhbHVlXG4gICAgY29uc3QgbGVuID0gaGl0Lmxlbmd0aDtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueSAtLSBmb3IgZ2VuZXJpYyBvYmplY3RcbiAgICBsZXQgbGFzdCA9IG9iajtcbiAgICBsZXQgaSA9IDA7XG4gICAgd2hpbGUgKGkgPCBsZW4pIHtcbiAgICAgICAgY29uc3Qga2V5ID0gaGl0W2ldO1xuICAgICAgICAvKipcbiAgICAgICAgICogTk9URTpcbiAgICAgICAgICogaWYgYGtleWAgaXMgaW50bGlmeSBtZXNzYWdlIGZvcm1hdCBBU1Qgbm9kZSBrZXkgYW5kIGBsYXN0YCBpcyBpbnRsaWZ5IG1lc3NhZ2UgZm9ybWF0IEFTVCwgc2tpcCBpdC5cbiAgICAgICAgICogYmVjYXVzZSB0aGUgQVNUIG5vZGUgaXMgbm90IGEga2V5LXZhbHVlIHN0cnVjdHVyZS5cbiAgICAgICAgICovXG4gICAgICAgIGlmIChBU1RfTk9ERV9QUk9QU19LRVlTLmluY2x1ZGVzKGtleSkgJiYgaXNNZXNzYWdlQVNUKGxhc3QpKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWlzT2JqZWN0KGxhc3QpKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWhhc093bihsYXN0LCBrZXkpKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB2YWwgPSBsYXN0W2tleV07XG4gICAgICAgIGlmICh2YWwgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzRnVuY3Rpb24obGFzdCkpIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIGxhc3QgPSB2YWw7XG4gICAgICAgIGkrKztcbiAgICB9XG4gICAgcmV0dXJuIGxhc3Q7XG59XG5cbmNvbnN0IENvcmVXYXJuQ29kZXMgPSB7XG4gICAgTk9UX0ZPVU5EX0tFWTogMSxcbiAgICBGQUxMQkFDS19UT19UUkFOU0xBVEU6IDIsXG4gICAgQ0FOTk9UX0ZPUk1BVF9OVU1CRVI6IDMsXG4gICAgRkFMTEJBQ0tfVE9fTlVNQkVSX0ZPUk1BVDogNCxcbiAgICBDQU5OT1RfRk9STUFUX0RBVEU6IDUsXG4gICAgRkFMTEJBQ0tfVE9fREFURV9GT1JNQVQ6IDYsXG4gICAgRVhQRVJJTUVOVEFMX0NVU1RPTV9NRVNTQUdFX0NPTVBJTEVSOiA3LFxuICAgIElOVkFMSURfTlVNQkVSX0FSR1VNRU5UOiA4LFxuICAgIElOVkFMSURfREFURV9BUkdVTUVOVDogOVxufTtcbmNvbnN0IENPUkVfV0FSTl9DT0RFU19FWFRFTkRfUE9JTlQgPSAxMDtcbi8qKiBAaW50ZXJuYWwgKi9cbmNvbnN0IHdhcm5NZXNzYWdlcyA9IHtcbiAgICBbQ29yZVdhcm5Db2Rlcy5OT1RfRk9VTkRfS0VZXTogYE5vdCBmb3VuZCAne2tleX0nIGtleSBpbiAne2xvY2FsZX0nIGxvY2FsZSBtZXNzYWdlcy5gLFxuICAgIFtDb3JlV2FybkNvZGVzLkZBTExCQUNLX1RPX1RSQU5TTEFURV06IGBGYWxsIGJhY2sgdG8gdHJhbnNsYXRlICd7a2V5fScga2V5IHdpdGggJ3t0YXJnZXR9JyBsb2NhbGUuYCxcbiAgICBbQ29yZVdhcm5Db2Rlcy5DQU5OT1RfRk9STUFUX05VTUJFUl06IGBDYW5ub3QgZm9ybWF0IGEgbnVtYmVyIHZhbHVlIGR1ZSB0byBub3Qgc3VwcG9ydGVkIEludGwuTnVtYmVyRm9ybWF0LmAsXG4gICAgW0NvcmVXYXJuQ29kZXMuRkFMTEJBQ0tfVE9fTlVNQkVSX0ZPUk1BVF06IGBGYWxsIGJhY2sgdG8gbnVtYmVyIGZvcm1hdCAne2tleX0nIGtleSB3aXRoICd7dGFyZ2V0fScgbG9jYWxlLmAsXG4gICAgW0NvcmVXYXJuQ29kZXMuQ0FOTk9UX0ZPUk1BVF9EQVRFXTogYENhbm5vdCBmb3JtYXQgYSBkYXRlIHZhbHVlIGR1ZSB0byBub3Qgc3VwcG9ydGVkIEludGwuRGF0ZVRpbWVGb3JtYXQuYCxcbiAgICBbQ29yZVdhcm5Db2Rlcy5GQUxMQkFDS19UT19EQVRFX0ZPUk1BVF06IGBGYWxsIGJhY2sgdG8gZGF0ZXRpbWUgZm9ybWF0ICd7a2V5fScga2V5IHdpdGggJ3t0YXJnZXR9JyBsb2NhbGUuYCxcbiAgICBbQ29yZVdhcm5Db2Rlcy5FWFBFUklNRU5UQUxfQ1VTVE9NX01FU1NBR0VfQ09NUElMRVJdOiBgVGhpcyBwcm9qZWN0IGlzIHVzaW5nIEN1c3RvbSBNZXNzYWdlIENvbXBpbGVyLCB3aGljaCBpcyBhbiBleHBlcmltZW50YWwgZmVhdHVyZS4gSXQgbWF5IHJlY2VpdmUgYnJlYWtpbmcgY2hhbmdlcyBvciBiZSByZW1vdmVkIGluIHRoZSBmdXR1cmUuYCxcbiAgICBbQ29yZVdhcm5Db2Rlcy5JTlZBTElEX05VTUJFUl9BUkdVTUVOVF06IGBJbnZhbGlkIGFyZ3VtZW50IGZvciBudW1iZXIgZm9ybWF0dGluZzogZXhwZWN0ZWQgYSBudW1iZXIgYnV0IHJlY2VpdmVkICd7dmFsdWV9Jy5gLFxuICAgIFtDb3JlV2FybkNvZGVzLklOVkFMSURfREFURV9BUkdVTUVOVF06IGBJbnZhbGlkIGFyZ3VtZW50IGZvciBkYXRldGltZSBmb3JtYXR0aW5nOiBleHBlY3RlZCBhIERhdGUsIG51bWJlciwgb3IgSVNPIHN0cmluZyBidXQgcmVjZWl2ZWQgJ3t2YWx1ZX0nLmBcbn07XG5mdW5jdGlvbiBnZXRXYXJuTWVzc2FnZShjb2RlLCAuLi5hcmdzKSB7XG4gICAgcmV0dXJuIGZvcm1hdCQxKHdhcm5NZXNzYWdlc1tjb2RlXSwgLi4uYXJncyk7XG59XG5cbi8qIGVzbGludC1kaXNhYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cbi8qKlxuICogSW50bGlmeSBjb3JlLWJhc2UgdmVyc2lvblxuICogQGludGVybmFsXG4gKi9cbmNvbnN0IFZFUlNJT04gPSAnMTEuNC44JztcbmNvbnN0IE5PVF9SRU9TTFZFRCA9IC0xO1xuY29uc3QgREVGQVVMVF9MT0NBTEUgPSAnZW4tVVMnO1xuY29uc3QgTUlTU0lOR19SRVNPTFZFX1ZBTFVFID0gJyc7XG5jb25zdCBjYXBpdGFsaXplID0gKHN0cikgPT4gYCR7c3RyLmNoYXJBdCgwKS50b0xvY2FsZVVwcGVyQ2FzZSgpfSR7c3RyLnN1YnN0cigxKX1gO1xuZnVuY3Rpb24gZ2V0RGVmYXVsdExpbmtlZE1vZGlmaWVycygpIHtcbiAgICByZXR1cm4ge1xuICAgICAgICB1cHBlcjogKHZhbCwgdHlwZSkgPT4ge1xuICAgICAgICAgICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgICAgICAgICByZXR1cm4gdHlwZSA9PT0gJ3RleHQnICYmIGlzU3RyaW5nKHZhbClcbiAgICAgICAgICAgICAgICA/IHZhbC50b1VwcGVyQ2FzZSgpXG4gICAgICAgICAgICAgICAgOiB0eXBlID09PSAndm5vZGUnICYmIGlzT2JqZWN0KHZhbCkgJiYgJ19fdl9pc1ZOb2RlJyBpbiB2YWxcbiAgICAgICAgICAgICAgICAgICAgPyB2YWwuY2hpbGRyZW4udG9VcHBlckNhc2UoKVxuICAgICAgICAgICAgICAgICAgICA6IHZhbDtcbiAgICAgICAgfSxcbiAgICAgICAgbG93ZXI6ICh2YWwsIHR5cGUpID0+IHtcbiAgICAgICAgICAgIC8vIHByZXR0aWVyLWlnbm9yZVxuICAgICAgICAgICAgcmV0dXJuIHR5cGUgPT09ICd0ZXh0JyAmJiBpc1N0cmluZyh2YWwpXG4gICAgICAgICAgICAgICAgPyB2YWwudG9Mb3dlckNhc2UoKVxuICAgICAgICAgICAgICAgIDogdHlwZSA9PT0gJ3Zub2RlJyAmJiBpc09iamVjdCh2YWwpICYmICdfX3ZfaXNWTm9kZScgaW4gdmFsXG4gICAgICAgICAgICAgICAgICAgID8gdmFsLmNoaWxkcmVuLnRvTG93ZXJDYXNlKClcbiAgICAgICAgICAgICAgICAgICAgOiB2YWw7XG4gICAgICAgIH0sXG4gICAgICAgIGNhcGl0YWxpemU6ICh2YWwsIHR5cGUpID0+IHtcbiAgICAgICAgICAgIC8vIHByZXR0aWVyLWlnbm9yZVxuICAgICAgICAgICAgcmV0dXJuICh0eXBlID09PSAndGV4dCcgJiYgaXNTdHJpbmcodmFsKVxuICAgICAgICAgICAgICAgID8gY2FwaXRhbGl6ZSh2YWwpXG4gICAgICAgICAgICAgICAgOiB0eXBlID09PSAndm5vZGUnICYmIGlzT2JqZWN0KHZhbCkgJiYgJ19fdl9pc1ZOb2RlJyBpbiB2YWxcbiAgICAgICAgICAgICAgICAgICAgPyBjYXBpdGFsaXplKHZhbC5jaGlsZHJlbilcbiAgICAgICAgICAgICAgICAgICAgOiB2YWwpO1xuICAgICAgICB9XG4gICAgfTtcbn1cbmxldCBfY29tcGlsZXI7XG5mdW5jdGlvbiByZWdpc3Rlck1lc3NhZ2VDb21waWxlcihjb21waWxlcikge1xuICAgIF9jb21waWxlciA9IGNvbXBpbGVyO1xufVxubGV0IF9yZXNvbHZlcjtcbi8qKlxuICogUmVnaXN0ZXIgdGhlIG1lc3NhZ2UgcmVzb2x2ZXJcbiAqXG4gKiBAcGFyYW0gcmVzb2x2ZXIgLSBBIHtAbGluayBNZXNzYWdlUmVzb2x2ZXJ9IGZ1bmN0aW9uXG4gKlxuICogQFZ1ZUkxOG5HZW5lcmFsXG4gKi9cbmZ1bmN0aW9uIHJlZ2lzdGVyTWVzc2FnZVJlc29sdmVyKHJlc29sdmVyKSB7XG4gICAgX3Jlc29sdmVyID0gcmVzb2x2ZXI7XG59XG5sZXQgX2ZhbGxiYWNrZXI7XG4vKipcbiAqIFJlZ2lzdGVyIHRoZSBsb2NhbGUgZmFsbGJhY2tlclxuICpcbiAqIEBwYXJhbSBmYWxsYmFja2VyIC0gQSB7QGxpbmsgTG9jYWxlRmFsbGJhY2tlcn0gZnVuY3Rpb25cbiAqXG4gKiBAVnVlSTE4bkdlbmVyYWxcbiAqL1xuZnVuY3Rpb24gcmVnaXN0ZXJMb2NhbGVGYWxsYmFja2VyKGZhbGxiYWNrZXIpIHtcbiAgICBfZmFsbGJhY2tlciA9IGZhbGxiYWNrZXI7XG59XG4vLyBBZGRpdGlvbmFsIE1ldGEgZm9yIEludGxpZnkgRGV2VG9vbHNcbmxldCBfYWRkaXRpb25hbE1ldGEgPSBudWxsO1xuLyogI19fTk9fU0lERV9FRkZFQ1RTX18gKi9cbmNvbnN0IHNldEFkZGl0aW9uYWxNZXRhID0gKG1ldGEpID0+IHtcbiAgICBfYWRkaXRpb25hbE1ldGEgPSBtZXRhO1xufTtcbi8qICNfX05PX1NJREVfRUZGRUNUU19fICovXG5jb25zdCBnZXRBZGRpdGlvbmFsTWV0YSA9ICgpID0+IF9hZGRpdGlvbmFsTWV0YTtcbmxldCBfZmFsbGJhY2tDb250ZXh0ID0gbnVsbDtcbmNvbnN0IHNldEZhbGxiYWNrQ29udGV4dCA9IChjb250ZXh0KSA9PiB7XG4gICAgX2ZhbGxiYWNrQ29udGV4dCA9IGNvbnRleHQ7XG59O1xuY29uc3QgZ2V0RmFsbGJhY2tDb250ZXh0ID0gKCkgPT4gX2ZhbGxiYWNrQ29udGV4dDtcbi8vIElEIGZvciBDb3JlQ29udGV4dFxubGV0IF9jaWQgPSAwO1xuZnVuY3Rpb24gY3JlYXRlQ29yZUNvbnRleHQob3B0aW9ucyA9IHt9KSB7XG4gICAgLy8gc2V0dXAgb3B0aW9uc1xuICAgIGNvbnN0IG9uV2FybiA9IGlzRnVuY3Rpb24ob3B0aW9ucy5vbldhcm4pID8gb3B0aW9ucy5vbldhcm4gOiB3YXJuO1xuICAgIGNvbnN0IHZlcnNpb24gPSBpc1N0cmluZyhvcHRpb25zLnZlcnNpb24pID8gb3B0aW9ucy52ZXJzaW9uIDogVkVSU0lPTjtcbiAgICBjb25zdCBsb2NhbGUgPSBpc1N0cmluZyhvcHRpb25zLmxvY2FsZSkgfHwgaXNGdW5jdGlvbihvcHRpb25zLmxvY2FsZSlcbiAgICAgICAgPyBvcHRpb25zLmxvY2FsZVxuICAgICAgICA6IERFRkFVTFRfTE9DQUxFO1xuICAgIGNvbnN0IF9sb2NhbGUgPSBpc0Z1bmN0aW9uKGxvY2FsZSkgPyBERUZBVUxUX0xPQ0FMRSA6IGxvY2FsZTtcbiAgICBjb25zdCBmYWxsYmFja0xvY2FsZSA9IGlzQXJyYXkob3B0aW9ucy5mYWxsYmFja0xvY2FsZSkgfHxcbiAgICAgICAgaXNQbGFpbk9iamVjdChvcHRpb25zLmZhbGxiYWNrTG9jYWxlKSB8fFxuICAgICAgICBpc1N0cmluZyhvcHRpb25zLmZhbGxiYWNrTG9jYWxlKSB8fFxuICAgICAgICBvcHRpb25zLmZhbGxiYWNrTG9jYWxlID09PSBmYWxzZVxuICAgICAgICA/IG9wdGlvbnMuZmFsbGJhY2tMb2NhbGVcbiAgICAgICAgOiBfbG9jYWxlO1xuICAgIGNvbnN0IG1lc3NhZ2VzID0gaXNQbGFpbk9iamVjdChvcHRpb25zLm1lc3NhZ2VzKVxuICAgICAgICA/IG9wdGlvbnMubWVzc2FnZXNcbiAgICAgICAgOiBjcmVhdGVSZXNvdXJjZXMoX2xvY2FsZSk7XG4gICAgY29uc3QgZGF0ZXRpbWVGb3JtYXRzID0gaXNQbGFpbk9iamVjdChvcHRpb25zLmRhdGV0aW1lRm9ybWF0cylcbiAgICAgICAgICAgID8gb3B0aW9ucy5kYXRldGltZUZvcm1hdHNcbiAgICAgICAgICAgIDogY3JlYXRlUmVzb3VyY2VzKF9sb2NhbGUpXG4gICAgICAgIDtcbiAgICBjb25zdCBudW1iZXJGb3JtYXRzID0gaXNQbGFpbk9iamVjdChvcHRpb25zLm51bWJlckZvcm1hdHMpXG4gICAgICAgICAgICA/IG9wdGlvbnMubnVtYmVyRm9ybWF0c1xuICAgICAgICAgICAgOiBjcmVhdGVSZXNvdXJjZXMoX2xvY2FsZSlcbiAgICAgICAgO1xuICAgIGNvbnN0IG1vZGlmaWVycyA9IGFzc2lnbihjcmVhdGUoKSwgb3B0aW9ucy5tb2RpZmllcnMsIGdldERlZmF1bHRMaW5rZWRNb2RpZmllcnMoKSk7XG4gICAgY29uc3QgcGx1cmFsUnVsZXMgPSBvcHRpb25zLnBsdXJhbFJ1bGVzIHx8IGNyZWF0ZSgpO1xuICAgIGNvbnN0IG1pc3NpbmcgPSBpc0Z1bmN0aW9uKG9wdGlvbnMubWlzc2luZykgPyBvcHRpb25zLm1pc3NpbmcgOiBudWxsO1xuICAgIGNvbnN0IG1pc3NpbmdXYXJuID0gaXNCb29sZWFuKG9wdGlvbnMubWlzc2luZ1dhcm4pIHx8IGlzUmVnRXhwKG9wdGlvbnMubWlzc2luZ1dhcm4pXG4gICAgICAgID8gb3B0aW9ucy5taXNzaW5nV2FyblxuICAgICAgICA6IHRydWU7XG4gICAgY29uc3QgZmFsbGJhY2tXYXJuID0gaXNCb29sZWFuKG9wdGlvbnMuZmFsbGJhY2tXYXJuKSB8fCBpc1JlZ0V4cChvcHRpb25zLmZhbGxiYWNrV2FybilcbiAgICAgICAgPyBvcHRpb25zLmZhbGxiYWNrV2FyblxuICAgICAgICA6IHRydWU7XG4gICAgY29uc3QgZmFsbGJhY2tGb3JtYXQgPSAhIW9wdGlvbnMuZmFsbGJhY2tGb3JtYXQ7XG4gICAgY29uc3QgdW5yZXNvbHZpbmcgPSAhIW9wdGlvbnMudW5yZXNvbHZpbmc7XG4gICAgY29uc3QgcG9zdFRyYW5zbGF0aW9uID0gaXNGdW5jdGlvbihvcHRpb25zLnBvc3RUcmFuc2xhdGlvbilcbiAgICAgICAgPyBvcHRpb25zLnBvc3RUcmFuc2xhdGlvblxuICAgICAgICA6IG51bGw7XG4gICAgY29uc3QgcHJvY2Vzc29yID0gaXNQbGFpbk9iamVjdChvcHRpb25zLnByb2Nlc3NvcikgPyBvcHRpb25zLnByb2Nlc3NvciA6IG51bGw7XG4gICAgY29uc3Qgd2Fybkh0bWxNZXNzYWdlID0gaXNCb29sZWFuKG9wdGlvbnMud2Fybkh0bWxNZXNzYWdlKVxuICAgICAgICA/IG9wdGlvbnMud2Fybkh0bWxNZXNzYWdlXG4gICAgICAgIDogdHJ1ZTtcbiAgICBjb25zdCBlc2NhcGVQYXJhbWV0ZXIgPSAhIW9wdGlvbnMuZXNjYXBlUGFyYW1ldGVyO1xuICAgIGNvbnN0IG1lc3NhZ2VDb21waWxlciA9IGlzRnVuY3Rpb24ob3B0aW9ucy5tZXNzYWdlQ29tcGlsZXIpXG4gICAgICAgID8gb3B0aW9ucy5tZXNzYWdlQ29tcGlsZXJcbiAgICAgICAgOiBfY29tcGlsZXI7XG4gICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSAmJlxuICAgICAgICB0cnVlICYmXG4gICAgICAgIHRydWUgJiZcbiAgICAgICAgaXNGdW5jdGlvbihvcHRpb25zLm1lc3NhZ2VDb21waWxlcikpIHtcbiAgICAgICAgd2Fybk9uY2UoZ2V0V2Fybk1lc3NhZ2UoQ29yZVdhcm5Db2Rlcy5FWFBFUklNRU5UQUxfQ1VTVE9NX01FU1NBR0VfQ09NUElMRVIpKTtcbiAgICB9XG4gICAgY29uc3QgbWVzc2FnZVJlc29sdmVyID0gaXNGdW5jdGlvbihvcHRpb25zLm1lc3NhZ2VSZXNvbHZlcilcbiAgICAgICAgPyBvcHRpb25zLm1lc3NhZ2VSZXNvbHZlclxuICAgICAgICA6IF9yZXNvbHZlciB8fCByZXNvbHZlV2l0aEtleVZhbHVlO1xuICAgIGNvbnN0IGxvY2FsZUZhbGxiYWNrZXIgPSBpc0Z1bmN0aW9uKG9wdGlvbnMubG9jYWxlRmFsbGJhY2tlcilcbiAgICAgICAgPyBvcHRpb25zLmxvY2FsZUZhbGxiYWNrZXJcbiAgICAgICAgOiBfZmFsbGJhY2tlciB8fCBmYWxsYmFja1dpdGhTaW1wbGU7XG4gICAgY29uc3QgZmFsbGJhY2tDb250ZXh0ID0gaXNPYmplY3Qob3B0aW9ucy5mYWxsYmFja0NvbnRleHQpXG4gICAgICAgID8gb3B0aW9ucy5mYWxsYmFja0NvbnRleHRcbiAgICAgICAgOiB1bmRlZmluZWQ7XG4gICAgLy8gc2V0dXAgaW50ZXJuYWwgb3B0aW9uc1xuICAgIGNvbnN0IGludGVybmFsT3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgY29uc3QgX19kYXRldGltZUZvcm1hdHRlcnMgPSBpc09iamVjdChpbnRlcm5hbE9wdGlvbnMuX19kYXRldGltZUZvcm1hdHRlcnMpXG4gICAgICAgICAgICA/IGludGVybmFsT3B0aW9ucy5fX2RhdGV0aW1lRm9ybWF0dGVyc1xuICAgICAgICAgICAgOiBuZXcgTWFwKClcbiAgICAgICAgO1xuICAgIGNvbnN0IF9fbnVtYmVyRm9ybWF0dGVycyA9IGlzT2JqZWN0KGludGVybmFsT3B0aW9ucy5fX251bWJlckZvcm1hdHRlcnMpXG4gICAgICAgICAgICA/IGludGVybmFsT3B0aW9ucy5fX251bWJlckZvcm1hdHRlcnNcbiAgICAgICAgICAgIDogbmV3IE1hcCgpXG4gICAgICAgIDtcbiAgICBjb25zdCBfX21ldGEgPSBpc09iamVjdChpbnRlcm5hbE9wdGlvbnMuX19tZXRhKSA/IGludGVybmFsT3B0aW9ucy5fX21ldGEgOiB7fTtcbiAgICBfY2lkKys7XG4gICAgY29uc3QgY29udGV4dCA9IHtcbiAgICAgICAgdmVyc2lvbixcbiAgICAgICAgY2lkOiBfY2lkLFxuICAgICAgICBsb2NhbGUsXG4gICAgICAgIGZhbGxiYWNrTG9jYWxlLFxuICAgICAgICBtZXNzYWdlcyxcbiAgICAgICAgbW9kaWZpZXJzLFxuICAgICAgICBwbHVyYWxSdWxlcyxcbiAgICAgICAgbWlzc2luZyxcbiAgICAgICAgbWlzc2luZ1dhcm4sXG4gICAgICAgIGZhbGxiYWNrV2FybixcbiAgICAgICAgZmFsbGJhY2tGb3JtYXQsXG4gICAgICAgIHVucmVzb2x2aW5nLFxuICAgICAgICBwb3N0VHJhbnNsYXRpb24sXG4gICAgICAgIHByb2Nlc3NvcixcbiAgICAgICAgd2Fybkh0bWxNZXNzYWdlLFxuICAgICAgICBlc2NhcGVQYXJhbWV0ZXIsXG4gICAgICAgIG1lc3NhZ2VDb21waWxlcixcbiAgICAgICAgbWVzc2FnZVJlc29sdmVyLFxuICAgICAgICBsb2NhbGVGYWxsYmFja2VyLFxuICAgICAgICBmYWxsYmFja0NvbnRleHQsXG4gICAgICAgIG9uV2FybixcbiAgICAgICAgX19tZXRhXG4gICAgfTtcbiAgICB7XG4gICAgICAgIGNvbnRleHQuZGF0ZXRpbWVGb3JtYXRzID0gZGF0ZXRpbWVGb3JtYXRzO1xuICAgICAgICBjb250ZXh0Lm51bWJlckZvcm1hdHMgPSBudW1iZXJGb3JtYXRzO1xuICAgICAgICBjb250ZXh0Ll9fZGF0ZXRpbWVGb3JtYXR0ZXJzID0gX19kYXRldGltZUZvcm1hdHRlcnM7XG4gICAgICAgIGNvbnRleHQuX19udW1iZXJGb3JtYXR0ZXJzID0gX19udW1iZXJGb3JtYXR0ZXJzO1xuICAgIH1cbiAgICAvLyBmb3IgdnVlLWRldnRvb2xzIHRpbWVsaW5lIGV2ZW50XG4gICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSkge1xuICAgICAgICBjb250ZXh0Ll9fdl9lbWl0dGVyID1cbiAgICAgICAgICAgIGludGVybmFsT3B0aW9ucy5fX3ZfZW1pdHRlciAhPSBudWxsXG4gICAgICAgICAgICAgICAgPyBpbnRlcm5hbE9wdGlvbnMuX192X2VtaXR0ZXJcbiAgICAgICAgICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgLy8gTk9URTogZXhwZXJpbWVudGFsICEhXG4gICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB8fCBfX0lOVExJRllfUFJPRF9ERVZUT09MU19fKSB7XG4gICAgICAgIGluaXRJMThuRGV2VG9vbHMoY29udGV4dCwgdmVyc2lvbiwgX19tZXRhKTtcbiAgICB9XG4gICAgcmV0dXJuIGNvbnRleHQ7XG59XG5jb25zdCBjcmVhdGVSZXNvdXJjZXMgPSAobG9jYWxlKSA9PiAoeyBbbG9jYWxlXTogY3JlYXRlKCkgfSk7XG4vKiogQGludGVybmFsICovXG5mdW5jdGlvbiBpc1RyYW5zbGF0ZUZhbGxiYWNrV2FybihmYWxsYmFjaywga2V5KSB7XG4gICAgcmV0dXJuIGZhbGxiYWNrIGluc3RhbmNlb2YgUmVnRXhwID8gZmFsbGJhY2sudGVzdChrZXkpIDogZmFsbGJhY2s7XG59XG4vKiogQGludGVybmFsICovXG5mdW5jdGlvbiBpc1RyYW5zbGF0ZU1pc3NpbmdXYXJuKG1pc3NpbmcsIGtleSkge1xuICAgIHJldHVybiBtaXNzaW5nIGluc3RhbmNlb2YgUmVnRXhwID8gbWlzc2luZy50ZXN0KGtleSkgOiBtaXNzaW5nO1xufVxuLyoqIEBpbnRlcm5hbCAqL1xuZnVuY3Rpb24gaGFuZGxlTWlzc2luZyhjb250ZXh0LCBrZXksIGxvY2FsZSwgbWlzc2luZ1dhcm4sIHR5cGUpIHtcbiAgICBjb25zdCB7IG1pc3NpbmcsIG9uV2FybiB9ID0gY29udGV4dDtcbiAgICAvLyBmb3IgdnVlLWRldnRvb2xzIHRpbWVsaW5lIGV2ZW50XG4gICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSkge1xuICAgICAgICBjb25zdCBlbWl0dGVyID0gY29udGV4dC5fX3ZfZW1pdHRlcjtcbiAgICAgICAgaWYgKGVtaXR0ZXIpIHtcbiAgICAgICAgICAgIGVtaXR0ZXIuZW1pdCgnbWlzc2luZycsIHtcbiAgICAgICAgICAgICAgICBsb2NhbGUsXG4gICAgICAgICAgICAgICAga2V5LFxuICAgICAgICAgICAgICAgIHR5cGUsXG4gICAgICAgICAgICAgICAgZ3JvdXBJZDogYCR7dHlwZX06JHtrZXl9YFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKG1pc3NpbmcgIT09IG51bGwpIHtcbiAgICAgICAgY29uc3QgcmV0ID0gbWlzc2luZyhjb250ZXh0LCBsb2NhbGUsIGtleSwgdHlwZSk7XG4gICAgICAgIHJldHVybiBpc1N0cmluZyhyZXQpID8gcmV0IDoga2V5O1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSAmJiBpc1RyYW5zbGF0ZU1pc3NpbmdXYXJuKG1pc3NpbmdXYXJuLCBrZXkpKSB7XG4gICAgICAgICAgICBvbldhcm4oZ2V0V2Fybk1lc3NhZ2UoQ29yZVdhcm5Db2Rlcy5OT1RfRk9VTkRfS0VZLCB7IGtleSwgbG9jYWxlIH0pKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ga2V5O1xuICAgIH1cbn1cbi8qKiBAaW50ZXJuYWwgKi9cbmZ1bmN0aW9uIHVwZGF0ZUZhbGxiYWNrTG9jYWxlKGN0eCwgbG9jYWxlLCBmYWxsYmFjaykge1xuICAgIGNvbnN0IGNvbnRleHQgPSBjdHg7XG4gICAgY29udGV4dC5fX2xvY2FsZUNoYWluQ2FjaGUgPSBuZXcgTWFwKCk7XG4gICAgY3R4LmxvY2FsZUZhbGxiYWNrZXIoY3R4LCBmYWxsYmFjaywgbG9jYWxlKTtcbn1cbi8qKiBAaW50ZXJuYWwgKi9cbmZ1bmN0aW9uIGlzQWxtb3N0U2FtZUxvY2FsZShsb2NhbGUsIGNvbXBhcmVMb2NhbGUpIHtcbiAgICBpZiAobG9jYWxlID09PSBjb21wYXJlTG9jYWxlKVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgcmV0dXJuIGxvY2FsZS5zcGxpdCgnLScpWzBdID09PSBjb21wYXJlTG9jYWxlLnNwbGl0KCctJylbMF07XG59XG4vKiogQGludGVybmFsICovXG5mdW5jdGlvbiBpc0ltcGxpY2l0RmFsbGJhY2sodGFyZ2V0TG9jYWxlLCBsb2NhbGVzKSB7XG4gICAgY29uc3QgaW5kZXggPSBsb2NhbGVzLmluZGV4T2YodGFyZ2V0TG9jYWxlKTtcbiAgICBpZiAoaW5kZXggPT09IC0xKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgZm9yIChsZXQgaSA9IGluZGV4ICsgMTsgaSA8IGxvY2FsZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgaWYgKGlzQWxtb3N0U2FtZUxvY2FsZSh0YXJnZXRMb2NhbGUsIGxvY2FsZXNbaV0pKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG59XG4vKiBlc2xpbnQtZW5hYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cblxuZnVuY3Rpb24gcmVzb2x2ZUZvcm1hdExvY2FsZShjb250ZXh0LCBrZXksIGxvY2FsZSwgZm9ybWF0cywgbWlzc2luZ1dhcm4sIGZhbGxiYWNrV2FybiwgdHlwZSkge1xuICAgIGNvbnN0IHsgZmFsbGJhY2tMb2NhbGUsIGxvY2FsZUZhbGxiYWNrZXIsIG9uV2FybiB9ID0gY29udGV4dDtcbiAgICBjb25zdCBsb2NhbGVzID0gbG9jYWxlRmFsbGJhY2tlcihjb250ZXh0LCAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbiAgICBmYWxsYmFja0xvY2FsZSwgbG9jYWxlKTtcbiAgICBsZXQgZnJvbSA9IGxvY2FsZTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxvY2FsZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY29uc3QgdGFyZ2V0TG9jYWxlID0gbG9jYWxlc1tpXTtcbiAgICAgICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSAmJlxuICAgICAgICAgICAgbG9jYWxlICE9PSB0YXJnZXRMb2NhbGUgJiZcbiAgICAgICAgICAgIGlzVHJhbnNsYXRlRmFsbGJhY2tXYXJuKGZhbGxiYWNrV2Fybiwga2V5KSkge1xuICAgICAgICAgICAgb25XYXJuKGdldFdhcm5NZXNzYWdlKHR5cGUgPT09ICdkYXRldGltZSBmb3JtYXQnXG4gICAgICAgICAgICAgICAgPyBDb3JlV2FybkNvZGVzLkZBTExCQUNLX1RPX0RBVEVfRk9STUFUXG4gICAgICAgICAgICAgICAgOiBDb3JlV2FybkNvZGVzLkZBTExCQUNLX1RPX05VTUJFUl9GT1JNQVQsIHtcbiAgICAgICAgICAgICAgICBrZXksXG4gICAgICAgICAgICAgICAgdGFyZ2V0OiB0YXJnZXRMb2NhbGVcbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpICYmIGxvY2FsZSAhPT0gdGFyZ2V0TG9jYWxlKSB7XG4gICAgICAgICAgICBjb25zdCBlbWl0dGVyID0gY29udGV4dC5fX3ZfZW1pdHRlcjtcbiAgICAgICAgICAgIGlmIChlbWl0dGVyKSB7XG4gICAgICAgICAgICAgICAgZW1pdHRlci5lbWl0KCdmYWxsYmFjaycsIHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZSxcbiAgICAgICAgICAgICAgICAgICAga2V5LFxuICAgICAgICAgICAgICAgICAgICBmcm9tLFxuICAgICAgICAgICAgICAgICAgICB0bzogdGFyZ2V0TG9jYWxlLFxuICAgICAgICAgICAgICAgICAgICBncm91cElkOiBgJHt0eXBlfToke2tleX1gXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZm9ybWF0ID0gKGZvcm1hdHNbdGFyZ2V0TG9jYWxlXSB8fCB7fSlba2V5XTtcbiAgICAgICAgaWYgKGlzUGxhaW5PYmplY3QoZm9ybWF0KSAmJiBpc1N0cmluZyh0YXJnZXRMb2NhbGUpKSB7XG4gICAgICAgICAgICByZXR1cm4gdGFyZ2V0TG9jYWxlO1xuICAgICAgICB9XG4gICAgICAgIGhhbmRsZU1pc3NpbmcoY29udGV4dCwga2V5LCB0YXJnZXRMb2NhbGUsIG1pc3NpbmdXYXJuLCB0eXBlKTtcbiAgICAgICAgZnJvbSA9IHRhcmdldExvY2FsZTtcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiBnZXRGb3JtYXR0ZXJDYWNoZUtleShsb2NhbGUsIGtleSwgb3ZlcnJpZGVzKSB7XG4gICAgbGV0IGlkID0gYCR7bG9jYWxlfV9fJHtrZXl9YDtcbiAgICBpZiAoaXNQbGFpbk9iamVjdChvdmVycmlkZXMpICYmICFpc0VtcHR5T2JqZWN0KG92ZXJyaWRlcykpIHtcbiAgICAgICAgaWQgPSBgJHtpZH1fXyR7SlNPTi5zdHJpbmdpZnkob3ZlcnJpZGVzKX1gO1xuICAgIH1cbiAgICByZXR1cm4gaWQ7XG59XG5mdW5jdGlvbiBjbGVhckZvcm1hdENhY2hlKGZvcm1hdHRlcnMsIGxvY2FsZSwgZm9ybWF0KSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZm9ybWF0KSB7XG4gICAgICAgIGNvbnN0IHByZWZpeCA9IGAke2xvY2FsZX1fXyR7a2V5fWA7XG4gICAgICAgIGZvciAoY29uc3QgaWQgb2YgZm9ybWF0dGVycy5rZXlzKCkpIHtcbiAgICAgICAgICAgIGlmIChpZCA9PT0gcHJlZml4IHx8IGlkLnN0YXJ0c1dpdGgoYCR7cHJlZml4fV9fYCkpIHtcbiAgICAgICAgICAgICAgICBmb3JtYXR0ZXJzLmRlbGV0ZShpZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG5mdW5jdGlvbiBwYXJzZUZvcm1hdEFyZ3MoYXJncywgb3B0aW9ucywgaW5pdGlhbE92ZXJyaWRlcywgb3B0aW9uc0tleXMpIHtcbiAgICBjb25zdCBbLCBhcmcyLCBhcmczLCBhcmc0XSA9IGFyZ3M7XG4gICAgbGV0IG92ZXJyaWRlcyA9IGluaXRpYWxPdmVycmlkZXM7XG4gICAgaWYgKGlzU3RyaW5nKGFyZzIpKSB7XG4gICAgICAgIG9wdGlvbnMua2V5ID0gYXJnMjtcbiAgICB9XG4gICAgZWxzZSBpZiAoaXNQbGFpbk9iamVjdChhcmcyKSkge1xuICAgICAgICBPYmplY3Qua2V5cyhhcmcyKS5mb3JFYWNoKGtleSA9PiB7XG4gICAgICAgICAgICBpZiAob3B0aW9uc0tleXMuaW5jbHVkZXMoa2V5KSkge1xuICAgICAgICAgICAgICAgIG92ZXJyaWRlc1trZXldID0gYXJnMltrZXldO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgb3B0aW9uc1trZXldID0gYXJnMltrZXldO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG4gICAgaWYgKGlzU3RyaW5nKGFyZzMpKSB7XG4gICAgICAgIG9wdGlvbnMubG9jYWxlID0gYXJnMztcbiAgICB9XG4gICAgZWxzZSBpZiAoaXNQbGFpbk9iamVjdChhcmczKSkge1xuICAgICAgICBvdmVycmlkZXMgPSBhcmczO1xuICAgIH1cbiAgICBpZiAoaXNQbGFpbk9iamVjdChhcmc0KSkge1xuICAgICAgICBvdmVycmlkZXMgPSBhcmc0O1xuICAgIH1cbiAgICByZXR1cm4gb3ZlcnJpZGVzO1xufVxuXG5jb25zdCBpbnRsRGVmaW5lZCA9IHR5cGVvZiBJbnRsICE9PSAndW5kZWZpbmVkJztcbmNvbnN0IEF2YWlsYWJpbGl0aWVzID0ge1xuICAgIGRhdGVUaW1lRm9ybWF0OiBpbnRsRGVmaW5lZCAmJiB0eXBlb2YgSW50bC5EYXRlVGltZUZvcm1hdCAhPT0gJ3VuZGVmaW5lZCcsXG4gICAgbnVtYmVyRm9ybWF0OiBpbnRsRGVmaW5lZCAmJiB0eXBlb2YgSW50bC5OdW1iZXJGb3JtYXQgIT09ICd1bmRlZmluZWQnXG59O1xuXG4vLyBpbXBsZW1lbnRhdGlvbiBvZiBgZGF0ZXRpbWVgIGZ1bmN0aW9uXG5mdW5jdGlvbiBkYXRldGltZShjb250ZXh0LCAuLi5hcmdzKSB7XG4gICAgY29uc3QgeyBkYXRldGltZUZvcm1hdHMsIHVucmVzb2x2aW5nLCBvbldhcm4gfSA9IGNvbnRleHQ7XG4gICAgY29uc3QgeyBfX2RhdGV0aW1lRm9ybWF0dGVycyB9ID0gY29udGV4dDtcbiAgICBpZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpICYmICFBdmFpbGFiaWxpdGllcy5kYXRlVGltZUZvcm1hdCkge1xuICAgICAgICBvbldhcm4oZ2V0V2Fybk1lc3NhZ2UoQ29yZVdhcm5Db2Rlcy5DQU5OT1RfRk9STUFUX0RBVEUpKTtcbiAgICAgICAgcmV0dXJuIE1JU1NJTkdfUkVTT0xWRV9WQUxVRTtcbiAgICB9XG4gICAgaWYgKCFpc1N0cmluZyhhcmdzWzBdKSAmJiAhaXNEYXRlKGFyZ3NbMF0pICYmICFpc051bWJlcihhcmdzWzBdKSkge1xuICAgICAgICBpZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpKSB7XG4gICAgICAgICAgICBvbldhcm4oZ2V0V2Fybk1lc3NhZ2UoQ29yZVdhcm5Db2Rlcy5JTlZBTElEX0RBVEVfQVJHVU1FTlQsIHtcbiAgICAgICAgICAgICAgICB2YWx1ZTogU3RyaW5nKGFyZ3NbMF0pXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIE1JU1NJTkdfUkVTT0xWRV9WQUxVRTtcbiAgICB9XG4gICAgY29uc3QgW2tleSwgdmFsdWUsIG9wdGlvbnMsIG92ZXJyaWRlc10gPSBwYXJzZURhdGVUaW1lQXJncyguLi5hcmdzKTtcbiAgICBjb25zdCBtaXNzaW5nV2FybiA9IGlzQm9vbGVhbihvcHRpb25zLm1pc3NpbmdXYXJuKVxuICAgICAgICA/IG9wdGlvbnMubWlzc2luZ1dhcm5cbiAgICAgICAgOiBjb250ZXh0Lm1pc3NpbmdXYXJuO1xuICAgIGNvbnN0IGZhbGxiYWNrV2FybiA9IGlzQm9vbGVhbihvcHRpb25zLmZhbGxiYWNrV2FybilcbiAgICAgICAgPyBvcHRpb25zLmZhbGxiYWNrV2FyblxuICAgICAgICA6IGNvbnRleHQuZmFsbGJhY2tXYXJuO1xuICAgIGNvbnN0IHBhcnQgPSAhIW9wdGlvbnMucGFydDtcbiAgICBjb25zdCBsb2NhbGUgPSBnZXRMb2NhbGUoY29udGV4dCwgb3B0aW9ucyk7XG4gICAgaWYgKCFpc1N0cmluZyhrZXkpIHx8IGtleSA9PT0gJycpIHtcbiAgICAgICAgY29uc3QgZm9ybWF0dGVyID0gbmV3IEludGwuRGF0ZVRpbWVGb3JtYXQobG9jYWxlLnJlcGxhY2UoLyEvZywgJycpLCBvdmVycmlkZXMpO1xuICAgICAgICByZXR1cm4gIXBhcnQgPyBmb3JtYXR0ZXIuZm9ybWF0KHZhbHVlKSA6IGZvcm1hdHRlci5mb3JtYXRUb1BhcnRzKHZhbHVlKTtcbiAgICB9XG4gICAgY29uc3QgdGFyZ2V0TG9jYWxlID0gcmVzb2x2ZUZvcm1hdExvY2FsZShjb250ZXh0LCBrZXksIGxvY2FsZSwgZGF0ZXRpbWVGb3JtYXRzLCBtaXNzaW5nV2FybiwgZmFsbGJhY2tXYXJuLCAnZGF0ZXRpbWUgZm9ybWF0Jyk7XG4gICAgaWYgKCFpc1N0cmluZyh0YXJnZXRMb2NhbGUpKSB7XG4gICAgICAgIHJldHVybiB1bnJlc29sdmluZyA/IE5PVF9SRU9TTFZFRCA6IGtleTtcbiAgICB9XG4gICAgY29uc3QgZm9ybWF0ID0gZGF0ZXRpbWVGb3JtYXRzW3RhcmdldExvY2FsZV1ba2V5XTtcbiAgICBjb25zdCBpZCA9IGdldEZvcm1hdHRlckNhY2hlS2V5KHRhcmdldExvY2FsZSwga2V5LCBvdmVycmlkZXMpO1xuICAgIGxldCBmb3JtYXR0ZXIgPSBfX2RhdGV0aW1lRm9ybWF0dGVycy5nZXQoaWQpO1xuICAgIGlmICghZm9ybWF0dGVyKSB7XG4gICAgICAgIGZvcm1hdHRlciA9IG5ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KHRhcmdldExvY2FsZSwgYXNzaWduKHt9LCBmb3JtYXQsIG92ZXJyaWRlcykpO1xuICAgICAgICBfX2RhdGV0aW1lRm9ybWF0dGVycy5zZXQoaWQsIGZvcm1hdHRlcik7XG4gICAgfVxuICAgIHJldHVybiAhcGFydCA/IGZvcm1hdHRlci5mb3JtYXQodmFsdWUpIDogZm9ybWF0dGVyLmZvcm1hdFRvUGFydHModmFsdWUpO1xufVxuLyoqIEBpbnRlcm5hbCAqL1xuY29uc3QgREFURVRJTUVfRk9STUFUX09QVElPTlNfS0VZUyA9IFtcbiAgICAnbG9jYWxlTWF0Y2hlcicsXG4gICAgJ3dlZWtkYXknLFxuICAgICdlcmEnLFxuICAgICd5ZWFyJyxcbiAgICAnbW9udGgnLFxuICAgICdkYXknLFxuICAgICdob3VyJyxcbiAgICAnbWludXRlJyxcbiAgICAnc2Vjb25kJyxcbiAgICAndGltZVpvbmVOYW1lJyxcbiAgICAnZm9ybWF0TWF0Y2hlcicsXG4gICAgJ2hvdXIxMicsXG4gICAgJ3RpbWVab25lJyxcbiAgICAnZGF0ZVN0eWxlJyxcbiAgICAndGltZVN0eWxlJyxcbiAgICAnY2FsZW5kYXInLFxuICAgICdkYXlQZXJpb2QnLFxuICAgICdudW1iZXJpbmdTeXN0ZW0nLFxuICAgICdob3VyQ3ljbGUnLFxuICAgICdmcmFjdGlvbmFsU2Vjb25kRGlnaXRzJ1xuXTtcbi8qKiBAaW50ZXJuYWwgKi9cbmZ1bmN0aW9uIHBhcnNlRGF0ZVRpbWVBcmdzKC4uLmFyZ3MpIHtcbiAgICBjb25zdCBbYXJnMV0gPSBhcmdzO1xuICAgIGNvbnN0IG9wdGlvbnMgPSBjcmVhdGUoKTtcbiAgICBjb25zdCBpbml0aWFsT3ZlcnJpZGVzID0gY3JlYXRlKCk7XG4gICAgbGV0IHZhbHVlO1xuICAgIGlmIChpc1N0cmluZyhhcmcxKSkge1xuICAgICAgICAvLyBPbmx5IGFsbG93IElTTyBzdHJpbmdzIC0gb3RoZXIgZGF0ZSBmb3JtYXRzIGFyZSBvZnRlbiBzdXBwb3J0ZWQsXG4gICAgICAgIC8vIGJ1dCBtYXkgY2F1c2UgZGlmZmVyZW50IHJlc3VsdHMgaW4gZGlmZmVyZW50IGJyb3dzZXJzLlxuICAgICAgICBjb25zdCBtYXRjaGVzID0gYXJnMS5tYXRjaCgvKFxcZHs0fS1cXGR7Mn0tXFxkezJ9KShUfFxccyk/KC4qKS8pO1xuICAgICAgICBpZiAoIW1hdGNoZXMpIHtcbiAgICAgICAgICAgIHRocm93IGNyZWF0ZUNvcmVFcnJvcihDb3JlRXJyb3JDb2Rlcy5JTlZBTElEX0lTT19EQVRFX0FSR1VNRU5UKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBTb21lIGJyb3dzZXJzIGNhbiBub3QgcGFyc2UgdGhlIGlzbyBkYXRldGltZSBzZXBhcmF0ZWQgYnkgc3BhY2UsXG4gICAgICAgIC8vIHRoaXMgaXMgYSBjb21wcm9taXNlIHNvbHV0aW9uIGJ5IHJlcGxhY2UgdGhlICdUJy8nICcgd2l0aCAnVCdcbiAgICAgICAgY29uc3QgZGF0ZVRpbWUgPSBtYXRjaGVzWzNdXG4gICAgICAgICAgICA/IG1hdGNoZXNbM10udHJpbSgpLnN0YXJ0c1dpdGgoJ1QnKVxuICAgICAgICAgICAgICAgID8gYCR7bWF0Y2hlc1sxXS50cmltKCl9JHttYXRjaGVzWzNdLnRyaW0oKX1gXG4gICAgICAgICAgICAgICAgOiBgJHttYXRjaGVzWzFdLnRyaW0oKX1UJHttYXRjaGVzWzNdLnRyaW0oKX1gXG4gICAgICAgICAgICA6IG1hdGNoZXNbMV0udHJpbSgpO1xuICAgICAgICB2YWx1ZSA9IG5ldyBEYXRlKGRhdGVUaW1lKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIC8vIFRoaXMgd2lsbCBmYWlsIGlmIHRoZSBkYXRlIGlzIG5vdCB2YWxpZFxuICAgICAgICAgICAgdmFsdWUudG9JU09TdHJpbmcoKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCB7XG4gICAgICAgICAgICB0aHJvdyBjcmVhdGVDb3JlRXJyb3IoQ29yZUVycm9yQ29kZXMuSU5WQUxJRF9JU09fREFURV9BUkdVTUVOVCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZWxzZSBpZiAoaXNEYXRlKGFyZzEpKSB7XG4gICAgICAgIGlmIChpc05hTihhcmcxLmdldFRpbWUoKSkpIHtcbiAgICAgICAgICAgIHRocm93IGNyZWF0ZUNvcmVFcnJvcihDb3JlRXJyb3JDb2Rlcy5JTlZBTElEX0RBVEVfQVJHVU1FTlQpO1xuICAgICAgICB9XG4gICAgICAgIHZhbHVlID0gYXJnMTtcbiAgICB9XG4gICAgZWxzZSBpZiAoaXNOdW1iZXIoYXJnMSkpIHtcbiAgICAgICAgdmFsdWUgPSBhcmcxO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgdGhyb3cgY3JlYXRlQ29yZUVycm9yKENvcmVFcnJvckNvZGVzLklOVkFMSURfQVJHVU1FTlQpO1xuICAgIH1cbiAgICBjb25zdCBvdmVycmlkZXMgPSBwYXJzZUZvcm1hdEFyZ3MoYXJncywgb3B0aW9ucywgaW5pdGlhbE92ZXJyaWRlcywgREFURVRJTUVfRk9STUFUX09QVElPTlNfS0VZUyk7XG4gICAgcmV0dXJuIFtvcHRpb25zLmtleSB8fCAnJywgdmFsdWUsIG9wdGlvbnMsIG92ZXJyaWRlc107XG59XG4vKiogQGludGVybmFsICovXG5mdW5jdGlvbiBjbGVhckRhdGVUaW1lRm9ybWF0KGN0eCwgbG9jYWxlLCBmb3JtYXQpIHtcbiAgICBjb25zdCBjb250ZXh0ID0gY3R4O1xuICAgIGNsZWFyRm9ybWF0Q2FjaGUoY29udGV4dC5fX2RhdGV0aW1lRm9ybWF0dGVycywgbG9jYWxlLCBmb3JtYXQpO1xufVxuXG4vLyBpbXBsZW1lbnRhdGlvbiBvZiBgbnVtYmVyYCBmdW5jdGlvblxuZnVuY3Rpb24gbnVtYmVyKGNvbnRleHQsIC4uLmFyZ3MpIHtcbiAgICBjb25zdCB7IG51bWJlckZvcm1hdHMsIHVucmVzb2x2aW5nLCBvbldhcm4gfSA9IGNvbnRleHQ7XG4gICAgY29uc3QgeyBfX251bWJlckZvcm1hdHRlcnMgfSA9IGNvbnRleHQ7XG4gICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSAmJiAhQXZhaWxhYmlsaXRpZXMubnVtYmVyRm9ybWF0KSB7XG4gICAgICAgIG9uV2FybihnZXRXYXJuTWVzc2FnZShDb3JlV2FybkNvZGVzLkNBTk5PVF9GT1JNQVRfTlVNQkVSKSk7XG4gICAgICAgIHJldHVybiBNSVNTSU5HX1JFU09MVkVfVkFMVUU7XG4gICAgfVxuICAgIGlmICghaXNOdW1iZXIoYXJnc1swXSkpIHtcbiAgICAgICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSkge1xuICAgICAgICAgICAgb25XYXJuKGdldFdhcm5NZXNzYWdlKENvcmVXYXJuQ29kZXMuSU5WQUxJRF9OVU1CRVJfQVJHVU1FTlQsIHtcbiAgICAgICAgICAgICAgICB2YWx1ZTogU3RyaW5nKGFyZ3NbMF0pXG4gICAgICAgICAgICB9KSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIE1JU1NJTkdfUkVTT0xWRV9WQUxVRTtcbiAgICB9XG4gICAgY29uc3QgW2tleSwgdmFsdWUsIG9wdGlvbnMsIG92ZXJyaWRlc10gPSBwYXJzZU51bWJlckFyZ3MoLi4uYXJncyk7XG4gICAgY29uc3QgbWlzc2luZ1dhcm4gPSBpc0Jvb2xlYW4ob3B0aW9ucy5taXNzaW5nV2FybilcbiAgICAgICAgPyBvcHRpb25zLm1pc3NpbmdXYXJuXG4gICAgICAgIDogY29udGV4dC5taXNzaW5nV2FybjtcbiAgICBjb25zdCBmYWxsYmFja1dhcm4gPSBpc0Jvb2xlYW4ob3B0aW9ucy5mYWxsYmFja1dhcm4pXG4gICAgICAgID8gb3B0aW9ucy5mYWxsYmFja1dhcm5cbiAgICAgICAgOiBjb250ZXh0LmZhbGxiYWNrV2FybjtcbiAgICBjb25zdCBwYXJ0ID0gISFvcHRpb25zLnBhcnQ7XG4gICAgY29uc3QgbG9jYWxlID0gZ2V0TG9jYWxlKGNvbnRleHQsIG9wdGlvbnMpO1xuICAgIGlmICghaXNTdHJpbmcoa2V5KSB8fCBrZXkgPT09ICcnKSB7XG4gICAgICAgIGNvbnN0IGZvcm1hdHRlciA9IG5ldyBJbnRsLk51bWJlckZvcm1hdChsb2NhbGUucmVwbGFjZSgvIS9nLCAnJyksIG92ZXJyaWRlcyk7XG4gICAgICAgIHJldHVybiAhcGFydCA/IGZvcm1hdHRlci5mb3JtYXQodmFsdWUpIDogZm9ybWF0dGVyLmZvcm1hdFRvUGFydHModmFsdWUpO1xuICAgIH1cbiAgICBjb25zdCB0YXJnZXRMb2NhbGUgPSByZXNvbHZlRm9ybWF0TG9jYWxlKGNvbnRleHQsIGtleSwgbG9jYWxlLCBudW1iZXJGb3JtYXRzLCBtaXNzaW5nV2FybiwgZmFsbGJhY2tXYXJuLCAnbnVtYmVyIGZvcm1hdCcpO1xuICAgIGlmICghaXNTdHJpbmcodGFyZ2V0TG9jYWxlKSkge1xuICAgICAgICByZXR1cm4gdW5yZXNvbHZpbmcgPyBOT1RfUkVPU0xWRUQgOiBrZXk7XG4gICAgfVxuICAgIGNvbnN0IGZvcm1hdCA9IG51bWJlckZvcm1hdHNbdGFyZ2V0TG9jYWxlXVtrZXldO1xuICAgIGNvbnN0IGlkID0gZ2V0Rm9ybWF0dGVyQ2FjaGVLZXkodGFyZ2V0TG9jYWxlLCBrZXksIG92ZXJyaWRlcyk7XG4gICAgbGV0IGZvcm1hdHRlciA9IF9fbnVtYmVyRm9ybWF0dGVycy5nZXQoaWQpO1xuICAgIGlmICghZm9ybWF0dGVyKSB7XG4gICAgICAgIGZvcm1hdHRlciA9IG5ldyBJbnRsLk51bWJlckZvcm1hdCh0YXJnZXRMb2NhbGUsIGFzc2lnbih7fSwgZm9ybWF0LCBvdmVycmlkZXMpKTtcbiAgICAgICAgX19udW1iZXJGb3JtYXR0ZXJzLnNldChpZCwgZm9ybWF0dGVyKTtcbiAgICB9XG4gICAgcmV0dXJuICFwYXJ0ID8gZm9ybWF0dGVyLmZvcm1hdCh2YWx1ZSkgOiBmb3JtYXR0ZXIuZm9ybWF0VG9QYXJ0cyh2YWx1ZSk7XG59XG4vKiogQGludGVybmFsICovXG5jb25zdCBOVU1CRVJfRk9STUFUX09QVElPTlNfS0VZUyA9IFtcbiAgICAnbG9jYWxlTWF0Y2hlcicsXG4gICAgJ3N0eWxlJyxcbiAgICAnY3VycmVuY3knLFxuICAgICdjdXJyZW5jeURpc3BsYXknLFxuICAgICdjdXJyZW5jeVNpZ24nLFxuICAgICd1c2VHcm91cGluZycsXG4gICAgJ21pbmltdW1JbnRlZ2VyRGlnaXRzJyxcbiAgICAnbWluaW11bUZyYWN0aW9uRGlnaXRzJyxcbiAgICAnbWF4aW11bUZyYWN0aW9uRGlnaXRzJyxcbiAgICAnbWluaW11bVNpZ25pZmljYW50RGlnaXRzJyxcbiAgICAnbWF4aW11bVNpZ25pZmljYW50RGlnaXRzJyxcbiAgICAnY29tcGFjdERpc3BsYXknLFxuICAgICdub3RhdGlvbicsXG4gICAgJ3NpZ25EaXNwbGF5JyxcbiAgICAndW5pdCcsXG4gICAgJ3VuaXREaXNwbGF5JyxcbiAgICAncm91bmRpbmdNb2RlJyxcbiAgICAncm91bmRpbmdQcmlvcml0eScsXG4gICAgJ3JvdW5kaW5nSW5jcmVtZW50JyxcbiAgICAndHJhaWxpbmdaZXJvRGlzcGxheSdcbl07XG4vKiogQGludGVybmFsICovXG5mdW5jdGlvbiBwYXJzZU51bWJlckFyZ3MoLi4uYXJncykge1xuICAgIGNvbnN0IFthcmcxXSA9IGFyZ3M7XG4gICAgY29uc3Qgb3B0aW9ucyA9IGNyZWF0ZSgpO1xuICAgIGNvbnN0IGluaXRpYWxPdmVycmlkZXMgPSBjcmVhdGUoKTtcbiAgICBpZiAoIWlzTnVtYmVyKGFyZzEpKSB7XG4gICAgICAgIHRocm93IGNyZWF0ZUNvcmVFcnJvcihDb3JlRXJyb3JDb2Rlcy5JTlZBTElEX0FSR1VNRU5UKTtcbiAgICB9XG4gICAgY29uc3QgdmFsdWUgPSBhcmcxO1xuICAgIGNvbnN0IG92ZXJyaWRlcyA9IHBhcnNlRm9ybWF0QXJncyhhcmdzLCBvcHRpb25zLCBpbml0aWFsT3ZlcnJpZGVzLCBOVU1CRVJfRk9STUFUX09QVElPTlNfS0VZUyk7XG4gICAgcmV0dXJuIFtvcHRpb25zLmtleSB8fCAnJywgdmFsdWUsIG9wdGlvbnMsIG92ZXJyaWRlc107XG59XG4vKiogQGludGVybmFsICovXG5mdW5jdGlvbiBjbGVhck51bWJlckZvcm1hdChjdHgsIGxvY2FsZSwgZm9ybWF0KSB7XG4gICAgY29uc3QgY29udGV4dCA9IGN0eDtcbiAgICBjbGVhckZvcm1hdENhY2hlKGNvbnRleHQuX19udW1iZXJGb3JtYXR0ZXJzLCBsb2NhbGUsIGZvcm1hdCk7XG59XG5cbmNvbnN0IERFRkFVTFRfTU9ESUZJRVIgPSAoc3RyKSA9PiBzdHI7XG5jb25zdCBERUZBVUxUX01FU1NBR0UgPSAoY3R4KSA9PiAnJzsgLy8gZXNsaW50LWRpc2FibGUtbGluZVxuY29uc3QgREVGQVVMVF9NRVNTQUdFX0RBVEFfVFlQRSA9ICd0ZXh0JztcbmNvbnN0IERFRkFVTFRfTk9STUFMSVpFID0gKHZhbHVlcykgPT4gdmFsdWVzLmxlbmd0aCA9PT0gMCA/ICcnIDogam9pbih2YWx1ZXMpO1xuY29uc3QgREVGQVVMVF9JTlRFUlBPTEFURSA9IHRvRGlzcGxheVN0cmluZztcbmZ1bmN0aW9uIHBsdXJhbERlZmF1bHQoY2hvaWNlLCBjaG9pY2VzTGVuZ3RoKSB7XG4gICAgY2hvaWNlID0gTWF0aC5hYnMoY2hvaWNlKTtcbiAgICAvLyBzaW5ndWxhciAoMCkgfCBwbHVyYWwgKDEpXG4gICAgaWYgKGNob2ljZXNMZW5ndGggPT09IDIpIHtcbiAgICAgICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgICAgIHJldHVybiBjaG9pY2UgPT09IDFcbiAgICAgICAgICAgID8gMFxuICAgICAgICAgICAgOiAxO1xuICAgIH1cbiAgICAvLyB6ZXJvICgwKSB8IHNpbmd1bGFyICgxKSB8IHBsdXJhbCAoMilcbiAgICByZXR1cm4gTWF0aC5taW4oY2hvaWNlLCAyKTtcbn1cbmZ1bmN0aW9uIGdldFBsdXJhbEluZGV4KG9wdGlvbnMpIHtcbiAgICAvLyBwcmV0dGllci1pZ25vcmVcbiAgICBjb25zdCBpbmRleCA9IGlzTnVtYmVyKG9wdGlvbnMucGx1cmFsSW5kZXgpXG4gICAgICAgID8gb3B0aW9ucy5wbHVyYWxJbmRleFxuICAgICAgICA6IC0xO1xuICAgIHJldHVybiBpc051bWJlcihvcHRpb25zLm5hbWVkPy5jb3VudClcbiAgICAgICAgPyBvcHRpb25zLm5hbWVkLmNvdW50XG4gICAgICAgIDogaXNOdW1iZXIob3B0aW9ucy5uYW1lZD8ubilcbiAgICAgICAgICAgID8gb3B0aW9ucy5uYW1lZC5uXG4gICAgICAgICAgICA6IGluZGV4O1xufVxuZnVuY3Rpb24gY3JlYXRlTWVzc2FnZUNvbnRleHQob3B0aW9ucyA9IHt9KSB7XG4gICAgY29uc3QgbG9jYWxlID0gb3B0aW9ucy5sb2NhbGU7XG4gICAgY29uc3QgcGx1cmFsSW5kZXggPSBnZXRQbHVyYWxJbmRleChvcHRpb25zKTtcbiAgICBjb25zdCBwbHVyYWxSdWxlID0gaXNTdHJpbmcobG9jYWxlKSAmJiBpc0Z1bmN0aW9uKG9wdGlvbnMucGx1cmFsUnVsZXM/Lltsb2NhbGVdKVxuICAgICAgICA/IG9wdGlvbnMucGx1cmFsUnVsZXNbbG9jYWxlXVxuICAgICAgICA6IHBsdXJhbERlZmF1bHQ7XG4gICAgY29uc3Qgb3JnUGx1cmFsUnVsZSA9IHBsdXJhbFJ1bGUgPT09IHBsdXJhbERlZmF1bHQgPyB1bmRlZmluZWQgOiBwbHVyYWxEZWZhdWx0O1xuICAgIGNvbnN0IHBsdXJhbCA9IChtZXNzYWdlcykgPT4gbWVzc2FnZXNbcGx1cmFsUnVsZShwbHVyYWxJbmRleCwgbWVzc2FnZXMubGVuZ3RoLCBvcmdQbHVyYWxSdWxlKV07XG4gICAgY29uc3QgX2xpc3QgPSBvcHRpb25zLmxpc3QgfHwgW107XG4gICAgY29uc3QgbGlzdCA9IChpbmRleCkgPT4gX2xpc3RbaW5kZXhdO1xuICAgIGNvbnN0IF9uYW1lZCA9IG9wdGlvbnMubmFtZWQgfHwgY3JlYXRlKCk7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLWV4cGxpY2l0LWFueVxuICAgIC8vIG5vcm1hbGl6ZSBuYW1lZFxuICAgIGlmIChpc051bWJlcihvcHRpb25zLnBsdXJhbEluZGV4KSkge1xuICAgICAgICBfbmFtZWQuY291bnQgfHw9IG9wdGlvbnMucGx1cmFsSW5kZXg7XG4gICAgICAgIF9uYW1lZC5uIHx8PSBvcHRpb25zLnBsdXJhbEluZGV4O1xuICAgIH1cbiAgICBjb25zdCBuYW1lZCA9IChrZXkpID0+IF9uYW1lZFtrZXldO1xuICAgIGZ1bmN0aW9uIG1lc3NhZ2Uoa2V5LCB1c2VMaW5rZWQpIHtcbiAgICAgICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgICAgIGNvbnN0IG1zZyA9IGlzRnVuY3Rpb24ob3B0aW9ucy5tZXNzYWdlcylcbiAgICAgICAgICAgID8gb3B0aW9ucy5tZXNzYWdlcyhrZXksICEhdXNlTGlua2VkKVxuICAgICAgICAgICAgOiBpc09iamVjdChvcHRpb25zLm1lc3NhZ2VzKVxuICAgICAgICAgICAgICAgID8gb3B0aW9ucy5tZXNzYWdlc1trZXldXG4gICAgICAgICAgICAgICAgOiBmYWxzZTtcbiAgICAgICAgcmV0dXJuICFtc2dcbiAgICAgICAgICAgID8gb3B0aW9ucy5wYXJlbnRcbiAgICAgICAgICAgICAgICA/IG9wdGlvbnMucGFyZW50Lm1lc3NhZ2Uoa2V5KSAvLyByZXNvbHZlIGZyb20gcGFyZW50IG1lc3NhZ2VzXG4gICAgICAgICAgICAgICAgOiBERUZBVUxUX01FU1NBR0VcbiAgICAgICAgICAgIDogbXNnO1xuICAgIH1cbiAgICBjb25zdCBfbW9kaWZpZXIgPSAobmFtZSkgPT4gb3B0aW9ucy5tb2RpZmllcnNcbiAgICAgICAgPyBvcHRpb25zLm1vZGlmaWVyc1tuYW1lXVxuICAgICAgICA6IERFRkFVTFRfTU9ESUZJRVI7XG4gICAgY29uc3Qgbm9ybWFsaXplID0gaXNGdW5jdGlvbihvcHRpb25zLnByb2Nlc3Nvcj8ubm9ybWFsaXplKVxuICAgICAgICA/IG9wdGlvbnMucHJvY2Vzc29yLm5vcm1hbGl6ZVxuICAgICAgICA6IERFRkFVTFRfTk9STUFMSVpFO1xuICAgIGNvbnN0IGludGVycG9sYXRlID0gaXNGdW5jdGlvbihvcHRpb25zLnByb2Nlc3Nvcj8uaW50ZXJwb2xhdGUpXG4gICAgICAgID8gb3B0aW9ucy5wcm9jZXNzb3IuaW50ZXJwb2xhdGVcbiAgICAgICAgOiBERUZBVUxUX0lOVEVSUE9MQVRFO1xuICAgIGNvbnN0IHR5cGUgPSBpc1N0cmluZyhvcHRpb25zLnByb2Nlc3Nvcj8udHlwZSlcbiAgICAgICAgPyBvcHRpb25zLnByb2Nlc3Nvci50eXBlXG4gICAgICAgIDogREVGQVVMVF9NRVNTQUdFX0RBVEFfVFlQRTtcbiAgICBjb25zdCBsaW5rZWQgPSAoa2V5LCAuLi5hcmdzKSA9PiB7XG4gICAgICAgIGNvbnN0IFthcmcxLCBhcmcyXSA9IGFyZ3M7XG4gICAgICAgIGxldCB0eXBlID0gJ3RleHQnO1xuICAgICAgICBsZXQgbW9kaWZpZXIgPSAnJztcbiAgICAgICAgaWYgKGFyZ3MubGVuZ3RoID09PSAxKSB7XG4gICAgICAgICAgICBpZiAoaXNPYmplY3QoYXJnMSkpIHtcbiAgICAgICAgICAgICAgICBtb2RpZmllciA9IGFyZzEubW9kaWZpZXIgfHwgbW9kaWZpZXI7XG4gICAgICAgICAgICAgICAgdHlwZSA9IGFyZzEudHlwZSB8fCB0eXBlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoaXNTdHJpbmcoYXJnMSkpIHtcbiAgICAgICAgICAgICAgICBtb2RpZmllciA9IGFyZzEgfHwgbW9kaWZpZXI7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoYXJncy5sZW5ndGggPT09IDIpIHtcbiAgICAgICAgICAgIGlmIChpc1N0cmluZyhhcmcxKSkge1xuICAgICAgICAgICAgICAgIG1vZGlmaWVyID0gYXJnMSB8fCBtb2RpZmllcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpc1N0cmluZyhhcmcyKSkge1xuICAgICAgICAgICAgICAgIHR5cGUgPSBhcmcyIHx8IHR5cGU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmV0ID0gbWVzc2FnZShrZXksIHRydWUpKGN0eCk7XG4gICAgICAgIC8vIElmIHRoZSBsaW5rZWQgbWVzc2FnZSBpcyBub3QgcmVzb2x2ZWQgKGVtcHR5IHN0cmluZyksIGZhbGwgYmFjayB0byB0aGUga2V5IGl0c2VsZlxuICAgICAgICBjb25zdCByZXNvbHZlZCA9IHJldCA9PT0gJycgfHwgcmV0ID09PSB1bmRlZmluZWQgPyBrZXkgOiByZXQ7XG4gICAgICAgIGNvbnN0IG1zZyA9IFxuICAgICAgICAvLyBUaGUgbWVzc2FnZSBpbiB2bm9kZSByZXNvbHZlZCB3aXRoIGxpbmtlZCBhcmUgcmV0dXJuZWQgYXMgYW4gYXJyYXkgYnkgcHJvY2Vzc29yLm5vbWFsaXplXG4gICAgICAgIHR5cGUgPT09ICd2bm9kZScgJiYgaXNBcnJheShyZXNvbHZlZCkgJiYgbW9kaWZpZXJcbiAgICAgICAgICAgID8gcmVzb2x2ZWRbMF1cbiAgICAgICAgICAgIDogcmVzb2x2ZWQ7XG4gICAgICAgIHJldHVybiBtb2RpZmllciA/IF9tb2RpZmllcihtb2RpZmllcikobXNnLCB0eXBlKSA6IG1zZztcbiAgICB9O1xuICAgIGNvbnN0IGN0eCA9IHtcbiAgICAgICAgW1wibGlzdFwiIC8qIEhlbHBlck5hbWVNYXAuTElTVCAqL106IGxpc3QsXG4gICAgICAgIFtcIm5hbWVkXCIgLyogSGVscGVyTmFtZU1hcC5OQU1FRCAqL106IG5hbWVkLFxuICAgICAgICBbXCJwbHVyYWxcIiAvKiBIZWxwZXJOYW1lTWFwLlBMVVJBTCAqL106IHBsdXJhbCxcbiAgICAgICAgW1wibGlua2VkXCIgLyogSGVscGVyTmFtZU1hcC5MSU5LRUQgKi9dOiBsaW5rZWQsXG4gICAgICAgIFtcIm1lc3NhZ2VcIiAvKiBIZWxwZXJOYW1lTWFwLk1FU1NBR0UgKi9dOiBtZXNzYWdlLFxuICAgICAgICBbXCJ0eXBlXCIgLyogSGVscGVyTmFtZU1hcC5UWVBFICovXTogdHlwZSxcbiAgICAgICAgW1wiaW50ZXJwb2xhdGVcIiAvKiBIZWxwZXJOYW1lTWFwLklOVEVSUE9MQVRFICovXTogaW50ZXJwb2xhdGUsXG4gICAgICAgIFtcIm5vcm1hbGl6ZVwiIC8qIEhlbHBlck5hbWVNYXAuTk9STUFMSVpFICovXTogbm9ybWFsaXplLFxuICAgICAgICBbXCJ2YWx1ZXNcIiAvKiBIZWxwZXJOYW1lTWFwLlZBTFVFUyAqL106IGFzc2lnbihjcmVhdGUoKSwgX2xpc3QsIF9uYW1lZClcbiAgICB9O1xuICAgIHJldHVybiBjdHg7XG59XG5cbmNvbnN0IE5PT1BfTUVTU0FHRV9GVU5DVElPTiA9ICgpID0+ICcnO1xuY29uc3QgaXNNZXNzYWdlRnVuY3Rpb24gPSAodmFsKSA9PiBpc0Z1bmN0aW9uKHZhbCk7XG4vLyBpbXBsZW1lbnRhdGlvbiBvZiBgdHJhbnNsYXRlYCBmdW5jdGlvblxuZnVuY3Rpb24gdHJhbnNsYXRlKGNvbnRleHQsIC4uLmFyZ3MpIHtcbiAgICBjb25zdCB7IGZhbGxiYWNrRm9ybWF0LCBwb3N0VHJhbnNsYXRpb24sIHVucmVzb2x2aW5nLCBtZXNzYWdlQ29tcGlsZXIsIGZhbGxiYWNrTG9jYWxlLCBtZXNzYWdlcyB9ID0gY29udGV4dDtcbiAgICBjb25zdCBba2V5LCBvcHRpb25zXSA9IHBhcnNlVHJhbnNsYXRlQXJncyguLi5hcmdzKTtcbiAgICBjb25zdCBtaXNzaW5nV2FybiA9IGlzQm9vbGVhbihvcHRpb25zLm1pc3NpbmdXYXJuKVxuICAgICAgICA/IG9wdGlvbnMubWlzc2luZ1dhcm5cbiAgICAgICAgOiBjb250ZXh0Lm1pc3NpbmdXYXJuO1xuICAgIGNvbnN0IGZhbGxiYWNrV2FybiA9IGlzQm9vbGVhbihvcHRpb25zLmZhbGxiYWNrV2FybilcbiAgICAgICAgPyBvcHRpb25zLmZhbGxiYWNrV2FyblxuICAgICAgICA6IGNvbnRleHQuZmFsbGJhY2tXYXJuO1xuICAgIGNvbnN0IGVzY2FwZVBhcmFtZXRlciA9IGlzQm9vbGVhbihvcHRpb25zLmVzY2FwZVBhcmFtZXRlcilcbiAgICAgICAgPyBvcHRpb25zLmVzY2FwZVBhcmFtZXRlclxuICAgICAgICA6IGNvbnRleHQuZXNjYXBlUGFyYW1ldGVyO1xuICAgIGNvbnN0IHJlc29sdmVkTWVzc2FnZSA9ICEhb3B0aW9ucy5yZXNvbHZlZE1lc3NhZ2U7XG4gICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgY29uc3QgZGVmYXVsdE1zZ09yS2V5ID0gaXNTdHJpbmcob3B0aW9ucy5kZWZhdWx0KSB8fCBpc0Jvb2xlYW4ob3B0aW9ucy5kZWZhdWx0KSAvLyBkZWZhdWx0IGJ5IGZ1bmN0aW9uIG9wdGlvblxuICAgICAgICA/ICFpc0Jvb2xlYW4ob3B0aW9ucy5kZWZhdWx0KVxuICAgICAgICAgICAgPyBvcHRpb25zLmRlZmF1bHRcbiAgICAgICAgICAgIDogKCFtZXNzYWdlQ29tcGlsZXIgPyAoKSA9PiBrZXkgOiBrZXkpXG4gICAgICAgIDogZmFsbGJhY2tGb3JtYXQgLy8gZGVmYXVsdCBieSBgZmFsbGJhY2tGb3JtYXRgIG9wdGlvblxuICAgICAgICAgICAgPyAoIW1lc3NhZ2VDb21waWxlciA/ICgpID0+IGtleSA6IGtleSlcbiAgICAgICAgICAgIDogbnVsbDtcbiAgICBjb25zdCBlbmFibGVEZWZhdWx0TXNnID0gZmFsbGJhY2tGb3JtYXQgfHxcbiAgICAgICAgKGRlZmF1bHRNc2dPcktleSAhPSBudWxsICYmXG4gICAgICAgICAgICAoaXNTdHJpbmcoZGVmYXVsdE1zZ09yS2V5KSB8fCBpc0Z1bmN0aW9uKGRlZmF1bHRNc2dPcktleSkpKTtcbiAgICBjb25zdCBsb2NhbGUgPSBnZXRMb2NhbGUoY29udGV4dCwgb3B0aW9ucyk7XG4gICAgLy8gZXNjYXBlIHBhcmFtc1xuICAgIGVzY2FwZVBhcmFtZXRlciAmJiBlc2NhcGVQYXJhbXMob3B0aW9ucyk7XG4gICAgLy8gcmVzb2x2ZSBtZXNzYWdlIGZvcm1hdFxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBwcmVmZXItY29uc3RcbiAgICBsZXQgW2Zvcm1hdFNjb3BlLCB0YXJnZXRMb2NhbGUsIG1lc3NhZ2VdID0gIXJlc29sdmVkTWVzc2FnZVxuICAgICAgICA/IHJlc29sdmVNZXNzYWdlRm9ybWF0KGNvbnRleHQsIGtleSwgbG9jYWxlLCBmYWxsYmFja0xvY2FsZSwgZmFsbGJhY2tXYXJuLCBtaXNzaW5nV2FybilcbiAgICAgICAgOiBbXG4gICAgICAgICAgICBrZXksXG4gICAgICAgICAgICBsb2NhbGUsXG4gICAgICAgICAgICBtZXNzYWdlc1tsb2NhbGVdIHx8IGNyZWF0ZSgpXG4gICAgICAgIF07XG4gICAgLy8gTk9URTpcbiAgICAvLyAgRml4IHRvIHdvcmsgYXJvdW5kIGBzc3JUcmFuc2Zyb21gIGJ1ZyBpbiBWaXRlLlxuICAgIC8vICBodHRwczovL2dpdGh1Yi5jb20vdml0ZWpzL3ZpdGUvaXNzdWVzLzQzMDZcbiAgICAvLyAgVG8gZ2V0IGFyb3VuZCB0aGlzLCB1c2UgdGVtcG9yYXJ5IHZhcmlhYmxlcy5cbiAgICAvLyAgaHR0cHM6Ly9naXRodWIuY29tL251eHQvZnJhbWV3b3JrL2lzc3Vlcy8xNDYxI2lzc3VlY29tbWVudC05NTQ2MDYyNDNcbiAgICBsZXQgZm9ybWF0ID0gZm9ybWF0U2NvcGU7XG4gICAgLy8gaWYgeW91IHVzZSBkZWZhdWx0IG1lc3NhZ2UsIHNldCBpdCBhcyBtZXNzYWdlIGZvcm1hdCFcbiAgICBsZXQgY2FjaGVCYXNlS2V5ID0ga2V5O1xuICAgIGlmICghcmVzb2x2ZWRNZXNzYWdlICYmXG4gICAgICAgICEoaXNTdHJpbmcoZm9ybWF0KSB8fFxuICAgICAgICAgICAgaXNNZXNzYWdlQVNUKGZvcm1hdCkgfHxcbiAgICAgICAgICAgIGlzTWVzc2FnZUZ1bmN0aW9uKGZvcm1hdCkpKSB7XG4gICAgICAgIGlmIChlbmFibGVEZWZhdWx0TXNnKSB7XG4gICAgICAgICAgICBmb3JtYXQgPSBkZWZhdWx0TXNnT3JLZXk7XG4gICAgICAgICAgICBjYWNoZUJhc2VLZXkgPSBmb3JtYXQ7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gY2hlY2tpbmcgbWVzc2FnZSBmb3JtYXQgYW5kIHRhcmdldCBsb2NhbGVcbiAgICBpZiAoIXJlc29sdmVkTWVzc2FnZSAmJlxuICAgICAgICAoIShpc1N0cmluZyhmb3JtYXQpIHx8XG4gICAgICAgICAgICBpc01lc3NhZ2VBU1QoZm9ybWF0KSB8fFxuICAgICAgICAgICAgaXNNZXNzYWdlRnVuY3Rpb24oZm9ybWF0KSkgfHxcbiAgICAgICAgICAgICFpc1N0cmluZyh0YXJnZXRMb2NhbGUpKSkge1xuICAgICAgICByZXR1cm4gdW5yZXNvbHZpbmcgPyBOT1RfUkVPU0xWRUQgOiBrZXk7XG4gICAgfVxuICAgIC8vIFRPRE86IHJlZmFjdG9yXG4gICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSAmJiBpc1N0cmluZyhmb3JtYXQpICYmIGNvbnRleHQubWVzc2FnZUNvbXBpbGVyID09IG51bGwpIHtcbiAgICAgICAgd2FybihgVGhlIG1lc3NhZ2UgZm9ybWF0IGNvbXBpbGF0aW9uIGlzIG5vdCBzdXBwb3J0ZWQgaW4gdGhpcyBidWlsZC4gYCArXG4gICAgICAgICAgICBgQmVjYXVzZSBtZXNzYWdlIGNvbXBpbGVyIGlzbid0IGluY2x1ZGVkLiBgICtcbiAgICAgICAgICAgIGBZb3UgbmVlZCB0byBwcmUtY29tcGlsYXRpb24gYWxsIG1lc3NhZ2UgZm9ybWF0LiBgICtcbiAgICAgICAgICAgIGBTbyB0cmFuc2xhdGUgZnVuY3Rpb24gcmV0dXJuICcke2tleX0nLmApO1xuICAgICAgICByZXR1cm4ga2V5O1xuICAgIH1cbiAgICAvLyBzZXR1cCBjb21waWxlIGVycm9yIGRldGVjdGluZ1xuICAgIGxldCBvY2N1cnJlZCA9IGZhbHNlO1xuICAgIGNvbnN0IG9uRXJyb3IgPSAoKSA9PiB7XG4gICAgICAgIG9jY3VycmVkID0gdHJ1ZTtcbiAgICB9O1xuICAgIC8vIGNvbXBpbGUgbWVzc2FnZSBmb3JtYXRcbiAgICBjb25zdCBtc2cgPSAhaXNNZXNzYWdlRnVuY3Rpb24oZm9ybWF0KVxuICAgICAgICA/IGNvbXBpbGVNZXNzYWdlRm9ybWF0KGNvbnRleHQsIGtleSwgdGFyZ2V0TG9jYWxlLCBmb3JtYXQsIGNhY2hlQmFzZUtleSwgb25FcnJvcilcbiAgICAgICAgOiBmb3JtYXQ7XG4gICAgLy8gaWYgb2NjdXJyZWQgY29tcGlsZSBlcnJvciwgcmV0dXJuIHRoZSBtZXNzYWdlIGZvcm1hdFxuICAgIGlmIChvY2N1cnJlZCkge1xuICAgICAgICByZXR1cm4gZm9ybWF0O1xuICAgIH1cbiAgICAvLyBldmFsdWF0ZSBtZXNzYWdlIHdpdGggY29udGV4dFxuICAgIGNvbnN0IGN0eE9wdGlvbnMgPSBnZXRNZXNzYWdlQ29udGV4dE9wdGlvbnMoY29udGV4dCwgdGFyZ2V0TG9jYWxlLCBtZXNzYWdlLCBvcHRpb25zKTtcbiAgICBjb25zdCBtc2dDb250ZXh0ID0gY3JlYXRlTWVzc2FnZUNvbnRleHQoY3R4T3B0aW9ucyk7XG4gICAgY29uc3QgbWVzc2FnZWQgPSBldmFsdWF0ZU1lc3NhZ2UoY29udGV4dCwgbXNnLCBtc2dDb250ZXh0KTtcbiAgICAvLyBpZiB1c2UgcG9zdCB0cmFuc2xhdGlvbiBvcHRpb24sIHByb2NlZWQgaXQgd2l0aCBoYW5kbGVyXG4gICAgbGV0IHJldCA9IHBvc3RUcmFuc2xhdGlvblxuICAgICAgICA/IHBvc3RUcmFuc2xhdGlvbihtZXNzYWdlZCwga2V5KVxuICAgICAgICA6IG1lc3NhZ2VkO1xuICAgIC8vIGFwcGx5IEhUTUwgc2FuaXRpemF0aW9uIGZvciBzZWN1cml0eVxuICAgIGlmIChlc2NhcGVQYXJhbWV0ZXIgJiYgaXNTdHJpbmcocmV0KSkge1xuICAgICAgICByZXQgPSBzYW5pdGl6ZVRyYW5zbGF0ZWRIdG1sKHJldCk7XG4gICAgfVxuICAgIC8vIE5PVEU6IGV4cGVyaW1lbnRhbCAhIVxuICAgIGlmICgocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgfHwgX19JTlRMSUZZX1BST0RfREVWVE9PTFNfXykge1xuICAgICAgICAvLyBwcmV0dGllci1pZ25vcmVcbiAgICAgICAgY29uc3QgcGF5bG9hZHMgPSB7XG4gICAgICAgICAgICB0aW1lc3RhbXA6IERhdGUubm93KCksXG4gICAgICAgICAgICBrZXk6IGlzU3RyaW5nKGtleSlcbiAgICAgICAgICAgICAgICA/IGtleVxuICAgICAgICAgICAgICAgIDogaXNNZXNzYWdlRnVuY3Rpb24oZm9ybWF0KVxuICAgICAgICAgICAgICAgICAgICA/IGZvcm1hdC5rZXlcbiAgICAgICAgICAgICAgICAgICAgOiAnJyxcbiAgICAgICAgICAgIGxvY2FsZTogdGFyZ2V0TG9jYWxlIHx8IChpc01lc3NhZ2VGdW5jdGlvbihmb3JtYXQpXG4gICAgICAgICAgICAgICAgPyBmb3JtYXQubG9jYWxlXG4gICAgICAgICAgICAgICAgOiAnJyksXG4gICAgICAgICAgICBmb3JtYXQ6IGlzU3RyaW5nKGZvcm1hdClcbiAgICAgICAgICAgICAgICA/IGZvcm1hdFxuICAgICAgICAgICAgICAgIDogaXNNZXNzYWdlRnVuY3Rpb24oZm9ybWF0KVxuICAgICAgICAgICAgICAgICAgICA/IGZvcm1hdC5zb3VyY2VcbiAgICAgICAgICAgICAgICAgICAgOiAnJyxcbiAgICAgICAgICAgIG1lc3NhZ2U6IHJldFxuICAgICAgICB9O1xuICAgICAgICBwYXlsb2Fkcy5tZXRhID0gYXNzaWduKHt9LCBjb250ZXh0Ll9fbWV0YSwgZ2V0QWRkaXRpb25hbE1ldGEoKSB8fCB7fSk7XG4gICAgICAgIHRyYW5zbGF0ZURldlRvb2xzKHBheWxvYWRzKTtcbiAgICB9XG4gICAgcmV0dXJuIHJldDtcbn1cbmZ1bmN0aW9uIGVzY2FwZVBhcmFtcyhvcHRpb25zKSB7XG4gICAgaWYgKGlzQXJyYXkob3B0aW9ucy5saXN0KSkge1xuICAgICAgICBvcHRpb25zLmxpc3QgPSBvcHRpb25zLmxpc3QubWFwKGl0ZW0gPT4gaXNTdHJpbmcoaXRlbSkgPyBlc2NhcGVIdG1sKGl0ZW0pIDogaXRlbSk7XG4gICAgfVxuICAgIGVsc2UgaWYgKGlzT2JqZWN0KG9wdGlvbnMubmFtZWQpKSB7XG4gICAgICAgIE9iamVjdC5rZXlzKG9wdGlvbnMubmFtZWQpLmZvckVhY2goa2V5ID0+IHtcbiAgICAgICAgICAgIGlmIChpc1N0cmluZyhvcHRpb25zLm5hbWVkW2tleV0pKSB7XG4gICAgICAgICAgICAgICAgb3B0aW9ucy5uYW1lZFtrZXldID0gZXNjYXBlSHRtbChvcHRpb25zLm5hbWVkW2tleV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG59XG5mdW5jdGlvbiByZXNvbHZlTWVzc2FnZUZvcm1hdChjb250ZXh0LCBrZXksIGxvY2FsZSwgZmFsbGJhY2tMb2NhbGUsIGZhbGxiYWNrV2FybiwgbWlzc2luZ1dhcm4pIHtcbiAgICBjb25zdCB7IG1lc3NhZ2VzLCBvbldhcm4sIG1lc3NhZ2VSZXNvbHZlcjogcmVzb2x2ZVZhbHVlLCBsb2NhbGVGYWxsYmFja2VyIH0gPSBjb250ZXh0O1xuICAgIGNvbnN0IGxvY2FsZXMgPSBsb2NhbGVGYWxsYmFja2VyKGNvbnRleHQsIGZhbGxiYWNrTG9jYWxlLCBsb2NhbGUpOyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbiAgICBsZXQgbWVzc2FnZSA9IGNyZWF0ZSgpO1xuICAgIGxldCB0YXJnZXRMb2NhbGU7XG4gICAgbGV0IGZvcm1hdCA9IG51bGw7XG4gICAgbGV0IGZyb20gPSBsb2NhbGU7XG4gICAgbGV0IHRvID0gbnVsbDtcbiAgICBjb25zdCB0eXBlID0gJ3RyYW5zbGF0ZSc7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsb2NhbGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHRhcmdldExvY2FsZSA9IHRvID0gbG9jYWxlc1tpXTtcbiAgICAgICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSAmJlxuICAgICAgICAgICAgbG9jYWxlICE9PSB0YXJnZXRMb2NhbGUgJiZcbiAgICAgICAgICAgICFpc0FsbW9zdFNhbWVMb2NhbGUobG9jYWxlLCB0YXJnZXRMb2NhbGUpICYmXG4gICAgICAgICAgICBpc1RyYW5zbGF0ZUZhbGxiYWNrV2FybihmYWxsYmFja1dhcm4sIGtleSkpIHtcbiAgICAgICAgICAgIG9uV2FybihnZXRXYXJuTWVzc2FnZShDb3JlV2FybkNvZGVzLkZBTExCQUNLX1RPX1RSQU5TTEFURSwge1xuICAgICAgICAgICAgICAgIGtleSxcbiAgICAgICAgICAgICAgICB0YXJnZXQ6IHRhcmdldExvY2FsZVxuICAgICAgICAgICAgfSkpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGVtaXR0ZXIgPSAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJylcbiAgICAgICAgICAgID8gY29udGV4dC5fX3ZfZW1pdHRlclxuICAgICAgICAgICAgOiB1bmRlZmluZWQ7XG4gICAgICAgIC8vIGZvciB2dWUtZGV2dG9vbHMgdGltZWxpbmUgZXZlbnRcbiAgICAgICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSAmJiBsb2NhbGUgIT09IHRhcmdldExvY2FsZSkge1xuICAgICAgICAgICAgaWYgKGVtaXR0ZXIpIHtcbiAgICAgICAgICAgICAgICBlbWl0dGVyLmVtaXQoJ2ZhbGxiYWNrJywge1xuICAgICAgICAgICAgICAgICAgICB0eXBlLFxuICAgICAgICAgICAgICAgICAgICBrZXksXG4gICAgICAgICAgICAgICAgICAgIGZyb20sXG4gICAgICAgICAgICAgICAgICAgIHRvLFxuICAgICAgICAgICAgICAgICAgICBncm91cElkOiBgJHt0eXBlfToke2tleX1gXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgbWVzc2FnZSA9XG4gICAgICAgICAgICBtZXNzYWdlc1t0YXJnZXRMb2NhbGVdIHx8IGNyZWF0ZSgpO1xuICAgICAgICAvLyBmb3IgdnVlLWRldnRvb2xzIHRpbWVsaW5lIGV2ZW50XG4gICAgICAgIGxldCBzdGFydCA9IG51bGw7XG4gICAgICAgIGxldCBzdGFydFRhZztcbiAgICAgICAgbGV0IGVuZFRhZztcbiAgICAgICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSAmJiBpbkJyb3dzZXIgJiYgZW1pdHRlcikge1xuICAgICAgICAgICAgc3RhcnQgPSB3aW5kb3cucGVyZm9ybWFuY2Uubm93KCk7XG4gICAgICAgICAgICBzdGFydFRhZyA9ICdpbnRsaWZ5LW1lc3NhZ2UtcmVzb2x2ZS1zdGFydCc7XG4gICAgICAgICAgICBlbmRUYWcgPSAnaW50bGlmeS1tZXNzYWdlLXJlc29sdmUtZW5kJztcbiAgICAgICAgICAgIG1hcmsgJiYgbWFyayhzdGFydFRhZyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKChmb3JtYXQgPSByZXNvbHZlVmFsdWUobWVzc2FnZSwga2V5KSkgPT09IG51bGwpIHtcbiAgICAgICAgICAgIC8vIGlmIG51bGwsIHJlc29sdmUgd2l0aCBvYmplY3Qga2V5IHBhdGhcbiAgICAgICAgICAgIGZvcm1hdCA9IG1lc3NhZ2Vba2V5XTsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgICAgIH1cbiAgICAgICAgLy8gZm9yIHZ1ZS1kZXZ0b29scyB0aW1lbGluZSBldmVudFxuICAgICAgICBpZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpICYmIGluQnJvd3NlciAmJiBlbWl0dGVyKSB7XG4gICAgICAgICAgICBjb25zdCBlbmQgPSB3aW5kb3cucGVyZm9ybWFuY2Uubm93KCk7XG4gICAgICAgICAgICBpZiAoZW1pdHRlciAmJiBzdGFydCAmJiBmb3JtYXQpIHtcbiAgICAgICAgICAgICAgICBlbWl0dGVyLmVtaXQoJ21lc3NhZ2UtcmVzb2x2ZScsIHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogJ21lc3NhZ2UtcmVzb2x2ZScsXG4gICAgICAgICAgICAgICAgICAgIGtleSxcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZTogZm9ybWF0LFxuICAgICAgICAgICAgICAgICAgICB0aW1lOiBlbmQgLSBzdGFydCxcbiAgICAgICAgICAgICAgICAgICAgZ3JvdXBJZDogYCR7dHlwZX06JHtrZXl9YFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHN0YXJ0VGFnICYmIGVuZFRhZyAmJiBtYXJrICYmIG1lYXN1cmUpIHtcbiAgICAgICAgICAgICAgICBtYXJrKGVuZFRhZyk7XG4gICAgICAgICAgICAgICAgbWVhc3VyZSgnaW50bGlmeSBtZXNzYWdlIHJlc29sdmUnLCBzdGFydFRhZywgZW5kVGFnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNTdHJpbmcoZm9ybWF0KSB8fCBpc01lc3NhZ2VBU1QoZm9ybWF0KSB8fCBpc01lc3NhZ2VGdW5jdGlvbihmb3JtYXQpKSB7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWlzSW1wbGljaXRGYWxsYmFjayh0YXJnZXRMb2NhbGUsIGxvY2FsZXMpKSB7XG4gICAgICAgICAgICBjb25zdCBtaXNzaW5nUmV0ID0gaGFuZGxlTWlzc2luZyhjb250ZXh0LCAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbiAgICAgICAgICAgIGtleSwgdGFyZ2V0TG9jYWxlLCBtaXNzaW5nV2FybiwgdHlwZSk7XG4gICAgICAgICAgICBpZiAobWlzc2luZ1JldCAhPT0ga2V5KSB7XG4gICAgICAgICAgICAgICAgZm9ybWF0ID0gbWlzc2luZ1JldDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBmcm9tID0gdG87XG4gICAgfVxuICAgIHJldHVybiBbZm9ybWF0LCB0YXJnZXRMb2NhbGUsIG1lc3NhZ2VdO1xufVxuZnVuY3Rpb24gY29tcGlsZU1lc3NhZ2VGb3JtYXQoY29udGV4dCwga2V5LCB0YXJnZXRMb2NhbGUsIGZvcm1hdCwgY2FjaGVCYXNlS2V5LCBvbkVycm9yKSB7XG4gICAgY29uc3QgeyBtZXNzYWdlQ29tcGlsZXIsIHdhcm5IdG1sTWVzc2FnZSB9ID0gY29udGV4dDtcbiAgICBpZiAoaXNNZXNzYWdlRnVuY3Rpb24oZm9ybWF0KSkge1xuICAgICAgICBjb25zdCBtc2cgPSBmb3JtYXQ7XG4gICAgICAgIG1zZy5sb2NhbGUgPSBtc2cubG9jYWxlIHx8IHRhcmdldExvY2FsZTtcbiAgICAgICAgbXNnLmtleSA9IG1zZy5rZXkgfHwga2V5O1xuICAgICAgICByZXR1cm4gbXNnO1xuICAgIH1cbiAgICBpZiAobWVzc2FnZUNvbXBpbGVyID09IG51bGwpIHtcbiAgICAgICAgY29uc3QgbXNnID0gKCgpID0+IGZvcm1hdCk7XG4gICAgICAgIG1zZy5sb2NhbGUgPSB0YXJnZXRMb2NhbGU7XG4gICAgICAgIG1zZy5rZXkgPSBrZXk7XG4gICAgICAgIHJldHVybiBtc2c7XG4gICAgfVxuICAgIC8vIGZvciB2dWUtZGV2dG9vbHMgdGltZWxpbmUgZXZlbnRcbiAgICBjb25zdCBlbWl0dGVyID0gKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpXG4gICAgICAgID8gY29udGV4dC5fX3ZfZW1pdHRlclxuICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICBsZXQgc3RhcnQgPSBudWxsO1xuICAgIGxldCBzdGFydFRhZztcbiAgICBsZXQgZW5kVGFnO1xuICAgIGlmICgocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgJiYgaW5Ccm93c2VyICYmIGVtaXR0ZXIpIHtcbiAgICAgICAgc3RhcnQgPSB3aW5kb3cucGVyZm9ybWFuY2Uubm93KCk7XG4gICAgICAgIHN0YXJ0VGFnID0gJ2ludGxpZnktbWVzc2FnZS1jb21waWxhdGlvbi1zdGFydCc7XG4gICAgICAgIGVuZFRhZyA9ICdpbnRsaWZ5LW1lc3NhZ2UtY29tcGlsYXRpb24tZW5kJztcbiAgICAgICAgbWFyayAmJiBtYXJrKHN0YXJ0VGFnKTtcbiAgICB9XG4gICAgY29uc3QgbXNnID0gbWVzc2FnZUNvbXBpbGVyKGZvcm1hdCwgZ2V0Q29tcGlsZUNvbnRleHQoY29udGV4dCwgdGFyZ2V0TG9jYWxlLCBjYWNoZUJhc2VLZXksIGZvcm1hdCwgd2Fybkh0bWxNZXNzYWdlLCBvbkVycm9yKSk7XG4gICAgLy8gZm9yIHZ1ZS1kZXZ0b29scyB0aW1lbGluZSBldmVudFxuICAgIGlmICgocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgJiYgaW5Ccm93c2VyICYmIGVtaXR0ZXIpIHtcbiAgICAgICAgY29uc3QgZW5kID0gd2luZG93LnBlcmZvcm1hbmNlLm5vdygpO1xuICAgICAgICBpZiAoZW1pdHRlciAmJiBzdGFydCkge1xuICAgICAgICAgICAgZW1pdHRlci5lbWl0KCdtZXNzYWdlLWNvbXBpbGF0aW9uJywge1xuICAgICAgICAgICAgICAgIHR5cGU6ICdtZXNzYWdlLWNvbXBpbGF0aW9uJyxcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBmb3JtYXQsXG4gICAgICAgICAgICAgICAgdGltZTogZW5kIC0gc3RhcnQsXG4gICAgICAgICAgICAgICAgZ3JvdXBJZDogYCR7J3RyYW5zbGF0ZSd9OiR7a2V5fWBcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzdGFydFRhZyAmJiBlbmRUYWcgJiYgbWFyayAmJiBtZWFzdXJlKSB7XG4gICAgICAgICAgICBtYXJrKGVuZFRhZyk7XG4gICAgICAgICAgICBtZWFzdXJlKCdpbnRsaWZ5IG1lc3NhZ2UgY29tcGlsYXRpb24nLCBzdGFydFRhZywgZW5kVGFnKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBtc2cubG9jYWxlID0gdGFyZ2V0TG9jYWxlO1xuICAgIG1zZy5rZXkgPSBrZXk7XG4gICAgbXNnLnNvdXJjZSA9IGZvcm1hdDtcbiAgICByZXR1cm4gbXNnO1xufVxuZnVuY3Rpb24gZXZhbHVhdGVNZXNzYWdlKGNvbnRleHQsIG1zZywgbXNnQ3R4KSB7XG4gICAgLy8gZm9yIHZ1ZS1kZXZ0b29scyB0aW1lbGluZSBldmVudFxuICAgIGNvbnN0IGVtaXR0ZXIgPSAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJylcbiAgICAgICAgPyBjb250ZXh0Ll9fdl9lbWl0dGVyXG4gICAgICAgIDogdW5kZWZpbmVkO1xuICAgIGxldCBzdGFydCA9IG51bGw7XG4gICAgbGV0IHN0YXJ0VGFnO1xuICAgIGxldCBlbmRUYWc7XG4gICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSAmJiBpbkJyb3dzZXIgJiYgZW1pdHRlcikge1xuICAgICAgICBzdGFydCA9IHdpbmRvdy5wZXJmb3JtYW5jZS5ub3coKTtcbiAgICAgICAgc3RhcnRUYWcgPSAnaW50bGlmeS1tZXNzYWdlLWV2YWx1YXRpb24tc3RhcnQnO1xuICAgICAgICBlbmRUYWcgPSAnaW50bGlmeS1tZXNzYWdlLWV2YWx1YXRpb24tZW5kJztcbiAgICAgICAgbWFyayAmJiBtYXJrKHN0YXJ0VGFnKTtcbiAgICB9XG4gICAgY29uc3QgbWVzc2FnZWQgPSBtc2cobXNnQ3R4KTtcbiAgICAvLyBmb3IgdnVlLWRldnRvb2xzIHRpbWVsaW5lIGV2ZW50XG4gICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSAmJiBpbkJyb3dzZXIgJiYgZW1pdHRlcikge1xuICAgICAgICBjb25zdCBlbmQgPSB3aW5kb3cucGVyZm9ybWFuY2Uubm93KCk7XG4gICAgICAgIGlmIChlbWl0dGVyICYmIHN0YXJ0KSB7XG4gICAgICAgICAgICBlbWl0dGVyLmVtaXQoJ21lc3NhZ2UtZXZhbHVhdGlvbicsIHtcbiAgICAgICAgICAgICAgICB0eXBlOiAnbWVzc2FnZS1ldmFsdWF0aW9uJyxcbiAgICAgICAgICAgICAgICB2YWx1ZTogbWVzc2FnZWQsXG4gICAgICAgICAgICAgICAgdGltZTogZW5kIC0gc3RhcnQsXG4gICAgICAgICAgICAgICAgZ3JvdXBJZDogYCR7J3RyYW5zbGF0ZSd9OiR7bXNnLmtleX1gXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc3RhcnRUYWcgJiYgZW5kVGFnICYmIG1hcmsgJiYgbWVhc3VyZSkge1xuICAgICAgICAgICAgbWFyayhlbmRUYWcpO1xuICAgICAgICAgICAgbWVhc3VyZSgnaW50bGlmeSBtZXNzYWdlIGV2YWx1YXRpb24nLCBzdGFydFRhZywgZW5kVGFnKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbWVzc2FnZWQ7XG59XG4vKiogQGludGVybmFsICovXG5mdW5jdGlvbiBwYXJzZVRyYW5zbGF0ZUFyZ3MoLi4uYXJncykge1xuICAgIGNvbnN0IFthcmcxLCBhcmcyLCBhcmczXSA9IGFyZ3M7XG4gICAgY29uc3Qgb3B0aW9ucyA9IGNyZWF0ZSgpO1xuICAgIGlmICghaXNTdHJpbmcoYXJnMSkgJiZcbiAgICAgICAgIWlzTnVtYmVyKGFyZzEpICYmXG4gICAgICAgICFpc01lc3NhZ2VGdW5jdGlvbihhcmcxKSAmJlxuICAgICAgICAhaXNNZXNzYWdlQVNUKGFyZzEpKSB7XG4gICAgICAgIHRocm93IGNyZWF0ZUNvcmVFcnJvcihDb3JlRXJyb3JDb2Rlcy5JTlZBTElEX0FSR1VNRU5UKTtcbiAgICB9XG4gICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgY29uc3Qga2V5ID0gaXNOdW1iZXIoYXJnMSlcbiAgICAgICAgPyBTdHJpbmcoYXJnMSlcbiAgICAgICAgOiBpc01lc3NhZ2VGdW5jdGlvbihhcmcxKVxuICAgICAgICAgICAgPyBhcmcxXG4gICAgICAgICAgICA6IGFyZzE7XG4gICAgaWYgKGlzTnVtYmVyKGFyZzIpKSB7XG4gICAgICAgIG9wdGlvbnMucGx1cmFsID0gYXJnMjtcbiAgICB9XG4gICAgZWxzZSBpZiAoaXNTdHJpbmcoYXJnMikpIHtcbiAgICAgICAgb3B0aW9ucy5kZWZhdWx0ID0gYXJnMjtcbiAgICB9XG4gICAgZWxzZSBpZiAoaXNQbGFpbk9iamVjdChhcmcyKSAmJiAhaXNFbXB0eU9iamVjdChhcmcyKSkge1xuICAgICAgICBvcHRpb25zLm5hbWVkID0gYXJnMjtcbiAgICB9XG4gICAgZWxzZSBpZiAoaXNBcnJheShhcmcyKSkge1xuICAgICAgICBvcHRpb25zLmxpc3QgPSBhcmcyO1xuICAgIH1cbiAgICBpZiAoaXNOdW1iZXIoYXJnMykpIHtcbiAgICAgICAgb3B0aW9ucy5wbHVyYWwgPSBhcmczO1xuICAgIH1cbiAgICBlbHNlIGlmIChpc1N0cmluZyhhcmczKSkge1xuICAgICAgICBvcHRpb25zLmRlZmF1bHQgPSBhcmczO1xuICAgIH1cbiAgICBlbHNlIGlmIChpc1BsYWluT2JqZWN0KGFyZzMpKSB7XG4gICAgICAgIGFzc2lnbihvcHRpb25zLCBhcmczKTtcbiAgICB9XG4gICAgcmV0dXJuIFtrZXksIG9wdGlvbnNdO1xufVxuZnVuY3Rpb24gZ2V0Q29tcGlsZUNvbnRleHQoY29udGV4dCwgbG9jYWxlLCBrZXksIHNvdXJjZSwgd2Fybkh0bWxNZXNzYWdlLCBvbkVycm9yKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgbG9jYWxlLFxuICAgICAgICBrZXksXG4gICAgICAgIHdhcm5IdG1sTWVzc2FnZSxcbiAgICAgICAgb25FcnJvcjogKGVycikgPT4ge1xuICAgICAgICAgICAgb25FcnJvciAmJiBvbkVycm9yKGVycik7XG4gICAgICAgICAgICBpZiAoKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgX3NvdXJjZSA9IGdldFNvdXJjZUZvckNvZGVGcmFtZShzb3VyY2UpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvZGVGcmFtZSA9IGVyci5sb2NhdGlvbiAmJlxuICAgICAgICAgICAgICAgICAgICBfc291cmNlICYmXG4gICAgICAgICAgICAgICAgICAgIGdlbmVyYXRlQ29kZUZyYW1lKF9zb3VyY2UsIGVyci5sb2NhdGlvbi5zdGFydC5vZmZzZXQsIGVyci5sb2NhdGlvbi5lbmQub2Zmc2V0KTtcbiAgICAgICAgICAgICAgICBjb25zdCBlbWl0dGVyID0gY29udGV4dC5fX3ZfZW1pdHRlcjtcbiAgICAgICAgICAgICAgICBpZiAoZW1pdHRlciAmJiBfc291cmNlKSB7XG4gICAgICAgICAgICAgICAgICAgIGVtaXR0ZXIuZW1pdCgnY29tcGlsZS1lcnJvcicsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IF9zb3VyY2UsXG4gICAgICAgICAgICAgICAgICAgICAgICBlcnJvcjogZXJyLm1lc3NhZ2UsXG4gICAgICAgICAgICAgICAgICAgICAgICBzdGFydDogZXJyLmxvY2F0aW9uICYmIGVyci5sb2NhdGlvbi5zdGFydC5vZmZzZXQsXG4gICAgICAgICAgICAgICAgICAgICAgICBlbmQ6IGVyci5sb2NhdGlvbiAmJiBlcnIubG9jYXRpb24uZW5kLm9mZnNldCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGdyb3VwSWQ6IGAkeyd0cmFuc2xhdGUnfToke2tleX1gXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb25zdCBtZXNzYWdlID0gYE1lc3NhZ2UgY29tcGlsYXRpb24gZXJyb3I6ICR7ZXJyLm1lc3NhZ2V9YDtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgU3ludGF4RXJyb3IoY29kZUZyYW1lID8gYCR7bWVzc2FnZX1cXG4ke2NvZGVGcmFtZX1gIDogbWVzc2FnZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aHJvdyBlcnI7XG4gICAgICAgIH0sXG4gICAgICAgIG9uQ2FjaGVLZXk6IChzb3VyY2UpID0+IGdlbmVyYXRlRm9ybWF0Q2FjaGVLZXkobG9jYWxlLCBrZXksIHNvdXJjZSlcbiAgICB9O1xufVxuZnVuY3Rpb24gZ2V0U291cmNlRm9yQ29kZUZyYW1lKHNvdXJjZSkge1xuICAgIGlmIChpc1N0cmluZyhzb3VyY2UpKSB7XG4gICAgICAgIHJldHVybiBzb3VyY2U7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBpZiAoc291cmNlLmxvYyAmJiBzb3VyY2UubG9jLnNvdXJjZSkge1xuICAgICAgICAgICAgcmV0dXJuIHNvdXJjZS5sb2Muc291cmNlO1xuICAgICAgICB9XG4gICAgfVxufVxuZnVuY3Rpb24gZ2V0TWVzc2FnZUNvbnRleHRPcHRpb25zKGNvbnRleHQsIGxvY2FsZSwgbWVzc2FnZSwgb3B0aW9ucykge1xuICAgIGNvbnN0IHsgbW9kaWZpZXJzLCBwbHVyYWxSdWxlcywgbWVzc2FnZVJlc29sdmVyOiByZXNvbHZlVmFsdWUsIGZhbGxiYWNrTG9jYWxlLCBmYWxsYmFja1dhcm4sIG1pc3NpbmdXYXJuLCBmYWxsYmFja0NvbnRleHQgfSA9IGNvbnRleHQ7XG4gICAgY29uc3QgcmVzb2x2ZU1lc3NhZ2UgPSAoa2V5LCB1c2VMaW5rZWQpID0+IHtcbiAgICAgICAgbGV0IHZhbCA9IHJlc29sdmVWYWx1ZShtZXNzYWdlLCBrZXkpO1xuICAgICAgICAvLyBmYWxsYmFja1xuICAgICAgICBpZiAodmFsID09IG51bGwgJiYgKGZhbGxiYWNrQ29udGV4dCB8fCB1c2VMaW5rZWQpKSB7XG4gICAgICAgICAgICBjb25zdCBbZm9ybWF0LCAsIG1lc3NhZ2VdID0gcmVzb2x2ZU1lc3NhZ2VGb3JtYXQoZmFsbGJhY2tDb250ZXh0IHx8IGNvbnRleHQsIC8vIE5PVEU6IGlmIGhhcyBmYWxsYmFja0NvbnRleHQsIGZhbGxiYWNrIHRvIHJvb3QsIGVsc2UgaWYgdXNlIGxpbmtlZCwgZmFsbGJhY2sgdG8gbG9jYWwgY29udGV4dFxuICAgICAgICAgICAga2V5LCBsb2NhbGUsIGZhbGxiYWNrTG9jYWxlLCBmYWxsYmFja1dhcm4sIG1pc3NpbmdXYXJuKTtcbiAgICAgICAgICAgIHZhbCA9IGZvcm1hdCA/PyByZXNvbHZlVmFsdWUobWVzc2FnZSwga2V5KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNTdHJpbmcodmFsKSB8fCBpc01lc3NhZ2VBU1QodmFsKSkge1xuICAgICAgICAgICAgbGV0IG9jY3VycmVkID0gZmFsc2U7XG4gICAgICAgICAgICBjb25zdCBvbkVycm9yID0gKCkgPT4ge1xuICAgICAgICAgICAgICAgIG9jY3VycmVkID0gdHJ1ZTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBjb25zdCBtc2cgPSBjb21waWxlTWVzc2FnZUZvcm1hdChjb250ZXh0LCBrZXksIGxvY2FsZSwgdmFsLCBrZXksIG9uRXJyb3IpO1xuICAgICAgICAgICAgcmV0dXJuICFvY2N1cnJlZFxuICAgICAgICAgICAgICAgID8gbXNnXG4gICAgICAgICAgICAgICAgOiBOT09QX01FU1NBR0VfRlVOQ1RJT047XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoaXNNZXNzYWdlRnVuY3Rpb24odmFsKSkge1xuICAgICAgICAgICAgcmV0dXJuIHZhbDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIC8vIFRPRE86IHNob3VsZCBiZSBpbXBsZW1lbnRlZCB3YXJuaW5nIG1lc3NhZ2VcbiAgICAgICAgICAgIHJldHVybiBOT09QX01FU1NBR0VfRlVOQ1RJT047XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGN0eE9wdGlvbnMgPSB7XG4gICAgICAgIGxvY2FsZSxcbiAgICAgICAgbW9kaWZpZXJzLFxuICAgICAgICBwbHVyYWxSdWxlcyxcbiAgICAgICAgbWVzc2FnZXM6IHJlc29sdmVNZXNzYWdlXG4gICAgfTtcbiAgICBpZiAoY29udGV4dC5wcm9jZXNzb3IpIHtcbiAgICAgICAgY3R4T3B0aW9ucy5wcm9jZXNzb3IgPSBjb250ZXh0LnByb2Nlc3NvcjtcbiAgICB9XG4gICAgaWYgKG9wdGlvbnMubGlzdCkge1xuICAgICAgICBjdHhPcHRpb25zLmxpc3QgPSBvcHRpb25zLmxpc3Q7XG4gICAgfVxuICAgIGlmIChvcHRpb25zLm5hbWVkKSB7XG4gICAgICAgIGN0eE9wdGlvbnMubmFtZWQgPSBvcHRpb25zLm5hbWVkO1xuICAgIH1cbiAgICBpZiAoaXNOdW1iZXIob3B0aW9ucy5wbHVyYWwpKSB7XG4gICAgICAgIGN0eE9wdGlvbnMucGx1cmFsSW5kZXggPSBvcHRpb25zLnBsdXJhbDtcbiAgICB9XG4gICAgcmV0dXJuIGN0eE9wdGlvbnM7XG59XG5cbntcbiAgICBpbml0RmVhdHVyZUZsYWdzKCk7XG59XG5cbmV4cG9ydCB7IEFTVF9OT0RFX1BST1BTX0tFWVMsIENPUkVfRVJST1JfQ09ERVNfRVhURU5EX1BPSU5ULCBDT1JFX1dBUk5fQ09ERVNfRVhURU5EX1BPSU5ULCBDb3JlRXJyb3JDb2RlcywgQ29yZVdhcm5Db2RlcywgREFURVRJTUVfRk9STUFUX09QVElPTlNfS0VZUywgREVGQVVMVF9MT0NBTEUsIERFRkFVTFRfTUVTU0FHRV9EQVRBX1RZUEUsIE1JU1NJTkdfUkVTT0xWRV9WQUxVRSwgTk9UX1JFT1NMVkVELCBOVU1CRVJfRk9STUFUX09QVElPTlNfS0VZUywgVkVSU0lPTiwgY2xlYXJDb21waWxlQ2FjaGUsIGNsZWFyRGF0ZVRpbWVGb3JtYXQsIGNsZWFyTnVtYmVyRm9ybWF0LCBjb21waWxlLCBjcmVhdGVDb3JlQ29udGV4dCwgY3JlYXRlQ29yZUVycm9yLCBjcmVhdGVNZXNzYWdlQ29udGV4dCwgZGF0ZXRpbWUsIGZhbGxiYWNrV2l0aExvY2FsZUNoYWluLCBmYWxsYmFja1dpdGhTaW1wbGUsIGdldEFkZGl0aW9uYWxNZXRhLCBnZXREZXZUb29sc0hvb2ssIGdldEZhbGxiYWNrQ29udGV4dCwgZ2V0TG9jYWxlLCBnZXRXYXJuTWVzc2FnZSwgaGFuZGxlTWlzc2luZywgaW5pdEkxOG5EZXZUb29scywgaXNBbG1vc3RTYW1lTG9jYWxlLCBpc0ltcGxpY2l0RmFsbGJhY2ssIGlzTWVzc2FnZUFTVCwgaXNNZXNzYWdlRnVuY3Rpb24sIGlzVHJhbnNsYXRlRmFsbGJhY2tXYXJuLCBpc1RyYW5zbGF0ZU1pc3NpbmdXYXJuLCBudW1iZXIsIHBhcnNlLCBwYXJzZURhdGVUaW1lQXJncywgcGFyc2VOdW1iZXJBcmdzLCBwYXJzZVRyYW5zbGF0ZUFyZ3MsIHJlZ2lzdGVyTG9jYWxlRmFsbGJhY2tlciwgcmVnaXN0ZXJNZXNzYWdlQ29tcGlsZXIsIHJlZ2lzdGVyTWVzc2FnZVJlc29sdmVyLCByZXNvbHZlTG9jYWxlLCByZXNvbHZlVmFsdWUsIHJlc29sdmVXaXRoS2V5VmFsdWUsIHNldEFkZGl0aW9uYWxNZXRhLCBzZXREZXZUb29sc0hvb2ssIHNldEZhbGxiYWNrQ29udGV4dCwgdHJhbnNsYXRlLCB0cmFuc2xhdGVEZXZUb29scywgdXBkYXRlRmFsbGJhY2tMb2NhbGUgfTtcbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19