import { getCurrentInstance, nextTick, onMounted, readonly, ref, watch } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
//#region node_modules/.pnpm/@primeuix+utils@0.8.0/node_modules/@primeuix/utils/dist/object/index.mjs
var ce$2 = Object.defineProperty;
var $$1 = Object.getOwnPropertySymbols;
var pe$2 = Object.prototype.hasOwnProperty;
var ge$2 = Object.prototype.propertyIsEnumerable;
var q = (e, t, n) => t in e ? ce$2(e, t, {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: n
}) : e[t] = n;
var E = (e, t) => {
	for (var n in t || (t = {})) pe$2.call(t, n) && q(e, n, t[n]);
	if ($$1) for (var n of $$1(t)) ge$2.call(t, n) && q(e, n, t[n]);
	return e;
};
function p$1(e) {
	return e == null || e === "" || Array.isArray(e) && e.length === 0 || !(e instanceof Date) && typeof e == "object" && Object.keys(e).length === 0;
}
function m(e) {
	return typeof e == "function" && "call" in e && "apply" in e;
}
function l(e) {
	return !p$1(e);
}
function s(e, t = !0) {
	return e instanceof Object && e.constructor === Object && (t || Object.keys(e).length !== 0);
}
var me$1 = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]);
function S$2(e, t, n, r = /* @__PURE__ */ new WeakSet()) {
	let o = E({}, e);
	Object.keys(o).length === 0 && !n.has(t) && n.set(t, o);
	let u = !r.has(t);
	return u && r.add(t), Object.keys(t).forEach((i) => {
		var y, k;
		if (me$1.has(i)) return;
		let f = i, a = t[f];
		s(a) && f in e && s(e[f]) ? o[f] = r.has(a) ? (y = n.get(a)) != null ? y : S$2({}, a, n, r) : S$2(e[f], a, n, r) : s(a) ? o[f] = (k = n.get(a)) != null ? k : S$2({}, a, n, r) : o[f] = a;
	}), u && r.delete(t), o;
}
function F(...e) {
	return e.reduce((t, n) => S$2(t, n || {}, /* @__PURE__ */ new WeakMap()), {});
}
function x$2(e, ...t) {
	return m(e) ? e(...t) : e;
}
function c(e, t = !0) {
	return typeof e == "string" && (t || e !== "");
}
function C$2(e) {
	return c(e) ? e.replace(/(-|_)/g, "").toLowerCase() : e;
}
function K$1(e, t = "", n = {}) {
	let r = C$2(t).split("."), o = r.shift();
	if (o) {
		if (s(e) || Array.isArray(e)) return K$1(x$2(e[Object.keys(e).find((i) => C$2(i) === o) || ""], n), r.join("."), n);
		return;
	}
	return x$2(e, n);
}
function A$1(e, t = !0) {
	return Array.isArray(e) && (t || e.length !== 0);
}
function Z(e) {
	return l(e) && !isNaN(e);
}
function H$1(e, t) {
	if (t) {
		t.lastIndex = 0;
		let n = t.test(e);
		return t.lastIndex = 0, n;
	}
	return !1;
}
function Q$1(...e) {
	return F(...e);
}
function de$1(e, t) {
	let n = 0;
	for (; t - 1 - n >= 0 && e[t - 1 - n] === "\\";) n++;
	return n % 2 === 1;
}
function X$1(e) {
	return e.replace(/[\r\n\t]+/g, "").replace(/ {2,}/g, " ").replace(/ ([{:}]) /g, "$1").replace(/([;,]) /g, "$1").replace(/ !/g, "!").replace(/: /g, ":");
}
function B(e) {
	if (!e) return e;
	let t = "", n = "", r = 0;
	for (; r < e.length;) {
		let o = e[r];
		if (o === "/" && e[r + 1] === "*") {
			let u = e.indexOf("*/", r + 2);
			r = u === -1 ? e.length : u + 2;
		} else if (o === "\"" || o === "'") {
			t += X$1(n), n = "";
			let u = r + 1;
			for (; u < e.length && (e[u] !== o || de$1(e, u));) u++;
			t += e.slice(r, Math.min(u + 1, e.length)), r = u + 1;
		} else n += o, r++;
	}
	return (t + X$1(n)).trim();
}
function N$2(e = {}, t = "") {
	return Object.entries(e).reduce((n, [r, o]) => {
		let u = t ? `${t}.${r}` : r;
		return s(o) ? n = n.concat(N$2(o, u)) : n.push(u), n;
	}, []);
}
function ie(e) {
	return c(e, !1) ? e[0].toUpperCase() + e.slice(1) : e;
}
function fe(e) {
	return c(e) ? e.replace(/(_)/g, "-").replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase() : e;
}
function ae(e) {
	return c(e) ? e.replace(/[A-Z]/g, (t, n) => n === 0 ? t : "." + t.toLowerCase()).toLowerCase() : e;
}
//#endregion
//#region node_modules/.pnpm/@primeuix+utils@0.8.0/node_modules/@primeuix/utils/dist/dom/index.mjs
function I(t, e) {
	return t ? t.classList ? t.classList.contains(e) : new RegExp("(^| )" + e + "( |$)", "gi").test(t.className) : !1;
}
function R$1(t, e) {
	if (t && e) {
		let o = (n) => {
			I(t, n) || (t.classList ? t.classList.add(n) : t.className += " " + n);
		};
		[e].flat().filter(Boolean).forEach((n) => n.split(" ").forEach(o));
	}
}
function U() {
	return window.innerWidth - document.documentElement.offsetWidth;
}
function mt(t) {
	typeof t == "string" ? R$1(document.body, t || "p-overflow-hidden") : (t != null && t.variableName && document.body.style.setProperty(t.variableName, U() + "px"), R$1(document.body, (t == null ? void 0 : t.className) || "p-overflow-hidden"));
}
function W(t, e) {
	if (t && e) {
		let o = (n) => {
			t.classList ? t.classList.remove(n) : t.className = t.className.replace(new RegExp("(^|\\b)" + n.split(" ").join("|") + "(\\b|$)", "gi"), " ");
		};
		[e].flat().filter(Boolean).forEach((n) => n.split(" ").forEach(o));
	}
}
function ht(t) {
	typeof t == "string" ? W(document.body, t || "p-overflow-hidden") : (t != null && t.variableName && document.body.style.removeProperty(t.variableName), W(document.body, (t == null ? void 0 : t.className) || "p-overflow-hidden"));
}
function h$1() {
	let t = window, e = document, o = e.documentElement, n = e.getElementsByTagName("body")[0];
	return {
		width: t.innerWidth || o.clientWidth || n.clientWidth,
		height: t.innerHeight || o.clientHeight || n.clientHeight
	};
}
function S$1(t) {
	return t ? Math.abs(t.scrollLeft) : 0;
}
var pe$1 = /expression\s*\(|url\s*\(\s*['"]?\s*(?:javascript|vbscript):|@import\s+['"]?\s*(?:javascript|vbscript|data):/i;
var bt = /url\s*\(\s*['"]?\s*(data:[^'")]*)/gi;
var ce$1 = /* @__PURE__ */ new Set([
	"href",
	"src",
	"xlink:href",
	"action",
	"formaction"
]);
var me = /* @__PURE__ */ new Set([
	"http",
	"https",
	"mailto",
	"tel",
	"sms",
	"ftp",
	"ftps",
	"blob"
]);
var yt = /^data:image\/(?:png|gif|jpeg|jpg|webp|bmp|avif);base64,[a-z0-9+/=\s]+$/i;
function _(t) {
	if (typeof t != "string") return !1;
	if (pe$1.test(t)) return !0;
	bt.lastIndex = 0;
	let e;
	for (; e = bt.exec(t);) if (!yt.test(e[1].trim())) return !0;
	return !1;
}
function ge$1(t) {
	let e = "";
	for (let o of t) {
		let n = o.charCodeAt(0);
		n <= 31 || n === 127 || /\s/.test(o) || (e += o);
	}
	return e;
}
function he$1(t, e) {
	var i, s;
	let o = ge$1(t), n = e.toLowerCase();
	if (o.startsWith("#") || o.startsWith("/") || o.startsWith("./") || o.startsWith("../") || o.startsWith("?")) return !0;
	let r = (s = (i = o.match(/^([a-z][a-z0-9+.-]*):/i)) == null ? void 0 : i[1]) == null ? void 0 : s.toLowerCase();
	return r ? r === "data" ? (n === "src" || n === "xlink:href") && yt.test(t.trim()) : me.has(r) : !0;
}
function P$1(t, e) {
	return typeof e == "string" && ce$1.has(t.toLowerCase()) && !he$1(e, t);
}
function O(t, e) {
	return t.toLowerCase() === "srcdoc" && typeof e == "string" && /<\s*script\b|on\w+\s*=|javascript:|data:text\/html/i.test(e);
}
function ye$1(t) {
	return t.startsWith("--") ? t : t.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
}
function X(t, e, o = {}) {
	o.clear && (t.style.cssText = ""), e.forEach((n) => {
		let r = n.indexOf(":");
		if (r < 0) return;
		let i = n.slice(0, r).trim(), s = n.slice(r + 1).trim();
		if (!i || _(s)) return;
		let l = "";
		/!\s*important$/i.test(s) && (s = s.replace(/!\s*important$/i, "").trim(), l = "important"), t.style.setProperty(i, s, l);
	});
}
function xe(t, e) {
	let o = 0;
	for (; e - 1 - o >= 0 && t[e - 1 - o] === "\\";) o++;
	return o % 2 === 1;
}
function we(t) {
	let e = [], o = 0, n = "", r = 0;
	for (let i = 0; i < t.length; i++) {
		let s = t[i];
		n ? s === n && !xe(t, i) && (n = "") : s === "'" || s === "\"" ? n = s : s === "(" ? r++ : s === ")" ? r = Math.max(0, r - 1) : s === ";" && r === 0 && (e.push(t.slice(o, i)), o = i + 1);
	}
	return e.push(t.slice(o)), e;
}
function v$1(t, e, o = {}) {
	if (typeof e == "string") {
		X(t, we(e), o);
		return;
	}
	o.clear && (t.style.cssText = ""), Object.entries(e).forEach(([n, r]) => {
		if (r == null || _(r)) return;
		let i = String(r), s = "";
		/!\s*important$/i.test(i) && (i = i.replace(/!\s*important$/i, "").trim(), s = "important"), t.style.setProperty(ye$1(n), i, s);
	});
}
function L$1(t, e) {
	t && (typeof e == "string" ? v$1(t, e, { clear: !0 }) : v$1(t, e || {}));
}
function C$1(t, e) {
	if (t instanceof HTMLElement) {
		let o = t.offsetWidth;
		if (e) {
			let n = getComputedStyle(t);
			o += parseFloat(n.marginLeft) + parseFloat(n.marginRight);
		}
		return o;
	}
	return 0;
}
function b(t) {
	if (t) {
		let e = t.parentNode;
		return e && e instanceof ShadowRoot && e.host && (e = e.host), e;
	}
	return null;
}
function H(t) {
	return !!(t !== null && typeof t != "undefined" && t.nodeName && b(t));
}
function p(t) {
	return typeof Element != "undefined" ? t instanceof Element : t !== null && typeof t == "object" && t.nodeType === 1 && typeof t.nodeName == "string";
}
function A(t, e, o) {
	if (typeof o != "function" && !(typeof o == "object" && o !== null && "handleEvent" in o)) return;
	let n = t, r = n._pListeners || (n._pListeners = []), i = !1;
	for (let s = r.length - 1; s >= 0; s--) r[s][0] === e && (r[s][1] === o ? i = !0 : (t.removeEventListener(e, r[s][1]), r.splice(s, 1)));
	i || (t.addEventListener(e, o), r.push([e, o]));
}
function N$1(t, e = {}) {
	if (p(t)) {
		let o = t == null ? void 0 : t.$attrs, n = (s, l) => {
			let a = o != null && o[s] ? [o[s]] : [];
			return [l].flat().reduce((f, u) => {
				if (u != null) {
					let c = typeof u;
					if (c === "string" || c === "number") f.push(u);
					else if (c === "object") {
						let d = Array.isArray(u) ? n(s, u) : Object.entries(u).map(([g, w]) => s === "style" && (w || w === 0) ? `${g.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()}:${w}` : w ? g : void 0);
						f = d.length ? f.concat(d.filter((g) => !!g)) : f;
					}
				}
				return f;
			}, a);
		}, r = (s) => {
			X(t, n("style", s));
		}, i = t;
		Object.entries(e).forEach(([s, l]) => {
			if (l != null) {
				let a = s.match(/^on(.+)/);
				if (a) A(t, a[1].toLowerCase(), l);
				else if (s === "p-bind" || s === "pBind") N$1(t, l);
				else if (s === "style") r(l), i.$attrs = i.$attrs || {}, i.$attrs[s] = t.style.cssText;
				else {
					if (P$1(s, l) || O(s, l)) return;
					l = s === "class" ? [...new Set(n("class", l))].join(" ").trim() : l, i.$attrs = i.$attrs || {}, i.$attrs[s] = l, t.setAttribute(s, l);
				}
			}
		});
	}
}
function Q(t, e = {}, ...o) {
	if (t) {
		let n = document.createElement(t);
		return N$1(n, e), n.append(...o), n;
	}
}
function G(t) {
	return String(t).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function tt(t, e) {
	return p(t) ? Array.from(t.querySelectorAll(e)) : [];
}
function Ht(t, e) {
	t && document.activeElement !== t && t.focus(e);
}
function ot$1(t, e) {
	if (p(t)) {
		let o = t.getAttribute(e);
		return o !== null && o.trim() !== "" && !isNaN(o) ? +o : o === "true" || o === "false" ? o === "true" : o;
	}
}
function x$1(t, e = "") {
	let o = tt(t, `button:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${e},
            [href]:not([tabindex = "-1"]):not([style*="display:none"]):not([hidden])${e},
            input:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${e},
            select:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${e},
            textarea:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${e},
            [tabIndex]:not([tabIndex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${e},
            [contenteditable]:not([tabIndex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${e}`), n = [];
	for (let r of o) {
		let i = getComputedStyle(r);
		i.display != "none" && i.visibility != "hidden" && n.push(r);
	}
	return n;
}
function Wt(t, e) {
	let o = x$1(t, e);
	return o.length > 0 ? o[0] : null;
}
function Pt(t) {
	if (t) {
		let e = t.offsetHeight, o = getComputedStyle(t);
		return e -= parseFloat(o.paddingTop) + parseFloat(o.paddingBottom) + parseFloat(o.borderTopWidth) + parseFloat(o.borderBottomWidth), e;
	}
	return 0;
}
function Nt(t, e) {
	let o = x$1(t, e);
	return o.length > 0 ? o[o.length - 1] : null;
}
function st(t) {
	if (t) {
		let e = t.getBoundingClientRect();
		return {
			top: e.top + (window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0),
			left: e.left + (window.pageXOffset || S$1(document.documentElement) || S$1(document.body) || 0)
		};
	}
	return {
		top: "auto",
		left: "auto"
	};
}
function k(t, e) {
	if (t) {
		let o = t.offsetHeight;
		if (e) {
			let n = getComputedStyle(t);
			o += parseFloat(n.marginTop) + parseFloat(n.marginBottom);
		}
		return o;
	}
	return 0;
}
function jt(t) {
	if (t) {
		let e = t.offsetWidth, o = getComputedStyle(t);
		return e -= parseFloat(o.paddingLeft) + parseFloat(o.paddingRight) + parseFloat(o.borderLeftWidth) + parseFloat(o.borderRightWidth), e;
	}
	return 0;
}
function at() {
	return !!(typeof window != "undefined" && window.document && window.document.createElement);
}
function Gt(t, e = "") {
	return p(t) ? t.matches(`button:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${e},
            [href]:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${e},
            input:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${e},
            select:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${e},
            textarea:not([tabindex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${e},
            [tabIndex]:not([tabIndex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${e},
            [contenteditable]:not([tabIndex = "-1"]):not([disabled]):not([style*="display:none"]):not([hidden])${e}`) : !1;
}
function de(t, e = "", o) {
	if (p(t) && o !== null && o !== void 0) {
		let n = e.toLowerCase();
		if (/^on[a-z]/.test(n)) {
			A(t, n.slice(2), o);
			return;
		}
		if (n === "style") {
			typeof o == "string" ? v$1(t, o, { clear: !0 }) : typeof o == "object" && v$1(t, o);
			return;
		}
		if (P$1(e, o) || O(e, o)) return;
		t.setAttribute(e, o);
	}
}
//#endregion
//#region node_modules/.pnpm/@primeuix+utils@0.8.0/node_modules/@primeuix/utils/dist/eventbus/index.mjs
function v() {
	let s = /* @__PURE__ */ new Map(), r = {
		on(n, t) {
			let e = s.get(n);
			return e ? e.push(t) : e = [t], s.set(n, e), r;
		},
		off(n, t) {
			let e = s.get(n);
			if (e) {
				let o = e.indexOf(t);
				o !== -1 && e.splice(o, 1);
			}
			return r;
		},
		emit(n, ...t) {
			let e = s.get(n);
			e && e.forEach((o) => {
				o(t[0]);
			});
		},
		clear() {
			s.clear();
		}
	};
	return r;
}
//#endregion
//#region node_modules/.pnpm/@primeuix+utils@0.8.0/node_modules/@primeuix/utils/dist/zindex/index.mjs
function g() {
	let r = [], i = (e, n, t = 999) => {
		let s = u(e, n, t), o = s.value + (s.key === e ? 0 : t) + 1;
		return r.push({
			key: e,
			value: o
		}), o;
	}, d = (e) => {
		r = r.filter((n) => n.value !== e);
	}, a = (e, n) => u(e, n).value, u = (e, n, t = 0) => [...r].reverse().find((s) => n ? !0 : s.key === e) || {
		key: e,
		value: t
	}, l = (e) => e && parseInt(e.style.zIndex, 10) || 0;
	return {
		get: l,
		set: (e, n, t) => {
			n && (n.style.zIndex = String(i(e, !0, t)));
		},
		clear: (e) => {
			e && (d(l(e)), e.style.zIndex = "");
		},
		getCurrent: (e) => a(e, !1)
	};
}
var x = g();
//#endregion
//#region node_modules/.pnpm/@primeuix+styled@1.0.0/node_modules/@primeuix/styled/dist/index.mjs
var nt = Object.defineProperty;
var ot = Object.defineProperties;
var it = Object.getOwnPropertyDescriptors;
var te = Object.getOwnPropertySymbols;
var Se = Object.prototype.hasOwnProperty;
var Oe = Object.prototype.propertyIsEnumerable;
var ye = (e, t, s) => t in e ? nt(e, t, {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: s
}) : e[t] = s;
var y = (e, t) => {
	for (var s in t || (t = {})) Se.call(t, s) && ye(e, s, t[s]);
	if (te) for (var s of te(t)) Oe.call(t, s) && ye(e, s, t[s]);
	return e;
};
var C = (e, t) => ot(e, it(t));
var V = (e, t) => {
	var s = {};
	for (var r in e) Se.call(e, r) && t.indexOf(r) < 0 && (s[r] = e[r]);
	if (e != null && te) for (var r of te(e)) t.indexOf(r) < 0 && Oe.call(e, r) && (s[r] = e[r]);
	return s;
};
var R = v();
var P = /{([^}]*)}/g;
var re = /(\d+\s+[+*/-]\s+\d+)/g;
var ne = /var\([^)]+\)/g;
function K(e) {
	return c(e) ? e.replace(/[A-Z]/g, (t, s) => s === 0 ? t : "." + t.toLowerCase()).toLowerCase() : e;
}
function Pe(e) {
	return s(e) && Object.prototype.hasOwnProperty.call(e, "$value") && Object.prototype.hasOwnProperty.call(e, "$type") ? e.$value : e;
}
function pt(e) {
	return e.replaceAll(/ /g, "").replace(/[^\w]/g, "-");
}
function oe(e = "", t = "") {
	return pt(`${c(e, !1) && c(t, !1) ? `${e}-` : e}${t}`);
}
function ce(e = "", t = "") {
	return `--${oe(e, t)}`;
}
function gt(e = "") {
	return ((e.match(/{/g) || []).length + (e.match(/}/g) || []).length) % 2 !== 0;
}
function L(e, t = "", s = "", r = [], o) {
	if (c(e)) {
		let i = e.trim();
		if (gt(i)) return;
		if (H$1(i, P)) {
			let n = i.replaceAll(P, (u) => {
				return `var(${ce(s, fe(u.replace(/{|}/g, "").split(".").filter((l) => !r.some((c) => H$1(l, c))).join("-")))}${l(o) ? `, ${o}` : ""})`;
			});
			return H$1(n.replace(ne, "0"), re) ? `calc(${n})` : n;
		}
		return i;
	} else if (Z(e)) return e;
}
function $e(e, t, s) {
	c(t, !1) && e.push(`${t}:${s};`);
}
function j(e, t) {
	return e ? `${e}{${t}}` : "";
}
function ue(e, t) {
	if (e.indexOf("dt(") === -1) return e;
	function s(n, u) {
		let m = [], a = 0, l = "", c = null, p = 0;
		for (; a <= n.length;) {
			let g = n[a];
			if ((g === "\"" || g === "'" || g === "`") && n[a - 1] !== "\\" && (c = c === g ? null : g), !c && (g === "(" && p++, g === ")" && p--, (g === "," || a === n.length) && p === 0)) {
				let f = l.trim();
				f.startsWith("dt(") ? m.push(ue(f, u)) : m.push(r(f)), l = "", a++;
				continue;
			}
			g !== void 0 && (l += g), a++;
		}
		return m;
	}
	function r(n) {
		let u = n[0];
		if ((u === "\"" || u === "'" || u === "`") && n[n.length - 1] === u) return n.slice(1, -1);
		let m = Number(n);
		return isNaN(m) ? n : m;
	}
	let o = [], i = [];
	for (let n = 0; n < e.length; n++) if (e[n] === "d" && e.slice(n, n + 3) === "dt(") i.push(n), n += 2;
	else if (e[n] === ")" && i.length > 0) {
		let u = i.pop();
		i.length === 0 && o.push([u, n]);
	}
	if (!o.length) return e;
	for (let n = o.length - 1; n >= 0; n--) {
		let [u, m] = o[n], c = t(...s(e.slice(u + 3, m), t));
		e = e.slice(0, u) + c + e.slice(m + 1);
	}
	return e;
}
var St = (e, t) => {
	let s = e.split("."), r = "";
	for (let o = 0; o < s.length; o++) {
		let i = K(s[o]);
		t.lastIndex = 0, !t.test(i) && (r = r ? `${r}.${i}` : i);
	}
	return r;
};
var he = (e, t, s, r, o) => {
	if (typeof e != "string") return e != null ? e : S.getTokenValue(t);
	if (P.lastIndex = 0, !P.test(e)) return e;
	let i = t.slice(0, t.indexOf("."));
	return L(e.replace(P, (u) => {
		let m = u.slice(1, -1), a = m.indexOf(".");
		if ((a === -1 ? m : m.slice(0, a)) !== i) return u;
		let l = S.getTokenValue(m);
		return l == null ? u : `${l}`;
	}), void 0, s, [r], o);
};
var Ot = (e, t, s, r) => {
	var l, c, p, g;
	let o = St(e, s), i = S.tokens, n = i.__strictCache;
	n || (n = /* @__PURE__ */ new Map(), Object.defineProperty(i, "__strictCache", {
		value: n,
		enumerable: !1,
		configurable: !0
	}));
	let u = r == null || typeof r != "object", m = u && r != null ? `${t}|${o}|${r}` : `${t}|${o}`, a = u ? n.get(m) : void 0;
	if (a === void 0 && (!u || !n.has(m))) {
		let f = (l = i[o]) == null ? void 0 : l.paths, h = f == null ? void 0 : f.find((k) => k.scheme === "none"), d = (c = f == null ? void 0 : f.find((k) => k.scheme === "light")) != null ? c : h, T = (p = f == null ? void 0 : f.find((k) => k.scheme === "dark")) != null ? p : h;
		if (d && T && d !== T) {
			let k = he(d.value, o, t, s, r), b = he(T.value, o, t, s, r);
			a = k === b ? k : `light-dark(${k},${b})`;
		} else a = he((g = d != null ? d : T) == null ? void 0 : g.value, o, t, s, r);
		u && n.set(m, a);
	}
	return S.hasScopedTokenPath(o) ? L(`{${o}}`, void 0, t, [s], a) : a;
};
var us = (e) => {
	var i, n, u;
	let t = S.getTheme(), s = `${(i = pe(t, e, void 0, "variable")) != null ? i : ""}`;
	return {
		name: (u = (n = s.match(/--[\w-]+/g)) == null ? void 0 : n[0]) != null ? u : "",
		variable: s,
		value: pe(t, e, void 0, "value")
	};
};
var N = (e, t, s) => pe(S.getTheme(), e, t, s);
var pe = (e = {}, t, s, r) => {
	var m, a, l, c, p, g, f, h, d, T;
	if (!t) return "";
	let o = (m = S.defaults) == null ? void 0 : m.variable, i = (p = (a = e == null ? void 0 : e.options) == null ? void 0 : a.prefix) != null ? p : (c = (l = S.defaults) == null ? void 0 : l.options) == null ? void 0 : c.prefix, n = (T = (d = (g = e == null ? void 0 : e.options) == null ? void 0 : g.cssVariables) != null ? d : (h = (f = S.defaults) == null ? void 0 : f.options) == null ? void 0 : h.cssVariables) != null ? T : !0;
	if (r === "value") return S.getTokenValue(t);
	if (p$1(r) && !n) return Ot(t, i, o.excludedKeyRegex, s);
	return L(H$1(t, P) ? t : `{${t}}`, void 0, i, [o.excludedKeyRegex], s);
};
var xt = (...e) => {
	var t;
	return `${(t = N(...e)) != null ? t : ""}`;
};
function gs(e, ...t) {
	if (e instanceof Array) return ue(e.reduce((r, o, i) => {
		var n;
		return r + o + ((n = x$2(t[i], { dt: N })) != null ? n : "");
	}, ""), xt);
	return x$2(e, { dt: N });
}
function ge(e, t = {}) {
	let s$4 = S.defaults.variable, { prefix: r = s$4.prefix, selector: o = s$4.selector, excludedKeyRegex: i = s$4.excludedKeyRegex } = t, n = [], u = [], m = [{
		node: e,
		path: r
	}];
	for (; m.length;) {
		let { node: l, path: c } = m.pop();
		for (let p in l) {
			let g = l[p], f = Pe(g), d = H$1(p, i) ? oe(c) : oe(c, fe(p));
			if (s(f)) m.push({
				node: f,
				path: d
			});
			else {
				let T = ce(d), k = L(f, d, r, [i]);
				$e(u, T, k == null ? k : `${k}`);
				let b = d;
				r && b.startsWith(r + "-") && (b = b.slice(r.length + 1)), n.push(b.replace(/-/g, "."));
			}
		}
	}
	let a = u.join("");
	return {
		value: u,
		tokens: n,
		declarations: a,
		css: j(o, a)
	};
}
var $ = {
	regex: {
		rules: {
			class: {
				pattern: /^\.([a-zA-Z][\w-]*)$/,
				resolve(e) {
					return {
						type: "class",
						selector: e,
						matched: this.pattern.test(e.trim())
					};
				}
			},
			attr: {
				pattern: /^\[(.*)\]$/,
				resolve(e) {
					return {
						type: "attr",
						selector: `:root${e},:host${e}`,
						matched: this.pattern.test(e.trim())
					};
				}
			},
			media: {
				pattern: /^@media (.*)$/,
				resolve(e) {
					return {
						type: "media",
						selector: e,
						matched: this.pattern.test(e.trim())
					};
				}
			},
			system: {
				pattern: /^system$/,
				resolve(e) {
					return {
						type: "system",
						selector: "@media (prefers-color-scheme: dark)",
						matched: this.pattern.test(e.trim())
					};
				}
			},
			custom: { resolve(e) {
				return {
					type: "custom",
					selector: e,
					matched: !0
				};
			} }
		},
		resolve(e) {
			let t = Object.keys(this.rules).filter((s) => s !== "custom").map((s) => this.rules[s]);
			return [e].flat().map((s) => {
				var r;
				return (r = t.map((o) => o.resolve(s)).find((o) => o.matched)) != null ? r : this.rules.custom.resolve(s);
			});
		}
	},
	_toVariables(e, t) {
		return ge(e, { prefix: t == null ? void 0 : t.prefix });
	},
	getCommon({ name: e = "", theme: t = {}, params: s, set: r, defaults: o }) {
		var k, b, O, v, E, _, w;
		let { preset: i, options: n } = t, u, m, a, l$1, c, p, g;
		if (l(i)) {
			let { primitive: z, semantic: G, extend: I } = i, f = G || {}, { colorScheme: ae } = f, U = V(f, ["colorScheme"]), h = I || {}, { colorScheme: H } = h, M = V(h, ["colorScheme"]), d = ae || {}, { dark: B } = d, W = V(d, ["dark"]), T = H || {}, { dark: q } = T, F = V(T, ["dark"]), Z = l(z) ? this._toVariables({ primitive: z }, n) : {}, J = l(U) ? this._toVariables({ semantic: U }, n) : {}, Q = l(W) ? this._toVariables({ light: W }, n) : {}, Y = l(B) ? this._toVariables({ dark: B }, n) : {}, ee = l(M) ? this._toVariables({ semantic: M }, n) : {}, Te = l(F) ? this._toVariables({ light: F }, n) : {}, be = l(q) ? this._toVariables({ dark: q }, n) : {}, [Ke, Xe] = [(k = Z.declarations) != null ? k : "", Z.tokens], [ze, Ge] = [(b = J.declarations) != null ? b : "", J.tokens || []], [Ie, Ue] = [(O = Q.declarations) != null ? O : "", Q.tokens || []], [He, We] = [(v = Y.declarations) != null ? v : "", Y.tokens || []], [qe, Fe] = [(E = ee.declarations) != null ? E : "", ee.tokens || []], [Ze, Je] = [(_ = Te.declarations) != null ? _ : "", Te.tokens || []], [Qe, Ye] = [(w = be.declarations) != null ? w : "", be.tokens || []];
			u = this.transformCSS(e, Ke, "light", "variable", n, r, o), m = Xe;
			a = `${this.transformCSS(e, `${ze}${Ie}`, "light", "variable", n, r, o)}${this.transformCSS(e, `${He}`, "dark", "variable", n, r, o)}`, l$1 = [.../* @__PURE__ */ new Set([
				...Ge,
				...Ue,
				...We
			])];
			c = `${this.transformCSS(e, `${qe}${Ze}color-scheme:light`, "light", "variable", n, r, o)}${this.transformCSS(e, `${Qe}color-scheme:dark`, "dark", "variable", n, r, o)}`, p = [.../* @__PURE__ */ new Set([
				...Fe,
				...Je,
				...Ye
			])], g = x$2(i.css, { dt: N });
		}
		return {
			primitive: {
				css: u,
				tokens: m
			},
			semantic: {
				css: a,
				tokens: l$1
			},
			global: {
				css: c,
				tokens: p
			},
			style: g
		};
	},
	getPreset({ name: e = "", preset: t = {}, options: s, params: r, set: o, defaults: i, selector: n, isScopedTokenPaths: u }) {
		var c, d, T, k;
		let m, a, l$2;
		if (l(t) && ((c = s == null ? void 0 : s.cssVariables) == null || c || u)) {
			let b = e.replace("-directive", ""), p = t, { colorScheme: O, extend: v, css: E } = p, _ = V(p, [
				"colorScheme",
				"extend",
				"css"
			]), g = v || {}, { colorScheme: w } = g, z = V(g, ["colorScheme"]), f = O || {}, { dark: G } = f, I = V(f, ["dark"]), h = w || {}, { dark: ae } = h, U = V(h, ["dark"]), H = l(_) ? this._toVariables({ [b]: y(y({}, _), z) }, s) : {}, M = l(I) ? this._toVariables({ [b]: y(y({}, I), U) }, s) : {}, B = l(G) ? this._toVariables({ [b]: y(y({}, G), ae) }, s) : {}, [W, q] = [(d = H.declarations) != null ? d : "", H.tokens || []], [F, Z] = [(T = M.declarations) != null ? T : "", M.tokens || []], [J, Q] = [(k = B.declarations) != null ? k : "", B.tokens || []];
			m = `${this.transformCSS(b, `${W}${F}`, "light", "variable", s, o, i, n)}${this.transformCSS(b, J, "dark", "variable", s, o, i, n)}`, a = [.../* @__PURE__ */ new Set([
				...q,
				...Z,
				...Q
			])], l$2 = x$2(E, { dt: N });
		}
		return {
			css: m,
			tokens: a,
			style: l$2
		};
	},
	getScopedSelector(e, t) {
		if (!(!(t != null && t.scoped) || !e)) return `[data-styled="${e}"]`;
	},
	getPresetC({ name: e = "", theme: t = {}, params: s, set: r, defaults: o }) {
		var a;
		let { preset: i, options: n } = t, u = (a = i == null ? void 0 : i.components) == null ? void 0 : a[e], m = this.getScopedSelector(e, n);
		return this.getPreset({
			name: e,
			preset: u,
			options: n,
			params: s,
			set: r,
			defaults: o,
			selector: m
		});
	},
	getPresetD({ name: e = "", theme: t = {}, params: s, set: r, defaults: o }) {
		var l, c;
		let i = e.replace("-directive", ""), { preset: n, options: u } = t, m = ((l = n == null ? void 0 : n.components) == null ? void 0 : l[i]) || ((c = n == null ? void 0 : n.directives) == null ? void 0 : c[i]), a = this.getScopedSelector(i, u);
		return this.getPreset({
			name: i,
			preset: m,
			options: u,
			params: s,
			set: r,
			defaults: o,
			selector: a
		});
	},
	applyDarkColorScheme(e) {
		let t = e.darkModeSelector;
		return !(t === "none" || t === !1);
	},
	getColorSchemeOption(e, t) {
		var s;
		return this.applyDarkColorScheme(e) ? this.regex.resolve(e.darkModeSelector === !0 ? t.options.darkModeSelector : (s = e.darkModeSelector) != null ? s : t.options.darkModeSelector) : [];
	},
	getLayerOrder(e, t = {}, s, r) {
		let { cssLayer: o } = t;
		return o ? `@layer ${x$2(o.order || o.name || "primeui", s)}` : "";
	},
	getCommonStyleSheet({ name: e = "", theme: t = {}, params: s$1, props: r = {}, set: o, defaults: i }) {
		let n = this.getCommon({
			name: e,
			theme: t,
			params: s$1,
			set: o,
			defaults: i
		}), u = Object.entries(r).reduce((m, [a, l]) => (m.push(`${a}="${G(l)}"`), m), []).join(" ");
		return Object.entries(n || {}).reduce((m, [a, l]) => {
			if (s(l) && Object.hasOwn(l, "css")) {
				let c = B(l.css), p = `${a}-variables`;
				m.push(`<style type="text/css" data-primevue-style-id="${p}" ${u}>${c}</style>`);
			}
			return m;
		}, []).join("");
	},
	getStyleSheet({ name: e = "", theme: t = {}, params: s, props: r = {}, set: o, defaults: i }) {
		var a;
		let n = {
			name: e,
			theme: t,
			params: s,
			set: o,
			defaults: i
		}, u = (a = e.includes("-directive") ? this.getPresetD(n) : this.getPresetC(n)) == null ? void 0 : a.css, m = Object.entries(r).reduce((l, [c, p]) => (l.push(`${c}="${G(p)}"`), l), []).join(" ");
		return u ? `<style type="text/css" data-primevue-style-id="${e}-variables" ${m}>${B(u)}</style>` : "";
	},
	createTokens(e = {}, t, s$2 = "", r = "", o = {}) {
		let i = function(a, l, c, p) {
			return a.replace(P, (g) => {
				var T;
				let f = g.slice(1, -1), h = this.tokens[f];
				if (!h) return console.warn(`Token not found for path: ${f}`), "__UNRESOLVED__";
				let d = h.computed(l, c, p);
				if (Array.isArray(d) && d.length === 2) {
					let k = d[0].value, b = d[1].value;
					return k === b ? k != null ? k : "__UNRESOLVED__" : `light-dark(${k},${b})`;
				}
				return (T = d == null ? void 0 : d.value) != null ? T : "__UNRESOLVED__";
			});
		}, n = function(a, l, c, p) {
			if (a.indexOf("light-dark(") === -1) return a;
			let g = [], f = a.length, h = 0;
			for (; h < f;) {
				let d = a.indexOf("light-dark(", h);
				if (d === -1) {
					g.push(a.slice(h));
					break;
				}
				g.push(a.slice(h, d));
				let T = 1, k = d + 11, b = -1;
				for (; k < f && T > 0;) {
					let _ = a.charCodeAt(k);
					_ === 40 ? T++ : _ === 41 ? T-- : _ === 44 && T === 1 && b === -1 && (b = k), k++;
				}
				if (T !== 0 || b === -1) {
					g.push(a.slice(d));
					break;
				}
				let O = a.slice(d + 11, b).trim(), v = a.slice(b + 1, k - 1).trim(), E = l && l !== "none" ? l : null;
				if (E === "light") g.push(n.call(this, O, "light", c, p));
				else if (E === "dark") g.push(n.call(this, v, "dark", c, p));
				else {
					let _ = i.call(this, n.call(this, O, "light", c, p), "light", c, p), w = i.call(this, n.call(this, v, "dark", c, p), "dark", c, p);
					g.push(_ === w ? _ : `light-dark(${_},${w})`);
				}
				h = k;
			}
			return g.join("");
		}, u = function(a, l = {}, c = []) {
			if (c.includes(this.path)) return console.warn(`Circular reference detected at ${this.path}`), {
				colorScheme: a,
				path: this.path,
				paths: l,
				value: void 0
			};
			c.push(this.path), l.name = this.path, l.binding || (l.binding = {});
			let p = this.value;
			if (typeof this.value == "string") {
				let g = this.value.trim(), f = g.indexOf("light-dark(") !== -1, h = g.indexOf("{") !== -1;
				if (f || h) {
					let d = f ? n.call(this, g, a, l, c) : g, T = d.indexOf("{") !== -1 ? i.call(this, d, a, l, c) : d;
					re.lastIndex = 0, ne.lastIndex = 0, p = re.test(T.replace(ne, "0")) ? `calc(${T})` : T;
				}
			}
			return p$1(l.binding) && delete l.binding, c.pop(), {
				colorScheme: a,
				path: this.path,
				paths: l,
				value: typeof p == "string" && p.indexOf("__UNRESOLVED__") !== -1 ? void 0 : p
			};
		}, m = (a, l, c) => {
			Object.entries(a).forEach(([p, g]) => {
				let f = H$1(p, t.variable.excludedKeyRegex) ? l : l ? `${l}.${K(p)}` : K(p), h = c ? `${c}.${p}` : p;
				s(g) ? m(g, f, h) : (o[f] || (o[f] = {
					paths: [],
					computed: (d, T = {}, k = []) => {
						let b = o[f].paths;
						if (b.length === 1) {
							let O = b[0], v = O.scheme !== "none" ? O.scheme : d;
							return O.computed(v, T.binding, k);
						} else if (d && d !== "none") for (let O = 0; O < b.length; O++) {
							let v = b[O];
							if (v.scheme === d) return v.computed(d, T.binding, k);
						}
						return b.map((O) => O.computed(O.scheme, T[O.scheme], k));
					}
				}), o[f].paths.push({
					path: h,
					value: g,
					scheme: h.includes("colorScheme.light") ? "light" : h.includes("colorScheme.dark") ? "dark" : "none",
					computed: u,
					tokens: o
				}));
			});
		};
		return m(e, s$2, r), o;
	},
	getTokenValue(e, t, s) {
		var p, g, f;
		let r = e.__cache;
		r || (r = /* @__PURE__ */ new Map(), Object.defineProperty(e, "__cache", {
			value: r,
			enumerable: !1,
			configurable: !0
		}));
		let o = r.get(t);
		if (o !== void 0 || r.has(t)) return o;
		let i = s.variable.excludedKeyRegex, n = t.split("."), u = [];
		for (let h = 0; h < n.length; h++) {
			let d = n[h];
			i.lastIndex = 0, i.test(d.toLowerCase()) || u.push(d);
		}
		let m = u.join("."), a = t.indexOf("colorScheme.light") !== -1 ? "light" : t.indexOf("colorScheme.dark") !== -1 ? "dark" : void 0, l = e[m];
		if (!l) {
			r.set(t, void 0);
			return;
		}
		let c;
		if (a) {
			let h = l.computed(a);
			if (Array.isArray(h)) {
				for (let d = 0; d < h.length; d++) if (((p = h[d]) == null ? void 0 : p.colorScheme) === a) {
					c = h[d].value;
					break;
				}
			} else c = h == null ? void 0 : h.value;
		} else {
			let h = l.computed("light"), d = l.computed("dark"), T, k;
			if (Array.isArray(h)) {
				for (let b = 0; b < h.length; b++) if (((g = h[b]) == null ? void 0 : g.colorScheme) === "light") {
					T = h[b].value;
					break;
				}
			} else T = h == null ? void 0 : h.value;
			if (Array.isArray(d)) {
				for (let b = 0; b < d.length; b++) if (((f = d[b]) == null ? void 0 : f.colorScheme) === "dark") {
					k = d[b].value;
					break;
				}
			} else k = d == null ? void 0 : d.value;
			T === void 0 && k === void 0 ? c = void 0 : T === void 0 ? c = k : k === void 0 || T === k ? c = T : c = `light-dark(${T},${k})`;
		}
		return r.set(t, c), c;
	},
	getSelectorRule(e, t, s, r, o = ":root,:host") {
		return s === "class" || s === "attr" ? j(l(t) ? `${e}${t},${e} ${t}` : e, r) : j(e, j(t != null ? t : o, r));
	},
	transformCSS(e, t, s$3, r, o = {}, i, n, u) {
		var m, a;
		if (l(t)) {
			let { cssLayer: l$3 } = o;
			if (r !== "style") {
				let c = this.getColorSchemeOption(o, n), p = (a = (m = n == null ? void 0 : n.variable) == null ? void 0 : m.selector) != null ? a : ":root,:host";
				t = s$3 === "dark" ? c.reduce((g, { type: f, selector: h }) => (l(h) && (g += h.includes("[CSS]") ? h.replace("[CSS]", t) : this.getSelectorRule(h, u, f, t, p)), g), "") : j(u != null ? u : p, t);
			}
			if (l$3) {
				let c = {
					name: "primeui",
					order: "primeui"
				};
				s(l$3) && (c.name = x$2(l$3.name, {
					name: e,
					type: r
				})), l(c.name) && (t = j(`@layer ${c.name}`, t), i?.layerNames(c.name));
			}
			return t;
		}
		return "";
	}
};
var S = {
	defaults: {
		variable: {
			prefix: "p",
			selector: ":root,:host",
			excludedKeyRegex: /^(primitive|semantic|components|directives|variables|colorscheme|light|dark|common|root|states|extend|css)$/gi
		},
		options: {
			prefix: "p",
			darkModeSelector: "system",
			cssLayer: !1,
			cssVariables: !0,
			scoped: !1
		}
	},
	_theme: void 0,
	_layerNames: /* @__PURE__ */ new Set(),
	_loadedStyleNames: /* @__PURE__ */ new Set(),
	_loadingStyles: /* @__PURE__ */ new Set(),
	_tokens: {},
	_scopedTokenPaths: /* @__PURE__ */ new Set(),
	update(e = {}) {
		let { theme: t } = e;
		t && (this._theme = C(y({}, t), { options: y(y({}, this.defaults.options), t.options) }), this._tokens = $.createTokens(this.preset, this.defaults), this.resetCaches());
	},
	get theme() {
		return this._theme;
	},
	get preset() {
		var e;
		return ((e = this.theme) == null ? void 0 : e.preset) || {};
	},
	get options() {
		var e;
		return ((e = this.theme) == null ? void 0 : e.options) || {};
	},
	get tokens() {
		return this._tokens;
	},
	hasScopedTokenPath(e) {
		return this._scopedTokenPaths.has(e);
	},
	getScopedTokenPaths() {
		return [...this._scopedTokenPaths];
	},
	addScopedToken(e) {
		let t = !1;
		return e && Object.keys(e).length && N$2(e).forEach((s) => {
			let r = ae(s);
			this._scopedTokenPaths.has(r) || (this._scopedTokenPaths.add(r), t = !0);
		}), t;
	},
	clearScopedTokenPaths() {
		this._scopedTokenPaths.clear();
	},
	getTheme() {
		return this.theme;
	},
	setTheme(e) {
		this.update({ theme: e }), R.emit("theme:change", e);
	},
	getPreset() {
		return this.preset;
	},
	setPreset(e) {
		this._theme = C(y({}, this.theme), { preset: e }), this._tokens = $.createTokens(e, this.defaults), this.resetCaches(), R.emit("preset:change", e), R.emit("theme:change", this.theme);
	},
	getOptions() {
		return this.options;
	},
	setOptions(e) {
		this._theme = C(y({}, this.theme), { options: e }), this.resetStyleCaches(), R.emit("options:change", e), R.emit("theme:change", this.theme);
	},
	resetStyleCaches() {
		this.clearLoadedStyleNames(), this.clearLayerNames();
	},
	resetCaches() {
		this.resetStyleCaches(), this.clearScopedTokenPaths();
	},
	getLayerNames() {
		return [...this._layerNames];
	},
	setLayerNames(e) {
		this._layerNames.add(e);
	},
	clearLayerNames() {
		this._layerNames.clear();
	},
	getLoadedStyleNames() {
		return this._loadedStyleNames;
	},
	isStyleNameLoaded(e) {
		return this._loadedStyleNames.has(e);
	},
	setLoadedStyleName(e) {
		this._loadedStyleNames.add(e);
	},
	deleteLoadedStyleName(e) {
		this._loadedStyleNames.delete(e);
	},
	clearLoadedStyleNames() {
		this._loadedStyleNames.clear();
	},
	getTokenValue(e) {
		return $.getTokenValue(this.tokens, e, this.defaults);
	},
	getCommon(e = "", t) {
		return $.getCommon({
			name: e,
			theme: this.theme,
			params: t,
			defaults: this.defaults,
			set: { layerNames: this.setLayerNames.bind(this) }
		});
	},
	getComponent(e = "", t) {
		let s = {
			name: e,
			theme: this.theme,
			params: t,
			defaults: this.defaults,
			set: { layerNames: this.setLayerNames.bind(this) }
		};
		return $.getPresetC(s);
	},
	getDirective(e = "", t) {
		let s = {
			name: e,
			theme: this.theme,
			params: t,
			defaults: this.defaults,
			set: { layerNames: this.setLayerNames.bind(this) }
		};
		return $.getPresetD(s);
	},
	getCustomPreset(e = "", t, s, r) {
		let o = {
			name: e,
			preset: t,
			options: this.options,
			selector: s,
			params: r,
			defaults: this.defaults,
			set: { layerNames: this.setLayerNames.bind(this) },
			isScopedTokenPaths: !0
		};
		return $.getPreset(o);
	},
	getLayerOrderCSS(e = "") {
		return $.getLayerOrder(e, this.options, { names: this.getLayerNames() }, this.defaults);
	},
	transformCSS(e = "", t, s = "style", r) {
		return $.transformCSS(e, t, r, s, this.options, { layerNames: this.setLayerNames.bind(this) }, this.defaults);
	},
	getCommonStyleSheet(e = "", t, s = {}) {
		return $.getCommonStyleSheet({
			name: e,
			theme: this.theme,
			params: t,
			props: s,
			defaults: this.defaults,
			set: { layerNames: this.setLayerNames.bind(this) }
		});
	},
	getStyleSheet(e, t, s = {}) {
		return $.getStyleSheet({
			name: e,
			theme: this.theme,
			params: t,
			props: s,
			defaults: this.defaults,
			set: { layerNames: this.setLayerNames.bind(this) }
		});
	},
	onStyleMounted(e) {
		this._loadingStyles.add(e);
	},
	onStyleUpdated(e) {
		this._loadingStyles.add(e);
	},
	onStyleLoaded(e, { name: t }) {
		this._loadingStyles.size && (this._loadingStyles.delete(t), R.emit(`theme:${t}:load`, e), this._loadingStyles.size || R.emit("theme:load"));
	}
};
//#endregion
//#region node_modules/.pnpm/@primeuix+styles@3.0.0/node_modules/@primeuix/styles/dist/base/index.mjs
var style = "\n    *,\n    ::before,\n    ::after {\n        box-sizing: border-box;\n    }\n\n    .p-component {\n        font-family: dt('typography.font.family');\n        font-feature-settings: inherit;\n        line-height: dt('typography.line.height');\n    }\n\n    .p-collapsible-enter-active {\n        animation: p-animate-collapsible-expand 0.2s ease-out;\n        overflow: hidden;\n    }\n\n    .p-collapsible-leave-active {\n        animation: p-animate-collapsible-collapse 0.2s ease-out;\n        overflow: hidden;\n    }\n\n    @keyframes p-animate-collapsible-expand {\n        from {\n            grid-template-rows: 0fr;\n        }\n        to {\n            grid-template-rows: 1fr;\n        }\n    }\n\n    @keyframes p-animate-collapsible-collapse {\n        from {\n            grid-template-rows: 1fr;\n        }\n        to {\n            grid-template-rows: 0fr;\n        }\n    }\n\n    .p-disabled,\n    .p-disabled * {\n        cursor: default;\n        pointer-events: none;\n        user-select: none;\n    }\n\n    .p-disabled,\n    .p-component:disabled {\n        opacity: dt('disabled.opacity');\n    }\n\n    .pi {\n        font-size: dt('icon.size');\n    }\n\n    .p-icon {\n        width: var(--px-icon-size, dt('icon.size'));\n        height: var(--px-icon-size, dt('icon.size'));\n        flex-shrink: 0;\n    }\n\n    .p-icon-spin {\n        -webkit-animation: p-icon-spin 2s infinite linear;\n        animation: p-icon-spin 2s infinite linear;\n    }\n\n    @-webkit-keyframes p-icon-spin {\n        0% {\n            -webkit-transform: rotate(0deg);\n            transform: rotate(0deg);\n        }\n        100% {\n            -webkit-transform: rotate(359deg);\n            transform: rotate(359deg);\n        }\n    }\n\n    @keyframes p-icon-spin {\n        0% {\n            -webkit-transform: rotate(0deg);\n            transform: rotate(0deg);\n        }\n        100% {\n            -webkit-transform: rotate(359deg);\n            transform: rotate(359deg);\n        }\n    }\n\n    .p-overlay-mask {\n        background: var(--px-mask-background, dt('mask.background'));\n        color: dt('mask.color');\n        position: fixed;\n        top: 0;\n        left: 0;\n        width: 100%;\n        height: 100%;\n    }\n\n    .p-overlay-mask-enter-active {\n        animation: p-animate-overlay-mask-enter dt('mask.transition.duration') forwards;\n    }\n\n    .p-overlay-mask-leave-active {\n        animation: p-animate-overlay-mask-leave dt('mask.transition.duration') forwards;\n    }\n\n    @keyframes p-animate-overlay-mask-enter {\n        from {\n            background: transparent;\n        }\n        to {\n            background: var(--px-mask-background, dt('mask.background'));\n        }\n    }\n    @keyframes p-animate-overlay-mask-leave {\n        from {\n            background: var(--px-mask-background, dt('mask.background'));\n        }\n        to {\n            background: transparent;\n        }\n    }\n\n    .p-anchored-overlay-enter-active {\n        animation: p-animate-anchored-overlay-enter 300ms cubic-bezier(.19,1,.22,1);\n    }\n\n    .p-anchored-overlay-leave-active {\n        animation: p-animate-anchored-overlay-leave 300ms cubic-bezier(.19,1,.22,1);\n    }\n\n    @keyframes p-animate-anchored-overlay-enter {\n        from {\n            opacity: 0;\n            transform: scale(0.93);\n        }\n    }\n\n    @keyframes p-animate-anchored-overlay-leave {\n        to {\n            opacity: 0;\n            transform: scale(0.93);\n        }\n    }\n";
//#endregion
//#region node_modules/.pnpm/@primevue+core@5.0.0_vue@3.5.40_typescript@6.0.3_/node_modules/@primevue/core/usestyle/index.mjs
function _typeof$1(o) {
	"@babel/helpers - typeof";
	return _typeof$1 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof$1(o);
}
function ownKeys$1(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$1(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$1(Object(t), true).forEach(function(r) {
			_defineProperty$1(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$1(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$1(e, r, t) {
	return (r = _toPropertyKey$1(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey$1(t) {
	var i = _toPrimitive$1(t, "string");
	return "symbol" == _typeof$1(i) ? i : i + "";
}
function _toPrimitive$1(t, r) {
	if ("object" != _typeof$1(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof$1(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function tryOnMounted(fn) {
	var sync = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : true;
	if (getCurrentInstance() && getCurrentInstance().components) onMounted(fn);
	else if (sync) fn();
	else nextTick(fn);
}
var _id = 0;
function useStyle(css) {
	var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
	var isLoaded = ref(false);
	var cssRef = ref(css);
	var styleRef = ref(null);
	var defaultDocument = at() ? window.document : void 0;
	var _options$document = options.document, document = _options$document === void 0 ? defaultDocument : _options$document, _options$immediate = options.immediate, immediate = _options$immediate === void 0 ? true : _options$immediate, _options$manual = options.manual, manual = _options$manual === void 0 ? false : _options$manual, _options$name = options.name, name = _options$name === void 0 ? "style_".concat(++_id) : _options$name, _options$id = options.id, id = _options$id === void 0 ? void 0 : _options$id, _options$media = options.media, media = _options$media === void 0 ? void 0 : _options$media, _options$nonce = options.nonce, nonce = _options$nonce === void 0 ? void 0 : _options$nonce, _options$first = options.first, first = _options$first === void 0 ? false : _options$first, _options$onMounted = options.onMounted, onStyleMounted = _options$onMounted === void 0 ? void 0 : _options$onMounted, _options$onUpdated = options.onUpdated, onStyleUpdated = _options$onUpdated === void 0 ? void 0 : _options$onUpdated, _options$onLoad = options.onLoad, onStyleLoaded = _options$onLoad === void 0 ? void 0 : _options$onLoad, _options$props = options.props, props = _options$props === void 0 ? {} : _options$props;
	var stop = function stop() {};
	var load = function load(_css) {
		var _props = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		if (!document) return;
		var _styleProps = _objectSpread$1(_objectSpread$1({}, props), _props);
		var _name = _styleProps.name || name, _id = _styleProps.id || id, _nonce = _styleProps.nonce || nonce;
		styleRef.value = document.querySelector("style[data-primevue-style-id=\"".concat(_name, "\"]")) || document.getElementById(_id) || document.createElement("style");
		if (!styleRef.value.isConnected) {
			cssRef.value = _css || css;
			N$1(styleRef.value, {
				type: "text/css",
				id: _id,
				media,
				nonce: _nonce
			});
			first ? document.head.prepend(styleRef.value) : document.head.appendChild(styleRef.value);
			de(styleRef.value, "data-primevue-style-id", _name);
			N$1(styleRef.value, _styleProps);
			styleRef.value.onload = function(event) {
				return onStyleLoaded === null || onStyleLoaded === void 0 ? void 0 : onStyleLoaded(event, { name: _name });
			};
			onStyleMounted === null || onStyleMounted === void 0 || onStyleMounted(_name);
		}
		if (isLoaded.value) return;
		stop = watch(cssRef, function(value) {
			styleRef.value.textContent = value;
			onStyleUpdated === null || onStyleUpdated === void 0 || onStyleUpdated(_name);
		}, { immediate: true });
		isLoaded.value = true;
	};
	var unload = function unload() {
		if (!document || !isLoaded.value) return;
		stop();
		H(styleRef.value) && document.head.removeChild(styleRef.value);
		isLoaded.value = false;
		styleRef.value = null;
	};
	if (immediate && !manual) tryOnMounted(load);
	return {
		id,
		name,
		el: styleRef,
		css: cssRef,
		unload,
		load,
		isLoaded: readonly(isLoaded)
	};
}
//#endregion
//#region node_modules/.pnpm/@primevue+core@5.0.0_vue@3.5.40_typescript@6.0.3_/node_modules/@primevue/core/base/style/index.mjs
function _typeof(o) {
	"@babel/helpers - typeof";
	return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
		return typeof o;
	} : function(o) {
		return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
	}, _typeof(o);
}
var _templateObject;
var _templateObject2;
var _templateObject3;
var _templateObject4;
function _slicedToArray(r, e) {
	return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
}
function _nonIterableRest() {
	throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(r, a) {
	if (r) {
		if ("string" == typeof r) return _arrayLikeToArray(r, a);
		var t = {}.toString.call(r).slice(8, -1);
		return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
	}
}
function _arrayLikeToArray(r, a) {
	(null == a || a > r.length) && (a = r.length);
	for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
	return n;
}
function _iterableToArrayLimit(r, l) {
	var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
	if (null != t) {
		var e, n, i, u, a = [], f = true, o = false;
		try {
			if (i = (t = t.call(r)).next, 0 === l);
			else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
		} catch (r) {
			o = true, n = r;
		} finally {
			try {
				if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
			} finally {
				if (o) throw n;
			}
		}
		return a;
	}
}
function _arrayWithHoles(r) {
	if (Array.isArray(r)) return r;
}
function ownKeys(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys(Object(t), true).forEach(function(r) {
			_defineProperty(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty(e, r, t) {
	return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: true,
		configurable: true,
		writable: true
	}) : e[r] = t, e;
}
function _toPropertyKey(t) {
	var i = _toPrimitive(t, "string");
	return "symbol" == _typeof(i) ? i : i + "";
}
function _toPrimitive(t, r) {
	if ("object" != _typeof(t) || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r);
		if ("object" != _typeof(i)) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _taggedTemplateLiteral(e, t) {
	return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, { raw: { value: Object.freeze(t) } }));
}
var BaseStyle = {
	name: "base",
	css: function css(_ref) {
		var dt = _ref.dt;
		return "\n.p-hidden-accessible {\n    border: 0;\n    clip: rect(0 0 0 0);\n    height: 1px;\n    margin: -1px;\n    opacity: 0;\n    overflow: hidden;\n    padding: 0;\n    pointer-events: none;\n    position: absolute;\n    white-space: nowrap;\n    width: 1px;\n}\n\n.p-overflow-hidden {\n    overflow: hidden;\n    padding-right: ".concat(dt("scrollbar.width"), ";\n}\n");
	},
	style,
	classes: {},
	inlineStyles: {},
	load: function load(style) {
		var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		var computedStyle = (arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : function(cs) {
			return cs;
		})(gs(_templateObject || (_templateObject = _taggedTemplateLiteral(["", ""])), style));
		return l(computedStyle) ? useStyle(B(computedStyle), _objectSpread({ name: this.name }, options)) : {};
	},
	loadCSS: function loadCSS() {
		var options = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		return this.load(this.css, options);
	},
	loadStyle: function loadStyle() {
		var _this = this;
		var options = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
		var style = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
		return this.load(this.style, options, function() {
			var computedStyle = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
			return S.transformCSS(options.name || _this.name, "".concat(computedStyle).concat(gs(_templateObject2 || (_templateObject2 = _taggedTemplateLiteral(["", ""])), style)));
		});
	},
	getCommonTheme: function getCommonTheme(params) {
		return S.getCommon(this.name, params);
	},
	getComponentTheme: function getComponentTheme(params) {
		return S.getComponent(this.name, params);
	},
	getDirectiveTheme: function getDirectiveTheme(params) {
		return S.getDirective(this.name, params);
	},
	getPresetTheme: function getPresetTheme(preset, selector, params) {
		return S.getCustomPreset(this.name, preset, selector, params);
	},
	getLayerOrderThemeCSS: function getLayerOrderThemeCSS() {
		return S.getLayerOrderCSS(this.name);
	},
	getStyleSheet: function getStyleSheet() {
		var extendedCSS = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
		var props = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		if (this.css) {
			var _css = x$2(this.css, { dt: N }) || "";
			var _style = B(gs(_templateObject3 || (_templateObject3 = _taggedTemplateLiteral([
				"",
				"",
				""
			])), _css, extendedCSS));
			var _props = Object.entries(props).reduce(function(acc, _ref2) {
				var _ref3 = _slicedToArray(_ref2, 2), k = _ref3[0], v = _ref3[1];
				return acc.push("".concat(k, "=\"").concat(v, "\"")) && acc;
			}, []).join(" ");
			return l(_style) ? "<style type=\"text/css\" data-primevue-style-id=\"".concat(this.name, "\" ").concat(_props, ">").concat(_style, "</style>") : "";
		}
		return "";
	},
	getCommonThemeStyleSheet: function getCommonThemeStyleSheet(params) {
		var props = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		return S.getCommonStyleSheet(this.name, params, props);
	},
	getThemeStyleSheet: function getThemeStyleSheet(params) {
		var props = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		var css = [S.getStyleSheet(this.name, params, props)];
		if (this.style) {
			var name = this.name === "base" ? "global-style" : "".concat(this.name, "-style");
			var _css = gs(_templateObject4 || (_templateObject4 = _taggedTemplateLiteral(["", ""])), x$2(this.style, { dt: N }));
			var _style = B(S.transformCSS(name, _css));
			var _props = Object.entries(props).reduce(function(acc, _ref4) {
				var _ref5 = _slicedToArray(_ref4, 2), k = _ref5[0], v = _ref5[1];
				return acc.push("".concat(k, "=\"").concat(v, "\"")) && acc;
			}, []).join(" ");
			l(_style) && css.push("<style type=\"text/css\" data-primevue-style-id=\"".concat(name, "\" ").concat(_props, ">").concat(_style, "</style>"));
		}
		return css.join("");
	},
	extend: function extend(inStyle) {
		return _objectSpread(_objectSpread({}, this), {}, {
			css: void 0,
			style: void 0
		}, inStyle);
	}
};
//#endregion
//#region node_modules/.pnpm/@primevue+core@5.0.0_vue@3.5.40_typescript@6.0.3_/node_modules/@primevue/core/license/licenseBanner/index.mjs
/**
* Inject a fixed-positioned banner into the bottom-right of the page when the
* PrimeVue license cannot be verified.
*
* The banner content is rendered inside a closed-mode shadow root so page-level
* CSS cannot reach into it. `all:initial` on the host element blocks inherited
* styles. The host carries no semantically obvious id, slowing down trivial
* hide-by-selector attempts.
*
* Idempotent — guarded by the host id, so multiple call sites (the plugin's
* verify promise resolving, BaseComponent detecting a missing plugin install)
* cannot produce more than one banner per page.
*
* SSR-safe — short-circuits when `document` is undefined.
*
* Note: client-side license enforcement is anti-honest-user signaling, not
* anti-piracy. The cryptographic signature (Ed25519) is what actually prevents
* forging valid tokens. This banner just makes the licensing problem visible
* to a legitimate customer whose key needs attention.
*/
function showInvalidLicenseBanner() {
	if (typeof document === "undefined") return;
	if (document.getElementById("p-license-host")) return;
	var host = document.createElement("div");
	host.id = "p-license-host";
	host.style.cssText = "all:initial;position:fixed;bottom:16px;right:16px;z-index:2147483647;pointer-events:none;";
	var shadow = host.attachShadow({ mode: "closed" });
	shadow.innerHTML = "<div role=\"alert\" style=\"padding:10px 14px;background:#991b1b;color:#fff;font:600 13px/1.2 system-ui,-apple-system,sans-serif;border-radius:6px;box-shadow:0 4px 12px rgba(0,0,0,0.2);\">Invalid PrimeUI License</div>";
	document.body.appendChild(host);
}
//#endregion
export { Q$1 as A, k as C, A$1 as D, st as E, m as F, p$1 as I, s as L, fe as M, ie as N, C$2 as O, l as P, x$2 as R, jt as S, ot$1 as T, Wt as _, us as a, h$1 as b, C$1 as c, L$1 as d, Nt as f, W as g, R$1 as h, S as i, c as j, K$1 as k, Gt as l, Q as m, BaseStyle as n, x as o, Pt as p, R as r, v as s, showInvalidLicenseBanner as t, Ht as u, at as v, mt as w, ht as x, de as y };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGljZW5zZUJhbm5lci1CSm02X011My5qcyIsIm5hbWVzIjpbImNlIiwiJCIsInBlIiwiZ2UiLCJwIiwibWUiLCJTIiwieCIsIkMiLCJLIiwiQSIsIkgiLCJRIiwiZGUiLCJYIiwiTiIsIlIiLCJoIiwiUyIsInBlIiwiY2UiLCJnZSIsImhlIiwiUCIsInllIiwidiIsIkwiLCJDIiwiTiIsIm90IiwieCIsImx0IiwiRCIsIl9lIiwic2UiLCJodCIsIm10IiwibGUiLCJidCIsInl0IiwiamUiLCJzIiwiUHQiLCIkdCIsIl90IiwibCIsIngiLCJpZSIsIndlIiwiZmUiLCJOZSIsInZ0IiwiQ3QiLCJWdCIsIlJ0IiwiX3R5cGVvZiIsIm93bktleXMiLCJfb2JqZWN0U3ByZWFkIiwiX2RlZmluZVByb3BlcnR5IiwiX3RvUHJvcGVydHlLZXkiLCJfdG9QcmltaXRpdmUiLCJpc0NsaWVudCIsImNzcyQxIiwiaXNOb3RFbXB0eSIsIm1pbmlmeUNTUyIsIlRoZW1lIiwicmVzb2x2ZSIsImR0Il0sInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLnBucG0vQHByaW1ldWl4K3V0aWxzQDAuOC4wL25vZGVfbW9kdWxlcy9AcHJpbWV1aXgvdXRpbHMvZGlzdC9vYmplY3QvaW5kZXgubWpzIiwiLi4vLi4vLi4vLi4vLnBucG0vQHByaW1ldWl4K3V0aWxzQDAuOC4wL25vZGVfbW9kdWxlcy9AcHJpbWV1aXgvdXRpbHMvZGlzdC9kb20vaW5kZXgubWpzIiwiLi4vLi4vLi4vLi4vLnBucG0vQHByaW1ldWl4K3V0aWxzQDAuOC4wL25vZGVfbW9kdWxlcy9AcHJpbWV1aXgvdXRpbHMvZGlzdC9ldmVudGJ1cy9pbmRleC5tanMiLCIuLi8uLi8uLi8uLi8ucG5wbS9AcHJpbWV1aXgrdXRpbHNAMC44LjAvbm9kZV9tb2R1bGVzL0BwcmltZXVpeC91dGlscy9kaXN0L3ppbmRleC9pbmRleC5tanMiLCIuLi8uLi8uLi8uLi8ucG5wbS9AcHJpbWV1aXgrc3R5bGVkQDEuMC4wL25vZGVfbW9kdWxlcy9AcHJpbWV1aXgvc3R5bGVkL2Rpc3QvaW5kZXgubWpzIiwiLi4vLi4vLi4vLi4vLnBucG0vQHByaW1ldWl4K3N0eWxlc0AzLjAuMC9ub2RlX21vZHVsZXMvQHByaW1ldWl4L3N0eWxlcy9kaXN0L2Jhc2UvaW5kZXgubWpzIiwiLi4vLi4vLi4vLi4vLnBucG0vQHByaW1ldnVlK2NvcmVANS4wLjBfdnVlQDMuNS40MF90eXBlc2NyaXB0QDYuMC4zXy9ub2RlX21vZHVsZXMvQHByaW1ldnVlL2NvcmUvdXNlc3R5bGUvaW5kZXgubWpzIiwiLi4vLi4vLi4vLi4vLnBucG0vQHByaW1ldnVlK2NvcmVANS4wLjBfdnVlQDMuNS40MF90eXBlc2NyaXB0QDYuMC4zXy9ub2RlX21vZHVsZXMvQHByaW1ldnVlL2NvcmUvYmFzZS9zdHlsZS9pbmRleC5tanMiLCIuLi8uLi8uLi8uLi8ucG5wbS9AcHJpbWV2dWUrY29yZUA1LjAuMF92dWVAMy41LjQwX3R5cGVzY3JpcHRANi4wLjNfL25vZGVfbW9kdWxlcy9AcHJpbWV2dWUvY29yZS9saWNlbnNlL2xpY2Vuc2VCYW5uZXIvaW5kZXgubWpzIl0sInNvdXJjZXNDb250ZW50IjpbInZhciBjZT1PYmplY3QuZGVmaW5lUHJvcGVydHk7dmFyICQ9T2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9sczt2YXIgcGU9T2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eSxnZT1PYmplY3QucHJvdG90eXBlLnByb3BlcnR5SXNFbnVtZXJhYmxlO3ZhciBxPShlLHQsbik9PnQgaW4gZT9jZShlLHQse2VudW1lcmFibGU6ITAsY29uZmlndXJhYmxlOiEwLHdyaXRhYmxlOiEwLHZhbHVlOm59KTplW3RdPW4sRT0oZSx0KT0+e2Zvcih2YXIgbiBpbiB0fHwodD17fSkpcGUuY2FsbCh0LG4pJiZxKGUsbix0W25dKTtpZigkKWZvcih2YXIgbiBvZiAkKHQpKWdlLmNhbGwodCxuKSYmcShlLG4sdFtuXSk7cmV0dXJuIGV9O2Z1bmN0aW9uIHAoZSl7cmV0dXJuIGU9PW51bGx8fGU9PT1cIlwifHxBcnJheS5pc0FycmF5KGUpJiZlLmxlbmd0aD09PTB8fCEoZSBpbnN0YW5jZW9mIERhdGUpJiZ0eXBlb2YgZT09XCJvYmplY3RcIiYmT2JqZWN0LmtleXMoZSkubGVuZ3RoPT09MH1mdW5jdGlvbiBUKGUsdCxuLHI9MSl7bGV0IG89LTEsdT1wKGUpLGk9cCh0KTtyZXR1cm4gdSYmaT9vPTA6dT9vPXI6aT9vPS1yOnR5cGVvZiBlPT1cInN0cmluZ1wiJiZ0eXBlb2YgdD09XCJzdHJpbmdcIj9vPW4oZSx0KTpvPWU8dD8tMTplPnQ/MTowLG99ZnVuY3Rpb24gTyhlLHQsbil7aWYoZT09PXR8fGUhPT1lJiZ0IT09dClyZXR1cm4hMDtpZighZXx8IXR8fHR5cGVvZiBlIT1cIm9iamVjdFwifHx0eXBlb2YgdCE9XCJvYmplY3RcIilyZXR1cm4hMTtufHwobj1uZXcgV2Vha01hcCk7bGV0IHI9bi5nZXQoZSk7aWYociE9bnVsbCYmci5oYXModCkpcmV0dXJuITA7cnx8bi5zZXQoZSxyPW5ldyBXZWFrU2V0KSxyLmFkZCh0KTtsZXQgbz1BcnJheS5pc0FycmF5KGUpLHU9QXJyYXkuaXNBcnJheSh0KSxpPSEwO2lmKG8mJnUpe2lmKGUubGVuZ3RoIT09dC5sZW5ndGgpaT0hMTtlbHNlIGZvcihsZXQgZj1lLmxlbmd0aDtmLS0hPT0wOylpZighTyhlW2ZdLHRbZl0sbikpe2k9ITE7YnJlYWt9fWVsc2UgaWYobyE9PXUpaT0hMTtlbHNle2xldCBmPWUgaW5zdGFuY2VvZiBEYXRlLGE9dCBpbnN0YW5jZW9mIERhdGU7aWYoZiE9PWEpaT0hMTtlbHNlIGlmKGYmJmEpaT1lLmdldFRpbWUoKT09PXQuZ2V0VGltZSgpO2Vsc2V7bGV0IHk9ZSBpbnN0YW5jZW9mIFJlZ0V4cCxrPXQgaW5zdGFuY2VvZiBSZWdFeHA7aWYoeSE9PWspaT0hMTtlbHNlIGlmKHkmJmspaT1lLnRvU3RyaW5nKCk9PT10LnRvU3RyaW5nKCk7ZWxzZSBpZihlIGluc3RhbmNlb2YgTWFwfHx0IGluc3RhbmNlb2YgTWFwKXtpZighKGUgaW5zdGFuY2VvZiBNYXAmJnQgaW5zdGFuY2VvZiBNYXApfHxlLnNpemUhPT10LnNpemUpaT0hMTtlbHNlIGZvcihsZXRbZyx3XW9mIGUpaWYoIXQuaGFzKGcpfHwhTyh3LHQuZ2V0KGcpLG4pKXtpPSExO2JyZWFrfX1lbHNlIGlmKGUgaW5zdGFuY2VvZiBTZXR8fHQgaW5zdGFuY2VvZiBTZXQpe2lmKCEoZSBpbnN0YW5jZW9mIFNldCYmdCBpbnN0YW5jZW9mIFNldCl8fGUuc2l6ZSE9PXQuc2l6ZSlpPSExO2Vsc2UgZm9yKGxldCBnIG9mIGUpaWYoIXQuaGFzKGcpKXtpPSExO2JyZWFrfX1lbHNle2xldCBnPU9iamVjdC5rZXlzKGUpLHc9Zy5sZW5ndGg7aWYodyE9PU9iamVjdC5rZXlzKHQpLmxlbmd0aClpPSExO2Vsc2V7Zm9yKGxldCBoPXc7aC0tIT09MDspaWYoIU9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbCh0LGdbaF0pKXtpPSExO2JyZWFrfWlmKGkpZm9yKGxldCBoPXc7aC0tIT09MDspe2xldCBNPWdbaF07aWYoIU8oZVtNXSx0W01dLG4pKXtpPSExO2JyZWFrfX19fX19cmV0dXJuIGl8fHIuZGVsZXRlKHQpLGl9ZnVuY3Rpb24gUihlLHQpe3JldHVybiBPKGUsdCl9ZnVuY3Rpb24gbShlKXtyZXR1cm4gdHlwZW9mIGU9PVwiZnVuY3Rpb25cIiYmXCJjYWxsXCJpbiBlJiZcImFwcGx5XCJpbiBlfWZ1bmN0aW9uIGwoZSl7cmV0dXJuIXAoZSl9ZnVuY3Rpb24gZChlLHQpe2lmKCFlfHwhdClyZXR1cm4gbnVsbDtsZXQgbj1lO3RyeXtsZXQgcj1uW3RdO2lmKGwocikpcmV0dXJuIHJ9Y2F0Y2gocil7fWlmKE9iamVjdC5rZXlzKG4pLmxlbmd0aCl7aWYobSh0KSlyZXR1cm4gdChlKTtpZih0LmluZGV4T2YoXCIuXCIpPT09LTEpcmV0dXJuIG5bdF07e2xldCByPXQuc3BsaXQoXCIuXCIpLG89ZTtmb3IobGV0IHU9MCxpPXIubGVuZ3RoO3U8aTsrK3Upe2lmKG89PW51bGwpcmV0dXJuIG51bGw7bz1vW3JbdV1dfXJldHVybiBvfX1yZXR1cm4gbnVsbH1mdW5jdGlvbiBiKGUsdCxuKXtyZXR1cm4gbj9kKGUsbik9PT1kKHQsbik6UihlLHQpfWZ1bmN0aW9uIF8oZSx0KXtpZihlIT1udWxsJiZ0JiZ0Lmxlbmd0aCl7Zm9yKGxldCBuIG9mIHQpaWYoYihlLG4pKXJldHVybiEwfXJldHVybiExfWZ1bmN0aW9uIHMoZSx0PSEwKXtyZXR1cm4gZSBpbnN0YW5jZW9mIE9iamVjdCYmZS5jb25zdHJ1Y3Rvcj09PU9iamVjdCYmKHR8fE9iamVjdC5rZXlzKGUpLmxlbmd0aCE9PTApfXZhciBtZT1uZXcgU2V0KFtcIl9fcHJvdG9fX1wiLFwiY29uc3RydWN0b3JcIixcInByb3RvdHlwZVwiXSk7ZnVuY3Rpb24gUyhlLHQsbixyPW5ldyBXZWFrU2V0KXtsZXQgbz1FKHt9LGUpO09iamVjdC5rZXlzKG8pLmxlbmd0aD09PTAmJiFuLmhhcyh0KSYmbi5zZXQodCxvKTtsZXQgdT0hci5oYXModCk7cmV0dXJuIHUmJnIuYWRkKHQpLE9iamVjdC5rZXlzKHQpLmZvckVhY2goaT0+e3ZhciB5LGs7aWYobWUuaGFzKGkpKXJldHVybjtsZXQgZj1pLGE9dFtmXTtzKGEpJiZmIGluIGUmJnMoZVtmXSk/b1tmXT1yLmhhcyhhKT8oeT1uLmdldChhKSkhPW51bGw/eTpTKHt9LGEsbixyKTpTKGVbZl0sYSxuLHIpOnMoYSk/b1tmXT0oaz1uLmdldChhKSkhPW51bGw/azpTKHt9LGEsbixyKTpvW2ZdPWF9KSx1JiZyLmRlbGV0ZSh0KSxvfWZ1bmN0aW9uIEYoLi4uZSl7cmV0dXJuIGUucmVkdWNlKCh0LG4pPT5TKHQsbnx8e30sbmV3IFdlYWtNYXApLHt9KX1mdW5jdGlvbiBQKGUsdCxuKXtsZXQgcj1bXTtpZihlKXtmb3IobGV0IG8gb2YgZSlmb3IobGV0IHUgb2YgdClpZihTdHJpbmcoZChvLHUpKS50b0xvd2VyQ2FzZSgpLmluZGV4T2Yobi50b0xvd2VyQ2FzZSgpKT4tMSl7ci5wdXNoKG8pO2JyZWFrfX1yZXR1cm4gcn1mdW5jdGlvbiBEKGUsdCl7bGV0IG49LTE7aWYodCl7Zm9yKGxldCByPTA7cjx0Lmxlbmd0aDtyKyspaWYodFtyXT09PWUpe249cjticmVha319cmV0dXJuIG59ZnVuY3Rpb24gVyhlLHQpe2xldCBuO2lmKGwoZSkpdHJ5e249ZS5maW5kTGFzdCh0KX1jYXRjaChyKXtuPVsuLi5lXS5yZXZlcnNlKCkuZmluZCh0KX1yZXR1cm4gbn1mdW5jdGlvbiB6KGUsdCl7bGV0IG49LTE7aWYobChlKSl0cnl7bj1lLmZpbmRMYXN0SW5kZXgodCl9Y2F0Y2gocil7bj1lLmxhc3RJbmRleE9mKFsuLi5lXS5yZXZlcnNlKCkuZmluZCh0KSl9cmV0dXJuIG59ZnVuY3Rpb24geChlLC4uLnQpe3JldHVybiBtKGUpP2UoLi4udCk6ZX1mdW5jdGlvbiBjKGUsdD0hMCl7cmV0dXJuIHR5cGVvZiBlPT1cInN0cmluZ1wiJiYodHx8ZSE9PVwiXCIpfWZ1bmN0aW9uIEMoZSl7cmV0dXJuIGMoZSk/ZS5yZXBsYWNlKC8oLXxfKS9nLFwiXCIpLnRvTG93ZXJDYXNlKCk6ZX1mdW5jdGlvbiBLKGUsdD1cIlwiLG49e30pe2xldCByPUModCkuc3BsaXQoXCIuXCIpLG89ci5zaGlmdCgpO2lmKG8pe2lmKHMoZSl8fEFycmF5LmlzQXJyYXkoZSkpe2xldCB1PU9iamVjdC5rZXlzKGUpLmZpbmQoaT0+QyhpKT09PW8pfHxcIlwiO3JldHVybiBLKHgoZVt1XSxuKSxyLmpvaW4oXCIuXCIpLG4pfXJldHVybn1yZXR1cm4geChlLG4pfWZ1bmN0aW9uIFYoZSx0LG4scil7aWYobi5sZW5ndGg+MCl7bGV0IG89ITE7Zm9yKGxldCB1PTA7dTxuLmxlbmd0aDt1KyspaWYoRChuW3VdLHIpPnQpe24uc3BsaWNlKHUsMCxlKSxvPSEwO2JyZWFrfW98fG4ucHVzaChlKX1lbHNlIG4ucHVzaChlKX1mdW5jdGlvbiBBKGUsdD0hMCl7cmV0dXJuIEFycmF5LmlzQXJyYXkoZSkmJih0fHxlLmxlbmd0aCE9PTApfWZ1bmN0aW9uIEkoZSl7cmV0dXJuIGUgaW5zdGFuY2VvZiBEYXRlfWZ1bmN0aW9uIFUoZSl7cmV0dXJuL15bYS16QS1aXFx1MDBDMC1cXHUwMTdGXSQvLnRlc3QoZSl9ZnVuY3Rpb24gWihlKXtyZXR1cm4gbChlKSYmIWlzTmFOKGUpfWZ1bmN0aW9uIEooZT1cIlwiKXtyZXR1cm4gbChlKSYmZS5sZW5ndGg9PT0xJiYhIWUubWF0Y2goL1xcU3wgLyl9ZnVuY3Rpb24gWShlKXtyZXR1cm4gZSE9bnVsbCYmKHR5cGVvZiBlPT1cInN0cmluZ1wifHx0eXBlb2YgZT09XCJudW1iZXJcInx8dHlwZW9mIGU9PVwiYmlnaW50XCJ8fHR5cGVvZiBlPT1cImJvb2xlYW5cIil9ZnVuY3Rpb24gRygpe3JldHVybiBuZXcgSW50bC5Db2xsYXRvcih2b2lkIDAse251bWVyaWM6ITB9KS5jb21wYXJlfWZ1bmN0aW9uIEgoZSx0KXtpZih0KXt0Lmxhc3RJbmRleD0wO2xldCBuPXQudGVzdChlKTtyZXR1cm4gdC5sYXN0SW5kZXg9MCxufXJldHVybiExfWZ1bmN0aW9uIFEoLi4uZSl7cmV0dXJuIEYoLi4uZSl9ZnVuY3Rpb24gZGUoZSx0KXtsZXQgbj0wO2Zvcig7dC0xLW4+PTAmJmVbdC0xLW5dPT09XCJcXFxcXCI7KW4rKztyZXR1cm4gbiUyPT09MX1mdW5jdGlvbiBYKGUpe3JldHVybiBlLnJlcGxhY2UoL1tcXHJcXG5cXHRdKy9nLFwiXCIpLnJlcGxhY2UoLyB7Mix9L2csXCIgXCIpLnJlcGxhY2UoLyAoW3s6fV0pIC9nLFwiJDFcIikucmVwbGFjZSgvKFs7LF0pIC9nLFwiJDFcIikucmVwbGFjZSgvICEvZyxcIiFcIikucmVwbGFjZSgvOiAvZyxcIjpcIil9ZnVuY3Rpb24gQihlKXtpZighZSlyZXR1cm4gZTtsZXQgdD1cIlwiLG49XCJcIixyPTA7Zm9yKDtyPGUubGVuZ3RoOyl7bGV0IG89ZVtyXTtpZihvPT09XCIvXCImJmVbcisxXT09PVwiKlwiKXtsZXQgdT1lLmluZGV4T2YoXCIqL1wiLHIrMik7cj11PT09LTE/ZS5sZW5ndGg6dSsyfWVsc2UgaWYobz09PSdcIid8fG89PT1cIidcIil7dCs9WChuKSxuPVwiXCI7bGV0IHU9cisxO2Zvcig7dTxlLmxlbmd0aCYmKGVbdV0hPT1vfHxkZShlLHUpKTspdSsrO3QrPWUuc2xpY2UocixNYXRoLm1pbih1KzEsZS5sZW5ndGgpKSxyPXUrMX1lbHNlIG4rPW8scisrfXJldHVybih0K1gobikpLnRyaW0oKX1mdW5jdGlvbiBOKGU9e30sdD1cIlwiKXtyZXR1cm4gT2JqZWN0LmVudHJpZXMoZSkucmVkdWNlKChuLFtyLG9dKT0+e2xldCB1PXQ/YCR7dH0uJHtyfWA6cjtyZXR1cm4gcyhvKT9uPW4uY29uY2F0KE4obyx1KSk6bi5wdXNoKHUpLG59LFtdKX1mdW5jdGlvbiB2KGUsLi4udCl7aWYoIXMoZSkpcmV0dXJuIGU7bGV0IG49RSh7fSxlKTtyZXR1cm4gdD09bnVsbHx8dC5mbGF0KCkuZm9yRWFjaChyPT5kZWxldGUgbltyXSksbn12YXIgeGU9L1tcXHhDMC1cXHhGRlxcdTAxMDAtXFx1MDE3RV0vLGo9e0E6L1tcXHhDMC1cXHhDNVxcdTAxMDBcXHUwMTAyXFx1MDEwNF0vZyxBRTovW1xceEM2XS9nLEM6L1tcXHhDN1xcdTAxMDZcXHUwMTA4XFx1MDEwQVxcdTAxMENdL2csRDovW1xceEQwXFx1MDEwRVxcdTAxMTBdL2csRTovW1xceEM4LVxceENCXFx1MDExMlxcdTAxMTRcXHUwMTE2XFx1MDExOFxcdTAxMUFdL2csRzovW1xcdTAxMUNcXHUwMTFFXFx1MDEyMFxcdTAxMjJdL2csSDovW1xcdTAxMjRcXHUwMTI2XS9nLEk6L1tcXHhDQy1cXHhDRlxcdTAxMjhcXHUwMTJBXFx1MDEyQ1xcdTAxMkVcXHUwMTMwXS9nLElKOi9bXFx1MDEzMl0vZyxKOi9bXFx1MDEzNF0vZyxLOi9bXFx1MDEzNl0vZyxMOi9bXFx1MDEzOVxcdTAxM0JcXHUwMTNEXFx1MDEzRlxcdTAxNDFdL2csTjovW1xceEQxXFx1MDE0M1xcdTAxNDVcXHUwMTQ3XFx1MDE0QV0vZyxPOi9bXFx4RDItXFx4RDZcXHhEOFxcdTAxNENcXHUwMTRFXFx1MDE1MF0vZyxPRTovW1xcdTAxNTJdL2csUjovW1xcdTAxNTRcXHUwMTU2XFx1MDE1OF0vZyxTOi9bXFx1MDE1QVxcdTAxNUNcXHUwMTVFXFx1MDE2MF0vZyxUOi9bXFx1MDE2MlxcdTAxNjRcXHUwMTY2XS9nLFU6L1tcXHhEOS1cXHhEQ1xcdTAxNjhcXHUwMTZBXFx1MDE2Q1xcdTAxNkVcXHUwMTcwXFx1MDE3Ml0vZyxXOi9bXFx1MDE3NF0vZyxZOi9bXFx4RERcXHUwMTc2XFx1MDE3OF0vZyxaOi9bXFx1MDE3OVxcdTAxN0JcXHUwMTdEXS9nLGE6L1tcXHhFMC1cXHhFNVxcdTAxMDFcXHUwMTAzXFx1MDEwNV0vZyxhZTovW1xceEU2XS9nLGM6L1tcXHhFN1xcdTAxMDdcXHUwMTA5XFx1MDEwQlxcdTAxMERdL2csZDovW1xcdTAxMEZcXHUwMTExXS9nLGU6L1tcXHhFOC1cXHhFQlxcdTAxMTNcXHUwMTE1XFx1MDExN1xcdTAxMTlcXHUwMTFCXS9nLGc6L1tcXHUwMTFEXFx1MDExRlxcdTAxMjFcXHUwMTIzXS9nLGk6L1tcXHhFQy1cXHhFRlxcdTAxMjlcXHUwMTJCXFx1MDEyRFxcdTAxMkZcXHUwMTMxXS9nLGlqOi9bXFx1MDEzM10vZyxqOi9bXFx1MDEzNV0vZyxrOi9bXFx1MDEzNyxcXHUwMTM4XS9nLGw6L1tcXHUwMTNBXFx1MDEzQ1xcdTAxM0VcXHUwMTQwXFx1MDE0Ml0vZyxuOi9bXFx4RjFcXHUwMTQ0XFx1MDE0NlxcdTAxNDhcXHUwMTRCXS9nLHA6L1tcXHhGRV0vZyxvOi9bXFx4RjItXFx4RjZcXHhGOFxcdTAxNERcXHUwMTRGXFx1MDE1MV0vZyxvZTovW1xcdTAxNTNdL2cscjovW1xcdTAxNTVcXHUwMTU3XFx1MDE1OV0vZyxzOi9bXFx1MDE1QlxcdTAxNURcXHUwMTVGXFx1MDE2MV0vZyx0Oi9bXFx1MDE2M1xcdTAxNjVcXHUwMTY3XS9nLHU6L1tcXHhGOS1cXHhGQ1xcdTAxNjlcXHUwMTZCXFx1MDE2RFxcdTAxNkZcXHUwMTcxXFx1MDE3M10vZyx3Oi9bXFx1MDE3NV0vZyx5Oi9bXFx4RkRcXHhGRlxcdTAxNzddL2csejovW1xcdTAxN0FcXHUwMTdDXFx1MDE3RV0vZ307ZnVuY3Rpb24gZWUoZSl7aWYoZSYmeGUudGVzdChlKSlmb3IobGV0IHQgaW4gaillPWUucmVwbGFjZShqW3RdLHQpO3JldHVybiBlfWZ1bmN0aW9uIHRlKGUsdCxuKXtlJiZ0IT09biYmKG4+PWUubGVuZ3RoJiYobiU9ZS5sZW5ndGgsdCU9ZS5sZW5ndGgpLGUuc3BsaWNlKG4sMCxlLnNwbGljZSh0LDEpWzBdKSl9ZnVuY3Rpb24gbmUoZSx0KXtpZihlPT09dClyZXR1cm4hMDtsZXQgbj1PYmplY3Qua2V5cyhlKSxyPU9iamVjdC5rZXlzKHQpO2lmKG4ubGVuZ3RoIT09ci5sZW5ndGgpcmV0dXJuITE7Zm9yKGxldCBvIG9mIG4pe2xldCB1PWVbb10saT10W29dO2lmKCEodHlwZW9mIHU9PVwiZnVuY3Rpb25cIiYmdHlwZW9mIGk9PVwiZnVuY3Rpb25cIikmJiFPYmplY3QuaXModSxpKSlyZXR1cm4hMX1yZXR1cm4hMH1mdW5jdGlvbiByZShlLHQpe2lmKGU9PT10KXJldHVybiEwO2lmKHR5cGVvZiBlIT10eXBlb2YgdHx8ZT09PW51bGx8fHQ9PT1udWxsKXJldHVybiExO2lmKHR5cGVvZiBlIT1cIm9iamVjdFwiKXJldHVybiBlPT09dDtpZihPYmplY3QuaXMoZSx0KSlyZXR1cm4hMDtpZih0eXBlb2YgZSE9XCJvYmplY3RcInx8ZT09PW51bGx8fHR5cGVvZiB0IT1cIm9iamVjdFwifHx0PT09bnVsbClyZXR1cm4hMTtpZihBcnJheS5pc0FycmF5KGUpJiZBcnJheS5pc0FycmF5KHQpKXtpZihlLmxlbmd0aCE9PXQubGVuZ3RoKXJldHVybiExO2ZvcihsZXQgbz0wO288ZS5sZW5ndGg7bysrKWlmKCFPYmplY3QuaXMoZVtvXSx0W29dKSlyZXR1cm4hMTtyZXR1cm4hMH1pZihBcnJheS5pc0FycmF5KGUpfHxBcnJheS5pc0FycmF5KHQpKXJldHVybiExO2xldCBuPU9iamVjdC5rZXlzKGUpLHI9T2JqZWN0LmtleXModCk7aWYobi5sZW5ndGghPT1yLmxlbmd0aClyZXR1cm4hMTtmb3IobGV0IG8gb2YgbilpZighT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHQsbyl8fCFPYmplY3QuaXMoZVtvXSx0W29dKSlyZXR1cm4hMTtyZXR1cm4hMH1mdW5jdGlvbiBvZShlLHQsbj0xLHIsbz0xKXtsZXQgdT1UKGUsdCxyLG4pLGk9bjtyZXR1cm4ocChlKXx8cCh0KSkmJihpPW89PT0xP246byksaSp1fWZ1bmN0aW9uIEwoZSx0PTIsbj0wKXtsZXQgcj1cIiBcIi5yZXBlYXQobiksbz1cIiBcIi5yZXBlYXQobit0KTtyZXR1cm4gQShlKT9cIltcIitlLm1hcCh1PT5MKHUsdCxuK3QpKS5qb2luKFwiLCBcIikrXCJdXCI6SShlKT9lLnRvSVNPU3RyaW5nKCk6bShlKT9lLnRvU3RyaW5nKCk6cyhlKT9ge1xuYCtPYmplY3QuZW50cmllcyhlKS5tYXAoKFt1LGldKT0+YCR7b30ke3V9OiAke0woaSx0LG4rdCl9YCkuam9pbihgLFxuYCkrYFxuJHtyfX1gOkpTT04uc3RyaW5naWZ5KGUpfWZ1bmN0aW9uIHVlKGUpe3JldHVybiBjKGUpP2UucmVwbGFjZSgvWy1fXShcXHcpL2csKHQsbik9Pm4/bi50b1VwcGVyQ2FzZSgpOlwiXCIpOmV9ZnVuY3Rpb24gaWUoZSl7cmV0dXJuIGMoZSwhMSk/ZVswXS50b1VwcGVyQ2FzZSgpK2Uuc2xpY2UoMSk6ZX1mdW5jdGlvbiBmZShlKXtyZXR1cm4gYyhlKT9lLnJlcGxhY2UoLyhfKS9nLFwiLVwiKS5yZXBsYWNlKC8oW2Etel0pKFtBLVpdKS9nLFwiJDEtJDJcIikudG9Mb3dlckNhc2UoKTplfWZ1bmN0aW9uIHNlKGUpe2lmKGU9PT1cImF1dG9cIilyZXR1cm4gMDtpZih0eXBlb2YgZT09XCJudW1iZXJcIilyZXR1cm4gZTtsZXQgdD1OdW1iZXIoZS5yZXBsYWNlKFwiLFwiLFwiLlwiKS5yZXBsYWNlKC9bXlxcZC5dL2csXCJcIikpO3JldHVybiBOdW1iZXIuaXNOYU4odCl8fC9tc1xccyokLy50ZXN0KGUpP3Q6dCoxZTN9ZnVuY3Rpb24gYWUoZSl7cmV0dXJuIGMoZSk/ZS5yZXBsYWNlKC9bQS1aXS9nLCh0LG4pPT5uPT09MD90OlwiLlwiK3QudG9Mb3dlckNhc2UoKSkudG9Mb3dlckNhc2UoKTplfWZ1bmN0aW9uIGxlKGUpe2lmKGUmJnR5cGVvZiBlPT1cIm9iamVjdFwiKXtpZihcImN1cnJlbnRcImluIGUpcmV0dXJuIGUuY3VycmVudDtpZihcInZhbHVlXCJpbiBlKXJldHVybiBlLnZhbHVlfXJldHVybiB4KGUpfWV4cG9ydHtUIGFzIGNvbXBhcmUsXyBhcyBjb250YWlucyxSIGFzIGRlZXBFcXVhbHMsRiBhcyBkZWVwTWVyZ2UsYiBhcyBlcXVhbHMsUCBhcyBmaWx0ZXIsRCBhcyBmaW5kSW5kZXhJbkxpc3QsVyBhcyBmaW5kTGFzdCx6IGFzIGZpbmRMYXN0SW5kZXgsSyBhcyBnZXRLZXlWYWx1ZSxWIGFzIGluc2VydEludG9PcmRlcmVkQXJyYXksQSBhcyBpc0FycmF5LEkgYXMgaXNEYXRlLHAgYXMgaXNFbXB0eSxtIGFzIGlzRnVuY3Rpb24sVSBhcyBpc0xldHRlcixsIGFzIGlzTm90RW1wdHksWiBhcyBpc051bWJlcixzIGFzIGlzT2JqZWN0LEogYXMgaXNQcmludGFibGVDaGFyYWN0ZXIsWSBhcyBpc1NjYWxhcixjIGFzIGlzU3RyaW5nLEcgYXMgbG9jYWxlQ29tcGFyYXRvcixIIGFzIG1hdGNoUmVnZXgsUSBhcyBtZXJnZUtleXMsQiBhcyBtaW5pZnlDU1MsTiBhcyBuZXN0ZWRLZXlzLHYgYXMgb21pdCxlZSBhcyByZW1vdmVBY2NlbnRzLHRlIGFzIHJlb3JkZXJBcnJheSx4IGFzIHJlc29sdmUsZCBhcyByZXNvbHZlRmllbGREYXRhLG5lIGFzIHNoYWxsb3dFcXVhbFByb3BzLHJlIGFzIHNoYWxsb3dFcXVhbHMsb2UgYXMgc29ydCxMIGFzIHN0cmluZ2lmeSx1ZSBhcyB0b0NhbWVsQ2FzZSxpZSBhcyB0b0NhcGl0YWxDYXNlLEMgYXMgdG9GbGF0Q2FzZSxmZSBhcyB0b0tlYmFiQ2FzZSxzZSBhcyB0b01zLGFlIGFzIHRvVG9rZW5LZXksbGUgYXMgdG9WYWx1ZX07XG4iLCJmdW5jdGlvbiBJKHQsZSl7cmV0dXJuIHQ/dC5jbGFzc0xpc3Q/dC5jbGFzc0xpc3QuY29udGFpbnMoZSk6bmV3IFJlZ0V4cChcIihefCApXCIrZStcIiggfCQpXCIsXCJnaVwiKS50ZXN0KHQuY2xhc3NOYW1lKTohMX1mdW5jdGlvbiBSKHQsZSl7aWYodCYmZSl7bGV0IG89bj0+e0kodCxuKXx8KHQuY2xhc3NMaXN0P3QuY2xhc3NMaXN0LmFkZChuKTp0LmNsYXNzTmFtZSs9XCIgXCIrbil9O1tlXS5mbGF0KCkuZmlsdGVyKEJvb2xlYW4pLmZvckVhY2gobj0+bi5zcGxpdChcIiBcIikuZm9yRWFjaChvKSl9fWZ1bmN0aW9uIFUoKXtyZXR1cm4gd2luZG93LmlubmVyV2lkdGgtZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50Lm9mZnNldFdpZHRofWZ1bmN0aW9uIG10KHQpe3R5cGVvZiB0PT1cInN0cmluZ1wiP1IoZG9jdW1lbnQuYm9keSx0fHxcInAtb3ZlcmZsb3ctaGlkZGVuXCIpOih0IT1udWxsJiZ0LnZhcmlhYmxlTmFtZSYmZG9jdW1lbnQuYm9keS5zdHlsZS5zZXRQcm9wZXJ0eSh0LnZhcmlhYmxlTmFtZSxVKCkrXCJweFwiKSxSKGRvY3VtZW50LmJvZHksKHQ9PW51bGw/dm9pZCAwOnQuY2xhc3NOYW1lKXx8XCJwLW92ZXJmbG93LWhpZGRlblwiKSl9ZnVuY3Rpb24gRCh0KXtpZih0KXtsZXQgZT1kb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiYVwiKTtpZihlLmRvd25sb2FkIT09dm9pZCAwKXtsZXR7bmFtZTpvLHNyYzpufT10O3JldHVybiBlLnNldEF0dHJpYnV0ZShcImhyZWZcIixuKSxlLnNldEF0dHJpYnV0ZShcImRvd25sb2FkXCIsbyksZS5zdHlsZS5kaXNwbGF5PVwibm9uZVwiLGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZSksZS5jbGljaygpLGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoZSksITB9fXJldHVybiExfWZ1bmN0aW9uIGd0KHQsZSl7bGV0IG89bmV3IEJsb2IoW3RdLHt0eXBlOlwiYXBwbGljYXRpb24vY3N2O2NoYXJzZXQ9dXRmLTg7XCJ9KSxuPXdpbmRvdy5uYXZpZ2F0b3I7aWYobi5tc1NhdmVPck9wZW5CbG9iKW4ubXNTYXZlT3JPcGVuQmxvYihvLGUrXCIuY3N2XCIpO2Vsc2V7bGV0IHI9VVJMLmNyZWF0ZU9iamVjdFVSTChvKSxpPUQoe25hbWU6ZStcIi5jc3ZcIixzcmM6cn0pO3NldFRpbWVvdXQoKCk9PlVSTC5yZXZva2VPYmplY3RVUkwociksNGU0KSxpfHwodD1cImRhdGE6dGV4dC9jc3Y7Y2hhcnNldD11dGYtOCxcIit0LHdpbmRvdy5vcGVuKGVuY29kZVVSSSh0KSkpfX1mdW5jdGlvbiBXKHQsZSl7aWYodCYmZSl7bGV0IG89bj0+e3QuY2xhc3NMaXN0P3QuY2xhc3NMaXN0LnJlbW92ZShuKTp0LmNsYXNzTmFtZT10LmNsYXNzTmFtZS5yZXBsYWNlKG5ldyBSZWdFeHAoXCIoXnxcXFxcYilcIituLnNwbGl0KFwiIFwiKS5qb2luKFwifFwiKStcIihcXFxcYnwkKVwiLFwiZ2lcIiksXCIgXCIpfTtbZV0uZmxhdCgpLmZpbHRlcihCb29sZWFuKS5mb3JFYWNoKG49Pm4uc3BsaXQoXCIgXCIpLmZvckVhY2gobykpfX1mdW5jdGlvbiBodCh0KXt0eXBlb2YgdD09XCJzdHJpbmdcIj9XKGRvY3VtZW50LmJvZHksdHx8XCJwLW92ZXJmbG93LWhpZGRlblwiKToodCE9bnVsbCYmdC52YXJpYWJsZU5hbWUmJmRvY3VtZW50LmJvZHkuc3R5bGUucmVtb3ZlUHJvcGVydHkodC52YXJpYWJsZU5hbWUpLFcoZG9jdW1lbnQuYm9keSwodD09bnVsbD92b2lkIDA6dC5jbGFzc05hbWUpfHxcInAtb3ZlcmZsb3ctaGlkZGVuXCIpKX1mdW5jdGlvbiBFKHQpe2lmKHR5cGVvZiBkb2N1bWVudD09XCJ1bmRlZmluZWRcIilyZXR1cm4gbnVsbDtmb3IobGV0IGUgb2YgQXJyYXkuZnJvbShkb2N1bWVudC5zdHlsZVNoZWV0c3x8W10pKXRyeXtmb3IobGV0IG8gb2YgQXJyYXkuZnJvbShlLmNzc1J1bGVzfHxbXSkpe2xldCBuPW8uc3R5bGU7aWYobil7Zm9yKGxldCByIG9mIEFycmF5LmZyb20obikpaWYodC5sYXN0SW5kZXg9MCx0LnRlc3QocikpcmV0dXJue25hbWU6cix2YWx1ZTpuLmdldFByb3BlcnR5VmFsdWUocikudHJpbSgpfX19fWNhdGNoKG8pe2NvbnRpbnVlfXJldHVybiBudWxsfWZ1bmN0aW9uIFQodCl7bGV0IGU9e3dpZHRoOjAsaGVpZ2h0OjB9O2lmKHQpe2xldFtvLG5dPVt0LnN0eWxlLnZpc2liaWxpdHksdC5zdHlsZS5kaXNwbGF5XSxyPXQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7dC5zdHlsZS52aXNpYmlsaXR5PVwiaGlkZGVuXCIsdC5zdHlsZS5kaXNwbGF5PVwiYmxvY2tcIixlLndpZHRoPXIud2lkdGh8fHQub2Zmc2V0V2lkdGgsZS5oZWlnaHQ9ci5oZWlnaHR8fHQub2Zmc2V0SGVpZ2h0LHQuc3R5bGUuZGlzcGxheT1uLHQuc3R5bGUudmlzaWJpbGl0eT1vfXJldHVybiBlfWZ1bmN0aW9uIGgoKXtsZXQgdD13aW5kb3csZT1kb2N1bWVudCxvPWUuZG9jdW1lbnRFbGVtZW50LG49ZS5nZXRFbGVtZW50c0J5VGFnTmFtZShcImJvZHlcIilbMF0scj10LmlubmVyV2lkdGh8fG8uY2xpZW50V2lkdGh8fG4uY2xpZW50V2lkdGgsaT10LmlubmVySGVpZ2h0fHxvLmNsaWVudEhlaWdodHx8bi5jbGllbnRIZWlnaHQ7cmV0dXJue3dpZHRoOnIsaGVpZ2h0Oml9fWZ1bmN0aW9uIFModCl7cmV0dXJuIHQ/TWF0aC5hYnModC5zY3JvbGxMZWZ0KTowfWZ1bmN0aW9uIFYoKXtsZXQgdD1kb2N1bWVudC5kb2N1bWVudEVsZW1lbnQ7cmV0dXJuKHdpbmRvdy5wYWdlWE9mZnNldHx8Uyh0KSktKHQuY2xpZW50TGVmdHx8MCl9ZnVuY3Rpb24gaigpe2xldCB0PWRvY3VtZW50LmRvY3VtZW50RWxlbWVudDtyZXR1cm4od2luZG93LnBhZ2VZT2Zmc2V0fHx0LnNjcm9sbFRvcCktKHQuY2xpZW50VG9wfHwwKX1mdW5jdGlvbiBxKHQpe3JldHVybiB0P2dldENvbXB1dGVkU3R5bGUodCkuZGlyZWN0aW9uPT09XCJydGxcIjohMX1mdW5jdGlvbiB6KHQsZSxvPSEwKXt2YXIgbixyLGkscztpZih0KXtsZXQgbD10Lm9mZnNldFBhcmVudD97d2lkdGg6dC5vZmZzZXRXaWR0aCxoZWlnaHQ6dC5vZmZzZXRIZWlnaHR9OlQodCksYT1sLmhlaWdodCxmPWwud2lkdGgsdT1lLm9mZnNldEhlaWdodCxjPWUub2Zmc2V0V2lkdGgsZD1lLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLGc9aigpLHc9VigpLGN0PWgoKSxNLEIsZHQ9XCJ0b3BcIjtkLnRvcCt1K2E+Y3QuaGVpZ2h0PyhNPWQudG9wK2ctYSxkdD1cImJvdHRvbVwiLE08MCYmKE09ZykpOk09dStkLnRvcCtnLGQubGVmdCtmPmN0LndpZHRoP0I9TWF0aC5tYXgoMCxkLmxlZnQrdytjLWYpOkI9ZC5sZWZ0K3cscSh0KT90LnN0eWxlLmluc2V0SW5saW5lRW5kPUIrXCJweFwiOnQuc3R5bGUuaW5zZXRJbmxpbmVTdGFydD1CK1wicHhcIix0LnN0eWxlLnRvcD1NK1wicHhcIix0LnN0eWxlLnRyYW5zZm9ybU9yaWdpbj1kdCxvJiYodC5zdHlsZS5tYXJnaW5Ub3A9ZHQ9PT1cImJvdHRvbVwiP2BjYWxjKCR7KHI9KG49RSgvLWFuY2hvci1ndXR0ZXIkLykpPT1udWxsP3ZvaWQgMDpuLnZhbHVlKSE9bnVsbD9yOlwiMnB4XCJ9ICogLTEpYDoocz0oaT1FKC8tYW5jaG9yLWd1dHRlciQvKSk9PW51bGw/dm9pZCAwOmkudmFsdWUpIT1udWxsP3M6XCJcIil9fXZhciBwZT0vZXhwcmVzc2lvblxccypcXCh8dXJsXFxzKlxcKFxccypbJ1wiXT9cXHMqKD86amF2YXNjcmlwdHx2YnNjcmlwdCk6fEBpbXBvcnRcXHMrWydcIl0/XFxzKig/OmphdmFzY3JpcHR8dmJzY3JpcHR8ZGF0YSk6L2ksYnQ9L3VybFxccypcXChcXHMqWydcIl0/XFxzKihkYXRhOlteJ1wiKV0qKS9naSxjZT1uZXcgU2V0KFtcImhyZWZcIixcInNyY1wiLFwieGxpbms6aHJlZlwiLFwiYWN0aW9uXCIsXCJmb3JtYWN0aW9uXCJdKSxtZT1uZXcgU2V0KFtcImh0dHBcIixcImh0dHBzXCIsXCJtYWlsdG9cIixcInRlbFwiLFwic21zXCIsXCJmdHBcIixcImZ0cHNcIixcImJsb2JcIl0pLHl0PS9eZGF0YTppbWFnZVxcLyg/OnBuZ3xnaWZ8anBlZ3xqcGd8d2VicHxibXB8YXZpZik7YmFzZTY0LFthLXowLTkrLz1cXHNdKyQvaTtmdW5jdGlvbiBfKHQpe2lmKHR5cGVvZiB0IT1cInN0cmluZ1wiKXJldHVybiExO2lmKHBlLnRlc3QodCkpcmV0dXJuITA7YnQubGFzdEluZGV4PTA7bGV0IGU7Zm9yKDtlPWJ0LmV4ZWModCk7KWlmKCF5dC50ZXN0KGVbMV0udHJpbSgpKSlyZXR1cm4hMDtyZXR1cm4hMX1mdW5jdGlvbiBnZSh0KXtsZXQgZT1cIlwiO2ZvcihsZXQgbyBvZiB0KXtsZXQgbj1vLmNoYXJDb2RlQXQoMCk7bjw9MzF8fG49PT0xMjd8fC9cXHMvLnRlc3Qobyl8fChlKz1vKX1yZXR1cm4gZX1mdW5jdGlvbiBoZSh0LGUpe3ZhciBpLHM7bGV0IG89Z2UodCksbj1lLnRvTG93ZXJDYXNlKCk7aWYoby5zdGFydHNXaXRoKFwiI1wiKXx8by5zdGFydHNXaXRoKFwiL1wiKXx8by5zdGFydHNXaXRoKFwiLi9cIil8fG8uc3RhcnRzV2l0aChcIi4uL1wiKXx8by5zdGFydHNXaXRoKFwiP1wiKSlyZXR1cm4hMDtsZXQgcj0ocz0oaT1vLm1hdGNoKC9eKFthLXpdW2EtejAtOSsuLV0qKTovaSkpPT1udWxsP3ZvaWQgMDppWzFdKT09bnVsbD92b2lkIDA6cy50b0xvd2VyQ2FzZSgpO3JldHVybiByP3I9PT1cImRhdGFcIj8obj09PVwic3JjXCJ8fG49PT1cInhsaW5rOmhyZWZcIikmJnl0LnRlc3QodC50cmltKCkpOm1lLmhhcyhyKTohMH1mdW5jdGlvbiBQKHQsZSl7cmV0dXJuIHR5cGVvZiBlPT1cInN0cmluZ1wiJiZjZS5oYXModC50b0xvd2VyQ2FzZSgpKSYmIWhlKGUsdCl9ZnVuY3Rpb24gTyh0LGUpe3JldHVybiB0LnRvTG93ZXJDYXNlKCk9PT1cInNyY2RvY1wiJiZ0eXBlb2YgZT09XCJzdHJpbmdcIiYmLzxcXHMqc2NyaXB0XFxifG9uXFx3K1xccyo9fGphdmFzY3JpcHQ6fGRhdGE6dGV4dFxcL2h0bWwvaS50ZXN0KGUpfXZhciBiZT17aGFzVW5zYWZlQ3NzVmFsdWU6Xyxpc1Vuc2FmZVVybEF0dHJpYnV0ZTpQLGlzVW5zYWZlSHRtbEF0dHJpYnV0ZTpPfTtmdW5jdGlvbiB5ZSh0KXtyZXR1cm4gdC5zdGFydHNXaXRoKFwiLS1cIik/dDp0LnJlcGxhY2UoLyhbYS16XSkoW0EtWl0pL2csXCIkMS0kMlwiKS50b0xvd2VyQ2FzZSgpfWZ1bmN0aW9uIFgodCxlLG89e30pe28uY2xlYXImJih0LnN0eWxlLmNzc1RleHQ9XCJcIiksZS5mb3JFYWNoKG49PntsZXQgcj1uLmluZGV4T2YoXCI6XCIpO2lmKHI8MClyZXR1cm47bGV0IGk9bi5zbGljZSgwLHIpLnRyaW0oKSxzPW4uc2xpY2UocisxKS50cmltKCk7aWYoIWl8fF8ocykpcmV0dXJuO2xldCBsPVwiXCI7LyFcXHMqaW1wb3J0YW50JC9pLnRlc3QocykmJihzPXMucmVwbGFjZSgvIVxccyppbXBvcnRhbnQkL2ksXCJcIikudHJpbSgpLGw9XCJpbXBvcnRhbnRcIiksdC5zdHlsZS5zZXRQcm9wZXJ0eShpLHMsbCl9KX1mdW5jdGlvbiB4ZSh0LGUpe2xldCBvPTA7Zm9yKDtlLTEtbz49MCYmdFtlLTEtb109PT1cIlxcXFxcIjspbysrO3JldHVybiBvJTI9PT0xfWZ1bmN0aW9uIHdlKHQpe2xldCBlPVtdLG89MCxuPVwiXCIscj0wO2ZvcihsZXQgaT0wO2k8dC5sZW5ndGg7aSsrKXtsZXQgcz10W2ldO24/cz09PW4mJiF4ZSh0LGkpJiYobj1cIlwiKTpzPT09XCInXCJ8fHM9PT0nXCInP249czpzPT09XCIoXCI/cisrOnM9PT1cIilcIj9yPU1hdGgubWF4KDAsci0xKTpzPT09XCI7XCImJnI9PT0wJiYoZS5wdXNoKHQuc2xpY2UobyxpKSksbz1pKzEpfXJldHVybiBlLnB1c2godC5zbGljZShvKSksZX1mdW5jdGlvbiB2KHQsZSxvPXt9KXtpZih0eXBlb2YgZT09XCJzdHJpbmdcIil7bGV0IG49d2UoZSk7WCh0LG4sbyk7cmV0dXJufW8uY2xlYXImJih0LnN0eWxlLmNzc1RleHQ9XCJcIiksT2JqZWN0LmVudHJpZXMoZSkuZm9yRWFjaCgoW24scl0pPT57aWYocj09bnVsbHx8XyhyKSlyZXR1cm47bGV0IGk9U3RyaW5nKHIpLHM9XCJcIjsvIVxccyppbXBvcnRhbnQkL2kudGVzdChpKSYmKGk9aS5yZXBsYWNlKC8hXFxzKmltcG9ydGFudCQvaSxcIlwiKS50cmltKCkscz1cImltcG9ydGFudFwiKSx0LnN0eWxlLnNldFByb3BlcnR5KHllKG4pLGkscyl9KX12YXIgRWU9e2FwcGx5SW5saW5lU3R5bGVTYWZlbHk6dixhcHBseVN0eWxlRGVjbGFyYXRpb25zU2FmZWx5Olh9O2Z1bmN0aW9uIEwodCxlKXt0JiYodHlwZW9mIGU9PVwic3RyaW5nXCI/dih0LGUse2NsZWFyOiEwfSk6dih0LGV8fHt9KSl9ZnVuY3Rpb24gQyh0LGUpe2lmKHQgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCl7bGV0IG89dC5vZmZzZXRXaWR0aDtpZihlKXtsZXQgbj1nZXRDb21wdXRlZFN0eWxlKHQpO28rPXBhcnNlRmxvYXQobi5tYXJnaW5MZWZ0KStwYXJzZUZsb2F0KG4ubWFyZ2luUmlnaHQpfXJldHVybiBvfXJldHVybiAwfWZ1bmN0aW9uIFkodCxlLG89ITAsbj12b2lkIDApe3ZhciByO2lmKHQpe2xldCBpPXQub2Zmc2V0UGFyZW50P3t3aWR0aDp0Lm9mZnNldFdpZHRoLGhlaWdodDp0Lm9mZnNldEhlaWdodH06VCh0KSxzPWUub2Zmc2V0SGVpZ2h0LGw9ZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSxhPWgoKSxmLHUsYz1uIT1udWxsP246XCJ0b3BcIjtpZighbiYmbC50b3ArcytpLmhlaWdodD5hLmhlaWdodD8oZj0tMSppLmhlaWdodCxjPVwiYm90dG9tXCIsbC50b3ArZjwwJiYoZj0tMSpsLnRvcCkpOmY9cyxpLndpZHRoPmEud2lkdGg/dT1sLmxlZnQqLTE6bC5sZWZ0K2kud2lkdGg+YS53aWR0aD91PShsLmxlZnQraS53aWR0aC1hLndpZHRoKSotMTp1PTAsdC5zdHlsZS50b3A9ZitcInB4XCIsdC5zdHlsZS5pbnNldElubGluZVN0YXJ0PXUrXCJweFwiLHQuc3R5bGUudHJhbnNmb3JtT3JpZ2luPWMsbyl7bGV0IGQ9KHI9RSgvLWFuY2hvci1ndXR0ZXIkLykpPT1udWxsP3ZvaWQgMDpyLnZhbHVlO3Quc3R5bGUubWFyZ2luVG9wPWM9PT1cImJvdHRvbVwiP2BjYWxjKCR7ZCE9bnVsbD9kOlwiMnB4XCJ9ICogLTEpYDpkIT1udWxsP2Q6XCJcIn19fWZ1bmN0aW9uIHh0KHQsZSxvLG49ITApe3QmJmUmJihvPT09XCJzZWxmXCI/WSh0LGUpOihuJiYodC5zdHlsZS5taW5XaWR0aD1DKGUpK1wicHhcIikseih0LGUpKSl9ZnVuY3Rpb24gYih0KXtpZih0KXtsZXQgZT10LnBhcmVudE5vZGU7cmV0dXJuIGUmJmUgaW5zdGFuY2VvZiBTaGFkb3dSb290JiZlLmhvc3QmJihlPWUuaG9zdCksZX1yZXR1cm4gbnVsbH1mdW5jdGlvbiBIKHQpe3JldHVybiEhKHQhPT1udWxsJiZ0eXBlb2YgdCE9XCJ1bmRlZmluZWRcIiYmdC5ub2RlTmFtZSYmYih0KSl9aW1wb3J0e3Jlc29sdmUgYXMgU2V9ZnJvbVwiQHByaW1ldWl4L3V0aWxzL29iamVjdFwiO2Z1bmN0aW9uIHAodCl7cmV0dXJuIHR5cGVvZiBFbGVtZW50IT1cInVuZGVmaW5lZFwiP3QgaW5zdGFuY2VvZiBFbGVtZW50OnQhPT1udWxsJiZ0eXBlb2YgdD09XCJvYmplY3RcIiYmdC5ub2RlVHlwZT09PTEmJnR5cGVvZiB0Lm5vZGVOYW1lPT1cInN0cmluZ1wifWZ1bmN0aW9uIHkodCl7dmFyIG87aWYocCh0KSlyZXR1cm4gdDtpZighdHx8dHlwZW9mIHQhPVwib2JqZWN0XCIpcmV0dXJuO2xldCBlPXQ7aWYoXCJjdXJyZW50XCJpbiB0KWU9dC5jdXJyZW50LGU9KG89eShlPT1udWxsP3ZvaWQgMDplLmVsZW1lbnRSZWYpKSE9bnVsbD9vOmU7ZWxzZSBpZihcInZhbHVlXCJpbiB0KWU9dC52YWx1ZTtlbHNlIGlmKFwibmF0aXZlRWxlbWVudFwiaW4gdCllPXQubmF0aXZlRWxlbWVudDtlbHNlIGlmKFwiZWxcImluIHQpe2xldCBuPXQuZWw7biYmdHlwZW9mIG49PVwib2JqZWN0XCImJlwibmF0aXZlRWxlbWVudFwiaW4gbj9lPW4ubmF0aXZlRWxlbWVudDplPW59ZWxzZSBpZihcImVsZW1lbnRSZWZcImluIHQpcmV0dXJuIHkodC5lbGVtZW50UmVmKTtyZXR1cm4gZT1TZShlKSxwKGUpP2U6dm9pZCAwfWZ1bmN0aW9uIFoodCxlKXt2YXIgbyxuLHI7aWYodClzd2l0Y2godCl7Y2FzZVwiZG9jdW1lbnRcIjpyZXR1cm4gZG9jdW1lbnQ7Y2FzZVwid2luZG93XCI6cmV0dXJuIHdpbmRvdztjYXNlXCJib2R5XCI6cmV0dXJuIGRvY3VtZW50LmJvZHk7Y2FzZVwiQG5leHRcIjpyZXR1cm4gZT09bnVsbD92b2lkIDA6ZS5uZXh0RWxlbWVudFNpYmxpbmc7Y2FzZVwiQHByZXZcIjpyZXR1cm4gZT09bnVsbD92b2lkIDA6ZS5wcmV2aW91c0VsZW1lbnRTaWJsaW5nO2Nhc2VcIkBmaXJzdFwiOnJldHVybiBlPT1udWxsP3ZvaWQgMDplLmZpcnN0RWxlbWVudENoaWxkO2Nhc2VcIkBsYXN0XCI6cmV0dXJuIGU9PW51bGw/dm9pZCAwOmUubGFzdEVsZW1lbnRDaGlsZDtjYXNlXCJAY2hpbGRcIjpyZXR1cm4obz1lPT1udWxsP3ZvaWQgMDplLmNoaWxkcmVuKT09bnVsbD92b2lkIDA6b1swXTtjYXNlXCJAcGFyZW50XCI6cmV0dXJuIGU9PW51bGw/dm9pZCAwOmUucGFyZW50RWxlbWVudDtjYXNlXCJAZ3JhbmRwYXJlbnRcIjpyZXR1cm4obj1lPT1udWxsP3ZvaWQgMDplLnBhcmVudEVsZW1lbnQpPT1udWxsP3ZvaWQgMDpuLnBhcmVudEVsZW1lbnQ7ZGVmYXVsdDp7aWYodHlwZW9mIHQ9PVwic3RyaW5nXCIpe2xldCBhPXQubWF0Y2goL15AY2hpbGRcXFsoXFxkKyldLyk7cmV0dXJuIGE/KChyPWU9PW51bGw/dm9pZCAwOmUuY2hpbGRyZW4pPT1udWxsP3ZvaWQgMDpyW3BhcnNlSW50KGFbMV0sMTApXSl8fG51bGw6ZG9jdW1lbnQucXVlcnlTZWxlY3Rvcih0KXx8bnVsbH1sZXQgcz0oYT0+dHlwZW9mIGE9PVwiZnVuY3Rpb25cIiYmXCJjYWxsXCJpbiBhJiZcImFwcGx5XCJpbiBhKSh0KT90KCk6dCxsPXkocyk7cmV0dXJuIEgobCk/bDoocz09bnVsbD92b2lkIDA6cy5ub2RlVHlwZSk9PT05P3M6dm9pZCAwfX19ZnVuY3Rpb24gd3QodCxlKXtsZXQgbz1aKHQsZSk7aWYobylvLmFwcGVuZENoaWxkKGUpO2Vsc2UgdGhyb3cgbmV3IEVycm9yKFwiQ2Fubm90IGFwcGVuZCBcIitlK1wiIHRvIFwiK3QpfWZ1bmN0aW9uIEEodCxlLG8pe2lmKHR5cGVvZiBvIT1cImZ1bmN0aW9uXCImJiEodHlwZW9mIG89PVwib2JqZWN0XCImJm8hPT1udWxsJiZcImhhbmRsZUV2ZW50XCJpbiBvKSlyZXR1cm47bGV0IG49dCxyPW4uX3BMaXN0ZW5lcnN8fChuLl9wTGlzdGVuZXJzPVtdKSxpPSExO2ZvcihsZXQgcz1yLmxlbmd0aC0xO3M+PTA7cy0tKXJbc11bMF09PT1lJiYocltzXVsxXT09PW8/aT0hMDoodC5yZW1vdmVFdmVudExpc3RlbmVyKGUscltzXVsxXSksci5zcGxpY2UocywxKSkpO2l8fCh0LmFkZEV2ZW50TGlzdGVuZXIoZSxvKSxyLnB1c2goW2Usb10pKX12YXIgdXQ7ZnVuY3Rpb24gRXQodCl7aWYodCl7bGV0IGU9Z2V0Q29tcHV0ZWRTdHlsZSh0KTtyZXR1cm4gdC5vZmZzZXRIZWlnaHQtdC5jbGllbnRIZWlnaHQtcGFyc2VGbG9hdChlLmJvcmRlclRvcFdpZHRoKS1wYXJzZUZsb2F0KGUuYm9yZGVyQm90dG9tV2lkdGgpfWVsc2V7aWYodXQhPW51bGwpcmV0dXJuIHV0O2xldCBlPWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7TChlLHt3aWR0aDpcIjEwMHB4XCIsaGVpZ2h0OlwiMTAwcHhcIixvdmVyZmxvdzpcInNjcm9sbFwiLHBvc2l0aW9uOlwiYWJzb2x1dGVcIix0b3A6XCItOTk5OXB4XCJ9KSxkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGUpO2xldCBvPWUub2Zmc2V0SGVpZ2h0LWUuY2xpZW50SGVpZ2h0O3JldHVybiBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGUpLHV0PW8sb319dmFyIHB0O2Z1bmN0aW9uIEYodCl7aWYodCl7bGV0IGU9Z2V0Q29tcHV0ZWRTdHlsZSh0KTtyZXR1cm4gdC5vZmZzZXRXaWR0aC10LmNsaWVudFdpZHRoLXBhcnNlRmxvYXQoZS5ib3JkZXJMZWZ0V2lkdGgpLXBhcnNlRmxvYXQoZS5ib3JkZXJSaWdodFdpZHRoKX1lbHNle2lmKHB0IT1udWxsKXJldHVybiBwdDtsZXQgZT1kb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO0woZSx7d2lkdGg6XCIxMDBweFwiLGhlaWdodDpcIjEwMHB4XCIsb3ZlcmZsb3c6XCJzY3JvbGxcIixwb3NpdGlvbjpcImFic29sdXRlXCIsdG9wOlwiLTk5OTlweFwifSksZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChlKTtsZXQgbz1lLm9mZnNldFdpZHRoLWUuY2xpZW50V2lkdGg7cmV0dXJuIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoZSkscHQ9byxvfX1mdW5jdGlvbiBTdCgpe2lmKHdpbmRvdy5nZXRTZWxlY3Rpb24pe2xldCB0PXdpbmRvdy5nZXRTZWxlY3Rpb24oKXx8e307dC5lbXB0eT90LmVtcHR5KCk6dC5yZW1vdmVBbGxSYW5nZXMmJnQucmFuZ2VDb3VudCYmdC5yYW5nZUNvdW50PjAmJnQuZ2V0UmFuZ2VBdCYmdC5nZXRSYW5nZUF0KDApLmdldENsaWVudFJlY3RzKCkubGVuZ3RoPjAmJnQucmVtb3ZlQWxsUmFuZ2VzKCl9fWZ1bmN0aW9uIE4odCxlPXt9KXtpZihwKHQpKXtsZXQgbz10PT1udWxsP3ZvaWQgMDp0LiRhdHRycyxuPShzLGwpPT57bGV0IGE9byE9bnVsbCYmb1tzXT9bb1tzXV06W107cmV0dXJuW2xdLmZsYXQoKS5yZWR1Y2UoKGYsdSk9PntpZih1IT1udWxsKXtsZXQgYz10eXBlb2YgdTtpZihjPT09XCJzdHJpbmdcInx8Yz09PVwibnVtYmVyXCIpZi5wdXNoKHUpO2Vsc2UgaWYoYz09PVwib2JqZWN0XCIpe2xldCBkPUFycmF5LmlzQXJyYXkodSk/bihzLHUpOk9iamVjdC5lbnRyaWVzKHUpLm1hcCgoW2csd10pPT5zPT09XCJzdHlsZVwiJiYod3x8dz09PTApP2Ake2cucmVwbGFjZSgvKFthLXpdKShbQS1aXSkvZyxcIiQxLSQyXCIpLnRvTG93ZXJDYXNlKCl9OiR7d31gOnc/Zzp2b2lkIDApO2Y9ZC5sZW5ndGg/Zi5jb25jYXQoZC5maWx0ZXIoZz0+ISFnKSk6Zn19cmV0dXJuIGZ9LGEpfSxyPXM9PntsZXQgbD1uKFwic3R5bGVcIixzKTtYKHQsbCl9LGk9dDtPYmplY3QuZW50cmllcyhlKS5mb3JFYWNoKChbcyxsXSk9PntpZihsIT1udWxsKXtsZXQgYT1zLm1hdGNoKC9eb24oLispLyk7aWYoYSlBKHQsYVsxXS50b0xvd2VyQ2FzZSgpLGwpO2Vsc2UgaWYocz09PVwicC1iaW5kXCJ8fHM9PT1cInBCaW5kXCIpTih0LGwpO2Vsc2UgaWYocz09PVwic3R5bGVcIilyKGwpLGkuJGF0dHJzPWkuJGF0dHJzfHx7fSxpLiRhdHRyc1tzXT10LnN0eWxlLmNzc1RleHQ7ZWxzZXtpZihQKHMsbCl8fE8ocyxsKSlyZXR1cm47bD1zPT09XCJjbGFzc1wiP1suLi5uZXcgU2V0KG4oXCJjbGFzc1wiLGwpKV0uam9pbihcIiBcIikudHJpbSgpOmwsaS4kYXR0cnM9aS4kYXR0cnN8fHt9LGkuJGF0dHJzW3NdPWwsdC5zZXRBdHRyaWJ1dGUocyxsKX19fSl9fWZ1bmN0aW9uIFEodCxlPXt9LC4uLm8pe2lmKHQpe2xldCBuPWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQodCk7cmV0dXJuIE4obixlKSxuLmFwcGVuZCguLi5vKSxufX1mdW5jdGlvbiBHKHQpe3JldHVybiBTdHJpbmcodCkucmVwbGFjZSgvJi9nLFwiJmFtcDtcIikucmVwbGFjZSgvXCIvZyxcIiZxdW90O1wiKS5yZXBsYWNlKC88L2csXCImbHQ7XCIpLnJlcGxhY2UoLz4vZyxcIiZndDtcIil9ZnVuY3Rpb24gSih0LGU9e30pe3JldHVybiB0P2A8c3R5bGUke09iamVjdC5lbnRyaWVzKGUpLnJlZHVjZSgobyxbbixyXSk9Pm8rYCAke259PVwiJHtHKHIpfVwiYCxcIlwiKX0+JHt0fTwvc3R5bGU+YDpcIlwifWZ1bmN0aW9uIHZ0KHQsZT17fSl7cmV0dXJuIEoodCxlKX1mdW5jdGlvbiBLKHQsZT17fSxvKXtsZXQgbj1RKFwic3R5bGVcIixlLHQpO3JldHVybiBvPT1udWxsfHxvLmFwcGVuZENoaWxkKG4pLG59ZnVuY3Rpb24gVHQodD17fSxlKXtyZXR1cm4gSyhcIlwiLHQsZXx8ZG9jdW1lbnQuaGVhZCl9ZnVuY3Rpb24gTHQodCxlKXtpZighdClyZXR1cm4oKT0+e307dC5zdHlsZS5vcGFjaXR5PVwiMFwiO2xldCBvPStuZXcgRGF0ZSxuPTAscixpLHM9ZnVuY3Rpb24oKXtuKz0obmV3IERhdGUoKS5nZXRUaW1lKCktbykvZSx0LnN0eWxlLm9wYWNpdHk9YCR7bn1gLG89K25ldyBEYXRlLG48MSYmKFwicmVxdWVzdEFuaW1hdGlvbkZyYW1lXCJpbiB3aW5kb3c/cj1yZXF1ZXN0QW5pbWF0aW9uRnJhbWUocyk6aT1zZXRUaW1lb3V0KHMsMTYpKX07cmV0dXJuIHMoKSwoKT0+e3IhPT12b2lkIDAmJmNhbmNlbEFuaW1hdGlvbkZyYW1lKHIpLGkhPT12b2lkIDAmJmNsZWFyVGltZW91dChpKX19ZnVuY3Rpb24gQ3QodCxlKXtpZighdClyZXR1cm4oKT0+e307bGV0IG89MSxuPTUwLHI9bi9lLGk9c2V0SW50ZXJ2YWwoKCk9PntvLT1yLG88PTAmJihvPTAsY2xlYXJJbnRlcnZhbChpKSksdC5zdHlsZS5vcGFjaXR5PW8udG9TdHJpbmcoKX0sbik7cmV0dXJuKCk9PmNsZWFySW50ZXJ2YWwoaSl9ZnVuY3Rpb24gdHQodCxlKXtyZXR1cm4gcCh0KT9BcnJheS5mcm9tKHQucXVlcnlTZWxlY3RvckFsbChlKSk6W119ZnVuY3Rpb24gZXQodCxlKXtyZXR1cm4gcCh0KT90Lm1hdGNoZXMoZSk/dDp0LnF1ZXJ5U2VsZWN0b3IoZSk6bnVsbH1mdW5jdGlvbiBIdCh0LGUpe3QmJmRvY3VtZW50LmFjdGl2ZUVsZW1lbnQhPT10JiZ0LmZvY3VzKGUpfWZ1bmN0aW9uIG90KHQsZSl7aWYocCh0KSl7bGV0IG89dC5nZXRBdHRyaWJ1dGUoZSk7cmV0dXJuIG8hPT1udWxsJiZvLnRyaW0oKSE9PVwiXCImJiFpc05hTihvKT8rbzpvPT09XCJ0cnVlXCJ8fG89PT1cImZhbHNlXCI/bz09PVwidHJ1ZVwiOm99fWZ1bmN0aW9uIG50KCl7bGV0IHQ9bmF2aWdhdG9yLnVzZXJBZ2VudC50b0xvd2VyQ2FzZSgpLGU9LyhjaHJvbWUpWyBdKFtcXHcuXSspLy5leGVjKHQpfHwvKHdlYmtpdClbIF0oW1xcdy5dKykvLmV4ZWModCl8fC8ob3BlcmEpKD86Lip2ZXJzaW9ufClbIF0oW1xcdy5dKykvLmV4ZWModCl8fC8obXNpZSkgKFtcXHcuXSspLy5leGVjKHQpfHx0LmluZGV4T2YoXCJjb21wYXRpYmxlXCIpPDAmJi8obW96aWxsYSkoPzouKj8gcnY6KFtcXHcuXSspfCkvLmV4ZWModCl8fFtdO3JldHVybnticm93c2VyOmVbMV18fFwiXCIsdmVyc2lvbjplWzJdfHxcIjBcIn19dmFyIG09bnVsbDtmdW5jdGlvbiBBdCgpe2lmKCFtKXttPXt9O2xldCB0PW50KCk7dC5icm93c2VyJiYobVt0LmJyb3dzZXJdPSEwLG0udmVyc2lvbj10LnZlcnNpb24pLG0uY2hyb21lP20ud2Via2l0PSEwOm0ud2Via2l0JiYobS5zYWZhcmk9ITApfXJldHVybiBtfWZ1bmN0aW9uIGt0KCl7cmV0dXJuIG5hdmlnYXRvci5sYW5ndWFnZXMmJm5hdmlnYXRvci5sYW5ndWFnZXMubGVuZ3RoJiZuYXZpZ2F0b3IubGFuZ3VhZ2VzWzBdfHxuYXZpZ2F0b3IubGFuZ3VhZ2V8fFwiZW5cIn1mdW5jdGlvbiBNdCh0LGUsbyl7dmFyIG47cmV0dXJuIHQmJmU/bz8obj10PT1udWxsP3ZvaWQgMDp0LnN0eWxlKT09bnVsbD92b2lkIDA6bi5nZXRQcm9wZXJ0eVZhbHVlKGUpOmdldENvbXB1dGVkU3R5bGUodCkuZ2V0UHJvcGVydHlWYWx1ZShlKTpudWxsfWZ1bmN0aW9uIFJ0KHQsZSxvLG4pe2lmKHQpe2xldCByPWdldENvbXB1dGVkU3R5bGUodCksaT1kb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO2kuc3R5bGUucG9zaXRpb249XCJhYnNvbHV0ZVwiLGkuc3R5bGUudG9wPVwiMHB4XCIsaS5zdHlsZS5sZWZ0PVwiMHB4XCIsaS5zdHlsZS52aXNpYmlsaXR5PVwiaGlkZGVuXCIsaS5zdHlsZS5wb2ludGVyRXZlbnRzPVwibm9uZVwiLGkuc3R5bGUub3ZlcmZsb3c9ci5vdmVyZmxvdyxpLnN0eWxlLndpZHRoPXIud2lkdGgsaS5zdHlsZS5oZWlnaHQ9ci5oZWlnaHQsaS5zdHlsZS5wYWRkaW5nPXIucGFkZGluZyxpLnN0eWxlLmJvcmRlcj1yLmJvcmRlcixpLnN0eWxlLm92ZXJmbG93V3JhcD1yLm92ZXJmbG93V3JhcCxpLnN0eWxlLndoaXRlU3BhY2U9ci53aGl0ZVNwYWNlLGkuc3R5bGUubGluZUhlaWdodD1yLmxpbmVIZWlnaHQsZS5zcGxpdCgvXFxyXFxufFxccnxcXG4vKS5mb3JFYWNoKChjLGQpPT57ZD4wJiZpLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJiclwiKSksaS5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShjKSl9KTtsZXQgcz1kb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic3BhblwiKTtzLnRleHRDb250ZW50PW4saS5hcHBlbmRDaGlsZChzKTtsZXQgbD1kb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShvKTtpLmFwcGVuZENoaWxkKGwpLGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoaSk7bGV0e29mZnNldExlZnQ6YSxvZmZzZXRUb3A6ZixjbGllbnRIZWlnaHQ6dX09cztyZXR1cm4gZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChpKSx7bGVmdDpNYXRoLmFicyhhLXQuc2Nyb2xsTGVmdCksdG9wOk1hdGguYWJzKGYtdC5zY3JvbGxUb3ApK3V9fXJldHVybnt0b3A6XCJhdXRvXCIsbGVmdDpcImF1dG9cIn19ZnVuY3Rpb24geCh0LGU9XCJcIil7bGV0IG89dHQodCxgYnV0dG9uOm5vdChbdGFiaW5kZXggPSBcIi0xXCJdKTpub3QoW2Rpc2FibGVkXSk6bm90KFtzdHlsZSo9XCJkaXNwbGF5Om5vbmVcIl0pOm5vdChbaGlkZGVuXSkke2V9LFxuICAgICAgICAgICAgW2hyZWZdOm5vdChbdGFiaW5kZXggPSBcIi0xXCJdKTpub3QoW3N0eWxlKj1cImRpc3BsYXk6bm9uZVwiXSk6bm90KFtoaWRkZW5dKSR7ZX0sXG4gICAgICAgICAgICBpbnB1dDpub3QoW3RhYmluZGV4ID0gXCItMVwiXSk6bm90KFtkaXNhYmxlZF0pOm5vdChbc3R5bGUqPVwiZGlzcGxheTpub25lXCJdKTpub3QoW2hpZGRlbl0pJHtlfSxcbiAgICAgICAgICAgIHNlbGVjdDpub3QoW3RhYmluZGV4ID0gXCItMVwiXSk6bm90KFtkaXNhYmxlZF0pOm5vdChbc3R5bGUqPVwiZGlzcGxheTpub25lXCJdKTpub3QoW2hpZGRlbl0pJHtlfSxcbiAgICAgICAgICAgIHRleHRhcmVhOm5vdChbdGFiaW5kZXggPSBcIi0xXCJdKTpub3QoW2Rpc2FibGVkXSk6bm90KFtzdHlsZSo9XCJkaXNwbGF5Om5vbmVcIl0pOm5vdChbaGlkZGVuXSkke2V9LFxuICAgICAgICAgICAgW3RhYkluZGV4XTpub3QoW3RhYkluZGV4ID0gXCItMVwiXSk6bm90KFtkaXNhYmxlZF0pOm5vdChbc3R5bGUqPVwiZGlzcGxheTpub25lXCJdKTpub3QoW2hpZGRlbl0pJHtlfSxcbiAgICAgICAgICAgIFtjb250ZW50ZWRpdGFibGVdOm5vdChbdGFiSW5kZXggPSBcIi0xXCJdKTpub3QoW2Rpc2FibGVkXSk6bm90KFtzdHlsZSo9XCJkaXNwbGF5Om5vbmVcIl0pOm5vdChbaGlkZGVuXSkke2V9YCksbj1bXTtmb3IobGV0IHIgb2Ygbyl7bGV0IGk9Z2V0Q29tcHV0ZWRTdHlsZShyKTtpLmRpc3BsYXkhPVwibm9uZVwiJiZpLnZpc2liaWxpdHkhPVwiaGlkZGVuXCImJm4ucHVzaChyKX1yZXR1cm4gbn1mdW5jdGlvbiBXdCh0LGUpe2xldCBvPXgodCxlKTtyZXR1cm4gby5sZW5ndGg+MD9vWzBdOm51bGx9ZnVuY3Rpb24gUHQodCl7aWYodCl7bGV0IGU9dC5vZmZzZXRIZWlnaHQsbz1nZXRDb21wdXRlZFN0eWxlKHQpO3JldHVybiBlLT1wYXJzZUZsb2F0KG8ucGFkZGluZ1RvcCkrcGFyc2VGbG9hdChvLnBhZGRpbmdCb3R0b20pK3BhcnNlRmxvYXQoby5ib3JkZXJUb3BXaWR0aCkrcGFyc2VGbG9hdChvLmJvcmRlckJvdHRvbVdpZHRoKSxlfXJldHVybiAwfWZ1bmN0aW9uIHJ0KHQpe2lmKHQpe2xldFtlLG9dPVt0LnN0eWxlLnZpc2liaWxpdHksdC5zdHlsZS5kaXNwbGF5XTt0LnN0eWxlLnZpc2liaWxpdHk9XCJoaWRkZW5cIix0LnN0eWxlLmRpc3BsYXk9XCJibG9ja1wiO2xldCBuPXQub2Zmc2V0SGVpZ2h0O3JldHVybiB0LnN0eWxlLmRpc3BsYXk9byx0LnN0eWxlLnZpc2liaWxpdHk9ZSxufXJldHVybiAwfWZ1bmN0aW9uIGl0KHQpe2lmKHQpe2xldFtlLG9dPVt0LnN0eWxlLnZpc2liaWxpdHksdC5zdHlsZS5kaXNwbGF5XTt0LnN0eWxlLnZpc2liaWxpdHk9XCJoaWRkZW5cIix0LnN0eWxlLmRpc3BsYXk9XCJibG9ja1wiO2xldCBuPXQub2Zmc2V0V2lkdGg7cmV0dXJuIHQuc3R5bGUuZGlzcGxheT1vLHQuc3R5bGUudmlzaWJpbGl0eT1lLG59cmV0dXJuIDB9ZnVuY3Rpb24gT3QodCl7dmFyIGU7aWYodCl7bGV0IG89KGU9Yih0KSk9PW51bGw/dm9pZCAwOmUuY2hpbGROb2RlcyxuPTA7aWYobylmb3IobGV0IHI9MDtyPG8ubGVuZ3RoO3IrKyl7aWYob1tyXT09PXQpcmV0dXJuIG47b1tyXS5ub2RlVHlwZT09PTEmJm4rK319cmV0dXJuLTF9ZnVuY3Rpb24gRnQodCl7aWYodCl7bGV0IGU9dC5vZmZzZXRXaWR0aCxvPWdldENvbXB1dGVkU3R5bGUodCk7cmV0dXJuIGUtPXBhcnNlRmxvYXQoby5ib3JkZXJMZWZ0KStwYXJzZUZsb2F0KG8uYm9yZGVyUmlnaHQpLGV9cmV0dXJuIDB9ZnVuY3Rpb24gTnQodCxlKXtsZXQgbz14KHQsZSk7cmV0dXJuIG8ubGVuZ3RoPjA/b1tvLmxlbmd0aC0xXTpudWxsfWZ1bmN0aW9uICR0KHQsZSl7bGV0IG89dC5uZXh0RWxlbWVudFNpYmxpbmc7Zm9yKDtvOyl7aWYoby5tYXRjaGVzKGUpKXJldHVybiBvO289by5uZXh0RWxlbWVudFNpYmxpbmd9cmV0dXJuIG51bGx9ZnVuY3Rpb24gQnQodCxlLG8pe2xldCBuPXgodCxvKSxyPW4ubGVuZ3RoPjA/bi5maW5kSW5kZXgocz0+cz09PWUpOi0xLGk9cj4tMSYmbi5sZW5ndGg+cisxP3IrMTotMTtyZXR1cm4gaT4tMT9uW2ldOm51bGx9ZnVuY3Rpb24gc3QodCl7aWYodCl7bGV0IGU9dC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtyZXR1cm57dG9wOmUudG9wKyh3aW5kb3cucGFnZVlPZmZzZXR8fGRvY3VtZW50LmRvY3VtZW50RWxlbWVudC5zY3JvbGxUb3B8fGRvY3VtZW50LmJvZHkuc2Nyb2xsVG9wfHwwKSxsZWZ0OmUubGVmdCsod2luZG93LnBhZ2VYT2Zmc2V0fHxTKGRvY3VtZW50LmRvY3VtZW50RWxlbWVudCl8fFMoZG9jdW1lbnQuYm9keSl8fDApfX1yZXR1cm57dG9wOlwiYXV0b1wiLGxlZnQ6XCJhdXRvXCJ9fWZ1bmN0aW9uIGsodCxlKXtpZih0KXtsZXQgbz10Lm9mZnNldEhlaWdodDtpZihlKXtsZXQgbj1nZXRDb21wdXRlZFN0eWxlKHQpO28rPXBhcnNlRmxvYXQobi5tYXJnaW5Ub3ApK3BhcnNlRmxvYXQobi5tYXJnaW5Cb3R0b20pfXJldHVybiBvfXJldHVybiAwfWZ1bmN0aW9uICQodCxlPVtdKXtsZXQgbz1iKHQpO3JldHVybiBvPT09bnVsbD9lOiQobyxlLmNvbmNhdChbb10pKX1mdW5jdGlvbiBJdCh0LGUpe2xldCBvPXQucHJldmlvdXNFbGVtZW50U2libGluZztmb3IoO287KXtpZihvLm1hdGNoZXMoZSkpcmV0dXJuIG87bz1vLnByZXZpb3VzRWxlbWVudFNpYmxpbmd9cmV0dXJuIG51bGx9ZnVuY3Rpb24gVXQodCl7bGV0IGU9W107aWYodCl7bGV0IG89JCh0KSxuPS8oYXV0b3xzY3JvbGwpLyxyPWk9Pnt0cnl7bGV0IHM9d2luZG93LmdldENvbXB1dGVkU3R5bGUoaSxudWxsKTtyZXR1cm4gbi50ZXN0KHMuZ2V0UHJvcGVydHlWYWx1ZShcIm92ZXJmbG93XCIpKXx8bi50ZXN0KHMuZ2V0UHJvcGVydHlWYWx1ZShcIm92ZXJmbG93WFwiKSl8fG4udGVzdChzLmdldFByb3BlcnR5VmFsdWUoXCJvdmVyZmxvd1lcIikpfWNhdGNoKHMpe3JldHVybiExfX07Zm9yKGxldCBpIG9mIG8pe2xldCBzPWkubm9kZVR5cGU9PT0xJiZpLmRhdGFzZXQuc2Nyb2xsc2VsZWN0b3JzO2lmKHMpe2xldCBsPXMuc3BsaXQoXCIsXCIpO2ZvcihsZXQgYSBvZiBsKXtsZXQgZj1ldChpLGEpO2YmJnIoZikmJmUucHVzaChmKX19aS5ub2RlVHlwZSE9PTkmJnIoaSkmJmUucHVzaChpKX19cmV0dXJuIGV9ZnVuY3Rpb24gRHQoKXtpZih3aW5kb3cuZ2V0U2VsZWN0aW9uKXJldHVybiB3aW5kb3cuZ2V0U2VsZWN0aW9uKCkudG9TdHJpbmcoKTtpZihkb2N1bWVudC5nZXRTZWxlY3Rpb24pcmV0dXJuIGRvY3VtZW50LmdldFNlbGVjdGlvbigpLnRvU3RyaW5nKCl9ZnVuY3Rpb24gVnQoKXtyZXR1cm4gbmF2aWdhdG9yLnVzZXJBZ2VudH1mdW5jdGlvbiBqdCh0KXtpZih0KXtsZXQgZT10Lm9mZnNldFdpZHRoLG89Z2V0Q29tcHV0ZWRTdHlsZSh0KTtyZXR1cm4gZS09cGFyc2VGbG9hdChvLnBhZGRpbmdMZWZ0KStwYXJzZUZsb2F0KG8ucGFkZGluZ1JpZ2h0KStwYXJzZUZsb2F0KG8uYm9yZGVyTGVmdFdpZHRoKStwYXJzZUZsb2F0KG8uYm9yZGVyUmlnaHRXaWR0aCksZX1yZXR1cm4gMH1mdW5jdGlvbiBxdCh0KXtpZih0KXtsZXQgZT1nZXRDb21wdXRlZFN0eWxlKHQpO3JldHVybiBwYXJzZUZsb2F0KGUuZ2V0UHJvcGVydHlWYWx1ZShcImFuaW1hdGlvbi1kdXJhdGlvblwiKXx8XCIwXCIpPjB9cmV0dXJuITF9ZnVuY3Rpb24genQodCl7aWYodCl7bGV0IGU9Z2V0Q29tcHV0ZWRTdHlsZSh0KTtyZXR1cm4gcGFyc2VGbG9hdChlLmdldFByb3BlcnR5VmFsdWUoXCJ0cmFuc2l0aW9uLWR1cmF0aW9uXCIpfHxcIjBcIik+MH1yZXR1cm4hMX1mdW5jdGlvbiBfdCh0LGUsbyl7bGV0IG49dFtlXTt0eXBlb2Ygbj09XCJmdW5jdGlvblwiJiZuLmFwcGx5KHQsbyE9bnVsbD9vOltdKX1mdW5jdGlvbiBYdCgpe3JldHVybi8oYW5kcm9pZCkvaS50ZXN0KG5hdmlnYXRvci51c2VyQWdlbnQpfWZ1bmN0aW9uIGx0KHQsZSxvKXtyZXR1cm4gcCh0KT9vdCh0LGUpPT09bzohMX1mdW5jdGlvbiBZdCh0LGUsbyl7cmV0dXJuIWx0KHQsZSxvKX1mdW5jdGlvbiBadCh0KXtpZih0KXtsZXQgZT10Lm5vZGVOYW1lLG89dC5wYXJlbnRFbGVtZW50JiZ0LnBhcmVudEVsZW1lbnQubm9kZU5hbWU7cmV0dXJuIGU9PT1cIklOUFVUXCJ8fGU9PT1cIlRFWFRBUkVBXCJ8fGU9PT1cIkJVVFRPTlwifHxlPT09XCJBXCJ8fG89PT1cIklOUFVUXCJ8fG89PT1cIlRFWFRBUkVBXCJ8fG89PT1cIkJVVFRPTlwifHxvPT09XCJBXCJ8fCEhdC5jbG9zZXN0KFwiLnAtYnV0dG9uLCAucC1jaGVja2JveCwgLnAtcmFkaW9idXR0b25cIil9cmV0dXJuITF9ZnVuY3Rpb24gYXQoKXtyZXR1cm4hISh0eXBlb2Ygd2luZG93IT1cInVuZGVmaW5lZFwiJiZ3aW5kb3cuZG9jdW1lbnQmJndpbmRvdy5kb2N1bWVudC5jcmVhdGVFbGVtZW50KX1mdW5jdGlvbiBRdCh0LGUpe2lmKHR5cGVvZiBDU1M9PVwidW5kZWZpbmVkXCJ8fCFDU1Muc3VwcG9ydHMpcmV0dXJuITE7aWYoZSE9PXZvaWQgMCl7bGV0IG89dC50b1N0cmluZygpLnJlcGxhY2UoL1tBLVpdL2csbj0+XCItXCIrbi50b0xvd2VyQ2FzZSgpKTtyZXR1cm4gQ1NTLnN1cHBvcnRzKG8sZSl9cmV0dXJuIENTUy5zdXBwb3J0cyh0LnRvU3RyaW5nKCkpfWZ1bmN0aW9uIEd0KHQsZT1cIlwiKXtyZXR1cm4gcCh0KT90Lm1hdGNoZXMoYGJ1dHRvbjpub3QoW3RhYmluZGV4ID0gXCItMVwiXSk6bm90KFtkaXNhYmxlZF0pOm5vdChbc3R5bGUqPVwiZGlzcGxheTpub25lXCJdKTpub3QoW2hpZGRlbl0pJHtlfSxcbiAgICAgICAgICAgIFtocmVmXTpub3QoW3RhYmluZGV4ID0gXCItMVwiXSk6bm90KFtkaXNhYmxlZF0pOm5vdChbc3R5bGUqPVwiZGlzcGxheTpub25lXCJdKTpub3QoW2hpZGRlbl0pJHtlfSxcbiAgICAgICAgICAgIGlucHV0Om5vdChbdGFiaW5kZXggPSBcIi0xXCJdKTpub3QoW2Rpc2FibGVkXSk6bm90KFtzdHlsZSo9XCJkaXNwbGF5Om5vbmVcIl0pOm5vdChbaGlkZGVuXSkke2V9LFxuICAgICAgICAgICAgc2VsZWN0Om5vdChbdGFiaW5kZXggPSBcIi0xXCJdKTpub3QoW2Rpc2FibGVkXSk6bm90KFtzdHlsZSo9XCJkaXNwbGF5Om5vbmVcIl0pOm5vdChbaGlkZGVuXSkke2V9LFxuICAgICAgICAgICAgdGV4dGFyZWE6bm90KFt0YWJpbmRleCA9IFwiLTFcIl0pOm5vdChbZGlzYWJsZWRdKTpub3QoW3N0eWxlKj1cImRpc3BsYXk6bm9uZVwiXSk6bm90KFtoaWRkZW5dKSR7ZX0sXG4gICAgICAgICAgICBbdGFiSW5kZXhdOm5vdChbdGFiSW5kZXggPSBcIi0xXCJdKTpub3QoW2Rpc2FibGVkXSk6bm90KFtzdHlsZSo9XCJkaXNwbGF5Om5vbmVcIl0pOm5vdChbaGlkZGVuXSkke2V9LFxuICAgICAgICAgICAgW2NvbnRlbnRlZGl0YWJsZV06bm90KFt0YWJJbmRleCA9IFwiLTFcIl0pOm5vdChbZGlzYWJsZWRdKTpub3QoW3N0eWxlKj1cImRpc3BsYXk6bm9uZVwiXSk6bm90KFtoaWRkZW5dKSR7ZX1gKTohMX1mdW5jdGlvbiBmdCh0KXtyZXR1cm4hISh0JiZ0Lm9mZnNldFBhcmVudCE9bnVsbCl9ZnVuY3Rpb24gSnQodCl7cmV0dXJuIWZ0KHQpfWZ1bmN0aW9uIEt0KCl7cmV0dXJuL2lQYWR8aVBob25lfGlQb2QvLnRlc3QobmF2aWdhdG9yLnVzZXJBZ2VudCkmJiEoXCJNU1N0cmVhbVwiaW4gd2luZG93KX1mdW5jdGlvbiB0ZSgpe3JldHVybiB0eXBlb2Ygd2luZG93PT1cInVuZGVmaW5lZFwifHwhd2luZG93Lm1hdGNoTWVkaWE/ITE6d2luZG93Lm1hdGNoTWVkaWEoXCIocHJlZmVycy1yZWR1Y2VkLW1vdGlvbjogcmVkdWNlKVwiKS5tYXRjaGVzfWZ1bmN0aW9uIGVlKCl7cmV0dXJuIWF0KCl9ZnVuY3Rpb24gb2UoKXtyZXR1cm5cIm9udG91Y2hzdGFydFwiaW4gd2luZG93fHxuYXZpZ2F0b3IubWF4VG91Y2hQb2ludHM+MHx8bmF2aWdhdG9yLm1zTWF4VG91Y2hQb2ludHM+MH1mdW5jdGlvbiBuZSh0LGUpe3ZhciBvLG47aWYodCl7bGV0IHI9dC5wYXJlbnRFbGVtZW50LGk9c3Qocikscz1oKCksbD10Lm9mZnNldFBhcmVudD90Lm9mZnNldFdpZHRoOml0KHQpLGE9dC5vZmZzZXRQYXJlbnQ/dC5vZmZzZXRIZWlnaHQ6cnQodCksZj1DKChvPXI9PW51bGw/dm9pZCAwOnIuY2hpbGRyZW4pPT1udWxsP3ZvaWQgMDpvWzBdKSx1PWsoKG49cj09bnVsbD92b2lkIDA6ci5jaGlsZHJlbik9PW51bGw/dm9pZCAwOm5bMF0pLGM9XCJcIixkPVwiXCI7aS5sZWZ0K2YrbD5zLndpZHRoLUYoKT9pLmxlZnQ8bD9lJTI9PT0xP2M9aS5sZWZ0P1wiLVwiK2kubGVmdCtcInB4XCI6XCIxMDAlXCI6ZSUyPT09MCYmKGM9cy53aWR0aC1sLUYoKStcInB4XCIpOmM9XCItMTAwJVwiOmM9XCIxMDAlXCIsdC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS50b3ArdSthPnMuaGVpZ2h0P2Q9YC0ke2EtdX1weGA6ZD1cIjBweFwiLHQuc3R5bGUudG9wPWQsdC5zdHlsZS5pbnNldElubGluZVN0YXJ0PWN9fWZ1bmN0aW9uIHJlKCl7cmV0dXJuIG5ldyBQcm9taXNlKHQ9PntyZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCk9PntyZXF1ZXN0QW5pbWF0aW9uRnJhbWUoKCk9PnQoKSl9KX0pfWZ1bmN0aW9uIGllKHQpe3ZhciBlO3QmJihcInJlbW92ZVwiaW4gRWxlbWVudC5wcm90b3R5cGU/dC5yZW1vdmUoKTooZT10LnBhcmVudE5vZGUpPT1udWxsfHxlLnJlbW92ZUNoaWxkKHQpKX1mdW5jdGlvbiBzZSh0KXtpZihwKHQpKXtsZXQgZT10LG89ZS5fcExpc3RlbmVycztvJiYoby5mb3JFYWNoKChbbixyXSk9Pnt0LnJlbW92ZUV2ZW50TGlzdGVuZXIobixyKX0pLGUuX3BMaXN0ZW5lcnM9W10pfX1mdW5jdGlvbiBsZSh0LGUpe2xldCBvPXkodCk7aWYobylvLnJlbW92ZUNoaWxkKGUpO2Vsc2UgdGhyb3cgbmV3IEVycm9yKFwiQ2Fubm90IHJlbW92ZSBcIitlK1wiIGZyb20gXCIrdCl9ZnVuY3Rpb24gYWUodCl7dmFyIGU7aWYoSCh0KSl7dHJ5eyhlPXQucGFyZW50Tm9kZSk9PW51bGx8fGUucmVtb3ZlQ2hpbGQodCl9Y2F0Y2gobyl7fXJldHVybiBudWxsfXJldHVybiB0fWZ1bmN0aW9uIGZlKHQsZSl7bGV0IG89Z2V0Q29tcHV0ZWRTdHlsZSh0KSxuPW8uZ2V0UHJvcGVydHlWYWx1ZShcImJvcmRlci10b3Atd2lkdGhcIikscj1uP3BhcnNlRmxvYXQobik6MCxpPW8uZ2V0UHJvcGVydHlWYWx1ZShcInBhZGRpbmctdG9wXCIpLHM9aT9wYXJzZUZsb2F0KGkpOjAsbD10LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLGY9ZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS50b3ArZG9jdW1lbnQuYm9keS5zY3JvbGxUb3AtKGwudG9wK2RvY3VtZW50LmJvZHkuc2Nyb2xsVG9wKS1yLXMsdT10LnNjcm9sbFRvcCxjPXQuY2xpZW50SGVpZ2h0LGQ9ayhlKTtmPDA/dC5zY3JvbGxUb3A9dStmOmYrZD5jJiYodC5zY3JvbGxUb3A9dStmLWMrZCl9ZnVuY3Rpb24gZGUodCxlPVwiXCIsbyl7aWYocCh0KSYmbyE9PW51bGwmJm8hPT12b2lkIDApe2xldCBuPWUudG9Mb3dlckNhc2UoKTtpZigvXm9uW2Etel0vLnRlc3Qobikpe0EodCxuLnNsaWNlKDIpLG8pO3JldHVybn1pZihuPT09XCJzdHlsZVwiKXt0eXBlb2Ygbz09XCJzdHJpbmdcIj92KHQsbyx7Y2xlYXI6ITB9KTp0eXBlb2Ygbz09XCJvYmplY3RcIiYmdih0LG8pO3JldHVybn1pZihQKGUsbyl8fE8oZSxvKSlyZXR1cm47dC5zZXRBdHRyaWJ1dGUoZSxvKX19ZnVuY3Rpb24gdWUodCxlLG89bnVsbCxuKXtlJiYodCE9bnVsbCYmdC5zdHlsZSkmJnQuc3R5bGUuc2V0UHJvcGVydHkoZSxvLG4pfWV4cG9ydHt6IGFzIGFic29sdXRlUG9zaXRpb24sUiBhcyBhZGRDbGFzcyxMIGFzIGFkZFN0eWxlLHh0IGFzIGFsaWduT3ZlcmxheSx3dCBhcyBhcHBlbmRDaGlsZCxBIGFzIGFwcGx5RXZlbnRMaXN0ZW5lcixFZSBhcyBhcHBseVN0eWxlLG10IGFzIGJsb2NrQm9keVNjcm9sbCxVIGFzIGNhbGN1bGF0ZUJvZHlTY3JvbGxiYXJXaWR0aCxFdCBhcyBjYWxjdWxhdGVTY3JvbGxiYXJIZWlnaHQsRiBhcyBjYWxjdWxhdGVTY3JvbGxiYXJXaWR0aCxTdCBhcyBjbGVhclNlbGVjdGlvbixRIGFzIGNyZWF0ZUVsZW1lbnQsdnQgYXMgY3JlYXRlU3R5bGVBc1N0cmluZyxLIGFzIGNyZWF0ZVN0eWxlRWxlbWVudCxKIGFzIGNyZWF0ZVN0eWxlTWFya3VwLFR0IGFzIGNyZWF0ZVN0eWxlVGFnLEcgYXMgZXNjYXBlQXR0cmlidXRlLGd0IGFzIGV4cG9ydENTVixMdCBhcyBmYWRlSW4sQ3QgYXMgZmFkZU91dCx0dCBhcyBmaW5kLGV0IGFzIGZpbmRTaW5nbGUsSHQgYXMgZm9jdXMsb3QgYXMgZ2V0QXR0cmlidXRlLEF0IGFzIGdldEJyb3dzZXIsa3QgYXMgZ2V0QnJvd3Nlckxhbmd1YWdlLE10IGFzIGdldENTU1Byb3BlcnR5LEUgYXMgZ2V0Q1NTVmFyaWFibGVCeVJlZ2V4LFJ0IGFzIGdldEN1cnNvck9mZnNldCxXdCBhcyBnZXRGaXJzdEZvY3VzYWJsZUVsZW1lbnQseCBhcyBnZXRGb2N1c2FibGVFbGVtZW50cyxQdCBhcyBnZXRIZWlnaHQsVCBhcyBnZXRIaWRkZW5FbGVtZW50RGltZW5zaW9ucyxydCBhcyBnZXRIaWRkZW5FbGVtZW50T3V0ZXJIZWlnaHQsaXQgYXMgZ2V0SGlkZGVuRWxlbWVudE91dGVyV2lkdGgsT3QgYXMgZ2V0SW5kZXgsRnQgYXMgZ2V0SW5uZXJXaWR0aCxOdCBhcyBnZXRMYXN0Rm9jdXNhYmxlRWxlbWVudCwkdCBhcyBnZXROZXh0RWxlbWVudFNpYmxpbmcsQnQgYXMgZ2V0TmV4dEZvY3VzYWJsZUVsZW1lbnQsc3QgYXMgZ2V0T2Zmc2V0LGsgYXMgZ2V0T3V0ZXJIZWlnaHQsQyBhcyBnZXRPdXRlcldpZHRoLGIgYXMgZ2V0UGFyZW50Tm9kZSwkIGFzIGdldFBhcmVudHMsSXQgYXMgZ2V0UHJldmlvdXNFbGVtZW50U2libGluZyxTIGFzIGdldFNjcm9sbExlZnQsVXQgYXMgZ2V0U2Nyb2xsYWJsZVBhcmVudHMsRHQgYXMgZ2V0U2VsZWN0aW9uLFogYXMgZ2V0VGFyZ2V0RWxlbWVudCxWdCBhcyBnZXRVc2VyQWdlbnQsaCBhcyBnZXRWaWV3cG9ydCxqdCBhcyBnZXRXaWR0aCxWIGFzIGdldFdpbmRvd1Njcm9sbExlZnQsaiBhcyBnZXRXaW5kb3dTY3JvbGxUb3AscXQgYXMgaGFzQ1NTQW5pbWF0aW9uLHp0IGFzIGhhc0NTU1RyYW5zaXRpb24sSSBhcyBoYXNDbGFzcyxfdCBhcyBpbnZva2VFbGVtZW50TWV0aG9kLFh0IGFzIGlzQW5kcm9pZCxsdCBhcyBpc0F0dHJpYnV0ZUVxdWFscyxZdCBhcyBpc0F0dHJpYnV0ZU5vdEVxdWFscyxadCBhcyBpc0NsaWNrYWJsZSxhdCBhcyBpc0NsaWVudCxRdCBhcyBpc0Nzc1N1cHBvcnRlZCxwIGFzIGlzRWxlbWVudCxIIGFzIGlzRXhpc3QsR3QgYXMgaXNGb2N1c2FibGVFbGVtZW50LEp0IGFzIGlzSGlkZGVuLEt0IGFzIGlzSU9TLHRlIGFzIGlzUHJlZmVyc1JlZHVjZWRNb3Rpb24scSBhcyBpc1JUTCxlZSBhcyBpc1NlcnZlcixvZSBhcyBpc1RvdWNoRGV2aWNlLGZ0IGFzIGlzVmlzaWJsZSxuZSBhcyBuZXN0ZWRQb3NpdGlvbixyZSBhcyBuZXh0RnJhbWUsWSBhcyByZWxhdGl2ZVBvc2l0aW9uLGllIGFzIHJlbW92ZSxzZSBhcyByZW1vdmVBdHRyaWJ1dGVzLGxlIGFzIHJlbW92ZUNoaWxkLFcgYXMgcmVtb3ZlQ2xhc3MsYWUgYXMgcmVtb3ZlU3R5bGVUYWcsbnQgYXMgcmVzb2x2ZVVzZXJBZ2VudCxEIGFzIHNhdmVBcyxmZSBhcyBzY3JvbGxJblZpZXcsYmUgYXMgc2VjdXJpdHksZGUgYXMgc2V0QXR0cmlidXRlLE4gYXMgc2V0QXR0cmlidXRlcyx1ZSBhcyBzZXRDU1NQcm9wZXJ0eSx5IGFzIHRvRWxlbWVudCxodCBhcyB1bmJsb2NrQm9keVNjcm9sbH07XG4iLCJmdW5jdGlvbiB2KCl7bGV0IHM9bmV3IE1hcCxyPXtvbihuLHQpe2xldCBlPXMuZ2V0KG4pO3JldHVybiBlP2UucHVzaCh0KTplPVt0XSxzLnNldChuLGUpLHJ9LG9mZihuLHQpe2xldCBlPXMuZ2V0KG4pO2lmKGUpe2xldCBvPWUuaW5kZXhPZih0KTtvIT09LTEmJmUuc3BsaWNlKG8sMSl9cmV0dXJuIHJ9LGVtaXQobiwuLi50KXtsZXQgZT1zLmdldChuKTtlJiZlLmZvckVhY2gobz0+e28odFswXSl9KX0sY2xlYXIoKXtzLmNsZWFyKCl9fTtyZXR1cm4gcn1leHBvcnR7diBhcyBFdmVudEJ1c307XG4iLCJmdW5jdGlvbiBnKCl7bGV0IHI9W10saT0oZSxuLHQ9OTk5KT0+e2xldCBzPXUoZSxuLHQpLG89cy52YWx1ZSsocy5rZXk9PT1lPzA6dCkrMTtyZXR1cm4gci5wdXNoKHtrZXk6ZSx2YWx1ZTpvfSksb30sZD1lPT57cj1yLmZpbHRlcihuPT5uLnZhbHVlIT09ZSl9LGE9KGUsbik9PnUoZSxuKS52YWx1ZSx1PShlLG4sdD0wKT0+Wy4uLnJdLnJldmVyc2UoKS5maW5kKHM9Pm4/ITA6cy5rZXk9PT1lKXx8e2tleTplLHZhbHVlOnR9LGw9ZT0+ZSYmcGFyc2VJbnQoZS5zdHlsZS56SW5kZXgsMTApfHwwO3JldHVybntnZXQ6bCxzZXQ6KGUsbix0KT0+e24mJihuLnN0eWxlLnpJbmRleD1TdHJpbmcoaShlLCEwLHQpKSl9LGNsZWFyOmU9PntlJiYoZChsKGUpKSxlLnN0eWxlLnpJbmRleD1cIlwiKX0sZ2V0Q3VycmVudDplPT5hKGUsITEpfX12YXIgeD1nKCk7ZXhwb3J0e3ggYXMgWkluZGV4fTtcbiIsInZhciBudD1PYmplY3QuZGVmaW5lUHJvcGVydHksb3Q9T2JqZWN0LmRlZmluZVByb3BlcnRpZXM7dmFyIGl0PU9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzO3ZhciB0ZT1PYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzO3ZhciBTZT1PYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LE9lPU9iamVjdC5wcm90b3R5cGUucHJvcGVydHlJc0VudW1lcmFibGU7dmFyIHllPShlLHQscyk9PnQgaW4gZT9udChlLHQse2VudW1lcmFibGU6ITAsY29uZmlndXJhYmxlOiEwLHdyaXRhYmxlOiEwLHZhbHVlOnN9KTplW3RdPXMseT0oZSx0KT0+e2Zvcih2YXIgcyBpbiB0fHwodD17fSkpU2UuY2FsbCh0LHMpJiZ5ZShlLHMsdFtzXSk7aWYodGUpZm9yKHZhciBzIG9mIHRlKHQpKU9lLmNhbGwodCxzKSYmeWUoZSxzLHRbc10pO3JldHVybiBlfSxDPShlLHQpPT5vdChlLGl0KHQpKTt2YXIgVj0oZSx0KT0+e3ZhciBzPXt9O2Zvcih2YXIgciBpbiBlKVNlLmNhbGwoZSxyKSYmdC5pbmRleE9mKHIpPDAmJihzW3JdPWVbcl0pO2lmKGUhPW51bGwmJnRlKWZvcih2YXIgciBvZiB0ZShlKSl0LmluZGV4T2Yocik8MCYmT2UuY2FsbChlLHIpJiYoc1tyXT1lW3JdKTtyZXR1cm4gc307aW1wb3J0e2RlZXBNZXJnZSBhcyBhdH1mcm9tXCJAcHJpbWV1aXgvdXRpbHMvb2JqZWN0XCI7ZnVuY3Rpb24geGUoZSwuLi50KXtyZXR1cm4gYXQoZSwuLi50KX1pbXBvcnR7ZGVlcE1lcmdlIGFzIGp0fWZyb21cIkBwcmltZXVpeC91dGlscy9vYmplY3RcIjtpbXBvcnR7bmVzdGVkS2V5cyBhcyBWdCx0b1Rva2VuS2V5IGFzIFJ0fWZyb21cIkBwcmltZXVpeC91dGlscy9vYmplY3RcIjtpbXBvcnR7RXZlbnRCdXMgYXMgbHR9ZnJvbVwiQHByaW1ldWl4L3V0aWxzL2V2ZW50YnVzXCI7dmFyIGN0PWx0KCksUj1jdDtpbXBvcnR7Z2V0S2V5VmFsdWUgYXMgdXQsaXNBcnJheSBhcyBkdCxpc05vdEVtcHR5IGFzIG10LGlzTnVtYmVyIGFzIGxlLGlzT2JqZWN0IGFzIF9lLGlzU3RyaW5nIGFzIEQsbWF0Y2hSZWdleCBhcyBzZSx0b0tlYmFiQ2FzZSBhcyBodH1mcm9tXCJAcHJpbWV1aXgvdXRpbHMvb2JqZWN0XCI7dmFyIFA9L3soW159XSopfS9nLHJlPS8oXFxkK1xccytbKyovLV1cXHMrXFxkKykvZyxuZT0vdmFyXFwoW14pXStcXCkvZztmdW5jdGlvbiBLKGUpe3JldHVybiBEKGUpP2UucmVwbGFjZSgvW0EtWl0vZywodCxzKT0+cz09PTA/dDpcIi5cIit0LnRvTG93ZXJDYXNlKCkpLnRvTG93ZXJDYXNlKCk6ZX1mdW5jdGlvbiB6dChlLHQpe2R0KGUpP2UucHVzaCguLi50fHxbXSk6X2UoZSkmJk9iamVjdC5hc3NpZ24oZSx0KX1mdW5jdGlvbiBQZShlKXtyZXR1cm4gX2UoZSkmJk9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChlLFwiJHZhbHVlXCIpJiZPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoZSxcIiR0eXBlXCIpP2UuJHZhbHVlOmV9ZnVuY3Rpb24gR3QoZSx0PVwiXCIpe3JldHVybltcIm9wYWNpdHlcIixcInotaW5kZXhcIixcImxpbmUtaGVpZ2h0XCIsXCJmb250LXdlaWdodFwiLFwiZmxleFwiLFwiZmxleC1ncm93XCIsXCJmbGV4LXNocmlua1wiLFwib3JkZXJcIl0uc29tZShyPT50LmVuZHNXaXRoKHIpKT9lOmAke2V9YC50cmltKCkuc3BsaXQoXCIgXCIpLm1hcChpPT5sZShpKT9gJHtpfXB4YDppKS5qb2luKFwiIFwiKX1mdW5jdGlvbiBwdChlKXtyZXR1cm4gZS5yZXBsYWNlQWxsKC8gL2csXCJcIikucmVwbGFjZSgvW15cXHddL2csXCItXCIpfWZ1bmN0aW9uIG9lKGU9XCJcIix0PVwiXCIpe3JldHVybiBwdChgJHtEKGUsITEpJiZEKHQsITEpP2Ake2V9LWA6ZX0ke3R9YCl9ZnVuY3Rpb24gY2UoZT1cIlwiLHQ9XCJcIil7cmV0dXJuYC0tJHtvZShlLHQpfWB9ZnVuY3Rpb24gZ3QoZT1cIlwiKXtsZXQgdD0oZS5tYXRjaCgvey9nKXx8W10pLmxlbmd0aCxzPShlLm1hdGNoKC99L2cpfHxbXSkubGVuZ3RoO3JldHVybih0K3MpJTIhPT0wfWZ1bmN0aW9uIEwoZSx0PVwiXCIscz1cIlwiLHI9W10sbyl7aWYoRChlKSl7bGV0IGk9ZS50cmltKCk7aWYoZ3QoaSkpcmV0dXJuO2lmKHNlKGksUCkpe2xldCBuPWkucmVwbGFjZUFsbChQLHU9PntsZXQgYT11LnJlcGxhY2UoL3t8fS9nLFwiXCIpLnNwbGl0KFwiLlwiKS5maWx0ZXIobD0+IXIuc29tZShjPT5zZShsLGMpKSk7cmV0dXJuYHZhcigke2NlKHMsaHQoYS5qb2luKFwiLVwiKSkpfSR7bXQobyk/YCwgJHtvfWA6XCJcIn0pYH0pO3JldHVybiBzZShuLnJlcGxhY2UobmUsXCIwXCIpLHJlKT9gY2FsYygke259KWA6bn1yZXR1cm4gaX1lbHNlIGlmKGxlKGUpKXJldHVybiBlfWZ1bmN0aW9uIEl0KGU9e30sdCl7aWYoRCh0KSl7bGV0IHM9dC50cmltKCk7cmV0dXJuIHNlKHMsUCk/cy5yZXBsYWNlQWxsKFAscj0+dXQoZSxyLnJlcGxhY2UoL3t8fS9nLFwiXCIpKSk6c31lbHNlIGlmKGxlKHQpKXJldHVybiB0fWZ1bmN0aW9uICRlKGUsdCxzKXtEKHQsITEpJiZlLnB1c2goYCR7dH06JHtzfTtgKX1mdW5jdGlvbiBqKGUsdCl7cmV0dXJuIGU/YCR7ZX17JHt0fX1gOlwiXCJ9ZnVuY3Rpb24gdWUoZSx0KXtpZihlLmluZGV4T2YoXCJkdChcIik9PT0tMSlyZXR1cm4gZTtmdW5jdGlvbiBzKG4sdSl7bGV0IG09W10sYT0wLGw9XCJcIixjPW51bGwscD0wO2Zvcig7YTw9bi5sZW5ndGg7KXtsZXQgZz1uW2FdO2lmKChnPT09J1wiJ3x8Zz09PVwiJ1wifHxnPT09XCJgXCIpJiZuW2EtMV0hPT1cIlxcXFxcIiYmKGM9Yz09PWc/bnVsbDpnKSwhYyYmKGc9PT1cIihcIiYmcCsrLGc9PT1cIilcIiYmcC0tLChnPT09XCIsXCJ8fGE9PT1uLmxlbmd0aCkmJnA9PT0wKSl7bGV0IGY9bC50cmltKCk7Zi5zdGFydHNXaXRoKFwiZHQoXCIpP20ucHVzaCh1ZShmLHUpKTptLnB1c2gocihmKSksbD1cIlwiLGErKztjb250aW51ZX1nIT09dm9pZCAwJiYobCs9ZyksYSsrfXJldHVybiBtfWZ1bmN0aW9uIHIobil7bGV0IHU9blswXTtpZigodT09PSdcIid8fHU9PT1cIidcInx8dT09PVwiYFwiKSYmbltuLmxlbmd0aC0xXT09PXUpcmV0dXJuIG4uc2xpY2UoMSwtMSk7bGV0IG09TnVtYmVyKG4pO3JldHVybiBpc05hTihtKT9uOm19bGV0IG89W10saT1bXTtmb3IobGV0IG49MDtuPGUubGVuZ3RoO24rKylpZihlW25dPT09XCJkXCImJmUuc2xpY2UobixuKzMpPT09XCJkdChcIilpLnB1c2gobiksbis9MjtlbHNlIGlmKGVbbl09PT1cIilcIiYmaS5sZW5ndGg+MCl7bGV0IHU9aS5wb3AoKTtpLmxlbmd0aD09PTAmJm8ucHVzaChbdSxuXSl9aWYoIW8ubGVuZ3RoKXJldHVybiBlO2ZvcihsZXQgbj1vLmxlbmd0aC0xO24+PTA7bi0tKXtsZXRbdSxtXT1vW25dLGE9ZS5zbGljZSh1KzMsbSksbD1zKGEsdCksYz10KC4uLmwpO2U9ZS5zbGljZSgwLHUpK2MrZS5zbGljZShtKzEpfXJldHVybiBlfWltcG9ydHtlc2NhcGVBdHRyaWJ1dGUgYXMgd2V9ZnJvbVwiQHByaW1ldWl4L3V0aWxzL2RvbVwiO2ltcG9ydHtpc0VtcHR5IGFzIHZ0LGlzTm90RW1wdHkgYXMgeCxpc09iamVjdCBhcyBmZSxtYXRjaFJlZ2V4IGFzIEN0LG1pbmlmeUNTUyBhcyBOZSxyZXNvbHZlIGFzIGllfWZyb21cIkBwcmltZXVpeC91dGlscy9vYmplY3RcIjtmdW5jdGlvbiB2ZShlKXtyZXR1cm4gZS5sZW5ndGg9PT00P2AjJHtlWzFdfSR7ZVsxXX0ke2VbMl19JHtlWzJdfSR7ZVszXX0ke2VbM119YDplfWZ1bmN0aW9uIENlKGUpe2xldCB0PXBhcnNlSW50KGUuc3Vic3RyaW5nKDEpLDE2KSxzPXQ+PjE2JjI1NSxyPXQ+PjgmMjU1LG89dCYyNTU7cmV0dXJue3I6cyxnOnIsYjpvfX1mdW5jdGlvbiBmdChlLHQscyl7cmV0dXJuYCMke2UudG9TdHJpbmcoMTYpLnBhZFN0YXJ0KDIsXCIwXCIpfSR7dC50b1N0cmluZygxNikucGFkU3RhcnQoMixcIjBcIil9JHtzLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLFwiMFwiKX1gfXZhciBWZT0vXiMoWzAtOWEtZl17M318WzAtOWEtZl17Nn0pJC9pLFg9KGUsdCxzKT0+e2lmKCFWZS50ZXN0KGUpfHwhVmUudGVzdCh0KSlyZXR1cm4gdDtlPXZlKGUpLHQ9dmUodCk7bGV0IGk9KHMvMTAwKjItMSsxKS8yLG49MS1pLHU9Q2UoZSksbT1DZSh0KSxhPU1hdGgucm91bmQodS5yKmkrbS5yKm4pLGw9TWF0aC5yb3VuZCh1LmcqaSttLmcqbiksYz1NYXRoLnJvdW5kKHUuYippK20uYipuKTtyZXR1cm4gZnQoYSxsLGMpfTtpbXBvcnR7bWF0Y2hSZWdleCBhcyBrdH1mcm9tXCJAcHJpbWV1aXgvdXRpbHNcIjt2YXIgZGU9KGUsdCk9PlgoXCIjMDAwMDAwXCIsZSx0KTt2YXIgbWU9KGUsdCk9PlgoXCIjZmZmZmZmXCIsZSx0KTt2YXIgUmU9WzUwLDEwMCwyMDAsMzAwLDQwMCw1MDAsNjAwLDcwMCw4MDAsOTAwLDk1MF0sVHQ9ZT0+e2lmKGt0KGUsUCkpe2xldCB0PWUucmVwbGFjZSgve3x9L2csXCJcIik7cmV0dXJuIFJlLnJlZHVjZSgocyxyKT0+KHNbcl09YHske3R9LiR7cn19YCxzKSx7fSl9cmV0dXJuIFJlLnJlZHVjZSgodCxzLHIpPT4odFtzXT1yPD01P21lKGUsKDUtcikqMTkpOmRlKGUsKHItNSkqMTUpLHQpLHt9KX07aW1wb3J0e3Jlc29sdmUgYXMgamV9ZnJvbVwiQHByaW1ldWl4L3V0aWxzXCI7aW1wb3J0e2lzRW1wdHkgYXMgYnQsbWF0Y2hSZWdleCBhcyB5dH1mcm9tXCJAcHJpbWV1aXgvdXRpbHMvb2JqZWN0XCI7dmFyIFN0PShlLHQpPT57bGV0IHM9ZS5zcGxpdChcIi5cIikscj1cIlwiO2ZvcihsZXQgbz0wO288cy5sZW5ndGg7bysrKXtsZXQgaT1LKHNbb10pO3QubGFzdEluZGV4PTAsIXQudGVzdChpKSYmKHI9cj9gJHtyfS4ke2l9YDppKX1yZXR1cm4gcn0saGU9KGUsdCxzLHIsbyk9PntpZih0eXBlb2YgZSE9XCJzdHJpbmdcIilyZXR1cm4gZSE9bnVsbD9lOlMuZ2V0VG9rZW5WYWx1ZSh0KTtpZihQLmxhc3RJbmRleD0wLCFQLnRlc3QoZSkpcmV0dXJuIGU7bGV0IGk9dC5zbGljZSgwLHQuaW5kZXhPZihcIi5cIikpLG49ZS5yZXBsYWNlKFAsdT0+e2xldCBtPXUuc2xpY2UoMSwtMSksYT1tLmluZGV4T2YoXCIuXCIpO2lmKChhPT09LTE/bTptLnNsaWNlKDAsYSkpIT09aSlyZXR1cm4gdTtsZXQgbD1TLmdldFRva2VuVmFsdWUobSk7cmV0dXJuIGw9PW51bGw/dTpgJHtsfWB9KTtyZXR1cm4gTChuLHZvaWQgMCxzLFtyXSxvKX0sT3Q9KGUsdCxzLHIpPT57dmFyIGwsYyxwLGc7bGV0IG89U3QoZSxzKSxpPVMudG9rZW5zLG49aS5fX3N0cmljdENhY2hlO258fChuPW5ldyBNYXAsT2JqZWN0LmRlZmluZVByb3BlcnR5KGksXCJfX3N0cmljdENhY2hlXCIse3ZhbHVlOm4sZW51bWVyYWJsZTohMSxjb25maWd1cmFibGU6ITB9KSk7bGV0IHU9cj09bnVsbHx8dHlwZW9mIHIhPVwib2JqZWN0XCIsbT11JiZyIT1udWxsP2Ake3R9fCR7b318JHtyfWA6YCR7dH18JHtvfWAsYT11P24uZ2V0KG0pOnZvaWQgMDtpZihhPT09dm9pZCAwJiYoIXV8fCFuLmhhcyhtKSkpe2xldCBmPShsPWlbb10pPT1udWxsP3ZvaWQgMDpsLnBhdGhzLGg9Zj09bnVsbD92b2lkIDA6Zi5maW5kKGs9Pmsuc2NoZW1lPT09XCJub25lXCIpLGQ9KGM9Zj09bnVsbD92b2lkIDA6Zi5maW5kKGs9Pmsuc2NoZW1lPT09XCJsaWdodFwiKSkhPW51bGw/YzpoLFQ9KHA9Zj09bnVsbD92b2lkIDA6Zi5maW5kKGs9Pmsuc2NoZW1lPT09XCJkYXJrXCIpKSE9bnVsbD9wOmg7aWYoZCYmVCYmZCE9PVQpe2xldCBrPWhlKGQudmFsdWUsbyx0LHMsciksYj1oZShULnZhbHVlLG8sdCxzLHIpO2E9az09PWI/azpgbGlnaHQtZGFyaygke2t9LCR7Yn0pYH1lbHNlIGE9aGUoKGc9ZCE9bnVsbD9kOlQpPT1udWxsP3ZvaWQgMDpnLnZhbHVlLG8sdCxzLHIpO3UmJm4uc2V0KG0sYSl9cmV0dXJuIFMuaGFzU2NvcGVkVG9rZW5QYXRoKG8pP0woYHske299fWAsdm9pZCAwLHQsW3NdLGEpOmF9LHVzPWU9Pnt2YXIgaSxuLHU7bGV0IHQ9Uy5nZXRUaGVtZSgpLHM9YCR7KGk9cGUodCxlLHZvaWQgMCxcInZhcmlhYmxlXCIpKSE9bnVsbD9pOlwiXCJ9YCxyPSh1PShuPXMubWF0Y2goLy0tW1xcdy1dKy9nKSk9PW51bGw/dm9pZCAwOm5bMF0pIT1udWxsP3U6XCJcIixvPXBlKHQsZSx2b2lkIDAsXCJ2YWx1ZVwiKTtyZXR1cm57bmFtZTpyLHZhcmlhYmxlOnMsdmFsdWU6b319LE49KGUsdCxzKT0+cGUoUy5nZXRUaGVtZSgpLGUsdCxzKSxwZT0oZT17fSx0LHMscik9Pnt2YXIgbSxhLGwsYyxwLGcsZixoLGQsVDtpZighdClyZXR1cm5cIlwiO2xldCBvPShtPVMuZGVmYXVsdHMpPT1udWxsP3ZvaWQgMDptLnZhcmlhYmxlLGk9KHA9KGE9ZT09bnVsbD92b2lkIDA6ZS5vcHRpb25zKT09bnVsbD92b2lkIDA6YS5wcmVmaXgpIT1udWxsP3A6KGM9KGw9Uy5kZWZhdWx0cyk9PW51bGw/dm9pZCAwOmwub3B0aW9ucyk9PW51bGw/dm9pZCAwOmMucHJlZml4LG49KFQ9KGQ9KGc9ZT09bnVsbD92b2lkIDA6ZS5vcHRpb25zKT09bnVsbD92b2lkIDA6Zy5jc3NWYXJpYWJsZXMpIT1udWxsP2Q6KGg9KGY9Uy5kZWZhdWx0cyk9PW51bGw/dm9pZCAwOmYub3B0aW9ucyk9PW51bGw/dm9pZCAwOmguY3NzVmFyaWFibGVzKSE9bnVsbD9UOiEwO2lmKHI9PT1cInZhbHVlXCIpcmV0dXJuIFMuZ2V0VG9rZW5WYWx1ZSh0KTtpZihidChyKSYmIW4pcmV0dXJuIE90KHQsaSxvLmV4Y2x1ZGVkS2V5UmVnZXgscyk7bGV0IHU9eXQodCxQKT90OmB7JHt0fX1gO3JldHVybiBMKHUsdm9pZCAwLGksW28uZXhjbHVkZWRLZXlSZWdleF0scyl9O3ZhciB4dD0oLi4uZSk9Pnt2YXIgdDtyZXR1cm5gJHsodD1OKC4uLmUpKSE9bnVsbD90OlwiXCJ9YH07ZnVuY3Rpb24gZ3MoZSwuLi50KXtpZihlIGluc3RhbmNlb2YgQXJyYXkpe2xldCBzPWUucmVkdWNlKChyLG8saSk9Pnt2YXIgbjtyZXR1cm4gcitvKygobj1qZSh0W2ldLHtkdDpOfSkpIT1udWxsP246XCJcIil9LFwiXCIpO3JldHVybiB1ZShzLHh0KX1yZXR1cm4gamUoZSx7ZHQ6Tn0pfWltcG9ydHttZXJnZUtleXMgYXMgRWV9ZnJvbVwiQHByaW1ldWl4L3V0aWxzL29iamVjdFwiO3ZhciBBPShlPXt9KT0+e2xldHtwcmVzZXQ6dCxvcHRpb25zOnN9PWU7cmV0dXJue3ByZXNldChyKXtyZXR1cm4gdD10P0VlKHQscik6cix0aGlzfSxvcHRpb25zKHIpe3JldHVybiBzPXM/eSh5KHt9LHMpLHIpOnIsdGhpc30scHJpbWFyeVBhbGV0dGUocil7bGV0e3NlbWFudGljOm99PXR8fHt9O3JldHVybiB0PUMoeSh7fSx0KSx7c2VtYW50aWM6Qyh5KHt9LG8pLHtwcmltYXJ5OnJ9KX0pLHRoaXN9LHN1cmZhY2VQYWxldHRlKHIpe3ZhciBtLGEsbDtsZXQgbz0obT10PT1udWxsP3ZvaWQgMDp0LnNlbWFudGljKSE9bnVsbD9tOnt9LGk9ciYmT2JqZWN0Lmhhc093bihyLFwibGlnaHRcIik/ci5saWdodDpyLG49ciYmT2JqZWN0Lmhhc093bihyLFwiZGFya1wiKT9yLmRhcms6cix1PXtjb2xvclNjaGVtZTp7bGlnaHQ6eSh5KHt9LChhPW8uY29sb3JTY2hlbWUpPT1udWxsP3ZvaWQgMDphLmxpZ2h0KSwhIWkmJntzdXJmYWNlOml9KSxkYXJrOnkoeSh7fSwobD1vLmNvbG9yU2NoZW1lKT09bnVsbD92b2lkIDA6bC5kYXJrKSwhIW4mJntzdXJmYWNlOm59KX19O3JldHVybiB0PUMoeSh7fSx0KSx7c2VtYW50aWM6eSh5KHt9LG8pLHUpfSksdGhpc30sZGVmaW5lKHt1c2VEZWZhdWx0UHJlc2V0OnI9ITEsdXNlRGVmYXVsdE9wdGlvbnM6bz0hMX09e30pe3JldHVybntwcmVzZXQ6cj9TLmdldFByZXNldCgpOnQsb3B0aW9uczpvP1MuZ2V0T3B0aW9ucygpOnN9fSx1cGRhdGUoe21lcmdlUHJlc2V0czpyPSEwLG1lcmdlT3B0aW9uczpvPSEwfT17fSl7bGV0IGk9e3ByZXNldDpyP0VlKFMuZ2V0UHJlc2V0KCksdCE9bnVsbD90Ont9KTp0LG9wdGlvbnM6bz95KHkoe30sUy5nZXRPcHRpb25zKCkpLHMpOnN9O3JldHVybiBTLnNldFRoZW1lKGkpLGl9LHVzZShyKXtsZXQgbz10aGlzLmRlZmluZShyKTtyZXR1cm4gUy5zZXRUaGVtZShvKSxvfX19O2ltcG9ydHtpc09iamVjdCBhcyBfdCxtYXRjaFJlZ2V4IGFzIFB0LHRvS2ViYWJDYXNlIGFzICR0fWZyb21cIkBwcmltZXVpeC91dGlscy9vYmplY3RcIjtmdW5jdGlvbiBnZShlLHQ9e30pe2xldCBzPVMuZGVmYXVsdHMudmFyaWFibGUse3ByZWZpeDpyPXMucHJlZml4LHNlbGVjdG9yOm89cy5zZWxlY3RvcixleGNsdWRlZEtleVJlZ2V4Omk9cy5leGNsdWRlZEtleVJlZ2V4fT10LG49W10sdT1bXSxtPVt7bm9kZTplLHBhdGg6cn1dO2Zvcig7bS5sZW5ndGg7KXtsZXR7bm9kZTpsLHBhdGg6Y309bS5wb3AoKTtmb3IobGV0IHAgaW4gbCl7bGV0IGc9bFtwXSxmPVBlKGcpLGQ9UHQocCxpKT9vZShjKTpvZShjLCR0KHApKTtpZihfdChmKSltLnB1c2goe25vZGU6ZixwYXRoOmR9KTtlbHNle2xldCBUPWNlKGQpLGs9TChmLGQscixbaV0pOyRlKHUsVCxrPT1udWxsP2s6YCR7a31gKTtsZXQgYj1kO3ImJmIuc3RhcnRzV2l0aChyK1wiLVwiKSYmKGI9Yi5zbGljZShyLmxlbmd0aCsxKSksbi5wdXNoKGIucmVwbGFjZSgvLS9nLFwiLlwiKSl9fX1sZXQgYT11LmpvaW4oXCJcIik7cmV0dXJue3ZhbHVlOnUsdG9rZW5zOm4sZGVjbGFyYXRpb25zOmEsY3NzOmoobyxhKX19dmFyICQ9e3JlZ2V4OntydWxlczp7Y2xhc3M6e3BhdHRlcm46L15cXC4oW2EtekEtWl1bXFx3LV0qKSQvLHJlc29sdmUoZSl7cmV0dXJue3R5cGU6XCJjbGFzc1wiLHNlbGVjdG9yOmUsbWF0Y2hlZDp0aGlzLnBhdHRlcm4udGVzdChlLnRyaW0oKSl9fX0sYXR0cjp7cGF0dGVybjovXlxcWyguKilcXF0kLyxyZXNvbHZlKGUpe3JldHVybnt0eXBlOlwiYXR0clwiLHNlbGVjdG9yOmA6cm9vdCR7ZX0sOmhvc3Qke2V9YCxtYXRjaGVkOnRoaXMucGF0dGVybi50ZXN0KGUudHJpbSgpKX19fSxtZWRpYTp7cGF0dGVybjovXkBtZWRpYSAoLiopJC8scmVzb2x2ZShlKXtyZXR1cm57dHlwZTpcIm1lZGlhXCIsc2VsZWN0b3I6ZSxtYXRjaGVkOnRoaXMucGF0dGVybi50ZXN0KGUudHJpbSgpKX19fSxzeXN0ZW06e3BhdHRlcm46L15zeXN0ZW0kLyxyZXNvbHZlKGUpe3JldHVybnt0eXBlOlwic3lzdGVtXCIsc2VsZWN0b3I6XCJAbWVkaWEgKHByZWZlcnMtY29sb3Itc2NoZW1lOiBkYXJrKVwiLG1hdGNoZWQ6dGhpcy5wYXR0ZXJuLnRlc3QoZS50cmltKCkpfX19LGN1c3RvbTp7cmVzb2x2ZShlKXtyZXR1cm57dHlwZTpcImN1c3RvbVwiLHNlbGVjdG9yOmUsbWF0Y2hlZDohMH19fX0scmVzb2x2ZShlKXtsZXQgdD1PYmplY3Qua2V5cyh0aGlzLnJ1bGVzKS5maWx0ZXIocz0+cyE9PVwiY3VzdG9tXCIpLm1hcChzPT50aGlzLnJ1bGVzW3NdKTtyZXR1cm5bZV0uZmxhdCgpLm1hcChzPT57dmFyIHI7cmV0dXJuKHI9dC5tYXAobz0+by5yZXNvbHZlKHMpKS5maW5kKG89Pm8ubWF0Y2hlZCkpIT1udWxsP3I6dGhpcy5ydWxlcy5jdXN0b20ucmVzb2x2ZShzKX0pfX0sX3RvVmFyaWFibGVzKGUsdCl7cmV0dXJuIGdlKGUse3ByZWZpeDp0PT1udWxsP3ZvaWQgMDp0LnByZWZpeH0pfSxnZXRDb21tb24oe25hbWU6ZT1cIlwiLHRoZW1lOnQ9e30scGFyYW1zOnMsc2V0OnIsZGVmYXVsdHM6b30pe3ZhciBrLGIsTyx2LEUsXyx3O2xldHtwcmVzZXQ6aSxvcHRpb25zOm59PXQsdSxtLGEsbCxjLHAsZztpZih4KGkpKXtsZXR7cHJpbWl0aXZlOnosc2VtYW50aWM6RyxleHRlbmQ6SX09aSxmPUd8fHt9LHtjb2xvclNjaGVtZTphZX09ZixVPVYoZixbXCJjb2xvclNjaGVtZVwiXSksaD1JfHx7fSx7Y29sb3JTY2hlbWU6SH09aCxNPVYoaCxbXCJjb2xvclNjaGVtZVwiXSksZD1hZXx8e30se2Rhcms6Qn09ZCxXPVYoZCxbXCJkYXJrXCJdKSxUPUh8fHt9LHtkYXJrOnF9PVQsRj1WKFQsW1wiZGFya1wiXSksWj14KHopP3RoaXMuX3RvVmFyaWFibGVzKHtwcmltaXRpdmU6en0sbik6e30sSj14KFUpP3RoaXMuX3RvVmFyaWFibGVzKHtzZW1hbnRpYzpVfSxuKTp7fSxRPXgoVyk/dGhpcy5fdG9WYXJpYWJsZXMoe2xpZ2h0Old9LG4pOnt9LFk9eChCKT90aGlzLl90b1ZhcmlhYmxlcyh7ZGFyazpCfSxuKTp7fSxlZT14KE0pP3RoaXMuX3RvVmFyaWFibGVzKHtzZW1hbnRpYzpNfSxuKTp7fSxUZT14KEYpP3RoaXMuX3RvVmFyaWFibGVzKHtsaWdodDpGfSxuKTp7fSxiZT14KHEpP3RoaXMuX3RvVmFyaWFibGVzKHtkYXJrOnF9LG4pOnt9LFtLZSxYZV09WyhrPVouZGVjbGFyYXRpb25zKSE9bnVsbD9rOlwiXCIsWi50b2tlbnNdLFt6ZSxHZV09WyhiPUouZGVjbGFyYXRpb25zKSE9bnVsbD9iOlwiXCIsSi50b2tlbnN8fFtdXSxbSWUsVWVdPVsoTz1RLmRlY2xhcmF0aW9ucykhPW51bGw/TzpcIlwiLFEudG9rZW5zfHxbXV0sW0hlLFdlXT1bKHY9WS5kZWNsYXJhdGlvbnMpIT1udWxsP3Y6XCJcIixZLnRva2Vuc3x8W11dLFtxZSxGZV09WyhFPWVlLmRlY2xhcmF0aW9ucykhPW51bGw/RTpcIlwiLGVlLnRva2Vuc3x8W11dLFtaZSxKZV09WyhfPVRlLmRlY2xhcmF0aW9ucykhPW51bGw/XzpcIlwiLFRlLnRva2Vuc3x8W11dLFtRZSxZZV09Wyh3PWJlLmRlY2xhcmF0aW9ucykhPW51bGw/dzpcIlwiLGJlLnRva2Vuc3x8W11dO3U9dGhpcy50cmFuc2Zvcm1DU1MoZSxLZSxcImxpZ2h0XCIsXCJ2YXJpYWJsZVwiLG4scixvKSxtPVhlO2xldCBldD10aGlzLnRyYW5zZm9ybUNTUyhlLGAke3plfSR7SWV9YCxcImxpZ2h0XCIsXCJ2YXJpYWJsZVwiLG4scixvKSx0dD10aGlzLnRyYW5zZm9ybUNTUyhlLGAke0hlfWAsXCJkYXJrXCIsXCJ2YXJpYWJsZVwiLG4scixvKTthPWAke2V0fSR7dHR9YCxsPVsuLi5uZXcgU2V0KFsuLi5HZSwuLi5VZSwuLi5XZV0pXTtsZXQgc3Q9dGhpcy50cmFuc2Zvcm1DU1MoZSxgJHtxZX0ke1plfWNvbG9yLXNjaGVtZTpsaWdodGAsXCJsaWdodFwiLFwidmFyaWFibGVcIixuLHIsbykscnQ9dGhpcy50cmFuc2Zvcm1DU1MoZSxgJHtRZX1jb2xvci1zY2hlbWU6ZGFya2AsXCJkYXJrXCIsXCJ2YXJpYWJsZVwiLG4scixvKTtjPWAke3N0fSR7cnR9YCxwPVsuLi5uZXcgU2V0KFsuLi5GZSwuLi5KZSwuLi5ZZV0pXSxnPWllKGkuY3NzLHtkdDpOfSl9cmV0dXJue3ByaW1pdGl2ZTp7Y3NzOnUsdG9rZW5zOm19LHNlbWFudGljOntjc3M6YSx0b2tlbnM6bH0sZ2xvYmFsOntjc3M6Yyx0b2tlbnM6cH0sc3R5bGU6Z319LGdldFByZXNldCh7bmFtZTplPVwiXCIscHJlc2V0OnQ9e30sb3B0aW9uczpzLHBhcmFtczpyLHNldDpvLGRlZmF1bHRzOmksc2VsZWN0b3I6bixpc1Njb3BlZFRva2VuUGF0aHM6dX0pe3ZhciBjLGQsVCxrO2xldCBtLGEsbDtpZih4KHQpJiYoKGM9cz09bnVsbD92b2lkIDA6cy5jc3NWYXJpYWJsZXMpPT1udWxsfHxjfHx1KSl7bGV0IGI9ZS5yZXBsYWNlKFwiLWRpcmVjdGl2ZVwiLFwiXCIpLHA9dCx7Y29sb3JTY2hlbWU6TyxleHRlbmQ6dixjc3M6RX09cCxfPVYocCxbXCJjb2xvclNjaGVtZVwiLFwiZXh0ZW5kXCIsXCJjc3NcIl0pLGc9dnx8e30se2NvbG9yU2NoZW1lOnd9PWcsej1WKGcsW1wiY29sb3JTY2hlbWVcIl0pLGY9T3x8e30se2Rhcms6R309ZixJPVYoZixbXCJkYXJrXCJdKSxoPXd8fHt9LHtkYXJrOmFlfT1oLFU9VihoLFtcImRhcmtcIl0pLEg9eChfKT90aGlzLl90b1ZhcmlhYmxlcyh7W2JdOnkoeSh7fSxfKSx6KX0scyk6e30sTT14KEkpP3RoaXMuX3RvVmFyaWFibGVzKHtbYl06eSh5KHt9LEkpLFUpfSxzKTp7fSxCPXgoRyk/dGhpcy5fdG9WYXJpYWJsZXMoe1tiXTp5KHkoe30sRyksYWUpfSxzKTp7fSxbVyxxXT1bKGQ9SC5kZWNsYXJhdGlvbnMpIT1udWxsP2Q6XCJcIixILnRva2Vuc3x8W11dLFtGLFpdPVsoVD1NLmRlY2xhcmF0aW9ucykhPW51bGw/VDpcIlwiLE0udG9rZW5zfHxbXV0sW0osUV09WyhrPUIuZGVjbGFyYXRpb25zKSE9bnVsbD9rOlwiXCIsQi50b2tlbnN8fFtdXSxZPXRoaXMudHJhbnNmb3JtQ1NTKGIsYCR7V30ke0Z9YCxcImxpZ2h0XCIsXCJ2YXJpYWJsZVwiLHMsbyxpLG4pLGVlPXRoaXMudHJhbnNmb3JtQ1NTKGIsSixcImRhcmtcIixcInZhcmlhYmxlXCIscyxvLGksbik7bT1gJHtZfSR7ZWV9YCxhPVsuLi5uZXcgU2V0KFsuLi5xLC4uLlosLi4uUV0pXSxsPWllKEUse2R0Ok59KX1yZXR1cm57Y3NzOm0sdG9rZW5zOmEsc3R5bGU6bH19LGdldFNjb3BlZFNlbGVjdG9yKGUsdCl7aWYoISghKHQhPW51bGwmJnQuc2NvcGVkKXx8IWUpKXJldHVybmBbZGF0YS1zdHlsZWQ9XCIke2V9XCJdYH0sZ2V0UHJlc2V0Qyh7bmFtZTplPVwiXCIsdGhlbWU6dD17fSxwYXJhbXM6cyxzZXQ6cixkZWZhdWx0czpvfSl7dmFyIGE7bGV0e3ByZXNldDppLG9wdGlvbnM6bn09dCx1PShhPWk9PW51bGw/dm9pZCAwOmkuY29tcG9uZW50cyk9PW51bGw/dm9pZCAwOmFbZV0sbT10aGlzLmdldFNjb3BlZFNlbGVjdG9yKGUsbik7cmV0dXJuIHRoaXMuZ2V0UHJlc2V0KHtuYW1lOmUscHJlc2V0OnUsb3B0aW9uczpuLHBhcmFtczpzLHNldDpyLGRlZmF1bHRzOm8sc2VsZWN0b3I6bX0pfSxnZXRQcmVzZXREKHtuYW1lOmU9XCJcIix0aGVtZTp0PXt9LHBhcmFtczpzLHNldDpyLGRlZmF1bHRzOm99KXt2YXIgbCxjO2xldCBpPWUucmVwbGFjZShcIi1kaXJlY3RpdmVcIixcIlwiKSx7cHJlc2V0Om4sb3B0aW9uczp1fT10LG09KChsPW49PW51bGw/dm9pZCAwOm4uY29tcG9uZW50cyk9PW51bGw/dm9pZCAwOmxbaV0pfHwoKGM9bj09bnVsbD92b2lkIDA6bi5kaXJlY3RpdmVzKT09bnVsbD92b2lkIDA6Y1tpXSksYT10aGlzLmdldFNjb3BlZFNlbGVjdG9yKGksdSk7cmV0dXJuIHRoaXMuZ2V0UHJlc2V0KHtuYW1lOmkscHJlc2V0Om0sb3B0aW9uczp1LHBhcmFtczpzLHNldDpyLGRlZmF1bHRzOm8sc2VsZWN0b3I6YX0pfSxhcHBseURhcmtDb2xvclNjaGVtZShlKXtsZXQgdD1lLmRhcmtNb2RlU2VsZWN0b3I7cmV0dXJuISh0PT09XCJub25lXCJ8fHQ9PT0hMSl9LGdldENvbG9yU2NoZW1lT3B0aW9uKGUsdCl7dmFyIHM7cmV0dXJuIHRoaXMuYXBwbHlEYXJrQ29sb3JTY2hlbWUoZSk/dGhpcy5yZWdleC5yZXNvbHZlKGUuZGFya01vZGVTZWxlY3Rvcj09PSEwP3Qub3B0aW9ucy5kYXJrTW9kZVNlbGVjdG9yOihzPWUuZGFya01vZGVTZWxlY3RvcikhPW51bGw/czp0Lm9wdGlvbnMuZGFya01vZGVTZWxlY3Rvcik6W119LGdldExheWVyT3JkZXIoZSx0PXt9LHMscil7bGV0e2Nzc0xheWVyOm99PXQ7cmV0dXJuIG8/YEBsYXllciAke2llKG8ub3JkZXJ8fG8ubmFtZXx8XCJwcmltZXVpXCIscyl9YDpcIlwifSxnZXRDb21tb25TdHlsZVNoZWV0KHtuYW1lOmU9XCJcIix0aGVtZTp0PXt9LHBhcmFtczpzLHByb3BzOnI9e30sc2V0Om8sZGVmYXVsdHM6aX0pe2xldCBuPXRoaXMuZ2V0Q29tbW9uKHtuYW1lOmUsdGhlbWU6dCxwYXJhbXM6cyxzZXQ6byxkZWZhdWx0czppfSksdT1PYmplY3QuZW50cmllcyhyKS5yZWR1Y2UoKG0sW2EsbF0pPT4obS5wdXNoKGAke2F9PVwiJHt3ZShsKX1cImApLG0pLFtdKS5qb2luKFwiIFwiKTtyZXR1cm4gT2JqZWN0LmVudHJpZXMobnx8e30pLnJlZHVjZSgobSxbYSxsXSk9PntpZihmZShsKSYmT2JqZWN0Lmhhc093bihsLFwiY3NzXCIpKXtsZXQgYz1OZShsLmNzcykscD1gJHthfS12YXJpYWJsZXNgO20ucHVzaChgPHN0eWxlIHR5cGU9XCJ0ZXh0L2Nzc1wiIGRhdGEtcHJpbWV2dWUtc3R5bGUtaWQ9XCIke3B9XCIgJHt1fT4ke2N9PC9zdHlsZT5gKX1yZXR1cm4gbX0sW10pLmpvaW4oXCJcIil9LGdldFN0eWxlU2hlZXQoe25hbWU6ZT1cIlwiLHRoZW1lOnQ9e30scGFyYW1zOnMscHJvcHM6cj17fSxzZXQ6byxkZWZhdWx0czppfSl7dmFyIGE7bGV0IG49e25hbWU6ZSx0aGVtZTp0LHBhcmFtczpzLHNldDpvLGRlZmF1bHRzOml9LHU9KGE9ZS5pbmNsdWRlcyhcIi1kaXJlY3RpdmVcIik/dGhpcy5nZXRQcmVzZXREKG4pOnRoaXMuZ2V0UHJlc2V0QyhuKSk9PW51bGw/dm9pZCAwOmEuY3NzLG09T2JqZWN0LmVudHJpZXMocikucmVkdWNlKChsLFtjLHBdKT0+KGwucHVzaChgJHtjfT1cIiR7d2UocCl9XCJgKSxsKSxbXSkuam9pbihcIiBcIik7cmV0dXJuIHU/YDxzdHlsZSB0eXBlPVwidGV4dC9jc3NcIiBkYXRhLXByaW1ldnVlLXN0eWxlLWlkPVwiJHtlfS12YXJpYWJsZXNcIiAke219PiR7TmUodSl9PC9zdHlsZT5gOlwiXCJ9LGNyZWF0ZVRva2VucyhlPXt9LHQscz1cIlwiLHI9XCJcIixvPXt9KXtsZXQgaT1mdW5jdGlvbihhLGwsYyxwKXtyZXR1cm4gYS5yZXBsYWNlKFAsZz0+e3ZhciBUO2xldCBmPWcuc2xpY2UoMSwtMSksaD10aGlzLnRva2Vuc1tmXTtpZighaClyZXR1cm4gY29uc29sZS53YXJuKGBUb2tlbiBub3QgZm91bmQgZm9yIHBhdGg6ICR7Zn1gKSxcIl9fVU5SRVNPTFZFRF9fXCI7bGV0IGQ9aC5jb21wdXRlZChsLGMscCk7aWYoQXJyYXkuaXNBcnJheShkKSYmZC5sZW5ndGg9PT0yKXtsZXQgaz1kWzBdLnZhbHVlLGI9ZFsxXS52YWx1ZTtyZXR1cm4gaz09PWI/ayE9bnVsbD9rOlwiX19VTlJFU09MVkVEX19cIjpgbGlnaHQtZGFyaygke2t9LCR7Yn0pYH1yZXR1cm4oVD1kPT1udWxsP3ZvaWQgMDpkLnZhbHVlKSE9bnVsbD9UOlwiX19VTlJFU09MVkVEX19cIn0pfSxuPWZ1bmN0aW9uKGEsbCxjLHApe2lmKGEuaW5kZXhPZihcImxpZ2h0LWRhcmsoXCIpPT09LTEpcmV0dXJuIGE7bGV0IGc9W10sZj1hLmxlbmd0aCxoPTA7Zm9yKDtoPGY7KXtsZXQgZD1hLmluZGV4T2YoXCJsaWdodC1kYXJrKFwiLGgpO2lmKGQ9PT0tMSl7Zy5wdXNoKGEuc2xpY2UoaCkpO2JyZWFrfWcucHVzaChhLnNsaWNlKGgsZCkpO2xldCBUPTEsaz1kKzExLGI9LTE7Zm9yKDtrPGYmJlQ+MDspe2xldCBfPWEuY2hhckNvZGVBdChrKTtfPT09NDA/VCsrOl89PT00MT9ULS06Xz09PTQ0JiZUPT09MSYmYj09PS0xJiYoYj1rKSxrKyt9aWYoVCE9PTB8fGI9PT0tMSl7Zy5wdXNoKGEuc2xpY2UoZCkpO2JyZWFrfWxldCBPPWEuc2xpY2UoZCsxMSxiKS50cmltKCksdj1hLnNsaWNlKGIrMSxrLTEpLnRyaW0oKSxFPWwmJmwhPT1cIm5vbmVcIj9sOm51bGw7aWYoRT09PVwibGlnaHRcIilnLnB1c2gobi5jYWxsKHRoaXMsTyxcImxpZ2h0XCIsYyxwKSk7ZWxzZSBpZihFPT09XCJkYXJrXCIpZy5wdXNoKG4uY2FsbCh0aGlzLHYsXCJkYXJrXCIsYyxwKSk7ZWxzZXtsZXQgXz1pLmNhbGwodGhpcyxuLmNhbGwodGhpcyxPLFwibGlnaHRcIixjLHApLFwibGlnaHRcIixjLHApLHc9aS5jYWxsKHRoaXMsbi5jYWxsKHRoaXMsdixcImRhcmtcIixjLHApLFwiZGFya1wiLGMscCk7Zy5wdXNoKF89PT13P186YGxpZ2h0LWRhcmsoJHtffSwke3d9KWApfWg9a31yZXR1cm4gZy5qb2luKFwiXCIpfSx1PWZ1bmN0aW9uKGEsbD17fSxjPVtdKXtpZihjLmluY2x1ZGVzKHRoaXMucGF0aCkpcmV0dXJuIGNvbnNvbGUud2FybihgQ2lyY3VsYXIgcmVmZXJlbmNlIGRldGVjdGVkIGF0ICR7dGhpcy5wYXRofWApLHtjb2xvclNjaGVtZTphLHBhdGg6dGhpcy5wYXRoLHBhdGhzOmwsdmFsdWU6dm9pZCAwfTtjLnB1c2godGhpcy5wYXRoKSxsLm5hbWU9dGhpcy5wYXRoLGwuYmluZGluZ3x8KGwuYmluZGluZz17fSk7bGV0IHA9dGhpcy52YWx1ZTtpZih0eXBlb2YgdGhpcy52YWx1ZT09XCJzdHJpbmdcIil7bGV0IGc9dGhpcy52YWx1ZS50cmltKCksZj1nLmluZGV4T2YoXCJsaWdodC1kYXJrKFwiKSE9PS0xLGg9Zy5pbmRleE9mKFwie1wiKSE9PS0xO2lmKGZ8fGgpe2xldCBkPWY/bi5jYWxsKHRoaXMsZyxhLGwsYyk6ZyxUPWQuaW5kZXhPZihcIntcIikhPT0tMT9pLmNhbGwodGhpcyxkLGEsbCxjKTpkO3JlLmxhc3RJbmRleD0wLG5lLmxhc3RJbmRleD0wLHA9cmUudGVzdChULnJlcGxhY2UobmUsXCIwXCIpKT9gY2FsYygke1R9KWA6VH19cmV0dXJuIHZ0KGwuYmluZGluZykmJmRlbGV0ZSBsLmJpbmRpbmcsYy5wb3AoKSx7Y29sb3JTY2hlbWU6YSxwYXRoOnRoaXMucGF0aCxwYXRoczpsLHZhbHVlOnR5cGVvZiBwPT1cInN0cmluZ1wiJiZwLmluZGV4T2YoXCJfX1VOUkVTT0xWRURfX1wiKSE9PS0xP3ZvaWQgMDpwfX0sbT0oYSxsLGMpPT57T2JqZWN0LmVudHJpZXMoYSkuZm9yRWFjaCgoW3AsZ10pPT57bGV0IGY9Q3QocCx0LnZhcmlhYmxlLmV4Y2x1ZGVkS2V5UmVnZXgpP2w6bD9gJHtsfS4ke0socCl9YDpLKHApLGg9Yz9gJHtjfS4ke3B9YDpwO2ZlKGcpP20oZyxmLGgpOihvW2ZdfHwob1tmXT17cGF0aHM6W10sY29tcHV0ZWQ6KGQsVD17fSxrPVtdKT0+e2xldCBiPW9bZl0ucGF0aHM7aWYoYi5sZW5ndGg9PT0xKXtsZXQgTz1iWzBdLHY9Ty5zY2hlbWUhPT1cIm5vbmVcIj9PLnNjaGVtZTpkO3JldHVybiBPLmNvbXB1dGVkKHYsVC5iaW5kaW5nLGspfWVsc2UgaWYoZCYmZCE9PVwibm9uZVwiKWZvcihsZXQgTz0wO088Yi5sZW5ndGg7TysrKXtsZXQgdj1iW09dO2lmKHYuc2NoZW1lPT09ZClyZXR1cm4gdi5jb21wdXRlZChkLFQuYmluZGluZyxrKX1yZXR1cm4gYi5tYXAoTz0+Ty5jb21wdXRlZChPLnNjaGVtZSxUW08uc2NoZW1lXSxrKSl9fSksb1tmXS5wYXRocy5wdXNoKHtwYXRoOmgsdmFsdWU6ZyxzY2hlbWU6aC5pbmNsdWRlcyhcImNvbG9yU2NoZW1lLmxpZ2h0XCIpP1wibGlnaHRcIjpoLmluY2x1ZGVzKFwiY29sb3JTY2hlbWUuZGFya1wiKT9cImRhcmtcIjpcIm5vbmVcIixjb21wdXRlZDp1LHRva2VuczpvfSkpfSl9O3JldHVybiBtKGUscyxyKSxvfSxnZXRUb2tlblZhbHVlKGUsdCxzKXt2YXIgcCxnLGY7bGV0IHI9ZS5fX2NhY2hlO3J8fChyPW5ldyBNYXAsT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsXCJfX2NhY2hlXCIse3ZhbHVlOnIsZW51bWVyYWJsZTohMSxjb25maWd1cmFibGU6ITB9KSk7bGV0IG89ci5nZXQodCk7aWYobyE9PXZvaWQgMHx8ci5oYXModCkpcmV0dXJuIG87bGV0IGk9cy52YXJpYWJsZS5leGNsdWRlZEtleVJlZ2V4LG49dC5zcGxpdChcIi5cIiksdT1bXTtmb3IobGV0IGg9MDtoPG4ubGVuZ3RoO2grKyl7bGV0IGQ9bltoXTtpLmxhc3RJbmRleD0wLGkudGVzdChkLnRvTG93ZXJDYXNlKCkpfHx1LnB1c2goZCl9bGV0IG09dS5qb2luKFwiLlwiKSxhPXQuaW5kZXhPZihcImNvbG9yU2NoZW1lLmxpZ2h0XCIpIT09LTE/XCJsaWdodFwiOnQuaW5kZXhPZihcImNvbG9yU2NoZW1lLmRhcmtcIikhPT0tMT9cImRhcmtcIjp2b2lkIDAsbD1lW21dO2lmKCFsKXtyLnNldCh0LHZvaWQgMCk7cmV0dXJufWxldCBjO2lmKGEpe2xldCBoPWwuY29tcHV0ZWQoYSk7aWYoQXJyYXkuaXNBcnJheShoKSl7Zm9yKGxldCBkPTA7ZDxoLmxlbmd0aDtkKyspaWYoKChwPWhbZF0pPT1udWxsP3ZvaWQgMDpwLmNvbG9yU2NoZW1lKT09PWEpe2M9aFtkXS52YWx1ZTticmVha319ZWxzZSBjPWg9PW51bGw/dm9pZCAwOmgudmFsdWV9ZWxzZXtsZXQgaD1sLmNvbXB1dGVkKFwibGlnaHRcIiksZD1sLmNvbXB1dGVkKFwiZGFya1wiKSxULGs7aWYoQXJyYXkuaXNBcnJheShoKSl7Zm9yKGxldCBiPTA7YjxoLmxlbmd0aDtiKyspaWYoKChnPWhbYl0pPT1udWxsP3ZvaWQgMDpnLmNvbG9yU2NoZW1lKT09PVwibGlnaHRcIil7VD1oW2JdLnZhbHVlO2JyZWFrfX1lbHNlIFQ9aD09bnVsbD92b2lkIDA6aC52YWx1ZTtpZihBcnJheS5pc0FycmF5KGQpKXtmb3IobGV0IGI9MDtiPGQubGVuZ3RoO2IrKylpZigoKGY9ZFtiXSk9PW51bGw/dm9pZCAwOmYuY29sb3JTY2hlbWUpPT09XCJkYXJrXCIpe2s9ZFtiXS52YWx1ZTticmVha319ZWxzZSBrPWQ9PW51bGw/dm9pZCAwOmQudmFsdWU7VD09PXZvaWQgMCYmaz09PXZvaWQgMD9jPXZvaWQgMDpUPT09dm9pZCAwP2M9azprPT09dm9pZCAwfHxUPT09az9jPVQ6Yz1gbGlnaHQtZGFyaygke1R9LCR7a30pYH1yZXR1cm4gci5zZXQodCxjKSxjfSxnZXRTZWxlY3RvclJ1bGUoZSx0LHMscixvPVwiOnJvb3QsOmhvc3RcIil7cmV0dXJuIHM9PT1cImNsYXNzXCJ8fHM9PT1cImF0dHJcIj9qKHgodCk/YCR7ZX0ke3R9LCR7ZX0gJHt0fWA6ZSxyKTpqKGUsaih0IT1udWxsP3Q6byxyKSl9LHRyYW5zZm9ybUNTUyhlLHQscyxyLG89e30saSxuLHUpe3ZhciBtLGE7aWYoeCh0KSl7bGV0e2Nzc0xheWVyOmx9PW87aWYociE9PVwic3R5bGVcIil7bGV0IGM9dGhpcy5nZXRDb2xvclNjaGVtZU9wdGlvbihvLG4pLHA9KGE9KG09bj09bnVsbD92b2lkIDA6bi52YXJpYWJsZSk9PW51bGw/dm9pZCAwOm0uc2VsZWN0b3IpIT1udWxsP2E6XCI6cm9vdCw6aG9zdFwiO3Q9cz09PVwiZGFya1wiP2MucmVkdWNlKChnLHt0eXBlOmYsc2VsZWN0b3I6aH0pPT4oeChoKSYmKGcrPWguaW5jbHVkZXMoXCJbQ1NTXVwiKT9oLnJlcGxhY2UoXCJbQ1NTXVwiLHQpOnRoaXMuZ2V0U2VsZWN0b3JSdWxlKGgsdSxmLHQscCkpLGcpLFwiXCIpOmoodSE9bnVsbD91OnAsdCl9aWYobCl7bGV0IGM9e25hbWU6XCJwcmltZXVpXCIsb3JkZXI6XCJwcmltZXVpXCJ9O2ZlKGwpJiYoYy5uYW1lPWllKGwubmFtZSx7bmFtZTplLHR5cGU6cn0pKSx4KGMubmFtZSkmJih0PWooYEBsYXllciAke2MubmFtZX1gLHQpLGk9PW51bGx8fGkubGF5ZXJOYW1lcyhjLm5hbWUpKX1yZXR1cm4gdH1yZXR1cm5cIlwifX07dmFyIFM9e2RlZmF1bHRzOnt2YXJpYWJsZTp7cHJlZml4OlwicFwiLHNlbGVjdG9yOlwiOnJvb3QsOmhvc3RcIixleGNsdWRlZEtleVJlZ2V4Oi9eKHByaW1pdGl2ZXxzZW1hbnRpY3xjb21wb25lbnRzfGRpcmVjdGl2ZXN8dmFyaWFibGVzfGNvbG9yc2NoZW1lfGxpZ2h0fGRhcmt8Y29tbW9ufHJvb3R8c3RhdGVzfGV4dGVuZHxjc3MpJC9naX0sb3B0aW9uczp7cHJlZml4OlwicFwiLGRhcmtNb2RlU2VsZWN0b3I6XCJzeXN0ZW1cIixjc3NMYXllcjohMSxjc3NWYXJpYWJsZXM6ITAsc2NvcGVkOiExfX0sX3RoZW1lOnZvaWQgMCxfbGF5ZXJOYW1lczpuZXcgU2V0LF9sb2FkZWRTdHlsZU5hbWVzOm5ldyBTZXQsX2xvYWRpbmdTdHlsZXM6bmV3IFNldCxfdG9rZW5zOnt9LF9zY29wZWRUb2tlblBhdGhzOm5ldyBTZXQsdXBkYXRlKGU9e30pe2xldHt0aGVtZTp0fT1lO3QmJih0aGlzLl90aGVtZT1DKHkoe30sdCkse29wdGlvbnM6eSh5KHt9LHRoaXMuZGVmYXVsdHMub3B0aW9ucyksdC5vcHRpb25zKX0pLHRoaXMuX3Rva2Vucz0kLmNyZWF0ZVRva2Vucyh0aGlzLnByZXNldCx0aGlzLmRlZmF1bHRzKSx0aGlzLnJlc2V0Q2FjaGVzKCkpfSxnZXQgdGhlbWUoKXtyZXR1cm4gdGhpcy5fdGhlbWV9LGdldCBwcmVzZXQoKXt2YXIgZTtyZXR1cm4oKGU9dGhpcy50aGVtZSk9PW51bGw/dm9pZCAwOmUucHJlc2V0KXx8e319LGdldCBvcHRpb25zKCl7dmFyIGU7cmV0dXJuKChlPXRoaXMudGhlbWUpPT1udWxsP3ZvaWQgMDplLm9wdGlvbnMpfHx7fX0sZ2V0IHRva2Vucygpe3JldHVybiB0aGlzLl90b2tlbnN9LGhhc1Njb3BlZFRva2VuUGF0aChlKXtyZXR1cm4gdGhpcy5fc2NvcGVkVG9rZW5QYXRocy5oYXMoZSl9LGdldFNjb3BlZFRva2VuUGF0aHMoKXtyZXR1cm5bLi4udGhpcy5fc2NvcGVkVG9rZW5QYXRoc119LGFkZFNjb3BlZFRva2VuKGUpe2xldCB0PSExO3JldHVybiBlJiZPYmplY3Qua2V5cyhlKS5sZW5ndGgmJlZ0KGUpLmZvckVhY2gocz0+e2xldCByPVJ0KHMpO3RoaXMuX3Njb3BlZFRva2VuUGF0aHMuaGFzKHIpfHwodGhpcy5fc2NvcGVkVG9rZW5QYXRocy5hZGQociksdD0hMCl9KSx0fSxjbGVhclNjb3BlZFRva2VuUGF0aHMoKXt0aGlzLl9zY29wZWRUb2tlblBhdGhzLmNsZWFyKCl9LGdldFRoZW1lKCl7cmV0dXJuIHRoaXMudGhlbWV9LHNldFRoZW1lKGUpe3RoaXMudXBkYXRlKHt0aGVtZTplfSksUi5lbWl0KFwidGhlbWU6Y2hhbmdlXCIsZSl9LGdldFByZXNldCgpe3JldHVybiB0aGlzLnByZXNldH0sc2V0UHJlc2V0KGUpe3RoaXMuX3RoZW1lPUMoeSh7fSx0aGlzLnRoZW1lKSx7cHJlc2V0OmV9KSx0aGlzLl90b2tlbnM9JC5jcmVhdGVUb2tlbnMoZSx0aGlzLmRlZmF1bHRzKSx0aGlzLnJlc2V0Q2FjaGVzKCksUi5lbWl0KFwicHJlc2V0OmNoYW5nZVwiLGUpLFIuZW1pdChcInRoZW1lOmNoYW5nZVwiLHRoaXMudGhlbWUpfSxnZXRPcHRpb25zKCl7cmV0dXJuIHRoaXMub3B0aW9uc30sc2V0T3B0aW9ucyhlKXt0aGlzLl90aGVtZT1DKHkoe30sdGhpcy50aGVtZSkse29wdGlvbnM6ZX0pLHRoaXMucmVzZXRTdHlsZUNhY2hlcygpLFIuZW1pdChcIm9wdGlvbnM6Y2hhbmdlXCIsZSksUi5lbWl0KFwidGhlbWU6Y2hhbmdlXCIsdGhpcy50aGVtZSl9LHJlc2V0U3R5bGVDYWNoZXMoKXt0aGlzLmNsZWFyTG9hZGVkU3R5bGVOYW1lcygpLHRoaXMuY2xlYXJMYXllck5hbWVzKCl9LHJlc2V0Q2FjaGVzKCl7dGhpcy5yZXNldFN0eWxlQ2FjaGVzKCksdGhpcy5jbGVhclNjb3BlZFRva2VuUGF0aHMoKX0sZ2V0TGF5ZXJOYW1lcygpe3JldHVyblsuLi50aGlzLl9sYXllck5hbWVzXX0sc2V0TGF5ZXJOYW1lcyhlKXt0aGlzLl9sYXllck5hbWVzLmFkZChlKX0sY2xlYXJMYXllck5hbWVzKCl7dGhpcy5fbGF5ZXJOYW1lcy5jbGVhcigpfSxnZXRMb2FkZWRTdHlsZU5hbWVzKCl7cmV0dXJuIHRoaXMuX2xvYWRlZFN0eWxlTmFtZXN9LGlzU3R5bGVOYW1lTG9hZGVkKGUpe3JldHVybiB0aGlzLl9sb2FkZWRTdHlsZU5hbWVzLmhhcyhlKX0sc2V0TG9hZGVkU3R5bGVOYW1lKGUpe3RoaXMuX2xvYWRlZFN0eWxlTmFtZXMuYWRkKGUpfSxkZWxldGVMb2FkZWRTdHlsZU5hbWUoZSl7dGhpcy5fbG9hZGVkU3R5bGVOYW1lcy5kZWxldGUoZSl9LGNsZWFyTG9hZGVkU3R5bGVOYW1lcygpe3RoaXMuX2xvYWRlZFN0eWxlTmFtZXMuY2xlYXIoKX0sZ2V0VG9rZW5WYWx1ZShlKXtyZXR1cm4gJC5nZXRUb2tlblZhbHVlKHRoaXMudG9rZW5zLGUsdGhpcy5kZWZhdWx0cyl9LGdldENvbW1vbihlPVwiXCIsdCl7cmV0dXJuICQuZ2V0Q29tbW9uKHtuYW1lOmUsdGhlbWU6dGhpcy50aGVtZSxwYXJhbXM6dCxkZWZhdWx0czp0aGlzLmRlZmF1bHRzLHNldDp7bGF5ZXJOYW1lczp0aGlzLnNldExheWVyTmFtZXMuYmluZCh0aGlzKX19KX0sZ2V0Q29tcG9uZW50KGU9XCJcIix0KXtsZXQgcz17bmFtZTplLHRoZW1lOnRoaXMudGhlbWUscGFyYW1zOnQsZGVmYXVsdHM6dGhpcy5kZWZhdWx0cyxzZXQ6e2xheWVyTmFtZXM6dGhpcy5zZXRMYXllck5hbWVzLmJpbmQodGhpcyl9fTtyZXR1cm4gJC5nZXRQcmVzZXRDKHMpfSxnZXREaXJlY3RpdmUoZT1cIlwiLHQpe2xldCBzPXtuYW1lOmUsdGhlbWU6dGhpcy50aGVtZSxwYXJhbXM6dCxkZWZhdWx0czp0aGlzLmRlZmF1bHRzLHNldDp7bGF5ZXJOYW1lczp0aGlzLnNldExheWVyTmFtZXMuYmluZCh0aGlzKX19O3JldHVybiAkLmdldFByZXNldEQocyl9LGdldEN1c3RvbVByZXNldChlPVwiXCIsdCxzLHIpe2xldCBvPXtuYW1lOmUscHJlc2V0OnQsb3B0aW9uczp0aGlzLm9wdGlvbnMsc2VsZWN0b3I6cyxwYXJhbXM6cixkZWZhdWx0czp0aGlzLmRlZmF1bHRzLHNldDp7bGF5ZXJOYW1lczp0aGlzLnNldExheWVyTmFtZXMuYmluZCh0aGlzKX0saXNTY29wZWRUb2tlblBhdGhzOiEwfTtyZXR1cm4gJC5nZXRQcmVzZXQobyl9LGdldExheWVyT3JkZXJDU1MoZT1cIlwiKXtyZXR1cm4gJC5nZXRMYXllck9yZGVyKGUsdGhpcy5vcHRpb25zLHtuYW1lczp0aGlzLmdldExheWVyTmFtZXMoKX0sdGhpcy5kZWZhdWx0cyl9LHRyYW5zZm9ybUNTUyhlPVwiXCIsdCxzPVwic3R5bGVcIixyKXtyZXR1cm4gJC50cmFuc2Zvcm1DU1MoZSx0LHIscyx0aGlzLm9wdGlvbnMse2xheWVyTmFtZXM6dGhpcy5zZXRMYXllck5hbWVzLmJpbmQodGhpcyl9LHRoaXMuZGVmYXVsdHMpfSxnZXRDb21tb25TdHlsZVNoZWV0KGU9XCJcIix0LHM9e30pe3JldHVybiAkLmdldENvbW1vblN0eWxlU2hlZXQoe25hbWU6ZSx0aGVtZTp0aGlzLnRoZW1lLHBhcmFtczp0LHByb3BzOnMsZGVmYXVsdHM6dGhpcy5kZWZhdWx0cyxzZXQ6e2xheWVyTmFtZXM6dGhpcy5zZXRMYXllck5hbWVzLmJpbmQodGhpcyl9fSl9LGdldFN0eWxlU2hlZXQoZSx0LHM9e30pe3JldHVybiAkLmdldFN0eWxlU2hlZXQoe25hbWU6ZSx0aGVtZTp0aGlzLnRoZW1lLHBhcmFtczp0LHByb3BzOnMsZGVmYXVsdHM6dGhpcy5kZWZhdWx0cyxzZXQ6e2xheWVyTmFtZXM6dGhpcy5zZXRMYXllck5hbWVzLmJpbmQodGhpcyl9fSl9LG9uU3R5bGVNb3VudGVkKGUpe3RoaXMuX2xvYWRpbmdTdHlsZXMuYWRkKGUpfSxvblN0eWxlVXBkYXRlZChlKXt0aGlzLl9sb2FkaW5nU3R5bGVzLmFkZChlKX0sb25TdHlsZUxvYWRlZChlLHtuYW1lOnR9KXt0aGlzLl9sb2FkaW5nU3R5bGVzLnNpemUmJih0aGlzLl9sb2FkaW5nU3R5bGVzLmRlbGV0ZSh0KSxSLmVtaXQoYHRoZW1lOiR7dH06bG9hZGAsZSksdGhpcy5fbG9hZGluZ1N0eWxlcy5zaXplfHxSLmVtaXQoXCJ0aGVtZTpsb2FkXCIpKX19O2Z1bmN0aW9uIERlKC4uLmUpe2xldCB0PWp0KFMuZ2V0UHJlc2V0KCksLi4uZSk7cmV0dXJuIFMuc2V0UHJlc2V0KHQpLHR9ZnVuY3Rpb24gTGUoZSl7cmV0dXJuIEEoKS5wcmltYXJ5UGFsZXR0ZShlIT1udWxsP2U6e30pLnVwZGF0ZSgpLnByZXNldH1mdW5jdGlvbiBBZShlKXtyZXR1cm4gQSgpLnN1cmZhY2VQYWxldHRlKGUhPW51bGw/ZTp7fSkudXBkYXRlKCkucHJlc2V0fWltcG9ydHtkZWVwTWVyZ2UgYXMgRXR9ZnJvbVwiQHByaW1ldWl4L3V0aWxzL29iamVjdFwiO2Z1bmN0aW9uIE1lKGUsLi4udCl7bGV0IHM9RXQoZSwuLi50KTtyZXR1cm4gUy5zZXRQcmVzZXQocyksc31mdW5jdGlvbiBCZShlKXtyZXR1cm4gQShlKS51cGRhdGUoe21lcmdlUHJlc2V0czohMSxtZXJnZU9wdGlvbnM6ITF9KX1pbXBvcnR7Y3JlYXRlU3R5bGVNYXJrdXAgYXMgd3QsaXNOb3RFbXB0eSBhcyBOdH1mcm9tXCJAcHJpbWV1aXgvdXRpbHNcIjt2YXIga2U9Y2xhc3N7Y29uc3RydWN0b3Ioe2F0dHJzOnR9PXt9KXt0aGlzLl9zdHlsZXM9bmV3IE1hcCx0aGlzLl9hdHRycz10fHx7fX1nZXQodCl7cmV0dXJuIHRoaXMuX3N0eWxlcy5nZXQodCl9aGFzKHQpe3JldHVybiB0aGlzLl9zdHlsZXMuaGFzKHQpfWRlbGV0ZSh0KXt0aGlzLl9zdHlsZXMuZGVsZXRlKHQpfWNsZWFyKCl7dGhpcy5fc3R5bGVzLmNsZWFyKCl9YWRkKHQscyl7aWYoTnQocykpe2xldCByPXtuYW1lOnQsY3NzOnMsYXR0cnM6dGhpcy5fYXR0cnMsbWFya3VwOnd0KHMsdGhpcy5fYXR0cnMpfTt0aGlzLl9zdHlsZXMuc2V0KHQsQyh5KHt9LHIpLHtlbGVtZW50OnRoaXMuY3JlYXRlU3R5bGVFbGVtZW50KHIpfSkpfX11cGRhdGUoKXt9Z2V0U3R5bGVzKCl7cmV0dXJuIHRoaXMuX3N0eWxlc31nZXRBbGxDU1MoKXtyZXR1cm5bLi4udGhpcy5fc3R5bGVzLnZhbHVlcygpXS5tYXAodD0+dC5jc3MpLmZpbHRlcih0PT4hIXQpfWdldEFsbE1hcmt1cCgpe3JldHVyblsuLi50aGlzLl9zdHlsZXMudmFsdWVzKCldLm1hcCh0PT50Lm1hcmt1cCkuZmlsdGVyKHQ9PiEhdCl9Z2V0QWxsRWxlbWVudHMoKXtyZXR1cm5bLi4udGhpcy5fc3R5bGVzLnZhbHVlcygpXS5tYXAodD0+dC5lbGVtZW50KX1jcmVhdGVTdHlsZUVsZW1lbnQodD17fSl7fX0sRHQ9a2U7ZXhwb3J0e3VzIGFzICRkdCxBIGFzICR0LHJlIGFzIENBTENfUkVHRVgsUCBhcyBFWFBSX1JFR0VYLER0IGFzIFN0eWxlU2hlZXQsUyBhcyBUaGVtZSxSIGFzIFRoZW1lU2VydmljZSwkIGFzIFRoZW1lVXRpbHMsbmUgYXMgVkFSX1JFR0VYLGdzIGFzIGNzcyx4ZSBhcyBkZWZpbmVQcmVzZXQsTiBhcyBkdCxwZSBhcyBkdHd0LHVlIGFzIGV2YWx1YXRlRHRFeHByZXNzaW9ucyxJdCBhcyBnZXRDb21wdXRlZFZhbHVlLGogYXMgZ2V0UnVsZSxjZSBhcyBnZXRWYXJpYWJsZU5hbWUsTCBhcyBnZXRWYXJpYWJsZVZhbHVlLGd0IGFzIGhhc09kZEJyYWNlcyx6dCBhcyBtZXJnZSxYIGFzIG1peCxUdCBhcyBwYWxldHRlLCRlIGFzIHNldFByb3BlcnR5LGRlIGFzIHNoYWRlLG1lIGFzIHRpbnQscHQgYXMgdG9Ob3JtYWxpemVQcmVmaXgsb2UgYXMgdG9Ob3JtYWxpemVWYXJpYWJsZSxLIGFzIHRvVG9rZW5LZXksR3QgYXMgdG9Vbml0LFBlIGFzIHRvVmFsdWUsZ2UgYXMgdG9WYXJpYWJsZXMsRGUgYXMgdXBkYXRlUHJlc2V0LExlIGFzIHVwZGF0ZVByaW1hcnlQYWxldHRlLEFlIGFzIHVwZGF0ZVN1cmZhY2VQYWxldHRlLE1lIGFzIHVzZVByZXNldCxCZSBhcyB1c2VUaGVtZX07XG4iLCJ2YXIgc3R5bGU9XCJcXG4gICAgKixcXG4gICAgOjpiZWZvcmUsXFxuICAgIDo6YWZ0ZXIge1xcbiAgICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcXG4gICAgfVxcblxcbiAgICAucC1jb21wb25lbnQge1xcbiAgICAgICAgZm9udC1mYW1pbHk6IGR0KCd0eXBvZ3JhcGh5LmZvbnQuZmFtaWx5Jyk7XFxuICAgICAgICBmb250LWZlYXR1cmUtc2V0dGluZ3M6IGluaGVyaXQ7XFxuICAgICAgICBsaW5lLWhlaWdodDogZHQoJ3R5cG9ncmFwaHkubGluZS5oZWlnaHQnKTtcXG4gICAgfVxcblxcbiAgICAucC1jb2xsYXBzaWJsZS1lbnRlci1hY3RpdmUge1xcbiAgICAgICAgYW5pbWF0aW9uOiBwLWFuaW1hdGUtY29sbGFwc2libGUtZXhwYW5kIDAuMnMgZWFzZS1vdXQ7XFxuICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xcbiAgICB9XFxuXFxuICAgIC5wLWNvbGxhcHNpYmxlLWxlYXZlLWFjdGl2ZSB7XFxuICAgICAgICBhbmltYXRpb246IHAtYW5pbWF0ZS1jb2xsYXBzaWJsZS1jb2xsYXBzZSAwLjJzIGVhc2Utb3V0O1xcbiAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcXG4gICAgfVxcblxcbiAgICBAa2V5ZnJhbWVzIHAtYW5pbWF0ZS1jb2xsYXBzaWJsZS1leHBhbmQge1xcbiAgICAgICAgZnJvbSB7XFxuICAgICAgICAgICAgZ3JpZC10ZW1wbGF0ZS1yb3dzOiAwZnI7XFxuICAgICAgICB9XFxuICAgICAgICB0byB7XFxuICAgICAgICAgICAgZ3JpZC10ZW1wbGF0ZS1yb3dzOiAxZnI7XFxuICAgICAgICB9XFxuICAgIH1cXG5cXG4gICAgQGtleWZyYW1lcyBwLWFuaW1hdGUtY29sbGFwc2libGUtY29sbGFwc2Uge1xcbiAgICAgICAgZnJvbSB7XFxuICAgICAgICAgICAgZ3JpZC10ZW1wbGF0ZS1yb3dzOiAxZnI7XFxuICAgICAgICB9XFxuICAgICAgICB0byB7XFxuICAgICAgICAgICAgZ3JpZC10ZW1wbGF0ZS1yb3dzOiAwZnI7XFxuICAgICAgICB9XFxuICAgIH1cXG5cXG4gICAgLnAtZGlzYWJsZWQsXFxuICAgIC5wLWRpc2FibGVkICoge1xcbiAgICAgICAgY3Vyc29yOiBkZWZhdWx0O1xcbiAgICAgICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XFxuICAgICAgICB1c2VyLXNlbGVjdDogbm9uZTtcXG4gICAgfVxcblxcbiAgICAucC1kaXNhYmxlZCxcXG4gICAgLnAtY29tcG9uZW50OmRpc2FibGVkIHtcXG4gICAgICAgIG9wYWNpdHk6IGR0KCdkaXNhYmxlZC5vcGFjaXR5Jyk7XFxuICAgIH1cXG5cXG4gICAgLnBpIHtcXG4gICAgICAgIGZvbnQtc2l6ZTogZHQoJ2ljb24uc2l6ZScpO1xcbiAgICB9XFxuXFxuICAgIC5wLWljb24ge1xcbiAgICAgICAgd2lkdGg6IHZhcigtLXB4LWljb24tc2l6ZSwgZHQoJ2ljb24uc2l6ZScpKTtcXG4gICAgICAgIGhlaWdodDogdmFyKC0tcHgtaWNvbi1zaXplLCBkdCgnaWNvbi5zaXplJykpO1xcbiAgICAgICAgZmxleC1zaHJpbms6IDA7XFxuICAgIH1cXG5cXG4gICAgLnAtaWNvbi1zcGluIHtcXG4gICAgICAgIC13ZWJraXQtYW5pbWF0aW9uOiBwLWljb24tc3BpbiAycyBpbmZpbml0ZSBsaW5lYXI7XFxuICAgICAgICBhbmltYXRpb246IHAtaWNvbi1zcGluIDJzIGluZmluaXRlIGxpbmVhcjtcXG4gICAgfVxcblxcbiAgICBALXdlYmtpdC1rZXlmcmFtZXMgcC1pY29uLXNwaW4ge1xcbiAgICAgICAgMCUge1xcbiAgICAgICAgICAgIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7XFxuICAgICAgICB9XFxuICAgICAgICAxMDAlIHtcXG4gICAgICAgICAgICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7XFxuICAgICAgICAgICAgdHJhbnNmb3JtOiByb3RhdGUoMzU5ZGVnKTtcXG4gICAgICAgIH1cXG4gICAgfVxcblxcbiAgICBAa2V5ZnJhbWVzIHAtaWNvbi1zcGluIHtcXG4gICAgICAgIDAlIHtcXG4gICAgICAgICAgICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDBkZWcpO1xcbiAgICAgICAgfVxcbiAgICAgICAgMTAwJSB7XFxuICAgICAgICAgICAgLXdlYmtpdC10cmFuc2Zvcm06IHJvdGF0ZSgzNTlkZWcpO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogcm90YXRlKDM1OWRlZyk7XFxuICAgICAgICB9XFxuICAgIH1cXG5cXG4gICAgLnAtb3ZlcmxheS1tYXNrIHtcXG4gICAgICAgIGJhY2tncm91bmQ6IHZhcigtLXB4LW1hc2stYmFja2dyb3VuZCwgZHQoJ21hc2suYmFja2dyb3VuZCcpKTtcXG4gICAgICAgIGNvbG9yOiBkdCgnbWFzay5jb2xvcicpO1xcbiAgICAgICAgcG9zaXRpb246IGZpeGVkO1xcbiAgICAgICAgdG9wOiAwO1xcbiAgICAgICAgbGVmdDogMDtcXG4gICAgICAgIHdpZHRoOiAxMDAlO1xcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xcbiAgICB9XFxuXFxuICAgIC5wLW92ZXJsYXktbWFzay1lbnRlci1hY3RpdmUge1xcbiAgICAgICAgYW5pbWF0aW9uOiBwLWFuaW1hdGUtb3ZlcmxheS1tYXNrLWVudGVyIGR0KCdtYXNrLnRyYW5zaXRpb24uZHVyYXRpb24nKSBmb3J3YXJkcztcXG4gICAgfVxcblxcbiAgICAucC1vdmVybGF5LW1hc2stbGVhdmUtYWN0aXZlIHtcXG4gICAgICAgIGFuaW1hdGlvbjogcC1hbmltYXRlLW92ZXJsYXktbWFzay1sZWF2ZSBkdCgnbWFzay50cmFuc2l0aW9uLmR1cmF0aW9uJykgZm9yd2FyZHM7XFxuICAgIH1cXG5cXG4gICAgQGtleWZyYW1lcyBwLWFuaW1hdGUtb3ZlcmxheS1tYXNrLWVudGVyIHtcXG4gICAgICAgIGZyb20ge1xcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xcbiAgICAgICAgfVxcbiAgICAgICAgdG8ge1xcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLXB4LW1hc2stYmFja2dyb3VuZCwgZHQoJ21hc2suYmFja2dyb3VuZCcpKTtcXG4gICAgICAgIH1cXG4gICAgfVxcbiAgICBAa2V5ZnJhbWVzIHAtYW5pbWF0ZS1vdmVybGF5LW1hc2stbGVhdmUge1xcbiAgICAgICAgZnJvbSB7XFxuICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0tcHgtbWFzay1iYWNrZ3JvdW5kLCBkdCgnbWFzay5iYWNrZ3JvdW5kJykpO1xcbiAgICAgICAgfVxcbiAgICAgICAgdG8ge1xcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xcbiAgICAgICAgfVxcbiAgICB9XFxuXFxuICAgIC5wLWFuY2hvcmVkLW92ZXJsYXktZW50ZXItYWN0aXZlIHtcXG4gICAgICAgIGFuaW1hdGlvbjogcC1hbmltYXRlLWFuY2hvcmVkLW92ZXJsYXktZW50ZXIgMzAwbXMgY3ViaWMtYmV6aWVyKC4xOSwxLC4yMiwxKTtcXG4gICAgfVxcblxcbiAgICAucC1hbmNob3JlZC1vdmVybGF5LWxlYXZlLWFjdGl2ZSB7XFxuICAgICAgICBhbmltYXRpb246IHAtYW5pbWF0ZS1hbmNob3JlZC1vdmVybGF5LWxlYXZlIDMwMG1zIGN1YmljLWJlemllciguMTksMSwuMjIsMSk7XFxuICAgIH1cXG5cXG4gICAgQGtleWZyYW1lcyBwLWFuaW1hdGUtYW5jaG9yZWQtb3ZlcmxheS1lbnRlciB7XFxuICAgICAgICBmcm9tIHtcXG4gICAgICAgICAgICBvcGFjaXR5OiAwO1xcbiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC45Myk7XFxuICAgICAgICB9XFxuICAgIH1cXG5cXG4gICAgQGtleWZyYW1lcyBwLWFuaW1hdGUtYW5jaG9yZWQtb3ZlcmxheS1sZWF2ZSB7XFxuICAgICAgICB0byB7XFxuICAgICAgICAgICAgb3BhY2l0eTogMDtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDAuOTMpO1xcbiAgICAgICAgfVxcbiAgICB9XFxuXCI7ZXhwb3J0e3N0eWxlfTsiLCJpbXBvcnQgeyBpc0NsaWVudCwgc2V0QXR0cmlidXRlcywgc2V0QXR0cmlidXRlLCBpc0V4aXN0IH0gZnJvbSAnQHByaW1ldWl4L3V0aWxzL2RvbSc7XG5pbXBvcnQgeyByZWYsIHJlYWRvbmx5LCB3YXRjaCwgZ2V0Q3VycmVudEluc3RhbmNlLCBvbk1vdW50ZWQsIG5leHRUaWNrIH0gZnJvbSAndnVlJztcblxuZnVuY3Rpb24gX3R5cGVvZihvKSB7IFwiQGJhYmVsL2hlbHBlcnMgLSB0eXBlb2ZcIjsgcmV0dXJuIF90eXBlb2YgPSBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIFN5bWJvbCAmJiBcInN5bWJvbFwiID09IHR5cGVvZiBTeW1ib2wuaXRlcmF0b3IgPyBmdW5jdGlvbiAobykgeyByZXR1cm4gdHlwZW9mIG87IH0gOiBmdW5jdGlvbiAobykgeyByZXR1cm4gbyAmJiBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIFN5bWJvbCAmJiBvLmNvbnN0cnVjdG9yID09PSBTeW1ib2wgJiYgbyAhPT0gU3ltYm9sLnByb3RvdHlwZSA/IFwic3ltYm9sXCIgOiB0eXBlb2YgbzsgfSwgX3R5cGVvZihvKTsgfVxuZnVuY3Rpb24gb3duS2V5cyhlLCByKSB7IHZhciB0ID0gT2JqZWN0LmtleXMoZSk7IGlmIChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKSB7IHZhciBvID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTsgciAmJiAobyA9IG8uZmlsdGVyKGZ1bmN0aW9uIChyKSB7IHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGUsIHIpLmVudW1lcmFibGU7IH0pKSwgdC5wdXNoLmFwcGx5KHQsIG8pOyB9IHJldHVybiB0OyB9XG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKGUpIHsgZm9yICh2YXIgciA9IDE7IHIgPCBhcmd1bWVudHMubGVuZ3RoOyByKyspIHsgdmFyIHQgPSBudWxsICE9IGFyZ3VtZW50c1tyXSA/IGFyZ3VtZW50c1tyXSA6IHt9OyByICUgMiA/IG93bktleXMoT2JqZWN0KHQpLCB0cnVlKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0W3JdKTsgfSkgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGUsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHQpKSA6IG93bktleXMoT2JqZWN0KHQpKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIHIpKTsgfSk7IH0gcmV0dXJuIGU7IH1cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0KSB7IHJldHVybiAociA9IF90b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHsgdmFsdWU6IHQsIGVudW1lcmFibGU6IHRydWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSwgd3JpdGFibGU6IHRydWUgfSkgOiBlW3JdID0gdCwgZTsgfVxuZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkgeyB2YXIgaSA9IF90b1ByaW1pdGl2ZSh0LCBcInN0cmluZ1wiKTsgcmV0dXJuIFwic3ltYm9sXCIgPT0gX3R5cGVvZihpKSA/IGkgOiBpICsgXCJcIjsgfVxuZnVuY3Rpb24gX3RvUHJpbWl0aXZlKHQsIHIpIHsgaWYgKFwib2JqZWN0XCIgIT0gX3R5cGVvZih0KSB8fCAhdCkgcmV0dXJuIHQ7IHZhciBlID0gdFtTeW1ib2wudG9QcmltaXRpdmVdOyBpZiAodm9pZCAwICE9PSBlKSB7IHZhciBpID0gZS5jYWxsKHQsIHIpOyBpZiAoXCJvYmplY3RcIiAhPSBfdHlwZW9mKGkpKSByZXR1cm4gaTsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuXCIpOyB9IHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7IH1cbmZ1bmN0aW9uIHRyeU9uTW91bnRlZChmbikge1xuICB2YXIgc3luYyA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDogdHJ1ZTtcbiAgaWYgKGdldEN1cnJlbnRJbnN0YW5jZSgpICYmIGdldEN1cnJlbnRJbnN0YW5jZSgpLmNvbXBvbmVudHMpIG9uTW91bnRlZChmbik7ZWxzZSBpZiAoc3luYykgZm4oKTtlbHNlIG5leHRUaWNrKGZuKTtcbn1cbnZhciBfaWQgPSAwO1xuZnVuY3Rpb24gdXNlU3R5bGUoY3NzKSB7XG4gIHZhciBvcHRpb25zID0gYXJndW1lbnRzLmxlbmd0aCA+IDEgJiYgYXJndW1lbnRzWzFdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMV0gOiB7fTtcbiAgdmFyIGlzTG9hZGVkID0gcmVmKGZhbHNlKTtcbiAgdmFyIGNzc1JlZiA9IHJlZihjc3MpO1xuICB2YXIgc3R5bGVSZWYgPSByZWYobnVsbCk7XG4gIHZhciBkZWZhdWx0RG9jdW1lbnQgPSBpc0NsaWVudCgpID8gd2luZG93LmRvY3VtZW50IDogdW5kZWZpbmVkO1xuICB2YXIgX29wdGlvbnMkZG9jdW1lbnQgPSBvcHRpb25zLmRvY3VtZW50LFxuICAgIGRvY3VtZW50ID0gX29wdGlvbnMkZG9jdW1lbnQgPT09IHZvaWQgMCA/IGRlZmF1bHREb2N1bWVudCA6IF9vcHRpb25zJGRvY3VtZW50LFxuICAgIF9vcHRpb25zJGltbWVkaWF0ZSA9IG9wdGlvbnMuaW1tZWRpYXRlLFxuICAgIGltbWVkaWF0ZSA9IF9vcHRpb25zJGltbWVkaWF0ZSA9PT0gdm9pZCAwID8gdHJ1ZSA6IF9vcHRpb25zJGltbWVkaWF0ZSxcbiAgICBfb3B0aW9ucyRtYW51YWwgPSBvcHRpb25zLm1hbnVhbCxcbiAgICBtYW51YWwgPSBfb3B0aW9ucyRtYW51YWwgPT09IHZvaWQgMCA/IGZhbHNlIDogX29wdGlvbnMkbWFudWFsLFxuICAgIF9vcHRpb25zJG5hbWUgPSBvcHRpb25zLm5hbWUsXG4gICAgbmFtZSA9IF9vcHRpb25zJG5hbWUgPT09IHZvaWQgMCA/IFwic3R5bGVfXCIuY29uY2F0KCsrX2lkKSA6IF9vcHRpb25zJG5hbWUsXG4gICAgX29wdGlvbnMkaWQgPSBvcHRpb25zLmlkLFxuICAgIGlkID0gX29wdGlvbnMkaWQgPT09IHZvaWQgMCA/IHVuZGVmaW5lZCA6IF9vcHRpb25zJGlkLFxuICAgIF9vcHRpb25zJG1lZGlhID0gb3B0aW9ucy5tZWRpYSxcbiAgICBtZWRpYSA9IF9vcHRpb25zJG1lZGlhID09PSB2b2lkIDAgPyB1bmRlZmluZWQgOiBfb3B0aW9ucyRtZWRpYSxcbiAgICBfb3B0aW9ucyRub25jZSA9IG9wdGlvbnMubm9uY2UsXG4gICAgbm9uY2UgPSBfb3B0aW9ucyRub25jZSA9PT0gdm9pZCAwID8gdW5kZWZpbmVkIDogX29wdGlvbnMkbm9uY2UsXG4gICAgX29wdGlvbnMkZmlyc3QgPSBvcHRpb25zLmZpcnN0LFxuICAgIGZpcnN0ID0gX29wdGlvbnMkZmlyc3QgPT09IHZvaWQgMCA/IGZhbHNlIDogX29wdGlvbnMkZmlyc3QsXG4gICAgX29wdGlvbnMkb25Nb3VudGVkID0gb3B0aW9ucy5vbk1vdW50ZWQsXG4gICAgb25TdHlsZU1vdW50ZWQgPSBfb3B0aW9ucyRvbk1vdW50ZWQgPT09IHZvaWQgMCA/IHVuZGVmaW5lZCA6IF9vcHRpb25zJG9uTW91bnRlZCxcbiAgICBfb3B0aW9ucyRvblVwZGF0ZWQgPSBvcHRpb25zLm9uVXBkYXRlZCxcbiAgICBvblN0eWxlVXBkYXRlZCA9IF9vcHRpb25zJG9uVXBkYXRlZCA9PT0gdm9pZCAwID8gdW5kZWZpbmVkIDogX29wdGlvbnMkb25VcGRhdGVkLFxuICAgIF9vcHRpb25zJG9uTG9hZCA9IG9wdGlvbnMub25Mb2FkLFxuICAgIG9uU3R5bGVMb2FkZWQgPSBfb3B0aW9ucyRvbkxvYWQgPT09IHZvaWQgMCA/IHVuZGVmaW5lZCA6IF9vcHRpb25zJG9uTG9hZCxcbiAgICBfb3B0aW9ucyRwcm9wcyA9IG9wdGlvbnMucHJvcHMsXG4gICAgcHJvcHMgPSBfb3B0aW9ucyRwcm9wcyA9PT0gdm9pZCAwID8ge30gOiBfb3B0aW9ucyRwcm9wcztcbiAgdmFyIHN0b3AgPSBmdW5jdGlvbiBzdG9wKCkge307XG5cbiAgLyogQHRvZG86IEltcHJvdmUgX29wdGlvbnMgcGFyYW1zICovXG4gIHZhciBsb2FkID0gZnVuY3Rpb24gbG9hZChfY3NzKSB7XG4gICAgdmFyIF9wcm9wcyA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDoge307XG4gICAgaWYgKCFkb2N1bWVudCkgcmV0dXJuO1xuICAgIHZhciBfc3R5bGVQcm9wcyA9IF9vYmplY3RTcHJlYWQoX29iamVjdFNwcmVhZCh7fSwgcHJvcHMpLCBfcHJvcHMpO1xuICAgIHZhciBfbmFtZSA9IF9zdHlsZVByb3BzLm5hbWUgfHwgbmFtZSxcbiAgICAgIF9pZCA9IF9zdHlsZVByb3BzLmlkIHx8IGlkLFxuICAgICAgX25vbmNlID0gX3N0eWxlUHJvcHMubm9uY2UgfHwgbm9uY2U7XG4gICAgc3R5bGVSZWYudmFsdWUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwic3R5bGVbZGF0YS1wcmltZXZ1ZS1zdHlsZS1pZD1cXFwiXCIuY29uY2F0KF9uYW1lLCBcIlxcXCJdXCIpKSB8fCBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChfaWQpIHx8IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJyk7XG4gICAgaWYgKCFzdHlsZVJlZi52YWx1ZS5pc0Nvbm5lY3RlZCkge1xuICAgICAgY3NzUmVmLnZhbHVlID0gX2NzcyB8fCBjc3M7XG4gICAgICBzZXRBdHRyaWJ1dGVzKHN0eWxlUmVmLnZhbHVlLCB7XG4gICAgICAgIHR5cGU6ICd0ZXh0L2NzcycsXG4gICAgICAgIGlkOiBfaWQsXG4gICAgICAgIG1lZGlhOiBtZWRpYSxcbiAgICAgICAgbm9uY2U6IF9ub25jZVxuICAgICAgfSk7XG4gICAgICBmaXJzdCA/IGRvY3VtZW50LmhlYWQucHJlcGVuZChzdHlsZVJlZi52YWx1ZSkgOiBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKHN0eWxlUmVmLnZhbHVlKTtcbiAgICAgIHNldEF0dHJpYnV0ZShzdHlsZVJlZi52YWx1ZSwgJ2RhdGEtcHJpbWV2dWUtc3R5bGUtaWQnLCBfbmFtZSk7XG4gICAgICBzZXRBdHRyaWJ1dGVzKHN0eWxlUmVmLnZhbHVlLCBfc3R5bGVQcm9wcyk7XG4gICAgICBzdHlsZVJlZi52YWx1ZS5vbmxvYWQgPSBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgcmV0dXJuIG9uU3R5bGVMb2FkZWQgPT09IG51bGwgfHwgb25TdHlsZUxvYWRlZCA9PT0gdm9pZCAwID8gdm9pZCAwIDogb25TdHlsZUxvYWRlZChldmVudCwge1xuICAgICAgICAgIG5hbWU6IF9uYW1lXG4gICAgICAgIH0pO1xuICAgICAgfTtcbiAgICAgIG9uU3R5bGVNb3VudGVkID09PSBudWxsIHx8IG9uU3R5bGVNb3VudGVkID09PSB2b2lkIDAgfHwgb25TdHlsZU1vdW50ZWQoX25hbWUpO1xuICAgIH1cbiAgICBpZiAoaXNMb2FkZWQudmFsdWUpIHJldHVybjtcbiAgICBzdG9wID0gd2F0Y2goY3NzUmVmLCBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICAgIHN0eWxlUmVmLnZhbHVlLnRleHRDb250ZW50ID0gdmFsdWU7XG4gICAgICBvblN0eWxlVXBkYXRlZCA9PT0gbnVsbCB8fCBvblN0eWxlVXBkYXRlZCA9PT0gdm9pZCAwIHx8IG9uU3R5bGVVcGRhdGVkKF9uYW1lKTtcbiAgICB9LCB7XG4gICAgICBpbW1lZGlhdGU6IHRydWVcbiAgICB9KTtcbiAgICBpc0xvYWRlZC52YWx1ZSA9IHRydWU7XG4gIH07XG4gIHZhciB1bmxvYWQgPSBmdW5jdGlvbiB1bmxvYWQoKSB7XG4gICAgaWYgKCFkb2N1bWVudCB8fCAhaXNMb2FkZWQudmFsdWUpIHJldHVybjtcbiAgICBzdG9wKCk7XG4gICAgaXNFeGlzdChzdHlsZVJlZi52YWx1ZSkgJiYgZG9jdW1lbnQuaGVhZC5yZW1vdmVDaGlsZChzdHlsZVJlZi52YWx1ZSk7XG4gICAgaXNMb2FkZWQudmFsdWUgPSBmYWxzZTtcbiAgICBzdHlsZVJlZi52YWx1ZSA9IG51bGw7XG4gIH07XG4gIGlmIChpbW1lZGlhdGUgJiYgIW1hbnVhbCkgdHJ5T25Nb3VudGVkKGxvYWQpO1xuXG4gIC8qaWYgKCFtYW51YWwpXG4gICAgdHJ5T25TY29wZURpc3Bvc2UodW5sb2FkKSovXG5cbiAgcmV0dXJuIHtcbiAgICBpZDogaWQsXG4gICAgbmFtZTogbmFtZSxcbiAgICBlbDogc3R5bGVSZWYsXG4gICAgY3NzOiBjc3NSZWYsXG4gICAgdW5sb2FkOiB1bmxvYWQsXG4gICAgbG9hZDogbG9hZCxcbiAgICBpc0xvYWRlZDogcmVhZG9ubHkoaXNMb2FkZWQpXG4gIH07XG59XG5cbmV4cG9ydCB7IHVzZVN0eWxlIH07XG4iLCJpbXBvcnQgeyBUaGVtZSwgY3NzIGFzIGNzcyQxLCBkdCB9IGZyb20gJ0BwcmltZXVpeC9zdHlsZWQnO1xuaW1wb3J0IHsgc3R5bGUgfSBmcm9tICdAcHJpbWV1aXgvc3R5bGVzL2Jhc2UnO1xuaW1wb3J0IHsgcmVzb2x2ZSwgbWluaWZ5Q1NTLCBpc05vdEVtcHR5IH0gZnJvbSAnQHByaW1ldWl4L3V0aWxzL29iamVjdCc7XG5pbXBvcnQgeyB1c2VTdHlsZSB9IGZyb20gJ0BwcmltZXZ1ZS9jb3JlL3VzZXN0eWxlJztcblxuZnVuY3Rpb24gX3R5cGVvZihvKSB7IFwiQGJhYmVsL2hlbHBlcnMgLSB0eXBlb2ZcIjsgcmV0dXJuIF90eXBlb2YgPSBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIFN5bWJvbCAmJiBcInN5bWJvbFwiID09IHR5cGVvZiBTeW1ib2wuaXRlcmF0b3IgPyBmdW5jdGlvbiAobykgeyByZXR1cm4gdHlwZW9mIG87IH0gOiBmdW5jdGlvbiAobykgeyByZXR1cm4gbyAmJiBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIFN5bWJvbCAmJiBvLmNvbnN0cnVjdG9yID09PSBTeW1ib2wgJiYgbyAhPT0gU3ltYm9sLnByb3RvdHlwZSA/IFwic3ltYm9sXCIgOiB0eXBlb2YgbzsgfSwgX3R5cGVvZihvKTsgfVxudmFyIF90ZW1wbGF0ZU9iamVjdCwgX3RlbXBsYXRlT2JqZWN0MiwgX3RlbXBsYXRlT2JqZWN0MywgX3RlbXBsYXRlT2JqZWN0NDtcbmZ1bmN0aW9uIF9zbGljZWRUb0FycmF5KHIsIGUpIHsgcmV0dXJuIF9hcnJheVdpdGhIb2xlcyhyKSB8fCBfaXRlcmFibGVUb0FycmF5TGltaXQociwgZSkgfHwgX3Vuc3VwcG9ydGVkSXRlcmFibGVUb0FycmF5KHIsIGUpIHx8IF9ub25JdGVyYWJsZVJlc3QoKTsgfVxuZnVuY3Rpb24gX25vbkl0ZXJhYmxlUmVzdCgpIHsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkludmFsaWQgYXR0ZW1wdCB0byBkZXN0cnVjdHVyZSBub24taXRlcmFibGUgaW5zdGFuY2UuXFxuSW4gb3JkZXIgdG8gYmUgaXRlcmFibGUsIG5vbi1hcnJheSBvYmplY3RzIG11c3QgaGF2ZSBhIFtTeW1ib2wuaXRlcmF0b3JdKCkgbWV0aG9kLlwiKTsgfVxuZnVuY3Rpb24gX3Vuc3VwcG9ydGVkSXRlcmFibGVUb0FycmF5KHIsIGEpIHsgaWYgKHIpIHsgaWYgKFwic3RyaW5nXCIgPT0gdHlwZW9mIHIpIHJldHVybiBfYXJyYXlMaWtlVG9BcnJheShyLCBhKTsgdmFyIHQgPSB7fS50b1N0cmluZy5jYWxsKHIpLnNsaWNlKDgsIC0xKTsgcmV0dXJuIFwiT2JqZWN0XCIgPT09IHQgJiYgci5jb25zdHJ1Y3RvciAmJiAodCA9IHIuY29uc3RydWN0b3IubmFtZSksIFwiTWFwXCIgPT09IHQgfHwgXCJTZXRcIiA9PT0gdCA/IEFycmF5LmZyb20ocikgOiBcIkFyZ3VtZW50c1wiID09PSB0IHx8IC9eKD86VWl8SSludCg/Ojh8MTZ8MzIpKD86Q2xhbXBlZCk/QXJyYXkkLy50ZXN0KHQpID8gX2FycmF5TGlrZVRvQXJyYXkociwgYSkgOiB2b2lkIDA7IH0gfVxuZnVuY3Rpb24gX2FycmF5TGlrZVRvQXJyYXkociwgYSkgeyAobnVsbCA9PSBhIHx8IGEgPiByLmxlbmd0aCkgJiYgKGEgPSByLmxlbmd0aCk7IGZvciAodmFyIGUgPSAwLCBuID0gQXJyYXkoYSk7IGUgPCBhOyBlKyspIG5bZV0gPSByW2VdOyByZXR1cm4gbjsgfVxuZnVuY3Rpb24gX2l0ZXJhYmxlVG9BcnJheUxpbWl0KHIsIGwpIHsgdmFyIHQgPSBudWxsID09IHIgPyBudWxsIDogXCJ1bmRlZmluZWRcIiAhPSB0eXBlb2YgU3ltYm9sICYmIHJbU3ltYm9sLml0ZXJhdG9yXSB8fCByW1wiQEBpdGVyYXRvclwiXTsgaWYgKG51bGwgIT0gdCkgeyB2YXIgZSwgbiwgaSwgdSwgYSA9IFtdLCBmID0gdHJ1ZSwgbyA9IGZhbHNlOyB0cnkgeyBpZiAoaSA9ICh0ID0gdC5jYWxsKHIpKS5uZXh0LCAwID09PSBsKSA7IGVsc2UgZm9yICg7ICEoZiA9IChlID0gaS5jYWxsKHQpKS5kb25lKSAmJiAoYS5wdXNoKGUudmFsdWUpLCBhLmxlbmd0aCAhPT0gbCk7IGYgPSAhMCk7IH0gY2F0Y2ggKHIpIHsgbyA9IHRydWUsIG4gPSByOyB9IGZpbmFsbHkgeyB0cnkgeyBpZiAoIWYgJiYgbnVsbCAhPSB0W1wicmV0dXJuXCJdICYmICh1ID0gdFtcInJldHVyblwiXSgpLCBPYmplY3QodSkgIT09IHUpKSByZXR1cm47IH0gZmluYWxseSB7IGlmIChvKSB0aHJvdyBuOyB9IH0gcmV0dXJuIGE7IH0gfVxuZnVuY3Rpb24gX2FycmF5V2l0aEhvbGVzKHIpIHsgaWYgKEFycmF5LmlzQXJyYXkocikpIHJldHVybiByOyB9XG5mdW5jdGlvbiBvd25LZXlzKGUsIHIpIHsgdmFyIHQgPSBPYmplY3Qua2V5cyhlKTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHsgdmFyIG8gPSBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKGUpOyByICYmIChvID0gby5maWx0ZXIoZnVuY3Rpb24gKHIpIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoZSwgcikuZW51bWVyYWJsZTsgfSkpLCB0LnB1c2guYXBwbHkodCwgbyk7IH0gcmV0dXJuIHQ7IH1cbmZ1bmN0aW9uIF9vYmplY3RTcHJlYWQoZSkgeyBmb3IgKHZhciByID0gMTsgciA8IGFyZ3VtZW50cy5sZW5ndGg7IHIrKykgeyB2YXIgdCA9IG51bGwgIT0gYXJndW1lbnRzW3JdID8gYXJndW1lbnRzW3JdIDoge307IHIgJSAyID8gb3duS2V5cyhPYmplY3QodCksIHRydWUpLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgX2RlZmluZVByb3BlcnR5KGUsIHIsIHRbcl0pOyB9KSA6IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzID8gT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoZSwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnModCkpIDogb3duS2V5cyhPYmplY3QodCkpLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodCwgcikpOyB9KTsgfSByZXR1cm4gZTsgfVxuZnVuY3Rpb24gX2RlZmluZVByb3BlcnR5KGUsIHIsIHQpIHsgcmV0dXJuIChyID0gX3RvUHJvcGVydHlLZXkocikpIGluIGUgPyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZSwgciwgeyB2YWx1ZTogdCwgZW51bWVyYWJsZTogdHJ1ZSwgY29uZmlndXJhYmxlOiB0cnVlLCB3cml0YWJsZTogdHJ1ZSB9KSA6IGVbcl0gPSB0LCBlOyB9XG5mdW5jdGlvbiBfdG9Qcm9wZXJ0eUtleSh0KSB7IHZhciBpID0gX3RvUHJpbWl0aXZlKHQsIFwic3RyaW5nXCIpOyByZXR1cm4gXCJzeW1ib2xcIiA9PSBfdHlwZW9mKGkpID8gaSA6IGkgKyBcIlwiOyB9XG5mdW5jdGlvbiBfdG9QcmltaXRpdmUodCwgcikgeyBpZiAoXCJvYmplY3RcIiAhPSBfdHlwZW9mKHQpIHx8ICF0KSByZXR1cm4gdDsgdmFyIGUgPSB0W1N5bWJvbC50b1ByaW1pdGl2ZV07IGlmICh2b2lkIDAgIT09IGUpIHsgdmFyIGkgPSBlLmNhbGwodCwgcik7IGlmIChcIm9iamVjdFwiICE9IF90eXBlb2YoaSkpIHJldHVybiBpOyB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQEB0b1ByaW1pdGl2ZSBtdXN0IHJldHVybiBhIHByaW1pdGl2ZSB2YWx1ZS5cIik7IH0gcmV0dXJuIChcInN0cmluZ1wiID09PSByID8gU3RyaW5nIDogTnVtYmVyKSh0KTsgfVxuZnVuY3Rpb24gX3RhZ2dlZFRlbXBsYXRlTGl0ZXJhbChlLCB0KSB7IHJldHVybiB0IHx8ICh0ID0gZS5zbGljZSgwKSksIE9iamVjdC5mcmVlemUoT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoZSwgeyByYXc6IHsgdmFsdWU6IE9iamVjdC5mcmVlemUodCkgfSB9KSk7IH1cbnZhciBjc3MgPSBmdW5jdGlvbiBjc3MoX3JlZikge1xuICB2YXIgZHQgPSBfcmVmLmR0O1xuICByZXR1cm4gXCJcXG4ucC1oaWRkZW4tYWNjZXNzaWJsZSB7XFxuICAgIGJvcmRlcjogMDtcXG4gICAgY2xpcDogcmVjdCgwIDAgMCAwKTtcXG4gICAgaGVpZ2h0OiAxcHg7XFxuICAgIG1hcmdpbjogLTFweDtcXG4gICAgb3BhY2l0eTogMDtcXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcXG4gICAgcGFkZGluZzogMDtcXG4gICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XFxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcXG4gICAgd2lkdGg6IDFweDtcXG59XFxuXFxuLnAtb3ZlcmZsb3ctaGlkZGVuIHtcXG4gICAgb3ZlcmZsb3c6IGhpZGRlbjtcXG4gICAgcGFkZGluZy1yaWdodDogXCIuY29uY2F0KGR0KCdzY3JvbGxiYXIud2lkdGgnKSwgXCI7XFxufVxcblwiKTtcbn07XG52YXIgY2xhc3NlcyA9IHt9O1xudmFyIGlubGluZVN0eWxlcyA9IHt9O1xudmFyIEJhc2VTdHlsZSA9IHtcbiAgbmFtZTogJ2Jhc2UnLFxuICBjc3M6IGNzcyxcbiAgc3R5bGU6IHN0eWxlLFxuICBjbGFzc2VzOiBjbGFzc2VzLFxuICBpbmxpbmVTdHlsZXM6IGlubGluZVN0eWxlcyxcbiAgbG9hZDogZnVuY3Rpb24gbG9hZChzdHlsZSkge1xuICAgIHZhciBvcHRpb25zID0gYXJndW1lbnRzLmxlbmd0aCA+IDEgJiYgYXJndW1lbnRzWzFdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMV0gOiB7fTtcbiAgICB2YXIgdHJhbnNmb3JtID0gYXJndW1lbnRzLmxlbmd0aCA+IDIgJiYgYXJndW1lbnRzWzJdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMl0gOiBmdW5jdGlvbiAoY3MpIHtcbiAgICAgIHJldHVybiBjcztcbiAgICB9O1xuICAgIHZhciBjb21wdXRlZFN0eWxlID0gdHJhbnNmb3JtKGNzcyQxKF90ZW1wbGF0ZU9iamVjdCB8fCAoX3RlbXBsYXRlT2JqZWN0ID0gX3RhZ2dlZFRlbXBsYXRlTGl0ZXJhbChbXCJcIiwgXCJcIl0pKSwgc3R5bGUpKTtcbiAgICByZXR1cm4gaXNOb3RFbXB0eShjb21wdXRlZFN0eWxlKSA/IHVzZVN0eWxlKG1pbmlmeUNTUyhjb21wdXRlZFN0eWxlKSwgX29iamVjdFNwcmVhZCh7XG4gICAgICBuYW1lOiB0aGlzLm5hbWVcbiAgICB9LCBvcHRpb25zKSkgOiB7fTtcbiAgfSxcbiAgbG9hZENTUzogZnVuY3Rpb24gbG9hZENTUygpIHtcbiAgICB2YXIgb3B0aW9ucyA9IGFyZ3VtZW50cy5sZW5ndGggPiAwICYmIGFyZ3VtZW50c1swXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzBdIDoge307XG4gICAgcmV0dXJuIHRoaXMubG9hZCh0aGlzLmNzcywgb3B0aW9ucyk7XG4gIH0sXG4gIGxvYWRTdHlsZTogZnVuY3Rpb24gbG9hZFN0eWxlKCkge1xuICAgIHZhciBfdGhpcyA9IHRoaXM7XG4gICAgdmFyIG9wdGlvbnMgPSBhcmd1bWVudHMubGVuZ3RoID4gMCAmJiBhcmd1bWVudHNbMF0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1swXSA6IHt9O1xuICAgIHZhciBzdHlsZSA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDogJyc7XG4gICAgcmV0dXJuIHRoaXMubG9hZCh0aGlzLnN0eWxlLCBvcHRpb25zLCBmdW5jdGlvbiAoKSB7XG4gICAgICB2YXIgY29tcHV0ZWRTdHlsZSA9IGFyZ3VtZW50cy5sZW5ndGggPiAwICYmIGFyZ3VtZW50c1swXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzBdIDogJyc7XG4gICAgICByZXR1cm4gVGhlbWUudHJhbnNmb3JtQ1NTKG9wdGlvbnMubmFtZSB8fCBfdGhpcy5uYW1lLCBcIlwiLmNvbmNhdChjb21wdXRlZFN0eWxlKS5jb25jYXQoY3NzJDEoX3RlbXBsYXRlT2JqZWN0MiB8fCAoX3RlbXBsYXRlT2JqZWN0MiA9IF90YWdnZWRUZW1wbGF0ZUxpdGVyYWwoW1wiXCIsIFwiXCJdKSksIHN0eWxlKSkpO1xuICAgIH0pO1xuICB9LFxuICBnZXRDb21tb25UaGVtZTogZnVuY3Rpb24gZ2V0Q29tbW9uVGhlbWUocGFyYW1zKSB7XG4gICAgcmV0dXJuIFRoZW1lLmdldENvbW1vbih0aGlzLm5hbWUsIHBhcmFtcyk7XG4gIH0sXG4gIGdldENvbXBvbmVudFRoZW1lOiBmdW5jdGlvbiBnZXRDb21wb25lbnRUaGVtZShwYXJhbXMpIHtcbiAgICByZXR1cm4gVGhlbWUuZ2V0Q29tcG9uZW50KHRoaXMubmFtZSwgcGFyYW1zKTtcbiAgfSxcbiAgZ2V0RGlyZWN0aXZlVGhlbWU6IGZ1bmN0aW9uIGdldERpcmVjdGl2ZVRoZW1lKHBhcmFtcykge1xuICAgIHJldHVybiBUaGVtZS5nZXREaXJlY3RpdmUodGhpcy5uYW1lLCBwYXJhbXMpO1xuICB9LFxuICBnZXRQcmVzZXRUaGVtZTogZnVuY3Rpb24gZ2V0UHJlc2V0VGhlbWUocHJlc2V0LCBzZWxlY3RvciwgcGFyYW1zKSB7XG4gICAgcmV0dXJuIFRoZW1lLmdldEN1c3RvbVByZXNldCh0aGlzLm5hbWUsIHByZXNldCwgc2VsZWN0b3IsIHBhcmFtcyk7XG4gIH0sXG4gIGdldExheWVyT3JkZXJUaGVtZUNTUzogZnVuY3Rpb24gZ2V0TGF5ZXJPcmRlclRoZW1lQ1NTKCkge1xuICAgIHJldHVybiBUaGVtZS5nZXRMYXllck9yZGVyQ1NTKHRoaXMubmFtZSk7XG4gIH0sXG4gIGdldFN0eWxlU2hlZXQ6IGZ1bmN0aW9uIGdldFN0eWxlU2hlZXQoKSB7XG4gICAgdmFyIGV4dGVuZGVkQ1NTID0gYXJndW1lbnRzLmxlbmd0aCA+IDAgJiYgYXJndW1lbnRzWzBdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMF0gOiAnJztcbiAgICB2YXIgcHJvcHMgPSBhcmd1bWVudHMubGVuZ3RoID4gMSAmJiBhcmd1bWVudHNbMV0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1sxXSA6IHt9O1xuICAgIGlmICh0aGlzLmNzcykge1xuICAgICAgdmFyIF9jc3MgPSByZXNvbHZlKHRoaXMuY3NzLCB7XG4gICAgICAgIGR0OiBkdFxuICAgICAgfSkgfHwgJyc7XG4gICAgICB2YXIgX3N0eWxlID0gbWluaWZ5Q1NTKGNzcyQxKF90ZW1wbGF0ZU9iamVjdDMgfHwgKF90ZW1wbGF0ZU9iamVjdDMgPSBfdGFnZ2VkVGVtcGxhdGVMaXRlcmFsKFtcIlwiLCBcIlwiLCBcIlwiXSkpLCBfY3NzLCBleHRlbmRlZENTUykpO1xuICAgICAgdmFyIF9wcm9wcyA9IE9iamVjdC5lbnRyaWVzKHByb3BzKS5yZWR1Y2UoZnVuY3Rpb24gKGFjYywgX3JlZjIpIHtcbiAgICAgICAgdmFyIF9yZWYzID0gX3NsaWNlZFRvQXJyYXkoX3JlZjIsIDIpLFxuICAgICAgICAgIGsgPSBfcmVmM1swXSxcbiAgICAgICAgICB2ID0gX3JlZjNbMV07XG4gICAgICAgIHJldHVybiBhY2MucHVzaChcIlwiLmNvbmNhdChrLCBcIj1cXFwiXCIpLmNvbmNhdCh2LCBcIlxcXCJcIikpICYmIGFjYztcbiAgICAgIH0sIFtdKS5qb2luKCcgJyk7XG4gICAgICByZXR1cm4gaXNOb3RFbXB0eShfc3R5bGUpID8gXCI8c3R5bGUgdHlwZT1cXFwidGV4dC9jc3NcXFwiIGRhdGEtcHJpbWV2dWUtc3R5bGUtaWQ9XFxcIlwiLmNvbmNhdCh0aGlzLm5hbWUsIFwiXFxcIiBcIikuY29uY2F0KF9wcm9wcywgXCI+XCIpLmNvbmNhdChfc3R5bGUsIFwiPC9zdHlsZT5cIikgOiAnJztcbiAgICB9XG4gICAgcmV0dXJuICcnO1xuICB9LFxuICBnZXRDb21tb25UaGVtZVN0eWxlU2hlZXQ6IGZ1bmN0aW9uIGdldENvbW1vblRoZW1lU3R5bGVTaGVldChwYXJhbXMpIHtcbiAgICB2YXIgcHJvcHMgPSBhcmd1bWVudHMubGVuZ3RoID4gMSAmJiBhcmd1bWVudHNbMV0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1sxXSA6IHt9O1xuICAgIHJldHVybiBUaGVtZS5nZXRDb21tb25TdHlsZVNoZWV0KHRoaXMubmFtZSwgcGFyYW1zLCBwcm9wcyk7XG4gIH0sXG4gIGdldFRoZW1lU3R5bGVTaGVldDogZnVuY3Rpb24gZ2V0VGhlbWVTdHlsZVNoZWV0KHBhcmFtcykge1xuICAgIHZhciBwcm9wcyA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDoge307XG4gICAgdmFyIGNzcyA9IFtUaGVtZS5nZXRTdHlsZVNoZWV0KHRoaXMubmFtZSwgcGFyYW1zLCBwcm9wcyldO1xuICAgIGlmICh0aGlzLnN0eWxlKSB7XG4gICAgICB2YXIgbmFtZSA9IHRoaXMubmFtZSA9PT0gJ2Jhc2UnID8gJ2dsb2JhbC1zdHlsZScgOiBcIlwiLmNvbmNhdCh0aGlzLm5hbWUsIFwiLXN0eWxlXCIpO1xuICAgICAgdmFyIF9jc3MgPSBjc3MkMShfdGVtcGxhdGVPYmplY3Q0IHx8IChfdGVtcGxhdGVPYmplY3Q0ID0gX3RhZ2dlZFRlbXBsYXRlTGl0ZXJhbChbXCJcIiwgXCJcIl0pKSwgcmVzb2x2ZSh0aGlzLnN0eWxlLCB7XG4gICAgICAgIGR0OiBkdFxuICAgICAgfSkpO1xuICAgICAgdmFyIF9zdHlsZSA9IG1pbmlmeUNTUyhUaGVtZS50cmFuc2Zvcm1DU1MobmFtZSwgX2NzcykpO1xuICAgICAgdmFyIF9wcm9wcyA9IE9iamVjdC5lbnRyaWVzKHByb3BzKS5yZWR1Y2UoZnVuY3Rpb24gKGFjYywgX3JlZjQpIHtcbiAgICAgICAgdmFyIF9yZWY1ID0gX3NsaWNlZFRvQXJyYXkoX3JlZjQsIDIpLFxuICAgICAgICAgIGsgPSBfcmVmNVswXSxcbiAgICAgICAgICB2ID0gX3JlZjVbMV07XG4gICAgICAgIHJldHVybiBhY2MucHVzaChcIlwiLmNvbmNhdChrLCBcIj1cXFwiXCIpLmNvbmNhdCh2LCBcIlxcXCJcIikpICYmIGFjYztcbiAgICAgIH0sIFtdKS5qb2luKCcgJyk7XG4gICAgICBpc05vdEVtcHR5KF9zdHlsZSkgJiYgY3NzLnB1c2goXCI8c3R5bGUgdHlwZT1cXFwidGV4dC9jc3NcXFwiIGRhdGEtcHJpbWV2dWUtc3R5bGUtaWQ9XFxcIlwiLmNvbmNhdChuYW1lLCBcIlxcXCIgXCIpLmNvbmNhdChfcHJvcHMsIFwiPlwiKS5jb25jYXQoX3N0eWxlLCBcIjwvc3R5bGU+XCIpKTtcbiAgICB9XG4gICAgcmV0dXJuIGNzcy5qb2luKCcnKTtcbiAgfSxcbiAgZXh0ZW5kOiBmdW5jdGlvbiBleHRlbmQoaW5TdHlsZSkge1xuICAgIHJldHVybiBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe30sIHRoaXMpLCB7fSwge1xuICAgICAgY3NzOiB1bmRlZmluZWQsXG4gICAgICBzdHlsZTogdW5kZWZpbmVkXG4gICAgfSwgaW5TdHlsZSk7XG4gIH1cbn07XG5cbmV4cG9ydCB7IEJhc2VTdHlsZSBhcyBkZWZhdWx0IH07XG4iLCIvKipcbiAqIEluamVjdCBhIGZpeGVkLXBvc2l0aW9uZWQgYmFubmVyIGludG8gdGhlIGJvdHRvbS1yaWdodCBvZiB0aGUgcGFnZSB3aGVuIHRoZVxuICogUHJpbWVWdWUgbGljZW5zZSBjYW5ub3QgYmUgdmVyaWZpZWQuXG4gKlxuICogVGhlIGJhbm5lciBjb250ZW50IGlzIHJlbmRlcmVkIGluc2lkZSBhIGNsb3NlZC1tb2RlIHNoYWRvdyByb290IHNvIHBhZ2UtbGV2ZWxcbiAqIENTUyBjYW5ub3QgcmVhY2ggaW50byBpdC4gYGFsbDppbml0aWFsYCBvbiB0aGUgaG9zdCBlbGVtZW50IGJsb2NrcyBpbmhlcml0ZWRcbiAqIHN0eWxlcy4gVGhlIGhvc3QgY2FycmllcyBubyBzZW1hbnRpY2FsbHkgb2J2aW91cyBpZCwgc2xvd2luZyBkb3duIHRyaXZpYWxcbiAqIGhpZGUtYnktc2VsZWN0b3IgYXR0ZW1wdHMuXG4gKlxuICogSWRlbXBvdGVudCDigJQgZ3VhcmRlZCBieSB0aGUgaG9zdCBpZCwgc28gbXVsdGlwbGUgY2FsbCBzaXRlcyAodGhlIHBsdWdpbidzXG4gKiB2ZXJpZnkgcHJvbWlzZSByZXNvbHZpbmcsIEJhc2VDb21wb25lbnQgZGV0ZWN0aW5nIGEgbWlzc2luZyBwbHVnaW4gaW5zdGFsbClcbiAqIGNhbm5vdCBwcm9kdWNlIG1vcmUgdGhhbiBvbmUgYmFubmVyIHBlciBwYWdlLlxuICpcbiAqIFNTUi1zYWZlIOKAlCBzaG9ydC1jaXJjdWl0cyB3aGVuIGBkb2N1bWVudGAgaXMgdW5kZWZpbmVkLlxuICpcbiAqIE5vdGU6IGNsaWVudC1zaWRlIGxpY2Vuc2UgZW5mb3JjZW1lbnQgaXMgYW50aS1ob25lc3QtdXNlciBzaWduYWxpbmcsIG5vdFxuICogYW50aS1waXJhY3kuIFRoZSBjcnlwdG9ncmFwaGljIHNpZ25hdHVyZSAoRWQyNTUxOSkgaXMgd2hhdCBhY3R1YWxseSBwcmV2ZW50c1xuICogZm9yZ2luZyB2YWxpZCB0b2tlbnMuIFRoaXMgYmFubmVyIGp1c3QgbWFrZXMgdGhlIGxpY2Vuc2luZyBwcm9ibGVtIHZpc2libGVcbiAqIHRvIGEgbGVnaXRpbWF0ZSBjdXN0b21lciB3aG9zZSBrZXkgbmVlZHMgYXR0ZW50aW9uLlxuICovXG5mdW5jdGlvbiBzaG93SW52YWxpZExpY2Vuc2VCYW5uZXIoKSB7XG4gIGlmICh0eXBlb2YgZG9jdW1lbnQgPT09ICd1bmRlZmluZWQnKSByZXR1cm47XG4gIGlmIChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncC1saWNlbnNlLWhvc3QnKSkgcmV0dXJuO1xuICB2YXIgaG9zdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICBob3N0LmlkID0gJ3AtbGljZW5zZS1ob3N0JztcbiAgaG9zdC5zdHlsZS5jc3NUZXh0ID0gJ2FsbDppbml0aWFsO3Bvc2l0aW9uOmZpeGVkO2JvdHRvbToxNnB4O3JpZ2h0OjE2cHg7ei1pbmRleDoyMTQ3NDgzNjQ3O3BvaW50ZXItZXZlbnRzOm5vbmU7JztcbiAgdmFyIHNoYWRvdyA9IGhvc3QuYXR0YWNoU2hhZG93KHtcbiAgICBtb2RlOiAnY2xvc2VkJ1xuICB9KTtcbiAgc2hhZG93LmlubmVySFRNTCA9ICc8ZGl2IHJvbGU9XCJhbGVydFwiIHN0eWxlPVwicGFkZGluZzoxMHB4IDE0cHg7YmFja2dyb3VuZDojOTkxYjFiO2NvbG9yOiNmZmY7Zm9udDo2MDAgMTNweC8xLjIgc3lzdGVtLXVpLC1hcHBsZS1zeXN0ZW0sc2Fucy1zZXJpZjtib3JkZXItcmFkaXVzOjZweDtib3gtc2hhZG93OjAgNHB4IDEycHggcmdiYSgwLDAsMCwwLjIpO1wiPicgKyAnSW52YWxpZCBQcmltZVVJIExpY2Vuc2UnICsgJzwvZGl2Pic7XG4gIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoaG9zdCk7XG59XG5cbmV4cG9ydCB7IHNob3dJbnZhbGlkTGljZW5zZUJhbm5lciB9O1xuIl0sInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOF0sIm1hcHBpbmdzIjoiOztBQUFBLElBQUlBLE9BQUcsT0FBTztBQUFlLElBQUlDLE1BQUUsT0FBTztBQUFzQixJQUFJQyxPQUFHLE9BQU8sVUFBVTtBQUFlQyxJQUFBQSxPQUFHLE9BQU8sVUFBVTtBQUFxQixJQUFJLEtBQUcsR0FBRSxHQUFFLE1BQUksS0FBSyxJQUFFSCxLQUFHLEdBQUUsR0FBRTtDQUFDLFlBQVcsQ0FBQztDQUFFLGNBQWEsQ0FBQztDQUFFLFVBQVMsQ0FBQztDQUFFLE9BQU07QUFBQyxDQUFDLElBQUUsRUFBRSxLQUFHO0FBQUUsSUFBQSxLQUFHLEdBQUUsTUFBSTtDQUFDLEtBQUksSUFBSSxLQUFLLE1BQUksSUFBRSxDQUFDLElBQUcsS0FBRyxLQUFLLEdBQUUsQ0FBQyxLQUFHLEVBQUUsR0FBRSxHQUFFLEVBQUUsRUFBRTtDQUFFLElBQUdDLEtBQUUsS0FBSSxJQUFJLEtBQUtBLElBQUUsQ0FBQyxHQUFFLEtBQUcsS0FBSyxHQUFFLENBQUMsS0FBRyxFQUFFLEdBQUUsR0FBRSxFQUFFLEVBQUU7Q0FBRSxPQUFPO0FBQUM7QUFBRSxTQUFTRyxJQUFFLEdBQUU7Q0FBQyxPQUFPLEtBQUcsUUFBTSxNQUFJLE1BQUksTUFBTSxRQUFRLENBQUMsS0FBRyxFQUFFLFdBQVMsS0FBRyxFQUFFLGFBQWEsU0FBTyxPQUFPLEtBQUcsWUFBVSxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsV0FBUztBQUFDO0FBQWcwQyxTQUFTLEVBQUUsR0FBRTtDQUFDLE9BQU8sT0FBTyxLQUFHLGNBQVksVUFBUyxLQUFHLFdBQVU7QUFBQztBQUFDLFNBQVMsRUFBRSxHQUFFO0NBQUMsT0FBTSxDQUFDQSxJQUFFLENBQUM7QUFBQztBQUErWixTQUFTLEVBQUUsR0FBRSxJQUFFLENBQUMsR0FBRTtDQUFDLE9BQU8sYUFBYSxVQUFRLEVBQUUsZ0JBQWMsV0FBUyxLQUFHLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxXQUFTO0FBQUU7QUFBQyxJQUFJQyx1QkFBRyxJQUFJLElBQUk7Q0FBQztDQUFZO0NBQWM7QUFBVyxDQUFDO0FBQUUsU0FBU0MsSUFBRSxHQUFFLEdBQUUsR0FBRSxvQkFBRSxJQUFJLFFBQU0sR0FBRTtDQUFDLElBQUksSUFBRSxFQUFFLENBQUMsR0FBRSxDQUFDO0NBQUUsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLFdBQVMsS0FBRyxDQUFDLEVBQUUsSUFBSSxDQUFDLEtBQUcsRUFBRSxJQUFJLEdBQUUsQ0FBQztDQUFFLElBQUksSUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDO0NBQUUsT0FBTyxLQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUUsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVEsTUFBRztFQUFDLElBQUksR0FBRTtFQUFFLElBQUdELEtBQUcsSUFBSSxDQUFDLEdBQUU7RUFBTyxJQUFJLElBQUUsR0FBRSxJQUFFLEVBQUU7RUFBRyxFQUFFLENBQUMsS0FBRyxLQUFLLEtBQUcsRUFBRSxFQUFFLEVBQUUsSUFBRSxFQUFFLEtBQUcsRUFBRSxJQUFJLENBQUMsS0FBRyxJQUFFLEVBQUUsSUFBSSxDQUFDLE1BQUksT0FBSyxJQUFFQyxJQUFFLENBQUMsR0FBRSxHQUFFLEdBQUUsQ0FBQyxJQUFFQSxJQUFFLEVBQUUsSUFBRyxHQUFFLEdBQUUsQ0FBQyxJQUFFLEVBQUUsQ0FBQyxJQUFFLEVBQUUsTUFBSSxJQUFFLEVBQUUsSUFBSSxDQUFDLE1BQUksT0FBSyxJQUFFQSxJQUFFLENBQUMsR0FBRSxHQUFFLEdBQUUsQ0FBQyxJQUFFLEVBQUUsS0FBRztDQUFDLENBQUMsR0FBRSxLQUFHLEVBQUUsT0FBTyxDQUFDLEdBQUU7QUFBQztBQUFDLFNBQVMsRUFBRSxHQUFHLEdBQUU7Q0FBQyxPQUFPLEVBQUUsUUFBUSxHQUFFLE1BQUlBLElBQUUsR0FBRSxLQUFHLENBQUMsbUJBQUUsSUFBSSxRQUFNLENBQUMsR0FBRSxDQUFDLENBQUM7QUFBQztBQUF1YyxTQUFTQyxJQUFFLEdBQUUsR0FBRyxHQUFFO0NBQUMsT0FBTyxFQUFFLENBQUMsSUFBRSxFQUFFLEdBQUcsQ0FBQyxJQUFFO0FBQUM7QUFBQyxTQUFTLEVBQUUsR0FBRSxJQUFFLENBQUMsR0FBRTtDQUFDLE9BQU8sT0FBTyxLQUFHLGFBQVcsS0FBRyxNQUFJO0FBQUc7QUFBQyxTQUFTQyxJQUFFLEdBQUU7Q0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFFLEVBQUUsUUFBUSxVQUFTLEVBQUUsQ0FBQyxDQUFDLFlBQVksSUFBRTtBQUFDO0FBQUMsU0FBU0MsSUFBRSxHQUFFLElBQUUsSUFBRyxJQUFFLENBQUMsR0FBRTtDQUFDLElBQUksSUFBRUQsSUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsR0FBRSxJQUFFLEVBQUUsTUFBTTtDQUFFLElBQUcsR0FBRTtFQUFDLElBQUcsRUFBRSxDQUFDLEtBQUcsTUFBTSxRQUFRLENBQUMsR0FBOEMsT0FBT0MsSUFBRUYsSUFBRSxFQUFoRCxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBSyxNQUFHQyxJQUFFLENBQUMsTUFBSSxDQUFDLEtBQUcsS0FBbUIsQ0FBQyxHQUFFLEVBQUUsS0FBSyxHQUFHLEdBQUUsQ0FBQztFQUFFO0NBQU07Q0FBQyxPQUFPRCxJQUFFLEdBQUUsQ0FBQztBQUFDO0FBQStJLFNBQVNHLElBQUUsR0FBRSxJQUFFLENBQUMsR0FBRTtDQUFDLE9BQU8sTUFBTSxRQUFRLENBQUMsTUFBSSxLQUFHLEVBQUUsV0FBUztBQUFFO0FBQThGLFNBQVMsRUFBRSxHQUFFO0NBQUMsT0FBTyxFQUFFLENBQUMsS0FBRyxDQUFDLE1BQU0sQ0FBQztBQUFDO0FBQWtQLFNBQVNDLElBQUUsR0FBRSxHQUFFO0NBQUMsSUFBRyxHQUFFO0VBQUMsRUFBRSxZQUFVO0VBQUUsSUFBSSxJQUFFLEVBQUUsS0FBSyxDQUFDO0VBQUUsT0FBTyxFQUFFLFlBQVUsR0FBRTtDQUFDO0NBQUMsT0FBTSxDQUFDO0FBQUM7QUFBQyxTQUFTQyxJQUFFLEdBQUcsR0FBRTtDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUM7QUFBQztBQUFDLFNBQVNDLEtBQUcsR0FBRSxHQUFFO0NBQUMsSUFBSSxJQUFFO0NBQUUsT0FBSyxJQUFFLElBQUUsS0FBRyxLQUFHLEVBQUUsSUFBRSxJQUFFLE9BQUssT0FBTTtDQUFJLE9BQU8sSUFBRSxNQUFJO0FBQUM7QUFBQyxTQUFTQyxJQUFFLEdBQUU7Q0FBQyxPQUFPLEVBQUUsUUFBUSxjQUFhLEVBQUUsQ0FBQyxDQUFDLFFBQVEsVUFBUyxHQUFHLENBQUMsQ0FBQyxRQUFRLGNBQWEsSUFBSSxDQUFDLENBQUMsUUFBUSxZQUFXLElBQUksQ0FBQyxDQUFDLFFBQVEsT0FBTSxHQUFHLENBQUMsQ0FBQyxRQUFRLE9BQU0sR0FBRztBQUFDO0FBQUMsU0FBUyxFQUFFLEdBQUU7Q0FBQyxJQUFHLENBQUMsR0FBRSxPQUFPO0NBQUUsSUFBSSxJQUFFLElBQUcsSUFBRSxJQUFHLElBQUU7Q0FBRSxPQUFLLElBQUUsRUFBRSxTQUFRO0VBQUMsSUFBSSxJQUFFLEVBQUU7RUFBRyxJQUFHLE1BQUksT0FBSyxFQUFFLElBQUUsT0FBSyxLQUFJO0dBQUMsSUFBSSxJQUFFLEVBQUUsUUFBUSxNQUFLLElBQUUsQ0FBQztHQUFFLElBQUUsTUFBSSxLQUFHLEVBQUUsU0FBTyxJQUFFO0VBQUMsT0FBTSxJQUFHLE1BQUksUUFBSyxNQUFJLEtBQUk7R0FBQyxLQUFHQSxJQUFFLENBQUMsR0FBRSxJQUFFO0dBQUcsSUFBSSxJQUFFLElBQUU7R0FBRSxPQUFLLElBQUUsRUFBRSxXQUFTLEVBQUUsT0FBSyxLQUFHRCxLQUFHLEdBQUUsQ0FBQyxLQUFJO0dBQUksS0FBRyxFQUFFLE1BQU0sR0FBRSxLQUFLLElBQUksSUFBRSxHQUFFLEVBQUUsTUFBTSxDQUFDLEdBQUUsSUFBRSxJQUFFO0VBQUMsT0FBTSxLQUFHLEdBQUU7Q0FBRztDQUFDLFFBQU8sSUFBRUMsSUFBRSxDQUFDLEVBQUEsQ0FBRyxLQUFLO0FBQUM7QUFBQyxTQUFTQyxJQUFFLElBQUUsQ0FBQyxHQUFFLElBQUUsSUFBRztDQUFDLE9BQU8sT0FBTyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRSxDQUFDLEdBQUUsT0FBSztFQUFDLElBQUksSUFBRSxJQUFFLEdBQUcsRUFBRSxHQUFHLE1BQUk7RUFBRSxPQUFPLEVBQUUsQ0FBQyxJQUFFLElBQUUsRUFBRSxPQUFPQSxJQUFFLEdBQUUsQ0FBQyxDQUFDLElBQUUsRUFBRSxLQUFLLENBQUMsR0FBRTtDQUFDLEdBQUUsQ0FBQyxDQUFDO0FBQUM7QUFHeDRKLFNBQVMsR0FBRyxHQUFFO0NBQUMsT0FBTyxFQUFFLEdBQUUsQ0FBQyxDQUFDLElBQUUsRUFBRSxFQUFFLENBQUMsWUFBWSxJQUFFLEVBQUUsTUFBTSxDQUFDLElBQUU7QUFBQztBQUFDLFNBQVMsR0FBRyxHQUFFO0NBQUMsT0FBTyxFQUFFLENBQUMsSUFBRSxFQUFFLFFBQVEsUUFBTyxHQUFHLENBQUMsQ0FBQyxRQUFRLG1CQUFrQixPQUFPLENBQUMsQ0FBQyxZQUFZLElBQUU7QUFBQztBQUE4SyxTQUFTLEdBQUcsR0FBRTtDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUUsRUFBRSxRQUFRLFdBQVUsR0FBRSxNQUFJLE1BQUksSUFBRSxJQUFFLE1BQUksRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLFlBQVksSUFBRTtBQUFDOzs7QUNIemhCLFNBQVMsRUFBRSxHQUFFLEdBQUU7Q0FBQyxPQUFPLElBQUUsRUFBRSxZQUFVLEVBQUUsVUFBVSxTQUFTLENBQUMsSUFBRSxJQUFJLE9BQU8sVUFBUSxJQUFFLFNBQVEsSUFBSSxDQUFDLENBQUMsS0FBSyxFQUFFLFNBQVMsSUFBRSxDQUFDO0FBQUM7QUFBQyxTQUFTQyxJQUFFLEdBQUUsR0FBRTtDQUFDLElBQUcsS0FBRyxHQUFFO0VBQUMsSUFBSSxLQUFFLE1BQUc7R0FBQyxFQUFFLEdBQUUsQ0FBQyxNQUFJLEVBQUUsWUFBVSxFQUFFLFVBQVUsSUFBSSxDQUFDLElBQUUsRUFBRSxhQUFXLE1BQUk7RUFBRTtFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxTQUFRLE1BQUcsRUFBRSxNQUFNLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0NBQUM7QUFBQztBQUFDLFNBQVMsSUFBRztDQUFDLE9BQU8sT0FBTyxhQUFXLFNBQVMsZ0JBQWdCO0FBQVc7QUFBQyxTQUFTLEdBQUcsR0FBRTtDQUFDLE9BQU8sS0FBRyxXQUFTQSxJQUFFLFNBQVMsTUFBSyxLQUFHLG1CQUFtQixLQUFHLEtBQUcsUUFBTSxFQUFFLGdCQUFjLFNBQVMsS0FBSyxNQUFNLFlBQVksRUFBRSxjQUFhLEVBQUUsSUFBRSxJQUFJLEdBQUVBLElBQUUsU0FBUyxPQUFNLEtBQUcsT0FBSyxLQUFLLElBQUUsRUFBRSxjQUFZLG1CQUFtQjtBQUFFO0FBQXdrQixTQUFTLEVBQUUsR0FBRSxHQUFFO0NBQUMsSUFBRyxLQUFHLEdBQUU7RUFBQyxJQUFJLEtBQUUsTUFBRztHQUFDLEVBQUUsWUFBVSxFQUFFLFVBQVUsT0FBTyxDQUFDLElBQUUsRUFBRSxZQUFVLEVBQUUsVUFBVSxRQUFRLElBQUksT0FBTyxZQUFVLEVBQUUsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBRSxXQUFVLElBQUksR0FBRSxHQUFHO0VBQUM7RUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sT0FBTyxDQUFDLENBQUMsU0FBUSxNQUFHLEVBQUUsTUFBTSxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztDQUFDO0FBQUM7QUFBQyxTQUFTLEdBQUcsR0FBRTtDQUFDLE9BQU8sS0FBRyxXQUFTLEVBQUUsU0FBUyxNQUFLLEtBQUcsbUJBQW1CLEtBQUcsS0FBRyxRQUFNLEVBQUUsZ0JBQWMsU0FBUyxLQUFLLE1BQU0sZUFBZSxFQUFFLFlBQVksR0FBRSxFQUFFLFNBQVMsT0FBTSxLQUFHLE9BQUssS0FBSyxJQUFFLEVBQUUsY0FBWSxtQkFBbUI7QUFBRTtBQUFrbEIsU0FBU0MsTUFBRztDQUFDLElBQUksSUFBRSxRQUFPLElBQUUsVUFBUyxJQUFFLEVBQUUsaUJBQWdCLElBQUUsRUFBRSxxQkFBcUIsTUFBTSxDQUFDLENBQUM7Q0FBZ0csT0FBTTtFQUFDLE9BQWxHLEVBQUUsY0FBWSxFQUFFLGVBQWEsRUFBRTtFQUEyRSxRQUE3RCxFQUFFLGVBQWEsRUFBRSxnQkFBYyxFQUFFO0NBQW9DO0FBQUM7QUFBQyxTQUFTQyxJQUFFLEdBQUU7Q0FBQyxPQUFPLElBQUUsS0FBSyxJQUFJLEVBQUUsVUFBVSxJQUFFO0FBQUM7QUFBcTRCLElBQUlDLE9BQUc7QUFBK0csSUFBQSxLQUFHO0FBQXNDQyxJQUFBQSx1QkFBRyxJQUFJLElBQUk7Q0FBQztDQUFPO0NBQU07Q0FBYTtDQUFTO0FBQVksQ0FBQztBQUFFLElBQUEscUJBQUcsSUFBSSxJQUFJO0NBQUM7Q0FBTztDQUFRO0NBQVM7Q0FBTTtDQUFNO0NBQU07Q0FBTztBQUFNLENBQUM7QUFBRSxJQUFBLEtBQUc7QUFBMEUsU0FBUyxFQUFFLEdBQUU7Q0FBQyxJQUFHLE9BQU8sS0FBRyxVQUFTLE9BQU0sQ0FBQztDQUFFLElBQUdELEtBQUcsS0FBSyxDQUFDLEdBQUUsT0FBTSxDQUFDO0NBQUUsR0FBRyxZQUFVO0NBQUUsSUFBSTtDQUFFLE9BQUssSUFBRSxHQUFHLEtBQUssQ0FBQyxJQUFHLElBQUcsQ0FBQyxHQUFHLEtBQUssRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUUsT0FBTSxDQUFDO0NBQUUsT0FBTSxDQUFDO0FBQUM7QUFBQyxTQUFTRSxLQUFHLEdBQUU7Q0FBQyxJQUFJLElBQUU7Q0FBRyxLQUFJLElBQUksS0FBSyxHQUFFO0VBQUMsSUFBSSxJQUFFLEVBQUUsV0FBVyxDQUFDO0VBQUUsS0FBRyxNQUFJLE1BQUksT0FBSyxLQUFLLEtBQUssQ0FBQyxNQUFJLEtBQUc7Q0FBRTtDQUFDLE9BQU87QUFBQztBQUFDLFNBQVNDLEtBQUcsR0FBRSxHQUFFO0NBQUMsSUFBSSxHQUFFO0NBQUUsSUFBSSxJQUFFRCxLQUFHLENBQUMsR0FBRSxJQUFFLEVBQUUsWUFBWTtDQUFFLElBQUcsRUFBRSxXQUFXLEdBQUcsS0FBRyxFQUFFLFdBQVcsR0FBRyxLQUFHLEVBQUUsV0FBVyxJQUFJLEtBQUcsRUFBRSxXQUFXLEtBQUssS0FBRyxFQUFFLFdBQVcsR0FBRyxHQUFFLE9BQU0sQ0FBQztDQUFFLElBQUksS0FBRyxLQUFHLElBQUUsRUFBRSxNQUFNLHdCQUF3QixNQUFJLE9BQUssS0FBSyxJQUFFLEVBQUUsT0FBSyxPQUFLLEtBQUssSUFBRSxFQUFFLFlBQVk7Q0FBRSxPQUFPLElBQUUsTUFBSSxVQUFRLE1BQUksU0FBTyxNQUFJLGlCQUFlLEdBQUcsS0FBSyxFQUFFLEtBQUssQ0FBQyxJQUFFLEdBQUcsSUFBSSxDQUFDLElBQUUsQ0FBQztBQUFDO0FBQUMsU0FBU0UsSUFBRSxHQUFFLEdBQUU7Q0FBQyxPQUFPLE9BQU8sS0FBRyxZQUFVSCxLQUFHLElBQUksRUFBRSxZQUFZLENBQUMsS0FBRyxDQUFDRSxLQUFHLEdBQUUsQ0FBQztBQUFDO0FBQUMsU0FBUyxFQUFFLEdBQUUsR0FBRTtDQUFDLE9BQU8sRUFBRSxZQUFZLE1BQUksWUFBVSxPQUFPLEtBQUcsWUFBVSxzREFBc0QsS0FBSyxDQUFDO0FBQUM7QUFBNkUsU0FBU0UsS0FBRyxHQUFFO0NBQUMsT0FBTyxFQUFFLFdBQVcsSUFBSSxJQUFFLElBQUUsRUFBRSxRQUFRLG1CQUFrQixPQUFPLENBQUMsQ0FBQyxZQUFZO0FBQUM7QUFBQyxTQUFTLEVBQUUsR0FBRSxHQUFFLElBQUUsQ0FBQyxHQUFFO0NBQUMsRUFBRSxVQUFRLEVBQUUsTUFBTSxVQUFRLEtBQUksRUFBRSxTQUFRLE1BQUc7RUFBQyxJQUFJLElBQUUsRUFBRSxRQUFRLEdBQUc7RUFBRSxJQUFHLElBQUUsR0FBRTtFQUFPLElBQUksSUFBRSxFQUFFLE1BQU0sR0FBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUUsSUFBRSxFQUFFLE1BQU0sSUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLO0VBQUUsSUFBRyxDQUFDLEtBQUcsRUFBRSxDQUFDLEdBQUU7RUFBTyxJQUFJLElBQUU7RUFBRyxrQkFBa0IsS0FBSyxDQUFDLE1BQUksSUFBRSxFQUFFLFFBQVEsbUJBQWtCLEVBQUUsQ0FBQyxDQUFDLEtBQUssR0FBRSxJQUFFLGNBQWEsRUFBRSxNQUFNLFlBQVksR0FBRSxHQUFFLENBQUM7Q0FBQyxDQUFDO0FBQUM7QUFBQyxTQUFTLEdBQUcsR0FBRSxHQUFFO0NBQUMsSUFBSSxJQUFFO0NBQUUsT0FBSyxJQUFFLElBQUUsS0FBRyxLQUFHLEVBQUUsSUFBRSxJQUFFLE9BQUssT0FBTTtDQUFJLE9BQU8sSUFBRSxNQUFJO0FBQUM7QUFBQyxTQUFTLEdBQUcsR0FBRTtDQUFDLElBQUksSUFBRSxDQUFDLEdBQUUsSUFBRSxHQUFFLElBQUUsSUFBRyxJQUFFO0NBQUUsS0FBSSxJQUFJLElBQUUsR0FBRSxJQUFFLEVBQUUsUUFBTyxLQUFJO0VBQUMsSUFBSSxJQUFFLEVBQUU7RUFBRyxJQUFFLE1BQUksS0FBRyxDQUFDLEdBQUcsR0FBRSxDQUFDLE1BQUksSUFBRSxNQUFJLE1BQUksT0FBSyxNQUFJLE9BQUksSUFBRSxJQUFFLE1BQUksTUFBSSxNQUFJLE1BQUksTUFBSSxJQUFFLEtBQUssSUFBSSxHQUFFLElBQUUsQ0FBQyxJQUFFLE1BQUksT0FBSyxNQUFJLE1BQUksRUFBRSxLQUFLLEVBQUUsTUFBTSxHQUFFLENBQUMsQ0FBQyxHQUFFLElBQUUsSUFBRTtDQUFFO0NBQUMsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQyxHQUFFO0FBQUM7QUFBQyxTQUFTQyxJQUFFLEdBQUUsR0FBRSxJQUFFLENBQUMsR0FBRTtDQUFDLElBQUcsT0FBTyxLQUFHLFVBQVM7RUFBYSxFQUFFLEdBQVIsR0FBRyxDQUFPLEdBQUUsQ0FBQztFQUFFO0NBQU07Q0FBQyxFQUFFLFVBQVEsRUFBRSxNQUFNLFVBQVEsS0FBSSxPQUFPLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUUsT0FBSztFQUFDLElBQUcsS0FBRyxRQUFNLEVBQUUsQ0FBQyxHQUFFO0VBQU8sSUFBSSxJQUFFLE9BQU8sQ0FBQyxHQUFFLElBQUU7RUFBRyxrQkFBa0IsS0FBSyxDQUFDLE1BQUksSUFBRSxFQUFFLFFBQVEsbUJBQWtCLEVBQUUsQ0FBQyxDQUFDLEtBQUssR0FBRSxJQUFFLGNBQWEsRUFBRSxNQUFNLFlBQVlELEtBQUcsQ0FBQyxHQUFFLEdBQUUsQ0FBQztDQUFDLENBQUM7QUFBQztBQUFrRSxTQUFTRSxJQUFFLEdBQUUsR0FBRTtDQUFDLE1BQUksT0FBTyxLQUFHLFdBQVNELElBQUUsR0FBRSxHQUFFLEVBQUMsT0FBTSxDQUFDLEVBQUMsQ0FBQyxJQUFFQSxJQUFFLEdBQUUsS0FBRyxDQUFDLENBQUM7QUFBRTtBQUFDLFNBQVNFLElBQUUsR0FBRSxHQUFFO0NBQUMsSUFBRyxhQUFhLGFBQVk7RUFBQyxJQUFJLElBQUUsRUFBRTtFQUFZLElBQUcsR0FBRTtHQUFDLElBQUksSUFBRSxpQkFBaUIsQ0FBQztHQUFFLEtBQUcsV0FBVyxFQUFFLFVBQVUsSUFBRSxXQUFXLEVBQUUsV0FBVztFQUFDO0VBQUMsT0FBTztDQUFDO0NBQUMsT0FBTztBQUFDO0FBQW9wQixTQUFTLEVBQUUsR0FBRTtDQUFDLElBQUcsR0FBRTtFQUFDLElBQUksSUFBRSxFQUFFO0VBQVcsT0FBTyxLQUFHLGFBQWEsY0FBWSxFQUFFLFNBQU8sSUFBRSxFQUFFLE9BQU07Q0FBQztDQUFDLE9BQU87QUFBSTtBQUFDLFNBQVMsRUFBRSxHQUFFO0NBQUMsT0FBTSxDQUFDLEVBQUUsTUFBSSxRQUFNLE9BQU8sS0FBRyxlQUFhLEVBQUUsWUFBVSxFQUFFLENBQUM7QUFBRTtBQUFtRCxTQUFTLEVBQUUsR0FBRTtDQUFDLE9BQU8sT0FBTyxXQUFTLGNBQVksYUFBYSxVQUFRLE1BQUksUUFBTSxPQUFPLEtBQUcsWUFBVSxFQUFFLGFBQVcsS0FBRyxPQUFPLEVBQUUsWUFBVTtBQUFRO0FBQTYxQyxTQUFTLEVBQUUsR0FBRSxHQUFFLEdBQUU7Q0FBQyxJQUFHLE9BQU8sS0FBRyxjQUFZLEVBQUUsT0FBTyxLQUFHLFlBQVUsTUFBSSxRQUFNLGlCQUFnQixJQUFHO0NBQU8sSUFBSSxJQUFFLEdBQUUsSUFBRSxFQUFFLGdCQUFjLEVBQUUsY0FBWSxDQUFDLElBQUcsSUFBRSxDQUFDO0NBQUUsS0FBSSxJQUFJLElBQUUsRUFBRSxTQUFPLEdBQUUsS0FBRyxHQUFFLEtBQUksRUFBRSxFQUFFLENBQUMsT0FBSyxNQUFJLEVBQUUsRUFBRSxDQUFDLE9BQUssSUFBRSxJQUFFLENBQUMsS0FBRyxFQUFFLG9CQUFvQixHQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsR0FBRSxFQUFFLE9BQU8sR0FBRSxDQUFDO0NBQUksTUFBSSxFQUFFLGlCQUFpQixHQUFFLENBQUMsR0FBRSxFQUFFLEtBQUssQ0FBQyxHQUFFLENBQUMsQ0FBQztBQUFFO0FBQTJnQyxTQUFTQyxJQUFFLEdBQUUsSUFBRSxDQUFDLEdBQUU7Q0FBQyxJQUFHLEVBQUUsQ0FBQyxHQUFFO0VBQUMsSUFBSSxJQUFFLEtBQUcsT0FBSyxLQUFLLElBQUUsRUFBRSxRQUFPLEtBQUcsR0FBRSxNQUFJO0dBQUMsSUFBSSxJQUFFLEtBQUcsUUFBTSxFQUFFLEtBQUcsQ0FBQyxFQUFFLEVBQUUsSUFBRSxDQUFDO0dBQUUsT0FBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsR0FBRSxNQUFJO0lBQUMsSUFBRyxLQUFHLE1BQUs7S0FBQyxJQUFJLElBQUUsT0FBTztLQUFFLElBQUcsTUFBSSxZQUFVLE1BQUksVUFBUyxFQUFFLEtBQUssQ0FBQztVQUFPLElBQUcsTUFBSSxVQUFTO01BQUMsSUFBSSxJQUFFLE1BQU0sUUFBUSxDQUFDLElBQUUsRUFBRSxHQUFFLENBQUMsSUFBRSxPQUFPLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUUsT0FBSyxNQUFJLFlBQVUsS0FBRyxNQUFJLEtBQUcsR0FBRyxFQUFFLFFBQVEsbUJBQWtCLE9BQU8sQ0FBQyxDQUFDLFlBQVksRUFBRSxHQUFHLE1BQUksSUFBRSxJQUFFLEtBQUssQ0FBQztNQUFFLElBQUUsRUFBRSxTQUFPLEVBQUUsT0FBTyxFQUFFLFFBQU8sTUFBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUU7S0FBQztJQUFDO0lBQUMsT0FBTztHQUFDLEdBQUUsQ0FBQztFQUFDLEdBQUUsS0FBRSxNQUFHO0dBQW9CLEVBQUUsR0FBZixFQUFFLFNBQVEsQ0FBTyxDQUFDO0VBQUMsR0FBRSxJQUFFO0VBQUUsT0FBTyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFFLE9BQUs7R0FBQyxJQUFHLEtBQUcsTUFBSztJQUFDLElBQUksSUFBRSxFQUFFLE1BQU0sU0FBUztJQUFFLElBQUcsR0FBRSxFQUFFLEdBQUUsRUFBRSxFQUFFLENBQUMsWUFBWSxHQUFFLENBQUM7U0FBTyxJQUFHLE1BQUksWUFBVSxNQUFJLFNBQVEsSUFBRSxHQUFFLENBQUM7U0FBTyxJQUFHLE1BQUksU0FBUSxFQUFFLENBQUMsR0FBRSxFQUFFLFNBQU8sRUFBRSxVQUFRLENBQUMsR0FBRSxFQUFFLE9BQU8sS0FBRyxFQUFFLE1BQU07U0FBWTtLQUFDLElBQUdMLElBQUUsR0FBRSxDQUFDLEtBQUcsRUFBRSxHQUFFLENBQUMsR0FBRTtLQUFPLElBQUUsTUFBSSxVQUFRLENBQUMsR0FBRyxJQUFJLElBQUksRUFBRSxTQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUssSUFBRSxHQUFFLEVBQUUsU0FBTyxFQUFFLFVBQVEsQ0FBQyxHQUFFLEVBQUUsT0FBTyxLQUFHLEdBQUUsRUFBRSxhQUFhLEdBQUUsQ0FBQztJQUFDO0dBQUM7RUFBQyxDQUFDO0NBQUM7QUFBQztBQUFDLFNBQVMsRUFBRSxHQUFFLElBQUUsQ0FBQyxHQUFFLEdBQUcsR0FBRTtDQUFDLElBQUcsR0FBRTtFQUFDLElBQUksSUFBRSxTQUFTLGNBQWMsQ0FBQztFQUFFLE9BQU9LLElBQUUsR0FBRSxDQUFDLEdBQUUsRUFBRSxPQUFPLEdBQUcsQ0FBQyxHQUFFO0NBQUM7QUFBQztBQUFDLFNBQVMsRUFBRSxHQUFFO0NBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxDQUFDLFFBQVEsTUFBSyxPQUFPLENBQUMsQ0FBQyxRQUFRLE1BQUssUUFBUSxDQUFDLENBQUMsUUFBUSxNQUFLLE1BQU0sQ0FBQyxDQUFDLFFBQVEsTUFBSyxNQUFNO0FBQUM7QUFBcXdCLFNBQVMsR0FBRyxHQUFFLEdBQUU7Q0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFFLE1BQU0sS0FBSyxFQUFFLGlCQUFpQixDQUFDLENBQUMsSUFBRSxDQUFDO0FBQUM7QUFBcUUsU0FBUyxHQUFHLEdBQUUsR0FBRTtDQUFDLEtBQUcsU0FBUyxrQkFBZ0IsS0FBRyxFQUFFLE1BQU0sQ0FBQztBQUFDO0FBQUMsU0FBU0MsS0FBRyxHQUFFLEdBQUU7Q0FBQyxJQUFHLEVBQUUsQ0FBQyxHQUFFO0VBQUMsSUFBSSxJQUFFLEVBQUUsYUFBYSxDQUFDO0VBQUUsT0FBTyxNQUFJLFFBQU0sRUFBRSxLQUFLLE1BQUksTUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFFLENBQUMsSUFBRSxNQUFJLFVBQVEsTUFBSSxVQUFRLE1BQUksU0FBTztDQUFDO0FBQUM7QUFBdWtELFNBQVNDLElBQUUsR0FBRSxJQUFFLElBQUc7Q0FBQyxJQUFJLElBQUUsR0FBRyxHQUFFLDJGQUEyRixFQUFFO3NGQUN6b2EsRUFBRTtxR0FDYSxFQUFFO3NHQUNELEVBQUU7d0dBQ0EsRUFBRTswR0FDQSxFQUFFO2lIQUNLLEdBQUcsR0FBRSxJQUFFLENBQUM7Q0FBRSxLQUFJLElBQUksS0FBSyxHQUFFO0VBQUMsSUFBSSxJQUFFLGlCQUFpQixDQUFDO0VBQUUsRUFBRSxXQUFTLFVBQVEsRUFBRSxjQUFZLFlBQVUsRUFBRSxLQUFLLENBQUM7Q0FBQztDQUFDLE9BQU87QUFBQztBQUFDLFNBQVMsR0FBRyxHQUFFLEdBQUU7Q0FBQyxJQUFJLElBQUVBLElBQUUsR0FBRSxDQUFDO0NBQUUsT0FBTyxFQUFFLFNBQU8sSUFBRSxFQUFFLEtBQUc7QUFBSTtBQUFDLFNBQVMsR0FBRyxHQUFFO0NBQUMsSUFBRyxHQUFFO0VBQUMsSUFBSSxJQUFFLEVBQUUsY0FBYSxJQUFFLGlCQUFpQixDQUFDO0VBQUUsT0FBTyxLQUFHLFdBQVcsRUFBRSxVQUFVLElBQUUsV0FBVyxFQUFFLGFBQWEsSUFBRSxXQUFXLEVBQUUsY0FBYyxJQUFFLFdBQVcsRUFBRSxpQkFBaUIsR0FBRTtDQUFDO0NBQUMsT0FBTztBQUFDO0FBQWdyQixTQUFTLEdBQUcsR0FBRSxHQUFFO0NBQUMsSUFBSSxJQUFFQSxJQUFFLEdBQUUsQ0FBQztDQUFFLE9BQU8sRUFBRSxTQUFPLElBQUUsRUFBRSxFQUFFLFNBQU8sS0FBRztBQUFJO0FBQTBPLFNBQVMsR0FBRyxHQUFFO0NBQUMsSUFBRyxHQUFFO0VBQUMsSUFBSSxJQUFFLEVBQUUsc0JBQXNCO0VBQUUsT0FBTTtHQUFDLEtBQUksRUFBRSxPQUFLLE9BQU8sZUFBYSxTQUFTLGdCQUFnQixhQUFXLFNBQVMsS0FBSyxhQUFXO0dBQUcsTUFBSyxFQUFFLFFBQU0sT0FBTyxlQUFhWixJQUFFLFNBQVMsZUFBZSxLQUFHQSxJQUFFLFNBQVMsSUFBSSxLQUFHO0VBQUU7Q0FBQztDQUFDLE9BQU07RUFBQyxLQUFJO0VBQU8sTUFBSztDQUFNO0FBQUM7QUFBQyxTQUFTLEVBQUUsR0FBRSxHQUFFO0NBQUMsSUFBRyxHQUFFO0VBQUMsSUFBSSxJQUFFLEVBQUU7RUFBYSxJQUFHLEdBQUU7R0FBQyxJQUFJLElBQUUsaUJBQWlCLENBQUM7R0FBRSxLQUFHLFdBQVcsRUFBRSxTQUFTLElBQUUsV0FBVyxFQUFFLFlBQVk7RUFBQztFQUFDLE9BQU87Q0FBQztDQUFDLE9BQU87QUFBQztBQUEweUIsU0FBUyxHQUFHLEdBQUU7Q0FBQyxJQUFHLEdBQUU7RUFBQyxJQUFJLElBQUUsRUFBRSxhQUFZLElBQUUsaUJBQWlCLENBQUM7RUFBRSxPQUFPLEtBQUcsV0FBVyxFQUFFLFdBQVcsSUFBRSxXQUFXLEVBQUUsWUFBWSxJQUFFLFdBQVcsRUFBRSxlQUFlLElBQUUsV0FBVyxFQUFFLGdCQUFnQixHQUFFO0NBQUM7Q0FBQyxPQUFPO0FBQUM7QUFBaXRCLFNBQVMsS0FBSTtDQUFDLE9BQU0sQ0FBQyxFQUFFLE9BQU8sVUFBUSxlQUFhLE9BQU8sWUFBVSxPQUFPLFNBQVM7QUFBYztBQUEyTSxTQUFTLEdBQUcsR0FBRSxJQUFFLElBQUc7Q0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFFLEVBQUUsUUFBUSwyRkFBMkYsRUFBRTtzR0FDNzJILEVBQUU7cUdBQ0gsRUFBRTtzR0FDRCxFQUFFO3dHQUNBLEVBQUU7MEdBQ0EsRUFBRTtpSEFDSyxHQUFHLElBQUUsQ0FBQztBQUFDO0FBQXl4RCxTQUFTLEdBQUcsR0FBRSxJQUFFLElBQUcsR0FBRTtDQUFDLElBQUcsRUFBRSxDQUFDLEtBQUcsTUFBSSxRQUFNLE1BQUksS0FBSyxHQUFFO0VBQUMsSUFBSSxJQUFFLEVBQUUsWUFBWTtFQUFFLElBQUcsV0FBVyxLQUFLLENBQUMsR0FBRTtHQUFDLEVBQUUsR0FBRSxFQUFFLE1BQU0sQ0FBQyxHQUFFLENBQUM7R0FBRTtFQUFNO0VBQUMsSUFBRyxNQUFJLFNBQVE7R0FBQyxPQUFPLEtBQUcsV0FBU08sSUFBRSxHQUFFLEdBQUUsRUFBQyxPQUFNLENBQUMsRUFBQyxDQUFDLElBQUUsT0FBTyxLQUFHLFlBQVVBLElBQUUsR0FBRSxDQUFDO0dBQUU7RUFBTTtFQUFDLElBQUdGLElBQUUsR0FBRSxDQUFDLEtBQUcsRUFBRSxHQUFFLENBQUMsR0FBRTtFQUFPLEVBQUUsYUFBYSxHQUFFLENBQUM7Q0FBQztBQUFDOzs7QUNaaHBFLFNBQVMsSUFBRztDQUFDLElBQUksb0JBQUUsSUFBSSxJQUFFLEdBQUUsSUFBRTtFQUFDLEdBQUcsR0FBRSxHQUFFO0dBQUMsSUFBSSxJQUFFLEVBQUUsSUFBSSxDQUFDO0dBQUUsT0FBTyxJQUFFLEVBQUUsS0FBSyxDQUFDLElBQUUsSUFBRSxDQUFDLENBQUMsR0FBRSxFQUFFLElBQUksR0FBRSxDQUFDLEdBQUU7RUFBQztFQUFFLElBQUksR0FBRSxHQUFFO0dBQUMsSUFBSSxJQUFFLEVBQUUsSUFBSSxDQUFDO0dBQUUsSUFBRyxHQUFFO0lBQUMsSUFBSSxJQUFFLEVBQUUsUUFBUSxDQUFDO0lBQUUsTUFBSSxNQUFJLEVBQUUsT0FBTyxHQUFFLENBQUM7R0FBQztHQUFDLE9BQU87RUFBQztFQUFFLEtBQUssR0FBRSxHQUFHLEdBQUU7R0FBQyxJQUFJLElBQUUsRUFBRSxJQUFJLENBQUM7R0FBRSxLQUFHLEVBQUUsU0FBUSxNQUFHO0lBQUMsRUFBRSxFQUFFLEVBQUU7R0FBQyxDQUFDO0VBQUM7RUFBRSxRQUFPO0dBQUMsRUFBRSxNQUFNO0VBQUM7Q0FBQztDQUFFLE9BQU87QUFBQzs7O0FDQWpRLFNBQVMsSUFBRztDQUFDLElBQUksSUFBRSxDQUFDLEdBQUUsS0FBRyxHQUFFLEdBQUUsSUFBRSxRQUFNO0VBQUMsSUFBSSxJQUFFLEVBQUUsR0FBRSxHQUFFLENBQUMsR0FBRSxJQUFFLEVBQUUsU0FBTyxFQUFFLFFBQU0sSUFBRSxJQUFFLEtBQUc7RUFBRSxPQUFPLEVBQUUsS0FBSztHQUFDLEtBQUk7R0FBRSxPQUFNO0VBQUMsQ0FBQyxHQUFFO0NBQUMsR0FBRSxLQUFFLE1BQUc7RUFBQyxJQUFFLEVBQUUsUUFBTyxNQUFHLEVBQUUsVUFBUSxDQUFDO0NBQUMsR0FBRSxLQUFHLEdBQUUsTUFBSSxFQUFFLEdBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTSxLQUFHLEdBQUUsR0FBRSxJQUFFLE1BQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQUssTUFBRyxJQUFFLENBQUMsSUFBRSxFQUFFLFFBQU0sQ0FBQyxLQUFHO0VBQUMsS0FBSTtFQUFFLE9BQU07Q0FBQyxHQUFFLEtBQUUsTUFBRyxLQUFHLFNBQVMsRUFBRSxNQUFNLFFBQU8sRUFBRSxLQUFHO0NBQUUsT0FBTTtFQUFDLEtBQUk7RUFBRSxNQUFLLEdBQUUsR0FBRSxNQUFJO0dBQUMsTUFBSSxFQUFFLE1BQU0sU0FBTyxPQUFPLEVBQUUsR0FBRSxDQUFDLEdBQUUsQ0FBQyxDQUFDO0VBQUU7RUFBRSxRQUFNLE1BQUc7R0FBQyxNQUFJLEVBQUUsRUFBRSxDQUFDLENBQUMsR0FBRSxFQUFFLE1BQU0sU0FBTztFQUFHO0VBQUUsYUFBVyxNQUFHLEVBQUUsR0FBRSxDQUFDLENBQUM7Q0FBQztBQUFDO0FBQUMsSUFBSSxJQUFFLEVBQUU7OztBQ0FwYSxJQUFJLEtBQUcsT0FBTztBQUFlLElBQUEsS0FBRyxPQUFPO0FBQWlCLElBQUksS0FBRyxPQUFPO0FBQTBCLElBQUksS0FBRyxPQUFPO0FBQXNCLElBQUksS0FBRyxPQUFPLFVBQVU7QUFBZSxJQUFBLEtBQUcsT0FBTyxVQUFVO0FBQXFCLElBQUksTUFBSSxHQUFFLEdBQUUsTUFBSSxLQUFLLElBQUUsR0FBRyxHQUFFLEdBQUU7Q0FBQyxZQUFXLENBQUM7Q0FBRSxjQUFhLENBQUM7Q0FBRSxVQUFTLENBQUM7Q0FBRSxPQUFNO0FBQUMsQ0FBQyxJQUFFLEVBQUUsS0FBRztBQUFFLElBQUEsS0FBRyxHQUFFLE1BQUk7Q0FBQyxLQUFJLElBQUksS0FBSyxNQUFJLElBQUUsQ0FBQyxJQUFHLEdBQUcsS0FBSyxHQUFFLENBQUMsS0FBRyxHQUFHLEdBQUUsR0FBRSxFQUFFLEVBQUU7Q0FBRSxJQUFHLElBQUcsS0FBSSxJQUFJLEtBQUssR0FBRyxDQUFDLEdBQUUsR0FBRyxLQUFLLEdBQUUsQ0FBQyxLQUFHLEdBQUcsR0FBRSxHQUFFLEVBQUUsRUFBRTtDQUFFLE9BQU87QUFBQztBQUFFLElBQUEsS0FBRyxHQUFFLE1BQUksR0FBRyxHQUFFLEdBQUcsQ0FBQyxDQUFDO0FBQUUsSUFBSSxLQUFHLEdBQUUsTUFBSTtDQUFDLElBQUksSUFBRSxDQUFDO0NBQUUsS0FBSSxJQUFJLEtBQUssR0FBRSxHQUFHLEtBQUssR0FBRSxDQUFDLEtBQUcsRUFBRSxRQUFRLENBQUMsSUFBRSxNQUFJLEVBQUUsS0FBRyxFQUFFO0NBQUksSUFBRyxLQUFHLFFBQU0sSUFBRyxLQUFJLElBQUksS0FBSyxHQUFHLENBQUMsR0FBRSxFQUFFLFFBQVEsQ0FBQyxJQUFFLEtBQUcsR0FBRyxLQUFLLEdBQUUsQ0FBQyxNQUFJLEVBQUUsS0FBRyxFQUFFO0NBQUksT0FBTztBQUFDO0FBQTJRLElBQVksSUFBTFEsRUFBUTtBQUFzSyxJQUFJLElBQUU7QUFBYSxJQUFBLEtBQUc7QUFBd0IsSUFBQSxLQUFHO0FBQWdCLFNBQVMsRUFBRSxHQUFFO0NBQUMsT0FBT0MsRUFBRSxDQUFDLElBQUUsRUFBRSxRQUFRLFdBQVUsR0FBRSxNQUFJLE1BQUksSUFBRSxJQUFFLE1BQUksRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDLFlBQVksSUFBRTtBQUFDO0FBQW1FLFNBQVMsR0FBRyxHQUFFO0NBQUMsT0FBT0MsRUFBRyxDQUFDLEtBQUcsT0FBTyxVQUFVLGVBQWUsS0FBSyxHQUFFLFFBQVEsS0FBRyxPQUFPLFVBQVUsZUFBZSxLQUFLLEdBQUUsT0FBTyxJQUFFLEVBQUUsU0FBTztBQUFDO0FBQTJNLFNBQVMsR0FBRyxHQUFFO0NBQUMsT0FBTyxFQUFFLFdBQVcsTUFBSyxFQUFFLENBQUMsQ0FBQyxRQUFRLFVBQVMsR0FBRztBQUFDO0FBQUMsU0FBUyxHQUFHLElBQUUsSUFBRyxJQUFFLElBQUc7Q0FBQyxPQUFPLEdBQUcsR0FBR0QsRUFBRSxHQUFFLENBQUMsQ0FBQyxLQUFHQSxFQUFFLEdBQUUsQ0FBQyxDQUFDLElBQUUsR0FBRyxFQUFFLEtBQUcsSUFBSSxHQUFHO0FBQUM7QUFBQyxTQUFTLEdBQUcsSUFBRSxJQUFHLElBQUUsSUFBRztDQUFDLE9BQU0sS0FBSyxHQUFHLEdBQUUsQ0FBQztBQUFHO0FBQUMsU0FBUyxHQUFHLElBQUUsSUFBRztDQUErRCxTQUF2RCxFQUFFLE1BQU0sSUFBSSxLQUFHLENBQUMsRUFBQSxDQUFHLFVBQVUsRUFBRSxNQUFNLElBQUksS0FBRyxDQUFDLEVBQUEsQ0FBRyxVQUFtQixNQUFJO0FBQUM7QUFBQyxTQUFTLEVBQUUsR0FBRSxJQUFFLElBQUcsSUFBRSxJQUFHLElBQUUsQ0FBQyxHQUFFLEdBQUU7Q0FBQyxJQUFHQSxFQUFFLENBQUMsR0FBRTtFQUFDLElBQUksSUFBRSxFQUFFLEtBQUs7RUFBRSxJQUFHLEdBQUcsQ0FBQyxHQUFFO0VBQU8sSUFBR0UsSUFBRyxHQUFFLENBQUMsR0FBRTtHQUFDLElBQUksSUFBRSxFQUFFLFdBQVcsSUFBRSxNQUFHO0lBQXNFLE9BQU0sT0FBTyxHQUFHLEdBQUVDLEdBQWpGLEVBQUUsUUFBUSxRQUFPLEVBQUUsQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsUUFBTyxNQUFHLENBQUMsRUFBRSxNQUFLLE1BQUdELElBQUcsR0FBRSxDQUFDLENBQUMsQ0FBd0IsQ0FBQSxDQUFFLEtBQUssR0FBRyxDQUFDLENBQUMsSUFBSUUsRUFBRyxDQUFDLElBQUUsS0FBSyxNQUFJLEdBQUc7R0FBRSxDQUFDO0dBQUUsT0FBT0YsSUFBRyxFQUFFLFFBQVEsSUFBRyxHQUFHLEdBQUUsRUFBRSxJQUFFLFFBQVEsRUFBRSxLQUFHO0VBQUM7RUFBQyxPQUFPO0NBQUMsT0FBTSxJQUFHRyxFQUFHLENBQUMsR0FBRSxPQUFPO0FBQUM7QUFBbUksU0FBUyxHQUFHLEdBQUUsR0FBRSxHQUFFO0NBQUMsRUFBRSxHQUFFLENBQUMsQ0FBQyxLQUFHLEVBQUUsS0FBSyxHQUFHLEVBQUUsR0FBRyxFQUFFLEVBQUU7QUFBQztBQUFDLFNBQVMsRUFBRSxHQUFFLEdBQUU7Q0FBQyxPQUFPLElBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxLQUFHO0FBQUU7QUFBQyxTQUFTLEdBQUcsR0FBRSxHQUFFO0NBQUMsSUFBRyxFQUFFLFFBQVEsS0FBSyxNQUFJLElBQUcsT0FBTztDQUFFLFNBQVMsRUFBRSxHQUFFLEdBQUU7RUFBQyxJQUFJLElBQUUsQ0FBQyxHQUFFLElBQUUsR0FBRSxJQUFFLElBQUcsSUFBRSxNQUFLLElBQUU7RUFBRSxPQUFLLEtBQUcsRUFBRSxTQUFRO0dBQUMsSUFBSSxJQUFFLEVBQUU7R0FBRyxLQUFJLE1BQUksUUFBSyxNQUFJLE9BQUssTUFBSSxRQUFNLEVBQUUsSUFBRSxPQUFLLFNBQU8sSUFBRSxNQUFJLElBQUUsT0FBSyxJQUFHLENBQUMsTUFBSSxNQUFJLE9BQUssS0FBSSxNQUFJLE9BQUssTUFBSyxNQUFJLE9BQUssTUFBSSxFQUFFLFdBQVMsTUFBSSxJQUFHO0lBQUMsSUFBSSxJQUFFLEVBQUUsS0FBSztJQUFFLEVBQUUsV0FBVyxLQUFLLElBQUUsRUFBRSxLQUFLLEdBQUcsR0FBRSxDQUFDLENBQUMsSUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsR0FBRSxJQUFFLElBQUc7SUFBSTtHQUFRO0dBQUMsTUFBSSxLQUFLLE1BQUksS0FBRyxJQUFHO0VBQUc7RUFBQyxPQUFPO0NBQUM7Q0FBQyxTQUFTLEVBQUUsR0FBRTtFQUFDLElBQUksSUFBRSxFQUFFO0VBQUcsS0FBSSxNQUFJLFFBQUssTUFBSSxPQUFLLE1BQUksUUFBTSxFQUFFLEVBQUUsU0FBTyxPQUFLLEdBQUUsT0FBTyxFQUFFLE1BQU0sR0FBRSxFQUFFO0VBQUUsSUFBSSxJQUFFLE9BQU8sQ0FBQztFQUFFLE9BQU8sTUFBTSxDQUFDLElBQUUsSUFBRTtDQUFDO0NBQUMsSUFBSSxJQUFFLENBQUMsR0FBRSxJQUFFLENBQUM7Q0FBRSxLQUFJLElBQUksSUFBRSxHQUFFLElBQUUsRUFBRSxRQUFPLEtBQUksSUFBRyxFQUFFLE9BQUssT0FBSyxFQUFFLE1BQU0sR0FBRSxJQUFFLENBQUMsTUFBSSxPQUFNLEVBQUUsS0FBSyxDQUFDLEdBQUUsS0FBRztNQUFPLElBQUcsRUFBRSxPQUFLLE9BQUssRUFBRSxTQUFPLEdBQUU7RUFBQyxJQUFJLElBQUUsRUFBRSxJQUFJO0VBQUUsRUFBRSxXQUFTLEtBQUcsRUFBRSxLQUFLLENBQUMsR0FBRSxDQUFDLENBQUM7Q0FBQztDQUFDLElBQUcsQ0FBQyxFQUFFLFFBQU8sT0FBTztDQUFFLEtBQUksSUFBSSxJQUFFLEVBQUUsU0FBTyxHQUFFLEtBQUcsR0FBRSxLQUFJO0VBQUMsSUFBRyxDQUFDLEdBQUUsS0FBRyxFQUFFLElBQTZCLElBQUUsRUFBRSxHQUFYLEVBQWpCLEVBQUUsTUFBTSxJQUFFLEdBQUUsQ0FBTyxHQUFFLENBQVUsQ0FBQztFQUFFLElBQUUsRUFBRSxNQUFNLEdBQUUsQ0FBQyxJQUFFLElBQUUsRUFBRSxNQUFNLElBQUUsQ0FBQztDQUFDO0NBQUMsT0FBTztBQUFDO0FBQTZwQyxJQUFJLE1BQUksR0FBRSxNQUFJO0NBQUMsSUFBSSxJQUFFLEVBQUUsTUFBTSxHQUFHLEdBQUUsSUFBRTtDQUFHLEtBQUksSUFBSSxJQUFFLEdBQUUsSUFBRSxFQUFFLFFBQU8sS0FBSTtFQUFDLElBQUksSUFBRSxFQUFFLEVBQUUsRUFBRTtFQUFFLEVBQUUsWUFBVSxHQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsTUFBSSxJQUFFLElBQUUsR0FBRyxFQUFFLEdBQUcsTUFBSTtDQUFFO0NBQUMsT0FBTztBQUFDO0FBQUUsSUFBQSxNQUFJLEdBQUUsR0FBRSxHQUFFLEdBQUUsTUFBSTtDQUFDLElBQUcsT0FBTyxLQUFHLFVBQVMsT0FBTyxLQUFHLE9BQUssSUFBRSxFQUFFLGNBQWMsQ0FBQztDQUFFLElBQUcsRUFBRSxZQUFVLEdBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxHQUFFLE9BQU87Q0FBRSxJQUFJLElBQUUsRUFBRSxNQUFNLEdBQUUsRUFBRSxRQUFRLEdBQUcsQ0FBQztDQUFvSixPQUFPLEVBQXZKLEVBQUUsUUFBUSxJQUFFLE1BQUc7RUFBQyxJQUFJLElBQUUsRUFBRSxNQUFNLEdBQUUsRUFBRSxHQUFFLElBQUUsRUFBRSxRQUFRLEdBQUc7RUFBRSxLQUFJLE1BQUksS0FBRyxJQUFFLEVBQUUsTUFBTSxHQUFFLENBQUMsT0FBSyxHQUFFLE9BQU87RUFBRSxJQUFJLElBQUUsRUFBRSxjQUFjLENBQUM7RUFBRSxPQUFPLEtBQUcsT0FBSyxJQUFFLEdBQUc7Q0FBRyxDQUFZLEdBQUUsS0FBSyxHQUFFLEdBQUUsQ0FBQyxDQUFDLEdBQUUsQ0FBQztBQUFDO0FBQUUsSUFBQSxNQUFJLEdBQUUsR0FBRSxHQUFFLE1BQUk7Q0FBQyxJQUFJLEdBQUUsR0FBRSxHQUFFO0NBQUUsSUFBSSxJQUFFLEdBQUcsR0FBRSxDQUFDLEdBQUUsSUFBRSxFQUFFLFFBQU8sSUFBRSxFQUFFO0NBQWMsTUFBSSxvQkFBRSxJQUFJLElBQUUsR0FBRSxPQUFPLGVBQWUsR0FBRSxpQkFBZ0I7RUFBQyxPQUFNO0VBQUUsWUFBVyxDQUFDO0VBQUUsY0FBYSxDQUFDO0NBQUMsQ0FBQztDQUFHLElBQUksSUFBRSxLQUFHLFFBQU0sT0FBTyxLQUFHLFVBQVMsSUFBRSxLQUFHLEtBQUcsT0FBSyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsTUFBSSxHQUFHLEVBQUUsR0FBRyxLQUFJLElBQUUsSUFBRSxFQUFFLElBQUksQ0FBQyxJQUFFLEtBQUs7Q0FBRSxJQUFHLE1BQUksS0FBSyxNQUFJLENBQUMsS0FBRyxDQUFDLEVBQUUsSUFBSSxDQUFDLElBQUc7RUFBQyxJQUFJLEtBQUcsSUFBRSxFQUFFLE9BQUssT0FBSyxLQUFLLElBQUUsRUFBRSxPQUFNLElBQUUsS0FBRyxPQUFLLEtBQUssSUFBRSxFQUFFLE1BQUssTUFBRyxFQUFFLFdBQVMsTUFBTSxHQUFFLEtBQUcsSUFBRSxLQUFHLE9BQUssS0FBSyxJQUFFLEVBQUUsTUFBSyxNQUFHLEVBQUUsV0FBUyxPQUFPLE1BQUksT0FBSyxJQUFFLEdBQUUsS0FBRyxJQUFFLEtBQUcsT0FBSyxLQUFLLElBQUUsRUFBRSxNQUFLLE1BQUcsRUFBRSxXQUFTLE1BQU0sTUFBSSxPQUFLLElBQUU7RUFBRSxJQUFHLEtBQUcsS0FBRyxNQUFJLEdBQUU7R0FBQyxJQUFJLElBQUUsR0FBRyxFQUFFLE9BQU0sR0FBRSxHQUFFLEdBQUUsQ0FBQyxHQUFFLElBQUUsR0FBRyxFQUFFLE9BQU0sR0FBRSxHQUFFLEdBQUUsQ0FBQztHQUFFLElBQUUsTUFBSSxJQUFFLElBQUUsY0FBYyxFQUFFLEdBQUcsRUFBRTtFQUFFLE9BQU0sSUFBRSxJQUFJLElBQUUsS0FBRyxPQUFLLElBQUUsTUFBSSxPQUFLLEtBQUssSUFBRSxFQUFFLE9BQU0sR0FBRSxHQUFFLEdBQUUsQ0FBQztFQUFFLEtBQUcsRUFBRSxJQUFJLEdBQUUsQ0FBQztDQUFDO0NBQUMsT0FBTyxFQUFFLG1CQUFtQixDQUFDLElBQUUsRUFBRSxJQUFJLEVBQUUsSUFBRyxLQUFLLEdBQUUsR0FBRSxDQUFDLENBQUMsR0FBRSxDQUFDLElBQUU7QUFBQztBQUFFLElBQUEsTUFBRyxNQUFHO0NBQUMsSUFBSSxHQUFFLEdBQUU7Q0FBRSxJQUFJLElBQUUsRUFBRSxTQUFTLEdBQUUsSUFBRSxJQUFJLElBQUUsR0FBRyxHQUFFLEdBQUUsS0FBSyxHQUFFLFVBQVUsTUFBSSxPQUFLLElBQUU7Q0FBMEYsT0FBTTtFQUFDLE9BQXpGLEtBQUcsSUFBRSxFQUFFLE1BQU0sV0FBVyxNQUFJLE9BQUssS0FBSyxJQUFFLEVBQUUsT0FBSyxPQUFLLElBQUU7RUFBMEMsVUFBUztFQUFFLE9BQWhELEdBQUcsR0FBRSxHQUFFLEtBQUssR0FBRSxPQUF3QztDQUFDO0FBQUM7QUFBRSxJQUFBLEtBQUcsR0FBRSxHQUFFLE1BQUksR0FBRyxFQUFFLFNBQVMsR0FBRSxHQUFFLEdBQUUsQ0FBQztBQUFFLElBQUEsTUFBSSxJQUFFLENBQUMsR0FBRSxHQUFFLEdBQUUsTUFBSTtDQUFDLElBQUksR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFLEdBQUU7Q0FBRSxJQUFHLENBQUMsR0FBRSxPQUFNO0NBQUcsSUFBSSxLQUFHLElBQUUsRUFBRSxhQUFXLE9BQUssS0FBSyxJQUFFLEVBQUUsVUFBUyxLQUFHLEtBQUcsSUFBRSxLQUFHLE9BQUssS0FBSyxJQUFFLEVBQUUsWUFBVSxPQUFLLEtBQUssSUFBRSxFQUFFLFdBQVMsT0FBSyxLQUFHLEtBQUcsSUFBRSxFQUFFLGFBQVcsT0FBSyxLQUFLLElBQUUsRUFBRSxZQUFVLE9BQUssS0FBSyxJQUFFLEVBQUUsUUFBTyxLQUFHLEtBQUcsS0FBRyxJQUFFLEtBQUcsT0FBSyxLQUFLLElBQUUsRUFBRSxZQUFVLE9BQUssS0FBSyxJQUFFLEVBQUUsaUJBQWUsT0FBSyxLQUFHLEtBQUcsSUFBRSxFQUFFLGFBQVcsT0FBSyxLQUFLLElBQUUsRUFBRSxZQUFVLE9BQUssS0FBSyxJQUFFLEVBQUUsaUJBQWUsT0FBSyxJQUFFLENBQUM7Q0FBRSxJQUFHLE1BQUksU0FBUSxPQUFPLEVBQUUsY0FBYyxDQUFDO0NBQUUsSUFBR0MsSUFBRyxDQUFDLEtBQUcsQ0FBQyxHQUFFLE9BQU8sR0FBRyxHQUFFLEdBQUUsRUFBRSxrQkFBaUIsQ0FBQztDQUEyQixPQUFPLEVBQTFCQyxJQUFHLEdBQUUsQ0FBQyxJQUFFLElBQUUsSUFBSSxFQUFFLElBQWMsS0FBSyxHQUFFLEdBQUUsQ0FBQyxFQUFFLGdCQUFnQixHQUFFLENBQUM7QUFBQztBQUFFLElBQUksTUFBSSxHQUFHLE1BQUk7Q0FBQyxJQUFJO0NBQUUsT0FBTSxJQUFJLElBQUUsRUFBRSxHQUFHLENBQUMsTUFBSSxPQUFLLElBQUU7QUFBSTtBQUFFLFNBQVMsR0FBRyxHQUFFLEdBQUcsR0FBRTtDQUFDLElBQUcsYUFBYSxPQUF1RixPQUFPLEdBQWpGLEVBQUUsUUFBUSxHQUFFLEdBQUUsTUFBSTtFQUFDLElBQUk7RUFBRSxPQUFPLElBQUUsTUFBSSxJQUFFQyxJQUFHLEVBQUUsSUFBRyxFQUFDLElBQUcsRUFBQyxDQUFDLE1BQUksT0FBSyxJQUFFO0NBQUcsR0FBRSxFQUFjLEdBQUUsRUFBRTtDQUFFLE9BQU9BLElBQUcsR0FBRSxFQUFDLElBQUcsRUFBQyxDQUFDO0FBQUM7QUFBc2lDLFNBQVMsR0FBRyxHQUFFLElBQUUsQ0FBQyxHQUFFO0NBQUMsSUFBSUMsTUFBRSxFQUFFLFNBQVMsVUFBUyxFQUFDLFFBQU8sSUFBRUEsSUFBRSxRQUFPLFVBQVMsSUFBRUEsSUFBRSxVQUFTLGtCQUFpQixJQUFFQSxJQUFFLHFCQUFrQixHQUFFLElBQUUsQ0FBQyxHQUFFLElBQUUsQ0FBQyxHQUFFLElBQUUsQ0FBQztFQUFDLE1BQUs7RUFBRSxNQUFLO0NBQUMsQ0FBQztDQUFFLE9BQUssRUFBRSxTQUFRO0VBQUMsSUFBRyxFQUFDLE1BQUssR0FBRSxNQUFLLE1BQUcsRUFBRSxJQUFJO0VBQUUsS0FBSSxJQUFJLEtBQUssR0FBRTtHQUFDLElBQUksSUFBRSxFQUFFLElBQUcsSUFBRSxHQUFHLENBQUMsR0FBRSxJQUFFQyxJQUFHLEdBQUUsQ0FBQyxJQUFFLEdBQUcsQ0FBQyxJQUFFLEdBQUcsR0FBRUMsR0FBRyxDQUFDLENBQUM7R0FBRSxJQUFHQyxFQUFHLENBQUMsR0FBRSxFQUFFLEtBQUs7SUFBQyxNQUFLO0lBQUUsTUFBSztHQUFDLENBQUM7UUFBTTtJQUFDLElBQUksSUFBRSxHQUFHLENBQUMsR0FBRSxJQUFFLEVBQUUsR0FBRSxHQUFFLEdBQUUsQ0FBQyxDQUFDLENBQUM7SUFBRSxHQUFHLEdBQUUsR0FBRSxLQUFHLE9BQUssSUFBRSxHQUFHLEdBQUc7SUFBRSxJQUFJLElBQUU7SUFBRSxLQUFHLEVBQUUsV0FBVyxJQUFFLEdBQUcsTUFBSSxJQUFFLEVBQUUsTUFBTSxFQUFFLFNBQU8sQ0FBQyxJQUFHLEVBQUUsS0FBSyxFQUFFLFFBQVEsTUFBSyxHQUFHLENBQUM7R0FBQztFQUFDO0NBQUM7Q0FBQyxJQUFJLElBQUUsRUFBRSxLQUFLLEVBQUU7Q0FBRSxPQUFNO0VBQUMsT0FBTTtFQUFFLFFBQU87RUFBRSxjQUFhO0VBQUUsS0FBSSxFQUFFLEdBQUUsQ0FBQztDQUFDO0FBQUM7QUFBQyxJQUFJLElBQUU7Q0FBQyxPQUFNO0VBQUMsT0FBTTtHQUFDLE9BQU07SUFBQyxTQUFRO0lBQXVCLFFBQVEsR0FBRTtLQUFDLE9BQU07TUFBQyxNQUFLO01BQVEsVUFBUztNQUFFLFNBQVEsS0FBSyxRQUFRLEtBQUssRUFBRSxLQUFLLENBQUM7S0FBQztJQUFDO0dBQUM7R0FBRSxNQUFLO0lBQUMsU0FBUTtJQUFhLFFBQVEsR0FBRTtLQUFDLE9BQU07TUFBQyxNQUFLO01BQU8sVUFBUyxRQUFRLEVBQUUsUUFBUTtNQUFJLFNBQVEsS0FBSyxRQUFRLEtBQUssRUFBRSxLQUFLLENBQUM7S0FBQztJQUFDO0dBQUM7R0FBRSxPQUFNO0lBQUMsU0FBUTtJQUFnQixRQUFRLEdBQUU7S0FBQyxPQUFNO01BQUMsTUFBSztNQUFRLFVBQVM7TUFBRSxTQUFRLEtBQUssUUFBUSxLQUFLLEVBQUUsS0FBSyxDQUFDO0tBQUM7SUFBQztHQUFDO0dBQUUsUUFBTztJQUFDLFNBQVE7SUFBVyxRQUFRLEdBQUU7S0FBQyxPQUFNO01BQUMsTUFBSztNQUFTLFVBQVM7TUFBc0MsU0FBUSxLQUFLLFFBQVEsS0FBSyxFQUFFLEtBQUssQ0FBQztLQUFDO0lBQUM7R0FBQztHQUFFLFFBQU8sRUFBQyxRQUFRLEdBQUU7SUFBQyxPQUFNO0tBQUMsTUFBSztLQUFTLFVBQVM7S0FBRSxTQUFRLENBQUM7SUFBQztHQUFDLEVBQUM7RUFBQztFQUFFLFFBQVEsR0FBRTtHQUFDLElBQUksSUFBRSxPQUFPLEtBQUssS0FBSyxLQUFLLENBQUMsQ0FBQyxRQUFPLE1BQUcsTUFBSSxRQUFRLENBQUMsQ0FBQyxLQUFJLE1BQUcsS0FBSyxNQUFNLEVBQUU7R0FBRSxPQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSSxNQUFHO0lBQUMsSUFBSTtJQUFFLFFBQU8sSUFBRSxFQUFFLEtBQUksTUFBRyxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFLLE1BQUcsRUFBRSxPQUFPLE1BQUksT0FBSyxJQUFFLEtBQUssTUFBTSxPQUFPLFFBQVEsQ0FBQztHQUFDLENBQUM7RUFBQztDQUFDO0NBQUUsYUFBYSxHQUFFLEdBQUU7RUFBQyxPQUFPLEdBQUcsR0FBRSxFQUFDLFFBQU8sS0FBRyxPQUFLLEtBQUssSUFBRSxFQUFFLE9BQU0sQ0FBQztDQUFDO0NBQUUsVUFBVSxFQUFDLE1BQUssSUFBRSxJQUFHLE9BQU0sSUFBRSxDQUFDLEdBQUUsUUFBTyxHQUFFLEtBQUksR0FBRSxVQUFTLEtBQUc7RUFBQyxJQUFJLEdBQUUsR0FBRSxHQUFFLEdBQUUsR0FBRSxHQUFFO0VBQUUsSUFBRyxFQUFDLFFBQU8sR0FBRSxTQUFRLE1BQUcsR0FBRSxHQUFFLEdBQUUsR0FBRUMsS0FBRSxHQUFFLEdBQUU7RUFBRSxJQUFHQyxFQUFFLENBQUMsR0FBRTtHQUFDLElBQUcsRUFBQyxXQUFVLEdBQUUsVUFBUyxHQUFFLFFBQU8sTUFBRyxHQUFFLElBQUUsS0FBRyxDQUFDLEdBQUUsRUFBQyxhQUFZLE9BQUksR0FBRSxJQUFFLEVBQUUsR0FBRSxDQUFDLGFBQWEsQ0FBQyxHQUFFLElBQUUsS0FBRyxDQUFDLEdBQUUsRUFBQyxhQUFZLE1BQUcsR0FBRSxJQUFFLEVBQUUsR0FBRSxDQUFDLGFBQWEsQ0FBQyxHQUFFLElBQUUsTUFBSSxDQUFDLEdBQUUsRUFBQyxNQUFLLE1BQUcsR0FBRSxJQUFFLEVBQUUsR0FBRSxDQUFDLE1BQU0sQ0FBQyxHQUFFLElBQUUsS0FBRyxDQUFDLEdBQUUsRUFBQyxNQUFLLE1BQUcsR0FBRSxJQUFFLEVBQUUsR0FBRSxDQUFDLE1BQU0sQ0FBQyxHQUFFLElBQUVBLEVBQUUsQ0FBQyxJQUFFLEtBQUssYUFBYSxFQUFDLFdBQVUsRUFBQyxHQUFFLENBQUMsSUFBRSxDQUFDLEdBQUUsSUFBRUEsRUFBRSxDQUFDLElBQUUsS0FBSyxhQUFhLEVBQUMsVUFBUyxFQUFDLEdBQUUsQ0FBQyxJQUFFLENBQUMsR0FBRSxJQUFFQSxFQUFFLENBQUMsSUFBRSxLQUFLLGFBQWEsRUFBQyxPQUFNLEVBQUMsR0FBRSxDQUFDLElBQUUsQ0FBQyxHQUFFLElBQUVBLEVBQUUsQ0FBQyxJQUFFLEtBQUssYUFBYSxFQUFDLE1BQUssRUFBQyxHQUFFLENBQUMsSUFBRSxDQUFDLEdBQUUsS0FBR0EsRUFBRSxDQUFDLElBQUUsS0FBSyxhQUFhLEVBQUMsVUFBUyxFQUFDLEdBQUUsQ0FBQyxJQUFFLENBQUMsR0FBRSxLQUFHQSxFQUFFLENBQUMsSUFBRSxLQUFLLGFBQWEsRUFBQyxPQUFNLEVBQUMsR0FBRSxDQUFDLElBQUUsQ0FBQyxHQUFFLEtBQUdBLEVBQUUsQ0FBQyxJQUFFLEtBQUssYUFBYSxFQUFDLE1BQUssRUFBQyxHQUFFLENBQUMsSUFBRSxDQUFDLEdBQUUsQ0FBQyxJQUFHLE1BQUksRUFBRSxJQUFFLEVBQUUsaUJBQWUsT0FBSyxJQUFFLElBQUcsRUFBRSxNQUFNLEdBQUUsQ0FBQyxJQUFHLE1BQUksRUFBRSxJQUFFLEVBQUUsaUJBQWUsT0FBSyxJQUFFLElBQUcsRUFBRSxVQUFRLENBQUMsQ0FBQyxHQUFFLENBQUMsSUFBRyxNQUFJLEVBQUUsSUFBRSxFQUFFLGlCQUFlLE9BQUssSUFBRSxJQUFHLEVBQUUsVUFBUSxDQUFDLENBQUMsR0FBRSxDQUFDLElBQUcsTUFBSSxFQUFFLElBQUUsRUFBRSxpQkFBZSxPQUFLLElBQUUsSUFBRyxFQUFFLFVBQVEsQ0FBQyxDQUFDLEdBQUUsQ0FBQyxJQUFHLE1BQUksRUFBRSxJQUFFLEdBQUcsaUJBQWUsT0FBSyxJQUFFLElBQUcsR0FBRyxVQUFRLENBQUMsQ0FBQyxHQUFFLENBQUMsSUFBRyxNQUFJLEVBQUUsSUFBRSxHQUFHLGlCQUFlLE9BQUssSUFBRSxJQUFHLEdBQUcsVUFBUSxDQUFDLENBQUMsR0FBRSxDQUFDLElBQUcsTUFBSSxFQUFFLElBQUUsR0FBRyxpQkFBZSxPQUFLLElBQUUsSUFBRyxHQUFHLFVBQVEsQ0FBQyxDQUFDO0dBQUUsSUFBRSxLQUFLLGFBQWEsR0FBRSxJQUFHLFNBQVEsWUFBVyxHQUFFLEdBQUUsQ0FBQyxHQUFFLElBQUU7R0FBNkgsSUFBRSxHQUFySCxLQUFLLGFBQWEsR0FBRSxHQUFHLEtBQUssTUFBSyxTQUFRLFlBQVcsR0FBRSxHQUFFLENBQWlFLElBQTNELEtBQUssYUFBYSxHQUFFLEdBQUcsTUFBSyxRQUFPLFlBQVcsR0FBRSxHQUFFLENBQWMsS0FBSSxNQUFFLENBQUMsbUJBQUcsSUFBSSxJQUFJO0lBQUMsR0FBRztJQUFHLEdBQUc7SUFBRyxHQUFHO0dBQUUsQ0FBQyxDQUFDO0dBQStKLElBQUUsR0FBeEosS0FBSyxhQUFhLEdBQUUsR0FBRyxLQUFLLEdBQUcscUJBQW9CLFNBQVEsWUFBVyxHQUFFLEdBQUUsQ0FBa0YsSUFBNUUsS0FBSyxhQUFhLEdBQUUsR0FBRyxHQUFHLG9CQUFtQixRQUFPLFlBQVcsR0FBRSxHQUFFLENBQWMsS0FBSSxJQUFFLENBQUMsbUJBQUcsSUFBSSxJQUFJO0lBQUMsR0FBRztJQUFHLEdBQUc7SUFBRyxHQUFHO0dBQUUsQ0FBQyxDQUFDLEdBQUUsSUFBRUMsSUFBRyxFQUFFLEtBQUksRUFBQyxJQUFHLEVBQUMsQ0FBQztFQUFDO0VBQUMsT0FBTTtHQUFDLFdBQVU7SUFBQyxLQUFJO0lBQUUsUUFBTztHQUFDO0dBQUUsVUFBUztJQUFDLEtBQUk7SUFBRSxRQUFPRjtHQUFDO0dBQUUsUUFBTztJQUFDLEtBQUk7SUFBRSxRQUFPO0dBQUM7R0FBRSxPQUFNO0VBQUM7Q0FBQztDQUFFLFVBQVUsRUFBQyxNQUFLLElBQUUsSUFBRyxRQUFPLElBQUUsQ0FBQyxHQUFFLFNBQVEsR0FBRSxRQUFPLEdBQUUsS0FBSSxHQUFFLFVBQVMsR0FBRSxVQUFTLEdBQUUsb0JBQW1CLEtBQUc7RUFBQyxJQUFJLEdBQUUsR0FBRSxHQUFFO0VBQUUsSUFBSSxHQUFFLEdBQUVBO0VBQUUsSUFBR0MsRUFBRSxDQUFDLE9BQUssSUFBRSxLQUFHLE9BQUssS0FBSyxJQUFFLEVBQUUsaUJBQWUsUUFBTSxLQUFHLElBQUc7R0FBQyxJQUFJLElBQUUsRUFBRSxRQUFRLGNBQWEsRUFBRSxHQUFFLElBQUUsR0FBRSxFQUFDLGFBQVksR0FBRSxRQUFPLEdBQUUsS0FBSSxNQUFHLEdBQUUsSUFBRSxFQUFFLEdBQUU7SUFBQztJQUFjO0lBQVM7R0FBSyxDQUFDLEdBQUUsSUFBRSxLQUFHLENBQUMsR0FBRSxFQUFDLGFBQVksTUFBRyxHQUFFLElBQUUsRUFBRSxHQUFFLENBQUMsYUFBYSxDQUFDLEdBQUUsSUFBRSxLQUFHLENBQUMsR0FBRSxFQUFDLE1BQUssTUFBRyxHQUFFLElBQUUsRUFBRSxHQUFFLENBQUMsTUFBTSxDQUFDLEdBQUUsSUFBRSxLQUFHLENBQUMsR0FBRSxFQUFDLE1BQUssT0FBSSxHQUFFLElBQUUsRUFBRSxHQUFFLENBQUMsTUFBTSxDQUFDLEdBQUUsSUFBRUEsRUFBRSxDQUFDLElBQUUsS0FBSyxhQUFhLEdBQUUsSUFBRyxFQUFFLEVBQUUsQ0FBQyxHQUFFLENBQUMsR0FBRSxDQUFDLEVBQUMsR0FBRSxDQUFDLElBQUUsQ0FBQyxHQUFFLElBQUVBLEVBQUUsQ0FBQyxJQUFFLEtBQUssYUFBYSxHQUFFLElBQUcsRUFBRSxFQUFFLENBQUMsR0FBRSxDQUFDLEdBQUUsQ0FBQyxFQUFDLEdBQUUsQ0FBQyxJQUFFLENBQUMsR0FBRSxJQUFFQSxFQUFFLENBQUMsSUFBRSxLQUFLLGFBQWEsR0FBRSxJQUFHLEVBQUUsRUFBRSxDQUFDLEdBQUUsQ0FBQyxHQUFFLEVBQUUsRUFBQyxHQUFFLENBQUMsSUFBRSxDQUFDLEdBQUUsQ0FBQyxHQUFFLEtBQUcsRUFBRSxJQUFFLEVBQUUsaUJBQWUsT0FBSyxJQUFFLElBQUcsRUFBRSxVQUFRLENBQUMsQ0FBQyxHQUFFLENBQUMsR0FBRSxLQUFHLEVBQUUsSUFBRSxFQUFFLGlCQUFlLE9BQUssSUFBRSxJQUFHLEVBQUUsVUFBUSxDQUFDLENBQUMsR0FBRSxDQUFDLEdBQUUsS0FBRyxFQUFFLElBQUUsRUFBRSxpQkFBZSxPQUFLLElBQUUsSUFBRyxFQUFFLFVBQVEsQ0FBQyxDQUFDO0dBQW1ILElBQUUsR0FBakgsS0FBSyxhQUFhLEdBQUUsR0FBRyxJQUFJLEtBQUksU0FBUSxZQUFXLEdBQUUsR0FBRSxHQUFFLENBQTRELElBQXRELEtBQUssYUFBYSxHQUFFLEdBQUUsUUFBTyxZQUFXLEdBQUUsR0FBRSxHQUFFLENBQWEsS0FBSSxJQUFFLENBQUMsbUJBQUcsSUFBSSxJQUFJO0lBQUMsR0FBRztJQUFFLEdBQUc7SUFBRSxHQUFHO0dBQUMsQ0FBQyxDQUFDLEdBQUUsTUFBRUMsSUFBRyxHQUFFLEVBQUMsSUFBRyxFQUFDLENBQUM7RUFBQztFQUFDLE9BQU07R0FBQyxLQUFJO0dBQUUsUUFBTztHQUFFLE9BQU1GO0VBQUM7Q0FBQztDQUFFLGtCQUFrQixHQUFFLEdBQUU7RUFBQyxJQUFHLEVBQUUsRUFBRSxLQUFHLFFBQU0sRUFBRSxXQUFTLENBQUMsSUFBRyxPQUFNLGlCQUFpQixFQUFFO0NBQUc7Q0FBRSxXQUFXLEVBQUMsTUFBSyxJQUFFLElBQUcsT0FBTSxJQUFFLENBQUMsR0FBRSxRQUFPLEdBQUUsS0FBSSxHQUFFLFVBQVMsS0FBRztFQUFDLElBQUk7RUFBRSxJQUFHLEVBQUMsUUFBTyxHQUFFLFNBQVEsTUFBRyxHQUFFLEtBQUcsSUFBRSxLQUFHLE9BQUssS0FBSyxJQUFFLEVBQUUsZUFBYSxPQUFLLEtBQUssSUFBRSxFQUFFLElBQUcsSUFBRSxLQUFLLGtCQUFrQixHQUFFLENBQUM7RUFBRSxPQUFPLEtBQUssVUFBVTtHQUFDLE1BQUs7R0FBRSxRQUFPO0dBQUUsU0FBUTtHQUFFLFFBQU87R0FBRSxLQUFJO0dBQUUsVUFBUztHQUFFLFVBQVM7RUFBQyxDQUFDO0NBQUM7Q0FBRSxXQUFXLEVBQUMsTUFBSyxJQUFFLElBQUcsT0FBTSxJQUFFLENBQUMsR0FBRSxRQUFPLEdBQUUsS0FBSSxHQUFFLFVBQVMsS0FBRztFQUFDLElBQUksR0FBRTtFQUFFLElBQUksSUFBRSxFQUFFLFFBQVEsY0FBYSxFQUFFLEdBQUUsRUFBQyxRQUFPLEdBQUUsU0FBUSxNQUFHLEdBQUUsTUFBSSxJQUFFLEtBQUcsT0FBSyxLQUFLLElBQUUsRUFBRSxlQUFhLE9BQUssS0FBSyxJQUFFLEVBQUUsU0FBTyxJQUFFLEtBQUcsT0FBSyxLQUFLLElBQUUsRUFBRSxlQUFhLE9BQUssS0FBSyxJQUFFLEVBQUUsS0FBSSxJQUFFLEtBQUssa0JBQWtCLEdBQUUsQ0FBQztFQUFFLE9BQU8sS0FBSyxVQUFVO0dBQUMsTUFBSztHQUFFLFFBQU87R0FBRSxTQUFRO0dBQUUsUUFBTztHQUFFLEtBQUk7R0FBRSxVQUFTO0dBQUUsVUFBUztFQUFDLENBQUM7Q0FBQztDQUFFLHFCQUFxQixHQUFFO0VBQUMsSUFBSSxJQUFFLEVBQUU7RUFBaUIsT0FBTSxFQUFFLE1BQUksVUFBUSxNQUFJLENBQUM7Q0FBRTtDQUFFLHFCQUFxQixHQUFFLEdBQUU7RUFBQyxJQUFJO0VBQUUsT0FBTyxLQUFLLHFCQUFxQixDQUFDLElBQUUsS0FBSyxNQUFNLFFBQVEsRUFBRSxxQkFBbUIsQ0FBQyxJQUFFLEVBQUUsUUFBUSxvQkFBa0IsSUFBRSxFQUFFLHFCQUFtQixPQUFLLElBQUUsRUFBRSxRQUFRLGdCQUFnQixJQUFFLENBQUM7Q0FBQztDQUFFLGNBQWMsR0FBRSxJQUFFLENBQUMsR0FBRSxHQUFFLEdBQUU7RUFBQyxJQUFHLEVBQUMsVUFBUyxNQUFHO0VBQUUsT0FBTyxJQUFFLFVBQVVFLElBQUcsRUFBRSxTQUFPLEVBQUUsUUFBTSxXQUFVLENBQUMsTUFBSTtDQUFFO0NBQUUsb0JBQW9CLEVBQUMsTUFBSyxJQUFFLElBQUcsT0FBTSxJQUFFLENBQUMsR0FBRSxRQUFPTixLQUFFLE9BQU0sSUFBRSxDQUFDLEdBQUUsS0FBSSxHQUFFLFVBQVMsS0FBRztFQUFDLElBQUksSUFBRSxLQUFLLFVBQVU7R0FBQyxNQUFLO0dBQUUsT0FBTTtHQUFFLFFBQU9BO0dBQUUsS0FBSTtHQUFFLFVBQVM7RUFBQyxDQUFDLEdBQUUsSUFBRSxPQUFPLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFFLENBQUMsR0FBRSxRQUFNLEVBQUUsS0FBSyxHQUFHLEVBQUUsSUFBSU8sRUFBRyxDQUFDLEVBQUUsRUFBRSxHQUFFLElBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUc7RUFBRSxPQUFPLE9BQU8sUUFBUSxLQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFFLENBQUMsR0FBRSxPQUFLO0dBQUMsSUFBR0MsRUFBRyxDQUFDLEtBQUcsT0FBTyxPQUFPLEdBQUUsS0FBSyxHQUFFO0lBQUMsSUFBSSxJQUFFQyxFQUFHLEVBQUUsR0FBRyxHQUFFLElBQUUsR0FBRyxFQUFFO0lBQVksRUFBRSxLQUFLLGtEQUFrRCxFQUFFLElBQUksRUFBRSxHQUFHLEVBQUUsU0FBUztHQUFDO0dBQUMsT0FBTztFQUFDLEdBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7Q0FBQztDQUFFLGNBQWMsRUFBQyxNQUFLLElBQUUsSUFBRyxPQUFNLElBQUUsQ0FBQyxHQUFFLFFBQU8sR0FBRSxPQUFNLElBQUUsQ0FBQyxHQUFFLEtBQUksR0FBRSxVQUFTLEtBQUc7RUFBQyxJQUFJO0VBQUUsSUFBSSxJQUFFO0dBQUMsTUFBSztHQUFFLE9BQU07R0FBRSxRQUFPO0dBQUUsS0FBSTtHQUFFLFVBQVM7RUFBQyxHQUFFLEtBQUcsSUFBRSxFQUFFLFNBQVMsWUFBWSxJQUFFLEtBQUssV0FBVyxDQUFDLElBQUUsS0FBSyxXQUFXLENBQUMsTUFBSSxPQUFLLEtBQUssSUFBRSxFQUFFLEtBQUksSUFBRSxPQUFPLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUSxHQUFFLENBQUMsR0FBRSxRQUFNLEVBQUUsS0FBSyxHQUFHLEVBQUUsSUFBSUYsRUFBRyxDQUFDLEVBQUUsRUFBRSxHQUFFLElBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUc7RUFBRSxPQUFPLElBQUUsa0RBQWtELEVBQUUsY0FBYyxFQUFFLEdBQUdFLEVBQUcsQ0FBQyxFQUFFLFlBQVU7Q0FBRTtDQUFFLGFBQWEsSUFBRSxDQUFDLEdBQUUsR0FBRSxNQUFFLElBQUcsSUFBRSxJQUFHLElBQUUsQ0FBQyxHQUFFO0VBQUMsSUFBSSxJQUFFLFNBQVMsR0FBRSxHQUFFLEdBQUUsR0FBRTtHQUFDLE9BQU8sRUFBRSxRQUFRLElBQUUsTUFBRztJQUFDLElBQUk7SUFBRSxJQUFJLElBQUUsRUFBRSxNQUFNLEdBQUUsRUFBRSxHQUFFLElBQUUsS0FBSyxPQUFPO0lBQUcsSUFBRyxDQUFDLEdBQUUsT0FBTyxRQUFRLEtBQUssNkJBQTZCLEdBQUcsR0FBRTtJQUFpQixJQUFJLElBQUUsRUFBRSxTQUFTLEdBQUUsR0FBRSxDQUFDO0lBQUUsSUFBRyxNQUFNLFFBQVEsQ0FBQyxLQUFHLEVBQUUsV0FBUyxHQUFFO0tBQUMsSUFBSSxJQUFFLEVBQUUsRUFBRSxDQUFDLE9BQU0sSUFBRSxFQUFFLEVBQUUsQ0FBQztLQUFNLE9BQU8sTUFBSSxJQUFFLEtBQUcsT0FBSyxJQUFFLG1CQUFpQixjQUFjLEVBQUUsR0FBRyxFQUFFO0lBQUU7SUFBQyxRQUFPLElBQUUsS0FBRyxPQUFLLEtBQUssSUFBRSxFQUFFLFVBQVEsT0FBSyxJQUFFO0dBQWdCLENBQUM7RUFBQyxHQUFFLElBQUUsU0FBUyxHQUFFLEdBQUUsR0FBRSxHQUFFO0dBQUMsSUFBRyxFQUFFLFFBQVEsYUFBYSxNQUFJLElBQUcsT0FBTztHQUFFLElBQUksSUFBRSxDQUFDLEdBQUUsSUFBRSxFQUFFLFFBQU8sSUFBRTtHQUFFLE9BQUssSUFBRSxJQUFHO0lBQUMsSUFBSSxJQUFFLEVBQUUsUUFBUSxlQUFjLENBQUM7SUFBRSxJQUFHLE1BQUksSUFBRztLQUFDLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0tBQUU7SUFBSztJQUFDLEVBQUUsS0FBSyxFQUFFLE1BQU0sR0FBRSxDQUFDLENBQUM7SUFBRSxJQUFJLElBQUUsR0FBRSxJQUFFLElBQUUsSUFBRyxJQUFFO0lBQUcsT0FBSyxJQUFFLEtBQUcsSUFBRSxJQUFHO0tBQUMsSUFBSSxJQUFFLEVBQUUsV0FBVyxDQUFDO0tBQUUsTUFBSSxLQUFHLE1BQUksTUFBSSxLQUFHLE1BQUksTUFBSSxNQUFJLE1BQUksS0FBRyxNQUFJLE9BQUssSUFBRSxJQUFHO0lBQUc7SUFBQyxJQUFHLE1BQUksS0FBRyxNQUFJLElBQUc7S0FBQyxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztLQUFFO0lBQUs7SUFBQyxJQUFJLElBQUUsRUFBRSxNQUFNLElBQUUsSUFBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUUsSUFBRSxFQUFFLE1BQU0sSUFBRSxHQUFFLElBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFFLElBQUUsS0FBRyxNQUFJLFNBQU8sSUFBRTtJQUFLLElBQUcsTUFBSSxTQUFRLEVBQUUsS0FBSyxFQUFFLEtBQUssTUFBSyxHQUFFLFNBQVEsR0FBRSxDQUFDLENBQUM7U0FBTyxJQUFHLE1BQUksUUFBTyxFQUFFLEtBQUssRUFBRSxLQUFLLE1BQUssR0FBRSxRQUFPLEdBQUUsQ0FBQyxDQUFDO1NBQU07S0FBQyxJQUFJLElBQUUsRUFBRSxLQUFLLE1BQUssRUFBRSxLQUFLLE1BQUssR0FBRSxTQUFRLEdBQUUsQ0FBQyxHQUFFLFNBQVEsR0FBRSxDQUFDLEdBQUUsSUFBRSxFQUFFLEtBQUssTUFBSyxFQUFFLEtBQUssTUFBSyxHQUFFLFFBQU8sR0FBRSxDQUFDLEdBQUUsUUFBTyxHQUFFLENBQUM7S0FBRSxFQUFFLEtBQUssTUFBSSxJQUFFLElBQUUsY0FBYyxFQUFFLEdBQUcsRUFBRSxFQUFFO0lBQUM7SUFBQyxJQUFFO0dBQUM7R0FBQyxPQUFPLEVBQUUsS0FBSyxFQUFFO0VBQUMsR0FBRSxJQUFFLFNBQVMsR0FBRSxJQUFFLENBQUMsR0FBRSxJQUFFLENBQUMsR0FBRTtHQUFDLElBQUcsRUFBRSxTQUFTLEtBQUssSUFBSSxHQUFFLE9BQU8sUUFBUSxLQUFLLGtDQUFrQyxLQUFLLE1BQU0sR0FBRTtJQUFDLGFBQVk7SUFBRSxNQUFLLEtBQUs7SUFBSyxPQUFNO0lBQUUsT0FBTSxLQUFLO0dBQUM7R0FBRSxFQUFFLEtBQUssS0FBSyxJQUFJLEdBQUUsRUFBRSxPQUFLLEtBQUssTUFBSyxFQUFFLFlBQVUsRUFBRSxVQUFRLENBQUM7R0FBRyxJQUFJLElBQUUsS0FBSztHQUFNLElBQUcsT0FBTyxLQUFLLFNBQU8sVUFBUztJQUFDLElBQUksSUFBRSxLQUFLLE1BQU0sS0FBSyxHQUFFLElBQUUsRUFBRSxRQUFRLGFBQWEsTUFBSSxJQUFHLElBQUUsRUFBRSxRQUFRLEdBQUcsTUFBSTtJQUFHLElBQUcsS0FBRyxHQUFFO0tBQUMsSUFBSSxJQUFFLElBQUUsRUFBRSxLQUFLLE1BQUssR0FBRSxHQUFFLEdBQUUsQ0FBQyxJQUFFLEdBQUUsSUFBRSxFQUFFLFFBQVEsR0FBRyxNQUFJLEtBQUcsRUFBRSxLQUFLLE1BQUssR0FBRSxHQUFFLEdBQUUsQ0FBQyxJQUFFO0tBQUUsR0FBRyxZQUFVLEdBQUUsR0FBRyxZQUFVLEdBQUUsSUFBRSxHQUFHLEtBQUssRUFBRSxRQUFRLElBQUcsR0FBRyxDQUFDLElBQUUsUUFBUSxFQUFFLEtBQUc7SUFBQztHQUFDO0dBQUMsT0FBT0MsSUFBRyxFQUFFLE9BQU8sS0FBRyxPQUFPLEVBQUUsU0FBUSxFQUFFLElBQUksR0FBRTtJQUFDLGFBQVk7SUFBRSxNQUFLLEtBQUs7SUFBSyxPQUFNO0lBQUUsT0FBTSxPQUFPLEtBQUcsWUFBVSxFQUFFLFFBQVEsZ0JBQWdCLE1BQUksS0FBRyxLQUFLLElBQUU7R0FBQztFQUFDLEdBQUUsS0FBRyxHQUFFLEdBQUUsTUFBSTtHQUFDLE9BQU8sUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRSxPQUFLO0lBQUMsSUFBSSxJQUFFQyxJQUFHLEdBQUUsRUFBRSxTQUFTLGdCQUFnQixJQUFFLElBQUUsSUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUMsTUFBSSxFQUFFLENBQUMsR0FBRSxJQUFFLElBQUUsR0FBRyxFQUFFLEdBQUcsTUFBSTtJQUFFLEVBQUcsQ0FBQyxJQUFFLEVBQUUsR0FBRSxHQUFFLENBQUMsS0FBRyxFQUFFLE9BQUssRUFBRSxLQUFHO0tBQUMsT0FBTSxDQUFDO0tBQUUsV0FBVSxHQUFFLElBQUUsQ0FBQyxHQUFFLElBQUUsQ0FBQyxNQUFJO01BQUMsSUFBSSxJQUFFLEVBQUUsRUFBRSxDQUFDO01BQU0sSUFBRyxFQUFFLFdBQVMsR0FBRTtPQUFDLElBQUksSUFBRSxFQUFFLElBQUcsSUFBRSxFQUFFLFdBQVMsU0FBTyxFQUFFLFNBQU87T0FBRSxPQUFPLEVBQUUsU0FBUyxHQUFFLEVBQUUsU0FBUSxDQUFDO01BQUMsT0FBTSxJQUFHLEtBQUcsTUFBSSxRQUFPLEtBQUksSUFBSSxJQUFFLEdBQUUsSUFBRSxFQUFFLFFBQU8sS0FBSTtPQUFDLElBQUksSUFBRSxFQUFFO09BQUcsSUFBRyxFQUFFLFdBQVMsR0FBRSxPQUFPLEVBQUUsU0FBUyxHQUFFLEVBQUUsU0FBUSxDQUFDO01BQUM7TUFBQyxPQUFPLEVBQUUsS0FBSSxNQUFHLEVBQUUsU0FBUyxFQUFFLFFBQU8sRUFBRSxFQUFFLFNBQVEsQ0FBQyxDQUFDO0tBQUM7SUFBQyxJQUFHLEVBQUUsRUFBRSxDQUFDLE1BQU0sS0FBSztLQUFDLE1BQUs7S0FBRSxPQUFNO0tBQUUsUUFBTyxFQUFFLFNBQVMsbUJBQW1CLElBQUUsVUFBUSxFQUFFLFNBQVMsa0JBQWtCLElBQUUsU0FBTztLQUFPLFVBQVM7S0FBRSxRQUFPO0lBQUMsQ0FBQztHQUFFLENBQUM7RUFBQztFQUFFLE9BQU8sRUFBRSxHQUFFWCxLQUFFLENBQUMsR0FBRTtDQUFDO0NBQUUsY0FBYyxHQUFFLEdBQUUsR0FBRTtFQUFDLElBQUksR0FBRSxHQUFFO0VBQUUsSUFBSSxJQUFFLEVBQUU7RUFBUSxNQUFJLG9CQUFFLElBQUksSUFBRSxHQUFFLE9BQU8sZUFBZSxHQUFFLFdBQVU7R0FBQyxPQUFNO0dBQUUsWUFBVyxDQUFDO0dBQUUsY0FBYSxDQUFDO0VBQUMsQ0FBQztFQUFHLElBQUksSUFBRSxFQUFFLElBQUksQ0FBQztFQUFFLElBQUcsTUFBSSxLQUFLLEtBQUcsRUFBRSxJQUFJLENBQUMsR0FBRSxPQUFPO0VBQUUsSUFBSSxJQUFFLEVBQUUsU0FBUyxrQkFBaUIsSUFBRSxFQUFFLE1BQU0sR0FBRyxHQUFFLElBQUUsQ0FBQztFQUFFLEtBQUksSUFBSSxJQUFFLEdBQUUsSUFBRSxFQUFFLFFBQU8sS0FBSTtHQUFDLElBQUksSUFBRSxFQUFFO0dBQUcsRUFBRSxZQUFVLEdBQUUsRUFBRSxLQUFLLEVBQUUsWUFBWSxDQUFDLEtBQUcsRUFBRSxLQUFLLENBQUM7RUFBQztFQUFDLElBQUksSUFBRSxFQUFFLEtBQUssR0FBRyxHQUFFLElBQUUsRUFBRSxRQUFRLG1CQUFtQixNQUFJLEtBQUcsVUFBUSxFQUFFLFFBQVEsa0JBQWtCLE1BQUksS0FBRyxTQUFPLEtBQUssR0FBRSxJQUFFLEVBQUU7RUFBRyxJQUFHLENBQUMsR0FBRTtHQUFDLEVBQUUsSUFBSSxHQUFFLEtBQUssQ0FBQztHQUFFO0VBQU07RUFBQyxJQUFJO0VBQUUsSUFBRyxHQUFFO0dBQUMsSUFBSSxJQUFFLEVBQUUsU0FBUyxDQUFDO0dBQUUsSUFBRyxNQUFNLFFBQVEsQ0FBQyxHQUFPO1NBQUEsSUFBSSxJQUFFLEdBQUUsSUFBRSxFQUFFLFFBQU8sS0FBSSxNQUFLLElBQUUsRUFBRSxPQUFLLE9BQUssS0FBSyxJQUFFLEVBQUUsaUJBQWUsR0FBRTtLQUFDLElBQUUsRUFBRSxFQUFFLENBQUM7S0FBTTtJQUFLO1VBQU8sSUFBRSxLQUFHLE9BQUssS0FBSyxJQUFFLEVBQUU7RUFBSyxPQUFLO0dBQUMsSUFBSSxJQUFFLEVBQUUsU0FBUyxPQUFPLEdBQUUsSUFBRSxFQUFFLFNBQVMsTUFBTSxHQUFFLEdBQUU7R0FBRSxJQUFHLE1BQU0sUUFBUSxDQUFDLEdBQU87U0FBQSxJQUFJLElBQUUsR0FBRSxJQUFFLEVBQUUsUUFBTyxLQUFJLE1BQUssSUFBRSxFQUFFLE9BQUssT0FBSyxLQUFLLElBQUUsRUFBRSxpQkFBZSxTQUFRO0tBQUMsSUFBRSxFQUFFLEVBQUUsQ0FBQztLQUFNO0lBQUs7VUFBTyxJQUFFLEtBQUcsT0FBSyxLQUFLLElBQUUsRUFBRTtHQUFNLElBQUcsTUFBTSxRQUFRLENBQUMsR0FBTztTQUFBLElBQUksSUFBRSxHQUFFLElBQUUsRUFBRSxRQUFPLEtBQUksTUFBSyxJQUFFLEVBQUUsT0FBSyxPQUFLLEtBQUssSUFBRSxFQUFFLGlCQUFlLFFBQU87S0FBQyxJQUFFLEVBQUUsRUFBRSxDQUFDO0tBQU07SUFBSztVQUFPLElBQUUsS0FBRyxPQUFLLEtBQUssSUFBRSxFQUFFO0dBQU0sTUFBSSxLQUFLLEtBQUcsTUFBSSxLQUFLLElBQUUsSUFBRSxLQUFLLElBQUUsTUFBSSxLQUFLLElBQUUsSUFBRSxJQUFFLE1BQUksS0FBSyxLQUFHLE1BQUksSUFBRSxJQUFFLElBQUUsSUFBRSxjQUFjLEVBQUUsR0FBRyxFQUFFO0VBQUU7RUFBQyxPQUFPLEVBQUUsSUFBSSxHQUFFLENBQUMsR0FBRTtDQUFDO0NBQUUsZ0JBQWdCLEdBQUUsR0FBRSxHQUFFLEdBQUUsSUFBRSxlQUFjO0VBQUMsT0FBTyxNQUFJLFdBQVMsTUFBSSxTQUFPLEVBQUVLLEVBQUUsQ0FBQyxJQUFFLEdBQUcsSUFBSSxFQUFFLEdBQUcsRUFBRSxHQUFHLE1BQUksR0FBRSxDQUFDLElBQUUsRUFBRSxHQUFFLEVBQUUsS0FBRyxPQUFLLElBQUUsR0FBRSxDQUFDLENBQUM7Q0FBQztDQUFFLGFBQWEsR0FBRSxHQUFFLEtBQUUsR0FBRSxJQUFFLENBQUMsR0FBRSxHQUFFLEdBQUUsR0FBRTtFQUFDLElBQUksR0FBRTtFQUFFLElBQUdBLEVBQUUsQ0FBQyxHQUFFO0dBQUMsSUFBRyxFQUFDLFVBQVNELFFBQUc7R0FBRSxJQUFHLE1BQUksU0FBUTtJQUFDLElBQUksSUFBRSxLQUFLLHFCQUFxQixHQUFFLENBQUMsR0FBRSxLQUFHLEtBQUcsSUFBRSxLQUFHLE9BQUssS0FBSyxJQUFFLEVBQUUsYUFBVyxPQUFLLEtBQUssSUFBRSxFQUFFLGFBQVcsT0FBSyxJQUFFO0lBQWMsSUFBRUosUUFBSSxTQUFPLEVBQUUsUUFBUSxHQUFFLEVBQUMsTUFBSyxHQUFFLFVBQVMsU0FBTUssRUFBRSxDQUFDLE1BQUksS0FBRyxFQUFFLFNBQVMsT0FBTyxJQUFFLEVBQUUsUUFBUSxTQUFRLENBQUMsSUFBRSxLQUFLLGdCQUFnQixHQUFFLEdBQUUsR0FBRSxHQUFFLENBQUMsSUFBRyxJQUFHLEVBQUUsSUFBRSxFQUFFLEtBQUcsT0FBSyxJQUFFLEdBQUUsQ0FBQztHQUFDO0dBQUMsSUFBR0QsS0FBRTtJQUFDLElBQUksSUFBRTtLQUFDLE1BQUs7S0FBVSxPQUFNO0lBQVM7SUFBRSxFQUFHQSxHQUFDLE1BQUksRUFBRSxPQUFLRSxJQUFHRixJQUFFLE1BQUs7S0FBQyxNQUFLO0tBQUUsTUFBSztJQUFDLENBQUMsSUFBR0MsRUFBRSxFQUFFLElBQUksTUFBSSxJQUFFLEVBQUUsVUFBVSxFQUFFLFFBQU8sQ0FBQyxHQUFFLEdBQVcsV0FBVyxFQUFFLElBQUk7R0FBRTtHQUFDLE9BQU87RUFBQztFQUFDLE9BQU07Q0FBRTtBQUFDO0FBQUUsSUFBSSxJQUFFO0NBQUMsVUFBUztFQUFDLFVBQVM7R0FBQyxRQUFPO0dBQUksVUFBUztHQUFjLGtCQUFpQjtFQUErRztFQUFFLFNBQVE7R0FBQyxRQUFPO0dBQUksa0JBQWlCO0dBQVMsVUFBUyxDQUFDO0dBQUUsY0FBYSxDQUFDO0dBQUUsUUFBTyxDQUFDO0VBQUM7Q0FBQztDQUFFLFFBQU8sS0FBSztDQUFFLDZCQUFZLElBQUksSUFBRTtDQUFFLG1DQUFrQixJQUFJLElBQUU7Q0FBRSxnQ0FBZSxJQUFJLElBQUU7Q0FBRSxTQUFRLENBQUM7Q0FBRSxtQ0FBa0IsSUFBSSxJQUFFO0NBQUUsT0FBTyxJQUFFLENBQUMsR0FBRTtFQUFDLElBQUcsRUFBQyxPQUFNLE1BQUc7RUFBRSxNQUFJLEtBQUssU0FBTyxFQUFFLEVBQUUsQ0FBQyxHQUFFLENBQUMsR0FBRSxFQUFDLFNBQVEsRUFBRSxFQUFFLENBQUMsR0FBRSxLQUFLLFNBQVMsT0FBTyxHQUFFLEVBQUUsT0FBTyxFQUFDLENBQUMsR0FBRSxLQUFLLFVBQVEsRUFBRSxhQUFhLEtBQUssUUFBTyxLQUFLLFFBQVEsR0FBRSxLQUFLLFlBQVk7Q0FBRTtDQUFFLElBQUksUUFBTztFQUFDLE9BQU8sS0FBSztDQUFNO0NBQUUsSUFBSSxTQUFRO0VBQUMsSUFBSTtFQUFFLFNBQVEsSUFBRSxLQUFLLFVBQVEsT0FBSyxLQUFLLElBQUUsRUFBRSxXQUFTLENBQUM7Q0FBQztDQUFFLElBQUksVUFBUztFQUFDLElBQUk7RUFBRSxTQUFRLElBQUUsS0FBSyxVQUFRLE9BQUssS0FBSyxJQUFFLEVBQUUsWUFBVSxDQUFDO0NBQUM7Q0FBRSxJQUFJLFNBQVE7RUFBQyxPQUFPLEtBQUs7Q0FBTztDQUFFLG1CQUFtQixHQUFFO0VBQUMsT0FBTyxLQUFLLGtCQUFrQixJQUFJLENBQUM7Q0FBQztDQUFFLHNCQUFxQjtFQUFDLE9BQU0sQ0FBQyxHQUFHLEtBQUssaUJBQWlCO0NBQUM7Q0FBRSxlQUFlLEdBQUU7RUFBQyxJQUFJLElBQUUsQ0FBQztFQUFFLE9BQU8sS0FBRyxPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsVUFBUU8sSUFBRyxDQUFDLENBQUMsQ0FBQyxTQUFRLE1BQUc7R0FBQyxJQUFJLElBQUVDLEdBQUcsQ0FBQztHQUFFLEtBQUssa0JBQWtCLElBQUksQ0FBQyxNQUFJLEtBQUssa0JBQWtCLElBQUksQ0FBQyxHQUFFLElBQUUsQ0FBQztFQUFFLENBQUMsR0FBRTtDQUFDO0NBQUUsd0JBQXVCO0VBQUMsS0FBSyxrQkFBa0IsTUFBTTtDQUFDO0NBQUUsV0FBVTtFQUFDLE9BQU8sS0FBSztDQUFLO0NBQUUsU0FBUyxHQUFFO0VBQUMsS0FBSyxPQUFPLEVBQUMsT0FBTSxFQUFDLENBQUMsR0FBRSxFQUFFLEtBQUssZ0JBQWUsQ0FBQztDQUFDO0NBQUUsWUFBVztFQUFDLE9BQU8sS0FBSztDQUFNO0NBQUUsVUFBVSxHQUFFO0VBQUMsS0FBSyxTQUFPLEVBQUUsRUFBRSxDQUFDLEdBQUUsS0FBSyxLQUFLLEdBQUUsRUFBQyxRQUFPLEVBQUMsQ0FBQyxHQUFFLEtBQUssVUFBUSxFQUFFLGFBQWEsR0FBRSxLQUFLLFFBQVEsR0FBRSxLQUFLLFlBQVksR0FBRSxFQUFFLEtBQUssaUJBQWdCLENBQUMsR0FBRSxFQUFFLEtBQUssZ0JBQWUsS0FBSyxLQUFLO0NBQUM7Q0FBRSxhQUFZO0VBQUMsT0FBTyxLQUFLO0NBQU87Q0FBRSxXQUFXLEdBQUU7RUFBQyxLQUFLLFNBQU8sRUFBRSxFQUFFLENBQUMsR0FBRSxLQUFLLEtBQUssR0FBRSxFQUFDLFNBQVEsRUFBQyxDQUFDLEdBQUUsS0FBSyxpQkFBaUIsR0FBRSxFQUFFLEtBQUssa0JBQWlCLENBQUMsR0FBRSxFQUFFLEtBQUssZ0JBQWUsS0FBSyxLQUFLO0NBQUM7Q0FBRSxtQkFBa0I7RUFBQyxLQUFLLHNCQUFzQixHQUFFLEtBQUssZ0JBQWdCO0NBQUM7Q0FBRSxjQUFhO0VBQUMsS0FBSyxpQkFBaUIsR0FBRSxLQUFLLHNCQUFzQjtDQUFDO0NBQUUsZ0JBQWU7RUFBQyxPQUFNLENBQUMsR0FBRyxLQUFLLFdBQVc7Q0FBQztDQUFFLGNBQWMsR0FBRTtFQUFDLEtBQUssWUFBWSxJQUFJLENBQUM7Q0FBQztDQUFFLGtCQUFpQjtFQUFDLEtBQUssWUFBWSxNQUFNO0NBQUM7Q0FBRSxzQkFBcUI7RUFBQyxPQUFPLEtBQUs7Q0FBaUI7Q0FBRSxrQkFBa0IsR0FBRTtFQUFDLE9BQU8sS0FBSyxrQkFBa0IsSUFBSSxDQUFDO0NBQUM7Q0FBRSxtQkFBbUIsR0FBRTtFQUFDLEtBQUssa0JBQWtCLElBQUksQ0FBQztDQUFDO0NBQUUsc0JBQXNCLEdBQUU7RUFBQyxLQUFLLGtCQUFrQixPQUFPLENBQUM7Q0FBQztDQUFFLHdCQUF1QjtFQUFDLEtBQUssa0JBQWtCLE1BQU07Q0FBQztDQUFFLGNBQWMsR0FBRTtFQUFDLE9BQU8sRUFBRSxjQUFjLEtBQUssUUFBTyxHQUFFLEtBQUssUUFBUTtDQUFDO0NBQUUsVUFBVSxJQUFFLElBQUcsR0FBRTtFQUFDLE9BQU8sRUFBRSxVQUFVO0dBQUMsTUFBSztHQUFFLE9BQU0sS0FBSztHQUFNLFFBQU87R0FBRSxVQUFTLEtBQUs7R0FBUyxLQUFJLEVBQUMsWUFBVyxLQUFLLGNBQWMsS0FBSyxJQUFJLEVBQUM7RUFBQyxDQUFDO0NBQUM7Q0FBRSxhQUFhLElBQUUsSUFBRyxHQUFFO0VBQUMsSUFBSSxJQUFFO0dBQUMsTUFBSztHQUFFLE9BQU0sS0FBSztHQUFNLFFBQU87R0FBRSxVQUFTLEtBQUs7R0FBUyxLQUFJLEVBQUMsWUFBVyxLQUFLLGNBQWMsS0FBSyxJQUFJLEVBQUM7RUFBQztFQUFFLE9BQU8sRUFBRSxXQUFXLENBQUM7Q0FBQztDQUFFLGFBQWEsSUFBRSxJQUFHLEdBQUU7RUFBQyxJQUFJLElBQUU7R0FBQyxNQUFLO0dBQUUsT0FBTSxLQUFLO0dBQU0sUUFBTztHQUFFLFVBQVMsS0FBSztHQUFTLEtBQUksRUFBQyxZQUFXLEtBQUssY0FBYyxLQUFLLElBQUksRUFBQztFQUFDO0VBQUUsT0FBTyxFQUFFLFdBQVcsQ0FBQztDQUFDO0NBQUUsZ0JBQWdCLElBQUUsSUFBRyxHQUFFLEdBQUUsR0FBRTtFQUFDLElBQUksSUFBRTtHQUFDLE1BQUs7R0FBRSxRQUFPO0dBQUUsU0FBUSxLQUFLO0dBQVEsVUFBUztHQUFFLFFBQU87R0FBRSxVQUFTLEtBQUs7R0FBUyxLQUFJLEVBQUMsWUFBVyxLQUFLLGNBQWMsS0FBSyxJQUFJLEVBQUM7R0FBRSxvQkFBbUIsQ0FBQztFQUFDO0VBQUUsT0FBTyxFQUFFLFVBQVUsQ0FBQztDQUFDO0NBQUUsaUJBQWlCLElBQUUsSUFBRztFQUFDLE9BQU8sRUFBRSxjQUFjLEdBQUUsS0FBSyxTQUFRLEVBQUMsT0FBTSxLQUFLLGNBQWMsRUFBQyxHQUFFLEtBQUssUUFBUTtDQUFDO0NBQUUsYUFBYSxJQUFFLElBQUcsR0FBRSxJQUFFLFNBQVEsR0FBRTtFQUFDLE9BQU8sRUFBRSxhQUFhLEdBQUUsR0FBRSxHQUFFLEdBQUUsS0FBSyxTQUFRLEVBQUMsWUFBVyxLQUFLLGNBQWMsS0FBSyxJQUFJLEVBQUMsR0FBRSxLQUFLLFFBQVE7Q0FBQztDQUFFLG9CQUFvQixJQUFFLElBQUcsR0FBRSxJQUFFLENBQUMsR0FBRTtFQUFDLE9BQU8sRUFBRSxvQkFBb0I7R0FBQyxNQUFLO0dBQUUsT0FBTSxLQUFLO0dBQU0sUUFBTztHQUFFLE9BQU07R0FBRSxVQUFTLEtBQUs7R0FBUyxLQUFJLEVBQUMsWUFBVyxLQUFLLGNBQWMsS0FBSyxJQUFJLEVBQUM7RUFBQyxDQUFDO0NBQUM7Q0FBRSxjQUFjLEdBQUUsR0FBRSxJQUFFLENBQUMsR0FBRTtFQUFDLE9BQU8sRUFBRSxjQUFjO0dBQUMsTUFBSztHQUFFLE9BQU0sS0FBSztHQUFNLFFBQU87R0FBRSxPQUFNO0dBQUUsVUFBUyxLQUFLO0dBQVMsS0FBSSxFQUFDLFlBQVcsS0FBSyxjQUFjLEtBQUssSUFBSSxFQUFDO0VBQUMsQ0FBQztDQUFDO0NBQUUsZUFBZSxHQUFFO0VBQUMsS0FBSyxlQUFlLElBQUksQ0FBQztDQUFDO0NBQUUsZUFBZSxHQUFFO0VBQUMsS0FBSyxlQUFlLElBQUksQ0FBQztDQUFDO0NBQUUsY0FBYyxHQUFFLEVBQUMsTUFBSyxLQUFHO0VBQUMsS0FBSyxlQUFlLFNBQU8sS0FBSyxlQUFlLE9BQU8sQ0FBQyxHQUFFLEVBQUUsS0FBSyxTQUFTLEVBQUUsUUFBTyxDQUFDLEdBQUUsS0FBSyxlQUFlLFFBQU0sRUFBRSxLQUFLLFlBQVk7Q0FBRTtBQUFDOzs7QUNBNTRwQixJQUFJLFFBQU07OztBQ0dWLFNBQVNDLFVBQVEsR0FBRztDQUFFO0NBQTJCLE9BQU8sWUFBVSxjQUFjLE9BQU8sVUFBVSxZQUFZLE9BQU8sT0FBTyxXQUFXLFNBQVUsR0FBRztFQUFFLE9BQU8sT0FBTztDQUFHLElBQUksU0FBVSxHQUFHO0VBQUUsT0FBTyxLQUFLLGNBQWMsT0FBTyxVQUFVLEVBQUUsZ0JBQWdCLFVBQVUsTUFBTSxPQUFPLFlBQVksV0FBVyxPQUFPO0NBQUcsR0FBR0EsVUFBUSxDQUFDO0FBQUc7QUFDN1QsU0FBU0MsVUFBUSxHQUFHLEdBQUc7Q0FBRSxJQUFJLElBQUksT0FBTyxLQUFLLENBQUM7Q0FBRyxJQUFJLE9BQU8sdUJBQXVCO0VBQUUsSUFBSSxJQUFJLE9BQU8sc0JBQXNCLENBQUM7RUFBRyxNQUFNLElBQUksRUFBRSxPQUFPLFNBQVUsR0FBRztHQUFFLE9BQU8sT0FBTyx5QkFBeUIsR0FBRyxDQUFDLENBQUMsQ0FBQztFQUFZLENBQUMsSUFBSSxFQUFFLEtBQUssTUFBTSxHQUFHLENBQUM7Q0FBRztDQUFFLE9BQU87QUFBRztBQUM5UCxTQUFTQyxnQkFBYyxHQUFHO0NBQUUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxLQUFLO0VBQUUsSUFBSSxJQUFJLFFBQVEsVUFBVSxLQUFLLFVBQVUsS0FBSyxDQUFDO0VBQUcsSUFBSSxJQUFJRCxVQUFRLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLFFBQVEsU0FBVSxHQUFHO0dBQUUsa0JBQWdCLEdBQUcsR0FBRyxFQUFFLEVBQUU7RUFBRyxDQUFDLElBQUksT0FBTyw0QkFBNEIsT0FBTyxpQkFBaUIsR0FBRyxPQUFPLDBCQUEwQixDQUFDLENBQUMsSUFBSUEsVUFBUSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxTQUFVLEdBQUc7R0FBRSxPQUFPLGVBQWUsR0FBRyxHQUFHLE9BQU8seUJBQXlCLEdBQUcsQ0FBQyxDQUFDO0VBQUcsQ0FBQztDQUFHO0NBQUUsT0FBTztBQUFHO0FBQ3hiLFNBQVNFLGtCQUFnQixHQUFHLEdBQUcsR0FBRztDQUFFLFFBQVEsSUFBSUMsaUJBQWUsQ0FBQyxNQUFNLElBQUksT0FBTyxlQUFlLEdBQUcsR0FBRztFQUFFLE9BQU87RUFBRyxZQUFZO0VBQU0sY0FBYztFQUFNLFVBQVU7Q0FBSyxDQUFDLElBQUksRUFBRSxLQUFLLEdBQUc7QUFBRztBQUN6TCxTQUFTQSxpQkFBZSxHQUFHO0NBQUUsSUFBSSxJQUFJQyxlQUFhLEdBQUcsUUFBUTtDQUFHLE9BQU8sWUFBWUwsVUFBUSxDQUFDLElBQUksSUFBSSxJQUFJO0FBQUk7QUFDNUcsU0FBU0ssZUFBYSxHQUFHLEdBQUc7Q0FBRSxJQUFJLFlBQVlMLFVBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxPQUFPO0NBQUcsSUFBSSxJQUFJLEVBQUUsT0FBTztDQUFjLElBQUksS0FBSyxNQUFNLEdBQUc7RUFBRSxJQUFJLElBQUksRUFBRSxLQUFLLEdBQUcsQ0FBQztFQUFHLElBQUksWUFBWUEsVUFBUSxDQUFDLEdBQUcsT0FBTztFQUFHLE1BQU0sSUFBSSxVQUFVLDhDQUE4QztDQUFHO0NBQUUsUUFBUSxhQUFhLElBQUksU0FBUyxPQUFBLENBQVEsQ0FBQztBQUFHO0FBQzlTLFNBQVMsYUFBYSxJQUFJO0NBQ3hCLElBQUksT0FBTyxVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sS0FBQSxJQUFZLFVBQVUsS0FBSztDQUMvRSxJQUFJLG1CQUFtQixLQUFLLG1CQUFtQixDQUFDLENBQUMsWUFBWSxVQUFVLEVBQUU7TUFBTyxJQUFJLE1BQU0sR0FBRztNQUFPLFNBQVMsRUFBRTtBQUNqSDtBQUNBLElBQUksTUFBTTtBQUNWLFNBQVMsU0FBUyxLQUFLO0NBQ3JCLElBQUksVUFBVSxVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sS0FBQSxJQUFZLFVBQVUsS0FBSyxDQUFDO0NBQ25GLElBQUksV0FBVyxJQUFJLEtBQUs7Q0FDeEIsSUFBSSxTQUFTLElBQUksR0FBRztDQUNwQixJQUFJLFdBQVcsSUFBSSxJQUFJO0NBQ3ZCLElBQUksa0JBQWtCTSxHQUFTLElBQUksT0FBTyxXQUFXLEtBQUE7Q0FDckQsSUFBSSxvQkFBb0IsUUFBUSxVQUM5QixXQUFXLHNCQUFzQixLQUFLLElBQUksa0JBQWtCLG1CQUM1RCxxQkFBcUIsUUFBUSxXQUM3QixZQUFZLHVCQUF1QixLQUFLLElBQUksT0FBTyxvQkFDbkQsa0JBQWtCLFFBQVEsUUFDMUIsU0FBUyxvQkFBb0IsS0FBSyxJQUFJLFFBQVEsaUJBQzlDLGdCQUFnQixRQUFRLE1BQ3hCLE9BQU8sa0JBQWtCLEtBQUssSUFBSSxTQUFTLE9BQU8sRUFBRSxHQUFHLElBQUksZUFDM0QsY0FBYyxRQUFRLElBQ3RCLEtBQUssZ0JBQWdCLEtBQUssSUFBSSxLQUFBLElBQVksYUFDMUMsaUJBQWlCLFFBQVEsT0FDekIsUUFBUSxtQkFBbUIsS0FBSyxJQUFJLEtBQUEsSUFBWSxnQkFDaEQsaUJBQWlCLFFBQVEsT0FDekIsUUFBUSxtQkFBbUIsS0FBSyxJQUFJLEtBQUEsSUFBWSxnQkFDaEQsaUJBQWlCLFFBQVEsT0FDekIsUUFBUSxtQkFBbUIsS0FBSyxJQUFJLFFBQVEsZ0JBQzVDLHFCQUFxQixRQUFRLFdBQzdCLGlCQUFpQix1QkFBdUIsS0FBSyxJQUFJLEtBQUEsSUFBWSxvQkFDN0QscUJBQXFCLFFBQVEsV0FDN0IsaUJBQWlCLHVCQUF1QixLQUFLLElBQUksS0FBQSxJQUFZLG9CQUM3RCxrQkFBa0IsUUFBUSxRQUMxQixnQkFBZ0Isb0JBQW9CLEtBQUssSUFBSSxLQUFBLElBQVksaUJBQ3pELGlCQUFpQixRQUFRLE9BQ3pCLFFBQVEsbUJBQW1CLEtBQUssSUFBSSxDQUFDLElBQUk7Q0FDM0MsSUFBSSxPQUFPLFNBQVMsT0FBTyxDQUFDO0NBRzVCLElBQUksT0FBTyxTQUFTLEtBQUssTUFBTTtFQUM3QixJQUFJLFNBQVMsVUFBVSxTQUFTLEtBQUssVUFBVSxPQUFPLEtBQUEsSUFBWSxVQUFVLEtBQUssQ0FBQztFQUNsRixJQUFJLENBQUMsVUFBVTtFQUNmLElBQUksY0FBY0osZ0JBQWNBLGdCQUFjLENBQUMsR0FBRyxLQUFLLEdBQUcsTUFBTTtFQUNoRSxJQUFJLFFBQVEsWUFBWSxRQUFRLE1BQzlCLE1BQU0sWUFBWSxNQUFNLElBQ3hCLFNBQVMsWUFBWSxTQUFTO0VBQ2hDLFNBQVMsUUFBUSxTQUFTLGNBQWMsa0NBQWtDLE9BQU8sT0FBTyxLQUFLLENBQUMsS0FBSyxTQUFTLGVBQWUsR0FBRyxLQUFLLFNBQVMsY0FBYyxPQUFPO0VBQ2pLLElBQUksQ0FBQyxTQUFTLE1BQU0sYUFBYTtHQUMvQixPQUFPLFFBQVEsUUFBUTtHQUN2QixJQUFjLFNBQVMsT0FBTztJQUM1QixNQUFNO0lBQ04sSUFBSTtJQUNHO0lBQ1AsT0FBTztHQUNULENBQUM7R0FDRCxRQUFRLFNBQVMsS0FBSyxRQUFRLFNBQVMsS0FBSyxJQUFJLFNBQVMsS0FBSyxZQUFZLFNBQVMsS0FBSztHQUN4RixHQUFhLFNBQVMsT0FBTywwQkFBMEIsS0FBSztHQUM1RCxJQUFjLFNBQVMsT0FBTyxXQUFXO0dBQ3pDLFNBQVMsTUFBTSxTQUFTLFNBQVUsT0FBTztJQUN2QyxPQUFPLGtCQUFrQixRQUFRLGtCQUFrQixLQUFLLElBQUksS0FBSyxJQUFJLGNBQWMsT0FBTyxFQUN4RixNQUFNLE1BQ1IsQ0FBQztHQUNIO0dBQ0EsbUJBQW1CLFFBQVEsbUJBQW1CLEtBQUssS0FBSyxlQUFlLEtBQUs7RUFDOUU7RUFDQSxJQUFJLFNBQVMsT0FBTztFQUNwQixPQUFPLE1BQU0sUUFBUSxTQUFVLE9BQU87R0FDcEMsU0FBUyxNQUFNLGNBQWM7R0FDN0IsbUJBQW1CLFFBQVEsbUJBQW1CLEtBQUssS0FBSyxlQUFlLEtBQUs7RUFDOUUsR0FBRyxFQUNELFdBQVcsS0FDYixDQUFDO0VBQ0QsU0FBUyxRQUFRO0NBQ25CO0NBQ0EsSUFBSSxTQUFTLFNBQVMsU0FBUztFQUM3QixJQUFJLENBQUMsWUFBWSxDQUFDLFNBQVMsT0FBTztFQUNsQyxLQUFLO0VBQ0wsRUFBUSxTQUFTLEtBQUssS0FBSyxTQUFTLEtBQUssWUFBWSxTQUFTLEtBQUs7RUFDbkUsU0FBUyxRQUFRO0VBQ2pCLFNBQVMsUUFBUTtDQUNuQjtDQUNBLElBQUksYUFBYSxDQUFDLFFBQVEsYUFBYSxJQUFJO0NBSzNDLE9BQU87RUFDRDtFQUNFO0VBQ04sSUFBSTtFQUNKLEtBQUs7RUFDRztFQUNGO0VBQ04sVUFBVSxTQUFTLFFBQVE7Q0FDN0I7QUFDRjs7O0FDbEdBLFNBQVMsUUFBUSxHQUFHO0NBQUU7Q0FBMkIsT0FBTyxVQUFVLGNBQWMsT0FBTyxVQUFVLFlBQVksT0FBTyxPQUFPLFdBQVcsU0FBVSxHQUFHO0VBQUUsT0FBTyxPQUFPO0NBQUcsSUFBSSxTQUFVLEdBQUc7RUFBRSxPQUFPLEtBQUssY0FBYyxPQUFPLFVBQVUsRUFBRSxnQkFBZ0IsVUFBVSxNQUFNLE9BQU8sWUFBWSxXQUFXLE9BQU87Q0FBRyxHQUFHLFFBQVEsQ0FBQztBQUFHO0FBQzdULElBQUk7QUFBaUIsSUFBQTtBQUFrQixJQUFBO0FBQWtCLElBQUE7QUFDekQsU0FBUyxlQUFlLEdBQUcsR0FBRztDQUFFLE9BQU8sZ0JBQWdCLENBQUMsS0FBSyxzQkFBc0IsR0FBRyxDQUFDLEtBQUssNEJBQTRCLEdBQUcsQ0FBQyxLQUFLLGlCQUFpQjtBQUFHO0FBQ3JKLFNBQVMsbUJBQW1CO0NBQUUsTUFBTSxJQUFJLFVBQVUsMklBQTJJO0FBQUc7QUFDaE0sU0FBUyw0QkFBNEIsR0FBRyxHQUFHO0NBQUUsSUFBSSxHQUFHO0VBQUUsSUFBSSxZQUFZLE9BQU8sR0FBRyxPQUFPLGtCQUFrQixHQUFHLENBQUM7RUFBRyxJQUFJLElBQUksQ0FBQyxFQUFFLFNBQVMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRTtFQUFHLE9BQU8sYUFBYSxLQUFLLEVBQUUsZ0JBQWdCLElBQUksRUFBRSxZQUFZLE9BQU8sVUFBVSxLQUFLLFVBQVUsSUFBSSxNQUFNLEtBQUssQ0FBQyxJQUFJLGdCQUFnQixLQUFLLDJDQUEyQyxLQUFLLENBQUMsSUFBSSxrQkFBa0IsR0FBRyxDQUFDLElBQUksS0FBSztDQUFHO0FBQUU7QUFDelgsU0FBUyxrQkFBa0IsR0FBRyxHQUFHO0NBQUUsQ0FBQyxRQUFRLEtBQUssSUFBSSxFQUFFLFlBQVksSUFBSSxFQUFFO0NBQVMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLE1BQU0sQ0FBQyxHQUFHLElBQUksR0FBRyxLQUFLLEVBQUUsS0FBSyxFQUFFO0NBQUksT0FBTztBQUFHO0FBQ25KLFNBQVMsc0JBQXNCLEdBQUcsR0FBRztDQUFFLElBQUksSUFBSSxRQUFRLElBQUksT0FBTyxlQUFlLE9BQU8sVUFBVSxFQUFFLE9BQU8sYUFBYSxFQUFFO0NBQWUsSUFBSSxRQUFRLEdBQUc7RUFBRSxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsSUFBSSxNQUFNLElBQUk7RUFBTyxJQUFJO0dBQUUsSUFBSSxLQUFLLElBQUksRUFBRSxLQUFLLENBQUMsRUFBQSxDQUFHLE1BQU0sTUFBTTtRQUFVLE9BQU8sRUFBRSxLQUFLLElBQUksRUFBRSxLQUFLLENBQUMsRUFBQSxDQUFHLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxHQUFHLEVBQUUsV0FBVyxJQUFJLElBQUksQ0FBQztFQUFJLFNBQVMsR0FBRztHQUFFLElBQUksTUFBTSxJQUFJO0VBQUcsVUFBVTtHQUFFLElBQUk7SUFBRSxJQUFJLENBQUMsS0FBSyxRQUFRLEVBQUUsY0FBYyxJQUFJLEVBQUUsU0FBUyxDQUFDLEdBQUcsT0FBTyxDQUFDLE1BQU0sSUFBSTtHQUFRLFVBQVU7SUFBRSxJQUFJLEdBQUcsTUFBTTtHQUFHO0VBQUU7RUFBRSxPQUFPO0NBQUc7QUFBRTtBQUN6ZixTQUFTLGdCQUFnQixHQUFHO0NBQUUsSUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHLE9BQU87QUFBRztBQUM5RCxTQUFTLFFBQVEsR0FBRyxHQUFHO0NBQUUsSUFBSSxJQUFJLE9BQU8sS0FBSyxDQUFDO0NBQUcsSUFBSSxPQUFPLHVCQUF1QjtFQUFFLElBQUksSUFBSSxPQUFPLHNCQUFzQixDQUFDO0VBQUcsTUFBTSxJQUFJLEVBQUUsT0FBTyxTQUFVLEdBQUc7R0FBRSxPQUFPLE9BQU8seUJBQXlCLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFBWSxDQUFDLElBQUksRUFBRSxLQUFLLE1BQU0sR0FBRyxDQUFDO0NBQUc7Q0FBRSxPQUFPO0FBQUc7QUFDOVAsU0FBUyxjQUFjLEdBQUc7Q0FBRSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxRQUFRLEtBQUs7RUFBRSxJQUFJLElBQUksUUFBUSxVQUFVLEtBQUssVUFBVSxLQUFLLENBQUM7RUFBRyxJQUFJLElBQUksUUFBUSxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxRQUFRLFNBQVUsR0FBRztHQUFFLGdCQUFnQixHQUFHLEdBQUcsRUFBRSxFQUFFO0VBQUcsQ0FBQyxJQUFJLE9BQU8sNEJBQTRCLE9BQU8saUJBQWlCLEdBQUcsT0FBTywwQkFBMEIsQ0FBQyxDQUFDLElBQUksUUFBUSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxTQUFVLEdBQUc7R0FBRSxPQUFPLGVBQWUsR0FBRyxHQUFHLE9BQU8seUJBQXlCLEdBQUcsQ0FBQyxDQUFDO0VBQUcsQ0FBQztDQUFHO0NBQUUsT0FBTztBQUFHO0FBQ3hiLFNBQVMsZ0JBQWdCLEdBQUcsR0FBRyxHQUFHO0NBQUUsUUFBUSxJQUFJLGVBQWUsQ0FBQyxNQUFNLElBQUksT0FBTyxlQUFlLEdBQUcsR0FBRztFQUFFLE9BQU87RUFBRyxZQUFZO0VBQU0sY0FBYztFQUFNLFVBQVU7Q0FBSyxDQUFDLElBQUksRUFBRSxLQUFLLEdBQUc7QUFBRztBQUN6TCxTQUFTLGVBQWUsR0FBRztDQUFFLElBQUksSUFBSSxhQUFhLEdBQUcsUUFBUTtDQUFHLE9BQU8sWUFBWSxRQUFRLENBQUMsSUFBSSxJQUFJLElBQUk7QUFBSTtBQUM1RyxTQUFTLGFBQWEsR0FBRyxHQUFHO0NBQUUsSUFBSSxZQUFZLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxPQUFPO0NBQUcsSUFBSSxJQUFJLEVBQUUsT0FBTztDQUFjLElBQUksS0FBSyxNQUFNLEdBQUc7RUFBRSxJQUFJLElBQUksRUFBRSxLQUFLLEdBQUcsQ0FBQztFQUFHLElBQUksWUFBWSxRQUFRLENBQUMsR0FBRyxPQUFPO0VBQUcsTUFBTSxJQUFJLFVBQVUsOENBQThDO0NBQUc7Q0FBRSxRQUFRLGFBQWEsSUFBSSxTQUFTLE9BQUEsQ0FBUSxDQUFDO0FBQUc7QUFDOVMsU0FBUyx1QkFBdUIsR0FBRyxHQUFHO0NBQUUsT0FBTyxNQUFNLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSSxPQUFPLE9BQU8sT0FBTyxpQkFBaUIsR0FBRyxFQUFFLEtBQUssRUFBRSxPQUFPLE9BQU8sT0FBTyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFBRztBQU92SixJQUFJLFlBQVk7Q0FDZCxNQUFNO0NBQ04sS0FBSyxTQVJZLElBQUksTUFBTTtFQUMzQixJQUFJLEtBQUssS0FBSztFQUNkLE9BQU8seVVBQXlVLE9BQU8sR0FBRyxpQkFBaUIsR0FBRyxRQUFRO0NBQ3hYO0NBTVM7Q0FDUCxTQUFTLENBQU07Q0FDZixjQUFjLENBQVc7Q0FDekIsTUFBTSxTQUFTLEtBQUssT0FBTztFQUN6QixJQUFJLFVBQVUsVUFBVSxTQUFTLEtBQUssVUFBVSxPQUFPLEtBQUEsSUFBWSxVQUFVLEtBQUssQ0FBQztFQUluRixJQUFJLGlCQUhZLFVBQVUsU0FBUyxLQUFLLFVBQVUsT0FBTyxLQUFBLElBQVksVUFBVSxLQUFLLFNBQVUsSUFBSTtHQUNoRyxPQUFPO0VBQ1QsRUFBQSxDQUM4QkssR0FBTSxvQkFBb0Isa0JBQWtCLHVCQUF1QixDQUFDLElBQUksRUFBRSxDQUFDLElBQUksS0FBSyxDQUFDO0VBQ25ILE9BQU9DLEVBQVcsYUFBYSxJQUFJLFNBQVNDLEVBQVUsYUFBYSxHQUFHLGNBQWMsRUFDbEYsTUFBTSxLQUFLLEtBQ2IsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDO0NBQ2xCO0NBQ0EsU0FBUyxTQUFTLFVBQVU7RUFDMUIsSUFBSSxVQUFVLFVBQVUsU0FBUyxLQUFLLFVBQVUsT0FBTyxLQUFBLElBQVksVUFBVSxLQUFLLENBQUM7RUFDbkYsT0FBTyxLQUFLLEtBQUssS0FBSyxLQUFLLE9BQU87Q0FDcEM7Q0FDQSxXQUFXLFNBQVMsWUFBWTtFQUM5QixJQUFJLFFBQVE7RUFDWixJQUFJLFVBQVUsVUFBVSxTQUFTLEtBQUssVUFBVSxPQUFPLEtBQUEsSUFBWSxVQUFVLEtBQUssQ0FBQztFQUNuRixJQUFJLFFBQVEsVUFBVSxTQUFTLEtBQUssVUFBVSxPQUFPLEtBQUEsSUFBWSxVQUFVLEtBQUs7RUFDaEYsT0FBTyxLQUFLLEtBQUssS0FBSyxPQUFPLFNBQVMsV0FBWTtHQUNoRCxJQUFJLGdCQUFnQixVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sS0FBQSxJQUFZLFVBQVUsS0FBSztHQUN4RixPQUFPQyxFQUFNLGFBQWEsUUFBUSxRQUFRLE1BQU0sTUFBTSxHQUFHLE9BQU8sYUFBYSxDQUFDLENBQUMsT0FBT0gsR0FBTSxxQkFBcUIsbUJBQW1CLHVCQUF1QixDQUFDLElBQUksRUFBRSxDQUFDLElBQUksS0FBSyxDQUFDLENBQUM7RUFDaEwsQ0FBQztDQUNIO0NBQ0EsZ0JBQWdCLFNBQVMsZUFBZSxRQUFRO0VBQzlDLE9BQU9HLEVBQU0sVUFBVSxLQUFLLE1BQU0sTUFBTTtDQUMxQztDQUNBLG1CQUFtQixTQUFTLGtCQUFrQixRQUFRO0VBQ3BELE9BQU9BLEVBQU0sYUFBYSxLQUFLLE1BQU0sTUFBTTtDQUM3QztDQUNBLG1CQUFtQixTQUFTLGtCQUFrQixRQUFRO0VBQ3BELE9BQU9BLEVBQU0sYUFBYSxLQUFLLE1BQU0sTUFBTTtDQUM3QztDQUNBLGdCQUFnQixTQUFTLGVBQWUsUUFBUSxVQUFVLFFBQVE7RUFDaEUsT0FBT0EsRUFBTSxnQkFBZ0IsS0FBSyxNQUFNLFFBQVEsVUFBVSxNQUFNO0NBQ2xFO0NBQ0EsdUJBQXVCLFNBQVMsd0JBQXdCO0VBQ3RELE9BQU9BLEVBQU0saUJBQWlCLEtBQUssSUFBSTtDQUN6QztDQUNBLGVBQWUsU0FBUyxnQkFBZ0I7RUFDdEMsSUFBSSxjQUFjLFVBQVUsU0FBUyxLQUFLLFVBQVUsT0FBTyxLQUFBLElBQVksVUFBVSxLQUFLO0VBQ3RGLElBQUksUUFBUSxVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sS0FBQSxJQUFZLFVBQVUsS0FBSyxDQUFDO0VBQ2pGLElBQUksS0FBSyxLQUFLO0dBQ1osSUFBSSxPQUFPQyxJQUFRLEtBQUssS0FBSyxFQUMzQixJQUFJQyxFQUNOLENBQUMsS0FBSztHQUNOLElBQUksU0FBU0gsRUFBVUYsR0FBTSxxQkFBcUIsbUJBQW1CLHVCQUF1QjtJQUFDO0lBQUk7SUFBSTtHQUFFLENBQUMsSUFBSSxNQUFNLFdBQVcsQ0FBQztHQUM5SCxJQUFJLFNBQVMsT0FBTyxRQUFRLEtBQUssQ0FBQyxDQUFDLE9BQU8sU0FBVSxLQUFLLE9BQU87SUFDOUQsSUFBSSxRQUFRLGVBQWUsT0FBTyxDQUFDLEdBQ2pDLElBQUksTUFBTSxJQUNWLElBQUksTUFBTTtJQUNaLE9BQU8sSUFBSSxLQUFLLEdBQUcsT0FBTyxHQUFHLEtBQUssQ0FBQyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSztHQUMxRCxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHO0dBQ2YsT0FBT0MsRUFBVyxNQUFNLElBQUkscURBQXFELE9BQU8sS0FBSyxNQUFNLEtBQUssQ0FBQyxDQUFDLE9BQU8sUUFBUSxHQUFHLENBQUMsQ0FBQyxPQUFPLFFBQVEsVUFBVSxJQUFJO0VBQzdKO0VBQ0EsT0FBTztDQUNUO0NBQ0EsMEJBQTBCLFNBQVMseUJBQXlCLFFBQVE7RUFDbEUsSUFBSSxRQUFRLFVBQVUsU0FBUyxLQUFLLFVBQVUsT0FBTyxLQUFBLElBQVksVUFBVSxLQUFLLENBQUM7RUFDakYsT0FBT0UsRUFBTSxvQkFBb0IsS0FBSyxNQUFNLFFBQVEsS0FBSztDQUMzRDtDQUNBLG9CQUFvQixTQUFTLG1CQUFtQixRQUFRO0VBQ3RELElBQUksUUFBUSxVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sS0FBQSxJQUFZLFVBQVUsS0FBSyxDQUFDO0VBQ2pGLElBQUksTUFBTSxDQUFDQSxFQUFNLGNBQWMsS0FBSyxNQUFNLFFBQVEsS0FBSyxDQUFDO0VBQ3hELElBQUksS0FBSyxPQUFPO0dBQ2QsSUFBSSxPQUFPLEtBQUssU0FBUyxTQUFTLGlCQUFpQixHQUFHLE9BQU8sS0FBSyxNQUFNLFFBQVE7R0FDaEYsSUFBSSxPQUFPSCxHQUFNLHFCQUFxQixtQkFBbUIsdUJBQXVCLENBQUMsSUFBSSxFQUFFLENBQUMsSUFBSUksSUFBUSxLQUFLLE9BQU8sRUFDOUcsSUFBSUMsRUFDTixDQUFDLENBQUM7R0FDRixJQUFJLFNBQVNILEVBQVVDLEVBQU0sYUFBYSxNQUFNLElBQUksQ0FBQztHQUNyRCxJQUFJLFNBQVMsT0FBTyxRQUFRLEtBQUssQ0FBQyxDQUFDLE9BQU8sU0FBVSxLQUFLLE9BQU87SUFDOUQsSUFBSSxRQUFRLGVBQWUsT0FBTyxDQUFDLEdBQ2pDLElBQUksTUFBTSxJQUNWLElBQUksTUFBTTtJQUNaLE9BQU8sSUFBSSxLQUFLLEdBQUcsT0FBTyxHQUFHLEtBQUssQ0FBQyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSztHQUMxRCxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHO0dBQ2YsRUFBVyxNQUFNLEtBQUssSUFBSSxLQUFLLHFEQUFxRCxPQUFPLE1BQU0sS0FBSyxDQUFDLENBQUMsT0FBTyxRQUFRLEdBQUcsQ0FBQyxDQUFDLE9BQU8sUUFBUSxVQUFVLENBQUM7RUFDeEo7RUFDQSxPQUFPLElBQUksS0FBSyxFQUFFO0NBQ3BCO0NBQ0EsUUFBUSxTQUFTLE9BQU8sU0FBUztFQUMvQixPQUFPLGNBQWMsY0FBYyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRztHQUNoRCxLQUFLLEtBQUE7R0FDTCxPQUFPLEtBQUE7RUFDVCxHQUFHLE9BQU87Q0FDWjtBQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hHQSxTQUFTLDJCQUEyQjtDQUNsQyxJQUFJLE9BQU8sYUFBYSxhQUFhO0NBQ3JDLElBQUksU0FBUyxlQUFlLGdCQUFnQixHQUFHO0NBQy9DLElBQUksT0FBTyxTQUFTLGNBQWMsS0FBSztDQUN2QyxLQUFLLEtBQUs7Q0FDVixLQUFLLE1BQU0sVUFBVTtDQUNyQixJQUFJLFNBQVMsS0FBSyxhQUFhLEVBQzdCLE1BQU0sU0FDUixDQUFDO0NBQ0QsT0FBTyxZQUFZO0NBQ25CLFNBQVMsS0FBSyxZQUFZLElBQUk7QUFDaEMifQ==