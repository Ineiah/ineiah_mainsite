/*!
* message-compiler v11.4.8
* (c) 2026 kazuya kawaguchi
* Released under the MIT License.
*/
import { format, assign, join, isString } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@intlify+shared@11.4.8/node_modules/@intlify/shared/dist/shared.mjs?v=7e73afc2";
const LOCATION_STUB = {
	start: {
		line: 1,
		column: 1,
		offset: 0
	},
	end: {
		line: 1,
		column: 1,
		offset: 0
	}
};
function createPosition(line, column, offset) {
	return {
		line,
		column,
		offset
	};
}
function createLocation(start, end, source) {
	const loc = {
		start,
		end
	};
	if (source != null) {
		loc.source = source;
	}
	return loc;
}
const CompileErrorCodes = {
	// tokenizer error codes
	EXPECTED_TOKEN: 1,
	INVALID_TOKEN_IN_PLACEHOLDER: 2,
	UNTERMINATED_SINGLE_QUOTE_IN_PLACEHOLDER: 3,
	UNKNOWN_ESCAPE_SEQUENCE: 4,
	INVALID_UNICODE_ESCAPE_SEQUENCE: 5,
	UNBALANCED_CLOSING_BRACE: 6,
	UNTERMINATED_CLOSING_BRACE: 7,
	EMPTY_PLACEHOLDER: 8,
	NOT_ALLOW_NEST_PLACEHOLDER: 9,
	INVALID_LINKED_FORMAT: 10,
	// parser error codes
	MUST_HAVE_MESSAGES_IN_PLURAL: 11,
	UNEXPECTED_EMPTY_LINKED_MODIFIER: 12,
	UNEXPECTED_EMPTY_LINKED_KEY: 13,
	UNEXPECTED_LEXICAL_ANALYSIS: 14,
	// generator error codes
	UNHANDLED_CODEGEN_NODE_TYPE: 15,
	// minifier error codes
	UNHANDLED_MINIFIER_NODE_TYPE: 16
};
// Special value for higher-order compilers to pick up the last code
// to avoid collision of error codes.
// This should always be kept as the last item.
const COMPILE_ERROR_CODES_EXTEND_POINT = 17;
/** @internal */
const errorMessages = {
	// tokenizer error messages
	[CompileErrorCodes.EXPECTED_TOKEN]: `Expected token: '{0}'`,
	[CompileErrorCodes.INVALID_TOKEN_IN_PLACEHOLDER]: `Invalid token in placeholder: '{0}'`,
	[CompileErrorCodes.UNTERMINATED_SINGLE_QUOTE_IN_PLACEHOLDER]: `Unterminated single quote in placeholder`,
	[CompileErrorCodes.UNKNOWN_ESCAPE_SEQUENCE]: `Unknown escape sequence: \\{0}`,
	[CompileErrorCodes.INVALID_UNICODE_ESCAPE_SEQUENCE]: `Invalid unicode escape sequence: {0}`,
	[CompileErrorCodes.UNBALANCED_CLOSING_BRACE]: `Unbalanced closing brace`,
	[CompileErrorCodes.UNTERMINATED_CLOSING_BRACE]: `Unterminated closing brace`,
	[CompileErrorCodes.EMPTY_PLACEHOLDER]: `Empty placeholder`,
	[CompileErrorCodes.NOT_ALLOW_NEST_PLACEHOLDER]: `Not allowed nest placeholder`,
	[CompileErrorCodes.INVALID_LINKED_FORMAT]: `Invalid linked format`,
	// parser error messages
	[CompileErrorCodes.MUST_HAVE_MESSAGES_IN_PLURAL]: `Plural must have messages`,
	[CompileErrorCodes.UNEXPECTED_EMPTY_LINKED_MODIFIER]: `Unexpected empty linked modifier`,
	[CompileErrorCodes.UNEXPECTED_EMPTY_LINKED_KEY]: `Unexpected empty linked key`,
	[CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS]: `Unexpected lexical analysis in token: '{0}'`,
	// generator error messages
	[CompileErrorCodes.UNHANDLED_CODEGEN_NODE_TYPE]: `unhandled codegen node type: '{0}'`,
	// minimizer error messages
	[CompileErrorCodes.UNHANDLED_MINIFIER_NODE_TYPE]: `unhandled mimifier node type: '{0}'`
};
function createCompileError(code, loc, options = {}) {
	const { domain, messages, args } = options;
	const msg = "development" !== "production" ? format((messages || errorMessages)[code] || "", ...args || []) : code;
	const error = new SyntaxError(String(msg));
	error.code = code;
	if (loc) {
		error.location = loc;
	}
	error.domain = domain;
	return error;
}
/** @internal */
function defaultOnError(error) {
	throw error;
}
// eslint-disable-next-line no-useless-escape
const RE_HTML_TAG = /<\/?[\w\s="/.':;#-\/]+>/;
const detectHtmlTag = (source) => RE_HTML_TAG.test(source);
const CHAR_SP = " ";
const CHAR_CR = "\r";
const CHAR_LF = "\n";
const CHAR_LS = String.fromCharCode(8232);
const CHAR_PS = String.fromCharCode(8233);
function createScanner(str) {
	const _buf = str;
	let _index = 0;
	let _line = 1;
	let _column = 1;
	let _peekOffset = 0;
	const isCRLF = (index) => _buf[index] === CHAR_CR && _buf[index + 1] === CHAR_LF;
	const isLF = (index) => _buf[index] === CHAR_LF;
	const isPS = (index) => _buf[index] === CHAR_PS;
	const isLS = (index) => _buf[index] === CHAR_LS;
	const isLineEnd = (index) => isCRLF(index) || isLF(index) || isPS(index) || isLS(index);
	const index = () => _index;
	const line = () => _line;
	const column = () => _column;
	const peekOffset = () => _peekOffset;
	const charAt = (offset) => isCRLF(offset) || isPS(offset) || isLS(offset) ? CHAR_LF : _buf[offset];
	const currentChar = () => charAt(_index);
	const currentPeek = () => charAt(_index + _peekOffset);
	function next() {
		_peekOffset = 0;
		if (isLineEnd(_index)) {
			_line++;
			_column = 0;
		}
		if (isCRLF(_index)) {
			_index++;
		}
		_index++;
		_column++;
		return _buf[_index];
	}
	function peek() {
		if (isCRLF(_index + _peekOffset)) {
			_peekOffset++;
		}
		_peekOffset++;
		return _buf[_index + _peekOffset];
	}
	function reset() {
		_index = 0;
		_line = 1;
		_column = 1;
		_peekOffset = 0;
	}
	function resetPeek(offset = 0) {
		_peekOffset = offset;
	}
	function skipToPeek() {
		const target = _index + _peekOffset;
		while (target !== _index) {
			next();
		}
		_peekOffset = 0;
	}
	return {
		index,
		line,
		column,
		peekOffset,
		charAt,
		currentChar,
		currentPeek,
		next,
		peek,
		reset,
		resetPeek,
		skipToPeek
	};
}
const EOF = undefined;
const DOT = ".";
const LITERAL_DELIMITER = "'";
const ERROR_DOMAIN$3 = "tokenizer";
function createTokenizer(source, options = {}) {
	const location = options.location !== false;
	const _scnr = createScanner(source);
	const currentOffset = () => _scnr.index();
	const currentPosition = () => createPosition(_scnr.line(), _scnr.column(), _scnr.index());
	const _initLoc = currentPosition();
	const _initOffset = currentOffset();
	const _context = {
		currentType: 13,
		offset: _initOffset,
		startLoc: _initLoc,
		endLoc: _initLoc,
		lastType: 13,
		lastOffset: _initOffset,
		lastStartLoc: _initLoc,
		lastEndLoc: _initLoc,
		braceNest: 0,
		inLinked: false,
		text: ""
	};
	const context = () => _context;
	const { onError } = options;
	function emitError(code, pos, offset, ...args) {
		const ctx = context();
		pos.column += offset;
		pos.offset += offset;
		if (onError) {
			const loc = location ? createLocation(ctx.startLoc, pos) : null;
			const err = createCompileError(code, loc, {
				domain: ERROR_DOMAIN$3,
				args
			});
			onError(err);
		}
	}
	function getToken(context, type, value) {
		context.endLoc = currentPosition();
		context.currentType = type;
		const token = { type };
		if (location) {
			token.loc = createLocation(context.startLoc, context.endLoc);
		}
		if (value != null) {
			token.value = value;
		}
		return token;
	}
	const getEndToken = (context) => getToken(
		context,
		13
		/* TokenTypes.EOF */
	);
	function eat(scnr, ch) {
		if (scnr.currentChar() === ch) {
			scnr.next();
			return ch;
		} else {
			emitError(CompileErrorCodes.EXPECTED_TOKEN, currentPosition(), 0, ch);
			return "";
		}
	}
	function peekSpaces(scnr) {
		let buf = "";
		while (scnr.currentPeek() === CHAR_SP || scnr.currentPeek() === CHAR_LF) {
			buf += scnr.currentPeek();
			scnr.peek();
		}
		return buf;
	}
	function skipSpaces(scnr) {
		const buf = peekSpaces(scnr);
		scnr.skipToPeek();
		return buf;
	}
	function isIdentifierStart(ch) {
		if (ch === EOF) {
			return false;
		}
		const cc = ch.charCodeAt(0);
		return cc >= 97 && cc <= 122 || cc >= 65 && cc <= 90 || cc === 95;
	}
	function isNumberStart(ch) {
		if (ch === EOF) {
			return false;
		}
		const cc = ch.charCodeAt(0);
		return cc >= 48 && cc <= 57;
	}
	function isNamedIdentifierStart(scnr, context) {
		const { currentType } = context;
		if (currentType !== 2) {
			return false;
		}
		peekSpaces(scnr);
		const ret = isIdentifierStart(scnr.currentPeek());
		scnr.resetPeek();
		return ret;
	}
	function isListIdentifierStart(scnr, context) {
		const { currentType } = context;
		if (currentType !== 2) {
			return false;
		}
		peekSpaces(scnr);
		const ch = scnr.currentPeek() === "-" ? scnr.peek() : scnr.currentPeek();
		const ret = isNumberStart(ch);
		scnr.resetPeek();
		return ret;
	}
	function isLiteralStart(scnr, context) {
		const { currentType } = context;
		if (currentType !== 2) {
			return false;
		}
		peekSpaces(scnr);
		const ret = scnr.currentPeek() === LITERAL_DELIMITER;
		scnr.resetPeek();
		return ret;
	}
	function isLinkedDotStart(scnr, context) {
		const { currentType } = context;
		if (currentType !== 7) {
			return false;
		}
		peekSpaces(scnr);
		const ret = scnr.currentPeek() === ".";
		scnr.resetPeek();
		return ret;
	}
	function isLinkedModifierStart(scnr, context) {
		const { currentType } = context;
		if (currentType !== 8) {
			return false;
		}
		peekSpaces(scnr);
		const ret = isIdentifierStart(scnr.currentPeek());
		scnr.resetPeek();
		return ret;
	}
	function isLinkedDelimiterStart(scnr, context) {
		const { currentType } = context;
		if (!(currentType === 7 || currentType === 11)) {
			return false;
		}
		peekSpaces(scnr);
		const ret = scnr.currentPeek() === ":";
		scnr.resetPeek();
		return ret;
	}
	function isLinkedReferStart(scnr, context) {
		const { currentType } = context;
		if (currentType !== 9) {
			return false;
		}
		const fn = () => {
			const ch = scnr.currentPeek();
			if (ch === "{") {
				return isIdentifierStart(scnr.peek());
			} else if (ch === "@" || ch === "|" || ch === ":" || ch === "." || ch === CHAR_SP || !ch) {
				return false;
			} else if (ch === CHAR_LF) {
				scnr.peek();
				return fn();
			} else {
				// other characters
				return isTextStart(scnr, false);
			}
		};
		const ret = fn();
		scnr.resetPeek();
		return ret;
	}
	function isPluralStart(scnr) {
		peekSpaces(scnr);
		const ret = scnr.currentPeek() === "|";
		scnr.resetPeek();
		return ret;
	}
	function isTextStart(scnr, reset = true) {
		const fn = (hasSpace = false, prev = "") => {
			const ch = scnr.currentPeek();
			if (ch === "{") {
				return hasSpace;
			} else if (ch === "@" || !ch) {
				return hasSpace;
			} else if (ch === "|") {
				return !(prev === CHAR_SP || prev === CHAR_LF);
			} else if (ch === CHAR_SP) {
				scnr.peek();
				return fn(true, CHAR_SP);
			} else if (ch === CHAR_LF) {
				scnr.peek();
				return fn(true, CHAR_LF);
			} else {
				return true;
			}
		};
		const ret = fn();
		reset && scnr.resetPeek();
		return ret;
	}
	function takeChar(scnr, fn) {
		const ch = scnr.currentChar();
		if (ch === EOF) {
			return EOF;
		}
		if (fn(ch)) {
			scnr.next();
			return ch;
		}
		return null;
	}
	function isIdentifier(ch) {
		const cc = ch.charCodeAt(0);
		return cc >= 97 && cc <= 122 || cc >= 65 && cc <= 90 || cc >= 48 && cc <= 57 || cc === 95 || cc === 36;
	}
	function takeIdentifierChar(scnr) {
		return takeChar(scnr, isIdentifier);
	}
	function isNamedIdentifier(ch) {
		const cc = ch.charCodeAt(0);
		return cc >= 97 && cc <= 122 || cc >= 65 && cc <= 90 || cc >= 48 && cc <= 57 || cc === 95 || cc === 36 || cc === 45;
	}
	function takeNamedIdentifierChar(scnr) {
		return takeChar(scnr, isNamedIdentifier);
	}
	function isDigit(ch) {
		const cc = ch.charCodeAt(0);
		return cc >= 48 && cc <= 57;
	}
	function takeDigit(scnr) {
		return takeChar(scnr, isDigit);
	}
	function isHexDigit(ch) {
		const cc = ch.charCodeAt(0);
		return cc >= 48 && cc <= 57 || cc >= 65 && cc <= 70 || cc >= 97 && cc <= 102;
	}
	function takeHexDigit(scnr) {
		return takeChar(scnr, isHexDigit);
	}
	function getDigits(scnr) {
		let ch = "";
		let num = "";
		while (ch = takeDigit(scnr)) {
			num += ch;
		}
		return num;
	}
	function readText(scnr) {
		let buf = "";
		while (true) {
			const ch = scnr.currentChar();
			if (ch === "\\") {
				const nextCh = scnr.peek();
				if (nextCh === "{" || nextCh === "}" || nextCh === "@" || nextCh === "|" || nextCh === "\\") {
					buf += ch + nextCh;
					scnr.next();
					scnr.next();
				} else {
					scnr.resetPeek();
					buf += ch;
					scnr.next();
				}
			} else if (ch === "{" || ch === "}" || ch === "@" || ch === "|" || !ch) {
				break;
			} else if (ch === CHAR_SP || ch === CHAR_LF) {
				if (isTextStart(scnr)) {
					buf += ch;
					scnr.next();
				} else if (isPluralStart(scnr)) {
					break;
				} else {
					buf += ch;
					scnr.next();
				}
			} else {
				buf += ch;
				scnr.next();
			}
		}
		return buf;
	}
	function readNamedIdentifier(scnr) {
		skipSpaces(scnr);
		let ch = "";
		let name = "";
		while (ch = takeNamedIdentifierChar(scnr)) {
			name += ch;
		}
		// Check if takeNamedIdentifierChar stoped because of invalid characters
		const currentChar = scnr.currentChar();
		if (currentChar && currentChar !== "}" && currentChar !== EOF && currentChar !== CHAR_SP && currentChar !== CHAR_LF && currentChar !== "　") {
			const invalidPart = readInvalidIdentifier(scnr);
			emitError(CompileErrorCodes.INVALID_TOKEN_IN_PLACEHOLDER, currentPosition(), 0, name + invalidPart);
			return name + invalidPart;
		}
		if (scnr.currentChar() === EOF) {
			emitError(CompileErrorCodes.UNTERMINATED_CLOSING_BRACE, currentPosition(), 0);
		}
		return name;
	}
	function readListIdentifier(scnr) {
		skipSpaces(scnr);
		let value = "";
		if (scnr.currentChar() === "-") {
			scnr.next();
			value += `-${getDigits(scnr)}`;
		} else {
			value += getDigits(scnr);
		}
		if (scnr.currentChar() === EOF) {
			emitError(CompileErrorCodes.UNTERMINATED_CLOSING_BRACE, currentPosition(), 0);
		}
		return value;
	}
	function isLiteral(ch) {
		return ch !== LITERAL_DELIMITER && ch !== CHAR_LF;
	}
	function readLiteral(scnr) {
		skipSpaces(scnr);
		// eslint-disable-next-line no-useless-escape
		eat(scnr, `\'`);
		let ch = "";
		let literal = "";
		while (ch = takeChar(scnr, isLiteral)) {
			if (ch === "\\") {
				literal += readEscapeSequence(scnr);
			} else {
				literal += ch;
			}
		}
		const current = scnr.currentChar();
		if (current === CHAR_LF || current === EOF) {
			emitError(CompileErrorCodes.UNTERMINATED_SINGLE_QUOTE_IN_PLACEHOLDER, currentPosition(), 0);
			// TODO: Is it correct really?
			if (current === CHAR_LF) {
				scnr.next();
				// eslint-disable-next-line no-useless-escape
				eat(scnr, `\'`);
			}
			return literal;
		}
		// eslint-disable-next-line no-useless-escape
		eat(scnr, `\'`);
		return literal;
	}
	function readEscapeSequence(scnr) {
		const ch = scnr.currentChar();
		switch (ch) {
			case "\\":
			case `\'`:
				// eslint-disable-line no-useless-escape
				scnr.next();
				return `\\${ch}`;
			case "u": return readUnicodeEscapeSequence(scnr, ch, 4);
			case "U": return readUnicodeEscapeSequence(scnr, ch, 6);
			default:
				emitError(CompileErrorCodes.UNKNOWN_ESCAPE_SEQUENCE, currentPosition(), 0, ch);
				return "";
		}
	}
	function readUnicodeEscapeSequence(scnr, unicode, digits) {
		eat(scnr, unicode);
		let sequence = "";
		for (let i = 0; i < digits; i++) {
			const ch = takeHexDigit(scnr);
			if (!ch) {
				emitError(CompileErrorCodes.INVALID_UNICODE_ESCAPE_SEQUENCE, currentPosition(), 0, `\\${unicode}${sequence}${scnr.currentChar()}`);
				break;
			}
			sequence += ch;
		}
		return `\\${unicode}${sequence}`;
	}
	function isInvalidIdentifier(ch) {
		return ch !== "{" && ch !== "}" && ch !== CHAR_SP && ch !== CHAR_LF;
	}
	function readInvalidIdentifier(scnr) {
		skipSpaces(scnr);
		let ch = "";
		let identifiers = "";
		while (ch = takeChar(scnr, isInvalidIdentifier)) {
			identifiers += ch;
		}
		return identifiers;
	}
	function readLinkedModifier(scnr) {
		let ch = "";
		let name = "";
		while (ch = takeIdentifierChar(scnr)) {
			name += ch;
		}
		return name;
	}
	function readLinkedRefer(scnr) {
		const fn = (buf) => {
			const ch = scnr.currentChar();
			if (ch === "{" || ch === "@" || ch === "|" || ch === "(" || ch === ")" || !ch) {
				return buf;
			} else if (ch === CHAR_SP) {
				return buf;
			} else if (ch === CHAR_LF || ch === DOT) {
				buf += ch;
				scnr.next();
				return fn(buf);
			} else {
				buf += ch;
				scnr.next();
				return fn(buf);
			}
		};
		return fn("");
	}
	function readPlural(scnr) {
		skipSpaces(scnr);
		const plural = eat(
			scnr,
			"|"
			/* TokenChars.Pipe */
		);
		skipSpaces(scnr);
		return plural;
	}
	// TODO: We need refactoring of token parsing ...
	function readTokenInPlaceholder(scnr, context) {
		let token = null;
		const ch = scnr.currentChar();
		switch (ch) {
			case "{":
				if (context.braceNest >= 1) {
					emitError(CompileErrorCodes.NOT_ALLOW_NEST_PLACEHOLDER, currentPosition(), 0);
				}
				scnr.next();
				token = getToken(
					context,
					2,
					"{"
					/* TokenChars.BraceLeft */
				);
				skipSpaces(scnr);
				context.braceNest++;
				return token;
			case "}":
				if (context.braceNest > 0 && context.currentType === 2) {
					emitError(CompileErrorCodes.EMPTY_PLACEHOLDER, currentPosition(), 0);
				}
				scnr.next();
				token = getToken(
					context,
					3,
					"}"
					/* TokenChars.BraceRight */
				);
				context.braceNest--;
				context.braceNest > 0 && skipSpaces(scnr);
				if (context.inLinked && context.braceNest === 0) {
					context.inLinked = false;
				}
				return token;
			case "@":
				if (context.braceNest > 0) {
					emitError(CompileErrorCodes.UNTERMINATED_CLOSING_BRACE, currentPosition(), 0);
				}
				token = readTokenInLinked(scnr, context) || getEndToken(context);
				context.braceNest = 0;
				return token;
			default: {
				let validNamedIdentifier = true;
				let validListIdentifier = true;
				let validLiteral = true;
				if (isPluralStart(scnr)) {
					if (context.braceNest > 0) {
						emitError(CompileErrorCodes.UNTERMINATED_CLOSING_BRACE, currentPosition(), 0);
					}
					token = getToken(context, 1, readPlural(scnr));
					// reset
					context.braceNest = 0;
					context.inLinked = false;
					return token;
				}
				if (context.braceNest > 0 && (context.currentType === 4 || context.currentType === 5 || context.currentType === 6)) {
					emitError(CompileErrorCodes.UNTERMINATED_CLOSING_BRACE, currentPosition(), 0);
					context.braceNest = 0;
					return readToken(scnr, context);
				}
				if (validNamedIdentifier = isNamedIdentifierStart(scnr, context)) {
					token = getToken(context, 4, readNamedIdentifier(scnr));
					skipSpaces(scnr);
					return token;
				}
				if (validListIdentifier = isListIdentifierStart(scnr, context)) {
					token = getToken(context, 5, readListIdentifier(scnr));
					skipSpaces(scnr);
					return token;
				}
				if (validLiteral = isLiteralStart(scnr, context)) {
					token = getToken(context, 6, readLiteral(scnr));
					skipSpaces(scnr);
					return token;
				}
				if (!validNamedIdentifier && !validListIdentifier && !validLiteral) {
					// TODO: we should be re-designed invalid cases, when we will extend message syntax near the future ...
					token = getToken(context, 12, readInvalidIdentifier(scnr));
					emitError(CompileErrorCodes.INVALID_TOKEN_IN_PLACEHOLDER, currentPosition(), 0, token.value);
					skipSpaces(scnr);
					return token;
				}
				break;
			}
		}
		return token;
	}
	// TODO: We need refactoring of token parsing ...
	function readTokenInLinked(scnr, context) {
		const { currentType } = context;
		let token = null;
		const ch = scnr.currentChar();
		if ((currentType === 7 || currentType === 8 || currentType === 11 || currentType === 9) && (ch === CHAR_LF || ch === CHAR_SP)) {
			emitError(CompileErrorCodes.INVALID_LINKED_FORMAT, currentPosition(), 0);
		}
		switch (ch) {
			case "@":
				scnr.next();
				token = getToken(
					context,
					7,
					"@"
					/* TokenChars.LinkedAlias */
				);
				context.inLinked = true;
				return token;
			case ".":
				skipSpaces(scnr);
				scnr.next();
				return getToken(
					context,
					8,
					"."
					/* TokenChars.LinkedDot */
				);
			case ":":
				skipSpaces(scnr);
				scnr.next();
				return getToken(
					context,
					9,
					":"
					/* TokenChars.LinkedDelimiter */
				);
			default:
				if (isPluralStart(scnr)) {
					token = getToken(context, 1, readPlural(scnr));
					// reset
					context.braceNest = 0;
					context.inLinked = false;
					return token;
				}
				if (isLinkedDotStart(scnr, context) || isLinkedDelimiterStart(scnr, context)) {
					skipSpaces(scnr);
					return readTokenInLinked(scnr, context);
				}
				if (isLinkedModifierStart(scnr, context)) {
					skipSpaces(scnr);
					return getToken(context, 11, readLinkedModifier(scnr));
				}
				if (isLinkedReferStart(scnr, context)) {
					skipSpaces(scnr);
					if (ch === "{") {
						// scan the placeholder
						return readTokenInPlaceholder(scnr, context) || token;
					} else {
						return getToken(context, 10, readLinkedRefer(scnr));
					}
				}
				if (currentType === 7) {
					emitError(CompileErrorCodes.INVALID_LINKED_FORMAT, currentPosition(), 0);
				}
				context.braceNest = 0;
				context.inLinked = false;
				return readToken(scnr, context);
		}
	}
	// TODO: We need refactoring of token parsing ...
	function readToken(scnr, context) {
		let token = { type: 13 };
		if (context.braceNest > 0) {
			return readTokenInPlaceholder(scnr, context) || getEndToken(context);
		}
		if (context.inLinked) {
			return readTokenInLinked(scnr, context) || getEndToken(context);
		}
		const ch = scnr.currentChar();
		switch (ch) {
			case "{": return readTokenInPlaceholder(scnr, context) || getEndToken(context);
			case "}":
				emitError(CompileErrorCodes.UNBALANCED_CLOSING_BRACE, currentPosition(), 0);
				scnr.next();
				return getToken(
					context,
					3,
					"}"
					/* TokenChars.BraceRight */
				);
			case "@": return readTokenInLinked(scnr, context) || getEndToken(context);
			default: {
				if (isPluralStart(scnr)) {
					token = getToken(context, 1, readPlural(scnr));
					// reset
					context.braceNest = 0;
					context.inLinked = false;
					return token;
				}
				if (isTextStart(scnr)) {
					return getToken(context, 0, readText(scnr));
				}
				break;
			}
		}
		return token;
	}
	function nextToken() {
		const { currentType, offset, startLoc, endLoc } = _context;
		_context.lastType = currentType;
		_context.lastOffset = offset;
		_context.lastStartLoc = startLoc;
		_context.lastEndLoc = endLoc;
		_context.offset = currentOffset();
		_context.startLoc = currentPosition();
		if (_scnr.currentChar() === EOF) {
			return getToken(
				_context,
				13
				/* TokenTypes.EOF */
			);
		}
		return readToken(_scnr, _context);
	}
	return {
		nextToken,
		currentOffset,
		currentPosition,
		context
	};
}
const ERROR_DOMAIN$2 = "parser";
// Backslash backslash, backslash quote, uHHHH, UHHHHHH.
const KNOWN_ESCAPES = /(?:\\\\|\\'|\\u([0-9a-fA-F]{4})|\\U([0-9a-fA-F]{6}))/g;
// Text context escape sequences: \\, \@, \{, \}, \|
const TEXT_ESCAPES = /\\([\\@{}|])/g;
function fromTextEscapeSequence(_match, char) {
	return char;
}
function fromEscapeSequence(match, codePoint4, codePoint6) {
	switch (match) {
		case `\\\\`: return `\\`;
		// eslint-disable-next-line no-useless-escape
		case `\\\'`:
 // eslint-disable-next-line no-useless-escape
		return `\'`;
		default: {
			const codePoint = parseInt(codePoint4 || codePoint6, 16);
			if (codePoint <= 55295 || codePoint >= 57344) {
				return String.fromCodePoint(codePoint);
			}
			// invalid ...
			// Replace them with U+FFFD REPLACEMENT CHARACTER.
			return "�";
		}
	}
}
function createParser(options = {}) {
	const location = options.location !== false;
	const { onError } = options;
	function emitError(tokenzer, code, start, offset, ...args) {
		const end = tokenzer.currentPosition();
		end.offset += offset;
		end.column += offset;
		if (onError) {
			const loc = location ? createLocation(start, end) : null;
			const err = createCompileError(code, loc, {
				domain: ERROR_DOMAIN$2,
				args
			});
			onError(err);
		}
	}
	function startNode(type, offset, loc) {
		const node = { type };
		if (location) {
			node.start = offset;
			node.end = offset;
			node.loc = {
				start: loc,
				end: loc
			};
		}
		return node;
	}
	function endNode(node, offset, pos, type) {
		if (location) {
			node.end = offset;
			if (node.loc) {
				node.loc.end = pos;
			}
		}
	}
	function parseText(tokenizer, value) {
		const context = tokenizer.context();
		const node = startNode(3, context.offset, context.startLoc);
		node.value = value.replace(TEXT_ESCAPES, fromTextEscapeSequence);
		endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
		return node;
	}
	function parseList(tokenizer, index) {
		const context = tokenizer.context();
		const { lastOffset: offset, lastStartLoc: loc } = context;
		const node = startNode(5, offset, loc);
		node.index = parseInt(index, 10);
		tokenizer.nextToken();
		endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
		return node;
	}
	function parseNamed(tokenizer, key) {
		const context = tokenizer.context();
		const { lastOffset: offset, lastStartLoc: loc } = context;
		const node = startNode(4, offset, loc);
		node.key = key;
		tokenizer.nextToken();
		endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
		return node;
	}
	function parseLiteral(tokenizer, value) {
		const context = tokenizer.context();
		const { lastOffset: offset, lastStartLoc: loc } = context;
		const node = startNode(9, offset, loc);
		node.value = value.replace(KNOWN_ESCAPES, fromEscapeSequence);
		tokenizer.nextToken();
		endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
		return node;
	}
	function parseLinkedModifier(tokenizer) {
		const token = tokenizer.nextToken();
		const context = tokenizer.context();
		const { lastOffset: offset, lastStartLoc: loc } = context;
		const node = startNode(8, offset, loc);
		if (token.type !== 11) {
			// empty modifier
			emitError(tokenizer, CompileErrorCodes.UNEXPECTED_EMPTY_LINKED_MODIFIER, context.lastStartLoc, 0);
			node.value = "";
			endNode(node, offset, loc);
			return {
				nextConsumeToken: token,
				node
			};
		}
		// check token
		if (token.value == null) {
			emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
		}
		node.value = token.value || "";
		endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
		return { node };
	}
	function parseLinkedKey(tokenizer, value) {
		const context = tokenizer.context();
		const node = startNode(7, context.offset, context.startLoc);
		node.value = value;
		endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
		return node;
	}
	function parseLinked(tokenizer) {
		const context = tokenizer.context();
		const linkedNode = startNode(6, context.offset, context.startLoc);
		let token = tokenizer.nextToken();
		if (token.type === 8) {
			const parsed = parseLinkedModifier(tokenizer);
			linkedNode.modifier = parsed.node;
			token = parsed.nextConsumeToken || tokenizer.nextToken();
		}
		// asset check token
		if (token.type !== 9) {
			emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
		}
		token = tokenizer.nextToken();
		// skip brace left
		if (token.type === 2) {
			token = tokenizer.nextToken();
		}
		switch (token.type) {
			case 10:
				if (token.value == null) {
					emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
				}
				linkedNode.key = parseLinkedKey(tokenizer, token.value || "");
				break;
			case 4:
				if (token.value == null) {
					emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
				}
				linkedNode.key = parseNamed(tokenizer, token.value || "");
				break;
			case 5:
				if (token.value == null) {
					emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
				}
				linkedNode.key = parseList(tokenizer, token.value || "");
				break;
			case 6:
				if (token.value == null) {
					emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
				}
				linkedNode.key = parseLiteral(tokenizer, token.value || "");
				break;
			default: {
				// empty key
				emitError(tokenizer, CompileErrorCodes.UNEXPECTED_EMPTY_LINKED_KEY, context.lastStartLoc, 0);
				const nextContext = tokenizer.context();
				const emptyLinkedKeyNode = startNode(7, nextContext.offset, nextContext.startLoc);
				emptyLinkedKeyNode.value = "";
				endNode(emptyLinkedKeyNode, nextContext.offset, nextContext.startLoc);
				linkedNode.key = emptyLinkedKeyNode;
				endNode(linkedNode, nextContext.offset, nextContext.startLoc);
				return {
					nextConsumeToken: token,
					node: linkedNode
				};
			}
		}
		endNode(linkedNode, tokenizer.currentOffset(), tokenizer.currentPosition());
		return { node: linkedNode };
	}
	function parseMessage(tokenizer) {
		const context = tokenizer.context();
		const startOffset = context.currentType === 1 ? tokenizer.currentOffset() : context.offset;
		const startLoc = context.currentType === 1 ? context.endLoc : context.startLoc;
		const node = startNode(2, startOffset, startLoc);
		node.items = [];
		let nextToken = null;
		do {
			const token = nextToken || tokenizer.nextToken();
			nextToken = null;
			switch (token.type) {
				case 0:
					if (token.value == null) {
						emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
					}
					node.items.push(parseText(tokenizer, token.value || ""));
					break;
				case 5:
					if (token.value == null) {
						emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
					}
					node.items.push(parseList(tokenizer, token.value || ""));
					break;
				case 4:
					if (token.value == null) {
						emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
					}
					node.items.push(parseNamed(tokenizer, token.value || ""));
					break;
				case 6:
					if (token.value == null) {
						emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, getTokenCaption(token));
					}
					node.items.push(parseLiteral(tokenizer, token.value || ""));
					break;
				case 7: {
					const parsed = parseLinked(tokenizer);
					node.items.push(parsed.node);
					nextToken = parsed.nextConsumeToken || null;
					break;
				}
			}
		} while (context.currentType !== 13 && context.currentType !== 1);
		// adjust message node loc
		const endOffset = context.currentType === 1 ? context.lastOffset : tokenizer.currentOffset();
		const endLoc = context.currentType === 1 ? context.lastEndLoc : tokenizer.currentPosition();
		endNode(node, endOffset, endLoc);
		return node;
	}
	function parsePlural(tokenizer, offset, loc, msgNode) {
		const context = tokenizer.context();
		let hasEmptyMessage = msgNode.items.length === 0;
		const node = startNode(1, offset, loc);
		node.cases = [];
		node.cases.push(msgNode);
		do {
			const msg = parseMessage(tokenizer);
			if (!hasEmptyMessage) {
				hasEmptyMessage = msg.items.length === 0;
			}
			node.cases.push(msg);
		} while (context.currentType !== 13);
		if (hasEmptyMessage) {
			emitError(tokenizer, CompileErrorCodes.MUST_HAVE_MESSAGES_IN_PLURAL, loc, 0);
		}
		endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
		return node;
	}
	function parseResource(tokenizer) {
		const context = tokenizer.context();
		const { offset, startLoc } = context;
		const msgNode = parseMessage(tokenizer);
		if (context.currentType === 13) {
			return msgNode;
		} else {
			return parsePlural(tokenizer, offset, startLoc, msgNode);
		}
	}
	function parse(source) {
		const tokenizer = createTokenizer(source, assign({}, options));
		const context = tokenizer.context();
		const node = startNode(0, context.offset, context.startLoc);
		if (location && node.loc) {
			node.loc.source = source;
		}
		node.body = parseResource(tokenizer);
		if (options.onCacheKey) {
			node.cacheKey = options.onCacheKey(source);
		}
		// assert whether achieved to EOF
		if (context.currentType !== 13) {
			emitError(tokenizer, CompileErrorCodes.UNEXPECTED_LEXICAL_ANALYSIS, context.lastStartLoc, 0, source[context.offset] || "");
		}
		endNode(node, tokenizer.currentOffset(), tokenizer.currentPosition());
		return node;
	}
	return { parse };
}
function getTokenCaption(token) {
	if (token.type === 13) {
		return "EOF";
	}
	const name = (token.value || "").replace(/\r?\n/gu, "\\n");
	return name.length > 10 ? name.slice(0, 9) + "…" : name;
}
function createTransformer(ast, options = {}) {
	const _context = {
		ast,
		helpers: new Set()
	};
	const context = () => _context;
	const helper = (name) => {
		_context.helpers.add(name);
		return name;
	};
	return {
		context,
		helper
	};
}
function traverseNodes(nodes, transformer) {
	for (let i = 0; i < nodes.length; i++) {
		traverseNode(nodes[i], transformer);
	}
}
function traverseNode(node, transformer) {
	// TODO: if we need pre-hook of transform, should be implemented to here
	switch (node.type) {
		case 1:
			traverseNodes(node.cases, transformer);
			transformer.helper(
				"plural"
				/* HelperNameMap.PLURAL */
			);
			break;
		case 2:
			traverseNodes(node.items, transformer);
			break;
		case 6: {
			const linked = node;
			traverseNode(linked.key, transformer);
			transformer.helper(
				"linked"
				/* HelperNameMap.LINKED */
			);
			transformer.helper(
				"type"
				/* HelperNameMap.TYPE */
			);
			break;
		}
		case 5:
			transformer.helper(
				"interpolate"
				/* HelperNameMap.INTERPOLATE */
			);
			transformer.helper(
				"list"
				/* HelperNameMap.LIST */
			);
			break;
		case 4:
			transformer.helper(
				"interpolate"
				/* HelperNameMap.INTERPOLATE */
			);
			transformer.helper(
				"named"
				/* HelperNameMap.NAMED */
			);
			break;
	}
	// TODO: if we need post-hook of transform, should be implemented to here
}
// transform AST
function transform(ast, options = {}) {
	const transformer = createTransformer(ast);
	transformer.helper(
		"normalize"
		/* HelperNameMap.NORMALIZE */
	);
	// traverse
	ast.body && traverseNode(ast.body, transformer);
	// set meta information
	const context = transformer.context();
	ast.helpers = Array.from(context.helpers);
}
function optimize(ast) {
	const body = ast.body;
	if (body.type === 2) {
		optimizeMessageNode(body);
	} else {
		body.cases.forEach((c) => optimizeMessageNode(c));
	}
	return ast;
}
function optimizeMessageNode(message) {
	if (message.items.length === 1) {
		const item = message.items[0];
		if (item.type === 3 || item.type === 9) {
			message.static = item.value;
			delete item.value;
		}
	} else {
		const values = [];
		for (let i = 0; i < message.items.length; i++) {
			const item = message.items[i];
			if (!(item.type === 3 || item.type === 9)) {
				break;
			}
			if (item.value == null) {
				break;
			}
			values.push(item.value);
		}
		if (values.length === message.items.length) {
			message.static = join(values);
			for (let i = 0; i < message.items.length; i++) {
				const item = message.items[i];
				if (item.type === 3 || item.type === 9) {
					delete item.value;
				}
			}
		}
	}
}
const ERROR_DOMAIN$1 = "minifier";
/* eslint-disable @typescript-eslint/no-explicit-any */
function minify(node) {
	node.t = node.type;
	switch (node.type) {
		case 0: {
			const resource = node;
			minify(resource.body);
			resource.b = resource.body;
			delete resource.body;
			break;
		}
		case 1: {
			const plural = node;
			const cases = plural.cases;
			for (let i = 0; i < cases.length; i++) {
				minify(cases[i]);
			}
			plural.c = cases;
			delete plural.cases;
			break;
		}
		case 2: {
			const message = node;
			const items = message.items;
			for (let i = 0; i < items.length; i++) {
				minify(items[i]);
			}
			message.i = items;
			delete message.items;
			if (message.static) {
				message.s = message.static;
				delete message.static;
			}
			break;
		}
		case 3:
		case 9:
		case 8:
		case 7: {
			const valueNode = node;
			if (valueNode.value) {
				valueNode.v = valueNode.value;
				delete valueNode.value;
			}
			break;
		}
		case 6: {
			const linked = node;
			minify(linked.key);
			linked.k = linked.key;
			delete linked.key;
			if (linked.modifier) {
				minify(linked.modifier);
				linked.m = linked.modifier;
				delete linked.modifier;
			}
			break;
		}
		case 5: {
			const list = node;
			list.i = list.index;
			delete list.index;
			break;
		}
		case 4: {
			const named = node;
			named.k = named.key;
			delete named.key;
			break;
		}
		default: if ("development" !== "production") {
			throw createCompileError(CompileErrorCodes.UNHANDLED_MINIFIER_NODE_TYPE, null, {
				domain: ERROR_DOMAIN$1,
				args: [node.type]
			});
		}
	}
	delete node.type;
}
/* eslint-enable @typescript-eslint/no-explicit-any */
// eslint-disable-next-line @typescript-eslint/triple-slash-reference
/// <reference types="source-map-js" />
const ERROR_DOMAIN = "parser";
function createCodeGenerator(ast, options) {
	const { filename, breakLineCode, needIndent: _needIndent } = options;
	const location = options.location !== false;
	const _context = {
		filename,
		code: "",
		column: 1,
		line: 1,
		offset: 0,
		map: undefined,
		breakLineCode,
		needIndent: _needIndent,
		indentLevel: 0
	};
	if (location && ast.loc) {
		_context.source = ast.loc.source;
	}
	const context = () => _context;
	function push(code, node) {
		_context.code += code;
	}
	function _newline(n, withBreakLine = true) {
		const _breakLineCode = withBreakLine ? breakLineCode : "";
		push(_needIndent ? _breakLineCode + `  `.repeat(n) : _breakLineCode);
	}
	function indent(withNewLine = true) {
		const level = ++_context.indentLevel;
		withNewLine && _newline(level);
	}
	function deindent(withNewLine = true) {
		const level = --_context.indentLevel;
		withNewLine && _newline(level);
	}
	function newline() {
		_newline(_context.indentLevel);
	}
	const helper = (key) => `_${key}`;
	const needIndent = () => _context.needIndent;
	return {
		context,
		push,
		indent,
		deindent,
		newline,
		helper,
		needIndent
	};
}
function generateLinkedNode(generator, node) {
	const { helper } = generator;
	generator.push(`${helper(
		"linked"
		/* HelperNameMap.LINKED */
	)}(`);
	generateNode(generator, node.key);
	if (node.modifier) {
		generator.push(`, `);
		generateNode(generator, node.modifier);
		generator.push(`, _type`);
	} else {
		generator.push(`, undefined, _type`);
	}
	generator.push(`)`);
}
function generateMessageNode(generator, node) {
	const { helper, needIndent } = generator;
	generator.push(`${helper(
		"normalize"
		/* HelperNameMap.NORMALIZE */
	)}([`);
	generator.indent(needIndent());
	const length = node.items.length;
	for (let i = 0; i < length; i++) {
		generateNode(generator, node.items[i]);
		if (i === length - 1) {
			break;
		}
		generator.push(", ");
	}
	generator.deindent(needIndent());
	generator.push("])");
}
function generatePluralNode(generator, node) {
	const { helper, needIndent } = generator;
	if (node.cases.length > 1) {
		generator.push(`${helper(
			"plural"
			/* HelperNameMap.PLURAL */
		)}([`);
		generator.indent(needIndent());
		const length = node.cases.length;
		for (let i = 0; i < length; i++) {
			generateNode(generator, node.cases[i]);
			if (i === length - 1) {
				break;
			}
			generator.push(", ");
		}
		generator.deindent(needIndent());
		generator.push(`])`);
	}
}
function generateResource(generator, node) {
	if (node.body) {
		generateNode(generator, node.body);
	} else {
		generator.push("null");
	}
}
function generateNode(generator, node) {
	const { helper } = generator;
	switch (node.type) {
		case 0:
			generateResource(generator, node);
			break;
		case 1:
			generatePluralNode(generator, node);
			break;
		case 2:
			generateMessageNode(generator, node);
			break;
		case 6:
			generateLinkedNode(generator, node);
			break;
		case 8:
			generator.push(JSON.stringify(node.value), node);
			break;
		case 7:
			generator.push(JSON.stringify(node.value), node);
			break;
		case 5:
			generator.push(`${helper(
				"interpolate"
				/* HelperNameMap.INTERPOLATE */
			)}(${helper(
				"list"
				/* HelperNameMap.LIST */
			)}(${node.index}))`, node);
			break;
		case 4:
			generator.push(`${helper(
				"interpolate"
				/* HelperNameMap.INTERPOLATE */
			)}(${helper(
				"named"
				/* HelperNameMap.NAMED */
			)}(${JSON.stringify(node.key)}))`, node);
			break;
		case 9:
			generator.push(JSON.stringify(node.value), node);
			break;
		case 3:
			generator.push(JSON.stringify(node.value), node);
			break;
		default: if ("development" !== "production") {
			throw createCompileError(CompileErrorCodes.UNHANDLED_CODEGEN_NODE_TYPE, null, {
				domain: ERROR_DOMAIN,
				args: [node.type]
			});
		}
	}
}
// generate code from AST
const generate = (ast, options = {}) => {
	const mode = isString(options.mode) ? options.mode : "normal";
	const filename = isString(options.filename) ? options.filename : "message.intl";
	!!options.sourceMap;
	// prettier-ignore
	const breakLineCode = options.breakLineCode != null ? options.breakLineCode : mode === "arrow" ? ";" : "\n";
	const needIndent = options.needIndent ? options.needIndent : mode !== "arrow";
	const helpers = ast.helpers || [];
	const generator = createCodeGenerator(ast, {
		filename,
		breakLineCode,
		needIndent
	});
	generator.push(mode === "normal" ? `function __msg__ (ctx) {` : `(ctx) => {`);
	generator.indent(needIndent);
	if (helpers.length > 0) {
		generator.push(`const { ${join(helpers.map((s) => `${s}: _${s}`), ", ")} } = ctx`);
		generator.newline();
	}
	generator.push(`return `);
	generateNode(generator, ast);
	generator.deindent(needIndent);
	generator.push(`}`);
	delete ast.helpers;
	const { code, map } = generator.context();
	return {
		ast,
		code,
		map: map ? map.toJSON() : undefined
	};
};
function baseCompile(source, options = {}) {
	const assignedOptions = assign({}, options);
	const jit = !!assignedOptions.jit;
	const enalbeMinify = !!assignedOptions.minify;
	const enambeOptimize = assignedOptions.optimize == null ? true : assignedOptions.optimize;
	// parse source codes
	const parser = createParser(assignedOptions);
	const ast = parser.parse(source);
	if (!jit) {
		// transform ASTs
		transform(ast, assignedOptions);
		// generate javascript codes
		return generate(ast, assignedOptions);
	} else {
		// optimize ASTs
		enambeOptimize && optimize(ast);
		// minimize ASTs
		enalbeMinify && minify(ast);
		// In JIT mode, no ast transform, no code generation.
		return {
			ast,
			code: ""
		};
	}
}
export { COMPILE_ERROR_CODES_EXTEND_POINT, CompileErrorCodes, ERROR_DOMAIN$2 as ERROR_DOMAIN, LOCATION_STUB, baseCompile, createCompileError, createLocation, createParser, createPosition, defaultOnError, detectHtmlTag, errorMessages };

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFLQSxTQUFTLFFBQVEsUUFBUSxNQUFNLGdCQUFnQjtBQUUvQyxNQUFNLGdCQUFnQjtDQUNsQixPQUFPO0VBQUUsTUFBTTtFQUFHLFFBQVE7RUFBRyxRQUFRO0NBQUU7Q0FDdkMsS0FBSztFQUFFLE1BQU07RUFBRyxRQUFRO0VBQUcsUUFBUTtDQUFFO0FBQ3pDO0FBQ0EsU0FBUyxlQUFlLE1BQU0sUUFBUSxRQUFRO0NBQzFDLE9BQU87RUFBRTtFQUFNO0VBQVE7Q0FBTztBQUNsQztBQUNBLFNBQVMsZUFBZSxPQUFPLEtBQUssUUFBUTtDQUN4QyxNQUFNLE1BQU07RUFBRTtFQUFPO0NBQUk7Q0FDekIsSUFBSSxVQUFVLE1BQU07RUFDaEIsSUFBSSxTQUFTO0NBQ2pCO0NBQ0EsT0FBTztBQUNYO0FBRUEsTUFBTSxvQkFBb0I7O0NBRXRCLGdCQUFnQjtDQUNoQiw4QkFBOEI7Q0FDOUIsMENBQTBDO0NBQzFDLHlCQUF5QjtDQUN6QixpQ0FBaUM7Q0FDakMsMEJBQTBCO0NBQzFCLDRCQUE0QjtDQUM1QixtQkFBbUI7Q0FDbkIsNEJBQTRCO0NBQzVCLHVCQUF1Qjs7Q0FFdkIsOEJBQThCO0NBQzlCLGtDQUFrQztDQUNsQyw2QkFBNkI7Q0FDN0IsNkJBQTZCOztDQUU3Qiw2QkFBNkI7O0NBRTdCLDhCQUE4QjtBQUNsQzs7OztBQUlBLE1BQU0sbUNBQW1DOztBQUV6QyxNQUFNLGdCQUFnQjs7RUFFakIsa0JBQWtCLGlCQUFpQjtFQUNuQyxrQkFBa0IsK0JBQStCO0VBQ2pELGtCQUFrQiwyQ0FBMkM7RUFDN0Qsa0JBQWtCLDBCQUEwQjtFQUM1QyxrQkFBa0Isa0NBQWtDO0VBQ3BELGtCQUFrQiwyQkFBMkI7RUFDN0Msa0JBQWtCLDZCQUE2QjtFQUMvQyxrQkFBa0Isb0JBQW9CO0VBQ3RDLGtCQUFrQiw2QkFBNkI7RUFDL0Msa0JBQWtCLHdCQUF3Qjs7RUFFMUMsa0JBQWtCLCtCQUErQjtFQUNqRCxrQkFBa0IsbUNBQW1DO0VBQ3JELGtCQUFrQiw4QkFBOEI7RUFDaEQsa0JBQWtCLDhCQUE4Qjs7RUFFaEQsa0JBQWtCLDhCQUE4Qjs7RUFFaEQsa0JBQWtCLCtCQUErQjtBQUN0RDtBQUNBLFNBQVMsbUJBQW1CLE1BQU0sS0FBSyxVQUFVLENBQUMsR0FBRztDQUNqRCxNQUFNLEVBQUUsUUFBUSxVQUFVLFNBQVM7Q0FDbkMsTUFBTSx3QkFBZ0MsZUFDaEMsUUFBUSxZQUFZLGNBQWEsQ0FBRSxTQUFTLElBQUksR0FBSSxRQUFRLENBQUMsQ0FBRSxJQUMvRDtDQUNOLE1BQU0sUUFBUSxJQUFJLFlBQVksT0FBTyxHQUFHLENBQUM7Q0FDekMsTUFBTSxPQUFPO0NBQ2IsSUFBSSxLQUFLO0VBQ0wsTUFBTSxXQUFXO0NBQ3JCO0NBQ0EsTUFBTSxTQUFTO0NBQ2YsT0FBTztBQUNYOztBQUVBLFNBQVMsZUFBZSxPQUFPO0NBQzNCLE1BQU07QUFDVjs7QUFHQSxNQUFNLGNBQWM7QUFDcEIsTUFBTSxpQkFBaUIsV0FBVyxZQUFZLEtBQUssTUFBTTtBQUV6RCxNQUFNLFVBQVU7QUFDaEIsTUFBTSxVQUFVO0FBQ2hCLE1BQU0sVUFBVTtBQUNoQixNQUFNLFVBQVUsT0FBTyxhQUFhLElBQU07QUFDMUMsTUFBTSxVQUFVLE9BQU8sYUFBYSxJQUFNO0FBQzFDLFNBQVMsY0FBYyxLQUFLO0NBQ3hCLE1BQU0sT0FBTztDQUNiLElBQUksU0FBUztDQUNiLElBQUksUUFBUTtDQUNaLElBQUksVUFBVTtDQUNkLElBQUksY0FBYztDQUNsQixNQUFNLFVBQVUsVUFBVSxLQUFLLFdBQVcsV0FBVyxLQUFLLFFBQVEsT0FBTztDQUN6RSxNQUFNLFFBQVEsVUFBVSxLQUFLLFdBQVc7Q0FDeEMsTUFBTSxRQUFRLFVBQVUsS0FBSyxXQUFXO0NBQ3hDLE1BQU0sUUFBUSxVQUFVLEtBQUssV0FBVztDQUN4QyxNQUFNLGFBQWEsVUFBVSxPQUFPLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUs7Q0FDdEYsTUFBTSxjQUFjO0NBQ3BCLE1BQU0sYUFBYTtDQUNuQixNQUFNLGVBQWU7Q0FDckIsTUFBTSxtQkFBbUI7Q0FDekIsTUFBTSxVQUFVLFdBQVcsT0FBTyxNQUFNLEtBQUssS0FBSyxNQUFNLEtBQUssS0FBSyxNQUFNLElBQUksVUFBVSxLQUFLO0NBQzNGLE1BQU0sb0JBQW9CLE9BQU8sTUFBTTtDQUN2QyxNQUFNLG9CQUFvQixPQUFPLFNBQVMsV0FBVztDQUNyRCxTQUFTLE9BQU87RUFDWixjQUFjO0VBQ2QsSUFBSSxVQUFVLE1BQU0sR0FBRztHQUNuQjtHQUNBLFVBQVU7RUFDZDtFQUNBLElBQUksT0FBTyxNQUFNLEdBQUc7R0FDaEI7RUFDSjtFQUNBO0VBQ0E7RUFDQSxPQUFPLEtBQUs7Q0FDaEI7Q0FDQSxTQUFTLE9BQU87RUFDWixJQUFJLE9BQU8sU0FBUyxXQUFXLEdBQUc7R0FDOUI7RUFDSjtFQUNBO0VBQ0EsT0FBTyxLQUFLLFNBQVM7Q0FDekI7Q0FDQSxTQUFTLFFBQVE7RUFDYixTQUFTO0VBQ1QsUUFBUTtFQUNSLFVBQVU7RUFDVixjQUFjO0NBQ2xCO0NBQ0EsU0FBUyxVQUFVLFNBQVMsR0FBRztFQUMzQixjQUFjO0NBQ2xCO0NBQ0EsU0FBUyxhQUFhO0VBQ2xCLE1BQU0sU0FBUyxTQUFTO0VBQ3hCLE9BQU8sV0FBVyxRQUFRO0dBQ3RCLEtBQUs7RUFDVDtFQUNBLGNBQWM7Q0FDbEI7Q0FDQSxPQUFPO0VBQ0g7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0o7QUFDSjtBQUVBLE1BQU0sTUFBTTtBQUNaLE1BQU0sTUFBTTtBQUNaLE1BQU0sb0JBQW9CO0FBQzFCLE1BQU0saUJBQWlCO0FBQ3ZCLFNBQVMsZ0JBQWdCLFFBQVEsVUFBVSxDQUFDLEdBQUc7Q0FDM0MsTUFBTSxXQUFXLFFBQVEsYUFBYTtDQUN0QyxNQUFNLFFBQVEsY0FBYyxNQUFNO0NBQ2xDLE1BQU0sc0JBQXNCLE1BQU0sTUFBTTtDQUN4QyxNQUFNLHdCQUF3QixlQUFlLE1BQU0sS0FBSyxHQUFHLE1BQU0sT0FBTyxHQUFHLE1BQU0sTUFBTSxDQUFDO0NBQ3hGLE1BQU0sV0FBVyxnQkFBZ0I7Q0FDakMsTUFBTSxjQUFjLGNBQWM7Q0FDbEMsTUFBTSxXQUFXO0VBQ2IsYUFBYTtFQUNiLFFBQVE7RUFDUixVQUFVO0VBQ1YsUUFBUTtFQUNSLFVBQVU7RUFDVixZQUFZO0VBQ1osY0FBYztFQUNkLFlBQVk7RUFDWixXQUFXO0VBQ1gsVUFBVTtFQUNWLE1BQU07Q0FDVjtDQUNBLE1BQU0sZ0JBQWdCO0NBQ3RCLE1BQU0sRUFBRSxZQUFZO0NBQ3BCLFNBQVMsVUFBVSxNQUFNLEtBQUssUUFBUSxHQUFHLE1BQU07RUFDM0MsTUFBTSxNQUFNLFFBQVE7RUFDcEIsSUFBSSxVQUFVO0VBQ2QsSUFBSSxVQUFVO0VBQ2QsSUFBSSxTQUFTO0dBQ1QsTUFBTSxNQUFNLFdBQVcsZUFBZSxJQUFJLFVBQVUsR0FBRyxJQUFJO0dBQzNELE1BQU0sTUFBTSxtQkFBbUIsTUFBTSxLQUFLO0lBQ3RDLFFBQVE7SUFDUjtHQUNKLENBQUM7R0FDRCxRQUFRLEdBQUc7RUFDZjtDQUNKO0NBQ0EsU0FBUyxTQUFTLFNBQVMsTUFBTSxPQUFPO0VBQ3BDLFFBQVEsU0FBUyxnQkFBZ0I7RUFDakMsUUFBUSxjQUFjO0VBQ3RCLE1BQU0sUUFBUSxFQUFFLEtBQUs7RUFDckIsSUFBSSxVQUFVO0dBQ1YsTUFBTSxNQUFNLGVBQWUsUUFBUSxVQUFVLFFBQVEsTUFBTTtFQUMvRDtFQUNBLElBQUksU0FBUyxNQUFNO0dBQ2YsTUFBTSxRQUFRO0VBQ2xCO0VBQ0EsT0FBTztDQUNYO0NBQ0EsTUFBTSxlQUFlLFlBQVk7RUFBUztFQUFTOztDQUF1QjtDQUMxRSxTQUFTLElBQUksTUFBTSxJQUFJO0VBQ25CLElBQUksS0FBSyxZQUFZLE1BQU0sSUFBSTtHQUMzQixLQUFLLEtBQUs7R0FDVixPQUFPO0VBQ1gsT0FDSztHQUNELFVBQVUsa0JBQWtCLGdCQUFnQixnQkFBZ0IsR0FBRyxHQUFHLEVBQUU7R0FDcEUsT0FBTztFQUNYO0NBQ0o7Q0FDQSxTQUFTLFdBQVcsTUFBTTtFQUN0QixJQUFJLE1BQU07RUFDVixPQUFPLEtBQUssWUFBWSxNQUFNLFdBQVcsS0FBSyxZQUFZLE1BQU0sU0FBUztHQUNyRSxPQUFPLEtBQUssWUFBWTtHQUN4QixLQUFLLEtBQUs7RUFDZDtFQUNBLE9BQU87Q0FDWDtDQUNBLFNBQVMsV0FBVyxNQUFNO0VBQ3RCLE1BQU0sTUFBTSxXQUFXLElBQUk7RUFDM0IsS0FBSyxXQUFXO0VBQ2hCLE9BQU87Q0FDWDtDQUNBLFNBQVMsa0JBQWtCLElBQUk7RUFDM0IsSUFBSSxPQUFPLEtBQUs7R0FDWixPQUFPO0VBQ1g7RUFDQSxNQUFNLEtBQUssR0FBRyxXQUFXLENBQUM7RUFDMUIsT0FBUyxNQUFNLE1BQU0sTUFBTSxPQUN0QixNQUFNLE1BQU0sTUFBTSxNQUNuQixPQUFPO0NBRWY7Q0FDQSxTQUFTLGNBQWMsSUFBSTtFQUN2QixJQUFJLE9BQU8sS0FBSztHQUNaLE9BQU87RUFDWDtFQUNBLE1BQU0sS0FBSyxHQUFHLFdBQVcsQ0FBQztFQUMxQixPQUFPLE1BQU0sTUFBTSxNQUFNO0NBQzdCO0NBQ0EsU0FBUyx1QkFBdUIsTUFBTSxTQUFTO0VBQzNDLE1BQU0sRUFBRSxnQkFBZ0I7RUFDeEIsSUFBSSxnQkFBZ0IsR0FBOEI7R0FDOUMsT0FBTztFQUNYO0VBQ0EsV0FBVyxJQUFJO0VBQ2YsTUFBTSxNQUFNLGtCQUFrQixLQUFLLFlBQVksQ0FBQztFQUNoRCxLQUFLLFVBQVU7RUFDZixPQUFPO0NBQ1g7Q0FDQSxTQUFTLHNCQUFzQixNQUFNLFNBQVM7RUFDMUMsTUFBTSxFQUFFLGdCQUFnQjtFQUN4QixJQUFJLGdCQUFnQixHQUE4QjtHQUM5QyxPQUFPO0VBQ1g7RUFDQSxXQUFXLElBQUk7RUFDZixNQUFNLEtBQUssS0FBSyxZQUFZLE1BQU0sTUFBTSxLQUFLLEtBQUssSUFBSSxLQUFLLFlBQVk7RUFDdkUsTUFBTSxNQUFNLGNBQWMsRUFBRTtFQUM1QixLQUFLLFVBQVU7RUFDZixPQUFPO0NBQ1g7Q0FDQSxTQUFTLGVBQWUsTUFBTSxTQUFTO0VBQ25DLE1BQU0sRUFBRSxnQkFBZ0I7RUFDeEIsSUFBSSxnQkFBZ0IsR0FBOEI7R0FDOUMsT0FBTztFQUNYO0VBQ0EsV0FBVyxJQUFJO0VBQ2YsTUFBTSxNQUFNLEtBQUssWUFBWSxNQUFNO0VBQ25DLEtBQUssVUFBVTtFQUNmLE9BQU87Q0FDWDtDQUNBLFNBQVMsaUJBQWlCLE1BQU0sU0FBUztFQUNyQyxNQUFNLEVBQUUsZ0JBQWdCO0VBQ3hCLElBQUksZ0JBQWdCLEdBQWdDO0dBQ2hELE9BQU87RUFDWDtFQUNBLFdBQVcsSUFBSTtFQUNmLE1BQU0sTUFBTSxLQUFLLFlBQVksTUFBTTtFQUNuQyxLQUFLLFVBQVU7RUFDZixPQUFPO0NBQ1g7Q0FDQSxTQUFTLHNCQUFzQixNQUFNLFNBQVM7RUFDMUMsTUFBTSxFQUFFLGdCQUFnQjtFQUN4QixJQUFJLGdCQUFnQixHQUE4QjtHQUM5QyxPQUFPO0VBQ1g7RUFDQSxXQUFXLElBQUk7RUFDZixNQUFNLE1BQU0sa0JBQWtCLEtBQUssWUFBWSxDQUFDO0VBQ2hELEtBQUssVUFBVTtFQUNmLE9BQU87Q0FDWDtDQUNBLFNBQVMsdUJBQXVCLE1BQU0sU0FBUztFQUMzQyxNQUFNLEVBQUUsZ0JBQWdCO0VBQ3hCLElBQUksRUFBRSxnQkFBZ0IsS0FDbEIsZ0JBQWdCLEtBQXFDO0dBQ3JELE9BQU87RUFDWDtFQUNBLFdBQVcsSUFBSTtFQUNmLE1BQU0sTUFBTSxLQUFLLFlBQVksTUFBTTtFQUNuQyxLQUFLLFVBQVU7RUFDZixPQUFPO0NBQ1g7Q0FDQSxTQUFTLG1CQUFtQixNQUFNLFNBQVM7RUFDdkMsTUFBTSxFQUFFLGdCQUFnQjtFQUN4QixJQUFJLGdCQUFnQixHQUFvQztHQUNwRCxPQUFPO0VBQ1g7RUFDQSxNQUFNLFdBQVc7R0FDYixNQUFNLEtBQUssS0FBSyxZQUFZO0dBQzVCLElBQUksT0FBTyxLQUFnQztJQUN2QyxPQUFPLGtCQUFrQixLQUFLLEtBQUssQ0FBQztHQUN4QyxPQUNLLElBQUksT0FBTyxPQUNaLE9BQU8sT0FDUCxPQUFPLE9BQ1AsT0FBTyxPQUNQLE9BQU8sV0FDUCxDQUFDLElBQUk7SUFDTCxPQUFPO0dBQ1gsT0FDSyxJQUFJLE9BQU8sU0FBUztJQUNyQixLQUFLLEtBQUs7SUFDVixPQUFPLEdBQUc7R0FDZCxPQUNLOztJQUVELE9BQU8sWUFBWSxNQUFNLEtBQUs7R0FDbEM7RUFDSjtFQUNBLE1BQU0sTUFBTSxHQUFHO0VBQ2YsS0FBSyxVQUFVO0VBQ2YsT0FBTztDQUNYO0NBQ0EsU0FBUyxjQUFjLE1BQU07RUFDekIsV0FBVyxJQUFJO0VBQ2YsTUFBTSxNQUFNLEtBQUssWUFBWSxNQUFNO0VBQ25DLEtBQUssVUFBVTtFQUNmLE9BQU87Q0FDWDtDQUNBLFNBQVMsWUFBWSxNQUFNLFFBQVEsTUFBTTtFQUNyQyxNQUFNLE1BQU0sV0FBVyxPQUFPLE9BQU8sT0FBTztHQUN4QyxNQUFNLEtBQUssS0FBSyxZQUFZO0dBQzVCLElBQUksT0FBTyxLQUFnQztJQUN2QyxPQUFPO0dBQ1gsT0FDSyxJQUFJLE9BQU8sT0FBb0MsQ0FBQyxJQUFJO0lBQ3JELE9BQU87R0FDWCxPQUNLLElBQUksT0FBTyxLQUEyQjtJQUN2QyxPQUFPLEVBQUUsU0FBUyxXQUFXLFNBQVM7R0FDMUMsT0FDSyxJQUFJLE9BQU8sU0FBUztJQUNyQixLQUFLLEtBQUs7SUFDVixPQUFPLEdBQUcsTUFBTSxPQUFPO0dBQzNCLE9BQ0ssSUFBSSxPQUFPLFNBQVM7SUFDckIsS0FBSyxLQUFLO0lBQ1YsT0FBTyxHQUFHLE1BQU0sT0FBTztHQUMzQixPQUNLO0lBQ0QsT0FBTztHQUNYO0VBQ0o7RUFDQSxNQUFNLE1BQU0sR0FBRztFQUNmLFNBQVMsS0FBSyxVQUFVO0VBQ3hCLE9BQU87Q0FDWDtDQUNBLFNBQVMsU0FBUyxNQUFNLElBQUk7RUFDeEIsTUFBTSxLQUFLLEtBQUssWUFBWTtFQUM1QixJQUFJLE9BQU8sS0FBSztHQUNaLE9BQU87RUFDWDtFQUNBLElBQUksR0FBRyxFQUFFLEdBQUc7R0FDUixLQUFLLEtBQUs7R0FDVixPQUFPO0VBQ1g7RUFDQSxPQUFPO0NBQ1g7Q0FDQSxTQUFTLGFBQWEsSUFBSTtFQUN0QixNQUFNLEtBQUssR0FBRyxXQUFXLENBQUM7RUFDMUIsT0FBUyxNQUFNLE1BQU0sTUFBTSxPQUN0QixNQUFNLE1BQU0sTUFBTSxNQUNsQixNQUFNLE1BQU0sTUFBTSxNQUNuQixPQUFPLE1BQ1AsT0FBTztDQUVmO0NBQ0EsU0FBUyxtQkFBbUIsTUFBTTtFQUM5QixPQUFPLFNBQVMsTUFBTSxZQUFZO0NBQ3RDO0NBQ0EsU0FBUyxrQkFBa0IsSUFBSTtFQUMzQixNQUFNLEtBQUssR0FBRyxXQUFXLENBQUM7RUFDMUIsT0FBUyxNQUFNLE1BQU0sTUFBTSxPQUN0QixNQUFNLE1BQU0sTUFBTSxNQUNsQixNQUFNLE1BQU0sTUFBTSxNQUNuQixPQUFPLE1BQ1AsT0FBTyxNQUNQLE9BQU87Q0FFZjtDQUNBLFNBQVMsd0JBQXdCLE1BQU07RUFDbkMsT0FBTyxTQUFTLE1BQU0saUJBQWlCO0NBQzNDO0NBQ0EsU0FBUyxRQUFRLElBQUk7RUFDakIsTUFBTSxLQUFLLEdBQUcsV0FBVyxDQUFDO0VBQzFCLE9BQU8sTUFBTSxNQUFNLE1BQU07Q0FDN0I7Q0FDQSxTQUFTLFVBQVUsTUFBTTtFQUNyQixPQUFPLFNBQVMsTUFBTSxPQUFPO0NBQ2pDO0NBQ0EsU0FBUyxXQUFXLElBQUk7RUFDcEIsTUFBTSxLQUFLLEdBQUcsV0FBVyxDQUFDO0VBQzFCLE9BQVMsTUFBTSxNQUFNLE1BQU0sTUFDdEIsTUFBTSxNQUFNLE1BQU0sTUFDbEIsTUFBTSxNQUFNLE1BQU07Q0FDM0I7Q0FDQSxTQUFTLGFBQWEsTUFBTTtFQUN4QixPQUFPLFNBQVMsTUFBTSxVQUFVO0NBQ3BDO0NBQ0EsU0FBUyxVQUFVLE1BQU07RUFDckIsSUFBSSxLQUFLO0VBQ1QsSUFBSSxNQUFNO0VBQ1YsT0FBUSxLQUFLLFVBQVUsSUFBSSxHQUFJO0dBQzNCLE9BQU87RUFDWDtFQUNBLE9BQU87Q0FDWDtDQUNBLFNBQVMsU0FBUyxNQUFNO0VBQ3BCLElBQUksTUFBTTtFQUNWLE9BQU8sTUFBTTtHQUNULE1BQU0sS0FBSyxLQUFLLFlBQVk7R0FDNUIsSUFBSSxPQUFPLE1BQU07SUFDYixNQUFNLFNBQVMsS0FBSyxLQUFLO0lBQ3pCLElBQUksV0FBVyxPQUNYLFdBQVcsT0FDWCxXQUFXLE9BQ1gsV0FBVyxPQUNYLFdBQVcsTUFBTTtLQUNqQixPQUFPLEtBQUs7S0FDWixLQUFLLEtBQUs7S0FDVixLQUFLLEtBQUs7SUFDZCxPQUNLO0tBQ0QsS0FBSyxVQUFVO0tBQ2YsT0FBTztLQUNQLEtBQUssS0FBSztJQUNkO0dBQ0osT0FDSyxJQUFJLE9BQU8sT0FDWixPQUFPLE9BQ1AsT0FBTyxPQUNQLE9BQU8sT0FDUCxDQUFDLElBQUk7SUFDTDtHQUNKLE9BQ0ssSUFBSSxPQUFPLFdBQVcsT0FBTyxTQUFTO0lBQ3ZDLElBQUksWUFBWSxJQUFJLEdBQUc7S0FDbkIsT0FBTztLQUNQLEtBQUssS0FBSztJQUNkLE9BQ0ssSUFBSSxjQUFjLElBQUksR0FBRztLQUMxQjtJQUNKLE9BQ0s7S0FDRCxPQUFPO0tBQ1AsS0FBSyxLQUFLO0lBQ2Q7R0FDSixPQUNLO0lBQ0QsT0FBTztJQUNQLEtBQUssS0FBSztHQUNkO0VBQ0o7RUFDQSxPQUFPO0NBQ1g7Q0FDQSxTQUFTLG9CQUFvQixNQUFNO0VBQy9CLFdBQVcsSUFBSTtFQUNmLElBQUksS0FBSztFQUNULElBQUksT0FBTztFQUNYLE9BQVEsS0FBSyx3QkFBd0IsSUFBSSxHQUFJO0dBQ3pDLFFBQVE7RUFDWjs7RUFFQSxNQUFNLGNBQWMsS0FBSyxZQUFZO0VBQ3JDLElBQUksZUFDQSxnQkFBZ0IsT0FDaEIsZ0JBQWdCLE9BQ2hCLGdCQUFnQixXQUNoQixnQkFBZ0IsV0FDaEIsZ0JBQWdCLEtBQVU7R0FDMUIsTUFBTSxjQUFjLHNCQUFzQixJQUFJO0dBQzlDLFVBQVUsa0JBQWtCLDhCQUE4QixnQkFBZ0IsR0FBRyxHQUFHLE9BQU8sV0FBVztHQUNsRyxPQUFPLE9BQU87RUFDbEI7RUFDQSxJQUFJLEtBQUssWUFBWSxNQUFNLEtBQUs7R0FDNUIsVUFBVSxrQkFBa0IsNEJBQTRCLGdCQUFnQixHQUFHLENBQUM7RUFDaEY7RUFDQSxPQUFPO0NBQ1g7Q0FDQSxTQUFTLG1CQUFtQixNQUFNO0VBQzlCLFdBQVcsSUFBSTtFQUNmLElBQUksUUFBUTtFQUNaLElBQUksS0FBSyxZQUFZLE1BQU0sS0FBSztHQUM1QixLQUFLLEtBQUs7R0FDVixTQUFTLElBQUksVUFBVSxJQUFJO0VBQy9CLE9BQ0s7R0FDRCxTQUFTLFVBQVUsSUFBSTtFQUMzQjtFQUNBLElBQUksS0FBSyxZQUFZLE1BQU0sS0FBSztHQUM1QixVQUFVLGtCQUFrQiw0QkFBNEIsZ0JBQWdCLEdBQUcsQ0FBQztFQUNoRjtFQUNBLE9BQU87Q0FDWDtDQUNBLFNBQVMsVUFBVSxJQUFJO0VBQ25CLE9BQU8sT0FBTyxxQkFBcUIsT0FBTztDQUM5QztDQUNBLFNBQVMsWUFBWSxNQUFNO0VBQ3ZCLFdBQVcsSUFBSTs7RUFFZixJQUFJLE1BQU0sSUFBSTtFQUNkLElBQUksS0FBSztFQUNULElBQUksVUFBVTtFQUNkLE9BQVEsS0FBSyxTQUFTLE1BQU0sU0FBUyxHQUFJO0dBQ3JDLElBQUksT0FBTyxNQUFNO0lBQ2IsV0FBVyxtQkFBbUIsSUFBSTtHQUN0QyxPQUNLO0lBQ0QsV0FBVztHQUNmO0VBQ0o7RUFDQSxNQUFNLFVBQVUsS0FBSyxZQUFZO0VBQ2pDLElBQUksWUFBWSxXQUFXLFlBQVksS0FBSztHQUN4QyxVQUFVLGtCQUFrQiwwQ0FBMEMsZ0JBQWdCLEdBQUcsQ0FBQzs7R0FFMUYsSUFBSSxZQUFZLFNBQVM7SUFDckIsS0FBSyxLQUFLOztJQUVWLElBQUksTUFBTSxJQUFJO0dBQ2xCO0dBQ0EsT0FBTztFQUNYOztFQUVBLElBQUksTUFBTSxJQUFJO0VBQ2QsT0FBTztDQUNYO0NBQ0EsU0FBUyxtQkFBbUIsTUFBTTtFQUM5QixNQUFNLEtBQUssS0FBSyxZQUFZO0VBQzVCLFFBQVEsSUFBUjtHQUNJLEtBQUs7R0FDTCxLQUFLOztJQUNELEtBQUssS0FBSztJQUNWLE9BQU8sS0FBSztHQUNoQixLQUFLLEtBQ0QsT0FBTywwQkFBMEIsTUFBTSxJQUFJLENBQUM7R0FDaEQsS0FBSyxLQUNELE9BQU8sMEJBQTBCLE1BQU0sSUFBSSxDQUFDO0dBQ2hEO0lBQ0ksVUFBVSxrQkFBa0IseUJBQXlCLGdCQUFnQixHQUFHLEdBQUcsRUFBRTtJQUM3RSxPQUFPO0VBQ2Y7Q0FDSjtDQUNBLFNBQVMsMEJBQTBCLE1BQU0sU0FBUyxRQUFRO0VBQ3RELElBQUksTUFBTSxPQUFPO0VBQ2pCLElBQUksV0FBVztFQUNmLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLEtBQUs7R0FDN0IsTUFBTSxLQUFLLGFBQWEsSUFBSTtHQUM1QixJQUFJLENBQUMsSUFBSTtJQUNMLFVBQVUsa0JBQWtCLGlDQUFpQyxnQkFBZ0IsR0FBRyxHQUFHLEtBQUssVUFBVSxXQUFXLEtBQUssWUFBWSxHQUFHO0lBQ2pJO0dBQ0o7R0FDQSxZQUFZO0VBQ2hCO0VBQ0EsT0FBTyxLQUFLLFVBQVU7Q0FDMUI7Q0FDQSxTQUFTLG9CQUFvQixJQUFJO0VBQzdCLE9BQVEsT0FBTyxPQUNYLE9BQU8sT0FDUCxPQUFPLFdBQ1AsT0FBTztDQUNmO0NBQ0EsU0FBUyxzQkFBc0IsTUFBTTtFQUNqQyxXQUFXLElBQUk7RUFDZixJQUFJLEtBQUs7RUFDVCxJQUFJLGNBQWM7RUFDbEIsT0FBUSxLQUFLLFNBQVMsTUFBTSxtQkFBbUIsR0FBSTtHQUMvQyxlQUFlO0VBQ25CO0VBQ0EsT0FBTztDQUNYO0NBQ0EsU0FBUyxtQkFBbUIsTUFBTTtFQUM5QixJQUFJLEtBQUs7RUFDVCxJQUFJLE9BQU87RUFDWCxPQUFRLEtBQUssbUJBQW1CLElBQUksR0FBSTtHQUNwQyxRQUFRO0VBQ1o7RUFDQSxPQUFPO0NBQ1g7Q0FDQSxTQUFTLGdCQUFnQixNQUFNO0VBQzNCLE1BQU0sTUFBTSxRQUFRO0dBQ2hCLE1BQU0sS0FBSyxLQUFLLFlBQVk7R0FDNUIsSUFBSSxPQUFPLE9BQ1AsT0FBTyxPQUNQLE9BQU8sT0FDUCxPQUFPLE9BQ1AsT0FBTyxPQUNQLENBQUMsSUFBSTtJQUNMLE9BQU87R0FDWCxPQUNLLElBQUksT0FBTyxTQUFTO0lBQ3JCLE9BQU87R0FDWCxPQUNLLElBQUksT0FBTyxXQUFXLE9BQU8sS0FBSztJQUNuQyxPQUFPO0lBQ1AsS0FBSyxLQUFLO0lBQ1YsT0FBTyxHQUFHLEdBQUc7R0FDakIsT0FDSztJQUNELE9BQU87SUFDUCxLQUFLLEtBQUs7SUFDVixPQUFPLEdBQUcsR0FBRztHQUNqQjtFQUNKO0VBQ0EsT0FBTyxHQUFHLEVBQUU7Q0FDaEI7Q0FDQSxTQUFTLFdBQVcsTUFBTTtFQUN0QixXQUFXLElBQUk7RUFDZixNQUFNLFNBQVM7R0FBSTtHQUFNOztFQUF5QjtFQUNsRCxXQUFXLElBQUk7RUFDZixPQUFPO0NBQ1g7O0NBRUEsU0FBUyx1QkFBdUIsTUFBTSxTQUFTO0VBQzNDLElBQUksUUFBUTtFQUNaLE1BQU0sS0FBSyxLQUFLLFlBQVk7RUFDNUIsUUFBUSxJQUFSO0dBQ0ksS0FBSztJQUNELElBQUksUUFBUSxhQUFhLEdBQUc7S0FDeEIsVUFBVSxrQkFBa0IsNEJBQTRCLGdCQUFnQixHQUFHLENBQUM7SUFDaEY7SUFDQSxLQUFLLEtBQUs7SUFDVixRQUFRO0tBQVM7S0FBUztLQUE4Qjs7SUFBOEI7SUFDdEYsV0FBVyxJQUFJO0lBQ2YsUUFBUTtJQUNSLE9BQU87R0FDWCxLQUFLO0lBQ0QsSUFBSSxRQUFRLFlBQVksS0FDcEIsUUFBUSxnQkFBZ0IsR0FBOEI7S0FDdEQsVUFBVSxrQkFBa0IsbUJBQW1CLGdCQUFnQixHQUFHLENBQUM7SUFDdkU7SUFDQSxLQUFLLEtBQUs7SUFDVixRQUFRO0tBQVM7S0FBUztLQUErQjs7SUFBK0I7SUFDeEYsUUFBUTtJQUNSLFFBQVEsWUFBWSxLQUFLLFdBQVcsSUFBSTtJQUN4QyxJQUFJLFFBQVEsWUFBWSxRQUFRLGNBQWMsR0FBRztLQUM3QyxRQUFRLFdBQVc7SUFDdkI7SUFDQSxPQUFPO0dBQ1gsS0FBSztJQUNELElBQUksUUFBUSxZQUFZLEdBQUc7S0FDdkIsVUFBVSxrQkFBa0IsNEJBQTRCLGdCQUFnQixHQUFHLENBQUM7SUFDaEY7SUFDQSxRQUFRLGtCQUFrQixNQUFNLE9BQU8sS0FBSyxZQUFZLE9BQU87SUFDL0QsUUFBUSxZQUFZO0lBQ3BCLE9BQU87R0FDWCxTQUFTO0lBQ0wsSUFBSSx1QkFBdUI7SUFDM0IsSUFBSSxzQkFBc0I7SUFDMUIsSUFBSSxlQUFlO0lBQ25CLElBQUksY0FBYyxJQUFJLEdBQUc7S0FDckIsSUFBSSxRQUFRLFlBQVksR0FBRztNQUN2QixVQUFVLGtCQUFrQiw0QkFBNEIsZ0JBQWdCLEdBQUcsQ0FBQztLQUNoRjtLQUNBLFFBQVEsU0FBUyxTQUFTLEdBQXlCLFdBQVcsSUFBSSxDQUFDOztLQUVuRSxRQUFRLFlBQVk7S0FDcEIsUUFBUSxXQUFXO0tBQ25CLE9BQU87SUFDWDtJQUNBLElBQUksUUFBUSxZQUFZLE1BQ25CLFFBQVEsZ0JBQWdCLEtBQ3JCLFFBQVEsZ0JBQWdCLEtBQ3hCLFFBQVEsZ0JBQWdCLElBQTZCO0tBQ3pELFVBQVUsa0JBQWtCLDRCQUE0QixnQkFBZ0IsR0FBRyxDQUFDO0tBQzVFLFFBQVEsWUFBWTtLQUNwQixPQUFPLFVBQVUsTUFBTSxPQUFPO0lBQ2xDO0lBQ0EsSUFBSyx1QkFBdUIsdUJBQXVCLE1BQU0sT0FBTyxHQUFJO0tBQ2hFLFFBQVEsU0FBUyxTQUFTLEdBQTBCLG9CQUFvQixJQUFJLENBQUM7S0FDN0UsV0FBVyxJQUFJO0tBQ2YsT0FBTztJQUNYO0lBQ0EsSUFBSyxzQkFBc0Isc0JBQXNCLE1BQU0sT0FBTyxHQUFJO0tBQzlELFFBQVEsU0FBUyxTQUFTLEdBQXlCLG1CQUFtQixJQUFJLENBQUM7S0FDM0UsV0FBVyxJQUFJO0tBQ2YsT0FBTztJQUNYO0lBQ0EsSUFBSyxlQUFlLGVBQWUsTUFBTSxPQUFPLEdBQUk7S0FDaEQsUUFBUSxTQUFTLFNBQVMsR0FBNEIsWUFBWSxJQUFJLENBQUM7S0FDdkUsV0FBVyxJQUFJO0tBQ2YsT0FBTztJQUNYO0lBQ0EsSUFBSSxDQUFDLHdCQUF3QixDQUFDLHVCQUF1QixDQUFDLGNBQWM7O0tBRWhFLFFBQVEsU0FBUyxTQUFTLElBQWtDLHNCQUFzQixJQUFJLENBQUM7S0FDdkYsVUFBVSxrQkFBa0IsOEJBQThCLGdCQUFnQixHQUFHLEdBQUcsTUFBTSxLQUFLO0tBQzNGLFdBQVcsSUFBSTtLQUNmLE9BQU87SUFDWDtJQUNBO0dBQ0o7RUFDSjtFQUNBLE9BQU87Q0FDWDs7Q0FFQSxTQUFTLGtCQUFrQixNQUFNLFNBQVM7RUFDdEMsTUFBTSxFQUFFLGdCQUFnQjtFQUN4QixJQUFJLFFBQVE7RUFDWixNQUFNLEtBQUssS0FBSyxZQUFZO0VBQzVCLEtBQUssZ0JBQWdCLEtBQ2pCLGdCQUFnQixLQUNoQixnQkFBZ0IsTUFDaEIsZ0JBQWdCLE9BQ2YsT0FBTyxXQUFXLE9BQU8sVUFBVTtHQUNwQyxVQUFVLGtCQUFrQix1QkFBdUIsZ0JBQWdCLEdBQUcsQ0FBQztFQUMzRTtFQUNBLFFBQVEsSUFBUjtHQUNJLEtBQUs7SUFDRCxLQUFLLEtBQUs7SUFDVixRQUFRO0tBQVM7S0FBUztLQUFnQzs7SUFBZ0M7SUFDMUYsUUFBUSxXQUFXO0lBQ25CLE9BQU87R0FDWCxLQUFLO0lBQ0QsV0FBVyxJQUFJO0lBQ2YsS0FBSyxLQUFLO0lBQ1YsT0FBTztLQUFTO0tBQVM7S0FBOEI7O0lBQThCO0dBQ3pGLEtBQUs7SUFDRCxXQUFXLElBQUk7SUFDZixLQUFLLEtBQUs7SUFDVixPQUFPO0tBQVM7S0FBUztLQUFvQzs7SUFBb0M7R0FDckc7SUFDSSxJQUFJLGNBQWMsSUFBSSxHQUFHO0tBQ3JCLFFBQVEsU0FBUyxTQUFTLEdBQXlCLFdBQVcsSUFBSSxDQUFDOztLQUVuRSxRQUFRLFlBQVk7S0FDcEIsUUFBUSxXQUFXO0tBQ25CLE9BQU87SUFDWDtJQUNBLElBQUksaUJBQWlCLE1BQU0sT0FBTyxLQUM5Qix1QkFBdUIsTUFBTSxPQUFPLEdBQUc7S0FDdkMsV0FBVyxJQUFJO0tBQ2YsT0FBTyxrQkFBa0IsTUFBTSxPQUFPO0lBQzFDO0lBQ0EsSUFBSSxzQkFBc0IsTUFBTSxPQUFPLEdBQUc7S0FDdEMsV0FBVyxJQUFJO0tBQ2YsT0FBTyxTQUFTLFNBQVMsSUFBb0MsbUJBQW1CLElBQUksQ0FBQztJQUN6RjtJQUNBLElBQUksbUJBQW1CLE1BQU0sT0FBTyxHQUFHO0tBQ25DLFdBQVcsSUFBSTtLQUNmLElBQUksT0FBTyxLQUFnQzs7TUFFdkMsT0FBTyx1QkFBdUIsTUFBTSxPQUFPLEtBQUs7S0FDcEQsT0FDSztNQUNELE9BQU8sU0FBUyxTQUFTLElBQStCLGdCQUFnQixJQUFJLENBQUM7S0FDakY7SUFDSjtJQUNBLElBQUksZ0JBQWdCLEdBQWdDO0tBQ2hELFVBQVUsa0JBQWtCLHVCQUF1QixnQkFBZ0IsR0FBRyxDQUFDO0lBQzNFO0lBQ0EsUUFBUSxZQUFZO0lBQ3BCLFFBQVEsV0FBVztJQUNuQixPQUFPLFVBQVUsTUFBTSxPQUFPO0VBQ3RDO0NBQ0o7O0NBRUEsU0FBUyxVQUFVLE1BQU0sU0FBUztFQUM5QixJQUFJLFFBQVEsRUFBRSxNQUFNLEdBQXdCO0VBQzVDLElBQUksUUFBUSxZQUFZLEdBQUc7R0FDdkIsT0FBTyx1QkFBdUIsTUFBTSxPQUFPLEtBQUssWUFBWSxPQUFPO0VBQ3ZFO0VBQ0EsSUFBSSxRQUFRLFVBQVU7R0FDbEIsT0FBTyxrQkFBa0IsTUFBTSxPQUFPLEtBQUssWUFBWSxPQUFPO0VBQ2xFO0VBQ0EsTUFBTSxLQUFLLEtBQUssWUFBWTtFQUM1QixRQUFRLElBQVI7R0FDSSxLQUFLLEtBQ0QsT0FBTyx1QkFBdUIsTUFBTSxPQUFPLEtBQUssWUFBWSxPQUFPO0dBQ3ZFLEtBQUs7SUFDRCxVQUFVLGtCQUFrQiwwQkFBMEIsZ0JBQWdCLEdBQUcsQ0FBQztJQUMxRSxLQUFLLEtBQUs7SUFDVixPQUFPO0tBQVM7S0FBUztLQUErQjs7SUFBK0I7R0FDM0YsS0FBSyxLQUNELE9BQU8sa0JBQWtCLE1BQU0sT0FBTyxLQUFLLFlBQVksT0FBTztHQUNsRSxTQUFTO0lBQ0wsSUFBSSxjQUFjLElBQUksR0FBRztLQUNyQixRQUFRLFNBQVMsU0FBUyxHQUF5QixXQUFXLElBQUksQ0FBQzs7S0FFbkUsUUFBUSxZQUFZO0tBQ3BCLFFBQVEsV0FBVztLQUNuQixPQUFPO0lBQ1g7SUFDQSxJQUFJLFlBQVksSUFBSSxHQUFHO0tBQ25CLE9BQU8sU0FBUyxTQUFTLEdBQXlCLFNBQVMsSUFBSSxDQUFDO0lBQ3BFO0lBQ0E7R0FDSjtFQUNKO0VBQ0EsT0FBTztDQUNYO0NBQ0EsU0FBUyxZQUFZO0VBQ2pCLE1BQU0sRUFBRSxhQUFhLFFBQVEsVUFBVSxXQUFXO0VBQ2xELFNBQVMsV0FBVztFQUNwQixTQUFTLGFBQWE7RUFDdEIsU0FBUyxlQUFlO0VBQ3hCLFNBQVMsYUFBYTtFQUN0QixTQUFTLFNBQVMsY0FBYztFQUNoQyxTQUFTLFdBQVcsZ0JBQWdCO0VBQ3BDLElBQUksTUFBTSxZQUFZLE1BQU0sS0FBSztHQUM3QixPQUFPO0lBQVM7SUFBVTs7R0FBdUI7RUFDckQ7RUFDQSxPQUFPLFVBQVUsT0FBTyxRQUFRO0NBQ3BDO0NBQ0EsT0FBTztFQUNIO0VBQ0E7RUFDQTtFQUNBO0NBQ0o7QUFDSjtBQUVBLE1BQU0saUJBQWlCOztBQUV2QixNQUFNLGdCQUFnQjs7QUFFdEIsTUFBTSxlQUFlO0FBQ3JCLFNBQVMsdUJBQXVCLFFBQVEsTUFBTTtDQUMxQyxPQUFPO0FBQ1g7QUFDQSxTQUFTLG1CQUFtQixPQUFPLFlBQVksWUFBWTtDQUN2RCxRQUFRLE9BQVI7RUFDSSxLQUFLLFFBQ0QsT0FBTzs7RUFFWCxLQUFLOztFQUVELE9BQU87RUFDWCxTQUFTO0dBQ0wsTUFBTSxZQUFZLFNBQVMsY0FBYyxZQUFZLEVBQUU7R0FDdkQsSUFBSSxhQUFhLFNBQVUsYUFBYSxPQUFRO0lBQzVDLE9BQU8sT0FBTyxjQUFjLFNBQVM7R0FDekM7OztHQUdBLE9BQU87RUFDWDtDQUNKO0FBQ0o7QUFDQSxTQUFTLGFBQWEsVUFBVSxDQUFDLEdBQUc7Q0FDaEMsTUFBTSxXQUFXLFFBQVEsYUFBYTtDQUN0QyxNQUFNLEVBQUUsWUFBWTtDQUNwQixTQUFTLFVBQVUsVUFBVSxNQUFNLE9BQU8sUUFBUSxHQUFHLE1BQU07RUFDdkQsTUFBTSxNQUFNLFNBQVMsZ0JBQWdCO0VBQ3JDLElBQUksVUFBVTtFQUNkLElBQUksVUFBVTtFQUNkLElBQUksU0FBUztHQUNULE1BQU0sTUFBTSxXQUFXLGVBQWUsT0FBTyxHQUFHLElBQUk7R0FDcEQsTUFBTSxNQUFNLG1CQUFtQixNQUFNLEtBQUs7SUFDdEMsUUFBUTtJQUNSO0dBQ0osQ0FBQztHQUNELFFBQVEsR0FBRztFQUNmO0NBQ0o7Q0FDQSxTQUFTLFVBQVUsTUFBTSxRQUFRLEtBQUs7RUFDbEMsTUFBTSxPQUFPLEVBQUUsS0FBSztFQUNwQixJQUFJLFVBQVU7R0FDVixLQUFLLFFBQVE7R0FDYixLQUFLLE1BQU07R0FDWCxLQUFLLE1BQU07SUFBRSxPQUFPO0lBQUssS0FBSztHQUFJO0VBQ3RDO0VBQ0EsT0FBTztDQUNYO0NBQ0EsU0FBUyxRQUFRLE1BQU0sUUFBUSxLQUFLLE1BQU07RUFDdEMsSUFBSSxVQUFVO0dBQ1YsS0FBSyxNQUFNO0dBQ1gsSUFBSSxLQUFLLEtBQUs7SUFDVixLQUFLLElBQUksTUFBTTtHQUNuQjtFQUNKO0NBQ0o7Q0FDQSxTQUFTLFVBQVUsV0FBVyxPQUFPO0VBQ2pDLE1BQU0sVUFBVSxVQUFVLFFBQVE7RUFDbEMsTUFBTSxPQUFPLFVBQVUsR0FBd0IsUUFBUSxRQUFRLFFBQVEsUUFBUTtFQUMvRSxLQUFLLFFBQVEsTUFBTSxRQUFRLGNBQWMsc0JBQXNCO0VBQy9ELFFBQVEsTUFBTSxVQUFVLGNBQWMsR0FBRyxVQUFVLGdCQUFnQixDQUFDO0VBQ3BFLE9BQU87Q0FDWDtDQUNBLFNBQVMsVUFBVSxXQUFXLE9BQU87RUFDakMsTUFBTSxVQUFVLFVBQVUsUUFBUTtFQUNsQyxNQUFNLEVBQUUsWUFBWSxRQUFRLGNBQWMsUUFBUTtFQUNsRCxNQUFNLE9BQU8sVUFBVSxHQUF3QixRQUFRLEdBQUc7RUFDMUQsS0FBSyxRQUFRLFNBQVMsT0FBTyxFQUFFO0VBQy9CLFVBQVUsVUFBVTtFQUNwQixRQUFRLE1BQU0sVUFBVSxjQUFjLEdBQUcsVUFBVSxnQkFBZ0IsQ0FBQztFQUNwRSxPQUFPO0NBQ1g7Q0FDQSxTQUFTLFdBQVcsV0FBVyxLQUFLO0VBQ2hDLE1BQU0sVUFBVSxVQUFVLFFBQVE7RUFDbEMsTUFBTSxFQUFFLFlBQVksUUFBUSxjQUFjLFFBQVE7RUFDbEQsTUFBTSxPQUFPLFVBQVUsR0FBeUIsUUFBUSxHQUFHO0VBQzNELEtBQUssTUFBTTtFQUNYLFVBQVUsVUFBVTtFQUNwQixRQUFRLE1BQU0sVUFBVSxjQUFjLEdBQUcsVUFBVSxnQkFBZ0IsQ0FBQztFQUNwRSxPQUFPO0NBQ1g7Q0FDQSxTQUFTLGFBQWEsV0FBVyxPQUFPO0VBQ3BDLE1BQU0sVUFBVSxVQUFVLFFBQVE7RUFDbEMsTUFBTSxFQUFFLFlBQVksUUFBUSxjQUFjLFFBQVE7RUFDbEQsTUFBTSxPQUFPLFVBQVUsR0FBMkIsUUFBUSxHQUFHO0VBQzdELEtBQUssUUFBUSxNQUFNLFFBQVEsZUFBZSxrQkFBa0I7RUFDNUQsVUFBVSxVQUFVO0VBQ3BCLFFBQVEsTUFBTSxVQUFVLGNBQWMsR0FBRyxVQUFVLGdCQUFnQixDQUFDO0VBQ3BFLE9BQU87Q0FDWDtDQUNBLFNBQVMsb0JBQW9CLFdBQVc7RUFDcEMsTUFBTSxRQUFRLFVBQVUsVUFBVTtFQUNsQyxNQUFNLFVBQVUsVUFBVSxRQUFRO0VBQ2xDLE1BQU0sRUFBRSxZQUFZLFFBQVEsY0FBYyxRQUFRO0VBQ2xELE1BQU0sT0FBTyxVQUFVLEdBQWtDLFFBQVEsR0FBRztFQUNwRSxJQUFJLE1BQU0sU0FBUyxJQUFvQzs7R0FFbkQsVUFBVSxXQUFXLGtCQUFrQixrQ0FBa0MsUUFBUSxjQUFjLENBQUM7R0FDaEcsS0FBSyxRQUFRO0dBQ2IsUUFBUSxNQUFNLFFBQVEsR0FBRztHQUN6QixPQUFPO0lBQ0gsa0JBQWtCO0lBQ2xCO0dBQ0o7RUFDSjs7RUFFQSxJQUFJLE1BQU0sU0FBUyxNQUFNO0dBQ3JCLFVBQVUsV0FBVyxrQkFBa0IsNkJBQTZCLFFBQVEsY0FBYyxHQUFHLGdCQUFnQixLQUFLLENBQUM7RUFDdkg7RUFDQSxLQUFLLFFBQVEsTUFBTSxTQUFTO0VBQzVCLFFBQVEsTUFBTSxVQUFVLGNBQWMsR0FBRyxVQUFVLGdCQUFnQixDQUFDO0VBQ3BFLE9BQU8sRUFDSCxLQUNKO0NBQ0o7Q0FDQSxTQUFTLGVBQWUsV0FBVyxPQUFPO0VBQ3RDLE1BQU0sVUFBVSxVQUFVLFFBQVE7RUFDbEMsTUFBTSxPQUFPLFVBQVUsR0FBNkIsUUFBUSxRQUFRLFFBQVEsUUFBUTtFQUNwRixLQUFLLFFBQVE7RUFDYixRQUFRLE1BQU0sVUFBVSxjQUFjLEdBQUcsVUFBVSxnQkFBZ0IsQ0FBQztFQUNwRSxPQUFPO0NBQ1g7Q0FDQSxTQUFTLFlBQVksV0FBVztFQUM1QixNQUFNLFVBQVUsVUFBVSxRQUFRO0VBQ2xDLE1BQU0sYUFBYSxVQUFVLEdBQTBCLFFBQVEsUUFBUSxRQUFRLFFBQVE7RUFDdkYsSUFBSSxRQUFRLFVBQVUsVUFBVTtFQUNoQyxJQUFJLE1BQU0sU0FBUyxHQUE4QjtHQUM3QyxNQUFNLFNBQVMsb0JBQW9CLFNBQVM7R0FDNUMsV0FBVyxXQUFXLE9BQU87R0FDN0IsUUFBUSxPQUFPLG9CQUFvQixVQUFVLFVBQVU7RUFDM0Q7O0VBRUEsSUFBSSxNQUFNLFNBQVMsR0FBb0M7R0FDbkQsVUFBVSxXQUFXLGtCQUFrQiw2QkFBNkIsUUFBUSxjQUFjLEdBQUcsZ0JBQWdCLEtBQUssQ0FBQztFQUN2SDtFQUNBLFFBQVEsVUFBVSxVQUFVOztFQUU1QixJQUFJLE1BQU0sU0FBUyxHQUE4QjtHQUM3QyxRQUFRLFVBQVUsVUFBVTtFQUNoQztFQUNBLFFBQVEsTUFBTSxNQUFkO0dBQ0ksS0FBSztJQUNELElBQUksTUFBTSxTQUFTLE1BQU07S0FDckIsVUFBVSxXQUFXLGtCQUFrQiw2QkFBNkIsUUFBUSxjQUFjLEdBQUcsZ0JBQWdCLEtBQUssQ0FBQztJQUN2SDtJQUNBLFdBQVcsTUFBTSxlQUFlLFdBQVcsTUFBTSxTQUFTLEVBQUU7SUFDNUQ7R0FDSixLQUFLO0lBQ0QsSUFBSSxNQUFNLFNBQVMsTUFBTTtLQUNyQixVQUFVLFdBQVcsa0JBQWtCLDZCQUE2QixRQUFRLGNBQWMsR0FBRyxnQkFBZ0IsS0FBSyxDQUFDO0lBQ3ZIO0lBQ0EsV0FBVyxNQUFNLFdBQVcsV0FBVyxNQUFNLFNBQVMsRUFBRTtJQUN4RDtHQUNKLEtBQUs7SUFDRCxJQUFJLE1BQU0sU0FBUyxNQUFNO0tBQ3JCLFVBQVUsV0FBVyxrQkFBa0IsNkJBQTZCLFFBQVEsY0FBYyxHQUFHLGdCQUFnQixLQUFLLENBQUM7SUFDdkg7SUFDQSxXQUFXLE1BQU0sVUFBVSxXQUFXLE1BQU0sU0FBUyxFQUFFO0lBQ3ZEO0dBQ0osS0FBSztJQUNELElBQUksTUFBTSxTQUFTLE1BQU07S0FDckIsVUFBVSxXQUFXLGtCQUFrQiw2QkFBNkIsUUFBUSxjQUFjLEdBQUcsZ0JBQWdCLEtBQUssQ0FBQztJQUN2SDtJQUNBLFdBQVcsTUFBTSxhQUFhLFdBQVcsTUFBTSxTQUFTLEVBQUU7SUFDMUQ7R0FDSixTQUFTOztJQUVMLFVBQVUsV0FBVyxrQkFBa0IsNkJBQTZCLFFBQVEsY0FBYyxDQUFDO0lBQzNGLE1BQU0sY0FBYyxVQUFVLFFBQVE7SUFDdEMsTUFBTSxxQkFBcUIsVUFBVSxHQUE2QixZQUFZLFFBQVEsWUFBWSxRQUFRO0lBQzFHLG1CQUFtQixRQUFRO0lBQzNCLFFBQVEsb0JBQW9CLFlBQVksUUFBUSxZQUFZLFFBQVE7SUFDcEUsV0FBVyxNQUFNO0lBQ2pCLFFBQVEsWUFBWSxZQUFZLFFBQVEsWUFBWSxRQUFRO0lBQzVELE9BQU87S0FDSCxrQkFBa0I7S0FDbEIsTUFBTTtJQUNWO0dBQ0o7RUFDSjtFQUNBLFFBQVEsWUFBWSxVQUFVLGNBQWMsR0FBRyxVQUFVLGdCQUFnQixDQUFDO0VBQzFFLE9BQU8sRUFDSCxNQUFNLFdBQ1Y7Q0FDSjtDQUNBLFNBQVMsYUFBYSxXQUFXO0VBQzdCLE1BQU0sVUFBVSxVQUFVLFFBQVE7RUFDbEMsTUFBTSxjQUFjLFFBQVEsZ0JBQWdCLElBQ3RDLFVBQVUsY0FBYyxJQUN4QixRQUFRO0VBQ2QsTUFBTSxXQUFXLFFBQVEsZ0JBQWdCLElBQ25DLFFBQVEsU0FDUixRQUFRO0VBQ2QsTUFBTSxPQUFPLFVBQVUsR0FBMkIsYUFBYSxRQUFRO0VBQ3ZFLEtBQUssUUFBUSxDQUFDO0VBQ2QsSUFBSSxZQUFZO0VBQ2hCLEdBQUc7R0FDQyxNQUFNLFFBQVEsYUFBYSxVQUFVLFVBQVU7R0FDL0MsWUFBWTtHQUNaLFFBQVEsTUFBTSxNQUFkO0lBQ0ksS0FBSztLQUNELElBQUksTUFBTSxTQUFTLE1BQU07TUFDckIsVUFBVSxXQUFXLGtCQUFrQiw2QkFBNkIsUUFBUSxjQUFjLEdBQUcsZ0JBQWdCLEtBQUssQ0FBQztLQUN2SDtLQUNBLEtBQUssTUFBTSxLQUFLLFVBQVUsV0FBVyxNQUFNLFNBQVMsRUFBRSxDQUFDO0tBQ3ZEO0lBQ0osS0FBSztLQUNELElBQUksTUFBTSxTQUFTLE1BQU07TUFDckIsVUFBVSxXQUFXLGtCQUFrQiw2QkFBNkIsUUFBUSxjQUFjLEdBQUcsZ0JBQWdCLEtBQUssQ0FBQztLQUN2SDtLQUNBLEtBQUssTUFBTSxLQUFLLFVBQVUsV0FBVyxNQUFNLFNBQVMsRUFBRSxDQUFDO0tBQ3ZEO0lBQ0osS0FBSztLQUNELElBQUksTUFBTSxTQUFTLE1BQU07TUFDckIsVUFBVSxXQUFXLGtCQUFrQiw2QkFBNkIsUUFBUSxjQUFjLEdBQUcsZ0JBQWdCLEtBQUssQ0FBQztLQUN2SDtLQUNBLEtBQUssTUFBTSxLQUFLLFdBQVcsV0FBVyxNQUFNLFNBQVMsRUFBRSxDQUFDO0tBQ3hEO0lBQ0osS0FBSztLQUNELElBQUksTUFBTSxTQUFTLE1BQU07TUFDckIsVUFBVSxXQUFXLGtCQUFrQiw2QkFBNkIsUUFBUSxjQUFjLEdBQUcsZ0JBQWdCLEtBQUssQ0FBQztLQUN2SDtLQUNBLEtBQUssTUFBTSxLQUFLLGFBQWEsV0FBVyxNQUFNLFNBQVMsRUFBRSxDQUFDO0tBQzFEO0lBQ0osS0FBSyxHQUFnQztLQUNqQyxNQUFNLFNBQVMsWUFBWSxTQUFTO0tBQ3BDLEtBQUssTUFBTSxLQUFLLE9BQU8sSUFBSTtLQUMzQixZQUFZLE9BQU8sb0JBQW9CO0tBQ3ZDO0lBQ0o7R0FDSjtFQUNKLFNBQVMsUUFBUSxnQkFBZ0IsTUFDN0IsUUFBUSxnQkFBZ0I7O0VBRTVCLE1BQU0sWUFBWSxRQUFRLGdCQUFnQixJQUNwQyxRQUFRLGFBQ1IsVUFBVSxjQUFjO0VBQzlCLE1BQU0sU0FBUyxRQUFRLGdCQUFnQixJQUNqQyxRQUFRLGFBQ1IsVUFBVSxnQkFBZ0I7RUFDaEMsUUFBUSxNQUFNLFdBQVcsTUFBTTtFQUMvQixPQUFPO0NBQ1g7Q0FDQSxTQUFTLFlBQVksV0FBVyxRQUFRLEtBQUssU0FBUztFQUNsRCxNQUFNLFVBQVUsVUFBVSxRQUFRO0VBQ2xDLElBQUksa0JBQWtCLFFBQVEsTUFBTSxXQUFXO0VBQy9DLE1BQU0sT0FBTyxVQUFVLEdBQTBCLFFBQVEsR0FBRztFQUM1RCxLQUFLLFFBQVEsQ0FBQztFQUNkLEtBQUssTUFBTSxLQUFLLE9BQU87RUFDdkIsR0FBRztHQUNDLE1BQU0sTUFBTSxhQUFhLFNBQVM7R0FDbEMsSUFBSSxDQUFDLGlCQUFpQjtJQUNsQixrQkFBa0IsSUFBSSxNQUFNLFdBQVc7R0FDM0M7R0FDQSxLQUFLLE1BQU0sS0FBSyxHQUFHO0VBQ3ZCLFNBQVMsUUFBUSxnQkFBZ0I7RUFDakMsSUFBSSxpQkFBaUI7R0FDakIsVUFBVSxXQUFXLGtCQUFrQiw4QkFBOEIsS0FBSyxDQUFDO0VBQy9FO0VBQ0EsUUFBUSxNQUFNLFVBQVUsY0FBYyxHQUFHLFVBQVUsZ0JBQWdCLENBQUM7RUFDcEUsT0FBTztDQUNYO0NBQ0EsU0FBUyxjQUFjLFdBQVc7RUFDOUIsTUFBTSxVQUFVLFVBQVUsUUFBUTtFQUNsQyxNQUFNLEVBQUUsUUFBUSxhQUFhO0VBQzdCLE1BQU0sVUFBVSxhQUFhLFNBQVM7RUFDdEMsSUFBSSxRQUFRLGdCQUFnQixJQUF5QjtHQUNqRCxPQUFPO0VBQ1gsT0FDSztHQUNELE9BQU8sWUFBWSxXQUFXLFFBQVEsVUFBVSxPQUFPO0VBQzNEO0NBQ0o7Q0FDQSxTQUFTLE1BQU0sUUFBUTtFQUNuQixNQUFNLFlBQVksZ0JBQWdCLFFBQVEsT0FBTyxDQUFDLEdBQUcsT0FBTyxDQUFDO0VBQzdELE1BQU0sVUFBVSxVQUFVLFFBQVE7RUFDbEMsTUFBTSxPQUFPLFVBQVUsR0FBNEIsUUFBUSxRQUFRLFFBQVEsUUFBUTtFQUNuRixJQUFJLFlBQVksS0FBSyxLQUFLO0dBQ3RCLEtBQUssSUFBSSxTQUFTO0VBQ3RCO0VBQ0EsS0FBSyxPQUFPLGNBQWMsU0FBUztFQUNuQyxJQUFJLFFBQVEsWUFBWTtHQUNwQixLQUFLLFdBQVcsUUFBUSxXQUFXLE1BQU07RUFDN0M7O0VBRUEsSUFBSSxRQUFRLGdCQUFnQixJQUF5QjtHQUNqRCxVQUFVLFdBQVcsa0JBQWtCLDZCQUE2QixRQUFRLGNBQWMsR0FBRyxPQUFPLFFBQVEsV0FBVyxFQUFFO0VBQzdIO0VBQ0EsUUFBUSxNQUFNLFVBQVUsY0FBYyxHQUFHLFVBQVUsZ0JBQWdCLENBQUM7RUFDcEUsT0FBTztDQUNYO0NBQ0EsT0FBTyxFQUFFLE1BQU07QUFDbkI7QUFDQSxTQUFTLGdCQUFnQixPQUFPO0NBQzVCLElBQUksTUFBTSxTQUFTLElBQXlCO0VBQ3hDLE9BQU87Q0FDWDtDQUNBLE1BQU0sUUFBUSxNQUFNLFNBQVMsR0FBRSxDQUFFLFFBQVEsV0FBVyxLQUFLO0NBQ3pELE9BQU8sS0FBSyxTQUFTLEtBQUssS0FBSyxNQUFNLEdBQUcsQ0FBQyxJQUFJLE1BQU07QUFDdkQ7QUFFQSxTQUFTLGtCQUFrQixLQUFLLFVBQVUsQ0FBQyxHQUN6QztDQUNFLE1BQU0sV0FBVztFQUNiO0VBQ0EsU0FBUyxJQUFJLElBQUk7Q0FDckI7Q0FDQSxNQUFNLGdCQUFnQjtDQUN0QixNQUFNLFVBQVUsU0FBUztFQUNyQixTQUFTLFFBQVEsSUFBSSxJQUFJO0VBQ3pCLE9BQU87Q0FDWDtDQUNBLE9BQU87RUFBRTtFQUFTO0NBQU87QUFDN0I7QUFDQSxTQUFTLGNBQWMsT0FBTyxhQUFhO0NBQ3ZDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztFQUNuQyxhQUFhLE1BQU0sSUFBSSxXQUFXO0NBQ3RDO0FBQ0o7QUFDQSxTQUFTLGFBQWEsTUFBTSxhQUFhOztDQUVyQyxRQUFRLEtBQUssTUFBYjtFQUNJLEtBQUs7R0FDRCxjQUFjLEtBQUssT0FBTyxXQUFXO0dBQ3JDLFlBQVk7SUFBTzs7R0FBbUM7R0FDdEQ7RUFDSixLQUFLO0dBQ0QsY0FBYyxLQUFLLE9BQU8sV0FBVztHQUNyQztFQUNKLEtBQUssR0FBMEI7R0FDM0IsTUFBTSxTQUFTO0dBQ2YsYUFBYSxPQUFPLEtBQUssV0FBVztHQUNwQyxZQUFZO0lBQU87O0dBQW1DO0dBQ3RELFlBQVk7SUFBTzs7R0FBK0I7R0FDbEQ7RUFDSjtFQUNBLEtBQUs7R0FDRCxZQUFZO0lBQU87O0dBQTZDO0dBQ2hFLFlBQVk7SUFBTzs7R0FBK0I7R0FDbEQ7RUFDSixLQUFLO0dBQ0QsWUFBWTtJQUFPOztHQUE2QztHQUNoRSxZQUFZO0lBQU87O0dBQWlDO0dBQ3BEO0NBQ1I7O0FBRUo7O0FBRUEsU0FBUyxVQUFVLEtBQUssVUFBVSxDQUFDLEdBQ2pDO0NBQ0UsTUFBTSxjQUFjLGtCQUFrQixHQUFHO0NBQ3pDLFlBQVk7RUFBTzs7Q0FBeUM7O0NBRTVELElBQUksUUFBUSxhQUFhLElBQUksTUFBTSxXQUFXOztDQUU5QyxNQUFNLFVBQVUsWUFBWSxRQUFRO0NBQ3BDLElBQUksVUFBVSxNQUFNLEtBQUssUUFBUSxPQUFPO0FBQzVDO0FBRUEsU0FBUyxTQUFTLEtBQUs7Q0FDbkIsTUFBTSxPQUFPLElBQUk7Q0FDakIsSUFBSSxLQUFLLFNBQVMsR0FBMkI7RUFDekMsb0JBQW9CLElBQUk7Q0FDNUIsT0FDSztFQUNELEtBQUssTUFBTSxTQUFRLE1BQUssb0JBQW9CLENBQUMsQ0FBQztDQUNsRDtDQUNBLE9BQU87QUFDWDtBQUNBLFNBQVMsb0JBQW9CLFNBQVM7Q0FDbEMsSUFBSSxRQUFRLE1BQU0sV0FBVyxHQUFHO0VBQzVCLE1BQU0sT0FBTyxRQUFRLE1BQU07RUFDM0IsSUFBSSxLQUFLLFNBQVMsS0FBMEIsS0FBSyxTQUFTLEdBQTJCO0dBQ2pGLFFBQVEsU0FBUyxLQUFLO0dBQ3RCLE9BQU8sS0FBSztFQUNoQjtDQUNKLE9BQ0s7RUFDRCxNQUFNLFNBQVMsQ0FBQztFQUNoQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxNQUFNLFFBQVEsS0FBSztHQUMzQyxNQUFNLE9BQU8sUUFBUSxNQUFNO0dBQzNCLElBQUksRUFBRSxLQUFLLFNBQVMsS0FBMEIsS0FBSyxTQUFTLElBQTRCO0lBQ3BGO0dBQ0o7R0FDQSxJQUFJLEtBQUssU0FBUyxNQUFNO0lBQ3BCO0dBQ0o7R0FDQSxPQUFPLEtBQUssS0FBSyxLQUFLO0VBQzFCO0VBQ0EsSUFBSSxPQUFPLFdBQVcsUUFBUSxNQUFNLFFBQVE7R0FDeEMsUUFBUSxTQUFTLEtBQUssTUFBTTtHQUM1QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxNQUFNLFFBQVEsS0FBSztJQUMzQyxNQUFNLE9BQU8sUUFBUSxNQUFNO0lBQzNCLElBQUksS0FBSyxTQUFTLEtBQTBCLEtBQUssU0FBUyxHQUEyQjtLQUNqRixPQUFPLEtBQUs7SUFDaEI7R0FDSjtFQUNKO0NBQ0o7QUFDSjtBQUVBLE1BQU0saUJBQWlCOztBQUV2QixTQUFTLE9BQU8sTUFBTTtDQUNsQixLQUFLLElBQUksS0FBSztDQUNkLFFBQVEsS0FBSyxNQUFiO0VBQ0ksS0FBSyxHQUE0QjtHQUM3QixNQUFNLFdBQVc7R0FDakIsT0FBTyxTQUFTLElBQUk7R0FDcEIsU0FBUyxJQUFJLFNBQVM7R0FDdEIsT0FBTyxTQUFTO0dBQ2hCO0VBQ0o7RUFDQSxLQUFLLEdBQTBCO0dBQzNCLE1BQU0sU0FBUztHQUNmLE1BQU0sUUFBUSxPQUFPO0dBQ3JCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSztJQUNuQyxPQUFPLE1BQU0sRUFBRTtHQUNuQjtHQUNBLE9BQU8sSUFBSTtHQUNYLE9BQU8sT0FBTztHQUNkO0VBQ0o7RUFDQSxLQUFLLEdBQTJCO0dBQzVCLE1BQU0sVUFBVTtHQUNoQixNQUFNLFFBQVEsUUFBUTtHQUN0QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksTUFBTSxRQUFRLEtBQUs7SUFDbkMsT0FBTyxNQUFNLEVBQUU7R0FDbkI7R0FDQSxRQUFRLElBQUk7R0FDWixPQUFPLFFBQVE7R0FDZixJQUFJLFFBQVEsUUFBUTtJQUNoQixRQUFRLElBQUksUUFBUTtJQUNwQixPQUFPLFFBQVE7R0FDbkI7R0FDQTtFQUNKO0VBQ0EsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSyxHQUE2QjtHQUM5QixNQUFNLFlBQVk7R0FDbEIsSUFBSSxVQUFVLE9BQU87SUFDakIsVUFBVSxJQUFJLFVBQVU7SUFDeEIsT0FBTyxVQUFVO0dBQ3JCO0dBQ0E7RUFDSjtFQUNBLEtBQUssR0FBMEI7R0FDM0IsTUFBTSxTQUFTO0dBQ2YsT0FBTyxPQUFPLEdBQUc7R0FDakIsT0FBTyxJQUFJLE9BQU87R0FDbEIsT0FBTyxPQUFPO0dBQ2QsSUFBSSxPQUFPLFVBQVU7SUFDakIsT0FBTyxPQUFPLFFBQVE7SUFDdEIsT0FBTyxJQUFJLE9BQU87SUFDbEIsT0FBTyxPQUFPO0dBQ2xCO0dBQ0E7RUFDSjtFQUNBLEtBQUssR0FBd0I7R0FDekIsTUFBTSxPQUFPO0dBQ2IsS0FBSyxJQUFJLEtBQUs7R0FDZCxPQUFPLEtBQUs7R0FDWjtFQUNKO0VBQ0EsS0FBSyxHQUF5QjtHQUMxQixNQUFNLFFBQVE7R0FDZCxNQUFNLElBQUksTUFBTTtHQUNoQixPQUFPLE1BQU07R0FDYjtFQUNKO0VBQ0EsU0FDSSxzQkFBOEIsY0FBZTtHQUN6QyxNQUFNLG1CQUFtQixrQkFBa0IsOEJBQThCLE1BQU07SUFDM0UsUUFBUTtJQUNSLE1BQU0sQ0FBQyxLQUFLLElBQUk7R0FDcEIsQ0FBQztFQUNMO0NBQ1I7Q0FDQSxPQUFPLEtBQUs7QUFDaEI7Ozs7QUFLQSxNQUFNLGVBQWU7QUFDckIsU0FBUyxvQkFBb0IsS0FBSyxTQUFTO0NBQ3ZDLE1BQU0sRUFBRSxVQUFVLGVBQWUsWUFBWSxnQkFBZ0I7Q0FDN0QsTUFBTSxXQUFXLFFBQVEsYUFBYTtDQUN0QyxNQUFNLFdBQVc7RUFDYjtFQUNBLE1BQU07RUFDTixRQUFRO0VBQ1IsTUFBTTtFQUNOLFFBQVE7RUFDUixLQUFLO0VBQ0w7RUFDQSxZQUFZO0VBQ1osYUFBYTtDQUNqQjtDQUNBLElBQUksWUFBWSxJQUFJLEtBQUs7RUFDckIsU0FBUyxTQUFTLElBQUksSUFBSTtDQUM5QjtDQUNBLE1BQU0sZ0JBQWdCO0NBQ3RCLFNBQVMsS0FBSyxNQUFNLE1BQU07RUFDdEIsU0FBUyxRQUFRO0NBQ3JCO0NBQ0EsU0FBUyxTQUFTLEdBQUcsZ0JBQWdCLE1BQU07RUFDdkMsTUFBTSxpQkFBaUIsZ0JBQWdCLGdCQUFnQjtFQUN2RCxLQUFLLGNBQWMsaUJBQWlCLEtBQUssT0FBTyxDQUFDLElBQUksY0FBYztDQUN2RTtDQUNBLFNBQVMsT0FBTyxjQUFjLE1BQU07RUFDaEMsTUFBTSxRQUFRLEVBQUUsU0FBUztFQUN6QixlQUFlLFNBQVMsS0FBSztDQUNqQztDQUNBLFNBQVMsU0FBUyxjQUFjLE1BQU07RUFDbEMsTUFBTSxRQUFRLEVBQUUsU0FBUztFQUN6QixlQUFlLFNBQVMsS0FBSztDQUNqQztDQUNBLFNBQVMsVUFBVTtFQUNmLFNBQVMsU0FBUyxXQUFXO0NBQ2pDO0NBQ0EsTUFBTSxVQUFVLFFBQVEsSUFBSTtDQUM1QixNQUFNLG1CQUFtQixTQUFTO0NBQ2xDLE9BQU87RUFDSDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNKO0FBQ0o7QUFDQSxTQUFTLG1CQUFtQixXQUFXLE1BQU07Q0FDekMsTUFBTSxFQUFFLFdBQVc7Q0FDbkIsVUFBVSxLQUFLLEdBQUc7RUFBTzs7Q0FBbUMsRUFBRSxFQUFFO0NBQ2hFLGFBQWEsV0FBVyxLQUFLLEdBQUc7Q0FDaEMsSUFBSSxLQUFLLFVBQVU7RUFDZixVQUFVLEtBQUssSUFBSTtFQUNuQixhQUFhLFdBQVcsS0FBSyxRQUFRO0VBQ3JDLFVBQVUsS0FBSyxTQUFTO0NBQzVCLE9BQ0s7RUFDRCxVQUFVLEtBQUssb0JBQW9CO0NBQ3ZDO0NBQ0EsVUFBVSxLQUFLLEdBQUc7QUFDdEI7QUFDQSxTQUFTLG9CQUFvQixXQUFXLE1BQU07Q0FDMUMsTUFBTSxFQUFFLFFBQVEsZUFBZTtDQUMvQixVQUFVLEtBQUssR0FBRztFQUFPOztDQUF5QyxFQUFFLEdBQUc7Q0FDdkUsVUFBVSxPQUFPLFdBQVcsQ0FBQztDQUM3QixNQUFNLFNBQVMsS0FBSyxNQUFNO0NBQzFCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLEtBQUs7RUFDN0IsYUFBYSxXQUFXLEtBQUssTUFBTSxFQUFFO0VBQ3JDLElBQUksTUFBTSxTQUFTLEdBQUc7R0FDbEI7RUFDSjtFQUNBLFVBQVUsS0FBSyxJQUFJO0NBQ3ZCO0NBQ0EsVUFBVSxTQUFTLFdBQVcsQ0FBQztDQUMvQixVQUFVLEtBQUssSUFBSTtBQUN2QjtBQUNBLFNBQVMsbUJBQW1CLFdBQVcsTUFBTTtDQUN6QyxNQUFNLEVBQUUsUUFBUSxlQUFlO0NBQy9CLElBQUksS0FBSyxNQUFNLFNBQVMsR0FBRztFQUN2QixVQUFVLEtBQUssR0FBRztHQUFPOztFQUFtQyxFQUFFLEdBQUc7RUFDakUsVUFBVSxPQUFPLFdBQVcsQ0FBQztFQUM3QixNQUFNLFNBQVMsS0FBSyxNQUFNO0VBQzFCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLEtBQUs7R0FDN0IsYUFBYSxXQUFXLEtBQUssTUFBTSxFQUFFO0dBQ3JDLElBQUksTUFBTSxTQUFTLEdBQUc7SUFDbEI7R0FDSjtHQUNBLFVBQVUsS0FBSyxJQUFJO0VBQ3ZCO0VBQ0EsVUFBVSxTQUFTLFdBQVcsQ0FBQztFQUMvQixVQUFVLEtBQUssSUFBSTtDQUN2QjtBQUNKO0FBQ0EsU0FBUyxpQkFBaUIsV0FBVyxNQUFNO0NBQ3ZDLElBQUksS0FBSyxNQUFNO0VBQ1gsYUFBYSxXQUFXLEtBQUssSUFBSTtDQUNyQyxPQUNLO0VBQ0QsVUFBVSxLQUFLLE1BQU07Q0FDekI7QUFDSjtBQUNBLFNBQVMsYUFBYSxXQUFXLE1BQU07Q0FDbkMsTUFBTSxFQUFFLFdBQVc7Q0FDbkIsUUFBUSxLQUFLLE1BQWI7RUFDSSxLQUFLO0dBQ0QsaUJBQWlCLFdBQVcsSUFBSTtHQUNoQztFQUNKLEtBQUs7R0FDRCxtQkFBbUIsV0FBVyxJQUFJO0dBQ2xDO0VBQ0osS0FBSztHQUNELG9CQUFvQixXQUFXLElBQUk7R0FDbkM7RUFDSixLQUFLO0dBQ0QsbUJBQW1CLFdBQVcsSUFBSTtHQUNsQztFQUNKLEtBQUs7R0FDRCxVQUFVLEtBQUssS0FBSyxVQUFVLEtBQUssS0FBSyxHQUFHLElBQUk7R0FDL0M7RUFDSixLQUFLO0dBQ0QsVUFBVSxLQUFLLEtBQUssVUFBVSxLQUFLLEtBQUssR0FBRyxJQUFJO0dBQy9DO0VBQ0osS0FBSztHQUNELFVBQVUsS0FBSyxHQUFHO0lBQU87O0dBQTZDLEVBQUUsR0FBRztJQUFPOztHQUErQixFQUFFLEdBQUcsS0FBSyxNQUFNLEtBQUssSUFBSTtHQUMxSTtFQUNKLEtBQUs7R0FDRCxVQUFVLEtBQUssR0FBRztJQUFPOztHQUE2QyxFQUFFLEdBQUc7SUFBTzs7R0FBaUMsRUFBRSxHQUFHLEtBQUssVUFBVSxLQUFLLEdBQUcsRUFBRSxLQUFLLElBQUk7R0FDMUo7RUFDSixLQUFLO0dBQ0QsVUFBVSxLQUFLLEtBQUssVUFBVSxLQUFLLEtBQUssR0FBRyxJQUFJO0dBQy9DO0VBQ0osS0FBSztHQUNELFVBQVUsS0FBSyxLQUFLLFVBQVUsS0FBSyxLQUFLLEdBQUcsSUFBSTtHQUMvQztFQUNKLFNBQ0ksc0JBQThCLGNBQWU7R0FDekMsTUFBTSxtQkFBbUIsa0JBQWtCLDZCQUE2QixNQUFNO0lBQzFFLFFBQVE7SUFDUixNQUFNLENBQUMsS0FBSyxJQUFJO0dBQ3BCLENBQUM7RUFDTDtDQUNSO0FBQ0o7O0FBRUEsTUFBTSxZQUFZLEtBQUssVUFBVSxDQUFDLE1BQU07Q0FDcEMsTUFBTSxPQUFPLFNBQVMsUUFBUSxJQUFJLElBQUksUUFBUSxPQUFPO0NBQ3JELE1BQU0sV0FBVyxTQUFTLFFBQVEsUUFBUSxJQUNwQyxRQUFRLFdBQ1I7Q0FDTixDQUFDLENBQUMsUUFBUTs7Q0FFVixNQUFNLGdCQUFnQixRQUFRLGlCQUFpQixPQUN6QyxRQUFRLGdCQUNSLFNBQVMsVUFDTCxNQUNBO0NBQ1YsTUFBTSxhQUFhLFFBQVEsYUFBYSxRQUFRLGFBQWEsU0FBUztDQUN0RSxNQUFNLFVBQVUsSUFBSSxXQUFXLENBQUM7Q0FDaEMsTUFBTSxZQUFZLG9CQUFvQixLQUFLO0VBQ3ZDO0VBQ0E7RUFDQTtDQUNKLENBQUM7Q0FDRCxVQUFVLEtBQUssU0FBUyxXQUFXLDZCQUE2QixZQUFZO0NBQzVFLFVBQVUsT0FBTyxVQUFVO0NBQzNCLElBQUksUUFBUSxTQUFTLEdBQUc7RUFDcEIsVUFBVSxLQUFLLFdBQVcsS0FBSyxRQUFRLEtBQUksTUFBSyxHQUFHLEVBQUUsS0FBSyxHQUFHLEdBQUcsSUFBSSxFQUFFLFNBQVM7RUFDL0UsVUFBVSxRQUFRO0NBQ3RCO0NBQ0EsVUFBVSxLQUFLLFNBQVM7Q0FDeEIsYUFBYSxXQUFXLEdBQUc7Q0FDM0IsVUFBVSxTQUFTLFVBQVU7Q0FDN0IsVUFBVSxLQUFLLEdBQUc7Q0FDbEIsT0FBTyxJQUFJO0NBQ1gsTUFBTSxFQUFFLE1BQU0sUUFBUSxVQUFVLFFBQVE7Q0FDeEMsT0FBTztFQUNIO0VBQ0E7RUFDQSxLQUFLLE1BQU0sSUFBSSxPQUFPLElBQUk7Q0FDOUI7QUFDSjtBQUVBLFNBQVMsWUFBWSxRQUFRLFVBQVUsQ0FBQyxHQUFHO0NBQ3ZDLE1BQU0sa0JBQWtCLE9BQU8sQ0FBQyxHQUFHLE9BQU87Q0FDMUMsTUFBTSxNQUFNLENBQUMsQ0FBQyxnQkFBZ0I7Q0FDOUIsTUFBTSxlQUFlLENBQUMsQ0FBQyxnQkFBZ0I7Q0FDdkMsTUFBTSxpQkFBaUIsZ0JBQWdCLFlBQVksT0FBTyxPQUFPLGdCQUFnQjs7Q0FFakYsTUFBTSxTQUFTLGFBQWEsZUFBZTtDQUMzQyxNQUFNLE1BQU0sT0FBTyxNQUFNLE1BQU07Q0FDL0IsSUFBSSxDQUFDLEtBQUs7O0VBRU4sVUFBVSxLQUFLLGVBQWU7O0VBRTlCLE9BQU8sU0FBUyxLQUFLLGVBQWU7Q0FDeEMsT0FDSzs7RUFFRCxrQkFBa0IsU0FBUyxHQUFHOztFQUU5QixnQkFBZ0IsT0FBTyxHQUFHOztFQUUxQixPQUFPO0dBQUU7R0FBSyxNQUFNO0VBQUc7Q0FDM0I7QUFDSjtBQUVBLFNBQVMsa0NBQWtDLG1CQUFtQixrQkFBa0IsY0FBYyxlQUFlLGFBQWEsb0JBQW9CLGdCQUFnQixjQUFjLGdCQUFnQixnQkFBZ0IsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJtZXNzYWdlLWNvbXBpbGVyLm1qcz92PTdlNzNhZmMyIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIi8qIVxuICAqIG1lc3NhZ2UtY29tcGlsZXIgdjExLjQuOFxuICAqIChjKSAyMDI2IGthenV5YSBrYXdhZ3VjaGlcbiAgKiBSZWxlYXNlZCB1bmRlciB0aGUgTUlUIExpY2Vuc2UuXG4gICovXG5pbXBvcnQgeyBmb3JtYXQsIGFzc2lnbiwgam9pbiwgaXNTdHJpbmcgfSBmcm9tICdAaW50bGlmeS9zaGFyZWQnO1xuXG5jb25zdCBMT0NBVElPTl9TVFVCID0ge1xuICAgIHN0YXJ0OiB7IGxpbmU6IDEsIGNvbHVtbjogMSwgb2Zmc2V0OiAwIH0sXG4gICAgZW5kOiB7IGxpbmU6IDEsIGNvbHVtbjogMSwgb2Zmc2V0OiAwIH1cbn07XG5mdW5jdGlvbiBjcmVhdGVQb3NpdGlvbihsaW5lLCBjb2x1bW4sIG9mZnNldCkge1xuICAgIHJldHVybiB7IGxpbmUsIGNvbHVtbiwgb2Zmc2V0IH07XG59XG5mdW5jdGlvbiBjcmVhdGVMb2NhdGlvbihzdGFydCwgZW5kLCBzb3VyY2UpIHtcbiAgICBjb25zdCBsb2MgPSB7IHN0YXJ0LCBlbmQgfTtcbiAgICBpZiAoc291cmNlICE9IG51bGwpIHtcbiAgICAgICAgbG9jLnNvdXJjZSA9IHNvdXJjZTtcbiAgICB9XG4gICAgcmV0dXJuIGxvYztcbn1cblxuY29uc3QgQ29tcGlsZUVycm9yQ29kZXMgPSB7XG4gICAgLy8gdG9rZW5pemVyIGVycm9yIGNvZGVzXG4gICAgRVhQRUNURURfVE9LRU46IDEsXG4gICAgSU5WQUxJRF9UT0tFTl9JTl9QTEFDRUhPTERFUjogMixcbiAgICBVTlRFUk1JTkFURURfU0lOR0xFX1FVT1RFX0lOX1BMQUNFSE9MREVSOiAzLFxuICAgIFVOS05PV05fRVNDQVBFX1NFUVVFTkNFOiA0LFxuICAgIElOVkFMSURfVU5JQ09ERV9FU0NBUEVfU0VRVUVOQ0U6IDUsXG4gICAgVU5CQUxBTkNFRF9DTE9TSU5HX0JSQUNFOiA2LFxuICAgIFVOVEVSTUlOQVRFRF9DTE9TSU5HX0JSQUNFOiA3LFxuICAgIEVNUFRZX1BMQUNFSE9MREVSOiA4LFxuICAgIE5PVF9BTExPV19ORVNUX1BMQUNFSE9MREVSOiA5LFxuICAgIElOVkFMSURfTElOS0VEX0ZPUk1BVDogMTAsXG4gICAgLy8gcGFyc2VyIGVycm9yIGNvZGVzXG4gICAgTVVTVF9IQVZFX01FU1NBR0VTX0lOX1BMVVJBTDogMTEsXG4gICAgVU5FWFBFQ1RFRF9FTVBUWV9MSU5LRURfTU9ESUZJRVI6IDEyLFxuICAgIFVORVhQRUNURURfRU1QVFlfTElOS0VEX0tFWTogMTMsXG4gICAgVU5FWFBFQ1RFRF9MRVhJQ0FMX0FOQUxZU0lTOiAxNCxcbiAgICAvLyBnZW5lcmF0b3IgZXJyb3IgY29kZXNcbiAgICBVTkhBTkRMRURfQ09ERUdFTl9OT0RFX1RZUEU6IDE1LFxuICAgIC8vIG1pbmlmaWVyIGVycm9yIGNvZGVzXG4gICAgVU5IQU5ETEVEX01JTklGSUVSX05PREVfVFlQRTogMTZcbn07XG4vLyBTcGVjaWFsIHZhbHVlIGZvciBoaWdoZXItb3JkZXIgY29tcGlsZXJzIHRvIHBpY2sgdXAgdGhlIGxhc3QgY29kZVxuLy8gdG8gYXZvaWQgY29sbGlzaW9uIG9mIGVycm9yIGNvZGVzLlxuLy8gVGhpcyBzaG91bGQgYWx3YXlzIGJlIGtlcHQgYXMgdGhlIGxhc3QgaXRlbS5cbmNvbnN0IENPTVBJTEVfRVJST1JfQ09ERVNfRVhURU5EX1BPSU5UID0gMTc7XG4vKiogQGludGVybmFsICovXG5jb25zdCBlcnJvck1lc3NhZ2VzID0ge1xuICAgIC8vIHRva2VuaXplciBlcnJvciBtZXNzYWdlc1xuICAgIFtDb21waWxlRXJyb3JDb2Rlcy5FWFBFQ1RFRF9UT0tFTl06IGBFeHBlY3RlZCB0b2tlbjogJ3swfSdgLFxuICAgIFtDb21waWxlRXJyb3JDb2Rlcy5JTlZBTElEX1RPS0VOX0lOX1BMQUNFSE9MREVSXTogYEludmFsaWQgdG9rZW4gaW4gcGxhY2Vob2xkZXI6ICd7MH0nYCxcbiAgICBbQ29tcGlsZUVycm9yQ29kZXMuVU5URVJNSU5BVEVEX1NJTkdMRV9RVU9URV9JTl9QTEFDRUhPTERFUl06IGBVbnRlcm1pbmF0ZWQgc2luZ2xlIHF1b3RlIGluIHBsYWNlaG9sZGVyYCxcbiAgICBbQ29tcGlsZUVycm9yQ29kZXMuVU5LTk9XTl9FU0NBUEVfU0VRVUVOQ0VdOiBgVW5rbm93biBlc2NhcGUgc2VxdWVuY2U6IFxcXFx7MH1gLFxuICAgIFtDb21waWxlRXJyb3JDb2Rlcy5JTlZBTElEX1VOSUNPREVfRVNDQVBFX1NFUVVFTkNFXTogYEludmFsaWQgdW5pY29kZSBlc2NhcGUgc2VxdWVuY2U6IHswfWAsXG4gICAgW0NvbXBpbGVFcnJvckNvZGVzLlVOQkFMQU5DRURfQ0xPU0lOR19CUkFDRV06IGBVbmJhbGFuY2VkIGNsb3NpbmcgYnJhY2VgLFxuICAgIFtDb21waWxlRXJyb3JDb2Rlcy5VTlRFUk1JTkFURURfQ0xPU0lOR19CUkFDRV06IGBVbnRlcm1pbmF0ZWQgY2xvc2luZyBicmFjZWAsXG4gICAgW0NvbXBpbGVFcnJvckNvZGVzLkVNUFRZX1BMQUNFSE9MREVSXTogYEVtcHR5IHBsYWNlaG9sZGVyYCxcbiAgICBbQ29tcGlsZUVycm9yQ29kZXMuTk9UX0FMTE9XX05FU1RfUExBQ0VIT0xERVJdOiBgTm90IGFsbG93ZWQgbmVzdCBwbGFjZWhvbGRlcmAsXG4gICAgW0NvbXBpbGVFcnJvckNvZGVzLklOVkFMSURfTElOS0VEX0ZPUk1BVF06IGBJbnZhbGlkIGxpbmtlZCBmb3JtYXRgLFxuICAgIC8vIHBhcnNlciBlcnJvciBtZXNzYWdlc1xuICAgIFtDb21waWxlRXJyb3JDb2Rlcy5NVVNUX0hBVkVfTUVTU0FHRVNfSU5fUExVUkFMXTogYFBsdXJhbCBtdXN0IGhhdmUgbWVzc2FnZXNgLFxuICAgIFtDb21waWxlRXJyb3JDb2Rlcy5VTkVYUEVDVEVEX0VNUFRZX0xJTktFRF9NT0RJRklFUl06IGBVbmV4cGVjdGVkIGVtcHR5IGxpbmtlZCBtb2RpZmllcmAsXG4gICAgW0NvbXBpbGVFcnJvckNvZGVzLlVORVhQRUNURURfRU1QVFlfTElOS0VEX0tFWV06IGBVbmV4cGVjdGVkIGVtcHR5IGxpbmtlZCBrZXlgLFxuICAgIFtDb21waWxlRXJyb3JDb2Rlcy5VTkVYUEVDVEVEX0xFWElDQUxfQU5BTFlTSVNdOiBgVW5leHBlY3RlZCBsZXhpY2FsIGFuYWx5c2lzIGluIHRva2VuOiAnezB9J2AsXG4gICAgLy8gZ2VuZXJhdG9yIGVycm9yIG1lc3NhZ2VzXG4gICAgW0NvbXBpbGVFcnJvckNvZGVzLlVOSEFORExFRF9DT0RFR0VOX05PREVfVFlQRV06IGB1bmhhbmRsZWQgY29kZWdlbiBub2RlIHR5cGU6ICd7MH0nYCxcbiAgICAvLyBtaW5pbWl6ZXIgZXJyb3IgbWVzc2FnZXNcbiAgICBbQ29tcGlsZUVycm9yQ29kZXMuVU5IQU5ETEVEX01JTklGSUVSX05PREVfVFlQRV06IGB1bmhhbmRsZWQgbWltaWZpZXIgbm9kZSB0eXBlOiAnezB9J2Bcbn07XG5mdW5jdGlvbiBjcmVhdGVDb21waWxlRXJyb3IoY29kZSwgbG9jLCBvcHRpb25zID0ge30pIHtcbiAgICBjb25zdCB7IGRvbWFpbiwgbWVzc2FnZXMsIGFyZ3MgfSA9IG9wdGlvbnM7XG4gICAgY29uc3QgbXNnID0gKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpXG4gICAgICAgID8gZm9ybWF0KChtZXNzYWdlcyB8fCBlcnJvck1lc3NhZ2VzKVtjb2RlXSB8fCAnJywgLi4uKGFyZ3MgfHwgW10pKVxuICAgICAgICA6IGNvZGU7XG4gICAgY29uc3QgZXJyb3IgPSBuZXcgU3ludGF4RXJyb3IoU3RyaW5nKG1zZykpO1xuICAgIGVycm9yLmNvZGUgPSBjb2RlO1xuICAgIGlmIChsb2MpIHtcbiAgICAgICAgZXJyb3IubG9jYXRpb24gPSBsb2M7XG4gICAgfVxuICAgIGVycm9yLmRvbWFpbiA9IGRvbWFpbjtcbiAgICByZXR1cm4gZXJyb3I7XG59XG4vKiogQGludGVybmFsICovXG5mdW5jdGlvbiBkZWZhdWx0T25FcnJvcihlcnJvcikge1xuICAgIHRocm93IGVycm9yO1xufVxuXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdXNlbGVzcy1lc2NhcGVcbmNvbnN0IFJFX0hUTUxfVEFHID0gLzxcXC8/W1xcd1xccz1cIi8uJzo7Iy1cXC9dKz4vO1xuY29uc3QgZGV0ZWN0SHRtbFRhZyA9IChzb3VyY2UpID0+IFJFX0hUTUxfVEFHLnRlc3Qoc291cmNlKTtcblxuY29uc3QgQ0hBUl9TUCA9ICcgJztcbmNvbnN0IENIQVJfQ1IgPSAnXFxyJztcbmNvbnN0IENIQVJfTEYgPSAnXFxuJztcbmNvbnN0IENIQVJfTFMgPSBTdHJpbmcuZnJvbUNoYXJDb2RlKDB4MjAyOCk7XG5jb25zdCBDSEFSX1BTID0gU3RyaW5nLmZyb21DaGFyQ29kZSgweDIwMjkpO1xuZnVuY3Rpb24gY3JlYXRlU2Nhbm5lcihzdHIpIHtcbiAgICBjb25zdCBfYnVmID0gc3RyO1xuICAgIGxldCBfaW5kZXggPSAwO1xuICAgIGxldCBfbGluZSA9IDE7XG4gICAgbGV0IF9jb2x1bW4gPSAxO1xuICAgIGxldCBfcGVla09mZnNldCA9IDA7XG4gICAgY29uc3QgaXNDUkxGID0gKGluZGV4KSA9PiBfYnVmW2luZGV4XSA9PT0gQ0hBUl9DUiAmJiBfYnVmW2luZGV4ICsgMV0gPT09IENIQVJfTEY7XG4gICAgY29uc3QgaXNMRiA9IChpbmRleCkgPT4gX2J1ZltpbmRleF0gPT09IENIQVJfTEY7XG4gICAgY29uc3QgaXNQUyA9IChpbmRleCkgPT4gX2J1ZltpbmRleF0gPT09IENIQVJfUFM7XG4gICAgY29uc3QgaXNMUyA9IChpbmRleCkgPT4gX2J1ZltpbmRleF0gPT09IENIQVJfTFM7XG4gICAgY29uc3QgaXNMaW5lRW5kID0gKGluZGV4KSA9PiBpc0NSTEYoaW5kZXgpIHx8IGlzTEYoaW5kZXgpIHx8IGlzUFMoaW5kZXgpIHx8IGlzTFMoaW5kZXgpO1xuICAgIGNvbnN0IGluZGV4ID0gKCkgPT4gX2luZGV4O1xuICAgIGNvbnN0IGxpbmUgPSAoKSA9PiBfbGluZTtcbiAgICBjb25zdCBjb2x1bW4gPSAoKSA9PiBfY29sdW1uO1xuICAgIGNvbnN0IHBlZWtPZmZzZXQgPSAoKSA9PiBfcGVla09mZnNldDtcbiAgICBjb25zdCBjaGFyQXQgPSAob2Zmc2V0KSA9PiBpc0NSTEYob2Zmc2V0KSB8fCBpc1BTKG9mZnNldCkgfHwgaXNMUyhvZmZzZXQpID8gQ0hBUl9MRiA6IF9idWZbb2Zmc2V0XTtcbiAgICBjb25zdCBjdXJyZW50Q2hhciA9ICgpID0+IGNoYXJBdChfaW5kZXgpO1xuICAgIGNvbnN0IGN1cnJlbnRQZWVrID0gKCkgPT4gY2hhckF0KF9pbmRleCArIF9wZWVrT2Zmc2V0KTtcbiAgICBmdW5jdGlvbiBuZXh0KCkge1xuICAgICAgICBfcGVla09mZnNldCA9IDA7XG4gICAgICAgIGlmIChpc0xpbmVFbmQoX2luZGV4KSkge1xuICAgICAgICAgICAgX2xpbmUrKztcbiAgICAgICAgICAgIF9jb2x1bW4gPSAwO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0NSTEYoX2luZGV4KSkge1xuICAgICAgICAgICAgX2luZGV4Kys7XG4gICAgICAgIH1cbiAgICAgICAgX2luZGV4Kys7XG4gICAgICAgIF9jb2x1bW4rKztcbiAgICAgICAgcmV0dXJuIF9idWZbX2luZGV4XTtcbiAgICB9XG4gICAgZnVuY3Rpb24gcGVlaygpIHtcbiAgICAgICAgaWYgKGlzQ1JMRihfaW5kZXggKyBfcGVla09mZnNldCkpIHtcbiAgICAgICAgICAgIF9wZWVrT2Zmc2V0Kys7XG4gICAgICAgIH1cbiAgICAgICAgX3BlZWtPZmZzZXQrKztcbiAgICAgICAgcmV0dXJuIF9idWZbX2luZGV4ICsgX3BlZWtPZmZzZXRdO1xuICAgIH1cbiAgICBmdW5jdGlvbiByZXNldCgpIHtcbiAgICAgICAgX2luZGV4ID0gMDtcbiAgICAgICAgX2xpbmUgPSAxO1xuICAgICAgICBfY29sdW1uID0gMTtcbiAgICAgICAgX3BlZWtPZmZzZXQgPSAwO1xuICAgIH1cbiAgICBmdW5jdGlvbiByZXNldFBlZWsob2Zmc2V0ID0gMCkge1xuICAgICAgICBfcGVla09mZnNldCA9IG9mZnNldDtcbiAgICB9XG4gICAgZnVuY3Rpb24gc2tpcFRvUGVlaygpIHtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gX2luZGV4ICsgX3BlZWtPZmZzZXQ7XG4gICAgICAgIHdoaWxlICh0YXJnZXQgIT09IF9pbmRleCkge1xuICAgICAgICAgICAgbmV4dCgpO1xuICAgICAgICB9XG4gICAgICAgIF9wZWVrT2Zmc2V0ID0gMDtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgaW5kZXgsXG4gICAgICAgIGxpbmUsXG4gICAgICAgIGNvbHVtbixcbiAgICAgICAgcGVla09mZnNldCxcbiAgICAgICAgY2hhckF0LFxuICAgICAgICBjdXJyZW50Q2hhcixcbiAgICAgICAgY3VycmVudFBlZWssXG4gICAgICAgIG5leHQsXG4gICAgICAgIHBlZWssXG4gICAgICAgIHJlc2V0LFxuICAgICAgICByZXNldFBlZWssXG4gICAgICAgIHNraXBUb1BlZWtcbiAgICB9O1xufVxuXG5jb25zdCBFT0YgPSB1bmRlZmluZWQ7XG5jb25zdCBET1QgPSAnLic7XG5jb25zdCBMSVRFUkFMX0RFTElNSVRFUiA9IFwiJ1wiO1xuY29uc3QgRVJST1JfRE9NQUlOJDMgPSAndG9rZW5pemVyJztcbmZ1bmN0aW9uIGNyZWF0ZVRva2VuaXplcihzb3VyY2UsIG9wdGlvbnMgPSB7fSkge1xuICAgIGNvbnN0IGxvY2F0aW9uID0gb3B0aW9ucy5sb2NhdGlvbiAhPT0gZmFsc2U7XG4gICAgY29uc3QgX3NjbnIgPSBjcmVhdGVTY2FubmVyKHNvdXJjZSk7XG4gICAgY29uc3QgY3VycmVudE9mZnNldCA9ICgpID0+IF9zY25yLmluZGV4KCk7XG4gICAgY29uc3QgY3VycmVudFBvc2l0aW9uID0gKCkgPT4gY3JlYXRlUG9zaXRpb24oX3NjbnIubGluZSgpLCBfc2Nuci5jb2x1bW4oKSwgX3NjbnIuaW5kZXgoKSk7XG4gICAgY29uc3QgX2luaXRMb2MgPSBjdXJyZW50UG9zaXRpb24oKTtcbiAgICBjb25zdCBfaW5pdE9mZnNldCA9IGN1cnJlbnRPZmZzZXQoKTtcbiAgICBjb25zdCBfY29udGV4dCA9IHtcbiAgICAgICAgY3VycmVudFR5cGU6IDEzIC8qIFRva2VuVHlwZXMuRU9GICovLFxuICAgICAgICBvZmZzZXQ6IF9pbml0T2Zmc2V0LFxuICAgICAgICBzdGFydExvYzogX2luaXRMb2MsXG4gICAgICAgIGVuZExvYzogX2luaXRMb2MsXG4gICAgICAgIGxhc3RUeXBlOiAxMyAvKiBUb2tlblR5cGVzLkVPRiAqLyxcbiAgICAgICAgbGFzdE9mZnNldDogX2luaXRPZmZzZXQsXG4gICAgICAgIGxhc3RTdGFydExvYzogX2luaXRMb2MsXG4gICAgICAgIGxhc3RFbmRMb2M6IF9pbml0TG9jLFxuICAgICAgICBicmFjZU5lc3Q6IDAsXG4gICAgICAgIGluTGlua2VkOiBmYWxzZSxcbiAgICAgICAgdGV4dDogJydcbiAgICB9O1xuICAgIGNvbnN0IGNvbnRleHQgPSAoKSA9PiBfY29udGV4dDtcbiAgICBjb25zdCB7IG9uRXJyb3IgfSA9IG9wdGlvbnM7XG4gICAgZnVuY3Rpb24gZW1pdEVycm9yKGNvZGUsIHBvcywgb2Zmc2V0LCAuLi5hcmdzKSB7XG4gICAgICAgIGNvbnN0IGN0eCA9IGNvbnRleHQoKTtcbiAgICAgICAgcG9zLmNvbHVtbiArPSBvZmZzZXQ7XG4gICAgICAgIHBvcy5vZmZzZXQgKz0gb2Zmc2V0O1xuICAgICAgICBpZiAob25FcnJvcikge1xuICAgICAgICAgICAgY29uc3QgbG9jID0gbG9jYXRpb24gPyBjcmVhdGVMb2NhdGlvbihjdHguc3RhcnRMb2MsIHBvcykgOiBudWxsO1xuICAgICAgICAgICAgY29uc3QgZXJyID0gY3JlYXRlQ29tcGlsZUVycm9yKGNvZGUsIGxvYywge1xuICAgICAgICAgICAgICAgIGRvbWFpbjogRVJST1JfRE9NQUlOJDMsXG4gICAgICAgICAgICAgICAgYXJnc1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBvbkVycm9yKGVycik7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0VG9rZW4oY29udGV4dCwgdHlwZSwgdmFsdWUpIHtcbiAgICAgICAgY29udGV4dC5lbmRMb2MgPSBjdXJyZW50UG9zaXRpb24oKTtcbiAgICAgICAgY29udGV4dC5jdXJyZW50VHlwZSA9IHR5cGU7XG4gICAgICAgIGNvbnN0IHRva2VuID0geyB0eXBlIH07XG4gICAgICAgIGlmIChsb2NhdGlvbikge1xuICAgICAgICAgICAgdG9rZW4ubG9jID0gY3JlYXRlTG9jYXRpb24oY29udGV4dC5zdGFydExvYywgY29udGV4dC5lbmRMb2MpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh2YWx1ZSAhPSBudWxsKSB7XG4gICAgICAgICAgICB0b2tlbi52YWx1ZSA9IHZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0b2tlbjtcbiAgICB9XG4gICAgY29uc3QgZ2V0RW5kVG9rZW4gPSAoY29udGV4dCkgPT4gZ2V0VG9rZW4oY29udGV4dCwgMTMgLyogVG9rZW5UeXBlcy5FT0YgKi8pO1xuICAgIGZ1bmN0aW9uIGVhdChzY25yLCBjaCkge1xuICAgICAgICBpZiAoc2Nuci5jdXJyZW50Q2hhcigpID09PSBjaCkge1xuICAgICAgICAgICAgc2Nuci5uZXh0KCk7XG4gICAgICAgICAgICByZXR1cm4gY2g7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBlbWl0RXJyb3IoQ29tcGlsZUVycm9yQ29kZXMuRVhQRUNURURfVE9LRU4sIGN1cnJlbnRQb3NpdGlvbigpLCAwLCBjaCk7XG4gICAgICAgICAgICByZXR1cm4gJyc7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gcGVla1NwYWNlcyhzY25yKSB7XG4gICAgICAgIGxldCBidWYgPSAnJztcbiAgICAgICAgd2hpbGUgKHNjbnIuY3VycmVudFBlZWsoKSA9PT0gQ0hBUl9TUCB8fCBzY25yLmN1cnJlbnRQZWVrKCkgPT09IENIQVJfTEYpIHtcbiAgICAgICAgICAgIGJ1ZiArPSBzY25yLmN1cnJlbnRQZWVrKCk7XG4gICAgICAgICAgICBzY25yLnBlZWsoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYnVmO1xuICAgIH1cbiAgICBmdW5jdGlvbiBza2lwU3BhY2VzKHNjbnIpIHtcbiAgICAgICAgY29uc3QgYnVmID0gcGVla1NwYWNlcyhzY25yKTtcbiAgICAgICAgc2Nuci5za2lwVG9QZWVrKCk7XG4gICAgICAgIHJldHVybiBidWY7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGlzSWRlbnRpZmllclN0YXJ0KGNoKSB7XG4gICAgICAgIGlmIChjaCA9PT0gRU9GKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY2MgPSBjaC5jaGFyQ29kZUF0KDApO1xuICAgICAgICByZXR1cm4gKChjYyA+PSA5NyAmJiBjYyA8PSAxMjIpIHx8IC8vIGEtelxuICAgICAgICAgICAgKGNjID49IDY1ICYmIGNjIDw9IDkwKSB8fCAvLyBBLVpcbiAgICAgICAgICAgIGNjID09PSA5NSAvLyBfXG4gICAgICAgICk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGlzTnVtYmVyU3RhcnQoY2gpIHtcbiAgICAgICAgaWYgKGNoID09PSBFT0YpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjYyA9IGNoLmNoYXJDb2RlQXQoMCk7XG4gICAgICAgIHJldHVybiBjYyA+PSA0OCAmJiBjYyA8PSA1NzsgLy8gMC05XG4gICAgfVxuICAgIGZ1bmN0aW9uIGlzTmFtZWRJZGVudGlmaWVyU3RhcnQoc2NuciwgY29udGV4dCkge1xuICAgICAgICBjb25zdCB7IGN1cnJlbnRUeXBlIH0gPSBjb250ZXh0O1xuICAgICAgICBpZiAoY3VycmVudFR5cGUgIT09IDIgLyogVG9rZW5UeXBlcy5CcmFjZUxlZnQgKi8pIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBwZWVrU3BhY2VzKHNjbnIpO1xuICAgICAgICBjb25zdCByZXQgPSBpc0lkZW50aWZpZXJTdGFydChzY25yLmN1cnJlbnRQZWVrKCkpO1xuICAgICAgICBzY25yLnJlc2V0UGVlaygpO1xuICAgICAgICByZXR1cm4gcmV0O1xuICAgIH1cbiAgICBmdW5jdGlvbiBpc0xpc3RJZGVudGlmaWVyU3RhcnQoc2NuciwgY29udGV4dCkge1xuICAgICAgICBjb25zdCB7IGN1cnJlbnRUeXBlIH0gPSBjb250ZXh0O1xuICAgICAgICBpZiAoY3VycmVudFR5cGUgIT09IDIgLyogVG9rZW5UeXBlcy5CcmFjZUxlZnQgKi8pIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBwZWVrU3BhY2VzKHNjbnIpO1xuICAgICAgICBjb25zdCBjaCA9IHNjbnIuY3VycmVudFBlZWsoKSA9PT0gJy0nID8gc2Nuci5wZWVrKCkgOiBzY25yLmN1cnJlbnRQZWVrKCk7XG4gICAgICAgIGNvbnN0IHJldCA9IGlzTnVtYmVyU3RhcnQoY2gpO1xuICAgICAgICBzY25yLnJlc2V0UGVlaygpO1xuICAgICAgICByZXR1cm4gcmV0O1xuICAgIH1cbiAgICBmdW5jdGlvbiBpc0xpdGVyYWxTdGFydChzY25yLCBjb250ZXh0KSB7XG4gICAgICAgIGNvbnN0IHsgY3VycmVudFR5cGUgfSA9IGNvbnRleHQ7XG4gICAgICAgIGlmIChjdXJyZW50VHlwZSAhPT0gMiAvKiBUb2tlblR5cGVzLkJyYWNlTGVmdCAqLykge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHBlZWtTcGFjZXMoc2Nucik7XG4gICAgICAgIGNvbnN0IHJldCA9IHNjbnIuY3VycmVudFBlZWsoKSA9PT0gTElURVJBTF9ERUxJTUlURVI7XG4gICAgICAgIHNjbnIucmVzZXRQZWVrKCk7XG4gICAgICAgIHJldHVybiByZXQ7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGlzTGlua2VkRG90U3RhcnQoc2NuciwgY29udGV4dCkge1xuICAgICAgICBjb25zdCB7IGN1cnJlbnRUeXBlIH0gPSBjb250ZXh0O1xuICAgICAgICBpZiAoY3VycmVudFR5cGUgIT09IDcgLyogVG9rZW5UeXBlcy5MaW5rZWRBbGlhcyAqLykge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHBlZWtTcGFjZXMoc2Nucik7XG4gICAgICAgIGNvbnN0IHJldCA9IHNjbnIuY3VycmVudFBlZWsoKSA9PT0gXCIuXCIgLyogVG9rZW5DaGFycy5MaW5rZWREb3QgKi87XG4gICAgICAgIHNjbnIucmVzZXRQZWVrKCk7XG4gICAgICAgIHJldHVybiByZXQ7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGlzTGlua2VkTW9kaWZpZXJTdGFydChzY25yLCBjb250ZXh0KSB7XG4gICAgICAgIGNvbnN0IHsgY3VycmVudFR5cGUgfSA9IGNvbnRleHQ7XG4gICAgICAgIGlmIChjdXJyZW50VHlwZSAhPT0gOCAvKiBUb2tlblR5cGVzLkxpbmtlZERvdCAqLykge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHBlZWtTcGFjZXMoc2Nucik7XG4gICAgICAgIGNvbnN0IHJldCA9IGlzSWRlbnRpZmllclN0YXJ0KHNjbnIuY3VycmVudFBlZWsoKSk7XG4gICAgICAgIHNjbnIucmVzZXRQZWVrKCk7XG4gICAgICAgIHJldHVybiByZXQ7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGlzTGlua2VkRGVsaW1pdGVyU3RhcnQoc2NuciwgY29udGV4dCkge1xuICAgICAgICBjb25zdCB7IGN1cnJlbnRUeXBlIH0gPSBjb250ZXh0O1xuICAgICAgICBpZiAoIShjdXJyZW50VHlwZSA9PT0gNyAvKiBUb2tlblR5cGVzLkxpbmtlZEFsaWFzICovIHx8XG4gICAgICAgICAgICBjdXJyZW50VHlwZSA9PT0gMTEgLyogVG9rZW5UeXBlcy5MaW5rZWRNb2RpZmllciAqLykpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBwZWVrU3BhY2VzKHNjbnIpO1xuICAgICAgICBjb25zdCByZXQgPSBzY25yLmN1cnJlbnRQZWVrKCkgPT09IFwiOlwiIC8qIFRva2VuQ2hhcnMuTGlua2VkRGVsaW1pdGVyICovO1xuICAgICAgICBzY25yLnJlc2V0UGVlaygpO1xuICAgICAgICByZXR1cm4gcmV0O1xuICAgIH1cbiAgICBmdW5jdGlvbiBpc0xpbmtlZFJlZmVyU3RhcnQoc2NuciwgY29udGV4dCkge1xuICAgICAgICBjb25zdCB7IGN1cnJlbnRUeXBlIH0gPSBjb250ZXh0O1xuICAgICAgICBpZiAoY3VycmVudFR5cGUgIT09IDkgLyogVG9rZW5UeXBlcy5MaW5rZWREZWxpbWl0ZXIgKi8pIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBmbiA9ICgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGNoID0gc2Nuci5jdXJyZW50UGVlaygpO1xuICAgICAgICAgICAgaWYgKGNoID09PSBcIntcIiAvKiBUb2tlbkNoYXJzLkJyYWNlTGVmdCAqLykge1xuICAgICAgICAgICAgICAgIHJldHVybiBpc0lkZW50aWZpZXJTdGFydChzY25yLnBlZWsoKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChjaCA9PT0gXCJAXCIgLyogVG9rZW5DaGFycy5MaW5rZWRBbGlhcyAqLyB8fFxuICAgICAgICAgICAgICAgIGNoID09PSBcInxcIiAvKiBUb2tlbkNoYXJzLlBpcGUgKi8gfHxcbiAgICAgICAgICAgICAgICBjaCA9PT0gXCI6XCIgLyogVG9rZW5DaGFycy5MaW5rZWREZWxpbWl0ZXIgKi8gfHxcbiAgICAgICAgICAgICAgICBjaCA9PT0gXCIuXCIgLyogVG9rZW5DaGFycy5MaW5rZWREb3QgKi8gfHxcbiAgICAgICAgICAgICAgICBjaCA9PT0gQ0hBUl9TUCB8fFxuICAgICAgICAgICAgICAgICFjaCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGNoID09PSBDSEFSX0xGKSB7XG4gICAgICAgICAgICAgICAgc2Nuci5wZWVrKCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZuKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBvdGhlciBjaGFyYWN0ZXJzXG4gICAgICAgICAgICAgICAgcmV0dXJuIGlzVGV4dFN0YXJ0KHNjbnIsIGZhbHNlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgcmV0ID0gZm4oKTtcbiAgICAgICAgc2Nuci5yZXNldFBlZWsoKTtcbiAgICAgICAgcmV0dXJuIHJldDtcbiAgICB9XG4gICAgZnVuY3Rpb24gaXNQbHVyYWxTdGFydChzY25yKSB7XG4gICAgICAgIHBlZWtTcGFjZXMoc2Nucik7XG4gICAgICAgIGNvbnN0IHJldCA9IHNjbnIuY3VycmVudFBlZWsoKSA9PT0gXCJ8XCIgLyogVG9rZW5DaGFycy5QaXBlICovO1xuICAgICAgICBzY25yLnJlc2V0UGVlaygpO1xuICAgICAgICByZXR1cm4gcmV0O1xuICAgIH1cbiAgICBmdW5jdGlvbiBpc1RleHRTdGFydChzY25yLCByZXNldCA9IHRydWUpIHtcbiAgICAgICAgY29uc3QgZm4gPSAoaGFzU3BhY2UgPSBmYWxzZSwgcHJldiA9ICcnKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBjaCA9IHNjbnIuY3VycmVudFBlZWsoKTtcbiAgICAgICAgICAgIGlmIChjaCA9PT0gXCJ7XCIgLyogVG9rZW5DaGFycy5CcmFjZUxlZnQgKi8pIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gaGFzU3BhY2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChjaCA9PT0gXCJAXCIgLyogVG9rZW5DaGFycy5MaW5rZWRBbGlhcyAqLyB8fCAhY2gpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gaGFzU3BhY2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChjaCA9PT0gXCJ8XCIgLyogVG9rZW5DaGFycy5QaXBlICovKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuICEocHJldiA9PT0gQ0hBUl9TUCB8fCBwcmV2ID09PSBDSEFSX0xGKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGNoID09PSBDSEFSX1NQKSB7XG4gICAgICAgICAgICAgICAgc2Nuci5wZWVrKCk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZuKHRydWUsIENIQVJfU1ApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoY2ggPT09IENIQVJfTEYpIHtcbiAgICAgICAgICAgICAgICBzY25yLnBlZWsoKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZm4odHJ1ZSwgQ0hBUl9MRik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgcmV0ID0gZm4oKTtcbiAgICAgICAgcmVzZXQgJiYgc2Nuci5yZXNldFBlZWsoKTtcbiAgICAgICAgcmV0dXJuIHJldDtcbiAgICB9XG4gICAgZnVuY3Rpb24gdGFrZUNoYXIoc2NuciwgZm4pIHtcbiAgICAgICAgY29uc3QgY2ggPSBzY25yLmN1cnJlbnRDaGFyKCk7XG4gICAgICAgIGlmIChjaCA9PT0gRU9GKSB7XG4gICAgICAgICAgICByZXR1cm4gRU9GO1xuICAgICAgICB9XG4gICAgICAgIGlmIChmbihjaCkpIHtcbiAgICAgICAgICAgIHNjbnIubmV4dCgpO1xuICAgICAgICAgICAgcmV0dXJuIGNoO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBmdW5jdGlvbiBpc0lkZW50aWZpZXIoY2gpIHtcbiAgICAgICAgY29uc3QgY2MgPSBjaC5jaGFyQ29kZUF0KDApO1xuICAgICAgICByZXR1cm4gKChjYyA+PSA5NyAmJiBjYyA8PSAxMjIpIHx8IC8vIGEtelxuICAgICAgICAgICAgKGNjID49IDY1ICYmIGNjIDw9IDkwKSB8fCAvLyBBLVpcbiAgICAgICAgICAgIChjYyA+PSA0OCAmJiBjYyA8PSA1NykgfHwgLy8gMC05XG4gICAgICAgICAgICBjYyA9PT0gOTUgfHwgLy8gX1xuICAgICAgICAgICAgY2MgPT09IDM2IC8vICRcbiAgICAgICAgKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gdGFrZUlkZW50aWZpZXJDaGFyKHNjbnIpIHtcbiAgICAgICAgcmV0dXJuIHRha2VDaGFyKHNjbnIsIGlzSWRlbnRpZmllcik7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGlzTmFtZWRJZGVudGlmaWVyKGNoKSB7XG4gICAgICAgIGNvbnN0IGNjID0gY2guY2hhckNvZGVBdCgwKTtcbiAgICAgICAgcmV0dXJuICgoY2MgPj0gOTcgJiYgY2MgPD0gMTIyKSB8fCAvLyBhLXpcbiAgICAgICAgICAgIChjYyA+PSA2NSAmJiBjYyA8PSA5MCkgfHwgLy8gQS1aXG4gICAgICAgICAgICAoY2MgPj0gNDggJiYgY2MgPD0gNTcpIHx8IC8vIDAtOVxuICAgICAgICAgICAgY2MgPT09IDk1IHx8IC8vIF9cbiAgICAgICAgICAgIGNjID09PSAzNiB8fCAvLyAkXG4gICAgICAgICAgICBjYyA9PT0gNDUgLy8gLVxuICAgICAgICApO1xuICAgIH1cbiAgICBmdW5jdGlvbiB0YWtlTmFtZWRJZGVudGlmaWVyQ2hhcihzY25yKSB7XG4gICAgICAgIHJldHVybiB0YWtlQ2hhcihzY25yLCBpc05hbWVkSWRlbnRpZmllcik7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGlzRGlnaXQoY2gpIHtcbiAgICAgICAgY29uc3QgY2MgPSBjaC5jaGFyQ29kZUF0KDApO1xuICAgICAgICByZXR1cm4gY2MgPj0gNDggJiYgY2MgPD0gNTc7IC8vIDAtOVxuICAgIH1cbiAgICBmdW5jdGlvbiB0YWtlRGlnaXQoc2Nucikge1xuICAgICAgICByZXR1cm4gdGFrZUNoYXIoc2NuciwgaXNEaWdpdCk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGlzSGV4RGlnaXQoY2gpIHtcbiAgICAgICAgY29uc3QgY2MgPSBjaC5jaGFyQ29kZUF0KDApO1xuICAgICAgICByZXR1cm4gKChjYyA+PSA0OCAmJiBjYyA8PSA1NykgfHwgLy8gMC05XG4gICAgICAgICAgICAoY2MgPj0gNjUgJiYgY2MgPD0gNzApIHx8IC8vIEEtRlxuICAgICAgICAgICAgKGNjID49IDk3ICYmIGNjIDw9IDEwMikpOyAvLyBhLWZcbiAgICB9XG4gICAgZnVuY3Rpb24gdGFrZUhleERpZ2l0KHNjbnIpIHtcbiAgICAgICAgcmV0dXJuIHRha2VDaGFyKHNjbnIsIGlzSGV4RGlnaXQpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBnZXREaWdpdHMoc2Nucikge1xuICAgICAgICBsZXQgY2ggPSAnJztcbiAgICAgICAgbGV0IG51bSA9ICcnO1xuICAgICAgICB3aGlsZSAoKGNoID0gdGFrZURpZ2l0KHNjbnIpKSkge1xuICAgICAgICAgICAgbnVtICs9IGNoO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBudW07XG4gICAgfVxuICAgIGZ1bmN0aW9uIHJlYWRUZXh0KHNjbnIpIHtcbiAgICAgICAgbGV0IGJ1ZiA9ICcnO1xuICAgICAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgICAgICAgY29uc3QgY2ggPSBzY25yLmN1cnJlbnRDaGFyKCk7XG4gICAgICAgICAgICBpZiAoY2ggPT09ICdcXFxcJykge1xuICAgICAgICAgICAgICAgIGNvbnN0IG5leHRDaCA9IHNjbnIucGVlaygpO1xuICAgICAgICAgICAgICAgIGlmIChuZXh0Q2ggPT09IFwie1wiIC8qIFRva2VuQ2hhcnMuQnJhY2VMZWZ0ICovIHx8XG4gICAgICAgICAgICAgICAgICAgIG5leHRDaCA9PT0gXCJ9XCIgLyogVG9rZW5DaGFycy5CcmFjZVJpZ2h0ICovIHx8XG4gICAgICAgICAgICAgICAgICAgIG5leHRDaCA9PT0gXCJAXCIgLyogVG9rZW5DaGFycy5MaW5rZWRBbGlhcyAqLyB8fFxuICAgICAgICAgICAgICAgICAgICBuZXh0Q2ggPT09IFwifFwiIC8qIFRva2VuQ2hhcnMuUGlwZSAqLyB8fFxuICAgICAgICAgICAgICAgICAgICBuZXh0Q2ggPT09ICdcXFxcJykge1xuICAgICAgICAgICAgICAgICAgICBidWYgKz0gY2ggKyBuZXh0Q2g7XG4gICAgICAgICAgICAgICAgICAgIHNjbnIubmV4dCgpO1xuICAgICAgICAgICAgICAgICAgICBzY25yLm5leHQoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHNjbnIucmVzZXRQZWVrKCk7XG4gICAgICAgICAgICAgICAgICAgIGJ1ZiArPSBjaDtcbiAgICAgICAgICAgICAgICAgICAgc2Nuci5uZXh0KCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoY2ggPT09IFwie1wiIC8qIFRva2VuQ2hhcnMuQnJhY2VMZWZ0ICovIHx8XG4gICAgICAgICAgICAgICAgY2ggPT09IFwifVwiIC8qIFRva2VuQ2hhcnMuQnJhY2VSaWdodCAqLyB8fFxuICAgICAgICAgICAgICAgIGNoID09PSBcIkBcIiAvKiBUb2tlbkNoYXJzLkxpbmtlZEFsaWFzICovIHx8XG4gICAgICAgICAgICAgICAgY2ggPT09IFwifFwiIC8qIFRva2VuQ2hhcnMuUGlwZSAqLyB8fFxuICAgICAgICAgICAgICAgICFjaCkge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoY2ggPT09IENIQVJfU1AgfHwgY2ggPT09IENIQVJfTEYpIHtcbiAgICAgICAgICAgICAgICBpZiAoaXNUZXh0U3RhcnQoc2NucikpIHtcbiAgICAgICAgICAgICAgICAgICAgYnVmICs9IGNoO1xuICAgICAgICAgICAgICAgICAgICBzY25yLm5leHQoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoaXNQbHVyYWxTdGFydChzY25yKSkge1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGJ1ZiArPSBjaDtcbiAgICAgICAgICAgICAgICAgICAgc2Nuci5uZXh0KCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgYnVmICs9IGNoO1xuICAgICAgICAgICAgICAgIHNjbnIubmV4dCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBidWY7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHJlYWROYW1lZElkZW50aWZpZXIoc2Nucikge1xuICAgICAgICBza2lwU3BhY2VzKHNjbnIpO1xuICAgICAgICBsZXQgY2ggPSAnJztcbiAgICAgICAgbGV0IG5hbWUgPSAnJztcbiAgICAgICAgd2hpbGUgKChjaCA9IHRha2VOYW1lZElkZW50aWZpZXJDaGFyKHNjbnIpKSkge1xuICAgICAgICAgICAgbmFtZSArPSBjaDtcbiAgICAgICAgfVxuICAgICAgICAvLyBDaGVjayBpZiB0YWtlTmFtZWRJZGVudGlmaWVyQ2hhciBzdG9wZWQgYmVjYXVzZSBvZiBpbnZhbGlkIGNoYXJhY3RlcnNcbiAgICAgICAgY29uc3QgY3VycmVudENoYXIgPSBzY25yLmN1cnJlbnRDaGFyKCk7XG4gICAgICAgIGlmIChjdXJyZW50Q2hhciAmJlxuICAgICAgICAgICAgY3VycmVudENoYXIgIT09ICd9JyAmJlxuICAgICAgICAgICAgY3VycmVudENoYXIgIT09IEVPRiAmJlxuICAgICAgICAgICAgY3VycmVudENoYXIgIT09IENIQVJfU1AgJiZcbiAgICAgICAgICAgIGN1cnJlbnRDaGFyICE9PSBDSEFSX0xGICYmXG4gICAgICAgICAgICBjdXJyZW50Q2hhciAhPT0gJ1xcdTMwMDAnKSB7XG4gICAgICAgICAgICBjb25zdCBpbnZhbGlkUGFydCA9IHJlYWRJbnZhbGlkSWRlbnRpZmllcihzY25yKTtcbiAgICAgICAgICAgIGVtaXRFcnJvcihDb21waWxlRXJyb3JDb2Rlcy5JTlZBTElEX1RPS0VOX0lOX1BMQUNFSE9MREVSLCBjdXJyZW50UG9zaXRpb24oKSwgMCwgbmFtZSArIGludmFsaWRQYXJ0KTtcbiAgICAgICAgICAgIHJldHVybiBuYW1lICsgaW52YWxpZFBhcnQ7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHNjbnIuY3VycmVudENoYXIoKSA9PT0gRU9GKSB7XG4gICAgICAgICAgICBlbWl0RXJyb3IoQ29tcGlsZUVycm9yQ29kZXMuVU5URVJNSU5BVEVEX0NMT1NJTkdfQlJBQ0UsIGN1cnJlbnRQb3NpdGlvbigpLCAwKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmFtZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gcmVhZExpc3RJZGVudGlmaWVyKHNjbnIpIHtcbiAgICAgICAgc2tpcFNwYWNlcyhzY25yKTtcbiAgICAgICAgbGV0IHZhbHVlID0gJyc7XG4gICAgICAgIGlmIChzY25yLmN1cnJlbnRDaGFyKCkgPT09ICctJykge1xuICAgICAgICAgICAgc2Nuci5uZXh0KCk7XG4gICAgICAgICAgICB2YWx1ZSArPSBgLSR7Z2V0RGlnaXRzKHNjbnIpfWA7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB2YWx1ZSArPSBnZXREaWdpdHMoc2Nucik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHNjbnIuY3VycmVudENoYXIoKSA9PT0gRU9GKSB7XG4gICAgICAgICAgICBlbWl0RXJyb3IoQ29tcGlsZUVycm9yQ29kZXMuVU5URVJNSU5BVEVEX0NMT1NJTkdfQlJBQ0UsIGN1cnJlbnRQb3NpdGlvbigpLCAwKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGlzTGl0ZXJhbChjaCkge1xuICAgICAgICByZXR1cm4gY2ggIT09IExJVEVSQUxfREVMSU1JVEVSICYmIGNoICE9PSBDSEFSX0xGO1xuICAgIH1cbiAgICBmdW5jdGlvbiByZWFkTGl0ZXJhbChzY25yKSB7XG4gICAgICAgIHNraXBTcGFjZXMoc2Nucik7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11c2VsZXNzLWVzY2FwZVxuICAgICAgICBlYXQoc2NuciwgYFxcJ2ApO1xuICAgICAgICBsZXQgY2ggPSAnJztcbiAgICAgICAgbGV0IGxpdGVyYWwgPSAnJztcbiAgICAgICAgd2hpbGUgKChjaCA9IHRha2VDaGFyKHNjbnIsIGlzTGl0ZXJhbCkpKSB7XG4gICAgICAgICAgICBpZiAoY2ggPT09ICdcXFxcJykge1xuICAgICAgICAgICAgICAgIGxpdGVyYWwgKz0gcmVhZEVzY2FwZVNlcXVlbmNlKHNjbnIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgbGl0ZXJhbCArPSBjaDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjdXJyZW50ID0gc2Nuci5jdXJyZW50Q2hhcigpO1xuICAgICAgICBpZiAoY3VycmVudCA9PT0gQ0hBUl9MRiB8fCBjdXJyZW50ID09PSBFT0YpIHtcbiAgICAgICAgICAgIGVtaXRFcnJvcihDb21waWxlRXJyb3JDb2Rlcy5VTlRFUk1JTkFURURfU0lOR0xFX1FVT1RFX0lOX1BMQUNFSE9MREVSLCBjdXJyZW50UG9zaXRpb24oKSwgMCk7XG4gICAgICAgICAgICAvLyBUT0RPOiBJcyBpdCBjb3JyZWN0IHJlYWxseT9cbiAgICAgICAgICAgIGlmIChjdXJyZW50ID09PSBDSEFSX0xGKSB7XG4gICAgICAgICAgICAgICAgc2Nuci5uZXh0KCk7XG4gICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVzZWxlc3MtZXNjYXBlXG4gICAgICAgICAgICAgICAgZWF0KHNjbnIsIGBcXCdgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBsaXRlcmFsO1xuICAgICAgICB9XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11c2VsZXNzLWVzY2FwZVxuICAgICAgICBlYXQoc2NuciwgYFxcJ2ApO1xuICAgICAgICByZXR1cm4gbGl0ZXJhbDtcbiAgICB9XG4gICAgZnVuY3Rpb24gcmVhZEVzY2FwZVNlcXVlbmNlKHNjbnIpIHtcbiAgICAgICAgY29uc3QgY2ggPSBzY25yLmN1cnJlbnRDaGFyKCk7XG4gICAgICAgIHN3aXRjaCAoY2gpIHtcbiAgICAgICAgICAgIGNhc2UgJ1xcXFwnOlxuICAgICAgICAgICAgY2FzZSBgXFwnYDogLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby11c2VsZXNzLWVzY2FwZVxuICAgICAgICAgICAgICAgIHNjbnIubmV4dCgpO1xuICAgICAgICAgICAgICAgIHJldHVybiBgXFxcXCR7Y2h9YDtcbiAgICAgICAgICAgIGNhc2UgJ3UnOlxuICAgICAgICAgICAgICAgIHJldHVybiByZWFkVW5pY29kZUVzY2FwZVNlcXVlbmNlKHNjbnIsIGNoLCA0KTtcbiAgICAgICAgICAgIGNhc2UgJ1UnOlxuICAgICAgICAgICAgICAgIHJldHVybiByZWFkVW5pY29kZUVzY2FwZVNlcXVlbmNlKHNjbnIsIGNoLCA2KTtcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgZW1pdEVycm9yKENvbXBpbGVFcnJvckNvZGVzLlVOS05PV05fRVNDQVBFX1NFUVVFTkNFLCBjdXJyZW50UG9zaXRpb24oKSwgMCwgY2gpO1xuICAgICAgICAgICAgICAgIHJldHVybiAnJztcbiAgICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiByZWFkVW5pY29kZUVzY2FwZVNlcXVlbmNlKHNjbnIsIHVuaWNvZGUsIGRpZ2l0cykge1xuICAgICAgICBlYXQoc2NuciwgdW5pY29kZSk7XG4gICAgICAgIGxldCBzZXF1ZW5jZSA9ICcnO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRpZ2l0czsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBjaCA9IHRha2VIZXhEaWdpdChzY25yKTtcbiAgICAgICAgICAgIGlmICghY2gpIHtcbiAgICAgICAgICAgICAgICBlbWl0RXJyb3IoQ29tcGlsZUVycm9yQ29kZXMuSU5WQUxJRF9VTklDT0RFX0VTQ0FQRV9TRVFVRU5DRSwgY3VycmVudFBvc2l0aW9uKCksIDAsIGBcXFxcJHt1bmljb2RlfSR7c2VxdWVuY2V9JHtzY25yLmN1cnJlbnRDaGFyKCl9YCk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzZXF1ZW5jZSArPSBjaDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYFxcXFwke3VuaWNvZGV9JHtzZXF1ZW5jZX1gO1xuICAgIH1cbiAgICBmdW5jdGlvbiBpc0ludmFsaWRJZGVudGlmaWVyKGNoKSB7XG4gICAgICAgIHJldHVybiAoY2ggIT09IFwie1wiIC8qIFRva2VuQ2hhcnMuQnJhY2VMZWZ0ICovICYmXG4gICAgICAgICAgICBjaCAhPT0gXCJ9XCIgLyogVG9rZW5DaGFycy5CcmFjZVJpZ2h0ICovICYmXG4gICAgICAgICAgICBjaCAhPT0gQ0hBUl9TUCAmJlxuICAgICAgICAgICAgY2ggIT09IENIQVJfTEYpO1xuICAgIH1cbiAgICBmdW5jdGlvbiByZWFkSW52YWxpZElkZW50aWZpZXIoc2Nucikge1xuICAgICAgICBza2lwU3BhY2VzKHNjbnIpO1xuICAgICAgICBsZXQgY2ggPSAnJztcbiAgICAgICAgbGV0IGlkZW50aWZpZXJzID0gJyc7XG4gICAgICAgIHdoaWxlICgoY2ggPSB0YWtlQ2hhcihzY25yLCBpc0ludmFsaWRJZGVudGlmaWVyKSkpIHtcbiAgICAgICAgICAgIGlkZW50aWZpZXJzICs9IGNoO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBpZGVudGlmaWVycztcbiAgICB9XG4gICAgZnVuY3Rpb24gcmVhZExpbmtlZE1vZGlmaWVyKHNjbnIpIHtcbiAgICAgICAgbGV0IGNoID0gJyc7XG4gICAgICAgIGxldCBuYW1lID0gJyc7XG4gICAgICAgIHdoaWxlICgoY2ggPSB0YWtlSWRlbnRpZmllckNoYXIoc2NucikpKSB7XG4gICAgICAgICAgICBuYW1lICs9IGNoO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBuYW1lO1xuICAgIH1cbiAgICBmdW5jdGlvbiByZWFkTGlua2VkUmVmZXIoc2Nucikge1xuICAgICAgICBjb25zdCBmbiA9IChidWYpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGNoID0gc2Nuci5jdXJyZW50Q2hhcigpO1xuICAgICAgICAgICAgaWYgKGNoID09PSBcIntcIiAvKiBUb2tlbkNoYXJzLkJyYWNlTGVmdCAqLyB8fFxuICAgICAgICAgICAgICAgIGNoID09PSBcIkBcIiAvKiBUb2tlbkNoYXJzLkxpbmtlZEFsaWFzICovIHx8XG4gICAgICAgICAgICAgICAgY2ggPT09IFwifFwiIC8qIFRva2VuQ2hhcnMuUGlwZSAqLyB8fFxuICAgICAgICAgICAgICAgIGNoID09PSBcIihcIiAvKiBUb2tlbkNoYXJzLlBhcmVuTGVmdCAqLyB8fFxuICAgICAgICAgICAgICAgIGNoID09PSBcIilcIiAvKiBUb2tlbkNoYXJzLlBhcmVuUmlnaHQgKi8gfHxcbiAgICAgICAgICAgICAgICAhY2gpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYnVmO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoY2ggPT09IENIQVJfU1ApIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYnVmO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoY2ggPT09IENIQVJfTEYgfHwgY2ggPT09IERPVCkge1xuICAgICAgICAgICAgICAgIGJ1ZiArPSBjaDtcbiAgICAgICAgICAgICAgICBzY25yLm5leHQoKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZm4oYnVmKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGJ1ZiArPSBjaDtcbiAgICAgICAgICAgICAgICBzY25yLm5leHQoKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZm4oYnVmKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgICAgcmV0dXJuIGZuKCcnKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gcmVhZFBsdXJhbChzY25yKSB7XG4gICAgICAgIHNraXBTcGFjZXMoc2Nucik7XG4gICAgICAgIGNvbnN0IHBsdXJhbCA9IGVhdChzY25yLCBcInxcIiAvKiBUb2tlbkNoYXJzLlBpcGUgKi8pO1xuICAgICAgICBza2lwU3BhY2VzKHNjbnIpO1xuICAgICAgICByZXR1cm4gcGx1cmFsO1xuICAgIH1cbiAgICAvLyBUT0RPOiBXZSBuZWVkIHJlZmFjdG9yaW5nIG9mIHRva2VuIHBhcnNpbmcgLi4uXG4gICAgZnVuY3Rpb24gcmVhZFRva2VuSW5QbGFjZWhvbGRlcihzY25yLCBjb250ZXh0KSB7XG4gICAgICAgIGxldCB0b2tlbiA9IG51bGw7XG4gICAgICAgIGNvbnN0IGNoID0gc2Nuci5jdXJyZW50Q2hhcigpO1xuICAgICAgICBzd2l0Y2ggKGNoKSB7XG4gICAgICAgICAgICBjYXNlIFwie1wiIC8qIFRva2VuQ2hhcnMuQnJhY2VMZWZ0ICovOlxuICAgICAgICAgICAgICAgIGlmIChjb250ZXh0LmJyYWNlTmVzdCA+PSAxKSB7XG4gICAgICAgICAgICAgICAgICAgIGVtaXRFcnJvcihDb21waWxlRXJyb3JDb2Rlcy5OT1RfQUxMT1dfTkVTVF9QTEFDRUhPTERFUiwgY3VycmVudFBvc2l0aW9uKCksIDApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBzY25yLm5leHQoKTtcbiAgICAgICAgICAgICAgICB0b2tlbiA9IGdldFRva2VuKGNvbnRleHQsIDIgLyogVG9rZW5UeXBlcy5CcmFjZUxlZnQgKi8sIFwie1wiIC8qIFRva2VuQ2hhcnMuQnJhY2VMZWZ0ICovKTtcbiAgICAgICAgICAgICAgICBza2lwU3BhY2VzKHNjbnIpO1xuICAgICAgICAgICAgICAgIGNvbnRleHQuYnJhY2VOZXN0Kys7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRva2VuO1xuICAgICAgICAgICAgY2FzZSBcIn1cIiAvKiBUb2tlbkNoYXJzLkJyYWNlUmlnaHQgKi86XG4gICAgICAgICAgICAgICAgaWYgKGNvbnRleHQuYnJhY2VOZXN0ID4gMCAmJlxuICAgICAgICAgICAgICAgICAgICBjb250ZXh0LmN1cnJlbnRUeXBlID09PSAyIC8qIFRva2VuVHlwZXMuQnJhY2VMZWZ0ICovKSB7XG4gICAgICAgICAgICAgICAgICAgIGVtaXRFcnJvcihDb21waWxlRXJyb3JDb2Rlcy5FTVBUWV9QTEFDRUhPTERFUiwgY3VycmVudFBvc2l0aW9uKCksIDApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBzY25yLm5leHQoKTtcbiAgICAgICAgICAgICAgICB0b2tlbiA9IGdldFRva2VuKGNvbnRleHQsIDMgLyogVG9rZW5UeXBlcy5CcmFjZVJpZ2h0ICovLCBcIn1cIiAvKiBUb2tlbkNoYXJzLkJyYWNlUmlnaHQgKi8pO1xuICAgICAgICAgICAgICAgIGNvbnRleHQuYnJhY2VOZXN0LS07XG4gICAgICAgICAgICAgICAgY29udGV4dC5icmFjZU5lc3QgPiAwICYmIHNraXBTcGFjZXMoc2Nucik7XG4gICAgICAgICAgICAgICAgaWYgKGNvbnRleHQuaW5MaW5rZWQgJiYgY29udGV4dC5icmFjZU5lc3QgPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgY29udGV4dC5pbkxpbmtlZCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gdG9rZW47XG4gICAgICAgICAgICBjYXNlIFwiQFwiIC8qIFRva2VuQ2hhcnMuTGlua2VkQWxpYXMgKi86XG4gICAgICAgICAgICAgICAgaWYgKGNvbnRleHQuYnJhY2VOZXN0ID4gMCkge1xuICAgICAgICAgICAgICAgICAgICBlbWl0RXJyb3IoQ29tcGlsZUVycm9yQ29kZXMuVU5URVJNSU5BVEVEX0NMT1NJTkdfQlJBQ0UsIGN1cnJlbnRQb3NpdGlvbigpLCAwKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdG9rZW4gPSByZWFkVG9rZW5JbkxpbmtlZChzY25yLCBjb250ZXh0KSB8fCBnZXRFbmRUb2tlbihjb250ZXh0KTtcbiAgICAgICAgICAgICAgICBjb250ZXh0LmJyYWNlTmVzdCA9IDA7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRva2VuO1xuICAgICAgICAgICAgZGVmYXVsdDoge1xuICAgICAgICAgICAgICAgIGxldCB2YWxpZE5hbWVkSWRlbnRpZmllciA9IHRydWU7XG4gICAgICAgICAgICAgICAgbGV0IHZhbGlkTGlzdElkZW50aWZpZXIgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGxldCB2YWxpZExpdGVyYWwgPSB0cnVlO1xuICAgICAgICAgICAgICAgIGlmIChpc1BsdXJhbFN0YXJ0KHNjbnIpKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjb250ZXh0LmJyYWNlTmVzdCA+IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtaXRFcnJvcihDb21waWxlRXJyb3JDb2Rlcy5VTlRFUk1JTkFURURfQ0xPU0lOR19CUkFDRSwgY3VycmVudFBvc2l0aW9uKCksIDApO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRva2VuID0gZ2V0VG9rZW4oY29udGV4dCwgMSAvKiBUb2tlblR5cGVzLlBpcGUgKi8sIHJlYWRQbHVyYWwoc2NucikpO1xuICAgICAgICAgICAgICAgICAgICAvLyByZXNldFxuICAgICAgICAgICAgICAgICAgICBjb250ZXh0LmJyYWNlTmVzdCA9IDA7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRleHQuaW5MaW5rZWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRva2VuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoY29udGV4dC5icmFjZU5lc3QgPiAwICYmXG4gICAgICAgICAgICAgICAgICAgIChjb250ZXh0LmN1cnJlbnRUeXBlID09PSA0IC8qIFRva2VuVHlwZXMuTmFtZWQgKi8gfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRleHQuY3VycmVudFR5cGUgPT09IDUgLyogVG9rZW5UeXBlcy5MaXN0ICovIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICBjb250ZXh0LmN1cnJlbnRUeXBlID09PSA2IC8qIFRva2VuVHlwZXMuTGl0ZXJhbCAqLykpIHtcbiAgICAgICAgICAgICAgICAgICAgZW1pdEVycm9yKENvbXBpbGVFcnJvckNvZGVzLlVOVEVSTUlOQVRFRF9DTE9TSU5HX0JSQUNFLCBjdXJyZW50UG9zaXRpb24oKSwgMCk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRleHQuYnJhY2VOZXN0ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlYWRUb2tlbihzY25yLCBjb250ZXh0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKCh2YWxpZE5hbWVkSWRlbnRpZmllciA9IGlzTmFtZWRJZGVudGlmaWVyU3RhcnQoc2NuciwgY29udGV4dCkpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRva2VuID0gZ2V0VG9rZW4oY29udGV4dCwgNCAvKiBUb2tlblR5cGVzLk5hbWVkICovLCByZWFkTmFtZWRJZGVudGlmaWVyKHNjbnIpKTtcbiAgICAgICAgICAgICAgICAgICAgc2tpcFNwYWNlcyhzY25yKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRva2VuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoKHZhbGlkTGlzdElkZW50aWZpZXIgPSBpc0xpc3RJZGVudGlmaWVyU3RhcnQoc2NuciwgY29udGV4dCkpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRva2VuID0gZ2V0VG9rZW4oY29udGV4dCwgNSAvKiBUb2tlblR5cGVzLkxpc3QgKi8sIHJlYWRMaXN0SWRlbnRpZmllcihzY25yKSk7XG4gICAgICAgICAgICAgICAgICAgIHNraXBTcGFjZXMoc2Nucik7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0b2tlbjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKCh2YWxpZExpdGVyYWwgPSBpc0xpdGVyYWxTdGFydChzY25yLCBjb250ZXh0KSkpIHtcbiAgICAgICAgICAgICAgICAgICAgdG9rZW4gPSBnZXRUb2tlbihjb250ZXh0LCA2IC8qIFRva2VuVHlwZXMuTGl0ZXJhbCAqLywgcmVhZExpdGVyYWwoc2NucikpO1xuICAgICAgICAgICAgICAgICAgICBza2lwU3BhY2VzKHNjbnIpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdG9rZW47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmICghdmFsaWROYW1lZElkZW50aWZpZXIgJiYgIXZhbGlkTGlzdElkZW50aWZpZXIgJiYgIXZhbGlkTGl0ZXJhbCkge1xuICAgICAgICAgICAgICAgICAgICAvLyBUT0RPOiB3ZSBzaG91bGQgYmUgcmUtZGVzaWduZWQgaW52YWxpZCBjYXNlcywgd2hlbiB3ZSB3aWxsIGV4dGVuZCBtZXNzYWdlIHN5bnRheCBuZWFyIHRoZSBmdXR1cmUgLi4uXG4gICAgICAgICAgICAgICAgICAgIHRva2VuID0gZ2V0VG9rZW4oY29udGV4dCwgMTIgLyogVG9rZW5UeXBlcy5JbnZhbGlkUGxhY2UgKi8sIHJlYWRJbnZhbGlkSWRlbnRpZmllcihzY25yKSk7XG4gICAgICAgICAgICAgICAgICAgIGVtaXRFcnJvcihDb21waWxlRXJyb3JDb2Rlcy5JTlZBTElEX1RPS0VOX0lOX1BMQUNFSE9MREVSLCBjdXJyZW50UG9zaXRpb24oKSwgMCwgdG9rZW4udmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICBza2lwU3BhY2VzKHNjbnIpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdG9rZW47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0b2tlbjtcbiAgICB9XG4gICAgLy8gVE9ETzogV2UgbmVlZCByZWZhY3RvcmluZyBvZiB0b2tlbiBwYXJzaW5nIC4uLlxuICAgIGZ1bmN0aW9uIHJlYWRUb2tlbkluTGlua2VkKHNjbnIsIGNvbnRleHQpIHtcbiAgICAgICAgY29uc3QgeyBjdXJyZW50VHlwZSB9ID0gY29udGV4dDtcbiAgICAgICAgbGV0IHRva2VuID0gbnVsbDtcbiAgICAgICAgY29uc3QgY2ggPSBzY25yLmN1cnJlbnRDaGFyKCk7XG4gICAgICAgIGlmICgoY3VycmVudFR5cGUgPT09IDcgLyogVG9rZW5UeXBlcy5MaW5rZWRBbGlhcyAqLyB8fFxuICAgICAgICAgICAgY3VycmVudFR5cGUgPT09IDggLyogVG9rZW5UeXBlcy5MaW5rZWREb3QgKi8gfHxcbiAgICAgICAgICAgIGN1cnJlbnRUeXBlID09PSAxMSAvKiBUb2tlblR5cGVzLkxpbmtlZE1vZGlmaWVyICovIHx8XG4gICAgICAgICAgICBjdXJyZW50VHlwZSA9PT0gOSAvKiBUb2tlblR5cGVzLkxpbmtlZERlbGltaXRlciAqLykgJiZcbiAgICAgICAgICAgIChjaCA9PT0gQ0hBUl9MRiB8fCBjaCA9PT0gQ0hBUl9TUCkpIHtcbiAgICAgICAgICAgIGVtaXRFcnJvcihDb21waWxlRXJyb3JDb2Rlcy5JTlZBTElEX0xJTktFRF9GT1JNQVQsIGN1cnJlbnRQb3NpdGlvbigpLCAwKTtcbiAgICAgICAgfVxuICAgICAgICBzd2l0Y2ggKGNoKSB7XG4gICAgICAgICAgICBjYXNlIFwiQFwiIC8qIFRva2VuQ2hhcnMuTGlua2VkQWxpYXMgKi86XG4gICAgICAgICAgICAgICAgc2Nuci5uZXh0KCk7XG4gICAgICAgICAgICAgICAgdG9rZW4gPSBnZXRUb2tlbihjb250ZXh0LCA3IC8qIFRva2VuVHlwZXMuTGlua2VkQWxpYXMgKi8sIFwiQFwiIC8qIFRva2VuQ2hhcnMuTGlua2VkQWxpYXMgKi8pO1xuICAgICAgICAgICAgICAgIGNvbnRleHQuaW5MaW5rZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHJldHVybiB0b2tlbjtcbiAgICAgICAgICAgIGNhc2UgXCIuXCIgLyogVG9rZW5DaGFycy5MaW5rZWREb3QgKi86XG4gICAgICAgICAgICAgICAgc2tpcFNwYWNlcyhzY25yKTtcbiAgICAgICAgICAgICAgICBzY25yLm5leHQoKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZ2V0VG9rZW4oY29udGV4dCwgOCAvKiBUb2tlblR5cGVzLkxpbmtlZERvdCAqLywgXCIuXCIgLyogVG9rZW5DaGFycy5MaW5rZWREb3QgKi8pO1xuICAgICAgICAgICAgY2FzZSBcIjpcIiAvKiBUb2tlbkNoYXJzLkxpbmtlZERlbGltaXRlciAqLzpcbiAgICAgICAgICAgICAgICBza2lwU3BhY2VzKHNjbnIpO1xuICAgICAgICAgICAgICAgIHNjbnIubmV4dCgpO1xuICAgICAgICAgICAgICAgIHJldHVybiBnZXRUb2tlbihjb250ZXh0LCA5IC8qIFRva2VuVHlwZXMuTGlua2VkRGVsaW1pdGVyICovLCBcIjpcIiAvKiBUb2tlbkNoYXJzLkxpbmtlZERlbGltaXRlciAqLyk7XG4gICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgIGlmIChpc1BsdXJhbFN0YXJ0KHNjbnIpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRva2VuID0gZ2V0VG9rZW4oY29udGV4dCwgMSAvKiBUb2tlblR5cGVzLlBpcGUgKi8sIHJlYWRQbHVyYWwoc2NucikpO1xuICAgICAgICAgICAgICAgICAgICAvLyByZXNldFxuICAgICAgICAgICAgICAgICAgICBjb250ZXh0LmJyYWNlTmVzdCA9IDA7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRleHQuaW5MaW5rZWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRva2VuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoaXNMaW5rZWREb3RTdGFydChzY25yLCBjb250ZXh0KSB8fFxuICAgICAgICAgICAgICAgICAgICBpc0xpbmtlZERlbGltaXRlclN0YXJ0KHNjbnIsIGNvbnRleHQpKSB7XG4gICAgICAgICAgICAgICAgICAgIHNraXBTcGFjZXMoc2Nucik7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZWFkVG9rZW5JbkxpbmtlZChzY25yLCBjb250ZXh0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGlzTGlua2VkTW9kaWZpZXJTdGFydChzY25yLCBjb250ZXh0KSkge1xuICAgICAgICAgICAgICAgICAgICBza2lwU3BhY2VzKHNjbnIpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZ2V0VG9rZW4oY29udGV4dCwgMTEgLyogVG9rZW5UeXBlcy5MaW5rZWRNb2RpZmllciAqLywgcmVhZExpbmtlZE1vZGlmaWVyKHNjbnIpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGlzTGlua2VkUmVmZXJTdGFydChzY25yLCBjb250ZXh0KSkge1xuICAgICAgICAgICAgICAgICAgICBza2lwU3BhY2VzKHNjbnIpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoY2ggPT09IFwie1wiIC8qIFRva2VuQ2hhcnMuQnJhY2VMZWZ0ICovKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBzY2FuIHRoZSBwbGFjZWhvbGRlclxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlYWRUb2tlbkluUGxhY2Vob2xkZXIoc2NuciwgY29udGV4dCkgfHwgdG9rZW47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZ2V0VG9rZW4oY29udGV4dCwgMTAgLyogVG9rZW5UeXBlcy5MaW5rZWRLZXkgKi8sIHJlYWRMaW5rZWRSZWZlcihzY25yKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGN1cnJlbnRUeXBlID09PSA3IC8qIFRva2VuVHlwZXMuTGlua2VkQWxpYXMgKi8pIHtcbiAgICAgICAgICAgICAgICAgICAgZW1pdEVycm9yKENvbXBpbGVFcnJvckNvZGVzLklOVkFMSURfTElOS0VEX0ZPUk1BVCwgY3VycmVudFBvc2l0aW9uKCksIDApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjb250ZXh0LmJyYWNlTmVzdCA9IDA7XG4gICAgICAgICAgICAgICAgY29udGV4dC5pbkxpbmtlZCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHJldHVybiByZWFkVG9rZW4oc2NuciwgY29udGV4dCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gVE9ETzogV2UgbmVlZCByZWZhY3RvcmluZyBvZiB0b2tlbiBwYXJzaW5nIC4uLlxuICAgIGZ1bmN0aW9uIHJlYWRUb2tlbihzY25yLCBjb250ZXh0KSB7XG4gICAgICAgIGxldCB0b2tlbiA9IHsgdHlwZTogMTMgLyogVG9rZW5UeXBlcy5FT0YgKi8gfTtcbiAgICAgICAgaWYgKGNvbnRleHQuYnJhY2VOZXN0ID4gMCkge1xuICAgICAgICAgICAgcmV0dXJuIHJlYWRUb2tlbkluUGxhY2Vob2xkZXIoc2NuciwgY29udGV4dCkgfHwgZ2V0RW5kVG9rZW4oY29udGV4dCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGNvbnRleHQuaW5MaW5rZWQpIHtcbiAgICAgICAgICAgIHJldHVybiByZWFkVG9rZW5JbkxpbmtlZChzY25yLCBjb250ZXh0KSB8fCBnZXRFbmRUb2tlbihjb250ZXh0KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBjaCA9IHNjbnIuY3VycmVudENoYXIoKTtcbiAgICAgICAgc3dpdGNoIChjaCkge1xuICAgICAgICAgICAgY2FzZSBcIntcIiAvKiBUb2tlbkNoYXJzLkJyYWNlTGVmdCAqLzpcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVhZFRva2VuSW5QbGFjZWhvbGRlcihzY25yLCBjb250ZXh0KSB8fCBnZXRFbmRUb2tlbihjb250ZXh0KTtcbiAgICAgICAgICAgIGNhc2UgXCJ9XCIgLyogVG9rZW5DaGFycy5CcmFjZVJpZ2h0ICovOlxuICAgICAgICAgICAgICAgIGVtaXRFcnJvcihDb21waWxlRXJyb3JDb2Rlcy5VTkJBTEFOQ0VEX0NMT1NJTkdfQlJBQ0UsIGN1cnJlbnRQb3NpdGlvbigpLCAwKTtcbiAgICAgICAgICAgICAgICBzY25yLm5leHQoKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZ2V0VG9rZW4oY29udGV4dCwgMyAvKiBUb2tlblR5cGVzLkJyYWNlUmlnaHQgKi8sIFwifVwiIC8qIFRva2VuQ2hhcnMuQnJhY2VSaWdodCAqLyk7XG4gICAgICAgICAgICBjYXNlIFwiQFwiIC8qIFRva2VuQ2hhcnMuTGlua2VkQWxpYXMgKi86XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlYWRUb2tlbkluTGlua2VkKHNjbnIsIGNvbnRleHQpIHx8IGdldEVuZFRva2VuKGNvbnRleHQpO1xuICAgICAgICAgICAgZGVmYXVsdDoge1xuICAgICAgICAgICAgICAgIGlmIChpc1BsdXJhbFN0YXJ0KHNjbnIpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRva2VuID0gZ2V0VG9rZW4oY29udGV4dCwgMSAvKiBUb2tlblR5cGVzLlBpcGUgKi8sIHJlYWRQbHVyYWwoc2NucikpO1xuICAgICAgICAgICAgICAgICAgICAvLyByZXNldFxuICAgICAgICAgICAgICAgICAgICBjb250ZXh0LmJyYWNlTmVzdCA9IDA7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRleHQuaW5MaW5rZWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRva2VuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoaXNUZXh0U3RhcnQoc2NucikpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGdldFRva2VuKGNvbnRleHQsIDAgLyogVG9rZW5UeXBlcy5UZXh0ICovLCByZWFkVGV4dChzY25yKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0b2tlbjtcbiAgICB9XG4gICAgZnVuY3Rpb24gbmV4dFRva2VuKCkge1xuICAgICAgICBjb25zdCB7IGN1cnJlbnRUeXBlLCBvZmZzZXQsIHN0YXJ0TG9jLCBlbmRMb2MgfSA9IF9jb250ZXh0O1xuICAgICAgICBfY29udGV4dC5sYXN0VHlwZSA9IGN1cnJlbnRUeXBlO1xuICAgICAgICBfY29udGV4dC5sYXN0T2Zmc2V0ID0gb2Zmc2V0O1xuICAgICAgICBfY29udGV4dC5sYXN0U3RhcnRMb2MgPSBzdGFydExvYztcbiAgICAgICAgX2NvbnRleHQubGFzdEVuZExvYyA9IGVuZExvYztcbiAgICAgICAgX2NvbnRleHQub2Zmc2V0ID0gY3VycmVudE9mZnNldCgpO1xuICAgICAgICBfY29udGV4dC5zdGFydExvYyA9IGN1cnJlbnRQb3NpdGlvbigpO1xuICAgICAgICBpZiAoX3NjbnIuY3VycmVudENoYXIoKSA9PT0gRU9GKSB7XG4gICAgICAgICAgICByZXR1cm4gZ2V0VG9rZW4oX2NvbnRleHQsIDEzIC8qIFRva2VuVHlwZXMuRU9GICovKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVhZFRva2VuKF9zY25yLCBfY29udGV4dCk7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIG5leHRUb2tlbixcbiAgICAgICAgY3VycmVudE9mZnNldCxcbiAgICAgICAgY3VycmVudFBvc2l0aW9uLFxuICAgICAgICBjb250ZXh0XG4gICAgfTtcbn1cblxuY29uc3QgRVJST1JfRE9NQUlOJDIgPSAncGFyc2VyJztcbi8vIEJhY2tzbGFzaCBiYWNrc2xhc2gsIGJhY2tzbGFzaCBxdW90ZSwgdUhISEgsIFVISEhISEguXG5jb25zdCBLTk9XTl9FU0NBUEVTID0gLyg/OlxcXFxcXFxcfFxcXFwnfFxcXFx1KFswLTlhLWZBLUZdezR9KXxcXFxcVShbMC05YS1mQS1GXXs2fSkpL2c7XG4vLyBUZXh0IGNvbnRleHQgZXNjYXBlIHNlcXVlbmNlczogXFxcXCwgXFxALCBcXHssIFxcfSwgXFx8XG5jb25zdCBURVhUX0VTQ0FQRVMgPSAvXFxcXChbXFxcXEB7fXxdKS9nO1xuZnVuY3Rpb24gZnJvbVRleHRFc2NhcGVTZXF1ZW5jZShfbWF0Y2gsIGNoYXIpIHtcbiAgICByZXR1cm4gY2hhcjtcbn1cbmZ1bmN0aW9uIGZyb21Fc2NhcGVTZXF1ZW5jZShtYXRjaCwgY29kZVBvaW50NCwgY29kZVBvaW50Nikge1xuICAgIHN3aXRjaCAobWF0Y2gpIHtcbiAgICAgICAgY2FzZSBgXFxcXFxcXFxgOlxuICAgICAgICAgICAgcmV0dXJuIGBcXFxcYDtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVzZWxlc3MtZXNjYXBlXG4gICAgICAgIGNhc2UgYFxcXFxcXCdgOlxuICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVzZWxlc3MtZXNjYXBlXG4gICAgICAgICAgICByZXR1cm4gYFxcJ2A7XG4gICAgICAgIGRlZmF1bHQ6IHtcbiAgICAgICAgICAgIGNvbnN0IGNvZGVQb2ludCA9IHBhcnNlSW50KGNvZGVQb2ludDQgfHwgY29kZVBvaW50NiwgMTYpO1xuICAgICAgICAgICAgaWYgKGNvZGVQb2ludCA8PSAweGQ3ZmYgfHwgY29kZVBvaW50ID49IDB4ZTAwMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBTdHJpbmcuZnJvbUNvZGVQb2ludChjb2RlUG9pbnQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gaW52YWxpZCAuLi5cbiAgICAgICAgICAgIC8vIFJlcGxhY2UgdGhlbSB3aXRoIFUrRkZGRCBSRVBMQUNFTUVOVCBDSEFSQUNURVIuXG4gICAgICAgICAgICByZXR1cm4gJ++/vSc7XG4gICAgICAgIH1cbiAgICB9XG59XG5mdW5jdGlvbiBjcmVhdGVQYXJzZXIob3B0aW9ucyA9IHt9KSB7XG4gICAgY29uc3QgbG9jYXRpb24gPSBvcHRpb25zLmxvY2F0aW9uICE9PSBmYWxzZTtcbiAgICBjb25zdCB7IG9uRXJyb3IgfSA9IG9wdGlvbnM7XG4gICAgZnVuY3Rpb24gZW1pdEVycm9yKHRva2VuemVyLCBjb2RlLCBzdGFydCwgb2Zmc2V0LCAuLi5hcmdzKSB7XG4gICAgICAgIGNvbnN0IGVuZCA9IHRva2VuemVyLmN1cnJlbnRQb3NpdGlvbigpO1xuICAgICAgICBlbmQub2Zmc2V0ICs9IG9mZnNldDtcbiAgICAgICAgZW5kLmNvbHVtbiArPSBvZmZzZXQ7XG4gICAgICAgIGlmIChvbkVycm9yKSB7XG4gICAgICAgICAgICBjb25zdCBsb2MgPSBsb2NhdGlvbiA/IGNyZWF0ZUxvY2F0aW9uKHN0YXJ0LCBlbmQpIDogbnVsbDtcbiAgICAgICAgICAgIGNvbnN0IGVyciA9IGNyZWF0ZUNvbXBpbGVFcnJvcihjb2RlLCBsb2MsIHtcbiAgICAgICAgICAgICAgICBkb21haW46IEVSUk9SX0RPTUFJTiQyLFxuICAgICAgICAgICAgICAgIGFyZ3NcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgb25FcnJvcihlcnIpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIHN0YXJ0Tm9kZSh0eXBlLCBvZmZzZXQsIGxvYykge1xuICAgICAgICBjb25zdCBub2RlID0geyB0eXBlIH07XG4gICAgICAgIGlmIChsb2NhdGlvbikge1xuICAgICAgICAgICAgbm9kZS5zdGFydCA9IG9mZnNldDtcbiAgICAgICAgICAgIG5vZGUuZW5kID0gb2Zmc2V0O1xuICAgICAgICAgICAgbm9kZS5sb2MgPSB7IHN0YXJ0OiBsb2MsIGVuZDogbG9jIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG5vZGU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGVuZE5vZGUobm9kZSwgb2Zmc2V0LCBwb3MsIHR5cGUpIHtcbiAgICAgICAgaWYgKGxvY2F0aW9uKSB7XG4gICAgICAgICAgICBub2RlLmVuZCA9IG9mZnNldDtcbiAgICAgICAgICAgIGlmIChub2RlLmxvYykge1xuICAgICAgICAgICAgICAgIG5vZGUubG9jLmVuZCA9IHBvcztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBwYXJzZVRleHQodG9rZW5pemVyLCB2YWx1ZSkge1xuICAgICAgICBjb25zdCBjb250ZXh0ID0gdG9rZW5pemVyLmNvbnRleHQoKTtcbiAgICAgICAgY29uc3Qgbm9kZSA9IHN0YXJ0Tm9kZSgzIC8qIE5vZGVUeXBlcy5UZXh0ICovLCBjb250ZXh0Lm9mZnNldCwgY29udGV4dC5zdGFydExvYyk7XG4gICAgICAgIG5vZGUudmFsdWUgPSB2YWx1ZS5yZXBsYWNlKFRFWFRfRVNDQVBFUywgZnJvbVRleHRFc2NhcGVTZXF1ZW5jZSk7XG4gICAgICAgIGVuZE5vZGUobm9kZSwgdG9rZW5pemVyLmN1cnJlbnRPZmZzZXQoKSwgdG9rZW5pemVyLmN1cnJlbnRQb3NpdGlvbigpKTtcbiAgICAgICAgcmV0dXJuIG5vZGU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHBhcnNlTGlzdCh0b2tlbml6ZXIsIGluZGV4KSB7XG4gICAgICAgIGNvbnN0IGNvbnRleHQgPSB0b2tlbml6ZXIuY29udGV4dCgpO1xuICAgICAgICBjb25zdCB7IGxhc3RPZmZzZXQ6IG9mZnNldCwgbGFzdFN0YXJ0TG9jOiBsb2MgfSA9IGNvbnRleHQ7IC8vIGdldCBicmFjZSBsZWZ0IGxvY1xuICAgICAgICBjb25zdCBub2RlID0gc3RhcnROb2RlKDUgLyogTm9kZVR5cGVzLkxpc3QgKi8sIG9mZnNldCwgbG9jKTtcbiAgICAgICAgbm9kZS5pbmRleCA9IHBhcnNlSW50KGluZGV4LCAxMCk7XG4gICAgICAgIHRva2VuaXplci5uZXh0VG9rZW4oKTsgLy8gc2tpcCBicmFjaCByaWdodFxuICAgICAgICBlbmROb2RlKG5vZGUsIHRva2VuaXplci5jdXJyZW50T2Zmc2V0KCksIHRva2VuaXplci5jdXJyZW50UG9zaXRpb24oKSk7XG4gICAgICAgIHJldHVybiBub2RlO1xuICAgIH1cbiAgICBmdW5jdGlvbiBwYXJzZU5hbWVkKHRva2VuaXplciwga2V5KSB7XG4gICAgICAgIGNvbnN0IGNvbnRleHQgPSB0b2tlbml6ZXIuY29udGV4dCgpO1xuICAgICAgICBjb25zdCB7IGxhc3RPZmZzZXQ6IG9mZnNldCwgbGFzdFN0YXJ0TG9jOiBsb2MgfSA9IGNvbnRleHQ7IC8vIGdldCBicmFjZSBsZWZ0IGxvY1xuICAgICAgICBjb25zdCBub2RlID0gc3RhcnROb2RlKDQgLyogTm9kZVR5cGVzLk5hbWVkICovLCBvZmZzZXQsIGxvYyk7XG4gICAgICAgIG5vZGUua2V5ID0ga2V5O1xuICAgICAgICB0b2tlbml6ZXIubmV4dFRva2VuKCk7IC8vIHNraXAgYnJhY2ggcmlnaHRcbiAgICAgICAgZW5kTm9kZShub2RlLCB0b2tlbml6ZXIuY3VycmVudE9mZnNldCgpLCB0b2tlbml6ZXIuY3VycmVudFBvc2l0aW9uKCkpO1xuICAgICAgICByZXR1cm4gbm9kZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gcGFyc2VMaXRlcmFsKHRva2VuaXplciwgdmFsdWUpIHtcbiAgICAgICAgY29uc3QgY29udGV4dCA9IHRva2VuaXplci5jb250ZXh0KCk7XG4gICAgICAgIGNvbnN0IHsgbGFzdE9mZnNldDogb2Zmc2V0LCBsYXN0U3RhcnRMb2M6IGxvYyB9ID0gY29udGV4dDsgLy8gZ2V0IGJyYWNlIGxlZnQgbG9jXG4gICAgICAgIGNvbnN0IG5vZGUgPSBzdGFydE5vZGUoOSAvKiBOb2RlVHlwZXMuTGl0ZXJhbCAqLywgb2Zmc2V0LCBsb2MpO1xuICAgICAgICBub2RlLnZhbHVlID0gdmFsdWUucmVwbGFjZShLTk9XTl9FU0NBUEVTLCBmcm9tRXNjYXBlU2VxdWVuY2UpO1xuICAgICAgICB0b2tlbml6ZXIubmV4dFRva2VuKCk7IC8vIHNraXAgYnJhY2ggcmlnaHRcbiAgICAgICAgZW5kTm9kZShub2RlLCB0b2tlbml6ZXIuY3VycmVudE9mZnNldCgpLCB0b2tlbml6ZXIuY3VycmVudFBvc2l0aW9uKCkpO1xuICAgICAgICByZXR1cm4gbm9kZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gcGFyc2VMaW5rZWRNb2RpZmllcih0b2tlbml6ZXIpIHtcbiAgICAgICAgY29uc3QgdG9rZW4gPSB0b2tlbml6ZXIubmV4dFRva2VuKCk7XG4gICAgICAgIGNvbnN0IGNvbnRleHQgPSB0b2tlbml6ZXIuY29udGV4dCgpO1xuICAgICAgICBjb25zdCB7IGxhc3RPZmZzZXQ6IG9mZnNldCwgbGFzdFN0YXJ0TG9jOiBsb2MgfSA9IGNvbnRleHQ7IC8vIGdldCBsaW5rZWQgZG90IGxvY1xuICAgICAgICBjb25zdCBub2RlID0gc3RhcnROb2RlKDggLyogTm9kZVR5cGVzLkxpbmtlZE1vZGlmaWVyICovLCBvZmZzZXQsIGxvYyk7XG4gICAgICAgIGlmICh0b2tlbi50eXBlICE9PSAxMSAvKiBUb2tlblR5cGVzLkxpbmtlZE1vZGlmaWVyICovKSB7XG4gICAgICAgICAgICAvLyBlbXB0eSBtb2RpZmllclxuICAgICAgICAgICAgZW1pdEVycm9yKHRva2VuaXplciwgQ29tcGlsZUVycm9yQ29kZXMuVU5FWFBFQ1RFRF9FTVBUWV9MSU5LRURfTU9ESUZJRVIsIGNvbnRleHQubGFzdFN0YXJ0TG9jLCAwKTtcbiAgICAgICAgICAgIG5vZGUudmFsdWUgPSAnJztcbiAgICAgICAgICAgIGVuZE5vZGUobm9kZSwgb2Zmc2V0LCBsb2MpO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBuZXh0Q29uc3VtZVRva2VuOiB0b2tlbixcbiAgICAgICAgICAgICAgICBub2RlXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIC8vIGNoZWNrIHRva2VuXG4gICAgICAgIGlmICh0b2tlbi52YWx1ZSA9PSBudWxsKSB7XG4gICAgICAgICAgICBlbWl0RXJyb3IodG9rZW5pemVyLCBDb21waWxlRXJyb3JDb2Rlcy5VTkVYUEVDVEVEX0xFWElDQUxfQU5BTFlTSVMsIGNvbnRleHQubGFzdFN0YXJ0TG9jLCAwLCBnZXRUb2tlbkNhcHRpb24odG9rZW4pKTtcbiAgICAgICAgfVxuICAgICAgICBub2RlLnZhbHVlID0gdG9rZW4udmFsdWUgfHwgJyc7XG4gICAgICAgIGVuZE5vZGUobm9kZSwgdG9rZW5pemVyLmN1cnJlbnRPZmZzZXQoKSwgdG9rZW5pemVyLmN1cnJlbnRQb3NpdGlvbigpKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIG5vZGVcbiAgICAgICAgfTtcbiAgICB9XG4gICAgZnVuY3Rpb24gcGFyc2VMaW5rZWRLZXkodG9rZW5pemVyLCB2YWx1ZSkge1xuICAgICAgICBjb25zdCBjb250ZXh0ID0gdG9rZW5pemVyLmNvbnRleHQoKTtcbiAgICAgICAgY29uc3Qgbm9kZSA9IHN0YXJ0Tm9kZSg3IC8qIE5vZGVUeXBlcy5MaW5rZWRLZXkgKi8sIGNvbnRleHQub2Zmc2V0LCBjb250ZXh0LnN0YXJ0TG9jKTtcbiAgICAgICAgbm9kZS52YWx1ZSA9IHZhbHVlO1xuICAgICAgICBlbmROb2RlKG5vZGUsIHRva2VuaXplci5jdXJyZW50T2Zmc2V0KCksIHRva2VuaXplci5jdXJyZW50UG9zaXRpb24oKSk7XG4gICAgICAgIHJldHVybiBub2RlO1xuICAgIH1cbiAgICBmdW5jdGlvbiBwYXJzZUxpbmtlZCh0b2tlbml6ZXIpIHtcbiAgICAgICAgY29uc3QgY29udGV4dCA9IHRva2VuaXplci5jb250ZXh0KCk7XG4gICAgICAgIGNvbnN0IGxpbmtlZE5vZGUgPSBzdGFydE5vZGUoNiAvKiBOb2RlVHlwZXMuTGlua2VkICovLCBjb250ZXh0Lm9mZnNldCwgY29udGV4dC5zdGFydExvYyk7XG4gICAgICAgIGxldCB0b2tlbiA9IHRva2VuaXplci5uZXh0VG9rZW4oKTtcbiAgICAgICAgaWYgKHRva2VuLnR5cGUgPT09IDggLyogVG9rZW5UeXBlcy5MaW5rZWREb3QgKi8pIHtcbiAgICAgICAgICAgIGNvbnN0IHBhcnNlZCA9IHBhcnNlTGlua2VkTW9kaWZpZXIodG9rZW5pemVyKTtcbiAgICAgICAgICAgIGxpbmtlZE5vZGUubW9kaWZpZXIgPSBwYXJzZWQubm9kZTtcbiAgICAgICAgICAgIHRva2VuID0gcGFyc2VkLm5leHRDb25zdW1lVG9rZW4gfHwgdG9rZW5pemVyLm5leHRUb2tlbigpO1xuICAgICAgICB9XG4gICAgICAgIC8vIGFzc2V0IGNoZWNrIHRva2VuXG4gICAgICAgIGlmICh0b2tlbi50eXBlICE9PSA5IC8qIFRva2VuVHlwZXMuTGlua2VkRGVsaW1pdGVyICovKSB7XG4gICAgICAgICAgICBlbWl0RXJyb3IodG9rZW5pemVyLCBDb21waWxlRXJyb3JDb2Rlcy5VTkVYUEVDVEVEX0xFWElDQUxfQU5BTFlTSVMsIGNvbnRleHQubGFzdFN0YXJ0TG9jLCAwLCBnZXRUb2tlbkNhcHRpb24odG9rZW4pKTtcbiAgICAgICAgfVxuICAgICAgICB0b2tlbiA9IHRva2VuaXplci5uZXh0VG9rZW4oKTtcbiAgICAgICAgLy8gc2tpcCBicmFjZSBsZWZ0XG4gICAgICAgIGlmICh0b2tlbi50eXBlID09PSAyIC8qIFRva2VuVHlwZXMuQnJhY2VMZWZ0ICovKSB7XG4gICAgICAgICAgICB0b2tlbiA9IHRva2VuaXplci5uZXh0VG9rZW4oKTtcbiAgICAgICAgfVxuICAgICAgICBzd2l0Y2ggKHRva2VuLnR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgMTAgLyogVG9rZW5UeXBlcy5MaW5rZWRLZXkgKi86XG4gICAgICAgICAgICAgICAgaWYgKHRva2VuLnZhbHVlID09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgZW1pdEVycm9yKHRva2VuaXplciwgQ29tcGlsZUVycm9yQ29kZXMuVU5FWFBFQ1RFRF9MRVhJQ0FMX0FOQUxZU0lTLCBjb250ZXh0Lmxhc3RTdGFydExvYywgMCwgZ2V0VG9rZW5DYXB0aW9uKHRva2VuKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGxpbmtlZE5vZGUua2V5ID0gcGFyc2VMaW5rZWRLZXkodG9rZW5pemVyLCB0b2tlbi52YWx1ZSB8fCAnJyk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDQgLyogVG9rZW5UeXBlcy5OYW1lZCAqLzpcbiAgICAgICAgICAgICAgICBpZiAodG9rZW4udmFsdWUgPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICBlbWl0RXJyb3IodG9rZW5pemVyLCBDb21waWxlRXJyb3JDb2Rlcy5VTkVYUEVDVEVEX0xFWElDQUxfQU5BTFlTSVMsIGNvbnRleHQubGFzdFN0YXJ0TG9jLCAwLCBnZXRUb2tlbkNhcHRpb24odG9rZW4pKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgbGlua2VkTm9kZS5rZXkgPSBwYXJzZU5hbWVkKHRva2VuaXplciwgdG9rZW4udmFsdWUgfHwgJycpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSA1IC8qIFRva2VuVHlwZXMuTGlzdCAqLzpcbiAgICAgICAgICAgICAgICBpZiAodG9rZW4udmFsdWUgPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICBlbWl0RXJyb3IodG9rZW5pemVyLCBDb21waWxlRXJyb3JDb2Rlcy5VTkVYUEVDVEVEX0xFWElDQUxfQU5BTFlTSVMsIGNvbnRleHQubGFzdFN0YXJ0TG9jLCAwLCBnZXRUb2tlbkNhcHRpb24odG9rZW4pKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgbGlua2VkTm9kZS5rZXkgPSBwYXJzZUxpc3QodG9rZW5pemVyLCB0b2tlbi52YWx1ZSB8fCAnJyk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDYgLyogVG9rZW5UeXBlcy5MaXRlcmFsICovOlxuICAgICAgICAgICAgICAgIGlmICh0b2tlbi52YWx1ZSA9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIGVtaXRFcnJvcih0b2tlbml6ZXIsIENvbXBpbGVFcnJvckNvZGVzLlVORVhQRUNURURfTEVYSUNBTF9BTkFMWVNJUywgY29udGV4dC5sYXN0U3RhcnRMb2MsIDAsIGdldFRva2VuQ2FwdGlvbih0b2tlbikpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBsaW5rZWROb2RlLmtleSA9IHBhcnNlTGl0ZXJhbCh0b2tlbml6ZXIsIHRva2VuLnZhbHVlIHx8ICcnKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGRlZmF1bHQ6IHtcbiAgICAgICAgICAgICAgICAvLyBlbXB0eSBrZXlcbiAgICAgICAgICAgICAgICBlbWl0RXJyb3IodG9rZW5pemVyLCBDb21waWxlRXJyb3JDb2Rlcy5VTkVYUEVDVEVEX0VNUFRZX0xJTktFRF9LRVksIGNvbnRleHQubGFzdFN0YXJ0TG9jLCAwKTtcbiAgICAgICAgICAgICAgICBjb25zdCBuZXh0Q29udGV4dCA9IHRva2VuaXplci5jb250ZXh0KCk7XG4gICAgICAgICAgICAgICAgY29uc3QgZW1wdHlMaW5rZWRLZXlOb2RlID0gc3RhcnROb2RlKDcgLyogTm9kZVR5cGVzLkxpbmtlZEtleSAqLywgbmV4dENvbnRleHQub2Zmc2V0LCBuZXh0Q29udGV4dC5zdGFydExvYyk7XG4gICAgICAgICAgICAgICAgZW1wdHlMaW5rZWRLZXlOb2RlLnZhbHVlID0gJyc7XG4gICAgICAgICAgICAgICAgZW5kTm9kZShlbXB0eUxpbmtlZEtleU5vZGUsIG5leHRDb250ZXh0Lm9mZnNldCwgbmV4dENvbnRleHQuc3RhcnRMb2MpO1xuICAgICAgICAgICAgICAgIGxpbmtlZE5vZGUua2V5ID0gZW1wdHlMaW5rZWRLZXlOb2RlO1xuICAgICAgICAgICAgICAgIGVuZE5vZGUobGlua2VkTm9kZSwgbmV4dENvbnRleHQub2Zmc2V0LCBuZXh0Q29udGV4dC5zdGFydExvYyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgbmV4dENvbnN1bWVUb2tlbjogdG9rZW4sXG4gICAgICAgICAgICAgICAgICAgIG5vZGU6IGxpbmtlZE5vZGVcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVuZE5vZGUobGlua2VkTm9kZSwgdG9rZW5pemVyLmN1cnJlbnRPZmZzZXQoKSwgdG9rZW5pemVyLmN1cnJlbnRQb3NpdGlvbigpKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIG5vZGU6IGxpbmtlZE5vZGVcbiAgICAgICAgfTtcbiAgICB9XG4gICAgZnVuY3Rpb24gcGFyc2VNZXNzYWdlKHRva2VuaXplcikge1xuICAgICAgICBjb25zdCBjb250ZXh0ID0gdG9rZW5pemVyLmNvbnRleHQoKTtcbiAgICAgICAgY29uc3Qgc3RhcnRPZmZzZXQgPSBjb250ZXh0LmN1cnJlbnRUeXBlID09PSAxIC8qIFRva2VuVHlwZXMuUGlwZSAqL1xuICAgICAgICAgICAgPyB0b2tlbml6ZXIuY3VycmVudE9mZnNldCgpXG4gICAgICAgICAgICA6IGNvbnRleHQub2Zmc2V0O1xuICAgICAgICBjb25zdCBzdGFydExvYyA9IGNvbnRleHQuY3VycmVudFR5cGUgPT09IDEgLyogVG9rZW5UeXBlcy5QaXBlICovXG4gICAgICAgICAgICA/IGNvbnRleHQuZW5kTG9jXG4gICAgICAgICAgICA6IGNvbnRleHQuc3RhcnRMb2M7XG4gICAgICAgIGNvbnN0IG5vZGUgPSBzdGFydE5vZGUoMiAvKiBOb2RlVHlwZXMuTWVzc2FnZSAqLywgc3RhcnRPZmZzZXQsIHN0YXJ0TG9jKTtcbiAgICAgICAgbm9kZS5pdGVtcyA9IFtdO1xuICAgICAgICBsZXQgbmV4dFRva2VuID0gbnVsbDtcbiAgICAgICAgZG8ge1xuICAgICAgICAgICAgY29uc3QgdG9rZW4gPSBuZXh0VG9rZW4gfHwgdG9rZW5pemVyLm5leHRUb2tlbigpO1xuICAgICAgICAgICAgbmV4dFRva2VuID0gbnVsbDtcbiAgICAgICAgICAgIHN3aXRjaCAodG9rZW4udHlwZSkge1xuICAgICAgICAgICAgICAgIGNhc2UgMCAvKiBUb2tlblR5cGVzLlRleHQgKi86XG4gICAgICAgICAgICAgICAgICAgIGlmICh0b2tlbi52YWx1ZSA9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBlbWl0RXJyb3IodG9rZW5pemVyLCBDb21waWxlRXJyb3JDb2Rlcy5VTkVYUEVDVEVEX0xFWElDQUxfQU5BTFlTSVMsIGNvbnRleHQubGFzdFN0YXJ0TG9jLCAwLCBnZXRUb2tlbkNhcHRpb24odG9rZW4pKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBub2RlLml0ZW1zLnB1c2gocGFyc2VUZXh0KHRva2VuaXplciwgdG9rZW4udmFsdWUgfHwgJycpKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSA1IC8qIFRva2VuVHlwZXMuTGlzdCAqLzpcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRva2VuLnZhbHVlID09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtaXRFcnJvcih0b2tlbml6ZXIsIENvbXBpbGVFcnJvckNvZGVzLlVORVhQRUNURURfTEVYSUNBTF9BTkFMWVNJUywgY29udGV4dC5sYXN0U3RhcnRMb2MsIDAsIGdldFRva2VuQ2FwdGlvbih0b2tlbikpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIG5vZGUuaXRlbXMucHVzaChwYXJzZUxpc3QodG9rZW5pemVyLCB0b2tlbi52YWx1ZSB8fCAnJykpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIDQgLyogVG9rZW5UeXBlcy5OYW1lZCAqLzpcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRva2VuLnZhbHVlID09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtaXRFcnJvcih0b2tlbml6ZXIsIENvbXBpbGVFcnJvckNvZGVzLlVORVhQRUNURURfTEVYSUNBTF9BTkFMWVNJUywgY29udGV4dC5sYXN0U3RhcnRMb2MsIDAsIGdldFRva2VuQ2FwdGlvbih0b2tlbikpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIG5vZGUuaXRlbXMucHVzaChwYXJzZU5hbWVkKHRva2VuaXplciwgdG9rZW4udmFsdWUgfHwgJycpKTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSA2IC8qIFRva2VuVHlwZXMuTGl0ZXJhbCAqLzpcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRva2VuLnZhbHVlID09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVtaXRFcnJvcih0b2tlbml6ZXIsIENvbXBpbGVFcnJvckNvZGVzLlVORVhQRUNURURfTEVYSUNBTF9BTkFMWVNJUywgY29udGV4dC5sYXN0U3RhcnRMb2MsIDAsIGdldFRva2VuQ2FwdGlvbih0b2tlbikpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIG5vZGUuaXRlbXMucHVzaChwYXJzZUxpdGVyYWwodG9rZW5pemVyLCB0b2tlbi52YWx1ZSB8fCAnJykpO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlIDcgLyogVG9rZW5UeXBlcy5MaW5rZWRBbGlhcyAqLzoge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBwYXJzZWQgPSBwYXJzZUxpbmtlZCh0b2tlbml6ZXIpO1xuICAgICAgICAgICAgICAgICAgICBub2RlLml0ZW1zLnB1c2gocGFyc2VkLm5vZGUpO1xuICAgICAgICAgICAgICAgICAgICBuZXh0VG9rZW4gPSBwYXJzZWQubmV4dENvbnN1bWVUb2tlbiB8fCBudWxsO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gd2hpbGUgKGNvbnRleHQuY3VycmVudFR5cGUgIT09IDEzIC8qIFRva2VuVHlwZXMuRU9GICovICYmXG4gICAgICAgICAgICBjb250ZXh0LmN1cnJlbnRUeXBlICE9PSAxIC8qIFRva2VuVHlwZXMuUGlwZSAqLyk7XG4gICAgICAgIC8vIGFkanVzdCBtZXNzYWdlIG5vZGUgbG9jXG4gICAgICAgIGNvbnN0IGVuZE9mZnNldCA9IGNvbnRleHQuY3VycmVudFR5cGUgPT09IDEgLyogVG9rZW5UeXBlcy5QaXBlICovXG4gICAgICAgICAgICA/IGNvbnRleHQubGFzdE9mZnNldFxuICAgICAgICAgICAgOiB0b2tlbml6ZXIuY3VycmVudE9mZnNldCgpO1xuICAgICAgICBjb25zdCBlbmRMb2MgPSBjb250ZXh0LmN1cnJlbnRUeXBlID09PSAxIC8qIFRva2VuVHlwZXMuUGlwZSAqL1xuICAgICAgICAgICAgPyBjb250ZXh0Lmxhc3RFbmRMb2NcbiAgICAgICAgICAgIDogdG9rZW5pemVyLmN1cnJlbnRQb3NpdGlvbigpO1xuICAgICAgICBlbmROb2RlKG5vZGUsIGVuZE9mZnNldCwgZW5kTG9jKTtcbiAgICAgICAgcmV0dXJuIG5vZGU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHBhcnNlUGx1cmFsKHRva2VuaXplciwgb2Zmc2V0LCBsb2MsIG1zZ05vZGUpIHtcbiAgICAgICAgY29uc3QgY29udGV4dCA9IHRva2VuaXplci5jb250ZXh0KCk7XG4gICAgICAgIGxldCBoYXNFbXB0eU1lc3NhZ2UgPSBtc2dOb2RlLml0ZW1zLmxlbmd0aCA9PT0gMDtcbiAgICAgICAgY29uc3Qgbm9kZSA9IHN0YXJ0Tm9kZSgxIC8qIE5vZGVUeXBlcy5QbHVyYWwgKi8sIG9mZnNldCwgbG9jKTtcbiAgICAgICAgbm9kZS5jYXNlcyA9IFtdO1xuICAgICAgICBub2RlLmNhc2VzLnB1c2gobXNnTm9kZSk7XG4gICAgICAgIGRvIHtcbiAgICAgICAgICAgIGNvbnN0IG1zZyA9IHBhcnNlTWVzc2FnZSh0b2tlbml6ZXIpO1xuICAgICAgICAgICAgaWYgKCFoYXNFbXB0eU1lc3NhZ2UpIHtcbiAgICAgICAgICAgICAgICBoYXNFbXB0eU1lc3NhZ2UgPSBtc2cuaXRlbXMubGVuZ3RoID09PSAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbm9kZS5jYXNlcy5wdXNoKG1zZyk7XG4gICAgICAgIH0gd2hpbGUgKGNvbnRleHQuY3VycmVudFR5cGUgIT09IDEzIC8qIFRva2VuVHlwZXMuRU9GICovKTtcbiAgICAgICAgaWYgKGhhc0VtcHR5TWVzc2FnZSkge1xuICAgICAgICAgICAgZW1pdEVycm9yKHRva2VuaXplciwgQ29tcGlsZUVycm9yQ29kZXMuTVVTVF9IQVZFX01FU1NBR0VTX0lOX1BMVVJBTCwgbG9jLCAwKTtcbiAgICAgICAgfVxuICAgICAgICBlbmROb2RlKG5vZGUsIHRva2VuaXplci5jdXJyZW50T2Zmc2V0KCksIHRva2VuaXplci5jdXJyZW50UG9zaXRpb24oKSk7XG4gICAgICAgIHJldHVybiBub2RlO1xuICAgIH1cbiAgICBmdW5jdGlvbiBwYXJzZVJlc291cmNlKHRva2VuaXplcikge1xuICAgICAgICBjb25zdCBjb250ZXh0ID0gdG9rZW5pemVyLmNvbnRleHQoKTtcbiAgICAgICAgY29uc3QgeyBvZmZzZXQsIHN0YXJ0TG9jIH0gPSBjb250ZXh0O1xuICAgICAgICBjb25zdCBtc2dOb2RlID0gcGFyc2VNZXNzYWdlKHRva2VuaXplcik7XG4gICAgICAgIGlmIChjb250ZXh0LmN1cnJlbnRUeXBlID09PSAxMyAvKiBUb2tlblR5cGVzLkVPRiAqLykge1xuICAgICAgICAgICAgcmV0dXJuIG1zZ05vZGU7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gcGFyc2VQbHVyYWwodG9rZW5pemVyLCBvZmZzZXQsIHN0YXJ0TG9jLCBtc2dOb2RlKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBwYXJzZShzb3VyY2UpIHtcbiAgICAgICAgY29uc3QgdG9rZW5pemVyID0gY3JlYXRlVG9rZW5pemVyKHNvdXJjZSwgYXNzaWduKHt9LCBvcHRpb25zKSk7XG4gICAgICAgIGNvbnN0IGNvbnRleHQgPSB0b2tlbml6ZXIuY29udGV4dCgpO1xuICAgICAgICBjb25zdCBub2RlID0gc3RhcnROb2RlKDAgLyogTm9kZVR5cGVzLlJlc291cmNlICovLCBjb250ZXh0Lm9mZnNldCwgY29udGV4dC5zdGFydExvYyk7XG4gICAgICAgIGlmIChsb2NhdGlvbiAmJiBub2RlLmxvYykge1xuICAgICAgICAgICAgbm9kZS5sb2Muc291cmNlID0gc291cmNlO1xuICAgICAgICB9XG4gICAgICAgIG5vZGUuYm9keSA9IHBhcnNlUmVzb3VyY2UodG9rZW5pemVyKTtcbiAgICAgICAgaWYgKG9wdGlvbnMub25DYWNoZUtleSkge1xuICAgICAgICAgICAgbm9kZS5jYWNoZUtleSA9IG9wdGlvbnMub25DYWNoZUtleShzb3VyY2UpO1xuICAgICAgICB9XG4gICAgICAgIC8vIGFzc2VydCB3aGV0aGVyIGFjaGlldmVkIHRvIEVPRlxuICAgICAgICBpZiAoY29udGV4dC5jdXJyZW50VHlwZSAhPT0gMTMgLyogVG9rZW5UeXBlcy5FT0YgKi8pIHtcbiAgICAgICAgICAgIGVtaXRFcnJvcih0b2tlbml6ZXIsIENvbXBpbGVFcnJvckNvZGVzLlVORVhQRUNURURfTEVYSUNBTF9BTkFMWVNJUywgY29udGV4dC5sYXN0U3RhcnRMb2MsIDAsIHNvdXJjZVtjb250ZXh0Lm9mZnNldF0gfHwgJycpO1xuICAgICAgICB9XG4gICAgICAgIGVuZE5vZGUobm9kZSwgdG9rZW5pemVyLmN1cnJlbnRPZmZzZXQoKSwgdG9rZW5pemVyLmN1cnJlbnRQb3NpdGlvbigpKTtcbiAgICAgICAgcmV0dXJuIG5vZGU7XG4gICAgfVxuICAgIHJldHVybiB7IHBhcnNlIH07XG59XG5mdW5jdGlvbiBnZXRUb2tlbkNhcHRpb24odG9rZW4pIHtcbiAgICBpZiAodG9rZW4udHlwZSA9PT0gMTMgLyogVG9rZW5UeXBlcy5FT0YgKi8pIHtcbiAgICAgICAgcmV0dXJuICdFT0YnO1xuICAgIH1cbiAgICBjb25zdCBuYW1lID0gKHRva2VuLnZhbHVlIHx8ICcnKS5yZXBsYWNlKC9cXHI/XFxuL2d1LCAnXFxcXG4nKTtcbiAgICByZXR1cm4gbmFtZS5sZW5ndGggPiAxMCA/IG5hbWUuc2xpY2UoMCwgOSkgKyAn4oCmJyA6IG5hbWU7XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZVRyYW5zZm9ybWVyKGFzdCwgb3B0aW9ucyA9IHt9IC8vIGVzbGludC1kaXNhYmxlLWxpbmVcbikge1xuICAgIGNvbnN0IF9jb250ZXh0ID0ge1xuICAgICAgICBhc3QsXG4gICAgICAgIGhlbHBlcnM6IG5ldyBTZXQoKVxuICAgIH07XG4gICAgY29uc3QgY29udGV4dCA9ICgpID0+IF9jb250ZXh0O1xuICAgIGNvbnN0IGhlbHBlciA9IChuYW1lKSA9PiB7XG4gICAgICAgIF9jb250ZXh0LmhlbHBlcnMuYWRkKG5hbWUpO1xuICAgICAgICByZXR1cm4gbmFtZTtcbiAgICB9O1xuICAgIHJldHVybiB7IGNvbnRleHQsIGhlbHBlciB9O1xufVxuZnVuY3Rpb24gdHJhdmVyc2VOb2Rlcyhub2RlcywgdHJhbnNmb3JtZXIpIHtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IG5vZGVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHRyYXZlcnNlTm9kZShub2Rlc1tpXSwgdHJhbnNmb3JtZXIpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIHRyYXZlcnNlTm9kZShub2RlLCB0cmFuc2Zvcm1lcikge1xuICAgIC8vIFRPRE86IGlmIHdlIG5lZWQgcHJlLWhvb2sgb2YgdHJhbnNmb3JtLCBzaG91bGQgYmUgaW1wbGVtZW50ZWQgdG8gaGVyZVxuICAgIHN3aXRjaCAobm9kZS50eXBlKSB7XG4gICAgICAgIGNhc2UgMSAvKiBOb2RlVHlwZXMuUGx1cmFsICovOlxuICAgICAgICAgICAgdHJhdmVyc2VOb2Rlcyhub2RlLmNhc2VzLCB0cmFuc2Zvcm1lcik7XG4gICAgICAgICAgICB0cmFuc2Zvcm1lci5oZWxwZXIoXCJwbHVyYWxcIiAvKiBIZWxwZXJOYW1lTWFwLlBMVVJBTCAqLyk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAyIC8qIE5vZGVUeXBlcy5NZXNzYWdlICovOlxuICAgICAgICAgICAgdHJhdmVyc2VOb2Rlcyhub2RlLml0ZW1zLCB0cmFuc2Zvcm1lcik7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSA2IC8qIE5vZGVUeXBlcy5MaW5rZWQgKi86IHtcbiAgICAgICAgICAgIGNvbnN0IGxpbmtlZCA9IG5vZGU7XG4gICAgICAgICAgICB0cmF2ZXJzZU5vZGUobGlua2VkLmtleSwgdHJhbnNmb3JtZXIpO1xuICAgICAgICAgICAgdHJhbnNmb3JtZXIuaGVscGVyKFwibGlua2VkXCIgLyogSGVscGVyTmFtZU1hcC5MSU5LRUQgKi8pO1xuICAgICAgICAgICAgdHJhbnNmb3JtZXIuaGVscGVyKFwidHlwZVwiIC8qIEhlbHBlck5hbWVNYXAuVFlQRSAqLyk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBjYXNlIDUgLyogTm9kZVR5cGVzLkxpc3QgKi86XG4gICAgICAgICAgICB0cmFuc2Zvcm1lci5oZWxwZXIoXCJpbnRlcnBvbGF0ZVwiIC8qIEhlbHBlck5hbWVNYXAuSU5URVJQT0xBVEUgKi8pO1xuICAgICAgICAgICAgdHJhbnNmb3JtZXIuaGVscGVyKFwibGlzdFwiIC8qIEhlbHBlck5hbWVNYXAuTElTVCAqLyk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSA0IC8qIE5vZGVUeXBlcy5OYW1lZCAqLzpcbiAgICAgICAgICAgIHRyYW5zZm9ybWVyLmhlbHBlcihcImludGVycG9sYXRlXCIgLyogSGVscGVyTmFtZU1hcC5JTlRFUlBPTEFURSAqLyk7XG4gICAgICAgICAgICB0cmFuc2Zvcm1lci5oZWxwZXIoXCJuYW1lZFwiIC8qIEhlbHBlck5hbWVNYXAuTkFNRUQgKi8pO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgfVxuICAgIC8vIFRPRE86IGlmIHdlIG5lZWQgcG9zdC1ob29rIG9mIHRyYW5zZm9ybSwgc2hvdWxkIGJlIGltcGxlbWVudGVkIHRvIGhlcmVcbn1cbi8vIHRyYW5zZm9ybSBBU1RcbmZ1bmN0aW9uIHRyYW5zZm9ybShhc3QsIG9wdGlvbnMgPSB7fSAvLyBlc2xpbnQtZGlzYWJsZS1saW5lXG4pIHtcbiAgICBjb25zdCB0cmFuc2Zvcm1lciA9IGNyZWF0ZVRyYW5zZm9ybWVyKGFzdCk7XG4gICAgdHJhbnNmb3JtZXIuaGVscGVyKFwibm9ybWFsaXplXCIgLyogSGVscGVyTmFtZU1hcC5OT1JNQUxJWkUgKi8pO1xuICAgIC8vIHRyYXZlcnNlXG4gICAgYXN0LmJvZHkgJiYgdHJhdmVyc2VOb2RlKGFzdC5ib2R5LCB0cmFuc2Zvcm1lcik7XG4gICAgLy8gc2V0IG1ldGEgaW5mb3JtYXRpb25cbiAgICBjb25zdCBjb250ZXh0ID0gdHJhbnNmb3JtZXIuY29udGV4dCgpO1xuICAgIGFzdC5oZWxwZXJzID0gQXJyYXkuZnJvbShjb250ZXh0LmhlbHBlcnMpO1xufVxuXG5mdW5jdGlvbiBvcHRpbWl6ZShhc3QpIHtcbiAgICBjb25zdCBib2R5ID0gYXN0LmJvZHk7XG4gICAgaWYgKGJvZHkudHlwZSA9PT0gMiAvKiBOb2RlVHlwZXMuTWVzc2FnZSAqLykge1xuICAgICAgICBvcHRpbWl6ZU1lc3NhZ2VOb2RlKGJvZHkpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgYm9keS5jYXNlcy5mb3JFYWNoKGMgPT4gb3B0aW1pemVNZXNzYWdlTm9kZShjKSk7XG4gICAgfVxuICAgIHJldHVybiBhc3Q7XG59XG5mdW5jdGlvbiBvcHRpbWl6ZU1lc3NhZ2VOb2RlKG1lc3NhZ2UpIHtcbiAgICBpZiAobWVzc2FnZS5pdGVtcy5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgY29uc3QgaXRlbSA9IG1lc3NhZ2UuaXRlbXNbMF07XG4gICAgICAgIGlmIChpdGVtLnR5cGUgPT09IDMgLyogTm9kZVR5cGVzLlRleHQgKi8gfHwgaXRlbS50eXBlID09PSA5IC8qIE5vZGVUeXBlcy5MaXRlcmFsICovKSB7XG4gICAgICAgICAgICBtZXNzYWdlLnN0YXRpYyA9IGl0ZW0udmFsdWU7XG4gICAgICAgICAgICBkZWxldGUgaXRlbS52YWx1ZTsgLy8gb3B0aW1pemF0aW9uIGZvciBzaXplXG4gICAgICAgIH1cbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGNvbnN0IHZhbHVlcyA9IFtdO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG1lc3NhZ2UuaXRlbXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGl0ZW0gPSBtZXNzYWdlLml0ZW1zW2ldO1xuICAgICAgICAgICAgaWYgKCEoaXRlbS50eXBlID09PSAzIC8qIE5vZGVUeXBlcy5UZXh0ICovIHx8IGl0ZW0udHlwZSA9PT0gOSAvKiBOb2RlVHlwZXMuTGl0ZXJhbCAqLykpIHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpdGVtLnZhbHVlID09IG51bGwpIHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHZhbHVlcy5wdXNoKGl0ZW0udmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh2YWx1ZXMubGVuZ3RoID09PSBtZXNzYWdlLml0ZW1zLmxlbmd0aCkge1xuICAgICAgICAgICAgbWVzc2FnZS5zdGF0aWMgPSBqb2luKHZhbHVlcyk7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IG1lc3NhZ2UuaXRlbXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICBjb25zdCBpdGVtID0gbWVzc2FnZS5pdGVtc1tpXTtcbiAgICAgICAgICAgICAgICBpZiAoaXRlbS50eXBlID09PSAzIC8qIE5vZGVUeXBlcy5UZXh0ICovIHx8IGl0ZW0udHlwZSA9PT0gOSAvKiBOb2RlVHlwZXMuTGl0ZXJhbCAqLykge1xuICAgICAgICAgICAgICAgICAgICBkZWxldGUgaXRlbS52YWx1ZTsgLy8gb3B0aW1pemF0aW9uIGZvciBzaXplXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG5jb25zdCBFUlJPUl9ET01BSU4kMSA9ICdtaW5pZmllcic7XG4vKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55ICovXG5mdW5jdGlvbiBtaW5pZnkobm9kZSkge1xuICAgIG5vZGUudCA9IG5vZGUudHlwZTtcbiAgICBzd2l0Y2ggKG5vZGUudHlwZSkge1xuICAgICAgICBjYXNlIDAgLyogTm9kZVR5cGVzLlJlc291cmNlICovOiB7XG4gICAgICAgICAgICBjb25zdCByZXNvdXJjZSA9IG5vZGU7XG4gICAgICAgICAgICBtaW5pZnkocmVzb3VyY2UuYm9keSk7XG4gICAgICAgICAgICByZXNvdXJjZS5iID0gcmVzb3VyY2UuYm9keTtcbiAgICAgICAgICAgIGRlbGV0ZSByZXNvdXJjZS5ib2R5O1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgY2FzZSAxIC8qIE5vZGVUeXBlcy5QbHVyYWwgKi86IHtcbiAgICAgICAgICAgIGNvbnN0IHBsdXJhbCA9IG5vZGU7XG4gICAgICAgICAgICBjb25zdCBjYXNlcyA9IHBsdXJhbC5jYXNlcztcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY2FzZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICBtaW5pZnkoY2FzZXNbaV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcGx1cmFsLmMgPSBjYXNlcztcbiAgICAgICAgICAgIGRlbGV0ZSBwbHVyYWwuY2FzZXM7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBjYXNlIDIgLyogTm9kZVR5cGVzLk1lc3NhZ2UgKi86IHtcbiAgICAgICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBub2RlO1xuICAgICAgICAgICAgY29uc3QgaXRlbXMgPSBtZXNzYWdlLml0ZW1zO1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpdGVtcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIG1pbmlmeShpdGVtc1tpXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtZXNzYWdlLmkgPSBpdGVtcztcbiAgICAgICAgICAgIGRlbGV0ZSBtZXNzYWdlLml0ZW1zO1xuICAgICAgICAgICAgaWYgKG1lc3NhZ2Uuc3RhdGljKSB7XG4gICAgICAgICAgICAgICAgbWVzc2FnZS5zID0gbWVzc2FnZS5zdGF0aWM7XG4gICAgICAgICAgICAgICAgZGVsZXRlIG1lc3NhZ2Uuc3RhdGljO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgY2FzZSAzIC8qIE5vZGVUeXBlcy5UZXh0ICovOlxuICAgICAgICBjYXNlIDkgLyogTm9kZVR5cGVzLkxpdGVyYWwgKi86XG4gICAgICAgIGNhc2UgOCAvKiBOb2RlVHlwZXMuTGlua2VkTW9kaWZpZXIgKi86XG4gICAgICAgIGNhc2UgNyAvKiBOb2RlVHlwZXMuTGlua2VkS2V5ICovOiB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZU5vZGUgPSBub2RlO1xuICAgICAgICAgICAgaWYgKHZhbHVlTm9kZS52YWx1ZSkge1xuICAgICAgICAgICAgICAgIHZhbHVlTm9kZS52ID0gdmFsdWVOb2RlLnZhbHVlO1xuICAgICAgICAgICAgICAgIGRlbGV0ZSB2YWx1ZU5vZGUudmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBjYXNlIDYgLyogTm9kZVR5cGVzLkxpbmtlZCAqLzoge1xuICAgICAgICAgICAgY29uc3QgbGlua2VkID0gbm9kZTtcbiAgICAgICAgICAgIG1pbmlmeShsaW5rZWQua2V5KTtcbiAgICAgICAgICAgIGxpbmtlZC5rID0gbGlua2VkLmtleTtcbiAgICAgICAgICAgIGRlbGV0ZSBsaW5rZWQua2V5O1xuICAgICAgICAgICAgaWYgKGxpbmtlZC5tb2RpZmllcikge1xuICAgICAgICAgICAgICAgIG1pbmlmeShsaW5rZWQubW9kaWZpZXIpO1xuICAgICAgICAgICAgICAgIGxpbmtlZC5tID0gbGlua2VkLm1vZGlmaWVyO1xuICAgICAgICAgICAgICAgIGRlbGV0ZSBsaW5rZWQubW9kaWZpZXI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBjYXNlIDUgLyogTm9kZVR5cGVzLkxpc3QgKi86IHtcbiAgICAgICAgICAgIGNvbnN0IGxpc3QgPSBub2RlO1xuICAgICAgICAgICAgbGlzdC5pID0gbGlzdC5pbmRleDtcbiAgICAgICAgICAgIGRlbGV0ZSBsaXN0LmluZGV4O1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgY2FzZSA0IC8qIE5vZGVUeXBlcy5OYW1lZCAqLzoge1xuICAgICAgICAgICAgY29uc3QgbmFtZWQgPSBub2RlO1xuICAgICAgICAgICAgbmFtZWQuayA9IG5hbWVkLmtleTtcbiAgICAgICAgICAgIGRlbGV0ZSBuYW1lZC5rZXk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgaWYgKChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSkge1xuICAgICAgICAgICAgICAgIHRocm93IGNyZWF0ZUNvbXBpbGVFcnJvcihDb21waWxlRXJyb3JDb2Rlcy5VTkhBTkRMRURfTUlOSUZJRVJfTk9ERV9UWVBFLCBudWxsLCB7XG4gICAgICAgICAgICAgICAgICAgIGRvbWFpbjogRVJST1JfRE9NQUlOJDEsXG4gICAgICAgICAgICAgICAgICAgIGFyZ3M6IFtub2RlLnR5cGVdXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgfVxuICAgIGRlbGV0ZSBub2RlLnR5cGU7XG59XG4vKiBlc2xpbnQtZW5hYmxlIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnkgKi9cblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC90cmlwbGUtc2xhc2gtcmVmZXJlbmNlXG4vLy8gPHJlZmVyZW5jZSB0eXBlcz1cInNvdXJjZS1tYXAtanNcIiAvPlxuY29uc3QgRVJST1JfRE9NQUlOID0gJ3BhcnNlcic7XG5mdW5jdGlvbiBjcmVhdGVDb2RlR2VuZXJhdG9yKGFzdCwgb3B0aW9ucykge1xuICAgIGNvbnN0IHsgZmlsZW5hbWUsIGJyZWFrTGluZUNvZGUsIG5lZWRJbmRlbnQ6IF9uZWVkSW5kZW50IH0gPSBvcHRpb25zO1xuICAgIGNvbnN0IGxvY2F0aW9uID0gb3B0aW9ucy5sb2NhdGlvbiAhPT0gZmFsc2U7XG4gICAgY29uc3QgX2NvbnRleHQgPSB7XG4gICAgICAgIGZpbGVuYW1lLFxuICAgICAgICBjb2RlOiAnJyxcbiAgICAgICAgY29sdW1uOiAxLFxuICAgICAgICBsaW5lOiAxLFxuICAgICAgICBvZmZzZXQ6IDAsXG4gICAgICAgIG1hcDogdW5kZWZpbmVkLFxuICAgICAgICBicmVha0xpbmVDb2RlLFxuICAgICAgICBuZWVkSW5kZW50OiBfbmVlZEluZGVudCxcbiAgICAgICAgaW5kZW50TGV2ZWw6IDBcbiAgICB9O1xuICAgIGlmIChsb2NhdGlvbiAmJiBhc3QubG9jKSB7XG4gICAgICAgIF9jb250ZXh0LnNvdXJjZSA9IGFzdC5sb2Muc291cmNlO1xuICAgIH1cbiAgICBjb25zdCBjb250ZXh0ID0gKCkgPT4gX2NvbnRleHQ7XG4gICAgZnVuY3Rpb24gcHVzaChjb2RlLCBub2RlKSB7XG4gICAgICAgIF9jb250ZXh0LmNvZGUgKz0gY29kZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gX25ld2xpbmUobiwgd2l0aEJyZWFrTGluZSA9IHRydWUpIHtcbiAgICAgICAgY29uc3QgX2JyZWFrTGluZUNvZGUgPSB3aXRoQnJlYWtMaW5lID8gYnJlYWtMaW5lQ29kZSA6ICcnO1xuICAgICAgICBwdXNoKF9uZWVkSW5kZW50ID8gX2JyZWFrTGluZUNvZGUgKyBgICBgLnJlcGVhdChuKSA6IF9icmVha0xpbmVDb2RlKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gaW5kZW50KHdpdGhOZXdMaW5lID0gdHJ1ZSkge1xuICAgICAgICBjb25zdCBsZXZlbCA9ICsrX2NvbnRleHQuaW5kZW50TGV2ZWw7XG4gICAgICAgIHdpdGhOZXdMaW5lICYmIF9uZXdsaW5lKGxldmVsKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZGVpbmRlbnQod2l0aE5ld0xpbmUgPSB0cnVlKSB7XG4gICAgICAgIGNvbnN0IGxldmVsID0gLS1fY29udGV4dC5pbmRlbnRMZXZlbDtcbiAgICAgICAgd2l0aE5ld0xpbmUgJiYgX25ld2xpbmUobGV2ZWwpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBuZXdsaW5lKCkge1xuICAgICAgICBfbmV3bGluZShfY29udGV4dC5pbmRlbnRMZXZlbCk7XG4gICAgfVxuICAgIGNvbnN0IGhlbHBlciA9IChrZXkpID0+IGBfJHtrZXl9YDtcbiAgICBjb25zdCBuZWVkSW5kZW50ID0gKCkgPT4gX2NvbnRleHQubmVlZEluZGVudDtcbiAgICByZXR1cm4ge1xuICAgICAgICBjb250ZXh0LFxuICAgICAgICBwdXNoLFxuICAgICAgICBpbmRlbnQsXG4gICAgICAgIGRlaW5kZW50LFxuICAgICAgICBuZXdsaW5lLFxuICAgICAgICBoZWxwZXIsXG4gICAgICAgIG5lZWRJbmRlbnRcbiAgICB9O1xufVxuZnVuY3Rpb24gZ2VuZXJhdGVMaW5rZWROb2RlKGdlbmVyYXRvciwgbm9kZSkge1xuICAgIGNvbnN0IHsgaGVscGVyIH0gPSBnZW5lcmF0b3I7XG4gICAgZ2VuZXJhdG9yLnB1c2goYCR7aGVscGVyKFwibGlua2VkXCIgLyogSGVscGVyTmFtZU1hcC5MSU5LRUQgKi8pfShgKTtcbiAgICBnZW5lcmF0ZU5vZGUoZ2VuZXJhdG9yLCBub2RlLmtleSk7XG4gICAgaWYgKG5vZGUubW9kaWZpZXIpIHtcbiAgICAgICAgZ2VuZXJhdG9yLnB1c2goYCwgYCk7XG4gICAgICAgIGdlbmVyYXRlTm9kZShnZW5lcmF0b3IsIG5vZGUubW9kaWZpZXIpO1xuICAgICAgICBnZW5lcmF0b3IucHVzaChgLCBfdHlwZWApO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgZ2VuZXJhdG9yLnB1c2goYCwgdW5kZWZpbmVkLCBfdHlwZWApO1xuICAgIH1cbiAgICBnZW5lcmF0b3IucHVzaChgKWApO1xufVxuZnVuY3Rpb24gZ2VuZXJhdGVNZXNzYWdlTm9kZShnZW5lcmF0b3IsIG5vZGUpIHtcbiAgICBjb25zdCB7IGhlbHBlciwgbmVlZEluZGVudCB9ID0gZ2VuZXJhdG9yO1xuICAgIGdlbmVyYXRvci5wdXNoKGAke2hlbHBlcihcIm5vcm1hbGl6ZVwiIC8qIEhlbHBlck5hbWVNYXAuTk9STUFMSVpFICovKX0oW2ApO1xuICAgIGdlbmVyYXRvci5pbmRlbnQobmVlZEluZGVudCgpKTtcbiAgICBjb25zdCBsZW5ndGggPSBub2RlLml0ZW1zLmxlbmd0aDtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGdlbmVyYXRlTm9kZShnZW5lcmF0b3IsIG5vZGUuaXRlbXNbaV0pO1xuICAgICAgICBpZiAoaSA9PT0gbGVuZ3RoIC0gMSkge1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgZ2VuZXJhdG9yLnB1c2goJywgJyk7XG4gICAgfVxuICAgIGdlbmVyYXRvci5kZWluZGVudChuZWVkSW5kZW50KCkpO1xuICAgIGdlbmVyYXRvci5wdXNoKCddKScpO1xufVxuZnVuY3Rpb24gZ2VuZXJhdGVQbHVyYWxOb2RlKGdlbmVyYXRvciwgbm9kZSkge1xuICAgIGNvbnN0IHsgaGVscGVyLCBuZWVkSW5kZW50IH0gPSBnZW5lcmF0b3I7XG4gICAgaWYgKG5vZGUuY2FzZXMubGVuZ3RoID4gMSkge1xuICAgICAgICBnZW5lcmF0b3IucHVzaChgJHtoZWxwZXIoXCJwbHVyYWxcIiAvKiBIZWxwZXJOYW1lTWFwLlBMVVJBTCAqLyl9KFtgKTtcbiAgICAgICAgZ2VuZXJhdG9yLmluZGVudChuZWVkSW5kZW50KCkpO1xuICAgICAgICBjb25zdCBsZW5ndGggPSBub2RlLmNhc2VzLmxlbmd0aDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgZ2VuZXJhdGVOb2RlKGdlbmVyYXRvciwgbm9kZS5jYXNlc1tpXSk7XG4gICAgICAgICAgICBpZiAoaSA9PT0gbGVuZ3RoIC0gMSkge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZ2VuZXJhdG9yLnB1c2goJywgJyk7XG4gICAgICAgIH1cbiAgICAgICAgZ2VuZXJhdG9yLmRlaW5kZW50KG5lZWRJbmRlbnQoKSk7XG4gICAgICAgIGdlbmVyYXRvci5wdXNoKGBdKWApO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGdlbmVyYXRlUmVzb3VyY2UoZ2VuZXJhdG9yLCBub2RlKSB7XG4gICAgaWYgKG5vZGUuYm9keSkge1xuICAgICAgICBnZW5lcmF0ZU5vZGUoZ2VuZXJhdG9yLCBub2RlLmJvZHkpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgZ2VuZXJhdG9yLnB1c2goJ251bGwnKTtcbiAgICB9XG59XG5mdW5jdGlvbiBnZW5lcmF0ZU5vZGUoZ2VuZXJhdG9yLCBub2RlKSB7XG4gICAgY29uc3QgeyBoZWxwZXIgfSA9IGdlbmVyYXRvcjtcbiAgICBzd2l0Y2ggKG5vZGUudHlwZSkge1xuICAgICAgICBjYXNlIDAgLyogTm9kZVR5cGVzLlJlc291cmNlICovOlxuICAgICAgICAgICAgZ2VuZXJhdGVSZXNvdXJjZShnZW5lcmF0b3IsIG5vZGUpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgMSAvKiBOb2RlVHlwZXMuUGx1cmFsICovOlxuICAgICAgICAgICAgZ2VuZXJhdGVQbHVyYWxOb2RlKGdlbmVyYXRvciwgbm9kZSk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAyIC8qIE5vZGVUeXBlcy5NZXNzYWdlICovOlxuICAgICAgICAgICAgZ2VuZXJhdGVNZXNzYWdlTm9kZShnZW5lcmF0b3IsIG5vZGUpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgNiAvKiBOb2RlVHlwZXMuTGlua2VkICovOlxuICAgICAgICAgICAgZ2VuZXJhdGVMaW5rZWROb2RlKGdlbmVyYXRvciwgbm9kZSk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSA4IC8qIE5vZGVUeXBlcy5MaW5rZWRNb2RpZmllciAqLzpcbiAgICAgICAgICAgIGdlbmVyYXRvci5wdXNoKEpTT04uc3RyaW5naWZ5KG5vZGUudmFsdWUpLCBub2RlKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIDcgLyogTm9kZVR5cGVzLkxpbmtlZEtleSAqLzpcbiAgICAgICAgICAgIGdlbmVyYXRvci5wdXNoKEpTT04uc3RyaW5naWZ5KG5vZGUudmFsdWUpLCBub2RlKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIDUgLyogTm9kZVR5cGVzLkxpc3QgKi86XG4gICAgICAgICAgICBnZW5lcmF0b3IucHVzaChgJHtoZWxwZXIoXCJpbnRlcnBvbGF0ZVwiIC8qIEhlbHBlck5hbWVNYXAuSU5URVJQT0xBVEUgKi8pfSgke2hlbHBlcihcImxpc3RcIiAvKiBIZWxwZXJOYW1lTWFwLkxJU1QgKi8pfSgke25vZGUuaW5kZXh9KSlgLCBub2RlKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIDQgLyogTm9kZVR5cGVzLk5hbWVkICovOlxuICAgICAgICAgICAgZ2VuZXJhdG9yLnB1c2goYCR7aGVscGVyKFwiaW50ZXJwb2xhdGVcIiAvKiBIZWxwZXJOYW1lTWFwLklOVEVSUE9MQVRFICovKX0oJHtoZWxwZXIoXCJuYW1lZFwiIC8qIEhlbHBlck5hbWVNYXAuTkFNRUQgKi8pfSgke0pTT04uc3RyaW5naWZ5KG5vZGUua2V5KX0pKWAsIG5vZGUpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgOSAvKiBOb2RlVHlwZXMuTGl0ZXJhbCAqLzpcbiAgICAgICAgICAgIGdlbmVyYXRvci5wdXNoKEpTT04uc3RyaW5naWZ5KG5vZGUudmFsdWUpLCBub2RlKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIDMgLyogTm9kZVR5cGVzLlRleHQgKi86XG4gICAgICAgICAgICBnZW5lcmF0b3IucHVzaChKU09OLnN0cmluZ2lmeShub2RlLnZhbHVlKSwgbm9kZSk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIGlmICgocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBjcmVhdGVDb21waWxlRXJyb3IoQ29tcGlsZUVycm9yQ29kZXMuVU5IQU5ETEVEX0NPREVHRU5fTk9ERV9UWVBFLCBudWxsLCB7XG4gICAgICAgICAgICAgICAgICAgIGRvbWFpbjogRVJST1JfRE9NQUlOLFxuICAgICAgICAgICAgICAgICAgICBhcmdzOiBbbm9kZS50eXBlXVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgIH1cbn1cbi8vIGdlbmVyYXRlIGNvZGUgZnJvbSBBU1RcbmNvbnN0IGdlbmVyYXRlID0gKGFzdCwgb3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgY29uc3QgbW9kZSA9IGlzU3RyaW5nKG9wdGlvbnMubW9kZSkgPyBvcHRpb25zLm1vZGUgOiAnbm9ybWFsJztcbiAgICBjb25zdCBmaWxlbmFtZSA9IGlzU3RyaW5nKG9wdGlvbnMuZmlsZW5hbWUpXG4gICAgICAgID8gb3B0aW9ucy5maWxlbmFtZVxuICAgICAgICA6ICdtZXNzYWdlLmludGwnO1xuICAgICEhb3B0aW9ucy5zb3VyY2VNYXA7XG4gICAgLy8gcHJldHRpZXItaWdub3JlXG4gICAgY29uc3QgYnJlYWtMaW5lQ29kZSA9IG9wdGlvbnMuYnJlYWtMaW5lQ29kZSAhPSBudWxsXG4gICAgICAgID8gb3B0aW9ucy5icmVha0xpbmVDb2RlXG4gICAgICAgIDogbW9kZSA9PT0gJ2Fycm93J1xuICAgICAgICAgICAgPyAnOydcbiAgICAgICAgICAgIDogJ1xcbic7XG4gICAgY29uc3QgbmVlZEluZGVudCA9IG9wdGlvbnMubmVlZEluZGVudCA/IG9wdGlvbnMubmVlZEluZGVudCA6IG1vZGUgIT09ICdhcnJvdyc7XG4gICAgY29uc3QgaGVscGVycyA9IGFzdC5oZWxwZXJzIHx8IFtdO1xuICAgIGNvbnN0IGdlbmVyYXRvciA9IGNyZWF0ZUNvZGVHZW5lcmF0b3IoYXN0LCB7XG4gICAgICAgIGZpbGVuYW1lLFxuICAgICAgICBicmVha0xpbmVDb2RlLFxuICAgICAgICBuZWVkSW5kZW50XG4gICAgfSk7XG4gICAgZ2VuZXJhdG9yLnB1c2gobW9kZSA9PT0gJ25vcm1hbCcgPyBgZnVuY3Rpb24gX19tc2dfXyAoY3R4KSB7YCA6IGAoY3R4KSA9PiB7YCk7XG4gICAgZ2VuZXJhdG9yLmluZGVudChuZWVkSW5kZW50KTtcbiAgICBpZiAoaGVscGVycy5sZW5ndGggPiAwKSB7XG4gICAgICAgIGdlbmVyYXRvci5wdXNoKGBjb25zdCB7ICR7am9pbihoZWxwZXJzLm1hcChzID0+IGAke3N9OiBfJHtzfWApLCAnLCAnKX0gfSA9IGN0eGApO1xuICAgICAgICBnZW5lcmF0b3IubmV3bGluZSgpO1xuICAgIH1cbiAgICBnZW5lcmF0b3IucHVzaChgcmV0dXJuIGApO1xuICAgIGdlbmVyYXRlTm9kZShnZW5lcmF0b3IsIGFzdCk7XG4gICAgZ2VuZXJhdG9yLmRlaW5kZW50KG5lZWRJbmRlbnQpO1xuICAgIGdlbmVyYXRvci5wdXNoKGB9YCk7XG4gICAgZGVsZXRlIGFzdC5oZWxwZXJzO1xuICAgIGNvbnN0IHsgY29kZSwgbWFwIH0gPSBnZW5lcmF0b3IuY29udGV4dCgpO1xuICAgIHJldHVybiB7XG4gICAgICAgIGFzdCxcbiAgICAgICAgY29kZSxcbiAgICAgICAgbWFwOiBtYXAgPyBtYXAudG9KU09OKCkgOiB1bmRlZmluZWQgLy8gZXNsaW50LWRpc2FibGUtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gICAgfTtcbn07XG5cbmZ1bmN0aW9uIGJhc2VDb21waWxlKHNvdXJjZSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgY29uc3QgYXNzaWduZWRPcHRpb25zID0gYXNzaWduKHt9LCBvcHRpb25zKTtcbiAgICBjb25zdCBqaXQgPSAhIWFzc2lnbmVkT3B0aW9ucy5qaXQ7XG4gICAgY29uc3QgZW5hbGJlTWluaWZ5ID0gISFhc3NpZ25lZE9wdGlvbnMubWluaWZ5O1xuICAgIGNvbnN0IGVuYW1iZU9wdGltaXplID0gYXNzaWduZWRPcHRpb25zLm9wdGltaXplID09IG51bGwgPyB0cnVlIDogYXNzaWduZWRPcHRpb25zLm9wdGltaXplO1xuICAgIC8vIHBhcnNlIHNvdXJjZSBjb2Rlc1xuICAgIGNvbnN0IHBhcnNlciA9IGNyZWF0ZVBhcnNlcihhc3NpZ25lZE9wdGlvbnMpO1xuICAgIGNvbnN0IGFzdCA9IHBhcnNlci5wYXJzZShzb3VyY2UpO1xuICAgIGlmICghaml0KSB7XG4gICAgICAgIC8vIHRyYW5zZm9ybSBBU1RzXG4gICAgICAgIHRyYW5zZm9ybShhc3QsIGFzc2lnbmVkT3B0aW9ucyk7XG4gICAgICAgIC8vIGdlbmVyYXRlIGphdmFzY3JpcHQgY29kZXNcbiAgICAgICAgcmV0dXJuIGdlbmVyYXRlKGFzdCwgYXNzaWduZWRPcHRpb25zKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIC8vIG9wdGltaXplIEFTVHNcbiAgICAgICAgZW5hbWJlT3B0aW1pemUgJiYgb3B0aW1pemUoYXN0KTtcbiAgICAgICAgLy8gbWluaW1pemUgQVNUc1xuICAgICAgICBlbmFsYmVNaW5pZnkgJiYgbWluaWZ5KGFzdCk7XG4gICAgICAgIC8vIEluIEpJVCBtb2RlLCBubyBhc3QgdHJhbnNmb3JtLCBubyBjb2RlIGdlbmVyYXRpb24uXG4gICAgICAgIHJldHVybiB7IGFzdCwgY29kZTogJycgfTtcbiAgICB9XG59XG5cbmV4cG9ydCB7IENPTVBJTEVfRVJST1JfQ09ERVNfRVhURU5EX1BPSU5ULCBDb21waWxlRXJyb3JDb2RlcywgRVJST1JfRE9NQUlOJDIgYXMgRVJST1JfRE9NQUlOLCBMT0NBVElPTl9TVFVCLCBiYXNlQ29tcGlsZSwgY3JlYXRlQ29tcGlsZUVycm9yLCBjcmVhdGVMb2NhdGlvbiwgY3JlYXRlUGFyc2VyLCBjcmVhdGVQb3NpdGlvbiwgZGVmYXVsdE9uRXJyb3IsIGRldGVjdEh0bWxUYWcsIGVycm9yTWVzc2FnZXMgfTtcbiJdLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19