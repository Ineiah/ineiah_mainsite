/*!
* vue-router v5.2.0
* (c) 2026 Eduardo San Martin Morote
* @license MIT
*/
import { _ as isRouteComponent, c as diagnostics, g as isESModule, h as isArray, p as assign, r as matchedRouteKey, u as createRouterError } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue-router@5.2.0_@vue+compiler-sfc@3.5.40_esbuild@0.28.1_pinia@4.0.2_@vue+devtools-api@_da13f14f8d547f2ae66d0a1be426cab8/node_modules/vue-router/dist/useApi-CROJJdhE.js?v=7e73afc2";
import { getCurrentInstance, inject, onActivated, onDeactivated, onUnmounted, watch } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/vue@3.5.40_typescript@6.0.3/node_modules/vue/dist/vue.runtime.esm-bundler.js?v=7e73afc2";
import { setupDevtoolsPlugin } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vue+devtools-api@8.2.1/node_modules/@vue/devtools-api/dist/index.js?v=7e73afc2";
//#region src/utils/env.ts
const isBrowser = typeof document !== "undefined";
//#endregion
//#region src/encoding.ts
/**
* Encoding Rules (␣ = Space)
* - Path: ␣ " < > # ? { }
* - Query: ␣ " < > # & =
* - Hash: ␣ " < > `
*
* On top of that, the RFC3986 (https://tools.ietf.org/html/rfc3986#section-2.2)
* defines some extra characters to be encoded. Most browsers do not encode them
* in encodeURI https://github.com/whatwg/url/issues/369, so it may be safer to
* also encode `!'()*`. Leaving un-encoded only ASCII alphanumeric(`a-zA-Z0-9`)
* plus `-._~`. This extra safety should be applied to query by patching the
* string returned by encodeURIComponent encodeURI also encodes `[\]^`. `\`
* should be encoded to avoid ambiguity. Browsers (IE, FF, C) transform a `\`
* into a `/` if directly typed in. The _backtick_ (`````) should also be
* encoded everywhere because some browsers like FF encode it when directly
* written while others don't. Safari and IE don't encode ``"<>{}``` in hash.
*/
const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const IM_RE = /\?/g;
const PLUS_RE = /\+/g;
/**
* NOTE: It's not clear to me if we should encode the + symbol in queries, it
* seems to be less flexible than not doing so and I can't find out the legacy
* systems requiring this for regular requests like text/html. In the standard,
* the encoding of the plus character is only mentioned for
* application/x-www-form-urlencoded
* (https://url.spec.whatwg.org/#urlencoded-parsing) and most browsers seems lo
* leave the plus character as is in queries. To be more flexible, we allow the
* plus character on the query, but it can also be manually encoded by the user.
*
* Resources:
* - https://url.spec.whatwg.org/#urlencoded-parsing
* - https://stackoverflow.com/questions/1634271/url-encoding-the-space-character-or-20
*/
const ENC_BRACKET_OPEN_RE = /%5B/g;
const ENC_BRACKET_CLOSE_RE = /%5D/g;
const ENC_CARET_RE = /%5E/g;
const ENC_BACKTICK_RE = /%60/g;
const ENC_CURLY_OPEN_RE = /%7B/g;
const ENC_PIPE_RE = /%7C/g;
const ENC_CURLY_CLOSE_RE = /%7D/g;
const ENC_SPACE_RE = /%20/g;
/**
* Encode characters that need to be encoded on the path, search and hash
* sections of the URL.
*
* @internal
* @param text - string to encode
* @returns encoded string
*/
function commonEncode(text) {
	return text == null ? "" : encodeURI("" + text).replace(ENC_PIPE_RE, "|").replace(ENC_BRACKET_OPEN_RE, "[").replace(ENC_BRACKET_CLOSE_RE, "]");
}
/**
* Encode characters that need to be encoded on the hash section of the URL.
*
* @param text - string to encode
* @returns encoded string
*/
function encodeHash(text) {
	return commonEncode(text).replace(ENC_CURLY_OPEN_RE, "{").replace(ENC_CURLY_CLOSE_RE, "}").replace(ENC_CARET_RE, "^");
}
/**
* Encode characters that need to be encoded query values on the query
* section of the URL.
*
* @param text - string to encode
* @returns encoded string
*/
function encodeQueryValue(text) {
	return commonEncode(text).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CURLY_OPEN_RE, "{").replace(ENC_CURLY_CLOSE_RE, "}").replace(ENC_CARET_RE, "^");
}
/**
* Like `encodeQueryValue` but also encodes the `=` character.
*
* @param text - string to encode
*/
function encodeQueryKey(text) {
	return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
/**
* Encode characters that need to be encoded on the path section of the URL.
*
* @param text - string to encode
* @returns encoded string
*/
function encodePath(text) {
	return commonEncode(text).replace(HASH_RE, "%23").replace(IM_RE, "%3F");
}
/**
* Encode characters that need to be encoded on the path section of the URL as a
* param. This function encodes everything {@link encodePath} does plus the
* slash (`/`) character. If `text` is `null` or `undefined`, returns an empty
* string instead.
*
* @param text - string to encode
* @returns encoded string
*/
function encodeParam(text) {
	return encodePath(text).replace(SLASH_RE, "%2F");
}
function decode(text) {
	if (text == null) return null;
	try {
		return decodeURIComponent("" + text);
	} catch {
		"development" !== "production" && diagnostics.VUE_ROUTER_R0080({ text: "" + text });
	}
	return "" + text;
}
//#endregion
//#region src/location.ts
const TRAILING_SLASH_RE = /\/$/;
const removeTrailingSlash = (path) => path.replace(TRAILING_SLASH_RE, "");
/**
* Transforms a URI into a normalized history location
*
* @param parseQuery
* @param location - URI to normalize
* @param currentLocation - current absolute location. Allows resolving relative
* paths. Must start with `/`. Defaults to `/`
* @returns a normalized history location
*/
function parseURL(parseQuery, location, currentLocation = "/") {
	let path, query = {}, searchString = "", hash = "";
	const hashPos = location.indexOf("#");
	let searchPos = location.indexOf("?");
	searchPos = hashPos >= 0 && searchPos > hashPos ? -1 : searchPos;
	if (searchPos >= 0) {
		path = location.slice(0, searchPos);
		searchString = location.slice(searchPos, hashPos > 0 ? hashPos : location.length);
		query = parseQuery(searchString.slice(1));
	}
	if (hashPos >= 0) {
		path = path || location.slice(0, hashPos);
		hash = location.slice(hashPos, location.length);
	}
	path = resolveRelativePath(path != null ? path : location, currentLocation);
	return {
		fullPath: path + searchString + hash,
		path,
		query,
		hash: decode(hash)
	};
}
function NEW_stringifyURL(stringifyQuery, path, query, hash = "") {
	const searchText = stringifyQuery(query);
	return path + (searchText && "?") + searchText + encodeHash(hash);
}
/**
* Stringifies a URL object
*
* @param stringifyQuery
* @param location
*/
function stringifyURL(stringifyQuery, location) {
	const query = location.query ? stringifyQuery(location.query) : "";
	return location.path + (query && "?") + query + (location.hash || "");
}
/**
* Strips off the base from the beginning of a location.pathname in a non-case-sensitive way.
*
* @param pathname - location.pathname
* @param base - base to strip off
*/
function stripBase(pathname, base) {
	if (!base || !pathname.toLowerCase().startsWith(base.toLowerCase())) return pathname;
	return pathname.slice(base.length) || "/";
}
/**
* Checks if two RouteLocation are equal. This means that both locations are
* pointing towards the same {@link RouteRecord} and that all `params`, `query`
* parameters and `hash` are the same
*
* @param stringifyQuery - A function that takes a query object of type LocationQueryRaw and returns a string representation of it.
* @param a - first {@link RouteLocation}
* @param b - second {@link RouteLocation}
*/
function isSameRouteLocation(stringifyQuery, a, b) {
	const aLastIndex = a.matched.length - 1;
	const bLastIndex = b.matched.length - 1;
	return aLastIndex > -1 && aLastIndex === bLastIndex && isSameRouteRecord(a.matched[aLastIndex], b.matched[bLastIndex]) && isSameRouteLocationParams(a.params, b.params) && stringifyQuery(a.query) === stringifyQuery(b.query) && a.hash === b.hash;
}
/**
* Check if two `RouteRecords` are equal. Takes into account aliases: they are
* considered equal to the `RouteRecord` they are aliasing.
*
* @param a - first {@link RouteRecord}
* @param b - second {@link RouteRecord}
*/
function isSameRouteRecord(a, b) {
	return (a.aliasOf || a) === (b.aliasOf || b);
}
function isSameRouteLocationParams(a, b) {
	if (Object.keys(a).length !== Object.keys(b).length) return false;
	for (var key in a) if (!isSameRouteLocationParamsValue(a[key], b[key])) return false;
	return true;
}
function isSameRouteLocationParamsValue(a, b) {
	return isArray(a) ? isEquivalentArray(a, b) : isArray(b) ? isEquivalentArray(b, a) : (a && a.valueOf()) === (b && b.valueOf());
}
/**
* Check if two arrays are the same or if an array with one single entry is the
* same as another primitive value. Used to check query and parameters
*
* @param a - array of values
* @param b - array of values or a single value
*/
function isEquivalentArray(a, b) {
	return isArray(b) ? a.length === b.length && a.every((value, i) => value === b[i]) : a.length === 1 && a[0] === b;
}
/**
* Resolves a relative path that starts with `.`.
*
* @param to - path location we are resolving
* @param from - currentLocation.path, should start with `/`
*/
function resolveRelativePath(to, from) {
	if (to.startsWith("/")) return to;
	if ("development" !== "production" && !from.startsWith("/")) {
		diagnostics.VUE_ROUTER_R0070({
			to,
			from
		});
		return to;
	}
	if (!to) return from;
	const fromSegments = from.split("/");
	const toSegments = to.split("/");
	const lastToSegment = toSegments[toSegments.length - 1];
	if (lastToSegment === ".." || lastToSegment === ".") toSegments.push("");
	let position = fromSegments.length - 1;
	let toPosition;
	let segment;
	for (toPosition = 0; toPosition < toSegments.length; toPosition++) {
		segment = toSegments[toPosition];
		if (segment === ".") continue;
		if (segment === "..") {
			if (position > 1) position--;
		} else break;
	}
	return fromSegments.slice(0, position).join("/") + "/" + toSegments.slice(toPosition).join("/");
}
/**
* Initial route location where the router is. Can be used in navigation guards
* to differentiate the initial navigation.
*
* @example
* ```js
* import { START_LOCATION } from 'vue-router'
*
* router.beforeEach((to, from) => {
*   if (from === START_LOCATION) {
*     // initial navigation
*   }
* })
* ```
*/
const START_LOCATION_NORMALIZED = {
	path: "/",
	name: void 0,
	params: {},
	query: {},
	hash: "",
	fullPath: "/",
	matched: [],
	meta: {},
	redirectedFrom: void 0
};
//#endregion
//#region src/history/common.ts
/**
* Normalizes a base by removing any trailing slash and reading the base tag if
* present.
*
* @param base - base to normalize
*/
function normalizeBase(base) {
	if (!base) if (isBrowser) {
		const baseEl = document.querySelector("base");
		base = baseEl && baseEl.getAttribute("href") || "/";
		base = base.replace(/^\w+:\/\/[^/]+/, "");
	} else base = "/";
	if (base[0] !== "/" && base[0] !== "#") base = "/" + base;
	return removeTrailingSlash(base);
}
const BEFORE_HASH_RE = /^[^#]+#/;
function createHref(base, location) {
	return base.replace(BEFORE_HASH_RE, "#") + location;
}
//#endregion
//#region src/scrollBehavior.ts
function getElementPosition(el, offset) {
	const docRect = document.documentElement.getBoundingClientRect();
	const elRect = el.getBoundingClientRect();
	return {
		behavior: offset.behavior,
		left: elRect.left - docRect.left - (offset.left || 0),
		top: elRect.top - docRect.top - (offset.top || 0)
	};
}
const computeScrollPosition = () => ({
	left: window.scrollX,
	top: window.scrollY
});
function scrollToPosition(position) {
	let scrollToOptions;
	if ("el" in position) {
		const positionEl = position.el;
		const isIdSelector = typeof positionEl === "string" && positionEl.startsWith("#");
		/**
		* `id`s can accept pretty much any characters, including CSS combinators
		* like `>` or `~`. It's still possible to retrieve elements using
		* `document.getElementById('~')` but it needs to be escaped when using
		* `document.querySelector('#\\~')` for it to be valid. The only
		* requirements for `id`s are them to be unique on the page and to not be
		* empty (`id=""`). Because of that, when passing an id selector, it should
		* be properly escaped for it to work with `querySelector`. We could check
		* for the id selector to be simple (no CSS combinators `+ >~`) but that
		* would make things inconsistent since they are valid characters for an
		* `id` but would need to be escaped when using `querySelector`, breaking
		* their usage and ending up in no selector returned. Selectors need to be
		* escaped:
		*
		* - `#1-thing` becomes `#\31 -thing`
		* - `#with~symbols` becomes `#with\\~symbols`
		*
		* - More information about  the topic can be found at
		*   https://mathiasbynens.be/notes/html5-id-class.
		* - Practical example: https://mathiasbynens.be/demo/html5-id
		*/
		if ("development" !== "production" && typeof position.el === "string") {
			if (!isIdSelector || !document.getElementById(position.el.slice(1))) try {
				const foundEl = document.querySelector(position.el);
				if (isIdSelector && foundEl) {
					diagnostics.VUE_ROUTER_R0040({ el: position.el });
					return;
				}
			} catch {
				diagnostics.VUE_ROUTER_R0041({ el: position.el });
				return;
			}
		}
		const el = typeof positionEl === "string" ? isIdSelector ? document.getElementById(positionEl.slice(1)) : document.querySelector(positionEl) : positionEl;
		if (!el) {
			"development" !== "production" && diagnostics.VUE_ROUTER_R0042({ el: position.el });
			return;
		}
		scrollToOptions = getElementPosition(el, position);
	} else scrollToOptions = position;
	if ("scrollBehavior" in document.documentElement.style) window.scrollTo(scrollToOptions);
	else window.scrollTo(scrollToOptions.left != null ? scrollToOptions.left : window.scrollX, scrollToOptions.top != null ? scrollToOptions.top : window.scrollY);
}
function getScrollKey(path, delta) {
	return (history.state ? history.state.position - delta : -1) + path;
}
const scrollPositions = /* @__PURE__ */ new Map();
function saveScrollPosition(key, scrollPosition) {
	scrollPositions.set(key, scrollPosition);
}
function getSavedScrollPosition(key) {
	const scroll = scrollPositions.get(key);
	scrollPositions.delete(key);
	return scroll;
}
/**
* ScrollBehavior instance used by the router to compute and restore the scroll
* position when navigating.
*/
//#endregion
//#region src/types/typeGuards.ts
function isRouteLocation(route) {
	return typeof route === "string" || route && typeof route === "object";
}
function isRouteName(name) {
	return typeof name === "string" || typeof name === "symbol";
}
//#endregion
//#region src/query.ts
/**
* Transforms a queryString into a {@link LocationQuery} object. Accept both, a
* version with the leading `?` and without Should work as URLSearchParams

* @internal
*
* @param search - search string to parse
* @returns a query object
*/
function parseQuery(search) {
	const query = {};
	if (search === "" || search === "?") return query;
	const searchParams = (search[0] === "?" ? search.slice(1) : search).split("&");
	for (let i = 0; i < searchParams.length; ++i) {
		const searchParam = searchParams[i].replace(PLUS_RE, " ");
		const eqPos = searchParam.indexOf("=");
		const key = decode(eqPos < 0 ? searchParam : searchParam.slice(0, eqPos));
		const value = eqPos < 0 ? null : decode(searchParam.slice(eqPos + 1));
		if (key in query) {
			let currentValue = query[key];
			if (!isArray(currentValue)) currentValue = query[key] = [currentValue];
			currentValue.push(value);
		} else query[key] = value;
	}
	return query;
}
/**
* Stringifies a {@link LocationQueryRaw} object. Like `URLSearchParams`, it
* doesn't prepend a `?`
*
* @internal
*
* @param query - query object to stringify
* @returns string version of the query without the leading `?`
*/
function stringifyQuery(query) {
	let search = "";
	for (let key in query) {
		const value = query[key];
		key = encodeQueryKey(key);
		if (value == null) {
			if (value !== void 0) search += (search.length ? "&" : "") + key;
			continue;
		}
		(isArray(value) ? value.map((v) => v && encodeQueryValue(v)) : [value && encodeQueryValue(value)]).forEach((value) => {
			if (value !== void 0) {
				search += (search.length ? "&" : "") + key;
				if (value != null) search += "=" + value;
			}
		});
	}
	return search;
}
/**
* Transforms a {@link LocationQueryRaw} into a {@link LocationQuery} by casting
* numbers into strings, removing keys with an undefined value and replacing
* undefined with null in arrays
*
* @param query - query object to normalize
* @returns a normalized query object
*/
function normalizeQuery(query) {
	const normalizedQuery = {};
	for (const key in query) {
		const value = query[key];
		if (value !== void 0) normalizedQuery[key] = isArray(value) ? value.map((v) => v == null ? null : "" + v) : value == null ? value : "" + value;
	}
	return normalizedQuery;
}
//#endregion
//#region src/utils/callbacks.ts
/**
* Create a list of callbacks that can be reset. Used to create before and after navigation guards list
*/
function useCallbacks() {
	let handlers = [];
	function add(handler) {
		handlers.push(handler);
		return () => {
			const i = handlers.indexOf(handler);
			if (i > -1) handlers.splice(i, 1);
		};
	}
	function reset() {
		handlers = [];
	}
	return {
		add,
		list: () => handlers.slice(),
		reset
	};
}
//#endregion
//#region src/navigationGuards.ts
function registerGuard(activeRecordRef, name, guard) {
	const record = activeRecordRef.value;
	if (!record) {
		if ("development" !== "production") {
			const fnName = name === "updateGuards" ? "onBeforeRouteUpdate" : "onBeforeRouteLeave";
			diagnostics.VUE_ROUTER_R0020({ fn: fnName });
		}
		return;
	}
	let currentRecord = record;
	const removeFromList = () => {
		currentRecord[name].delete(guard);
	};
	onUnmounted(removeFromList);
	onDeactivated(removeFromList);
	onActivated(() => {
		const newRecord = activeRecordRef.value;
		if ("development" !== "production" && !newRecord) diagnostics.VUE_ROUTER_R0021();
		if (newRecord) currentRecord = newRecord;
		currentRecord[name].add(guard);
	});
	currentRecord[name].add(guard);
}
/**
* Add a navigation guard that triggers whenever the component for the current
* location is about to be left. Similar to {@link beforeRouteLeave} but can be
* used in any component. The guard is removed when the component is unmounted.
*
* @param leaveGuard - {@link NavigationGuard}
*/
function onBeforeRouteLeave(leaveGuard) {
	if ("development" !== "production" && !getCurrentInstance()) {
		diagnostics.VUE_ROUTER_R0022({ fn: "onBeforeRouteLeave" });
		return;
	}
	registerGuard(inject(matchedRouteKey, {}), "leaveGuards", leaveGuard);
}
/**
* Add a navigation guard that triggers whenever the current location is about
* to be updated. Similar to {@link beforeRouteUpdate} but can be used in any
* component. The guard is removed when the component is unmounted.
*
* @param updateGuard - {@link NavigationGuard}
*/
function onBeforeRouteUpdate(updateGuard) {
	if ("development" !== "production" && !getCurrentInstance()) {
		diagnostics.VUE_ROUTER_R0022({ fn: "onBeforeRouteUpdate" });
		return;
	}
	registerGuard(inject(matchedRouteKey, {}), "updateGuards", updateGuard);
}
function guardToPromiseFn(guard, to, from, record, name, runWithContext = (fn) => fn()) {
	const enterCallbackArray = record && (record.enterCallbacks[name] = record.enterCallbacks[name] || []);
	return () => new Promise((resolve, reject) => {
		const next = (valid) => {
			if (valid === false) reject(createRouterError(4, {
				from,
				to
			}));
			else if (valid instanceof Error) reject(valid);
			else if (isRouteLocation(valid)) reject(createRouterError(2, {
				from: to,
				to: valid
			}));
			else {
				if (enterCallbackArray && record.enterCallbacks[name] === enterCallbackArray && typeof valid === "function") enterCallbackArray.push(valid);
				resolve();
			}
		};
		const guardReturn = runWithContext(() => guard.call(record && record.instances[name], to, from, "development" !== "production" ? withDeprecationWarning(canOnlyBeCalledOnce(next, to, from)) : next));
		let guardCall = Promise.resolve(guardReturn);
		if (guard.length < 3) guardCall = guardCall.then(next);
		if ("development" !== "production" && guard.length > 2) {
			const guardInfo = {
				name: guard.name,
				guard: guard.toString()
			};
			if (typeof guardReturn === "object" && "then" in guardReturn) guardCall = guardCall.then((resolvedValue) => {
				if (!next._called) {
					diagnostics.VUE_ROUTER_R0023(guardInfo);
					return Promise.reject(/* @__PURE__ */ new Error("Invalid navigation guard"));
				}
				return resolvedValue;
			});
			else if (guardReturn !== void 0) {
				if (!next._called) {
					diagnostics.VUE_ROUTER_R0023(guardInfo);
					reject(/* @__PURE__ */ new Error("Invalid navigation guard"));
					return;
				}
			}
		}
		guardCall.catch((err) => reject(err));
	});
}
/**
* Wraps the next callback to warn when it is used. Dev-only: when __DEV__ is
* false (production builds), this branch is dead code and is stripped from the
* bundle.
*
* @internal
*/
function withDeprecationWarning(next) {
	let warned = false;
	return function() {
		if (!warned) {
			warned = true;
			diagnostics.VUE_ROUTER_R0025();
		}
		return next.apply(this, arguments);
	};
}
function canOnlyBeCalledOnce(next, to, from) {
	let called = 0;
	return function() {
		if (called++ === 1) diagnostics.VUE_ROUTER_R0024({
			from: from.fullPath,
			to: to.fullPath
		});
		next._called = true;
		if (called === 1) next.apply(null, arguments);
	};
}
function extractComponentsGuards(matched, guardType, to, from, runWithContext = (fn) => fn()) {
	const guards = [];
	for (const record of matched) {
		if ("development" !== "production" && !record.components && record.children && !record.children.length) diagnostics.VUE_ROUTER_R0026({ path: record.path });
		for (const name in record.components) {
			let rawComponent = record.components[name];
			if ("development" !== "production") {
				if (!rawComponent || typeof rawComponent !== "object" && typeof rawComponent !== "function") {
					diagnostics.VUE_ROUTER_R0027({
						name,
						path: record.path,
						received: String(rawComponent)
					});
					throw new Error("Invalid route component");
				} else if ("then" in rawComponent) {
					diagnostics.VUE_ROUTER_R0028({
						name,
						path: record.path
					});
					const promise = rawComponent;
					rawComponent = () => promise;
				} else if (rawComponent.__asyncLoader && !rawComponent.__warnedDefineAsync) {
					rawComponent.__warnedDefineAsync = true;
					diagnostics.VUE_ROUTER_R0029({
						name,
						path: record.path
					});
				}
			}
			if (guardType !== "beforeRouteEnter" && !record.instances[name]) continue;
			if (isRouteComponent(rawComponent)) {
				const guard = (rawComponent.__vccOpts || rawComponent)[guardType];
				guard && guards.push(guardToPromiseFn(guard, to, from, record, name, runWithContext));
			} else {
				let componentPromise = rawComponent();
				if ("development" !== "production" && !("catch" in componentPromise)) {
					diagnostics.VUE_ROUTER_R0030({
						name,
						path: record.path
					});
					componentPromise = Promise.resolve(componentPromise);
				}
				guards.push(() => componentPromise.then((resolved) => {
					if (!resolved) throw new Error(`Couldn't resolve component "${name}" at "${record.path}"`);
					const resolvedComponent = isESModule(resolved) ? resolved.default : resolved;
					record.mods[name] = resolved;
					record.components[name] = resolvedComponent;
					const guard = (resolvedComponent.__vccOpts || resolvedComponent)[guardType];
					return guard && guardToPromiseFn(guard, to, from, record, name, runWithContext)();
				}));
			}
		}
	}
	return guards;
}
/**
* Ensures a route is loaded, so it can be passed as o prop to `<RouterView>`.
*
* @param route - resolved route to load
*/
function loadRouteLocation(route) {
	return route.matched.every((record) => record.redirect) ? Promise.reject(/* @__PURE__ */ new Error("Cannot load a route that redirects.")) : Promise.all(route.matched.map((record) => record.components && Promise.all(Object.keys(record.components).reduce((promises, name) => {
		const rawComponent = record.components[name];
		if (typeof rawComponent === "function" && !("displayName" in rawComponent)) promises.push(rawComponent().then((resolved) => {
			if (!resolved) return Promise.reject(/* @__PURE__ */ new Error(`Couldn't resolve component "${name}" at "${record.path}". Ensure you passed a function that returns a promise.`));
			const resolvedComponent = isESModule(resolved) ? resolved.default : resolved;
			record.mods[name] = resolved;
			record.components[name] = resolvedComponent;
		}));
		return promises;
	}, [])))).then(() => route);
}
/**
* Split the leaving, updating, and entering records.
* @internal
*
* @param  to - Location we are navigating to
* @param from - Location we are navigating from
*/
function extractChangingRecords(to, from) {
	const leavingRecords = [];
	const updatingRecords = [];
	const enteringRecords = [];
	const len = Math.max(from.matched.length, to.matched.length);
	for (let i = 0; i < len; i++) {
		const recordFrom = from.matched[i];
		if (recordFrom) if (to.matched.find((record) => isSameRouteRecord(record, recordFrom))) updatingRecords.push(recordFrom);
		else leavingRecords.push(recordFrom);
		const recordTo = to.matched[i];
		if (recordTo) {
			if (!from.matched.find((record) => isSameRouteRecord(record, recordTo))) enteringRecords.push(recordTo);
		}
	}
	return [
		leavingRecords,
		updatingRecords,
		enteringRecords
	];
}
//#endregion
//#region src/devtools.ts
/**
* Copies a route location and removes any problematic properties that cannot be shown in devtools (e.g. Vue instances).
*
* @param routeLocation - routeLocation to format
* @param tooltip - optional tooltip
* @returns a copy of the routeLocation
*/
function formatRouteLocation(routeLocation, tooltip) {
	const copy = assign({}, routeLocation, { matched: routeLocation.matched.map((matched) => omit(matched, [
		"instances",
		"children",
		"aliasOf"
	])) });
	return { _custom: {
		type: null,
		readOnly: true,
		display: routeLocation.fullPath,
		tooltip,
		value: copy
	} };
}
function formatDisplay(display) {
	return { _custom: { display } };
}
let routerId = 0;
function addDevtools(app, router, matcher) {
	if (router.__hasDevtools) return;
	router.__hasDevtools = true;
	const id = routerId++;
	setupDevtoolsPlugin({
		id: "org.vuejs.router" + (id ? "." + id : ""),
		label: "Vue Router",
		packageName: "vue-router",
		homepage: "https://router.vuejs.org",
		logo: "https://router.vuejs.org/logo.png",
		componentStateTypes: ["Routing"],
		app
	}, (api) => {
		api.on.inspectComponent((payload) => {
			if (payload.instanceData) payload.instanceData.state.push({
				type: "Routing",
				key: "$route",
				editable: false,
				value: formatRouteLocation(router.currentRoute.value, "Current Route")
			});
		});
		api.on.visitComponentTree(({ treeNode: node, componentInstance }) => {
			if (componentInstance.__vrv_devtools) {
				const info = componentInstance.__vrv_devtools;
				node.tags.push({
					label: (info.name ? `${info.name.toString()}: ` : "") + info.path,
					textColor: 0,
					tooltip: "This component is rendered by &lt;router-view&gt;",
					backgroundColor: PINK_500
				});
			}
			if (isArray(componentInstance.__vrl_devtools)) {
				componentInstance.__devtoolsApi = api;
				componentInstance.__vrl_devtools.forEach((devtoolsData) => {
					let label = devtoolsData.route.path;
					let backgroundColor = ORANGE_400;
					let tooltip = "";
					let textColor = 0;
					if (devtoolsData.error) {
						label = devtoolsData.error;
						backgroundColor = RED_100;
						textColor = RED_700;
					} else if (devtoolsData.isExactActive) {
						backgroundColor = LIME_500;
						tooltip = "This is exactly active";
					} else if (devtoolsData.isActive) {
						backgroundColor = BLUE_600;
						tooltip = "This link is active";
					}
					node.tags.push({
						label,
						textColor,
						tooltip,
						backgroundColor
					});
				});
			}
		});
		watch(router.currentRoute, () => {
			refreshRoutesView();
			api.notifyComponentUpdate();
			api.sendInspectorTree(routerInspectorId);
			api.sendInspectorState(routerInspectorId);
		});
		const navigationsLayerId = "router:navigations:" + id;
		api.addTimelineLayer({
			id: navigationsLayerId,
			label: `Router${id ? " " + id : ""} Navigations`,
			color: 4237508
		});
		router.onError((error, to) => {
			api.addTimelineEvent({
				layerId: navigationsLayerId,
				event: {
					title: "Error during Navigation",
					subtitle: to.fullPath,
					logType: "error",
					time: api.now(),
					data: { error },
					groupId: to.meta.__navigationId
				}
			});
		});
		let navigationId = 0;
		router.beforeEach((to, from) => {
			const data = {
				guard: formatDisplay("beforeEach"),
				from: formatRouteLocation(from, "Current Location during this navigation"),
				to: formatRouteLocation(to, "Target location")
			};
			Object.defineProperty(to.meta, "__navigationId", { value: navigationId++ });
			api.addTimelineEvent({
				layerId: navigationsLayerId,
				event: {
					time: api.now(),
					title: "Start of navigation",
					subtitle: to.fullPath,
					data,
					groupId: to.meta.__navigationId
				}
			});
		});
		router.afterEach((to, from, failure) => {
			const data = { guard: formatDisplay("afterEach") };
			if (failure) {
				data.failure = { _custom: {
					type: Error,
					readOnly: true,
					display: failure ? failure.message : "",
					tooltip: "Navigation Failure",
					value: failure
				} };
				data.status = formatDisplay("❌");
			} else data.status = formatDisplay("✅");
			data.from = formatRouteLocation(from, "Current Location during this navigation");
			data.to = formatRouteLocation(to, "Target location");
			api.addTimelineEvent({
				layerId: navigationsLayerId,
				event: {
					title: "End of navigation",
					subtitle: to.fullPath,
					time: api.now(),
					data,
					logType: failure ? "warning" : "default",
					groupId: to.meta.__navigationId
				}
			});
		});
		/**
		* Inspector of Existing routes
		*/
		const routerInspectorId = "router-inspector:" + id;
		api.addInspector({
			id: routerInspectorId,
			label: "Routes" + (id ? " " + id : ""),
			icon: "book",
			treeFilterPlaceholder: "Search routes"
		});
		function refreshRoutesView() {
			if (!activeRoutesPayload) return;
			const payload = activeRoutesPayload;
			let routes = matcher.getRoutes().filter((route) => !route.parent || !route.parent.record.components);
			routes.forEach(resetMatchStateOnRouteRecord);
			if (payload.filter) routes = routes.filter((route) => isRouteMatching(route, payload.filter.toLowerCase()));
			routes.forEach((route) => markRouteRecordActive(route, router.currentRoute.value));
			payload.rootNodes = routes.map(formatRouteRecordForInspector);
		}
		let activeRoutesPayload;
		api.on.getInspectorTree((payload) => {
			activeRoutesPayload = payload;
			if (payload.app === app && payload.inspectorId === routerInspectorId) refreshRoutesView();
		});
		/**
		* Display information about the currently selected route record
		*/
		api.on.getInspectorState((payload) => {
			if (payload.app === app && payload.inspectorId === routerInspectorId) {
				const route = matcher.getRoutes().find((route) => route.record.__vd_id === payload.nodeId);
				if (route) payload.state = { options: formatRouteRecordMatcherForStateInspector(route) };
			}
		});
		api.sendInspectorTree(routerInspectorId);
		api.sendInspectorState(routerInspectorId);
	});
}
function modifierForKey(key) {
	if (key.optional) return key.repeatable ? "*" : "?";
	else return key.repeatable ? "+" : "";
}
function formatRouteRecordMatcherForStateInspector(route) {
	const { record } = route;
	const fields = [{
		editable: false,
		key: "path",
		value: record.path
	}];
	if (record.name != null) fields.push({
		editable: false,
		key: "name",
		value: record.name
	});
	fields.push({
		editable: false,
		key: "regexp",
		value: route.re
	});
	if (route.keys.length) fields.push({
		editable: false,
		key: "keys",
		value: { _custom: {
			type: null,
			readOnly: true,
			display: route.keys.map((key) => `${key.name}${modifierForKey(key)}`).join(" "),
			tooltip: "Param keys",
			value: route.keys
		} }
	});
	if (record.redirect != null) fields.push({
		editable: false,
		key: "redirect",
		value: record.redirect
	});
	if (route.alias.length) fields.push({
		editable: false,
		key: "aliases",
		value: route.alias.map((alias) => alias.record.path)
	});
	if (Object.keys(route.record.meta).length) fields.push({
		editable: false,
		key: "meta",
		value: route.record.meta
	});
	fields.push({
		key: "score",
		editable: false,
		value: { _custom: {
			type: null,
			readOnly: true,
			display: route.score.map((score) => score.join(", ")).join(" | "),
			tooltip: "Score used to sort routes",
			value: route.score
		} }
	});
	return fields;
}
/**
* Extracted from tailwind palette
*/
const PINK_500 = 15485081;
const BLUE_600 = 2450411;
const LIME_500 = 8702998;
const CYAN_400 = 2282478;
const ORANGE_400 = 16486972;
const DARK = 6710886;
const RED_100 = 16704226;
const RED_700 = 12131356;
function formatRouteRecordForInspector(route) {
	const tags = [];
	const { record } = route;
	if (record.name != null) tags.push({
		label: String(record.name),
		textColor: 0,
		backgroundColor: CYAN_400
	});
	if (record.aliasOf) tags.push({
		label: "alias",
		textColor: 0,
		backgroundColor: ORANGE_400
	});
	if (route.__vd_match) tags.push({
		label: "matches",
		textColor: 0,
		backgroundColor: PINK_500
	});
	if (route.__vd_exactActive) tags.push({
		label: "exact",
		textColor: 0,
		backgroundColor: LIME_500
	});
	if (route.__vd_active) tags.push({
		label: "active",
		textColor: 0,
		backgroundColor: BLUE_600
	});
	if (record.redirect) tags.push({
		label: typeof record.redirect === "string" ? `redirect: ${record.redirect}` : "redirects",
		textColor: 16777215,
		backgroundColor: DARK
	});
	let id = record.__vd_id;
	if (id == null) {
		id = String(routeRecordId++);
		record.__vd_id = id;
	}
	return {
		id,
		label: record.path,
		tags,
		children: route.children.map(formatRouteRecordForInspector)
	};
}
let routeRecordId = 0;
const EXTRACT_REGEXP_RE = /^\/(.*)\/([a-z]*)$/;
function markRouteRecordActive(route, currentRoute) {
	const isExactActive = currentRoute.matched.length && isSameRouteRecord(currentRoute.matched[currentRoute.matched.length - 1], route.record);
	route.__vd_exactActive = route.__vd_active = isExactActive;
	if (!isExactActive) route.__vd_active = currentRoute.matched.some((match) => isSameRouteRecord(match, route.record));
	route.children.forEach((childRoute) => markRouteRecordActive(childRoute, currentRoute));
}
function resetMatchStateOnRouteRecord(route) {
	route.__vd_match = false;
	route.children.forEach(resetMatchStateOnRouteRecord);
}
function isRouteMatching(route, filter) {
	const found = String(route.re).match(EXTRACT_REGEXP_RE);
	route.__vd_match = false;
	if (!found || found.length < 3) return false;
	if (new RegExp(found[1].replace(/\$$/, ""), found[2]).test(filter)) {
		route.children.forEach((child) => isRouteMatching(child, filter));
		if (route.record.path !== "/" || filter === "/") {
			route.__vd_match = route.re.test(filter);
			return true;
		}
		return false;
	}
	const path = route.record.path.toLowerCase();
	const decodedPath = decode(path);
	if (!filter.startsWith("/") && (decodedPath.includes(filter) || path.includes(filter))) return true;
	if (decodedPath.startsWith(filter) || path.startsWith(filter)) return true;
	if (route.record.name && String(route.record.name).includes(filter)) return true;
	return route.children.some((child) => isRouteMatching(child, filter));
}
function omit(obj, keys) {
	const ret = {};
	for (const key in obj) if (!keys.includes(key)) ret[key] = obj[key];
	return ret;
}
//#endregion
export { PLUS_RE as A, isSameRouteLocation as C, resolveRelativePath as D, parseURL as E, isBrowser as F, encodeHash as M, encodeParam as N, stringifyURL as O, encodePath as P, START_LOCATION_NORMALIZED as S, isSameRouteRecord as T, saveScrollPosition as _, loadRouteLocation as a, normalizeBase as b, useCallbacks as c, stringifyQuery as d, isRouteLocation as f, getScrollKey as g, getSavedScrollPosition as h, guardToPromiseFn as i, decode as j, stripBase as k, normalizeQuery as l, computeScrollPosition as m, extractChangingRecords as n, onBeforeRouteLeave as o, isRouteName as p, extractComponentsGuards as r, onBeforeRouteUpdate as s, addDevtools as t, parseQuery as u, scrollToPosition as v, isSameRouteLocationParams as w, NEW_stringifyURL as x, createHref as y };

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7Ozs7QUFLQSxTQUFTLEtBQUssa0JBQWtCLEtBQUssYUFBYSxLQUFLLFlBQVksS0FBSyxTQUFTLEtBQUssUUFBUSxLQUFLLGlCQUFpQixLQUFLLHlCQUF5QjtBQUNsSixTQUFTLG9CQUFvQixRQUFRLGFBQWEsZUFBZSxhQUFhLGFBQWE7QUFDM0YsU0FBUywyQkFBMkI7O0FBRXBDLE1BQU0sWUFBWSxPQUFPLGFBQWE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBb0J0QyxNQUFNLFVBQVU7QUFDaEIsTUFBTSxlQUFlO0FBQ3JCLE1BQU0sV0FBVztBQUNqQixNQUFNLFdBQVc7QUFDakIsTUFBTSxRQUFRO0FBQ2QsTUFBTSxVQUFVOzs7Ozs7Ozs7Ozs7Ozs7QUFlaEIsTUFBTSxzQkFBc0I7QUFDNUIsTUFBTSx1QkFBdUI7QUFDN0IsTUFBTSxlQUFlO0FBQ3JCLE1BQU0sa0JBQWtCO0FBQ3hCLE1BQU0sb0JBQW9CO0FBQzFCLE1BQU0sY0FBYztBQUNwQixNQUFNLHFCQUFxQjtBQUMzQixNQUFNLGVBQWU7Ozs7Ozs7OztBQVNyQixTQUFTLGFBQWEsTUFBTTtDQUMzQixPQUFPLFFBQVEsT0FBTyxLQUFLLFVBQVUsS0FBSyxJQUFJLENBQUMsQ0FBQyxRQUFRLGFBQWEsR0FBRyxDQUFDLENBQUMsUUFBUSxxQkFBcUIsR0FBRyxDQUFDLENBQUMsUUFBUSxzQkFBc0IsR0FBRztBQUM5STs7Ozs7OztBQU9BLFNBQVMsV0FBVyxNQUFNO0NBQ3pCLE9BQU8sYUFBYSxJQUFJLENBQUMsQ0FBQyxRQUFRLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxRQUFRLG9CQUFvQixHQUFHLENBQUMsQ0FBQyxRQUFRLGNBQWMsR0FBRztBQUNySDs7Ozs7Ozs7QUFRQSxTQUFTLGlCQUFpQixNQUFNO0NBQy9CLE9BQU8sYUFBYSxJQUFJLENBQUMsQ0FBQyxRQUFRLFNBQVMsS0FBSyxDQUFDLENBQUMsUUFBUSxjQUFjLEdBQUcsQ0FBQyxDQUFDLFFBQVEsU0FBUyxLQUFLLENBQUMsQ0FBQyxRQUFRLGNBQWMsS0FBSyxDQUFDLENBQUMsUUFBUSxpQkFBaUIsR0FBRyxDQUFDLENBQUMsUUFBUSxtQkFBbUIsR0FBRyxDQUFDLENBQUMsUUFBUSxvQkFBb0IsR0FBRyxDQUFDLENBQUMsUUFBUSxjQUFjLEdBQUc7QUFDM1A7Ozs7OztBQU1BLFNBQVMsZUFBZSxNQUFNO0NBQzdCLE9BQU8saUJBQWlCLElBQUksQ0FBQyxDQUFDLFFBQVEsVUFBVSxLQUFLO0FBQ3REOzs7Ozs7O0FBT0EsU0FBUyxXQUFXLE1BQU07Q0FDekIsT0FBTyxhQUFhLElBQUksQ0FBQyxDQUFDLFFBQVEsU0FBUyxLQUFLLENBQUMsQ0FBQyxRQUFRLE9BQU8sS0FBSztBQUN2RTs7Ozs7Ozs7OztBQVVBLFNBQVMsWUFBWSxNQUFNO0NBQzFCLE9BQU8sV0FBVyxJQUFJLENBQUMsQ0FBQyxRQUFRLFVBQVUsS0FBSztBQUNoRDtBQUNBLFNBQVMsT0FBTyxNQUFNO0NBQ3JCLElBQUksUUFBUSxNQUFNLE9BQU87Q0FDekIsSUFBSTtFQUNILE9BQU8sbUJBQW1CLEtBQUssSUFBSTtDQUNwQyxRQUFRO0VBQ1Asa0JBQXlCLGdCQUFnQixZQUFZLGlCQUFpQixFQUFFLE1BQU0sS0FBSyxLQUFLLENBQUM7Q0FDMUY7Q0FDQSxPQUFPLEtBQUs7QUFDYjs7O0FBR0EsTUFBTSxvQkFBb0I7QUFDMUIsTUFBTSx1QkFBdUIsU0FBUyxLQUFLLFFBQVEsbUJBQW1CLEVBQUU7Ozs7Ozs7Ozs7QUFVeEUsU0FBUyxTQUFTLFlBQVksVUFBVSxrQkFBa0IsS0FBSztDQUM5RCxJQUFJLE1BQU0sUUFBUSxDQUFDLEdBQUcsZUFBZSxJQUFJLE9BQU87Q0FDaEQsTUFBTSxVQUFVLFNBQVMsUUFBUSxHQUFHO0NBQ3BDLElBQUksWUFBWSxTQUFTLFFBQVEsR0FBRztDQUNwQyxZQUFZLFdBQVcsS0FBSyxZQUFZLFVBQVUsQ0FBQyxJQUFJO0NBQ3ZELElBQUksYUFBYSxHQUFHO0VBQ25CLE9BQU8sU0FBUyxNQUFNLEdBQUcsU0FBUztFQUNsQyxlQUFlLFNBQVMsTUFBTSxXQUFXLFVBQVUsSUFBSSxVQUFVLFNBQVMsTUFBTTtFQUNoRixRQUFRLFdBQVcsYUFBYSxNQUFNLENBQUMsQ0FBQztDQUN6QztDQUNBLElBQUksV0FBVyxHQUFHO0VBQ2pCLE9BQU8sUUFBUSxTQUFTLE1BQU0sR0FBRyxPQUFPO0VBQ3hDLE9BQU8sU0FBUyxNQUFNLFNBQVMsU0FBUyxNQUFNO0NBQy9DO0NBQ0EsT0FBTyxvQkFBb0IsUUFBUSxPQUFPLE9BQU8sVUFBVSxlQUFlO0NBQzFFLE9BQU87RUFDTixVQUFVLE9BQU8sZUFBZTtFQUNoQztFQUNBO0VBQ0EsTUFBTSxPQUFPLElBQUk7Q0FDbEI7QUFDRDtBQUNBLFNBQVMsaUJBQWlCLGdCQUFnQixNQUFNLE9BQU8sT0FBTyxJQUFJO0NBQ2pFLE1BQU0sYUFBYSxlQUFlLEtBQUs7Q0FDdkMsT0FBTyxRQUFRLGNBQWMsT0FBTyxhQUFhLFdBQVcsSUFBSTtBQUNqRTs7Ozs7OztBQU9BLFNBQVMsYUFBYSxnQkFBZ0IsVUFBVTtDQUMvQyxNQUFNLFFBQVEsU0FBUyxRQUFRLGVBQWUsU0FBUyxLQUFLLElBQUk7Q0FDaEUsT0FBTyxTQUFTLFFBQVEsU0FBUyxPQUFPLFNBQVMsU0FBUyxRQUFRO0FBQ25FOzs7Ozs7O0FBT0EsU0FBUyxVQUFVLFVBQVUsTUFBTTtDQUNsQyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsWUFBWSxDQUFDLENBQUMsV0FBVyxLQUFLLFlBQVksQ0FBQyxHQUFHLE9BQU87Q0FDNUUsT0FBTyxTQUFTLE1BQU0sS0FBSyxNQUFNLEtBQUs7QUFDdkM7Ozs7Ozs7Ozs7QUFVQSxTQUFTLG9CQUFvQixnQkFBZ0IsR0FBRyxHQUFHO0NBQ2xELE1BQU0sYUFBYSxFQUFFLFFBQVEsU0FBUztDQUN0QyxNQUFNLGFBQWEsRUFBRSxRQUFRLFNBQVM7Q0FDdEMsT0FBTyxhQUFhLENBQUMsS0FBSyxlQUFlLGNBQWMsa0JBQWtCLEVBQUUsUUFBUSxhQUFhLEVBQUUsUUFBUSxXQUFXLEtBQUssMEJBQTBCLEVBQUUsUUFBUSxFQUFFLE1BQU0sS0FBSyxlQUFlLEVBQUUsS0FBSyxNQUFNLGVBQWUsRUFBRSxLQUFLLEtBQUssRUFBRSxTQUFTLEVBQUU7QUFDaFA7Ozs7Ozs7O0FBUUEsU0FBUyxrQkFBa0IsR0FBRyxHQUFHO0NBQ2hDLFFBQVEsRUFBRSxXQUFXLFFBQVEsRUFBRSxXQUFXO0FBQzNDO0FBQ0EsU0FBUywwQkFBMEIsR0FBRyxHQUFHO0NBQ3hDLElBQUksT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLFdBQVcsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsT0FBTztDQUM1RCxLQUFLLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQywrQkFBK0IsRUFBRSxNQUFNLEVBQUUsSUFBSSxHQUFHLE9BQU87Q0FDL0UsT0FBTztBQUNSO0FBQ0EsU0FBUywrQkFBK0IsR0FBRyxHQUFHO0NBQzdDLE9BQU8sUUFBUSxDQUFDLElBQUksa0JBQWtCLEdBQUcsQ0FBQyxJQUFJLFFBQVEsQ0FBQyxJQUFJLGtCQUFrQixHQUFHLENBQUMsS0FBSyxLQUFLLEVBQUUsUUFBUSxRQUFRLEtBQUssRUFBRSxRQUFRO0FBQzdIOzs7Ozs7OztBQVFBLFNBQVMsa0JBQWtCLEdBQUcsR0FBRztDQUNoQyxPQUFPLFFBQVEsQ0FBQyxJQUFJLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxPQUFPLE9BQU8sTUFBTSxVQUFVLEVBQUUsRUFBRSxJQUFJLEVBQUUsV0FBVyxLQUFLLEVBQUUsT0FBTztBQUNqSDs7Ozs7OztBQU9BLFNBQVMsb0JBQW9CLElBQUksTUFBTTtDQUN0QyxJQUFJLEdBQUcsV0FBVyxHQUFHLEdBQUcsT0FBTztDQUMvQixzQkFBNkIsZ0JBQWdCLENBQUMsS0FBSyxXQUFXLEdBQUcsR0FBRztFQUNuRSxZQUFZLGlCQUFpQjtHQUM1QjtHQUNBO0VBQ0QsQ0FBQztFQUNELE9BQU87Q0FDUjtDQUNBLElBQUksQ0FBQyxJQUFJLE9BQU87Q0FDaEIsTUFBTSxlQUFlLEtBQUssTUFBTSxHQUFHO0NBQ25DLE1BQU0sYUFBYSxHQUFHLE1BQU0sR0FBRztDQUMvQixNQUFNLGdCQUFnQixXQUFXLFdBQVcsU0FBUztDQUNyRCxJQUFJLGtCQUFrQixRQUFRLGtCQUFrQixLQUFLLFdBQVcsS0FBSyxFQUFFO0NBQ3ZFLElBQUksV0FBVyxhQUFhLFNBQVM7Q0FDckMsSUFBSTtDQUNKLElBQUk7Q0FDSixLQUFLLGFBQWEsR0FBRyxhQUFhLFdBQVcsUUFBUSxjQUFjO0VBQ2xFLFVBQVUsV0FBVztFQUNyQixJQUFJLFlBQVksS0FBSztFQUNyQixJQUFJLFlBQVksTUFBTTtHQUNyQixJQUFJLFdBQVcsR0FBRztFQUNuQixPQUFPO0NBQ1I7Q0FDQSxPQUFPLGFBQWEsTUFBTSxHQUFHLFFBQVEsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLE1BQU0sV0FBVyxNQUFNLFVBQVUsQ0FBQyxDQUFDLEtBQUssR0FBRztBQUMvRjs7Ozs7Ozs7Ozs7Ozs7OztBQWdCQSxNQUFNLDRCQUE0QjtDQUNqQyxNQUFNO0NBQ04sTUFBTSxLQUFLO0NBQ1gsUUFBUSxDQUFDO0NBQ1QsT0FBTyxDQUFDO0NBQ1IsTUFBTTtDQUNOLFVBQVU7Q0FDVixTQUFTLENBQUM7Q0FDVixNQUFNLENBQUM7Q0FDUCxnQkFBZ0IsS0FBSztBQUN0Qjs7Ozs7Ozs7O0FBU0EsU0FBUyxjQUFjLE1BQU07Q0FDNUIsSUFBSSxDQUFDLE1BQU0sSUFBSSxXQUFXO0VBQ3pCLE1BQU0sU0FBUyxTQUFTLGNBQWMsTUFBTTtFQUM1QyxPQUFPLFVBQVUsT0FBTyxhQUFhLE1BQU0sS0FBSztFQUNoRCxPQUFPLEtBQUssUUFBUSxrQkFBa0IsRUFBRTtDQUN6QyxPQUFPLE9BQU87Q0FDZCxJQUFJLEtBQUssT0FBTyxPQUFPLEtBQUssT0FBTyxLQUFLLE9BQU8sTUFBTTtDQUNyRCxPQUFPLG9CQUFvQixJQUFJO0FBQ2hDO0FBQ0EsTUFBTSxpQkFBaUI7QUFDdkIsU0FBUyxXQUFXLE1BQU0sVUFBVTtDQUNuQyxPQUFPLEtBQUssUUFBUSxnQkFBZ0IsR0FBRyxJQUFJO0FBQzVDOzs7QUFHQSxTQUFTLG1CQUFtQixJQUFJLFFBQVE7Q0FDdkMsTUFBTSxVQUFVLFNBQVMsZ0JBQWdCLHNCQUFzQjtDQUMvRCxNQUFNLFNBQVMsR0FBRyxzQkFBc0I7Q0FDeEMsT0FBTztFQUNOLFVBQVUsT0FBTztFQUNqQixNQUFNLE9BQU8sT0FBTyxRQUFRLFFBQVEsT0FBTyxRQUFRO0VBQ25ELEtBQUssT0FBTyxNQUFNLFFBQVEsT0FBTyxPQUFPLE9BQU87Q0FDaEQ7QUFDRDtBQUNBLE1BQU0sK0JBQStCO0NBQ3BDLE1BQU0sT0FBTztDQUNiLEtBQUssT0FBTztBQUNiO0FBQ0EsU0FBUyxpQkFBaUIsVUFBVTtDQUNuQyxJQUFJO0NBQ0osSUFBSSxRQUFRLFVBQVU7RUFDckIsTUFBTSxhQUFhLFNBQVM7RUFDNUIsTUFBTSxlQUFlLE9BQU8sZUFBZSxZQUFZLFdBQVcsV0FBVyxHQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0VBc0JoRixzQkFBNkIsZ0JBQWdCLE9BQU8sU0FBUyxPQUFPLFVBQVU7R0FDN0UsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsZUFBZSxTQUFTLEdBQUcsTUFBTSxDQUFDLENBQUMsR0FBRyxJQUFJO0lBQ3hFLE1BQU0sVUFBVSxTQUFTLGNBQWMsU0FBUyxFQUFFO0lBQ2xELElBQUksZ0JBQWdCLFNBQVM7S0FDNUIsWUFBWSxpQkFBaUIsRUFBRSxJQUFJLFNBQVMsR0FBRyxDQUFDO0tBQ2hEO0lBQ0Q7R0FDRCxRQUFRO0lBQ1AsWUFBWSxpQkFBaUIsRUFBRSxJQUFJLFNBQVMsR0FBRyxDQUFDO0lBQ2hEO0dBQ0Q7RUFDRDtFQUNBLE1BQU0sS0FBSyxPQUFPLGVBQWUsV0FBVyxlQUFlLFNBQVMsZUFBZSxXQUFXLE1BQU0sQ0FBQyxDQUFDLElBQUksU0FBUyxjQUFjLFVBQVUsSUFBSTtFQUMvSSxJQUFJLENBQUMsSUFBSTtHQUNSLGtCQUF5QixnQkFBZ0IsWUFBWSxpQkFBaUIsRUFBRSxJQUFJLFNBQVMsR0FBRyxDQUFDO0dBQ3pGO0VBQ0Q7RUFDQSxrQkFBa0IsbUJBQW1CLElBQUksUUFBUTtDQUNsRCxPQUFPLGtCQUFrQjtDQUN6QixJQUFJLG9CQUFvQixTQUFTLGdCQUFnQixPQUFPLE9BQU8sU0FBUyxlQUFlO01BQ2xGLE9BQU8sU0FBUyxnQkFBZ0IsUUFBUSxPQUFPLGdCQUFnQixPQUFPLE9BQU8sU0FBUyxnQkFBZ0IsT0FBTyxPQUFPLGdCQUFnQixNQUFNLE9BQU8sT0FBTztBQUM5SjtBQUNBLFNBQVMsYUFBYSxNQUFNLE9BQU87Q0FDbEMsUUFBUSxRQUFRLFFBQVEsUUFBUSxNQUFNLFdBQVcsUUFBUSxDQUFDLEtBQUs7QUFDaEU7QUFDQSxNQUFNLGtDQUFrQyxJQUFJLElBQUk7QUFDaEQsU0FBUyxtQkFBbUIsS0FBSyxnQkFBZ0I7Q0FDaEQsZ0JBQWdCLElBQUksS0FBSyxjQUFjO0FBQ3hDO0FBQ0EsU0FBUyx1QkFBdUIsS0FBSztDQUNwQyxNQUFNLFNBQVMsZ0JBQWdCLElBQUksR0FBRztDQUN0QyxnQkFBZ0IsT0FBTyxHQUFHO0NBQzFCLE9BQU87QUFDUjs7Ozs7OztBQU9BLFNBQVMsZ0JBQWdCLE9BQU87Q0FDL0IsT0FBTyxPQUFPLFVBQVUsWUFBWSxTQUFTLE9BQU8sVUFBVTtBQUMvRDtBQUNBLFNBQVMsWUFBWSxNQUFNO0NBQzFCLE9BQU8sT0FBTyxTQUFTLFlBQVksT0FBTyxTQUFTO0FBQ3BEOzs7Ozs7Ozs7Ozs7QUFZQSxTQUFTLFdBQVcsUUFBUTtDQUMzQixNQUFNLFFBQVEsQ0FBQztDQUNmLElBQUksV0FBVyxNQUFNLFdBQVcsS0FBSyxPQUFPO0NBQzVDLE1BQU0sZ0JBQWdCLE9BQU8sT0FBTyxNQUFNLE9BQU8sTUFBTSxDQUFDLElBQUksT0FBTSxDQUFFLE1BQU0sR0FBRztDQUM3RSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksYUFBYSxRQUFRLEVBQUUsR0FBRztFQUM3QyxNQUFNLGNBQWMsYUFBYSxFQUFFLENBQUMsUUFBUSxTQUFTLEdBQUc7RUFDeEQsTUFBTSxRQUFRLFlBQVksUUFBUSxHQUFHO0VBQ3JDLE1BQU0sTUFBTSxPQUFPLFFBQVEsSUFBSSxjQUFjLFlBQVksTUFBTSxHQUFHLEtBQUssQ0FBQztFQUN4RSxNQUFNLFFBQVEsUUFBUSxJQUFJLE9BQU8sT0FBTyxZQUFZLE1BQU0sUUFBUSxDQUFDLENBQUM7RUFDcEUsSUFBSSxPQUFPLE9BQU87R0FDakIsSUFBSSxlQUFlLE1BQU07R0FDekIsSUFBSSxDQUFDLFFBQVEsWUFBWSxHQUFHLGVBQWUsTUFBTSxPQUFPLENBQUMsWUFBWTtHQUNyRSxhQUFhLEtBQUssS0FBSztFQUN4QixPQUFPLE1BQU0sT0FBTztDQUNyQjtDQUNBLE9BQU87QUFDUjs7Ozs7Ozs7OztBQVVBLFNBQVMsZUFBZSxPQUFPO0NBQzlCLElBQUksU0FBUztDQUNiLEtBQUssSUFBSSxPQUFPLE9BQU87RUFDdEIsTUFBTSxRQUFRLE1BQU07RUFDcEIsTUFBTSxlQUFlLEdBQUc7RUFDeEIsSUFBSSxTQUFTLE1BQU07R0FDbEIsSUFBSSxVQUFVLEtBQUssR0FBRyxXQUFXLE9BQU8sU0FBUyxNQUFNLE1BQU07R0FDN0Q7RUFDRDtFQUNBLENBQUMsUUFBUSxLQUFLLElBQUksTUFBTSxLQUFLLE1BQU0sS0FBSyxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLGlCQUFpQixLQUFLLENBQUMsRUFBQyxDQUFFLFNBQVMsVUFBVTtHQUNySCxJQUFJLFVBQVUsS0FBSyxHQUFHO0lBQ3JCLFdBQVcsT0FBTyxTQUFTLE1BQU0sTUFBTTtJQUN2QyxJQUFJLFNBQVMsTUFBTSxVQUFVLE1BQU07R0FDcEM7RUFDRCxDQUFDO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1I7Ozs7Ozs7OztBQVNBLFNBQVMsZUFBZSxPQUFPO0NBQzlCLE1BQU0sa0JBQWtCLENBQUM7Q0FDekIsS0FBSyxNQUFNLE9BQU8sT0FBTztFQUN4QixNQUFNLFFBQVEsTUFBTTtFQUNwQixJQUFJLFVBQVUsS0FBSyxHQUFHLGdCQUFnQixPQUFPLFFBQVEsS0FBSyxJQUFJLE1BQU0sS0FBSyxNQUFNLEtBQUssT0FBTyxPQUFPLEtBQUssQ0FBQyxJQUFJLFNBQVMsT0FBTyxRQUFRLEtBQUs7Q0FDMUk7Q0FDQSxPQUFPO0FBQ1I7Ozs7OztBQU1BLFNBQVMsZUFBZTtDQUN2QixJQUFJLFdBQVcsQ0FBQztDQUNoQixTQUFTLElBQUksU0FBUztFQUNyQixTQUFTLEtBQUssT0FBTztFQUNyQixhQUFhO0dBQ1osTUFBTSxJQUFJLFNBQVMsUUFBUSxPQUFPO0dBQ2xDLElBQUksSUFBSSxDQUFDLEdBQUcsU0FBUyxPQUFPLEdBQUcsQ0FBQztFQUNqQztDQUNEO0NBQ0EsU0FBUyxRQUFRO0VBQ2hCLFdBQVcsQ0FBQztDQUNiO0NBQ0EsT0FBTztFQUNOO0VBQ0EsWUFBWSxTQUFTLE1BQU07RUFDM0I7Q0FDRDtBQUNEOzs7QUFHQSxTQUFTLGNBQWMsaUJBQWlCLE1BQU0sT0FBTztDQUNwRCxNQUFNLFNBQVMsZ0JBQWdCO0NBQy9CLElBQUksQ0FBQyxRQUFRO0VBQ1osc0JBQTZCLGNBQWM7R0FDMUMsTUFBTSxTQUFTLFNBQVMsaUJBQWlCLHdCQUF3QjtHQUNqRSxZQUFZLGlCQUFpQixFQUFFLElBQUksT0FBTyxDQUFDO0VBQzVDO0VBQ0E7Q0FDRDtDQUNBLElBQUksZ0JBQWdCO0NBQ3BCLE1BQU0sdUJBQXVCO0VBQzVCLGNBQWMsS0FBSyxDQUFDLE9BQU8sS0FBSztDQUNqQztDQUNBLFlBQVksY0FBYztDQUMxQixjQUFjLGNBQWM7Q0FDNUIsa0JBQWtCO0VBQ2pCLE1BQU0sWUFBWSxnQkFBZ0I7RUFDbEMsc0JBQTZCLGdCQUFnQixDQUFDLFdBQVcsWUFBWSxpQkFBaUI7RUFDdEYsSUFBSSxXQUFXLGdCQUFnQjtFQUMvQixjQUFjLEtBQUssQ0FBQyxJQUFJLEtBQUs7Q0FDOUIsQ0FBQztDQUNELGNBQWMsS0FBSyxDQUFDLElBQUksS0FBSztBQUM5Qjs7Ozs7Ozs7QUFRQSxTQUFTLG1CQUFtQixZQUFZO0NBQ3ZDLHNCQUE2QixnQkFBZ0IsQ0FBQyxtQkFBbUIsR0FBRztFQUNuRSxZQUFZLGlCQUFpQixFQUFFLElBQUkscUJBQXFCLENBQUM7RUFDekQ7Q0FDRDtDQUNBLGNBQWMsT0FBTyxpQkFBaUIsQ0FBQyxDQUFDLEdBQUcsZUFBZSxVQUFVO0FBQ3JFOzs7Ozs7OztBQVFBLFNBQVMsb0JBQW9CLGFBQWE7Q0FDekMsc0JBQTZCLGdCQUFnQixDQUFDLG1CQUFtQixHQUFHO0VBQ25FLFlBQVksaUJBQWlCLEVBQUUsSUFBSSxzQkFBc0IsQ0FBQztFQUMxRDtDQUNEO0NBQ0EsY0FBYyxPQUFPLGlCQUFpQixDQUFDLENBQUMsR0FBRyxnQkFBZ0IsV0FBVztBQUN2RTtBQUNBLFNBQVMsaUJBQWlCLE9BQU8sSUFBSSxNQUFNLFFBQVEsTUFBTSxrQkFBa0IsT0FBTyxHQUFHLEdBQUc7Q0FDdkYsTUFBTSxxQkFBcUIsV0FBVyxPQUFPLGVBQWUsUUFBUSxPQUFPLGVBQWUsU0FBUyxDQUFDO0NBQ3BHLGFBQWEsSUFBSSxTQUFTLFNBQVMsV0FBVztFQUM3QyxNQUFNLFFBQVEsVUFBVTtHQUN2QixJQUFJLFVBQVUsT0FBTyxPQUFPLGtCQUFrQixHQUFHO0lBQ2hEO0lBQ0E7R0FDRCxDQUFDLENBQUM7UUFDRyxJQUFJLGlCQUFpQixPQUFPLE9BQU8sS0FBSztRQUN4QyxJQUFJLGdCQUFnQixLQUFLLEdBQUcsT0FBTyxrQkFBa0IsR0FBRztJQUM1RCxNQUFNO0lBQ04sSUFBSTtHQUNMLENBQUMsQ0FBQztRQUNHO0lBQ0osSUFBSSxzQkFBc0IsT0FBTyxlQUFlLFVBQVUsc0JBQXNCLE9BQU8sVUFBVSxZQUFZLG1CQUFtQixLQUFLLEtBQUs7SUFDMUksUUFBUTtHQUNUO0VBQ0Q7RUFDQSxNQUFNLGNBQWMscUJBQXFCLE1BQU0sS0FBSyxVQUFVLE9BQU8sVUFBVSxPQUFPLElBQUksd0JBQStCLGVBQWUsdUJBQXVCLG9CQUFvQixNQUFNLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxDQUFDO0VBQzNNLElBQUksWUFBWSxRQUFRLFFBQVEsV0FBVztFQUMzQyxJQUFJLE1BQU0sU0FBUyxHQUFHLFlBQVksVUFBVSxLQUFLLElBQUk7RUFDckQsc0JBQTZCLGdCQUFnQixNQUFNLFNBQVMsR0FBRztHQUM5RCxNQUFNLFlBQVk7SUFDakIsTUFBTSxNQUFNO0lBQ1osT0FBTyxNQUFNLFNBQVM7R0FDdkI7R0FDQSxJQUFJLE9BQU8sZ0JBQWdCLFlBQVksVUFBVSxhQUFhLFlBQVksVUFBVSxNQUFNLGtCQUFrQjtJQUMzRyxJQUFJLENBQUMsS0FBSyxTQUFTO0tBQ2xCLFlBQVksaUJBQWlCLFNBQVM7S0FDdEMsT0FBTyxRQUFRLHVCQUF1QixJQUFJLE1BQU0sMEJBQTBCLENBQUM7SUFDNUU7SUFDQSxPQUFPO0dBQ1IsQ0FBQztRQUNJLElBQUksZ0JBQWdCLEtBQUssR0FBRztJQUNoQyxJQUFJLENBQUMsS0FBSyxTQUFTO0tBQ2xCLFlBQVksaUJBQWlCLFNBQVM7S0FDdEMsdUJBQXVCLElBQUksTUFBTSwwQkFBMEIsQ0FBQztLQUM1RDtJQUNEO0dBQ0Q7RUFDRDtFQUNBLFVBQVUsT0FBTyxRQUFRLE9BQU8sR0FBRyxDQUFDO0NBQ3JDLENBQUM7QUFDRjs7Ozs7Ozs7QUFRQSxTQUFTLHVCQUF1QixNQUFNO0NBQ3JDLElBQUksU0FBUztDQUNiLE9BQU8sV0FBVztFQUNqQixJQUFJLENBQUMsUUFBUTtHQUNaLFNBQVM7R0FDVCxZQUFZLGlCQUFpQjtFQUM5QjtFQUNBLE9BQU8sS0FBSyxNQUFNLE1BQU0sU0FBUztDQUNsQztBQUNEO0FBQ0EsU0FBUyxvQkFBb0IsTUFBTSxJQUFJLE1BQU07Q0FDNUMsSUFBSSxTQUFTO0NBQ2IsT0FBTyxXQUFXO0VBQ2pCLElBQUksYUFBYSxHQUFHLFlBQVksaUJBQWlCO0dBQ2hELE1BQU0sS0FBSztHQUNYLElBQUksR0FBRztFQUNSLENBQUM7RUFDRCxLQUFLLFVBQVU7RUFDZixJQUFJLFdBQVcsR0FBRyxLQUFLLE1BQU0sTUFBTSxTQUFTO0NBQzdDO0FBQ0Q7QUFDQSxTQUFTLHdCQUF3QixTQUFTLFdBQVcsSUFBSSxNQUFNLGtCQUFrQixPQUFPLEdBQUcsR0FBRztDQUM3RixNQUFNLFNBQVMsQ0FBQztDQUNoQixLQUFLLE1BQU0sVUFBVSxTQUFTO0VBQzdCLHNCQUE2QixnQkFBZ0IsQ0FBQyxPQUFPLGNBQWMsT0FBTyxZQUFZLENBQUMsT0FBTyxTQUFTLFFBQVEsWUFBWSxpQkFBaUIsRUFBRSxNQUFNLE9BQU8sS0FBSyxDQUFDO0VBQ2pLLEtBQUssTUFBTSxRQUFRLE9BQU8sWUFBWTtHQUNyQyxJQUFJLGVBQWUsT0FBTyxXQUFXO0dBQ3JDLHNCQUE2QixjQUFjO0lBQzFDLElBQUksQ0FBQyxnQkFBZ0IsT0FBTyxpQkFBaUIsWUFBWSxPQUFPLGlCQUFpQixZQUFZO0tBQzVGLFlBQVksaUJBQWlCO01BQzVCO01BQ0EsTUFBTSxPQUFPO01BQ2IsVUFBVSxPQUFPLFlBQVk7S0FDOUIsQ0FBQztLQUNELE1BQU0sSUFBSSxNQUFNLHlCQUF5QjtJQUMxQyxPQUFPLElBQUksVUFBVSxjQUFjO0tBQ2xDLFlBQVksaUJBQWlCO01BQzVCO01BQ0EsTUFBTSxPQUFPO0tBQ2QsQ0FBQztLQUNELE1BQU0sVUFBVTtLQUNoQixxQkFBcUI7SUFDdEIsT0FBTyxJQUFJLGFBQWEsaUJBQWlCLENBQUMsYUFBYSxxQkFBcUI7S0FDM0UsYUFBYSxzQkFBc0I7S0FDbkMsWUFBWSxpQkFBaUI7TUFDNUI7TUFDQSxNQUFNLE9BQU87S0FDZCxDQUFDO0lBQ0Y7R0FDRDtHQUNBLElBQUksY0FBYyxzQkFBc0IsQ0FBQyxPQUFPLFVBQVUsT0FBTztHQUNqRSxJQUFJLGlCQUFpQixZQUFZLEdBQUc7SUFDbkMsTUFBTSxTQUFTLGFBQWEsYUFBYSxhQUFZLENBQUU7SUFDdkQsU0FBUyxPQUFPLEtBQUssaUJBQWlCLE9BQU8sSUFBSSxNQUFNLFFBQVEsTUFBTSxjQUFjLENBQUM7R0FDckYsT0FBTztJQUNOLElBQUksbUJBQW1CLGFBQWE7SUFDcEMsc0JBQTZCLGdCQUFnQixFQUFFLFdBQVcsbUJBQW1CO0tBQzVFLFlBQVksaUJBQWlCO01BQzVCO01BQ0EsTUFBTSxPQUFPO0tBQ2QsQ0FBQztLQUNELG1CQUFtQixRQUFRLFFBQVEsZ0JBQWdCO0lBQ3BEO0lBQ0EsT0FBTyxXQUFXLGlCQUFpQixNQUFNLGFBQWE7S0FDckQsSUFBSSxDQUFDLFVBQVUsTUFBTSxJQUFJLE1BQU0sK0JBQStCLEtBQUssUUFBUSxPQUFPLEtBQUssRUFBRTtLQUN6RixNQUFNLG9CQUFvQixXQUFXLFFBQVEsSUFBSSxTQUFTLFVBQVU7S0FDcEUsT0FBTyxLQUFLLFFBQVE7S0FDcEIsT0FBTyxXQUFXLFFBQVE7S0FDMUIsTUFBTSxTQUFTLGtCQUFrQixhQUFhLGtCQUFpQixDQUFFO0tBQ2pFLE9BQU8sU0FBUyxpQkFBaUIsT0FBTyxJQUFJLE1BQU0sUUFBUSxNQUFNLGNBQWMsQ0FBQyxDQUFDO0lBQ2pGLENBQUMsQ0FBQztHQUNIO0VBQ0Q7Q0FDRDtDQUNBLE9BQU87QUFDUjs7Ozs7O0FBTUEsU0FBUyxrQkFBa0IsT0FBTztDQUNqQyxPQUFPLE1BQU0sUUFBUSxPQUFPLFdBQVcsT0FBTyxRQUFRLElBQUksUUFBUSx1QkFBdUIsSUFBSSxNQUFNLHFDQUFxQyxDQUFDLElBQUksUUFBUSxJQUFJLE1BQU0sUUFBUSxLQUFLLFdBQVcsT0FBTyxjQUFjLFFBQVEsSUFBSSxPQUFPLEtBQUssT0FBTyxVQUFVLENBQUMsQ0FBQyxRQUFRLFVBQVUsU0FBUztFQUNqUixNQUFNLGVBQWUsT0FBTyxXQUFXO0VBQ3ZDLElBQUksT0FBTyxpQkFBaUIsY0FBYyxFQUFFLGlCQUFpQixlQUFlLFNBQVMsS0FBSyxhQUFhLENBQUMsQ0FBQyxNQUFNLGFBQWE7R0FDM0gsSUFBSSxDQUFDLFVBQVUsT0FBTyxRQUFRLHVCQUF1QixJQUFJLE1BQU0sK0JBQStCLEtBQUssUUFBUSxPQUFPLEtBQUssd0RBQXdELENBQUM7R0FDaEwsTUFBTSxvQkFBb0IsV0FBVyxRQUFRLElBQUksU0FBUyxVQUFVO0dBQ3BFLE9BQU8sS0FBSyxRQUFRO0dBQ3BCLE9BQU8sV0FBVyxRQUFRO0VBQzNCLENBQUMsQ0FBQztFQUNGLE9BQU87Q0FDUixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxLQUFLO0FBQzNCOzs7Ozs7OztBQVFBLFNBQVMsdUJBQXVCLElBQUksTUFBTTtDQUN6QyxNQUFNLGlCQUFpQixDQUFDO0NBQ3hCLE1BQU0sa0JBQWtCLENBQUM7Q0FDekIsTUFBTSxrQkFBa0IsQ0FBQztDQUN6QixNQUFNLE1BQU0sS0FBSyxJQUFJLEtBQUssUUFBUSxRQUFRLEdBQUcsUUFBUSxNQUFNO0NBQzNELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUs7RUFDN0IsTUFBTSxhQUFhLEtBQUssUUFBUTtFQUNoQyxJQUFJLFlBQVksSUFBSSxHQUFHLFFBQVEsTUFBTSxXQUFXLGtCQUFrQixRQUFRLFVBQVUsQ0FBQyxHQUFHLGdCQUFnQixLQUFLLFVBQVU7T0FDbEgsZUFBZSxLQUFLLFVBQVU7RUFDbkMsTUFBTSxXQUFXLEdBQUcsUUFBUTtFQUM1QixJQUFJLFVBQVU7R0FDYixJQUFJLENBQUMsS0FBSyxRQUFRLE1BQU0sV0FBVyxrQkFBa0IsUUFBUSxRQUFRLENBQUMsR0FBRyxnQkFBZ0IsS0FBSyxRQUFRO0VBQ3ZHO0NBQ0Q7Q0FDQSxPQUFPO0VBQ047RUFDQTtFQUNBO0NBQ0Q7QUFDRDs7Ozs7Ozs7OztBQVVBLFNBQVMsb0JBQW9CLGVBQWUsU0FBUztDQUNwRCxNQUFNLE9BQU8sT0FBTyxDQUFDLEdBQUcsZUFBZSxFQUFFLFNBQVMsY0FBYyxRQUFRLEtBQUssWUFBWSxLQUFLLFNBQVM7RUFDdEc7RUFDQTtFQUNBO0NBQ0QsQ0FBQyxDQUFDLEVBQUUsQ0FBQztDQUNMLE9BQU8sRUFBRSxTQUFTO0VBQ2pCLE1BQU07RUFDTixVQUFVO0VBQ1YsU0FBUyxjQUFjO0VBQ3ZCO0VBQ0EsT0FBTztDQUNSLEVBQUU7QUFDSDtBQUNBLFNBQVMsY0FBYyxTQUFTO0NBQy9CLE9BQU8sRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFO0FBQy9CO0FBQ0EsSUFBSSxXQUFXO0FBQ2YsU0FBUyxZQUFZLEtBQUssUUFBUSxTQUFTO0NBQzFDLElBQUksT0FBTyxlQUFlO0NBQzFCLE9BQU8sZ0JBQWdCO0NBQ3ZCLE1BQU0sS0FBSztDQUNYLG9CQUFvQjtFQUNuQixJQUFJLHNCQUFzQixLQUFLLE1BQU0sS0FBSztFQUMxQyxPQUFPO0VBQ1AsYUFBYTtFQUNiLFVBQVU7RUFDVixNQUFNO0VBQ04scUJBQXFCLENBQUMsU0FBUztFQUMvQjtDQUNELElBQUksUUFBUTtFQUNYLElBQUksR0FBRyxrQkFBa0IsWUFBWTtHQUNwQyxJQUFJLFFBQVEsY0FBYyxRQUFRLGFBQWEsTUFBTSxLQUFLO0lBQ3pELE1BQU07SUFDTixLQUFLO0lBQ0wsVUFBVTtJQUNWLE9BQU8sb0JBQW9CLE9BQU8sYUFBYSxPQUFPLGVBQWU7R0FDdEUsQ0FBQztFQUNGLENBQUM7RUFDRCxJQUFJLEdBQUcsb0JBQW9CLEVBQUUsVUFBVSxNQUFNLHdCQUF3QjtHQUNwRSxJQUFJLGtCQUFrQixnQkFBZ0I7SUFDckMsTUFBTSxPQUFPLGtCQUFrQjtJQUMvQixLQUFLLEtBQUssS0FBSztLQUNkLFFBQVEsS0FBSyxPQUFPLEdBQUcsS0FBSyxLQUFLLFNBQVMsRUFBRSxNQUFNLE1BQU0sS0FBSztLQUM3RCxXQUFXO0tBQ1gsU0FBUztLQUNULGlCQUFpQjtJQUNsQixDQUFDO0dBQ0Y7R0FDQSxJQUFJLFFBQVEsa0JBQWtCLGNBQWMsR0FBRztJQUM5QyxrQkFBa0IsZ0JBQWdCO0lBQ2xDLGtCQUFrQixlQUFlLFNBQVMsaUJBQWlCO0tBQzFELElBQUksUUFBUSxhQUFhLE1BQU07S0FDL0IsSUFBSSxrQkFBa0I7S0FDdEIsSUFBSSxVQUFVO0tBQ2QsSUFBSSxZQUFZO0tBQ2hCLElBQUksYUFBYSxPQUFPO01BQ3ZCLFFBQVEsYUFBYTtNQUNyQixrQkFBa0I7TUFDbEIsWUFBWTtLQUNiLE9BQU8sSUFBSSxhQUFhLGVBQWU7TUFDdEMsa0JBQWtCO01BQ2xCLFVBQVU7S0FDWCxPQUFPLElBQUksYUFBYSxVQUFVO01BQ2pDLGtCQUFrQjtNQUNsQixVQUFVO0tBQ1g7S0FDQSxLQUFLLEtBQUssS0FBSztNQUNkO01BQ0E7TUFDQTtNQUNBO0tBQ0QsQ0FBQztJQUNGLENBQUM7R0FDRjtFQUNELENBQUM7RUFDRCxNQUFNLE9BQU8sb0JBQW9CO0dBQ2hDLGtCQUFrQjtHQUNsQixJQUFJLHNCQUFzQjtHQUMxQixJQUFJLGtCQUFrQixpQkFBaUI7R0FDdkMsSUFBSSxtQkFBbUIsaUJBQWlCO0VBQ3pDLENBQUM7RUFDRCxNQUFNLHFCQUFxQix3QkFBd0I7RUFDbkQsSUFBSSxpQkFBaUI7R0FDcEIsSUFBSTtHQUNKLE9BQU8sU0FBUyxLQUFLLE1BQU0sS0FBSyxHQUFHO0dBQ25DLE9BQU87RUFDUixDQUFDO0VBQ0QsT0FBTyxTQUFTLE9BQU8sT0FBTztHQUM3QixJQUFJLGlCQUFpQjtJQUNwQixTQUFTO0lBQ1QsT0FBTztLQUNOLE9BQU87S0FDUCxVQUFVLEdBQUc7S0FDYixTQUFTO0tBQ1QsTUFBTSxJQUFJLElBQUk7S0FDZCxNQUFNLEVBQUUsTUFBTTtLQUNkLFNBQVMsR0FBRyxLQUFLO0lBQ2xCO0dBQ0QsQ0FBQztFQUNGLENBQUM7RUFDRCxJQUFJLGVBQWU7RUFDbkIsT0FBTyxZQUFZLElBQUksU0FBUztHQUMvQixNQUFNLE9BQU87SUFDWixPQUFPLGNBQWMsWUFBWTtJQUNqQyxNQUFNLG9CQUFvQixNQUFNLHlDQUF5QztJQUN6RSxJQUFJLG9CQUFvQixJQUFJLGlCQUFpQjtHQUM5QztHQUNBLE9BQU8sZUFBZSxHQUFHLE1BQU0sa0JBQWtCLEVBQUUsT0FBTyxlQUFlLENBQUM7R0FDMUUsSUFBSSxpQkFBaUI7SUFDcEIsU0FBUztJQUNULE9BQU87S0FDTixNQUFNLElBQUksSUFBSTtLQUNkLE9BQU87S0FDUCxVQUFVLEdBQUc7S0FDYjtLQUNBLFNBQVMsR0FBRyxLQUFLO0lBQ2xCO0dBQ0QsQ0FBQztFQUNGLENBQUM7RUFDRCxPQUFPLFdBQVcsSUFBSSxNQUFNLFlBQVk7R0FDdkMsTUFBTSxPQUFPLEVBQUUsT0FBTyxjQUFjLFdBQVcsRUFBRTtHQUNqRCxJQUFJLFNBQVM7SUFDWixLQUFLLFVBQVUsRUFBRSxTQUFTO0tBQ3pCLE1BQU07S0FDTixVQUFVO0tBQ1YsU0FBUyxVQUFVLFFBQVEsVUFBVTtLQUNyQyxTQUFTO0tBQ1QsT0FBTztJQUNSLEVBQUU7SUFDRixLQUFLLFNBQVMsY0FBYyxHQUFHO0dBQ2hDLE9BQU8sS0FBSyxTQUFTLGNBQWMsR0FBRztHQUN0QyxLQUFLLE9BQU8sb0JBQW9CLE1BQU0seUNBQXlDO0dBQy9FLEtBQUssS0FBSyxvQkFBb0IsSUFBSSxpQkFBaUI7R0FDbkQsSUFBSSxpQkFBaUI7SUFDcEIsU0FBUztJQUNULE9BQU87S0FDTixPQUFPO0tBQ1AsVUFBVSxHQUFHO0tBQ2IsTUFBTSxJQUFJLElBQUk7S0FDZDtLQUNBLFNBQVMsVUFBVSxZQUFZO0tBQy9CLFNBQVMsR0FBRyxLQUFLO0lBQ2xCO0dBQ0QsQ0FBQztFQUNGLENBQUM7Ozs7RUFJRCxNQUFNLG9CQUFvQixzQkFBc0I7RUFDaEQsSUFBSSxhQUFhO0dBQ2hCLElBQUk7R0FDSixPQUFPLFlBQVksS0FBSyxNQUFNLEtBQUs7R0FDbkMsTUFBTTtHQUNOLHVCQUF1QjtFQUN4QixDQUFDO0VBQ0QsU0FBUyxvQkFBb0I7R0FDNUIsSUFBSSxDQUFDLHFCQUFxQjtHQUMxQixNQUFNLFVBQVU7R0FDaEIsSUFBSSxTQUFTLFFBQVEsVUFBVSxDQUFDLENBQUMsUUFBUSxVQUFVLENBQUMsTUFBTSxVQUFVLENBQUMsTUFBTSxPQUFPLE9BQU8sVUFBVTtHQUNuRyxPQUFPLFFBQVEsNEJBQTRCO0dBQzNDLElBQUksUUFBUSxRQUFRLFNBQVMsT0FBTyxRQUFRLFVBQVUsZ0JBQWdCLE9BQU8sUUFBUSxPQUFPLFlBQVksQ0FBQyxDQUFDO0dBQzFHLE9BQU8sU0FBUyxVQUFVLHNCQUFzQixPQUFPLE9BQU8sYUFBYSxLQUFLLENBQUM7R0FDakYsUUFBUSxZQUFZLE9BQU8sSUFBSSw2QkFBNkI7RUFDN0Q7RUFDQSxJQUFJO0VBQ0osSUFBSSxHQUFHLGtCQUFrQixZQUFZO0dBQ3BDLHNCQUFzQjtHQUN0QixJQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsZ0JBQWdCLG1CQUFtQixrQkFBa0I7RUFDekYsQ0FBQzs7OztFQUlELElBQUksR0FBRyxtQkFBbUIsWUFBWTtHQUNyQyxJQUFJLFFBQVEsUUFBUSxPQUFPLFFBQVEsZ0JBQWdCLG1CQUFtQjtJQUNyRSxNQUFNLFFBQVEsUUFBUSxVQUFVLENBQUMsQ0FBQyxNQUFNLFVBQVUsTUFBTSxPQUFPLFlBQVksUUFBUSxNQUFNO0lBQ3pGLElBQUksT0FBTyxRQUFRLFFBQVEsRUFBRSxTQUFTLDBDQUEwQyxLQUFLLEVBQUU7R0FDeEY7RUFDRCxDQUFDO0VBQ0QsSUFBSSxrQkFBa0IsaUJBQWlCO0VBQ3ZDLElBQUksbUJBQW1CLGlCQUFpQjtDQUN6QyxDQUFDO0FBQ0Y7QUFDQSxTQUFTLGVBQWUsS0FBSztDQUM1QixJQUFJLElBQUksVUFBVSxPQUFPLElBQUksYUFBYSxNQUFNO01BQzNDLE9BQU8sSUFBSSxhQUFhLE1BQU07QUFDcEM7QUFDQSxTQUFTLDBDQUEwQyxPQUFPO0NBQ3pELE1BQU0sRUFBRSxXQUFXO0NBQ25CLE1BQU0sU0FBUyxDQUFDO0VBQ2YsVUFBVTtFQUNWLEtBQUs7RUFDTCxPQUFPLE9BQU87Q0FDZixDQUFDO0NBQ0QsSUFBSSxPQUFPLFFBQVEsTUFBTSxPQUFPLEtBQUs7RUFDcEMsVUFBVTtFQUNWLEtBQUs7RUFDTCxPQUFPLE9BQU87Q0FDZixDQUFDO0NBQ0QsT0FBTyxLQUFLO0VBQ1gsVUFBVTtFQUNWLEtBQUs7RUFDTCxPQUFPLE1BQU07Q0FDZCxDQUFDO0NBQ0QsSUFBSSxNQUFNLEtBQUssUUFBUSxPQUFPLEtBQUs7RUFDbEMsVUFBVTtFQUNWLEtBQUs7RUFDTCxPQUFPLEVBQUUsU0FBUztHQUNqQixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVMsTUFBTSxLQUFLLEtBQUssUUFBUSxHQUFHLElBQUksT0FBTyxlQUFlLEdBQUcsR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHO0dBQzlFLFNBQVM7R0FDVCxPQUFPLE1BQU07RUFDZCxFQUFFO0NBQ0gsQ0FBQztDQUNELElBQUksT0FBTyxZQUFZLE1BQU0sT0FBTyxLQUFLO0VBQ3hDLFVBQVU7RUFDVixLQUFLO0VBQ0wsT0FBTyxPQUFPO0NBQ2YsQ0FBQztDQUNELElBQUksTUFBTSxNQUFNLFFBQVEsT0FBTyxLQUFLO0VBQ25DLFVBQVU7RUFDVixLQUFLO0VBQ0wsT0FBTyxNQUFNLE1BQU0sS0FBSyxVQUFVLE1BQU0sT0FBTyxJQUFJO0NBQ3BELENBQUM7Q0FDRCxJQUFJLE9BQU8sS0FBSyxNQUFNLE9BQU8sSUFBSSxDQUFDLENBQUMsUUFBUSxPQUFPLEtBQUs7RUFDdEQsVUFBVTtFQUNWLEtBQUs7RUFDTCxPQUFPLE1BQU0sT0FBTztDQUNyQixDQUFDO0NBQ0QsT0FBTyxLQUFLO0VBQ1gsS0FBSztFQUNMLFVBQVU7RUFDVixPQUFPLEVBQUUsU0FBUztHQUNqQixNQUFNO0dBQ04sVUFBVTtHQUNWLFNBQVMsTUFBTSxNQUFNLEtBQUssVUFBVSxNQUFNLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUs7R0FDaEUsU0FBUztHQUNULE9BQU8sTUFBTTtFQUNkLEVBQUU7Q0FDSCxDQUFDO0NBQ0QsT0FBTztBQUNSOzs7O0FBSUEsTUFBTSxXQUFXO0FBQ2pCLE1BQU0sV0FBVztBQUNqQixNQUFNLFdBQVc7QUFDakIsTUFBTSxXQUFXO0FBQ2pCLE1BQU0sYUFBYTtBQUNuQixNQUFNLE9BQU87QUFDYixNQUFNLFVBQVU7QUFDaEIsTUFBTSxVQUFVO0FBQ2hCLFNBQVMsOEJBQThCLE9BQU87Q0FDN0MsTUFBTSxPQUFPLENBQUM7Q0FDZCxNQUFNLEVBQUUsV0FBVztDQUNuQixJQUFJLE9BQU8sUUFBUSxNQUFNLEtBQUssS0FBSztFQUNsQyxPQUFPLE9BQU8sT0FBTyxJQUFJO0VBQ3pCLFdBQVc7RUFDWCxpQkFBaUI7Q0FDbEIsQ0FBQztDQUNELElBQUksT0FBTyxTQUFTLEtBQUssS0FBSztFQUM3QixPQUFPO0VBQ1AsV0FBVztFQUNYLGlCQUFpQjtDQUNsQixDQUFDO0NBQ0QsSUFBSSxNQUFNLFlBQVksS0FBSyxLQUFLO0VBQy9CLE9BQU87RUFDUCxXQUFXO0VBQ1gsaUJBQWlCO0NBQ2xCLENBQUM7Q0FDRCxJQUFJLE1BQU0sa0JBQWtCLEtBQUssS0FBSztFQUNyQyxPQUFPO0VBQ1AsV0FBVztFQUNYLGlCQUFpQjtDQUNsQixDQUFDO0NBQ0QsSUFBSSxNQUFNLGFBQWEsS0FBSyxLQUFLO0VBQ2hDLE9BQU87RUFDUCxXQUFXO0VBQ1gsaUJBQWlCO0NBQ2xCLENBQUM7Q0FDRCxJQUFJLE9BQU8sVUFBVSxLQUFLLEtBQUs7RUFDOUIsT0FBTyxPQUFPLE9BQU8sYUFBYSxXQUFXLGFBQWEsT0FBTyxhQUFhO0VBQzlFLFdBQVc7RUFDWCxpQkFBaUI7Q0FDbEIsQ0FBQztDQUNELElBQUksS0FBSyxPQUFPO0NBQ2hCLElBQUksTUFBTSxNQUFNO0VBQ2YsS0FBSyxPQUFPLGVBQWU7RUFDM0IsT0FBTyxVQUFVO0NBQ2xCO0NBQ0EsT0FBTztFQUNOO0VBQ0EsT0FBTyxPQUFPO0VBQ2Q7RUFDQSxVQUFVLE1BQU0sU0FBUyxJQUFJLDZCQUE2QjtDQUMzRDtBQUNEO0FBQ0EsSUFBSSxnQkFBZ0I7QUFDcEIsTUFBTSxvQkFBb0I7QUFDMUIsU0FBUyxzQkFBc0IsT0FBTyxjQUFjO0NBQ25ELE1BQU0sZ0JBQWdCLGFBQWEsUUFBUSxVQUFVLGtCQUFrQixhQUFhLFFBQVEsYUFBYSxRQUFRLFNBQVMsSUFBSSxNQUFNLE1BQU07Q0FDMUksTUFBTSxtQkFBbUIsTUFBTSxjQUFjO0NBQzdDLElBQUksQ0FBQyxlQUFlLE1BQU0sY0FBYyxhQUFhLFFBQVEsTUFBTSxVQUFVLGtCQUFrQixPQUFPLE1BQU0sTUFBTSxDQUFDO0NBQ25ILE1BQU0sU0FBUyxTQUFTLGVBQWUsc0JBQXNCLFlBQVksWUFBWSxDQUFDO0FBQ3ZGO0FBQ0EsU0FBUyw2QkFBNkIsT0FBTztDQUM1QyxNQUFNLGFBQWE7Q0FDbkIsTUFBTSxTQUFTLFFBQVEsNEJBQTRCO0FBQ3BEO0FBQ0EsU0FBUyxnQkFBZ0IsT0FBTyxRQUFRO0NBQ3ZDLE1BQU0sUUFBUSxPQUFPLE1BQU0sRUFBRSxDQUFDLENBQUMsTUFBTSxpQkFBaUI7Q0FDdEQsTUFBTSxhQUFhO0NBQ25CLElBQUksQ0FBQyxTQUFTLE1BQU0sU0FBUyxHQUFHLE9BQU87Q0FDdkMsSUFBSSxJQUFJLE9BQU8sTUFBTSxFQUFFLENBQUMsUUFBUSxPQUFPLEVBQUUsR0FBRyxNQUFNLEVBQUUsQ0FBQyxDQUFDLEtBQUssTUFBTSxHQUFHO0VBQ25FLE1BQU0sU0FBUyxTQUFTLFVBQVUsZ0JBQWdCLE9BQU8sTUFBTSxDQUFDO0VBQ2hFLElBQUksTUFBTSxPQUFPLFNBQVMsT0FBTyxXQUFXLEtBQUs7R0FDaEQsTUFBTSxhQUFhLE1BQU0sR0FBRyxLQUFLLE1BQU07R0FDdkMsT0FBTztFQUNSO0VBQ0EsT0FBTztDQUNSO0NBQ0EsTUFBTSxPQUFPLE1BQU0sT0FBTyxLQUFLLFlBQVk7Q0FDM0MsTUFBTSxjQUFjLE9BQU8sSUFBSTtDQUMvQixJQUFJLENBQUMsT0FBTyxXQUFXLEdBQUcsTUFBTSxZQUFZLFNBQVMsTUFBTSxLQUFLLEtBQUssU0FBUyxNQUFNLElBQUksT0FBTztDQUMvRixJQUFJLFlBQVksV0FBVyxNQUFNLEtBQUssS0FBSyxXQUFXLE1BQU0sR0FBRyxPQUFPO0NBQ3RFLElBQUksTUFBTSxPQUFPLFFBQVEsT0FBTyxNQUFNLE9BQU8sSUFBSSxDQUFDLENBQUMsU0FBUyxNQUFNLEdBQUcsT0FBTztDQUM1RSxPQUFPLE1BQU0sU0FBUyxNQUFNLFVBQVUsZ0JBQWdCLE9BQU8sTUFBTSxDQUFDO0FBQ3JFO0FBQ0EsU0FBUyxLQUFLLEtBQUssTUFBTTtDQUN4QixNQUFNLE1BQU0sQ0FBQztDQUNiLEtBQUssTUFBTSxPQUFPLEtBQUssSUFBSSxDQUFDLEtBQUssU0FBUyxHQUFHLEdBQUcsSUFBSSxPQUFPLElBQUk7Q0FDL0QsT0FBTztBQUNSOztBQUVBLFNBQVMsV0FBVyxHQUFHLHVCQUF1QixHQUFHLHVCQUF1QixHQUFHLFlBQVksR0FBRyxhQUFhLEdBQUcsY0FBYyxHQUFHLGVBQWUsR0FBRyxnQkFBZ0IsR0FBRyxjQUFjLEdBQUcsNkJBQTZCLEdBQUcscUJBQXFCLEdBQUcsc0JBQXNCLEdBQUcscUJBQXFCLEdBQUcsaUJBQWlCLEdBQUcsZ0JBQWdCLEdBQUcsa0JBQWtCLEdBQUcsbUJBQW1CLEdBQUcsZ0JBQWdCLEdBQUcsMEJBQTBCLEdBQUcsb0JBQW9CLEdBQUcsVUFBVSxHQUFHLGFBQWEsR0FBRyxrQkFBa0IsR0FBRyx5QkFBeUIsR0FBRywwQkFBMEIsR0FBRyxzQkFBc0IsR0FBRyxlQUFlLEdBQUcsMkJBQTJCLEdBQUcsdUJBQXVCLEdBQUcsZUFBZSxHQUFHLGNBQWMsR0FBRyxvQkFBb0IsR0FBRyw2QkFBNkIsR0FBRyxvQkFBb0IsR0FBRyxjQUFjIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImRldnRvb2xzLUJwcjdaQVZCLmpzP3Y9N2U3M2FmYzIiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiLyohXG4qIHZ1ZS1yb3V0ZXIgdjUuMi4wXG4qIChjKSAyMDI2IEVkdWFyZG8gU2FuIE1hcnRpbiBNb3JvdGVcbiogQGxpY2Vuc2UgTUlUXG4qL1xuaW1wb3J0IHsgXyBhcyBpc1JvdXRlQ29tcG9uZW50LCBjIGFzIGRpYWdub3N0aWNzLCBnIGFzIGlzRVNNb2R1bGUsIGggYXMgaXNBcnJheSwgcCBhcyBhc3NpZ24sIHIgYXMgbWF0Y2hlZFJvdXRlS2V5LCB1IGFzIGNyZWF0ZVJvdXRlckVycm9yIH0gZnJvbSBcIi4vdXNlQXBpLUNST0pKZGhFLmpzXCI7XG5pbXBvcnQgeyBnZXRDdXJyZW50SW5zdGFuY2UsIGluamVjdCwgb25BY3RpdmF0ZWQsIG9uRGVhY3RpdmF0ZWQsIG9uVW5tb3VudGVkLCB3YXRjaCB9IGZyb20gXCJ2dWVcIjtcbmltcG9ydCB7IHNldHVwRGV2dG9vbHNQbHVnaW4gfSBmcm9tIFwiQHZ1ZS9kZXZ0b29scy1hcGlcIjtcbi8vI3JlZ2lvbiBzcmMvdXRpbHMvZW52LnRzXG5jb25zdCBpc0Jyb3dzZXIgPSB0eXBlb2YgZG9jdW1lbnQgIT09IFwidW5kZWZpbmVkXCI7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvZW5jb2RpbmcudHNcbi8qKlxuKiBFbmNvZGluZyBSdWxlcyAo4pCjID0gU3BhY2UpXG4qIC0gUGF0aDog4pCjIFwiIDwgPiAjID8geyB9XG4qIC0gUXVlcnk6IOKQoyBcIiA8ID4gIyAmID1cbiogLSBIYXNoOiDikKMgXCIgPCA+IGBcbipcbiogT24gdG9wIG9mIHRoYXQsIHRoZSBSRkMzOTg2IChodHRwczovL3Rvb2xzLmlldGYub3JnL2h0bWwvcmZjMzk4NiNzZWN0aW9uLTIuMilcbiogZGVmaW5lcyBzb21lIGV4dHJhIGNoYXJhY3RlcnMgdG8gYmUgZW5jb2RlZC4gTW9zdCBicm93c2VycyBkbyBub3QgZW5jb2RlIHRoZW1cbiogaW4gZW5jb2RlVVJJIGh0dHBzOi8vZ2l0aHViLmNvbS93aGF0d2cvdXJsL2lzc3Vlcy8zNjksIHNvIGl0IG1heSBiZSBzYWZlciB0b1xuKiBhbHNvIGVuY29kZSBgIScoKSpgLiBMZWF2aW5nIHVuLWVuY29kZWQgb25seSBBU0NJSSBhbHBoYW51bWVyaWMoYGEtekEtWjAtOWApXG4qIHBsdXMgYC0uX35gLiBUaGlzIGV4dHJhIHNhZmV0eSBzaG91bGQgYmUgYXBwbGllZCB0byBxdWVyeSBieSBwYXRjaGluZyB0aGVcbiogc3RyaW5nIHJldHVybmVkIGJ5IGVuY29kZVVSSUNvbXBvbmVudCBlbmNvZGVVUkkgYWxzbyBlbmNvZGVzIGBbXFxdXmAuIGBcXGBcbiogc2hvdWxkIGJlIGVuY29kZWQgdG8gYXZvaWQgYW1iaWd1aXR5LiBCcm93c2VycyAoSUUsIEZGLCBDKSB0cmFuc2Zvcm0gYSBgXFxgXG4qIGludG8gYSBgL2AgaWYgZGlyZWN0bHkgdHlwZWQgaW4uIFRoZSBfYmFja3RpY2tfIChgYGBgYCkgc2hvdWxkIGFsc28gYmVcbiogZW5jb2RlZCBldmVyeXdoZXJlIGJlY2F1c2Ugc29tZSBicm93c2VycyBsaWtlIEZGIGVuY29kZSBpdCB3aGVuIGRpcmVjdGx5XG4qIHdyaXR0ZW4gd2hpbGUgb3RoZXJzIGRvbid0LiBTYWZhcmkgYW5kIElFIGRvbid0IGVuY29kZSBgYFwiPD57fWBgYCBpbiBoYXNoLlxuKi9cbmNvbnN0IEhBU0hfUkUgPSAvIy9nO1xuY29uc3QgQU1QRVJTQU5EX1JFID0gLyYvZztcbmNvbnN0IFNMQVNIX1JFID0gL1xcLy9nO1xuY29uc3QgRVFVQUxfUkUgPSAvPS9nO1xuY29uc3QgSU1fUkUgPSAvXFw/L2c7XG5jb25zdCBQTFVTX1JFID0gL1xcKy9nO1xuLyoqXG4qIE5PVEU6IEl0J3Mgbm90IGNsZWFyIHRvIG1lIGlmIHdlIHNob3VsZCBlbmNvZGUgdGhlICsgc3ltYm9sIGluIHF1ZXJpZXMsIGl0XG4qIHNlZW1zIHRvIGJlIGxlc3MgZmxleGlibGUgdGhhbiBub3QgZG9pbmcgc28gYW5kIEkgY2FuJ3QgZmluZCBvdXQgdGhlIGxlZ2FjeVxuKiBzeXN0ZW1zIHJlcXVpcmluZyB0aGlzIGZvciByZWd1bGFyIHJlcXVlc3RzIGxpa2UgdGV4dC9odG1sLiBJbiB0aGUgc3RhbmRhcmQsXG4qIHRoZSBlbmNvZGluZyBvZiB0aGUgcGx1cyBjaGFyYWN0ZXIgaXMgb25seSBtZW50aW9uZWQgZm9yXG4qIGFwcGxpY2F0aW9uL3gtd3d3LWZvcm0tdXJsZW5jb2RlZFxuKiAoaHR0cHM6Ly91cmwuc3BlYy53aGF0d2cub3JnLyN1cmxlbmNvZGVkLXBhcnNpbmcpIGFuZCBtb3N0IGJyb3dzZXJzIHNlZW1zIGxvXG4qIGxlYXZlIHRoZSBwbHVzIGNoYXJhY3RlciBhcyBpcyBpbiBxdWVyaWVzLiBUbyBiZSBtb3JlIGZsZXhpYmxlLCB3ZSBhbGxvdyB0aGVcbiogcGx1cyBjaGFyYWN0ZXIgb24gdGhlIHF1ZXJ5LCBidXQgaXQgY2FuIGFsc28gYmUgbWFudWFsbHkgZW5jb2RlZCBieSB0aGUgdXNlci5cbipcbiogUmVzb3VyY2VzOlxuKiAtIGh0dHBzOi8vdXJsLnNwZWMud2hhdHdnLm9yZy8jdXJsZW5jb2RlZC1wYXJzaW5nXG4qIC0gaHR0cHM6Ly9zdGFja292ZXJmbG93LmNvbS9xdWVzdGlvbnMvMTYzNDI3MS91cmwtZW5jb2RpbmctdGhlLXNwYWNlLWNoYXJhY3Rlci1vci0yMFxuKi9cbmNvbnN0IEVOQ19CUkFDS0VUX09QRU5fUkUgPSAvJTVCL2c7XG5jb25zdCBFTkNfQlJBQ0tFVF9DTE9TRV9SRSA9IC8lNUQvZztcbmNvbnN0IEVOQ19DQVJFVF9SRSA9IC8lNUUvZztcbmNvbnN0IEVOQ19CQUNLVElDS19SRSA9IC8lNjAvZztcbmNvbnN0IEVOQ19DVVJMWV9PUEVOX1JFID0gLyU3Qi9nO1xuY29uc3QgRU5DX1BJUEVfUkUgPSAvJTdDL2c7XG5jb25zdCBFTkNfQ1VSTFlfQ0xPU0VfUkUgPSAvJTdEL2c7XG5jb25zdCBFTkNfU1BBQ0VfUkUgPSAvJTIwL2c7XG4vKipcbiogRW5jb2RlIGNoYXJhY3RlcnMgdGhhdCBuZWVkIHRvIGJlIGVuY29kZWQgb24gdGhlIHBhdGgsIHNlYXJjaCBhbmQgaGFzaFxuKiBzZWN0aW9ucyBvZiB0aGUgVVJMLlxuKlxuKiBAaW50ZXJuYWxcbiogQHBhcmFtIHRleHQgLSBzdHJpbmcgdG8gZW5jb2RlXG4qIEByZXR1cm5zIGVuY29kZWQgc3RyaW5nXG4qL1xuZnVuY3Rpb24gY29tbW9uRW5jb2RlKHRleHQpIHtcblx0cmV0dXJuIHRleHQgPT0gbnVsbCA/IFwiXCIgOiBlbmNvZGVVUkkoXCJcIiArIHRleHQpLnJlcGxhY2UoRU5DX1BJUEVfUkUsIFwifFwiKS5yZXBsYWNlKEVOQ19CUkFDS0VUX09QRU5fUkUsIFwiW1wiKS5yZXBsYWNlKEVOQ19CUkFDS0VUX0NMT1NFX1JFLCBcIl1cIik7XG59XG4vKipcbiogRW5jb2RlIGNoYXJhY3RlcnMgdGhhdCBuZWVkIHRvIGJlIGVuY29kZWQgb24gdGhlIGhhc2ggc2VjdGlvbiBvZiB0aGUgVVJMLlxuKlxuKiBAcGFyYW0gdGV4dCAtIHN0cmluZyB0byBlbmNvZGVcbiogQHJldHVybnMgZW5jb2RlZCBzdHJpbmdcbiovXG5mdW5jdGlvbiBlbmNvZGVIYXNoKHRleHQpIHtcblx0cmV0dXJuIGNvbW1vbkVuY29kZSh0ZXh0KS5yZXBsYWNlKEVOQ19DVVJMWV9PUEVOX1JFLCBcIntcIikucmVwbGFjZShFTkNfQ1VSTFlfQ0xPU0VfUkUsIFwifVwiKS5yZXBsYWNlKEVOQ19DQVJFVF9SRSwgXCJeXCIpO1xufVxuLyoqXG4qIEVuY29kZSBjaGFyYWN0ZXJzIHRoYXQgbmVlZCB0byBiZSBlbmNvZGVkIHF1ZXJ5IHZhbHVlcyBvbiB0aGUgcXVlcnlcbiogc2VjdGlvbiBvZiB0aGUgVVJMLlxuKlxuKiBAcGFyYW0gdGV4dCAtIHN0cmluZyB0byBlbmNvZGVcbiogQHJldHVybnMgZW5jb2RlZCBzdHJpbmdcbiovXG5mdW5jdGlvbiBlbmNvZGVRdWVyeVZhbHVlKHRleHQpIHtcblx0cmV0dXJuIGNvbW1vbkVuY29kZSh0ZXh0KS5yZXBsYWNlKFBMVVNfUkUsIFwiJTJCXCIpLnJlcGxhY2UoRU5DX1NQQUNFX1JFLCBcIitcIikucmVwbGFjZShIQVNIX1JFLCBcIiUyM1wiKS5yZXBsYWNlKEFNUEVSU0FORF9SRSwgXCIlMjZcIikucmVwbGFjZShFTkNfQkFDS1RJQ0tfUkUsIFwiYFwiKS5yZXBsYWNlKEVOQ19DVVJMWV9PUEVOX1JFLCBcIntcIikucmVwbGFjZShFTkNfQ1VSTFlfQ0xPU0VfUkUsIFwifVwiKS5yZXBsYWNlKEVOQ19DQVJFVF9SRSwgXCJeXCIpO1xufVxuLyoqXG4qIExpa2UgYGVuY29kZVF1ZXJ5VmFsdWVgIGJ1dCBhbHNvIGVuY29kZXMgdGhlIGA9YCBjaGFyYWN0ZXIuXG4qXG4qIEBwYXJhbSB0ZXh0IC0gc3RyaW5nIHRvIGVuY29kZVxuKi9cbmZ1bmN0aW9uIGVuY29kZVF1ZXJ5S2V5KHRleHQpIHtcblx0cmV0dXJuIGVuY29kZVF1ZXJ5VmFsdWUodGV4dCkucmVwbGFjZShFUVVBTF9SRSwgXCIlM0RcIik7XG59XG4vKipcbiogRW5jb2RlIGNoYXJhY3RlcnMgdGhhdCBuZWVkIHRvIGJlIGVuY29kZWQgb24gdGhlIHBhdGggc2VjdGlvbiBvZiB0aGUgVVJMLlxuKlxuKiBAcGFyYW0gdGV4dCAtIHN0cmluZyB0byBlbmNvZGVcbiogQHJldHVybnMgZW5jb2RlZCBzdHJpbmdcbiovXG5mdW5jdGlvbiBlbmNvZGVQYXRoKHRleHQpIHtcblx0cmV0dXJuIGNvbW1vbkVuY29kZSh0ZXh0KS5yZXBsYWNlKEhBU0hfUkUsIFwiJTIzXCIpLnJlcGxhY2UoSU1fUkUsIFwiJTNGXCIpO1xufVxuLyoqXG4qIEVuY29kZSBjaGFyYWN0ZXJzIHRoYXQgbmVlZCB0byBiZSBlbmNvZGVkIG9uIHRoZSBwYXRoIHNlY3Rpb24gb2YgdGhlIFVSTCBhcyBhXG4qIHBhcmFtLiBUaGlzIGZ1bmN0aW9uIGVuY29kZXMgZXZlcnl0aGluZyB7QGxpbmsgZW5jb2RlUGF0aH0gZG9lcyBwbHVzIHRoZVxuKiBzbGFzaCAoYC9gKSBjaGFyYWN0ZXIuIElmIGB0ZXh0YCBpcyBgbnVsbGAgb3IgYHVuZGVmaW5lZGAsIHJldHVybnMgYW4gZW1wdHlcbiogc3RyaW5nIGluc3RlYWQuXG4qXG4qIEBwYXJhbSB0ZXh0IC0gc3RyaW5nIHRvIGVuY29kZVxuKiBAcmV0dXJucyBlbmNvZGVkIHN0cmluZ1xuKi9cbmZ1bmN0aW9uIGVuY29kZVBhcmFtKHRleHQpIHtcblx0cmV0dXJuIGVuY29kZVBhdGgodGV4dCkucmVwbGFjZShTTEFTSF9SRSwgXCIlMkZcIik7XG59XG5mdW5jdGlvbiBkZWNvZGUodGV4dCkge1xuXHRpZiAodGV4dCA9PSBudWxsKSByZXR1cm4gbnVsbDtcblx0dHJ5IHtcblx0XHRyZXR1cm4gZGVjb2RlVVJJQ29tcG9uZW50KFwiXCIgKyB0ZXh0KTtcblx0fSBjYXRjaCB7XG5cdFx0cHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwODAoeyB0ZXh0OiBcIlwiICsgdGV4dCB9KTtcblx0fVxuXHRyZXR1cm4gXCJcIiArIHRleHQ7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbG9jYXRpb24udHNcbmNvbnN0IFRSQUlMSU5HX1NMQVNIX1JFID0gL1xcLyQvO1xuY29uc3QgcmVtb3ZlVHJhaWxpbmdTbGFzaCA9IChwYXRoKSA9PiBwYXRoLnJlcGxhY2UoVFJBSUxJTkdfU0xBU0hfUkUsIFwiXCIpO1xuLyoqXG4qIFRyYW5zZm9ybXMgYSBVUkkgaW50byBhIG5vcm1hbGl6ZWQgaGlzdG9yeSBsb2NhdGlvblxuKlxuKiBAcGFyYW0gcGFyc2VRdWVyeVxuKiBAcGFyYW0gbG9jYXRpb24gLSBVUkkgdG8gbm9ybWFsaXplXG4qIEBwYXJhbSBjdXJyZW50TG9jYXRpb24gLSBjdXJyZW50IGFic29sdXRlIGxvY2F0aW9uLiBBbGxvd3MgcmVzb2x2aW5nIHJlbGF0aXZlXG4qIHBhdGhzLiBNdXN0IHN0YXJ0IHdpdGggYC9gLiBEZWZhdWx0cyB0byBgL2BcbiogQHJldHVybnMgYSBub3JtYWxpemVkIGhpc3RvcnkgbG9jYXRpb25cbiovXG5mdW5jdGlvbiBwYXJzZVVSTChwYXJzZVF1ZXJ5LCBsb2NhdGlvbiwgY3VycmVudExvY2F0aW9uID0gXCIvXCIpIHtcblx0bGV0IHBhdGgsIHF1ZXJ5ID0ge30sIHNlYXJjaFN0cmluZyA9IFwiXCIsIGhhc2ggPSBcIlwiO1xuXHRjb25zdCBoYXNoUG9zID0gbG9jYXRpb24uaW5kZXhPZihcIiNcIik7XG5cdGxldCBzZWFyY2hQb3MgPSBsb2NhdGlvbi5pbmRleE9mKFwiP1wiKTtcblx0c2VhcmNoUG9zID0gaGFzaFBvcyA+PSAwICYmIHNlYXJjaFBvcyA+IGhhc2hQb3MgPyAtMSA6IHNlYXJjaFBvcztcblx0aWYgKHNlYXJjaFBvcyA+PSAwKSB7XG5cdFx0cGF0aCA9IGxvY2F0aW9uLnNsaWNlKDAsIHNlYXJjaFBvcyk7XG5cdFx0c2VhcmNoU3RyaW5nID0gbG9jYXRpb24uc2xpY2Uoc2VhcmNoUG9zLCBoYXNoUG9zID4gMCA/IGhhc2hQb3MgOiBsb2NhdGlvbi5sZW5ndGgpO1xuXHRcdHF1ZXJ5ID0gcGFyc2VRdWVyeShzZWFyY2hTdHJpbmcuc2xpY2UoMSkpO1xuXHR9XG5cdGlmIChoYXNoUG9zID49IDApIHtcblx0XHRwYXRoID0gcGF0aCB8fCBsb2NhdGlvbi5zbGljZSgwLCBoYXNoUG9zKTtcblx0XHRoYXNoID0gbG9jYXRpb24uc2xpY2UoaGFzaFBvcywgbG9jYXRpb24ubGVuZ3RoKTtcblx0fVxuXHRwYXRoID0gcmVzb2x2ZVJlbGF0aXZlUGF0aChwYXRoICE9IG51bGwgPyBwYXRoIDogbG9jYXRpb24sIGN1cnJlbnRMb2NhdGlvbik7XG5cdHJldHVybiB7XG5cdFx0ZnVsbFBhdGg6IHBhdGggKyBzZWFyY2hTdHJpbmcgKyBoYXNoLFxuXHRcdHBhdGgsXG5cdFx0cXVlcnksXG5cdFx0aGFzaDogZGVjb2RlKGhhc2gpXG5cdH07XG59XG5mdW5jdGlvbiBORVdfc3RyaW5naWZ5VVJMKHN0cmluZ2lmeVF1ZXJ5LCBwYXRoLCBxdWVyeSwgaGFzaCA9IFwiXCIpIHtcblx0Y29uc3Qgc2VhcmNoVGV4dCA9IHN0cmluZ2lmeVF1ZXJ5KHF1ZXJ5KTtcblx0cmV0dXJuIHBhdGggKyAoc2VhcmNoVGV4dCAmJiBcIj9cIikgKyBzZWFyY2hUZXh0ICsgZW5jb2RlSGFzaChoYXNoKTtcbn1cbi8qKlxuKiBTdHJpbmdpZmllcyBhIFVSTCBvYmplY3RcbipcbiogQHBhcmFtIHN0cmluZ2lmeVF1ZXJ5XG4qIEBwYXJhbSBsb2NhdGlvblxuKi9cbmZ1bmN0aW9uIHN0cmluZ2lmeVVSTChzdHJpbmdpZnlRdWVyeSwgbG9jYXRpb24pIHtcblx0Y29uc3QgcXVlcnkgPSBsb2NhdGlvbi5xdWVyeSA/IHN0cmluZ2lmeVF1ZXJ5KGxvY2F0aW9uLnF1ZXJ5KSA6IFwiXCI7XG5cdHJldHVybiBsb2NhdGlvbi5wYXRoICsgKHF1ZXJ5ICYmIFwiP1wiKSArIHF1ZXJ5ICsgKGxvY2F0aW9uLmhhc2ggfHwgXCJcIik7XG59XG4vKipcbiogU3RyaXBzIG9mZiB0aGUgYmFzZSBmcm9tIHRoZSBiZWdpbm5pbmcgb2YgYSBsb2NhdGlvbi5wYXRobmFtZSBpbiBhIG5vbi1jYXNlLXNlbnNpdGl2ZSB3YXkuXG4qXG4qIEBwYXJhbSBwYXRobmFtZSAtIGxvY2F0aW9uLnBhdGhuYW1lXG4qIEBwYXJhbSBiYXNlIC0gYmFzZSB0byBzdHJpcCBvZmZcbiovXG5mdW5jdGlvbiBzdHJpcEJhc2UocGF0aG5hbWUsIGJhc2UpIHtcblx0aWYgKCFiYXNlIHx8ICFwYXRobmFtZS50b0xvd2VyQ2FzZSgpLnN0YXJ0c1dpdGgoYmFzZS50b0xvd2VyQ2FzZSgpKSkgcmV0dXJuIHBhdGhuYW1lO1xuXHRyZXR1cm4gcGF0aG5hbWUuc2xpY2UoYmFzZS5sZW5ndGgpIHx8IFwiL1wiO1xufVxuLyoqXG4qIENoZWNrcyBpZiB0d28gUm91dGVMb2NhdGlvbiBhcmUgZXF1YWwuIFRoaXMgbWVhbnMgdGhhdCBib3RoIGxvY2F0aW9ucyBhcmVcbiogcG9pbnRpbmcgdG93YXJkcyB0aGUgc2FtZSB7QGxpbmsgUm91dGVSZWNvcmR9IGFuZCB0aGF0IGFsbCBgcGFyYW1zYCwgYHF1ZXJ5YFxuKiBwYXJhbWV0ZXJzIGFuZCBgaGFzaGAgYXJlIHRoZSBzYW1lXG4qXG4qIEBwYXJhbSBzdHJpbmdpZnlRdWVyeSAtIEEgZnVuY3Rpb24gdGhhdCB0YWtlcyBhIHF1ZXJ5IG9iamVjdCBvZiB0eXBlIExvY2F0aW9uUXVlcnlSYXcgYW5kIHJldHVybnMgYSBzdHJpbmcgcmVwcmVzZW50YXRpb24gb2YgaXQuXG4qIEBwYXJhbSBhIC0gZmlyc3Qge0BsaW5rIFJvdXRlTG9jYXRpb259XG4qIEBwYXJhbSBiIC0gc2Vjb25kIHtAbGluayBSb3V0ZUxvY2F0aW9ufVxuKi9cbmZ1bmN0aW9uIGlzU2FtZVJvdXRlTG9jYXRpb24oc3RyaW5naWZ5UXVlcnksIGEsIGIpIHtcblx0Y29uc3QgYUxhc3RJbmRleCA9IGEubWF0Y2hlZC5sZW5ndGggLSAxO1xuXHRjb25zdCBiTGFzdEluZGV4ID0gYi5tYXRjaGVkLmxlbmd0aCAtIDE7XG5cdHJldHVybiBhTGFzdEluZGV4ID4gLTEgJiYgYUxhc3RJbmRleCA9PT0gYkxhc3RJbmRleCAmJiBpc1NhbWVSb3V0ZVJlY29yZChhLm1hdGNoZWRbYUxhc3RJbmRleF0sIGIubWF0Y2hlZFtiTGFzdEluZGV4XSkgJiYgaXNTYW1lUm91dGVMb2NhdGlvblBhcmFtcyhhLnBhcmFtcywgYi5wYXJhbXMpICYmIHN0cmluZ2lmeVF1ZXJ5KGEucXVlcnkpID09PSBzdHJpbmdpZnlRdWVyeShiLnF1ZXJ5KSAmJiBhLmhhc2ggPT09IGIuaGFzaDtcbn1cbi8qKlxuKiBDaGVjayBpZiB0d28gYFJvdXRlUmVjb3Jkc2AgYXJlIGVxdWFsLiBUYWtlcyBpbnRvIGFjY291bnQgYWxpYXNlczogdGhleSBhcmVcbiogY29uc2lkZXJlZCBlcXVhbCB0byB0aGUgYFJvdXRlUmVjb3JkYCB0aGV5IGFyZSBhbGlhc2luZy5cbipcbiogQHBhcmFtIGEgLSBmaXJzdCB7QGxpbmsgUm91dGVSZWNvcmR9XG4qIEBwYXJhbSBiIC0gc2Vjb25kIHtAbGluayBSb3V0ZVJlY29yZH1cbiovXG5mdW5jdGlvbiBpc1NhbWVSb3V0ZVJlY29yZChhLCBiKSB7XG5cdHJldHVybiAoYS5hbGlhc09mIHx8IGEpID09PSAoYi5hbGlhc09mIHx8IGIpO1xufVxuZnVuY3Rpb24gaXNTYW1lUm91dGVMb2NhdGlvblBhcmFtcyhhLCBiKSB7XG5cdGlmIChPYmplY3Qua2V5cyhhKS5sZW5ndGggIT09IE9iamVjdC5rZXlzKGIpLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuXHRmb3IgKHZhciBrZXkgaW4gYSkgaWYgKCFpc1NhbWVSb3V0ZUxvY2F0aW9uUGFyYW1zVmFsdWUoYVtrZXldLCBiW2tleV0pKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gaXNTYW1lUm91dGVMb2NhdGlvblBhcmFtc1ZhbHVlKGEsIGIpIHtcblx0cmV0dXJuIGlzQXJyYXkoYSkgPyBpc0VxdWl2YWxlbnRBcnJheShhLCBiKSA6IGlzQXJyYXkoYikgPyBpc0VxdWl2YWxlbnRBcnJheShiLCBhKSA6IChhICYmIGEudmFsdWVPZigpKSA9PT0gKGIgJiYgYi52YWx1ZU9mKCkpO1xufVxuLyoqXG4qIENoZWNrIGlmIHR3byBhcnJheXMgYXJlIHRoZSBzYW1lIG9yIGlmIGFuIGFycmF5IHdpdGggb25lIHNpbmdsZSBlbnRyeSBpcyB0aGVcbiogc2FtZSBhcyBhbm90aGVyIHByaW1pdGl2ZSB2YWx1ZS4gVXNlZCB0byBjaGVjayBxdWVyeSBhbmQgcGFyYW1ldGVyc1xuKlxuKiBAcGFyYW0gYSAtIGFycmF5IG9mIHZhbHVlc1xuKiBAcGFyYW0gYiAtIGFycmF5IG9mIHZhbHVlcyBvciBhIHNpbmdsZSB2YWx1ZVxuKi9cbmZ1bmN0aW9uIGlzRXF1aXZhbGVudEFycmF5KGEsIGIpIHtcblx0cmV0dXJuIGlzQXJyYXkoYikgPyBhLmxlbmd0aCA9PT0gYi5sZW5ndGggJiYgYS5ldmVyeSgodmFsdWUsIGkpID0+IHZhbHVlID09PSBiW2ldKSA6IGEubGVuZ3RoID09PSAxICYmIGFbMF0gPT09IGI7XG59XG4vKipcbiogUmVzb2x2ZXMgYSByZWxhdGl2ZSBwYXRoIHRoYXQgc3RhcnRzIHdpdGggYC5gLlxuKlxuKiBAcGFyYW0gdG8gLSBwYXRoIGxvY2F0aW9uIHdlIGFyZSByZXNvbHZpbmdcbiogQHBhcmFtIGZyb20gLSBjdXJyZW50TG9jYXRpb24ucGF0aCwgc2hvdWxkIHN0YXJ0IHdpdGggYC9gXG4qL1xuZnVuY3Rpb24gcmVzb2x2ZVJlbGF0aXZlUGF0aCh0bywgZnJvbSkge1xuXHRpZiAodG8uc3RhcnRzV2l0aChcIi9cIikpIHJldHVybiB0bztcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhZnJvbS5zdGFydHNXaXRoKFwiL1wiKSkge1xuXHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwNzAoe1xuXHRcdFx0dG8sXG5cdFx0XHRmcm9tXG5cdFx0fSk7XG5cdFx0cmV0dXJuIHRvO1xuXHR9XG5cdGlmICghdG8pIHJldHVybiBmcm9tO1xuXHRjb25zdCBmcm9tU2VnbWVudHMgPSBmcm9tLnNwbGl0KFwiL1wiKTtcblx0Y29uc3QgdG9TZWdtZW50cyA9IHRvLnNwbGl0KFwiL1wiKTtcblx0Y29uc3QgbGFzdFRvU2VnbWVudCA9IHRvU2VnbWVudHNbdG9TZWdtZW50cy5sZW5ndGggLSAxXTtcblx0aWYgKGxhc3RUb1NlZ21lbnQgPT09IFwiLi5cIiB8fCBsYXN0VG9TZWdtZW50ID09PSBcIi5cIikgdG9TZWdtZW50cy5wdXNoKFwiXCIpO1xuXHRsZXQgcG9zaXRpb24gPSBmcm9tU2VnbWVudHMubGVuZ3RoIC0gMTtcblx0bGV0IHRvUG9zaXRpb247XG5cdGxldCBzZWdtZW50O1xuXHRmb3IgKHRvUG9zaXRpb24gPSAwOyB0b1Bvc2l0aW9uIDwgdG9TZWdtZW50cy5sZW5ndGg7IHRvUG9zaXRpb24rKykge1xuXHRcdHNlZ21lbnQgPSB0b1NlZ21lbnRzW3RvUG9zaXRpb25dO1xuXHRcdGlmIChzZWdtZW50ID09PSBcIi5cIikgY29udGludWU7XG5cdFx0aWYgKHNlZ21lbnQgPT09IFwiLi5cIikge1xuXHRcdFx0aWYgKHBvc2l0aW9uID4gMSkgcG9zaXRpb24tLTtcblx0XHR9IGVsc2UgYnJlYWs7XG5cdH1cblx0cmV0dXJuIGZyb21TZWdtZW50cy5zbGljZSgwLCBwb3NpdGlvbikuam9pbihcIi9cIikgKyBcIi9cIiArIHRvU2VnbWVudHMuc2xpY2UodG9Qb3NpdGlvbikuam9pbihcIi9cIik7XG59XG4vKipcbiogSW5pdGlhbCByb3V0ZSBsb2NhdGlvbiB3aGVyZSB0aGUgcm91dGVyIGlzLiBDYW4gYmUgdXNlZCBpbiBuYXZpZ2F0aW9uIGd1YXJkc1xuKiB0byBkaWZmZXJlbnRpYXRlIHRoZSBpbml0aWFsIG5hdmlnYXRpb24uXG4qXG4qIEBleGFtcGxlXG4qIGBgYGpzXG4qIGltcG9ydCB7IFNUQVJUX0xPQ0FUSU9OIH0gZnJvbSAndnVlLXJvdXRlcidcbipcbiogcm91dGVyLmJlZm9yZUVhY2goKHRvLCBmcm9tKSA9PiB7XG4qICAgaWYgKGZyb20gPT09IFNUQVJUX0xPQ0FUSU9OKSB7XG4qICAgICAvLyBpbml0aWFsIG5hdmlnYXRpb25cbiogICB9XG4qIH0pXG4qIGBgYFxuKi9cbmNvbnN0IFNUQVJUX0xPQ0FUSU9OX05PUk1BTElaRUQgPSB7XG5cdHBhdGg6IFwiL1wiLFxuXHRuYW1lOiB2b2lkIDAsXG5cdHBhcmFtczoge30sXG5cdHF1ZXJ5OiB7fSxcblx0aGFzaDogXCJcIixcblx0ZnVsbFBhdGg6IFwiL1wiLFxuXHRtYXRjaGVkOiBbXSxcblx0bWV0YToge30sXG5cdHJlZGlyZWN0ZWRGcm9tOiB2b2lkIDBcbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvaGlzdG9yeS9jb21tb24udHNcbi8qKlxuKiBOb3JtYWxpemVzIGEgYmFzZSBieSByZW1vdmluZyBhbnkgdHJhaWxpbmcgc2xhc2ggYW5kIHJlYWRpbmcgdGhlIGJhc2UgdGFnIGlmXG4qIHByZXNlbnQuXG4qXG4qIEBwYXJhbSBiYXNlIC0gYmFzZSB0byBub3JtYWxpemVcbiovXG5mdW5jdGlvbiBub3JtYWxpemVCYXNlKGJhc2UpIHtcblx0aWYgKCFiYXNlKSBpZiAoaXNCcm93c2VyKSB7XG5cdFx0Y29uc3QgYmFzZUVsID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcImJhc2VcIik7XG5cdFx0YmFzZSA9IGJhc2VFbCAmJiBiYXNlRWwuZ2V0QXR0cmlidXRlKFwiaHJlZlwiKSB8fCBcIi9cIjtcblx0XHRiYXNlID0gYmFzZS5yZXBsYWNlKC9eXFx3KzpcXC9cXC9bXi9dKy8sIFwiXCIpO1xuXHR9IGVsc2UgYmFzZSA9IFwiL1wiO1xuXHRpZiAoYmFzZVswXSAhPT0gXCIvXCIgJiYgYmFzZVswXSAhPT0gXCIjXCIpIGJhc2UgPSBcIi9cIiArIGJhc2U7XG5cdHJldHVybiByZW1vdmVUcmFpbGluZ1NsYXNoKGJhc2UpO1xufVxuY29uc3QgQkVGT1JFX0hBU0hfUkUgPSAvXlteI10rIy87XG5mdW5jdGlvbiBjcmVhdGVIcmVmKGJhc2UsIGxvY2F0aW9uKSB7XG5cdHJldHVybiBiYXNlLnJlcGxhY2UoQkVGT1JFX0hBU0hfUkUsIFwiI1wiKSArIGxvY2F0aW9uO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3Njcm9sbEJlaGF2aW9yLnRzXG5mdW5jdGlvbiBnZXRFbGVtZW50UG9zaXRpb24oZWwsIG9mZnNldCkge1xuXHRjb25zdCBkb2NSZWN0ID0gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuXHRjb25zdCBlbFJlY3QgPSBlbC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcblx0cmV0dXJuIHtcblx0XHRiZWhhdmlvcjogb2Zmc2V0LmJlaGF2aW9yLFxuXHRcdGxlZnQ6IGVsUmVjdC5sZWZ0IC0gZG9jUmVjdC5sZWZ0IC0gKG9mZnNldC5sZWZ0IHx8IDApLFxuXHRcdHRvcDogZWxSZWN0LnRvcCAtIGRvY1JlY3QudG9wIC0gKG9mZnNldC50b3AgfHwgMClcblx0fTtcbn1cbmNvbnN0IGNvbXB1dGVTY3JvbGxQb3NpdGlvbiA9ICgpID0+ICh7XG5cdGxlZnQ6IHdpbmRvdy5zY3JvbGxYLFxuXHR0b3A6IHdpbmRvdy5zY3JvbGxZXG59KTtcbmZ1bmN0aW9uIHNjcm9sbFRvUG9zaXRpb24ocG9zaXRpb24pIHtcblx0bGV0IHNjcm9sbFRvT3B0aW9ucztcblx0aWYgKFwiZWxcIiBpbiBwb3NpdGlvbikge1xuXHRcdGNvbnN0IHBvc2l0aW9uRWwgPSBwb3NpdGlvbi5lbDtcblx0XHRjb25zdCBpc0lkU2VsZWN0b3IgPSB0eXBlb2YgcG9zaXRpb25FbCA9PT0gXCJzdHJpbmdcIiAmJiBwb3NpdGlvbkVsLnN0YXJ0c1dpdGgoXCIjXCIpO1xuXHRcdC8qKlxuXHRcdCogYGlkYHMgY2FuIGFjY2VwdCBwcmV0dHkgbXVjaCBhbnkgY2hhcmFjdGVycywgaW5jbHVkaW5nIENTUyBjb21iaW5hdG9yc1xuXHRcdCogbGlrZSBgPmAgb3IgYH5gLiBJdCdzIHN0aWxsIHBvc3NpYmxlIHRvIHJldHJpZXZlIGVsZW1lbnRzIHVzaW5nXG5cdFx0KiBgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ34nKWAgYnV0IGl0IG5lZWRzIHRvIGJlIGVzY2FwZWQgd2hlbiB1c2luZ1xuXHRcdCogYGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNcXFxcficpYCBmb3IgaXQgdG8gYmUgdmFsaWQuIFRoZSBvbmx5XG5cdFx0KiByZXF1aXJlbWVudHMgZm9yIGBpZGBzIGFyZSB0aGVtIHRvIGJlIHVuaXF1ZSBvbiB0aGUgcGFnZSBhbmQgdG8gbm90IGJlXG5cdFx0KiBlbXB0eSAoYGlkPVwiXCJgKS4gQmVjYXVzZSBvZiB0aGF0LCB3aGVuIHBhc3NpbmcgYW4gaWQgc2VsZWN0b3IsIGl0IHNob3VsZFxuXHRcdCogYmUgcHJvcGVybHkgZXNjYXBlZCBmb3IgaXQgdG8gd29yayB3aXRoIGBxdWVyeVNlbGVjdG9yYC4gV2UgY291bGQgY2hlY2tcblx0XHQqIGZvciB0aGUgaWQgc2VsZWN0b3IgdG8gYmUgc2ltcGxlIChubyBDU1MgY29tYmluYXRvcnMgYCsgPn5gKSBidXQgdGhhdFxuXHRcdCogd291bGQgbWFrZSB0aGluZ3MgaW5jb25zaXN0ZW50IHNpbmNlIHRoZXkgYXJlIHZhbGlkIGNoYXJhY3RlcnMgZm9yIGFuXG5cdFx0KiBgaWRgIGJ1dCB3b3VsZCBuZWVkIHRvIGJlIGVzY2FwZWQgd2hlbiB1c2luZyBgcXVlcnlTZWxlY3RvcmAsIGJyZWFraW5nXG5cdFx0KiB0aGVpciB1c2FnZSBhbmQgZW5kaW5nIHVwIGluIG5vIHNlbGVjdG9yIHJldHVybmVkLiBTZWxlY3RvcnMgbmVlZCB0byBiZVxuXHRcdCogZXNjYXBlZDpcblx0XHQqXG5cdFx0KiAtIGAjMS10aGluZ2AgYmVjb21lcyBgI1xcMzEgLXRoaW5nYFxuXHRcdCogLSBgI3dpdGh+c3ltYm9sc2AgYmVjb21lcyBgI3dpdGhcXFxcfnN5bWJvbHNgXG5cdFx0KlxuXHRcdCogLSBNb3JlIGluZm9ybWF0aW9uIGFib3V0ICB0aGUgdG9waWMgY2FuIGJlIGZvdW5kIGF0XG5cdFx0KiAgIGh0dHBzOi8vbWF0aGlhc2J5bmVucy5iZS9ub3Rlcy9odG1sNS1pZC1jbGFzcy5cblx0XHQqIC0gUHJhY3RpY2FsIGV4YW1wbGU6IGh0dHBzOi8vbWF0aGlhc2J5bmVucy5iZS9kZW1vL2h0bWw1LWlkXG5cdFx0Ki9cblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIHR5cGVvZiBwb3NpdGlvbi5lbCA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0aWYgKCFpc0lkU2VsZWN0b3IgfHwgIWRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHBvc2l0aW9uLmVsLnNsaWNlKDEpKSkgdHJ5IHtcblx0XHRcdFx0Y29uc3QgZm91bmRFbCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IocG9zaXRpb24uZWwpO1xuXHRcdFx0XHRpZiAoaXNJZFNlbGVjdG9yICYmIGZvdW5kRWwpIHtcblx0XHRcdFx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDQwKHsgZWw6IHBvc2l0aW9uLmVsIH0pO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwNDEoeyBlbDogcG9zaXRpb24uZWwgfSk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHR9XG5cdFx0Y29uc3QgZWwgPSB0eXBlb2YgcG9zaXRpb25FbCA9PT0gXCJzdHJpbmdcIiA/IGlzSWRTZWxlY3RvciA/IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHBvc2l0aW9uRWwuc2xpY2UoMSkpIDogZG9jdW1lbnQucXVlcnlTZWxlY3Rvcihwb3NpdGlvbkVsKSA6IHBvc2l0aW9uRWw7XG5cdFx0aWYgKCFlbCkge1xuXHRcdFx0cHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwNDIoeyBlbDogcG9zaXRpb24uZWwgfSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdHNjcm9sbFRvT3B0aW9ucyA9IGdldEVsZW1lbnRQb3NpdGlvbihlbCwgcG9zaXRpb24pO1xuXHR9IGVsc2Ugc2Nyb2xsVG9PcHRpb25zID0gcG9zaXRpb247XG5cdGlmIChcInNjcm9sbEJlaGF2aW9yXCIgaW4gZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LnN0eWxlKSB3aW5kb3cuc2Nyb2xsVG8oc2Nyb2xsVG9PcHRpb25zKTtcblx0ZWxzZSB3aW5kb3cuc2Nyb2xsVG8oc2Nyb2xsVG9PcHRpb25zLmxlZnQgIT0gbnVsbCA/IHNjcm9sbFRvT3B0aW9ucy5sZWZ0IDogd2luZG93LnNjcm9sbFgsIHNjcm9sbFRvT3B0aW9ucy50b3AgIT0gbnVsbCA/IHNjcm9sbFRvT3B0aW9ucy50b3AgOiB3aW5kb3cuc2Nyb2xsWSk7XG59XG5mdW5jdGlvbiBnZXRTY3JvbGxLZXkocGF0aCwgZGVsdGEpIHtcblx0cmV0dXJuIChoaXN0b3J5LnN0YXRlID8gaGlzdG9yeS5zdGF0ZS5wb3NpdGlvbiAtIGRlbHRhIDogLTEpICsgcGF0aDtcbn1cbmNvbnN0IHNjcm9sbFBvc2l0aW9ucyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5mdW5jdGlvbiBzYXZlU2Nyb2xsUG9zaXRpb24oa2V5LCBzY3JvbGxQb3NpdGlvbikge1xuXHRzY3JvbGxQb3NpdGlvbnMuc2V0KGtleSwgc2Nyb2xsUG9zaXRpb24pO1xufVxuZnVuY3Rpb24gZ2V0U2F2ZWRTY3JvbGxQb3NpdGlvbihrZXkpIHtcblx0Y29uc3Qgc2Nyb2xsID0gc2Nyb2xsUG9zaXRpb25zLmdldChrZXkpO1xuXHRzY3JvbGxQb3NpdGlvbnMuZGVsZXRlKGtleSk7XG5cdHJldHVybiBzY3JvbGw7XG59XG4vKipcbiogU2Nyb2xsQmVoYXZpb3IgaW5zdGFuY2UgdXNlZCBieSB0aGUgcm91dGVyIHRvIGNvbXB1dGUgYW5kIHJlc3RvcmUgdGhlIHNjcm9sbFxuKiBwb3NpdGlvbiB3aGVuIG5hdmlnYXRpbmcuXG4qL1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3R5cGVzL3R5cGVHdWFyZHMudHNcbmZ1bmN0aW9uIGlzUm91dGVMb2NhdGlvbihyb3V0ZSkge1xuXHRyZXR1cm4gdHlwZW9mIHJvdXRlID09PSBcInN0cmluZ1wiIHx8IHJvdXRlICYmIHR5cGVvZiByb3V0ZSA9PT0gXCJvYmplY3RcIjtcbn1cbmZ1bmN0aW9uIGlzUm91dGVOYW1lKG5hbWUpIHtcblx0cmV0dXJuIHR5cGVvZiBuYW1lID09PSBcInN0cmluZ1wiIHx8IHR5cGVvZiBuYW1lID09PSBcInN5bWJvbFwiO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3F1ZXJ5LnRzXG4vKipcbiogVHJhbnNmb3JtcyBhIHF1ZXJ5U3RyaW5nIGludG8gYSB7QGxpbmsgTG9jYXRpb25RdWVyeX0gb2JqZWN0LiBBY2NlcHQgYm90aCwgYVxuKiB2ZXJzaW9uIHdpdGggdGhlIGxlYWRpbmcgYD9gIGFuZCB3aXRob3V0IFNob3VsZCB3b3JrIGFzIFVSTFNlYXJjaFBhcmFtc1xuXG4qIEBpbnRlcm5hbFxuKlxuKiBAcGFyYW0gc2VhcmNoIC0gc2VhcmNoIHN0cmluZyB0byBwYXJzZVxuKiBAcmV0dXJucyBhIHF1ZXJ5IG9iamVjdFxuKi9cbmZ1bmN0aW9uIHBhcnNlUXVlcnkoc2VhcmNoKSB7XG5cdGNvbnN0IHF1ZXJ5ID0ge307XG5cdGlmIChzZWFyY2ggPT09IFwiXCIgfHwgc2VhcmNoID09PSBcIj9cIikgcmV0dXJuIHF1ZXJ5O1xuXHRjb25zdCBzZWFyY2hQYXJhbXMgPSAoc2VhcmNoWzBdID09PSBcIj9cIiA/IHNlYXJjaC5zbGljZSgxKSA6IHNlYXJjaCkuc3BsaXQoXCImXCIpO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IHNlYXJjaFBhcmFtcy5sZW5ndGg7ICsraSkge1xuXHRcdGNvbnN0IHNlYXJjaFBhcmFtID0gc2VhcmNoUGFyYW1zW2ldLnJlcGxhY2UoUExVU19SRSwgXCIgXCIpO1xuXHRcdGNvbnN0IGVxUG9zID0gc2VhcmNoUGFyYW0uaW5kZXhPZihcIj1cIik7XG5cdFx0Y29uc3Qga2V5ID0gZGVjb2RlKGVxUG9zIDwgMCA/IHNlYXJjaFBhcmFtIDogc2VhcmNoUGFyYW0uc2xpY2UoMCwgZXFQb3MpKTtcblx0XHRjb25zdCB2YWx1ZSA9IGVxUG9zIDwgMCA/IG51bGwgOiBkZWNvZGUoc2VhcmNoUGFyYW0uc2xpY2UoZXFQb3MgKyAxKSk7XG5cdFx0aWYgKGtleSBpbiBxdWVyeSkge1xuXHRcdFx0bGV0IGN1cnJlbnRWYWx1ZSA9IHF1ZXJ5W2tleV07XG5cdFx0XHRpZiAoIWlzQXJyYXkoY3VycmVudFZhbHVlKSkgY3VycmVudFZhbHVlID0gcXVlcnlba2V5XSA9IFtjdXJyZW50VmFsdWVdO1xuXHRcdFx0Y3VycmVudFZhbHVlLnB1c2godmFsdWUpO1xuXHRcdH0gZWxzZSBxdWVyeVtrZXldID0gdmFsdWU7XG5cdH1cblx0cmV0dXJuIHF1ZXJ5O1xufVxuLyoqXG4qIFN0cmluZ2lmaWVzIGEge0BsaW5rIExvY2F0aW9uUXVlcnlSYXd9IG9iamVjdC4gTGlrZSBgVVJMU2VhcmNoUGFyYW1zYCwgaXRcbiogZG9lc24ndCBwcmVwZW5kIGEgYD9gXG4qXG4qIEBpbnRlcm5hbFxuKlxuKiBAcGFyYW0gcXVlcnkgLSBxdWVyeSBvYmplY3QgdG8gc3RyaW5naWZ5XG4qIEByZXR1cm5zIHN0cmluZyB2ZXJzaW9uIG9mIHRoZSBxdWVyeSB3aXRob3V0IHRoZSBsZWFkaW5nIGA/YFxuKi9cbmZ1bmN0aW9uIHN0cmluZ2lmeVF1ZXJ5KHF1ZXJ5KSB7XG5cdGxldCBzZWFyY2ggPSBcIlwiO1xuXHRmb3IgKGxldCBrZXkgaW4gcXVlcnkpIHtcblx0XHRjb25zdCB2YWx1ZSA9IHF1ZXJ5W2tleV07XG5cdFx0a2V5ID0gZW5jb2RlUXVlcnlLZXkoa2V5KTtcblx0XHRpZiAodmFsdWUgPT0gbnVsbCkge1xuXHRcdFx0aWYgKHZhbHVlICE9PSB2b2lkIDApIHNlYXJjaCArPSAoc2VhcmNoLmxlbmd0aCA/IFwiJlwiIDogXCJcIikgKyBrZXk7XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0KGlzQXJyYXkodmFsdWUpID8gdmFsdWUubWFwKCh2KSA9PiB2ICYmIGVuY29kZVF1ZXJ5VmFsdWUodikpIDogW3ZhbHVlICYmIGVuY29kZVF1ZXJ5VmFsdWUodmFsdWUpXSkuZm9yRWFjaCgodmFsdWUpID0+IHtcblx0XHRcdGlmICh2YWx1ZSAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdHNlYXJjaCArPSAoc2VhcmNoLmxlbmd0aCA/IFwiJlwiIDogXCJcIikgKyBrZXk7XG5cdFx0XHRcdGlmICh2YWx1ZSAhPSBudWxsKSBzZWFyY2ggKz0gXCI9XCIgKyB2YWx1ZTtcblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXHRyZXR1cm4gc2VhcmNoO1xufVxuLyoqXG4qIFRyYW5zZm9ybXMgYSB7QGxpbmsgTG9jYXRpb25RdWVyeVJhd30gaW50byBhIHtAbGluayBMb2NhdGlvblF1ZXJ5fSBieSBjYXN0aW5nXG4qIG51bWJlcnMgaW50byBzdHJpbmdzLCByZW1vdmluZyBrZXlzIHdpdGggYW4gdW5kZWZpbmVkIHZhbHVlIGFuZCByZXBsYWNpbmdcbiogdW5kZWZpbmVkIHdpdGggbnVsbCBpbiBhcnJheXNcbipcbiogQHBhcmFtIHF1ZXJ5IC0gcXVlcnkgb2JqZWN0IHRvIG5vcm1hbGl6ZVxuKiBAcmV0dXJucyBhIG5vcm1hbGl6ZWQgcXVlcnkgb2JqZWN0XG4qL1xuZnVuY3Rpb24gbm9ybWFsaXplUXVlcnkocXVlcnkpIHtcblx0Y29uc3Qgbm9ybWFsaXplZFF1ZXJ5ID0ge307XG5cdGZvciAoY29uc3Qga2V5IGluIHF1ZXJ5KSB7XG5cdFx0Y29uc3QgdmFsdWUgPSBxdWVyeVtrZXldO1xuXHRcdGlmICh2YWx1ZSAhPT0gdm9pZCAwKSBub3JtYWxpemVkUXVlcnlba2V5XSA9IGlzQXJyYXkodmFsdWUpID8gdmFsdWUubWFwKCh2KSA9PiB2ID09IG51bGwgPyBudWxsIDogXCJcIiArIHYpIDogdmFsdWUgPT0gbnVsbCA/IHZhbHVlIDogXCJcIiArIHZhbHVlO1xuXHR9XG5cdHJldHVybiBub3JtYWxpemVkUXVlcnk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdXRpbHMvY2FsbGJhY2tzLnRzXG4vKipcbiogQ3JlYXRlIGEgbGlzdCBvZiBjYWxsYmFja3MgdGhhdCBjYW4gYmUgcmVzZXQuIFVzZWQgdG8gY3JlYXRlIGJlZm9yZSBhbmQgYWZ0ZXIgbmF2aWdhdGlvbiBndWFyZHMgbGlzdFxuKi9cbmZ1bmN0aW9uIHVzZUNhbGxiYWNrcygpIHtcblx0bGV0IGhhbmRsZXJzID0gW107XG5cdGZ1bmN0aW9uIGFkZChoYW5kbGVyKSB7XG5cdFx0aGFuZGxlcnMucHVzaChoYW5kbGVyKTtcblx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0Y29uc3QgaSA9IGhhbmRsZXJzLmluZGV4T2YoaGFuZGxlcik7XG5cdFx0XHRpZiAoaSA+IC0xKSBoYW5kbGVycy5zcGxpY2UoaSwgMSk7XG5cdFx0fTtcblx0fVxuXHRmdW5jdGlvbiByZXNldCgpIHtcblx0XHRoYW5kbGVycyA9IFtdO1xuXHR9XG5cdHJldHVybiB7XG5cdFx0YWRkLFxuXHRcdGxpc3Q6ICgpID0+IGhhbmRsZXJzLnNsaWNlKCksXG5cdFx0cmVzZXRcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9uYXZpZ2F0aW9uR3VhcmRzLnRzXG5mdW5jdGlvbiByZWdpc3Rlckd1YXJkKGFjdGl2ZVJlY29yZFJlZiwgbmFtZSwgZ3VhcmQpIHtcblx0Y29uc3QgcmVjb3JkID0gYWN0aXZlUmVjb3JkUmVmLnZhbHVlO1xuXHRpZiAoIXJlY29yZCkge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRcdGNvbnN0IGZuTmFtZSA9IG5hbWUgPT09IFwidXBkYXRlR3VhcmRzXCIgPyBcIm9uQmVmb3JlUm91dGVVcGRhdGVcIiA6IFwib25CZWZvcmVSb3V0ZUxlYXZlXCI7XG5cdFx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDIwKHsgZm46IGZuTmFtZSB9KTtcblx0XHR9XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGxldCBjdXJyZW50UmVjb3JkID0gcmVjb3JkO1xuXHRjb25zdCByZW1vdmVGcm9tTGlzdCA9ICgpID0+IHtcblx0XHRjdXJyZW50UmVjb3JkW25hbWVdLmRlbGV0ZShndWFyZCk7XG5cdH07XG5cdG9uVW5tb3VudGVkKHJlbW92ZUZyb21MaXN0KTtcblx0b25EZWFjdGl2YXRlZChyZW1vdmVGcm9tTGlzdCk7XG5cdG9uQWN0aXZhdGVkKCgpID0+IHtcblx0XHRjb25zdCBuZXdSZWNvcmQgPSBhY3RpdmVSZWNvcmRSZWYudmFsdWU7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhbmV3UmVjb3JkKSBkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDIxKCk7XG5cdFx0aWYgKG5ld1JlY29yZCkgY3VycmVudFJlY29yZCA9IG5ld1JlY29yZDtcblx0XHRjdXJyZW50UmVjb3JkW25hbWVdLmFkZChndWFyZCk7XG5cdH0pO1xuXHRjdXJyZW50UmVjb3JkW25hbWVdLmFkZChndWFyZCk7XG59XG4vKipcbiogQWRkIGEgbmF2aWdhdGlvbiBndWFyZCB0aGF0IHRyaWdnZXJzIHdoZW5ldmVyIHRoZSBjb21wb25lbnQgZm9yIHRoZSBjdXJyZW50XG4qIGxvY2F0aW9uIGlzIGFib3V0IHRvIGJlIGxlZnQuIFNpbWlsYXIgdG8ge0BsaW5rIGJlZm9yZVJvdXRlTGVhdmV9IGJ1dCBjYW4gYmVcbiogdXNlZCBpbiBhbnkgY29tcG9uZW50LiBUaGUgZ3VhcmQgaXMgcmVtb3ZlZCB3aGVuIHRoZSBjb21wb25lbnQgaXMgdW5tb3VudGVkLlxuKlxuKiBAcGFyYW0gbGVhdmVHdWFyZCAtIHtAbGluayBOYXZpZ2F0aW9uR3VhcmR9XG4qL1xuZnVuY3Rpb24gb25CZWZvcmVSb3V0ZUxlYXZlKGxlYXZlR3VhcmQpIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhZ2V0Q3VycmVudEluc3RhbmNlKCkpIHtcblx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDIyKHsgZm46IFwib25CZWZvcmVSb3V0ZUxlYXZlXCIgfSk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdHJlZ2lzdGVyR3VhcmQoaW5qZWN0KG1hdGNoZWRSb3V0ZUtleSwge30pLCBcImxlYXZlR3VhcmRzXCIsIGxlYXZlR3VhcmQpO1xufVxuLyoqXG4qIEFkZCBhIG5hdmlnYXRpb24gZ3VhcmQgdGhhdCB0cmlnZ2VycyB3aGVuZXZlciB0aGUgY3VycmVudCBsb2NhdGlvbiBpcyBhYm91dFxuKiB0byBiZSB1cGRhdGVkLiBTaW1pbGFyIHRvIHtAbGluayBiZWZvcmVSb3V0ZVVwZGF0ZX0gYnV0IGNhbiBiZSB1c2VkIGluIGFueVxuKiBjb21wb25lbnQuIFRoZSBndWFyZCBpcyByZW1vdmVkIHdoZW4gdGhlIGNvbXBvbmVudCBpcyB1bm1vdW50ZWQuXG4qXG4qIEBwYXJhbSB1cGRhdGVHdWFyZCAtIHtAbGluayBOYXZpZ2F0aW9uR3VhcmR9XG4qL1xuZnVuY3Rpb24gb25CZWZvcmVSb3V0ZVVwZGF0ZSh1cGRhdGVHdWFyZCkge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFnZXRDdXJyZW50SW5zdGFuY2UoKSkge1xuXHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMjIoeyBmbjogXCJvbkJlZm9yZVJvdXRlVXBkYXRlXCIgfSk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdHJlZ2lzdGVyR3VhcmQoaW5qZWN0KG1hdGNoZWRSb3V0ZUtleSwge30pLCBcInVwZGF0ZUd1YXJkc1wiLCB1cGRhdGVHdWFyZCk7XG59XG5mdW5jdGlvbiBndWFyZFRvUHJvbWlzZUZuKGd1YXJkLCB0bywgZnJvbSwgcmVjb3JkLCBuYW1lLCBydW5XaXRoQ29udGV4dCA9IChmbikgPT4gZm4oKSkge1xuXHRjb25zdCBlbnRlckNhbGxiYWNrQXJyYXkgPSByZWNvcmQgJiYgKHJlY29yZC5lbnRlckNhbGxiYWNrc1tuYW1lXSA9IHJlY29yZC5lbnRlckNhbGxiYWNrc1tuYW1lXSB8fCBbXSk7XG5cdHJldHVybiAoKSA9PiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0Y29uc3QgbmV4dCA9ICh2YWxpZCkgPT4ge1xuXHRcdFx0aWYgKHZhbGlkID09PSBmYWxzZSkgcmVqZWN0KGNyZWF0ZVJvdXRlckVycm9yKDQsIHtcblx0XHRcdFx0ZnJvbSxcblx0XHRcdFx0dG9cblx0XHRcdH0pKTtcblx0XHRcdGVsc2UgaWYgKHZhbGlkIGluc3RhbmNlb2YgRXJyb3IpIHJlamVjdCh2YWxpZCk7XG5cdFx0XHRlbHNlIGlmIChpc1JvdXRlTG9jYXRpb24odmFsaWQpKSByZWplY3QoY3JlYXRlUm91dGVyRXJyb3IoMiwge1xuXHRcdFx0XHRmcm9tOiB0byxcblx0XHRcdFx0dG86IHZhbGlkXG5cdFx0XHR9KSk7XG5cdFx0XHRlbHNlIHtcblx0XHRcdFx0aWYgKGVudGVyQ2FsbGJhY2tBcnJheSAmJiByZWNvcmQuZW50ZXJDYWxsYmFja3NbbmFtZV0gPT09IGVudGVyQ2FsbGJhY2tBcnJheSAmJiB0eXBlb2YgdmFsaWQgPT09IFwiZnVuY3Rpb25cIikgZW50ZXJDYWxsYmFja0FycmF5LnB1c2godmFsaWQpO1xuXHRcdFx0XHRyZXNvbHZlKCk7XG5cdFx0XHR9XG5cdFx0fTtcblx0XHRjb25zdCBndWFyZFJldHVybiA9IHJ1bldpdGhDb250ZXh0KCgpID0+IGd1YXJkLmNhbGwocmVjb3JkICYmIHJlY29yZC5pbnN0YW5jZXNbbmFtZV0sIHRvLCBmcm9tLCBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyB3aXRoRGVwcmVjYXRpb25XYXJuaW5nKGNhbk9ubHlCZUNhbGxlZE9uY2UobmV4dCwgdG8sIGZyb20pKSA6IG5leHQpKTtcblx0XHRsZXQgZ3VhcmRDYWxsID0gUHJvbWlzZS5yZXNvbHZlKGd1YXJkUmV0dXJuKTtcblx0XHRpZiAoZ3VhcmQubGVuZ3RoIDwgMykgZ3VhcmRDYWxsID0gZ3VhcmRDYWxsLnRoZW4obmV4dCk7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBndWFyZC5sZW5ndGggPiAyKSB7XG5cdFx0XHRjb25zdCBndWFyZEluZm8gPSB7XG5cdFx0XHRcdG5hbWU6IGd1YXJkLm5hbWUsXG5cdFx0XHRcdGd1YXJkOiBndWFyZC50b1N0cmluZygpXG5cdFx0XHR9O1xuXHRcdFx0aWYgKHR5cGVvZiBndWFyZFJldHVybiA9PT0gXCJvYmplY3RcIiAmJiBcInRoZW5cIiBpbiBndWFyZFJldHVybikgZ3VhcmRDYWxsID0gZ3VhcmRDYWxsLnRoZW4oKHJlc29sdmVkVmFsdWUpID0+IHtcblx0XHRcdFx0aWYgKCFuZXh0Ll9jYWxsZWQpIHtcblx0XHRcdFx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDIzKGd1YXJkSW5mbyk7XG5cdFx0XHRcdFx0cmV0dXJuIFByb21pc2UucmVqZWN0KC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoXCJJbnZhbGlkIG5hdmlnYXRpb24gZ3VhcmRcIikpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiByZXNvbHZlZFZhbHVlO1xuXHRcdFx0fSk7XG5cdFx0XHRlbHNlIGlmIChndWFyZFJldHVybiAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdGlmICghbmV4dC5fY2FsbGVkKSB7XG5cdFx0XHRcdFx0ZGlhZ25vc3RpY3MuVlVFX1JPVVRFUl9SMDAyMyhndWFyZEluZm8pO1xuXHRcdFx0XHRcdHJlamVjdCgvKiBAX19QVVJFX18gKi8gbmV3IEVycm9yKFwiSW52YWxpZCBuYXZpZ2F0aW9uIGd1YXJkXCIpKTtcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdFx0Z3VhcmRDYWxsLmNhdGNoKChlcnIpID0+IHJlamVjdChlcnIpKTtcblx0fSk7XG59XG4vKipcbiogV3JhcHMgdGhlIG5leHQgY2FsbGJhY2sgdG8gd2FybiB3aGVuIGl0IGlzIHVzZWQuIERldi1vbmx5OiB3aGVuIF9fREVWX18gaXNcbiogZmFsc2UgKHByb2R1Y3Rpb24gYnVpbGRzKSwgdGhpcyBicmFuY2ggaXMgZGVhZCBjb2RlIGFuZCBpcyBzdHJpcHBlZCBmcm9tIHRoZVxuKiBidW5kbGUuXG4qXG4qIEBpbnRlcm5hbFxuKi9cbmZ1bmN0aW9uIHdpdGhEZXByZWNhdGlvbldhcm5pbmcobmV4dCkge1xuXHRsZXQgd2FybmVkID0gZmFsc2U7XG5cdHJldHVybiBmdW5jdGlvbigpIHtcblx0XHRpZiAoIXdhcm5lZCkge1xuXHRcdFx0d2FybmVkID0gdHJ1ZTtcblx0XHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMjUoKTtcblx0XHR9XG5cdFx0cmV0dXJuIG5leHQuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcblx0fTtcbn1cbmZ1bmN0aW9uIGNhbk9ubHlCZUNhbGxlZE9uY2UobmV4dCwgdG8sIGZyb20pIHtcblx0bGV0IGNhbGxlZCA9IDA7XG5cdHJldHVybiBmdW5jdGlvbigpIHtcblx0XHRpZiAoY2FsbGVkKysgPT09IDEpIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMjQoe1xuXHRcdFx0ZnJvbTogZnJvbS5mdWxsUGF0aCxcblx0XHRcdHRvOiB0by5mdWxsUGF0aFxuXHRcdH0pO1xuXHRcdG5leHQuX2NhbGxlZCA9IHRydWU7XG5cdFx0aWYgKGNhbGxlZCA9PT0gMSkgbmV4dC5hcHBseShudWxsLCBhcmd1bWVudHMpO1xuXHR9O1xufVxuZnVuY3Rpb24gZXh0cmFjdENvbXBvbmVudHNHdWFyZHMobWF0Y2hlZCwgZ3VhcmRUeXBlLCB0bywgZnJvbSwgcnVuV2l0aENvbnRleHQgPSAoZm4pID0+IGZuKCkpIHtcblx0Y29uc3QgZ3VhcmRzID0gW107XG5cdGZvciAoY29uc3QgcmVjb3JkIG9mIG1hdGNoZWQpIHtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFyZWNvcmQuY29tcG9uZW50cyAmJiByZWNvcmQuY2hpbGRyZW4gJiYgIXJlY29yZC5jaGlsZHJlbi5sZW5ndGgpIGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMjYoeyBwYXRoOiByZWNvcmQucGF0aCB9KTtcblx0XHRmb3IgKGNvbnN0IG5hbWUgaW4gcmVjb3JkLmNvbXBvbmVudHMpIHtcblx0XHRcdGxldCByYXdDb21wb25lbnQgPSByZWNvcmQuY29tcG9uZW50c1tuYW1lXTtcblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRcdFx0aWYgKCFyYXdDb21wb25lbnQgfHwgdHlwZW9mIHJhd0NvbXBvbmVudCAhPT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgcmF3Q29tcG9uZW50ICE9PSBcImZ1bmN0aW9uXCIpIHtcblx0XHRcdFx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDI3KHtcblx0XHRcdFx0XHRcdG5hbWUsXG5cdFx0XHRcdFx0XHRwYXRoOiByZWNvcmQucGF0aCxcblx0XHRcdFx0XHRcdHJlY2VpdmVkOiBTdHJpbmcocmF3Q29tcG9uZW50KVxuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgcm91dGUgY29tcG9uZW50XCIpO1xuXHRcdFx0XHR9IGVsc2UgaWYgKFwidGhlblwiIGluIHJhd0NvbXBvbmVudCkge1xuXHRcdFx0XHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMjgoe1xuXHRcdFx0XHRcdFx0bmFtZSxcblx0XHRcdFx0XHRcdHBhdGg6IHJlY29yZC5wYXRoXG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0Y29uc3QgcHJvbWlzZSA9IHJhd0NvbXBvbmVudDtcblx0XHRcdFx0XHRyYXdDb21wb25lbnQgPSAoKSA9PiBwcm9taXNlO1xuXHRcdFx0XHR9IGVsc2UgaWYgKHJhd0NvbXBvbmVudC5fX2FzeW5jTG9hZGVyICYmICFyYXdDb21wb25lbnQuX193YXJuZWREZWZpbmVBc3luYykge1xuXHRcdFx0XHRcdHJhd0NvbXBvbmVudC5fX3dhcm5lZERlZmluZUFzeW5jID0gdHJ1ZTtcblx0XHRcdFx0XHRkaWFnbm9zdGljcy5WVUVfUk9VVEVSX1IwMDI5KHtcblx0XHRcdFx0XHRcdG5hbWUsXG5cdFx0XHRcdFx0XHRwYXRoOiByZWNvcmQucGF0aFxuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAoZ3VhcmRUeXBlICE9PSBcImJlZm9yZVJvdXRlRW50ZXJcIiAmJiAhcmVjb3JkLmluc3RhbmNlc1tuYW1lXSkgY29udGludWU7XG5cdFx0XHRpZiAoaXNSb3V0ZUNvbXBvbmVudChyYXdDb21wb25lbnQpKSB7XG5cdFx0XHRcdGNvbnN0IGd1YXJkID0gKHJhd0NvbXBvbmVudC5fX3ZjY09wdHMgfHwgcmF3Q29tcG9uZW50KVtndWFyZFR5cGVdO1xuXHRcdFx0XHRndWFyZCAmJiBndWFyZHMucHVzaChndWFyZFRvUHJvbWlzZUZuKGd1YXJkLCB0bywgZnJvbSwgcmVjb3JkLCBuYW1lLCBydW5XaXRoQ29udGV4dCkpO1xuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0bGV0IGNvbXBvbmVudFByb21pc2UgPSByYXdDb21wb25lbnQoKTtcblx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhKFwiY2F0Y2hcIiBpbiBjb21wb25lbnRQcm9taXNlKSkge1xuXHRcdFx0XHRcdGRpYWdub3N0aWNzLlZVRV9ST1VURVJfUjAwMzAoe1xuXHRcdFx0XHRcdFx0bmFtZSxcblx0XHRcdFx0XHRcdHBhdGg6IHJlY29yZC5wYXRoXG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0Y29tcG9uZW50UHJvbWlzZSA9IFByb21pc2UucmVzb2x2ZShjb21wb25lbnRQcm9taXNlKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRndWFyZHMucHVzaCgoKSA9PiBjb21wb25lbnRQcm9taXNlLnRoZW4oKHJlc29sdmVkKSA9PiB7XG5cdFx0XHRcdFx0aWYgKCFyZXNvbHZlZCkgdGhyb3cgbmV3IEVycm9yKGBDb3VsZG4ndCByZXNvbHZlIGNvbXBvbmVudCBcIiR7bmFtZX1cIiBhdCBcIiR7cmVjb3JkLnBhdGh9XCJgKTtcblx0XHRcdFx0XHRjb25zdCByZXNvbHZlZENvbXBvbmVudCA9IGlzRVNNb2R1bGUocmVzb2x2ZWQpID8gcmVzb2x2ZWQuZGVmYXVsdCA6IHJlc29sdmVkO1xuXHRcdFx0XHRcdHJlY29yZC5tb2RzW25hbWVdID0gcmVzb2x2ZWQ7XG5cdFx0XHRcdFx0cmVjb3JkLmNvbXBvbmVudHNbbmFtZV0gPSByZXNvbHZlZENvbXBvbmVudDtcblx0XHRcdFx0XHRjb25zdCBndWFyZCA9IChyZXNvbHZlZENvbXBvbmVudC5fX3ZjY09wdHMgfHwgcmVzb2x2ZWRDb21wb25lbnQpW2d1YXJkVHlwZV07XG5cdFx0XHRcdFx0cmV0dXJuIGd1YXJkICYmIGd1YXJkVG9Qcm9taXNlRm4oZ3VhcmQsIHRvLCBmcm9tLCByZWNvcmQsIG5hbWUsIHJ1bldpdGhDb250ZXh0KSgpO1xuXHRcdFx0XHR9KSk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cdHJldHVybiBndWFyZHM7XG59XG4vKipcbiogRW5zdXJlcyBhIHJvdXRlIGlzIGxvYWRlZCwgc28gaXQgY2FuIGJlIHBhc3NlZCBhcyBvIHByb3AgdG8gYDxSb3V0ZXJWaWV3PmAuXG4qXG4qIEBwYXJhbSByb3V0ZSAtIHJlc29sdmVkIHJvdXRlIHRvIGxvYWRcbiovXG5mdW5jdGlvbiBsb2FkUm91dGVMb2NhdGlvbihyb3V0ZSkge1xuXHRyZXR1cm4gcm91dGUubWF0Y2hlZC5ldmVyeSgocmVjb3JkKSA9PiByZWNvcmQucmVkaXJlY3QpID8gUHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihcIkNhbm5vdCBsb2FkIGEgcm91dGUgdGhhdCByZWRpcmVjdHMuXCIpKSA6IFByb21pc2UuYWxsKHJvdXRlLm1hdGNoZWQubWFwKChyZWNvcmQpID0+IHJlY29yZC5jb21wb25lbnRzICYmIFByb21pc2UuYWxsKE9iamVjdC5rZXlzKHJlY29yZC5jb21wb25lbnRzKS5yZWR1Y2UoKHByb21pc2VzLCBuYW1lKSA9PiB7XG5cdFx0Y29uc3QgcmF3Q29tcG9uZW50ID0gcmVjb3JkLmNvbXBvbmVudHNbbmFtZV07XG5cdFx0aWYgKHR5cGVvZiByYXdDb21wb25lbnQgPT09IFwiZnVuY3Rpb25cIiAmJiAhKFwiZGlzcGxheU5hbWVcIiBpbiByYXdDb21wb25lbnQpKSBwcm9taXNlcy5wdXNoKHJhd0NvbXBvbmVudCgpLnRoZW4oKHJlc29sdmVkKSA9PiB7XG5cdFx0XHRpZiAoIXJlc29sdmVkKSByZXR1cm4gUHJvbWlzZS5yZWplY3QoLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihgQ291bGRuJ3QgcmVzb2x2ZSBjb21wb25lbnQgXCIke25hbWV9XCIgYXQgXCIke3JlY29yZC5wYXRofVwiLiBFbnN1cmUgeW91IHBhc3NlZCBhIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhIHByb21pc2UuYCkpO1xuXHRcdFx0Y29uc3QgcmVzb2x2ZWRDb21wb25lbnQgPSBpc0VTTW9kdWxlKHJlc29sdmVkKSA/IHJlc29sdmVkLmRlZmF1bHQgOiByZXNvbHZlZDtcblx0XHRcdHJlY29yZC5tb2RzW25hbWVdID0gcmVzb2x2ZWQ7XG5cdFx0XHRyZWNvcmQuY29tcG9uZW50c1tuYW1lXSA9IHJlc29sdmVkQ29tcG9uZW50O1xuXHRcdH0pKTtcblx0XHRyZXR1cm4gcHJvbWlzZXM7XG5cdH0sIFtdKSkpKS50aGVuKCgpID0+IHJvdXRlKTtcbn1cbi8qKlxuKiBTcGxpdCB0aGUgbGVhdmluZywgdXBkYXRpbmcsIGFuZCBlbnRlcmluZyByZWNvcmRzLlxuKiBAaW50ZXJuYWxcbipcbiogQHBhcmFtICB0byAtIExvY2F0aW9uIHdlIGFyZSBuYXZpZ2F0aW5nIHRvXG4qIEBwYXJhbSBmcm9tIC0gTG9jYXRpb24gd2UgYXJlIG5hdmlnYXRpbmcgZnJvbVxuKi9cbmZ1bmN0aW9uIGV4dHJhY3RDaGFuZ2luZ1JlY29yZHModG8sIGZyb20pIHtcblx0Y29uc3QgbGVhdmluZ1JlY29yZHMgPSBbXTtcblx0Y29uc3QgdXBkYXRpbmdSZWNvcmRzID0gW107XG5cdGNvbnN0IGVudGVyaW5nUmVjb3JkcyA9IFtdO1xuXHRjb25zdCBsZW4gPSBNYXRoLm1heChmcm9tLm1hdGNoZWQubGVuZ3RoLCB0by5tYXRjaGVkLmxlbmd0aCk7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcblx0XHRjb25zdCByZWNvcmRGcm9tID0gZnJvbS5tYXRjaGVkW2ldO1xuXHRcdGlmIChyZWNvcmRGcm9tKSBpZiAodG8ubWF0Y2hlZC5maW5kKChyZWNvcmQpID0+IGlzU2FtZVJvdXRlUmVjb3JkKHJlY29yZCwgcmVjb3JkRnJvbSkpKSB1cGRhdGluZ1JlY29yZHMucHVzaChyZWNvcmRGcm9tKTtcblx0XHRlbHNlIGxlYXZpbmdSZWNvcmRzLnB1c2gocmVjb3JkRnJvbSk7XG5cdFx0Y29uc3QgcmVjb3JkVG8gPSB0by5tYXRjaGVkW2ldO1xuXHRcdGlmIChyZWNvcmRUbykge1xuXHRcdFx0aWYgKCFmcm9tLm1hdGNoZWQuZmluZCgocmVjb3JkKSA9PiBpc1NhbWVSb3V0ZVJlY29yZChyZWNvcmQsIHJlY29yZFRvKSkpIGVudGVyaW5nUmVjb3Jkcy5wdXNoKHJlY29yZFRvKTtcblx0XHR9XG5cdH1cblx0cmV0dXJuIFtcblx0XHRsZWF2aW5nUmVjb3Jkcyxcblx0XHR1cGRhdGluZ1JlY29yZHMsXG5cdFx0ZW50ZXJpbmdSZWNvcmRzXG5cdF07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvZGV2dG9vbHMudHNcbi8qKlxuKiBDb3BpZXMgYSByb3V0ZSBsb2NhdGlvbiBhbmQgcmVtb3ZlcyBhbnkgcHJvYmxlbWF0aWMgcHJvcGVydGllcyB0aGF0IGNhbm5vdCBiZSBzaG93biBpbiBkZXZ0b29scyAoZS5nLiBWdWUgaW5zdGFuY2VzKS5cbipcbiogQHBhcmFtIHJvdXRlTG9jYXRpb24gLSByb3V0ZUxvY2F0aW9uIHRvIGZvcm1hdFxuKiBAcGFyYW0gdG9vbHRpcCAtIG9wdGlvbmFsIHRvb2x0aXBcbiogQHJldHVybnMgYSBjb3B5IG9mIHRoZSByb3V0ZUxvY2F0aW9uXG4qL1xuZnVuY3Rpb24gZm9ybWF0Um91dGVMb2NhdGlvbihyb3V0ZUxvY2F0aW9uLCB0b29sdGlwKSB7XG5cdGNvbnN0IGNvcHkgPSBhc3NpZ24oe30sIHJvdXRlTG9jYXRpb24sIHsgbWF0Y2hlZDogcm91dGVMb2NhdGlvbi5tYXRjaGVkLm1hcCgobWF0Y2hlZCkgPT4gb21pdChtYXRjaGVkLCBbXG5cdFx0XCJpbnN0YW5jZXNcIixcblx0XHRcImNoaWxkcmVuXCIsXG5cdFx0XCJhbGlhc09mXCJcblx0XSkpIH0pO1xuXHRyZXR1cm4geyBfY3VzdG9tOiB7XG5cdFx0dHlwZTogbnVsbCxcblx0XHRyZWFkT25seTogdHJ1ZSxcblx0XHRkaXNwbGF5OiByb3V0ZUxvY2F0aW9uLmZ1bGxQYXRoLFxuXHRcdHRvb2x0aXAsXG5cdFx0dmFsdWU6IGNvcHlcblx0fSB9O1xufVxuZnVuY3Rpb24gZm9ybWF0RGlzcGxheShkaXNwbGF5KSB7XG5cdHJldHVybiB7IF9jdXN0b206IHsgZGlzcGxheSB9IH07XG59XG5sZXQgcm91dGVySWQgPSAwO1xuZnVuY3Rpb24gYWRkRGV2dG9vbHMoYXBwLCByb3V0ZXIsIG1hdGNoZXIpIHtcblx0aWYgKHJvdXRlci5fX2hhc0RldnRvb2xzKSByZXR1cm47XG5cdHJvdXRlci5fX2hhc0RldnRvb2xzID0gdHJ1ZTtcblx0Y29uc3QgaWQgPSByb3V0ZXJJZCsrO1xuXHRzZXR1cERldnRvb2xzUGx1Z2luKHtcblx0XHRpZDogXCJvcmcudnVlanMucm91dGVyXCIgKyAoaWQgPyBcIi5cIiArIGlkIDogXCJcIiksXG5cdFx0bGFiZWw6IFwiVnVlIFJvdXRlclwiLFxuXHRcdHBhY2thZ2VOYW1lOiBcInZ1ZS1yb3V0ZXJcIixcblx0XHRob21lcGFnZTogXCJodHRwczovL3JvdXRlci52dWVqcy5vcmdcIixcblx0XHRsb2dvOiBcImh0dHBzOi8vcm91dGVyLnZ1ZWpzLm9yZy9sb2dvLnBuZ1wiLFxuXHRcdGNvbXBvbmVudFN0YXRlVHlwZXM6IFtcIlJvdXRpbmdcIl0sXG5cdFx0YXBwXG5cdH0sIChhcGkpID0+IHtcblx0XHRhcGkub24uaW5zcGVjdENvbXBvbmVudCgocGF5bG9hZCkgPT4ge1xuXHRcdFx0aWYgKHBheWxvYWQuaW5zdGFuY2VEYXRhKSBwYXlsb2FkLmluc3RhbmNlRGF0YS5zdGF0ZS5wdXNoKHtcblx0XHRcdFx0dHlwZTogXCJSb3V0aW5nXCIsXG5cdFx0XHRcdGtleTogXCIkcm91dGVcIixcblx0XHRcdFx0ZWRpdGFibGU6IGZhbHNlLFxuXHRcdFx0XHR2YWx1ZTogZm9ybWF0Um91dGVMb2NhdGlvbihyb3V0ZXIuY3VycmVudFJvdXRlLnZhbHVlLCBcIkN1cnJlbnQgUm91dGVcIilcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHRcdGFwaS5vbi52aXNpdENvbXBvbmVudFRyZWUoKHsgdHJlZU5vZGU6IG5vZGUsIGNvbXBvbmVudEluc3RhbmNlIH0pID0+IHtcblx0XHRcdGlmIChjb21wb25lbnRJbnN0YW5jZS5fX3Zydl9kZXZ0b29scykge1xuXHRcdFx0XHRjb25zdCBpbmZvID0gY29tcG9uZW50SW5zdGFuY2UuX192cnZfZGV2dG9vbHM7XG5cdFx0XHRcdG5vZGUudGFncy5wdXNoKHtcblx0XHRcdFx0XHRsYWJlbDogKGluZm8ubmFtZSA/IGAke2luZm8ubmFtZS50b1N0cmluZygpfTogYCA6IFwiXCIpICsgaW5mby5wYXRoLFxuXHRcdFx0XHRcdHRleHRDb2xvcjogMCxcblx0XHRcdFx0XHR0b29sdGlwOiBcIlRoaXMgY29tcG9uZW50IGlzIHJlbmRlcmVkIGJ5ICZsdDtyb3V0ZXItdmlldyZndDtcIixcblx0XHRcdFx0XHRiYWNrZ3JvdW5kQ29sb3I6IFBJTktfNTAwXG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdFx0aWYgKGlzQXJyYXkoY29tcG9uZW50SW5zdGFuY2UuX192cmxfZGV2dG9vbHMpKSB7XG5cdFx0XHRcdGNvbXBvbmVudEluc3RhbmNlLl9fZGV2dG9vbHNBcGkgPSBhcGk7XG5cdFx0XHRcdGNvbXBvbmVudEluc3RhbmNlLl9fdnJsX2RldnRvb2xzLmZvckVhY2goKGRldnRvb2xzRGF0YSkgPT4ge1xuXHRcdFx0XHRcdGxldCBsYWJlbCA9IGRldnRvb2xzRGF0YS5yb3V0ZS5wYXRoO1xuXHRcdFx0XHRcdGxldCBiYWNrZ3JvdW5kQ29sb3IgPSBPUkFOR0VfNDAwO1xuXHRcdFx0XHRcdGxldCB0b29sdGlwID0gXCJcIjtcblx0XHRcdFx0XHRsZXQgdGV4dENvbG9yID0gMDtcblx0XHRcdFx0XHRpZiAoZGV2dG9vbHNEYXRhLmVycm9yKSB7XG5cdFx0XHRcdFx0XHRsYWJlbCA9IGRldnRvb2xzRGF0YS5lcnJvcjtcblx0XHRcdFx0XHRcdGJhY2tncm91bmRDb2xvciA9IFJFRF8xMDA7XG5cdFx0XHRcdFx0XHR0ZXh0Q29sb3IgPSBSRURfNzAwO1xuXHRcdFx0XHRcdH0gZWxzZSBpZiAoZGV2dG9vbHNEYXRhLmlzRXhhY3RBY3RpdmUpIHtcblx0XHRcdFx0XHRcdGJhY2tncm91bmRDb2xvciA9IExJTUVfNTAwO1xuXHRcdFx0XHRcdFx0dG9vbHRpcCA9IFwiVGhpcyBpcyBleGFjdGx5IGFjdGl2ZVwiO1xuXHRcdFx0XHRcdH0gZWxzZSBpZiAoZGV2dG9vbHNEYXRhLmlzQWN0aXZlKSB7XG5cdFx0XHRcdFx0XHRiYWNrZ3JvdW5kQ29sb3IgPSBCTFVFXzYwMDtcblx0XHRcdFx0XHRcdHRvb2x0aXAgPSBcIlRoaXMgbGluayBpcyBhY3RpdmVcIjtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0bm9kZS50YWdzLnB1c2goe1xuXHRcdFx0XHRcdFx0bGFiZWwsXG5cdFx0XHRcdFx0XHR0ZXh0Q29sb3IsXG5cdFx0XHRcdFx0XHR0b29sdGlwLFxuXHRcdFx0XHRcdFx0YmFja2dyb3VuZENvbG9yXG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdHdhdGNoKHJvdXRlci5jdXJyZW50Um91dGUsICgpID0+IHtcblx0XHRcdHJlZnJlc2hSb3V0ZXNWaWV3KCk7XG5cdFx0XHRhcGkubm90aWZ5Q29tcG9uZW50VXBkYXRlKCk7XG5cdFx0XHRhcGkuc2VuZEluc3BlY3RvclRyZWUocm91dGVySW5zcGVjdG9ySWQpO1xuXHRcdFx0YXBpLnNlbmRJbnNwZWN0b3JTdGF0ZShyb3V0ZXJJbnNwZWN0b3JJZCk7XG5cdFx0fSk7XG5cdFx0Y29uc3QgbmF2aWdhdGlvbnNMYXllcklkID0gXCJyb3V0ZXI6bmF2aWdhdGlvbnM6XCIgKyBpZDtcblx0XHRhcGkuYWRkVGltZWxpbmVMYXllcih7XG5cdFx0XHRpZDogbmF2aWdhdGlvbnNMYXllcklkLFxuXHRcdFx0bGFiZWw6IGBSb3V0ZXIke2lkID8gXCIgXCIgKyBpZCA6IFwiXCJ9IE5hdmlnYXRpb25zYCxcblx0XHRcdGNvbG9yOiA0MjM3NTA4XG5cdFx0fSk7XG5cdFx0cm91dGVyLm9uRXJyb3IoKGVycm9yLCB0bykgPT4ge1xuXHRcdFx0YXBpLmFkZFRpbWVsaW5lRXZlbnQoe1xuXHRcdFx0XHRsYXllcklkOiBuYXZpZ2F0aW9uc0xheWVySWQsXG5cdFx0XHRcdGV2ZW50OiB7XG5cdFx0XHRcdFx0dGl0bGU6IFwiRXJyb3IgZHVyaW5nIE5hdmlnYXRpb25cIixcblx0XHRcdFx0XHRzdWJ0aXRsZTogdG8uZnVsbFBhdGgsXG5cdFx0XHRcdFx0bG9nVHlwZTogXCJlcnJvclwiLFxuXHRcdFx0XHRcdHRpbWU6IGFwaS5ub3coKSxcblx0XHRcdFx0XHRkYXRhOiB7IGVycm9yIH0sXG5cdFx0XHRcdFx0Z3JvdXBJZDogdG8ubWV0YS5fX25hdmlnYXRpb25JZFxuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0XHRsZXQgbmF2aWdhdGlvbklkID0gMDtcblx0XHRyb3V0ZXIuYmVmb3JlRWFjaCgodG8sIGZyb20pID0+IHtcblx0XHRcdGNvbnN0IGRhdGEgPSB7XG5cdFx0XHRcdGd1YXJkOiBmb3JtYXREaXNwbGF5KFwiYmVmb3JlRWFjaFwiKSxcblx0XHRcdFx0ZnJvbTogZm9ybWF0Um91dGVMb2NhdGlvbihmcm9tLCBcIkN1cnJlbnQgTG9jYXRpb24gZHVyaW5nIHRoaXMgbmF2aWdhdGlvblwiKSxcblx0XHRcdFx0dG86IGZvcm1hdFJvdXRlTG9jYXRpb24odG8sIFwiVGFyZ2V0IGxvY2F0aW9uXCIpXG5cdFx0XHR9O1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KHRvLm1ldGEsIFwiX19uYXZpZ2F0aW9uSWRcIiwgeyB2YWx1ZTogbmF2aWdhdGlvbklkKysgfSk7XG5cdFx0XHRhcGkuYWRkVGltZWxpbmVFdmVudCh7XG5cdFx0XHRcdGxheWVySWQ6IG5hdmlnYXRpb25zTGF5ZXJJZCxcblx0XHRcdFx0ZXZlbnQ6IHtcblx0XHRcdFx0XHR0aW1lOiBhcGkubm93KCksXG5cdFx0XHRcdFx0dGl0bGU6IFwiU3RhcnQgb2YgbmF2aWdhdGlvblwiLFxuXHRcdFx0XHRcdHN1YnRpdGxlOiB0by5mdWxsUGF0aCxcblx0XHRcdFx0XHRkYXRhLFxuXHRcdFx0XHRcdGdyb3VwSWQ6IHRvLm1ldGEuX19uYXZpZ2F0aW9uSWRcblx0XHRcdFx0fVxuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdFx0cm91dGVyLmFmdGVyRWFjaCgodG8sIGZyb20sIGZhaWx1cmUpID0+IHtcblx0XHRcdGNvbnN0IGRhdGEgPSB7IGd1YXJkOiBmb3JtYXREaXNwbGF5KFwiYWZ0ZXJFYWNoXCIpIH07XG5cdFx0XHRpZiAoZmFpbHVyZSkge1xuXHRcdFx0XHRkYXRhLmZhaWx1cmUgPSB7IF9jdXN0b206IHtcblx0XHRcdFx0XHR0eXBlOiBFcnJvcixcblx0XHRcdFx0XHRyZWFkT25seTogdHJ1ZSxcblx0XHRcdFx0XHRkaXNwbGF5OiBmYWlsdXJlID8gZmFpbHVyZS5tZXNzYWdlIDogXCJcIixcblx0XHRcdFx0XHR0b29sdGlwOiBcIk5hdmlnYXRpb24gRmFpbHVyZVwiLFxuXHRcdFx0XHRcdHZhbHVlOiBmYWlsdXJlXG5cdFx0XHRcdH0gfTtcblx0XHRcdFx0ZGF0YS5zdGF0dXMgPSBmb3JtYXREaXNwbGF5KFwi4p2MXCIpO1xuXHRcdFx0fSBlbHNlIGRhdGEuc3RhdHVzID0gZm9ybWF0RGlzcGxheShcIuKchVwiKTtcblx0XHRcdGRhdGEuZnJvbSA9IGZvcm1hdFJvdXRlTG9jYXRpb24oZnJvbSwgXCJDdXJyZW50IExvY2F0aW9uIGR1cmluZyB0aGlzIG5hdmlnYXRpb25cIik7XG5cdFx0XHRkYXRhLnRvID0gZm9ybWF0Um91dGVMb2NhdGlvbih0bywgXCJUYXJnZXQgbG9jYXRpb25cIik7XG5cdFx0XHRhcGkuYWRkVGltZWxpbmVFdmVudCh7XG5cdFx0XHRcdGxheWVySWQ6IG5hdmlnYXRpb25zTGF5ZXJJZCxcblx0XHRcdFx0ZXZlbnQ6IHtcblx0XHRcdFx0XHR0aXRsZTogXCJFbmQgb2YgbmF2aWdhdGlvblwiLFxuXHRcdFx0XHRcdHN1YnRpdGxlOiB0by5mdWxsUGF0aCxcblx0XHRcdFx0XHR0aW1lOiBhcGkubm93KCksXG5cdFx0XHRcdFx0ZGF0YSxcblx0XHRcdFx0XHRsb2dUeXBlOiBmYWlsdXJlID8gXCJ3YXJuaW5nXCIgOiBcImRlZmF1bHRcIixcblx0XHRcdFx0XHRncm91cElkOiB0by5tZXRhLl9fbmF2aWdhdGlvbklkXG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH0pO1xuXHRcdC8qKlxuXHRcdCogSW5zcGVjdG9yIG9mIEV4aXN0aW5nIHJvdXRlc1xuXHRcdCovXG5cdFx0Y29uc3Qgcm91dGVySW5zcGVjdG9ySWQgPSBcInJvdXRlci1pbnNwZWN0b3I6XCIgKyBpZDtcblx0XHRhcGkuYWRkSW5zcGVjdG9yKHtcblx0XHRcdGlkOiByb3V0ZXJJbnNwZWN0b3JJZCxcblx0XHRcdGxhYmVsOiBcIlJvdXRlc1wiICsgKGlkID8gXCIgXCIgKyBpZCA6IFwiXCIpLFxuXHRcdFx0aWNvbjogXCJib29rXCIsXG5cdFx0XHR0cmVlRmlsdGVyUGxhY2Vob2xkZXI6IFwiU2VhcmNoIHJvdXRlc1wiXG5cdFx0fSk7XG5cdFx0ZnVuY3Rpb24gcmVmcmVzaFJvdXRlc1ZpZXcoKSB7XG5cdFx0XHRpZiAoIWFjdGl2ZVJvdXRlc1BheWxvYWQpIHJldHVybjtcblx0XHRcdGNvbnN0IHBheWxvYWQgPSBhY3RpdmVSb3V0ZXNQYXlsb2FkO1xuXHRcdFx0bGV0IHJvdXRlcyA9IG1hdGNoZXIuZ2V0Um91dGVzKCkuZmlsdGVyKChyb3V0ZSkgPT4gIXJvdXRlLnBhcmVudCB8fCAhcm91dGUucGFyZW50LnJlY29yZC5jb21wb25lbnRzKTtcblx0XHRcdHJvdXRlcy5mb3JFYWNoKHJlc2V0TWF0Y2hTdGF0ZU9uUm91dGVSZWNvcmQpO1xuXHRcdFx0aWYgKHBheWxvYWQuZmlsdGVyKSByb3V0ZXMgPSByb3V0ZXMuZmlsdGVyKChyb3V0ZSkgPT4gaXNSb3V0ZU1hdGNoaW5nKHJvdXRlLCBwYXlsb2FkLmZpbHRlci50b0xvd2VyQ2FzZSgpKSk7XG5cdFx0XHRyb3V0ZXMuZm9yRWFjaCgocm91dGUpID0+IG1hcmtSb3V0ZVJlY29yZEFjdGl2ZShyb3V0ZSwgcm91dGVyLmN1cnJlbnRSb3V0ZS52YWx1ZSkpO1xuXHRcdFx0cGF5bG9hZC5yb290Tm9kZXMgPSByb3V0ZXMubWFwKGZvcm1hdFJvdXRlUmVjb3JkRm9ySW5zcGVjdG9yKTtcblx0XHR9XG5cdFx0bGV0IGFjdGl2ZVJvdXRlc1BheWxvYWQ7XG5cdFx0YXBpLm9uLmdldEluc3BlY3RvclRyZWUoKHBheWxvYWQpID0+IHtcblx0XHRcdGFjdGl2ZVJvdXRlc1BheWxvYWQgPSBwYXlsb2FkO1xuXHRcdFx0aWYgKHBheWxvYWQuYXBwID09PSBhcHAgJiYgcGF5bG9hZC5pbnNwZWN0b3JJZCA9PT0gcm91dGVySW5zcGVjdG9ySWQpIHJlZnJlc2hSb3V0ZXNWaWV3KCk7XG5cdFx0fSk7XG5cdFx0LyoqXG5cdFx0KiBEaXNwbGF5IGluZm9ybWF0aW9uIGFib3V0IHRoZSBjdXJyZW50bHkgc2VsZWN0ZWQgcm91dGUgcmVjb3JkXG5cdFx0Ki9cblx0XHRhcGkub24uZ2V0SW5zcGVjdG9yU3RhdGUoKHBheWxvYWQpID0+IHtcblx0XHRcdGlmIChwYXlsb2FkLmFwcCA9PT0gYXBwICYmIHBheWxvYWQuaW5zcGVjdG9ySWQgPT09IHJvdXRlckluc3BlY3RvcklkKSB7XG5cdFx0XHRcdGNvbnN0IHJvdXRlID0gbWF0Y2hlci5nZXRSb3V0ZXMoKS5maW5kKChyb3V0ZSkgPT4gcm91dGUucmVjb3JkLl9fdmRfaWQgPT09IHBheWxvYWQubm9kZUlkKTtcblx0XHRcdFx0aWYgKHJvdXRlKSBwYXlsb2FkLnN0YXRlID0geyBvcHRpb25zOiBmb3JtYXRSb3V0ZVJlY29yZE1hdGNoZXJGb3JTdGF0ZUluc3BlY3Rvcihyb3V0ZSkgfTtcblx0XHRcdH1cblx0XHR9KTtcblx0XHRhcGkuc2VuZEluc3BlY3RvclRyZWUocm91dGVySW5zcGVjdG9ySWQpO1xuXHRcdGFwaS5zZW5kSW5zcGVjdG9yU3RhdGUocm91dGVySW5zcGVjdG9ySWQpO1xuXHR9KTtcbn1cbmZ1bmN0aW9uIG1vZGlmaWVyRm9yS2V5KGtleSkge1xuXHRpZiAoa2V5Lm9wdGlvbmFsKSByZXR1cm4ga2V5LnJlcGVhdGFibGUgPyBcIipcIiA6IFwiP1wiO1xuXHRlbHNlIHJldHVybiBrZXkucmVwZWF0YWJsZSA/IFwiK1wiIDogXCJcIjtcbn1cbmZ1bmN0aW9uIGZvcm1hdFJvdXRlUmVjb3JkTWF0Y2hlckZvclN0YXRlSW5zcGVjdG9yKHJvdXRlKSB7XG5cdGNvbnN0IHsgcmVjb3JkIH0gPSByb3V0ZTtcblx0Y29uc3QgZmllbGRzID0gW3tcblx0XHRlZGl0YWJsZTogZmFsc2UsXG5cdFx0a2V5OiBcInBhdGhcIixcblx0XHR2YWx1ZTogcmVjb3JkLnBhdGhcblx0fV07XG5cdGlmIChyZWNvcmQubmFtZSAhPSBudWxsKSBmaWVsZHMucHVzaCh7XG5cdFx0ZWRpdGFibGU6IGZhbHNlLFxuXHRcdGtleTogXCJuYW1lXCIsXG5cdFx0dmFsdWU6IHJlY29yZC5uYW1lXG5cdH0pO1xuXHRmaWVsZHMucHVzaCh7XG5cdFx0ZWRpdGFibGU6IGZhbHNlLFxuXHRcdGtleTogXCJyZWdleHBcIixcblx0XHR2YWx1ZTogcm91dGUucmVcblx0fSk7XG5cdGlmIChyb3V0ZS5rZXlzLmxlbmd0aCkgZmllbGRzLnB1c2goe1xuXHRcdGVkaXRhYmxlOiBmYWxzZSxcblx0XHRrZXk6IFwia2V5c1wiLFxuXHRcdHZhbHVlOiB7IF9jdXN0b206IHtcblx0XHRcdHR5cGU6IG51bGwsXG5cdFx0XHRyZWFkT25seTogdHJ1ZSxcblx0XHRcdGRpc3BsYXk6IHJvdXRlLmtleXMubWFwKChrZXkpID0+IGAke2tleS5uYW1lfSR7bW9kaWZpZXJGb3JLZXkoa2V5KX1gKS5qb2luKFwiIFwiKSxcblx0XHRcdHRvb2x0aXA6IFwiUGFyYW0ga2V5c1wiLFxuXHRcdFx0dmFsdWU6IHJvdXRlLmtleXNcblx0XHR9IH1cblx0fSk7XG5cdGlmIChyZWNvcmQucmVkaXJlY3QgIT0gbnVsbCkgZmllbGRzLnB1c2goe1xuXHRcdGVkaXRhYmxlOiBmYWxzZSxcblx0XHRrZXk6IFwicmVkaXJlY3RcIixcblx0XHR2YWx1ZTogcmVjb3JkLnJlZGlyZWN0XG5cdH0pO1xuXHRpZiAocm91dGUuYWxpYXMubGVuZ3RoKSBmaWVsZHMucHVzaCh7XG5cdFx0ZWRpdGFibGU6IGZhbHNlLFxuXHRcdGtleTogXCJhbGlhc2VzXCIsXG5cdFx0dmFsdWU6IHJvdXRlLmFsaWFzLm1hcCgoYWxpYXMpID0+IGFsaWFzLnJlY29yZC5wYXRoKVxuXHR9KTtcblx0aWYgKE9iamVjdC5rZXlzKHJvdXRlLnJlY29yZC5tZXRhKS5sZW5ndGgpIGZpZWxkcy5wdXNoKHtcblx0XHRlZGl0YWJsZTogZmFsc2UsXG5cdFx0a2V5OiBcIm1ldGFcIixcblx0XHR2YWx1ZTogcm91dGUucmVjb3JkLm1ldGFcblx0fSk7XG5cdGZpZWxkcy5wdXNoKHtcblx0XHRrZXk6IFwic2NvcmVcIixcblx0XHRlZGl0YWJsZTogZmFsc2UsXG5cdFx0dmFsdWU6IHsgX2N1c3RvbToge1xuXHRcdFx0dHlwZTogbnVsbCxcblx0XHRcdHJlYWRPbmx5OiB0cnVlLFxuXHRcdFx0ZGlzcGxheTogcm91dGUuc2NvcmUubWFwKChzY29yZSkgPT4gc2NvcmUuam9pbihcIiwgXCIpKS5qb2luKFwiIHwgXCIpLFxuXHRcdFx0dG9vbHRpcDogXCJTY29yZSB1c2VkIHRvIHNvcnQgcm91dGVzXCIsXG5cdFx0XHR2YWx1ZTogcm91dGUuc2NvcmVcblx0XHR9IH1cblx0fSk7XG5cdHJldHVybiBmaWVsZHM7XG59XG4vKipcbiogRXh0cmFjdGVkIGZyb20gdGFpbHdpbmQgcGFsZXR0ZVxuKi9cbmNvbnN0IFBJTktfNTAwID0gMTU0ODUwODE7XG5jb25zdCBCTFVFXzYwMCA9IDI0NTA0MTE7XG5jb25zdCBMSU1FXzUwMCA9IDg3MDI5OTg7XG5jb25zdCBDWUFOXzQwMCA9IDIyODI0Nzg7XG5jb25zdCBPUkFOR0VfNDAwID0gMTY0ODY5NzI7XG5jb25zdCBEQVJLID0gNjcxMDg4NjtcbmNvbnN0IFJFRF8xMDAgPSAxNjcwNDIyNjtcbmNvbnN0IFJFRF83MDAgPSAxMjEzMTM1NjtcbmZ1bmN0aW9uIGZvcm1hdFJvdXRlUmVjb3JkRm9ySW5zcGVjdG9yKHJvdXRlKSB7XG5cdGNvbnN0IHRhZ3MgPSBbXTtcblx0Y29uc3QgeyByZWNvcmQgfSA9IHJvdXRlO1xuXHRpZiAocmVjb3JkLm5hbWUgIT0gbnVsbCkgdGFncy5wdXNoKHtcblx0XHRsYWJlbDogU3RyaW5nKHJlY29yZC5uYW1lKSxcblx0XHR0ZXh0Q29sb3I6IDAsXG5cdFx0YmFja2dyb3VuZENvbG9yOiBDWUFOXzQwMFxuXHR9KTtcblx0aWYgKHJlY29yZC5hbGlhc09mKSB0YWdzLnB1c2goe1xuXHRcdGxhYmVsOiBcImFsaWFzXCIsXG5cdFx0dGV4dENvbG9yOiAwLFxuXHRcdGJhY2tncm91bmRDb2xvcjogT1JBTkdFXzQwMFxuXHR9KTtcblx0aWYgKHJvdXRlLl9fdmRfbWF0Y2gpIHRhZ3MucHVzaCh7XG5cdFx0bGFiZWw6IFwibWF0Y2hlc1wiLFxuXHRcdHRleHRDb2xvcjogMCxcblx0XHRiYWNrZ3JvdW5kQ29sb3I6IFBJTktfNTAwXG5cdH0pO1xuXHRpZiAocm91dGUuX192ZF9leGFjdEFjdGl2ZSkgdGFncy5wdXNoKHtcblx0XHRsYWJlbDogXCJleGFjdFwiLFxuXHRcdHRleHRDb2xvcjogMCxcblx0XHRiYWNrZ3JvdW5kQ29sb3I6IExJTUVfNTAwXG5cdH0pO1xuXHRpZiAocm91dGUuX192ZF9hY3RpdmUpIHRhZ3MucHVzaCh7XG5cdFx0bGFiZWw6IFwiYWN0aXZlXCIsXG5cdFx0dGV4dENvbG9yOiAwLFxuXHRcdGJhY2tncm91bmRDb2xvcjogQkxVRV82MDBcblx0fSk7XG5cdGlmIChyZWNvcmQucmVkaXJlY3QpIHRhZ3MucHVzaCh7XG5cdFx0bGFiZWw6IHR5cGVvZiByZWNvcmQucmVkaXJlY3QgPT09IFwic3RyaW5nXCIgPyBgcmVkaXJlY3Q6ICR7cmVjb3JkLnJlZGlyZWN0fWAgOiBcInJlZGlyZWN0c1wiLFxuXHRcdHRleHRDb2xvcjogMTY3NzcyMTUsXG5cdFx0YmFja2dyb3VuZENvbG9yOiBEQVJLXG5cdH0pO1xuXHRsZXQgaWQgPSByZWNvcmQuX192ZF9pZDtcblx0aWYgKGlkID09IG51bGwpIHtcblx0XHRpZCA9IFN0cmluZyhyb3V0ZVJlY29yZElkKyspO1xuXHRcdHJlY29yZC5fX3ZkX2lkID0gaWQ7XG5cdH1cblx0cmV0dXJuIHtcblx0XHRpZCxcblx0XHRsYWJlbDogcmVjb3JkLnBhdGgsXG5cdFx0dGFncyxcblx0XHRjaGlsZHJlbjogcm91dGUuY2hpbGRyZW4ubWFwKGZvcm1hdFJvdXRlUmVjb3JkRm9ySW5zcGVjdG9yKVxuXHR9O1xufVxubGV0IHJvdXRlUmVjb3JkSWQgPSAwO1xuY29uc3QgRVhUUkFDVF9SRUdFWFBfUkUgPSAvXlxcLyguKilcXC8oW2Etel0qKSQvO1xuZnVuY3Rpb24gbWFya1JvdXRlUmVjb3JkQWN0aXZlKHJvdXRlLCBjdXJyZW50Um91dGUpIHtcblx0Y29uc3QgaXNFeGFjdEFjdGl2ZSA9IGN1cnJlbnRSb3V0ZS5tYXRjaGVkLmxlbmd0aCAmJiBpc1NhbWVSb3V0ZVJlY29yZChjdXJyZW50Um91dGUubWF0Y2hlZFtjdXJyZW50Um91dGUubWF0Y2hlZC5sZW5ndGggLSAxXSwgcm91dGUucmVjb3JkKTtcblx0cm91dGUuX192ZF9leGFjdEFjdGl2ZSA9IHJvdXRlLl9fdmRfYWN0aXZlID0gaXNFeGFjdEFjdGl2ZTtcblx0aWYgKCFpc0V4YWN0QWN0aXZlKSByb3V0ZS5fX3ZkX2FjdGl2ZSA9IGN1cnJlbnRSb3V0ZS5tYXRjaGVkLnNvbWUoKG1hdGNoKSA9PiBpc1NhbWVSb3V0ZVJlY29yZChtYXRjaCwgcm91dGUucmVjb3JkKSk7XG5cdHJvdXRlLmNoaWxkcmVuLmZvckVhY2goKGNoaWxkUm91dGUpID0+IG1hcmtSb3V0ZVJlY29yZEFjdGl2ZShjaGlsZFJvdXRlLCBjdXJyZW50Um91dGUpKTtcbn1cbmZ1bmN0aW9uIHJlc2V0TWF0Y2hTdGF0ZU9uUm91dGVSZWNvcmQocm91dGUpIHtcblx0cm91dGUuX192ZF9tYXRjaCA9IGZhbHNlO1xuXHRyb3V0ZS5jaGlsZHJlbi5mb3JFYWNoKHJlc2V0TWF0Y2hTdGF0ZU9uUm91dGVSZWNvcmQpO1xufVxuZnVuY3Rpb24gaXNSb3V0ZU1hdGNoaW5nKHJvdXRlLCBmaWx0ZXIpIHtcblx0Y29uc3QgZm91bmQgPSBTdHJpbmcocm91dGUucmUpLm1hdGNoKEVYVFJBQ1RfUkVHRVhQX1JFKTtcblx0cm91dGUuX192ZF9tYXRjaCA9IGZhbHNlO1xuXHRpZiAoIWZvdW5kIHx8IGZvdW5kLmxlbmd0aCA8IDMpIHJldHVybiBmYWxzZTtcblx0aWYgKG5ldyBSZWdFeHAoZm91bmRbMV0ucmVwbGFjZSgvXFwkJC8sIFwiXCIpLCBmb3VuZFsyXSkudGVzdChmaWx0ZXIpKSB7XG5cdFx0cm91dGUuY2hpbGRyZW4uZm9yRWFjaCgoY2hpbGQpID0+IGlzUm91dGVNYXRjaGluZyhjaGlsZCwgZmlsdGVyKSk7XG5cdFx0aWYgKHJvdXRlLnJlY29yZC5wYXRoICE9PSBcIi9cIiB8fCBmaWx0ZXIgPT09IFwiL1wiKSB7XG5cdFx0XHRyb3V0ZS5fX3ZkX21hdGNoID0gcm91dGUucmUudGVzdChmaWx0ZXIpO1xuXHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0fVxuXHRcdHJldHVybiBmYWxzZTtcblx0fVxuXHRjb25zdCBwYXRoID0gcm91dGUucmVjb3JkLnBhdGgudG9Mb3dlckNhc2UoKTtcblx0Y29uc3QgZGVjb2RlZFBhdGggPSBkZWNvZGUocGF0aCk7XG5cdGlmICghZmlsdGVyLnN0YXJ0c1dpdGgoXCIvXCIpICYmIChkZWNvZGVkUGF0aC5pbmNsdWRlcyhmaWx0ZXIpIHx8IHBhdGguaW5jbHVkZXMoZmlsdGVyKSkpIHJldHVybiB0cnVlO1xuXHRpZiAoZGVjb2RlZFBhdGguc3RhcnRzV2l0aChmaWx0ZXIpIHx8IHBhdGguc3RhcnRzV2l0aChmaWx0ZXIpKSByZXR1cm4gdHJ1ZTtcblx0aWYgKHJvdXRlLnJlY29yZC5uYW1lICYmIFN0cmluZyhyb3V0ZS5yZWNvcmQubmFtZSkuaW5jbHVkZXMoZmlsdGVyKSkgcmV0dXJuIHRydWU7XG5cdHJldHVybiByb3V0ZS5jaGlsZHJlbi5zb21lKChjaGlsZCkgPT4gaXNSb3V0ZU1hdGNoaW5nKGNoaWxkLCBmaWx0ZXIpKTtcbn1cbmZ1bmN0aW9uIG9taXQob2JqLCBrZXlzKSB7XG5cdGNvbnN0IHJldCA9IHt9O1xuXHRmb3IgKGNvbnN0IGtleSBpbiBvYmopIGlmICgha2V5cy5pbmNsdWRlcyhrZXkpKSByZXRba2V5XSA9IG9ialtrZXldO1xuXHRyZXR1cm4gcmV0O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBQTFVTX1JFIGFzIEEsIGlzU2FtZVJvdXRlTG9jYXRpb24gYXMgQywgcmVzb2x2ZVJlbGF0aXZlUGF0aCBhcyBELCBwYXJzZVVSTCBhcyBFLCBpc0Jyb3dzZXIgYXMgRiwgZW5jb2RlSGFzaCBhcyBNLCBlbmNvZGVQYXJhbSBhcyBOLCBzdHJpbmdpZnlVUkwgYXMgTywgZW5jb2RlUGF0aCBhcyBQLCBTVEFSVF9MT0NBVElPTl9OT1JNQUxJWkVEIGFzIFMsIGlzU2FtZVJvdXRlUmVjb3JkIGFzIFQsIHNhdmVTY3JvbGxQb3NpdGlvbiBhcyBfLCBsb2FkUm91dGVMb2NhdGlvbiBhcyBhLCBub3JtYWxpemVCYXNlIGFzIGIsIHVzZUNhbGxiYWNrcyBhcyBjLCBzdHJpbmdpZnlRdWVyeSBhcyBkLCBpc1JvdXRlTG9jYXRpb24gYXMgZiwgZ2V0U2Nyb2xsS2V5IGFzIGcsIGdldFNhdmVkU2Nyb2xsUG9zaXRpb24gYXMgaCwgZ3VhcmRUb1Byb21pc2VGbiBhcyBpLCBkZWNvZGUgYXMgaiwgc3RyaXBCYXNlIGFzIGssIG5vcm1hbGl6ZVF1ZXJ5IGFzIGwsIGNvbXB1dGVTY3JvbGxQb3NpdGlvbiBhcyBtLCBleHRyYWN0Q2hhbmdpbmdSZWNvcmRzIGFzIG4sIG9uQmVmb3JlUm91dGVMZWF2ZSBhcyBvLCBpc1JvdXRlTmFtZSBhcyBwLCBleHRyYWN0Q29tcG9uZW50c0d1YXJkcyBhcyByLCBvbkJlZm9yZVJvdXRlVXBkYXRlIGFzIHMsIGFkZERldnRvb2xzIGFzIHQsIHBhcnNlUXVlcnkgYXMgdSwgc2Nyb2xsVG9Qb3NpdGlvbiBhcyB2LCBpc1NhbWVSb3V0ZUxvY2F0aW9uUGFyYW1zIGFzIHcsIE5FV19zdHJpbmdpZnlVUkwgYXMgeCwgY3JlYXRlSHJlZiBhcyB5IH07XG4iXSwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==