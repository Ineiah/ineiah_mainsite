import { basename, camelize, classify, deepClone, isBrowser, isNuxtApp, isUrlString, kebabize, target } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@vue+devtools-shared@8.2.1/node_modules/@vue/devtools-shared/dist/index.js?v=7e73afc2";
import { debounce } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/perfect-debounce@2.1.0/node_modules/perfect-debounce/dist/index.mjs?v=7e73afc2";
import { createHooks } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/hookable@5.5.3/node_modules/hookable/dist/index.mjs?v=7e73afc2";
import { createBirpc, createBirpcGroup } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/birpc@2.9.0/node_modules/birpc/dist/index.mjs?v=7e73afc2";
//#region \0rolldown/runtime.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJSMin = (cb, mod) => () => (mod || cb((mod = { exports: {} }).exports, mod), mod.exports);
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
//#endregion
//#region src/compat/index.ts
function onLegacyDevToolsPluginApiAvailable(cb) {
	if (target.__VUE_DEVTOOLS_PLUGIN_API_AVAILABLE__) {
		cb();
		return;
	}
	Object.defineProperty(target, "__VUE_DEVTOOLS_PLUGIN_API_AVAILABLE__", {
		set(value) {
			if (value) cb();
		},
		configurable: true
	});
}
//#endregion
//#region src/core/component/utils/index.ts
function getComponentTypeName(options) {
	if (typeof options === "function") return options.displayName || options.name || options.__VUE_DEVTOOLS_COMPONENT_GUSSED_NAME__ || "";
	const name = options.name || options._componentTag || options.__VUE_DEVTOOLS_COMPONENT_GUSSED_NAME__ || options.__name;
	if (name === "index" && options.__file?.endsWith("index.vue")) return "";
	return name;
}
function getComponentFileName(options) {
	const file = options.__file;
	if (file) return classify(basename(file, ".vue"));
}
function getComponentName(options) {
	const name = options.displayName || options.name || options._componentTag;
	if (name) return name;
	return getComponentFileName(options);
}
function saveComponentGussedName(instance, name) {
	instance.type.__VUE_DEVTOOLS_COMPONENT_GUSSED_NAME__ = name;
	return name;
}
function getAppRecord(instance) {
	if (instance.__VUE_DEVTOOLS_NEXT_APP_RECORD__) return instance.__VUE_DEVTOOLS_NEXT_APP_RECORD__;
	else if (instance.root) return instance.appContext.app.__VUE_DEVTOOLS_NEXT_APP_RECORD__;
}
async function getComponentId(options) {
	const { app, uid, instance } = options;
	try {
		if (instance.__VUE_DEVTOOLS_NEXT_UID__) return instance.__VUE_DEVTOOLS_NEXT_UID__;
		const appRecord = await getAppRecord(app);
		if (!appRecord) return null;
		const isRoot = appRecord.rootInstance === instance;
		return `${appRecord.id}:${isRoot ? "root" : uid}`;
	} catch (e) {}
}
function isFragment(instance) {
	const subTreeType = instance.subTree?.type;
	const appRecord = getAppRecord(instance);
	if (appRecord) return appRecord?.types?.Fragment === subTreeType;
	return false;
}
function isBeingDestroyed(instance) {
	return instance._isBeingDestroyed || instance.isUnmounted;
}
/**
* Get the appropriate display name for an instance.
*
* @param {Vue} instance
* @return {string}
*/
function getInstanceName(instance) {
	const name = getComponentTypeName(instance?.type || {});
	if (name) return name;
	if (instance?.root === instance) return "Root";
	for (const key in instance.parent?.type?.components) if (instance.parent.type.components[key] === instance?.type) return saveComponentGussedName(instance, key);
	for (const key in instance.appContext?.components) if (instance.appContext.components[key] === instance?.type) return saveComponentGussedName(instance, key);
	const fileName = getComponentFileName(instance?.type || {});
	if (fileName) return fileName;
	return "Anonymous Component";
}
/**
* Returns a devtools unique id for instance.
* @param {Vue} instance
*/
function getUniqueComponentId(instance) {
	return `${instance?.appContext?.app?.__VUE_DEVTOOLS_NEXT_APP_RECORD_ID__ ?? 0}:${instance === instance?.root ? "root" : instance.uid}`;
}
function getRenderKey(value) {
	if (value == null) return "";
	if (typeof value === "number") return value;
	else if (typeof value === "string") return `'${value}'`;
	else if (Array.isArray(value)) return "Array";
	else return "Object";
}
function returnError(cb) {
	try {
		return cb();
	} catch (e) {
		return e;
	}
}
function getComponentInstance(appRecord, instanceId) {
	instanceId = instanceId || `${appRecord.id}:root`;
	return appRecord.instanceMap.get(instanceId) || appRecord.instanceMap.get(":root");
}
function ensurePropertyExists(obj, key, skipObjCheck = false) {
	return skipObjCheck ? key in obj : typeof obj === "object" && obj !== null ? key in obj : false;
}
//#endregion
//#region src/core/component/state/bounding-rect.ts
function createRect() {
	const rect = {
		top: 0,
		bottom: 0,
		left: 0,
		right: 0,
		get width() {
			return rect.right - rect.left;
		},
		get height() {
			return rect.bottom - rect.top;
		}
	};
	return rect;
}
let range;
function getTextRect(node) {
	if (!range) range = document.createRange();
	range.selectNode(node);
	return range.getBoundingClientRect();
}
function getFragmentRect(vnode) {
	const rect = createRect();
	if (!vnode.children) return rect;
	for (let i = 0, l = vnode.children.length; i < l; i++) {
		const childVnode = vnode.children[i];
		let childRect;
		if (childVnode.component) childRect = getComponentBoundingRect(childVnode.component);
		else if (childVnode.el) {
			const el = childVnode.el;
			if (el.nodeType === 1 || el.getBoundingClientRect) childRect = el.getBoundingClientRect();
			else if (el.nodeType === 3 && el.data.trim()) childRect = getTextRect(el);
		}
		if (childRect) mergeRects(rect, childRect);
	}
	return rect;
}
function mergeRects(a, b) {
	if (!a.top || b.top < a.top) a.top = b.top;
	if (!a.bottom || b.bottom > a.bottom) a.bottom = b.bottom;
	if (!a.left || b.left < a.left) a.left = b.left;
	if (!a.right || b.right > a.right) a.right = b.right;
	return a;
}
const DEFAULT_RECT = {
	top: 0,
	left: 0,
	right: 0,
	bottom: 0,
	width: 0,
	height: 0
};
function getComponentBoundingRect(instance) {
	const el = instance.subTree.el;
	if (typeof window === "undefined") return DEFAULT_RECT;
	if (isFragment(instance)) return getFragmentRect(instance.subTree);
	else if (el?.nodeType === 1) return el?.getBoundingClientRect();
	else if (instance.subTree.component) return getComponentBoundingRect(instance.subTree.component);
	else return DEFAULT_RECT;
}
//#endregion
//#region src/core/component/tree/el.ts
function getRootElementsFromComponentInstance(instance) {
	if (isFragment(instance)) return getFragmentRootElements(instance.subTree);
	if (!instance.subTree) return [];
	return [instance.subTree.el];
}
function getFragmentRootElements(vnode) {
	if (!vnode.children) return [];
	const list = [];
	vnode.children.forEach((childVnode) => {
		if (childVnode.component) list.push(...getRootElementsFromComponentInstance(childVnode.component));
		else if (childVnode?.el) list.push(childVnode.el);
	});
	return list;
}
//#endregion
//#region src/core/component-highlighter/index.ts
const CONTAINER_ELEMENT_ID = "__vue-devtools-component-inspector__";
const CARD_ELEMENT_ID = "__vue-devtools-component-inspector__card__";
const COMPONENT_NAME_ELEMENT_ID = "__vue-devtools-component-inspector__name__";
const INDICATOR_ELEMENT_ID = "__vue-devtools-component-inspector__indicator__";
const containerStyles = {
	display: "block",
	zIndex: 2147483640,
	position: "fixed",
	backgroundColor: "#42b88325",
	border: "1px solid #42b88350",
	borderRadius: "5px",
	transition: "all 0.1s ease-in",
	pointerEvents: "none"
};
const cardStyles = {
	fontFamily: "Arial, Helvetica, sans-serif",
	padding: "5px 8px",
	borderRadius: "4px",
	textAlign: "left",
	position: "absolute",
	left: 0,
	color: "#e9e9e9",
	fontSize: "14px",
	fontWeight: 600,
	lineHeight: "24px",
	backgroundColor: "#42b883",
	boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px -1px rgba(0, 0, 0, 0.1)"
};
const indicatorStyles = {
	display: "inline-block",
	fontWeight: 400,
	fontStyle: "normal",
	fontSize: "12px",
	opacity: .7
};
function getContainerElement() {
	return document.getElementById(CONTAINER_ELEMENT_ID);
}
function getCardElement() {
	return document.getElementById(CARD_ELEMENT_ID);
}
function getIndicatorElement() {
	return document.getElementById(INDICATOR_ELEMENT_ID);
}
function getNameElement() {
	return document.getElementById(COMPONENT_NAME_ELEMENT_ID);
}
function getStyles(bounds) {
	return {
		left: `${Math.round(bounds.left * 100) / 100}px`,
		top: `${Math.round(bounds.top * 100) / 100}px`,
		width: `${Math.round(bounds.width * 100) / 100}px`,
		height: `${Math.round(bounds.height * 100) / 100}px`
	};
}
function create(options) {
	const containerEl = document.createElement("div");
	containerEl.id = options.elementId ?? CONTAINER_ELEMENT_ID;
	Object.assign(containerEl.style, {
		...containerStyles,
		...getStyles(options.bounds),
		...options.style
	});
	const cardEl = document.createElement("span");
	cardEl.id = CARD_ELEMENT_ID;
	Object.assign(cardEl.style, {
		...cardStyles,
		top: options.bounds.top < 35 ? 0 : "-35px"
	});
	const nameEl = document.createElement("span");
	nameEl.id = COMPONENT_NAME_ELEMENT_ID;
	nameEl.innerHTML = `&lt;${options.name}&gt;&nbsp;&nbsp;`;
	const indicatorEl = document.createElement("i");
	indicatorEl.id = INDICATOR_ELEMENT_ID;
	indicatorEl.innerHTML = `${Math.round(options.bounds.width * 100) / 100} x ${Math.round(options.bounds.height * 100) / 100}`;
	Object.assign(indicatorEl.style, indicatorStyles);
	cardEl.appendChild(nameEl);
	cardEl.appendChild(indicatorEl);
	containerEl.appendChild(cardEl);
	document.body.appendChild(containerEl);
	return containerEl;
}
function update(options) {
	const containerEl = getContainerElement();
	const cardEl = getCardElement();
	const nameEl = getNameElement();
	const indicatorEl = getIndicatorElement();
	if (containerEl) {
		Object.assign(containerEl.style, {
			...containerStyles,
			...getStyles(options.bounds)
		});
		Object.assign(cardEl.style, { top: options.bounds.top < 35 ? 0 : "-35px" });
		nameEl.innerHTML = `&lt;${options.name}&gt;&nbsp;&nbsp;`;
		indicatorEl.innerHTML = `${Math.round(options.bounds.width * 100) / 100} x ${Math.round(options.bounds.height * 100) / 100}`;
	}
}
function highlight(instance) {
	const bounds = getComponentBoundingRect(instance);
	if (!bounds.width && !bounds.height) return;
	const name = getInstanceName(instance);
	getContainerElement() ? update({
		bounds,
		name
	}) : create({
		bounds,
		name
	});
}
function unhighlight() {
	const el = getContainerElement();
	if (el) el.style.display = "none";
}
let inspectInstance = null;
function inspectFn(e) {
	const target = e.target;
	if (target) {
		const instance = target.__vueParentComponent;
		if (instance) {
			inspectInstance = instance;
			if (instance.vnode.el) {
				const bounds = getComponentBoundingRect(instance);
				const name = getInstanceName(instance);
				getContainerElement() ? update({
					bounds,
					name
				}) : create({
					bounds,
					name
				});
			}
		}
	}
}
function selectComponentFn(e, cb) {
	e.preventDefault();
	e.stopPropagation();
	if (inspectInstance) cb(getUniqueComponentId(inspectInstance));
}
let inspectComponentHighLighterSelectFn = null;
function cancelInspectComponentHighLighter() {
	unhighlight();
	window.removeEventListener("mouseover", inspectFn);
	window.removeEventListener("click", inspectComponentHighLighterSelectFn, true);
	inspectComponentHighLighterSelectFn = null;
}
function inspectComponentHighLighter() {
	window.addEventListener("mouseover", inspectFn);
	return new Promise((resolve) => {
		function onSelect(e) {
			e.preventDefault();
			e.stopPropagation();
			selectComponentFn(e, (id) => {
				window.removeEventListener("click", onSelect, true);
				inspectComponentHighLighterSelectFn = null;
				window.removeEventListener("mouseover", inspectFn);
				const el = getContainerElement();
				if (el) el.style.display = "none";
				resolve(JSON.stringify({ id }));
			});
		}
		inspectComponentHighLighterSelectFn = onSelect;
		window.addEventListener("click", onSelect, true);
	});
}
function scrollToComponent(options) {
	const instance = getComponentInstance(activeAppRecord.value, options.id);
	if (instance) {
		const [el] = getRootElementsFromComponentInstance(instance);
		if (typeof el.scrollIntoView === "function") el.scrollIntoView({ behavior: "smooth" });
		else {
			const bounds = getComponentBoundingRect(instance);
			const scrollTarget = document.createElement("div");
			const styles = {
				...getStyles(bounds),
				position: "absolute"
			};
			Object.assign(scrollTarget.style, styles);
			document.body.appendChild(scrollTarget);
			scrollTarget.scrollIntoView({ behavior: "smooth" });
			setTimeout(() => {
				document.body.removeChild(scrollTarget);
			}, 2e3);
		}
		setTimeout(() => {
			const bounds = getComponentBoundingRect(instance);
			if (bounds.width || bounds.height) {
				const name = getInstanceName(instance);
				const el = getContainerElement();
				el ? update({
					...options,
					name,
					bounds
				}) : create({
					...options,
					name,
					bounds
				});
				setTimeout(() => {
					if (el) el.style.display = "none";
				}, 1500);
			}
		}, 1200);
	}
}
//#endregion
//#region src/core/component-inspector/index.ts
target.__VUE_DEVTOOLS_COMPONENT_INSPECTOR_ENABLED__ ??= true;
function toggleComponentInspectorEnabled(enabled) {
	target.__VUE_DEVTOOLS_COMPONENT_INSPECTOR_ENABLED__ = enabled;
}
function waitForInspectorInit(cb) {
	let total = 0;
	const timer = setInterval(() => {
		if (target.__VUE_INSPECTOR__) {
			clearInterval(timer);
			total += 30;
			cb();
		}
		if (total >= 5e3) clearInterval(timer);
	}, 30);
}
function setupInspector() {
	const inspector = target.__VUE_INSPECTOR__;
	const _openInEditor = inspector.openInEditor;
	inspector.openInEditor = async (...params) => {
		inspector.disable();
		_openInEditor(...params);
	};
}
function getComponentInspector() {
	return new Promise((resolve) => {
		function setup() {
			setupInspector();
			resolve(target.__VUE_INSPECTOR__);
		}
		if (!target.__VUE_INSPECTOR__) waitForInspectorInit(() => {
			setup();
		});
		else setup();
	});
}
//#endregion
//#region src/shared/stub-vue.ts
/**
* To prevent include a **HUGE** vue package in the final bundle of chrome ext / electron
* we stub the necessary vue module.
* This implementation is based on the 1c3327a0fa5983aa9078e3f7bb2330f572435425 commit
*/
/**
* @from [@vue/reactivity](https://github.com/vuejs/core/blob/1c3327a0fa5983aa9078e3f7bb2330f572435425/packages/reactivity/src/constants.ts#L17-L23)
*/
let ReactiveFlags = /* @__PURE__ */ function(ReactiveFlags) {
	ReactiveFlags["SKIP"] = "__v_skip";
	ReactiveFlags["IS_REACTIVE"] = "__v_isReactive";
	ReactiveFlags["IS_READONLY"] = "__v_isReadonly";
	ReactiveFlags["IS_SHALLOW"] = "__v_isShallow";
	ReactiveFlags["RAW"] = "__v_raw";
	return ReactiveFlags;
}({});
/**
* @from [@vue/reactivity](https://github.com/vuejs/core/blob/1c3327a0fa5983aa9078e3f7bb2330f572435425/packages/reactivity/src/reactive.ts#L330-L332)
*/
function isReadonly(value) {
	return !!(value && value[ReactiveFlags.IS_READONLY]);
}
/**
* @from [@vue/reactivity](https://github.com/vuejs/core/blob/1c3327a0fa5983aa9078e3f7bb2330f572435425/packages/reactivity/src/reactive.ts#L312-L317)
*/
function isReactive$1(value) {
	if (isReadonly(value)) return isReactive$1(value[ReactiveFlags.RAW]);
	return !!(value && value[ReactiveFlags.IS_REACTIVE]);
}
function isRef$1(r) {
	return !!(r && r.__v_isRef === true);
}
/**
* @from [@vue/reactivity](https://github.com/vuejs/core/blob/1c3327a0fa5983aa9078e3f7bb2330f572435425/packages/reactivity/src/reactive.ts#L372-L375)
*/
function toRaw$1(observed) {
	const raw = observed && observed[ReactiveFlags.RAW];
	return raw ? toRaw$1(raw) : observed;
}
//#endregion
//#region src/core/component/state/editor.ts
var StateEditor = class {
	constructor() {
		this.refEditor = new RefStateEditor();
	}
	set(object, path, value, cb) {
		const sections = Array.isArray(path) ? path : path.split(".");
		while (sections.length > 1) {
			const section = sections.shift();
			if (object instanceof Map) object = object.get(section);
			else if (object instanceof Set) object = Array.from(object.values())[section];
			else object = object[section];
			if (this.refEditor.isRef(object)) object = this.refEditor.get(object);
		}
		const field = sections[0];
		const item = this.refEditor.get(object)[field];
		if (cb) cb(object, field, value);
		else if (this.refEditor.isRef(item)) this.refEditor.set(item, value);
		else object[field] = value;
	}
	get(object, path) {
		const sections = Array.isArray(path) ? path : path.split(".");
		for (let i = 0; i < sections.length; i++) {
			if (object instanceof Map) object = object.get(sections[i]);
			else object = object[sections[i]];
			if (this.refEditor.isRef(object)) object = this.refEditor.get(object);
			if (!object) return void 0;
		}
		return object;
	}
	has(object, path, parent = false) {
		if (typeof object === "undefined") return false;
		const sections = Array.isArray(path) ? path.slice() : path.split(".");
		const size = !parent ? 1 : 2;
		while (object && sections.length > size) {
			const section = sections.shift();
			object = object[section];
			if (this.refEditor.isRef(object)) object = this.refEditor.get(object);
		}
		return object != null && Object.prototype.hasOwnProperty.call(object, sections[0]);
	}
	createDefaultSetCallback(state) {
		return (object, field, value) => {
			if (state.remove || state.newKey) if (Array.isArray(object)) object.splice(field, 1);
			else if (toRaw$1(object) instanceof Map) object.delete(field);
			else if (toRaw$1(object) instanceof Set) object.delete(Array.from(object.values())[field]);
			else Reflect.deleteProperty(object, field);
			if (!state.remove) {
				const target = object[state.newKey || field];
				if (this.refEditor.isRef(target)) this.refEditor.set(target, value);
				else if (toRaw$1(object) instanceof Map) object.set(state.newKey || field, value);
				else if (toRaw$1(object) instanceof Set) object.add(value);
				else object[state.newKey || field] = value;
			}
		};
	}
};
var RefStateEditor = class {
	set(ref, value) {
		if (isRef$1(ref)) ref.value = value;
		else {
			if (ref instanceof Set && Array.isArray(value)) {
				ref.clear();
				value.forEach((v) => ref.add(v));
				return;
			}
			const currentKeys = Object.keys(value);
			if (ref instanceof Map) {
				const previousKeysSet = new Set(ref.keys());
				currentKeys.forEach((key) => {
					ref.set(key, Reflect.get(value, key));
					previousKeysSet.delete(key);
				});
				previousKeysSet.forEach((key) => ref.delete(key));
				return;
			}
			const previousKeysSet = new Set(Object.keys(ref));
			currentKeys.forEach((key) => {
				Reflect.set(ref, key, Reflect.get(value, key));
				previousKeysSet.delete(key);
			});
			previousKeysSet.forEach((key) => Reflect.deleteProperty(ref, key));
		}
	}
	get(ref) {
		return isRef$1(ref) ? ref.value : ref;
	}
	isRef(ref) {
		return isRef$1(ref) || isReactive$1(ref);
	}
};
async function editComponentState(payload, stateEditor) {
	const { path, nodeId, state, type } = payload;
	const instance = getComponentInstance(activeAppRecord.value, nodeId);
	if (!instance) return;
	const targetPath = path.slice();
	let target;
	if (Object.keys(instance.props).includes(path[0])) target = instance.props;
	else if (instance.devtoolsRawSetupState && Object.keys(instance.devtoolsRawSetupState).includes(path[0])) target = instance.devtoolsRawSetupState;
	else if (instance.data && Object.keys(instance.data).includes(path[0])) target = instance.data;
	else target = instance.proxy;
	if (target && targetPath) {
		if (state.type === "object" && type === "reactive") {}
		stateEditor.set(target, targetPath, state.value, stateEditor.createDefaultSetCallback(state));
	}
}
const stateEditor = new StateEditor();
async function editState(payload) {
	editComponentState(payload, stateEditor);
}
//#endregion
//#region src/core/timeline/storage.ts
const TIMELINE_LAYERS_STATE_STORAGE_ID = "__VUE_DEVTOOLS_KIT_TIMELINE_LAYERS_STATE__";
function addTimelineLayersStateToStorage(state) {
	if (!isBrowser || typeof localStorage === "undefined" || localStorage === null) return;
	localStorage.setItem(TIMELINE_LAYERS_STATE_STORAGE_ID, JSON.stringify(state));
}
function getTimelineLayersStateFromStorage() {
	if (typeof window === "undefined" || !isBrowser || typeof localStorage === "undefined" || localStorage === null) return {
		recordingState: false,
		mouseEventEnabled: false,
		keyboardEventEnabled: false,
		componentEventEnabled: false,
		performanceEventEnabled: false,
		selected: ""
	};
	const state = typeof localStorage.getItem !== "undefined" ? localStorage.getItem(TIMELINE_LAYERS_STATE_STORAGE_ID) : null;
	return state ? JSON.parse(state) : {
		recordingState: false,
		mouseEventEnabled: false,
		keyboardEventEnabled: false,
		componentEventEnabled: false,
		performanceEventEnabled: false,
		selected: ""
	};
}
//#endregion
//#region src/ctx/timeline.ts
target.__VUE_DEVTOOLS_KIT_TIMELINE_LAYERS ??= [];
const devtoolsTimelineLayers = new Proxy(target.__VUE_DEVTOOLS_KIT_TIMELINE_LAYERS, { get(target, prop, receiver) {
	return Reflect.get(target, prop, receiver);
} });
function addTimelineLayer(options, descriptor) {
	devtoolsState.timelineLayersState[descriptor.id] = false;
	devtoolsTimelineLayers.push({
		...options,
		descriptorId: descriptor.id,
		appRecord: getAppRecord(descriptor.app)
	});
}
function updateTimelineLayersState(state) {
	const updatedState = {
		...devtoolsState.timelineLayersState,
		...state
	};
	addTimelineLayersStateToStorage(updatedState);
	updateDevToolsState({ timelineLayersState: updatedState });
}
//#endregion
//#region src/ctx/inspector.ts
target.__VUE_DEVTOOLS_KIT_INSPECTOR__ ??= [];
const devtoolsInspector = new Proxy(target.__VUE_DEVTOOLS_KIT_INSPECTOR__, { get(target, prop, receiver) {
	return Reflect.get(target, prop, receiver);
} });
const callInspectorUpdatedHook = debounce(() => {
	devtoolsContext.hooks.callHook(DevToolsMessagingHookKeys.SEND_INSPECTOR_TO_CLIENT, getActiveInspectors());
});
function addInspector(inspector, descriptor) {
	devtoolsInspector.push({
		options: inspector,
		descriptor,
		treeFilterPlaceholder: inspector.treeFilterPlaceholder ?? "Search tree...",
		stateFilterPlaceholder: inspector.stateFilterPlaceholder ?? "Search state...",
		treeFilter: "",
		selectedNodeId: "",
		appRecord: getAppRecord(descriptor.app)
	});
	callInspectorUpdatedHook();
}
function getActiveInspectors() {
	return devtoolsInspector.filter((inspector) => inspector.descriptor.app === activeAppRecord.value.app).filter((inspector) => inspector.descriptor.id !== "components").map((inspector) => {
		const descriptor = inspector.descriptor;
		const options = inspector.options;
		return {
			id: options.id,
			label: options.label,
			logo: descriptor.logo,
			icon: `custom-ic-baseline-${options?.icon?.replace(/_/g, "-")}`,
			packageName: descriptor.packageName,
			homepage: descriptor.homepage,
			pluginId: descriptor.id
		};
	});
}
function getInspectorInfo(id) {
	const inspector = getInspector(id, activeAppRecord.value.app);
	if (!inspector) return;
	const descriptor = inspector.descriptor;
	const options = inspector.options;
	const timelineLayers = devtoolsTimelineLayers.filter((layer) => layer.descriptorId === descriptor.id).map((item) => ({
		id: item.id,
		label: item.label,
		color: item.color
	}));
	return {
		id: options.id,
		label: options.label,
		logo: descriptor.logo,
		packageName: descriptor.packageName,
		homepage: descriptor.homepage,
		timelineLayers,
		treeFilterPlaceholder: inspector.treeFilterPlaceholder,
		stateFilterPlaceholder: inspector.stateFilterPlaceholder
	};
}
function getInspector(id, app) {
	return devtoolsInspector.find((inspector) => inspector.options.id === id && (app ? inspector.descriptor.app === app : true));
}
function getInspectorActions(id) {
	return getInspector(id)?.options.actions;
}
function getInspectorNodeActions(id) {
	return getInspector(id)?.options.nodeActions;
}
//#endregion
//#region src/ctx/hook.ts
let DevToolsV6PluginAPIHookKeys = /* @__PURE__ */ function(DevToolsV6PluginAPIHookKeys) {
	DevToolsV6PluginAPIHookKeys["VISIT_COMPONENT_TREE"] = "visitComponentTree";
	DevToolsV6PluginAPIHookKeys["INSPECT_COMPONENT"] = "inspectComponent";
	DevToolsV6PluginAPIHookKeys["EDIT_COMPONENT_STATE"] = "editComponentState";
	DevToolsV6PluginAPIHookKeys["GET_INSPECTOR_TREE"] = "getInspectorTree";
	DevToolsV6PluginAPIHookKeys["GET_INSPECTOR_STATE"] = "getInspectorState";
	DevToolsV6PluginAPIHookKeys["EDIT_INSPECTOR_STATE"] = "editInspectorState";
	DevToolsV6PluginAPIHookKeys["INSPECT_TIMELINE_EVENT"] = "inspectTimelineEvent";
	DevToolsV6PluginAPIHookKeys["TIMELINE_CLEARED"] = "timelineCleared";
	DevToolsV6PluginAPIHookKeys["SET_PLUGIN_SETTINGS"] = "setPluginSettings";
	return DevToolsV6PluginAPIHookKeys;
}({});
let DevToolsContextHookKeys = /* @__PURE__ */ function(DevToolsContextHookKeys) {
	DevToolsContextHookKeys["ADD_INSPECTOR"] = "addInspector";
	DevToolsContextHookKeys["SEND_INSPECTOR_TREE"] = "sendInspectorTree";
	DevToolsContextHookKeys["SEND_INSPECTOR_STATE"] = "sendInspectorState";
	DevToolsContextHookKeys["CUSTOM_INSPECTOR_SELECT_NODE"] = "customInspectorSelectNode";
	DevToolsContextHookKeys["TIMELINE_LAYER_ADDED"] = "timelineLayerAdded";
	DevToolsContextHookKeys["TIMELINE_EVENT_ADDED"] = "timelineEventAdded";
	DevToolsContextHookKeys["GET_COMPONENT_INSTANCES"] = "getComponentInstances";
	DevToolsContextHookKeys["GET_COMPONENT_BOUNDS"] = "getComponentBounds";
	DevToolsContextHookKeys["GET_COMPONENT_NAME"] = "getComponentName";
	DevToolsContextHookKeys["COMPONENT_HIGHLIGHT"] = "componentHighlight";
	DevToolsContextHookKeys["COMPONENT_UNHIGHLIGHT"] = "componentUnhighlight";
	return DevToolsContextHookKeys;
}({});
let DevToolsMessagingHookKeys = /* @__PURE__ */ function(DevToolsMessagingHookKeys) {
	DevToolsMessagingHookKeys["SEND_INSPECTOR_TREE_TO_CLIENT"] = "sendInspectorTreeToClient";
	DevToolsMessagingHookKeys["SEND_INSPECTOR_STATE_TO_CLIENT"] = "sendInspectorStateToClient";
	DevToolsMessagingHookKeys["SEND_TIMELINE_EVENT_TO_CLIENT"] = "sendTimelineEventToClient";
	DevToolsMessagingHookKeys["SEND_INSPECTOR_TO_CLIENT"] = "sendInspectorToClient";
	DevToolsMessagingHookKeys["SEND_ACTIVE_APP_UNMOUNTED_TO_CLIENT"] = "sendActiveAppUpdatedToClient";
	DevToolsMessagingHookKeys["DEVTOOLS_STATE_UPDATED"] = "devtoolsStateUpdated";
	DevToolsMessagingHookKeys["DEVTOOLS_CONNECTED_UPDATED"] = "devtoolsConnectedUpdated";
	DevToolsMessagingHookKeys["ROUTER_INFO_UPDATED"] = "routerInfoUpdated";
	return DevToolsMessagingHookKeys;
}({});
function createDevToolsCtxHooks() {
	const hooks = createHooks();
	hooks.hook(DevToolsContextHookKeys.ADD_INSPECTOR, ({ inspector, plugin }) => {
		addInspector(inspector, plugin.descriptor);
	});
	const debounceSendInspectorTree = debounce(async ({ inspectorId, plugin }) => {
		if (!inspectorId || !plugin?.descriptor?.app || devtoolsState.highPerfModeEnabled) return;
		const inspector = getInspector(inspectorId, plugin.descriptor.app);
		const _payload = {
			app: plugin.descriptor.app,
			inspectorId,
			filter: inspector?.treeFilter || "",
			rootNodes: []
		};
		await new Promise((resolve) => {
			hooks.callHookWith(async (callbacks) => {
				await Promise.all(callbacks.map((cb) => cb(_payload)));
				resolve();
			}, DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_TREE);
		});
		hooks.callHookWith(async (callbacks) => {
			await Promise.all(callbacks.map((cb) => cb({
				inspectorId,
				rootNodes: _payload.rootNodes
			})));
		}, DevToolsMessagingHookKeys.SEND_INSPECTOR_TREE_TO_CLIENT);
	}, 120);
	hooks.hook(DevToolsContextHookKeys.SEND_INSPECTOR_TREE, debounceSendInspectorTree);
	const debounceSendInspectorState = debounce(async ({ inspectorId, plugin }) => {
		if (!inspectorId || !plugin?.descriptor?.app || devtoolsState.highPerfModeEnabled) return;
		const inspector = getInspector(inspectorId, plugin.descriptor.app);
		const _payload = {
			app: plugin.descriptor.app,
			inspectorId,
			nodeId: inspector?.selectedNodeId || "",
			state: null
		};
		const ctx = { currentTab: `custom-inspector:${inspectorId}` };
		if (_payload.nodeId) await new Promise((resolve) => {
			hooks.callHookWith(async (callbacks) => {
				await Promise.all(callbacks.map((cb) => cb(_payload, ctx)));
				resolve();
			}, DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_STATE);
		});
		hooks.callHookWith(async (callbacks) => {
			await Promise.all(callbacks.map((cb) => cb({
				inspectorId,
				nodeId: _payload.nodeId,
				state: _payload.state
			})));
		}, DevToolsMessagingHookKeys.SEND_INSPECTOR_STATE_TO_CLIENT);
	}, 120);
	hooks.hook(DevToolsContextHookKeys.SEND_INSPECTOR_STATE, debounceSendInspectorState);
	hooks.hook(DevToolsContextHookKeys.CUSTOM_INSPECTOR_SELECT_NODE, ({ inspectorId, nodeId, plugin }) => {
		const inspector = getInspector(inspectorId, plugin.descriptor.app);
		if (!inspector) return;
		inspector.selectedNodeId = nodeId;
	});
	hooks.hook(DevToolsContextHookKeys.TIMELINE_LAYER_ADDED, ({ options, plugin }) => {
		addTimelineLayer(options, plugin.descriptor);
	});
	hooks.hook(DevToolsContextHookKeys.TIMELINE_EVENT_ADDED, ({ options, plugin }) => {
		if (devtoolsState.highPerfModeEnabled || !devtoolsState.timelineLayersState?.[plugin.descriptor.id] && ![
			"performance",
			"component-event",
			"keyboard",
			"mouse"
		].includes(options.layerId)) return;
		hooks.callHookWith(async (callbacks) => {
			await Promise.all(callbacks.map((cb) => cb(options)));
		}, DevToolsMessagingHookKeys.SEND_TIMELINE_EVENT_TO_CLIENT);
	});
	hooks.hook(DevToolsContextHookKeys.GET_COMPONENT_INSTANCES, async ({ app }) => {
		const appRecord = app.__VUE_DEVTOOLS_NEXT_APP_RECORD__;
		if (!appRecord) return null;
		const appId = appRecord.id.toString();
		return [...appRecord.instanceMap].filter(([key]) => key.split(":")[0] === appId).map(([, instance]) => instance);
	});
	hooks.hook(DevToolsContextHookKeys.GET_COMPONENT_BOUNDS, async ({ instance }) => {
		return getComponentBoundingRect(instance);
	});
	hooks.hook(DevToolsContextHookKeys.GET_COMPONENT_NAME, ({ instance }) => {
		return getInstanceName(instance);
	});
	hooks.hook(DevToolsContextHookKeys.COMPONENT_HIGHLIGHT, ({ uid }) => {
		const instance = activeAppRecord.value.instanceMap.get(uid);
		if (instance) highlight(instance);
	});
	hooks.hook(DevToolsContextHookKeys.COMPONENT_UNHIGHLIGHT, () => {
		unhighlight();
	});
	return hooks;
}
//#endregion
//#region src/ctx/state.ts
target.__VUE_DEVTOOLS_KIT_APP_RECORDS__ ??= [];
target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD__ ??= {};
target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD_ID__ ??= "";
target.__VUE_DEVTOOLS_KIT_CUSTOM_TABS__ ??= [];
target.__VUE_DEVTOOLS_KIT_CUSTOM_COMMANDS__ ??= [];
const STATE_KEY = "__VUE_DEVTOOLS_KIT_GLOBAL_STATE__";
function initStateFactory() {
	return {
		connected: false,
		clientConnected: false,
		vitePluginDetected: true,
		appRecords: [],
		activeAppRecordId: "",
		tabs: [],
		commands: [],
		highPerfModeEnabled: true,
		devtoolsClientDetected: {},
		perfUniqueGroupId: 0,
		timelineLayersState: getTimelineLayersStateFromStorage()
	};
}
target[STATE_KEY] ??= initStateFactory();
const callStateUpdatedHook = debounce((state) => {
	devtoolsContext.hooks.callHook(DevToolsMessagingHookKeys.DEVTOOLS_STATE_UPDATED, { state });
});
const callConnectedUpdatedHook = debounce((state, oldState) => {
	devtoolsContext.hooks.callHook(DevToolsMessagingHookKeys.DEVTOOLS_CONNECTED_UPDATED, {
		state,
		oldState
	});
});
const devtoolsAppRecords = new Proxy(target.__VUE_DEVTOOLS_KIT_APP_RECORDS__, { get(_target, prop, receiver) {
	if (prop === "value") return target.__VUE_DEVTOOLS_KIT_APP_RECORDS__;
	return target.__VUE_DEVTOOLS_KIT_APP_RECORDS__[prop];
} });
const addDevToolsAppRecord = (app) => {
	target.__VUE_DEVTOOLS_KIT_APP_RECORDS__ = [...target.__VUE_DEVTOOLS_KIT_APP_RECORDS__, app];
};
const removeDevToolsAppRecord = (app) => {
	target.__VUE_DEVTOOLS_KIT_APP_RECORDS__ = devtoolsAppRecords.value.filter((record) => record.app !== app);
};
const activeAppRecord = new Proxy(target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD__, { get(_target, prop, receiver) {
	if (prop === "value") return target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD__;
	else if (prop === "id") return target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD_ID__;
	return target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD__[prop];
} });
function updateAllStates() {
	callStateUpdatedHook({
		...target[STATE_KEY],
		appRecords: devtoolsAppRecords.value,
		activeAppRecordId: activeAppRecord.id,
		tabs: target.__VUE_DEVTOOLS_KIT_CUSTOM_TABS__,
		commands: target.__VUE_DEVTOOLS_KIT_CUSTOM_COMMANDS__
	});
}
function setActiveAppRecord(app) {
	target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD__ = app;
	updateAllStates();
}
function setActiveAppRecordId(id) {
	target.__VUE_DEVTOOLS_KIT_ACTIVE_APP_RECORD_ID__ = id;
	updateAllStates();
}
const devtoolsState = new Proxy(target[STATE_KEY], {
	get(target$3, property) {
		if (property === "appRecords") return devtoolsAppRecords;
		else if (property === "activeAppRecordId") return activeAppRecord.id;
		else if (property === "tabs") return target.__VUE_DEVTOOLS_KIT_CUSTOM_TABS__;
		else if (property === "commands") return target.__VUE_DEVTOOLS_KIT_CUSTOM_COMMANDS__;
		return target[STATE_KEY][property];
	},
	deleteProperty(target, property) {
		delete target[property];
		return true;
	},
	set(target$4, property, value) {
		target$4[property] = value;
		target[STATE_KEY][property] = value;
		return true;
	}
});
function resetDevToolsState() {
	Object.assign(target[STATE_KEY], initStateFactory());
}
function updateDevToolsState(state) {
	const oldState = {
		...target[STATE_KEY],
		appRecords: devtoolsAppRecords.value,
		activeAppRecordId: activeAppRecord.id
	};
	if (oldState.connected !== state.connected && state.connected || oldState.clientConnected !== state.clientConnected && state.clientConnected) callConnectedUpdatedHook(target[STATE_KEY], oldState);
	Object.assign(target[STATE_KEY], state);
	updateAllStates();
}
function onDevToolsConnected(fn) {
	return new Promise((resolve) => {
		if (devtoolsState.connected) {
			fn();
			resolve();
		}
		devtoolsContext.hooks.hook(DevToolsMessagingHookKeys.DEVTOOLS_CONNECTED_UPDATED, ({ state }) => {
			if (state.connected) {
				fn();
				resolve();
			}
		});
	});
}
const resolveIcon = (icon) => {
	if (!icon) return;
	if (icon.startsWith("baseline-")) return `custom-ic-${icon}`;
	if (icon.startsWith("i-") || isUrlString(icon)) return icon;
	return `custom-ic-baseline-${icon}`;
};
function addCustomTab(tab) {
	const tabs = target.__VUE_DEVTOOLS_KIT_CUSTOM_TABS__;
	if (tabs.some((t) => t.name === tab.name)) return;
	tabs.push({
		...tab,
		icon: resolveIcon(tab.icon)
	});
	updateAllStates();
}
function addCustomCommand(action) {
	const commands = target.__VUE_DEVTOOLS_KIT_CUSTOM_COMMANDS__;
	if (commands.some((t) => t.id === action.id)) return;
	commands.push({
		...action,
		icon: resolveIcon(action.icon),
		children: action.children ? action.children.map((child) => ({
			...child,
			icon: resolveIcon(child.icon)
		})) : void 0
	});
	updateAllStates();
}
function removeCustomCommand(actionId) {
	const commands = target.__VUE_DEVTOOLS_KIT_CUSTOM_COMMANDS__;
	const index = commands.findIndex((t) => t.id === actionId);
	if (index === -1) return;
	commands.splice(index, 1);
	updateAllStates();
}
function toggleClientConnected(state) {
	updateDevToolsState({ clientConnected: state });
}
//#endregion
//#region src/core/open-in-editor/index.ts
function setOpenInEditorBaseUrl(url) {
	target.__VUE_DEVTOOLS_OPEN_IN_EDITOR_BASE_URL__ = url;
}
function openInEditor(options = {}) {
	const { file, host, baseUrl = window.location.origin, line = 0, column = 0 } = options;
	if (file) {
		if (host === "chrome-extension") {
			const fileName = file.replace(/\\/g, "\\\\");
			const _baseUrl = window.VUE_DEVTOOLS_CONFIG?.openInEditorHost ?? "/";
			fetch(`${_baseUrl}__open-in-editor?file=${encodeURI(file)}`).then((response) => {
				if (!response.ok) {
					const msg = `Opening component ${fileName} failed`;
					console.log(`%c${msg}`, "color:red");
				}
			});
		} else if (devtoolsState.vitePluginDetected) {
			const _baseUrl = target.__VUE_DEVTOOLS_OPEN_IN_EDITOR_BASE_URL__ ?? baseUrl;
			target.__VUE_INSPECTOR__.openInEditor(_baseUrl, file, line, column);
		}
	}
}
//#endregion
//#region src/ctx/plugin.ts
target.__VUE_DEVTOOLS_KIT_PLUGIN_BUFFER__ ??= [];
const devtoolsPluginBuffer = new Proxy(target.__VUE_DEVTOOLS_KIT_PLUGIN_BUFFER__, { get(target, prop, receiver) {
	return Reflect.get(target, prop, receiver);
} });
function addDevToolsPluginToBuffer(pluginDescriptor, setupFn) {
	devtoolsPluginBuffer.push([pluginDescriptor, setupFn]);
}
//#endregion
//#region src/core/plugin/plugin-settings.ts
function _getSettings(settings) {
	const _settings = {};
	Object.keys(settings).forEach((key) => {
		_settings[key] = settings[key].defaultValue;
	});
	return _settings;
}
function getPluginLocalKey(pluginId) {
	return `__VUE_DEVTOOLS_NEXT_PLUGIN_SETTINGS__${pluginId}__`;
}
function getPluginSettingsOptions(pluginId) {
	return (devtoolsPluginBuffer.find((item) => item[0].id === pluginId && !!item[0]?.settings)?.[0] ?? null)?.settings ?? null;
}
function getPluginSettings(pluginId, fallbackValue) {
	const localKey = getPluginLocalKey(pluginId);
	if (localKey) {
		const localSettings = localStorage.getItem(localKey);
		if (localSettings) return JSON.parse(localSettings);
	}
	if (pluginId) return _getSettings((devtoolsPluginBuffer.find((item) => item[0].id === pluginId)?.[0] ?? null)?.settings ?? {});
	return _getSettings(fallbackValue);
}
function initPluginSettings(pluginId, settings) {
	const localKey = getPluginLocalKey(pluginId);
	if (!localStorage.getItem(localKey)) localStorage.setItem(localKey, JSON.stringify(_getSettings(settings)));
}
function setPluginSettings(pluginId, key, value) {
	const localKey = getPluginLocalKey(pluginId);
	const localSettings = localStorage.getItem(localKey);
	const parsedLocalSettings = JSON.parse(localSettings || "{}");
	const updated = {
		...parsedLocalSettings,
		[key]: value
	};
	localStorage.setItem(localKey, JSON.stringify(updated));
	devtoolsContext.hooks.callHookWith((callbacks) => {
		callbacks.forEach((cb) => cb({
			pluginId,
			key,
			oldValue: parsedLocalSettings[key],
			newValue: value,
			settings: updated
		}));
	}, DevToolsV6PluginAPIHookKeys.SET_PLUGIN_SETTINGS);
}
//#endregion
//#region src/types/hook.ts
let DevToolsHooks = /* @__PURE__ */ function(DevToolsHooks) {
	DevToolsHooks["APP_INIT"] = "app:init";
	DevToolsHooks["APP_UNMOUNT"] = "app:unmount";
	DevToolsHooks["COMPONENT_UPDATED"] = "component:updated";
	DevToolsHooks["COMPONENT_ADDED"] = "component:added";
	DevToolsHooks["COMPONENT_REMOVED"] = "component:removed";
	DevToolsHooks["COMPONENT_EMIT"] = "component:emit";
	DevToolsHooks["PERFORMANCE_START"] = "perf:start";
	DevToolsHooks["PERFORMANCE_END"] = "perf:end";
	DevToolsHooks["ADD_ROUTE"] = "router:add-route";
	DevToolsHooks["REMOVE_ROUTE"] = "router:remove-route";
	DevToolsHooks["RENDER_TRACKED"] = "render:tracked";
	DevToolsHooks["RENDER_TRIGGERED"] = "render:triggered";
	DevToolsHooks["APP_CONNECTED"] = "app:connected";
	DevToolsHooks["SETUP_DEVTOOLS_PLUGIN"] = "devtools-plugin:setup";
	return DevToolsHooks;
}({});
//#endregion
//#region src/hook/index.ts
const devtoolsHooks = target.__VUE_DEVTOOLS_HOOK ??= createHooks();
const on = {
	vueAppInit(fn) {
		devtoolsHooks.hook(DevToolsHooks.APP_INIT, fn);
	},
	vueAppUnmount(fn) {
		devtoolsHooks.hook(DevToolsHooks.APP_UNMOUNT, fn);
	},
	vueAppConnected(fn) {
		devtoolsHooks.hook(DevToolsHooks.APP_CONNECTED, fn);
	},
	componentAdded(fn) {
		return devtoolsHooks.hook(DevToolsHooks.COMPONENT_ADDED, fn);
	},
	componentEmit(fn) {
		return devtoolsHooks.hook(DevToolsHooks.COMPONENT_EMIT, fn);
	},
	componentUpdated(fn) {
		return devtoolsHooks.hook(DevToolsHooks.COMPONENT_UPDATED, fn);
	},
	componentRemoved(fn) {
		return devtoolsHooks.hook(DevToolsHooks.COMPONENT_REMOVED, fn);
	},
	setupDevtoolsPlugin(fn) {
		devtoolsHooks.hook(DevToolsHooks.SETUP_DEVTOOLS_PLUGIN, fn);
	},
	perfStart(fn) {
		return devtoolsHooks.hook(DevToolsHooks.PERFORMANCE_START, fn);
	},
	perfEnd(fn) {
		return devtoolsHooks.hook(DevToolsHooks.PERFORMANCE_END, fn);
	}
};
function createDevToolsHook() {
	return {
		id: "vue-devtools-next",
		devtoolsVersion: "7.0",
		enabled: false,
		appRecords: [],
		apps: [],
		events: /* @__PURE__ */ new Map(),
		on(event, fn) {
			if (!this.events.has(event)) this.events.set(event, []);
			this.events.get(event)?.push(fn);
			return () => this.off(event, fn);
		},
		once(event, fn) {
			const onceFn = (...args) => {
				this.off(event, onceFn);
				fn(...args);
			};
			this.on(event, onceFn);
			return [event, onceFn];
		},
		off(event, fn) {
			if (this.events.has(event)) {
				const eventCallbacks = this.events.get(event);
				const index = eventCallbacks.indexOf(fn);
				if (index !== -1) eventCallbacks.splice(index, 1);
			}
		},
		emit(event, ...payload) {
			if (this.events.has(event)) this.events.get(event).forEach((fn) => fn(...payload));
		}
	};
}
function subscribeDevToolsHook(hook) {
	hook.on(DevToolsHooks.APP_INIT, (app, version, types) => {
		if (app?._instance?.type?.devtools?.hide) return;
		devtoolsHooks.callHook(DevToolsHooks.APP_INIT, app, version, types);
	});
	hook.on(DevToolsHooks.APP_UNMOUNT, (app) => {
		devtoolsHooks.callHook(DevToolsHooks.APP_UNMOUNT, app);
	});
	hook.on(DevToolsHooks.COMPONENT_ADDED, async (app, uid, parentUid, component) => {
		if (app?._instance?.type?.devtools?.hide || devtoolsState.highPerfModeEnabled) return;
		if (!app || typeof uid !== "number" && !uid || !component) return;
		devtoolsHooks.callHook(DevToolsHooks.COMPONENT_ADDED, app, uid, parentUid, component);
	});
	hook.on(DevToolsHooks.COMPONENT_UPDATED, (app, uid, parentUid, component) => {
		if (!app || typeof uid !== "number" && !uid || !component || devtoolsState.highPerfModeEnabled) return;
		devtoolsHooks.callHook(DevToolsHooks.COMPONENT_UPDATED, app, uid, parentUid, component);
	});
	hook.on(DevToolsHooks.COMPONENT_REMOVED, async (app, uid, parentUid, component) => {
		if (!app || typeof uid !== "number" && !uid || !component || devtoolsState.highPerfModeEnabled) return;
		devtoolsHooks.callHook(DevToolsHooks.COMPONENT_REMOVED, app, uid, parentUid, component);
	});
	hook.on(DevToolsHooks.COMPONENT_EMIT, async (app, instance, event, params) => {
		if (!app || !instance || devtoolsState.highPerfModeEnabled) return;
		devtoolsHooks.callHook(DevToolsHooks.COMPONENT_EMIT, app, instance, event, params);
	});
	hook.on(DevToolsHooks.PERFORMANCE_START, (app, uid, vm, type, time) => {
		if (!app || devtoolsState.highPerfModeEnabled) return;
		devtoolsHooks.callHook(DevToolsHooks.PERFORMANCE_START, app, uid, vm, type, time);
	});
	hook.on(DevToolsHooks.PERFORMANCE_END, (app, uid, vm, type, time) => {
		if (!app || devtoolsState.highPerfModeEnabled) return;
		devtoolsHooks.callHook(DevToolsHooks.PERFORMANCE_END, app, uid, vm, type, time);
	});
	hook.on(DevToolsHooks.SETUP_DEVTOOLS_PLUGIN, (pluginDescriptor, setupFn, options) => {
		if (options?.target === "legacy") return;
		devtoolsHooks.callHook(DevToolsHooks.SETUP_DEVTOOLS_PLUGIN, pluginDescriptor, setupFn);
	});
}
const hook = {
	on,
	setupDevToolsPlugin(pluginDescriptor, setupFn) {
		return devtoolsHooks.callHook(DevToolsHooks.SETUP_DEVTOOLS_PLUGIN, pluginDescriptor, setupFn);
	}
};
//#endregion
//#region src/api/v6/index.ts
var DevToolsV6PluginAPI = class {
	constructor({ plugin, ctx }) {
		this.hooks = ctx.hooks;
		this.plugin = plugin;
	}
	get on() {
		return {
			visitComponentTree: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.VISIT_COMPONENT_TREE, handler);
			},
			inspectComponent: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.INSPECT_COMPONENT, handler);
			},
			editComponentState: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.EDIT_COMPONENT_STATE, handler);
			},
			getInspectorTree: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_TREE, handler);
			},
			getInspectorState: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_STATE, handler);
			},
			editInspectorState: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.EDIT_INSPECTOR_STATE, handler);
			},
			inspectTimelineEvent: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.INSPECT_TIMELINE_EVENT, handler);
			},
			timelineCleared: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.TIMELINE_CLEARED, handler);
			},
			setPluginSettings: (handler) => {
				this.hooks.hook(DevToolsV6PluginAPIHookKeys.SET_PLUGIN_SETTINGS, handler);
			}
		};
	}
	notifyComponentUpdate(instance) {
		if (devtoolsState.highPerfModeEnabled) return;
		const inspector = getActiveInspectors().find((i) => i.packageName === this.plugin.descriptor.packageName);
		if (inspector?.id) {
			if (instance) {
				const args = [
					instance.appContext.app,
					instance.uid,
					instance.parent?.uid,
					instance
				];
				devtoolsHooks.callHook(DevToolsHooks.COMPONENT_UPDATED, ...args);
			} else devtoolsHooks.callHook(DevToolsHooks.COMPONENT_UPDATED);
			this.hooks.callHook(DevToolsContextHookKeys.SEND_INSPECTOR_STATE, {
				inspectorId: inspector.id,
				plugin: this.plugin
			});
		}
	}
	addInspector(options) {
		this.hooks.callHook(DevToolsContextHookKeys.ADD_INSPECTOR, {
			inspector: options,
			plugin: this.plugin
		});
		if (this.plugin.descriptor.settings) initPluginSettings(options.id, this.plugin.descriptor.settings);
	}
	sendInspectorTree(inspectorId) {
		if (devtoolsState.highPerfModeEnabled) return;
		this.hooks.callHook(DevToolsContextHookKeys.SEND_INSPECTOR_TREE, {
			inspectorId,
			plugin: this.plugin
		});
	}
	sendInspectorState(inspectorId) {
		if (devtoolsState.highPerfModeEnabled) return;
		this.hooks.callHook(DevToolsContextHookKeys.SEND_INSPECTOR_STATE, {
			inspectorId,
			plugin: this.plugin
		});
	}
	selectInspectorNode(inspectorId, nodeId) {
		this.hooks.callHook(DevToolsContextHookKeys.CUSTOM_INSPECTOR_SELECT_NODE, {
			inspectorId,
			nodeId,
			plugin: this.plugin
		});
	}
	visitComponentTree(payload) {
		return this.hooks.callHook(DevToolsV6PluginAPIHookKeys.VISIT_COMPONENT_TREE, payload);
	}
	now() {
		if (devtoolsState.highPerfModeEnabled) return 0;
		return Date.now();
	}
	addTimelineLayer(options) {
		this.hooks.callHook(DevToolsContextHookKeys.TIMELINE_LAYER_ADDED, {
			options,
			plugin: this.plugin
		});
	}
	addTimelineEvent(options) {
		if (devtoolsState.highPerfModeEnabled) return;
		this.hooks.callHook(DevToolsContextHookKeys.TIMELINE_EVENT_ADDED, {
			options,
			plugin: this.plugin
		});
	}
	getSettings(pluginId) {
		return getPluginSettings(pluginId ?? this.plugin.descriptor.id, this.plugin.descriptor.settings);
	}
	getComponentInstances(app) {
		return this.hooks.callHook(DevToolsContextHookKeys.GET_COMPONENT_INSTANCES, { app });
	}
	getComponentBounds(instance) {
		return this.hooks.callHook(DevToolsContextHookKeys.GET_COMPONENT_BOUNDS, { instance });
	}
	getComponentName(instance) {
		return this.hooks.callHook(DevToolsContextHookKeys.GET_COMPONENT_NAME, { instance });
	}
	highlightElement(instance) {
		const uid = instance.__VUE_DEVTOOLS_NEXT_UID__;
		return this.hooks.callHook(DevToolsContextHookKeys.COMPONENT_HIGHLIGHT, { uid });
	}
	unhighlightElement() {
		return this.hooks.callHook(DevToolsContextHookKeys.COMPONENT_UNHIGHLIGHT);
	}
};
//#endregion
//#region src/api/index.ts
const DevToolsPluginAPI = DevToolsV6PluginAPI;
//#endregion
//#region src/core/component/state/constants.ts
const vueBuiltins = new Set([
	"nextTick",
	"defineComponent",
	"defineAsyncComponent",
	"defineCustomElement",
	"ref",
	"computed",
	"reactive",
	"readonly",
	"watchEffect",
	"watchPostEffect",
	"watchSyncEffect",
	"watch",
	"isRef",
	"unref",
	"toRef",
	"toRefs",
	"isProxy",
	"isReactive",
	"isReadonly",
	"shallowRef",
	"triggerRef",
	"customRef",
	"shallowReactive",
	"shallowReadonly",
	"toRaw",
	"markRaw",
	"effectScope",
	"getCurrentScope",
	"onScopeDispose",
	"onMounted",
	"onUpdated",
	"onUnmounted",
	"onBeforeMount",
	"onBeforeUpdate",
	"onBeforeUnmount",
	"onErrorCaptured",
	"onRenderTracked",
	"onRenderTriggered",
	"onActivated",
	"onDeactivated",
	"onServerPrefetch",
	"provide",
	"inject",
	"h",
	"mergeProps",
	"cloneVNode",
	"isVNode",
	"resolveComponent",
	"resolveDirective",
	"withDirectives",
	"withModifiers"
]);
const symbolRE = /^\[native Symbol Symbol\((.*)\)\]$/;
const rawTypeRE = /^\[object (\w+)\]$/;
const specialTypeRE = /^\[native (\w+) (.*?)(<>(([\s\S])*))?\]$/;
const fnTypeRE = /^(?:function|class) (\w+)/;
const MAX_STRING_SIZE = 1e4;
const MAX_ARRAY_SIZE = 5e3;
const UNDEFINED = "__vue_devtool_undefined__";
const INFINITY = "__vue_devtool_infinity__";
const NEGATIVE_INFINITY = "__vue_devtool_negative_infinity__";
const NAN = "__vue_devtool_nan__";
const ESC = {
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"&": "&amp;"
};
//#endregion
//#region src/core/component/state/is.ts
function isVueInstance(value) {
	if (!ensurePropertyExists(value, "_")) return false;
	if (!isPlainObject(value._)) return false;
	return Object.keys(value._).includes("vnode");
}
function isPlainObject(obj) {
	return Object.prototype.toString.call(obj) === "[object Object]";
}
function isPrimitive$1(data) {
	if (data == null) return true;
	const type = typeof data;
	return type === "string" || type === "number" || type === "boolean";
}
function isRef(raw) {
	return !!raw.__v_isRef;
}
function isComputed(raw) {
	return isRef(raw) && !!raw.effect;
}
function isReactive(raw) {
	return !!raw.__v_isReactive;
}
function isReadOnly(raw) {
	return !!raw.__v_isReadonly;
}
//#endregion
//#region src/core/component/state/util.ts
const tokenMap = {
	[UNDEFINED]: "undefined",
	[NAN]: "NaN",
	[INFINITY]: "Infinity",
	[NEGATIVE_INFINITY]: "-Infinity"
};
const reversedTokenMap = Object.entries(tokenMap).reduce((acc, [key, value]) => {
	acc[value] = key;
	return acc;
}, {});
function internalStateTokenToString(value) {
	if (value === null) return "null";
	return typeof value === "string" && tokenMap[value] || false;
}
function replaceTokenToString(value) {
	const replaceRegex = new RegExp(`"(${Object.keys(tokenMap).join("|")})"`, "g");
	return value.replace(replaceRegex, (_, g1) => tokenMap[g1]);
}
function replaceStringToToken(value) {
	const literalValue = reversedTokenMap[value.trim()];
	if (literalValue) return `"${literalValue}"`;
	const replaceRegex = new RegExp(`:\\s*(${Object.keys(reversedTokenMap).join("|")})`, "g");
	return value.replace(replaceRegex, (_, g1) => `:"${reversedTokenMap[g1]}"`);
}
/**
* Convert prop type constructor to string.
*/
function getPropType(type) {
	if (Array.isArray(type)) return type.map((t) => getPropType(t)).join(" or ");
	if (type == null) return "null";
	const match = type.toString().match(fnTypeRE);
	return typeof type === "function" ? match && match[1] || "any" : "any";
}
/**
* Sanitize data to be posted to the other side.
* Since the message posted is sent with structured clone,
* we need to filter out any types that might cause an error.
*/
function sanitize(data) {
	if (!isPrimitive$1(data) && !Array.isArray(data) && !isPlainObject(data)) return Object.prototype.toString.call(data);
	else return data;
}
function getSetupStateType(raw) {
	try {
		return {
			ref: isRef(raw),
			computed: isComputed(raw),
			reactive: isReactive(raw),
			readonly: isReadOnly(raw)
		};
	} catch {
		return {
			ref: false,
			computed: false,
			reactive: false,
			readonly: false
		};
	}
}
function toRaw(value) {
	if (value?.__v_raw) return value.__v_raw;
	return value;
}
function escape(s) {
	return s.replace(/[<>"&]/g, (s) => {
		return ESC[s] || s;
	});
}
//#endregion
//#region src/core/component/state/process.ts
function mergeOptions(to, from, instance) {
	if (typeof from === "function") from = from.options;
	if (!from) return to;
	const { mixins, extends: extendsOptions } = from;
	extendsOptions && mergeOptions(to, extendsOptions, instance);
	mixins && mixins.forEach((m) => mergeOptions(to, m, instance));
	for (const key of ["computed", "inject"]) if (Object.prototype.hasOwnProperty.call(from, key)) {
		to[key] ??= {};
		Object.assign(to[key], from[key]);
	}
	return to;
}
function resolveMergedOptions(instance) {
	const raw = instance?.type;
	if (!raw) return {};
	const { mixins, extends: extendsOptions } = raw;
	const globalMixins = instance.appContext.mixins;
	if (!globalMixins.length && !mixins && !extendsOptions) return raw;
	const options = {};
	globalMixins.forEach((m) => mergeOptions(options, m, instance));
	mergeOptions(options, raw, instance);
	return options;
}
/**
* Process the props of an instance.
* Make sure return a plain object because window.postMessage()
* will throw an Error if the passed object contains Functions.
*
*/
function processProps(instance) {
	const props = [];
	const propDefinitions = instance?.type?.props;
	for (const key in instance?.props) {
		const propDefinition = propDefinitions ? propDefinitions[key] : null;
		const camelizeKey = camelize(key);
		props.push({
			type: "props",
			key: camelizeKey,
			value: returnError(() => instance.props[key]),
			editable: true,
			meta: propDefinition ? {
				type: propDefinition.type ? getPropType(propDefinition.type) : "any",
				required: !!propDefinition.required,
				...propDefinition.default ? { default: propDefinition.default.toString() } : {}
			} : { type: "invalid" }
		});
	}
	return props;
}
/**
* Process state, filtering out props and "clean" the result
* with a JSON dance. This removes functions which can cause
* errors during structured clone used by window.postMessage.
*
*/
function processState(instance) {
	const type = instance.type;
	const props = type?.props;
	const getters = type.vuex && type.vuex.getters;
	const computedDefs = type.computed;
	const data = {
		...instance.data,
		...instance.renderContext
	};
	return Object.keys(data).filter((key) => !(props && key in props) && !(getters && key in getters) && !(computedDefs && key in computedDefs)).map((key) => ({
		key,
		type: "data",
		value: returnError(() => data[key]),
		editable: true
	}));
}
function getStateTypeAndName(info) {
	const stateType = info.computed ? "computed" : info.ref ? "ref" : info.reactive ? "reactive" : null;
	return {
		stateType,
		stateTypeName: stateType ? `${stateType.charAt(0).toUpperCase()}${stateType.slice(1)}` : null
	};
}
function processSetupState(instance) {
	const raw = instance.devtoolsRawSetupState || {};
	return Object.keys(instance.setupState).filter((key) => !vueBuiltins.has(key) && key.split(/(?=[A-Z])/)[0] !== "use").map((key) => {
		const value = returnError(() => toRaw(instance.setupState[key]));
		const accessError = value instanceof Error;
		const rawData = raw[key];
		let result;
		let isOtherType = accessError || typeof value === "function" || ensurePropertyExists(value, "render") && typeof value.render === "function" || ensurePropertyExists(value, "__asyncLoader") && typeof value.__asyncLoader === "function" || typeof value === "object" && value && ("setup" in value || "props" in value) || /^v[A-Z]/.test(key);
		if (rawData && !accessError) {
			const info = getSetupStateType(rawData);
			const { stateType, stateTypeName } = getStateTypeAndName(info);
			const isState = info.ref || info.computed || info.reactive;
			const raw = ensurePropertyExists(rawData, "effect") ? rawData.effect?.raw?.toString() || rawData.effect?.fn?.toString() : null;
			if (stateType) isOtherType = false;
			result = {
				...stateType ? {
					stateType,
					stateTypeName
				} : {},
				...raw ? { raw } : {},
				editable: isState && !info.readonly
			};
		}
		return {
			key,
			value,
			type: isOtherType ? "setup (other)" : "setup",
			...result
		};
	});
}
/**
* Process the computed properties of an instance.
*/
function processComputed(instance, mergedType) {
	const type = mergedType;
	const computed = [];
	const defs = type.computed || {};
	for (const key in defs) {
		const def = defs[key];
		const type = typeof def === "function" && def.vuex ? "vuex bindings" : "computed";
		computed.push({
			type,
			key,
			value: returnError(() => instance?.proxy?.[key]),
			editable: typeof def.set === "function"
		});
	}
	return computed;
}
function processAttrs(instance) {
	return Object.keys(instance.attrs).map((key) => ({
		type: "attrs",
		key,
		value: returnError(() => instance.attrs[key])
	}));
}
function processProvide(instance) {
	return Reflect.ownKeys(instance.provides).map((key) => ({
		type: "provided",
		key: key.toString(),
		value: returnError(() => instance.provides[key])
	}));
}
const hasOwnProperty = Object.prototype.hasOwnProperty;
const hasOwn = (val, key) => hasOwnProperty.call(val, key);
function processInject(instance, mergedType) {
	if (!mergedType?.inject) return [];
	let keys;
	if (Array.isArray(mergedType.inject)) keys = mergedType.inject.map((key) => ({
		key,
		originalKey: key
	}));
	else keys = Reflect.ownKeys(mergedType.inject).map((key) => {
		const value = mergedType.inject[key];
		let originalKey;
		if (typeof value === "string" || typeof value === "symbol") originalKey = value;
		else originalKey = value.from ?? key;
		return {
			key,
			originalKey
		};
	});
	return keys.map(({ key, originalKey }) => ({
		type: "injected",
		key: key !== originalKey ? `${String(originalKey)} ➞ ${String(key)}` : String(key),
		value: returnError(() => hasOwn(instance.ctx, key) ? instance.ctx[key] : void 0)
	}));
}
function processRefs(instance) {
	return Object.keys(instance.refs).map((key) => ({
		type: "template refs",
		key,
		value: returnError(() => instance.refs[key])
	}));
}
const vnodeEvents = new Set([
	"vnode-before-mount",
	"vnode-mounted",
	"vnode-before-update",
	"vnode-updated",
	"vnode-before-unmount",
	"vnode-unmounted"
]);
function processEventListeners(instance) {
	const emitsDefinition = instance.type.emits;
	const declaredEmits = Array.isArray(emitsDefinition) ? emitsDefinition : Object.keys(emitsDefinition ?? {});
	const keys = Object.keys(instance?.vnode?.props ?? {});
	const result = [];
	for (const key of keys) {
		const [prefix, ...eventNameParts] = key.split(/(?=[A-Z])/);
		if (prefix === "on") {
			const eventName = eventNameParts.join("-").toLowerCase();
			const isBuiltIn = vnodeEvents.has(eventName);
			const isDeclared = declaredEmits.includes(eventName) || declaredEmits.includes(camelize(eventName));
			const text = isBuiltIn ? "✅ Built-in" : isDeclared ? "✅ Declared" : "⚠️ Not declared";
			result.push({
				type: "event listeners",
				key: eventName,
				value: { _custom: {
					displayText: text,
					key: text,
					value: text,
					tooltipText: isBuiltIn ? `The event <code>${escape(eventName)}</code> is part of Vue and doesn't need to be declared by the component` : !isDeclared ? `The event <code>${escape(eventName)}</code> is not declared in the <code>emits</code> option. It will leak into the component's attributes (<code>$attrs</code>).` : null
				} }
			});
		}
	}
	return result;
}
function processInstanceState(instance) {
	const mergedType = resolveMergedOptions(instance);
	return processProps(instance).concat(processState(instance), processSetupState(instance), processComputed(instance, mergedType), processAttrs(instance), processProvide(instance), processInject(instance, mergedType), processRefs(instance), processEventListeners(instance));
}
//#endregion
//#region src/core/component/state/index.ts
function getInstanceState(params) {
	const instance = getComponentInstance(activeAppRecord.value, params.instanceId);
	return {
		id: getUniqueComponentId(instance),
		name: getInstanceName(instance),
		file: instance?.type?.__file,
		state: processInstanceState(instance),
		instance
	};
}
//#endregion
//#region src/core/component/tree/filter.ts
var ComponentFilter = class {
	constructor(filter) {
		this.filter = filter || "";
	}
	/**
	* Check if an instance is qualified.
	*
	* @param {Vue|Vnode} instance
	* @return {boolean}
	*/
	isQualified(instance) {
		const name = getInstanceName(instance);
		return classify(name).toLowerCase().includes(this.filter) || kebabize(name).toLowerCase().includes(this.filter);
	}
};
function createComponentFilter(filterText) {
	return new ComponentFilter(filterText);
}
//#endregion
//#region src/core/component/tree/walker.ts
var ComponentWalker = class {
	constructor(options) {
		this.captureIds = /* @__PURE__ */ new Map();
		const { filterText = "", maxDepth, recursively, api } = options;
		this.componentFilter = createComponentFilter(filterText);
		this.maxDepth = maxDepth;
		this.recursively = recursively;
		this.api = api;
	}
	getComponentTree(instance) {
		this.captureIds = /* @__PURE__ */ new Map();
		return this.findQualifiedChildren(instance, 0);
	}
	getComponentParents(instance) {
		this.captureIds = /* @__PURE__ */ new Map();
		const parents = [];
		this.captureId(instance);
		let parent = instance;
		while (parent = parent.parent) {
			this.captureId(parent);
			parents.push(parent);
		}
		return parents;
	}
	captureId(instance) {
		if (!instance) return null;
		const id = instance.__VUE_DEVTOOLS_NEXT_UID__ != null ? instance.__VUE_DEVTOOLS_NEXT_UID__ : getUniqueComponentId(instance);
		instance.__VUE_DEVTOOLS_NEXT_UID__ = id;
		if (this.captureIds.has(id)) return null;
		else this.captureIds.set(id, void 0);
		this.mark(instance);
		return id;
	}
	/**
	* Capture the meta information of an instance. (recursive)
	*
	* @param {Vue} instance
	* @return {object}
	*/
	async capture(instance, depth) {
		if (!instance) return null;
		const id = this.captureId(instance);
		const name = getInstanceName(instance);
		const children = this.getInternalInstanceChildren(instance.subTree).filter((child) => !isBeingDestroyed(child));
		const parents = this.getComponentParents(instance) || [];
		const inactive = !!instance.isDeactivated || parents.some((parent) => parent.isDeactivated);
		const treeNode = {
			uid: instance.uid,
			id,
			name,
			renderKey: getRenderKey(instance.vnode ? instance.vnode.key : null),
			inactive,
			children: [],
			hasChildren: !!children.length,
			isFragment: isFragment(instance),
			tags: typeof instance.type !== "function" ? [] : [{
				label: "functional",
				textColor: 5592405,
				backgroundColor: 15658734
			}],
			autoOpen: this.recursively,
			file: instance.type.__file || ""
		};
		if (depth < this.maxDepth || instance.type.__isKeepAlive || parents.some((parent) => parent.type.__isKeepAlive)) treeNode.children = await Promise.all(children.map((child) => this.capture(child, depth + 1)).filter(Boolean));
		if (this.isKeepAlive(instance)) {
			const cachedComponents = this.getKeepAliveCachedInstances(instance);
			const childrenIds = children.map((child) => child.__VUE_DEVTOOLS_NEXT_UID__);
			for (const cachedChild of cachedComponents) if (!childrenIds.includes(cachedChild.__VUE_DEVTOOLS_NEXT_UID__)) {
				const node = await this.capture({
					...cachedChild,
					isDeactivated: true
				}, depth + 1);
				if (node) treeNode.children.push(node);
			}
		}
		const firstElement = getRootElementsFromComponentInstance(instance)[0];
		if (firstElement?.parentElement) {
			const parentInstance = instance.parent;
			const parentRootElements = parentInstance ? getRootElementsFromComponentInstance(parentInstance) : [];
			let el = firstElement;
			const indexList = [];
			do {
				indexList.push(Array.from(el.parentElement.childNodes).indexOf(el));
				el = el.parentElement;
			} while (el.parentElement && parentRootElements.length && !parentRootElements.includes(el));
			treeNode.domOrder = indexList.reverse();
		} else treeNode.domOrder = [-1];
		if (instance.suspense?.suspenseKey) {
			treeNode.tags.push({
				label: instance.suspense.suspenseKey,
				backgroundColor: 14979812,
				textColor: 16777215
			});
			this.mark(instance, true);
		}
		this.api.visitComponentTree({
			treeNode,
			componentInstance: instance,
			app: instance.appContext.app,
			filter: this.componentFilter.filter
		});
		return treeNode;
	}
	/**
	* Find qualified children from a single instance.
	* If the instance itself is qualified, just return itself.
	* This is ok because [].concat works in both cases.
	*
	* @param {Vue|Vnode} instance
	* @return {Vue|Array}
	*/
	async findQualifiedChildren(instance, depth) {
		if (this.componentFilter.isQualified(instance) && !instance.type.devtools?.hide) return [await this.capture(instance, depth)];
		else if (instance.subTree) {
			const list = this.isKeepAlive(instance) ? this.getKeepAliveCachedInstances(instance) : this.getInternalInstanceChildren(instance.subTree);
			return this.findQualifiedChildrenFromList(list, depth);
		} else return [];
	}
	/**
	* Iterate through an array of instances and flatten it into
	* an array of qualified instances. This is a depth-first
	* traversal - e.g. if an instance is not matched, we will
	* recursively go deeper until a qualified child is found.
	*
	* @param {Array} instances
	* @return {Array}
	*/
	async findQualifiedChildrenFromList(instances, depth) {
		instances = instances.filter((child) => !isBeingDestroyed(child) && !child.type.devtools?.hide);
		if (!this.componentFilter.filter) return Promise.all(instances.map((child) => this.capture(child, depth)));
		else return Array.prototype.concat.apply([], await Promise.all(instances.map((i) => this.findQualifiedChildren(i, depth))));
	}
	/**
	* Get children from a component instance.
	*/
	getInternalInstanceChildren(subTree, suspense = null) {
		const list = [];
		if (subTree) {
			if (subTree.component) !suspense ? list.push(subTree.component) : list.push({
				...subTree.component,
				suspense
			});
			else if (subTree.suspense) {
				const suspenseKey = !subTree.suspense.isInFallback ? "suspense default" : "suspense fallback";
				list.push(...this.getInternalInstanceChildren(subTree.suspense.activeBranch, {
					...subTree.suspense,
					suspenseKey
				}));
			} else if (Array.isArray(subTree.children)) subTree.children.forEach((childSubTree) => {
				if (childSubTree.component) !suspense ? list.push(childSubTree.component) : list.push({
					...childSubTree.component,
					suspense
				});
				else list.push(...this.getInternalInstanceChildren(childSubTree, suspense));
			});
		}
		return list.filter((child) => !isBeingDestroyed(child) && !child.type.devtools?.hide);
	}
	/**
	* Mark an instance as captured and store it in the instance map.
	*
	* @param {Vue} instance
	*/
	mark(instance, force = false) {
		const instanceMap = getAppRecord(instance).instanceMap;
		if (force || !instanceMap.has(instance.__VUE_DEVTOOLS_NEXT_UID__)) {
			instanceMap.set(instance.__VUE_DEVTOOLS_NEXT_UID__, instance);
			activeAppRecord.value.instanceMap = instanceMap;
		}
	}
	isKeepAlive(instance) {
		return instance.type.__isKeepAlive && instance.__v_cache;
	}
	getKeepAliveCachedInstances(instance) {
		return Array.from(instance.__v_cache.values()).map((vnode) => vnode.component).filter(Boolean);
	}
};
//#endregion
//#region src/core/timeline/perf.ts
const markEndQueue = /* @__PURE__ */ new Map();
const PERFORMANCE_EVENT_LAYER_ID = "performance";
async function performanceMarkStart(api, app, uid, vm, type, time) {
	const appRecord = await getAppRecord(app);
	if (!appRecord) return;
	const componentName = getInstanceName(vm) || "Unknown Component";
	const groupId = devtoolsState.perfUniqueGroupId++;
	const groupKey = `${uid}-${type}`;
	appRecord.perfGroupIds.set(groupKey, {
		groupId,
		time
	});
	await api.addTimelineEvent({
		layerId: PERFORMANCE_EVENT_LAYER_ID,
		event: {
			time: Date.now(),
			data: {
				component: componentName,
				type,
				measure: "start"
			},
			title: componentName,
			subtitle: type,
			groupId
		}
	});
	if (markEndQueue.has(groupKey)) {
		const { app, uid, instance, type, time } = markEndQueue.get(groupKey);
		markEndQueue.delete(groupKey);
		await performanceMarkEnd(api, app, uid, instance, type, time);
	}
}
function performanceMarkEnd(api, app, uid, vm, type, time) {
	const appRecord = getAppRecord(app);
	if (!appRecord) return;
	const componentName = getInstanceName(vm) || "Unknown Component";
	const groupKey = `${uid}-${type}`;
	const groupInfo = appRecord.perfGroupIds.get(groupKey);
	if (groupInfo) {
		const groupId = groupInfo.groupId;
		const duration = time - groupInfo.time;
		api.addTimelineEvent({
			layerId: PERFORMANCE_EVENT_LAYER_ID,
			event: {
				time: Date.now(),
				data: {
					component: componentName,
					type,
					measure: "end",
					duration: { _custom: {
						type: "Duration",
						value: duration,
						display: `${duration} ms`
					} }
				},
				title: componentName,
				subtitle: type,
				groupId
			}
		});
	} else markEndQueue.set(groupKey, {
		app,
		uid,
		instance: vm,
		type,
		time
	});
}
//#endregion
//#region src/core/timeline/index.ts
const COMPONENT_EVENT_LAYER_ID = "component-event";
function setupBuiltinTimelineLayers(api) {
	if (!isBrowser) return;
	api.addTimelineLayer({
		id: "mouse",
		label: "Mouse",
		color: 10768815
	});
	[
		"mousedown",
		"mouseup",
		"click",
		"dblclick"
	].forEach((eventType) => {
		if (!devtoolsState.timelineLayersState.recordingState || !devtoolsState.timelineLayersState.mouseEventEnabled) return;
		window.addEventListener(eventType, async (event) => {
			await api.addTimelineEvent({
				layerId: "mouse",
				event: {
					time: Date.now(),
					data: {
						type: eventType,
						x: event.clientX,
						y: event.clientY
					},
					title: eventType
				}
			});
		}, {
			capture: true,
			passive: true
		});
	});
	api.addTimelineLayer({
		id: "keyboard",
		label: "Keyboard",
		color: 8475055
	});
	[
		"keyup",
		"keydown",
		"keypress"
	].forEach((eventType) => {
		window.addEventListener(eventType, async (event) => {
			if (!devtoolsState.timelineLayersState.recordingState || !devtoolsState.timelineLayersState.keyboardEventEnabled) return;
			await api.addTimelineEvent({
				layerId: "keyboard",
				event: {
					time: Date.now(),
					data: {
						type: eventType,
						key: event.key,
						ctrlKey: event.ctrlKey,
						shiftKey: event.shiftKey,
						altKey: event.altKey,
						metaKey: event.metaKey
					},
					title: event.key
				}
			});
		}, {
			capture: true,
			passive: true
		});
	});
	api.addTimelineLayer({
		id: COMPONENT_EVENT_LAYER_ID,
		label: "Component events",
		color: 5226637
	});
	hook.on.componentEmit(async (app, instance, event, params) => {
		if (!devtoolsState.timelineLayersState.recordingState || !devtoolsState.timelineLayersState.componentEventEnabled) return;
		const appRecord = await getAppRecord(app);
		if (!appRecord) return;
		const componentId = `${appRecord.id}:${instance.uid}`;
		const componentName = getInstanceName(instance) || "Unknown Component";
		api.addTimelineEvent({
			layerId: COMPONENT_EVENT_LAYER_ID,
			event: {
				time: Date.now(),
				data: {
					component: { _custom: {
						type: "component-definition",
						display: componentName
					} },
					event,
					params
				},
				title: event,
				subtitle: `by ${componentName}`,
				meta: { componentId }
			}
		});
	});
	api.addTimelineLayer({
		id: "performance",
		label: PERFORMANCE_EVENT_LAYER_ID,
		color: 4307050
	});
	hook.on.perfStart((app, uid, vm, type, time) => {
		if (!devtoolsState.timelineLayersState.recordingState || !devtoolsState.timelineLayersState.performanceEventEnabled) return;
		performanceMarkStart(api, app, uid, vm, type, time);
	});
	hook.on.perfEnd((app, uid, vm, type, time) => {
		if (!devtoolsState.timelineLayersState.recordingState || !devtoolsState.timelineLayersState.performanceEventEnabled) return;
		performanceMarkEnd(api, app, uid, vm, type, time);
	});
}
//#endregion
//#region src/core/vm/index.ts
const MAX_$VM = 10;
const $vmQueue = [];
function exposeInstanceToWindow(componentInstance) {
	if (typeof window === "undefined") return;
	const win = window;
	if (!componentInstance) return;
	win.$vm = componentInstance;
	if ($vmQueue[0] !== componentInstance) {
		if ($vmQueue.length >= MAX_$VM) $vmQueue.pop();
		for (let i = $vmQueue.length; i > 0; i--) win[`$vm${i}`] = $vmQueue[i] = $vmQueue[i - 1];
		win.$vm0 = $vmQueue[0] = componentInstance;
	}
}
//#endregion
//#region src/core/plugin/components.ts
const INSPECTOR_ID = "components";
function createComponentsDevToolsPlugin(app) {
	const descriptor = {
		id: INSPECTOR_ID,
		label: "Components",
		app
	};
	const setupFn = (api) => {
		api.addInspector({
			id: INSPECTOR_ID,
			label: "Components",
			treeFilterPlaceholder: "Search components"
		});
		setupBuiltinTimelineLayers(api);
		api.on.getInspectorTree(async (payload) => {
			if (payload.app === app && payload.inspectorId === INSPECTOR_ID) {
				const instance = getComponentInstance(activeAppRecord.value, payload.instanceId);
				if (instance) payload.rootNodes = await new ComponentWalker({
					filterText: payload.filter,
					maxDepth: 100,
					recursively: false,
					api
				}).getComponentTree(instance);
			}
		});
		api.on.getInspectorState(async (payload) => {
			if (payload.app === app && payload.inspectorId === INSPECTOR_ID) {
				const result = getInstanceState({ instanceId: payload.nodeId });
				const componentInstance = result.instance;
				const _payload = {
					componentInstance,
					app: result.instance?.appContext.app,
					instanceData: result
				};
				devtoolsContext.hooks.callHookWith((callbacks) => {
					callbacks.forEach((cb) => cb(_payload));
				}, DevToolsV6PluginAPIHookKeys.INSPECT_COMPONENT);
				payload.state = result;
				exposeInstanceToWindow(componentInstance);
			}
		});
		api.on.editInspectorState(async (payload) => {
			if (payload.app === app && payload.inspectorId === INSPECTOR_ID) {
				editState(payload);
				await api.sendInspectorState("components");
			}
		});
		const debounceSendInspectorTree = debounce(() => {
			api.sendInspectorTree(INSPECTOR_ID);
		}, 120);
		const debounceSendInspectorState = debounce(() => {
			api.sendInspectorState(INSPECTOR_ID);
		}, 120);
		hook.on.componentAdded(async (app, uid, parentUid, component) => {
			if (devtoolsState.highPerfModeEnabled) return;
			if (app?._instance?.type?.devtools?.hide) return;
			if (!app || typeof uid !== "number" && !uid || !component) return;
			const id = await getComponentId({
				app,
				uid,
				instance: component
			});
			const appRecord = await getAppRecord(app);
			if (component) {
				if (component.__VUE_DEVTOOLS_NEXT_UID__ == null) component.__VUE_DEVTOOLS_NEXT_UID__ = id;
				if (!appRecord?.instanceMap.has(id)) {
					appRecord?.instanceMap.set(id, component);
					if (activeAppRecord.value.id === appRecord?.id) activeAppRecord.value.instanceMap = appRecord.instanceMap;
				}
			}
			if (!appRecord) return;
			debounceSendInspectorTree();
		});
		hook.on.componentUpdated(async (app, uid, parentUid, component) => {
			if (devtoolsState.highPerfModeEnabled) return;
			if (app?._instance?.type?.devtools?.hide) return;
			if (!app || typeof uid !== "number" && !uid || !component) return;
			const id = await getComponentId({
				app,
				uid,
				instance: component
			});
			const appRecord = await getAppRecord(app);
			if (component) {
				if (component.__VUE_DEVTOOLS_NEXT_UID__ == null) component.__VUE_DEVTOOLS_NEXT_UID__ = id;
				if (!appRecord?.instanceMap.has(id)) {
					appRecord?.instanceMap.set(id, component);
					if (activeAppRecord.value.id === appRecord?.id) activeAppRecord.value.instanceMap = appRecord.instanceMap;
				}
			}
			if (!appRecord) return;
			debounceSendInspectorTree();
			debounceSendInspectorState();
		});
		hook.on.componentRemoved(async (app, uid, parentUid, component) => {
			if (devtoolsState.highPerfModeEnabled) return;
			if (app?._instance?.type?.devtools?.hide) return;
			if (!app || typeof uid !== "number" && !uid || !component) return;
			const appRecord = await getAppRecord(app);
			if (!appRecord) return;
			const id = await getComponentId({
				app,
				uid,
				instance: component
			});
			appRecord?.instanceMap.delete(id);
			if (activeAppRecord.value.id === appRecord?.id) activeAppRecord.value.instanceMap = appRecord.instanceMap;
			debounceSendInspectorTree();
		});
	};
	return [descriptor, setupFn];
}
//#endregion
//#region src/core/plugin/index.ts
target.__VUE_DEVTOOLS_KIT__REGISTERED_PLUGIN_APPS__ ??= /* @__PURE__ */ new Set();
function setupDevToolsPlugin(pluginDescriptor, setupFn) {
	return hook.setupDevToolsPlugin(pluginDescriptor, setupFn);
}
function callDevToolsPluginSetupFn(plugin, app) {
	const [pluginDescriptor, setupFn] = plugin;
	if (pluginDescriptor.app !== app) return;
	const api = new DevToolsPluginAPI({
		plugin: {
			setupFn,
			descriptor: pluginDescriptor
		},
		ctx: devtoolsContext
	});
	if (pluginDescriptor.packageName === "vuex") api.on.editInspectorState((payload) => {
		api.sendInspectorState(payload.inspectorId);
	});
	setupFn(api);
}
function removeRegisteredPluginApp(app) {
	target.__VUE_DEVTOOLS_KIT__REGISTERED_PLUGIN_APPS__.delete(app);
}
function registerDevToolsPlugin(app, options) {
	if (target.__VUE_DEVTOOLS_KIT__REGISTERED_PLUGIN_APPS__.has(app)) return;
	if (devtoolsState.highPerfModeEnabled && !options?.inspectingComponent) return;
	target.__VUE_DEVTOOLS_KIT__REGISTERED_PLUGIN_APPS__.add(app);
	devtoolsPluginBuffer.forEach((plugin) => {
		callDevToolsPluginSetupFn(plugin, app);
	});
}
//#endregion
//#region src/ctx/router.ts
const ROUTER_KEY = "__VUE_DEVTOOLS_ROUTER__";
const ROUTER_INFO_KEY = "__VUE_DEVTOOLS_ROUTER_INFO__";
target[ROUTER_INFO_KEY] ??= {
	currentRoute: null,
	routes: []
};
target[ROUTER_KEY] ??= {};
const devtoolsRouterInfo = new Proxy(target[ROUTER_INFO_KEY], { get(target$1, property) {
	return target[ROUTER_INFO_KEY][property];
} });
const devtoolsRouter = new Proxy(target[ROUTER_KEY], { get(target$2, property) {
	if (property === "value") return target[ROUTER_KEY];
} });
//#endregion
//#region src/core/router/index.ts
function getRoutes(router) {
	const routesMap = /* @__PURE__ */ new Map();
	return (router?.getRoutes() || []).filter((i) => !routesMap.has(i.path) && routesMap.set(i.path, 1));
}
function filterRoutes(routes) {
	return routes.map((item) => {
		let { path, name, children, meta } = item;
		if (children?.length) children = filterRoutes(children);
		return {
			path,
			name,
			children,
			meta
		};
	});
}
function filterCurrentRoute(route) {
	if (route) {
		const { fullPath, hash, href, path, name, matched, params, query } = route;
		return {
			fullPath,
			hash,
			href,
			path,
			name,
			params,
			query,
			matched: filterRoutes(matched)
		};
	}
	return route;
}
function normalizeRouterInfo(appRecord, activeAppRecord) {
	function init() {
		const router = appRecord.app?.config.globalProperties.$router;
		const currentRoute = filterCurrentRoute(router?.currentRoute.value);
		const routes = filterRoutes(getRoutes(router));
		const c = console.warn;
		console.warn = () => {};
		target[ROUTER_INFO_KEY] = {
			currentRoute: currentRoute ? deepClone(currentRoute) : {},
			routes: deepClone(routes)
		};
		target[ROUTER_KEY] = router;
		console.warn = c;
	}
	init();
	hook.on.componentUpdated(debounce(() => {
		if (activeAppRecord.value?.app !== appRecord.app) return;
		init();
		if (devtoolsState.highPerfModeEnabled) return;
		devtoolsContext.hooks.callHook(DevToolsMessagingHookKeys.ROUTER_INFO_UPDATED, { state: target[ROUTER_INFO_KEY] });
	}, 200));
}
//#endregion
//#region src/ctx/api.ts
function createDevToolsApi(hooks) {
	return {
		async getInspectorTree(payload) {
			const _payload = {
				...payload,
				app: activeAppRecord.value.app,
				rootNodes: []
			};
			await new Promise((resolve) => {
				hooks.callHookWith(async (callbacks) => {
					await Promise.all(callbacks.map((cb) => cb(_payload)));
					resolve();
				}, DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_TREE);
			});
			return _payload.rootNodes;
		},
		async getInspectorState(payload) {
			const _payload = {
				...payload,
				app: activeAppRecord.value.app,
				state: null
			};
			const ctx = { currentTab: `custom-inspector:${payload.inspectorId}` };
			await new Promise((resolve) => {
				hooks.callHookWith(async (callbacks) => {
					await Promise.all(callbacks.map((cb) => cb(_payload, ctx)));
					resolve();
				}, DevToolsV6PluginAPIHookKeys.GET_INSPECTOR_STATE);
			});
			return _payload.state;
		},
		editInspectorState(payload) {
			const stateEditor = new StateEditor();
			const _payload = {
				...payload,
				app: activeAppRecord.value.app,
				set: (obj, path = payload.path, value = payload.state.value, cb) => {
					stateEditor.set(obj, path, value, cb || stateEditor.createDefaultSetCallback(payload.state));
				}
			};
			hooks.callHookWith((callbacks) => {
				callbacks.forEach((cb) => cb(_payload));
			}, DevToolsV6PluginAPIHookKeys.EDIT_INSPECTOR_STATE);
		},
		sendInspectorState(inspectorId) {
			const inspector = getInspector(inspectorId);
			hooks.callHook(DevToolsContextHookKeys.SEND_INSPECTOR_STATE, {
				inspectorId,
				plugin: {
					descriptor: inspector.descriptor,
					setupFn: () => ({})
				}
			});
		},
		inspectComponentInspector() {
			return inspectComponentHighLighter();
		},
		cancelInspectComponentInspector() {
			return cancelInspectComponentHighLighter();
		},
		getComponentRenderCode(id) {
			const instance = getComponentInstance(activeAppRecord.value, id);
			if (instance) return !(typeof instance?.type === "function") ? instance.render.toString() : instance.type.toString();
		},
		scrollToComponent(id) {
			return scrollToComponent({ id });
		},
		openInEditor,
		getVueInspector: getComponentInspector,
		toggleApp(id, options) {
			const appRecord = devtoolsAppRecords.value.find((record) => record.id === id);
			if (appRecord) {
				setActiveAppRecordId(id);
				setActiveAppRecord(appRecord);
				normalizeRouterInfo(appRecord, activeAppRecord);
				callInspectorUpdatedHook();
				registerDevToolsPlugin(appRecord.app, options);
			}
		},
		inspectDOM(instanceId) {
			const instance = getComponentInstance(activeAppRecord.value, instanceId);
			if (instance) {
				const [el] = getRootElementsFromComponentInstance(instance);
				if (el) target.__VUE_DEVTOOLS_INSPECT_DOM_TARGET__ = el;
			}
		},
		updatePluginSettings(pluginId, key, value) {
			setPluginSettings(pluginId, key, value);
		},
		getPluginSettings(pluginId) {
			return {
				options: getPluginSettingsOptions(pluginId),
				values: getPluginSettings(pluginId)
			};
		}
	};
}
//#endregion
//#region src/ctx/env.ts
target.__VUE_DEVTOOLS_ENV__ ??= { vitePluginDetected: false };
function getDevToolsEnv() {
	return target.__VUE_DEVTOOLS_ENV__;
}
function setDevToolsEnv(env) {
	target.__VUE_DEVTOOLS_ENV__ = {
		...target.__VUE_DEVTOOLS_ENV__,
		...env
	};
}
//#endregion
//#region src/ctx/index.ts
const hooks = createDevToolsCtxHooks();
target.__VUE_DEVTOOLS_KIT_CONTEXT__ ??= {
	hooks,
	get state() {
		return {
			...devtoolsState,
			activeAppRecordId: activeAppRecord.id,
			activeAppRecord: activeAppRecord.value,
			appRecords: devtoolsAppRecords.value
		};
	},
	api: createDevToolsApi(hooks)
};
const devtoolsContext = target.__VUE_DEVTOOLS_KIT_CONTEXT__;
//#endregion
//#region ../../node_modules/.pnpm/speakingurl@14.0.1/node_modules/speakingurl/lib/speakingurl.js
var require_speakingurl$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(root) {
		"use strict";
		/**
		* charMap
		* @type {Object}
		*/
		var charMap = {
			"À": "A",
			"Á": "A",
			"Â": "A",
			"Ã": "A",
			"Ä": "Ae",
			"Å": "A",
			"Æ": "AE",
			"Ç": "C",
			"È": "E",
			"É": "E",
			"Ê": "E",
			"Ë": "E",
			"Ì": "I",
			"Í": "I",
			"Î": "I",
			"Ï": "I",
			"Ð": "D",
			"Ñ": "N",
			"Ò": "O",
			"Ó": "O",
			"Ô": "O",
			"Õ": "O",
			"Ö": "Oe",
			"Ő": "O",
			"Ø": "O",
			"Ù": "U",
			"Ú": "U",
			"Û": "U",
			"Ü": "Ue",
			"Ű": "U",
			"Ý": "Y",
			"Þ": "TH",
			"ß": "ss",
			"à": "a",
			"á": "a",
			"â": "a",
			"ã": "a",
			"ä": "ae",
			"å": "a",
			"æ": "ae",
			"ç": "c",
			"è": "e",
			"é": "e",
			"ê": "e",
			"ë": "e",
			"ì": "i",
			"í": "i",
			"î": "i",
			"ï": "i",
			"ð": "d",
			"ñ": "n",
			"ò": "o",
			"ó": "o",
			"ô": "o",
			"õ": "o",
			"ö": "oe",
			"ő": "o",
			"ø": "o",
			"ù": "u",
			"ú": "u",
			"û": "u",
			"ü": "ue",
			"ű": "u",
			"ý": "y",
			"þ": "th",
			"ÿ": "y",
			"ẞ": "SS",
			"ا": "a",
			"أ": "a",
			"إ": "i",
			"آ": "aa",
			"ؤ": "u",
			"ئ": "e",
			"ء": "a",
			"ب": "b",
			"ت": "t",
			"ث": "th",
			"ج": "j",
			"ح": "h",
			"خ": "kh",
			"د": "d",
			"ذ": "th",
			"ر": "r",
			"ز": "z",
			"س": "s",
			"ش": "sh",
			"ص": "s",
			"ض": "dh",
			"ط": "t",
			"ظ": "z",
			"ع": "a",
			"غ": "gh",
			"ف": "f",
			"ق": "q",
			"ك": "k",
			"ل": "l",
			"م": "m",
			"ن": "n",
			"ه": "h",
			"و": "w",
			"ي": "y",
			"ى": "a",
			"ة": "h",
			"ﻻ": "la",
			"ﻷ": "laa",
			"ﻹ": "lai",
			"ﻵ": "laa",
			"گ": "g",
			"چ": "ch",
			"پ": "p",
			"ژ": "zh",
			"ک": "k",
			"ی": "y",
			"َ": "a",
			"ً": "an",
			"ِ": "e",
			"ٍ": "en",
			"ُ": "u",
			"ٌ": "on",
			"ْ": "",
			"٠": "0",
			"١": "1",
			"٢": "2",
			"٣": "3",
			"٤": "4",
			"٥": "5",
			"٦": "6",
			"٧": "7",
			"٨": "8",
			"٩": "9",
			"۰": "0",
			"۱": "1",
			"۲": "2",
			"۳": "3",
			"۴": "4",
			"۵": "5",
			"۶": "6",
			"۷": "7",
			"۸": "8",
			"۹": "9",
			"က": "k",
			"ခ": "kh",
			"ဂ": "g",
			"ဃ": "ga",
			"င": "ng",
			"စ": "s",
			"ဆ": "sa",
			"ဇ": "z",
			"စျ": "za",
			"ည": "ny",
			"ဋ": "t",
			"ဌ": "ta",
			"ဍ": "d",
			"ဎ": "da",
			"ဏ": "na",
			"တ": "t",
			"ထ": "ta",
			"ဒ": "d",
			"ဓ": "da",
			"န": "n",
			"ပ": "p",
			"ဖ": "pa",
			"ဗ": "b",
			"ဘ": "ba",
			"မ": "m",
			"ယ": "y",
			"ရ": "ya",
			"လ": "l",
			"ဝ": "w",
			"သ": "th",
			"ဟ": "h",
			"ဠ": "la",
			"အ": "a",
			"ြ": "y",
			"ျ": "ya",
			"ွ": "w",
			"ြွ": "yw",
			"ျွ": "ywa",
			"ှ": "h",
			"ဧ": "e",
			"၏": "-e",
			"ဣ": "i",
			"ဤ": "-i",
			"ဉ": "u",
			"ဦ": "-u",
			"ဩ": "aw",
			"သြော": "aw",
			"ဪ": "aw",
			"၀": "0",
			"၁": "1",
			"၂": "2",
			"၃": "3",
			"၄": "4",
			"၅": "5",
			"၆": "6",
			"၇": "7",
			"၈": "8",
			"၉": "9",
			"္": "",
			"့": "",
			"း": "",
			"č": "c",
			"ď": "d",
			"ě": "e",
			"ň": "n",
			"ř": "r",
			"š": "s",
			"ť": "t",
			"ů": "u",
			"ž": "z",
			"Č": "C",
			"Ď": "D",
			"Ě": "E",
			"Ň": "N",
			"Ř": "R",
			"Š": "S",
			"Ť": "T",
			"Ů": "U",
			"Ž": "Z",
			"ހ": "h",
			"ށ": "sh",
			"ނ": "n",
			"ރ": "r",
			"ބ": "b",
			"ޅ": "lh",
			"ކ": "k",
			"އ": "a",
			"ވ": "v",
			"މ": "m",
			"ފ": "f",
			"ދ": "dh",
			"ތ": "th",
			"ލ": "l",
			"ގ": "g",
			"ޏ": "gn",
			"ސ": "s",
			"ޑ": "d",
			"ޒ": "z",
			"ޓ": "t",
			"ޔ": "y",
			"ޕ": "p",
			"ޖ": "j",
			"ޗ": "ch",
			"ޘ": "tt",
			"ޙ": "hh",
			"ޚ": "kh",
			"ޛ": "th",
			"ޜ": "z",
			"ޝ": "sh",
			"ޞ": "s",
			"ޟ": "d",
			"ޠ": "t",
			"ޡ": "z",
			"ޢ": "a",
			"ޣ": "gh",
			"ޤ": "q",
			"ޥ": "w",
			"ަ": "a",
			"ާ": "aa",
			"ި": "i",
			"ީ": "ee",
			"ު": "u",
			"ޫ": "oo",
			"ެ": "e",
			"ޭ": "ey",
			"ޮ": "o",
			"ޯ": "oa",
			"ް": "",
			"ა": "a",
			"ბ": "b",
			"გ": "g",
			"დ": "d",
			"ე": "e",
			"ვ": "v",
			"ზ": "z",
			"თ": "t",
			"ი": "i",
			"კ": "k",
			"ლ": "l",
			"მ": "m",
			"ნ": "n",
			"ო": "o",
			"პ": "p",
			"ჟ": "zh",
			"რ": "r",
			"ს": "s",
			"ტ": "t",
			"უ": "u",
			"ფ": "p",
			"ქ": "k",
			"ღ": "gh",
			"ყ": "q",
			"შ": "sh",
			"ჩ": "ch",
			"ც": "ts",
			"ძ": "dz",
			"წ": "ts",
			"ჭ": "ch",
			"ხ": "kh",
			"ჯ": "j",
			"ჰ": "h",
			"α": "a",
			"β": "v",
			"γ": "g",
			"δ": "d",
			"ε": "e",
			"ζ": "z",
			"η": "i",
			"θ": "th",
			"ι": "i",
			"κ": "k",
			"λ": "l",
			"μ": "m",
			"ν": "n",
			"ξ": "ks",
			"ο": "o",
			"π": "p",
			"ρ": "r",
			"σ": "s",
			"τ": "t",
			"υ": "y",
			"φ": "f",
			"χ": "x",
			"ψ": "ps",
			"ω": "o",
			"ά": "a",
			"έ": "e",
			"ί": "i",
			"ό": "o",
			"ύ": "y",
			"ή": "i",
			"ώ": "o",
			"ς": "s",
			"ϊ": "i",
			"ΰ": "y",
			"ϋ": "y",
			"ΐ": "i",
			"Α": "A",
			"Β": "B",
			"Γ": "G",
			"Δ": "D",
			"Ε": "E",
			"Ζ": "Z",
			"Η": "I",
			"Θ": "TH",
			"Ι": "I",
			"Κ": "K",
			"Λ": "L",
			"Μ": "M",
			"Ν": "N",
			"Ξ": "KS",
			"Ο": "O",
			"Π": "P",
			"Ρ": "R",
			"Σ": "S",
			"Τ": "T",
			"Υ": "Y",
			"Φ": "F",
			"Χ": "X",
			"Ψ": "PS",
			"Ω": "O",
			"Ά": "A",
			"Έ": "E",
			"Ί": "I",
			"Ό": "O",
			"Ύ": "Y",
			"Ή": "I",
			"Ώ": "O",
			"Ϊ": "I",
			"Ϋ": "Y",
			"ā": "a",
			"ē": "e",
			"ģ": "g",
			"ī": "i",
			"ķ": "k",
			"ļ": "l",
			"ņ": "n",
			"ū": "u",
			"Ā": "A",
			"Ē": "E",
			"Ģ": "G",
			"Ī": "I",
			"Ķ": "k",
			"Ļ": "L",
			"Ņ": "N",
			"Ū": "U",
			"Ќ": "Kj",
			"ќ": "kj",
			"Љ": "Lj",
			"љ": "lj",
			"Њ": "Nj",
			"њ": "nj",
			"Тс": "Ts",
			"тс": "ts",
			"ą": "a",
			"ć": "c",
			"ę": "e",
			"ł": "l",
			"ń": "n",
			"ś": "s",
			"ź": "z",
			"ż": "z",
			"Ą": "A",
			"Ć": "C",
			"Ę": "E",
			"Ł": "L",
			"Ń": "N",
			"Ś": "S",
			"Ź": "Z",
			"Ż": "Z",
			"Є": "Ye",
			"І": "I",
			"Ї": "Yi",
			"Ґ": "G",
			"є": "ye",
			"і": "i",
			"ї": "yi",
			"ґ": "g",
			"ă": "a",
			"Ă": "A",
			"ș": "s",
			"Ș": "S",
			"ț": "t",
			"Ț": "T",
			"ţ": "t",
			"Ţ": "T",
			"а": "a",
			"б": "b",
			"в": "v",
			"г": "g",
			"д": "d",
			"е": "e",
			"ё": "yo",
			"ж": "zh",
			"з": "z",
			"и": "i",
			"й": "i",
			"к": "k",
			"л": "l",
			"м": "m",
			"н": "n",
			"о": "o",
			"п": "p",
			"р": "r",
			"с": "s",
			"т": "t",
			"у": "u",
			"ф": "f",
			"х": "kh",
			"ц": "c",
			"ч": "ch",
			"ш": "sh",
			"щ": "sh",
			"ъ": "",
			"ы": "y",
			"ь": "",
			"э": "e",
			"ю": "yu",
			"я": "ya",
			"А": "A",
			"Б": "B",
			"В": "V",
			"Г": "G",
			"Д": "D",
			"Е": "E",
			"Ё": "Yo",
			"Ж": "Zh",
			"З": "Z",
			"И": "I",
			"Й": "I",
			"К": "K",
			"Л": "L",
			"М": "M",
			"Н": "N",
			"О": "O",
			"П": "P",
			"Р": "R",
			"С": "S",
			"Т": "T",
			"У": "U",
			"Ф": "F",
			"Х": "Kh",
			"Ц": "C",
			"Ч": "Ch",
			"Ш": "Sh",
			"Щ": "Sh",
			"Ъ": "",
			"Ы": "Y",
			"Ь": "",
			"Э": "E",
			"Ю": "Yu",
			"Я": "Ya",
			"ђ": "dj",
			"ј": "j",
			"ћ": "c",
			"џ": "dz",
			"Ђ": "Dj",
			"Ј": "j",
			"Ћ": "C",
			"Џ": "Dz",
			"ľ": "l",
			"ĺ": "l",
			"ŕ": "r",
			"Ľ": "L",
			"Ĺ": "L",
			"Ŕ": "R",
			"ş": "s",
			"Ş": "S",
			"ı": "i",
			"İ": "I",
			"ğ": "g",
			"Ğ": "G",
			"ả": "a",
			"Ả": "A",
			"ẳ": "a",
			"Ẳ": "A",
			"ẩ": "a",
			"Ẩ": "A",
			"đ": "d",
			"Đ": "D",
			"ẹ": "e",
			"Ẹ": "E",
			"ẽ": "e",
			"Ẽ": "E",
			"ẻ": "e",
			"Ẻ": "E",
			"ế": "e",
			"Ế": "E",
			"ề": "e",
			"Ề": "E",
			"ệ": "e",
			"Ệ": "E",
			"ễ": "e",
			"Ễ": "E",
			"ể": "e",
			"Ể": "E",
			"ỏ": "o",
			"ọ": "o",
			"Ọ": "o",
			"ố": "o",
			"Ố": "O",
			"ồ": "o",
			"Ồ": "O",
			"ổ": "o",
			"Ổ": "O",
			"ộ": "o",
			"Ộ": "O",
			"ỗ": "o",
			"Ỗ": "O",
			"ơ": "o",
			"Ơ": "O",
			"ớ": "o",
			"Ớ": "O",
			"ờ": "o",
			"Ờ": "O",
			"ợ": "o",
			"Ợ": "O",
			"ỡ": "o",
			"Ỡ": "O",
			"Ở": "o",
			"ở": "o",
			"ị": "i",
			"Ị": "I",
			"ĩ": "i",
			"Ĩ": "I",
			"ỉ": "i",
			"Ỉ": "i",
			"ủ": "u",
			"Ủ": "U",
			"ụ": "u",
			"Ụ": "U",
			"ũ": "u",
			"Ũ": "U",
			"ư": "u",
			"Ư": "U",
			"ứ": "u",
			"Ứ": "U",
			"ừ": "u",
			"Ừ": "U",
			"ự": "u",
			"Ự": "U",
			"ữ": "u",
			"Ữ": "U",
			"ử": "u",
			"Ử": "ư",
			"ỷ": "y",
			"Ỷ": "y",
			"ỳ": "y",
			"Ỳ": "Y",
			"ỵ": "y",
			"Ỵ": "Y",
			"ỹ": "y",
			"Ỹ": "Y",
			"ạ": "a",
			"Ạ": "A",
			"ấ": "a",
			"Ấ": "A",
			"ầ": "a",
			"Ầ": "A",
			"ậ": "a",
			"Ậ": "A",
			"ẫ": "a",
			"Ẫ": "A",
			"ắ": "a",
			"Ắ": "A",
			"ằ": "a",
			"Ằ": "A",
			"ặ": "a",
			"Ặ": "A",
			"ẵ": "a",
			"Ẵ": "A",
			"⓪": "0",
			"①": "1",
			"②": "2",
			"③": "3",
			"④": "4",
			"⑤": "5",
			"⑥": "6",
			"⑦": "7",
			"⑧": "8",
			"⑨": "9",
			"⑩": "10",
			"⑪": "11",
			"⑫": "12",
			"⑬": "13",
			"⑭": "14",
			"⑮": "15",
			"⑯": "16",
			"⑰": "17",
			"⑱": "18",
			"⑲": "18",
			"⑳": "18",
			"⓵": "1",
			"⓶": "2",
			"⓷": "3",
			"⓸": "4",
			"⓹": "5",
			"⓺": "6",
			"⓻": "7",
			"⓼": "8",
			"⓽": "9",
			"⓾": "10",
			"⓿": "0",
			"⓫": "11",
			"⓬": "12",
			"⓭": "13",
			"⓮": "14",
			"⓯": "15",
			"⓰": "16",
			"⓱": "17",
			"⓲": "18",
			"⓳": "19",
			"⓴": "20",
			"Ⓐ": "A",
			"Ⓑ": "B",
			"Ⓒ": "C",
			"Ⓓ": "D",
			"Ⓔ": "E",
			"Ⓕ": "F",
			"Ⓖ": "G",
			"Ⓗ": "H",
			"Ⓘ": "I",
			"Ⓙ": "J",
			"Ⓚ": "K",
			"Ⓛ": "L",
			"Ⓜ": "M",
			"Ⓝ": "N",
			"Ⓞ": "O",
			"Ⓟ": "P",
			"Ⓠ": "Q",
			"Ⓡ": "R",
			"Ⓢ": "S",
			"Ⓣ": "T",
			"Ⓤ": "U",
			"Ⓥ": "V",
			"Ⓦ": "W",
			"Ⓧ": "X",
			"Ⓨ": "Y",
			"Ⓩ": "Z",
			"ⓐ": "a",
			"ⓑ": "b",
			"ⓒ": "c",
			"ⓓ": "d",
			"ⓔ": "e",
			"ⓕ": "f",
			"ⓖ": "g",
			"ⓗ": "h",
			"ⓘ": "i",
			"ⓙ": "j",
			"ⓚ": "k",
			"ⓛ": "l",
			"ⓜ": "m",
			"ⓝ": "n",
			"ⓞ": "o",
			"ⓟ": "p",
			"ⓠ": "q",
			"ⓡ": "r",
			"ⓢ": "s",
			"ⓣ": "t",
			"ⓤ": "u",
			"ⓦ": "v",
			"ⓥ": "w",
			"ⓧ": "x",
			"ⓨ": "y",
			"ⓩ": "z",
			"“": "\"",
			"”": "\"",
			"‘": "'",
			"’": "'",
			"∂": "d",
			"ƒ": "f",
			"™": "(TM)",
			"©": "(C)",
			"œ": "oe",
			"Œ": "OE",
			"®": "(R)",
			"†": "+",
			"℠": "(SM)",
			"…": "...",
			"˚": "o",
			"º": "o",
			"ª": "a",
			"•": "*",
			"၊": ",",
			"။": ".",
			"$": "USD",
			"€": "EUR",
			"₢": "BRN",
			"₣": "FRF",
			"£": "GBP",
			"₤": "ITL",
			"₦": "NGN",
			"₧": "ESP",
			"₩": "KRW",
			"₪": "ILS",
			"₫": "VND",
			"₭": "LAK",
			"₮": "MNT",
			"₯": "GRD",
			"₱": "ARS",
			"₲": "PYG",
			"₳": "ARA",
			"₴": "UAH",
			"₵": "GHS",
			"¢": "cent",
			"¥": "CNY",
			"元": "CNY",
			"円": "YEN",
			"﷼": "IRR",
			"₠": "EWE",
			"฿": "THB",
			"₨": "INR",
			"₹": "INR",
			"₰": "PF",
			"₺": "TRY",
			"؋": "AFN",
			"₼": "AZN",
			"лв": "BGN",
			"៛": "KHR",
			"₡": "CRC",
			"₸": "KZT",
			"ден": "MKD",
			"zł": "PLN",
			"₽": "RUB",
			"₾": "GEL"
		};
		/**
		* special look ahead character array
		* These characters form with consonants to become 'single'/consonant combo
		* @type [Array]
		*/
		var lookAheadCharArray = ["်", "ް"];
		/**
		* diatricMap for languages where transliteration changes entirely as more diatrics are added
		* @type {Object}
		*/
		var diatricMap = {
			"ာ": "a",
			"ါ": "a",
			"ေ": "e",
			"ဲ": "e",
			"ိ": "i",
			"ီ": "i",
			"ို": "o",
			"ု": "u",
			"ူ": "u",
			"ေါင်": "aung",
			"ော": "aw",
			"ော်": "aw",
			"ေါ": "aw",
			"ေါ်": "aw",
			"်": "်",
			"က်": "et",
			"ိုက်": "aik",
			"ောက်": "auk",
			"င်": "in",
			"ိုင်": "aing",
			"ောင်": "aung",
			"စ်": "it",
			"ည်": "i",
			"တ်": "at",
			"ိတ်": "eik",
			"ုတ်": "ok",
			"ွတ်": "ut",
			"ေတ်": "it",
			"ဒ်": "d",
			"ိုဒ်": "ok",
			"ုဒ်": "ait",
			"န်": "an",
			"ာန်": "an",
			"ိန်": "ein",
			"ုန်": "on",
			"ွန်": "un",
			"ပ်": "at",
			"ိပ်": "eik",
			"ုပ်": "ok",
			"ွပ်": "ut",
			"န်ုပ်": "nub",
			"မ်": "an",
			"ိမ်": "ein",
			"ုမ်": "on",
			"ွမ်": "un",
			"ယ်": "e",
			"ိုလ်": "ol",
			"ဉ်": "in",
			"ံ": "an",
			"ိံ": "ein",
			"ုံ": "on",
			"ައް": "ah",
			"ަށް": "ah"
		};
		/**
		* langCharMap language specific characters translations
		* @type   {Object}
		*/
		var langCharMap = {
			"en": {},
			"az": {
				"ç": "c",
				"ə": "e",
				"ğ": "g",
				"ı": "i",
				"ö": "o",
				"ş": "s",
				"ü": "u",
				"Ç": "C",
				"Ə": "E",
				"Ğ": "G",
				"İ": "I",
				"Ö": "O",
				"Ş": "S",
				"Ü": "U"
			},
			"cs": {
				"č": "c",
				"ď": "d",
				"ě": "e",
				"ň": "n",
				"ř": "r",
				"š": "s",
				"ť": "t",
				"ů": "u",
				"ž": "z",
				"Č": "C",
				"Ď": "D",
				"Ě": "E",
				"Ň": "N",
				"Ř": "R",
				"Š": "S",
				"Ť": "T",
				"Ů": "U",
				"Ž": "Z"
			},
			"fi": {
				"ä": "a",
				"Ä": "A",
				"ö": "o",
				"Ö": "O"
			},
			"hu": {
				"ä": "a",
				"Ä": "A",
				"ö": "o",
				"Ö": "O",
				"ü": "u",
				"Ü": "U",
				"ű": "u",
				"Ű": "U"
			},
			"lt": {
				"ą": "a",
				"č": "c",
				"ę": "e",
				"ė": "e",
				"į": "i",
				"š": "s",
				"ų": "u",
				"ū": "u",
				"ž": "z",
				"Ą": "A",
				"Č": "C",
				"Ę": "E",
				"Ė": "E",
				"Į": "I",
				"Š": "S",
				"Ų": "U",
				"Ū": "U"
			},
			"lv": {
				"ā": "a",
				"č": "c",
				"ē": "e",
				"ģ": "g",
				"ī": "i",
				"ķ": "k",
				"ļ": "l",
				"ņ": "n",
				"š": "s",
				"ū": "u",
				"ž": "z",
				"Ā": "A",
				"Č": "C",
				"Ē": "E",
				"Ģ": "G",
				"Ī": "i",
				"Ķ": "k",
				"Ļ": "L",
				"Ņ": "N",
				"Š": "S",
				"Ū": "u",
				"Ž": "Z"
			},
			"pl": {
				"ą": "a",
				"ć": "c",
				"ę": "e",
				"ł": "l",
				"ń": "n",
				"ó": "o",
				"ś": "s",
				"ź": "z",
				"ż": "z",
				"Ą": "A",
				"Ć": "C",
				"Ę": "e",
				"Ł": "L",
				"Ń": "N",
				"Ó": "O",
				"Ś": "S",
				"Ź": "Z",
				"Ż": "Z"
			},
			"sv": {
				"ä": "a",
				"Ä": "A",
				"ö": "o",
				"Ö": "O"
			},
			"sk": {
				"ä": "a",
				"Ä": "A"
			},
			"sr": {
				"љ": "lj",
				"њ": "nj",
				"Љ": "Lj",
				"Њ": "Nj",
				"đ": "dj",
				"Đ": "Dj"
			},
			"tr": {
				"Ü": "U",
				"Ö": "O",
				"ü": "u",
				"ö": "o"
			}
		};
		/**
		* symbolMap language specific symbol translations
		* translations must be transliterated already
		* @type   {Object}
		*/
		var symbolMap = {
			"ar": {
				"∆": "delta",
				"∞": "la-nihaya",
				"♥": "hob",
				"&": "wa",
				"|": "aw",
				"<": "aqal-men",
				">": "akbar-men",
				"∑": "majmou",
				"¤": "omla"
			},
			"az": {},
			"ca": {
				"∆": "delta",
				"∞": "infinit",
				"♥": "amor",
				"&": "i",
				"|": "o",
				"<": "menys que",
				">": "mes que",
				"∑": "suma dels",
				"¤": "moneda"
			},
			"cs": {
				"∆": "delta",
				"∞": "nekonecno",
				"♥": "laska",
				"&": "a",
				"|": "nebo",
				"<": "mensi nez",
				">": "vetsi nez",
				"∑": "soucet",
				"¤": "mena"
			},
			"de": {
				"∆": "delta",
				"∞": "unendlich",
				"♥": "Liebe",
				"&": "und",
				"|": "oder",
				"<": "kleiner als",
				">": "groesser als",
				"∑": "Summe von",
				"¤": "Waehrung"
			},
			"dv": {
				"∆": "delta",
				"∞": "kolunulaa",
				"♥": "loabi",
				"&": "aai",
				"|": "noonee",
				"<": "ah vure kuda",
				">": "ah vure bodu",
				"∑": "jumula",
				"¤": "faisaa"
			},
			"en": {
				"∆": "delta",
				"∞": "infinity",
				"♥": "love",
				"&": "and",
				"|": "or",
				"<": "less than",
				">": "greater than",
				"∑": "sum",
				"¤": "currency"
			},
			"es": {
				"∆": "delta",
				"∞": "infinito",
				"♥": "amor",
				"&": "y",
				"|": "u",
				"<": "menos que",
				">": "mas que",
				"∑": "suma de los",
				"¤": "moneda"
			},
			"fa": {
				"∆": "delta",
				"∞": "bi-nahayat",
				"♥": "eshgh",
				"&": "va",
				"|": "ya",
				"<": "kamtar-az",
				">": "bishtar-az",
				"∑": "majmooe",
				"¤": "vahed"
			},
			"fi": {
				"∆": "delta",
				"∞": "aarettomyys",
				"♥": "rakkaus",
				"&": "ja",
				"|": "tai",
				"<": "pienempi kuin",
				">": "suurempi kuin",
				"∑": "summa",
				"¤": "valuutta"
			},
			"fr": {
				"∆": "delta",
				"∞": "infiniment",
				"♥": "Amour",
				"&": "et",
				"|": "ou",
				"<": "moins que",
				">": "superieure a",
				"∑": "somme des",
				"¤": "monnaie"
			},
			"ge": {
				"∆": "delta",
				"∞": "usasruloba",
				"♥": "siqvaruli",
				"&": "da",
				"|": "an",
				"<": "naklebi",
				">": "meti",
				"∑": "jami",
				"¤": "valuta"
			},
			"gr": {},
			"hu": {
				"∆": "delta",
				"∞": "vegtelen",
				"♥": "szerelem",
				"&": "es",
				"|": "vagy",
				"<": "kisebb mint",
				">": "nagyobb mint",
				"∑": "szumma",
				"¤": "penznem"
			},
			"it": {
				"∆": "delta",
				"∞": "infinito",
				"♥": "amore",
				"&": "e",
				"|": "o",
				"<": "minore di",
				">": "maggiore di",
				"∑": "somma",
				"¤": "moneta"
			},
			"lt": {
				"∆": "delta",
				"∞": "begalybe",
				"♥": "meile",
				"&": "ir",
				"|": "ar",
				"<": "maziau nei",
				">": "daugiau nei",
				"∑": "suma",
				"¤": "valiuta"
			},
			"lv": {
				"∆": "delta",
				"∞": "bezgaliba",
				"♥": "milestiba",
				"&": "un",
				"|": "vai",
				"<": "mazak neka",
				">": "lielaks neka",
				"∑": "summa",
				"¤": "valuta"
			},
			"my": {
				"∆": "kwahkhyaet",
				"∞": "asaonasme",
				"♥": "akhyait",
				"&": "nhin",
				"|": "tho",
				"<": "ngethaw",
				">": "kyithaw",
				"∑": "paungld",
				"¤": "ngwekye"
			},
			"mk": {},
			"nl": {
				"∆": "delta",
				"∞": "oneindig",
				"♥": "liefde",
				"&": "en",
				"|": "of",
				"<": "kleiner dan",
				">": "groter dan",
				"∑": "som",
				"¤": "valuta"
			},
			"pl": {
				"∆": "delta",
				"∞": "nieskonczonosc",
				"♥": "milosc",
				"&": "i",
				"|": "lub",
				"<": "mniejsze niz",
				">": "wieksze niz",
				"∑": "suma",
				"¤": "waluta"
			},
			"pt": {
				"∆": "delta",
				"∞": "infinito",
				"♥": "amor",
				"&": "e",
				"|": "ou",
				"<": "menor que",
				">": "maior que",
				"∑": "soma",
				"¤": "moeda"
			},
			"ro": {
				"∆": "delta",
				"∞": "infinit",
				"♥": "dragoste",
				"&": "si",
				"|": "sau",
				"<": "mai mic ca",
				">": "mai mare ca",
				"∑": "suma",
				"¤": "valuta"
			},
			"ru": {
				"∆": "delta",
				"∞": "beskonechno",
				"♥": "lubov",
				"&": "i",
				"|": "ili",
				"<": "menshe",
				">": "bolshe",
				"∑": "summa",
				"¤": "valjuta"
			},
			"sk": {
				"∆": "delta",
				"∞": "nekonecno",
				"♥": "laska",
				"&": "a",
				"|": "alebo",
				"<": "menej ako",
				">": "viac ako",
				"∑": "sucet",
				"¤": "mena"
			},
			"sr": {},
			"tr": {
				"∆": "delta",
				"∞": "sonsuzluk",
				"♥": "ask",
				"&": "ve",
				"|": "veya",
				"<": "kucuktur",
				">": "buyuktur",
				"∑": "toplam",
				"¤": "para birimi"
			},
			"uk": {
				"∆": "delta",
				"∞": "bezkinechnist",
				"♥": "lubov",
				"&": "i",
				"|": "abo",
				"<": "menshe",
				">": "bilshe",
				"∑": "suma",
				"¤": "valjuta"
			},
			"vn": {
				"∆": "delta",
				"∞": "vo cuc",
				"♥": "yeu",
				"&": "va",
				"|": "hoac",
				"<": "nho hon",
				">": "lon hon",
				"∑": "tong",
				"¤": "tien te"
			}
		};
		var uricChars = [
			";",
			"?",
			":",
			"@",
			"&",
			"=",
			"+",
			"$",
			",",
			"/"
		].join("");
		var uricNoSlashChars = [
			";",
			"?",
			":",
			"@",
			"&",
			"=",
			"+",
			"$",
			","
		].join("");
		var markChars = [
			".",
			"!",
			"~",
			"*",
			"'",
			"(",
			")"
		].join("");
		/**
		* getSlug
		* @param  {string} input input string
		* @param  {object|string} opts config object or separator string/char
		* @api    public
		* @return {string}  sluggified string
		*/
		var getSlug = function getSlug(input, opts) {
			var separator = "-";
			var result = "";
			var diatricString = "";
			var convertSymbols = true;
			var customReplacements = {};
			var maintainCase;
			var titleCase;
			var truncate;
			var uricFlag;
			var uricNoSlashFlag;
			var markFlag;
			var symbol;
			var langChar;
			var lucky;
			var i;
			var ch;
			var l;
			var lastCharWasSymbol;
			var lastCharWasDiatric;
			var allowedChars = "";
			if (typeof input !== "string") return "";
			if (typeof opts === "string") separator = opts;
			symbol = symbolMap.en;
			langChar = langCharMap.en;
			if (typeof opts === "object") {
				maintainCase = opts.maintainCase || false;
				customReplacements = opts.custom && typeof opts.custom === "object" ? opts.custom : customReplacements;
				truncate = +opts.truncate > 1 && opts.truncate || false;
				uricFlag = opts.uric || false;
				uricNoSlashFlag = opts.uricNoSlash || false;
				markFlag = opts.mark || false;
				convertSymbols = opts.symbols === false || opts.lang === false ? false : true;
				separator = opts.separator || separator;
				if (uricFlag) allowedChars += uricChars;
				if (uricNoSlashFlag) allowedChars += uricNoSlashChars;
				if (markFlag) allowedChars += markChars;
				symbol = opts.lang && symbolMap[opts.lang] && convertSymbols ? symbolMap[opts.lang] : convertSymbols ? symbolMap.en : {};
				langChar = opts.lang && langCharMap[opts.lang] ? langCharMap[opts.lang] : opts.lang === false || opts.lang === true ? {} : langCharMap.en;
				if (opts.titleCase && typeof opts.titleCase.length === "number" && Array.prototype.toString.call(opts.titleCase)) {
					opts.titleCase.forEach(function(v) {
						customReplacements[v + ""] = v + "";
					});
					titleCase = true;
				} else titleCase = !!opts.titleCase;
				if (opts.custom && typeof opts.custom.length === "number" && Array.prototype.toString.call(opts.custom)) opts.custom.forEach(function(v) {
					customReplacements[v + ""] = v + "";
				});
				Object.keys(customReplacements).forEach(function(v) {
					var r;
					if (v.length > 1) r = new RegExp("\\b" + escapeChars(v) + "\\b", "gi");
					else r = new RegExp(escapeChars(v), "gi");
					input = input.replace(r, customReplacements[v]);
				});
				for (ch in customReplacements) allowedChars += ch;
			}
			allowedChars += separator;
			allowedChars = escapeChars(allowedChars);
			input = input.replace(/(^\s+|\s+$)/g, "");
			lastCharWasSymbol = false;
			lastCharWasDiatric = false;
			for (i = 0, l = input.length; i < l; i++) {
				ch = input[i];
				if (isReplacedCustomChar(ch, customReplacements)) lastCharWasSymbol = false;
				else if (langChar[ch]) {
					ch = lastCharWasSymbol && langChar[ch].match(/[A-Za-z0-9]/) ? " " + langChar[ch] : langChar[ch];
					lastCharWasSymbol = false;
				} else if (ch in charMap) {
					if (i + 1 < l && lookAheadCharArray.indexOf(input[i + 1]) >= 0) {
						diatricString += ch;
						ch = "";
					} else if (lastCharWasDiatric === true) {
						ch = diatricMap[diatricString] + charMap[ch];
						diatricString = "";
					} else ch = lastCharWasSymbol && charMap[ch].match(/[A-Za-z0-9]/) ? " " + charMap[ch] : charMap[ch];
					lastCharWasSymbol = false;
					lastCharWasDiatric = false;
				} else if (ch in diatricMap) {
					diatricString += ch;
					ch = "";
					if (i === l - 1) ch = diatricMap[diatricString];
					lastCharWasDiatric = true;
				} else if (symbol[ch] && !(uricFlag && uricChars.indexOf(ch) !== -1) && !(uricNoSlashFlag && uricNoSlashChars.indexOf(ch) !== -1)) {
					ch = lastCharWasSymbol || result.substr(-1).match(/[A-Za-z0-9]/) ? separator + symbol[ch] : symbol[ch];
					ch += input[i + 1] !== void 0 && input[i + 1].match(/[A-Za-z0-9]/) ? separator : "";
					lastCharWasSymbol = true;
				} else {
					if (lastCharWasDiatric === true) {
						ch = diatricMap[diatricString] + ch;
						diatricString = "";
						lastCharWasDiatric = false;
					} else if (lastCharWasSymbol && (/[A-Za-z0-9]/.test(ch) || result.substr(-1).match(/A-Za-z0-9]/))) ch = " " + ch;
					lastCharWasSymbol = false;
				}
				result += ch.replace(new RegExp("[^\\w\\s" + allowedChars + "_-]", "g"), separator);
			}
			if (titleCase) result = result.replace(/(\w)(\S*)/g, function(_, i, r) {
				var j = i.toUpperCase() + (r !== null ? r : "");
				return Object.keys(customReplacements).indexOf(j.toLowerCase()) < 0 ? j : j.toLowerCase();
			});
			result = result.replace(/\s+/g, separator).replace(new RegExp("\\" + separator + "+", "g"), separator).replace(new RegExp("(^\\" + separator + "+|\\" + separator + "+$)", "g"), "");
			if (truncate && result.length > truncate) {
				lucky = result.charAt(truncate) === separator;
				result = result.slice(0, truncate);
				if (!lucky) result = result.slice(0, result.lastIndexOf(separator));
			}
			if (!maintainCase && !titleCase) result = result.toLowerCase();
			return result;
		};
		/**
		* createSlug curried(opts)(input)
		* @param   {object|string} opts config object or input string
		* @return  {Function} function getSlugWithConfig()
		**/
		var createSlug = function createSlug(opts) {
			/**
			* getSlugWithConfig
			* @param   {string} input string
			* @return  {string} slug string
			*/
			return function getSlugWithConfig(input) {
				return getSlug(input, opts);
			};
		};
		/**
		* escape Chars
		* @param   {string} input string
		*/
		var escapeChars = function escapeChars(input) {
			return input.replace(/[-\\^$*+?.()|[\]{}\/]/g, "\\$&");
		};
		/**
		* check if the char is an already converted char from custom list
		* @param   {char} ch character to check
		* @param   {object} customReplacements custom translation map
		*/
		var isReplacedCustomChar = function(ch, customReplacements) {
			for (var c in customReplacements) if (customReplacements[c] === ch) return true;
		};
		if (typeof module !== "undefined" && module.exports) {
			module.exports = getSlug;
			module.exports.createSlug = createSlug;
		} else if (typeof define !== "undefined" && define.amd) define([], function() {
			return getSlug;
		});
		else try {
			if (root.getSlug || root.createSlug) throw "speakingurl: globals exists /(getSlug|createSlug)/";
			else {
				root.getSlug = getSlug;
				root.createSlug = createSlug;
			}
		} catch (e) {}
	})(exports);
}));
//#endregion
//#region src/core/app/index.ts
var import_speakingurl = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_speakingurl$1();
})))(), 1);
const appRecordInfo = target.__VUE_DEVTOOLS_NEXT_APP_RECORD_INFO__ ??= {
	id: 0,
	appIds: /* @__PURE__ */ new Set()
};
function getAppRecordName(app, fallbackName) {
	return app?._component?.name || `App ${fallbackName}`;
}
function getAppRootInstance(app) {
	if (app._instance) return app._instance;
	else if (app._container?._vnode?.component) return app._container?._vnode?.component;
}
function removeAppRecordId(app) {
	const id = app.__VUE_DEVTOOLS_NEXT_APP_RECORD_ID__;
	if (id != null) {
		appRecordInfo.appIds.delete(id);
		appRecordInfo.id--;
	}
}
function getAppRecordId(app, defaultId) {
	if (app.__VUE_DEVTOOLS_NEXT_APP_RECORD_ID__ != null) return app.__VUE_DEVTOOLS_NEXT_APP_RECORD_ID__;
	let id = defaultId ?? (appRecordInfo.id++).toString();
	if (defaultId && appRecordInfo.appIds.has(id)) {
		let count = 1;
		while (appRecordInfo.appIds.has(`${defaultId}_${count}`)) count++;
		id = `${defaultId}_${count}`;
	}
	appRecordInfo.appIds.add(id);
	app.__VUE_DEVTOOLS_NEXT_APP_RECORD_ID__ = id;
	return id;
}
function createAppRecord(app, types) {
	const rootInstance = getAppRootInstance(app);
	if (rootInstance) {
		appRecordInfo.id++;
		const name = getAppRecordName(app, appRecordInfo.id.toString());
		const id = getAppRecordId(app, (0, import_speakingurl.default)(name));
		const [el] = getRootElementsFromComponentInstance(rootInstance);
		const record = {
			id,
			name,
			types,
			instanceMap: /* @__PURE__ */ new Map(),
			perfGroupIds: /* @__PURE__ */ new Map(),
			rootInstance,
			iframe: isBrowser && document !== el?.ownerDocument ? el?.ownerDocument?.location?.pathname : void 0
		};
		app.__VUE_DEVTOOLS_NEXT_APP_RECORD__ = record;
		const rootId = `${record.id}:root`;
		record.instanceMap.set(rootId, record.rootInstance);
		record.rootInstance.__VUE_DEVTOOLS_NEXT_UID__ = rootId;
		return record;
	} else return {};
}
//#endregion
//#region src/core/iframe/index.ts
function detectIframeApp(target, inIframe = false) {
	if (inIframe) {
		function sendEventToParent(cb) {
			try {
				const hook = window.parent.__VUE_DEVTOOLS_GLOBAL_HOOK__;
				if (hook) cb(hook);
			} catch (e) {}
		}
		const hook = {
			id: "vue-devtools-next",
			devtoolsVersion: "7.0",
			on: (event, cb) => {
				sendEventToParent((hook) => {
					hook.on(event, cb);
				});
			},
			once: (event, cb) => {
				sendEventToParent((hook) => {
					hook.once(event, cb);
				});
			},
			off: (event, cb) => {
				sendEventToParent((hook) => {
					hook.off(event, cb);
				});
			},
			emit: (event, ...payload) => {
				sendEventToParent((hook) => {
					hook.emit(event, ...payload);
				});
			}
		};
		Object.defineProperty(target, "__VUE_DEVTOOLS_GLOBAL_HOOK__", {
			get() {
				return hook;
			},
			configurable: true
		});
	}
	function injectVueHookToIframe(iframe) {
		if (iframe.__vdevtools__injected) return;
		try {
			iframe.__vdevtools__injected = true;
			const inject = () => {
				try {
					iframe.contentWindow.__VUE_DEVTOOLS_IFRAME__ = iframe;
					const script = iframe.contentDocument.createElement("script");
					script.textContent = `;(${detectIframeApp.toString()})(window, true)`;
					iframe.contentDocument.documentElement.appendChild(script);
					script.parentNode.removeChild(script);
				} catch (e) {}
			};
			inject();
			iframe.addEventListener("load", () => inject());
		} catch (e) {}
	}
	function injectVueHookToIframes() {
		if (typeof window === "undefined") return;
		const iframes = Array.from(document.querySelectorAll("iframe:not([data-vue-devtools-ignore])"));
		for (const iframe of iframes) injectVueHookToIframe(iframe);
	}
	injectVueHookToIframes();
	let iframeAppChecks = 0;
	const iframeAppCheckTimer = setInterval(() => {
		injectVueHookToIframes();
		iframeAppChecks++;
		if (iframeAppChecks >= 5) clearInterval(iframeAppCheckTimer);
	}, 1e3);
}
//#endregion
//#region src/core/index.ts
function initDevTools() {
	detectIframeApp(target);
	updateDevToolsState({ vitePluginDetected: getDevToolsEnv().vitePluginDetected });
	const isDevToolsNext = target.__VUE_DEVTOOLS_GLOBAL_HOOK__?.id === "vue-devtools-next";
	if (target.__VUE_DEVTOOLS_GLOBAL_HOOK__ && isDevToolsNext) return;
	const _devtoolsHook = createDevToolsHook();
	if (target.__VUE_DEVTOOLS_HOOK_REPLAY__) try {
		target.__VUE_DEVTOOLS_HOOK_REPLAY__.forEach((cb) => cb(_devtoolsHook));
		target.__VUE_DEVTOOLS_HOOK_REPLAY__ = [];
	} catch (e) {
		console.error("[vue-devtools] Error during hook replay", e);
	}
	_devtoolsHook.once("init", (Vue) => {
		target.__VUE_DEVTOOLS_VUE2_APP_DETECTED__ = true;
		console.log("%c[_____Vue DevTools v7 log_____]", "color: red; font-bold: 600; font-size: 16px;");
		console.log("%cVue DevTools v7 detected in your Vue2 project. v7 only supports Vue3 and will not work.", "font-bold: 500; font-size: 14px;");
		const legacyChromeUrl = "https://chromewebstore.google.com/detail/vuejs-devtools/iaajmlceplecbljialhhkmedjlpdblhp";
		const legacyFirefoxUrl = "https://addons.mozilla.org/firefox/addon/vue-js-devtools-v6-legacy";
		console.log(`%cThe legacy version of chrome extension that supports both Vue 2 and Vue 3 has been moved to %c ${legacyChromeUrl}`, "font-size: 14px;", "text-decoration: underline; cursor: pointer;font-size: 14px;");
		console.log(`%cThe legacy version of firefox extension that supports both Vue 2 and Vue 3 has been moved to %c ${legacyFirefoxUrl}`, "font-size: 14px;", "text-decoration: underline; cursor: pointer;font-size: 14px;");
		console.log("%cPlease install and enable only the legacy version for your Vue2 app.", "font-bold: 500; font-size: 14px;");
		console.log("%c[_____Vue DevTools v7 log_____]", "color: red; font-bold: 600; font-size: 16px;");
	});
	hook.on.setupDevtoolsPlugin((pluginDescriptor, setupFn) => {
		addDevToolsPluginToBuffer(pluginDescriptor, setupFn);
		const { app } = activeAppRecord ?? {};
		if (pluginDescriptor.settings) initPluginSettings(pluginDescriptor.id, pluginDescriptor.settings);
		if (!app) return;
		callDevToolsPluginSetupFn([pluginDescriptor, setupFn], app);
	});
	onLegacyDevToolsPluginApiAvailable(() => {
		devtoolsPluginBuffer.filter(([item]) => item.id !== "components").forEach(([pluginDescriptor, setupFn]) => {
			_devtoolsHook.emit(DevToolsHooks.SETUP_DEVTOOLS_PLUGIN, pluginDescriptor, setupFn, { target: "legacy" });
		});
	});
	hook.on.vueAppInit(async (app, version, types) => {
		const normalizedAppRecord = {
			...createAppRecord(app, types),
			app,
			version
		};
		addDevToolsAppRecord(normalizedAppRecord);
		if (devtoolsAppRecords.value.length === 1) {
			setActiveAppRecord(normalizedAppRecord);
			setActiveAppRecordId(normalizedAppRecord.id);
			normalizeRouterInfo(normalizedAppRecord, activeAppRecord);
			registerDevToolsPlugin(normalizedAppRecord.app);
		}
		setupDevToolsPlugin(...createComponentsDevToolsPlugin(normalizedAppRecord.app));
		updateDevToolsState({ connected: true });
		_devtoolsHook.apps.push(app);
	});
	hook.on.vueAppUnmount(async (app) => {
		const activeRecords = devtoolsAppRecords.value.filter((appRecord) => appRecord.app !== app);
		if (activeRecords.length === 0) updateDevToolsState({ connected: false });
		removeDevToolsAppRecord(app);
		removeAppRecordId(app);
		if (activeAppRecord.value.app === app) {
			setActiveAppRecord(activeRecords[0]);
			devtoolsContext.hooks.callHook(DevToolsMessagingHookKeys.SEND_ACTIVE_APP_UNMOUNTED_TO_CLIENT);
		}
		target.__VUE_DEVTOOLS_GLOBAL_HOOK__.apps.splice(target.__VUE_DEVTOOLS_GLOBAL_HOOK__.apps.indexOf(app), 1);
		removeRegisteredPluginApp(app);
	});
	subscribeDevToolsHook(_devtoolsHook);
	if (!target.__VUE_DEVTOOLS_GLOBAL_HOOK__) Object.defineProperty(target, "__VUE_DEVTOOLS_GLOBAL_HOOK__", {
		get() {
			return _devtoolsHook;
		},
		configurable: true
	});
	else if (!isNuxtApp) Object.assign(__VUE_DEVTOOLS_GLOBAL_HOOK__, _devtoolsHook);
}
function onDevToolsClientConnected(fn) {
	return new Promise((resolve) => {
		if (devtoolsState.connected && devtoolsState.clientConnected) {
			fn();
			resolve();
			return;
		}
		devtoolsContext.hooks.hook(DevToolsMessagingHookKeys.DEVTOOLS_CONNECTED_UPDATED, ({ state }) => {
			if (state.connected && state.clientConnected) {
				fn();
				resolve();
			}
		});
	});
}
//#endregion
//#region src/core/high-perf-mode/index.ts
function toggleHighPerfMode(state) {
	devtoolsState.highPerfModeEnabled = state ?? !devtoolsState.highPerfModeEnabled;
	if (!state && activeAppRecord.value) registerDevToolsPlugin(activeAppRecord.value.app);
}
//#endregion
//#region src/core/component/state/reviver.ts
function reviveSet(val) {
	const result = /* @__PURE__ */ new Set();
	const list = val._custom.value;
	for (let i = 0; i < list.length; i++) {
		const value = list[i];
		result.add(revive(value));
	}
	return result;
}
function reviveMap(val) {
	const result = /* @__PURE__ */ new Map();
	const list = val._custom.value;
	for (let i = 0; i < list.length; i++) {
		const { key, value } = list[i];
		result.set(key, revive(value));
	}
	return result;
}
function revive(val) {
	if (val === "__vue_devtool_undefined__") return;
	else if (val === "__vue_devtool_infinity__") return Number.POSITIVE_INFINITY;
	else if (val === "__vue_devtool_negative_infinity__") return Number.NEGATIVE_INFINITY;
	else if (val === "__vue_devtool_nan__") return NaN;
	else if (val && val._custom) {
		const { _custom: custom } = val;
		if (custom.type === "component") return activeAppRecord.value.instanceMap.get(custom.id);
		else if (custom.type === "map") return reviveMap(val);
		else if (custom.type === "set") return reviveSet(val);
		else if (custom.type === "bigint") return BigInt(custom.value);
		else return revive(custom.value);
	} else if (symbolRE.test(val)) {
		const [, string] = symbolRE.exec(val);
		return Symbol.for(string);
	} else if (specialTypeRE.test(val)) {
		const [, type, string, , details] = specialTypeRE.exec(val);
		const result = new target[type](string);
		if (type === "Error" && details) result.stack = details;
		return result;
	} else return val;
}
function reviver(key, value) {
	return revive(value);
}
//#endregion
//#region src/core/component/state/format.ts
function getInspectorStateValueType(value, raw = true) {
	const type = typeof value;
	if (value == null || value === "__vue_devtool_undefined__" || value === "undefined") return "null";
	else if (type === "boolean" || type === "number" || value === "__vue_devtool_infinity__" || value === "__vue_devtool_negative_infinity__" || value === "__vue_devtool_nan__") return "literal";
	else if (value?._custom) if (raw || value._custom.display != null || value._custom.displayText != null) return "custom";
	else return getInspectorStateValueType(value._custom.value);
	else if (typeof value === "string") {
		const typeMatch = specialTypeRE.exec(value);
		if (typeMatch) {
			const [, type] = typeMatch;
			return `native ${type}`;
		} else return "string";
	} else if (Array.isArray(value) || value?._isArray) return "array";
	else if (isPlainObject(value)) return "plain-object";
	else return "unknown";
}
function formatInspectorStateValue(value, quotes = false, options) {
	const { customClass } = options ?? {};
	let result;
	const type = getInspectorStateValueType(value, false);
	if (type !== "custom" && value?._custom) value = value._custom.value;
	if (result = internalStateTokenToString(value)) return result;
	else if (type === "custom") return value._custom.value?._custom && formatInspectorStateValue(value._custom.value, quotes, options) || value._custom.displayText || value._custom.display;
	else if (type === "array") return `Array[${value.length}]`;
	else if (type === "plain-object") return `Object${Object.keys(value).length ? "" : " (empty)"}`;
	else if (type?.includes("native")) return escape(specialTypeRE.exec(value)?.[2]);
	else if (typeof value === "string") {
		const typeMatch = value.match(rawTypeRE);
		if (typeMatch) value = escapeString(typeMatch[1]);
		else if (quotes) value = `<span>"</span>${customClass?.string ? `<span class=${customClass.string}>${escapeString(value)}</span>` : escapeString(value)}<span>"</span>`;
		else value = customClass?.string ? `<span class="${customClass?.string ?? ""}">${escapeString(value)}</span>` : escapeString(value);
	}
	return value;
}
function escapeString(value) {
	return escape(value).replace(/ /g, "&nbsp;").replace(/\n/g, "<span>\\n</span>");
}
function getRaw(value) {
	let customType;
	const isCustom = getInspectorStateValueType(value) === "custom";
	let inherit = {};
	if (isCustom) {
		const data = value;
		const customValue = data._custom?.value;
		const currentCustomType = data._custom?.type;
		const nestedCustom = typeof customValue === "object" && customValue !== null && "_custom" in customValue ? getRaw(customValue) : {
			inherit: void 0,
			value: void 0,
			customType: void 0
		};
		inherit = nestedCustom.inherit || data._custom?.fields || {};
		value = nestedCustom.value || customValue;
		customType = nestedCustom.customType || currentCustomType;
	}
	if (value && value._isArray) value = value.items;
	return {
		value,
		inherit,
		customType
	};
}
function toEdit(value, customType) {
	if (customType === "bigint") return value;
	if (customType === "date") return value;
	return replaceTokenToString(JSON.stringify(value));
}
function toSubmit(value, customType) {
	if (customType === "bigint") return BigInt(value);
	if (customType === "date") return new Date(value);
	return JSON.parse(replaceStringToToken(value), reviver);
}
//#endregion
//#region src/core/devtools-client/detected.ts
function updateDevToolsClientDetected(params) {
	devtoolsState.devtoolsClientDetected = {
		...devtoolsState.devtoolsClientDetected,
		...params
	};
	toggleHighPerfMode(!Object.values(devtoolsState.devtoolsClientDetected).some(Boolean));
}
target.__VUE_DEVTOOLS_UPDATE_CLIENT_DETECTED__ ??= updateDevToolsClientDetected;
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/double-indexed-kv.js
var DoubleIndexedKV = class {
	constructor() {
		this.keyToValue = /* @__PURE__ */ new Map();
		this.valueToKey = /* @__PURE__ */ new Map();
	}
	set(key, value) {
		this.keyToValue.set(key, value);
		this.valueToKey.set(value, key);
	}
	getByKey(key) {
		return this.keyToValue.get(key);
	}
	getByValue(value) {
		return this.valueToKey.get(value);
	}
	clear() {
		this.keyToValue.clear();
		this.valueToKey.clear();
	}
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/registry.js
var Registry = class {
	constructor(generateIdentifier) {
		this.generateIdentifier = generateIdentifier;
		this.kv = new DoubleIndexedKV();
	}
	register(value, identifier) {
		if (this.kv.getByValue(value)) return;
		if (!identifier) identifier = this.generateIdentifier(value);
		this.kv.set(identifier, value);
	}
	clear() {
		this.kv.clear();
	}
	getIdentifier(value) {
		return this.kv.getByValue(value);
	}
	getValue(identifier) {
		return this.kv.getByKey(identifier);
	}
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/class-registry.js
var ClassRegistry = class extends Registry {
	constructor() {
		super((c) => c.name);
		this.classToAllowedProps = /* @__PURE__ */ new Map();
	}
	register(value, options) {
		if (typeof options === "object") {
			if (options.allowProps) this.classToAllowedProps.set(value, options.allowProps);
			super.register(value, options.identifier);
		} else super.register(value, options);
	}
	getAllowedProps(value) {
		return this.classToAllowedProps.get(value);
	}
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/util.js
function valuesOfObj(record) {
	if ("values" in Object) return Object.values(record);
	const values = [];
	for (const key in record) if (record.hasOwnProperty(key)) values.push(record[key]);
	return values;
}
function find(record, predicate) {
	const values = valuesOfObj(record);
	if ("find" in values) return values.find(predicate);
	const valuesNotNever = values;
	for (let i = 0; i < valuesNotNever.length; i++) {
		const value = valuesNotNever[i];
		if (predicate(value)) return value;
	}
}
function forEach(record, run) {
	Object.entries(record).forEach(([key, value]) => run(value, key));
}
function includes(arr, value) {
	return arr.indexOf(value) !== -1;
}
function findArr(record, predicate) {
	for (let i = 0; i < record.length; i++) {
		const value = record[i];
		if (predicate(value)) return value;
	}
}
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/custom-transformer-registry.js
var CustomTransformerRegistry = class {
	constructor() {
		this.transfomers = {};
	}
	register(transformer) {
		this.transfomers[transformer.name] = transformer;
	}
	findApplicable(v) {
		return find(this.transfomers, (transformer) => transformer.isApplicable(v));
	}
	findByName(name) {
		return this.transfomers[name];
	}
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/is.js
const getType$1 = (payload) => Object.prototype.toString.call(payload).slice(8, -1);
const isUndefined$1 = (payload) => typeof payload === "undefined";
const isNull$1 = (payload) => payload === null;
const isPlainObject$2 = (payload) => {
	if (typeof payload !== "object" || payload === null) return false;
	if (payload === Object.prototype) return false;
	if (Object.getPrototypeOf(payload) === null) return true;
	return Object.getPrototypeOf(payload) === Object.prototype;
};
const isEmptyObject = (payload) => isPlainObject$2(payload) && Object.keys(payload).length === 0;
const isArray$2 = (payload) => Array.isArray(payload);
const isString = (payload) => typeof payload === "string";
const isNumber = (payload) => typeof payload === "number" && !isNaN(payload);
const isBoolean = (payload) => typeof payload === "boolean";
const isRegExp = (payload) => payload instanceof RegExp;
const isMap = (payload) => payload instanceof Map;
const isSet = (payload) => payload instanceof Set;
const isSymbol = (payload) => getType$1(payload) === "Symbol";
const isDate = (payload) => payload instanceof Date && !isNaN(payload.valueOf());
const isError = (payload) => payload instanceof Error;
const isNaNValue = (payload) => typeof payload === "number" && isNaN(payload);
const isPrimitive = (payload) => isBoolean(payload) || isNull$1(payload) || isUndefined$1(payload) || isNumber(payload) || isString(payload) || isSymbol(payload);
const isBigint = (payload) => typeof payload === "bigint";
const isInfinite = (payload) => payload === Infinity || payload === -Infinity;
const isTypedArray = (payload) => ArrayBuffer.isView(payload) && !(payload instanceof DataView);
const isURL = (payload) => payload instanceof URL;
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/pathstringifier.js
const escapeKey = (key) => key.replace(/\./g, "\\.");
const stringifyPath = (path) => path.map(String).map(escapeKey).join(".");
const parsePath = (string) => {
	const result = [];
	let segment = "";
	for (let i = 0; i < string.length; i++) {
		let char = string.charAt(i);
		if (char === "\\" && string.charAt(i + 1) === ".") {
			segment += ".";
			i++;
			continue;
		}
		if (char === ".") {
			result.push(segment);
			segment = "";
			continue;
		}
		segment += char;
	}
	const lastSegment = segment;
	result.push(lastSegment);
	return result;
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/transformer.js
function simpleTransformation(isApplicable, annotation, transform, untransform) {
	return {
		isApplicable,
		annotation,
		transform,
		untransform
	};
}
const simpleRules = [
	simpleTransformation(isUndefined$1, "undefined", () => null, () => void 0),
	simpleTransformation(isBigint, "bigint", (v) => v.toString(), (v) => {
		if (typeof BigInt !== "undefined") return BigInt(v);
		console.error("Please add a BigInt polyfill.");
		return v;
	}),
	simpleTransformation(isDate, "Date", (v) => v.toISOString(), (v) => new Date(v)),
	simpleTransformation(isError, "Error", (v, superJson) => {
		const baseError = {
			name: v.name,
			message: v.message
		};
		superJson.allowedErrorProps.forEach((prop) => {
			baseError[prop] = v[prop];
		});
		return baseError;
	}, (v, superJson) => {
		const e = new Error(v.message);
		e.name = v.name;
		e.stack = v.stack;
		superJson.allowedErrorProps.forEach((prop) => {
			e[prop] = v[prop];
		});
		return e;
	}),
	simpleTransformation(isRegExp, "regexp", (v) => "" + v, (regex) => {
		const body = regex.slice(1, regex.lastIndexOf("/"));
		const flags = regex.slice(regex.lastIndexOf("/") + 1);
		return new RegExp(body, flags);
	}),
	simpleTransformation(isSet, "set", (v) => [...v.values()], (v) => new Set(v)),
	simpleTransformation(isMap, "map", (v) => [...v.entries()], (v) => new Map(v)),
	simpleTransformation((v) => isNaNValue(v) || isInfinite(v), "number", (v) => {
		if (isNaNValue(v)) return "NaN";
		if (v > 0) return "Infinity";
		else return "-Infinity";
	}, Number),
	simpleTransformation((v) => v === 0 && 1 / v === -Infinity, "number", () => {
		return "-0";
	}, Number),
	simpleTransformation(isURL, "URL", (v) => v.toString(), (v) => new URL(v))
];
function compositeTransformation(isApplicable, annotation, transform, untransform) {
	return {
		isApplicable,
		annotation,
		transform,
		untransform
	};
}
const symbolRule = compositeTransformation((s, superJson) => {
	if (isSymbol(s)) return !!superJson.symbolRegistry.getIdentifier(s);
	return false;
}, (s, superJson) => {
	return ["symbol", superJson.symbolRegistry.getIdentifier(s)];
}, (v) => v.description, (_, a, superJson) => {
	const value = superJson.symbolRegistry.getValue(a[1]);
	if (!value) throw new Error("Trying to deserialize unknown symbol");
	return value;
});
const constructorToName = [
	Int8Array,
	Uint8Array,
	Int16Array,
	Uint16Array,
	Int32Array,
	Uint32Array,
	Float32Array,
	Float64Array,
	Uint8ClampedArray
].reduce((obj, ctor) => {
	obj[ctor.name] = ctor;
	return obj;
}, {});
const typedArrayRule = compositeTransformation(isTypedArray, (v) => ["typed-array", v.constructor.name], (v) => [...v], (v, a) => {
	const ctor = constructorToName[a[1]];
	if (!ctor) throw new Error("Trying to deserialize unknown typed array");
	return new ctor(v);
});
function isInstanceOfRegisteredClass(potentialClass, superJson) {
	if (potentialClass?.constructor) return !!superJson.classRegistry.getIdentifier(potentialClass.constructor);
	return false;
}
const classRule = compositeTransformation(isInstanceOfRegisteredClass, (clazz, superJson) => {
	return ["class", superJson.classRegistry.getIdentifier(clazz.constructor)];
}, (clazz, superJson) => {
	const allowedProps = superJson.classRegistry.getAllowedProps(clazz.constructor);
	if (!allowedProps) return { ...clazz };
	const result = {};
	allowedProps.forEach((prop) => {
		result[prop] = clazz[prop];
	});
	return result;
}, (v, a, superJson) => {
	const clazz = superJson.classRegistry.getValue(a[1]);
	if (!clazz) throw new Error(`Trying to deserialize unknown class '${a[1]}' - check https://github.com/blitz-js/superjson/issues/116#issuecomment-773996564`);
	return Object.assign(Object.create(clazz.prototype), v);
});
const customRule = compositeTransformation((value, superJson) => {
	return !!superJson.customTransformerRegistry.findApplicable(value);
}, (value, superJson) => {
	return ["custom", superJson.customTransformerRegistry.findApplicable(value).name];
}, (value, superJson) => {
	return superJson.customTransformerRegistry.findApplicable(value).serialize(value);
}, (v, a, superJson) => {
	const transformer = superJson.customTransformerRegistry.findByName(a[1]);
	if (!transformer) throw new Error("Trying to deserialize unknown custom value");
	return transformer.deserialize(v);
});
const compositeRules = [
	classRule,
	symbolRule,
	customRule,
	typedArrayRule
];
const transformValue = (value, superJson) => {
	const applicableCompositeRule = findArr(compositeRules, (rule) => rule.isApplicable(value, superJson));
	if (applicableCompositeRule) return {
		value: applicableCompositeRule.transform(value, superJson),
		type: applicableCompositeRule.annotation(value, superJson)
	};
	const applicableSimpleRule = findArr(simpleRules, (rule) => rule.isApplicable(value, superJson));
	if (applicableSimpleRule) return {
		value: applicableSimpleRule.transform(value, superJson),
		type: applicableSimpleRule.annotation
	};
};
const simpleRulesByAnnotation = {};
simpleRules.forEach((rule) => {
	simpleRulesByAnnotation[rule.annotation] = rule;
});
const untransformValue = (json, type, superJson) => {
	if (isArray$2(type)) switch (type[0]) {
		case "symbol": return symbolRule.untransform(json, type, superJson);
		case "class": return classRule.untransform(json, type, superJson);
		case "custom": return customRule.untransform(json, type, superJson);
		case "typed-array": return typedArrayRule.untransform(json, type, superJson);
		default: throw new Error("Unknown transformation: " + type);
	}
	else {
		const transformation = simpleRulesByAnnotation[type];
		if (!transformation) throw new Error("Unknown transformation: " + type);
		return transformation.untransform(json, superJson);
	}
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/accessDeep.js
const getNthKey = (value, n) => {
	if (n > value.size) throw new Error("index out of bounds");
	const keys = value.keys();
	while (n > 0) {
		keys.next();
		n--;
	}
	return keys.next().value;
};
function validatePath(path) {
	if (includes(path, "__proto__")) throw new Error("__proto__ is not allowed as a property");
	if (includes(path, "prototype")) throw new Error("prototype is not allowed as a property");
	if (includes(path, "constructor")) throw new Error("constructor is not allowed as a property");
}
const getDeep = (object, path) => {
	validatePath(path);
	for (let i = 0; i < path.length; i++) {
		const key = path[i];
		if (isSet(object)) object = getNthKey(object, +key);
		else if (isMap(object)) {
			const row = +key;
			const type = +path[++i] === 0 ? "key" : "value";
			const keyOfRow = getNthKey(object, row);
			switch (type) {
				case "key":
					object = keyOfRow;
					break;
				case "value":
					object = object.get(keyOfRow);
					break;
			}
		} else object = object[key];
	}
	return object;
};
const setDeep = (object, path, mapper) => {
	validatePath(path);
	if (path.length === 0) return mapper(object);
	let parent = object;
	for (let i = 0; i < path.length - 1; i++) {
		const key = path[i];
		if (isArray$2(parent)) {
			const index = +key;
			parent = parent[index];
		} else if (isPlainObject$2(parent)) parent = parent[key];
		else if (isSet(parent)) {
			const row = +key;
			parent = getNthKey(parent, row);
		} else if (isMap(parent)) {
			if (i === path.length - 2) break;
			const row = +key;
			const type = +path[++i] === 0 ? "key" : "value";
			const keyOfRow = getNthKey(parent, row);
			switch (type) {
				case "key":
					parent = keyOfRow;
					break;
				case "value":
					parent = parent.get(keyOfRow);
					break;
			}
		}
	}
	const lastKey = path[path.length - 1];
	if (isArray$2(parent)) parent[+lastKey] = mapper(parent[+lastKey]);
	else if (isPlainObject$2(parent)) parent[lastKey] = mapper(parent[lastKey]);
	if (isSet(parent)) {
		const oldValue = getNthKey(parent, +lastKey);
		const newValue = mapper(oldValue);
		if (oldValue !== newValue) {
			parent.delete(oldValue);
			parent.add(newValue);
		}
	}
	if (isMap(parent)) {
		const row = +path[path.length - 2];
		const keyToRow = getNthKey(parent, row);
		switch (+lastKey === 0 ? "key" : "value") {
			case "key": {
				const newKey = mapper(keyToRow);
				parent.set(newKey, parent.get(keyToRow));
				if (newKey !== keyToRow) parent.delete(keyToRow);
				break;
			}
			case "value":
				parent.set(keyToRow, mapper(parent.get(keyToRow)));
				break;
		}
	}
	return object;
};
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/plainer.js
function traverse(tree, walker, origin = []) {
	if (!tree) return;
	if (!isArray$2(tree)) {
		forEach(tree, (subtree, key) => traverse(subtree, walker, [...origin, ...parsePath(key)]));
		return;
	}
	const [nodeValue, children] = tree;
	if (children) forEach(children, (child, key) => {
		traverse(child, walker, [...origin, ...parsePath(key)]);
	});
	walker(nodeValue, origin);
}
function applyValueAnnotations(plain, annotations, superJson) {
	traverse(annotations, (type, path) => {
		plain = setDeep(plain, path, (v) => untransformValue(v, type, superJson));
	});
	return plain;
}
function applyReferentialEqualityAnnotations(plain, annotations) {
	function apply(identicalPaths, path) {
		const object = getDeep(plain, parsePath(path));
		identicalPaths.map(parsePath).forEach((identicalObjectPath) => {
			plain = setDeep(plain, identicalObjectPath, () => object);
		});
	}
	if (isArray$2(annotations)) {
		const [root, other] = annotations;
		root.forEach((identicalPath) => {
			plain = setDeep(plain, parsePath(identicalPath), () => plain);
		});
		if (other) forEach(other, apply);
	} else forEach(annotations, apply);
	return plain;
}
const isDeep = (object, superJson) => isPlainObject$2(object) || isArray$2(object) || isMap(object) || isSet(object) || isInstanceOfRegisteredClass(object, superJson);
function addIdentity(object, path, identities) {
	const existingSet = identities.get(object);
	if (existingSet) existingSet.push(path);
	else identities.set(object, [path]);
}
function generateReferentialEqualityAnnotations(identitites, dedupe) {
	const result = {};
	let rootEqualityPaths = void 0;
	identitites.forEach((paths) => {
		if (paths.length <= 1) return;
		if (!dedupe) paths = paths.map((path) => path.map(String)).sort((a, b) => a.length - b.length);
		const [representativePath, ...identicalPaths] = paths;
		if (representativePath.length === 0) rootEqualityPaths = identicalPaths.map(stringifyPath);
		else result[stringifyPath(representativePath)] = identicalPaths.map(stringifyPath);
	});
	if (rootEqualityPaths) if (isEmptyObject(result)) return [rootEqualityPaths];
	else return [rootEqualityPaths, result];
	else return isEmptyObject(result) ? void 0 : result;
}
const walker = (object, identities, superJson, dedupe, path = [], objectsInThisPath = [], seenObjects = /* @__PURE__ */ new Map()) => {
	const primitive = isPrimitive(object);
	if (!primitive) {
		addIdentity(object, path, identities);
		const seen = seenObjects.get(object);
		if (seen) return dedupe ? { transformedValue: null } : seen;
	}
	if (!isDeep(object, superJson)) {
		const transformed = transformValue(object, superJson);
		const result = transformed ? {
			transformedValue: transformed.value,
			annotations: [transformed.type]
		} : { transformedValue: object };
		if (!primitive) seenObjects.set(object, result);
		return result;
	}
	if (includes(objectsInThisPath, object)) return { transformedValue: null };
	const transformationResult = transformValue(object, superJson);
	const transformed = transformationResult?.value ?? object;
	const transformedValue = isArray$2(transformed) ? [] : {};
	const innerAnnotations = {};
	forEach(transformed, (value, index) => {
		if (index === "__proto__" || index === "constructor" || index === "prototype") throw new Error(`Detected property ${index}. This is a prototype pollution risk, please remove it from your object.`);
		const recursiveResult = walker(value, identities, superJson, dedupe, [...path, index], [...objectsInThisPath, object], seenObjects);
		transformedValue[index] = recursiveResult.transformedValue;
		if (isArray$2(recursiveResult.annotations)) innerAnnotations[index] = recursiveResult.annotations;
		else if (isPlainObject$2(recursiveResult.annotations)) forEach(recursiveResult.annotations, (tree, key) => {
			innerAnnotations[escapeKey(index) + "." + key] = tree;
		});
	});
	const result = isEmptyObject(innerAnnotations) ? {
		transformedValue,
		annotations: !!transformationResult ? [transformationResult.type] : void 0
	} : {
		transformedValue,
		annotations: !!transformationResult ? [transformationResult.type, innerAnnotations] : innerAnnotations
	};
	if (!primitive) seenObjects.set(object, result);
	return result;
};
//#endregion
//#region ../../node_modules/.pnpm/is-what@4.1.16/node_modules/is-what/dist/index.js
function getType(payload) {
	return Object.prototype.toString.call(payload).slice(8, -1);
}
function isArray$1(payload) {
	return getType(payload) === "Array";
}
function isPlainObject$1(payload) {
	if (getType(payload) !== "Object") return false;
	const prototype = Object.getPrototypeOf(payload);
	return !!prototype && prototype.constructor === Object && prototype === Object.prototype;
}
function isNull(payload) {
	return getType(payload) === "Null";
}
function isOneOf(a, b, c, d, e) {
	return (value) => a(value) || b(value) || !!c && c(value) || !!d && d(value) || !!e && e(value);
}
function isUndefined(payload) {
	return getType(payload) === "Undefined";
}
isOneOf(isNull, isUndefined);
//#endregion
//#region ../../node_modules/.pnpm/copy-anything@3.0.5/node_modules/copy-anything/dist/index.js
function assignProp(carry, key, newVal, originalObject, includeNonenumerable) {
	const propType = {}.propertyIsEnumerable.call(originalObject, key) ? "enumerable" : "nonenumerable";
	if (propType === "enumerable") carry[key] = newVal;
	if (includeNonenumerable && propType === "nonenumerable") Object.defineProperty(carry, key, {
		value: newVal,
		enumerable: false,
		writable: true,
		configurable: true
	});
}
function copy(target, options = {}) {
	if (isArray$1(target)) return target.map((item) => copy(item, options));
	if (!isPlainObject$1(target)) return target;
	const props = Object.getOwnPropertyNames(target);
	const symbols = Object.getOwnPropertySymbols(target);
	return [...props, ...symbols].reduce((carry, key) => {
		if (isArray$1(options.props) && !options.props.includes(key)) return carry;
		const val = target[key];
		assignProp(carry, key, copy(val, options), target, options.nonenumerable);
		return carry;
	}, {});
}
//#endregion
//#region ../../node_modules/.pnpm/superjson@2.2.2/node_modules/superjson/dist/index.js
var SuperJSON = class {
	/**
	* @param dedupeReferentialEqualities  If true, SuperJSON will make sure only one instance of referentially equal objects are serialized and the rest are replaced with `null`.
	*/
	constructor({ dedupe = false } = {}) {
		this.classRegistry = new ClassRegistry();
		this.symbolRegistry = new Registry((s) => s.description ?? "");
		this.customTransformerRegistry = new CustomTransformerRegistry();
		this.allowedErrorProps = [];
		this.dedupe = dedupe;
	}
	serialize(object) {
		const identities = /* @__PURE__ */ new Map();
		const output = walker(object, identities, this, this.dedupe);
		const res = { json: output.transformedValue };
		if (output.annotations) res.meta = {
			...res.meta,
			values: output.annotations
		};
		const equalityAnnotations = generateReferentialEqualityAnnotations(identities, this.dedupe);
		if (equalityAnnotations) res.meta = {
			...res.meta,
			referentialEqualities: equalityAnnotations
		};
		return res;
	}
	deserialize(payload) {
		const { json, meta } = payload;
		let result = copy(json);
		if (meta?.values) result = applyValueAnnotations(result, meta.values, this);
		if (meta?.referentialEqualities) result = applyReferentialEqualityAnnotations(result, meta.referentialEqualities);
		return result;
	}
	stringify(object) {
		return JSON.stringify(this.serialize(object));
	}
	parse(string) {
		return this.deserialize(JSON.parse(string));
	}
	registerClass(v, options) {
		this.classRegistry.register(v, options);
	}
	registerSymbol(v, identifier) {
		this.symbolRegistry.register(v, identifier);
	}
	registerCustom(transformer, name) {
		this.customTransformerRegistry.register({
			name,
			...transformer
		});
	}
	allowErrorProps(...props) {
		this.allowedErrorProps.push(...props);
	}
};
SuperJSON.defaultInstance = new SuperJSON();
SuperJSON.serialize = SuperJSON.defaultInstance.serialize.bind(SuperJSON.defaultInstance);
SuperJSON.deserialize = SuperJSON.defaultInstance.deserialize.bind(SuperJSON.defaultInstance);
SuperJSON.stringify = SuperJSON.defaultInstance.stringify.bind(SuperJSON.defaultInstance);
SuperJSON.parse = SuperJSON.defaultInstance.parse.bind(SuperJSON.defaultInstance);
SuperJSON.registerClass = SuperJSON.defaultInstance.registerClass.bind(SuperJSON.defaultInstance);
SuperJSON.registerSymbol = SuperJSON.defaultInstance.registerSymbol.bind(SuperJSON.defaultInstance);
SuperJSON.registerCustom = SuperJSON.defaultInstance.registerCustom.bind(SuperJSON.defaultInstance);
SuperJSON.allowErrorProps = SuperJSON.defaultInstance.allowErrorProps.bind(SuperJSON.defaultInstance);
SuperJSON.serialize;
SuperJSON.deserialize;
SuperJSON.stringify;
SuperJSON.parse;
SuperJSON.registerClass;
SuperJSON.registerCustom;
SuperJSON.registerSymbol;
SuperJSON.allowErrorProps;
//#endregion
//#region src/messaging/presets/broadcast-channel/context.ts
const __DEVTOOLS_KIT_BROADCAST_MESSAGING_EVENT_KEY = "__devtools-kit-broadcast-messaging-event-key__";
//#endregion
//#region src/messaging/presets/broadcast-channel/index.ts
const BROADCAST_CHANNEL_NAME = "__devtools-kit:broadcast-channel__";
function createBroadcastChannel() {
	const channel = new BroadcastChannel(BROADCAST_CHANNEL_NAME);
	return {
		post: (data) => {
			channel.postMessage(SuperJSON.stringify({
				event: __DEVTOOLS_KIT_BROADCAST_MESSAGING_EVENT_KEY,
				data
			}));
		},
		on: (handler) => {
			channel.onmessage = (event) => {
				const parsed = SuperJSON.parse(event.data);
				if (parsed.event === "__devtools-kit-broadcast-messaging-event-key__") handler(parsed.data);
			};
		}
	};
}
//#endregion
//#region src/messaging/presets/electron/context.ts
const __ELECTRON_CLIENT_CONTEXT__ = "electron:client-context";
const __ELECTRON_RPOXY_CONTEXT__ = "electron:proxy-context";
const __ELECTRON_SERVER_CONTEXT__ = "electron:server-context";
const __DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__ = {
	CLIENT_TO_PROXY: "client->proxy",
	PROXY_TO_CLIENT: "proxy->client",
	PROXY_TO_SERVER: "proxy->server",
	SERVER_TO_PROXY: "server->proxy"
};
function getElectronClientContext() {
	return target[__ELECTRON_CLIENT_CONTEXT__];
}
function setElectronClientContext(context) {
	target[__ELECTRON_CLIENT_CONTEXT__] = context;
}
function getElectronProxyContext() {
	return target[__ELECTRON_RPOXY_CONTEXT__];
}
function setElectronProxyContext(context) {
	target[__ELECTRON_RPOXY_CONTEXT__] = context;
}
function getElectronServerContext() {
	return target[__ELECTRON_SERVER_CONTEXT__];
}
function setElectronServerContext(context) {
	target[__ELECTRON_SERVER_CONTEXT__] = context;
}
//#endregion
//#region src/messaging/presets/electron/client.ts
function createElectronClientChannel() {
	const socket = getElectronClientContext();
	return {
		post: (data) => {
			socket.emit(__DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__.CLIENT_TO_PROXY, SuperJSON.stringify(data));
		},
		on: (handler) => {
			socket.on(__DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__.PROXY_TO_CLIENT, (e) => {
				handler(SuperJSON.parse(e));
			});
		}
	};
}
//#endregion
//#region src/messaging/presets/electron/proxy.ts
function createElectronProxyChannel() {
	const socket = getElectronProxyContext();
	return {
		post: (data) => {},
		on: (handler) => {
			socket.on(__DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__.SERVER_TO_PROXY, (data) => {
				socket.broadcast.emit(__DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__.PROXY_TO_CLIENT, data);
			});
			socket.on(__DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__.CLIENT_TO_PROXY, (data) => {
				socket.broadcast.emit(__DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__.PROXY_TO_SERVER, data);
			});
		}
	};
}
//#endregion
//#region src/messaging/presets/electron/server.ts
function createElectronServerChannel() {
	const socket = getElectronServerContext();
	return {
		post: (data) => {
			socket.emit(__DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__.SERVER_TO_PROXY, SuperJSON.stringify(data));
		},
		on: (handler) => {
			socket.on(__DEVTOOLS_KIT_ELECTRON_MESSAGING_EVENT_KEY__.PROXY_TO_SERVER, (data) => {
				handler(SuperJSON.parse(data));
			});
		}
	};
}
//#endregion
//#region src/messaging/presets/extension/context.ts
const __EXTENSION_CLIENT_CONTEXT__ = "electron:client-context";
const __DEVTOOLS_KIT_EXTENSION_MESSAGING_EVENT_KEY__ = {
	CLIENT_TO_PROXY: "client->proxy",
	PROXY_TO_CLIENT: "proxy->client",
	PROXY_TO_SERVER: "proxy->server",
	SERVER_TO_PROXY: "server->proxy"
};
function getExtensionClientContext() {
	return target[__EXTENSION_CLIENT_CONTEXT__];
}
function setExtensionClientContext(context) {
	target[__EXTENSION_CLIENT_CONTEXT__] = context;
}
//#endregion
//#region src/messaging/presets/extension/client.ts
function createExtensionClientChannel() {
	let disconnected = false;
	let port = null;
	let reconnectTimer = null;
	let onMessageHandler = null;
	function connect() {
		try {
			clearTimeout(reconnectTimer);
			port = chrome.runtime.connect({ name: `${chrome.devtools.inspectedWindow.tabId}` });
			setExtensionClientContext(port);
			disconnected = false;
			port?.onMessage.addListener(onMessageHandler);
			port.onDisconnect.addListener(() => {
				disconnected = true;
				port?.onMessage.removeListener(onMessageHandler);
				reconnectTimer = setTimeout(connect, 1e3);
			});
		} catch (e) {
			disconnected = true;
		}
	}
	connect();
	return {
		post: (data) => {
			if (disconnected) return;
			port?.postMessage(SuperJSON.stringify(data));
		},
		on: (handler) => {
			onMessageHandler = (data) => {
				if (disconnected) return;
				handler(SuperJSON.parse(data));
			};
			port?.onMessage.addListener(onMessageHandler);
		}
	};
}
//#endregion
//#region src/messaging/presets/extension/proxy.ts
function createExtensionProxyChannel() {
	const port = chrome.runtime.connect({ name: "content-script" });
	function sendMessageToUserApp(payload) {
		window.postMessage({
			source: __DEVTOOLS_KIT_EXTENSION_MESSAGING_EVENT_KEY__.PROXY_TO_SERVER,
			payload
		}, "*");
	}
	function sendMessageToDevToolsClient(e) {
		if (e.data && e.data.source === __DEVTOOLS_KIT_EXTENSION_MESSAGING_EVENT_KEY__.SERVER_TO_PROXY) try {
			port.postMessage(e.data.payload);
		} catch (e) {}
	}
	port.onMessage.addListener(sendMessageToUserApp);
	window.addEventListener("message", sendMessageToDevToolsClient);
	port.onDisconnect.addListener(() => {
		window.removeEventListener("message", sendMessageToDevToolsClient);
		sendMessageToUserApp(SuperJSON.stringify({ event: "shutdown" }));
	});
	sendMessageToUserApp(SuperJSON.stringify({ event: "init" }));
	return {
		post: (data) => {},
		on: (handler) => {}
	};
}
//#endregion
//#region src/messaging/presets/extension/server.ts
function createExtensionServerChannel() {
	return {
		post: (data) => {
			window.postMessage({
				source: __DEVTOOLS_KIT_EXTENSION_MESSAGING_EVENT_KEY__.SERVER_TO_PROXY,
				payload: SuperJSON.stringify(data)
			}, "*");
		},
		on: (handler) => {
			const listener = (event) => {
				if (event.data.source === __DEVTOOLS_KIT_EXTENSION_MESSAGING_EVENT_KEY__.PROXY_TO_SERVER && event.data.payload) handler(SuperJSON.parse(event.data.payload));
			};
			window.addEventListener("message", listener);
			return () => {
				window.removeEventListener("message", listener);
			};
		}
	};
}
//#endregion
//#region src/messaging/presets/iframe/context.ts
const __DEVTOOLS_KIT_IFRAME_MESSAGING_EVENT_KEY = "__devtools-kit-iframe-messaging-event-key__";
const __IFRAME_SERVER_CONTEXT__ = "iframe:server-context";
function getIframeServerContext() {
	return target[__IFRAME_SERVER_CONTEXT__];
}
function setIframeServerContext(context) {
	target[__IFRAME_SERVER_CONTEXT__] = context;
}
//#endregion
//#region src/messaging/presets/iframe/client.ts
function createIframeClientChannel() {
	if (!isBrowser) return {
		post: (data) => {},
		on: (handler) => {}
	};
	return {
		post: (data) => window.parent.postMessage(SuperJSON.stringify({
			event: __DEVTOOLS_KIT_IFRAME_MESSAGING_EVENT_KEY,
			data
		}), "*"),
		on: (handler) => window.addEventListener("message", (event) => {
			try {
				const parsed = SuperJSON.parse(event.data);
				if (event.source === window.parent && parsed.event === "__devtools-kit-iframe-messaging-event-key__") handler(parsed.data);
			} catch (e) {}
		})
	};
}
//#endregion
//#region src/messaging/presets/iframe/server.ts
function createIframeServerChannel() {
	if (!isBrowser) return {
		post: (data) => {},
		on: (handler) => {}
	};
	return {
		post: (data) => {
			getIframeServerContext()?.contentWindow?.postMessage(SuperJSON.stringify({
				event: __DEVTOOLS_KIT_IFRAME_MESSAGING_EVENT_KEY,
				data
			}), "*");
		},
		on: (handler) => {
			window.addEventListener("message", (event) => {
				const iframe = getIframeServerContext();
				try {
					const parsed = SuperJSON.parse(event.data);
					if (event.source === iframe?.contentWindow && parsed.event === "__devtools-kit-iframe-messaging-event-key__") handler(parsed.data);
				} catch (e) {}
			});
		}
	};
}
//#endregion
//#region src/messaging/presets/vite/context.ts
const __DEVTOOLS_KIT_VITE_MESSAGING_EVENT_KEY = "__devtools-kit-vite-messaging-event-key__";
const __VITE_CLIENT_CONTEXT__ = "vite:client-context";
const __VITE_SERVER_CONTEXT__ = "vite:server-context";
function getViteClientContext() {
	return target[__VITE_CLIENT_CONTEXT__];
}
function setViteClientContext(context) {
	target[__VITE_CLIENT_CONTEXT__] = context;
}
function getViteServerContext() {
	return target[__VITE_SERVER_CONTEXT__];
}
function setViteServerContext(context) {
	target[__VITE_SERVER_CONTEXT__] = context;
}
//#endregion
//#region src/messaging/presets/vite/client.ts
function createViteClientChannel() {
	const client = getViteClientContext();
	return {
		post: (data) => {
			client?.send(__DEVTOOLS_KIT_VITE_MESSAGING_EVENT_KEY, SuperJSON.stringify(data));
		},
		on: (handler) => {
			client?.on(__DEVTOOLS_KIT_VITE_MESSAGING_EVENT_KEY, (event) => {
				handler(SuperJSON.parse(event));
			});
		}
	};
}
//#endregion
//#region src/messaging/presets/vite/server.ts
function createViteServerChannel() {
	const viteServer = getViteServerContext();
	const ws = viteServer.hot ?? viteServer.ws;
	return {
		post: (data) => ws?.send(__DEVTOOLS_KIT_VITE_MESSAGING_EVENT_KEY, SuperJSON.stringify(data)),
		on: (handler) => ws?.on(__DEVTOOLS_KIT_VITE_MESSAGING_EVENT_KEY, (event) => {
			handler(SuperJSON.parse(event));
		})
	};
}
//#endregion
//#region src/messaging/index.ts
target.__VUE_DEVTOOLS_KIT_MESSAGE_CHANNELS__ ??= [];
target.__VUE_DEVTOOLS_KIT_RPC_CLIENT__ ??= null;
target.__VUE_DEVTOOLS_KIT_RPC_SERVER__ ??= null;
target.__VUE_DEVTOOLS_KIT_VITE_RPC_CLIENT__ ??= null;
target.__VUE_DEVTOOLS_KIT_VITE_RPC_SERVER__ ??= null;
target.__VUE_DEVTOOLS_KIT_BROADCAST_RPC_SERVER__ ??= null;
function setRpcClientToGlobal(rpc) {
	target.__VUE_DEVTOOLS_KIT_RPC_CLIENT__ = rpc;
}
function setRpcServerToGlobal(rpc) {
	target.__VUE_DEVTOOLS_KIT_RPC_SERVER__ = rpc;
}
function getRpcClient() {
	return target.__VUE_DEVTOOLS_KIT_RPC_CLIENT__;
}
function getRpcServer() {
	return target.__VUE_DEVTOOLS_KIT_RPC_SERVER__;
}
function setViteRpcClientToGlobal(rpc) {
	target.__VUE_DEVTOOLS_KIT_VITE_RPC_CLIENT__ = rpc;
}
function setViteRpcServerToGlobal(rpc) {
	target.__VUE_DEVTOOLS_KIT_VITE_RPC_SERVER__ = rpc;
}
function getViteRpcClient() {
	return target.__VUE_DEVTOOLS_KIT_VITE_RPC_CLIENT__;
}
function getViteRpcServer() {
	return target.__VUE_DEVTOOLS_KIT_VITE_RPC_SERVER__;
}
function getChannel(preset, host = "client") {
	const channel = {
		iframe: {
			client: createIframeClientChannel,
			server: createIframeServerChannel
		}[host],
		electron: {
			client: createElectronClientChannel,
			proxy: createElectronProxyChannel,
			server: createElectronServerChannel
		}[host],
		vite: {
			client: createViteClientChannel,
			server: createViteServerChannel
		}[host],
		broadcast: {
			client: createBroadcastChannel,
			server: createBroadcastChannel
		}[host],
		extension: {
			client: createExtensionClientChannel,
			proxy: createExtensionProxyChannel,
			server: createExtensionServerChannel
		}[host]
	}[preset];
	return channel();
}
function createRpcClient(functions, options = {}) {
	const { channel: _channel, options: _options, preset } = options;
	const channel = preset ? getChannel(preset) : _channel;
	const rpc = createBirpc(functions, {
		..._options,
		...channel,
		timeout: -1
	});
	if (preset === "vite") {
		setViteRpcClientToGlobal(rpc);
		return;
	}
	setRpcClientToGlobal(rpc);
	return rpc;
}
function createRpcServer(functions, options = {}) {
	const { channel: _channel, options: _options, preset } = options;
	const channel = preset ? getChannel(preset, "server") : _channel;
	const rpcServer = getRpcServer();
	if (!rpcServer) {
		const group = createBirpcGroup(functions, [channel], {
			..._options,
			timeout: -1
		});
		if (preset === "vite") {
			setViteRpcServerToGlobal(group);
			return;
		}
		setRpcServerToGlobal(group);
	} else rpcServer.updateChannels((channels) => {
		channels.push(channel);
	});
}
function createRpcProxy(options = {}) {
	const { channel: _channel, options: _options, preset } = options;
	const channel = preset ? getChannel(preset, "proxy") : _channel;
	return createBirpc({}, {
		..._options,
		...channel,
		timeout: -1
	});
}
//#endregion
//#region src/core/component/state/custom.ts
function getFunctionDetails(func) {
	let string = "";
	let matches = null;
	try {
		string = Function.prototype.toString.call(func);
		matches = String.prototype.match.call(string, /\([\s\S]*?\)/);
	} catch (e) {}
	const match = matches && matches[0];
	const args = typeof match === "string" ? match : "(?)";
	return { _custom: {
		type: "function",
		displayText: `<span style="opacity:.8;margin-right:5px;">function</span> <span style="white-space:nowrap;">${escape(typeof func.name === "string" ? func.name : "")}${args}</span>`,
		tooltipText: string.trim() ? `<pre>${escape(string)}</pre>` : null
	} };
}
function getBigIntDetails(val) {
	const stringifiedBigInt = BigInt.prototype.toString.call(val);
	return { _custom: {
		type: "bigint",
		displayText: `BigInt(${stringifiedBigInt})`,
		value: stringifiedBigInt
	} };
}
function getDateDetails(val) {
	const date = new Date(val.getTime());
	date.setMinutes(date.getMinutes() - date.getTimezoneOffset());
	return { _custom: {
		type: "date",
		displayText: Date.prototype.toString.call(val),
		value: date.toISOString().slice(0, -1)
	} };
}
function getMapDetails(val) {
	return { _custom: {
		type: "map",
		displayText: "Map",
		value: Object.fromEntries(val),
		readOnly: true,
		fields: { abstract: true }
	} };
}
function getSetDetails(val) {
	const list = Array.from(val);
	return { _custom: {
		type: "set",
		displayText: `Set[${list.length}]`,
		value: list,
		readOnly: true
	} };
}
function getCaughtGetters(store) {
	const getters = {};
	const origGetters = store.getters || {};
	const keys = Object.keys(origGetters);
	for (let i = 0; i < keys.length; i++) {
		const key = keys[i];
		Object.defineProperty(getters, key, {
			enumerable: true,
			get: () => {
				try {
					return origGetters[key];
				} catch (e) {
					return e;
				}
			}
		});
	}
	return getters;
}
function reduceStateList(list) {
	if (!list.length) return void 0;
	return list.reduce((map, item) => {
		const key = item.type || "data";
		const obj = map[key] = map[key] || {};
		obj[item.key] = item.value;
		return map;
	}, {});
}
function namedNodeMapToObject(map) {
	const result = {};
	const l = map.length;
	for (let i = 0; i < l; i++) {
		const node = map.item(i);
		result[node.name] = node.value;
	}
	return result;
}
function getStoreDetails(store) {
	return { _custom: {
		type: "store",
		displayText: "Store",
		value: {
			state: store.state,
			getters: getCaughtGetters(store)
		},
		fields: { abstract: true }
	} };
}
function getInstanceDetails(instance) {
	if (instance._) instance = instance._;
	const state = processInstanceState(instance);
	return { _custom: {
		type: "component",
		id: instance.__VUE_DEVTOOLS_NEXT_UID__,
		displayText: getInstanceName(instance),
		tooltipText: "Component instance",
		value: reduceStateList(state),
		fields: { abstract: true }
	} };
}
function getComponentDefinitionDetails(definition) {
	let display = getComponentName(definition);
	if (display) {
		if (definition.name && definition.__file) display += ` <span>(${definition.__file})</span>`;
	} else display = "<i>Unknown Component</i>";
	return { _custom: {
		type: "component-definition",
		displayText: display,
		tooltipText: "Component definition",
		...definition.__file ? { file: definition.__file } : {}
	} };
}
function getHTMLElementDetails(value) {
	try {
		return { _custom: {
			type: "HTMLElement",
			displayText: `<span class="opacity-30">&lt;</span><span class="text-blue-500">${value.tagName.toLowerCase()}</span><span class="opacity-30">&gt;</span>`,
			value: namedNodeMapToObject(value.attributes)
		} };
	} catch (e) {
		return { _custom: {
			type: "HTMLElement",
			displayText: `<span class="text-blue-500">${String(value)}</span>`
		} };
	}
}
/**
* - ObjectRefImpl, toRef({ foo: 'foo' }, 'foo'), `_value` is the actual value, (since 3.5.0)
* - GetterRefImpl, toRef(() => state.foo), `_value` is the actual value, (since 3.5.0)
* - RefImpl, ref('foo') / computed(() => 'foo'), `_value` is the actual value
*/
function tryGetRefValue(ref) {
	if (ensurePropertyExists(ref, "_value", true)) return ref._value;
	if (ensurePropertyExists(ref, "value", true)) return ref.value;
}
function getObjectDetails(object) {
	const info = getSetupStateType(object);
	if (info.ref || info.computed || info.reactive) {
		const stateTypeName = info.computed ? "Computed" : info.ref ? "Ref" : info.reactive ? "Reactive" : null;
		const value = toRaw(info.reactive ? object : tryGetRefValue(object));
		const raw = ensurePropertyExists(object, "effect") ? object.effect?.raw?.toString() || object.effect?.fn?.toString() : null;
		return { _custom: {
			type: stateTypeName?.toLowerCase(),
			stateTypeName,
			value,
			...raw ? { tooltipText: `<pre>${escape(raw)}</pre>` } : {}
		} };
	}
	if (ensurePropertyExists(object, "__asyncLoader") && typeof object.__asyncLoader === "function") return { _custom: {
		type: "component-definition",
		display: "Async component definition"
	} };
}
//#endregion
//#region src/core/component/state/replacer.ts
function stringifyReplacer(key, _value, depth, seenInstance) {
	if (key === "compilerOptions") return;
	const val = this[key];
	const type = typeof val;
	if (Array.isArray(val)) {
		const l = val.length;
		if (l > 5e3) return {
			_isArray: true,
			length: l,
			items: val.slice(0, MAX_ARRAY_SIZE)
		};
		return val;
	} else if (typeof val === "string") if (val.length > 1e4) return `${val.substring(0, MAX_STRING_SIZE)}... (${val.length} total length)`;
	else return val;
	else if (type === "undefined") return UNDEFINED;
	else if (val === Number.POSITIVE_INFINITY) return INFINITY;
	else if (val === Number.NEGATIVE_INFINITY) return NEGATIVE_INFINITY;
	else if (typeof val === "function") return getFunctionDetails(val);
	else if (type === "symbol") return `[native Symbol ${Symbol.prototype.toString.call(val)}]`;
	else if (typeof val === "bigint") return getBigIntDetails(val);
	else if (val !== null && typeof val === "object") {
		const proto = Object.prototype.toString.call(val);
		if (proto === "[object Map]") return getMapDetails(val);
		else if (proto === "[object Set]") return getSetDetails(val);
		else if (proto === "[object RegExp]") return `[native RegExp ${RegExp.prototype.toString.call(val)}]`;
		else if (proto === "[object Date]") return getDateDetails(val);
		else if (proto === "[object Error]") return `[native Error ${val.message}<>${val.stack}]`;
		else if (ensurePropertyExists(val, "state", true) && ensurePropertyExists(val, "_vm", true)) return getStoreDetails(val);
		else if (isVueInstance(val)) {
			const componentVal = getInstanceDetails(val);
			const parentInstanceDepth = seenInstance?.get(val);
			if (parentInstanceDepth && parentInstanceDepth < depth) return `[[CircularRef]] <${componentVal._custom.displayText}>`;
			seenInstance?.set(val, depth);
			return componentVal;
		} else if (ensurePropertyExists(val, "render", true) && typeof val.render === "function") return getComponentDefinitionDetails(val);
		else if (val.constructor && val.constructor.name === "VNode") return `[native VNode <${val.tag}>]`;
		else if (typeof HTMLElement !== "undefined" && val instanceof HTMLElement) return getHTMLElementDetails(val);
		else if (val.constructor?.name === "Store" && "_wrappedGetters" in val) return "[object Store]";
		const customDetails = getObjectDetails(val);
		if (customDetails != null) return customDetails;
	} else if (Number.isNaN(val)) return NAN;
	return sanitize(val);
}
//#endregion
//#region src/shared/transfer.ts
const MAX_SERIALIZED_SIZE = 2 * 1024 * 1024;
function isObject(_data, proto) {
	return proto === "[object Object]";
}
function isArray(_data, proto) {
	return proto === "[object Array]";
}
function isVueReactiveLinkNode(node) {
	const constructorName = node?.constructor?.name;
	return constructorName === "Dep" && "activeLink" in node || constructorName === "Link" && "dep" in node;
}
/**
* This function is used to serialize object with handling circular references.
*
* ```ts
* const obj = { a: 1, b: { c: 2 }, d: obj }
* const result = stringifyCircularAutoChunks(obj) // call `encode` inside
* console.log(result) // [{"a":1,"b":2,"d":0},1,{"c":4},2]
* ```
*
* Each object is stored in a list and the index is used to reference the object.
* With seen map, we can check if the object is already stored in the list to avoid circular references.
*
* Note: here we have a special case for Vue instance.
* We check if a vue instance includes itself in its properties and skip it
* by using `seenVueInstance` and `depth` to avoid infinite loop.
*/
function encode(data, replacer, list, seen, depth = 0, seenVueInstance = /* @__PURE__ */ new Map()) {
	let stored;
	let key;
	let value;
	let i;
	let l;
	const seenIndex = seen.get(data);
	if (seenIndex != null) return seenIndex;
	const index = list.length;
	const proto = Object.prototype.toString.call(data);
	if (isObject(data, proto)) {
		if (isVueReactiveLinkNode(data)) return index;
		stored = {};
		seen.set(data, index);
		list.push(stored);
		const keys = Object.keys(data);
		for (i = 0, l = keys.length; i < l; i++) {
			key = keys[i];
			if (key === "compilerOptions") return index;
			value = data[key];
			const isVm = value != null && isObject(value, Object.prototype.toString.call(data)) && isVueInstance(value);
			try {
				if (replacer) value = replacer.call(data, key, value, depth, seenVueInstance);
			} catch (e) {
				value = e;
			}
			stored[key] = encode(value, replacer, list, seen, depth + 1, seenVueInstance);
			if (isVm) seenVueInstance.delete(value);
		}
	} else if (isArray(data, proto)) {
		stored = [];
		seen.set(data, index);
		list.push(stored);
		for (i = 0, l = data.length; i < l; i++) {
			try {
				value = data[i];
				if (replacer) value = replacer.call(data, i, value, depth, seenVueInstance);
			} catch (e) {
				value = e;
			}
			stored[i] = encode(value, replacer, list, seen, depth + 1, seenVueInstance);
		}
	} else list.push(data);
	return index;
}
function decode(list, reviver = null) {
	let i = list.length;
	let j, k, data, key, value, proto;
	while (i--) {
		data = list[i];
		proto = Object.prototype.toString.call(data);
		if (proto === "[object Object]") {
			const keys = Object.keys(data);
			for (j = 0, k = keys.length; j < k; j++) {
				key = keys[j];
				value = list[data[key]];
				if (reviver) value = reviver.call(data, key, value);
				data[key] = value;
			}
		} else if (proto === "[object Array]") for (j = 0, k = data.length; j < k; j++) {
			value = list[data[j]];
			if (reviver) value = reviver.call(data, j, value);
			data[j] = value;
		}
	}
}
function stringifyCircularAutoChunks(data, replacer = null, space = null) {
	let result;
	try {
		result = arguments.length === 1 ? JSON.stringify(data) : JSON.stringify(data, (k, v) => replacer?.(k, v)?.call(this), space);
	} catch (e) {
		result = stringifyStrictCircularAutoChunks(data, replacer, space);
	}
	if (result.length > MAX_SERIALIZED_SIZE) {
		const chunkCount = Math.ceil(result.length / MAX_SERIALIZED_SIZE);
		const chunks = [];
		for (let i = 0; i < chunkCount; i++) chunks.push(result.slice(i * MAX_SERIALIZED_SIZE, (i + 1) * MAX_SERIALIZED_SIZE));
		return chunks;
	}
	return result;
}
function stringifyStrictCircularAutoChunks(data, replacer = null, space = null) {
	const list = [];
	encode(data, replacer, list, /* @__PURE__ */ new Map());
	return space ? ` ${JSON.stringify(list, null, space)}` : ` ${JSON.stringify(list)}`;
}
function parseCircularAutoChunks(data, reviver = null) {
	if (Array.isArray(data)) data = data.join("");
	if (!/^\s/.test(data)) return arguments.length === 1 ? JSON.parse(data) : JSON.parse(data, reviver);
	else {
		const list = JSON.parse(data);
		decode(list, reviver);
		return list[0];
	}
}
//#endregion
//#region src/shared/util.ts
function stringify(data) {
	return stringifyCircularAutoChunks(data, stringifyReplacer);
}
function parse(data, revive = false) {
	if (data == void 0) return {};
	return revive ? parseCircularAutoChunks(data, reviver) : parseCircularAutoChunks(data);
}
//#endregion
//#region src/index.ts
const devtools = {
	hook,
	init: () => {
		initDevTools();
	},
	get ctx() {
		return devtoolsContext;
	},
	get api() {
		return devtoolsContext.api;
	}
};
//#endregion
export { DevToolsContextHookKeys, DevToolsMessagingHookKeys, DevToolsV6PluginAPIHookKeys, INFINITY, NAN, NEGATIVE_INFINITY, ROUTER_INFO_KEY, ROUTER_KEY, UNDEFINED, activeAppRecord, addCustomCommand, addCustomTab, addDevToolsAppRecord, addDevToolsPluginToBuffer, addInspector, callConnectedUpdatedHook, callDevToolsPluginSetupFn, callInspectorUpdatedHook, callStateUpdatedHook, createComponentsDevToolsPlugin, createDevToolsApi, createDevToolsCtxHooks, createRpcClient, createRpcProxy, createRpcServer, devtools, devtoolsAppRecords, devtoolsContext, devtoolsInspector, devtoolsPluginBuffer, devtoolsRouter, devtoolsRouterInfo, devtoolsState, escape, formatInspectorStateValue, getActiveInspectors, getDevToolsEnv, getExtensionClientContext, getInspector, getInspectorActions, getInspectorInfo, getInspectorNodeActions, getInspectorStateValueType, getRaw, getRpcClient, getRpcServer, getViteRpcClient, getViteRpcServer, initDevTools, isPlainObject, onDevToolsClientConnected, onDevToolsConnected, parse, registerDevToolsPlugin, removeCustomCommand, removeDevToolsAppRecord, removeRegisteredPluginApp, resetDevToolsState, setActiveAppRecord, setActiveAppRecordId, setDevToolsEnv, setElectronClientContext, setElectronProxyContext, setElectronServerContext, setExtensionClientContext, setIframeServerContext, setOpenInEditorBaseUrl, setRpcServerToGlobal, setViteClientContext, setViteRpcClientToGlobal, setViteRpcServerToGlobal, setViteServerContext, setupDevToolsPlugin, stringify, toEdit, toSubmit, toggleClientConnected, toggleComponentInspectorEnabled, toggleHighPerfMode, updateDevToolsClientDetected, updateDevToolsState, updateTimelineLayersState };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LmpzP3Y9N2U3M2FmYzIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYmFzZW5hbWUsIGNhbWVsaXplLCBjbGFzc2lmeSwgZGVlcENsb25lLCBpc0Jyb3dzZXIsIGlzTnV4dEFwcCwgaXNVcmxTdHJpbmcsIGtlYmFiaXplLCB0YXJnZXQgfSBmcm9tIFwiL19udXh0L0Bmcy9Wb2x1bWVzL0NvZGluZy9Qcm9qZWN0cy9XZWJzaXRlcy9pbmVpYWgvZnJvbnRlbmQvbm9kZV9tb2R1bGVzLy5wbnBtL0B2dWUrZGV2dG9vbHMtc2hhcmVkQDguMi4xL25vZGVfbW9kdWxlcy9AdnVlL2RldnRvb2xzLXNoYXJlZC9kaXN0L2luZGV4LmpzP3Y9N2U3M2FmYzJcIjtcbmltcG9ydCB7IGRlYm91bmNlIH0gZnJvbSBcIi9fbnV4dC9AZnMvVm9sdW1lcy9Db2RpbmcvUHJvamVjdHMvV2Vic2l0ZXMvaW5laWFoL2Zyb250ZW5kL25vZGVfbW9kdWxlcy8ucG5wbS9wZXJmZWN0LWRlYm91bmNlQDIuMS4wL25vZGVfbW9kdWxlcy9wZXJmZWN0LWRlYm91bmNlL2Rpc3QvaW5kZXgubWpzP3Y9N2U3M2FmYzJcIjtcbmltcG9ydCB7IGNyZWF0ZUhvb2tzIH0gZnJvbSBcIi9fbnV4dC9AZnMvVm9sdW1lcy9Db2RpbmcvUHJvamVjdHMvV2Vic2l0ZXMvaW5laWFoL2Zyb250ZW5kL25vZGVfbW9kdWxlcy8ucG5wbS9ob29rYWJsZUA1LjUuMy9ub2RlX21vZHVsZXMvaG9va2FibGUvZGlzdC9pbmRleC5tanM/dj03ZTczYWZjMlwiO1xuaW1wb3J0IHsgY3JlYXRlQmlycGMsIGNyZWF0ZUJpcnBjR3JvdXAgfSBmcm9tIFwiL19udXh0L0Bmcy9Wb2x1bWVzL0NvZGluZy9Qcm9qZWN0cy9XZWJzaXRlcy9pbmVpYWgvZnJvbnRlbmQvbm9kZV9tb2R1bGVzLy5wbnBtL2JpcnBjQDIuOS4wL25vZGVfbW9kdWxlcy9iaXJwYy9kaXN0L2luZGV4Lm1qcz92PTdlNzNhZmMyXCI7XG4vLyNyZWdpb24gXFwwcm9sbGRvd24vcnVudGltZS5qc1xudmFyIF9fY3JlYXRlID0gT2JqZWN0LmNyZWF0ZTtcbnZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19nZXRPd25Qcm9wRGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3I7XG52YXIgX19nZXRPd25Qcm9wTmFtZXMgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcztcbnZhciBfX2dldFByb3RvT2YgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2Y7XG52YXIgX19oYXNPd25Qcm9wID0gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eTtcbnZhciBfX2NvbW1vbkpTTWluID0gKGNiLCBtb2QpID0+ICgpID0+IChtb2QgfHwgY2IoKG1vZCA9IHsgZXhwb3J0czoge30gfSkuZXhwb3J0cywgbW9kKSwgbW9kLmV4cG9ydHMpO1xudmFyIF9fY29weVByb3BzID0gKHRvLCBmcm9tLCBleGNlcHQsIGRlc2MpID0+IHtcblx0aWYgKGZyb20gJiYgdHlwZW9mIGZyb20gPT09IFwib2JqZWN0XCIgfHwgdHlwZW9mIGZyb20gPT09IFwiZnVuY3Rpb25cIikgZm9yICh2YXIga2V5cyA9IF9fZ2V0T3duUHJvcE5hbWVzKGZyb20pLCBpID0gMCwgbiA9IGtleXMubGVuZ3RoLCBrZXk7IGkgPCBuOyBpKyspIHtcblx0XHRrZXkgPSBrZXlzW2ldO1xuXHRcdGlmICghX19oYXNPd25Qcm9wLmNhbGwodG8sIGtleSkgJiYga2V5ICE9PSBleGNlcHQpIF9fZGVmUHJvcCh0bywga2V5LCB7XG5cdFx0XHRnZXQ6ICgoaykgPT4gZnJvbVtrXSkuYmluZChudWxsLCBrZXkpLFxuXHRcdFx0ZW51bWVyYWJsZTogIShkZXNjID0gX19nZXRPd25Qcm9wRGVzYyhmcm9tLCBrZXkpKSB8fCBkZXNjLmVudW1lcmFibGVcblx0XHR9KTtcblx0fVxuXHRyZXR1cm4gdG87XG59O1xudmFyIF9fdG9FU00gPSAobW9kLCBpc05vZGVNb2RlLCB0YXJnZXQpID0+ICh0YXJnZXQgPSBtb2QgIT0gbnVsbCA/IF9fY3JlYXRlKF9fZ2V0UHJvdG9PZihtb2QpKSA6IHt9LCBfX2NvcHlQcm9wcyhpc05vZGVNb2RlIHx8ICFtb2QgfHwgIW1vZC5fX2VzTW9kdWxlID8gX19kZWZQcm9wKHRhcmdldCwgXCJkZWZhdWx0XCIsIHtcblx0dmFsdWU6IG1vZCxcblx0ZW51bWVyYWJsZTogdHJ1ZVxufSkgOiB0YXJnZXQsIG1vZCkpO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvbXBhdC9pbmRleC50c1xuZnVuY3Rpb24gb25MZWdhY3lEZXZUb29sc1BsdWdpbkFwaUF2YWlsYWJsZShjYikge1xuXHRpZiAodGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX1BMVUdJTl9BUElfQVZBSUxBQkxFX18pIHtcblx0XHRjYigpO1xuXHRcdHJldHVybjtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBcIl9fVlVFX0RFVlRPT0xTX1BMVUdJTl9BUElfQVZBSUxBQkxFX19cIiwge1xuXHRcdHNldCh2YWx1ZSkge1xuXHRcdFx0aWYgKHZhbHVlKSBjYigpO1xuXHRcdH0sXG5cdFx0Y29uZmlndXJhYmxlOiB0cnVlXG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50L3V0aWxzL2luZGV4LnRzXG5mdW5jdGlvbiBnZXRDb21wb25lbnRUeXBlTmFtZShvcHRpb25zKSB7XG5cdGlmICh0eXBlb2Ygb3B0aW9ucyA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gb3B0aW9ucy5kaXNwbGF5TmFtZSB8fCBvcHRpb25zLm5hbWUgfHwgb3B0aW9ucy5fX1ZVRV9ERVZUT09MU19DT01QT05FTlRfR1VTU0VEX05BTUVfXyB8fCBcIlwiO1xuXHRjb25zdCBuYW1lID0gb3B0aW9ucy5uYW1lIHx8IG9wdGlvbnMuX2NvbXBvbmVudFRhZyB8fCBvcHRpb25zLl9fVlVFX0RFVlRPT0xTX0NPTVBPTkVOVF9HVVNTRURfTkFNRV9fIHx8IG9wdGlvbnMuX19uYW1lO1xuXHRpZiAobmFtZSA9PT0gXCJpbmRleFwiICYmIG9wdGlvbnMuX19maWxlPy5lbmRzV2l0aChcImluZGV4LnZ1ZVwiKSkgcmV0dXJuIFwiXCI7XG5cdHJldHVybiBuYW1lO1xufVxuZnVuY3Rpb24gZ2V0Q29tcG9uZW50RmlsZU5hbWUob3B0aW9ucykge1xuXHRjb25zdCBmaWxlID0gb3B0aW9ucy5fX2ZpbGU7XG5cdGlmIChmaWxlKSByZXR1cm4gY2xhc3NpZnkoYmFzZW5hbWUoZmlsZSwgXCIudnVlXCIpKTtcbn1cbmZ1bmN0aW9uIGdldENvbXBvbmVudE5hbWUob3B0aW9ucykge1xuXHRjb25zdCBuYW1lID0gb3B0aW9ucy5kaXNwbGF5TmFtZSB8fCBvcHRpb25zLm5hbWUgfHwgb3B0aW9ucy5fY29tcG9uZW50VGFnO1xuXHRpZiAobmFtZSkgcmV0dXJuIG5hbWU7XG5cdHJldHVybiBnZXRDb21wb25lbnRGaWxlTmFtZShvcHRpb25zKTtcbn1cbmZ1bmN0aW9uIHNhdmVDb21wb25lbnRHdXNzZWROYW1lKGluc3RhbmNlLCBuYW1lKSB7XG5cdGluc3RhbmNlLnR5cGUuX19WVUVfREVWVE9PTFNfQ09NUE9ORU5UX0dVU1NFRF9OQU1FX18gPSBuYW1lO1xuXHRyZXR1cm4gbmFtZTtcbn1cbmZ1bmN0aW9uIGdldEFwcFJlY29yZChpbnN0YW5jZSkge1xuXHRpZiAoaW5zdGFuY2UuX19WVUVfREVWVE9PTFNfTkVYVF9BUFBfUkVDT1JEX18pIHJldHVybiBpbnN0YW5jZS5fX1ZVRV9ERVZUT09MU19ORVhUX0FQUF9SRUNPUkRfXztcblx0ZWxzZSBpZiAoaW5zdGFuY2Uucm9vdCkgcmV0dXJuIGluc3RhbmNlLmFwcENvbnRleHQuYXBwLl9fVlVFX0RFVlRPT0xTX05FWFRfQVBQX1JFQ09SRF9fO1xufVxuYXN5bmMgZnVuY3Rpb24gZ2V0Q29tcG9uZW50SWQob3B0aW9ucykge1xuXHRjb25zdCB7IGFwcCwgdWlkLCBpbnN0YW5jZSB9ID0gb3B0aW9ucztcblx0dHJ5IHtcblx0XHRpZiAoaW5zdGFuY2UuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXykgcmV0dXJuIGluc3RhbmNlLl9fVlVFX0RFVlRPT0xTX05FWFRfVUlEX187XG5cdFx0Y29uc3QgYXBwUmVjb3JkID0gYXdhaXQgZ2V0QXBwUmVjb3JkKGFwcCk7XG5cdFx0aWYgKCFhcHBSZWNvcmQpIHJldHVybiBudWxsO1xuXHRcdGNvbnN0IGlzUm9vdCA9IGFwcFJlY29yZC5yb290SW5zdGFuY2UgPT09IGluc3RhbmNlO1xuXHRcdHJldHVybiBgJHthcHBSZWNvcmQuaWR9OiR7aXNSb290ID8gXCJyb290XCIgOiB1aWR9YDtcblx0fSBjYXRjaCAoZSkge31cbn1cbmZ1bmN0aW9uIGlzRnJhZ21lbnQoaW5zdGFuY2UpIHtcblx0Y29uc3Qgc3ViVHJlZVR5cGUgPSBpbnN0YW5jZS5zdWJUcmVlPy50eXBlO1xuXHRjb25zdCBhcHBSZWNvcmQgPSBnZXRBcHBSZWNvcmQoaW5zdGFuY2UpO1xuXHRpZiAoYXBwUmVjb3JkKSByZXR1cm4gYXBwUmVjb3JkPy50eXBlcz8uRnJhZ21lbnQgPT09IHN1YlRyZWVUeXBlO1xuXHRyZXR1cm4gZmFsc2U7XG59XG5mdW5jdGlvbiBpc0JlaW5nRGVzdHJveWVkKGluc3RhbmNlKSB7XG5cdHJldHVybiBpbnN0YW5jZS5faXNCZWluZ0Rlc3Ryb3llZCB8fCBpbnN0YW5jZS5pc1VubW91bnRlZDtcbn1cbi8qKlxuKiBHZXQgdGhlIGFwcHJvcHJpYXRlIGRpc3BsYXkgbmFtZSBmb3IgYW4gaW5zdGFuY2UuXG4qXG4qIEBwYXJhbSB7VnVlfSBpbnN0YW5jZVxuKiBAcmV0dXJuIHtzdHJpbmd9XG4qL1xuZnVuY3Rpb24gZ2V0SW5zdGFuY2VOYW1lKGluc3RhbmNlKSB7XG5cdGNvbnN0IG5hbWUgPSBnZXRDb21wb25lbnRUeXBlTmFtZShpbnN0YW5jZT8udHlwZSB8fCB7fSk7XG5cdGlmIChuYW1lKSByZXR1cm4gbmFtZTtcblx0aWYgKGluc3RhbmNlPy5yb290ID09PSBpbnN0YW5jZSkgcmV0dXJuIFwiUm9vdFwiO1xuXHRmb3IgKGNvbnN0IGtleSBpbiBpbnN0YW5jZS5wYXJlbnQ/LnR5cGU/LmNvbXBvbmVudHMpIGlmIChpbnN0YW5jZS5wYXJlbnQudHlwZS5jb21wb25lbnRzW2tleV0gPT09IGluc3RhbmNlPy50eXBlKSByZXR1cm4gc2F2ZUNvbXBvbmVudEd1c3NlZE5hbWUoaW5zdGFuY2UsIGtleSk7XG5cdGZvciAoY29uc3Qga2V5IGluIGluc3RhbmNlLmFwcENvbnRleHQ/LmNvbXBvbmVudHMpIGlmIChpbnN0YW5jZS5hcHBDb250ZXh0LmNvbXBvbmVudHNba2V5XSA9PT0gaW5zdGFuY2U/LnR5cGUpIHJldHVybiBzYXZlQ29tcG9uZW50R3Vzc2VkTmFtZShpbnN0YW5jZSwga2V5KTtcblx0Y29uc3QgZmlsZU5hbWUgPSBnZXRDb21wb25lbnRGaWxlTmFtZShpbnN0YW5jZT8udHlwZSB8fCB7fSk7XG5cdGlmIChmaWxlTmFtZSkgcmV0dXJuIGZpbGVOYW1lO1xuXHRyZXR1cm4gXCJBbm9ueW1vdXMgQ29tcG9uZW50XCI7XG59XG4vKipcbiogUmV0dXJucyBhIGRldnRvb2xzIHVuaXF1ZSBpZCBmb3IgaW5zdGFuY2UuXG4qIEBwYXJhbSB7VnVlfSBpbnN0YW5jZVxuKi9cbmZ1bmN0aW9uIGdldFVuaXF1ZUNvbXBvbmVudElkKGluc3RhbmNlKSB7XG5cdHJldHVybiBgJHtpbnN0YW5jZT8uYXBwQ29udGV4dD8uYXBwPy5fX1ZVRV9ERVZUT09MU19ORVhUX0FQUF9SRUNPUkRfSURfXyA/PyAwfToke2luc3RhbmNlID09PSBpbnN0YW5jZT8ucm9vdCA/IFwicm9vdFwiIDogaW5zdGFuY2UudWlkfWA7XG59XG5mdW5jdGlvbiBnZXRSZW5kZXJLZXkodmFsdWUpIHtcblx0aWYgKHZhbHVlID09IG51bGwpIHJldHVybiBcIlwiO1xuXHRpZiAodHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiKSByZXR1cm4gdmFsdWU7XG5cdGVsc2UgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIGAnJHt2YWx1ZX0nYDtcblx0ZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHJldHVybiBcIkFycmF5XCI7XG5cdGVsc2UgcmV0dXJuIFwiT2JqZWN0XCI7XG59XG5mdW5jdGlvbiByZXR1cm5FcnJvcihjYikge1xuXHR0cnkge1xuXHRcdHJldHVybiBjYigpO1xuXHR9IGNhdGNoIChlKSB7XG5cdFx0cmV0dXJuIGU7XG5cdH1cbn1cbmZ1bmN0aW9uIGdldENvbXBvbmVudEluc3RhbmNlKGFwcFJlY29yZCwgaW5zdGFuY2VJZCkge1xuXHRpbnN0YW5jZUlkID0gaW5zdGFuY2VJZCB8fCBgJHthcHBSZWNvcmQuaWR9OnJvb3RgO1xuXHRyZXR1cm4gYXBwUmVjb3JkLmluc3RhbmNlTWFwLmdldChpbnN0YW5jZUlkKSB8fCBhcHBSZWNvcmQuaW5zdGFuY2VNYXAuZ2V0KFwiOnJvb3RcIik7XG59XG5mdW5jdGlvbiBlbnN1cmVQcm9wZXJ0eUV4aXN0cyhvYmosIGtleSwgc2tpcE9iakNoZWNrID0gZmFsc2UpIHtcblx0cmV0dXJuIHNraXBPYmpDaGVjayA/IGtleSBpbiBvYmogOiB0eXBlb2Ygb2JqID09PSBcIm9iamVjdFwiICYmIG9iaiAhPT0gbnVsbCA/IGtleSBpbiBvYmogOiBmYWxzZTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2NvbXBvbmVudC9zdGF0ZS9ib3VuZGluZy1yZWN0LnRzXG5mdW5jdGlvbiBjcmVhdGVSZWN0KCkge1xuXHRjb25zdCByZWN0ID0ge1xuXHRcdHRvcDogMCxcblx0XHRib3R0b206IDAsXG5cdFx0bGVmdDogMCxcblx0XHRyaWdodDogMCxcblx0XHRnZXQgd2lkdGgoKSB7XG5cdFx0XHRyZXR1cm4gcmVjdC5yaWdodCAtIHJlY3QubGVmdDtcblx0XHR9LFxuXHRcdGdldCBoZWlnaHQoKSB7XG5cdFx0XHRyZXR1cm4gcmVjdC5ib3R0b20gLSByZWN0LnRvcDtcblx0XHR9XG5cdH07XG5cdHJldHVybiByZWN0O1xufVxubGV0IHJhbmdlO1xuZnVuY3Rpb24gZ2V0VGV4dFJlY3Qobm9kZSkge1xuXHRpZiAoIXJhbmdlKSByYW5nZSA9IGRvY3VtZW50LmNyZWF0ZVJhbmdlKCk7XG5cdHJhbmdlLnNlbGVjdE5vZGUobm9kZSk7XG5cdHJldHVybiByYW5nZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbn1cbmZ1bmN0aW9uIGdldEZyYWdtZW50UmVjdCh2bm9kZSkge1xuXHRjb25zdCByZWN0ID0gY3JlYXRlUmVjdCgpO1xuXHRpZiAoIXZub2RlLmNoaWxkcmVuKSByZXR1cm4gcmVjdDtcblx0Zm9yIChsZXQgaSA9IDAsIGwgPSB2bm9kZS5jaGlsZHJlbi5sZW5ndGg7IGkgPCBsOyBpKyspIHtcblx0XHRjb25zdCBjaGlsZFZub2RlID0gdm5vZGUuY2hpbGRyZW5baV07XG5cdFx0bGV0IGNoaWxkUmVjdDtcblx0XHRpZiAoY2hpbGRWbm9kZS5jb21wb25lbnQpIGNoaWxkUmVjdCA9IGdldENvbXBvbmVudEJvdW5kaW5nUmVjdChjaGlsZFZub2RlLmNvbXBvbmVudCk7XG5cdFx0ZWxzZSBpZiAoY2hpbGRWbm9kZS5lbCkge1xuXHRcdFx0Y29uc3QgZWwgPSBjaGlsZFZub2RlLmVsO1xuXHRcdFx0aWYgKGVsLm5vZGVUeXBlID09PSAxIHx8IGVsLmdldEJvdW5kaW5nQ2xpZW50UmVjdCkgY2hpbGRSZWN0ID0gZWwuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG5cdFx0XHRlbHNlIGlmIChlbC5ub2RlVHlwZSA9PT0gMyAmJiBlbC5kYXRhLnRyaW0oKSkgY2hpbGRSZWN0ID0gZ2V0VGV4dFJlY3QoZWwpO1xuXHRcdH1cblx0XHRpZiAoY2hpbGRSZWN0KSBtZXJnZVJlY3RzKHJlY3QsIGNoaWxkUmVjdCk7XG5cdH1cblx0cmV0dXJuIHJlY3Q7XG59XG5mdW5jdGlvbiBtZXJnZVJlY3RzKGEsIGIpIHtcblx0aWYgKCFhLnRvcCB8fCBiLnRvcCA8IGEudG9wKSBhLnRvcCA9IGIudG9wO1xuXHRpZiAoIWEuYm90dG9tIHx8IGIuYm90dG9tID4gYS5ib3R0b20pIGEuYm90dG9tID0gYi5ib3R0b207XG5cdGlmICghYS5sZWZ0IHx8IGIubGVmdCA8IGEubGVmdCkgYS5sZWZ0ID0gYi5sZWZ0O1xuXHRpZiAoIWEucmlnaHQgfHwgYi5yaWdodCA+IGEucmlnaHQpIGEucmlnaHQgPSBiLnJpZ2h0O1xuXHRyZXR1cm4gYTtcbn1cbmNvbnN0IERFRkFVTFRfUkVDVCA9IHtcblx0dG9wOiAwLFxuXHRsZWZ0OiAwLFxuXHRyaWdodDogMCxcblx0Ym90dG9tOiAwLFxuXHR3aWR0aDogMCxcblx0aGVpZ2h0OiAwXG59O1xuZnVuY3Rpb24gZ2V0Q29tcG9uZW50Qm91bmRpbmdSZWN0KGluc3RhbmNlKSB7XG5cdGNvbnN0IGVsID0gaW5zdGFuY2Uuc3ViVHJlZS5lbDtcblx0aWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBERUZBVUxUX1JFQ1Q7XG5cdGlmIChpc0ZyYWdtZW50KGluc3RhbmNlKSkgcmV0dXJuIGdldEZyYWdtZW50UmVjdChpbnN0YW5jZS5zdWJUcmVlKTtcblx0ZWxzZSBpZiAoZWw/Lm5vZGVUeXBlID09PSAxKSByZXR1cm4gZWw/LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuXHRlbHNlIGlmIChpbnN0YW5jZS5zdWJUcmVlLmNvbXBvbmVudCkgcmV0dXJuIGdldENvbXBvbmVudEJvdW5kaW5nUmVjdChpbnN0YW5jZS5zdWJUcmVlLmNvbXBvbmVudCk7XG5cdGVsc2UgcmV0dXJuIERFRkFVTFRfUkVDVDtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2NvbXBvbmVudC90cmVlL2VsLnRzXG5mdW5jdGlvbiBnZXRSb290RWxlbWVudHNGcm9tQ29tcG9uZW50SW5zdGFuY2UoaW5zdGFuY2UpIHtcblx0aWYgKGlzRnJhZ21lbnQoaW5zdGFuY2UpKSByZXR1cm4gZ2V0RnJhZ21lbnRSb290RWxlbWVudHMoaW5zdGFuY2Uuc3ViVHJlZSk7XG5cdGlmICghaW5zdGFuY2Uuc3ViVHJlZSkgcmV0dXJuIFtdO1xuXHRyZXR1cm4gW2luc3RhbmNlLnN1YlRyZWUuZWxdO1xufVxuZnVuY3Rpb24gZ2V0RnJhZ21lbnRSb290RWxlbWVudHModm5vZGUpIHtcblx0aWYgKCF2bm9kZS5jaGlsZHJlbikgcmV0dXJuIFtdO1xuXHRjb25zdCBsaXN0ID0gW107XG5cdHZub2RlLmNoaWxkcmVuLmZvckVhY2goKGNoaWxkVm5vZGUpID0+IHtcblx0XHRpZiAoY2hpbGRWbm9kZS5jb21wb25lbnQpIGxpc3QucHVzaCguLi5nZXRSb290RWxlbWVudHNGcm9tQ29tcG9uZW50SW5zdGFuY2UoY2hpbGRWbm9kZS5jb21wb25lbnQpKTtcblx0XHRlbHNlIGlmIChjaGlsZFZub2RlPy5lbCkgbGlzdC5wdXNoKGNoaWxkVm5vZGUuZWwpO1xuXHR9KTtcblx0cmV0dXJuIGxpc3Q7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQtaGlnaGxpZ2h0ZXIvaW5kZXgudHNcbmNvbnN0IENPTlRBSU5FUl9FTEVNRU5UX0lEID0gXCJfX3Z1ZS1kZXZ0b29scy1jb21wb25lbnQtaW5zcGVjdG9yX19cIjtcbmNvbnN0IENBUkRfRUxFTUVOVF9JRCA9IFwiX192dWUtZGV2dG9vbHMtY29tcG9uZW50LWluc3BlY3Rvcl9fY2FyZF9fXCI7XG5jb25zdCBDT01QT05FTlRfTkFNRV9FTEVNRU5UX0lEID0gXCJfX3Z1ZS1kZXZ0b29scy1jb21wb25lbnQtaW5zcGVjdG9yX19uYW1lX19cIjtcbmNvbnN0IElORElDQVRPUl9FTEVNRU5UX0lEID0gXCJfX3Z1ZS1kZXZ0b29scy1jb21wb25lbnQtaW5zcGVjdG9yX19pbmRpY2F0b3JfX1wiO1xuY29uc3QgY29udGFpbmVyU3R5bGVzID0ge1xuXHRkaXNwbGF5OiBcImJsb2NrXCIsXG5cdHpJbmRleDogMjE0NzQ4MzY0MCxcblx0cG9zaXRpb246IFwiZml4ZWRcIixcblx0YmFja2dyb3VuZENvbG9yOiBcIiM0MmI4ODMyNVwiLFxuXHRib3JkZXI6IFwiMXB4IHNvbGlkICM0MmI4ODM1MFwiLFxuXHRib3JkZXJSYWRpdXM6IFwiNXB4XCIsXG5cdHRyYW5zaXRpb246IFwiYWxsIDAuMXMgZWFzZS1pblwiLFxuXHRwb2ludGVyRXZlbnRzOiBcIm5vbmVcIlxufTtcbmNvbnN0IGNhcmRTdHlsZXMgPSB7XG5cdGZvbnRGYW1pbHk6IFwiQXJpYWwsIEhlbHZldGljYSwgc2Fucy1zZXJpZlwiLFxuXHRwYWRkaW5nOiBcIjVweCA4cHhcIixcblx0Ym9yZGVyUmFkaXVzOiBcIjRweFwiLFxuXHR0ZXh0QWxpZ246IFwibGVmdFwiLFxuXHRwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLFxuXHRsZWZ0OiAwLFxuXHRjb2xvcjogXCIjZTllOWU5XCIsXG5cdGZvbnRTaXplOiBcIjE0cHhcIixcblx0Zm9udFdlaWdodDogNjAwLFxuXHRsaW5lSGVpZ2h0OiBcIjI0cHhcIixcblx0YmFja2dyb3VuZENvbG9yOiBcIiM0MmI4ODNcIixcblx0Ym94U2hhZG93OiBcIjAgMXB4IDNweCAwIHJnYmEoMCwgMCwgMCwgMC4xKSwgMCAxcHggMnB4IC0xcHggcmdiYSgwLCAwLCAwLCAwLjEpXCJcbn07XG5jb25zdCBpbmRpY2F0b3JTdHlsZXMgPSB7XG5cdGRpc3BsYXk6IFwiaW5saW5lLWJsb2NrXCIsXG5cdGZvbnRXZWlnaHQ6IDQwMCxcblx0Zm9udFN0eWxlOiBcIm5vcm1hbFwiLFxuXHRmb250U2l6ZTogXCIxMnB4XCIsXG5cdG9wYWNpdHk6IC43XG59O1xuZnVuY3Rpb24gZ2V0Q29udGFpbmVyRWxlbWVudCgpIHtcblx0cmV0dXJuIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKENPTlRBSU5FUl9FTEVNRU5UX0lEKTtcbn1cbmZ1bmN0aW9uIGdldENhcmRFbGVtZW50KCkge1xuXHRyZXR1cm4gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoQ0FSRF9FTEVNRU5UX0lEKTtcbn1cbmZ1bmN0aW9uIGdldEluZGljYXRvckVsZW1lbnQoKSB7XG5cdHJldHVybiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChJTkRJQ0FUT1JfRUxFTUVOVF9JRCk7XG59XG5mdW5jdGlvbiBnZXROYW1lRWxlbWVudCgpIHtcblx0cmV0dXJuIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKENPTVBPTkVOVF9OQU1FX0VMRU1FTlRfSUQpO1xufVxuZnVuY3Rpb24gZ2V0U3R5bGVzKGJvdW5kcykge1xuXHRyZXR1cm4ge1xuXHRcdGxlZnQ6IGAke01hdGgucm91bmQoYm91bmRzLmxlZnQgKiAxMDApIC8gMTAwfXB4YCxcblx0XHR0b3A6IGAke01hdGgucm91bmQoYm91bmRzLnRvcCAqIDEwMCkgLyAxMDB9cHhgLFxuXHRcdHdpZHRoOiBgJHtNYXRoLnJvdW5kKGJvdW5kcy53aWR0aCAqIDEwMCkgLyAxMDB9cHhgLFxuXHRcdGhlaWdodDogYCR7TWF0aC5yb3VuZChib3VuZHMuaGVpZ2h0ICogMTAwKSAvIDEwMH1weGBcblx0fTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZShvcHRpb25zKSB7XG5cdGNvbnN0IGNvbnRhaW5lckVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcblx0Y29udGFpbmVyRWwuaWQgPSBvcHRpb25zLmVsZW1lbnRJZCA/PyBDT05UQUlORVJfRUxFTUVOVF9JRDtcblx0T2JqZWN0LmFzc2lnbihjb250YWluZXJFbC5zdHlsZSwge1xuXHRcdC4uLmNvbnRhaW5lclN0eWxlcyxcblx0XHQuLi5nZXRTdHlsZXMob3B0aW9ucy5ib3VuZHMpLFxuXHRcdC4uLm9wdGlvbnMuc3R5bGVcblx0fSk7XG5cdGNvbnN0IGNhcmRFbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzcGFuXCIpO1xuXHRjYXJkRWwuaWQgPSBDQVJEX0VMRU1FTlRfSUQ7XG5cdE9iamVjdC5hc3NpZ24oY2FyZEVsLnN0eWxlLCB7XG5cdFx0Li4uY2FyZFN0eWxlcyxcblx0XHR0b3A6IG9wdGlvbnMuYm91bmRzLnRvcCA8IDM1ID8gMCA6IFwiLTM1cHhcIlxuXHR9KTtcblx0Y29uc3QgbmFtZUVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNwYW5cIik7XG5cdG5hbWVFbC5pZCA9IENPTVBPTkVOVF9OQU1FX0VMRU1FTlRfSUQ7XG5cdG5hbWVFbC5pbm5lckhUTUwgPSBgJmx0OyR7b3B0aW9ucy5uYW1lfSZndDsmbmJzcDsmbmJzcDtgO1xuXHRjb25zdCBpbmRpY2F0b3JFbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJpXCIpO1xuXHRpbmRpY2F0b3JFbC5pZCA9IElORElDQVRPUl9FTEVNRU5UX0lEO1xuXHRpbmRpY2F0b3JFbC5pbm5lckhUTUwgPSBgJHtNYXRoLnJvdW5kKG9wdGlvbnMuYm91bmRzLndpZHRoICogMTAwKSAvIDEwMH0geCAke01hdGgucm91bmQob3B0aW9ucy5ib3VuZHMuaGVpZ2h0ICogMTAwKSAvIDEwMH1gO1xuXHRPYmplY3QuYXNzaWduKGluZGljYXRvckVsLnN0eWxlLCBpbmRpY2F0b3JTdHlsZXMpO1xuXHRjYXJkRWwuYXBwZW5kQ2hpbGQobmFtZUVsKTtcblx0Y2FyZEVsLmFwcGVuZENoaWxkKGluZGljYXRvckVsKTtcblx0Y29udGFpbmVyRWwuYXBwZW5kQ2hpbGQoY2FyZEVsKTtcblx0ZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChjb250YWluZXJFbCk7XG5cdHJldHVybiBjb250YWluZXJFbDtcbn1cbmZ1bmN0aW9uIHVwZGF0ZShvcHRpb25zKSB7XG5cdGNvbnN0IGNvbnRhaW5lckVsID0gZ2V0Q29udGFpbmVyRWxlbWVudCgpO1xuXHRjb25zdCBjYXJkRWwgPSBnZXRDYXJkRWxlbWVudCgpO1xuXHRjb25zdCBuYW1lRWwgPSBnZXROYW1lRWxlbWVudCgpO1xuXHRjb25zdCBpbmRpY2F0b3JFbCA9IGdldEluZGljYXRvckVsZW1lbnQoKTtcblx0aWYgKGNvbnRhaW5lckVsKSB7XG5cdFx0T2JqZWN0LmFzc2lnbihjb250YWluZXJFbC5zdHlsZSwge1xuXHRcdFx0Li4uY29udGFpbmVyU3R5bGVzLFxuXHRcdFx0Li4uZ2V0U3R5bGVzKG9wdGlvbnMuYm91bmRzKVxuXHRcdH0pO1xuXHRcdE9iamVjdC5hc3NpZ24oY2FyZEVsLnN0eWxlLCB7IHRvcDogb3B0aW9ucy5ib3VuZHMudG9wIDwgMzUgPyAwIDogXCItMzVweFwiIH0pO1xuXHRcdG5hbWVFbC5pbm5lckhUTUwgPSBgJmx0OyR7b3B0aW9ucy5uYW1lfSZndDsmbmJzcDsmbmJzcDtgO1xuXHRcdGluZGljYXRvckVsLmlubmVySFRNTCA9IGAke01hdGgucm91bmQob3B0aW9ucy5ib3VuZHMud2lkdGggKiAxMDApIC8gMTAwfSB4ICR7TWF0aC5yb3VuZChvcHRpb25zLmJvdW5kcy5oZWlnaHQgKiAxMDApIC8gMTAwfWA7XG5cdH1cbn1cbmZ1bmN0aW9uIGhpZ2hsaWdodChpbnN0YW5jZSkge1xuXHRjb25zdCBib3VuZHMgPSBnZXRDb21wb25lbnRCb3VuZGluZ1JlY3QoaW5zdGFuY2UpO1xuXHRpZiAoIWJvdW5kcy53aWR0aCAmJiAhYm91bmRzLmhlaWdodCkgcmV0dXJuO1xuXHRjb25zdCBuYW1lID0gZ2V0SW5zdGFuY2VOYW1lKGluc3RhbmNlKTtcblx0Z2V0Q29udGFpbmVyRWxlbWVudCgpID8gdXBkYXRlKHtcblx0XHRib3VuZHMsXG5cdFx0bmFtZVxuXHR9KSA6IGNyZWF0ZSh7XG5cdFx0Ym91bmRzLFxuXHRcdG5hbWVcblx0fSk7XG59XG5mdW5jdGlvbiB1bmhpZ2hsaWdodCgpIHtcblx0Y29uc3QgZWwgPSBnZXRDb250YWluZXJFbGVtZW50KCk7XG5cdGlmIChlbCkgZWwuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xufVxubGV0IGluc3BlY3RJbnN0YW5jZSA9IG51bGw7XG5mdW5jdGlvbiBpbnNwZWN0Rm4oZSkge1xuXHRjb25zdCB0YXJnZXQgPSBlLnRhcmdldDtcblx0aWYgKHRhcmdldCkge1xuXHRcdGNvbnN0IGluc3RhbmNlID0gdGFyZ2V0Ll9fdnVlUGFyZW50Q29tcG9uZW50O1xuXHRcdGlmIChpbnN0YW5jZSkge1xuXHRcdFx0aW5zcGVjdEluc3RhbmNlID0gaW5zdGFuY2U7XG5cdFx0XHRpZiAoaW5zdGFuY2Uudm5vZGUuZWwpIHtcblx0XHRcdFx0Y29uc3QgYm91bmRzID0gZ2V0Q29tcG9uZW50Qm91bmRpbmdSZWN0KGluc3RhbmNlKTtcblx0XHRcdFx0Y29uc3QgbmFtZSA9IGdldEluc3RhbmNlTmFtZShpbnN0YW5jZSk7XG5cdFx0XHRcdGdldENvbnRhaW5lckVsZW1lbnQoKSA/IHVwZGF0ZSh7XG5cdFx0XHRcdFx0Ym91bmRzLFxuXHRcdFx0XHRcdG5hbWVcblx0XHRcdFx0fSkgOiBjcmVhdGUoe1xuXHRcdFx0XHRcdGJvdW5kcyxcblx0XHRcdFx0XHRuYW1lXG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxufVxuZnVuY3Rpb24gc2VsZWN0Q29tcG9uZW50Rm4oZSwgY2IpIHtcblx0ZS5wcmV2ZW50RGVmYXVsdCgpO1xuXHRlLnN0b3BQcm9wYWdhdGlvbigpO1xuXHRpZiAoaW5zcGVjdEluc3RhbmNlKSBjYihnZXRVbmlxdWVDb21wb25lbnRJZChpbnNwZWN0SW5zdGFuY2UpKTtcbn1cbmxldCBpbnNwZWN0Q29tcG9uZW50SGlnaExpZ2h0ZXJTZWxlY3RGbiA9IG51bGw7XG5mdW5jdGlvbiBjYW5jZWxJbnNwZWN0Q29tcG9uZW50SGlnaExpZ2h0ZXIoKSB7XG5cdHVuaGlnaGxpZ2h0KCk7XG5cdHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwibW91c2VvdmVyXCIsIGluc3BlY3RGbik7XG5cdHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgaW5zcGVjdENvbXBvbmVudEhpZ2hMaWdodGVyU2VsZWN0Rm4sIHRydWUpO1xuXHRpbnNwZWN0Q29tcG9uZW50SGlnaExpZ2h0ZXJTZWxlY3RGbiA9IG51bGw7XG59XG5mdW5jdGlvbiBpbnNwZWN0Q29tcG9uZW50SGlnaExpZ2h0ZXIoKSB7XG5cdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwibW91c2VvdmVyXCIsIGluc3BlY3RGbik7XG5cdHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuXHRcdGZ1bmN0aW9uIG9uU2VsZWN0KGUpIHtcblx0XHRcdGUucHJldmVudERlZmF1bHQoKTtcblx0XHRcdGUuc3RvcFByb3BhZ2F0aW9uKCk7XG5cdFx0XHRzZWxlY3RDb21wb25lbnRGbihlLCAoaWQpID0+IHtcblx0XHRcdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBvblNlbGVjdCwgdHJ1ZSk7XG5cdFx0XHRcdGluc3BlY3RDb21wb25lbnRIaWdoTGlnaHRlclNlbGVjdEZuID0gbnVsbDtcblx0XHRcdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtb3VzZW92ZXJcIiwgaW5zcGVjdEZuKTtcblx0XHRcdFx0Y29uc3QgZWwgPSBnZXRDb250YWluZXJFbGVtZW50KCk7XG5cdFx0XHRcdGlmIChlbCkgZWwuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuXHRcdFx0XHRyZXNvbHZlKEpTT04uc3RyaW5naWZ5KHsgaWQgfSkpO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdGluc3BlY3RDb21wb25lbnRIaWdoTGlnaHRlclNlbGVjdEZuID0gb25TZWxlY3Q7XG5cdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJjbGlja1wiLCBvblNlbGVjdCwgdHJ1ZSk7XG5cdH0pO1xufVxuZnVuY3Rpb24gc2Nyb2xsVG9Db21wb25lbnQob3B0aW9ucykge1xuXHRjb25zdCBpbnN0YW5jZSA9IGdldENvbXBvbmVudEluc3RhbmNlKGFjdGl2ZUFwcFJlY29yZC52YWx1ZSwgb3B0aW9ucy5pZCk7XG5cdGlmIChpbnN0YW5jZSkge1xuXHRcdGNvbnN0IFtlbF0gPSBnZXRSb290RWxlbWVudHNGcm9tQ29tcG9uZW50SW5zdGFuY2UoaW5zdGFuY2UpO1xuXHRcdGlmICh0eXBlb2YgZWwuc2Nyb2xsSW50b1ZpZXcgPT09IFwiZnVuY3Rpb25cIikgZWwuc2Nyb2xsSW50b1ZpZXcoeyBiZWhhdmlvcjogXCJzbW9vdGhcIiB9KTtcblx0XHRlbHNlIHtcblx0XHRcdGNvbnN0IGJvdW5kcyA9IGdldENvbXBvbmVudEJvdW5kaW5nUmVjdChpbnN0YW5jZSk7XG5cdFx0XHRjb25zdCBzY3JvbGxUYXJnZXQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuXHRcdFx0Y29uc3Qgc3R5bGVzID0ge1xuXHRcdFx0XHQuLi5nZXRTdHlsZXMoYm91bmRzKSxcblx0XHRcdFx0cG9zaXRpb246IFwiYWJzb2x1dGVcIlxuXHRcdFx0fTtcblx0XHRcdE9iamVjdC5hc3NpZ24oc2Nyb2xsVGFyZ2V0LnN0eWxlLCBzdHlsZXMpO1xuXHRcdFx0ZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChzY3JvbGxUYXJnZXQpO1xuXHRcdFx0c2Nyb2xsVGFyZ2V0LnNjcm9sbEludG9WaWV3KHsgYmVoYXZpb3I6IFwic21vb3RoXCIgfSk7XG5cdFx0XHRzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdFx0ZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChzY3JvbGxUYXJnZXQpO1xuXHRcdFx0fSwgMmUzKTtcblx0XHR9XG5cdFx0c2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHRjb25zdCBib3VuZHMgPSBnZXRDb21wb25lbnRCb3VuZGluZ1JlY3QoaW5zdGFuY2UpO1xuXHRcdFx0aWYgKGJvdW5kcy53aWR0aCB8fCBib3VuZHMuaGVpZ2h0KSB7XG5cdFx0XHRcdGNvbnN0IG5hbWUgPSBnZXRJbnN0YW5jZU5hbWUoaW5zdGFuY2UpO1xuXHRcdFx0XHRjb25zdCBlbCA9IGdldENvbnRhaW5lckVsZW1lbnQoKTtcblx0XHRcdFx0ZWwgPyB1cGRhdGUoe1xuXHRcdFx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRcdFx0bmFtZSxcblx0XHRcdFx0XHRib3VuZHNcblx0XHRcdFx0fSkgOiBjcmVhdGUoe1xuXHRcdFx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRcdFx0bmFtZSxcblx0XHRcdFx0XHRib3VuZHNcblx0XHRcdFx0fSk7XG5cdFx0XHRcdHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0XHRcdGlmIChlbCkgZWwuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuXHRcdFx0XHR9LCAxNTAwKTtcblx0XHRcdH1cblx0XHR9LCAxMjAwKTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50LWluc3BlY3Rvci9pbmRleC50c1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0NPTVBPTkVOVF9JTlNQRUNUT1JfRU5BQkxFRF9fID8/PSB0cnVlO1xuZnVuY3Rpb24gdG9nZ2xlQ29tcG9uZW50SW5zcGVjdG9yRW5hYmxlZChlbmFibGVkKSB7XG5cdHRhcmdldC5fX1ZVRV9ERVZUT09MU19DT01QT05FTlRfSU5TUEVDVE9SX0VOQUJMRURfXyA9IGVuYWJsZWQ7XG59XG5mdW5jdGlvbiB3YWl0Rm9ySW5zcGVjdG9ySW5pdChjYikge1xuXHRsZXQgdG90YWwgPSAwO1xuXHRjb25zdCB0aW1lciA9IHNldEludGVydmFsKCgpID0+IHtcblx0XHRpZiAodGFyZ2V0Ll9fVlVFX0lOU1BFQ1RPUl9fKSB7XG5cdFx0XHRjbGVhckludGVydmFsKHRpbWVyKTtcblx0XHRcdHRvdGFsICs9IDMwO1xuXHRcdFx0Y2IoKTtcblx0XHR9XG5cdFx0aWYgKHRvdGFsID49IDVlMykgY2xlYXJJbnRlcnZhbCh0aW1lcik7XG5cdH0sIDMwKTtcbn1cbmZ1bmN0aW9uIHNldHVwSW5zcGVjdG9yKCkge1xuXHRjb25zdCBpbnNwZWN0b3IgPSB0YXJnZXQuX19WVUVfSU5TUEVDVE9SX187XG5cdGNvbnN0IF9vcGVuSW5FZGl0b3IgPSBpbnNwZWN0b3Iub3BlbkluRWRpdG9yO1xuXHRpbnNwZWN0b3Iub3BlbkluRWRpdG9yID0gYXN5bmMgKC4uLnBhcmFtcykgPT4ge1xuXHRcdGluc3BlY3Rvci5kaXNhYmxlKCk7XG5cdFx0X29wZW5JbkVkaXRvciguLi5wYXJhbXMpO1xuXHR9O1xufVxuZnVuY3Rpb24gZ2V0Q29tcG9uZW50SW5zcGVjdG9yKCkge1xuXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRmdW5jdGlvbiBzZXR1cCgpIHtcblx0XHRcdHNldHVwSW5zcGVjdG9yKCk7XG5cdFx0XHRyZXNvbHZlKHRhcmdldC5fX1ZVRV9JTlNQRUNUT1JfXyk7XG5cdFx0fVxuXHRcdGlmICghdGFyZ2V0Ll9fVlVFX0lOU1BFQ1RPUl9fKSB3YWl0Rm9ySW5zcGVjdG9ySW5pdCgoKSA9PiB7XG5cdFx0XHRzZXR1cCgpO1xuXHRcdH0pO1xuXHRcdGVsc2Ugc2V0dXAoKTtcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2hhcmVkL3N0dWItdnVlLnRzXG4vKipcbiogVG8gcHJldmVudCBpbmNsdWRlIGEgKipIVUdFKiogdnVlIHBhY2thZ2UgaW4gdGhlIGZpbmFsIGJ1bmRsZSBvZiBjaHJvbWUgZXh0IC8gZWxlY3Ryb25cbiogd2Ugc3R1YiB0aGUgbmVjZXNzYXJ5IHZ1ZSBtb2R1bGUuXG4qIFRoaXMgaW1wbGVtZW50YXRpb24gaXMgYmFzZWQgb24gdGhlIDFjMzMyN2EwZmE1OTgzYWE5MDc4ZTNmN2JiMjMzMGY1NzI0MzU0MjUgY29tbWl0XG4qL1xuLyoqXG4qIEBmcm9tIFtAdnVlL3JlYWN0aXZpdHldKGh0dHBzOi8vZ2l0aHViLmNvbS92dWVqcy9jb3JlL2Jsb2IvMWMzMzI3YTBmYTU5ODNhYTkwNzhlM2Y3YmIyMzMwZjU3MjQzNTQyNS9wYWNrYWdlcy9yZWFjdGl2aXR5L3NyYy9jb25zdGFudHMudHMjTDE3LUwyMylcbiovXG5sZXQgUmVhY3RpdmVGbGFncyA9IC8qIEBfX1BVUkVfXyAqLyBmdW5jdGlvbihSZWFjdGl2ZUZsYWdzKSB7XG5cdFJlYWN0aXZlRmxhZ3NbXCJTS0lQXCJdID0gXCJfX3Zfc2tpcFwiO1xuXHRSZWFjdGl2ZUZsYWdzW1wiSVNfUkVBQ1RJVkVcIl0gPSBcIl9fdl9pc1JlYWN0aXZlXCI7XG5cdFJlYWN0aXZlRmxhZ3NbXCJJU19SRUFET05MWVwiXSA9IFwiX192X2lzUmVhZG9ubHlcIjtcblx0UmVhY3RpdmVGbGFnc1tcIklTX1NIQUxMT1dcIl0gPSBcIl9fdl9pc1NoYWxsb3dcIjtcblx0UmVhY3RpdmVGbGFnc1tcIlJBV1wiXSA9IFwiX192X3Jhd1wiO1xuXHRyZXR1cm4gUmVhY3RpdmVGbGFncztcbn0oe30pO1xuLyoqXG4qIEBmcm9tIFtAdnVlL3JlYWN0aXZpdHldKGh0dHBzOi8vZ2l0aHViLmNvbS92dWVqcy9jb3JlL2Jsb2IvMWMzMzI3YTBmYTU5ODNhYTkwNzhlM2Y3YmIyMzMwZjU3MjQzNTQyNS9wYWNrYWdlcy9yZWFjdGl2aXR5L3NyYy9yZWFjdGl2ZS50cyNMMzMwLUwzMzIpXG4qL1xuZnVuY3Rpb24gaXNSZWFkb25seSh2YWx1ZSkge1xuXHRyZXR1cm4gISEodmFsdWUgJiYgdmFsdWVbUmVhY3RpdmVGbGFncy5JU19SRUFET05MWV0pO1xufVxuLyoqXG4qIEBmcm9tIFtAdnVlL3JlYWN0aXZpdHldKGh0dHBzOi8vZ2l0aHViLmNvbS92dWVqcy9jb3JlL2Jsb2IvMWMzMzI3YTBmYTU5ODNhYTkwNzhlM2Y3YmIyMzMwZjU3MjQzNTQyNS9wYWNrYWdlcy9yZWFjdGl2aXR5L3NyYy9yZWFjdGl2ZS50cyNMMzEyLUwzMTcpXG4qL1xuZnVuY3Rpb24gaXNSZWFjdGl2ZSQxKHZhbHVlKSB7XG5cdGlmIChpc1JlYWRvbmx5KHZhbHVlKSkgcmV0dXJuIGlzUmVhY3RpdmUkMSh2YWx1ZVtSZWFjdGl2ZUZsYWdzLlJBV10pO1xuXHRyZXR1cm4gISEodmFsdWUgJiYgdmFsdWVbUmVhY3RpdmVGbGFncy5JU19SRUFDVElWRV0pO1xufVxuZnVuY3Rpb24gaXNSZWYkMShyKSB7XG5cdHJldHVybiAhIShyICYmIHIuX192X2lzUmVmID09PSB0cnVlKTtcbn1cbi8qKlxuKiBAZnJvbSBbQHZ1ZS9yZWFjdGl2aXR5XShodHRwczovL2dpdGh1Yi5jb20vdnVlanMvY29yZS9ibG9iLzFjMzMyN2EwZmE1OTgzYWE5MDc4ZTNmN2JiMjMzMGY1NzI0MzU0MjUvcGFja2FnZXMvcmVhY3Rpdml0eS9zcmMvcmVhY3RpdmUudHMjTDM3Mi1MMzc1KVxuKi9cbmZ1bmN0aW9uIHRvUmF3JDEob2JzZXJ2ZWQpIHtcblx0Y29uc3QgcmF3ID0gb2JzZXJ2ZWQgJiYgb2JzZXJ2ZWRbUmVhY3RpdmVGbGFncy5SQVddO1xuXHRyZXR1cm4gcmF3ID8gdG9SYXckMShyYXcpIDogb2JzZXJ2ZWQ7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvc3RhdGUvZWRpdG9yLnRzXG52YXIgU3RhdGVFZGl0b3IgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKCkge1xuXHRcdHRoaXMucmVmRWRpdG9yID0gbmV3IFJlZlN0YXRlRWRpdG9yKCk7XG5cdH1cblx0c2V0KG9iamVjdCwgcGF0aCwgdmFsdWUsIGNiKSB7XG5cdFx0Y29uc3Qgc2VjdGlvbnMgPSBBcnJheS5pc0FycmF5KHBhdGgpID8gcGF0aCA6IHBhdGguc3BsaXQoXCIuXCIpO1xuXHRcdHdoaWxlIChzZWN0aW9ucy5sZW5ndGggPiAxKSB7XG5cdFx0XHRjb25zdCBzZWN0aW9uID0gc2VjdGlvbnMuc2hpZnQoKTtcblx0XHRcdGlmIChvYmplY3QgaW5zdGFuY2VvZiBNYXApIG9iamVjdCA9IG9iamVjdC5nZXQoc2VjdGlvbik7XG5cdFx0XHRlbHNlIGlmIChvYmplY3QgaW5zdGFuY2VvZiBTZXQpIG9iamVjdCA9IEFycmF5LmZyb20ob2JqZWN0LnZhbHVlcygpKVtzZWN0aW9uXTtcblx0XHRcdGVsc2Ugb2JqZWN0ID0gb2JqZWN0W3NlY3Rpb25dO1xuXHRcdFx0aWYgKHRoaXMucmVmRWRpdG9yLmlzUmVmKG9iamVjdCkpIG9iamVjdCA9IHRoaXMucmVmRWRpdG9yLmdldChvYmplY3QpO1xuXHRcdH1cblx0XHRjb25zdCBmaWVsZCA9IHNlY3Rpb25zWzBdO1xuXHRcdGNvbnN0IGl0ZW0gPSB0aGlzLnJlZkVkaXRvci5nZXQob2JqZWN0KVtmaWVsZF07XG5cdFx0aWYgKGNiKSBjYihvYmplY3QsIGZpZWxkLCB2YWx1ZSk7XG5cdFx0ZWxzZSBpZiAodGhpcy5yZWZFZGl0b3IuaXNSZWYoaXRlbSkpIHRoaXMucmVmRWRpdG9yLnNldChpdGVtLCB2YWx1ZSk7XG5cdFx0ZWxzZSBvYmplY3RbZmllbGRdID0gdmFsdWU7XG5cdH1cblx0Z2V0KG9iamVjdCwgcGF0aCkge1xuXHRcdGNvbnN0IHNlY3Rpb25zID0gQXJyYXkuaXNBcnJheShwYXRoKSA/IHBhdGggOiBwYXRoLnNwbGl0KFwiLlwiKTtcblx0XHRmb3IgKGxldCBpID0gMDsgaSA8IHNlY3Rpb25zLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRpZiAob2JqZWN0IGluc3RhbmNlb2YgTWFwKSBvYmplY3QgPSBvYmplY3QuZ2V0KHNlY3Rpb25zW2ldKTtcblx0XHRcdGVsc2Ugb2JqZWN0ID0gb2JqZWN0W3NlY3Rpb25zW2ldXTtcblx0XHRcdGlmICh0aGlzLnJlZkVkaXRvci5pc1JlZihvYmplY3QpKSBvYmplY3QgPSB0aGlzLnJlZkVkaXRvci5nZXQob2JqZWN0KTtcblx0XHRcdGlmICghb2JqZWN0KSByZXR1cm4gdm9pZCAwO1xuXHRcdH1cblx0XHRyZXR1cm4gb2JqZWN0O1xuXHR9XG5cdGhhcyhvYmplY3QsIHBhdGgsIHBhcmVudCA9IGZhbHNlKSB7XG5cdFx0aWYgKHR5cGVvZiBvYmplY3QgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBmYWxzZTtcblx0XHRjb25zdCBzZWN0aW9ucyA9IEFycmF5LmlzQXJyYXkocGF0aCkgPyBwYXRoLnNsaWNlKCkgOiBwYXRoLnNwbGl0KFwiLlwiKTtcblx0XHRjb25zdCBzaXplID0gIXBhcmVudCA/IDEgOiAyO1xuXHRcdHdoaWxlIChvYmplY3QgJiYgc2VjdGlvbnMubGVuZ3RoID4gc2l6ZSkge1xuXHRcdFx0Y29uc3Qgc2VjdGlvbiA9IHNlY3Rpb25zLnNoaWZ0KCk7XG5cdFx0XHRvYmplY3QgPSBvYmplY3Rbc2VjdGlvbl07XG5cdFx0XHRpZiAodGhpcy5yZWZFZGl0b3IuaXNSZWYob2JqZWN0KSkgb2JqZWN0ID0gdGhpcy5yZWZFZGl0b3IuZ2V0KG9iamVjdCk7XG5cdFx0fVxuXHRcdHJldHVybiBvYmplY3QgIT0gbnVsbCAmJiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBzZWN0aW9uc1swXSk7XG5cdH1cblx0Y3JlYXRlRGVmYXVsdFNldENhbGxiYWNrKHN0YXRlKSB7XG5cdFx0cmV0dXJuIChvYmplY3QsIGZpZWxkLCB2YWx1ZSkgPT4ge1xuXHRcdFx0aWYgKHN0YXRlLnJlbW92ZSB8fCBzdGF0ZS5uZXdLZXkpIGlmIChBcnJheS5pc0FycmF5KG9iamVjdCkpIG9iamVjdC5zcGxpY2UoZmllbGQsIDEpO1xuXHRcdFx0ZWxzZSBpZiAodG9SYXckMShvYmplY3QpIGluc3RhbmNlb2YgTWFwKSBvYmplY3QuZGVsZXRlKGZpZWxkKTtcblx0XHRcdGVsc2UgaWYgKHRvUmF3JDEob2JqZWN0KSBpbnN0YW5jZW9mIFNldCkgb2JqZWN0LmRlbGV0ZShBcnJheS5mcm9tKG9iamVjdC52YWx1ZXMoKSlbZmllbGRdKTtcblx0XHRcdGVsc2UgUmVmbGVjdC5kZWxldGVQcm9wZXJ0eShvYmplY3QsIGZpZWxkKTtcblx0XHRcdGlmICghc3RhdGUucmVtb3ZlKSB7XG5cdFx0XHRcdGNvbnN0IHRhcmdldCA9IG9iamVjdFtzdGF0ZS5uZXdLZXkgfHwgZmllbGRdO1xuXHRcdFx0XHRpZiAodGhpcy5yZWZFZGl0b3IuaXNSZWYodGFyZ2V0KSkgdGhpcy5yZWZFZGl0b3Iuc2V0KHRhcmdldCwgdmFsdWUpO1xuXHRcdFx0XHRlbHNlIGlmICh0b1JhdyQxKG9iamVjdCkgaW5zdGFuY2VvZiBNYXApIG9iamVjdC5zZXQoc3RhdGUubmV3S2V5IHx8IGZpZWxkLCB2YWx1ZSk7XG5cdFx0XHRcdGVsc2UgaWYgKHRvUmF3JDEob2JqZWN0KSBpbnN0YW5jZW9mIFNldCkgb2JqZWN0LmFkZCh2YWx1ZSk7XG5cdFx0XHRcdGVsc2Ugb2JqZWN0W3N0YXRlLm5ld0tleSB8fCBmaWVsZF0gPSB2YWx1ZTtcblx0XHRcdH1cblx0XHR9O1xuXHR9XG59O1xudmFyIFJlZlN0YXRlRWRpdG9yID0gY2xhc3Mge1xuXHRzZXQocmVmLCB2YWx1ZSkge1xuXHRcdGlmIChpc1JlZiQxKHJlZikpIHJlZi52YWx1ZSA9IHZhbHVlO1xuXHRcdGVsc2Uge1xuXHRcdFx0aWYgKHJlZiBpbnN0YW5jZW9mIFNldCAmJiBBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuXHRcdFx0XHRyZWYuY2xlYXIoKTtcblx0XHRcdFx0dmFsdWUuZm9yRWFjaCgodikgPT4gcmVmLmFkZCh2KSk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdGNvbnN0IGN1cnJlbnRLZXlzID0gT2JqZWN0LmtleXModmFsdWUpO1xuXHRcdFx0aWYgKHJlZiBpbnN0YW5jZW9mIE1hcCkge1xuXHRcdFx0XHRjb25zdCBwcmV2aW91c0tleXNTZXQgPSBuZXcgU2V0KHJlZi5rZXlzKCkpO1xuXHRcdFx0XHRjdXJyZW50S2V5cy5mb3JFYWNoKChrZXkpID0+IHtcblx0XHRcdFx0XHRyZWYuc2V0KGtleSwgUmVmbGVjdC5nZXQodmFsdWUsIGtleSkpO1xuXHRcdFx0XHRcdHByZXZpb3VzS2V5c1NldC5kZWxldGUoa2V5KTtcblx0XHRcdFx0fSk7XG5cdFx0XHRcdHByZXZpb3VzS2V5c1NldC5mb3JFYWNoKChrZXkpID0+IHJlZi5kZWxldGUoa2V5KSk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdGNvbnN0IHByZXZpb3VzS2V5c1NldCA9IG5ldyBTZXQoT2JqZWN0LmtleXMocmVmKSk7XG5cdFx0XHRjdXJyZW50S2V5cy5mb3JFYWNoKChrZXkpID0+IHtcblx0XHRcdFx0UmVmbGVjdC5zZXQocmVmLCBrZXksIFJlZmxlY3QuZ2V0KHZhbHVlLCBrZXkpKTtcblx0XHRcdFx0cHJldmlvdXNLZXlzU2V0LmRlbGV0ZShrZXkpO1xuXHRcdFx0fSk7XG5cdFx0XHRwcmV2aW91c0tleXNTZXQuZm9yRWFjaCgoa2V5KSA9PiBSZWZsZWN0LmRlbGV0ZVByb3BlcnR5KHJlZiwga2V5KSk7XG5cdFx0fVxuXHR9XG5cdGdldChyZWYpIHtcblx0XHRyZXR1cm4gaXNSZWYkMShyZWYpID8gcmVmLnZhbHVlIDogcmVmO1xuXHR9XG5cdGlzUmVmKHJlZikge1xuXHRcdHJldHVybiBpc1JlZiQxKHJlZikgfHwgaXNSZWFjdGl2ZSQxKHJlZik7XG5cdH1cbn07XG5hc3luYyBmdW5jdGlvbiBlZGl0Q29tcG9uZW50U3RhdGUocGF5bG9hZCwgc3RhdGVFZGl0b3IpIHtcblx0Y29uc3QgeyBwYXRoLCBub2RlSWQsIHN0YXRlLCB0eXBlIH0gPSBwYXlsb2FkO1xuXHRjb25zdCBpbnN0YW5jZSA9IGdldENvbXBvbmVudEluc3RhbmNlKGFjdGl2ZUFwcFJlY29yZC52YWx1ZSwgbm9kZUlkKTtcblx0aWYgKCFpbnN0YW5jZSkgcmV0dXJuO1xuXHRjb25zdCB0YXJnZXRQYXRoID0gcGF0aC5zbGljZSgpO1xuXHRsZXQgdGFyZ2V0O1xuXHRpZiAoT2JqZWN0LmtleXMoaW5zdGFuY2UucHJvcHMpLmluY2x1ZGVzKHBhdGhbMF0pKSB0YXJnZXQgPSBpbnN0YW5jZS5wcm9wcztcblx0ZWxzZSBpZiAoaW5zdGFuY2UuZGV2dG9vbHNSYXdTZXR1cFN0YXRlICYmIE9iamVjdC5rZXlzKGluc3RhbmNlLmRldnRvb2xzUmF3U2V0dXBTdGF0ZSkuaW5jbHVkZXMocGF0aFswXSkpIHRhcmdldCA9IGluc3RhbmNlLmRldnRvb2xzUmF3U2V0dXBTdGF0ZTtcblx0ZWxzZSBpZiAoaW5zdGFuY2UuZGF0YSAmJiBPYmplY3Qua2V5cyhpbnN0YW5jZS5kYXRhKS5pbmNsdWRlcyhwYXRoWzBdKSkgdGFyZ2V0ID0gaW5zdGFuY2UuZGF0YTtcblx0ZWxzZSB0YXJnZXQgPSBpbnN0YW5jZS5wcm94eTtcblx0aWYgKHRhcmdldCAmJiB0YXJnZXRQYXRoKSB7XG5cdFx0aWYgKHN0YXRlLnR5cGUgPT09IFwib2JqZWN0XCIgJiYgdHlwZSA9PT0gXCJyZWFjdGl2ZVwiKSB7fVxuXHRcdHN0YXRlRWRpdG9yLnNldCh0YXJnZXQsIHRhcmdldFBhdGgsIHN0YXRlLnZhbHVlLCBzdGF0ZUVkaXRvci5jcmVhdGVEZWZhdWx0U2V0Q2FsbGJhY2soc3RhdGUpKTtcblx0fVxufVxuY29uc3Qgc3RhdGVFZGl0b3IgPSBuZXcgU3RhdGVFZGl0b3IoKTtcbmFzeW5jIGZ1bmN0aW9uIGVkaXRTdGF0ZShwYXlsb2FkKSB7XG5cdGVkaXRDb21wb25lbnRTdGF0ZShwYXlsb2FkLCBzdGF0ZUVkaXRvcik7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS90aW1lbGluZS9zdG9yYWdlLnRzXG5jb25zdCBUSU1FTElORV9MQVlFUlNfU1RBVEVfU1RPUkFHRV9JRCA9IFwiX19WVUVfREVWVE9PTFNfS0lUX1RJTUVMSU5FX0xBWUVSU19TVEFURV9fXCI7XG5mdW5jdGlvbiBhZGRUaW1lbGluZUxheWVyc1N0YXRlVG9TdG9yYWdlKHN0YXRlKSB7XG5cdGlmICghaXNCcm93c2VyIHx8IHR5cGVvZiBsb2NhbFN0b3JhZ2UgPT09IFwidW5kZWZpbmVkXCIgfHwgbG9jYWxTdG9yYWdlID09PSBudWxsKSByZXR1cm47XG5cdGxvY2FsU3RvcmFnZS5zZXRJdGVtKFRJTUVMSU5FX0xBWUVSU19TVEFURV9TVE9SQUdFX0lELCBKU09OLnN0cmluZ2lmeShzdGF0ZSkpO1xufVxuZnVuY3Rpb24gZ2V0VGltZWxpbmVMYXllcnNTdGF0ZUZyb21TdG9yYWdlKCkge1xuXHRpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIiB8fCAhaXNCcm93c2VyIHx8IHR5cGVvZiBsb2NhbFN0b3JhZ2UgPT09IFwidW5kZWZpbmVkXCIgfHwgbG9jYWxTdG9yYWdlID09PSBudWxsKSByZXR1cm4ge1xuXHRcdHJlY29yZGluZ1N0YXRlOiBmYWxzZSxcblx0XHRtb3VzZUV2ZW50RW5hYmxlZDogZmFsc2UsXG5cdFx0a2V5Ym9hcmRFdmVudEVuYWJsZWQ6IGZhbHNlLFxuXHRcdGNvbXBvbmVudEV2ZW50RW5hYmxlZDogZmFsc2UsXG5cdFx0cGVyZm9ybWFuY2VFdmVudEVuYWJsZWQ6IGZhbHNlLFxuXHRcdHNlbGVjdGVkOiBcIlwiXG5cdH07XG5cdGNvbnN0IHN0YXRlID0gdHlwZW9mIGxvY2FsU3RvcmFnZS5nZXRJdGVtICE9PSBcInVuZGVmaW5lZFwiID8gbG9jYWxTdG9yYWdlLmdldEl0ZW0oVElNRUxJTkVfTEFZRVJTX1NUQVRFX1NUT1JBR0VfSUQpIDogbnVsbDtcblx0cmV0dXJuIHN0YXRlID8gSlNPTi5wYXJzZShzdGF0ZSkgOiB7XG5cdFx0cmVjb3JkaW5nU3RhdGU6IGZhbHNlLFxuXHRcdG1vdXNlRXZlbnRFbmFibGVkOiBmYWxzZSxcblx0XHRrZXlib2FyZEV2ZW50RW5hYmxlZDogZmFsc2UsXG5cdFx0Y29tcG9uZW50RXZlbnRFbmFibGVkOiBmYWxzZSxcblx0XHRwZXJmb3JtYW5jZUV2ZW50RW5hYmxlZDogZmFsc2UsXG5cdFx0c2VsZWN0ZWQ6IFwiXCJcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jdHgvdGltZWxpbmUudHNcbnRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfVElNRUxJTkVfTEFZRVJTID8/PSBbXTtcbmNvbnN0IGRldnRvb2xzVGltZWxpbmVMYXllcnMgPSBuZXcgUHJveHkodGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9USU1FTElORV9MQVlFUlMsIHsgZ2V0KHRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpIHtcblx0cmV0dXJuIFJlZmxlY3QuZ2V0KHRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpO1xufSB9KTtcbmZ1bmN0aW9uIGFkZFRpbWVsaW5lTGF5ZXIob3B0aW9ucywgZGVzY3JpcHRvcikge1xuXHRkZXZ0b29sc1N0YXRlLnRpbWVsaW5lTGF5ZXJzU3RhdGVbZGVzY3JpcHRvci5pZF0gPSBmYWxzZTtcblx0ZGV2dG9vbHNUaW1lbGluZUxheWVycy5wdXNoKHtcblx0XHQuLi5vcHRpb25zLFxuXHRcdGRlc2NyaXB0b3JJZDogZGVzY3JpcHRvci5pZCxcblx0XHRhcHBSZWNvcmQ6IGdldEFwcFJlY29yZChkZXNjcmlwdG9yLmFwcClcblx0fSk7XG59XG5mdW5jdGlvbiB1cGRhdGVUaW1lbGluZUxheWVyc1N0YXRlKHN0YXRlKSB7XG5cdGNvbnN0IHVwZGF0ZWRTdGF0ZSA9IHtcblx0XHQuLi5kZXZ0b29sc1N0YXRlLnRpbWVsaW5lTGF5ZXJzU3RhdGUsXG5cdFx0Li4uc3RhdGVcblx0fTtcblx0YWRkVGltZWxpbmVMYXllcnNTdGF0ZVRvU3RvcmFnZSh1cGRhdGVkU3RhdGUpO1xuXHR1cGRhdGVEZXZUb29sc1N0YXRlKHsgdGltZWxpbmVMYXllcnNTdGF0ZTogdXBkYXRlZFN0YXRlIH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2N0eC9pbnNwZWN0b3IudHNcbnRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfSU5TUEVDVE9SX18gPz89IFtdO1xuY29uc3QgZGV2dG9vbHNJbnNwZWN0b3IgPSBuZXcgUHJveHkodGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9JTlNQRUNUT1JfXywgeyBnZXQodGFyZ2V0LCBwcm9wLCByZWNlaXZlcikge1xuXHRyZXR1cm4gUmVmbGVjdC5nZXQodGFyZ2V0LCBwcm9wLCByZWNlaXZlcik7XG59IH0pO1xuY29uc3QgY2FsbEluc3BlY3RvclVwZGF0ZWRIb29rID0gZGVib3VuY2UoKCkgPT4ge1xuXHRkZXZ0b29sc0NvbnRleHQuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5cy5TRU5EX0lOU1BFQ1RPUl9UT19DTElFTlQsIGdldEFjdGl2ZUluc3BlY3RvcnMoKSk7XG59KTtcbmZ1bmN0aW9uIGFkZEluc3BlY3RvcihpbnNwZWN0b3IsIGRlc2NyaXB0b3IpIHtcblx0ZGV2dG9vbHNJbnNwZWN0b3IucHVzaCh7XG5cdFx0b3B0aW9uczogaW5zcGVjdG9yLFxuXHRcdGRlc2NyaXB0b3IsXG5cdFx0dHJlZUZpbHRlclBsYWNlaG9sZGVyOiBpbnNwZWN0b3IudHJlZUZpbHRlclBsYWNlaG9sZGVyID8/IFwiU2VhcmNoIHRyZWUuLi5cIixcblx0XHRzdGF0ZUZpbHRlclBsYWNlaG9sZGVyOiBpbnNwZWN0b3Iuc3RhdGVGaWx0ZXJQbGFjZWhvbGRlciA/PyBcIlNlYXJjaCBzdGF0ZS4uLlwiLFxuXHRcdHRyZWVGaWx0ZXI6IFwiXCIsXG5cdFx0c2VsZWN0ZWROb2RlSWQ6IFwiXCIsXG5cdFx0YXBwUmVjb3JkOiBnZXRBcHBSZWNvcmQoZGVzY3JpcHRvci5hcHApXG5cdH0pO1xuXHRjYWxsSW5zcGVjdG9yVXBkYXRlZEhvb2soKTtcbn1cbmZ1bmN0aW9uIGdldEFjdGl2ZUluc3BlY3RvcnMoKSB7XG5cdHJldHVybiBkZXZ0b29sc0luc3BlY3Rvci5maWx0ZXIoKGluc3BlY3RvcikgPT4gaW5zcGVjdG9yLmRlc2NyaXB0b3IuYXBwID09PSBhY3RpdmVBcHBSZWNvcmQudmFsdWUuYXBwKS5maWx0ZXIoKGluc3BlY3RvcikgPT4gaW5zcGVjdG9yLmRlc2NyaXB0b3IuaWQgIT09IFwiY29tcG9uZW50c1wiKS5tYXAoKGluc3BlY3RvcikgPT4ge1xuXHRcdGNvbnN0IGRlc2NyaXB0b3IgPSBpbnNwZWN0b3IuZGVzY3JpcHRvcjtcblx0XHRjb25zdCBvcHRpb25zID0gaW5zcGVjdG9yLm9wdGlvbnM7XG5cdFx0cmV0dXJuIHtcblx0XHRcdGlkOiBvcHRpb25zLmlkLFxuXHRcdFx0bGFiZWw6IG9wdGlvbnMubGFiZWwsXG5cdFx0XHRsb2dvOiBkZXNjcmlwdG9yLmxvZ28sXG5cdFx0XHRpY29uOiBgY3VzdG9tLWljLWJhc2VsaW5lLSR7b3B0aW9ucz8uaWNvbj8ucmVwbGFjZSgvXy9nLCBcIi1cIil9YCxcblx0XHRcdHBhY2thZ2VOYW1lOiBkZXNjcmlwdG9yLnBhY2thZ2VOYW1lLFxuXHRcdFx0aG9tZXBhZ2U6IGRlc2NyaXB0b3IuaG9tZXBhZ2UsXG5cdFx0XHRwbHVnaW5JZDogZGVzY3JpcHRvci5pZFxuXHRcdH07XG5cdH0pO1xufVxuZnVuY3Rpb24gZ2V0SW5zcGVjdG9ySW5mbyhpZCkge1xuXHRjb25zdCBpbnNwZWN0b3IgPSBnZXRJbnNwZWN0b3IoaWQsIGFjdGl2ZUFwcFJlY29yZC52YWx1ZS5hcHApO1xuXHRpZiAoIWluc3BlY3RvcikgcmV0dXJuO1xuXHRjb25zdCBkZXNjcmlwdG9yID0gaW5zcGVjdG9yLmRlc2NyaXB0b3I7XG5cdGNvbnN0IG9wdGlvbnMgPSBpbnNwZWN0b3Iub3B0aW9ucztcblx0Y29uc3QgdGltZWxpbmVMYXllcnMgPSBkZXZ0b29sc1RpbWVsaW5lTGF5ZXJzLmZpbHRlcigobGF5ZXIpID0+IGxheWVyLmRlc2NyaXB0b3JJZCA9PT0gZGVzY3JpcHRvci5pZCkubWFwKChpdGVtKSA9PiAoe1xuXHRcdGlkOiBpdGVtLmlkLFxuXHRcdGxhYmVsOiBpdGVtLmxhYmVsLFxuXHRcdGNvbG9yOiBpdGVtLmNvbG9yXG5cdH0pKTtcblx0cmV0dXJuIHtcblx0XHRpZDogb3B0aW9ucy5pZCxcblx0XHRsYWJlbDogb3B0aW9ucy5sYWJlbCxcblx0XHRsb2dvOiBkZXNjcmlwdG9yLmxvZ28sXG5cdFx0cGFja2FnZU5hbWU6IGRlc2NyaXB0b3IucGFja2FnZU5hbWUsXG5cdFx0aG9tZXBhZ2U6IGRlc2NyaXB0b3IuaG9tZXBhZ2UsXG5cdFx0dGltZWxpbmVMYXllcnMsXG5cdFx0dHJlZUZpbHRlclBsYWNlaG9sZGVyOiBpbnNwZWN0b3IudHJlZUZpbHRlclBsYWNlaG9sZGVyLFxuXHRcdHN0YXRlRmlsdGVyUGxhY2Vob2xkZXI6IGluc3BlY3Rvci5zdGF0ZUZpbHRlclBsYWNlaG9sZGVyXG5cdH07XG59XG5mdW5jdGlvbiBnZXRJbnNwZWN0b3IoaWQsIGFwcCkge1xuXHRyZXR1cm4gZGV2dG9vbHNJbnNwZWN0b3IuZmluZCgoaW5zcGVjdG9yKSA9PiBpbnNwZWN0b3Iub3B0aW9ucy5pZCA9PT0gaWQgJiYgKGFwcCA/IGluc3BlY3Rvci5kZXNjcmlwdG9yLmFwcCA9PT0gYXBwIDogdHJ1ZSkpO1xufVxuZnVuY3Rpb24gZ2V0SW5zcGVjdG9yQWN0aW9ucyhpZCkge1xuXHRyZXR1cm4gZ2V0SW5zcGVjdG9yKGlkKT8ub3B0aW9ucy5hY3Rpb25zO1xufVxuZnVuY3Rpb24gZ2V0SW5zcGVjdG9yTm9kZUFjdGlvbnMoaWQpIHtcblx0cmV0dXJuIGdldEluc3BlY3RvcihpZCk/Lm9wdGlvbnMubm9kZUFjdGlvbnM7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY3R4L2hvb2sudHNcbmxldCBEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMgPSAvKiBAX19QVVJFX18gKi8gZnVuY3Rpb24oRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzKSB7XG5cdERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5c1tcIlZJU0lUX0NPTVBPTkVOVF9UUkVFXCJdID0gXCJ2aXNpdENvbXBvbmVudFRyZWVcIjtcblx0RGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzW1wiSU5TUEVDVF9DT01QT05FTlRcIl0gPSBcImluc3BlY3RDb21wb25lbnRcIjtcblx0RGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzW1wiRURJVF9DT01QT05FTlRfU1RBVEVcIl0gPSBcImVkaXRDb21wb25lbnRTdGF0ZVwiO1xuXHREZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXNbXCJHRVRfSU5TUEVDVE9SX1RSRUVcIl0gPSBcImdldEluc3BlY3RvclRyZWVcIjtcblx0RGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzW1wiR0VUX0lOU1BFQ1RPUl9TVEFURVwiXSA9IFwiZ2V0SW5zcGVjdG9yU3RhdGVcIjtcblx0RGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzW1wiRURJVF9JTlNQRUNUT1JfU1RBVEVcIl0gPSBcImVkaXRJbnNwZWN0b3JTdGF0ZVwiO1xuXHREZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXNbXCJJTlNQRUNUX1RJTUVMSU5FX0VWRU5UXCJdID0gXCJpbnNwZWN0VGltZWxpbmVFdmVudFwiO1xuXHREZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXNbXCJUSU1FTElORV9DTEVBUkVEXCJdID0gXCJ0aW1lbGluZUNsZWFyZWRcIjtcblx0RGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzW1wiU0VUX1BMVUdJTl9TRVRUSU5HU1wiXSA9IFwic2V0UGx1Z2luU2V0dGluZ3NcIjtcblx0cmV0dXJuIERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cztcbn0oe30pO1xubGV0IERldlRvb2xzQ29udGV4dEhvb2tLZXlzID0gLyogQF9fUFVSRV9fICovIGZ1bmN0aW9uKERldlRvb2xzQ29udGV4dEhvb2tLZXlzKSB7XG5cdERldlRvb2xzQ29udGV4dEhvb2tLZXlzW1wiQUREX0lOU1BFQ1RPUlwiXSA9IFwiYWRkSW5zcGVjdG9yXCI7XG5cdERldlRvb2xzQ29udGV4dEhvb2tLZXlzW1wiU0VORF9JTlNQRUNUT1JfVFJFRVwiXSA9IFwic2VuZEluc3BlY3RvclRyZWVcIjtcblx0RGV2VG9vbHNDb250ZXh0SG9va0tleXNbXCJTRU5EX0lOU1BFQ1RPUl9TVEFURVwiXSA9IFwic2VuZEluc3BlY3RvclN0YXRlXCI7XG5cdERldlRvb2xzQ29udGV4dEhvb2tLZXlzW1wiQ1VTVE9NX0lOU1BFQ1RPUl9TRUxFQ1RfTk9ERVwiXSA9IFwiY3VzdG9tSW5zcGVjdG9yU2VsZWN0Tm9kZVwiO1xuXHREZXZUb29sc0NvbnRleHRIb29rS2V5c1tcIlRJTUVMSU5FX0xBWUVSX0FEREVEXCJdID0gXCJ0aW1lbGluZUxheWVyQWRkZWRcIjtcblx0RGV2VG9vbHNDb250ZXh0SG9va0tleXNbXCJUSU1FTElORV9FVkVOVF9BRERFRFwiXSA9IFwidGltZWxpbmVFdmVudEFkZGVkXCI7XG5cdERldlRvb2xzQ29udGV4dEhvb2tLZXlzW1wiR0VUX0NPTVBPTkVOVF9JTlNUQU5DRVNcIl0gPSBcImdldENvbXBvbmVudEluc3RhbmNlc1wiO1xuXHREZXZUb29sc0NvbnRleHRIb29rS2V5c1tcIkdFVF9DT01QT05FTlRfQk9VTkRTXCJdID0gXCJnZXRDb21wb25lbnRCb3VuZHNcIjtcblx0RGV2VG9vbHNDb250ZXh0SG9va0tleXNbXCJHRVRfQ09NUE9ORU5UX05BTUVcIl0gPSBcImdldENvbXBvbmVudE5hbWVcIjtcblx0RGV2VG9vbHNDb250ZXh0SG9va0tleXNbXCJDT01QT05FTlRfSElHSExJR0hUXCJdID0gXCJjb21wb25lbnRIaWdobGlnaHRcIjtcblx0RGV2VG9vbHNDb250ZXh0SG9va0tleXNbXCJDT01QT05FTlRfVU5ISUdITElHSFRcIl0gPSBcImNvbXBvbmVudFVuaGlnaGxpZ2h0XCI7XG5cdHJldHVybiBEZXZUb29sc0NvbnRleHRIb29rS2V5cztcbn0oe30pO1xubGV0IERldlRvb2xzTWVzc2FnaW5nSG9va0tleXMgPSAvKiBAX19QVVJFX18gKi8gZnVuY3Rpb24oRGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5cykge1xuXHREZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzW1wiU0VORF9JTlNQRUNUT1JfVFJFRV9UT19DTElFTlRcIl0gPSBcInNlbmRJbnNwZWN0b3JUcmVlVG9DbGllbnRcIjtcblx0RGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5c1tcIlNFTkRfSU5TUEVDVE9SX1NUQVRFX1RPX0NMSUVOVFwiXSA9IFwic2VuZEluc3BlY3RvclN0YXRlVG9DbGllbnRcIjtcblx0RGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5c1tcIlNFTkRfVElNRUxJTkVfRVZFTlRfVE9fQ0xJRU5UXCJdID0gXCJzZW5kVGltZWxpbmVFdmVudFRvQ2xpZW50XCI7XG5cdERldlRvb2xzTWVzc2FnaW5nSG9va0tleXNbXCJTRU5EX0lOU1BFQ1RPUl9UT19DTElFTlRcIl0gPSBcInNlbmRJbnNwZWN0b3JUb0NsaWVudFwiO1xuXHREZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzW1wiU0VORF9BQ1RJVkVfQVBQX1VOTU9VTlRFRF9UT19DTElFTlRcIl0gPSBcInNlbmRBY3RpdmVBcHBVcGRhdGVkVG9DbGllbnRcIjtcblx0RGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5c1tcIkRFVlRPT0xTX1NUQVRFX1VQREFURURcIl0gPSBcImRldnRvb2xzU3RhdGVVcGRhdGVkXCI7XG5cdERldlRvb2xzTWVzc2FnaW5nSG9va0tleXNbXCJERVZUT09MU19DT05ORUNURURfVVBEQVRFRFwiXSA9IFwiZGV2dG9vbHNDb25uZWN0ZWRVcGRhdGVkXCI7XG5cdERldlRvb2xzTWVzc2FnaW5nSG9va0tleXNbXCJST1VURVJfSU5GT19VUERBVEVEXCJdID0gXCJyb3V0ZXJJbmZvVXBkYXRlZFwiO1xuXHRyZXR1cm4gRGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5cztcbn0oe30pO1xuZnVuY3Rpb24gY3JlYXRlRGV2VG9vbHNDdHhIb29rcygpIHtcblx0Y29uc3QgaG9va3MgPSBjcmVhdGVIb29rcygpO1xuXHRob29rcy5ob29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLkFERF9JTlNQRUNUT1IsICh7IGluc3BlY3RvciwgcGx1Z2luIH0pID0+IHtcblx0XHRhZGRJbnNwZWN0b3IoaW5zcGVjdG9yLCBwbHVnaW4uZGVzY3JpcHRvcik7XG5cdH0pO1xuXHRjb25zdCBkZWJvdW5jZVNlbmRJbnNwZWN0b3JUcmVlID0gZGVib3VuY2UoYXN5bmMgKHsgaW5zcGVjdG9ySWQsIHBsdWdpbiB9KSA9PiB7XG5cdFx0aWYgKCFpbnNwZWN0b3JJZCB8fCAhcGx1Z2luPy5kZXNjcmlwdG9yPy5hcHAgfHwgZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0Y29uc3QgaW5zcGVjdG9yID0gZ2V0SW5zcGVjdG9yKGluc3BlY3RvcklkLCBwbHVnaW4uZGVzY3JpcHRvci5hcHApO1xuXHRcdGNvbnN0IF9wYXlsb2FkID0ge1xuXHRcdFx0YXBwOiBwbHVnaW4uZGVzY3JpcHRvci5hcHAsXG5cdFx0XHRpbnNwZWN0b3JJZCxcblx0XHRcdGZpbHRlcjogaW5zcGVjdG9yPy50cmVlRmlsdGVyIHx8IFwiXCIsXG5cdFx0XHRyb290Tm9kZXM6IFtdXG5cdFx0fTtcblx0XHRhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuXHRcdFx0aG9va3MuY2FsbEhvb2tXaXRoKGFzeW5jIChjYWxsYmFja3MpID0+IHtcblx0XHRcdFx0YXdhaXQgUHJvbWlzZS5hbGwoY2FsbGJhY2tzLm1hcCgoY2IpID0+IGNiKF9wYXlsb2FkKSkpO1xuXHRcdFx0XHRyZXNvbHZlKCk7XG5cdFx0XHR9LCBEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuR0VUX0lOU1BFQ1RPUl9UUkVFKTtcblx0XHR9KTtcblx0XHRob29rcy5jYWxsSG9va1dpdGgoYXN5bmMgKGNhbGxiYWNrcykgPT4ge1xuXHRcdFx0YXdhaXQgUHJvbWlzZS5hbGwoY2FsbGJhY2tzLm1hcCgoY2IpID0+IGNiKHtcblx0XHRcdFx0aW5zcGVjdG9ySWQsXG5cdFx0XHRcdHJvb3ROb2RlczogX3BheWxvYWQucm9vdE5vZGVzXG5cdFx0XHR9KSkpO1xuXHRcdH0sIERldlRvb2xzTWVzc2FnaW5nSG9va0tleXMuU0VORF9JTlNQRUNUT1JfVFJFRV9UT19DTElFTlQpO1xuXHR9LCAxMjApO1xuXHRob29rcy5ob29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLlNFTkRfSU5TUEVDVE9SX1RSRUUsIGRlYm91bmNlU2VuZEluc3BlY3RvclRyZWUpO1xuXHRjb25zdCBkZWJvdW5jZVNlbmRJbnNwZWN0b3JTdGF0ZSA9IGRlYm91bmNlKGFzeW5jICh7IGluc3BlY3RvcklkLCBwbHVnaW4gfSkgPT4ge1xuXHRcdGlmICghaW5zcGVjdG9ySWQgfHwgIXBsdWdpbj8uZGVzY3JpcHRvcj8uYXBwIHx8IGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdGNvbnN0IGluc3BlY3RvciA9IGdldEluc3BlY3RvcihpbnNwZWN0b3JJZCwgcGx1Z2luLmRlc2NyaXB0b3IuYXBwKTtcblx0XHRjb25zdCBfcGF5bG9hZCA9IHtcblx0XHRcdGFwcDogcGx1Z2luLmRlc2NyaXB0b3IuYXBwLFxuXHRcdFx0aW5zcGVjdG9ySWQsXG5cdFx0XHRub2RlSWQ6IGluc3BlY3Rvcj8uc2VsZWN0ZWROb2RlSWQgfHwgXCJcIixcblx0XHRcdHN0YXRlOiBudWxsXG5cdFx0fTtcblx0XHRjb25zdCBjdHggPSB7IGN1cnJlbnRUYWI6IGBjdXN0b20taW5zcGVjdG9yOiR7aW5zcGVjdG9ySWR9YCB9O1xuXHRcdGlmIChfcGF5bG9hZC5ub2RlSWQpIGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0XHRob29rcy5jYWxsSG9va1dpdGgoYXN5bmMgKGNhbGxiYWNrcykgPT4ge1xuXHRcdFx0XHRhd2FpdCBQcm9taXNlLmFsbChjYWxsYmFja3MubWFwKChjYikgPT4gY2IoX3BheWxvYWQsIGN0eCkpKTtcblx0XHRcdFx0cmVzb2x2ZSgpO1xuXHRcdFx0fSwgRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLkdFVF9JTlNQRUNUT1JfU1RBVEUpO1xuXHRcdH0pO1xuXHRcdGhvb2tzLmNhbGxIb29rV2l0aChhc3luYyAoY2FsbGJhY2tzKSA9PiB7XG5cdFx0XHRhd2FpdCBQcm9taXNlLmFsbChjYWxsYmFja3MubWFwKChjYikgPT4gY2Ioe1xuXHRcdFx0XHRpbnNwZWN0b3JJZCxcblx0XHRcdFx0bm9kZUlkOiBfcGF5bG9hZC5ub2RlSWQsXG5cdFx0XHRcdHN0YXRlOiBfcGF5bG9hZC5zdGF0ZVxuXHRcdFx0fSkpKTtcblx0XHR9LCBEZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzLlNFTkRfSU5TUEVDVE9SX1NUQVRFX1RPX0NMSUVOVCk7XG5cdH0sIDEyMCk7XG5cdGhvb2tzLmhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuU0VORF9JTlNQRUNUT1JfU1RBVEUsIGRlYm91bmNlU2VuZEluc3BlY3RvclN0YXRlKTtcblx0aG9va3MuaG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5DVVNUT01fSU5TUEVDVE9SX1NFTEVDVF9OT0RFLCAoeyBpbnNwZWN0b3JJZCwgbm9kZUlkLCBwbHVnaW4gfSkgPT4ge1xuXHRcdGNvbnN0IGluc3BlY3RvciA9IGdldEluc3BlY3RvcihpbnNwZWN0b3JJZCwgcGx1Z2luLmRlc2NyaXB0b3IuYXBwKTtcblx0XHRpZiAoIWluc3BlY3RvcikgcmV0dXJuO1xuXHRcdGluc3BlY3Rvci5zZWxlY3RlZE5vZGVJZCA9IG5vZGVJZDtcblx0fSk7XG5cdGhvb2tzLmhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuVElNRUxJTkVfTEFZRVJfQURERUQsICh7IG9wdGlvbnMsIHBsdWdpbiB9KSA9PiB7XG5cdFx0YWRkVGltZWxpbmVMYXllcihvcHRpb25zLCBwbHVnaW4uZGVzY3JpcHRvcik7XG5cdH0pO1xuXHRob29rcy5ob29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLlRJTUVMSU5FX0VWRU5UX0FEREVELCAoeyBvcHRpb25zLCBwbHVnaW4gfSkgPT4ge1xuXHRcdGlmIChkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQgfHwgIWRldnRvb2xzU3RhdGUudGltZWxpbmVMYXllcnNTdGF0ZT8uW3BsdWdpbi5kZXNjcmlwdG9yLmlkXSAmJiAhW1xuXHRcdFx0XCJwZXJmb3JtYW5jZVwiLFxuXHRcdFx0XCJjb21wb25lbnQtZXZlbnRcIixcblx0XHRcdFwia2V5Ym9hcmRcIixcblx0XHRcdFwibW91c2VcIlxuXHRcdF0uaW5jbHVkZXMob3B0aW9ucy5sYXllcklkKSkgcmV0dXJuO1xuXHRcdGhvb2tzLmNhbGxIb29rV2l0aChhc3luYyAoY2FsbGJhY2tzKSA9PiB7XG5cdFx0XHRhd2FpdCBQcm9taXNlLmFsbChjYWxsYmFja3MubWFwKChjYikgPT4gY2Iob3B0aW9ucykpKTtcblx0XHR9LCBEZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzLlNFTkRfVElNRUxJTkVfRVZFTlRfVE9fQ0xJRU5UKTtcblx0fSk7XG5cdGhvb2tzLmhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuR0VUX0NPTVBPTkVOVF9JTlNUQU5DRVMsIGFzeW5jICh7IGFwcCB9KSA9PiB7XG5cdFx0Y29uc3QgYXBwUmVjb3JkID0gYXBwLl9fVlVFX0RFVlRPT0xTX05FWFRfQVBQX1JFQ09SRF9fO1xuXHRcdGlmICghYXBwUmVjb3JkKSByZXR1cm4gbnVsbDtcblx0XHRjb25zdCBhcHBJZCA9IGFwcFJlY29yZC5pZC50b1N0cmluZygpO1xuXHRcdHJldHVybiBbLi4uYXBwUmVjb3JkLmluc3RhbmNlTWFwXS5maWx0ZXIoKFtrZXldKSA9PiBrZXkuc3BsaXQoXCI6XCIpWzBdID09PSBhcHBJZCkubWFwKChbLCBpbnN0YW5jZV0pID0+IGluc3RhbmNlKTtcblx0fSk7XG5cdGhvb2tzLmhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuR0VUX0NPTVBPTkVOVF9CT1VORFMsIGFzeW5jICh7IGluc3RhbmNlIH0pID0+IHtcblx0XHRyZXR1cm4gZ2V0Q29tcG9uZW50Qm91bmRpbmdSZWN0KGluc3RhbmNlKTtcblx0fSk7XG5cdGhvb2tzLmhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuR0VUX0NPTVBPTkVOVF9OQU1FLCAoeyBpbnN0YW5jZSB9KSA9PiB7XG5cdFx0cmV0dXJuIGdldEluc3RhbmNlTmFtZShpbnN0YW5jZSk7XG5cdH0pO1xuXHRob29rcy5ob29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLkNPTVBPTkVOVF9ISUdITElHSFQsICh7IHVpZCB9KSA9PiB7XG5cdFx0Y29uc3QgaW5zdGFuY2UgPSBhY3RpdmVBcHBSZWNvcmQudmFsdWUuaW5zdGFuY2VNYXAuZ2V0KHVpZCk7XG5cdFx0aWYgKGluc3RhbmNlKSBoaWdobGlnaHQoaW5zdGFuY2UpO1xuXHR9KTtcblx0aG9va3MuaG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5DT01QT05FTlRfVU5ISUdITElHSFQsICgpID0+IHtcblx0XHR1bmhpZ2hsaWdodCgpO1xuXHR9KTtcblx0cmV0dXJuIGhvb2tzO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2N0eC9zdGF0ZS50c1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BUFBfUkVDT1JEU19fID8/PSBbXTtcbnRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQUNUSVZFX0FQUF9SRUNPUkRfXyA/Pz0ge307XG50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0FDVElWRV9BUFBfUkVDT1JEX0lEX18gPz89IFwiXCI7XG50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0NVU1RPTV9UQUJTX18gPz89IFtdO1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9DVVNUT01fQ09NTUFORFNfXyA/Pz0gW107XG5jb25zdCBTVEFURV9LRVkgPSBcIl9fVlVFX0RFVlRPT0xTX0tJVF9HTE9CQUxfU1RBVEVfX1wiO1xuZnVuY3Rpb24gaW5pdFN0YXRlRmFjdG9yeSgpIHtcblx0cmV0dXJuIHtcblx0XHRjb25uZWN0ZWQ6IGZhbHNlLFxuXHRcdGNsaWVudENvbm5lY3RlZDogZmFsc2UsXG5cdFx0dml0ZVBsdWdpbkRldGVjdGVkOiB0cnVlLFxuXHRcdGFwcFJlY29yZHM6IFtdLFxuXHRcdGFjdGl2ZUFwcFJlY29yZElkOiBcIlwiLFxuXHRcdHRhYnM6IFtdLFxuXHRcdGNvbW1hbmRzOiBbXSxcblx0XHRoaWdoUGVyZk1vZGVFbmFibGVkOiB0cnVlLFxuXHRcdGRldnRvb2xzQ2xpZW50RGV0ZWN0ZWQ6IHt9LFxuXHRcdHBlcmZVbmlxdWVHcm91cElkOiAwLFxuXHRcdHRpbWVsaW5lTGF5ZXJzU3RhdGU6IGdldFRpbWVsaW5lTGF5ZXJzU3RhdGVGcm9tU3RvcmFnZSgpXG5cdH07XG59XG50YXJnZXRbU1RBVEVfS0VZXSA/Pz0gaW5pdFN0YXRlRmFjdG9yeSgpO1xuY29uc3QgY2FsbFN0YXRlVXBkYXRlZEhvb2sgPSBkZWJvdW5jZSgoc3RhdGUpID0+IHtcblx0ZGV2dG9vbHNDb250ZXh0Lmhvb2tzLmNhbGxIb29rKERldlRvb2xzTWVzc2FnaW5nSG9va0tleXMuREVWVE9PTFNfU1RBVEVfVVBEQVRFRCwgeyBzdGF0ZSB9KTtcbn0pO1xuY29uc3QgY2FsbENvbm5lY3RlZFVwZGF0ZWRIb29rID0gZGVib3VuY2UoKHN0YXRlLCBvbGRTdGF0ZSkgPT4ge1xuXHRkZXZ0b29sc0NvbnRleHQuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNNZXNzYWdpbmdIb29rS2V5cy5ERVZUT09MU19DT05ORUNURURfVVBEQVRFRCwge1xuXHRcdHN0YXRlLFxuXHRcdG9sZFN0YXRlXG5cdH0pO1xufSk7XG5jb25zdCBkZXZ0b29sc0FwcFJlY29yZHMgPSBuZXcgUHJveHkodGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BUFBfUkVDT1JEU19fLCB7IGdldChfdGFyZ2V0LCBwcm9wLCByZWNlaXZlcikge1xuXHRpZiAocHJvcCA9PT0gXCJ2YWx1ZVwiKSByZXR1cm4gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BUFBfUkVDT1JEU19fO1xuXHRyZXR1cm4gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BUFBfUkVDT1JEU19fW3Byb3BdO1xufSB9KTtcbmNvbnN0IGFkZERldlRvb2xzQXBwUmVjb3JkID0gKGFwcCkgPT4ge1xuXHR0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0FQUF9SRUNPUkRTX18gPSBbLi4udGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BUFBfUkVDT1JEU19fLCBhcHBdO1xufTtcbmNvbnN0IHJlbW92ZURldlRvb2xzQXBwUmVjb3JkID0gKGFwcCkgPT4ge1xuXHR0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0FQUF9SRUNPUkRTX18gPSBkZXZ0b29sc0FwcFJlY29yZHMudmFsdWUuZmlsdGVyKChyZWNvcmQpID0+IHJlY29yZC5hcHAgIT09IGFwcCk7XG59O1xuY29uc3QgYWN0aXZlQXBwUmVjb3JkID0gbmV3IFByb3h5KHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQUNUSVZFX0FQUF9SRUNPUkRfXywgeyBnZXQoX3RhcmdldCwgcHJvcCwgcmVjZWl2ZXIpIHtcblx0aWYgKHByb3AgPT09IFwidmFsdWVcIikgcmV0dXJuIHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQUNUSVZFX0FQUF9SRUNPUkRfXztcblx0ZWxzZSBpZiAocHJvcCA9PT0gXCJpZFwiKSByZXR1cm4gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BQ1RJVkVfQVBQX1JFQ09SRF9JRF9fO1xuXHRyZXR1cm4gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BQ1RJVkVfQVBQX1JFQ09SRF9fW3Byb3BdO1xufSB9KTtcbmZ1bmN0aW9uIHVwZGF0ZUFsbFN0YXRlcygpIHtcblx0Y2FsbFN0YXRlVXBkYXRlZEhvb2soe1xuXHRcdC4uLnRhcmdldFtTVEFURV9LRVldLFxuXHRcdGFwcFJlY29yZHM6IGRldnRvb2xzQXBwUmVjb3Jkcy52YWx1ZSxcblx0XHRhY3RpdmVBcHBSZWNvcmRJZDogYWN0aXZlQXBwUmVjb3JkLmlkLFxuXHRcdHRhYnM6IHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQ1VTVE9NX1RBQlNfXyxcblx0XHRjb21tYW5kczogdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9DVVNUT01fQ09NTUFORFNfX1xuXHR9KTtcbn1cbmZ1bmN0aW9uIHNldEFjdGl2ZUFwcFJlY29yZChhcHApIHtcblx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9BQ1RJVkVfQVBQX1JFQ09SRF9fID0gYXBwO1xuXHR1cGRhdGVBbGxTdGF0ZXMoKTtcbn1cbmZ1bmN0aW9uIHNldEFjdGl2ZUFwcFJlY29yZElkKGlkKSB7XG5cdHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQUNUSVZFX0FQUF9SRUNPUkRfSURfXyA9IGlkO1xuXHR1cGRhdGVBbGxTdGF0ZXMoKTtcbn1cbmNvbnN0IGRldnRvb2xzU3RhdGUgPSBuZXcgUHJveHkodGFyZ2V0W1NUQVRFX0tFWV0sIHtcblx0Z2V0KHRhcmdldCQzLCBwcm9wZXJ0eSkge1xuXHRcdGlmIChwcm9wZXJ0eSA9PT0gXCJhcHBSZWNvcmRzXCIpIHJldHVybiBkZXZ0b29sc0FwcFJlY29yZHM7XG5cdFx0ZWxzZSBpZiAocHJvcGVydHkgPT09IFwiYWN0aXZlQXBwUmVjb3JkSWRcIikgcmV0dXJuIGFjdGl2ZUFwcFJlY29yZC5pZDtcblx0XHRlbHNlIGlmIChwcm9wZXJ0eSA9PT0gXCJ0YWJzXCIpIHJldHVybiB0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0NVU1RPTV9UQUJTX187XG5cdFx0ZWxzZSBpZiAocHJvcGVydHkgPT09IFwiY29tbWFuZHNcIikgcmV0dXJuIHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQ1VTVE9NX0NPTU1BTkRTX187XG5cdFx0cmV0dXJuIHRhcmdldFtTVEFURV9LRVldW3Byb3BlcnR5XTtcblx0fSxcblx0ZGVsZXRlUHJvcGVydHkodGFyZ2V0LCBwcm9wZXJ0eSkge1xuXHRcdGRlbGV0ZSB0YXJnZXRbcHJvcGVydHldO1xuXHRcdHJldHVybiB0cnVlO1xuXHR9LFxuXHRzZXQodGFyZ2V0JDQsIHByb3BlcnR5LCB2YWx1ZSkge1xuXHRcdHRhcmdldCQ0W3Byb3BlcnR5XSA9IHZhbHVlO1xuXHRcdHRhcmdldFtTVEFURV9LRVldW3Byb3BlcnR5XSA9IHZhbHVlO1xuXHRcdHJldHVybiB0cnVlO1xuXHR9XG59KTtcbmZ1bmN0aW9uIHJlc2V0RGV2VG9vbHNTdGF0ZSgpIHtcblx0T2JqZWN0LmFzc2lnbih0YXJnZXRbU1RBVEVfS0VZXSwgaW5pdFN0YXRlRmFjdG9yeSgpKTtcbn1cbmZ1bmN0aW9uIHVwZGF0ZURldlRvb2xzU3RhdGUoc3RhdGUpIHtcblx0Y29uc3Qgb2xkU3RhdGUgPSB7XG5cdFx0Li4udGFyZ2V0W1NUQVRFX0tFWV0sXG5cdFx0YXBwUmVjb3JkczogZGV2dG9vbHNBcHBSZWNvcmRzLnZhbHVlLFxuXHRcdGFjdGl2ZUFwcFJlY29yZElkOiBhY3RpdmVBcHBSZWNvcmQuaWRcblx0fTtcblx0aWYgKG9sZFN0YXRlLmNvbm5lY3RlZCAhPT0gc3RhdGUuY29ubmVjdGVkICYmIHN0YXRlLmNvbm5lY3RlZCB8fCBvbGRTdGF0ZS5jbGllbnRDb25uZWN0ZWQgIT09IHN0YXRlLmNsaWVudENvbm5lY3RlZCAmJiBzdGF0ZS5jbGllbnRDb25uZWN0ZWQpIGNhbGxDb25uZWN0ZWRVcGRhdGVkSG9vayh0YXJnZXRbU1RBVEVfS0VZXSwgb2xkU3RhdGUpO1xuXHRPYmplY3QuYXNzaWduKHRhcmdldFtTVEFURV9LRVldLCBzdGF0ZSk7XG5cdHVwZGF0ZUFsbFN0YXRlcygpO1xufVxuZnVuY3Rpb24gb25EZXZUb29sc0Nvbm5lY3RlZChmbikge1xuXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRpZiAoZGV2dG9vbHNTdGF0ZS5jb25uZWN0ZWQpIHtcblx0XHRcdGZuKCk7XG5cdFx0XHRyZXNvbHZlKCk7XG5cdFx0fVxuXHRcdGRldnRvb2xzQ29udGV4dC5ob29rcy5ob29rKERldlRvb2xzTWVzc2FnaW5nSG9va0tleXMuREVWVE9PTFNfQ09OTkVDVEVEX1VQREFURUQsICh7IHN0YXRlIH0pID0+IHtcblx0XHRcdGlmIChzdGF0ZS5jb25uZWN0ZWQpIHtcblx0XHRcdFx0Zm4oKTtcblx0XHRcdFx0cmVzb2x2ZSgpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHR9KTtcbn1cbmNvbnN0IHJlc29sdmVJY29uID0gKGljb24pID0+IHtcblx0aWYgKCFpY29uKSByZXR1cm47XG5cdGlmIChpY29uLnN0YXJ0c1dpdGgoXCJiYXNlbGluZS1cIikpIHJldHVybiBgY3VzdG9tLWljLSR7aWNvbn1gO1xuXHRpZiAoaWNvbi5zdGFydHNXaXRoKFwiaS1cIikgfHwgaXNVcmxTdHJpbmcoaWNvbikpIHJldHVybiBpY29uO1xuXHRyZXR1cm4gYGN1c3RvbS1pYy1iYXNlbGluZS0ke2ljb259YDtcbn07XG5mdW5jdGlvbiBhZGRDdXN0b21UYWIodGFiKSB7XG5cdGNvbnN0IHRhYnMgPSB0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX0NVU1RPTV9UQUJTX187XG5cdGlmICh0YWJzLnNvbWUoKHQpID0+IHQubmFtZSA9PT0gdGFiLm5hbWUpKSByZXR1cm47XG5cdHRhYnMucHVzaCh7XG5cdFx0Li4udGFiLFxuXHRcdGljb246IHJlc29sdmVJY29uKHRhYi5pY29uKVxuXHR9KTtcblx0dXBkYXRlQWxsU3RhdGVzKCk7XG59XG5mdW5jdGlvbiBhZGRDdXN0b21Db21tYW5kKGFjdGlvbikge1xuXHRjb25zdCBjb21tYW5kcyA9IHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQ1VTVE9NX0NPTU1BTkRTX187XG5cdGlmIChjb21tYW5kcy5zb21lKCh0KSA9PiB0LmlkID09PSBhY3Rpb24uaWQpKSByZXR1cm47XG5cdGNvbW1hbmRzLnB1c2goe1xuXHRcdC4uLmFjdGlvbixcblx0XHRpY29uOiByZXNvbHZlSWNvbihhY3Rpb24uaWNvbiksXG5cdFx0Y2hpbGRyZW46IGFjdGlvbi5jaGlsZHJlbiA/IGFjdGlvbi5jaGlsZHJlbi5tYXAoKGNoaWxkKSA9PiAoe1xuXHRcdFx0Li4uY2hpbGQsXG5cdFx0XHRpY29uOiByZXNvbHZlSWNvbihjaGlsZC5pY29uKVxuXHRcdH0pKSA6IHZvaWQgMFxuXHR9KTtcblx0dXBkYXRlQWxsU3RhdGVzKCk7XG59XG5mdW5jdGlvbiByZW1vdmVDdXN0b21Db21tYW5kKGFjdGlvbklkKSB7XG5cdGNvbnN0IGNvbW1hbmRzID0gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9DVVNUT01fQ09NTUFORFNfXztcblx0Y29uc3QgaW5kZXggPSBjb21tYW5kcy5maW5kSW5kZXgoKHQpID0+IHQuaWQgPT09IGFjdGlvbklkKTtcblx0aWYgKGluZGV4ID09PSAtMSkgcmV0dXJuO1xuXHRjb21tYW5kcy5zcGxpY2UoaW5kZXgsIDEpO1xuXHR1cGRhdGVBbGxTdGF0ZXMoKTtcbn1cbmZ1bmN0aW9uIHRvZ2dsZUNsaWVudENvbm5lY3RlZChzdGF0ZSkge1xuXHR1cGRhdGVEZXZUb29sc1N0YXRlKHsgY2xpZW50Q29ubmVjdGVkOiBzdGF0ZSB9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL29wZW4taW4tZWRpdG9yL2luZGV4LnRzXG5mdW5jdGlvbiBzZXRPcGVuSW5FZGl0b3JCYXNlVXJsKHVybCkge1xuXHR0YXJnZXQuX19WVUVfREVWVE9PTFNfT1BFTl9JTl9FRElUT1JfQkFTRV9VUkxfXyA9IHVybDtcbn1cbmZ1bmN0aW9uIG9wZW5JbkVkaXRvcihvcHRpb25zID0ge30pIHtcblx0Y29uc3QgeyBmaWxlLCBob3N0LCBiYXNlVXJsID0gd2luZG93LmxvY2F0aW9uLm9yaWdpbiwgbGluZSA9IDAsIGNvbHVtbiA9IDAgfSA9IG9wdGlvbnM7XG5cdGlmIChmaWxlKSB7XG5cdFx0aWYgKGhvc3QgPT09IFwiY2hyb21lLWV4dGVuc2lvblwiKSB7XG5cdFx0XHRjb25zdCBmaWxlTmFtZSA9IGZpbGUucmVwbGFjZSgvXFxcXC9nLCBcIlxcXFxcXFxcXCIpO1xuXHRcdFx0Y29uc3QgX2Jhc2VVcmwgPSB3aW5kb3cuVlVFX0RFVlRPT0xTX0NPTkZJRz8ub3BlbkluRWRpdG9ySG9zdCA/PyBcIi9cIjtcblx0XHRcdGZldGNoKGAke19iYXNlVXJsfV9fb3Blbi1pbi1lZGl0b3I/ZmlsZT0ke2VuY29kZVVSSShmaWxlKX1gKS50aGVuKChyZXNwb25zZSkgPT4ge1xuXHRcdFx0XHRpZiAoIXJlc3BvbnNlLm9rKSB7XG5cdFx0XHRcdFx0Y29uc3QgbXNnID0gYE9wZW5pbmcgY29tcG9uZW50ICR7ZmlsZU5hbWV9IGZhaWxlZGA7XG5cdFx0XHRcdFx0Y29uc29sZS5sb2coYCVjJHttc2d9YCwgXCJjb2xvcjpyZWRcIik7XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH0gZWxzZSBpZiAoZGV2dG9vbHNTdGF0ZS52aXRlUGx1Z2luRGV0ZWN0ZWQpIHtcblx0XHRcdGNvbnN0IF9iYXNlVXJsID0gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX09QRU5fSU5fRURJVE9SX0JBU0VfVVJMX18gPz8gYmFzZVVybDtcblx0XHRcdHRhcmdldC5fX1ZVRV9JTlNQRUNUT1JfXy5vcGVuSW5FZGl0b3IoX2Jhc2VVcmwsIGZpbGUsIGxpbmUsIGNvbHVtbik7XG5cdFx0fVxuXHR9XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY3R4L3BsdWdpbi50c1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9QTFVHSU5fQlVGRkVSX18gPz89IFtdO1xuY29uc3QgZGV2dG9vbHNQbHVnaW5CdWZmZXIgPSBuZXcgUHJveHkodGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9QTFVHSU5fQlVGRkVSX18sIHsgZ2V0KHRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpIHtcblx0cmV0dXJuIFJlZmxlY3QuZ2V0KHRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpO1xufSB9KTtcbmZ1bmN0aW9uIGFkZERldlRvb2xzUGx1Z2luVG9CdWZmZXIocGx1Z2luRGVzY3JpcHRvciwgc2V0dXBGbikge1xuXHRkZXZ0b29sc1BsdWdpbkJ1ZmZlci5wdXNoKFtwbHVnaW5EZXNjcmlwdG9yLCBzZXR1cEZuXSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9wbHVnaW4vcGx1Z2luLXNldHRpbmdzLnRzXG5mdW5jdGlvbiBfZ2V0U2V0dGluZ3Moc2V0dGluZ3MpIHtcblx0Y29uc3QgX3NldHRpbmdzID0ge307XG5cdE9iamVjdC5rZXlzKHNldHRpbmdzKS5mb3JFYWNoKChrZXkpID0+IHtcblx0XHRfc2V0dGluZ3Nba2V5XSA9IHNldHRpbmdzW2tleV0uZGVmYXVsdFZhbHVlO1xuXHR9KTtcblx0cmV0dXJuIF9zZXR0aW5ncztcbn1cbmZ1bmN0aW9uIGdldFBsdWdpbkxvY2FsS2V5KHBsdWdpbklkKSB7XG5cdHJldHVybiBgX19WVUVfREVWVE9PTFNfTkVYVF9QTFVHSU5fU0VUVElOR1NfXyR7cGx1Z2luSWR9X19gO1xufVxuZnVuY3Rpb24gZ2V0UGx1Z2luU2V0dGluZ3NPcHRpb25zKHBsdWdpbklkKSB7XG5cdHJldHVybiAoZGV2dG9vbHNQbHVnaW5CdWZmZXIuZmluZCgoaXRlbSkgPT4gaXRlbVswXS5pZCA9PT0gcGx1Z2luSWQgJiYgISFpdGVtWzBdPy5zZXR0aW5ncyk/LlswXSA/PyBudWxsKT8uc2V0dGluZ3MgPz8gbnVsbDtcbn1cbmZ1bmN0aW9uIGdldFBsdWdpblNldHRpbmdzKHBsdWdpbklkLCBmYWxsYmFja1ZhbHVlKSB7XG5cdGNvbnN0IGxvY2FsS2V5ID0gZ2V0UGx1Z2luTG9jYWxLZXkocGx1Z2luSWQpO1xuXHRpZiAobG9jYWxLZXkpIHtcblx0XHRjb25zdCBsb2NhbFNldHRpbmdzID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0obG9jYWxLZXkpO1xuXHRcdGlmIChsb2NhbFNldHRpbmdzKSByZXR1cm4gSlNPTi5wYXJzZShsb2NhbFNldHRpbmdzKTtcblx0fVxuXHRpZiAocGx1Z2luSWQpIHJldHVybiBfZ2V0U2V0dGluZ3MoKGRldnRvb2xzUGx1Z2luQnVmZmVyLmZpbmQoKGl0ZW0pID0+IGl0ZW1bMF0uaWQgPT09IHBsdWdpbklkKT8uWzBdID8/IG51bGwpPy5zZXR0aW5ncyA/PyB7fSk7XG5cdHJldHVybiBfZ2V0U2V0dGluZ3MoZmFsbGJhY2tWYWx1ZSk7XG59XG5mdW5jdGlvbiBpbml0UGx1Z2luU2V0dGluZ3MocGx1Z2luSWQsIHNldHRpbmdzKSB7XG5cdGNvbnN0IGxvY2FsS2V5ID0gZ2V0UGx1Z2luTG9jYWxLZXkocGx1Z2luSWQpO1xuXHRpZiAoIWxvY2FsU3RvcmFnZS5nZXRJdGVtKGxvY2FsS2V5KSkgbG9jYWxTdG9yYWdlLnNldEl0ZW0obG9jYWxLZXksIEpTT04uc3RyaW5naWZ5KF9nZXRTZXR0aW5ncyhzZXR0aW5ncykpKTtcbn1cbmZ1bmN0aW9uIHNldFBsdWdpblNldHRpbmdzKHBsdWdpbklkLCBrZXksIHZhbHVlKSB7XG5cdGNvbnN0IGxvY2FsS2V5ID0gZ2V0UGx1Z2luTG9jYWxLZXkocGx1Z2luSWQpO1xuXHRjb25zdCBsb2NhbFNldHRpbmdzID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0obG9jYWxLZXkpO1xuXHRjb25zdCBwYXJzZWRMb2NhbFNldHRpbmdzID0gSlNPTi5wYXJzZShsb2NhbFNldHRpbmdzIHx8IFwie31cIik7XG5cdGNvbnN0IHVwZGF0ZWQgPSB7XG5cdFx0Li4ucGFyc2VkTG9jYWxTZXR0aW5ncyxcblx0XHRba2V5XTogdmFsdWVcblx0fTtcblx0bG9jYWxTdG9yYWdlLnNldEl0ZW0obG9jYWxLZXksIEpTT04uc3RyaW5naWZ5KHVwZGF0ZWQpKTtcblx0ZGV2dG9vbHNDb250ZXh0Lmhvb2tzLmNhbGxIb29rV2l0aCgoY2FsbGJhY2tzKSA9PiB7XG5cdFx0Y2FsbGJhY2tzLmZvckVhY2goKGNiKSA9PiBjYih7XG5cdFx0XHRwbHVnaW5JZCxcblx0XHRcdGtleSxcblx0XHRcdG9sZFZhbHVlOiBwYXJzZWRMb2NhbFNldHRpbmdzW2tleV0sXG5cdFx0XHRuZXdWYWx1ZTogdmFsdWUsXG5cdFx0XHRzZXR0aW5nczogdXBkYXRlZFxuXHRcdH0pKTtcblx0fSwgRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLlNFVF9QTFVHSU5fU0VUVElOR1MpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3R5cGVzL2hvb2sudHNcbmxldCBEZXZUb29sc0hvb2tzID0gLyogQF9fUFVSRV9fICovIGZ1bmN0aW9uKERldlRvb2xzSG9va3MpIHtcblx0RGV2VG9vbHNIb29rc1tcIkFQUF9JTklUXCJdID0gXCJhcHA6aW5pdFwiO1xuXHREZXZUb29sc0hvb2tzW1wiQVBQX1VOTU9VTlRcIl0gPSBcImFwcDp1bm1vdW50XCI7XG5cdERldlRvb2xzSG9va3NbXCJDT01QT05FTlRfVVBEQVRFRFwiXSA9IFwiY29tcG9uZW50OnVwZGF0ZWRcIjtcblx0RGV2VG9vbHNIb29rc1tcIkNPTVBPTkVOVF9BRERFRFwiXSA9IFwiY29tcG9uZW50OmFkZGVkXCI7XG5cdERldlRvb2xzSG9va3NbXCJDT01QT05FTlRfUkVNT1ZFRFwiXSA9IFwiY29tcG9uZW50OnJlbW92ZWRcIjtcblx0RGV2VG9vbHNIb29rc1tcIkNPTVBPTkVOVF9FTUlUXCJdID0gXCJjb21wb25lbnQ6ZW1pdFwiO1xuXHREZXZUb29sc0hvb2tzW1wiUEVSRk9STUFOQ0VfU1RBUlRcIl0gPSBcInBlcmY6c3RhcnRcIjtcblx0RGV2VG9vbHNIb29rc1tcIlBFUkZPUk1BTkNFX0VORFwiXSA9IFwicGVyZjplbmRcIjtcblx0RGV2VG9vbHNIb29rc1tcIkFERF9ST1VURVwiXSA9IFwicm91dGVyOmFkZC1yb3V0ZVwiO1xuXHREZXZUb29sc0hvb2tzW1wiUkVNT1ZFX1JPVVRFXCJdID0gXCJyb3V0ZXI6cmVtb3ZlLXJvdXRlXCI7XG5cdERldlRvb2xzSG9va3NbXCJSRU5ERVJfVFJBQ0tFRFwiXSA9IFwicmVuZGVyOnRyYWNrZWRcIjtcblx0RGV2VG9vbHNIb29rc1tcIlJFTkRFUl9UUklHR0VSRURcIl0gPSBcInJlbmRlcjp0cmlnZ2VyZWRcIjtcblx0RGV2VG9vbHNIb29rc1tcIkFQUF9DT05ORUNURURcIl0gPSBcImFwcDpjb25uZWN0ZWRcIjtcblx0RGV2VG9vbHNIb29rc1tcIlNFVFVQX0RFVlRPT0xTX1BMVUdJTlwiXSA9IFwiZGV2dG9vbHMtcGx1Z2luOnNldHVwXCI7XG5cdHJldHVybiBEZXZUb29sc0hvb2tzO1xufSh7fSk7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvaG9vay9pbmRleC50c1xuY29uc3QgZGV2dG9vbHNIb29rcyA9IHRhcmdldC5fX1ZVRV9ERVZUT09MU19IT09LID8/PSBjcmVhdGVIb29rcygpO1xuY29uc3Qgb24gPSB7XG5cdHZ1ZUFwcEluaXQoZm4pIHtcblx0XHRkZXZ0b29sc0hvb2tzLmhvb2soRGV2VG9vbHNIb29rcy5BUFBfSU5JVCwgZm4pO1xuXHR9LFxuXHR2dWVBcHBVbm1vdW50KGZuKSB7XG5cdFx0ZGV2dG9vbHNIb29rcy5ob29rKERldlRvb2xzSG9va3MuQVBQX1VOTU9VTlQsIGZuKTtcblx0fSxcblx0dnVlQXBwQ29ubmVjdGVkKGZuKSB7XG5cdFx0ZGV2dG9vbHNIb29rcy5ob29rKERldlRvb2xzSG9va3MuQVBQX0NPTk5FQ1RFRCwgZm4pO1xuXHR9LFxuXHRjb21wb25lbnRBZGRlZChmbikge1xuXHRcdHJldHVybiBkZXZ0b29sc0hvb2tzLmhvb2soRGV2VG9vbHNIb29rcy5DT01QT05FTlRfQURERUQsIGZuKTtcblx0fSxcblx0Y29tcG9uZW50RW1pdChmbikge1xuXHRcdHJldHVybiBkZXZ0b29sc0hvb2tzLmhvb2soRGV2VG9vbHNIb29rcy5DT01QT05FTlRfRU1JVCwgZm4pO1xuXHR9LFxuXHRjb21wb25lbnRVcGRhdGVkKGZuKSB7XG5cdFx0cmV0dXJuIGRldnRvb2xzSG9va3MuaG9vayhEZXZUb29sc0hvb2tzLkNPTVBPTkVOVF9VUERBVEVELCBmbik7XG5cdH0sXG5cdGNvbXBvbmVudFJlbW92ZWQoZm4pIHtcblx0XHRyZXR1cm4gZGV2dG9vbHNIb29rcy5ob29rKERldlRvb2xzSG9va3MuQ09NUE9ORU5UX1JFTU9WRUQsIGZuKTtcblx0fSxcblx0c2V0dXBEZXZ0b29sc1BsdWdpbihmbikge1xuXHRcdGRldnRvb2xzSG9va3MuaG9vayhEZXZUb29sc0hvb2tzLlNFVFVQX0RFVlRPT0xTX1BMVUdJTiwgZm4pO1xuXHR9LFxuXHRwZXJmU3RhcnQoZm4pIHtcblx0XHRyZXR1cm4gZGV2dG9vbHNIb29rcy5ob29rKERldlRvb2xzSG9va3MuUEVSRk9STUFOQ0VfU1RBUlQsIGZuKTtcblx0fSxcblx0cGVyZkVuZChmbikge1xuXHRcdHJldHVybiBkZXZ0b29sc0hvb2tzLmhvb2soRGV2VG9vbHNIb29rcy5QRVJGT1JNQU5DRV9FTkQsIGZuKTtcblx0fVxufTtcbmZ1bmN0aW9uIGNyZWF0ZURldlRvb2xzSG9vaygpIHtcblx0cmV0dXJuIHtcblx0XHRpZDogXCJ2dWUtZGV2dG9vbHMtbmV4dFwiLFxuXHRcdGRldnRvb2xzVmVyc2lvbjogXCI3LjBcIixcblx0XHRlbmFibGVkOiBmYWxzZSxcblx0XHRhcHBSZWNvcmRzOiBbXSxcblx0XHRhcHBzOiBbXSxcblx0XHRldmVudHM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCksXG5cdFx0b24oZXZlbnQsIGZuKSB7XG5cdFx0XHRpZiAoIXRoaXMuZXZlbnRzLmhhcyhldmVudCkpIHRoaXMuZXZlbnRzLnNldChldmVudCwgW10pO1xuXHRcdFx0dGhpcy5ldmVudHMuZ2V0KGV2ZW50KT8ucHVzaChmbik7XG5cdFx0XHRyZXR1cm4gKCkgPT4gdGhpcy5vZmYoZXZlbnQsIGZuKTtcblx0XHR9LFxuXHRcdG9uY2UoZXZlbnQsIGZuKSB7XG5cdFx0XHRjb25zdCBvbmNlRm4gPSAoLi4uYXJncykgPT4ge1xuXHRcdFx0XHR0aGlzLm9mZihldmVudCwgb25jZUZuKTtcblx0XHRcdFx0Zm4oLi4uYXJncyk7XG5cdFx0XHR9O1xuXHRcdFx0dGhpcy5vbihldmVudCwgb25jZUZuKTtcblx0XHRcdHJldHVybiBbZXZlbnQsIG9uY2VGbl07XG5cdFx0fSxcblx0XHRvZmYoZXZlbnQsIGZuKSB7XG5cdFx0XHRpZiAodGhpcy5ldmVudHMuaGFzKGV2ZW50KSkge1xuXHRcdFx0XHRjb25zdCBldmVudENhbGxiYWNrcyA9IHRoaXMuZXZlbnRzLmdldChldmVudCk7XG5cdFx0XHRcdGNvbnN0IGluZGV4ID0gZXZlbnRDYWxsYmFja3MuaW5kZXhPZihmbik7XG5cdFx0XHRcdGlmIChpbmRleCAhPT0gLTEpIGV2ZW50Q2FsbGJhY2tzLnNwbGljZShpbmRleCwgMSk7XG5cdFx0XHR9XG5cdFx0fSxcblx0XHRlbWl0KGV2ZW50LCAuLi5wYXlsb2FkKSB7XG5cdFx0XHRpZiAodGhpcy5ldmVudHMuaGFzKGV2ZW50KSkgdGhpcy5ldmVudHMuZ2V0KGV2ZW50KS5mb3JFYWNoKChmbikgPT4gZm4oLi4ucGF5bG9hZCkpO1xuXHRcdH1cblx0fTtcbn1cbmZ1bmN0aW9uIHN1YnNjcmliZURldlRvb2xzSG9vayhob29rKSB7XG5cdGhvb2sub24oRGV2VG9vbHNIb29rcy5BUFBfSU5JVCwgKGFwcCwgdmVyc2lvbiwgdHlwZXMpID0+IHtcblx0XHRpZiAoYXBwPy5faW5zdGFuY2U/LnR5cGU/LmRldnRvb2xzPy5oaWRlKSByZXR1cm47XG5cdFx0ZGV2dG9vbHNIb29rcy5jYWxsSG9vayhEZXZUb29sc0hvb2tzLkFQUF9JTklULCBhcHAsIHZlcnNpb24sIHR5cGVzKTtcblx0fSk7XG5cdGhvb2sub24oRGV2VG9vbHNIb29rcy5BUFBfVU5NT1VOVCwgKGFwcCkgPT4ge1xuXHRcdGRldnRvb2xzSG9va3MuY2FsbEhvb2soRGV2VG9vbHNIb29rcy5BUFBfVU5NT1VOVCwgYXBwKTtcblx0fSk7XG5cdGhvb2sub24oRGV2VG9vbHNIb29rcy5DT01QT05FTlRfQURERUQsIGFzeW5jIChhcHAsIHVpZCwgcGFyZW50VWlkLCBjb21wb25lbnQpID0+IHtcblx0XHRpZiAoYXBwPy5faW5zdGFuY2U/LnR5cGU/LmRldnRvb2xzPy5oaWRlIHx8IGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdGlmICghYXBwIHx8IHR5cGVvZiB1aWQgIT09IFwibnVtYmVyXCIgJiYgIXVpZCB8fCAhY29tcG9uZW50KSByZXR1cm47XG5cdFx0ZGV2dG9vbHNIb29rcy5jYWxsSG9vayhEZXZUb29sc0hvb2tzLkNPTVBPTkVOVF9BRERFRCwgYXBwLCB1aWQsIHBhcmVudFVpZCwgY29tcG9uZW50KTtcblx0fSk7XG5cdGhvb2sub24oRGV2VG9vbHNIb29rcy5DT01QT05FTlRfVVBEQVRFRCwgKGFwcCwgdWlkLCBwYXJlbnRVaWQsIGNvbXBvbmVudCkgPT4ge1xuXHRcdGlmICghYXBwIHx8IHR5cGVvZiB1aWQgIT09IFwibnVtYmVyXCIgJiYgIXVpZCB8fCAhY29tcG9uZW50IHx8IGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdGRldnRvb2xzSG9va3MuY2FsbEhvb2soRGV2VG9vbHNIb29rcy5DT01QT05FTlRfVVBEQVRFRCwgYXBwLCB1aWQsIHBhcmVudFVpZCwgY29tcG9uZW50KTtcblx0fSk7XG5cdGhvb2sub24oRGV2VG9vbHNIb29rcy5DT01QT05FTlRfUkVNT1ZFRCwgYXN5bmMgKGFwcCwgdWlkLCBwYXJlbnRVaWQsIGNvbXBvbmVudCkgPT4ge1xuXHRcdGlmICghYXBwIHx8IHR5cGVvZiB1aWQgIT09IFwibnVtYmVyXCIgJiYgIXVpZCB8fCAhY29tcG9uZW50IHx8IGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdGRldnRvb2xzSG9va3MuY2FsbEhvb2soRGV2VG9vbHNIb29rcy5DT01QT05FTlRfUkVNT1ZFRCwgYXBwLCB1aWQsIHBhcmVudFVpZCwgY29tcG9uZW50KTtcblx0fSk7XG5cdGhvb2sub24oRGV2VG9vbHNIb29rcy5DT01QT05FTlRfRU1JVCwgYXN5bmMgKGFwcCwgaW5zdGFuY2UsIGV2ZW50LCBwYXJhbXMpID0+IHtcblx0XHRpZiAoIWFwcCB8fCAhaW5zdGFuY2UgfHwgZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0ZGV2dG9vbHNIb29rcy5jYWxsSG9vayhEZXZUb29sc0hvb2tzLkNPTVBPTkVOVF9FTUlULCBhcHAsIGluc3RhbmNlLCBldmVudCwgcGFyYW1zKTtcblx0fSk7XG5cdGhvb2sub24oRGV2VG9vbHNIb29rcy5QRVJGT1JNQU5DRV9TVEFSVCwgKGFwcCwgdWlkLCB2bSwgdHlwZSwgdGltZSkgPT4ge1xuXHRcdGlmICghYXBwIHx8IGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdGRldnRvb2xzSG9va3MuY2FsbEhvb2soRGV2VG9vbHNIb29rcy5QRVJGT1JNQU5DRV9TVEFSVCwgYXBwLCB1aWQsIHZtLCB0eXBlLCB0aW1lKTtcblx0fSk7XG5cdGhvb2sub24oRGV2VG9vbHNIb29rcy5QRVJGT1JNQU5DRV9FTkQsIChhcHAsIHVpZCwgdm0sIHR5cGUsIHRpbWUpID0+IHtcblx0XHRpZiAoIWFwcCB8fCBkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQpIHJldHVybjtcblx0XHRkZXZ0b29sc0hvb2tzLmNhbGxIb29rKERldlRvb2xzSG9va3MuUEVSRk9STUFOQ0VfRU5ELCBhcHAsIHVpZCwgdm0sIHR5cGUsIHRpbWUpO1xuXHR9KTtcblx0aG9vay5vbihEZXZUb29sc0hvb2tzLlNFVFVQX0RFVlRPT0xTX1BMVUdJTiwgKHBsdWdpbkRlc2NyaXB0b3IsIHNldHVwRm4sIG9wdGlvbnMpID0+IHtcblx0XHRpZiAob3B0aW9ucz8udGFyZ2V0ID09PSBcImxlZ2FjeVwiKSByZXR1cm47XG5cdFx0ZGV2dG9vbHNIb29rcy5jYWxsSG9vayhEZXZUb29sc0hvb2tzLlNFVFVQX0RFVlRPT0xTX1BMVUdJTiwgcGx1Z2luRGVzY3JpcHRvciwgc2V0dXBGbik7XG5cdH0pO1xufVxuY29uc3QgaG9vayA9IHtcblx0b24sXG5cdHNldHVwRGV2VG9vbHNQbHVnaW4ocGx1Z2luRGVzY3JpcHRvciwgc2V0dXBGbikge1xuXHRcdHJldHVybiBkZXZ0b29sc0hvb2tzLmNhbGxIb29rKERldlRvb2xzSG9va3MuU0VUVVBfREVWVE9PTFNfUExVR0lOLCBwbHVnaW5EZXNjcmlwdG9yLCBzZXR1cEZuKTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9hcGkvdjYvaW5kZXgudHNcbnZhciBEZXZUb29sc1Y2UGx1Z2luQVBJID0gY2xhc3Mge1xuXHRjb25zdHJ1Y3Rvcih7IHBsdWdpbiwgY3R4IH0pIHtcblx0XHR0aGlzLmhvb2tzID0gY3R4Lmhvb2tzO1xuXHRcdHRoaXMucGx1Z2luID0gcGx1Z2luO1xuXHR9XG5cdGdldCBvbigpIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0dmlzaXRDb21wb25lbnRUcmVlOiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0XHR0aGlzLmhvb2tzLmhvb2soRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLlZJU0lUX0NPTVBPTkVOVF9UUkVFLCBoYW5kbGVyKTtcblx0XHRcdH0sXG5cdFx0XHRpbnNwZWN0Q29tcG9uZW50OiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0XHR0aGlzLmhvb2tzLmhvb2soRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLklOU1BFQ1RfQ09NUE9ORU5ULCBoYW5kbGVyKTtcblx0XHRcdH0sXG5cdFx0XHRlZGl0Q29tcG9uZW50U3RhdGU6IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRcdHRoaXMuaG9va3MuaG9vayhEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuRURJVF9DT01QT05FTlRfU1RBVEUsIGhhbmRsZXIpO1xuXHRcdFx0fSxcblx0XHRcdGdldEluc3BlY3RvclRyZWU6IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRcdHRoaXMuaG9va3MuaG9vayhEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuR0VUX0lOU1BFQ1RPUl9UUkVFLCBoYW5kbGVyKTtcblx0XHRcdH0sXG5cdFx0XHRnZXRJbnNwZWN0b3JTdGF0ZTogKGhhbmRsZXIpID0+IHtcblx0XHRcdFx0dGhpcy5ob29rcy5ob29rKERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cy5HRVRfSU5TUEVDVE9SX1NUQVRFLCBoYW5kbGVyKTtcblx0XHRcdH0sXG5cdFx0XHRlZGl0SW5zcGVjdG9yU3RhdGU6IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRcdHRoaXMuaG9va3MuaG9vayhEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuRURJVF9JTlNQRUNUT1JfU1RBVEUsIGhhbmRsZXIpO1xuXHRcdFx0fSxcblx0XHRcdGluc3BlY3RUaW1lbGluZUV2ZW50OiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0XHR0aGlzLmhvb2tzLmhvb2soRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLklOU1BFQ1RfVElNRUxJTkVfRVZFTlQsIGhhbmRsZXIpO1xuXHRcdFx0fSxcblx0XHRcdHRpbWVsaW5lQ2xlYXJlZDogKGhhbmRsZXIpID0+IHtcblx0XHRcdFx0dGhpcy5ob29rcy5ob29rKERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cy5USU1FTElORV9DTEVBUkVELCBoYW5kbGVyKTtcblx0XHRcdH0sXG5cdFx0XHRzZXRQbHVnaW5TZXR0aW5nczogKGhhbmRsZXIpID0+IHtcblx0XHRcdFx0dGhpcy5ob29rcy5ob29rKERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cy5TRVRfUExVR0lOX1NFVFRJTkdTLCBoYW5kbGVyKTtcblx0XHRcdH1cblx0XHR9O1xuXHR9XG5cdG5vdGlmeUNvbXBvbmVudFVwZGF0ZShpbnN0YW5jZSkge1xuXHRcdGlmIChkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQpIHJldHVybjtcblx0XHRjb25zdCBpbnNwZWN0b3IgPSBnZXRBY3RpdmVJbnNwZWN0b3JzKCkuZmluZCgoaSkgPT4gaS5wYWNrYWdlTmFtZSA9PT0gdGhpcy5wbHVnaW4uZGVzY3JpcHRvci5wYWNrYWdlTmFtZSk7XG5cdFx0aWYgKGluc3BlY3Rvcj8uaWQpIHtcblx0XHRcdGlmIChpbnN0YW5jZSkge1xuXHRcdFx0XHRjb25zdCBhcmdzID0gW1xuXHRcdFx0XHRcdGluc3RhbmNlLmFwcENvbnRleHQuYXBwLFxuXHRcdFx0XHRcdGluc3RhbmNlLnVpZCxcblx0XHRcdFx0XHRpbnN0YW5jZS5wYXJlbnQ/LnVpZCxcblx0XHRcdFx0XHRpbnN0YW5jZVxuXHRcdFx0XHRdO1xuXHRcdFx0XHRkZXZ0b29sc0hvb2tzLmNhbGxIb29rKERldlRvb2xzSG9va3MuQ09NUE9ORU5UX1VQREFURUQsIC4uLmFyZ3MpO1xuXHRcdFx0fSBlbHNlIGRldnRvb2xzSG9va3MuY2FsbEhvb2soRGV2VG9vbHNIb29rcy5DT01QT05FTlRfVVBEQVRFRCk7XG5cdFx0XHR0aGlzLmhvb2tzLmNhbGxIb29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLlNFTkRfSU5TUEVDVE9SX1NUQVRFLCB7XG5cdFx0XHRcdGluc3BlY3RvcklkOiBpbnNwZWN0b3IuaWQsXG5cdFx0XHRcdHBsdWdpbjogdGhpcy5wbHVnaW5cblx0XHRcdH0pO1xuXHRcdH1cblx0fVxuXHRhZGRJbnNwZWN0b3Iob3B0aW9ucykge1xuXHRcdHRoaXMuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuQUREX0lOU1BFQ1RPUiwge1xuXHRcdFx0aW5zcGVjdG9yOiBvcHRpb25zLFxuXHRcdFx0cGx1Z2luOiB0aGlzLnBsdWdpblxuXHRcdH0pO1xuXHRcdGlmICh0aGlzLnBsdWdpbi5kZXNjcmlwdG9yLnNldHRpbmdzKSBpbml0UGx1Z2luU2V0dGluZ3Mob3B0aW9ucy5pZCwgdGhpcy5wbHVnaW4uZGVzY3JpcHRvci5zZXR0aW5ncyk7XG5cdH1cblx0c2VuZEluc3BlY3RvclRyZWUoaW5zcGVjdG9ySWQpIHtcblx0XHRpZiAoZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0dGhpcy5ob29rcy5jYWxsSG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5TRU5EX0lOU1BFQ1RPUl9UUkVFLCB7XG5cdFx0XHRpbnNwZWN0b3JJZCxcblx0XHRcdHBsdWdpbjogdGhpcy5wbHVnaW5cblx0XHR9KTtcblx0fVxuXHRzZW5kSW5zcGVjdG9yU3RhdGUoaW5zcGVjdG9ySWQpIHtcblx0XHRpZiAoZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0dGhpcy5ob29rcy5jYWxsSG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5TRU5EX0lOU1BFQ1RPUl9TVEFURSwge1xuXHRcdFx0aW5zcGVjdG9ySWQsXG5cdFx0XHRwbHVnaW46IHRoaXMucGx1Z2luXG5cdFx0fSk7XG5cdH1cblx0c2VsZWN0SW5zcGVjdG9yTm9kZShpbnNwZWN0b3JJZCwgbm9kZUlkKSB7XG5cdFx0dGhpcy5ob29rcy5jYWxsSG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5DVVNUT01fSU5TUEVDVE9SX1NFTEVDVF9OT0RFLCB7XG5cdFx0XHRpbnNwZWN0b3JJZCxcblx0XHRcdG5vZGVJZCxcblx0XHRcdHBsdWdpbjogdGhpcy5wbHVnaW5cblx0XHR9KTtcblx0fVxuXHR2aXNpdENvbXBvbmVudFRyZWUocGF5bG9hZCkge1xuXHRcdHJldHVybiB0aGlzLmhvb2tzLmNhbGxIb29rKERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cy5WSVNJVF9DT01QT05FTlRfVFJFRSwgcGF5bG9hZCk7XG5cdH1cblx0bm93KCkge1xuXHRcdGlmIChkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQpIHJldHVybiAwO1xuXHRcdHJldHVybiBEYXRlLm5vdygpO1xuXHR9XG5cdGFkZFRpbWVsaW5lTGF5ZXIob3B0aW9ucykge1xuXHRcdHRoaXMuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuVElNRUxJTkVfTEFZRVJfQURERUQsIHtcblx0XHRcdG9wdGlvbnMsXG5cdFx0XHRwbHVnaW46IHRoaXMucGx1Z2luXG5cdFx0fSk7XG5cdH1cblx0YWRkVGltZWxpbmVFdmVudChvcHRpb25zKSB7XG5cdFx0aWYgKGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdHRoaXMuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuVElNRUxJTkVfRVZFTlRfQURERUQsIHtcblx0XHRcdG9wdGlvbnMsXG5cdFx0XHRwbHVnaW46IHRoaXMucGx1Z2luXG5cdFx0fSk7XG5cdH1cblx0Z2V0U2V0dGluZ3MocGx1Z2luSWQpIHtcblx0XHRyZXR1cm4gZ2V0UGx1Z2luU2V0dGluZ3MocGx1Z2luSWQgPz8gdGhpcy5wbHVnaW4uZGVzY3JpcHRvci5pZCwgdGhpcy5wbHVnaW4uZGVzY3JpcHRvci5zZXR0aW5ncyk7XG5cdH1cblx0Z2V0Q29tcG9uZW50SW5zdGFuY2VzKGFwcCkge1xuXHRcdHJldHVybiB0aGlzLmhvb2tzLmNhbGxIb29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLkdFVF9DT01QT05FTlRfSU5TVEFOQ0VTLCB7IGFwcCB9KTtcblx0fVxuXHRnZXRDb21wb25lbnRCb3VuZHMoaW5zdGFuY2UpIHtcblx0XHRyZXR1cm4gdGhpcy5ob29rcy5jYWxsSG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5HRVRfQ09NUE9ORU5UX0JPVU5EUywgeyBpbnN0YW5jZSB9KTtcblx0fVxuXHRnZXRDb21wb25lbnROYW1lKGluc3RhbmNlKSB7XG5cdFx0cmV0dXJuIHRoaXMuaG9va3MuY2FsbEhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuR0VUX0NPTVBPTkVOVF9OQU1FLCB7IGluc3RhbmNlIH0pO1xuXHR9XG5cdGhpZ2hsaWdodEVsZW1lbnQoaW5zdGFuY2UpIHtcblx0XHRjb25zdCB1aWQgPSBpbnN0YW5jZS5fX1ZVRV9ERVZUT09MU19ORVhUX1VJRF9fO1xuXHRcdHJldHVybiB0aGlzLmhvb2tzLmNhbGxIb29rKERldlRvb2xzQ29udGV4dEhvb2tLZXlzLkNPTVBPTkVOVF9ISUdITElHSFQsIHsgdWlkIH0pO1xuXHR9XG5cdHVuaGlnaGxpZ2h0RWxlbWVudCgpIHtcblx0XHRyZXR1cm4gdGhpcy5ob29rcy5jYWxsSG9vayhEZXZUb29sc0NvbnRleHRIb29rS2V5cy5DT01QT05FTlRfVU5ISUdITElHSFQpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2FwaS9pbmRleC50c1xuY29uc3QgRGV2VG9vbHNQbHVnaW5BUEkgPSBEZXZUb29sc1Y2UGx1Z2luQVBJO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50L3N0YXRlL2NvbnN0YW50cy50c1xuY29uc3QgdnVlQnVpbHRpbnMgPSBuZXcgU2V0KFtcblx0XCJuZXh0VGlja1wiLFxuXHRcImRlZmluZUNvbXBvbmVudFwiLFxuXHRcImRlZmluZUFzeW5jQ29tcG9uZW50XCIsXG5cdFwiZGVmaW5lQ3VzdG9tRWxlbWVudFwiLFxuXHRcInJlZlwiLFxuXHRcImNvbXB1dGVkXCIsXG5cdFwicmVhY3RpdmVcIixcblx0XCJyZWFkb25seVwiLFxuXHRcIndhdGNoRWZmZWN0XCIsXG5cdFwid2F0Y2hQb3N0RWZmZWN0XCIsXG5cdFwid2F0Y2hTeW5jRWZmZWN0XCIsXG5cdFwid2F0Y2hcIixcblx0XCJpc1JlZlwiLFxuXHRcInVucmVmXCIsXG5cdFwidG9SZWZcIixcblx0XCJ0b1JlZnNcIixcblx0XCJpc1Byb3h5XCIsXG5cdFwiaXNSZWFjdGl2ZVwiLFxuXHRcImlzUmVhZG9ubHlcIixcblx0XCJzaGFsbG93UmVmXCIsXG5cdFwidHJpZ2dlclJlZlwiLFxuXHRcImN1c3RvbVJlZlwiLFxuXHRcInNoYWxsb3dSZWFjdGl2ZVwiLFxuXHRcInNoYWxsb3dSZWFkb25seVwiLFxuXHRcInRvUmF3XCIsXG5cdFwibWFya1Jhd1wiLFxuXHRcImVmZmVjdFNjb3BlXCIsXG5cdFwiZ2V0Q3VycmVudFNjb3BlXCIsXG5cdFwib25TY29wZURpc3Bvc2VcIixcblx0XCJvbk1vdW50ZWRcIixcblx0XCJvblVwZGF0ZWRcIixcblx0XCJvblVubW91bnRlZFwiLFxuXHRcIm9uQmVmb3JlTW91bnRcIixcblx0XCJvbkJlZm9yZVVwZGF0ZVwiLFxuXHRcIm9uQmVmb3JlVW5tb3VudFwiLFxuXHRcIm9uRXJyb3JDYXB0dXJlZFwiLFxuXHRcIm9uUmVuZGVyVHJhY2tlZFwiLFxuXHRcIm9uUmVuZGVyVHJpZ2dlcmVkXCIsXG5cdFwib25BY3RpdmF0ZWRcIixcblx0XCJvbkRlYWN0aXZhdGVkXCIsXG5cdFwib25TZXJ2ZXJQcmVmZXRjaFwiLFxuXHRcInByb3ZpZGVcIixcblx0XCJpbmplY3RcIixcblx0XCJoXCIsXG5cdFwibWVyZ2VQcm9wc1wiLFxuXHRcImNsb25lVk5vZGVcIixcblx0XCJpc1ZOb2RlXCIsXG5cdFwicmVzb2x2ZUNvbXBvbmVudFwiLFxuXHRcInJlc29sdmVEaXJlY3RpdmVcIixcblx0XCJ3aXRoRGlyZWN0aXZlc1wiLFxuXHRcIndpdGhNb2RpZmllcnNcIlxuXSk7XG5jb25zdCBzeW1ib2xSRSA9IC9eXFxbbmF0aXZlIFN5bWJvbCBTeW1ib2xcXCgoLiopXFwpXFxdJC87XG5jb25zdCByYXdUeXBlUkUgPSAvXlxcW29iamVjdCAoXFx3KylcXF0kLztcbmNvbnN0IHNwZWNpYWxUeXBlUkUgPSAvXlxcW25hdGl2ZSAoXFx3KykgKC4qPykoPD4oKFtcXHNcXFNdKSopKT9cXF0kLztcbmNvbnN0IGZuVHlwZVJFID0gL14oPzpmdW5jdGlvbnxjbGFzcykgKFxcdyspLztcbmNvbnN0IE1BWF9TVFJJTkdfU0laRSA9IDFlNDtcbmNvbnN0IE1BWF9BUlJBWV9TSVpFID0gNWUzO1xuY29uc3QgVU5ERUZJTkVEID0gXCJfX3Z1ZV9kZXZ0b29sX3VuZGVmaW5lZF9fXCI7XG5jb25zdCBJTkZJTklUWSA9IFwiX192dWVfZGV2dG9vbF9pbmZpbml0eV9fXCI7XG5jb25zdCBORUdBVElWRV9JTkZJTklUWSA9IFwiX192dWVfZGV2dG9vbF9uZWdhdGl2ZV9pbmZpbml0eV9fXCI7XG5jb25zdCBOQU4gPSBcIl9fdnVlX2RldnRvb2xfbmFuX19cIjtcbmNvbnN0IEVTQyA9IHtcblx0XCI8XCI6IFwiJmx0O1wiLFxuXHRcIj5cIjogXCImZ3Q7XCIsXG5cdFwiXFxcIlwiOiBcIiZxdW90O1wiLFxuXHRcIiZcIjogXCImYW1wO1wiXG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50L3N0YXRlL2lzLnRzXG5mdW5jdGlvbiBpc1Z1ZUluc3RhbmNlKHZhbHVlKSB7XG5cdGlmICghZW5zdXJlUHJvcGVydHlFeGlzdHModmFsdWUsIFwiX1wiKSkgcmV0dXJuIGZhbHNlO1xuXHRpZiAoIWlzUGxhaW5PYmplY3QodmFsdWUuXykpIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIE9iamVjdC5rZXlzKHZhbHVlLl8pLmluY2x1ZGVzKFwidm5vZGVcIik7XG59XG5mdW5jdGlvbiBpc1BsYWluT2JqZWN0KG9iaikge1xuXHRyZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG9iaikgPT09IFwiW29iamVjdCBPYmplY3RdXCI7XG59XG5mdW5jdGlvbiBpc1ByaW1pdGl2ZSQxKGRhdGEpIHtcblx0aWYgKGRhdGEgPT0gbnVsbCkgcmV0dXJuIHRydWU7XG5cdGNvbnN0IHR5cGUgPSB0eXBlb2YgZGF0YTtcblx0cmV0dXJuIHR5cGUgPT09IFwic3RyaW5nXCIgfHwgdHlwZSA9PT0gXCJudW1iZXJcIiB8fCB0eXBlID09PSBcImJvb2xlYW5cIjtcbn1cbmZ1bmN0aW9uIGlzUmVmKHJhdykge1xuXHRyZXR1cm4gISFyYXcuX192X2lzUmVmO1xufVxuZnVuY3Rpb24gaXNDb21wdXRlZChyYXcpIHtcblx0cmV0dXJuIGlzUmVmKHJhdykgJiYgISFyYXcuZWZmZWN0O1xufVxuZnVuY3Rpb24gaXNSZWFjdGl2ZShyYXcpIHtcblx0cmV0dXJuICEhcmF3Ll9fdl9pc1JlYWN0aXZlO1xufVxuZnVuY3Rpb24gaXNSZWFkT25seShyYXcpIHtcblx0cmV0dXJuICEhcmF3Ll9fdl9pc1JlYWRvbmx5O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50L3N0YXRlL3V0aWwudHNcbmNvbnN0IHRva2VuTWFwID0ge1xuXHRbVU5ERUZJTkVEXTogXCJ1bmRlZmluZWRcIixcblx0W05BTl06IFwiTmFOXCIsXG5cdFtJTkZJTklUWV06IFwiSW5maW5pdHlcIixcblx0W05FR0FUSVZFX0lORklOSVRZXTogXCItSW5maW5pdHlcIlxufTtcbmNvbnN0IHJldmVyc2VkVG9rZW5NYXAgPSBPYmplY3QuZW50cmllcyh0b2tlbk1hcCkucmVkdWNlKChhY2MsIFtrZXksIHZhbHVlXSkgPT4ge1xuXHRhY2NbdmFsdWVdID0ga2V5O1xuXHRyZXR1cm4gYWNjO1xufSwge30pO1xuZnVuY3Rpb24gaW50ZXJuYWxTdGF0ZVRva2VuVG9TdHJpbmcodmFsdWUpIHtcblx0aWYgKHZhbHVlID09PSBudWxsKSByZXR1cm4gXCJudWxsXCI7XG5cdHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwic3RyaW5nXCIgJiYgdG9rZW5NYXBbdmFsdWVdIHx8IGZhbHNlO1xufVxuZnVuY3Rpb24gcmVwbGFjZVRva2VuVG9TdHJpbmcodmFsdWUpIHtcblx0Y29uc3QgcmVwbGFjZVJlZ2V4ID0gbmV3IFJlZ0V4cChgXCIoJHtPYmplY3Qua2V5cyh0b2tlbk1hcCkuam9pbihcInxcIil9KVwiYCwgXCJnXCIpO1xuXHRyZXR1cm4gdmFsdWUucmVwbGFjZShyZXBsYWNlUmVnZXgsIChfLCBnMSkgPT4gdG9rZW5NYXBbZzFdKTtcbn1cbmZ1bmN0aW9uIHJlcGxhY2VTdHJpbmdUb1Rva2VuKHZhbHVlKSB7XG5cdGNvbnN0IGxpdGVyYWxWYWx1ZSA9IHJldmVyc2VkVG9rZW5NYXBbdmFsdWUudHJpbSgpXTtcblx0aWYgKGxpdGVyYWxWYWx1ZSkgcmV0dXJuIGBcIiR7bGl0ZXJhbFZhbHVlfVwiYDtcblx0Y29uc3QgcmVwbGFjZVJlZ2V4ID0gbmV3IFJlZ0V4cChgOlxcXFxzKigke09iamVjdC5rZXlzKHJldmVyc2VkVG9rZW5NYXApLmpvaW4oXCJ8XCIpfSlgLCBcImdcIik7XG5cdHJldHVybiB2YWx1ZS5yZXBsYWNlKHJlcGxhY2VSZWdleCwgKF8sIGcxKSA9PiBgOlwiJHtyZXZlcnNlZFRva2VuTWFwW2cxXX1cImApO1xufVxuLyoqXG4qIENvbnZlcnQgcHJvcCB0eXBlIGNvbnN0cnVjdG9yIHRvIHN0cmluZy5cbiovXG5mdW5jdGlvbiBnZXRQcm9wVHlwZSh0eXBlKSB7XG5cdGlmIChBcnJheS5pc0FycmF5KHR5cGUpKSByZXR1cm4gdHlwZS5tYXAoKHQpID0+IGdldFByb3BUeXBlKHQpKS5qb2luKFwiIG9yIFwiKTtcblx0aWYgKHR5cGUgPT0gbnVsbCkgcmV0dXJuIFwibnVsbFwiO1xuXHRjb25zdCBtYXRjaCA9IHR5cGUudG9TdHJpbmcoKS5tYXRjaChmblR5cGVSRSk7XG5cdHJldHVybiB0eXBlb2YgdHlwZSA9PT0gXCJmdW5jdGlvblwiID8gbWF0Y2ggJiYgbWF0Y2hbMV0gfHwgXCJhbnlcIiA6IFwiYW55XCI7XG59XG4vKipcbiogU2FuaXRpemUgZGF0YSB0byBiZSBwb3N0ZWQgdG8gdGhlIG90aGVyIHNpZGUuXG4qIFNpbmNlIHRoZSBtZXNzYWdlIHBvc3RlZCBpcyBzZW50IHdpdGggc3RydWN0dXJlZCBjbG9uZSxcbiogd2UgbmVlZCB0byBmaWx0ZXIgb3V0IGFueSB0eXBlcyB0aGF0IG1pZ2h0IGNhdXNlIGFuIGVycm9yLlxuKi9cbmZ1bmN0aW9uIHNhbml0aXplKGRhdGEpIHtcblx0aWYgKCFpc1ByaW1pdGl2ZSQxKGRhdGEpICYmICFBcnJheS5pc0FycmF5KGRhdGEpICYmICFpc1BsYWluT2JqZWN0KGRhdGEpKSByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKGRhdGEpO1xuXHRlbHNlIHJldHVybiBkYXRhO1xufVxuZnVuY3Rpb24gZ2V0U2V0dXBTdGF0ZVR5cGUocmF3KSB7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdHJlZjogaXNSZWYocmF3KSxcblx0XHRcdGNvbXB1dGVkOiBpc0NvbXB1dGVkKHJhdyksXG5cdFx0XHRyZWFjdGl2ZTogaXNSZWFjdGl2ZShyYXcpLFxuXHRcdFx0cmVhZG9ubHk6IGlzUmVhZE9ubHkocmF3KVxuXHRcdH07XG5cdH0gY2F0Y2gge1xuXHRcdHJldHVybiB7XG5cdFx0XHRyZWY6IGZhbHNlLFxuXHRcdFx0Y29tcHV0ZWQ6IGZhbHNlLFxuXHRcdFx0cmVhY3RpdmU6IGZhbHNlLFxuXHRcdFx0cmVhZG9ubHk6IGZhbHNlXG5cdFx0fTtcblx0fVxufVxuZnVuY3Rpb24gdG9SYXcodmFsdWUpIHtcblx0aWYgKHZhbHVlPy5fX3ZfcmF3KSByZXR1cm4gdmFsdWUuX192X3Jhdztcblx0cmV0dXJuIHZhbHVlO1xufVxuZnVuY3Rpb24gZXNjYXBlKHMpIHtcblx0cmV0dXJuIHMucmVwbGFjZSgvWzw+XCImXS9nLCAocykgPT4ge1xuXHRcdHJldHVybiBFU0Nbc10gfHwgcztcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvc3RhdGUvcHJvY2Vzcy50c1xuZnVuY3Rpb24gbWVyZ2VPcHRpb25zKHRvLCBmcm9tLCBpbnN0YW5jZSkge1xuXHRpZiAodHlwZW9mIGZyb20gPT09IFwiZnVuY3Rpb25cIikgZnJvbSA9IGZyb20ub3B0aW9ucztcblx0aWYgKCFmcm9tKSByZXR1cm4gdG87XG5cdGNvbnN0IHsgbWl4aW5zLCBleHRlbmRzOiBleHRlbmRzT3B0aW9ucyB9ID0gZnJvbTtcblx0ZXh0ZW5kc09wdGlvbnMgJiYgbWVyZ2VPcHRpb25zKHRvLCBleHRlbmRzT3B0aW9ucywgaW5zdGFuY2UpO1xuXHRtaXhpbnMgJiYgbWl4aW5zLmZvckVhY2goKG0pID0+IG1lcmdlT3B0aW9ucyh0bywgbSwgaW5zdGFuY2UpKTtcblx0Zm9yIChjb25zdCBrZXkgb2YgW1wiY29tcHV0ZWRcIiwgXCJpbmplY3RcIl0pIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoZnJvbSwga2V5KSkge1xuXHRcdHRvW2tleV0gPz89IHt9O1xuXHRcdE9iamVjdC5hc3NpZ24odG9ba2V5XSwgZnJvbVtrZXldKTtcblx0fVxuXHRyZXR1cm4gdG87XG59XG5mdW5jdGlvbiByZXNvbHZlTWVyZ2VkT3B0aW9ucyhpbnN0YW5jZSkge1xuXHRjb25zdCByYXcgPSBpbnN0YW5jZT8udHlwZTtcblx0aWYgKCFyYXcpIHJldHVybiB7fTtcblx0Y29uc3QgeyBtaXhpbnMsIGV4dGVuZHM6IGV4dGVuZHNPcHRpb25zIH0gPSByYXc7XG5cdGNvbnN0IGdsb2JhbE1peGlucyA9IGluc3RhbmNlLmFwcENvbnRleHQubWl4aW5zO1xuXHRpZiAoIWdsb2JhbE1peGlucy5sZW5ndGggJiYgIW1peGlucyAmJiAhZXh0ZW5kc09wdGlvbnMpIHJldHVybiByYXc7XG5cdGNvbnN0IG9wdGlvbnMgPSB7fTtcblx0Z2xvYmFsTWl4aW5zLmZvckVhY2goKG0pID0+IG1lcmdlT3B0aW9ucyhvcHRpb25zLCBtLCBpbnN0YW5jZSkpO1xuXHRtZXJnZU9wdGlvbnMob3B0aW9ucywgcmF3LCBpbnN0YW5jZSk7XG5cdHJldHVybiBvcHRpb25zO1xufVxuLyoqXG4qIFByb2Nlc3MgdGhlIHByb3BzIG9mIGFuIGluc3RhbmNlLlxuKiBNYWtlIHN1cmUgcmV0dXJuIGEgcGxhaW4gb2JqZWN0IGJlY2F1c2Ugd2luZG93LnBvc3RNZXNzYWdlKClcbiogd2lsbCB0aHJvdyBhbiBFcnJvciBpZiB0aGUgcGFzc2VkIG9iamVjdCBjb250YWlucyBGdW5jdGlvbnMuXG4qXG4qL1xuZnVuY3Rpb24gcHJvY2Vzc1Byb3BzKGluc3RhbmNlKSB7XG5cdGNvbnN0IHByb3BzID0gW107XG5cdGNvbnN0IHByb3BEZWZpbml0aW9ucyA9IGluc3RhbmNlPy50eXBlPy5wcm9wcztcblx0Zm9yIChjb25zdCBrZXkgaW4gaW5zdGFuY2U/LnByb3BzKSB7XG5cdFx0Y29uc3QgcHJvcERlZmluaXRpb24gPSBwcm9wRGVmaW5pdGlvbnMgPyBwcm9wRGVmaW5pdGlvbnNba2V5XSA6IG51bGw7XG5cdFx0Y29uc3QgY2FtZWxpemVLZXkgPSBjYW1lbGl6ZShrZXkpO1xuXHRcdHByb3BzLnB1c2goe1xuXHRcdFx0dHlwZTogXCJwcm9wc1wiLFxuXHRcdFx0a2V5OiBjYW1lbGl6ZUtleSxcblx0XHRcdHZhbHVlOiByZXR1cm5FcnJvcigoKSA9PiBpbnN0YW5jZS5wcm9wc1trZXldKSxcblx0XHRcdGVkaXRhYmxlOiB0cnVlLFxuXHRcdFx0bWV0YTogcHJvcERlZmluaXRpb24gPyB7XG5cdFx0XHRcdHR5cGU6IHByb3BEZWZpbml0aW9uLnR5cGUgPyBnZXRQcm9wVHlwZShwcm9wRGVmaW5pdGlvbi50eXBlKSA6IFwiYW55XCIsXG5cdFx0XHRcdHJlcXVpcmVkOiAhIXByb3BEZWZpbml0aW9uLnJlcXVpcmVkLFxuXHRcdFx0XHQuLi5wcm9wRGVmaW5pdGlvbi5kZWZhdWx0ID8geyBkZWZhdWx0OiBwcm9wRGVmaW5pdGlvbi5kZWZhdWx0LnRvU3RyaW5nKCkgfSA6IHt9XG5cdFx0XHR9IDogeyB0eXBlOiBcImludmFsaWRcIiB9XG5cdFx0fSk7XG5cdH1cblx0cmV0dXJuIHByb3BzO1xufVxuLyoqXG4qIFByb2Nlc3Mgc3RhdGUsIGZpbHRlcmluZyBvdXQgcHJvcHMgYW5kIFwiY2xlYW5cIiB0aGUgcmVzdWx0XG4qIHdpdGggYSBKU09OIGRhbmNlLiBUaGlzIHJlbW92ZXMgZnVuY3Rpb25zIHdoaWNoIGNhbiBjYXVzZVxuKiBlcnJvcnMgZHVyaW5nIHN0cnVjdHVyZWQgY2xvbmUgdXNlZCBieSB3aW5kb3cucG9zdE1lc3NhZ2UuXG4qXG4qL1xuZnVuY3Rpb24gcHJvY2Vzc1N0YXRlKGluc3RhbmNlKSB7XG5cdGNvbnN0IHR5cGUgPSBpbnN0YW5jZS50eXBlO1xuXHRjb25zdCBwcm9wcyA9IHR5cGU/LnByb3BzO1xuXHRjb25zdCBnZXR0ZXJzID0gdHlwZS52dWV4ICYmIHR5cGUudnVleC5nZXR0ZXJzO1xuXHRjb25zdCBjb21wdXRlZERlZnMgPSB0eXBlLmNvbXB1dGVkO1xuXHRjb25zdCBkYXRhID0ge1xuXHRcdC4uLmluc3RhbmNlLmRhdGEsXG5cdFx0Li4uaW5zdGFuY2UucmVuZGVyQ29udGV4dFxuXHR9O1xuXHRyZXR1cm4gT2JqZWN0LmtleXMoZGF0YSkuZmlsdGVyKChrZXkpID0+ICEocHJvcHMgJiYga2V5IGluIHByb3BzKSAmJiAhKGdldHRlcnMgJiYga2V5IGluIGdldHRlcnMpICYmICEoY29tcHV0ZWREZWZzICYmIGtleSBpbiBjb21wdXRlZERlZnMpKS5tYXAoKGtleSkgPT4gKHtcblx0XHRrZXksXG5cdFx0dHlwZTogXCJkYXRhXCIsXG5cdFx0dmFsdWU6IHJldHVybkVycm9yKCgpID0+IGRhdGFba2V5XSksXG5cdFx0ZWRpdGFibGU6IHRydWVcblx0fSkpO1xufVxuZnVuY3Rpb24gZ2V0U3RhdGVUeXBlQW5kTmFtZShpbmZvKSB7XG5cdGNvbnN0IHN0YXRlVHlwZSA9IGluZm8uY29tcHV0ZWQgPyBcImNvbXB1dGVkXCIgOiBpbmZvLnJlZiA/IFwicmVmXCIgOiBpbmZvLnJlYWN0aXZlID8gXCJyZWFjdGl2ZVwiIDogbnVsbDtcblx0cmV0dXJuIHtcblx0XHRzdGF0ZVR5cGUsXG5cdFx0c3RhdGVUeXBlTmFtZTogc3RhdGVUeXBlID8gYCR7c3RhdGVUeXBlLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpfSR7c3RhdGVUeXBlLnNsaWNlKDEpfWAgOiBudWxsXG5cdH07XG59XG5mdW5jdGlvbiBwcm9jZXNzU2V0dXBTdGF0ZShpbnN0YW5jZSkge1xuXHRjb25zdCByYXcgPSBpbnN0YW5jZS5kZXZ0b29sc1Jhd1NldHVwU3RhdGUgfHwge307XG5cdHJldHVybiBPYmplY3Qua2V5cyhpbnN0YW5jZS5zZXR1cFN0YXRlKS5maWx0ZXIoKGtleSkgPT4gIXZ1ZUJ1aWx0aW5zLmhhcyhrZXkpICYmIGtleS5zcGxpdCgvKD89W0EtWl0pLylbMF0gIT09IFwidXNlXCIpLm1hcCgoa2V5KSA9PiB7XG5cdFx0Y29uc3QgdmFsdWUgPSByZXR1cm5FcnJvcigoKSA9PiB0b1JhdyhpbnN0YW5jZS5zZXR1cFN0YXRlW2tleV0pKTtcblx0XHRjb25zdCBhY2Nlc3NFcnJvciA9IHZhbHVlIGluc3RhbmNlb2YgRXJyb3I7XG5cdFx0Y29uc3QgcmF3RGF0YSA9IHJhd1trZXldO1xuXHRcdGxldCByZXN1bHQ7XG5cdFx0bGV0IGlzT3RoZXJUeXBlID0gYWNjZXNzRXJyb3IgfHwgdHlwZW9mIHZhbHVlID09PSBcImZ1bmN0aW9uXCIgfHwgZW5zdXJlUHJvcGVydHlFeGlzdHModmFsdWUsIFwicmVuZGVyXCIpICYmIHR5cGVvZiB2YWx1ZS5yZW5kZXIgPT09IFwiZnVuY3Rpb25cIiB8fCBlbnN1cmVQcm9wZXJ0eUV4aXN0cyh2YWx1ZSwgXCJfX2FzeW5jTG9hZGVyXCIpICYmIHR5cGVvZiB2YWx1ZS5fX2FzeW5jTG9hZGVyID09PSBcImZ1bmN0aW9uXCIgfHwgdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICYmIChcInNldHVwXCIgaW4gdmFsdWUgfHwgXCJwcm9wc1wiIGluIHZhbHVlKSB8fCAvXnZbQS1aXS8udGVzdChrZXkpO1xuXHRcdGlmIChyYXdEYXRhICYmICFhY2Nlc3NFcnJvcikge1xuXHRcdFx0Y29uc3QgaW5mbyA9IGdldFNldHVwU3RhdGVUeXBlKHJhd0RhdGEpO1xuXHRcdFx0Y29uc3QgeyBzdGF0ZVR5cGUsIHN0YXRlVHlwZU5hbWUgfSA9IGdldFN0YXRlVHlwZUFuZE5hbWUoaW5mbyk7XG5cdFx0XHRjb25zdCBpc1N0YXRlID0gaW5mby5yZWYgfHwgaW5mby5jb21wdXRlZCB8fCBpbmZvLnJlYWN0aXZlO1xuXHRcdFx0Y29uc3QgcmF3ID0gZW5zdXJlUHJvcGVydHlFeGlzdHMocmF3RGF0YSwgXCJlZmZlY3RcIikgPyByYXdEYXRhLmVmZmVjdD8ucmF3Py50b1N0cmluZygpIHx8IHJhd0RhdGEuZWZmZWN0Py5mbj8udG9TdHJpbmcoKSA6IG51bGw7XG5cdFx0XHRpZiAoc3RhdGVUeXBlKSBpc090aGVyVHlwZSA9IGZhbHNlO1xuXHRcdFx0cmVzdWx0ID0ge1xuXHRcdFx0XHQuLi5zdGF0ZVR5cGUgPyB7XG5cdFx0XHRcdFx0c3RhdGVUeXBlLFxuXHRcdFx0XHRcdHN0YXRlVHlwZU5hbWVcblx0XHRcdFx0fSA6IHt9LFxuXHRcdFx0XHQuLi5yYXcgPyB7IHJhdyB9IDoge30sXG5cdFx0XHRcdGVkaXRhYmxlOiBpc1N0YXRlICYmICFpbmZvLnJlYWRvbmx5XG5cdFx0XHR9O1xuXHRcdH1cblx0XHRyZXR1cm4ge1xuXHRcdFx0a2V5LFxuXHRcdFx0dmFsdWUsXG5cdFx0XHR0eXBlOiBpc090aGVyVHlwZSA/IFwic2V0dXAgKG90aGVyKVwiIDogXCJzZXR1cFwiLFxuXHRcdFx0Li4ucmVzdWx0XG5cdFx0fTtcblx0fSk7XG59XG4vKipcbiogUHJvY2VzcyB0aGUgY29tcHV0ZWQgcHJvcGVydGllcyBvZiBhbiBpbnN0YW5jZS5cbiovXG5mdW5jdGlvbiBwcm9jZXNzQ29tcHV0ZWQoaW5zdGFuY2UsIG1lcmdlZFR5cGUpIHtcblx0Y29uc3QgdHlwZSA9IG1lcmdlZFR5cGU7XG5cdGNvbnN0IGNvbXB1dGVkID0gW107XG5cdGNvbnN0IGRlZnMgPSB0eXBlLmNvbXB1dGVkIHx8IHt9O1xuXHRmb3IgKGNvbnN0IGtleSBpbiBkZWZzKSB7XG5cdFx0Y29uc3QgZGVmID0gZGVmc1trZXldO1xuXHRcdGNvbnN0IHR5cGUgPSB0eXBlb2YgZGVmID09PSBcImZ1bmN0aW9uXCIgJiYgZGVmLnZ1ZXggPyBcInZ1ZXggYmluZGluZ3NcIiA6IFwiY29tcHV0ZWRcIjtcblx0XHRjb21wdXRlZC5wdXNoKHtcblx0XHRcdHR5cGUsXG5cdFx0XHRrZXksXG5cdFx0XHR2YWx1ZTogcmV0dXJuRXJyb3IoKCkgPT4gaW5zdGFuY2U/LnByb3h5Py5ba2V5XSksXG5cdFx0XHRlZGl0YWJsZTogdHlwZW9mIGRlZi5zZXQgPT09IFwiZnVuY3Rpb25cIlxuXHRcdH0pO1xuXHR9XG5cdHJldHVybiBjb21wdXRlZDtcbn1cbmZ1bmN0aW9uIHByb2Nlc3NBdHRycyhpbnN0YW5jZSkge1xuXHRyZXR1cm4gT2JqZWN0LmtleXMoaW5zdGFuY2UuYXR0cnMpLm1hcCgoa2V5KSA9PiAoe1xuXHRcdHR5cGU6IFwiYXR0cnNcIixcblx0XHRrZXksXG5cdFx0dmFsdWU6IHJldHVybkVycm9yKCgpID0+IGluc3RhbmNlLmF0dHJzW2tleV0pXG5cdH0pKTtcbn1cbmZ1bmN0aW9uIHByb2Nlc3NQcm92aWRlKGluc3RhbmNlKSB7XG5cdHJldHVybiBSZWZsZWN0Lm93bktleXMoaW5zdGFuY2UucHJvdmlkZXMpLm1hcCgoa2V5KSA9PiAoe1xuXHRcdHR5cGU6IFwicHJvdmlkZWRcIixcblx0XHRrZXk6IGtleS50b1N0cmluZygpLFxuXHRcdHZhbHVlOiByZXR1cm5FcnJvcigoKSA9PiBpbnN0YW5jZS5wcm92aWRlc1trZXldKVxuXHR9KSk7XG59XG5jb25zdCBoYXNPd25Qcm9wZXJ0eSA9IE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHk7XG5jb25zdCBoYXNPd24gPSAodmFsLCBrZXkpID0+IGhhc093blByb3BlcnR5LmNhbGwodmFsLCBrZXkpO1xuZnVuY3Rpb24gcHJvY2Vzc0luamVjdChpbnN0YW5jZSwgbWVyZ2VkVHlwZSkge1xuXHRpZiAoIW1lcmdlZFR5cGU/LmluamVjdCkgcmV0dXJuIFtdO1xuXHRsZXQga2V5cztcblx0aWYgKEFycmF5LmlzQXJyYXkobWVyZ2VkVHlwZS5pbmplY3QpKSBrZXlzID0gbWVyZ2VkVHlwZS5pbmplY3QubWFwKChrZXkpID0+ICh7XG5cdFx0a2V5LFxuXHRcdG9yaWdpbmFsS2V5OiBrZXlcblx0fSkpO1xuXHRlbHNlIGtleXMgPSBSZWZsZWN0Lm93bktleXMobWVyZ2VkVHlwZS5pbmplY3QpLm1hcCgoa2V5KSA9PiB7XG5cdFx0Y29uc3QgdmFsdWUgPSBtZXJnZWRUeXBlLmluamVjdFtrZXldO1xuXHRcdGxldCBvcmlnaW5hbEtleTtcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiIHx8IHR5cGVvZiB2YWx1ZSA9PT0gXCJzeW1ib2xcIikgb3JpZ2luYWxLZXkgPSB2YWx1ZTtcblx0XHRlbHNlIG9yaWdpbmFsS2V5ID0gdmFsdWUuZnJvbSA/PyBrZXk7XG5cdFx0cmV0dXJuIHtcblx0XHRcdGtleSxcblx0XHRcdG9yaWdpbmFsS2V5XG5cdFx0fTtcblx0fSk7XG5cdHJldHVybiBrZXlzLm1hcCgoeyBrZXksIG9yaWdpbmFsS2V5IH0pID0+ICh7XG5cdFx0dHlwZTogXCJpbmplY3RlZFwiLFxuXHRcdGtleToga2V5ICE9PSBvcmlnaW5hbEtleSA/IGAke1N0cmluZyhvcmlnaW5hbEtleSl9IOKeniAke1N0cmluZyhrZXkpfWAgOiBTdHJpbmcoa2V5KSxcblx0XHR2YWx1ZTogcmV0dXJuRXJyb3IoKCkgPT4gaGFzT3duKGluc3RhbmNlLmN0eCwga2V5KSA/IGluc3RhbmNlLmN0eFtrZXldIDogdm9pZCAwKVxuXHR9KSk7XG59XG5mdW5jdGlvbiBwcm9jZXNzUmVmcyhpbnN0YW5jZSkge1xuXHRyZXR1cm4gT2JqZWN0LmtleXMoaW5zdGFuY2UucmVmcykubWFwKChrZXkpID0+ICh7XG5cdFx0dHlwZTogXCJ0ZW1wbGF0ZSByZWZzXCIsXG5cdFx0a2V5LFxuXHRcdHZhbHVlOiByZXR1cm5FcnJvcigoKSA9PiBpbnN0YW5jZS5yZWZzW2tleV0pXG5cdH0pKTtcbn1cbmNvbnN0IHZub2RlRXZlbnRzID0gbmV3IFNldChbXG5cdFwidm5vZGUtYmVmb3JlLW1vdW50XCIsXG5cdFwidm5vZGUtbW91bnRlZFwiLFxuXHRcInZub2RlLWJlZm9yZS11cGRhdGVcIixcblx0XCJ2bm9kZS11cGRhdGVkXCIsXG5cdFwidm5vZGUtYmVmb3JlLXVubW91bnRcIixcblx0XCJ2bm9kZS11bm1vdW50ZWRcIlxuXSk7XG5mdW5jdGlvbiBwcm9jZXNzRXZlbnRMaXN0ZW5lcnMoaW5zdGFuY2UpIHtcblx0Y29uc3QgZW1pdHNEZWZpbml0aW9uID0gaW5zdGFuY2UudHlwZS5lbWl0cztcblx0Y29uc3QgZGVjbGFyZWRFbWl0cyA9IEFycmF5LmlzQXJyYXkoZW1pdHNEZWZpbml0aW9uKSA/IGVtaXRzRGVmaW5pdGlvbiA6IE9iamVjdC5rZXlzKGVtaXRzRGVmaW5pdGlvbiA/PyB7fSk7XG5cdGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhpbnN0YW5jZT8udm5vZGU/LnByb3BzID8/IHt9KTtcblx0Y29uc3QgcmVzdWx0ID0gW107XG5cdGZvciAoY29uc3Qga2V5IG9mIGtleXMpIHtcblx0XHRjb25zdCBbcHJlZml4LCAuLi5ldmVudE5hbWVQYXJ0c10gPSBrZXkuc3BsaXQoLyg/PVtBLVpdKS8pO1xuXHRcdGlmIChwcmVmaXggPT09IFwib25cIikge1xuXHRcdFx0Y29uc3QgZXZlbnROYW1lID0gZXZlbnROYW1lUGFydHMuam9pbihcIi1cIikudG9Mb3dlckNhc2UoKTtcblx0XHRcdGNvbnN0IGlzQnVpbHRJbiA9IHZub2RlRXZlbnRzLmhhcyhldmVudE5hbWUpO1xuXHRcdFx0Y29uc3QgaXNEZWNsYXJlZCA9IGRlY2xhcmVkRW1pdHMuaW5jbHVkZXMoZXZlbnROYW1lKSB8fCBkZWNsYXJlZEVtaXRzLmluY2x1ZGVzKGNhbWVsaXplKGV2ZW50TmFtZSkpO1xuXHRcdFx0Y29uc3QgdGV4dCA9IGlzQnVpbHRJbiA/IFwi4pyFIEJ1aWx0LWluXCIgOiBpc0RlY2xhcmVkID8gXCLinIUgRGVjbGFyZWRcIiA6IFwi4pqg77iPIE5vdCBkZWNsYXJlZFwiO1xuXHRcdFx0cmVzdWx0LnB1c2goe1xuXHRcdFx0XHR0eXBlOiBcImV2ZW50IGxpc3RlbmVyc1wiLFxuXHRcdFx0XHRrZXk6IGV2ZW50TmFtZSxcblx0XHRcdFx0dmFsdWU6IHsgX2N1c3RvbToge1xuXHRcdFx0XHRcdGRpc3BsYXlUZXh0OiB0ZXh0LFxuXHRcdFx0XHRcdGtleTogdGV4dCxcblx0XHRcdFx0XHR2YWx1ZTogdGV4dCxcblx0XHRcdFx0XHR0b29sdGlwVGV4dDogaXNCdWlsdEluID8gYFRoZSBldmVudCA8Y29kZT4ke2VzY2FwZShldmVudE5hbWUpfTwvY29kZT4gaXMgcGFydCBvZiBWdWUgYW5kIGRvZXNuJ3QgbmVlZCB0byBiZSBkZWNsYXJlZCBieSB0aGUgY29tcG9uZW50YCA6ICFpc0RlY2xhcmVkID8gYFRoZSBldmVudCA8Y29kZT4ke2VzY2FwZShldmVudE5hbWUpfTwvY29kZT4gaXMgbm90IGRlY2xhcmVkIGluIHRoZSA8Y29kZT5lbWl0czwvY29kZT4gb3B0aW9uLiBJdCB3aWxsIGxlYWsgaW50byB0aGUgY29tcG9uZW50J3MgYXR0cmlidXRlcyAoPGNvZGU+JGF0dHJzPC9jb2RlPikuYCA6IG51bGxcblx0XHRcdFx0fSB9XG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0cmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIHByb2Nlc3NJbnN0YW5jZVN0YXRlKGluc3RhbmNlKSB7XG5cdGNvbnN0IG1lcmdlZFR5cGUgPSByZXNvbHZlTWVyZ2VkT3B0aW9ucyhpbnN0YW5jZSk7XG5cdHJldHVybiBwcm9jZXNzUHJvcHMoaW5zdGFuY2UpLmNvbmNhdChwcm9jZXNzU3RhdGUoaW5zdGFuY2UpLCBwcm9jZXNzU2V0dXBTdGF0ZShpbnN0YW5jZSksIHByb2Nlc3NDb21wdXRlZChpbnN0YW5jZSwgbWVyZ2VkVHlwZSksIHByb2Nlc3NBdHRycyhpbnN0YW5jZSksIHByb2Nlc3NQcm92aWRlKGluc3RhbmNlKSwgcHJvY2Vzc0luamVjdChpbnN0YW5jZSwgbWVyZ2VkVHlwZSksIHByb2Nlc3NSZWZzKGluc3RhbmNlKSwgcHJvY2Vzc0V2ZW50TGlzdGVuZXJzKGluc3RhbmNlKSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvc3RhdGUvaW5kZXgudHNcbmZ1bmN0aW9uIGdldEluc3RhbmNlU3RhdGUocGFyYW1zKSB7XG5cdGNvbnN0IGluc3RhbmNlID0gZ2V0Q29tcG9uZW50SW5zdGFuY2UoYWN0aXZlQXBwUmVjb3JkLnZhbHVlLCBwYXJhbXMuaW5zdGFuY2VJZCk7XG5cdHJldHVybiB7XG5cdFx0aWQ6IGdldFVuaXF1ZUNvbXBvbmVudElkKGluc3RhbmNlKSxcblx0XHRuYW1lOiBnZXRJbnN0YW5jZU5hbWUoaW5zdGFuY2UpLFxuXHRcdGZpbGU6IGluc3RhbmNlPy50eXBlPy5fX2ZpbGUsXG5cdFx0c3RhdGU6IHByb2Nlc3NJbnN0YW5jZVN0YXRlKGluc3RhbmNlKSxcblx0XHRpbnN0YW5jZVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50L3RyZWUvZmlsdGVyLnRzXG52YXIgQ29tcG9uZW50RmlsdGVyID0gY2xhc3Mge1xuXHRjb25zdHJ1Y3RvcihmaWx0ZXIpIHtcblx0XHR0aGlzLmZpbHRlciA9IGZpbHRlciB8fCBcIlwiO1xuXHR9XG5cdC8qKlxuXHQqIENoZWNrIGlmIGFuIGluc3RhbmNlIGlzIHF1YWxpZmllZC5cblx0KlxuXHQqIEBwYXJhbSB7VnVlfFZub2RlfSBpbnN0YW5jZVxuXHQqIEByZXR1cm4ge2Jvb2xlYW59XG5cdCovXG5cdGlzUXVhbGlmaWVkKGluc3RhbmNlKSB7XG5cdFx0Y29uc3QgbmFtZSA9IGdldEluc3RhbmNlTmFtZShpbnN0YW5jZSk7XG5cdFx0cmV0dXJuIGNsYXNzaWZ5KG5hbWUpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXModGhpcy5maWx0ZXIpIHx8IGtlYmFiaXplKG5hbWUpLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXModGhpcy5maWx0ZXIpO1xuXHR9XG59O1xuZnVuY3Rpb24gY3JlYXRlQ29tcG9uZW50RmlsdGVyKGZpbHRlclRleHQpIHtcblx0cmV0dXJuIG5ldyBDb21wb25lbnRGaWx0ZXIoZmlsdGVyVGV4dCk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvdHJlZS93YWxrZXIudHNcbnZhciBDb21wb25lbnRXYWxrZXIgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcblx0XHR0aGlzLmNhcHR1cmVJZHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdGNvbnN0IHsgZmlsdGVyVGV4dCA9IFwiXCIsIG1heERlcHRoLCByZWN1cnNpdmVseSwgYXBpIH0gPSBvcHRpb25zO1xuXHRcdHRoaXMuY29tcG9uZW50RmlsdGVyID0gY3JlYXRlQ29tcG9uZW50RmlsdGVyKGZpbHRlclRleHQpO1xuXHRcdHRoaXMubWF4RGVwdGggPSBtYXhEZXB0aDtcblx0XHR0aGlzLnJlY3Vyc2l2ZWx5ID0gcmVjdXJzaXZlbHk7XG5cdFx0dGhpcy5hcGkgPSBhcGk7XG5cdH1cblx0Z2V0Q29tcG9uZW50VHJlZShpbnN0YW5jZSkge1xuXHRcdHRoaXMuY2FwdHVyZUlkcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0cmV0dXJuIHRoaXMuZmluZFF1YWxpZmllZENoaWxkcmVuKGluc3RhbmNlLCAwKTtcblx0fVxuXHRnZXRDb21wb25lbnRQYXJlbnRzKGluc3RhbmNlKSB7XG5cdFx0dGhpcy5jYXB0dXJlSWRzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHRjb25zdCBwYXJlbnRzID0gW107XG5cdFx0dGhpcy5jYXB0dXJlSWQoaW5zdGFuY2UpO1xuXHRcdGxldCBwYXJlbnQgPSBpbnN0YW5jZTtcblx0XHR3aGlsZSAocGFyZW50ID0gcGFyZW50LnBhcmVudCkge1xuXHRcdFx0dGhpcy5jYXB0dXJlSWQocGFyZW50KTtcblx0XHRcdHBhcmVudHMucHVzaChwYXJlbnQpO1xuXHRcdH1cblx0XHRyZXR1cm4gcGFyZW50cztcblx0fVxuXHRjYXB0dXJlSWQoaW5zdGFuY2UpIHtcblx0XHRpZiAoIWluc3RhbmNlKSByZXR1cm4gbnVsbDtcblx0XHRjb25zdCBpZCA9IGluc3RhbmNlLl9fVlVFX0RFVlRPT0xTX05FWFRfVUlEX18gIT0gbnVsbCA/IGluc3RhbmNlLl9fVlVFX0RFVlRPT0xTX05FWFRfVUlEX18gOiBnZXRVbmlxdWVDb21wb25lbnRJZChpbnN0YW5jZSk7XG5cdFx0aW5zdGFuY2UuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXyA9IGlkO1xuXHRcdGlmICh0aGlzLmNhcHR1cmVJZHMuaGFzKGlkKSkgcmV0dXJuIG51bGw7XG5cdFx0ZWxzZSB0aGlzLmNhcHR1cmVJZHMuc2V0KGlkLCB2b2lkIDApO1xuXHRcdHRoaXMubWFyayhpbnN0YW5jZSk7XG5cdFx0cmV0dXJuIGlkO1xuXHR9XG5cdC8qKlxuXHQqIENhcHR1cmUgdGhlIG1ldGEgaW5mb3JtYXRpb24gb2YgYW4gaW5zdGFuY2UuIChyZWN1cnNpdmUpXG5cdCpcblx0KiBAcGFyYW0ge1Z1ZX0gaW5zdGFuY2Vcblx0KiBAcmV0dXJuIHtvYmplY3R9XG5cdCovXG5cdGFzeW5jIGNhcHR1cmUoaW5zdGFuY2UsIGRlcHRoKSB7XG5cdFx0aWYgKCFpbnN0YW5jZSkgcmV0dXJuIG51bGw7XG5cdFx0Y29uc3QgaWQgPSB0aGlzLmNhcHR1cmVJZChpbnN0YW5jZSk7XG5cdFx0Y29uc3QgbmFtZSA9IGdldEluc3RhbmNlTmFtZShpbnN0YW5jZSk7XG5cdFx0Y29uc3QgY2hpbGRyZW4gPSB0aGlzLmdldEludGVybmFsSW5zdGFuY2VDaGlsZHJlbihpbnN0YW5jZS5zdWJUcmVlKS5maWx0ZXIoKGNoaWxkKSA9PiAhaXNCZWluZ0Rlc3Ryb3llZChjaGlsZCkpO1xuXHRcdGNvbnN0IHBhcmVudHMgPSB0aGlzLmdldENvbXBvbmVudFBhcmVudHMoaW5zdGFuY2UpIHx8IFtdO1xuXHRcdGNvbnN0IGluYWN0aXZlID0gISFpbnN0YW5jZS5pc0RlYWN0aXZhdGVkIHx8IHBhcmVudHMuc29tZSgocGFyZW50KSA9PiBwYXJlbnQuaXNEZWFjdGl2YXRlZCk7XG5cdFx0Y29uc3QgdHJlZU5vZGUgPSB7XG5cdFx0XHR1aWQ6IGluc3RhbmNlLnVpZCxcblx0XHRcdGlkLFxuXHRcdFx0bmFtZSxcblx0XHRcdHJlbmRlcktleTogZ2V0UmVuZGVyS2V5KGluc3RhbmNlLnZub2RlID8gaW5zdGFuY2Uudm5vZGUua2V5IDogbnVsbCksXG5cdFx0XHRpbmFjdGl2ZSxcblx0XHRcdGNoaWxkcmVuOiBbXSxcblx0XHRcdGhhc0NoaWxkcmVuOiAhIWNoaWxkcmVuLmxlbmd0aCxcblx0XHRcdGlzRnJhZ21lbnQ6IGlzRnJhZ21lbnQoaW5zdGFuY2UpLFxuXHRcdFx0dGFnczogdHlwZW9mIGluc3RhbmNlLnR5cGUgIT09IFwiZnVuY3Rpb25cIiA/IFtdIDogW3tcblx0XHRcdFx0bGFiZWw6IFwiZnVuY3Rpb25hbFwiLFxuXHRcdFx0XHR0ZXh0Q29sb3I6IDU1OTI0MDUsXG5cdFx0XHRcdGJhY2tncm91bmRDb2xvcjogMTU2NTg3MzRcblx0XHRcdH1dLFxuXHRcdFx0YXV0b09wZW46IHRoaXMucmVjdXJzaXZlbHksXG5cdFx0XHRmaWxlOiBpbnN0YW5jZS50eXBlLl9fZmlsZSB8fCBcIlwiXG5cdFx0fTtcblx0XHRpZiAoZGVwdGggPCB0aGlzLm1heERlcHRoIHx8IGluc3RhbmNlLnR5cGUuX19pc0tlZXBBbGl2ZSB8fCBwYXJlbnRzLnNvbWUoKHBhcmVudCkgPT4gcGFyZW50LnR5cGUuX19pc0tlZXBBbGl2ZSkpIHRyZWVOb2RlLmNoaWxkcmVuID0gYXdhaXQgUHJvbWlzZS5hbGwoY2hpbGRyZW4ubWFwKChjaGlsZCkgPT4gdGhpcy5jYXB0dXJlKGNoaWxkLCBkZXB0aCArIDEpKS5maWx0ZXIoQm9vbGVhbikpO1xuXHRcdGlmICh0aGlzLmlzS2VlcEFsaXZlKGluc3RhbmNlKSkge1xuXHRcdFx0Y29uc3QgY2FjaGVkQ29tcG9uZW50cyA9IHRoaXMuZ2V0S2VlcEFsaXZlQ2FjaGVkSW5zdGFuY2VzKGluc3RhbmNlKTtcblx0XHRcdGNvbnN0IGNoaWxkcmVuSWRzID0gY2hpbGRyZW4ubWFwKChjaGlsZCkgPT4gY2hpbGQuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXyk7XG5cdFx0XHRmb3IgKGNvbnN0IGNhY2hlZENoaWxkIG9mIGNhY2hlZENvbXBvbmVudHMpIGlmICghY2hpbGRyZW5JZHMuaW5jbHVkZXMoY2FjaGVkQ2hpbGQuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXykpIHtcblx0XHRcdFx0Y29uc3Qgbm9kZSA9IGF3YWl0IHRoaXMuY2FwdHVyZSh7XG5cdFx0XHRcdFx0Li4uY2FjaGVkQ2hpbGQsXG5cdFx0XHRcdFx0aXNEZWFjdGl2YXRlZDogdHJ1ZVxuXHRcdFx0XHR9LCBkZXB0aCArIDEpO1xuXHRcdFx0XHRpZiAobm9kZSkgdHJlZU5vZGUuY2hpbGRyZW4ucHVzaChub2RlKTtcblx0XHRcdH1cblx0XHR9XG5cdFx0Y29uc3QgZmlyc3RFbGVtZW50ID0gZ2V0Um9vdEVsZW1lbnRzRnJvbUNvbXBvbmVudEluc3RhbmNlKGluc3RhbmNlKVswXTtcblx0XHRpZiAoZmlyc3RFbGVtZW50Py5wYXJlbnRFbGVtZW50KSB7XG5cdFx0XHRjb25zdCBwYXJlbnRJbnN0YW5jZSA9IGluc3RhbmNlLnBhcmVudDtcblx0XHRcdGNvbnN0IHBhcmVudFJvb3RFbGVtZW50cyA9IHBhcmVudEluc3RhbmNlID8gZ2V0Um9vdEVsZW1lbnRzRnJvbUNvbXBvbmVudEluc3RhbmNlKHBhcmVudEluc3RhbmNlKSA6IFtdO1xuXHRcdFx0bGV0IGVsID0gZmlyc3RFbGVtZW50O1xuXHRcdFx0Y29uc3QgaW5kZXhMaXN0ID0gW107XG5cdFx0XHRkbyB7XG5cdFx0XHRcdGluZGV4TGlzdC5wdXNoKEFycmF5LmZyb20oZWwucGFyZW50RWxlbWVudC5jaGlsZE5vZGVzKS5pbmRleE9mKGVsKSk7XG5cdFx0XHRcdGVsID0gZWwucGFyZW50RWxlbWVudDtcblx0XHRcdH0gd2hpbGUgKGVsLnBhcmVudEVsZW1lbnQgJiYgcGFyZW50Um9vdEVsZW1lbnRzLmxlbmd0aCAmJiAhcGFyZW50Um9vdEVsZW1lbnRzLmluY2x1ZGVzKGVsKSk7XG5cdFx0XHR0cmVlTm9kZS5kb21PcmRlciA9IGluZGV4TGlzdC5yZXZlcnNlKCk7XG5cdFx0fSBlbHNlIHRyZWVOb2RlLmRvbU9yZGVyID0gWy0xXTtcblx0XHRpZiAoaW5zdGFuY2Uuc3VzcGVuc2U/LnN1c3BlbnNlS2V5KSB7XG5cdFx0XHR0cmVlTm9kZS50YWdzLnB1c2goe1xuXHRcdFx0XHRsYWJlbDogaW5zdGFuY2Uuc3VzcGVuc2Uuc3VzcGVuc2VLZXksXG5cdFx0XHRcdGJhY2tncm91bmRDb2xvcjogMTQ5Nzk4MTIsXG5cdFx0XHRcdHRleHRDb2xvcjogMTY3NzcyMTVcblx0XHRcdH0pO1xuXHRcdFx0dGhpcy5tYXJrKGluc3RhbmNlLCB0cnVlKTtcblx0XHR9XG5cdFx0dGhpcy5hcGkudmlzaXRDb21wb25lbnRUcmVlKHtcblx0XHRcdHRyZWVOb2RlLFxuXHRcdFx0Y29tcG9uZW50SW5zdGFuY2U6IGluc3RhbmNlLFxuXHRcdFx0YXBwOiBpbnN0YW5jZS5hcHBDb250ZXh0LmFwcCxcblx0XHRcdGZpbHRlcjogdGhpcy5jb21wb25lbnRGaWx0ZXIuZmlsdGVyXG5cdFx0fSk7XG5cdFx0cmV0dXJuIHRyZWVOb2RlO1xuXHR9XG5cdC8qKlxuXHQqIEZpbmQgcXVhbGlmaWVkIGNoaWxkcmVuIGZyb20gYSBzaW5nbGUgaW5zdGFuY2UuXG5cdCogSWYgdGhlIGluc3RhbmNlIGl0c2VsZiBpcyBxdWFsaWZpZWQsIGp1c3QgcmV0dXJuIGl0c2VsZi5cblx0KiBUaGlzIGlzIG9rIGJlY2F1c2UgW10uY29uY2F0IHdvcmtzIGluIGJvdGggY2FzZXMuXG5cdCpcblx0KiBAcGFyYW0ge1Z1ZXxWbm9kZX0gaW5zdGFuY2Vcblx0KiBAcmV0dXJuIHtWdWV8QXJyYXl9XG5cdCovXG5cdGFzeW5jIGZpbmRRdWFsaWZpZWRDaGlsZHJlbihpbnN0YW5jZSwgZGVwdGgpIHtcblx0XHRpZiAodGhpcy5jb21wb25lbnRGaWx0ZXIuaXNRdWFsaWZpZWQoaW5zdGFuY2UpICYmICFpbnN0YW5jZS50eXBlLmRldnRvb2xzPy5oaWRlKSByZXR1cm4gW2F3YWl0IHRoaXMuY2FwdHVyZShpbnN0YW5jZSwgZGVwdGgpXTtcblx0XHRlbHNlIGlmIChpbnN0YW5jZS5zdWJUcmVlKSB7XG5cdFx0XHRjb25zdCBsaXN0ID0gdGhpcy5pc0tlZXBBbGl2ZShpbnN0YW5jZSkgPyB0aGlzLmdldEtlZXBBbGl2ZUNhY2hlZEluc3RhbmNlcyhpbnN0YW5jZSkgOiB0aGlzLmdldEludGVybmFsSW5zdGFuY2VDaGlsZHJlbihpbnN0YW5jZS5zdWJUcmVlKTtcblx0XHRcdHJldHVybiB0aGlzLmZpbmRRdWFsaWZpZWRDaGlsZHJlbkZyb21MaXN0KGxpc3QsIGRlcHRoKTtcblx0XHR9IGVsc2UgcmV0dXJuIFtdO1xuXHR9XG5cdC8qKlxuXHQqIEl0ZXJhdGUgdGhyb3VnaCBhbiBhcnJheSBvZiBpbnN0YW5jZXMgYW5kIGZsYXR0ZW4gaXQgaW50b1xuXHQqIGFuIGFycmF5IG9mIHF1YWxpZmllZCBpbnN0YW5jZXMuIFRoaXMgaXMgYSBkZXB0aC1maXJzdFxuXHQqIHRyYXZlcnNhbCAtIGUuZy4gaWYgYW4gaW5zdGFuY2UgaXMgbm90IG1hdGNoZWQsIHdlIHdpbGxcblx0KiByZWN1cnNpdmVseSBnbyBkZWVwZXIgdW50aWwgYSBxdWFsaWZpZWQgY2hpbGQgaXMgZm91bmQuXG5cdCpcblx0KiBAcGFyYW0ge0FycmF5fSBpbnN0YW5jZXNcblx0KiBAcmV0dXJuIHtBcnJheX1cblx0Ki9cblx0YXN5bmMgZmluZFF1YWxpZmllZENoaWxkcmVuRnJvbUxpc3QoaW5zdGFuY2VzLCBkZXB0aCkge1xuXHRcdGluc3RhbmNlcyA9IGluc3RhbmNlcy5maWx0ZXIoKGNoaWxkKSA9PiAhaXNCZWluZ0Rlc3Ryb3llZChjaGlsZCkgJiYgIWNoaWxkLnR5cGUuZGV2dG9vbHM/LmhpZGUpO1xuXHRcdGlmICghdGhpcy5jb21wb25lbnRGaWx0ZXIuZmlsdGVyKSByZXR1cm4gUHJvbWlzZS5hbGwoaW5zdGFuY2VzLm1hcCgoY2hpbGQpID0+IHRoaXMuY2FwdHVyZShjaGlsZCwgZGVwdGgpKSk7XG5cdFx0ZWxzZSByZXR1cm4gQXJyYXkucHJvdG90eXBlLmNvbmNhdC5hcHBseShbXSwgYXdhaXQgUHJvbWlzZS5hbGwoaW5zdGFuY2VzLm1hcCgoaSkgPT4gdGhpcy5maW5kUXVhbGlmaWVkQ2hpbGRyZW4oaSwgZGVwdGgpKSkpO1xuXHR9XG5cdC8qKlxuXHQqIEdldCBjaGlsZHJlbiBmcm9tIGEgY29tcG9uZW50IGluc3RhbmNlLlxuXHQqL1xuXHRnZXRJbnRlcm5hbEluc3RhbmNlQ2hpbGRyZW4oc3ViVHJlZSwgc3VzcGVuc2UgPSBudWxsKSB7XG5cdFx0Y29uc3QgbGlzdCA9IFtdO1xuXHRcdGlmIChzdWJUcmVlKSB7XG5cdFx0XHRpZiAoc3ViVHJlZS5jb21wb25lbnQpICFzdXNwZW5zZSA/IGxpc3QucHVzaChzdWJUcmVlLmNvbXBvbmVudCkgOiBsaXN0LnB1c2goe1xuXHRcdFx0XHQuLi5zdWJUcmVlLmNvbXBvbmVudCxcblx0XHRcdFx0c3VzcGVuc2Vcblx0XHRcdH0pO1xuXHRcdFx0ZWxzZSBpZiAoc3ViVHJlZS5zdXNwZW5zZSkge1xuXHRcdFx0XHRjb25zdCBzdXNwZW5zZUtleSA9ICFzdWJUcmVlLnN1c3BlbnNlLmlzSW5GYWxsYmFjayA/IFwic3VzcGVuc2UgZGVmYXVsdFwiIDogXCJzdXNwZW5zZSBmYWxsYmFja1wiO1xuXHRcdFx0XHRsaXN0LnB1c2goLi4udGhpcy5nZXRJbnRlcm5hbEluc3RhbmNlQ2hpbGRyZW4oc3ViVHJlZS5zdXNwZW5zZS5hY3RpdmVCcmFuY2gsIHtcblx0XHRcdFx0XHQuLi5zdWJUcmVlLnN1c3BlbnNlLFxuXHRcdFx0XHRcdHN1c3BlbnNlS2V5XG5cdFx0XHRcdH0pKTtcblx0XHRcdH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShzdWJUcmVlLmNoaWxkcmVuKSkgc3ViVHJlZS5jaGlsZHJlbi5mb3JFYWNoKChjaGlsZFN1YlRyZWUpID0+IHtcblx0XHRcdFx0aWYgKGNoaWxkU3ViVHJlZS5jb21wb25lbnQpICFzdXNwZW5zZSA/IGxpc3QucHVzaChjaGlsZFN1YlRyZWUuY29tcG9uZW50KSA6IGxpc3QucHVzaCh7XG5cdFx0XHRcdFx0Li4uY2hpbGRTdWJUcmVlLmNvbXBvbmVudCxcblx0XHRcdFx0XHRzdXNwZW5zZVxuXHRcdFx0XHR9KTtcblx0XHRcdFx0ZWxzZSBsaXN0LnB1c2goLi4udGhpcy5nZXRJbnRlcm5hbEluc3RhbmNlQ2hpbGRyZW4oY2hpbGRTdWJUcmVlLCBzdXNwZW5zZSkpO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdHJldHVybiBsaXN0LmZpbHRlcigoY2hpbGQpID0+ICFpc0JlaW5nRGVzdHJveWVkKGNoaWxkKSAmJiAhY2hpbGQudHlwZS5kZXZ0b29scz8uaGlkZSk7XG5cdH1cblx0LyoqXG5cdCogTWFyayBhbiBpbnN0YW5jZSBhcyBjYXB0dXJlZCBhbmQgc3RvcmUgaXQgaW4gdGhlIGluc3RhbmNlIG1hcC5cblx0KlxuXHQqIEBwYXJhbSB7VnVlfSBpbnN0YW5jZVxuXHQqL1xuXHRtYXJrKGluc3RhbmNlLCBmb3JjZSA9IGZhbHNlKSB7XG5cdFx0Y29uc3QgaW5zdGFuY2VNYXAgPSBnZXRBcHBSZWNvcmQoaW5zdGFuY2UpLmluc3RhbmNlTWFwO1xuXHRcdGlmIChmb3JjZSB8fCAhaW5zdGFuY2VNYXAuaGFzKGluc3RhbmNlLl9fVlVFX0RFVlRPT0xTX05FWFRfVUlEX18pKSB7XG5cdFx0XHRpbnN0YW5jZU1hcC5zZXQoaW5zdGFuY2UuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXywgaW5zdGFuY2UpO1xuXHRcdFx0YWN0aXZlQXBwUmVjb3JkLnZhbHVlLmluc3RhbmNlTWFwID0gaW5zdGFuY2VNYXA7XG5cdFx0fVxuXHR9XG5cdGlzS2VlcEFsaXZlKGluc3RhbmNlKSB7XG5cdFx0cmV0dXJuIGluc3RhbmNlLnR5cGUuX19pc0tlZXBBbGl2ZSAmJiBpbnN0YW5jZS5fX3ZfY2FjaGU7XG5cdH1cblx0Z2V0S2VlcEFsaXZlQ2FjaGVkSW5zdGFuY2VzKGluc3RhbmNlKSB7XG5cdFx0cmV0dXJuIEFycmF5LmZyb20oaW5zdGFuY2UuX192X2NhY2hlLnZhbHVlcygpKS5tYXAoKHZub2RlKSA9PiB2bm9kZS5jb21wb25lbnQpLmZpbHRlcihCb29sZWFuKTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3RpbWVsaW5lL3BlcmYudHNcbmNvbnN0IG1hcmtFbmRRdWV1ZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5jb25zdCBQRVJGT1JNQU5DRV9FVkVOVF9MQVlFUl9JRCA9IFwicGVyZm9ybWFuY2VcIjtcbmFzeW5jIGZ1bmN0aW9uIHBlcmZvcm1hbmNlTWFya1N0YXJ0KGFwaSwgYXBwLCB1aWQsIHZtLCB0eXBlLCB0aW1lKSB7XG5cdGNvbnN0IGFwcFJlY29yZCA9IGF3YWl0IGdldEFwcFJlY29yZChhcHApO1xuXHRpZiAoIWFwcFJlY29yZCkgcmV0dXJuO1xuXHRjb25zdCBjb21wb25lbnROYW1lID0gZ2V0SW5zdGFuY2VOYW1lKHZtKSB8fCBcIlVua25vd24gQ29tcG9uZW50XCI7XG5cdGNvbnN0IGdyb3VwSWQgPSBkZXZ0b29sc1N0YXRlLnBlcmZVbmlxdWVHcm91cElkKys7XG5cdGNvbnN0IGdyb3VwS2V5ID0gYCR7dWlkfS0ke3R5cGV9YDtcblx0YXBwUmVjb3JkLnBlcmZHcm91cElkcy5zZXQoZ3JvdXBLZXksIHtcblx0XHRncm91cElkLFxuXHRcdHRpbWVcblx0fSk7XG5cdGF3YWl0IGFwaS5hZGRUaW1lbGluZUV2ZW50KHtcblx0XHRsYXllcklkOiBQRVJGT1JNQU5DRV9FVkVOVF9MQVlFUl9JRCxcblx0XHRldmVudDoge1xuXHRcdFx0dGltZTogRGF0ZS5ub3coKSxcblx0XHRcdGRhdGE6IHtcblx0XHRcdFx0Y29tcG9uZW50OiBjb21wb25lbnROYW1lLFxuXHRcdFx0XHR0eXBlLFxuXHRcdFx0XHRtZWFzdXJlOiBcInN0YXJ0XCJcblx0XHRcdH0sXG5cdFx0XHR0aXRsZTogY29tcG9uZW50TmFtZSxcblx0XHRcdHN1YnRpdGxlOiB0eXBlLFxuXHRcdFx0Z3JvdXBJZFxuXHRcdH1cblx0fSk7XG5cdGlmIChtYXJrRW5kUXVldWUuaGFzKGdyb3VwS2V5KSkge1xuXHRcdGNvbnN0IHsgYXBwLCB1aWQsIGluc3RhbmNlLCB0eXBlLCB0aW1lIH0gPSBtYXJrRW5kUXVldWUuZ2V0KGdyb3VwS2V5KTtcblx0XHRtYXJrRW5kUXVldWUuZGVsZXRlKGdyb3VwS2V5KTtcblx0XHRhd2FpdCBwZXJmb3JtYW5jZU1hcmtFbmQoYXBpLCBhcHAsIHVpZCwgaW5zdGFuY2UsIHR5cGUsIHRpbWUpO1xuXHR9XG59XG5mdW5jdGlvbiBwZXJmb3JtYW5jZU1hcmtFbmQoYXBpLCBhcHAsIHVpZCwgdm0sIHR5cGUsIHRpbWUpIHtcblx0Y29uc3QgYXBwUmVjb3JkID0gZ2V0QXBwUmVjb3JkKGFwcCk7XG5cdGlmICghYXBwUmVjb3JkKSByZXR1cm47XG5cdGNvbnN0IGNvbXBvbmVudE5hbWUgPSBnZXRJbnN0YW5jZU5hbWUodm0pIHx8IFwiVW5rbm93biBDb21wb25lbnRcIjtcblx0Y29uc3QgZ3JvdXBLZXkgPSBgJHt1aWR9LSR7dHlwZX1gO1xuXHRjb25zdCBncm91cEluZm8gPSBhcHBSZWNvcmQucGVyZkdyb3VwSWRzLmdldChncm91cEtleSk7XG5cdGlmIChncm91cEluZm8pIHtcblx0XHRjb25zdCBncm91cElkID0gZ3JvdXBJbmZvLmdyb3VwSWQ7XG5cdFx0Y29uc3QgZHVyYXRpb24gPSB0aW1lIC0gZ3JvdXBJbmZvLnRpbWU7XG5cdFx0YXBpLmFkZFRpbWVsaW5lRXZlbnQoe1xuXHRcdFx0bGF5ZXJJZDogUEVSRk9STUFOQ0VfRVZFTlRfTEFZRVJfSUQsXG5cdFx0XHRldmVudDoge1xuXHRcdFx0XHR0aW1lOiBEYXRlLm5vdygpLFxuXHRcdFx0XHRkYXRhOiB7XG5cdFx0XHRcdFx0Y29tcG9uZW50OiBjb21wb25lbnROYW1lLFxuXHRcdFx0XHRcdHR5cGUsXG5cdFx0XHRcdFx0bWVhc3VyZTogXCJlbmRcIixcblx0XHRcdFx0XHRkdXJhdGlvbjogeyBfY3VzdG9tOiB7XG5cdFx0XHRcdFx0XHR0eXBlOiBcIkR1cmF0aW9uXCIsXG5cdFx0XHRcdFx0XHR2YWx1ZTogZHVyYXRpb24sXG5cdFx0XHRcdFx0XHRkaXNwbGF5OiBgJHtkdXJhdGlvbn0gbXNgXG5cdFx0XHRcdFx0fSB9XG5cdFx0XHRcdH0sXG5cdFx0XHRcdHRpdGxlOiBjb21wb25lbnROYW1lLFxuXHRcdFx0XHRzdWJ0aXRsZTogdHlwZSxcblx0XHRcdFx0Z3JvdXBJZFxuXHRcdFx0fVxuXHRcdH0pO1xuXHR9IGVsc2UgbWFya0VuZFF1ZXVlLnNldChncm91cEtleSwge1xuXHRcdGFwcCxcblx0XHR1aWQsXG5cdFx0aW5zdGFuY2U6IHZtLFxuXHRcdHR5cGUsXG5cdFx0dGltZVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3RpbWVsaW5lL2luZGV4LnRzXG5jb25zdCBDT01QT05FTlRfRVZFTlRfTEFZRVJfSUQgPSBcImNvbXBvbmVudC1ldmVudFwiO1xuZnVuY3Rpb24gc2V0dXBCdWlsdGluVGltZWxpbmVMYXllcnMoYXBpKSB7XG5cdGlmICghaXNCcm93c2VyKSByZXR1cm47XG5cdGFwaS5hZGRUaW1lbGluZUxheWVyKHtcblx0XHRpZDogXCJtb3VzZVwiLFxuXHRcdGxhYmVsOiBcIk1vdXNlXCIsXG5cdFx0Y29sb3I6IDEwNzY4ODE1XG5cdH0pO1xuXHRbXG5cdFx0XCJtb3VzZWRvd25cIixcblx0XHRcIm1vdXNldXBcIixcblx0XHRcImNsaWNrXCIsXG5cdFx0XCJkYmxjbGlja1wiXG5cdF0uZm9yRWFjaCgoZXZlbnRUeXBlKSA9PiB7XG5cdFx0aWYgKCFkZXZ0b29sc1N0YXRlLnRpbWVsaW5lTGF5ZXJzU3RhdGUucmVjb3JkaW5nU3RhdGUgfHwgIWRldnRvb2xzU3RhdGUudGltZWxpbmVMYXllcnNTdGF0ZS5tb3VzZUV2ZW50RW5hYmxlZCkgcmV0dXJuO1xuXHRcdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKGV2ZW50VHlwZSwgYXN5bmMgKGV2ZW50KSA9PiB7XG5cdFx0XHRhd2FpdCBhcGkuYWRkVGltZWxpbmVFdmVudCh7XG5cdFx0XHRcdGxheWVySWQ6IFwibW91c2VcIixcblx0XHRcdFx0ZXZlbnQ6IHtcblx0XHRcdFx0XHR0aW1lOiBEYXRlLm5vdygpLFxuXHRcdFx0XHRcdGRhdGE6IHtcblx0XHRcdFx0XHRcdHR5cGU6IGV2ZW50VHlwZSxcblx0XHRcdFx0XHRcdHg6IGV2ZW50LmNsaWVudFgsXG5cdFx0XHRcdFx0XHR5OiBldmVudC5jbGllbnRZXG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0XHR0aXRsZTogZXZlbnRUeXBlXG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH0sIHtcblx0XHRcdGNhcHR1cmU6IHRydWUsXG5cdFx0XHRwYXNzaXZlOiB0cnVlXG5cdFx0fSk7XG5cdH0pO1xuXHRhcGkuYWRkVGltZWxpbmVMYXllcih7XG5cdFx0aWQ6IFwia2V5Ym9hcmRcIixcblx0XHRsYWJlbDogXCJLZXlib2FyZFwiLFxuXHRcdGNvbG9yOiA4NDc1MDU1XG5cdH0pO1xuXHRbXG5cdFx0XCJrZXl1cFwiLFxuXHRcdFwia2V5ZG93blwiLFxuXHRcdFwia2V5cHJlc3NcIlxuXHRdLmZvckVhY2goKGV2ZW50VHlwZSkgPT4ge1xuXHRcdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKGV2ZW50VHlwZSwgYXN5bmMgKGV2ZW50KSA9PiB7XG5cdFx0XHRpZiAoIWRldnRvb2xzU3RhdGUudGltZWxpbmVMYXllcnNTdGF0ZS5yZWNvcmRpbmdTdGF0ZSB8fCAhZGV2dG9vbHNTdGF0ZS50aW1lbGluZUxheWVyc1N0YXRlLmtleWJvYXJkRXZlbnRFbmFibGVkKSByZXR1cm47XG5cdFx0XHRhd2FpdCBhcGkuYWRkVGltZWxpbmVFdmVudCh7XG5cdFx0XHRcdGxheWVySWQ6IFwia2V5Ym9hcmRcIixcblx0XHRcdFx0ZXZlbnQ6IHtcblx0XHRcdFx0XHR0aW1lOiBEYXRlLm5vdygpLFxuXHRcdFx0XHRcdGRhdGE6IHtcblx0XHRcdFx0XHRcdHR5cGU6IGV2ZW50VHlwZSxcblx0XHRcdFx0XHRcdGtleTogZXZlbnQua2V5LFxuXHRcdFx0XHRcdFx0Y3RybEtleTogZXZlbnQuY3RybEtleSxcblx0XHRcdFx0XHRcdHNoaWZ0S2V5OiBldmVudC5zaGlmdEtleSxcblx0XHRcdFx0XHRcdGFsdEtleTogZXZlbnQuYWx0S2V5LFxuXHRcdFx0XHRcdFx0bWV0YUtleTogZXZlbnQubWV0YUtleVxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0dGl0bGU6IGV2ZW50LmtleVxuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHR9LCB7XG5cdFx0XHRjYXB0dXJlOiB0cnVlLFxuXHRcdFx0cGFzc2l2ZTogdHJ1ZVxuXHRcdH0pO1xuXHR9KTtcblx0YXBpLmFkZFRpbWVsaW5lTGF5ZXIoe1xuXHRcdGlkOiBDT01QT05FTlRfRVZFTlRfTEFZRVJfSUQsXG5cdFx0bGFiZWw6IFwiQ29tcG9uZW50IGV2ZW50c1wiLFxuXHRcdGNvbG9yOiA1MjI2NjM3XG5cdH0pO1xuXHRob29rLm9uLmNvbXBvbmVudEVtaXQoYXN5bmMgKGFwcCwgaW5zdGFuY2UsIGV2ZW50LCBwYXJhbXMpID0+IHtcblx0XHRpZiAoIWRldnRvb2xzU3RhdGUudGltZWxpbmVMYXllcnNTdGF0ZS5yZWNvcmRpbmdTdGF0ZSB8fCAhZGV2dG9vbHNTdGF0ZS50aW1lbGluZUxheWVyc1N0YXRlLmNvbXBvbmVudEV2ZW50RW5hYmxlZCkgcmV0dXJuO1xuXHRcdGNvbnN0IGFwcFJlY29yZCA9IGF3YWl0IGdldEFwcFJlY29yZChhcHApO1xuXHRcdGlmICghYXBwUmVjb3JkKSByZXR1cm47XG5cdFx0Y29uc3QgY29tcG9uZW50SWQgPSBgJHthcHBSZWNvcmQuaWR9OiR7aW5zdGFuY2UudWlkfWA7XG5cdFx0Y29uc3QgY29tcG9uZW50TmFtZSA9IGdldEluc3RhbmNlTmFtZShpbnN0YW5jZSkgfHwgXCJVbmtub3duIENvbXBvbmVudFwiO1xuXHRcdGFwaS5hZGRUaW1lbGluZUV2ZW50KHtcblx0XHRcdGxheWVySWQ6IENPTVBPTkVOVF9FVkVOVF9MQVlFUl9JRCxcblx0XHRcdGV2ZW50OiB7XG5cdFx0XHRcdHRpbWU6IERhdGUubm93KCksXG5cdFx0XHRcdGRhdGE6IHtcblx0XHRcdFx0XHRjb21wb25lbnQ6IHsgX2N1c3RvbToge1xuXHRcdFx0XHRcdFx0dHlwZTogXCJjb21wb25lbnQtZGVmaW5pdGlvblwiLFxuXHRcdFx0XHRcdFx0ZGlzcGxheTogY29tcG9uZW50TmFtZVxuXHRcdFx0XHRcdH0gfSxcblx0XHRcdFx0XHRldmVudCxcblx0XHRcdFx0XHRwYXJhbXNcblx0XHRcdFx0fSxcblx0XHRcdFx0dGl0bGU6IGV2ZW50LFxuXHRcdFx0XHRzdWJ0aXRsZTogYGJ5ICR7Y29tcG9uZW50TmFtZX1gLFxuXHRcdFx0XHRtZXRhOiB7IGNvbXBvbmVudElkIH1cblx0XHRcdH1cblx0XHR9KTtcblx0fSk7XG5cdGFwaS5hZGRUaW1lbGluZUxheWVyKHtcblx0XHRpZDogXCJwZXJmb3JtYW5jZVwiLFxuXHRcdGxhYmVsOiBQRVJGT1JNQU5DRV9FVkVOVF9MQVlFUl9JRCxcblx0XHRjb2xvcjogNDMwNzA1MFxuXHR9KTtcblx0aG9vay5vbi5wZXJmU3RhcnQoKGFwcCwgdWlkLCB2bSwgdHlwZSwgdGltZSkgPT4ge1xuXHRcdGlmICghZGV2dG9vbHNTdGF0ZS50aW1lbGluZUxheWVyc1N0YXRlLnJlY29yZGluZ1N0YXRlIHx8ICFkZXZ0b29sc1N0YXRlLnRpbWVsaW5lTGF5ZXJzU3RhdGUucGVyZm9ybWFuY2VFdmVudEVuYWJsZWQpIHJldHVybjtcblx0XHRwZXJmb3JtYW5jZU1hcmtTdGFydChhcGksIGFwcCwgdWlkLCB2bSwgdHlwZSwgdGltZSk7XG5cdH0pO1xuXHRob29rLm9uLnBlcmZFbmQoKGFwcCwgdWlkLCB2bSwgdHlwZSwgdGltZSkgPT4ge1xuXHRcdGlmICghZGV2dG9vbHNTdGF0ZS50aW1lbGluZUxheWVyc1N0YXRlLnJlY29yZGluZ1N0YXRlIHx8ICFkZXZ0b29sc1N0YXRlLnRpbWVsaW5lTGF5ZXJzU3RhdGUucGVyZm9ybWFuY2VFdmVudEVuYWJsZWQpIHJldHVybjtcblx0XHRwZXJmb3JtYW5jZU1hcmtFbmQoYXBpLCBhcHAsIHVpZCwgdm0sIHR5cGUsIHRpbWUpO1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3ZtL2luZGV4LnRzXG5jb25zdCBNQVhfJFZNID0gMTA7XG5jb25zdCAkdm1RdWV1ZSA9IFtdO1xuZnVuY3Rpb24gZXhwb3NlSW5zdGFuY2VUb1dpbmRvdyhjb21wb25lbnRJbnN0YW5jZSkge1xuXHRpZiAodHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuO1xuXHRjb25zdCB3aW4gPSB3aW5kb3c7XG5cdGlmICghY29tcG9uZW50SW5zdGFuY2UpIHJldHVybjtcblx0d2luLiR2bSA9IGNvbXBvbmVudEluc3RhbmNlO1xuXHRpZiAoJHZtUXVldWVbMF0gIT09IGNvbXBvbmVudEluc3RhbmNlKSB7XG5cdFx0aWYgKCR2bVF1ZXVlLmxlbmd0aCA+PSBNQVhfJFZNKSAkdm1RdWV1ZS5wb3AoKTtcblx0XHRmb3IgKGxldCBpID0gJHZtUXVldWUubGVuZ3RoOyBpID4gMDsgaS0tKSB3aW5bYCR2bSR7aX1gXSA9ICR2bVF1ZXVlW2ldID0gJHZtUXVldWVbaSAtIDFdO1xuXHRcdHdpbi4kdm0wID0gJHZtUXVldWVbMF0gPSBjb21wb25lbnRJbnN0YW5jZTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvcGx1Z2luL2NvbXBvbmVudHMudHNcbmNvbnN0IElOU1BFQ1RPUl9JRCA9IFwiY29tcG9uZW50c1wiO1xuZnVuY3Rpb24gY3JlYXRlQ29tcG9uZW50c0RldlRvb2xzUGx1Z2luKGFwcCkge1xuXHRjb25zdCBkZXNjcmlwdG9yID0ge1xuXHRcdGlkOiBJTlNQRUNUT1JfSUQsXG5cdFx0bGFiZWw6IFwiQ29tcG9uZW50c1wiLFxuXHRcdGFwcFxuXHR9O1xuXHRjb25zdCBzZXR1cEZuID0gKGFwaSkgPT4ge1xuXHRcdGFwaS5hZGRJbnNwZWN0b3Ioe1xuXHRcdFx0aWQ6IElOU1BFQ1RPUl9JRCxcblx0XHRcdGxhYmVsOiBcIkNvbXBvbmVudHNcIixcblx0XHRcdHRyZWVGaWx0ZXJQbGFjZWhvbGRlcjogXCJTZWFyY2ggY29tcG9uZW50c1wiXG5cdFx0fSk7XG5cdFx0c2V0dXBCdWlsdGluVGltZWxpbmVMYXllcnMoYXBpKTtcblx0XHRhcGkub24uZ2V0SW5zcGVjdG9yVHJlZShhc3luYyAocGF5bG9hZCkgPT4ge1xuXHRcdFx0aWYgKHBheWxvYWQuYXBwID09PSBhcHAgJiYgcGF5bG9hZC5pbnNwZWN0b3JJZCA9PT0gSU5TUEVDVE9SX0lEKSB7XG5cdFx0XHRcdGNvbnN0IGluc3RhbmNlID0gZ2V0Q29tcG9uZW50SW5zdGFuY2UoYWN0aXZlQXBwUmVjb3JkLnZhbHVlLCBwYXlsb2FkLmluc3RhbmNlSWQpO1xuXHRcdFx0XHRpZiAoaW5zdGFuY2UpIHBheWxvYWQucm9vdE5vZGVzID0gYXdhaXQgbmV3IENvbXBvbmVudFdhbGtlcih7XG5cdFx0XHRcdFx0ZmlsdGVyVGV4dDogcGF5bG9hZC5maWx0ZXIsXG5cdFx0XHRcdFx0bWF4RGVwdGg6IDEwMCxcblx0XHRcdFx0XHRyZWN1cnNpdmVseTogZmFsc2UsXG5cdFx0XHRcdFx0YXBpXG5cdFx0XHRcdH0pLmdldENvbXBvbmVudFRyZWUoaW5zdGFuY2UpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdGFwaS5vbi5nZXRJbnNwZWN0b3JTdGF0ZShhc3luYyAocGF5bG9hZCkgPT4ge1xuXHRcdFx0aWYgKHBheWxvYWQuYXBwID09PSBhcHAgJiYgcGF5bG9hZC5pbnNwZWN0b3JJZCA9PT0gSU5TUEVDVE9SX0lEKSB7XG5cdFx0XHRcdGNvbnN0IHJlc3VsdCA9IGdldEluc3RhbmNlU3RhdGUoeyBpbnN0YW5jZUlkOiBwYXlsb2FkLm5vZGVJZCB9KTtcblx0XHRcdFx0Y29uc3QgY29tcG9uZW50SW5zdGFuY2UgPSByZXN1bHQuaW5zdGFuY2U7XG5cdFx0XHRcdGNvbnN0IF9wYXlsb2FkID0ge1xuXHRcdFx0XHRcdGNvbXBvbmVudEluc3RhbmNlLFxuXHRcdFx0XHRcdGFwcDogcmVzdWx0Lmluc3RhbmNlPy5hcHBDb250ZXh0LmFwcCxcblx0XHRcdFx0XHRpbnN0YW5jZURhdGE6IHJlc3VsdFxuXHRcdFx0XHR9O1xuXHRcdFx0XHRkZXZ0b29sc0NvbnRleHQuaG9va3MuY2FsbEhvb2tXaXRoKChjYWxsYmFja3MpID0+IHtcblx0XHRcdFx0XHRjYWxsYmFja3MuZm9yRWFjaCgoY2IpID0+IGNiKF9wYXlsb2FkKSk7XG5cdFx0XHRcdH0sIERldlRvb2xzVjZQbHVnaW5BUElIb29rS2V5cy5JTlNQRUNUX0NPTVBPTkVOVCk7XG5cdFx0XHRcdHBheWxvYWQuc3RhdGUgPSByZXN1bHQ7XG5cdFx0XHRcdGV4cG9zZUluc3RhbmNlVG9XaW5kb3coY29tcG9uZW50SW5zdGFuY2UpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdGFwaS5vbi5lZGl0SW5zcGVjdG9yU3RhdGUoYXN5bmMgKHBheWxvYWQpID0+IHtcblx0XHRcdGlmIChwYXlsb2FkLmFwcCA9PT0gYXBwICYmIHBheWxvYWQuaW5zcGVjdG9ySWQgPT09IElOU1BFQ1RPUl9JRCkge1xuXHRcdFx0XHRlZGl0U3RhdGUocGF5bG9hZCk7XG5cdFx0XHRcdGF3YWl0IGFwaS5zZW5kSW5zcGVjdG9yU3RhdGUoXCJjb21wb25lbnRzXCIpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdGNvbnN0IGRlYm91bmNlU2VuZEluc3BlY3RvclRyZWUgPSBkZWJvdW5jZSgoKSA9PiB7XG5cdFx0XHRhcGkuc2VuZEluc3BlY3RvclRyZWUoSU5TUEVDVE9SX0lEKTtcblx0XHR9LCAxMjApO1xuXHRcdGNvbnN0IGRlYm91bmNlU2VuZEluc3BlY3RvclN0YXRlID0gZGVib3VuY2UoKCkgPT4ge1xuXHRcdFx0YXBpLnNlbmRJbnNwZWN0b3JTdGF0ZShJTlNQRUNUT1JfSUQpO1xuXHRcdH0sIDEyMCk7XG5cdFx0aG9vay5vbi5jb21wb25lbnRBZGRlZChhc3luYyAoYXBwLCB1aWQsIHBhcmVudFVpZCwgY29tcG9uZW50KSA9PiB7XG5cdFx0XHRpZiAoZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkKSByZXR1cm47XG5cdFx0XHRpZiAoYXBwPy5faW5zdGFuY2U/LnR5cGU/LmRldnRvb2xzPy5oaWRlKSByZXR1cm47XG5cdFx0XHRpZiAoIWFwcCB8fCB0eXBlb2YgdWlkICE9PSBcIm51bWJlclwiICYmICF1aWQgfHwgIWNvbXBvbmVudCkgcmV0dXJuO1xuXHRcdFx0Y29uc3QgaWQgPSBhd2FpdCBnZXRDb21wb25lbnRJZCh7XG5cdFx0XHRcdGFwcCxcblx0XHRcdFx0dWlkLFxuXHRcdFx0XHRpbnN0YW5jZTogY29tcG9uZW50XG5cdFx0XHR9KTtcblx0XHRcdGNvbnN0IGFwcFJlY29yZCA9IGF3YWl0IGdldEFwcFJlY29yZChhcHApO1xuXHRcdFx0aWYgKGNvbXBvbmVudCkge1xuXHRcdFx0XHRpZiAoY29tcG9uZW50Ll9fVlVFX0RFVlRPT0xTX05FWFRfVUlEX18gPT0gbnVsbCkgY29tcG9uZW50Ll9fVlVFX0RFVlRPT0xTX05FWFRfVUlEX18gPSBpZDtcblx0XHRcdFx0aWYgKCFhcHBSZWNvcmQ/Lmluc3RhbmNlTWFwLmhhcyhpZCkpIHtcblx0XHRcdFx0XHRhcHBSZWNvcmQ/Lmluc3RhbmNlTWFwLnNldChpZCwgY29tcG9uZW50KTtcblx0XHRcdFx0XHRpZiAoYWN0aXZlQXBwUmVjb3JkLnZhbHVlLmlkID09PSBhcHBSZWNvcmQ/LmlkKSBhY3RpdmVBcHBSZWNvcmQudmFsdWUuaW5zdGFuY2VNYXAgPSBhcHBSZWNvcmQuaW5zdGFuY2VNYXA7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGlmICghYXBwUmVjb3JkKSByZXR1cm47XG5cdFx0XHRkZWJvdW5jZVNlbmRJbnNwZWN0b3JUcmVlKCk7XG5cdFx0fSk7XG5cdFx0aG9vay5vbi5jb21wb25lbnRVcGRhdGVkKGFzeW5jIChhcHAsIHVpZCwgcGFyZW50VWlkLCBjb21wb25lbnQpID0+IHtcblx0XHRcdGlmIChkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQpIHJldHVybjtcblx0XHRcdGlmIChhcHA/Ll9pbnN0YW5jZT8udHlwZT8uZGV2dG9vbHM/LmhpZGUpIHJldHVybjtcblx0XHRcdGlmICghYXBwIHx8IHR5cGVvZiB1aWQgIT09IFwibnVtYmVyXCIgJiYgIXVpZCB8fCAhY29tcG9uZW50KSByZXR1cm47XG5cdFx0XHRjb25zdCBpZCA9IGF3YWl0IGdldENvbXBvbmVudElkKHtcblx0XHRcdFx0YXBwLFxuXHRcdFx0XHR1aWQsXG5cdFx0XHRcdGluc3RhbmNlOiBjb21wb25lbnRcblx0XHRcdH0pO1xuXHRcdFx0Y29uc3QgYXBwUmVjb3JkID0gYXdhaXQgZ2V0QXBwUmVjb3JkKGFwcCk7XG5cdFx0XHRpZiAoY29tcG9uZW50KSB7XG5cdFx0XHRcdGlmIChjb21wb25lbnQuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXyA9PSBudWxsKSBjb21wb25lbnQuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXyA9IGlkO1xuXHRcdFx0XHRpZiAoIWFwcFJlY29yZD8uaW5zdGFuY2VNYXAuaGFzKGlkKSkge1xuXHRcdFx0XHRcdGFwcFJlY29yZD8uaW5zdGFuY2VNYXAuc2V0KGlkLCBjb21wb25lbnQpO1xuXHRcdFx0XHRcdGlmIChhY3RpdmVBcHBSZWNvcmQudmFsdWUuaWQgPT09IGFwcFJlY29yZD8uaWQpIGFjdGl2ZUFwcFJlY29yZC52YWx1ZS5pbnN0YW5jZU1hcCA9IGFwcFJlY29yZC5pbnN0YW5jZU1hcDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKCFhcHBSZWNvcmQpIHJldHVybjtcblx0XHRcdGRlYm91bmNlU2VuZEluc3BlY3RvclRyZWUoKTtcblx0XHRcdGRlYm91bmNlU2VuZEluc3BlY3RvclN0YXRlKCk7XG5cdFx0fSk7XG5cdFx0aG9vay5vbi5jb21wb25lbnRSZW1vdmVkKGFzeW5jIChhcHAsIHVpZCwgcGFyZW50VWlkLCBjb21wb25lbnQpID0+IHtcblx0XHRcdGlmIChkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQpIHJldHVybjtcblx0XHRcdGlmIChhcHA/Ll9pbnN0YW5jZT8udHlwZT8uZGV2dG9vbHM/LmhpZGUpIHJldHVybjtcblx0XHRcdGlmICghYXBwIHx8IHR5cGVvZiB1aWQgIT09IFwibnVtYmVyXCIgJiYgIXVpZCB8fCAhY29tcG9uZW50KSByZXR1cm47XG5cdFx0XHRjb25zdCBhcHBSZWNvcmQgPSBhd2FpdCBnZXRBcHBSZWNvcmQoYXBwKTtcblx0XHRcdGlmICghYXBwUmVjb3JkKSByZXR1cm47XG5cdFx0XHRjb25zdCBpZCA9IGF3YWl0IGdldENvbXBvbmVudElkKHtcblx0XHRcdFx0YXBwLFxuXHRcdFx0XHR1aWQsXG5cdFx0XHRcdGluc3RhbmNlOiBjb21wb25lbnRcblx0XHRcdH0pO1xuXHRcdFx0YXBwUmVjb3JkPy5pbnN0YW5jZU1hcC5kZWxldGUoaWQpO1xuXHRcdFx0aWYgKGFjdGl2ZUFwcFJlY29yZC52YWx1ZS5pZCA9PT0gYXBwUmVjb3JkPy5pZCkgYWN0aXZlQXBwUmVjb3JkLnZhbHVlLmluc3RhbmNlTWFwID0gYXBwUmVjb3JkLmluc3RhbmNlTWFwO1xuXHRcdFx0ZGVib3VuY2VTZW5kSW5zcGVjdG9yVHJlZSgpO1xuXHRcdH0pO1xuXHR9O1xuXHRyZXR1cm4gW2Rlc2NyaXB0b3IsIHNldHVwRm5dO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvcGx1Z2luL2luZGV4LnRzXG50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX19SRUdJU1RFUkVEX1BMVUdJTl9BUFBTX18gPz89IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5mdW5jdGlvbiBzZXR1cERldlRvb2xzUGx1Z2luKHBsdWdpbkRlc2NyaXB0b3IsIHNldHVwRm4pIHtcblx0cmV0dXJuIGhvb2suc2V0dXBEZXZUb29sc1BsdWdpbihwbHVnaW5EZXNjcmlwdG9yLCBzZXR1cEZuKTtcbn1cbmZ1bmN0aW9uIGNhbGxEZXZUb29sc1BsdWdpblNldHVwRm4ocGx1Z2luLCBhcHApIHtcblx0Y29uc3QgW3BsdWdpbkRlc2NyaXB0b3IsIHNldHVwRm5dID0gcGx1Z2luO1xuXHRpZiAocGx1Z2luRGVzY3JpcHRvci5hcHAgIT09IGFwcCkgcmV0dXJuO1xuXHRjb25zdCBhcGkgPSBuZXcgRGV2VG9vbHNQbHVnaW5BUEkoe1xuXHRcdHBsdWdpbjoge1xuXHRcdFx0c2V0dXBGbixcblx0XHRcdGRlc2NyaXB0b3I6IHBsdWdpbkRlc2NyaXB0b3Jcblx0XHR9LFxuXHRcdGN0eDogZGV2dG9vbHNDb250ZXh0XG5cdH0pO1xuXHRpZiAocGx1Z2luRGVzY3JpcHRvci5wYWNrYWdlTmFtZSA9PT0gXCJ2dWV4XCIpIGFwaS5vbi5lZGl0SW5zcGVjdG9yU3RhdGUoKHBheWxvYWQpID0+IHtcblx0XHRhcGkuc2VuZEluc3BlY3RvclN0YXRlKHBheWxvYWQuaW5zcGVjdG9ySWQpO1xuXHR9KTtcblx0c2V0dXBGbihhcGkpO1xufVxuZnVuY3Rpb24gcmVtb3ZlUmVnaXN0ZXJlZFBsdWdpbkFwcChhcHApIHtcblx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9fUkVHSVNURVJFRF9QTFVHSU5fQVBQU19fLmRlbGV0ZShhcHApO1xufVxuZnVuY3Rpb24gcmVnaXN0ZXJEZXZUb29sc1BsdWdpbihhcHAsIG9wdGlvbnMpIHtcblx0aWYgKHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfX1JFR0lTVEVSRURfUExVR0lOX0FQUFNfXy5oYXMoYXBwKSkgcmV0dXJuO1xuXHRpZiAoZGV2dG9vbHNTdGF0ZS5oaWdoUGVyZk1vZGVFbmFibGVkICYmICFvcHRpb25zPy5pbnNwZWN0aW5nQ29tcG9uZW50KSByZXR1cm47XG5cdHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfX1JFR0lTVEVSRURfUExVR0lOX0FQUFNfXy5hZGQoYXBwKTtcblx0ZGV2dG9vbHNQbHVnaW5CdWZmZXIuZm9yRWFjaCgocGx1Z2luKSA9PiB7XG5cdFx0Y2FsbERldlRvb2xzUGx1Z2luU2V0dXBGbihwbHVnaW4sIGFwcCk7XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2N0eC9yb3V0ZXIudHNcbmNvbnN0IFJPVVRFUl9LRVkgPSBcIl9fVlVFX0RFVlRPT0xTX1JPVVRFUl9fXCI7XG5jb25zdCBST1VURVJfSU5GT19LRVkgPSBcIl9fVlVFX0RFVlRPT0xTX1JPVVRFUl9JTkZPX19cIjtcbnRhcmdldFtST1VURVJfSU5GT19LRVldID8/PSB7XG5cdGN1cnJlbnRSb3V0ZTogbnVsbCxcblx0cm91dGVzOiBbXVxufTtcbnRhcmdldFtST1VURVJfS0VZXSA/Pz0ge307XG5jb25zdCBkZXZ0b29sc1JvdXRlckluZm8gPSBuZXcgUHJveHkodGFyZ2V0W1JPVVRFUl9JTkZPX0tFWV0sIHsgZ2V0KHRhcmdldCQxLCBwcm9wZXJ0eSkge1xuXHRyZXR1cm4gdGFyZ2V0W1JPVVRFUl9JTkZPX0tFWV1bcHJvcGVydHldO1xufSB9KTtcbmNvbnN0IGRldnRvb2xzUm91dGVyID0gbmV3IFByb3h5KHRhcmdldFtST1VURVJfS0VZXSwgeyBnZXQodGFyZ2V0JDIsIHByb3BlcnR5KSB7XG5cdGlmIChwcm9wZXJ0eSA9PT0gXCJ2YWx1ZVwiKSByZXR1cm4gdGFyZ2V0W1JPVVRFUl9LRVldO1xufSB9KTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3JvdXRlci9pbmRleC50c1xuZnVuY3Rpb24gZ2V0Um91dGVzKHJvdXRlcikge1xuXHRjb25zdCByb3V0ZXNNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRyZXR1cm4gKHJvdXRlcj8uZ2V0Um91dGVzKCkgfHwgW10pLmZpbHRlcigoaSkgPT4gIXJvdXRlc01hcC5oYXMoaS5wYXRoKSAmJiByb3V0ZXNNYXAuc2V0KGkucGF0aCwgMSkpO1xufVxuZnVuY3Rpb24gZmlsdGVyUm91dGVzKHJvdXRlcykge1xuXHRyZXR1cm4gcm91dGVzLm1hcCgoaXRlbSkgPT4ge1xuXHRcdGxldCB7IHBhdGgsIG5hbWUsIGNoaWxkcmVuLCBtZXRhIH0gPSBpdGVtO1xuXHRcdGlmIChjaGlsZHJlbj8ubGVuZ3RoKSBjaGlsZHJlbiA9IGZpbHRlclJvdXRlcyhjaGlsZHJlbik7XG5cdFx0cmV0dXJuIHtcblx0XHRcdHBhdGgsXG5cdFx0XHRuYW1lLFxuXHRcdFx0Y2hpbGRyZW4sXG5cdFx0XHRtZXRhXG5cdFx0fTtcblx0fSk7XG59XG5mdW5jdGlvbiBmaWx0ZXJDdXJyZW50Um91dGUocm91dGUpIHtcblx0aWYgKHJvdXRlKSB7XG5cdFx0Y29uc3QgeyBmdWxsUGF0aCwgaGFzaCwgaHJlZiwgcGF0aCwgbmFtZSwgbWF0Y2hlZCwgcGFyYW1zLCBxdWVyeSB9ID0gcm91dGU7XG5cdFx0cmV0dXJuIHtcblx0XHRcdGZ1bGxQYXRoLFxuXHRcdFx0aGFzaCxcblx0XHRcdGhyZWYsXG5cdFx0XHRwYXRoLFxuXHRcdFx0bmFtZSxcblx0XHRcdHBhcmFtcyxcblx0XHRcdHF1ZXJ5LFxuXHRcdFx0bWF0Y2hlZDogZmlsdGVyUm91dGVzKG1hdGNoZWQpXG5cdFx0fTtcblx0fVxuXHRyZXR1cm4gcm91dGU7XG59XG5mdW5jdGlvbiBub3JtYWxpemVSb3V0ZXJJbmZvKGFwcFJlY29yZCwgYWN0aXZlQXBwUmVjb3JkKSB7XG5cdGZ1bmN0aW9uIGluaXQoKSB7XG5cdFx0Y29uc3Qgcm91dGVyID0gYXBwUmVjb3JkLmFwcD8uY29uZmlnLmdsb2JhbFByb3BlcnRpZXMuJHJvdXRlcjtcblx0XHRjb25zdCBjdXJyZW50Um91dGUgPSBmaWx0ZXJDdXJyZW50Um91dGUocm91dGVyPy5jdXJyZW50Um91dGUudmFsdWUpO1xuXHRcdGNvbnN0IHJvdXRlcyA9IGZpbHRlclJvdXRlcyhnZXRSb3V0ZXMocm91dGVyKSk7XG5cdFx0Y29uc3QgYyA9IGNvbnNvbGUud2Fybjtcblx0XHRjb25zb2xlLndhcm4gPSAoKSA9PiB7fTtcblx0XHR0YXJnZXRbUk9VVEVSX0lORk9fS0VZXSA9IHtcblx0XHRcdGN1cnJlbnRSb3V0ZTogY3VycmVudFJvdXRlID8gZGVlcENsb25lKGN1cnJlbnRSb3V0ZSkgOiB7fSxcblx0XHRcdHJvdXRlczogZGVlcENsb25lKHJvdXRlcylcblx0XHR9O1xuXHRcdHRhcmdldFtST1VURVJfS0VZXSA9IHJvdXRlcjtcblx0XHRjb25zb2xlLndhcm4gPSBjO1xuXHR9XG5cdGluaXQoKTtcblx0aG9vay5vbi5jb21wb25lbnRVcGRhdGVkKGRlYm91bmNlKCgpID0+IHtcblx0XHRpZiAoYWN0aXZlQXBwUmVjb3JkLnZhbHVlPy5hcHAgIT09IGFwcFJlY29yZC5hcHApIHJldHVybjtcblx0XHRpbml0KCk7XG5cdFx0aWYgKGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCkgcmV0dXJuO1xuXHRcdGRldnRvb2xzQ29udGV4dC5ob29rcy5jYWxsSG9vayhEZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzLlJPVVRFUl9JTkZPX1VQREFURUQsIHsgc3RhdGU6IHRhcmdldFtST1VURVJfSU5GT19LRVldIH0pO1xuXHR9LCAyMDApKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jdHgvYXBpLnRzXG5mdW5jdGlvbiBjcmVhdGVEZXZUb29sc0FwaShob29rcykge1xuXHRyZXR1cm4ge1xuXHRcdGFzeW5jIGdldEluc3BlY3RvclRyZWUocGF5bG9hZCkge1xuXHRcdFx0Y29uc3QgX3BheWxvYWQgPSB7XG5cdFx0XHRcdC4uLnBheWxvYWQsXG5cdFx0XHRcdGFwcDogYWN0aXZlQXBwUmVjb3JkLnZhbHVlLmFwcCxcblx0XHRcdFx0cm9vdE5vZGVzOiBbXVxuXHRcdFx0fTtcblx0XHRcdGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0XHRcdGhvb2tzLmNhbGxIb29rV2l0aChhc3luYyAoY2FsbGJhY2tzKSA9PiB7XG5cdFx0XHRcdFx0YXdhaXQgUHJvbWlzZS5hbGwoY2FsbGJhY2tzLm1hcCgoY2IpID0+IGNiKF9wYXlsb2FkKSkpO1xuXHRcdFx0XHRcdHJlc29sdmUoKTtcblx0XHRcdFx0fSwgRGV2VG9vbHNWNlBsdWdpbkFQSUhvb2tLZXlzLkdFVF9JTlNQRUNUT1JfVFJFRSk7XG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiBfcGF5bG9hZC5yb290Tm9kZXM7XG5cdFx0fSxcblx0XHRhc3luYyBnZXRJbnNwZWN0b3JTdGF0ZShwYXlsb2FkKSB7XG5cdFx0XHRjb25zdCBfcGF5bG9hZCA9IHtcblx0XHRcdFx0Li4ucGF5bG9hZCxcblx0XHRcdFx0YXBwOiBhY3RpdmVBcHBSZWNvcmQudmFsdWUuYXBwLFxuXHRcdFx0XHRzdGF0ZTogbnVsbFxuXHRcdFx0fTtcblx0XHRcdGNvbnN0IGN0eCA9IHsgY3VycmVudFRhYjogYGN1c3RvbS1pbnNwZWN0b3I6JHtwYXlsb2FkLmluc3BlY3RvcklkfWAgfTtcblx0XHRcdGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0XHRcdGhvb2tzLmNhbGxIb29rV2l0aChhc3luYyAoY2FsbGJhY2tzKSA9PiB7XG5cdFx0XHRcdFx0YXdhaXQgUHJvbWlzZS5hbGwoY2FsbGJhY2tzLm1hcCgoY2IpID0+IGNiKF9wYXlsb2FkLCBjdHgpKSk7XG5cdFx0XHRcdFx0cmVzb2x2ZSgpO1xuXHRcdFx0XHR9LCBEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuR0VUX0lOU1BFQ1RPUl9TVEFURSk7XG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiBfcGF5bG9hZC5zdGF0ZTtcblx0XHR9LFxuXHRcdGVkaXRJbnNwZWN0b3JTdGF0ZShwYXlsb2FkKSB7XG5cdFx0XHRjb25zdCBzdGF0ZUVkaXRvciA9IG5ldyBTdGF0ZUVkaXRvcigpO1xuXHRcdFx0Y29uc3QgX3BheWxvYWQgPSB7XG5cdFx0XHRcdC4uLnBheWxvYWQsXG5cdFx0XHRcdGFwcDogYWN0aXZlQXBwUmVjb3JkLnZhbHVlLmFwcCxcblx0XHRcdFx0c2V0OiAob2JqLCBwYXRoID0gcGF5bG9hZC5wYXRoLCB2YWx1ZSA9IHBheWxvYWQuc3RhdGUudmFsdWUsIGNiKSA9PiB7XG5cdFx0XHRcdFx0c3RhdGVFZGl0b3Iuc2V0KG9iaiwgcGF0aCwgdmFsdWUsIGNiIHx8IHN0YXRlRWRpdG9yLmNyZWF0ZURlZmF1bHRTZXRDYWxsYmFjayhwYXlsb2FkLnN0YXRlKSk7XG5cdFx0XHRcdH1cblx0XHRcdH07XG5cdFx0XHRob29rcy5jYWxsSG9va1dpdGgoKGNhbGxiYWNrcykgPT4ge1xuXHRcdFx0XHRjYWxsYmFja3MuZm9yRWFjaCgoY2IpID0+IGNiKF9wYXlsb2FkKSk7XG5cdFx0XHR9LCBEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMuRURJVF9JTlNQRUNUT1JfU1RBVEUpO1xuXHRcdH0sXG5cdFx0c2VuZEluc3BlY3RvclN0YXRlKGluc3BlY3RvcklkKSB7XG5cdFx0XHRjb25zdCBpbnNwZWN0b3IgPSBnZXRJbnNwZWN0b3IoaW5zcGVjdG9ySWQpO1xuXHRcdFx0aG9va3MuY2FsbEhvb2soRGV2VG9vbHNDb250ZXh0SG9va0tleXMuU0VORF9JTlNQRUNUT1JfU1RBVEUsIHtcblx0XHRcdFx0aW5zcGVjdG9ySWQsXG5cdFx0XHRcdHBsdWdpbjoge1xuXHRcdFx0XHRcdGRlc2NyaXB0b3I6IGluc3BlY3Rvci5kZXNjcmlwdG9yLFxuXHRcdFx0XHRcdHNldHVwRm46ICgpID0+ICh7fSlcblx0XHRcdFx0fVxuXHRcdFx0fSk7XG5cdFx0fSxcblx0XHRpbnNwZWN0Q29tcG9uZW50SW5zcGVjdG9yKCkge1xuXHRcdFx0cmV0dXJuIGluc3BlY3RDb21wb25lbnRIaWdoTGlnaHRlcigpO1xuXHRcdH0sXG5cdFx0Y2FuY2VsSW5zcGVjdENvbXBvbmVudEluc3BlY3RvcigpIHtcblx0XHRcdHJldHVybiBjYW5jZWxJbnNwZWN0Q29tcG9uZW50SGlnaExpZ2h0ZXIoKTtcblx0XHR9LFxuXHRcdGdldENvbXBvbmVudFJlbmRlckNvZGUoaWQpIHtcblx0XHRcdGNvbnN0IGluc3RhbmNlID0gZ2V0Q29tcG9uZW50SW5zdGFuY2UoYWN0aXZlQXBwUmVjb3JkLnZhbHVlLCBpZCk7XG5cdFx0XHRpZiAoaW5zdGFuY2UpIHJldHVybiAhKHR5cGVvZiBpbnN0YW5jZT8udHlwZSA9PT0gXCJmdW5jdGlvblwiKSA/IGluc3RhbmNlLnJlbmRlci50b1N0cmluZygpIDogaW5zdGFuY2UudHlwZS50b1N0cmluZygpO1xuXHRcdH0sXG5cdFx0c2Nyb2xsVG9Db21wb25lbnQoaWQpIHtcblx0XHRcdHJldHVybiBzY3JvbGxUb0NvbXBvbmVudCh7IGlkIH0pO1xuXHRcdH0sXG5cdFx0b3BlbkluRWRpdG9yLFxuXHRcdGdldFZ1ZUluc3BlY3RvcjogZ2V0Q29tcG9uZW50SW5zcGVjdG9yLFxuXHRcdHRvZ2dsZUFwcChpZCwgb3B0aW9ucykge1xuXHRcdFx0Y29uc3QgYXBwUmVjb3JkID0gZGV2dG9vbHNBcHBSZWNvcmRzLnZhbHVlLmZpbmQoKHJlY29yZCkgPT4gcmVjb3JkLmlkID09PSBpZCk7XG5cdFx0XHRpZiAoYXBwUmVjb3JkKSB7XG5cdFx0XHRcdHNldEFjdGl2ZUFwcFJlY29yZElkKGlkKTtcblx0XHRcdFx0c2V0QWN0aXZlQXBwUmVjb3JkKGFwcFJlY29yZCk7XG5cdFx0XHRcdG5vcm1hbGl6ZVJvdXRlckluZm8oYXBwUmVjb3JkLCBhY3RpdmVBcHBSZWNvcmQpO1xuXHRcdFx0XHRjYWxsSW5zcGVjdG9yVXBkYXRlZEhvb2soKTtcblx0XHRcdFx0cmVnaXN0ZXJEZXZUb29sc1BsdWdpbihhcHBSZWNvcmQuYXBwLCBvcHRpb25zKTtcblx0XHRcdH1cblx0XHR9LFxuXHRcdGluc3BlY3RET00oaW5zdGFuY2VJZCkge1xuXHRcdFx0Y29uc3QgaW5zdGFuY2UgPSBnZXRDb21wb25lbnRJbnN0YW5jZShhY3RpdmVBcHBSZWNvcmQudmFsdWUsIGluc3RhbmNlSWQpO1xuXHRcdFx0aWYgKGluc3RhbmNlKSB7XG5cdFx0XHRcdGNvbnN0IFtlbF0gPSBnZXRSb290RWxlbWVudHNGcm9tQ29tcG9uZW50SW5zdGFuY2UoaW5zdGFuY2UpO1xuXHRcdFx0XHRpZiAoZWwpIHRhcmdldC5fX1ZVRV9ERVZUT09MU19JTlNQRUNUX0RPTV9UQVJHRVRfXyA9IGVsO1xuXHRcdFx0fVxuXHRcdH0sXG5cdFx0dXBkYXRlUGx1Z2luU2V0dGluZ3MocGx1Z2luSWQsIGtleSwgdmFsdWUpIHtcblx0XHRcdHNldFBsdWdpblNldHRpbmdzKHBsdWdpbklkLCBrZXksIHZhbHVlKTtcblx0XHR9LFxuXHRcdGdldFBsdWdpblNldHRpbmdzKHBsdWdpbklkKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRvcHRpb25zOiBnZXRQbHVnaW5TZXR0aW5nc09wdGlvbnMocGx1Z2luSWQpLFxuXHRcdFx0XHR2YWx1ZXM6IGdldFBsdWdpblNldHRpbmdzKHBsdWdpbklkKVxuXHRcdFx0fTtcblx0XHR9XG5cdH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY3R4L2Vudi50c1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0VOVl9fID8/PSB7IHZpdGVQbHVnaW5EZXRlY3RlZDogZmFsc2UgfTtcbmZ1bmN0aW9uIGdldERldlRvb2xzRW52KCkge1xuXHRyZXR1cm4gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0VOVl9fO1xufVxuZnVuY3Rpb24gc2V0RGV2VG9vbHNFbnYoZW52KSB7XG5cdHRhcmdldC5fX1ZVRV9ERVZUT09MU19FTlZfXyA9IHtcblx0XHQuLi50YXJnZXQuX19WVUVfREVWVE9PTFNfRU5WX18sXG5cdFx0Li4uZW52XG5cdH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY3R4L2luZGV4LnRzXG5jb25zdCBob29rcyA9IGNyZWF0ZURldlRvb2xzQ3R4SG9va3MoKTtcbnRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQ09OVEVYVF9fID8/PSB7XG5cdGhvb2tzLFxuXHRnZXQgc3RhdGUoKSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdC4uLmRldnRvb2xzU3RhdGUsXG5cdFx0XHRhY3RpdmVBcHBSZWNvcmRJZDogYWN0aXZlQXBwUmVjb3JkLmlkLFxuXHRcdFx0YWN0aXZlQXBwUmVjb3JkOiBhY3RpdmVBcHBSZWNvcmQudmFsdWUsXG5cdFx0XHRhcHBSZWNvcmRzOiBkZXZ0b29sc0FwcFJlY29yZHMudmFsdWVcblx0XHR9O1xuXHR9LFxuXHRhcGk6IGNyZWF0ZURldlRvb2xzQXBpKGhvb2tzKVxufTtcbmNvbnN0IGRldnRvb2xzQ29udGV4dCA9IHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfQ09OVEVYVF9fO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3NwZWFraW5ndXJsQDE0LjAuMS9ub2RlX21vZHVsZXMvc3BlYWtpbmd1cmwvbGliL3NwZWFraW5ndXJsLmpzXG52YXIgcmVxdWlyZV9zcGVha2luZ3VybCQxID0gLyogQF9fUFVSRV9fICovIF9fY29tbW9uSlNNaW4oKChleHBvcnRzLCBtb2R1bGUpID0+IHtcblx0KGZ1bmN0aW9uKHJvb3QpIHtcblx0XHRcInVzZSBzdHJpY3RcIjtcblx0XHQvKipcblx0XHQqIGNoYXJNYXBcblx0XHQqIEB0eXBlIHtPYmplY3R9XG5cdFx0Ki9cblx0XHR2YXIgY2hhck1hcCA9IHtcblx0XHRcdFwiw4BcIjogXCJBXCIsXG5cdFx0XHRcIsOBXCI6IFwiQVwiLFxuXHRcdFx0XCLDglwiOiBcIkFcIixcblx0XHRcdFwiw4NcIjogXCJBXCIsXG5cdFx0XHRcIsOEXCI6IFwiQWVcIixcblx0XHRcdFwiw4VcIjogXCJBXCIsXG5cdFx0XHRcIsOGXCI6IFwiQUVcIixcblx0XHRcdFwiw4dcIjogXCJDXCIsXG5cdFx0XHRcIsOIXCI6IFwiRVwiLFxuXHRcdFx0XCLDiVwiOiBcIkVcIixcblx0XHRcdFwiw4pcIjogXCJFXCIsXG5cdFx0XHRcIsOLXCI6IFwiRVwiLFxuXHRcdFx0XCLDjFwiOiBcIklcIixcblx0XHRcdFwiw41cIjogXCJJXCIsXG5cdFx0XHRcIsOOXCI6IFwiSVwiLFxuXHRcdFx0XCLDj1wiOiBcIklcIixcblx0XHRcdFwiw5BcIjogXCJEXCIsXG5cdFx0XHRcIsORXCI6IFwiTlwiLFxuXHRcdFx0XCLDklwiOiBcIk9cIixcblx0XHRcdFwiw5NcIjogXCJPXCIsXG5cdFx0XHRcIsOUXCI6IFwiT1wiLFxuXHRcdFx0XCLDlVwiOiBcIk9cIixcblx0XHRcdFwiw5ZcIjogXCJPZVwiLFxuXHRcdFx0XCLFkFwiOiBcIk9cIixcblx0XHRcdFwiw5hcIjogXCJPXCIsXG5cdFx0XHRcIsOZXCI6IFwiVVwiLFxuXHRcdFx0XCLDmlwiOiBcIlVcIixcblx0XHRcdFwiw5tcIjogXCJVXCIsXG5cdFx0XHRcIsOcXCI6IFwiVWVcIixcblx0XHRcdFwixbBcIjogXCJVXCIsXG5cdFx0XHRcIsOdXCI6IFwiWVwiLFxuXHRcdFx0XCLDnlwiOiBcIlRIXCIsXG5cdFx0XHRcIsOfXCI6IFwic3NcIixcblx0XHRcdFwiw6BcIjogXCJhXCIsXG5cdFx0XHRcIsOhXCI6IFwiYVwiLFxuXHRcdFx0XCLDolwiOiBcImFcIixcblx0XHRcdFwiw6NcIjogXCJhXCIsXG5cdFx0XHRcIsOkXCI6IFwiYWVcIixcblx0XHRcdFwiw6VcIjogXCJhXCIsXG5cdFx0XHRcIsOmXCI6IFwiYWVcIixcblx0XHRcdFwiw6dcIjogXCJjXCIsXG5cdFx0XHRcIsOoXCI6IFwiZVwiLFxuXHRcdFx0XCLDqVwiOiBcImVcIixcblx0XHRcdFwiw6pcIjogXCJlXCIsXG5cdFx0XHRcIsOrXCI6IFwiZVwiLFxuXHRcdFx0XCLDrFwiOiBcImlcIixcblx0XHRcdFwiw61cIjogXCJpXCIsXG5cdFx0XHRcIsOuXCI6IFwiaVwiLFxuXHRcdFx0XCLDr1wiOiBcImlcIixcblx0XHRcdFwiw7BcIjogXCJkXCIsXG5cdFx0XHRcIsOxXCI6IFwiblwiLFxuXHRcdFx0XCLDslwiOiBcIm9cIixcblx0XHRcdFwiw7NcIjogXCJvXCIsXG5cdFx0XHRcIsO0XCI6IFwib1wiLFxuXHRcdFx0XCLDtVwiOiBcIm9cIixcblx0XHRcdFwiw7ZcIjogXCJvZVwiLFxuXHRcdFx0XCLFkVwiOiBcIm9cIixcblx0XHRcdFwiw7hcIjogXCJvXCIsXG5cdFx0XHRcIsO5XCI6IFwidVwiLFxuXHRcdFx0XCLDulwiOiBcInVcIixcblx0XHRcdFwiw7tcIjogXCJ1XCIsXG5cdFx0XHRcIsO8XCI6IFwidWVcIixcblx0XHRcdFwixbFcIjogXCJ1XCIsXG5cdFx0XHRcIsO9XCI6IFwieVwiLFxuXHRcdFx0XCLDvlwiOiBcInRoXCIsXG5cdFx0XHRcIsO/XCI6IFwieVwiLFxuXHRcdFx0XCLhup5cIjogXCJTU1wiLFxuXHRcdFx0XCLYp1wiOiBcImFcIixcblx0XHRcdFwi2KNcIjogXCJhXCIsXG5cdFx0XHRcItilXCI6IFwiaVwiLFxuXHRcdFx0XCLYolwiOiBcImFhXCIsXG5cdFx0XHRcItikXCI6IFwidVwiLFxuXHRcdFx0XCLYplwiOiBcImVcIixcblx0XHRcdFwi2KFcIjogXCJhXCIsXG5cdFx0XHRcItioXCI6IFwiYlwiLFxuXHRcdFx0XCLYqlwiOiBcInRcIixcblx0XHRcdFwi2KtcIjogXCJ0aFwiLFxuXHRcdFx0XCLYrFwiOiBcImpcIixcblx0XHRcdFwi2K1cIjogXCJoXCIsXG5cdFx0XHRcItiuXCI6IFwia2hcIixcblx0XHRcdFwi2K9cIjogXCJkXCIsXG5cdFx0XHRcItiwXCI6IFwidGhcIixcblx0XHRcdFwi2LFcIjogXCJyXCIsXG5cdFx0XHRcItiyXCI6IFwielwiLFxuXHRcdFx0XCLYs1wiOiBcInNcIixcblx0XHRcdFwi2LRcIjogXCJzaFwiLFxuXHRcdFx0XCLYtVwiOiBcInNcIixcblx0XHRcdFwi2LZcIjogXCJkaFwiLFxuXHRcdFx0XCLYt1wiOiBcInRcIixcblx0XHRcdFwi2LhcIjogXCJ6XCIsXG5cdFx0XHRcIti5XCI6IFwiYVwiLFxuXHRcdFx0XCLYulwiOiBcImdoXCIsXG5cdFx0XHRcItmBXCI6IFwiZlwiLFxuXHRcdFx0XCLZglwiOiBcInFcIixcblx0XHRcdFwi2YNcIjogXCJrXCIsXG5cdFx0XHRcItmEXCI6IFwibFwiLFxuXHRcdFx0XCLZhVwiOiBcIm1cIixcblx0XHRcdFwi2YZcIjogXCJuXCIsXG5cdFx0XHRcItmHXCI6IFwiaFwiLFxuXHRcdFx0XCLZiFwiOiBcIndcIixcblx0XHRcdFwi2YpcIjogXCJ5XCIsXG5cdFx0XHRcItmJXCI6IFwiYVwiLFxuXHRcdFx0XCLYqVwiOiBcImhcIixcblx0XHRcdFwi77u7XCI6IFwibGFcIixcblx0XHRcdFwi77u3XCI6IFwibGFhXCIsXG5cdFx0XHRcIu+7uVwiOiBcImxhaVwiLFxuXHRcdFx0XCLvu7VcIjogXCJsYWFcIixcblx0XHRcdFwi2q9cIjogXCJnXCIsXG5cdFx0XHRcItqGXCI6IFwiY2hcIixcblx0XHRcdFwi2b5cIjogXCJwXCIsXG5cdFx0XHRcItqYXCI6IFwiemhcIixcblx0XHRcdFwi2qlcIjogXCJrXCIsXG5cdFx0XHRcItuMXCI6IFwieVwiLFxuXHRcdFx0XCLZjlwiOiBcImFcIixcblx0XHRcdFwi2YtcIjogXCJhblwiLFxuXHRcdFx0XCLZkFwiOiBcImVcIixcblx0XHRcdFwi2Y1cIjogXCJlblwiLFxuXHRcdFx0XCLZj1wiOiBcInVcIixcblx0XHRcdFwi2YxcIjogXCJvblwiLFxuXHRcdFx0XCLZklwiOiBcIlwiLFxuXHRcdFx0XCLZoFwiOiBcIjBcIixcblx0XHRcdFwi2aFcIjogXCIxXCIsXG5cdFx0XHRcItmiXCI6IFwiMlwiLFxuXHRcdFx0XCLZo1wiOiBcIjNcIixcblx0XHRcdFwi2aRcIjogXCI0XCIsXG5cdFx0XHRcItmlXCI6IFwiNVwiLFxuXHRcdFx0XCLZplwiOiBcIjZcIixcblx0XHRcdFwi2adcIjogXCI3XCIsXG5cdFx0XHRcItmoXCI6IFwiOFwiLFxuXHRcdFx0XCLZqVwiOiBcIjlcIixcblx0XHRcdFwi27BcIjogXCIwXCIsXG5cdFx0XHRcItuxXCI6IFwiMVwiLFxuXHRcdFx0XCLbslwiOiBcIjJcIixcblx0XHRcdFwi27NcIjogXCIzXCIsXG5cdFx0XHRcItu0XCI6IFwiNFwiLFxuXHRcdFx0XCLbtVwiOiBcIjVcIixcblx0XHRcdFwi27ZcIjogXCI2XCIsXG5cdFx0XHRcItu3XCI6IFwiN1wiLFxuXHRcdFx0XCLbuFwiOiBcIjhcIixcblx0XHRcdFwi27lcIjogXCI5XCIsXG5cdFx0XHRcIuGAgFwiOiBcImtcIixcblx0XHRcdFwi4YCBXCI6IFwia2hcIixcblx0XHRcdFwi4YCCXCI6IFwiZ1wiLFxuXHRcdFx0XCLhgINcIjogXCJnYVwiLFxuXHRcdFx0XCLhgIRcIjogXCJuZ1wiLFxuXHRcdFx0XCLhgIVcIjogXCJzXCIsXG5cdFx0XHRcIuGAhlwiOiBcInNhXCIsXG5cdFx0XHRcIuGAh1wiOiBcInpcIixcblx0XHRcdFwi4YCF4YC7XCI6IFwiemFcIixcblx0XHRcdFwi4YCKXCI6IFwibnlcIixcblx0XHRcdFwi4YCLXCI6IFwidFwiLFxuXHRcdFx0XCLhgIxcIjogXCJ0YVwiLFxuXHRcdFx0XCLhgI1cIjogXCJkXCIsXG5cdFx0XHRcIuGAjlwiOiBcImRhXCIsXG5cdFx0XHRcIuGAj1wiOiBcIm5hXCIsXG5cdFx0XHRcIuGAkFwiOiBcInRcIixcblx0XHRcdFwi4YCRXCI6IFwidGFcIixcblx0XHRcdFwi4YCSXCI6IFwiZFwiLFxuXHRcdFx0XCLhgJNcIjogXCJkYVwiLFxuXHRcdFx0XCLhgJRcIjogXCJuXCIsXG5cdFx0XHRcIuGAlVwiOiBcInBcIixcblx0XHRcdFwi4YCWXCI6IFwicGFcIixcblx0XHRcdFwi4YCXXCI6IFwiYlwiLFxuXHRcdFx0XCLhgJhcIjogXCJiYVwiLFxuXHRcdFx0XCLhgJlcIjogXCJtXCIsXG5cdFx0XHRcIuGAmlwiOiBcInlcIixcblx0XHRcdFwi4YCbXCI6IFwieWFcIixcblx0XHRcdFwi4YCcXCI6IFwibFwiLFxuXHRcdFx0XCLhgJ1cIjogXCJ3XCIsXG5cdFx0XHRcIuGAnlwiOiBcInRoXCIsXG5cdFx0XHRcIuGAn1wiOiBcImhcIixcblx0XHRcdFwi4YCgXCI6IFwibGFcIixcblx0XHRcdFwi4YChXCI6IFwiYVwiLFxuXHRcdFx0XCLhgLxcIjogXCJ5XCIsXG5cdFx0XHRcIuGAu1wiOiBcInlhXCIsXG5cdFx0XHRcIuGAvVwiOiBcIndcIixcblx0XHRcdFwi4YC84YC9XCI6IFwieXdcIixcblx0XHRcdFwi4YC74YC9XCI6IFwieXdhXCIsXG5cdFx0XHRcIuGAvlwiOiBcImhcIixcblx0XHRcdFwi4YCnXCI6IFwiZVwiLFxuXHRcdFx0XCLhgY9cIjogXCItZVwiLFxuXHRcdFx0XCLhgKNcIjogXCJpXCIsXG5cdFx0XHRcIuGApFwiOiBcIi1pXCIsXG5cdFx0XHRcIuGAiVwiOiBcInVcIixcblx0XHRcdFwi4YCmXCI6IFwiLXVcIixcblx0XHRcdFwi4YCpXCI6IFwiYXdcIixcblx0XHRcdFwi4YCe4YC84YCx4YCsXCI6IFwiYXdcIixcblx0XHRcdFwi4YCqXCI6IFwiYXdcIixcblx0XHRcdFwi4YGAXCI6IFwiMFwiLFxuXHRcdFx0XCLhgYFcIjogXCIxXCIsXG5cdFx0XHRcIuGBglwiOiBcIjJcIixcblx0XHRcdFwi4YGDXCI6IFwiM1wiLFxuXHRcdFx0XCLhgYRcIjogXCI0XCIsXG5cdFx0XHRcIuGBhVwiOiBcIjVcIixcblx0XHRcdFwi4YGGXCI6IFwiNlwiLFxuXHRcdFx0XCLhgYdcIjogXCI3XCIsXG5cdFx0XHRcIuGBiFwiOiBcIjhcIixcblx0XHRcdFwi4YGJXCI6IFwiOVwiLFxuXHRcdFx0XCLhgLlcIjogXCJcIixcblx0XHRcdFwi4YC3XCI6IFwiXCIsXG5cdFx0XHRcIuGAuFwiOiBcIlwiLFxuXHRcdFx0XCLEjVwiOiBcImNcIixcblx0XHRcdFwixI9cIjogXCJkXCIsXG5cdFx0XHRcIsSbXCI6IFwiZVwiLFxuXHRcdFx0XCLFiFwiOiBcIm5cIixcblx0XHRcdFwixZlcIjogXCJyXCIsXG5cdFx0XHRcIsWhXCI6IFwic1wiLFxuXHRcdFx0XCLFpVwiOiBcInRcIixcblx0XHRcdFwixa9cIjogXCJ1XCIsXG5cdFx0XHRcIsW+XCI6IFwielwiLFxuXHRcdFx0XCLEjFwiOiBcIkNcIixcblx0XHRcdFwixI5cIjogXCJEXCIsXG5cdFx0XHRcIsSaXCI6IFwiRVwiLFxuXHRcdFx0XCLFh1wiOiBcIk5cIixcblx0XHRcdFwixZhcIjogXCJSXCIsXG5cdFx0XHRcIsWgXCI6IFwiU1wiLFxuXHRcdFx0XCLFpFwiOiBcIlRcIixcblx0XHRcdFwixa5cIjogXCJVXCIsXG5cdFx0XHRcIsW9XCI6IFwiWlwiLFxuXHRcdFx0XCLegFwiOiBcImhcIixcblx0XHRcdFwi3oFcIjogXCJzaFwiLFxuXHRcdFx0XCLeglwiOiBcIm5cIixcblx0XHRcdFwi3oNcIjogXCJyXCIsXG5cdFx0XHRcIt6EXCI6IFwiYlwiLFxuXHRcdFx0XCLehVwiOiBcImxoXCIsXG5cdFx0XHRcIt6GXCI6IFwia1wiLFxuXHRcdFx0XCLeh1wiOiBcImFcIixcblx0XHRcdFwi3ohcIjogXCJ2XCIsXG5cdFx0XHRcIt6JXCI6IFwibVwiLFxuXHRcdFx0XCLeilwiOiBcImZcIixcblx0XHRcdFwi3otcIjogXCJkaFwiLFxuXHRcdFx0XCLejFwiOiBcInRoXCIsXG5cdFx0XHRcIt6NXCI6IFwibFwiLFxuXHRcdFx0XCLejlwiOiBcImdcIixcblx0XHRcdFwi3o9cIjogXCJnblwiLFxuXHRcdFx0XCLekFwiOiBcInNcIixcblx0XHRcdFwi3pFcIjogXCJkXCIsXG5cdFx0XHRcIt6SXCI6IFwielwiLFxuXHRcdFx0XCLek1wiOiBcInRcIixcblx0XHRcdFwi3pRcIjogXCJ5XCIsXG5cdFx0XHRcIt6VXCI6IFwicFwiLFxuXHRcdFx0XCLellwiOiBcImpcIixcblx0XHRcdFwi3pdcIjogXCJjaFwiLFxuXHRcdFx0XCLemFwiOiBcInR0XCIsXG5cdFx0XHRcIt6ZXCI6IFwiaGhcIixcblx0XHRcdFwi3ppcIjogXCJraFwiLFxuXHRcdFx0XCLem1wiOiBcInRoXCIsXG5cdFx0XHRcIt6cXCI6IFwielwiLFxuXHRcdFx0XCLenVwiOiBcInNoXCIsXG5cdFx0XHRcIt6eXCI6IFwic1wiLFxuXHRcdFx0XCLen1wiOiBcImRcIixcblx0XHRcdFwi3qBcIjogXCJ0XCIsXG5cdFx0XHRcIt6hXCI6IFwielwiLFxuXHRcdFx0XCLeolwiOiBcImFcIixcblx0XHRcdFwi3qNcIjogXCJnaFwiLFxuXHRcdFx0XCLepFwiOiBcInFcIixcblx0XHRcdFwi3qVcIjogXCJ3XCIsXG5cdFx0XHRcIt6mXCI6IFwiYVwiLFxuXHRcdFx0XCLep1wiOiBcImFhXCIsXG5cdFx0XHRcIt6oXCI6IFwiaVwiLFxuXHRcdFx0XCLeqVwiOiBcImVlXCIsXG5cdFx0XHRcIt6qXCI6IFwidVwiLFxuXHRcdFx0XCLeq1wiOiBcIm9vXCIsXG5cdFx0XHRcIt6sXCI6IFwiZVwiLFxuXHRcdFx0XCLerVwiOiBcImV5XCIsXG5cdFx0XHRcIt6uXCI6IFwib1wiLFxuXHRcdFx0XCLer1wiOiBcIm9hXCIsXG5cdFx0XHRcIt6wXCI6IFwiXCIsXG5cdFx0XHRcIuGDkFwiOiBcImFcIixcblx0XHRcdFwi4YORXCI6IFwiYlwiLFxuXHRcdFx0XCLhg5JcIjogXCJnXCIsXG5cdFx0XHRcIuGDk1wiOiBcImRcIixcblx0XHRcdFwi4YOUXCI6IFwiZVwiLFxuXHRcdFx0XCLhg5VcIjogXCJ2XCIsXG5cdFx0XHRcIuGDllwiOiBcInpcIixcblx0XHRcdFwi4YOXXCI6IFwidFwiLFxuXHRcdFx0XCLhg5hcIjogXCJpXCIsXG5cdFx0XHRcIuGDmVwiOiBcImtcIixcblx0XHRcdFwi4YOaXCI6IFwibFwiLFxuXHRcdFx0XCLhg5tcIjogXCJtXCIsXG5cdFx0XHRcIuGDnFwiOiBcIm5cIixcblx0XHRcdFwi4YOdXCI6IFwib1wiLFxuXHRcdFx0XCLhg55cIjogXCJwXCIsXG5cdFx0XHRcIuGDn1wiOiBcInpoXCIsXG5cdFx0XHRcIuGDoFwiOiBcInJcIixcblx0XHRcdFwi4YOhXCI6IFwic1wiLFxuXHRcdFx0XCLhg6JcIjogXCJ0XCIsXG5cdFx0XHRcIuGDo1wiOiBcInVcIixcblx0XHRcdFwi4YOkXCI6IFwicFwiLFxuXHRcdFx0XCLhg6VcIjogXCJrXCIsXG5cdFx0XHRcIuGDplwiOiBcImdoXCIsXG5cdFx0XHRcIuGDp1wiOiBcInFcIixcblx0XHRcdFwi4YOoXCI6IFwic2hcIixcblx0XHRcdFwi4YOpXCI6IFwiY2hcIixcblx0XHRcdFwi4YOqXCI6IFwidHNcIixcblx0XHRcdFwi4YOrXCI6IFwiZHpcIixcblx0XHRcdFwi4YOsXCI6IFwidHNcIixcblx0XHRcdFwi4YOtXCI6IFwiY2hcIixcblx0XHRcdFwi4YOuXCI6IFwia2hcIixcblx0XHRcdFwi4YOvXCI6IFwialwiLFxuXHRcdFx0XCLhg7BcIjogXCJoXCIsXG5cdFx0XHRcIs6xXCI6IFwiYVwiLFxuXHRcdFx0XCLOslwiOiBcInZcIixcblx0XHRcdFwizrNcIjogXCJnXCIsXG5cdFx0XHRcIs60XCI6IFwiZFwiLFxuXHRcdFx0XCLOtVwiOiBcImVcIixcblx0XHRcdFwizrZcIjogXCJ6XCIsXG5cdFx0XHRcIs63XCI6IFwiaVwiLFxuXHRcdFx0XCLOuFwiOiBcInRoXCIsXG5cdFx0XHRcIs65XCI6IFwiaVwiLFxuXHRcdFx0XCLOulwiOiBcImtcIixcblx0XHRcdFwizrtcIjogXCJsXCIsXG5cdFx0XHRcIs68XCI6IFwibVwiLFxuXHRcdFx0XCLOvVwiOiBcIm5cIixcblx0XHRcdFwizr5cIjogXCJrc1wiLFxuXHRcdFx0XCLOv1wiOiBcIm9cIixcblx0XHRcdFwiz4BcIjogXCJwXCIsXG5cdFx0XHRcIs+BXCI6IFwiclwiLFxuXHRcdFx0XCLPg1wiOiBcInNcIixcblx0XHRcdFwiz4RcIjogXCJ0XCIsXG5cdFx0XHRcIs+FXCI6IFwieVwiLFxuXHRcdFx0XCLPhlwiOiBcImZcIixcblx0XHRcdFwiz4dcIjogXCJ4XCIsXG5cdFx0XHRcIs+IXCI6IFwicHNcIixcblx0XHRcdFwiz4lcIjogXCJvXCIsXG5cdFx0XHRcIs6sXCI6IFwiYVwiLFxuXHRcdFx0XCLOrVwiOiBcImVcIixcblx0XHRcdFwizq9cIjogXCJpXCIsXG5cdFx0XHRcIs+MXCI6IFwib1wiLFxuXHRcdFx0XCLPjVwiOiBcInlcIixcblx0XHRcdFwizq5cIjogXCJpXCIsXG5cdFx0XHRcIs+OXCI6IFwib1wiLFxuXHRcdFx0XCLPglwiOiBcInNcIixcblx0XHRcdFwiz4pcIjogXCJpXCIsXG5cdFx0XHRcIs6wXCI6IFwieVwiLFxuXHRcdFx0XCLPi1wiOiBcInlcIixcblx0XHRcdFwizpBcIjogXCJpXCIsXG5cdFx0XHRcIs6RXCI6IFwiQVwiLFxuXHRcdFx0XCLOklwiOiBcIkJcIixcblx0XHRcdFwizpNcIjogXCJHXCIsXG5cdFx0XHRcIs6UXCI6IFwiRFwiLFxuXHRcdFx0XCLOlVwiOiBcIkVcIixcblx0XHRcdFwizpZcIjogXCJaXCIsXG5cdFx0XHRcIs6XXCI6IFwiSVwiLFxuXHRcdFx0XCLOmFwiOiBcIlRIXCIsXG5cdFx0XHRcIs6ZXCI6IFwiSVwiLFxuXHRcdFx0XCLOmlwiOiBcIktcIixcblx0XHRcdFwizptcIjogXCJMXCIsXG5cdFx0XHRcIs6cXCI6IFwiTVwiLFxuXHRcdFx0XCLOnVwiOiBcIk5cIixcblx0XHRcdFwizp5cIjogXCJLU1wiLFxuXHRcdFx0XCLOn1wiOiBcIk9cIixcblx0XHRcdFwizqBcIjogXCJQXCIsXG5cdFx0XHRcIs6hXCI6IFwiUlwiLFxuXHRcdFx0XCLOo1wiOiBcIlNcIixcblx0XHRcdFwizqRcIjogXCJUXCIsXG5cdFx0XHRcIs6lXCI6IFwiWVwiLFxuXHRcdFx0XCLOplwiOiBcIkZcIixcblx0XHRcdFwizqdcIjogXCJYXCIsXG5cdFx0XHRcIs6oXCI6IFwiUFNcIixcblx0XHRcdFwizqlcIjogXCJPXCIsXG5cdFx0XHRcIs6GXCI6IFwiQVwiLFxuXHRcdFx0XCLOiFwiOiBcIkVcIixcblx0XHRcdFwizopcIjogXCJJXCIsXG5cdFx0XHRcIs6MXCI6IFwiT1wiLFxuXHRcdFx0XCLOjlwiOiBcIllcIixcblx0XHRcdFwizolcIjogXCJJXCIsXG5cdFx0XHRcIs6PXCI6IFwiT1wiLFxuXHRcdFx0XCLOqlwiOiBcIklcIixcblx0XHRcdFwizqtcIjogXCJZXCIsXG5cdFx0XHRcIsSBXCI6IFwiYVwiLFxuXHRcdFx0XCLEk1wiOiBcImVcIixcblx0XHRcdFwixKNcIjogXCJnXCIsXG5cdFx0XHRcIsSrXCI6IFwiaVwiLFxuXHRcdFx0XCLEt1wiOiBcImtcIixcblx0XHRcdFwixLxcIjogXCJsXCIsXG5cdFx0XHRcIsWGXCI6IFwiblwiLFxuXHRcdFx0XCLFq1wiOiBcInVcIixcblx0XHRcdFwixIBcIjogXCJBXCIsXG5cdFx0XHRcIsSSXCI6IFwiRVwiLFxuXHRcdFx0XCLEolwiOiBcIkdcIixcblx0XHRcdFwixKpcIjogXCJJXCIsXG5cdFx0XHRcIsS2XCI6IFwia1wiLFxuXHRcdFx0XCLEu1wiOiBcIkxcIixcblx0XHRcdFwixYVcIjogXCJOXCIsXG5cdFx0XHRcIsWqXCI6IFwiVVwiLFxuXHRcdFx0XCLQjFwiOiBcIktqXCIsXG5cdFx0XHRcItGcXCI6IFwia2pcIixcblx0XHRcdFwi0IlcIjogXCJMalwiLFxuXHRcdFx0XCLRmVwiOiBcImxqXCIsXG5cdFx0XHRcItCKXCI6IFwiTmpcIixcblx0XHRcdFwi0ZpcIjogXCJualwiLFxuXHRcdFx0XCLQotGBXCI6IFwiVHNcIixcblx0XHRcdFwi0YLRgVwiOiBcInRzXCIsXG5cdFx0XHRcIsSFXCI6IFwiYVwiLFxuXHRcdFx0XCLEh1wiOiBcImNcIixcblx0XHRcdFwixJlcIjogXCJlXCIsXG5cdFx0XHRcIsWCXCI6IFwibFwiLFxuXHRcdFx0XCLFhFwiOiBcIm5cIixcblx0XHRcdFwixZtcIjogXCJzXCIsXG5cdFx0XHRcIsW6XCI6IFwielwiLFxuXHRcdFx0XCLFvFwiOiBcInpcIixcblx0XHRcdFwixIRcIjogXCJBXCIsXG5cdFx0XHRcIsSGXCI6IFwiQ1wiLFxuXHRcdFx0XCLEmFwiOiBcIkVcIixcblx0XHRcdFwixYFcIjogXCJMXCIsXG5cdFx0XHRcIsWDXCI6IFwiTlwiLFxuXHRcdFx0XCLFmlwiOiBcIlNcIixcblx0XHRcdFwixblcIjogXCJaXCIsXG5cdFx0XHRcIsW7XCI6IFwiWlwiLFxuXHRcdFx0XCLQhFwiOiBcIlllXCIsXG5cdFx0XHRcItCGXCI6IFwiSVwiLFxuXHRcdFx0XCLQh1wiOiBcIllpXCIsXG5cdFx0XHRcItKQXCI6IFwiR1wiLFxuXHRcdFx0XCLRlFwiOiBcInllXCIsXG5cdFx0XHRcItGWXCI6IFwiaVwiLFxuXHRcdFx0XCLRl1wiOiBcInlpXCIsXG5cdFx0XHRcItKRXCI6IFwiZ1wiLFxuXHRcdFx0XCLEg1wiOiBcImFcIixcblx0XHRcdFwixIJcIjogXCJBXCIsXG5cdFx0XHRcIsiZXCI6IFwic1wiLFxuXHRcdFx0XCLImFwiOiBcIlNcIixcblx0XHRcdFwiyJtcIjogXCJ0XCIsXG5cdFx0XHRcIsiaXCI6IFwiVFwiLFxuXHRcdFx0XCLFo1wiOiBcInRcIixcblx0XHRcdFwixaJcIjogXCJUXCIsXG5cdFx0XHRcItCwXCI6IFwiYVwiLFxuXHRcdFx0XCLQsVwiOiBcImJcIixcblx0XHRcdFwi0LJcIjogXCJ2XCIsXG5cdFx0XHRcItCzXCI6IFwiZ1wiLFxuXHRcdFx0XCLQtFwiOiBcImRcIixcblx0XHRcdFwi0LVcIjogXCJlXCIsXG5cdFx0XHRcItGRXCI6IFwieW9cIixcblx0XHRcdFwi0LZcIjogXCJ6aFwiLFxuXHRcdFx0XCLQt1wiOiBcInpcIixcblx0XHRcdFwi0LhcIjogXCJpXCIsXG5cdFx0XHRcItC5XCI6IFwiaVwiLFxuXHRcdFx0XCLQulwiOiBcImtcIixcblx0XHRcdFwi0LtcIjogXCJsXCIsXG5cdFx0XHRcItC8XCI6IFwibVwiLFxuXHRcdFx0XCLQvVwiOiBcIm5cIixcblx0XHRcdFwi0L5cIjogXCJvXCIsXG5cdFx0XHRcItC/XCI6IFwicFwiLFxuXHRcdFx0XCLRgFwiOiBcInJcIixcblx0XHRcdFwi0YFcIjogXCJzXCIsXG5cdFx0XHRcItGCXCI6IFwidFwiLFxuXHRcdFx0XCLRg1wiOiBcInVcIixcblx0XHRcdFwi0YRcIjogXCJmXCIsXG5cdFx0XHRcItGFXCI6IFwia2hcIixcblx0XHRcdFwi0YZcIjogXCJjXCIsXG5cdFx0XHRcItGHXCI6IFwiY2hcIixcblx0XHRcdFwi0YhcIjogXCJzaFwiLFxuXHRcdFx0XCLRiVwiOiBcInNoXCIsXG5cdFx0XHRcItGKXCI6IFwiXCIsXG5cdFx0XHRcItGLXCI6IFwieVwiLFxuXHRcdFx0XCLRjFwiOiBcIlwiLFxuXHRcdFx0XCLRjVwiOiBcImVcIixcblx0XHRcdFwi0Y5cIjogXCJ5dVwiLFxuXHRcdFx0XCLRj1wiOiBcInlhXCIsXG5cdFx0XHRcItCQXCI6IFwiQVwiLFxuXHRcdFx0XCLQkVwiOiBcIkJcIixcblx0XHRcdFwi0JJcIjogXCJWXCIsXG5cdFx0XHRcItCTXCI6IFwiR1wiLFxuXHRcdFx0XCLQlFwiOiBcIkRcIixcblx0XHRcdFwi0JVcIjogXCJFXCIsXG5cdFx0XHRcItCBXCI6IFwiWW9cIixcblx0XHRcdFwi0JZcIjogXCJaaFwiLFxuXHRcdFx0XCLQl1wiOiBcIlpcIixcblx0XHRcdFwi0JhcIjogXCJJXCIsXG5cdFx0XHRcItCZXCI6IFwiSVwiLFxuXHRcdFx0XCLQmlwiOiBcIktcIixcblx0XHRcdFwi0JtcIjogXCJMXCIsXG5cdFx0XHRcItCcXCI6IFwiTVwiLFxuXHRcdFx0XCLQnVwiOiBcIk5cIixcblx0XHRcdFwi0J5cIjogXCJPXCIsXG5cdFx0XHRcItCfXCI6IFwiUFwiLFxuXHRcdFx0XCLQoFwiOiBcIlJcIixcblx0XHRcdFwi0KFcIjogXCJTXCIsXG5cdFx0XHRcItCiXCI6IFwiVFwiLFxuXHRcdFx0XCLQo1wiOiBcIlVcIixcblx0XHRcdFwi0KRcIjogXCJGXCIsXG5cdFx0XHRcItClXCI6IFwiS2hcIixcblx0XHRcdFwi0KZcIjogXCJDXCIsXG5cdFx0XHRcItCnXCI6IFwiQ2hcIixcblx0XHRcdFwi0KhcIjogXCJTaFwiLFxuXHRcdFx0XCLQqVwiOiBcIlNoXCIsXG5cdFx0XHRcItCqXCI6IFwiXCIsXG5cdFx0XHRcItCrXCI6IFwiWVwiLFxuXHRcdFx0XCLQrFwiOiBcIlwiLFxuXHRcdFx0XCLQrVwiOiBcIkVcIixcblx0XHRcdFwi0K5cIjogXCJZdVwiLFxuXHRcdFx0XCLQr1wiOiBcIllhXCIsXG5cdFx0XHRcItGSXCI6IFwiZGpcIixcblx0XHRcdFwi0ZhcIjogXCJqXCIsXG5cdFx0XHRcItGbXCI6IFwiY1wiLFxuXHRcdFx0XCLRn1wiOiBcImR6XCIsXG5cdFx0XHRcItCCXCI6IFwiRGpcIixcblx0XHRcdFwi0IhcIjogXCJqXCIsXG5cdFx0XHRcItCLXCI6IFwiQ1wiLFxuXHRcdFx0XCLQj1wiOiBcIkR6XCIsXG5cdFx0XHRcIsS+XCI6IFwibFwiLFxuXHRcdFx0XCLEulwiOiBcImxcIixcblx0XHRcdFwixZVcIjogXCJyXCIsXG5cdFx0XHRcIsS9XCI6IFwiTFwiLFxuXHRcdFx0XCLEuVwiOiBcIkxcIixcblx0XHRcdFwixZRcIjogXCJSXCIsXG5cdFx0XHRcIsWfXCI6IFwic1wiLFxuXHRcdFx0XCLFnlwiOiBcIlNcIixcblx0XHRcdFwixLFcIjogXCJpXCIsXG5cdFx0XHRcIsSwXCI6IFwiSVwiLFxuXHRcdFx0XCLEn1wiOiBcImdcIixcblx0XHRcdFwixJ5cIjogXCJHXCIsXG5cdFx0XHRcIuG6o1wiOiBcImFcIixcblx0XHRcdFwi4bqiXCI6IFwiQVwiLFxuXHRcdFx0XCLhurNcIjogXCJhXCIsXG5cdFx0XHRcIuG6slwiOiBcIkFcIixcblx0XHRcdFwi4bqpXCI6IFwiYVwiLFxuXHRcdFx0XCLhuqhcIjogXCJBXCIsXG5cdFx0XHRcIsSRXCI6IFwiZFwiLFxuXHRcdFx0XCLEkFwiOiBcIkRcIixcblx0XHRcdFwi4bq5XCI6IFwiZVwiLFxuXHRcdFx0XCLhurhcIjogXCJFXCIsXG5cdFx0XHRcIuG6vVwiOiBcImVcIixcblx0XHRcdFwi4bq8XCI6IFwiRVwiLFxuXHRcdFx0XCLhurtcIjogXCJlXCIsXG5cdFx0XHRcIuG6ulwiOiBcIkVcIixcblx0XHRcdFwi4bq/XCI6IFwiZVwiLFxuXHRcdFx0XCLhur5cIjogXCJFXCIsXG5cdFx0XHRcIuG7gVwiOiBcImVcIixcblx0XHRcdFwi4buAXCI6IFwiRVwiLFxuXHRcdFx0XCLhu4dcIjogXCJlXCIsXG5cdFx0XHRcIuG7hlwiOiBcIkVcIixcblx0XHRcdFwi4buFXCI6IFwiZVwiLFxuXHRcdFx0XCLhu4RcIjogXCJFXCIsXG5cdFx0XHRcIuG7g1wiOiBcImVcIixcblx0XHRcdFwi4buCXCI6IFwiRVwiLFxuXHRcdFx0XCLhu49cIjogXCJvXCIsXG5cdFx0XHRcIuG7jVwiOiBcIm9cIixcblx0XHRcdFwi4buMXCI6IFwib1wiLFxuXHRcdFx0XCLhu5FcIjogXCJvXCIsXG5cdFx0XHRcIuG7kFwiOiBcIk9cIixcblx0XHRcdFwi4buTXCI6IFwib1wiLFxuXHRcdFx0XCLhu5JcIjogXCJPXCIsXG5cdFx0XHRcIuG7lVwiOiBcIm9cIixcblx0XHRcdFwi4buUXCI6IFwiT1wiLFxuXHRcdFx0XCLhu5lcIjogXCJvXCIsXG5cdFx0XHRcIuG7mFwiOiBcIk9cIixcblx0XHRcdFwi4buXXCI6IFwib1wiLFxuXHRcdFx0XCLhu5ZcIjogXCJPXCIsXG5cdFx0XHRcIsahXCI6IFwib1wiLFxuXHRcdFx0XCLGoFwiOiBcIk9cIixcblx0XHRcdFwi4bubXCI6IFwib1wiLFxuXHRcdFx0XCLhu5pcIjogXCJPXCIsXG5cdFx0XHRcIuG7nVwiOiBcIm9cIixcblx0XHRcdFwi4bucXCI6IFwiT1wiLFxuXHRcdFx0XCLhu6NcIjogXCJvXCIsXG5cdFx0XHRcIuG7olwiOiBcIk9cIixcblx0XHRcdFwi4buhXCI6IFwib1wiLFxuXHRcdFx0XCLhu6BcIjogXCJPXCIsXG5cdFx0XHRcIuG7nlwiOiBcIm9cIixcblx0XHRcdFwi4bufXCI6IFwib1wiLFxuXHRcdFx0XCLhu4tcIjogXCJpXCIsXG5cdFx0XHRcIuG7ilwiOiBcIklcIixcblx0XHRcdFwixKlcIjogXCJpXCIsXG5cdFx0XHRcIsSoXCI6IFwiSVwiLFxuXHRcdFx0XCLhu4lcIjogXCJpXCIsXG5cdFx0XHRcIuG7iFwiOiBcImlcIixcblx0XHRcdFwi4bunXCI6IFwidVwiLFxuXHRcdFx0XCLhu6ZcIjogXCJVXCIsXG5cdFx0XHRcIuG7pVwiOiBcInVcIixcblx0XHRcdFwi4bukXCI6IFwiVVwiLFxuXHRcdFx0XCLFqVwiOiBcInVcIixcblx0XHRcdFwixahcIjogXCJVXCIsXG5cdFx0XHRcIsawXCI6IFwidVwiLFxuXHRcdFx0XCLGr1wiOiBcIlVcIixcblx0XHRcdFwi4bupXCI6IFwidVwiLFxuXHRcdFx0XCLhu6hcIjogXCJVXCIsXG5cdFx0XHRcIuG7q1wiOiBcInVcIixcblx0XHRcdFwi4buqXCI6IFwiVVwiLFxuXHRcdFx0XCLhu7FcIjogXCJ1XCIsXG5cdFx0XHRcIuG7sFwiOiBcIlVcIixcblx0XHRcdFwi4buvXCI6IFwidVwiLFxuXHRcdFx0XCLhu65cIjogXCJVXCIsXG5cdFx0XHRcIuG7rVwiOiBcInVcIixcblx0XHRcdFwi4busXCI6IFwixrBcIixcblx0XHRcdFwi4bu3XCI6IFwieVwiLFxuXHRcdFx0XCLhu7ZcIjogXCJ5XCIsXG5cdFx0XHRcIuG7s1wiOiBcInlcIixcblx0XHRcdFwi4buyXCI6IFwiWVwiLFxuXHRcdFx0XCLhu7VcIjogXCJ5XCIsXG5cdFx0XHRcIuG7tFwiOiBcIllcIixcblx0XHRcdFwi4bu5XCI6IFwieVwiLFxuXHRcdFx0XCLhu7hcIjogXCJZXCIsXG5cdFx0XHRcIuG6oVwiOiBcImFcIixcblx0XHRcdFwi4bqgXCI6IFwiQVwiLFxuXHRcdFx0XCLhuqVcIjogXCJhXCIsXG5cdFx0XHRcIuG6pFwiOiBcIkFcIixcblx0XHRcdFwi4bqnXCI6IFwiYVwiLFxuXHRcdFx0XCLhuqZcIjogXCJBXCIsXG5cdFx0XHRcIuG6rVwiOiBcImFcIixcblx0XHRcdFwi4bqsXCI6IFwiQVwiLFxuXHRcdFx0XCLhuqtcIjogXCJhXCIsXG5cdFx0XHRcIuG6qlwiOiBcIkFcIixcblx0XHRcdFwi4bqvXCI6IFwiYVwiLFxuXHRcdFx0XCLhuq5cIjogXCJBXCIsXG5cdFx0XHRcIuG6sVwiOiBcImFcIixcblx0XHRcdFwi4bqwXCI6IFwiQVwiLFxuXHRcdFx0XCLhurdcIjogXCJhXCIsXG5cdFx0XHRcIuG6tlwiOiBcIkFcIixcblx0XHRcdFwi4bq1XCI6IFwiYVwiLFxuXHRcdFx0XCLhurRcIjogXCJBXCIsXG5cdFx0XHRcIuKTqlwiOiBcIjBcIixcblx0XHRcdFwi4pGgXCI6IFwiMVwiLFxuXHRcdFx0XCLikaFcIjogXCIyXCIsXG5cdFx0XHRcIuKRolwiOiBcIjNcIixcblx0XHRcdFwi4pGjXCI6IFwiNFwiLFxuXHRcdFx0XCLikaRcIjogXCI1XCIsXG5cdFx0XHRcIuKRpVwiOiBcIjZcIixcblx0XHRcdFwi4pGmXCI6IFwiN1wiLFxuXHRcdFx0XCLikadcIjogXCI4XCIsXG5cdFx0XHRcIuKRqFwiOiBcIjlcIixcblx0XHRcdFwi4pGpXCI6IFwiMTBcIixcblx0XHRcdFwi4pGqXCI6IFwiMTFcIixcblx0XHRcdFwi4pGrXCI6IFwiMTJcIixcblx0XHRcdFwi4pGsXCI6IFwiMTNcIixcblx0XHRcdFwi4pGtXCI6IFwiMTRcIixcblx0XHRcdFwi4pGuXCI6IFwiMTVcIixcblx0XHRcdFwi4pGvXCI6IFwiMTZcIixcblx0XHRcdFwi4pGwXCI6IFwiMTdcIixcblx0XHRcdFwi4pGxXCI6IFwiMThcIixcblx0XHRcdFwi4pGyXCI6IFwiMThcIixcblx0XHRcdFwi4pGzXCI6IFwiMThcIixcblx0XHRcdFwi4pO1XCI6IFwiMVwiLFxuXHRcdFx0XCLik7ZcIjogXCIyXCIsXG5cdFx0XHRcIuKTt1wiOiBcIjNcIixcblx0XHRcdFwi4pO4XCI6IFwiNFwiLFxuXHRcdFx0XCLik7lcIjogXCI1XCIsXG5cdFx0XHRcIuKTulwiOiBcIjZcIixcblx0XHRcdFwi4pO7XCI6IFwiN1wiLFxuXHRcdFx0XCLik7xcIjogXCI4XCIsXG5cdFx0XHRcIuKTvVwiOiBcIjlcIixcblx0XHRcdFwi4pO+XCI6IFwiMTBcIixcblx0XHRcdFwi4pO/XCI6IFwiMFwiLFxuXHRcdFx0XCLik6tcIjogXCIxMVwiLFxuXHRcdFx0XCLik6xcIjogXCIxMlwiLFxuXHRcdFx0XCLik61cIjogXCIxM1wiLFxuXHRcdFx0XCLik65cIjogXCIxNFwiLFxuXHRcdFx0XCLik69cIjogXCIxNVwiLFxuXHRcdFx0XCLik7BcIjogXCIxNlwiLFxuXHRcdFx0XCLik7FcIjogXCIxN1wiLFxuXHRcdFx0XCLik7JcIjogXCIxOFwiLFxuXHRcdFx0XCLik7NcIjogXCIxOVwiLFxuXHRcdFx0XCLik7RcIjogXCIyMFwiLFxuXHRcdFx0XCLikrZcIjogXCJBXCIsXG5cdFx0XHRcIuKSt1wiOiBcIkJcIixcblx0XHRcdFwi4pK4XCI6IFwiQ1wiLFxuXHRcdFx0XCLikrlcIjogXCJEXCIsXG5cdFx0XHRcIuKSulwiOiBcIkVcIixcblx0XHRcdFwi4pK7XCI6IFwiRlwiLFxuXHRcdFx0XCLikrxcIjogXCJHXCIsXG5cdFx0XHRcIuKSvVwiOiBcIkhcIixcblx0XHRcdFwi4pK+XCI6IFwiSVwiLFxuXHRcdFx0XCLikr9cIjogXCJKXCIsXG5cdFx0XHRcIuKTgFwiOiBcIktcIixcblx0XHRcdFwi4pOBXCI6IFwiTFwiLFxuXHRcdFx0XCLik4JcIjogXCJNXCIsXG5cdFx0XHRcIuKTg1wiOiBcIk5cIixcblx0XHRcdFwi4pOEXCI6IFwiT1wiLFxuXHRcdFx0XCLik4VcIjogXCJQXCIsXG5cdFx0XHRcIuKThlwiOiBcIlFcIixcblx0XHRcdFwi4pOHXCI6IFwiUlwiLFxuXHRcdFx0XCLik4hcIjogXCJTXCIsXG5cdFx0XHRcIuKTiVwiOiBcIlRcIixcblx0XHRcdFwi4pOKXCI6IFwiVVwiLFxuXHRcdFx0XCLik4tcIjogXCJWXCIsXG5cdFx0XHRcIuKTjFwiOiBcIldcIixcblx0XHRcdFwi4pONXCI6IFwiWFwiLFxuXHRcdFx0XCLik45cIjogXCJZXCIsXG5cdFx0XHRcIuKTj1wiOiBcIlpcIixcblx0XHRcdFwi4pOQXCI6IFwiYVwiLFxuXHRcdFx0XCLik5FcIjogXCJiXCIsXG5cdFx0XHRcIuKTklwiOiBcImNcIixcblx0XHRcdFwi4pOTXCI6IFwiZFwiLFxuXHRcdFx0XCLik5RcIjogXCJlXCIsXG5cdFx0XHRcIuKTlVwiOiBcImZcIixcblx0XHRcdFwi4pOWXCI6IFwiZ1wiLFxuXHRcdFx0XCLik5dcIjogXCJoXCIsXG5cdFx0XHRcIuKTmFwiOiBcImlcIixcblx0XHRcdFwi4pOZXCI6IFwialwiLFxuXHRcdFx0XCLik5pcIjogXCJrXCIsXG5cdFx0XHRcIuKTm1wiOiBcImxcIixcblx0XHRcdFwi4pOcXCI6IFwibVwiLFxuXHRcdFx0XCLik51cIjogXCJuXCIsXG5cdFx0XHRcIuKTnlwiOiBcIm9cIixcblx0XHRcdFwi4pOfXCI6IFwicFwiLFxuXHRcdFx0XCLik6BcIjogXCJxXCIsXG5cdFx0XHRcIuKToVwiOiBcInJcIixcblx0XHRcdFwi4pOiXCI6IFwic1wiLFxuXHRcdFx0XCLik6NcIjogXCJ0XCIsXG5cdFx0XHRcIuKTpFwiOiBcInVcIixcblx0XHRcdFwi4pOmXCI6IFwidlwiLFxuXHRcdFx0XCLik6VcIjogXCJ3XCIsXG5cdFx0XHRcIuKTp1wiOiBcInhcIixcblx0XHRcdFwi4pOoXCI6IFwieVwiLFxuXHRcdFx0XCLik6lcIjogXCJ6XCIsXG5cdFx0XHRcIuKAnFwiOiBcIlxcXCJcIixcblx0XHRcdFwi4oCdXCI6IFwiXFxcIlwiLFxuXHRcdFx0XCLigJhcIjogXCInXCIsXG5cdFx0XHRcIuKAmVwiOiBcIidcIixcblx0XHRcdFwi4oiCXCI6IFwiZFwiLFxuXHRcdFx0XCLGklwiOiBcImZcIixcblx0XHRcdFwi4oSiXCI6IFwiKFRNKVwiLFxuXHRcdFx0XCLCqVwiOiBcIihDKVwiLFxuXHRcdFx0XCLFk1wiOiBcIm9lXCIsXG5cdFx0XHRcIsWSXCI6IFwiT0VcIixcblx0XHRcdFwiwq5cIjogXCIoUilcIixcblx0XHRcdFwi4oCgXCI6IFwiK1wiLFxuXHRcdFx0XCLihKBcIjogXCIoU00pXCIsXG5cdFx0XHRcIuKAplwiOiBcIi4uLlwiLFxuXHRcdFx0XCLLmlwiOiBcIm9cIixcblx0XHRcdFwiwrpcIjogXCJvXCIsXG5cdFx0XHRcIsKqXCI6IFwiYVwiLFxuXHRcdFx0XCLigKJcIjogXCIqXCIsXG5cdFx0XHRcIuGBilwiOiBcIixcIixcblx0XHRcdFwi4YGLXCI6IFwiLlwiLFxuXHRcdFx0XCIkXCI6IFwiVVNEXCIsXG5cdFx0XHRcIuKCrFwiOiBcIkVVUlwiLFxuXHRcdFx0XCLigqJcIjogXCJCUk5cIixcblx0XHRcdFwi4oKjXCI6IFwiRlJGXCIsXG5cdFx0XHRcIsKjXCI6IFwiR0JQXCIsXG5cdFx0XHRcIuKCpFwiOiBcIklUTFwiLFxuXHRcdFx0XCLigqZcIjogXCJOR05cIixcblx0XHRcdFwi4oKnXCI6IFwiRVNQXCIsXG5cdFx0XHRcIuKCqVwiOiBcIktSV1wiLFxuXHRcdFx0XCLigqpcIjogXCJJTFNcIixcblx0XHRcdFwi4oKrXCI6IFwiVk5EXCIsXG5cdFx0XHRcIuKCrVwiOiBcIkxBS1wiLFxuXHRcdFx0XCLigq5cIjogXCJNTlRcIixcblx0XHRcdFwi4oKvXCI6IFwiR1JEXCIsXG5cdFx0XHRcIuKCsVwiOiBcIkFSU1wiLFxuXHRcdFx0XCLigrJcIjogXCJQWUdcIixcblx0XHRcdFwi4oKzXCI6IFwiQVJBXCIsXG5cdFx0XHRcIuKCtFwiOiBcIlVBSFwiLFxuXHRcdFx0XCLigrVcIjogXCJHSFNcIixcblx0XHRcdFwiwqJcIjogXCJjZW50XCIsXG5cdFx0XHRcIsKlXCI6IFwiQ05ZXCIsXG5cdFx0XHRcIuWFg1wiOiBcIkNOWVwiLFxuXHRcdFx0XCLlhoZcIjogXCJZRU5cIixcblx0XHRcdFwi77e8XCI6IFwiSVJSXCIsXG5cdFx0XHRcIuKCoFwiOiBcIkVXRVwiLFxuXHRcdFx0XCLguL9cIjogXCJUSEJcIixcblx0XHRcdFwi4oKoXCI6IFwiSU5SXCIsXG5cdFx0XHRcIuKCuVwiOiBcIklOUlwiLFxuXHRcdFx0XCLigrBcIjogXCJQRlwiLFxuXHRcdFx0XCLigrpcIjogXCJUUllcIixcblx0XHRcdFwi2ItcIjogXCJBRk5cIixcblx0XHRcdFwi4oK8XCI6IFwiQVpOXCIsXG5cdFx0XHRcItC70LJcIjogXCJCR05cIixcblx0XHRcdFwi4Z+bXCI6IFwiS0hSXCIsXG5cdFx0XHRcIuKCoVwiOiBcIkNSQ1wiLFxuXHRcdFx0XCLigrhcIjogXCJLWlRcIixcblx0XHRcdFwi0LTQtdC9XCI6IFwiTUtEXCIsXG5cdFx0XHRcInrFglwiOiBcIlBMTlwiLFxuXHRcdFx0XCLigr1cIjogXCJSVUJcIixcblx0XHRcdFwi4oK+XCI6IFwiR0VMXCJcblx0XHR9O1xuXHRcdC8qKlxuXHRcdCogc3BlY2lhbCBsb29rIGFoZWFkIGNoYXJhY3RlciBhcnJheVxuXHRcdCogVGhlc2UgY2hhcmFjdGVycyBmb3JtIHdpdGggY29uc29uYW50cyB0byBiZWNvbWUgJ3NpbmdsZScvY29uc29uYW50IGNvbWJvXG5cdFx0KiBAdHlwZSBbQXJyYXldXG5cdFx0Ki9cblx0XHR2YXIgbG9va0FoZWFkQ2hhckFycmF5ID0gW1wi4YC6XCIsIFwi3rBcIl07XG5cdFx0LyoqXG5cdFx0KiBkaWF0cmljTWFwIGZvciBsYW5ndWFnZXMgd2hlcmUgdHJhbnNsaXRlcmF0aW9uIGNoYW5nZXMgZW50aXJlbHkgYXMgbW9yZSBkaWF0cmljcyBhcmUgYWRkZWRcblx0XHQqIEB0eXBlIHtPYmplY3R9XG5cdFx0Ki9cblx0XHR2YXIgZGlhdHJpY01hcCA9IHtcblx0XHRcdFwi4YCsXCI6IFwiYVwiLFxuXHRcdFx0XCLhgKtcIjogXCJhXCIsXG5cdFx0XHRcIuGAsVwiOiBcImVcIixcblx0XHRcdFwi4YCyXCI6IFwiZVwiLFxuXHRcdFx0XCLhgK1cIjogXCJpXCIsXG5cdFx0XHRcIuGArlwiOiBcImlcIixcblx0XHRcdFwi4YCt4YCvXCI6IFwib1wiLFxuXHRcdFx0XCLhgK9cIjogXCJ1XCIsXG5cdFx0XHRcIuGAsFwiOiBcInVcIixcblx0XHRcdFwi4YCx4YCr4YCE4YC6XCI6IFwiYXVuZ1wiLFxuXHRcdFx0XCLhgLHhgKxcIjogXCJhd1wiLFxuXHRcdFx0XCLhgLHhgKzhgLpcIjogXCJhd1wiLFxuXHRcdFx0XCLhgLHhgKtcIjogXCJhd1wiLFxuXHRcdFx0XCLhgLHhgKvhgLpcIjogXCJhd1wiLFxuXHRcdFx0XCLhgLpcIjogXCLhgLpcIixcblx0XHRcdFwi4YCA4YC6XCI6IFwiZXRcIixcblx0XHRcdFwi4YCt4YCv4YCA4YC6XCI6IFwiYWlrXCIsXG5cdFx0XHRcIuGAseGArOGAgOGAulwiOiBcImF1a1wiLFxuXHRcdFx0XCLhgIThgLpcIjogXCJpblwiLFxuXHRcdFx0XCLhgK3hgK/hgIThgLpcIjogXCJhaW5nXCIsXG5cdFx0XHRcIuGAseGArOGAhOGAulwiOiBcImF1bmdcIixcblx0XHRcdFwi4YCF4YC6XCI6IFwiaXRcIixcblx0XHRcdFwi4YCK4YC6XCI6IFwiaVwiLFxuXHRcdFx0XCLhgJDhgLpcIjogXCJhdFwiLFxuXHRcdFx0XCLhgK3hgJDhgLpcIjogXCJlaWtcIixcblx0XHRcdFwi4YCv4YCQ4YC6XCI6IFwib2tcIixcblx0XHRcdFwi4YC94YCQ4YC6XCI6IFwidXRcIixcblx0XHRcdFwi4YCx4YCQ4YC6XCI6IFwiaXRcIixcblx0XHRcdFwi4YCS4YC6XCI6IFwiZFwiLFxuXHRcdFx0XCLhgK3hgK/hgJLhgLpcIjogXCJva1wiLFxuXHRcdFx0XCLhgK/hgJLhgLpcIjogXCJhaXRcIixcblx0XHRcdFwi4YCU4YC6XCI6IFwiYW5cIixcblx0XHRcdFwi4YCs4YCU4YC6XCI6IFwiYW5cIixcblx0XHRcdFwi4YCt4YCU4YC6XCI6IFwiZWluXCIsXG5cdFx0XHRcIuGAr+GAlOGAulwiOiBcIm9uXCIsXG5cdFx0XHRcIuGAveGAlOGAulwiOiBcInVuXCIsXG5cdFx0XHRcIuGAleGAulwiOiBcImF0XCIsXG5cdFx0XHRcIuGAreGAleGAulwiOiBcImVpa1wiLFxuXHRcdFx0XCLhgK/hgJXhgLpcIjogXCJva1wiLFxuXHRcdFx0XCLhgL3hgJXhgLpcIjogXCJ1dFwiLFxuXHRcdFx0XCLhgJThgLrhgK/hgJXhgLpcIjogXCJudWJcIixcblx0XHRcdFwi4YCZ4YC6XCI6IFwiYW5cIixcblx0XHRcdFwi4YCt4YCZ4YC6XCI6IFwiZWluXCIsXG5cdFx0XHRcIuGAr+GAmeGAulwiOiBcIm9uXCIsXG5cdFx0XHRcIuGAveGAmeGAulwiOiBcInVuXCIsXG5cdFx0XHRcIuGAmuGAulwiOiBcImVcIixcblx0XHRcdFwi4YCt4YCv4YCc4YC6XCI6IFwib2xcIixcblx0XHRcdFwi4YCJ4YC6XCI6IFwiaW5cIixcblx0XHRcdFwi4YC2XCI6IFwiYW5cIixcblx0XHRcdFwi4YCt4YC2XCI6IFwiZWluXCIsXG5cdFx0XHRcIuGAr+GAtlwiOiBcIm9uXCIsXG5cdFx0XHRcIt6m3ofesFwiOiBcImFoXCIsXG5cdFx0XHRcIt6m3oHesFwiOiBcImFoXCJcblx0XHR9O1xuXHRcdC8qKlxuXHRcdCogbGFuZ0NoYXJNYXAgbGFuZ3VhZ2Ugc3BlY2lmaWMgY2hhcmFjdGVycyB0cmFuc2xhdGlvbnNcblx0XHQqIEB0eXBlICAge09iamVjdH1cblx0XHQqL1xuXHRcdHZhciBsYW5nQ2hhck1hcCA9IHtcblx0XHRcdFwiZW5cIjoge30sXG5cdFx0XHRcImF6XCI6IHtcblx0XHRcdFx0XCLDp1wiOiBcImNcIixcblx0XHRcdFx0XCLJmVwiOiBcImVcIixcblx0XHRcdFx0XCLEn1wiOiBcImdcIixcblx0XHRcdFx0XCLEsVwiOiBcImlcIixcblx0XHRcdFx0XCLDtlwiOiBcIm9cIixcblx0XHRcdFx0XCLFn1wiOiBcInNcIixcblx0XHRcdFx0XCLDvFwiOiBcInVcIixcblx0XHRcdFx0XCLDh1wiOiBcIkNcIixcblx0XHRcdFx0XCLGj1wiOiBcIkVcIixcblx0XHRcdFx0XCLEnlwiOiBcIkdcIixcblx0XHRcdFx0XCLEsFwiOiBcIklcIixcblx0XHRcdFx0XCLDllwiOiBcIk9cIixcblx0XHRcdFx0XCLFnlwiOiBcIlNcIixcblx0XHRcdFx0XCLDnFwiOiBcIlVcIlxuXHRcdFx0fSxcblx0XHRcdFwiY3NcIjoge1xuXHRcdFx0XHRcIsSNXCI6IFwiY1wiLFxuXHRcdFx0XHRcIsSPXCI6IFwiZFwiLFxuXHRcdFx0XHRcIsSbXCI6IFwiZVwiLFxuXHRcdFx0XHRcIsWIXCI6IFwiblwiLFxuXHRcdFx0XHRcIsWZXCI6IFwiclwiLFxuXHRcdFx0XHRcIsWhXCI6IFwic1wiLFxuXHRcdFx0XHRcIsWlXCI6IFwidFwiLFxuXHRcdFx0XHRcIsWvXCI6IFwidVwiLFxuXHRcdFx0XHRcIsW+XCI6IFwielwiLFxuXHRcdFx0XHRcIsSMXCI6IFwiQ1wiLFxuXHRcdFx0XHRcIsSOXCI6IFwiRFwiLFxuXHRcdFx0XHRcIsSaXCI6IFwiRVwiLFxuXHRcdFx0XHRcIsWHXCI6IFwiTlwiLFxuXHRcdFx0XHRcIsWYXCI6IFwiUlwiLFxuXHRcdFx0XHRcIsWgXCI6IFwiU1wiLFxuXHRcdFx0XHRcIsWkXCI6IFwiVFwiLFxuXHRcdFx0XHRcIsWuXCI6IFwiVVwiLFxuXHRcdFx0XHRcIsW9XCI6IFwiWlwiXG5cdFx0XHR9LFxuXHRcdFx0XCJmaVwiOiB7XG5cdFx0XHRcdFwiw6RcIjogXCJhXCIsXG5cdFx0XHRcdFwiw4RcIjogXCJBXCIsXG5cdFx0XHRcdFwiw7ZcIjogXCJvXCIsXG5cdFx0XHRcdFwiw5ZcIjogXCJPXCJcblx0XHRcdH0sXG5cdFx0XHRcImh1XCI6IHtcblx0XHRcdFx0XCLDpFwiOiBcImFcIixcblx0XHRcdFx0XCLDhFwiOiBcIkFcIixcblx0XHRcdFx0XCLDtlwiOiBcIm9cIixcblx0XHRcdFx0XCLDllwiOiBcIk9cIixcblx0XHRcdFx0XCLDvFwiOiBcInVcIixcblx0XHRcdFx0XCLDnFwiOiBcIlVcIixcblx0XHRcdFx0XCLFsVwiOiBcInVcIixcblx0XHRcdFx0XCLFsFwiOiBcIlVcIlxuXHRcdFx0fSxcblx0XHRcdFwibHRcIjoge1xuXHRcdFx0XHRcIsSFXCI6IFwiYVwiLFxuXHRcdFx0XHRcIsSNXCI6IFwiY1wiLFxuXHRcdFx0XHRcIsSZXCI6IFwiZVwiLFxuXHRcdFx0XHRcIsSXXCI6IFwiZVwiLFxuXHRcdFx0XHRcIsSvXCI6IFwiaVwiLFxuXHRcdFx0XHRcIsWhXCI6IFwic1wiLFxuXHRcdFx0XHRcIsWzXCI6IFwidVwiLFxuXHRcdFx0XHRcIsWrXCI6IFwidVwiLFxuXHRcdFx0XHRcIsW+XCI6IFwielwiLFxuXHRcdFx0XHRcIsSEXCI6IFwiQVwiLFxuXHRcdFx0XHRcIsSMXCI6IFwiQ1wiLFxuXHRcdFx0XHRcIsSYXCI6IFwiRVwiLFxuXHRcdFx0XHRcIsSWXCI6IFwiRVwiLFxuXHRcdFx0XHRcIsSuXCI6IFwiSVwiLFxuXHRcdFx0XHRcIsWgXCI6IFwiU1wiLFxuXHRcdFx0XHRcIsWyXCI6IFwiVVwiLFxuXHRcdFx0XHRcIsWqXCI6IFwiVVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJsdlwiOiB7XG5cdFx0XHRcdFwixIFcIjogXCJhXCIsXG5cdFx0XHRcdFwixI1cIjogXCJjXCIsXG5cdFx0XHRcdFwixJNcIjogXCJlXCIsXG5cdFx0XHRcdFwixKNcIjogXCJnXCIsXG5cdFx0XHRcdFwixKtcIjogXCJpXCIsXG5cdFx0XHRcdFwixLdcIjogXCJrXCIsXG5cdFx0XHRcdFwixLxcIjogXCJsXCIsXG5cdFx0XHRcdFwixYZcIjogXCJuXCIsXG5cdFx0XHRcdFwixaFcIjogXCJzXCIsXG5cdFx0XHRcdFwixatcIjogXCJ1XCIsXG5cdFx0XHRcdFwixb5cIjogXCJ6XCIsXG5cdFx0XHRcdFwixIBcIjogXCJBXCIsXG5cdFx0XHRcdFwixIxcIjogXCJDXCIsXG5cdFx0XHRcdFwixJJcIjogXCJFXCIsXG5cdFx0XHRcdFwixKJcIjogXCJHXCIsXG5cdFx0XHRcdFwixKpcIjogXCJpXCIsXG5cdFx0XHRcdFwixLZcIjogXCJrXCIsXG5cdFx0XHRcdFwixLtcIjogXCJMXCIsXG5cdFx0XHRcdFwixYVcIjogXCJOXCIsXG5cdFx0XHRcdFwixaBcIjogXCJTXCIsXG5cdFx0XHRcdFwixapcIjogXCJ1XCIsXG5cdFx0XHRcdFwixb1cIjogXCJaXCJcblx0XHRcdH0sXG5cdFx0XHRcInBsXCI6IHtcblx0XHRcdFx0XCLEhVwiOiBcImFcIixcblx0XHRcdFx0XCLEh1wiOiBcImNcIixcblx0XHRcdFx0XCLEmVwiOiBcImVcIixcblx0XHRcdFx0XCLFglwiOiBcImxcIixcblx0XHRcdFx0XCLFhFwiOiBcIm5cIixcblx0XHRcdFx0XCLDs1wiOiBcIm9cIixcblx0XHRcdFx0XCLFm1wiOiBcInNcIixcblx0XHRcdFx0XCLFulwiOiBcInpcIixcblx0XHRcdFx0XCLFvFwiOiBcInpcIixcblx0XHRcdFx0XCLEhFwiOiBcIkFcIixcblx0XHRcdFx0XCLEhlwiOiBcIkNcIixcblx0XHRcdFx0XCLEmFwiOiBcImVcIixcblx0XHRcdFx0XCLFgVwiOiBcIkxcIixcblx0XHRcdFx0XCLFg1wiOiBcIk5cIixcblx0XHRcdFx0XCLDk1wiOiBcIk9cIixcblx0XHRcdFx0XCLFmlwiOiBcIlNcIixcblx0XHRcdFx0XCLFuVwiOiBcIlpcIixcblx0XHRcdFx0XCLFu1wiOiBcIlpcIlxuXHRcdFx0fSxcblx0XHRcdFwic3ZcIjoge1xuXHRcdFx0XHRcIsOkXCI6IFwiYVwiLFxuXHRcdFx0XHRcIsOEXCI6IFwiQVwiLFxuXHRcdFx0XHRcIsO2XCI6IFwib1wiLFxuXHRcdFx0XHRcIsOWXCI6IFwiT1wiXG5cdFx0XHR9LFxuXHRcdFx0XCJza1wiOiB7XG5cdFx0XHRcdFwiw6RcIjogXCJhXCIsXG5cdFx0XHRcdFwiw4RcIjogXCJBXCJcblx0XHRcdH0sXG5cdFx0XHRcInNyXCI6IHtcblx0XHRcdFx0XCLRmVwiOiBcImxqXCIsXG5cdFx0XHRcdFwi0ZpcIjogXCJualwiLFxuXHRcdFx0XHRcItCJXCI6IFwiTGpcIixcblx0XHRcdFx0XCLQilwiOiBcIk5qXCIsXG5cdFx0XHRcdFwixJFcIjogXCJkalwiLFxuXHRcdFx0XHRcIsSQXCI6IFwiRGpcIlxuXHRcdFx0fSxcblx0XHRcdFwidHJcIjoge1xuXHRcdFx0XHRcIsOcXCI6IFwiVVwiLFxuXHRcdFx0XHRcIsOWXCI6IFwiT1wiLFxuXHRcdFx0XHRcIsO8XCI6IFwidVwiLFxuXHRcdFx0XHRcIsO2XCI6IFwib1wiXG5cdFx0XHR9XG5cdFx0fTtcblx0XHQvKipcblx0XHQqIHN5bWJvbE1hcCBsYW5ndWFnZSBzcGVjaWZpYyBzeW1ib2wgdHJhbnNsYXRpb25zXG5cdFx0KiB0cmFuc2xhdGlvbnMgbXVzdCBiZSB0cmFuc2xpdGVyYXRlZCBhbHJlYWR5XG5cdFx0KiBAdHlwZSAgIHtPYmplY3R9XG5cdFx0Ki9cblx0XHR2YXIgc3ltYm9sTWFwID0ge1xuXHRcdFx0XCJhclwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJsYS1uaWhheWFcIixcblx0XHRcdFx0XCLimaVcIjogXCJob2JcIixcblx0XHRcdFx0XCImXCI6IFwid2FcIixcblx0XHRcdFx0XCJ8XCI6IFwiYXdcIixcblx0XHRcdFx0XCI8XCI6IFwiYXFhbC1tZW5cIixcblx0XHRcdFx0XCI+XCI6IFwiYWtiYXItbWVuXCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwibWFqbW91XCIsXG5cdFx0XHRcdFwiwqRcIjogXCJvbWxhXCJcblx0XHRcdH0sXG5cdFx0XHRcImF6XCI6IHt9LFxuXHRcdFx0XCJjYVwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJpbmZpbml0XCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwiYW1vclwiLFxuXHRcdFx0XHRcIiZcIjogXCJpXCIsXG5cdFx0XHRcdFwifFwiOiBcIm9cIixcblx0XHRcdFx0XCI8XCI6IFwibWVueXMgcXVlXCIsXG5cdFx0XHRcdFwiPlwiOiBcIm1lcyBxdWVcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzdW1hIGRlbHNcIixcblx0XHRcdFx0XCLCpFwiOiBcIm1vbmVkYVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJjc1wiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJuZWtvbmVjbm9cIixcblx0XHRcdFx0XCLimaVcIjogXCJsYXNrYVwiLFxuXHRcdFx0XHRcIiZcIjogXCJhXCIsXG5cdFx0XHRcdFwifFwiOiBcIm5lYm9cIixcblx0XHRcdFx0XCI8XCI6IFwibWVuc2kgbmV6XCIsXG5cdFx0XHRcdFwiPlwiOiBcInZldHNpIG5lelwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInNvdWNldFwiLFxuXHRcdFx0XHRcIsKkXCI6IFwibWVuYVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJkZVwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJ1bmVuZGxpY2hcIixcblx0XHRcdFx0XCLimaVcIjogXCJMaWViZVwiLFxuXHRcdFx0XHRcIiZcIjogXCJ1bmRcIixcblx0XHRcdFx0XCJ8XCI6IFwib2RlclwiLFxuXHRcdFx0XHRcIjxcIjogXCJrbGVpbmVyIGFsc1wiLFxuXHRcdFx0XHRcIj5cIjogXCJncm9lc3NlciBhbHNcIixcblx0XHRcdFx0XCLiiJFcIjogXCJTdW1tZSB2b25cIixcblx0XHRcdFx0XCLCpFwiOiBcIldhZWhydW5nXCJcblx0XHRcdH0sXG5cdFx0XHRcImR2XCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcImtvbHVudWxhYVwiLFxuXHRcdFx0XHRcIuKZpVwiOiBcImxvYWJpXCIsXG5cdFx0XHRcdFwiJlwiOiBcImFhaVwiLFxuXHRcdFx0XHRcInxcIjogXCJub29uZWVcIixcblx0XHRcdFx0XCI8XCI6IFwiYWggdnVyZSBrdWRhXCIsXG5cdFx0XHRcdFwiPlwiOiBcImFoIHZ1cmUgYm9kdVwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcImp1bXVsYVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwiZmFpc2FhXCJcblx0XHRcdH0sXG5cdFx0XHRcImVuXCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcImluZmluaXR5XCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwibG92ZVwiLFxuXHRcdFx0XHRcIiZcIjogXCJhbmRcIixcblx0XHRcdFx0XCJ8XCI6IFwib3JcIixcblx0XHRcdFx0XCI8XCI6IFwibGVzcyB0aGFuXCIsXG5cdFx0XHRcdFwiPlwiOiBcImdyZWF0ZXIgdGhhblwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInN1bVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwiY3VycmVuY3lcIlxuXHRcdFx0fSxcblx0XHRcdFwiZXNcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiaW5maW5pdG9cIixcblx0XHRcdFx0XCLimaVcIjogXCJhbW9yXCIsXG5cdFx0XHRcdFwiJlwiOiBcInlcIixcblx0XHRcdFx0XCJ8XCI6IFwidVwiLFxuXHRcdFx0XHRcIjxcIjogXCJtZW5vcyBxdWVcIixcblx0XHRcdFx0XCI+XCI6IFwibWFzIHF1ZVwiLFxuXHRcdFx0XHRcIuKIkVwiOiBcInN1bWEgZGUgbG9zXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJtb25lZGFcIlxuXHRcdFx0fSxcblx0XHRcdFwiZmFcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiYmktbmFoYXlhdFwiLFxuXHRcdFx0XHRcIuKZpVwiOiBcImVzaGdoXCIsXG5cdFx0XHRcdFwiJlwiOiBcInZhXCIsXG5cdFx0XHRcdFwifFwiOiBcInlhXCIsXG5cdFx0XHRcdFwiPFwiOiBcImthbXRhci1helwiLFxuXHRcdFx0XHRcIj5cIjogXCJiaXNodGFyLWF6XCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwibWFqbW9vZVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwidmFoZWRcIlxuXHRcdFx0fSxcblx0XHRcdFwiZmlcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiYWFyZXR0b215eXNcIixcblx0XHRcdFx0XCLimaVcIjogXCJyYWtrYXVzXCIsXG5cdFx0XHRcdFwiJlwiOiBcImphXCIsXG5cdFx0XHRcdFwifFwiOiBcInRhaVwiLFxuXHRcdFx0XHRcIjxcIjogXCJwaWVuZW1waSBrdWluXCIsXG5cdFx0XHRcdFwiPlwiOiBcInN1dXJlbXBpIGt1aW5cIixcblx0XHRcdFx0XCLiiJFcIjogXCJzdW1tYVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwidmFsdXV0dGFcIlxuXHRcdFx0fSxcblx0XHRcdFwiZnJcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiaW5maW5pbWVudFwiLFxuXHRcdFx0XHRcIuKZpVwiOiBcIkFtb3VyXCIsXG5cdFx0XHRcdFwiJlwiOiBcImV0XCIsXG5cdFx0XHRcdFwifFwiOiBcIm91XCIsXG5cdFx0XHRcdFwiPFwiOiBcIm1vaW5zIHF1ZVwiLFxuXHRcdFx0XHRcIj5cIjogXCJzdXBlcmlldXJlIGFcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzb21tZSBkZXNcIixcblx0XHRcdFx0XCLCpFwiOiBcIm1vbm5haWVcIlxuXHRcdFx0fSxcblx0XHRcdFwiZ2VcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwidXNhc3J1bG9iYVwiLFxuXHRcdFx0XHRcIuKZpVwiOiBcInNpcXZhcnVsaVwiLFxuXHRcdFx0XHRcIiZcIjogXCJkYVwiLFxuXHRcdFx0XHRcInxcIjogXCJhblwiLFxuXHRcdFx0XHRcIjxcIjogXCJuYWtsZWJpXCIsXG5cdFx0XHRcdFwiPlwiOiBcIm1ldGlcIixcblx0XHRcdFx0XCLiiJFcIjogXCJqYW1pXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJ2YWx1dGFcIlxuXHRcdFx0fSxcblx0XHRcdFwiZ3JcIjoge30sXG5cdFx0XHRcImh1XCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcInZlZ3RlbGVuXCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwic3plcmVsZW1cIixcblx0XHRcdFx0XCImXCI6IFwiZXNcIixcblx0XHRcdFx0XCJ8XCI6IFwidmFneVwiLFxuXHRcdFx0XHRcIjxcIjogXCJraXNlYmIgbWludFwiLFxuXHRcdFx0XHRcIj5cIjogXCJuYWd5b2JiIG1pbnRcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzenVtbWFcIixcblx0XHRcdFx0XCLCpFwiOiBcInBlbnpuZW1cIlxuXHRcdFx0fSxcblx0XHRcdFwiaXRcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiaW5maW5pdG9cIixcblx0XHRcdFx0XCLimaVcIjogXCJhbW9yZVwiLFxuXHRcdFx0XHRcIiZcIjogXCJlXCIsXG5cdFx0XHRcdFwifFwiOiBcIm9cIixcblx0XHRcdFx0XCI8XCI6IFwibWlub3JlIGRpXCIsXG5cdFx0XHRcdFwiPlwiOiBcIm1hZ2dpb3JlIGRpXCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwic29tbWFcIixcblx0XHRcdFx0XCLCpFwiOiBcIm1vbmV0YVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJsdFwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJiZWdhbHliZVwiLFxuXHRcdFx0XHRcIuKZpVwiOiBcIm1laWxlXCIsXG5cdFx0XHRcdFwiJlwiOiBcImlyXCIsXG5cdFx0XHRcdFwifFwiOiBcImFyXCIsXG5cdFx0XHRcdFwiPFwiOiBcIm1hemlhdSBuZWlcIixcblx0XHRcdFx0XCI+XCI6IFwiZGF1Z2lhdSBuZWlcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzdW1hXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJ2YWxpdXRhXCJcblx0XHRcdH0sXG5cdFx0XHRcImx2XCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcImJlemdhbGliYVwiLFxuXHRcdFx0XHRcIuKZpVwiOiBcIm1pbGVzdGliYVwiLFxuXHRcdFx0XHRcIiZcIjogXCJ1blwiLFxuXHRcdFx0XHRcInxcIjogXCJ2YWlcIixcblx0XHRcdFx0XCI8XCI6IFwibWF6YWsgbmVrYVwiLFxuXHRcdFx0XHRcIj5cIjogXCJsaWVsYWtzIG5la2FcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzdW1tYVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwidmFsdXRhXCJcblx0XHRcdH0sXG5cdFx0XHRcIm15XCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJrd2Foa2h5YWV0XCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiYXNhb25hc21lXCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwiYWtoeWFpdFwiLFxuXHRcdFx0XHRcIiZcIjogXCJuaGluXCIsXG5cdFx0XHRcdFwifFwiOiBcInRob1wiLFxuXHRcdFx0XHRcIjxcIjogXCJuZ2V0aGF3XCIsXG5cdFx0XHRcdFwiPlwiOiBcImt5aXRoYXdcIixcblx0XHRcdFx0XCLiiJFcIjogXCJwYXVuZ2xkXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJuZ3dla3llXCJcblx0XHRcdH0sXG5cdFx0XHRcIm1rXCI6IHt9LFxuXHRcdFx0XCJubFwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJvbmVpbmRpZ1wiLFxuXHRcdFx0XHRcIuKZpVwiOiBcImxpZWZkZVwiLFxuXHRcdFx0XHRcIiZcIjogXCJlblwiLFxuXHRcdFx0XHRcInxcIjogXCJvZlwiLFxuXHRcdFx0XHRcIjxcIjogXCJrbGVpbmVyIGRhblwiLFxuXHRcdFx0XHRcIj5cIjogXCJncm90ZXIgZGFuXCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwic29tXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJ2YWx1dGFcIlxuXHRcdFx0fSxcblx0XHRcdFwicGxcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwibmllc2tvbmN6b25vc2NcIixcblx0XHRcdFx0XCLimaVcIjogXCJtaWxvc2NcIixcblx0XHRcdFx0XCImXCI6IFwiaVwiLFxuXHRcdFx0XHRcInxcIjogXCJsdWJcIixcblx0XHRcdFx0XCI8XCI6IFwibW5pZWpzemUgbml6XCIsXG5cdFx0XHRcdFwiPlwiOiBcIndpZWtzemUgbml6XCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwic3VtYVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwid2FsdXRhXCJcblx0XHRcdH0sXG5cdFx0XHRcInB0XCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcImluZmluaXRvXCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwiYW1vclwiLFxuXHRcdFx0XHRcIiZcIjogXCJlXCIsXG5cdFx0XHRcdFwifFwiOiBcIm91XCIsXG5cdFx0XHRcdFwiPFwiOiBcIm1lbm9yIHF1ZVwiLFxuXHRcdFx0XHRcIj5cIjogXCJtYWlvciBxdWVcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzb21hXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJtb2VkYVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJyb1wiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJpbmZpbml0XCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwiZHJhZ29zdGVcIixcblx0XHRcdFx0XCImXCI6IFwic2lcIixcblx0XHRcdFx0XCJ8XCI6IFwic2F1XCIsXG5cdFx0XHRcdFwiPFwiOiBcIm1haSBtaWMgY2FcIixcblx0XHRcdFx0XCI+XCI6IFwibWFpIG1hcmUgY2FcIixcblx0XHRcdFx0XCLiiJFcIjogXCJzdW1hXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJ2YWx1dGFcIlxuXHRcdFx0fSxcblx0XHRcdFwicnVcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwiYmVza29uZWNobm9cIixcblx0XHRcdFx0XCLimaVcIjogXCJsdWJvdlwiLFxuXHRcdFx0XHRcIiZcIjogXCJpXCIsXG5cdFx0XHRcdFwifFwiOiBcImlsaVwiLFxuXHRcdFx0XHRcIjxcIjogXCJtZW5zaGVcIixcblx0XHRcdFx0XCI+XCI6IFwiYm9sc2hlXCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwic3VtbWFcIixcblx0XHRcdFx0XCLCpFwiOiBcInZhbGp1dGFcIlxuXHRcdFx0fSxcblx0XHRcdFwic2tcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwibmVrb25lY25vXCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwibGFza2FcIixcblx0XHRcdFx0XCImXCI6IFwiYVwiLFxuXHRcdFx0XHRcInxcIjogXCJhbGVib1wiLFxuXHRcdFx0XHRcIjxcIjogXCJtZW5laiBha29cIixcblx0XHRcdFx0XCI+XCI6IFwidmlhYyBha29cIixcblx0XHRcdFx0XCLiiJFcIjogXCJzdWNldFwiLFxuXHRcdFx0XHRcIsKkXCI6IFwibWVuYVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJzclwiOiB7fSxcblx0XHRcdFwidHJcIjoge1xuXHRcdFx0XHRcIuKIhlwiOiBcImRlbHRhXCIsXG5cdFx0XHRcdFwi4oieXCI6IFwic29uc3V6bHVrXCIsXG5cdFx0XHRcdFwi4pmlXCI6IFwiYXNrXCIsXG5cdFx0XHRcdFwiJlwiOiBcInZlXCIsXG5cdFx0XHRcdFwifFwiOiBcInZleWFcIixcblx0XHRcdFx0XCI8XCI6IFwia3VjdWt0dXJcIixcblx0XHRcdFx0XCI+XCI6IFwiYnV5dWt0dXJcIixcblx0XHRcdFx0XCLiiJFcIjogXCJ0b3BsYW1cIixcblx0XHRcdFx0XCLCpFwiOiBcInBhcmEgYmlyaW1pXCJcblx0XHRcdH0sXG5cdFx0XHRcInVrXCI6IHtcblx0XHRcdFx0XCLiiIZcIjogXCJkZWx0YVwiLFxuXHRcdFx0XHRcIuKInlwiOiBcImJlemtpbmVjaG5pc3RcIixcblx0XHRcdFx0XCLimaVcIjogXCJsdWJvdlwiLFxuXHRcdFx0XHRcIiZcIjogXCJpXCIsXG5cdFx0XHRcdFwifFwiOiBcImFib1wiLFxuXHRcdFx0XHRcIjxcIjogXCJtZW5zaGVcIixcblx0XHRcdFx0XCI+XCI6IFwiYmlsc2hlXCIsXG5cdFx0XHRcdFwi4oiRXCI6IFwic3VtYVwiLFxuXHRcdFx0XHRcIsKkXCI6IFwidmFsanV0YVwiXG5cdFx0XHR9LFxuXHRcdFx0XCJ2blwiOiB7XG5cdFx0XHRcdFwi4oiGXCI6IFwiZGVsdGFcIixcblx0XHRcdFx0XCLiiJ5cIjogXCJ2byBjdWNcIixcblx0XHRcdFx0XCLimaVcIjogXCJ5ZXVcIixcblx0XHRcdFx0XCImXCI6IFwidmFcIixcblx0XHRcdFx0XCJ8XCI6IFwiaG9hY1wiLFxuXHRcdFx0XHRcIjxcIjogXCJuaG8gaG9uXCIsXG5cdFx0XHRcdFwiPlwiOiBcImxvbiBob25cIixcblx0XHRcdFx0XCLiiJFcIjogXCJ0b25nXCIsXG5cdFx0XHRcdFwiwqRcIjogXCJ0aWVuIHRlXCJcblx0XHRcdH1cblx0XHR9O1xuXHRcdHZhciB1cmljQ2hhcnMgPSBbXG5cdFx0XHRcIjtcIixcblx0XHRcdFwiP1wiLFxuXHRcdFx0XCI6XCIsXG5cdFx0XHRcIkBcIixcblx0XHRcdFwiJlwiLFxuXHRcdFx0XCI9XCIsXG5cdFx0XHRcIitcIixcblx0XHRcdFwiJFwiLFxuXHRcdFx0XCIsXCIsXG5cdFx0XHRcIi9cIlxuXHRcdF0uam9pbihcIlwiKTtcblx0XHR2YXIgdXJpY05vU2xhc2hDaGFycyA9IFtcblx0XHRcdFwiO1wiLFxuXHRcdFx0XCI/XCIsXG5cdFx0XHRcIjpcIixcblx0XHRcdFwiQFwiLFxuXHRcdFx0XCImXCIsXG5cdFx0XHRcIj1cIixcblx0XHRcdFwiK1wiLFxuXHRcdFx0XCIkXCIsXG5cdFx0XHRcIixcIlxuXHRcdF0uam9pbihcIlwiKTtcblx0XHR2YXIgbWFya0NoYXJzID0gW1xuXHRcdFx0XCIuXCIsXG5cdFx0XHRcIiFcIixcblx0XHRcdFwiflwiLFxuXHRcdFx0XCIqXCIsXG5cdFx0XHRcIidcIixcblx0XHRcdFwiKFwiLFxuXHRcdFx0XCIpXCJcblx0XHRdLmpvaW4oXCJcIik7XG5cdFx0LyoqXG5cdFx0KiBnZXRTbHVnXG5cdFx0KiBAcGFyYW0gIHtzdHJpbmd9IGlucHV0IGlucHV0IHN0cmluZ1xuXHRcdCogQHBhcmFtICB7b2JqZWN0fHN0cmluZ30gb3B0cyBjb25maWcgb2JqZWN0IG9yIHNlcGFyYXRvciBzdHJpbmcvY2hhclxuXHRcdCogQGFwaSAgICBwdWJsaWNcblx0XHQqIEByZXR1cm4ge3N0cmluZ30gIHNsdWdnaWZpZWQgc3RyaW5nXG5cdFx0Ki9cblx0XHR2YXIgZ2V0U2x1ZyA9IGZ1bmN0aW9uIGdldFNsdWcoaW5wdXQsIG9wdHMpIHtcblx0XHRcdHZhciBzZXBhcmF0b3IgPSBcIi1cIjtcblx0XHRcdHZhciByZXN1bHQgPSBcIlwiO1xuXHRcdFx0dmFyIGRpYXRyaWNTdHJpbmcgPSBcIlwiO1xuXHRcdFx0dmFyIGNvbnZlcnRTeW1ib2xzID0gdHJ1ZTtcblx0XHRcdHZhciBjdXN0b21SZXBsYWNlbWVudHMgPSB7fTtcblx0XHRcdHZhciBtYWludGFpbkNhc2U7XG5cdFx0XHR2YXIgdGl0bGVDYXNlO1xuXHRcdFx0dmFyIHRydW5jYXRlO1xuXHRcdFx0dmFyIHVyaWNGbGFnO1xuXHRcdFx0dmFyIHVyaWNOb1NsYXNoRmxhZztcblx0XHRcdHZhciBtYXJrRmxhZztcblx0XHRcdHZhciBzeW1ib2w7XG5cdFx0XHR2YXIgbGFuZ0NoYXI7XG5cdFx0XHR2YXIgbHVja3k7XG5cdFx0XHR2YXIgaTtcblx0XHRcdHZhciBjaDtcblx0XHRcdHZhciBsO1xuXHRcdFx0dmFyIGxhc3RDaGFyV2FzU3ltYm9sO1xuXHRcdFx0dmFyIGxhc3RDaGFyV2FzRGlhdHJpYztcblx0XHRcdHZhciBhbGxvd2VkQ2hhcnMgPSBcIlwiO1xuXHRcdFx0aWYgKHR5cGVvZiBpbnB1dCAhPT0gXCJzdHJpbmdcIikgcmV0dXJuIFwiXCI7XG5cdFx0XHRpZiAodHlwZW9mIG9wdHMgPT09IFwic3RyaW5nXCIpIHNlcGFyYXRvciA9IG9wdHM7XG5cdFx0XHRzeW1ib2wgPSBzeW1ib2xNYXAuZW47XG5cdFx0XHRsYW5nQ2hhciA9IGxhbmdDaGFyTWFwLmVuO1xuXHRcdFx0aWYgKHR5cGVvZiBvcHRzID09PSBcIm9iamVjdFwiKSB7XG5cdFx0XHRcdG1haW50YWluQ2FzZSA9IG9wdHMubWFpbnRhaW5DYXNlIHx8IGZhbHNlO1xuXHRcdFx0XHRjdXN0b21SZXBsYWNlbWVudHMgPSBvcHRzLmN1c3RvbSAmJiB0eXBlb2Ygb3B0cy5jdXN0b20gPT09IFwib2JqZWN0XCIgPyBvcHRzLmN1c3RvbSA6IGN1c3RvbVJlcGxhY2VtZW50cztcblx0XHRcdFx0dHJ1bmNhdGUgPSArb3B0cy50cnVuY2F0ZSA+IDEgJiYgb3B0cy50cnVuY2F0ZSB8fCBmYWxzZTtcblx0XHRcdFx0dXJpY0ZsYWcgPSBvcHRzLnVyaWMgfHwgZmFsc2U7XG5cdFx0XHRcdHVyaWNOb1NsYXNoRmxhZyA9IG9wdHMudXJpY05vU2xhc2ggfHwgZmFsc2U7XG5cdFx0XHRcdG1hcmtGbGFnID0gb3B0cy5tYXJrIHx8IGZhbHNlO1xuXHRcdFx0XHRjb252ZXJ0U3ltYm9scyA9IG9wdHMuc3ltYm9scyA9PT0gZmFsc2UgfHwgb3B0cy5sYW5nID09PSBmYWxzZSA/IGZhbHNlIDogdHJ1ZTtcblx0XHRcdFx0c2VwYXJhdG9yID0gb3B0cy5zZXBhcmF0b3IgfHwgc2VwYXJhdG9yO1xuXHRcdFx0XHRpZiAodXJpY0ZsYWcpIGFsbG93ZWRDaGFycyArPSB1cmljQ2hhcnM7XG5cdFx0XHRcdGlmICh1cmljTm9TbGFzaEZsYWcpIGFsbG93ZWRDaGFycyArPSB1cmljTm9TbGFzaENoYXJzO1xuXHRcdFx0XHRpZiAobWFya0ZsYWcpIGFsbG93ZWRDaGFycyArPSBtYXJrQ2hhcnM7XG5cdFx0XHRcdHN5bWJvbCA9IG9wdHMubGFuZyAmJiBzeW1ib2xNYXBbb3B0cy5sYW5nXSAmJiBjb252ZXJ0U3ltYm9scyA/IHN5bWJvbE1hcFtvcHRzLmxhbmddIDogY29udmVydFN5bWJvbHMgPyBzeW1ib2xNYXAuZW4gOiB7fTtcblx0XHRcdFx0bGFuZ0NoYXIgPSBvcHRzLmxhbmcgJiYgbGFuZ0NoYXJNYXBbb3B0cy5sYW5nXSA/IGxhbmdDaGFyTWFwW29wdHMubGFuZ10gOiBvcHRzLmxhbmcgPT09IGZhbHNlIHx8IG9wdHMubGFuZyA9PT0gdHJ1ZSA/IHt9IDogbGFuZ0NoYXJNYXAuZW47XG5cdFx0XHRcdGlmIChvcHRzLnRpdGxlQ2FzZSAmJiB0eXBlb2Ygb3B0cy50aXRsZUNhc2UubGVuZ3RoID09PSBcIm51bWJlclwiICYmIEFycmF5LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG9wdHMudGl0bGVDYXNlKSkge1xuXHRcdFx0XHRcdG9wdHMudGl0bGVDYXNlLmZvckVhY2goZnVuY3Rpb24odikge1xuXHRcdFx0XHRcdFx0Y3VzdG9tUmVwbGFjZW1lbnRzW3YgKyBcIlwiXSA9IHYgKyBcIlwiO1xuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdHRpdGxlQ2FzZSA9IHRydWU7XG5cdFx0XHRcdH0gZWxzZSB0aXRsZUNhc2UgPSAhIW9wdHMudGl0bGVDYXNlO1xuXHRcdFx0XHRpZiAob3B0cy5jdXN0b20gJiYgdHlwZW9mIG9wdHMuY3VzdG9tLmxlbmd0aCA9PT0gXCJudW1iZXJcIiAmJiBBcnJheS5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChvcHRzLmN1c3RvbSkpIG9wdHMuY3VzdG9tLmZvckVhY2goZnVuY3Rpb24odikge1xuXHRcdFx0XHRcdGN1c3RvbVJlcGxhY2VtZW50c1t2ICsgXCJcIl0gPSB2ICsgXCJcIjtcblx0XHRcdFx0fSk7XG5cdFx0XHRcdE9iamVjdC5rZXlzKGN1c3RvbVJlcGxhY2VtZW50cykuZm9yRWFjaChmdW5jdGlvbih2KSB7XG5cdFx0XHRcdFx0dmFyIHI7XG5cdFx0XHRcdFx0aWYgKHYubGVuZ3RoID4gMSkgciA9IG5ldyBSZWdFeHAoXCJcXFxcYlwiICsgZXNjYXBlQ2hhcnModikgKyBcIlxcXFxiXCIsIFwiZ2lcIik7XG5cdFx0XHRcdFx0ZWxzZSByID0gbmV3IFJlZ0V4cChlc2NhcGVDaGFycyh2KSwgXCJnaVwiKTtcblx0XHRcdFx0XHRpbnB1dCA9IGlucHV0LnJlcGxhY2UociwgY3VzdG9tUmVwbGFjZW1lbnRzW3ZdKTtcblx0XHRcdFx0fSk7XG5cdFx0XHRcdGZvciAoY2ggaW4gY3VzdG9tUmVwbGFjZW1lbnRzKSBhbGxvd2VkQ2hhcnMgKz0gY2g7XG5cdFx0XHR9XG5cdFx0XHRhbGxvd2VkQ2hhcnMgKz0gc2VwYXJhdG9yO1xuXHRcdFx0YWxsb3dlZENoYXJzID0gZXNjYXBlQ2hhcnMoYWxsb3dlZENoYXJzKTtcblx0XHRcdGlucHV0ID0gaW5wdXQucmVwbGFjZSgvKF5cXHMrfFxccyskKS9nLCBcIlwiKTtcblx0XHRcdGxhc3RDaGFyV2FzU3ltYm9sID0gZmFsc2U7XG5cdFx0XHRsYXN0Q2hhcldhc0RpYXRyaWMgPSBmYWxzZTtcblx0XHRcdGZvciAoaSA9IDAsIGwgPSBpbnB1dC5sZW5ndGg7IGkgPCBsOyBpKyspIHtcblx0XHRcdFx0Y2ggPSBpbnB1dFtpXTtcblx0XHRcdFx0aWYgKGlzUmVwbGFjZWRDdXN0b21DaGFyKGNoLCBjdXN0b21SZXBsYWNlbWVudHMpKSBsYXN0Q2hhcldhc1N5bWJvbCA9IGZhbHNlO1xuXHRcdFx0XHRlbHNlIGlmIChsYW5nQ2hhcltjaF0pIHtcblx0XHRcdFx0XHRjaCA9IGxhc3RDaGFyV2FzU3ltYm9sICYmIGxhbmdDaGFyW2NoXS5tYXRjaCgvW0EtWmEtejAtOV0vKSA/IFwiIFwiICsgbGFuZ0NoYXJbY2hdIDogbGFuZ0NoYXJbY2hdO1xuXHRcdFx0XHRcdGxhc3RDaGFyV2FzU3ltYm9sID0gZmFsc2U7XG5cdFx0XHRcdH0gZWxzZSBpZiAoY2ggaW4gY2hhck1hcCkge1xuXHRcdFx0XHRcdGlmIChpICsgMSA8IGwgJiYgbG9va0FoZWFkQ2hhckFycmF5LmluZGV4T2YoaW5wdXRbaSArIDFdKSA+PSAwKSB7XG5cdFx0XHRcdFx0XHRkaWF0cmljU3RyaW5nICs9IGNoO1xuXHRcdFx0XHRcdFx0Y2ggPSBcIlwiO1xuXHRcdFx0XHRcdH0gZWxzZSBpZiAobGFzdENoYXJXYXNEaWF0cmljID09PSB0cnVlKSB7XG5cdFx0XHRcdFx0XHRjaCA9IGRpYXRyaWNNYXBbZGlhdHJpY1N0cmluZ10gKyBjaGFyTWFwW2NoXTtcblx0XHRcdFx0XHRcdGRpYXRyaWNTdHJpbmcgPSBcIlwiO1xuXHRcdFx0XHRcdH0gZWxzZSBjaCA9IGxhc3RDaGFyV2FzU3ltYm9sICYmIGNoYXJNYXBbY2hdLm1hdGNoKC9bQS1aYS16MC05XS8pID8gXCIgXCIgKyBjaGFyTWFwW2NoXSA6IGNoYXJNYXBbY2hdO1xuXHRcdFx0XHRcdGxhc3RDaGFyV2FzU3ltYm9sID0gZmFsc2U7XG5cdFx0XHRcdFx0bGFzdENoYXJXYXNEaWF0cmljID0gZmFsc2U7XG5cdFx0XHRcdH0gZWxzZSBpZiAoY2ggaW4gZGlhdHJpY01hcCkge1xuXHRcdFx0XHRcdGRpYXRyaWNTdHJpbmcgKz0gY2g7XG5cdFx0XHRcdFx0Y2ggPSBcIlwiO1xuXHRcdFx0XHRcdGlmIChpID09PSBsIC0gMSkgY2ggPSBkaWF0cmljTWFwW2RpYXRyaWNTdHJpbmddO1xuXHRcdFx0XHRcdGxhc3RDaGFyV2FzRGlhdHJpYyA9IHRydWU7XG5cdFx0XHRcdH0gZWxzZSBpZiAoc3ltYm9sW2NoXSAmJiAhKHVyaWNGbGFnICYmIHVyaWNDaGFycy5pbmRleE9mKGNoKSAhPT0gLTEpICYmICEodXJpY05vU2xhc2hGbGFnICYmIHVyaWNOb1NsYXNoQ2hhcnMuaW5kZXhPZihjaCkgIT09IC0xKSkge1xuXHRcdFx0XHRcdGNoID0gbGFzdENoYXJXYXNTeW1ib2wgfHwgcmVzdWx0LnN1YnN0cigtMSkubWF0Y2goL1tBLVphLXowLTldLykgPyBzZXBhcmF0b3IgKyBzeW1ib2xbY2hdIDogc3ltYm9sW2NoXTtcblx0XHRcdFx0XHRjaCArPSBpbnB1dFtpICsgMV0gIT09IHZvaWQgMCAmJiBpbnB1dFtpICsgMV0ubWF0Y2goL1tBLVphLXowLTldLykgPyBzZXBhcmF0b3IgOiBcIlwiO1xuXHRcdFx0XHRcdGxhc3RDaGFyV2FzU3ltYm9sID0gdHJ1ZTtcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRpZiAobGFzdENoYXJXYXNEaWF0cmljID09PSB0cnVlKSB7XG5cdFx0XHRcdFx0XHRjaCA9IGRpYXRyaWNNYXBbZGlhdHJpY1N0cmluZ10gKyBjaDtcblx0XHRcdFx0XHRcdGRpYXRyaWNTdHJpbmcgPSBcIlwiO1xuXHRcdFx0XHRcdFx0bGFzdENoYXJXYXNEaWF0cmljID0gZmFsc2U7XG5cdFx0XHRcdFx0fSBlbHNlIGlmIChsYXN0Q2hhcldhc1N5bWJvbCAmJiAoL1tBLVphLXowLTldLy50ZXN0KGNoKSB8fCByZXN1bHQuc3Vic3RyKC0xKS5tYXRjaCgvQS1aYS16MC05XS8pKSkgY2ggPSBcIiBcIiArIGNoO1xuXHRcdFx0XHRcdGxhc3RDaGFyV2FzU3ltYm9sID0gZmFsc2U7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmVzdWx0ICs9IGNoLnJlcGxhY2UobmV3IFJlZ0V4cChcIlteXFxcXHdcXFxcc1wiICsgYWxsb3dlZENoYXJzICsgXCJfLV1cIiwgXCJnXCIpLCBzZXBhcmF0b3IpO1xuXHRcdFx0fVxuXHRcdFx0aWYgKHRpdGxlQ2FzZSkgcmVzdWx0ID0gcmVzdWx0LnJlcGxhY2UoLyhcXHcpKFxcUyopL2csIGZ1bmN0aW9uKF8sIGksIHIpIHtcblx0XHRcdFx0dmFyIGogPSBpLnRvVXBwZXJDYXNlKCkgKyAociAhPT0gbnVsbCA/IHIgOiBcIlwiKTtcblx0XHRcdFx0cmV0dXJuIE9iamVjdC5rZXlzKGN1c3RvbVJlcGxhY2VtZW50cykuaW5kZXhPZihqLnRvTG93ZXJDYXNlKCkpIDwgMCA/IGogOiBqLnRvTG93ZXJDYXNlKCk7XG5cdFx0XHR9KTtcblx0XHRcdHJlc3VsdCA9IHJlc3VsdC5yZXBsYWNlKC9cXHMrL2csIHNlcGFyYXRvcikucmVwbGFjZShuZXcgUmVnRXhwKFwiXFxcXFwiICsgc2VwYXJhdG9yICsgXCIrXCIsIFwiZ1wiKSwgc2VwYXJhdG9yKS5yZXBsYWNlKG5ldyBSZWdFeHAoXCIoXlxcXFxcIiArIHNlcGFyYXRvciArIFwiK3xcXFxcXCIgKyBzZXBhcmF0b3IgKyBcIiskKVwiLCBcImdcIiksIFwiXCIpO1xuXHRcdFx0aWYgKHRydW5jYXRlICYmIHJlc3VsdC5sZW5ndGggPiB0cnVuY2F0ZSkge1xuXHRcdFx0XHRsdWNreSA9IHJlc3VsdC5jaGFyQXQodHJ1bmNhdGUpID09PSBzZXBhcmF0b3I7XG5cdFx0XHRcdHJlc3VsdCA9IHJlc3VsdC5zbGljZSgwLCB0cnVuY2F0ZSk7XG5cdFx0XHRcdGlmICghbHVja3kpIHJlc3VsdCA9IHJlc3VsdC5zbGljZSgwLCByZXN1bHQubGFzdEluZGV4T2Yoc2VwYXJhdG9yKSk7XG5cdFx0XHR9XG5cdFx0XHRpZiAoIW1haW50YWluQ2FzZSAmJiAhdGl0bGVDYXNlKSByZXN1bHQgPSByZXN1bHQudG9Mb3dlckNhc2UoKTtcblx0XHRcdHJldHVybiByZXN1bHQ7XG5cdFx0fTtcblx0XHQvKipcblx0XHQqIGNyZWF0ZVNsdWcgY3VycmllZChvcHRzKShpbnB1dClcblx0XHQqIEBwYXJhbSAgIHtvYmplY3R8c3RyaW5nfSBvcHRzIGNvbmZpZyBvYmplY3Qgb3IgaW5wdXQgc3RyaW5nXG5cdFx0KiBAcmV0dXJuICB7RnVuY3Rpb259IGZ1bmN0aW9uIGdldFNsdWdXaXRoQ29uZmlnKClcblx0XHQqKi9cblx0XHR2YXIgY3JlYXRlU2x1ZyA9IGZ1bmN0aW9uIGNyZWF0ZVNsdWcob3B0cykge1xuXHRcdFx0LyoqXG5cdFx0XHQqIGdldFNsdWdXaXRoQ29uZmlnXG5cdFx0XHQqIEBwYXJhbSAgIHtzdHJpbmd9IGlucHV0IHN0cmluZ1xuXHRcdFx0KiBAcmV0dXJuICB7c3RyaW5nfSBzbHVnIHN0cmluZ1xuXHRcdFx0Ki9cblx0XHRcdHJldHVybiBmdW5jdGlvbiBnZXRTbHVnV2l0aENvbmZpZyhpbnB1dCkge1xuXHRcdFx0XHRyZXR1cm4gZ2V0U2x1ZyhpbnB1dCwgb3B0cyk7XG5cdFx0XHR9O1xuXHRcdH07XG5cdFx0LyoqXG5cdFx0KiBlc2NhcGUgQ2hhcnNcblx0XHQqIEBwYXJhbSAgIHtzdHJpbmd9IGlucHV0IHN0cmluZ1xuXHRcdCovXG5cdFx0dmFyIGVzY2FwZUNoYXJzID0gZnVuY3Rpb24gZXNjYXBlQ2hhcnMoaW5wdXQpIHtcblx0XHRcdHJldHVybiBpbnB1dC5yZXBsYWNlKC9bLVxcXFxeJCorPy4oKXxbXFxde31cXC9dL2csIFwiXFxcXCQmXCIpO1xuXHRcdH07XG5cdFx0LyoqXG5cdFx0KiBjaGVjayBpZiB0aGUgY2hhciBpcyBhbiBhbHJlYWR5IGNvbnZlcnRlZCBjaGFyIGZyb20gY3VzdG9tIGxpc3Rcblx0XHQqIEBwYXJhbSAgIHtjaGFyfSBjaCBjaGFyYWN0ZXIgdG8gY2hlY2tcblx0XHQqIEBwYXJhbSAgIHtvYmplY3R9IGN1c3RvbVJlcGxhY2VtZW50cyBjdXN0b20gdHJhbnNsYXRpb24gbWFwXG5cdFx0Ki9cblx0XHR2YXIgaXNSZXBsYWNlZEN1c3RvbUNoYXIgPSBmdW5jdGlvbihjaCwgY3VzdG9tUmVwbGFjZW1lbnRzKSB7XG5cdFx0XHRmb3IgKHZhciBjIGluIGN1c3RvbVJlcGxhY2VtZW50cykgaWYgKGN1c3RvbVJlcGxhY2VtZW50c1tjXSA9PT0gY2gpIHJldHVybiB0cnVlO1xuXHRcdH07XG5cdFx0aWYgKHR5cGVvZiBtb2R1bGUgIT09IFwidW5kZWZpbmVkXCIgJiYgbW9kdWxlLmV4cG9ydHMpIHtcblx0XHRcdG1vZHVsZS5leHBvcnRzID0gZ2V0U2x1Zztcblx0XHRcdG1vZHVsZS5leHBvcnRzLmNyZWF0ZVNsdWcgPSBjcmVhdGVTbHVnO1xuXHRcdH0gZWxzZSBpZiAodHlwZW9mIGRlZmluZSAhPT0gXCJ1bmRlZmluZWRcIiAmJiBkZWZpbmUuYW1kKSBkZWZpbmUoW10sIGZ1bmN0aW9uKCkge1xuXHRcdFx0cmV0dXJuIGdldFNsdWc7XG5cdFx0fSk7XG5cdFx0ZWxzZSB0cnkge1xuXHRcdFx0aWYgKHJvb3QuZ2V0U2x1ZyB8fCByb290LmNyZWF0ZVNsdWcpIHRocm93IFwic3BlYWtpbmd1cmw6IGdsb2JhbHMgZXhpc3RzIC8oZ2V0U2x1Z3xjcmVhdGVTbHVnKS9cIjtcblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRyb290LmdldFNsdWcgPSBnZXRTbHVnO1xuXHRcdFx0XHRyb290LmNyZWF0ZVNsdWcgPSBjcmVhdGVTbHVnO1xuXHRcdFx0fVxuXHRcdH0gY2F0Y2ggKGUpIHt9XG5cdH0pKGV4cG9ydHMpO1xufSkpO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvYXBwL2luZGV4LnRzXG52YXIgaW1wb3J0X3NwZWFraW5ndXJsID0gLyogQF9fUFVSRV9fICovIF9fdG9FU00oKC8qIEBfX1BVUkVfXyAqLyBfX2NvbW1vbkpTTWluKCgoZXhwb3J0cywgbW9kdWxlKSA9PiB7XG5cdG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZV9zcGVha2luZ3VybCQxKCk7XG59KSkpKCksIDEpO1xuY29uc3QgYXBwUmVjb3JkSW5mbyA9IHRhcmdldC5fX1ZVRV9ERVZUT09MU19ORVhUX0FQUF9SRUNPUkRfSU5GT19fID8/PSB7XG5cdGlkOiAwLFxuXHRhcHBJZHM6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KClcbn07XG5mdW5jdGlvbiBnZXRBcHBSZWNvcmROYW1lKGFwcCwgZmFsbGJhY2tOYW1lKSB7XG5cdHJldHVybiBhcHA/Ll9jb21wb25lbnQ/Lm5hbWUgfHwgYEFwcCAke2ZhbGxiYWNrTmFtZX1gO1xufVxuZnVuY3Rpb24gZ2V0QXBwUm9vdEluc3RhbmNlKGFwcCkge1xuXHRpZiAoYXBwLl9pbnN0YW5jZSkgcmV0dXJuIGFwcC5faW5zdGFuY2U7XG5cdGVsc2UgaWYgKGFwcC5fY29udGFpbmVyPy5fdm5vZGU/LmNvbXBvbmVudCkgcmV0dXJuIGFwcC5fY29udGFpbmVyPy5fdm5vZGU/LmNvbXBvbmVudDtcbn1cbmZ1bmN0aW9uIHJlbW92ZUFwcFJlY29yZElkKGFwcCkge1xuXHRjb25zdCBpZCA9IGFwcC5fX1ZVRV9ERVZUT09MU19ORVhUX0FQUF9SRUNPUkRfSURfXztcblx0aWYgKGlkICE9IG51bGwpIHtcblx0XHRhcHBSZWNvcmRJbmZvLmFwcElkcy5kZWxldGUoaWQpO1xuXHRcdGFwcFJlY29yZEluZm8uaWQtLTtcblx0fVxufVxuZnVuY3Rpb24gZ2V0QXBwUmVjb3JkSWQoYXBwLCBkZWZhdWx0SWQpIHtcblx0aWYgKGFwcC5fX1ZVRV9ERVZUT09MU19ORVhUX0FQUF9SRUNPUkRfSURfXyAhPSBudWxsKSByZXR1cm4gYXBwLl9fVlVFX0RFVlRPT0xTX05FWFRfQVBQX1JFQ09SRF9JRF9fO1xuXHRsZXQgaWQgPSBkZWZhdWx0SWQgPz8gKGFwcFJlY29yZEluZm8uaWQrKykudG9TdHJpbmcoKTtcblx0aWYgKGRlZmF1bHRJZCAmJiBhcHBSZWNvcmRJbmZvLmFwcElkcy5oYXMoaWQpKSB7XG5cdFx0bGV0IGNvdW50ID0gMTtcblx0XHR3aGlsZSAoYXBwUmVjb3JkSW5mby5hcHBJZHMuaGFzKGAke2RlZmF1bHRJZH1fJHtjb3VudH1gKSkgY291bnQrKztcblx0XHRpZCA9IGAke2RlZmF1bHRJZH1fJHtjb3VudH1gO1xuXHR9XG5cdGFwcFJlY29yZEluZm8uYXBwSWRzLmFkZChpZCk7XG5cdGFwcC5fX1ZVRV9ERVZUT09MU19ORVhUX0FQUF9SRUNPUkRfSURfXyA9IGlkO1xuXHRyZXR1cm4gaWQ7XG59XG5mdW5jdGlvbiBjcmVhdGVBcHBSZWNvcmQoYXBwLCB0eXBlcykge1xuXHRjb25zdCByb290SW5zdGFuY2UgPSBnZXRBcHBSb290SW5zdGFuY2UoYXBwKTtcblx0aWYgKHJvb3RJbnN0YW5jZSkge1xuXHRcdGFwcFJlY29yZEluZm8uaWQrKztcblx0XHRjb25zdCBuYW1lID0gZ2V0QXBwUmVjb3JkTmFtZShhcHAsIGFwcFJlY29yZEluZm8uaWQudG9TdHJpbmcoKSk7XG5cdFx0Y29uc3QgaWQgPSBnZXRBcHBSZWNvcmRJZChhcHAsICgwLCBpbXBvcnRfc3BlYWtpbmd1cmwuZGVmYXVsdCkobmFtZSkpO1xuXHRcdGNvbnN0IFtlbF0gPSBnZXRSb290RWxlbWVudHNGcm9tQ29tcG9uZW50SW5zdGFuY2Uocm9vdEluc3RhbmNlKTtcblx0XHRjb25zdCByZWNvcmQgPSB7XG5cdFx0XHRpZCxcblx0XHRcdG5hbWUsXG5cdFx0XHR0eXBlcyxcblx0XHRcdGluc3RhbmNlTWFwOiAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpLFxuXHRcdFx0cGVyZkdyb3VwSWRzOiAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpLFxuXHRcdFx0cm9vdEluc3RhbmNlLFxuXHRcdFx0aWZyYW1lOiBpc0Jyb3dzZXIgJiYgZG9jdW1lbnQgIT09IGVsPy5vd25lckRvY3VtZW50ID8gZWw/Lm93bmVyRG9jdW1lbnQ/LmxvY2F0aW9uPy5wYXRobmFtZSA6IHZvaWQgMFxuXHRcdH07XG5cdFx0YXBwLl9fVlVFX0RFVlRPT0xTX05FWFRfQVBQX1JFQ09SRF9fID0gcmVjb3JkO1xuXHRcdGNvbnN0IHJvb3RJZCA9IGAke3JlY29yZC5pZH06cm9vdGA7XG5cdFx0cmVjb3JkLmluc3RhbmNlTWFwLnNldChyb290SWQsIHJlY29yZC5yb290SW5zdGFuY2UpO1xuXHRcdHJlY29yZC5yb290SW5zdGFuY2UuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXyA9IHJvb3RJZDtcblx0XHRyZXR1cm4gcmVjb3JkO1xuXHR9IGVsc2UgcmV0dXJuIHt9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvaWZyYW1lL2luZGV4LnRzXG5mdW5jdGlvbiBkZXRlY3RJZnJhbWVBcHAodGFyZ2V0LCBpbklmcmFtZSA9IGZhbHNlKSB7XG5cdGlmIChpbklmcmFtZSkge1xuXHRcdGZ1bmN0aW9uIHNlbmRFdmVudFRvUGFyZW50KGNiKSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBob29rID0gd2luZG93LnBhcmVudC5fX1ZVRV9ERVZUT09MU19HTE9CQUxfSE9PS19fO1xuXHRcdFx0XHRpZiAoaG9vaykgY2IoaG9vayk7XG5cdFx0XHR9IGNhdGNoIChlKSB7fVxuXHRcdH1cblx0XHRjb25zdCBob29rID0ge1xuXHRcdFx0aWQ6IFwidnVlLWRldnRvb2xzLW5leHRcIixcblx0XHRcdGRldnRvb2xzVmVyc2lvbjogXCI3LjBcIixcblx0XHRcdG9uOiAoZXZlbnQsIGNiKSA9PiB7XG5cdFx0XHRcdHNlbmRFdmVudFRvUGFyZW50KChob29rKSA9PiB7XG5cdFx0XHRcdFx0aG9vay5vbihldmVudCwgY2IpO1xuXHRcdFx0XHR9KTtcblx0XHRcdH0sXG5cdFx0XHRvbmNlOiAoZXZlbnQsIGNiKSA9PiB7XG5cdFx0XHRcdHNlbmRFdmVudFRvUGFyZW50KChob29rKSA9PiB7XG5cdFx0XHRcdFx0aG9vay5vbmNlKGV2ZW50LCBjYik7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fSxcblx0XHRcdG9mZjogKGV2ZW50LCBjYikgPT4ge1xuXHRcdFx0XHRzZW5kRXZlbnRUb1BhcmVudCgoaG9vaykgPT4ge1xuXHRcdFx0XHRcdGhvb2sub2ZmKGV2ZW50LCBjYik7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fSxcblx0XHRcdGVtaXQ6IChldmVudCwgLi4ucGF5bG9hZCkgPT4ge1xuXHRcdFx0XHRzZW5kRXZlbnRUb1BhcmVudCgoaG9vaykgPT4ge1xuXHRcdFx0XHRcdGhvb2suZW1pdChldmVudCwgLi4ucGF5bG9hZCk7XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdH07XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KHRhcmdldCwgXCJfX1ZVRV9ERVZUT09MU19HTE9CQUxfSE9PS19fXCIsIHtcblx0XHRcdGdldCgpIHtcblx0XHRcdFx0cmV0dXJuIGhvb2s7XG5cdFx0XHR9LFxuXHRcdFx0Y29uZmlndXJhYmxlOiB0cnVlXG5cdFx0fSk7XG5cdH1cblx0ZnVuY3Rpb24gaW5qZWN0VnVlSG9va1RvSWZyYW1lKGlmcmFtZSkge1xuXHRcdGlmIChpZnJhbWUuX192ZGV2dG9vbHNfX2luamVjdGVkKSByZXR1cm47XG5cdFx0dHJ5IHtcblx0XHRcdGlmcmFtZS5fX3ZkZXZ0b29sc19faW5qZWN0ZWQgPSB0cnVlO1xuXHRcdFx0Y29uc3QgaW5qZWN0ID0gKCkgPT4ge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGlmcmFtZS5jb250ZW50V2luZG93Ll9fVlVFX0RFVlRPT0xTX0lGUkFNRV9fID0gaWZyYW1lO1xuXHRcdFx0XHRcdGNvbnN0IHNjcmlwdCA9IGlmcmFtZS5jb250ZW50RG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNjcmlwdFwiKTtcblx0XHRcdFx0XHRzY3JpcHQudGV4dENvbnRlbnQgPSBgOygke2RldGVjdElmcmFtZUFwcC50b1N0cmluZygpfSkod2luZG93LCB0cnVlKWA7XG5cdFx0XHRcdFx0aWZyYW1lLmNvbnRlbnREb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuYXBwZW5kQ2hpbGQoc2NyaXB0KTtcblx0XHRcdFx0XHRzY3JpcHQucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChzY3JpcHQpO1xuXHRcdFx0XHR9IGNhdGNoIChlKSB7fVxuXHRcdFx0fTtcblx0XHRcdGluamVjdCgpO1xuXHRcdFx0aWZyYW1lLmFkZEV2ZW50TGlzdGVuZXIoXCJsb2FkXCIsICgpID0+IGluamVjdCgpKTtcblx0XHR9IGNhdGNoIChlKSB7fVxuXHR9XG5cdGZ1bmN0aW9uIGluamVjdFZ1ZUhvb2tUb0lmcmFtZXMoKSB7XG5cdFx0aWYgKHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybjtcblx0XHRjb25zdCBpZnJhbWVzID0gQXJyYXkuZnJvbShkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKFwiaWZyYW1lOm5vdChbZGF0YS12dWUtZGV2dG9vbHMtaWdub3JlXSlcIikpO1xuXHRcdGZvciAoY29uc3QgaWZyYW1lIG9mIGlmcmFtZXMpIGluamVjdFZ1ZUhvb2tUb0lmcmFtZShpZnJhbWUpO1xuXHR9XG5cdGluamVjdFZ1ZUhvb2tUb0lmcmFtZXMoKTtcblx0bGV0IGlmcmFtZUFwcENoZWNrcyA9IDA7XG5cdGNvbnN0IGlmcmFtZUFwcENoZWNrVGltZXIgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG5cdFx0aW5qZWN0VnVlSG9va1RvSWZyYW1lcygpO1xuXHRcdGlmcmFtZUFwcENoZWNrcysrO1xuXHRcdGlmIChpZnJhbWVBcHBDaGVja3MgPj0gNSkgY2xlYXJJbnRlcnZhbChpZnJhbWVBcHBDaGVja1RpbWVyKTtcblx0fSwgMWUzKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2luZGV4LnRzXG5mdW5jdGlvbiBpbml0RGV2VG9vbHMoKSB7XG5cdGRldGVjdElmcmFtZUFwcCh0YXJnZXQpO1xuXHR1cGRhdGVEZXZUb29sc1N0YXRlKHsgdml0ZVBsdWdpbkRldGVjdGVkOiBnZXREZXZUb29sc0VudigpLnZpdGVQbHVnaW5EZXRlY3RlZCB9KTtcblx0Y29uc3QgaXNEZXZUb29sc05leHQgPSB0YXJnZXQuX19WVUVfREVWVE9PTFNfR0xPQkFMX0hPT0tfXz8uaWQgPT09IFwidnVlLWRldnRvb2xzLW5leHRcIjtcblx0aWYgKHRhcmdldC5fX1ZVRV9ERVZUT09MU19HTE9CQUxfSE9PS19fICYmIGlzRGV2VG9vbHNOZXh0KSByZXR1cm47XG5cdGNvbnN0IF9kZXZ0b29sc0hvb2sgPSBjcmVhdGVEZXZUb29sc0hvb2soKTtcblx0aWYgKHRhcmdldC5fX1ZVRV9ERVZUT09MU19IT09LX1JFUExBWV9fKSB0cnkge1xuXHRcdHRhcmdldC5fX1ZVRV9ERVZUT09MU19IT09LX1JFUExBWV9fLmZvckVhY2goKGNiKSA9PiBjYihfZGV2dG9vbHNIb29rKSk7XG5cdFx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0hPT0tfUkVQTEFZX18gPSBbXTtcblx0fSBjYXRjaCAoZSkge1xuXHRcdGNvbnNvbGUuZXJyb3IoXCJbdnVlLWRldnRvb2xzXSBFcnJvciBkdXJpbmcgaG9vayByZXBsYXlcIiwgZSk7XG5cdH1cblx0X2RldnRvb2xzSG9vay5vbmNlKFwiaW5pdFwiLCAoVnVlKSA9PiB7XG5cdFx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX1ZVRTJfQVBQX0RFVEVDVEVEX18gPSB0cnVlO1xuXHRcdGNvbnNvbGUubG9nKFwiJWNbX19fX19WdWUgRGV2VG9vbHMgdjcgbG9nX19fX19dXCIsIFwiY29sb3I6IHJlZDsgZm9udC1ib2xkOiA2MDA7IGZvbnQtc2l6ZTogMTZweDtcIik7XG5cdFx0Y29uc29sZS5sb2coXCIlY1Z1ZSBEZXZUb29scyB2NyBkZXRlY3RlZCBpbiB5b3VyIFZ1ZTIgcHJvamVjdC4gdjcgb25seSBzdXBwb3J0cyBWdWUzIGFuZCB3aWxsIG5vdCB3b3JrLlwiLCBcImZvbnQtYm9sZDogNTAwOyBmb250LXNpemU6IDE0cHg7XCIpO1xuXHRcdGNvbnN0IGxlZ2FjeUNocm9tZVVybCA9IFwiaHR0cHM6Ly9jaHJvbWV3ZWJzdG9yZS5nb29nbGUuY29tL2RldGFpbC92dWVqcy1kZXZ0b29scy9pYWFqbWxjZXBsZWNibGppYWxoaGttZWRqbHBkYmxocFwiO1xuXHRcdGNvbnN0IGxlZ2FjeUZpcmVmb3hVcmwgPSBcImh0dHBzOi8vYWRkb25zLm1vemlsbGEub3JnL2ZpcmVmb3gvYWRkb24vdnVlLWpzLWRldnRvb2xzLXY2LWxlZ2FjeVwiO1xuXHRcdGNvbnNvbGUubG9nKGAlY1RoZSBsZWdhY3kgdmVyc2lvbiBvZiBjaHJvbWUgZXh0ZW5zaW9uIHRoYXQgc3VwcG9ydHMgYm90aCBWdWUgMiBhbmQgVnVlIDMgaGFzIGJlZW4gbW92ZWQgdG8gJWMgJHtsZWdhY3lDaHJvbWVVcmx9YCwgXCJmb250LXNpemU6IDE0cHg7XCIsIFwidGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7IGN1cnNvcjogcG9pbnRlcjtmb250LXNpemU6IDE0cHg7XCIpO1xuXHRcdGNvbnNvbGUubG9nKGAlY1RoZSBsZWdhY3kgdmVyc2lvbiBvZiBmaXJlZm94IGV4dGVuc2lvbiB0aGF0IHN1cHBvcnRzIGJvdGggVnVlIDIgYW5kIFZ1ZSAzIGhhcyBiZWVuIG1vdmVkIHRvICVjICR7bGVnYWN5RmlyZWZveFVybH1gLCBcImZvbnQtc2l6ZTogMTRweDtcIiwgXCJ0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTsgY3Vyc29yOiBwb2ludGVyO2ZvbnQtc2l6ZTogMTRweDtcIik7XG5cdFx0Y29uc29sZS5sb2coXCIlY1BsZWFzZSBpbnN0YWxsIGFuZCBlbmFibGUgb25seSB0aGUgbGVnYWN5IHZlcnNpb24gZm9yIHlvdXIgVnVlMiBhcHAuXCIsIFwiZm9udC1ib2xkOiA1MDA7IGZvbnQtc2l6ZTogMTRweDtcIik7XG5cdFx0Y29uc29sZS5sb2coXCIlY1tfX19fX1Z1ZSBEZXZUb29scyB2NyBsb2dfX19fX11cIiwgXCJjb2xvcjogcmVkOyBmb250LWJvbGQ6IDYwMDsgZm9udC1zaXplOiAxNnB4O1wiKTtcblx0fSk7XG5cdGhvb2sub24uc2V0dXBEZXZ0b29sc1BsdWdpbigocGx1Z2luRGVzY3JpcHRvciwgc2V0dXBGbikgPT4ge1xuXHRcdGFkZERldlRvb2xzUGx1Z2luVG9CdWZmZXIocGx1Z2luRGVzY3JpcHRvciwgc2V0dXBGbik7XG5cdFx0Y29uc3QgeyBhcHAgfSA9IGFjdGl2ZUFwcFJlY29yZCA/PyB7fTtcblx0XHRpZiAocGx1Z2luRGVzY3JpcHRvci5zZXR0aW5ncykgaW5pdFBsdWdpblNldHRpbmdzKHBsdWdpbkRlc2NyaXB0b3IuaWQsIHBsdWdpbkRlc2NyaXB0b3Iuc2V0dGluZ3MpO1xuXHRcdGlmICghYXBwKSByZXR1cm47XG5cdFx0Y2FsbERldlRvb2xzUGx1Z2luU2V0dXBGbihbcGx1Z2luRGVzY3JpcHRvciwgc2V0dXBGbl0sIGFwcCk7XG5cdH0pO1xuXHRvbkxlZ2FjeURldlRvb2xzUGx1Z2luQXBpQXZhaWxhYmxlKCgpID0+IHtcblx0XHRkZXZ0b29sc1BsdWdpbkJ1ZmZlci5maWx0ZXIoKFtpdGVtXSkgPT4gaXRlbS5pZCAhPT0gXCJjb21wb25lbnRzXCIpLmZvckVhY2goKFtwbHVnaW5EZXNjcmlwdG9yLCBzZXR1cEZuXSkgPT4ge1xuXHRcdFx0X2RldnRvb2xzSG9vay5lbWl0KERldlRvb2xzSG9va3MuU0VUVVBfREVWVE9PTFNfUExVR0lOLCBwbHVnaW5EZXNjcmlwdG9yLCBzZXR1cEZuLCB7IHRhcmdldDogXCJsZWdhY3lcIiB9KTtcblx0XHR9KTtcblx0fSk7XG5cdGhvb2sub24udnVlQXBwSW5pdChhc3luYyAoYXBwLCB2ZXJzaW9uLCB0eXBlcykgPT4ge1xuXHRcdGNvbnN0IG5vcm1hbGl6ZWRBcHBSZWNvcmQgPSB7XG5cdFx0XHQuLi5jcmVhdGVBcHBSZWNvcmQoYXBwLCB0eXBlcyksXG5cdFx0XHRhcHAsXG5cdFx0XHR2ZXJzaW9uXG5cdFx0fTtcblx0XHRhZGREZXZUb29sc0FwcFJlY29yZChub3JtYWxpemVkQXBwUmVjb3JkKTtcblx0XHRpZiAoZGV2dG9vbHNBcHBSZWNvcmRzLnZhbHVlLmxlbmd0aCA9PT0gMSkge1xuXHRcdFx0c2V0QWN0aXZlQXBwUmVjb3JkKG5vcm1hbGl6ZWRBcHBSZWNvcmQpO1xuXHRcdFx0c2V0QWN0aXZlQXBwUmVjb3JkSWQobm9ybWFsaXplZEFwcFJlY29yZC5pZCk7XG5cdFx0XHRub3JtYWxpemVSb3V0ZXJJbmZvKG5vcm1hbGl6ZWRBcHBSZWNvcmQsIGFjdGl2ZUFwcFJlY29yZCk7XG5cdFx0XHRyZWdpc3RlckRldlRvb2xzUGx1Z2luKG5vcm1hbGl6ZWRBcHBSZWNvcmQuYXBwKTtcblx0XHR9XG5cdFx0c2V0dXBEZXZUb29sc1BsdWdpbiguLi5jcmVhdGVDb21wb25lbnRzRGV2VG9vbHNQbHVnaW4obm9ybWFsaXplZEFwcFJlY29yZC5hcHApKTtcblx0XHR1cGRhdGVEZXZUb29sc1N0YXRlKHsgY29ubmVjdGVkOiB0cnVlIH0pO1xuXHRcdF9kZXZ0b29sc0hvb2suYXBwcy5wdXNoKGFwcCk7XG5cdH0pO1xuXHRob29rLm9uLnZ1ZUFwcFVubW91bnQoYXN5bmMgKGFwcCkgPT4ge1xuXHRcdGNvbnN0IGFjdGl2ZVJlY29yZHMgPSBkZXZ0b29sc0FwcFJlY29yZHMudmFsdWUuZmlsdGVyKChhcHBSZWNvcmQpID0+IGFwcFJlY29yZC5hcHAgIT09IGFwcCk7XG5cdFx0aWYgKGFjdGl2ZVJlY29yZHMubGVuZ3RoID09PSAwKSB1cGRhdGVEZXZUb29sc1N0YXRlKHsgY29ubmVjdGVkOiBmYWxzZSB9KTtcblx0XHRyZW1vdmVEZXZUb29sc0FwcFJlY29yZChhcHApO1xuXHRcdHJlbW92ZUFwcFJlY29yZElkKGFwcCk7XG5cdFx0aWYgKGFjdGl2ZUFwcFJlY29yZC52YWx1ZS5hcHAgPT09IGFwcCkge1xuXHRcdFx0c2V0QWN0aXZlQXBwUmVjb3JkKGFjdGl2ZVJlY29yZHNbMF0pO1xuXHRcdFx0ZGV2dG9vbHNDb250ZXh0Lmhvb2tzLmNhbGxIb29rKERldlRvb2xzTWVzc2FnaW5nSG9va0tleXMuU0VORF9BQ1RJVkVfQVBQX1VOTU9VTlRFRF9UT19DTElFTlQpO1xuXHRcdH1cblx0XHR0YXJnZXQuX19WVUVfREVWVE9PTFNfR0xPQkFMX0hPT0tfXy5hcHBzLnNwbGljZSh0YXJnZXQuX19WVUVfREVWVE9PTFNfR0xPQkFMX0hPT0tfXy5hcHBzLmluZGV4T2YoYXBwKSwgMSk7XG5cdFx0cmVtb3ZlUmVnaXN0ZXJlZFBsdWdpbkFwcChhcHApO1xuXHR9KTtcblx0c3Vic2NyaWJlRGV2VG9vbHNIb29rKF9kZXZ0b29sc0hvb2spO1xuXHRpZiAoIXRhcmdldC5fX1ZVRV9ERVZUT09MU19HTE9CQUxfSE9PS19fKSBPYmplY3QuZGVmaW5lUHJvcGVydHkodGFyZ2V0LCBcIl9fVlVFX0RFVlRPT0xTX0dMT0JBTF9IT09LX19cIiwge1xuXHRcdGdldCgpIHtcblx0XHRcdHJldHVybiBfZGV2dG9vbHNIb29rO1xuXHRcdH0sXG5cdFx0Y29uZmlndXJhYmxlOiB0cnVlXG5cdH0pO1xuXHRlbHNlIGlmICghaXNOdXh0QXBwKSBPYmplY3QuYXNzaWduKF9fVlVFX0RFVlRPT0xTX0dMT0JBTF9IT09LX18sIF9kZXZ0b29sc0hvb2spO1xufVxuZnVuY3Rpb24gb25EZXZUb29sc0NsaWVudENvbm5lY3RlZChmbikge1xuXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRpZiAoZGV2dG9vbHNTdGF0ZS5jb25uZWN0ZWQgJiYgZGV2dG9vbHNTdGF0ZS5jbGllbnRDb25uZWN0ZWQpIHtcblx0XHRcdGZuKCk7XG5cdFx0XHRyZXNvbHZlKCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGRldnRvb2xzQ29udGV4dC5ob29rcy5ob29rKERldlRvb2xzTWVzc2FnaW5nSG9va0tleXMuREVWVE9PTFNfQ09OTkVDVEVEX1VQREFURUQsICh7IHN0YXRlIH0pID0+IHtcblx0XHRcdGlmIChzdGF0ZS5jb25uZWN0ZWQgJiYgc3RhdGUuY2xpZW50Q29ubmVjdGVkKSB7XG5cdFx0XHRcdGZuKCk7XG5cdFx0XHRcdHJlc29sdmUoKTtcblx0XHRcdH1cblx0XHR9KTtcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9oaWdoLXBlcmYtbW9kZS9pbmRleC50c1xuZnVuY3Rpb24gdG9nZ2xlSGlnaFBlcmZNb2RlKHN0YXRlKSB7XG5cdGRldnRvb2xzU3RhdGUuaGlnaFBlcmZNb2RlRW5hYmxlZCA9IHN0YXRlID8/ICFkZXZ0b29sc1N0YXRlLmhpZ2hQZXJmTW9kZUVuYWJsZWQ7XG5cdGlmICghc3RhdGUgJiYgYWN0aXZlQXBwUmVjb3JkLnZhbHVlKSByZWdpc3RlckRldlRvb2xzUGx1Z2luKGFjdGl2ZUFwcFJlY29yZC52YWx1ZS5hcHApO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvY29tcG9uZW50L3N0YXRlL3Jldml2ZXIudHNcbmZ1bmN0aW9uIHJldml2ZVNldCh2YWwpIHtcblx0Y29uc3QgcmVzdWx0ID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0Y29uc3QgbGlzdCA9IHZhbC5fY3VzdG9tLnZhbHVlO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IGxpc3QubGVuZ3RoOyBpKyspIHtcblx0XHRjb25zdCB2YWx1ZSA9IGxpc3RbaV07XG5cdFx0cmVzdWx0LmFkZChyZXZpdmUodmFsdWUpKTtcblx0fVxuXHRyZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gcmV2aXZlTWFwKHZhbCkge1xuXHRjb25zdCByZXN1bHQgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRjb25zdCBsaXN0ID0gdmFsLl9jdXN0b20udmFsdWU7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgbGlzdC5sZW5ndGg7IGkrKykge1xuXHRcdGNvbnN0IHsga2V5LCB2YWx1ZSB9ID0gbGlzdFtpXTtcblx0XHRyZXN1bHQuc2V0KGtleSwgcmV2aXZlKHZhbHVlKSk7XG5cdH1cblx0cmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIHJldml2ZSh2YWwpIHtcblx0aWYgKHZhbCA9PT0gXCJfX3Z1ZV9kZXZ0b29sX3VuZGVmaW5lZF9fXCIpIHJldHVybjtcblx0ZWxzZSBpZiAodmFsID09PSBcIl9fdnVlX2RldnRvb2xfaW5maW5pdHlfX1wiKSByZXR1cm4gTnVtYmVyLlBPU0lUSVZFX0lORklOSVRZO1xuXHRlbHNlIGlmICh2YWwgPT09IFwiX192dWVfZGV2dG9vbF9uZWdhdGl2ZV9pbmZpbml0eV9fXCIpIHJldHVybiBOdW1iZXIuTkVHQVRJVkVfSU5GSU5JVFk7XG5cdGVsc2UgaWYgKHZhbCA9PT0gXCJfX3Z1ZV9kZXZ0b29sX25hbl9fXCIpIHJldHVybiBOYU47XG5cdGVsc2UgaWYgKHZhbCAmJiB2YWwuX2N1c3RvbSkge1xuXHRcdGNvbnN0IHsgX2N1c3RvbTogY3VzdG9tIH0gPSB2YWw7XG5cdFx0aWYgKGN1c3RvbS50eXBlID09PSBcImNvbXBvbmVudFwiKSByZXR1cm4gYWN0aXZlQXBwUmVjb3JkLnZhbHVlLmluc3RhbmNlTWFwLmdldChjdXN0b20uaWQpO1xuXHRcdGVsc2UgaWYgKGN1c3RvbS50eXBlID09PSBcIm1hcFwiKSByZXR1cm4gcmV2aXZlTWFwKHZhbCk7XG5cdFx0ZWxzZSBpZiAoY3VzdG9tLnR5cGUgPT09IFwic2V0XCIpIHJldHVybiByZXZpdmVTZXQodmFsKTtcblx0XHRlbHNlIGlmIChjdXN0b20udHlwZSA9PT0gXCJiaWdpbnRcIikgcmV0dXJuIEJpZ0ludChjdXN0b20udmFsdWUpO1xuXHRcdGVsc2UgcmV0dXJuIHJldml2ZShjdXN0b20udmFsdWUpO1xuXHR9IGVsc2UgaWYgKHN5bWJvbFJFLnRlc3QodmFsKSkge1xuXHRcdGNvbnN0IFssIHN0cmluZ10gPSBzeW1ib2xSRS5leGVjKHZhbCk7XG5cdFx0cmV0dXJuIFN5bWJvbC5mb3Ioc3RyaW5nKTtcblx0fSBlbHNlIGlmIChzcGVjaWFsVHlwZVJFLnRlc3QodmFsKSkge1xuXHRcdGNvbnN0IFssIHR5cGUsIHN0cmluZywgLCBkZXRhaWxzXSA9IHNwZWNpYWxUeXBlUkUuZXhlYyh2YWwpO1xuXHRcdGNvbnN0IHJlc3VsdCA9IG5ldyB0YXJnZXRbdHlwZV0oc3RyaW5nKTtcblx0XHRpZiAodHlwZSA9PT0gXCJFcnJvclwiICYmIGRldGFpbHMpIHJlc3VsdC5zdGFjayA9IGRldGFpbHM7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fSBlbHNlIHJldHVybiB2YWw7XG59XG5mdW5jdGlvbiByZXZpdmVyKGtleSwgdmFsdWUpIHtcblx0cmV0dXJuIHJldml2ZSh2YWx1ZSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvc3RhdGUvZm9ybWF0LnRzXG5mdW5jdGlvbiBnZXRJbnNwZWN0b3JTdGF0ZVZhbHVlVHlwZSh2YWx1ZSwgcmF3ID0gdHJ1ZSkge1xuXHRjb25zdCB0eXBlID0gdHlwZW9mIHZhbHVlO1xuXHRpZiAodmFsdWUgPT0gbnVsbCB8fCB2YWx1ZSA9PT0gXCJfX3Z1ZV9kZXZ0b29sX3VuZGVmaW5lZF9fXCIgfHwgdmFsdWUgPT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBcIm51bGxcIjtcblx0ZWxzZSBpZiAodHlwZSA9PT0gXCJib29sZWFuXCIgfHwgdHlwZSA9PT0gXCJudW1iZXJcIiB8fCB2YWx1ZSA9PT0gXCJfX3Z1ZV9kZXZ0b29sX2luZmluaXR5X19cIiB8fCB2YWx1ZSA9PT0gXCJfX3Z1ZV9kZXZ0b29sX25lZ2F0aXZlX2luZmluaXR5X19cIiB8fCB2YWx1ZSA9PT0gXCJfX3Z1ZV9kZXZ0b29sX25hbl9fXCIpIHJldHVybiBcImxpdGVyYWxcIjtcblx0ZWxzZSBpZiAodmFsdWU/Ll9jdXN0b20pIGlmIChyYXcgfHwgdmFsdWUuX2N1c3RvbS5kaXNwbGF5ICE9IG51bGwgfHwgdmFsdWUuX2N1c3RvbS5kaXNwbGF5VGV4dCAhPSBudWxsKSByZXR1cm4gXCJjdXN0b21cIjtcblx0ZWxzZSByZXR1cm4gZ2V0SW5zcGVjdG9yU3RhdGVWYWx1ZVR5cGUodmFsdWUuX2N1c3RvbS52YWx1ZSk7XG5cdGVsc2UgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIikge1xuXHRcdGNvbnN0IHR5cGVNYXRjaCA9IHNwZWNpYWxUeXBlUkUuZXhlYyh2YWx1ZSk7XG5cdFx0aWYgKHR5cGVNYXRjaCkge1xuXHRcdFx0Y29uc3QgWywgdHlwZV0gPSB0eXBlTWF0Y2g7XG5cdFx0XHRyZXR1cm4gYG5hdGl2ZSAke3R5cGV9YDtcblx0XHR9IGVsc2UgcmV0dXJuIFwic3RyaW5nXCI7XG5cdH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkgfHwgdmFsdWU/Ll9pc0FycmF5KSByZXR1cm4gXCJhcnJheVwiO1xuXHRlbHNlIGlmIChpc1BsYWluT2JqZWN0KHZhbHVlKSkgcmV0dXJuIFwicGxhaW4tb2JqZWN0XCI7XG5cdGVsc2UgcmV0dXJuIFwidW5rbm93blwiO1xufVxuZnVuY3Rpb24gZm9ybWF0SW5zcGVjdG9yU3RhdGVWYWx1ZSh2YWx1ZSwgcXVvdGVzID0gZmFsc2UsIG9wdGlvbnMpIHtcblx0Y29uc3QgeyBjdXN0b21DbGFzcyB9ID0gb3B0aW9ucyA/PyB7fTtcblx0bGV0IHJlc3VsdDtcblx0Y29uc3QgdHlwZSA9IGdldEluc3BlY3RvclN0YXRlVmFsdWVUeXBlKHZhbHVlLCBmYWxzZSk7XG5cdGlmICh0eXBlICE9PSBcImN1c3RvbVwiICYmIHZhbHVlPy5fY3VzdG9tKSB2YWx1ZSA9IHZhbHVlLl9jdXN0b20udmFsdWU7XG5cdGlmIChyZXN1bHQgPSBpbnRlcm5hbFN0YXRlVG9rZW5Ub1N0cmluZyh2YWx1ZSkpIHJldHVybiByZXN1bHQ7XG5cdGVsc2UgaWYgKHR5cGUgPT09IFwiY3VzdG9tXCIpIHJldHVybiB2YWx1ZS5fY3VzdG9tLnZhbHVlPy5fY3VzdG9tICYmIGZvcm1hdEluc3BlY3RvclN0YXRlVmFsdWUodmFsdWUuX2N1c3RvbS52YWx1ZSwgcXVvdGVzLCBvcHRpb25zKSB8fCB2YWx1ZS5fY3VzdG9tLmRpc3BsYXlUZXh0IHx8IHZhbHVlLl9jdXN0b20uZGlzcGxheTtcblx0ZWxzZSBpZiAodHlwZSA9PT0gXCJhcnJheVwiKSByZXR1cm4gYEFycmF5WyR7dmFsdWUubGVuZ3RofV1gO1xuXHRlbHNlIGlmICh0eXBlID09PSBcInBsYWluLW9iamVjdFwiKSByZXR1cm4gYE9iamVjdCR7T2JqZWN0LmtleXModmFsdWUpLmxlbmd0aCA/IFwiXCIgOiBcIiAoZW1wdHkpXCJ9YDtcblx0ZWxzZSBpZiAodHlwZT8uaW5jbHVkZXMoXCJuYXRpdmVcIikpIHJldHVybiBlc2NhcGUoc3BlY2lhbFR5cGVSRS5leGVjKHZhbHVlKT8uWzJdKTtcblx0ZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiKSB7XG5cdFx0Y29uc3QgdHlwZU1hdGNoID0gdmFsdWUubWF0Y2gocmF3VHlwZVJFKTtcblx0XHRpZiAodHlwZU1hdGNoKSB2YWx1ZSA9IGVzY2FwZVN0cmluZyh0eXBlTWF0Y2hbMV0pO1xuXHRcdGVsc2UgaWYgKHF1b3RlcykgdmFsdWUgPSBgPHNwYW4+XCI8L3NwYW4+JHtjdXN0b21DbGFzcz8uc3RyaW5nID8gYDxzcGFuIGNsYXNzPSR7Y3VzdG9tQ2xhc3Muc3RyaW5nfT4ke2VzY2FwZVN0cmluZyh2YWx1ZSl9PC9zcGFuPmAgOiBlc2NhcGVTdHJpbmcodmFsdWUpfTxzcGFuPlwiPC9zcGFuPmA7XG5cdFx0ZWxzZSB2YWx1ZSA9IGN1c3RvbUNsYXNzPy5zdHJpbmcgPyBgPHNwYW4gY2xhc3M9XCIke2N1c3RvbUNsYXNzPy5zdHJpbmcgPz8gXCJcIn1cIj4ke2VzY2FwZVN0cmluZyh2YWx1ZSl9PC9zcGFuPmAgOiBlc2NhcGVTdHJpbmcodmFsdWUpO1xuXHR9XG5cdHJldHVybiB2YWx1ZTtcbn1cbmZ1bmN0aW9uIGVzY2FwZVN0cmluZyh2YWx1ZSkge1xuXHRyZXR1cm4gZXNjYXBlKHZhbHVlKS5yZXBsYWNlKC8gL2csIFwiJm5ic3A7XCIpLnJlcGxhY2UoL1xcbi9nLCBcIjxzcGFuPlxcXFxuPC9zcGFuPlwiKTtcbn1cbmZ1bmN0aW9uIGdldFJhdyh2YWx1ZSkge1xuXHRsZXQgY3VzdG9tVHlwZTtcblx0Y29uc3QgaXNDdXN0b20gPSBnZXRJbnNwZWN0b3JTdGF0ZVZhbHVlVHlwZSh2YWx1ZSkgPT09IFwiY3VzdG9tXCI7XG5cdGxldCBpbmhlcml0ID0ge307XG5cdGlmIChpc0N1c3RvbSkge1xuXHRcdGNvbnN0IGRhdGEgPSB2YWx1ZTtcblx0XHRjb25zdCBjdXN0b21WYWx1ZSA9IGRhdGEuX2N1c3RvbT8udmFsdWU7XG5cdFx0Y29uc3QgY3VycmVudEN1c3RvbVR5cGUgPSBkYXRhLl9jdXN0b20/LnR5cGU7XG5cdFx0Y29uc3QgbmVzdGVkQ3VzdG9tID0gdHlwZW9mIGN1c3RvbVZhbHVlID09PSBcIm9iamVjdFwiICYmIGN1c3RvbVZhbHVlICE9PSBudWxsICYmIFwiX2N1c3RvbVwiIGluIGN1c3RvbVZhbHVlID8gZ2V0UmF3KGN1c3RvbVZhbHVlKSA6IHtcblx0XHRcdGluaGVyaXQ6IHZvaWQgMCxcblx0XHRcdHZhbHVlOiB2b2lkIDAsXG5cdFx0XHRjdXN0b21UeXBlOiB2b2lkIDBcblx0XHR9O1xuXHRcdGluaGVyaXQgPSBuZXN0ZWRDdXN0b20uaW5oZXJpdCB8fCBkYXRhLl9jdXN0b20/LmZpZWxkcyB8fCB7fTtcblx0XHR2YWx1ZSA9IG5lc3RlZEN1c3RvbS52YWx1ZSB8fCBjdXN0b21WYWx1ZTtcblx0XHRjdXN0b21UeXBlID0gbmVzdGVkQ3VzdG9tLmN1c3RvbVR5cGUgfHwgY3VycmVudEN1c3RvbVR5cGU7XG5cdH1cblx0aWYgKHZhbHVlICYmIHZhbHVlLl9pc0FycmF5KSB2YWx1ZSA9IHZhbHVlLml0ZW1zO1xuXHRyZXR1cm4ge1xuXHRcdHZhbHVlLFxuXHRcdGluaGVyaXQsXG5cdFx0Y3VzdG9tVHlwZVxuXHR9O1xufVxuZnVuY3Rpb24gdG9FZGl0KHZhbHVlLCBjdXN0b21UeXBlKSB7XG5cdGlmIChjdXN0b21UeXBlID09PSBcImJpZ2ludFwiKSByZXR1cm4gdmFsdWU7XG5cdGlmIChjdXN0b21UeXBlID09PSBcImRhdGVcIikgcmV0dXJuIHZhbHVlO1xuXHRyZXR1cm4gcmVwbGFjZVRva2VuVG9TdHJpbmcoSlNPTi5zdHJpbmdpZnkodmFsdWUpKTtcbn1cbmZ1bmN0aW9uIHRvU3VibWl0KHZhbHVlLCBjdXN0b21UeXBlKSB7XG5cdGlmIChjdXN0b21UeXBlID09PSBcImJpZ2ludFwiKSByZXR1cm4gQmlnSW50KHZhbHVlKTtcblx0aWYgKGN1c3RvbVR5cGUgPT09IFwiZGF0ZVwiKSByZXR1cm4gbmV3IERhdGUodmFsdWUpO1xuXHRyZXR1cm4gSlNPTi5wYXJzZShyZXBsYWNlU3RyaW5nVG9Ub2tlbih2YWx1ZSksIHJldml2ZXIpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvZGV2dG9vbHMtY2xpZW50L2RldGVjdGVkLnRzXG5mdW5jdGlvbiB1cGRhdGVEZXZUb29sc0NsaWVudERldGVjdGVkKHBhcmFtcykge1xuXHRkZXZ0b29sc1N0YXRlLmRldnRvb2xzQ2xpZW50RGV0ZWN0ZWQgPSB7XG5cdFx0Li4uZGV2dG9vbHNTdGF0ZS5kZXZ0b29sc0NsaWVudERldGVjdGVkLFxuXHRcdC4uLnBhcmFtc1xuXHR9O1xuXHR0b2dnbGVIaWdoUGVyZk1vZGUoIU9iamVjdC52YWx1ZXMoZGV2dG9vbHNTdGF0ZS5kZXZ0b29sc0NsaWVudERldGVjdGVkKS5zb21lKEJvb2xlYW4pKTtcbn1cbnRhcmdldC5fX1ZVRV9ERVZUT09MU19VUERBVEVfQ0xJRU5UX0RFVEVDVEVEX18gPz89IHVwZGF0ZURldlRvb2xzQ2xpZW50RGV0ZWN0ZWQ7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc3VwZXJqc29uQDIuMi4yL25vZGVfbW9kdWxlcy9zdXBlcmpzb24vZGlzdC9kb3VibGUtaW5kZXhlZC1rdi5qc1xudmFyIERvdWJsZUluZGV4ZWRLViA9IGNsYXNzIHtcblx0Y29uc3RydWN0b3IoKSB7XG5cdFx0dGhpcy5rZXlUb1ZhbHVlID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHR0aGlzLnZhbHVlVG9LZXkgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHR9XG5cdHNldChrZXksIHZhbHVlKSB7XG5cdFx0dGhpcy5rZXlUb1ZhbHVlLnNldChrZXksIHZhbHVlKTtcblx0XHR0aGlzLnZhbHVlVG9LZXkuc2V0KHZhbHVlLCBrZXkpO1xuXHR9XG5cdGdldEJ5S2V5KGtleSkge1xuXHRcdHJldHVybiB0aGlzLmtleVRvVmFsdWUuZ2V0KGtleSk7XG5cdH1cblx0Z2V0QnlWYWx1ZSh2YWx1ZSkge1xuXHRcdHJldHVybiB0aGlzLnZhbHVlVG9LZXkuZ2V0KHZhbHVlKTtcblx0fVxuXHRjbGVhcigpIHtcblx0XHR0aGlzLmtleVRvVmFsdWUuY2xlYXIoKTtcblx0XHR0aGlzLnZhbHVlVG9LZXkuY2xlYXIoKTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zdXBlcmpzb25AMi4yLjIvbm9kZV9tb2R1bGVzL3N1cGVyanNvbi9kaXN0L3JlZ2lzdHJ5LmpzXG52YXIgUmVnaXN0cnkgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKGdlbmVyYXRlSWRlbnRpZmllcikge1xuXHRcdHRoaXMuZ2VuZXJhdGVJZGVudGlmaWVyID0gZ2VuZXJhdGVJZGVudGlmaWVyO1xuXHRcdHRoaXMua3YgPSBuZXcgRG91YmxlSW5kZXhlZEtWKCk7XG5cdH1cblx0cmVnaXN0ZXIodmFsdWUsIGlkZW50aWZpZXIpIHtcblx0XHRpZiAodGhpcy5rdi5nZXRCeVZhbHVlKHZhbHVlKSkgcmV0dXJuO1xuXHRcdGlmICghaWRlbnRpZmllcikgaWRlbnRpZmllciA9IHRoaXMuZ2VuZXJhdGVJZGVudGlmaWVyKHZhbHVlKTtcblx0XHR0aGlzLmt2LnNldChpZGVudGlmaWVyLCB2YWx1ZSk7XG5cdH1cblx0Y2xlYXIoKSB7XG5cdFx0dGhpcy5rdi5jbGVhcigpO1xuXHR9XG5cdGdldElkZW50aWZpZXIodmFsdWUpIHtcblx0XHRyZXR1cm4gdGhpcy5rdi5nZXRCeVZhbHVlKHZhbHVlKTtcblx0fVxuXHRnZXRWYWx1ZShpZGVudGlmaWVyKSB7XG5cdFx0cmV0dXJuIHRoaXMua3YuZ2V0QnlLZXkoaWRlbnRpZmllcik7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc3VwZXJqc29uQDIuMi4yL25vZGVfbW9kdWxlcy9zdXBlcmpzb24vZGlzdC9jbGFzcy1yZWdpc3RyeS5qc1xudmFyIENsYXNzUmVnaXN0cnkgPSBjbGFzcyBleHRlbmRzIFJlZ2lzdHJ5IHtcblx0Y29uc3RydWN0b3IoKSB7XG5cdFx0c3VwZXIoKGMpID0+IGMubmFtZSk7XG5cdFx0dGhpcy5jbGFzc1RvQWxsb3dlZFByb3BzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0fVxuXHRyZWdpc3Rlcih2YWx1ZSwgb3B0aW9ucykge1xuXHRcdGlmICh0eXBlb2Ygb3B0aW9ucyA9PT0gXCJvYmplY3RcIikge1xuXHRcdFx0aWYgKG9wdGlvbnMuYWxsb3dQcm9wcykgdGhpcy5jbGFzc1RvQWxsb3dlZFByb3BzLnNldCh2YWx1ZSwgb3B0aW9ucy5hbGxvd1Byb3BzKTtcblx0XHRcdHN1cGVyLnJlZ2lzdGVyKHZhbHVlLCBvcHRpb25zLmlkZW50aWZpZXIpO1xuXHRcdH0gZWxzZSBzdXBlci5yZWdpc3Rlcih2YWx1ZSwgb3B0aW9ucyk7XG5cdH1cblx0Z2V0QWxsb3dlZFByb3BzKHZhbHVlKSB7XG5cdFx0cmV0dXJuIHRoaXMuY2xhc3NUb0FsbG93ZWRQcm9wcy5nZXQodmFsdWUpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3N1cGVyanNvbkAyLjIuMi9ub2RlX21vZHVsZXMvc3VwZXJqc29uL2Rpc3QvdXRpbC5qc1xuZnVuY3Rpb24gdmFsdWVzT2ZPYmoocmVjb3JkKSB7XG5cdGlmIChcInZhbHVlc1wiIGluIE9iamVjdCkgcmV0dXJuIE9iamVjdC52YWx1ZXMocmVjb3JkKTtcblx0Y29uc3QgdmFsdWVzID0gW107XG5cdGZvciAoY29uc3Qga2V5IGluIHJlY29yZCkgaWYgKHJlY29yZC5oYXNPd25Qcm9wZXJ0eShrZXkpKSB2YWx1ZXMucHVzaChyZWNvcmRba2V5XSk7XG5cdHJldHVybiB2YWx1ZXM7XG59XG5mdW5jdGlvbiBmaW5kKHJlY29yZCwgcHJlZGljYXRlKSB7XG5cdGNvbnN0IHZhbHVlcyA9IHZhbHVlc09mT2JqKHJlY29yZCk7XG5cdGlmIChcImZpbmRcIiBpbiB2YWx1ZXMpIHJldHVybiB2YWx1ZXMuZmluZChwcmVkaWNhdGUpO1xuXHRjb25zdCB2YWx1ZXNOb3ROZXZlciA9IHZhbHVlcztcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCB2YWx1ZXNOb3ROZXZlci5sZW5ndGg7IGkrKykge1xuXHRcdGNvbnN0IHZhbHVlID0gdmFsdWVzTm90TmV2ZXJbaV07XG5cdFx0aWYgKHByZWRpY2F0ZSh2YWx1ZSkpIHJldHVybiB2YWx1ZTtcblx0fVxufVxuZnVuY3Rpb24gZm9yRWFjaChyZWNvcmQsIHJ1bikge1xuXHRPYmplY3QuZW50cmllcyhyZWNvcmQpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT4gcnVuKHZhbHVlLCBrZXkpKTtcbn1cbmZ1bmN0aW9uIGluY2x1ZGVzKGFyciwgdmFsdWUpIHtcblx0cmV0dXJuIGFyci5pbmRleE9mKHZhbHVlKSAhPT0gLTE7XG59XG5mdW5jdGlvbiBmaW5kQXJyKHJlY29yZCwgcHJlZGljYXRlKSB7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgcmVjb3JkLmxlbmd0aDsgaSsrKSB7XG5cdFx0Y29uc3QgdmFsdWUgPSByZWNvcmRbaV07XG5cdFx0aWYgKHByZWRpY2F0ZSh2YWx1ZSkpIHJldHVybiB2YWx1ZTtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3N1cGVyanNvbkAyLjIuMi9ub2RlX21vZHVsZXMvc3VwZXJqc29uL2Rpc3QvY3VzdG9tLXRyYW5zZm9ybWVyLXJlZ2lzdHJ5LmpzXG52YXIgQ3VzdG9tVHJhbnNmb3JtZXJSZWdpc3RyeSA9IGNsYXNzIHtcblx0Y29uc3RydWN0b3IoKSB7XG5cdFx0dGhpcy50cmFuc2ZvbWVycyA9IHt9O1xuXHR9XG5cdHJlZ2lzdGVyKHRyYW5zZm9ybWVyKSB7XG5cdFx0dGhpcy50cmFuc2ZvbWVyc1t0cmFuc2Zvcm1lci5uYW1lXSA9IHRyYW5zZm9ybWVyO1xuXHR9XG5cdGZpbmRBcHBsaWNhYmxlKHYpIHtcblx0XHRyZXR1cm4gZmluZCh0aGlzLnRyYW5zZm9tZXJzLCAodHJhbnNmb3JtZXIpID0+IHRyYW5zZm9ybWVyLmlzQXBwbGljYWJsZSh2KSk7XG5cdH1cblx0ZmluZEJ5TmFtZShuYW1lKSB7XG5cdFx0cmV0dXJuIHRoaXMudHJhbnNmb21lcnNbbmFtZV07XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc3VwZXJqc29uQDIuMi4yL25vZGVfbW9kdWxlcy9zdXBlcmpzb24vZGlzdC9pcy5qc1xuY29uc3QgZ2V0VHlwZSQxID0gKHBheWxvYWQpID0+IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChwYXlsb2FkKS5zbGljZSg4LCAtMSk7XG5jb25zdCBpc1VuZGVmaW5lZCQxID0gKHBheWxvYWQpID0+IHR5cGVvZiBwYXlsb2FkID09PSBcInVuZGVmaW5lZFwiO1xuY29uc3QgaXNOdWxsJDEgPSAocGF5bG9hZCkgPT4gcGF5bG9hZCA9PT0gbnVsbDtcbmNvbnN0IGlzUGxhaW5PYmplY3QkMiA9IChwYXlsb2FkKSA9PiB7XG5cdGlmICh0eXBlb2YgcGF5bG9hZCAhPT0gXCJvYmplY3RcIiB8fCBwYXlsb2FkID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG5cdGlmIChwYXlsb2FkID09PSBPYmplY3QucHJvdG90eXBlKSByZXR1cm4gZmFsc2U7XG5cdGlmIChPYmplY3QuZ2V0UHJvdG90eXBlT2YocGF5bG9hZCkgPT09IG51bGwpIHJldHVybiB0cnVlO1xuXHRyZXR1cm4gT2JqZWN0LmdldFByb3RvdHlwZU9mKHBheWxvYWQpID09PSBPYmplY3QucHJvdG90eXBlO1xufTtcbmNvbnN0IGlzRW1wdHlPYmplY3QgPSAocGF5bG9hZCkgPT4gaXNQbGFpbk9iamVjdCQyKHBheWxvYWQpICYmIE9iamVjdC5rZXlzKHBheWxvYWQpLmxlbmd0aCA9PT0gMDtcbmNvbnN0IGlzQXJyYXkkMiA9IChwYXlsb2FkKSA9PiBBcnJheS5pc0FycmF5KHBheWxvYWQpO1xuY29uc3QgaXNTdHJpbmcgPSAocGF5bG9hZCkgPT4gdHlwZW9mIHBheWxvYWQgPT09IFwic3RyaW5nXCI7XG5jb25zdCBpc051bWJlciA9IChwYXlsb2FkKSA9PiB0eXBlb2YgcGF5bG9hZCA9PT0gXCJudW1iZXJcIiAmJiAhaXNOYU4ocGF5bG9hZCk7XG5jb25zdCBpc0Jvb2xlYW4gPSAocGF5bG9hZCkgPT4gdHlwZW9mIHBheWxvYWQgPT09IFwiYm9vbGVhblwiO1xuY29uc3QgaXNSZWdFeHAgPSAocGF5bG9hZCkgPT4gcGF5bG9hZCBpbnN0YW5jZW9mIFJlZ0V4cDtcbmNvbnN0IGlzTWFwID0gKHBheWxvYWQpID0+IHBheWxvYWQgaW5zdGFuY2VvZiBNYXA7XG5jb25zdCBpc1NldCA9IChwYXlsb2FkKSA9PiBwYXlsb2FkIGluc3RhbmNlb2YgU2V0O1xuY29uc3QgaXNTeW1ib2wgPSAocGF5bG9hZCkgPT4gZ2V0VHlwZSQxKHBheWxvYWQpID09PSBcIlN5bWJvbFwiO1xuY29uc3QgaXNEYXRlID0gKHBheWxvYWQpID0+IHBheWxvYWQgaW5zdGFuY2VvZiBEYXRlICYmICFpc05hTihwYXlsb2FkLnZhbHVlT2YoKSk7XG5jb25zdCBpc0Vycm9yID0gKHBheWxvYWQpID0+IHBheWxvYWQgaW5zdGFuY2VvZiBFcnJvcjtcbmNvbnN0IGlzTmFOVmFsdWUgPSAocGF5bG9hZCkgPT4gdHlwZW9mIHBheWxvYWQgPT09IFwibnVtYmVyXCIgJiYgaXNOYU4ocGF5bG9hZCk7XG5jb25zdCBpc1ByaW1pdGl2ZSA9IChwYXlsb2FkKSA9PiBpc0Jvb2xlYW4ocGF5bG9hZCkgfHwgaXNOdWxsJDEocGF5bG9hZCkgfHwgaXNVbmRlZmluZWQkMShwYXlsb2FkKSB8fCBpc051bWJlcihwYXlsb2FkKSB8fCBpc1N0cmluZyhwYXlsb2FkKSB8fCBpc1N5bWJvbChwYXlsb2FkKTtcbmNvbnN0IGlzQmlnaW50ID0gKHBheWxvYWQpID0+IHR5cGVvZiBwYXlsb2FkID09PSBcImJpZ2ludFwiO1xuY29uc3QgaXNJbmZpbml0ZSA9IChwYXlsb2FkKSA9PiBwYXlsb2FkID09PSBJbmZpbml0eSB8fCBwYXlsb2FkID09PSAtSW5maW5pdHk7XG5jb25zdCBpc1R5cGVkQXJyYXkgPSAocGF5bG9hZCkgPT4gQXJyYXlCdWZmZXIuaXNWaWV3KHBheWxvYWQpICYmICEocGF5bG9hZCBpbnN0YW5jZW9mIERhdGFWaWV3KTtcbmNvbnN0IGlzVVJMID0gKHBheWxvYWQpID0+IHBheWxvYWQgaW5zdGFuY2VvZiBVUkw7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiAuLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vc3VwZXJqc29uQDIuMi4yL25vZGVfbW9kdWxlcy9zdXBlcmpzb24vZGlzdC9wYXRoc3RyaW5naWZpZXIuanNcbmNvbnN0IGVzY2FwZUtleSA9IChrZXkpID0+IGtleS5yZXBsYWNlKC9cXC4vZywgXCJcXFxcLlwiKTtcbmNvbnN0IHN0cmluZ2lmeVBhdGggPSAocGF0aCkgPT4gcGF0aC5tYXAoU3RyaW5nKS5tYXAoZXNjYXBlS2V5KS5qb2luKFwiLlwiKTtcbmNvbnN0IHBhcnNlUGF0aCA9IChzdHJpbmcpID0+IHtcblx0Y29uc3QgcmVzdWx0ID0gW107XG5cdGxldCBzZWdtZW50ID0gXCJcIjtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBzdHJpbmcubGVuZ3RoOyBpKyspIHtcblx0XHRsZXQgY2hhciA9IHN0cmluZy5jaGFyQXQoaSk7XG5cdFx0aWYgKGNoYXIgPT09IFwiXFxcXFwiICYmIHN0cmluZy5jaGFyQXQoaSArIDEpID09PSBcIi5cIikge1xuXHRcdFx0c2VnbWVudCArPSBcIi5cIjtcblx0XHRcdGkrKztcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHRpZiAoY2hhciA9PT0gXCIuXCIpIHtcblx0XHRcdHJlc3VsdC5wdXNoKHNlZ21lbnQpO1xuXHRcdFx0c2VnbWVudCA9IFwiXCI7XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0c2VnbWVudCArPSBjaGFyO1xuXHR9XG5cdGNvbnN0IGxhc3RTZWdtZW50ID0gc2VnbWVudDtcblx0cmVzdWx0LnB1c2gobGFzdFNlZ21lbnQpO1xuXHRyZXR1cm4gcmVzdWx0O1xufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zdXBlcmpzb25AMi4yLjIvbm9kZV9tb2R1bGVzL3N1cGVyanNvbi9kaXN0L3RyYW5zZm9ybWVyLmpzXG5mdW5jdGlvbiBzaW1wbGVUcmFuc2Zvcm1hdGlvbihpc0FwcGxpY2FibGUsIGFubm90YXRpb24sIHRyYW5zZm9ybSwgdW50cmFuc2Zvcm0pIHtcblx0cmV0dXJuIHtcblx0XHRpc0FwcGxpY2FibGUsXG5cdFx0YW5ub3RhdGlvbixcblx0XHR0cmFuc2Zvcm0sXG5cdFx0dW50cmFuc2Zvcm1cblx0fTtcbn1cbmNvbnN0IHNpbXBsZVJ1bGVzID0gW1xuXHRzaW1wbGVUcmFuc2Zvcm1hdGlvbihpc1VuZGVmaW5lZCQxLCBcInVuZGVmaW5lZFwiLCAoKSA9PiBudWxsLCAoKSA9PiB2b2lkIDApLFxuXHRzaW1wbGVUcmFuc2Zvcm1hdGlvbihpc0JpZ2ludCwgXCJiaWdpbnRcIiwgKHYpID0+IHYudG9TdHJpbmcoKSwgKHYpID0+IHtcblx0XHRpZiAodHlwZW9mIEJpZ0ludCAhPT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIEJpZ0ludCh2KTtcblx0XHRjb25zb2xlLmVycm9yKFwiUGxlYXNlIGFkZCBhIEJpZ0ludCBwb2x5ZmlsbC5cIik7XG5cdFx0cmV0dXJuIHY7XG5cdH0pLFxuXHRzaW1wbGVUcmFuc2Zvcm1hdGlvbihpc0RhdGUsIFwiRGF0ZVwiLCAodikgPT4gdi50b0lTT1N0cmluZygpLCAodikgPT4gbmV3IERhdGUodikpLFxuXHRzaW1wbGVUcmFuc2Zvcm1hdGlvbihpc0Vycm9yLCBcIkVycm9yXCIsICh2LCBzdXBlckpzb24pID0+IHtcblx0XHRjb25zdCBiYXNlRXJyb3IgPSB7XG5cdFx0XHRuYW1lOiB2Lm5hbWUsXG5cdFx0XHRtZXNzYWdlOiB2Lm1lc3NhZ2Vcblx0XHR9O1xuXHRcdHN1cGVySnNvbi5hbGxvd2VkRXJyb3JQcm9wcy5mb3JFYWNoKChwcm9wKSA9PiB7XG5cdFx0XHRiYXNlRXJyb3JbcHJvcF0gPSB2W3Byb3BdO1xuXHRcdH0pO1xuXHRcdHJldHVybiBiYXNlRXJyb3I7XG5cdH0sICh2LCBzdXBlckpzb24pID0+IHtcblx0XHRjb25zdCBlID0gbmV3IEVycm9yKHYubWVzc2FnZSk7XG5cdFx0ZS5uYW1lID0gdi5uYW1lO1xuXHRcdGUuc3RhY2sgPSB2LnN0YWNrO1xuXHRcdHN1cGVySnNvbi5hbGxvd2VkRXJyb3JQcm9wcy5mb3JFYWNoKChwcm9wKSA9PiB7XG5cdFx0XHRlW3Byb3BdID0gdltwcm9wXTtcblx0XHR9KTtcblx0XHRyZXR1cm4gZTtcblx0fSksXG5cdHNpbXBsZVRyYW5zZm9ybWF0aW9uKGlzUmVnRXhwLCBcInJlZ2V4cFwiLCAodikgPT4gXCJcIiArIHYsIChyZWdleCkgPT4ge1xuXHRcdGNvbnN0IGJvZHkgPSByZWdleC5zbGljZSgxLCByZWdleC5sYXN0SW5kZXhPZihcIi9cIikpO1xuXHRcdGNvbnN0IGZsYWdzID0gcmVnZXguc2xpY2UocmVnZXgubGFzdEluZGV4T2YoXCIvXCIpICsgMSk7XG5cdFx0cmV0dXJuIG5ldyBSZWdFeHAoYm9keSwgZmxhZ3MpO1xuXHR9KSxcblx0c2ltcGxlVHJhbnNmb3JtYXRpb24oaXNTZXQsIFwic2V0XCIsICh2KSA9PiBbLi4udi52YWx1ZXMoKV0sICh2KSA9PiBuZXcgU2V0KHYpKSxcblx0c2ltcGxlVHJhbnNmb3JtYXRpb24oaXNNYXAsIFwibWFwXCIsICh2KSA9PiBbLi4udi5lbnRyaWVzKCldLCAodikgPT4gbmV3IE1hcCh2KSksXG5cdHNpbXBsZVRyYW5zZm9ybWF0aW9uKCh2KSA9PiBpc05hTlZhbHVlKHYpIHx8IGlzSW5maW5pdGUodiksIFwibnVtYmVyXCIsICh2KSA9PiB7XG5cdFx0aWYgKGlzTmFOVmFsdWUodikpIHJldHVybiBcIk5hTlwiO1xuXHRcdGlmICh2ID4gMCkgcmV0dXJuIFwiSW5maW5pdHlcIjtcblx0XHRlbHNlIHJldHVybiBcIi1JbmZpbml0eVwiO1xuXHR9LCBOdW1iZXIpLFxuXHRzaW1wbGVUcmFuc2Zvcm1hdGlvbigodikgPT4gdiA9PT0gMCAmJiAxIC8gdiA9PT0gLUluZmluaXR5LCBcIm51bWJlclwiLCAoKSA9PiB7XG5cdFx0cmV0dXJuIFwiLTBcIjtcblx0fSwgTnVtYmVyKSxcblx0c2ltcGxlVHJhbnNmb3JtYXRpb24oaXNVUkwsIFwiVVJMXCIsICh2KSA9PiB2LnRvU3RyaW5nKCksICh2KSA9PiBuZXcgVVJMKHYpKVxuXTtcbmZ1bmN0aW9uIGNvbXBvc2l0ZVRyYW5zZm9ybWF0aW9uKGlzQXBwbGljYWJsZSwgYW5ub3RhdGlvbiwgdHJhbnNmb3JtLCB1bnRyYW5zZm9ybSkge1xuXHRyZXR1cm4ge1xuXHRcdGlzQXBwbGljYWJsZSxcblx0XHRhbm5vdGF0aW9uLFxuXHRcdHRyYW5zZm9ybSxcblx0XHR1bnRyYW5zZm9ybVxuXHR9O1xufVxuY29uc3Qgc3ltYm9sUnVsZSA9IGNvbXBvc2l0ZVRyYW5zZm9ybWF0aW9uKChzLCBzdXBlckpzb24pID0+IHtcblx0aWYgKGlzU3ltYm9sKHMpKSByZXR1cm4gISFzdXBlckpzb24uc3ltYm9sUmVnaXN0cnkuZ2V0SWRlbnRpZmllcihzKTtcblx0cmV0dXJuIGZhbHNlO1xufSwgKHMsIHN1cGVySnNvbikgPT4ge1xuXHRyZXR1cm4gW1wic3ltYm9sXCIsIHN1cGVySnNvbi5zeW1ib2xSZWdpc3RyeS5nZXRJZGVudGlmaWVyKHMpXTtcbn0sICh2KSA9PiB2LmRlc2NyaXB0aW9uLCAoXywgYSwgc3VwZXJKc29uKSA9PiB7XG5cdGNvbnN0IHZhbHVlID0gc3VwZXJKc29uLnN5bWJvbFJlZ2lzdHJ5LmdldFZhbHVlKGFbMV0pO1xuXHRpZiAoIXZhbHVlKSB0aHJvdyBuZXcgRXJyb3IoXCJUcnlpbmcgdG8gZGVzZXJpYWxpemUgdW5rbm93biBzeW1ib2xcIik7XG5cdHJldHVybiB2YWx1ZTtcbn0pO1xuY29uc3QgY29uc3RydWN0b3JUb05hbWUgPSBbXG5cdEludDhBcnJheSxcblx0VWludDhBcnJheSxcblx0SW50MTZBcnJheSxcblx0VWludDE2QXJyYXksXG5cdEludDMyQXJyYXksXG5cdFVpbnQzMkFycmF5LFxuXHRGbG9hdDMyQXJyYXksXG5cdEZsb2F0NjRBcnJheSxcblx0VWludDhDbGFtcGVkQXJyYXlcbl0ucmVkdWNlKChvYmosIGN0b3IpID0+IHtcblx0b2JqW2N0b3IubmFtZV0gPSBjdG9yO1xuXHRyZXR1cm4gb2JqO1xufSwge30pO1xuY29uc3QgdHlwZWRBcnJheVJ1bGUgPSBjb21wb3NpdGVUcmFuc2Zvcm1hdGlvbihpc1R5cGVkQXJyYXksICh2KSA9PiBbXCJ0eXBlZC1hcnJheVwiLCB2LmNvbnN0cnVjdG9yLm5hbWVdLCAodikgPT4gWy4uLnZdLCAodiwgYSkgPT4ge1xuXHRjb25zdCBjdG9yID0gY29uc3RydWN0b3JUb05hbWVbYVsxXV07XG5cdGlmICghY3RvcikgdGhyb3cgbmV3IEVycm9yKFwiVHJ5aW5nIHRvIGRlc2VyaWFsaXplIHVua25vd24gdHlwZWQgYXJyYXlcIik7XG5cdHJldHVybiBuZXcgY3Rvcih2KTtcbn0pO1xuZnVuY3Rpb24gaXNJbnN0YW5jZU9mUmVnaXN0ZXJlZENsYXNzKHBvdGVudGlhbENsYXNzLCBzdXBlckpzb24pIHtcblx0aWYgKHBvdGVudGlhbENsYXNzPy5jb25zdHJ1Y3RvcikgcmV0dXJuICEhc3VwZXJKc29uLmNsYXNzUmVnaXN0cnkuZ2V0SWRlbnRpZmllcihwb3RlbnRpYWxDbGFzcy5jb25zdHJ1Y3Rvcik7XG5cdHJldHVybiBmYWxzZTtcbn1cbmNvbnN0IGNsYXNzUnVsZSA9IGNvbXBvc2l0ZVRyYW5zZm9ybWF0aW9uKGlzSW5zdGFuY2VPZlJlZ2lzdGVyZWRDbGFzcywgKGNsYXp6LCBzdXBlckpzb24pID0+IHtcblx0cmV0dXJuIFtcImNsYXNzXCIsIHN1cGVySnNvbi5jbGFzc1JlZ2lzdHJ5LmdldElkZW50aWZpZXIoY2xhenouY29uc3RydWN0b3IpXTtcbn0sIChjbGF6eiwgc3VwZXJKc29uKSA9PiB7XG5cdGNvbnN0IGFsbG93ZWRQcm9wcyA9IHN1cGVySnNvbi5jbGFzc1JlZ2lzdHJ5LmdldEFsbG93ZWRQcm9wcyhjbGF6ei5jb25zdHJ1Y3Rvcik7XG5cdGlmICghYWxsb3dlZFByb3BzKSByZXR1cm4geyAuLi5jbGF6eiB9O1xuXHRjb25zdCByZXN1bHQgPSB7fTtcblx0YWxsb3dlZFByb3BzLmZvckVhY2goKHByb3ApID0+IHtcblx0XHRyZXN1bHRbcHJvcF0gPSBjbGF6eltwcm9wXTtcblx0fSk7XG5cdHJldHVybiByZXN1bHQ7XG59LCAodiwgYSwgc3VwZXJKc29uKSA9PiB7XG5cdGNvbnN0IGNsYXp6ID0gc3VwZXJKc29uLmNsYXNzUmVnaXN0cnkuZ2V0VmFsdWUoYVsxXSk7XG5cdGlmICghY2xhenopIHRocm93IG5ldyBFcnJvcihgVHJ5aW5nIHRvIGRlc2VyaWFsaXplIHVua25vd24gY2xhc3MgJyR7YVsxXX0nIC0gY2hlY2sgaHR0cHM6Ly9naXRodWIuY29tL2JsaXR6LWpzL3N1cGVyanNvbi9pc3N1ZXMvMTE2I2lzc3VlY29tbWVudC03NzM5OTY1NjRgKTtcblx0cmV0dXJuIE9iamVjdC5hc3NpZ24oT2JqZWN0LmNyZWF0ZShjbGF6ei5wcm90b3R5cGUpLCB2KTtcbn0pO1xuY29uc3QgY3VzdG9tUnVsZSA9IGNvbXBvc2l0ZVRyYW5zZm9ybWF0aW9uKCh2YWx1ZSwgc3VwZXJKc29uKSA9PiB7XG5cdHJldHVybiAhIXN1cGVySnNvbi5jdXN0b21UcmFuc2Zvcm1lclJlZ2lzdHJ5LmZpbmRBcHBsaWNhYmxlKHZhbHVlKTtcbn0sICh2YWx1ZSwgc3VwZXJKc29uKSA9PiB7XG5cdHJldHVybiBbXCJjdXN0b21cIiwgc3VwZXJKc29uLmN1c3RvbVRyYW5zZm9ybWVyUmVnaXN0cnkuZmluZEFwcGxpY2FibGUodmFsdWUpLm5hbWVdO1xufSwgKHZhbHVlLCBzdXBlckpzb24pID0+IHtcblx0cmV0dXJuIHN1cGVySnNvbi5jdXN0b21UcmFuc2Zvcm1lclJlZ2lzdHJ5LmZpbmRBcHBsaWNhYmxlKHZhbHVlKS5zZXJpYWxpemUodmFsdWUpO1xufSwgKHYsIGEsIHN1cGVySnNvbikgPT4ge1xuXHRjb25zdCB0cmFuc2Zvcm1lciA9IHN1cGVySnNvbi5jdXN0b21UcmFuc2Zvcm1lclJlZ2lzdHJ5LmZpbmRCeU5hbWUoYVsxXSk7XG5cdGlmICghdHJhbnNmb3JtZXIpIHRocm93IG5ldyBFcnJvcihcIlRyeWluZyB0byBkZXNlcmlhbGl6ZSB1bmtub3duIGN1c3RvbSB2YWx1ZVwiKTtcblx0cmV0dXJuIHRyYW5zZm9ybWVyLmRlc2VyaWFsaXplKHYpO1xufSk7XG5jb25zdCBjb21wb3NpdGVSdWxlcyA9IFtcblx0Y2xhc3NSdWxlLFxuXHRzeW1ib2xSdWxlLFxuXHRjdXN0b21SdWxlLFxuXHR0eXBlZEFycmF5UnVsZVxuXTtcbmNvbnN0IHRyYW5zZm9ybVZhbHVlID0gKHZhbHVlLCBzdXBlckpzb24pID0+IHtcblx0Y29uc3QgYXBwbGljYWJsZUNvbXBvc2l0ZVJ1bGUgPSBmaW5kQXJyKGNvbXBvc2l0ZVJ1bGVzLCAocnVsZSkgPT4gcnVsZS5pc0FwcGxpY2FibGUodmFsdWUsIHN1cGVySnNvbikpO1xuXHRpZiAoYXBwbGljYWJsZUNvbXBvc2l0ZVJ1bGUpIHJldHVybiB7XG5cdFx0dmFsdWU6IGFwcGxpY2FibGVDb21wb3NpdGVSdWxlLnRyYW5zZm9ybSh2YWx1ZSwgc3VwZXJKc29uKSxcblx0XHR0eXBlOiBhcHBsaWNhYmxlQ29tcG9zaXRlUnVsZS5hbm5vdGF0aW9uKHZhbHVlLCBzdXBlckpzb24pXG5cdH07XG5cdGNvbnN0IGFwcGxpY2FibGVTaW1wbGVSdWxlID0gZmluZEFycihzaW1wbGVSdWxlcywgKHJ1bGUpID0+IHJ1bGUuaXNBcHBsaWNhYmxlKHZhbHVlLCBzdXBlckpzb24pKTtcblx0aWYgKGFwcGxpY2FibGVTaW1wbGVSdWxlKSByZXR1cm4ge1xuXHRcdHZhbHVlOiBhcHBsaWNhYmxlU2ltcGxlUnVsZS50cmFuc2Zvcm0odmFsdWUsIHN1cGVySnNvbiksXG5cdFx0dHlwZTogYXBwbGljYWJsZVNpbXBsZVJ1bGUuYW5ub3RhdGlvblxuXHR9O1xufTtcbmNvbnN0IHNpbXBsZVJ1bGVzQnlBbm5vdGF0aW9uID0ge307XG5zaW1wbGVSdWxlcy5mb3JFYWNoKChydWxlKSA9PiB7XG5cdHNpbXBsZVJ1bGVzQnlBbm5vdGF0aW9uW3J1bGUuYW5ub3RhdGlvbl0gPSBydWxlO1xufSk7XG5jb25zdCB1bnRyYW5zZm9ybVZhbHVlID0gKGpzb24sIHR5cGUsIHN1cGVySnNvbikgPT4ge1xuXHRpZiAoaXNBcnJheSQyKHR5cGUpKSBzd2l0Y2ggKHR5cGVbMF0pIHtcblx0XHRjYXNlIFwic3ltYm9sXCI6IHJldHVybiBzeW1ib2xSdWxlLnVudHJhbnNmb3JtKGpzb24sIHR5cGUsIHN1cGVySnNvbik7XG5cdFx0Y2FzZSBcImNsYXNzXCI6IHJldHVybiBjbGFzc1J1bGUudW50cmFuc2Zvcm0oanNvbiwgdHlwZSwgc3VwZXJKc29uKTtcblx0XHRjYXNlIFwiY3VzdG9tXCI6IHJldHVybiBjdXN0b21SdWxlLnVudHJhbnNmb3JtKGpzb24sIHR5cGUsIHN1cGVySnNvbik7XG5cdFx0Y2FzZSBcInR5cGVkLWFycmF5XCI6IHJldHVybiB0eXBlZEFycmF5UnVsZS51bnRyYW5zZm9ybShqc29uLCB0eXBlLCBzdXBlckpzb24pO1xuXHRcdGRlZmF1bHQ6IHRocm93IG5ldyBFcnJvcihcIlVua25vd24gdHJhbnNmb3JtYXRpb246IFwiICsgdHlwZSk7XG5cdH1cblx0ZWxzZSB7XG5cdFx0Y29uc3QgdHJhbnNmb3JtYXRpb24gPSBzaW1wbGVSdWxlc0J5QW5ub3RhdGlvblt0eXBlXTtcblx0XHRpZiAoIXRyYW5zZm9ybWF0aW9uKSB0aHJvdyBuZXcgRXJyb3IoXCJVbmtub3duIHRyYW5zZm9ybWF0aW9uOiBcIiArIHR5cGUpO1xuXHRcdHJldHVybiB0cmFuc2Zvcm1hdGlvbi51bnRyYW5zZm9ybShqc29uLCBzdXBlckpzb24pO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3N1cGVyanNvbkAyLjIuMi9ub2RlX21vZHVsZXMvc3VwZXJqc29uL2Rpc3QvYWNjZXNzRGVlcC5qc1xuY29uc3QgZ2V0TnRoS2V5ID0gKHZhbHVlLCBuKSA9PiB7XG5cdGlmIChuID4gdmFsdWUuc2l6ZSkgdGhyb3cgbmV3IEVycm9yKFwiaW5kZXggb3V0IG9mIGJvdW5kc1wiKTtcblx0Y29uc3Qga2V5cyA9IHZhbHVlLmtleXMoKTtcblx0d2hpbGUgKG4gPiAwKSB7XG5cdFx0a2V5cy5uZXh0KCk7XG5cdFx0bi0tO1xuXHR9XG5cdHJldHVybiBrZXlzLm5leHQoKS52YWx1ZTtcbn07XG5mdW5jdGlvbiB2YWxpZGF0ZVBhdGgocGF0aCkge1xuXHRpZiAoaW5jbHVkZXMocGF0aCwgXCJfX3Byb3RvX19cIikpIHRocm93IG5ldyBFcnJvcihcIl9fcHJvdG9fXyBpcyBub3QgYWxsb3dlZCBhcyBhIHByb3BlcnR5XCIpO1xuXHRpZiAoaW5jbHVkZXMocGF0aCwgXCJwcm90b3R5cGVcIikpIHRocm93IG5ldyBFcnJvcihcInByb3RvdHlwZSBpcyBub3QgYWxsb3dlZCBhcyBhIHByb3BlcnR5XCIpO1xuXHRpZiAoaW5jbHVkZXMocGF0aCwgXCJjb25zdHJ1Y3RvclwiKSkgdGhyb3cgbmV3IEVycm9yKFwiY29uc3RydWN0b3IgaXMgbm90IGFsbG93ZWQgYXMgYSBwcm9wZXJ0eVwiKTtcbn1cbmNvbnN0IGdldERlZXAgPSAob2JqZWN0LCBwYXRoKSA9PiB7XG5cdHZhbGlkYXRlUGF0aChwYXRoKTtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBwYXRoLmxlbmd0aDsgaSsrKSB7XG5cdFx0Y29uc3Qga2V5ID0gcGF0aFtpXTtcblx0XHRpZiAoaXNTZXQob2JqZWN0KSkgb2JqZWN0ID0gZ2V0TnRoS2V5KG9iamVjdCwgK2tleSk7XG5cdFx0ZWxzZSBpZiAoaXNNYXAob2JqZWN0KSkge1xuXHRcdFx0Y29uc3Qgcm93ID0gK2tleTtcblx0XHRcdGNvbnN0IHR5cGUgPSArcGF0aFsrK2ldID09PSAwID8gXCJrZXlcIiA6IFwidmFsdWVcIjtcblx0XHRcdGNvbnN0IGtleU9mUm93ID0gZ2V0TnRoS2V5KG9iamVjdCwgcm93KTtcblx0XHRcdHN3aXRjaCAodHlwZSkge1xuXHRcdFx0XHRjYXNlIFwia2V5XCI6XG5cdFx0XHRcdFx0b2JqZWN0ID0ga2V5T2ZSb3c7XG5cdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdGNhc2UgXCJ2YWx1ZVwiOlxuXHRcdFx0XHRcdG9iamVjdCA9IG9iamVjdC5nZXQoa2V5T2ZSb3cpO1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSBvYmplY3QgPSBvYmplY3Rba2V5XTtcblx0fVxuXHRyZXR1cm4gb2JqZWN0O1xufTtcbmNvbnN0IHNldERlZXAgPSAob2JqZWN0LCBwYXRoLCBtYXBwZXIpID0+IHtcblx0dmFsaWRhdGVQYXRoKHBhdGgpO1xuXHRpZiAocGF0aC5sZW5ndGggPT09IDApIHJldHVybiBtYXBwZXIob2JqZWN0KTtcblx0bGV0IHBhcmVudCA9IG9iamVjdDtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBwYXRoLmxlbmd0aCAtIDE7IGkrKykge1xuXHRcdGNvbnN0IGtleSA9IHBhdGhbaV07XG5cdFx0aWYgKGlzQXJyYXkkMihwYXJlbnQpKSB7XG5cdFx0XHRjb25zdCBpbmRleCA9ICtrZXk7XG5cdFx0XHRwYXJlbnQgPSBwYXJlbnRbaW5kZXhdO1xuXHRcdH0gZWxzZSBpZiAoaXNQbGFpbk9iamVjdCQyKHBhcmVudCkpIHBhcmVudCA9IHBhcmVudFtrZXldO1xuXHRcdGVsc2UgaWYgKGlzU2V0KHBhcmVudCkpIHtcblx0XHRcdGNvbnN0IHJvdyA9ICtrZXk7XG5cdFx0XHRwYXJlbnQgPSBnZXROdGhLZXkocGFyZW50LCByb3cpO1xuXHRcdH0gZWxzZSBpZiAoaXNNYXAocGFyZW50KSkge1xuXHRcdFx0aWYgKGkgPT09IHBhdGgubGVuZ3RoIC0gMikgYnJlYWs7XG5cdFx0XHRjb25zdCByb3cgPSAra2V5O1xuXHRcdFx0Y29uc3QgdHlwZSA9ICtwYXRoWysraV0gPT09IDAgPyBcImtleVwiIDogXCJ2YWx1ZVwiO1xuXHRcdFx0Y29uc3Qga2V5T2ZSb3cgPSBnZXROdGhLZXkocGFyZW50LCByb3cpO1xuXHRcdFx0c3dpdGNoICh0eXBlKSB7XG5cdFx0XHRcdGNhc2UgXCJrZXlcIjpcblx0XHRcdFx0XHRwYXJlbnQgPSBrZXlPZlJvdztcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0Y2FzZSBcInZhbHVlXCI6XG5cdFx0XHRcdFx0cGFyZW50ID0gcGFyZW50LmdldChrZXlPZlJvdyk7XG5cdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cdGNvbnN0IGxhc3RLZXkgPSBwYXRoW3BhdGgubGVuZ3RoIC0gMV07XG5cdGlmIChpc0FycmF5JDIocGFyZW50KSkgcGFyZW50WytsYXN0S2V5XSA9IG1hcHBlcihwYXJlbnRbK2xhc3RLZXldKTtcblx0ZWxzZSBpZiAoaXNQbGFpbk9iamVjdCQyKHBhcmVudCkpIHBhcmVudFtsYXN0S2V5XSA9IG1hcHBlcihwYXJlbnRbbGFzdEtleV0pO1xuXHRpZiAoaXNTZXQocGFyZW50KSkge1xuXHRcdGNvbnN0IG9sZFZhbHVlID0gZ2V0TnRoS2V5KHBhcmVudCwgK2xhc3RLZXkpO1xuXHRcdGNvbnN0IG5ld1ZhbHVlID0gbWFwcGVyKG9sZFZhbHVlKTtcblx0XHRpZiAob2xkVmFsdWUgIT09IG5ld1ZhbHVlKSB7XG5cdFx0XHRwYXJlbnQuZGVsZXRlKG9sZFZhbHVlKTtcblx0XHRcdHBhcmVudC5hZGQobmV3VmFsdWUpO1xuXHRcdH1cblx0fVxuXHRpZiAoaXNNYXAocGFyZW50KSkge1xuXHRcdGNvbnN0IHJvdyA9ICtwYXRoW3BhdGgubGVuZ3RoIC0gMl07XG5cdFx0Y29uc3Qga2V5VG9Sb3cgPSBnZXROdGhLZXkocGFyZW50LCByb3cpO1xuXHRcdHN3aXRjaCAoK2xhc3RLZXkgPT09IDAgPyBcImtleVwiIDogXCJ2YWx1ZVwiKSB7XG5cdFx0XHRjYXNlIFwia2V5XCI6IHtcblx0XHRcdFx0Y29uc3QgbmV3S2V5ID0gbWFwcGVyKGtleVRvUm93KTtcblx0XHRcdFx0cGFyZW50LnNldChuZXdLZXksIHBhcmVudC5nZXQoa2V5VG9Sb3cpKTtcblx0XHRcdFx0aWYgKG5ld0tleSAhPT0ga2V5VG9Sb3cpIHBhcmVudC5kZWxldGUoa2V5VG9Sb3cpO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdH1cblx0XHRcdGNhc2UgXCJ2YWx1ZVwiOlxuXHRcdFx0XHRwYXJlbnQuc2V0KGtleVRvUm93LCBtYXBwZXIocGFyZW50LmdldChrZXlUb1JvdykpKTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0fVxuXHR9XG5cdHJldHVybiBvYmplY3Q7XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3N1cGVyanNvbkAyLjIuMi9ub2RlX21vZHVsZXMvc3VwZXJqc29uL2Rpc3QvcGxhaW5lci5qc1xuZnVuY3Rpb24gdHJhdmVyc2UodHJlZSwgd2Fsa2VyLCBvcmlnaW4gPSBbXSkge1xuXHRpZiAoIXRyZWUpIHJldHVybjtcblx0aWYgKCFpc0FycmF5JDIodHJlZSkpIHtcblx0XHRmb3JFYWNoKHRyZWUsIChzdWJ0cmVlLCBrZXkpID0+IHRyYXZlcnNlKHN1YnRyZWUsIHdhbGtlciwgWy4uLm9yaWdpbiwgLi4ucGFyc2VQYXRoKGtleSldKSk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGNvbnN0IFtub2RlVmFsdWUsIGNoaWxkcmVuXSA9IHRyZWU7XG5cdGlmIChjaGlsZHJlbikgZm9yRWFjaChjaGlsZHJlbiwgKGNoaWxkLCBrZXkpID0+IHtcblx0XHR0cmF2ZXJzZShjaGlsZCwgd2Fsa2VyLCBbLi4ub3JpZ2luLCAuLi5wYXJzZVBhdGgoa2V5KV0pO1xuXHR9KTtcblx0d2Fsa2VyKG5vZGVWYWx1ZSwgb3JpZ2luKTtcbn1cbmZ1bmN0aW9uIGFwcGx5VmFsdWVBbm5vdGF0aW9ucyhwbGFpbiwgYW5ub3RhdGlvbnMsIHN1cGVySnNvbikge1xuXHR0cmF2ZXJzZShhbm5vdGF0aW9ucywgKHR5cGUsIHBhdGgpID0+IHtcblx0XHRwbGFpbiA9IHNldERlZXAocGxhaW4sIHBhdGgsICh2KSA9PiB1bnRyYW5zZm9ybVZhbHVlKHYsIHR5cGUsIHN1cGVySnNvbikpO1xuXHR9KTtcblx0cmV0dXJuIHBsYWluO1xufVxuZnVuY3Rpb24gYXBwbHlSZWZlcmVudGlhbEVxdWFsaXR5QW5ub3RhdGlvbnMocGxhaW4sIGFubm90YXRpb25zKSB7XG5cdGZ1bmN0aW9uIGFwcGx5KGlkZW50aWNhbFBhdGhzLCBwYXRoKSB7XG5cdFx0Y29uc3Qgb2JqZWN0ID0gZ2V0RGVlcChwbGFpbiwgcGFyc2VQYXRoKHBhdGgpKTtcblx0XHRpZGVudGljYWxQYXRocy5tYXAocGFyc2VQYXRoKS5mb3JFYWNoKChpZGVudGljYWxPYmplY3RQYXRoKSA9PiB7XG5cdFx0XHRwbGFpbiA9IHNldERlZXAocGxhaW4sIGlkZW50aWNhbE9iamVjdFBhdGgsICgpID0+IG9iamVjdCk7XG5cdFx0fSk7XG5cdH1cblx0aWYgKGlzQXJyYXkkMihhbm5vdGF0aW9ucykpIHtcblx0XHRjb25zdCBbcm9vdCwgb3RoZXJdID0gYW5ub3RhdGlvbnM7XG5cdFx0cm9vdC5mb3JFYWNoKChpZGVudGljYWxQYXRoKSA9PiB7XG5cdFx0XHRwbGFpbiA9IHNldERlZXAocGxhaW4sIHBhcnNlUGF0aChpZGVudGljYWxQYXRoKSwgKCkgPT4gcGxhaW4pO1xuXHRcdH0pO1xuXHRcdGlmIChvdGhlcikgZm9yRWFjaChvdGhlciwgYXBwbHkpO1xuXHR9IGVsc2UgZm9yRWFjaChhbm5vdGF0aW9ucywgYXBwbHkpO1xuXHRyZXR1cm4gcGxhaW47XG59XG5jb25zdCBpc0RlZXAgPSAob2JqZWN0LCBzdXBlckpzb24pID0+IGlzUGxhaW5PYmplY3QkMihvYmplY3QpIHx8IGlzQXJyYXkkMihvYmplY3QpIHx8IGlzTWFwKG9iamVjdCkgfHwgaXNTZXQob2JqZWN0KSB8fCBpc0luc3RhbmNlT2ZSZWdpc3RlcmVkQ2xhc3Mob2JqZWN0LCBzdXBlckpzb24pO1xuZnVuY3Rpb24gYWRkSWRlbnRpdHkob2JqZWN0LCBwYXRoLCBpZGVudGl0aWVzKSB7XG5cdGNvbnN0IGV4aXN0aW5nU2V0ID0gaWRlbnRpdGllcy5nZXQob2JqZWN0KTtcblx0aWYgKGV4aXN0aW5nU2V0KSBleGlzdGluZ1NldC5wdXNoKHBhdGgpO1xuXHRlbHNlIGlkZW50aXRpZXMuc2V0KG9iamVjdCwgW3BhdGhdKTtcbn1cbmZ1bmN0aW9uIGdlbmVyYXRlUmVmZXJlbnRpYWxFcXVhbGl0eUFubm90YXRpb25zKGlkZW50aXRpdGVzLCBkZWR1cGUpIHtcblx0Y29uc3QgcmVzdWx0ID0ge307XG5cdGxldCByb290RXF1YWxpdHlQYXRocyA9IHZvaWQgMDtcblx0aWRlbnRpdGl0ZXMuZm9yRWFjaCgocGF0aHMpID0+IHtcblx0XHRpZiAocGF0aHMubGVuZ3RoIDw9IDEpIHJldHVybjtcblx0XHRpZiAoIWRlZHVwZSkgcGF0aHMgPSBwYXRocy5tYXAoKHBhdGgpID0+IHBhdGgubWFwKFN0cmluZykpLnNvcnQoKGEsIGIpID0+IGEubGVuZ3RoIC0gYi5sZW5ndGgpO1xuXHRcdGNvbnN0IFtyZXByZXNlbnRhdGl2ZVBhdGgsIC4uLmlkZW50aWNhbFBhdGhzXSA9IHBhdGhzO1xuXHRcdGlmIChyZXByZXNlbnRhdGl2ZVBhdGgubGVuZ3RoID09PSAwKSByb290RXF1YWxpdHlQYXRocyA9IGlkZW50aWNhbFBhdGhzLm1hcChzdHJpbmdpZnlQYXRoKTtcblx0XHRlbHNlIHJlc3VsdFtzdHJpbmdpZnlQYXRoKHJlcHJlc2VudGF0aXZlUGF0aCldID0gaWRlbnRpY2FsUGF0aHMubWFwKHN0cmluZ2lmeVBhdGgpO1xuXHR9KTtcblx0aWYgKHJvb3RFcXVhbGl0eVBhdGhzKSBpZiAoaXNFbXB0eU9iamVjdChyZXN1bHQpKSByZXR1cm4gW3Jvb3RFcXVhbGl0eVBhdGhzXTtcblx0ZWxzZSByZXR1cm4gW3Jvb3RFcXVhbGl0eVBhdGhzLCByZXN1bHRdO1xuXHRlbHNlIHJldHVybiBpc0VtcHR5T2JqZWN0KHJlc3VsdCkgPyB2b2lkIDAgOiByZXN1bHQ7XG59XG5jb25zdCB3YWxrZXIgPSAob2JqZWN0LCBpZGVudGl0aWVzLCBzdXBlckpzb24sIGRlZHVwZSwgcGF0aCA9IFtdLCBvYmplY3RzSW5UaGlzUGF0aCA9IFtdLCBzZWVuT2JqZWN0cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCkpID0+IHtcblx0Y29uc3QgcHJpbWl0aXZlID0gaXNQcmltaXRpdmUob2JqZWN0KTtcblx0aWYgKCFwcmltaXRpdmUpIHtcblx0XHRhZGRJZGVudGl0eShvYmplY3QsIHBhdGgsIGlkZW50aXRpZXMpO1xuXHRcdGNvbnN0IHNlZW4gPSBzZWVuT2JqZWN0cy5nZXQob2JqZWN0KTtcblx0XHRpZiAoc2VlbikgcmV0dXJuIGRlZHVwZSA/IHsgdHJhbnNmb3JtZWRWYWx1ZTogbnVsbCB9IDogc2Vlbjtcblx0fVxuXHRpZiAoIWlzRGVlcChvYmplY3QsIHN1cGVySnNvbikpIHtcblx0XHRjb25zdCB0cmFuc2Zvcm1lZCA9IHRyYW5zZm9ybVZhbHVlKG9iamVjdCwgc3VwZXJKc29uKTtcblx0XHRjb25zdCByZXN1bHQgPSB0cmFuc2Zvcm1lZCA/IHtcblx0XHRcdHRyYW5zZm9ybWVkVmFsdWU6IHRyYW5zZm9ybWVkLnZhbHVlLFxuXHRcdFx0YW5ub3RhdGlvbnM6IFt0cmFuc2Zvcm1lZC50eXBlXVxuXHRcdH0gOiB7IHRyYW5zZm9ybWVkVmFsdWU6IG9iamVjdCB9O1xuXHRcdGlmICghcHJpbWl0aXZlKSBzZWVuT2JqZWN0cy5zZXQob2JqZWN0LCByZXN1bHQpO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH1cblx0aWYgKGluY2x1ZGVzKG9iamVjdHNJblRoaXNQYXRoLCBvYmplY3QpKSByZXR1cm4geyB0cmFuc2Zvcm1lZFZhbHVlOiBudWxsIH07XG5cdGNvbnN0IHRyYW5zZm9ybWF0aW9uUmVzdWx0ID0gdHJhbnNmb3JtVmFsdWUob2JqZWN0LCBzdXBlckpzb24pO1xuXHRjb25zdCB0cmFuc2Zvcm1lZCA9IHRyYW5zZm9ybWF0aW9uUmVzdWx0Py52YWx1ZSA/PyBvYmplY3Q7XG5cdGNvbnN0IHRyYW5zZm9ybWVkVmFsdWUgPSBpc0FycmF5JDIodHJhbnNmb3JtZWQpID8gW10gOiB7fTtcblx0Y29uc3QgaW5uZXJBbm5vdGF0aW9ucyA9IHt9O1xuXHRmb3JFYWNoKHRyYW5zZm9ybWVkLCAodmFsdWUsIGluZGV4KSA9PiB7XG5cdFx0aWYgKGluZGV4ID09PSBcIl9fcHJvdG9fX1wiIHx8IGluZGV4ID09PSBcImNvbnN0cnVjdG9yXCIgfHwgaW5kZXggPT09IFwicHJvdG90eXBlXCIpIHRocm93IG5ldyBFcnJvcihgRGV0ZWN0ZWQgcHJvcGVydHkgJHtpbmRleH0uIFRoaXMgaXMgYSBwcm90b3R5cGUgcG9sbHV0aW9uIHJpc2ssIHBsZWFzZSByZW1vdmUgaXQgZnJvbSB5b3VyIG9iamVjdC5gKTtcblx0XHRjb25zdCByZWN1cnNpdmVSZXN1bHQgPSB3YWxrZXIodmFsdWUsIGlkZW50aXRpZXMsIHN1cGVySnNvbiwgZGVkdXBlLCBbLi4ucGF0aCwgaW5kZXhdLCBbLi4ub2JqZWN0c0luVGhpc1BhdGgsIG9iamVjdF0sIHNlZW5PYmplY3RzKTtcblx0XHR0cmFuc2Zvcm1lZFZhbHVlW2luZGV4XSA9IHJlY3Vyc2l2ZVJlc3VsdC50cmFuc2Zvcm1lZFZhbHVlO1xuXHRcdGlmIChpc0FycmF5JDIocmVjdXJzaXZlUmVzdWx0LmFubm90YXRpb25zKSkgaW5uZXJBbm5vdGF0aW9uc1tpbmRleF0gPSByZWN1cnNpdmVSZXN1bHQuYW5ub3RhdGlvbnM7XG5cdFx0ZWxzZSBpZiAoaXNQbGFpbk9iamVjdCQyKHJlY3Vyc2l2ZVJlc3VsdC5hbm5vdGF0aW9ucykpIGZvckVhY2gocmVjdXJzaXZlUmVzdWx0LmFubm90YXRpb25zLCAodHJlZSwga2V5KSA9PiB7XG5cdFx0XHRpbm5lckFubm90YXRpb25zW2VzY2FwZUtleShpbmRleCkgKyBcIi5cIiArIGtleV0gPSB0cmVlO1xuXHRcdH0pO1xuXHR9KTtcblx0Y29uc3QgcmVzdWx0ID0gaXNFbXB0eU9iamVjdChpbm5lckFubm90YXRpb25zKSA/IHtcblx0XHR0cmFuc2Zvcm1lZFZhbHVlLFxuXHRcdGFubm90YXRpb25zOiAhIXRyYW5zZm9ybWF0aW9uUmVzdWx0ID8gW3RyYW5zZm9ybWF0aW9uUmVzdWx0LnR5cGVdIDogdm9pZCAwXG5cdH0gOiB7XG5cdFx0dHJhbnNmb3JtZWRWYWx1ZSxcblx0XHRhbm5vdGF0aW9uczogISF0cmFuc2Zvcm1hdGlvblJlc3VsdCA/IFt0cmFuc2Zvcm1hdGlvblJlc3VsdC50eXBlLCBpbm5lckFubm90YXRpb25zXSA6IGlubmVyQW5ub3RhdGlvbnNcblx0fTtcblx0aWYgKCFwcmltaXRpdmUpIHNlZW5PYmplY3RzLnNldChvYmplY3QsIHJlc3VsdCk7XG5cdHJldHVybiByZXN1bHQ7XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2lzLXdoYXRANC4xLjE2L25vZGVfbW9kdWxlcy9pcy13aGF0L2Rpc3QvaW5kZXguanNcbmZ1bmN0aW9uIGdldFR5cGUocGF5bG9hZCkge1xuXHRyZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHBheWxvYWQpLnNsaWNlKDgsIC0xKTtcbn1cbmZ1bmN0aW9uIGlzQXJyYXkkMShwYXlsb2FkKSB7XG5cdHJldHVybiBnZXRUeXBlKHBheWxvYWQpID09PSBcIkFycmF5XCI7XG59XG5mdW5jdGlvbiBpc1BsYWluT2JqZWN0JDEocGF5bG9hZCkge1xuXHRpZiAoZ2V0VHlwZShwYXlsb2FkKSAhPT0gXCJPYmplY3RcIikgcmV0dXJuIGZhbHNlO1xuXHRjb25zdCBwcm90b3R5cGUgPSBPYmplY3QuZ2V0UHJvdG90eXBlT2YocGF5bG9hZCk7XG5cdHJldHVybiAhIXByb3RvdHlwZSAmJiBwcm90b3R5cGUuY29uc3RydWN0b3IgPT09IE9iamVjdCAmJiBwcm90b3R5cGUgPT09IE9iamVjdC5wcm90b3R5cGU7XG59XG5mdW5jdGlvbiBpc051bGwocGF5bG9hZCkge1xuXHRyZXR1cm4gZ2V0VHlwZShwYXlsb2FkKSA9PT0gXCJOdWxsXCI7XG59XG5mdW5jdGlvbiBpc09uZU9mKGEsIGIsIGMsIGQsIGUpIHtcblx0cmV0dXJuICh2YWx1ZSkgPT4gYSh2YWx1ZSkgfHwgYih2YWx1ZSkgfHwgISFjICYmIGModmFsdWUpIHx8ICEhZCAmJiBkKHZhbHVlKSB8fCAhIWUgJiYgZSh2YWx1ZSk7XG59XG5mdW5jdGlvbiBpc1VuZGVmaW5lZChwYXlsb2FkKSB7XG5cdHJldHVybiBnZXRUeXBlKHBheWxvYWQpID09PSBcIlVuZGVmaW5lZFwiO1xufVxuaXNPbmVPZihpc051bGwsIGlzVW5kZWZpbmVkKTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9jb3B5LWFueXRoaW5nQDMuMC41L25vZGVfbW9kdWxlcy9jb3B5LWFueXRoaW5nL2Rpc3QvaW5kZXguanNcbmZ1bmN0aW9uIGFzc2lnblByb3AoY2FycnksIGtleSwgbmV3VmFsLCBvcmlnaW5hbE9iamVjdCwgaW5jbHVkZU5vbmVudW1lcmFibGUpIHtcblx0Y29uc3QgcHJvcFR5cGUgPSB7fS5wcm9wZXJ0eUlzRW51bWVyYWJsZS5jYWxsKG9yaWdpbmFsT2JqZWN0LCBrZXkpID8gXCJlbnVtZXJhYmxlXCIgOiBcIm5vbmVudW1lcmFibGVcIjtcblx0aWYgKHByb3BUeXBlID09PSBcImVudW1lcmFibGVcIikgY2Fycnlba2V5XSA9IG5ld1ZhbDtcblx0aWYgKGluY2x1ZGVOb25lbnVtZXJhYmxlICYmIHByb3BUeXBlID09PSBcIm5vbmVudW1lcmFibGVcIikgT2JqZWN0LmRlZmluZVByb3BlcnR5KGNhcnJ5LCBrZXksIHtcblx0XHR2YWx1ZTogbmV3VmFsLFxuXHRcdGVudW1lcmFibGU6IGZhbHNlLFxuXHRcdHdyaXRhYmxlOiB0cnVlLFxuXHRcdGNvbmZpZ3VyYWJsZTogdHJ1ZVxuXHR9KTtcbn1cbmZ1bmN0aW9uIGNvcHkodGFyZ2V0LCBvcHRpb25zID0ge30pIHtcblx0aWYgKGlzQXJyYXkkMSh0YXJnZXQpKSByZXR1cm4gdGFyZ2V0Lm1hcCgoaXRlbSkgPT4gY29weShpdGVtLCBvcHRpb25zKSk7XG5cdGlmICghaXNQbGFpbk9iamVjdCQxKHRhcmdldCkpIHJldHVybiB0YXJnZXQ7XG5cdGNvbnN0IHByb3BzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModGFyZ2V0KTtcblx0Y29uc3Qgc3ltYm9scyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHModGFyZ2V0KTtcblx0cmV0dXJuIFsuLi5wcm9wcywgLi4uc3ltYm9sc10ucmVkdWNlKChjYXJyeSwga2V5KSA9PiB7XG5cdFx0aWYgKGlzQXJyYXkkMShvcHRpb25zLnByb3BzKSAmJiAhb3B0aW9ucy5wcm9wcy5pbmNsdWRlcyhrZXkpKSByZXR1cm4gY2Fycnk7XG5cdFx0Y29uc3QgdmFsID0gdGFyZ2V0W2tleV07XG5cdFx0YXNzaWduUHJvcChjYXJyeSwga2V5LCBjb3B5KHZhbCwgb3B0aW9ucyksIHRhcmdldCwgb3B0aW9ucy5ub25lbnVtZXJhYmxlKTtcblx0XHRyZXR1cm4gY2Fycnk7XG5cdH0sIHt9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIC4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9zdXBlcmpzb25AMi4yLjIvbm9kZV9tb2R1bGVzL3N1cGVyanNvbi9kaXN0L2luZGV4LmpzXG52YXIgU3VwZXJKU09OID0gY2xhc3Mge1xuXHQvKipcblx0KiBAcGFyYW0gZGVkdXBlUmVmZXJlbnRpYWxFcXVhbGl0aWVzICBJZiB0cnVlLCBTdXBlckpTT04gd2lsbCBtYWtlIHN1cmUgb25seSBvbmUgaW5zdGFuY2Ugb2YgcmVmZXJlbnRpYWxseSBlcXVhbCBvYmplY3RzIGFyZSBzZXJpYWxpemVkIGFuZCB0aGUgcmVzdCBhcmUgcmVwbGFjZWQgd2l0aCBgbnVsbGAuXG5cdCovXG5cdGNvbnN0cnVjdG9yKHsgZGVkdXBlID0gZmFsc2UgfSA9IHt9KSB7XG5cdFx0dGhpcy5jbGFzc1JlZ2lzdHJ5ID0gbmV3IENsYXNzUmVnaXN0cnkoKTtcblx0XHR0aGlzLnN5bWJvbFJlZ2lzdHJ5ID0gbmV3IFJlZ2lzdHJ5KChzKSA9PiBzLmRlc2NyaXB0aW9uID8/IFwiXCIpO1xuXHRcdHRoaXMuY3VzdG9tVHJhbnNmb3JtZXJSZWdpc3RyeSA9IG5ldyBDdXN0b21UcmFuc2Zvcm1lclJlZ2lzdHJ5KCk7XG5cdFx0dGhpcy5hbGxvd2VkRXJyb3JQcm9wcyA9IFtdO1xuXHRcdHRoaXMuZGVkdXBlID0gZGVkdXBlO1xuXHR9XG5cdHNlcmlhbGl6ZShvYmplY3QpIHtcblx0XHRjb25zdCBpZGVudGl0aWVzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHRjb25zdCBvdXRwdXQgPSB3YWxrZXIob2JqZWN0LCBpZGVudGl0aWVzLCB0aGlzLCB0aGlzLmRlZHVwZSk7XG5cdFx0Y29uc3QgcmVzID0geyBqc29uOiBvdXRwdXQudHJhbnNmb3JtZWRWYWx1ZSB9O1xuXHRcdGlmIChvdXRwdXQuYW5ub3RhdGlvbnMpIHJlcy5tZXRhID0ge1xuXHRcdFx0Li4ucmVzLm1ldGEsXG5cdFx0XHR2YWx1ZXM6IG91dHB1dC5hbm5vdGF0aW9uc1xuXHRcdH07XG5cdFx0Y29uc3QgZXF1YWxpdHlBbm5vdGF0aW9ucyA9IGdlbmVyYXRlUmVmZXJlbnRpYWxFcXVhbGl0eUFubm90YXRpb25zKGlkZW50aXRpZXMsIHRoaXMuZGVkdXBlKTtcblx0XHRpZiAoZXF1YWxpdHlBbm5vdGF0aW9ucykgcmVzLm1ldGEgPSB7XG5cdFx0XHQuLi5yZXMubWV0YSxcblx0XHRcdHJlZmVyZW50aWFsRXF1YWxpdGllczogZXF1YWxpdHlBbm5vdGF0aW9uc1xuXHRcdH07XG5cdFx0cmV0dXJuIHJlcztcblx0fVxuXHRkZXNlcmlhbGl6ZShwYXlsb2FkKSB7XG5cdFx0Y29uc3QgeyBqc29uLCBtZXRhIH0gPSBwYXlsb2FkO1xuXHRcdGxldCByZXN1bHQgPSBjb3B5KGpzb24pO1xuXHRcdGlmIChtZXRhPy52YWx1ZXMpIHJlc3VsdCA9IGFwcGx5VmFsdWVBbm5vdGF0aW9ucyhyZXN1bHQsIG1ldGEudmFsdWVzLCB0aGlzKTtcblx0XHRpZiAobWV0YT8ucmVmZXJlbnRpYWxFcXVhbGl0aWVzKSByZXN1bHQgPSBhcHBseVJlZmVyZW50aWFsRXF1YWxpdHlBbm5vdGF0aW9ucyhyZXN1bHQsIG1ldGEucmVmZXJlbnRpYWxFcXVhbGl0aWVzKTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG5cdHN0cmluZ2lmeShvYmplY3QpIHtcblx0XHRyZXR1cm4gSlNPTi5zdHJpbmdpZnkodGhpcy5zZXJpYWxpemUob2JqZWN0KSk7XG5cdH1cblx0cGFyc2Uoc3RyaW5nKSB7XG5cdFx0cmV0dXJuIHRoaXMuZGVzZXJpYWxpemUoSlNPTi5wYXJzZShzdHJpbmcpKTtcblx0fVxuXHRyZWdpc3RlckNsYXNzKHYsIG9wdGlvbnMpIHtcblx0XHR0aGlzLmNsYXNzUmVnaXN0cnkucmVnaXN0ZXIodiwgb3B0aW9ucyk7XG5cdH1cblx0cmVnaXN0ZXJTeW1ib2wodiwgaWRlbnRpZmllcikge1xuXHRcdHRoaXMuc3ltYm9sUmVnaXN0cnkucmVnaXN0ZXIodiwgaWRlbnRpZmllcik7XG5cdH1cblx0cmVnaXN0ZXJDdXN0b20odHJhbnNmb3JtZXIsIG5hbWUpIHtcblx0XHR0aGlzLmN1c3RvbVRyYW5zZm9ybWVyUmVnaXN0cnkucmVnaXN0ZXIoe1xuXHRcdFx0bmFtZSxcblx0XHRcdC4uLnRyYW5zZm9ybWVyXG5cdFx0fSk7XG5cdH1cblx0YWxsb3dFcnJvclByb3BzKC4uLnByb3BzKSB7XG5cdFx0dGhpcy5hbGxvd2VkRXJyb3JQcm9wcy5wdXNoKC4uLnByb3BzKTtcblx0fVxufTtcblN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UgPSBuZXcgU3VwZXJKU09OKCk7XG5TdXBlckpTT04uc2VyaWFsaXplID0gU3VwZXJKU09OLmRlZmF1bHRJbnN0YW5jZS5zZXJpYWxpemUuYmluZChTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlKTtcblN1cGVySlNPTi5kZXNlcmlhbGl6ZSA9IFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UuZGVzZXJpYWxpemUuYmluZChTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlKTtcblN1cGVySlNPTi5zdHJpbmdpZnkgPSBTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlLnN0cmluZ2lmeS5iaW5kKFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UpO1xuU3VwZXJKU09OLnBhcnNlID0gU3VwZXJKU09OLmRlZmF1bHRJbnN0YW5jZS5wYXJzZS5iaW5kKFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UpO1xuU3VwZXJKU09OLnJlZ2lzdGVyQ2xhc3MgPSBTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlLnJlZ2lzdGVyQ2xhc3MuYmluZChTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlKTtcblN1cGVySlNPTi5yZWdpc3RlclN5bWJvbCA9IFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UucmVnaXN0ZXJTeW1ib2wuYmluZChTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlKTtcblN1cGVySlNPTi5yZWdpc3RlckN1c3RvbSA9IFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UucmVnaXN0ZXJDdXN0b20uYmluZChTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlKTtcblN1cGVySlNPTi5hbGxvd0Vycm9yUHJvcHMgPSBTdXBlckpTT04uZGVmYXVsdEluc3RhbmNlLmFsbG93RXJyb3JQcm9wcy5iaW5kKFN1cGVySlNPTi5kZWZhdWx0SW5zdGFuY2UpO1xuU3VwZXJKU09OLnNlcmlhbGl6ZTtcblN1cGVySlNPTi5kZXNlcmlhbGl6ZTtcblN1cGVySlNPTi5zdHJpbmdpZnk7XG5TdXBlckpTT04ucGFyc2U7XG5TdXBlckpTT04ucmVnaXN0ZXJDbGFzcztcblN1cGVySlNPTi5yZWdpc3RlckN1c3RvbTtcblN1cGVySlNPTi5yZWdpc3RlclN5bWJvbDtcblN1cGVySlNPTi5hbGxvd0Vycm9yUHJvcHM7XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWVzc2FnaW5nL3ByZXNldHMvYnJvYWRjYXN0LWNoYW5uZWwvY29udGV4dC50c1xuY29uc3QgX19ERVZUT09MU19LSVRfQlJPQURDQVNUX01FU1NBR0lOR19FVkVOVF9LRVkgPSBcIl9fZGV2dG9vbHMta2l0LWJyb2FkY2FzdC1tZXNzYWdpbmctZXZlbnQta2V5X19cIjtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9icm9hZGNhc3QtY2hhbm5lbC9pbmRleC50c1xuY29uc3QgQlJPQURDQVNUX0NIQU5ORUxfTkFNRSA9IFwiX19kZXZ0b29scy1raXQ6YnJvYWRjYXN0LWNoYW5uZWxfX1wiO1xuZnVuY3Rpb24gY3JlYXRlQnJvYWRjYXN0Q2hhbm5lbCgpIHtcblx0Y29uc3QgY2hhbm5lbCA9IG5ldyBCcm9hZGNhc3RDaGFubmVsKEJST0FEQ0FTVF9DSEFOTkVMX05BTUUpO1xuXHRyZXR1cm4ge1xuXHRcdHBvc3Q6IChkYXRhKSA9PiB7XG5cdFx0XHRjaGFubmVsLnBvc3RNZXNzYWdlKFN1cGVySlNPTi5zdHJpbmdpZnkoe1xuXHRcdFx0XHRldmVudDogX19ERVZUT09MU19LSVRfQlJPQURDQVNUX01FU1NBR0lOR19FVkVOVF9LRVksXG5cdFx0XHRcdGRhdGFcblx0XHRcdH0pKTtcblx0XHR9LFxuXHRcdG9uOiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0Y2hhbm5lbC5vbm1lc3NhZ2UgPSAoZXZlbnQpID0+IHtcblx0XHRcdFx0Y29uc3QgcGFyc2VkID0gU3VwZXJKU09OLnBhcnNlKGV2ZW50LmRhdGEpO1xuXHRcdFx0XHRpZiAocGFyc2VkLmV2ZW50ID09PSBcIl9fZGV2dG9vbHMta2l0LWJyb2FkY2FzdC1tZXNzYWdpbmctZXZlbnQta2V5X19cIikgaGFuZGxlcihwYXJzZWQuZGF0YSk7XG5cdFx0XHR9O1xuXHRcdH1cblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9lbGVjdHJvbi9jb250ZXh0LnRzXG5jb25zdCBfX0VMRUNUUk9OX0NMSUVOVF9DT05URVhUX18gPSBcImVsZWN0cm9uOmNsaWVudC1jb250ZXh0XCI7XG5jb25zdCBfX0VMRUNUUk9OX1JQT1hZX0NPTlRFWFRfXyA9IFwiZWxlY3Ryb246cHJveHktY29udGV4dFwiO1xuY29uc3QgX19FTEVDVFJPTl9TRVJWRVJfQ09OVEVYVF9fID0gXCJlbGVjdHJvbjpzZXJ2ZXItY29udGV4dFwiO1xuY29uc3QgX19ERVZUT09MU19LSVRfRUxFQ1RST05fTUVTU0FHSU5HX0VWRU5UX0tFWV9fID0ge1xuXHRDTElFTlRfVE9fUFJPWFk6IFwiY2xpZW50LT5wcm94eVwiLFxuXHRQUk9YWV9UT19DTElFTlQ6IFwicHJveHktPmNsaWVudFwiLFxuXHRQUk9YWV9UT19TRVJWRVI6IFwicHJveHktPnNlcnZlclwiLFxuXHRTRVJWRVJfVE9fUFJPWFk6IFwic2VydmVyLT5wcm94eVwiXG59O1xuZnVuY3Rpb24gZ2V0RWxlY3Ryb25DbGllbnRDb250ZXh0KCkge1xuXHRyZXR1cm4gdGFyZ2V0W19fRUxFQ1RST05fQ0xJRU5UX0NPTlRFWFRfX107XG59XG5mdW5jdGlvbiBzZXRFbGVjdHJvbkNsaWVudENvbnRleHQoY29udGV4dCkge1xuXHR0YXJnZXRbX19FTEVDVFJPTl9DTElFTlRfQ09OVEVYVF9fXSA9IGNvbnRleHQ7XG59XG5mdW5jdGlvbiBnZXRFbGVjdHJvblByb3h5Q29udGV4dCgpIHtcblx0cmV0dXJuIHRhcmdldFtfX0VMRUNUUk9OX1JQT1hZX0NPTlRFWFRfX107XG59XG5mdW5jdGlvbiBzZXRFbGVjdHJvblByb3h5Q29udGV4dChjb250ZXh0KSB7XG5cdHRhcmdldFtfX0VMRUNUUk9OX1JQT1hZX0NPTlRFWFRfX10gPSBjb250ZXh0O1xufVxuZnVuY3Rpb24gZ2V0RWxlY3Ryb25TZXJ2ZXJDb250ZXh0KCkge1xuXHRyZXR1cm4gdGFyZ2V0W19fRUxFQ1RST05fU0VSVkVSX0NPTlRFWFRfX107XG59XG5mdW5jdGlvbiBzZXRFbGVjdHJvblNlcnZlckNvbnRleHQoY29udGV4dCkge1xuXHR0YXJnZXRbX19FTEVDVFJPTl9TRVJWRVJfQ09OVEVYVF9fXSA9IGNvbnRleHQ7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWVzc2FnaW5nL3ByZXNldHMvZWxlY3Ryb24vY2xpZW50LnRzXG5mdW5jdGlvbiBjcmVhdGVFbGVjdHJvbkNsaWVudENoYW5uZWwoKSB7XG5cdGNvbnN0IHNvY2tldCA9IGdldEVsZWN0cm9uQ2xpZW50Q29udGV4dCgpO1xuXHRyZXR1cm4ge1xuXHRcdHBvc3Q6IChkYXRhKSA9PiB7XG5cdFx0XHRzb2NrZXQuZW1pdChfX0RFVlRPT0xTX0tJVF9FTEVDVFJPTl9NRVNTQUdJTkdfRVZFTlRfS0VZX18uQ0xJRU5UX1RPX1BST1hZLCBTdXBlckpTT04uc3RyaW5naWZ5KGRhdGEpKTtcblx0XHR9LFxuXHRcdG9uOiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0c29ja2V0Lm9uKF9fREVWVE9PTFNfS0lUX0VMRUNUUk9OX01FU1NBR0lOR19FVkVOVF9LRVlfXy5QUk9YWV9UT19DTElFTlQsIChlKSA9PiB7XG5cdFx0XHRcdGhhbmRsZXIoU3VwZXJKU09OLnBhcnNlKGUpKTtcblx0XHRcdH0pO1xuXHRcdH1cblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9lbGVjdHJvbi9wcm94eS50c1xuZnVuY3Rpb24gY3JlYXRlRWxlY3Ryb25Qcm94eUNoYW5uZWwoKSB7XG5cdGNvbnN0IHNvY2tldCA9IGdldEVsZWN0cm9uUHJveHlDb250ZXh0KCk7XG5cdHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHt9LFxuXHRcdG9uOiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0c29ja2V0Lm9uKF9fREVWVE9PTFNfS0lUX0VMRUNUUk9OX01FU1NBR0lOR19FVkVOVF9LRVlfXy5TRVJWRVJfVE9fUFJPWFksIChkYXRhKSA9PiB7XG5cdFx0XHRcdHNvY2tldC5icm9hZGNhc3QuZW1pdChfX0RFVlRPT0xTX0tJVF9FTEVDVFJPTl9NRVNTQUdJTkdfRVZFTlRfS0VZX18uUFJPWFlfVE9fQ0xJRU5ULCBkYXRhKTtcblx0XHRcdH0pO1xuXHRcdFx0c29ja2V0Lm9uKF9fREVWVE9PTFNfS0lUX0VMRUNUUk9OX01FU1NBR0lOR19FVkVOVF9LRVlfXy5DTElFTlRfVE9fUFJPWFksIChkYXRhKSA9PiB7XG5cdFx0XHRcdHNvY2tldC5icm9hZGNhc3QuZW1pdChfX0RFVlRPT0xTX0tJVF9FTEVDVFJPTl9NRVNTQUdJTkdfRVZFTlRfS0VZX18uUFJPWFlfVE9fU0VSVkVSLCBkYXRhKTtcblx0XHRcdH0pO1xuXHRcdH1cblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9lbGVjdHJvbi9zZXJ2ZXIudHNcbmZ1bmN0aW9uIGNyZWF0ZUVsZWN0cm9uU2VydmVyQ2hhbm5lbCgpIHtcblx0Y29uc3Qgc29ja2V0ID0gZ2V0RWxlY3Ryb25TZXJ2ZXJDb250ZXh0KCk7XG5cdHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHtcblx0XHRcdHNvY2tldC5lbWl0KF9fREVWVE9PTFNfS0lUX0VMRUNUUk9OX01FU1NBR0lOR19FVkVOVF9LRVlfXy5TRVJWRVJfVE9fUFJPWFksIFN1cGVySlNPTi5zdHJpbmdpZnkoZGF0YSkpO1xuXHRcdH0sXG5cdFx0b246IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRzb2NrZXQub24oX19ERVZUT09MU19LSVRfRUxFQ1RST05fTUVTU0FHSU5HX0VWRU5UX0tFWV9fLlBST1hZX1RPX1NFUlZFUiwgKGRhdGEpID0+IHtcblx0XHRcdFx0aGFuZGxlcihTdXBlckpTT04ucGFyc2UoZGF0YSkpO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9wcmVzZXRzL2V4dGVuc2lvbi9jb250ZXh0LnRzXG5jb25zdCBfX0VYVEVOU0lPTl9DTElFTlRfQ09OVEVYVF9fID0gXCJlbGVjdHJvbjpjbGllbnQtY29udGV4dFwiO1xuY29uc3QgX19ERVZUT09MU19LSVRfRVhURU5TSU9OX01FU1NBR0lOR19FVkVOVF9LRVlfXyA9IHtcblx0Q0xJRU5UX1RPX1BST1hZOiBcImNsaWVudC0+cHJveHlcIixcblx0UFJPWFlfVE9fQ0xJRU5UOiBcInByb3h5LT5jbGllbnRcIixcblx0UFJPWFlfVE9fU0VSVkVSOiBcInByb3h5LT5zZXJ2ZXJcIixcblx0U0VSVkVSX1RPX1BST1hZOiBcInNlcnZlci0+cHJveHlcIlxufTtcbmZ1bmN0aW9uIGdldEV4dGVuc2lvbkNsaWVudENvbnRleHQoKSB7XG5cdHJldHVybiB0YXJnZXRbX19FWFRFTlNJT05fQ0xJRU5UX0NPTlRFWFRfX107XG59XG5mdW5jdGlvbiBzZXRFeHRlbnNpb25DbGllbnRDb250ZXh0KGNvbnRleHQpIHtcblx0dGFyZ2V0W19fRVhURU5TSU9OX0NMSUVOVF9DT05URVhUX19dID0gY29udGV4dDtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9leHRlbnNpb24vY2xpZW50LnRzXG5mdW5jdGlvbiBjcmVhdGVFeHRlbnNpb25DbGllbnRDaGFubmVsKCkge1xuXHRsZXQgZGlzY29ubmVjdGVkID0gZmFsc2U7XG5cdGxldCBwb3J0ID0gbnVsbDtcblx0bGV0IHJlY29ubmVjdFRpbWVyID0gbnVsbDtcblx0bGV0IG9uTWVzc2FnZUhhbmRsZXIgPSBudWxsO1xuXHRmdW5jdGlvbiBjb25uZWN0KCkge1xuXHRcdHRyeSB7XG5cdFx0XHRjbGVhclRpbWVvdXQocmVjb25uZWN0VGltZXIpO1xuXHRcdFx0cG9ydCA9IGNocm9tZS5ydW50aW1lLmNvbm5lY3QoeyBuYW1lOiBgJHtjaHJvbWUuZGV2dG9vbHMuaW5zcGVjdGVkV2luZG93LnRhYklkfWAgfSk7XG5cdFx0XHRzZXRFeHRlbnNpb25DbGllbnRDb250ZXh0KHBvcnQpO1xuXHRcdFx0ZGlzY29ubmVjdGVkID0gZmFsc2U7XG5cdFx0XHRwb3J0Py5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIob25NZXNzYWdlSGFuZGxlcik7XG5cdFx0XHRwb3J0Lm9uRGlzY29ubmVjdC5hZGRMaXN0ZW5lcigoKSA9PiB7XG5cdFx0XHRcdGRpc2Nvbm5lY3RlZCA9IHRydWU7XG5cdFx0XHRcdHBvcnQ/Lm9uTWVzc2FnZS5yZW1vdmVMaXN0ZW5lcihvbk1lc3NhZ2VIYW5kbGVyKTtcblx0XHRcdFx0cmVjb25uZWN0VGltZXIgPSBzZXRUaW1lb3V0KGNvbm5lY3QsIDFlMyk7XG5cdFx0XHR9KTtcblx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRkaXNjb25uZWN0ZWQgPSB0cnVlO1xuXHRcdH1cblx0fVxuXHRjb25uZWN0KCk7XG5cdHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHtcblx0XHRcdGlmIChkaXNjb25uZWN0ZWQpIHJldHVybjtcblx0XHRcdHBvcnQ/LnBvc3RNZXNzYWdlKFN1cGVySlNPTi5zdHJpbmdpZnkoZGF0YSkpO1xuXHRcdH0sXG5cdFx0b246IChoYW5kbGVyKSA9PiB7XG5cdFx0XHRvbk1lc3NhZ2VIYW5kbGVyID0gKGRhdGEpID0+IHtcblx0XHRcdFx0aWYgKGRpc2Nvbm5lY3RlZCkgcmV0dXJuO1xuXHRcdFx0XHRoYW5kbGVyKFN1cGVySlNPTi5wYXJzZShkYXRhKSk7XG5cdFx0XHR9O1xuXHRcdFx0cG9ydD8ub25NZXNzYWdlLmFkZExpc3RlbmVyKG9uTWVzc2FnZUhhbmRsZXIpO1xuXHRcdH1cblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9leHRlbnNpb24vcHJveHkudHNcbmZ1bmN0aW9uIGNyZWF0ZUV4dGVuc2lvblByb3h5Q2hhbm5lbCgpIHtcblx0Y29uc3QgcG9ydCA9IGNocm9tZS5ydW50aW1lLmNvbm5lY3QoeyBuYW1lOiBcImNvbnRlbnQtc2NyaXB0XCIgfSk7XG5cdGZ1bmN0aW9uIHNlbmRNZXNzYWdlVG9Vc2VyQXBwKHBheWxvYWQpIHtcblx0XHR3aW5kb3cucG9zdE1lc3NhZ2Uoe1xuXHRcdFx0c291cmNlOiBfX0RFVlRPT0xTX0tJVF9FWFRFTlNJT05fTUVTU0FHSU5HX0VWRU5UX0tFWV9fLlBST1hZX1RPX1NFUlZFUixcblx0XHRcdHBheWxvYWRcblx0XHR9LCBcIipcIik7XG5cdH1cblx0ZnVuY3Rpb24gc2VuZE1lc3NhZ2VUb0RldlRvb2xzQ2xpZW50KGUpIHtcblx0XHRpZiAoZS5kYXRhICYmIGUuZGF0YS5zb3VyY2UgPT09IF9fREVWVE9PTFNfS0lUX0VYVEVOU0lPTl9NRVNTQUdJTkdfRVZFTlRfS0VZX18uU0VSVkVSX1RPX1BST1hZKSB0cnkge1xuXHRcdFx0cG9ydC5wb3N0TWVzc2FnZShlLmRhdGEucGF5bG9hZCk7XG5cdFx0fSBjYXRjaCAoZSkge31cblx0fVxuXHRwb3J0Lm9uTWVzc2FnZS5hZGRMaXN0ZW5lcihzZW5kTWVzc2FnZVRvVXNlckFwcCk7XG5cdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLCBzZW5kTWVzc2FnZVRvRGV2VG9vbHNDbGllbnQpO1xuXHRwb3J0Lm9uRGlzY29ubmVjdC5hZGRMaXN0ZW5lcigoKSA9PiB7XG5cdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIHNlbmRNZXNzYWdlVG9EZXZUb29sc0NsaWVudCk7XG5cdFx0c2VuZE1lc3NhZ2VUb1VzZXJBcHAoU3VwZXJKU09OLnN0cmluZ2lmeSh7IGV2ZW50OiBcInNodXRkb3duXCIgfSkpO1xuXHR9KTtcblx0c2VuZE1lc3NhZ2VUb1VzZXJBcHAoU3VwZXJKU09OLnN0cmluZ2lmeSh7IGV2ZW50OiBcImluaXRcIiB9KSk7XG5cdHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHt9LFxuXHRcdG9uOiAoaGFuZGxlcikgPT4ge31cblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy9leHRlbnNpb24vc2VydmVyLnRzXG5mdW5jdGlvbiBjcmVhdGVFeHRlbnNpb25TZXJ2ZXJDaGFubmVsKCkge1xuXHRyZXR1cm4ge1xuXHRcdHBvc3Q6IChkYXRhKSA9PiB7XG5cdFx0XHR3aW5kb3cucG9zdE1lc3NhZ2Uoe1xuXHRcdFx0XHRzb3VyY2U6IF9fREVWVE9PTFNfS0lUX0VYVEVOU0lPTl9NRVNTQUdJTkdfRVZFTlRfS0VZX18uU0VSVkVSX1RPX1BST1hZLFxuXHRcdFx0XHRwYXlsb2FkOiBTdXBlckpTT04uc3RyaW5naWZ5KGRhdGEpXG5cdFx0XHR9LCBcIipcIik7XG5cdFx0fSxcblx0XHRvbjogKGhhbmRsZXIpID0+IHtcblx0XHRcdGNvbnN0IGxpc3RlbmVyID0gKGV2ZW50KSA9PiB7XG5cdFx0XHRcdGlmIChldmVudC5kYXRhLnNvdXJjZSA9PT0gX19ERVZUT09MU19LSVRfRVhURU5TSU9OX01FU1NBR0lOR19FVkVOVF9LRVlfXy5QUk9YWV9UT19TRVJWRVIgJiYgZXZlbnQuZGF0YS5wYXlsb2FkKSBoYW5kbGVyKFN1cGVySlNPTi5wYXJzZShldmVudC5kYXRhLnBheWxvYWQpKTtcblx0XHRcdH07XG5cdFx0XHR3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgbGlzdGVuZXIpO1xuXHRcdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdFx0d2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIGxpc3RlbmVyKTtcblx0XHRcdH07XG5cdFx0fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9wcmVzZXRzL2lmcmFtZS9jb250ZXh0LnRzXG5jb25zdCBfX0RFVlRPT0xTX0tJVF9JRlJBTUVfTUVTU0FHSU5HX0VWRU5UX0tFWSA9IFwiX19kZXZ0b29scy1raXQtaWZyYW1lLW1lc3NhZ2luZy1ldmVudC1rZXlfX1wiO1xuY29uc3QgX19JRlJBTUVfU0VSVkVSX0NPTlRFWFRfXyA9IFwiaWZyYW1lOnNlcnZlci1jb250ZXh0XCI7XG5mdW5jdGlvbiBnZXRJZnJhbWVTZXJ2ZXJDb250ZXh0KCkge1xuXHRyZXR1cm4gdGFyZ2V0W19fSUZSQU1FX1NFUlZFUl9DT05URVhUX19dO1xufVxuZnVuY3Rpb24gc2V0SWZyYW1lU2VydmVyQ29udGV4dChjb250ZXh0KSB7XG5cdHRhcmdldFtfX0lGUkFNRV9TRVJWRVJfQ09OVEVYVF9fXSA9IGNvbnRleHQ7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWVzc2FnaW5nL3ByZXNldHMvaWZyYW1lL2NsaWVudC50c1xuZnVuY3Rpb24gY3JlYXRlSWZyYW1lQ2xpZW50Q2hhbm5lbCgpIHtcblx0aWYgKCFpc0Jyb3dzZXIpIHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHt9LFxuXHRcdG9uOiAoaGFuZGxlcikgPT4ge31cblx0fTtcblx0cmV0dXJuIHtcblx0XHRwb3N0OiAoZGF0YSkgPT4gd2luZG93LnBhcmVudC5wb3N0TWVzc2FnZShTdXBlckpTT04uc3RyaW5naWZ5KHtcblx0XHRcdGV2ZW50OiBfX0RFVlRPT0xTX0tJVF9JRlJBTUVfTUVTU0FHSU5HX0VWRU5UX0tFWSxcblx0XHRcdGRhdGFcblx0XHR9KSwgXCIqXCIpLFxuXHRcdG9uOiAoaGFuZGxlcikgPT4gd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIChldmVudCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3QgcGFyc2VkID0gU3VwZXJKU09OLnBhcnNlKGV2ZW50LmRhdGEpO1xuXHRcdFx0XHRpZiAoZXZlbnQuc291cmNlID09PSB3aW5kb3cucGFyZW50ICYmIHBhcnNlZC5ldmVudCA9PT0gXCJfX2RldnRvb2xzLWtpdC1pZnJhbWUtbWVzc2FnaW5nLWV2ZW50LWtleV9fXCIpIGhhbmRsZXIocGFyc2VkLmRhdGEpO1xuXHRcdFx0fSBjYXRjaCAoZSkge31cblx0XHR9KVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9wcmVzZXRzL2lmcmFtZS9zZXJ2ZXIudHNcbmZ1bmN0aW9uIGNyZWF0ZUlmcmFtZVNlcnZlckNoYW5uZWwoKSB7XG5cdGlmICghaXNCcm93c2VyKSByZXR1cm4ge1xuXHRcdHBvc3Q6IChkYXRhKSA9PiB7fSxcblx0XHRvbjogKGhhbmRsZXIpID0+IHt9XG5cdH07XG5cdHJldHVybiB7XG5cdFx0cG9zdDogKGRhdGEpID0+IHtcblx0XHRcdGdldElmcmFtZVNlcnZlckNvbnRleHQoKT8uY29udGVudFdpbmRvdz8ucG9zdE1lc3NhZ2UoU3VwZXJKU09OLnN0cmluZ2lmeSh7XG5cdFx0XHRcdGV2ZW50OiBfX0RFVlRPT0xTX0tJVF9JRlJBTUVfTUVTU0FHSU5HX0VWRU5UX0tFWSxcblx0XHRcdFx0ZGF0YVxuXHRcdFx0fSksIFwiKlwiKTtcblx0XHR9LFxuXHRcdG9uOiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIChldmVudCkgPT4ge1xuXHRcdFx0XHRjb25zdCBpZnJhbWUgPSBnZXRJZnJhbWVTZXJ2ZXJDb250ZXh0KCk7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0Y29uc3QgcGFyc2VkID0gU3VwZXJKU09OLnBhcnNlKGV2ZW50LmRhdGEpO1xuXHRcdFx0XHRcdGlmIChldmVudC5zb3VyY2UgPT09IGlmcmFtZT8uY29udGVudFdpbmRvdyAmJiBwYXJzZWQuZXZlbnQgPT09IFwiX19kZXZ0b29scy1raXQtaWZyYW1lLW1lc3NhZ2luZy1ldmVudC1rZXlfX1wiKSBoYW5kbGVyKHBhcnNlZC5kYXRhKTtcblx0XHRcdFx0fSBjYXRjaCAoZSkge31cblx0XHRcdH0pO1xuXHRcdH1cblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tZXNzYWdpbmcvcHJlc2V0cy92aXRlL2NvbnRleHQudHNcbmNvbnN0IF9fREVWVE9PTFNfS0lUX1ZJVEVfTUVTU0FHSU5HX0VWRU5UX0tFWSA9IFwiX19kZXZ0b29scy1raXQtdml0ZS1tZXNzYWdpbmctZXZlbnQta2V5X19cIjtcbmNvbnN0IF9fVklURV9DTElFTlRfQ09OVEVYVF9fID0gXCJ2aXRlOmNsaWVudC1jb250ZXh0XCI7XG5jb25zdCBfX1ZJVEVfU0VSVkVSX0NPTlRFWFRfXyA9IFwidml0ZTpzZXJ2ZXItY29udGV4dFwiO1xuZnVuY3Rpb24gZ2V0Vml0ZUNsaWVudENvbnRleHQoKSB7XG5cdHJldHVybiB0YXJnZXRbX19WSVRFX0NMSUVOVF9DT05URVhUX19dO1xufVxuZnVuY3Rpb24gc2V0Vml0ZUNsaWVudENvbnRleHQoY29udGV4dCkge1xuXHR0YXJnZXRbX19WSVRFX0NMSUVOVF9DT05URVhUX19dID0gY29udGV4dDtcbn1cbmZ1bmN0aW9uIGdldFZpdGVTZXJ2ZXJDb250ZXh0KCkge1xuXHRyZXR1cm4gdGFyZ2V0W19fVklURV9TRVJWRVJfQ09OVEVYVF9fXTtcbn1cbmZ1bmN0aW9uIHNldFZpdGVTZXJ2ZXJDb250ZXh0KGNvbnRleHQpIHtcblx0dGFyZ2V0W19fVklURV9TRVJWRVJfQ09OVEVYVF9fXSA9IGNvbnRleHQ7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWVzc2FnaW5nL3ByZXNldHMvdml0ZS9jbGllbnQudHNcbmZ1bmN0aW9uIGNyZWF0ZVZpdGVDbGllbnRDaGFubmVsKCkge1xuXHRjb25zdCBjbGllbnQgPSBnZXRWaXRlQ2xpZW50Q29udGV4dCgpO1xuXHRyZXR1cm4ge1xuXHRcdHBvc3Q6IChkYXRhKSA9PiB7XG5cdFx0XHRjbGllbnQ/LnNlbmQoX19ERVZUT09MU19LSVRfVklURV9NRVNTQUdJTkdfRVZFTlRfS0VZLCBTdXBlckpTT04uc3RyaW5naWZ5KGRhdGEpKTtcblx0XHR9LFxuXHRcdG9uOiAoaGFuZGxlcikgPT4ge1xuXHRcdFx0Y2xpZW50Py5vbihfX0RFVlRPT0xTX0tJVF9WSVRFX01FU1NBR0lOR19FVkVOVF9LRVksIChldmVudCkgPT4ge1xuXHRcdFx0XHRoYW5kbGVyKFN1cGVySlNPTi5wYXJzZShldmVudCkpO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9wcmVzZXRzL3ZpdGUvc2VydmVyLnRzXG5mdW5jdGlvbiBjcmVhdGVWaXRlU2VydmVyQ2hhbm5lbCgpIHtcblx0Y29uc3Qgdml0ZVNlcnZlciA9IGdldFZpdGVTZXJ2ZXJDb250ZXh0KCk7XG5cdGNvbnN0IHdzID0gdml0ZVNlcnZlci5ob3QgPz8gdml0ZVNlcnZlci53cztcblx0cmV0dXJuIHtcblx0XHRwb3N0OiAoZGF0YSkgPT4gd3M/LnNlbmQoX19ERVZUT09MU19LSVRfVklURV9NRVNTQUdJTkdfRVZFTlRfS0VZLCBTdXBlckpTT04uc3RyaW5naWZ5KGRhdGEpKSxcblx0XHRvbjogKGhhbmRsZXIpID0+IHdzPy5vbihfX0RFVlRPT0xTX0tJVF9WSVRFX01FU1NBR0lOR19FVkVOVF9LRVksIChldmVudCkgPT4ge1xuXHRcdFx0aGFuZGxlcihTdXBlckpTT04ucGFyc2UoZXZlbnQpKTtcblx0XHR9KVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL21lc3NhZ2luZy9pbmRleC50c1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9NRVNTQUdFX0NIQU5ORUxTX18gPz89IFtdO1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9SUENfQ0xJRU5UX18gPz89IG51bGw7XG50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX1JQQ19TRVJWRVJfXyA/Pz0gbnVsbDtcbnRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfVklURV9SUENfQ0xJRU5UX18gPz89IG51bGw7XG50YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX1ZJVEVfUlBDX1NFUlZFUl9fID8/PSBudWxsO1xudGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9CUk9BRENBU1RfUlBDX1NFUlZFUl9fID8/PSBudWxsO1xuZnVuY3Rpb24gc2V0UnBjQ2xpZW50VG9HbG9iYWwocnBjKSB7XG5cdHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfUlBDX0NMSUVOVF9fID0gcnBjO1xufVxuZnVuY3Rpb24gc2V0UnBjU2VydmVyVG9HbG9iYWwocnBjKSB7XG5cdHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfUlBDX1NFUlZFUl9fID0gcnBjO1xufVxuZnVuY3Rpb24gZ2V0UnBjQ2xpZW50KCkge1xuXHRyZXR1cm4gdGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9SUENfQ0xJRU5UX187XG59XG5mdW5jdGlvbiBnZXRScGNTZXJ2ZXIoKSB7XG5cdHJldHVybiB0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX1JQQ19TRVJWRVJfXztcbn1cbmZ1bmN0aW9uIHNldFZpdGVScGNDbGllbnRUb0dsb2JhbChycGMpIHtcblx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9WSVRFX1JQQ19DTElFTlRfXyA9IHJwYztcbn1cbmZ1bmN0aW9uIHNldFZpdGVScGNTZXJ2ZXJUb0dsb2JhbChycGMpIHtcblx0dGFyZ2V0Ll9fVlVFX0RFVlRPT0xTX0tJVF9WSVRFX1JQQ19TRVJWRVJfXyA9IHJwYztcbn1cbmZ1bmN0aW9uIGdldFZpdGVScGNDbGllbnQoKSB7XG5cdHJldHVybiB0YXJnZXQuX19WVUVfREVWVE9PTFNfS0lUX1ZJVEVfUlBDX0NMSUVOVF9fO1xufVxuZnVuY3Rpb24gZ2V0Vml0ZVJwY1NlcnZlcigpIHtcblx0cmV0dXJuIHRhcmdldC5fX1ZVRV9ERVZUT09MU19LSVRfVklURV9SUENfU0VSVkVSX187XG59XG5mdW5jdGlvbiBnZXRDaGFubmVsKHByZXNldCwgaG9zdCA9IFwiY2xpZW50XCIpIHtcblx0Y29uc3QgY2hhbm5lbCA9IHtcblx0XHRpZnJhbWU6IHtcblx0XHRcdGNsaWVudDogY3JlYXRlSWZyYW1lQ2xpZW50Q2hhbm5lbCxcblx0XHRcdHNlcnZlcjogY3JlYXRlSWZyYW1lU2VydmVyQ2hhbm5lbFxuXHRcdH1baG9zdF0sXG5cdFx0ZWxlY3Ryb246IHtcblx0XHRcdGNsaWVudDogY3JlYXRlRWxlY3Ryb25DbGllbnRDaGFubmVsLFxuXHRcdFx0cHJveHk6IGNyZWF0ZUVsZWN0cm9uUHJveHlDaGFubmVsLFxuXHRcdFx0c2VydmVyOiBjcmVhdGVFbGVjdHJvblNlcnZlckNoYW5uZWxcblx0XHR9W2hvc3RdLFxuXHRcdHZpdGU6IHtcblx0XHRcdGNsaWVudDogY3JlYXRlVml0ZUNsaWVudENoYW5uZWwsXG5cdFx0XHRzZXJ2ZXI6IGNyZWF0ZVZpdGVTZXJ2ZXJDaGFubmVsXG5cdFx0fVtob3N0XSxcblx0XHRicm9hZGNhc3Q6IHtcblx0XHRcdGNsaWVudDogY3JlYXRlQnJvYWRjYXN0Q2hhbm5lbCxcblx0XHRcdHNlcnZlcjogY3JlYXRlQnJvYWRjYXN0Q2hhbm5lbFxuXHRcdH1baG9zdF0sXG5cdFx0ZXh0ZW5zaW9uOiB7XG5cdFx0XHRjbGllbnQ6IGNyZWF0ZUV4dGVuc2lvbkNsaWVudENoYW5uZWwsXG5cdFx0XHRwcm94eTogY3JlYXRlRXh0ZW5zaW9uUHJveHlDaGFubmVsLFxuXHRcdFx0c2VydmVyOiBjcmVhdGVFeHRlbnNpb25TZXJ2ZXJDaGFubmVsXG5cdFx0fVtob3N0XVxuXHR9W3ByZXNldF07XG5cdHJldHVybiBjaGFubmVsKCk7XG59XG5mdW5jdGlvbiBjcmVhdGVScGNDbGllbnQoZnVuY3Rpb25zLCBvcHRpb25zID0ge30pIHtcblx0Y29uc3QgeyBjaGFubmVsOiBfY2hhbm5lbCwgb3B0aW9uczogX29wdGlvbnMsIHByZXNldCB9ID0gb3B0aW9ucztcblx0Y29uc3QgY2hhbm5lbCA9IHByZXNldCA/IGdldENoYW5uZWwocHJlc2V0KSA6IF9jaGFubmVsO1xuXHRjb25zdCBycGMgPSBjcmVhdGVCaXJwYyhmdW5jdGlvbnMsIHtcblx0XHQuLi5fb3B0aW9ucyxcblx0XHQuLi5jaGFubmVsLFxuXHRcdHRpbWVvdXQ6IC0xXG5cdH0pO1xuXHRpZiAocHJlc2V0ID09PSBcInZpdGVcIikge1xuXHRcdHNldFZpdGVScGNDbGllbnRUb0dsb2JhbChycGMpO1xuXHRcdHJldHVybjtcblx0fVxuXHRzZXRScGNDbGllbnRUb0dsb2JhbChycGMpO1xuXHRyZXR1cm4gcnBjO1xufVxuZnVuY3Rpb24gY3JlYXRlUnBjU2VydmVyKGZ1bmN0aW9ucywgb3B0aW9ucyA9IHt9KSB7XG5cdGNvbnN0IHsgY2hhbm5lbDogX2NoYW5uZWwsIG9wdGlvbnM6IF9vcHRpb25zLCBwcmVzZXQgfSA9IG9wdGlvbnM7XG5cdGNvbnN0IGNoYW5uZWwgPSBwcmVzZXQgPyBnZXRDaGFubmVsKHByZXNldCwgXCJzZXJ2ZXJcIikgOiBfY2hhbm5lbDtcblx0Y29uc3QgcnBjU2VydmVyID0gZ2V0UnBjU2VydmVyKCk7XG5cdGlmICghcnBjU2VydmVyKSB7XG5cdFx0Y29uc3QgZ3JvdXAgPSBjcmVhdGVCaXJwY0dyb3VwKGZ1bmN0aW9ucywgW2NoYW5uZWxdLCB7XG5cdFx0XHQuLi5fb3B0aW9ucyxcblx0XHRcdHRpbWVvdXQ6IC0xXG5cdFx0fSk7XG5cdFx0aWYgKHByZXNldCA9PT0gXCJ2aXRlXCIpIHtcblx0XHRcdHNldFZpdGVScGNTZXJ2ZXJUb0dsb2JhbChncm91cCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdHNldFJwY1NlcnZlclRvR2xvYmFsKGdyb3VwKTtcblx0fSBlbHNlIHJwY1NlcnZlci51cGRhdGVDaGFubmVscygoY2hhbm5lbHMpID0+IHtcblx0XHRjaGFubmVscy5wdXNoKGNoYW5uZWwpO1xuXHR9KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVJwY1Byb3h5KG9wdGlvbnMgPSB7fSkge1xuXHRjb25zdCB7IGNoYW5uZWw6IF9jaGFubmVsLCBvcHRpb25zOiBfb3B0aW9ucywgcHJlc2V0IH0gPSBvcHRpb25zO1xuXHRjb25zdCBjaGFubmVsID0gcHJlc2V0ID8gZ2V0Q2hhbm5lbChwcmVzZXQsIFwicHJveHlcIikgOiBfY2hhbm5lbDtcblx0cmV0dXJuIGNyZWF0ZUJpcnBjKHt9LCB7XG5cdFx0Li4uX29wdGlvbnMsXG5cdFx0Li4uY2hhbm5lbCxcblx0XHR0aW1lb3V0OiAtMVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2NvbXBvbmVudC9zdGF0ZS9jdXN0b20udHNcbmZ1bmN0aW9uIGdldEZ1bmN0aW9uRGV0YWlscyhmdW5jKSB7XG5cdGxldCBzdHJpbmcgPSBcIlwiO1xuXHRsZXQgbWF0Y2hlcyA9IG51bGw7XG5cdHRyeSB7XG5cdFx0c3RyaW5nID0gRnVuY3Rpb24ucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwoZnVuYyk7XG5cdFx0bWF0Y2hlcyA9IFN0cmluZy5wcm90b3R5cGUubWF0Y2guY2FsbChzdHJpbmcsIC9cXChbXFxzXFxTXSo/XFwpLyk7XG5cdH0gY2F0Y2ggKGUpIHt9XG5cdGNvbnN0IG1hdGNoID0gbWF0Y2hlcyAmJiBtYXRjaGVzWzBdO1xuXHRjb25zdCBhcmdzID0gdHlwZW9mIG1hdGNoID09PSBcInN0cmluZ1wiID8gbWF0Y2ggOiBcIig/KVwiO1xuXHRyZXR1cm4geyBfY3VzdG9tOiB7XG5cdFx0dHlwZTogXCJmdW5jdGlvblwiLFxuXHRcdGRpc3BsYXlUZXh0OiBgPHNwYW4gc3R5bGU9XCJvcGFjaXR5Oi44O21hcmdpbi1yaWdodDo1cHg7XCI+ZnVuY3Rpb248L3NwYW4+IDxzcGFuIHN0eWxlPVwid2hpdGUtc3BhY2U6bm93cmFwO1wiPiR7ZXNjYXBlKHR5cGVvZiBmdW5jLm5hbWUgPT09IFwic3RyaW5nXCIgPyBmdW5jLm5hbWUgOiBcIlwiKX0ke2FyZ3N9PC9zcGFuPmAsXG5cdFx0dG9vbHRpcFRleHQ6IHN0cmluZy50cmltKCkgPyBgPHByZT4ke2VzY2FwZShzdHJpbmcpfTwvcHJlPmAgOiBudWxsXG5cdH0gfTtcbn1cbmZ1bmN0aW9uIGdldEJpZ0ludERldGFpbHModmFsKSB7XG5cdGNvbnN0IHN0cmluZ2lmaWVkQmlnSW50ID0gQmlnSW50LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbCk7XG5cdHJldHVybiB7IF9jdXN0b206IHtcblx0XHR0eXBlOiBcImJpZ2ludFwiLFxuXHRcdGRpc3BsYXlUZXh0OiBgQmlnSW50KCR7c3RyaW5naWZpZWRCaWdJbnR9KWAsXG5cdFx0dmFsdWU6IHN0cmluZ2lmaWVkQmlnSW50XG5cdH0gfTtcbn1cbmZ1bmN0aW9uIGdldERhdGVEZXRhaWxzKHZhbCkge1xuXHRjb25zdCBkYXRlID0gbmV3IERhdGUodmFsLmdldFRpbWUoKSk7XG5cdGRhdGUuc2V0TWludXRlcyhkYXRlLmdldE1pbnV0ZXMoKSAtIGRhdGUuZ2V0VGltZXpvbmVPZmZzZXQoKSk7XG5cdHJldHVybiB7IF9jdXN0b206IHtcblx0XHR0eXBlOiBcImRhdGVcIixcblx0XHRkaXNwbGF5VGV4dDogRGF0ZS5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh2YWwpLFxuXHRcdHZhbHVlOiBkYXRlLnRvSVNPU3RyaW5nKCkuc2xpY2UoMCwgLTEpXG5cdH0gfTtcbn1cbmZ1bmN0aW9uIGdldE1hcERldGFpbHModmFsKSB7XG5cdHJldHVybiB7IF9jdXN0b206IHtcblx0XHR0eXBlOiBcIm1hcFwiLFxuXHRcdGRpc3BsYXlUZXh0OiBcIk1hcFwiLFxuXHRcdHZhbHVlOiBPYmplY3QuZnJvbUVudHJpZXModmFsKSxcblx0XHRyZWFkT25seTogdHJ1ZSxcblx0XHRmaWVsZHM6IHsgYWJzdHJhY3Q6IHRydWUgfVxuXHR9IH07XG59XG5mdW5jdGlvbiBnZXRTZXREZXRhaWxzKHZhbCkge1xuXHRjb25zdCBsaXN0ID0gQXJyYXkuZnJvbSh2YWwpO1xuXHRyZXR1cm4geyBfY3VzdG9tOiB7XG5cdFx0dHlwZTogXCJzZXRcIixcblx0XHRkaXNwbGF5VGV4dDogYFNldFske2xpc3QubGVuZ3RofV1gLFxuXHRcdHZhbHVlOiBsaXN0LFxuXHRcdHJlYWRPbmx5OiB0cnVlXG5cdH0gfTtcbn1cbmZ1bmN0aW9uIGdldENhdWdodEdldHRlcnMoc3RvcmUpIHtcblx0Y29uc3QgZ2V0dGVycyA9IHt9O1xuXHRjb25zdCBvcmlnR2V0dGVycyA9IHN0b3JlLmdldHRlcnMgfHwge307XG5cdGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhvcmlnR2V0dGVycyk7XG5cdGZvciAobGV0IGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7IGkrKykge1xuXHRcdGNvbnN0IGtleSA9IGtleXNbaV07XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGdldHRlcnMsIGtleSwge1xuXHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRcdGdldDogKCkgPT4ge1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdHJldHVybiBvcmlnR2V0dGVyc1trZXldO1xuXHRcdFx0XHR9IGNhdGNoIChlKSB7XG5cdFx0XHRcdFx0cmV0dXJuIGU7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXHRyZXR1cm4gZ2V0dGVycztcbn1cbmZ1bmN0aW9uIHJlZHVjZVN0YXRlTGlzdChsaXN0KSB7XG5cdGlmICghbGlzdC5sZW5ndGgpIHJldHVybiB2b2lkIDA7XG5cdHJldHVybiBsaXN0LnJlZHVjZSgobWFwLCBpdGVtKSA9PiB7XG5cdFx0Y29uc3Qga2V5ID0gaXRlbS50eXBlIHx8IFwiZGF0YVwiO1xuXHRcdGNvbnN0IG9iaiA9IG1hcFtrZXldID0gbWFwW2tleV0gfHwge307XG5cdFx0b2JqW2l0ZW0ua2V5XSA9IGl0ZW0udmFsdWU7XG5cdFx0cmV0dXJuIG1hcDtcblx0fSwge30pO1xufVxuZnVuY3Rpb24gbmFtZWROb2RlTWFwVG9PYmplY3QobWFwKSB7XG5cdGNvbnN0IHJlc3VsdCA9IHt9O1xuXHRjb25zdCBsID0gbWFwLmxlbmd0aDtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBsOyBpKyspIHtcblx0XHRjb25zdCBub2RlID0gbWFwLml0ZW0oaSk7XG5cdFx0cmVzdWx0W25vZGUubmFtZV0gPSBub2RlLnZhbHVlO1xuXHR9XG5cdHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiBnZXRTdG9yZURldGFpbHMoc3RvcmUpIHtcblx0cmV0dXJuIHsgX2N1c3RvbToge1xuXHRcdHR5cGU6IFwic3RvcmVcIixcblx0XHRkaXNwbGF5VGV4dDogXCJTdG9yZVwiLFxuXHRcdHZhbHVlOiB7XG5cdFx0XHRzdGF0ZTogc3RvcmUuc3RhdGUsXG5cdFx0XHRnZXR0ZXJzOiBnZXRDYXVnaHRHZXR0ZXJzKHN0b3JlKVxuXHRcdH0sXG5cdFx0ZmllbGRzOiB7IGFic3RyYWN0OiB0cnVlIH1cblx0fSB9O1xufVxuZnVuY3Rpb24gZ2V0SW5zdGFuY2VEZXRhaWxzKGluc3RhbmNlKSB7XG5cdGlmIChpbnN0YW5jZS5fKSBpbnN0YW5jZSA9IGluc3RhbmNlLl87XG5cdGNvbnN0IHN0YXRlID0gcHJvY2Vzc0luc3RhbmNlU3RhdGUoaW5zdGFuY2UpO1xuXHRyZXR1cm4geyBfY3VzdG9tOiB7XG5cdFx0dHlwZTogXCJjb21wb25lbnRcIixcblx0XHRpZDogaW5zdGFuY2UuX19WVUVfREVWVE9PTFNfTkVYVF9VSURfXyxcblx0XHRkaXNwbGF5VGV4dDogZ2V0SW5zdGFuY2VOYW1lKGluc3RhbmNlKSxcblx0XHR0b29sdGlwVGV4dDogXCJDb21wb25lbnQgaW5zdGFuY2VcIixcblx0XHR2YWx1ZTogcmVkdWNlU3RhdGVMaXN0KHN0YXRlKSxcblx0XHRmaWVsZHM6IHsgYWJzdHJhY3Q6IHRydWUgfVxuXHR9IH07XG59XG5mdW5jdGlvbiBnZXRDb21wb25lbnREZWZpbml0aW9uRGV0YWlscyhkZWZpbml0aW9uKSB7XG5cdGxldCBkaXNwbGF5ID0gZ2V0Q29tcG9uZW50TmFtZShkZWZpbml0aW9uKTtcblx0aWYgKGRpc3BsYXkpIHtcblx0XHRpZiAoZGVmaW5pdGlvbi5uYW1lICYmIGRlZmluaXRpb24uX19maWxlKSBkaXNwbGF5ICs9IGAgPHNwYW4+KCR7ZGVmaW5pdGlvbi5fX2ZpbGV9KTwvc3Bhbj5gO1xuXHR9IGVsc2UgZGlzcGxheSA9IFwiPGk+VW5rbm93biBDb21wb25lbnQ8L2k+XCI7XG5cdHJldHVybiB7IF9jdXN0b206IHtcblx0XHR0eXBlOiBcImNvbXBvbmVudC1kZWZpbml0aW9uXCIsXG5cdFx0ZGlzcGxheVRleHQ6IGRpc3BsYXksXG5cdFx0dG9vbHRpcFRleHQ6IFwiQ29tcG9uZW50IGRlZmluaXRpb25cIixcblx0XHQuLi5kZWZpbml0aW9uLl9fZmlsZSA/IHsgZmlsZTogZGVmaW5pdGlvbi5fX2ZpbGUgfSA6IHt9XG5cdH0gfTtcbn1cbmZ1bmN0aW9uIGdldEhUTUxFbGVtZW50RGV0YWlscyh2YWx1ZSkge1xuXHR0cnkge1xuXHRcdHJldHVybiB7IF9jdXN0b206IHtcblx0XHRcdHR5cGU6IFwiSFRNTEVsZW1lbnRcIixcblx0XHRcdGRpc3BsYXlUZXh0OiBgPHNwYW4gY2xhc3M9XCJvcGFjaXR5LTMwXCI+Jmx0Ozwvc3Bhbj48c3BhbiBjbGFzcz1cInRleHQtYmx1ZS01MDBcIj4ke3ZhbHVlLnRhZ05hbWUudG9Mb3dlckNhc2UoKX08L3NwYW4+PHNwYW4gY2xhc3M9XCJvcGFjaXR5LTMwXCI+Jmd0Ozwvc3Bhbj5gLFxuXHRcdFx0dmFsdWU6IG5hbWVkTm9kZU1hcFRvT2JqZWN0KHZhbHVlLmF0dHJpYnV0ZXMpXG5cdFx0fSB9O1xuXHR9IGNhdGNoIChlKSB7XG5cdFx0cmV0dXJuIHsgX2N1c3RvbToge1xuXHRcdFx0dHlwZTogXCJIVE1MRWxlbWVudFwiLFxuXHRcdFx0ZGlzcGxheVRleHQ6IGA8c3BhbiBjbGFzcz1cInRleHQtYmx1ZS01MDBcIj4ke1N0cmluZyh2YWx1ZSl9PC9zcGFuPmBcblx0XHR9IH07XG5cdH1cbn1cbi8qKlxuKiAtIE9iamVjdFJlZkltcGwsIHRvUmVmKHsgZm9vOiAnZm9vJyB9LCAnZm9vJyksIGBfdmFsdWVgIGlzIHRoZSBhY3R1YWwgdmFsdWUsIChzaW5jZSAzLjUuMClcbiogLSBHZXR0ZXJSZWZJbXBsLCB0b1JlZigoKSA9PiBzdGF0ZS5mb28pLCBgX3ZhbHVlYCBpcyB0aGUgYWN0dWFsIHZhbHVlLCAoc2luY2UgMy41LjApXG4qIC0gUmVmSW1wbCwgcmVmKCdmb28nKSAvIGNvbXB1dGVkKCgpID0+ICdmb28nKSwgYF92YWx1ZWAgaXMgdGhlIGFjdHVhbCB2YWx1ZVxuKi9cbmZ1bmN0aW9uIHRyeUdldFJlZlZhbHVlKHJlZikge1xuXHRpZiAoZW5zdXJlUHJvcGVydHlFeGlzdHMocmVmLCBcIl92YWx1ZVwiLCB0cnVlKSkgcmV0dXJuIHJlZi5fdmFsdWU7XG5cdGlmIChlbnN1cmVQcm9wZXJ0eUV4aXN0cyhyZWYsIFwidmFsdWVcIiwgdHJ1ZSkpIHJldHVybiByZWYudmFsdWU7XG59XG5mdW5jdGlvbiBnZXRPYmplY3REZXRhaWxzKG9iamVjdCkge1xuXHRjb25zdCBpbmZvID0gZ2V0U2V0dXBTdGF0ZVR5cGUob2JqZWN0KTtcblx0aWYgKGluZm8ucmVmIHx8IGluZm8uY29tcHV0ZWQgfHwgaW5mby5yZWFjdGl2ZSkge1xuXHRcdGNvbnN0IHN0YXRlVHlwZU5hbWUgPSBpbmZvLmNvbXB1dGVkID8gXCJDb21wdXRlZFwiIDogaW5mby5yZWYgPyBcIlJlZlwiIDogaW5mby5yZWFjdGl2ZSA/IFwiUmVhY3RpdmVcIiA6IG51bGw7XG5cdFx0Y29uc3QgdmFsdWUgPSB0b1JhdyhpbmZvLnJlYWN0aXZlID8gb2JqZWN0IDogdHJ5R2V0UmVmVmFsdWUob2JqZWN0KSk7XG5cdFx0Y29uc3QgcmF3ID0gZW5zdXJlUHJvcGVydHlFeGlzdHMob2JqZWN0LCBcImVmZmVjdFwiKSA/IG9iamVjdC5lZmZlY3Q/LnJhdz8udG9TdHJpbmcoKSB8fCBvYmplY3QuZWZmZWN0Py5mbj8udG9TdHJpbmcoKSA6IG51bGw7XG5cdFx0cmV0dXJuIHsgX2N1c3RvbToge1xuXHRcdFx0dHlwZTogc3RhdGVUeXBlTmFtZT8udG9Mb3dlckNhc2UoKSxcblx0XHRcdHN0YXRlVHlwZU5hbWUsXG5cdFx0XHR2YWx1ZSxcblx0XHRcdC4uLnJhdyA/IHsgdG9vbHRpcFRleHQ6IGA8cHJlPiR7ZXNjYXBlKHJhdyl9PC9wcmU+YCB9IDoge31cblx0XHR9IH07XG5cdH1cblx0aWYgKGVuc3VyZVByb3BlcnR5RXhpc3RzKG9iamVjdCwgXCJfX2FzeW5jTG9hZGVyXCIpICYmIHR5cGVvZiBvYmplY3QuX19hc3luY0xvYWRlciA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4geyBfY3VzdG9tOiB7XG5cdFx0dHlwZTogXCJjb21wb25lbnQtZGVmaW5pdGlvblwiLFxuXHRcdGRpc3BsYXk6IFwiQXN5bmMgY29tcG9uZW50IGRlZmluaXRpb25cIlxuXHR9IH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9jb21wb25lbnQvc3RhdGUvcmVwbGFjZXIudHNcbmZ1bmN0aW9uIHN0cmluZ2lmeVJlcGxhY2VyKGtleSwgX3ZhbHVlLCBkZXB0aCwgc2Vlbkluc3RhbmNlKSB7XG5cdGlmIChrZXkgPT09IFwiY29tcGlsZXJPcHRpb25zXCIpIHJldHVybjtcblx0Y29uc3QgdmFsID0gdGhpc1trZXldO1xuXHRjb25zdCB0eXBlID0gdHlwZW9mIHZhbDtcblx0aWYgKEFycmF5LmlzQXJyYXkodmFsKSkge1xuXHRcdGNvbnN0IGwgPSB2YWwubGVuZ3RoO1xuXHRcdGlmIChsID4gNWUzKSByZXR1cm4ge1xuXHRcdFx0X2lzQXJyYXk6IHRydWUsXG5cdFx0XHRsZW5ndGg6IGwsXG5cdFx0XHRpdGVtczogdmFsLnNsaWNlKDAsIE1BWF9BUlJBWV9TSVpFKVxuXHRcdH07XG5cdFx0cmV0dXJuIHZhbDtcblx0fSBlbHNlIGlmICh0eXBlb2YgdmFsID09PSBcInN0cmluZ1wiKSBpZiAodmFsLmxlbmd0aCA+IDFlNCkgcmV0dXJuIGAke3ZhbC5zdWJzdHJpbmcoMCwgTUFYX1NUUklOR19TSVpFKX0uLi4gKCR7dmFsLmxlbmd0aH0gdG90YWwgbGVuZ3RoKWA7XG5cdGVsc2UgcmV0dXJuIHZhbDtcblx0ZWxzZSBpZiAodHlwZSA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIFVOREVGSU5FRDtcblx0ZWxzZSBpZiAodmFsID09PSBOdW1iZXIuUE9TSVRJVkVfSU5GSU5JVFkpIHJldHVybiBJTkZJTklUWTtcblx0ZWxzZSBpZiAodmFsID09PSBOdW1iZXIuTkVHQVRJVkVfSU5GSU5JVFkpIHJldHVybiBORUdBVElWRV9JTkZJTklUWTtcblx0ZWxzZSBpZiAodHlwZW9mIHZhbCA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gZ2V0RnVuY3Rpb25EZXRhaWxzKHZhbCk7XG5cdGVsc2UgaWYgKHR5cGUgPT09IFwic3ltYm9sXCIpIHJldHVybiBgW25hdGl2ZSBTeW1ib2wgJHtTeW1ib2wucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsKX1dYDtcblx0ZWxzZSBpZiAodHlwZW9mIHZhbCA9PT0gXCJiaWdpbnRcIikgcmV0dXJuIGdldEJpZ0ludERldGFpbHModmFsKTtcblx0ZWxzZSBpZiAodmFsICE9PSBudWxsICYmIHR5cGVvZiB2YWwgPT09IFwib2JqZWN0XCIpIHtcblx0XHRjb25zdCBwcm90byA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh2YWwpO1xuXHRcdGlmIChwcm90byA9PT0gXCJbb2JqZWN0IE1hcF1cIikgcmV0dXJuIGdldE1hcERldGFpbHModmFsKTtcblx0XHRlbHNlIGlmIChwcm90byA9PT0gXCJbb2JqZWN0IFNldF1cIikgcmV0dXJuIGdldFNldERldGFpbHModmFsKTtcblx0XHRlbHNlIGlmIChwcm90byA9PT0gXCJbb2JqZWN0IFJlZ0V4cF1cIikgcmV0dXJuIGBbbmF0aXZlIFJlZ0V4cCAke1JlZ0V4cC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh2YWwpfV1gO1xuXHRcdGVsc2UgaWYgKHByb3RvID09PSBcIltvYmplY3QgRGF0ZV1cIikgcmV0dXJuIGdldERhdGVEZXRhaWxzKHZhbCk7XG5cdFx0ZWxzZSBpZiAocHJvdG8gPT09IFwiW29iamVjdCBFcnJvcl1cIikgcmV0dXJuIGBbbmF0aXZlIEVycm9yICR7dmFsLm1lc3NhZ2V9PD4ke3ZhbC5zdGFja31dYDtcblx0XHRlbHNlIGlmIChlbnN1cmVQcm9wZXJ0eUV4aXN0cyh2YWwsIFwic3RhdGVcIiwgdHJ1ZSkgJiYgZW5zdXJlUHJvcGVydHlFeGlzdHModmFsLCBcIl92bVwiLCB0cnVlKSkgcmV0dXJuIGdldFN0b3JlRGV0YWlscyh2YWwpO1xuXHRcdGVsc2UgaWYgKGlzVnVlSW5zdGFuY2UodmFsKSkge1xuXHRcdFx0Y29uc3QgY29tcG9uZW50VmFsID0gZ2V0SW5zdGFuY2VEZXRhaWxzKHZhbCk7XG5cdFx0XHRjb25zdCBwYXJlbnRJbnN0YW5jZURlcHRoID0gc2Vlbkluc3RhbmNlPy5nZXQodmFsKTtcblx0XHRcdGlmIChwYXJlbnRJbnN0YW5jZURlcHRoICYmIHBhcmVudEluc3RhbmNlRGVwdGggPCBkZXB0aCkgcmV0dXJuIGBbW0NpcmN1bGFyUmVmXV0gPCR7Y29tcG9uZW50VmFsLl9jdXN0b20uZGlzcGxheVRleHR9PmA7XG5cdFx0XHRzZWVuSW5zdGFuY2U/LnNldCh2YWwsIGRlcHRoKTtcblx0XHRcdHJldHVybiBjb21wb25lbnRWYWw7XG5cdFx0fSBlbHNlIGlmIChlbnN1cmVQcm9wZXJ0eUV4aXN0cyh2YWwsIFwicmVuZGVyXCIsIHRydWUpICYmIHR5cGVvZiB2YWwucmVuZGVyID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiBnZXRDb21wb25lbnREZWZpbml0aW9uRGV0YWlscyh2YWwpO1xuXHRcdGVsc2UgaWYgKHZhbC5jb25zdHJ1Y3RvciAmJiB2YWwuY29uc3RydWN0b3IubmFtZSA9PT0gXCJWTm9kZVwiKSByZXR1cm4gYFtuYXRpdmUgVk5vZGUgPCR7dmFsLnRhZ30+XWA7XG5cdFx0ZWxzZSBpZiAodHlwZW9mIEhUTUxFbGVtZW50ICE9PSBcInVuZGVmaW5lZFwiICYmIHZhbCBpbnN0YW5jZW9mIEhUTUxFbGVtZW50KSByZXR1cm4gZ2V0SFRNTEVsZW1lbnREZXRhaWxzKHZhbCk7XG5cdFx0ZWxzZSBpZiAodmFsLmNvbnN0cnVjdG9yPy5uYW1lID09PSBcIlN0b3JlXCIgJiYgXCJfd3JhcHBlZEdldHRlcnNcIiBpbiB2YWwpIHJldHVybiBcIltvYmplY3QgU3RvcmVdXCI7XG5cdFx0Y29uc3QgY3VzdG9tRGV0YWlscyA9IGdldE9iamVjdERldGFpbHModmFsKTtcblx0XHRpZiAoY3VzdG9tRGV0YWlscyAhPSBudWxsKSByZXR1cm4gY3VzdG9tRGV0YWlscztcblx0fSBlbHNlIGlmIChOdW1iZXIuaXNOYU4odmFsKSkgcmV0dXJuIE5BTjtcblx0cmV0dXJuIHNhbml0aXplKHZhbCk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2hhcmVkL3RyYW5zZmVyLnRzXG5jb25zdCBNQVhfU0VSSUFMSVpFRF9TSVpFID0gMiAqIDEwMjQgKiAxMDI0O1xuZnVuY3Rpb24gaXNPYmplY3QoX2RhdGEsIHByb3RvKSB7XG5cdHJldHVybiBwcm90byA9PT0gXCJbb2JqZWN0IE9iamVjdF1cIjtcbn1cbmZ1bmN0aW9uIGlzQXJyYXkoX2RhdGEsIHByb3RvKSB7XG5cdHJldHVybiBwcm90byA9PT0gXCJbb2JqZWN0IEFycmF5XVwiO1xufVxuZnVuY3Rpb24gaXNWdWVSZWFjdGl2ZUxpbmtOb2RlKG5vZGUpIHtcblx0Y29uc3QgY29uc3RydWN0b3JOYW1lID0gbm9kZT8uY29uc3RydWN0b3I/Lm5hbWU7XG5cdHJldHVybiBjb25zdHJ1Y3Rvck5hbWUgPT09IFwiRGVwXCIgJiYgXCJhY3RpdmVMaW5rXCIgaW4gbm9kZSB8fCBjb25zdHJ1Y3Rvck5hbWUgPT09IFwiTGlua1wiICYmIFwiZGVwXCIgaW4gbm9kZTtcbn1cbi8qKlxuKiBUaGlzIGZ1bmN0aW9uIGlzIHVzZWQgdG8gc2VyaWFsaXplIG9iamVjdCB3aXRoIGhhbmRsaW5nIGNpcmN1bGFyIHJlZmVyZW5jZXMuXG4qXG4qIGBgYHRzXG4qIGNvbnN0IG9iaiA9IHsgYTogMSwgYjogeyBjOiAyIH0sIGQ6IG9iaiB9XG4qIGNvbnN0IHJlc3VsdCA9IHN0cmluZ2lmeUNpcmN1bGFyQXV0b0NodW5rcyhvYmopIC8vIGNhbGwgYGVuY29kZWAgaW5zaWRlXG4qIGNvbnNvbGUubG9nKHJlc3VsdCkgLy8gW3tcImFcIjoxLFwiYlwiOjIsXCJkXCI6MH0sMSx7XCJjXCI6NH0sMl1cbiogYGBgXG4qXG4qIEVhY2ggb2JqZWN0IGlzIHN0b3JlZCBpbiBhIGxpc3QgYW5kIHRoZSBpbmRleCBpcyB1c2VkIHRvIHJlZmVyZW5jZSB0aGUgb2JqZWN0LlxuKiBXaXRoIHNlZW4gbWFwLCB3ZSBjYW4gY2hlY2sgaWYgdGhlIG9iamVjdCBpcyBhbHJlYWR5IHN0b3JlZCBpbiB0aGUgbGlzdCB0byBhdm9pZCBjaXJjdWxhciByZWZlcmVuY2VzLlxuKlxuKiBOb3RlOiBoZXJlIHdlIGhhdmUgYSBzcGVjaWFsIGNhc2UgZm9yIFZ1ZSBpbnN0YW5jZS5cbiogV2UgY2hlY2sgaWYgYSB2dWUgaW5zdGFuY2UgaW5jbHVkZXMgaXRzZWxmIGluIGl0cyBwcm9wZXJ0aWVzIGFuZCBza2lwIGl0XG4qIGJ5IHVzaW5nIGBzZWVuVnVlSW5zdGFuY2VgIGFuZCBgZGVwdGhgIHRvIGF2b2lkIGluZmluaXRlIGxvb3AuXG4qL1xuZnVuY3Rpb24gZW5jb2RlKGRhdGEsIHJlcGxhY2VyLCBsaXN0LCBzZWVuLCBkZXB0aCA9IDAsIHNlZW5WdWVJbnN0YW5jZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCkpIHtcblx0bGV0IHN0b3JlZDtcblx0bGV0IGtleTtcblx0bGV0IHZhbHVlO1xuXHRsZXQgaTtcblx0bGV0IGw7XG5cdGNvbnN0IHNlZW5JbmRleCA9IHNlZW4uZ2V0KGRhdGEpO1xuXHRpZiAoc2VlbkluZGV4ICE9IG51bGwpIHJldHVybiBzZWVuSW5kZXg7XG5cdGNvbnN0IGluZGV4ID0gbGlzdC5sZW5ndGg7XG5cdGNvbnN0IHByb3RvID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKGRhdGEpO1xuXHRpZiAoaXNPYmplY3QoZGF0YSwgcHJvdG8pKSB7XG5cdFx0aWYgKGlzVnVlUmVhY3RpdmVMaW5rTm9kZShkYXRhKSkgcmV0dXJuIGluZGV4O1xuXHRcdHN0b3JlZCA9IHt9O1xuXHRcdHNlZW4uc2V0KGRhdGEsIGluZGV4KTtcblx0XHRsaXN0LnB1c2goc3RvcmVkKTtcblx0XHRjb25zdCBrZXlzID0gT2JqZWN0LmtleXMoZGF0YSk7XG5cdFx0Zm9yIChpID0gMCwgbCA9IGtleXMubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG5cdFx0XHRrZXkgPSBrZXlzW2ldO1xuXHRcdFx0aWYgKGtleSA9PT0gXCJjb21waWxlck9wdGlvbnNcIikgcmV0dXJuIGluZGV4O1xuXHRcdFx0dmFsdWUgPSBkYXRhW2tleV07XG5cdFx0XHRjb25zdCBpc1ZtID0gdmFsdWUgIT0gbnVsbCAmJiBpc09iamVjdCh2YWx1ZSwgT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKGRhdGEpKSAmJiBpc1Z1ZUluc3RhbmNlKHZhbHVlKTtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGlmIChyZXBsYWNlcikgdmFsdWUgPSByZXBsYWNlci5jYWxsKGRhdGEsIGtleSwgdmFsdWUsIGRlcHRoLCBzZWVuVnVlSW5zdGFuY2UpO1xuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHR2YWx1ZSA9IGU7XG5cdFx0XHR9XG5cdFx0XHRzdG9yZWRba2V5XSA9IGVuY29kZSh2YWx1ZSwgcmVwbGFjZXIsIGxpc3QsIHNlZW4sIGRlcHRoICsgMSwgc2VlblZ1ZUluc3RhbmNlKTtcblx0XHRcdGlmIChpc1ZtKSBzZWVuVnVlSW5zdGFuY2UuZGVsZXRlKHZhbHVlKTtcblx0XHR9XG5cdH0gZWxzZSBpZiAoaXNBcnJheShkYXRhLCBwcm90bykpIHtcblx0XHRzdG9yZWQgPSBbXTtcblx0XHRzZWVuLnNldChkYXRhLCBpbmRleCk7XG5cdFx0bGlzdC5wdXNoKHN0b3JlZCk7XG5cdFx0Zm9yIChpID0gMCwgbCA9IGRhdGEubGVuZ3RoOyBpIDwgbDsgaSsrKSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHR2YWx1ZSA9IGRhdGFbaV07XG5cdFx0XHRcdGlmIChyZXBsYWNlcikgdmFsdWUgPSByZXBsYWNlci5jYWxsKGRhdGEsIGksIHZhbHVlLCBkZXB0aCwgc2VlblZ1ZUluc3RhbmNlKTtcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0dmFsdWUgPSBlO1xuXHRcdFx0fVxuXHRcdFx0c3RvcmVkW2ldID0gZW5jb2RlKHZhbHVlLCByZXBsYWNlciwgbGlzdCwgc2VlbiwgZGVwdGggKyAxLCBzZWVuVnVlSW5zdGFuY2UpO1xuXHRcdH1cblx0fSBlbHNlIGxpc3QucHVzaChkYXRhKTtcblx0cmV0dXJuIGluZGV4O1xufVxuZnVuY3Rpb24gZGVjb2RlKGxpc3QsIHJldml2ZXIgPSBudWxsKSB7XG5cdGxldCBpID0gbGlzdC5sZW5ndGg7XG5cdGxldCBqLCBrLCBkYXRhLCBrZXksIHZhbHVlLCBwcm90bztcblx0d2hpbGUgKGktLSkge1xuXHRcdGRhdGEgPSBsaXN0W2ldO1xuXHRcdHByb3RvID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKGRhdGEpO1xuXHRcdGlmIChwcm90byA9PT0gXCJbb2JqZWN0IE9iamVjdF1cIikge1xuXHRcdFx0Y29uc3Qga2V5cyA9IE9iamVjdC5rZXlzKGRhdGEpO1xuXHRcdFx0Zm9yIChqID0gMCwgayA9IGtleXMubGVuZ3RoOyBqIDwgazsgaisrKSB7XG5cdFx0XHRcdGtleSA9IGtleXNbal07XG5cdFx0XHRcdHZhbHVlID0gbGlzdFtkYXRhW2tleV1dO1xuXHRcdFx0XHRpZiAocmV2aXZlcikgdmFsdWUgPSByZXZpdmVyLmNhbGwoZGF0YSwga2V5LCB2YWx1ZSk7XG5cdFx0XHRcdGRhdGFba2V5XSA9IHZhbHVlO1xuXHRcdFx0fVxuXHRcdH0gZWxzZSBpZiAocHJvdG8gPT09IFwiW29iamVjdCBBcnJheV1cIikgZm9yIChqID0gMCwgayA9IGRhdGEubGVuZ3RoOyBqIDwgazsgaisrKSB7XG5cdFx0XHR2YWx1ZSA9IGxpc3RbZGF0YVtqXV07XG5cdFx0XHRpZiAocmV2aXZlcikgdmFsdWUgPSByZXZpdmVyLmNhbGwoZGF0YSwgaiwgdmFsdWUpO1xuXHRcdFx0ZGF0YVtqXSA9IHZhbHVlO1xuXHRcdH1cblx0fVxufVxuZnVuY3Rpb24gc3RyaW5naWZ5Q2lyY3VsYXJBdXRvQ2h1bmtzKGRhdGEsIHJlcGxhY2VyID0gbnVsbCwgc3BhY2UgPSBudWxsKSB7XG5cdGxldCByZXN1bHQ7XG5cdHRyeSB7XG5cdFx0cmVzdWx0ID0gYXJndW1lbnRzLmxlbmd0aCA9PT0gMSA/IEpTT04uc3RyaW5naWZ5KGRhdGEpIDogSlNPTi5zdHJpbmdpZnkoZGF0YSwgKGssIHYpID0+IHJlcGxhY2VyPy4oaywgdik/LmNhbGwodGhpcyksIHNwYWNlKTtcblx0fSBjYXRjaCAoZSkge1xuXHRcdHJlc3VsdCA9IHN0cmluZ2lmeVN0cmljdENpcmN1bGFyQXV0b0NodW5rcyhkYXRhLCByZXBsYWNlciwgc3BhY2UpO1xuXHR9XG5cdGlmIChyZXN1bHQubGVuZ3RoID4gTUFYX1NFUklBTElaRURfU0laRSkge1xuXHRcdGNvbnN0IGNodW5rQ291bnQgPSBNYXRoLmNlaWwocmVzdWx0Lmxlbmd0aCAvIE1BWF9TRVJJQUxJWkVEX1NJWkUpO1xuXHRcdGNvbnN0IGNodW5rcyA9IFtdO1xuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgY2h1bmtDb3VudDsgaSsrKSBjaHVua3MucHVzaChyZXN1bHQuc2xpY2UoaSAqIE1BWF9TRVJJQUxJWkVEX1NJWkUsIChpICsgMSkgKiBNQVhfU0VSSUFMSVpFRF9TSVpFKSk7XG5cdFx0cmV0dXJuIGNodW5rcztcblx0fVxuXHRyZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gc3RyaW5naWZ5U3RyaWN0Q2lyY3VsYXJBdXRvQ2h1bmtzKGRhdGEsIHJlcGxhY2VyID0gbnVsbCwgc3BhY2UgPSBudWxsKSB7XG5cdGNvbnN0IGxpc3QgPSBbXTtcblx0ZW5jb2RlKGRhdGEsIHJlcGxhY2VyLCBsaXN0LCAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpKTtcblx0cmV0dXJuIHNwYWNlID8gYCAke0pTT04uc3RyaW5naWZ5KGxpc3QsIG51bGwsIHNwYWNlKX1gIDogYCAke0pTT04uc3RyaW5naWZ5KGxpc3QpfWA7XG59XG5mdW5jdGlvbiBwYXJzZUNpcmN1bGFyQXV0b0NodW5rcyhkYXRhLCByZXZpdmVyID0gbnVsbCkge1xuXHRpZiAoQXJyYXkuaXNBcnJheShkYXRhKSkgZGF0YSA9IGRhdGEuam9pbihcIlwiKTtcblx0aWYgKCEvXlxccy8udGVzdChkYXRhKSkgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPT09IDEgPyBKU09OLnBhcnNlKGRhdGEpIDogSlNPTi5wYXJzZShkYXRhLCByZXZpdmVyKTtcblx0ZWxzZSB7XG5cdFx0Y29uc3QgbGlzdCA9IEpTT04ucGFyc2UoZGF0YSk7XG5cdFx0ZGVjb2RlKGxpc3QsIHJldml2ZXIpO1xuXHRcdHJldHVybiBsaXN0WzBdO1xuXHR9XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvc2hhcmVkL3V0aWwudHNcbmZ1bmN0aW9uIHN0cmluZ2lmeShkYXRhKSB7XG5cdHJldHVybiBzdHJpbmdpZnlDaXJjdWxhckF1dG9DaHVua3MoZGF0YSwgc3RyaW5naWZ5UmVwbGFjZXIpO1xufVxuZnVuY3Rpb24gcGFyc2UoZGF0YSwgcmV2aXZlID0gZmFsc2UpIHtcblx0aWYgKGRhdGEgPT0gdm9pZCAwKSByZXR1cm4ge307XG5cdHJldHVybiByZXZpdmUgPyBwYXJzZUNpcmN1bGFyQXV0b0NodW5rcyhkYXRhLCByZXZpdmVyKSA6IHBhcnNlQ2lyY3VsYXJBdXRvQ2h1bmtzKGRhdGEpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2luZGV4LnRzXG5jb25zdCBkZXZ0b29scyA9IHtcblx0aG9vayxcblx0aW5pdDogKCkgPT4ge1xuXHRcdGluaXREZXZUb29scygpO1xuXHR9LFxuXHRnZXQgY3R4KCkge1xuXHRcdHJldHVybiBkZXZ0b29sc0NvbnRleHQ7XG5cdH0sXG5cdGdldCBhcGkoKSB7XG5cdFx0cmV0dXJuIGRldnRvb2xzQ29udGV4dC5hcGk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IERldlRvb2xzQ29udGV4dEhvb2tLZXlzLCBEZXZUb29sc01lc3NhZ2luZ0hvb2tLZXlzLCBEZXZUb29sc1Y2UGx1Z2luQVBJSG9va0tleXMsIElORklOSVRZLCBOQU4sIE5FR0FUSVZFX0lORklOSVRZLCBST1VURVJfSU5GT19LRVksIFJPVVRFUl9LRVksIFVOREVGSU5FRCwgYWN0aXZlQXBwUmVjb3JkLCBhZGRDdXN0b21Db21tYW5kLCBhZGRDdXN0b21UYWIsIGFkZERldlRvb2xzQXBwUmVjb3JkLCBhZGREZXZUb29sc1BsdWdpblRvQnVmZmVyLCBhZGRJbnNwZWN0b3IsIGNhbGxDb25uZWN0ZWRVcGRhdGVkSG9vaywgY2FsbERldlRvb2xzUGx1Z2luU2V0dXBGbiwgY2FsbEluc3BlY3RvclVwZGF0ZWRIb29rLCBjYWxsU3RhdGVVcGRhdGVkSG9vaywgY3JlYXRlQ29tcG9uZW50c0RldlRvb2xzUGx1Z2luLCBjcmVhdGVEZXZUb29sc0FwaSwgY3JlYXRlRGV2VG9vbHNDdHhIb29rcywgY3JlYXRlUnBjQ2xpZW50LCBjcmVhdGVScGNQcm94eSwgY3JlYXRlUnBjU2VydmVyLCBkZXZ0b29scywgZGV2dG9vbHNBcHBSZWNvcmRzLCBkZXZ0b29sc0NvbnRleHQsIGRldnRvb2xzSW5zcGVjdG9yLCBkZXZ0b29sc1BsdWdpbkJ1ZmZlciwgZGV2dG9vbHNSb3V0ZXIsIGRldnRvb2xzUm91dGVySW5mbywgZGV2dG9vbHNTdGF0ZSwgZXNjYXBlLCBmb3JtYXRJbnNwZWN0b3JTdGF0ZVZhbHVlLCBnZXRBY3RpdmVJbnNwZWN0b3JzLCBnZXREZXZUb29sc0VudiwgZ2V0RXh0ZW5zaW9uQ2xpZW50Q29udGV4dCwgZ2V0SW5zcGVjdG9yLCBnZXRJbnNwZWN0b3JBY3Rpb25zLCBnZXRJbnNwZWN0b3JJbmZvLCBnZXRJbnNwZWN0b3JOb2RlQWN0aW9ucywgZ2V0SW5zcGVjdG9yU3RhdGVWYWx1ZVR5cGUsIGdldFJhdywgZ2V0UnBjQ2xpZW50LCBnZXRScGNTZXJ2ZXIsIGdldFZpdGVScGNDbGllbnQsIGdldFZpdGVScGNTZXJ2ZXIsIGluaXREZXZUb29scywgaXNQbGFpbk9iamVjdCwgb25EZXZUb29sc0NsaWVudENvbm5lY3RlZCwgb25EZXZUb29sc0Nvbm5lY3RlZCwgcGFyc2UsIHJlZ2lzdGVyRGV2VG9vbHNQbHVnaW4sIHJlbW92ZUN1c3RvbUNvbW1hbmQsIHJlbW92ZURldlRvb2xzQXBwUmVjb3JkLCByZW1vdmVSZWdpc3RlcmVkUGx1Z2luQXBwLCByZXNldERldlRvb2xzU3RhdGUsIHNldEFjdGl2ZUFwcFJlY29yZCwgc2V0QWN0aXZlQXBwUmVjb3JkSWQsIHNldERldlRvb2xzRW52LCBzZXRFbGVjdHJvbkNsaWVudENvbnRleHQsIHNldEVsZWN0cm9uUHJveHlDb250ZXh0LCBzZXRFbGVjdHJvblNlcnZlckNvbnRleHQsIHNldEV4dGVuc2lvbkNsaWVudENvbnRleHQsIHNldElmcmFtZVNlcnZlckNvbnRleHQsIHNldE9wZW5JbkVkaXRvckJhc2VVcmwsIHNldFJwY1NlcnZlclRvR2xvYmFsLCBzZXRWaXRlQ2xpZW50Q29udGV4dCwgc2V0Vml0ZVJwY0NsaWVudFRvR2xvYmFsLCBzZXRWaXRlUnBjU2VydmVyVG9HbG9iYWwsIHNldFZpdGVTZXJ2ZXJDb250ZXh0LCBzZXR1cERldlRvb2xzUGx1Z2luLCBzdHJpbmdpZnksIHRvRWRpdCwgdG9TdWJtaXQsIHRvZ2dsZUNsaWVudENvbm5lY3RlZCwgdG9nZ2xlQ29tcG9uZW50SW5zcGVjdG9yRW5hYmxlZCwgdG9nZ2xlSGlnaFBlcmZNb2RlLCB1cGRhdGVEZXZUb29sc0NsaWVudERldGVjdGVkLCB1cGRhdGVEZXZUb29sc1N0YXRlLCB1cGRhdGVUaW1lbGluZUxheWVyc1N0YXRlIH07XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDblIsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDeEwsTUFBTSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQzNLLE1BQU0sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3ZMLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUM7QUFDN0IsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDNUIsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWM7QUFDckMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsd0JBQXdCO0FBQ3RELEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQjtBQUNsRCxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsY0FBYztBQUN4QyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWM7QUFDbEQsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUM7QUFDckcsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2SixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDeEUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDeEMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDN0QsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxFQUFFO0FBQ1YsQ0FBQztBQUNELEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUN0TCxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUc7QUFDWCxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO0FBQzNCLFFBQVEsQ0FBQyxrQ0FBa0MsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNoRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO0FBQ25ELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxNQUFNO0FBQ1IsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHFDQUFxQyxDQUFDLENBQUMsQ0FBQztBQUN4RSxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7QUFDekMsUUFBUSxDQUFDLG9CQUFvQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLHNDQUFzQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNO0FBQ3ZILENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ3pFLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDWjtBQUNBLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN2QyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNO0FBQzVCLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDbEQ7QUFDQSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGFBQWE7QUFDMUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUN0QixDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLENBQUM7QUFDckM7QUFDQSxRQUFRLENBQUMsdUJBQXVCLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakQsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHNDQUFzQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQzVELENBQUMsTUFBTSxDQUFDLElBQUk7QUFDWjtBQUNBLFFBQVEsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDaEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsZ0NBQWdDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGdDQUFnQztBQUNoRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLGdDQUFnQztBQUN4RjtBQUNBLEtBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ3ZDLENBQUMsR0FBRyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMseUJBQXlCO0FBQ25GLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQztBQUMzQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUM3QixDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDcEQsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkO0FBQ0EsUUFBUSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM5QixDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJO0FBQzNDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQztBQUN6QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ2pFLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDYjtBQUNBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNwQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVc7QUFDMUQ7QUFDQSxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFFBQVE7QUFDbEQ7QUFDQSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU07QUFDakIsQ0FBQztBQUNELFFBQVEsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDbkMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUN0QixDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMvQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsdUJBQXVCLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2hLLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLHVCQUF1QixDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUM3SixDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRO0FBQzlCLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQztBQUM3QjtBQUNBLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxRQUFRO0FBQzNDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2YsQ0FBQztBQUNELFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN4QyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDdkk7QUFDQSxRQUFRLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzdCLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQzVDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUN4RCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzlDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNyQjtBQUNBLFFBQVEsQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDekIsQ0FBQyxHQUFHLENBQUM7QUFDTCxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDVixDQUFDO0FBQ0Q7QUFDQSxRQUFRLENBQUMsb0JBQW9CLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDckQsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2xELENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNuRjtBQUNBLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzlELENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDaEc7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztBQUNqRCxRQUFRLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUk7QUFDaEMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUc7QUFDaEMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUNaO0FBQ0EsR0FBRyxDQUFDLEtBQUs7QUFDVCxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzNCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUMzQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDO0FBQ3ZCLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0FBQ3JDO0FBQ0EsUUFBUSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNoQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQzFCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDakMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUztBQUNmLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDO0FBQ3RGLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxFQUFFO0FBQzNCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLHFCQUFxQixDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMscUJBQXFCLENBQUMsQ0FBQztBQUM1RixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7QUFDNUUsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDNUMsQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLElBQUk7QUFDWjtBQUNBLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQzNDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUMxRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDaEQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3JELENBQUMsTUFBTSxDQUFDLENBQUM7QUFDVDtBQUNBLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNSLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsTUFBTSxDQUFDLENBQUM7QUFDVCxDQUFDO0FBQ0QsUUFBUSxDQUFDLHdCQUF3QixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFO0FBQy9CLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWTtBQUN2RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztBQUNuRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQztBQUNoRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztBQUNqRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWTtBQUN6QjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7QUFDckMsUUFBUSxDQUFDLG9DQUFvQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3hELENBQUMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLHVCQUF1QixDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7QUFDM0UsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7QUFDN0I7QUFDQSxRQUFRLENBQUMsdUJBQXVCLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsb0NBQW9DLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3BHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDO0FBQ25ELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUNaO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQztBQUMvQyxLQUFLLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDO0FBQ25FLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsaUJBQWlCLENBQUM7QUFDcEUsS0FBSyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDO0FBQzlFLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsQ0FBQztBQUM5RSxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2pCLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVTtBQUNuQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2xCLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUM3QixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUM5QixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ3BCLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO0FBQy9CLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3JCLENBQUM7QUFDRCxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUMzQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUNuQixDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ3BCLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDbEIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNyQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDakIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNqQixDQUFDLFVBQVUsQ0FBQyxDQUFDLEdBQUc7QUFDaEIsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNuQixDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDM0IsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUUsQ0FBQztBQUNELEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO0FBQ3hCLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRztBQUNoQixDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ3BCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDakIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQztBQUNELFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxvQkFBb0IsQ0FBQztBQUNyRDtBQUNBLFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsZUFBZSxDQUFDO0FBQ2hEO0FBQ0EsUUFBUSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQztBQUMvQixDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLG9CQUFvQixDQUFDO0FBQ3JEO0FBQ0EsUUFBUSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyx5QkFBeUIsQ0FBQztBQUMxRDtBQUNBLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDM0IsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztBQUNsRCxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztBQUNoRCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztBQUNwRCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7QUFDckQsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3pCLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2xELENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxvQkFBb0I7QUFDM0QsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZTtBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDOUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxlQUFlO0FBQzVCLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVU7QUFDZixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMzQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzlDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMseUJBQXlCO0FBQ3RDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3pELENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hELENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsb0JBQW9CO0FBQ3RDLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzdILENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsZUFBZSxDQUFDO0FBQ2xELENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUM7QUFDM0IsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQztBQUNoQyxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDO0FBQ2hDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDO0FBQ3ZDLENBQUMsTUFBTSxDQUFDLFdBQVc7QUFDbkI7QUFDQSxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3pCLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUMxQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQzFDLENBQUMsRUFBRSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWU7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxNQUFNO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3RSxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzFELENBQUMsQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDOUgsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM3QixDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLFFBQVEsQ0FBQztBQUNsRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNO0FBQzVDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQztBQUN2QyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxNQUFNO0FBQ1IsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLE1BQU07QUFDUixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2xDO0FBQ0EsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMxQixRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDeEIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsb0JBQW9CO0FBQzlDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDN0IsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLFFBQVEsQ0FBQztBQUNyRCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0Q7QUFDQSxRQUFRLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDcEIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxFQUFFLENBQUMsb0JBQW9CLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDL0Q7QUFDQSxHQUFHLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDOUMsUUFBUSxDQUFDLGlDQUFpQyxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNuRCxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDL0UsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMzQztBQUNBLFFBQVEsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNoRCxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDdkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNyQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLG1DQUFtQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2hELENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNsRCxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsUUFBUSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3BDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7QUFDekUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsb0NBQW9DLENBQUMsUUFBUSxDQUFDO0FBQzdELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4RixDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsUUFBUSxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNyRCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUM1QyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEQsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNWLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsUUFBUSxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDdEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDVixDQUFDO0FBQ0Q7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDO0FBQzdDLE1BQU0sQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDNUQsUUFBUSxDQUFDLCtCQUErQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2xELENBQUMsTUFBTSxDQUFDLDRDQUE0QyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQzlEO0FBQ0EsUUFBUSxDQUFDLG9CQUFvQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ2QsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7QUFDeEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDUDtBQUNBLFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQjtBQUMzQyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxZQUFZO0FBQzdDLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUMxQixDQUFDLENBQUM7QUFDRjtBQUNBLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDO0FBQ3BDLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVELENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQzlCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ2hGLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLE1BQU07QUFDbEMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLHdDQUF3QyxDQUFDO0FBQy9FLENBQUM7QUFDRCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsd0NBQXdDLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsR0FBRztBQUNsSixDQUFDO0FBQ0QsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQzVELENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbkMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQztBQUNoRCxDQUFDLGFBQWEsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDO0FBQ2hELENBQUMsYUFBYSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUM7QUFDOUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNqQyxDQUFDLE1BQU0sQ0FBQyxhQUFhO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyx3Q0FBd0MsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJO0FBQ25KLENBQUM7QUFDRCxRQUFRLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzNCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3JEO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLHdDQUF3QyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUk7QUFDbkosQ0FBQztBQUNELFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzdCLENBQUMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNyRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNyRDtBQUNBLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3JDO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLHdDQUF3QyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUk7QUFDbkosQ0FBQztBQUNELFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzNCLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDO0FBQ3BELENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNyQztBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7QUFDMUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3hCLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDdkMsQ0FBQztBQUNELENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvRCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQztBQUMxRCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDaEYsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO0FBQ3hFLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEQsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDbEMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUN0RSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUM1QixDQUFDO0FBQ0QsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9ELENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlELENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztBQUN4RSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDZixDQUFDO0FBQ0QsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNqRCxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2RSxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztBQUN4RSxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRixDQUFDO0FBQ0QsQ0FBQyx3QkFBd0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZGLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztBQUNoRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDN0YsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDdkUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNyRixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztBQUM5RCxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUM5QyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNELENBQUM7QUFDRCxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDM0IsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3JDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNWLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNWLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNsRCxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3JFLENBQUMsQ0FBQztBQUNGLENBQUM7QUFDRCxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRztBQUN2QyxDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDMUMsQ0FBQztBQUNELENBQUM7QUFDRCxLQUFLLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3hELENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQzlDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNyRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTTtBQUN0QixDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNoQyxDQUFDLEdBQUcsQ0FBQyxNQUFNO0FBQ1gsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLO0FBQzNFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLHFCQUFxQjtBQUNsSixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUk7QUFDL0YsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSztBQUM3QixDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkQsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsQ0FBQyx3QkFBd0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMvRixDQUFDO0FBQ0Q7QUFDQSxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDckMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxXQUFXLENBQUM7QUFDekM7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7QUFDcEMsS0FBSyxDQUFDLGdDQUFnQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDBDQUEwQyxDQUFDO0FBQ3JGLFFBQVEsQ0FBQywrQkFBK0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNoRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU07QUFDdkYsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLGdDQUFnQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM5RTtBQUNBLFFBQVEsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDekgsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLEtBQUs7QUFDdkIsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsS0FBSztBQUMxQixDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxLQUFLO0FBQzdCLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLEtBQUs7QUFDOUIsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsS0FBSztBQUNoQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQztBQUNGLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLGdDQUFnQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDMUgsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsS0FBSztBQUN2QixDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxLQUFLO0FBQzFCLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLEtBQUs7QUFDN0IsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsS0FBSztBQUM5QixDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxLQUFLO0FBQ2hDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztBQUMzQixNQUFNLENBQUMsa0NBQWtDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEQsS0FBSyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDbEgsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUMvQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDekQsQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDWixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsVUFBVSxDQUFDLEVBQUU7QUFDN0IsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsR0FBRztBQUN4QyxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsUUFBUSxDQUFDLHlCQUF5QixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUI7QUFDdEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBQ0YsQ0FBQywrQkFBK0IsQ0FBQyxZQUFZLENBQUM7QUFDOUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0FBQzNEO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7QUFDNUIsTUFBTSxDQUFDLDhCQUE4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3pHLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixLQUFLLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLHlCQUF5QixDQUFDLHdCQUF3QixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO0FBQzFHLENBQUMsQ0FBQztBQUNGLFFBQVEsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDN0MsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUM7QUFDeEIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVM7QUFDcEIsQ0FBQyxDQUFDLFVBQVU7QUFDWixDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQyxTQUFTLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVFLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0UsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLEdBQUc7QUFDeEMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLHdCQUF3QixDQUFDLENBQUM7QUFDM0I7QUFDQSxRQUFRLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzTCxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVU7QUFDekMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPO0FBQ25DLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRTtBQUNqQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSztBQUN2QixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSTtBQUN4QixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsVUFBVSxDQUFDLFdBQVc7QUFDdEMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVE7QUFDaEMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUM5QixDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUM5RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTTtBQUN2QixDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFVO0FBQ3hDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU87QUFDbEMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEgsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQ2IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLO0FBQ25CLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUU7QUFDaEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLO0FBQ3RCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSTtBQUN2QixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsVUFBVSxDQUFDLFdBQVc7QUFDckMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxRQUFRO0FBQy9CLENBQUMsQ0FBQyxjQUFjO0FBQ2hCLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxxQkFBcUI7QUFDeEQsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3BDLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUMvQixDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzdIO0FBQ0EsUUFBUSxDQUFDLG1CQUFtQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPO0FBQ3pDO0FBQ0EsUUFBUSxDQUFDLHVCQUF1QixDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXO0FBQzdDO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7QUFDdkIsR0FBRyxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsMkJBQTJCLENBQUMsQ0FBQztBQUN4RixDQUFDLDJCQUEyQixDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDO0FBQzNFLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUM7QUFDdEUsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztBQUMzRSxDQUFDLDJCQUEyQixDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDO0FBQ3ZFLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUM7QUFDekUsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztBQUMzRSxDQUFDLDJCQUEyQixDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDO0FBQy9FLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDO0FBQ3BFLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUM7QUFDekUsQ0FBQyxNQUFNLENBQUMsMkJBQTJCO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDLENBQUM7QUFDaEYsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDO0FBQzFELENBQUMsdUJBQXVCLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUM7QUFDckUsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztBQUN2RSxDQUFDLHVCQUF1QixDQUFDLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHlCQUF5QixDQUFDO0FBQ3RGLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUM7QUFDdkUsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztBQUN2RSxDQUFDLHVCQUF1QixDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDO0FBQzdFLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUM7QUFDdkUsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQztBQUNuRSxDQUFDLHVCQUF1QixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDO0FBQ3RFLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUM7QUFDMUUsQ0FBQyxNQUFNLENBQUMsdUJBQXVCO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLHlCQUF5QixDQUFDLENBQUM7QUFDcEYsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLDZCQUE2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQztBQUN6RixDQUFDLHlCQUF5QixDQUFDLENBQUMsOEJBQThCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDBCQUEwQixDQUFDO0FBQzNGLENBQUMseUJBQXlCLENBQUMsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMseUJBQXlCLENBQUM7QUFDekYsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQztBQUNoRixDQUFDLHlCQUF5QixDQUFDLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDRCQUE0QixDQUFDO0FBQ2xHLENBQUMseUJBQXlCLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUM7QUFDN0UsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQztBQUNyRixDQUFDLHlCQUF5QixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDO0FBQ3ZFLENBQUMsTUFBTSxDQUFDLHlCQUF5QjtBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxRQUFRLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5RSxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEtBQUssQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0UsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU07QUFDM0YsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQztBQUNwRSxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHO0FBQzdCLENBQUMsQ0FBQyxDQUFDLFdBQVc7QUFDZCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDMUQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLGtCQUFrQixDQUFDO0FBQ3JELENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMseUJBQXlCLENBQUMsNkJBQTZCLENBQUM7QUFDN0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDUixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsbUJBQW1CLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQztBQUNuRixDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEYsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU07QUFDM0YsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQztBQUNwRSxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxHQUFHO0FBQzdCLENBQUMsQ0FBQyxDQUFDLFdBQVc7QUFDZCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9ELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0RCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQy9ELENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxtQkFBbUIsQ0FBQztBQUN0RCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVc7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMseUJBQXlCLENBQUMsOEJBQThCLENBQUM7QUFDOUQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDUixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsb0JBQW9CLENBQUMsQ0FBQywwQkFBMEIsQ0FBQztBQUNyRixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQztBQUNwRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNO0FBQ3hCLENBQUMsQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ25DLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25GLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25GLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ3JDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUN4RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMseUJBQXlCLENBQUMsNkJBQTZCLENBQUM7QUFDN0QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hGLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsZ0NBQWdDO0FBQ3hELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQzdCLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbEgsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsdUJBQXVCLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xGLENBQUMsQ0FBQyxNQUFNLENBQUMsd0JBQXdCLENBQUMsUUFBUSxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLHVCQUF1QixDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFFLENBQUMsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0RSxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUM3RCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pFLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNiO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7QUFDeEIsTUFBTSxDQUFDLGdDQUFnQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDLE1BQU0sQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRCxNQUFNLENBQUMseUNBQXlDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkQsTUFBTSxDQUFDLGdDQUFnQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDLE1BQU0sQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRCxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlDQUFpQyxDQUFDO0FBQ3JELFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBSztBQUNsQixDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsS0FBSztBQUN4QixDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJO0FBQzFCLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsSUFBSTtBQUMzQixDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxpQ0FBaUMsQ0FBQztBQUN6RCxDQUFDLENBQUM7QUFDRjtBQUNBLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDeEMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRCxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLHlCQUF5QixDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDNUYsQ0FBQyxDQUFDO0FBQ0YsS0FBSyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvRCxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLHlCQUF5QixDQUFDLDBCQUEwQixDQUFDLENBQUM7QUFDdEYsQ0FBQyxDQUFDLEtBQUs7QUFDUCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQztBQUNGLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsZ0NBQWdDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzdHLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsZ0NBQWdDO0FBQ3JFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxnQ0FBZ0MsQ0FBQyxJQUFJLENBQUM7QUFDckQsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QyxDQUFDLE1BQU0sQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0NBQWdDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDNUYsQ0FBQztBQUNELEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLE1BQU0sQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDMUcsQ0FBQztBQUNELEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLHNDQUFzQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNoSCxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLHNDQUFzQztBQUMzRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyx5Q0FBeUM7QUFDaEYsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLHNDQUFzQyxDQUFDLElBQUksQ0FBQztBQUMzRCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxvQkFBb0IsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQztBQUN0QixDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsa0JBQWtCLENBQUMsS0FBSztBQUN0QyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxlQUFlLENBQUMsRUFBRTtBQUN2QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLGdDQUFnQztBQUMvQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxRQUFRLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDakMsQ0FBQyxNQUFNLENBQUMsc0NBQXNDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDcEQsQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUNsQjtBQUNBLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNsQyxDQUFDLE1BQU0sQ0FBQyx5Q0FBeUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUN0RCxDQUFDLGVBQWUsQ0FBQyxDQUFDO0FBQ2xCO0FBQ0EsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCO0FBQzFELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxFQUFFO0FBQ3RFLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsZ0NBQWdDO0FBQzlFLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsb0NBQW9DO0FBQ3RGLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNwQyxDQUFDLENBQUM7QUFDRixDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7QUFDekIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQ2IsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzVCLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDckMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQ2IsQ0FBQztBQUNELENBQUMsQ0FBQztBQUNGLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztBQUNyRDtBQUNBLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNwQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLO0FBQ3RDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLGVBQWUsQ0FBQztBQUNyQyxDQUFDLENBQUM7QUFDRixDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNwTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3hDLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDbEI7QUFDQSxRQUFRLENBQUMsbUJBQW1CLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDakMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTTtBQUNsQixDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM3RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDNUQsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDcEMsQ0FBQztBQUNELFFBQVEsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0NBQWdDO0FBQ3JELENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ2xELENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ1IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSTtBQUM1QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsZUFBZSxDQUFDLENBQUM7QUFDbEI7QUFDQSxRQUFRLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDbEMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsb0NBQW9DO0FBQzdELENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ3JELENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ1gsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNYLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsSUFBSTtBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLGVBQWUsQ0FBQyxDQUFDO0FBQ2xCO0FBQ0EsUUFBUSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLG9DQUFvQztBQUM3RCxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQzNELENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ3pCLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUNsQjtBQUNBLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN0QyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ2hEO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDeEMsUUFBUSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsTUFBTSxDQUFDLHdDQUF3QyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ3REO0FBQ0EsUUFBUSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUN2RixDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN2RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsa0JBQWtCLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsd0NBQXdDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUM5RSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN0RSxDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0Q7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztBQUN6QixNQUFNLENBQUMsa0NBQWtDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEQsS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDaEgsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzlELENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN2RDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7QUFDMUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNoQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFlBQVk7QUFDN0MsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLE1BQU0sQ0FBQyxTQUFTO0FBQ2pCO0FBQ0EsUUFBUSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsTUFBTSxDQUFDLENBQUMscUNBQXFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDO0FBQzVEO0FBQ0EsUUFBUSxDQUFDLHdCQUF3QixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVDLENBQUMsTUFBTSxDQUFDLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDNUg7QUFDQSxRQUFRLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDcEQsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUM7QUFDN0MsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztBQUN0RCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDO0FBQ3JELENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9ILENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUM7QUFDbkM7QUFDQSxRQUFRLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDaEQsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUM7QUFDN0MsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDNUc7QUFDQSxRQUFRLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDakQsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUM7QUFDN0MsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztBQUNyRCxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlELENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQjtBQUN4QixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25ELENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDWCxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ04sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUs7QUFDbEIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLG1CQUFtQixDQUFDO0FBQ3BEO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFDekIsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQzVELENBQUMsYUFBYSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0FBQ3ZDLENBQUMsYUFBYSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDO0FBQzdDLENBQUMsYUFBYSxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUM7QUFDekQsQ0FBQyxhQUFhLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7QUFDckQsQ0FBQyxhQUFhLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQztBQUN6RCxDQUFDLGFBQWEsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztBQUNuRCxDQUFDLGFBQWEsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQ2xELENBQUMsYUFBYSxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQzlDLENBQUMsYUFBYSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztBQUNoRCxDQUFDLGFBQWEsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDdEQsQ0FBQyxhQUFhLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDbkQsQ0FBQyxhQUFhLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQztBQUN2RCxDQUFDLGFBQWEsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztBQUNqRCxDQUFDLGFBQWEsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztBQUNqRSxDQUFDLE1BQU0sQ0FBQyxhQUFhO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQ3pCLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ2xFLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNoRCxDQUFDLENBQUM7QUFDRixDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ25ELENBQUMsQ0FBQztBQUNGLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDckQsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxlQUFlLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDOUQsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDN0QsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2hFLENBQUMsQ0FBQztBQUNGLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNoRSxDQUFDLENBQUM7QUFDRixDQUFDLG1CQUFtQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUM3RCxDQUFDLENBQUM7QUFDRixDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDaEUsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUM5RCxDQUFDO0FBQ0QsQ0FBQztBQUNELFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztBQUN6QixDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLO0FBQ2hCLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUQsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7QUFDakQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztBQUM1QyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckQsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDckYsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxRQUFRLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDckMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNO0FBQ2xELENBQUMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDckUsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUN4RCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEYsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxNQUFNO0FBQ3ZGLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU07QUFDbkUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUN2RixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxNQUFNO0FBQ3hHLENBQUMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUN6RixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsTUFBTTtBQUN4RyxDQUFDLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDekYsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9FLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxNQUFNO0FBQ3BFLENBQUMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxjQUFjLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDcEYsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4RSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsTUFBTTtBQUN2RCxDQUFDLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDbkYsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU07QUFDdkQsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNqRixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxhQUFhLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEYsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQzFDLENBQUMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3hGLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsRUFBRTtBQUNILENBQUMsbUJBQW1CLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLHFCQUFxQixDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDL0YsQ0FBQztBQUNELENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7QUFDM0IsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUs7QUFDeEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDdEIsQ0FBQztBQUNELENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDOUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLGlCQUFpQixDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzNFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUM5RSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDNUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLG1CQUFtQixDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzdFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUM5RSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDaEYsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUMxRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDN0UsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxNQUFNO0FBQy9DLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQztBQUMzRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUFHO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUc7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNwRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDO0FBQ2pFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDLG9CQUFvQixDQUFDLENBQUM7QUFDckUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRTtBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0QsQ0FBQyxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQzdELENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU87QUFDckIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQztBQUN0RyxDQUFDO0FBQ0QsQ0FBQyxpQkFBaUIsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsTUFBTTtBQUMvQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsdUJBQXVCLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUNuRSxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ2QsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDO0FBQ0QsQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsTUFBTTtBQUMvQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsdUJBQXVCLENBQUMsb0JBQW9CLENBQUMsQ0FBQztBQUNwRSxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ2QsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDO0FBQ0QsQ0FBQyxtQkFBbUIsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsdUJBQXVCLENBQUMsNEJBQTRCLENBQUMsQ0FBQztBQUM1RSxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ2QsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNULENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUNELENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQywyQkFBMkIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUN2RixDQUFDO0FBQ0QsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ25CLENBQUM7QUFDRCxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0FBQ3BFLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDVixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUM7QUFDRCxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxNQUFNO0FBQy9DLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0FBQ3BFLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDVixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUM7QUFDRCxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUM7QUFDbEcsQ0FBQztBQUNELENBQUMscUJBQXFCLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ3RGLENBQUM7QUFDRCxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsdUJBQXVCLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUN4RixDQUFDO0FBQ0QsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDdEYsQ0FBQztBQUNELENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyx5QkFBeUI7QUFDaEQsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ2xGLENBQUM7QUFDRCxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLHVCQUF1QixDQUFDLHFCQUFxQixDQUFDO0FBQzNFLENBQUM7QUFDRCxDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7QUFDeEIsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxtQkFBbUI7QUFDN0MsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztBQUM3QyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDWCxDQUFDLENBQUMsZUFBZSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQztBQUN2QixDQUFDLENBQUMsbUJBQW1CLENBQUM7QUFDdEIsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNOLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDWCxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ1gsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNYLENBQUMsQ0FBQyxXQUFXLENBQUM7QUFDZCxDQUFDLENBQUMsZUFBZSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxlQUFlLENBQUM7QUFDbEIsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNSLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDUixDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNSLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVCxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUNiLENBQUMsQ0FBQyxVQUFVLENBQUM7QUFDYixDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUNiLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDWixDQUFDLENBQUMsZUFBZSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxlQUFlLENBQUM7QUFDbEIsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNSLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDVixDQUFDLENBQUMsV0FBVyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLGVBQWUsQ0FBQztBQUNsQixDQUFDLENBQUMsY0FBYyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDWixDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ1osQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUNkLENBQUMsQ0FBQyxhQUFhLENBQUM7QUFDaEIsQ0FBQyxDQUFDLGNBQWMsQ0FBQztBQUNqQixDQUFDLENBQUMsZUFBZSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxlQUFlLENBQUM7QUFDbEIsQ0FBQyxDQUFDLGVBQWUsQ0FBQztBQUNsQixDQUFDLENBQUMsaUJBQWlCLENBQUM7QUFDcEIsQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUNkLENBQUMsQ0FBQyxhQUFhLENBQUM7QUFDaEIsQ0FBQyxDQUFDLGdCQUFnQixDQUFDO0FBQ25CLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDVixDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxVQUFVLENBQUM7QUFDYixDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNWLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQztBQUNuQixDQUFDLENBQUMsZ0JBQWdCLENBQUM7QUFDbkIsQ0FBQyxDQUFDLGNBQWMsQ0FBQztBQUNqQixDQUFDLENBQUMsYUFBYTtBQUNmLENBQUMsQ0FBQztBQUNGLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JELEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQzNCLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDMUIsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQztBQUM3QyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDO0FBQzNDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQ0FBaUMsQ0FBQztBQUM3RCxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDO0FBQ2pDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ1osQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7QUFDdEMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM5QixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDcEQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUMxQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM5QztBQUNBLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNqRTtBQUNBLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzdCLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQzlCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDekIsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3BFO0FBQ0EsUUFBUSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNwQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVM7QUFDdkI7QUFDQSxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU07QUFDbEM7QUFDQSxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsY0FBYztBQUM1QjtBQUNBLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDekIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxjQUFjO0FBQzVCO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztBQUN4QyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUN6QixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDaEMsQ0FBQztBQUNELEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEYsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDakIsQ0FBQyxNQUFNLENBQUMsR0FBRztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sUUFBUSxDQUFDLDBCQUEwQixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzNDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2xDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzdEO0FBQ0EsUUFBUSxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3JDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9FLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDNUQ7QUFDQSxRQUFRLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDckMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNwRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRixDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVFO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsTUFBTTtBQUN6QyxDQUFDO0FBQ0QsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMzQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUM3RSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDaEMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO0FBQzlDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ3ZFO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSTtBQUM5QyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLO0FBQ3hELENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUs7QUFDM0QsQ0FBQztBQUNELFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDeEIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDdEgsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDakI7QUFDQSxRQUFRLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxHQUFHLENBQUM7QUFDTCxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUc7QUFDM0IsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDVCxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSztBQUNiLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUs7QUFDbEIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSztBQUNsQixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQztBQUNEO0FBQ0EsUUFBUSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN0QixDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTztBQUN6QyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2I7QUFDQSxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUMzQyxRQUFRLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPO0FBQ3BELENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRTtBQUNyQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNqRCxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQzdELENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDL0QsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNoRyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNuQyxDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsRUFBRTtBQUNWO0FBQ0EsUUFBUSxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSTtBQUMzQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUNoRCxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsTUFBTTtBQUNoRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHO0FBQ25FLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNoRSxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDckMsQ0FBQyxNQUFNLENBQUMsT0FBTztBQUNmO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsUUFBUTtBQUNsQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUM7QUFDN0QsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQVM7QUFDN0Q7QUFDQSxDQUFDO0FBQ0QsUUFBUSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNoQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUs7QUFDOUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDdEUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7QUFDbkMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXO0FBQ25CLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUk7QUFDakIsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ3hFLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxRQUFRO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUNELENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDYjtBQUNBLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVztBQUMzRDtBQUNBLENBQUM7QUFDRCxRQUFRLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUk7QUFDM0IsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLO0FBQzFCLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU87QUFDL0MsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUTtBQUNuQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDZCxDQUFDLENBQUM7QUFDRixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1SixDQUFDLENBQUMsR0FBRztBQUNMLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNkLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSjtBQUNBLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNuQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDcEcsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsU0FBUztBQUNYLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNGLENBQUMsQ0FBQztBQUNGO0FBQ0EsUUFBUSxDQUFDLGlCQUFpQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRCxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BJLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNsRSxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxLQUFLO0FBQzVDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTTtBQUNaLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDalYsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQztBQUNqRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVE7QUFDN0QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNqSSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDckMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDTixDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLFFBQVE7QUFDaEQsQ0FBQztBQUNELFFBQVEsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDL0MsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVO0FBQ3hCLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUN2QixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ25GLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDUCxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ04sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxRQUFRO0FBQ2hCO0FBQ0EsUUFBUSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNoQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNmLENBQUMsQ0FBQyxHQUFHO0FBQ0wsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0o7QUFDQSxRQUFRLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekQsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQztBQUNqRCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0o7QUFDQSxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLGNBQWM7QUFDdEQsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUMxRCxRQUFRLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQzdDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsR0FBRyxDQUFDLElBQUk7QUFDVCxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUUsQ0FBQyxDQUFDLEdBQUc7QUFDTCxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3RCxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDdEMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXO0FBQ2pCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNqRixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ3RDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ04sQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbEIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQ3BGLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakYsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKO0FBQ0EsUUFBUSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMvQixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7QUFDdkIsQ0FBQyxDQUFDLEdBQUc7QUFDTCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSjtBQUNBLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDNUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztBQUN0QixDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUNoQixDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDdkIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTO0FBQ2pCLENBQUMsQ0FBQztBQUNGLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN6QyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSztBQUM1QyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2RCxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1RCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQzNELENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDO0FBQy9DLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDdEcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztBQUN4RixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUk7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUNGLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2Q7QUFDQSxRQUFRLENBQUMsb0JBQW9CLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDeEMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUM7QUFDbEQsQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2hSO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztBQUN6QyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDbEMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQztBQUNoRixDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUM7QUFDcEMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUM7QUFDakMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU07QUFDOUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQztBQUN2QyxDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDekMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzVCLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsU0FBUztBQUNwQyxDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPO0FBQ25CLENBQUMsQ0FBQztBQUNGLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUNqSCxDQUFDO0FBQ0QsQ0FBQztBQUNELFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUMzQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQztBQUN2QztBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDekMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzVCLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDakUsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLFVBQVUsQ0FBQztBQUMxRCxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUMxQixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsV0FBVztBQUNoQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUNoQixDQUFDO0FBQ0QsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDO0FBQ0QsQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDO0FBQzFCLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ3ZCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUN2QixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU87QUFDaEIsQ0FBQztBQUNELENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQzVCLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLFFBQVEsQ0FBQztBQUM3SCxDQUFDLENBQUMsUUFBUSxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ3pDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJO0FBQzFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUN0QyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7QUFDckIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFO0FBQ1gsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTO0FBQzFELENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTTtBQUNsQixDQUFDLENBQUM7QUFDRixDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDNUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDakgsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDO0FBQzdGLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRztBQUNwQixDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNQLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3RFLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDWCxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU07QUFDakMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVc7QUFDN0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2pPLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsUUFBUSxDQUFDO0FBQ3RFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMseUJBQXlCLENBQUM7QUFDL0UsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQztBQUNqSCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLG9DQUFvQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4RSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU07QUFDekMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLG9DQUFvQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWTtBQUN4QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDdkUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxhQUFhO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUM5RixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxXQUFXO0FBQ3hDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsUUFBUTtBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDNUIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNYLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsUUFBUTtBQUM5QixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEdBQUc7QUFDL0IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRO0FBQ2pCLENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVE7QUFDakQsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDMUQsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxLQUFLO0FBQ25ELENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLO0FBQ3JCLENBQUMsQ0FBQztBQUNGLENBQUMsS0FBSyxDQUFDLHFCQUFxQixDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDL0gsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztBQUM1SSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLDZCQUE2QixDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUN6RCxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO0FBQ3hELENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDcEQsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDdEQsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLO0FBQ3pELENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSztBQUNqQixDQUFDLENBQUM7QUFDRixDQUFDLEtBQUssQ0FBQyw2QkFBNkIsQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN2RCxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2pHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUM1RyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3SCxDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVE7QUFDekMsQ0FBQyxDQUFDO0FBQ0YsQ0FBQywyQkFBMkIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUMvRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQztBQUNqRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDakYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxRQUFRO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDMUYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsMkJBQTJCLENBQUMsWUFBWSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDL0UsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3ZGLENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsR0FBRztBQUNoRSxDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUM7QUFDRixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsV0FBVztBQUN4RCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDO0FBQ3JFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLHlCQUF5QixDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQ2xELENBQUMsQ0FBQztBQUNGLENBQUM7QUFDRCxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxTQUFTO0FBQzFELENBQUM7QUFDRCxDQUFDLDJCQUEyQixDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUNoRyxDQUFDO0FBQ0QsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztBQUNqQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDOUMsS0FBSyxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUNoRCxLQUFLLENBQUMsUUFBUSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ25FLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUM7QUFDMUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU07QUFDdkIsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDO0FBQ2pFLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLENBQUM7QUFDbEQsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbEMsQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN0QyxDQUFDLENBQUMsT0FBTztBQUNULENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDO0FBQzVCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQywwQkFBMEI7QUFDckMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxhQUFhO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxhQUFhO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUk7QUFDakIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDO0FBQ3ZFLENBQUMsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztBQUMvQixDQUFDLENBQUMsS0FBSyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMvRCxDQUFDO0FBQ0Q7QUFDQSxRQUFRLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDM0QsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDO0FBQ3BDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNO0FBQ3ZCLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztBQUNqRSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztBQUN2RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTztBQUNuQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSTtBQUN4QyxDQUFDLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLDBCQUEwQjtBQUN0QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsYUFBYTtBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVE7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRTtBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxhQUFhO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSTtBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLEdBQUc7QUFDTCxDQUFDLENBQUMsR0FBRztBQUNMLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFO0FBQ2QsQ0FBQyxDQUFDLElBQUk7QUFDTixDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDO0FBQ2xDLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDO0FBQ2xELFFBQVEsQ0FBQywwQkFBMEIsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN6QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTTtBQUN2QixDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztBQUN0QixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDYixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNYLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxNQUFNO0FBQ3ZILENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEQsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU87QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSTtBQUNoQixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDO0FBQ3RCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNoQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbkIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNYLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEQsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLG9CQUFvQixDQUFDLENBQUMsTUFBTTtBQUMzSCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUTtBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTTtBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7QUFDdEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLHdCQUF3QjtBQUM5QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO0FBQzNCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvRCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLHFCQUFxQixDQUFDLENBQUMsTUFBTTtBQUMzSCxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUM7QUFDM0MsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTTtBQUN4QixDQUFDLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDdkQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7QUFDeEUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyx3QkFBd0I7QUFDcEMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztBQUN0QixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7QUFDbkIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLDBCQUEwQjtBQUNuQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLHVCQUF1QixDQUFDLENBQUMsTUFBTTtBQUM3SCxDQUFDLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ3JELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9DLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxNQUFNO0FBQzdILENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQztBQUM1QixLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUNsQixLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixRQUFRLENBQUMsc0JBQXNCLENBQUMsaUJBQWlCLENBQUMsQ0FBQztBQUNuRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUMxQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDbkIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsTUFBTTtBQUMvQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsaUJBQWlCO0FBQzVCLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFGLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUI7QUFDNUMsQ0FBQztBQUNEO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO0FBQ3JDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ2pDLFFBQVEsQ0FBQyw4QkFBOEIsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM3QyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxZQUFZO0FBQ2xCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUNyQixDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRixDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWTtBQUNuQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVU7QUFDNUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQywwQkFBMEIsQ0FBQyxHQUFHLENBQUM7QUFDakMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDcEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQztBQUNwRixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTTtBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsS0FBSztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUNwRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNuRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVE7QUFDN0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUc7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUM1QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLGlCQUFpQixDQUFDO0FBQ3JELENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUMxQixDQUFDLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLGlCQUFpQixDQUFDO0FBQzdDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9DLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ3BFLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsS0FBSyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLFlBQVksQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNULENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxNQUFNO0FBQ2hELENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU07QUFDbkQsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNO0FBQ3BFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUM3RixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFdBQVc7QUFDOUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU07QUFDaEQsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTTtBQUNuRCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU07QUFDcEUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUM7QUFDNUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQzdGLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsV0FBVztBQUM5RyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU07QUFDekIsQ0FBQyxDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxNQUFNO0FBQ2hELENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU07QUFDbkQsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNO0FBQ3BFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTTtBQUN6QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsV0FBVztBQUM1RyxDQUFDLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFDRixDQUFDLE1BQU0sQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUM3QjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztBQUNoQyxNQUFNLENBQUMsNENBQTRDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDakYsUUFBUSxDQUFDLG1CQUFtQixDQUFDLGdCQUFnQixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLGdCQUFnQixDQUFDLENBQUMsT0FBTyxDQUFDO0FBQzNEO0FBQ0EsUUFBUSxDQUFDLHlCQUF5QixDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2hELENBQUMsS0FBSyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUMzQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU07QUFDekMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUM7QUFDbkMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNWLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsRUFBRSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyRixDQUFDLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7QUFDYjtBQUNBLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN4QyxDQUFDLE1BQU0sQ0FBQyw0Q0FBNEMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQ2hFO0FBQ0EsUUFBUSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzlDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLDRDQUE0QyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDekUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU07QUFDL0UsQ0FBQyxNQUFNLENBQUMsNENBQTRDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUM3RCxDQUFDLG9CQUFvQixDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDeEMsQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO0FBQ3pCLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUM7QUFDNUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyw0QkFBNEIsQ0FBQztBQUN0RCxNQUFNLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUk7QUFDbkIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQztBQUNELE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDeEYsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMvRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO0FBQ2hDLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDM0IsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDNUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyRztBQUNBLFFBQVEsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDOUIsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDM0MsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQztBQUN6RCxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNQLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDUCxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ1gsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxRQUFRLENBQUMsa0JBQWtCLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDNUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDWCxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ1AsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNQLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDUCxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ1AsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNULENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDUixDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxZQUFZLENBQUMsT0FBTztBQUNoQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2I7QUFDQSxRQUFRLENBQUMsbUJBQW1CLENBQUMsU0FBUyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDekQsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE1BQU07QUFDL0QsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUM7QUFDckUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDaEQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJO0FBQ3hCLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1RCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsTUFBTTtBQUMzQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDN0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQztBQUNELENBQUMsSUFBSSxDQUFDLENBQUM7QUFDUCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU07QUFDMUQsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE1BQU07QUFDL0MsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLHlCQUF5QixDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkgsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNUO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDdEIsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2xDLENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsR0FBRztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDM0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxrQkFBa0IsQ0FBQztBQUN0RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQVM7QUFDNUIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxHQUFHO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4RSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsMkJBQTJCLENBQUMsbUJBQW1CLENBQUM7QUFDdkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLO0FBQ3hCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUN4QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsR0FBRztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsd0JBQXdCLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2pHLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMzQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxvQkFBb0IsQ0FBQztBQUN2RCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsdUJBQXVCLENBQUMsb0JBQW9CLENBQUMsQ0FBQztBQUNoRSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVc7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFVO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLCtCQUErQixDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsaUNBQWlDLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ25FLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3ZILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxZQUFZO0FBQ2QsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLHFCQUFxQjtBQUN4QyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2hGLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsRUFBRSxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsU0FBUyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsU0FBUyxDQUFDLENBQUMsZUFBZSxDQUFDO0FBQ25ELENBQUMsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDbEQsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUMzRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxvQ0FBb0MsQ0FBQyxRQUFRLENBQUM7QUFDL0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsbUNBQW1DLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDM0QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxRQUFRLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxRQUFRO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQ3RCLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzdELFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0I7QUFDbkM7QUFDQSxRQUFRLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzdCLENBQUMsTUFBTSxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLG9CQUFvQjtBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO0FBQ3hCLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFDdEMsTUFBTSxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxLQUFLO0FBQ04sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhO0FBQ25CLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsZUFBZSxDQUFDLEVBQUU7QUFDeEMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUs7QUFDekMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsa0JBQWtCLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUM7QUFDRixDQUFDLEdBQUcsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLEtBQUs7QUFDN0IsQ0FBQztBQUNELEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyw0QkFBNEI7QUFDM0QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUM7QUFDL0YsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRixDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNO0FBQ2pCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDWixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUN2RSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSztBQUNoQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQztBQUN6RixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTTtBQUNqQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDYixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDbkIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxjQUFjLENBQUM7QUFDeEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ25CLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUNqQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztBQUNuRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDOUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQzVCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxZQUFZO0FBQ25CLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxTQUFTO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRO0FBQ2YsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVE7QUFDZixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsZUFBZTtBQUN0QixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUTtBQUNmLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNO0FBQ2IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVE7QUFDZixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSztBQUNaLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUU7QUFDVCxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUI7QUFDeEIsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGtCQUFrQjtBQUN6QixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2pELENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUU7QUFDeEIsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsRUFBRTtBQUM1QixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDN0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGtCQUFrQjtBQUMxRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzNELENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUMvQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNqRixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTO0FBQzNDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCO0FBQ3pELENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7QUFDM0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVILENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxFQUFFO0FBQzdJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztBQUN0SCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDckIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTO0FBQ3ZDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0ksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQzNFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDOUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ3JELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7QUFDNUIsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzVCLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzdCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFFLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDL0UsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUM7QUFDcEcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztBQUNsRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO0FBQ3hHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDOUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7QUFDM0csQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDckgsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3ZGLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQzdGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2TCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTO0FBQ2pELENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDdkUsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ2pFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2hCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7QUFDekQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDO0FBQ25ELENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDNUIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6RCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDL0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQztBQUNwQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUM7QUFDNUQsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQztBQUM5RCxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUk7QUFDbEYsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDM0IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFVBQVU7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDaEYsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU87QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7QUFDbEcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsVUFBVTtBQUNoQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ1osQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7QUFDN0IsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RHLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNWLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQztBQUNqQyxDQUFDO0FBQ0QsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQzdDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDdEQ7QUFDQSxRQUFRLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDakMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTO0FBQ3hDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVM7QUFDckY7QUFDQSxRQUFRLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsbUNBQW1DO0FBQ25ELENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7QUFDakMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNwQixDQUFDO0FBQ0Q7QUFDQSxRQUFRLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLG1DQUFtQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsbUNBQW1DO0FBQ3BHLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN0RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNuRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDOUIsQ0FBQztBQUNELENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO0FBQzdCLENBQUMsR0FBRyxDQUFDLG1DQUFtQyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQzdDLENBQUMsTUFBTSxDQUFDLEVBQUU7QUFDVjtBQUNBLFFBQVEsQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDckMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUM7QUFDN0MsQ0FBQyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDakUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3ZFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsb0NBQW9DLENBQUMsWUFBWSxDQUFDO0FBQ2pFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ0wsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNQLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDUixDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDLFlBQVk7QUFDZixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUN0RyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxHQUFHLENBQUMsZ0NBQWdDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDL0MsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDcEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUM7QUFDckQsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDeEQsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2YsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDakI7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDaEMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ25ELENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyw0QkFBNEI7QUFDM0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQztBQUNoRSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLHFCQUFxQixDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsQ0FBQyxNQUFNO0FBQzFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDTixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMscUJBQXFCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDdEMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUMxRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxhQUFhLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNsRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMxRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQztBQUMvRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDO0FBQzFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ2xELENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUMzQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxDQUFDLHFCQUFxQixDQUFDLE1BQU0sQ0FBQztBQUM3RCxDQUFDO0FBQ0QsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9DLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQztBQUM5RCxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNSO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDekIsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDO0FBQ3hCLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7QUFDakYsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO0FBQ3ZGLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLE1BQU07QUFDbEUsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQzNDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLDRCQUE0QixDQUFDLENBQUMsR0FBRyxDQUFDO0FBQzlDLENBQUMsQ0FBQyxNQUFNLENBQUMsNEJBQTRCLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQyxDQUFDO0FBQ3hFLENBQUMsQ0FBQyxNQUFNLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0QsQ0FBQztBQUNELENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsTUFBTSxDQUFDLGtDQUFrQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2xELENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2xHLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUM5SSxDQUFDLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLGdDQUFnQyxDQUFDO0FBQ3BILENBQUMsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7QUFDL0YsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUN4TixDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDMU4sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzNILENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2xHLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLG1CQUFtQixDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1RCxDQUFDLENBQUMseUJBQXlCLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDdEQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUMsa0JBQWtCLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxDQUFDLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDO0FBQ25HLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU07QUFDbEIsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUM3RCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsa0NBQWtDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdHLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLHFCQUFxQixDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0csQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuRCxDQUFDLENBQUMsS0FBSyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDTixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLG1CQUFtQixDQUFDO0FBQzNDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsbUJBQW1CLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsbUJBQW1CLENBQUMsRUFBRSxDQUFDO0FBQy9DLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLG1CQUFtQixDQUFDLENBQUMsZUFBZSxDQUFDO0FBQzVELENBQUMsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQztBQUNsRCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsOEJBQThCLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDakYsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDOUIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUM3RixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQzNFLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxHQUFHLENBQUM7QUFDOUIsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQztBQUN4QixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMseUJBQXlCLENBQUMsbUNBQW1DLENBQUM7QUFDaEcsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLE1BQU0sQ0FBQyw0QkFBNEIsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyw0QkFBNEIsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNHLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxHQUFHLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLHFCQUFxQixDQUFDLGFBQWEsQ0FBQztBQUNyQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLDRCQUE0QixDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQztBQUN6RyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLDRCQUE0QixDQUFDLENBQUMsYUFBYSxDQUFDO0FBQ2hGO0FBQ0EsUUFBUSxDQUFDLHlCQUF5QixDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDaEUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDVCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsZUFBZSxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDeEMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ25DLENBQUMsYUFBYSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsbUJBQW1CO0FBQ2hGLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDLHNCQUFzQixDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ3ZGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUMzQyxRQUFRLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLO0FBQy9CLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMzQixDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkO0FBQ0EsUUFBUSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN4QixDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN6QyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSztBQUMvQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNoQyxDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkO0FBQ0EsUUFBUSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNyQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDaEQsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUI7QUFDN0UsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUI7QUFDdEYsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUc7QUFDbkQsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUM5QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ2pDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztBQUMxRixDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUM7QUFDdkQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDaEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUN2QyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQzdELENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN6QyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ3pELENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNmLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRztBQUNsQjtBQUNBLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDN0IsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztBQUNyQjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7QUFDMUMsUUFBUSxDQUFDLDBCQUEwQixDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdkQsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUMxQixDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDbkcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlDQUFpQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQy9MLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ3hILENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQywwQkFBMEIsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztBQUM1RCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUM3QyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTO0FBQzdCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNuRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO0FBQ3JELENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUN0QjtBQUNBLFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25FLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsR0FBRyxDQUFDLE1BQU07QUFDWCxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUN0RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUs7QUFDckUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDOUQsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTztBQUN6TCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUMzRCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pGLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDO0FBQzFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3pLLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQztBQUNySSxDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNiO0FBQ0EsUUFBUSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM3QixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNoRjtBQUNBLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxHQUFHLENBQUMsVUFBVTtBQUNmLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsMEJBQTBCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNoRSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDcEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLO0FBQ3pDLENBQUMsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJO0FBQzlDLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25JLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXO0FBQzNDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsaUJBQWlCO0FBQzNELENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSztBQUNqRCxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxLQUFLO0FBQ1AsQ0FBQyxDQUFDLE9BQU87QUFDVCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRjtBQUNBLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDbkMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDMUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDeEMsQ0FBQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNuRDtBQUNBLFFBQVEsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDckMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDbEQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQ2xELENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDeEQ7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO0FBQzVDLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM5QyxDQUFDLGFBQWEsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxzQkFBc0I7QUFDekMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLHNCQUFzQixDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3ZGO0FBQ0EsTUFBTSxDQUFDLHVDQUF1QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsNEJBQTRCO0FBQy9FLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7QUFDakcsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzVCLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM3QyxDQUFDO0FBQ0QsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNqQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2pDLENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO0FBQ2pDLENBQUM7QUFDRCxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztBQUNuQyxDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDekIsQ0FBQztBQUNELENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztBQUN4RixHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDckIsQ0FBQyxXQUFXLENBQUMsa0JBQWtCLENBQUMsQ0FBQztBQUNqQyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxrQkFBa0I7QUFDOUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUNqQyxDQUFDO0FBQ0QsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUN2QyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLENBQUM7QUFDOUQsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQyxDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDakIsQ0FBQztBQUNELENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO0FBQ2xDLENBQUM7QUFDRCxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLFVBQVUsQ0FBQztBQUNyQyxDQUFDO0FBQ0QsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQztBQUM5RixHQUFHLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztBQUMzQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUN0QixDQUFDLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDdEQsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUM7QUFDbEYsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ3ZDLENBQUM7QUFDRCxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO0FBQzVDLENBQUM7QUFDRCxDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDcEYsUUFBUSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM3QixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztBQUNyRCxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNuRixDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2Q7QUFDQSxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQztBQUNuQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztBQUNwRCxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDOUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUM7QUFDakMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ3BDLENBQUM7QUFDRDtBQUNBLFFBQVEsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbEU7QUFDQSxRQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzlCLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakM7QUFDQSxRQUFRLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNwQyxDQUFDO0FBQ0Q7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDO0FBQzNHLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3RDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVztBQUNsRCxDQUFDO0FBQ0QsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3RSxDQUFDO0FBQ0QsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQztBQUMvQixDQUFDO0FBQ0QsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO0FBQ2xGLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkYsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ2pFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDOUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNsRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUMvQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSTtBQUN6RCxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVM7QUFDM0QsQ0FBQztBQUNELEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7QUFDckQsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDekQsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7QUFDNUUsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDM0QsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLE1BQU07QUFDdkQsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEdBQUc7QUFDakQsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEdBQUc7QUFDakQsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDN0QsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUNoRixLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsS0FBSztBQUNyRCxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7QUFDN0UsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztBQUNqSyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN6RCxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDN0UsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQztBQUMvRixLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsR0FBRztBQUNqRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQztBQUMvRixLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRCxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pFLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDWCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNYLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNqQixDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQzVCLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7QUFDekIsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkLENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQztBQUMzRixRQUFRLENBQUMsb0JBQW9CLENBQUMsWUFBWSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDaEYsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsWUFBWTtBQUNkLENBQUMsQ0FBQyxVQUFVO0FBQ1osQ0FBQyxDQUFDLFNBQVM7QUFDWCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRjtBQUNBLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsb0JBQW9CLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzNFLENBQUMsb0JBQW9CLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7QUFDaEQsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ1YsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pGLENBQUMsb0JBQW9CLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ2YsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsU0FBUyxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hELENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDbkIsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNWLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRSxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyRCxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5RSxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvRSxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDakMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQzlCLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDWCxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0UsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDWCxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUMxRSxDQUFDO0FBQ0QsUUFBUSxDQUFDLHVCQUF1QixDQUFDLFlBQVksQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ25GLENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLFlBQVk7QUFDZCxDQUFDLENBQUMsVUFBVTtBQUNaLENBQUMsQ0FBQyxTQUFTO0FBQ1gsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdELENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7QUFDcEUsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0QsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0RCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDcEUsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNiLENBQUMsQ0FBQztBQUNGLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxTQUFTO0FBQ1YsQ0FBQyxVQUFVO0FBQ1gsQ0FBQyxVQUFVO0FBQ1gsQ0FBQyxXQUFXO0FBQ1osQ0FBQyxVQUFVO0FBQ1gsQ0FBQyxXQUFXO0FBQ1osQ0FBQyxZQUFZO0FBQ2IsQ0FBQyxZQUFZO0FBQ2IsQ0FBQztBQUNELENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDdEIsQ0FBQyxNQUFNLENBQUMsR0FBRztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN4RSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUM7QUFDRixRQUFRLENBQUMsMkJBQTJCLENBQUMsY0FBYyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDaEUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUM7QUFDNUcsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNiO0FBQ0EsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdGLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUMzRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQztBQUNoRixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN2QyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQzdKLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxDQUFDO0FBQ0YsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLHlCQUF5QixDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUM7QUFDbkUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMseUJBQXlCLENBQUMsY0FBYyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNsRixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pCLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyx5QkFBeUIsQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQztBQUNsRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLHlCQUF5QixDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDekUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNoRixDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUM7QUFDRixLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQztBQUN2QixDQUFDLFNBQVM7QUFDVixDQUFDLFVBQVU7QUFDWCxDQUFDLFVBQVU7QUFDWCxDQUFDO0FBQ0QsQ0FBQztBQUNELEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDdkcsQ0FBQyxFQUFFLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNyQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsdUJBQXVCLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUM1RCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsdUJBQXVCLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVM7QUFDM0QsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxLQUFLLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDakcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNsQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsb0JBQW9CLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUN6RCxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsb0JBQW9CLENBQUM7QUFDN0IsQ0FBQyxDQUFDO0FBQ0YsQ0FBQztBQUNELEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5QixDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNoRCxDQUFDLENBQUM7QUFDRixLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3JFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUNuRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDckUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUM5RSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDN0QsQ0FBQztBQUNELENBQUMsSUFBSSxDQUFDO0FBQ04sQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQztBQUN0RCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUN6RSxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3BELENBQUM7QUFDRCxDQUFDO0FBQ0QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7QUFDMUYsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDM0QsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDMUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3pCLENBQUM7QUFDRCxRQUFRLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQzVCLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDM0YsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMzRixDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQy9GO0FBQ0EsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUM7QUFDbkIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ3JELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ25CLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDbEQsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUMxQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDVixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNWLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQzdCLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2QsQ0FBQztBQUNELEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDO0FBQ25CLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0FBQzdDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNwQixDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3JCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ3JCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztBQUN6QixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO0FBQzFELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHO0FBQ25CLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ25DLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUNuQixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2xELENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDVixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQztBQUNGLENBQUM7QUFDRCxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNuRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzVFLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUM5QyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztBQUNuQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDN0IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7QUFDdkIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQztBQUNELENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUN6QyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUM1QyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7QUFDcEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ1QsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDZixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUN0RCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDVCxDQUFDLENBQUM7QUFDRixDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkLENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQztBQUN2RixRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTTtBQUNsQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVGLENBQUMsQ0FBQyxNQUFNO0FBQ1IsQ0FBQztBQUNELENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDbkMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRCxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDekQsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDMUI7QUFDQSxRQUFRLENBQUMscUJBQXFCLENBQUMsS0FBSyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDOUQsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUMzRSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDYjtBQUNBLFFBQVEsQ0FBQyxtQ0FBbUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNqRSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdEMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDaEQsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUM1RCxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQztBQUNELENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVztBQUNuQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNoRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDbkMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNiO0FBQ0EsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDdEssUUFBUSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUMvQyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO0FBQzNDLENBQUMsRUFBRSxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDeEMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3BDO0FBQ0EsUUFBUSxDQUFDLHNDQUFzQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3JFLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMvQixDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQy9CLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2hHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3ZELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUM7QUFDNUYsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUM7QUFDcEYsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLEVBQUUsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsaUJBQWlCLENBQUM7QUFDN0UsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDeEMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUNwRDtBQUNBLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0SSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUM7QUFDdEMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDO0FBQ3ZDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztBQUN0QyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUM3RCxDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO0FBQ2pDLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsV0FBVyxDQUFDLEtBQUs7QUFDdEMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsSUFBSTtBQUNqQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNqRCxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDZixDQUFDO0FBQ0QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMzRSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFNBQVMsQ0FBQztBQUMvRCxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDMUQsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDMUQsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUN0TSxDQUFDLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUM7QUFDckksQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsZ0JBQWdCO0FBQzVELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsV0FBVztBQUNuRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzdHLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDeEQsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEQsQ0FBQyxDQUFDLGdCQUFnQjtBQUNsQixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDM0UsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLGdCQUFnQjtBQUNsQixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hGLENBQUMsQ0FBQztBQUNGLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNoRCxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2QsQ0FBQztBQUNELENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDbEYsUUFBUSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMxQixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVEO0FBQ0EsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDcEM7QUFDQSxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNsQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNoRCxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDO0FBQ2pELENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUztBQUN6RjtBQUNBLFFBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDekIsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDbkM7QUFDQSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDaEc7QUFDQSxRQUFRLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzlCLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0FBQ3hDO0FBQ0EsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsQ0FBQztBQUM1QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQzdGLFFBQVEsQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQztBQUM5RSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUM7QUFDcEcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNO0FBQ25ELENBQUMsRUFBRSxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDN0YsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU07QUFDZixDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsS0FBSztBQUNuQixDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSTtBQUNoQixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNBLFFBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3hFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDNUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDO0FBQ2pELENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLHFCQUFxQixDQUFDLE1BQU0sQ0FBQztBQUNyRCxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDNUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7QUFDekIsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDO0FBQzNFLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQ3JGLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLDJCQUEyQixDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQztBQUM5SyxDQUFDLENBQUM7QUFDRixDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDMUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO0FBQ2xFLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUN0QixDQUFDO0FBQ0QsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM5QyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDOUQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztBQUMvQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJO0FBQ2QsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsc0NBQXNDLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUM3RixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUN0QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSTtBQUNkLENBQUMsQ0FBQyxDQUFDLHFCQUFxQixDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUc7QUFDWixDQUFDO0FBQ0QsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDdEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNoQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUN6QixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzdFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsbUNBQW1DLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDO0FBQ25ILENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNmLENBQUM7QUFDRCxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMvQyxDQUFDO0FBQ0QsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDZixDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUM3QyxDQUFDO0FBQ0QsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztBQUN6QyxDQUFDO0FBQ0QsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUM3QyxDQUFDO0FBQ0QsQ0FBQyxjQUFjLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxRQUFRLENBQUM7QUFDMUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNQLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUM7QUFDRCxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDdkMsQ0FBQztBQUNELENBQUM7QUFDRCxTQUFTLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDM0MsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUM7QUFDekYsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUM7QUFDN0YsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUM7QUFDekYsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUM7QUFDakYsU0FBUyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUM7QUFDakcsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUM7QUFDbkcsU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUM7QUFDbkcsU0FBUyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUM7QUFDckcsU0FBUyxDQUFDLFNBQVM7QUFDbkIsU0FBUyxDQUFDLFdBQVc7QUFDckIsU0FBUyxDQUFDLFNBQVM7QUFDbkIsU0FBUyxDQUFDLEtBQUs7QUFDZixTQUFTLENBQUMsYUFBYTtBQUN2QixTQUFTLENBQUMsY0FBYztBQUN4QixTQUFTLENBQUMsY0FBYztBQUN4QixTQUFTLENBQUMsZUFBZTtBQUN6QixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztBQUMxRCxLQUFLLENBQUMsNENBQTRDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUM7QUFDckcsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7QUFDeEQsS0FBSyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQztBQUNuRSxRQUFRLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLHNCQUFzQixDQUFDO0FBQzdELENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsNENBQTRDO0FBQ3ZELENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztBQUM5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztBQUMvRixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO0FBQ2pELEtBQUssQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUM3RCxLQUFLLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7QUFDM0QsS0FBSyxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzdELEtBQUssQ0FBQyw2Q0FBNkMsQ0FBQyxDQUFDLENBQUM7QUFDdEQsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNqQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2pDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDakMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUs7QUFDaEMsQ0FBQztBQUNELFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLDJCQUEyQixDQUFDO0FBQzNDO0FBQ0EsUUFBUSxDQUFDLHdCQUF3QixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzNDLENBQUMsTUFBTSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDOUM7QUFDQSxRQUFRLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQywwQkFBMEIsQ0FBQztBQUMxQztBQUNBLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUMxQyxDQUFDLE1BQU0sQ0FBQywwQkFBMEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQzdDO0FBQ0EsUUFBUSxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsMkJBQTJCLENBQUM7QUFDM0M7QUFDQSxRQUFRLENBQUMsd0JBQXdCLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDM0MsQ0FBQyxNQUFNLENBQUMsMkJBQTJCLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUM5QztBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7QUFDaEQsUUFBUSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUM7QUFDMUMsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLDZDQUE2QyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDeEcsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLDZDQUE2QyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7QUFDL0MsUUFBUSxDQUFDLDBCQUEwQixDQUFDLENBQUMsQ0FBQztBQUN0QyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUM7QUFDekMsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyw2Q0FBNkMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RGLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsNkNBQTZDLENBQUMsZUFBZSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzlGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsNkNBQTZDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0RixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLDZDQUE2QyxDQUFDLGVBQWUsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUM5RixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUM7QUFDaEQsUUFBUSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUM7QUFDMUMsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLDZDQUE2QyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDeEcsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLDZDQUE2QyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUM7QUFDbEQsS0FBSyxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzlELEtBQUssQ0FBQyw4Q0FBOEMsQ0FBQyxDQUFDLENBQUM7QUFDdkQsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUNqQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ2pDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDakMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUs7QUFDaEMsQ0FBQztBQUNELFFBQVEsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLDRCQUE0QixDQUFDO0FBQzVDO0FBQ0EsUUFBUSxDQUFDLHlCQUF5QixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQzVDLENBQUMsTUFBTSxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDL0M7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO0FBQ2pELFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3pCLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUNoQixDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDMUIsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDNUIsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ04sQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQztBQUMvQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0RixDQUFDLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxJQUFJLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ3ZCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLENBQUM7QUFDaEQsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDO0FBQ3BELENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQzdDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDZCxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDdEIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQztBQUNELENBQUMsT0FBTyxDQUFDLENBQUM7QUFDVixDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU07QUFDM0IsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU07QUFDNUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0osQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQztBQUNoRCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7QUFDaEQsUUFBUSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEUsQ0FBQyxRQUFRLENBQUMsb0JBQW9CLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDeEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUM7QUFDckIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsOENBQThDLENBQUMsZUFBZTtBQUN6RSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ1QsQ0FBQztBQUNELENBQUMsUUFBUSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsOENBQThDLENBQUMsZUFBZSxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ3RHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQztBQUNELENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUM7QUFDakQsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLDJCQUEyQixDQUFDO0FBQ2hFLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsMkJBQTJCLENBQUM7QUFDcEUsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEUsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLG9CQUFvQixDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDN0QsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7QUFDakQsUUFBUSxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FBQztBQUN4QyxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUM7QUFDdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyw4Q0FBOEMsQ0FBQyxlQUFlO0FBQzFFLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxJQUFJO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLDhDQUE4QyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDaEssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQy9DLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ25ELENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUM7QUFDRixDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDL0MsS0FBSyxDQUFDLHlDQUF5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDO0FBQy9GLEtBQUssQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUN6RCxRQUFRLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDO0FBQ2xDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyx5QkFBeUIsQ0FBQztBQUN6QztBQUNBLFFBQVEsQ0FBQyxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN6QyxDQUFDLE1BQU0sQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQzVDO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztBQUM5QyxRQUFRLENBQUMseUJBQXlCLENBQUMsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDeEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxNQUFNLENBQUM7QUFDUixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDO0FBQ2hFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLHlDQUF5QztBQUNuRCxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFDOUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7QUFDOUgsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUM7QUFDRjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7QUFDOUMsUUFBUSxDQUFDLHlCQUF5QixDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQztBQUNGLENBQUMsTUFBTSxDQUFDO0FBQ1IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEIsQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUM7QUFDNUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyx5Q0FBeUM7QUFDcEQsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pELENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsc0JBQXNCLENBQUMsQ0FBQztBQUMzQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFDL0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO0FBQ3ZJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO0FBQzdDLEtBQUssQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQztBQUMzRixLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDckQsS0FBSyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQ3JELFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLHVCQUF1QixDQUFDO0FBQ3ZDO0FBQ0EsUUFBUSxDQUFDLG9CQUFvQixDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3ZDLENBQUMsTUFBTSxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDMUM7QUFDQSxRQUFRLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQztBQUN2QztBQUNBLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN2QyxDQUFDLE1BQU0sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQzFDO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUM1QyxRQUFRLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQztBQUN0QyxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbkYsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsdUNBQXVDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xFLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDO0FBQ0Y7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO0FBQzVDLFFBQVEsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0FBQzFDLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBRTtBQUMzQyxDQUFDLE1BQU0sQ0FBQztBQUNSLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDOUYsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLHVDQUF1QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5RSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNsQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQztBQUNGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7QUFDOUIsTUFBTSxDQUFDLHFDQUFxQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25ELE1BQU0sQ0FBQywrQkFBK0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDL0MsTUFBTSxDQUFDLCtCQUErQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUMvQyxNQUFNLENBQUMsb0NBQW9DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3BELE1BQU0sQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDcEQsTUFBTSxDQUFDLHlDQUF5QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUN6RCxRQUFRLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxNQUFNLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDN0M7QUFDQSxRQUFRLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxNQUFNLENBQUMsK0JBQStCLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDN0M7QUFDQSxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsK0JBQStCO0FBQzlDO0FBQ0EsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLCtCQUErQjtBQUM5QztBQUNBLFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN2QyxDQUFDLE1BQU0sQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUNsRDtBQUNBLFFBQVEsQ0FBQyx3QkFBd0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN2QyxDQUFDLE1BQU0sQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDLENBQUMsR0FBRztBQUNsRDtBQUNBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLG9DQUFvQztBQUNuRDtBQUNBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLG9DQUFvQztBQUNuRDtBQUNBLFFBQVEsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDVixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyx5QkFBeUI7QUFDcEMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNULENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLDJCQUEyQjtBQUN0QyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQywwQkFBMEI7QUFDcEMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUNULENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNSLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLHVCQUF1QjtBQUNsQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQ1QsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsc0JBQXNCO0FBQ2pDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDVCxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyw0QkFBNEI7QUFDdkMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsMkJBQTJCO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ1gsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ1IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0FBQ1YsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDakI7QUFDQSxRQUFRLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRCxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNqRSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ3ZELENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU87QUFDWixDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLEdBQUcsQ0FBQztBQUMvQixDQUFDLENBQUMsTUFBTTtBQUNSLENBQUM7QUFDRCxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQztBQUMxQixDQUFDLE1BQU0sQ0FBQyxHQUFHO0FBQ1g7QUFDQSxRQUFRLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRCxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNqRSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNqRSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ2pDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ3ZELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFDZCxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLENBQUMsd0JBQXdCLENBQUMsS0FBSyxDQUFDO0FBQ2xDLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDVCxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDO0FBQzdCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0MsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDO0FBQ0g7QUFDQSxRQUFRLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTztBQUNqRSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNoRSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN4QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPO0FBQ1osQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQztBQUNIO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztBQUMxQyxRQUFRLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbEMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEIsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ25CLENBQUMsR0FBRyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUNqRCxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDL0QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDcEMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkQsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUNsQixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNyTCxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKO0FBQ0EsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQy9CLENBQUMsS0FBSyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQzlELENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7QUFDaEIsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNKO0FBQ0EsUUFBUSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM3QixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO0FBQzlELENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDZCxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUNoRCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0o7QUFDQSxRQUFRLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzVCLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDYixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDcEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJO0FBQ2hCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSjtBQUNBLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUM3QixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDbkIsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNwQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSTtBQUNiLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNaLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSjtBQUNBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNqQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7QUFDdEMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDckIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDdEMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSTtBQUNuQixDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ1IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSixDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsT0FBTztBQUNmO0FBQ0EsUUFBUSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMvQixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNoQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDakMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUs7QUFDNUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHO0FBQ1osQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNQO0FBQ0EsUUFBUSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ25DLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xCLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE1BQU07QUFDckIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7QUFDMUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLO0FBQ2hDLENBQUM7QUFDRCxDQUFDLE1BQU0sQ0FBQyxNQUFNO0FBQ2Q7QUFDQSxRQUFRLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2hDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDZixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDdEIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ1QsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUs7QUFDckIsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsS0FBSztBQUNsQyxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSjtBQUNBLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN0QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3RDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsUUFBUSxDQUFDO0FBQzdDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7QUFDbkIsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyx5QkFBeUI7QUFDeEMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUM7QUFDeEMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztBQUNuQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQztBQUMvQixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0o7QUFDQSxRQUFRLENBQUMsNkJBQTZCLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDbkQsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUM7QUFDM0MsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNkLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDN0YsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUM7QUFDOUIsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLE9BQU87QUFDdEIsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQztBQUNyQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hELENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSjtBQUNBLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN0QyxDQUFDLEdBQUcsQ0FBQztBQUNMLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMzSixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsVUFBVTtBQUMvQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDcEUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUNEO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztBQUN4RSxDQUFDO0FBQ0QsUUFBUSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUM3QixDQUFDLEVBQUUsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTTtBQUNqRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSztBQUMvRDtBQUNBLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNsQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLGlCQUFpQixDQUFDLE1BQU0sQ0FBQztBQUN2QyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDakQsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDekcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN0RSxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsb0JBQW9CLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUM3SCxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsQ0FBQyxhQUFhO0FBQ2hCLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDUixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNMLENBQUM7QUFDRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ3BILENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUM7QUFDOUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxVQUFVO0FBQ3RDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSjtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUM7QUFDNUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQzdELENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDdEMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQ3RCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUc7QUFDeEIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDekIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNO0FBQ3RCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDWixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWM7QUFDckMsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUc7QUFDWixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDeEksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUc7QUFDaEIsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTO0FBQ2hELENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxRQUFRO0FBQzNELENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxpQkFBaUI7QUFDcEUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDO0FBQ25FLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUYsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxDQUFDO0FBQy9ELENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ25ELENBQUMsQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQ25ELENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQztBQUN6RCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDO0FBQzlELENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZHLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUM7QUFDaEUsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUMzRixDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQztBQUMxSCxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLEdBQUcsQ0FBQztBQUMvQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFDckQsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFlBQVksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUN6SCxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxZQUFZO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsNkJBQTZCLENBQUMsR0FBRyxDQUFDO0FBQ3JJLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLHFCQUFxQixDQUFDLEdBQUcsQ0FBQztBQUM5RyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ2pHLENBQUMsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLENBQUM7QUFDN0MsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsYUFBYTtBQUNqRCxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHO0FBQ3pDLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7QUFDckI7QUFDQSxDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztBQUM5QixLQUFLLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQzNDLFFBQVEsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDaEMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNuQztBQUNBLFFBQVEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDL0IsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUNsQztBQUNBLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNyQyxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLElBQUk7QUFDaEQsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJO0FBQ3hHO0FBQ0EsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxVQUFVO0FBQzdFO0FBQ0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztBQUMxQyxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsMkJBQTJCLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDbkUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pELENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDSjtBQUNBLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxNQUFNO0FBQy9FLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFVBQVU7QUFDdEc7QUFDQSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxRQUFRO0FBQ3BELENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7QUFDeEUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJO0FBQy9ELENBQUM7QUFDRCxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BHLENBQUMsR0FBRyxDQUFDLE1BQU07QUFDWCxDQUFDLEdBQUcsQ0FBQyxHQUFHO0FBQ1IsQ0FBQyxHQUFHLENBQUMsS0FBSztBQUNWLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDTixDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztBQUNqQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUztBQUN4QyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNO0FBQzFCLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUNuRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0FBQzVCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQy9DLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNiLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUN2QixDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDbkIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUs7QUFDOUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUM7QUFDOUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsZUFBZSxDQUFDO0FBQ2pGLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNmLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGVBQWUsQ0FBQztBQUNoRixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxlQUFlLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztBQUMxQyxDQUFDLENBQUM7QUFDRixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQ3ZCLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUNuQixDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxlQUFlLENBQUM7QUFDL0UsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2YsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxDQUFDO0FBQzlFLENBQUMsQ0FBQztBQUNGLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUN2QixDQUFDLE1BQU0sQ0FBQyxLQUFLO0FBQ2I7QUFDQSxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdEMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTTtBQUNwQixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLO0FBQ2xDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQzlDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUNqQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzNCLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUN2RCxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSztBQUNyQixDQUFDLENBQUMsQ0FBQztBQUNILENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEYsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDcEQsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQ2xCLENBQUMsQ0FBQztBQUNGLENBQUM7QUFDRDtBQUNBLFFBQVEsQ0FBQywyQkFBMkIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDMUUsQ0FBQyxHQUFHLENBQUMsTUFBTTtBQUNYLENBQUMsR0FBRyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDOUgsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDYixDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxpQ0FBaUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDbkUsQ0FBQztBQUNELENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUMxQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQztBQUNuRSxDQUFDLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUN4SCxDQUFDLENBQUMsTUFBTSxDQUFDLE1BQU07QUFDZixDQUFDO0FBQ0QsQ0FBQyxNQUFNLENBQUMsTUFBTTtBQUNkO0FBQ0EsUUFBUSxDQUFDLGlDQUFpQyxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNoRixDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUN4RCxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3BGO0FBQ0EsUUFBUSxDQUFDLHVCQUF1QixDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdkQsQ0FBQyxFQUFFLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDcEcsQ0FBQyxJQUFJLENBQUM7QUFDTixDQUFDLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFDL0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUM7QUFDdkIsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ2hCLENBQUM7QUFDRDtBQUNBLENBQUMsQ0FBQyxDQUFDO0FBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO0FBQzFCLFFBQVEsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDekIsQ0FBQyxNQUFNLENBQUMsMkJBQTJCLENBQUMsSUFBSSxDQUFDLENBQUMsaUJBQWlCLENBQUM7QUFDNUQ7QUFDQSxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDckMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDOUIsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDO0FBQ3ZGO0FBQ0EsQ0FBQyxDQUFDLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztBQUNwQixLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNqQixDQUFDLElBQUk7QUFDTCxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQ2hCLENBQUMsQ0FBQztBQUNGLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsTUFBTSxDQUFDLGVBQWU7QUFDeEIsQ0FBQyxDQUFDO0FBQ0YsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNYLENBQUMsQ0FBQyxNQUFNLENBQUMsZUFBZSxDQUFDLEdBQUc7QUFDNUIsQ0FBQztBQUNELENBQUM7QUFDRCxDQUFDLENBQUMsQ0FBQztBQUNILE1BQU0sQ0FBQyxDQUFDLENBQUMsdUJBQXVCLENBQUMsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLDJCQUEyQixDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxlQUFlLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLDhCQUE4QixDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLGVBQWUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLHVCQUF1QixDQUFDLENBQUMsMEJBQTBCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLG9CQUFvQixDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsd0JBQXdCLENBQUMsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUMseUJBQXlCLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLHNCQUFzQixDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLHdCQUF3QixDQUFDLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMscUJBQXFCLENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDLGtCQUFrQixDQUFDLENBQUMsNEJBQTRCLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLHlCQUF5QixDQUFDLENBQUM7In0=