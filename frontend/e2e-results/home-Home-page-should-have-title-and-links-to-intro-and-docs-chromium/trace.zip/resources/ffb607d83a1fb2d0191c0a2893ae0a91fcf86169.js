import { Component, ComponentContainer } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@firebase+component@0.7.4/node_modules/@firebase/component/dist/esm/index.esm.js?v=7e73afc2";
import { Logger, setUserLogHandler, setLogLevel as setLogLevel$1 } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@firebase+logger@0.5.1/node_modules/@firebase/logger/dist/esm/index.esm.js?v=7e73afc2";
import { ErrorFactory, base64Decode, getDefaultAppConfig, deepEqual, isBrowser, isWebWorker, FirebaseError, base64urlEncodeWithoutPadding, isIndexedDBAvailable, validateIndexedDBOpenable } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@firebase+util@1.15.2/node_modules/@firebase/util/dist/index.esm.js?v=7e73afc2";
export { FirebaseError } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/@firebase+util@1.15.2/node_modules/@firebase/util/dist/index.esm.js?v=7e73afc2";
import { openDB } from "/_nuxt/@fs/Volumes/Coding/Projects/Websites/ineiah/frontend/node_modules/.pnpm/idb@7.1.1/node_modules/idb/build/index.js?v=7e73afc2";

/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class PlatformLoggerServiceImpl {
    constructor(container) {
        this.container = container;
    }
    // In initial implementation, this will be called by installations on
    // auth token refresh, and installations will send this string.
    getPlatformInfoString() {
        const providers = this.container.getProviders();
        // Loop through providers and get library/version pairs from any that are
        // version components.
        return providers
            .map(provider => {
            if (isVersionServiceProvider(provider)) {
                const service = provider.getImmediate();
                return `${service.library}/${service.version}`;
            }
            else {
                return null;
            }
        })
            .filter(logString => logString)
            .join(' ');
    }
}
/**
 *
 * @param provider check if this provider provides a VersionService
 *
 * NOTE: Using Provider<'app-version'> is a hack to indicate that the provider
 * provides VersionService. The provider is not necessarily a 'app-version'
 * provider.
 */
function isVersionServiceProvider(provider) {
    const component = provider.getComponent();
    return component?.type === "VERSION" /* ComponentType.VERSION */;
}

const name$q = "@firebase/app";
const version$1 = "0.16.0";

/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const logger = new Logger('@firebase/app');

const name$p = "@firebase/app-compat";

const name$o = "@firebase/analytics-compat";

const name$n = "@firebase/analytics";

const name$m = "@firebase/app-check-compat";

const name$l = "@firebase/app-check";

const name$k = "@firebase/auth";

const name$j = "@firebase/auth-compat";

const name$i = "@firebase/database";

const name$h = "@firebase/data-connect";

const name$g = "@firebase/database-compat";

const name$f = "@firebase/functions";

const name$e = "@firebase/functions-compat";

const name$d = "@firebase/installations";

const name$c = "@firebase/installations-compat";

const name$b = "@firebase/messaging";

const name$a = "@firebase/messaging-compat";

const name$9 = "@firebase/performance";

const name$8 = "@firebase/performance-compat";

const name$7 = "@firebase/remote-config";

const name$6 = "@firebase/remote-config-compat";

const name$5 = "@firebase/storage";

const name$4 = "@firebase/storage-compat";

const name$3 = "@firebase/firestore";

const name$2 = "@firebase/ai";

const name$1 = "@firebase/firestore-compat";

const name = "firebase";
const version = "12.17.0";

/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * The default app name
 *
 * @internal
 */
const DEFAULT_ENTRY_NAME = '[DEFAULT]';
const PLATFORM_LOG_STRING = {
    [name$q]: 'fire-core',
    [name$p]: 'fire-core-compat',
    [name$n]: 'fire-analytics',
    [name$o]: 'fire-analytics-compat',
    [name$l]: 'fire-app-check',
    [name$m]: 'fire-app-check-compat',
    [name$k]: 'fire-auth',
    [name$j]: 'fire-auth-compat',
    [name$i]: 'fire-rtdb',
    [name$h]: 'fire-data-connect',
    [name$g]: 'fire-rtdb-compat',
    [name$f]: 'fire-fn',
    [name$e]: 'fire-fn-compat',
    [name$d]: 'fire-iid',
    [name$c]: 'fire-iid-compat',
    [name$b]: 'fire-fcm',
    [name$a]: 'fire-fcm-compat',
    [name$9]: 'fire-perf',
    [name$8]: 'fire-perf-compat',
    [name$7]: 'fire-rc',
    [name$6]: 'fire-rc-compat',
    [name$5]: 'fire-gcs',
    [name$4]: 'fire-gcs-compat',
    [name$3]: 'fire-fst',
    [name$1]: 'fire-fst-compat',
    [name$2]: 'fire-vertex',
    'fire-js': 'fire-js', // Platform identifier for JS SDK.
    [name]: 'fire-js-all'
};

/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * @internal
 */
const _apps = new Map();
/**
 * @internal
 */
const _serverApps = new Map();
/**
 * Registered components.
 *
 * @internal
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const _components = new Map();
/**
 * @param component - the component being added to this app's container
 *
 * @internal
 */
function _addComponent(app, component) {
    try {
        app.container.addComponent(component);
    }
    catch (e) {
        logger.debug(`Component ${component.name} failed to register with FirebaseApp ${app.name}`, e);
    }
}
/**
 *
 * @internal
 */
function _addOrOverwriteComponent(app, component) {
    app.container.addOrOverwriteComponent(component);
}
/**
 *
 * @param component - the component to register
 * @returns whether or not the component is registered successfully
 *
 * @internal
 */
function _registerComponent(component) {
    const componentName = component.name;
    if (_components.has(componentName)) {
        logger.debug(`There were multiple attempts to register component ${componentName}.`);
        return false;
    }
    _components.set(componentName, component);
    // add the component to existing app instances
    for (const app of _apps.values()) {
        _addComponent(app, component);
    }
    for (const serverApp of _serverApps.values()) {
        _addComponent(serverApp, component);
    }
    return true;
}
/**
 *
 * @param app - FirebaseApp instance
 * @param name - service name
 *
 * @returns the provider for the service with the matching name
 *
 * @internal
 */
function _getProvider(app, name) {
    const heartbeatController = app.container
        .getProvider('heartbeat')
        .getImmediate({ optional: true });
    if (heartbeatController) {
        void heartbeatController.triggerHeartbeat();
    }
    return app.container.getProvider(name);
}
/**
 *
 * @param app - FirebaseApp instance
 * @param name - service name
 * @param instanceIdentifier - service instance identifier in case the service supports multiple instances
 *
 * @internal
 */
function _removeServiceInstance(app, name, instanceIdentifier = DEFAULT_ENTRY_NAME) {
    _getProvider(app, name).clearInstance(instanceIdentifier);
}
/**
 *
 * @param obj - an object of type FirebaseApp, FirebaseOptions or FirebaseAppSettings.
 *
 * @returns true if the provide object is of type FirebaseApp.
 *
 * @internal
 */
function _isFirebaseApp(obj) {
    return obj.options !== undefined;
}
/**
 *
 * @param obj - an object of type FirebaseApp, FirebaseOptions or FirebaseAppSettings.
 *
 * @returns true if the provided object is of type FirebaseServerAppImpl.
 *
 * @internal
 */
function _isFirebaseServerAppSettings(obj) {
    if (_isFirebaseApp(obj)) {
        return false;
    }
    return ('authIdToken' in obj ||
        'appCheckToken' in obj ||
        'releaseOnDeref' in obj ||
        'automaticDataCollectionEnabled' in obj);
}
/**
 *
 * @param obj - an object of type FirebaseApp.
 *
 * @returns true if the provided object is of type FirebaseServerAppImpl.
 *
 * @internal
 */
function _isFirebaseServerApp(obj) {
    if (obj === null || obj === undefined) {
        return false;
    }
    return obj.settings !== undefined;
}
/**
 * Test only
 *
 * @internal
 */
function _clearComponents() {
    _components.clear();
}

/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ERRORS = {
    ["no-app" /* AppError.NO_APP */]: "No Firebase App '{$appName}' has been created - " +
        'call initializeApp() first',
    ["bad-app-name" /* AppError.BAD_APP_NAME */]: "Illegal App name: '{$appName}'",
    ["duplicate-app" /* AppError.DUPLICATE_APP */]: "Firebase App named '{$appName}' already exists with different {$mismatchedParam}." +
        " Existing: '{$oldValue}'. New: '{$newValue}'.",
    ["app-deleted" /* AppError.APP_DELETED */]: "Firebase App named '{$appName}' already deleted",
    ["server-app-deleted" /* AppError.SERVER_APP_DELETED */]: 'Firebase Server App has been deleted',
    ["no-options" /* AppError.NO_OPTIONS */]: 'Need to provide options, when not being deployed to hosting via source.',
    ["invalid-app-argument" /* AppError.INVALID_APP_ARGUMENT */]: 'firebase.{$appName}() takes either no argument or a ' +
        'Firebase App instance.',
    ["invalid-log-argument" /* AppError.INVALID_LOG_ARGUMENT */]: 'First argument to `onLog` must be null or a function.',
    ["idb-open" /* AppError.IDB_OPEN */]: 'Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.',
    ["idb-get" /* AppError.IDB_GET */]: 'Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.',
    ["idb-set" /* AppError.IDB_WRITE */]: 'Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.',
    ["idb-delete" /* AppError.IDB_DELETE */]: 'Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.',
    ["finalization-registry-not-supported" /* AppError.FINALIZATION_REGISTRY_NOT_SUPPORTED */]: 'FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.',
    ["invalid-server-app-environment" /* AppError.INVALID_SERVER_APP_ENVIRONMENT */]: 'FirebaseServerApp is not for use in browser environments.'
};
const ERROR_FACTORY = new ErrorFactory('app', 'Firebase', ERRORS);

/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class FirebaseAppImpl {
    constructor(options, config, container) {
        this._isDeleted = false;
        this._options = { ...options };
        this._config = { ...config };
        this._name = config.name;
        this._automaticDataCollectionEnabled =
            config.automaticDataCollectionEnabled;
        this._container = container;
        this.container.addComponent(new Component('app', () => this, "PUBLIC" /* ComponentType.PUBLIC */));
    }
    get automaticDataCollectionEnabled() {
        this.checkDestroyed();
        return this._automaticDataCollectionEnabled;
    }
    set automaticDataCollectionEnabled(val) {
        this.checkDestroyed();
        this._automaticDataCollectionEnabled = val;
    }
    get name() {
        this.checkDestroyed();
        return this._name;
    }
    get options() {
        this.checkDestroyed();
        return this._options;
    }
    get config() {
        this.checkDestroyed();
        return this._config;
    }
    get container() {
        return this._container;
    }
    get isDeleted() {
        return this._isDeleted;
    }
    set isDeleted(val) {
        this._isDeleted = val;
    }
    /**
     * This function will throw an Error if the App has already been deleted -
     * use before performing API actions on the App.
     */
    checkDestroyed() {
        if (this.isDeleted) {
            throw ERROR_FACTORY.create("app-deleted" /* AppError.APP_DELETED */, { appName: this._name });
        }
    }
}

/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// Parse the token and check to see if the `exp` claim is in the future.
// Reports an error to the console if the token or claim could not be parsed, or if `exp` is in
// the past.
function validateTokenTTL(base64Token, tokenName) {
    const secondPart = base64Decode(base64Token.split('.')[1]);
    if (secondPart === null) {
        console.error(`FirebaseServerApp ${tokenName} is invalid: second part could not be parsed.`);
        return;
    }
    const expClaim = JSON.parse(secondPart).exp;
    if (expClaim === undefined) {
        console.error(`FirebaseServerApp ${tokenName} is invalid: expiration claim could not be parsed`);
        return;
    }
    const exp = JSON.parse(secondPart).exp * 1000;
    const now = new Date().getTime();
    const diff = exp - now;
    if (diff <= 0) {
        console.error(`FirebaseServerApp ${tokenName} is invalid: the token has expired.`);
    }
}
class FirebaseServerAppImpl extends FirebaseAppImpl {
    constructor(options, serverConfig, name, container) {
        // Build configuration parameters for the FirebaseAppImpl base class.
        const automaticDataCollectionEnabled = serverConfig.automaticDataCollectionEnabled !== undefined
            ? serverConfig.automaticDataCollectionEnabled
            : true;
        // Create the FirebaseAppSettings object for the FirebaseAppImp constructor.
        const config = {
            name,
            automaticDataCollectionEnabled
        };
        if (options.apiKey !== undefined) {
            // Construct the parent FirebaseAppImp object.
            super(options, config, container);
        }
        else {
            const appImpl = options;
            super(appImpl.options, config, container);
        }
        // Now construct the data for the FirebaseServerAppImpl.
        this._serverConfig = {
            automaticDataCollectionEnabled,
            ...serverConfig
        };
        // Ensure that the current time is within the `authIdtoken` window of validity.
        if (this._serverConfig.authIdToken) {
            validateTokenTTL(this._serverConfig.authIdToken, 'authIdToken');
        }
        // Ensure that the current time is within the `appCheckToken` window of validity.
        if (this._serverConfig.appCheckToken) {
            validateTokenTTL(this._serverConfig.appCheckToken, 'appCheckToken');
        }
        this._finalizationRegistry = null;
        if (typeof FinalizationRegistry !== 'undefined') {
            this._finalizationRegistry = new FinalizationRegistry(() => {
                this.automaticCleanup();
            });
        }
        this._refCount = 0;
        this.incRefCount(this._serverConfig.releaseOnDeref);
        // Do not retain a hard reference to the dref object, otherwise the FinalizationRegistry
        // will never trigger.
        this._serverConfig.releaseOnDeref = undefined;
        serverConfig.releaseOnDeref = undefined;
        registerVersion(name$q, version$1, 'serverapp');
    }
    toJSON() {
        return undefined;
    }
    get refCount() {
        return this._refCount;
    }
    // Increment the reference count of this server app. If an object is provided, register it
    // with the finalization registry.
    incRefCount(obj) {
        if (this.isDeleted) {
            return;
        }
        this._refCount++;
        if (obj !== undefined && this._finalizationRegistry !== null) {
            this._finalizationRegistry.register(obj, this);
        }
    }
    // Decrement the reference count.
    decRefCount() {
        if (this.isDeleted) {
            return 0;
        }
        return --this._refCount;
    }
    // Invoked by the FinalizationRegistry callback to note that this app should go through its
    // reference counts and delete itself if no reference count remain. The coordinating logic that
    // handles this is in deleteApp(...).
    automaticCleanup() {
        void deleteApp(this);
    }
    get settings() {
        this.checkDestroyed();
        return this._serverConfig;
    }
    /**
     * This function will throw an Error if the App has already been deleted -
     * use before performing API actions on the App.
     */
    checkDestroyed() {
        if (this.isDeleted) {
            throw ERROR_FACTORY.create("server-app-deleted" /* AppError.SERVER_APP_DELETED */);
        }
    }
}

/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/**
 * The current SDK version.
 *
 * @public
 */
const SDK_VERSION = version;
function initializeApp(_options, rawConfig = {}) {
    let options = _options;
    if (typeof rawConfig !== 'object') {
        const name = rawConfig;
        rawConfig = { name };
    }
    const config = {
        name: DEFAULT_ENTRY_NAME,
        automaticDataCollectionEnabled: true,
        ...rawConfig
    };
    const name = config.name;
    if (typeof name !== 'string' || !name) {
        throw ERROR_FACTORY.create("bad-app-name" /* AppError.BAD_APP_NAME */, {
            appName: String(name)
        });
    }
    options || (options = getDefaultAppConfig());
    if (!options) {
        throw ERROR_FACTORY.create("no-options" /* AppError.NO_OPTIONS */);
    }
    const existingApp = _apps.get(name);
    if (existingApp) {
        // return the existing app if options and config deep equal the ones in the existing app.
        if (!deepEqual(options, existingApp.options)) {
            throw ERROR_FACTORY.create("duplicate-app" /* AppError.DUPLICATE_APP */, {
                appName: name,
                mismatchedParam: 'options',
                oldValue: JSON.stringify(existingApp.options),
                newValue: JSON.stringify(options)
            });
        }
        else if (!deepEqual(config, existingApp.config)) {
            throw ERROR_FACTORY.create("duplicate-app" /* AppError.DUPLICATE_APP */, {
                appName: name,
                mismatchedParam: 'config',
                oldValue: JSON.stringify(existingApp.config),
                newValue: JSON.stringify(config)
            });
        }
        else {
            return existingApp;
        }
    }
    const container = new ComponentContainer(name);
    for (const component of _components.values()) {
        container.addComponent(component);
    }
    const newApp = new FirebaseAppImpl(options, config, container);
    _apps.set(name, newApp);
    return newApp;
}
function initializeServerApp(_options, _serverAppConfig = {}) {
    if (isBrowser() && !isWebWorker()) {
        // FirebaseServerApp isn't designed to be run in browsers.
        throw ERROR_FACTORY.create("invalid-server-app-environment" /* AppError.INVALID_SERVER_APP_ENVIRONMENT */);
    }
    let firebaseOptions;
    let serverAppSettings = _serverAppConfig || {};
    if (_options) {
        if (_isFirebaseApp(_options)) {
            firebaseOptions = _options.options;
        }
        else if (_isFirebaseServerAppSettings(_options)) {
            serverAppSettings = _options;
        }
        else {
            firebaseOptions = _options;
        }
    }
    if (serverAppSettings.automaticDataCollectionEnabled === undefined) {
        serverAppSettings.automaticDataCollectionEnabled = true;
    }
    firebaseOptions || (firebaseOptions = getDefaultAppConfig());
    if (!firebaseOptions) {
        throw ERROR_FACTORY.create("no-options" /* AppError.NO_OPTIONS */);
    }
    // Build an app name based on a hash of the configuration options.
    const nameObj = {
        ...serverAppSettings,
        ...firebaseOptions
    };
    // However, Do not mangle the name based on releaseOnDeref, since it will vary between the
    // construction of FirebaseServerApp instances. For example, if the object is the request headers.
    if (nameObj.releaseOnDeref !== undefined) {
        delete nameObj.releaseOnDeref;
    }
    const hashCode = (s) => {
        return [...s].reduce((hash, c) => (Math.imul(31, hash) + c.charCodeAt(0)) | 0, 0);
    };
    if (serverAppSettings.releaseOnDeref !== undefined) {
        if (typeof FinalizationRegistry === 'undefined') {
            throw ERROR_FACTORY.create("finalization-registry-not-supported" /* AppError.FINALIZATION_REGISTRY_NOT_SUPPORTED */, {});
        }
    }
    const nameString = '' + hashCode(JSON.stringify(nameObj));
    const existingApp = _serverApps.get(nameString);
    if (existingApp) {
        existingApp.incRefCount(serverAppSettings.releaseOnDeref);
        return existingApp;
    }
    const container = new ComponentContainer(nameString);
    for (const component of _components.values()) {
        container.addComponent(component);
    }
    const newApp = new FirebaseServerAppImpl(firebaseOptions, serverAppSettings, nameString, container);
    _serverApps.set(nameString, newApp);
    return newApp;
}
/**
 * Retrieves a {@link @firebase/app#FirebaseApp} instance.
 *
 * When called with no arguments, the default app is returned. When an app name
 * is provided, the app corresponding to that name is returned.
 *
 * An exception is thrown if the app being retrieved has not yet been
 * initialized.
 *
 * @example
 * ```javascript
 * // Return the default app
 * const app = getApp();
 * ```
 *
 * @example
 * ```javascript
 * // Return a named app
 * const otherApp = getApp("otherApp");
 * ```
 *
 * @param name - Optional name of the app to return. If no name is
 *   provided, the default is `"[DEFAULT]"`.
 *
 * @returns The app corresponding to the provided app name.
 *   If no app name is provided, the default app is returned.
 *
 * @public
 */
function getApp(name = DEFAULT_ENTRY_NAME) {
    const app = _apps.get(name);
    if (!app && name === DEFAULT_ENTRY_NAME && getDefaultAppConfig()) {
        return initializeApp();
    }
    if (!app) {
        throw ERROR_FACTORY.create("no-app" /* AppError.NO_APP */, { appName: name });
    }
    return app;
}
/**
 * A (read-only) array of all initialized apps.
 * @public
 */
function getApps() {
    return Array.from(_apps.values());
}
/**
 * Renders this app unusable and frees the resources of all associated
 * services.
 *
 * @example
 * ```javascript
 * deleteApp(app)
 *   .then(function() {
 *     console.log("App deleted successfully");
 *   })
 *   .catch(function(error) {
 *     console.log("Error deleting app:", error);
 *   });
 * ```
 *
 * @public
 */
async function deleteApp(app) {
    let cleanupProviders = false;
    const name = app.name;
    if (_apps.has(name)) {
        cleanupProviders = true;
        _apps.delete(name);
    }
    else if (_serverApps.has(name)) {
        const firebaseServerApp = app;
        if (firebaseServerApp.decRefCount() <= 0) {
            _serverApps.delete(name);
            cleanupProviders = true;
        }
    }
    if (cleanupProviders) {
        await Promise.all(app.container
            .getProviders()
            .map(provider => provider.delete()));
        app.isDeleted = true;
    }
}
/**
 * Registers a library's name and version for platform logging purposes.
 * @param library - Name of 1p or 3p library (e.g. firestore, angularfire)
 * @param version - Current version of that library.
 * @param variant - Bundle variant, e.g., node, rn, etc.
 *
 * @public
 */
function registerVersion(libraryKeyOrName, version, variant) {
    // TODO: We can use this check to whitelist strings when/if we set up
    // a good whitelist system.
    let library = PLATFORM_LOG_STRING[libraryKeyOrName] ?? libraryKeyOrName;
    if (variant) {
        library += `-${variant}`;
    }
    const libraryMismatch = library.match(/\s|\//);
    const versionMismatch = version.match(/\s|\//);
    if (libraryMismatch || versionMismatch) {
        const warning = [
            `Unable to register library "${library}" with version "${version}":`
        ];
        if (libraryMismatch) {
            warning.push(`library name "${library}" contains illegal characters (whitespace or "/")`);
        }
        if (libraryMismatch && versionMismatch) {
            warning.push('and');
        }
        if (versionMismatch) {
            warning.push(`version name "${version}" contains illegal characters (whitespace or "/")`);
        }
        logger.warn(warning.join(' '));
        return;
    }
    _registerComponent(new Component(`${library}-version`, () => ({ library, version }), "VERSION" /* ComponentType.VERSION */));
}
/**
 * Sets log handler for all Firebase SDKs.
 * @param logCallback - An optional custom log handler that executes user code whenever
 * the Firebase SDK makes a logging call.
 *
 * @public
 */
function onLog(logCallback, options) {
    if (logCallback !== null && typeof logCallback !== 'function') {
        throw ERROR_FACTORY.create("invalid-log-argument" /* AppError.INVALID_LOG_ARGUMENT */);
    }
    setUserLogHandler(logCallback, options);
}
/**
 * Sets log level for all Firebase SDKs.
 *
 * All of the log types above the current log level are captured (i.e. if
 * you set the log level to `info`, errors are logged, but `debug` and
 * `verbose` logs are not).
 *
 * @public
 */
function setLogLevel(logLevel) {
    setLogLevel$1(logLevel);
}

/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const DB_NAME = 'firebase-heartbeat-database';
const DB_VERSION = 1;
const STORE_NAME = 'firebase-heartbeat-store';
let dbPromise = null;
function getDbPromise() {
    if (!dbPromise) {
        dbPromise = openDB(DB_NAME, DB_VERSION, {
            upgrade: (db, oldVersion) => {
                // We don't use 'break' in this switch statement, the fall-through
                // behavior is what we want, because if there are multiple versions between
                // the old version and the current version, we want ALL the migrations
                // that correspond to those versions to run, not only the last one.
                // eslint-disable-next-line default-case
                switch (oldVersion) {
                    case 0:
                        try {
                            db.createObjectStore(STORE_NAME);
                        }
                        catch (e) {
                            // Safari/iOS browsers throw occasional exceptions on
                            // db.createObjectStore() that may be a bug. Avoid blocking
                            // the rest of the app functionality.
                            console.warn(e);
                        }
                }
            }
        }).catch(e => {
            throw ERROR_FACTORY.create("idb-open" /* AppError.IDB_OPEN */, {
                originalErrorMessage: e.message
            });
        });
    }
    return dbPromise;
}
async function readHeartbeatsFromIndexedDB(app) {
    try {
        const db = await getDbPromise();
        const tx = db.transaction(STORE_NAME);
        const result = await tx.objectStore(STORE_NAME).get(computeKey(app));
        // We already have the value but tx.done can throw,
        // so we need to await it here to catch errors
        await tx.done;
        return result;
    }
    catch (e) {
        if (e instanceof FirebaseError) {
            logger.warn(e.message);
        }
        else {
            const idbGetError = ERROR_FACTORY.create("idb-get" /* AppError.IDB_GET */, {
                originalErrorMessage: e?.message
            });
            logger.warn(idbGetError.message);
        }
    }
}
async function writeHeartbeatsToIndexedDB(app, heartbeatObject) {
    try {
        const db = await getDbPromise();
        const tx = db.transaction(STORE_NAME, 'readwrite');
        const objectStore = tx.objectStore(STORE_NAME);
        await objectStore.put(heartbeatObject, computeKey(app));
        await tx.done;
    }
    catch (e) {
        if (e instanceof FirebaseError) {
            logger.warn(e.message);
        }
        else {
            const idbGetError = ERROR_FACTORY.create("idb-set" /* AppError.IDB_WRITE */, {
                originalErrorMessage: e?.message
            });
            logger.warn(idbGetError.message);
        }
    }
}
function computeKey(app) {
    return `${app.name}!${app.options.appId}`;
}

/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const MAX_HEADER_BYTES = 1024;
const MAX_NUM_STORED_HEARTBEATS = 30;
class HeartbeatServiceImpl {
    constructor(container) {
        this.container = container;
        /**
         * In-memory cache for heartbeats, used by getHeartbeatsHeader() to generate
         * the header string.
         * Stores one record per date. This will be consolidated into the standard
         * format of one record per user agent string before being sent as a header.
         * Populated from indexedDB when the controller is instantiated and should
         * be kept in sync with indexedDB.
         * Leave public for easier testing.
         */
        this._heartbeatsCache = null;
        const app = this.container.getProvider('app').getImmediate();
        this._storage = new HeartbeatStorageImpl(app);
        this._heartbeatsCachePromise = this._storage.read().then(result => {
            this._heartbeatsCache = result;
            return result;
        });
    }
    /**
     * Called to report a heartbeat. The function will generate
     * a HeartbeatsByUserAgent object, update heartbeatsCache, and persist it
     * to IndexedDB.
     * Note that we only store one heartbeat per day. So if a heartbeat for today is
     * already logged, subsequent calls to this function in the same day will be ignored.
     */
    async triggerHeartbeat() {
        try {
            const platformLogger = this.container
                .getProvider('platform-logger')
                .getImmediate();
            // This is the "Firebase user agent" string from the platform logger
            // service, not the browser user agent.
            const agent = platformLogger.getPlatformInfoString();
            const date = getUTCDateString();
            if (this._heartbeatsCache?.heartbeats == null) {
                this._heartbeatsCache = await this._heartbeatsCachePromise;
                // If we failed to construct a heartbeats cache, then return immediately.
                if (this._heartbeatsCache?.heartbeats == null) {
                    return;
                }
            }
            // Do not store a heartbeat if one is already stored for this day
            // or if a header has already been sent today.
            if (this._heartbeatsCache.lastSentHeartbeatDate === date ||
                this._heartbeatsCache.heartbeats.some(singleDateHeartbeat => singleDateHeartbeat.date === date)) {
                return;
            }
            else {
                // There is no entry for this date. Create one.
                this._heartbeatsCache.heartbeats.push({ date, agent });
                // If the number of stored heartbeats exceeds the maximum number of stored heartbeats, remove the heartbeat with the earliest date.
                // Since this is executed each time a heartbeat is pushed, the limit can only be exceeded by one, so only one needs to be removed.
                if (this._heartbeatsCache.heartbeats.length > MAX_NUM_STORED_HEARTBEATS) {
                    const earliestHeartbeatIdx = getEarliestHeartbeatIdx(this._heartbeatsCache.heartbeats);
                    this._heartbeatsCache.heartbeats.splice(earliestHeartbeatIdx, 1);
                }
            }
            return this._storage.overwrite(this._heartbeatsCache);
        }
        catch (e) {
            logger.warn(e);
        }
    }
    /**
     * Returns a base64 encoded string which can be attached to the heartbeat-specific header directly.
     * It also clears all heartbeats from memory as well as in IndexedDB.
     *
     * NOTE: Consuming product SDKs should not send the header if this method
     * returns an empty string.
     */
    async getHeartbeatsHeader() {
        try {
            if (this._heartbeatsCache === null) {
                await this._heartbeatsCachePromise;
            }
            // If it's still null or the array is empty, there is no data to send.
            if (this._heartbeatsCache?.heartbeats == null ||
                this._heartbeatsCache.heartbeats.length === 0) {
                return '';
            }
            const date = getUTCDateString();
            // Extract as many heartbeats from the cache as will fit under the size limit.
            const { heartbeatsToSend, unsentEntries } = extractHeartbeatsForHeader(this._heartbeatsCache.heartbeats);
            const headerString = base64urlEncodeWithoutPadding(JSON.stringify({ version: 2, heartbeats: heartbeatsToSend }));
            // Store last sent date to prevent another being logged/sent for the same day.
            this._heartbeatsCache.lastSentHeartbeatDate = date;
            if (unsentEntries.length > 0) {
                // Store any unsent entries if they exist.
                this._heartbeatsCache.heartbeats = unsentEntries;
                // This seems more likely than emptying the array (below) to lead to some odd state
                // since the cache isn't empty and this will be called again on the next request,
                // and is probably safest if we await it.
                await this._storage.overwrite(this._heartbeatsCache);
            }
            else {
                this._heartbeatsCache.heartbeats = [];
                // Do not wait for this, to reduce latency.
                void this._storage.overwrite(this._heartbeatsCache);
            }
            return headerString;
        }
        catch (e) {
            logger.warn(e);
            return '';
        }
    }
}
function getUTCDateString() {
    const today = new Date();
    // Returns date format 'YYYY-MM-DD'
    return today.toISOString().substring(0, 10);
}
function extractHeartbeatsForHeader(heartbeatsCache, maxSize = MAX_HEADER_BYTES) {
    // Heartbeats grouped by user agent in the standard format to be sent in
    // the header.
    const heartbeatsToSend = [];
    // Single date format heartbeats that are not sent.
    let unsentEntries = heartbeatsCache.slice();
    for (const singleDateHeartbeat of heartbeatsCache) {
        // Look for an existing entry with the same user agent.
        const heartbeatEntry = heartbeatsToSend.find(hb => hb.agent === singleDateHeartbeat.agent);
        if (!heartbeatEntry) {
            // If no entry for this user agent exists, create one.
            heartbeatsToSend.push({
                agent: singleDateHeartbeat.agent,
                dates: [singleDateHeartbeat.date]
            });
            if (countBytes(heartbeatsToSend) > maxSize) {
                // If the header would exceed max size, remove the added heartbeat
                // entry and stop adding to the header.
                heartbeatsToSend.pop();
                break;
            }
        }
        else {
            heartbeatEntry.dates.push(singleDateHeartbeat.date);
            // If the header would exceed max size, remove the added date
            // and stop adding to the header.
            if (countBytes(heartbeatsToSend) > maxSize) {
                heartbeatEntry.dates.pop();
                break;
            }
        }
        // Pop unsent entry from queue. (Skipped if adding the entry exceeded
        // quota and the loop breaks early.)
        unsentEntries = unsentEntries.slice(1);
    }
    return {
        heartbeatsToSend,
        unsentEntries
    };
}
class HeartbeatStorageImpl {
    constructor(app) {
        this.app = app;
        this._canUseIndexedDBPromise = this.runIndexedDBEnvironmentCheck();
    }
    async runIndexedDBEnvironmentCheck() {
        if (!isIndexedDBAvailable()) {
            return false;
        }
        else {
            return validateIndexedDBOpenable()
                .then(() => true)
                .catch(() => false);
        }
    }
    /**
     * Read all heartbeats.
     */
    async read() {
        const canUseIndexedDB = await this._canUseIndexedDBPromise;
        if (!canUseIndexedDB) {
            return { heartbeats: [] };
        }
        else {
            const idbHeartbeatObject = await readHeartbeatsFromIndexedDB(this.app);
            if (idbHeartbeatObject?.heartbeats) {
                return idbHeartbeatObject;
            }
            else {
                return { heartbeats: [] };
            }
        }
    }
    // overwrite the storage with the provided heartbeats
    async overwrite(heartbeatsObject) {
        const canUseIndexedDB = await this._canUseIndexedDBPromise;
        if (!canUseIndexedDB) {
            return;
        }
        else {
            const existingHeartbeatsObject = await this.read();
            return writeHeartbeatsToIndexedDB(this.app, {
                lastSentHeartbeatDate: heartbeatsObject.lastSentHeartbeatDate ??
                    existingHeartbeatsObject.lastSentHeartbeatDate,
                heartbeats: heartbeatsObject.heartbeats
            });
        }
    }
    // add heartbeats
    async add(heartbeatsObject) {
        const canUseIndexedDB = await this._canUseIndexedDBPromise;
        if (!canUseIndexedDB) {
            return;
        }
        else {
            const existingHeartbeatsObject = await this.read();
            return writeHeartbeatsToIndexedDB(this.app, {
                lastSentHeartbeatDate: heartbeatsObject.lastSentHeartbeatDate ??
                    existingHeartbeatsObject.lastSentHeartbeatDate,
                heartbeats: [
                    ...existingHeartbeatsObject.heartbeats,
                    ...heartbeatsObject.heartbeats
                ]
            });
        }
    }
}
/**
 * Calculate bytes of a HeartbeatsByUserAgent array after being wrapped
 * in a platform logging header JSON object, stringified, and converted
 * to base 64.
 */
function countBytes(heartbeatsCache) {
    // base64 has a restricted set of characters, all of which should be 1 byte.
    return base64urlEncodeWithoutPadding(
    // heartbeatsCache wrapper properties
    JSON.stringify({ version: 2, heartbeats: heartbeatsCache })).length;
}
/**
 * Returns the index of the heartbeat with the earliest date.
 * If the heartbeats array is empty, -1 is returned.
 */
function getEarliestHeartbeatIdx(heartbeats) {
    if (heartbeats.length === 0) {
        return -1;
    }
    let earliestHeartbeatIdx = 0;
    let earliestHeartbeatDate = heartbeats[0].date;
    for (let i = 1; i < heartbeats.length; i++) {
        if (heartbeats[i].date < earliestHeartbeatDate) {
            earliestHeartbeatDate = heartbeats[i].date;
            earliestHeartbeatIdx = i;
        }
    }
    return earliestHeartbeatIdx;
}

/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function registerCoreComponents(variant) {
    _registerComponent(new Component('platform-logger', container => new PlatformLoggerServiceImpl(container), "PRIVATE" /* ComponentType.PRIVATE */));
    _registerComponent(new Component('heartbeat', container => new HeartbeatServiceImpl(container), "PRIVATE" /* ComponentType.PRIVATE */));
    // Register `app` package.
    registerVersion(name$q, version$1, variant);
    // BUILD_TARGET will be replaced by values like esm, cjs, etc during the compilation
    registerVersion(name$q, version$1, 'esm2020');
    // Register platform SDK identifier (no version).
    registerVersion('fire-js', '');
}

/**
 * Firebase App
 *
 * @remarks This package coordinates the communication between the different Firebase components
 * @packageDocumentation
 */
/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
registerCoreComponents('');

export { SDK_VERSION, DEFAULT_ENTRY_NAME as _DEFAULT_ENTRY_NAME, _addComponent, _addOrOverwriteComponent, _apps, _clearComponents, _components, _getProvider, _isFirebaseApp, _isFirebaseServerApp, _isFirebaseServerAppSettings, _registerComponent, _removeServiceInstance, _serverApps, deleteApp, getApp, getApps, initializeApp, initializeServerApp, onLog, registerVersion, setLogLevel };
                                     

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguZXNtLmpzIiwic291cmNlcyI6WyIuLi8uLi9zcmMvcGxhdGZvcm1Mb2dnZXJTZXJ2aWNlLnRzIiwiLi4vLi4vc3JjL2xvZ2dlci50cyIsIi4uLy4uL3NyYy9jb25zdGFudHMudHMiLCIuLi8uLi9zcmMvaW50ZXJuYWwudHMiLCIuLi8uLi9zcmMvZXJyb3JzLnRzIiwiLi4vLi4vc3JjL2ZpcmViYXNlQXBwLnRzIiwiLi4vLi4vc3JjL2ZpcmViYXNlU2VydmVyQXBwLnRzIiwiLi4vLi4vc3JjL2FwaS50cyIsIi4uLy4uL3NyYy9pbmRleGVkZGIudHMiLCIuLi8uLi9zcmMvaGVhcnRiZWF0U2VydmljZS50cyIsIi4uLy4uL3NyYy9yZWdpc3RlckNvcmVDb21wb25lbnRzLnRzIiwiLi4vLi4vc3JjL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmltcG9ydCB7XG4gIENvbXBvbmVudENvbnRhaW5lcixcbiAgQ29tcG9uZW50VHlwZSxcbiAgUHJvdmlkZXIsXG4gIE5hbWVcbn0gZnJvbSAnQGZpcmViYXNlL2NvbXBvbmVudCc7XG5pbXBvcnQgeyBQbGF0Zm9ybUxvZ2dlclNlcnZpY2UsIFZlcnNpb25TZXJ2aWNlIH0gZnJvbSAnLi90eXBlcyc7XG5cbmV4cG9ydCBjbGFzcyBQbGF0Zm9ybUxvZ2dlclNlcnZpY2VJbXBsIGltcGxlbWVudHMgUGxhdGZvcm1Mb2dnZXJTZXJ2aWNlIHtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSByZWFkb25seSBjb250YWluZXI6IENvbXBvbmVudENvbnRhaW5lcikge31cbiAgLy8gSW4gaW5pdGlhbCBpbXBsZW1lbnRhdGlvbiwgdGhpcyB3aWxsIGJlIGNhbGxlZCBieSBpbnN0YWxsYXRpb25zIG9uXG4gIC8vIGF1dGggdG9rZW4gcmVmcmVzaCwgYW5kIGluc3RhbGxhdGlvbnMgd2lsbCBzZW5kIHRoaXMgc3RyaW5nLlxuICBnZXRQbGF0Zm9ybUluZm9TdHJpbmcoKTogc3RyaW5nIHtcbiAgICBjb25zdCBwcm92aWRlcnMgPSB0aGlzLmNvbnRhaW5lci5nZXRQcm92aWRlcnMoKTtcbiAgICAvLyBMb29wIHRocm91Z2ggcHJvdmlkZXJzIGFuZCBnZXQgbGlicmFyeS92ZXJzaW9uIHBhaXJzIGZyb20gYW55IHRoYXQgYXJlXG4gICAgLy8gdmVyc2lvbiBjb21wb25lbnRzLlxuICAgIHJldHVybiBwcm92aWRlcnNcbiAgICAgIC5tYXAocHJvdmlkZXIgPT4ge1xuICAgICAgICBpZiAoaXNWZXJzaW9uU2VydmljZVByb3ZpZGVyKHByb3ZpZGVyKSkge1xuICAgICAgICAgIGNvbnN0IHNlcnZpY2UgPSBwcm92aWRlci5nZXRJbW1lZGlhdGUoKSBhcyBWZXJzaW9uU2VydmljZTtcbiAgICAgICAgICByZXR1cm4gYCR7c2VydmljZS5saWJyYXJ5fS8ke3NlcnZpY2UudmVyc2lvbn1gO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICB9KVxuICAgICAgLmZpbHRlcihsb2dTdHJpbmcgPT4gbG9nU3RyaW5nKVxuICAgICAgLmpvaW4oJyAnKTtcbiAgfVxufVxuLyoqXG4gKlxuICogQHBhcmFtIHByb3ZpZGVyIGNoZWNrIGlmIHRoaXMgcHJvdmlkZXIgcHJvdmlkZXMgYSBWZXJzaW9uU2VydmljZVxuICpcbiAqIE5PVEU6IFVzaW5nIFByb3ZpZGVyPCdhcHAtdmVyc2lvbic+IGlzIGEgaGFjayB0byBpbmRpY2F0ZSB0aGF0IHRoZSBwcm92aWRlclxuICogcHJvdmlkZXMgVmVyc2lvblNlcnZpY2UuIFRoZSBwcm92aWRlciBpcyBub3QgbmVjZXNzYXJpbHkgYSAnYXBwLXZlcnNpb24nXG4gKiBwcm92aWRlci5cbiAqL1xuZnVuY3Rpb24gaXNWZXJzaW9uU2VydmljZVByb3ZpZGVyKHByb3ZpZGVyOiBQcm92aWRlcjxOYW1lPik6IGJvb2xlYW4ge1xuICBjb25zdCBjb21wb25lbnQgPSBwcm92aWRlci5nZXRDb21wb25lbnQoKTtcbiAgcmV0dXJuIGNvbXBvbmVudD8udHlwZSA9PT0gQ29tcG9uZW50VHlwZS5WRVJTSU9OO1xufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgTG9nZ2VyIH0gZnJvbSAnQGZpcmViYXNlL2xvZ2dlcic7XG5cbmV4cG9ydCBjb25zdCBsb2dnZXIgPSBuZXcgTG9nZ2VyKCdAZmlyZWJhc2UvYXBwJyk7XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG5pbXBvcnQgeyBuYW1lIGFzIGFwcE5hbWUgfSBmcm9tICcuLi9wYWNrYWdlLmpzb24nO1xuaW1wb3J0IHsgbmFtZSBhcyBhcHBDb21wYXROYW1lIH0gZnJvbSAnLi4vLi4vYXBwLWNvbXBhdC9wYWNrYWdlLmpzb24nO1xuaW1wb3J0IHsgbmFtZSBhcyBhbmFseXRpY3NDb21wYXROYW1lIH0gZnJvbSAnLi4vLi4vLi4vcGFja2FnZXMvYW5hbHl0aWNzLWNvbXBhdC9wYWNrYWdlLmpzb24nO1xuaW1wb3J0IHsgbmFtZSBhcyBhbmFseXRpY3NOYW1lIH0gZnJvbSAnLi4vLi4vLi4vcGFja2FnZXMvYW5hbHl0aWNzL3BhY2thZ2UuanNvbic7XG5pbXBvcnQgeyBuYW1lIGFzIGFwcENoZWNrQ29tcGF0TmFtZSB9IGZyb20gJy4uLy4uLy4uL3BhY2thZ2VzL2FwcC1jaGVjay1jb21wYXQvcGFja2FnZS5qc29uJztcbmltcG9ydCB7IG5hbWUgYXMgYXBwQ2hlY2tOYW1lIH0gZnJvbSAnLi4vLi4vLi4vcGFja2FnZXMvYXBwLWNoZWNrL3BhY2thZ2UuanNvbic7XG5pbXBvcnQgeyBuYW1lIGFzIGF1dGhOYW1lIH0gZnJvbSAnLi4vLi4vLi4vcGFja2FnZXMvYXV0aC9wYWNrYWdlLmpzb24nO1xuaW1wb3J0IHsgbmFtZSBhcyBhdXRoQ29tcGF0TmFtZSB9IGZyb20gJy4uLy4uLy4uL3BhY2thZ2VzL2F1dGgtY29tcGF0L3BhY2thZ2UuanNvbic7XG5pbXBvcnQgeyBuYW1lIGFzIGRhdGFiYXNlTmFtZSB9IGZyb20gJy4uLy4uLy4uL3BhY2thZ2VzL2RhdGFiYXNlL3BhY2thZ2UuanNvbic7XG5pbXBvcnQgeyBuYW1lIGFzIGRhdGFjb25uZWN0TmFtZSB9IGZyb20gJy4uLy4uLy4uL3BhY2thZ2VzL2RhdGEtY29ubmVjdC9wYWNrYWdlLmpzb24nO1xuaW1wb3J0IHsgbmFtZSBhcyBkYXRhYmFzZUNvbXBhdE5hbWUgfSBmcm9tICcuLi8uLi8uLi9wYWNrYWdlcy9kYXRhYmFzZS1jb21wYXQvcGFja2FnZS5qc29uJztcbmltcG9ydCB7IG5hbWUgYXMgZnVuY3Rpb25zTmFtZSB9IGZyb20gJy4uLy4uLy4uL3BhY2thZ2VzL2Z1bmN0aW9ucy9wYWNrYWdlLmpzb24nO1xuaW1wb3J0IHsgbmFtZSBhcyBmdW5jdGlvbnNDb21wYXROYW1lIH0gZnJvbSAnLi4vLi4vLi4vcGFja2FnZXMvZnVuY3Rpb25zLWNvbXBhdC9wYWNrYWdlLmpzb24nO1xuaW1wb3J0IHsgbmFtZSBhcyBpbnN0YWxsYXRpb25zTmFtZSB9IGZyb20gJy4uLy4uLy4uL3BhY2thZ2VzL2luc3RhbGxhdGlvbnMvcGFja2FnZS5qc29uJztcbmltcG9ydCB7IG5hbWUgYXMgaW5zdGFsbGF0aW9uc0NvbXBhdE5hbWUgfSBmcm9tICcuLi8uLi8uLi9wYWNrYWdlcy9pbnN0YWxsYXRpb25zLWNvbXBhdC9wYWNrYWdlLmpzb24nO1xuaW1wb3J0IHsgbmFtZSBhcyBtZXNzYWdpbmdOYW1lIH0gZnJvbSAnLi4vLi4vLi4vcGFja2FnZXMvbWVzc2FnaW5nL3BhY2thZ2UuanNvbic7XG5pbXBvcnQgeyBuYW1lIGFzIG1lc3NhZ2luZ0NvbXBhdE5hbWUgfSBmcm9tICcuLi8uLi8uLi9wYWNrYWdlcy9tZXNzYWdpbmctY29tcGF0L3BhY2thZ2UuanNvbic7XG5pbXBvcnQgeyBuYW1lIGFzIHBlcmZvcm1hbmNlTmFtZSB9IGZyb20gJy4uLy4uLy4uL3BhY2thZ2VzL3BlcmZvcm1hbmNlL3BhY2thZ2UuanNvbic7XG5pbXBvcnQgeyBuYW1lIGFzIHBlcmZvcm1hbmNlQ29tcGF0TmFtZSB9IGZyb20gJy4uLy4uLy4uL3BhY2thZ2VzL3BlcmZvcm1hbmNlLWNvbXBhdC9wYWNrYWdlLmpzb24nO1xuaW1wb3J0IHsgbmFtZSBhcyByZW1vdGVDb25maWdOYW1lIH0gZnJvbSAnLi4vLi4vLi4vcGFja2FnZXMvcmVtb3RlLWNvbmZpZy9wYWNrYWdlLmpzb24nO1xuaW1wb3J0IHsgbmFtZSBhcyByZW1vdGVDb25maWdDb21wYXROYW1lIH0gZnJvbSAnLi4vLi4vLi4vcGFja2FnZXMvcmVtb3RlLWNvbmZpZy1jb21wYXQvcGFja2FnZS5qc29uJztcbmltcG9ydCB7IG5hbWUgYXMgc3RvcmFnZU5hbWUgfSBmcm9tICcuLi8uLi8uLi9wYWNrYWdlcy9zdG9yYWdlL3BhY2thZ2UuanNvbic7XG5pbXBvcnQgeyBuYW1lIGFzIHN0b3JhZ2VDb21wYXROYW1lIH0gZnJvbSAnLi4vLi4vLi4vcGFja2FnZXMvc3RvcmFnZS1jb21wYXQvcGFja2FnZS5qc29uJztcbmltcG9ydCB7IG5hbWUgYXMgZmlyZXN0b3JlTmFtZSB9IGZyb20gJy4uLy4uLy4uL3BhY2thZ2VzL2ZpcmVzdG9yZS9wYWNrYWdlLmpzb24nO1xuaW1wb3J0IHsgbmFtZSBhcyBhaU5hbWUgfSBmcm9tICcuLi8uLi8uLi9wYWNrYWdlcy9haS9wYWNrYWdlLmpzb24nO1xuaW1wb3J0IHsgbmFtZSBhcyBmaXJlc3RvcmVDb21wYXROYW1lIH0gZnJvbSAnLi4vLi4vLi4vcGFja2FnZXMvZmlyZXN0b3JlLWNvbXBhdC9wYWNrYWdlLmpzb24nO1xuaW1wb3J0IHsgbmFtZSBhcyBwYWNrYWdlTmFtZSB9IGZyb20gJy4uLy4uLy4uL3BhY2thZ2VzL2ZpcmViYXNlL3BhY2thZ2UuanNvbic7XG5cbi8qKlxuICogVGhlIGRlZmF1bHQgYXBwIG5hbWVcbiAqXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGNvbnN0IERFRkFVTFRfRU5UUllfTkFNRSA9ICdbREVGQVVMVF0nO1xuXG5leHBvcnQgY29uc3QgUExBVEZPUk1fTE9HX1NUUklORyA9IHtcbiAgW2FwcE5hbWVdOiAnZmlyZS1jb3JlJyxcbiAgW2FwcENvbXBhdE5hbWVdOiAnZmlyZS1jb3JlLWNvbXBhdCcsXG4gIFthbmFseXRpY3NOYW1lXTogJ2ZpcmUtYW5hbHl0aWNzJyxcbiAgW2FuYWx5dGljc0NvbXBhdE5hbWVdOiAnZmlyZS1hbmFseXRpY3MtY29tcGF0JyxcbiAgW2FwcENoZWNrTmFtZV06ICdmaXJlLWFwcC1jaGVjaycsXG4gIFthcHBDaGVja0NvbXBhdE5hbWVdOiAnZmlyZS1hcHAtY2hlY2stY29tcGF0JyxcbiAgW2F1dGhOYW1lXTogJ2ZpcmUtYXV0aCcsXG4gIFthdXRoQ29tcGF0TmFtZV06ICdmaXJlLWF1dGgtY29tcGF0JyxcbiAgW2RhdGFiYXNlTmFtZV06ICdmaXJlLXJ0ZGInLFxuICBbZGF0YWNvbm5lY3ROYW1lXTogJ2ZpcmUtZGF0YS1jb25uZWN0JyxcbiAgW2RhdGFiYXNlQ29tcGF0TmFtZV06ICdmaXJlLXJ0ZGItY29tcGF0JyxcbiAgW2Z1bmN0aW9uc05hbWVdOiAnZmlyZS1mbicsXG4gIFtmdW5jdGlvbnNDb21wYXROYW1lXTogJ2ZpcmUtZm4tY29tcGF0JyxcbiAgW2luc3RhbGxhdGlvbnNOYW1lXTogJ2ZpcmUtaWlkJyxcbiAgW2luc3RhbGxhdGlvbnNDb21wYXROYW1lXTogJ2ZpcmUtaWlkLWNvbXBhdCcsXG4gIFttZXNzYWdpbmdOYW1lXTogJ2ZpcmUtZmNtJyxcbiAgW21lc3NhZ2luZ0NvbXBhdE5hbWVdOiAnZmlyZS1mY20tY29tcGF0JyxcbiAgW3BlcmZvcm1hbmNlTmFtZV06ICdmaXJlLXBlcmYnLFxuICBbcGVyZm9ybWFuY2VDb21wYXROYW1lXTogJ2ZpcmUtcGVyZi1jb21wYXQnLFxuICBbcmVtb3RlQ29uZmlnTmFtZV06ICdmaXJlLXJjJyxcbiAgW3JlbW90ZUNvbmZpZ0NvbXBhdE5hbWVdOiAnZmlyZS1yYy1jb21wYXQnLFxuICBbc3RvcmFnZU5hbWVdOiAnZmlyZS1nY3MnLFxuICBbc3RvcmFnZUNvbXBhdE5hbWVdOiAnZmlyZS1nY3MtY29tcGF0JyxcbiAgW2ZpcmVzdG9yZU5hbWVdOiAnZmlyZS1mc3QnLFxuICBbZmlyZXN0b3JlQ29tcGF0TmFtZV06ICdmaXJlLWZzdC1jb21wYXQnLFxuICBbYWlOYW1lXTogJ2ZpcmUtdmVydGV4JyxcbiAgJ2ZpcmUtanMnOiAnZmlyZS1qcycsIC8vIFBsYXRmb3JtIGlkZW50aWZpZXIgZm9yIEpTIFNESy5cbiAgW3BhY2thZ2VOYW1lXTogJ2ZpcmUtanMtYWxsJ1xufSBhcyBjb25zdDtcbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDE5IEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmltcG9ydCB7XG4gIEZpcmViYXNlQXBwLFxuICBGaXJlYmFzZUFwcFNldHRpbmdzLFxuICBGaXJlYmFzZVNlcnZlckFwcFNldHRpbmdzLFxuICBGaXJlYmFzZU9wdGlvbnMsXG4gIEZpcmViYXNlU2VydmVyQXBwXG59IGZyb20gJy4vcHVibGljLXR5cGVzJztcbmltcG9ydCB7IENvbXBvbmVudCwgUHJvdmlkZXIsIE5hbWUgfSBmcm9tICdAZmlyZWJhc2UvY29tcG9uZW50JztcbmltcG9ydCB7IGxvZ2dlciB9IGZyb20gJy4vbG9nZ2VyJztcbmltcG9ydCB7IERFRkFVTFRfRU5UUllfTkFNRSB9IGZyb20gJy4vY29uc3RhbnRzJztcbmltcG9ydCB7IEZpcmViYXNlQXBwSW1wbCB9IGZyb20gJy4vZmlyZWJhc2VBcHAnO1xuaW1wb3J0IHsgRmlyZWJhc2VTZXJ2ZXJBcHBJbXBsIH0gZnJvbSAnLi9maXJlYmFzZVNlcnZlckFwcCc7XG5cbi8qKlxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCBjb25zdCBfYXBwcyA9IG5ldyBNYXA8c3RyaW5nLCBGaXJlYmFzZUFwcD4oKTtcblxuLyoqXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGNvbnN0IF9zZXJ2ZXJBcHBzID0gbmV3IE1hcDxzdHJpbmcsIEZpcmViYXNlU2VydmVyQXBwPigpO1xuXG4vKipcbiAqIFJlZ2lzdGVyZWQgY29tcG9uZW50cy5cbiAqXG4gKiBAaW50ZXJuYWxcbiAqL1xuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby1leHBsaWNpdC1hbnlcbmV4cG9ydCBjb25zdCBfY29tcG9uZW50cyA9IG5ldyBNYXA8c3RyaW5nLCBDb21wb25lbnQ8YW55Pj4oKTtcblxuLyoqXG4gKiBAcGFyYW0gY29tcG9uZW50IC0gdGhlIGNvbXBvbmVudCBiZWluZyBhZGRlZCB0byB0aGlzIGFwcCdzIGNvbnRhaW5lclxuICpcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgZnVuY3Rpb24gX2FkZENvbXBvbmVudDxUIGV4dGVuZHMgTmFtZT4oXG4gIGFwcDogRmlyZWJhc2VBcHAsXG4gIGNvbXBvbmVudDogQ29tcG9uZW50PFQ+XG4pOiB2b2lkIHtcbiAgdHJ5IHtcbiAgICAoYXBwIGFzIEZpcmViYXNlQXBwSW1wbCkuY29udGFpbmVyLmFkZENvbXBvbmVudChjb21wb25lbnQpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgbG9nZ2VyLmRlYnVnKFxuICAgICAgYENvbXBvbmVudCAke2NvbXBvbmVudC5uYW1lfSBmYWlsZWQgdG8gcmVnaXN0ZXIgd2l0aCBGaXJlYmFzZUFwcCAke2FwcC5uYW1lfWAsXG4gICAgICBlXG4gICAgKTtcbiAgfVxufVxuXG4vKipcbiAqXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIF9hZGRPck92ZXJ3cml0ZUNvbXBvbmVudChcbiAgYXBwOiBGaXJlYmFzZUFwcCxcbiAgY29tcG9uZW50OiBDb21wb25lbnRcbik6IHZvaWQge1xuICAoYXBwIGFzIEZpcmViYXNlQXBwSW1wbCkuY29udGFpbmVyLmFkZE9yT3ZlcndyaXRlQ29tcG9uZW50KGNvbXBvbmVudCk7XG59XG5cbi8qKlxuICpcbiAqIEBwYXJhbSBjb21wb25lbnQgLSB0aGUgY29tcG9uZW50IHRvIHJlZ2lzdGVyXG4gKiBAcmV0dXJucyB3aGV0aGVyIG9yIG5vdCB0aGUgY29tcG9uZW50IGlzIHJlZ2lzdGVyZWQgc3VjY2Vzc2Z1bGx5XG4gKlxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBfcmVnaXN0ZXJDb21wb25lbnQ8VCBleHRlbmRzIE5hbWU+KFxuICBjb21wb25lbnQ6IENvbXBvbmVudDxUPlxuKTogYm9vbGVhbiB7XG4gIGNvbnN0IGNvbXBvbmVudE5hbWUgPSBjb21wb25lbnQubmFtZTtcbiAgaWYgKF9jb21wb25lbnRzLmhhcyhjb21wb25lbnROYW1lKSkge1xuICAgIGxvZ2dlci5kZWJ1ZyhcbiAgICAgIGBUaGVyZSB3ZXJlIG11bHRpcGxlIGF0dGVtcHRzIHRvIHJlZ2lzdGVyIGNvbXBvbmVudCAke2NvbXBvbmVudE5hbWV9LmBcbiAgICApO1xuXG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgX2NvbXBvbmVudHMuc2V0KGNvbXBvbmVudE5hbWUsIGNvbXBvbmVudCk7XG5cbiAgLy8gYWRkIHRoZSBjb21wb25lbnQgdG8gZXhpc3RpbmcgYXBwIGluc3RhbmNlc1xuICBmb3IgKGNvbnN0IGFwcCBvZiBfYXBwcy52YWx1ZXMoKSkge1xuICAgIF9hZGRDb21wb25lbnQoYXBwIGFzIEZpcmViYXNlQXBwSW1wbCwgY29tcG9uZW50KTtcbiAgfVxuXG4gIGZvciAoY29uc3Qgc2VydmVyQXBwIG9mIF9zZXJ2ZXJBcHBzLnZhbHVlcygpKSB7XG4gICAgX2FkZENvbXBvbmVudChzZXJ2ZXJBcHAgYXMgRmlyZWJhc2VTZXJ2ZXJBcHBJbXBsLCBjb21wb25lbnQpO1xuICB9XG5cbiAgcmV0dXJuIHRydWU7XG59XG5cbi8qKlxuICpcbiAqIEBwYXJhbSBhcHAgLSBGaXJlYmFzZUFwcCBpbnN0YW5jZVxuICogQHBhcmFtIG5hbWUgLSBzZXJ2aWNlIG5hbWVcbiAqXG4gKiBAcmV0dXJucyB0aGUgcHJvdmlkZXIgZm9yIHRoZSBzZXJ2aWNlIHdpdGggdGhlIG1hdGNoaW5nIG5hbWVcbiAqXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIF9nZXRQcm92aWRlcjxUIGV4dGVuZHMgTmFtZT4oXG4gIGFwcDogRmlyZWJhc2VBcHAsXG4gIG5hbWU6IFRcbik6IFByb3ZpZGVyPFQ+IHtcbiAgY29uc3QgaGVhcnRiZWF0Q29udHJvbGxlciA9IChhcHAgYXMgRmlyZWJhc2VBcHBJbXBsKS5jb250YWluZXJcbiAgICAuZ2V0UHJvdmlkZXIoJ2hlYXJ0YmVhdCcpXG4gICAgLmdldEltbWVkaWF0ZSh7IG9wdGlvbmFsOiB0cnVlIH0pO1xuICBpZiAoaGVhcnRiZWF0Q29udHJvbGxlcikge1xuICAgIHZvaWQgaGVhcnRiZWF0Q29udHJvbGxlci50cmlnZ2VySGVhcnRiZWF0KCk7XG4gIH1cbiAgcmV0dXJuIChhcHAgYXMgRmlyZWJhc2VBcHBJbXBsKS5jb250YWluZXIuZ2V0UHJvdmlkZXIobmFtZSk7XG59XG5cbi8qKlxuICpcbiAqIEBwYXJhbSBhcHAgLSBGaXJlYmFzZUFwcCBpbnN0YW5jZVxuICogQHBhcmFtIG5hbWUgLSBzZXJ2aWNlIG5hbWVcbiAqIEBwYXJhbSBpbnN0YW5jZUlkZW50aWZpZXIgLSBzZXJ2aWNlIGluc3RhbmNlIGlkZW50aWZpZXIgaW4gY2FzZSB0aGUgc2VydmljZSBzdXBwb3J0cyBtdWx0aXBsZSBpbnN0YW5jZXNcbiAqXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIF9yZW1vdmVTZXJ2aWNlSW5zdGFuY2U8VCBleHRlbmRzIE5hbWU+KFxuICBhcHA6IEZpcmViYXNlQXBwLFxuICBuYW1lOiBULFxuICBpbnN0YW5jZUlkZW50aWZpZXI6IHN0cmluZyA9IERFRkFVTFRfRU5UUllfTkFNRVxuKTogdm9pZCB7XG4gIF9nZXRQcm92aWRlcihhcHAsIG5hbWUpLmNsZWFySW5zdGFuY2UoaW5zdGFuY2VJZGVudGlmaWVyKTtcbn1cblxuLyoqXG4gKlxuICogQHBhcmFtIG9iaiAtIGFuIG9iamVjdCBvZiB0eXBlIEZpcmViYXNlQXBwLCBGaXJlYmFzZU9wdGlvbnMgb3IgRmlyZWJhc2VBcHBTZXR0aW5ncy5cbiAqXG4gKiBAcmV0dXJucyB0cnVlIGlmIHRoZSBwcm92aWRlIG9iamVjdCBpcyBvZiB0eXBlIEZpcmViYXNlQXBwLlxuICpcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgZnVuY3Rpb24gX2lzRmlyZWJhc2VBcHAoXG4gIG9iajogRmlyZWJhc2VBcHAgfCBGaXJlYmFzZU9wdGlvbnMgfCBGaXJlYmFzZUFwcFNldHRpbmdzXG4pOiBvYmogaXMgRmlyZWJhc2VBcHAge1xuICByZXR1cm4gKG9iaiBhcyBGaXJlYmFzZUFwcCkub3B0aW9ucyAhPT0gdW5kZWZpbmVkO1xufVxuXG4vKipcbiAqXG4gKiBAcGFyYW0gb2JqIC0gYW4gb2JqZWN0IG9mIHR5cGUgRmlyZWJhc2VBcHAsIEZpcmViYXNlT3B0aW9ucyBvciBGaXJlYmFzZUFwcFNldHRpbmdzLlxuICpcbiAqIEByZXR1cm5zIHRydWUgaWYgdGhlIHByb3ZpZGVkIG9iamVjdCBpcyBvZiB0eXBlIEZpcmViYXNlU2VydmVyQXBwSW1wbC5cbiAqXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIF9pc0ZpcmViYXNlU2VydmVyQXBwU2V0dGluZ3MoXG4gIG9iajogRmlyZWJhc2VBcHAgfCBGaXJlYmFzZU9wdGlvbnMgfCBGaXJlYmFzZUFwcFNldHRpbmdzXG4pOiBvYmogaXMgRmlyZWJhc2VTZXJ2ZXJBcHBTZXR0aW5ncyB7XG4gIGlmIChfaXNGaXJlYmFzZUFwcChvYmopKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiAoXG4gICAgJ2F1dGhJZFRva2VuJyBpbiBvYmogfHxcbiAgICAnYXBwQ2hlY2tUb2tlbicgaW4gb2JqIHx8XG4gICAgJ3JlbGVhc2VPbkRlcmVmJyBpbiBvYmogfHxcbiAgICAnYXV0b21hdGljRGF0YUNvbGxlY3Rpb25FbmFibGVkJyBpbiBvYmpcbiAgKTtcbn1cblxuLyoqXG4gKlxuICogQHBhcmFtIG9iaiAtIGFuIG9iamVjdCBvZiB0eXBlIEZpcmViYXNlQXBwLlxuICpcbiAqIEByZXR1cm5zIHRydWUgaWYgdGhlIHByb3ZpZGVkIG9iamVjdCBpcyBvZiB0eXBlIEZpcmViYXNlU2VydmVyQXBwSW1wbC5cbiAqXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIF9pc0ZpcmViYXNlU2VydmVyQXBwKFxuICBvYmo6IEZpcmViYXNlQXBwIHwgRmlyZWJhc2VTZXJ2ZXJBcHAgfCBudWxsIHwgdW5kZWZpbmVkXG4pOiBvYmogaXMgRmlyZWJhc2VTZXJ2ZXJBcHAge1xuICBpZiAob2JqID09PSBudWxsIHx8IG9iaiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHJldHVybiAob2JqIGFzIEZpcmViYXNlU2VydmVyQXBwKS5zZXR0aW5ncyAhPT0gdW5kZWZpbmVkO1xufVxuXG4vKipcbiAqIFRlc3Qgb25seVxuICpcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgZnVuY3Rpb24gX2NsZWFyQ29tcG9uZW50cygpOiB2b2lkIHtcbiAgX2NvbXBvbmVudHMuY2xlYXIoKTtcbn1cblxuLyoqXG4gKiBFeHBvcnRlZCBpbiBvcmRlciB0byBiZSB1c2VkIGluIGFwcC1jb21wYXQgcGFja2FnZVxuICovXG5leHBvcnQgeyBERUZBVUxUX0VOVFJZX05BTUUgYXMgX0RFRkFVTFRfRU5UUllfTkFNRSB9O1xuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgRXJyb3JGYWN0b3J5LCBFcnJvck1hcCB9IGZyb20gJ0BmaXJlYmFzZS91dGlsJztcblxuZXhwb3J0IGNvbnN0IGVudW0gQXBwRXJyb3Ige1xuICBOT19BUFAgPSAnbm8tYXBwJyxcbiAgQkFEX0FQUF9OQU1FID0gJ2JhZC1hcHAtbmFtZScsXG4gIERVUExJQ0FURV9BUFAgPSAnZHVwbGljYXRlLWFwcCcsXG4gIEFQUF9ERUxFVEVEID0gJ2FwcC1kZWxldGVkJyxcbiAgU0VSVkVSX0FQUF9ERUxFVEVEID0gJ3NlcnZlci1hcHAtZGVsZXRlZCcsXG4gIE5PX09QVElPTlMgPSAnbm8tb3B0aW9ucycsXG4gIElOVkFMSURfQVBQX0FSR1VNRU5UID0gJ2ludmFsaWQtYXBwLWFyZ3VtZW50JyxcbiAgSU5WQUxJRF9MT0dfQVJHVU1FTlQgPSAnaW52YWxpZC1sb2ctYXJndW1lbnQnLFxuICBJREJfT1BFTiA9ICdpZGItb3BlbicsXG4gIElEQl9HRVQgPSAnaWRiLWdldCcsXG4gIElEQl9XUklURSA9ICdpZGItc2V0JyxcbiAgSURCX0RFTEVURSA9ICdpZGItZGVsZXRlJyxcbiAgRklOQUxJWkFUSU9OX1JFR0lTVFJZX05PVF9TVVBQT1JURUQgPSAnZmluYWxpemF0aW9uLXJlZ2lzdHJ5LW5vdC1zdXBwb3J0ZWQnLFxuICBJTlZBTElEX1NFUlZFUl9BUFBfRU5WSVJPTk1FTlQgPSAnaW52YWxpZC1zZXJ2ZXItYXBwLWVudmlyb25tZW50J1xufVxuXG5jb25zdCBFUlJPUlM6IEVycm9yTWFwPEFwcEVycm9yPiA9IHtcbiAgW0FwcEVycm9yLk5PX0FQUF06XG4gICAgXCJObyBGaXJlYmFzZSBBcHAgJ3skYXBwTmFtZX0nIGhhcyBiZWVuIGNyZWF0ZWQgLSBcIiArXG4gICAgJ2NhbGwgaW5pdGlhbGl6ZUFwcCgpIGZpcnN0JyxcbiAgW0FwcEVycm9yLkJBRF9BUFBfTkFNRV06IFwiSWxsZWdhbCBBcHAgbmFtZTogJ3skYXBwTmFtZX0nXCIsXG4gIFtBcHBFcnJvci5EVVBMSUNBVEVfQVBQXTpcbiAgICBcIkZpcmViYXNlIEFwcCBuYW1lZCAneyRhcHBOYW1lfScgYWxyZWFkeSBleGlzdHMgd2l0aCBkaWZmZXJlbnQgeyRtaXNtYXRjaGVkUGFyYW19LlwiICtcbiAgICBcIiBFeGlzdGluZzogJ3skb2xkVmFsdWV9Jy4gTmV3OiAneyRuZXdWYWx1ZX0nLlwiLFxuICBbQXBwRXJyb3IuQVBQX0RFTEVURURdOiBcIkZpcmViYXNlIEFwcCBuYW1lZCAneyRhcHBOYW1lfScgYWxyZWFkeSBkZWxldGVkXCIsXG4gIFtBcHBFcnJvci5TRVJWRVJfQVBQX0RFTEVURURdOiAnRmlyZWJhc2UgU2VydmVyIEFwcCBoYXMgYmVlbiBkZWxldGVkJyxcbiAgW0FwcEVycm9yLk5PX09QVElPTlNdOlxuICAgICdOZWVkIHRvIHByb3ZpZGUgb3B0aW9ucywgd2hlbiBub3QgYmVpbmcgZGVwbG95ZWQgdG8gaG9zdGluZyB2aWEgc291cmNlLicsXG4gIFtBcHBFcnJvci5JTlZBTElEX0FQUF9BUkdVTUVOVF06XG4gICAgJ2ZpcmViYXNlLnskYXBwTmFtZX0oKSB0YWtlcyBlaXRoZXIgbm8gYXJndW1lbnQgb3IgYSAnICtcbiAgICAnRmlyZWJhc2UgQXBwIGluc3RhbmNlLicsXG4gIFtBcHBFcnJvci5JTlZBTElEX0xPR19BUkdVTUVOVF06XG4gICAgJ0ZpcnN0IGFyZ3VtZW50IHRvIGBvbkxvZ2AgbXVzdCBiZSBudWxsIG9yIGEgZnVuY3Rpb24uJyxcbiAgW0FwcEVycm9yLklEQl9PUEVOXTpcbiAgICAnRXJyb3IgdGhyb3duIHdoZW4gb3BlbmluZyBJbmRleGVkREIuIE9yaWdpbmFsIGVycm9yOiB7JG9yaWdpbmFsRXJyb3JNZXNzYWdlfS4nLFxuICBbQXBwRXJyb3IuSURCX0dFVF06XG4gICAgJ0Vycm9yIHRocm93biB3aGVuIHJlYWRpbmcgZnJvbSBJbmRleGVkREIuIE9yaWdpbmFsIGVycm9yOiB7JG9yaWdpbmFsRXJyb3JNZXNzYWdlfS4nLFxuICBbQXBwRXJyb3IuSURCX1dSSVRFXTpcbiAgICAnRXJyb3IgdGhyb3duIHdoZW4gd3JpdGluZyB0byBJbmRleGVkREIuIE9yaWdpbmFsIGVycm9yOiB7JG9yaWdpbmFsRXJyb3JNZXNzYWdlfS4nLFxuICBbQXBwRXJyb3IuSURCX0RFTEVURV06XG4gICAgJ0Vycm9yIHRocm93biB3aGVuIGRlbGV0aW5nIGZyb20gSW5kZXhlZERCLiBPcmlnaW5hbCBlcnJvcjogeyRvcmlnaW5hbEVycm9yTWVzc2FnZX0uJyxcbiAgW0FwcEVycm9yLkZJTkFMSVpBVElPTl9SRUdJU1RSWV9OT1RfU1VQUE9SVEVEXTpcbiAgICAnRmlyZWJhc2VTZXJ2ZXJBcHAgZGVsZXRlT25EZXJlZiBmaWVsZCBkZWZpbmVkIGJ1dCB0aGUgSlMgcnVudGltZSBkb2VzIG5vdCBzdXBwb3J0IEZpbmFsaXphdGlvblJlZ2lzdHJ5LicsXG4gIFtBcHBFcnJvci5JTlZBTElEX1NFUlZFUl9BUFBfRU5WSVJPTk1FTlRdOlxuICAgICdGaXJlYmFzZVNlcnZlckFwcCBpcyBub3QgZm9yIHVzZSBpbiBicm93c2VyIGVudmlyb25tZW50cy4nXG59O1xuXG5pbnRlcmZhY2UgRXJyb3JQYXJhbXMge1xuICBbQXBwRXJyb3IuTk9fQVBQXTogeyBhcHBOYW1lOiBzdHJpbmcgfTtcbiAgW0FwcEVycm9yLkJBRF9BUFBfTkFNRV06IHsgYXBwTmFtZTogc3RyaW5nIH07XG4gIFtBcHBFcnJvci5EVVBMSUNBVEVfQVBQXToge1xuICAgIGFwcE5hbWU6IHN0cmluZztcbiAgICBtaXNtYXRjaGVkUGFyYW06IHN0cmluZztcbiAgICBvbGRWYWx1ZTogc3RyaW5nO1xuICAgIG5ld1ZhbHVlOiBzdHJpbmc7XG4gIH07XG4gIFtBcHBFcnJvci5BUFBfREVMRVRFRF06IHsgYXBwTmFtZTogc3RyaW5nIH07XG4gIFtBcHBFcnJvci5JTlZBTElEX0FQUF9BUkdVTUVOVF06IHsgYXBwTmFtZTogc3RyaW5nIH07XG4gIFtBcHBFcnJvci5JREJfT1BFTl06IHsgb3JpZ2luYWxFcnJvck1lc3NhZ2U/OiBzdHJpbmcgfTtcbiAgW0FwcEVycm9yLklEQl9HRVRdOiB7IG9yaWdpbmFsRXJyb3JNZXNzYWdlPzogc3RyaW5nIH07XG4gIFtBcHBFcnJvci5JREJfV1JJVEVdOiB7IG9yaWdpbmFsRXJyb3JNZXNzYWdlPzogc3RyaW5nIH07XG4gIFtBcHBFcnJvci5JREJfREVMRVRFXTogeyBvcmlnaW5hbEVycm9yTWVzc2FnZT86IHN0cmluZyB9O1xuICBbQXBwRXJyb3IuRklOQUxJWkFUSU9OX1JFR0lTVFJZX05PVF9TVVBQT1JURURdOiB7IGFwcE5hbWU/OiBzdHJpbmcgfTtcbn1cblxuZXhwb3J0IGNvbnN0IEVSUk9SX0ZBQ1RPUlkgPSBuZXcgRXJyb3JGYWN0b3J5PEFwcEVycm9yLCBFcnJvclBhcmFtcz4oXG4gICdhcHAnLFxuICAnRmlyZWJhc2UnLFxuICBFUlJPUlNcbik7XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG5pbXBvcnQge1xuICBGaXJlYmFzZUFwcCxcbiAgRmlyZWJhc2VPcHRpb25zLFxuICBGaXJlYmFzZUFwcFNldHRpbmdzXG59IGZyb20gJy4vcHVibGljLXR5cGVzJztcbmltcG9ydCB7XG4gIENvbXBvbmVudENvbnRhaW5lcixcbiAgQ29tcG9uZW50LFxuICBDb21wb25lbnRUeXBlXG59IGZyb20gJ0BmaXJlYmFzZS9jb21wb25lbnQnO1xuaW1wb3J0IHsgRVJST1JfRkFDVE9SWSwgQXBwRXJyb3IgfSBmcm9tICcuL2Vycm9ycyc7XG5cbmV4cG9ydCBjbGFzcyBGaXJlYmFzZUFwcEltcGwgaW1wbGVtZW50cyBGaXJlYmFzZUFwcCB7XG4gIHByb3RlY3RlZCByZWFkb25seSBfb3B0aW9uczogRmlyZWJhc2VPcHRpb25zO1xuICBwcm90ZWN0ZWQgcmVhZG9ubHkgX25hbWU6IHN0cmluZztcbiAgLyoqXG4gICAqIE9yaWdpbmFsIGNvbmZpZyB2YWx1ZXMgcGFzc2VkIGluIGFzIGEgY29uc3RydWN0b3IgcGFyYW1ldGVyLlxuICAgKiBJdCBpcyBvbmx5IHVzZWQgdG8gY29tcGFyZSB3aXRoIGFub3RoZXIgY29uZmlnIG9iamVjdCB0byBzdXBwb3J0IGlkZW1wb3RlbnQgaW5pdGlhbGl6ZUFwcCgpLlxuICAgKlxuICAgKiBVcGRhdGluZyBhdXRvbWF0aWNEYXRhQ29sbGVjdGlvbkVuYWJsZWQgb24gdGhlIEFwcCBpbnN0YW5jZSB3aWxsIG5vdCBjaGFuZ2UgaXRzIHZhbHVlIGluIF9jb25maWcuXG4gICAqL1xuICBwcml2YXRlIHJlYWRvbmx5IF9jb25maWc6IFJlcXVpcmVkPEZpcmViYXNlQXBwU2V0dGluZ3M+O1xuICBwcml2YXRlIF9hdXRvbWF0aWNEYXRhQ29sbGVjdGlvbkVuYWJsZWQ6IGJvb2xlYW47XG4gIHByb3RlY3RlZCBfaXNEZWxldGVkID0gZmFsc2U7XG4gIHByaXZhdGUgcmVhZG9ubHkgX2NvbnRhaW5lcjogQ29tcG9uZW50Q29udGFpbmVyO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIG9wdGlvbnM6IEZpcmViYXNlT3B0aW9ucyxcbiAgICBjb25maWc6IFJlcXVpcmVkPEZpcmViYXNlQXBwU2V0dGluZ3M+LFxuICAgIGNvbnRhaW5lcjogQ29tcG9uZW50Q29udGFpbmVyXG4gICkge1xuICAgIHRoaXMuX29wdGlvbnMgPSB7IC4uLm9wdGlvbnMgfTtcbiAgICB0aGlzLl9jb25maWcgPSB7IC4uLmNvbmZpZyB9O1xuICAgIHRoaXMuX25hbWUgPSBjb25maWcubmFtZTtcbiAgICB0aGlzLl9hdXRvbWF0aWNEYXRhQ29sbGVjdGlvbkVuYWJsZWQgPVxuICAgICAgY29uZmlnLmF1dG9tYXRpY0RhdGFDb2xsZWN0aW9uRW5hYmxlZDtcbiAgICB0aGlzLl9jb250YWluZXIgPSBjb250YWluZXI7XG4gICAgdGhpcy5jb250YWluZXIuYWRkQ29tcG9uZW50KFxuICAgICAgbmV3IENvbXBvbmVudCgnYXBwJywgKCkgPT4gdGhpcywgQ29tcG9uZW50VHlwZS5QVUJMSUMpXG4gICAgKTtcbiAgfVxuXG4gIGdldCBhdXRvbWF0aWNEYXRhQ29sbGVjdGlvbkVuYWJsZWQoKTogYm9vbGVhbiB7XG4gICAgdGhpcy5jaGVja0Rlc3Ryb3llZCgpO1xuICAgIHJldHVybiB0aGlzLl9hdXRvbWF0aWNEYXRhQ29sbGVjdGlvbkVuYWJsZWQ7XG4gIH1cblxuICBzZXQgYXV0b21hdGljRGF0YUNvbGxlY3Rpb25FbmFibGVkKHZhbDogYm9vbGVhbikge1xuICAgIHRoaXMuY2hlY2tEZXN0cm95ZWQoKTtcbiAgICB0aGlzLl9hdXRvbWF0aWNEYXRhQ29sbGVjdGlvbkVuYWJsZWQgPSB2YWw7XG4gIH1cblxuICBnZXQgbmFtZSgpOiBzdHJpbmcge1xuICAgIHRoaXMuY2hlY2tEZXN0cm95ZWQoKTtcbiAgICByZXR1cm4gdGhpcy5fbmFtZTtcbiAgfVxuXG4gIGdldCBvcHRpb25zKCk6IEZpcmViYXNlT3B0aW9ucyB7XG4gICAgdGhpcy5jaGVja0Rlc3Ryb3llZCgpO1xuICAgIHJldHVybiB0aGlzLl9vcHRpb25zO1xuICB9XG5cbiAgZ2V0IGNvbmZpZygpOiBSZXF1aXJlZDxGaXJlYmFzZUFwcFNldHRpbmdzPiB7XG4gICAgdGhpcy5jaGVja0Rlc3Ryb3llZCgpO1xuICAgIHJldHVybiB0aGlzLl9jb25maWc7XG4gIH1cblxuICBnZXQgY29udGFpbmVyKCk6IENvbXBvbmVudENvbnRhaW5lciB7XG4gICAgcmV0dXJuIHRoaXMuX2NvbnRhaW5lcjtcbiAgfVxuXG4gIGdldCBpc0RlbGV0ZWQoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuX2lzRGVsZXRlZDtcbiAgfVxuXG4gIHNldCBpc0RlbGV0ZWQodmFsOiBib29sZWFuKSB7XG4gICAgdGhpcy5faXNEZWxldGVkID0gdmFsO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoaXMgZnVuY3Rpb24gd2lsbCB0aHJvdyBhbiBFcnJvciBpZiB0aGUgQXBwIGhhcyBhbHJlYWR5IGJlZW4gZGVsZXRlZCAtXG4gICAqIHVzZSBiZWZvcmUgcGVyZm9ybWluZyBBUEkgYWN0aW9ucyBvbiB0aGUgQXBwLlxuICAgKi9cbiAgcHJvdGVjdGVkIGNoZWNrRGVzdHJveWVkKCk6IHZvaWQge1xuICAgIGlmICh0aGlzLmlzRGVsZXRlZCkge1xuICAgICAgdGhyb3cgRVJST1JfRkFDVE9SWS5jcmVhdGUoQXBwRXJyb3IuQVBQX0RFTEVURUQsIHsgYXBwTmFtZTogdGhpcy5fbmFtZSB9KTtcbiAgICB9XG4gIH1cbn1cbiIsIi8qKlxuICogQGxpY2Vuc2VcbiAqIENvcHlyaWdodCAyMDIzIEdvb2dsZSBMTENcbiAqXG4gKiBMaWNlbnNlZCB1bmRlciB0aGUgQXBhY2hlIExpY2Vuc2UsIFZlcnNpb24gMi4wICh0aGUgXCJMaWNlbnNlXCIpO1xuICogeW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogWW91IG1heSBvYnRhaW4gYSBjb3B5IG9mIHRoZSBMaWNlbnNlIGF0XG4gKlxuICogICBodHRwOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5cbmltcG9ydCB7XG4gIEZpcmViYXNlQXBwU2V0dGluZ3MsXG4gIEZpcmViYXNlU2VydmVyQXBwLFxuICBGaXJlYmFzZVNlcnZlckFwcFNldHRpbmdzLFxuICBGaXJlYmFzZU9wdGlvbnNcbn0gZnJvbSAnLi9wdWJsaWMtdHlwZXMnO1xuaW1wb3J0IHsgZGVsZXRlQXBwLCByZWdpc3RlclZlcnNpb24gfSBmcm9tICcuL2FwaSc7XG5pbXBvcnQgeyBDb21wb25lbnRDb250YWluZXIgfSBmcm9tICdAZmlyZWJhc2UvY29tcG9uZW50JztcbmltcG9ydCB7IEZpcmViYXNlQXBwSW1wbCB9IGZyb20gJy4vZmlyZWJhc2VBcHAnO1xuaW1wb3J0IHsgRVJST1JfRkFDVE9SWSwgQXBwRXJyb3IgfSBmcm9tICcuL2Vycm9ycyc7XG5pbXBvcnQgeyBuYW1lIGFzIHBhY2thZ2VOYW1lLCB2ZXJzaW9uIH0gZnJvbSAnLi4vcGFja2FnZS5qc29uJztcbmltcG9ydCB7IGJhc2U2NERlY29kZSB9IGZyb20gJ0BmaXJlYmFzZS91dGlsJztcblxuLy8gUGFyc2UgdGhlIHRva2VuIGFuZCBjaGVjayB0byBzZWUgaWYgdGhlIGBleHBgIGNsYWltIGlzIGluIHRoZSBmdXR1cmUuXG4vLyBSZXBvcnRzIGFuIGVycm9yIHRvIHRoZSBjb25zb2xlIGlmIHRoZSB0b2tlbiBvciBjbGFpbSBjb3VsZCBub3QgYmUgcGFyc2VkLCBvciBpZiBgZXhwYCBpcyBpblxuLy8gdGhlIHBhc3QuXG5mdW5jdGlvbiB2YWxpZGF0ZVRva2VuVFRMKGJhc2U2NFRva2VuOiBzdHJpbmcsIHRva2VuTmFtZTogc3RyaW5nKTogdm9pZCB7XG4gIGNvbnN0IHNlY29uZFBhcnQgPSBiYXNlNjREZWNvZGUoYmFzZTY0VG9rZW4uc3BsaXQoJy4nKVsxXSk7XG4gIGlmIChzZWNvbmRQYXJ0ID09PSBudWxsKSB7XG4gICAgY29uc29sZS5lcnJvcihcbiAgICAgIGBGaXJlYmFzZVNlcnZlckFwcCAke3Rva2VuTmFtZX0gaXMgaW52YWxpZDogc2Vjb25kIHBhcnQgY291bGQgbm90IGJlIHBhcnNlZC5gXG4gICAgKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgZXhwQ2xhaW0gPSBKU09OLnBhcnNlKHNlY29uZFBhcnQpLmV4cDtcbiAgaWYgKGV4cENsYWltID09PSB1bmRlZmluZWQpIHtcbiAgICBjb25zb2xlLmVycm9yKFxuICAgICAgYEZpcmViYXNlU2VydmVyQXBwICR7dG9rZW5OYW1lfSBpcyBpbnZhbGlkOiBleHBpcmF0aW9uIGNsYWltIGNvdWxkIG5vdCBiZSBwYXJzZWRgXG4gICAgKTtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgZXhwID0gSlNPTi5wYXJzZShzZWNvbmRQYXJ0KS5leHAgKiAxMDAwO1xuICBjb25zdCBub3cgPSBuZXcgRGF0ZSgpLmdldFRpbWUoKTtcbiAgY29uc3QgZGlmZiA9IGV4cCAtIG5vdztcbiAgaWYgKGRpZmYgPD0gMCkge1xuICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICBgRmlyZWJhc2VTZXJ2ZXJBcHAgJHt0b2tlbk5hbWV9IGlzIGludmFsaWQ6IHRoZSB0b2tlbiBoYXMgZXhwaXJlZC5gXG4gICAgKTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgRmlyZWJhc2VTZXJ2ZXJBcHBJbXBsXG4gIGV4dGVuZHMgRmlyZWJhc2VBcHBJbXBsXG4gIGltcGxlbWVudHMgRmlyZWJhc2VTZXJ2ZXJBcHBcbntcbiAgcHJpdmF0ZSByZWFkb25seSBfc2VydmVyQ29uZmlnOiBGaXJlYmFzZVNlcnZlckFwcFNldHRpbmdzO1xuICBwcml2YXRlIF9maW5hbGl6YXRpb25SZWdpc3RyeTogRmluYWxpemF0aW9uUmVnaXN0cnk8b2JqZWN0PiB8IG51bGw7XG4gIHByaXZhdGUgX3JlZkNvdW50OiBudW1iZXI7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgb3B0aW9uczogRmlyZWJhc2VPcHRpb25zIHwgRmlyZWJhc2VBcHBJbXBsLFxuICAgIHNlcnZlckNvbmZpZzogRmlyZWJhc2VTZXJ2ZXJBcHBTZXR0aW5ncyxcbiAgICBuYW1lOiBzdHJpbmcsXG4gICAgY29udGFpbmVyOiBDb21wb25lbnRDb250YWluZXJcbiAgKSB7XG4gICAgLy8gQnVpbGQgY29uZmlndXJhdGlvbiBwYXJhbWV0ZXJzIGZvciB0aGUgRmlyZWJhc2VBcHBJbXBsIGJhc2UgY2xhc3MuXG4gICAgY29uc3QgYXV0b21hdGljRGF0YUNvbGxlY3Rpb25FbmFibGVkID1cbiAgICAgIHNlcnZlckNvbmZpZy5hdXRvbWF0aWNEYXRhQ29sbGVjdGlvbkVuYWJsZWQgIT09IHVuZGVmaW5lZFxuICAgICAgICA/IHNlcnZlckNvbmZpZy5hdXRvbWF0aWNEYXRhQ29sbGVjdGlvbkVuYWJsZWRcbiAgICAgICAgOiB0cnVlO1xuXG4gICAgLy8gQ3JlYXRlIHRoZSBGaXJlYmFzZUFwcFNldHRpbmdzIG9iamVjdCBmb3IgdGhlIEZpcmViYXNlQXBwSW1wIGNvbnN0cnVjdG9yLlxuICAgIGNvbnN0IGNvbmZpZzogUmVxdWlyZWQ8RmlyZWJhc2VBcHBTZXR0aW5ncz4gPSB7XG4gICAgICBuYW1lLFxuICAgICAgYXV0b21hdGljRGF0YUNvbGxlY3Rpb25FbmFibGVkXG4gICAgfTtcblxuICAgIGlmICgob3B0aW9ucyBhcyBGaXJlYmFzZU9wdGlvbnMpLmFwaUtleSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAvLyBDb25zdHJ1Y3QgdGhlIHBhcmVudCBGaXJlYmFzZUFwcEltcCBvYmplY3QuXG4gICAgICBzdXBlcihvcHRpb25zIGFzIEZpcmViYXNlT3B0aW9ucywgY29uZmlnLCBjb250YWluZXIpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBhcHBJbXBsOiBGaXJlYmFzZUFwcEltcGwgPSBvcHRpb25zIGFzIEZpcmViYXNlQXBwSW1wbDtcbiAgICAgIHN1cGVyKGFwcEltcGwub3B0aW9ucywgY29uZmlnLCBjb250YWluZXIpO1xuICAgIH1cblxuICAgIC8vIE5vdyBjb25zdHJ1Y3QgdGhlIGRhdGEgZm9yIHRoZSBGaXJlYmFzZVNlcnZlckFwcEltcGwuXG4gICAgdGhpcy5fc2VydmVyQ29uZmlnID0ge1xuICAgICAgYXV0b21hdGljRGF0YUNvbGxlY3Rpb25FbmFibGVkLFxuICAgICAgLi4uc2VydmVyQ29uZmlnXG4gICAgfTtcblxuICAgIC8vIEVuc3VyZSB0aGF0IHRoZSBjdXJyZW50IHRpbWUgaXMgd2l0aGluIHRoZSBgYXV0aElkdG9rZW5gIHdpbmRvdyBvZiB2YWxpZGl0eS5cbiAgICBpZiAodGhpcy5fc2VydmVyQ29uZmlnLmF1dGhJZFRva2VuKSB7XG4gICAgICB2YWxpZGF0ZVRva2VuVFRMKHRoaXMuX3NlcnZlckNvbmZpZy5hdXRoSWRUb2tlbiwgJ2F1dGhJZFRva2VuJyk7XG4gICAgfVxuXG4gICAgLy8gRW5zdXJlIHRoYXQgdGhlIGN1cnJlbnQgdGltZSBpcyB3aXRoaW4gdGhlIGBhcHBDaGVja1Rva2VuYCB3aW5kb3cgb2YgdmFsaWRpdHkuXG4gICAgaWYgKHRoaXMuX3NlcnZlckNvbmZpZy5hcHBDaGVja1Rva2VuKSB7XG4gICAgICB2YWxpZGF0ZVRva2VuVFRMKHRoaXMuX3NlcnZlckNvbmZpZy5hcHBDaGVja1Rva2VuLCAnYXBwQ2hlY2tUb2tlbicpO1xuICAgIH1cblxuICAgIHRoaXMuX2ZpbmFsaXphdGlvblJlZ2lzdHJ5ID0gbnVsbDtcbiAgICBpZiAodHlwZW9mIEZpbmFsaXphdGlvblJlZ2lzdHJ5ICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgdGhpcy5fZmluYWxpemF0aW9uUmVnaXN0cnkgPSBuZXcgRmluYWxpemF0aW9uUmVnaXN0cnkoKCkgPT4ge1xuICAgICAgICB0aGlzLmF1dG9tYXRpY0NsZWFudXAoKTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHRoaXMuX3JlZkNvdW50ID0gMDtcbiAgICB0aGlzLmluY1JlZkNvdW50KHRoaXMuX3NlcnZlckNvbmZpZy5yZWxlYXNlT25EZXJlZik7XG5cbiAgICAvLyBEbyBub3QgcmV0YWluIGEgaGFyZCByZWZlcmVuY2UgdG8gdGhlIGRyZWYgb2JqZWN0LCBvdGhlcndpc2UgdGhlIEZpbmFsaXphdGlvblJlZ2lzdHJ5XG4gICAgLy8gd2lsbCBuZXZlciB0cmlnZ2VyLlxuICAgIHRoaXMuX3NlcnZlckNvbmZpZy5yZWxlYXNlT25EZXJlZiA9IHVuZGVmaW5lZDtcbiAgICBzZXJ2ZXJDb25maWcucmVsZWFzZU9uRGVyZWYgPSB1bmRlZmluZWQ7XG5cbiAgICByZWdpc3RlclZlcnNpb24ocGFja2FnZU5hbWUsIHZlcnNpb24sICdzZXJ2ZXJhcHAnKTtcbiAgfVxuXG4gIHRvSlNPTigpOiB1bmRlZmluZWQge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cblxuICBnZXQgcmVmQ291bnQoKTogbnVtYmVyIHtcbiAgICByZXR1cm4gdGhpcy5fcmVmQ291bnQ7XG4gIH1cblxuICAvLyBJbmNyZW1lbnQgdGhlIHJlZmVyZW5jZSBjb3VudCBvZiB0aGlzIHNlcnZlciBhcHAuIElmIGFuIG9iamVjdCBpcyBwcm92aWRlZCwgcmVnaXN0ZXIgaXRcbiAgLy8gd2l0aCB0aGUgZmluYWxpemF0aW9uIHJlZ2lzdHJ5LlxuICBpbmNSZWZDb3VudChvYmo6IG9iamVjdCB8IHVuZGVmaW5lZCk6IHZvaWQge1xuICAgIGlmICh0aGlzLmlzRGVsZXRlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLl9yZWZDb3VudCsrO1xuICAgIGlmIChvYmogIT09IHVuZGVmaW5lZCAmJiB0aGlzLl9maW5hbGl6YXRpb25SZWdpc3RyeSAhPT0gbnVsbCkge1xuICAgICAgdGhpcy5fZmluYWxpemF0aW9uUmVnaXN0cnkucmVnaXN0ZXIob2JqLCB0aGlzKTtcbiAgICB9XG4gIH1cblxuICAvLyBEZWNyZW1lbnQgdGhlIHJlZmVyZW5jZSBjb3VudC5cbiAgZGVjUmVmQ291bnQoKTogbnVtYmVyIHtcbiAgICBpZiAodGhpcy5pc0RlbGV0ZWQpIHtcbiAgICAgIHJldHVybiAwO1xuICAgIH1cbiAgICByZXR1cm4gLS10aGlzLl9yZWZDb3VudDtcbiAgfVxuXG4gIC8vIEludm9rZWQgYnkgdGhlIEZpbmFsaXphdGlvblJlZ2lzdHJ5IGNhbGxiYWNrIHRvIG5vdGUgdGhhdCB0aGlzIGFwcCBzaG91bGQgZ28gdGhyb3VnaCBpdHNcbiAgLy8gcmVmZXJlbmNlIGNvdW50cyBhbmQgZGVsZXRlIGl0c2VsZiBpZiBubyByZWZlcmVuY2UgY291bnQgcmVtYWluLiBUaGUgY29vcmRpbmF0aW5nIGxvZ2ljIHRoYXRcbiAgLy8gaGFuZGxlcyB0aGlzIGlzIGluIGRlbGV0ZUFwcCguLi4pLlxuICBwcml2YXRlIGF1dG9tYXRpY0NsZWFudXAoKTogdm9pZCB7XG4gICAgdm9pZCBkZWxldGVBcHAodGhpcyk7XG4gIH1cblxuICBnZXQgc2V0dGluZ3MoKTogRmlyZWJhc2VTZXJ2ZXJBcHBTZXR0aW5ncyB7XG4gICAgdGhpcy5jaGVja0Rlc3Ryb3llZCgpO1xuICAgIHJldHVybiB0aGlzLl9zZXJ2ZXJDb25maWc7XG4gIH1cblxuICAvKipcbiAgICogVGhpcyBmdW5jdGlvbiB3aWxsIHRocm93IGFuIEVycm9yIGlmIHRoZSBBcHAgaGFzIGFscmVhZHkgYmVlbiBkZWxldGVkIC1cbiAgICogdXNlIGJlZm9yZSBwZXJmb3JtaW5nIEFQSSBhY3Rpb25zIG9uIHRoZSBBcHAuXG4gICAqL1xuICBwcm90ZWN0ZWQgY2hlY2tEZXN0cm95ZWQoKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuaXNEZWxldGVkKSB7XG4gICAgICB0aHJvdyBFUlJPUl9GQUNUT1JZLmNyZWF0ZShBcHBFcnJvci5TRVJWRVJfQVBQX0RFTEVURUQpO1xuICAgIH1cbiAgfVxufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHtcbiAgRmlyZWJhc2VBcHAsXG4gIEZpcmViYXNlU2VydmVyQXBwLFxuICBGaXJlYmFzZU9wdGlvbnMsXG4gIEZpcmViYXNlQXBwU2V0dGluZ3MsXG4gIEZpcmViYXNlU2VydmVyQXBwU2V0dGluZ3Ncbn0gZnJvbSAnLi9wdWJsaWMtdHlwZXMnO1xuaW1wb3J0IHsgREVGQVVMVF9FTlRSWV9OQU1FLCBQTEFURk9STV9MT0dfU1RSSU5HIH0gZnJvbSAnLi9jb25zdGFudHMnO1xuaW1wb3J0IHsgRVJST1JfRkFDVE9SWSwgQXBwRXJyb3IgfSBmcm9tICcuL2Vycm9ycyc7XG5pbXBvcnQge1xuICBDb21wb25lbnRDb250YWluZXIsXG4gIENvbXBvbmVudCxcbiAgTmFtZSxcbiAgQ29tcG9uZW50VHlwZVxufSBmcm9tICdAZmlyZWJhc2UvY29tcG9uZW50JztcbmltcG9ydCB7IHZlcnNpb24gfSBmcm9tICcuLi8uLi9maXJlYmFzZS9wYWNrYWdlLmpzb24nO1xuaW1wb3J0IHsgRmlyZWJhc2VBcHBJbXBsIH0gZnJvbSAnLi9maXJlYmFzZUFwcCc7XG5pbXBvcnQgeyBGaXJlYmFzZVNlcnZlckFwcEltcGwgfSBmcm9tICcuL2ZpcmViYXNlU2VydmVyQXBwJztcbmltcG9ydCB7XG4gIF9hcHBzLFxuICBfY29tcG9uZW50cyxcbiAgX2lzRmlyZWJhc2VBcHAsXG4gIF9pc0ZpcmViYXNlU2VydmVyQXBwU2V0dGluZ3MsXG4gIF9yZWdpc3RlckNvbXBvbmVudCxcbiAgX3NlcnZlckFwcHNcbn0gZnJvbSAnLi9pbnRlcm5hbCc7XG5pbXBvcnQgeyBsb2dnZXIgfSBmcm9tICcuL2xvZ2dlcic7XG5pbXBvcnQge1xuICBMb2dMZXZlbFN0cmluZyxcbiAgc2V0TG9nTGV2ZWwgYXMgc2V0TG9nTGV2ZWxJbXBsLFxuICBMb2dDYWxsYmFjayxcbiAgTG9nT3B0aW9ucyxcbiAgc2V0VXNlckxvZ0hhbmRsZXJcbn0gZnJvbSAnQGZpcmViYXNlL2xvZ2dlcic7XG5pbXBvcnQge1xuICBkZWVwRXF1YWwsXG4gIGdldERlZmF1bHRBcHBDb25maWcsXG4gIGlzQnJvd3NlcixcbiAgaXNXZWJXb3JrZXJcbn0gZnJvbSAnQGZpcmViYXNlL3V0aWwnO1xuXG5leHBvcnQgeyBGaXJlYmFzZUVycm9yIH0gZnJvbSAnQGZpcmViYXNlL3V0aWwnO1xuXG4vKipcbiAqIFRoZSBjdXJyZW50IFNESyB2ZXJzaW9uLlxuICpcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IGNvbnN0IFNES19WRVJTSU9OID0gdmVyc2lvbjtcblxuLyoqXG4gKiBDcmVhdGVzIGFuZCBpbml0aWFsaXplcyBhIHtAbGluayBAZmlyZWJhc2UvYXBwI0ZpcmViYXNlQXBwfSBpbnN0YW5jZS5cbiAqXG4gKiBTZWVcbiAqIHtAbGlua1xuICogICBodHRwczovL2ZpcmViYXNlLmdvb2dsZS5jb20vZG9jcy93ZWIvc2V0dXAjYWRkX2ZpcmViYXNlX3RvX3lvdXJfYXBwXG4gKiAgIHwgQWRkIEZpcmViYXNlIHRvIHlvdXIgYXBwfSBhbmRcbiAqIHtAbGlua1xuICogICBodHRwczovL2ZpcmViYXNlLmdvb2dsZS5jb20vZG9jcy93ZWIvc2V0dXAjbXVsdGlwbGUtcHJvamVjdHNcbiAqICAgfCBJbml0aWFsaXplIG11bHRpcGxlIHByb2plY3RzfSBmb3IgZGV0YWlsZWQgZG9jdW1lbnRhdGlvbi5cbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgamF2YXNjcmlwdFxuICpcbiAqIC8vIEluaXRpYWxpemUgZGVmYXVsdCBhcHBcbiAqIC8vIFJldHJpZXZlIHlvdXIgb3duIG9wdGlvbnMgdmFsdWVzIGJ5IGFkZGluZyBhIHdlYiBhcHAgb25cbiAqIC8vIGh0dHBzOi8vY29uc29sZS5maXJlYmFzZS5nb29nbGUuY29tXG4gKiBpbml0aWFsaXplQXBwKHtcbiAqICAgYXBpS2V5OiBcIkFJemEuLi4uXCIsICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBBdXRoIC8gR2VuZXJhbCBVc2VcbiAqICAgYXV0aERvbWFpbjogXCJZT1VSX0FQUC5maXJlYmFzZWFwcC5jb21cIiwgICAgICAgICAvLyBBdXRoIHdpdGggcG9wdXAvcmVkaXJlY3RcbiAqICAgZGF0YWJhc2VVUkw6IFwiaHR0cHM6Ly9ZT1VSX0FQUC5maXJlYmFzZWlvLmNvbVwiLCAvLyBSZWFsdGltZSBEYXRhYmFzZVxuICogICBzdG9yYWdlQnVja2V0OiBcIllPVVJfQVBQLmFwcHNwb3QuY29tXCIsICAgICAgICAgIC8vIFN0b3JhZ2VcbiAqICAgbWVzc2FnaW5nU2VuZGVySWQ6IFwiMTIzNDU2Nzg5XCIgICAgICAgICAgICAgICAgICAvLyBDbG91ZCBNZXNzYWdpbmdcbiAqIH0pO1xuICogYGBgXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYGphdmFzY3JpcHRcbiAqXG4gKiAvLyBJbml0aWFsaXplIGFub3RoZXIgYXBwXG4gKiBjb25zdCBvdGhlckFwcCA9IGluaXRpYWxpemVBcHAoe1xuICogICBkYXRhYmFzZVVSTDogXCJodHRwczovLzxPVEhFUl9EQVRBQkFTRV9OQU1FPi5maXJlYmFzZWlvLmNvbVwiLFxuICogICBzdG9yYWdlQnVja2V0OiBcIjxPVEhFUl9TVE9SQUdFX0JVQ0tFVD4uYXBwc3BvdC5jb21cIlxuICogfSwgXCJvdGhlckFwcFwiKTtcbiAqIGBgYFxuICpcbiAqIEBwYXJhbSBvcHRpb25zIC0gT3B0aW9ucyB0byBjb25maWd1cmUgdGhlIGFwcCdzIHNlcnZpY2VzLlxuICogQHBhcmFtIG5hbWUgLSBPcHRpb25hbCBuYW1lIG9mIHRoZSBhcHAgdG8gaW5pdGlhbGl6ZS4gSWYgbm8gbmFtZVxuICogICBpcyBwcm92aWRlZCwgdGhlIGRlZmF1bHQgaXMgYFwiW0RFRkFVTFRdXCJgLlxuICpcbiAqIEByZXR1cm5zIFRoZSBpbml0aWFsaXplZCBhcHAuXG4gKlxuICogQHRocm93cyBJZiB0aGUgb3B0aW9uYWwgYG5hbWVgIHBhcmFtZXRlciBpcyBtYWxmb3JtZWQgb3IgZW1wdHkuXG4gKlxuICogQHRocm93cyBJZiBhIGBGaXJlYmFzZUFwcGAgYWxyZWFkeSBleGlzdHMgd2l0aCB0aGUgc2FtZSBuYW1lIGJ1dCB3aXRoIGEgZGlmZmVyZW50IGNvbmZpZ3VyYXRpb24uXG4gKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgZnVuY3Rpb24gaW5pdGlhbGl6ZUFwcChcbiAgb3B0aW9uczogRmlyZWJhc2VPcHRpb25zLFxuICBuYW1lPzogc3RyaW5nXG4pOiBGaXJlYmFzZUFwcDtcbi8qKlxuICogQ3JlYXRlcyBhbmQgaW5pdGlhbGl6ZXMgYSBGaXJlYmFzZUFwcCBpbnN0YW5jZS5cbiAqXG4gKiBAcGFyYW0gb3B0aW9ucyAtIE9wdGlvbnMgdG8gY29uZmlndXJlIHRoZSBhcHAncyBzZXJ2aWNlcy5cbiAqIEBwYXJhbSBjb25maWcgLSBGaXJlYmFzZUFwcCBDb25maWd1cmF0aW9uXG4gKlxuICogQHRocm93cyBJZiB7QGxpbmsgRmlyZWJhc2VBcHBTZXR0aW5ncy5uYW1lfSBpcyBkZWZpbmVkIGJ1dCB0aGUgdmFsdWUgaXMgbWFsZm9ybWVkIG9yIGVtcHR5LlxuICpcbiAqIEB0aHJvd3MgSWYgYSBgRmlyZWJhc2VBcHBgIGFscmVhZHkgZXhpc3RzIHdpdGggdGhlIHNhbWUgbmFtZSBidXQgd2l0aCBhIGRpZmZlcmVudCBjb25maWd1cmF0aW9uLlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgZnVuY3Rpb24gaW5pdGlhbGl6ZUFwcChcbiAgb3B0aW9uczogRmlyZWJhc2VPcHRpb25zLFxuICBjb25maWc/OiBGaXJlYmFzZUFwcFNldHRpbmdzXG4pOiBGaXJlYmFzZUFwcDtcbi8qKlxuICogQ3JlYXRlcyBhbmQgaW5pdGlhbGl6ZXMgYSBGaXJlYmFzZUFwcCBpbnN0YW5jZS5cbiAqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpbml0aWFsaXplQXBwKCk6IEZpcmViYXNlQXBwO1xuZXhwb3J0IGZ1bmN0aW9uIGluaXRpYWxpemVBcHAoXG4gIF9vcHRpb25zPzogRmlyZWJhc2VPcHRpb25zLFxuICByYXdDb25maWcgPSB7fVxuKTogRmlyZWJhc2VBcHAge1xuICBsZXQgb3B0aW9ucyA9IF9vcHRpb25zO1xuXG4gIGlmICh0eXBlb2YgcmF3Q29uZmlnICE9PSAnb2JqZWN0Jykge1xuICAgIGNvbnN0IG5hbWUgPSByYXdDb25maWc7XG4gICAgcmF3Q29uZmlnID0geyBuYW1lIH07XG4gIH1cblxuICBjb25zdCBjb25maWc6IFJlcXVpcmVkPEZpcmViYXNlQXBwU2V0dGluZ3M+ID0ge1xuICAgIG5hbWU6IERFRkFVTFRfRU5UUllfTkFNRSxcbiAgICBhdXRvbWF0aWNEYXRhQ29sbGVjdGlvbkVuYWJsZWQ6IHRydWUsXG4gICAgLi4ucmF3Q29uZmlnXG4gIH07XG4gIGNvbnN0IG5hbWUgPSBjb25maWcubmFtZTtcblxuICBpZiAodHlwZW9mIG5hbWUgIT09ICdzdHJpbmcnIHx8ICFuYW1lKSB7XG4gICAgdGhyb3cgRVJST1JfRkFDVE9SWS5jcmVhdGUoQXBwRXJyb3IuQkFEX0FQUF9OQU1FLCB7XG4gICAgICBhcHBOYW1lOiBTdHJpbmcobmFtZSlcbiAgICB9KTtcbiAgfVxuXG4gIG9wdGlvbnMgfHw9IGdldERlZmF1bHRBcHBDb25maWcoKTtcblxuICBpZiAoIW9wdGlvbnMpIHtcbiAgICB0aHJvdyBFUlJPUl9GQUNUT1JZLmNyZWF0ZShBcHBFcnJvci5OT19PUFRJT05TKTtcbiAgfVxuXG4gIGNvbnN0IGV4aXN0aW5nQXBwID0gX2FwcHMuZ2V0KG5hbWUpIGFzIEZpcmViYXNlQXBwSW1wbDtcbiAgaWYgKGV4aXN0aW5nQXBwKSB7XG4gICAgLy8gcmV0dXJuIHRoZSBleGlzdGluZyBhcHAgaWYgb3B0aW9ucyBhbmQgY29uZmlnIGRlZXAgZXF1YWwgdGhlIG9uZXMgaW4gdGhlIGV4aXN0aW5nIGFwcC5cbiAgICBpZiAoIWRlZXBFcXVhbChvcHRpb25zLCBleGlzdGluZ0FwcC5vcHRpb25zKSkge1xuICAgICAgdGhyb3cgRVJST1JfRkFDVE9SWS5jcmVhdGUoQXBwRXJyb3IuRFVQTElDQVRFX0FQUCwge1xuICAgICAgICBhcHBOYW1lOiBuYW1lLFxuICAgICAgICBtaXNtYXRjaGVkUGFyYW06ICdvcHRpb25zJyxcbiAgICAgICAgb2xkVmFsdWU6IEpTT04uc3RyaW5naWZ5KGV4aXN0aW5nQXBwLm9wdGlvbnMpLFxuICAgICAgICBuZXdWYWx1ZTogSlNPTi5zdHJpbmdpZnkob3B0aW9ucylcbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAoIWRlZXBFcXVhbChjb25maWcsIGV4aXN0aW5nQXBwLmNvbmZpZykpIHtcbiAgICAgIHRocm93IEVSUk9SX0ZBQ1RPUlkuY3JlYXRlKEFwcEVycm9yLkRVUExJQ0FURV9BUFAsIHtcbiAgICAgICAgYXBwTmFtZTogbmFtZSxcbiAgICAgICAgbWlzbWF0Y2hlZFBhcmFtOiAnY29uZmlnJyxcbiAgICAgICAgb2xkVmFsdWU6IEpTT04uc3RyaW5naWZ5KGV4aXN0aW5nQXBwLmNvbmZpZyksXG4gICAgICAgIG5ld1ZhbHVlOiBKU09OLnN0cmluZ2lmeShjb25maWcpXG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIGV4aXN0aW5nQXBwO1xuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGNvbnRhaW5lciA9IG5ldyBDb21wb25lbnRDb250YWluZXIobmFtZSk7XG4gIGZvciAoY29uc3QgY29tcG9uZW50IG9mIF9jb21wb25lbnRzLnZhbHVlcygpKSB7XG4gICAgY29udGFpbmVyLmFkZENvbXBvbmVudChjb21wb25lbnQpO1xuICB9XG5cbiAgY29uc3QgbmV3QXBwID0gbmV3IEZpcmViYXNlQXBwSW1wbChvcHRpb25zLCBjb25maWcsIGNvbnRhaW5lcik7XG5cbiAgX2FwcHMuc2V0KG5hbWUsIG5ld0FwcCk7XG5cbiAgcmV0dXJuIG5ld0FwcDtcbn1cblxuLyoqXG4gKiBDcmVhdGVzIGFuZCBpbml0aWFsaXplcyBhIHtAbGluayBAZmlyZWJhc2UvYXBwI0ZpcmViYXNlU2VydmVyQXBwfSBpbnN0YW5jZS5cbiAqXG4gKiBUaGUgYEZpcmViYXNlU2VydmVyQXBwYCBpcyBzaW1pbGFyIHRvIGBGaXJlYmFzZUFwcGAsIGJ1dCBpcyBpbnRlbmRlZCBmb3IgZXhlY3V0aW9uIGluXG4gKiBzZXJ2ZXIgc2lkZSByZW5kZXJpbmcgZW52aXJvbm1lbnRzIG9ubHkuIEluaXRpYWxpemF0aW9uIHdpbGwgZmFpbCBpZiBpbnZva2VkIGZyb20gYVxuICogYnJvd3NlciBlbnZpcm9ubWVudC5cbiAqXG4gKiBTZWVcbiAqIHtAbGlua1xuICogICBodHRwczovL2ZpcmViYXNlLmdvb2dsZS5jb20vZG9jcy93ZWIvc2V0dXAjYWRkX2ZpcmViYXNlX3RvX3lvdXJfYXBwXG4gKiAgIHwgQWRkIEZpcmViYXNlIHRvIHlvdXIgYXBwfSBhbmRcbiAqIHtAbGlua1xuICogICBodHRwczovL2ZpcmViYXNlLmdvb2dsZS5jb20vZG9jcy93ZWIvc2V0dXAjbXVsdGlwbGUtcHJvamVjdHNcbiAqICAgfCBJbml0aWFsaXplIG11bHRpcGxlIHByb2plY3RzfSBmb3IgZGV0YWlsZWQgZG9jdW1lbnRhdGlvbi5cbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgamF2YXNjcmlwdFxuICpcbiAqIC8vIEluaXRpYWxpemUgYW4gaW5zdGFuY2Ugb2YgYEZpcmViYXNlU2VydmVyQXBwYC5cbiAqIC8vIFJldHJpZXZlIHlvdXIgb3duIG9wdGlvbnMgdmFsdWVzIGJ5IGFkZGluZyBhIHdlYiBhcHAgb25cbiAqIC8vIGh0dHBzOi8vY29uc29sZS5maXJlYmFzZS5nb29nbGUuY29tXG4gKiBpbml0aWFsaXplU2VydmVyQXBwKHtcbiAqICAgICBhcGlLZXk6IFwiQUl6YS4uLi5cIiwgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEF1dGggLyBHZW5lcmFsIFVzZVxuICogICAgIGF1dGhEb21haW46IFwiWU9VUl9BUFAuZmlyZWJhc2VhcHAuY29tXCIsICAgICAgICAgLy8gQXV0aCB3aXRoIHBvcHVwL3JlZGlyZWN0XG4gKiAgICAgZGF0YWJhc2VVUkw6IFwiaHR0cHM6Ly9ZT1VSX0FQUC5maXJlYmFzZWlvLmNvbVwiLCAvLyBSZWFsdGltZSBEYXRhYmFzZVxuICogICAgIHN0b3JhZ2VCdWNrZXQ6IFwiWU9VUl9BUFAuYXBwc3BvdC5jb21cIiwgICAgICAgICAgLy8gU3RvcmFnZVxuICogICAgIG1lc3NhZ2luZ1NlbmRlcklkOiBcIjEyMzQ1Njc4OVwiICAgICAgICAgICAgICAgICAgLy8gQ2xvdWQgTWVzc2FnaW5nXG4gKiAgIH0sXG4gKiAgIHtcbiAqICAgIGF1dGhJZFRva2VuOiBcIllvdXIgQXV0aCBJRCBUb2tlblwiXG4gKiAgIH0pO1xuICogYGBgXG4gKlxuICogQHBhcmFtIG9wdGlvbnMgLSBgRmlyZWJhc2UuQXBwT3B0aW9uc2AgdG8gY29uZmlndXJlIHRoZSBhcHAncyBzZXJ2aWNlcywgb3IgYVxuICogICBhIGBGaXJlYmFzZUFwcGAgaW5zdGFuY2Ugd2hpY2ggY29udGFpbnMgdGhlIGBBcHBPcHRpb25zYCB3aXRoaW4uXG4gKiBAcGFyYW0gY29uZmlnIC0gT3B0aW9uYWwgYEZpcmViYXNlU2VydmVyQXBwYCBzZXR0aW5ncy5cbiAqXG4gKiBAcmV0dXJucyBUaGUgaW5pdGlhbGl6ZWQgYEZpcmViYXNlU2VydmVyQXBwYC5cbiAqXG4gKiBAdGhyb3dzIElmIGludm9rZWQgaW4gYW4gdW5zdXBwb3J0ZWQgbm9uLXNlcnZlciBlbnZpcm9ubWVudCBzdWNoIGFzIGEgYnJvd3Nlci5cbiAqXG4gKiBAdGhyb3dzIElmIHtAbGluayBGaXJlYmFzZVNlcnZlckFwcFNldHRpbmdzLnJlbGVhc2VPbkRlcmVmfSBpcyBkZWZpbmVkIGJ1dCB0aGUgcnVudGltZSBkb2Vzbid0XG4gKiAgIHByb3ZpZGUgRmluYWxpemF0aW9uIFJlZ2lzdHJ5IHN1cHBvcnQuXG4gKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgZnVuY3Rpb24gaW5pdGlhbGl6ZVNlcnZlckFwcChcbiAgb3B0aW9uczogRmlyZWJhc2VPcHRpb25zIHwgRmlyZWJhc2VBcHAsXG4gIGNvbmZpZz86IEZpcmViYXNlU2VydmVyQXBwU2V0dGluZ3Ncbik6IEZpcmViYXNlU2VydmVyQXBwO1xuXG4vKipcbiAqIENyZWF0ZXMgYW5kIGluaXRpYWxpemVzIGEge0BsaW5rIEBmaXJlYmFzZS9hcHAjRmlyZWJhc2VTZXJ2ZXJBcHB9IGluc3RhbmNlLlxuICpcbiAqIEBwYXJhbSBjb25maWcgLSBPcHRpb25hbCBgRmlyZWJhc2VTZXJ2ZXJBcHBgIHNldHRpbmdzLlxuICpcbiAqIEByZXR1cm5zIFRoZSBpbml0aWFsaXplZCBgRmlyZWJhc2VTZXJ2ZXJBcHBgLlxuICpcbiAqIEB0aHJvd3MgSWYgaW52b2tlZCBpbiBhbiB1bnN1cHBvcnRlZCBub24tc2VydmVyIGVudmlyb25tZW50IHN1Y2ggYXMgYSBicm93c2VyLlxuICogQHRocm93cyBJZiB7QGxpbmsgRmlyZWJhc2VTZXJ2ZXJBcHBTZXR0aW5ncy5yZWxlYXNlT25EZXJlZn0gaXMgZGVmaW5lZCBidXQgdGhlIHJ1bnRpbWUgZG9lc24ndFxuICogICBwcm92aWRlIEZpbmFsaXphdGlvbiBSZWdpc3RyeSBzdXBwb3J0LlxuICogQHRocm93cyBJZiB0aGUgYEZJUkVCQVNFX09QVElPTlNgIGVudmlyb25tZW50IHZhcmlhYmxlIGRvZXMgbm90IGNvbnRhaW4gYSB2YWxpZCBwcm9qZWN0XG4gKiAgIGNvbmZpZ3VyYXRpb24gcmVxdWlyZWQgZm9yIGF1dG8taW5pdGlhbGl6YXRpb24uXG4gKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgZnVuY3Rpb24gaW5pdGlhbGl6ZVNlcnZlckFwcChcbiAgY29uZmlnPzogRmlyZWJhc2VTZXJ2ZXJBcHBTZXR0aW5nc1xuKTogRmlyZWJhc2VTZXJ2ZXJBcHA7XG5leHBvcnQgZnVuY3Rpb24gaW5pdGlhbGl6ZVNlcnZlckFwcChcbiAgX29wdGlvbnM/OiBGaXJlYmFzZUFwcCB8IEZpcmViYXNlU2VydmVyQXBwU2V0dGluZ3MgfCBGaXJlYmFzZU9wdGlvbnMsXG4gIF9zZXJ2ZXJBcHBDb25maWc6IEZpcmViYXNlU2VydmVyQXBwU2V0dGluZ3MgPSB7fVxuKTogRmlyZWJhc2VTZXJ2ZXJBcHAge1xuICBpZiAoaXNCcm93c2VyKCkgJiYgIWlzV2ViV29ya2VyKCkpIHtcbiAgICAvLyBGaXJlYmFzZVNlcnZlckFwcCBpc24ndCBkZXNpZ25lZCB0byBiZSBydW4gaW4gYnJvd3NlcnMuXG4gICAgdGhyb3cgRVJST1JfRkFDVE9SWS5jcmVhdGUoQXBwRXJyb3IuSU5WQUxJRF9TRVJWRVJfQVBQX0VOVklST05NRU5UKTtcbiAgfVxuXG4gIGxldCBmaXJlYmFzZU9wdGlvbnM6IEZpcmViYXNlT3B0aW9ucyB8IHVuZGVmaW5lZDtcbiAgbGV0IHNlcnZlckFwcFNldHRpbmdzOiBGaXJlYmFzZVNlcnZlckFwcFNldHRpbmdzID0gX3NlcnZlckFwcENvbmZpZyB8fCB7fTtcblxuICBpZiAoX29wdGlvbnMpIHtcbiAgICBpZiAoX2lzRmlyZWJhc2VBcHAoX29wdGlvbnMpKSB7XG4gICAgICBmaXJlYmFzZU9wdGlvbnMgPSBfb3B0aW9ucy5vcHRpb25zO1xuICAgIH0gZWxzZSBpZiAoX2lzRmlyZWJhc2VTZXJ2ZXJBcHBTZXR0aW5ncyhfb3B0aW9ucykpIHtcbiAgICAgIHNlcnZlckFwcFNldHRpbmdzID0gX29wdGlvbnM7XG4gICAgfSBlbHNlIHtcbiAgICAgIGZpcmViYXNlT3B0aW9ucyA9IF9vcHRpb25zO1xuICAgIH1cbiAgfVxuXG4gIGlmIChzZXJ2ZXJBcHBTZXR0aW5ncy5hdXRvbWF0aWNEYXRhQ29sbGVjdGlvbkVuYWJsZWQgPT09IHVuZGVmaW5lZCkge1xuICAgIHNlcnZlckFwcFNldHRpbmdzLmF1dG9tYXRpY0RhdGFDb2xsZWN0aW9uRW5hYmxlZCA9IHRydWU7XG4gIH1cblxuICBmaXJlYmFzZU9wdGlvbnMgfHw9IGdldERlZmF1bHRBcHBDb25maWcoKTtcbiAgaWYgKCFmaXJlYmFzZU9wdGlvbnMpIHtcbiAgICB0aHJvdyBFUlJPUl9GQUNUT1JZLmNyZWF0ZShBcHBFcnJvci5OT19PUFRJT05TKTtcbiAgfVxuXG4gIC8vIEJ1aWxkIGFuIGFwcCBuYW1lIGJhc2VkIG9uIGEgaGFzaCBvZiB0aGUgY29uZmlndXJhdGlvbiBvcHRpb25zLlxuICBjb25zdCBuYW1lT2JqID0ge1xuICAgIC4uLnNlcnZlckFwcFNldHRpbmdzLFxuICAgIC4uLmZpcmViYXNlT3B0aW9uc1xuICB9O1xuXG4gIC8vIEhvd2V2ZXIsIERvIG5vdCBtYW5nbGUgdGhlIG5hbWUgYmFzZWQgb24gcmVsZWFzZU9uRGVyZWYsIHNpbmNlIGl0IHdpbGwgdmFyeSBiZXR3ZWVuIHRoZVxuICAvLyBjb25zdHJ1Y3Rpb24gb2YgRmlyZWJhc2VTZXJ2ZXJBcHAgaW5zdGFuY2VzLiBGb3IgZXhhbXBsZSwgaWYgdGhlIG9iamVjdCBpcyB0aGUgcmVxdWVzdCBoZWFkZXJzLlxuICBpZiAobmFtZU9iai5yZWxlYXNlT25EZXJlZiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgZGVsZXRlIG5hbWVPYmoucmVsZWFzZU9uRGVyZWY7XG4gIH1cblxuICBjb25zdCBoYXNoQ29kZSA9IChzOiBzdHJpbmcpOiBudW1iZXIgPT4ge1xuICAgIHJldHVybiBbLi4uc10ucmVkdWNlKFxuICAgICAgKGhhc2gsIGMpID0+IChNYXRoLmltdWwoMzEsIGhhc2gpICsgYy5jaGFyQ29kZUF0KDApKSB8IDAsXG4gICAgICAwXG4gICAgKTtcbiAgfTtcblxuICBpZiAoc2VydmVyQXBwU2V0dGluZ3MucmVsZWFzZU9uRGVyZWYgIT09IHVuZGVmaW5lZCkge1xuICAgIGlmICh0eXBlb2YgRmluYWxpemF0aW9uUmVnaXN0cnkgPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICB0aHJvdyBFUlJPUl9GQUNUT1JZLmNyZWF0ZShcbiAgICAgICAgQXBwRXJyb3IuRklOQUxJWkFUSU9OX1JFR0lTVFJZX05PVF9TVVBQT1JURUQsXG4gICAgICAgIHt9XG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIGNvbnN0IG5hbWVTdHJpbmcgPSAnJyArIGhhc2hDb2RlKEpTT04uc3RyaW5naWZ5KG5hbWVPYmopKTtcbiAgY29uc3QgZXhpc3RpbmdBcHAgPSBfc2VydmVyQXBwcy5nZXQobmFtZVN0cmluZykgYXMgRmlyZWJhc2VTZXJ2ZXJBcHA7XG4gIGlmIChleGlzdGluZ0FwcCkge1xuICAgIChleGlzdGluZ0FwcCBhcyBGaXJlYmFzZVNlcnZlckFwcEltcGwpLmluY1JlZkNvdW50KFxuICAgICAgc2VydmVyQXBwU2V0dGluZ3MucmVsZWFzZU9uRGVyZWZcbiAgICApO1xuICAgIHJldHVybiBleGlzdGluZ0FwcDtcbiAgfVxuXG4gIGNvbnN0IGNvbnRhaW5lciA9IG5ldyBDb21wb25lbnRDb250YWluZXIobmFtZVN0cmluZyk7XG4gIGZvciAoY29uc3QgY29tcG9uZW50IG9mIF9jb21wb25lbnRzLnZhbHVlcygpKSB7XG4gICAgY29udGFpbmVyLmFkZENvbXBvbmVudChjb21wb25lbnQpO1xuICB9XG5cbiAgY29uc3QgbmV3QXBwID0gbmV3IEZpcmViYXNlU2VydmVyQXBwSW1wbChcbiAgICBmaXJlYmFzZU9wdGlvbnMsXG4gICAgc2VydmVyQXBwU2V0dGluZ3MsXG4gICAgbmFtZVN0cmluZyxcbiAgICBjb250YWluZXJcbiAgKTtcblxuICBfc2VydmVyQXBwcy5zZXQobmFtZVN0cmluZywgbmV3QXBwKTtcblxuICByZXR1cm4gbmV3QXBwO1xufVxuXG4vKipcbiAqIFJldHJpZXZlcyBhIHtAbGluayBAZmlyZWJhc2UvYXBwI0ZpcmViYXNlQXBwfSBpbnN0YW5jZS5cbiAqXG4gKiBXaGVuIGNhbGxlZCB3aXRoIG5vIGFyZ3VtZW50cywgdGhlIGRlZmF1bHQgYXBwIGlzIHJldHVybmVkLiBXaGVuIGFuIGFwcCBuYW1lXG4gKiBpcyBwcm92aWRlZCwgdGhlIGFwcCBjb3JyZXNwb25kaW5nIHRvIHRoYXQgbmFtZSBpcyByZXR1cm5lZC5cbiAqXG4gKiBBbiBleGNlcHRpb24gaXMgdGhyb3duIGlmIHRoZSBhcHAgYmVpbmcgcmV0cmlldmVkIGhhcyBub3QgeWV0IGJlZW5cbiAqIGluaXRpYWxpemVkLlxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGBqYXZhc2NyaXB0XG4gKiAvLyBSZXR1cm4gdGhlIGRlZmF1bHQgYXBwXG4gKiBjb25zdCBhcHAgPSBnZXRBcHAoKTtcbiAqIGBgYFxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGBqYXZhc2NyaXB0XG4gKiAvLyBSZXR1cm4gYSBuYW1lZCBhcHBcbiAqIGNvbnN0IG90aGVyQXBwID0gZ2V0QXBwKFwib3RoZXJBcHBcIik7XG4gKiBgYGBcbiAqXG4gKiBAcGFyYW0gbmFtZSAtIE9wdGlvbmFsIG5hbWUgb2YgdGhlIGFwcCB0byByZXR1cm4uIElmIG5vIG5hbWUgaXNcbiAqICAgcHJvdmlkZWQsIHRoZSBkZWZhdWx0IGlzIGBcIltERUZBVUxUXVwiYC5cbiAqXG4gKiBAcmV0dXJucyBUaGUgYXBwIGNvcnJlc3BvbmRpbmcgdG8gdGhlIHByb3ZpZGVkIGFwcCBuYW1lLlxuICogICBJZiBubyBhcHAgbmFtZSBpcyBwcm92aWRlZCwgdGhlIGRlZmF1bHQgYXBwIGlzIHJldHVybmVkLlxuICpcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldEFwcChuYW1lOiBzdHJpbmcgPSBERUZBVUxUX0VOVFJZX05BTUUpOiBGaXJlYmFzZUFwcCB7XG4gIGNvbnN0IGFwcCA9IF9hcHBzLmdldChuYW1lKTtcbiAgaWYgKCFhcHAgJiYgbmFtZSA9PT0gREVGQVVMVF9FTlRSWV9OQU1FICYmIGdldERlZmF1bHRBcHBDb25maWcoKSkge1xuICAgIHJldHVybiBpbml0aWFsaXplQXBwKCk7XG4gIH1cbiAgaWYgKCFhcHApIHtcbiAgICB0aHJvdyBFUlJPUl9GQUNUT1JZLmNyZWF0ZShBcHBFcnJvci5OT19BUFAsIHsgYXBwTmFtZTogbmFtZSB9KTtcbiAgfVxuXG4gIHJldHVybiBhcHA7XG59XG5cbi8qKlxuICogQSAocmVhZC1vbmx5KSBhcnJheSBvZiBhbGwgaW5pdGlhbGl6ZWQgYXBwcy5cbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldEFwcHMoKTogRmlyZWJhc2VBcHBbXSB7XG4gIHJldHVybiBBcnJheS5mcm9tKF9hcHBzLnZhbHVlcygpKTtcbn1cblxuLyoqXG4gKiBSZW5kZXJzIHRoaXMgYXBwIHVudXNhYmxlIGFuZCBmcmVlcyB0aGUgcmVzb3VyY2VzIG9mIGFsbCBhc3NvY2lhdGVkXG4gKiBzZXJ2aWNlcy5cbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgamF2YXNjcmlwdFxuICogZGVsZXRlQXBwKGFwcClcbiAqICAgLnRoZW4oZnVuY3Rpb24oKSB7XG4gKiAgICAgY29uc29sZS5sb2coXCJBcHAgZGVsZXRlZCBzdWNjZXNzZnVsbHlcIik7XG4gKiAgIH0pXG4gKiAgIC5jYXRjaChmdW5jdGlvbihlcnJvcikge1xuICogICAgIGNvbnNvbGUubG9nKFwiRXJyb3IgZGVsZXRpbmcgYXBwOlwiLCBlcnJvcik7XG4gKiAgIH0pO1xuICogYGBgXG4gKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlQXBwKGFwcDogRmlyZWJhc2VBcHApOiBQcm9taXNlPHZvaWQ+IHtcbiAgbGV0IGNsZWFudXBQcm92aWRlcnMgPSBmYWxzZTtcbiAgY29uc3QgbmFtZSA9IGFwcC5uYW1lO1xuICBpZiAoX2FwcHMuaGFzKG5hbWUpKSB7XG4gICAgY2xlYW51cFByb3ZpZGVycyA9IHRydWU7XG4gICAgX2FwcHMuZGVsZXRlKG5hbWUpO1xuICB9IGVsc2UgaWYgKF9zZXJ2ZXJBcHBzLmhhcyhuYW1lKSkge1xuICAgIGNvbnN0IGZpcmViYXNlU2VydmVyQXBwID0gYXBwIGFzIEZpcmViYXNlU2VydmVyQXBwSW1wbDtcbiAgICBpZiAoZmlyZWJhc2VTZXJ2ZXJBcHAuZGVjUmVmQ291bnQoKSA8PSAwKSB7XG4gICAgICBfc2VydmVyQXBwcy5kZWxldGUobmFtZSk7XG4gICAgICBjbGVhbnVwUHJvdmlkZXJzID0gdHJ1ZTtcbiAgICB9XG4gIH1cblxuICBpZiAoY2xlYW51cFByb3ZpZGVycykge1xuICAgIGF3YWl0IFByb21pc2UuYWxsKFxuICAgICAgKGFwcCBhcyBGaXJlYmFzZUFwcEltcGwpLmNvbnRhaW5lclxuICAgICAgICAuZ2V0UHJvdmlkZXJzKClcbiAgICAgICAgLm1hcChwcm92aWRlciA9PiBwcm92aWRlci5kZWxldGUoKSlcbiAgICApO1xuICAgIChhcHAgYXMgRmlyZWJhc2VBcHBJbXBsKS5pc0RlbGV0ZWQgPSB0cnVlO1xuICB9XG59XG5cbi8qKlxuICogUmVnaXN0ZXJzIGEgbGlicmFyeSdzIG5hbWUgYW5kIHZlcnNpb24gZm9yIHBsYXRmb3JtIGxvZ2dpbmcgcHVycG9zZXMuXG4gKiBAcGFyYW0gbGlicmFyeSAtIE5hbWUgb2YgMXAgb3IgM3AgbGlicmFyeSAoZS5nLiBmaXJlc3RvcmUsIGFuZ3VsYXJmaXJlKVxuICogQHBhcmFtIHZlcnNpb24gLSBDdXJyZW50IHZlcnNpb24gb2YgdGhhdCBsaWJyYXJ5LlxuICogQHBhcmFtIHZhcmlhbnQgLSBCdW5kbGUgdmFyaWFudCwgZS5nLiwgbm9kZSwgcm4sIGV0Yy5cbiAqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZWdpc3RlclZlcnNpb24oXG4gIGxpYnJhcnlLZXlPck5hbWU6IHN0cmluZyxcbiAgdmVyc2lvbjogc3RyaW5nLFxuICB2YXJpYW50Pzogc3RyaW5nXG4pOiB2b2lkIHtcbiAgLy8gVE9ETzogV2UgY2FuIHVzZSB0aGlzIGNoZWNrIHRvIHdoaXRlbGlzdCBzdHJpbmdzIHdoZW4vaWYgd2Ugc2V0IHVwXG4gIC8vIGEgZ29vZCB3aGl0ZWxpc3Qgc3lzdGVtLlxuICBsZXQgbGlicmFyeSA9IFBMQVRGT1JNX0xPR19TVFJJTkdbbGlicmFyeUtleU9yTmFtZV0gPz8gbGlicmFyeUtleU9yTmFtZTtcbiAgaWYgKHZhcmlhbnQpIHtcbiAgICBsaWJyYXJ5ICs9IGAtJHt2YXJpYW50fWA7XG4gIH1cbiAgY29uc3QgbGlicmFyeU1pc21hdGNoID0gbGlicmFyeS5tYXRjaCgvXFxzfFxcLy8pO1xuICBjb25zdCB2ZXJzaW9uTWlzbWF0Y2ggPSB2ZXJzaW9uLm1hdGNoKC9cXHN8XFwvLyk7XG4gIGlmIChsaWJyYXJ5TWlzbWF0Y2ggfHwgdmVyc2lvbk1pc21hdGNoKSB7XG4gICAgY29uc3Qgd2FybmluZyA9IFtcbiAgICAgIGBVbmFibGUgdG8gcmVnaXN0ZXIgbGlicmFyeSBcIiR7bGlicmFyeX1cIiB3aXRoIHZlcnNpb24gXCIke3ZlcnNpb259XCI6YFxuICAgIF07XG4gICAgaWYgKGxpYnJhcnlNaXNtYXRjaCkge1xuICAgICAgd2FybmluZy5wdXNoKFxuICAgICAgICBgbGlicmFyeSBuYW1lIFwiJHtsaWJyYXJ5fVwiIGNvbnRhaW5zIGlsbGVnYWwgY2hhcmFjdGVycyAod2hpdGVzcGFjZSBvciBcIi9cIilgXG4gICAgICApO1xuICAgIH1cbiAgICBpZiAobGlicmFyeU1pc21hdGNoICYmIHZlcnNpb25NaXNtYXRjaCkge1xuICAgICAgd2FybmluZy5wdXNoKCdhbmQnKTtcbiAgICB9XG4gICAgaWYgKHZlcnNpb25NaXNtYXRjaCkge1xuICAgICAgd2FybmluZy5wdXNoKFxuICAgICAgICBgdmVyc2lvbiBuYW1lIFwiJHt2ZXJzaW9ufVwiIGNvbnRhaW5zIGlsbGVnYWwgY2hhcmFjdGVycyAod2hpdGVzcGFjZSBvciBcIi9cIilgXG4gICAgICApO1xuICAgIH1cbiAgICBsb2dnZXIud2Fybih3YXJuaW5nLmpvaW4oJyAnKSk7XG4gICAgcmV0dXJuO1xuICB9XG4gIF9yZWdpc3RlckNvbXBvbmVudChcbiAgICBuZXcgQ29tcG9uZW50KFxuICAgICAgYCR7bGlicmFyeX0tdmVyc2lvbmAgYXMgTmFtZSxcbiAgICAgICgpID0+ICh7IGxpYnJhcnksIHZlcnNpb24gfSksXG4gICAgICBDb21wb25lbnRUeXBlLlZFUlNJT05cbiAgICApXG4gICk7XG59XG5cbi8qKlxuICogU2V0cyBsb2cgaGFuZGxlciBmb3IgYWxsIEZpcmViYXNlIFNES3MuXG4gKiBAcGFyYW0gbG9nQ2FsbGJhY2sgLSBBbiBvcHRpb25hbCBjdXN0b20gbG9nIGhhbmRsZXIgdGhhdCBleGVjdXRlcyB1c2VyIGNvZGUgd2hlbmV2ZXJcbiAqIHRoZSBGaXJlYmFzZSBTREsgbWFrZXMgYSBsb2dnaW5nIGNhbGwuXG4gKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgZnVuY3Rpb24gb25Mb2coXG4gIGxvZ0NhbGxiYWNrOiBMb2dDYWxsYmFjayB8IG51bGwsXG4gIG9wdGlvbnM/OiBMb2dPcHRpb25zXG4pOiB2b2lkIHtcbiAgaWYgKGxvZ0NhbGxiYWNrICE9PSBudWxsICYmIHR5cGVvZiBsb2dDYWxsYmFjayAhPT0gJ2Z1bmN0aW9uJykge1xuICAgIHRocm93IEVSUk9SX0ZBQ1RPUlkuY3JlYXRlKEFwcEVycm9yLklOVkFMSURfTE9HX0FSR1VNRU5UKTtcbiAgfVxuICBzZXRVc2VyTG9nSGFuZGxlcihsb2dDYWxsYmFjaywgb3B0aW9ucyk7XG59XG5cbi8qKlxuICogU2V0cyBsb2cgbGV2ZWwgZm9yIGFsbCBGaXJlYmFzZSBTREtzLlxuICpcbiAqIEFsbCBvZiB0aGUgbG9nIHR5cGVzIGFib3ZlIHRoZSBjdXJyZW50IGxvZyBsZXZlbCBhcmUgY2FwdHVyZWQgKGkuZS4gaWZcbiAqIHlvdSBzZXQgdGhlIGxvZyBsZXZlbCB0byBgaW5mb2AsIGVycm9ycyBhcmUgbG9nZ2VkLCBidXQgYGRlYnVnYCBhbmRcbiAqIGB2ZXJib3NlYCBsb2dzIGFyZSBub3QpLlxuICpcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNldExvZ0xldmVsKGxvZ0xldmVsOiBMb2dMZXZlbFN0cmluZyk6IHZvaWQge1xuICBzZXRMb2dMZXZlbEltcGwobG9nTGV2ZWwpO1xufVxuIiwiLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMjEgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgRmlyZWJhc2VFcnJvciB9IGZyb20gJ0BmaXJlYmFzZS91dGlsJztcbmltcG9ydCB7IERCU2NoZW1hLCBvcGVuREIsIElEQlBEYXRhYmFzZSB9IGZyb20gJ2lkYic7XG5pbXBvcnQgeyBBcHBFcnJvciwgRVJST1JfRkFDVE9SWSB9IGZyb20gJy4vZXJyb3JzJztcbmltcG9ydCB7IEZpcmViYXNlQXBwIH0gZnJvbSAnLi9wdWJsaWMtdHlwZXMnO1xuaW1wb3J0IHsgSGVhcnRiZWF0c0luSW5kZXhlZERCIH0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyBsb2dnZXIgfSBmcm9tICcuL2xvZ2dlcic7XG5cbmNvbnN0IERCX05BTUUgPSAnZmlyZWJhc2UtaGVhcnRiZWF0LWRhdGFiYXNlJztcbmNvbnN0IERCX1ZFUlNJT04gPSAxO1xuY29uc3QgU1RPUkVfTkFNRSA9ICdmaXJlYmFzZS1oZWFydGJlYXQtc3RvcmUnO1xuXG5pbnRlcmZhY2UgQXBwREIgZXh0ZW5kcyBEQlNjaGVtYSB7XG4gICdmaXJlYmFzZS1oZWFydGJlYXQtc3RvcmUnOiB7XG4gICAga2V5OiBzdHJpbmc7XG4gICAgdmFsdWU6IEhlYXJ0YmVhdHNJbkluZGV4ZWREQjtcbiAgfTtcbn1cblxubGV0IGRiUHJvbWlzZTogUHJvbWlzZTxJREJQRGF0YWJhc2U8QXBwREI+PiB8IG51bGwgPSBudWxsO1xuZnVuY3Rpb24gZ2V0RGJQcm9taXNlKCk6IFByb21pc2U8SURCUERhdGFiYXNlPEFwcERCPj4ge1xuICBpZiAoIWRiUHJvbWlzZSkge1xuICAgIGRiUHJvbWlzZSA9IG9wZW5EQjxBcHBEQj4oREJfTkFNRSwgREJfVkVSU0lPTiwge1xuICAgICAgdXBncmFkZTogKGRiLCBvbGRWZXJzaW9uKSA9PiB7XG4gICAgICAgIC8vIFdlIGRvbid0IHVzZSAnYnJlYWsnIGluIHRoaXMgc3dpdGNoIHN0YXRlbWVudCwgdGhlIGZhbGwtdGhyb3VnaFxuICAgICAgICAvLyBiZWhhdmlvciBpcyB3aGF0IHdlIHdhbnQsIGJlY2F1c2UgaWYgdGhlcmUgYXJlIG11bHRpcGxlIHZlcnNpb25zIGJldHdlZW5cbiAgICAgICAgLy8gdGhlIG9sZCB2ZXJzaW9uIGFuZCB0aGUgY3VycmVudCB2ZXJzaW9uLCB3ZSB3YW50IEFMTCB0aGUgbWlncmF0aW9uc1xuICAgICAgICAvLyB0aGF0IGNvcnJlc3BvbmQgdG8gdGhvc2UgdmVyc2lvbnMgdG8gcnVuLCBub3Qgb25seSB0aGUgbGFzdCBvbmUuXG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBkZWZhdWx0LWNhc2VcbiAgICAgICAgc3dpdGNoIChvbGRWZXJzaW9uKSB7XG4gICAgICAgICAgY2FzZSAwOlxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgZGIuY3JlYXRlT2JqZWN0U3RvcmUoU1RPUkVfTkFNRSk7XG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgIC8vIFNhZmFyaS9pT1MgYnJvd3NlcnMgdGhyb3cgb2NjYXNpb25hbCBleGNlcHRpb25zIG9uXG4gICAgICAgICAgICAgIC8vIGRiLmNyZWF0ZU9iamVjdFN0b3JlKCkgdGhhdCBtYXkgYmUgYSBidWcuIEF2b2lkIGJsb2NraW5nXG4gICAgICAgICAgICAgIC8vIHRoZSByZXN0IG9mIHRoZSBhcHAgZnVuY3Rpb25hbGl0eS5cbiAgICAgICAgICAgICAgY29uc29sZS53YXJuKGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSkuY2F0Y2goZSA9PiB7XG4gICAgICB0aHJvdyBFUlJPUl9GQUNUT1JZLmNyZWF0ZShBcHBFcnJvci5JREJfT1BFTiwge1xuICAgICAgICBvcmlnaW5hbEVycm9yTWVzc2FnZTogZS5tZXNzYWdlXG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gZGJQcm9taXNlO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVhZEhlYXJ0YmVhdHNGcm9tSW5kZXhlZERCKFxuICBhcHA6IEZpcmViYXNlQXBwXG4pOiBQcm9taXNlPEhlYXJ0YmVhdHNJbkluZGV4ZWREQiB8IHVuZGVmaW5lZD4ge1xuICB0cnkge1xuICAgIGNvbnN0IGRiID0gYXdhaXQgZ2V0RGJQcm9taXNlKCk7XG4gICAgY29uc3QgdHggPSBkYi50cmFuc2FjdGlvbihTVE9SRV9OQU1FKTtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0eC5vYmplY3RTdG9yZShTVE9SRV9OQU1FKS5nZXQoY29tcHV0ZUtleShhcHApKTtcbiAgICAvLyBXZSBhbHJlYWR5IGhhdmUgdGhlIHZhbHVlIGJ1dCB0eC5kb25lIGNhbiB0aHJvdyxcbiAgICAvLyBzbyB3ZSBuZWVkIHRvIGF3YWl0IGl0IGhlcmUgdG8gY2F0Y2ggZXJyb3JzXG4gICAgYXdhaXQgdHguZG9uZTtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9IGNhdGNoIChlKSB7XG4gICAgaWYgKGUgaW5zdGFuY2VvZiBGaXJlYmFzZUVycm9yKSB7XG4gICAgICBsb2dnZXIud2FybihlLm1lc3NhZ2UpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBpZGJHZXRFcnJvciA9IEVSUk9SX0ZBQ1RPUlkuY3JlYXRlKEFwcEVycm9yLklEQl9HRVQsIHtcbiAgICAgICAgb3JpZ2luYWxFcnJvck1lc3NhZ2U6IChlIGFzIEVycm9yKT8ubWVzc2FnZVxuICAgICAgfSk7XG4gICAgICBsb2dnZXIud2FybihpZGJHZXRFcnJvci5tZXNzYWdlKTtcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHdyaXRlSGVhcnRiZWF0c1RvSW5kZXhlZERCKFxuICBhcHA6IEZpcmViYXNlQXBwLFxuICBoZWFydGJlYXRPYmplY3Q6IEhlYXJ0YmVhdHNJbkluZGV4ZWREQlxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIHRyeSB7XG4gICAgY29uc3QgZGIgPSBhd2FpdCBnZXREYlByb21pc2UoKTtcbiAgICBjb25zdCB0eCA9IGRiLnRyYW5zYWN0aW9uKFNUT1JFX05BTUUsICdyZWFkd3JpdGUnKTtcbiAgICBjb25zdCBvYmplY3RTdG9yZSA9IHR4Lm9iamVjdFN0b3JlKFNUT1JFX05BTUUpO1xuICAgIGF3YWl0IG9iamVjdFN0b3JlLnB1dChoZWFydGJlYXRPYmplY3QsIGNvbXB1dGVLZXkoYXBwKSk7XG4gICAgYXdhaXQgdHguZG9uZTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIGlmIChlIGluc3RhbmNlb2YgRmlyZWJhc2VFcnJvcikge1xuICAgICAgbG9nZ2VyLndhcm4oZS5tZXNzYWdlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgaWRiR2V0RXJyb3IgPSBFUlJPUl9GQUNUT1JZLmNyZWF0ZShBcHBFcnJvci5JREJfV1JJVEUsIHtcbiAgICAgICAgb3JpZ2luYWxFcnJvck1lc3NhZ2U6IChlIGFzIEVycm9yKT8ubWVzc2FnZVxuICAgICAgfSk7XG4gICAgICBsb2dnZXIud2FybihpZGJHZXRFcnJvci5tZXNzYWdlKTtcbiAgICB9XG4gIH1cbn1cblxuZnVuY3Rpb24gY29tcHV0ZUtleShhcHA6IEZpcmViYXNlQXBwKTogc3RyaW5nIHtcbiAgcmV0dXJuIGAke2FwcC5uYW1lfSEke2FwcC5vcHRpb25zLmFwcElkfWA7XG59XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAyMSBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG5pbXBvcnQgeyBDb21wb25lbnRDb250YWluZXIgfSBmcm9tICdAZmlyZWJhc2UvY29tcG9uZW50JztcbmltcG9ydCB7XG4gIGJhc2U2NHVybEVuY29kZVdpdGhvdXRQYWRkaW5nLFxuICBpc0luZGV4ZWREQkF2YWlsYWJsZSxcbiAgdmFsaWRhdGVJbmRleGVkREJPcGVuYWJsZVxufSBmcm9tICdAZmlyZWJhc2UvdXRpbCc7XG5pbXBvcnQge1xuICByZWFkSGVhcnRiZWF0c0Zyb21JbmRleGVkREIsXG4gIHdyaXRlSGVhcnRiZWF0c1RvSW5kZXhlZERCXG59IGZyb20gJy4vaW5kZXhlZGRiJztcbmltcG9ydCB7IEZpcmViYXNlQXBwIH0gZnJvbSAnLi9wdWJsaWMtdHlwZXMnO1xuaW1wb3J0IHtcbiAgSGVhcnRiZWF0c0J5VXNlckFnZW50LFxuICBIZWFydGJlYXRTZXJ2aWNlLFxuICBIZWFydGJlYXRzSW5JbmRleGVkREIsXG4gIEhlYXJ0YmVhdFN0b3JhZ2UsXG4gIFNpbmdsZURhdGVIZWFydGJlYXRcbn0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyBsb2dnZXIgfSBmcm9tICcuL2xvZ2dlcic7XG5cbmNvbnN0IE1BWF9IRUFERVJfQllURVMgPSAxMDI0O1xuZXhwb3J0IGNvbnN0IE1BWF9OVU1fU1RPUkVEX0hFQVJUQkVBVFMgPSAzMDtcblxuZXhwb3J0IGNsYXNzIEhlYXJ0YmVhdFNlcnZpY2VJbXBsIGltcGxlbWVudHMgSGVhcnRiZWF0U2VydmljZSB7XG4gIC8qKlxuICAgKiBUaGUgcGVyc2lzdGVuY2UgbGF5ZXIgZm9yIGhlYXJ0YmVhdHNcbiAgICogTGVhdmUgcHVibGljIGZvciBlYXNpZXIgdGVzdGluZy5cbiAgICovXG4gIF9zdG9yYWdlOiBIZWFydGJlYXRTdG9yYWdlSW1wbDtcblxuICAvKipcbiAgICogSW4tbWVtb3J5IGNhY2hlIGZvciBoZWFydGJlYXRzLCB1c2VkIGJ5IGdldEhlYXJ0YmVhdHNIZWFkZXIoKSB0byBnZW5lcmF0ZVxuICAgKiB0aGUgaGVhZGVyIHN0cmluZy5cbiAgICogU3RvcmVzIG9uZSByZWNvcmQgcGVyIGRhdGUuIFRoaXMgd2lsbCBiZSBjb25zb2xpZGF0ZWQgaW50byB0aGUgc3RhbmRhcmRcbiAgICogZm9ybWF0IG9mIG9uZSByZWNvcmQgcGVyIHVzZXIgYWdlbnQgc3RyaW5nIGJlZm9yZSBiZWluZyBzZW50IGFzIGEgaGVhZGVyLlxuICAgKiBQb3B1bGF0ZWQgZnJvbSBpbmRleGVkREIgd2hlbiB0aGUgY29udHJvbGxlciBpcyBpbnN0YW50aWF0ZWQgYW5kIHNob3VsZFxuICAgKiBiZSBrZXB0IGluIHN5bmMgd2l0aCBpbmRleGVkREIuXG4gICAqIExlYXZlIHB1YmxpYyBmb3IgZWFzaWVyIHRlc3RpbmcuXG4gICAqL1xuICBfaGVhcnRiZWF0c0NhY2hlOiBIZWFydGJlYXRzSW5JbmRleGVkREIgfCBudWxsID0gbnVsbDtcblxuICAvKipcbiAgICogdGhlIGluaXRpYWxpemF0aW9uIHByb21pc2UgZm9yIHBvcHVsYXRpbmcgaGVhcnRiZWF0Q2FjaGUuXG4gICAqIElmIGdldEhlYXJ0YmVhdHNIZWFkZXIoKSBpcyBjYWxsZWQgYmVmb3JlIHRoZSBwcm9taXNlIHJlc29sdmVzXG4gICAqIChoZWFydGJlYXRzQ2FjaGUgPT0gbnVsbCksIGl0IHNob3VsZCB3YWl0IGZvciB0aGlzIHByb21pc2VcbiAgICogTGVhdmUgcHVibGljIGZvciBlYXNpZXIgdGVzdGluZy5cbiAgICovXG4gIF9oZWFydGJlYXRzQ2FjaGVQcm9taXNlOiBQcm9taXNlPEhlYXJ0YmVhdHNJbkluZGV4ZWREQj47XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcmVhZG9ubHkgY29udGFpbmVyOiBDb21wb25lbnRDb250YWluZXIpIHtcbiAgICBjb25zdCBhcHAgPSB0aGlzLmNvbnRhaW5lci5nZXRQcm92aWRlcignYXBwJykuZ2V0SW1tZWRpYXRlKCk7XG4gICAgdGhpcy5fc3RvcmFnZSA9IG5ldyBIZWFydGJlYXRTdG9yYWdlSW1wbChhcHApO1xuICAgIHRoaXMuX2hlYXJ0YmVhdHNDYWNoZVByb21pc2UgPSB0aGlzLl9zdG9yYWdlLnJlYWQoKS50aGVuKHJlc3VsdCA9PiB7XG4gICAgICB0aGlzLl9oZWFydGJlYXRzQ2FjaGUgPSByZXN1bHQ7XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH0pO1xuICB9XG5cbiAgLyoqXG4gICAqIENhbGxlZCB0byByZXBvcnQgYSBoZWFydGJlYXQuIFRoZSBmdW5jdGlvbiB3aWxsIGdlbmVyYXRlXG4gICAqIGEgSGVhcnRiZWF0c0J5VXNlckFnZW50IG9iamVjdCwgdXBkYXRlIGhlYXJ0YmVhdHNDYWNoZSwgYW5kIHBlcnNpc3QgaXRcbiAgICogdG8gSW5kZXhlZERCLlxuICAgKiBOb3RlIHRoYXQgd2Ugb25seSBzdG9yZSBvbmUgaGVhcnRiZWF0IHBlciBkYXkuIFNvIGlmIGEgaGVhcnRiZWF0IGZvciB0b2RheSBpc1xuICAgKiBhbHJlYWR5IGxvZ2dlZCwgc3Vic2VxdWVudCBjYWxscyB0byB0aGlzIGZ1bmN0aW9uIGluIHRoZSBzYW1lIGRheSB3aWxsIGJlIGlnbm9yZWQuXG4gICAqL1xuICBhc3luYyB0cmlnZ2VySGVhcnRiZWF0KCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBwbGF0Zm9ybUxvZ2dlciA9IHRoaXMuY29udGFpbmVyXG4gICAgICAgIC5nZXRQcm92aWRlcigncGxhdGZvcm0tbG9nZ2VyJylcbiAgICAgICAgLmdldEltbWVkaWF0ZSgpO1xuXG4gICAgICAvLyBUaGlzIGlzIHRoZSBcIkZpcmViYXNlIHVzZXIgYWdlbnRcIiBzdHJpbmcgZnJvbSB0aGUgcGxhdGZvcm0gbG9nZ2VyXG4gICAgICAvLyBzZXJ2aWNlLCBub3QgdGhlIGJyb3dzZXIgdXNlciBhZ2VudC5cbiAgICAgIGNvbnN0IGFnZW50ID0gcGxhdGZvcm1Mb2dnZXIuZ2V0UGxhdGZvcm1JbmZvU3RyaW5nKCk7XG4gICAgICBjb25zdCBkYXRlID0gZ2V0VVRDRGF0ZVN0cmluZygpO1xuICAgICAgaWYgKHRoaXMuX2hlYXJ0YmVhdHNDYWNoZT8uaGVhcnRiZWF0cyA9PSBudWxsKSB7XG4gICAgICAgIHRoaXMuX2hlYXJ0YmVhdHNDYWNoZSA9IGF3YWl0IHRoaXMuX2hlYXJ0YmVhdHNDYWNoZVByb21pc2U7XG4gICAgICAgIC8vIElmIHdlIGZhaWxlZCB0byBjb25zdHJ1Y3QgYSBoZWFydGJlYXRzIGNhY2hlLCB0aGVuIHJldHVybiBpbW1lZGlhdGVseS5cbiAgICAgICAgaWYgKHRoaXMuX2hlYXJ0YmVhdHNDYWNoZT8uaGVhcnRiZWF0cyA9PSBudWxsKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICAvLyBEbyBub3Qgc3RvcmUgYSBoZWFydGJlYXQgaWYgb25lIGlzIGFscmVhZHkgc3RvcmVkIGZvciB0aGlzIGRheVxuICAgICAgLy8gb3IgaWYgYSBoZWFkZXIgaGFzIGFscmVhZHkgYmVlbiBzZW50IHRvZGF5LlxuICAgICAgaWYgKFxuICAgICAgICB0aGlzLl9oZWFydGJlYXRzQ2FjaGUubGFzdFNlbnRIZWFydGJlYXREYXRlID09PSBkYXRlIHx8XG4gICAgICAgIHRoaXMuX2hlYXJ0YmVhdHNDYWNoZS5oZWFydGJlYXRzLnNvbWUoXG4gICAgICAgICAgc2luZ2xlRGF0ZUhlYXJ0YmVhdCA9PiBzaW5nbGVEYXRlSGVhcnRiZWF0LmRhdGUgPT09IGRhdGVcbiAgICAgICAgKVxuICAgICAgKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIFRoZXJlIGlzIG5vIGVudHJ5IGZvciB0aGlzIGRhdGUuIENyZWF0ZSBvbmUuXG4gICAgICAgIHRoaXMuX2hlYXJ0YmVhdHNDYWNoZS5oZWFydGJlYXRzLnB1c2goeyBkYXRlLCBhZ2VudCB9KTtcblxuICAgICAgICAvLyBJZiB0aGUgbnVtYmVyIG9mIHN0b3JlZCBoZWFydGJlYXRzIGV4Y2VlZHMgdGhlIG1heGltdW0gbnVtYmVyIG9mIHN0b3JlZCBoZWFydGJlYXRzLCByZW1vdmUgdGhlIGhlYXJ0YmVhdCB3aXRoIHRoZSBlYXJsaWVzdCBkYXRlLlxuICAgICAgICAvLyBTaW5jZSB0aGlzIGlzIGV4ZWN1dGVkIGVhY2ggdGltZSBhIGhlYXJ0YmVhdCBpcyBwdXNoZWQsIHRoZSBsaW1pdCBjYW4gb25seSBiZSBleGNlZWRlZCBieSBvbmUsIHNvIG9ubHkgb25lIG5lZWRzIHRvIGJlIHJlbW92ZWQuXG4gICAgICAgIGlmIChcbiAgICAgICAgICB0aGlzLl9oZWFydGJlYXRzQ2FjaGUuaGVhcnRiZWF0cy5sZW5ndGggPiBNQVhfTlVNX1NUT1JFRF9IRUFSVEJFQVRTXG4gICAgICAgICkge1xuICAgICAgICAgIGNvbnN0IGVhcmxpZXN0SGVhcnRiZWF0SWR4ID0gZ2V0RWFybGllc3RIZWFydGJlYXRJZHgoXG4gICAgICAgICAgICB0aGlzLl9oZWFydGJlYXRzQ2FjaGUuaGVhcnRiZWF0c1xuICAgICAgICAgICk7XG4gICAgICAgICAgdGhpcy5faGVhcnRiZWF0c0NhY2hlLmhlYXJ0YmVhdHMuc3BsaWNlKGVhcmxpZXN0SGVhcnRiZWF0SWR4LCAxKTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICByZXR1cm4gdGhpcy5fc3RvcmFnZS5vdmVyd3JpdGUodGhpcy5faGVhcnRiZWF0c0NhY2hlKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBsb2dnZXIud2FybihlKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBhIGJhc2U2NCBlbmNvZGVkIHN0cmluZyB3aGljaCBjYW4gYmUgYXR0YWNoZWQgdG8gdGhlIGhlYXJ0YmVhdC1zcGVjaWZpYyBoZWFkZXIgZGlyZWN0bHkuXG4gICAqIEl0IGFsc28gY2xlYXJzIGFsbCBoZWFydGJlYXRzIGZyb20gbWVtb3J5IGFzIHdlbGwgYXMgaW4gSW5kZXhlZERCLlxuICAgKlxuICAgKiBOT1RFOiBDb25zdW1pbmcgcHJvZHVjdCBTREtzIHNob3VsZCBub3Qgc2VuZCB0aGUgaGVhZGVyIGlmIHRoaXMgbWV0aG9kXG4gICAqIHJldHVybnMgYW4gZW1wdHkgc3RyaW5nLlxuICAgKi9cbiAgYXN5bmMgZ2V0SGVhcnRiZWF0c0hlYWRlcigpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIHRyeSB7XG4gICAgICBpZiAodGhpcy5faGVhcnRiZWF0c0NhY2hlID09PSBudWxsKSB7XG4gICAgICAgIGF3YWl0IHRoaXMuX2hlYXJ0YmVhdHNDYWNoZVByb21pc2U7XG4gICAgICB9XG4gICAgICAvLyBJZiBpdCdzIHN0aWxsIG51bGwgb3IgdGhlIGFycmF5IGlzIGVtcHR5LCB0aGVyZSBpcyBubyBkYXRhIHRvIHNlbmQuXG4gICAgICBpZiAoXG4gICAgICAgIHRoaXMuX2hlYXJ0YmVhdHNDYWNoZT8uaGVhcnRiZWF0cyA9PSBudWxsIHx8XG4gICAgICAgIHRoaXMuX2hlYXJ0YmVhdHNDYWNoZS5oZWFydGJlYXRzLmxlbmd0aCA9PT0gMFxuICAgICAgKSB7XG4gICAgICAgIHJldHVybiAnJztcbiAgICAgIH1cbiAgICAgIGNvbnN0IGRhdGUgPSBnZXRVVENEYXRlU3RyaW5nKCk7XG4gICAgICAvLyBFeHRyYWN0IGFzIG1hbnkgaGVhcnRiZWF0cyBmcm9tIHRoZSBjYWNoZSBhcyB3aWxsIGZpdCB1bmRlciB0aGUgc2l6ZSBsaW1pdC5cbiAgICAgIGNvbnN0IHsgaGVhcnRiZWF0c1RvU2VuZCwgdW5zZW50RW50cmllcyB9ID0gZXh0cmFjdEhlYXJ0YmVhdHNGb3JIZWFkZXIoXG4gICAgICAgIHRoaXMuX2hlYXJ0YmVhdHNDYWNoZS5oZWFydGJlYXRzXG4gICAgICApO1xuICAgICAgY29uc3QgaGVhZGVyU3RyaW5nID0gYmFzZTY0dXJsRW5jb2RlV2l0aG91dFBhZGRpbmcoXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHsgdmVyc2lvbjogMiwgaGVhcnRiZWF0czogaGVhcnRiZWF0c1RvU2VuZCB9KVxuICAgICAgKTtcbiAgICAgIC8vIFN0b3JlIGxhc3Qgc2VudCBkYXRlIHRvIHByZXZlbnQgYW5vdGhlciBiZWluZyBsb2dnZWQvc2VudCBmb3IgdGhlIHNhbWUgZGF5LlxuICAgICAgdGhpcy5faGVhcnRiZWF0c0NhY2hlLmxhc3RTZW50SGVhcnRiZWF0RGF0ZSA9IGRhdGU7XG4gICAgICBpZiAodW5zZW50RW50cmllcy5sZW5ndGggPiAwKSB7XG4gICAgICAgIC8vIFN0b3JlIGFueSB1bnNlbnQgZW50cmllcyBpZiB0aGV5IGV4aXN0LlxuICAgICAgICB0aGlzLl9oZWFydGJlYXRzQ2FjaGUuaGVhcnRiZWF0cyA9IHVuc2VudEVudHJpZXM7XG4gICAgICAgIC8vIFRoaXMgc2VlbXMgbW9yZSBsaWtlbHkgdGhhbiBlbXB0eWluZyB0aGUgYXJyYXkgKGJlbG93KSB0byBsZWFkIHRvIHNvbWUgb2RkIHN0YXRlXG4gICAgICAgIC8vIHNpbmNlIHRoZSBjYWNoZSBpc24ndCBlbXB0eSBhbmQgdGhpcyB3aWxsIGJlIGNhbGxlZCBhZ2FpbiBvbiB0aGUgbmV4dCByZXF1ZXN0LFxuICAgICAgICAvLyBhbmQgaXMgcHJvYmFibHkgc2FmZXN0IGlmIHdlIGF3YWl0IGl0LlxuICAgICAgICBhd2FpdCB0aGlzLl9zdG9yYWdlLm92ZXJ3cml0ZSh0aGlzLl9oZWFydGJlYXRzQ2FjaGUpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5faGVhcnRiZWF0c0NhY2hlLmhlYXJ0YmVhdHMgPSBbXTtcbiAgICAgICAgLy8gRG8gbm90IHdhaXQgZm9yIHRoaXMsIHRvIHJlZHVjZSBsYXRlbmN5LlxuICAgICAgICB2b2lkIHRoaXMuX3N0b3JhZ2Uub3ZlcndyaXRlKHRoaXMuX2hlYXJ0YmVhdHNDYWNoZSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gaGVhZGVyU3RyaW5nO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGxvZ2dlci53YXJuKGUpO1xuICAgICAgcmV0dXJuICcnO1xuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiBnZXRVVENEYXRlU3RyaW5nKCk6IHN0cmluZyB7XG4gIGNvbnN0IHRvZGF5ID0gbmV3IERhdGUoKTtcbiAgLy8gUmV0dXJucyBkYXRlIGZvcm1hdCAnWVlZWS1NTS1ERCdcbiAgcmV0dXJuIHRvZGF5LnRvSVNPU3RyaW5nKCkuc3Vic3RyaW5nKDAsIDEwKTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGV4dHJhY3RIZWFydGJlYXRzRm9ySGVhZGVyKFxuICBoZWFydGJlYXRzQ2FjaGU6IFNpbmdsZURhdGVIZWFydGJlYXRbXSxcbiAgbWF4U2l6ZSA9IE1BWF9IRUFERVJfQllURVNcbik6IHtcbiAgaGVhcnRiZWF0c1RvU2VuZDogSGVhcnRiZWF0c0J5VXNlckFnZW50W107XG4gIHVuc2VudEVudHJpZXM6IFNpbmdsZURhdGVIZWFydGJlYXRbXTtcbn0ge1xuICAvLyBIZWFydGJlYXRzIGdyb3VwZWQgYnkgdXNlciBhZ2VudCBpbiB0aGUgc3RhbmRhcmQgZm9ybWF0IHRvIGJlIHNlbnQgaW5cbiAgLy8gdGhlIGhlYWRlci5cbiAgY29uc3QgaGVhcnRiZWF0c1RvU2VuZDogSGVhcnRiZWF0c0J5VXNlckFnZW50W10gPSBbXTtcbiAgLy8gU2luZ2xlIGRhdGUgZm9ybWF0IGhlYXJ0YmVhdHMgdGhhdCBhcmUgbm90IHNlbnQuXG4gIGxldCB1bnNlbnRFbnRyaWVzID0gaGVhcnRiZWF0c0NhY2hlLnNsaWNlKCk7XG4gIGZvciAoY29uc3Qgc2luZ2xlRGF0ZUhlYXJ0YmVhdCBvZiBoZWFydGJlYXRzQ2FjaGUpIHtcbiAgICAvLyBMb29rIGZvciBhbiBleGlzdGluZyBlbnRyeSB3aXRoIHRoZSBzYW1lIHVzZXIgYWdlbnQuXG4gICAgY29uc3QgaGVhcnRiZWF0RW50cnkgPSBoZWFydGJlYXRzVG9TZW5kLmZpbmQoXG4gICAgICBoYiA9PiBoYi5hZ2VudCA9PT0gc2luZ2xlRGF0ZUhlYXJ0YmVhdC5hZ2VudFxuICAgICk7XG4gICAgaWYgKCFoZWFydGJlYXRFbnRyeSkge1xuICAgICAgLy8gSWYgbm8gZW50cnkgZm9yIHRoaXMgdXNlciBhZ2VudCBleGlzdHMsIGNyZWF0ZSBvbmUuXG4gICAgICBoZWFydGJlYXRzVG9TZW5kLnB1c2goe1xuICAgICAgICBhZ2VudDogc2luZ2xlRGF0ZUhlYXJ0YmVhdC5hZ2VudCxcbiAgICAgICAgZGF0ZXM6IFtzaW5nbGVEYXRlSGVhcnRiZWF0LmRhdGVdXG4gICAgICB9KTtcbiAgICAgIGlmIChjb3VudEJ5dGVzKGhlYXJ0YmVhdHNUb1NlbmQpID4gbWF4U2l6ZSkge1xuICAgICAgICAvLyBJZiB0aGUgaGVhZGVyIHdvdWxkIGV4Y2VlZCBtYXggc2l6ZSwgcmVtb3ZlIHRoZSBhZGRlZCBoZWFydGJlYXRcbiAgICAgICAgLy8gZW50cnkgYW5kIHN0b3AgYWRkaW5nIHRvIHRoZSBoZWFkZXIuXG4gICAgICAgIGhlYXJ0YmVhdHNUb1NlbmQucG9wKCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBoZWFydGJlYXRFbnRyeS5kYXRlcy5wdXNoKHNpbmdsZURhdGVIZWFydGJlYXQuZGF0ZSk7XG4gICAgICAvLyBJZiB0aGUgaGVhZGVyIHdvdWxkIGV4Y2VlZCBtYXggc2l6ZSwgcmVtb3ZlIHRoZSBhZGRlZCBkYXRlXG4gICAgICAvLyBhbmQgc3RvcCBhZGRpbmcgdG8gdGhlIGhlYWRlci5cbiAgICAgIGlmIChjb3VudEJ5dGVzKGhlYXJ0YmVhdHNUb1NlbmQpID4gbWF4U2l6ZSkge1xuICAgICAgICBoZWFydGJlYXRFbnRyeS5kYXRlcy5wb3AoKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIC8vIFBvcCB1bnNlbnQgZW50cnkgZnJvbSBxdWV1ZS4gKFNraXBwZWQgaWYgYWRkaW5nIHRoZSBlbnRyeSBleGNlZWRlZFxuICAgIC8vIHF1b3RhIGFuZCB0aGUgbG9vcCBicmVha3MgZWFybHkuKVxuICAgIHVuc2VudEVudHJpZXMgPSB1bnNlbnRFbnRyaWVzLnNsaWNlKDEpO1xuICB9XG4gIHJldHVybiB7XG4gICAgaGVhcnRiZWF0c1RvU2VuZCxcbiAgICB1bnNlbnRFbnRyaWVzXG4gIH07XG59XG5cbmV4cG9ydCBjbGFzcyBIZWFydGJlYXRTdG9yYWdlSW1wbCBpbXBsZW1lbnRzIEhlYXJ0YmVhdFN0b3JhZ2Uge1xuICBwcml2YXRlIF9jYW5Vc2VJbmRleGVkREJQcm9taXNlOiBQcm9taXNlPGJvb2xlYW4+O1xuICBjb25zdHJ1Y3RvcihwdWJsaWMgYXBwOiBGaXJlYmFzZUFwcCkge1xuICAgIHRoaXMuX2NhblVzZUluZGV4ZWREQlByb21pc2UgPSB0aGlzLnJ1bkluZGV4ZWREQkVudmlyb25tZW50Q2hlY2soKTtcbiAgfVxuICBhc3luYyBydW5JbmRleGVkREJFbnZpcm9ubWVudENoZWNrKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIGlmICghaXNJbmRleGVkREJBdmFpbGFibGUoKSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gdmFsaWRhdGVJbmRleGVkREJPcGVuYWJsZSgpXG4gICAgICAgIC50aGVuKCgpID0+IHRydWUpXG4gICAgICAgIC5jYXRjaCgoKSA9PiBmYWxzZSk7XG4gICAgfVxuICB9XG4gIC8qKlxuICAgKiBSZWFkIGFsbCBoZWFydGJlYXRzLlxuICAgKi9cbiAgYXN5bmMgcmVhZCgpOiBQcm9taXNlPEhlYXJ0YmVhdHNJbkluZGV4ZWREQj4ge1xuICAgIGNvbnN0IGNhblVzZUluZGV4ZWREQiA9IGF3YWl0IHRoaXMuX2NhblVzZUluZGV4ZWREQlByb21pc2U7XG4gICAgaWYgKCFjYW5Vc2VJbmRleGVkREIpIHtcbiAgICAgIHJldHVybiB7IGhlYXJ0YmVhdHM6IFtdIH07XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGlkYkhlYXJ0YmVhdE9iamVjdCA9IGF3YWl0IHJlYWRIZWFydGJlYXRzRnJvbUluZGV4ZWREQih0aGlzLmFwcCk7XG4gICAgICBpZiAoaWRiSGVhcnRiZWF0T2JqZWN0Py5oZWFydGJlYXRzKSB7XG4gICAgICAgIHJldHVybiBpZGJIZWFydGJlYXRPYmplY3Q7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4geyBoZWFydGJlYXRzOiBbXSB9O1xuICAgICAgfVxuICAgIH1cbiAgfVxuICAvLyBvdmVyd3JpdGUgdGhlIHN0b3JhZ2Ugd2l0aCB0aGUgcHJvdmlkZWQgaGVhcnRiZWF0c1xuICBhc3luYyBvdmVyd3JpdGUoaGVhcnRiZWF0c09iamVjdDogSGVhcnRiZWF0c0luSW5kZXhlZERCKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgY2FuVXNlSW5kZXhlZERCID0gYXdhaXQgdGhpcy5fY2FuVXNlSW5kZXhlZERCUHJvbWlzZTtcbiAgICBpZiAoIWNhblVzZUluZGV4ZWREQikge1xuICAgICAgcmV0dXJuO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBleGlzdGluZ0hlYXJ0YmVhdHNPYmplY3QgPSBhd2FpdCB0aGlzLnJlYWQoKTtcbiAgICAgIHJldHVybiB3cml0ZUhlYXJ0YmVhdHNUb0luZGV4ZWREQih0aGlzLmFwcCwge1xuICAgICAgICBsYXN0U2VudEhlYXJ0YmVhdERhdGU6XG4gICAgICAgICAgaGVhcnRiZWF0c09iamVjdC5sYXN0U2VudEhlYXJ0YmVhdERhdGUgPz9cbiAgICAgICAgICBleGlzdGluZ0hlYXJ0YmVhdHNPYmplY3QubGFzdFNlbnRIZWFydGJlYXREYXRlLFxuICAgICAgICBoZWFydGJlYXRzOiBoZWFydGJlYXRzT2JqZWN0LmhlYXJ0YmVhdHNcbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICAvLyBhZGQgaGVhcnRiZWF0c1xuICBhc3luYyBhZGQoaGVhcnRiZWF0c09iamVjdDogSGVhcnRiZWF0c0luSW5kZXhlZERCKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgY2FuVXNlSW5kZXhlZERCID0gYXdhaXQgdGhpcy5fY2FuVXNlSW5kZXhlZERCUHJvbWlzZTtcbiAgICBpZiAoIWNhblVzZUluZGV4ZWREQikge1xuICAgICAgcmV0dXJuO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBleGlzdGluZ0hlYXJ0YmVhdHNPYmplY3QgPSBhd2FpdCB0aGlzLnJlYWQoKTtcbiAgICAgIHJldHVybiB3cml0ZUhlYXJ0YmVhdHNUb0luZGV4ZWREQih0aGlzLmFwcCwge1xuICAgICAgICBsYXN0U2VudEhlYXJ0YmVhdERhdGU6XG4gICAgICAgICAgaGVhcnRiZWF0c09iamVjdC5sYXN0U2VudEhlYXJ0YmVhdERhdGUgPz9cbiAgICAgICAgICBleGlzdGluZ0hlYXJ0YmVhdHNPYmplY3QubGFzdFNlbnRIZWFydGJlYXREYXRlLFxuICAgICAgICBoZWFydGJlYXRzOiBbXG4gICAgICAgICAgLi4uZXhpc3RpbmdIZWFydGJlYXRzT2JqZWN0LmhlYXJ0YmVhdHMsXG4gICAgICAgICAgLi4uaGVhcnRiZWF0c09iamVjdC5oZWFydGJlYXRzXG4gICAgICAgIF1cbiAgICAgIH0pO1xuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqIENhbGN1bGF0ZSBieXRlcyBvZiBhIEhlYXJ0YmVhdHNCeVVzZXJBZ2VudCBhcnJheSBhZnRlciBiZWluZyB3cmFwcGVkXG4gKiBpbiBhIHBsYXRmb3JtIGxvZ2dpbmcgaGVhZGVyIEpTT04gb2JqZWN0LCBzdHJpbmdpZmllZCwgYW5kIGNvbnZlcnRlZFxuICogdG8gYmFzZSA2NC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvdW50Qnl0ZXMoaGVhcnRiZWF0c0NhY2hlOiBIZWFydGJlYXRzQnlVc2VyQWdlbnRbXSk6IG51bWJlciB7XG4gIC8vIGJhc2U2NCBoYXMgYSByZXN0cmljdGVkIHNldCBvZiBjaGFyYWN0ZXJzLCBhbGwgb2Ygd2hpY2ggc2hvdWxkIGJlIDEgYnl0ZS5cbiAgcmV0dXJuIGJhc2U2NHVybEVuY29kZVdpdGhvdXRQYWRkaW5nKFxuICAgIC8vIGhlYXJ0YmVhdHNDYWNoZSB3cmFwcGVyIHByb3BlcnRpZXNcbiAgICBKU09OLnN0cmluZ2lmeSh7IHZlcnNpb246IDIsIGhlYXJ0YmVhdHM6IGhlYXJ0YmVhdHNDYWNoZSB9KVxuICApLmxlbmd0aDtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBpbmRleCBvZiB0aGUgaGVhcnRiZWF0IHdpdGggdGhlIGVhcmxpZXN0IGRhdGUuXG4gKiBJZiB0aGUgaGVhcnRiZWF0cyBhcnJheSBpcyBlbXB0eSwgLTEgaXMgcmV0dXJuZWQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRFYXJsaWVzdEhlYXJ0YmVhdElkeChcbiAgaGVhcnRiZWF0czogU2luZ2xlRGF0ZUhlYXJ0YmVhdFtdXG4pOiBudW1iZXIge1xuICBpZiAoaGVhcnRiZWF0cy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gLTE7XG4gIH1cblxuICBsZXQgZWFybGllc3RIZWFydGJlYXRJZHggPSAwO1xuICBsZXQgZWFybGllc3RIZWFydGJlYXREYXRlID0gaGVhcnRiZWF0c1swXS5kYXRlO1xuXG4gIGZvciAobGV0IGkgPSAxOyBpIDwgaGVhcnRiZWF0cy5sZW5ndGg7IGkrKykge1xuICAgIGlmIChoZWFydGJlYXRzW2ldLmRhdGUgPCBlYXJsaWVzdEhlYXJ0YmVhdERhdGUpIHtcbiAgICAgIGVhcmxpZXN0SGVhcnRiZWF0RGF0ZSA9IGhlYXJ0YmVhdHNbaV0uZGF0ZTtcbiAgICAgIGVhcmxpZXN0SGVhcnRiZWF0SWR4ID0gaTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gZWFybGllc3RIZWFydGJlYXRJZHg7XG59XG4iLCIvKipcbiAqIEBsaWNlbnNlXG4gKiBDb3B5cmlnaHQgMjAxOSBHb29nbGUgTExDXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqICAgaHR0cDovL3d3dy5hcGFjaGUub3JnL2xpY2Vuc2VzL0xJQ0VOU0UtMi4wXG4gKlxuICogVW5sZXNzIHJlcXVpcmVkIGJ5IGFwcGxpY2FibGUgbGF3IG9yIGFncmVlZCB0byBpbiB3cml0aW5nLCBzb2Z0d2FyZVxuICogZGlzdHJpYnV0ZWQgdW5kZXIgdGhlIExpY2Vuc2UgaXMgZGlzdHJpYnV0ZWQgb24gYW4gXCJBUyBJU1wiIEJBU0lTLFxuICogV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlciBleHByZXNzIG9yIGltcGxpZWQuXG4gKiBTZWUgdGhlIExpY2Vuc2UgZm9yIHRoZSBzcGVjaWZpYyBsYW5ndWFnZSBnb3Zlcm5pbmcgcGVybWlzc2lvbnMgYW5kXG4gKiBsaW1pdGF0aW9ucyB1bmRlciB0aGUgTGljZW5zZS5cbiAqL1xuXG5pbXBvcnQgeyBDb21wb25lbnQsIENvbXBvbmVudFR5cGUgfSBmcm9tICdAZmlyZWJhc2UvY29tcG9uZW50JztcbmltcG9ydCB7IFBsYXRmb3JtTG9nZ2VyU2VydmljZUltcGwgfSBmcm9tICcuL3BsYXRmb3JtTG9nZ2VyU2VydmljZSc7XG5pbXBvcnQgeyBuYW1lLCB2ZXJzaW9uIH0gZnJvbSAnLi4vcGFja2FnZS5qc29uJztcbmltcG9ydCB7IF9yZWdpc3RlckNvbXBvbmVudCB9IGZyb20gJy4vaW50ZXJuYWwnO1xuaW1wb3J0IHsgcmVnaXN0ZXJWZXJzaW9uIH0gZnJvbSAnLi9hcGknO1xuaW1wb3J0IHsgSGVhcnRiZWF0U2VydmljZUltcGwgfSBmcm9tICcuL2hlYXJ0YmVhdFNlcnZpY2UnO1xuXG5leHBvcnQgZnVuY3Rpb24gcmVnaXN0ZXJDb3JlQ29tcG9uZW50cyh2YXJpYW50Pzogc3RyaW5nKTogdm9pZCB7XG4gIF9yZWdpc3RlckNvbXBvbmVudChcbiAgICBuZXcgQ29tcG9uZW50KFxuICAgICAgJ3BsYXRmb3JtLWxvZ2dlcicsXG4gICAgICBjb250YWluZXIgPT4gbmV3IFBsYXRmb3JtTG9nZ2VyU2VydmljZUltcGwoY29udGFpbmVyKSxcbiAgICAgIENvbXBvbmVudFR5cGUuUFJJVkFURVxuICAgIClcbiAgKTtcbiAgX3JlZ2lzdGVyQ29tcG9uZW50KFxuICAgIG5ldyBDb21wb25lbnQoXG4gICAgICAnaGVhcnRiZWF0JyxcbiAgICAgIGNvbnRhaW5lciA9PiBuZXcgSGVhcnRiZWF0U2VydmljZUltcGwoY29udGFpbmVyKSxcbiAgICAgIENvbXBvbmVudFR5cGUuUFJJVkFURVxuICAgIClcbiAgKTtcblxuICAvLyBSZWdpc3RlciBgYXBwYCBwYWNrYWdlLlxuICByZWdpc3RlclZlcnNpb24obmFtZSwgdmVyc2lvbiwgdmFyaWFudCk7XG4gIC8vIEJVSUxEX1RBUkdFVCB3aWxsIGJlIHJlcGxhY2VkIGJ5IHZhbHVlcyBsaWtlIGVzbSwgY2pzLCBldGMgZHVyaW5nIHRoZSBjb21waWxhdGlvblxuICByZWdpc3RlclZlcnNpb24obmFtZSwgdmVyc2lvbiwgJ19fQlVJTERfVEFSR0VUX18nKTtcbiAgLy8gUmVnaXN0ZXIgcGxhdGZvcm0gU0RLIGlkZW50aWZpZXIgKG5vIHZlcnNpb24pLlxuICByZWdpc3RlclZlcnNpb24oJ2ZpcmUtanMnLCAnJyk7XG59XG4iLCIvKipcbiAqIEZpcmViYXNlIEFwcFxuICpcbiAqIEByZW1hcmtzIFRoaXMgcGFja2FnZSBjb29yZGluYXRlcyB0aGUgY29tbXVuaWNhdGlvbiBiZXR3ZWVuIHRoZSBkaWZmZXJlbnQgRmlyZWJhc2UgY29tcG9uZW50c1xuICogQHBhY2thZ2VEb2N1bWVudGF0aW9uXG4gKi9cblxuLyoqXG4gKiBAbGljZW5zZVxuICogQ29weXJpZ2h0IDIwMTkgR29vZ2xlIExMQ1xuICpcbiAqIExpY2Vuc2VkIHVuZGVyIHRoZSBBcGFjaGUgTGljZW5zZSwgVmVyc2lvbiAyLjAgKHRoZSBcIkxpY2Vuc2VcIik7XG4gKiB5b3UgbWF5IG5vdCB1c2UgdGhpcyBmaWxlIGV4Y2VwdCBpbiBjb21wbGlhbmNlIHdpdGggdGhlIExpY2Vuc2UuXG4gKiBZb3UgbWF5IG9idGFpbiBhIGNvcHkgb2YgdGhlIExpY2Vuc2UgYXRcbiAqXG4gKiAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqIFVubGVzcyByZXF1aXJlZCBieSBhcHBsaWNhYmxlIGxhdyBvciBhZ3JlZWQgdG8gaW4gd3JpdGluZywgc29mdHdhcmVcbiAqIGRpc3RyaWJ1dGVkIHVuZGVyIHRoZSBMaWNlbnNlIGlzIGRpc3RyaWJ1dGVkIG9uIGFuIFwiQVMgSVNcIiBCQVNJUyxcbiAqIFdJVEhPVVQgV0FSUkFOVElFUyBPUiBDT05ESVRJT05TIE9GIEFOWSBLSU5ELCBlaXRoZXIgZXhwcmVzcyBvciBpbXBsaWVkLlxuICogU2VlIHRoZSBMaWNlbnNlIGZvciB0aGUgc3BlY2lmaWMgbGFuZ3VhZ2UgZ292ZXJuaW5nIHBlcm1pc3Npb25zIGFuZFxuICogbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgcmVnaXN0ZXJDb3JlQ29tcG9uZW50cyB9IGZyb20gJy4vcmVnaXN0ZXJDb3JlQ29tcG9uZW50cyc7XG5cbmV4cG9ydCAqIGZyb20gJy4vYXBpJztcbmV4cG9ydCAqIGZyb20gJy4vaW50ZXJuYWwnO1xuZXhwb3J0ICogZnJvbSAnLi9wdWJsaWMtdHlwZXMnO1xuXG5yZWdpc3RlckNvcmVDb21wb25lbnRzKCdfX1JVTlRJTUVfRU5WX18nKTtcbiJdLCJuYW1lcyI6WyJhcHBOYW1lIiwiYXBwQ29tcGF0TmFtZSIsImFuYWx5dGljc05hbWUiLCJhbmFseXRpY3NDb21wYXROYW1lIiwiYXBwQ2hlY2tOYW1lIiwiYXBwQ2hlY2tDb21wYXROYW1lIiwiYXV0aE5hbWUiLCJhdXRoQ29tcGF0TmFtZSIsImRhdGFiYXNlTmFtZSIsImRhdGFjb25uZWN0TmFtZSIsImRhdGFiYXNlQ29tcGF0TmFtZSIsImZ1bmN0aW9uc05hbWUiLCJmdW5jdGlvbnNDb21wYXROYW1lIiwiaW5zdGFsbGF0aW9uc05hbWUiLCJpbnN0YWxsYXRpb25zQ29tcGF0TmFtZSIsIm1lc3NhZ2luZ05hbWUiLCJtZXNzYWdpbmdDb21wYXROYW1lIiwicGVyZm9ybWFuY2VOYW1lIiwicGVyZm9ybWFuY2VDb21wYXROYW1lIiwicmVtb3RlQ29uZmlnTmFtZSIsInJlbW90ZUNvbmZpZ0NvbXBhdE5hbWUiLCJzdG9yYWdlTmFtZSIsInN0b3JhZ2VDb21wYXROYW1lIiwiZmlyZXN0b3JlTmFtZSIsImZpcmVzdG9yZUNvbXBhdE5hbWUiLCJhaU5hbWUiLCJwYWNrYWdlTmFtZSIsInZlcnNpb24iLCJzZXRMb2dMZXZlbEltcGwiLCJuYW1lIl0sIm1hcHBpbmdzIjoiOzs7Ozs7QUFBQTs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7TUFVVSx5QkFBeUIsQ0FBQTtBQUNwQyxJQUFBLFdBQUEsQ0FBNkIsU0FBNkIsRUFBQTtRQUE3QixJQUFBLENBQUEsU0FBUyxHQUFULFNBQVM7SUFBdUI7OztJQUc3RCxxQkFBcUIsR0FBQTtRQUNuQixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRTs7O0FBRy9DLFFBQUEsT0FBTzthQUNKLEdBQUcsQ0FBQyxRQUFRLElBQUc7QUFDZCxZQUFBLElBQUksd0JBQXdCLENBQUMsUUFBUSxDQUFDLEVBQUU7QUFDdEMsZ0JBQUEsTUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLFlBQVksRUFBb0I7Z0JBQ3pELE9BQU8sQ0FBQSxFQUFHLE9BQU8sQ0FBQyxPQUFPLElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQSxDQUFFO1lBQ2hEO2lCQUFPO0FBQ0wsZ0JBQUEsT0FBTyxJQUFJO1lBQ2I7QUFDRixRQUFBLENBQUM7QUFDQSxhQUFBLE1BQU0sQ0FBQyxTQUFTLElBQUksU0FBUzthQUM3QixJQUFJLENBQUMsR0FBRyxDQUFDO0lBQ2Q7QUFDRDtBQUNEOzs7Ozs7O0FBT0c7QUFDSCxTQUFTLHdCQUF3QixDQUFDLFFBQXdCLEVBQUE7QUFDeEQsSUFBQSxNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsWUFBWSxFQUFFO0FBQ3pDLElBQUEsT0FBTyxTQUFTLEVBQUUsSUFBSSxLQUFBLFNBQUE7QUFDeEI7Ozs7O0FDekRBOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztBQUlJLE1BQU0sTUFBTSxHQUFHLElBQUksTUFBTSxDQUFDLGVBQWUsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25CakQ7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBOEJIOzs7O0FBSUc7QUFDSSxNQUFNLGtCQUFrQixHQUFHO0FBRTNCLE1BQU0sbUJBQW1CLEdBQUc7SUFDakMsQ0FBQ0EsTUFBTyxHQUFHLFdBQVc7SUFDdEIsQ0FBQ0MsTUFBYSxHQUFHLGtCQUFrQjtJQUNuQyxDQUFDQyxNQUFhLEdBQUcsZ0JBQWdCO0lBQ2pDLENBQUNDLE1BQW1CLEdBQUcsdUJBQXVCO0lBQzlDLENBQUNDLE1BQVksR0FBRyxnQkFBZ0I7SUFDaEMsQ0FBQ0MsTUFBa0IsR0FBRyx1QkFBdUI7SUFDN0MsQ0FBQ0MsTUFBUSxHQUFHLFdBQVc7SUFDdkIsQ0FBQ0MsTUFBYyxHQUFHLGtCQUFrQjtJQUNwQyxDQUFDQyxNQUFZLEdBQUcsV0FBVztJQUMzQixDQUFDQyxNQUFlLEdBQUcsbUJBQW1CO0lBQ3RDLENBQUNDLE1BQWtCLEdBQUcsa0JBQWtCO0lBQ3hDLENBQUNDLE1BQWEsR0FBRyxTQUFTO0lBQzFCLENBQUNDLE1BQW1CLEdBQUcsZ0JBQWdCO0lBQ3ZDLENBQUNDLE1BQWlCLEdBQUcsVUFBVTtJQUMvQixDQUFDQyxNQUF1QixHQUFHLGlCQUFpQjtJQUM1QyxDQUFDQyxNQUFhLEdBQUcsVUFBVTtJQUMzQixDQUFDQyxNQUFtQixHQUFHLGlCQUFpQjtJQUN4QyxDQUFDQyxNQUFlLEdBQUcsV0FBVztJQUM5QixDQUFDQyxNQUFxQixHQUFHLGtCQUFrQjtJQUMzQyxDQUFDQyxNQUFnQixHQUFHLFNBQVM7SUFDN0IsQ0FBQ0MsTUFBc0IsR0FBRyxnQkFBZ0I7SUFDMUMsQ0FBQ0MsTUFBVyxHQUFHLFVBQVU7SUFDekIsQ0FBQ0MsTUFBaUIsR0FBRyxpQkFBaUI7SUFDdEMsQ0FBQ0MsTUFBYSxHQUFHLFVBQVU7SUFDM0IsQ0FBQ0MsTUFBbUIsR0FBRyxpQkFBaUI7SUFDeEMsQ0FBQ0MsTUFBTSxHQUFHLGFBQWE7SUFDdkIsU0FBUyxFQUFFLFNBQVM7SUFDcEIsQ0FBQ0MsSUFBVyxHQUFHO0NBQ1A7O0FDakZWOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztBQWVIOztBQUVHO0FBQ0ksTUFBTSxLQUFLLEdBQUcsSUFBSSxHQUFHO0FBRTVCOztBQUVHO0FBQ0ksTUFBTSxXQUFXLEdBQUcsSUFBSSxHQUFHO0FBRWxDOzs7O0FBSUc7QUFDSDtBQUNPLE1BQU0sV0FBVyxHQUFHLElBQUksR0FBRztBQUVsQzs7OztBQUlHO0FBQ0csU0FBVSxhQUFhLENBQzNCLEdBQWdCLEVBQ2hCLFNBQXVCLEVBQUE7QUFFdkIsSUFBQSxJQUFJO0FBQ0QsUUFBQSxHQUF1QixDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDO0lBQzVEO0lBQUUsT0FBTyxDQUFDLEVBQUU7QUFDVixRQUFBLE1BQU0sQ0FBQyxLQUFLLENBQ1YsQ0FBQSxVQUFBLEVBQWEsU0FBUyxDQUFDLElBQUksQ0FBQSxxQ0FBQSxFQUF3QyxHQUFHLENBQUMsSUFBSSxDQUFBLENBQUUsRUFDN0UsQ0FBQyxDQUNGO0lBQ0g7QUFDRjtBQUVBOzs7QUFHRztBQUNHLFNBQVUsd0JBQXdCLENBQ3RDLEdBQWdCLEVBQ2hCLFNBQW9CLEVBQUE7QUFFbkIsSUFBQSxHQUF1QixDQUFDLFNBQVMsQ0FBQyx1QkFBdUIsQ0FBQyxTQUFTLENBQUM7QUFDdkU7QUFFQTs7Ozs7O0FBTUc7QUFDRyxTQUFVLGtCQUFrQixDQUNoQyxTQUF1QixFQUFBO0FBRXZCLElBQUEsTUFBTSxhQUFhLEdBQUcsU0FBUyxDQUFDLElBQUk7QUFDcEMsSUFBQSxJQUFJLFdBQVcsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLEVBQUU7QUFDbEMsUUFBQSxNQUFNLENBQUMsS0FBSyxDQUNWLHNEQUFzRCxhQUFhLENBQUEsQ0FBQSxDQUFHLENBQ3ZFO0FBRUQsUUFBQSxPQUFPLEtBQUs7SUFDZDtBQUVBLElBQUEsV0FBVyxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsU0FBUyxDQUFDOztJQUd6QyxLQUFLLE1BQU0sR0FBRyxJQUFJLEtBQUssQ0FBQyxNQUFNLEVBQUUsRUFBRTtBQUNoQyxRQUFBLGFBQWEsQ0FBQyxHQUFzQixFQUFFLFNBQVMsQ0FBQztJQUNsRDtJQUVBLEtBQUssTUFBTSxTQUFTLElBQUksV0FBVyxDQUFDLE1BQU0sRUFBRSxFQUFFO0FBQzVDLFFBQUEsYUFBYSxDQUFDLFNBQWtDLEVBQUUsU0FBUyxDQUFDO0lBQzlEO0FBRUEsSUFBQSxPQUFPLElBQUk7QUFDYjtBQUVBOzs7Ozs7OztBQVFHO0FBQ0csU0FBVSxZQUFZLENBQzFCLEdBQWdCLEVBQ2hCLElBQU8sRUFBQTtBQUVQLElBQUEsTUFBTSxtQkFBbUIsR0FBSSxHQUF1QixDQUFDO1NBQ2xELFdBQVcsQ0FBQyxXQUFXO0FBQ3ZCLFNBQUEsWUFBWSxDQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxDQUFDO0lBQ25DLElBQUksbUJBQW1CLEVBQUU7QUFDdkIsUUFBQSxLQUFLLG1CQUFtQixDQUFDLGdCQUFnQixFQUFFO0lBQzdDO0lBQ0EsT0FBUSxHQUF1QixDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDO0FBQzdEO0FBRUE7Ozs7Ozs7QUFPRztBQUNHLFNBQVUsc0JBQXNCLENBQ3BDLEdBQWdCLEVBQ2hCLElBQU8sRUFDUCxxQkFBNkIsa0JBQWtCLEVBQUE7SUFFL0MsWUFBWSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQyxhQUFhLENBQUMsa0JBQWtCLENBQUM7QUFDM0Q7QUFFQTs7Ozs7OztBQU9HO0FBQ0csU0FBVSxjQUFjLENBQzVCLEdBQXdELEVBQUE7QUFFeEQsSUFBQSxPQUFRLEdBQW1CLENBQUMsT0FBTyxLQUFLLFNBQVM7QUFDbkQ7QUFFQTs7Ozs7OztBQU9HO0FBQ0csU0FBVSw0QkFBNEIsQ0FDMUMsR0FBd0QsRUFBQTtBQUV4RCxJQUFBLElBQUksY0FBYyxDQUFDLEdBQUcsQ0FBQyxFQUFFO0FBQ3ZCLFFBQUEsT0FBTyxLQUFLO0lBQ2Q7SUFDQSxRQUNFLGFBQWEsSUFBSSxHQUFHO0FBQ3BCLFFBQUEsZUFBZSxJQUFJLEdBQUc7QUFDdEIsUUFBQSxnQkFBZ0IsSUFBSSxHQUFHO1FBQ3ZCLGdDQUFnQyxJQUFJLEdBQUc7QUFFM0M7QUFFQTs7Ozs7OztBQU9HO0FBQ0csU0FBVSxvQkFBb0IsQ0FDbEMsR0FBdUQsRUFBQTtJQUV2RCxJQUFJLEdBQUcsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLFNBQVMsRUFBRTtBQUNyQyxRQUFBLE9BQU8sS0FBSztJQUNkO0FBQ0EsSUFBQSxPQUFRLEdBQXlCLENBQUMsUUFBUSxLQUFLLFNBQVM7QUFDMUQ7QUFFQTs7OztBQUlHO1NBQ2EsZ0JBQWdCLEdBQUE7SUFDOUIsV0FBVyxDQUFDLEtBQUssRUFBRTtBQUNyQjs7QUNqTkE7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBcUJILE1BQU0sTUFBTSxHQUF1QjtBQUNqQyxJQUFBLENBQUEsUUFBQSx5QkFDRSxrREFBa0Q7UUFDbEQsNEJBQTRCO0FBQzlCLElBQUEsQ0FBQSxjQUFBLCtCQUF5QixnQ0FBZ0M7QUFDekQsSUFBQSxDQUFBLGVBQUEsZ0NBQ0UsbUZBQW1GO1FBQ25GLCtDQUErQztBQUNqRCxJQUFBLENBQUEsYUFBQSw4QkFBd0IsaURBQWlEO0FBQ3pFLElBQUEsQ0FBQSxvQkFBQSxxQ0FBK0Isc0NBQXNDO0FBQ3JFLElBQUEsQ0FBQSxZQUFBLDZCQUNFLHlFQUF5RTtBQUMzRSxJQUFBLENBQUEsc0JBQUEsdUNBQ0Usc0RBQXNEO1FBQ3RELHdCQUF3QjtBQUMxQixJQUFBLENBQUEsc0JBQUEsdUNBQ0UsdURBQXVEO0FBQ3pELElBQUEsQ0FBQSxVQUFBLDJCQUNFLCtFQUErRTtBQUNqRixJQUFBLENBQUEsU0FBQSwwQkFDRSxvRkFBb0Y7QUFDdEYsSUFBQSxDQUFBLFNBQUEsNEJBQ0Usa0ZBQWtGO0FBQ3BGLElBQUEsQ0FBQSxZQUFBLDZCQUNFLHFGQUFxRjtBQUN2RixJQUFBLENBQUEscUNBQUEsc0RBQ0UseUdBQXlHO0FBQzNHLElBQUEsQ0FBQSxnQ0FBQSxpREFDRTtDQUNIO0FBb0JNLE1BQU0sYUFBYSxHQUFHLElBQUksWUFBWSxDQUMzQyxLQUFLLEVBQ0wsVUFBVSxFQUNWLE1BQU0sQ0FDUDs7QUN6RkQ7Ozs7Ozs7Ozs7Ozs7OztBQWVHO01BY1UsZUFBZSxDQUFBO0FBYzFCLElBQUEsV0FBQSxDQUNFLE9BQXdCLEVBQ3hCLE1BQXFDLEVBQ3JDLFNBQTZCLEVBQUE7UUFOckIsSUFBQSxDQUFBLFVBQVUsR0FBRyxLQUFLO0FBUTFCLFFBQUEsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLEdBQUcsT0FBTyxFQUFFO0FBQzlCLFFBQUEsSUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLEdBQUcsTUFBTSxFQUFFO0FBQzVCLFFBQUEsSUFBSSxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUMsSUFBSTtBQUN4QixRQUFBLElBQUksQ0FBQywrQkFBK0I7WUFDbEMsTUFBTSxDQUFDLDhCQUE4QjtBQUN2QyxRQUFBLElBQUksQ0FBQyxVQUFVLEdBQUcsU0FBUztBQUMzQixRQUFBLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUN6QixJQUFJLFNBQVMsQ0FBQyxLQUFLLEVBQUUsTUFBTSxJQUFJLEVBQUEsUUFBQSw0QkFBdUIsQ0FDdkQ7SUFDSDtBQUVBLElBQUEsSUFBSSw4QkFBOEIsR0FBQTtRQUNoQyxJQUFJLENBQUMsY0FBYyxFQUFFO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLCtCQUErQjtJQUM3QztJQUVBLElBQUksOEJBQThCLENBQUMsR0FBWSxFQUFBO1FBQzdDLElBQUksQ0FBQyxjQUFjLEVBQUU7QUFDckIsUUFBQSxJQUFJLENBQUMsK0JBQStCLEdBQUcsR0FBRztJQUM1QztBQUVBLElBQUEsSUFBSSxJQUFJLEdBQUE7UUFDTixJQUFJLENBQUMsY0FBYyxFQUFFO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLEtBQUs7SUFDbkI7QUFFQSxJQUFBLElBQUksT0FBTyxHQUFBO1FBQ1QsSUFBSSxDQUFDLGNBQWMsRUFBRTtRQUNyQixPQUFPLElBQUksQ0FBQyxRQUFRO0lBQ3RCO0FBRUEsSUFBQSxJQUFJLE1BQU0sR0FBQTtRQUNSLElBQUksQ0FBQyxjQUFjLEVBQUU7UUFDckIsT0FBTyxJQUFJLENBQUMsT0FBTztJQUNyQjtBQUVBLElBQUEsSUFBSSxTQUFTLEdBQUE7UUFDWCxPQUFPLElBQUksQ0FBQyxVQUFVO0lBQ3hCO0FBRUEsSUFBQSxJQUFJLFNBQVMsR0FBQTtRQUNYLE9BQU8sSUFBSSxDQUFDLFVBQVU7SUFDeEI7SUFFQSxJQUFJLFNBQVMsQ0FBQyxHQUFZLEVBQUE7QUFDeEIsUUFBQSxJQUFJLENBQUMsVUFBVSxHQUFHLEdBQUc7SUFDdkI7QUFFQTs7O0FBR0c7SUFDTyxjQUFjLEdBQUE7QUFDdEIsUUFBQSxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7QUFDbEIsWUFBQSxNQUFNLGFBQWEsQ0FBQyxNQUFNLENBQUEsYUFBQSw2QkFBdUIsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQzNFO0lBQ0Y7QUFDRDs7QUN6R0Q7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBZUg7QUFDQTtBQUNBO0FBQ0EsU0FBUyxnQkFBZ0IsQ0FBQyxXQUFtQixFQUFFLFNBQWlCLEVBQUE7QUFDOUQsSUFBQSxNQUFNLFVBQVUsR0FBRyxZQUFZLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMxRCxJQUFBLElBQUksVUFBVSxLQUFLLElBQUksRUFBRTtBQUN2QixRQUFBLE9BQU8sQ0FBQyxLQUFLLENBQ1gscUJBQXFCLFNBQVMsQ0FBQSw2Q0FBQSxDQUErQyxDQUM5RTtRQUNEO0lBQ0Y7SUFDQSxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEdBQUc7QUFDM0MsSUFBQSxJQUFJLFFBQVEsS0FBSyxTQUFTLEVBQUU7QUFDMUIsUUFBQSxPQUFPLENBQUMsS0FBSyxDQUNYLHFCQUFxQixTQUFTLENBQUEsaURBQUEsQ0FBbUQsQ0FDbEY7UUFDRDtJQUNGO0FBQ0EsSUFBQSxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLEdBQUcsR0FBRyxJQUFJO0lBQzdDLE1BQU0sR0FBRyxHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFO0FBQ2hDLElBQUEsTUFBTSxJQUFJLEdBQUcsR0FBRyxHQUFHLEdBQUc7QUFDdEIsSUFBQSxJQUFJLElBQUksSUFBSSxDQUFDLEVBQUU7QUFDYixRQUFBLE9BQU8sQ0FBQyxLQUFLLENBQ1gscUJBQXFCLFNBQVMsQ0FBQSxtQ0FBQSxDQUFxQyxDQUNwRTtJQUNIO0FBQ0Y7QUFFTSxNQUFPLHFCQUNYLFNBQVEsZUFBZSxDQUFBO0FBT3ZCLElBQUEsV0FBQSxDQUNFLE9BQTBDLEVBQzFDLFlBQXVDLEVBQ3ZDLElBQVksRUFDWixTQUE2QixFQUFBOztBQUc3QixRQUFBLE1BQU0sOEJBQThCLEdBQ2xDLFlBQVksQ0FBQyw4QkFBOEIsS0FBSztjQUM1QyxZQUFZLENBQUM7Y0FDYixJQUFJOztBQUdWLFFBQUEsTUFBTSxNQUFNLEdBQWtDO1lBQzVDLElBQUk7WUFDSjtTQUNEO0FBRUQsUUFBQSxJQUFLLE9BQTJCLENBQUMsTUFBTSxLQUFLLFNBQVMsRUFBRTs7QUFFckQsWUFBQSxLQUFLLENBQUMsT0FBMEIsRUFBRSxNQUFNLEVBQUUsU0FBUyxDQUFDO1FBQ3REO2FBQU87WUFDTCxNQUFNLE9BQU8sR0FBb0IsT0FBMEI7WUFDM0QsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLFNBQVMsQ0FBQztRQUMzQzs7UUFHQSxJQUFJLENBQUMsYUFBYSxHQUFHO1lBQ25CLDhCQUE4QjtBQUM5QixZQUFBLEdBQUc7U0FDSjs7QUFHRCxRQUFBLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLEVBQUU7WUFDbEMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLEVBQUUsYUFBYSxDQUFDO1FBQ2pFOztBQUdBLFFBQUEsSUFBSSxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsRUFBRTtZQUNwQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsRUFBRSxlQUFlLENBQUM7UUFDckU7QUFFQSxRQUFBLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJO0FBQ2pDLFFBQUEsSUFBSSxPQUFPLG9CQUFvQixLQUFLLFdBQVcsRUFBRTtBQUMvQyxZQUFBLElBQUksQ0FBQyxxQkFBcUIsR0FBRyxJQUFJLG9CQUFvQixDQUFDLE1BQUs7Z0JBQ3pELElBQUksQ0FBQyxnQkFBZ0IsRUFBRTtBQUN6QixZQUFBLENBQUMsQ0FBQztRQUNKO0FBRUEsUUFBQSxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUM7UUFDbEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQzs7O0FBSW5ELFFBQUEsSUFBSSxDQUFDLGFBQWEsQ0FBQyxjQUFjLEdBQUcsU0FBUztBQUM3QyxRQUFBLFlBQVksQ0FBQyxjQUFjLEdBQUcsU0FBUztBQUV2QyxRQUFBLGVBQWUsQ0FBQ0EsTUFBVyxFQUFFQyxTQUFPLEVBQUUsV0FBVyxDQUFDO0lBQ3BEO0lBRUEsTUFBTSxHQUFBO0FBQ0osUUFBQSxPQUFPLFNBQVM7SUFDbEI7QUFFQSxJQUFBLElBQUksUUFBUSxHQUFBO1FBQ1YsT0FBTyxJQUFJLENBQUMsU0FBUztJQUN2Qjs7O0FBSUEsSUFBQSxXQUFXLENBQUMsR0FBdUIsRUFBQTtBQUNqQyxRQUFBLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNsQjtRQUNGO1FBQ0EsSUFBSSxDQUFDLFNBQVMsRUFBRTtRQUNoQixJQUFJLEdBQUcsS0FBSyxTQUFTLElBQUksSUFBSSxDQUFDLHFCQUFxQixLQUFLLElBQUksRUFBRTtZQUM1RCxJQUFJLENBQUMscUJBQXFCLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUM7UUFDaEQ7SUFDRjs7SUFHQSxXQUFXLEdBQUE7QUFDVCxRQUFBLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtBQUNsQixZQUFBLE9BQU8sQ0FBQztRQUNWO0FBQ0EsUUFBQSxPQUFPLEVBQUUsSUFBSSxDQUFDLFNBQVM7SUFDekI7Ozs7SUFLUSxnQkFBZ0IsR0FBQTtBQUN0QixRQUFBLEtBQUssU0FBUyxDQUFDLElBQUksQ0FBQztJQUN0QjtBQUVBLElBQUEsSUFBSSxRQUFRLEdBQUE7UUFDVixJQUFJLENBQUMsY0FBYyxFQUFFO1FBQ3JCLE9BQU8sSUFBSSxDQUFDLGFBQWE7SUFDM0I7QUFFQTs7O0FBR0c7SUFDTyxjQUFjLEdBQUE7QUFDdEIsUUFBQSxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7QUFDbEIsWUFBQSxNQUFNLGFBQWEsQ0FBQyxNQUFNLENBQUEsb0JBQUEsbUNBQTZCO1FBQ3pEO0lBQ0Y7QUFDRDs7QUMvS0Q7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBNkNIOzs7O0FBSUc7QUFDSSxNQUFNLFdBQVcsR0FBRztTQTJFWCxhQUFhLENBQzNCLFFBQTBCLEVBQzFCLFNBQVMsR0FBRyxFQUFFLEVBQUE7SUFFZCxJQUFJLE9BQU8sR0FBRyxRQUFRO0FBRXRCLElBQUEsSUFBSSxPQUFPLFNBQVMsS0FBSyxRQUFRLEVBQUU7UUFDakMsTUFBTSxJQUFJLEdBQUcsU0FBUztBQUN0QixRQUFBLFNBQVMsR0FBRyxFQUFFLElBQUksRUFBRTtJQUN0QjtBQUVBLElBQUEsTUFBTSxNQUFNLEdBQWtDO0FBQzVDLFFBQUEsSUFBSSxFQUFFLGtCQUFrQjtBQUN4QixRQUFBLDhCQUE4QixFQUFFLElBQUk7QUFDcEMsUUFBQSxHQUFHO0tBQ0o7QUFDRCxJQUFBLE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJO0lBRXhCLElBQUksT0FBTyxJQUFJLEtBQUssUUFBUSxJQUFJLENBQUMsSUFBSSxFQUFFO1FBQ3JDLE1BQU0sYUFBYSxDQUFDLE1BQU0sQ0FBQSxjQUFBLDhCQUF3QjtBQUNoRCxZQUFBLE9BQU8sRUFBRSxNQUFNLENBQUMsSUFBSTtBQUNyQixTQUFBLENBQUM7SUFDSjtBQUVBLElBQUEsT0FBTyxLQUFQLE9BQU8sR0FBSyxtQkFBbUIsRUFBRSxDQUFBO0lBRWpDLElBQUksQ0FBQyxPQUFPLEVBQUU7QUFDWixRQUFBLE1BQU0sYUFBYSxDQUFDLE1BQU0sQ0FBQSxZQUFBLDJCQUFxQjtJQUNqRDtJQUVBLE1BQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFvQjtJQUN0RCxJQUFJLFdBQVcsRUFBRTs7UUFFZixJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDNUMsTUFBTSxhQUFhLENBQUMsTUFBTSxDQUFBLGVBQUEsK0JBQXlCO0FBQ2pELGdCQUFBLE9BQU8sRUFBRSxJQUFJO0FBQ2IsZ0JBQUEsZUFBZSxFQUFFLFNBQVM7Z0JBQzFCLFFBQVEsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUM7QUFDN0MsZ0JBQUEsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTztBQUNqQyxhQUFBLENBQUM7UUFDSjthQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNqRCxNQUFNLGFBQWEsQ0FBQyxNQUFNLENBQUEsZUFBQSwrQkFBeUI7QUFDakQsZ0JBQUEsT0FBTyxFQUFFLElBQUk7QUFDYixnQkFBQSxlQUFlLEVBQUUsUUFBUTtnQkFDekIsUUFBUSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQztBQUM1QyxnQkFBQSxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNO0FBQ2hDLGFBQUEsQ0FBQztRQUNKO2FBQU87QUFDTCxZQUFBLE9BQU8sV0FBVztRQUNwQjtJQUNGO0FBRUEsSUFBQSxNQUFNLFNBQVMsR0FBRyxJQUFJLGtCQUFrQixDQUFDLElBQUksQ0FBQztJQUM5QyxLQUFLLE1BQU0sU0FBUyxJQUFJLFdBQVcsQ0FBQyxNQUFNLEVBQUUsRUFBRTtBQUM1QyxRQUFBLFNBQVMsQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDO0lBQ25DO0lBRUEsTUFBTSxNQUFNLEdBQUcsSUFBSSxlQUFlLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxTQUFTLENBQUM7QUFFOUQsSUFBQSxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUM7QUFFdkIsSUFBQSxPQUFPLE1BQU07QUFDZjtTQXVFZ0IsbUJBQW1CLENBQ2pDLFFBQW9FLEVBQ3BFLG1CQUE4QyxFQUFFLEVBQUE7QUFFaEQsSUFBQSxJQUFJLFNBQVMsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLEVBQUU7O0FBRWpDLFFBQUEsTUFBTSxhQUFhLENBQUMsTUFBTSxDQUFBLGdDQUFBLCtDQUF5QztJQUNyRTtBQUVBLElBQUEsSUFBSSxlQUE0QztBQUNoRCxJQUFBLElBQUksaUJBQWlCLEdBQThCLGdCQUFnQixJQUFJLEVBQUU7SUFFekUsSUFBSSxRQUFRLEVBQUU7QUFDWixRQUFBLElBQUksY0FBYyxDQUFDLFFBQVEsQ0FBQyxFQUFFO0FBQzVCLFlBQUEsZUFBZSxHQUFHLFFBQVEsQ0FBQyxPQUFPO1FBQ3BDO0FBQU8sYUFBQSxJQUFJLDRCQUE0QixDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQ2pELGlCQUFpQixHQUFHLFFBQVE7UUFDOUI7YUFBTztZQUNMLGVBQWUsR0FBRyxRQUFRO1FBQzVCO0lBQ0Y7QUFFQSxJQUFBLElBQUksaUJBQWlCLENBQUMsOEJBQThCLEtBQUssU0FBUyxFQUFFO0FBQ2xFLFFBQUEsaUJBQWlCLENBQUMsOEJBQThCLEdBQUcsSUFBSTtJQUN6RDtBQUVBLElBQUEsZUFBZSxLQUFmLGVBQWUsR0FBSyxtQkFBbUIsRUFBRSxDQUFBO0lBQ3pDLElBQUksQ0FBQyxlQUFlLEVBQUU7QUFDcEIsUUFBQSxNQUFNLGFBQWEsQ0FBQyxNQUFNLENBQUEsWUFBQSwyQkFBcUI7SUFDakQ7O0FBR0EsSUFBQSxNQUFNLE9BQU8sR0FBRztBQUNkLFFBQUEsR0FBRyxpQkFBaUI7QUFDcEIsUUFBQSxHQUFHO0tBQ0o7OztBQUlELElBQUEsSUFBSSxPQUFPLENBQUMsY0FBYyxLQUFLLFNBQVMsRUFBRTtRQUN4QyxPQUFPLE9BQU8sQ0FBQyxjQUFjO0lBQy9CO0FBRUEsSUFBQSxNQUFNLFFBQVEsR0FBRyxDQUFDLENBQVMsS0FBWTtBQUNyQyxRQUFBLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FDbEIsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQ3hELENBQUMsQ0FDRjtBQUNILElBQUEsQ0FBQztBQUVELElBQUEsSUFBSSxpQkFBaUIsQ0FBQyxjQUFjLEtBQUssU0FBUyxFQUFFO0FBQ2xELFFBQUEsSUFBSSxPQUFPLG9CQUFvQixLQUFLLFdBQVcsRUFBRTtBQUMvQyxZQUFBLE1BQU0sYUFBYSxDQUFDLE1BQU0sQ0FBQSxxQ0FBQSxxREFFeEIsRUFBRSxDQUNIO1FBQ0g7SUFDRjtBQUVBLElBQUEsTUFBTSxVQUFVLEdBQUcsRUFBRSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ3pELE1BQU0sV0FBVyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFzQjtJQUNwRSxJQUFJLFdBQVcsRUFBRTtBQUNkLFFBQUEsV0FBcUMsQ0FBQyxXQUFXLENBQ2hELGlCQUFpQixDQUFDLGNBQWMsQ0FDakM7QUFDRCxRQUFBLE9BQU8sV0FBVztJQUNwQjtBQUVBLElBQUEsTUFBTSxTQUFTLEdBQUcsSUFBSSxrQkFBa0IsQ0FBQyxVQUFVLENBQUM7SUFDcEQsS0FBSyxNQUFNLFNBQVMsSUFBSSxXQUFXLENBQUMsTUFBTSxFQUFFLEVBQUU7QUFDNUMsUUFBQSxTQUFTLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQztJQUNuQztBQUVBLElBQUEsTUFBTSxNQUFNLEdBQUcsSUFBSSxxQkFBcUIsQ0FDdEMsZUFBZSxFQUNmLGlCQUFpQixFQUNqQixVQUFVLEVBQ1YsU0FBUyxDQUNWO0FBRUQsSUFBQSxXQUFXLENBQUMsR0FBRyxDQUFDLFVBQVUsRUFBRSxNQUFNLENBQUM7QUFFbkMsSUFBQSxPQUFPLE1BQU07QUFDZjtBQUVBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBNEJHO0FBQ0csU0FBVSxNQUFNLENBQUMsSUFBQSxHQUFlLGtCQUFrQixFQUFBO0lBQ3RELE1BQU0sR0FBRyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0lBQzNCLElBQUksQ0FBQyxHQUFHLElBQUksSUFBSSxLQUFLLGtCQUFrQixJQUFJLG1CQUFtQixFQUFFLEVBQUU7UUFDaEUsT0FBTyxhQUFhLEVBQUU7SUFDeEI7SUFDQSxJQUFJLENBQUMsR0FBRyxFQUFFO1FBQ1IsTUFBTSxhQUFhLENBQUMsTUFBTSxDQUFBLFFBQUEsd0JBQWtCLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxDQUFDO0lBQ2hFO0FBRUEsSUFBQSxPQUFPLEdBQUc7QUFDWjtBQUVBOzs7QUFHRztTQUNhLE9BQU8sR0FBQTtJQUNyQixPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO0FBQ25DO0FBRUE7Ozs7Ozs7Ozs7Ozs7Ozs7QUFnQkc7QUFDSSxlQUFlLFNBQVMsQ0FBQyxHQUFnQixFQUFBO0lBQzlDLElBQUksZ0JBQWdCLEdBQUcsS0FBSztBQUM1QixJQUFBLE1BQU0sSUFBSSxHQUFHLEdBQUcsQ0FBQyxJQUFJO0FBQ3JCLElBQUEsSUFBSSxLQUFLLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO1FBQ25CLGdCQUFnQixHQUFHLElBQUk7QUFDdkIsUUFBQSxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztJQUNwQjtBQUFPLFNBQUEsSUFBSSxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFO1FBQ2hDLE1BQU0saUJBQWlCLEdBQUcsR0FBNEI7QUFDdEQsUUFBQSxJQUFJLGlCQUFpQixDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsRUFBRTtBQUN4QyxZQUFBLFdBQVcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1lBQ3hCLGdCQUFnQixHQUFHLElBQUk7UUFDekI7SUFDRjtJQUVBLElBQUksZ0JBQWdCLEVBQUU7QUFDcEIsUUFBQSxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQ2QsR0FBdUIsQ0FBQztBQUN0QixhQUFBLFlBQVk7YUFDWixHQUFHLENBQUMsUUFBUSxJQUFJLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUN0QztBQUNBLFFBQUEsR0FBdUIsQ0FBQyxTQUFTLEdBQUcsSUFBSTtJQUMzQztBQUNGO0FBRUE7Ozs7Ozs7QUFPRztTQUNhLGVBQWUsQ0FDN0IsZ0JBQXdCLEVBQ3hCLE9BQWUsRUFDZixPQUFnQixFQUFBOzs7SUFJaEIsSUFBSSxPQUFPLEdBQUcsbUJBQW1CLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxnQkFBZ0I7SUFDdkUsSUFBSSxPQUFPLEVBQUU7QUFDWCxRQUFBLE9BQU8sSUFBSSxDQUFBLENBQUEsRUFBSSxPQUFPLENBQUEsQ0FBRTtJQUMxQjtJQUNBLE1BQU0sZUFBZSxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO0lBQzlDLE1BQU0sZUFBZSxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO0FBQzlDLElBQUEsSUFBSSxlQUFlLElBQUksZUFBZSxFQUFFO0FBQ3RDLFFBQUEsTUFBTSxPQUFPLEdBQUc7WUFDZCxDQUFBLDRCQUFBLEVBQStCLE9BQU8sQ0FBQSxnQkFBQSxFQUFtQixPQUFPLENBQUEsRUFBQTtTQUNqRTtRQUNELElBQUksZUFBZSxFQUFFO0FBQ25CLFlBQUEsT0FBTyxDQUFDLElBQUksQ0FDVixpQkFBaUIsT0FBTyxDQUFBLGlEQUFBLENBQW1ELENBQzVFO1FBQ0g7QUFDQSxRQUFBLElBQUksZUFBZSxJQUFJLGVBQWUsRUFBRTtBQUN0QyxZQUFBLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3JCO1FBQ0EsSUFBSSxlQUFlLEVBQUU7QUFDbkIsWUFBQSxPQUFPLENBQUMsSUFBSSxDQUNWLGlCQUFpQixPQUFPLENBQUEsaURBQUEsQ0FBbUQsQ0FDNUU7UUFDSDtRQUNBLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUM5QjtJQUNGO0lBQ0Esa0JBQWtCLENBQ2hCLElBQUksU0FBUyxDQUNYLEdBQUcsT0FBTyxDQUFBLFFBQUEsQ0FBa0IsRUFDNUIsT0FBTyxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFBLFNBQUEsNkJBRTdCLENBQ0Y7QUFDSDtBQUVBOzs7Ozs7QUFNRztBQUNHLFNBQVUsS0FBSyxDQUNuQixXQUErQixFQUMvQixPQUFvQixFQUFBO0lBRXBCLElBQUksV0FBVyxLQUFLLElBQUksSUFBSSxPQUFPLFdBQVcsS0FBSyxVQUFVLEVBQUU7QUFDN0QsUUFBQSxNQUFNLGFBQWEsQ0FBQyxNQUFNLENBQUEsc0JBQUEscUNBQStCO0lBQzNEO0FBQ0EsSUFBQSxpQkFBaUIsQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDO0FBQ3pDO0FBRUE7Ozs7Ozs7O0FBUUc7QUFDRyxTQUFVLFdBQVcsQ0FBQyxRQUF3QixFQUFBO0lBQ2xEQyxhQUFlLENBQUMsUUFBUSxDQUFDO0FBQzNCOztBQzlnQkE7Ozs7Ozs7Ozs7Ozs7OztBQWVHO0FBU0gsTUFBTSxPQUFPLEdBQUcsNkJBQTZCO0FBQzdDLE1BQU0sVUFBVSxHQUFHLENBQUM7QUFDcEIsTUFBTSxVQUFVLEdBQUcsMEJBQTBCO0FBUzdDLElBQUksU0FBUyxHQUF3QyxJQUFJO0FBQ3pELFNBQVMsWUFBWSxHQUFBO0lBQ25CLElBQUksQ0FBQyxTQUFTLEVBQUU7QUFDZCxRQUFBLFNBQVMsR0FBRyxNQUFNLENBQVEsT0FBTyxFQUFFLFVBQVUsRUFBRTtBQUM3QyxZQUFBLE9BQU8sRUFBRSxDQUFDLEVBQUUsRUFBRSxVQUFVLEtBQUk7Ozs7OztnQkFNMUIsUUFBUSxVQUFVO0FBQ2hCLG9CQUFBLEtBQUssQ0FBQztBQUNKLHdCQUFBLElBQUk7QUFDRiw0QkFBQSxFQUFFLENBQUMsaUJBQWlCLENBQUMsVUFBVSxDQUFDO3dCQUNsQzt3QkFBRSxPQUFPLENBQUMsRUFBRTs7OztBQUlWLDRCQUFBLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO3dCQUNqQjs7WUFFTjtBQUNELFNBQUEsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUc7WUFDWCxNQUFNLGFBQWEsQ0FBQyxNQUFNLENBQUEsVUFBQSwwQkFBb0I7Z0JBQzVDLG9CQUFvQixFQUFFLENBQUMsQ0FBQztBQUN6QixhQUFBLENBQUM7QUFDSixRQUFBLENBQUMsQ0FBQztJQUNKO0FBQ0EsSUFBQSxPQUFPLFNBQVM7QUFDbEI7QUFFTyxlQUFlLDJCQUEyQixDQUMvQyxHQUFnQixFQUFBO0FBRWhCLElBQUEsSUFBSTtBQUNGLFFBQUEsTUFBTSxFQUFFLEdBQUcsTUFBTSxZQUFZLEVBQUU7UUFDL0IsTUFBTSxFQUFFLEdBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUM7QUFDckMsUUFBQSxNQUFNLE1BQU0sR0FBRyxNQUFNLEVBQUUsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O1FBR3BFLE1BQU0sRUFBRSxDQUFDLElBQUk7QUFDYixRQUFBLE9BQU8sTUFBTTtJQUNmO0lBQUUsT0FBTyxDQUFDLEVBQUU7QUFDVixRQUFBLElBQUksQ0FBQyxZQUFZLGFBQWEsRUFBRTtBQUM5QixZQUFBLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztRQUN4QjthQUFPO0FBQ0wsWUFBQSxNQUFNLFdBQVcsR0FBRyxhQUFhLENBQUMsTUFBTSxDQUFBLFNBQUEseUJBQW1CO2dCQUN6RCxvQkFBb0IsRUFBRyxDQUFXLEVBQUU7QUFDckMsYUFBQSxDQUFDO0FBQ0YsWUFBQSxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUM7UUFDbEM7SUFDRjtBQUNGO0FBRU8sZUFBZSwwQkFBMEIsQ0FDOUMsR0FBZ0IsRUFDaEIsZUFBc0MsRUFBQTtBQUV0QyxJQUFBLElBQUk7QUFDRixRQUFBLE1BQU0sRUFBRSxHQUFHLE1BQU0sWUFBWSxFQUFFO1FBQy9CLE1BQU0sRUFBRSxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFLFdBQVcsQ0FBQztRQUNsRCxNQUFNLFdBQVcsR0FBRyxFQUFFLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQztRQUM5QyxNQUFNLFdBQVcsQ0FBQyxHQUFHLENBQUMsZUFBZSxFQUFFLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUN2RCxNQUFNLEVBQUUsQ0FBQyxJQUFJO0lBQ2Y7SUFBRSxPQUFPLENBQUMsRUFBRTtBQUNWLFFBQUEsSUFBSSxDQUFDLFlBQVksYUFBYSxFQUFFO0FBQzlCLFlBQUEsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQ3hCO2FBQU87QUFDTCxZQUFBLE1BQU0sV0FBVyxHQUFHLGFBQWEsQ0FBQyxNQUFNLENBQUEsU0FBQSwyQkFBcUI7Z0JBQzNELG9CQUFvQixFQUFHLENBQVcsRUFBRTtBQUNyQyxhQUFBLENBQUM7QUFDRixZQUFBLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQztRQUNsQztJQUNGO0FBQ0Y7QUFFQSxTQUFTLFVBQVUsQ0FBQyxHQUFnQixFQUFBO0lBQ2xDLE9BQU8sQ0FBQSxFQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUEsQ0FBQSxFQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFBLENBQUU7QUFDM0M7O0FDakhBOzs7Ozs7Ozs7Ozs7Ozs7QUFlRztBQXNCSCxNQUFNLGdCQUFnQixHQUFHLElBQUk7QUFDdEIsTUFBTSx5QkFBeUIsR0FBRyxFQUFFO01BRTlCLG9CQUFvQixDQUFBO0FBeUIvQixJQUFBLFdBQUEsQ0FBNkIsU0FBNkIsRUFBQTtRQUE3QixJQUFBLENBQUEsU0FBUyxHQUFULFNBQVM7QUFsQnRDOzs7Ozs7OztBQVFHO1FBQ0gsSUFBQSxDQUFBLGdCQUFnQixHQUFpQyxJQUFJO0FBVW5ELFFBQUEsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsWUFBWSxFQUFFO1FBQzVELElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxvQkFBb0IsQ0FBQyxHQUFHLENBQUM7QUFDN0MsUUFBQSxJQUFJLENBQUMsdUJBQXVCLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFHO0FBQ2hFLFlBQUEsSUFBSSxDQUFDLGdCQUFnQixHQUFHLE1BQU07QUFDOUIsWUFBQSxPQUFPLE1BQU07QUFDZixRQUFBLENBQUMsQ0FBQztJQUNKO0FBRUE7Ozs7OztBQU1HO0FBQ0gsSUFBQSxNQUFNLGdCQUFnQixHQUFBO0FBQ3BCLFFBQUEsSUFBSTtBQUNGLFlBQUEsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDO2lCQUN6QixXQUFXLENBQUMsaUJBQWlCO0FBQzdCLGlCQUFBLFlBQVksRUFBRTs7O0FBSWpCLFlBQUEsTUFBTSxLQUFLLEdBQUcsY0FBYyxDQUFDLHFCQUFxQixFQUFFO0FBQ3BELFlBQUEsTUFBTSxJQUFJLEdBQUcsZ0JBQWdCLEVBQUU7WUFDL0IsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsVUFBVSxJQUFJLElBQUksRUFBRTtBQUM3QyxnQkFBQSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsTUFBTSxJQUFJLENBQUMsdUJBQXVCOztnQkFFMUQsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsVUFBVSxJQUFJLElBQUksRUFBRTtvQkFDN0M7Z0JBQ0Y7WUFDRjs7O0FBR0EsWUFBQSxJQUNFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxxQkFBcUIsS0FBSyxJQUFJO0FBQ3BELGdCQUFBLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUNuQyxtQkFBbUIsSUFBSSxtQkFBbUIsQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUN6RCxFQUNEO2dCQUNBO1lBQ0Y7aUJBQU87O0FBRUwsZ0JBQUEsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLENBQUM7OztnQkFJdEQsSUFDRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyx5QkFBeUIsRUFDbkU7b0JBQ0EsTUFBTSxvQkFBb0IsR0FBRyx1QkFBdUIsQ0FDbEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FDakM7b0JBQ0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsb0JBQW9CLEVBQUUsQ0FBQyxDQUFDO2dCQUNsRTtZQUNGO1lBRUEsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7UUFDdkQ7UUFBRSxPQUFPLENBQUMsRUFBRTtBQUNWLFlBQUEsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDaEI7SUFDRjtBQUVBOzs7Ozs7QUFNRztBQUNILElBQUEsTUFBTSxtQkFBbUIsR0FBQTtBQUN2QixRQUFBLElBQUk7QUFDRixZQUFBLElBQUksSUFBSSxDQUFDLGdCQUFnQixLQUFLLElBQUksRUFBRTtnQkFDbEMsTUFBTSxJQUFJLENBQUMsdUJBQXVCO1lBQ3BDOztBQUVBLFlBQUEsSUFDRSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsVUFBVSxJQUFJLElBQUk7Z0JBQ3pDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsTUFBTSxLQUFLLENBQUMsRUFDN0M7QUFDQSxnQkFBQSxPQUFPLEVBQUU7WUFDWDtBQUNBLFlBQUEsTUFBTSxJQUFJLEdBQUcsZ0JBQWdCLEVBQUU7O0FBRS9CLFlBQUEsTUFBTSxFQUFFLGdCQUFnQixFQUFFLGFBQWEsRUFBRSxHQUFHLDBCQUEwQixDQUNwRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUNqQztBQUNELFlBQUEsTUFBTSxZQUFZLEdBQUcsNkJBQTZCLENBQ2hELElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFVBQVUsRUFBRSxnQkFBZ0IsRUFBRSxDQUFDLENBQzdEOztBQUVELFlBQUEsSUFBSSxDQUFDLGdCQUFnQixDQUFDLHFCQUFxQixHQUFHLElBQUk7QUFDbEQsWUFBQSxJQUFJLGFBQWEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFOztBQUU1QixnQkFBQSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxHQUFHLGFBQWE7Ozs7Z0JBSWhELE1BQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDO1lBQ3REO2lCQUFPO0FBQ0wsZ0JBQUEsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsR0FBRyxFQUFFOztnQkFFckMsS0FBSyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7WUFDckQ7QUFDQSxZQUFBLE9BQU8sWUFBWTtRQUNyQjtRQUFFLE9BQU8sQ0FBQyxFQUFFO0FBQ1YsWUFBQSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNkLFlBQUEsT0FBTyxFQUFFO1FBQ1g7SUFDRjtBQUNEO0FBRUQsU0FBUyxnQkFBZ0IsR0FBQTtBQUN2QixJQUFBLE1BQU0sS0FBSyxHQUFHLElBQUksSUFBSSxFQUFFOztJQUV4QixPQUFPLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztBQUM3QztTQUVnQiwwQkFBMEIsQ0FDeEMsZUFBc0MsRUFDdEMsT0FBTyxHQUFHLGdCQUFnQixFQUFBOzs7SUFPMUIsTUFBTSxnQkFBZ0IsR0FBNEIsRUFBRTs7QUFFcEQsSUFBQSxJQUFJLGFBQWEsR0FBRyxlQUFlLENBQUMsS0FBSyxFQUFFO0FBQzNDLElBQUEsS0FBSyxNQUFNLG1CQUFtQixJQUFJLGVBQWUsRUFBRTs7QUFFakQsUUFBQSxNQUFNLGNBQWMsR0FBRyxnQkFBZ0IsQ0FBQyxJQUFJLENBQzFDLEVBQUUsSUFBSSxFQUFFLENBQUMsS0FBSyxLQUFLLG1CQUFtQixDQUFDLEtBQUssQ0FDN0M7UUFDRCxJQUFJLENBQUMsY0FBYyxFQUFFOztZQUVuQixnQkFBZ0IsQ0FBQyxJQUFJLENBQUM7Z0JBQ3BCLEtBQUssRUFBRSxtQkFBbUIsQ0FBQyxLQUFLO0FBQ2hDLGdCQUFBLEtBQUssRUFBRSxDQUFDLG1CQUFtQixDQUFDLElBQUk7QUFDakMsYUFBQSxDQUFDO0FBQ0YsWUFBQSxJQUFJLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLE9BQU8sRUFBRTs7O2dCQUcxQyxnQkFBZ0IsQ0FBQyxHQUFHLEVBQUU7Z0JBQ3RCO1lBQ0Y7UUFDRjthQUFPO1lBQ0wsY0FBYyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDOzs7QUFHbkQsWUFBQSxJQUFJLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLE9BQU8sRUFBRTtBQUMxQyxnQkFBQSxjQUFjLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRTtnQkFDMUI7WUFDRjtRQUNGOzs7QUFHQSxRQUFBLGFBQWEsR0FBRyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUN4QztJQUNBLE9BQU87UUFDTCxnQkFBZ0I7UUFDaEI7S0FDRDtBQUNIO01BRWEsb0JBQW9CLENBQUE7QUFFL0IsSUFBQSxXQUFBLENBQW1CLEdBQWdCLEVBQUE7UUFBaEIsSUFBQSxDQUFBLEdBQUcsR0FBSCxHQUFHO0FBQ3BCLFFBQUEsSUFBSSxDQUFDLHVCQUF1QixHQUFHLElBQUksQ0FBQyw0QkFBNEIsRUFBRTtJQUNwRTtBQUNBLElBQUEsTUFBTSw0QkFBNEIsR0FBQTtBQUNoQyxRQUFBLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxFQUFFO0FBQzNCLFlBQUEsT0FBTyxLQUFLO1FBQ2Q7YUFBTztBQUNMLFlBQUEsT0FBTyx5QkFBeUI7QUFDN0IsaUJBQUEsSUFBSSxDQUFDLE1BQU0sSUFBSTtBQUNmLGlCQUFBLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQztRQUN2QjtJQUNGO0FBQ0E7O0FBRUc7QUFDSCxJQUFBLE1BQU0sSUFBSSxHQUFBO0FBQ1IsUUFBQSxNQUFNLGVBQWUsR0FBRyxNQUFNLElBQUksQ0FBQyx1QkFBdUI7UUFDMUQsSUFBSSxDQUFDLGVBQWUsRUFBRTtBQUNwQixZQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsRUFBRSxFQUFFO1FBQzNCO2FBQU87WUFDTCxNQUFNLGtCQUFrQixHQUFHLE1BQU0sMkJBQTJCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUN0RSxZQUFBLElBQUksa0JBQWtCLEVBQUUsVUFBVSxFQUFFO0FBQ2xDLGdCQUFBLE9BQU8sa0JBQWtCO1lBQzNCO2lCQUFPO0FBQ0wsZ0JBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUU7WUFDM0I7UUFDRjtJQUNGOztJQUVBLE1BQU0sU0FBUyxDQUFDLGdCQUF1QyxFQUFBO0FBQ3JELFFBQUEsTUFBTSxlQUFlLEdBQUcsTUFBTSxJQUFJLENBQUMsdUJBQXVCO1FBQzFELElBQUksQ0FBQyxlQUFlLEVBQUU7WUFDcEI7UUFDRjthQUFPO0FBQ0wsWUFBQSxNQUFNLHdCQUF3QixHQUFHLE1BQU0sSUFBSSxDQUFDLElBQUksRUFBRTtBQUNsRCxZQUFBLE9BQU8sMEJBQTBCLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDMUMscUJBQXFCLEVBQ25CLGdCQUFnQixDQUFDLHFCQUFxQjtBQUN0QyxvQkFBQSx3QkFBd0IsQ0FBQyxxQkFBcUI7Z0JBQ2hELFVBQVUsRUFBRSxnQkFBZ0IsQ0FBQztBQUM5QixhQUFBLENBQUM7UUFDSjtJQUNGOztJQUVBLE1BQU0sR0FBRyxDQUFDLGdCQUF1QyxFQUFBO0FBQy9DLFFBQUEsTUFBTSxlQUFlLEdBQUcsTUFBTSxJQUFJLENBQUMsdUJBQXVCO1FBQzFELElBQUksQ0FBQyxlQUFlLEVBQUU7WUFDcEI7UUFDRjthQUFPO0FBQ0wsWUFBQSxNQUFNLHdCQUF3QixHQUFHLE1BQU0sSUFBSSxDQUFDLElBQUksRUFBRTtBQUNsRCxZQUFBLE9BQU8sMEJBQTBCLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtnQkFDMUMscUJBQXFCLEVBQ25CLGdCQUFnQixDQUFDLHFCQUFxQjtBQUN0QyxvQkFBQSx3QkFBd0IsQ0FBQyxxQkFBcUI7QUFDaEQsZ0JBQUEsVUFBVSxFQUFFO29CQUNWLEdBQUcsd0JBQXdCLENBQUMsVUFBVTtvQkFDdEMsR0FBRyxnQkFBZ0IsQ0FBQztBQUNyQjtBQUNGLGFBQUEsQ0FBQztRQUNKO0lBQ0Y7QUFDRDtBQUVEOzs7O0FBSUc7QUFDRyxTQUFVLFVBQVUsQ0FBQyxlQUF3QyxFQUFBOztBQUVqRSxJQUFBLE9BQU8sNkJBQTZCOztBQUVsQyxJQUFBLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFVBQVUsRUFBRSxlQUFlLEVBQUUsQ0FBQyxDQUM1RCxDQUFDLE1BQU07QUFDVjtBQUVBOzs7QUFHRztBQUNHLFNBQVUsdUJBQXVCLENBQ3JDLFVBQWlDLEVBQUE7QUFFakMsSUFBQSxJQUFJLFVBQVUsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO1FBQzNCLE9BQU8sRUFBRTtJQUNYO0lBRUEsSUFBSSxvQkFBb0IsR0FBRyxDQUFDO0lBQzVCLElBQUkscUJBQXFCLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFFOUMsSUFBQSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsVUFBVSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtRQUMxQyxJQUFJLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUcscUJBQXFCLEVBQUU7QUFDOUMsWUFBQSxxQkFBcUIsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtZQUMxQyxvQkFBb0IsR0FBRyxDQUFDO1FBQzFCO0lBQ0Y7QUFFQSxJQUFBLE9BQU8sb0JBQW9CO0FBQzdCOztBQzVVQTs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUFTRyxTQUFVLHNCQUFzQixDQUFDLE9BQWdCLEVBQUE7QUFDckQsSUFBQSxrQkFBa0IsQ0FDaEIsSUFBSSxTQUFTLENBQ1gsaUJBQWlCLEVBQ2pCLFNBQVMsSUFBSSxJQUFJLHlCQUF5QixDQUFDLFNBQVMsQ0FBQyxFQUFBLFNBQUEsNkJBRXRELENBQ0Y7QUFDRCxJQUFBLGtCQUFrQixDQUNoQixJQUFJLFNBQVMsQ0FDWCxXQUFXLEVBQ1gsU0FBUyxJQUFJLElBQUksb0JBQW9CLENBQUMsU0FBUyxDQUFDLEVBQUEsU0FBQSw2QkFFakQsQ0FDRjs7QUFHRCxJQUFBLGVBQWUsQ0FBQ0MsTUFBSSxFQUFFRixTQUFPLEVBQUUsT0FBTyxDQUFDOztBQUV2QyxJQUFBLGVBQWUsQ0FBQ0UsTUFBSSxFQUFFRixTQUFPLEVBQUUsU0FBa0IsQ0FBQzs7QUFFbEQsSUFBQSxlQUFlLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQztBQUNoQzs7QUM5Q0E7Ozs7O0FBS0c7QUFFSDs7Ozs7Ozs7Ozs7Ozs7O0FBZUc7QUFRSCxzQkFBc0IsQ0FBQyxFQUFpQixDQUFDOzs7OyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExXX0=